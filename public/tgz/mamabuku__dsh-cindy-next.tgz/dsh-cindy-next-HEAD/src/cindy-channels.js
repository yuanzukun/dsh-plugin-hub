/**
 * The Cindy invoke channel router.
 *
 * This is the Host's half of the DeviceLink tunnel: the phone sends
 * `invoke { channel, args }` and gets one `invoke-result` back. The channel set
 * is a contract — `Cindy/packages/device-link/src/allowlist.ts` — and this Host
 * implements a deliberate subset of it (file-browser, the agent information
 * flow, approvals, todo, goal).
 *
 * Everything outside that subset answers `CHANNEL_NOT_ALLOWED`, which is exactly
 * what a Cindy controlled device answers for a channel it does not serve. That
 * is a permanent refusal, not proof of a working fallback. Only optional
 * features with a verified caller fallback may use that boundary; the latest
 * default input/durable-outbox path must be implemented end to end.
 */
import { agentKindForModel, toCindyActiveSessions, toCindySessionList, toCindySessionListRow } from './cindy-session-row.js';
import { flattenGenuiRows } from './genui-fence.js';
import { toAgentCapabilities, toCindyPermissionMode, toDshPermissionMode, toNewMakerDefaults, toPermissionOptions, toProviderList } from './host-models.js';
import { queueItemsFromInbox } from './host-input-queue.js';
import { toAgentSkills, toAgentCommands, toAtResources } from './host-palette.js';
import { toGoalStatusPayload } from './host-goals.js';
import { hostAttachmentsOf } from './host-attachments.js';
import { historyLocateOptions, locateCommittedMessages, capReferenceRows } from './host-history-locate.js';
import { assertNoStructuredSessionReferences } from './session-reference-boundary.js';
import { continuationKind } from './continuation-protocol.js';

async function deliveryReply(request, operation) {
  try { return invokeResult(request, await operation()); }
  catch (error) { return invokeError(request, typeof error?.code === 'string' ? error.code : 'DELIVERY_FAILURE', String(error?.message ?? error)); }
}

/** The phone's own unsubscribe channel, paired with subscribe. */
const SUBSCRIBE = 'device-link:subscribe';
const UNSUBSCRIBE = 'device-link:unsubscribe';

/** Topic carrying list-level changes; one of only two this Host serves. */
export const TOPIC_SESSIONS = 'sessions';
/** Topic carrying one session's live stream. */
export const TOPIC_SESSION_PREFIX = 'session:';

/**
 * The controller's goal write commands.
 *
 * The status read is deliberately not here: it is answered from the projection
 * stream and must never resume a session.
 */
export const GOAL_WRITE_CHANNELS = new Set([
  'maker:goal:set',
  'maker:goal:update',
  'maker:goal:pause',
  'maker:goal:resume',
  'maker:goal:clear',
]);

/**
 * The controller's pending-queue commands.
 *
 * These are what the queue panel's buttons send — 插话 (promote), 取消 (remove),
 * 编辑 (update), 停止 (stop). Without them the controller shows
 * `CHANNEL_NOT_ALLOWED` and the user cannot clear a stuck queue, which blocks
 * sending anything at all.
 */
export const QUEUE_COMMAND_CHANNELS = new Set([
  'maker:input:update-text',
  'maker:input:update-content',
  'maker:input:remove',
  'maker:input:stop',
  'maker:input:clear-session',
  'maker:input:set-expanded',
  'maker:input:set-edit-lock',
  'maker:input:set-interaction-lock',
  'maker:input:resume',
]);

/** The controller's current `InputProjection` for one session. */
function projectionNow(capabilities, sessionId) {
  const project = capabilities.inputProjection;
  return typeof project === 'function'
    ? project(sessionId, null)
    : { sessionId, pendingQueue: [], steeringQueueClientIds: [] };
}

/**
 * Answer a queue command, and tell the session's other watchers.
 *
 * The reply settles the controller that asked. A second screen watching the same
 * session has no reason to ask again, so without this push it keeps rendering a
 * row the user just deleted — the same shape of staleness the queue fold already
 * caused once.
 * @param request - the invoke being answered.
 * @param capabilities - the per-request capabilities.
 * @param sessionId - the session whose queue changed.
 * @returns the reply frame.
 */
function answerQueueCommand(request, capabilities, sessionId) {
  const push = capabilities?.pushInputProjection;
  if (typeof push === 'function') push(sessionId);
  return invokeResult(request, projectionNow(capabilities, sessionId));
}

/**
 * Commit one queue mutation to DSH.
 *
 * `control.update` is **async** — it resolves the session's agent before asking DSH to change
 * the inbox — so it reports a refusal by *rejecting*, not by throwing. A `try`/`catch` around
 * a call that is not awaited therefore catches nothing and the rejection floats: measured, it
 * reached DSH's fail-loud unhandled-rejection handler and ended the whole `dsh web` process
 * (`fatal load failure: RemoteError: queued item is no longer pending`, thrown from
 * `SessionCommandController.updateQueue`) while an acceptance probe edited a queue whose item
 * DSH had already admitted. The same bug also reported every refused mutation as a success,
 * because `null` (the "no failure" answer) was returned unconditionally.
 *
 * @returns null on success, or `{ code, message }` to report.
 */
async function commitQueueAction(control, sessionId, itemId, action) {
  try {
    await control.update({ sessionId, itemId, action });
    return null;
  } catch (error) {
    // DSH's own code travels: `session/steer-unavailable` and
    // `session/queue-item-not-found` describe the refusal precisely, and a
    // generic THREW would hide the difference between "there is no such item"
    // and "there is no turn to steer into".
    const code = typeof error?.code === 'string' && error.code !== '' ? error.code : 'THREW';
    return { code, message: String(error?.message ?? error) };
  }
}

/**
 * Commit one queue mutation and keep the controller's view honest either way.
 *
 * On **failure** the projection is still pushed. The controller promotes the row
 * optimistically before asking, so a refusal it only learns about from the error
 * leaves it showing a queued item as if it had been taken — and, for a steer,
 * spinning on a turn that never started. The push is what tells it otherwise.
 * @returns null on success, or `{ code, message }` to report.
 */
async function commitQueueActionAndReconcile(capabilities, sessionId, itemId, action) {
  const failure = await commitQueueAction(capabilities.queueControl, sessionId, itemId, action);
  if (failure !== null) {
    const push = capabilities?.pushInputProjection;
    if (typeof push === 'function') push(sessionId);
  }
  return failure;
}

/** How long to wait for DSH's `MessageId` before answering NOT_FOUND. */
const QUEUE_ITEM_ID_WAIT_MS = 1500;
const QUEUE_ITEM_ID_POLL_MS = 50;

/**
 * The durable id behind the controller's item id, waiting briefly if needed.
 *
 * `maker:input:enqueue` is answered from a row this Host synthesises, because
 * DSH's own `queue` frame trails the commit. For that moment the item is
 * addressable by the controller — it can see the row and press 取消 on it — but
 * its durable `MessageId` is not yet known, and `updateQueue` is keyed on that id.
 * Answering NOT_FOUND straight away made 取消 and 编辑 fail on a message the user
 * had just sent, which reads as "the button is broken" rather than "try again in
 * a moment". The frame is only milliseconds behind, so this waits for it.
 *
 * The wait is bounded and every iteration re-reads the fold, so a genuinely
 * absent item still fails fast enough to keep the button responsive.
 *
 * @param capabilities - the per-request capabilities.
 * @param sessionId - the session owning the item.
 * @param controllerId - the `clientId` the controller addressed it by.
 * @param waitMs - the bound, injectable so tests do not sleep.
 * @returns the DSH `MessageId`, or null if it never appeared.
 */
export async function resolveDshItemId(capabilities, sessionId, controllerId, waitMs = QUEUE_ITEM_ID_WAIT_MS) {
  const mirror = capabilities?.queueMirror;
  const deadline = Date.now() + Math.max(0, waitMs);
  for (;;) {
    const folded = typeof mirror?.dshItemId === 'function' ? mirror.dshItemId(sessionId, controllerId) : null;
    if (folded !== null && folded !== undefined) return folded;
    // The fold learns items only from pushed `queue` frames, and those are not
    // guaranteed to arrive — so a fold-only answer reported NOT_FOUND for an item
    // the Host itself had just accepted. The session's inbox is the authority.
    const read = capabilities?.readSessionState;
    if (typeof read === 'function') {
      let state = null;
      try {
        state = await read(sessionId);
      } catch {
        state = null;
      }
      if (state !== null && state !== undefined) {
        const wanted = String(controllerId);
        const found = queueItemsFromInbox(state.inbox)
          .find((entry) => entry.rpcId === wanted || entry.id === wanted);
        if (found !== undefined) return found.id;
      }
    }
    if (Date.now() >= deadline) return null;
    await new Promise((resolve) => { setTimeout(resolve, QUEUE_ITEM_ID_POLL_MS); });
  }
}

/**
 * Split the topics a controller asked for into the ones this Host serves.
 *
 * `session:<id>` used to be dropped here, which silently denied every live
 * per-session push: the subscription succeeded, the reply looked right, and no
 * stream ever arrived.
 * @param value - the raw `topics` argument.
 * @returns the accepted topics.
 */
export function acceptTopics(value) {
  if (!Array.isArray(value)) return [];
  return value.filter((topic) => typeof topic === 'string'
    && (topic === TOPIC_SESSIONS || (topic.startsWith(TOPIC_SESSION_PREFIX) && topic.length > TOPIC_SESSION_PREFIX.length)));
}

/** Channels this round implements; everything else is refused by omission. */
export const SUPPORTED_CHANNELS = Object.freeze([
  SUBSCRIBE,
  UNSUBSCRIBE,
  'local-db:sessions:list',
  'local-db:sessions:get',
  'local-db:messages:list',
  'local-db:messages:dismiss-error',
  'local-db:sessions:ack-interrupted',
  'local-db:messages:around',
  'local-db:messages:around-client-id',
  'local-db:sessions:patch-meta',
  'maker:create-session',
  'maker:send',
  'maker:input:enqueue',
  'maker:input:steer',
  'maker:list-active',
  'maker:session-in-turn',
  'maker:git-safety:get',
  'maker:goal:get-status',
  ...GOAL_WRITE_CHANNELS,
  ...QUEUE_COMMAND_CHANNELS,
  'maker:input:move',
  'maker:set-model',
  'maker:compact-session',
  'maker:fork',
  'local-db:conversations:search',
  'maker:session-background-tasks:list',
  'local-db:subagent-runs:list',
  'local-db:subagent-runs:detail',
  'local-db:subagent-runs:transcript',
  'maker:schedule:list',
  'maker:schedule:get',
  'maker:schedule:create',
  'maker:schedule:update',
  'maker:schedule:delete',
  'sidebar-settings:get-project-order',
  'sidebar-settings:apply-project-order',
  // Project display names for the controller's sidebar. Reads the native Workspace
  // titles; without it the phone falls back to the folder basename (English/UUID).
  'sidebar-settings:get-project-aliases',
  'local-db:project-aliases:list',
  'local-db:history:messages',
  'maker:input:session-reference-capability',
  'maker:set-effort',
  'fs:list-dir',
  'fs:stat-path',
  'text-file:read-preview',
  'maker:get-pending-interactions',
  'maker:regenerate-title',
  'maker:get-context-usage',
  'maker:resolve-interaction',
  'maker:input:get-projection',
  'maker:list-available-agents',
  'maker:provider:list',
  'maker:get-capabilities',
  'maker:get-new-maker-defaults',
  'maker:list-agent-skills',
  'maker:list-agent-commands',
  'maker:set-plan-mode',
  'file-browser:remote-op',
  'device-link:media:fetch',
  'device-link:file-peer',
  // The work-grouped history window. Gated on the controller's side by the
  // `history-view-v1` capability this Host advertises in `link-accept`
  // (`host-authorization.js`), so serving them is only half of turning them on.
  'local-db:messages:view',
  'local-db:messages:work-details',
  'local-db:messages:view-intent',
  'maker:set-permission-mode',
  'maker:list-desktop-commands',
  'maker:scan-at-resources',
]);

/** Three Cindy wire aliases for the same DSH harness and capabilities. */
export const DSH_AGENT_KINDS = Object.freeze(['claude-code', 'codex', 'pi']);

/** Legacy native protocol alias; display fallback for unknown routes is Claude. */
export const DSH_AGENT_KIND = 'pi';

/**
 * What this Host can do for `pi`.
 *
 * The phone asks for capabilities once per agent kind whenever it opens a
 * device, and a refused answer leaves it without the shape it validates
 * against. The lists are empty because this Host exposes no model catalog yet —
 * that is a missing feature, not a broken one, and it must not cost the session
 * list.
 */
export const DSH_AGENT_CAPABILITIES = Object.freeze({
  availableModels: [],
  effortLevels: [],
  permissionModes: [],
  hasFastMode: false,
  planModeSupported: false,
  supportsSessionAgentSwitch: false,
  supportsModelWindowSwitchGuard: false,
});

/** A relay result frame. `dst` is the requesting device, as the relay filled it. */
export function invokeResult(request, result) {
  return { v: 1, kind: 'invoke-result', id: request.id, dst: request.src, payload: { ok: true, result } };
}

/** A refusal the controller knows how to read. */
export function invokeError(request, code = 'CHANNEL_NOT_ALLOWED', message = 'Channel is not available on DSH Host') {
  return { v: 1, kind: 'invoke-result', id: request.id, dst: request.src, payload: { ok: false, error: { code, message } } };
}

/**
 * The refusal codes a seam may name for an ordinary refusal.
 *
 * A seam knows *why* something it was asked for cannot be done — a model that offers
 * no such effort, a path outside the workspace — and the controller reads those codes
 * to choose its fallback. Without this, every one of them arrived as `THREW`, which
 * the controller (rightly) treats as the Host crashing: the acceptance run reported
 * `maker:set-effort restores effort — THREW: provider "openai-codex" model
 * "gpt-5.6-sol" does not support reasoning effort "default"` for a request the Host
 * had *correctly* declined.
 */
export const REFUSAL_CODES = new Set(['BAD_REQUEST', 'NOT_AVAILABLE', 'NOT_FOUND', 'FORBIDDEN', 'OVERSIZE', 'CHANNEL_NOT_ALLOWED', 'PAYLOAD_TOO_LARGE', 'INTERNAL']);

/**
 * An error that carries the refusal the controller should read.
 * @param code - one of {@link REFUSAL_CODES}.
 * @param message - what the controller shows or logs.
 * @returns the error to throw from a seam.
 */
export function refusalError(code, message) {
  const error = new Error(message);
  error.refusalCode = REFUSAL_CODES.has(code) ? code : 'INTERNAL';
  return error;
}

/**
 * The code to answer an error with: the refusal it names, or `THREW` for a genuine
 * failure, which is the difference the controller's error handling keys on.
 * @param error - whatever a seam threw.
 * @returns a refusal code.
 */
export function refusalCodeOf(error) {
  return typeof error?.refusalCode === 'string' ? error.refusalCode : 'THREW';
}

/**
 * Pull the prompt text out of a send argument.
 *
 * The two send paths carry different shapes:
 *  - `maker:send` sends a bare string or `{ type: 'user', content }`, where
 *    `content` is the controller's persisted message — an object carrying
 *    `text`, or a plain string on older paths;
 *  - `maker:input:enqueue` / `:steer` send the controller's own
 *    `QueuedRemoteMessage`, whose `text` is top level.
 *
 * Anything else yields nothing, and the caller refuses rather than sending an
 * empty prompt.
 * @param message - the raw argument.
 * @returns the text to send, or null when there is none.
 */
export function extractSendText(message) {
  if (typeof message === 'string') return message.trim() === '' ? null : message;
  if (message === null || typeof message !== 'object') return null;
  // The queued-message shape, which is the composer's normal path.
  if (typeof message.text === 'string') return message.text.trim() === '' ? null : message.text;
  const content = message.content;
  if (typeof content === 'string') return content.trim() === '' ? null : content;
  if (content !== null && typeof content === 'object' && typeof content.text === 'string') {
    return content.text.trim() === '' ? null : content.text;
  }
  return null;
}

/**
 * The attachments this Host can actually serve, out of the ones the controller sent.
 *
 * Both forms are serveable: an absolute path on this machine, and an upload transit
 * reference (`cindy-oss-attach://…`, or the legacy `xdt-oss-attach://…` the phones
 * build) whose bytes this Host fetches with its own account credential. A reference is
 * fetched, never handed to a filesystem as if it were a path; anything else with a
 * scheme is left behind, and the send paths log what they carried.
 * @param message - the controller's send argument.
 * @returns the serveable attachments.
 */
export function extractSendAttachments(message) {
  return hostAttachmentsOf(message);
}


/**
 * Build the router.
 * @param options - the DSH read capabilities, the per-connection subscriber set,
 *   and a reader for this Host's own relay identity.
 * @returns a function turning one invoke request into one result frame.
 */
export function createChannelRouter({
  listSessions,
  getSession,
  listSessionStates,
  readMessages,
  createSession,
  sendMessage,
  resolveCapabilities,
  subscribers,
  onSubscribe,
  onUnsubscribe,
  now = () => new Date(),
  getDevice,
  getControllerPlatform,
}) {
  /**
   * Turn states for the two polled channels, without paying for a row fold.
   *
   * A router built without the cheap read (tests, and any caller that only has the full
   * listing) falls back to it rather than failing: the difference is cost, not answer.
   */
  const listStates = typeof listSessionStates === 'function' ? listSessionStates : listSessions;
  /** The requesting controller's platform, or null when unknown. */
  const platformFor = (request) => {
    if (typeof getControllerPlatform !== 'function') return null;
    try { return getControllerPlatform(request?.src) ?? null; } catch { return null; }
  };
  /** Flatten dsh-ui cards only for clients with no GenUI renderer. */
  const forClient = (value, request) => flattenGenuiRows(value, platformFor(request));
  /**
   * Resolve the Host's write/read capabilities *per request*.
   *
   * They arrive from another plugin and can land after this router is built, so
   * capturing them at construction would freeze an empty set — which shows up as
   * `NOT_AVAILABLE` on a Host that is in fact perfectly able to serve the call.
   */
  const capabilitiesNow = typeof resolveCapabilities === 'function'
    ? resolveCapabilities
    : () => ({ readMessages, createSession, sendMessage });

  /**
   * The model every session falls back to, as of the last capability read.
   *
   * The controller asks for capabilities when it opens a device and again when a
   * provider revision changes, so this is warm by the time it lists sessions —
   * without the list call itself paying for a catalog read.
   */
  let catalogDefaultModel = null;
  let agentCatalog = null;

  /** This Host's relay identity, as the phone's device filter needs it. */
  function deviceIdentity() {
    if (typeof getDevice !== 'function') return undefined;
    try {
      return getDevice();
    } catch {
      return undefined;
    }
  }

  /**
   * Read the session rows the phone renders.
   *
   * `local-db:sessions:list` is also the phone's device-responsiveness probe, so
   * it has to stay a single cheap read — which is why the row is folded from the
   * source's one listing rather than from a per-session fetch.
   *
   * **And it may not block on that read at all.** Measured on a live Host (2026-09-18,
   * 19:08–19:15): eighteen `invoke:local-db:sessions:list` calls aborted with
   * `TimeoutError` in seven minutes while a build saturated the machine — the abort is at
   * the **invoke** level (list read + title folding + row building together overran the
   * deadline), so the source's own stale-serve guard never saw it, and the phone read a
   * failed list as "the device is offline". The list a controller renders is satisfied by a
   * few seconds' staleness, so the rows are cached and the read happens behind the answer:
   * a warm cache answers instantly, and a refresh that fails leaves the previous page
   * standing rather than turning a slow machine into a disconnected phone.
   */
  let rowsCache = null;
  let rowsRefresh = null;
  let rowsGeneration = 0;
  /** How long a served page stays fresh enough to answer with before a refresh is kicked. */
  const SESSION_ROWS_TTL_MS = 5_000;

  /**
   * Void the cached page because this Host just changed a row.
   *
   * Called from every write path that changes what a list read must say — the reply a
   * controller applies is folded from the same rows, so a stale page there is not a small
   * lag but an instruction to revert the user's edit.
   */
  function invalidateSessionRows() {
    rowsGeneration += 1;
    rowsCache = null;
    rowsRefresh = null; // A pre-write read cannot fulfill a post-write request.
  }

  /** Read + fold once, sharing one flight between concurrent callers. */
  function refreshSessionRows() {
    if (rowsRefresh !== null) return rowsRefresh;
    const generation = rowsGeneration;
    const attempt = (async () => {
      const items = await listSessions();
      const rows = toCindySessionList(items, { now, device: deviceIdentity(), defaultModel: catalogDefaultModel, catalog: agentCatalog });
      if (generation === rowsGeneration) rowsCache = { rows, at: now() };
      return rows;
    })();
    rowsRefresh = attempt;
    const settle = () => { if (rowsRefresh === attempt) rowsRefresh = null; };
    attempt.then(settle, settle);
    return attempt;
  }

  async function sessionRows() {
    const cached = rowsCache;
    if (cached !== null) {
      if (now() - cached.at > SESSION_ROWS_TTL_MS) {
        // Stale-while-revalidate: the controller gets a real page now and a fresher one on
        // its next poll. A failed refresh is deliberately silent — the page above is durable.
        refreshSessionRows().catch(() => {});
      }
      return cached.rows;
    }
    // Cold start: the only case where the probe must wait for a read.
    return refreshSessionRows();
  }

  /** Mirror Cindy's native sessions:list paging contract over the cached full projection. */
  function sessionListPage(rows, args) {
    const rawLimit = typeof args[0] === 'number' ? args[0] : Number(args[0]);
    const limit = Number.isFinite(rawLimit) && rawLimit > 0
      ? Math.min(Math.max(Math.floor(rawLimit), 1), 1_000)
      : 20;
    const requestedStatus = args[1];
    const matching = rows.filter((row) => requestedStatus === 'active' || requestedStatus === 'archived'
      ? row.status === requestedStatus
      : row.status !== 'deleted');
    const recent = matching.slice(0, limit);
    const options = args[2] !== null && typeof args[2] === 'object' ? args[2] : {};
    if (options.includePinned !== true) return recent;
    const seen = new Set(recent.map((row) => row.id));
    return [...recent, ...matching.filter((row) => row.pinnedAt != null && !seen.has(row.id))];
  }

  async function sessionRow(sessionId) {
    if (typeof getSession === 'function') {
      const item = await getSession(sessionId);
      if (item == null || String(item.id) !== sessionId) return undefined;
      return toCindySessionListRow(item, { now, device: deviceIdentity(), defaultModel: catalogDefaultModel, catalog: agentCatalog });
    }
    let row = (await sessionRows()).find((candidate) => candidate.id === sessionId);
    if (row === undefined) {
      invalidateSessionRows();
      row = (await sessionRows()).find((candidate) => candidate.id === sessionId);
    }
    return row;
  }

  const handleInvoke = async function handleInvoke(request) {
    // A reply is addressed by `id` + `src`; without both there is nothing the
    // relay could route, so this answers nothing rather than fabricating a frame.
    if (request === null || typeof request !== 'object') return null;
    if (typeof request.id !== 'string' || typeof request.src !== 'string') return null;

    const channel = request?.payload?.channel;
    const args = Array.isArray(request?.payload?.args) ? request.payload.args : [];
    if (['maker:create-session', 'maker:send', 'maker:input:enqueue', 'maker:input:steer', 'maker:input:update-text', 'maker:input:update-content'].includes(channel)) {
      try { assertNoStructuredSessionReferences(args); }
      catch (error) { return invokeError(request, 'NOT_AVAILABLE', error.message); }
    }
    if (channel === 'maker:input:session-reference-capability') {
      if (args.length) return invokeError(request, 'BAD_REQUEST', 'Reference capability probe accepts no arguments');
      return invokeResult(request, { supported: false, version: 1 });
    }
    if (channel === 'local-db:history:messages') {
      if (args.length !== 1) return invokeError(request, 'BAD_REQUEST', 'Source history needs one request object');
      const capabilities = capabilitiesNow(); const port = capabilities.referenceHistory;
      if (typeof port?.read !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'Native reference source history is not composed');
      if (capabilities.sessionHidden?.(args[0]?.sessionId) === true) return invokeError(request, 'NOT_FOUND', 'Source session is hidden');
      try { return invokeResult(request, forClient(await port.read(args[0], { getView: id => sessionRow(id) }), request)); }
      catch (error) { return invokeError(request, refusalCodeOf(error), String(error?.message ?? error)); }
    }

    if (channel === SUBSCRIBE) {
      const topics = acceptTopics(args?.[0]?.topics);
      // A controller that subscribes is a controller that wants pushes; the
      // subscription set is per-connection and cleared with the socket.
      if (request.src && typeof onSubscribe === 'function') onSubscribe(request.src, topics);
      else if (request.src) subscribers.add(request.src);
      // A controller that has just attached knows nothing about the turn state,
      // and its spinner clears only on an explicit terminal event — a session
      // merely absent from `maker:list-active` is deliberately not read as idle.
      // So the state is announced rather than left to be inferred from silence:
      // without this, a refused steer or a failed prompt left the phone spinning
      // with nothing on the Host to correct it.
      //
      // The answer is read from the **source**, not from the runtime's row cache:
      // that cache is refreshed by list reads, so a controller attaching
      // mid-session can be looking at a `running: true` captured before the turn
      // that ended it. Announce only what the source says now, and fall back to
      // the cache only when the source cannot be read at all.
      const subscribing = capabilitiesNow();
      const sessionIds = topics.filter((topic) => topic.startsWith(TOPIC_SESSION_PREFIX))
        .map((topic) => topic.slice(TOPIC_SESSION_PREFIX.length));
      // The creation pipeline awaits the sessions-topic subscription BEFORE
      // sending create. Reading the corpus for that acknowledgement made cold
      // listing timeouts look like failed creates that never reached this Host.
      if (sessionIds.length > 0 && typeof subscribing.isSessionRunning === 'function'
        && typeof subscribing.pushTurnIdle === 'function'
        && typeof subscribing.pushTurnRunning === 'function') {
        let live = null;
        if (typeof getSession !== 'function') {
          try {
            const rows = await listStates();
            live = Array.isArray(rows) ? rows : null;
          } catch {
            // Legacy sources without exact reads keep the runtime fallback.
          }
        }
        for (const sessionId of sessionIds) {
          if (typeof subscribing.restoreTurnState === 'function') {
            await subscribing.restoreTurnState(request.src, sessionId);
          } else {
            let row = live === null ? null : live.find((candidate) => String(candidate?.id) === sessionId) ?? null;
            if (typeof getSession === 'function') {
              try { row = await getSession(sessionId) ?? null; } catch { row = null; }
            }
            const running = row === null ? subscribing.isSessionRunning(sessionId) === true : row.running === true;
            if (running) subscribing.pushTurnRunning(sessionId);
            else subscribing.pushTurnIdle(sessionId);
          }
          // …and the two things a push that never arrived would have carried.
          //
          // Measured: an app returning from the background does an unsubscribe → resubscribe
          // flicker (26 subscribes / 13 unsubscribes in one session), a send landed inside it, and
          // the frames carrying "accepted" and "the view changed" were discarded by the relay with
          // nobody to retry them — the bubble spun forever and the transcript stayed stale until
          // the app was restarted. A subscription is the one moment the client is guaranteed to be
          // listening, so it is where the Host repairs what it could not deliver: the authoritative
          // input projection (which retires a spinning bubble) and a view invalidation (which makes
          // it re-read). Both are idempotent and cost one frame each.
          if (typeof subscribing.pushInputProjection === 'function') subscribing.pushInputProjection(sessionId);
          if (typeof subscribing.invalidateHistoryView === 'function') subscribing.invalidateHistoryView(sessionId);
        }
      }
      return invokeResult(request, { subscribed: topics });
    }

    if (channel === UNSUBSCRIBE) {
      const topics = acceptTopics(args?.[0]?.topics);
      if (request.src && typeof onUnsubscribe === 'function') onUnsubscribe(request.src, topics);
      else if (request.src) subscribers.delete(request.src);
      return invokeResult(request, { unsubscribed: topics });
    }

    if (channel === 'local-db:sessions:list') {
      return invokeResult(request, sessionListPage(await sessionRows(), args));
    }

    if (channel === 'local-db:sessions:ack-interrupted' || channel === 'local-db:messages:dismiss-error') {
      const sid = args[0]; const cid = args[1]; const caps = capabilitiesNow();
      if (typeof sid !== 'string' || !sid || args.length !== (channel === 'local-db:sessions:ack-interrupted' ? 1 : 2) || (channel === 'local-db:messages:dismiss-error' && (typeof cid !== 'string' || !cid))) return invokeError(request, 'INVALID_PARAMS', 'Session and message identities are required');
      const action = channel === 'local-db:sessions:ack-interrupted' ? caps.ackInterrupted : caps.dismissError;
      if (typeof action !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'Diagnostic presentation actions are unavailable');
      return deliveryReply(request, () => channel === 'local-db:sessions:ack-interrupted' ? action(sid, request.src) : action(sid, cid, request.src));
    }

    if (channel === 'local-db:sessions:get') {
      const sessionId = String(args[0] ?? '');
      // A known blank session must be readable before its first enqueue. The
      // discovery list intentionally hides drafts and cannot prove absence.
      const row = await sessionRow(sessionId);
      // Cindy answers an unknown id with an error the controller already handles.
      if (row === undefined) return invokeError(request, 'NOT_FOUND', `No DSH session ${sessionId}`);
      // The row's message total is what lets the controller light its "load
      // earlier" entry point at all: `hasOlderMessagesByServerCount` answers
      // false for an unknown total, deliberately, so that an entry point which
      // leads nowhere is never shown. Answered only here, not in the list: the
      // controller polls the list, and folding every transcript per poll would
      // trade a paging bug for a latency one.
      const count = capabilitiesNow().countMessages;
      if (typeof count === 'function') {
        try {
          const total = await count(sessionId);
          if (Number.isFinite(total)) row._count = { messages: total };
        } catch {
          // An unreadable transcript leaves `_count` as the honest null it was.
        }
      }
      return invokeResult(request, row);
    }

    if (channel === 'local-db:messages:around' || channel === 'local-db:messages:around-client-id') {
      const capabilities = capabilitiesNow();
      if (typeof args[0] !== 'string' || !args[0] || typeof args[1] !== 'string' || !args[1]) return invokeError(request, 'INVALID_PARAMS', 'sessionId and message identity must be nonempty strings');
      const sessionId = args[0];
      if (capabilities.sessionHidden?.(sessionId) === true) return invokeError(request, 'NOT_FOUND', 'Session does not exist');
      if (typeof capabilities.readAllMessages !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This Host cannot read committed message history');
      try {
        const byClientId = channel === 'local-db:messages:around-client-id';
        const options = historyLocateOptions(byClientId ? args[2] : {radius: args[2]?.radius});
        const rows = locateCommittedMessages(await capabilities.readAllMessages(sessionId), {sessionId, identity: args[1], byClientId, radius: options.radius});
        const hydrated = typeof capabilities.hydrateImages === 'function' ? await capabilities.hydrateImages(rows) : rows;
        return invokeResult(request, capReferenceRows(hydrated, options.contentCharLimit));
      } catch (error) {
        if (error?.code === 'NOT_FOUND' || error?.code === 'INVALID_PARAMS' || error?.code === 'NOT_AVAILABLE') return invokeError(request, error.code, error.message);
        throw error;
      }
    }

    if (channel === 'local-db:messages:list') {
      const sessionId = String(args[0] ?? '');
      const read = capabilitiesNow().readMessages;
      if (typeof read !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot read message history yet');
      const options = args[1] !== null && typeof args[1] === 'object' ? args[1] : {};
      const rows = forClient(await read(sessionId, options), request);
      // A user row in history is delivery evidence to Cindy, even if it carries
      // an unknown pendingDelivery field. Keep unconsumed prompts exclusively in
      // InputProjection, or a list read falsely settles the phone's queue.
      return invokeResult(request, rows);
    }

    if (channel === 'maker:list-active') {
      // Its own shape: `[{ sessionId, isTurnRunning }]`. Answering with session
      // rows makes the controller skip every entry, which surfaces only as a
      // running badge that never lights up.
      //
      // An archived or deleted session is left out: the controller does not show its
      // row, so an entry for it would light the device's running badge from a session
      // the user cannot open.
      //
      // The **cheap** read on purpose. This is the most frequently polled channel on
      // this Host and it needs one boolean per session, so it must not pay for titles:
      // measured 8.4s through the full row fold on a 219-session profile, against a
      // handset that gives up at 15s.
      const rows = await listStates();
      const hidden = capabilitiesNow().sessionHidden;
      const visible = typeof hidden === 'function' ? rows.filter((row) => hidden(row.id) !== true) : rows;
      return invokeResult(request, toCindyActiveSessions(visible));
    }

    if (channel === 'maker:session-in-turn') {
      // The controller's **stall watchdog** — "controlling side uses this when a
      // Generating state seems stuck and no push has arrived: verify the host is
      // really still running; only `false` is safe to finish on, never kill a slow
      // turn that is genuinely working" (`isSessionTurnRunningFor` in the desktop
      // renderer). It answers a bare boolean.
      //
      // Read from the **source**, not from the runtime's cached row: a missed push is
      // exactly the condition being probed, and the cache is fed by those same
      // pushes. This is the read the subscribe path already trusts, and the cache is
      // only the fallback for when the source cannot be read at all.
      const sessionId = String(args[0] ?? '');
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', 'maker:session-in-turn needs a session id');
      let running = null;
      try {
        const rows = await listStates(sessionId);
        const row = Array.isArray(rows) ? rows.find((candidate) => String(candidate?.id) === sessionId) ?? null : null;
        running = row === null ? null : row.running === true;
      } catch {
        running = null;
      }
      if (running === null) running = capabilitiesNow().isSessionRunning?.(sessionId) === true;
      return invokeResult(request, running === true);
    }

    // Three controller aliases share one actual DSH harness. The selected kind
    // is presentation-only; model routing always follows the DSH selection.
    if (channel === 'maker:list-available-agents') {
      return invokeResult(request, [...DSH_AGENT_KINDS]);
    }

    if (channel === 'maker:get-new-maker-defaults') {
      const requested = typeof args[0] === 'string' ? args[0] : null;
      if (requested !== null && !DSH_AGENT_KINDS.includes(requested)) {
        return invokeError(request, 'NOT_AVAILABLE', `DSH Host does not offer the ${requested} alias`);
      }
      const readCatalog = capabilitiesNow().modelCatalog;
      if (typeof readCatalog !== 'function') return invokeResult(request, {});
      try {
        return invokeResult(request, toNewMakerDefaults(await readCatalog()));
      } catch {
        // Native Cindy also answers an empty object while its defaults cache is unavailable.
        return invokeResult(request, {});
      }
    }

    if (channel === 'maker:provider:list') {
      const readCatalog = capabilitiesNow().modelCatalog;
      if (typeof readCatalog !== 'function') return invokeResult(request, { providers: [], providerOrder: [] });
      try {
        const catalog = await readCatalog();
        agentCatalog = catalog;
        const defaultModel = catalog?.default?.model;
        catalogDefaultModel = typeof defaultModel === 'string' && defaultModel !== '' ? defaultModel : null;
        invalidateSessionRows();
        return invokeResult(request, toProviderList(catalog, DSH_AGENT_KINDS));
      } catch {
        return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host could not read its model catalog');
      }
    }

    if (channel === 'maker:get-capabilities') {
      const requested = typeof args[0] === 'string' ? args[0] : null;
      if (requested !== null && !DSH_AGENT_KINDS.includes(requested)) {
        return invokeError(request, 'NOT_AVAILABLE', `DSH Host does not offer the ${requested} alias`);
      }
      // The catalog is a live read, not a constant: it is what the picker lists,
      // and answering from a frozen copy would keep offering models that this
      // Host can no longer route to.
      const composed = capabilitiesNow();
      // DSH, not the controller's legacy Pi/90%-window heuristic, owns whether
      // a model may be selected. Advertise only when that native path is composed.
      const nativeModelSelection = typeof composed.selectModel === 'function';
      const fallback = { ...DSH_AGENT_CAPABILITIES, supportsModelWindowSwitchGuard: nativeModelSelection };
      const readCatalog = composed.modelCatalog;
      if (typeof readCatalog !== 'function') return invokeResult(request, fallback);
      let catalog;
      try {
        catalog = await readCatalog();
      } catch (error) {
        // A failed catalog read costs the picker, never the session list.
        agentCatalog = null;
        catalogDefaultModel = null;
        invalidateSessionRows();
        return invokeResult(request, fallback);
      }
      agentCatalog = catalog;
      const defaultModel = catalog?.default?.model;
      catalogDefaultModel = typeof defaultModel === 'string' && defaultModel !== '' ? defaultModel : null;
      invalidateSessionRows();
      const capabilities = toAgentCapabilities(catalog, { nativeModelSelection });
      // These two fields are what make the controls appear at all: the controller
      // draws the permission picker only when presets are advertised, and the
      // plan-mode switch only when support is — and DSH documents a missing
      // `permissions` projection as "clients hide the control".
      const controls = capabilitiesNow().sessionControls;
      if (typeof controls?.permissionNames === 'function') {
        try {
          capabilities.permissionModes = toPermissionOptions(controls.permissionNames());
        } catch {
          capabilities.permissionModes = [];
        }
      }
      if (typeof controls?.planModeSupported === 'function') {
        try {
          const supported = await controls.planModeSupported();
          capabilities.planMode = { supported: supported === true };
        } catch {
          capabilities.planMode = { supported: false };
        }
      }
      return invokeResult(request, capabilities);
    }

    if (channel === 'maker:set-plan-mode') {
      const controls = capabilitiesNow().sessionControls;
      if (typeof controls?.setPlanMode !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host composes no plan mode');
      const sessionId = String(args[0] ?? '');
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', 'maker:set-plan-mode needs a session id');
      try {
        const outcome = await controls.setPlanMode({ sessionId, enabled: args[1] === true });
        // `queued` means the switch lands at the next step rather than now. The
        // controller treats a resolved call as applied, so the outcome travels
        // as the answer instead of being flattened into a bare success. A seam
        // that can only report "the switch was accepted" says exactly that.
        if (outcome !== null && typeof outcome === 'object') {
          return invokeResult(request, {
            outcome: typeof outcome.outcome === 'string' ? outcome.outcome : 'accepted',
            ...(typeof outcome.message === 'string' ? { message: outcome.message } : {}),
          });
        }
        return invokeResult(request, { outcome: typeof outcome === 'string' ? outcome : 'committed' });
      } catch (error) {
        return invokeError(request, refusalCodeOf(error), String(error?.message ?? error));
      }
    }

    if (channel === 'maker:set-permission-mode') {
      const controls = capabilitiesNow().sessionControls;
      if (typeof controls?.setPermissionMode !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host composes no permission presets');
      const sessionId = String(args[0] ?? '');
      const mode = typeof args[1] === 'string' ? toDshPermissionMode(args[1]) : null;
      if (sessionId === '' || mode === null) return invokeError(request, 'BAD_REQUEST', 'maker:set-permission-mode needs a supported Cindy mode');
      try {
        await controls.setPermissionMode({ sessionId, mode });
        // The preset writes the session's knobs, so the row the controller holds
        // is now stale; a fresh read is pushed for the same reason a queue
        // command pushes one.
        const push = capabilitiesNow().pushInputProjection;
        if (typeof push === 'function') push(sessionId);
        return invokeResult(request, true);
      } catch (error) {
        return invokeError(request, refusalCodeOf(error), String(error?.message ?? error));
      }
    }

    if (channel === 'maker:set-model') {
      const select = capabilitiesNow().selectModel;
      if (typeof select !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot change the model');
      const sessionId = String(args[0] ?? '');
      const model = typeof args[1] === 'string' ? args[1] : '';
      if (sessionId === '' || model === '') return invokeError(request, 'BAD_REQUEST', 'maker:set-model needs a session and a model');
      // The controller sends `[sessionId, model, providerId?]`, and a richer
      // `[…, providerId, null, selection]` form when it has a full selection.
      const selection = args[4] !== null && typeof args[4] === 'object' ? args[4] : null;
      const provider = typeof args[2] === 'string' && args[2] !== ''
        ? args[2]
        : (typeof selection?.provider === 'string' && selection.provider !== '' ? selection.provider : null);
      const effort = typeof selection?.reasoningEffort === 'string' && selection.reasoningEffort !== ''
        ? selection.reasoningEffort
        : (typeof args[3] === 'string' && args[3] !== '' ? args[3] : undefined);
      // A provider is passed through when the controller has one, but it is not
      // required: `MobileModelOption` carries no provider id, so the Host
      // resolves it from its own catalog rather than refusing the choice.
      try {
        const selected = await select({
          sessionId,
          provider: provider ?? undefined,
          model,
          reasoningEffort: effort,
        });
        // The controller applies this to the row it is showing. A second screen
        // watching the same session learns the change from its next list read:
        // the row-level channel that would push it belongs to the `sessions`
        // topic, which a controller viewing one session does not hold.
        return invokeResult(request, {
          selected: selected?.selected ?? { provider, model, ...(effort === undefined ? {} : { reasoningEffort: effort }) },
        });
      } catch (error) {
        return invokeError(request, refusalCodeOf(error), String(error?.message ?? error));
      }
    }

    // The composer's `/` and `@` palettes.
    //
    // Refusing these is what the user sees as "channel is not available on DSH
    // Host" while typing — the palette is part of the agent's own information
    // flow, not an extra, so it answers even when a source is missing: an empty
    // palette reads as "nothing to offer", which is true, while a refusal reads
    // as a broken composer.
    if (channel === 'maker:set-effort') {
      // Effort is advertised in the capabilities (`effortLevels`, read from the
      // model catalog), so the controller draws the picker and will call this.
      // A Host that lists effort levels but cannot apply one is the same class of
      // lie as a model catalog that cannot route.
      const setEffort = capabilitiesNow().setEffort;
      if (typeof setEffort !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot change the reasoning effort');
      const sessionId = String(args[0] ?? '');
      const effort = typeof args[1] === 'string' ? args[1] : '';
      if (sessionId === '' || effort === '') return invokeError(request, 'BAD_REQUEST', 'maker:set-effort needs a session and an effort');
      try {
        await setEffort({ sessionId, effort });
        // The row the controller holds is now stale, exactly as after a model or
        // permission change.
        const push = capabilitiesNow().pushInputProjection;
        if (typeof push === 'function') push(sessionId);
        return invokeResult(request, true);
      } catch (error) {
        return invokeError(request, refusalCodeOf(error), String(error?.message ?? error));
      }
    }

    if (channel === 'maker:list-agent-skills') {
      const palette = capabilitiesNow().palette;
      if (typeof palette?.skills !== 'function') return invokeResult(request, { success: true, skills: [] });
      const cwd = typeof args[1]?.workingDir === 'string' && args[1].workingDir !== '' ? args[1].workingDir : undefined;
      // The session is what names the viewing scope: a preset's skills are
      // registered into its own layer, so without it the registry answers for
      // the global layer alone and this menu is empty on a profile that has
      // skills. The controller sends the same field for its command list.
      const sessionId = typeof args[1]?.sessionId === 'string' ? args[1].sessionId : '';
      let summaries = [];
      try {
        summaries = await palette.skills({ cwd, sessionId });
      } catch {
        summaries = [];
      }
      return invokeResult(request, toAgentSkills(summaries));
    }

    if (channel === 'maker:list-agent-commands') {
      const palette = capabilitiesNow().palette;
      if (typeof palette?.commands !== 'function') return invokeResult(request, { success: true, commands: [] });
      const sessionId = typeof args[1]?.sessionId === 'string' ? args[1].sessionId : '';
      let descriptors = [];
      try {
        descriptors = await palette.commands({ sessionId });
      } catch {
        descriptors = [];
      }
      return invokeResult(request, toAgentCommands(descriptors, 'agent-builtin'));
    }

    if (channel === 'maker:list-desktop-commands') {
      // Commands only the controlling desktop can run. This Host owns none, and
      // an empty success is the right answer here — unlike the provider catalog,
      // nothing downstream branches on this channel being *unsupported*.
      return invokeResult(request, { success: true, commands: [] });
    }

    if (channel === 'maker:scan-at-resources') {
      const palette = capabilitiesNow().palette;
      const workingDir = typeof args[1]?.workingDir === 'string' ? args[1].workingDir : '';
      if (typeof palette?.resources !== 'function' || workingDir === '') {
        return invokeResult(request, { success: true, items: [] });
      }
      let entries = [];
      try {
        entries = await palette.resources({
          workingDir,
          query: typeof args[1]?.query === 'string' ? args[1].query : '',
          cap: Number.isFinite(args[1]?.cap) ? args[1].cap : undefined,
        });
      } catch {
        entries = [];
      }
      return invokeResult(request, toAtResources(entries, {
        workingDir,
        cap: Number.isFinite(args[1]?.cap) ? args[1].cap : undefined,
        query: typeof args[1]?.query === 'string' ? args[1].query : '',
      }));
    }

    if (channel === 'maker:create-session') {
      const create = capabilitiesNow().createSession;
      if (typeof create !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot create sessions yet');
      const options = args[0] !== null && typeof args[0] === 'object' ? args[0] : {};
      // The runtime the controller picked for this conversation arrives **here and
      // nowhere else**. A new chat on the handset has no session to call
      // `maker:set-model` on yet — its whole pipeline is create, getSession, enqueue,
      // with no model write in between (measured in
      // `apps/mobile/src/session/newSessionCreation.ts`, which never calls `setModel`).
      // A Host that reads only `id`/`workingDir` therefore leaves the new session with
      // no session-local selection at all, and DSH's first prompt falls back to the
      // profile's `agent-default-model` — reported as
      // 「新对话选了 gpt，一运行又变成 deepseek」.
      //
      // The names are the controller's own: the handset
      // (`buildRemoteCreateSessionOptions`) and the desktop (`buildDeviceLinkCreateArgs`)
      // both send `model`, an optional `providerId` (absent/blank = follow this Host's
      // default route) and `effort`.
      //
      // `permissionMode` is the same class of field and the same class of loss, with a
      // worse failure: the handset's permission options **are** this Host's own
      // advertised Cindy `permissionModes` (ask / acceptEdits / bypassPermissions),
      // mapped exactly onto DSH read-only / workspace-write / danger-full-access presets.
      // A user who picks ask and gets the profile default of danger-full-access believes the agent is restricted while it
      // holds full access. Whatever reaches the seam here is whatever the controller
      // chose; the seam decides whether this Host can actually install it.
      const model = typeof options.model === 'string' ? options.model.trim() : '';
      const provider = typeof options.providerId === 'string' ? options.providerId.trim() : '';
      const effort = typeof options.effort === 'string' ? options.effort.trim() : '';
      const permission = typeof options.permissionMode === 'string' ? toDshPermissionMode(options.permissionMode) : null;
      try {
        // The controller may pre-allocate the session id so its optimistic row and
        // route use the final id from the start; DSH's create is idempotent on a
        // supplied id, so passing it through is safe and avoids a rekey.
        const created = await create({
          sessionId: typeof options.id === 'string' && options.id !== '' ? options.id : undefined,
          cwd: typeof options.workingDir === 'string' && options.workingDir !== '' ? options.workingDir : undefined,
          ...(model === '' ? {} : { model }),
          ...(provider === '' ? {} : { provider }),
          ...(effort === '' ? {} : { reasoningEffort: effort }),
          ...(permission === null ? {} : { permissionMode: permission }),
        });
        // What the session is actually on, never what was asked for: DSH resolves and
        // normalizes the selection, so echoing the request would claim a route the
        // session may not be running. Absent means the Host named no selection, which
        // is the only honest answer when the controller named none either.
        const applied = created?.selection ?? null;
        // A new session must be in the next list read, not five seconds later.
        invalidateSessionRows();
        return invokeResult(request, {
          sessionId: String(created?.sessionId ?? options.id ?? ''),
          // The requested platform is ignored. Echo only the applied DSH route
          // (or its known default), not the controller's draft kind.
          agentKind: agentKindForModel({ model: applied?.model, provider: applied?.provider, catalog: agentCatalog }),
          workDir: options.workingDir ?? null,
          usedProjectContext: false,
          ...(applied === null ? {} : {
            model: applied.model,
            providerId: applied.provider,
            ...(typeof applied.reasoningEffort === 'string' && applied.reasoningEffort !== ''
              ? { effort: applied.reasoningEffort }
              : {}),
          }),
          // Present only when the preset was really installed. A mode this Host does
          // not advertise keeps the profile's preset, and saying nothing about it is
          // the honest answer — the authoritative session row reports what is in force,
          // and the seam logs the request it could not honor.
          ...(typeof created?.permissionMode === 'string' && created.permissionMode !== ''
            ? { permissionMode: toCindyPermissionMode(created.permissionMode) }
            : {}),
        });
      } catch (error) {
        // A session that was created but whose model cannot be routed must not be
        // reported as a clean success: its row would then read deepseek while the user
        // is looking at the model they picked — the silent lie this path exists to
        // avoid. The refusal travels as a code the controller already understands, and
        // its idempotent retry adopts the existing session instead of creating another.
        return invokeError(request, refusalCodeOf(error), String(error?.message ?? error));
      }
    }

    if (channel === 'local-db:sessions:patch-meta') {
      const sessionId = String(args[0] ?? '');
      const patch = args[1] !== null && typeof args[1] === 'object' ? args[1] : {};
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', 'local-db:sessions:patch-meta needs a session id');

      // The controller's whole 删除 / 归档 / 置顶 / 重命名 menu arrives here, and it
      // reads the **returned row** as the truth: `useSessionListActions` applies only
      // the fields it wrote, taken from this reply. Answering with an unchanged row is
      // therefore not a refusal — it is an instruction to revert the user's edit,
      // which is how these three actions used to look like dead buttons.
      //
      // The runtime delegates archive/restore to native DSH and keeps delete/pin
      // compatibility metadata. The reply uses that same effective projection
      // as every list/get read, never just the requested status.
      const capabilities = capabilitiesNow();
      const rename = capabilities.renameSession;
      if (typeof capabilities.validateSessionMetaPatch === 'function') {
        try { capabilities.validateSessionMetaPatch(patch); }
        catch (error) { return invokeError(request, refusalCodeOf(error), String(error.message)); }
      }
      let wrote = false;
      if (typeof rename === 'function' && typeof patch.title === 'string' && patch.title.trim() !== '') {
        await rename({ sessionId, title: patch.title.trim() });
        wrote = true;
      }

      let deleteAcknowledgement;
      const writesMeta = patch.status !== undefined || patch.pinnedAt !== undefined;
      if (writesMeta) {
        const applyFlags = capabilities.applySessionFlags;
        if (typeof applyFlags !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot archive, delete or pin sessions');
        let applied;
        try {
          applied = await applyFlags(sessionId, { status: patch.status, pinnedAt: patch.pinnedAt });
        } catch (error) {
          if (error?.refusalCode !== undefined) return invokeError(request, refusalCodeOf(error), String(error.message));
          throw error;
        }
        wrote = true;
        // Echo only what was written, with this Host's effective value: that is the
        // same patch the controller applied optimistically, so other devices converge
        // on it too.
        const echoed = {};
        if (patch.status !== undefined) echoed.status = applied.status;
        if (patch.pinnedAt !== undefined) echoed.pinnedAt = applied.pinnedAt;
        // Deleting an already absent source session is still a successful hide once
        // its flags are saved. The phone needs only the fields it wrote; do not
        // fabricate a full session or extend this acknowledgement to mixed edits.
        if (patch.status === 'deleted' && applied.status === 'deleted'
          && Object.keys(patch).every((key) => key === 'status' || key === 'pinnedAt')) {
          deleteAcknowledgement = { id: sessionId, ...echoed };
        }
        if (typeof capabilities.publishSessionMeta === 'function') capabilities.publishSessionMeta(sessionId, echoed);
      }

      // The write just changed what a list read must say, so the cached page is void: without
      // this the reply below would echo the pre-write row, and the controller reads an
      // unchanged row as "revert my edit" (that is how these buttons looked dead once already).
      if (wrote) invalidateSessionRows();
      const row = await sessionRow(sessionId);
      if (row === undefined && deleteAcknowledgement !== undefined) return invokeResult(request, deleteAcknowledgement);
      return row === undefined ? invokeError(request, 'NOT_FOUND', `No DSH session ${sessionId}`) : invokeResult(request, row);
    }

    // The composer's send paths. `maker:send` is the direct one; an idle turn
    // uses `maker:input:enqueue` and a running turn uses `maker:input:steer`,
    // and BOTH must answer or the composer spins in one of the two states.
    if (channel === 'maker:input:enqueue' || channel === 'maker:input:steer') {
      const capabilities = capabilitiesNow();
      const sessionId = String(args[0] ?? '');
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', `${channel} needs a session id`);

      if (typeof capabilities.inputDelivery === 'function') {
        let delivery;
        try { delivery = capabilities.inputDelivery(); } catch (error) { return deliveryReply(request, () => { throw error; }); }
        if (delivery) return deliveryReply(request, () => channel === 'maker:input:steer' ? delivery.steer(sessionId, args[1], args[2] ?? {}) : delivery.accept(sessionId, args[1], args[2] ?? {}));
      }

      if (continuationKind(extractSendText(args[1]))) return invokeError(request, 'NOT_AVAILABLE', 'Safe manual continuation requires native durable input delivery');

      // A `steer` naming an item DSH already holds is a **promotion** of that
      // queued item, not a new message: the controller sends the queued row back
      // with `removeFromQueue`. Re-sending its text would duplicate it, which is
      // exactly what a queued item's 插话 button must not do.
      const namedId = typeof args[1]?.clientId === 'string' && args[1].clientId !== '' ? args[1].clientId : null;
      if (channel === 'maker:input:steer' && namedId !== null) {
        // Attach the session first: the inbox belongs to the live agent, so
        // without this the lookup reports the item missing on a cold session and
        // the steer degrades into a second send.
        if (typeof capabilities.ensureAgent === 'function') await capabilities.ensureAgent(sessionId);
        // One shot, no wait: steering a brand-new message is the common case and
        // must not pay for a queue lookup. Only an item the Host can already
        // address is treated as a promotion.
        const dshId = await resolveDshItemId(capabilities, sessionId, namedId, 0);
        if (dshId !== null) {
          const control = capabilities.queueControl;
          if (typeof control !== 'object' || control === null) {
            return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot change the pending queue');
          }
          const failure = await commitQueueActionAndReconcile(capabilities, sessionId, dshId, { kind: 'steer' });
          if (failure !== null) return invokeError(request, failure.code, failure.message);
          // `mirror` only re-places an item the fold already holds, and this one may not be
          // there: the authoritative read that follows an enqueue can race DSH's splice and
          // come back empty. That is exactly how a promoted 插话 left the projection saying
          // nothing — measured as a 42-second gap (08:54:40 promoted → 08:55:22 durable)
          // with the phone's bubble abandoned in between. The upsert makes the steering id
          // true from this moment; the durable row's `retireQueuedItem` clears it again.
          //
          // The record has to carry the message **content**, because that is what the
          // controller renders: the first version restated the id with `content: []`, and the
          // bubble appeared with no text in it (「插入之后里面的文字被清空了」) while the same
          // empty item produced an empty transcript row. The fold's own record is the
          // authority when it has one; otherwise the text the controller sent with the row.
          const mirror = capabilities.queueMirror;
          const known = typeof mirror?.itemFor === 'function' ? mirror.itemFor(sessionId, namedId) : null;
          const knownContent = Array.isArray(known?.message?.content) && known.message.content.length > 0
            ? known.message.content
            : null;
          const carried = extractSendText(args[1]);
          const content = knownContent
            ?? (typeof carried === 'string' && carried !== '' ? [{ type: 'text', text: carried }] : []);
          // Keyed on DSH's own id, not the controller's: the fold is keyed that way, and an
          // upsert under the `clientId` left the original queued row in the fold beside the new
          // steering one — a duplicate the projection then reported as both `queued` and
          // `steering`. The controller's id travels as `rpcId`, which is what the projection
          // names the row by.
          const itemId = known?.id !== undefined && known?.id !== null ? String(known.id) : String(dshId);
          if (typeof mirror?.markSteering === 'function') {
            mirror.markSteering(sessionId, {
              ...(known ?? {}),
              id: itemId,
              rpcId: namedId,
              message: { ...(known?.message ?? {}), id: itemId, content },
            });
          } else {
            mirror?.mirror(sessionId, namedId, { kind: 'steer' });
          }
          // The promotion moved the row from "queued" to "steering": tell the controller
          // that, or the row it is showing disappears in the hand-off.
          capabilities.pushInputProjection?.(sessionId);
          // The controller answers a steer with a boolean and then refetches.
          return invokeResult(request, true);
        }
      }

      const text = extractSendText(args[1]);
      const attachments = extractSendAttachments(args[1]);
      // A prompt with neither text nor a serveable attachment is nothing to run, and
      // accepting it would show the user a delivered message DSH has no counterpart
      // for. **Attachment-only is legitimate** — the phone's composer sends a photo
      // with `text: ''` — so the refusal is about having nothing at all, not about
      // having no words.
      if (text === null && attachments.length === 0) {
        return invokeError(request, 'BAD_REQUEST', `${channel} carried no text and no attachment this Host can serve`);
      }

      // A steer needs a **live turn**, and even then DSH can refuse it: "current turn no longer
      // accepts steering" is what the phone showed when the user's tap landed as the turn moved
      // past its steerable point. Checking the session state answers the first half (a turn that
      // never started), and it cannot answer the second: the gap between our check and DSH's
      // decision is a race, and **the user's words must not be the thing that loses it**.
      //
      // So a refused steer is retried once as a normal prompt: the same intent one step later,
      // which starts the turn it could not join. Measured before this: the insert produced an
      // error string on the handset and the message the user was looking at was lost from the
      // conversation until they sent it again.
      const wantsSteer = channel === 'maker:input:steer' && capabilities.isSessionRunning?.(sessionId) === true;
      if (typeof capabilities.sendMessage !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot send prompts yet');
      // The controller's own `clientId` is the prompt identity, and DSH persists
      // it as the queued item's `rpcId` — the field the controller retires its
      // local echo on, and the field DSH dedupes a retried prompt against.
      // Sending the relay's envelope id instead left the draft in the composer
      // (so the next thing the user typed was appended to it) and made a retry
      // indistinguishable from a new message.
      const send = (mode) => capabilities.sendMessage({
        sessionId,
        text: text ?? '',
        requestId: namedId ?? request.id,
        mode,
        // A message with no serveable attachment keeps the exact shape it always
        // had: an empty list is not information, and every seam test pins it.
        ...(attachments.length > 0 ? { attachments } : {}),
      });
      let steer = wantsSteer;
      let sent;
      try {
        sent = await send(wantsSteer ? 'steer' : 'queue');
      } catch (error) {
        const message = String(error?.message ?? error);
        if (!wantsSteer || !/steer/i.test(message)) throw error;
        // The turn would not take it. Say it as a prompt instead, and remember that this was not a
        // steering row so the projection does not claim one.
        steer = false;
        sent = await send('queue');
      }
      // An attachment-only prompt whose bytes could not be fetched is refused with
      // the reason: sending it would deliver a photo the agent never saw.
      if (sent !== undefined && sent !== null && sent.ok === false) {
        return invokeError(request, sent.code ?? 'ATTACHMENT_UNAVAILABLE', sent.message ?? 'the attachment could not be fetched');
      }

      if (steer) {
        // A **new** steering prompt (not a promotion) has to be made visible before it is
        // durable.
        //
        // DSH splices it into the running turn's next step a moment after `prompt()`
        // returns, so a projection read taken right now may legitimately say nothing about
        // it. The controller's bubble would then have nothing to hold on to and vanish —
        // 手机上「转圈转圈然后就消失了」 while the message did reach the desktop. Recording
        // it as a steering item keeps `steeringQueueClientIds` truthful from this moment,
        // and `retireQueuedItem` clears it the instant the durable row arrives.
        const controllerId = namedId ?? request.id;
        if (typeof capabilities.queueMirror?.markSteering === 'function') {
          capabilities.queueMirror.markSteering(sessionId, {
            id: controllerId,
            rpcId: controllerId,
            message: { id: controllerId, content: text === null || text === '' ? [] : [{ type: 'text', text }] },
          });
        }
        capabilities.pushInputProjection?.(sessionId);
        return invokeResult(request, true);
      }

      // Answer with the queue DSH actually holds.
      //
      // This Host used to synthesise a `pendingQueue` row for every accepted
      // prompt. When the session was idle DSH admitted the prompt immediately and
      // never put it in the inbox, so that row described a queue entry that did
      // not exist — and nothing would ever clear it, because no queue frame is
      // emitted for an item that was never queued. The phone showed 队列中 for a
      // message the agent had already answered.
      //
      // The authoritative read is the honest answer: a row appears only if DSH is
      // really holding one. A prompt that was admitted instead shows up as a
      // durable message, which is what the controller renders anyway.
      if (typeof capabilities.readSessionState === 'function' && typeof capabilities.projectionFromItems === 'function') {
        const state = await capabilities.readSessionState(sessionId);
        if (state !== null && state !== undefined) {
          const items = queueItemsFromInbox(state.inbox);
          // Teach the fold the durable ids, so a later cancel or edit resolves
          // without waiting for a queue frame that may never come.
          capabilities.queueMirror?.adopt?.(sessionId, items);
          const held = namedId !== null
            && items.some((entry) => entry.rpcId === namedId || entry.id === namedId);
          // A prompt accepted **while a turn is running** belongs in the queue,
          // and DSH's durable splice can land a moment after `prompt` returns —
          // so that one row is shown from the acceptance itself. A prompt
          // accepted by an idle session is admitted immediately, and showing it
          // as queued is what left the phone spinning on a 队列中 row for a
          // message the agent had already answered.
          const pending = !held && namedId !== null && capabilities.isSessionRunning?.(sessionId) === true
            ? (capabilities.queuedRow?.({ clientId: namedId, text, sessionId }) ?? null)
            : null;
          // A synthesised row has to exist in the fold too, not just in this answer: the
          // controller will keep showing it, and the next thing that happens to it (插话 →
          // promotion, 编辑, 删除) resolves against the fold by that id.
          if (pending !== null && typeof capabilities.queueMirror?.markQueued === 'function') {
            capabilities.queueMirror.markQueued(sessionId, {
              id: namedId,
              rpcId: namedId,
              message: { id: namedId, content: text === null || text === '' ? [] : [{ type: 'text', text }] },
            });
          }
          return invokeResult(request, capabilities.projectionFromItems(sessionId, items, pending));
        }
      }

      const project = capabilities.inputProjection;
      const pending = namedId === null ? null : capabilities.queuedRow?.({ clientId: namedId, text, sessionId });
      const projection = typeof project === 'function'
        ? project(sessionId, pending ?? null)
        : { sessionId, pendingQueue: pending === null ? [] : [pending], steeringQueueClientIds: [] };
      return invokeResult(request, projection);
    }

    // Queue commands. The queue lives in DSH's durable inbox, so every mutation
    // goes to `sessionController.updateQueue` (or `cancel`) and is mirrored into
    // this Host's fold: DSH's own queue frame trails the commit, and answering a
    // removal with the pre-removal queue would put the row straight back.
    if (QUEUE_COMMAND_CHANNELS.has(channel)) {
      const capabilities = capabilitiesNow();
      const sessionId = String(args[0]?.sessionId ?? args[0] ?? '');
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', `${channel} needs a session id`);
      const mirror = capabilities.queueMirror;
      const control = capabilities.queueControl;
      const clientId = typeof args[1] === 'string' ? args[1] : (typeof args[1]?.clientId === 'string' ? args[1].clientId : null);

      let durableQueue = null;
      if (typeof capabilities.inputDelivery === 'function') {
        try { durableQueue = capabilities.inputDelivery(); } catch (error) { return deliveryReply(request, () => { throw error; }); }
      }
      if (durableQueue && ['maker:input:remove', 'maker:input:clear-session', 'maker:input:update-text', 'maker:input:update-content'].includes(channel)) {
        return deliveryReply(request, async () => {
          const delivery = durableQueue;
          if (channel === 'maker:input:clear-session') return delivery.clear(sessionId);
          if (channel === 'maker:input:remove') return delivery.cancel(sessionId, clientId);
          return delivery.edit(sessionId, clientId, args[2]);
        });
      }

      // Controller-owned queue UI state. The controller sets it here and reads it
      // back out of the projection, so it must be recorded rather than ignored.
      if (channel === 'maker:input:set-expanded') {
        mirror?.setExpanded(sessionId, args[1] === true);
        return answerQueueCommand(request, capabilities, sessionId);
      }
      if (channel === 'maker:input:set-edit-lock') {
        mirror?.setEditLock(sessionId, clientId, args[2] === true);
        return answerQueueCommand(request, capabilities, sessionId);
      }
      if (channel === 'maker:input:set-interaction-lock') {
        mirror?.setInteractionLock(sessionId, clientId, args[2] === true);
        return answerQueueCommand(request, capabilities, sessionId);
      }
      // `resume` reopens a paused queue. DSH's inbox is never paused — this Host
      // reports `queuePaused: false` always — so there is nothing to resume and
      // the current projection is the whole truth.
      if (channel === 'maker:input:resume') {
        return answerQueueCommand(request, capabilities, sessionId);
      }

      if (typeof control !== 'object' || control === null) {
        return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot change the pending queue');
      }

      if (channel === 'maker:input:stop') {
        // DSH cancels the active turn without dropping the pending inbox, which
        // is exactly what the controller asks for: it only ever sends
        // `keepQueue: true` (see `stopOptionsForProjection`).
        try {
          await control.cancel({ sessionId });
          capabilities.manualCompact?.cancelSession?.(sessionId, 'Stopped by controller');
        } catch (error) {
          return invokeError(request, 'THREW', String(error?.message ?? error));
        }
        return answerQueueCommand(request, capabilities, sessionId);
      }

      if (channel === 'maker:input:clear-session') {
        // Emptying the queue means removing DSH's items one by one: the inbox is
        // the only owner, and `updateQueue` is the only supported mutation.
        //
        // An item DSH has already admitted is **not a failure here**, and two measured
        // behaviours depended on saying so. `updateQueue` answers such an item with
        // `session/queue-item-not-found` ("queued item is no longer pending"), which is the
        // outcome this channel exists to produce — the queue is what it should be. Returning
        // it as an error also aborted the loop, so everything after the first already-admitted
        // item stayed queued while the controller was told the clear had failed. Both showed
        // up as the acceptance suite's only two failures once refusals stopped being swallowed.
        // A genuine refusal is still reported, after the rest has been attempted.
        const ids = mirror?.itemIds(sessionId) ?? [];
        let failure = null;
        for (const itemId of ids) {
          const outcome = await commitQueueActionAndReconcile(capabilities, sessionId, itemId, { kind: 'remove' });
          if (outcome === null) continue;
          if (outcome.code === 'session/queue-item-not-found') continue;
          if (failure === null) failure = outcome;
        }
        // Only claim the queue is empty when it is: a real failure leaves the fold alone, so
        // the rows DSH still holds stay visible instead of vanishing on a false promise.
        if (failure === null) mirror?.clearSession(sessionId);
        if (failure !== null) return invokeError(request, failure.code, failure.message);
        return answerQueueCommand(request, capabilities, sessionId);
      }

      let action;
      if (channel === 'maker:input:remove') {
        action = { kind: 'remove' };
      } else if (channel === 'maker:input:update-text' || channel === 'maker:input:update-content') {
        // `update-text` passes the new text directly; `update-content` passes a
        // whole queued row (text plus attachments). Only text is durable here.
        const text = channel === 'maker:input:update-text' ? args[2] : extractSendText(args[2]);
        if (typeof text !== 'string' || text.trim() === '') {
          return invokeError(request, 'BAD_REQUEST', `${channel} carried no text`);
        }
        action = { kind: 'edit', content: [{ type: 'text', text }] };
      } else {
        return invokeError(request, 'BAD_REQUEST', `${channel} is not a queue command`);
      }

      if (clientId === null || clientId === '') return invokeError(request, 'BAD_REQUEST', `${channel} needs an item id`);
      // `updateQueue` is keyed on DSH's durable `MessageId`, not the `clientId`
      // the controller minted, so the id is translated — and the session is
      // attached first, because the inbox only exists on a live agent: without
      // that, a queued item on a cold session is invisible and the mutation is
      // refused as if the item had vanished.
      if (typeof capabilities.ensureAgent === 'function') await capabilities.ensureAgent(sessionId);
      const dshId = await resolveDshItemId(capabilities, sessionId, clientId);
      if (dshId === null) return invokeError(request, 'NOT_FOUND', `No queued item ${clientId}`);
      const failure = await commitQueueActionAndReconcile(capabilities, sessionId, dshId, action);
      if (failure !== null) {
        // A phone can delete a row just after the desktop admitted or removed it.
        // DSH then says the item is no longer pending; for *remove* only, that is
        // already the requested outcome. Verify against the durable inbox before
        // retiring the stale phone row, rather than turning it into a sync error.
        // Edit and steer must still report the refusal: they did not take effect.
        if (channel === 'maker:input:remove' && failure.code === 'session/queue-item-not-found'
          && typeof capabilities.readSessionState === 'function' && typeof mirror?.adopt === 'function') {
          let state = null;
          try { state = await capabilities.readSessionState(sessionId); } catch { /* Keep the original refusal. */ }
          if (state?.inbox !== null && typeof state?.inbox === 'object') {
            const items = queueItemsFromInbox(state.inbox);
            if (!items.some((item) => item.id === String(dshId) || item.rpcId === clientId)) {
              mirror.adopt(sessionId, items);
              return answerQueueCommand(request, capabilities, sessionId);
            }
          }
        }
        return invokeError(request, failure.code, failure.message);
      }
      mirror?.mirror(sessionId, clientId, action);
      return answerQueueCommand(request, capabilities, sessionId);
    }

    if (channel === 'maker:input:move') {
      const capabilities = capabilitiesNow();
      const sessionId = String(args[0] ?? '');
      const clientId = typeof args[1] === 'string' ? args[1] : null;
      if (sessionId === '' || clientId === null) return invokeError(request, 'BAD_REQUEST', 'maker:input:move needs a session and an item id');
      if (typeof capabilities.inputDelivery === 'function') {
        try { if (capabilities.inputDelivery()) return invokeError(request, 'NOT_AVAILABLE', 'DSH has no public durable inbox reorder operation'); } catch (error) { return deliveryReply(request, () => { throw error; }); }
      }
      // Reordering is presentation: DSH's inbox keeps its own order and a
      // reordered row would snap back on the next frame, so this Host records
      // the new order locally and says nothing it cannot keep.
      capabilities.queueMirror?.moveItem(sessionId, clientId, args[2]);
      return answerQueueCommand(request, capabilities, sessionId);
    }

    if (channel === 'maker:send') {
      const send = capabilitiesNow().sendMessage;
      if (typeof send !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot send prompts yet');
      const sessionId = String(args[0] ?? '');
      const text = extractSendText(args[1]);
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', 'maker:send needs a session id');
      const sendAttachments = extractSendAttachments(args[1]);
      // Refusing beats sending an empty prompt: the controller would show the
      // message as sent while DSH had nothing to run. A photo with no caption is
      // still something to run, so only "nothing at all" is refused.
      if (text === null && sendAttachments.length === 0) {
        return invokeError(request, 'BAD_REQUEST', 'maker:send carried no text and no attachment this Host can serve');
      }
      // The controller's own `clientId` is the prompt identity on this path too.
      // DSH persists it as the message's `rpcId`, which is what the controller
      // retires its local submission echo on — send the relay's envelope id and
      // the echo never clears, so the message sits "sending" and then vanishes.
      const clientId = typeof args[1]?.clientId === 'string' && args[1].clientId !== ''
        ? args[1].clientId
        : (typeof args[2]?.clientId === 'string' && args[2].clientId !== '' ? args[2].clientId : null);
      const capabilities = capabilitiesNow();
      if (typeof capabilities.inputDelivery === 'function') {
        let delivery;
        try { delivery = capabilities.inputDelivery(); } catch (error) { return deliveryReply(request, () => { throw error; }); }
        if (delivery) return deliveryReply(request, async () => { await delivery.accept(sessionId, { clientId: clientId ?? request.id, text: text ?? '', files: sendAttachments }, args[2] ?? {}); return { accepted: true }; });
      }
      const sent = await send({
        sessionId,
        text: text ?? '',
        requestId: clientId ?? request.id,
        ...(sendAttachments.length > 0 ? { attachments: sendAttachments } : {}),
      });
      if (sent !== undefined && sent !== null && sent.ok === false) {
        return invokeError(request, sent.code ?? 'ATTACHMENT_UNAVAILABLE', sent.message ?? 'the attachment could not be fetched');
      }
      return invokeResult(request, { accepted: true });
    }

    // Approvals. The questions are DSH's own pending `approval/request`s, routed
    // here only while a controller is watching the asking session.
    if (channel === 'sidebar-settings:get-project-aliases' || channel === 'local-db:project-aliases:list') {
      // The desktop family sends a filter object on some builds; both channels are
      // pure reads, so anything beyond the arguments is ignored rather than refused.
      if (args.length > 1) return invokeError(request, 'BAD_REQUEST', 'Invalid project-alias argument count');
      const port = capabilitiesNow().projectAliases;
      // A Host that cannot name its Workspaces is not an error for the phone: it
      // already falls back to the folder basename. Answer the empty shape, don't refuse.
      if (channel === 'sidebar-settings:get-project-aliases') {
        if (typeof port?.read !== 'function') return invokeResult(request, { aliases: [], platform: process.platform });
        try { return invokeResult(request, port.read()); }
        catch (error) { return invokeError(request, refusalCodeOf(error), String(error?.message ?? error)); }
      }
      if (typeof port?.list !== 'function') return invokeResult(request, []);
      try { return invokeResult(request, port.list()); }
      catch (error) { return invokeError(request, refusalCodeOf(error), String(error?.message ?? error)); }
    }

    if (channel === 'sidebar-settings:get-project-order' || channel === 'sidebar-settings:apply-project-order') {
      const read = channel === 'sidebar-settings:get-project-order';
      if (args.length !== (read ? 0 : 1)) return invokeError(request, 'BAD_REQUEST', 'Invalid project-order argument count');
      const port = capabilitiesNow().projectOrder;
      if (!port) return read ? invokeResult(request, { authoritative: false, available: false, manualProjectOrder: [], projectOrder: 'activity' }) : invokeError(request, 'NOT_AVAILABLE', 'Native Workspace ordering is not composed');
      try { return invokeResult(request, read ? await port.read() : await port.apply(args[0])); }
      catch (error) { return invokeError(request, refusalCodeOf(error), String(error?.message ?? error)); }
    }

    if (['maker:schedule:list', 'maker:schedule:get', 'maker:schedule:create', 'maker:schedule:update', 'maker:schedule:delete'].includes(channel)) {
      const method = channel.slice(channel.lastIndexOf(':') + 1);
      const expected = method === 'list' ? undefined : method === 'update' ? 2 : 1;
      if (expected === undefined ? args.length > 1 : args.length !== expected) return invokeError(request, 'BAD_REQUEST', 'Invalid native reminder argument count');
      const port = capabilitiesNow().reminders;
      if (typeof port?.[method] !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'Native existing-session reminders are not composed');
      const options = { getView: id => sessionRow(id), requestKey: JSON.stringify([request.src, request.id, channel]) };
      try { const value = method === 'update' ? await port.update(args[0], args[1], options) : await port[method](args[0], options); return invokeResult(request, value); }
      catch (error) { return invokeError(request, refusalCodeOf(error), String(error?.message ?? error)); }
    }

    if (['local-db:subagent-runs:list', 'local-db:subagent-runs:detail', 'local-db:subagent-runs:transcript'].includes(channel)) {
      if (args.length !== 1) return invokeError(request, 'BAD_REQUEST', 'Subagent reads need one request object');
      const method = channel.slice(channel.lastIndexOf(':') + 1); const port = capabilitiesNow().subagentReads;
      if (typeof port?.[method] !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'Native read-only subagent catalog is not composed');
      try { return invokeResult(request, await port[method](args[0])); }
      catch (error) { return invokeError(request, refusalCodeOf(error), String(error?.message ?? error)); }
    }

    if (channel === 'maker:session-background-tasks:list') {
      if (args.length !== 1 || typeof args[0] !== 'string' || !args[0].trim()) return invokeError(request, 'BAD_REQUEST', 'Background task list needs one session identity');
      const port = capabilitiesNow().backgroundJobs;
      if (typeof port?.read !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'Native background jobs are not composed');
      try { return invokeResult(request, await port.read(args[0])); }
      catch (error) { return invokeError(request, refusalCodeOf(error), String(error?.message ?? error)); }
    }

    if (channel === 'local-db:conversations:search') {
      if (args.length !== 1) return invokeError(request, 'BAD_REQUEST', 'Conversation search needs one request object');
      const port = capabilitiesNow().keywordSearch;
      if (typeof port?.run !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'Native keyword search is not composed');
      try {
        return invokeResult(request, await port.run(args[0], { getCandidates: async () => {
          const rows = await sessionRows();
          if (capabilitiesNow().keywordSearch !== port) throw refusalError('NOT_AVAILABLE', 'Native search source changed during candidate discovery');
          return rows;
        } }));
      } catch (error) { return invokeError(request, refusalCodeOf(error), String(error?.message ?? error)); }
    }

    if (channel === 'maker:fork') {
      const [sessionId, messageClientId] = args;
      if (args.length !== 2 || typeof sessionId !== 'string' || !sessionId.trim() ||
        typeof messageClientId !== 'string' || !messageClientId.trim()) return invokeError(request, 'BAD_REQUEST', 'fork needs exact source and message identities');
      const capabilities = capabilitiesNow(); const port = capabilities.forkSession;
      if (typeof port?.run !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'Native ordinary fork is not composed');
      if (capabilities.sessionHidden?.(sessionId) === true) return invokeError(request, 'NOT_AVAILABLE', 'Hidden source sessions cannot be forked');
      let created;
      try {
        created = await port.run({ sessionId, messageClientId, requestKey: JSON.stringify([request.src, request.id]) });
        invalidateSessionRows();
        if (capabilitiesNow().forkSession !== port) return invokeError(request, 'NOT_AVAILABLE', 'Native child was created but the source changed; sessionId=' + created.sessionId + '; do not repeat fork');
        capabilities.publishSessionCreated?.(created.sessionId);
        if (created.partial) return invokeError(request, 'THREW', created.partial + '; sessionId=' + created.sessionId + '; do not repeat fork; read the created session');
        const row = await sessionRow(created.sessionId);
        if (!row) return invokeError(request, 'NOT_AVAILABLE', 'Native child was created but its row is not yet readable; sessionId=' + created.sessionId + '; do not repeat fork');
        return invokeResult(request, row);
      } catch (error) {
        const evidence = created?.sessionId ? '; native child already created; sessionId=' + created.sessionId + '; do not repeat fork' : '';
        return invokeError(request, refusalCodeOf(error), String(error?.message ?? error) + evidence);
      }
    }

    if (channel === 'maker:compact-session') {
      const sessionId = args[0];
      const instructions = args[1];
      if (args.length > 2 || typeof sessionId !== 'string' || sessionId.trim() === '' ||
        (instructions !== undefined && typeof instructions !== 'string')) {
        return invokeError(request, 'BAD_REQUEST', 'compact-session needs a session id and optional string instructions');
      }
      if (instructions?.trim()) return invokeError(request, 'NOT_AVAILABLE', 'Native DSH /compact does not accept custom instructions');
      const capabilities = capabilitiesNow();
      if (typeof capabilities.manualCompact?.run !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'Native manual compaction is not composed');
      if (capabilities.sessionHidden?.(sessionId) === true) return invokeError(request, 'NOT_AVAILABLE', 'An archived or hidden session cannot be compacted');
      try {
        return invokeResult(request, await capabilities.manualCompact.run({ sessionId, instructions,
          requestKey: JSON.stringify([request.src, request.id]) }));
      } catch (error) {
        return invokeError(request, refusalCodeOf(error), String(error?.message ?? error));
      } finally {
        invalidateSessionRows();
        capabilities.invalidateHistoryView?.(sessionId);
      }
    }

    if (channel === 'maker:get-context-usage') {
      // How full the session's context is. The controller reads the answer
      // leniently (`totalTokens`/`contextTokens`, `maxTokens`/`contextWindow`,
      // `percent`) and renders "暂无上下文数据" for anything unusable — so an unknown
      // measurement is reported as `null` rather than as a zero, which would read
      // as "empty context".
      const usage = capabilitiesNow().contextUsage;
      if (typeof usage !== 'function') return invokeResult(request, null);
      const sessionId = String(args[0] ?? '');
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', 'maker:get-context-usage needs a session id');
      try {
        return invokeResult(request, (await usage({ sessionId })) ?? null);
      } catch {
        // A measurement that fails costs the panel, never the session.
        return invokeResult(request, null);
      }
    }

    if (channel === 'maker:regenerate-title') {
      // The controller sends `[{ sessionId }]` here — an object, unlike the bare
      // session-id string every other channel uses — and it reads the answer as
      // `{ title: string | null }`: this call only produces a title, and the
      // controller persists it through `local-db:sessions:patch-meta`. So "no title"
      // is a value, not an error frame.
      const sessionId = typeof args[0]?.sessionId === 'string' ? args[0].sessionId : '';
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', 'maker:regenerate-title needs a session id');
      const regenerate = capabilitiesNow().regenerateTitle;
      if (typeof regenerate !== 'function') return invokeResult(request, { title: null });
      try {
        return invokeResult(request, (await regenerate({ sessionId })) ?? { title: null });
      } catch {
        // A failed generation is the controller's documented "no title" outcome.
        return invokeResult(request, { title: null });
      }
    }

    if (channel === 'maker:get-pending-interactions') {
      const list = capabilitiesNow().listPendingInteractions;
      if (typeof list !== 'function') return invokeResult(request, []);
      const sessionId = typeof args[0] === 'string' && args[0] !== '' ? args[0] : undefined;
      return invokeResult(request, list(sessionId));
    }

    if (channel === 'maker:resolve-interaction') {
      const resolve = capabilitiesNow().resolveInteraction;
      if (typeof resolve !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot answer interactions');
      const requestId = typeof args[0] === 'string' ? args[0] : '';
      const decision = args[1] !== null && typeof args[1] === 'object' ? args[1] : {};
      if (requestId === '') return invokeError(request, 'BAD_REQUEST', 'maker:resolve-interaction needs a request id');
      // An unknown id or a decision this Host cannot map is refused rather than
      // acknowledged: the controller keeps the card open instead of believing it
      // was answered.
      return invokeResult(request, resolve(requestId, decision));
    }

    if (channel === 'maker:goal:get-status') {
      // Answered from the session projection stream, so a status read never
      // resumes a cold session to look at it.
      const sessionId = String(args[0] ?? '');
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', 'maker:goal:get-status needs a session id');
      const capabilities = capabilitiesNow();
      // Read the projection itself before trusting the stream: the pushed frames
      // are not guaranteed to arrive, and a goal that exists while every status
      // read answers `null` is a card that never appears.
      if (typeof capabilities.readSessionState === 'function') {
        const state = await capabilities.readSessionState(sessionId);
        // A registered key answers authoritatively, `null` value included.
        if (state !== null && state !== undefined && state.hasGoalKey === true) {
          return invokeResult(request, toGoalStatusPayload(sessionId, state.goal ?? null) ?? null);
        }
      }
      const goalStatus = capabilities.goalStatus;
      const folded = typeof goalStatus === 'function' ? goalStatus(sessionId) : undefined;
      if (folded !== undefined) return invokeResult(request, folded ?? null);
      // Nothing could answer, and the controller reads that difference exactly:
      // `undefined` (a payload with no `result` field) means "unknown, leave the
      // card alone", while an explicit `null` means "confirmed no goal" and wipes
      // it. Answering `null` here is how a live goal disappeared from the phone:
      // the projection read times out or the key is not registered, and because a
      // goal that has not changed never pushes again, nothing brought it back.
      return invokeResult(request, undefined);
    }

    // Goal writes. Unlike the status read above these cannot be answered from
    // the projection: DSH applies them as compare-and-set mutations on a live
    // `Agent`, so each one resolves the session. That is acceptable for an
    // action the user just took and is why the read path stays separate.
    if (GOAL_WRITE_CHANNELS.has(channel)) {
      const capabilities = capabilitiesNow();
      const write = capabilities.goalWrite;
      if (typeof write !== 'object' || write === null) {
        return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host composes no goal service');
      }
      const sessionId = String(args[0]?.sessionId ?? args[0] ?? '');
      if (sessionId === '') return invokeError(request, 'BAD_REQUEST', `${channel} needs a session id`);

      let outcome;
      if (channel === 'maker:goal:set') {
        outcome = await write.set({ sessionId, objective: args[0]?.objective, limits: args[0]?.limits });
      } else if (channel === 'maker:goal:update') {
        outcome = await write.update({ sessionId, patch: args[0]?.patch });
      } else {
        // `pause` / `resume` / `clear` take the bare session id.
        outcome = await write[channel.slice('maker:goal:'.length)](sessionId);
      }

      if (outcome?.ok !== true) {
        // The service's own code is passed through: `GOAL_ALREADY_EXISTS` and
        // `GOAL_INVALID_TRANSITION` say exactly what went wrong, and the
        // controller shows the message it is given.
        return invokeError(request, outcome?.code ?? 'THREW', outcome?.message ?? 'the goal write failed');
      }
      // The controller refetches status after a write, but a second screen
      // watching this session has no reason to — this is its signal.
      const push = capabilities.pushGoalStatus;
      if (typeof push === 'function') push(sessionId, outcome.status ?? null);
      return invokeResult(request, outcome.status ?? null);
    }

    if (channel === 'maker:git-safety:get') {
      // Git auto-snapshot is a Cindy desktop feature that guards its Rewind
      // entry. This Host has no such feature, so the honest answer is "off" —
      // refusing instead would look like a broken setting rather than an absent
      // one, and the controller reads these three booleans positionally.
      return invokeResult(request, { autoSnapshotEnabled: false, isCustomized: false, defaultAutoSnapshotEnabled: false });
    }

    if (channel === 'maker:input:get-projection') {
      const capabilities = capabilitiesNow();
      const sessionId = String(args[0] ?? '');
      if (typeof capabilities.inputDelivery === 'function') {
        let delivery;
        try { delivery = capabilities.inputDelivery(); } catch (error) { return deliveryReply(request, () => { throw error; }); }
        if (delivery) return deliveryReply(request, () => delivery.projection(sessionId, args[1]));
      }
      // Read what DSH actually holds before falling back to the fold: a fold that
      // never heard a `queue` frame reports an empty queue, which is how the
      // controller came to keep a 队列中 row for a message the agent had answered.
      if (sessionId !== '' && typeof capabilities.readSessionState === 'function' && typeof capabilities.projectionFromItems === 'function') {
        const state = await capabilities.readSessionState(sessionId);
        if (state !== null && state !== undefined) {
          return invokeResult(request, capabilities.projectionFromItems(sessionId, queueItemsFromInbox(state.inbox)));
        }
      }
      const project = capabilities.inputProjection;
      // The controller requests this on every session open, so it must answer
      // even when the queue is empty: an empty projection is the honest answer,
      // and refusing it would look like a broken composer.
      if (typeof project !== 'function' || sessionId === '') {
        return invokeResult(request, { sessionId, pendingQueue: [], steeringQueueClientIds: [] });
      }
      return invokeResult(request, project(sessionId));
    }

    // The aggregated remote file browser. One channel, dispatched by `op`; the
    // ops this Host does not serve answer `{ok:false, message}` the way the
    // reference host answers an op it does not know, rather than looking empty.
    if (channel === 'file-browser:remote-op') {
      const capabilities = capabilitiesNow();
      const op = args[0]?.op;
      // Whole-file access is Host-owned; never reinterpret nested SSH as local storage.
      if (op === 'caps' && typeof capabilities.fileUrl === 'function') {
        return invokeResult(request, { ok: true, fileRead: true });
      }
      if (op === 'fileUrl') {
        if (typeof capabilities.fileUrl !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This Host has no whole-file reader');
        return invokeResult(request, await capabilities.fileUrl({ workdir: args[0]?.workdir, relPath: args[0]?.relPath }));
      }
      // The two export ops are the controller's only way to *see* a picture that lives on
      // this machine — a file the agent drew, or any image in the file browser. The
      // reference controlled end answers `exportFileStart` immediately with a transfer id
      // and uploads to the shared staging area in the background, then `exportFileStatus`
      // reports `{state, key}`; the controller presign-gets the key itself. They are
      // Host-owned rather than browser-owned because the upload needs this runtime's
      // account session — the same reason attachment fetching lives there.
      if (op === 'exportFileStart' || op === 'exportFileStatus') {
        const start = capabilities.exportFileStart;
        const status = capabilities.exportFileStatus;
        if (op === 'exportFileStart') {
          if (typeof start !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot export files yet');
          const answered = await start({ workdir: args[0]?.workdir, relPath: args[0]?.relPath,
            ...(Object.hasOwn(args[0] ?? {}, 'maxBytes') ? { maxBytes: args[0].maxBytes } : {})
          }, { src: request.src, id: request.id });
          return answered?.ok === true ? invokeResult(request, answered) : invokeError(request, answered?.code ?? 'INTERNAL', answered?.message ?? 'file export failed');
        }
        if (typeof status !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot export files yet');
        const answered = status({ transferId: args[0]?.transferId }, { src: request.src, id: request.id });
        return answered?.ok === true ? invokeResult(request, answered) : invokeError(request, answered?.code ?? 'INTERNAL', answered?.message ?? 'unknown transfer');
      }
      const makeBrowser = capabilities.fileBrowser;
      const browser = typeof makeBrowser === 'function' ? makeBrowser() : undefined;
      if (browser === undefined || browser === null) {
        return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host composes no filesystem');
      }
      try {
        return invokeResult(request, await browser(args[0]));
      } catch (error) {
        return invokeError(request, 'THREW', String(error?.message ?? error));
      }
    }

    // The work-grouped history window. The controller only asks for these after seeing
    // `history-view-v1` in this Host's `link-accept`, and it falls back to the raw
    // `local-db:messages:list` window on any error it recognises as "no view here"
    // (`isHistoryViewUnavailable`), which is what `NOT_AVAILABLE` and
    // `UNSUPPORTED_CAPABILITY` both are.
    if (channel === 'local-db:messages:view' || channel === 'local-db:messages:work-details' || channel === 'local-db:messages:view-intent') {
      const view = capabilitiesNow().historyView;
      if (view === undefined || view === null) return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host projects no session history view');
      const sessionId = typeof args[0] === 'string' ? args[0] : '';
      const answered = channel === 'local-db:messages:view'
        ? await view.page(sessionId, args[1]?.before)
        : channel === 'local-db:messages:work-details'
          ? await view.details(sessionId, args[1], args[2]?.after)
          : await view.intent(sessionId, args[1]);
      // Pending bodies belong in InputProjection, never synthetic user history.
      return answered?.ok === true
        ? invokeResult(request, forClient(answered.result, request))
        : invokeError(request, answered?.code ?? 'INTERNAL', answered?.message ?? 'history view failed');
    }

    // A controller asking this machine for one of its files: an image the agent produced,
    // referenced by path in the transcript. The answer is a staged `ossKey` the controller
    // presign-gets itself, exactly as this Host does for a photo the phone uploaded.
    if (channel === 'device-link:file-peer') {
      const filePeer = capabilitiesNow().filePeer;
      if (typeof filePeer !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This Host has no file-peer transport');
      try {
        // Identity comes from the relay envelope, never from controller-supplied args.
        return invokeResult(request, await filePeer(request.src, args[0]));
      } catch (error) {
        const code = typeof error?.message === 'string' && /^(FILE_PEER_[A-Z_]+|INVALID_FILE_PEER_REQUEST|BAD_REQUEST|FORBIDDEN|NOT_FOUND|NOT_AVAILABLE)$/.test(error.message) ? error.message : 'FILE_PEER_FAILED';
        return invokeError(request, code, code);
      }
    }

    if (channel === 'device-link:media:fetch') {
      const fetchMedia = capabilitiesNow().fetchLocalMedia;
      if (typeof fetchMedia !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot serve local media');
      // `skipCache` is the controller saying "the object this key named is gone, stage it
      // again": it must bypass the staging cache rather than be dropped on the floor, or a
      // deleted object would stay unmaterializable for the cache's whole lifetime.
      const answered = await fetchMedia({
        url: args[0]?.url,
        thumbnail: args[0]?.thumbnail === true,
        skipCache: args[0]?.skipCache === true,
        ...(args[0]?.prepareOnly === true ? { prepareOnly: true } : {}),
      });
      return answered?.ok === true
        ? invokeResult(request, answered.result)
        : invokeError(request, answered?.code ?? 'INTERNAL', answered?.message ?? 'media fetch failed');
    }

    // File reads. Both families the controller uses take an absolute path and
    // answer in its own vocabulary; the translation lives in `host-files.js`.
    if (channel === 'fs:stat-path' || channel === 'fs:list-dir' || channel === 'text-file:read-preview') {
      const files = capabilitiesNow().files;
      if (typeof files !== 'function') return invokeError(request, 'NOT_AVAILABLE', 'This DSH Host cannot read files yet');
      const reader = files();
      const path = channel === 'text-file:read-preview'
        ? (args[0]?.filePath ?? args[0]?.path)
        : args[0]?.path;
      if (typeof path !== 'string' || path.trim() === '') return invokeError(request, 'BAD_REQUEST', `${channel} needs a path`);
      if (channel === 'fs:stat-path') return invokeResult(request, await reader.statPath(path));
      if (channel === 'fs:list-dir') return invokeResult(request, await reader.listDir(path));
      return invokeResult(request, await reader.readTextPreview(path));
    }

    // Fail closed and say so. The controller degrades on CHANNEL_NOT_ALLOWED.
    return invokeError(request);
  };
  handleInvoke.invalidateSessionRows = invalidateSessionRows;
  return handleInvoke;
}
