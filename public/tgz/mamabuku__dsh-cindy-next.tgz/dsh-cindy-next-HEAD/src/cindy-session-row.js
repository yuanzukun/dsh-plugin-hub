/**
 * Fold a DSH session row into the wire shape the Cindy controller stores.
 *
 * THE CONTRACT IS FLAT. `local-db:sessions:list` returns `RemoteSession[]` —
 * one flat session object per row, identity and status at the top level — and
 * `local-db:sessions:get` returns exactly one such object. The controller does
 * NOT unwrap anything: it hands the invoke result straight to
 * `remoteSessionStore.setDeviceSessions`, which de-dupes on `session.id`.
 *
 * `RemoteSessionListItem` (the `{ session: {...}, subtitle, detail, … }` view
 * model) is built *inside* the controller's own renderers
 * (`maker-shared/sessionList.ts`, `mobileHome.ts`) and must never cross the wire.
 * An earlier revision of this file emitted that view model, citing a
 * `mobileMakerTransport.listSessions()` that does not exist in the Cindy tree;
 * the result was a silently empty list — `id`, `status` and `deviceLinkDeviceId`
 * all arrived as `undefined`, so the controller's status filter, device filter,
 * and de-dupe key each discarded every row without raising anything.
 *
 * Only the wire shape belongs here. Anything the controller derives for display
 * (subtitle, detail, live activity, pending counts, schedule info) is its own
 * business and is deliberately absent.
 */

import { toCindyPermissionMode } from './host-models.js';

/** Cindy wire aliases for the one DSH harness; never use these to route a model. */
export function agentKindForModel({ model, provider, catalog } = {}) {
  let resolvedModel = typeof model === 'string' && model.trim() !== '' ? model.trim() : null;
  let resolvedProvider = typeof provider === 'string' && provider.trim() !== '' ? provider.trim() : null;
  if (resolvedModel === null && resolvedProvider === null) {
    const fallback = catalog?.default;
    resolvedModel = typeof fallback?.model === 'string' && fallback.model !== '' ? fallback.model : null;
    resolvedProvider = typeof fallback?.provider === 'string' && fallback.provider !== '' ? fallback.provider : null;
  } else if (resolvedProvider === null) {
    // The default route applies only to its own model. A model shared by two
    // providers cannot be classified without the session's source.
    if (catalog?.default?.model === resolvedModel) {
      resolvedProvider = catalog.default.provider ?? null;
    } else {
      const matches = (Array.isArray(catalog?.groups) ? catalog.groups : [])
        .filter((group) => Array.isArray(group?.models) && group.models.some((candidate) => candidate?.id === resolvedModel));
      if (matches.length === 1) resolvedProvider = matches[0].id;
    }
  }
  // Pi is reserved for a confirmed DeepSeek source, even if its model is unknown.
  if (typeof resolvedProvider === 'string' && /^deepseek(?:$|[-_./])/i.test(resolvedProvider)) return 'pi';
  if (resolvedModel === null || typeof resolvedProvider !== 'string' || resolvedProvider === '') return 'claude-code';
  if (/^(?:gpt(?:$|[-_./])|chatgpt(?:$|[-_./]))/i.test(resolvedModel)) return 'codex';
  return 'claude-code';
}
const DSH_MODEL = 'pi';
const DSH_EFFORT = 'default';
const DSH_PERMISSION_MODE = 'default';
const UNTITLED = 'Untitled DSH task';
const MAX_TITLE = 160;

/** Trim a title the way the local read model does, so both surfaces agree. */
function titleOf(value) {
  const title = typeof value === 'string' ? value.trim() : '';
  return title.slice(0, MAX_TITLE) || UNTITLED;
}

/**
 * Build one wire session row.
 * @param item - a source row: `{ id, title, running, updatedAt, createdAt, cwd, blank }`.
 * @param options - injectable clock and this Host's relay identity.
 * @returns the flat `RemoteSession` the controller stores.
 */
export function toCindySessionListRow(item, { now = () => new Date(), device, defaultModel, catalog } = {}) {
  const id = String(item.id);
  const updatedAt = item.updatedAt ?? now().toISOString();
  const createdAt = item.createdAt ?? updatedAt;
  const title = titleOf(item.title);
  const workingDir = typeof item.cwd === 'string' && item.cwd !== '' ? item.cwd : null;
  // What the *controller* groups by: the project's display path when the Host names
  // one, otherwise the real working directory. Kept separate from `workingDir` so a
  // display rename never rewrites the path other channels use for file access.
  const projectDir = typeof item.projectDir === 'string' && item.projectDir !== '' ? item.projectDir : null;

  return {
    id,
    title,
    // DSH projects ordinary user tasks, not Cindy Make/bot sessions. The phone's
    // entry gate requires explicit provenance before mounting the chat and its
    // local history cache; omitting it forces an extra remote lookup on re-entry.
    // This is task provenance, independent of the model's providerId below.
    source: 'desktop',
    createdAt,
    updatedAt,
    // `'active' | 'archived' | 'deleted'`; the controller's default status filter
    // is `'active'`, so this field decides whether a row is visible at all.
    //
    // Native DSH archives and legacy controller metadata are folded together
    // before reaching this wire adapter. A row with no status is active; delete
    // remains a Host-only hide and never destroys DSH history.
    status: item.status === 'archived' || item.status === 'deleted' ? item.status : 'active',
    agentKind: agentKindForModel({ model: item.model ?? defaultModel, provider: item.providerId, catalog }),
    // The controller looks the current model up by id in the catalog it fetched
    // (`availableModels.find(item => item.id === session.model)`), so a
    // placeholder here leaves the picker with nothing selected even when the
    // catalog is right. The session's own selection wins; the Host default is
    // the honest fallback while it is unknown.
    model: typeof item.model === 'string' && item.model !== ''
      ? item.model
      : (typeof defaultModel === 'string' && defaultModel !== '' ? defaultModel : DSH_MODEL),
    // The source that serves that model, when the session recorded one. The
    // controller keeps `providerId` beside the model and derives its new-chat draft
    // runtime from the most recent session (`pickRecentSessionRuntime`), so a row that
    // drops it hands the next conversation a model with no source. Absent — not null —
    // when nothing recorded one: the controller reads a missing field as "the Host's
    // default route", which is exactly what such a session runs.
    ...(typeof item.providerId === 'string' && item.providerId !== '' ? { providerId: item.providerId } : {}),
    // The session's own effort, which DSH carries as part of its model
    // selection. The placeholder is only for a session that has not chosen yet:
    // answering "default" after a successful `maker:set-effort` would make the
    // write look like it never landed.
    effort: typeof item.effort === 'string' && item.effort !== '' ? item.effort : DSH_EFFORT,
    // The session's own preset when the list carried the `permissions`
    // projection, so the composer shows the mode actually in force rather than a
    // placeholder that no picker entry matches.
    permissionMode: typeof item.permissionMode === 'string' && item.permissionMode !== ''
      ? toCindyPermissionMode(item.permissionMode)
      : DSH_PERMISSION_MODE,
    fastMode: false,
    workingDir,
    ...(projectDir === null ? {} : { projectDir }),
    // The controller groups by this: `workspaceKind === 'dialogue' || !(projectDir ?? workingDir)`
    // puts a row in the "chats" bucket, everything else under its project.
    workspaceKind: workingDir === null && projectDir === null ? 'dialogue' : 'project',
    // A blank session has no user turn yet; the controller shows it as a draft.
    preview: null,
    userSendAt: typeof item.userSendAt === 'string' && item.userSendAt !== '' ? item.userSendAt : null,
    _count: Number.isFinite(item.messageCount) && item.messageCount >= 0
      ? { messages: Math.floor(item.messageCount) }
      : null,
    // Not part of the stored row's contract, but harmless and honest: the
    // controller reads running state from `maker:list-active`, not from here.
    running: item.running === true,
    ...(Object.hasOwn(item, 'activeTurnStartedAt') ? { activeTurnStartedAt: item.activeTurnStartedAt, interruptedTurnStartedAt: item.interruptedTurnStartedAt, lastTurnEndedAt: item.lastTurnEndedAt, clearedAt: item.clearedAt ?? null } : {}),
    // Which device this row came from. The controller's home aggregates sessions
    // from every linked computer and filters with
    // `canonicalDeviceId ?? deviceLinkDeviceId === selectedDeviceId`
    // (`maker-shared/mobileHome.ts`), so a row that names neither is dropped the
    // moment the user selects this Host — which is the only way to see it.
    deviceLinkDeviceId: device?.deviceId ?? null,
    deviceLinkDeviceName: device?.deviceName ?? null,
    // Preserve a known unpin (including native archival). A missing field is
    // 'keep what I have' on a write reply, so dropping explicit null can retain
    // the controller's old pin even though DSH has archived the session.
    ...(item.pinnedAt === null ? { pinnedAt: null }
      : typeof item.pinnedAt === 'string' && item.pinnedAt !== '' ? { pinnedAt: item.pinnedAt } : {}),
  };
}

/**
 * Fold a whole listing.
 * @param items - source rows.
 * @param options - injectable clock and this Host's relay identity.
 * @returns the flat array the controller stores.
 */
export function toCindySessionList(items, options = {}) {
  const list = Array.isArray(items) ? items : [];
  return list.map((item) => toCindySessionListRow(item, options));
}

/**
 * Build the `maker:list-active` answer.
 *
 * This channel has its own shape — `[{ sessionId, isTurnRunning }]` — and is
 * neither a session row nor a list item. Answering it with session rows makes
 * the controller skip every entry, which shows up only as a running badge that
 * never lights up.
 * @param items - source rows.
 * @returns one entry per session that is currently in a turn.
 */
export function toCindyActiveSessions(items) {
  const list = Array.isArray(items) ? items : [];
  return list
    .filter((item) => item?.running === true)
    .map((item) => ({ sessionId: String(item.id), isTurnRunning: true }));
}
