window.__ModuleLoader__.load({ id: 'dsh-tool-ssh', factory: (require) => {
  const module = { exports: {} }
  const exports = module.exports
  const React = require('react')
  const ReactDOM = require('react-dom')
  const { useEffect, useRef, useState, useCallback } = React

  const BASE = '/plugins/dsh-tool-ssh'
  const UI_VERSION = 'v20'
  const BUFFER_CAP = 300000 // chars of retained terminal transcript per tab

  // ---------------------------------------------------------------------
  // Widen the conversation content column while the SSH view is active.
  // dsh web's ConversationRoot defines --dsh-chat-content-width: 748px and
  // centers the content column; our conversation.view tab is rendered inside
  // that same constrained column, so internal flex/width:100% cannot help.
  // Community-proven fix: inject a page-level <style> that overrides the
  // variable and max-width, scoped via :has() to our own stable marker so
  // the normal chat view is untouched. The <style> is removed on unload.
  // ---------------------------------------------------------------------
  const WIDEN_CSS = `
[data-phase]:has([data-dsh-ssh-view]) {
  --dsh-chat-content-width: 100% !important;
  --dsh-composer-card-max-width: 100% !important;
}
[data-phase]:has([data-dsh-ssh-view]) [data-slot="conversation.session"],
[data-phase]:has([data-dsh-ssh-view]) [data-slot="conversation.session"] > * {
  max-width: none !important;
}`
  let widenStyleEl = null
  function injectWidenStyle() {
    if (widenStyleEl) return widenStyleEl
    widenStyleEl = document.createElement('style')
    widenStyleEl.setAttribute('data-dsh-tool-ssh-widen', '')
    widenStyleEl.textContent = WIDEN_CSS
    document.head.appendChild(widenStyleEl)
    return widenStyleEl
  }
  // Inject as early as possible (module load), before the view can mount.
  if (typeof document !== 'undefined') injectWidenStyle()

  // ---------------------------------------------------------------------
  // tiny api helper
  // ---------------------------------------------------------------------
  async function api(path, options) {
    const res = await fetch(BASE + path, options)
    if (!res.ok) {
      let msg = `HTTP ${res.status}`
      try { const j = await res.json(); if (j && j.error) msg = j.error } catch { /* ignore */ }
      throw new Error(msg)
    }
    return res
  }

  function formatSize(n) {
    if (n === null || n === undefined) return '-'
    if (n < 1024) return `${n} B`
    if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
    if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`
    return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`
  }

  function formatTime(ts) {
    if (!ts) return '-'
    const d = new Date(ts * 1000)
    const p = (v) => String(v).padStart(2, '0')
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
  }

  function formatMode(mode) {
    if (typeof mode !== 'number' || mode === 0) return '----------'
    const typeBits = mode & 0o170000
    let t = '-'
    if (typeBits === 0o040000) t = 'd'
    else if (typeBits === 0o120000) t = 'l'
    const perms = ['r','w','x','r','w','x','r','w','x']
    let s = t
    for (let i = 8; i >= 0; i--) s += (mode & (1 << i)) ? perms[8 - i] : '-'
    return s
  }

  // ---------------------------------------------------------------------
  // module-scope state: file pane + terminal tab registry. The registry
  // lives at module level so transcripts survive view switches (the view
  // component unmounts when the user leaves the tab, but the tabs+content
  // stay in memory).
  // ---------------------------------------------------------------------
  let showFiles = true
  let terminalSeq = 0
  const terminalTabs = [] // {id, connection, title, buffer, status}
  let activeTerminalId = null
  let connectOpen = false // manual-connect modal visibility
  let pendingConnection = null // profile name to auto-select on next SSH view mount
  const uiListeners = new Set()
  function setFiles(next) { showFiles = next; for (const l of uiListeners) l() }
  function notifyTabs() { for (const l of uiListeners) l() }
  function setConnectOpen(next) { connectOpen = next; for (const l of uiListeners) l() }
  function subscribeUi(fn) { uiListeners.add(fn); return () => uiListeners.delete(fn) }

  // ---------------------------------------------------------------------
  // Saved-connection dropdown state (module scope). One live list is shared
  // by the SSH view, the manual-connect modal and the delete confirmation,
  // so a profile added or removed anywhere is reflected immediately — no
  // page switch needed. refreshConnections() pulls the list from the host
  // and notifies subscribers only when it actually changed; a light poll
  // (active only while the SSH view is open and the page is visible) also
  // picks up profiles saved from the chat (ssh_connections action=add).
  // ---------------------------------------------------------------------
  let savedConnections = []            // [{name, host, port, username}]
  let selectedConnection = ''          // profile name shown/selected in the dropdown
  let connectionsSig = ''              // signature of the last known list
  let connectionFetch = null           // in-flight fetch (dedupe)
  let suppressAutoOpen = false         // one-shot: no auto tab right after a delete
  let connPollTimer = null
  let connPollCleanup = null
  const CONNECTION_POLL_MS = 3000

  function connectionsSignature(list) {
    return list.map((c) => `${c.name}\u0000${c.host}\u0000${c.port}\u0000${c.username}`).join('\u0001')
  }

  function refreshConnections() {
    if (connectionFetch) return connectionFetch
    connectionFetch = api('/connections')
      .then((res) => res.json())
      .then((j) => {
        savedConnections = Array.isArray(j.connections) ? j.connections : []
        const sig = connectionsSignature(savedConnections)
        if (sig !== connectionsSig) {
          connectionsSig = sig
          notifyTabs()
        }
      })
      .catch(() => { /* keep the last known list */ })
      .finally(() => { connectionFetch = null })
    return connectionFetch
  }

  /** Pick which profile the dropdown should show after a refresh. */
  function settleSelection() {
    const prefer = pendingConnection
    pendingConnection = null
    let next = selectedConnection
    if (prefer && savedConnections.some((c) => c.name === prefer)) next = prefer
    else if (!savedConnections.some((c) => c.name === next)) next = savedConnections.length ? savedConnections[0].name : ''
    if (next !== selectedConnection) {
      selectedConnection = next
      notifyTabs()
      return true
    }
    return false
  }

  function startConnPolling() {
    stopConnPolling()
    const tick = () => {
      if (typeof document === 'undefined' || document.visibilityState === 'visible') void refreshConnections()
    }
    connPollTimer = setInterval(tick, CONNECTION_POLL_MS)
    const onVisible = () => { if (document.visibilityState === 'visible') void refreshConnections() }
    document.addEventListener('visibilitychange', onVisible)
    connPollCleanup = () => document.removeEventListener('visibilitychange', onVisible)
  }

  function stopConnPolling() {
    if (connPollTimer) { clearInterval(connPollTimer); connPollTimer = null }
    if (connPollCleanup) { connPollCleanup(); connPollCleanup = null }
  }

  // Terminal font size (px), persisted across reloads.
  const FONT_MIN = 8
  const FONT_MAX = 32
  let termFontSize = Number(localStorage.getItem('dsh-ssh-font-size')) || 13
  if (!(termFontSize >= FONT_MIN && termFontSize <= FONT_MAX)) termFontSize = 13
  function setTermFontSize(next) {
    termFontSize = Math.max(FONT_MIN, Math.min(FONT_MAX, next))
    try { localStorage.setItem('dsh-ssh-font-size', String(termFontSize)) } catch { /* ignore */ }
    for (const l of uiListeners) l()
  }

  /** Programmatically switch the conversation view to the SSH tab by
   * clicking its tab button (which calls the framework's own setView). */
  function switchToSshView() {
    const btn = [...document.querySelectorAll('button')].find((b) => b.textContent && b.textContent.includes('SSH \u8FDC\u7A0B\u63A7\u5236'))
    if (btn) btn.click()
    else console.warn('[dsh-tool-ssh] SSH view tab not found to switch to')
  }

  function addTerminal(connection) {
    const seq = ++terminalSeq
    const id = `t${seq}-${Math.random().toString(36).slice(2, 7)}`
    terminalTabs.push({ id, connection, title: `${connection || 'ssh'} #${seq}`, sessionId: null, status: '' })
    activeTerminalId = id
    notifyTabs()
  }
  function closeTerminal(id) {
    const i = terminalTabs.findIndex((t) => t.id === id)
    if (i < 0) return
    const tab = terminalTabs[i]
    // Closing the tab tears down the host-side SSH session for real.
    if (tab.sessionId) {
      void fetch(`${BASE}/term/close`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ id: tab.sessionId }),
      }).catch(() => {})
      tab.sessionId = null
    }
    terminalTabs.splice(i, 1)
    if (activeTerminalId === id) {
      activeTerminalId = terminalTabs.length ? terminalTabs[Math.min(i, terminalTabs.length - 1)].id : null
    }
    notifyTabs()
  }

  // ---------------------------------------------------------------------
  // xterm loading (vendored assets served by the plugin)
  // @xterm/xterm + @xterm/addon-canvas UMD copies exports onto globalThis:
  // window.Terminal and window.CanvasAddon (canvas renderer = much faster
  // than the default DOM renderer).
  // ---------------------------------------------------------------------
  let xtermPromise = null
  function loadXterm() {
    if (!xtermPromise) {
      xtermPromise = new Promise((resolve, reject) => {
        const link = document.createElement('link')
        link.rel = 'stylesheet'
        link.href = `${BASE}/assets/xterm.css`
        document.head.appendChild(link)
        const s = document.createElement('script')
        s.src = `${BASE}/assets/xterm.js`
        s.onload = () => {
          const c = document.createElement('script')
          c.src = `${BASE}/assets/addon-canvas.js`
          c.onload = () => (window.Terminal ? resolve() : reject(new Error('xterm global missing')))
          c.onerror = () => (window.Terminal ? resolve() : reject(new Error('xterm global missing')))
          document.head.appendChild(c)
        }
        s.onerror = () => reject(new Error('failed to load xterm.js'))
        document.head.appendChild(s)
      })
    }
    return xtermPromise
  }

  // ---------------------------------------------------------------------
  // SSE reader over fetch (gives us 404 detection + clean cancellation).
  // Host replays the retained transcript first, then live `data` events.
  // ---------------------------------------------------------------------
  async function connectSse(id, handlers, readerRef) {
    const res = await fetch(`${BASE}/term/stream?id=${encodeURIComponent(id)}`)
    if (!res.ok || !res.body) {
      handlers.onMissing && handlers.onMissing()
      return
    }
    const reader = res.body.getReader()
    if (readerRef) readerRef.current = reader
    const decoder = new TextDecoder()
    let buf = ''
    try {
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        buf += decoder.decode(value, { stream: true })
        let idx
        while ((idx = buf.indexOf('\n\n')) >= 0) {
          const frame = buf.slice(0, idx)
          buf = buf.slice(idx + 2)
          const ev = /^event: (\S+)/m.exec(frame)
          const data = /^data: (.+)$/m.exec(frame)
          if (data) {
            try { handlers.onEvent && handlers.onEvent(ev ? ev[1] : 'data', JSON.parse(data[1])) } catch { /* ignore */ }
          }
        }
      }
    } finally {
      if (readerRef && readerRef.current === reader) readerRef.current = null
    }
    handlers.onDone && handlers.onDone()
  }

  // ---------------------------------------------------------------------
  // Self-contained terminal fit: size the xterm to fill its container by
  // measuring the rendered cell size. No addon dependency.
  // ---------------------------------------------------------------------
  function fitTerminal(term, container) {
    if (!term || !container) return false
    const width = container.clientWidth
    const height = container.clientHeight
    if (width < 60 || height < 60) return false // hidden or not laid out yet
    const el = term.element
    let cellW = 8
    let cellH = 16
    if (el) {
      // Canvas renderer: the render canvas has an explicit CSS size equal to
      // cols*cellWidth x rows*cellHeight, so clientWidth/cols gives the cell
      // size exactly. (Canvas class is xterm-text-layer etc., so match any.)
      const canvas = el.querySelector('canvas')
      if (canvas && term.cols > 0 && term.rows > 0) {
        const cw = canvas.clientWidth / term.cols
        const ch = canvas.clientHeight / term.rows
        if (cw > 1 && ch > 1) { cellW = cw; cellH = ch }
      } else {
        // DOM renderer: measure one rendered row.
        const rowEl = el.querySelector('.xterm-rows > div')
        if (rowEl) {
          const rh = rowEl.offsetHeight
          const rw = rowEl.offsetWidth
          if (rh > 0) cellH = rh
          if (rw > 0 && term.cols > 0) cellW = rw / term.cols
        }
      }
    }
    const cols = Math.max(2, Math.floor((width - 4) / cellW))
    const rows = Math.max(2, Math.floor((height - 4) / cellH))
    if (cols !== term.cols || rows !== term.rows) {
      try { term.resize(cols, rows); return true } catch { /* ignore */ }
    }
    return false
  }

  // ---------------------------------------------------------------------
  // File browser (left pane)
  // ---------------------------------------------------------------------
  function FileBrowser({ connection }) {
    const [path, setPath] = useState('/')
    const [entries, setEntries] = useState(null)
    const [error, setError] = useState(null)
    const [busy, setBusy] = useState(false)
    const [uploading, setUploading] = useState(false)
    const fileRef = useRef(null)

    const load = useCallback(async (p) => {
      setBusy(true)
      setError(null)
      try {
        const res = await api(`/fs/list?connection=${encodeURIComponent(connection)}&path=${encodeURIComponent(p)}`)
        const j = await res.json()
        setEntries(j.entries || [])
        setPath(j.path)
      } catch (e) {
        setError(e.message)
        setEntries(null)
      } finally {
        setBusy(false)
      }
    }, [connection])

    useEffect(() => { load('/') }, [load])

    const enter = (entry) => { if (entry.type === 'dir') void load(path === '/' ? `/${entry.name}` : `${path}/${entry.name}`) }
    const up = () => {
      const trimmed = path.replace(/\/+$/, '')
      const idx = trimmed.lastIndexOf('/')
      void load(idx <= 0 ? '/' : trimmed.slice(0, idx))
    }
    const download = async (entry) => {
      const url = `${BASE}/fs/download?connection=${encodeURIComponent(connection)}&path=${encodeURIComponent(path === '/' ? `/${entry.name}` : `${path}/${entry.name}`)}`
      const a = document.createElement('a')
      a.href = url
      a.download = entry.name
      document.body.appendChild(a)
      a.click()
      a.remove()
    }
    const onUpload = async (event) => {
      const file = event.target.files && event.target.files[0]
      if (!file) return
      setUploading(true)
      try {
        const remote = path === '/' ? `/${file.name}` : `${path}/${file.name}`
        const res = await api(`/fs/upload?connection=${encodeURIComponent(connection)}&path=${encodeURIComponent(remote)}`, { method: 'POST', body: file })
        await res.json()
        void load(path)
      } catch (e) {
        setError(e.message)
      } finally {
        setUploading(false)
        if (fileRef.current) fileRef.current.value = ''
      }
    }

    const toolBtn = { padding: '3px 7px', borderRadius: 5, border: '1px solid rgba(128,128,128,0.4)', background: 'transparent', color: 'inherit', cursor: 'pointer', fontSize: 12 }
    const rowStyle = { display: 'flex', alignItems: 'center', padding: '3px 6px', cursor: 'pointer', borderBottom: '1px solid rgba(128,128,128,0.12)', gap: 8, fontSize: 12 }

    return React.createElement('div', { style: { display: 'flex', flexDirection: 'column', height: '100%', minWidth: 0, flex: 1, width: '100%' } },
      React.createElement('div', { style: { display: 'flex', gap: 5, padding: 6, alignItems: 'center', borderBottom: '1px solid rgba(128,128,128,0.25)', flexWrap: 'wrap' } },
        React.createElement('button', { onClick: up, disabled: path === '/', style: toolBtn, title: '\u4E0A\u7EA7' }, '\u2191'),
        React.createElement('input', { value: path, readOnly: true, style: { flex: 1, minWidth: 60, padding: '4px 6px', borderRadius: 5, border: '1px solid rgba(128,128,128,0.4)', background: 'transparent', color: 'inherit', fontFamily: 'monospace', fontSize: 12 } }),
        React.createElement('button', { onClick: () => void load(path), disabled: busy, style: toolBtn, title: '\u5237\u65B0' }, '\u21BB'),
        React.createElement('button', { onClick: () => fileRef.current && fileRef.current.click(), disabled: uploading, style: toolBtn, title: '\u4E0A\u4F20\u6587\u4EF6\u5230\u5F53\u524D\u76EE\u5F55' }, uploading ? '\u4E0A\u4F20\u4E2D' : '\u2191 \u4E0A\u4F20'),
        React.createElement('input', { ref: fileRef, type: 'file', style: { display: 'none' }, onChange: onUpload }),
      ),
      error ? React.createElement('div', { style: { padding: 8, color: '#e06c75', fontSize: 12 } }, error) : null,
      React.createElement('div', { style: { flex: 1, overflow: 'auto' } },
        entries === null && !error ? React.createElement('div', { style: { padding: 10, opacity: 0.7, fontSize: 12 } }, busy ? '\u52A0\u8F7D\u4E2D...' : '\u65E0\u6570\u636E') : null,
        entries ? entries.map((entry) =>
          React.createElement('div', { key: entry.name, style: rowStyle, onClick: () => enter(entry), onDoubleClick: () => { if (entry.type !== 'dir') void download(entry) }, title: entry.type === 'dir' ? entry.name : `${entry.name}  (${formatSize(entry.size)})\n\u53CC\u51FB\u4E0B\u8F7D` },
            React.createElement('span', { style: { width: 18, flexShrink: 0 } }, entry.type === 'dir' ? '\uD83D\uDCC1' : '\uD83D\uDCC4'),
            React.createElement('span', { style: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } }, entry.name),
            React.createElement('span', { style: { width: 52, flexShrink: 0, textAlign: 'right', opacity: 0.75 } }, entry.type === 'dir' ? '-' : formatSize(entry.size)),
            entry.type !== 'dir' ? React.createElement('button', { style: toolBtn, onClick: (e) => { e.stopPropagation(); void download(entry) }, title: '\u4E0B\u8F7D' }, '\u2193') : null,
          ),
        ) : null,
        entries && entries.length === 0 ? React.createElement('div', { style: { padding: 10, opacity: 0.6, fontSize: 12 } }, '(\u7A7A\u76EE\u5F55)') : null,
      ),
    )
  }

  // ---------------------------------------------------------------------
  // Terminal pane for one tab. The SSH session lives on the HOST and
  // survives view switches: on remount we attach to the same session id
  // (host replays the retained transcript), so the remote shell keeps
  // running — no reconnect, no content loss. The session is only torn down
  // when the user closes the tab (✕) or the GUI restarts.
  // ---------------------------------------------------------------------
  function TerminalPane({ tab }) {
    const hostRef = useRef(null)
    const termRef = useRef(null)
    const readerRef = useRef(null)
    const idRef = useRef(null)
    const inputTimerRef = useRef(null)
    const inputQueueRef = useRef('')
    const [status, setStatus] = useState(tab.status || '\u8FDE\u63A5\u4E2D...')
    const [dims, setDims] = useState('')

    useEffect(() => {
      let disposed = false
      let resizeObserver = null
      let onWinResize = null
      let pollTimer = null
      let offFontUi = null
      let rafPending = false
      const setStatusBoth = (s) => { tab.status = s; if (!disposed) setStatus(s) }

      async function start() {
        setStatusBoth('\u8FDE\u63A5\u4E2D...')
        try {
          await loadXterm()
          if (disposed || !hostRef.current) return
          const term = new window.Terminal({
            cursorBlink: true,
            fontSize: termFontSize,
            fontFamily: 'Menlo, Consolas, "Courier New", monospace',
            scrollback: 5000,
            cols: 100,
            rows: 30,
            theme: { background: '#101418', foreground: '#d4d4d4' },
          })
          if (window.CanvasAddon && window.CanvasAddon.CanvasAddon) {
            try { term.loadAddon(new window.CanvasAddon.CanvasAddon()) } catch { /* ignore */ }
          }
          termRef.current = term
          term.open(hostRef.current)

          // Fit BEFORE the stream connects, so the replayed transcript
          // renders at the final size (no reflow / vertical jitter).
          // Converging fit + polling: layout may settle late (the view can
          // mount while hidden, the canvas needs frames to size up), so we
          // keep refitting until the grid matches the container exactly.
          const doFit = () => {
            if (disposed || !term || !hostRef.current) return
            try { fitTerminal(term, hostRef.current) } catch { /* ignore */ }
          }
          const convergeFit = (passesLeft) => {
            if (disposed) return
            const changed = fitTerminal(term, hostRef.current)
            if (changed && passesLeft > 0) {
              requestAnimationFrame(() => convergeFit(passesLeft - 1))
            }
          }
          const refit = () => {
            if (rafPending) return
            rafPending = true
            requestAnimationFrame(() => { rafPending = false; convergeFit(6) })
          }
          requestAnimationFrame(() => { try { refit() } catch { /* ignore */ } })
          setTimeout(() => { try { refit() } catch { /* ignore */ } }, 150)
          setTimeout(() => { try { refit() } catch { /* ignore */ } }, 500)
          // Polling fallback: refit every 600ms for the first ~7s, so a late
          // layout (hidden→shown, pane width change) is always caught.
          let pollTicks = 0
          pollTimer = setInterval(() => {
            pollTicks += 1
            doFit()
            if (pollTicks >= 12) clearInterval(pollTimer)
          }, 600)
          resizeObserver = new ResizeObserver(() => { try { refit() } catch { /* ignore */ } })
          resizeObserver.observe(hostRef.current)
          onWinResize = () => { try { refit() } catch { /* ignore */ } }
          window.addEventListener('resize', onWinResize)

          // Apply live font-size changes (toolbar A-/A+) to this terminal.
          offFontUi = subscribeUi(() => {
            if (disposed || !termRef.current) return
            try { termRef.current.options.fontSize = termFontSize } catch { /* ignore */ }
            refit()
          })

          // Throttled input: batch keystrokes into one POST per 30ms.
          const flushInput = () => {
            inputTimerRef.current = null
            const payload = inputQueueRef.current
            inputQueueRef.current = ''
            const idNow = idRef.current
            if (!payload || !idNow) return
            void fetch(`${BASE}/term/input`, {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({ id: idNow, data: payload }),
            }).catch(() => {})
          }
          // Terminal-generated replies (OSC color replies `ESC]...`, private
          // CSI replies `ESC[?`, XTVERSION `ESC[>`) must never be forwarded
          // to the remote shell as user input — doing so makes the remote
          // echo them back and grow an infinite loop on every view switch.
          const isTerminalReply = (data) => /^\x1b\]/.test(data) || /^\x1b\[\?/.test(data) || /^\x1b\[>/.test(data)
          term.onData((data) => {
            if (isTerminalReply(data)) return
            inputQueueRef.current += data
            if (!inputTimerRef.current) inputTimerRef.current = setTimeout(flushInput, 30)
          })
          term.onResize(({ cols, rows }) => {
            setDims(`${cols}\u00D7${rows}`)
            const idNow = idRef.current
            if (!idNow) return
            void fetch(`${BASE}/term/resize`, {
              method: 'POST',
              headers: { 'content-type': 'application/json' },
              body: JSON.stringify({ id: idNow, cols, rows }),
            }).catch(() => {})
          })

          // Attach to the existing host session, or create one on first mount.
          const loop = async (attempt) => {
            if (disposed) return
            let id = tab.sessionId
            if (!id) {
              try {
                const res = await api('/term/open', {
                  method: 'POST',
                  headers: { 'content-type': 'application/json' },
                  body: JSON.stringify({ connection: tab.connection, cols: term.cols, rows: term.rows }),
                })
                const j = await res.json()
                id = j.id
                tab.sessionId = id
              } catch (e) {
                if (!disposed) setStatusBoth(`\u8FDE\u63A5\u5931\u8D25: ${e.message}`)
                return
              }
            }
            idRef.current = id
            if (disposed) return
            try {
              await connectSse(id, {
                onMissing: () => {
                  // Session died on the host (remote shell exited / GUI
                  // restarted): open a fresh one and retry once.
                  if (disposed || attempt >= 2) return
                  tab.sessionId = null
                  setStatusBoth('\u91CD\u65B0\u8FDE\u63A5...')
                  void loop(attempt + 1)
                },
                onEvent: (event, payload) => {
                  if (event === 'data' && !disposed) {
                    // Strip terminal QUERY sequences (DA `CSI c`, XTVERSION
                    // `CSI >0q`, OSC color queries `ESC]N;?`) from replayed
                    // and live output: a freshly created xterm would answer
                    // them, and those answers must not reach the remote.
                    let text = payload.data || ''
                    text = text.replace(/\x1b\[[0-9;]*c/g, '').replace(/\x1b\[>[0-9;]*q/g, '').replace(/\x1b\][0-9]+;\?(\x07|\x1b\\)/g, '')
                    if (text) { try { term.write(text) } catch { /* ignore */ } }
                  } else if (event === 'closed' && !disposed) {
                    setStatusBoth('\u5DF2\u5173\u95ED')
                  }
                },
                onDone: () => {},
              }, readerRef)
            } catch (e) {
              if (!disposed) setStatusBoth(`\u8FDE\u63A5\u4E2D\u65AD: ${e.message}`)
            }
          }
          void loop(0)
          term.focus()
          setStatusBoth('\u5DF2\u8FDE\u63A5 \u2014 \u76F4\u63A5\u8F93\u5165\u547D\u4EE4')
        } catch (e) {
          if (!disposed) setStatusBoth(`\u8FDE\u63A5\u5931\u8D25: ${e.message}`)
        }
      }
      void start()
      return () => {
        disposed = true
        offFontUi && offFontUi()
        if (inputTimerRef.current) { clearTimeout(inputTimerRef.current); inputTimerRef.current = null }
        if (pollTimer) { clearInterval(pollTimer); pollTimer = null }
        resizeObserver?.disconnect()
        if (onWinResize) window.removeEventListener('resize', onWinResize)
        // Cancel the stream read (host detaches the SSE writer) but keep the
        // SSH session alive so switching back resumes the same shell.
        readerRef.current && void readerRef.current.cancel().catch(() => {})
        readerRef.current = null
        termRef.current?.dispose()
        termRef.current = null
      }
    }, [tab])

    return React.createElement('div', { style: { display: 'flex', flexDirection: 'column', height: '100%', minWidth: 0, flex: 1, width: '100%' } },
      React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 8, padding: '3px 8px', opacity: 0.8, fontSize: 11, borderBottom: '1px solid rgba(128,128,128,0.2)', whiteSpace: 'nowrap', overflow: 'hidden' } },
        React.createElement('span', { style: { flex: 1, overflow: 'hidden', textOverflow: 'ellipsis' } }, status),
        dims ? React.createElement('span', { style: { opacity: 0.6, fontFamily: 'monospace' } }, dims) : null,
      ),
      React.createElement('div', { ref: hostRef, style: { flex: 1, overflow: 'hidden', padding: 4, background: '#101418' } }),
    )
  }

  // ---------------------------------------------------------------------
  // Draggable splitter between the file pane and the terminal
  // ---------------------------------------------------------------------
  function Splitter({ onDrag }) {
    const startDrag = (e) => {
      e.preventDefault()
      const move = (ev) => onDrag(ev.clientX)
      const up = () => {
        document.removeEventListener('mousemove', move)
        document.removeEventListener('mouseup', up)
        document.body.style.cursor = ''
        document.body.style.userSelect = ''
      }
      document.addEventListener('mousemove', move)
      document.addEventListener('mouseup', up)
      document.body.style.cursor = 'col-resize'
      document.body.style.userSelect = 'none'
    }
    return React.createElement('div', {
      onMouseDown: startDrag,
      style: { width: 6, flexShrink: 0, cursor: 'col-resize', background: 'rgba(128,128,128,0.35)', margin: 0 },
    })
  }

  // ---------------------------------------------------------------------
  // Full-page SSH console view (conversation.view slot = a top tab)
  // ---------------------------------------------------------------------
  function SshConsoleView() {
    const [filesVisible, setFilesVisibleState] = useState(showFiles)
    const [filesWidth, setFilesWidth] = useState(300)
    const [termWidth, setTermWidth] = useState(null) // explicit terminal width (null = fill)
    const [tabsVersion, setTabsVersion] = useState(0)
    const [confirmDelete, setConfirmDelete] = useState(null)   // profile name awaiting deletion
    const [deleteBusy, setDeleteBusy] = useState(false)
    const [deleteError, setDeleteError] = useState(null)
    const rootRef = useRef(null)

    // Re-render whenever any module-level UI state changes (files pane,
    // terminal tabs, saved-connection list / selection, font size …).
    useEffect(() => subscribeUi(() => { setFilesVisibleState(showFiles); setTabsVersion((v) => v + 1) }), [])

    // Load the saved-connection list whenever the SSH view opens, resolve the
    // selected profile, and keep polling while the view is mounted so a
    // profile added from the chat (ssh_connections action=add) shows up in
    // the dropdown automatically — no page switch needed.
    useEffect(() => {
      let active = true
      void refreshConnections().then(() => { if (active) settleSelection() })
      startConnPolling()
      return () => { active = false; stopConnPolling() }
    }, [])

    // After every list refresh: if nothing is selected but profiles exist
    // (e.g. an agent added one while the view sat empty), select the first;
    // if the selected profile vanished (deleted here or from the chat),
    // fall back to the first remaining one instead of showing a dead entry.
    useEffect(() => {
      if (selectedConnection && !savedConnections.some((c) => c.name === selectedConnection)) settleSelection()
      else if (!selectedConnection && savedConnections.length > 0) settleSelection()
    }, [tabsVersion])

    // Auto-create a terminal tab once a profile is selected and no tab is
    // open. Runs again whenever the selection changes with an empty tab bar
    // (the original "select a host → open a shell" behaviour). A delete sets
    // suppressAutoOpen so the view never silently dials the next host.
    useEffect(() => {
      if (!selectedConnection || terminalTabs.length > 0) return
      if (suppressAutoOpen) { suppressAutoOpen = false; return }
      addTerminal(selectedConnection)
    }, [selectedConnection])

    const deleteProfile = async () => {
      const name = confirmDelete
      if (!name) return
      setDeleteBusy(true)
      setDeleteError(null)
      try {
        const res = await api(`/connections?name=${encodeURIComponent(name)}`, { method: 'DELETE' })
        await res.json()
        // Close any open terminal tab(s) bound to the removed profile (their
        // host-side SSH sessions are torn down too).
        for (const t of [...terminalTabs]) {
          if (t.connection === name) closeTerminal(t.id)
        }
        // Drop it from the local list immediately, then reconcile with the
        // host so the dropdown never shows a deleted profile again.
        savedConnections = savedConnections.filter((c) => c.name !== name)
        connectionsSig = connectionsSignature(savedConnections)
        if (selectedConnection === name) {
          suppressAutoOpen = terminalTabs.length === 0
          selectedConnection = savedConnections.length ? savedConnections[0].name : ''
        }
        notifyTabs()
        void refreshConnections()
        setConfirmDelete(null)
      } catch (e) {
        setDeleteError(e.message)
      } finally {
        setDeleteBusy(false)
      }
    }

    // termWidth === null means "fill the remaining space". The right-edge
    // splitter is the terminal's OWN resize handle: drag left to shrink,
    // drag right to grow, drag to the far right to return to fill mode.
    const termLeft = filesVisible ? filesWidth + 6 : 0
    const onDragFiles = (clientX) => {
      const rect = rootRef.current && rootRef.current.getBoundingClientRect()
      if (!rect) return
      const max = rect.width - termLeft - 320
      setFilesWidth(Math.max(160, Math.min(clientX - rect.left, max)))
    }
    const onDragTerm = (clientX) => {
      const rect = rootRef.current && rootRef.current.getBoundingClientRect()
      if (!rect) return
      const maxFill = rect.width - termLeft - 12
      const w = clientX - rect.left - termLeft
      if (w >= maxFill - 8) setTermWidth(null) // back to fill mode
      else setTermWidth(Math.max(320, Math.min(w, maxFill)))
    }

    const headerBtn = { padding: '5px 10px', borderRadius: 6, border: '1px solid rgba(128,128,128,0.4)', background: 'transparent', color: 'inherit', cursor: 'pointer', fontSize: 12 }
    const selectStyle = { padding: '5px 8px', borderRadius: 6, border: '1px solid rgba(128,128,128,0.4)', background: 'transparent', color: 'inherit', maxWidth: 200, fontSize: 12 }
    const activeTab = terminalTabs.find((t) => t.id === activeTerminalId)

    return React.createElement(React.Fragment, null,
    React.createElement('div', { ref: rootRef, 'data-dsh-ssh-view': '', style: { display: 'flex', flexDirection: 'column', height: '100%', width: '100%', minHeight: 0, background: 'var(--surface-color, #161a20)', color: 'var(--text-color, #e6e6e6)' } },
      React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 10, padding: '8px 12px', borderBottom: '1px solid rgba(128,128,128,0.25)', flexWrap: 'wrap' } },
        React.createElement('strong', { style: { fontSize: 13 } }, '\uD83D\uDDA5\uFE0F SSH \u8FDC\u7A0B\u63A7\u5236'),
        React.createElement('small', { style: { opacity: 0.55 } }, UI_VERSION),
        React.createElement('select', {
          value: selectedConnection,
          onChange: (e) => {
            const v = e.target.value
            if (v !== selectedConnection) {
              // User-initiated switch: allow the empty-tab auto-open below.
              suppressAutoOpen = false
              selectedConnection = v
              notifyTabs()
            }
          },
          style: selectStyle,
        },
          savedConnections.map((c) => React.createElement('option', { key: c.name, value: c.name }, `${c.name} (${c.username}@${c.host})`)),
          savedConnections.length === 0 ? React.createElement('option', { value: '' }, '(\u6CA1\u6709\u5DF2\u4FDD\u5B58\u7684\u8FDE\u63A5)') : null,
        ),
        React.createElement('button', {
          onClick: () => void refreshConnections(),
          style: headerBtn,
          title: '\u5237\u65B0\u8FDE\u63A5\u5217\u8868',
        }, '\u21BB'),
        React.createElement('button', {
          onClick: () => { if (selectedConnection) { setDeleteError(null); setConfirmDelete(selectedConnection) } },
          disabled: !selectedConnection || deleteBusy,
          style: { ...headerBtn, color: '#e06c75', borderColor: 'rgba(224,108,117,0.55)' },
          title: '\u5220\u9664\u5F53\u524D\u9009\u4E2D\u7684\u5DF2\u4FDD\u5B58\u8FDE\u63A5',
        }, '\uD83D\uDDD1\uFE0F \u5220\u9664\u6240\u9009'),
        // Manual-connect lives INSIDE the plugin toolbar, right of the host
        // dropdown — never in a session/header slot.
        React.createElement(ConnectButton, null),
        React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 4 } },
          React.createElement('button', { onClick: () => setTermFontSize(termFontSize - 1), style: { ...headerBtn, padding: '4px 8px' }, title: '\u51CF\u5C0F\u7EC8\u7AEF\u5B57\u53F7' }, 'A-'),
          React.createElement('span', { style: { fontSize: 11, minWidth: 22, textAlign: 'center', opacity: 0.85 } }, termFontSize),
          React.createElement('button', { onClick: () => setTermFontSize(termFontSize + 1), style: { ...headerBtn, padding: '4px 8px' }, title: '\u589E\u5927\u7EC8\u7AEF\u5B57\u53F7' }, 'A+'),
        ),
        React.createElement('div', { style: { flex: 1 } }),
        React.createElement('button', { onClick: () => setFiles(!filesVisible), style: headerBtn, title: '\u663E\u793A/\u9690\u85CF\u6587\u4EF6\u9762\u677F' }, filesVisible ? '\uD83D\uDCC1 \u6587\u4EF6: \u663E\u793A' : '\uD83D\uDCC1 \u6587\u4EF6: \u9690\u85CF'),
      ),
      React.createElement('div', { style: { flex: 1, minHeight: 0, display: 'flex' } },
        !selectedConnection
          ? React.createElement('div', { style: { margin: 'auto', opacity: 0.7 } }, '\u8BF7\u5148\u4FDD\u5B58\u4E00\u4E2A SSH \u8FDE\u63A5\u914D\u7F6E(\u5728\u5BF9\u8BDD\u4E2D\u7528 ssh_connections action=add)')
          : React.createElement(React.Fragment, null,
              filesVisible ? React.createElement('div', { style: { width: filesWidth, flexShrink: 0, display: 'flex', minHeight: 0, borderRight: '1px solid rgba(128,128,128,0.2)' } },
                React.createElement(FileBrowser, { connection: selectedConnection }),
              ) : null,
              filesVisible ? React.createElement(Splitter, { onDrag: onDragFiles }) : null,
              React.createElement('div', { style: termWidth === null
                  ? { flex: 1, minWidth: 320, display: 'flex', flexDirection: 'column', minHeight: 0 }
                  : { width: termWidth, minWidth: 320, flexShrink: 0, display: 'flex', flexDirection: 'column', minHeight: 0 } },
                // Terminal tab bar
                React.createElement('div', { style: { display: 'flex', gap: 6, padding: '4px 8px', borderBottom: '1px solid rgba(128,128,128,0.25)', alignItems: 'center', overflowX: 'auto', flexShrink: 0 } },
                  terminalTabs.map((t) =>
                    React.createElement('span', {
                      key: t.id,
                      onClick: () => { activeTerminalId = t.id; notifyTabs() },
                      style: {
                        display: 'inline-flex', alignItems: 'center', gap: 6, padding: '3px 8px', borderRadius: 6, cursor: 'pointer', whiteSpace: 'nowrap',
                        fontSize: 12, border: '1px solid rgba(128,128,128,0.4)',
                        background: t.id === activeTerminalId ? 'rgba(90,140,255,0.28)' : 'rgba(128,128,128,0.12)',
                        fontWeight: t.id === activeTerminalId ? 600 : 400,
                      },
                    },
                      t.title,
                      React.createElement('span', {
                        onClick: (e) => { e.stopPropagation(); closeTerminal(t.id) },
                        style: { cursor: 'pointer', opacity: 0.7, paddingLeft: 2, fontSize: 11 },
                        title: '\u5173\u95ED\u7EC8\u7AEF',
                      }, '\u2715'),
                    ),
                  ),
                  React.createElement('button', {
                    onClick: () => addTerminal(selectedConnection),
                    style: { ...headerBtn, fontSize: 12, flexShrink: 0 },
                    title: '\u65B0\u5EFA\u7EC8\u7AEF',
                  }, '+ \u65B0\u7EC8\u7AEF'),
                ),
                React.createElement('div', { style: { flex: 1, minHeight: 0, display: 'flex' } },
                  activeTab
                    ? React.createElement(TerminalPane, { key: activeTab.id, tab: activeTab })
                    : React.createElement('div', { style: { margin: 'auto', opacity: 0.7 } }, '\u70B9\u51FB + \u65B0\u7EC8\u7AEF \u521B\u5EFA'),
                ),
              ),
              // The terminal's own resize handle: a SIBLING of the terminal
              // container (never inside the element passed to term.open() —
              // xterm fills that element with its own layers and its hidden
              // textarea intercepts events). In fill mode (termWidth === null)
              // it sits at the far right edge; dragging it left captures an
              // explicit width, dragging it back to the edge restores fill.
              React.createElement(Splitter, { onDrag: onDragTerm }),
            ),
      ),
    ),
      confirmDelete
        ? React.createElement(DeleteConfirmModal, {
            profile: savedConnections.find((c) => c.name === confirmDelete) || { name: confirmDelete },
            busy: deleteBusy,
            error: deleteError,
            onCancel: () => { if (!deleteBusy) setConfirmDelete(null) },
            onConfirm: () => void deleteProfile(),
          })
        : null,
    )
  }

  // ---------------------------------------------------------------------
  // Delete-confirmation dialog for a saved connection profile. Rendered as
  // its own portal so the overlay escapes transformed/filtered ancestors
  // (same reasoning as the manual-connect modal).
  // ---------------------------------------------------------------------
  function DeleteConfirmModal({ profile, busy, error, onCancel, onConfirm }) {
    const btn = { padding: '6px 14px', borderRadius: 6, border: '1px solid rgba(128,128,128,0.4)', background: 'transparent', color: 'inherit', cursor: 'pointer' }
    const name = (profile && profile.name) || ''
    const meta = profile ? `${profile.username || '?'}@${profile.host || '?'}:${profile.port ?? 22}` : ''
    return ReactDOM.createPortal(
      React.createElement('div', {
        style: { position: 'fixed', inset: 0, zIndex: 10000, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center' },
        onClick: () => { if (!busy) onCancel() },
      },
        React.createElement('div', {
          onClick: (e) => e.stopPropagation(),
          style: { width: 420, maxWidth: '92vw', background: 'var(--surface-color, #1b1f27)', color: 'var(--text-color, #e6e6e6)', border: '1px solid rgba(224,108,117,0.45)', borderRadius: 12, padding: 18, boxShadow: '0 12px 48px rgba(0,0,0,0.6)', display: 'flex', flexDirection: 'column', gap: 12 },
        },
          React.createElement('strong', { style: { fontSize: 14 } }, '\uD83D\uDDD1\uFE0F \u5220\u9664\u5DF2\u4FDD\u5B58\u7684\u8FDE\u63A5'),
          React.createElement('div', { style: { fontSize: 13, lineHeight: 1.7 } },
            '\u786E\u5B9A\u8981\u5220\u9664\u5DF2\u4FDD\u5B58\u7684\u8FDE\u63A5\u300C', name, '\u300D (', meta, ') \u5417\uFF1F'),
          React.createElement('div', { style: { fontSize: 12, opacity: 0.75, lineHeight: 1.7 } },
            '\u5220\u9664\u540E\u8BE5\u4E3B\u673A\u5C06\u4E0D\u518D\u51FA\u73B0\u5728\u8FDE\u63A5\u5217\u8868\u4E2D\u3002\u82E5\u5B58\u5728\u8FDE\u63A5\u5230\u5B83\u7684\u7EC8\u7AEF\u6807\u7B7E\u9875,\u4F1A\u4E00\u5E76\u5173\u95ED\u3002\u8BE5\u64CD\u4F5C\u4E0D\u53EF\u64A4\u9500\u3002'),
          error ? React.createElement('div', { style: { color: '#e06c75', fontSize: 12 } }, error) : null,
          React.createElement('div', { style: { display: 'flex', gap: 10, justifyContent: 'flex-end' } },
            React.createElement('button', { onClick: onCancel, disabled: busy, style: btn }, '\u53D6\u6D88'),
            React.createElement('button', {
              onClick: onConfirm,
              disabled: busy,
              style: { ...btn, background: 'rgba(224,108,117,0.25)', borderColor: 'rgba(224,108,117,0.7)', color: '#e06c75' },
            }, busy ? '\u5220\u9664\u4E2D...' : '\u5220\u9664'),
          ),
        ),
      ),
      document.body,
    )
  }

  // ---------------------------------------------------------------------
  // Manual-connect: a header action button (same row as the view tabs)
  // that opens a modal for ad-hoc SSH sessions (host / user / port / auth).
  // On success it saves the profile, optionally verifies the connection,
  // and switches to the SSH console with that connection selected.
  // ---------------------------------------------------------------------
  function ConnectModal() {
    // ALWAYS start blank: this dialog is for NEW hosts and must never carry
    // over anything from the currently selected connection (or the browser's
    // saved credentials). Only the port keeps a neutral default (22).
    const [form, setForm] = useState({ name: '', host: '', port: '22', username: '', password: '', privateKeyPath: '' })
    const [busy, setBusy] = useState(false)
    const [error, setError] = useState(null)
    const [connected, setConnected] = useState(false)
    const [showPw, setShowPw] = useState(false)
    // Belt-and-braces: if React ever reuses this instance, force a clean slate.
    useEffect(() => {
      setForm({ name: '', host: '', port: '22', username: '', password: '', privateKeyPath: '' })
    }, [])

    const set = (key) => (e) => setForm({ ...form, [key]: e.target.value })

    const doConnect = async () => {
      setBusy(true)
      setError(null)
      const name = form.name.trim() || `${form.username.trim()}@${form.host.trim()}`
      const body = {
        name,
        host: form.host.trim(),
        port: form.port.trim() || '22',
        username: form.username.trim(),
      }
      if (form.password.trim()) body.password = form.password
      else if (form.privateKeyPath.trim()) body.privateKeyPath = form.privateKeyPath
      try {
        const res = await api('/connections', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify(body),
        })
        await res.json()
        // Verify the connection works before switching (test open + close).
        const open = await api('/term/open', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ connection: name, cols: 80, rows: 24 }),
        })
        const { id } = await open.json()
        await api('/term/close', {
          method: 'POST',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ id }),
        }).catch(() => {})
        pendingConnection = name
        // Reflect the new profile in the dropdown immediately and select it —
        // no page switch needed — then open a terminal tab for the host the
        // user just added so they land in its shell.
        try { await refreshConnections() } catch { /* non-fatal */ }
        selectedConnection = name
        suppressAutoOpen = false
        notifyTabs()
        if (!terminalTabs.some((t) => t.connection === name)) addTerminal(name)
        setConnected(true)
        setTimeout(() => {
          setConnectOpen(false)
          switchToSshView()
        }, 600)
      } catch (e) {
        setError(e.message)
      } finally {
        setBusy(false)
      }
    }

    // autocomplete="off" + non-login name attributes keep the browser's
    // password manager from classifying this as a login form and autofilling
    // saved credentials into it. The password field additionally uses
    // autocomplete="new-password", which Chromium honors strictly.
    const field = (label, value, onChange, opts) =>
      React.createElement('label', { style: { display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12 } },
        React.createElement('span', { style: { opacity: 0.8 } }, label),
        React.createElement('input', Object.assign({
          value, onChange,
          autoComplete: 'off',
          style: { padding: '6px 8px', borderRadius: 6, border: '1px solid rgba(128,128,128,0.4)', background: 'transparent', color: 'inherit', fontFamily: 'monospace' },
        }, opts || {})),
      )
    const btn = { padding: '6px 14px', borderRadius: 6, border: '1px solid rgba(128,128,128,0.4)', background: 'transparent', color: 'inherit', cursor: 'pointer' }

    return React.createElement('div', {
      style: { position: 'fixed', inset: 0, zIndex: 10000, background: 'rgba(0,0,0,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center' },
      onClick: () => { if (!busy) setConnectOpen(false) },
    },
      React.createElement('div', {
        onClick: (e) => e.stopPropagation(),
        style: { width: 420, maxWidth: '92vw', background: 'var(--surface-color, #1b1f27)', color: 'var(--text-color, #e6e6e6)', border: '1px solid rgba(128,128,128,0.35)', borderRadius: 12, padding: 18, boxShadow: '0 12px 48px rgba(0,0,0,0.6)', display: 'flex', flexDirection: 'column', gap: 12 },
      },
        React.createElement('strong', { style: { fontSize: 14 } }, '\uD83D\uDD0C \u624B\u52A8\u8FDE\u63A5 SSH \u4E3B\u673A'),
        field('\u8FDE\u63A5\u540D\u79F0(\u53EF\u9009,\u9ED8\u8BA4 user@host)', form.name, set('name'), { name: 'dsh-ssh-name', placeholder: 'user@host' }),
        field('\u4E3B\u673A IP / \u57DF\u540D *', form.host, set('host'), { name: 'dsh-ssh-host', placeholder: '192.0.2.1' }),
        field('\u7528\u6237\u540D *', form.username, set('username'), { name: 'dsh-ssh-user', placeholder: 'root' }),
        field('\u7AEF\u53E3', form.port, set('port'), { name: 'dsh-ssh-port', placeholder: '22' }),
        React.createElement('label', { style: { display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12 } },
          React.createElement('span', { style: { opacity: 0.8 } }, '\u5BC6\u7801(\u4E0E\u79C1\u94A5\u4E8C\u9009\u4E00)'),
          React.createElement('div', { style: { display: 'flex', gap: 6, alignItems: 'center' } },
            React.createElement('input', {
              value: form.password,
              onChange: set('password'),
              type: showPw ? 'text' : 'password',
              autoComplete: 'new-password',
              name: 'dsh-ssh-password',
              placeholder: '\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022',
              style: { flex: 1, padding: '6px 8px', borderRadius: 6, border: '1px solid rgba(128,128,128,0.4)', background: 'transparent', color: 'inherit', fontFamily: 'monospace' },
            }),
            React.createElement('button', {
              type: 'button',
              onClick: () => setShowPw(!showPw),
              title: showPw ? '\u9690\u85CF\u5BC6\u7801' : '\u663E\u793A\u5BC6\u7801',
              style: btn,
            }, showPw ? '\uD83D\uDC41\uFE0F' : '\uD83D\uDC41\uFE0F\u200D\u26A0\uFE0F'),
          ),
        ),
        field('\u79C1\u94A5\u6587\u4EF6\u8DEF\u5F84(\u4E0E\u5BC6\u7801\u4E8C\u9009\u4E00)', form.privateKeyPath, set('privateKeyPath'), { name: 'dsh-ssh-key', placeholder: 'C:\\path\\to\\key.pem' }),
        error ? React.createElement('div', { style: { color: '#e06c75', fontSize: 12 } }, error) : null,
        connected ? React.createElement('div', { style: { color: '#98c379', fontSize: 12 } }, '\u2705 \u8FDE\u63A5\u6210\u529F,\u6B63\u5728\u8FDB\u5165 SSH \u63A7\u5236\u53F0...') : null,
        React.createElement('div', { style: { display: 'flex', gap: 10, justifyContent: 'flex-end' } },
          React.createElement('button', { onClick: () => setConnectOpen(false), disabled: busy, style: btn }, '\u53D6\u6D88'),
          React.createElement('button', {
            onClick: () => void doConnect(),
            disabled: busy || !form.host.trim() || !form.username.trim(),
            style: { ...btn, background: 'rgba(90,140,255,0.25)', borderColor: 'rgba(90,140,255,0.7)' },
          }, busy ? '\u8FDE\u63A5\u4E2D...' : '\u8FDE\u63A5'),
        ),
      ),
    )
  }

  function ConnectButton() {
    const [open, setOpenState] = useState(connectOpen)
    useEffect(() => subscribeUi(() => setOpenState(connectOpen)), [])
    return React.createElement(React.Fragment, null,
      React.createElement('button', {
        onClick: () => setConnectOpen(true),
        title: '\u8F93\u5165 IP/\u7528\u6237/\u7AEF\u53E3 \u624B\u52A8\u8FDE\u63A5 SSH \u4E3B\u673A',
        style: {
          padding: '5px 10px', borderRadius: 6, cursor: 'pointer', fontSize: 12, whiteSpace: 'nowrap',
          border: '1px solid rgba(90,140,255,0.5)', background: 'rgba(90,140,255,0.12)', color: 'inherit',
        },
      }, '\uD83D\uDD0C \u624B\u52A8\u8FDE\u63A5'),
      // Portal the modal to document.body: a fixed overlay inside a
      // transformed/filtered ancestor would be positioned relative to that
      // ancestor (that is exactly the misplacement we are fixing), so it must
      // escape the whole plugin tree.
      open ? ReactDOM.createPortal(React.createElement(ConnectModal, null), document.body) : null,
    )
  }

  // ---------------------------------------------------------------------
  // apply: register as a top-level conversation view (tab in the top row)
  // + a header action for manual connect
  // ---------------------------------------------------------------------
  function apply(ctx) {
    // Own the injected widen style: remove it when this client module unloads.
    const styleEl = injectWidenStyle()
    if (ctx.effect) ctx.effect(() => () => {
      try { styleEl.remove() } catch { /* ignore */ }
      widenStyleEl = null
    }, 'dsh-tool-ssh: widen style')
    ctx.slots.inject('conversation.view', () => ctx.slots.register({
      name: 'conversation.view',
      id: 'dsh-tool-ssh',
      order: 20,
      label: () => '\uD83D\uDDA5\uFE0F SSH \u8FDC\u7A0B\u63A7\u5236',
    }, SshConsoleView))
  }

  module.exports = {
    name: 'dsh-tool-ssh-client',
    inject: ['slots'],
    apply,
  }
  return module.exports
} })
