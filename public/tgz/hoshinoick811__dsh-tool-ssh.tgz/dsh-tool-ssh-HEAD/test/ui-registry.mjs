/**
 * Unit test for the v7 UiTerminalRegistry session-retention logic:
 * - a terminal session survives its SSE writer detaching (view switch)
 * - a reconnecting writer first receives the retained transcript (replay),
 *   then live output
 * - the remote shell keeps running while detached (counter state persists)
 * Run:  node test/ui-registry.mjs
 */
import ssh2 from "ssh2";
import { UiTerminalRegistry } from "../lib/ui.js";

const { Server, utils } = ssh2;
const keyPair = utils.generateKeyPairSync("ed25519");

let remoteCounter = 0;
const server = new Server({ hostKeys: [keyPair.private] }, (client) => {
	client.on("authentication", (ctx) => {
		if (ctx.method === "password" && ctx.password === "password") ctx.accept();
		else ctx.reject(["password"]);
	});
	client.on("ready", () => {
		client.on("session", (accept) => {
			const session = accept();
			session.on("pty", (acceptPty) => acceptPty && acceptPty());
			session.on("shell", (accept2) => {
				const stream = accept2();
				let buf = "";
				stream.on("data", (d) => {
					buf += d.toString("utf8");
					let idx;
					while ((idx = buf.indexOf("\n")) >= 0) {
						const line = buf.slice(0, idx).trim();
						buf = buf.slice(idx + 1);
						if (line === "exit") { stream.end(); return; }
						if (line === "count") stream.write(`count=${++remoteCounter}\r\n`);
						else stream.write(`echo:${line}\r\n`);
					}
				});
				stream.on("close", () => { try { stream.end(); } catch { /* ignore */ } });
			});
		});
	});
});

await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const port = server.address().port;

const manager = {
	getConnection: () => ({ name: "local", host: "127.0.0.1", port, username: "demo", password: "password" })
};
const registry = new UiTerminalRegistry(manager, { warn() {}, info() {} });

let failed = 0;
const check = (label, ok, extra = "") => {
	if (ok) console.log(`  ok    ${label}`);
	else { failed++; console.log(`  FAIL  ${label} ${extra}`); }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

try {
	const id = await registry.open("local", 80, 24);
	check("session opened", !!registry.get(id));

	// writer A attached (the "view is open" state)
	const a = [];
	const writerA = (text) => a.push(text === null ? "[closed]" : text);
	check("attach A", registry.attachWriter(id, writerA) === true);

	const entry = registry.get(id);
	entry.stream.write("count\n");
	await sleep(400);
	check("A received count=1", a.join("").includes("count=1"), JSON.stringify(a));

	// detach A — simulate the user switching away from the SSH view
	registry.detachWriter(id, writerA);
	entry.stream.write("count\n"); // shell keeps running while away
	await sleep(400);
	check("buffer retained (has count=1..2)", entry.buffer.includes("count=1") && entry.buffer.includes("count=2"), entry.buffer.slice(-80));

	// writer B attaches — must replay the retained transcript then go live
	const b = [];
	const writerB = (text) => b.push(text === null ? "[closed]" : text);
	check("attach B", registry.attachWriter(id, writerB) === true);
	await sleep(200);
	entry.stream.write("count\n");
	await sleep(400);

	const bText = b.join("");
	check("B replay contains count=1", bText.includes("count=1"), JSON.stringify(b));
	check("B replay contains count=2 (while away)", bText.includes("count=2"), JSON.stringify(b));
	check("B live contains count=3", bText.includes("count=3"), JSON.stringify(b));
	check("remote shell persisted (counter=3)", remoteCounter === 3, `counter=${remoteCounter}`);

	// detach B; close() should tear the session down for real
	registry.detachWriter(id, writerB);
	check("close tears down", registry.close(id) === true);
	check("session gone", registry.get(id) === undefined);
} catch (err) {
	failed++;
	console.error("  FATAL", err);
} finally {
	registry.closeAll();
	server.close();
}

console.log(failed === 0 ? "\nALL PASSED" : `\n${failed} CHECK(S) FAILED`);
process.exit(failed === 0 ? 0 : 1);
