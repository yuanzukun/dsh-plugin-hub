/**
 * Offline plugin registration test: loads the cordis plugin module with a
 * mocked context and asserts all 10 ssh_* tools register with valid,
 * compilable schemas. No network needed.
 *
 * Run:  node test/plugin-offline.mjs
 */
import * as plugin from "../lib/index.js";

let failed = 0;
function check(label, condition, extra = "") {
	if (condition) console.log(`  ok    ${label}`);
	else {
		failed++;
		console.log(`  FAIL  ${label} ${extra}`);
	}
}

const registered = [];
const ctx = {
	logger: () => ({ warn() {}, error() {}, info() {}, debug() {} }),
	effect: (fn) => { ctx.disposer = fn(); return () => {}; },
	get: () => undefined,
	tools: {
		register(definition) {
			registered.push(definition);
			return () => {};
		}
	}
};

plugin.apply(ctx, {});

check("module exports name", plugin.name === "dsh-tool-ssh", String(plugin.name));
check("module exports inject", Array.isArray(plugin.inject) && plugin.inject.includes("tools"));
check("module exports Config", typeof plugin.Config === "function");
check("module exports apply", typeof plugin.apply === "function");

const expected = [
	"ssh_connections", "ssh_connect", "ssh_exec", "ssh_read", "ssh_write",
	"ssh_list", "ssh_upload", "ssh_download", "ssh_disconnect", "ssh_sessions"
];
for (const name of expected) {
	const def = registered.find((d) => d.name === name);
	check(`registered ${name}`, !!def, "not found");
	if (def) {
		check(`  ${name}: description non-empty`, typeof def.description === "string" && def.description.length > 40);
		check(`  ${name}: parameters is object`, typeof def.parameters === "object" && def.parameters !== null);
		check(`  ${name}: output.schema present`, !!def.output?.schema);
		check(`  ${name}: execute is function`, typeof def.execute === "function");
		check(`  ${name}: render is function`, typeof def.output?.render === "function");
	}
}
check("no unexpected tools", registered.length === expected.length, `got ${registered.length}`);

// exec result render sanity
const execDef = registered.find((d) => d.name === "ssh_exec");
if (execDef) {
	const rendered = execDef.output.render({}, {
		stdout: "hello", stderr: "", exitCode: 0, timedOut: false, aborted: false, durationMs: 5
	});
	check("exec render clean exit", rendered[0]?.text === "hello", JSON.stringify(rendered));
	const renderedErr = execDef.output.render({}, {
		stdout: "x", stderr: "bad", exitCode: 2, timedOut: false, aborted: false, durationMs: 5
	});
	check("exec render markers", renderedErr[0]?.text.includes("[stderr]") && renderedErr[0]?.text.includes("[exit code: 2]"), JSON.stringify(renderedErr));
	const renderedTimeout = execDef.output.render({}, {
		stdout: "", stderr: "", exitCode: null, timedOut: true, aborted: false, durationMs: 90000
	});
	check("exec render timeout", renderedTimeout[0]?.text.includes("[timed out after 90000ms]"), JSON.stringify(renderedTimeout));
}

console.log(failed === 0 ? "\nALL PASSED" : `\n${failed} CHECK(S) FAILED`);
process.exit(failed === 0 ? 0 : 1);
