/**
 * Local end-to-end smoke test: spins up a real ssh2 Server on 127.0.0.1
 * (password auth, a tiny command shell) and drives the SshSessionManager
 * client against it — real SSH handshake, exec round-trips, stderr/exit-code
 * capture, cwd wrapping, and session reuse. No external network needed.
 *
 * Run:  node test/smoke-local.mjs
 */
import ssh2 from "ssh2";
import { SshSessionManager } from "../lib/ssh-core.js";

const { Server, utils } = ssh2;

const keyPair = utils.generateKeyPairSync("ed25519");

const server = new Server({ hostKeys: [keyPair.private] }, (client) => {
	client.on("authentication", (ctx) => {
		if (ctx.method === "password" && ctx.username === "demo" && ctx.password === "password") ctx.accept();
		else ctx.reject(["password"]);
	});
	client.on("ready", () => {
		client.on("session", (accept) => {
			const session = accept();
			session.on("exec", (acceptExec, rejectExec, info) => {
				const stream = acceptExec();
				const cmd = info.command;
				// A tiny fake shell adequate for the test commands.
				if (cmd === "sleep 5") {
					setTimeout(() => {
						stream.exit(0);
						stream.end();
					}, 600);
				} else if (cmd.startsWith("echo oops 1>&2; exit ")) {
					stream.stderr.write("oops\n");
					stream.exit(3);
					stream.end();
				} else if (cmd.startsWith("echo ")) {
					stream.write(`${cmd.slice(5)}\n`);
					stream.exit(0);
					stream.end();
				} else if (cmd.includes("pwd")) {
					stream.write("/\n");
					stream.exit(0);
					stream.end();
				} else {
					stream.stderr.write(`unknown command: ${cmd}\n`);
					stream.exit(1);
					stream.end();
				}
			});
		});
	});
});

await new Promise((resolve, reject) => {
	server.once("error", reject);
	server.listen(0, "127.0.0.1", resolve);
});
const port = server.address().port;
console.log(`local ssh server listening on 127.0.0.1:${port}`);

const manager = new SshSessionManager({
	defaultTimeoutMs: 15000,
	maxOutputBytes: 65536,
	connectTimeoutMs: 15000
});

let failed = 0;
function check(label, condition, extra = "") {
	if (condition) console.log(`  ok    ${label}`);
	else {
		failed++;
		console.log(`  FAIL  ${label} ${extra}`);
	}
}

try {
	console.log("== connect (password auth, loopback) ==");
	const entry = await manager.open({
		id: "local",
		host: "127.0.0.1",
		port,
		username: "demo",
		password: "password"
	});
	check("session open", !!entry && !!entry.client);
	check("session registered", manager.listSessions().length === 1);
	check("wrong password rejected", await (async () => {
		try {
			await manager.open({ id: "bad", host: "127.0.0.1", port, username: "demo", password: "nope", connectTimeoutMs: 8000 });
			return false;
		} catch { return true; }
	})());
	check("failed session cleaned up", manager.listSessions().length === 1);

	console.log("== exec ==");
	const res = await manager.exec("local", "echo hello-local");
	check("stdout captured", res.stdout.includes("hello-local"), JSON.stringify(res));
	check("exit code 0", res.exitCode === 0, `exitCode=${res.exitCode}`);

	const resErr = await manager.exec("local", "echo oops 1>&2; exit 3");
	check("stderr captured", resErr.stderr.includes("oops"), JSON.stringify(resErr));
	check("nonzero exit reported", resErr.exitCode === 3, `exitCode=${resErr.exitCode}`);

	const resCd = await manager.exec("local", "pwd", { cwd: "/" });
	check("cwd wrapping works", resCd.stdout.trim() === "/", JSON.stringify(resCd));

	console.log("== timeout handling ==");
	const resSlow = await manager.exec("local", "sleep 5", { timeoutMs: 100 });
	check("timedOut flagged", resSlow.timedOut === true, JSON.stringify(resSlow));
	check("partial output kept", typeof resSlow.stdout === "string", JSON.stringify(resSlow));

	console.log("== session reuse & close ==");
	const again = await manager.open({ id: "local", host: "127.0.0.1", port, username: "demo", password: "password" });
	check("reconnect reuses same session", again === entry);
	check("disconnect ok", manager.disconnect("local") === true);
	check("no sessions left", manager.listSessions().length === 0);
} catch (err) {
	failed++;
	console.error("  FATAL", err);
} finally {
	manager.closeAll();
	server.close();
}

console.log(failed === 0 ? "\nALL PASSED" : `\n${failed} CHECK(S) FAILED`);
process.exit(failed === 0 ? 0 : 1);
