/**
 * Minimal in-memory SFTP server for tests, built on ssh2 1.x's built-in
 * server-mode SFTP (event-driven). Serves password auth and a tiny virtual
 * filesystem, enough for list/read/write/upload/download client round-trips.
 * Test-only; not part of the plugin.
 *
 * @module test/sftp-mem-server
 */
import ssh2 from "ssh2";
import { generateKeyPairSync } from "node:crypto";
import { dirname, basename } from "node:path";

const { Server, utils } = ssh2;
const { STATUS_CODE } = utils.sftp;
const { READ, WRITE, CREAT, TRUNC, EXCL } = utils.sftp.OPEN_MODE;

/** Normalize a POSIX path to canonical form (absolute, no trailing slash). */
function normalize(path) {
	let p = String(path).replace(/\\/g, "/");
	if (!p.startsWith("/")) p = `/${p}`;
	p = p.replace(/\/+/g, "/");
	if (p.length > 1 && p.endsWith("/")) p = p.slice(0, -1);
	return p;
}

/** Tiny in-memory file tree. */
class MemFs {
	constructor(files = {}) {
		this.nodes = new Map(); // path -> { type:'dir', entries:Set<name> } | { type:'file', content:Buffer }
		this.nodes.set("/", { type: "dir", entries: new Set() });
		for (const [path, content] of Object.entries(files)) {
			this.writeFile(path, Buffer.from(String(content), "utf8"));
		}
	}

	ensureDir(path) {
		const p = normalize(path);
		if (this.nodes.has(p)) return;
		const parent = dirname(p);
		if (parent !== p) this.ensureDir(parent);
		this.nodes.set(p, { type: "dir", entries: new Set() });
		this.nodes.get(parent).entries.add(basename(p));
	}

	stat(path) {
		const node = this.nodes.get(normalize(path));
		if (!node) return null;
		const mtime = Math.floor(Date.now() / 1000);
		if (node.type === "dir") {
			return { size: 0, uid: 1000, gid: 1000, mode: 0o040755, atime: mtime, mtime };
		}
		return { size: node.content.length, uid: 1000, gid: 1000, mode: 0o100644, atime: mtime, mtime };
	}

	readdir(path) {
		const node = this.nodes.get(normalize(path));
		if (!node || node.type !== "dir") return null;
		return [...node.entries].map((name) => {
			const full = normalize(`${normalize(path)}/${name}`);
			const st = this.stat(full);
			return { filename: name, longname: "", attrs: st };
		});
	}

	writeFile(path, content) {
		const p = normalize(path);
		this.ensureDir(dirname(p));
		this.nodes.set(p, { type: "file", content: Buffer.from(content) });
		if (!this.nodes.get(dirname(p)).entries.has(basename(p))) {
			this.nodes.get(dirname(p)).entries.add(basename(p));
		}
	}

	readFile(path) {
		const node = this.nodes.get(normalize(path));
		return node && node.type === "file" ? node.content : null;
	}

	remove(path) {
		const p = normalize(path);
		const node = this.nodes.get(p);
		if (!node) return false;
		if (node.type === "dir" && node.entries.size > 0) return false;
		this.nodes.delete(p);
		this.nodes.get(dirname(p))?.entries.delete(basename(p));
		return true;
	}
}

/**
 * Attach SFTP server-mode handlers to an accepted SFTP instance.
 * @param {object} sftp - the SFTP instance returned by accept().
 * @param {MemFs} fs - backing store.
 */
function attachSftpHandlers(sftp, fs) {
	let nextHandle = 1;
	const handles = new Map(); // handleHex -> descriptor

	const newHandle = (descriptor) => {
		const hex = (nextHandle++).toString(16).padStart(8, "0");
		handles.set(hex, descriptor);
		return Buffer.from(hex, "utf8");
	};
	const byHandle = (handle) => handles.get(handle.toString("utf8"));

	sftp.on("OPEN", (reqID, filename, pflags) => {
		const path = normalize(filename);
		const isWrite = (pflags & (WRITE | CREAT | TRUNC)) !== 0;
		if (isWrite) {
			if (pflags & TRUNC) {
				fs.nodes.set(path, { type: "file", content: Buffer.alloc(0) });
				const parent = dirname(path);
				if (fs.nodes.get(parent)?.type === "dir" && !fs.nodes.get(parent).entries.has(basename(path))) {
					fs.nodes.get(parent).entries.add(basename(path));
				}
			} else if (!fs.nodes.has(path)) {
				fs.writeFile(path, Buffer.alloc(0));
			}
			const existing = fs.nodes.get(path);
			if (existing?.type === "file") {
				sftp.handle(reqID, newHandle({ kind: "file", path, mode: "w", data: Buffer.alloc(0) }));
			} else {
				sftp.status(reqID, STATUS_CODE.FAILURE);
			}
			return;
		}
		// read
		const content = fs.readFile(path);
		if (content === null) sftp.status(reqID, STATUS_CODE.NO_SUCH_FILE);
		else sftp.handle(reqID, newHandle({ kind: "file", path, mode: "r", data: content, pos: 0 }));
	});

	sftp.on("READ", (reqID, handle, offset, len) => {
		const d = byHandle(handle);
		if (!d || d.mode !== "r") return sftp.status(reqID, STATUS_CODE.FAILURE);
		const end = Math.min(Number(offset) + len, d.data.length);
		if (Number(offset) >= d.data.length) return sftp.status(reqID, STATUS_CODE.EOF);
		sftp.data(reqID, d.data.subarray(Number(offset), end));
	});

	sftp.on("WRITE", (reqID, handle, offset, data) => {
		const d = byHandle(handle);
		if (!d || d.mode !== "w") return sftp.status(reqID, STATUS_CODE.FAILURE);
		const end = Number(offset) + data.length;
		if (end > d.data.length) d.data = Buffer.concat([d.data, Buffer.alloc(end - d.data.length)]);
		data.copy(d.data, Number(offset));
		sftp.status(reqID, STATUS_CODE.OK);
	});

	sftp.on("CLOSE", (reqID, handle) => {
		const d = byHandle(handle);
		if (!d) return sftp.status(reqID, STATUS_CODE.FAILURE);
		handles.delete(handle.toString("utf8"));
		if (d.mode === "w") fs.writeFile(d.path, d.data);
		sftp.status(reqID, STATUS_CODE.OK);
	});

	sftp.on("OPENDIR", (reqID, path) => {
		const entries = fs.readdir(path);
		if (entries === null) sftp.status(reqID, STATUS_CODE.NO_SUCH_FILE);
		else sftp.handle(reqID, newHandle({ kind: "dir", path, entries, pos: 0 }));
	});

	sftp.on("READDIR", (reqID, handle) => {
		const d = byHandle(handle);
		if (!d || d.kind !== "dir") return sftp.status(reqID, STATUS_CODE.FAILURE);
		if (d.pos >= d.entries.length) return sftp.status(reqID, STATUS_CODE.EOF);
		const batch = d.entries.slice(d.pos);
		d.pos = d.entries.length;
		sftp.name(reqID, batch);
	});

	sftp.on("STAT", (reqID, path) => {
		const st = fs.stat(path);
		if (st === null) sftp.status(reqID, STATUS_CODE.NO_SUCH_FILE);
		else sftp.attrs(reqID, st);
	});

	sftp.on("LSTAT", (reqID, path) => {
		const st = fs.stat(path);
		if (st === null) sftp.status(reqID, STATUS_CODE.NO_SUCH_FILE);
		else sftp.attrs(reqID, st);
	});

	sftp.on("FSTAT", (reqID, handle) => {
		const d = byHandle(handle);
		if (!d) return sftp.status(reqID, STATUS_CODE.FAILURE);
		const st = d.kind === "dir" ? { size: 0, uid: 1000, gid: 1000, mode: 0o040755, atime: 0, mtime: 0 } : { size: d.data.length, uid: 1000, gid: 1000, mode: 0o100644, atime: 0, mtime: 0 };
		sftp.attrs(reqID, st);
	});

	sftp.on("REALPATH", (reqID, path) => {
		sftp.name(reqID, [{ filename: normalize(path), longname: "", attrs: { mode: 0o040755 } }]);
	});

	sftp.on("REMOVE", (reqID, path) => {
		sftp.status(reqID, fs.remove(path) ? STATUS_CODE.OK : STATUS_CODE.NO_SUCH_FILE);
	});

	sftp.on("MKDIR", (reqID, path) => {
		fs.ensureDir(path);
		sftp.status(reqID, STATUS_CODE.OK);
	});

	sftp.on("RMDIR", (reqID, path) => {
		sftp.status(reqID, fs.remove(path) ? STATUS_CODE.OK : STATUS_CODE.NO_SUCH_FILE);
	});

	sftp.on("RENAME", (reqID, oldPath, newPath) => {
		const content = fs.readFile(oldPath);
		if (content === null) return sftp.status(reqID, STATUS_CODE.NO_SUCH_FILE);
		fs.writeFile(newPath, content);
		fs.remove(oldPath);
		sftp.status(reqID, STATUS_CODE.OK);
	});

	sftp.on("SETSTAT", (reqID) => sftp.status(reqID, STATUS_CODE.OK));
	sftp.on("FSETSTAT", (reqID) => sftp.status(reqID, STATUS_CODE.OK));
	sftp.on("READLINK", (reqID) => sftp.status(reqID, STATUS_CODE.OP_UNSUPPORTED));
	sftp.on("SYMLINK", (reqID) => sftp.status(reqID, STATUS_CODE.OP_UNSUPPORTED));
}

/**
 * Start a password-auth SFTP server on 127.0.0.1 backed by a MemFs.
 * @param {object} options
 * @param {number} [options.port] - 0 picks a free port.
 * @param {Record<string,string>} [options.files] - initial file tree.
 * @param {string} [options.user] - default 'demo'.
 * @param {string} [options.password] - default 'password'.
 * @returns {Promise<{server: object, port: number, fs: MemFs}>}
 */
export async function startMemSftpServer({ port = 0, files = {}, user = "demo", password = "password" } = {}) {
	const fs = new MemFs(files);
	const keyPair = generateKeyPairSync("rsa", {
		modulusLength: 2048,
		privateKeyEncoding: { type: "pkcs1", format: "pem" },
		publicKeyEncoding: { type: "spki", format: "pem" }
	});
	const server = new Server({ hostKeys: [keyPair.privateKey] }, (client) => {
		client.on("authentication", (ctx) => {
			if (ctx.method === "password" && ctx.username === user && ctx.password === password) ctx.accept();
			else ctx.reject(["password"]);
		});
		client.on("ready", () => {
			client.on("session", (accept) => {
				const session = accept();
				session.on("sftp", (acceptSftp) => {
					const sftp = acceptSftp();
					attachSftpHandlers(sftp, fs);
				});
			});
		});
	});
	await new Promise((resolve, reject) => {
		server.once("error", reject);
		server.listen(port, "127.0.0.1", resolve);
	});
	return { server, port: server.address().port, fs };
}
