/**
 * Smoke test for dsh-tool-ssh's core against the public Rebex test server
 * (test.rebex.net, port 2222, user demo / password password). Exercises
 * connect, exec, SFTP list/read — enough to prove the ssh2 wiring works.
 *
 * Run:  node test/smoke.mjs
 */
import { SshSessionManager } from "../lib/ssh-core.js";

const manager = new SshSessionManager({
	connectionsFile: new URL("./tmp-connections.json", import.meta.url).pathname,
	defaultTimeoutMs: 20000,
	maxOutputBytes: 65536,
	connectTimeoutMs: 20000
});

let failed = 0;
function check(label, condition, extra = "") {
	if (condition) {
		console.log(`  ok    ${label}`);
	} else {
		failed++;
		console.log(`  FAIL  ${label} ${extra}`);
	}
}

try {
	console.log("== connect (password auth) ==");
	const entry = await manager.open({
		id: "rebex",
		host: "test.rebex.net",
		port: 2222,
		username: "demo",
		password: "password"
	});
	check("session open", !!entry && !!entry.client);
	check("session registered", manager.listSessions().length === 1);
	check("reconnect reuses same session", (await manager.open({ id: "rebex", host: "test.rebex.net", port: 2222, username: "demo", password: "password" })) === entry);

	console.log("== exec ==");
	const res = await manager.exec("rebex", "echo hello-from-rebex");
	check("stdout captured", res.stdout.includes("hello-from-rebex"), JSON.stringify(res));
	check("exit code 0", res.exitCode === 0, `exitCode=${res.exitCode}`);

	const resErr = await manager.exec("rebex", "echo oops 1>&2; exit 3");
	check("stderr captured", resErr.stderr.includes("oops"), JSON.stringify(resErr));
	check("nonzero exit reported", resErr.exitCode === 3, `exitCode=${resErr.exitCode}`);

	const resCd = await manager.exec("rebex", "pwd", { cwd: "/" });
	check("cwd honored", resCd.stdout.trim() === "/", JSON.stringify(resCd));

	console.log("== sftp list ==");
	const entries = await manager.list("rebex", "/");
	check("listing non-empty", Array.isArray(entries) && entries.length > 0, JSON.stringify(entries).slice(0, 200));
	check("has Readme.txt", entries.some((e) => e.name === "Readme.txt"), entries.map((e) => e.name).join(","));
	const readme = entries.find((e) => e.name === "Readme.txt");
	check("has size", typeof readme?.size === "number" && readme.size > 0, JSON.stringify(readme));

	console.log("== sftp read ==");
	const content = await manager.readFile("rebex", "/Readme.txt");
	check("read content", content.length > 0, content.slice(0, 120));
	check("utf8 text", /[A-Za-z]/.test(content));

	console.log("== session close ==");
	check("disconnect ok", manager.disconnect("rebex") === true);
	check("disconnect idempotent", manager.disconnect("rebex") === false);
	check("no sessions left", manager.listSessions().length === 0);
} catch (err) {
	failed++;
	console.error("  FATAL", err);
} finally {
	manager.closeAll();
}

console.log(failed === 0 ? "\nALL PASSED" : `\n${failed} CHECK(S) FAILED`);
process.exit(failed === 0 ? 0 : 1);
