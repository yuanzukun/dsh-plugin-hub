/**
 * SFTP end-to-end smoke test: boots the in-memory SFTP server
 * (test/sftp-mem-server.mjs, built on ssh2 1.x server mode) on 127.0.0.1 and
 * drives the SshSessionManager client through list/read/write/upload/download.
 * No external network.
 *
 * Run:  node test/smoke-sftp.mjs
 */
import { mkdirSync, writeFileSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { startMemSftpServer } from "./sftp-mem-server.mjs";
import { SshSessionManager } from "../lib/ssh-core.js";

const { server, port, fs } = await startMemSftpServer({
	files: {
		"/hello.txt": "hello from sftp server\n",
		"/sub/nested.txt": "nested content\n"
	}
});
console.log(`in-memory sftp server on 127.0.0.1:${port}`);

const manager = new SshSessionManager({
	defaultTimeoutMs: 20000,
	maxOutputBytes: 65536,
	connectTimeoutMs: 15000
});

let failed = 0;
function check(label, condition, extra = "") {
	if (condition) console.log(`  ok    ${label}`);
	else {
		failed++;
		console.log(`  FAIL  ${label} ${extra}`);
	}
}

try {
	console.log("== connect ==");
	await manager.open({ id: "sftp", host: "127.0.0.1", port, username: "demo", password: "password" });
	check("session open", manager.listSessions().length === 1);

	console.log("== ssh_list ==");
	const entries = await manager.list("sftp", "/");
	check("sees hello.txt", entries.some((e) => e.name === "hello.txt"), JSON.stringify(entries.map((e) => e.name)));
	check("sees sub dir as dir", entries.some((e) => e.name === "sub" && e.type === "dir"), JSON.stringify(entries));
	const hello = entries.find((e) => e.name === "hello.txt");
	check("file has size", typeof hello?.size === "number" && hello.size > 0, JSON.stringify(hello));
	check("file has mode", typeof hello?.mode === "number" && hello.mode > 0, JSON.stringify(hello));

	console.log("== ssh_read ==");
	const content = await manager.readFile("sftp", "/hello.txt");
	check("content matches", content.includes("hello from sftp server"), JSON.stringify(content));

	console.log("== ssh_write ==");
	const written = await manager.writeFile("sftp", "/written.txt", "brand new\n");
	check("bytes reported", written === 10, `bytes=${written}`);
	const reread = await manager.readFile("sftp", "/written.txt");
	check("write persisted", reread === "brand new\n", JSON.stringify(reread));
	check("server fs updated", fs.readFile("/written.txt")?.toString("utf8") === "brand new\n");

	console.log("== ssh_upload ==");
	const localUp = resolve(tmpdir(), `dsh-tool-ssh-up-${Date.now()}.txt`);
	writeFileSync(localUp, "upload payload 12345\n");
	const upBytes = await manager.upload("sftp", localUp, "/uploaded.txt");
	check("upload bytes", upBytes > 0, `bytes=${upBytes}`);
	const upBack = await manager.readFile("sftp", "/uploaded.txt");
	check("upload content", upBack.includes("upload payload"), JSON.stringify(upBack));

	console.log("== ssh_download ==");
	const localDown = resolve(tmpdir(), `dsh-tool-ssh-down-${Date.now()}.txt`);
	const downBytes = await manager.download("sftp", "/hello.txt", localDown);
	check("download bytes", downBytes > 0, `bytes=${downBytes}`);
	check("download content", readFileSync(localDown, "utf8").includes("hello from sftp"), readFileSync(localDown, "utf8"));

	console.log("== cleanup ==");
	check("disconnect", manager.disconnect("sftp") === true);
} catch (err) {
	failed++;
	console.error("  FATAL", err);
} finally {
	manager.closeAll();
	server.close();
}

console.log(failed === 0 ? "\nALL PASSED" : `\n${failed} CHECK(S) FAILED`);
process.exit(failed === 0 ? 0 : 1);
