/**
 * Step-by-step session bootstrap probe: logs the button/body state at each
 * step so we can see exactly where the conversation header (with the view
 * tabs) appears, then verifies the v4 SSH tab + console + splitter.
 * Run:  node test/debug-browser.mjs
 */
import puppeteer from "puppeteer-core";

const GUI = "http://127.0.0.1:3080";
const EDGE = "C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe";

const browser = await puppeteer.launch({
	executablePath: EDGE,
	headless: "new",
	args: ["--no-sandbox", "--disable-gpu", "--window-size=1500,950"],
	defaultViewport: { width: 1500, height: 950 },
});
const page = await browser.newPage();
const logs = [];
page.on("console", (m) => logs.push(`[console.${m.type()}] ${m.text()}`));
page.on("pageerror", (e) => logs.push(`[pageerror] ${e.message}`));
page.on("requestfailed", (r) => logs.push(`[requestfailed] ${r.url()} ${r.failure()?.errorText ?? ""}`));

let failed = 0;
const check = (label, ok, extra = "") => {
	if (ok) console.log(`  ok    ${label}`);
	else { failed++; console.log(`  FAIL  ${label} ${extra}`); }
};

const dump = async (label) => {
	const s = await page.evaluate(() => ({
		buttons: [...document.querySelectorAll("button")].map((b) => b.textContent.trim().replace(/\s+/g, " ").slice(0, 28)).filter(Boolean).slice(0, 30),
		body: document.body.textContent.replace(/\s+/g, " ").slice(0, 260),
	}));
	console.log(`\n-- ${label} --`);
	console.log("buttons:", JSON.stringify(s.buttons));
	console.log("body:", s.body);
	return s;
};

await page.goto(GUI, { waitUntil: "networkidle2", timeout: 30000 });
await new Promise((r) => setTimeout(r, 4500));
await dump("initial");

// Step 1: New Session
await page.evaluate(() => { const b = [...document.querySelectorAll("button")].find((x) => /新会话|New Session/.test(x.textContent)); if (b) b.click(); });
await new Promise((r) => setTimeout(r, 2500));
await dump("after new-session click");

// Step 2: if a workspace picker appeared, click a workspace row (not the header button)
await page.evaluate(() => {
	// candidates: elements (not buttons) with workspace names
	const ws = [...document.querySelectorAll("button, [role=option], li, div")].find((el) => {
		const t = el.textContent.trim();
		return t === "new project" || t === "pallas-bot-ai" || /添加工作区/.test(t);
	});
	if (ws) ws.click();
});
await new Promise((r) => setTimeout(r, 3500));
await dump("after workspace pick");

// Look for the conversation view tabs
const tabs = await page.evaluate(() =>
	[...document.querySelectorAll("button,[role=tab]")]
		.map((el) => el.textContent.trim().replace(/\s+/g, " ").slice(0, 30))
		.filter((t) => /轨迹|对话|SSH|Chat|Trajectory|远程/.test(t))
);
console.log("\ntabs found:", JSON.stringify(tabs));
check("SSH tab present", tabs.some((t) => t.includes("SSH")));

const clicked = await page.evaluate(() => {
	const b = [...document.querySelectorAll("button,[role=tab]")].find((el) => el.textContent && el.textContent.includes("SSH"));
	if (!b) return false;
	b.click();
	return true;
});
check("SSH tab clickable", clicked);
await new Promise((r) => setTimeout(r, 5000));

const view = await page.evaluate(() => {
	const text = document.body.textContent;
	const splitter = [...document.querySelectorAll("div")].find((el) => getComputedStyle(el).cursor === "col-resize");
	const filePane = [...document.querySelectorAll("div")].find((el) => {
		const s = getComputedStyle(el);
		return s.flexShrink === "0" && el.offsetWidth > 100 && el.offsetWidth < 600 && el.textContent.includes("boot");
	});
	return {
		hasSshHeader: text.includes("SSH \u8FDC\u7A0B\u63A7\u5236"),
		hasFiles: text.includes("\u4E0A\u4F20") && text.includes("boot"),
		hasTerm: !!document.querySelector(".xterm"),
		splitterFound: !!splitter,
		fileWidth: filePane ? filePane.offsetWidth : null,
	};
});
console.log("\nconsole view:", JSON.stringify(view));
check("full-page header", view.hasSshHeader);
check("file pane with remote listing", view.hasFiles);
check("xterm terminal present", view.hasTerm);
check("draggable splitter present", view.splitterFound);

if (view.splitterFound) {
	const before = view.fileWidth;
	await page.evaluate(() => {
		const splitter = [...document.querySelectorAll("div")].find((el) => getComputedStyle(el).cursor === "col-resize");
		if (!splitter) return;
		const r = splitter.getBoundingClientRect();
		const startX = r.left + r.width / 2, startY = r.top + r.height / 2;
		const dispatch = (type, x) => splitter.dispatchEvent(new MouseEvent(type, { clientX: x, clientY: startY, bubbles: true }));
		dispatch("mousedown", startX);
		for (let i = 1; i <= 5; i++) dispatch("mousemove", startX + i * 30);
		dispatch("mouseup", startX + 150);
	});
	await new Promise((r) => setTimeout(r, 1500));
	const after = await page.evaluate(() => {
		const p = [...document.querySelectorAll("div")].find((el) => {
			const s = getComputedStyle(el);
			return s.flexShrink === "0" && el.offsetWidth > 100 && el.offsetWidth < 600 && el.textContent.includes("boot");
		});
		return p ? p.offsetWidth : null;
	});
	console.log(`splitter drag: before=${before} after=${after}`);
	check("splitter drag changes width", after !== null && after > (before ?? 0) + 50, `before=${before} after=${after}`);
}

await page.screenshot({ path: "F:\\new project\\dsh-tool-ssh\\test\\panel-v4.png" });
console.log("\n== errors ==");
for (const l of logs) console.log(l);
console.log(failed === 0 ? "\nALL PASSED" : `\n${failed} CHECK(S) FAILED`);
await browser.close();
process.exit(failed === 0 ? 0 : 1);
