/**
 * HTTP-layer integration test for the /term/stream SSE handler ordering bug:
 * writeHead must run BEFORE attachWriter (which replays synchronously).
 * The old order sent implicit headers, then threw ERR_HTTP_HEADERS_SENT,
 * killing the live stream (typing/Enter produced nothing until a remount).
 *
 * Run:  node test/ui-stream-http.mjs
 */
import ssh2 from "ssh2";
import { mountUi, UiTerminalRegistry } from "../lib/ui.js";

const { Server, utils } = ssh2;
const keyPair = utils.generateKeyPairSync("ed25519");

let remoteCounter = 0;
const server = new Server({ hostKeys: [keyPair.private] }, (client) => {
	client.on("authentication", (ctx) => {
		if (ctx.method === "password" && ctx.password === "password") ctx.accept();
		else ctx.reject(["password"]);
	});
	client.on("ready", () => {
		client.on("session", (accept) => {
			const session = accept();
			session.on("pty", (acceptPty) => acceptPty && acceptPty());
			session.on("shell", (accept2) => {
				const stream = accept2();
				let buf = "";
				stream.on("data", (d) => {
					buf += d.toString("utf8");
					let idx;
					while ((idx = buf.indexOf("\n")) >= 0) {
						const line = buf.slice(0, idx).trim();
						buf = buf.slice(idx + 1);
						if (line === "exit") { stream.end(); return; }
						stream.write(`echo:${line}\r\n`);
					}
				});
				stream.on("close", () => { try { stream.end(); } catch { /* ignore */ } });
			});
		});
	});
});

await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
const port = server.address().port;

const manager = {
	getConnection: () => ({ name: "local", host: "127.0.0.1", port, username: "demo", password: "password" })
};

// Capture the routes mountUi registers against a fake webServer.
const routes = [];
const httpCtx = {
	effect: (fn) => fn(),
	webServer: { register: (r) => { routes.push(r); return () => {}; } }
};
const ctx = {
	logger: () => ({ warn() {}, info() {}, error() {} }),
	effect: () => () => {},
	inject: (names, cb) => cb(httpCtx)
};
// mountUi registers routes against the fake webServer and returns its
// internal terminal registry (which the stream handler operates on).
const registry = mountUi(ctx, manager, {});

let failed = 0;
const check = (label, ok, extra = "") => {
	if (ok) console.log(`  ok    ${label}`);
	else { failed++; console.log(`  FAIL  ${label} ${extra}`); }
};
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

try {
	const id = await registry.open("local", 80, 24);
	check("session opened", !!registry.get(id));

	// Pre-fill some output so the replay has content.
	registry.get(id).stream.write("hello\n");
	await sleep(400);

	// Invoke the registered /term/stream handler with mock req/res.
	const streamRoute = routes.find((r) => r.path === "/plugins/dsh-tool-ssh/term/stream");
	check("stream route registered", !!streamRoute);
	const handler = streamRoute && streamRoute.handler;

	const log = [];
	let headCount = 0;
	let headHeaders = null;
	const res = {
		writeHead(status, headers) { headCount++; headHeaders = headers; log.push("HEAD"); },
		write(chunk) { log.push(`W:${chunk}`); return true; },
		end() { log.push("END"); },
		flushHeaders() {}
	};
	const req = {
		method: "GET",
		url: `/plugins/dsh-tool-ssh/term/stream?id=${encodeURIComponent(id)}`,
		headers: {},
		socket: { remoteAddress: "127.0.0.1", setNoDelay() {} },
		on() { return req; }
	};
	await handler(req, res);

	check("writeHead called exactly once", headCount === 1, `count=${headCount}`);
	check("SSE content-type", !!headHeaders && headHeaders["content-type"].includes("text/event-stream"), JSON.stringify(headHeaders));
	// The critical ordering: no write before HEAD, and the replay arrived.
	const firstWrite = log.findIndex((l) => l.startsWith("W:"));
	const headIdx = log.indexOf("HEAD");
	check("no writes before writeHead", firstWrite === -1 || headIdx === -1 || firstWrite > headIdx, JSON.stringify(log.slice(0, 6)));
	check("replay delivered in response", log.some((l) => l.includes("hello")), JSON.stringify(log.slice(0, 4)));

	// Live path: a command typed now must produce a live frame immediately.
	const before = log.length;
	registry.get(id).stream.write("live\n");
	await sleep(400);
	const liveFrames = log.slice(before).filter((l) => l.includes("live"));
	check("live output streamed immediately", liveFrames.length > 0, JSON.stringify(log.slice(before)));
	check("response not ended prematurely", !log.includes("END") || log.indexOf("END") > log.length - 1, log.slice(-2).join("|"));
} catch (err) {
	failed++;
	console.error("  FATAL", err);
} finally {
	registry.closeAll();
	server.close();
}

console.log(failed === 0 ? "\nALL PASSED" : `\n${failed} CHECK(S) FAILED`);
process.exit(failed === 0 ? 0 : 1);
