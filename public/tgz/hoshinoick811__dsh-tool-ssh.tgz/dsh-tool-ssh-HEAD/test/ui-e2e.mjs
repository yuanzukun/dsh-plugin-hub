/**
 * End-to-end test of the dsh-tool-ssh UI endpoints on the running GUI:
 * terminal open → SSE stream → input → read output → close, plus asset and
 * client-module serving checks. Run:  node test/ui-e2e.mjs
 */
const BASE = "http://127.0.0.1:3080/plugins/dsh-tool-ssh";

let failed = 0;
function check(label, condition, extra = "") {
	if (condition) console.log(`  ok    ${label}`);
	else { failed++; console.log(`  FAIL  ${label} ${extra}`); }
}

async function post(path, body) {
	const res = await fetch(BASE + path, {
		method: "POST",
		headers: { "content-type": "application/json" },
		body: JSON.stringify(body),
	});
	return { status: res.status, json: await res.json().catch(() => ({})) };
}

// --- assets & client module ---------------------------------------------
for (const [path, label, probe] of [
	["/assets/xterm.js", "xterm.js served", (t) => t.includes("Terminal")],
	["/assets/xterm.css", "xterm.css served", (t) => t.includes(".xterm")],
	["/client.js", "client.js served", (t) => t.includes("__ModuleLoader__")],
]) {
	try {
		const res = await fetch(BASE + path);
		const text = await res.text();
		check(`${label} (${res.status}, ${text.length} bytes)`, res.ok && probe(text));
	} catch (e) {
		check(label, false, e.message);
	}
}

// --- fs list ------------------------------------------------------------
try {
	const res = await fetch(`${BASE}/fs/list?connection=aliyun&path=/`);
	const j = await res.json();
	check("fs/list returns entries", Array.isArray(j.entries) && j.entries.length > 5, JSON.stringify(j).slice(0, 120));
} catch (e) { check("fs/list", false, e.message); }

// --- terminal flow ------------------------------------------------------
console.log("== terminal ==");
let termId;
try {
	const open = await post("/term/open", { connection: "aliyun", cols: 100, rows: 30 });
	termId = open.json.id;
	check("term/open returns id", open.status === 200 && typeof termId === "string", JSON.stringify(open.json));
} catch (e) { check("term/open", false, e.message); }

if (termId) {
	try {
		// consume SSE for a few seconds, meanwhile send input
		const controller = new AbortController();
		const ssePromise = (async () => {
			const res = await fetch(`${BASE}/term/stream?id=${encodeURIComponent(termId)}`, { signal: controller.signal });
			check("term/stream 200 + event-stream", res.status === 200 && (res.headers.get("content-type") || "").includes("text/event-stream"));
			const reader = res.body.getReader();
			const decoder = new TextDecoder();
			let buffer = "";
			while (true) {
				const { done, value } = await reader.read();
				if (done) break;
				buffer += decoder.decode(value);
				if (buffer.includes("event: data") && buffer.includes("hello-from-dsh-terminal")) break;
			}
			return buffer;
		})();

		// wait for stream to connect, then send input
		await new Promise((r) => setTimeout(r, 1500));
		const input = await post("/term/input", { id: termId, data: "echo hello-from-dsh-terminal\n" });
		check("term/input accepted", input.status === 200, JSON.stringify(input.json));

		const streamText = await Promise.race([
			ssePromise,
			new Promise((_, reject) => setTimeout(() => reject(new Error("SSE timeout")), 15000)),
		]);
		check("SSE carries shell output", streamText.includes("hello-from-dsh-terminal"), streamText.slice(-200));

		// resize
		const resize = await post("/term/resize", { id: termId, cols: 120, rows: 40 });
		check("term/resize accepted", resize.status === 200, JSON.stringify(resize.json));

		// close
		const close = await post("/term/close", { id: termId });
		check("term/close ok", close.status === 200 && close.json.closed === true, JSON.stringify(close.json));
	} catch (e) {
		check("terminal flow", false, e.message);
		try { await post("/term/close", { id: termId }); } catch { /* ignore */ }
	}
}

console.log(failed === 0 ? "\nALL PASSED" : `\n${failed} CHECK(S) FAILED`);
process.exit(failed === 0 ? 0 : 1);
