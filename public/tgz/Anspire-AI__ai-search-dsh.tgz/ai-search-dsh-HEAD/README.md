# @anspire-ai/ai-search-dsh-plugin

Anspire AI Search 的 [DeepSeek Harness (dsh)](https://github.com/deepseek-ai/deepseek-harness) 插件。

为 agent 提供全网搜索能力：网页 / 图片 / 视频检索 + 垂域结构化数据（天气、股票、汇率、油价、万年历等），作为回答实时性问题的依据。## 安装

两种方式任选其一：

**方式一：npm（推荐，版本即发布 tag）**

```bash
dsh plugin --profile <name> add @anspire-ai/ai-search-dsh-plugin
```

**方式二：GitHub（固定 commit，获取未发布的改动）**

```bash
dsh plugin --profile <name> add github:Anspire-AI/ai-search-dsh#develop
# 或固定到具体提交：github:Anspire-AI/ai-search-dsh#<sha>
```

> 两种方式的插件功能完全一致；npm 方式随 `v*` tag 自动发布，GitHub 方式可吃到 develop 分支的最新改动。
> 本插件为纯 JavaScript（无构建步骤），GitHub 安装无需在 `pnpm-workspace.yaml` 中放行构建。

**从旧包名升级**（曾以 `anspire-ai-search-dsh-plugin` 无 scope 名义安装过）：先 `dsh plugin --profile <name> remove anspire-ai-search-dsh-plugin` 再按上述方式安装；已保存的配置（settings.yaml）不受影响。

## 配置

### 方式一：UI 插件设置页（推荐）

启动 dsh 后打开 **Settings → Plugins → anspire-ai-search**，直接在页面配置：

| 配置项 | 说明 |
|--------|------|
| `region` | 服务区域（下拉二选一）：`ai-search-cn`（国内，默认）/ `ai-search-global`（海外） |
| `apiKey` | Anspire API KEY，密钥框输入、自动脱敏；区域下方提供「获取 anspire-ai-search api-key」链接，点击即可前往申请 |
| `timeoutMs` | 请求超时（毫秒），默认 30000 |
| `defaultTopK` | 默认返回条数，默认 10 |

**服务区域**：国内与海外为独立服务，API KEY 不通用。区域与申请入口的对应关系见插件设置页内的链接。

**修改即时生效**（live），无需重启 dsh。配置持久化在 dsh 的 `settings.yaml`，由 dsh 统一管理。

> 卡片在「插件配置」tab 中，与终端/agent 循环/网页搜索并列。展开卡片即可编辑，支持「已覆盖」标记与恢复默认。API KEY 为密钥框输入（不回显）。

### 方式二：环境变量（兜底/CI 场景）

```bash
export ANSPIRE_API_KEY="你的 key"   # 申请入口见插件设置页链接
```

兼容的环境变量名：`ANSPIRE_API_KEY` > `ANPSIRE_API_KEY` > `DSP_ANSPIRE_KEY`（按此顺序取第一个非空）。

优先级：**UI 设置页 > 环境变量**。

### 进阶：patch 行覆盖（部署级默认值）

默认配置（`index.js` schema 默认值）：

```js
{
  region: 'ai-search-cn',   // 服务区域，决定请求端点
  timeoutMs: 30_000,
  defaultTopK: 10,
}
```

在 profile 為 `cordis.patch.yml` 中覆盖（按 id 定位本插件插入的行；`config` 是整体替换，需重述全部键）：

```yaml
# profile 的 cordis.patch.yml（~/.dsh/profiles/<name>/cordis.patch.yml）
- id: anspire-ai-search
  config:
    region: 'ai-search-global'
    timeoutMs: 20000
    defaultTopK: 20
```

## 提供的工具

### `anspire_search`

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `query` | string | ✅ | 搜索词，≤64 字符 |
| `topK` | number | | 返回条数 10/20/30/40/50，默认 10 |
| `insite` | string | | 限定站点，逗号分隔，最多 20 个 |
| `fromTime` | string | | 起始时间 `2025-01-01 00:00:00` |
| `toTime` | string | | 结束时间 |
| `searchType` | string | | `web`（默认）/ `image` / `video` |
| `regionMode` | number | | `0` 国内（默认）/ `1` 海外 / `2` 混合 |

输出为编号列表文本：标题 / 摘要 / 链接 / 日期 / 相关度。垂类词（如「北京天气」）自动返回结构化垂域数据。

## 开发

```bash
git clone git@github.com:Anspire-AI/ai-search-dsh.git
cd anspire-ai-search/code        # develop 分支即 bundle 根
node --test 'test/*.test.js'     # 运行测试（Node ≥18，零依赖）
```

### 发布（npm）

打 tag 自动发布（CI：测试 → 版本同步自 tag → pack 冒烟 → OIDC 发布）：

```bash
git tag v0.5.0 && git push origin v0.5.0
```

前置（一次性）：npm org `@anspire-ai` 的 Trusted Publisher 已配置指向本仓库的 `publish-npm.yml`。

### bundle 结构说明

- `cordis.patch.yml` 用 `- insert: [...]` 块向 entry 列表**追加**插件行。不要写成裸 `- id:` 行——那是「覆盖已存在 entry」语义，目标不存在时整条 patch 会被 loader 静默跳过（`patch: entry not found`），插件不加载。
- `index.js` 不导出 `Config`。cordis loader 要求 `Config["~standard"].validate`（Standard Schema 接口），普通对象会 TypeError。配置直接经 patch 行的 `config` 键流入 `apply(ctx, config)`，未提供时用内置默认值。

## License

MIT
