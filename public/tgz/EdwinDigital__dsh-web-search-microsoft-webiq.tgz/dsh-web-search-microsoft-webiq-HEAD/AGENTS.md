# AGENTS.md

An out-of-tree DeepSeek Harness plugin: the Microsoft Web IQ provider for the `ctx.web` search seam, plus the browser bundle-configuration page that configures it.

## Relationship to the harness conventions

This package is developed against the DeepSeek Harness but lives outside its workspace, so the harness `AGENTS.md` and `packages/AGENTS.md` are the upstream authority and this file records only what differs or what an out-of-tree checkout cannot infer. Where the two disagree the harness wins, because a package that drifts from the seam it plugs into breaks at load, not at review. Nothing here re-states a rule that already holds verbatim upstream.

The harness gates (`verify-export-jsdoc`, `verify-package-invariants`, `verify-package-meta`, `verify-package-readme-limitations`, `verify-translation-pairing`, `doc-sync`) are workspace scripts and **do not reach this package**. Every obligation they would enforce is maintained by hand here; the sections below name the ones that have already been violated once.

[docs/plugin-conventions.md](docs/plugin-conventions.md) carries the harness contracts themselves — the search-provider interface, volatile configuration, credential handling, browser delivery, package metadata, and README format — each cited to its harness page. **Read it before changing provider behaviour, the settings item, or the manifest, and keep the change conforming to it.** It also lists the workspace rules that deliberately do not bind an out-of-tree package, so a harness rule is not adopted here by reflex, and it records the conformance gaps that are currently open.

## Repository layout

```
src/            plugin source; the Host half (index/provider) and the browser half (client/)
  types.ts      types only — no runtime code
  client/       browser bundle-config page, its controller, locales, and CSS Modules
locale/         package display metadata discovered without activating the plugin
icon.svg        manifest artwork shown by Plugin Manager and Settings
lib/            committed build artifact — see "The committed artifact"
tests/          vitest specs at package level, never src/__tests__/
docs/           plugin-conventions.md, the harness contracts this package owes
  images/       README screenshots, referenced by relative path
cordis.patch.yml  the composition layer `dsh plugin add` appends
```

## Commands

| Command | What it does |
|---|---|
| `npm run build` | `tsc -b` emits declarations and JS under `lib/types`, then `tsdown` bundles both halves. The order is load-bearing: tsdown's entries are `lib/types/*.js`, so a bundle without a preceding `tsc -b` is stale or missing. |
| `npm run typecheck` | `tsc -b` alone. |

There is **no test script and no installed runner**. The specs under `tests/` are vitest and import `../src/*.ts` directly, so they execute only where vitest and the harness packages both resolve — a harness checkout with this package linked in. Do not report the suite as passing from this checkout alone.

Type checking has the same prerequisite. Every harness dependency is an **optional peer** that this repository deliberately leaves unresolved, and there is no published release to install them from, so point the peers at a harness checkout by linking its workspace packages into `node_modules` before running either command.

Harness peers declare the reviewed compatibility line `>=0.2.0-rc.2 <0.3.0-0`. Keep the explicit `0.2.0` prerelease comparator: replacing it with `*` or a broad range silently excludes prerelease builds under node-semver. A new prerelease tuple requires a compatibility audit before widening the range.

## The committed artifact

`lib/` is tracked so a git install needs no build step, which keeps the harness peer dependencies out of the installer's own resolution. `.gitignore` keeps only what the manifest publishes and drops tsc's incidental emit under `lib/types`.

That trade moves an obligation onto every change: **rebuild and commit `lib/` in the same commit as any `src/` edit.** Nothing enforces it and a stale artifact is silent — installers keep resolving the previous code with no warning at any layer. `git status` after a build is the check, and it works because the build is deterministic: repeated builds of unchanged sources produce byte-identical output, so any diff is a real change.

The browser half is bundled to the harness client-loader contract — a CJS closure handed to `window.__ModuleLoader__.load`, platform modules external so they resolve from the frozen module table, CSS Modules compiled through lightningcss into one injected style tag. That contract lives in a harness build helper that is not a published package, so `tsdown.config.ts` reproduces it here. A harness change to the loader format breaks this plugin at load time; the wrapper header in `lib/client.js` is what to compare against.

## Conventions

- **Function-plugin form, no default export.** `src/index.ts` named-exports `name` / `inject` / `Config` / `apply`. Adding a default export makes the Loader discard the namespace.
- **Optional services go through `ctx.get(name)`.** Only `web` is a declared injection; `credentials` and the launch environment are read per operation and may legitimately be absent.
- **Heritage-declared members carry no JSDoc here.** `available()` and `search()` document at the declaring `WebSearchProvider` interface, and duplicating those docs is the error, not the omission.
- **No hardcoded tunables.** Deployment-varying choices are validated `Config` fields changeable from `cordis.yml`; a `DEFAULT_*` constant is not configurability. Protocol constants and the Web IQ request contract stay fixed.
- **Live fields are `Volatile<T>`.** Read every field once at search start with `.get()`; a settings write affects the next search without replacing the plugin instance, while an in-flight search keeps its captured values.
- **Browser configuration uses the shared form service.** Bind `web-search-microsoft-webiq` and `web` through `ctx.configForms`, register under `plugins.bundle.config` with this package's npm name only while the provider entry is served, and use the credentials Remote namespace for write-only key changes. `plugins.item` is reserved for companion pages shipped with the Harness.
- **Misconfiguration fails loud.** `validateConfig` throws at load and operation entry for what is self-contained; a credential that cannot be resolved fails the operation with `WEB_PROVIDER_CREDENTIAL_MISSING` naming only the reference.
- **The credential-bearing request refuses redirects.** `redirect: 'error'` is a security invariant of sending the key to the configured endpoint, not a preference.
- **Secrets never widen.** The key literal is `role('secret')`, and it stays out of Settings descriptions, browser boot data, logs, and error messages.
- **No `./invariant` companion.** The package owns no independently observable mutable relationship, and current harness rules forbid empty companions or service-presence checks.
- **Files end with exactly one trailing newline.**

## Documentation

`README.md` and `README.zh.md` are a bilingual pair of equal authority: edit one and bring the other along in the same commit, keeping headings, code fences, and tables structurally identical.

`README.i18n.yaml` records the git blob hash of each side as of the last confirmed-consistent state. **Recompute it with `git hash-object README.md README.zh.md` before every commit that touches either file.** This has gone stale twice; a hash that no longer matches is worse than no record, because it asserts a consistency nobody checked.

Behaviour changes carry their docs in the same commit — config keys, defaults, error codes, and request or response fields all surface in the README. The README keeps the canonical Model Experience format (an H3 entry with `#### What the model sees`, `#### Token effect`, and `#### KV Cache effect`) and puts durable consumer gaps under `## Known Limitations and Deferred Work`. Write those from the model's perspective: task-relevant concepts only, no transport or implementation vocabulary.

Prose is current-state, one physical line per paragraph, one home per fact. State contracts and consequences rather than narrating changes or preserving review history.

## Distribution

`package.json` declares `dsh.bundle.patch`, which makes the installed bundle layer apply `cordis.patch.yml` after the shipped profile bundles. The patch inserts this package's own entry and selects `microsoft-webiq` in the existing `web` entry so a first installation works without a second enablement step; because that bundle layer remains present, the settings switch restores `deepseek-official` by writing an explicit profile user override rather than by unsetting the field. It composes no other package, because a patch row naming a package the profile cannot resolve fails the whole load.

The marketplace entry lives in the `awesome-dsh-plugin` repository under `data/plugins/`, with screenshots keyed by repository URL in `data/screenshots.json`. Both READMEs there are generated — never hand-edit them, and change only this package's own entry.

Pushing a `v*` tag runs [.github/workflows/publish.yml](.github/workflows/publish.yml), which publishes to npm. It installs nothing and builds nothing, because the harness peers are unresolvable on a runner and `lib/` is committed anyway; it guards the tag against the manifest version, checks the artifact is present, and rejects a payload carrying sources or maps. **So the tag must point at a commit whose `lib/` is already current** — the workflow cannot rebuild it, and a stale artifact publishes silently.

## Editing these instructions

Keep each rule self-contained and verifiable against the code. Delete a rule when the behaviour it describes is gone; a convention document that outlives its subject teaches the wrong thing.
