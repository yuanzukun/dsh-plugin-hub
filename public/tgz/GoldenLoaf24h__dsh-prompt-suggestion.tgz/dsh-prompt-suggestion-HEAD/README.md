# dsh-prompt-suggestion

Claude Code 风格的「下一步提示预测」：每轮结束后，输入框内以灰色 ghost text 显示模型预测的下一句用户提示。

![输入框里的灰色预测](assets/composer.png)

![插件页里的设置项](assets/settings.png)

## 行为

| 操作 | 结果 |
| --- | --- |
| `Tab` | 把整条预测填入输入框（可继续编辑，不发送） |
| `Alt` + `→` | 按词逐步填入预测，剩下的仍显示为灰字 |
| `Enter` | 把预测填入并立即发送（可在设置里关掉） |
| `Esc` | 忽略本次预测，并标记该轮不再提示 |
| 直接打字 | 预测自动消失；擦回原样后又会出现 |
| `Alt` + `R` | 换一条预测（旧的那条作为「不要重复」传给模型） |
| `↑` | 空输入框时填入本会话上一条已发送的提示（不是忽略预测，清空后灰字会回来） |

另有一条独立的**历史前缀补全**：输入几个字后，若本会话发过以它开头的提示，剩余部分会以灰字补出来（同样 `Tab` 采纳）。它和预测互不干扰——预测不再匹配当前输入时会自动让位给补全，不会把补全挡掉。

预测只在一轮任务结束、输入框为空、没有命令 chip、且会话不在运行时出现。同一轮重复请求命中磁盘缓存，不会重复调用模型；打开一个会话只读缓存、零模型调用，缓存缺失（会话早于插件安装，或条目过期）才补一次真实调用。若那次补调用失败，一分钟后再自动重试一次——不会因为一次超时就让输入框一直空着。`Tab` 采纳只影响当前这一屏，刷新页面仍会看到同一条；只有 `Esc` 才会把该轮标记为「不再提示」并落盘。

## 设置

「插件 → 提示预测」页面里可改，全部持久化到 `~/.dsh/plugin-data/dsh-prompt-suggestion/settings.json`：

- **启用下一步预测** — 总开关
- **模型服务商 / 模型** — 留空则跟随当前会话实际使用的 route；选了服务商后模型变成下拉，选项来自该 adapter 真实发布的目录
- **思考强度** — `自动（最省）` 问 route 要它最便宜的档位；也可显式指定 `off`/`low`/`high`/`max`
- **Alt + → 逐词采纳 / Enter 采纳并发送 / 历史前缀补全 / ↑ 回填上一条** — 四个独立开关
- **生成参数** — 预测最长字数、超时、输出上限、携带最近消息条数、上下文字符上限
- **上下文脱敏** — 发模型前抹掉密钥、令牌、密码等敏感串
- **最近预测** — 最近若干条的原文、耗时、所用模型

## 实现

**host**（`lib/index.js`，零第三方依赖）

- 路由：`/suggest`（取预测）、`/session`（上一条提示 + 历史）、`/dismiss`（标记忽略）、`/catalog`（服务商/模型/思考档位）、`/settings`（GET/POST）
- 用 `ctx.llm.prepareCall` + `call.stream` 发一次辅助调用；`purpose` 不设（该字段只接受 `compaction`/`session-title`）
- **思考强度阶梯**：`auto` 取 route 声明的最便宜档位；显式档位被 adapter 拒绝（`UNSUPPORTED_REASONING_EFFORT`）时自动降级重试；`''`（不传该字段，会继承会话的 `max`）永远排在最后
- **空返回加宽重试**：输出被思考 token 吃光时翻倍 `maxTokens` 再试一次
- transcript 来自 `session.deriveMessages()`，只取真人/助手文本，尾部按消息条数与字符数双预算裁剪
- 结果按「最后一个 `turn/end` 的 seq」缓存；失败（超时、模型空返回）**只在内存里压一分钟**、绝不写盘，所以一次模型抖动不会把这一轮永久钉死成「无预测」，重启即重试
- 自定义路由**不经过**宿主的 cookie 鉴权，因此自带一道 `Origin`/`Sec-Fetch-Site` 同源 fence

**client**（`lib/client.js`）

- 注册两个槽位：`conversation.input.overlay`（输入框里的灰字与按键）和 `plugins.bundle.config`（插件页的设置表单）
- 灰字挂在编辑器末段落的 `::after` 上，文本经**继承的 CSS 自定义属性** `--dsh-ps-ghost` 传入。不能用 `content: attr(...)`：Lexical 每次编辑都重建那个 `<p>`，属性会随之丢失；自定义属性设在编辑器上则一直继承下去。空编辑器（Lexical 一个 `<p>` 都不渲染）走 `:not(:has(> p, > div))::after` 兜底
- 按键在卡片上以**捕获阶段**监听，早于 Lexical 自己的 keymap；采纳走 `inputActions.captureInsertion()` + `insertText()`（带版本校验、可撤销），失败才退回 `setDraft()`

## 安装

本目录是一个标准 DSH bundle（`dsh.bundle.patch` 指向 `cordis.patch.yml`）：

1. **桌面端插件面板**（`desktop` profile 唯一可用的方式，它被 Electron 独占）：插件 → 添加插件 → 填本目录绝对路径，或 `github:GoldenLoaf24h/dsh-prompt-suggestion`
2. **CLI**（非 desktop profile）：`dsh plugin --profile <profile> add github:GoldenLoaf24h/dsh-prompt-suggestion`
3. **Agent 会话内**：`plugin_manager({action:'install_bundle', target:'github:GoldenLoaf24h/dsh-prompt-suggestion'})`

纯 JS、无构建步骤、零第三方运行时依赖，源码装即可用。装完后 `package.json` 的 `dsh.profile.bundles` 会自动登记。改 `lib/index.js` 需要在插件面板关掉再打开（host 半不热更新），改 `lib/client.js` 刷新页面即可。

## 配置

```yaml
- id: prompt-suggestion
  name: dsh-prompt-suggestion
  config:
    enabled: true   # 与设置页里的开关等价，设置页优先
```
