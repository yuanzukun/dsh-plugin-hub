# @xrn1997/dsh-session-delete

[![CI](https://github.com/xrn1997/dsh-session-delete/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/xrn1997/dsh-session-delete/actions/workflows/ci.yml)
[![npm version](https://img.shields.io/npm/v/@xrn1997/dsh-session-delete.svg)](https://www.npmjs.com/package/@xrn1997/dsh-session-delete)
[![License: Apache-2.0](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](LICENSE)
[![Tested with DSH 0.2.0-rc.2 … 0.2.2-rc.5](https://img.shields.io/badge/DSH-0.2.0--rc.2%20%E2%80%A6%200.2.2--rc.5-brightgreen)](#兼容性)

> **DeepSeek Harness（DSH）会话回收站插件** —— DSH 原生只有「归档」没有删除。本插件补上「移入回收站」：会话移进本地回收站、随时还原；彻底删除是另一件显式动作。

![回收站面板：顶部是「回收站 | 归档」平级分段；左列是按项目分组的无边框会话行（行右是恢复 / 彻底删除图标按钮），右栏是会话信息表、计量行、收起成摘要条的子会话段与四档「工作步骤」正文，右缘是提问轨，页脚是整页唯一的实心红按钮「清空回收站…」](docs/screenshots/screenshot-01.png)

- 安装：`dsh plugin --profile <profile> add @xrn1997/dsh-session-delete`（装完重启宿主）
- 许可：[Apache-2.0](LICENSE) · 运行环境：`Node.js >= 24` · 兼容性见[下文](#兼容性)
- 数据：回收站留在本机 `$DSH_HOME/session-trash/`（默认 `~/.dsh/session-trash/`），不联网、不上传

## 核心特性

- **移入回收站（可恢复）**：会话行「⋯」→「移入回收站」即执行，不弹确认框，同时出现一条 6 秒的「撤销」；也可直接把会话行拖到侧栏「回收站」入口松手即移入回收站；误操作靠撤销横幅与可恢复的回收站兜底。把正打开着的会话移入回收站时对话随之关闭，点撤销会重新打开。
- **按整组移入回收站**：父会话与它的子代理后代一起移入；任一会话在跑就整组拒绝、零副作用（「在新对话中分支」出来的 fork 是独立会话）。
- **批量操作**：宿主会话列表「⋯ → 多选」勾选后点「移入回收站」即批量执行（支持 `Shift`+点击范围勾选，拖其中一条到侧栏回收站可一拖把整集移入回收站），成功的 6 秒内可整批撤销；回收站面板里另有「多选」（同样支持 `Shift`+点击范围勾选），可批量恢复或批量彻底删除。失败不连坐，勾选收缩到失败项，可再点一次重试。
- **看得见的写入进度**：批量恢复与彻底删除、清空回收站在飞时，确认框显示服务端真实处理到的条目数、当前步骤与已用时间；单条恢复是即执行、没有确认框，撤销横幅里的恢复动作把同一条进度行放上横幅；排在另一趟写入后面时只显示排队中，不冒用别的进度。
- **回收站面板**：左侧清单右侧详情、按项目分组、分栏可拖；「归档」档与回收站平级，已归档会话可只读预览、一步解除归档或移入回收站。
- **看得见正文再决定**：详情完整还原对话（提问、助手文字与思考、工具调用与结果、注入上下文、系统消息与压缩标记），长会话可「加载更早」分页；正文有「简洁 / 标准 / 详细 / 完全展开」四档，默认「标准」把连续过程块收成一行「工作步骤」，点开仍逐条折叠；右缘提问轨一点跳到那句；子会话收起成摘要条、点开进孩子详情；图片可放大、文件可下载。
- **显式彻底删除**：单条与「清空回收站…」都带二次确认；单条报这一次释放多少，批量报条数，清空只报不可恢复；**永不自动过期**。
- **手动维护**：设置页「维护」卡检查并清理「孤儿会话」「孤儿附件」「投影缓存」，看过结果再决定，不自动扫描。
- **可调项有表单**：设置页「可调项」卡直接改三只旋钮，也可以改 profile 的 `cordis.patch.yml`。
- **多语言与容错**：界面跟随宿主语言（中文 / English，服务不可用时回退内置中文）；通道探测不过时不注册任何入口。

## 安装

```bash
dsh plugin --profile <profile> add @xrn1997/dsh-session-delete
```

装完**重启宿主**（Node 半不走热重载）。三种装法：

- **npm**（推荐）：预构建产物，秒装。
- **GitHub Release**：在 Release 页下载 tarball，再按下面的离线分发安装——URL 形态的 `add` 在桌面 0.2.2-rc.3 实测**不通**（宿主交给 bundled pnpm 拉 tarball 会失败）。钉版本下载：`https://github.com/xrn1997/dsh-session-delete/releases/download/V<版本>/xrn1997-dsh-session-delete-<版本>.tgz`。
- **离线分发**：`pnpm pack` 出 tarball 后 `dsh plugin --profile <profile> add ./xrn1997-dsh-session-delete-<版本>.tgz`。

卸载只移除插件：`dsh plugin --profile <profile> remove @xrn1997/dsh-session-delete`。`$DSH_HOME/session-trash/` 里已有的回收站不会被自动清理。

## 兼容性

- **装得上**：由 `package.json` 的 `engines.dsh` 表达，窗口是 **`>=0.1.7-rc.2 <0.3.0-0`**（预发布版本参与匹配）；窗口外没有支持面。当前宿主安装器与加载器并不强制校验这份声明（ADR-0046）。
- **真跑过**：桌面真机实测名单是 **DSH Desktop 0.2.0-rc.2、0.2.1-rc.1、0.2.1-rc.2、0.2.1-rc.3、0.2.1-rc.5、0.2.2-rc.1、0.2.2-rc.2、0.2.2-rc.3、0.2.2-rc.5**；窗口内其他版本没实测过。
- **多 Peer 部署**：接口的 owner 校验（非 owner 回 403）自 `0.2.1-alpha.3` 起才有；要跑多 Peer，优先选名单里 `0.2.1-rc.1` 起的实测代次。

## 使用指南

**单条移入回收站**：会话行「⋯」→「移入回收站」即执行，这条会话所在的组（含子会话）移入回收站；点顶部提示条里的「撤销」恢复。也可以直接把会话行拖到侧栏「回收站」入口松手即移入回收站。正在运行的会话菜单项置灰（0.2.2 起显示「移入回收站（运行中）」，≤0.2.1 用 tooltip 说明先停止）；拖放运行中的会话会抖动拒收；**列表里看不见的子会话在跑也算**——服务端整组拒绝并回原文。

![会话行的「⋯」菜单：宿主原有动作之后，本插件加了「多选」与红色的「移入回收站」两行](docs/screenshots/screenshot-02.png)

**批量移入回收站**：「⋯」→「多选」进入批量模式，勾选（支持 `Shift`+点击连续范围勾选）后点浮条里的「移入回收站」即完成，或直接拖动勾选集内的任一行到侧栏「回收站」入口整批移入回收站。

![多选批量模式：两行已勾选，浮条显示「已选 2 条」与展开的已选清单，动作是「移入回收站 2 条」与「退出多选」](docs/screenshots/screenshot-03.png)

**浏览与恢复**：侧栏「回收站」入口进两栏面板（窄屏下钻），顶部切换「回收站 | 归档」两档。左列按项目分组，右侧预览正文；「恢复」送回原项目（原工作区不在了归入「未分组」），「彻底删除」或「清空回收站…」永久释放空间，两者共用二次确认。归档档里可一步解除归档；归档档里的会话移入回收站后撤销，回到的是「归档」。

## 数据存储与安全

| 项目 | 说明 |
| :--- | :--- |
| **本地回收站** | `$DSH_HOME/session-trash/`（默认 `~/.dsh/session-trash/`），与会话目录同卷；搬进搬出是整目录重命名，原子。 |
| **回收站清单** | 本插件自己的存储域（介质在 `$DSH_HOME/storages/`）；会话文件自带 `id` 与 `cwd`，清单丢了也不影响识别与恢复，读取前自动与回收站目录对账。 |
| **保留期限** | **永不自动过期**，无天数或容量上限；释放空间是显式动作。 |
| **附件** | 移入回收站不碰附件；彻底删除只清仅被这些会话引用的 `.dsh` 内图片副本——共享副本保留、源文件不受影响；普通文件只渲染、不代删。对象在 `.dsh/attachments/v1/objects/`。 |
| **投影缓存** | 宿主缓存只写不删：永久删除顺手带走被删会话自己的记录；存量孤儿由维护卡手动清（派生数据，可重建）。 |
| **网络** | 全程本地，不联网、不上传。 |

## 可调项

三只旋钮都有默认值，可在设置页「可调项」卡或 profile 的 `cordis.patch.yml` 里改：

| 键 | 默认值 | 作用 |
| --- | --- | --- |
| `orphanPreviewLimit` | `200` | 「孤儿附件」预览清单的条数（数量与字节仍按全量报告） |
| `maxAttachmentBytes` | `20971520`（20 MiB） | 附件单次读取的字节上限 |
| `maxJsonRefBytes` | `10485760`（10 MiB） | 附件引用扫描里单个 JSON 引用源的字节上限 |

```yaml
- insert:
    - id: xrn1997-session-delete
      name: '@xrn1997/dsh-session-delete'
      config:
        orphanPreviewLimit: 200
        maxAttachmentBytes: 20971520
        maxJsonRefBytes: 10485760
```

激活时归一：未知键、非整数或越界会让这一条激活失败（不会用半套配置启动）。

## 常见问题

**装完侧栏没有「回收站」，会话菜单里也没有「移入回收站」？**
先重启宿主。若仍没有，说明这台宿主没通过数据通道探测——插件会隐藏全部入口，这是有意的「不可用」表达，不影响宿主稳定性。

**移入回收站后侧栏那一行没有立刻消失？**
插件只在确认宿主列表已真正移除后才移除行；短暂残留刷新页面即可。

**正在运行的会话为什么不能移入回收站？**
本行菜单项置灰；看不见的子会话在跑时由服务端整组拒绝并回原文。插件不替你终止任务，先停止再移入回收站。

**批量移入回收站 / 恢复只成功了一部分？**
逐条交回结果、失败不连坐；失败的留在原位并显示原文。宿主列表批量失败时勾选自动收缩到失败项，再点一次「移入回收站」只处理失败名单；回收站面板的逐条失败落在对应行上。

**把工作区删了，回收站里的会话还能恢复吗？**
能。恢复照常回盘，只跳过账本挂接，归入「未分组」。

**点文件下载失败，页面没有提示？**
下载走浏览器原生行为：宿主回错误响应时浏览器可能把错误页存成文件，页面内拿不到原因。换一条能下载的会话 / 文件，或直接从会话目录取原件。

**把会话目录手工搬回 `sessions/` 了，为什么列表里没有？**
手工搬回不是恢复，下一次读清单会把那一行对账掉；请在面板里点「恢复」。

**在局域网 IP 或自定义域名下访问 Web 端，入口不出现或提示校验异常？**
身份校验托管于宿主：访问域名 / IP 写进宿主 `client-connection` 的 `trustedHosts`，反向代理保留原始 `Host`，绑定地址用具体 IP。附件字节段另有插件的同源取数闸：同站 / 跨站页面与 authority 对不上的 `Origin` / `Referer` 会被拒（403 信封）。

## 开发与文档

```bash
pnpm install
pnpm gates   # 类型检查 + Lint + 单测 + 构建 + 打包预检
```

更多：[开发与调试](https://github.com/xrn1997/dsh-session-delete/blob/main/docs/development.md) · [系统架构](https://github.com/xrn1997/dsh-session-delete/blob/main/docs/architecture.md) · [界面规格](https://github.com/xrn1997/dsh-session-delete/blob/main/docs/ui-spec.md) · [更新日志](https://github.com/xrn1997/dsh-session-delete/blob/main/CHANGELOG.md) · [决策记录](https://github.com/xrn1997/dsh-session-delete/blob/main/docs/adr/README.md)

## 贡献与许可

欢迎提交 Issue 与 PR，参与前请先阅读 [CONTRIBUTING.md](https://github.com/xrn1997/dsh-session-delete/blob/main/CONTRIBUTING.md)。

- 主体代码基于 [Apache-2.0](LICENSE) 协议开源。
- 部分 UI 与 Markdown 渲染控件派生自 DeepSeek Harness（MIT 协议），内联第三方依赖许可声明见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)。
