# ADR-0004 — 路由表是一条记录，`dispatch` 读它

Status: accepted

## 背景

一条请求要过三道判断，而这三道判断的**同一份知识**分散在两个函数里：

| 判断 | 住在哪 | 怎么维持一致 |
| --- | --- | --- |
| 这个段名该用什么方法 | `dispatch()` 里六个 `if` 各调一次 `requireMethod` | 手写 |
| 这个段名纯不纯（要不要进到达序链） | `purityOf()` 里另一组 `if` | **注释**（「必须与上面那份一致」） |
| 这个段名要不要预读 body | `purityOf()` | 手写 |

两处不一致的后果都不轻，而且都不好在测试里撞见：

- 该纯的判成写 ⇒ 一次探测/大正文读把删除按钮堵在串行链后面；
- 该写的判成纯 ⇒ 写动作绕开到达序链，与对账交错，回收站出现「目录在、行是降级元数据」的世界；
- body 该读没读 ⇒ 下游拿到 `null`；读了两遍 ⇒ 请求流已被消费（`dispatch.ts` 的注释专门强调过这一点）。

此外 `APPLY_ACTIONS` 是 `ApplyAction` 联合在**运行期的手抄副本**，注释原文承认「必须同进同退」。

## 决定

1. 新增 `src/api/route-table.ts`（Node 半私有——浏览器半要 import `wire.ts`，值 import 会把 Node 半拖进 bundle）：
   每个段名一行，字段以 `RouteSpec` 为准。其中 `method` 的字面量家在 `wire.ts` 的
   结构化段名表（`ROUTES` 每项恰有 `{ path, method }` 两键），路由记录只投影（`method: ROUTES.x.method`）——
   一条 wire 事实（某段用什么方法）只住一处，两半各从同一格取。
2. `dispatch()` 读这一条记录：方法、纯度、读面、body 声明、响应形态**只有一处定义**
   （原先分居 `dispatch()` 与 `purityOf()` 两处的判断已并进这张表）；响应形态同时决定 run 的形
   （JSON 段拿 body / read，二进制段拿 query），两者仍在同一条记录里；deps 切片见 ADR-0032。
3. `APPLY_ACTIONS` 由 `ApplyAction` **派生**（`Record<ApplyAction, …>` + `satisfies`）：
   少一个动作就编译不过，多一个动作也是。
4. `/apply` 的「动作 → 纯度」（`count` 是纯读、其余进链）是 `route-table.ts` 里**唯一一张表**
   （`APPLY_ACTION_TABLE`：键由 `ApplyAction` 派生、`satisfies` 钉住——漏一个动作编译不过，多一个也是）。
   该路由 `purity` 的函数形式与动作拒否（`requireAction`）共用同一个识别器（`actionOf`：不抛，
   认不得就回 `undefined`），不各解析一遍动作；也不写在 `dispatch` 里。

## 边界

- **不给段名做动态发现**：九个段名是硬契约，`wire.ts` 仍是它们的家；`route-table.ts` 只负责「怎么处理」。
  线上方法是线上形状的一部分，按 ADR-0003 归 wire（`ROUTES` 每项 `{ path, method }`），路由记录与浏览器半都只投影。
- **不在这一轮改 HTTP 状态语义**（请求本身不对 4xx / 操作失败 200 + 信封）——那是既定口径，家在这几处：鉴权归宿主 `/api` bridge（ADR-0033），状态与失败信封的落地在 `src/api/connection-route.ts`（`dispatch` 只抛带 `httpStatus` 的请求错误），错误映射在 `src/remote/map-error.ts`。

## 后果

- 加一段 = `wire.ts` 加一个键 + `route-table.ts` 加一行；漏了任何一个都是编译错误或测试红
  （行的 deps 切片见 ADR-0032）。
- 「纯度」从注释承诺变成可枚举的数据：一条测试可以遍历整张表断言「写动作全部进链、纯读全部不进」。
- 到达序链那段代码本身（`throughChain`）不动——它今天是**没有测试覆盖**的，这一轮顺手补一条
  并发两条写请求的串行断言。

## 被否掉的替代

- **把 handler 放进 `shared/wire.ts`**：值 import 会把 Node 半（`node:http`、`node:fs`）拖进浏览器半的
  bundle，正好撞上 `tsdown` 的纯度门。
- **只把 `APPLY_ACTIONS` 从类型派生**：三处判断仍分居两处，最危险的那条（纯度）继续靠注释。

锚点：`CONTEXT.md`（路由表 / wire）；`src/api/route-table.ts`；`src/api/dispatch.ts`（`createDispatcher`）；`tests/route-table.test.ts`；ADR-0032。
