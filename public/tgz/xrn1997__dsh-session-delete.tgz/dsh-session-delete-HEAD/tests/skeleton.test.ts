import { existsSync, mkdtempSync, readFileSync, readdirSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import semver from 'semver'
import { describe, expect, it } from 'vitest'
import { PLATFORM_MODULES, gateClientImport, resolveBrowserBranchImport } from '../tsdown.config.js'
import * as plugin from '../src/index.js'
import { pick } from './support/fixture.js'

const manifest = JSON.parse(
  readFileSync(fileURLToPath(new URL('../package.json', import.meta.url)), 'utf8'),
) as {
  name: string
  main: string
  types: string
  exports: Record<string, unknown>
  files: string[]
  icon: string
  engines: Record<string, string>
  peerDependencies: Record<string, string>
  peerDependenciesMeta?: Record<string, { optional?: boolean }>
  dependencies?: Record<string, string>
  devDependencies: Record<string, string>
  publishConfig: { access?: string }
  repository: { url?: string }
  scripts: Record<string, string>
  dsh: {
    manifestVersion: 1
    bundle: { patch: string }
    client: { inject: string[]; platform: string }
  }
  xrn1997: { dshReleases: Record<string, string> }
}

/** 本插件真跑过的宿主代次（桌面版实测）。新增一代先在这里落账，再同步 dshReleases。 */
const TESTED_HOST_GENERATIONS = ['0.2.0-rc.2', '0.2.1-rc.1', '0.2.1-rc.2', '0.2.1-rc.3', '0.2.1-rc.5', '0.2.2-rc.1', '0.2.2-rc.2', '0.2.2-rc.3', '0.2.2-rc.5']

/** 完整功能的最低宿主代次（2026-10-19 **CLI 台架**实测：四个槽位齐全、激活零错误、ping 通）。
 *  它只决定 `engines.dsh` 的地板——**台架读数不进 `dshReleases`**（那份只收真机跑过的代次）。
 *  2026-11-04 按源码 tag 复核：0.1.7-rc.2 是第一个同时具备 `sidebar.session.row.leading`、
 *  `menu.item`、`row.action` 与 `workspaceRegistry.unarchiveSession` 的代次；0.1.7-rc.1 缺
 *  `leading`，0.1.7-alpha.* 缺 `menu`/`leading`，0.1.6-alpha.* 缺 `menu`，0.1.5 及以前还缺
 *  `row.action`/`unarchiveSession`。exact Fetch 路由不是地板来源：`ConnectionFetchRoute`
 *  自 0.1.3-alpha.2 起形状未变。 */
const BENCH_VERIFIED_FLOOR = '0.1.7-rc.2'

/** 宿主要求的唯一声明处。天花板是下一条线的起点——`<0.3.0-0` 才能连 0.3.0 的预发布
 *  一起挡在外面（`<0.3.0` 挡不住）。 */
const HOST_ENGINE_RANGE = '>=0.1.7-rc.2 <0.3.0-0'

/** 从 app.asar 抽出的宿主冻结平台模块表原文——**9 个键**，不是 312 个包名的并集。
 *  这里与 `tsdown.config.ts` 的 `PLATFORM_MODULES` 各自独立记录同一事实：
 *  两边不一致就是有人改了实现或改了实测，必须是一次显式裁定。 */
const FROZEN_PLATFORM_MODULES = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-store',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-dockkit',
]

describe('插件入口形状', () => {
  it('导出 name 与 apply，且 name 是本包名', () => {
    expect(plugin.name).toBe('@xrn1997/dsh-session-delete')
    expect(typeof plugin.apply).toBe('function')
  })

  // exact Fetch 路由注册在宿主 `connection` 上（`/api` bridge 做鉴权），所以 Node 半必须注入
  // `connection`（`client-connection` 的服务名逐字如此）。写错服务名不会报错——插件会永远停在
  // `pending (waiting for service: …)`，所以钉在这里。
  it('Node 半的 inject 含 connection（exact Fetch 路由的承载者）', () => {
    expect(plugin.inject).toContain('connection')
  })

  // 宿主从模块面拿 Config 在激活前校验可调项（ADR-0037）；删掉这一出口不会让任何行为测试红，
  // 只会让坏配置在运行期才炸——所以在这里钉形状。
  it('导出 Config（本地 Standard Schema），validate 交回归一值或 issues', () => {
    const schema = plugin.Config['~standard']
    expect(schema.version).toBe(1)
    expect(typeof schema.validate).toBe('function')
    expect(schema.validate({ orphanPreviewLimit: 1 })).toHaveProperty('value')
    expect('issues' in schema.validate({ unknownKnob: 1 })).toBe(true)
  })
})

const localeEn = JSON.parse(
  readFileSync(fileURLToPath(new URL('../locale/en.json', import.meta.url)), 'utf8'),
) as { meta: { title: string } }

describe('展示元数据与 peer 声明', () => {
  it('英文标题是 sentence case', () => {
    expect(localeEn.meta.title).toBe('Session delete')
  })

  it('cordis 不是 peer，react / react-dom 都是 optional peer', () => {
    expect(Object.keys(manifest.peerDependencies)).toEqual(['react', 'react-dom'])
    expect(manifest.peerDependenciesMeta?.react?.optional).toBe(true)
    expect(manifest.peerDependenciesMeta?.['react-dom']?.optional).toBe(true)
    expect(manifest.devDependencies['@deepseek-ai/cordis']).toBeDefined()
    expect(
      Object.keys(manifest.peerDependencies).filter((dep) => dep.startsWith('@deepseek-ai/dsh')),
    ).toEqual([])
  })
})

describe('宿主要求声明与浏览器半声明', () => {
  // 宿主导入插件时的判据（asar 里官方原文）：清单声明了 `engines.dsh` 时**只由该范围决定、
  // peerDependencies 被忽略**；没有它才逐条比对 `@deepseek-ai/dsh` / `@deepseek-ai/dsh-*` 的 peer。
  // 本插件的唯一声明处因此是顶层 `engines.dsh`——dsh-market 的清单解析也先读它、再退到
  // `dsh.engines.dsh`；两处都写等于给同一件事开了两个家。窗口要盖住真机名单里的每一代，
  // 地板必须正好是台架验过的完整功能下界，并且**只许盖到下一条线为止**。
  it('engines.dsh 是唯一的宿主要求：窗口盖住全部真机代次、地板对上台架下界、不越过下一条线', () => {
    expect(manifest.engines.dsh).toBe(HOST_ENGINE_RANGE)
    expect(HOST_ENGINE_RANGE.startsWith(`>=${BENCH_VERIFIED_FLOOR} `)).toBe(true)
    expect(semver.validRange(HOST_ENGINE_RANGE)).not.toBeNull()
    for (const generation of TESTED_HOST_GENERATIONS) {
      expect(
        semver.satisfies(generation, HOST_ENGINE_RANGE, { includePrerelease: true }),
        `${generation} 是实测代次，必须落在 engines.dsh 窗口内`,
      ).toBe(true)
    }
    // 天花板必须是下一条线的起点：`<0.3.0` 在宿主的 includePrerelease 语义下会放行 0.3.0-alpha.1
    expect(semver.satisfies('0.3.0-alpha.1', HOST_ENGINE_RANGE, { includePrerelease: true })).toBe(false)
    // dsh-market 的 manifestFacts 把超过 256 字符的范围整条当不存在——越界就会在市场里变成"未声明"
    expect(HOST_ENGINE_RANGE.length).toBeLessThanOrEqual(256)
    expect(manifest.dsh).not.toHaveProperty('engines')
  })

  // dsh-market 的卡片把 `engines.dsh` 与 dsh* peer **一起**算（宿主在前者存在时忽略后者），
  // 两个家迟早写出两种结论。peer 保持为零，dsh* 相关的判断只住 `engines.dsh` 一处；
  // 控件与图标已自造、不再 require 宿主的 `dsh-client-ui-primitives`（见 `src/client/ui/*`）。
  it('没有任何 @deepseek-ai/dsh-* peer（dsh* 判断只由 engines.dsh 说）', () => {
    const peers = Object.keys(manifest.peerDependencies).filter(
      (dep) => dep === '@deepseek-ai/dsh' || dep.startsWith('@deepseek-ai/dsh-'),
    )
    expect(peers).toEqual([])
  })

  // 真加了的话只能开实测过的某一代：peer 区间在 semver 预发布规则下没有"免维护写法"。
  it('若将来确要声明 dsh* peer，区间只能是实测过的某一代（正控）', () => {
    const declared = Object.entries(manifest.peerDependencies).filter(([dep]) =>
      dep.startsWith('@deepseek-ai/dsh-'),
    )
    for (const [dep, range] of declared) {
      expect(TESTED_HOST_GENERATIONS, `${dep} 的 peer 区间只能开实测过的一代`).toContain(range)
    }
  })

  // `dsh.client.inject` 的语义是**包行**（自带 `./client` 的 client 插件包）先到，不是静态表键：
  // 宿主浏览器半 `arriveGraphRow` 逐字 `for (const packageName of row.inject) { const dependency =
  // this.graphRows.get(packageName); if (dependency !== void 0) await this.arriveDependency(...) }`
  // ——名字取不到就静默跳过。locale 先到（客户端半要读 `locale` 服务）；0.2.2+ 的 context-menu
  // 先到（数据动作要读 `contextMenus` 服务），旧宿主取不到这个名字也不会挡激活。
  it('dsh.client.inject 只列 web 组合花名册里真实存在的 client 包（locale + context-menu）', () => {
    expect(manifest.dsh.client.inject).toEqual([
      '@deepseek-ai/dsh-client-locale',
      '@deepseek-ai/dsh-client-ui-context-menu',
    ])
    for (const name of manifest.dsh.client.inject) expect(FROZEN_PLATFORM_MODULES).not.toContain(name)
  })

  it('manifest 里没有 @deepseek-ai/dsh-client-ui-primitives（已自造控件，不再依赖宿主客户端包）', () => {
    expect(JSON.stringify(manifest)).not.toContain('dsh-client-ui-primitives')
  })

  it('manifest 里没有 @deepseek-ai/dsh-client-connection（不在平台表内，不值 import）', () => {
    expect(JSON.stringify(manifest)).not.toContain('dsh-client-connection')
  })

  it('真机账本住私有 xrn1997.dshReleases，只写 compatible，且名单与实测代次**双向**一致', () => {
    // 公开 `dsh` 字段只留官方声明；真机账本宿主与市场都不读，放 `dsh.*` 会被误读成平台契约。
    expect(manifest.dsh.manifestVersion).toBe(1)
    expect(manifest.dsh).not.toHaveProperty('compatibility')
    const releases = manifest.xrn1997.dshReleases
    for (const generation of TESTED_HOST_GENERATIONS) {
      expect(releases[generation]).toBe('compatible')
    }
    // 反方向才是 AGENTS.md 那条规矩的本体：没真跑过的代次不许进名单（只查上面那个方向时，
    // 名单里多塞一代照样绿）。
    for (const generation of Object.keys(releases)) {
      expect(TESTED_HOST_GENERATIONS, `${generation} 没实测过就不许进 dshReleases`).toContain(generation)
    }
    for (const status of Object.values(releases)) expect(status).toBe('compatible')
  })

  // **包形不变式**（官方 `reference/cookbook/adding-a-package` 逐字：`main: "lib/index.js"`、
  // `types: "lib/types/index.d.ts"`、`exports["."].types: "./lib/types/index.d.ts"`、
  // `exports["."].default: "./lib/index.js"`，并且**不发布** `src`、声明映射、JS map、陈旧的根声明文件）。
  // `./client` 那两件的形状不是推的——宿主 `dsh-client-connection` 的 `package.json` 原文就写着
  // `{ "types": "./lib/types/client/index.d.ts", "default": "./lib/client.js" }`（asar 实读）。
  it('包形不变式：main / types / 两个出口的 types+default 都在 lib/ 与 lib/types/ 下', () => {
    expect(manifest.main).toBe('lib/index.js')
    expect(manifest.types).toBe('lib/types/index.d.ts')
    expect(manifest.exports['.']).toEqual({ types: './lib/types/index.d.ts', default: './lib/index.js' })
    expect(manifest.exports['./client']).toEqual({
      types: './lib/types/client/index.d.ts', default: './lib/client.js',
    })
  })

  // `files` 从「整目录 `lib`」收成**精确产物**：整目录会把盘上所有构建产物一起发出去（官方那条明写
  // "不要发布 JS map"），而 `link:` 装法根本不看这份清单——两处不同步就会只有 npm 在发垃圾。
  it('发布清单精确到产物：不列整目录 lib、不带任何 .map', () => {
    expect(manifest.files).not.toContain('lib')
    for (const entry of manifest.files) expect(entry, entry).not.toMatch(/\.map$/)
    expect(manifest.files).toContain('lib/index.js')
    expect(manifest.files).toContain('lib/client.js')
    expect(manifest.files).toContain('lib/types/**/*.d.ts')
  })

  // 两半产物都是**自包含**的：`lib/client.js` 的外部 require 只有平台表（react / react-dom /
  // react/jsx-runtime），`lib/index.js` 只有 node 内建；npm 依赖（markdown 那套）在构建期 inline。
  // 所以生产依赖必须为空——否则 `dsh plugin add` 会把整套构建期依赖装进用户的 profile，
  // 运行时一个都解析不到。构建期那份归属由 devDependencies 说，产物侧的 require 面由构建纯度门
  // 与 `tests/client/*` 把守。
  it('生产依赖为空：npm 依赖全部在构建期内联，装包不多带运行时包', () => {
    expect(manifest.dependencies ?? {}).toEqual({})
  })

  // 宿主提供 React / React DOM（浏览器半的冻结平台表），它们不是运行期 npm 依赖：peer 标成可选，
  // 免得包装器按 peer 解析再往 profile 里装一份用不到的副本。
  it('react / react-dom 都是可选 peer（宿主平台表提供，不从 profile 解析）', () => {
    expect(manifest.peerDependenciesMeta?.react?.optional).toBe(true)
    expect(manifest.peerDependenciesMeta?.['react-dom']?.optional).toBe(true)
  })

  // 官方那条"peer 与 dev **同范围**、每条 dsh 对等依赖都在 devDependencies 里镜像"要防的是这一件事：
  // 声明的地板是 4.0.2、编译时装的是 4.0.4 ⇒ 那个地板从没被编译过，却写进了契约。
  it('每条 peer 若在 devDependencies 里镜像，范围必须逐字相同', () => {
    for (const [dep, range] of Object.entries(manifest.peerDependencies)) {
      if (dep in manifest.devDependencies) expect(manifest.devDependencies[dep], dep).toBe(range)
    }
  })

  it('两条半产物的入口在 manifest 里声明齐全', () => {
    expect(manifest.dsh.bundle.patch).toBe('./cordis.patch.yml')
  })

  // 行 id 是宿主寻址这一行的键：`configEditor` 只编辑唯一寻址的行，行配置卡的 key 也带它。
  // 裸名 `session-delete` 是通用词，可能被同一个 profile 里别的包占走；判据与改名代价见 ADR-0045。
  it('bundle 的 patch 行 id 带插件前缀', () => {
    const patch = readFileSync(fileURLToPath(new URL('../cordis.patch.yml', import.meta.url)), 'utf8')
    expect(patch).toMatch(/^\s*- id: xrn1997-session-delete$/m)
  })

  /* ── npm 发布面（缺哪一条，`npm publish` 不是失败就是发出去一个坏包） ── */

  it('scoped 包必须显式声明公开访问，否则首次 publish 被当成私有包拒绝', () => {
    expect(manifest.publishConfig.access).toBe('public')
  })

  it('发布即构建：build 两步（tsdown 出台面 JS，tsc 出 lib/types 声明），prepack 跑 build', () => {
    // `prepack` 在 `npm pack` / `pnpm pack` / `npm|pnpm publish` 四条路上都会跑，
    // 所以"手滑直接 publish 出一个空的 lib/"这件事不可能发生。
    expect(manifest.scripts.prepack).toBe('npm run build')
    // 声明换成 tsc 出到 `lib/types/`（tsdown 那份 `lib/index.d.ts` 正是官方点名不要的"根声明文件"），
    // 顺序不能反：tsdown 的 Node 半配置带 `clean: true`，会先把 `lib/` 抹干净。
    expect(manifest.scripts.build).toBe('tsdown && tsc -p tsconfig.build.json')
  })

  it('展示元信息：locale 两套语言、图标与真机截图都进了发布清单', () => {
    expect(manifest.exports['./locale/*.json']).toBe('./locale/*.json')
    expect(manifest.files).toContain('locale')
    expect(manifest.files).toContain('icon.svg')
    expect(manifest.icon).toBe('./icon.svg')
    // 真机截图是 README 的插图；相对图片从**包内**读，截图不进包就是破图。
    expect(manifest.files).toContain('docs/screenshots')
  })

  // 详情页渲染的长描述是各语言 locale `meta.detail` 点名的 Markdown，缺省才回退整篇 README（太长）。
  // 宿主契约里声明了却形状不对或文件缺失是 `invalid` 报错、**不回退**（文档顺序住宿主的插件详情库），
  // 装好的包少了这份文件或它的插图同样读不到——所以每个语言都钉四条：声明在场、路径形状合规、
  // 文件进发布清单、文档里的本地插图也进发布清单。
  it('每个 locale 的 meta.detail 都指向进发布清单的详情文档', () => {
    const dir = fileURLToPath(new URL('../locale', import.meta.url))
    const languages = readdirSync(dir).filter((name) => name.endsWith('.json'))
    expect(languages.length, 'locale 目录没有扫到任何语言').toBeGreaterThan(0)
    for (const name of languages) {
      const locale = JSON.parse(readFileSync(join(dir, name), 'utf8')) as { meta?: { detail?: string } }
      const detail = locale.meta?.detail
      expect(detail, `${name} 没有 meta.detail：详情页会渲染整篇 README`).toBeDefined()
      if (detail === undefined) continue
      expect(detail, `${name} 的 meta.detail 不是包根相对、/ 分隔的 .md 路径`)
        .toMatch(/^[^\s:\\]+(?:\/[^\s:\\]+)*\.(?:md|markdown)$/)
      expect(detail.split('/').every((seg) => seg !== '' && seg !== '.' && seg !== '..'),
        `${name} 的 meta.detail 含非法路径段`).toBe(true)
      expect(existsSync(fileURLToPath(new URL(`../${detail}`, import.meta.url))),
        `${name} 的 meta.detail 指向不存在的文件`).toBe(true)
      expect(manifest.files, `${name} 的详情文档不进发布清单，装好的包读不到`).toContain(detail)
      const markdown = readFileSync(fileURLToPath(new URL(`../${detail}`, import.meta.url)), 'utf8')
      // 官方详情文档的写法是**恰好一行图片**：功能、用法与限制住 `meta.description`，不在这份
      // Markdown 里重复。多出来的散文会让详情页出现第二份会漂移的用户文档。
      const contentLines = markdown.split(/\r?\n/).filter((line) => line.trim() !== '')
      expect(contentLines, `${name} 的详情文档必须恰好一行图片`).toHaveLength(1)
      const onlyLine = contentLines[0] ?? ''
      expect(onlyLine, `${name} 的详情文档不是一行 Markdown 图片`).toMatch(/^!\[[^\]]+\]\([^)\s]+\)$/)
      for (const match of markdown.matchAll(/!\[[^\]]*\]\(([^)\s]+)\)/g)) {
        const image = pick(match, 1)
        if (/^(?:https?:|data:)/.test(image)) continue
        const imagePath = `${detail.slice(0, detail.lastIndexOf('/') + 1)}${image}`
        expect(manifest.files, `${name} 的插图 ${imagePath} 不进发布清单，详情页就是一张破图`).toContain(imagePath)
      }
    }
  })

  it('插件卡片图标随宿主主题换色：两档颜色取自 label-primary', () => {
    const icon = readFileSync(fileURLToPath(new URL('../icon.svg', import.meta.url)), 'utf8')
    // 宿主 ThemePresenter 把解析后的主题写到根节点 color-scheme，SVG 图片内部的媒体查询据此切换
    expect(icon).toContain('@media (prefers-color-scheme: dark)')
    expect(icon).toContain('stroke: #0f1115')
    expect(icon).toContain('stroke: #f9fafb')
  })

  // 图标形状、图标集、控件实现与控件 / Markdown 样式逐字派生自 DeepSeek Harness 的 MIT 客户端包
  // （各文件头注），`lib/client.js` 还内联了 react-markdown / remark-gfm 闭包（MIT / ISC）。两类
  // 第三方代码都要求版权与许可声明随副本分发：这份声明必须真的进包，并点名「从哪来、落到哪」，
  // 否则 npm 上的副本就是缺声明的副本。
  it('第三方素材的许可声明随包发布，并点名来源、落点与内联依赖', () => {
    const notice = readFileSync(fileURLToPath(new URL('../THIRD_PARTY_NOTICES.md', import.meta.url)), 'utf8')
    expect(manifest.files).toContain('THIRD_PARTY_NOTICES.md')
    expect(notice).toContain('MIT License')
    expect(notice).toContain('ISC License')
    expect(notice).toContain('Copyright (c) 2026 DeepSeek')
    for (const source of [
      '@deepseek-ai/dsh-client-ui-primitives',
      '@deepseek-ai/dsh-client-ui-conversation',
      '@deepseek-ai/dsh-client-ui-workspace',
    ]) {
      expect(notice).toContain(source)
    }
    for (const copied of [
      'icon.svg',
      'src/client/ui/icons.tsx',
      'src/client/ui/Button.tsx',
      'src/client/ui/Tag.tsx',
      'src/client/ui/Modal.tsx',
      'src/client/ui/Tooltip.tsx',
      'src/client/ui/Toast.tsx',
      'src/client/ui/MenuItemButton.tsx',
      'src/client/ui/Checkbox.tsx',
      'src/client/ui/top-layer.ts',
      'src/client/ui/format.ts',
      'src/client/ui/ui.css',
      'src/client/ui/markdown.css',
    ]) {
      expect(notice).toContain(copied)
    }
    for (const inlined of ['react-markdown', 'remark-gfm', '@ungap/structured-clone']) {
      expect(notice).toContain(inlined)
    }
  })

  it('仓库/主页/工单面指向真实远端（不是编的 URL）', () => {
    expect(manifest.repository.url).toContain('github.com/xrn1997/dsh-session-delete')
  })
})

describe('浏览器半平台模块表', () => {
  // 表从 9 个键收到 3 个（2026-10-02）：本插件不再 require 任何一个 `@deepseek-ai/*` 客户端包，
  // 只剩 React 家族——它的**模块身份必须与外壳自己那份同一**（否则 hooks 在两个 React 实例间崩），
  // 只能由冻结表解答。收窄是**收紧纯度门**：多留一个键就是多留一个"再 import 它一次"的口子。
  it('只列本插件真正 require 的 React 家族，且都取自那一代冻结表', () => {
    expect([...PLATFORM_MODULES].sort()).toEqual(['react', 'react-dom', 'react/jsx-runtime'])
    for (const name of PLATFORM_MODULES) expect(FROZEN_PLATFORM_MODULES).toContain(name)
  })
})

describe('抄本表点名的自造差异（界面保真复核门：除 ui.css 文件头点名的那些外一律与官方明文逐属性一致）', () => {
  const css = readFileSync(fileURLToPath(new URL('../src/client/ui/ui.css', import.meta.url)), 'utf8')

  it('文件头点名的七条自造规则真在表里（声明与实现对上）', () => {
    expect(css).toContain('.sd-resizing {')
    // 2026-10-16 补的第二条：清单行是 role="row" 的可聚焦 div，键盘焦点必须有可见描边
    expect(css).toContain('.sd-session-row:focus-visible {')
    // 2026-10-17 补的第三条：官方那颗 iconButton 只有常态与 hover，勾选开关要按下/禁用两档
    expect(css).toContain(".sd-rowaction-button[aria-pressed='true'] {")
    // 第四条：宿主没有"浮条"这件控件
    expect(css).toContain('.sd-batch-bar {')
    // 第五条：宿主行自己的选中态归宿主，批量选择要有整行底色；状态点/归档行的兜底不能与行首重复
    expect(css).toContain('[data-row-key^="session:"]:has([data-dsh-session-delete="batch-pick"][data-checked="true"])')
    expect(css).toContain('[data-seat="leading"]) .sd-batch-pick-action')
    // 第六条：宿主行首 16×20 格里那层 inline-flex 包装
    expect(css).toContain('.sd-batch-pick-leading {')
    // 第七条：撤销横幅在飞时那颗动作要有禁用档（Toast 的 action 自带 color，UA 默认置灰不生效）
    expect(css).toContain('.sd-toast-action:disabled {')
    expect(/七处不是抄本/.test(css)).toBe(true)
    // 组头 reset 是文件头点名的例外，七项必须全在**组头那一块**的 inline 样式里（不能只 reset text-align）。
    // 组头的 DOM 现在只由 `session-list.tsx` 拼一次（两档共用），所以钉那一处的配方。
    const list = readFileSync(fileURLToPath(new URL('../src/client/session-list.tsx', import.meta.url)), 'utf8')
    const headStyle = /const GROUP_HEAD: CSSProperties = \{([^}]*)\}/.exec(list)?.[1] ?? ''
    expect(headStyle, '没找到组头的 inline style').not.toBe('')
    for (const prop of ["background: 'none'", "border: 'none'", 'padding: 0', "font: 'inherit'", "textAlign: 'start'", "'1 1 auto'", 'gap: 6']) {
      expect(headStyle, `组头 reset 缺 ${prop}`).toContain(prop)
    }
    expect(css.split('本插件自造的第').length - 1).toBe(7)
  })

  it('批量浮条按内容展开：width:max-content + max-width，避免左半屏收缩把按钮挤到第二行', () => {
    expect(css).toMatch(/\.sd-batch-bar\s*\{[^}]*width:\s*max-content/)
    expect(css).toMatch(/\.sd-batch-bar\s*\{[^}]*max-width:\s*calc\(100vw - 48px\)/)
  })

  it('批量浮条压在确认框下面：浮条的 z-index 必须小于模态根（否则会盖住确认按钮）', () => {
    const zIndexOf = (selector: string): number => {
      const start = css.indexOf(`${selector} {`)
      expect(start).toBeGreaterThanOrEqual(0)
      const match = /z-index:\s*(\d+)/.exec(css.slice(start))
      if (match === null) throw new Error(`${selector} 没有 z-index`)
      return Number(match[1])
    }
    expect(zIndexOf('.sd-batch-bar')).toBeLessThan(zIndexOf('.sd-modal-root'))
  })

  it('行那条描边复用选中态那枚 token，不新造颜色（2026-10-15 实测）', () => {
    // 不按字面多行比：源文件的工作树换行可能被本机工具写成 CRLF，钉"选择器 + 那条 outline 用的 token"这一件事就够。
    // 选中态 token 走本插件的别名层（`--sd-*`），别名解析到的仍是宿主那枚
    // `--dsw-alias-button-ghost-active-border`（见 ui.css 头注：私有 token 带公开兜底）。
    expect(css).toMatch(
      /\.sd-session-row:focus-visible\s*\{\s*outline:\s*0\.5px solid var\(--sd-button-ghost-active-border\)/,
    )
  })
})

describe('主题别名层的落点（`--sd-*`）', () => {
  const css = readFileSync(fileURLToPath(new URL('../src/client/ui/ui.css', import.meta.url)), 'utf8')

  // 宿主把 `--dsw-alias-*` palette 写在 `body` / `body[data-ds-dark-theme]` 上，主题服务还把快照
  // 逐条 inline 到 `document.body.style`；别名层若挂 `:root`，引用就在 `html` 上求值——私有 token
  // 与兜底都还没定义，整条 `var()` 链失效，用到它的字色/边框/底色会被整条丢弃。jsdom 不做层叠，
  // 单测抓不到，只能钉源码形态（为什么与实测证据见 ui.css 头注）。
  it('与宿主 palette 同元素：挂 body，不挂 :root', () => {
    expect(css).toMatch(/(?:^|\n)body\s*\{[^}]*--sd-label-tertiary:/)
    expect(css).not.toMatch(/:root\s*\{[^}]*--sd-label-tertiary:/)
  })
})

describe('主题别名层的完整性（`--sd-*`）', () => {
  const css = readFileSync(fileURLToPath(new URL('../src/client/ui/ui.css', import.meta.url)), 'utf8')
  const blockStart = css.indexOf('/* ──────────────── 主题 token 兜底')
  const blockEnd = css.indexOf('/* ────────────────────────── Button')
  const aliasBlock = css.slice(blockStart, blockEnd)

  /** 宿主 `ui-theme` 的 `BUILTIN_INSPECT_TOKENS`（14 项；换代先复核，别当成永久名单）。 */
  const PUBLIC_DSW_TOKENS = new Set([
    '--dsw-alias-bg-base',
    '--dsw-alias-bg-layer-1',
    '--dsw-alias-bg-layer-2',
    '--dsw-alias-bg-overlay',
    '--dsw-alias-border-l1',
    '--dsw-alias-border-l2',
    '--dsw-alias-brand-primary',
    '--dsw-alias-label-primary',
    '--dsw-alias-label-secondary',
    '--dsw-alias-state-error-primary',
    '--dsw-alias-state-idle-primary',
    '--dsw-alias-state-success-primary',
    '--dsw-alias-state-warn-primary',
    '--dsw-specific-sidebar-fill',
  ])

  function clientFiles(dir: string): string[] {
    return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
      const full = join(dir, entry.name)
      if (entry.isDirectory()) return clientFiles(full)
      return /\.(?:tsx?|css)$/.test(entry.name) ? [full] : []
    })
  }

  /** 正则捕获组在类型上是可选的；这里的模式都必中，取不到就是测试写法坏了。 */
  function captured(match: RegExpMatchArray, index: number): string {
    const value = match[index]
    if (value === undefined) throw new Error('正则捕获组缺失')
    return value
  }

  /** 按 `--sd-*` 键切块；值里可能跨行、含嵌套 `var()` 与 `color-mix()`。 */
  function aliasDefinitions(): Array<{ name: string; value: string }> {
    const body = aliasBlock.slice(aliasBlock.indexOf('{') + 1, aliasBlock.lastIndexOf('}'))
    const starts = [...body.matchAll(/(--sd-[a-z0-9-]+)\s*:\s*/g)]
    return starts.map((start, index) => {
      const from = start.index + start[0].length
      const to = starts[index + 1]?.index ?? body.length
      return { name: captured(start, 1), value: body.slice(from, to).replace(/;\s*$/, '').trim() }
    })
  }

  // 这一层最该防的失效模式是拼错名字：声明整条被丢弃，颜色退回继承值，jsdom 里看不出来。
  it('每个 var(--sd-*) 都有定义，且没有只在定义里躺着的别名', () => {
    const definitions = new Set(aliasDefinitions().map((definition) => definition.name))
    const usages = new Set<string>()
    for (const file of clientFiles(fileURLToPath(new URL('../src/client', import.meta.url)))) {
      for (const match of readFileSync(file, 'utf8').matchAll(/var\(\s*(--sd-[a-z0-9-]+)/g)) usages.add(captured(match, 1))
    }
    expect(definitions.size).toBeGreaterThan(0)
    expect([...usages].filter((name) => !definitions.has(name))).toEqual([])
    expect([...definitions].filter((name) => !usages.has(name))).toEqual([])
  })

  // fallback 里再拿一枚私有 token 兜底，换代时两条一起失效——等于没加这层。
  it('别名 fallback 只引用宿主公开 token', () => {
    for (const { name, value } of aliasDefinitions()) {
      const refs = [...value.matchAll(/var\(\s*(--dsw-[a-z0-9-]+)/g)].map((match) => captured(match, 1))
      expect(refs.length, `${name} 没有引用私有 token`).toBeGreaterThan(0)
      for (const fallback of refs.slice(1)) {
        expect(PUBLIC_DSW_TOKENS.has(fallback), `${name} 的 fallback ${fallback} 不是宿主公开 token`).toBe(true)
      }
    }
  })
})

describe('浏览器半纯度门', () => {
  it('Node 内建一律抛出', () => {
    expect(() => gateClientImport('node:fs')).toThrow(/Node 内建/)
    expect(() => gateClientImport('path')).toThrow(/Node 内建/)
  })

  it('表外的 @deepseek-ai/* 值 import 抛出——包括已经自造掉的那两个客户端包', () => {
    expect(() => gateClientImport('@deepseek-ai/dsh-client-connection')).toThrow(/平台模块表/)
    expect(() => gateClientImport('@deepseek-ai/dsh-workspace')).toThrow(/平台模块表/)
    // 自造控件的直接理由就是这条：这两个包随宿主换代而变、又不经类型检查。
    expect(() => gateClientImport('@deepseek-ai/dsh-client-ui-primitives')).toThrow(/平台模块表/)
    expect(() => gateClientImport('@deepseek-ai/dsh-client-ui-slots')).toThrow(/平台模块表/)
  })

  it('平台表内、非 @deepseek-ai 的 npm 依赖与相对路径放行', () => {
    expect(gateClientImport('react')).toBeNull()
    expect(gateClientImport('react-dom')).toBeNull()
    // 非 @deepseek-ai 的 npm 依赖由 alwaysBundle inline 进 bundle，不产生 require ⇒ 门不拦
    expect(gateClientImport('zod')).toBeNull()
    expect(gateClientImport('./delete-menu-item.js')).toBeNull()
  })
})

describe('vfile 浏览器分流（react-markdown 那条依赖链）', () => {
  // 构建期实测：CJS 输出下 rolldown 按 Node 条件解 vfile 的 `#min*` 内部请求，选中的是带
  // `node:path`/`node:url`/`node:process` 的那一支 ⇒ 纯度门先响。这里把它接回包作者自备的
  // `.browser.js`，并且**只在旁边真有那个文件时**才接。
  const dir = mkdtempSync(join(tmpdir(), 'sd-vfile-'))
  writeFileSync(join(dir, 'minpath.browser.js'), 'export const minpath = {}')
  const importer = join(dir, 'index.js')

  it('三个 # 请求接向同级的 .browser.js', () => {
    expect(resolveBrowserBranchImport('#minpath', importer)).toBe(join(dir, 'minpath.browser.js'))
    // 缺文件（换代改了名）⇒ null ⇒ 交回默认解析，让纯度门重新响，不静默放行
    expect(resolveBrowserBranchImport('#minproc', importer)).toBeNull()
    expect(resolveBrowserBranchImport('#minurl', importer)).toBeNull()
  })

  it('窄到只认这三个键：别的请求与非 vfile 的 importer 一律不接', () => {
    expect(resolveBrowserBranchImport('#fs', importer)).toBeNull()
    expect(resolveBrowserBranchImport('node:fs', importer)).toBeNull()
    expect(resolveBrowserBranchImport('#minpath', undefined)).toBeNull()
  })

  it('真装的 vfile 旁边确实有那三个浏览器实现（不是我们编的）', () => {
    const store = readdirSync(join(process.cwd(), 'node_modules', '.pnpm')).filter((n) => n.startsWith('vfile@'))
    expect(store.length).toBeGreaterThan(0)
    const lib = join(process.cwd(), 'node_modules', '.pnpm', pick(store, 0), 'node_modules', 'vfile', 'lib')
    for (const name of ['minpath', 'minproc', 'minurl']) {
      expect(resolveBrowserBranchImport(`#${name}`, join(lib, 'index.js'))).toBe(resolve(lib, `${name}.browser.js`))
    }
  })
})

/* ------------------------------------------------------------------ *
 * 跨插件 import 红线（AGENTS.md）——浏览器半有上面那道纯度门兜着，Node 半没有
 * ------------------------------------------------------------------ */

/** Node 半的源码：`src/` 下 `client/` 之外的每个 .ts/.tsx。 */
function nodeHalfSources(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    if (entry.isDirectory()) {
      return entry.name === 'client' ? [] : nodeHalfSources(join(dir, entry.name))
    }
    return /\.tsx?$/.test(entry.name) ? [join(dir, entry.name)] : []
  })
}

/** 某一棵子树下的每个 .ts/.tsx（浏览器半在 `src/client/`，由调用方给根）。 */
function allSources(dir: string): string[] {
  return readdirSync(dir, { withFileTypes: true }).flatMap((entry) =>
    entry.isDirectory()
      ? allSources(join(dir, entry.name))
      : /\.tsx?$/.test(entry.name)
        ? [join(dir, entry.name)]
        : [],
  )
}

/** `from '@deepseek-ai/…'` 的 import/export 语句。**不许跨语句**：要求 `from` 之前不含引号
 *  （引号只可能出现在同一语句的模块名里），否则懒惰量词会一路吃到下一条 `from '@deepseek-ai/…'`，
 *  把整段源码当成一条语句。 */
const HOST_IMPORT_RE = /(?:import|export)(?: type)?[^;"'`]*?from (['"])@deepseek-ai\/[^'"]*\1/g

const hostImportsIn = (source: string): string[] => source.match(HOST_IMPORT_RE) ?? []
const isTypeOnly = (statement: string): boolean => /^(?:import|export) type /.test(statement)

describe('跨插件 import 红线', () => {
  // 正控：判据本身要认得出一条真违例——否则「零违例」可能只是正则什么都没匹配上。
  it('判据认得出值 import、也放得过 type import（正控）', () => {
    const bad = [
      `import { RemoteError } from '@deepseek-ai/dsh-typert-protocol'`,
      'import {\n  Button,\n} from "@deepseek-ai/dsh-client-ui-primitives"',
    ]
    for (const statement of bad) {
      expect(hostImportsIn(statement)).toEqual([statement])
      expect(isTypeOnly(statement)).toBe(false)
    }
    expect(isTypeOnly(`import type { Context } from '@deepseek-ai/cordis'`)).toBe(true)
  })

  // AGENTS.md：跨插件一律 `import type`，值 import 是与生态的红线。这条在 **Node 半**尤其要命——
  // `tsdown.config.ts` 的纯度门只挂在浏览器半的 entry 上，Node 半的值 import 没人拦，会原样落进
  // `lib/index.js`，运行时去解析一个「与运行中的宿主不同代」的 npm 包（错了只在用户机器上炸）。
  // 判据直接从**源码**取，不依赖先跑构建。
  it('Node 半对宿主包只许 `import type` / `export type`', () => {
    const root = fileURLToPath(new URL('../src', import.meta.url))
    const files = nodeHalfSources(root)
    expect(files.length).toBeGreaterThan(0)
    const offenders = files.flatMap((file) =>
      hostImportsIn(readFileSync(file, 'utf8'))
        .filter((statement) => !isTypeOnly(statement))
        .map((statement) => `${file}: ${statement}`),
    )
    expect(offenders).toEqual([])
  })

  // 浏览器半比 Node 半更严：**一条 `@deepseek-ai/*` 的 import 都不许有，type-only 也不留**
  // （那边连类型都不从宿主包拿，全靠 `context.ts` 的本地窄镜像）。构建期那道纯度门只看得见
  // 真的解析到的 require，源码层面的越界在这里拦——这也是官方对第三方 UI 插件的要求
  // （"Do not require any Harness Client package as a module"）。
  it('浏览器半源码里没有任何 @deepseek-ai/* 的 import（值或类型都不许）', () => {
    const root = fileURLToPath(new URL('../src/client', import.meta.url))
    const files = allSources(root)
    expect(files.length).toBeGreaterThan(5)
    const offenders = files.flatMap((file) =>
      hostImportsIn(readFileSync(file, 'utf8')).map((statement) => `${file}: ${statement}`),
    )
    expect(offenders).toEqual([])
  })
})
