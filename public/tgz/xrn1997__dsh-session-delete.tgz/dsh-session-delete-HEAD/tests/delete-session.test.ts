import { describe, expect, it, vi } from 'vitest'
import { applyActions } from '../src/verbs/batch.js'
import { deleteSession } from '../src/verbs/delete-session.js'
import { resetWriteProgress, writeProgress } from '../src/verbs/write-progress.js'
import { makeEntryId, sessionDirOf, trashDirOf } from '../src/trash/entry.js'
import { createLogWorld, expectSteps, failureOf, holdCalls, stepProbe, type LogWorldOptions } from './support/world.js'

const HOME = '/h'
/** 内存里那第二个 adapter（`tests/support/fake-deps.ts`）之上的一层：世界由声明式读数描述，
 *  日志按**发生顺序**记 fs 与 host 两端——删除的顺序（摘账本 → 搬目录 → 摘活体 → 通告）是一条断言。
 *  **删除不碰归档**：回收站与归档解耦；活体靠 `evictLive`（session + agent）离开宿主。 */
const deps = (over: Omit<LogWorldOptions, 'logMethods'> = {}) =>
  createLogWorld({
    now: Date.UTC(2026, 8, 30, 13, 5, 0),
    projectDirOf: '--C-develop-GitHub-dsh-ebook--',
    ...over,
    logMethods: ['archive', 'detach', 'unarchive', 'attach', 'evictLive', 'announceRemoved', 'announceRestored', 'rename'],
  })

describe('删除动词', () => {
  it('运行中的会话一律拒绝，且不产生任何写操作', async () => {
    const { deps: d, calls, host, fs } = deps()
    host.isLive = vi.fn(async () => true)
    await expect(deleteSession(d)('session-abc')).rejects.toMatchObject({ code: 'sessiondelete/live' })
    expect(calls).toEqual([])
    expect(host.archive).not.toHaveBeenCalled()
    expect(host.unarchive).not.toHaveBeenCalled()
    expect(host.detach).not.toHaveBeenCalled()
    expect(fs.rename).not.toHaveBeenCalled()
  })

  // 删除不再用归档藏会话：先摘账本，搬目录，再让 `memberGone` 把 session + agent 一起摘掉，
  // 最后发 `api-session/removed`。归档集在删除前后都不变（用户原本归档的仍归档）。
  it('顺序固定为 detach → rename → evictLive → announceRemoved（不碰归档）', async () => {
    const { deps: d, calls, host } = deps()
    await deleteSession(d)('session-abc')
    expect(calls).toEqual(['detach', 'rename', 'evictLive', 'announceRemoved'])
    expect(host.archive).not.toHaveBeenCalled()
    expect(host.unarchive).not.toHaveBeenCalled()
  })

  it('删除前已归档的会话：不碰归档集，清单里记下"原本就是归档态"', async () => {
    const { deps: d, calls, host } = deps()
    host.isArchived = vi.fn(async () => true)
    const { entry } = await deleteSession(d)('session-abc')
    expect(calls).toEqual(['detach', 'rename', 'evictLive', 'announceRemoved'])
    expect(entry).toMatchObject({ wasArchived: true })
    expect(host.archive).not.toHaveBeenCalled()
    expect(host.unarchive).not.toHaveBeenCalled()
  })

  it('rename 失败即回滚已摘的账本，并把原始错误带出', async () => {
    const { deps: d, calls, fs } = deps()
    const boom = new Error('EXDEV')
    fs.rename = vi.fn(async () => { calls.push('rename'); throw boom })
    const err = await failureOf(deleteSession(d)('session-abc'))
    expect(err).toMatchObject({ code: 'sessiondelete/io' })
    expect(err.cause).toBe(boom)
    // 反向调用序：attach 挂回账本；归档没被碰过
    expect(calls).toEqual(['detach', 'rename', 'attach'])
  })

  // 真机 2026-11-26 复现的形态：Windows 目录里有打开的句柄时 rename 回 EPERM；一次批量里一条成员被占用、
  // 另一条正常。这里钉住"瞬态占用由动词层小步重试吞掉，成功落地且不触发回滚"（ADR-0073）。
  it('目录搬移遇瞬态 EPERM：重试后成功落地，不回滚账本', async () => {
    const { deps: d, calls, fs, manifest } = deps()
    const realRename = fs.rename
    let left = 2
    fs.rename = vi.fn(async (from: string, to: string) => {
      if (left-- > 0) throw Object.assign(new Error('EPERM'), { code: 'EPERM' })
      return realRename(from, to)
    })
    const { entry } = await deleteSession(d)('session-abc')
    expect(fs.rename).toHaveBeenCalledTimes(3)
    expect(calls).toEqual(['detach', 'rename', 'evictLive', 'announceRemoved'])
    expect(entry.sessionId).toBe('session-abc')
    expect(await manifest.list()).toHaveLength(1)
  })

  it('清单失败回滚搬回目录时遇瞬态占用：同一搬回重试后再挂回账本', async () => {
    const { deps: d, calls, fs, manifest } = deps()
    manifest.add = vi.fn(async () => { throw new Error('storage boom') })
    const realRename = fs.rename
    let n = 0
    fs.rename = vi.fn(async (from: string, to: string) => {
      n += 1
      // 第 2 次调用是回滚那一次：失败一次后由重试补上。
      if (n === 2) throw Object.assign(new Error('EPERM'), { code: 'EPERM' })
      return realRename(from, to)
    })
    await expect(deleteSession(d)('session-abc')).rejects.toMatchObject({ code: 'sessiondelete/io' })
    expect(fs.rename).toHaveBeenCalledTimes(3)
    expect(calls).toEqual(['detach', 'rename', 'rename', 'attach'])
  })

  // 清单登记是最后一件写：它失败也必须把账本 / 文件全部退回去，否则会话就成了
  // 「文件在回收站里、面板却看不见」的孤儿（判据住 `src/verbs/delete-session.ts`：清册行是最后一件写，
  // 它失败就把前几步全退回去）。
  it('清单登记失败即整体回退：目录搬回原处、账本挂回', async () => {
    const { deps: d, calls, fs, manifest } = deps()
    const boom = new Error('storage boom')
    manifest.add = vi.fn(async () => { throw boom })
    const err = await failureOf(deleteSession(d)('session-abc'))
    expect(err).toMatchObject({ code: 'sessiondelete/io' })
    expect(err.cause).toBe(boom)
    expect(calls).toEqual(['detach', 'rename', 'rename', 'attach'])
    const rename = fs.rename
    expect(rename.mock.calls).toEqual([
      [sessionDirOf('--C-develop-GitHub-dsh-ebook--', 'session-abc', HOME),
        trashDirOf('20260930T130500Z-session-abc', HOME)],
      [trashDirOf('20260930T130500Z-session-abc', HOME),
        sessionDirOf('--C-develop-GitHub-dsh-ebook--', 'session-abc', HOME)],
    ])
  })

  it('detach 失败即退出，文件一动不动', async () => {
    const { deps: d, calls, host, fs } = deps()
    const boom = new Error('detach boom')
    host.detach = vi.fn(async () => { calls.push('detach'); throw boom })
    const err = await failureOf(deleteSession(d)('session-abc'))
    expect(err).toMatchObject({ code: 'sessiondelete/io' })
    expect(err.cause).toBe(boom)
    expect(calls).toEqual(['detach'])
    expect(fs.rename).not.toHaveBeenCalled()
  })

  it('三件纯读失败即退出，不留下任何写过的痕迹（读在写之前）', async () => {
    const { deps: d, calls, host } = deps()
    const boom = new Error('读取标题失败')
    host.titleOf = vi.fn(async () => { throw boom })
    const err = await failureOf(deleteSession(d)('session-abc'))
    expect(err).toMatchObject({ code: 'sessiondelete/io' })
    expect(err.cause).toBe(boom)
    expect(calls).toEqual([])
  })

  it('成功后清单里有且只有一条，记录了原目录名、工作区与归档态', async () => {
    const { deps: d, manifest } = deps()
    const { entry } = await deleteSession(d)('session-abc')
    expect(entry).toMatchObject({
      id: '20260930T130500Z-session-abc', sessionId: 'session-abc',
      projectDir: '--C-develop-GitHub-dsh-ebook--', workspaceId: 'ws-1', wasArchived: false,
      title: '会话标题', sizeBytes: 1024,
    })
    expect(await manifest.list()).toHaveLength(1)
  })

  // 假 fs 是路径树状态机：动词的 `rename` 真的搬目录——删除后源目录从世界里消失、目标出现。
  // 过去 `rename` 只记账不搬（"旁观"），"目标路径算错 / rename 后源目录仍在"这类世界观 bug 对经世界跑的
  // 动词用例不可见；现在它们当场可见（这条断言在旧假件下会红：源目录仍在）。
  it('删除真的把目录搬进回收站：源目录从世界消失、目标出现（漂移可观察）', async () => {
    const { deps: d, fs } = deps()
    const sessionDir = sessionDirOf('--C-develop-GitHub-dsh-ebook--', 'session-abc', HOME)
    await deleteSession(d)('session-abc')
    expect(await fs.exists(sessionDir)).toBe(false)
    // 目标出现的判据只能钉在 `listDirs` 上：`exists` 缺省恒真，单靠它这半边是空转。
    expect(await fs.listDirs(`${HOME}/session-trash`)).toContain('20260930T130500Z-session-abc')
  })

  // 未分组的会话（宿主自己的"删除工作区"就会造出这种：目录与日志都留着，只是没有账目）
  // 照样可删：账本那一步没有可摘的东西，清单里把工作区记成空串，恢复时也不再挂账本。
  it('未分组的会话照样能删：不摘账本，清单里工作区记空串', async () => {
    const { deps: d, calls, host } = deps()
    host.workspaceOf = vi.fn(async () => undefined)
    const { entry } = await deleteSession(d)('session-abc')
    expect(calls).toEqual(['rename', 'evictLive', 'announceRemoved'])
    expect(entry).toMatchObject({ workspaceId: '', wasArchived: false })
  })

  it('未分组 + 已归档：只动文件', async () => {
    const { deps: d, calls, host } = deps()
    host.workspaceOf = vi.fn(async () => undefined)
    host.isArchived = vi.fn(async () => true)
    const { entry } = await deleteSession(d)('session-abc')
    expect(calls).toEqual(['rename', 'evictLive', 'announceRemoved'])
    expect(entry).toMatchObject({ workspaceId: '', wasArchived: true })
  })

  it('未分组 + rename 失败：不回挂账本，也不碰归档', async () => {
    const { deps: d, calls, host, fs } = deps()
    host.workspaceOf = vi.fn(async () => undefined)
    const boom = new Error('EXDEV')
    fs.rename = vi.fn(async () => { calls.push('rename'); throw boom })
    const err = await failureOf(deleteSession(d)('session-abc'))
    expect(err).toMatchObject({ code: 'sessiondelete/io' })
    expect(calls).toEqual(['rename'])
    expect(host.attach).not.toHaveBeenCalled()
    expect(host.archive).not.toHaveBeenCalled()
    expect(host.unarchive).not.toHaveBeenCalled()
  })

  it('只有推不出项目目录（账本 header 里查不到）才判 not-found，且零副作用', async () => {
    const { deps: d, calls, host } = deps()
    host.projectDirOf = vi.fn(async () => undefined)
    await expect(deleteSession(d)('session-abc')).rejects.toMatchObject({ code: 'sessiondelete/not-found' })
    expect(calls).toEqual([])
  })

  // 通告只在**知道宿主列表已经干净**时才发：`unknown`（live store 读不到 / 形状不符 / detach 抛）
  // 意味着它可能还活着、还挂在列表上，这时候发"已移除"就是假话（重连后那一行会自己长回来）。
  // 请不动也不影响删除结果——端口契约是不抛。
  it('摘内存结果未知（unknown）时不发移除通告，删除照样成功', async () => {
    const { deps: d, host, manifest } = deps()
    host.evictLive = vi.fn(async () => 'unknown' as const)
    const { entry } = await deleteSession(d)('session-abc')
    expect(entry).toMatchObject({ sessionId: 'session-abc', workspaceId: 'ws-1' })
    expect(await manifest.list()).toHaveLength(1)
    expect(host.evictLive).toHaveBeenCalledWith('session-abc')
    expect(host.announceRemoved).not.toHaveBeenCalled()
  })

  it('会话目录不存在时报 not-found，不静默当作成功', async () => {
    const { deps: d, fs } = deps()
    fs.exists = vi.fn(async () => false)
    await expect(deleteSession(d)('session-abc')).rejects.toMatchObject({ code: 'sessiondelete/not-found' })
  })
})

// 宿主把 session id 编成目录段再落盘（`encodeSegment`：`~`/空格/Unicode 都编成 `~XXXX`）。
// 删除必须按**同一段**拼源目录、写条目 id：拿原始 id 拼路径时，一旦 id 含这些字符，
// 删除就会对一个不存在的目录报 not-found——而那条会话其实还在盘上。
describe('删除动词 · 宿主目录段编码', () => {
  const PROJECT = '--C-develop-GitHub-dsh-ebook--'

  it('源目录与条目 id 都用编码后的目录段；清册仍记原始 sessionId', async () => {
    // 期望值是宿主 `encodeSegment` 的输出（逐字）：沙箱里没有宿主源码，向量就在这里钉住镜像。
    const sessionId = '会话 A~'
    const encoded = '~4F1A~8BDD~0020A~007E'
    const { deps: d, fs } = deps()
    const { entry } = await deleteSession(d)(sessionId)

    expect(entry.sessionId).toBe(sessionId)
    expect(entry.id).toBe(`20260930T130500Z-${encoded}`)
    expect(fs.rename.mock.calls).toEqual([[
      sessionDirOf(PROJECT, encoded, HOME),
      trashDirOf(`20260930T130500Z-${encoded}`, HOME),
    ]])
  })

  it('孩子也按自己的编码段搬：父与孩子各落各自目录', async () => {
    const kid = { sessionId: 'session-a~b', projectDir: '--p--' }
    const d = deps({ members: { 'session-parent': [kid] } })
    const { entry: parent, movedSessionIds } = await deleteSession(d.deps)('session-parent')

    expect(movedSessionIds).toEqual(['session-parent', 'session-a~b'])
    const renamedTo = d.fs.rename.mock.calls.map((call) => call[1])
    expect(renamedTo).toContain(trashDirOf(`20260930T130500Z-session-a~007Eb`, HOME))
    // 父行仍是未编码 id 的编码段（安全字母表 = 原样），孩子行的 parentEntryId 指向它。
    const rows = await d.manifest.list()
    expect(rows.find((row) => row.sessionId === 'session-a~b')?.parentEntryId).toBe(parent.id)
  })
})

// 级联（判据住 `src/trash/groups.ts`，词表见 CONTEXT.md 的「无主子会话」条）：宿主的客户端把 `origin:"subagent"` 整排藏了 ⇒ 用户点掉的是一条父会话，
// 而它留在盘上的孩子既看不见也占着字节（本机实测 41 条父留了 320 个目录 / 74.6 MB）。
// 这一格把它们**一起搬进回收站**：孩子各自成目录、各自一行，`parentEntryId` 指向父那一行；恢复与彻底删除都按整组走。
describe('删除动词 · 级联（盘上的孩子一起进回收站）', () => {
  const kidA = { sessionId: 'session-kidA', projectDir: '--p--' }
  const kidB = { sessionId: 'session-kidB', projectDir: '--p--' }

  it('父搬进去之后，每个孩子各自成目录、各自一行，清册记 parentEntryId 指向父那一行', async () => {
    const d = deps({ members: { 'session-parent': [kidA, kidB] } })
    const { entry: parent } = await deleteSession(d.deps)('session-parent')
    const rows = await d.manifest.list()
    expect(rows.map(r => r.sessionId).sort()).toEqual(['session-kidA', 'session-kidB', 'session-parent'])
    expect(rows.find(r => r.sessionId === 'session-parent')?.id).toBe(parent.id)
    expect(rows.filter(r => r.sessionId !== 'session-parent').map(r => r.parentEntryId)).toEqual([parent.id, parent.id])
    expect(parent.parentEntryId).toBeUndefined() // 父那一行自己不记 parent
    // 三个目录都真的搬了，且每个孩子落在**自己**的回收站目录里（不是塞进父的目录）
    expect(d.fs.rename).toHaveBeenCalledTimes(3)
    // 每个孩子落在**自己**的回收站目录里（不是塞进父那一格）；同一刻删除 ⇒ id 只差在目录名那一段
    const NOW = Date.UTC(2026, 8, 30, 13, 5, 0)
    const movedTo = d.fs.rename.mock.calls.map(c => c[1]).sort()
    expect(movedTo).toEqual([
      trashDirOf(makeEntryId(NOW, 'session-kidA'), HOME),
      trashDirOf(makeEntryId(NOW, 'session-kidB'), HOME),
      trashDirOf(parent.id, HOME),
    ].sort())
  })

  it('交回这次真的搬走的成员（父 + 盘上的孩子）', async () => {
    const d = deps({ members: { 'session-parent': [kidA, kidB] } })
    const result = await deleteSession(d.deps)('session-parent')
    expect(result.movedSessionIds).toEqual(['session-parent', 'session-kidA', 'session-kidB'])
  })

  // 语料看不见不是"盘上没有后代"，但写侧只许降级：父照样删，盘上残留留给 `GET /orphans` 兜底。
  it('语料看不见（available:false）⇒ 只删父，不因此失败', async () => {
    const d = deps({ membersAvailable: false })
    const { entry } = await deleteSession(d.deps)('session-parent')
    expect(entry).toMatchObject({ sessionId: 'session-parent' })
    // 写侧真的读了这一格（不是碰巧走了"没有孩子"的默认值）：缺席也必须点名问过这个父。
    expect(d.host.subagentMembersOf).toHaveBeenCalledWith(['session-parent'])
    const rows = await d.manifest.list()
    expect(rows.map(r => r.sessionId)).toEqual(['session-parent'])
    expect(d.fs.rename).toHaveBeenCalledTimes(1)
  })

  it('宿主报了孩子但盘上没有那个目录 ⇒ 跳过它，其余照搬，不让整次删除失败', async () => {
    const d = deps({ members: { 'session-parent': [kidA, kidB] } })
    d.fs.exists = vi.fn(async (p: string) => !p.includes('session-kidB'))
    const { entry: parent, movedSessionIds } = await deleteSession(d.deps)('session-parent')
    const rows = await d.manifest.list()
    expect(rows.map(r => r.sessionId).sort()).toEqual(['session-kidA', 'session-parent'])
    expect(rows.find(r => r.sessionId === 'session-kidA')?.parentEntryId).toBe(parent.id)
    expect(movedSessionIds).toEqual(['session-parent', 'session-kidA'])
  })

  // 读不出不是"盘上没有"：跳过的代价是那个孩子永远隐身（不在回收站、也不算孤儿）。
  it('孩子目录读不出（EACCES）⇒ 整次删除失败、零写入，不按"目录缺席"跳过', async () => {
    const d = deps({ members: { 'session-parent': [kidA, kidB] } })
    const eacces = Object.assign(new Error('EACCES: permission denied'), { code: 'EACCES' })
    d.fs.exists = vi.fn(async (p: string) => {
      if (p.includes('session-kidB')) throw eacces
      return true
    })

    await expect(deleteSession(d.deps)('session-parent')).rejects.toThrow('EACCES: permission denied')
    expect(d.fs.rename).not.toHaveBeenCalled()
    expect(d.host.detach).not.toHaveBeenCalled()
    expect(await d.manifest.list()).toEqual([])
  })

  it('孩子在跑 ⇒ 整组拒绝，一个字节都不动（不替用户终止正在跑的活）', async () => {
    const d = deps({ members: { 'session-parent': [kidA, kidB] } })
    d.host.isLive = vi.fn(async (id: string) => id === 'session-kidB')
    await expect(deleteSession(d.deps)('session-parent')).rejects.toMatchObject({ code: 'sessiondelete/live' })
    expect(d.fs.rename).not.toHaveBeenCalled()
    expect(d.host.archive).not.toHaveBeenCalled()
    expect(await d.manifest.list()).toEqual([])
  })

  it('第二个孩子搬不动 ⇒ 已经搬进去的（父与第一个孩子）一起滚回原处', async () => {
    const d = deps({ members: { 'session-parent': [kidA, kidB] } })
    d.fs.rename = vi.fn(async (_from: string, to: string) => {
      if (to.includes('session-kidB')) throw new Error('EBUSY')
    })
    await expect(deleteSession(d.deps)('session-parent')).rejects.toMatchObject({ code: 'sessiondelete/io' })
    // 反向 rename：搬进去的两个都搬回去（父与 kidA），且失败的那个不留下半行清册
    const rolled = d.fs.rename.mock.calls.filter((c) => c[0].includes('session-trash') && c[1].includes('/sessions/'))
    expect(rolled.length).toBe(2)
    expect(await d.manifest.list()).toEqual([])
    // 这两条已经收过"已移除"通告；回滚成功必须补"已恢复"，否则客户端那一行要等到重连才回来。
    expect(d.host.announceRestored).toHaveBeenCalledWith(['session-parent'])
    expect(d.host.announceRestored).toHaveBeenCalledWith(['session-kidA'])
  })

  it('回滚本身失败 ⇒ 原错误保留，回滚失败进 details，且不发"已恢复"', async () => {
    const { deps: d, fs, host } = deps({ members: { 'session-parent': [kidA, kidB] } })
    fs.rename = vi.fn(
      async (from: string, to: string) => {
        if (to.includes('session-kidB')) throw new Error('EBUSY')
        if (from.includes('session-trash') && to.includes('/sessions/')) throw new Error('EACCES')
      },
    )
    const err = await failureOf(deleteSession(d)('session-parent'))
    expect(err.code).toBe('sessiondelete/io')
    // 非对称匹配器返回 any：先落到 unknown 再交给 toMatchObject，断言本身不放宽。
    const rollbackFailures: unknown = expect.arrayContaining([expect.stringContaining('EACCES')])
    expect(err.details).toMatchObject({ rollbackFailures })
    expect(host.announceRestored).not.toHaveBeenCalled()
  })

  it('目录已搬回、清册行摘不掉 ⇒ 仍通告已恢复，失败进 details', async () => {
    const { deps: d, fs, host, manifest } = deps({ members: { 'session-parent': [kidA, kidB] } })
    fs.rename = vi.fn(async (_from: string, to: string) => {
      if (to.includes('session-kidB')) throw new Error('EBUSY')
    })
    // 回滚里目录先回来、再摘清册行；这一步失败不该把已经回盘的会话继续藏在客户端里。
    manifest.remove = vi.fn(async () => { throw new Error('storage boom') })
    const err = await failureOf(deleteSession(d)('session-parent'))
    expect(err.code).toBe('sessiondelete/io')
    const rollbackFailures: unknown = expect.arrayContaining([expect.stringContaining('清册行摘除失败')])
    expect(err.details).toMatchObject({ rollbackFailures })
    expect(host.announceRestored).toHaveBeenCalledWith(['session-parent'])
    expect(host.announceRestored).toHaveBeenCalledWith(['session-kidA'])
  })
})

// 步骤级 tick（写入进度）：步骤码→动作点的唯一映射住 `src/verbs/write-progress.ts`，这里把它钉成可观察的
// 序列——放行闸挂在各动作点的替身上，放行点读 `readWriteProgress().step`（不给记录器加测试专用状态）。
describe('删除动词 · 步骤级 tick', () => {
  it('measuring（读现场）→ ledger（摘账本）→ moving（搬目录）→ ledger（写清册行）→ finishing（memberGone）', async () => {
    resetWriteProgress()
    const { deps: d, host, fs, manifest } = deps()
    // 假件的 `manifest.add` 不是 `vi.fn`，包一层原实现才挂得上放行闸。
    const add = vi.fn(manifest.add)
    manifest.add = add
    const heldTitle = holdCalls(host.titleOf)
    const heldDetach = holdCalls(host.detach)
    const heldRename = holdCalls(fs.rename)
    const heldAdd = holdCalls(add)
    const heldEvict = holdCalls(host.evictLive)
    const { observed, at } = stepProbe()
    writeProgress.begin('delete', ['session-abc'], 1)
    const run = deleteSession(d)('session-abc')
    await at(heldTitle)
    await at(heldDetach)
    await at(heldRename)
    await at(heldAdd)
    await at(heldEvict)
    await run
    writeProgress.finish()
    expectSteps(observed, ['measuring', 'ledger', 'moving', 'ledger', 'finishing'])
  })
})

// 批量删除的预测与实况可以不符：预裁决的「盘上在场」探测只是**调度依据**（carried 挂不挂、谁跟谁串行），
// 真搬走谁以动词自己的实况读为准。孩子在执行期才出现时：父按实况把它带走一次，后来者回幂等 null——
// 不双搬（两次 rename 同一个目录会有一条变报错）、不报错。
describe('批量删除 · 预测与实况不符（执行期才出现的子目录）', () => {
  const kid = { sessionId: 'session-kid', projectDir: '--p--' }

  it('预测说孩子不在盘上、执行期才出现：不双搬、不报错——预判只管调度，实况为准', async () => {
    const d = deps({ members: { 'session-parent': [kid] } })
    // 第一次问（预裁决的盘上在场探测）说不在；之后（动词的实况读）说在。
    let kidProbes = 0
    d.fs.exists = vi.fn(async (p: string) => {
      if (!p.includes('session-kid')) return true
      kidProbes += 1
      return kidProbes > 1
    })
    const outcomes = await applyActions(d.deps, 'delete', ['session-parent', 'session-kid'])
    expect(outcomes.map((item) => item.ok)).toEqual([true, true])
    // 实况把孩子带走了 ⇒ 后来者回幂等 null：不是报错，也不是搬第二次
    expect(outcomes[1]).toMatchObject({ ok: true, value: null })
    const kidMoves = d.fs.rename.mock.calls.filter((call) => call.some((p) => p.includes('session-kid')))
    expect(kidMoves).toHaveLength(1)
    const rows = await d.manifest.list()
    expect(rows.filter((row) => row.sessionId === 'session-kid')).toHaveLength(1)
  })
})
