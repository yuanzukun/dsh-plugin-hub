// 批量删除确认框（2026-10-17）：数说清自己的、失败原文落行、重试只发失败 id。
// 假 adapter 驱动真组件（与 delete-menu-item.test.tsx 同款）：请求现场在场景里，setup 每例换新。
import { act, fireEvent, render, renderHook, screen, waitFor } from '@testing-library/react'
import { describe, expect, it, vi } from 'vitest'
import {
  BatchConfirmHost,
  clearDeleteBatchRequest,
  requestDeleteBatch,
  useDeleteBatchRequest,
} from '../../src/client/batch-confirm.js'
import { getPicks, shrinkPicksToFailures, togglePick } from '../../src/client/batch-selection-store.js'
import { useTrashRevision } from '../../src/client/trash-store.js'
import { UndoToast } from '../../src/client/undo-toast.js'
import { createFakeRemote, remoteFail, remoteOk } from './support/fake-remote.js'
import type { RemoteOutcome } from '../../src/client/remote.js'
import type { ApplyOutcome, WriteProgressWire } from '../../src/shared/wire.js'
import { countOutcomes, deleteOutcomes } from './support/outcomes.js'



describe('请求现场', () => {
  it('每发一批请求 seq 递增（确认框靠它重挂载）；空名单不发框也不占 seq', () => {
    const { result } = renderHook(() => useDeleteBatchRequest())
    requestDeleteBatch([])
    expect(result.current).toBeNull()
    act(() => {
      requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    })
    expect(result.current).toMatchObject({ seq: 1, items: [{ sessionId: 'a', title: 'A' }] })
    act(() => {
      requestDeleteBatch([{ sessionId: 'b', title: 'B' }])
    })
    expect(result.current).toMatchObject({ seq: 2, items: [{ sessionId: 'b', title: 'B' }] })
  })

  it('重试轮收缩失败名单不改 seq（框不重挂载，逐条失败原文留在框里）', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids, ['b'])),
    )
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    requestDeleteBatch(getPicks(), shrinkPicksToFailures)
    const view = renderHook(() => useDeleteBatchRequest())
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 2 条' }))
    await waitFor(() =>
      expect(view.result.current?.items.map((item) => item.sessionId)).toEqual(['b']),
    )
    expect(view.result.current?.seq).toBe(1)
    // 收缩只动请求现场的 items：seq 没变 ⇒ 框不重挂载，框内本地失败面（原文）还在。
    expect(screen.getByText('会话目录不在盘上')).toBeInTheDocument()
  })
})

describe('批量确认框', () => {
  it('写入在飞时取消/关闭都拦住（busy 关框规则）', async () => {
    let release: (value: RemoteOutcome<ApplyOutcome[]>) => void = () => {}
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]): Promise<RemoteOutcome<ApplyOutcome[]>> => {
      if (action === 'count') return remoteOk(countOutcomes(ids))
      return new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => { release = resolve })
    })
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))
    await waitFor(() => expect(screen.getByRole('button', { name: '取消' })).toBeDisabled())
    fireEvent.click(screen.getByRole('button', { name: '取消' }))
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    release(remoteOk(deleteOutcomes(['a'])))
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
  })

  it('写在飞时框内出进度行：按钮换动作文案，/progress 的 running 帧按写身份认领', async () => {
    let release!: (value: RemoteOutcome<ApplyOutcome[]>) => void
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]): Promise<RemoteOutcome<ApplyOutcome[]>> => {
      if (action === 'count') return remoteOk(countOutcomes(ids))
      return new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => { release = resolve })
    })
    const progress = vi.fn(async (): Promise<RemoteOutcome<WriteProgressWire>> => remoteOk({
      status: 'running', action: 'delete', ids: ['a'], done: 1, total: 2, step: 'ledger', startedAt: Date.now(),
    }))
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes, progress })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))
    // 忙碌面两件一起上：主按钮换 spinner + 动作文案，框内正文出认领到的 k/N 进度行。
    expect(await screen.findByRole('button', { name: '正在删除' })).toBeDisabled()
    expect(await screen.findByRole('status')).toHaveTextContent(/正在删除 1\/2 · 记账中 · 已用 \d+ 秒/)
    release(remoteOk(deleteOutcomes(['a'])))
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
  })

  it('同一 tick 连点两次「移入回收站」：第二趟被同步挡回 ⇒ 只发一条删除，框不提前收', async () => {
    let release!: (value: RemoteOutcome<ApplyOutcome[]>) => void
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]): Promise<RemoteOutcome<ApplyOutcome[]>> => {
      if (action === 'count') return remoteOk(countOutcomes(ids))
      return new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => { release = resolve })
    })
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    const confirm = await screen.findByRole('button', { name: '移入回收站 1 条' })
    act(() => {
      fireEvent.click(confirm)
      fireEvent.click(confirm)
    })
    await waitFor(() => expect(applyOutcomes.mock.calls.filter(([action]) => action === 'delete')).toHaveLength(1))
    // 挡回来的那一趟没有结论：框留在原地，等第一条真落地。
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    release(remoteOk(deleteOutcomes(['a'])))
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
  })

  it('标题随条数：1 条是单删那句，多条是「删除这些 N 个会话？」', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids)),
    )
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    expect(await screen.findByRole('heading', { name: '删除这个会话？' })).toBeInTheDocument()
  })

  it('子会话两句只在有数时说：chip 有才标、汇总句 K>0 才出；读不到整句不说且主按钮照常可点', async () => {
    const applyOutcomes = vi.fn(async (_action: string, ids: readonly string[]) =>
      remoteOk(countOutcomes(ids, { a: 2 })),
    )
    requestDeleteBatch([
      { sessionId: 'a', title: 'A' },
      { sessionId: 'b', title: 'B' },
    ])
    const first = render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    expect(await screen.findByText('删除这些 2 个会话？')).toBeInTheDocument()
    expect(screen.getByText('含 2 个子会话')).toBeInTheDocument()
    expect(screen.queryByText('含 0 个子会话')).not.toBeInTheDocument()
    expect(screen.getByText('含 2 个子会话，将一起移入回收站。')).toBeInTheDocument()
    // 同一个 document 里先收掉上一幕，否则两个框同屏、按名查会撞
    first.unmount()

    clearDeleteBatchRequest()
    const failing = vi.fn(async () => remoteFail({ code: 'sessiondelete/io', message: '读不到' }))
    requestDeleteBatch([{ sessionId: 'c', title: 'C' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes: failing })} />)
    expect(await screen.findByText('删除这个会话？')).toBeInTheDocument()
    expect(screen.queryByText(/将一起移入回收站/)).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: '移入回收站 1 条' })).toBeEnabled()
  })

  it('目标列表限高滚动：几十条也不会把标题和底部按钮顶出弹框', async () => {
    const applyOutcomes = vi.fn(async (_action: string, ids: readonly string[]) => remoteOk(countOutcomes(ids)))
    const items = Array.from({ length: 80 }, (_, i) => ({ sessionId: `s${i}`, title: `S${i}` }))
    requestDeleteBatch(items)
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)

    const card = document.querySelector('[data-dsh-session-delete="batch-target-card"]')
    expect(card).not.toBeNull()
    expect(card).toHaveStyle({ maxHeight: '280px', overflow: 'auto' })
    // 标题与底部动作还在（列表只在卡片内部滚）
    expect(screen.getByRole('heading', { name: '删除这些 80 个会话？' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '取消' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '移入回收站 80 条' })).toBeInTheDocument()
  })

  it('成功路径：一次 applyOutcomes、框收工、发批量撤销横幅、选中集清空', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids)),
    )
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    requestDeleteBatch(getPicks(), shrinkPicksToFailures)
    render(
      <>
        <BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />
        <UndoToast deps={createFakeRemote({ applyOutcomes })} />
      </>,
    )
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 2 条' }))
    await waitFor(() => expect(screen.getByText('2 条会话已移入回收站')).toBeInTheDocument())
    expect(applyOutcomes).toHaveBeenCalledWith('delete', ['a', 'b'])
    expect(screen.queryByRole('button', { name: '移入回收站 2 条' })).not.toBeInTheDocument()
    expect(getPicks()).toEqual([])
  })

  it('不交收缩钩子那一面（归档档页脚）：全成功也不动宿主侧栏的选中集', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids)),
    )
    togglePick({ sessionId: 'x', title: 'X' })
    togglePick({ sessionId: 'y', title: 'Y' })
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
    expect(applyOutcomes).toHaveBeenCalledWith('delete', ['a'])
    expect(getPicks().map((item) => item.sessionId)).toEqual(['x', 'y'])
  })

  it('不交收缩钩子那一面：部分失败也只收框自己的名单，宿主侧栏勾选原样留着', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids, ['b'])),
    )
    togglePick({ sessionId: 'x', title: 'X' })
    requestDeleteBatch([
      { sessionId: 'a', title: 'A' },
      { sessionId: 'b', title: 'B' },
    ])
    const view = renderHook(() => useDeleteBatchRequest())
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 2 条' }))
    await waitFor(() => expect(view.result.current?.items.map((item) => item.sessionId)).toEqual(['b']))
    expect(getPicks().map((item) => item.sessionId)).toEqual(['x'])
  })

  it('部分失败：原文落它自己那行、按钮变「重试这 1 条」、重试只发失败 id', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids, ['b'])),
    )
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    requestDeleteBatch(getPicks(), shrinkPicksToFailures)
    render(
      <>
        <BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />
        <UndoToast deps={createFakeRemote({ applyOutcomes })} />
      </>,
    )
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 2 条' }))
    expect(await screen.findByText(/会话目录不在盘上/)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '重试这 1 条' })).toBeInTheDocument()
    expect(screen.getByText('1 条会话已移入回收站')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: '重试这 1 条' }))
    await waitFor(() => expect(applyOutcomes).toHaveBeenLastCalledWith('delete', ['b']))
    expect(applyOutcomes).toHaveBeenCalledTimes(3)
  })

  it('重试轮收缩后汇总子会话数只算还在名单里的（不把已移走的算进去）', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids, { a: 2, b: 3 }) : deleteOutcomes(ids, ['b'])),
    )
    requestDeleteBatch([
      { sessionId: 'a', title: 'A' },
      { sessionId: 'b', title: 'B' },
    ])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    expect(await screen.findByText('含 5 个子会话，将一起移入回收站。')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: '移入回收站 2 条' }))
    expect(await screen.findByText(/会话目录不在盘上/)).toBeInTheDocument()
    expect(screen.getByText('含 3 个子会话，将一起移入回收站。')).toBeInTheDocument()
    expect(screen.queryByText('含 5 个子会话，将一起移入回收站。')).not.toBeInTheDocument()
  })

  it('旧批次的成功不清掉后来发布的批次（clear 带 expected 比较）', async () => {
    // A 在飞时用户又发布了 B（框按 seq 重挂载成 B）。A 晚到的成功只许收 A 自己。
    let release!: (value: RemoteOutcome<ApplyOutcome[]>) => void
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]): Promise<RemoteOutcome<ApplyOutcome[]>> => {
      if (action === 'count') return remoteOk(countOutcomes(ids))
      return new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => { release = resolve })
    })
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))

    act(() => { requestDeleteBatch([{ sessionId: 'b', title: 'B' }]) })
    expect(await screen.findByText('B')).toBeInTheDocument()

    await act(async () => { release(remoteOk(deleteOutcomes(['a']))) })
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    expect(screen.getByText('B')).toBeInTheDocument()
  })

  it('旧批次的部分失败不收缩后来发布的批次（shrink 带 expected 比较）', async () => {
    // A = [a1, a2] 在飞；期间发布 B = [a1, b]。A 晚到的部分失败只收 a1——旧实现会把 B 的名单
    // 收缩成 [a1]（条数、目标列表全被旧实例改写）。
    let release!: (value: RemoteOutcome<ApplyOutcome[]>) => void
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]): Promise<RemoteOutcome<ApplyOutcome[]>> => {
      if (action === 'count') return remoteOk(countOutcomes(ids))
      return new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => { release = resolve })
    })
    requestDeleteBatch([
      { sessionId: 'a1', title: 'A1' },
      { sessionId: 'a2', title: 'A2' },
    ])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 2 条' }))

    act(() => {
      requestDeleteBatch([
        { sessionId: 'a1', title: 'A1' },
        { sessionId: 'b', title: 'B' },
      ])
    })
    expect(await screen.findByText('删除这些 2 个会话？')).toBeInTheDocument()

    await act(async () => { release(remoteOk(deleteOutcomes(['a1', 'a2'], ['a1']))) })
    // B 的框不受旧失败影响：还是 2 条、还是「删除这些 2 个会话？」。
    expect(screen.getByText('删除这些 2 个会话？')).toBeInTheDocument()
    expect(screen.getByText('B')).toBeInTheDocument()
  })

  it('整批失败：失败原文落行、不发撤销横幅，但回收站照样收到失效通告', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids, ids)),
    )
    togglePick({ sessionId: 'a', title: 'A' })
    requestDeleteBatch(getPicks(), shrinkPicksToFailures)
    const revision = renderHook(() => useTrashRevision())
    render(
      <>
        <BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />
        <UndoToast deps={createFakeRemote({ applyOutcomes })} />
      </>,
    )
    expect(revision.result.current).toBe(0)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))
    expect(await screen.findByText('会话目录不在盘上')).toBeInTheDocument()
    expect(screen.queryByText(/条会话已移入回收站/)).not.toBeInTheDocument()
    expect(getPicks()).toHaveLength(1)
    // 回滚失败可能留下半套：信封成功就要让清单重读，哪怕一条都没落地。
    await waitFor(() => expect(revision.result.current).toBe(1))
  })
})
