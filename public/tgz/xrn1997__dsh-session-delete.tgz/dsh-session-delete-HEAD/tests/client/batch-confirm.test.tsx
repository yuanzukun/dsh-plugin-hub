// 批量删除确认框（2026-10-17）：数说清自己的、失败原文落行、重试只发失败 id。
// 假 adapter 驱动真组件（与 delete-menu-item.test.tsx 同款）：现场是模块级的，每个用例前清一次。
import { act, fireEvent, render, renderHook, screen, waitFor } from '@testing-library/react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import {
  BatchConfirmHost,
  clearDeleteBatchRequest,
  requestDeleteBatch,
  resetBatchConfirm,
  useDeleteBatchRequest,
} from '../../src/client/batch-confirm.js'
import { getPicks, resetSelection, togglePick } from '../../src/client/batch-selection-store.js'
import { resetTrashStore, useTrashRevision } from '../../src/client/trash-store.js'
import { UndoToast } from '../../src/client/undo-toast.js'
import { resetUndoNotice } from '../../src/client/undo-notices.js'
import { createFakeRemote } from './support/fake-remote.js'
import type { ApplyOutcome } from '../../src/client/remote.js'
import { countOutcomes, deleteOutcomes } from './support/outcomes.js'

beforeEach(() => {
  resetBatchConfirm()
  resetSelection()
  resetUndoNotice()
  resetTrashStore()
})

afterEach(() => {
  resetBatchConfirm()
  resetSelection()
  resetUndoNotice()
  resetTrashStore()
})

describe('模块级现场', () => {
  it('每发一批请求 seq 递增（确认框靠它重挂载）；空名单不发框也不占 seq', () => {
    const { result } = renderHook(() => useDeleteBatchRequest())
    requestDeleteBatch([])
    expect(result.current).toBeNull()
    act(() => {
      requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    })
    expect(result.current).toMatchObject({ seq: 1, items: [{ sessionId: 'a', title: 'A' }] })
    act(() => {
      requestDeleteBatch([{ sessionId: 'b', title: 'B' }])
    })
    expect(result.current).toMatchObject({ seq: 2, items: [{ sessionId: 'b', title: 'B' }] })
  })

  it('重试轮收缩失败名单不改 seq（框不重挂载，逐条失败原文留在框里）', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids, ['b']),
    )
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    requestDeleteBatch()
    const view = renderHook(() => useDeleteBatchRequest())
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 2 条' }))
    await waitFor(() =>
      expect(view.result.current?.items.map((item) => item.sessionId)).toEqual(['b']),
    )
    expect(view.result.current?.seq).toBe(1)
    // 收缩只动请求现场的 items：seq 没变 ⇒ 框不重挂载，框内本地失败面（原文）还在。
    expect(screen.getByText('会话目录不在盘上')).toBeInTheDocument()
  })
})

describe('批量确认框', () => {
  it('写入在飞时取消/关闭都拦住（busy 关框规则）', async () => {
    let release: (value: ApplyOutcome[]) => void = () => {}
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]): Promise<ApplyOutcome[]> => {
      if (action === 'count') return countOutcomes(ids)
      return new Promise<ApplyOutcome[]>((resolve) => { release = resolve })
    })
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))
    await waitFor(() => expect(screen.getByRole('button', { name: '取消' })).toBeDisabled())
    fireEvent.click(screen.getByRole('button', { name: '取消' }))
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    release(deleteOutcomes(['a']))
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
  })

  it('同一 tick 连点两次「移入回收站」：第二趟被同步挡回 ⇒ 只发一条删除，框不提前收', async () => {
    let release!: (value: ApplyOutcome[]) => void
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]): Promise<ApplyOutcome[]> => {
      if (action === 'count') return countOutcomes(ids)
      return new Promise<ApplyOutcome[]>((resolve) => { release = resolve })
    })
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    const confirm = await screen.findByRole('button', { name: '移入回收站 1 条' })
    act(() => {
      fireEvent.click(confirm)
      fireEvent.click(confirm)
    })
    await waitFor(() => expect(applyOutcomes.mock.calls.filter(([action]) => action === 'delete')).toHaveLength(1))
    // 挡回来的那一趟没有结论：框留在原地，等第一条真落地。
    expect(screen.getByRole('dialog')).toBeInTheDocument()
    release(deleteOutcomes(['a']))
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument())
  })

  it('标题随条数：1 条是单删那句，多条是「删除这些 N 个会话？」', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids),
    )
    requestDeleteBatch([{ sessionId: 'a', title: 'A' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    expect(await screen.findByRole('heading', { name: '删除这个会话？' })).toBeInTheDocument()
  })

  it('子会话两句只在有数时说：chip 有才标、汇总句 K>0 才出；读不到整句不说且主按钮照常可点', async () => {
    const applyOutcomes = vi.fn(async (_action: string, ids: readonly string[]) =>
      countOutcomes(ids, { a: 2 }),
    )
    requestDeleteBatch([
      { sessionId: 'a', title: 'A' },
      { sessionId: 'b', title: 'B' },
    ])
    const first = render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    expect(await screen.findByText('删除这些 2 个会话？')).toBeInTheDocument()
    expect(screen.getByText('含 2 个子会话')).toBeInTheDocument()
    expect(screen.queryByText('含 0 个子会话')).not.toBeInTheDocument()
    expect(screen.getByText('含 2 个子会话，将一起移入回收站。')).toBeInTheDocument()
    // 同一个 document 里先收掉上一幕，否则两个框同屏、按名查会撞
    first.unmount()

    clearDeleteBatchRequest()
    const failing = vi.fn(async () => {
      throw Object.assign(new Error('读不到'), { code: 'sessiondelete/io' })
    })
    requestDeleteBatch([{ sessionId: 'c', title: 'C' }])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes: failing })} />)
    expect(await screen.findByText('删除这个会话？')).toBeInTheDocument()
    expect(screen.queryByText(/将一起移入回收站/)).not.toBeInTheDocument()
    expect(screen.getByRole('button', { name: '移入回收站 1 条' })).toBeEnabled()
  })

  it('目标列表限高滚动：几十条也不会把标题和底部按钮顶出弹框', async () => {
    const applyOutcomes = vi.fn(async (_action: string, ids: readonly string[]) => countOutcomes(ids))
    const items = Array.from({ length: 80 }, (_, i) => ({ sessionId: `s${i}`, title: `S${i}` }))
    requestDeleteBatch(items)
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)

    const card = document.querySelector('[data-dsh-session-delete="batch-target-card"]')
    expect(card).not.toBeNull()
    expect(card).toHaveStyle({ maxHeight: '280px', overflow: 'auto' })
    // 标题与底部动作还在（列表只在卡片内部滚）
    expect(screen.getByRole('heading', { name: '删除这些 80 个会话？' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '取消' })).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '移入回收站 80 条' })).toBeInTheDocument()
  })

  it('成功路径：一次 applyOutcomes、框收工、发批量撤销横幅、选中集清空', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids),
    )
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    requestDeleteBatch()
    render(
      <>
        <BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />
        <UndoToast deps={createFakeRemote({ applyOutcomes })} />
      </>,
    )
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 2 条' }))
    await waitFor(() => expect(screen.getByText('2 条会话已移入回收站')).toBeInTheDocument())
    expect(applyOutcomes).toHaveBeenCalledWith('delete', ['a', 'b'])
    expect(screen.queryByRole('button', { name: '移入回收站 2 条' })).not.toBeInTheDocument()
    expect(getPicks()).toEqual([])
  })

  it('部分失败：原文落它自己那行、按钮变「重试这 1 条」、重试只发失败 id', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids, ['b']),
    )
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    requestDeleteBatch()
    render(
      <>
        <BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />
        <UndoToast deps={createFakeRemote({ applyOutcomes })} />
      </>,
    )
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 2 条' }))
    expect(await screen.findByText(/会话目录不在盘上/)).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '重试这 1 条' })).toBeInTheDocument()
    expect(screen.getByText('1 条会话已移入回收站')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: '重试这 1 条' }))
    await waitFor(() => expect(applyOutcomes).toHaveBeenLastCalledWith('delete', ['b']))
    expect(applyOutcomes).toHaveBeenCalledTimes(3)
  })

  it('重试轮收缩后汇总子会话数只算还在名单里的（不把已移走的算进去）', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      action === 'count' ? countOutcomes(ids, { a: 2, b: 3 }) : deleteOutcomes(ids, ['b']),
    )
    requestDeleteBatch([
      { sessionId: 'a', title: 'A' },
      { sessionId: 'b', title: 'B' },
    ])
    render(<BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />)
    expect(await screen.findByText('含 5 个子会话，将一起移入回收站。')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: '移入回收站 2 条' }))
    expect(await screen.findByText(/会话目录不在盘上/)).toBeInTheDocument()
    expect(screen.getByText('含 3 个子会话，将一起移入回收站。')).toBeInTheDocument()
    expect(screen.queryByText('含 5 个子会话，将一起移入回收站。')).not.toBeInTheDocument()
  })

  it('整批失败：失败原文落行、不发撤销横幅，但回收站照样收到失效通告', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids, ids),
    )
    togglePick({ sessionId: 'a', title: 'A' })
    requestDeleteBatch()
    const revision = renderHook(() => useTrashRevision())
    render(
      <>
        <BatchConfirmHost deps={createFakeRemote({ applyOutcomes })} />
        <UndoToast deps={createFakeRemote({ applyOutcomes })} />
      </>,
    )
    expect(revision.result.current).toBe(0)
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))
    expect(await screen.findByText('会话目录不在盘上')).toBeInTheDocument()
    expect(screen.queryByText(/条会话已移入回收站/)).not.toBeInTheDocument()
    expect(getPicks()).toHaveLength(1)
    // 回滚失败可能留下半套：信封成功就要让清单重读，哪怕一条都没落地。
    await waitFor(() => expect(revision.result.current).toBe(1))
  })
})
