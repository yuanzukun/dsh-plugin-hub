// 浏览器半的远程面（信封判别 + 注入面那一处展开）
//
// 这一层钉住的是**契约形状**：两半之间的 unary 调用 resolve 成 `{ ok: true, value }` /
// `{ ok: false, error }`，失败是返回而不是 reject；展开（`unwrapRemoteResult`）发生一次，
// 之后组件面只认裸值与 throw。用例全部围绕这条契约，不触碰任何组件。
//
// 信封形状（`RemoteResult`）、失败形状（`RemoteFailure`）与标记位判别（`isDSHRemoteError`）的家是
// 两半共用的 `src/shared/wire.js`；这里验的是**浏览器半对它们的使用**：判别、原文兜底、注入面展开。
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import {
  PARAMS,
  ROUTES,
  OFFICIAL_SESSION_DELETE_API_PREFIX,
  isDSHRemoteError,
  type ApplyOutcome,
  type RemoteFailure,
} from '../../src/shared/wire.js'
import {
  applyOne,
  buildDeps,
  createHttpRemote,
  failureOf,
  probeChannel,
  unwrapRemoteResult,
  type RawSessionDeleteRemote,
  type SessionDeleteRemote,
} from '../../src/client/remote.js'
import type { TrashPanelDeps } from '../../src/client/trash-panel.js'
import { pick } from '../support/fixture.js'

afterEach(() => {
  // 断言失败时也把 fetch 还原；否则下一条用例会拿着上一条的 stub 跑（新增用例不再依赖 finally）。
  vi.unstubAllGlobals()
  vi.restoreAllMocks()
})

const FAILURE: RemoteFailure = { code: 'sessiondelete/live', message: '会话正在运行' }

describe('失败判别（标记位）与原文兜底', () => {
  it('官方标记位才认失败；普通 {code,message} 对象不算', () => {
    expect(isDSHRemoteError(Object.assign(new Error('x'), { code: 'sessiondelete/io', isDSHRemoteError: true }))).toBe(true)
    // 这正是上一版自造鸭子判别的地方：普通 `{code, message}`（不是官方 RemoteError 实例）不认。
    expect(isDSHRemoteError({ code: 'sessiondelete/io', message: 'x' })).toBe(false)
    expect(isDSHRemoteError({ isDSHRemoteError: true })).toBe(false)
    expect(isDSHRemoteError(new Error('x'))).toBe(false)
    expect(isDSHRemoteError(null)).toBe(false)
    expect(isDSHRemoteError('sessiondelete/io')).toBe(false)
  })

  it('失败原文与码都不丢：带标记位的失败带自己的 code，其余按原文兜底', () => {
    expect(failureOf(Object.assign(new Error('会话正在运行'), { code: 'sessiondelete/live', isDSHRemoteError: true }))).toEqual({
      code: 'sessiondelete/live',
      message: '会话正在运行',
    })
    expect(failureOf(new TypeError('x.map is not a function'))).toEqual({
      code: 'client/unknown',
      message: 'x.map is not a function',
    })
    expect(failureOf('炸了')).toEqual({ code: 'client/unknown', message: '炸了' })
  })

  // 2026-10-17 错误面对齐：详情（`sessionId` / `activity`）必须一路走到组件面，不能在这里掉。
  it('带标记位的失败把 details 第三件原样带出', () => {
    const marked = Object.assign(new Error('会话正在运行'), {
      code: 'workspace/session-active',
      isDSHRemoteError: true,
      details: { sessionId: 'session-a', activity: [{ kind: 'turn' }] },
    })
    expect(failureOf(marked)).toEqual({
      code: 'workspace/session-active',
      message: '会话正在运行',
      details: { sessionId: 'session-a', activity: [{ kind: 'turn' }] },
    })
  })
})

describe('注入面的展开', () => {
  it('ok 支原样给值', () => {
    expect(unwrapRemoteResult({ ok: true, value: 42 })).toBe(42)
  })

  it('失败支抛异常：message 是原文，code 保住且被打上官方的结构标记位', () => {
    let thrown: unknown
    try {
      unwrapRemoteResult({ ok: false, error: FAILURE })
    } catch (reason) {
      thrown = reason
    }
    expect(thrown).toBeInstanceOf(Error)
    const error = thrown as Error & { code?: string }
    expect(error.message).toBe('会话正在运行')
    expect(error.code).toBe('sessiondelete/live')
    // 展开后抛出来的东西仍是「远程失败」——下游 `failureOf` 靠标记位而不是鸭子类型认出它。
    expect(isDSHRemoteError(thrown)).toBe(true)
    expect(failureOf(thrown)).toEqual(FAILURE)
  })
})

describe('createHttpRemote · 文档挂载点', () => {
  it('九个 JSON 段的 fetch 都保留 document.baseURI 的挂载点（config 读/写同段）', async () => {
    vi.spyOn(document, 'baseURI', 'get').mockReturnValue('http://host/dsh/')
    const paths: string[] = []
    vi.stubGlobal('fetch', async (path: string) => {
      paths.push(path)
      return new Response(JSON.stringify({ ok: true, value: [] }), {
        headers: { 'content-type': 'application/json' },
      })
    })

    const remote = createHttpRemote()
    await remote.list()
    await remote.ping()
    await remote.config()
    await remote.saveConfig({ orphanPreviewLimit: 200, maxAttachmentBytes: 20971520, maxJsonRefBytes: 10485760 })
    await remote.orphans()
    await remote.attachmentOrphans()
    await remote.attachmentClean()
    await remote.detail('e1')
    await remote.apply('purge', ['e1'])
    await remote.empty()

    expect(paths).toEqual([
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.list.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.ping.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.config.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.config.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.orphans.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.attachmentOrphans.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.attachmentClean.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.detail.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.apply.path}`,
      `/dsh${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.empty.path}`,
    ])
  })
})

describe('createHttpRemote · config 读/写共用一段', () => {
  it('两趟都是 POST：读发空对象、写带整份值；方法/路径投影自段名表', async () => {
    const calls: Array<{ path: string; method: string | undefined; body: unknown }> = []
    vi.stubGlobal('fetch', async (path: string, init: RequestInit) => {
      // 本仓只以 string 体调 fetch；类型收窄证明拿到的不是被 String 折过的对象。
      const raw = init.body
      if (typeof raw !== 'string') throw new Error(`期望请求体是字符串，实得 ${typeof raw}`)
      calls.push({ path, method: init.method, body: JSON.parse(raw) })
      return new Response(JSON.stringify({ ok: true, value: {} }), {
        headers: { 'content-type': 'application/json' },
      })
    })
    const next = { orphanPreviewLimit: 200, maxAttachmentBytes: 20971520, maxJsonRefBytes: 10485760 }
    const remote = createHttpRemote()
    await expect(remote.config()).resolves.toEqual({ ok: true, value: {} })
    await expect(remote.saveConfig(next)).resolves.toEqual({ ok: true, value: {} })

    const path = `${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.config.path}`
    expect(calls).toEqual([
      { path, method: ROUTES.config.method, body: {} },
      { path, method: ROUTES.config.method, body: next },
    ])
  })
})

describe('createHttpRemote · detail 那一趟（十段里的 `POST /detail`）', () => {
  const envelope = (value: unknown) =>
    new Response(JSON.stringify({ ok: true, value }), { headers: { 'content-type': 'application/json' } })

  it('POST 到 /detail，请求体是 { entryId }；带游标时多一格 before（字段名与 Node 半同源）', async () => {
    const calls: Array<{ path: string; init?: RequestInit }> = []
    vi.stubGlobal('fetch', async (path: string, init: RequestInit) => {
      calls.push({ path, init })
      return envelope({ entryId: 'e1', blocks: [], olderCursor: null })
    })
    await expect(createHttpRemote().detail('e1')).resolves.toMatchObject({ ok: true })
    await expect(createHttpRemote().detail('e1', 12)).resolves.toMatchObject({ ok: true })
    expect(pick(calls, 0).path).toBe(`${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.detail.path}`)
    expect(pick(calls, 0).init?.method).toBe('POST')
    // 本仓只以 string 体调 fetch（remote.ts 里 body 一律 JSON.stringify）；用 typeof 证明收窄而不是
    // String()，免得对象经 String 折成 '[object Object]' 还蒙着解析下一步。
    const firstBody = pick(calls, 0).init?.body
    if (typeof firstBody !== 'string') throw new Error(`期望请求体是字符串，实得 ${typeof firstBody}`)
    expect(JSON.parse(firstBody)).toEqual({ [PARAMS.entryId]: 'e1' })
    const secondBody = pick(calls, 1).init?.body
    if (typeof secondBody !== 'string') throw new Error(`期望请求体是字符串，实得 ${typeof secondBody}`)
    expect(JSON.parse(secondBody)).toEqual({ [PARAMS.entryId]: 'e1', [PARAMS.before]: 12 })
    vi.unstubAllGlobals()
  })

  it('注入面把失败支展成 throw，码与原文都不丢（详情读失败要能原样上屏）', async () => {
    vi.stubGlobal('fetch', async () =>
      new Response(JSON.stringify({ ok: false, error: { code: 'sessiondelete/io', message: '读会话日志失败：第 2 帧解压失败' } }),
        { headers: { 'content-type': 'application/json' } }))
    const deps = buildDeps(createHttpRemote())
    await expect(deps.detail('e1')).rejects.toMatchObject({
      code: 'sessiondelete/io',
      message: '读会话日志失败：第 2 帧解压失败',
    })
    vi.unstubAllGlobals()
  })

})

describe('probeChannel · 唯一 /api 通道', () => {
  /** 失败路径会 `console.warn` 留诊断；这些用例只关心入口出不出，别把警告刷进测试输出。 */
  beforeEach(() => {
    vi.spyOn(console, 'warn').mockImplementation(() => undefined)
  })
  const envelope = (value: unknown) =>
    new Response(JSON.stringify({ ok: true, value }), { headers: { 'content-type': 'application/json' } })
  const failureEnvelope = () =>
    new Response(JSON.stringify({ ok: false, error: { code: 'host/unknown', message: 'no such route' } }), {
      headers: { 'content-type': 'application/json' },
    })

  it('ping 回 pong ⇒ 通道在，且只打官方 /api 路径', async () => {
    const paths: string[] = []
    vi.stubGlobal('fetch', async (path: string) => {
      paths.push(path)
      return envelope('pong')
    })
    await expect(probeChannel(createHttpRemote())).resolves.toBe(true)
    expect(paths).toEqual([`${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.ping.path}`])
  })

  // 判据是 `ping` 的读数，不是 `ok` 布尔：`/api` 网关对未命中的路径也可能回 `ok:true` 形状的 JSON。
  it('回 ok:true 但不是 pong ⇒ 不是本插件的路由', async () => {
    vi.stubGlobal('fetch', async () => envelope('ok'))
    await expect(probeChannel(createHttpRemote())).resolves.toBe(false)
  })

  it('401 是身份缺失 ⇒ 入口不出现', async () => {
    vi.stubGlobal('fetch', async () => new Response('unauthorized', { status: 401 }))
    await expect(probeChannel(createHttpRemote())).resolves.toBe(false)
  })

  it('失败信封（可能是 /api 网关自己的错误形状）⇒ 入口不出现', async () => {
    vi.stubGlobal('fetch', async () => failureEnvelope())
    await expect(probeChannel(createHttpRemote())).resolves.toBe(false)
  })

  it('非信封 / 404 ⇒ 入口不出现', async () => {
    vi.stubGlobal('fetch', async () => new Response('not found', { status: 404 }))
    await expect(probeChannel(createHttpRemote())).resolves.toBe(false)
  })

  it('401/403 纯文本翻成两条固定原文，不冒充「回的不是信封」', async () => {
    vi.stubGlobal('fetch', async () => new Response('unauthorized', { status: 401 }))
    await expect(createHttpRemote().list()).rejects.toThrow(/宿主的 Web 身份/)
    vi.stubGlobal('fetch', async () => new Response('forbidden', { status: 403 }))
    await expect(createHttpRemote().list()).rejects.toThrow('非受信来源')
  })
})

describe('createHttpRemote · 非信封 JSON 的诊断（issue #8 第 1 条）', () => {
  const json = (body: unknown) =>
    new Response(JSON.stringify(body), { headers: { 'content-type': 'application/json' } })

  it('中间层回 {} 或 {"error":"…"} 时：抛「回的不是信封」，不是 TypeError、不是 "undefined" 上屏', async () => {
    for (const body of [{}, { error: 'boom' }, { ok: 'yes', value: 1 }]) {
      vi.stubGlobal('fetch', async () => json(body))
      await expect(createHttpRemote().list()).rejects.toThrow(/取数通道回的不是信封/)
      vi.unstubAllGlobals()
    }
  })

  it('合法信封照旧放行：{ok:true,value} 原样落地（guard 不误伤）', async () => {
    vi.stubGlobal('fetch', async () => json({ ok: true, value: [{ id: 'a' }] }))
    await expect(createHttpRemote().list()).resolves.toEqual({ ok: true, value: [{ id: 'a' }] })
    vi.unstubAllGlobals()
  })

  it('{ok:false,error:{code,message}} 仍是落地（返回不抛）', async () => {
    vi.stubGlobal('fetch', async () => json({ ok: false, error: { code: 'sessiondelete/io', message: '读清单失败' } }))
    await expect(createHttpRemote().list()).resolves.toMatchObject({ ok: false })
    vi.unstubAllGlobals()
  })
})

describe('createHttpRemote · orphans 那一趟（十段里的 `GET /orphans`）', () => {
  const report = {
    roots: ['session-root'],
    totalSessions: 2,
    totalBytes: 2048,
    missingParents: 1,
    groups: [{ projectDir: '--p--', sessions: 2, bytes: 2048 }],
  }
  const envelope = (value: unknown) =>
    new Response(JSON.stringify({ ok: true, value }), { headers: { 'content-type': 'application/json' } })

  it('GET 到 /orphans，不带 body；成功信封原样展开成报告', async () => {
    const calls: Array<{ path: string; init?: RequestInit }> = []
    vi.stubGlobal('fetch', async (path: string, init: RequestInit) => {
      calls.push({ path, init })
      return envelope(report)
    })
    await expect(createHttpRemote().orphans()).resolves.toEqual({ ok: true, value: report })
    expect(pick(calls, 0).path).toBe(`${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.orphans.path}`)
    expect(pick(calls, 0).init?.method).toBe('GET')
    expect(pick(calls, 0).init?.body).toBeUndefined()
    vi.unstubAllGlobals()
  })

  it('注入面把失败支展成 throw：扫描失败不许折成"零条残留"', async () => {
    vi.stubGlobal('fetch', async () =>
      new Response(JSON.stringify({ ok: false, error: { code: 'sessiondelete/io', message: 'sessionQuery 不在' } }),
        { headers: { 'content-type': 'application/json' } }))
    const deps = buildDeps(createHttpRemote())
    await expect(deps.scanOrphans()).rejects.toMatchObject({
      code: 'sessiondelete/io',
      message: 'sessionQuery 不在',
    })
    vi.unstubAllGlobals()
  })
})

// 2026-10-27 孤儿附件：报告是纯读（GET），清理是聚合写（POST）。两段都回 JSON 信封，
// 失败支在注入面展开成 throw——与其余段同一条契约。
describe('createHttpRemote · 孤儿附件两段（十段里的 `GET /attachment-orphans` / `POST /attachment-clean`）', () => {
  const envelope = (value: unknown) =>
    new Response(JSON.stringify({ ok: true, value }), { headers: { 'content-type': 'application/json' } })

  it('报告 GET 到 /attachment-orphans，不带 body；成功信封原样展开', async () => {
    const calls: Array<{ path: string; init?: RequestInit }> = []
    const report = { count: 106, totalBytes: 29_150_413, items: [] }
    vi.stubGlobal('fetch', async (path: string, init: RequestInit) => {
      calls.push({ path, init })
      return envelope(report)
    })
    await expect(createHttpRemote().attachmentOrphans()).resolves.toEqual({ ok: true, value: report })
    expect(pick(calls, 0).path).toBe(`${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.attachmentOrphans.path}`)
    expect(pick(calls, 0).init?.method).toBe('GET')
    expect(pick(calls, 0).init?.body).toBeUndefined()
    vi.unstubAllGlobals()
  })

  it('清理 POST 到 /attachment-clean，空请求体；聚合回执原样展开', async () => {
    const calls: Array<{ path: string; init?: RequestInit }> = []
    const cleanup = { removed: 106, freedBytes: 29_150_413, failed: 0 }
    vi.stubGlobal('fetch', async (path: string, init: RequestInit) => {
      calls.push({ path, init })
      return envelope(cleanup)
    })
    await expect(createHttpRemote().attachmentClean()).resolves.toEqual({ ok: true, value: cleanup })
    expect(pick(calls, 0).path).toBe(`${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.attachmentClean.path}`)
    expect(pick(calls, 0).init?.method).toBe('POST')
    const cleanBody = pick(calls, 0).init?.body
    if (typeof cleanBody !== 'string') throw new Error(`期望请求体是字符串，实得 ${typeof cleanBody}`)
    expect(JSON.parse(cleanBody)).toEqual({})
    vi.unstubAllGlobals()
  })

  it('注入面展开两段：成功支给裸值，失败支抛原文与码', async () => {
    const report = { count: 3, totalBytes: 300, items: [] }
    vi.stubGlobal('fetch', async (path: string) => {
      if (path.endsWith(ROUTES.attachmentOrphans.path)) return envelope(report)
      return envelope({ removed: 2, freedBytes: 200, failed: 0 })
    })
    const deps = buildDeps(createHttpRemote())
    await expect(deps.scanAttachmentOrphans()).resolves.toEqual(report)
    await expect(deps.cleanAttachmentOrphans()).resolves.toEqual({ removed: 2, freedBytes: 200, failed: 0 })

    vi.stubGlobal('fetch', async () =>
      new Response(JSON.stringify({ ok: false, error: { code: 'sessiondelete/io', message: '引用源读不出' } }),
        { headers: { 'content-type': 'application/json' } }))
    await expect(deps.scanAttachmentOrphans()).rejects.toMatchObject({
      code: 'sessiondelete/io',
      message: '引用源读不出',
    })
    await expect(deps.cleanAttachmentOrphans()).rejects.toMatchObject({
      code: 'sessiondelete/io',
      message: '引用源读不出',
    })
    vi.unstubAllGlobals()
  })
})

// 2026-10-17 批量重构：写动词从「一条一段」收成一段 `POST /apply`（body `{action, ids}`，
// 回逐条 `ApplyOutcome`）。这里钉通道的两件事：**只发一次请求**，以及**单条的失败不在信封层找**。
describe('createHttpRemote · /apply 一段管所有动作', () => {
  const envelope = (value: unknown) =>
    new Response(JSON.stringify({ ok: true, value }), { headers: { 'content-type': 'application/json' } })

  it('POST 到 /apply，请求体是 { action, ids }（字段名与 Node 半同源）', async () => {
    const calls: Array<{ path: string; init?: RequestInit }> = []
    vi.stubGlobal('fetch', async (path: string, init: RequestInit) => {
      calls.push({ path, init })
      return envelope([{ id: 'e1', action: 'restore', ok: true, value: { id: 'e1' } }])
    })
    await expect(createHttpRemote().apply('restore', ['e1', 'e2'])).resolves.toMatchObject({ ok: true })
    expect(calls).toHaveLength(1)
    expect(pick(calls, 0).path).toBe(`${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.apply.path}`)
    expect(pick(calls, 0).init?.method).toBe('POST')
    const applyBody = pick(calls, 0).init?.body
    if (typeof applyBody !== 'string') throw new Error(`期望请求体是字符串，实得 ${typeof applyBody}`)
    expect(JSON.parse(applyBody)).toEqual({ [PARAMS.action]: 'restore', [PARAMS.ids]: ['e1', 'e2'] })
    vi.unstubAllGlobals()
  })

  it('清空是另一段 /empty：聚合回执，不带 ids', async () => {
    const calls: Array<{ path: string; init?: RequestInit }> = []
    vi.stubGlobal('fetch', async (path: string, init: RequestInit) => {
      calls.push({ path, init })
      return envelope({ removed: 3, freedBytes: 1 })
    })
    await expect(createHttpRemote().empty()).resolves.toMatchObject({ ok: true, value: { removed: 3 } })
    expect(pick(calls, 0).path).toBe(`${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.empty.path}`)
    vi.unstubAllGlobals()
  })

  it('注入面：applyOne 展成裸值；批量里单条的失败**不 throw**（它住在 outcome 里）', async () => {
    vi.stubGlobal('fetch', async () =>
      new Response(JSON.stringify({
        ok: true,
        value: [
          { id: 'a', action: 'restore', ok: true, value: { id: 'a' } },
          { id: 'b', action: 'restore', ok: false, error: { code: 'sessiondelete/project-missing', message: '原项目目录已不存在' } },
        ],
      }), { headers: { 'content-type': 'application/json' } }))
    const deps = buildDeps(createHttpRemote())
    const outcomes = await deps.applyOutcomes('restore', ['a', 'b'])
    expect(outcomes.map((o) => o.ok)).toEqual([true, false])
    // N=1 的那一支才把失败展成 throw（组件按"这条没成"处理，与批量同一张表）
    await expect(applyOne(deps, 'restore', 'b')).rejects.toMatchObject({ code: 'sessiondelete/project-missing' })
    vi.unstubAllGlobals()
  })

  it('整次调用没办成（顶层 ok:false）时便捷支与批量口都抛原文', async () => {
    vi.stubGlobal('fetch', async () =>
      new Response(JSON.stringify({ ok: false, error: { code: 'sessiondelete/io', message: '方法不允许' } }),
        { headers: { 'content-type': 'application/json' } }))
    const deps = buildDeps(createHttpRemote())
    await expect(deps.applyOutcomes('purge', ['a'])).rejects.toMatchObject({ code: 'sessiondelete/io', message: '方法不允许' })
    await expect(applyOne(deps, 'count', 'x')).rejects.toMatchObject({ code: 'sessiondelete/io' })
    vi.unstubAllGlobals()
  })
})

describe('注入面 · 一个动作只有一条路', () => {
  it('注入面与面板的 deps 里都没有单条便捷方法：写走 `runWrite`，单条非写调用走 `applyOne`', () => {
    // 这两行是**类型层**的闸：谁把 `restore` / `delete` / `countSubagents` 加回 interface，
    // 它们立刻编译不过（同一个动作在一个 module 里有两条路——写路径收进 `runWrite` 就是要拆掉这个形状）。
    const remoteHasRestore: 'restore' extends keyof SessionDeleteRemote ? true : false = false
    const panelHasRestore: 'restore' extends keyof TrashPanelDeps ? true : false = false
    const remoteHasCount: 'countSubagents' extends keyof SessionDeleteRemote ? true : false = false
    expect([remoteHasRestore, panelHasRestore, remoteHasCount]).toEqual([false, false, false])
  })

  it('`applyOne` 取的是**发出去的那个 id** 的结果，不是第一条', async () => {
    const deps = {
      applyOutcomes: async (action: 'restore', ids: readonly string[]) => ids.map((id) => ({
        id, action, ok: true as const, value: { id } as never,
      })),
    }
    const outcome = await applyOne(deps, 'restore', 'only-one')
    expect(outcome.id).toBe('only-one')
  })

  it('applyOne：请求的 id 没回 / 回了幂等空值 ⇒ 都当通道错，不冒充成功', async () => {
    const empty = { applyOutcomes: async () => [] as ApplyOutcome[] }
    await expect(applyOne(empty, 'restore', 'a')).rejects.toThrow(/批量通道没回这一条的结果/)

    const gone = {
      applyOutcomes: async (action: 'restore', ids: readonly string[]) =>
        ids.map((id) => ({ id, action, ok: true as const, value: null })),
    }
    await expect(applyOne(gone, 'restore', 'a')).rejects.toThrow(/单条动作回了幂等空值/)
  })
})

describe('取数通道探测：一次往返 + 5s 上限', () => {
  const rawOf = (ping: (signal?: AbortSignal) => Promise<unknown>): RawSessionDeleteRemote =>
    ({ ping } as unknown as RawSessionDeleteRemote)

  it('成功回 pong 才真', async () => {
    const ping = vi.fn(async (_signal?: AbortSignal) => ({ ok: true as const, value: 'pong' }))
    await expect(probeChannel(rawOf(ping))).resolves.toBe(true)
    expect(ping).toHaveBeenCalledTimes(1)
  })

  it('失败信封 / 非 pong 都按不可用，且只探一次，并在 console 留下原因', async () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    const failure = vi.fn(async (_signal?: AbortSignal) => ({ ok: false as const, error: { code: 'sessiondelete/io', message: 'x' } }))
    await expect(probeChannel(rawOf(failure))).resolves.toBe(false)
    expect(failure).toHaveBeenCalledTimes(1)
    expect(warn).toHaveBeenCalledWith(expect.stringContaining('入口不注册'), 'sessiondelete/io', 'x')

    const wrong = vi.fn(async (_signal?: AbortSignal) => ({ ok: true as const, value: 'nope' }))
    await expect(probeChannel(rawOf(wrong))).resolves.toBe(false)
    expect(wrong).toHaveBeenCalledTimes(1)
    expect(warn).toHaveBeenCalledWith(expect.stringContaining('不是 pong'), 'nope')
  })

  it('超时：AbortSignal 被 abort，回 false，不重试，并留下诊断', async () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    const ping = vi.fn((signal?: AbortSignal) => new Promise((_resolve, reject) => {
      signal?.addEventListener('abort', () => { reject(new Error('aborted')) }, { once: true })
    }))
    await expect(probeChannel(rawOf(ping), { timeoutMs: 5 })).resolves.toBe(false)
    expect(ping).toHaveBeenCalledTimes(1)
    expect(ping.mock.calls[0]?.[0]?.aborted).toBe(true)
    expect(warn).toHaveBeenCalledWith(expect.stringContaining('打不通'), expect.any(Error))
  })
})
