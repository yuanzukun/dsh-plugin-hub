// 浏览器半入口（`apply` 的装配面）——**之前零覆盖的那一块**
//
// 这一层用**假的 `ctx`**（只给槽位注册表）与**假的 `fetch`**（我们自己的前缀路由）跑真的 `apply`，
// 再把注册表里的贡献按**真宿主的形状**装起来（`Scene`：菜单槽的行渲染在一个假 `Menu` 里，
// overlay 槽的贡献全挂上）。钉住四件事：
// 1. **取数通道的探测是注册的前提**：探测通过才十次 `slots.inject`（槽位名、插件专属 id、order、
//    以及 `main` 的 key 与 `sidebar.panellist` 的 id 同字）；探测不过 ⇒ 零注册、零抛错、`apply` 正常返回；
// 2. **deps 装配**：HTTP 回的是我们的信封（`{ ok: true, value }` / `{ ok: false, error }`，与官方
//    unary 面同形），浏览器半把它解析成 `RemoteOutcome`；《remote.test.ts》钉形状，这里钉**端到端的
//    可见后果**（原文上屏 / 面板不 TypeError）；
// 3. **两个座位的形状**：回收站入口占的全局面板是一对座位——`sidebar.panellist` 出一个只吃
//    `{ size, active }` 的 glyph（行本体归宿主：按钮、名字、选中态、折叠 tooltip 都不归我们），
//    `main` 的同字 key 出面板本体。两条**必须同一拍注册**：官方 `ctx.layout.selectPanel` 逐字
//    `if (panelId !== null && !this.hasMainPanel(panelId)) throw new Error(...)`，只有行没有面板时
//    点一下就是运行期抛错；
// 4. **菜单收起的门**：`open === false` ⇒ 槽位行子树不渲染（真产物 `Menu` 逐字如此）。移入请求的宿主必须脱离
//    这棵子树，否则按下「移入回收站」的那一帧它就被连坐卸载——那条请求就再也发不出去。
import { fireEvent, render, screen, waitFor } from '@testing-library/react'
import { type ComponentType, type ReactElement, useState } from 'react'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { apply, inject } from '../../src/client/index.js'
import type { ApplyAction, ApplyOutcome } from '../../src/shared/wire.js'
import type { TrashDetailLike, TrashEntryLike } from '../../src/client/remote.js'
import { enterSelection } from '../../src/client/batch-selection-store.js'
import { DEFAULT_CONFIG } from '../../src/config.js'
import {
  ROUTES,
  OFFICIAL_SESSION_DELETE_API_PREFIX,
  type AttachmentCleanupWire,
  type AttachmentOrphanReportWire,
  type OrphanReportWire,
  type PurgeStatsWire,
  type RemoteResult,
  type SessionDeleteConfigWire,
} from '../../src/shared/wire.js'

beforeEach(() => {
  // 归档旁路观察的可选服务缺席在激活期会 `console.info` 留因（安静降级）；这组用例只看入口注册，
  // 不把降级提示刷进测试输出。
  vi.spyOn(console, 'info').mockImplementation(() => undefined)
})


const MENU_SLOT = 'sidebar.workspaces.session.menu.item'
/** 会话行首 16px 格（状态点缺席时归第三方装饰）；批量移入回收站的主勾选框住这里。 */
const LEADING_SLOT = 'sidebar.session.row.leading'
/** 会话行尾悬停排的座位（状态点/归档行的兜底勾选开关住这里，宿主自己的归档/置顶也在这里）。 */
const ROW_ACTION_SLOT = 'sidebar.workspaces.session.row.action'
const OVERLAY_SLOT = 'shell.overlay'
const PANEL_SLOT = 'sidebar.panellist'
const MAIN_SLOT = 'main'
/** 插件设置页的子槽位：宿主声明它之后才挂载；卡片的 key 用 bundle 包名。 */
const SETTINGS_SLOT = 'plugins.bundle.config'
/** 面板 id 与 `main` 的 key 是**同一个字**（官方：list id 寻址同 id 的中央面板）。 */
const PANEL_ID = '@xrn1997/dsh-session-delete.trash'

type SlotComponent = (props: Record<string, unknown>) => ReactElement
type Props = Record<string, unknown>
type RowState = { byId?: Record<string, { running?: boolean; title?: string } | undefined> }
type Select = (state: RowState) => boolean
type FakeUseSessions = (select: Select) => boolean

interface Registration {
  name: string
  /** list 座位的占用者 id；`main`（keyed）用它自己的 `key`，两者同字。 */
  id?: string
  key?: string
  order?: number
  label?: string | (() => string)
  inject?: () => Props
  component: ComponentType<Record<string, unknown>>
}

const ROW: TrashEntryLike = {
  id: 'a',
  sessionId: 'session-a',
  projectDir: '--p--',
  workspaceId: 'ws',
  wasArchived: false,
  deletedAt: 1,
  title: '/code-review',
  sizeBytes: 224 * 1024,
  releaseBytes: 224 * 1024,
}

const DETAIL: TrashDetailLike = {
  entryId: 'a',
  cwd: 'C:/develop/p',
  createdAt: 1,
  lastActivity: 2,
  logTitle: '/code-review',
  models: ['m-1'],
  turnCount: 1,
  userMessageCount: 1,
  assistantMessageCount: 1,
  toolCallCount: 3,
  injectedCount: 7,
  blocks: [
    { kind: 'user', id: '0', time: 1, text: '先看改动', truncated: false, attachments: [] },
    { kind: 'assistant', id: '1', time: 2, text: '改动分四层', truncated: false, attachments: [] },
  ],
  olderCursor: null,
}

/** 一次 `apply` 的逐条成功结果（判别联合要的是**字面量**动作，所以按动作分支造，不靠展开）。 */
function okOutcomes(action: ApplyAction, ids: readonly string[]): ApplyOutcome[] {
  return ids.map((id) => {
    if (action === 'count') return { id, action, ok: true as const, value: 0 }
    if (action === 'purge') return { id, action, ok: true as const, value: { removed: 1, freedBytes: 224 * 1024 } }
    if (action === 'orphan-clean') return { id, action, ok: true as const, value: { removed: 1, freedBytes: 224 * 1024 } }
    if (action === 'unarchive') return { id, action, ok: true as const, value: 1 }
    return { id, action, ok: true as const, value: ROW }
  })
}

/** 假 `fetch` 的**线上面**：按段回信封。它不是浏览器半的通道 interface——那一条由生产实现
 *  解析这一层；这里只模拟宿主 `/api` 真正发回来的 JSON。 */
interface EnvelopeRemote {
  list(): Promise<RemoteResult<TrashEntryLike[]>>
  ping(): Promise<RemoteResult<string>>
  config(): Promise<RemoteResult<SessionDeleteConfigWire>>
  saveConfig(next: SessionDeleteConfigWire): Promise<RemoteResult<SessionDeleteConfigWire>>
  orphans(): Promise<RemoteResult<OrphanReportWire>>
  detail(entryId: string, before?: number): Promise<RemoteResult<TrashDetailLike>>
  apply(action: ApplyAction, ids: readonly string[]): Promise<RemoteResult<ApplyOutcome[]>>
  empty(): Promise<RemoteResult<PurgeStatsWire>>
  attachmentOrphans(): Promise<RemoteResult<AttachmentOrphanReportWire>>
  attachmentClean(): Promise<RemoteResult<AttachmentCleanupWire>>
}

/** 一个**与实现同形**的线上面：九个 JSON 段各回一个信封（写动词全走 `apply`；附件字节段是二进制，不经这层）。 */
function rawRemote(overrides: Partial<EnvelopeRemote> = {}): EnvelopeRemote {
  return {
    list: async () => ({ ok: true, value: [ROW] }),
    ping: async () => ({ ok: true, value: 'pong' }),
    config: async () => ({
      ok: true,
      value: { ...DEFAULT_CONFIG },
    }),
    saveConfig: async (next) => ({ ok: true, value: next }),
    orphans: async () => ({
      ok: true,
      value: { roots: [], totalSessions: 0, totalBytes: 0, missingParents: 0, groups: [] },
    }),
    detail: async () => ({ ok: true, value: DETAIL }),
    apply: async (action, ids) => ({ ok: true, value: okOutcomes(action, ids) }),
    empty: async () => ({ ok: true, value: { removed: 1, freedBytes: 224 * 1024 } }),
    attachmentOrphans: async () => ({ ok: true, value: { count: 0, totalBytes: 0, items: [] } }),
    attachmentClean: async () => ({ ok: true, value: { removed: 0, freedBytes: 0, failed: 0 } }),
    ...overrides,
  }
}

/**
 * 取数通道的三种状态。
 * - `up`：九个 JSON 段按井号回信封（**探测过**；附件字节段不经这层）；
 * - `throwing`：`fetch` 直接 reject（路由不在、宿主没起来）——探测不过；
 * - `not-json`：回的是 SPA 的 index.html（前缀路由没注册时落到兜底处理器）——探测也不过。
 */
type Channel = 'up' | 'throwing' | 'not-json'

interface FetchCall { path: string; method: string; body: unknown }

/** 假 `fetch`：只认我们自己的前缀路由，把 HTTP 一层折成"方法 + 段名 + body"。 */
function installFetch(raw: EnvelopeRemote, channel: Channel = 'up'): { calls: FetchCall[] } {
  const calls: FetchCall[] = []
  const handler: Record<string, (body: Record<string, unknown>) => Promise<unknown>> = {
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.list.path]: async () => raw.list(),
    // 探测走这一问（不再每次页面加载都跑一遍全表对账）
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.ping.path]: async () => raw.ping(),
    // 可调项：空体读、带字段写（与 Node 半 `/config` 的判据同形）
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.config.path]: async (body) =>
      Object.keys(body).length === 0 ? raw.config() : raw.saveConfig(body as never),
    // 两条纯读要有座位：面板挂载读详情、批量浮条防抖问一次计数
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.detail.path]: async (body) =>
      raw.detail(body['entryId'] as string, body['before'] as number | undefined),
    // 写动词一段收口：`/apply` 按 body 里的动作与 ids 分派（与 Node 半那张路由表同形）
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.apply.path]: async (body) =>
      raw.apply(body['action'] as never, body['ids'] as string[]),
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.empty.path]: async () => raw.empty(),
    // 残留条那一份纯读报告（清理不在这里，仍是 `/apply` 的第五个动作）
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.orphans.path]: async () => raw.orphans(),
    // 维护卡的孤儿附件：报告纯读、清理聚合写
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.attachmentOrphans.path]: async () => raw.attachmentOrphans(),
    [OFFICIAL_SESSION_DELETE_API_PREFIX + ROUTES.attachmentClean.path]: async () => raw.attachmentClean(),
  }
  globalThis.fetch = (async (input: unknown, init?: { method?: string; body?: string }) => {
    const path = String(input)
    const method = init?.method ?? 'GET'
    const body = init?.body === undefined ? {} : (JSON.parse(init.body) as Record<string, unknown>)
    calls.push({ path, method, body })
    if (channel === 'throwing') throw new TypeError('Failed to fetch')
    if (channel === 'not-json') {
      return { status: 200, ok: true, json: async () => { throw new SyntaxError('Unexpected token <') } }
    }
    const run = handler[path]
    if (run === undefined) throw new Error(`假 fetch 不认这条路径：${path}`)
    const envelope = await run(body)
    return { status: 200, ok: true, json: async () => envelope }
  }) as never
  return { calls }
}

/** 等探测那一拍落地（`apply` 是同步返回的，注册在 fetch 的续拍上）。 */
const settle = (): Promise<void> => new Promise((resolve) => setTimeout(resolve, 0))

/**
 * 跑一次真的 `apply`（假 ctx 只有**槽位注册表**一个成员——`slots` 是唯一写进 `inject` 的服务），
 * 把 inject / register 记下来。
 */
async function bootstrap(
  raw: EnvelopeRemote = rawRemote(),
  channel: Channel = 'up',
  uiWorkspace?: unknown,
  services: { contextMenus?: unknown; sessions?: unknown; getThrows?: boolean } = {},
) {
  const fetchCalls = installFetch(raw, channel).calls
  const injected: string[] = []
  const registered: Registration[] = []
  /** `ctx.effect` 交回的清理函数（真宿主按逆序在卸载时调用）；`disposeAll` 就是卸载那一刻。 */
  const cleanups: (() => unknown)[] = []
  /** `ctx.inject` 的等待队列：服务迟到时测试手动触发。 */
  const lateInject: Array<{ deps: readonly string[]; callback: (child: unknown) => unknown }> = []
  const ctx = {
    slots: {
      inject(key: string, contribute: () => unknown): unknown {
        injected.push(key)
        const before = registered.length
        contribute()
        const added = registered.slice(before)
        // 真宿主的 `slots.inject` 返回摘除函数；legacy → 数据动作的切换要靠它。
        // 按**行对象**摘，不按注册时的下标：先摘一条会让后面那条的下标前移。
        return () => {
          for (const row of added) {
            const index = registered.indexOf(row)
            if (index >= 0) registered.splice(index, 1)
          }
        }
      },
      register(options: Omit<Registration, 'component'>, component: unknown): unknown {
        registered.push({ ...options, component: component as Registration['component'] })
        return component
      },
    },
    get: (name: string) => {
      if (services.getThrows === true) throw new Error('动态包沙箱拒绝未放行的成员')
      if (name === 'uiWorkspace') return uiWorkspace
      if (name === 'contextMenus') return services.contextMenus
      if (name === 'sessions') return services.sessions
      return undefined
    },
    inject: (deps: readonly string[], callback: (child: unknown) => unknown) => {
      lateInject.push({ deps, callback })
      return () => undefined
    },
    effect: (execute: () => unknown) => {
      cleanups.push(execute() as () => unknown)
      return undefined
    },
  }
  apply(ctx)
  await settle()
  const slot = (name: string): Registration => {
    const found = registered.find((row) => row.name === name)
    if (found === undefined) throw new Error(`槽位 ${name} 没有注册`)
    return found
  }
  return {
    injected,
    registered,
    fetchCalls,
    lateInject,
    /** 手动让一个迟到的 `contextMenus` 就绪：模拟 `ui-context-menu` 晚于本条目激活。 */
    provideContextMenus: (menus: unknown): void => {
      const pending = lateInject.shift()
      if (pending === undefined) throw new Error('没有在等 contextMenus')
      pending.callback({
        slots: ctx.slots,
        get: (name: string) => name === 'contextMenus' ? menus : name === 'sessions' ? services.sessions : undefined,
        effect: ctx.effect,
      })
    },
    /** 卸载这一刻：真宿主按登记逆序调用清理函数（`bindMainView` 与激活守卫都挂在这上面）。 */
    async disposeAll() {
      for (const cleanup of cleanups.reverse()) await cleanup()
    },
    /** 取某个槽位贡献的组件与它的注入面 props。 */
    seat: (name: string): { Component: SlotComponent; props: Props } => {
      const found = slot(name)
      return {
        Component: found.component as unknown as SlotComponent,
        props: found.inject?.() ?? {},
      }
    },
  }
}

/**
 * 把 `apply` 注册出来的贡献按**真宿主的形状**装起来：
 *
 * - 菜单槽的行渲染在一个假 `Menu` 里，**忠实复刻真产物的那条门**：真 `Menu` 的渲染是
 *   `const list = open && jsxs(MenuSurface, { … children: [items.map(renderEntry), children] })`
 *   （asar @22074291 逐字），`open === false` 时槽位行（`children`）**根本不渲染**——行连同它的
 *   子树一起卸载。**替身原来缺的正是这条落差**（假 hook 只把 `open=false` 记进局部变量，行还在），
 *   所以「先关菜单、再执行删除」在旧实现上看起来通过，真机上却可能点不到。
 * - overlay 槽的**全部**贡献都挂上（宿主就是这样渲染 `shell.overlay` 的）。
 */
function Scene({
  registered,
  rowProps = {},
  onMenuClose,
}: {
  registered: Registration[]
  rowProps?: Props
  onMenuClose?: (open: boolean) => void
}) {
  const [open, setOpen] = useState(true)
  // 真宿主的菜单槽是 list：官方菜单行 + 我们的两行**全部**渲染（不是只渲染第一条），并且按 order 排。
  const menus = registered
    .filter((row) => row.name === MENU_SLOT)
    .sort((left, right) => (left.order ?? 0) - (right.order ?? 0))
  const overlays = registered.filter((row) => row.name === OVERLAY_SLOT)
  const useMenuOpenState = (): readonly [boolean, (next: boolean) => void] =>
    [
      open,
      (next: boolean) => {
        onMenuClose?.(next)
        setOpen(next)
      },
    ] as const
  // 行首 16px 格：真宿主只投 `sessionId`，标题由 root hook 读（这里给同形的假 hook）
  const leading = registered.find((row) => row.name === LEADING_SLOT)
  const PickLeading = leading?.component as SlotComponent | undefined
  const useSessionsForRow = (select: (state: RowState) => unknown): unknown =>
    select({ byId: { 'session-a': { running: false, title: '/code-review' } } })
  // 行尾悬停排：真宿主把它渲染在会话行末尾（`rowActions` 那层自己挡住点击冒泡）
  const pick = registered.find((row) => row.name === ROW_ACTION_SLOT)
  const PickRow = pick?.component as SlotComponent | undefined
  return (
    <>
      <div data-slot="fake-row" data-row-key="session:session-a">
        <div data-slot="fake-row-leading">
          {PickLeading !== undefined ? (
            <PickLeading
              {...(leading?.inject?.() ?? {})}
              sessionId="session-a"
              useSessions={useSessionsForRow}
              {...rowProps}
            />
          ) : null}
        </div>
        <div data-slot="fake-row-strip">
          {PickRow !== undefined ? (
            <PickRow
              {...(pick?.inject?.() ?? {})}
              sessionId="session-a"
              displayTitle="/code-review"
              {...rowProps}
            />
          ) : null}
        </div>
      </div>
      <div data-slot="fake-menu">
        {open
          ? menus.map((entry) => {
            const MenuRow = entry.component as SlotComponent
            return (
              <MenuRow
                key={entry.id}
                {...(entry.inject?.() ?? {})}
                sessionId="session-a"
                displayTitle="/code-review"
                useMenuOpenState={useMenuOpenState}
                {...rowProps}
              />
            )
          })
          : null}
      </div>
      {overlays.map((entry) => {
        const Overlay = entry.component as SlotComponent
        return <Overlay key={entry.id} {...(entry.inject?.() ?? {})} />
      })}
    </>
  )
}

describe('apply 的装配面', () => {
  it('取数通道可用时：菜单槽两行、行首格与行尾排各一次、overlay 槽三次（提示 + 单删动作 + 浮条）、面板行与中央面板各一次、设置页一次；面板 id 与 main 的 key 同字', async () => {
    const { injected, registered } = await bootstrap()
    // 同一个槽位 key 多次 `slots.inject` 是官方写法本身（宿主对 `conversation.chat.node`
    // 就连写十几次 inject，每次一个贡献），overlay 上的三样东西各是各的贡献。
    expect(injected).toEqual([
      MENU_SLOT,
      MENU_SLOT,
      LEADING_SLOT,
      ROW_ACTION_SLOT,
      OVERLAY_SLOT,
      OVERLAY_SLOT,
      OVERLAY_SLOT,
      PANEL_SLOT,
      MAIN_SLOT,
      SETTINGS_SLOT,
    ])
    expect(registered.map((row) => row.id)).toEqual([
      '@xrn1997/dsh-session-delete.delete',
      '@xrn1997/dsh-session-delete.batch-select',
      '@xrn1997/dsh-session-delete.batch-pick-leading',
      '@xrn1997/dsh-session-delete.batch-pick',
      '@xrn1997/dsh-session-delete.undo-toast',
      '@xrn1997/dsh-session-delete.delete-action',
      '@xrn1997/dsh-session-delete.batch-bar',
      PANEL_ID,
      undefined,
      undefined,
    ])
    // 一对座位：`sidebar.panellist` 的 id 与 `main` 的 key 必须同字（官方 selectPanel 按 id
    // 去 main 里找占用者，找不着就抛）。
    const panelRow = registered.find((row) => row.id === PANEL_ID)
    const panelMain = registered.find((row) => row.id === undefined && row.key === PANEL_ID)
    expect(panelMain?.key).toBe(PANEL_ID)
    // 行的名字由**注册元数据**给（宿主 `resolveSlotLabel(options.label)` 解析后画在行上），
    // 不是我们组件里写的字——所以这条必须钉在注册项上。**给的是 thunk**：官方
    // `resolveSlotLabel` 逐字按「函数就调用、否则取原值」收口，其 JSDoc 即
    // "thunks follow the active locale"，而宿主又挂了 `ctx.locale.subscribe(syncPanels)`
    // ⇒ 切语言时这一行跟着走（`copy.ts` 头注）。
    const label = panelRow?.label
    expect(typeof label).toBe('function')
    expect(typeof label === 'function' ? label() : label).toBe('回收站')
    // 菜单行落在官方菜单行（pin 100 / rename 200 / fork 300 / archive 400 / session-id 450）之后：多选 850 在删除 900
    // 之前；行首那一格由状态点优先占用（无状态点才轮到我们），行尾那颗落在宿主自己的
    // archive(100) / pin(200) 之后；面板行落在官方两个面板行（plugins 0 / schedules）与第三方
    // 「小说」（20）之后。
    expect(registered[0]?.order).toBe(900)
    expect(registered[1]?.order).toBe(850)
    expect(registered[2]?.order).toBe(300)
    expect(registered[3]?.order).toBe(300)
    expect(panelRow?.order).toBe(900)
    // 设置页卡片按 **bundle 包名** 寻址（keyed 座位），不是 `id`；宿主的插件详情页声明该子槽位后才会挂载。
    const settingsRow = registered.find((row) => row.name === SETTINGS_SLOT)
    expect(settingsRow?.key).toBe('@xrn1997/dsh-session-delete')
    expect(settingsRow?.id).toBeUndefined()
  })

  it('每条槽位贡献都包在错误边界里（单条目渲染崩溃只收起那一格，不空白宿主）', async () => {
    const { registered } = await bootstrap()
    for (const row of registered) {
      expect(row.component.displayName, `${row.name} 未包错误边界`).toMatch(/^withErrorBoundary\(/)
    }
  })

  it('0.2.2+：两行菜单改注册为 contextMenus 数据动作，legacy 菜单槽不再占用', async () => {
    interface Contribution {
      id: string
      target: string
      order: number
      observe?: (target: { sessionId: string; displayTitle: string }) => readonly unknown[]
      resolve: (
        target: { sessionId: string; displayTitle: string },
      ) => readonly Record<string, unknown>[] | Promise<readonly Record<string, unknown>[]>
    }
    const contributions: Contribution[] = []
    const contextMenus = {
      register(contribution: Contribution): () => void {
        contributions.push(contribution)
        return () => undefined
      },
    }
    let running = false
    const sessions = {
      list: {
        getSnapshot: () => ({ byId: { 'session-a': { running } } }),
        subscribe: () => () => undefined,
      },
    }
    const { injected, registered } = await bootstrap(rawRemote(), 'up', undefined, {
      contextMenus,
      sessions,
    })

    // 数据动作路径不再注册 legacy 菜单行；图标座位各注册一次。
    expect(injected).not.toContain(MENU_SLOT)
    expect(injected.filter((key) => key === 'contextMenu.icon')).toHaveLength(2)
    expect(registered.filter((row) => row.name === MENU_SLOT)).toHaveLength(0)
    // 两个 icon 贡献也各自包一层边界（context-menu-actions 的注册处同样是"单条目"）。
    const iconRows = registered.filter((row) => row.name === 'contextMenu.icon')
    expect(iconRows).toHaveLength(2)
    for (const iconRow of iconRows) expect(iconRow.component.displayName).toMatch(/^withErrorBoundary\(/)

    expect(contributions).toHaveLength(1)
    const contribution = contributions[0]
    if (contribution === undefined) throw new Error('没有注册 contextMenus 贡献')
    expect(contribution.target).toBe('session')
    expect(contribution.order).toBe(700)
    expect(contribution.observe?.({ sessionId: 'session-a', displayTitle: '/code-review' })).toEqual([
      sessions.list,
    ])

    const actions = await contribution.resolve({ sessionId: 'session-a', displayTitle: '/code-review' })
    expect(actions.map((action) => action['id'])).toEqual(['batch-select', 'delete'])
    const batchIcon: unknown = actions[0]?.['icon']
    expect(actions[0]).toMatchObject({
      label: '多选',
      afterContent: true,
      separatorBefore: true,
    })
    expect(batchIcon).toHaveProperty('key')
    const batchKey = (batchIcon as { key?: unknown }).key
    expect(typeof batchKey).toBe('string')
    expect(actions[1]).toMatchObject({
      label: '移入回收站',
      disabled: false,
      danger: true,
      afterContent: true,
    })

    running = true
    const live = await contribution.resolve({ sessionId: 'session-a', displayTitle: '/code-review' })
    expect(live[1]).toMatchObject({ label: '移入回收站（运行中）', disabled: true })
  })

  it('ctx.get 抛错按服务缺席处理：legacy 菜单行照注册，拖不垮其余座位', async () => {
    // `ctx.get` 在动态包沙箱 / 换代宿主上可能抛（`copy.ts` / `main-view.ts` 早就按这条兜）。
    // 它跑在任何槽位注册之前：这里若把异常放出去，整个客户端条目会零注册（页面里插件直接消失）。
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    try {
      const { injected, registered } = await bootstrap(rawRemote(), 'up', undefined, { getThrows: true })
      expect(injected).toEqual([
        MENU_SLOT,
        MENU_SLOT,
        LEADING_SLOT,
        ROW_ACTION_SLOT,
        OVERLAY_SLOT,
        OVERLAY_SLOT,
        OVERLAY_SLOT,
        PANEL_SLOT,
        MAIN_SLOT,
        SETTINGS_SLOT,
      ])
      expect(registered.filter((row) => row.name === MENU_SLOT)).toHaveLength(2)
      expect(warn).toHaveBeenCalled()
    } finally {
      warn.mockRestore()
    }
  })

  it('contextMenus 注册失败时回退 legacy 菜单行，且不注册图标', async () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => undefined)
    try {
      const contextMenus = { register() { throw new Error('register failed') } }
      const { injected, registered } = await bootstrap(rawRemote(), 'up', undefined, { contextMenus })
      expect(injected.filter((key) => key === MENU_SLOT)).toHaveLength(2)
      expect(registered.filter((row) => row.name === MENU_SLOT)).toHaveLength(2)
      expect(injected).not.toContain('contextMenu.icon')
    } finally {
      warn.mockRestore()
    }
  })

  it('contextMenus 迟到：先 legacy 两行，服务就绪后切数据动作并摘掉 legacy 行', async () => {
    const { injected, registered, provideContextMenus } = await bootstrap()
    expect(registered.filter((row) => row.name === MENU_SLOT)).toHaveLength(2)

    const register = vi.fn(() => () => undefined)
    provideContextMenus({ register })

    expect(register).toHaveBeenCalledTimes(1)
    expect(registered.filter((row) => row.name === MENU_SLOT)).toHaveLength(0)
    expect(injected.filter((key) => key === 'contextMenu.icon')).toHaveLength(2)
  })

  it('探测走 GET /ping（不碰清单）；删除与撤销各发一次 POST /apply', async () => {
    const apply = vi.fn(async (action: ApplyAction, ids: readonly string[]) => ({ ok: true as const, value: okOutcomes(action, ids) }))
    const { registered, fetchCalls } = await bootstrap(rawRemote({ apply }))
    // 探测那一次：最便宜的在/不在
    expect(fetchCalls[0]).toEqual({ path: `${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.ping.path}`, method: 'GET', body: {} })

    render(<Scene registered={registered} />)
    fireEvent.click(screen.getByRole('menuitem', { name: '移入回收站' }))
    await waitFor(() => expect(apply).toHaveBeenCalledWith('delete', ['session-a']))
    fireEvent.click(await screen.findByRole('button', { name: '撤销' }))
    await waitFor(() => expect(apply).toHaveBeenCalledWith('restore', ['a']))

    const posted = fetchCalls.filter((c) => c.method === 'POST')
    // 一段管所有动作：两次请求都打同一条路径，**动作住在 body 里**。
    expect(posted).toEqual([
      { path: `${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.apply.path}`, method: 'POST', body: { action: 'delete', ids: ['session-a'] } },
      { path: `${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.apply.path}`, method: 'POST', body: { action: 'restore', ids: ['a'] } },
    ])
  })

  // 真机（2026-10-21）：宿主客户端的常驻 Session 把 `removed` 粘住，`api-session/added` 不清它
  // ⇒ 恢复后输入框仍是「会话不可用」。删除当前主视图时关掉它（宿主归档也是这么做的），
  // 撤销恢复成功后等摘要落地再把会话重开（新实例 removed=false）。
  it('删除当前主视图 → 关掉它；撤销恢复 → 重开它', async () => {
    let selected: { sessionId?: string } = { sessionId: 'session-a' }
    const clearMain = vi.fn(() => { selected = {} })
    const openSession = vi.fn()
    const uiWorkspace = {
      selection: { getSnapshot: () => selected },
      sessions: { list: { getSnapshot: () => ({ byId: { 'session-a': {} } }) } },
      clearMain,
      openSession,
    }
    const apply = vi.fn(async (action: ApplyAction, ids: readonly string[]) => ({ ok: true as const, value: okOutcomes(action, ids) }))
    const { registered } = await bootstrap(rawRemote({ apply }), 'up', uiWorkspace)
    render(<Scene registered={registered} />)

    fireEvent.click(screen.getByRole('menuitem', { name: '移入回收站' }))
    await waitFor(() => expect(clearMain).toHaveBeenCalledTimes(1))

    fireEvent.click(await screen.findByRole('button', { name: '撤销' }))
    await waitFor(() => expect(openSession).toHaveBeenCalledWith('session-a'))
  })

  // 批量移入回收站走另一条写入座位——同一条主视图收尾也要接上。
  it('批量移入回收站当前主视图 → 关掉它；批量撤销恢复 → 重开它', async () => {
    let selected: { sessionId?: string } = { sessionId: 'session-a' }
    const clearMain = vi.fn(() => { selected = {} })
    const openSession = vi.fn()
    const uiWorkspace = {
      selection: { getSnapshot: () => selected },
      sessions: { list: { getSnapshot: () => ({ byId: { 'session-a': {} } }) } },
      clearMain,
      openSession,
    }
    const apply = vi.fn(async (action: ApplyAction, ids: readonly string[]) => ({ ok: true as const, value: okOutcomes(action, ids) }))
    const { registered } = await bootstrap(rawRemote({ apply }), 'up', uiWorkspace)
    render(<Scene registered={registered} />)

    fireEvent.click(screen.getByRole('menuitem', { name: '多选' }))
    fireEvent.click(screen.getByRole('checkbox', { name: '勾选「/code-review」以批量移入回收站' }))
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))
    await waitFor(() => expect(clearMain).toHaveBeenCalledTimes(1))

    fireEvent.click(await screen.findByRole('button', { name: '撤销' }))
    await waitFor(() => expect(openSession).toHaveBeenCalledWith('session-a'))
  })

  // 宿主列表批量移入回收站的端到端形状：「⋯ → 多选」进入模式 → 行首勾选 → 浮条即执行。
  it('⋯ 多选 → 行首勾选 → 浮条即删 → 批量撤销横幅 → 撤销发一次批量 restore', async () => {
    const apply = vi.fn(async (action: ApplyAction, ids: readonly string[]) => ({ ok: true as const, value: okOutcomes(action, ids) }))
    const { registered, fetchCalls } = await bootstrap(rawRemote({ apply }))
    render(<Scene registered={registered} />)
    fireEvent.click(screen.getByRole('menuitem', { name: '多选' }))
    expect(screen.getByText('点击会话行选择')).toBeInTheDocument()
    fireEvent.click(screen.getByRole('checkbox', { name: '勾选「/code-review」以批量移入回收站' }))
    // 浮条点击即移入回收站。
    fireEvent.click(await screen.findByRole('button', { name: '移入回收站 1 条' }))
    await waitFor(() => expect(apply).toHaveBeenCalledWith('delete', ['session-a']))
    expect(screen.getByText('1 条会话已移入回收站')).toBeInTheDocument()
    const posted = fetchCalls
      .filter((c) => c.method === 'POST')
      .map((c) => (c.body as { action: string }).action)
    expect(posted).toContain('delete')
    fireEvent.click(screen.getByRole('button', { name: '撤销' }))
    await waitFor(() => expect(apply).toHaveBeenLastCalledWith('restore', ['a']))
  })

  // 真机反馈：删完在侧栏菜单里，中央的回收站面板**不切走再回来就不更新**（面板是挂载时取一次数）。
  // 这条端到端钉住"删除成功后清单立刻把它读出来"——两侧都是真的：真 apply 注册出来的组件 +
  // 真的场景实例与失效通告台。
  it('删除成功后回收站面板立刻刷新出那一条（不用切走再回来）', async () => {
    let rows: TrashEntryLike[] = []
    const list = vi.fn(async () => ({ ok: true, value: rows }) as const)
    const { registered } = await bootstrap(
      rawRemote({
        list,
        apply: async (action) => { if (action === 'delete') rows = [ROW]; return { ok: true as const, value: okOutcomes('delete', ['session-a']) } },
      }),
    )
    const panel = registered.find((row) => row.name === MAIN_SLOT)
    const Panel = panel?.component as SlotComponent
    render(
      <>
        <Scene registered={registered} />
        <Panel {...(panel?.inject?.() ?? {})} />
      </>,
    )
    expect(await screen.findByText('回收站是空的')).toBeInTheDocument()
    // 一次：面板挂载那一次（探测走 `/ping`，不再读清单——2026-10-17）
    expect(list).toHaveBeenCalledTimes(1)

    fireEvent.click(screen.getByRole('menuitem', { name: '移入回收站' }))

    // 第二次 = 删除成功后的那次重读（本轮修的就是它）
    await waitFor(() => expect(list).toHaveBeenCalledTimes(2))
    expect(await screen.findByText('/code-review')).toBeInTheDocument()
    expect(screen.queryByText('回收站是空的')).not.toBeInTheDocument()
  })
})

// **探测在飞时插件可能已经被卸载**（宿主 HMR、条目销毁）。探测是一次往返（有 5s 上限，
// 但这道守卫不拿它当卸载信号），这段窗口仍可能跨过卸载；续拍再注册就是把贡献写进已销毁的
// 注册表。守卫钉在探测之前登记，探测回来后先看它——不是拿探测失败冒充卸载。
describe('探测期间插件被卸载（disposed 守卫）', () => {
  it('探测期间插件被卸载：后续不再注册任何槽位', async () => {
    let resolvePing!: (value: unknown) => void
    const pendingPing = new Promise((resolve) => {
      resolvePing = resolve
    })
    const env = await bootstrap(rawRemote({ ping: () => pendingPing as never }))
    // 探测还挂着：一条贡献都没有。
    expect(env.registered).toEqual([])
    await env.disposeAll()
    resolvePing({ ok: true, value: 'pong' })
    await settle()
    expect(env.registered).toEqual([])
    expect(env.injected).toEqual([])
  })
})

// **探测不过 ⇒ 一个槽位贡献都不注册**（通道换了几版，这条形状不变）。
// 为什么必须如此：前端启动自检对「有客户端模块但没激活成功」走的是致命路径
// （`web boot: N entry did not activate` ⇒ 桌面壳 `reportFatal`，整个进程结束）。
// 前缀路由缺席时（Node 半没接线、宿主没起来）本插件就是"不存在"，不是一个能让外壳死掉的理由。
describe('取数通道探测不过（路由缺席态）', () => {
  /** 探测失败会 `console.warn` 留诊断；这一组只验入口不出现，别把警告刷进测试输出。 */
  beforeEach(() => {
    vi.spyOn(console, 'warn').mockImplementation(() => undefined)
  })
  afterEach(() => {
    vi.restoreAllMocks()
  })

  it('inject 只声明一定存在的服务（slots）：通道不是 inject 的成员', () => {
    expect(inject).toEqual(['slots'])
  })

  it('fetch 打不通（reject）：apply 正常返回、零抛错、一个槽位贡献都不注册', async () => {
    const { injected, registered } = await bootstrap(rawRemote(), 'throwing')
    expect(injected).toEqual([])
    expect(registered).toEqual([])
  })

  it('回的压根不是信封（前缀路由没注册时落到 SPA 兜底）：同样零注册、零抛错', async () => {
    const { injected, registered } = await bootstrap(rawRemote(), 'not-json')
    expect(injected).toEqual([])
    expect(registered).toEqual([])
  })
})

describe('deps 装配：信封的失败支落到界面上的后果', () => {
  it('delete 回 { ok: false, error } 时原文上屏——不走「已移入回收站」那条成功路径', async () => {
    const { registered } = await bootstrap(
      rawRemote({
        apply: async () => ({ ok: false, error: { code: 'sessiondelete/live', message: '会话正在运行' } }) as const,
      }),
    )
    render(<Scene registered={registered} />)

    fireEvent.click(screen.getByRole('menuitem', { name: '移入回收站' }))

    expect(await screen.findByText(/会话正在运行/)).toBeInTheDocument()
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(screen.queryByText(/已移入回收站/)).not.toBeInTheDocument()
  })

  it('list 回 { ok: false } 时原文摆上面板——不是空态、也不是 TypeError', async () => {
    const { seat } = await bootstrap(
      rawRemote({
        list: async () => ({ ok: false, error: { code: 'sessiondelete/io', message: '回收站清单损坏' } }),
      }),
    )
    const { Component, props } = seat(MAIN_SLOT)
    render(<Component {...props} />)

    expect(await screen.findByText(/回收站清单损坏/)).toBeInTheDocument()
    expect(screen.queryByText('回收站是空的')).not.toBeInTheDocument()
    expect(screen.queryByText('undefined')).not.toBeInTheDocument()
  })

  it('单条支展成裸值时撤销拿到真的条目 id（不是信封本体）', async () => {
    const apply = vi.fn(async (action: ApplyAction, ids: readonly string[]) => ({
      ok: true as const,
      value: okOutcomes(action, ids),
    }))
    const { registered } = await bootstrap(rawRemote({ apply }))
    render(<Scene registered={registered} />)
    fireEvent.click(screen.getByRole('menuitem', { name: '移入回收站' }))
    expect(await screen.findByText(/\/code-review 已移入回收站/)).toBeInTheDocument()

    // 展开前 `outcome.value` 是 `{ ok, value }`，拿 `.id` 会得到 undefined——撤销会去打 restore(undefined)。
    fireEvent.click(screen.getByRole('button', { name: '撤销' }))
    await waitFor(() => expect(apply).toHaveBeenCalledWith('restore', ['a']))
  })
})

describe('live selector（MenuRow 的 props 桥）', () => {
  const evaluate = (state: RowState): FakeUseSessions => (select) => select(state)

  it('取的是 state.byId[id].running === true，形状不对一律不算在跑', async () => {
    const selectors: Select[] = []
    const useSessions: FakeUseSessions = (select) => {
      selectors.push(select)
      return false
    }
    const { seat } = await bootstrap()
    const { Component, props } = seat(MENU_SLOT)
    render(<Component {...props} sessionId="session-a" displayTitle="t" useSessions={useSessions} />)

    expect(selectors.length).toBeGreaterThan(0)
    const select = selectors[0] as Select
    expect(select({ byId: { 'session-a': { running: true } } })).toBe(true)
    expect(select({ byId: { 'session-a': { running: false } } })).toBe(false)
    // 别的会话在跑不算这一行在跑；`byId` 缺失 / 整个 state 缺失都不算。
    expect(select({ byId: { 'session-b': { running: true } } })).toBe(false)
    expect(select({ byId: {} })).toBe(false)
    expect(select({})).toBe(false)
  })

  it('running 的会话那一行置灰，不 running 的不置灰', async () => {
    const { seat } = await bootstrap()
    const { Component, props } = seat(MENU_SLOT)
    const row = { ...props, sessionId: 'session-a', displayTitle: 't' }

    const { unmount } = render(
      <Component {...row} useSessions={evaluate({ byId: { 'session-a': { running: true } } })} />,
    )
    expect(screen.getByRole('menuitem', { name: '移入回收站' })).toBeDisabled()
    unmount()

    render(<Component {...row} useSessions={evaluate({ byId: { 'session-a': { running: false } } })} />)
    expect(screen.getByRole('menuitem', { name: '移入回收站' })).not.toBeDisabled()
  })

  it('槽位 hook 缺失时兜底成「永不 live」，不炸', async () => {
    const { seat } = await bootstrap()
    const { Component, props } = seat(MENU_SLOT)
    render(<Component {...props} sessionId="session-a" displayTitle="t" />)
    expect(screen.getByRole('menuitem', { name: '移入回收站' })).not.toBeDisabled()
  })
})

describe('行首勾选的 props 桥（槽位只投 sessionId）', () => {
  it('标题从 root hook 的 byId[id].title 读，拼出 aria 名字', async () => {
    enterSelection()
    const { seat } = await bootstrap()
    const { Component, props } = seat(LEADING_SLOT)
    const useSessions = (select: (state: RowState) => unknown): unknown =>
      select({ byId: { 'session-a': { title: '/code-review' } } })
    render(<Component {...props} sessionId="session-a" useSessions={useSessions} />)
    expect(screen.getByRole('checkbox', { name: '勾选「/code-review」以批量移入回收站' })).toBeInTheDocument()
  })

  it('root hook 缺失时也不炸：多选态里勾选框照样出来，标题按空串处理', async () => {
    enterSelection()
    const { seat } = await bootstrap()
    const { Component, props } = seat(LEADING_SLOT)
    render(<Component {...props} sessionId="session-a" />)
    expect(screen.getByRole('checkbox')).toBeInTheDocument()
  })
})

describe('菜单收起 = 行子树卸载（真 Menu 的那条门）', () => {
  it('按下这一行：菜单 owner 收到「收起」（不是自己偷偷留着菜单）', async () => {
    const { registered } = await bootstrap()
    const closes: boolean[] = []
    render(<Scene registered={registered} onMenuClose={(next) => closes.push(next)} />)

    fireEvent.click(screen.getByRole('menuitem', { name: '移入回收站' }))

    expect(closes).toEqual([false])
  })

  it('按下这一行后菜单关掉、行没了——移入回收站仍执行，不弹确认框', async () => {
    const apply = vi.fn(async (action: ApplyAction, ids: readonly string[]) => ({
      ok: true as const,
      value: okOutcomes(action, ids),
    }))
    const { registered } = await bootstrap(rawRemote({ apply }))
    render(<Scene registered={registered} />)

    fireEvent.click(screen.getByRole('menuitem', { name: '移入回收站' }))

    // 门确实关了：行随菜单一起卸载（真机上是同一个门）。
    expect(screen.queryByRole('menuitem', { name: '移入回收站' })).not.toBeInTheDocument()
    // 动作宿主不住在行里，所以这次卸载带不走它。
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    await waitFor(() => expect(apply).toHaveBeenCalledWith('delete', ['session-a']))
  })
})

describe('全局面板行（`sidebar.panellist` 的占用者）', () => {
  it('只出 glyph：按 owner 给的 size 画回收站图标；按钮、名字、选中态、折叠 tooltip 全归宿主', async () => {
    const { seat } = await bootstrap()
    const { Component, props } = seat(PANEL_SLOT)
    const { container } = render(<Component {...props} size={18} active />)

    const glyph = container.querySelector('svg')
    expect(glyph).not.toBeNull()
    expect(glyph?.getAttribute('width')).toBe('18')
    expect(glyph?.getAttribute('height')).toBe('18')
    // 行本体（宿主的 `<button class=panelRow>` + `.panelTitle` + Tooltip + aria-current）不归我们，
    // 所以这条贡献里一个按钮都不该有——有了就是又画了一行，与「插件/任务/小说」三行必然错位。
    expect(container.querySelector('button')).toBeNull()
    expect(screen.queryByText('回收站')).not.toBeInTheDocument()
  })

  it('owner props 缺席也不炸（size 缺省 16；active 不参与绘制）', async () => {
    const { seat } = await bootstrap()
    const { Component, props } = seat(PANEL_SLOT)
    const { container } = render(<Component {...props} />)
    const glyph = container.querySelector('svg')
    expect(glyph?.getAttribute('width')).toBe('16')
  })
})

describe('中央面板（`main` 的占用者）', () => {
  it('渲染回收站清单本体：标题在、行读得到', async () => {
    const { seat } = await bootstrap()
    const { Component, props } = seat(MAIN_SLOT)
    render(<Component {...props} />)

    expect(await screen.findByText('/code-review')).toBeInTheDocument()
    expect(screen.getByText('回收站')).toBeInTheDocument()
  })
})

describe('插件设置页（`plugins.bundle.config` 的占用者）', () => {
  it('注入面给 deps/t；挂载只渲染两张卡，不自动发检查请求（可调项读一次当前值）', async () => {
    const { seat, fetchCalls } = await bootstrap()
    const { Component, props } = seat(SETTINGS_SLOT)
    render(<Component {...props} />)

    expect(screen.getByText('维护')).toBeInTheDocument()
    expect(screen.getByText('可调项')).toBeInTheDocument()
    expect(screen.getAllByText('尚未检查')).toHaveLength(3)
    // 探测那一问是注册的前提；可调项卡挂载时读一次当前值（不是扫描）；
    // 维护三段仍是手动触发，之后没有别的请求。
    expect(fetchCalls.map((call) => call.path)).toEqual([
      `${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.ping.path}`,
      `${OFFICIAL_SESSION_DELETE_API_PREFIX}${ROUTES.config.path}`,
    ])
  })

  // 宿主真实传的是 `{ view: 'page' }`；summary 是插件列表行的摘要位，维护卡不能顶掉它。
  // 组件单测直传 view 只能证明组件分支，这里证明**槽位装配**把宿主 props 原样带进组件。
  it('宿主按 view 派发：page 渲染卡片，summary 返回空', async () => {
    const { seat } = await bootstrap()
    const { Component, props } = seat(SETTINGS_SLOT)

    const page = render(<Component {...props} view="page" />)
    expect(screen.getByText('维护')).toBeInTheDocument()
    page.unmount()

    const summary = render(<Component {...props} view="summary" />)
    expect(summary.container.firstChild).toBeNull()
  })
})
