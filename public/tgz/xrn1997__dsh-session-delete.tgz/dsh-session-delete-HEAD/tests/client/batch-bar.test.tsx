// 批量移入回收站浮条（2026-10-17）：多选模式、计数、已选清单与行点击选择。
import { act, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { BatchPickButton } from '../../src/client/batch-select.js'
import { BatchBar } from '../../src/client/batch-bar.js'
import type { RemoteOutcome } from '../../src/client/remote.js'
import type { ApplyOutcome } from '../../src/shared/wire.js'
import { UndoToast } from '../../src/client/undo-toast.js'
import { createFakeRemote, remoteFail, remoteOk } from './support/fake-remote.js'
import {
  enterSelection,
  getPicks,
  isSelecting,
  togglePick,
} from '../../src/client/batch-selection-store.js'
import { countOutcomes, deleteOutcomes } from './support/outcomes.js'
import { pick } from '../support/fixture.js'


const fakeRows: HTMLElement[] = []

afterEach(() => {
  for (const row of fakeRows.splice(0)) row.remove()
})

function countOnly(): { applyOutcomes: ReturnType<typeof vi.fn> } {
  const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
    remoteOk(action === 'count' ? countOutcomes(ids) : []),
  )
  return { applyOutcomes }
}

/** 真宿主会话行替身：`data-row-key` 是守卫认行的唯一凭据，行自己的 onClick 模拟"切会话"。 */
function fakeRow(sessionId: string, titleText = 'A'): {
  row: HTMLDivElement
  title: HTMLSpanElement
  opened: () => number
} {
  const row = document.createElement('div')
  row.setAttribute('data-row-key', `session:${sessionId}`)
  const title = document.createElement('span')
  title.textContent = titleText
  row.appendChild(title)
  document.body.appendChild(row)
  fakeRows.push(row)
  let count = 0
  row.addEventListener('click', () => { count += 1 })
  return { row, title, opened: () => count }
}

describe('浮条', () => {
  it('不在多选态整个不渲染', () => {
    render(<BatchBar deps={createFakeRemote({ applyOutcomes: vi.fn() })} />)
    expect(screen.queryByText(/已选/)).not.toBeInTheDocument()
  })

  it('多选态 0 条也渲染：只剩提示、全选、禁用运行与退出', () => {
    enterSelection()
    render(<BatchBar deps={createFakeRemote({ applyOutcomes: vi.fn() })} />)
    expect(screen.queryByText(/已选 /)).not.toBeInTheDocument()
    expect(screen.getByText('点击会话行选择')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '移入回收站 0 条' })).toBeDisabled()
    expect(screen.getByRole('button', { name: '全选' })).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: '取消全选' })).not.toBeInTheDocument()
    expect(screen.queryByRole('button', { name: '查看已选' })).not.toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: '退出多选' }))
    expect(isSelecting()).toBe(false)
    expect(screen.queryByText('点击会话行选择')).not.toBeInTheDocument()
  })

  it('「全选」把可见行追加进名单：登记 effect 与全选的组合，切换口随即翻成「取消全选」', () => {
    enterSelection()
    fakeRow('s1')
    fakeRow('s2')
    // 不手动 registerHostRowInfo：标题与"可不可选"只能来自槽位组件的登记 effect。
    render(
      <>
        <BatchBar deps={createFakeRemote({ applyOutcomes: vi.fn() })} />
        <BatchPickButton sessionId="s1" title="A" />
        <BatchPickButton sessionId="s2" title="B" />
      </>,
    )

    fireEvent.click(screen.getByRole('button', { name: '全选' }))
    expect(getPicks()).toEqual([
      { sessionId: 's1', title: 'A' },
      { sessionId: 's2', title: 'B' },
    ])
    expect(screen.getByRole('button', { name: '取消全选' })).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: '全选' })).not.toBeInTheDocument()

    // 同一个切换口反向：点「取消全选」只清名单、仍留在多选态
    fireEvent.click(screen.getByRole('button', { name: '取消全选' }))
    expect(getPicks()).toEqual([])
    expect(screen.getByRole('button', { name: '全选' })).toBeInTheDocument()
  })

  it('主行不再放汇总；条数与子会话数在「查看已选」列表头', async () => {
    const applyOutcomes = vi.fn(async (_action: string, ids: readonly string[]) =>
      remoteOk(countOutcomes(ids, { a: 2 })),
    )
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)
    expect(screen.getByRole('button', { name: '移入回收站 2 条' })).toBeInTheDocument()
    expect(screen.queryByText('已选 2 条')).not.toBeInTheDocument()
    expect(screen.queryByText(/跟着整组走/)).not.toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: '查看已选' }))
    expect(screen.getByText('已选 2 条')).toBeInTheDocument()
    expect(await screen.findByText('含 2 个子会话，跟着整组走')).toBeInTheDocument()
  })

  it('计数读不到就整句不说（不拿 0 冒充没有）', async () => {
    const applyOutcomes = vi.fn(async () => remoteFail({ code: 'sessiondelete/io', message: '读不到' }))
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(screen.getByRole('button', { name: '查看已选' }))
    expect(screen.getByText('已选 1 条')).toBeInTheDocument()
    await new Promise((resolve) => setTimeout(resolve, 400))
    expect(screen.queryByText(/子会话/)).not.toBeInTheDocument()
  })

  it('新增勾选后到新读数回来之前：不拿旧 counts 给新名单求和（整句先不说）', async () => {
    const deferred: Array<(value: RemoteOutcome<ApplyOutcome[]>) => void> = []
    const applyOutcomes = vi.fn(
      () => new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => deferred.push(resolve)),
    )
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)
    // 第一轮读数：名单 [a]，a 带 2 个子会话。
    await waitFor(() => expect(applyOutcomes).toHaveBeenCalledTimes(1))
    pick(deferred, 0)(remoteOk(countOutcomes(['a'], { a: 2 })))
    fireEvent.click(await screen.findByRole('button', { name: '查看已选' }))
    expect(await screen.findByText('含 2 个子会话，跟着整组走')).toBeInTheDocument()

    // 新增 b：旧读数只覆盖 [a]，不许拿来给 [a, b] 求和（那会把 b 按 0 算，报一个偏小的 2）。
    act(() => { togglePick({ sessionId: 'b', title: 'B' }) })
    expect(screen.queryByText(/含 \d+ 个子会话，跟着整组走/)).not.toBeInTheDocument()

    // 新读数（a: 2、b: 1）落地才报 3。
    await waitFor(() => expect(applyOutcomes).toHaveBeenCalledTimes(2))
    pick(deferred, 1)(remoteOk(countOutcomes(['a', 'b'], { a: 2, b: 1 })))
    expect(await screen.findByText('含 3 个子会话，跟着整组走')).toBeInTheDocument()
  })

  it('旧响应不落地：后发的勾选才是准的', async () => {
    const deferred: Array<(value: RemoteOutcome<ApplyOutcome[]>) => void> = []
    const applyOutcomes = vi.fn(
      () => new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => deferred.push(resolve)),
    )
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    const view = render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)
    await waitFor(() => expect(applyOutcomes).toHaveBeenCalledTimes(1))
    togglePick({ sessionId: 'b', title: 'B' })
    await waitFor(() => expect(applyOutcomes).toHaveBeenCalledTimes(2))
    // 第二次的响应先回（a、b 都无子会话）……上面那条次数断言已经把它推进来了
    pick(deferred, 1)(remoteOk(countOutcomes(['a', 'b'])))
    await screen.findByRole('button', { name: '移入回收站 2 条' })
    fireEvent.click(screen.getByRole('button', { name: '查看已选' }))
    await screen.findByText('已选 2 条')
    // ……第一次的后回（a 带 2 个）——旧响应，不许把「含 2 个」盖回来
    pick(deferred, 0)(remoteOk(countOutcomes(['a'], { a: 2 })))
    await new Promise((resolve) => setTimeout(resolve, 50))
    expect(screen.queryByText(/子会话/)).not.toBeInTheDocument()
    view.unmount()
  })

  it('「查看已选」默认收起；展开后按勾选序列出标题，可逐条移除', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids, { a: 2 }) : []),
    )
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)

    expect(screen.queryByText('A')).not.toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: '查看已选' }))
    expect(screen.getByText('A')).toBeInTheDocument()
    expect(screen.getByText('B')).toBeInTheDocument()
    // 有子会话数就标在它自己那行（与浮条的合计句各说各的）
    expect(await screen.findByText('含 2 个子会话')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: '取消勾选「A」' }))
    expect(getPicks().map((p) => p.sessionId)).toEqual(['b'])
    expect(screen.queryByText('A')).not.toBeInTheDocument()
    expect(screen.getByText('已选 1 条')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: '收起已选' }))
    expect(screen.queryByText('B')).not.toBeInTheDocument()
  })

  it('清单里移除最后一条：留在多选态，浮条显示 0 条', () => {
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    render(<BatchBar deps={createFakeRemote({ applyOutcomes: vi.fn() })} />)
    fireEvent.click(screen.getByRole('button', { name: '查看已选' }))
    fireEvent.click(screen.getByRole('button', { name: '取消勾选「A」' }))
    expect(getPicks()).toEqual([])
    expect(screen.getByText('点击会话行选择')).toBeInTheDocument()
    expect(screen.getByRole('button', { name: '全选' })).toBeInTheDocument()
    expect(screen.queryByText(/已选 /)).not.toBeInTheDocument()
  })

  it('未登记的行不吞点击：其它列表 / 本插件没接管的行照常走宿主自己的行为', () => {
    enterSelection()
    const { applyOutcomes } = countOnly()
    render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)
    // 行在 DOM 里、键也长得对，但没有槽位组件登记过它 ⇒ 不属于本插件的可见可选集合。
    const { title, opened } = fakeRow('not-registered')

    fireEvent.click(title)
    expect(opened()).toBe(1)
    expect(getPicks()).toEqual([])
  })

  it('模式内点整行切换选中，并挡住行自己的 onClick（会话切换）', () => {
    enterSelection()
    const { applyOutcomes } = countOnly()
    render(
      <>
        <BatchBar deps={createFakeRemote({ applyOutcomes })} />
        <BatchPickButton sessionId="s1" title="A" />
      </>,
    )
    const { title, opened } = fakeRow('s1')

    fireEvent.click(title)
    expect(getPicks().map((p) => p.sessionId)).toEqual(['s1'])
    expect(opened()).toBe(0)

    fireEvent.click(title)
    expect(getPicks()).toEqual([])
    expect(opened()).toBe(0)
  })

  it('同一拍连点只发一次批量移入回收站，按钮在飞时置灰并展示忙碌态、锁定选择修改', async () => {
    let release: (value: RemoteOutcome<ApplyOutcome[]>) => void = () => {}
    const applyOutcomes = vi.fn((action: string, ids: readonly string[]) =>
      action === 'count'
        ? Promise.resolve(remoteOk(countOutcomes(ids)))
        : new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => { release = resolve }))
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)
    fireEvent.click(screen.getByRole('button', { name: '查看已选' }))
    const button = screen.getByRole('button', { name: '移入回收站 1 条' })

    act(() => {
      fireEvent.click(button)
      fireEvent.click(button)
    })

    await waitFor(() => expect(applyOutcomes).toHaveBeenCalledWith('delete', ['a']))
    expect(applyOutcomes.mock.calls.filter(([action]) => action === 'delete')).toHaveLength(1)
    expect(button).toBeDisabled()
    expect(button).toHaveTextContent('正在移入回收站')
    expect(screen.getByRole('button', { name: '取消全选' })).toBeDisabled()
    expect(screen.getByRole('button', { name: '取消勾选「A」' })).toBeDisabled()
    release(remoteOk(deleteOutcomes(['a'])))
    await waitFor(() => expect(button).not.toBeDisabled())
    expect(screen.getByRole('button', { name: '移入回收站 0 条' })).toBeDisabled()
  })

  it('部分失败时勾选收缩到失败项，原文立即可见于同一撤销横幅，可再点重试', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids, ['b'], '乙条失败')))
    const deps = createFakeRemote({ applyOutcomes })
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    togglePick({ sessionId: 'b', title: 'B' })
    render(
      <>
        <BatchBar deps={deps} />
        <UndoToast deps={deps} />
      </>,
    )

    fireEvent.click(screen.getByRole('button', { name: '移入回收站 2 条' }))

    const alert = await screen.findByRole('alert')
    expect(alert).toHaveTextContent('1 条会话已移入回收站')
    expect(alert).toHaveTextContent('1 条未能移入回收站：乙条失败')
    await waitFor(() => expect(getPicks().map((item) => item.sessionId)).toEqual(['b']))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    fireEvent.click(screen.getByRole('button', { name: '移入回收站 1 条' }))
    await waitFor(() => expect(applyOutcomes).toHaveBeenLastCalledWith('delete', ['b']))
  })

  it('批量移入在飞期间新勾选的会话不被成功结算误删', async () => {
    let release!: (value: RemoteOutcome<ApplyOutcome[]>) => void
    const applyOutcomes = vi.fn((action: string, ids: readonly string[]) =>
      action === 'count'
        ? Promise.resolve(remoteOk(countOutcomes(ids)))
        : new Promise<RemoteOutcome<ApplyOutcome[]>>((resolve) => { release = resolve }))
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)

    fireEvent.click(screen.getByRole('button', { name: '移入回收站 1 条' }))
    await waitFor(() => expect(applyOutcomes).toHaveBeenCalledWith('delete', ['a']))

    act(() => { togglePick({ sessionId: 'c', title: 'C' }) })
    await act(async () => { release(remoteOk(deleteOutcomes(['a']))) })
    expect(getPicks()).toEqual([{ sessionId: 'c', title: 'C' }])
  })

  it('点「移入回收站 N 条」即执行，不弹确认框；退出多选仍独立可用', async () => {
    const applyOutcomes = vi.fn(async (action: string, ids: readonly string[]) =>
      remoteOk(action === 'count' ? countOutcomes(ids) : deleteOutcomes(ids)),
    )
    enterSelection()
    togglePick({ sessionId: 'a', title: 'A' })
    render(<BatchBar deps={createFakeRemote({ applyOutcomes })} />)

    fireEvent.click(screen.getByRole('button', { name: '移入回收站 1 条' }))

    await waitFor(() => expect(applyOutcomes).toHaveBeenCalledWith('delete', ['a']))
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument()
    expect(getPicks()).toEqual([])
    expect(screen.getByText('点击会话行选择')).toBeInTheDocument()

    fireEvent.click(screen.getByRole('button', { name: '退出多选' }))
    expect(isSelecting()).toBe(false)
    expect(screen.queryByText('点击会话行选择')).not.toBeInTheDocument()
  })
})
