/**
 * 回收站详情块：`session-detail.tsx` 的回收站投影。取数与账本住 `use-trash-detail-reader.ts`。
 */
import type { Translate } from './copy.js'
import type { TrashEntryWire } from '../shared/wire.js'
import type { TrashDetailLike } from './remote.js'
import { fileSizeText } from './ui/format.js'
import { timeText } from './session-detail.js'
import {
  SessionDetail,
  type DetailInfoRow,
  type DetailNav,
} from './session-detail.js'
import type { DetailFrame } from './use-detail-frame.js'
import type { DetailState } from './use-detail-reader.js'
import { rowName, useSubagentSection } from './subagent-section.js'
import { detailNameOf } from './trash-view.js'

/** 详情主体只承诺清册那一行：孩子视图看的那条不在客户端清单里，没有只读数可配对（判据住 `TrashDetailLike`）；
 *  形状与通用详情读路同为 `DetailState`。 */
export type TrashDetailState = DetailState<TrashEntryWire, TrashDetailLike>

export interface TrashDetailProps {
  /** 详情帧（`use-detail-frame.ts`）：回收站档的读路来源 + 分页读面 + 提问轨，面板拼一次、这里原样转交。 */
  frame: DetailFrame<TrashEntryWire, TrashDetailLike>
  busy: boolean
  /** 宽档不画「返回清单」——同屏就有清单；孩子视图另有一颗返回，见 `detailNav.parentContext`。 */
  wide: boolean
  onRetry: () => void
  onBack: () => void
  /** 孩子视图的开与回（控制器派生，判据见 `DetailNav`）：缺席 = 不画入口/返回，组件只画状态，不自己造动作。 */
  detailNav: DetailNav
  t: Translate
}


/** 标题排的显示名：行 label → 详情 descriptor label → 清册标题 → 日志 `session/title`（ADR-0058）。 */
function headerName(entry: TrashEntryWire, detail: TrashDetailLike | undefined, t: Translate): string {
  return detailNameOf(entry, detail, t('common.untitled'))
}


/** 回收站信息表的行集（七行，顺序 = 决策相关性）；归档档的行集归 `archive-detail.tsx`，两档不共用。 */
function trashInfoRows(entry: TrashEntryWire, detail: TrashDetailLike, t: Translate): DetailInfoRow[] {
  const project = detail.cwd === '' ? t('trash.project.unknown') : detail.cwd
  const models = detail.models.join(', ') || '—'
  return [
    { label: t('detail.field.project'), value: project, title: project },
    { label: t('detail.field.models'), value: models, title: models },
    { label: t('detail.field.created'), value: timeText(detail.createdAt) },
    { label: t('detail.field.lastActivity'), value: timeText(detail.lastActivity) },
    { label: t('detail.field.sessionId'), value: entry.sessionId, title: entry.sessionId, code: true },
    { label: t('detail.field.trashDir'), value: entry.id, title: entry.id, code: true },
    { label: t('detail.field.wasArchived'), value: entry.wasArchived ? t('detail.value.yes') : t('detail.value.no') },
  ]
}


export function TrashDetail({
  frame,
  busy,
  wide,
  onRetry,
  onBack,
  detailNav,
  t,
}: TrashDetailProps) {
  const { state } = frame
  const shownId = state.kind === 'idle' ? null : state.subject.id
  const entry = state.kind === 'idle' ? null : state.subject
  const detail = state.kind === 'ready' || state.kind === 'holding' ? state.detail : undefined
  const title = entry === null ? '' : headerName(entry, detail, t)

  /** 孩子视图里 `onOpenChild` 缺席：整段不画（详情不给孩子再开入口，ADR-0055 单级）。 */
  const children = detailNav.onOpenChild === undefined ? [] : detail?.subagents ?? []
  const subagents = useSubagentSection({
    subjectId: shownId ?? '',
    children: children.map((child) => ({
      id: child.id,
      name: rowName(child, t),
      sizeBytes: child.sizeBytes,
      at: child.deletedAt,
      navigable: true,
    })),
    // 合计与总数只念 Node 半那两份读数：这里不再自己求和。
    total: detail?.subagentsTotal,
    totalSizeBytes: detail?.subagentsSizeBytes,
    note: t('detail.subagents.note'),
    ...(detailNav.onOpenChild === undefined ? {} : { onOpenChild: detailNav.onOpenChild }),
    ...(detailNav.onPrefetchChild === undefined ? {} : { onPrefetchChild: detailNav.onPrefetchChild }),
    t,
  })

  return (
    <SessionDetail
      frame={frame}
      subjectId={shownId ?? ''}
      head={{ displayName: title, sizeText: entry === null ? null : fileSizeText(entry.sizeBytes) }}
      infoRows={entry === null || detail === undefined ? [] : trashInfoRows(entry, detail, t)}
      {...(subagents === undefined ? {} : { subagents })}
      busy={busy}
      wide={wide}
      onRetry={onRetry}
      onBack={onBack}
      detailNav={detailNav}
      t={t}
    />
  )
}
