/**
 * 一次成员移动 = 一串自带反向动作的步骤（ADR-0002）。这里独占四件事：相反顺序退化、一步失败时退回已做成的、
 * 失败收集（回滚不干净时不让原错误独走，进 `details.rollbackFailures`）、非原子步骤（`undoOnFailure`）。
 * 只服务成员在 sessions/ 与 session-trash/ 之间搬，不做通用撤销框架。
 */
import { isSessionDeleteCodeError } from '../shared/wire.js'
import { rollbackReason, verbError, withRollbackFailures, type VerbError } from '../errors.js'

/** 一步反向动作的结果：`restored` 只回答 `key` 所指那件写是否回到原样；同一步里的附属写失败仍进 `failures`。 */
export interface StepUndo {
  readonly restored: boolean
  readonly failures: readonly string[]
}

/** 一步的领域键。`restored(key)` 用它点名要核的那件写；收成联合，手滑写错键在编译期就报。 */
export type JournalStepKey = 'read' | 'workspace' | 'dir' | 'archive' | 'manifest'

/** 一次 undo 的汇总：失败串仍按原样合并；`restored(key)` 给动词判「成员归位 / 已移除」用。 */
export interface JournalUndo {
  readonly failures: readonly string[]
  restored(key: JournalStepKey): boolean
}

export interface JournalStep {
  /** 稳定的领域键，给 `restored(key)` 用。 */
  readonly key: JournalStepKey
  /** 这一步在做什么。失败原文按「`<label>：<原错误>`」拼。 */
  readonly label: string
  /** 做这一步。抛什么都由 journal 折成 `sessiondelete/io`（除非它自己已经是一个动词码）。 */
  run(): Promise<void>
  /** 反向动作。**`run` 成功之后**才会被登记；返回这一步退没退成与原因。 */
  undo?(): Promise<StepUndo>
  /** 这一步**自己**失败时也跑 `undo`：给"可能已经半做完"的非原子步骤用（取消归档是唯一的例子）。 */
  readonly undoOnFailure?: boolean
}

export interface Journal {
  /** 按顺序跑完。中途失败 ⇒ 已做成的按相反顺序退回，然后把原错误（带 `rollbackFailures`）抛出去。 */
  run(): Promise<void>
  /** 把**已经做成**的步骤按相反顺序退回去（整组回滚用：组里后面那个成员搬不动时叫这一句）。 */
  undo(): Promise<JournalUndo>
}

/** 已经把某个前缀做成了的 journal——`undo()` 就退那一个前缀。 */
export function createJournal(steps: readonly JournalStep[]): Journal {
  const done: JournalStep[] = []

  const undoAll = async (alsoFailing?: JournalStep): Promise<JournalUndo> => {
    const failures: string[] = []
    const restored = new Map<string, boolean>()
    const runUndo = async (step: JournalStep): Promise<void> => {
      if (step.undo === undefined) return
      const result = await step.undo()
      failures.push(...result.failures)
      restored.set(step.key, result.restored)
    }
    if (alsoFailing?.undo !== undefined) await runUndo(alsoFailing)
    for (const step of [...done].reverse()) await runUndo(step)
    return {
      failures,
      restored: (key) => restored.get(key) ?? false,
    }
  }

  return {
    async run(): Promise<void> {
      for (const step of steps) {
        try {
          await step.run()
        } catch (error) {
          const undo = await undoAll(step.undoOnFailure === true ? step : undefined)
          const base = journalFailure(step, error)
          throw undo.failures.length > 0 ? withRollbackFailures(base, undo.failures) : base
        }
        done.push(step)
      }
    },
    undo(): Promise<JournalUndo> {
      return undoAll()
    },
  }
}

/** 跑一步反向动作并把它自己的失败收成一条原因（不抛：这些失败由调用方汇总成 `rollbackFailures`）。 */
export async function attempt(label: string, run: () => Promise<unknown>): Promise<readonly string[]> {
  try {
    await run()
    return []
  } catch (error) {
    return [rollbackReason(label, error)]
  }
}

/** 一步反向动作的完整结果：主写是否回到原样 + 失败串。附属写失败只进 `failures`，不推翻 `restored`。 */
export async function stepUndo(label: string, run: () => Promise<unknown>): Promise<StepUndo> {
  const failures = await attempt(label, run)
  return { restored: failures.length === 0, failures }
}

/**
 * **组级回滚**：把已经做成的成员按相反顺序退回；某一步退不干净时把失败并进原错误的
 * `details.rollbackFailures`，绝不让原错误独走。删除与恢复两个按组走的动词共用这一处。
 */
export async function rollbackJournals(journals: readonly Journal[], error: unknown): Promise<never> {
  const failures: string[] = []
  for (const journal of [...journals].reverse()) {
    const undo = await journal.undo()
    failures.push(...undo.failures)
  }
  if (failures.length > 0) throw withRollbackFailures(error, failures)
  throw error
}

/**
 * 这一步的失败形状：已经是动词码（`verbError` 的输出）就原样带，否则折成 `sessiondelete/io`。
 * 原文用 `String(error)` 而不是 `.message`——既有措辞就是这么拼的，换一种拼法上屏原文会跟着变。
 */
function journalFailure(step: JournalStep, error: unknown): VerbError {
  if (isSessionDeleteCodeError(error)) return error as VerbError
  return verbError('io', `${step.label}：${String(error)}`, error)
}
