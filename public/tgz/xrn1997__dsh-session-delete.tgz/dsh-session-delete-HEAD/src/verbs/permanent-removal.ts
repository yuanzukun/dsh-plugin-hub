/**
 * 永久删除的测量、计划与执行：先记录目录/字节/账本归属，再按计划动盘。
 * 计划函数只读；活体准入在计划阶段、任何写之前完成，执行器动第一笔写前再查一次。
 *
 * 测量与补账本归属**分家**：`/list` 的只读计划只吃 {@link measureMembers}（零账本读，不再为每个
 * 盘上后代问一次 `workspaceOf`，`/list` 的失败面不再含账本归属读）；`workspaceOf` 只有
 * purge / orphan-clean 的删除计划（{@link planMemberRemovals}）才付——executor 摘账本要用它。
 */
import { sessionDirForId, trashDirOf, type TrashEntry } from '../trash/entry.js'
import type { TrashGroupView } from '../trash/groups.js'
import {
  executeImageAttachmentRemoval,
  isMissing,
  planImageAttachmentRemoval,
  recheckImageRemovalExclusivity,
  type ImageRemovalPlan,
} from '../trash/attachments.js'
import type { HostCorpusPort, SubagentMember } from '../ports/host-port.js'
import { mapLimit } from '../trash/session-rows.js'
import { bareSessionId, firstByBare } from '../domain/closure.js'
import type { CoreDeps, RemovalDeps } from '../deps.js'
import { isSessionDeleteCodeError, type AttachmentCleanupWire } from '../shared/wire.js'
import { dropDeletedSessionCache } from '../trash/projection-cache.js'
import { verbError, rollbackReason, withRollbackFailures } from '../errors.js'
import { assertNoLive } from './live-admission.js'

export interface MeasuredMemberDir {
  readonly dir: string
  readonly bytes: number
}

/** 一条成员被删之前要记下的三件：目录、字节、账本归属（缺席 = 未分组）。purge / orphan-clean 的
 *  删除计划共用这一份形状；`/list` 的只读计划不吃它——那一面零账本读，见 {@link measureMembers}。 */
export interface PlannedMemberRemoval {
  readonly sessionId: string
  readonly dir: string
  readonly bytes: number
  readonly workspaceId?: string
}

/** 一条目录的盘上读数：在不在 + 实测字节（不在 = 0 字节）。 */
interface DirProbe {
  readonly present: boolean
  readonly bytes: number
}

/** `exists → sizeOfDir` 的唯一一条度量口径（成员目录与回收站目录共用）：先问在不在，再量字节；
 *  缺席（ENOENT / ENOTDIR）才是"不在"，别的错误照旧响亮（ADR-0039）。别再在调用点各写一遍这段 try/catch。
 *
 *  **已知粒度**：`sizeOfDir` 递归里撞到的缺席与"目录本身没了"是同一个码，所以目录里某个文件
 *  恰好在这一拍消失时，整条目录会被记成「不在」（`/list` 少算这条、删除计划里没有可删的字节，
 *  而清册行照旧摘——盘上留下目录等下一次 `reconcile` 重建成行，自愈、不丢数据）。复核一次
 *  `exists(dir)` 能把两者分开，却会让「宿主正在写、文件刚被挪走」这类正常竞态把 `/list` 整个打红——
 *  这里选自愈不选响亮。 */
async function probeDir(deps: CoreDeps, dir: string): Promise<DirProbe> {
  if (!(await deps.fs.exists(dir))) return { present: false, bytes: 0 }
  try {
    return { present: true, bytes: await deps.fs.sizeOfDir(dir) }
  } catch (error) {
    if (isMissing(error)) return { present: false, bytes: 0 }
    throw error
  }
}

/** 成员的盘上目录与字节（扫描、清单装配与 purge 共用这一条路径/存在性/度量口径；
 *  目录缺席回 `undefined`，不拿一份"记录还在、盘上已经没了"的旧读数冒充盘上残留）。 */
export async function measureMemberDir(
  deps: CoreDeps,
  member: { readonly sessionId: string; readonly projectDir: string },
): Promise<MeasuredMemberDir | undefined> {
  // 目录按宿主目录段拼（`sessionDirForId`）：`sessionId` 是原始 id，宿主编码后才是目录名。
  const dir = sessionDirForId(member.projectDir, member.sessionId, deps.home)
  const probe = await probeDir(deps, dir)
  return probe.present ? { dir, bytes: probe.bytes } : undefined
}

/** 一条成员的**测量**读数：身份两格 + 目录 + 实测字节。没有账本归属那一格——归属是删除动词才要
 *  读的账本事实（见 {@link measureMembers} 与 {@link PlannedMemberRemoval} 的分工）。 */
export interface MeasuredMember {
  readonly sessionId: string
  readonly projectDir: string
  readonly dir: string
  readonly bytes: number
}

/** 只测量（目录 + 实测字节）：`/list` 的只读计划只吃这一支，零账本读。目录不在的成员跳过
 *  （记录与盘不一致是那条成员自己的事）。为什么不顺手把归属也问了：`/list` 投影只用字节与条数，
 *  那一格立刻被丢弃——每开一次回收站为它付 N 次宿主调用，还把账本归属读拉进 `/list` 的失败面。 */
export async function measureMembers(
  deps: CoreDeps,
  members: readonly { readonly sessionId: string; readonly projectDir: string }[],
): Promise<MeasuredMember[]> {
  const out: MeasuredMember[] = []
  for (const member of members) {
    const measured = await measureMemberDir(deps, member)
    if (measured === undefined) continue
    out.push({ sessionId: member.sessionId, projectDir: member.projectDir, ...measured })
  }
  return out
}

/** 把一组成员折成"删之前要记下的计划"：{@link measureMembers} 的测量之外**逐成员补账本归属**
 *  （`workspaceOf`）——executor 摘账本要用。`/list` 不走这里（它只吃 measureMembers，零账本读）。 */
async function planMemberRemovals(
  deps: CoreDeps,
  members: readonly { readonly sessionId: string; readonly projectDir: string }[],
): Promise<PlannedMemberRemoval[]> {
  const plans: PlannedMemberRemoval[] = []
  for (const measured of await measureMembers(deps, members)) {
    const workspaceId = await deps.host.workspaceOf(measured.sessionId)
    plans.push({
      sessionId: measured.sessionId,
      dir: measured.dir,
      bytes: measured.bytes,
      ...(workspaceId === undefined ? {} : { workspaceId }),
    })
  }
  return plans
}

/** 回收站里的一条要删的行：目录、在不在、实测字节（缺席 = 0）。purge 与 `/list` 都由它量。 */
export interface PlannedTrashRow {
  readonly entry: TrashEntry
  readonly dir: string
  readonly present: boolean
  readonly bytes: number
}

/** 量一条回收站行；目录不在回 `present: false` / 0 字节（目录不在不等于清册行不用摘）。 */
async function measureTrashRow(deps: CoreDeps, entry: TrashEntry): Promise<PlannedTrashRow> {
  const dir = trashDirOf(entry.id, deps.home)
  const probe = await probeDir(deps, dir)
  return { entry, dir, present: probe.present, bytes: probe.bytes }
}

/** 扁平化候选与组号绑成一条记录：全局去重仍只走 `firstByBare`，不再维护两条等长数组与一张
 *  按对象身份反查的表。 */
interface GroupedMember {
  readonly sessionId: string
  readonly projectDir: string
  readonly member: SubagentMember
  readonly groupIndex: number
}

/**
 * 盘上后代的选择判据（`/list` 与 purge 的删除计划共用这一份）：`subagentMembersOf` 一次问全部父，
 * 再按 `bareSessionId` **排除全部清册 id**（跟着父进来的孩子不按盘上残留再算一遍），同一个 bare id 只认
 * **遍历顺序里第一次**出现的那条（同一个会话在两代宿主里的写法不同；去重口径住 `src/domain/closure.ts` 的 `firstByBare`）。
 *
 * 语料看不见（`available: false`）⇒ 每个根都按空成员收：`/list` 与 purge 只许静默降级，
 * 盘上残留留给 `GET /orphans` 兜底。
 *
 * 结果按传入父 id 的原序分组、组内保持宿主交回的顺序：全局去重需要顺序，实测那一步可以并行。
 *
 * **单行读数和单行回执可能差一条**：同一个 bare id 若同时挂在两个组根下，全局去重只把它算给遍历
 * 顺序里第一个根；而对某个根单独 purge 时它仍会算进那一组 ⇒ 那条的 `releaseBytes` 与对它 purge 的
 * `freedBytes` 在共享后代上可以不等（全部可见行之和与 `/empty` 的回执仍相等）。数据里有环或两代
 * 写法混杂才会撞上，不为它多开一条口径。
 */
async function selectStrandedMembers(
  host: Pick<HostCorpusPort, 'subagentMembersOf'>,
  manifest: readonly TrashEntry[],
  parentIds: readonly string[],
): Promise<SubagentMember[][]> {
  const manifestIds = new Set(manifest.map((row) => bareSessionId(row.sessionId)))
  const read = await host.subagentMembersOf(parentIds)
  if (!read.available) return parentIds.map(() => [])
  // 每条候选与它第一次出现的组号绑成一条记录；全局去重的唯一口径仍是 `firstByBare`
  //（同一条的两代写法只认首见），首见的那条发回它第一次出现的组——跨根共享的后代只算给
  // 遍历顺序里先出现的组根。
  const flat: GroupedMember[] = []
  parentIds.forEach((parentId, groupIndex) => {
    for (const member of read.value[parentId] ?? []) {
      if (manifestIds.has(bareSessionId(member.sessionId))) continue
      flat.push({ sessionId: member.sessionId, projectDir: member.projectDir, member, groupIndex })
    }
  })
  const out: SubagentMember[][] = parentIds.map(() => [])
  for (const entry of firstByBare(flat)) {
    const bucket = out[entry.groupIndex]
    // 组号来自 `parentIds.forEach` 的下标，必在界内；这一句只满足 `noUncheckedIndexedAccess`。
    if (bucket === undefined) throw verbError('io', `子会话分组越界：${entry.member.sessionId}`)
    bucket.push(entry.member)
  }
  return out
}

/** `/list` 的一行（一组）所需的只读数：`releaseBytes` 是这一组**实测**会释放的字节。
 *  `members` 是 {@link MeasuredMember}（测量读数，无账本归属格）：清单只用它的字节与条数。 */
export interface VisibleTrashGroup extends TrashGroupView {
  readonly trash: readonly PlannedTrashRow[]
  readonly members: readonly MeasuredMember[]
  readonly releaseBytes: number
  readonly subagentBytes: number
  readonly strandedBytes: number
  readonly strandedCount: number
}

/** `/list` 只读计划的盘上测量预算：组与组内的 kids 两级各用这一份。
 *  为什么要有界：`/list` 一次可能几百组、每组几百个孩子，无界 `Promise.all` 会把上千个
 *  `exists` / `sizeOfDir` 一起挂起去抢同一个盘；预算与逐行读数（`ROW_READ_CONCURRENCY`）的旋钮
 *  分家——那边是宿主投影读，这边是盘上递归量尺寸，同一个数没有同一条理由。 */
const VISIBLE_MEASURE_CONCURRENCY = 8

/**
 * `/list` 的只读计划：一行 = 一组。释放量与 purge 用同一条口径——回收站目录与成员目录**现测**，
 * 不用清册里记的 `sizeBytes`（那是删除那一刻的事实，盘上早就变了）。
 *
 * 盘上后代经 `selectStrandedMembers` 选出（排除全部清册 id、bare id 全局只算一次）；目录不在的成员
 * 不进 `members`（与 purge 计划同口径）。成员只吃 {@link measureMembers}：**零账本读**——不再为每个
 * 盘上后代问一次 `workspaceOf`，`/list` 的失败面不再含账本归属读（归属只有 purge 摘账本才付）。
 *
 * 两级都有界（{@link VISIBLE_MEASURE_CONCURRENCY}）：组之间、组内 kids 各一扇窗；输出顺序仍按
 * `groups` 原序（`mapLimit` 按 index 落位），首个失败原样抛。
 */
export async function planVisibleTrash(
  deps: CoreDeps,
  rows: readonly TrashEntry[],
  groups: readonly TrashGroupView[],
): Promise<VisibleTrashGroup[]> {
  // 候选按组先选好（只读，但要问一次宿主的 subagentMembersOf）：逐组实测那一步可以并行。
  const candidates = await selectStrandedMembers(deps.host, rows, groups.map((group) => group.root.sessionId))
  return await mapLimit(groups, VISIBLE_MEASURE_CONCURRENCY, async ({ root, kids }, index) => {
    const rootRow = await measureTrashRow(deps, root)
    const kidRows = await mapLimit(kids, VISIBLE_MEASURE_CONCURRENCY, (kid) => measureTrashRow(deps, kid))
    const members = await measureMembers(deps, candidates[index] ?? [])
    const subagentBytes = kidRows.reduce((total, row) => total + row.bytes, 0)
    const strandedBytes = members.reduce((total, member) => total + member.bytes, 0)
    return {
      root,
      kids,
      trash: [rootRow, ...kidRows],
      members,
      releaseBytes: rootRow.bytes + subagentBytes + strandedBytes,
      subagentBytes,
      strandedBytes,
      strandedCount: members.length,
    }
  })
}

/** 一次永久删除的只读计划：哪些目录要删、各自实测多少字节、哪些会话要先摘归档集。
 *  `kind` 同时决定执行器在**删目录阶段**失败时交不交部分回执：`trash`（purge）不带、`orphan`
 *  （orphan-clean）带 `{removed, freedBytes, failedSessionId}`——回执与 `kind` 在生产里 1:1，
 *  所以由 `kind` 派生，不另存一份会跟它漂移的字段；更早的 `unarchive` / `detach` 一步不套回执。 */
export interface RemovalPlan {
  readonly kind: 'trash' | 'orphan'
  readonly trash: readonly PlannedTrashRow[]
  readonly members: readonly PlannedMemberRemoval[]
  readonly unarchive: readonly string[]
  /** 计划量到的合计；成功回执的 freedBytes 只念它。 */
  readonly bytes: number
  /** 这一次要连带清掉的独占图片对象（`trash/attachments.ts` 的域判定；空计划 = 没有可删的、或
   *  剩余引用源读不出而整体跳过——原因在 `skipped` 里）。附件字节**不进** `bytes`：那是会话目录的
   *  释放量，附件读数单独走回执的 `attachments`。 */
  readonly attachments: ImageRemovalPlan
}

function totalBytes(items: readonly { readonly bytes: number }[]): number {
  return items.reduce((total, item) => total + item.bytes, 0)
}

/**
 * purge 的删除计划：`targets` 由调用方按组语义（`trash/groups.ts`）选好，这里只量、只筛、只查活体。
 * **计划函数是执行前的第一道闸**——调用方拿到计划才允许写；计划与第一笔写之间的窗口由
 * `executeRemoval` 在首笔写前复查（见该函数头注）。
 *
 * - `trash` 按 targets 原序逐个实测（目录缺席的行 `present:false` / 0 字节，但清册行仍要摘）。
 * - 盘上后代经 `selectStrandedMembers` 选出（一次问全部 targets、排除全部清册 id、bare id 全局只计划一次）。
 * - `members` 只收盘上还有目录的成员（目录缺席没有可删的字节）；`unarchive` = targets + 这些成员：
 *   只摘这一次真要碰的 id。
 * - `attachments` 由被删目录（targets + 这些成员）里的图片引用与全部剩余引用源算独占；共享的保留、
 *   剩余引用源读不出就整体跳过（判据住 `trash/attachments.ts`，这里只接线）。
 * - 活体准入在量目录与任何写之前逐个查 targets 与**全部枚举到的**盘上后代；任一在跑就整条拒绝、
 *   零副作用。没有跳过它的开关；执行器首笔写前还会用计划里的 `unarchive` 名单复查（ADR-0027）。
 * - `sessionQuery` 缺席时端口回 `{ available: false }` ⇒ members 为空、不抛（盘上残留留给 `GET /orphans` 兜底）。
 */
export async function planTrashRemoval(
  deps: CoreDeps,
  rows: readonly TrashEntry[],
  targets: readonly TrashEntry[],
): Promise<RemovalPlan> {
  const candidates = (await selectStrandedMembers(deps.host, rows, targets.map((entry) => entry.sessionId))).flat()
  // 准入住在计划里、量目录与任何写之前（判据与那句原文住 `verbs/live-admission.ts`）。
  await assertNoLive(deps.host, [
    ...targets.map((entry) => entry.sessionId),
    ...candidates.map((member) => member.sessionId),
  ])
  // 批量 purge 的 targets 可能一次上百条：盘上测量同样走组测量的那份有界预算，
  // 不拿宿主的并发换自己的省事（同一份 `mapLimit`，见 `/list` 的组测量）。
  const trash = await mapLimit(targets, VISIBLE_MEASURE_CONCURRENCY, (entry) => measureTrashRow(deps, entry))
  const members = await planMemberRemovals(deps, candidates)
  // 剩余引用源由附件域自己扫（活动会话 + 除本次被删目录外的全部 session-trash + storages/cache）。
  const attachments = await planImageAttachmentRemoval(
    deps,
    [...trash.map((row) => row.dir), ...members.map((member) => member.dir)],
  )
  return {
    kind: 'trash',
    trash,
    members,
    unarchive: [...targets.map((entry) => entry.sessionId), ...members.map((member) => member.sessionId)],
    bytes: totalBytes(trash) + totalBytes(members),
    attachments,
  }
}

/**
 * orphan-clean 的删除计划：成员是调用方扫出来的传递闭包（`orphanGroupsOf`）。
 *
 * - `members` 只收盘上还有目录的成员（目录缺席没有可删的字节），`bytes` 只算这些实测值。
 * - `unarchive` 覆盖**全部传入成员**（含目录缺席）：orphan-clean 在删目录之前整批摘归档集，
 *   目录缺席的 id 也可能还挂在归档集里；重试时不会再长出一条幽灵 id。
 * - live 准入覆盖**全部传入成员**（含目录缺席）：它们都在这一组的可见面里，任一在跑就整组拒绝。
 * - `attachments` 的剩余引用源由附件域自己扫（活动会话 + 全部 session-trash + storages/cache），
 *   共享图片因此保留（判据住 `trash/attachments.ts`）。
 * - 回执由 `kind:'orphan'` 派生：删目录阶段失败时执行器要交回 `{removed, freedBytes, failedSessionId}`。
 */
export async function planOrphanRemoval(
  deps: CoreDeps,
  members: readonly { readonly sessionId: string; readonly projectDir: string }[],
): Promise<RemovalPlan> {
  await assertNoLive(deps.host, members.map((member) => member.sessionId))
  const present = await planMemberRemovals(deps, members)
  const attachments = await planImageAttachmentRemoval(
    deps,
    present.map((member) => member.dir),
  )
  return {
    kind: 'orphan',
    trash: [],
    members: present,
    unarchive: members.map((member) => member.sessionId),
    bytes: totalBytes(present),
    attachments,
  }
}

/** 一次永久删除的成功回执：条数、计划合计字节与附件读数（purge 与 orphan-clean 共用这一形状）。 */
export interface RemovalStats {
  readonly removed: number
  readonly freedBytes: number
  readonly attachments: AttachmentCleanupWire
}

/**
 * 执行器的窄面：把一份计划动成盘、把 {@link RemovalStats} 交回来。清册作用域只拿这一件——
 * 删的能力（`RemovalDeps`）留在持有它的调用方手里、按调用点注入，作用域自己够不着。
 */
export type RemovalExecutor = (plan: RemovalPlan) => Promise<RemovalStats>

/**
 * 按计划执行一次永久删除：不再量。回执的字节念计划（`plan.bytes`），执行期不再累加一遍。
 *
 * **计划 + 执行器、准入查两遍**（ADR-0027）：计划期准入证明计划成立时没有会话在跑；执行器首笔写前
 * 再用同一份名单复查，补上附件扫描撑开的窗口。
 *
 * 计划期准入与第一笔写之间还隔着附件引用的全 home 扫描（`planImageAttachmentRemoval`），大 home
 * 上那是秒级窗口——期间用户 resume 一个会话，它的目录随后仍会被删。所以动任何写之前用计划里同一份
 * 会话名单**再查一次活体**（只读、廉价）；这一查失败仍然零写入。名单取 `plan.unarchive`：
 * 它覆盖所有会被删目录的会话（回收站行与盘上成员），目录已不在的成员没有可删的东西。
 *
 * 顺序：整批摘归档集 → 摘有账本的成员的账本 → 逐条回收站行
 * （在才删目录 → 摘清册行 → 通告成员离场）→ 逐条盘上成员（删目录 → 通告成员离场）→ 逐条附件对象。
 * 目录删掉就没有"退回去"这回事，中途失败**不回滚目录**；已经删掉的由下面的计数器如实交回。
 * **归档态回滚**：`unarchive` 排在所有删除之前（免得留下"会话没了、归档集还挂着"的幽灵 id），
 * 所以中途失败时目录还在、归档位却已经摘了。失败出口把**目录还在**的那些（这一趟没删掉、也不是计划时
 * 就缺席）按删除前的读数重新归档（`isArchived` 先读过一次，不是按 `wasArchived` 猜）；目录不在的跳过
 * ——那时恢复归档只会造幽灵 id。
 * 回滚自己的失败走 `details.rollbackFailures`，不让它把原错误吞掉（ADR-0040）。
 * **附件计划在执行期复核**：计划到删对象之间的窗口里新增的引用会让计划过期；删对象前用同一套
 * 剩余引用扫描重判一次，只删这一刻仍无引用的对象（ADR-0041）。
 *
 * 失败形状：
 * - `kind:'orphan'`（orphan-clean）⇒ `io` + `{removed, freedBytes, failedSessionId}`，不伪装成整组没动；
 * - `kind:'trash'`（purge）⇒ 同一个标签、不带 details；
 * - orphan-clean 的归档实况预读 / unarchive / detach 原样抛出；
 * - 归档态回滚不干净时，原错误带 `details.rollbackFailures`（码仍按原错误的动词码）。
 *
 * 通告只经 `member-presence`（摘活体三态 + `api-session/removed`），不在这里另写一份。
 */
export async function executeRemoval(
  deps: RemovalDeps,
  plan: RemovalPlan,
): Promise<RemovalStats> {
  // 计划→执行的窗口由附件引用扫描撑开；动第一笔写前重查同一份名单（理由见函数头注）。
  await assertNoLive(deps.host, plan.unarchive)
  const presence = deps.presence
  let removed = 0
  /** 删到这一刻已经腾出的**进度**：只喂 `orphan` 的部分回执；成功回执念计划的合计（`plan.bytes`）。 */
  let freedSoFar = 0

  /** 删除途中失败的唯一出口：标签沿用旧措辞；部分回执只属于 `orphan`（由计划的 `kind` 派生）。
   *  已经是本仓动词码的错误原样抛（与 `member-journal.ts` 的 `journalFailure` 同一条判据）——
   *  `not-found` / `live` 之类不许在这里被折成 `io`。 */
  const fail = (label: string, error: unknown, failedSessionId: string): never => {
    if (isSessionDeleteCodeError(error)) throw error
    const details = plan.kind === 'orphan' ? { removed, freedBytes: freedSoFar, failedSessionId } : undefined
    throw verbError('io', `${label}：${String(error)}`, error, details)
  }

  /** 归档实况预读 / 退归档集 / 摘账本这一步的失败形状：purge 折成带标签的 `io`；orphan-clean 原样抛。 */
  const step = async (label: string, sessionId: string, run: () => Promise<void>): Promise<void> => {
    if (plan.kind === 'orphan') {
      await run()
      return
    }
    try {
      await run()
    } catch (error) {
      fail(label, error, sessionId)
    }
  }

  // 归档态回滚名单：只放回删除前确实归档着的那些。`unarchive` 对未归档是 no-op，回滚时更不能
  // 凭空把没归档过的会话归档了——所以先读一次，不按 `wasArchived` 猜（旧条目、盘上成员的归档事实
  // 都可能与清册那一格不同）。预读失败与 unarchive 同走一条 `step` 形状（purge 折成带标签的 `io`、
  // orphan-clean 原样抛），且此刻零写入。
  const archivedBefore = new Set<string>()
  for (const sessionId of plan.unarchive) {
    await step('读取归档状态失败', sessionId, async () => {
      if (await deps.host.isArchived(sessionId)) archivedBefore.add(sessionId)
    })
  }
  /** 走到过 `unarchive` 这一步的 id（含失败那一条）：失败时按它回滚。 */
  const unarchived: string[] = []
  /** 计划时目录还在的 id：只有这些会话还有本体可挂归档。计划时就缺席的行 / 成员也在 `unarchive`
   *  名单里（那一步顺带清幽灵 id），但没有目录可回滚。 */
  const onDisk = new Set<string>([
    ...plan.trash.filter((row) => row.present).map((row) => row.entry.sessionId),
    ...plan.members.map((member) => member.sessionId),
  ])
  /** 目录已经真删掉的 id：没有归档态可放回去，跳过——否则会在 registry 里留下幽灵 id。 */
  const deleted = new Set<string>()

  try {
    // 归档集与账本在**任何删除之前**退掉：失败时目录还在，重试还能清；也不会留下"会话没了、归档集还挂着"的幽灵 id。
    for (const sessionId of plan.unarchive) {
      unarchived.push(sessionId)
      await step('取消归档失败', sessionId, () => deps.host.unarchive(sessionId))
    }
    for (const member of plan.members) {
      const workspaceId = member.workspaceId
      if (workspaceId === undefined) continue
      await step('摘账本失败', member.sessionId, () => deps.host.detach(member.sessionId, workspaceId))
    }

    // 回收站行：计划里 `present:false` 的行没有目录可删（执行期也不再问盘），但清册行仍要摘。
    for (const row of plan.trash) {
      if (row.present) {
        try {
          await deps.fs.removeDir(row.dir)
        } catch (error) {
          fail('删除回收站目录失败', error, row.entry.sessionId)
        }
        deleted.add(row.entry.sessionId)
        freedSoFar += row.bytes
      }
      try {
        await deps.ledger.remove(row.entry.id)
      } catch (error) {
        fail('摘除回收站条目失败', error, row.entry.sessionId)
      }
      removed += 1
      await presence.memberGone(row.entry.sessionId)
      // 只有这一行的目录/清册行确实处理完，才删**这一条会话**的投影缓存：不按计划名单批量扫，
      // 删到一半失败时已删的照清、没删成的不动。缓存删除失败只留 warning，不翻删除。
      await dropDeletedSessionCache(deps, row.entry.sessionId)
    }

    // 盘上成员：标签按调用方区分（purge 说的是"盘上后代"，orphan-clean 说的是"会话目录"）。
    const memberLabel = plan.kind === 'trash' ? '删除盘上后代目录失败' : '删除会话目录失败'
    for (const member of plan.members) {
      try {
        await deps.fs.removeDir(member.dir)
      } catch (error) {
        fail(memberLabel, error, member.sessionId)
      }
      deleted.add(member.sessionId)
      removed += 1
      freedSoFar += member.bytes
      await presence.memberGone(member.sessionId)
      // 同回收站行：这一条成员目录真的删掉了，才删这一条会话的缓存。
      await dropDeletedSessionCache(deps, member.sessionId)
    }

    // 附件对象最后动：会话目录已经真的没了，失败只计数、不回滚，也不改会话删除的字节。
    // 删之前再复核一次独占：计划到这一刻的窗口里新增的引用（同图再贴一次 / 派生存储新写一条）
    // 必须保住对象，否则删的是"这一刻仍被引用"的副本（ADR-0041）。
    const attachmentPlan = await recheckImageRemovalExclusivity(deps, plan.attachments)
    const attachments = await executeImageAttachmentRemoval(deps, attachmentPlan)
    return {
      removed,
      freedBytes: plan.bytes,
      attachments: {
        ...attachments,
        ...(attachmentPlan.skipped === undefined ? {} : { skipped: attachmentPlan.skipped }),
      },
    }
  } catch (error) {
    // 目录不回滚（删了就是删了）；归档态不是——条目还在回收站、目录也还在的那些，用户随后恢复时
    // 恢复路径不会替他补归档（它只按 `wasArchived` 迁移旧条目），所以这里必须放回去（ADR-0040）。
    const rollbackFailures: string[] = []
    for (const sessionId of [...unarchived].reverse()) {
      if (!archivedBefore.has(sessionId) || deleted.has(sessionId) || !onDisk.has(sessionId)) continue
      try {
        await deps.host.archive(sessionId)
      } catch (rollbackError) {
        rollbackFailures.push(rollbackReason('恢复归档失败', rollbackError))
      }
    }
    throw rollbackFailures.length === 0 ? error : withRollbackFailures(error, rollbackFailures)
  }
}
