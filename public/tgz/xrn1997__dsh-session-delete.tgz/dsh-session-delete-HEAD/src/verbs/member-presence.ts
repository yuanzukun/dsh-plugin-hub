/**
 * 成员离场 / 归位的通告协议：摘活体、三态判断、成对事件只在这里做。
 *
 * 调用方包括 delete、restore 回滚、purge、orphan-clean；协议说错一次就是客户端留假行或删真行。
 *
 * 边界：
 * - 批量恢复的编排归 `verbs/batch.ts`（ADR-0002）；本模块只实现 `announceRestored(ids)`（ADR-0019）。
 * - 哪个键算归位由动词在 `tail.onUndone` 里读成事实再交进来，真值表住这里；
 *   `run`/`undo` 之后补通告的形状由 {@link withPresenceTail} 拥有。
 * - `evictLive`/`announce*` 按契约不抛，这里不再叠 catch。
 */
import type { EvictionOutcome, HostPresencePort } from '../ports/host-port.js'
import type { PresenceCapability } from '../ports/presence-port.js'
import type { Journal, JournalUndo } from './member-journal.js'

/** 本模块实际用到的三条宿主能力。`Pick` 此刻覆盖 `HostPresencePort` 的三条方法，仍留着它当闸：
 *  将来端口多出第四条时，这里不会被动跟着变宽——能力面只暴露这三条，批量通告的编排归 `verbs/batch.ts`。 */
export type MemberPresenceHost = Pick<HostPresencePort, 'evictLive' | 'announceRemoved' | 'announceRestored'>

/** 本仓的在场能力实现，也是**全仓唯一的盖章处**：端口形状住 `src/ports/presence-port.ts`，这里只做
 *  三态与真值表。品牌字段是类型层的（unique symbol 不导出、没有运行时值），所以只有这一处显式断言
 *  能把三件方法盖成 `PresenceCapability`——手拼同样的三件满足不了那个面（`tests/deps.test.ts` 钉住）。
 *  `announceRestored` 直接交宿主那一手：能力面与宿主面同名同签名，再包一层只会多一个转调。 */
export function createMemberPresence(host: MemberPresenceHost): PresenceCapability {
  const impl: Pick<PresenceCapability, 'memberGone' | 'memberBack' | 'announceRestored'> = {
    async memberGone(sessionId, facts = { backInTrash: true }) {
      if (!facts.backInTrash) return
      const eviction: EvictionOutcome = await host.evictLive(sessionId)
      if (eviction !== 'unknown') await host.announceRemoved(sessionId)
    },
    async memberBack(sessionId, facts) {
      if (!facts.diskBack || !facts.workspaceBack) return
      await host.announceRestored([sessionId])
    },
    announceRestored: host.announceRestored,
  }
  // 盖章：三条方法先按结构类型（`Pick<PresenceCapability, …>`）逐字校验，`as` 只补品牌这一格。
  return impl as PresenceCapability
}

/** 一次 undo 之后要发哪一条通告：`leave` = 成员已不在可见面，`return` = 已回到原可见状态。 */
export type PresenceAnnounce =
  | { readonly kind: 'leave'; readonly backInTrash: boolean }
  | { readonly kind: 'return'; readonly diskBack: boolean; readonly workspaceBack: boolean }

/** 动词给工厂的那一格：哪个成员、run 成不成功要不要补离场、undo 之后按逐步结果发哪一条。 */
export interface PresenceTail {
  readonly sessionId: string
  /** `run()` 成功后补离场通告（删除用）。省略 = run 不动在场（恢复的 run 本来就不该发东西）。 */
  readonly onDone?: 'leave'
  /** `undo()` 完成后按逐步结果发通告。 */
  onUndone(undo: JournalUndo): PresenceAnnounce
}

/**
 * 给一次成员移动的 journal 补上「在场那条尾巴」：run 完全成功之后离场，undo 之后按事实归位或离场。
 *
 * 边界：`memberGone` 的 `backInTrash:false` 早退与 `memberBack` 的两件齐备真值表归 `createMemberPresence`；
 * 这里只把事实原样递过去。
 */
export function withPresenceTail(presence: PresenceCapability, journal: Journal, tail: PresenceTail): Journal {
  const announce = async (undo: JournalUndo): Promise<void> => {
    const fact = tail.onUndone(undo)
    if (fact.kind === 'leave') {
      await presence.memberGone(tail.sessionId, { backInTrash: fact.backInTrash })
      return
    }
    await presence.memberBack(tail.sessionId, { diskBack: fact.diskBack, workspaceBack: fact.workspaceBack })
  }
  return {
    async run(): Promise<void> {
      await journal.run()
      if (tail.onDone === 'leave') await presence.memberGone(tail.sessionId)
    },
    async undo(): Promise<JournalUndo> {
      const undo = await journal.undo()
      await announce(undo)
      return undo
    },
  }
}
