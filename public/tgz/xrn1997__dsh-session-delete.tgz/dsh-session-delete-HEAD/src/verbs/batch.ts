/**
 * 「这一批」的唯一实现（ADR-0002）：POST /apply 的落点——一组 id 上的同一个动作。
 *
 * 批量是请求的性质，不是单个动词的性质。这里拥有三件事：
 * - 去重并保持输入顺序；
 * - 逐条信封：一条失败不传染下一条，失败按 map-error 折成错误对象；
 * - 恢复通告攒到批尾，一次 announceRestored(ids)。
 *
 * 「已被同批前一条带走」是幂等成功（delete/restore 回 null，purge 回 0），不是失败；
 * 判据在 trash/groups.ts，同批已带走集在 batch-carried.ts。
 */
import { toRemoteFailure } from '../remote/map-error.js'
import { bareSessionId } from '../ports/host-port.js'
import type { ApplyAction, ApplyOutcome, ApplyValueByAction } from '../shared/wire.js'
import type { CoreDeps, DeleteDeps, DeleteSessionDeps, RemovalDeps } from '../deps.js'
import { createEntryCarried, createSessionCarried } from './batch-carried.js'
import { deleteSession } from './delete-session.js'
import { verbError } from './errors.js'
import { cleanOrphanGroup, loadOrphanGroups } from './orphan-subagents.js'
import { purgeTrash } from './purge-trash.js'
import { restoreSession } from './restore-session.js'

function failure(id: string, action: ApplyAction, error: unknown): ApplyOutcome {
  return { id, action, ok: false, error: toRemoteFailure(error) }
}

/** 按动作收窄的成功支（判别联合要的是**字面量**，所以动作参数按 `A` 收，不收成宽化的 `ApplyAction`）。 */
function success<A extends ApplyAction>(id: string, action: A, value: ApplyValueByAction[A]): Extract<ApplyOutcome, { action: A }> {
  return { id, action, ok: true, value } as Extract<ApplyOutcome, { action: A }>
}

/** 去重且保持输入顺序（重复 id 跑第二遍是"幂等成功"的伪装，不该发生）。 */
function unique(ids: readonly string[]): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  for (const id of ids) {
    if (seen.has(id)) continue
    seen.add(id)
    out.push(id)
  }
  return out
}

/**
 * 一条 id 一条结果：**这是批量唯一的形式**（单条就是长度为 1 的批量，仓里不留第二条执行路径）。
 * 动词只收一个 id、只吐一条结果；`try/catch` 在这一处，失败不传染下一条。
 */
async function forEachId<A extends ApplyAction>(
  action: A,
  ids: readonly string[],
  run: (id: string) => Promise<ApplyValueByAction[A]>,
): Promise<ApplyOutcome[]> {
  const outcomes: ApplyOutcome[] = []
  for (const id of unique(ids)) {
    try {
      outcomes.push(success(id, action, await run(id)))
    } catch (error) {
      outcomes.push(failure(id, action, error))
    }
  }
  return outcomes
}

async function applyDelete(deps: DeleteSessionDeps, ids: readonly string[]): Promise<ApplyOutcome[]> {
  const run = deleteSession(deps)
  // 同批父先被删时，孩子是跟着父一起搬走的；后到的孩子 id 是一次幂等 no-op。
  // 这份名单**由动词的结果长出**（`movedSessionIds` = 这次真的搬走的整组），删除写完之后不再读一次清册。
  const carried = createSessionCarried()
  return forEachId('delete', ids, async (sessionId) => {
    if (carried.claim(sessionId).verdict === 'carried') return null
    const { entry, movedSessionIds } = await run(sessionId)
    for (const movedId of movedSessionIds) carried.take(movedId)
    return entry
  })
}

/** 「这条是不是被同批前一条带走了」与视图收缩都归 `batch-carried.ts`；`apply` 整批只读一次清册，
 *  动词只拿它交回的只读组与当前清册。 */
async function applyRestore(deps: CoreDeps, ids: readonly string[]): Promise<ApplyOutcome[]> {
  // 整批一次清册读（"最初的样子"）+ 一份会收缩的同批已带走集；通告攒到批尾，一次发整组 id。
  const carried = createEntryCarried(await deps.ledger.list())
  const run = restoreSession(deps)
  const restored: string[] = []
  const outcomes = await forEachId('restore', ids, async (entryId) => {
    const claim = carried.claim(entryId)
    if (claim.verdict === 'carried') return null // 已被同批前一条带走：幂等 no-op
    // `absent`（幽灵 id）没有组：递空组，动词照样抛 trash-empty（原文只在动词一处）。
    const group = claim.verdict === 'fresh' ? claim.group : []
    const entry = await run(entryId, group)
    carried.take(entryId)
    // 通告的是**这一组的会话 id**（父 + 跟着它回来的孩子）
    restored.push(...group.map((row) => row.sessionId))
    return entry
  })
  if (restored.length > 0) {
    await deps.presence.announceRestored(restored)
  }
  return outcomes
}

async function applyPurge(deps: RemovalDeps, ids: readonly string[]): Promise<ApplyOutcome[]> {
  const carried = createEntryCarried(await deps.ledger.list())
  const run = purgeTrash(deps)
  return forEachId('purge', ids, async (entryId) => {
    const claim = carried.claim(entryId)
    if (claim.verdict === 'carried') return { removed: 0, freedBytes: 0 } // 已被同批前一条带走
    // 与 restore 同理：动词读**当前视图**，前一条已经清掉的行不再出现在这一组的预检/删除目标里；
    // `absent` 没有组，递空表让动词抛 trash-empty。
    const group = claim.verdict === 'fresh' ? claim.group : []
    const stats = await run(group, carried.rows(), entryId)
    carried.take(entryId)
    return stats
  })
}

/** 删除确认框那句「含 N 个子会话」：一次问完整批（`subagentMembersOf` 本来就是批量口）。
 *  宿主口缺席（`available:false`）时按 0（这里不再有"空表"这一步）；真读失败则整次调用失败，
 *  浏览器半按"读不到"把整句不说。 */
async function applyCount(deps: CoreDeps, ids: readonly string[]): Promise<ApplyOutcome[]> {
  const wanted = unique(ids)
  const read = await deps.host.subagentMembersOf(wanted)
  return wanted.map(id => success(id, 'count', read.available ? (read.value[id]?.length ?? 0) : 0))
}

/**
 * 清一组无主子会话（父已被彻底删掉、孩子还留在 `sessions/` 里的那些）。id 是**根会话 id**——
 * 界面先 `GET /orphans` 拿 `roots` 再原样带回来，所以这里的 `not-found` 说的是"这句话已经过期了"
 * （父又被人放回回收站、组已被上一个请求带走，或另一处已经把目录清掉），不是"用户打错了一个 id"。
 * 根 id 两边都去 `session-` 前缀再比：报告原样回传是正常路径，外部调用带另一种写法也认。
 *
 * **这是写动作，排在到达序链上**，而且**先对账再扫**：`loadOrphanGroups` 本身只扫描、不写清册；
 * 这里先把 `ledger.list()` 对账后的行交给它——刚被人手工搬进 `session-trash/` 的那一格目录此刻可能还
 * 没有对应行，拿 raw 索引扫就会把"父还在回收站里等着"的一组当成孤儿**直接删盘**，替用户做了一个没人
 * 点过的决定（那种组该跟着父恢复或彻底删除）。
 */
async function applyOrphanClean(deps: RemovalDeps, ids: readonly string[]): Promise<ApplyOutcome[]> {
  // 对账交回的行直接给扫描，不再读第二遍 raw 索引。
  const trash = await deps.ledger.list()
  // 语料面（宿主 `sessionQuery`）缺席时这一句抛 `io` ⇒ 整次调用失败，不回一份"零条"的假回执。
  // 只量请求点名的根：报告可能列着几十组，这里不该为没被点的那几组递归量树。
  const groups = await loadOrphanGroups(deps, trash, ids)
  const byRoot = new Map(groups.map(group => [bareSessionId(group.root.sessionId), group]))
  // 组内没有回收站这一层可退：`cleanOrphanGroup` 的 live 准入在任何写之前（整组拒绝、零副作用）；
  // 删到一半失败时已删目录不回滚，失败错误的 `details` 带 `{ removed, freedBytes }` 作为部分回执，
  // 不会伪装成"整组清完了"。`not-found` 在这里抛，由 `forEachId` 折成失败信封；`receipt.ts`
  // 对 orphan-clean 的 `not-found` 再判为中性。
  return forEachId('orphan-clean', ids, async (id) => {
    const group = byRoot.get(bareSessionId(id))
    if (group === undefined) throw verbError('not-found', `不再是可清理的无主子会话：${id}`)
    return await cleanOrphanGroup(deps, group)
  })
}

export function applyActions(deps: DeleteDeps, action: ApplyAction, ids: readonly string[]): Promise<ApplyOutcome[]> {
  switch (action) {
    case 'delete':
      return applyDelete(deps, ids)
    case 'restore':
      return applyRestore(deps, ids)
    case 'purge':
      return applyPurge(deps, ids)
    case 'count':
      return applyCount(deps, ids)
    case 'orphan-clean':
      return applyOrphanClean(deps, ids)
  }
}
