# dsh-providers-hub

> **本包原名 `dsh-codearts-auth`**（`0.2.0-rc.11` 起改名）。老用户的 DSH profile 里
> 还锁着旧名时，**插件会加载失败并被自动禁用**（宿主报 `N entry did not activate`，
> 界面里也就看不到它）—— 升级前先看
> [⚠️ 从旧包名 `dsh-codearts-auth` 升级](#️-从旧包名-dsh-codearts-auth-升级)。

> **使用声明**：本项目仅供学习研究使用，请遵守各服务提供方的服务条款。

> 📢 **与时俱进 莫要刻舟求剑**，magpie 插件推荐：<https://docs.qq.com/doc/DQ1pWTExHaEFtcFNY>

deepseek-harness 插件：统一管理多个 AI 编程服务的账号，并把它们的模型接进 DSH
的模型选择器。支持**多账号池**（同一服务登录多个账号，按可用性自动选号）与
**凭据静默续期**（到期前自动刷新，无需再次打开浏览器）。

- **29 个 provider 路由**，外加 1 个**聚合**路由（见下）
- 登录、状态、续期、积分领取**全部在 Jet Hub 设置页完成**，不注册任何斜杠命令
- 附带一个**本机 OpenAI 兼容网关**，供其它客户端复用已登录账号

> 📌 **本 README 只写「怎么用」。** 各 provider 的协议、端点、登录流程、请求头
> 构造、实测数据与事故史等**实现细节**，统一记录在不入库的内部文档
> `docs/implementation-notes.md` 中。需要改动实现或排查协议问题时读它。
>
> ⚠️ **accio 的章节该文件里还没有**（`implementation-notes.md` 目前零处 accio）——
> 读它时**不要**以为 accio 没有实现笔记。accio 的实测结论与坑点当前登记在
> `docs/agent-notes/providers-accio.md`（含三条与参考实现相反的结论、两个真缺陷、
> 区域选择与接线陷阱），补写 `implementation-notes.md` 的 accio 章节是**独立任务**。

---

## 目录

- [安装](#安装)
- [Windows 服务器部署（引导式 / 离线式）](#windows-服务器部署引导式--离线式)
- [用法](#用法)
- [支持的渠道](#支持的渠道)
- [聚合路由](#聚合路由aggregate)
- [本机 OpenAI 网关](#本机-openai-网关)
- [用量徽标与 Token 用量](#用量徽标与-token-用量)
- [模型选择器里的活动徽标](#模型选择器里的活动徽标)
- [配置项](#配置项)
- [开发](#开发)

---

## 安装

该包尚未发布到 npm registry。提供两种安装方式。

### ⚠️ 从旧包名 `dsh-codearts-auth` 升级

本包在 `0.2.0-rc.11` 把包名从 `dsh-codearts-auth` 改成了 `dsh-providers-hub`。
**仓库里改完了不代表你的机器上改完了** —— DSH 是在 **profile** 里按**包名字符串**
寻址 bundle 的，而老 profile 两处都还写着旧名：

```jsonc
// ~/.dsh/profiles/<name>/package.json
{
  "dependencies": { "dsh-codearts-auth": "link:…" },   // ← 旧键
  "dsh": { "profile": { "bundles": [ …, "dsh-codearts-auth" ] } }  // ← 旧项
}
```

**两处必须一起改**，缺一处就是静默失效 —— 而且**「两处都不改」同样会坏**，
只是坏的位置不同：

| profile 里的状态 | 后果 |
|---|---|
| **两处都是旧名**（老 profile 的现状） | bundle 目录**解析得到**（`node_modules/dsh-codearts-auth` 这个旧名别名还在），但包里 patch 的加载行写的是**新包名**，而宿主把加载行的解析基准设成 **profile 目录** ⇒ 新名在那里解析不到（本机实测 `MODULE_NOT_FOUND`）⇒ **该加载行 import 失败** ⇒ 宿主报 `N entry did not activate`，桌面端落进恢复模式并把插件**自动禁用**（Jet Hub 界面自然也不出现，即 issue IKLUME 的症状） |
| **只改 `dependencies`** | `dsh.profile.bundles[]` 里的旧名在 profile 里解析不到 ⇒ `resolveBundleDir()` 抛错 ⇒ 该 bundle 进 `skippedBundles` ⇒ **整个插件（连宿主侧）都不加载**，只在 stderr 留一行：无异常、无 UI 提示 |
| **只改 `dsh.profile.bundles`** | 与上一格同因：`node_modules/` 里只有旧名，`bundles[]` 里的新名解析不到 ⇒ 同样进 `skippedBundles` |

> **实测**（本机 `~/.dsh/profiles/web`）：`require.resolve('dsh-codearts-auth/package.json')`
> 成功解析到仓库根，而 `require.resolve('dsh-providers-hub/package.json')` 报
> `MODULE_NOT_FOUND`。宿主把加载行的解析基准设成 **profile 目录**
> （`dsh-app-boot` 对 patch 行调 `prepareProfilePatches(…, pathToFileURL(dirname(absoluteConfigPath))…)`，
> 同一个值也是 `boot()` 里 `ctx.baseUrl` 的来源），所以「旧名能解析」与「新名解析不到」
> 会**同时**成立 —— 这正是第一格的判断依据是**按名字解析**、而不是「目录在不在」的原因。
>
> ⚠️ 第一格的落点**不在客户端**：宿主**不会**替用户把这种行摘掉 —— `preflight()`
> 只在「兼容性冲突」时 deny 一行，其余失败**保留 cordis Loader 自己的诊断**
> （源码注释：*every other failure keeps the Loader's own diagnosis*），于是该行走进
> Loader 并**在宿主这一侧导入失败**。所以排障的第一现场是宿主日志里的
> `N entry did not activate` 与「插件已被禁用」，不是「宿主一切照常、只是客户端
> entry 没建立」——后者会让排查方向整个偏到前端产物上去。

推荐做法是**不要手改**，直接用 `dsh plugin --profile <name>` 的 `remove` / `add`
各走一遍，让工具自己写这两处：

```sh
dsh plugin --profile <name> remove dsh-codearts-auth
dsh plugin --profile <name> add "https://gitee.com/iJetLi/deepseek-harness-codearts.git"
```

⚠️ `<name>` 要**逐个 profile 走一遍**：本机 `~/.dsh/profiles/` 下的 `desktop` /
`headless` / `tui` / `web` 四个 profile 的 `package.json` **都**还锁着旧名，且
`dsh.profile.bundles` 里也都有它。只有既无依赖项也无 `node_modules` 的 profile
（如 `default` / `rescue`）可以跳过。

⚠️ 老版本可能残留 `node_modules/dsh-codearts-auth` 与 `pnpm-lock.yaml` 里的同名
依赖项；`add` 之后确认 profile 里不再有旧名的依赖键。

### 方式一：从 git 仓库安装（推荐）

`add` 以 git 仓库方式安装（pnpm 内部走 `git+https:` 协议），会运行本包的 `prepare`
脚本自动构建 `lib/`，无需手动 `pnpm build`。

⚠️ `prepare` **不依赖任何包管理器**（它直接内联 `tsc` / `node`）：pnpm 在 clone
目录里跑 `prepare` 时，**pnpm 10 / 11 不会把 npm 注入 PATH**（只有 pnpm ≥ 12 会）
⇒ 若 `prepare` 里写 `npm run …`，那两代上安装会直接失败。

⚠️ pnpm 10 起会拦截依赖的构建脚本，必须先在 profile 的 `pnpm-workspace.yaml`
（路径形如 `~/.dsh/profiles/<name>/pnpm-workspace.yaml`）里放行；而**放行键的写法
在 pnpm 10 与 pnpm 11 之间互不兼容**，写错就装不上。

**1. 先跑一次安装**（这一次必然失败，为的是让 pnpm 打印它期望的键）：

```sh
dsh plugin --profile <name> add "https://gitee.com/iJetLi/deepseek-harness-codearts.git"
```

**2. 按第 1 步的报错选一种写法，写进 profile 的 `pnpm-workspace.yaml`。**

报 **`ERR_PNPM_INVALID_VERSION_UNION`** 的（**pnpm 10.x**）—— 只认**纯包名**键：

```yaml
allowBuilds:
  dsh-providers-hub: true
```

报 **`ERR_PNPM_GIT_DEP_PREPARE_NOT_ALLOWED`** 的（**pnpm 11.x**）—— git 托管包
**不认**纯包名键，必须用第 1 步 pnpm 打印的**完整键（含 `#<commit>`）**：

```yaml
allowBuilds:
  dsh-providers-hub@git+https://gitee.com/iJetLi/deepseek-harness-codearts.git#<第 1 步打印的 commit>: true
```

**两代通用（省事，但放宽了权限）**：

```yaml
dangerouslyAllowAllBuilds: true
```

它会放行该 profile 里**所有**依赖的构建脚本（不止本插件）。

**3. 重跑第 1 步的命令**：这次会拉取、构建并安装成功。之后每次升级重新 `add` 即可。

⚠️ **不要**写 `dsh-providers-hub@git+https://gitee.com/…`（不带 `#<commit>`）——
这个"看起来最自然"的键在两代 pnpm 上都不工作。

⚠️ pnpm 11.x 的精确键里带 commit，因此**升级（重新 `add` 拉到新 commit）后该键
失效**，按新报错里的键替换即可；用 `dangerouslyAllowAllBuilds` 则不必改。

### 方式二：从源码目录安装（本地开发）

先在本仓库中构建 `lib/`，再安装为 pnpm `link:` 依赖：

```sh
pnpm build:all
dsh plugin --profile <name> install <path-to-this-repo>
```

> `dsh plugin install` 以 `link:` 方式安装，pnpm 不会为 `link:` 依赖运行
> `prepare` 脚本，因此必须先手动执行 `pnpm build:all` 生成 `lib/`。
> 注意必须用 `build:all` 而非 `build`：后者只编译宿主侧，不产出
> `lib/client/jet-hub.js`。

每次修改 `src/` 或 `plugin-src/` 后都需要重新执行 `pnpm build:all` —— dsh 启动时
不会自动重建。

### 通用说明

该包声明了 `dsh.bundle` 补丁（`cordis.patch.yml`），因此 profile 的 layer 栈会
自动拾取 `codearts-auth` 行。插件注入由 dsh base 提供的 `credentials`、
`commands` 和 `llm` 服务。

---

## Windows 服务器部署（引导式 / 离线式）

`service.bat` 除了把程序注册成 Windows 服务外，还能打出两种部署产物：

| 模式 | 命令 | 体积 | 目标机要求 |
|---|---|---|---|
| **引导式**（推荐） | `package -Mode bootstrap` | **约 20 MB** | 能访问网络；首次执行 `install.cmd` 自动备好 Node 并下载依赖（约 730 MB） |
| 离线式 | `package -Mode standalone` | 约 800 MB | **无需 anything**：Node 与全部依赖都内置，可完全断网 |

两者都**不包含** profile 的账号与设置数据 —— 那部分用 Jet Hub 的「账号备份导入」恢复。

### 引导式产物（按需下载，约 20 MB）

```bat
service.bat package -Mode bootstrap
```

产物在 `dist\bootstrap\dsh-providers-hub-<版本>-win-x64\`，部署只需两条命令：

```bat
install.cmd     :: 下载 DSH 宿主依赖 + 组装 profile（首次 1-3 分钟）
start.cmd       :: 启动
```

产物结构：

```
dsh-providers-hub-<版本>-win-x64\
├─ MANIFEST.json          版本 / 依赖版本 / 关键文件 sha256
├─ README.txt             部署说明
├─ install.cmd / install.ps1   目标机安装（下载依赖 + 组装 profile）
├─ start.cmd / stop.cmd / stop.ps1
├─ service.bat            注册 Windows 服务（产物随附，目标机就地可跑）
├─ runtime\
│  ├─ service-runner.mjs  服务包装器
│  └─ node.exe            ← 仅 --with-node 打包时存在（含 npm，+130 MB）
├─ plugin\                插件本体（lib / locale / cordis.patch.yml / package.json）
│  └─ node_modules\       插件生产依赖（4 个包；--thin 时改为目标机下载）
└─ host\
   ├─ package.json        宿主依赖声明
   └─ package-lock.json   精确锁定 548 个包的版本与 integrity（install 用 npm ci）
```

`install.cmd` 做 8 件事：**备好 Node（缺则自动下载）** → 校验 npm → 从 lock 安装宿主依赖 →
**核验 peer 闭包**（`dsh` / `dsh-base` / `dsh-web-app` / `dsh-llm` / `cordis-plugin-loader`）→
建 profile 骨架 → 把插件拷进 profile → 核验 `.node` 是否当前平台 → 打印后续命令。

**Node 是怎么解决的**（三级回退，无需人工干预）：

1. 产物内 `runtime\node.exe`（用 `--with-node` 打包时才有）；
2. 系统 `PATH` 上的 `node.exe`；
3. **都没有 → 自动下载**官方 Node win-x64 zip（版本取打包机自身版本，约 35 MB，自带 npm），
   解压到产物 `runtime\`。之后 `start.cmd` 与 `service.bat` 都会自动用这份 Node，
   不再依赖系统 PATH。

> 下载源顺序：`-NodeMirror <基址>`（若给）→ `npmmirror.com` → `nodejs.org`。
> 内网无外网时用 `-SkipNodeDownload` 让它老实报错，或事先把 Node 装好。

可选参数：`install.cmd -Profile prod -Registry https://registry.npmmirror.com -Force -SkipVerify`、
`-NodeMirror https://npmmirror.com/mirrors/node -SkipNodeDownload -NodeVersion v24.13.0`。

需要产物自带 Node（目标机没装 Node）时：

```bat
node scripts\build-bootstrap.mjs --with-node
```

> ⚠️ **不能给 `npm install` 加 `--omit=peer`**：DSH 宿主的 peerDependencies 是它运行的一部分，
> 漏一个就 `ERR_MODULE_NOT_FOUND` 起不来。`install.ps1` 会在装完后显式核验这 5 个包。

### 离线式产物（完全自包含，约 800 MB）

目标机**不需要安装 Node / npm / pnpm，也无法联网**，解压即跑。

```bat
service.bat package -Mode standalone
```

产物落在 `dist\standalone\dsh-providers-hub-<版本>-win-x64\`，把它整个目录拷到服务器即可。
下面的目录结构说明针对离线式产物；引导式产物在 `install.cmd` 跑完后，`home\` 下的布局与它一致。

### 目录结构

```
dsh-providers-hub-<版本>-win-x64\
├─ MANIFEST.json          版本 / 依赖清单 / 原生二进制清单（可审计）
├─ README.txt             部署说明（目录结构、启动方式、限制）
├─ start.cmd              启动（前台，用内置 Node）
├─ stop.cmd / stop.ps1    停止
├─ service.bat            注册 Windows 服务（产物随附，目标机就地可跑）
├─ runtime\
│  ├─ node.exe            内置 Node 运行时（目标机无需装 Node）
│  └─ service-runner.mjs  服务包装器
└─ home\                  == DSH_HOME
   ├─ cordis.patch.yml    home 级 patch 层
   └─ profiles\
      ├─ node_modules\
      │  └─ @deepseek-ai\dsh\           DSH 宿主
      │     ├─ lib\  package.json
      │     └─ node_modules\            宿主依赖闭包（548 个包，真实目录）
      └─ prod\                          预置 profile（免 npm install）
         ├─ package.json                dsh.profile.bundles
         ├─ cordis.patch.yml
         └─ node_modules\
            └─ dsh-providers-hub\       本插件
               ├─ lib\  locale\  cordis.patch.yml
               └─ node_modules\          插件生产依赖（真实目录）
```

要点：

- **全部依赖以真实目录分发**（不是 junction），所以产物可以随意移动/复制，zip 也不会损坏。
  宿主启动时若发现链接失效会**自动重建**。
- **原生模块按 Windows 平台收录**（如 `@img/sharp-win32-x64`、
  `node-addon-require-builtin-win32-x64-msvc`），打包时逐个核验，缺失即中止。
- **预置 profile 里插件已就位**，目标机**不需要执行任何 `npm install` / `pnpm install`**，
  也不需要联网。
- 插件与宿主共用的依赖会做**去重**（按 semver 判定），避免同一模块出现两个实例。

### 启动

```bat
start.cmd
```

| 环境变量 | 默认 | 说明 |
|---|---|---|
| `DSH_PROFILE` | `prod` | profile 名 |
| `DSH_HOST` | `127.0.0.1` | Web UI 监听地址 |
| `DSH_PORT` | `8123` | Web UI 端口 |
| `DSH_OPENAI_GATEWAY_PORT` | `8326` | 本机 OpenAI 网关端口 |
| `DSH_OPENAI_GATEWAY_HOST` | `127.0.0.1` | 网关监听地址 |
| `DSH_OPENAI_GATEWAY_PUBLIC_URL` | 未设置 | 客户端应当使用的**对外地址**（网关前面有反代 / 端口映射时填，如 `http://192.168.1.10:8080/v1`）；设置页优先显示它。只接受 http(s)，不得带口令或查询串 |

Web UI：`http://<DSH_HOST>:<DSH_PORT>`；网关：`http://<网关地址>:<端口>/v1`。

⚠️ 不要把监听地址改成 `0.0.0.0` / `::` —— 宿主与网关都会在启动前**显式拒绝**并报错退出；
要给内网访问请填**具体网卡 IP**，并务必设置 `DSH_OPENAI_GATEWAY_API_KEY`。

注册成 Windows 服务（需管理员 + NSSM；两种产物根目录都已随附 `service.bat`）：

```bat
service.bat install -Mode standalone -BundleDir <产物目录> -Profile prod   :: 离线式
service.bat install -Mode bootstrap  -BundleDir <产物目录> -Profile prod   :: 引导式（先跑过 install.cmd）
```

> ⚠️ 2026-10-31 审计（P1）：新版 `service.bat` 检测到 `-BundleDir` 已是完整产物时
> **自动跳过打包**（打印一行提示），无需再加 `-NoPackage`；`-Force` 仍可强制重打包。
> 老版本（无自动检测的）必须显式加 `-NoPackage`，否则它会在目标机上尝试重新打包而失败。

> ⚠️ 账号登录仍需在浏览器里完成（Jet Hub 设置页）；无浏览器环境请用「账号备份与迁移」里的
> 导出/导入把账号搬过去。

---

## 用法

**登录入口：Jet Hub 设置页的对应 provider 面板。**

⚠️ **不注册任何斜杠命令** —— 登录、状态查看、续期与积分领取统一在 Jet Hub 完成。

基本流程：

1. 打开 Jet Hub（点主导航里的 **Jet Hub** 一行；也可从「设置 → 插件 → Jet Hub」
   进入 —— 两条路径渲染的是**同一个页面**）；
2. 点「**+ 新建账号**」→ 浏览器打开授权页 → 完成登录；
3. 需要多个账号时重复第 2 步（账号池会自动选号）；
4. 回到 dsh 的模型选择器，选中该渠道的模型即可开始对话。

### 「面板入口」：两个入口二选一

上面那两条进入路径是**互斥**的，只能保留一条。改法在**插件详情页**：
「设置 → 插件 → dsh-providers-hub」，页面里有一张设置卡，卡里一个「**面板入口**」
下拉：

| 选项 | 结果 |
|---|---|
| **仅侧栏**（默认） | 主导航里多一行「Jet Hub」；设置弹层里**没有** Jet Hub 那一节 |
| **仅设置页** | 只剩「设置 → 插件 → Jet Hub」；主导航那一行消失 |

⚠️ 默认是「仅侧栏」，所以**设置弹层里默认找不到 Jet Hub 一节**，这不是插件没装好。
想从设置里进，就把下拉切成「仅设置页」——切换后主导航那一行会消失。

偏好存在宿主侧而不是浏览器存储，重启后保持 —— 理由见 `docs/agent-notes/client-ui.md`。

「+ 新建账号」是**两步式**的：先返回 `loginUrl` 由前端弹窗打开，后台再轮询换取
令牌 —— 这样不会阻塞浏览器手势窗口，弹窗不会被拦截。

### 登录授权页：自动打开 / 复制链接

**Jet Hub → 设置 →「登录授权」**有一个开关，默认**开**：

| 开关 | 「+ 新建账号」时 |
|---|---|
| **开**（默认） | 自动打开授权页（= 本功能上线前的行为） |
| **关** | **不自动开窗**；授权链接复制到剪贴板，并显示在账号面板里（链接旁有「复制链接」按钮），由你手动粘贴到浏览器打开 |

- 关闭后**宿主也不再自动拉起** CodeArts / OfficeAce 的**无痕窗口**（这两家的授权页在
  华为云 SSO 域，普通窗口可能复用上一个账号的登录态 ⇒ 建议手动在**无痕 / 隐私窗口**打开）。
- 通过插件自己接管浏览器读取登录态的渠道（豆包 / 百智云 / 超级麦吉 / MonkeyCode /
  Marvis）**没有**可复制的授权链接 —— 它们**不受**这个开关影响。
- 偏好落在宿主侧（`$DSH_HOME/jet-hub/login-preferences.json`），重启后保持；设置页改完
  立即生效（不需要重启）。
- ⚠️ 若「设置 → 插件」里的客户端已更新、而宿主进程仍是旧代码，开关会显示
  「读取 / 保存失败（宿主可能仍在运行旧代码）」—— 完全退出并重新打开 DSH 即可。

账号卡片支持：**测试 / 重测 / 重置 / 停用 / 代理 / 指纹 / 删除**，以及拖拽排序
（**顺序即选号优先级**）。停用只影响自动选号，**不影响凭据续期与积分领取**。

> **ZCode 例外**：`zcode` 多账号默认按 DSH 的 `sessionId` 做会话亲和 —— 同一会话
> **优先**落到同一账号、不同会话分散到不同账号；**没有 `sessionId` 的请求**（例如本机
> OpenAI 网关的一次性调用）每次随机选号。其余 provider 仍按上面的手动顺序优先。
>
> ⚠️ **但「手动顺序优先」对走余额分档的 14 家渠道默认不成立**：它们先按积分到期
> 档位排序、档内才看拖拽顺序（这就是「拖拽时灵时不灵」的由来）。面板对这些渠道
> 渲染「**严格手动顺序**」开关，打开后拖拽序才是唯一优先级（锁定永久积分时
> 只剩永久积分的号仍会被跳过）；开关按渠道独立保存，默认关 = 升级前行为。
>
> ⚠️ 这个「优先」有例外，**不是**「整个会话永远固定在一个账号上」：账号的**今日
> 请求数达到阈值**（默认 300）后会被沉底 ⇒ **新会话**绕开它；而一个**正在跑的长
> 会话**，一旦它所在的账号越阈，**下一次请求会迁移**到别的账号 —— 这是把「一个长
> 会话独占一个号」（本机实测单号占当日 71.6%、max/mean 4.3）摊开的唯一手段，代价是
> 这次迁移会让上游输入缓存失效一次。阈值可用
> `DSH_ZCODE_SESSION_BALANCE_OVERFLOW_REQUESTS` 调整（`0` = 关闭溢出，纯哈希亲和）。

⚠️ 「**代理**」按钮目前只对 `opencode` 与 `gemini` 渲染（两者语义不同，见
「出不去墙外服务」一节）；其余渠道的账号卡片上没有这个按钮。

---

## 支持的渠道

29 个 provider 路由（按协议源流分组排序），互不覆盖，可同时使用。

| id | 渠道 | 登录方式 | 积分能力 |
|---|---|---|---|
| `codearts` | CodeArts（华为云） | 浏览器回调 | 余额 + 每日签到 |
| `buddy` | CodeBuddy（腾讯） | 浏览器授权 + 轮询 | 余额 + 每日签到 + 成长任务 + 锁定永久积分 |
| `workbuddy` | WorkBuddy（国际版） | 同上 | 余额 + 每日签到（含活跃上报）+ 锁定永久积分 |
| `marvis` | 腾讯 Marvis（应用宝 AI 助手） | QQ / 微信 OAuth（隔离窗口 + 回调拦截） | 余额（钱包额度；**无签到**） |
| `lobsterai` | LobsterAI（有道） | 浏览器回调 | 余额 + 每日签到 |
| `qoder` | Qoder（阿里系） | 设备码轮询 | 余额 + 每日领取 + **个人资源包逐笔到期**（可选：粘贴网页会话 Cookie 后读官网明细） |
| `qodercn` | Qoder 中国版 | 同上（共用实现） | 同上 |
| `trae` | TRAE（字节跳动） | 浏览器回调 | 余额 + 签到 |
| `cline` | Cline | WorkOS 设备码轮询 | 余额 |
| `loomy` | Loomy（讯飞） | 短信验证码 | 余额（两个池）+ 每日额度 + 新手任务 |
| `astudio` | AStudio（讯飞） | 本机导入 / 认证页扫码 | 余额 + 每日签到（含积分包 / 永久锁定） |
| `raccoon` | Raccoon Work（商汤） | 微信扫码 / 短信 | 余额 + 每日签到 + 一次性登录奖励 |
| `magicrew` | 超级麦吉 | 本机浏览器导入 / 网页版登录 / 手机号+密码 | 余额 + 每日签到 + 新手任务 |
| `magicrewintl` | MagiCrew（国际版） | 同上（共用实现） | 余额 + 每日签到 + 新手任务 |
| `minimax` | MiniMax Code (中国版) | OAuth 设备码 + PKCE | 余额 + 每日签到 |
| `minimaxintl` | MiniMax Code (国际版) | 同上（共用实现） | 余额 + 每日签到 |
| `zcode` | ZCode（智谱 z.ai） | OAuth 设备码 | 余额 + 每日领取（含**营销活动**投放，如 1024 程序员节 5 亿 token） |
| `autoclaw` | AutoClaw（智谱） | 一键导入本机桌面端 / 手机验证码 | 余额 + 每日签到（含积分包 / 永久锁定） |
| `autoclawintl` | AutoClaw（国际版） | 同上（读国际版 userData 目录） | 余额 + 每日签到（含积分包 / 永久锁定） |
| `opencode` | OpenCode | — | 余额 |
| `gemini` | Gemini Code Assist | 浏览器回调 | 余额 |
| `officeace` | OfficeAce（华为 MaaS / 果办） | 华为云 OAuth PKCE | 余额 + 自动领取（**无手动签到入口**） |
| `accio` | Accio（阿里） | 浏览器回调 | 余额（三类桶；**无签到**） |
| `modelscope` | ModelScope（魔搭） | 粘贴 API Key（长期静态 Key） | 魔粒余额 + 每日登录奖励（可关闭自动签到） |
| `qiniu` | Qiniu（七牛云） | 粘贴 API Key | **无**（用量只在控制台可见） |
| `codely` | Codely（Unity 团结引擎） | 设备码轮询 | 余额 + 每日签到 |
| `monkeycode` | MonkeyCode | 浏览器登录（备用：粘贴 Key + Signing Secret） | 余额 + 每日签到 |
| `monkeycodeintl` | MonkeyCode 国际站 | 同上（共用实现） | 余额 + 每日签到 |
| `baizhi` | 百智云 | 浏览器登录（备用：粘贴 Key） | 余额 + 每日签到 |
| `agnescode` | AgnesCode | 导入本机桌面客户端登录态（Windows DPAPI） | 余额（订阅积分池；**无签到**） |
| `agnescodeintl` | AgnesCode（国际版） | 同上（共用实现，`*.agnes-ai.com`） | 余额（订阅积分池；**无签到**） |

各渠道的能力与限制要点：

- **图片输入**：`buddy` / `workbuddy` / `trae`（逐模型）/ `minimax` / `minimaxintl`（部分模型）/
  `accio`（逐模型）支持；`lobsterai`、`zcode` **不支持**；其余以模型声明为准。
  ⚠️ `accio` 的图片通路**已于 2026-10-14 实测接通**（issue IKLR7V，上游原生收图
  `parts[].inline_data`，四色全对）；但它的 `multimodal: false` 模型**不报错、而是静默
  忽略图片**（会把答案**幻觉**出来），插件因此按**逐模型**声明模态（`false` 写 `['text']`），
  把这类模型挡在选择器之外。
- **思考档位**：多数渠道支持，档位名按各渠道自己的定义下发；未声明的渠道不发送该字段。
- **`trae` 前缀缓存**：2026-10-26 起实测 `cache_read_input_tokens` 恒为 0（同前缀
  连发两次、对照组 buddy 97.6%），插件侧请求形态无变化，判断为上游服务端变更。
  影响是长上下文会话每一步都全量重算（实测单步可达数分钟），**不建议**把 `trae`
  当长跑主力；目前**未找到**客户端修复：2026-11-03 e2e 已用原始 SSE 证实上游返回 0，且 `prompt_cache_key` 实测无效。
- **`qoder` 多账号同机**：上游有**物理单设备每日限领锁** —— 同一台机器上第一个
  账号领完后，其余账号会收到 `SAME_PERSON_ALREADY_CLAIMED`（插件显示「同一设备
  今日已由其它 Qoder 账号领取」）。这不是登录失效，重登也无法绕过；多账号请分设备。
- **`loomy`** 是唯一用**短信验证码**登录、且**不能自动续期**的渠道。
- **`zcode`** 的领取路径需要一次性验证参数，由本机浏览器环境产出（web 版需要
  chromium，桌面版用自带内核）。
  ⚠️ 这正是它被登记进 `PROVIDER_REGISTRY.autoCheckinExcluded`（**默认不参加
  自动签到**）的原因：否则用户什么都没点、每天开着 DSH 就起一棵浏览器进程树，
  并按**设备**烧阿里云验证码配额（同设备每小时 150 次）。想让它自动领取请在
  「渠道管理 → ZCode」拨开「ZCode 自动签到」（opt-in，默认关）。
  ⚠ **推理（对话）路径是否也要它，由服务端开关决定**：官方 3.14.5 起
  `GET /api/v1/client/configs` 会下发 `captcha.skip_model_request`
  —— 当前实测是 `true`（**不校验**，故按最省的方式「先探后取」：
  不带验证头先发一发，被 `3007` 拒了才产）；一旦服务端翻成 `false`，
  插件会**自动改为首发直接带上**，不再白吃那发注定失败的往返
  （判据是三态：缺席 = 不知道 = 保持先探，见 `requiresCaptchaUpfront`）。
  ⚠️ **找不到浏览器时用 `ZCODE_CHROME_PATH` 指定**（Gitee issue IKQ4JN）：
  这是该链路**唯一**的人工出口，值是 chromium 内核浏览器的**绝对路径**
  （如 `C:\Program Files\Google\Chrome\Application\chrome.exe`）。
  候选链按优先级为 `ZCODE_CHROME_PATH` → `SCOOP` / `SCOOP_GLOBAL` →
  **从 `PATH` 反推的 scoop 根** → `~/scoop` → 系统 Chrome / Chromium /
  **Brave** / Edge。
  ⚠️ **设完必须重启 `dsh web`，且新进程要继承新环境** —— 从**旧终端**重启时
  新进程继承的仍是旧 shell 的环境快照，变量实际为空。找不到浏览器时的报错
  会回显「本进程看到的 `ZCODE_CHROME_PATH` = …」与**逐条候选路径**，
  照着它能立刻分清「变量没生效」与「路径写错」。
  ⚠️ **scoop 装在非默认根时不必设变量**：从 `PATH` 的 `<root>\shims` 反推
  已覆盖（用 `root_path` 把 scoop 挪到 D 盘的机器上 `SCOOP` 是空的，
  旧版因此一个 chromium 都找不到）。
  ⚠️ **不支持两类「看着能用」的封装**：Chrome++ 之类**外层 exe 启动后自行退出**
  （CDP 端口会正常起来，但退出码 0 被判为异常退出）；以及
  `chrome-headless-shell`（headless 一律 `F001`，必须 headful）。
- **`zcode` 的领取有「两个来源」，签到会同时查、一起去领**（2026-10-23）：
  ① 每日赠送 —— `GET /api/v1/zcode-plan/billing/preview` 的 `plans`；
  ② **营销活动投放** —— `GET /api/v1/marketing/touch` 里横幅按钮的
  `claim_zcode_plan`。后者就是官方客户端那类「限时可领取」横幅（如
  **1024 程序员节 5 亿 token**），它**不在** `preview` 里 —— 只查 preview 时
  它与「今天没有活动」在报文上**完全同形**（都是 `plans: []`）。
  ⚠️ **营销端点与领取端点都按客户端版本门控**：插件凭据里记的是自己的版本号
  （如 `3.14.3`）；用它查投放会拿到**空投放**，用它**领取**则回
  `400 / code 1004 no permission`（官方文案：「当前账号或**客户端版本**不满足
  领取条件」—— 极易被误读成「这个账号没资格」）。两条请求都会**按需抬到
  `3.16.3`**（`ZCODE_VERSION_GATED_MIN_APP_VERSION`；实测同一账号、其余头完全相同，
  只改这一个字段：查投放 `3.14.3` → `deliveries: []` / `3.16.3` → 有投放；
  领取 `3.14.3` → `1004` / `3.16.2` → `code 0`）。该覆盖**只作用于这两条请求**，
  不影响推理与额度两条已实测路径。
  ✅ **真机验收**（2026-10-23，走插件自己的生产路径）：`{"kind":"claimed",
  "credit":500000000,"unit":"token"}` —— 5 亿 token 领取成功。
  ⚠️ **「领取成功但额度仍是 0」是正常的**：活动的 `effective_at` 是 **23:00**
  （UTC+8），而额度桶要等那个时刻才建（上游 `plans[].status:"active"` 里
  额度已锁定，`balances` 仍是空的）。插件会把它单独显示成一个
  「**待生效**」的包并带出生效时刻，**不并进当前可用额度** ——
  并进去会让折算层在生效前就把 zcode 派发出去（必然失败）。
  ⚠️ **国际版（`zai`）账号同样能领到**（2026-10-23 实测：4 个账号含 2 个
  国际版都拿到同一个 1024 计划）⇒ 服务端**不按 OAuth 渠道区分**；
  「只有中国版有」是官方客户端**奖励中心分站**（`/cn/rewards` vs `/en/rewards`）
  造成的**入口**差异，插件不做渠道特判。
  ⚠️ 领取成功后插件会回报一次 `POST /marketing/touch/action`（`confirm`），
  否则服务端会**反复投放同一个活动** ⇒ 每轮签到白烧一个验证参数
  （阿里云验证是**设备级**配额）。失败时**绝不**回报 —— 那会让用户白丢一次机会。
- **`qiniu`（七牛云 AI）** 登录方式是**粘贴 API Key**（无浏览器、无需回调）：
  在面板点「+ 新建账号」，把 `portal.qiniu.com/ai-inference/api-key` 创建的 Key 贴进去即可
  （至少 16 位、无空白）。Key **长期有效、不需要续期**，同一条 Key 重复添加会**复用**
  同一个账号（不会平白多出一个额度桶）。
  ⚠️ **面板不显示余额，也没有签到按钮** —— 七牛云 AI 的用量与计费只在它的 web 控制台
  可见，没有可调用的余额接口。这不是「还没做」，是上游确实没有。
  ⚠️ 它的**模型 id 由平台动态下发**（形如 `deepseek-v3` 与 `moonshotai/kimi-k3` 两种写法
  混排），插件**原样透传**、不做任何改写 —— 手填模型 id 时必须与七牛云模型广场的
  「API model 参数」**逐字一致**，多写斜杠或少写斜杠都会 404。
  ⚠️ **图片输入与思考档位都未声明**：VL 系模型确实在目录里，但七牛云侧**未做读图实测**，
  插件按「不支持」处理（宁可挡住也不让模型对着图片编答案）；思考档位同理 —— 上游支持
  `low|medium|high` 但目录不下发每个模型的支持情况，故不显示档位选择器。
  ⚠️ 额度耗尽后的冷却**对齐 UTC+8 当日 24:00**（七牛的额度按自然日重置），不会把账号
  锁满 24 小时。
- **`qoder` / `qodercn`** 共用同一套实现，差异仅在产品配置。
- **`minimax` / `minimaxintl`** 共用同一套实现（**唯一**的 Anthropic Messages
  协议族渠道），差异仅在产品配置。⚠️ 两站的**账号不互通、API 主机也不同**，
  故它们是**两个独立面板** —— 各自在自己的面板里点「+ 新建账号」即可，
  **无需选择站点**（`minimax` → `agent.minimax.cn`，`minimaxintl` → `agent.minimax.io`）。
  ✅ **国际版已完成真机验证**（2026-10-15）：登录、账号管理、模型目录、**推理**、
  **每日签到**、**积分查询**全部实测可用 —— 与国内站**协议同形**（认证同样只需
  `Authorization: Bearer`）。核验入口见 `tests/e2e/README.md` 的
  `test:e2e:minimaxintl`。
  ⚠️ 国际站的**目录端点当前是公开的**（无 token、垃圾 token 都 200）⇒
  「能看到模型列表」**不代表**凭据有效（凭据证据看签到 / 积分 / 推理）。
  ⚠️ 若国际站各端点**同时**报 `token is required` / `invalid signature`，
  请先怀疑**上游故障**而不是配置 —— 此时**官方 mcode 客户端也会同样失败**。
- **`gemini`（必须过墙，见「出不去墙外服务」一节）**：Google 的登录与接口全部
  在墙外。⚠️ 症状极具误导性：**浏览器能打开授权页并点「同意」，面板里账号却一直
  不出现** —— 因为**浏览器读系统代理、插件进程不读**。这不是 `client_secret` 或
  `redirect_uri` 配错（那个 bug 已被修掉，token 端点强制校验客户端身份）。
- **`accio`** 登录走浏览器回调。⚠️ **新建账号时必须先选登录区域**（中国版  `www.accio-ai.com` / 国际版 `zh.accio.com`）：两个区域的**登录页域名不同**，
  而区域由服务端按账号下发、**登录前无法自动判断** ⇒ 选错会打开打不开的登录页，
  **登录不会成功**。区域会写进凭据，续期与推理按它选域名。
  ⚠️ **它没有签到按钮** —— 每日积分由服务端在**登录时**发放（24 小时有效、
  **不累积**，未登录的那天不补），没有可调用的领取接口。面板上的积分按服务端下发的
  **三类桶**（每日 / 每月 / 推荐）分列显示，并给出每日额度的重置倒计时。
  ⚠️ **「刷新每日额度」入口尚未实现**：它本质是**重新登录既有账号**，
  需要宿主侧新增一条 RPC（现有的「+ 新建账号」每次都会新造账号，拿它重登只会
  多出一个空账号而原账号额度不变）。**当前要刷新请删除该账号后重新登录一次。**
  ⚠️ 模型**倍率跨度极大**（0.013 ~ 2.8，**215 倍**），故倍率直接写进模型展示名
  （`模型名 · x倍率`），选型时看名字即可。
  ⚠️ **图片输入未实测**，面板会明确报「暂不支持图片输入」而不是静默丢掉。
  ⚠️ **该渠道不产生限流标记**（也不会被限流探针测出东西），故「重测 / 重置」这组
  按钮对它**整组不渲染** —— 渲染出来只会是点不动的死控件。
- **`doubao`（豆包 / 字节）**：粘一次浏览器 Cookie 即可登录；每日签到、额度查询与文本对话
  全部走纯 HTTP，**不需要本机浏览器**。
  登录：在已登录 `www.doubao.com` 的浏览器里复制整段 Cookie 头（`Cookie:` 前缀可有可无，
  整条「复制为 cURL」也认），粘进面板的「粘贴 Cookie」框。`sessionid` 必填；重复粘同一账号
  会按 sessionid 刷新原卡，不会挤成两张。
  ⚠️ 扫码登录已移除：passport 在扫码成功那一刻要求页面 SDK 现场算 `sign` / `qs` / `a_bogus`
  （绑定当次 query），纯 HTTP 复刻不出来。
  签到：`a_bogus` 由**随包内置**的官方 bdms SDK 在 `node:vm` 沙箱里生成
  （`src/assets/doubao-bdms-sdk.<hash>.js`，装载前逐字节校验 sha256，运行时零下载），
  所以容器 / 无桌面服务器也能签到。
  ⚠️ 签到**进每日自动链**（面板「豆包自动签到」那格，`doubaoCheckinEnabled()` 默认 `true`）。
  2026-11-26 零浏览器化之后签到就是一条 POST（沙箱签名 + 直连），不再起浏览器进程树
  ⇒ 自动跑不再有「用户只看到没到账、看不到原因」的代价。想手动控制请在面板关掉那格。
  ⚠️ `PROVIDER_REGISTRY` 里**刻意不写** `autoCheckinExcluded`（见 `provider-registry.ts:1166` 的注释）——
  这正是「默认进链」的实现方式，不是漏写。
  额度：读 `POST /alice/commerce/sale/subscription/overview/`（面板同款接口），
  金额是带千分位的字符串（`"4,003"`）、到期时间是毫秒；分类总额只在
  「总额 − 已用 == 剩余」算术自洽时采用，否则明确标 `totalKnown: false`，不编分母。
  ⚠️ 设备身份由 `accountKey`（= `sessionid`）**确定性派生**出 19 位数字设备号
  ⇒ 多账号各自独立，不共享「每设备每天一次」的签到配额。

### 限流中断后自动继续

号池里某个模型的号全被限流时，providers-hub 会把这一轮以「可用账号均在限流中，
最近一个将于 … 解禁」收尾。过去这一步只能由人**在解禁后补一句「继续」**，而解禁
常在几十分钟到几小时后 —— 插件现在替你等：

- **报错行行尾的图标按钮**（两态互切）：黄色延时 = 解禁后自动继续 / 红色叉 =
  不自动继续。只在这个会话**确实挂着**待续跑记录时出现。
- **Jet Hub → 设置 → 「限流续跑」**：总开关（默认开，只影响**之后**的中断）、当前
  挂着的记录列表，以及每条记录上的「**立即继续**」（不想等、或宿主刚重启时用）与
  「移除」。
- **跨宿主重启**：待续跑记录写在 `$DSH_HOME/jet-hub/rate-limit-resume.json`，
  重启后接着等。⚠️ 解禁时刻到来时若那个会话**不在内存**（没打开过），钩子**不会
  被丢弃** —— 它会按 2 分钟间隔重试，并在你**打开那个会话**的瞬间立刻补发。
- **谁会撤掉等待**：你亲手在**该会话**里发消息、或该会话开了新回合（含正常收尾）。
  插件注入的上下文（`runtime-context` / 记忆 / 技能目录等）**不算**你发言。

自动续跑投出的是一条**带自有来源标识**的普通消息（不是伪造的人类输入，因此
`tool-goal` 那类「必须有人类授权」的动作不会被它冒用），正文写的是「上一轮因限流
被中断，现在已解禁，接着推进、不要重复已完成的部分」。解禁时刻按三条来源取最早
的一条：服务端 `providerRetryAfterMs` → 失败文案里的「将于 … 解禁」→ 号池里该
模型的限流标记；三条都没有才退到「1 小时后」。

```text
DSH_RATE_LIMIT_RESUME=0     # 关掉整个功能（等价于设置页里那个总开关）
```

### 一键领取积分

在对应面板标题栏点「**一键领取积分**」，插件会**顺序**处理该面板下的所有账号
（顺序执行以避免并发请求），并**逐账号显示结果与原因**。

⚠️ 汇总**按单位分列**，不跨量纲求和 —— `ZCode` 的额度单位是 **token**、其余渠道是
**积分**，两者不可折算，因此显示成 `+100.00MToken, +100积分` 而不是加成一个数。

魔搭默认参与全局自动签到。可在「渠道管理 → ModelScope（魔搭）」单独关闭魔搭自动签到，
保存后从下一轮调度起生效，手动领取仍可用。该功能通过网页登录触发发放，
使用前请查看[魔搭社区用户协议](https://modelscope.cn/protocol/用户协议)。
面板展示可用魔粒余额及日奖励批次的实际到期时间。根据[魔粒体系说明](https://modelscope.cn/docs/magicube/intro)，
短期魔粒有效 24 小时，长期魔粒有效 90 天，均按发放时间起算。

ZCode 与魔搭**相反**：默认**不**参加全局自动签到。可在「渠道管理 → ZCode」拨开
「**ZCode 自动签到**」（opt-in，默认关），打开后它跟随全局签到时间自动领取。
⚠️ 打开的代价由本机支付：领取会拉起浏览器完成阿里云验证，该验证按**设备**限流
（同设备每小时 150 次），且同一个时段失败后不再重试（下个时段再来）。关闭时
手动「一键领取积分」照常可用。


### 模型列表开关

每个 provider 的面板都有「**显示列表**」按钮，可逐个开关模型，控制它是否出现在
对话框的模型选择器里（**黑名单制**，默认全部显示）。开关按 provider 隔离。

### 锁定永久积分

`buddy` / `workbuddy` / `loomy` 提供「**锁定永久积分**」按钮，用来保住不会马上
作废的积分。判定规则：距扣费截止不足 15 天的算**临时**（优先消耗），其余算永久。
锁定后只消耗临时积分，用完则明确报错而不是偷偷烧掉永久积分。

### 出不去墙外服务（`gemini`，以及任何需要代理的环境）

`gemini` 是本插件里**必须过墙**的渠道：令牌端点（`oauth2.googleapis.com/token`）、
userinfo、Cloud Code 的配额与推理端点（`cloudcode-pa.googleapis.com`）全部在墙外。

**典型症状**：浏览器**能**打开授权页并点「同意」，回到面板却一直失败、账号列表里
始终没有这个号；或账号在、但积分与对话全部失败。

**为什么浏览器能用、插件不能用**：浏览器读 **Windows 系统代理（WinINET）**，
而插件跑在 Node 的 `fetch`（undici）上，它**既不读系统代理、也不读
`HTTP(S)_PROXY`**。这条差异是全部症状的根源。

#### 两种配法（任选其一）

**① 给单个账号配出口代理（推荐）**

在 Gemini 面板的账号卡片上点「**代理**」→ 填地址（`http://127.0.0.1:7897` /
`socks5://…` / 带认证的 `http://user:pass@host:port`）→「测试连接」→ 保存。

- 「测试连接」**打的是 Google 自己的端点**（不是通用的出口 IP 查询服务）：
  代理能通 `ip-api` 却被 Google 拒的情况很常见，用后者会产生**假阳性**。
- 配好后该账号的**登录、续期、积分、对话**全部走这条出口，且**每个账号可以
  配不同的代理**。
- ⚠️ 该配置只作用于 Gemini（与 `opencode` 的「代理」是**两份独立配置**，
  清掉互不影响）。

**② 启动 dsh 之前导出环境变量**

```powershell
# PowerShell
$env:HTTPS_PROXY = 'http://127.0.0.1:7897'
$env:HTTP_PROXY  = 'http://127.0.0.1:7897'
$env:NO_PROXY    = 'localhost,127.0.0.1,::1'
dsh
```

⚠️ **必须「导出为环境变量」**。只打开系统代理开关（Windows 设置里的「使用代理
服务器」）**无效** —— 那正是浏览器能用、插件不能用的原因。

宿主 dsh 会在**第一个插件加载前**装一个全局代理分发器，所以这种配法对**插件的全部
请求**生效（不只 Gemini），也**不需要**额外设置 `NODE_USE_ENV_PROXY`。

#### Node 版本差异（2026-10-18 本机实测）

若走 ①（账号代理）不受此表影响 —— 它走插件自己的分发器，与 Node 版本无关。
下表说的是「裸 `fetch` 读环境变量」那条路：

| Node | 仅设 `HTTPS_PROXY` | 再加 `NODE_USE_ENV_PROXY=1` |
|---|---|---|
| 22.19 | ❌ 不读 | ❌ 不读 |
| 24.21 | ❌ 不读 | ⚠️ 读，但失败后会反复重试，界面长时间无响应 |
| 26.10 | ❌ 不读 | ✅ 可用 |

⇒ **结论**：这条「绕过」的路只在较新的 Node 上干净。优先用 ①。

#### 报错文案

连不上时，插件会明确提示「疑似需要代理」并带上根因码（如
`UND_ERR_CONNECT_TIMEOUT`），登录失败、续期失败、积分查询失败与对话失败四条腿
都会给同一句指路文案 —— 不再是一句无信息量的 `fetch failed`。

⚠️ 代理恢复后**无需重登**：凭据没被标成失效，后台续期会照常在下一轮把它接上。

---

## 聚合路由（`aggregate`）

同一个真实模型往往在**多个渠道**都能用（例如 DeepSeek V4.1 Flash 在 buddy、
codearts、cline 等都有）。聚合路由把「同一个真实模型」在各渠道的条目**归到一个
规范名下**，请求时自动挑一个渠道发出去。

**解决什么**：各家渠道送的免费额度**有到期时间**，用不完就作废。聚合层按
「**最快作废的额度优先用**」自动排序，把临期积分先烧掉。

**怎么用**：

1. 在模型选择器里选 **`aggregate`** 分组；
2. 想**不挑模型**就选该分组下的 **`auto`** —— 它用**所有参与轮换的渠道**的全部模型当
   候选池（哪些渠道参与见下面「参与轮换的渠道」）；
3. 想**指定模型**就选该分组下的**具体规范名**（如 `Deepseek-V4.1-Flash`）。

选中后模型名旁会附一个 **`· <渠道>`** 后缀，那是**首选渠道**（临期最早的那个）。
⚠️ 它**不是「本次实际发往的渠道」** —— 真实历史由**用量徽标**显示。

**自动切换**：某个渠道失败时会换下一个候选重试，但只在**还没吐出任何可见内容**
时才切换（已输出的内容收不回来，拼接会产生畸形回答）。

**参与轮换的渠道**：`buddy` / `workbuddy` / `loomy` / `codearts` / `zcode` /
`lobsterai` / `trae` / `accio` / `officeace` 九家。其余渠道**暂不参与**（插件对
它们的额度到期时刻没有可靠信息，宁可少一个候选，不可把未知当可用）—— 它们仍可
**直连**正常使用。

⚠️ **真正决定「某渠道在不在轮换里」的是一张编译期清单**
（`src/aggregate-expiry.ts` 的 `WIRED_EXPIRY_PROVIDERS`），**不是**
`src/aggregate-adapter.ts` 的 `AGGREGATE_CHANNELS`。上面这份名单就是按前者列的。
只加 `AGGREGATE_CHANNELS` 是**无效接线**，且症状**完全静默**（零报错、零日志）。
后果分两种，别只记住第一种：

| 该渠道的模型 | 会发生什么 |
|---|---|
| 与已接入渠道**共用规范名** | 它的候选**出现在聚合面板里**，但**默认不参与轮换**（标着「无临期积分 · 未参与」）⇒ 需要你**逐条手工打开** |
| 是**独有**模型 | 虚拟模型**也在目录里**（可被选中），同样默认不参与轮换、可逐条手工打开 |

⚠️ 上面第二行是 **2026-10-15 的行为变更**：升级前这类模型会被过滤掉、**连聚合目录都进不去**，
于是「手工打开候选」之后你在模型选择器里**仍然看不到它**（打开白做）。
现在改为**目录身份与你的开关无关**：模型始终在目录里，参不参与由每条候选自己的状态决定。
若你选了一个「没有任何候选在轮换」的模型，报错会**如实**告诉你这一点（并给出面板路径），
而不是把它藏起来。

（真正拦下**轮换候选**的是 `src/aggregate-expiry.ts` 里那句「未接入 ⇒ `UNUSABLE`」
短路，**不是**适配器自己那几处过滤 —— 后者管的是面板与元数据面。）

### Qoder 的例外：个人资源包能算出逐笔到期

`qoder` / `qodercn` 的**套餐额度**仍然没有到期时刻，但**个人资源包**（`addOnQuota`）
在 2026-11-14 之后有两条可得来源：

1. **官网明细**（首选，精确）：在设置页对应账号上点「会话」，粘贴一次官网
   `https://qoder.com/account/usage` 的 `Cookie`（或整条「复制为 cURL」）。插件会用
   它读 `/api/v2/me/usages/big_model_credits`，按 `expires_at` 逐笔拆出到期日。
   ⚠️ 这个 Cookie **能登录你的官网账号** ⇒ 只存在本机凭据库的独立条目
   （`<credentialRef>_web`，删账号时一并清理），**不下发客户端、不写日志**。
2. **领取记录推算**（兜底，近似）：每日领取成功时把「这一笔多少、什么时候到期」记下来，
   下次按「先到期先扣」推算。推算出来的包会标注**「按领取记录推算」**。

两条都没有时，那一整包仍显示**「到期未知」**（不是「永久」）—— 这是 Issue IKTLMX
定下的红线：**未知不许渲染成永久**。

### 没有临期信息的渠道：默认不参与，可逐条打开

对那 7 家**没有可靠到期时刻**的渠道（`qoder` / `qodercn` / `cline` / `raccoon` /
`minimax` / `gemini` / `opencode`），2026-10-15 起你可以在聚合面板里**逐条手工打开**
它们的候选，打开后它们**真的参与轮换**（排在所有能算出临期的候选**之后** ——
它们之间没有可比较的到期时间，那种混合顺序是**正常**的，不是缺陷）。

- **默认态是「不参与」**：插件对它们的配额一无所知，默认放行会把失败留给你；
- 顶部有 **「拒绝非临期」** 一键按钮，把所有没有临期折算的渠道**恢复成默认不参与**
  （已接入的九家**不受影响** —— 它们的手工打开是有意义的）；
- ⚠️ **没有「一键全部放行」**：配额未知的渠道被批量放行会把失败留给你，
  故只提供逐条打开 + 一键恢复默认这一对操作。

⚠️ 同一个账号的额度到期信息**不会因为手工打开而变得可知** —— 打开只是允许插件去**尝试**它。

### 候选顺序：按临期排序 / 按手工排序

面板顶部有一个两段式开关：

| 模式 | 意思 | 会自动刷新吗 |
|---|---|---|
| **排序：按临期** | 按「积分最快作废」的顺序（默认） | ✅ 面板打开期间**每 2 分钟**自动重查一次；该模式也是探测按钮，点它立即重查 |
| **排序：按手工** | 按你拖出来的顺序 | ❌ 不自动重查（顺序由你决定） |

- 两种顺序**分别保存**：切到手工拖好、再切回临期，切回手工时你排的顺序**还在**；
- 手工模式下可**拖动**候选调整顺序（鼠标拖动手柄，**松手即保存** —— 不需要再点按钮）；
- 手工序是**严格序**：你拖过的候选排在**全部**没拖过的之前，**即使它临期更晚** ——
  否则你的拖动会被临期值静默覆盖；
- 没拖过的候选按「临期 ↑ → 倍率 ↑」追加在**后面**（新增的候选因此不会消失）。

⚠️ **「按临期」不是后台常驻定时刷新**：它只在**面板打开且处于该模式**时每 2 分钟查一次
（且标签页在后台时跳过）。关掉面板就不再查询 —— 插件没有为「排序展示」常驻的定时器。
若你在渠道侧改了配置想立刻看到，点一次「排序：按临期」即可。

同类陷阱已**多次**发生（`cline` 只进过 `AGGREGATE_CHANNELS`、**从未**进过白名单；
`accio`、`officeace` 是先进行、后补白名单）。接新渠道时**两处必须同改**，
另有第三处 `src/provider-expiry.ts` 的 `createProviderExpiry()` 一并跟进 ——
后两者的运行期一致性由 `tests/unit/expiry-runtime-parity.spec.ts` 锁住。

⚠️ **`zcode` 的额度是「按模型」分桶的**，故它的可用性是**逐模型**判定的：
赠送的 8M 实测分成 `GLM-5.3` 3M 与 `GLM-5.3-Flash` 5M 两个**专属桶**
（上游在余额接口里下发 `capabilities: ["model:<模型>"]`）。某个模型烧光而另一个
还有额度时，只会把**烧光的那个模型**在该账号上标记为当日用尽 ——
另一个模型照常可用，不会因为「账号整体还有额度」而误派发到已尽的模型上。
若账号另有**不限定模型**的通用赠送额度（如 1 亿 token），且它还有余额，
则两个模型都仍可用（通用额度能承接它们）。

**上下文窗口**：聚合模型声明的是**候选渠道里的最大值**。同一个模型在 buddy /
codearts 上都是 1M，那么 `aggregate` 下选它也声明 1M（与直连一致）。⚠️ 若某次
请求恰好被路由到窗口更小的候选，由**失败切换**兜住（上游报超长 ⇒ 换下一个候选）。

**思考档位**：声明各渠道档位的**并集**（官方中文名），默认 `high` —— 与你选的
档位会**逐候选翻译**到目标渠道（精确命中就原样下发，写法不同就就近落到同族，
目标没有这一族就**不下发**该字段让它走自己的默认）。

聚合有**自己的**设置面板（Jet Hub 左侧 rail 的「聚合」项），可逐条控制候选
「是否参与轮换」（三态：参与 / 已拒绝 / 无临期积分·默认不参与），并提供
「排序：按临期 / 按手工」开关与「拒绝非临期」一键恢复。它没有账号与凭据（复用各渠道的账号）。

### ⚠️ 模型选择器里为什么有**两个**「Auto」

选到「不挑模型」这一档时，选择器里会出现**两条**看起来同义的项：

| 选择器里显示为 | 真实路由 | 代码 |
|---|---|---|
| **`聚合（跨渠道临期优先）`** 组下的 `Auto（聚合 · 跨渠道）` | `aggregate` / `auto` | `src/aggregate-adapter.ts` |
| **`Jet Hub 自动（临期优先）`** 组下的 `Auto（临期优先 · 整池）` | `jet-hub-auto` / `auto` | `src/auto-adapter.ts` |

后者是**上一代实现**（2026-10-06），前者是随后的重写（2026-10-07，`ba10f4f`）
并**泛化**成「规范模型名 + 渠道候选 + auto」三者共用一套排序
（`aggregate-core.ts`）。⚠️ 旧 auto 的**路由注册从未下线** —— `registerAutoLlm`
在 `ba10f4f` 前后都在 `src/index.ts` 里；`ba10f4f` 删掉的是它的**用量徽标接线**
（`lastDispatch` / `lastExpiryAt` 等字段与 `usage.badge` 改写），由 `2b8867c`
（2026-10-08「恢复旧 auto 的用量徽标」）补回，**两代因此并存至今**。
`src/index.ts` 的接线注释里直接称它为「**旧 auto**」。

⚠️ **日常请优先用 `聚合（跨渠道临期优先）`** —— 它是活跃维护线，两者**至少有四处**实质差异：

| | `aggregate/auto` | `jet-hub-auto/auto` |
|---|---|---|
| 候选渠道 | **9 家**（`WIRED_EXPIRY_PROVIDERS`） | **5 家**（`AUTO_PROVIDERS` 硬编码：`codearts` / `loomy` / `zcode` / `buddy` / `workbuddy`） |
| 尊重「拒绝轮换」开关 | ✅ | ❌ 不读拒绝表 |
| 「收下请求却零输出」目标级冷却 | ❌ 无 | ✅ 有（`zero-output-guard.ts`，issue IKJW31） |
| **候选级失败切换** | ✅ 某渠道失败时按候选序**换下一个重试** | ❌ **不换**：上游报错即整轮失败（只对「零输出」这一种情形改道） |

⚠️ **模型黑名单关不掉旧 auto**：它的 `listModels()` 无条件返回这一个模型、不套用户黑名单
（黑名单针对的是各渠道的真实模型），且 `jet-hub-auto` **不在** `provider-registry.ts`
里 ⇒ 设置页里连它的面板都没有。**忽略它即可**，选聚合那条。

⚠️⚠️ 但这**不等于「无法隐藏」**：`jet-hub-auto` 的 `ctx.llm` 注册路由**参与「已失效模型
剔除」**（`auto-adapter.ts` 注册时没传 `pruning`，而缺省即参与 —— 见
`llm-register-compat.ts` / `dead-model-store.ts`；对照 `src/index.ts` 对 `aggregate`
与对 `jet-hub-auto` 的**设置页表项**都是显式 `{ enabled: false }`）。
一旦 `dead-models.json` 里出现 `jet-hub-auto/auto` 记录，它就会从模型选择器消失，
而清除入口 `model.clearDead` 位于**它没有的那个面板**里 ⇒ **没有界面能恢复**
（只能手改 `dead-models.json` 或等 TTL 过期）。
⚠️ 生产可达性**未证实**：已知写入口需在该路由迭代中抛出「模型已下架」类错误，
而 auto 自身不走那条路径（真实用户盘里也只有一条 `aggregate/m1` 历史记录）。
⇒ 机制真实、当下**侥幸**未触发，按「**脆弱的绿**」对待。

（`src/aggregate-adapter.ts` 模块头的分工表里，「渠道内选模型 = 按倍率挑最便宜」与
「用途 = 不挑模型，谁临期烧谁」两格写的是「同左」；⚠️ 但**「候选来源」那格并不相同**
—— 旧 auto 是「5 个渠道的所有模型」，聚合是「所有渠道的所有模型」。
上表列的是**最要紧**的四处，不是穷举：上下文窗口的声明口径、用量徽标的数据源、
候选粒度（聚合按 `(渠道, realId)` 且同渠道内可回落下一个模型，旧 auto 每渠道只挑一个）
也都不同。是否合并/下线旧 auto 涉及把 `zero-output-guard.ts` 移植过去，
**属行为变更**，留待维护者定夺。）

---

## 本机 OpenAI 网关

插件启动后会在 `127.0.0.1:8326` 提供**两套**标准 OpenAI 接口，供 Pi、Continue、
Cline、OpenCode、Codex 或其他兼容客户端使用。网关复用 Jet Hub 已登录账号和现有
provider 适配器，不把上游凭据复制到客户端。

```
GET  http://127.0.0.1:8326/v1/models
GET  http://127.0.0.1:8326/v1/reasoning-efforts   ← 思考档位对照表
POST http://127.0.0.1:8326/v1/chat/completions    ← OpenAI Chat Completions
POST http://127.0.0.1:8326/v1/responses           ← OpenAI Responses API
```

⚠️ **两个端点同时可用，没有「格式开关」**：客户端用哪一套协议，由它自己请求的
路径决定。

⚠️ 上面那两个地址里的 **host 与端口都可被环境变量改掉**
（`DSH_OPENAI_GATEWAY_HOST` / `DSH_OPENAI_GATEWAY_PORT`）；设置页里的
「API 请求地址」显示的是**实际监听地址**，照它抄即可。

### 容器化部署（Docker / Compose）

默认只绑 `127.0.0.1`，因此**端口映射对网关无效**：容器里 `curl 127.0.0.1:8326`
能通只是假象，docker-proxy 与同网络的其它容器走的是容器桥接 IP（`eth0`），
那个地址上没有监听，于是宿主侧看到 `Connection reset by peer`
（对照：Web 端口绑的是容器 IP，所以映射可用）。

修法是让网关绑**容器自身的接口地址**：

```yaml
environment:
  - DSH_OPENAI_GATEWAY_ENABLED=1
  - DSH_OPENAI_GATEWAY_HOST=172.21.0.8   # 容器自身 IP：hostname -i 或 ip -4 addr show eth0
  - DSH_OPENAI_GATEWAY_PORT=8326
```

```console
$ docker exec dsh ss -tlnp | grep 8326
LISTEN  172.21.0.8:8326     # 绑上桥接 IP 后，端口映射才可达
```

⚠️ **不许填 `0.0.0.0` / `::` 这类通配地址**：会被显式拒绝并在启动前报错
（dsh 本体的 `--host` 也是同一姿态）。绑通配等于把网关暴露给整个网络，
真正的隔离只剩 API Key —— 而本网关承担的是「用你已登录的账号发请求」。
容器场景填容器自身 IP 即可。

⚠️ **暴露面不止「同一容器网络内的其它容器」，还包括宿主**：经端口映射（`-p`）
或 bridge 网关，宿主本身就能连到该端口。跨 bridge 网络的容器才被隔离。
设置页里绑了非回环地址时会显示这条提示；不打算对外提供时请保持默认
`127.0.0.1`（或删除该环境变量）。

### 缓存命中用量

- Chat Completions 使用 `usage.prompt_tokens_details.cached_tokens`。渠道未上报时省略缓存明细。
- Responses 使用 `usage.input_tokens_details.cached_tokens`。渠道未上报时，必填的计数保留为 `0`，并附加 `usage.cache_read_reported: false`。
  ⚠️ `cache_read_reported` 是**本插件的非标扩展**（OpenAI 官方 schema 没有这个字段），只在「未上报」时出现、恒为 `false`；官方 Python/TS SDK 与 codex 都会忽略未知字段，本仓的 `astudio` 适配器是唯一回读方。严格按 `additionalProperties: false` 校验的客户端会在这条降级路径上报错，属已知边界。
- 插件自己的**本地用量面板**按同一口径落盘：明确 `0` 原样记录，只有「未上报」才省略字段（PR #122 之前两者都会被省略，于是面板与网关口径对不上）。

渠道明确上报的 `0` 表示本次未命中。计算命中率时，只纳入有实际缓存计数的请求。

### 拿到地址与密钥

鉴权使用 `Authorization: Bearer <网关 API Key>`。

⚠️ 因此**在浏览器地址栏直接打开这些地址会返回 401**（没有带 Bearer 头）——
这是预期行为，不是网关没启动。请用客户端或 `curl` 带上传头访问。

优先从 `DSH_OPENAI_GATEWAY_API_KEY` 读取；未设置时，插件首次启动会在 DSH home 的
`openai-gateway/api-key` 生成并持久化随机密钥，重启后保持不变。

设置页里的开关状态存在 `$DSH_HOME/jet-hub/state.json` 的 `gatewayEnabled` 字段
（缺省为启用）。它**不进**账号备份/恢复。

### Qoder 和 Qoder CN 的并发与排队

Qoder 和 Qoder CN 的「单账号限流」默认开启，可在 Jet Hub 的对应渠道页分别关闭。设置保存后对新请求立即生效。同一个进程内，每个渠道的同一账号**同时只允许一个请求占着名额**，两次发出请求至少间隔 400 毫秒。账号已忙时立即返回本地排队错误。⚠️ 进入上游排队等待（`10605`）的那一刻会**让出名额**：否则一个账号被平台排队，就会把同一账号的其余请求全部拒掉。让出后这个账号可能在「本地等间隔」与「上游排队」两处各有一个请求 —— 那是排队不是并发调用，平台侧允许。面板尚未保存设置时，可用 `DSH_QODER_TRAFFIC_GUARD=off` 关闭默认限流。

上游返回 `10605` 时，网关识别 HTTP 和 SSE 两种响应。响应体未提供等待时间时，使用 HTTP `Retry-After`，每次等待仍以 10 秒为上限。可用 `DSH_QODER_QUEUE_MAX_ATTEMPTS` 设置重试次数（默认 180，`0` 表示立即返回排队错误），用 `DSH_QODER_QUEUE_TIMEOUT_MS` 设置整次排队预算（默认 30 分钟）。

直连可通过 `DSH_QODER_QUEUE_WAIT_MODE=visible` 在流式 Chat Completions 响应中查看 `qoder_queue` 排队信息，或设为 `fast` 立即返回错误。日志会记录上游提供的模型、队列类型、人数和可用状态，供排查使用。账号级调用限制由上游平台处理。

### 关闭网关

网关是**旁路功能**：它启动失败或被关闭，都不影响插件其余功能（登录、积分、模型
目录照常）。三种关闭方式：

| 方式 | 做法 |
|---|---|
| 环境变量 | `DSH_OPENAI_GATEWAY_ENABLED=0`（**完全不启动**，连 API Key 文件都不生成）|
| 设置页开关 | 关掉后不再监听 |
| 改端口 | `DSH_OPENAI_GATEWAY_PORT` 填非法值会记录错误并跳过启动，**不会**静默改用其它端口 |
| 改地址 | `DSH_OPENAI_GATEWAY_HOST` 填通配地址（`0.0.0.0` / `::`）同样记录错误并跳过启动 —— **不会**静默绑到全部网卡 |

### 请求体上限与 keep-alive

| 项 | 值 | 超限时的行为 |
|---|---|---|
| 请求体 | **300 MiB** | `HTTP 413` + `invalid_request_error` / `request_too_large`，响应体里带上限值 |
| 空闲连接（keep-alive） | **120 秒** | 服务端发 FIN；此后复用该连接会得到 `Connection reset` |

⚠️ 每轮把全量历史重新回传的客户端（Codex 等），历史里并入大截图后可能撞上 413：
新建会话、或删掉那条带大图的回合即可恢复。

### 安全边界

- **默认**只绑定 `127.0.0.1`，且**拒绝**通配地址（`0.0.0.0` / `::`）。
  只有容器/端口映射这类「客户端不在同一网络命名空间」的场景才需要改
  `DSH_OPENAI_GATEWAY_HOST`，且应填**具体接口地址**（如容器自身 IP）而不是通配。
  ⚠️ 改了之后暴露面**包含宿主**（端口映射/bridge 网关都能连到），
  同机与同容器网络的其它用户或进程也能连到该端口 —— 真正的隔离靠 API Key，
  不要把它配置进任何浏览器端工具或扩展。
- 密钥以明文写在 `$DSH_HOME/openai-gateway/api-key`。POSIX 下的 `0600` 权限在
  **Windows 上不生效**，多用户机器请改用 `DSH_OPENAI_GATEWAY_API_KEY` 环境变量。

---

## 用量徽标与 Token 用量

### 用量徽标

会话输入区右侧、模型选择器左边有一枚薄胶囊，显示**当前渠道一共有多少可用额度**；
点开是完整浮层（逐账号明细 / 订阅窗口 / 刷新 / 签到 / 显示偏好）。
只在选中本插件渠道的模型时渲染，非本插件的模型**不渲染、不发请求**。

折叠态按 **`渠道 • 读数`** 两段显示，例如：

```
CodeBuddy (腾讯) • 2434.96积分
CodeArts (华为云) • 9499.84积分
ZCode (智谱) • 94.54MToken
```

- **默认显示余额**（一共能用的额度）；可在浮层里切换成「优先订阅」或「只看积分」。
- **多账号只显示一个数字**（所有启用账号的余额合计），不会变成一长串。
- 账号读不到时合计会**静默少报**，故胶囊会挂一个**警示角标**（`441.78积分 ⚠`）。
- 浮层里逐账号列表**按余额降序**，超过 5 个折叠成「展开其余 N 个」。

### Token 用量

点 Jet Hub 页头的「**Token 用量**」按钮查看。数据分两份：

| 数据 | 位置 | 回答的问题 | 重启后 |
|---|---|---|---|
| 实时明细 + 汇总树 | 进程内存（上限 500 条） | 每一笔长什么样、这次会话花了多少 | 清空 |
| 历史日聚合 | `~/.dsh/jet-hub/token-ledger.json` | 本周 / 本月用了多少 | **保留**（按 UTC+8 日界，90 天）|

在历史图表中点选某一天并展开，可删除该日的历史累计。删除前会二次确认，只移除该日聚合，不影响实时明细、其他日期或账号设置；之后该日的新请求会重新累计。

- **计数是 wire 口径**：上游 usage 报什么记什么，不做本地估算。
- **总处理量** = 未命中缓存输入 + 缓存命中输入 + 输出；输出已含思考 token，缓存写入另列且不重复计入。不同渠道价格不同，因此这里不把 token 数冒充账单金额。
- 没收到 usage（失败 / 中断）显示 `—`，与真实的 `0` **严格区分**。
- 输出速率（tok/s）的分子含思考 token；汇总显示算术均值及完整样本的 P50/P90 估值。
- 日聚合文件升级到 schema v2 增加 TPS 对数直方图；旧 v1 数据照常读取（计数全保留）。⚠️ **升级前已累计过「输出速率样本」的日期不会显示 P50/P90** —— 判据要求「直方图样本数 = 累计样本数」，而旧桶的 `tpsCount` 在升级前就已累加、直方图为空，两者之差恒定 ⇒ 该日期在 90 天保留期内一直无分位数（`avgTps` 均值仍照常显示）。完全在 v2 之后累计满样本的日期正常显示；升级前存在但**从未有过速率样本**的日期（如当天全是失败请求）也会正常显示。

---

## 模型选择器里的活动徽标

服务商的模型目录**自带**活动信息（「夜间折扣」「限时免费」「错峰 4 折」「订阅优先」）。
本插件把那句**上游自己的话**读出来，画成宿主模型选择器里名字旁边的一枚胶囊：

- 徽标是**此刻**的函数，不是取目录那一刻的快照：活动一过期就不再出现；
  上游标了「只在活动期内显示」（`activeOnly`）的那一类，窗口一关也跟着消失；
  而「夜间折扣」这种上游**故意成对下发**的（夜里那条带折扣、白天另发一条只带同一个
  角标），徽标按上游语义全天挂着、**折扣价只在窗口内给** —— 与官方客户端一致，
  不是「过期了还挂着」；
- 跨零点的时段按**上游声明的时区**判断（23:00 说的是 Asia/Shanghai 的 23:00，不是你本地的）；
  带**星期**的时段按**当前日历日**判定 —— 周五 22:00–02:00 这种跨零点窗口在周六凌晨就按周六算，
  **不替上游把窗口延长到次日**（排程下一边界走的是另一套：按**窗口开始那天**找；两条路径措辞不同，
  不是同一条判据，详见 docs/agent-notes/promo-badge-issue-101.md §18）；
- 一个模型命中多条活动时只画一条，规则是**先看「此刻在跑」、再比优先级**（一条在跑的 priority 0 会压掉一条常驻的 priority 200 —— 这是刻意的：详见 issue #101 的讨论）；上游没给文案的条目**一律不画**，插件不编（唯一的例外是 trae —— 见下面那段）；
- 颜色由上游给，就近映射成宿主的四档语义色（绿=优惠、蓝=会员、暖色=先看一眼、其余中性）；
- **鼠标悬停那枚胶囊，会看到上游那句完整说明**（例如「11月16日–12月1日，每日赠送免费
  额度。」），后面还跟着**有效期**与**每日时段**（时段带上游声明的时区）。文案一律是
  上游自己的话，插件不翻译、不改写、不从折扣反推措辞。

> ⚠️ **悬停不是宿主徽标字段给的。** 宿主的 `LlmModelInfo.badge` 只有
> `{ text, tone }` 两格（实测 0.2.2-rc.3 的 `dsh-llm` 里 `hover` / `tooltip` /
> `title` 各 0 次命中），宿主自己的回落渲染也不带 `title`。那句长说明因此
> **必须由本插件占住 `conversation.input.model.label` 槽位**才能落地 ——
> 见下面「这一行由谁渲染」。

**它只是提示，不改变模型行为**：计费仍按上游当时的价格。名字里的倍率后缀
（例如 GLM-5.2 · x0.79→x0.50）讲的是「现在多少钱」，徽标讲的是「上游说这是一条活动」，
两条腿读**同一份目录文档**，因此不额外发任何请求。

覆盖渠道：buddy / workbuddy（/v3/config 的 modelPromotions 与 modelTiers）、
qoder / qodercn（模型目录每行自带的 promotion）、
trae（模型目录每行 `activity_discount.data.off_peak` 的**闲时窗口**）、
lobsterai（模型目录每行 `limitedFree` 四件套的**绝对时刻**窗口：`limitedFreeStartAt` /
`limitedFreeEndAt` 是 ISO 字符串，官方客户端自己算最近边界再 `setTimeout` 重拉）。

⚠️ TRAE 是**唯一**上游不给文案的一家（那份文档里只有数字），所以它的徽标措辞
是插件自己的（「闲时 5 折」）—— 换算只用上游给的支付比例，且**只在整十时换算**，
其余情形退回不带数字的那句；颜色也没有可抄的，恒为中性灰。其余两家的文案
逐字来自上游。

⚠️ **TRAE 的价格腿仍未接**（另案）：闲时时段里名字后面的倍率后缀还是**原价**
（`DeepSeek-V4-Flash · x0.2`），而名字旁挂着「闲时 5 折」—— 两条腿暂时不同源。
改它动的是「现在多少钱」的展示，且与 `traeDisplayName` 既有的占位判据纠缠。

⚠️ **LobsterAI 的限时免费是「绝对时刻」窗口，不是每日重复**：上游在模型目录里下发
`limitedFree` / `limitedFreeActive` / `limitedFreeStartAt` / `limitedFreeEndAt`
四件套（判据逐字取自官方客户端 asar）。徽标只在 **`limitedFreeActive === true`** 时画 ——
**声明 ≠ 生效**：`limitedFree:true` + `limitedFreeActive:false` 不画；而「此刻是否落在
窗口里」决定名字里的倍率是否按 `x0` 展示（窗口优先于快照：快照会过期）。起止读不懂时
**fail-closed**（不画徽标、倍率不归零、不排定时器），不把半条窗口当「无上界」；**只给一端**
（另一端是 `null` / 缺失）同样**不认窗口**、退回 `limitedFreeActive` 快照 —— 单边窗口会让
「永久免费」或「还没开始就免费」成立。⚠️ 官方客户端的画徽标条件还有一条 `!model.presetId`，
**本仓未采纳**：载荷里从未观测到该字段（模型类型上也没有），凭空加闸门等于替上游发明判据。
卡点如实标注：上游至今（2026-11-17 的真机目录）21/21 条目都是 `false/false/null/null`
⇒ **起止的真实格式尚未取证**，仓库里全是 fixture。

⚠️ **订阅闸门是另一回事：它不走徽标，走名字后缀。** LobsterAI 目录还下发
`accessible` / `subscriptionPriority` / `restrictionHint`，本插件把它们读成 `name` 的
短标签（`· 需订阅` / `· 不可用`），原因整句**追加**到 `description` 末行（不改写上游原文 ——
那句原文是取证材料）。三条刻意的取舍：

1. **不可用的模型仍在目录里**（`accessible:false` 只打标签、不隐藏）：隐藏等于让
   「订阅后能多用什么」不可见，而官方客户端对**已订阅**账号也是照常显示、不画标记。
   ⚠️ 已知缺口：聚合 `auto` 的候选池目前**没有** `accessible` 闸门，这类条目仍可能被选中
   （范围外、既有行为，已登记）；
2. **标签在倍率之前**（`Qwen4-Max · 需订阅 · x0.71`）：聚合的倍率解析
   （`priceFactorFromName`）是**末尾锚定**的正则，标签跟在后头会返回 `Infinity`
   ⇒ 带标签的模型被当成「最贵」排到最后，限免时连 `0` 倍率一起丢；
3. **上游名字先消毒再拼**：控制符换空格（删掉会把 `Weird\nName` 拼成 `WeirdName`）、
   剥零宽与双向控制符、折叠空白、限长 80 —— 上游名字是不可信字符串，而我们的标签
   与它拼在同一行里。

> **宿主版本影响的是哪一半（0.2.2 起才有 `LlmModelInfo.badge`）：**
>
> | 宿主 | 本插件的渠道（buddy / workbuddy / qoder / qodercn） | 其它插件的渠道 |
> |---|---|---|
> | ≥ 0.2.2（**实测**） | 胶囊 + 悬停长说明 | 它们自己下发的胶囊（由我们代画） |
> | < 0.2.2（**未实测**，按代码推） | 同上 —— 本插件的胶囊与悬停走槽位 + 自有候选表,
> | | 不读宿主 badge 字段 | 只有名字：宿主白名单里没有 `badge` 这个键,
> | | | 数据到不了选择器，我们也就无从代画 |
>
> 也就是说：本插件自己的活动徽标**不依赖**宿主版本 —— 它走的是槽位 +
> 自己的候选表。依赖 0.2.2 的只有「替兄弟插件把短标签画出来」这一半。
> （该槽位在更早的宿主上是否存在，本机**没有取证** —— 不写没有证据的话。）
>
> ⚠️ **证据强度如实标注**：上表 < 0.2.2 那一列是**按代码推的，没有实测**
> （本机宿主已升到 0.2.2-rc.3，没有旧宿主可跑）。≥ 0.2.2 那一列是实测：
> 无头 Edge 量到胶囊 58px、`title` 含上游原话与有效期（见 `tools/`）。
> 「升级前一行都没变」那句是**旧形态**的实测事实：那时本插件只下发
> `badge`、不占槽位，宿主不认这个键就等于零效果。

⚠️ 上游按**客户端身份**裁剪这份文档：实测同一个 URL、同一套凭据，App 身份回
「限时免费 + 订阅优先」（两个数组都在），纯 CLI 身份**两个数组都不在**（data 只剩 5 个键）。
所以「目录里读不到活动」可能是身份问题而不是上游问题 —— 排查时先对照官方客户端。

> ⚠️⚠️ **占住 single 槽的三条代价（PR #110 对抗审计 P1-1，如实登记）**：因为本插件替**所有**
> provider 画这一行（不只自家），凡是宿主自己会做、而我们在槽位里重画一遍的细节，都可能丢。
> 1. **名字与徽标的先后必须跟宿主走**：宿主 `placement` 两处排法**相反** —— `trigger`
>    （输入框上方那一行）**徽标在名字前**，`option`（下拉候选行）**徽标在名字后**。我们已按
>    `placement` 分支（`orderBadgeParts`）；`placement` 缺省时按 `option` 排。
> 2. **长名的省略行为由宿主自己做，重画会丢**：宿主对超长模型名有省略（`badgedName` 那套），
>    我们自造的 `dim-jh-modelLabel*` 类没有再实现它 ⇒ 极长的名字在槽位里可能不被省略。
> 3. **本地化是两套实现**：`resolveHostBadgeText` 与宿主的 `resolveText` 各写一遍（都按浏览器语言
>    选 en/zh）。这是本仓「同一判据只留一份实现」红线的**已知例外** —— 宿主的实现不在公开
>    导出里、本机 `node_modules` 也没有 `@deepseek-ai/dsh-client-ui-model-selection`（只有
>    `cordis`/`cosmokit`/`dsh-agent`/`dsh-commands`/`dsh-credentials`/`dsh-llm`/`schemastery`），
>    无法 import。将来若该包进入依赖，应改为复用宿主实现。
>
> 这三条的**净收益**仍是正的：不占槽位，兄弟插件的徽标在 single 槽上会被自己的 renderer
> 挡掉（`entriesOfSlot()[0]` 命中即 return，不跑 fallback）⇒ 别人的徽标**根本画不出来**。
> 「徽标排在名字前后 / 长名省略 / 本地化」这三处退让，换来的是「别人的徽标不被抹掉」。

窗口开关的那一刻由插件**主动播报**一次目录变更（本地事件，零上游请求），
因此徽标不必等 20 分钟的目录刷新周期。

### 这一行由谁渲染（以及占住槽位的代价）

模型选择器每一行的名字与徽标，宿主开的是 `conversation.input.model.label` 槽位。
该槽是 **`single`**（一个格子只有一个赢家），而**赢家替所有 provider 画行**。
本插件为了给出悬停而注册它（`plugin-src/client/model-label.js`，priority `-200`，
严格低于本机已装的 `dsh-connect-workbuddy` 的 `-105` 与 `dsh-connect-qoder` 的 `-1`）。

因此渲染分两条腿，缺一不可：

| 这一行是谁的数据 | 画什么 |
|---|---|
| 本插件有该**模型**的活动候选 | 名字 + 胶囊 + **完整悬停**（长句 · 有效期 · 时段）|
| 其余每一行 | 名字 + **宿主目录里那枚 `badge`**（别的插件发布的徽标因此继续可见）|

⚠️ 回落判据打在**模型 id**，不是「这家在不在候选表里」：撞名时本家的路由注册会被
幂等包装跳过、保留别人的路由，按 provider 压掉就会抹掉**别人按自己账号算出的**徽标。
⚠️ 反过来，自家渠道**绝不**回落到目录缓存里的 badge —— 那份是装配时刻挑定的，
宿主最长 20 分钟才重读目录；候选说「此刻不成立」时回落到它，画的就是过期徽标。

**代价如实登记**：占住这个格子后，`dsh-connect-workbuddy` 自己行上的负载图标、
「新」标记、折扣价后缀不再由它渲染（它的徽标经数据面保住）；`dsh-connect-qoder`
不发布数据面徽标，其错峰折扣胶囊由我们画不出来。两条都是 `single` 槽的固有形状，
不是缺陷 —— 要消除只能等宿主把该槽改成 `keyed`。

不想要这层接管时，把本插件从 profile 里移除即可。格子会落回**另一个占位者**手里
（本机是 `dsh-connect-workbuddy`，priority `-105`），它也会替兄弟插件画宿主 `badge`
的**短标签**（其 `HostBadgeChip`），但**没有**上面那句完整悬停 —— 因为长说明只在
本插件的候选表里。也就是说：徽标不丢，丢的是那句「哪天过期」。

### 与「用量徽标」的区别

上面那节讲的是会话输入区右侧那枚**额度**胶囊（本插件自己渲染，走 `conversation.input.right`，
那是 list 槽、与别人共存）。本节讲的是模型选择器**每一行**上的活动胶囊（走 single 槽，
独占）。两者不是同一条通路，数据面与渲染面都不同。

---

## 配置项

| 项 | 位置 | 说明 |
|---|---|---|
| 账号池 | `$DSH_HOME/jet-hub/state.json` | 账号、有效期、限流标记、模型黑名单、provider 顺序 |
| 网关开关 | 同上，`gatewayEnabled` | 缺省启用 |
| 供应商显示顺序 | 同上，`providerOrder` | 纯展示偏好，拖动行调整 |
| 永久积分锁定 | `$DSH_HOME/jet-hub/*.json`（独立文档）| **不与账号池同放** —— 避免多 profile 互相覆盖 |
| Token 账本 | `~/.dsh/jet-hub/token-ledger.json` | 历史日聚合 |

### 常见环境变量

| 变量 | 默认 | 说明 |
|---|---|---|
| `DSH_HIDE_MODELS_WITHOUT_ACCOUNT` | 关闭 | 设为真值时，**没有已登录账号的渠道**在模型选择器里整体隐藏 |
| `DSH_OPENAI_GATEWAY_ENABLED` | `1` | 设为 `0` / `false` / `off` / `no` 时完全不启动网关 |
| `DSH_OPENAI_GATEWAY_HOST` | `127.0.0.1` | 网关监听地址。容器/端口映射场景填**容器自身 IP**（`hostname -i`）；填 `0.0.0.0` / `::` 等通配地址会被拒绝并跳过启动 |
| `DSH_OPENAI_GATEWAY_PORT` | `8326` | 网关监听端口 |
| `DSH_OPENAI_GATEWAY_API_KEY` | 自动生成 | 网关 Bearer 密钥 |
| `DSH_REASONING_LOOP_GUARD` | 开启 | 思考死循环守卫总开关 |
| `DSH_REASONING_LOOP_AUTO_RESUME` | 开启 | 中止后是否自动补一句「继续」并重跑 |
| `DSH_REASONING_LOOP_AUTO_RESUME_MAX` | `2` | 连续自动续跑上限（最大 `10`）|| `DSH_TRAE_CHANNELS` | `solo_work_lite,solo_agent_remote` | TRAE 要拉取的通道，**顺序即优先级** |
| `DSH_TRAE_MAX_COMPLETION_TOKENS` | `64000` | TRAE 单次输出上限（设 `0` 关闭收敛）|

更多 provider 专属变量（如 `DSH_ZCODE_INTERNAL_CARRIER`、
`DSH_TRAE_ROTATE_MACHINE_ID` 等）见内部文档。

---

## 账号备份与迁移

Jet Hub 设置页底部的**备份**区提供导出 / 导入，用于两种情况：**换 DSH 版本时整体迁移**，
以及**从别处单独搬一个账号进来**。

备份文件是**自包含**的 JSON（账号索引 + 凭据原文 + 模型黑名单 + 永久积分锁定表）。

> ⚠️ **Qoder 的网页会话 Cookie 也在里面**（`<credentialRef>_web` 是独立凭据条目，
> 随账号一起导出）。它**能登录你的官网账号** ⇒ 分享备份文件之前先想清楚；只想迁移
> 模型与积分的话，先在设置页点「清除会话」再导出。
与 DSH 版本无关 —— 导入时按**当前版本**的存储契约重建，因此天然跨版本。

- **加密在浏览器侧完成**（PBKDF2 + AES-GCM），RPC 只收发明文载荷，明文与口令
  都不经过宿主持久化与日志。可选加密，不勾选即导出明文。
- 账号凭据、`refresh_token` 都在文件里，**等同于明文密钥**，请自行妥善保管。
- ⚠️ **不含的就是本机偏好**：备份只搬账号与凭据，**不搬**本机 OpenAI 网关开关、
  用量徽标偏好、自动签到记账等本机状态（导入时它们保持当前值，不会被备份覆盖）。
  账号条目上的字段（含 OpenCode 的 `opencodeProxy` / 指纹代次，以及 Gemini 的
  `geminiProxy`）则原样随快照往返。

### 导出：可以只导出选中的账号

导出弹窗列出当前账号池并可**逐个勾选**（`backup.export` 的 `accountIds`），
默认「全部账号」。只导一个账号时文件名会带上该账号 id（`dsh-codearts-backup-buddy-xxxx-日期.json`），
避免被误当成整份备份收着。

⚠️ **过滤只作用于 `accounts` 与 `credentials` 两个字段**：模型黑名单与永久积分锁定表
仍按**全量**写出。这样「只导一个账号」的产物依旧是**一份可整体还原的自包含快照** ——
让过滤只承担一种语义，两条路径就不会互相污染。

### 导入：两种模式（`replace` / `merge`）

| 模式 | 语义 | 用于 |
|---|---|---|
| `replace`（默认） | **整体替换**账号池与模型黑名单，还原快照 | 「恢复」按钮、换 DSH 版本后整体迁移 |
| `merge` | **只追加**：已存在的账号一律跳过，**不碰**模型黑名单与锁定表 | 「单独导入一个账号」、从别人的备份里挑账号 |

导入弹窗可勾选要落地哪些账号，并选择模式。

⚠️ **`merge` 下裁剪发生在发请求之前**（`plugin-src/client/backup-payload.js`）。
判重虽然在后端，但后端只知道「这份载荷里有哪些账号」，不知道用户勾了哪几个；
不先裁剪的话，从整份备份里只勾一个账号，其余账号仍会被追加，更糟的是备份里那些
**不在勾选范围内**的 `credentialRef` 可能已被本机现有账号占用，写进去等于
**覆盖现有账号的凭据**，与「只增加不覆盖」的承诺相反。故裁剪必须同时裁掉
`accounts`、`credentials` 与 `disabledModels` 三处。

### ⚠️ 合并导入判重的三层口径（缺一层就会堆出重复账号）

`src/backup.ts` 的 `importBackup({ mode: 'merge' })` 依次判：

1. **池里已有的 `id`** —— 账号的唯一键；
2. **池里已有的身份**（`provider:` + 凭据里的身份字段，见下表）；
3. **备份文件内部重复的 `id`** —— 同一份文件手工编辑后可能出现两条同 id。

⚠️ **只按 `id` 判重是不够的，第 2 层才是关键**：插件自己登录时 `id` 由 `shortId()`
**随机**生成（`buddy-a1b2c3d4`），而从第三方文件转换来的 id 是**确定性哈希**
（见下节）。同一个人因此有两套 id，只比 id 会把他重复加进池里 —— 而用户在
「从别人的备份里挑账号」时，最常见的情形恰恰是「这个号我已经手登过了」。

⚠️ **身份字段逐 provider 对齐**（漏一个字段，那个 provider 的「同一个号我已手登过」
场景就**必然**多一条重复账号）：

| 字段 | 哪些 provider 的凭据里有 |
|---|---|
| `user_id` | CodeBuddy / WorkBuddy / LobsterAI / Raccoon / ZCode |
| `uid` | Qoder（含中国版）/ TRAE |
| `userid` | Loomy |
| `account_id` | Cline / MiniMax |
| `sub` | Gemini（OIDC `sub`；**不取 `email`** —— 它会随改邮箱而变） |
| `api_key` | OpenCode（**仅账号槽**） |

⚠️ **Gemini 只认 `sub`，不认 `email`**：两者都在它的凭据里，但 `sub` 是 OIDC 的
**稳定主体标识**（换邮箱、改昵称都不变，上游就拿它当账号 id），而 `email` 会随用户
改邮箱而变 —— 拿它判重会让同一个账号在改邮箱后多出一条重复账号。

⚠️ **OpenCode 的匿名通道要排除**：它的凭据只有 `api_key`，而匿名通道的 `api_key`
恒为字面量 `public` —— 全部匿名槽共用一个值。若拿它当身份，用户刻意添加的
**第二条匿名通道会被判成「已存在」而拒绝导入**（「多条匿名通道各走各的出口」
是上游明确提供的能力）。故匿名槽不产生身份，退回按 `id` 判重。

⚠️ **轮换令牌（`access_token` / `refresh_token`）不能当身份**：它们每次续期都会变，
拿来判重会让续期后的同一账号被判成新账号。

⚠️ **`id` 与身份都可能判不出来**：凭据缺失/损坏时按「无法判断」跳过该条，
不让一次判重失败阻断整体导入。

### ⚠️ 第三方账号列表可以直接导入（自动转换）

很多用户手上的是**别的工具**（账号池 / 卡号池脚本、IDE 本地缓存导出）产生的
CodeBuddy 账号列表，而不是本插件备份。两者结构完全不同：

| | 第三方账号列表 | 本插件备份 |
|---|---|---|
| 顶层 | **裸数组** `[ {...} ]`（或 `{ accounts / data / items / list: [...] }`） | 对象 `{ format, version, ... }` |
| 格式标记 | 无 | `format: 'dsh-codearts-auth/backup'` |
| 凭据 | 账号对象里**直接带** `access_token` / `refresh_token` | 独立 `credentials` 字典（ref → 凭据 JSON **原文字符串**） |
| 账号索引 | `id` 是 uid 或工具自己的编号 | `accounts[]`，`id` 形如 `buddy-a1b2c3d4` |

直接把它丢给「恢复」只会得到「该备份文件里没有账号」—— 因为取不到 `accounts`。
故选中这类文件时会**自动识别并转换**（`plugin-src/client/backup-convert.js`），
转换结果显示在弹窗里供核对，并**默认落到 `merge` 模式**（别人的新号，避免误覆盖本机账号）。

⚠️ **转换只改结构，不改写令牌**：`access_token` / `refresh_token` 原样搬运。
其余字段以「本机一个真实可用的 CodeBuddy 凭据」为基准对齐：

| 字段 | 来源 |
|---|---|
| `expires_at` | 原值（**毫秒**时间戳），统一成字符串毫秒 |
| `refresh_expires_at` | 优先 `auth_raw` 的 `refreshExpiresIn - expiresIn` 差值补算，退回 refresh_token 的 JWT `exp` |
| `domain` | **access_token 的 JWT `iss` 主机名**（它会被当作 `X-Domain` 头发出去） |
| `user_id` | access_token 的 JWT `sub` |
| `token_type` / `account_type` | 原值，缺省 `Bearer` / `personal` |
| `enterprise_id` | 缺省 `''`（个人版为空串，与真实凭据一致） |

⚠️ **provider 按 JWT `iss` 的主机名分派**：含 `workbuddy` → 国际版，否则 → `buddy`。
两套 provider 是**不同路由**，认错会让凭据发到错误的端点。

⚠️ **账号 id 由 uid 经 FNV-1a 哈希确定性生成**（`stableShortId`），与插件自己登录
生成的形式一致。这样**同一份文件导入两次，第二次会全部被判为「已存在」而跳过**，
而不是堆出两份账号。但 id 判重挡不住「同一个人的账号已用随机 id 登录在本机」——
那正是靠上文第 2 层的身份字段判重。

⚠️ **不写 `scope`**：真实凭据里有它，但插件**从不读取** `scope` 发请求
（只在续期时原样带回），而第三方文件里也没有 —— 与其猜一个可能不准的值，不如省略。

### ⚠️ 合并导入只写「真正要新增的账号」的凭据

`merge` 模式下**绝不回写备份里其余凭据**（含各 provider 的默认单凭据 ref）。
`replace` 模式才按字典逐条写入 —— 备份文件里可能含账号池之外的独立凭据 ref，
导出时一并纳入，导入时同样还原。

⚠️ 写入顺序是**先凭据、后账号池**：账号池写入成功后门控（`hasLoggedInAccount`）
与黑名单立即反映新状态；凭据写入中途失败（非法 ref 等）只跳过该条、不中断整体。

⚠️ **模式必须取白名单**（`req?.mode === 'merge' ? 'merge' : 'replace'`），
不能把请求里的任意字符串透传下去：未知值会被 `?? 'replace'` 静默当成整体替换 ——
那时用户以为只是「加一个账号」，实际账号池被清空，属于**不可逆的数据损失**。

### 测试

- `tests/unit/backup.spec.ts`（44 条）—— 选择性导出、合并导入三层判重、
  `merge` 不回写其余凭据、`replace` 兼容旧行为、各 provider 的身份字段覆盖度；
- `tests/unit/backup-payload.spec.ts`（13 条）—— 载荷裁剪与账号摘要；
- `tests/unit/backup-convert.spec.ts`（28 条）—— 第三方列表识别与转换；
- `tests/unit/account-pool.spec.ts` 的 `mergeAccounts` 段（6 条）—— 只追加、
  不改黑名单与锁定、坏条目归一化、文件内重复 id。

### ⚠️ 与上游同步（2026-10-02）

本章功能已随上游 62 个提交（新增 OpenCode provider、本机 OpenAI 网关、用量徽标、
自动签到、供应商开关）重新落地：只有 `plugin-src/client/jet-hub.js` 的 import 块
需要手工合并，`BackupPanel` 与 `src/backup.ts` 上游未改动。唯一的适配点是
**OpenCode 的身份字段**（见上表与匿名槽说明）。细节与反向验证记录见 `AGENTS.md`
的「上游同步记录」一节。

⚠️ 已做**反向验证**（2026-09-30）：禁用身份判重 → 1 条变红；让 `merge` 回写全部
凭据 → 3 条变红；`mergeAccounts` 去掉文件内去重 → 1 条变红。

## 开发

```sh
pnpm test          # 单元测试（快速，无网络，全部 mock）
pnpm typecheck     # 只做类型检查
pnpm build:all     # 完整构建（宿主 tsc + 资源拷贝 + 客户端 esbuild）
```

### 构建

- `pnpm build` — 用 tsc 将 `src/` 编译到 `lib/`。插件**宿主侧**入口是 `lib/index.js`。
- `pnpm build:client` — 用 esbuild 将 `plugin-src/client/` 打包为
  `lib/client/jet-hub.js`（Jet Hub 设置页的客户端 bundle）。
- `pnpm build:all` — 依次执行上述步骤，是完整的构建。
- `pnpm typecheck` — 只做类型检查，不产出文件。

`lib/` 已被 gitignore，因此构建是安装或运行前的必需步骤。

### E2E 测试

E2E 探针**按 provider 分列**（如 `pnpm test:e2e:codearts`、`pnpm test:e2e:buddy`、
`pnpm test:e2e:loomy`），**均有闸门、默认全部跳过** —— 需要显式设置对应环境变量
（部分还需 `..._CONFIRM=yes`）才会真正发出请求。详见 `tests/e2e/README.md`。

⚠️ 带 `-claim` / `-chat` / `-tools` 后缀的探针会**真实消耗额度或领取机会**；
带 `-refresh` 后缀的会**真实轮换一次凭据**（如 `accio-refresh`）。运行前请确认。

### 项目结构

| 路径 | 说明 |
|---|---|
| `src/` | TypeScript 源码（宿主侧） |
| `plugin-src/client/` | Jet Hub 客户端源码（esbuild 打包） |
| `lib/` | 编译产物（已 gitignore） |
| `tests/unit/` | 单元测试 |
| `tests/e2e/` | 端到端测试（默认跳过） |
| `docs/agent-notes/` | 逐 provider 的事故史与约定（开发向） |
| `docs/implementation-notes.md` | **全部实现细节与协议笔记（不入库）**。⚠️ **目前没有 accio 章节** —— accio 的实测笔记在 `docs/agent-notes/providers-accio.md`，补写该章节是独立任务 |
| `cordis.patch.yml` | DSH bundle 补丁 |
