import type { Context } from '@deepseek-ai/cordis'
import type { CredentialRef } from '@deepseek-ai/dsh-credentials'
import {
  attributionHeaders, CONTEXT_WINDOW_EXCEEDED_CODE, isContextWindowExceededError,
  isQuotaExceededError, LlmAdapter, LlmError,
} from '@deepseek-ai/dsh-llm'
import type { GenerateOptions, LlmModelInfo, LlmProviderInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm'
import { ReasoningEffortId, ToolCallId } from '@deepseek-ai/dsh-llm'
import { AccountPool } from './account-pool.js'
import { createModelCatalog, isCatalogFreshFor, type CatalogEntry, type ModelCatalog } from './model-catalog.js'
import { RemoteCatalogGate } from './remote-catalog-gate.js'
import { broadcastCatalogChanged } from './catalog-broadcast.js'
import { nextUtc8DayStartMs } from './model-queue.js'
import { isCodeArtsBenefitModel } from './models.js'
import { normalizeHarnessMessages } from './message-shape.js'
import { signRequestHuawei } from './sign.js'
// ⚠️ `detailFieldText`（`detail` 那条腿）**只留一份实现** —— 本仓库 6 份同义的
// `errorDetail` 各写一条判据必然漂移（见 `openai-compat.ts` 的注释，IKLBSH A1）。
import { detailFieldText } from './openai-compat.js'
import { createBlankReasoningSuppressor, createDsmlMarkerNormalizer, createReasoningLoopDetector, fixDsmlMarkers, hasUsableToolName, isReasoningLoopGuardEnabled, isTruncatedArguments, normalizeToolArguments, readWithIdleTimeout, reasoningLoopFailure, resolveEmptyResponseReason, resolveToolPairing, stripCourseLeakFromHistoryContent, stripCourseLeakIfEnabled } from './sse.js'
import { planSessionTitleThinking } from './session-title.js'
import type { CodeArtsCredential } from './types.js'
import {
  registerAdapterIdempotent,
} from './llm-register-compat.js'
import { reportLedgerAccount } from './token-ledger.js'

export const CHAT_API_BASE = 'https://snap-access.cn-north-4.myhuaweicloud.com/api/v2'
export const PROVIDER = 'codearts'
/**
 * 本家**恒声明**的两档思考开关 —— 顺序即**强度序（弱 → 强）**（Issue IKLIDV）。
 *
 * ## 为什么顺序是「关闭 → 开启」
 *
 * DSH 的契约把该数组当作**展示顺序**
 *（`dsh-llm/lib/types/types.d.ts` 原文：`Supported efforts in adapter-preferred
 * display order`），而官方客户端**直接 `map`、不排序**
 *（`dsh-client-ui-model-selection/lib/client.js` 的 `effortChoices`：
 * `[…, ...reasoning.efforts.map(…)]`）。故任何「把档位数组铺成一条轴」的渲染
 * —— 官方那个纵向 `menuitemradio` 列表、以及第三方横向滑条 —— 都直接吃这个顺序。
 *
 * 原实现写成 `['on','off']`（把默认档排在最前）。那个动机在**纵向列表**里成立，
 * 一旦铺成**横向轴**就变成「左强右弱」：「开启」贴最左、「关闭」贴最右，
 * 与「左弱右强」的直觉相反。
 *
 * 强度序的**唯一权威**是本仓库的 `reasoning-ladder.ts`
 *（`REASONING_EFFORT_RANK`：`off: 0` / `on: 5`）⇒ `off` 必须在前。
 * 三处旁证同向：
 * - DSH 自家 `dsh-llm-deepseek` 声明 `[off, low, high, max]`；
 * - DSH 自家 `dsh-llm-pi-ai` 的 `THINKING_LEVELS` 是
 *   `[off, minimal, low, medium, high, xhigh, max]`；
 * - 本仓库 `zcode-upstream.ts` 的 `orderReasoningLevels` **主动**把上游的
 *   乱序（实测插入序 `low, max, high`）排成 `none → minimal → low → … → max`。
 *
 * ⚠️ **`defaultEffort` 与数组位置是两件事**：默认档由 {@link CODEARTS_DEFAULT_EFFORT}
 * 单独表达，**不**靠「排在首位」。故本顺序的调整不改变任何默认行为。
 *
 * ⚠️ **本声明的顺序不参与任何语义判断**：关闭思考靠
 * `thinkingOffEffortOf` 的 `.find(isThinkingOffEffort)`（按 rank 找，不按位置），
 * `session-title` 那条路径也只用它当集合。
 *
 * ⚠️ **本常量是这两档的唯一定义处**：同一文件里原先写了**两份**逐字相同的
 * 数组（已知模型的 `toCatalogEntry` 与未知模型的 `unknownModelReasoning`）——
 * 那正是「一文件两套同义判据」的形态，改一处必漏另一处（用户手填模型 id 时会
 * 看到与已知模型相反方向的档位轴）。现已收敛到这一份。
 *
 * ⚠️ 网关的 `openai_efforts` 是这份顺序的**机械投影**
 *（`openai-gateway/effort-view.ts` 逐个 push `canonical`），故本顺序同时决定
 * `/v1/models` 里那一列的可读性：升序 ⇒ `["none","high"]`。
 */
export const CODEARTS_REASONING_EFFORTS: readonly { id: ReturnType<typeof ReasoningEffortId>; name: string }[] =
  Object.freeze([
    { id: ReasoningEffortId('off'), name: '关闭' },
    { id: ReasoningEffortId('on'), name: '开启' },
  ])

/**
 * 默认思考档 = `开启`。
 *
 * 依据（实测 2026-09-29）：不传 `thinking` 与服务端默认等价，而服务端**默认就开着**
 *（`{type:'enabled'}` 与不传的 `reasoning_tokens` 落在同一基线）⇒ 标成 `on`
 * 是**如实描述**，不是我们强行改变行为。
 *
 * ⚠️ 必须落在 {@link CODEARTS_REASONING_EFFORTS} 内：DSH 在 `normalizeModelInfo`
 * 里校验「`defaultEffort` 必须是被声明过的 id」，不在则抛 **`INVALID_MODEL_REASONING`**
 *（整轮对话起不来）。
 * ⚠️ 别与 `UNSUPPORTED_REASONING_EFFORT` 混淆 —— 那个码是**另一回事**：
 * 指「**请求**里带的档位不在该模型声明内」（`resolveCallWithInfo` 抛）。
 * 审计实测（2026-10-14，`dsh-llm/lib/index.js`）：`defaultEffort='on'` 而
 * `efforts=[low,high]` ⇒ code 为 `INVALID_MODEL_REASONING`。本行原写
 * `UNSUPPORTED_REASONING_EFFORT` 是**张冠李戴**（同型措辞在 `raccoon-adapter.ts`
 * 与 `trae-adapter.ts` 是既有问题，本次只修这一处新增注释）。
 */
export const CODEARTS_DEFAULT_EFFORT = 'on'

/**
 * 「该账号没有 benefit（免费额度）包」的稳定失败码。
 *
 * CodeArts 对**积分制**账户（体验版等，没有 benefit 免费额度包）会以
 * HTTP 200 + SSE `InferHub.4004.200 benefit not found` 拒绝带
 * `maas_type: benefit` 的请求，而同一个模型不带该头可以正常出流（实测
 * 2026-10-01，deepseek-v4.1-flash）。`stream()` 命中该码后去掉该头重试一次。
 */
const BENEFIT_NOT_FOUND_CODE = 'BENEFIT_NOT_FOUND'
/** CodeArts 在账号没有 benefit 包时下发的事件 error_code。 */
const CODEARTS_BENEFIT_NOT_FOUND_ERROR_CODE = 'InferHub.4004.200'

/**
 * 额度用尽时抛出的错误码 —— **字面量 `'QUOTA_EXCEEDED'`，不是 harness 常量**。
 *
 * ## ⚠️ 为什么不能用 `QUOTA_EXCEEDED_CODE`（真实缺陷，Gitee issue IKJVCW）
 *
 * harness 导出的 `QUOTA_EXCEEDED_CODE` 字面值是 **`'QUOTA'`**，而 DSH 客户端
 * 对这三个码会**丢弃适配器精心写的 message、换成一句固定文案**
 * （实测 `dsh-client-ui-chat/lib/client.js`，桌面端 `app.asar` 内为逐字节同串）：
 * ```js
 * if (code === "QUOTA" || code === "ACCOUNT_QUOTA") return t("message.failure.quota");
 * return code === "AUTH" ? t("message.failure.auth") : message;
 * ```
 * locale 表：`"message.failure.quota": "当前请求的额度已用尽"`。
 *
 * 于是 {@link codeartsQuotaExhaustedMessage} 里那句**带解禁时间**的说明
 * （「预计 5.5 小时后重置（按 UTC+8 自然日结算…）可改用其它模型…」）
 * 一个字都到不了用户眼前 —— 用户只看到「当前请求的额度已用尽」，
 * 既没有原因也没有出路。这与 `docs/agent-notes/client-ui.md` 记的
 * 「凡是要把自定义文案送到用户眼前，码必须避开这三个」是**同一条铁律**；
 * buddy 的 `11140` 当初正因如此才从 `AUTH` 改成 `PERMISSION_DENIED`。
 *
 * ## 为什么取字面量而不是 `PERMISSION_DENIED`
 *
 * ① **语义准确**：额度用尽的出路是「等重置 / 充值 / 换模型」，不是「没权限」。
 *    仓库里 buddy / cline / lobsterai / trae / zcode / minimax 等 **~20 处**
 *    额度错误一律用字面量 `'QUOTA_EXCEEDED'`，且**都不被客户端替换** ——
 *    本处改用 harness 常量才是异类（codearts 是**唯一**用它的 provider，
 *    这正是缺陷只在本家复现的原因）。
 * ② **可重试性不变**：`'QUOTA_EXCEEDED'` 与 `'QUOTA'` **同样不在**
 *    harness 的 `DEFAULT_RETRYABLE_CODES`（`EMPTY_RESPONSE / RATE_LIMIT /
 *    SERVER / TIMEOUT / TRANSPORT`）里 ⇒ 仍是「确定性、不白退避」。
 * ③ **下游判据已双认**：`account-probe.isRateLimitFailure` 与
 *    `qoder-adapter.isQuotaExceededError` 都同时接受 `'QUOTA_EXCEEDED'`
 *    与 `'QUOTA'`；`dead-model-store` 的 `IGNORED_CODES` 更是**只收**
 *    `'QUOTA_EXCEEDED'` —— 原先靠 `NOT_GONE_PATTERNS` 的 `/额度/` 文案兜底
 *    才没被误记成模型失效，改后是显式命中，比原来更稳。
 *
 * ⚠️ **不要改回 `QUOTA_EXCEEDED_CODE`**，也不要为「与 harness 词汇一致」
 * 而改回 `'QUOTA'`：那正是本缺陷的成因，会让解禁时间再次从 UI 上消失。
 */
const CODEARTS_QUOTA_EXHAUSTED_CODE = 'QUOTA_EXCEEDED'

// DeepSeek V4（CodeArts Agent 模型列表新增，UI 标注"每日 1000 万免费 Tokens"福利）：
//
// 修正（2026-09-23，对齐 deveco-code-rust fb1b4a2）：早期注释称
// 「deepseek-v4-flash-0731 后端未注册」，该结论**有误** —— 实测它返回 404 的
// 真实原因是**缺少 `maas_type: benefit` 头**；带上该头即成功。带日期后缀与
// 无后缀是后端上两个不同的模型，均有注册，不能互相替代：
//   - deepseek-v4-flash-0731 / deepseek-v4-pro-0813 → benefit 模型（需 maas_type）
//   - deepseek-v4-flash / deepseek-v4-pro（无后缀）  → 非 benefit（带该头会
//     `unsupported model`）
// gateway/config 返回的是 benefit 那组，故下方静态表保留无后缀形态
// （无后缀始终可用，不依赖 benefit 头），而 deepseek-v4.1-flash 只有 benefit 形态。
const DEFAULT_MODELS: readonly string[] = [
  'GLM-5.2', 'GLM-5.1', 'GLM-5',
  'glm-5.3-flash',
  'openpangu-2.0-flash', 'openpangu-2.0-pro',
  'deepseek-v4-flash', 'deepseek-v4-pro',
  'deepseek-v4.1-flash',
]

/**
 * 模型上下文窗口（最大合并请求+响应 token 数）。
 * - GLM-5.2：202752（对齐 CodeArts Agent IDE 模型卡标注）。
 * - glm-5.3-flash：1048576（1M，逆向自 IDE gateway/config，对齐 deveco-code-rust 90aeb17d）。
 * - deepseek-v4-flash / deepseek-v4-pro：1048576（1M，UI 标注）。
 * - deepseek-v4.1-flash：1000000（对齐 IDE 下发的 inferhub-provider 模型配置，
 *   2026-09 kernel 日志；对齐 deveco-code-rust fb1b4a2）。
 * - 其余模型未公开上下文容量，留 undefined 让后端默认裁剪。
 */
const CONTEXT_WINDOWS: ReadonlyMap<string, number> = new Map([
  ['GLM-5.2', 202752],
  ['glm-5.3-flash', 1_048_576],
  ['deepseek-v4-flash', 1048576],
  ['deepseek-v4-pro', 1048576],
  ['deepseek-v4.1-flash', 1_000_000],
])

/**
 * 单次请求输出上限的安全边界。
 *
 * ⚠️ 取值依据是**本文件下方出站处的实测**（参考实现 deveco-code-rust e2e：
 * 65536 可用，131072 反而触发空流被后端拒绝）。**不是**「拒绝 128000」——
 * CodeArts 语境下仓库里没有任何 128000 的实测记录（README 那张
 * 128000/131072 表属于 buddy/workbuddy；`deepseek-v4.1-flash` 两个 provider
 * 都有该 id，极易张冠李戴）。
 *
 * ⚠️ 这是**全 provider 统一**的边界，不是逐模型表：本适配器的出站点只有一个，
 * 而 `CONTEXT_WINDOWS` 之上方已注明「其余模型未公开上下文容量」——
 * 拿不到实测就不该臆造更小的值。故凡走本适配器的模型一律收敛到此上限。
 */
const CODEARTS_MAX_OUTPUT_TOKENS = 65_536

/**
 * 收敛输出上限到安全区间；非法值返回 undefined（不编造，交由调用方取默认）。
 *
 * ⚠️ 存在的理由与 TRAE 的 `clampTraeMaxTokens`、Cline 的 `clampClineMaxTokens`
 * 完全同因：上游网关对超大 `max_tokens` 会直接 4xx，而 DSH 可能注入一个来自
 * 其它 provider 的大值（`maxTokens` 是 agent 的一等构造参数，只校验
 * 「正安全整数」、**无上限校验**）。网关层的 `normalizeMaxTokens` 只覆盖
 * 走 `/v1/chat/completions` 与 `/v1/responses` 的请求，**直连路径完全绕过它**
 * ⇒ 本函数是最后一道防线。
 */
function clampCodeArtsMaxTokens(value: number | undefined): number | undefined {
  if (value === undefined || !Number.isFinite(value)) return undefined
  const integer = Math.floor(value)
  if (integer <= 0) return undefined
  return Math.min(integer, CODEARTS_MAX_OUTPUT_TOKENS)
}

export interface CodeArtsAdapterOptions {
  credentialRef: CredentialRef
  resolveCredential: () => Promise<CodeArtsCredential | undefined>
  refresh: () => Promise<void>
  /** 动态拉取远端模型列表；失败时调用方回退到静态列表。 */
  fetchRemoteModels?: () => Promise<Array<{ id: string; name: string }>>
  /**
   * 最近一次目录拉取的**各来源成败**（issue IKJVTF，审计 I3）。
   *
   * CodeArts 的目录来自**两个独立端点**（`opengw gateway/config` 给 benefit 模型、
   * `snap-access /v1/model/builtin` 给常规模型），而失败路径都**静默**返回
   * `undefined` ⇒ 「一个成功、一个失败」时 `models.length > 0`，旧判据会把它
   * 当成「已拿到目录」⇒ **永久缓存**（短路）⇒ 残缺目录固化，只能重启 DSH。
   *
   * ⚠️ 用**回调**而非直接读 `service` 的内部状态：适配器不该依赖 `CodeArtsAuth`
   * 的字段形状（它由 `index.ts` 接线，且单测用替身）。接线层把它桥接成
   * 「读 `service.lastCatalogOutcome`」，见 `src/index.ts`。
   *
   * 返回 `undefined` 时按「无法判定」处理 —— 与 `normalizeLoadResult` 的
   * 向后兼容口径一致（`complete = got`）。
   */
  catalogComplete?: () => boolean | undefined
  /**
   * 时钟（注入以便单测推进目录 TTL；缺省 `Date.now`）。
   *
   * ⚠️ 只用于**目录新鲜度**（`ensureRemoteModels` 的 `isCatalogFresh`），
   *    不用于超时/退避计时 —— 那些仍走真实时钟。
   *    ⚠️ **buddy 是例外**：它的 `catalogGate` 也吃这个时钟（冷却与
   *    「距上次尝试 ≥10 秒」判定都走它），所以别把本行当成全仓库通用口径。
   */
  now?: () => number
  fetchImpl?: typeof fetch
  chatId?: string
  sessionId?: string
  /** 多账号池（用于限流时切换账号） */
  accountPool?: AccountPool
  /**
   * 远端目录**落地后**的通知回调（issue IKJVTF）。
   *
   * 由 `registerCodeArtsLlm` 注入为 `broadcastCatalogChanged(ctx)`。适配器本身
   * 拿不到 `ctx`，故必须由接线层桥接（与 `readImage` 等回调同一模式）。
   *
   * ⚠️ 必要性：客户端 `ModelCatalogDirectory` 在 `status === 'ready'` 时**短路
   * 返回缓存**，只在宿主事件上 `refresh()`。没有本回调时，冷启动首拉失败
   * 缓存的**兜底表**会永久留在对话框里，远端目录真的落地也不重读。
   */
  onCatalogLoaded?: () => void
}

/**
 * 将消息内容载荷展平为纯文本字符串。Harness 消息
 * 以 OpenAI 风格的块数组形式携带内容（`[{type:'text',...}]`，且
 * 助手历史可能包含 `{type:'reasoning',...}` 块）；CodeArts
 * 端点会拒绝非 `text` 块类型并返回空流，因此只保留
 * `text` 块并拼接。
 */
function contentToText(content: unknown): string {
  if (typeof content === 'string') return content
  if (!Array.isArray(content)) return ''
  return content
    .filter((block): block is { type: string; text: unknown } =>
      typeof block === 'object' && block !== null && (block as { type?: unknown }).type === 'text')
    .map((block) => String(block.text))
    .join('')
}

/**
 * 将 harness 对话消息序列化为 CodeArts chat-completions 的传输
 * 格式。助手的 `tool-call` 块转换为 `tool_calls` 字段；`reasoning`
 * 块折叠为 `reasoning_content` 字段（deepseek-v4 等推理模型的后端
 * 校验要求 assistant 消息必须携带该字段，缺失会报 "Missing
 * `reasoning_content` field"）；工具结果（搭载在 harness 用户消息中）
 * 展开为独立的 `{role: 'tool'}` 消息，使模型能看到其调用的返回值。
 * 其余非文本块（图片）被丢弃，与端点接受的格式一致。
 *
 * ⚠️ 入口先做 **DSH 0.1.7 消息形状归一化**（见 `message-shape.ts`）：0.1.7 把工具
 * 结果改为一等 `role:'tool'` 消息，若不归一化，下面的 `type === 'tool-result'`
 * 判据恒不命中 → 工具调用被 `resolveToolPairing` 整体剔除。
 */
export function serializeMessages(messages: readonly { role: string; content: unknown }[]): Array<Record<string, unknown>> {
  const normalized = normalizeHarnessMessages(messages)
  const wire: Array<Record<string, unknown>> = []
  // 剔除无法配对的工具调用/结果（详见 resolveToolPairing）：孤儿 tool_calls
  // 会让后端对之后每一条消息都返回 400，整个会话永久报废。
  const { keepCallIds, keepResultIds } = resolveToolPairing(normalized)
  for (const message of normalized) {
    if (message.role === 'assistant') {
      // 存量自愈：清洗历史里已持久化的行首 `course` / `课` 泄漏
      // （见 `stripCourseLeakFromHistoryContent`）。只清 assistant ——
      // 判据只对模型自己的输出成立，清洗用户输入等于篡改用户的话。
      const content = stripCourseLeakFromHistoryContent(
        message.role,
        Array.isArray(message.content) ? message.content : [],
      )
      const toolCalls = content
        .filter((block): block is { type: string; id: unknown; name: unknown; arguments: unknown } =>
          typeof block === 'object' && block !== null && (block as { type?: unknown }).type === 'tool-call')
        .filter(block => keepCallIds.has(String(block.id)))
        .map((block) => ({
          id: String(block.id),
          type: 'function' as const,
          function: { name: String(block.name), arguments: normalizeToolArguments(String(block.arguments)) },
        }))
      const reasoning = content
        .filter((block): block is { type: string; text: unknown } =>
          typeof block === 'object' && block !== null && (block as { type?: unknown }).type === 'reasoning')
        .map((block) => String(block.text))
        .join('')
      wire.push({
        role: 'assistant',
        content: contentToText(content),
        // 后端（deepseek-v4-flash/pro）校验要求 assistant 消息必须包含
        // reasoning_content 字段：历史里的推理块在上一轮被持久化，回传时
        // 若缺失该字段会直接 400（"Missing `reasoning_content` field"）。
        // 始终携带该字段（无推理时为空串），确保字段存在。
        reasoning_content: reasoning,
        ...toolCalls.length > 0 ? { tool_calls: toolCalls } : {},
      })
      continue
    }
    if (message.role === 'system') {
      wire.push({ role: 'system', content: contentToText(message.content) })
      continue
    }
    // user 角色：工具结果搭载在 harness 用户消息中；将每个展开为
    // 独立的 role:'tool' 传输消息，与 deepseek 适配器的行为一致。
    const content = Array.isArray(message.content) ? message.content : []
    const toolResults = content.filter((block): block is { type: string; toolCallId: unknown; content: unknown } =>
      typeof block === 'object' && block !== null && (block as { type?: unknown }).type === 'tool-result')
    // 纯文本 user 消息（字符串 content）需原样传递：contentToText 处理
    // 字符串时直接返回，但这里不能用 `content`（非数组时为 []）——否则
    // 字符串 user 消息会被序列化成空串，模型看不到任务指令。
    const text = contentToText(message.content)
    if (text.length > 0 || toolResults.length === 0) wire.push({ role: 'user', content: text })
    for (const result of toolResults) {
      // 丢弃孤儿工具结果：没有对应 tool_call 其结果同样会让后端 400。
      if (!keepResultIds.has(String(result.toolCallId))) continue
      wire.push({
        role: 'tool',
        tool_call_id: String(result.toolCallId),
        content: contentToText(result.content) || '(no output)',
      })
    }
  }
  return wire
}

/**
 * 判断模型是否为 deepseek-v4 系列（flash/pro）。
 *
 * deepseek-v4 对标准 OpenAI 格式的 `tool_calls.arguments` 采用一次性打包
 * 生成：模型在生成超大工具参数（如 2000 行 write content）期间 SSE 流
 * 长时间无数据，APIG 网关 ~60s 空闲超时必然掐断连接（`terminated`），
 * 且后端不会对任何请求头发送心跳保活（实测 2026-08-22：无论是否携带
 * app-id/plugin-name/x-ot-* 等 IDE 头、是否带 `accept: text/event-stream`、
 * `tool_stream`、调整 `max_tokens`，SSE 流均无 `:` 注释行，60s 静默必断）。
 *
 * 但 deepseek-v4 原生支持 DSML 工具调用格式：工具调用直接写入
 * `delta.content`（形如 `<｜DSML｜tool_calls>...`），走与 reasoning 相同的
 * 流式通道。实测（2026-08-22 e2e 探测）：1000 行 write content 的 DSML
 * 流全程最大静默仅 204ms，146s 完整结束；标准 tool_calls 模式 100 行也
 * 会在 17.7s 静默后一次性到达、300 行即 60s 断连。因此对 deepseek-v4
 * 模型将工具 schema 注入 system 消息、请求体不发送 `tools` 字段，让模型
 * 以 DSML 流式输出工具调用，从根上规避网关空闲断连。
 */
/**
 * ⚠️ **已移至共享层 `./dsml.js`**（2026-10-13）。
 *
 * OfficeAce 通道复用不到本文件的实现 ⇒ 漏注入 DSML 提示 ⇒ 模型臆造
 * `<｜DSML｜ calls>` 语法。协议定义**必须只有一份**。
 */
export { isDeepseekV4Model, needsDsmlToolMode, buildDsmlSystemPrompt } from './dsml.js'
import {
  buildDsmlSystemPrompt,
  DsmlContentExtractor,
  isDeepseekV4Model,
  needsDsmlToolMode,
} from './dsml.js'

/**
 * 工具名匹配大参数写文件类工具（content/arguments 可能达到数万 token）。
 * 仅用于对非 deepseek-v4 模型的 DSML 模式降级判定（当前全量模式不再使用此列表）。
 */
/**
 * 判断模型是否应使用 DSML 原生工具调用语法输出。
 *
 * deepseek-v4 模型始终走 DSML 模式（不论工具列表中包含什么工具），原因：
 * - 标准 `tool_calls` 模式要求参数一次性打包生成，SSE 流在生成参数期间长时间
 *   无数据，APIG 网关 ~60s 空闲超时必然掐断连接（`terminated`），且后端不对
 *   任何请求头发送心跳保活；
 * - 除 write/file_write/apply_patch 外，`subagent` 的 `prompt` 参数也可能很长
 *   （包含详细任务描述与上下文），同样面临网关断连风险；
 * - DSML 模式使工具调用通过 `delta.content` 流式输出（全程有数据流），从根上
 *   规避网关空闲断连，实测 1000 行 write content 的 DSML 流全程最大静默仅
 *   204ms，146s 完整结束；
 * - 模型行为统一，避免不同步骤间标准/DSML 模式切换引入的不一致。
 *
 * 非 deepseek-v4 模型（如 openpangu / GLM-5.2 等）使用华为标准 IAM AK/SK 鉴权，
 * 不走 CodeArts Agent APIG 网关，无 60s 空闲断连问题，继续保持标准 tool_calls。
 */
/**
 * CodeArts 并发排队端点。当后端按账户的会话
 * 并发上限达到时，chat completions 请求会以
 * `TM.00001041`（"并发会话数已达上限"）失败，调用方需轮询
 * 排队状态端点，直到后端再次允许该会话。
 */
export const QUEUE_STATUS_BASE = 'https://snap-access.cn-north-4.myhuaweicloud.com/api/v1/queue/status'

/** 在 CodeArts 队列中等待时的轮询间隔。 */
const QUEUE_RETRY_DELAY_MS = 10_000
/** 轮询上限：180 × 10 秒 = 30 分钟，与 deveco-code 参考实现一致。 */
const QUEUE_MAX_ATTEMPTS = 180

/**
 * APIG「正文哈希对不上」时**直接重发**的次数上限。
 *
 * 取 2：该故障是上游网关侧的瞬时状态，实测两次连续失败后第三次即可成功；
 * 再多只是把真正的持续故障拖长，反而掩盖问题。
 */
const SIGNATURE_RETRY_MAX = 2
/** 重发的退避基数：第 n 次等 n × 该值（500ms、1000ms）。 */
const SIGNATURE_RETRY_DELAY_MS = 500

/**
 * SSE 流空闲超时。CodeArts 后端 / APIG 网关对 SSE 连接有 ~60 秒无数据即
 * 断开的策略：当模型生成超长推理或大工具调用参数时，两次 chunk 之间可能
 * 静默数十秒，连接被服务端掐断后 Node undici 的 reader.read() 抛
 * `TypeError: terminated`。该错误非 HarnessError，被 normalizeLlmFailure
 * 归类为 UNKNOWN（不可重试），harness 直接失败。
 * 主动以略小于网关超时的窗口检测空闲：超时则取消 reader 并抛可重试的
 * TIMEOUT，让 harness 重试该步骤（历史已持久化，重试会带相同上下文）。
 *
 * SSE 流超时配置（对齐 CodeArts Agent IDE agentkernelServer 逆向实证：
 * `firstTokenTimeout = 300000` / `chunkTimeout = 600000`）。
 *
 * 历史背景：原实现用单一 `SSE_IDLE_TIMEOUT_MS = 55_000`（55s），对齐
 * APIG 网关 ~60s 空闲断连。但 deepseek-v4-flash 生成大文件 write 工具
 * 调用的 content 参数时，会先输出 file_path 参数然后长时间静默（模型
 * 在内部做长文本生成但不在 SSE 上 flush），实测三次均在 ~55s 处被掐断、
 * 重试后又重复相同模式——55s 对这类"思考型长生成"太短。
 *
 * IDE 的方案是拆成两个超时：
 * - firstTokenTimeout=300s：等第一个 token 的窗口，到点才报错
 * - chunkTimeout=600s：每收到一个 chunk 就重置；两次 chunk 之间超过 10 分钟才报错
 *
 * 两者均可通过环境变量覆盖（毫秒，整数），便于测试用短超时触发 TIMEOUT
 * 路径，或在线上针对特定模型调优。环境变量在每次 stream() 调用时读取，
 * 避免模块顶层常量在 import 时定型、测试运行中设置环境变量不生效。
 */
function resolveFirstTokenTimeoutMs(): number {
  return Number.parseInt(process.env.DSH_CODEARTS_SSE_FIRST_TOKEN_TIMEOUT_MS ?? '', 10) || 300_000
}
function resolveChunkTimeoutMs(): number {
  return Number.parseInt(process.env.DSH_CODEARTS_SSE_CHUNK_TIMEOUT_MS ?? '', 10) || 600_000
}

/**
 * 判断一个错误是否为 SSE 传输级故障（连接被对端掐断 / socket 重置 /
 * undici 内部 socket 错误），而非业务错误。这类错误可安全重试整个
 * chat 请求，因此映射为可重试的 TRANSPORT code，而非 UNKNOWN。
 */
function isTransportError(error: unknown): boolean {
  if (!(error instanceof Error)) return false
  const message = error.message.toLowerCase()
  // undici / Node 流在连接被对端关闭时抛 "terminated"
  if (message.includes('terminated')) return true
  // undici socket 错误（UND_ERR_SOCKET / UND_ERR_HEADERS_TIMEOUT 等）
  if (error.name.startsWith('UND_ERR_')) return true
  // fetch 网络层失败
  if (message.includes('fetch failed')) return true
  // TCP 重置 / 对端中断
  if (message.includes('econnreset') || message.includes('epipe') || message.includes('socket hang up')) return true
  return false
}

/**
 * SSE 流内可重试的排队/限流错误信号。CodeArts 后端有时以 HTTP 200 +
 * SSE 内嵌错误的形式返回排队/限流（如 `InferHub.ModelArts.81111.429`
 * TPM 超限），而不是 4xx——适配器把这种响应当成排队处理：延迟后
 * 重新发起整个 chat 请求，与 TM.00001041 行为一致。
 */
class SseQueueRetryError extends Error {
  readonly code: string
  constructor(code: string, message: string) {
    super(message)
    this.name = 'SseQueueRetryError'
    this.code = code
  }
}

/**
 * SSE 流内「额度已用尽」的信号（**不可重试**）。
 *
 * ⚠️ 必须与 {@link SseQueueRetryError} **分开**：排队是「等一会儿就通」，
 * 额度是「等多久都没用」。把它当排队处理正是本次缺陷的表象
 * （静默重试 30 分钟、界面零输出）。
 *
 * 之所以要单独一个类而不是直接抛 `LlmError`：`stream()` 需要在**同一个地方**
 * 完成「标记账号受限 + 切下一个账号 + 如实抛出」三件事，且要能 `continue`
 * 重试循环 —— 这件事只有捕获点的上下文（`credential` / `currentAccountId` /
 * `rateLimitTried`）才做得到。
 */
class SseQuotaExhaustedError extends Error {
  readonly code: string
  constructor(code: string, message: string) {
    super(message)
    this.name = 'SseQuotaExhaustedError'
    this.code = code
  }
}

/**
 * 把「距重置还有多久」格式化成中文短句。
 *
 * 用户需求（2026-10-02）：「其它渠道限额到了会提示多少时间后会解除限额，
 * 这个 codearts 的也加上吧」—— 其它渠道（buddy / workbuddy）由**服务端**
 * 在错误文案里给出重置时刻，故 `parseRateLimitError` 能解析；CodeArts 的
 * benefit 额度报文里**没有**任何时间字段（实测 `InferHub.4291.200` 的
 * `details` 只有 requestId / timestamps / modelId / traceId），因此按
 * **UTC+8 自然日**自行推算（见 {@link codeartsQuotaExhaustedMessage}）。
 *
 * @param resetAtMs - 解禁时刻（UTC 毫秒）。
 * @param nowMs - 当前时刻（注入以便单测）。
 */
export function formatResetIn(resetAtMs: number, nowMs: number = Date.now()): string {
  const diff = resetAtMs - nowMs
  if (diff <= 0) return '即将重置'
  if (diff < 60_000) return '不到 1 分钟'
  if (diff < 3_600_000) return `${Math.round(diff / 60_000)} 分钟`
  // 保留一位小数：额度按自然日结算，剩余时间通常在 1~24 小时之间，
  // 只报整数会让「还有 1 小时」与「还有 1.9 小时」看起来一样。
  return `${Math.round(diff / 360_000) / 10} 小时`
}

/**
 * 额度用尽时给用户看的完整说明（**含解禁时间**，这是用户明确要求的）。
 *
 * ## 为什么按「UTC+8 次日 00:00」推算
 *
 * CodeArts 的 benefit（免费额度）模型（`glm-5.3-flash` / `deepseek-v4.1-flash`）
 * 额度按**自然日**结算（IDE 模型卡标注「每日 1000 万免费 Tokens」），而
 * `InferHub.4291.200` 的报文里**不给重置时刻**。故与 `qoder` / `zcode` 的
 * 额度处理同款：复用 {@link nextUtc8DayStartMs} 取 UTC+8 当日 24:00，
 * **不能**复用 `parseRateLimitError`（它解析不到时间时退回「1 小时后」，
 * 对按日结算的额度会让标记过早失效，用户 1 小时后再撞一次同样的墙）。
 *
 * ⚠️ 措辞对「这是我们的推算」保持诚实：写「预计」，不谎称是服务端给的时间。
 *
 * @param model - 请求的模型 id（用户据此决定换哪个）。
 * @param resetAtMs - 推算出的解禁时刻。
 * @param nowMs - 当前时刻（注入以便单测）。
 */
export function codeartsQuotaExhaustedMessage(
  model: string,
  resetAtMs: number,
  nowMs: number = Date.now(),
): string {
  const when = formatResetIn(resetAtMs, nowMs)
  return (
    `codearts: 模型 ${model} 的免费额度（benefit）已用尽，`
    + `预计 ${when}后重置（按 UTC+8 自然日结算，预计 ${new Date(resetAtMs).toISOString()}）。`
    + '可改用其它模型，或在 Jet Hub 的 CodeArts 面板切换/添加账号。'
  )
}

/** CodeArts 后端返回的一次排队状态响应。 */
export interface CodeArtsQueueStatus {
  readonly status: 'waiting' | 'working' | 'error' | 'queue_full'
  readonly queuePosition: number
  readonly message: string
}

/** 判断 HTTP 错误体是否表示 CodeArts 并发排队限流。 */
function isQueueError(status: number, body: string): boolean {
  return status === 400
    && (body.includes('TM.00001041')
      || /peak\s+usage|try\s+again\s+after|peak\s+hours/i.test(body)
      || /high\s+demand|too\s+many\s+requests/i.test(body))
}

/**
 * 判断 HTTP 错误是否表示凭据已失效、可通过 refresh_token 续期后重试。
 * CodeArts 经华为 APIG 网关鉴权：SecurityToken 过期/无效时网关返回
 * `APIG.0602`（"Invalid token"），HTTP 状态通常是 401，但也观察到 403。
 * 本适配器在入口已按 expires_at 预判过期，但 SecurityToken 可能被后端
 * 提前吊销、或本地时钟与签发端有偏差——此时首次请求会命中本错误。
 * 策略：触发一次静默 refresh，用新 AK/SK/SecurityToken 重试一次；仍失败
 * 才抛 AUTH，避免把可自愈的瞬时鉴权失败暴露给用户。
 */
function isAuthError(status: number, body: string): boolean {
  if (status === 401 || status === 403) {
    // ⚠️ 先排除「网关瞬时签名故障」（`body hash mismatch`），否则会白跑一次
    // 凭据续期：它与 AK/SK、security_token 都无关，重发就能过（见
    // {@link isTransientSignatureFailure} 的实测依据）。
    if (isTransientSignatureFailure(status, body)) return false
    return true
  }
  return body.includes('APIG.0602') || /invalid\s+token|token\s+expired|token\s+is\s+invalid/i.test(body)
}

/**
 * 判断 SSE 流内返回的 error_code 是否属于**可重试**的排队/限流错误。
 *
 * CodeArts 以 HTTP 200 + SSE 内嵌 `error_code` 返回这类错误（例如
 * `InferHub.ModelArts.81111.429` TPM 每分钟 token 超限），而不是 4xx——
 * 适配器把它们当成排队处理：延迟后重试整个 chat 请求，与 TM.00001041
 * 行为一致，避免"思考后无输出"。
 *
 * ## ⚠️ 判据必须锚定「429」这个**独立数字**，不能用裸子串（真实缺陷）
 *
 * 原实现写作 `/81111|TPM|429|rate.?limit|…/`，其中 `429` 是**无边界子串**匹配，
 * 于是额度耗尽码 `InferHub.4291.200` 里的 `4291` **命中了 `429` 前缀** ——
 * 被误判成「可重试的排队限流」，进入每 10 秒重试、上限 180 次（30 分钟）的
 * 静默重试循环。
 *
 * 实测（2026-10-02，用户在本机真实凭据上的会话）：
 * ```
 * isSseQueueErrorCode('InferHub.4291.200') === true    ← 误判
 * 匹配到的子串: "429"
 * ```
 * 后果是**界面完全无输出**：`stream()` 在排队期间刻意不产出任何内容块
 * （见下方排队循环的长注释），而它误以为自己"在排队"。实测真实适配器
 * 25 秒内发出 4 次 chat 请求 + 3 次排队探测、**产出 0 个 chunk**，最终由
 * 用户手动中止（会话记录里是 `turn/end aborted` + `stream: []`，**没有任何
 * error 事件** —— 因为错误根本没被抛出）。这正是用户报障的「CodeArts Agent
 * 没反应」。
 *
 * ⇒ 现在 `429` 用 `(^|[^0-9])429([^0-9]|$)` 锚定为独立数字：`…81111.429`（结尾）
 * 与 `429 Too Many Requests`（后接空格）仍命中，而 `4291` 不再命中。
 * 额度耗尽的 `4291` 由 {@link isSseQuotaExhaustedErrorCode} 单独识别。
 *
 * 导出仅供单测直接锁定「`429` 的边界」这一判据本身 —— 若只靠调用点的先后顺序
 * （额度判据排在排队判据之前）来兜住 `4291`，那么把边界改回裸子串时**任何**
 * 端到端用例都不会变红（实测确认过），边界就成了没人守的装饰。
 */
export function isSseQueueErrorCode(code: string): boolean {
  return code === 'TM.00001041'
    || /81111|TPM|(^|[^0-9])429([^0-9]|$)|rate.?limit|too many requests|排队|限流/i.test(code)
}

/**
 * 判断 SSE 流内返回的 error_code 是否表示**额度已用尽**（不可重试）。
 *
 * 实测报文（2026-10-02，真实凭据）：
 * ```
 * HTTP 200  data:{"error_code":"InferHub.4291.200","error_msg":"insufficient quota",
 *                 "details":[…requestId…timestamps…modelId: deepseek-v4.1-flash…traceId…]}
 * ```
 * 同账号的 `deepseek-v4-flash`（非 benefit 通道）仍正常出流 —— 故这是
 * 「该模型 + 该账号的免费额度用尽」，不是账号欠费（同期 `statistics/plugin`
 * 显示积分余额仍有 8499.84）。
 *
 * 与「排队/限流」是**本质不同**的两件事，绝不可合并（同 `qoder` 的
 * `10605` 排队 vs `110` 额度那次教训，见 `AGENTS.md`）：
 *
 * | | 排队/TPM 限流 | 额度用尽 |
 * |---|---|---|
 * | 语义 | **暂时**受阻，等一会儿就通 | **额度真的没了**，重试无意义 |
 * | 处理 | 内部等待后重试 | **立即失败**并如实告知 |
 *
 * 判据用**子串** `4291`（而非全等）是刻意的：该码由服务端下发，本地产物里
 * 没有硬编码（同 `qoder` 的 `110`），若上游改用 `InferHub.4291.xxx` 的其它
 * 尾号表达同一语义，只认全等会漏判。`4291` 与排队族的 `81111` / 独立的
 * `429` 均不冲突。
 *
 * 文案兜底（`insufficient quota`）不可省：万一上游换了码值，序列化后的
 * detail 文本仍能命中 —— 与 `zcode` / `qoder` 的既有做法一致。
 */
export function isSseQuotaExhaustedErrorCode(code: string, message: string): boolean {
  return code.includes('4291') || /insufficient[\s_-]+quota/i.test(message)
}

/**
 * HTTP **4xx** 报文里是否表示「该账号没有 benefit（免费额度）包」。
 *
 * ## 为什么需要它（Gitee issue IKLBSH A6）
 *
 * 同一个上游条件走**两条**通道下发：
 *
 * | 通道 | 形态 | 修复前 |
 * |---|---|---|
 * | SSE | HTTP 200 + `{error_code:"InferHub.4004.200", …}` | ✅ 已接（`consumeSse` 抛 `BENEFIT_NOT_FOUND_CODE`）|
 * | HTTP | **4xx** + 同一码 | ❌ **未接** ⇒ 去头重试一次也不试，直接归 `INVALID_REQUEST` 抛出 |
 *
 * 「SSE 能自愈、4xx 却硬报错」＝同一个语义两套判据，正是本仓库首条红线的形态。
 *
 * ⚠️ **该缺陷已被独立锁定**：`origin/issue/IKJOF7-benefit-diagnostics` 分支
 *（2026-10-05）用 `it.fails` 显式锁死了它（「HTTP 4xx + 正文含
 * `InferHub.4004.200` 时也应当去头重试」），当时结论是「已确认，但本分支不修」。
 *
 * ⚠️ **判据复用同一个码值常量**（`CODEARTS_BENEFIT_NOT_FOUND_ERROR_CODE`），
 * 不另写第二份 —— 与 SSE 通道的判据（`consumeSse` 的 `===` 比较）**同源**，
 * 否则两条通道会在上游改码时分别漂移（这正是本缺陷的成因形态）。
 *
 * ⚠️ 与 {@link isSseQuotaExhaustedErrorCode} 的 `4291` **刻意不同**：那条腿用
 * 子串是为了容忍 `InferHub.4291.xxx` 的其它尾号，而 `4004` 这一族里
 * **没有证据**表明其它尾号是同一语义（`4004.200` 是实测唯一的 benefit 码）。
 * 按证据收紧到**全等**：放宽成 `InferHub.4004.` 前缀会把该族里未知语义的
 * 报文也变成可重试，属行为变更。将来真抓到别的尾号**再按实测放宽**。
 *
 * ⚠️ 不解析 JSON 而直接判原文：4xx 的报文形态与 SSE 不同（字段名可能不叫
 * `error_code`），这正是上面那条注释记录的教训。
 */
export function isBenefitNotFoundBody(body: string): boolean {
  return body.includes(CODEARTS_BENEFIT_NOT_FOUND_ERROR_CODE)
}

/**
 * 从错误体提取可分类的 detail 文本（OpenAI 风格 error 或 CodeArts error_code/error_msg）。
 *
 * ⚠️ **本次只「加腿」，且如实标注证据强度**：新增顶层字符串 `error` 一条。
 *
 * 该项的**证据是「同族实现已修」+「形态确实无法解析」，不是 codearts 的线上实录**
 * （141 个真实会话里没有 codearts 的 `{"error":"<字符串>"}` 报文）——
 * `src/openai-compat.ts` 的**同名函数**早已修过这个形态，其注释写明
 * 「只认 code/message/msg 会把整个 JSON 原样返回，用户看到一坨不可读的裸 JSON」，
 * 而本文件的这份没跟上（「一文件两套同义判据」是本仓库点名的复发形态，
 * 两处改一处时**必须同时改另一处**）。
 *
 * 之所以加：该形态在本份实现里**必然**退化成整段裸 JSON（`parts` 为空 ⇒
 * `return body`），而修法是把另一份已被验证的腿搬过来，零新增取舍 ——
 * 与 `httpErrorCode` 那次「调整判据优先级」不同，这里**不改变任何已有分类**，
 * 纯属补齐漏掉的形态（codearts 的 `errorDetail` 与 OpenAI 兼容报文同源）。
 *
 * ⚠️ **绝不「减腿」**：原有的 `error.code` / `error.type` / `error.message` /
 * `error_code`+`error_msg` / 顶层 `message` 五条**必须全部保留** ——
 * OpenAI 形态常把额度语义写在 `{"error":{"code":"insufficient_quota"}}` 里，
 * 少了 code 那条腿，该报文会从额度**掉回** `AUTH`/`INVALID_REQUEST`
 * （实测：`isQuotaExceededError` 对 `insufficient_quota` 为 true，
 * 但只有在它被拼进 detail 时才生效）。改的第一版真的把几条腿一起删了。
 *
 * ⚠️ **导出仅供单测直接锁定「形态覆盖」这一判据本身**（与
 * {@link isSseQueueErrorCode} / {@link isSseQuotaExhaustedErrorCode} 同款惯例）。
 * **不要**绕道「分类结果」去测它：`{"error":"insufficient balance"}` 这种报文，
 * 即使字符串腿失效、函数退回整段 JSON，**整段 JSON 里也含该短语** ⇒
 * 额度判据照样命中 ⇒ 那是**假守卫**（实测确认过，第一版就是这么错的）。
 * 直接断言本函数的**返回值**才测得到那条腿。
 *
 * ## ⚠️⚠️ 本函数是**展示**出口；分类出口是 {@link errorDetailForClassify}
 *
 * 无条件把 `detail` 计入产物会**翻转错误码**（真实净回归，两轮审计独立确证）：
 *
 * | 报文 | 只算既有腿 | 加上 detail 腿 |
 * |---|---|---|
 * | `{"message":"bad request","detail":"insufficient quota"}` | `INVALID_REQUEST` | **`QUOTA_EXCEEDED`** |
 * | `{"message":"bad request","detail":"prompt is too long for this model"}` | `INVALID_REQUEST` | **`CONTEXT_WINDOW_EXCEEDED`** |
 *
 * 后者还会**触发 DSH 的上下文溢出压缩**。本函数是 `httpErrorCode` 与 4xx 额度判据
 * 的**唯一分类输入** ⇒ 那两处**必须**改走 {@link errorDetailForClassify}，
 * 否则一个纯展示改进会静默改变分类行为（且我加的用例只断言返回值，零分类守卫）。
 *
 * ⚠️ **本份（codearts）与 `openai-compat.ts` 那份是同名不同实现**，
 * 两条出口的语义必须两处一致。
 */
export function errorDetail(body: string): string {
  return errorDetailImpl(body, true)
}

/**
 * 从错误体提取**分类用**的可读文本 —— **不含**顶层 `detail` 字段。
 *
 * ⚠️ 分类调用点（`httpErrorCode` / `isSseQuotaExhaustedErrorCode`）**必须**走本出口：
 * 它保证分类输入与「加 detail 腿之前」**逐字节相同**（见 {@link errorDetail} 的实测表）。
 */
export function errorDetailForClassify(body: string): string {
  return errorDetailImpl(body, false)
}

/**
 * `errorDetail` 的唯一实现（两条出口共用，**不各写一份** —— 那是本仓库首条红线
 * 「同一语义两套判据」，且必然漂移）。
 *
 * @param includeDetailField - `true` = 展示出口；`false` = 分类出口。
 */
function errorDetailImpl(body: string, includeDetailField: boolean): string {
  try {
    const data = JSON.parse(body) as Record<string, unknown>
    const error = typeof data.error === 'object' && data.error !== null
      ? data.error as Record<string, unknown>
      : undefined
    // 顶层 `error` 是**字符串**的形态（`openai-compat` 那份已覆盖，本份原先漏掉）。
    const errorText = typeof data.error === 'string' ? data.error : undefined
    const parts = [
      typeof error?.code === 'string' ? error.code : undefined,
      typeof error?.type === 'string' ? error.type : undefined,
      typeof error?.message === 'string' ? error.message : undefined,
      errorText,
      typeof data.error_code === 'string' ? data.error_code : undefined,
      typeof data.error_msg === 'string' ? data.error_msg : undefined,
      typeof data.message === 'string' ? data.message : undefined,
      // ⚠️ 上游代理的 `{"error":"acp-proxy failure","detail":"<真实原因>"}` 形态
      //（Gitee issue IKLBSH A1）—— 只认 `error` 会丢掉真正的原因。
      // 判据**只留一份实现**（`openai-compat.ts` 的 `detailFieldText`）；本仓库
      // 6 份同义 `errorDetail` 各写一条必然漂移（「同一语义两套判据」）。
      // ⚠️ **只在展示出口计入**（见上）。
      includeDetailField ? detailFieldText(data) : undefined,
    ].filter((value): value is string => value !== undefined)
    if (parts.length > 0) return parts.join(' ')
  } catch {
    // 非 JSON 错误体：直接用原文分类。
  }
  return body
}

/**
 * 将 CodeArts 错误响应归一化为 harness 错误码，与 deepseek 适配器的
 * httpErrorCode 词汇一致：400 且命中上下文超限措辞时归为
 * CONTEXT_WINDOW_EXCEEDED（触发 dsh compaction 自动压缩上下文），
 * 而不是不可重试的 HTTP_400，避免长会话在接近窗口上限时直接中断。
 *
 * ⚠️ **额度判据不得抢到 401/403 之前**（曾被审计建议改成这样，**已否决**）：
 * 「同一文案用 400 归额度、用 403 归 `AUTH`」看起来不一致，但那正是**有意**的 ——
 * codearts 的 401/403 来自**网关**（APIG.0602 Invalid token / APIG.0301 验签失败），
 * 而本仓库有一条**成文铁律**（`AGENTS.md` 的「同族判据必须逐格同构」）：
 * > **401/403 先判**，恒归认证类 —— 状态码与额度文案并存时
 * > （网关侧故障常在报文里捎带余额提示）**以状态码为准**
 *
 * 该铁律是 2026-10-06 raccoon / loomy「一个请求内 6 个号各被封 24h」事故的产物。
 * 把额度判据提到前面，就等于让网关故障时捎带的余额词**改写分类** ⇒
 * 真凭据失效被说成「额度用尽」，用户被引向「等额度恢复」而不是重新登录。
 *
 * ⚠️ 而且「codearts 会用 401/403 下发额度文案」这一前提**没有实测支撑**：
 * 141 个真实会话里 `InferHub.4291` 仅 1 次命中（还是在讨论参考实现的 Rust 源码），
 * 无任何真实 401/403 + 额度文案的记录。**将来若真抓到该报文，再按实测处理** ——
 * 不要据构造的报文改分类顺序。
 */
function httpErrorCode(status: number, body: string): string {
  if (status === 401 || status === 403) return 'AUTH'
  // ⚠️ **分类必须走 `errorDetailForClassify`**（不含 detail 腿）—— 用展示出口会让
  // detail 里的额度/超限措辞**翻转错误码**（实测表见 `errorDetail` 的 doc）。
  const detail = errorDetailForClassify(body)
  if (isQuotaExceededError(detail)) return CODEARTS_QUOTA_EXHAUSTED_CODE
  if (status === 429) return 'RATE_LIMIT'
  if (status === 400) {
    if (isContextWindowExceededError(detail)) return CONTEXT_WINDOW_EXCEEDED_CODE
    return 'INVALID_REQUEST'
  }
  if (status >= 500) return 'SERVER'
  return `HTTP_${status}`
}

/**
 * 华为 API 网关（APIG）**瞬时**签名故障的判据。
 *
 * 报文形态（用户报障 2026-10-03 的会话日志原文）：
 * `401 APIG.0301 Incorrect IAM authentication information: calc ak sk
 *  signature fail:body hash mismatch x-sdk-content-sha256 header`
 *
 * 为什么必须单独判它：这句说的是「网关收到的正文哈希 ≠ 我方
 * `x-sdk-content-sha256` 头」，**与 AK/SK、security_token 都无关**。
 * 本模块的签名实现（`sign.ts`）用**同一份字节**算哈希与发请求
 * （`signRequestHuawei(…, new TextEncoder().encode(body), …)` 的入参与
 * 传给 `fetch` 的 `body` 是同一个字符串）⇒ 本方不存在能把两者算岔的路径。
 * ⚠️ 这一点是**读码推导**，不是逐请求实测：仓库里没有对应的探针脚本。
 * 2026-10-19 审计已复核该不变量本身成立（空串 / 中文 / emoji /
 * 20 万字符 / 组合字符 5 组样本的 `sha256(body)` 与头恒等），但当时引用的
 * 「已用探针逐请求核对过」在本仓库**不存在** —— 按证据强度如实标注。
 *
 * 处置：直接重发（见 `SIGNATURE_RETRY_MAX`），**不要**刷新凭据 ——
 * 凭据与此故障无关，刷新只是白跑一次网络往返；
 * 也就不能让它落入 {@link isAuthError} 的「静默 refresh + 重发」分支。
 *
 * ⚠️ 判据刻意只认 `body hash mismatch`：`APIG.0301` 的另一半
 * （`verify ak sk signature fail`）**同时覆盖真实的 AK/SK 错误**
 * （`AGENTS.md` 记录了把 `Agent-Type` 误当签名头传入也会得到它），
 * 按它放宽会把真凭据问题误判成瞬时故障、让用户永远等不到「请重新登录」。
 */
export function isTransientSignatureFailure(status: number, body: string): boolean {
  if (status !== 401 && status !== 403) return false
  return typeof body === 'string' && /body hash mismatch/i.test(body)
}

/** 可中止的休眠；当信号中止时立即 resolve。 */
function delay(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve) => {
    if (signal?.aborted) return resolve()
    const onAbort = (): void => { clearTimeout(timer); resolve() }
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort)
      resolve()
    }, ms)
    signal?.addEventListener('abort', onAbort, { once: true })
  })
}

/** 安全读取 Error.message，避免访问器抛异常。 */
function errorMessage(error: unknown): string {
  if (error instanceof Error) return error.message
  try { return String(error) } catch { return 'unknown error' }
}

/**
 * 在空闲超时内读取一个流块（实现见 {@link readWithIdleTimeout}）。
 * 此处用 codearts 标签包一层，保持错误消息前缀与历史行为一致。
 */
function readCodeArtsChunk(
  reader: ReadableStreamDefaultReader<Uint8Array>,
  timeoutMs: number,
  signal?: AbortSignal,
  phase: 'first-token' | 'chunk' = 'chunk',
): Promise<{ done: boolean; value: Uint8Array | undefined }> {
  return readWithIdleTimeout(reader, timeoutMs, 'codearts', signal, phase)
}

/**
 * DSML 工具调用格式提取器。
 *
 * 某些模型（如 deepseek-v4）在未通过 `tools` 字段告知工具模式、或工具
 * 模式与模型训练格式不匹配时，会把工具调用以原生 DSML XML 风格直接写入
 * `delta.content`，形如：
 *   `<｜DSML｜tool_calls><｜DSML｜invoke name="bash">
 *    <｜DSML｜parameter name="command" string="true">ls</｜DSML｜parameter>
 *    </｜DSML｜invoke></｜DSML｜tool_calls>`
 * 适配器若原样作为 text-delta 输出，原始 token 会泄漏到 web UI（表现为
 * "dump 出奇怪的一段内容后终止"）。本提取器以流式状态机从 content 增量
 * 中识别完整 DSML 块并解析为结构化 tool-call；非 DSML 文本原样放行，
 * 保持流式输出不阻塞。
 *
 * 同时支持 DeepSeek-V4 Thinking 模式：模型在工具调用前会把推理过程包裹
 * 在 `<thought>...</thought>` 标记中写入 `delta.content`。本提取器把
 * `<thought>` 内容作为 reasoning 增量流式输出（与 `delta.reasoning_content`
 * 行为一致，显示在 web 的 Think 区域而非正文），避免推理文本泄漏到用户
 * 可见区域。参考 DSML 官方介绍：
 * https://blog.csdn.net/gitblog_00855/article/details/152146045
 *
 * 设计要点：
 * - 增量友好：content 可能跨多个 SSE chunk 分片到达，提取器维护内部
 *   缓冲区与多模式状态机（normal / in-thought / in-dsml），仅对已完成
 *   的 DSML 块产出 tool-call；reasoning 增量流式输出；未完成部分保留
 *   到下次 feed；非 DSML/thought 文本立即 flush，避免延迟。
 * - 容错：若缓冲区包含开标签前缀但长时间未闭合，且后续内容不像该标签
 *   （例如只是普通文本里碰巧出现该前缀），在 flush 时把残留作为纯文本
 *   输出，避免吞掉用户可见内容。
 * - 边界：DSML 标签使用全角 `｜`（U+FF5C）而非半角 `|`，与模型实际
 *   输出一致。`<thought>` 为半角普通 XML 标签，与 DSML 官方文档一致。
 */

/** 兼容 OpenAI 格式的 CodeArts 模型适配器，使用华为请求签名。 */
export class CodeArtsAdapter extends LlmAdapter {
  private readonly fetchImpl: typeof fetch
  private readonly chatId: string
  private readonly sessionId: string
  /**
   * ⚠️ **2026-10-08 Task 7b：三个方法收敛到共享骨架** `createModelCatalog`。
   * 原先 `listModels` / `resolveModel` / `listAllModels` 各写一遍骨架，
   * 现在只剩 `toCatalogEntry`（本家私有形状 + VL 过滤 + 静态 context 表）。
   */
  private readonly catalog: ModelCatalog

  constructor(private readonly options: CodeArtsAdapterOptions) {
    super()
    this.fetchImpl = options.fetchImpl ?? fetch
    this.chatId = options.chatId ?? crypto.randomUUID().replace(/-/g, '')
    this.sessionId = options.sessionId ?? crypto.randomUUID().replace(/-/g, '')
    // 目录落地后通知客户端重读（issue IKJVTF 的缺陷①）。
    this.catalogGate = new RemoteCatalogGate(
      options.onCatalogLoaded === undefined ? {} : { onLoaded: options.onCatalogLoaded },
    )
    // ⚠️ 共享骨架（Task 7b）：门控 → 读目录 → 黑名单 → 回填 → 三态。
    this.catalog = createModelCatalog(
      { accountPool: options.accountPool },
      {
        product: { id: PROVIDER },
        loadCatalog: () => this.catalogEntries(),
        syncCatalog: () => this.syncCatalogEntries(),
        // ⚠️ 未知 id 恒声明 `['text']`（本家是纯文本网关）。
        // ⚠️ 这是**用户 2026-10-08 裁定的一处行为变更**：原 `resolveModel` 对未知 id
        //    **省略**该字段（而 `listModels` 却声明 `['text']`，同一家内部不一致）
        //    ⇒ 统一为声明。影响面为零：CodeArts 是纯文本网关，VL 模型已被滤掉。
        unknownModelInputModalities: () => ['text'] as const,
        // ⚠️ **未知模型也声明思考档位**（7b 曾在此引入回归、7d 补回）：
        // 本网关唯一生效的思考控制是顶层 `thinking.type`，与模型无关 ⇒
        // 原实现对未知 id 同样给这两档。
        // ⚠️ 顺序规则见 `CODEARTS_REASONING_EFFORTS` 的长注释（**强度序：弱 → 强**）。
        // 未知模型与已知模型必须同一份顺序，否则用户手填 id 时档位轴会翻向。
        unknownModelReasoning: () => ({
          efforts: [...CODEARTS_REASONING_EFFORTS],
          defaultEffort: ReasoningEffortId(CODEARTS_DEFAULT_EFFORT),
        }),
        /**
         * ★ **强制重拉**（供后台 20 分钟刷新器与「用户改设置」）。
         *
         * ⚠️ 与 `loadCatalog` 的差别：后者内部有 `isCatalogFreshFor` 判据
         *    ⇒ 新鲜时**不拉**。本回调要的是「无视新鲜度，强制拉一次」，
         *    故先清 `catalogAt` 再调**同一个** `ensureRemoteModels()` ——
         *    **不另写一份拉取逻辑**（那会让两条路的上游行为分叉）。
         *    ⚠️ `ensureRemoteModels` 的入口就是 TTL gate ⇒ 清掉 `catalogAt`
         *    正是让它失效的承重动作（与 loomy / zcode 等家同型）。
         */
        refresh: async () => {
          this.catalogAt = 0
          await this.ensureRemoteModels()
        },
      },
    )
  }

  /**
   * 描述本适配器拥有的 provider 路由。
   *
   * 与 BuddyAdapter 同款防御：DSH 校验 `info.id === provider`，且模型设置页
   * 会用该 id 计算 `deriveKeyRef(provider)`（内部 `provider.toUpperCase()`）。
   * 入参异常时回退到 PROVIDER 常量，避免客户端抛
   * `undefined.toUpperCase is not a function`。
   */
  providerInfo(provider: string): LlmProviderInfo {
    const id = typeof provider === 'string' && provider.length > 0 ? provider : PROVIDER
    return { id, name: 'CodeArts Agent' }
  }

  /** 动态模型缓存（首次 listModels 成功后填充）。 */
  private remoteModels: Array<{ id: string; name: string }> | undefined

  /**
   * 已落缓存的目录是否**所有来源都取全**（issue IKJVTF，审计 I3）。
   *
   * ⚠️ **这是短路判据的第二半**：CodeArts 有两个目录端点，残缺目录也落
   * `remoteModels`，故只判「已定义」会让残缺永久固化（见 `ensureRemoteModels`）。
   */
  private remoteComplete = false

  /**
   * ⚠️ 上次**成功**读到远端目录的时刻（0 = 从未成功过）。
   *
   * ⚠️ 与 `remoteModels` **并存**、不是替代：`remoteModels` 存「有哪些模型」，
   *    本字段存「何时读到的」。只有 `remoteModels` 时目录**永不刷新**（原行为）。
   */
  private catalogAt = 0

  /**
   * 目录加载闸门：并发去重 + 失败冷却。
   *
   * ⚠ **不能省**：DSH 的 `buildModelCatalog` 对每个 provider `await listModels()`
   * 后再对每个模型 `await resolveModelInfo()`，两处都会走到这里。原实现失败
   * 直接返回（不落缓存）⇒ 一次网络故障被放大成「每模型重试一次」，每次顶着
   * 10s 超时（`src/models.ts FETCH_TIMEOUT_MS`），首屏因此长时间空转。
   */
  private readonly catalogGate: RemoteCatalogGate

  /**
   * 懒加载远端模型目录（**每 20 分钟**重新拉一次，用户 2026-10-18 的要求）。
   *
   * resolveModel 可能先于 listModels 被调用（如直接进入会话），此时同样触发远端拉取。
   */
  private async ensureRemoteModels(): Promise<void> {
    const fetchRemote = this.options.fetchRemoteModels
    // ⚠️ `fetchRemote === undefined` 那半边**原样保留** —— 它判的是「有没有远端
    //    可拉」（无凭据/无接线），与新鲜度是两件事。
    if (fetchRemote === undefined) return
    // ⚠️⚠️ **短路判据是「已完整」+「未超 20 分钟」，不是「已定义」**
    //    （issue IKJVTF 复审，审计 I3；TTL 由 `isCatalogFresh` 给出）。
    //
    // CodeArts 有两个独立目录端点，残缺目录**也**要落 `remoteModels`
    //（展示需要 —— 目录服务抖动时用户的模型列表不该整个消失），但那时**不能**
    // 短路：`RemoteCatalogGate` 的冷却（`retryAt` / `cooling()`）在生产里只有
    // 闸门自己那一处调用点，而它排在短路**之后** ⇒ 残缺目录一旦落缓存，
    // 冷却永远读不到、残缺永远补不齐（与 Cline 的缺陷② 完全同构）。
    //
    // ⚠️⚠️ **加 TTL 为什么不会破坏残缺恢复**（加 TTL 前逐行核实）：
    // TTL 那一腿是 `&&` 的**后半截**，前半截 `remoteComplete` 未变。残缺时
    // `remoteComplete === false` ⇒ 短路判据恒为假 ⇒ **残缺目录不会被判为
    // 「新鲜」，闸门冷却与补齐逻辑原样生效**。TTL 只让「重新拉取」变得可发生
    // （完整目录满 20 分钟会被重新拉，倍率/目录变化能跟上），不改变残缺的纠正路径。
    // ⇒ **未改任何合并逻辑**（两个端点各自成败仍由接线层经 `catalogComplete` 上报）。
    // ⚠️ **TTL 那一腿用 `isCatalogFreshFor`**（带「用户主动失效」）：用户在 Jet Hub
    //    改开关后要**立即**重拉（规格 §6 的正确性要求，见 `invalidateCatalogCache`）。
    //    ⚠️ 本家走 `LlmAdapter` 基类、`createModelCatalog` 的 `product` 是
    //    `{ id: PROVIDER }` ⇒ 登记的 provider id 恒为 `PROVIDER`（`codearts`），
    //    没有「一个类服务两个站」的情况（qoder / buddy 才有）。
    //    ⚠️ 失效腿与完整性腿是 `&&` ⇒ 失效让整条合取为假、照常进闸门；
    //    拉取失败时**保留**旧 `remoteModels`（本方法不清它）⇒ 用户看到的仍是
    //    上次那份完整列表，不会退化成兜底**子集**（规格 §7 的核心取舍）。
    if (this.remoteComplete
      && isCatalogFreshFor(PROVIDER, this.catalogAt, this.options.now?.() ?? Date.now())) {
      return
    }
    await this.catalogGate.run(async () => {
      const models = await fetchRemote()
      // 空目录同样算「没拿到」：既不应落缓存（否则再也拉不回来），
      // 也不应立刻重试（否则每个模型都打一次空请求）。
      if (models.length === 0) return false
      this.remoteModels = models
      // ⚠️ **只在成功赋值后**记时刻：失败/空结果不写，否则一次抖动会把上界
      //    刷新掉、下轮还要等满 20 分钟才发现上游没恢复。
      this.catalogAt = this.options.now?.() ?? Date.now()
      // ⚠️ 完整性由接线层桥接的数据源上报（两来源各自的成败）。
      // 拿不到判定时退回 `got`（= 旧行为），避免把「判不出」当成「残缺」
      // 而让每个 provider 都反复重拉。
      this.remoteComplete = this.options.catalogComplete?.() ?? true
      return { got: true, complete: this.remoteComplete }
    })
  }

  /**
   * 完整模型目录（**不应用用户黑名单**）。
   *
   * 设置页必须渲染被关闭的模型（否则用户无法重新打开），而 `listModels` 会按
   * 黑名单过滤掉它们 —— RPC 层只能凭裸 id 补回，展示名随之丢失
   * （用户报障：「关闭的就没有显示倍率」）。CodeArts 目录虽无倍率，但同样
   * 需要正确的 `name`（否则关闭项显示 `deepseek-v4-flash` 这类裸 id）。
   *
   * ⚠️ **2026-10-08 Task 7b**：骨架已上移到 `src/model-catalog.ts`，此处只剩委托。
   * ⚠️ 本家有一处**特有**的「可见性过滤」（VL 多模态不参与，见 `toCatalogEntry`），
   * 它在 `listModels` 与 `listAllModels` **两条路径上都要生效** ——
   * 故放在 `toCatalogEntry` 之前的取数回调里（`catalogEntries()`）。
   */
  /**
   * ★ **后台目录刷新器入口**（`src/index.ts` 的 `refreshOf` 调 `adapter.refresh?.()`）。
   *
   * ⚠️⚠️ 必须由适配器**显式转发** `catalog.refresh`：`ModelCatalog`（`model-catalog.ts`）
   *    上的这个成员**不会**自动变成适配器的成员 —— `pruned()` 的 Proxy 只透传
   *    **适配器自己的**成员（`dead-model-store.ts:748-749`）。
   *    漏转发 ⇒ 刷新器「已武装」却对这家**空转**，且**零日志**（`refreshOf` 返回
   *    `undefined` 时静默跳过 —— `index.ts` 的装配注释写着这件事）。
   *    ⚠️ 与 `options.refresh`（HTTP 401 后的**凭据**重取）**不是同一件事**，
   *    两者同名纯属巧合，**不得合并**。
   */
  async refresh(): Promise<void> {
    await this.catalog.refresh?.()
  }

  listAllModels(): readonly { id: string; name: string }[] {
    return this.catalog.listAllModels()
  }

  /**
   * 把本家条目转成共享骨架的中间结构。
   *
   * ⚠️ 本家三处**真实差异**（不要「顺手统一」）：
   * 1. **VL 多模态不参与目录**（`-VL-` / `-VL` 结尾的 id 被滤掉）——
   *    这是本家的可见性判据，骨架不认识；
   * 2. `contextWindow` 来自静态 `CONTEXT_WINDOWS` 表（不是远端字段）；
   * 3. `reasoning` 是**恒声明**的两档（关闭/开启，**强度序**），与 entry 无关 ——
   *    实测（2026-09-29）：本网关**唯一**真正生效的思考控制是顶层
   *    `thinking.type`，`reasoning_effort`（含 low/high/none/minimal）与嵌套
   *    `reasoning.effort` 都被服务端接受但**完全无效果**（判据为服务端上报的
   *    `reasoning_tokens`，落在基线噪声内；`none` 也照常思考）。
   *    故**不**臆造 low/high/max 强度阶梯。
   */
  private toCatalogEntry(model: { id: string; name: string }): CatalogEntry {
    const contextWindow = CONTEXT_WINDOWS.get(model.id)
    return {
      id: model.id,
      name: model.name,
      // ⚠️ 本家恒声明 `['text']`（CodeArts 是纯文本网关；VL 模型上面已滤掉）。
      inputModalities: ['text'] as const,
      ...contextWindow !== undefined ? { contextWindow } : {},
      reasoning: {
        // ⚠️ 顺序 = **强度序（弱 → 强）**，逐条理由见 `CODEARTS_REASONING_EFFORTS`
        // 的长注释（Issue IKLIDV）—— 简言之：DSH 把该数组当展示顺序、客户端不排序，
        // 故 `['on','off']` 会让「开启」落在横向轴的最左。
        // ⚠️ `defaultEffort` 仍由 `CODEARTS_DEFAULT_EFFORT` 单独表达，与位置无关。
        efforts: [...CODEARTS_REASONING_EFFORTS],
        defaultEffort: ReasoningEffortId(CODEARTS_DEFAULT_EFFORT),
      },
    }
  }

  /**
   * 本家全部条目（**含 VL 可见性过滤**）。
   *
   * ⚠️ `await this.ensureRemoteModels()` 是**必需**的（不是可选优化）：
   * 早期实现用 `void` 丢弃 Promise，冷缓存时远端目录尚未落地就走静态兜底表，
   * 模型选择器会短暂显示错误的模型集合（Jet Hub 的模型开关也据此渲染，
   * 会造成「关掉的模型又冒出来」）。
   */
  private async catalogEntries(): Promise<readonly CatalogEntry[]> {
    await this.ensureRemoteModels()
    const source = this.remoteModels ?? DEFAULT_MODELS.map((id) => ({ id, name: id }))
    // ⚠️ 与 `listModels` 保持**同一套**「可见性」过滤（VL 多模态不参与），
    // 唯一区别是不套用户黑名单 —— 那条区别现在由骨架的 `listAllModels` 承担。
    return source
      .filter((m) => !/-VL-/i.test(m.id) && !/-VL$/i.test(m.id))
      .map((m) => this.toCatalogEntry(m))
  }

  /**
   * 同步视图（`listAllModels` 用）。
   *
   * ⚠️ **不能** `await ensureRemoteModels()`（同步契约）—— 读 `remoteModels`
   * 缓存，未落地时回退静态兜底表（这正是原实现的语义）。
   */
  private syncCatalogEntries(): readonly CatalogEntry[] {
    const source = this.remoteModels ?? DEFAULT_MODELS.map((id) => ({ id, name: id }))
    return source
      .filter((m) => !/-VL-/i.test(m.id) && !/-VL$/i.test(m.id))
      .map((m) => this.toCatalogEntry(m))
  }

  async listModels(_provider: string): Promise<readonly LlmModelInfo[]> {
    return this.catalog.listModels(_provider)
  }

  async resolveModel(provider: string, model: string, signal?: AbortSignal): Promise<LlmResolvedModelInfo> {
    return this.catalog.resolveModel(provider, model, signal)
  }

  async prepareCall(
    provider: string,
    model: string,
    signal?: AbortSignal,
  ): Promise<{ model: LlmResolvedModelInfo; stream: (options: GenerateOptions) => AsyncIterable<StreamChunk> }> {
    return {
      model: { ...await this.resolveModel(provider, model, signal), inputModalities: ['text'] as const },
      stream: (options: GenerateOptions) => this.stream(options),
    }
  }

  async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    let credential = await this.options.resolveCredential()
    if (credential === undefined || Date.parse(credential.expires_at) <= Date.now()) {
      await this.options.refresh()
      credential = await this.options.resolveCredential()
    }
    if (credential === undefined || !credential.access_key_id || !credential.secret_access_key || !credential.security_token) {
      throw new LlmError('codearts: no usable credential; log in first', 'MISSING_CREDENTIAL')
    }

    // Track current account id for rate limit tracking
    let currentAccountId = ''
    if (this.options.accountPool && credential?.access_key_id) {
      try {
        currentAccountId = await this.options.accountPool.findAccountIdByCredential(
          'codearts',
          credential.access_key_id,
        )
      } catch (error) {
        console.warn('[codearts] 账号匹配失败（不影响本次请求）:', error)
      }
      // Token 账本（第 2 期）：回报「本笔请求解析出的账号」（空串不回报）。
      if (currentAccountId) reportLedgerAccount(PROVIDER, currentAccountId)
    }

    const messages = serializeMessages(options.messages)
    // harness 的 GenerateOptions.system 是独立的系统提示（如标题生成的
    // systemPrompt、agent 的 persona）。后端 chat/completions 只接受
    // messages 数组里的 system 角色，必须显式插入——否则模型看不到
    // system 指令，只见到 user prompt 本身（实测 2026-08-22：session
    // 标题变成了 "We need to generate a session title..." 的 prompt 回显）。
    if (options.system !== undefined && options.system.length > 0) {
      messages.unshift({ role: 'system', content: options.system })
    }
    // 将 harness 工具模式以 OpenAI function 格式告知模型，
    // 与 deepseek 适配器序列化 GenerateOptions.tools 的方式一致。
    const tools = options.tools?.map((tool) => ({
      type: 'function' as const,
      function: {
        name: tool.name,
        description: tool.description,
        parameters: tool.parameters,
      },
    }))
    // deepseek-v4 大文件写入修复（详见 isDeepseekV4Model 注释）：标准
    // tool_calls 参数一次性打包生成，SSE 静默 >60s 被网关掐断。仅当工具
    // 列表含大参数写文件类工具（write/file_write/apply_patch）时切换到
    // DSML：不发送 tools 字段、把 schema 注入 system 提示，让模型以
    // DSML 流式输出工具调用，全程有数据流、不触发网关空闲断连。read/
    // bash 等小参数工具保持标准 tool_calls，避免 DSML 带来的额外开销。
    let wireTools = tools
    if (wireTools !== undefined && needsDsmlToolMode(options.model, wireTools.map(tool => tool.function.name))) {
      // DSML 工具说明置于 system 之后、user 之前：与 CodeArts Agent IDE
      // 实际请求体一致（IDE 把工具说明作为 system 消息放在最前）。实证
      // （2026-08-22）：DSML 提示 push 到 messages 末尾时，deepseek-v4
      // 倾向把思考写入 content（正文）而非 reasoning_content；unshift 到
      // user 之前后模型恢复走 reasoning 通道，思考不再泄漏到正文。
      messages.splice(messages.findIndex(m => m.role === 'system') + 1, 0, { role: 'system', content: buildDsmlSystemPrompt(wireTools) })
      wireTools = undefined
    }
    /**
     * 会话自动命名（`purpose: 'session-title'`）的思考与预算决策（issue IKKVDH）。
     *
     * DSH 用 **64 token** 发标题请求且**不传 `reasoningEffort`**，而宿主会把
     * 本模型声明的默认档（本家恒为 `'on'`）注入进来
     * （`effective = requested ?? reasoning.defaultEffort`）。照常开思考时实测
     * 64 个 token 会被思考**全部吃满**、正文 0 字符、`finish_reason:'length'`
     * ⇒ `dsh-session-title-llm` 直接拒绝，标题永远停在 fallback。
     *
     * 本家的档位表是**恒声明的两档**（`on`/`off`，见 `resolveModel`），
     * 与具体模型无关 ⇒ 任何模型都**关得掉**，故这里必然走「关掉思考」分支，
     * 不需要抬预算（抬预算是「花钱买通」，思考本身要计费）。
     */
    const titlePlan = planSessionTitleThinking({
      purpose: options.purpose,
      requestedEffort: options.reasoningEffort === undefined ? undefined : String(options.reasoningEffort),
      // ⚠️ 与 `resolveModel` 声明的档位**同源**（`CODEARTS_REASONING_EFFORTS`）——
      // 各写一份必然漂移，而漂移的症状是「标题请求挑的关闭档不在声明里」。
      // ⚠️ `thinkingOffEffortOf` 按 **rank** 找关闭档（不按位置），故顺序调整不影响它。
      declaredEfforts: CODEARTS_REASONING_EFFORTS.map((effort) => String(effort.id)),
      maxTokens: options.maxTokens,
    })
    const body = JSON.stringify({
      model: options.model,
      messages,
      stream: true,
      // prompt_cache_key 让服务端启用前缀缓存并在 usage 中返回 cached_tokens，
      // 缺少该字段时缓存命中恒为 0（实测 2026-08-24）。
      prompt_cache_key: this.sessionId,
      // include/reasoning_summary 对齐 Rust 端 CodeArtsExtraFields，
      // 让服务端返回加密 reasoning 内容与摘要。
      include: ['reasoning.encrypted_content'],
      reasoning_summary: 'auto',
      // 思考开关（实测，2026-09-29）：档位「关闭」翻成本网关真正认的字段。
      // ⚠️ 是**顶层** `thinking`，不是 raccoon 那种 `extra_body.thinking` 方言
      // （两者是不同网关的方言，混用会静默无效）。
      // 实测判据：`disabled` → reasoning_tokens 3/3 全为 0、正文仍正确；
      // `enabled` 与不传等价（服务端默认就开着），故「开启」档**不发**该字段。
      //
      // ⚠️ 标题请求走 `titlePlan`（上方），它会把档位定成 `'off'`，
      // 于是这里同样发 `disabled` —— 两条判据**合并写**在一个表达式里，
      // 避免「标题请求绕开了关闭」这类静默失效。
      ...titlePlan.thinkingOff || options.reasoningEffort === 'off'
        ? { thinking: { type: 'disabled' } }
        : {},
      // 对齐 CodeArts Agent IDE 请求体（deveco-code 内核日志实证）：
      // tool_stream=true 让后端将超大工具调用参数（如大文件 file_write）
      // 分段流式传输，避免单次 SSE 事件过大导致连接被掐断
      // （error decoding response body）。deepseek-v4 的 DSML 路径不受此
      // 影响，保留该字段与 IDE 对齐。
      tool_stream: true,
      // 输出上限（对齐 deveco-code-rust 参考实现 codearts.rs 的 max_tokens 配置）：
      // 大文件 write 工具参数（如 1000-2000+ 行文档）需要数万 token 的生成空间，
      // 若沿用后端默认输出上限，参数 JSON 会在中途被截断成非法 JSON，harness
      // 工具校验报 `invalid arguments: "arguments" must be an object`。
      // 参考实现 e2e 实测：65536 可用，131072 反而触发空流被后端拒绝。
      //
      // ⚠️ **必须钳制，不能只兜底**（与 TRAE 的 `clampTraeMaxTokens`、
      // Cline 的 `clampClineMaxTokens` 同因）：`options.maxTokens` 原样透传时，
      // 上游对超大 `max_tokens` 会直接 4xx（`The request param is invalid`），
      // 而 **DSH 可能注入一个来自其它 provider 的大值** —— `maxTokens` 是 agent
      // 的一等构造参数（`dsh-agent-loop` 只校验「正安全整数」，**无上限校验**），
      // 走网关的路径由 `openai-gateway/messages.ts` 的 `normalizeMaxTokens`
      // 预先收敛，但**不经过网关的直连路径完全绕过那道判据**。
      // ⇒ 这里是最后一道防线，必须自己收敛，不能依赖上游调用方守规矩。
      // ⚠️ 抬预算（`titlePlan.maxTokens`，关不掉思考时才有值）必须走**同一个**
      // 钳制函数，否则会被钳回原值、兜底静默失效。标题请求的 512 远小于上限，
      // 故实际不会被钳；这里统一走一遍是为了「预算只有一个出口」。
      max_tokens: clampCodeArtsMaxTokens(titlePlan.maxTokens) ?? CODEARTS_MAX_OUTPUT_TOKENS,
      ...wireTools !== undefined && wireTools.length > 0 ? { tools: wireTools } : {},
    })
    const url = `${CHAT_API_BASE}/chat/completions`

    // CodeArts 按账户限制并发：当会话上限
    // 达到时请求以 TM.00001041 失败（或 SSE 流内返回
    // InferHub.ModelArts.81111.429 等排队/限流错误）。对齐参考实现
    // （deveco-code-rust runner.rs）：排队时不等待状态端点
    // working，而是每 QUEUE_RETRY_DELAY_MS 直接重试 chat 请求，
    // 上限 QUEUE_MAX_ATTEMPTS 次（180 × 10s = 30 分钟）。
    let response: Response
    let queueAttempts = 0
    // 鉴权失败（APIG.0602 / 401 / 403）后已刷新过凭据：避免死循环，
    // 同一次 stream() 调用最多 refresh 一次。
    let authRefreshed = false
    // 上游网关瞬时签名故障（正文哈希对不上）已重发的次数：
    // 与 `authRefreshed` 分开计，它**不是**鉴权失败，不该消耗续期名额。
    let signatureRetries = 0
    // 该账号不带 benefit 包时去掉 `maas_type: benefit` 头重试一次：
    // 只试一次，避免与真实失败互相掩盖。
    let benefitHeaderDropped = false
    // 因限流已尝试过的账号 id：保证每个账号只试一次，试完才判定"全部受限"。
    const rateLimitTried = new Set<string>()
    if (currentAccountId) rateLimitTried.add(currentAccountId)
    // benefit（免费额度）模型判定在重试循环外先算好：它要读 benefit 集合缓存
    // （`~/.cache/deveco/codearts_benefit_models.json`），不宜每轮重试都做 IO。
    // 集合来自 gateway/config 的模型清单 ∪ 静态兜底（见 isCodeArtsBenefitModel），
    // 使后端新增 benefit 模型时无需改代码即可自动识别。
    const isBenefitModel = isCodeArtsBenefitModel(options.model)
    for (;;) {
      // benefit（免费额度）模型（glm-5.3-flash、deepseek-v4.1-flash 等）后端要求
      // maas_type: benefit 头参与 SDK-HMAC-SHA256 签名，否则返回
      // InferHub.002002009.404 "model is not registered"。
      //
      // 判定必须是**动态**的：早期只硬编码 glm-5.3-flash 一个模型，导致
      // deepseek-v4.1-flash 等其它 benefit 模型调用失败（用户报障：
      // 发消息后报 Insufficient Balance / QUOTA —— 缺该头时后端按非 benefit
      // 通道处理该模型）。实证见 CODEARTS_BENEFIT_FALLBACK 注释。
      const extraSignedHeaders = isBenefitModel && !benefitHeaderDropped ? { maas_type: 'benefit' } : undefined
      const signed = await signRequestHuawei(
        credential.access_key_id,
        credential.secret_access_key,
        credential.security_token,
        'POST',
        url,
        new TextEncoder().encode(body),
        extraSignedHeaders,
      )
      const headers = new Headers(attributionHeaders())
      // 签名 map 中的额外头（如 maas_type）必须随请求发送——它们已参与
      // canonical 计算、包含在 SignedHeaders 列表中，缺失会导致服务端验签失败。
      signed.forEach((value, key) => { if (key !== 'content-type') headers.set(key, value) })
      headers.set('Content-Type', 'application/json')
      headers.set('Chat-Id', this.chatId)
      headers.set('Session-Id', this.sessionId)
      headers.set('lang', 'en')

      response = await this.fetchImpl(url, {
        method: 'POST',
        headers,
        body,
        signal: options.signal,
      })
      if (response.ok) {
        // 200：消费 SSE 流。CodeArts 有时以 HTTP 200 + SSE 内嵌
        // error_code/error_msg 返回排队/限流（如 InferHub.ModelArts.81111.429
        // TPM 超限），而非 4xx——consumeSse 检测到可重试排队错误时抛
        // SseQueueRetryError，落入下方排队重试逻辑，与 TM.00001041 一致。
        try {
          yield* this.consumeSse(response, options)
          break
        } catch (error) {
          if (error instanceof SseQuotaExhaustedError) {
            // ── 额度用尽（InferHub.4291.200）：标记 + 换号 + 如实报出解禁时间 ──
            //
            // ⚠️ 这块**必须与排队分支分开**，且**不能** `continue` 去重试：
            // 额度是按自然日结算的确定性失败，重试 180 次（30 分钟）也还是同一个
            // 结果，只会让 UI 长期停在「运行中」且零输出 —— 那正是本次报障。
            //
            // 标记时限按 **UTC+8 当日 24:00** 推算（报文里没有时间字段），
            // 与 qoder / zcode 的额度处理同款。标记写进 `modelRateLimits` 后，
            // Jet Hub 的「限额重置 · <模型> · N 小时后」徽章与池的选号
            // （`getAvailableAccount` 会跳过未到期的账号）同时生效。
            const message = codeartsQuotaExhaustedMessage(options.model, nextUtc8DayStartMs())
            // ① 先给**当前**账号记上限流标记（UI 徽章与池的选号都依赖它）。
            if (this.options.accountPool && currentAccountId) {
              await this.options.accountPool.updateModelRateLimit(
                currentAccountId, options.model, nextUtc8DayStartMs(),
              )
              rateLimitTried.add(currentAccountId)
            }
            // ② 取下一个可用账号。
            //
            // ⚠️ 必须传 `tried`：池按用户手动顺序返回候选，**刚失败的账号可能仍排
            // 第一**（当失败类别不写标记时尤甚），不排除就会拿回同一个、命中
            // `tried.has` 而立即放弃切换（换号形同虚设）。
            if (this.options.accountPool) {
              const next = await this.options.accountPool.getAvailableAccount<CodeArtsCredential>(
                'codearts', options.model, rateLimitTried,
              )
              if (next && !rateLimitTried.has(next.entry.id)) {
                rateLimitTried.add(next.entry.id)
                credential = next.credential
                currentAccountId = next.entry.id
                authRefreshed = false // 新凭据：重置「已刷新过」标记
                continue // 用下一个账号重试
              }
            }
            // ③ 没有可用账号（或没有账号池）：如实抛出，带上解禁时间。
            throw new LlmError(message, CODEARTS_QUOTA_EXHAUSTED_CODE, { status: 200 })
          }
          if (error instanceof SseQueueRetryError) {
            // 落入下方排队重试
          } else if (
            error instanceof LlmError
            && error.code === BENEFIT_NOT_FOUND_CODE
            && isBenefitModel
            && !benefitHeaderDropped
          ) {
            // 该账号没有 benefit 包：去掉 maas_type 头重试一次
            benefitHeaderDropped = true
            continue
          } else {
            throw error
          }
        }
      } else {
        const errorText = await response.text().catch(() => '')
        // 上游网关瞬时签名故障（`APIG.0301 … body hash mismatch`）：直接重发。
        //
        // 为什么值得自动重发：这是用户可见的一次性失败 —— 2026-10-03 用户报障
        // 「华为的还是用不了」，会话日志里两次 401（13:55、15:23）都带着
        // `APIG.0301 … body hash mismatch`，而此前同一会话的 135 轮调用全部正常、
        // 事后同一凭据重放也立刻成功。也就是说这一次失败**本来重发就能过去**，
        // 原实现却把它当凭据问题（先白刷一次凭据、再报「API 密钥无效」）。
        if (isTransientSignatureFailure(response.status, errorText) && signatureRetries < SIGNATURE_RETRY_MAX) {
          // ⚠️ **abort 后必须立刻停手**（2026-10-19 审计 I1）。`delay()` 在信号
          // 中止时是**静默 resolve**（不是 reject），若不判就直接 `continue`，
          // 循环会回到顶部**再发一次完整请求** —— 用户已经按了「停止」，网关
          // 却还在收请求（实测：基线 abort 后恒 2 次，加了这条重发后涨到 3 次）。
          //
          // ⚠️ 与下方排队路径 L1571 的 `if (options.signal?.aborted) throw` 是
          // **同一处置**，不是两份判据：排队与签名重发都要在退避后复检信号。
          if (options.signal?.aborted) {
            throw new LlmError('codearts: request aborted while retrying after a transient gateway signature failure', 'ABORTED')
          }
          signatureRetries += 1
          await delay(SIGNATURE_RETRY_DELAY_MS * signatureRetries, options.signal)
          continue
        }
        // 鉴权失败（SecurityToken 过期/被吊销/APIG.0602）：刷新一次凭据后
        // 重试整个 chat 请求。入口的 expires_at 预判无法覆盖后端提前吊销
        // 或时钟偏差场景，这里做兜底，避免把可自愈的鉴权失败抛给用户。
        if (isAuthError(response.status, errorText) && !authRefreshed) {
          authRefreshed = true
          await this.options.refresh()
          credential = await this.options.resolveCredential()
          if (credential === undefined || !credential.access_key_id || !credential.secret_access_key || !credential.security_token) {
            throw new LlmError('codearts: credential missing after refresh; log in again', 'MISSING_CREDENTIAL')
          }
          continue
        }
        // 额度用尽（**不可重试**）：与下面「限流/排队」是本质不同的两类。
        //
        // ⚠️ 必须在 `isRateLimited` **之前**判定：`insufficient quota` 这类文案
        // 若被限流判据先接走，就会被当成「重试可自愈」，而它其实是按自然日结算的
        // 确定性失败（同 `qoder` 的 `110` vs `10605` 那次教训）。
        // 实测该码主要走 SSE 通道（HTTP 200），但服务端同样可能以 4xx 下发 ——
        // 两条通道都接，避免哪天改了形态就漏（`AGENTS.md` 的既有铁律）。
        //
        // ⚠️ 判据用整个错误体（`errorDetail` 会拼出 `error_code` + `error_msg`）：
        // 4xx 的报文形态与 SSE 不同，不能指望顶层 `error_code` 字段名一致。
        // ⚠️ **分类必须走 `errorDetailForClassify`**（不含 detail 腿）—— 理由同上，
        // 用展示出口会让 detail 里的额度措辞翻转这条判据。
        if (isSseQuotaExhaustedErrorCode(errorDetailForClassify(errorText), errorText)) {
          const message = codeartsQuotaExhaustedMessage(options.model, nextUtc8DayStartMs())
          if (this.options.accountPool) {
            if (currentAccountId) {
              await this.options.accountPool.updateModelRateLimit(
                currentAccountId, options.model, nextUtc8DayStartMs(),
              )
              rateLimitTried.add(currentAccountId)
            }
            const next = await this.options.accountPool.getAvailableAccount<CodeArtsCredential>(
              'codearts', options.model, rateLimitTried,
            )
            if (next && !rateLimitTried.has(next.entry.id)) {
              rateLimitTried.add(next.entry.id)
              credential = next.credential
              currentAccountId = next.entry.id
              authRefreshed = false
              continue
            }
          }
          throw new LlmError(message, CODEARTS_QUOTA_EXHAUSTED_CODE, { status: response.status })
        }
        // ── benefit 去头重试的 **4xx 通道**（Gitee issue IKLBSH A6）──
        //
        // 同一个上游条件（该账号没有 benefit 免费额度包）会走**两条**通道下发：
        // SSE 200（`consumeSse` 已接，见 `CODEARTS_BENEFIT_NOT_FOUND_ERROR_CODE`）
        // 与 HTTP 4xx。此前**只有 200 那条接上了** —— 4xx 形态会径直落到
        // `httpErrorCode` 归成 `INVALID_REQUEST` 抛出，**去头重试一次也不试**，
        // 于是「同一条件下 SSE 能自愈、4xx 却硬报错」。
        //
        // ⚠️ 这不是推断：`origin/issue/IKJOF7-benefit-diagnostics` 分支
        //（2026-10-05 取证提交）用 `it.fails` **显式锁定**了该缺陷
        //（「HTTP 4xx + 正文含 InferHub.4004.200 时也应当去头重试」），
        // 当时的结论是「已确认，但本分支不修」——本处即补上那一半。
        //
        // 判据复用既有的 `benefitHeaderDropped` 门禁（**只试一次**）——它与
        // SSE 通道**共享同一个标记**，故两条通道叠加也只会去头一次，不会
        // 「各试一次」把请求放大成两轮。
        //
        // ⚠️ 不采纳 issue 建议的「1s / 2s / 3s 递增退避重试最多 3 次」：
        // 去头重试是**一次**（`benefitHeaderDropped` 的既有语义，注释写明
        // 「只试一次，避免与真实失败互相掩盖」），且 issue 自己给的证据是
        // 「去掉请求头后密集取样 9 次全部 200」——那说明的正是**去头即通**，
        // 而非「需要多次退避」。按证据改，不按建议改。
        if (isBenefitModel && !benefitHeaderDropped && isBenefitNotFoundBody(errorText)) {
          benefitHeaderDropped = true
          continue
        }
        // 限流处理：记录当前账号在该模型上的重置时间，然后切换账号重试
        // （外层 for(;;) 会在拿到新凭据后重新签名发请求）。用 tried 集合
        // 保证每个账号只尝试一次，试完才判定"全部受限"——避免只试一个
        // 就下结论，导致 UI 限流状态与实际判定不一致。
        //
        // ⚠️ 必须把 `response.status` 一并传入：服务端可能返回**空体**的 429，
        // 而只按正文判定时对空体恒为 false → 整段换号逻辑被跳过，本可自愈的
        // 限流被直接抛给用户（见 `isRateLimited` 的说明）。
        if (this.options.accountPool && isRateLimited(errorText, response.status)) {
          // ⚠️ 状态码必须传到 `parseRateLimitError` —— **与上面外层判据同源**。
          // 空体 429 时 `isRateLimited` 因状态码判真而放行进来，但只按正文解析的
          // `parseRateLimitError` 返回 `null`，下面的 `if (parsed)` 会把**整块**
          // （写限流标记 + 换号 + `continue`）一起跳过：既不换号、也不落标记，
          // 最终按原错误抛出 —— 「空体 429 在 CodeArts 上依旧不自愈」。
          // 这正是本补丁要修的缺陷，本处是第三条（也是最后一条）调用点。
          const parsed = parseRateLimitError(errorText, options.model, response.status)
          if (parsed) {
            if (currentAccountId) {
              await this.options.accountPool.updateModelRateLimit(
                currentAccountId, parsed.modelId, parsed.resetTimeMs,
              )
              /**
               * ⚠️⚠️ **必须把首号加进 `rateLimitTried`**（2026-10-18 审计补齐）。
               *
               * 这一格原先**既没加首号、也没把 `rateLimitTried` 传给池** —— 两处都漏。
               * 加首号是**承重**的：它是「本轮已试过」的记账，
               * 漏了它 ⇒ 首次 429 换号时排除集为空 ⇒ 池按手动顺序**把刚失败的
               * 首号再返回一次** ⇒ `rateLimitTried.has` 命中 → **换号立即终止**
               * ⇒ 报「所有账号均受限」而池里其实有可用账号。
               *
               * ⚠️ 与同文件 `:1323`（SSE 额度格）、`:1393`（HTTP 额度格）**同型** ——
               * 那两格一直都有这一行，只有本格漏了。
               */
              rateLimitTried.add(currentAccountId)
            }
            // ⚠️ 必须传 `rateLimitTried`（⚠️⚠️ **2026-10-18 修复：这一行原先漏传**）
            // —— 池按用户手动顺序返回候选，**刚被标记的账号可能仍排第一**
            // （模型级过滤命中时不会，但 `parsed.resetTimeMs` 若落在
            // `modelIds` 之外、或标记与本模型键不一致时就挡不住）⇒ 拿回同一个
            // ⇒ 命中下面的 `rateLimitTried.has` 而立即放弃换号，报
            // 「所有账号均受限」而池里其实有可用账号。
            // 与同文件 `:1331`（额度耗尽换号）、`:1395` 两处**同型同修**。
            // 该缺陷与 2026-09-17 的 `81706da`（`excludeAccountIds` 的引入
            // 动机）逐字同构，只是那一次漏在了这一格。
            const next = await this.options.accountPool.getAvailableAccount<CodeArtsCredential>(
              'codearts', options.model, rateLimitTried,
            )
            if (next && !rateLimitTried.has(next.entry.id)) {
              rateLimitTried.add(next.entry.id)
              credential = next.credential
              currentAccountId = next.entry.id
              authRefreshed = false // Reset auth refresh flag for new credential
              continue // Retry request with new credential
            }
            throw new LlmError(
              `codearts: 模型 ${options.model} 所有账号均受限，请稍后再试`,
              'QUOTA_EXCEEDED',
            )
          }
        }
        if (!isQueueError(response.status, errorText)) {
          // 非 TM.00001041 错误也未必没排队：openpangu 等模型的并发限流
          // 错误码/HTTP 状态可能与 GLM 不同，但仍会进入后端队列。先探测
          // 排队状态端点——只有端点确认会话在排队（waiting/queue_full）时
          // 才进入排队流程；端点不可达或未排队（working）则按原错误分类
          // 立即抛出，避免把真错误（如 401/400）拖成 30 分钟超时。
          const probe = await this.queryQueueStatus(credential, options.model, options.signal)
          if (probe === undefined || probe.status === 'working') {
            // 与 deepseek 适配器的 httpErrorCode 词汇保持一致；
            // 400 + 上下文超限措辞归为 CONTEXT_WINDOW_EXCEEDED（触发 compaction）。
            const code = httpErrorCode(response.status, errorText)
            throw new LlmError(`codearts: model request failed with HTTP ${response.status}`, code, { status: response.status })
          }
          // probe.status 为 'waiting' 或 'queue_full' → 落入下方排队流程。
        }
      }
      // TM.00001041 / 状态端点确认排队 / SSE 内排队错误：对齐参考实现
      // 直接重试 chat 请求，每 QUEUE_RETRY_DELAY_MS（10s）一次，上限
      // QUEUE_MAX_ATTEMPTS（180）次，不等待状态端点 working。排队期间
      // 不产出任何内容块（StreamChunk 协议没有独立的瞬态状态通道，
      // 任何 reasoning/text 块都会被 BlockAssembler 组装进 assistant
      // 消息并持久化到会话历史，reasoning 块还会显示在 web 的 Think
      // 区域，且 visible 回退可能把推理文本作为正文回传给模型），因此
      // 保持静默，web 显示 harness 自身的"运行中"状态。每次重试前查询
      // 状态端点：终态（error/queue_full）立即抛错，其余情况
      // （waiting/working/端点不可达）等待后直接重试 chat。
      queueAttempts += 1
      if (queueAttempts > QUEUE_MAX_ATTEMPTS) {
        throw new LlmError('codearts: queue wait timed out after 30 minutes', 'QUEUE')
      }
      if (options.signal?.aborted) throw new LlmError('codearts: request aborted while waiting in queue', 'QUEUE')
      const status = await this.queryQueueStatus(credential, options.model, options.signal)
      if (status?.status === 'error' || status?.status === 'queue_full') {
        throw new LlmError(`codearts: ${status.message || `queue status: ${status.status}`}`, 'QUEUE')
      }
      await delay(QUEUE_RETRY_DELAY_MS, options.signal)
      // 直接重试 chat 请求（外层 for(;;) 循环）
    }
  }

  /**
   * 消费一个 HTTP 200 的 SSE chat 响应并产出 StreamChunk。
   *
   * CodeArts 后端有时以 HTTP 200 + SSE 内嵌错误事件的形式返回排队/限流
   * （如 `InferHub.ModelArts.81111.429` TPM 超限，事件形如
   * `{"text":"[DONE]","error_code":"...","error_msg":"..."}`），而不是
   * 4xx——这类错误若直接当成流结束会被静默吞掉（表现为"思考后无输出"）。
   * 本方法解析每个 SSE 事件的 `error_code`/`error_msg`：可重试的排队/限流
   * 错误抛 {@link SseQueueRetryError} 让外层重试循环按 TM.00001041 同等
   * 处理（10s 间隔重试整个 chat 请求）；不可重试错误抛普通 LlmError。
   */
  private async *consumeSse(
    response: Response,
    options: GenerateOptions,
  ): AsyncIterable<StreamChunk> {
    if (!response.body) throw new LlmError('codearts: empty model response body', 'EMPTY_RESPONSE')
    // 块组装状态：文本 / 推理 / 工具调用各自拥有唯一
    // 索引，与 harness StreamChunk→ContentBlock 契约一致。
    const blocks: Array<{
      index: number
      kind: 'text' | 'reasoning'
      text: string
    }> = []
    let nextIndex = 0
    const toolCalls = new Map<number, {
      index: number
      text: string
      callId?: string
      name?: string
      /** 是否已发过 `block-start`（名字可用的那一刻才发，见下方 tool_calls 分支）。 */
      announced: boolean
    }>()
    const toolOrder: number[] = []
    /**
     * `tool_call` 分片 index → 后端签发的真实 id。
     *
     * ⚠️ **本兜底不可省略**（真实缺陷，2026-09-29 定位）：OpenAI 兼容协议里
     * `id` 只在**首个**分片出现，但实测华为侧偶发**完全不返回 `id`**（或返回空串）。
     * 早期实现直接把 `call.id` 写进 `block.callId`，缺失时落成**空串** id，
     * 于是 assistant 消息里留下 `{type:'tool-call', id:''}`：
     *
     * 1. `tool/call` 带着 `callId:''` 被持久化；
     * 2. 该调用完成后写 `tool/result` 时，DSH 的格式 v4 校验
     *    （`assertV4ToolResultMessage`）要求 `message.toolCallId === source.callId`
     *    且**都非空**，于是抛
     *    `format v4 tool/result at seq N requires toolCallId matching its tool source`；
     * 3. 该轮直接失败，且**会话永久报废** —— 日志停在 `tool/call`，崩溃恢复
     *    (`interruptedTurnClosers`) 按空 callId 合成修补结果时**再次**命中同一校验，
     *    既写不进也修不好。
     *
     * 空 id 同样过不了 `SessionFormatError`（它判 `length === 0`），故判据必须是
     * 「非空字符串」而不是「!== undefined」。
     *
     * 兄弟适配器（`openai-compat.ts` / `buddy-adapter.ts` / `lobsterai-adapter.ts` /
     * `trae-adapter.ts`）**都**有这层 `toolIds` 兜底，只有本文件漏了 —— 这正是
     * 该缺陷只在 `codearts` provider 复现的原因。
     *
     * ⚠️ 兜底 id 用 `call_${wireIndex}` 而非随机值：同一次响应内 index 唯一，
     * 且它必须是**稳定**的 —— 后续分片每片都要得到同一个 id。
     */
    const toolIds = new Map<number, string>()
    let buffer = ''
    let streamEnded = false
    let finishReason: 'stop' | 'tool_calls' | 'length' | undefined
    /**
     * 思考死循环检测（见 `createReasoningLoopDetector`）。命中后丢弃后续
     * reasoning 增量，收尾时发截断后的 block，并让 finish 报 max-tokens。
     *
     * 本适配器有**两处** reasoning 出口，两处都必须喂入同一判据（漏一处
     * 就等于漏一条路径）：① `emitDsmlFeed` 的 `reasoning` 聚合参数；
     * ② `delta.reasoning_content` → `dsmlReasoningExtractor` → `thinking`。
     */
    const loopGuard = isReasoningLoopGuardEnabled() ? createReasoningLoopDetector() : undefined
    let loopDetected = false
    /**
     * **正文**死循环检测（**独立实例**，见 `createReasoningLoopDetector`）。
     *
     * 真实缺陷（用户报障，2026-09-25）：唯一活动 session 出现**正文**循环，
     * 而旧实现只在 reasoning 分支调 `observe` → 正文循环完全看不见。
     *
     * ⚠️ 两个实例不可合并：判据看尾部 3000 字符窗口的行去重率，两条通道
     * 混进同一窗口会互相稀释，使守卫双双失效。
     *
     * ⚠️ 语义差异：实测正文循环的工具调用在循环正文**之后**到达且有效，
     * 故正文守卫**只截断文本**，绝不 `reader.cancel()`、绝不改 finish reason。
     *
     * ⚠️ **本适配器刻意不做 `</think:hex>` 归位**（与其余四个适配器不同）：
     * 实测那 28 处标签**全部出自 `workbuddy`**（`hy4-preview-f` 25 处、
     * `workbuddy/deepseek-v4.1-flash` 3 处），codearts 一条都没有。
     * 更关键的是，本适配器的正文出口带 **`visible` 回退**（正文为空且无工具
     * 调用时用推理文本回填可见区）—— 若在此处把正文归位成空串，回退会立刻
     * 把整段思考**复制回正文**，等于归位失效并放大问题。故此处只加守卫。
     */
    const proseLoopGuard = isReasoningLoopGuardEnabled() ? createReasoningLoopDetector() : undefined
    /**
     * DSML 标记归一化器（见 sse.ts `createDsmlMarkerNormalizer`）。
     * ⚠️ **每个 `stream()` 调用一个实例**：待定缓冲是跨帧状态，共用会串流。
     */
    const dsmlFix = createDsmlMarkerNormalizer()
    let proseLoopDetected = false
    /**
     * 纯空白思考抑制器（见 `createBlankReasoningSuppressor`）。与 `blocks` /
     * `loopGuard` 同生命周期：**每个 `stream()` 调用建一个实例**。
     *
     * ⚠️ **本适配器的两个 reasoning 出口必须共用这一个实例**：
     * ① `emitDsmlFeed` 的 `reasoning` 参数、② `delta.reasoning_content` →
     * `thinking`。两处都用 `blocks.find(kind === 'reasoning')` 找**同一个**
     * reasoning 块 —— 若各持一个 helper，第二处就会从空态重新开始累积
     * （明明已有非空白内容却被判为「至今仍空白」），`text()` 也随之错乱。
     *
     * 为什么必须延后建块：`BlockAssembler` 在**没有 `block-end`** 时同样会用
     * `partial.text` 组装出块，故只在出口过滤挡不住空 Think 块 —— 必须从一开始
     * 就不发任何 chunk（与「空名字 tool_call」同型修法）。
     */
    const suppressor = createBlankReasoningSuppressor()
    // DSML 提取器：从 delta.content 中识别模型以原生 DSML XML 风格
    // 写入的工具调用（deepseek-v4 等模型在工具模式不匹配时会直接
    // 输出 `<｜DSML｜tool_calls>...`），解析为结构化 tool-call，
    // 避免原始 token 泄漏到 web UI。
    // content 与 reasoning_content 两个通道使用各自独立的 DSML 提取器。
    // 早期实现共用单个提取器，但 deepseek-v4 有时在 content 通道输出
    // <thought> 开标签（提取器进入 in-thought 状态）后，把后续推理与
    // DSML 工具调用写到 reasoning_content 通道——共用提取器会把
    // reasoning_content 的 DSML 块当作 thought 内容吞掉，不解析为
    // tool-call，最终残留 DSML 标签经 visible 回退泄漏到正文（实测
    // session-067dcf78 turn1 step13 / turn2 step3）。独立提取器让各
    // 通道状态机互不污染。
    const dsmlContentExtractor = new DsmlContentExtractor()
    const dsmlReasoningExtractor = new DsmlContentExtractor()
    // 分流 DSML 提取结果：正文文本进入 text 块、thought 进入 reasoning
    // 块、解析出的工具调用进入 tool-call 块。
    async function* emitDsmlFeed(
      text: string,
      reasoning: string,
      dsmlCalls: Array<{ name: string; arguments: string }>,
    ): AsyncIterable<StreamChunk> {
      if (text.length > 0) {
        let block = blocks.find(candidate => candidate.kind === 'text')
        if (block === undefined) {
          block = { index: nextIndex++, kind: 'text', text: '' }
          blocks.push(block)
          yield { type: 'block-start', index: block.index, blockType: 'text' }
        }
        // 正文死循环守卫（见 `proseLoopGuard` 注释）。命中后只停止累积与发射，
        // 绝不 `reader.cancel()`、绝不改 finish reason。
        if (proseLoopGuard !== undefined) {
          if (proseLoopGuard.observe(text)) proseLoopDetected = true
        }
        if (!proseLoopDetected) {
          // ⚠️ **先归一化再累积**（2026-10-13）：本文件是 codearts 等多家渠道的
          //    基础正文出口，此前**漏接**归一化 —— 实测重启后会话仍有 270 处
          //    `<｜｜DSML｜｜` 坏标记，正是走这条路径（首批只覆盖了
          //    openai-compat 与 buddy）。push() 流式安全，
          //    见 sse.ts `createDsmlMarkerNormalizer`。
          const fixedText = dsmlFix.push(text)
          block.text += fixedText
          if (fixedText.length > 0) {
            yield { type: 'text-delta', index: block.index, text: fixedText }
          }
        }
      }
      if (reasoning.length > 0) {
        // 死循环守卫：命中后不再累积、不再发射。
        //
        // ⚠️ 这里**只跳过发射**：真正的止损（`reader.cancel()` + `break`）在
        // 本 chunk 的行循环**全部处理完之后**、外层 `for (;;)` 末尾执行（见下方
        // ★ 止损块）—— 这样同一 chunk 里已到达的 usage / [DONE] 仍会被处理。
        // 若在此处直接 `break`，本 chunk 剩余的行会被整块跳过。
        // ⚠️ 也**不能用 `continue`**（Task 2 审查发现并已实测复现）：它会
        // 连带跳过**同一帧内**位于本分支之后的处理（`usage` 记账、DSML
        // tool-call 解析），导致 token 统计静默丢失。故用 `if (!loopDetected)`
        // 守卫分支体。
        if (loopGuard !== undefined) {
          if (loopGuard.observe(reasoning)) loopDetected = true
        }
        if (!loopDetected) {
          // 纯空白思考：`emit === undefined` ⇒ 本片一个 chunk 都不发，
          // 于是既不建块、也不消耗 `nextIndex`（见 helper 注释）。
          const emit = suppressor.feed(reasoning)
          if (emit !== undefined) {
            let block = blocks.find(candidate => candidate.kind === 'reasoning')
            if (block === undefined) {
              block = { index: nextIndex++, kind: 'reasoning', text: '' }
              blocks.push(block)
              yield { type: 'block-start', index: block.index, blockType: 'reasoning' }
            }
            // ⚠️ **整块回写**（赋值，不是 `+=`）：helper 内部已累积全部文本，
            // 用 `+=` 会双写。本适配器两个出口共用同一 helper，故回写值恒为
            // 两处共同累积的完整文本。
            block.text = suppressor.text()
            yield { type: 'reasoning-delta', index: block.index, text: emit }
          }
        }
      }
      for (const call of dsmlCalls) {
        // 与 delta 路径同一条判据：名字不可用的调用**一个 chunk 都不产出**
        // （否则 `BlockAssembler` 会组装出 `name:''` 的块并污染会话，
        // 让下游端点以 400 code 11133 拒绝之后每一次请求）。
        if (!hasUsableToolName(call.name)) continue
        const wireIndex = toolCalls.size
        // DSML 语法没有 provider 签发的 call id，必须生成唯一 id：
        // harness 的 tool/call ↔ tool/result 配对与 web UI 的工具行
        // 渲染都用 callId 作为 key（见 client-runtime 匹配器
        // `tool/call -> id: String(callId)`），空 id 会让同一响应的
        // 多个工具调用（或历史重放）配对冲突，UI 只能回退为泛化的
        // "Tool call" 行而丢失 read/write 专属控件。
        const block = {
          index: nextIndex++,
          text: call.arguments,
          name: call.name,
          callId: ToolCallId(`dsml-${crypto.randomUUID().replace(/-/g, '')}`),
          announced: true,
        }
        toolCalls.set(wireIndex, block)
        toolOrder.push(block.index)
        yield { type: 'block-start', index: block.index, blockType: 'tool-call' }
        yield {
          type: 'tool-call-delta',
          index: block.index,
          id: block.callId,
          name: block.name,
          argumentsDelta: call.arguments,
        }
      }
    }
    const reader = response.body.getReader()
    const decoder = new TextDecoder()
    // 首 token 与 chunk 间超时分阶段使用（对齐 CodeArts Agent IDE）：
    // 第一次读取用 firstTokenTimeout（5min），收到首 chunk 后切换为
    // chunkTimeout（10min），并在每次成功读取后重置。deepseek-v4-flash
    // 生成大文件 write 的 content 参数时，首 token 后可能长时间静默，
    // 需要远大于网关 60s 的窗口才不会误判可重试 TIMEOUT 而反复重试。
    let firstTokenReceived = false
    try {
      for (;;) {
        if (streamEnded) break
        // CodeArts 网关对 SSE 有 ~60s 空闲超时：模型生成长推理 / 大工具
        // 参数时两次 chunk 间可能静默数十秒，连接被对端掐断后 reader.read()
        // 抛 `TypeError: terminated`（非 HarnessError → UNKNOWN 不可重试 →
        // harness 直接失败）。以略小于网关超时的窗口主动检测空闲：超时则
        // 取消 reader 并抛可重试 TIMEOUT；同时把传输级错误映射为可重试
        // TRANSPORT，让 harness 重试该步骤而非直接失败。
        let done: boolean
        let value: Uint8Array | undefined
        try {
          const timeoutMs = firstTokenReceived ? resolveChunkTimeoutMs() : resolveFirstTokenTimeoutMs()
          const phase = firstTokenReceived ? 'chunk' : 'first-token'
          const result = await readCodeArtsChunk(reader, timeoutMs, options.signal, phase)
          done = result.done
          value = result.value
          if (!done) firstTokenReceived = true
        } catch (error) {
          if (options.signal?.aborted) throw error
          if (error instanceof LlmError) throw error
          if (isTransportError(error)) {
            throw new LlmError(`codearts: sse transport error: ${errorMessage(error)}`, 'TRANSPORT', { cause: error })
          }
          throw error
        }
        if (done) break
        buffer += decoder.decode(value!, { stream: true })
        let newline: number
        while ((newline = buffer.indexOf('\n')) !== -1) {
          const line = buffer.slice(0, newline).trim()
          buffer = buffer.slice(newline + 1)
          if (!line.startsWith('data:')) continue
          const payload = line.slice(5).trim()
          if (payload === '[DONE]') {
            streamEnded = true
            break
          }
          let data: {
            error_code?: string
            error_msg?: string
            choices?: Array<{
              delta?: {
                content?: string
                reasoning_content?: string
                tool_calls?: Array<{
                  index?: number
                  id?: string
                  function?: { name?: string; arguments?: string }
                }>
              }
              finish_reason?: string
            }>
            usage?: Record<string, number>
          }
          try {
            data = JSON.parse(payload)
          } catch {
            continue
          }
          // SSE 内嵌错误检测：CodeArts 以 HTTP 200 + error_code/error_msg
          // 返回排队/限流（如 InferHub.ModelArts.81111.429 TPM 超限）。
          if (typeof data.error_code === 'string' && data.error_code.length > 0) {
            const message = typeof data.error_msg === 'string' && data.error_msg.length > 0
              ? data.error_msg
              : data.error_code
            // ⚠️ 顺序不可颠倒：额度耗尽（InferHub.4291.200）必须**先**于排队判据
            // 检查。历史上它们混淆过一次 —— `4291` 被 `429` 的裸子串匹配吃掉，
            // 额度错误因此被当成「可重试的排队」，进入 30 分钟静默重试循环，
            // 界面零输出（用户报障「没反应」的直接原因）。
            // 现在两个判据已互斥（裸 `429` 已锚定为独立数字），这里的先后仍保留：
            // 它把「额度优先」表达成代码结构，防止后续再有人放宽 `429` 判据。
            if (isSseQuotaExhaustedErrorCode(data.error_code, message)) {
              throw new SseQuotaExhaustedError(data.error_code, message)
            }
            if (isSseQueueErrorCode(data.error_code)) {
              throw new SseQueueRetryError(data.error_code, message)
            }
            if (data.error_code === CODEARTS_BENEFIT_NOT_FOUND_ERROR_CODE) {
              // 账号没有 benefit 包（积分制账户）：交给 stream() 去掉该头重试
              throw new LlmError(`codearts: ${message}`, BENEFIT_NOT_FOUND_CODE, { status: 200 })
            }
            throw new LlmError(`codearts: ${message}`, 'INVALID_REQUEST', { status: 200 })
          }
          const choice = data.choices?.[0]
          const delta = choice?.delta
          if (typeof choice?.finish_reason === 'string') {
            finishReason = choice.finish_reason as 'stop' | 'tool_calls' | 'length'
          }
          if (delta?.content) {
            // 通过 DSML 提取器：纯文本作为 text-delta 放行，
            // <thought> 内容作为 reasoning-delta 放行（显示在 Think 区域），
            // DSML 块解析为结构化 tool-call（与 delta.tool_calls 路径
            // 合并到同一 toolCalls/toolOrder 状态）。
            const { text, reasoning, toolCalls: dsmlCalls } = dsmlContentExtractor.feed(delta.content)
            yield* emitDsmlFeed(text, reasoning, dsmlCalls)
          }
          if (delta?.reasoning_content) {
            // 模型放在 reasoning_content 通道的内容就是思考，必须进入
            // reasoning 块（Think 区域），绝不能作为正文输出。实测
            // （2026-08-22）：deepseek-v4-flash 的 reasoning_content 通常
            // 没有 <thought> 标签，提取器会把整段当作 `text` 返回——若把
            // `text` 发给正文块，思考就泄漏到正文（TUI 显示 The user wants
            // me to... 跑到正文）。因此这里把 `text + reasoning` 合并后
            // 全部作为 reasoning 输出，仅 DSML 工具调用块单独解析执行。
            const { text, reasoning, toolCalls: reasoningDsmlCalls } = dsmlReasoningExtractor.feed(delta.reasoning_content)
            const thinking = text + reasoning
            if (thinking.length > 0) {
              // 死循环守卫：与上面 `emitDsmlFeed` 的 `reasoning` 分支同一判据，
              // 两条出口都要接（漏一处就等于漏一条路径）。
              //
              // ⚠️ 守卫必须**同时包住** `block.text += thinking` 与 `yield`
              // 两行 —— 只拦 yield 的话，累积文本仍含循环内容，收尾的截断
              // 就失效了。这里**只跳过发射**：止损（`reader.cancel()` + `break`）
              // 在本 chunk 行循环处理完之后执行（见下方 ★ 止损块），故同帧的
              // usage 记账不受影响；**也不能用 `continue`**（会连带跳过本帧
              // 之后的 usage 记账）。
              if (loopGuard !== undefined) {
                if (loopGuard.observe(thinking)) loopDetected = true
              }
              if (!loopDetected) {
                // 纯空白思考：`emit === undefined` ⇒ 本片一个 chunk 都不发。
                // ⚠️ 与出口①共用**同一个** `suppressor`：两处落在同一个
                // `blocks.find(kind === 'reasoning')` 块上，各自累积会错乱
                // （出口②会误判「整块迄今仍空白」而丢弃本已有内容的块）。
                const emit = suppressor.feed(thinking)
                if (emit !== undefined) {
                  let block = blocks.find(candidate => candidate.kind === 'reasoning')
                  if (block === undefined) {
                    block = { index: nextIndex++, kind: 'reasoning', text: '' }
                    blocks.push(block)
                    yield { type: 'block-start', index: block.index, blockType: 'reasoning' }
                  }
                  // ⚠️ **整块回写**（赋值，不是 `+=`）。
                  block.text = suppressor.text()
                  yield { type: 'reasoning-delta', index: block.index, text: emit }
                }
              }
            }
            for (const call of reasoningDsmlCalls) {
              // 同 delta 路径：名字不可用者一个 chunk 都不产出（见上）。
              if (!hasUsableToolName(call.name)) continue
              const wireIndex = toolCalls.size
              const block = {
                index: nextIndex++,
                text: call.arguments,
                name: call.name,
                callId: ToolCallId(`dsml-${crypto.randomUUID().replace(/-/g, '')}`),
                announced: true,
              }
              toolCalls.set(wireIndex, block)
              toolOrder.push(block.index)
              yield { type: 'block-start', index: block.index, blockType: 'tool-call' }
              yield {
                type: 'tool-call-delta',
                index: block.index,
                id: block.callId,
                name: block.name,
                argumentsDelta: call.arguments,
              }
            }
          }
          for (const call of delta?.tool_calls ?? []) {
            const wireIndex = call.index ?? 0
            // ⚠️ 只接受**非空** id 并记住它：后续分片可能新一轮又给空串/缺失，
            // 无条件覆盖会把首片拿到的真实 id 抹成空（与 `function.name` 同因）。
            if (typeof call.id === 'string' && call.id.length > 0) toolIds.set(wireIndex, call.id)
            const callId = toolIds.get(wireIndex) ?? `call_${wireIndex}`
            let block = toolCalls.get(wireIndex)
            if (block === undefined) {
              block = { index: nextIndex++, text: '', announced: false }
              toolCalls.set(wireIndex, block)
            }
            block.callId = callId
            // 后续参数分片会带上空的 function.name（""），它不是 undefined，
            // 直接覆盖会把首个分片解析出的真实工具名清空，导致
            // `unknown tool ""`。只有非空名字才允许更新。
            if (typeof call.function?.name === 'string' && call.function.name.length > 0) {
              block.name = call.function.name
            }
            const fragment = call.function?.arguments ?? ''
            block.text += fragment
            // ⚠️ **名称为空前不发射任何 chunk**（与 `openai-compat.ts` / `buddy-adapter.ts`
            // 同因同修）。只跳过收尾的 `block-end` 不够 —— `BlockAssembler`
            // 会把没有 block-end 的 partial 也组装成 `name:''`，污染会话后让
            // 腾讯系端点以 400 code 11133 拒绝之后每一次请求。
            if (!block.announced) {
              if (!hasUsableToolName(block.name)) continue
              block.announced = true
              toolOrder.push(block.index)
              yield { type: 'block-start', index: block.index, blockType: 'tool-call' }
              yield {
                type: 'tool-call-delta',
                index: block.index,
                id: ToolCallId(callId),
                name: block.name!,
                argumentsDelta: block.text,
              }
              continue
            }
            yield {
              type: 'tool-call-delta',
              index: block.index,
              id: ToolCallId(callId),
              ...block.name !== undefined ? { name: block.name } : {},
              argumentsDelta: fragment,
            }
          }
          if (data.usage) {
            const promptTokens = data.usage.prompt_tokens ?? 0
            const cachedTokens = (data.usage as { prompt_tokens_details?: { cached_tokens?: number } }).prompt_tokens_details?.cached_tokens
              ?? (data.usage as { prompt_cache_hit_tokens?: number }).prompt_cache_hit_tokens
              ?? 0
            const cacheWriteTokens = (data.usage as { prompt_tokens_details?: { cache_write_tokens?: number } }).prompt_tokens_details?.cache_write_tokens
            const reasoningTokens = (data.usage as { completion_tokens_details?: { reasoning_tokens?: number } }).completion_tokens_details?.reasoning_tokens
            yield {
              type: 'usage',
              usage: {
                inputTokens: cachedTokens > 0 ? promptTokens - cachedTokens : promptTokens,
                outputTokens: data.usage.completion_tokens ?? 0,
                ...cachedTokens > 0 ? { cacheReadTokens: cachedTokens } : {},
                ...cacheWriteTokens !== undefined && cacheWriteTokens > 0 ? { cacheWriteTokens } : {},
                ...reasoningTokens !== undefined && reasoningTokens > 0 ? { reasoningTokens } : {},
              },
            }
          }
        }
        // ★ 止损（终审 C1）：命中死循环后**中止上游**，否则 128000 token 照烧。
        // 原实现只跳过下行累积/发射，`for (;;)` 仍把流读到底 —— 实测上游
        // 200 帧被读 200 帧（守卫在 ~2304 字符即命中，99.5% 的额度仍被消耗）。
        //
        // ⚠️ 位置：内层行循环**之后**、外层 `for (;;)` 末尾 —— 同一 chunk 里已到达
        // 的 `usage` / `[DONE]` 因此仍会被处理，但命中后**立即**退出，不再读下一块。
        //
        // ⚠️ 只 cancel **reader**，绝不 abort `options.signal`：后者是调用方信号，
        // abort 会被上层报成「用户取消」而非**标记为不完整**的 `max-tokens`
        // （DSH 在 `max-tokens` 时**不自动重试**，由用户/上层决定是否继续）。
        // ⚠️ `.catch(() => {})` 不可省：连接已断时 `cancel()` 会抛错，不吞掉会把
        // 「正常止损」变成一次失败。
        if (loopDetected) {
          await reader.cancel().catch(() => {})
          break
        }
      }
    } finally {
      reader.releaseLock()
    }
    // 流结束：分别 flush content 与 reasoning_content 两个独立 DSML 提取器。
    // 若模型输出了不完整的 DSML 块（被 max_tokens 截断或模型异常终止），
    // 残留内容作为纯文本放行，避免吞掉用户可见内容；不完整的 <thought>
    // 块作为 reasoning 放行，避免推理泄漏到正文；同时让 finish_reason='length'
    // 路径生效，触发 harness max-tokens 续写而非执行不完整工具调用。
    // 复用 emitDsmlFeed 把残留 text/reasoning 路由到对应块。
    {
      const f = dsmlContentExtractor.flush()
      if (f.text.length > 0 || f.reasoning.length > 0) yield* emitDsmlFeed(f.text, f.reasoning, [])
    }
    {
      const f = dsmlReasoningExtractor.flush()
      if (f.text.length > 0 || f.reasoning.length > 0) yield* emitDsmlFeed(f.text, f.reasoning, [])
    }
    // 按创建顺序关闭每个块。GLM 端点偶尔把整个回答作为 reasoning_content
    // 发出且 content 为空：此时正文区为空，回退用推理文本填充可见区。
    // 但若推理中解析出了 DSML 工具调用（deepseek-v4 的 reasoning_content
    // 内嵌工具块），正文由工具调用承担，不再把推理复制为可见文本。
    const textBlock = blocks.find(block => block.kind === 'text')
    const reasoningBlock = blocks.find(block => block.kind === 'reasoning')
    // 命中死循环时只保留循环前的干净前缀（`cutAt`）。`block-end` 是
    // **权威覆盖**（已由 `scripts/verify-blockend-override.ts` 实证）：
    // 即便前面已 yield 了全部重复 delta，这里发截断后的 block 即可，无需撤回。
    //
    // ⚠️ 行首 `course` / `课` 泄漏清洗（`stripCourseLeak`）**在此处一次性完成**：
    // `reasoningText` 同时供 `reasoningHasDsml` 判定、`visible` 回退与
    // reasoning `block-end` 使用，故在此清洗可覆盖全部三处出口，
    // 不会出现「正文干净而 Think 区仍脏」或反之的不一致。
    const reasoningText = stripCourseLeakIfEnabled(
      loopDetected && loopGuard?.cutAt !== undefined
        // ⚠️ 文本以 helper 为权威（`suppressor.text()`），**不用**
        // `reasoningBlock.text` —— 两个出口共用同一 helper，以它为准才能保证
        // 累积口径一致；`reasoningBlock` 仅用于取块 `index`。
        ? suppressor.text().slice(0, loopGuard.cutAt)
        : suppressor.text(),
    )
    // visible 回退：正文为空且无工具调用时，用推理文本填充可见区（GLM 端点
    // 偶尔把整个回答作为 reasoning_content 输出）。但若推理含 DSML 标签
    // （deepseek-v4 在推理中引用 DSML 语法讨论实现方案，非完整工具调用块），
    // 不能复制为正文——DSML 标签泄漏到正文会被模型当用户输入，导致任务
    // 终止或循环（实测 session-a69fa289 turn2 step26：推理仅含 DSML 闭合
    // 标签片段，visible 回退复制到正文后任务终止）。此时正文留空，推理仍
    // 在 Think 区域可见。
    //
    // ⚠️ 回退必须用**截断后**的 `reasoningText`，不能用 `reasoningBlock.text`：
    // 命中死循环时正文恰好为空且无工具调用，用原文会把病态循环全文复制进
    // 正文块并持久化，下次重放又要重新吃一遍（正是本守卫要根除的问题）。
    const reasoningHasDsml = reasoningText.includes('｜DSML｜')
    // ⚠️ 正文出口也必须清洗 —— 不能只清 reasoning。
    //
    // 本适配器的 `visible` 有**两条来源**：正文块，或（正文为空且无工具调用时的）
    // reasoning 回退。初版只对 reasoning 侧调了 `stripCourseLeakIfEnabled`，
    // 正文侧直接取 `textBlock.text` 原值 —— 于是「正文块里带行首泄漏」这一路径
    // 完全没被覆盖，`block-end` 发出去的仍是脏文本（同型缺陷见
    // `buddy-adapter.ts` / `lobsterai-adapter.ts` / `trae-adapter.ts` 的
    // text 出口，那几处均已清洗）。
    //
    // 清洗放在**取值处**而非 `block-end` 处：`visible` 同时供 text `block-end`
    // 与下方回退判定使用，在此清洗可保证两条出口一致（不会出现「正文块干净、
    // 回退脏」或反之）。`reasoningText` 已是清洗后的值，故回退分支无需再清。
    // 正文死循环截断：只保留循环前的干净前缀。
    // ⚠️ **不改 finish reason**：工具调用仍要被执行。
    //
    // ⚠️ 截断必须在 `visible` 回退**之前**应用：否则「正文命中循环 → 截断后为空
    // → 回退又把推理文本复制进正文」会把病态循环原样搬到可见区。
    // ── DSML 归一化收尾：下发待定缓冲 ──（与 openai-compat.ts / buddy 同款）
    // 扣住的尾部在流结束时必须放行，否则最后几个字符永远不到达宿主。
    {
      const tail = dsmlFix.flush()
      if (tail.length > 0 && !proseLoopDetected) {
        const tailBlock = blocks.find(candidate => candidate.kind === 'text')
        if (tailBlock !== undefined) {
          tailBlock.text += tail
          yield { type: 'text-delta', index: tailBlock.index, text: tail }
        }
      }
    }
    const truncatedText = proseLoopDetected && proseLoopGuard?.cutAt !== undefined
      ? (textBlock?.text ?? '').slice(0, proseLoopGuard.cutAt)
      : undefined
    const visible = truncatedText !== undefined
      ? stripCourseLeakIfEnabled(truncatedText)
      : textBlock !== undefined && textBlock.text !== ''
        ? stripCourseLeakIfEnabled(textBlock.text)
        // ⚠️ `!loopDetected` 门禁**不可省**：命中思考死循环时若仍做该回退，
        // `visible` 会变成那段**被截断的循环垃圾**，于是下面的
        // `reasoningLoopIsSoleOutput` 判据恒为假 → 永远落回 max-tokens，
        // 「有分辨力的错误提示」在 codearts 这条路径上**静默失效**。
        // 且把循环垃圾回填进正文正是本守卫要根除的问题（见上方注释）。
        : reasoningBlock !== undefined && toolOrder.length === 0 && !reasoningHasDsml && !loopDetected
          ? reasoningText
          : ''
    /**
     * 本次响应**实际会发出的 `block-end` 数量**（＝真正落进 assistant 消息的块数）。
     *
     * ⚠️ **不能写成 `blocks.length`**：`blocks` 里可能留着**不会发出**的条目 ——
     * 纯空白思考块（已被 `suppressor` 压制，连 `block-start` 都没发）、
     * 或被 `cutAt` / `course` 清洗成空串的块。用 `blocks.length` 会把
     * 「零块响应」误判成「有块」，于是静默结束的缺陷原样保留。
     *
     * 故此处**在每个 `block-end` 的发射点自增**，与下面三段发射逻辑逐条对齐。
     * 本适配器有**两个**容易算错的地方：
     *
     * 1. **正文块的条件含 `visible` 回退**：判据是
     *    `textBlock !== undefined || visible !== ''`（不是只看 `textBlock`）。
     *    `visible` 在「正文为空且无工具调用」时用推理文本填充 —— 此时
     *    `textBlock` 可能是 `undefined`（正文一个 delta 都没收到），
     *    但块**确实会发出**。只数 `textBlock` 会漏掉它、把一个非空响应
     *    误判成零块。
     * 2. **reasoning 块是双层条件**：外层 `trim() !== ''`、内层
     *    `reasoningText !== ''`。只有两层都过才真的发 `block-end`。
     */
    let blockCount = 0
    for (const index of toolOrder) {
      const block = [...toolCalls.values()].find(candidate => candidate.index === index)!
      // `toolOrder` 只收「名字已可用」的块，故此处名字必然可用；不回退成
      // `?? ''` —— 那会把空名字块写进会话，正是本次修复要根除的污染路径。
      if (!hasUsableToolName(block.name)) continue
      blockCount += 1
      yield {
        type: 'block-end',
        index,
        block: {
          type: 'tool-call',
          // ⚠️ 判据用 `||`（同时兜 undefined 与空串），**不可**退回成
          // `block.callId ?? ''`：空串 id 会被格式 v4 校验拒绝（它判
          // `length === 0`），落库即等于报废整条会话（见上方 `toolIds` 注释）。
          // 正常路径下 `block.callId` 已在建块时填好，此处仅为最后一道防线。
          id: ToolCallId(block.callId || `call_${index}`),
          name: block.name!,
          // 同上：空分片补 {}，残缺参数保持原样交由截断判定处理。
          arguments: isTruncatedArguments(block.text)
            ? block.text
            : normalizeToolArguments(block.text),
        },
      }
    }
    // ⚠️ 计数条件必须与上面的**发射**条件逐字一致（含 `|| visible !== ''`）：
    // `visible` 回退会用推理文本回填正文，只数 `textBlock` 会把「有正文」误判成
    // 零块、进而错报 EMPTY_RESPONSE。
    //
    // 就当前实现而言，`|| visible !== ''` 这一半在**计数**上是冗余的防御
    // （`visible !== ''` 蕴含 reasoning 那块也非空，下一段的计数必命中，
    // 故块数不会因此为 0）—— 已用变异测试证实。但在**发射**上它是必需的
    // （去掉它会让 `llm-adapter.spec.ts` 的 visible 回退用例失败）。
    if (textBlock !== undefined || visible !== '') {
      blockCount += 1
      yield { type: 'block-end', index: textBlock?.index ?? nextIndex, block: { type: 'text', text: visible } }
    }
    // ⚠️ 判据收紧为 `trim() !== ''`：纯空白思考不得被算作「有 reasoning 产出」。
    // 文本改用上面的 `reasoningText`（源自 `suppressor.text()`，已应用 cutAt
    // 截断与 course 清洗），保证与 `visible` 回退、`reasoningHasDsml` 同一口径。
    if (reasoningBlock !== undefined && reasoningBlock.text.trim() !== '') {
      if (reasoningText !== '') {
        blockCount += 1
        yield { type: 'block-end', index: reasoningBlock.index, block: { type: 'reasoning', text: reasoningText } }
      }
    }
    // finish_reason 映射顺序很关键：'length'（输出被 max_tokens 截断）必须优先于
    // 工具调用检查。若先看 toolOrder.length > 0，截断的工具调用会被报告为
    // 'tool-calls'，harness 将执行其不完整的 JSON 参数（报 INVALID_ARGS），并
    // 把截断参数持久化进会话历史——web 加载历史时 presenter 解析也会失败
    // （"Unterminated string in JSON"）。报告 max-tokens 后，dsh 会丢弃不完整的
    // 工具调用并触发 max-tokens 续写（分批生成），避免脏数据与错误执行。
    //
    // 另：丢弃了无名 tool-call 且没有留下任何可用调用时，同样报 max-tokens 而
    // 非 stop —— 否则模型本意调工具、harness 却认为「正常答完了」，
    // 又是一次无报错中断（与 `openai-compat.ts` 同因同修）。
    const droppedUnnamedCalls = [...toolCalls.values()].some(block => !block.announced)
    /**
     * 思考死循环是否**是唯一的产出**（无可见正文、无工具调用）。
     *
     * ⚠️ 与 `buddy-adapter.ts` / `openai-compat.ts` 同因同修（Gitee !IKIZNK）：
     * 只有该步没有可见产出时才报 `error` —— `error` 路径**不落
     * `assistant/message`**（实测 219 会话里 222 例），有可见内容时报它会把内容
     * 整块丢掉。
     *
     * ⚠️ 判据用 `visible`（＝真正会发出去的正文块文本）而**不是** `textBlock`：
     * 本适配器有「正文为空且无工具调用时用推理文本回填正文」的回退（见下方
     * `visible` 的定义），该回退会让正文块非空 —— 只看 `textBlock` 会误判成
     * 「没有可见产出」，于是报 error 把那块回填文本静默丢掉。
     * 为配合本判据，回退分支也已加上 `!loopDetected` 门禁（见下方注释）。
     */
    const reasoningLoopIsSoleOutput = loopDetected
      && visible === ''
      && toolOrder.length === 0
    const reason = reasoningLoopIsSoleOutput
      // 思考死循环且无可见产出：报**有分辨力的 error**（见 REASONING_LOOP_CODE）。
      // ⚠️ 不能报 max-tokens —— UI 对它的固定文案是「已达到输出 token 上限」，
      // 把「检测到死循环」误导成「额度用满」（真实缺陷，Gitee !IKIZNK）。
      ? { kind: 'error' as const, failure: reasoningLoopFailure(
          loopGuard?.diagnostics,
          options.maxTokens,
          'reasoning',
        ) }
      // 循环命中但另有可见产出：只能报 max-tokens（保住内容），不能报 error。
      : loopDetected
        ? { kind: 'max-tokens' as const }
      : finishReason === 'length'
        || (droppedUnnamedCalls && toolOrder.length === 0)
        ? { kind: 'max-tokens' as const }
        : finishReason === 'tool_calls' || toolOrder.length > 0
          ? { kind: 'tool-calls' as const }
          : { kind: 'stop' as const }
    // 零内容块响应（例如本次只收到过那个被压制的空白 reasoning）否则会以
    // `stop` 收场 —— 那是 DSH `EMPTY_RESPONSE` 契约明令禁止的静默结束。
    // ⚠️ 传入的是**上面已算好的** `reason`（含 loopDetected / length /
    // 无名 tool-call 等全部既存判据）；helper 只在 `kind === 'stop'` 时改写。
    yield { type: 'finish', reason: resolveEmptyResponseReason(reason, blockCount) }
  }

  /**
   * 查询某个会话的 CodeArts 并发队列状态。该端点
   * 与 chat API 一样使用 AK/SK 签名；GET 不携带请求体，因此无 content-type。
   * @param credential - 用于签名请求的 AK/SK/SecurityToken。
   * @param model - 模型 id，作为 `model` 查询参数回传。
   * @param signal - 状态请求的取消信号。
   * @returns 解析后的排队状态，或当端点不可达
   *   或返回无法识别的载荷时返回 `undefined`。
   */
  private async queryQueueStatus(
    credential: CodeArtsCredential,
    model: string,
    signal?: AbortSignal,
  ): Promise<CodeArtsQueueStatus | undefined> {
    const url = `${QUEUE_STATUS_BASE}?model=${encodeURIComponent(model)}&task_id=${encodeURIComponent(this.sessionId)}`
    const signed = await signRequestHuawei(
      credential.access_key_id,
      credential.secret_access_key,
      credential.security_token,
      'GET',
      url,
      new Uint8Array(),
    )
    const headers = new Headers()
    signed.forEach((value, key) => { if (key !== 'content-type') headers.set(key, value) })
    headers.set('x-snap-traceid', crypto.randomUUID())
    headers.set('Agent-Type', 'INFERHUB_AGENT')
    headers.set('X-Language', 'en')
    let response: Response
    try {
      response = await this.fetchImpl(url, { method: 'GET', headers, signal })
    } catch {
      return undefined
    }
    if (response.status !== 200) return undefined
    let body: Record<string, unknown>
    try {
      body = await response.json() as Record<string, unknown>
    } catch {
      return undefined
    }
    const status = body.status
    if (status !== 'waiting' && status !== 'working' && status !== 'error' && status !== 'queue_full') return undefined
    return {
      status,
      queuePosition: Number(body.queue_position ?? -1),
      message: typeof body.message === 'string' ? body.message : '',
    }
  }
}

/** 在 ctx.llm 上注册 codearts 提供商路由和适配器。 */
export function registerCodeArtsLlm(ctx: Context, options: CodeArtsAdapterOptions): CodeArtsAdapter {
  const adapter = new CodeArtsAdapter({
    ...options,
    // ⚠️ 注入**唯一**的广播实现（`src/catalog-broadcast.ts`），不要在这里
    // 另写一份 emit —— 两份实现必然漂移（issue IKJVTF 的缺陷① 就是「十处全漏」）。
    onCatalogLoaded: () => broadcastCatalogChanged(ctx),
  })
  registerAdapterIdempotent(ctx.llm, [PROVIDER], adapter)
  // 返回实例：Jet Hub「显示列表」需要 `listAllModels()`（不受黑名单影响、
  // 带最终展示名）。`ctx.llm` 不透传自定义方法，须由调用方持有引用。
  return adapter
}

/**
 * CodeBuddy 系（buddy / workbuddy）表示「用量超出频率限制」的业务码。
 *
 * 判据优先用结构化业务码而非文案：**它与语言无关**，且不受服务端改文案影响。
 * 国际版与国内版用的是同一个码（实测均为 6004），只有 msg 文案分中英文。
 */
const RATE_LIMIT_BUSINESS_CODE = 6004

/**
 * 限流文案的**自然语言兜底**判据。
 *
 * 为什么需要兜底：并非所有限流错误都带得上结构化 code —— SSE 流内错误、
 * 网关返回的裸文本、以及 CodeArts（华为云）的中文错误都只有文案可判。
 *
 * ⚠️ **中英文都必须列全**。历史缺陷（用户报障，仅国际版暴露）：此处早期只有
 * 中文词（频率限制 / 使用量已超出 / 频率超出 / 重置），而国际版 WorkBuddy
 * （www.workbuddy.ai）返回的是英文
 * `usage exceeds frequency limit ... your usage will reset at <时间> UTC+8`。
 * 结果 `isRateLimited` 恒为 false → 适配器**跳过整个账号切换分支**，直接抛出
 * 原始 6004 JSON；错误码也因 HTTP 400 退化成 INVALID_REQUEST 而非
 * QUOTA_EXCEEDED。国内版返回中文文案，所以该缺陷只在国际版复现。
 *
 * `too many requests` 是标准 OpenAI 429 措辞，一并纳入。
 */
const RATE_LIMIT_PATTERN =
  /频率限制|频率超出|使用量已超出|重置|rate.?limit|frequency limit|usage exceeds|too many requests/i

/**
 * 腾讯网关「**模型饱和**」业务码（HTTP 429）。
 *
 * ## 它必须与额度限流（6004）分开（真实报障，2026-10-05）
 *
 * 用户第一次用 `buddy/space-bunny` 就报「模型 space-bunny 所有账号均受限」。
 * 直连实测（`scripts/probe-buddy-error-catalog.mjs`）逼出了服务端原话：
 * ```json
 * {"code":14003,"msg":"too many requests",
 *  "displayMsg":{"zh":"模型繁忙，请换模型或稍后重试"},
 *  "displayTips":{"zh":"这个模型当前请求量饱和，与你的网络无关。请换个模型，或稍等一会儿再重试。"},
 *  "actions":["SWITCH_MODEL","SUBMIT_FEEDBACK","RETRY"]}
 * ```
 *
 * ⚠️ **它自己就说明了「这不是账号问题」**（注意 `actions` 里根本没有换号的选项，
 * 只有 `SWITCH_MODEL`）。但 `isRateLimited` 对 **429 无条件返回 true** ⇒
 * 适配器把每个账号都写上「1 小时限流」标记（报文无「将在…重置」，
 * 故取 `RATE_LIMIT_FALLBACK_MS` 兜底）⇒ 4 个独立账号在 20 秒内**全部**被锁
 * ⇒ 用户等到 1 小时也不能用，且**期间连别的模型都受影响**（同一个账号池）。
 *
 * 实测证据（同型缺陷的判据来源）：
 * | 观测 | 结果 |
 * |---|---|
 * | 4 个不同腾讯 uid 的账号 | 20 秒内**全部**被标记 `space-bunny` |
 * | 标记解禁时刻 | 全部等于「写入 + 整 1 小时」= 兜底值，**非**服务端给的时刻 |
 * | 4 MB 输入 | 稳定逼出 `429 / 14003`（46~111 秒才返回） |
 * | 小请求 30 发 | 全 200，但耗时 841ms ~ 216s —— 上游是**时变**背压 |
 *
 * ⇒ 「4 个互不相干的账号同时中招」在账号级限流下无法解释，**只能**是模型级。
 * 与 zcode `3009 model concurrency limit exceeded` 同型（那边结论同样是
 * 「退避重试，**不换号、不标记**」）。
 *
 * ⚠️ **不许把 14003 并进 `RATE_LIMIT_BUSINESS_CODE`**：两者的正确动作相反 ——
 * 6004 是「这个账号在这模型上的额度用完了」（换号有效、必须标记）；
 * 14003 是「这个模型此刻整体饱和」（换号**无益**、**不许**标记）。
 */
export const MODEL_SATURATION_BUSINESS_CODE = 14003

/**
 * 「模型饱和」的**自然语言兜底**判据。
 *
 * 与额度限流同理：码值由服务端下发，本地产物里没有硬编码
 * （实测搜 `14003` 在本仓库源码中零命中才敢新增），上游可能改用别的码值表达
 * 同一语义，故需要文案兜底。
 *
 * ⚠️ **关键词必须窄**：`busy` / `saturated` 这种泛词若不加限定，
 * 模型正文里恰好讨论「服务器繁忙」就会被误判。这里只认腾讯原话里的组合，
 * 且判据本身**要求 HTTP 状态码 ≥ 400**（见 {@link isModelSaturationError}）。
 */
const MODEL_SATURATION_PATTERN = /模型繁忙|请求量饱和|model\s+busy|currently\s+saturated/i

/**
 * 判断一次失败是否为**模型饱和**（上游背压），而非账号级额度限流。
 *
 * ## 为什么这个区分是**行为分叉**而不是措辞问题
 *
 * | | 额度限流 `6004` | 模型饱和 `14003` |
 * |---|---|---|
 * | 语义 | 该**账号**在该模型上额度用完 | 该**模型**此刻整体饱和 |
 * | 换号 | **有效**（别的账号有独立额度） | **无益**（所有账号撞同一堵墙） |
 * | 写限流标记 | **必须**（否则每轮重撞） | **绝对不许**（会把整池锁 1 小时） |
 * | 建议 | 等解禁 / 换账号 | **换模型** / 稍后重试 |
 *
 * 实测 `actions` 字段本身就写着 `SWITCH_MODEL` 而**没有**换号选项 ——
 * 服务端与我们的结论一致。
 *
 * ⚠️ **必须先于 `status === 429` 的无条件判定**：14003 恰恰是 429，
 * 若先判状态码就永远走不到这里（这正是缺陷的成因，见常量注释）。
 *
 * @param status - HTTP 状态码。为 `undefined`（只有文案可判）时仍检查业务码；
 *   但**文案分支要求状态码 ≥ 400** —— 否则一段正常正文里出现「模型繁忙」
 *   就会被判成错误。
 * @param body - 响应体（可能为空串）。
 */
export function isModelSaturationError(status: number | undefined, body: string): boolean {
  // 状态码已知且 < 400 ⇒ 这是正常响应，正文里的字样不算错误。
  if (typeof status === 'number' && status < 400) return false
  if (body.length === 0) return false
  try {
    const code = (JSON.parse(body) as Record<string, unknown>).code
    if (code === MODEL_SATURATION_BUSINESS_CODE
      || code === String(MODEL_SATURATION_BUSINESS_CODE)) return true
    // ⚠️⚠️ **结构化降级：报文自带「额度限流」业务码时，一律不判模型饱和**
    // （2026-10-17 对抗审计实测的真缺陷）。
    //
    // 本函数的**码值腿是权威的**，文案腿只是「上游可能改用别的码值」的兜底；
    // 因此当报文**明确给出了另一个已知业务码**时，那才是权威信号。
    //
    // 实测（buddy 额度限流）：`{"code":6004,"msg":"请求量饱和，请稍后再试"}`
    // → `MODEL_SATURATION_PATTERN` 的「请求量饱和」命中 ⇒ 判成**模型级**饱和。
    // 后果不是措辞问题，而是**行为分叉**（见上表）：
    // | | 额度限流 6004 | 误判成模型饱和 |
    // |---|---|---|
    // | 换号 | 有效 | 退化成「原账号退避重试」 |
    // | 写限流标记 | 必须 | **绝对不许** |
    // ⇒ 一个**额度已耗尽**的账号会被判成「换账号无效、换模型吧」，
    // 而池里其它账号的额度是独立的、可用。
    //
    // ⚠️ 为什么要**降级而不是直接 return false**：6004 之外的码还可能是别的语义
    // （上游新码 / 未知码），此时文案兜底仍有价值。故只在**已知对立法**（额度限流）
    // 成立时降级，未知码仍走文案腿。
    if (code === RATE_LIMIT_BUSINESS_CODE || code === String(RATE_LIMIT_BUSINESS_CODE)) {
      return false
    }
  } catch {
    // 非 JSON：交给文案兜底。
  }
  return MODEL_SATURATION_PATTERN.test(body)
}

/**
 * 结构化判定：响应体是可解析 JSON 且 `code` 为该业务码。
 *
 * 不采用「全文包含 6004」的写法：`requestId` 是 UUID，任意数字子串都可能
 * 偶然出现，文本匹配会产生假阳性；这里只认 JSON 顶层的 `code` 字段。
 * 兼容 `"6004"`（字符串）与 `6004`（数字）两种编码。
 */
function hasRateLimitBusinessCode(body: string): boolean {
  try {
    const data = JSON.parse(body) as Record<string, unknown>
    const code = data.code
    return code === RATE_LIMIT_BUSINESS_CODE || code === String(RATE_LIMIT_BUSINESS_CODE)
  } catch {
    // 非 JSON：交给文案兜底
    return false
  }
}

/**
 * 判断错误文本是否为频率限制错误。
 *
 * @param body - 响应体（可能为空串）
 * @param status - HTTP 状态码（可选，但**手里有 Response 就必须传**）。为 `429`
 *   时无条件判为限流，即使响应体为空、不含任何可识别文案。
 *
 * ⚠️ **`status` 判据是真实缺陷的修复，不是可选便利**：本函数原先只接收响应体，
 * 而服务端（网关 / CDN / 限流中间件）完全可能返回**空体**的 429 —— 此时
 * `hasRateLimitBusinessCode` 与 `RATE_LIMIT_PATTERN` **双双不命中**，函数返回
 * `false`，于是适配器里整段「记录重置时间 + 切换账号」逻辑被**整体跳过**，
 * 把一个本可自愈的限流直接抛给用户（表现为「账号池里明明还有可用账号，插件却
 * 报错且不换号」）。
 *
 * 判据顺序刻意是「状态码优先」：429 是 HTTP 语义上**唯一**的限流信号，无需也不应
 * 再去猜文案；下面的文案 / 业务码兜底只服务于「状态码不是 429、但正文表达了限流」
 * 的场景（业务码 6004、SSE 流内错误、网关包装过的 200/400）。
 *
 * ⚠️ 反向的约束同样重要：**非 429 绝不能因为「有状态码」就判为限流** ——
 * 404「模型不存在」这类换号无益的错误若被识别成限流，会被吞成「所有账号均受限」，
 * 用户既看不到真实原因、插件还会白试一遍全池账号。
 */
export function isRateLimited(body: string, status?: number): boolean {
  if (status === 429) return true
  return hasRateLimitBusinessCode(body) || RATE_LIMIT_PATTERN.test(body)
}

/**
 * 重置时间的两种句式（中文 / 英文），并**捕获实际时区**而非硬编码 UTC+8。
 *
 * 中文（buddy 国内版）："您的使用量已超出频率限制，将在 2026-09-11 18:08:17 UTC+8 重置"
 * 英文（workbuddy 国际版）："... your usage will reset at 2026-09-17 09:09:36 UTC+8, alternatively, ..."
 *
 * 早期只列了中文句式，导致国际版即使判定为限流也只能走「1 小时后重试」的
 * 兜底，丢掉服务端给出的真实重置时刻（UI 限流徽章因此显示错误时间）。
 */
const RESET_TIME_PATTERN = /(?:将在|reset at)\s+([\d-]+\s+[\d:]+)\s+(UTC[+-]\d+(?::\d+)?)/i

/**
 * 限流文案里解析不出重置时刻时的**兜底时长**（1 小时）。
 *
 * 为什么需要兜底而不是「解析不到就不记标记」：网关 / CDN 返回的 429 常常既没有
 * 重置时间、甚至**没有响应体**，而标记是 UI「限额重置」徽章与「重测 / 重置」
 * 两条人工解禁路径的**唯一**依据 —— 静默跳过记录会让用户既看不到限流、也无从操作。
 *
 * ⚠️ 1 小时是**快照式**兜底（标记可被重测刷新），与 `BUDDY_POLICY_BLOCK_COOLDOWN_MS`
 * 的 30 分钟**语义不同**（那是「安全策略拦截」的本地冷却，报文里根本没有时间字段），
 * 也与 Qoder「按自然日 24:00」不同（那是按日的额度结算）。三者不要合并成一个常量。
 *
 * 导出是给 `buddy-adapter` 用的：它需要在**没拿到可解析体**时也能写出标记，
 * 且必须与这里 `parseRateLimitError` 的兜底**同值**，否则两处口径会漂。
 */
export const RATE_LIMIT_FALLBACK_MS = 3_600_000

/**
 * 从限流错误中提取重置时间；体里没有时间时返回 {@link RATE_LIMIT_FALLBACK_MS} 兜底。
 *
 * @param status - HTTP 状态码（可选）。为 `429` 时即使**体为空、或无任何可识别文案**
 *   也按兜底时长返回一条，避免调用方「识别出限流却没有标记可写」（见
 *   {@link RATE_LIMIT_FALLBACK_MS} 的说明）。
 */
export function parseRateLimitError(
  body: string,
  currentModel: string,
  status?: number,
): { modelId: string; resetTimeMs: number } | null {
  const fallback = (): { modelId: string; resetTimeMs: number } => ({
    modelId: currentModel,
    resetTimeMs: Date.now() + RATE_LIMIT_FALLBACK_MS,
  })
  try {
    const data = JSON.parse(body) as Record<string, unknown>
    const msg = typeof data.msg === 'string' ? data.msg : ''
    const resetMatch = RESET_TIME_PATTERN.exec(msg)
    if (resetMatch) {
      // 用捕获到的真实时区拼接（不再写死 UTC+8），Date.parse 能正确解析该写法。
      const resetMs = Date.parse(`${resetMatch[1]} ${resetMatch[2]}`)
      if (!Number.isNaN(resetMs)) {
        return { modelId: currentModel, resetTimeMs: resetMs }
      }
    }
    // 标准 OpenAI 429 格式，或带业务码但文案无法解析出时间
    if (isRateLimited(body, status)) {
      return fallback()
    }
    return null
  } catch {
    // 非 JSON（空体、纯文本、CDN 的 HTML 错误页）：只剩状态码可判。
    return status === 429 ? fallback() : null
  }
}
