# 依赖安全记录

本记录说明依赖告警的处理结果与剩余边界，最近复核日期为 2026-10-10。v0.5.2 的干净 `npm ci` 后，全量 `npm audit` 与生产依赖审计均为 **0 项已知漏洞**。审计或测试通过都不能解释为不存在未知漏洞。

## 2026-10-24 新公告处理

推送 `ca72bdd` 后两平台 CI 的 `npm audit` 报告 68 项（3 moderate、65 high），对应三个新公布公告，与该提交的代码改动无关。固定已修复的公开版本并更新锁文件，干净安装后全量审计归零：

- **运行依赖与宿主传递依赖** `zod` 4.4.3 → **4.6.7**（`dependencies` 与根级 `overrides` 同步固定）：修复校验超大受限集合时可能耗尽内存的告警（[GHSA-mrhx-c7xc-m3w5](https://github.com/advisories/GHSA-mrhx-c7xc-m3w5)）。
  - 升级改变模板 vendor，v0.5.6 运行时指纹 `daccaaf4…` 已登记为受信 v1 旧运行时，旧检查点按原指纹恢复、旧堆保留原 vendor 直到环境结束。
- 开发宿主链 `@deepseek-ai/dsh-http-proxy` 与 `@deepseek-ai/dsh-web-fetch-http` 锁定的 `undici` 经根级 `overrides` 固定 **8.12.3**：修复 EventSource 解析器无界内存、SRI 算法标记大小写绕过及过多 `content-encoding` 未捕获异常（[GHSA-4qv8-2p9j-2685](https://github.com/advisories/GHSA-4qv8-2p9j-2685)、[GHSA-f72v-6w45-q472](https://github.com/advisories/GHSA-f72v-6w45-q472)、[GHSA-xjj6-f33q-929c](https://github.com/advisories/GHSA-xjj6-f33q-929c)）。
- 开发宿主链 `@deepseek-ai/dsh-app-boot → ajv → fast-uri` 经根级 `overrides` 固定 **3.1.9**：修复 URI scheme 百分号解码欺骗、相对引用路径规范化、WHATWG host 混淆及后缀引用冒号注入（[GHSA-w74x-v6f9-j3xg](https://github.com/advisories/GHSA-w74x-v6f9-j3xg)、[GHSA-xhq7-xmqj-769h](https://github.com/advisories/GHSA-xhq7-xmqj-769h)、[GHSA-wjr9-j795-jxcr](https://github.com/advisories/GHSA-wjr9-j795-jxcr)、[GHSA-333x-w4r6-6crp](https://github.com/advisories/GHSA-333x-w4r6-6crp)）。

## 2026-10-22 新公告处理

推送 `0c6d9e2` 后两平台 CI 的 `npm audit` 报告 7 项（5 moderate、2 high），均为当天前后新公布的公告，与该提交的代码改动无关。按既有做法固定已修复的公开版本并更新锁文件，干净安装后全量审计归零：

- **运行依赖** `markdown-it` 15.0.2 → **15.0.3**：修复启用 html 时行内 HTML 解析的二次方复杂度（[GHSA-vfgh-jcmw-g37q](https://github.com/advisories/GHSA-vfgh-jcmw-g37q)）与多行链接引用定义的二次方渲染（[GHSA-gfr2-rv44-r23c](https://github.com/advisories/GHSA-gfr2-rv44-r23c)）。它只在可终止 worker 的 QuickJS 中运行，原有输入/输出上限与执行预算不变，此前的影响是耗尽渲染预算后明确失败。
  - 升级改变模板 vendor，运行时指纹由 `47c22ed5…`（v0.5.3–v0.5.5 相同）变为新值；`47c22ed5…` 已登记为受信 v1 旧运行时，旧检查点按原指纹恢复、旧堆保留原 vendor 直到环境结束。`test/templateCheckpointUpgrade.test.ts` 用升级前 vendor 原文（压缩夹具）生成真实旧堆，再由新安装包恢复。
- 开发依赖 `vitest` / `@vitest/*` 4.1.11 → **4.1.12**：修复手动 mock 注册代码注入与 Windows 反斜杠绕过 redirect 白名单（[GHSA-qxg6-89mg-rqv8](https://github.com/advisories/GHSA-qxg6-89mg-rqv8)、[GHSA-xp26-3454-mjgp](https://github.com/advisories/GHSA-xp26-3454-mjgp)）。本项目只用 `vitest run`。
- 开发链 `vitest → vite` 经根级 `overrides` 固定 **8.2.4**：修复 launch-editor 参数转义与 dev server 跨源/越界读取（GHSA-9jrq-w75r-8gcw 等 6 项）。本项目不启动 vite dev server。
- 开发宿主链 `@deepseek-ai/dsh → dsh-mcp-client → @modelcontextprotocol/client` 的 overrides 由 2.2.0 改为 **2.3.1**（core 同步 2.3.1）：修复 HTTP 传输与 OAuth 请求跟随跨源重定向时重发自定义头与请求体（[GHSA-6prh-2h8m-c8cw](https://github.com/advisories/GHSA-6prh-2h8m-c8cw)）。`test/dependencySecurity.test.ts` 的真实 MCP 握手与调用继续通过。宿主自身安装的版本需在其安装目录另行升级。

## v0.5.2 发布复核（2026-10-10）

本次修复前，全量 `npm audit` 报告 **5 项 high**，对应三个公告，均位于本仓库的开发宿主和测试链。根级 `overrides` 固定以下公开 npm 版本，锁文件同步更新，干净安装后全量审计归零：

- `@deepseek-ai/dsh@0.2.0-rc.2 → @deepseek-ai/dsh-mcp-client → @modelcontextprotocol/client`：client 从 2.0.0 升到 **2.2.0**，其精确依赖 core 同步到 **2.2.0**，处理 MCP OAuth 凭证归属告警 [GHSA-6qxp-vccf-f47h](https://github.com/advisories/GHSA-6qxp-vccf-f47h)。审计此前将两个上游包同时计入，共 3 项。回归验证指定 `expectedIssuer` 后，错误授权服务器在网络调用前被拒绝，正确服务器仍可取令牌。独立 OAuth 使用者还须传入可信 `expectedIssuer`，迁移没有 issuer 的旧凭证，并在自定义 provider 中保留 issuer；不能只升级版本。
- `@deepseek-ai/dsh → @deepseek-ai/dsh-otel → got → cacheable-request → http-cache-semantics`：从 4.2.0 升到 **4.3.0**，退出 [GHSA-ch52-4w7c-c8xp](https://github.com/advisories/GHSA-ch52-4w7c-c8xp) 当前受影响范围，并验证 `must-revalidate` 不被 `max-stale` 绕过。该公告仍未列出补丁版本，上游维护者对 Set-Cookie 报告的判断有[明确争议](https://github.com/kornelski/http-cache-semantics/issues/56)；4.3.0 不能被描述为禁止所有带 Cookie 的缓存复用。本仓库引入路径是宿主 OTLP 的 `got.post`，已核对其调用不配置 cache，而 got 默认 cache 为 undefined；插件本身不使用这份缓存库。
- `vitest → vite → postcss → source-map-js`：从 1.2.1 升到 **1.2.2**，修复索引式 source map 偏移导致计算放大的告警 [GHSA-68fv-2mgg-jv7q](https://github.com/advisories/GHSA-68fv-2mgg-jv7q)。回归在可终止 worker 中验证超大、负数、小数与嵌套累计偏移被拒绝，正常映射继续可用。

`test/dependencySecurity.test.ts` 还使用真实 MCP Client、动态 loopback HTTP 工厂及宿主 `createMcpToolDefinition` 验证握手、工具发现、调用与结果转换。Windows / Ubuntu CI 在安装后运行全量 `npm audit`，有漏洞时阻止发布制品进入后续流程。

v0.5.2 沿用精确的 dsh `0.2.0-rc.2` 宿主基线，包内不包含 `node_modules` 或开发依赖。根级 overrides 只作用于本仓库安装，不会修改用户独立安装的宿主；实际宿主依赖需在其安装目录另行核对，宿主升级按 [版本核对清单](HOST_COMPATIBILITY.md) 完成兼容与安装验证。

v0.3.1 发布复查：没有新增或升级运行依赖，也没有加入本机链接依赖；角色卡显示、CCv3 数据兼容和长聊天缓存均沿用现有隔离与数据边界。本地构建、156 个测试文件 / 2245 项通过（1 项按预期跳过）、doctor/backup 与 439 文件发布白名单检查通过；实际安装环境的动态卡仍为 opaque-origin iframe，只有 `allow-scripts`，默认禁止网络连接。发布包取自最终提交通过 Windows/Ubuntu CI 后生成的制品。

v0.3.0 发布复查：新公开适配器使用的宿主配置、凭证、附件和传输包均声明精确的 `0.1.5-rc.2` peer；没有新增第三方运行库或本机链接依赖。相同 manifest、锁文件及 .npmrc 已在独立空目录完成干净 npm ci，审计仍为 0。最终本地构建、154 文件 / 2187 项测试、doctor/backup 与 437 文件发布白名单检查通过；发布包取自最终提交的两平台 CI，保留下文的上游弃用提示。

v0.2.6 发布前本地验收：`npm run build`、全量 **140 文件 / 1986 项测试**、doctor/backup CLI 冒烟与 **425 文件**发布白名单检查通过；Windows 跳过 1 项 POSIX 专属用例。相同依赖和锁文件已在独立空目录完成干净 `npm ci`，仅保留下文说明的上游弃用提示，未审阅安装脚本为 0；最终提交还需通过两平台 CI 的干净安装和完整检查。真实宿主验证新卡导入、EJS 消息格式化、深浅主题和旧已完成历史读取，见 [宿主验收记录](HOST_COMPATIBILITY.md)。

## 已更新的依赖

- `js-yaml` 从 4.3.1 更新到 4.3.2，根级 `overrides` 固定补丁版本，锁文件同步更新。该版本修复恶意空映射合并绕过工作量限制的问题（[GHSA-2883-xcg3-v3hh](https://github.com/advisories/GHSA-2883-xcg3-v3hh)）。本仓库通过开发用 dsh / Cordis 依赖引入它；当前宿主基线为 0.2.1-rc.3。
- `vitest` 从 3.2.7 更新并固定为 4.1.11，相关 `@vitest/*` 包同步更新，修复 redirect mock 越界文件读取（[GHSA-82fw-gwwq-j7x9](https://github.com/advisories/GHSA-82fw-gwwq-j7x9)）。本项目只用 `vitest run` 执行测试，不向外提供 mock 开发服务器；升级仍需运行全量 React、文件系统和 worker 用例。

这些版本约束只作用于本仓库的 npm 安装。发布包不带开发依赖，依赖包的根级 `overrides` 也不会替使用者覆盖其独立安装的 dsh。实际宿主的 `js-yaml` 版本应在宿主安装目录通过 `npm explain js-yaml`（或对应包管理器命令）核对，由宿主依赖升级到兼容的已修复版本；更新本仓库锁文件不等于更新其他安装环境。

## 安装脚本与上游弃用提示

npm 11.16 的项目 `allowScripts` 逐版本记录：`@deepseek-ai/dsh-subprocess-local@0.2.2-rc.1`、`@google/genai@2.21.0`、`esbuild@0.25.12`、`esbuild@0.28.2`、`koffi@3.1.1`、`node-pty@1.2.0-beta.15`、`protobufjs@7.6.6`。不使用全局放行或通配符；以后版本变化需要重新审阅。此字段是脚本审批记录，不是脚本权限沙箱，旧 npm 可能不读取它。见 [npm 官方说明](https://docs.npmjs.com/cli/v11/commands/npm-approve-scripts/)。

2026-11-06 对照了 esbuild `0.25.12` 与 `0.28.2` 的安装脚本：新版仍准备当前平台二进制，并在需要从 npm 或官方 registry 补取时按包内摘要核对 SHA-256；它只用于 Vite 的开发依赖，产物构建器仍固定为 `0.25.12`。

已检查脚本行为：dsh 调整包内 spawn-helper 执行权限；esbuild 准备/验证同版本平台二进制，缺包时从配置的 npm registry 安装并可回退官方 registry；koffi 选择平台预编译包或本地 CMake 构建；node-pty 准备包内 prebuild/ConPTY，缺失时由 node-gyp 构建，可能下载 Node headers；protobufjs 只检查依赖版本写法；Google preinstall 仅输出 no-op。

仍保留一条 **非漏洞的上游弃用提示**：开发宿主的 Google 依赖链通过 `gaxios → node-fetch → fetch-blob` 引入 `node-domexception@1.0.0`。核对时 node-fetch 最新仍为 3.3.2，fetch-blob 最新 4.0.0 仍依赖该弃用包，node-domexception 最新 2.0.2 也已弃用；没有兼容的已发布修复。[上游移除提案](https://github.com/node-fetch/fetch-blob/pull/176)尚未发布。未通过伪造替代包、删除锁文件元数据或关闭告警掩盖该提示，也未跨主版本强改宿主依赖。它不进入插件运行 bundle，宿主依赖升级后应再次核对。

## Showdown：移除受影响解析器

Showdown 的公开最新版本仍为 2.1.0，三份公告均没有可直接升级的修复版本。本次从运行依赖、锁文件和实际 QuickJS 产物移除 Showdown 及其专用 commander 依赖，改用固定公开版本 **markdown-it 15.0.2 / markdown-it-emoji 3.1.0**；没有隐藏告警、重命名漏洞包或保留旧解析器作为回退。markdown-it 15.0.2 包含上游最新的复杂度修复，见 [官方变更记录](https://github.com/markdown-it/markdown-it/blob/master/CHANGELOG.md)。

| 原公告 | 触发条件 | 替换后的行为 |
| --- | --- | --- |
| [GHSA-rmmh-p597-ppvv](https://github.com/advisories/GHSA-rmmh-p597-ppvv) | 恶意嵌套链接使正则长时间计算 | 移除该解析实现。新引擎仍只在 worker 的 QuickJS 内运行，保留内存/执行预算及外层强制终止。输入和输出各限制为 1,048,576 个 UTF-16 码元；大输入超限明确失败，不返回半成品。 |
| [GHSA-cr32-g25g-vxjj](https://github.com/advisories/GHSA-cr32-g25g-vxjj) | metadata 与完整 HTML 文档选项同时开启，标题未经转义 | 新格式化器不解析 metadata、不生成完整文档，也不暴露可修改的解析器对象或全局选项。 |
| [GHSA-22g5-r2x5-97cx](https://github.com/advisories/GHSA-22g5-r2x5-97cx) | 原始表头拼入 HTML 的 `id` 属性 | 新格式化器不生成标题或表头 ID，表格测试继续覆盖注入形状。 |

HTML 格式化结果仍通过 `kind: 'html'` 片段交给现有卡面 iframe，使用 `sandbox="allow-scripts"`，不加 `allow-same-origin`。卡片支持原始 HTML 与脚本，格式化器不是 HTML 清洗器；严禁把结果移入主页面 DOM，业务桥的来源、剧情身份与 WAL 校验仍是必要边界。恶意输入仍可能耗尽当前渲染预算并明确失败。

`test/templateSecurity.test.ts` 用手写攻击形状验证旧库不再装载、无完整文档/标题 ID、HTML 沙箱交付、嵌套链接完整返回或明确资源超限、无限循环被终止、主线程响应及失败后的正常渲染。危险输入只在可终止 worker 中运行。`templateMarkdown` 与 `templateDisplay` 覆盖常用语法和代码/属性边界。

### 格式与旧剧情兼容

通过引擎规则保留表格、换行、删除线、命名 emoji、下划线和图片尺寸；不复制整份旧解析器。新格式遵守 CommonMark 的标题空格规则，`#Heading` 保持普通文本；省略号 `...` 保持原文；仅旧库提供的远程图片 emoji（如 `:octocat:`）不再自动加载；重复引用首次定义优先。复杂 HTML/列表的结构空白及代码块 class 可能变化，不承诺字节完全一致。

已完成回复的保存片段不重算。新重放日志携带 `formatterVersion: 2`；旧版未完成生成或仍持有跨轮回调闭包的日志，在执行任何重放代码前明确拒绝并保留所有数据。因为旧日志没有记录闭包内部的格式化结果，仅比较外显 hash 也不能证明闭包行为不变，不能自动改 hash 或丢弃闭包。升级前先备份、完成旧生成并让相关回调结束；已遇到此诊断时，保留备份，使用原版本完成回调，或回滚到注册相关回调之前的楼层，再升级。普通已完成且无活动重放的旧剧情不受此限制。详情见 [模板说明](PROMPT_TEMPLATES.md)。
