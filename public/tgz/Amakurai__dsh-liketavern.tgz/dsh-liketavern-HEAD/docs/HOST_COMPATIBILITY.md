# 宿主兼容记录

当前源码基线为 dsh 0.2.2-rc.1。以下按版本记录观测结果，升级时重新核对，不是永久架构要求。

`engines.dsh` 与全部 `@deepseek-ai/*` 公开 peer 声明为 `*`：宿主加载器（`evaluatePluginCompatibility`）优先读 `engines.dsh`，没有该字段的旧宿主读 peer，两者都以 `includePrerelease: true` 判断，因此过去与未来的任意宿主版本都不会再因版本号被拒。开发依赖、overrides、安装脚本许可和锁文件继续固定经验证的精确基线，构建与测试只针对该基线；`npm run host:check` 现在同时校验“门槛必须是 `*`”与“开发基线必须一致”，防止有人重新钉住版本号。放开版本号不等于保证接口兼容：真正的兼容由运行时守卫承担（见下节）。

## 宿主版本兼容矩阵

| 宿主版本 (DSH Runtime) | 插件版本 (Plugin Version) | 兼容状态 | 门槛与加载机制 | 运行时策略与注意事项 |
|---|---|---|---|---|
| **0.2.2-rc.1** | **当前构建 (post-v0.5.9)** | **原生支持 (已验证基线)** | `engines.dsh: "*"` 原生满足；加载器无需豁免 | 55 项宿主依赖精确对齐；适配 `parentSession` 移除、模型路由断言与单参 `installModelSelection`；全量通过生产检查与回归测试 |
| **0.2.2-rc.1** | **旧版 release (<= v0.5.9)** | **支持 (需 Profile 豁免)** | 无 `engines.dsh`，peer 钉死 `0.2.1-rc.3`；需 `<profile>/compatibility.json` 豁免或 `cordis.patch.yml` | Cordis 4.1.0 与 Schemastery 3.19.0 保持接口向后兼容；UI 插槽完备；开场白追加限制由原有 `try/catch` 保障无崩溃 |
| 0.2.1-rc.5 | 当前构建 (post-v0.5.9) | 兼容 (已验证) | `engines.dsh: "*"` 自动满足 | 运行时守卫 `hostCompat.ts` 优雅降级；支持模型列表、会话迁移 |
| 0.2.1-rc.3 | 当前构建 / v0.5.7–v0.5.9 | 兼容 (已验证) | 旧基线，旧版原生匹配，新版经 `*` 门槛满足 | 完整支持模型列表跟随、PTC 写入与剧情分支隔离 |
| 0.2.0-rc.1 ~ 0.2.1-rc.2 | 当前构建 / v0.5.0–v0.5.6 | 兼容 (已验证) | 经开放门槛加载 | 适配器自动回退至内置模型目录；支持完整角色/剧情/WAL 操作 |
| < 0.2.0 (如 0.1.x) | 任意版本 | 不兼容 (已废弃) | Session V3 架构与早期 PTC 运行时不兼容 | 宿主底层大幅重构，不建议且不支持跨代运行 |
| >= 0.2.3 / 0.3.x / 未来版本 | 当前构建 (post-v0.5.9) | 开放支持 (待冒烟) | `engines.dsh: "*"` 保证不被宿主加载器按版本号拦截 | 依靠 `src/node/hostCompat.ts` 的服务与方法探测进行阶段降级，需进行启动与 UI 冒烟核对 |

## 0.2.2-rc.1 升级与兼容核对（2026-11-05）

### 依赖对齐与基线升级

公开 npm 上全量宿主依赖发布 `0.2.2-rc.1`：
- `devDependencies` 中 55 个 `@deepseek-ai/*` 宿主包全部由 `0.2.1-rc.3` 升级至精确 `0.2.2-rc.1`。
- `overrides` 中 10 个 `@deepseek-ai/*` 覆盖项同步更新至 `0.2.2-rc.1`。
- `@deepseek-ai/cordis` 升级至 `4.1.0`，`@deepseek-ai/schemastery` 升级至 `~3.19.0`，Cordis 插件组（group, include, loader）升级至 `~1.1.0`。
- `allowScripts` 中的子进程许可同步更新为 `@deepseek-ai/dsh-subprocess-local@0.2.2-rc.1`。
- 静态对齐验证：`npm run host:check` 校验通过，确认 55 个包及锁文件与基线完全一致。

### 旧版本 Release（<= v0.5.9）在 DSH 0.2.2-rc.1 宿主上的兼容策略

针对已发布的历史旧版本（如 `v0.5.7`、`v0.5.8`、`v0.5.9`）：
1. **宿主静态检查拦截根因**：
   - 历史 release 的 `package.json` 未声明 `engines.dsh`，且在 `peerDependencies` 中将 `@deepseek-ai/dsh` 等 22 个包精确钉在 `0.2.1-rc.3`。
   - DSH 宿主加载器（`@deepseek-ai/dsh-app-boot/lib/index.js` 中的 `evaluatePluginCompatibility`）在缺少 `engines.dsh` 时，会逐项核对 `@deepseek-ai/dsh*` peerDependencies。在 `0.2.2-rc.1` 宿主下，`0.2.1-rc.3` 的精确要求无法满足，评估器默认返回 `{ unfulfilledRequirements: [...], exempted: false }`。
   - 宿主在 profile loader 阶段判定未豁免（`!issue.exempted`）时跳过加载（`skippedBundles.push`），并在 Cordis loader preflight 中标记 `row.disabled = true`，导致旧插件被拒载。
2. **免重打包运行方案（Profile Exemption & Patch）**：
   - **方式一（官方豁免机制）**：DSH 宿主提供了原生配置豁免能力。在用户配置目录的 `<profile>/compatibility.json` 中配置版本豁免：
     ```json
     {
       "dsh-liketavern@0.5.9": ["0.2.2-rc.1"]
     }
     ```
     或直接使用 CLI 命令授权：
     ```bash
     dsh plugin allow-version dsh-liketavern@0.5.9 --dsh-version 0.2.2-rc.1 --accept-risk
     ```
     设置后，宿主加载器判定 `issue.exempted === true`，不再跳过插件加载，Cordis 正常激活插件。
   - **方式二（配置层启用）**：在 profile 的 `cordis.patch.yml` 中声明插件条目并确保加载标志为启用。
3. **运行时安全性验证**：
   - **底层服务兼容**：Cordis `4.1.0` 与 Schemastery `3.19.0` 对插件服务注入（`ctx.inject`）、事件注册（`ctx.on` / `ctx.emit`）及设置 Schema 保持严格后向兼容，已废除或变更的方法未在旧版关键链路中使用。
   - **UI 插槽完备**：宿主 0.2.2-rc.1 依然完整挂载全部 5 个核心插槽（`conversation.chat.node`、`conversation.chat.assistant-actions`、`conversation.input.dock`、`conversation.session.header.actions`、`settings.section`），旧版客户端组件能够正常挂载。
   - **同步追加异常防护**：在 `0.2.2-rc.1` 中，`dsh-session` 禁止在 `session/created` 广播完成前追加事件（抛出 `cannot append before session/created completes`）。旧版 release 中的 `retireStuckBlank` 具备完备的 `try/catch` 守卫，会捕获该错误并仅记录警告日志，不会导致主进程崩溃。

### 现行版本策略（Version Policy）

- **完全放开公开门槛**：`engines.dsh` 与全部 `@deepseek-ai/*` peer 均声明为 `*`。宿主加载器优先通过 `semver.satisfies(runtimeVersion, engines.dsh, { includePrerelease: true })` 判断，`*` 使得任何历史版（`0.1.0`+）、当前版（`0.2.2-rc.1`）以及未来版本（`0.3.x`、`1.0.0`）均能在预检中 100% 通过（返回 `undefined`）。
- **严格锁定开发基线**：`devDependencies` 与 `overrides` 固定为当前经过完整冒烟与测试验证的精确版本（`0.2.2-rc.1`），避免非确定性依赖提升造成构建污染。
- **守卫层级化解耦**：将版本号静态判断转变为运行时接口守卫（`src/node/hostCompat.ts`），利用 `optionalService` 与 `hasMethod` 探测宿主能力，实现优雅降级。

### 0.2.2-rc.1 运行时接口变更与适配

1. **Session Fork 世系追踪（`parentSession` 变更）**：
   - **现象与宿主行为**：在 `dsh-session@0.2.2-rc.1` 中，`SessionStore.prototype.fork()` 在特定分支创建场景中不再显式持久化 `session.header.parentSession`，仅设置 `session.header.isSeeded = true`。
   - **插件适配实现**：
     - 在 `src/index.ts`、`src/node/floors.ts` 与 `src/node/sessionArchiveSnapshot.ts` 中安装 `installSessionForkTracking()`，在运行时挂钩 `SessionStore.prototype.fork`，动态记录子会话到父会话的映射表 `forkedSessionParents`。
     - 调整 `adoptHostFork`、`deriveLegacyLineage` 及 `snapshotSessionArchive`：当 `parentSession` 为 undefined 时，结合 `session.header.isSeeded === true` 与追踪缓存解析真实的父会话身份，确保分支剧情接管、楼层回滚与归档快照导出的世系链条完整无损。
2. **模型选择通知简化（`installModelSelection` 变动）**：
   - **现象与宿主行为**：`@deepseek-ai/dsh-agent@0.2.2-rc.1` 中，`installModelSelection(agentCtx)` 简化为单参数通知生成器，废除旧版传入第二个 `legacySelection` 参数的调用方式。
   - **插件适配实现**：插件端对齐单参数调用契约；同时在测试与兼容上下文中提供后向兼容 polyfill，自动处理单参/双参转发，保障平滑过渡。
3. **严格模型路由断言与透明请求投影（`dsh-agent-loop`）**：
   - **现象与宿主行为**：`ReactLoopAgent.prototype.preStep` 强化了前置断言，在执行提示词组装（prompt assembly）前严格要求 `this.model.current() !== undefined`；同时在 `agent/request` 钩子中，严格断言返回的 `proposedConfig.provider` 必须与当前的 `selection.provider` 保持一致。
   - **插件适配实现**：
     - 严格遵守 AGENTS.md 约束 5：在 `src/agent.ts` 的 `agent/request` 阶段，保持 `proposedConfig.provider` 为 `'deepseek-official'`，绝不将宿主可见的 provider 篡改为 `'tavern-deepseek'`，在此基础上进行透明的预设请求投影。
     - 引入安全探测机制：支持 `agent/request` probe（`payload.probe === true`）。在 `preStep` 阶段，若 `this.model.current()` 尚未确立（例如空选项创建的 agent），主动探测或回退至 `sessionModelRoute` / `deepseek-official / deepseek-chat`，防止在提示词组装前发生致命断言崩溃。
     - 动态同步路由：在 `prepareRequest` 中，若检测到 `proposedConfig` 变更了路由，同步调用 `this.model.select()` 保持状态一致。
4. **工具批量调用支持（`dsh-tools`）**：
   - `dsh-tools@0.2.2-rc.1` 的 `ToolsService.prototype.execute` 期望 `{ calls: ToolCall[] }` 的批处理结构。插件在兼容层中增加了单调用对象（`{ agent, callId, name, arguments, signal }`）到批调用的规范化兼容转换。

## 放开版本门槛（2026-11-05）

背景：桌面端从 `0.2.1-rc.3` 自动升级到 `0.2.1-rc.5` 后，插件面板报告“不兼容（要求 0.2.1-rc.3）”并拒绝加载。原因是已安装的 v0.5.9 构建把 22 个宿主包 peer 精确钉在 `0.2.1-rc.3`，且清单没有 `engines.dsh`；宿主按 peer 逐项判断后拒绝整个插件。报废的根因是版本门槛，不是代码真的不兼容。

改动：

- `engines.dsh` 与全部 `@deepseek-ai/*` peer 改为 `*`，`engines.node` 保持 `>=24`。
- 开发依赖与 overrides 仍固定精确基线；`scripts/verify-host-alignment.mjs` 改为校验“门槛必须放开 + 基线必须一致 + 锁文件同步”，`test/hostAlignment.test.ts` 用宿主真实的 `evaluatePluginCompatibility` 逐版本断言。
- 新增 `src/node/hostCompat.ts`：阶段级守卫（`guardPhase`/`guardPhaseAsync`）、可选服务探测（`optionalService`）、方法探测（`hasMethod`）与有界降级记录。`src/index.ts` 的注入表从 6 项收缩为核心 3 项（`settings`、`sessions`、`agents`），`agentPresets`、`workspaceRegistry`、`typert` 改为缺失即跳过；`src/agent.ts` 在宿主不提供 `getSectionOrder` 时把 `TOOLS_SDK` 段序回退到 5000，工具注册与空闲维护各自独立降级；`src/client/index.tsx` 先挂 remote，再逐块注册 slot，任何一块失败只跳过该块。
- 任何阶段失败只写一条 `dsh-tavern: <阶段> 已跳过（宿主接口可能已变更）` 日志，不抛回 Cordis，宿主与其它插件继续可用。

验证：用宿主自身 `dsh-app-boot` 的 `evaluatePluginCompatibility`（runtime `0.2.1-rc.5`）对改后清单逐版本检查 `0.1.0`、`0.2.0-alpha.1`、`0.2.0-rc.1`、`0.2.1-rc.3`、`0.2.1-rc.5`、`0.2.2-alpha.2`、`0.2.9-rc.1`、`0.3.0`、`0.3.9`、`0.4.0-alpha.1`、`0.4.0`、`0.5.0`、`1.0.0`、`2.5.3-rc.1`，全部接受；另外核对 `0.2.0-rc.1` 与 `0.2.1-rc.3` 的 app-boot 实现，两代都以 `includePrerelease: true` 判断，语义一致。桌面端 profile 已用 `dsh plugin --profile desktop update dsh-liketavern` 重新解析到 `origin/main`，宿主同款评估器对安装后的清单返回兼容。

放开范围意味着插件会在未验证的宿主上尝试运行，因此“能装”不等于“已验证”；升级后仍应检查日志里的降级行，并做启动与界面冒烟。

## 设置条件写入核对（2026-10-31）

人设保存后的默认项初始化与删除后的默认项清理使用 `ctx.settings.describe()` 的修订号，交给 `ctx.settings.update(ns, patch, expectedRevision)` 校验。仅在 `SETTINGS_CONFLICT` 时重新读取判断，最多尝试三次；用户已改选其它人设时停止自动写入，不覆盖其它默认字段。普通用户提交仍按局部补丁合并。

已核对本机安装的 `@deepseek-ai/dsh-settings` `0.2.1-rc.3`，以及兼容测试环境中的 `0.2.0-rc.1`、`0.2.2-alpha.2` 的 package.json、lib 与声明，均提供该修订号和条件更新接口。回归用真实 SettingsForms、Loader 与临时配置文件覆盖冲突、重启回读和持续竞争后的资产保留，不据此推断其它未验证宿主的行为。

## 扩大双向兼容范围（2026-10-31）

`0.2.0-rc.1` 缺少后续新增的模型列表 API：适配器在该宿主使用其内置目录，不加载不存在的导出；支持列表的宿主仍沿用 `/models` 及其拒绝语义。旧版真实宿主的 web 界面已验证 Tavern 模式、角色与会话创建、本地模拟模型请求、原生 PTC 写入记忆以及分支回滚隔离；旧会话经迁移文件导入真实 `0.2.2-alpha.2` 宿主后，历史和记忆可读取。两端均只使用合成数据和本机模拟端点。`0.3` 及未来版本尚未发布，范围只是允许尝试，并非已验证承诺。

扩大范围后的兼容构建分别安装到 `0.2.0-rc.1`、`0.2.1-alpha.1`、`0.2.1-alpha.4` 与 `0.2.2-alpha.2` 四个独立宿主；均正常启动并提供 Tavern 服务，两个中间版可创建角色。当时将旧版已回滚的子分支导入 `0.2.2-alpha.2` 后，原有记忆保留、被撤销的事实没有重新出现。旧版完整界面和模型请求冒烟使用的是相同旧版模型目录回退实现的预发布构建；未调用真实模型。后续增加历史校验后的构建在下述两端重新安装验证，两个中间版尚未复验最终构建。

此前对 Cordis `4.0.4` / Schemastery `3.18.4` 与 `4.0.5-alpha.1` / `3.18.5-alpha.1` 的单独冒烟，环境位于源码仓库内，部分间接包会向上解析到开发基线，不能单独证明完整配套兼容。现已在仓库外重新安装：`0.2.0-rc.1` 搭配 `4.0.4` / `3.18.4`、`0.2.1-alpha.1` 搭配 `4.0.5-alpha.1` / `3.18.5-alpha.1`，各自 26 个直接宿主依赖均解析到隔离目录内的指定版本。两组真实宿主均启动并经 gateway 创建角色；旧版创建的合成会话与记忆导入新版后，会话、剧情身份及记忆保持一致。本次隔离验证未调用模型或进行浏览器交互。对应的公开 peer 已包含这些版本及近期预发布补丁线。

本轮另复核到两处边界：配置要求模型列表而目录接口缺失时必须在请求前失败；迁移时宿主图片策略可能重编码附件，必须在发布剧情与恢复标记前核对实际附件身份。两处均有先复现、再修复的行为测试。

进一步验证发现，宿主 `Session.fromRestore` 的表面重放不校验完整的 V4 轮次关系：游离 assistant 消息曾能通过迁移并报告成功，却在宿主持久化重读时失败。导入及导出现在复用宿主公开的 V4 验证器，在发布任何会话与剧情前拒绝损坏历史；源工作区路径可能来自另一平台，校验时不把它误当作本机路径。新增该验证器所在宿主包为同范围公开 peer，开发依赖仍固定基线。

`0.2.2-alpha.2` 的模型列表缓存新增 `settings` 与 `changed` 回调，目录还增加徽标；旧基线的构造参数不足以触发自动刷新和变更通知，也会丢失徽标。现向新旧宿主都传入兼容回调并透传可选徽标。仓库外干净安装该版本及其配套依赖后，使用拦截的合成 `/models` 响应验证真实 gateway：Tavern 模型组显示徽标，缓存到期后自动请求并显示更新；单独验证公开目录变更事件。未请求真实模型服务。

`0.2.2-alpha.2` 在同步 `session/created` 期间禁止追加事件；旧开场白会话的轮次标记因此改在公告结束后写入，再在 Agent 入册时对齐空闲或维护相位的计数。用真实新版 AgentLoop 和合成旧日志验证，补偿后下一次输入从 turn 2 开始。不过宿主针对冷会话的复用检查发生在这个微任务之前，仍可能先把只有开场白的旧会话视为空白；此外缺少原始 turn/step 的游离 assistant 消息不符合宿主 V4 日志约束，补充空轮次无法修复其持久历史。此补偿不承诺修复或安全迁移这类损坏日志；正常新开场白使用完整轮次，不受该限制。

最后使用仓库外的 `0.2.0-rc.1` 与 `0.2.2-alpha.2` 宿主安装构建包并启动两个全新 web profile，经真实 gateway 双向迁移合成开场白与记忆：会话和剧情身份一致；篡改轮次关系的文件先被拒绝，随后同一原文件可成功导入。两边安装器的 pnpm 均报告 profile 缺少宿主 peer；`pnpm peers check` 的各项全部为 missing peer（含 Tavern 预设挂载的 `@deepseek-ai/dsh-compaction-tool-result-pruner`、`@deepseek-ai/dsh-compaction-basic` 与 `@deepseek-ai/dsh-command-compact`），实际运行由宿主提供，启动和上述迁移成功。该观察不适用于其它类型的 peer 冲突。

本轮 Windows / Node 24 回归覆盖 313 个测试文件：先前第一片 1934 项通过，最终第二片 1814 项通过、11 项条件跳过；新增文件和第一片受最后修改影响的文件另补跑 153 项通过。干净安装、构建、发布包白名单、host/doctor/backup 检查通过；Linux CI 和真实模型未在本轮运行。

此前构建在 `0.2.2-alpha.2` 的浏览器界面中打开了从旧版迁移并回滚的剧情，角色、开场白和已有聊天均可见；该宿主的记忆列表由真实 gateway 复核。增加历史校验后的最终构建复验了真实 gateway，未重复浏览器交互。

## 宿主范围与会话迁移验证（2026-10-31）

Windows / Node 24.18.0 下干净安装、构建和以单工作进程运行的完整测试通过：310 个文件、3732 项通过、11 项按条件跳过。`host:check`、`doctor:check`、`backup:check`、`npm pack --dry-run` 与 539 文件发布白名单检查通过。模板恶意代码的断言拆成独立用例，隔离 worker 的产品超时保持不变。

在两个独立临时 `DSH_HOME` 中，使用真实 `0.2.1-rc.5` CLI 安装最终构建并启动 web profile，通过真实 gateway 将合成角色的会话及记忆迁移到另一实例；目标在导入前先缓存该角色缺失，导入后仍能读取角色绑定和原记忆。另在修正最终锁顺序和缺失缓存之前，使用真实浏览器完成导出、选择目标工作区、导入并打开会话的界面冒烟；两次均未调用真实模型，也未读取用户数据。这证明了 rc.5 的上述路径，不代表范围内其它未来版本已经验证。

## 0.2.1-rc.3 升级核对（2026-10-24）

公开 npm 上锁定的全部宿主包都有 `0.2.1-rc.3`，没有包被移除或改名；`@deepseek-ai/cordis` 仍为 `4.0.5`、`@deepseek-ai/schemastery` 仍为 `3.18.5`，`cordis-plugin-*` 也没变。`peerDependencies`、`overrides`、`devDependencies` 统一改为精确 `0.2.1-rc.3`，`allowScripts` 同步改为 `@deepseek-ai/dsh-subprocess-local@0.2.1-rc.3`。锁文件只重解析 `@deepseek-ai` 宿主条目，其余依赖保持原解析结果，避免这一版顺带漂移无关传输。

用 `npm diff` 比较插件源码与测试导入的宿主包，只有四个包的 `lib/` 有实现变化，其余只有 package.json 版本号：

- `@deepseek-ai/dsh-llm-deepseek`：新增 `/models` 模型列表（listing / listing-config / listing-cache / listed-catalog），导出 `requestModelListing`、`ModelListingCache`、`resolveListedCatalog`、`refuseListedModel`、`isBuiltInCatalog`、`resolveListingTiming` 等；`DeepSeekAdapter` 的公开方法、`connect`/`admit` 可选依赖与内置目录条目都没有变。
- `@deepseek-ai/dsh-llm-deepseek-api-key`：`resolveAdapterOptions` 在「官方 origin + 内置目录」时给连接附加 `listing`，provider 注册改用 `connect`/`admit`，`discoverModels` 走列表；设置新增 `modelsTimeoutMs`/`modelsMaxAgeMs`。
- `@deepseek-ai/dsh-client-ui-primitives`：Tooltip 新增 `left` 与自动翻转（`tooltip-placement`）、Menu 新增 `minWidthFromAnchor`、MenuItemButton 新增 `current`、新增 `IconAppsAddOutline*`。
- `@deepseek-ai/dsh-client-ui-settings-general`：开发者工具开关新增桌面埋点与版本字面量；与插件无关。

适配与结论：

- 升级不阻断：`DeepSeekAdapter` 只读连接里的已知字段，多余的 `listing` 会被忽略；插件此前只传 `options`，内置模型路径与 rc.2 一致。重建后的 `lib/` 与旧基线相同，说明这次类型增量没有改变产物。
- 补齐 rc.3 的模型目录语义：Tavern 自建适配器用公开 `ModelListingCache` + `resolveListedCatalog` + `refuseListedModel` 折叠同一份列表。`discoverModels` 广告 `offered`（Tavern 分组能看到列表里的新模型），请求解析用 `resolution`（含列表未列出但本构建仍支持的内置模型），`admit` 在网络 I/O 前给出与宿主相同的 `CLIENT_UPGRADE_REQUIRED`/`MODEL_UNSUPPORTED`。此前 listed 模型会拿到 1e6/256k 的回退能力、图片被误判为不支持，也不产生这两个错误码。
- 列表请求沿用同一凭证与 `prepareCall` 的取消信号，只读公开 `/models`；失败与宿主一致退回内置目录，本已可用的模型不受影响。设置变化后丢弃解析快照并按新快照判断是否继续跟随，`ctx.effect` 负责 dispose。
- primitives 的改动是纯增量：插件只用到 `label`/`side="bottom"` 的 Tooltip 与已有 Menu 属性，客户端 tsc 与全量测试覆盖。

验证：Windows / Node 24.18.0 下干净 `npm ci`（649 个包，`npm audit` 0 项已知漏洞），`npm run build` 通过。全量 297 个测试文件、3596 项通过、11 项按平台或能力跳过、0 失败（含新增的列表跟随与宿主版本对齐回归）。`host:check`、`doctor:check`、`backup:check` 与 `package:check`（519 个白名单文件）通过。

安装冒烟：独立临时 `DSH_HOME`（`.tmp/smoke-rc3-20261024`）中用 rc.3 CLI 执行 `dsh plugin --profile web add` 安装本地 tgz，`plugin list --depth 0` 与 `--dump-config` 都显示 `dsh-tavern`；启动 `dsh --profile web` 后鉴权首页返回 200 并加载 `dsh-liketavern/client.js`，`dsh-tavern/` 数据目录完整初始化，stdout/stderr 没有插件加载错误。宿主按 PID 结束，端口经 netstat 确认释放。这次冒烟没有调用真实模型，也没有做浏览器交互验收；正式 Release 附件仍以目标提交两平台 CI 通过后的原始制品为准。

v0.5.7 发布后另下载 Release 附件复核：`dsh-liketavern-0.5.7.tgz` 的 SHA-256 与同页 `SHA256SUMS.txt` 及 GitHub 附件 digest 一致，tarball 仍是 519 个白名单文件、不含 src/test/node_modules，安装后的 manifest 为 0.5.7 且 peer 精确指向 `0.2.1-rc.3`。把它装入新的临时 `DSH_HOME` 后 `plugin list` 显示 `dsh-liketavern@0.5.7`，`--dump-config` 有 `dsh-tavern`，鉴权首页 200 并加载同一 client bundle，`dsh-tavern/` 数据目录完整初始化，日志无插件加载错误；宿主按 PID 结束、端口释放。

## v0.5.5 审计修复（2026-10-20）

宿主仍为 0.2.1-rc.2，未改动依赖或宿主接口用法。Windows / Node 24.18.0 下构建、287 个测试文件通过（3481 项通过、11 项跳过），511 文件发布白名单通过。核对 0.2.1-rc.2 的 `ReactLoopInbox.claim`：每个 turn 只认领一条 next-turn 输入，因此楼层重放必须合并为单条 followup；runtime context 与 inject 的插件 notice 都以 user/message 记入日志，重放前必须过滤。打包后的本地 tgz 经桌面端自带 CLI 装入 desktop profile，依赖解析与只读诊断正常；桌面端 UI 冒烟由维护者在真实环境完成，正式附件仍以目标提交两平台 CI 制品为准。

## v0.5.4 发布与新宿主回归（2026-10-20）

issue #13 的正式安装失败来自版本脱节：`main` 已适配 0.2.1-rc.2，而 v0.5.3 的 Git 标签和附件仍精确依赖 0.2.0-rc.2。本次以 v0.5.4 发布当前适配，同步 package/lock、中英文安装地址与宿主徽标，保留旧标签和附件；发布审核流程补充版本、标签、附件与实际安装的对应检查。

Windows / Node 24.18.0 下重新执行干净 `npm ci`，审计 0 项已知漏洞；构建、255 个测试文件通过（3380 项通过、11 项跳过），511 文件发布白名单、doctor/backup CLI 检查通过。编译产物与既有 main 一致，本次未更改运行时源码。

用独立临时 DSH_HOME 经真实 0.2.1-rc.2 CLI 安装本地 0.5.4 tgz 并启动 web profile。真实浏览器核对关于页的插件 0.5.4 / 宿主 0.2.1-rc.2，选择 Tavern 模式与合成角色后正常显示 HTML 开场白；卡面计数保存为 1，整页刷新后仍为 1。本机模拟 Messages 端点通过真实 AgentLoop 返回正常 SSE，重新生成创建独立子剧情；子分支计数保存为 2 后，切回来源分支仍为 1。页面 error/warn 日志为空。所有资产、模型密钥占位符、请求与截图仅在本地 .tmp；未使用真实模型、用户剧情或报告者原始存档，不能据此声称任意第三方卡与真实生成质量都已验证。正式 Release 附件仍需使用本次目标提交两平台 CI 通过后的原始制品。

## 0.2.1-rc.2 升级核对（2026-10-17）

公开 npm 上已有锁定的全部宿主包的 `0.2.1-rc.2` 版本，没有包被移除或改名。`@deepseek-ai/cordis` 仍为 `4.0.5`，`@deepseek-ai/schemastery` 仍为 `3.18.5`，`cordis-plugin-*` 版本也没变。`peerDependencies`、`overrides`、`devDependencies` 统一改为精确 `0.2.1-rc.2`，`allowScripts` 同步改为 `@deepseek-ai/dsh-subprocess-local@0.2.1-rc.2`。

用 `npm diff` 比较了插件源码与测试导入的宿主包，连同 `dsh-web-app`、`dsh-agent-preset` 共 44 个。差异只有 package.json 中的版本号和依赖版本，`lib/` 与类型声明没有变化。web profile 的 `cordis.patch.yml` 新增客户端插件 `@deepseek-ai/dsh-client-ui-deepseek-model-label-1017`，即官方 DeepSeek Flash 模型标签的临时徽标。`dsh-agent-preset` 的参考文档新增 `dsh-web-deepseek-api` 条目。这两项都不涉及插件使用的 slot、system-prompt、事件时序或适配器接口，所以源码无需修改，重建后 `lib/` 内容保持一致。

验证：Windows / Node 24.18.0 下，`npm audit` 为 0 已知漏洞，`npm run build` 通过。全量 254 个测试文件、3372 项测试通过，11 项按平台或能力跳过。`doctor:check`、`backup:check` 与 `package:check`（511 个白名单文件）通过。

在独立的临时 `DSH_HOME` 中，用 0.2.1-rc.2 CLI 执行 `dsh plugin --profile web add`，安装本地 tgz。`--dump-config` 能看到 `dsh-tavern` 条目。启动 `dsh --profile web` 后，鉴权首页返回 200，并加载了 `dsh-liketavern/client.js`；`dsh-tavern/` 数据目录完整初始化，日志中没有插件加载错误。pnpm 的 missing peer 提示来自宿主在运行时提供的 peer，与以往一致。测试宿主按 PID 与命令行核对后结束，3080 端口经 netstat 确认已释放，临时目录已清理。这次没有调用真实模型，也没有做浏览器 UI 交互验收。

## 0.2.1-rc.1 升级核对（2026-10-17）

公开 npm 上 `0.2.1-rc.1` 发布了新的宿主与基础包版本：`peerDependencies`、`overrides`、`devDependencies` 统一升级为精确 `0.2.1-rc.1`，`@deepseek-ai/cordis` 升至 `4.0.5`、`@deepseek-ai/schemastery` 升至 `3.18.5`，`@deepseek-ai/cordis-plugin-*` 同步更新；移除 0.2.1-rc.1 已裁撤的 `@deepseek-ai/dsh-invariants` 与 `@deepseek-ai/dsh-subagent-in-process-driver`，补入 `dsh-tools` 在 Agent PTC `run_code` 路径下依赖的 `@deepseek-ai/dsh-working-directory@0.2.1-rc.1`。

逐包核对 0.2.1-rc.1 的 `package.json`、`lib/` 与类型声明并完成适配：

- `SystemPrompt` 与 `ReactLoopAgent.step()`：0.2.1-rc.1 在 `agent/pre-step` 返回后调用 `systemPrompt.refreshContext(agent)`，用重新求值的快照替换 `decision.messages` 中的 `runtime-context` 消息。插件注册 `tavern:turn` context 时提供 `text` 回调，从 `state.appliedTurnContext` 返回本轮已组装的 turn 文本，避免 `refreshContext` 将 `tavern:turn` 重置为空；同时 `agent/pre-step` 将 `attachPresetPlanMessage` 挂在 `decision.messages` 最后一个非 `runtime-context` 的 `UserMessage` 上（防止 `refreshContext` 替换 `runtime-context` 时丢弃 `tavernPresetPlan`），`presetRequestProjection` 的 `frontierAt` 在命中载体消息后跨过同批次紧随的连续 `runtime-context` 消息，保持请求边界、尾部 runtime context 吸收与历史深度一致。
- `LlmAdapter` 新增抽象方法 `imageRequestTarget(provider, model, image)`：`TavernPresetDeepSeekAdapter` 将其委托给持有的公开 `DeepSeekAdapter`（固定 `PRESET_ADAPTER_SOURCE_PROVIDER`）。
- 客户端 `conversation.chat.node` 图片渲染：0.2.1-rc.1 的 `ChatMessageOwnerProps` 改为提供 `loadImage` 并经 `conversation.images.content` 工厂 slot 渲染图片网格；`assistant.tsx` 优先使用 `owner.loadImage` + `renderFactorySlot('conversation.images.content', ...)`，并保留 `renderMessageImages` 兼容回退。
- 测试与持久化插件契约：`@deepseek-ai/dsh-session-persistence-jsonl` 改为导出函数式插件 `apply` 与 `Config`；`@deepseek-ai/dsh-session/invariant` 移除后，消息编辑集成测试改用公开 `validateStoredEvents`、`Session.create`、`ToolCallRecovery` 与 `interruptedTurnClosers` 校验存储契约、surface 转换与 turn/step/工具调用配对；独立 PTC 集成测试显式挂载 `WorkingDirectoryService`。

验证：Windows / Node 24.18.0 下，`npm audit` 为 0 已知漏洞，`npm run build` 通过，全量 254 个测试文件 / 3372 项测试全部通过（11 项按平台或能力跳过），`doctor:check`、`backup:check` 与 `package:check`（511 个白名单文件）通过。在独立临时 `DSH_HOME` 中使用 0.2.1-rc.1 CLI 执行 `dsh plugin --profile web add` 安装本地 tgz，核对 `--dump-config` 合并配置后启动 `dsh --profile web`，鉴权首页返回 200 且包含 `dsh-liketavern` 客户端模块，`dsh-tavern/` 数据目录完整初始化，无插件加载错误，临时目录已清理。

## 0.2.0-rc.2 依赖安全与 v0.5.2 安装复核（2026-10-10）

宿主基线保持精确 rc.2，开发安装的 MCP client/core 固定为 2.2.0，http-cache-semantics 为 4.3.0，source-map-js 为 1.2.2。核对 dsh-mcp-client 的 package.json、lib 与声明：现有 HTTP 工厂只传 requestInit.headers，stdio 使用公开子路径，不配置 OAuth provider。真实补丁 Client 经 loopback HTTP 完成初始化、工具发现与调用，结果继续通过宿主 createMcpToolDefinition 的实际 schema 校验与转换；OAuth issuer 和 source map 限额另有行为回归。缓存公告争议与独立宿主 overrides 边界见 [依赖安全记录](DEPENDENCY_SECURITY.md)。

Windows / Node 24.18.0 使用新的 `.tmp/release-052-20261010-security` 工厂，在独立 DSH_HOME 通过真实 rc.2 CLI 将当前预编译 tgz 安装进 web profile 并冷启动。关于页正确显示插件 0.5.2、宿主 0.2.0-rc.2；已安装 memory.js 的 SHA-256 与仓库构建一致。记忆设置初始 dedupSimilarity 为 0.75、aliasExpansion 开启；关闭别名并保存后，真实 profile patch 写入 false，页面重载后保持关闭。页面错误日志为空。

这次页面验收覆盖安装、版本识别与记忆设置持久化；生成、取消、别名维护和隔离剧情由真实文件系统与模拟宿主的集成测试覆盖，没有调用真实模型。截图与合成资产只保留在本地 .tmp，不进入 Git 或发布包。干净 npm ci、全量及生产依赖审计均为 0；构建、221 文件 / 3130 项测试通过（10 项按平台或能力跳过）、doctor/backup 与 481 文件包白名单检查通过。最终发布附件仍取自目标提交通过两平台 CI 后的原始制品。

## 0.2.0-rc.2 卡面许可与分支恢复（2026-10-01）

卡面各桥固定非空 runtimeId，并在同一 WindowProxy 文档重写后保留退役身份；请求、结果、诊断、Applied 与高度通知都不能借用新运行时。可信客户端通过枚举的 openHelperFrame / closeHelperFrame 为固定会话、消息、剧情和只读权限登记私有许可，令牌不进入 iframe。新 epoch 在任何排锁前撤销旧许可，各写入口在 WAL、共享资产修改或草稿原子发布前复核；已认领的真实提交保留正确成功回执。重绘候选发布后由宿主登记同运行时的新可写 epoch。

原生分支接管的恢复规则见下方升级核对。公开 Session.firstLifecycleSeq 与 inheritedEventCount 用于区分首次创建和已恢复的种子分支；首次来源及继承指纹持久化，接管故障明确阻止发信。已合法绑定的子剧情不再依赖旧来源，明确解除先持久化 skipped 再取消和删除绑定；清理与解除在同一绑定锁内串行，旧内存计划同步失效。开场白切换从入口固定 Session/seq，读取与分支准备后复核，并在实际目录 rename 前同步检查历史和卡面许可。

本轮新增 135 项回归，最终 206 个测试文件、2919 项通过、8 项平台或能力用例跳过，零失败。最终构建、475 文件打包白名单、doctor/backup CLI 与差异格式检查通过；所有新增模块均已生成 lib JS 与声明，未更改依赖。

隔离安装使用新的 `.tmp/bugfix-boot-20261001b` DSH_HOME 与真实 rc.2 CLI web profile，确认安装后的 floors.js SHA-256 与最终构建一致。手写角色卡变量依次保存，document.write 重建与只读重绘发布后仍能写入；宿主原生分支创建独立剧情，子剧情计数修改不改变来源 helper.json 的 SHA-256。含空格内部名称的世界书经真实设置编辑器保存到原文件 ID，内部名称保留且未创建副本。最新包冷重启后子剧情恢复计数 4，继续保存、正常 stop 回复、再次重建及重绘后计数 7 已落盘；来源仍保持计数 3。

本轮浏览器日志无页面错误，iframe 仍仅为 sandbox="allow-scripts" 且 connect-src 'none'。模型请求只经过动态 loopback 手写 Messages/SSE 工厂，不代表真实模型效果或任意第三方脚本验收；PTC、取消和排锁故障由集成回归覆盖。页面已关闭，测试宿主与假端点按 PID 和启动时间核对后人工结束，监听端口经 netstat 确认释放；这不是自然 SIGINT 退出验证。截图和合成数据只保留在本地 .tmp，不进入 Git 或发布包。

## 0.2.0-rc.2 输入认领与绑定变更（2026-10-01）

核对已安装 AgentLoop 的顺序：turn/start → inbox.claim → assemble → agent/request → prepareCall；user/message 在准备完成后才追加。`agent/inbox/inserted` 包括未来排队输入，不能据此冻结本轮宏或世界书。插件改用带 turn 的 `agent/inbox/claimed`，与旧轮收口共用会话队列；真实 Session、AgentLoop 与文件系统回归覆盖未来文本和图片隔离、取消后恢复、持久 inbox 重载，以及 MVU 延迟后按原 ID 重新认领。

请求 waterfall 后仍有异步 prepareCall，宿主在其返回后先检查 AbortSignal 再发送。请求钩子复核计划之外，绑定服务在锁内完成合法性和归属校验后、发布换绑或解除之前，用公开 Agent.cancel 的 keepInbox 选项同步中止旧轮；不持锁等待 idle，也不进入 llm/stream 修改冻结请求。同剧情预设与人设编辑仍在下一轮生效。真实 AgentLoop 回归覆盖各等待窗口、未来队列保留、非法换绑不取消，以及临时绑定读故障时保留祖先并拒绝保存。该回归不替代安装环境的 boot/UI 验收。

安装环境验收使用新的临时 DSH_HOME、当前 tgz 与真实 rc.2 CLI web profile，模型只连接动态 loopback 端口上的手写 Messages/SSE 工厂。页面完成角色创建、编辑、绑定和正常 stop 回复；同名空书创建明确冲突，原书正文文件 SHA-256 和文件数保持不变。生成中排队的未来消息未进入当前请求；停止后队列保留，重新发信唤醒后按顺序进入后续轮次。冷重启后五轮消息、角色绑定和正文完整恢复，页面操作及重载阶段错误日志为空。该浏览器验收未调用真实模型，也未覆盖工具调用或任意第三方脚本；PTC 与隔离失败边界另由集成回归验证。

本轮最终验证：构建通过，195 个测试文件中 2784 项通过、8 项跳过；469 文件打包白名单、doctor/backup CLI 和差异格式检查通过。截图、原始合成请求及临时安装环境只保留在本地 `.tmp/bugfix-boot-20261001`，不进入 Git 或发布包。执行器发送控制字符是否递送系统 SIGINT 未核实；冷重启使用身份核对后的本工厂 PID 人工结束，不作为自然退出验收。测试页面已关闭，宿主和假模型端口经 netstat 确認释放；系统端口查询被拒绝时不得把空结果当作已释放。

## 0.2.0-rc.2 桌面端关于页修复（2026-09-30）

桌面端的 Node 主入口是 `dsh-desktop-host`，不是 `@deepseek-ai/dsh` 的 `bin.dsh`；此前仅核对 CLI 主入口，因而把桌面宿主显示为「无法读取」并禁用更新检查。核对已安装包的 package.json、公开声明与实际桌面包：桌面启动经 `runProfile` 提供 `profileContext.installAnchor`，指向应用内 `dsh/node_modules/@deepseek-ai/dsh/package.json`。

关于服务按实例传递并冻结该 profile 的名称和安装锚点，以有界文件读取校验真实宿主包名称与 SemVer。仅在没有 profile 时保留旧 CLI 入口识别；锚点缺失、损坏、超限或身份错误时保留 unknown，不回退到插件开发依赖、PATH 或其它宿主。desktop profile 仍可查询正式发布并核对精确 peer，但更新命令为空；按桌面安装界面的实际说明，升级需先在「插件」页面卸载旧版，再通过「添加插件」安装新版并完整重启。该输入框支持包名、GitHub 仓库地址或本地目录；v0.5.1 使用带版本标签的 GitHub 地址，并随 Git 提交预编译产物。

回归使用真实临时文件、目录 junction、模拟宿主 context 和手写 GitHub 响应，覆盖两个宿主实例的版本与更新检查隔离、锚点失败边界，以及真实 React 按钮与桌面提示。另以实际安装的 Electron Node 运行时执行最终构建及解压后的发布包，确认从 `resources/app.asar` 读取宿主 `0.2.0-rc.2`，安装版标识正确，模拟新版本检查成功且不给出 CLI 命令；此检查不代表完整桌面 UI 冒烟，也未改动用户安装或剧情数据。

Windows / Node 24.18.0 下构建、172 个测试文件 / 2537 项通过（1 项 POSIX 用例跳过）、459 文件打包白名单与 doctor/backup 入口检查通过。原目录 `npm ci` 因运行中的宿主持有 koffi 动态库而失败，随后恢复完整依赖，并以相同 package.json、锁文件及 .npmrc 在独立目录完成干净 `npm ci`，未停止用户宿主。

## 0.2.0-rc.2 升级核对（2026-09-29）

公开 npm 上 0.2.0-rc.2 覆盖了此前锁定的全部宿主包，没有包被移除或改名；Cordis 4.0.4、Schemastery 3.18.4、cordis-plugin-* 版本不变。peerDependencies、overrides、devDependencies 统一改为精确 `0.2.0-rc.2`，allowScripts 同步传递依赖的新版本（`@google/genai@2.21.0`、`koffi@3.1.1`）。重扫宿主包的非可选 peer，没有需要补进 devDependencies 的新基础包。

逐包对比旧新两版已安装的 `lib/` 与声明：

- llm、agent、tools、system-prompt、session-projection、settings、agent-preset-registry、attachment、credentials、typert、ptc-runtime(-node)、agent-tool-presentation 的声明无变化；session-format 仍到 v4，没有新迁移器。standing/turn 段位、`llm/stream` 冻结、prepareCall 与 `systemPromptUpdate` 边界沿用原核对结论。
- `AgentLoop` 步骤失败时新增 `ToolCallRecovery`：先为尚无结果的工具调用追加保守的错误 `tool/result`，再关闭步骤；崩溃修复与分支种子改用同一实现，且只有同 turn/step 的 append 结果才算已答复。剧情历史投影本就跳过 tool/developer 角色，楼层 WAL 以 turn 收口提交，不受这些合成结果影响。
- `MessageSourceMap` 新增 `user-question-reply`（ask_user 回答）。Tavern 预设不挂载 ask_user；即使出现，历史投影也只把 `user`/`model` 来源计入深度。
- DeepSeek 文件索引的 `invalidate`/`remove` 改为批量签名，插件的布局投影装饰器不调用这两个方法。会话控制器 fork 增加可选 `onCreated` 回调、gateway 增加 `hasLiveClient`，均为加法。
- 客户端：插件使用的 `conversation.chat.node`、`conversation.chat.assistant-actions`、`conversation.input.dock`、`conversation.session.header.actions`、`settings.section` 仍存在；chat 的 `groupPart` 分段、turn-tail `closing.finalNode.messageId` 契约不变。chat 的默认 `transcriptView` 从 standard 改为 detailed，运行状态与时长格式改为分片渲染（`duration.*Unit` 键），均为宿主自身展示。primitives 的 `--dsh-frame-top-clearance` 更名为 `--dsh-frame-overlay-top`，插件不引用；插件使用的 `--dsh-*` 变量均仍有定义。
- `dsh web` 仍是 `dsh --profile web` 的别名，启动器的 `--patch` 叠加层保留；宿主 web 补丁仅新增桌面遥测行并移除默认禁用的 schedule 行，预设 YAML 格式与 `tool-presentation` 的 `mode: ptc` 不变。

构建无类型错误，`lib/` 产物与旧基线逐字节一致；全量 172 个测试文件 / 2519 项通过、1 项 POSIX 用例跳过，仅需更新 doctor/backup 测试中的期望版本字面量。459 文件打包白名单、doctor 与 backup CLI 冒烟通过。

安装冒烟：独立临时 `DSH_HOME` 中用项目内 0.2.0-rc.2 CLI 执行 `dsh plugin --profile web add` 安装本地 tgz，再启动 `dsh --profile web`。宿主正常监听，插件建立 `dsh-tavern/` 数据目录，页面合并脚本包含 `dsh-liketavern/client.js`，日志无加载错误；pnpm 仅报告宿主 peer 在 profile 内“缺失”（运行时由宿主提供），无版本冲突。

端到端冒烟：`DEEPSEEK_BASE_URL` 指向本机假 Messages 端点（记录请求体、返回脚本化 SSE 与 `run_code` 工具调用），headless Edge 经 CDP 驱动同一宿主。合成角色卡覆盖：Tavern 模式选择、新建/编辑/绑定角色、英雄区宏展开、HTML 开场白卡面（仅 `allow-scripts`、`connect-src 'none'`，框内脚本可执行）、真实发信经 `tavern-deepseek` 适配器并冻结 `systemPromptUpdate: in-history`、跨轮 system 前缀逐字节一致、PTC `run_code` → `tavern_memory_write` 写入与同轮确认、重新生成/回退/编辑回复/续写各自建子会话且记忆只留在原剧情、AI 代答独立请求、设置八个页签及关于页宿主版本。完整重启宿主后四个会话均重新加载。全程浏览器无控制台错误（重启期间的断线重连除外）。

新发现并修复：宿主停止轮次时保留未消费的 next-step 输入，插件在工具执行中注入的「【Tavern 步骤】」与「【Tavern 同轮写入】」会被下一轮首步一并认领，模型把旧写入确认和「第 2 步」收口当成新一轮指令。`agent/pre-step` 在每轮第 1 步丢弃这类只属于原轮的插件通知（续写指令、记忆压缩不受影响），若只剩宿主 runtime context 则返回空批次由宿主按空首步收口。真实 AgentLoop 回归先复现、后验证修复，安装环境同一操作复测确认。

第二处（0.1.7 已存在）：宿主消息栏的「在新对话中分支」经 session-controller `fork` → `agents.create` 只复制日志前缀，插件不知情，子会话无绑定、无独立剧情，卡面退回原生源码显示。现于宿主 `session/created` 同步登记接管：来源已绑定、子会话为 Tavern 种子分支且非插件自身分支（插件分支在创建期间登记排除）、非子代理时，用插件分支同一草稿流程 `forkStory` 撤销未继承楼层、复制定时器与索引后绑定；前缀停在某轮中途且来源其后仍有模型/工具事件时连同该层撤销。接管完成前 `loadBinding` 等待，客户端与首轮不会读到未绑定。真实文件系统回归覆盖整轮边界、最终回复处、多步中途、插件分支不重复接管（去掉排除即失败）、读取等待及跳过条件；安装环境实际点击分支后显示角色芯片、卡面与 Tavern 操作栏，新轮在子剧情独立开层。

原生分支接管失败会明确阻止依赖绑定的读取与模型请求；下一次独立读取可重试，并发读取共用同一接管任务。首次来源绑定、继承 seed 指纹和回滚边界持久化在插件私有 `state/host-fork-adoptions/`，父会话后来换卡或新增事实不会改变重试来源。首次来源读取失败只有绑定文件检查点保持不变时可恢复；无法确认身份或检查点变化时要求重新分支。已确认来源未绑定或用户明确解除过角色的分支保留 `skipped` 凭据，恢复后继续普通助手；解除凭据写入失败时保留原绑定。已合法绑定的独立子剧情不再依赖旧来源可读。旧版本遗留或首记录写入失败的已恢复种子分支，若没有自身绑定及接管凭据，无法可靠推断原来源，必须重新创建分支；不沿父会话当前绑定猜测旧角色归属。

假端点重启后曾复用工具调用 ID，使同一会话出现重复 PTC subCallId，存储日志随后被宿主（0.1.7 起已有的）校验拒绝加载；真实供应商 ID 唯一，这是测试工具产物，不是插件或升级问题。未调用真实模型，不代表生成质量或任意第三方卡已经验收。

## 开场白首节点与迁移校验（2026-09-27）

rc.2 的运行中 `Session` 接受先写 assistant 开场白、后写 system 的顺序，但发布版 v3→v4 迁移器会拒绝：`system/message requires a protected first surface head`。单独验证 `Session.create` 不足以发现这个重载故障。

点击进入、swipe seed 和首条输入补偿统一写完整 turn/step，并在开场白前用公开 `createSystemMessage('')` 保留空 system 首节点。宿主 `SystemPromptProjection` 在首次请求时正常填入完整提示词，仍由宿主组装 SDK、standing 和 turn；占位不携带角色设定，不伪造模型请求。首条输入补偿在已有维护门控内等待会话队列，更新 lastTurn 后才放行生成；不再写 turn 0 游离开场白，异步资产读取后复核宿主是否已经开轮。

回归使用真实临时目录、AgentLoop、模拟适配器及发布版迁移器，覆盖开场白、首轮回复、回退继承前缀和旧顺序拒绝。此修改预防新记录继续产生上述结构，不自动修复已经无法加载的外部旧日志；安装环境 boot/UI 冒烟仍需单独进行。

切换开场白还需在读取前拒绝开放轮次，并在宏展开后及剧情分支草稿发布前复核来源 Session 身份与 seq；首条输入可能在文件读取期间到达，不能仅凭尚未落盘的 user/message 判定会话空闲。

## 0.1.7-rc.2 升级核对（2026-09-25）

逐包核对公开 npm 的 package.json、lib 和声明：Cordis 4.0.4、Schemastery 3.18.4；宿主包统一锁定 `0.1.7-rc.2`。

- `dsh-agent-presets` 改为 `dsh-agent-preset-registry`，Tavern 用 register/dispose 管理模式；提供业务 service 后再注册预设以满足立即激活。
- `dsh-settings` 以 Loader 配置和 volatile 值为唯一读写来源，更新后当前实例读取新值；entry id 与旧 `settings.yaml` 的 `dsh-tavern` 节一致。远程 strict codec 必须提供 `create()` 工厂，已移除旧 schema 字段及入口的类型绕过。
- 新消息将 tool/developer 分为独立 role；剧情历史投影必须跳过。runtime-context、system-prompt、compact-checkpoint 采用新版来源；插件 notice 使用声明扩展，并兼容旧 notice。
- 官方 DeepSeek 配置和凭据来自 `dsh-llm-deepseek-api-key`；复用公开适配器的 Messages、Files 协议。同代 prepareCall 冻结连接及能力。中途 system 只允许 user/tool 后、assistant 或结束前，否则合入首条并显示兼容说明；累计完整快照仍有 16 MiB 上限。
- PTC 从 worker-thread codeRuntime 转为 `dsh-ptc-runtime-node` 子进程，真实工具测试启用临时目录沙箱；卡面/EJS 不进入该执行器。
- 客户端改用宿主实际导出的 Medium 图标，仍使用原生 primitives 和不带同源权限的 iframe。

安装验收使用独立 `DSH_HOME`，通过真实 `dsh plugin --profile web add` 安装本地 tgz，再启动 dsh web；修复了启动时才暴露的 strict codec 故障。未配置模型凭据、未调用真实模型，模型请求由真实 AgentLoop、适配器和工厂 HTTP/SSE 测试覆盖。 界面实际完成工作区选择、Tavern 模式切换、手写角色创建/编辑/绑定和开场白显示；设置写入当前 profile，重启后角色与历史恢复。向独立 home 放入手写旧 settings.yaml 后，宿主将其重命名为 settings.yaml.imported，两项提示词偏好迁移后的 UI 值与新 profile 文件一致。浏览器未报告错误，验收页和宿主均已关闭。干净 npm ci（601 个包、审计 0 已知漏洞）、构建、157 个测试文件 / 2263 项通过 / 1 项 POSIX 跳过、doctor/backup 和 441 文件打包白名单检查通过。

## 0.1.5-rc.2 角色卡显示与安装环境 UI 复查（2026-09-20）

在 Windows / Node 24.18.0 / dsh `0.1.5-rc.2` 下，以独立临时 `DSH_HOME` 将与最终发布源码相同的本地 tgz 通过真实 `dsh plugin --profile web add` 安装到新的 web profile，再启动真实 `dsh web`。HTTP 首页返回 200，Tavern 模式、设置入口与角色管理正常；未读取或写入用户原有数据。

- 在真实浏览器中创建、编辑并绑定手写角色，开场白与历史气泡正常显示；角色改名后，气泡标题、历史卡面及后台角色脚本上下文均刷新。
- 动态卡在沙箱内将变量从 0 更新为 1，整页刷新后仍读回 1；相同 HTML 的成功重绘确实创建新沙箱，旧卡在候选就绪前保持可见。故意制造的重绘失败明确报错并保留旧卡，没有部分替换。
- 动态 iframe 仅有 `sandbox="allow-scripts"`，没有 `allow-same-origin`；CSP 的 `connect-src` 继续为 `none`。隐藏候选的只读限制、来源窗口及剧情身份校验没有放宽。
- 明暗主题下卡面与表单均可读。纯静态卡的 `srcdoc` 约 199 KiB，未装入脚本兼容库；动态卡约 817 KiB，仍包含完整兼容运行时。浏览器最终日志无页面错误，验收宿主已关闭且监听端口已释放。
- 本轮没有配置模型凭据或调用真实模型，也未导入任意第三方卡；因此只证明上述安装、卡面、重绘、持久化和安全边界，不声称全部 SillyTavern 卡或模型生成效果均已验证。

同一源码的最终本地验证为：`npm run build` 通过；156 个测试文件中 2245 项通过、1 项 POSIX 专属用例按预期跳过；439 文件发布白名单、差异格式检查通过。正式 Release 附件仍只使用最终提交通过 Windows/Ubuntu CI 后生成的安装包及校验和。

## 0.1.5-rc.2 分支输入队列边界（2026-09-19）

已核对 `dsh-agent` 的 `AgentSetup(agentCtx, agent)`、`Inbox.clear()` 与 `dsh-agent-loop` 的 setup/publish 时序。rc.2 通过 `agent/inbox/spliced` 持久化 next-turn/next-step；`session/end-seed` 不会清空队列。楼层前缀可能留下已入队、尚未消费的输入：回退后下次发消息会重放它；重新生成在 turn/start 前截断，再显式 followup 时还会重复处理同一输入。

分支统一在 setup 中先清空子 agent 的继承队列，再挂载预设；宿主在发布前将 setup 追加的取消事件写入存储。该操作不驱动模型、不修改来源会话，也不改变旧事件的序号、surface 引用和 inheritedEventCount。取消日志使重启后的队列投影同样为空；不采用发布后临时清内存或删改历史 splice 的方案。旧分支不自动迁移，需更新并重新回退。

真实 AgentRegistry、AgentLoop、Session、临时剧情目录与手写模型适配器回归：修复前复现回退续聊重放旧输入、重生成重复输入、编辑用户消息先执行旧内容；修复后四项通过，另覆盖助手删除分支的两类队列、发布时日志与后续日志冷重放、父会话日志和排队输入不变。冷重放使用真实 Session 重建快照，未调用真实模型或执行浏览器点击，也不是完整磁盘持久化后端重启验收；发布前写盘顺序另按 rc.2 宿主源码核对。

## 0.1.5-rc.2 PTC 返回值边界（2026-09-19）

核对 `dsh-tools` 与 `dsh-code-runtime-worker-thread`：子工具输出在交给程序前已经过无损 JSON 与 schema 校验；程序重组结果后的最终完成值另行校验。例如成功的写工具没有 `error` 字段，`return { ok: r.ok, error: r.error }` 会产生 `invalid-output: program completion must be lossless JSON`。顶层不返回值是允许的，不能把此错误归因于漏写 return。短写入结果可直接 `return r`，或对选取的可选字段使用 `?? null`。

真实注册表、worker、Session 与临时剧情文件回归已复现上述错误：外层失败后子调用仍成功、记忆仅写入一条、同轮落盘确认保留，正常楼层 WAL 回滚可撤销。原样返回与 null 投影均覆盖成功、相似记忆拒绝和未开楼层拒绝，并保留失败信息。截图未提供完整调用代码，回归证明的是这类失败机制，不认定截图中的具体错误字段。测试使用工厂数据，不调用真实模型。

## 0.1.5-rc.2 预设真实请求核对（2026-09-19）

核对已安装 agent、agent-loop、system-prompt、llm、session 的 package.json、公开声明和 lib：实际顺序是 `systemPrompt.assemble → agent/pre-step → step/start → agent/request → system/user 日志提交 → deriveMessages`。因此采样可读取本轮已冻结计划；后续请求从已记录的 header 起步，空 stop 必须清除上一轮插件值，maxTokens 回退只恢复显式 AgentOptions 上限。

runtime context 是 user 快照，且跨轮也按正文去重。PHI 仅移动到 turn 而不改变本轮标记，会在第二轮留在旧位置；当前为包含历史后/depth=0 指令的计划加冻结轮号。`agent/pre-step` 只接收 UserMessage，`agent/request` 不接收可替换 messages，llm 边界深冻结；这些公开接口不能提供精确非零深度或 assistant prefill。

`presetLiveRequest.test.ts` 使用真实 AgentLoop、Session、SystemPrompt、临时剧情文件和手写 LlmAdapter 流，验证连续两轮尾部指令、卡级覆盖、同轮工具后的计划冻结、下一轮采样更新及停止词清空；图片和工具消息保持宿主结构，WAL 正常提交。没有调用真实模型，不将这些结构检查称为生成质量验证。

同日补查 `llm/stream` 的 `next()` 无替代 options 参数，session-projection 不提供完整消息布局。此前修复内建标记往返、同序号稳定排序、同深度角色排序、常用宏及格式字段，并新增全局角色覆盖偏好；随后将 DeepSeek 官方普通聊天接入自持有公开适配器的布局投影，仍未升级宿主或另开普通聊天调用。布局通过合法 user/message 的可扩展 source 保存，原宿主消息与工具前缀保留。其它供应商仍采用两段映射，真正 prefill/prefix 仍需供应商编码支持；结构测试不保证模型遵循所有指令。

进一步核对 rc.2 `LlmResolvedModelInfo.systemPromptUpdate`：`in-history` 是“最后一条 system 为完整有效提示”，未声明则只读取首条 system。已准备模型能力与 endpoint、凭证等一同冻结；途中 system 使用累计完整快照，保留 SDK、其它宿主系统段及先前系统预设，只读首条的模型则合并系统指令并显示兼容说明。不能仅凭 wire 第一条仍有 SDK 就断言它未被后续 system 替代。真实 AgentLoop 与手写 HTTP/SSE 同时覆盖这两类模型。

最终验证：原位 `npm ci` 成功，依赖审计 0 项已知漏洞；构建通过，154 个文件中 2168 项测试通过，Windows 跳过 1 项 POSIX 用例。`npm pack --dry-run`、437 文件发布白名单、doctor 与 backup CLI 检查通过。使用独立临时 DSH_HOME、Windows / Node 24 / rc.2 加载最终构建并重启，真实浏览器确认 Tavern 模式、设置入口和预设面板正常；重启期间仅出现预期断线重连警告，未出现页面错误。此冒烟没有调用真实模型、导入用户资产或改动用户宿主，普通请求角色、图片上传、工具多步、路由切换及磁盘恢复由真实宿主对象与工厂 HTTP/SSE 集成测试覆盖。临时页面和验收宿主已关闭；这些检查不代表任意预设的生成效果已获验证。

### v0.3.0 发布前的全工作区复查

本次将预设、宏、模板、实际请求、卡面与显示重试、MVU beta、PTC 纪律及分支输入队列的全部未提交改动统一审查。进一步修复模板和实际布局的聊天深度不一致、纯图片身份丢失、宏 fallback 混入通知、纯空白覆盖语义、官方别名关闭思考的回退、非法 in-chat 深度晚失败，以及列表/引用中 Tab 代码围栏列偏移问题。相关用例先复现错误再验证修复。

请求投影缓存重复锚点和插入边界，覆盖 2,048 条历史与 8,192 个同边界/相对插入；相邻自有 system 合并后再生成完整快照，保留宿主消息边界和稳定 ID。请求诊断在序列化前剥除私有布局，诊断失败不阻断发信；文本窗口估算明确排除图片、工具编码和供应商封装，超限只提示，不按粗估丢弃指令。

v0.3.0 本地最终构建通过，154 个测试文件 / 2187 项通过，Windows 跳过 1 项 POSIX 用例；独立目录使用相同 manifest、锁文件和 .npmrc 完成干净 npm ci，审计 0 项已知漏洞。437 文件发布白名单、doctor/backup CLI 与差异格式检查通过。发布附件使用最终提交通过 Windows/Ubuntu CI 后生成的安装包，安装包的启动验收和 CI 链接记录在 GitHub Release 中。

升级需完整重启后台；旧导入预设重导入才能补回此前未保存的字段。in-chat 深度须为非负安全整数；旧负数、小数等非法深度须先修正。纯空白格式或覆盖现在清空对应内容。其它供应商的两段映射、专用助手预填、模型窗口与实际生成效果边界仍保留，不将本次修复宣称为全量 SillyTavern 等价实现。

## 0.1.5-rc.2 真实宿主 UI 复查（2026-09-16）

在 Windows / Node 24.18.0 / dsh `0.1.5-rc.2` 下，以独立临时 `DSH_HOME` 加载最终构建的 `lib/index.js`。工厂 overlay 关闭自动目录选择器并挂载官方 browse 后端与客户端两面；Tavern 预设指向当前 `lib/agent.js`。

- 在真实浏览器中添加工厂工作区、切换 Tavern 模式、创建和编辑手写角色卡、绑定角色并开始对话。
- HTML 沙箱 iframe 保存工厂变量 `smoke_count=7`，浏览器整页刷新后仍读回 7；切换备选开场白创建真实子会话，核对来源剧情的 helper 状态保留与子剧情的楼层回滚，随后在子剧情保存记忆与世界变化。
- 宿主重启后，子剧情的记忆与世界变化各保留一条；返回来源会话仍可从卡面读回变量 7，来源面板的记忆与世界变化均为零。只读提示词预览可以打开并展示 standing 模拟结果，最近宿主请求为空，与未发起模型调用一致。
- 在旧构建的世界书关键词输入框键入 `/\d{1,3}/, 港口`，UI 与磁盘均复现被拆成三个关键词；重建并重启实际宿主后，同一路径在 UI 与磁盘均确认保存为两个关键词。修复同时应用于主、次关键词，词法扫描不执行用户正则。
- 角色卡局部保存忽略 `undefined`，避免清空未提交字段；真实文件系统与 service 回归验证重新读取、导出仍保留其它字段，显式空串、空数组和深度提示 `null` 仍可清空。

本批新增 7 项回归，未发布版本累计新增 41 项；全量 129 个测试文件、1702 项测试通过，构建、doctor CLI 冒烟和 npm pack 白名单检查（405 个文件）通过。浏览器无错误日志，仅记录主动停机重建期间的连接重试；验收页与工厂宿主进程已关闭。未配置模型凭据、未调用真实模型，也未使用真实用户剧情；此次验收覆盖上述工厂交互与持久化路径，不代表全部第三方卡或模型生成链路已经通过验收。

## 0.1.5-rc.2 升级核对（2026-09-14）

- 全局 CLI 与项目内宿主包升级到 `0.1.5-rc.2`；peerDependencies、overrides、devDependencies 同步精确版本，锁文件重新解析。React / React DOM `18.3.1` 显式作为测试开发依赖，与 react-test-renderer 一致；客户端仍使用宿主提供的 React。
- `assistant/chunk` 不再是持久事件。`assistant/message.data.stream` 保存该消息的完整定时流，未产生正文的尝试为 `assistant/attempt`；assistant 不再允许 sourceEventSeqs。正常收口只认可该消息自身流中唯一且位于末尾的 stop，不能借用同一步重试的 finish；开场白使用空 stream。正文编辑清空过时的嵌入流，消息桥同步清理对应尝试记录。
- 冷会话读取改为 `sessionPersistence.open(id, 'read')` → `handle.read()`，在 finally 中关闭句柄。归属校验、读取故障传播及在线会话优先保持；不取得写所有权或为了展示执行恢复写入。
- `AgentLoop.create` 为异步。Inbox 由宿主 session projection 驱动，在 session/event 通知前已经更新；MVU 从有游标的日志折叠中读取 splice 前的输入，保留原消息 ID、队列目标和顺序。真实 Loop 回归覆盖拒绝、取消、维护等待、显式删除与日志重放。
- PTC 子调用日志改为 `tool/ptc-dispatch-start` / `tool/ptc-dispatch`；原生 PTC、多读并发、写入屏障及 standing 位于 TOOLS_SDK 后的回归通过。



验证：Windows / Node 24.18.0 下，127 个测试文件、1572 项测试全部通过；build 与 pack dry-run 白名单（401 个文件）通过。最终 lib 在独立临时 DSH_HOME 启动实际 dsh 0.1.5-rc.2，浏览器添加工厂工作区并创建会话，切换 Tavern 模式后出现角色选择入口。工厂 overlay 仅把目录选择器替换为官方 browse 两面；未配置模型凭据、未调用真实模型或写入真实剧情。验收页与宿主进程已关闭。这是基础 boot/UI 冒烟，不代表全部第三方卡或真实模型链路验收。

## 0.1.2-rc.1 历史观测（接口变更以上方新版本记录为准）

以下行为绑定 0.1.2-rc.1，升级宿主时逐条复查（以官方文档和宿主源码为准）：

2026-09-14 工具调用核对：原装 ptc 预设在 agent 面挂载 `@deepseek-ai/dsh-agent-tool-presentation`（`mode: ptc`），复用宿主 `codeRuntime`；Tavern 采用同一入口。`ToolRuntime` 仅向模型发送 `run_code` schema，七个 Tavern 业务工具的参数/规范输出进入 SDK，子调用仍经宿主策略管线、作用域与并发调度。四个读工具声明可并行，写工具保留独占屏障；`ok=false` 为可检查的业务拒绝，宿主错误以 `ToolCallError` 拒绝。rc.1 的 `TOOLS_SDK` 顺序为 5000，standing 使用公开 `getSectionOrder('TOOLS_SDK') + 10`；旧 order 210 会早于 PTC SDK，因此同步修订约定并递增 standing pin 版本。

验证：真实注册表、Agent、SystemPrompt、WorkerThreadCodeRuntime、Session 与临时剧情文件覆盖一次程序多操作、读取重叠、写后读、相似记忆更新、路径/楼层拒绝、WAL 回滚、步骤通知去重和普通模式隔离；实际组装断言工具前缀早于 standing、相同组装字节不变。全量 126 文件/1568 测试、build、pack dry-run 通过。在独立临时 DSH_HOME 启动 Windows/Node 24/dsh 0.1.2-rc.1，浏览器创建工厂工作区、将空白会话切换为 Tavern，成功显示角色选择入口。目录选择在工厂 overlay 中使用官方 browse 两面；预设指向当前 lib，未配置模型凭据或调用真实模型，未测实际模型延迟。测试页与宿主进程已关闭。

1. `Session.events` 数组属性已移除：读全量用 `snapshotEvents()`（下次追加前缓存复用，放心多次调），单条 `eventAt(seq)`，日志长度 `session.seq`。`header.seedLength` 移除：fork 继承前缀长度是 `session.inheritedEventCount`；`agents.create` 的 meta 写 `isSeeded: true` + 顶层 `inheritedEventCount`（与官方 `SessionStore.fork` 同形）。
2. 会话预设判定：`resolveSessionPreset` 帮手移除，官方路径是 `agentPreset` 会话投影；插件封装在 `sessionPresetId`（投影缺席时手动折叠 header + `agent-preset/selected` 兜底）。
3. client 侧：「新对话」动作从 `ctx.workspaces.startSession` 迁到 `ctx.uiWorkspace.startSession`（seatWatch 双路径兜底）；`dsh-client-runtime` 包删除，`dsh.client.inject` 不再需要（bundle 只 require seed 词：react 系 / cordis / ui-slots / ui-primitives）；`dsh-client-web-react` / `dsh-client-schema-form` / `dsh-client-ui-attachment` 均不在 seed。chat.node 图片用 owner 的 `renderMessageImages`；`fileMentions` 是 owner 函数，先解析再传给 MarkdownText，必填 `labels` 用 `useMarkdownLabels()` 获取。界面语言 auto 档经 `ctx.locale.getSnapshot().active` + `subscribe` 跟随宿主（LocaleRuntime）。会话列表摘要 `SessionSummary` 顶层不再有 `agentPreset`，预设 id 只读 `projectionValues.agentPreset`（`src/client/mode.ts`，读错位置会让全部会话面 UI 静默）；`SessionSnapshot` 移除 `composerPhase`，英雄区空会话判定用 `blank && !promptAttempted`。
4. 杂项迁移：`settingsNamespace()` 帮手移除（`settings.register` 直接吃字面量）；`JsonValue` 从 `dsh-session/types` 挪到 `@deepseek-ai/dsh-util-values`。dsh 把大量运行时依赖改写成了 peer（`dsh-jobs` / `dsh-session-persistence` 等基础包不再自动安装），本仓库 `legacy-peer-deps` 下这些宿主内部包必须显式列进 devDependencies，且 cordis / schemastery 要跟随宿主版本（当前 4.0.2 / 3.18.2）。
5. web 设置 RPC 无命名空间白名单（rc.2 起，0.1.2 仍成立），宿主通用设置页也能看到/改 `dsh-tavern` 的键——宿主行为，不要为此改插件面板。
6. 会话头宿主原生面包屑（`conversation.session.header.lineage`）与楼层级 ‹ n/m › 互补，不要替换那个 slot。
7. primitives `Modal` 的 dialog 外壳自带 `width:min(380px,100%)`：弹窗宽度档（`Dialog` 的 md/lg/xl/full）必须经 `className` 落在外壳上，挂在 `contentClassName`（内容层）会被外壳宽度卡住不生效。
8. 插件直接追加开场白的 `turn/start` 会推进服务端 `sessionListMetadata.blank`，但不经过客户端 `session.send` 的 blank 更新路径；成功后调用 `sessions.refresh()` 同步会话列表，避免「新会话」复用和英雄区预览残留。绑定读取附带日志判定的 `conversationStarted`，用于防止 blank 镜像滞后时误清绑定。
9. Vue 全局构建的模板编译依赖 `Function`。交互卡 srcDoc 在 `sandbox="allow-scripts"` 的 opaque origin 内允许 `unsafe-eval`，包括 `document.write` 重写后的文档；不增加 `allow-same-origin`、主窗口桥或默认网络访问权限。
10. 卡面酒馆助手兼容见 [接口说明](TAVERN_HELPER.md)：真实会话以用户可见 append 事件建立连续消息下标，变量使用稳定消息身份落在 state/helper.json，经剧情锁/WAL 提交；分支快照包含此文件。opaque-origin iframe 只获得固定会话/消息的变量业务桥，预览没有持久化能力。重绘不能丢失保存回执；卡面替换、切换会话后丢弃旧回复。历史改变、生成中、旧表冲突和坏日志必须拒绝写入。
11. 备份恢复必须创建新 iframe 文档。直接 `document.write` 重跑第三方页面会留下顶层词法绑定并触发 const 重声明；跨 opaque-origin 刷新也不能依赖窗口名传递数据。文档内的常规 rewrite 仅用于加载卡片内容，桥只装一层原生包装，重装前清理旧观察器与定时器。
12. 手机设置布局：`dsh-client-ui-settings-general` 的设置 dialog 在 390px 视口中宽 342px，仍保留 188px 导航及正文两侧 48px 内边距，使 Tavern 正文只剩约 98px（含滚动条差异）。`styles.ts` 在视口不超过 560px 且 dialog 含 `.dsh-tavern-panel` 时，把原导航按钮排成横向滚动顶栏；通过直属 `nav` 与相邻正文结构限定外壳，未替换宿主节点或改其状态。其它设置页/桌面恢复宿主样式；升级时核对 SettingsPanel 结构。主会话侧栏由 `dsh-client-ui-layout` 在低于 1024px 时自动折为 56px，手动展开由用户控制，插件不调用 toggle 强制修改桌面宽度。手机弹窗使用动态视口高度和 flex 正文滚动分配，第三方 iframe 内部是否响应式仍由卡片自身实现决定。
13. 后台角色脚本运行器挂在会话头部，面板隐藏时 iframe 保留，暂停/解绑/切换会话时卸载。脚本正文通过 JSON 编码的可信引导创建内联 module，不在主页面执行；脚本按钮和异常展示留在沙箱。剧情变量初始化仅发生于缺失的 script 表，重启不得补回已删除字段。
14. 剧情事件由主页面固定 sessionId/storyId 分组，消息来源须匹配 iframe 窗口；运行时 epoch 用于拒绝旧文档回执。监听在各自沙箱执行，父页面仅排序、转发有界 JSON 和等待回执。重入事件不持有全组串行锁；停止/重写移除监听，超时明确失败。同步入口不能同步等待跨 iframe 回调。

15. 重启后浏览旧会话可能只有持久日志，`ctx.sessions.get` 只返回已在线的 Session，不能据此判断“没有开场白”。展示与空白判定优先在线日志，否则使用 `ctx.sessionPersistence.inspect` 的不可变检查结果；不能用会修复并写盘的 `load`，也不能为展示调用 agents.resume。已验证冷会话 EJS 开场白可读且不落模板变量。
16. rc.1 的输入和 assistant Message 都有稳定 `id`。按消息模板变量使用该 id，不能由正文或事件 seq 推断；编辑后的新 Message.id 即使沿用 seq 也不能复用旧快照。历史投影仅使用 deriveMessages 可见消息，并按 inbox id 对待入日志输入去重。真实分支复制继承消息 id，变量和 sticky 仍随 story 文件独立推进。
17. 角色脚本编辑器只经类型化 remote 保存共享角色资产，使用资产锁和脚本树修订，保留同期更新的角色字段。写盘成功但回执失败时必须失效缓存，重试相同目标值不重复写入；剧情 script 变量不随资产编辑重置。当前浏览器工厂冒烟已验证真实 React 编辑和文件落盘，不能代替安装环境的宿主 boot/UI 验收。

18. 全局和预设脚本资产与普通预设写入共用数据根锁。全局库无缓存，预设写入即使回执失败也失效缓存；普通预设表单不能覆盖脚本管理器中的最新设置。运行器按绑定的 presetId 选库，异步加载末尾重新核对绑定，不能把旧预设代码安装进新绑定。脚本沙箱仅得到有界三库快照，仍无通用资产/文件桥。

19. 沙箱脚本库写入持有绑定锁，再进入对应资产锁；目标 ID 从绑定派生，旧 preset/story 的令牌拒绝。保存回执先送到来源窗口，沙箱确认后才通知后台重载；React 普通重绘不丢回执，srcDoc/剧情切换后丢弃旧回包。序列化到 iframe 的解析器依赖显式传参，不依赖构建器模块变量；构建产物已做真实浏览器 SDK 保存冒烟。

20. 现代世界书 SDK 通过固定会话/消息桥读写；公共库从目录 ID 或唯一原始名称解析，角色内嵌书和聊天书使用固定别名。旧绑定令牌不能写入新剧情；聊天书仅在正常完成楼层内经 WAL 保存。updater/predicate 留在沙箱，条目正则不会在主线程运行。构建产物已通过真实浏览器世界书保存冒烟，验证公共书读取修改、正则关键词转码、聊天书落盘与完成楼层 WAL；此工厂验证仍不能代替安装环境 boot/UI 验收。

21. 旧 lorebook 条目接口只在沙箱转换字段并复用现代 worldbook 桥，不添加新 remote 权限。局部更新必须保留未指定字段、未选中条目及现代 extra，UID 无效整批拒绝。组内计分支持条目覆盖全局，先过滤启用计分的低分候选，再按 override/权重选择，同分仍可加权。新增可选字段也须纳入模板恢复的严格 schema：保留 true/false/null，兼容旧快照缺省，坏类型拒绝。旧接口的构建产物已做真实浏览器 CRUD、部分更新及聊天书 WAL 冒烟。

升级 dsh 的检查清单：

- 模板回复处理依赖 `assistant/chunk` 的唯一末尾 `finish.reason.kind=stop`、`assistant/message` 的 seq/turn/step 与 `turn/end.reason.kind=completed`。必须在当前楼层关闭前保存展示快照；client 的 finalNode.seq 传给只读渲染接口。升级时核对这些真实字段和 turn 状态，不能在刷新回调中执行持久脚本。
- `package.json` 四处版本同步：`peerDependencies`、`overrides`、`devDependencies`、`allowScripts`（全部精确版本，不带 `^`），锁文件只重解析宿主条目；`npm run host:check` 会拦住漏改，CI 与 release workflow 都执行它。
- 逐条复查上面注记在新宿主上是否仍成立，失效的改掉并从本节删除。
- 对照官方文档的 breaking changes：slot、profile/bundle、patch 层顺序、system-prompt 瀑布、agent 事件、session 读取 API、client seed 模块表。
- `npm install` → `npm run build` → `npm test` → `npm pack --dry-run`，再 `npm run dev` 实机冒烟（peer 缺失只会在宿主 boot 时暴露）。
- 扫描宿主包的非可选 peer：缺失的宿主内部包补进 devDependencies；cordis / schemastery 等跟随宿主版本（0.1.2 起宿主大量依赖改写为 peer，`legacy-peer-deps` 不会自动装）。
- 在 `CHANGELOG.md` 记一行适配的 dsh 版本。


另见宿主源码：`dsh-agent-loop` 在 buildRequest 中深度冻结 GenerateOptions；`dsh-llm` 的 llm/stream waterfall 可观察请求，但 next() 不接受替换消息。本插件只读观察，不在中间件另起调用。

22. 世界书绑定桥只修改固定会话。主书显式关闭与角色附加书进入真实管线及修订标签；同轮修改仍重放冻结计划，下一轮生效。聊天活动书、闲置副本与选择共存原有 chat-lorebook.json，切换/解绑按完成楼层 WAL 原子保存，分支复制后独立；@dsh/chat 是主书固定标识，其它私有书须使用 getter 返回的标识。绑定回执更新令牌，拒绝迟到 updater；不确定保存失败先刷新再重试。真实文件系统测试覆盖副本复用、回滚、分支、损坏日志与写后报错。 构建产物的真实浏览器工厂已验证新旧绑定接口、切回保留修改、解绑保留内容及磁盘 WAL；真实 React 面板测试验证无主书/附加书保存。这些验证仍不代表安装环境 boot/UI 已完成。

23. 旧世界书设置适配为会话绑定内的部分引擎覆盖，绑定令牌含实际引擎设置，旧令牌拒绝提交；同步 setter 先改沙箱快照，flush 等待串行持久化，失败保留草稿并明确显示。设置与全局书选择在同一次绑定保存中应用，管线使用覆盖后的设置，同轮计划冻结不受影响。最少激活扩深与递归共用一次求值，保持条目固定扫描深度、总轮数与预算约束，定时器只推进一次，概率失败不重掷。 构建产物已通过真实浏览器工厂验证：连续同步设置、等待持久化、磁盘部分覆盖、实际扩深命中与 3000 token 预算一致。此工厂不代替安装环境 boot/UI 验收。

24. 助手消息正文编辑不使用 surface replace 冒充可见历史修改，而是通过 agents.create 的独立分支保留完整后续消息。修改后过时的 surface replace 和相关压缩记录替为 ignorable 插件标记，日志 seq 保持连续，原始 append 重新进入模型视图；被改消息的旧 chunk 及 sourceEventSeqs 不再用于展示新正文。正文替换保留非文本块；新 seed 必须通过 Session.create 校验，再准备剧情 WAL 回滚、发布并绑定子会话。真实 Session + 文件系统测试覆盖压缩后的编辑、后续正文、WAL 损坏、创建失败及准备期间新增事件；真实 React/SDK 测试覆盖回执确认后导航与迟到回执隔离。 构建产物的真实浏览器工厂已完成跨沙箱批量编辑、确认回执、压缩后模型视图与分支事实回滚验证；原会话仍保留原摘要和全部事实。此工厂不代替安装环境 boot/UI 验收。

25. 消息 data/extra 不改宿主日志，按稳定 Message.id 同存剧情 helper.json；普通变量提交必须保留 extra。纯数据批量写入当前完成楼层，正文混编在回滚后的草稿中写新身份；snapshotStory 提供的复制句柄不携带 WAL，显式数据必须另建绑定草稿 Wal 的 WorkspaceFs，以保证再次分支/回滚可撤销。旧格式没有 extras 时按空表读取，畸形表拒绝加载。真实 Session/文件系统测试覆盖源剧情隔离、子会话 WAL 撤销、并发 CAS、历史变化及写失败；SDK 测试覆盖等待期间本地变量不丢失与后续串行保存。 构建产物的浏览器沙箱已验证先纯数据保存并即时读回，再混编正文和数据；子剧情保留后续正文与显式数据，来源保持原数据、全部事实和摘要。此工厂仍不代替安装环境 boot/UI 验收。

26. getChatMessages 返回的完整消息和当前 swipe 页可经 SDK 归一后写回，宿主桥仍仅接收 message/data/extra 等固定字段。保持原值的名称、角色、隐藏状态及旧角色标志作为一致性检查；修改它们或未选中页会失败。当前页始终反映真实消息正文和剧情 data/extra，不能用角色资产中的旧开场白覆盖已编辑正文。不同表示只有一处变化时采用新值，矛盾的新值拒绝整批执行。 构建产物的真实浏览器沙箱已验证完整消息对象的数据写回、当前 swipe 页的正文/变量/元数据混编及原剧情隔离；宿主分支创建仍使用模拟适配器，此验证不代替安装环境验收。

27. 完整 swipe 按稳定消息身份保存在 helper.json 的 swipes 中，每页正文/data/extra 独立；当前页变量仍以普通 message 作用域为准，快照与 SDK 均投影最新已保存值。切换选中下标或当前正文修改采用真实 Session 编辑分支并撤销派生事实，未选中页修改直接经完成楼层 WAL。页集合及其数据在草稿回滚后用带 Wal 的 WorkspaceFs 保存，旧值冲突、坏页集合和写失败均在发布前拒绝。真实 Session/文件系统测试覆盖多次来回切页、重启、相同正文切页、来源隔离、子楼层回滚和故障；构建产物的真实浏览器沙箱已验证新增页、读取每页数据及切页后的实际模型历史。宿主创建仍为模拟适配器，安装环境 boot/UI 和生命周期事件验收待完成。

28. 真实会话旧消息/Slash/上下文入口只调用现有 setChatMessages 事务，避免旧闭包仍直发开场白桥。上下文保存限定原 story/historyRevision，并比较改动行的最新数据；不传整段未改历史。草稿数组与行引用保持，确认回执后按字段合并继续编辑，分支回执不重写旧页面草稿。variables/swipe_info 只作为完整页数组别名，冲突拒绝，结构性聊天变更仍未适配。预览保留已有开场白选择。 构建产物的真实浏览器沙箱已验证通过原生风格上下文新增页和保存变量/元数据，再由 /swipe 切页；子会话模型历史和页数据正确，来源未改。此工厂使用模拟宿主创建适配器，仍不代替安装环境 boot/UI 验收。

29. 删除不原地改宿主会话：可见 user/assistant 消息替为不含原内容的 ignorable 标记；assistant 同一步 chunk/tool call/result 成组移除，turn/step 边界保持，过时 surface replace 与 compaction 清除。相同步骤有多个独立 assistant 时拒绝歧义目标。剧情草稿回滚后显式清除删除消息的 helper scope/extra/swipes，其余混合修改按原 seq 定位新消息，不能沿用删除前数组下标。真实 Session 及其官方关系不变量伴随插件验证工具配对、完整删除 66 条后继续回合、坏 WAL/宿主失败和来源隔离；React 验证来源固定与回执后导航，SDK 支持 100 条以上的单批请求。构建产物的真实浏览器沙箱已验证压缩历史中的批量删除、后续正文及事实回滚，原会话保留摘要和全部事实。此工厂使用模拟宿主创建适配器，仍不代替安装环境 boot/UI 验收。

30. 消息重绘只针对当前页面已挂载插件气泡，宿主原生用户气泡与原生渲染事件仍待适配。固定 sessionId/message seq 由气泡提供；SDK 只提交 storyId/historyRevision/连续可见下标。准备阶段保存发起卡变量、保护目标卡变量/脚本/世界书/上下文草稿及卡外恢复表单，拒绝准备期间新业务请求；全部准备后等待来源沙箱确认才替换，失败/超时/卸载取消旧准备。正文仍通过既有只读 renderOutputText，不重新提交模板。真实 React/SDK 测试覆盖来源与历史校验、准备失败、重复刷新、相同正文、草稿、超时和迟到确认；构建产物的真实浏览器验证使用实际 SpeechBubble、Session、TavernService 渲染及变量 WAL，连续三次独立沙箱加载后变量保留、日志事件数不变。仅宿主 primitives 外壳和 remote 传输为工厂适配，此验证仍不代替真实安装环境 boot/UI 验收。

31. 插件气泡生命周期从真实卡面就绪信号产生，来源窗口与当前 helperEventConnect 运行时身份同时校验；一条消息的全部 HTML 块就绪后只发送一次 CHARACTER_MESSAGE_RENDERED(id, normal)，Markdown 在 React 提交后发送，流式与旧文档不报完成。all 重绘等待所有目标的显示及监听回执，再发送 CHAT_CHANGED(storyId)。宿主发布者复用有界 JSON 顺序路由，监听前同步最新剧情；快照准备失败保留 once，执行后失败不撤销已保存结果。真实 React、多卡面/旧身份/回执确认测试及编译 SDK 测试已覆盖；真实浏览器工厂使用实际 SpeechBubble、Session、TavernService 和 WAL，三次独立沙箱加载依次观察到 rendered(0,0)、rendered(0,1)、rendered(0,1)、chat(1)，宿主日志不变。此工厂仍不代替安装环境 boot/UI 验收。已核对 0.1.2-rc.1 的 ISessions.binding().eventSource 提供同步 replace/prepend/append 日志窗口；实时订阅只消费当前 Tavern 会话同步 append，并在 replace 时取消旧任务，prepend 不回放；可见序号由服务端完整历史投影，正常接收必须经过对应 turn/end 的成功收口回执与 WAL 验证。非正常轮次仅通知停止。宿主事件使用 prepare/execute 许可防止迟到来源执行和准备超时丢失 once。旧气泡/clean 沙箱刷新先同步权威修订，等待首消息的后台脚本随剧情通知启动；已有脚本不因新消息重建。实时浏览器工厂使用最终编译的订阅器、SpeechBubble 与沙箱 SDK，以及实际 Session、TavernService 和剧情 WAL；依次观察 start、sent(1)、received(2)、end(2)，接收监听持久化计数一次，随后 all 使旧/新 iframe 各重建一次，WAL 已提交。只替换宿主原语外壳和日志/remote 传输；实际宿主验收见下一条。

32. 2026-09-06 在 Windows/Node 24 与实际安装的 dsh 0.1.2-rc.1 中完成酒馆助手基础 boot/UI 验收。使用独立临时 DSH_HOME、工厂工作区及 profile/node_modules 到当前 checkout 的 junction；默认 web profile 加项目补丁，无额外模型凭据。真实浏览器通过 Tavern 面板导入手写 JSON 卡，选择工厂工作区与 Tavern 模式、绑定角色并点击“开始对话”，成功显示含 jQuery 的开场白卡面与模块后台脚本。卡面保存 count=1，后台脚本按钮保存 count=2，两个沙箱同步显示 2；refreshOneMessage 重绘与整页重开后均保持 2。核对仅工厂剧情中的 helper.json 为 count=2、对应 WAL committed=true，宿主终端无新增错误，无模型调用。目录选择采用官方 browse 两面替代 native 选择器，仅修改工厂 overlay；没有降低卡片沙箱权限或使用真实用户数据。全部验收页与宿主进程已关闭。这一验收覆盖已实现的基础链路，不代表全部第三方卡、MVU、生成控制与跨页面功能已经兼容。

33. MVU 手动接口在各自 opaque iframe 中运行：同步读取剧情快照，解析顺序等待同剧情可变事件，显式 replace 等待已有 CAS/WAL 回执。真实文件系统与模拟宿主验证消息变量保存、WAL committed、重建后可读和同卡剧情隔离；解析不改宿主正文、不创建分支。编译产物的真实浏览器工厂验证 add 后保存 15、Zod 拒绝负数、字符串 18 转为数字并保存、再次解析由结束钩子钳制为 20；模拟保存失败时存储仍为 20、编辑草稿保留 19，卡面显示错误。schema 留当前 iframe，仅约束编辑器。实际浏览器发现并修复 label 样式覆盖 hidden 属性的问题，复查聊天/消息作用域的目标输入切换通过。工厂的保存传输为内存适配器，文件系统行为另由集成测试覆盖；未将这一工厂称为完整 MVU 卡或安装宿主全量验收。世界书初值、正常 stop 自动更新、经典 schema 和模板变量整合仍待适配。临时页面和服务均已关闭。

34. 原生 MVU 自动模式使用 agent/turn-stopping 串行钩子，在正常 stop 的 assistant 已追加、turn/end 与下次输入 claim 之前持久登记任务，随后立即返回，不把浏览器变量处理算成模型生成。下一条输入由 runMaintenance 同步认领真正 idle 并等待，兜底 assemble 门控保留原生输入身份/顺序/目标；等待不占 session task 队列或剧情锁，取消不伪造唤醒消息。页面断开或脚本失败保留任务并阻止旧变量进入新轮次。实际开场白既有旧 turn 0，也有 greeting 来源标记的 turn 1（无模型 finish chunk），两者均纳入测试。完成数据与任务回执同写 helper.json；闭合楼层追加 MVU 写先 reopenFloor 保留原始回滚快照，WAL 恢复成功后才确认完成。

rc.2 的公开 SessionEventSource 将流式回复结算发布为 `settle-assistant`，其 `entry` 可缺省，不带 `entries`。实时追加只处理 type=event 的持久记录；结算读取单个持久 entry，临时流的分数 seq 不推进基线或消费游标。replace/prepend 仍不回放历史，最终接收通知仍等待对应 turn/end 的剧情收口回执。测试加载同包的真实事件源 ESM，并用真实 AgentLoop 与工厂 LLM 流验证无人提交 MVU 时回复仍正常 completed/idle、下一条输入保留且提交后才生成。

2026-09-14 在实际 Windows/Node 24/rc.2 安装环境完成启动与页面冒烟：先取消旧代码卡住的生成，重建并重启宿主，刷新后正文保留、会话恢复空闲、卡面不再显示 `change.entries is not iterable`，消息选项正常出现。没有发送真实模型请求；新回复的自动 completed/idle 与待处理变量门控由上述真实 Loop 和工厂流测试覆盖。全量 127 个测试文件、1576 项测试通过，打包白名单检查通过。

2026-09-06 的真实浏览器双沙箱工厂验证：异步模块就绪后初始化 7，经 INITIALIZED 钩子变 10；后续 stop 工厂输入依次得到 15、20，下一次命令到 25 经结束钩子限制回 20，监听读取的当前消息位置为 1/2/3。随后在实际 Windows/Node 24/dsh 0.1.2-rc.1 的独立工厂 DSH_HOME 启动新构建，UI 开启原生 MVU；真实 turn 1 开场白完成初始化，磁盘 pending 为空、完成回执一条、WAL committed=true；原有卡面按钮继续保存 count=3，未调用模型。此验证覆盖初始化和普通变量衔接；正常模型 stop 链路另由真实 AgentLoop/Session 与手写流适配器集成测试验证，未调用真实模型。

本次原生 MVU 工厂整页重载后仍显示 count=3 且没有重复初始化；验收页、浏览器工厂服务与真实宿主进程均已关闭。


### 0.1.2-rc.1 脚本选项输入核对

已核对安装包 `@deepseek-ai/dsh-client-ui-conversation` 0.1.2-rc.1 的公开 `IConversation.input.for(actx)` / `SessionInput.setDraft` 与 `InputState` 类型。脚本选项的可信点击处理经 `sessions.scope(sessionId)` 获取本会话输入面；限制当前会话、plain 阶段、无引用，保留原草稿。此前 AI 代答采用剪贴板仍保持原行为，不能据此推断宿主完全没有可写草稿 API。

### 2026-09-19：rc.2 角色、真实模型与恢复验收

Windows / Node 24.18.0 / dsh 0.1.5-rc.2，使用独立临时 DSH_HOME、手写角色与工作区、最终构建产物及官方 browse 目录选择器 overlay。真实 Edge 页面验证角色新建/保存、按标签与作者搜索、角色多行输入框的可访问标签。无内嵌书 JSON 卡也展示兼容预检；已知未实现接口与父窗口访问被正确列出，取消后列表不增加角色，再次选择同文件并确认后保存成功。预检未执行卡内脚本。

经用户指定使用本机默认模型，实际路由为 deepseek-official / deepseek-flash，页面显示 DeepSeek-V41-Flash / High。仅发送手写验收剧情：第一轮正确读出角色口令，第二轮通过原生 PTC 调用记忆写入并正常结束；真实剧情 memory 文件包含预期事实，楼层 WAL committed=true。全量自动化测试仍不调用真实模型。仅让临时宿主读取既有凭据存储，没有将密钥或用户剧情复制进项目、测试或备份。

停止临时宿主后，编译后的 backup CLI 完成 create → verify → restore：32 文件、42 目录、233731 字节，3 处可重装依赖路径在清单中明确排除，无结构/引用问题。恢复到新 DSH_HOME，重新挂载当前插件开发依赖并由宿主重建依赖后启动；页面读回相同角色绑定、开场白、两轮消息和工具确认，继续发送第三次模型请求正常回复「蓝色工具箱。」并恢复空闲。此演练覆盖实际宿主持久日志的恢复与续聊，但 verify 命令本身只校验其字节，不宣称完整解析所有宿主历史格式。

本次验证覆盖上述基础链路，不代表任意第三方卡、所有 MVU 行为或旧历史迁移都已验收；同类项目比较和检查结果见 [项目审查记录](PROJECT_REVIEW_2026-09-19.md)。

### 2026-09-19：依赖替换后的 Markdown 展示验收

在上述独立恢复目录使用 Windows / Node 24.18.0 / dsh 0.1.5-rc.2 和最新构建启动宿主。真实 Edge 页面导入手写 EJS 开场白卡，兼容报告正确识别模板；选择卡并开始对话后，加粗、双/三下划线、保留单下划线、emoji、表格和删除线正常展示，两个 iframe 均为 `sandbox="allow-scripts"`。本次没有发送新模型请求。

实际截图发现无自定义配色的卡面在深色主题下文字过暗：修复 iframe 继承宿主 color-scheme，并在可信文档头声明 light/dark 支持，不强制覆盖卡片文字或背景。修复后深色白字、浅色黑字均清晰；整页重载仍正常，测试外观恢复为跟随系统。切回先前已完成剧情，原角色、开场白、三轮回复与工具确认仍可读。验收页和临时宿主均已关闭。

旧未完成模板或跨轮回调闭包的升级拒绝由真实文件系统与 worker 集成测试覆盖；此 UI 冒烟不将其宣称为任意旧日志可自动迁移。

### 2026-09-19：关于页与更新检查

开发构建会让网页拿到新界面，但运行中的 Node 宿主不会同步重新加载新增服务方法。实际旧进程复现：角色目录正常，`tavern/getPluginAbout` 尚未注册；Web Connection 对缺失路由返回 HTTP 404，客户端包装为 `gateway/internal`。关于页只对本接口的固定 404 及明确的方法/描述符缺失给出完整重启提示，不把断网、磁盘错误或其它路由 404 误判为此问题。恢复需停止原 dsh 进程、重新启动后刷新网页，单独刷新或重试不能重新注册后台方法。

核对已安装的 dsh 0.1.5-rc.2：`dsh-host-plugin-inventory` 只提供 `list()`，没有版本检查或安装更新 RPC；普通设置 section 也没有公开的插件页跳转接口。正式安装方式仍是 `dsh plugin --profile <name> add <package>`。因此关于页只按需读取 GitHub 正式发布与该标签的 package.json、核对实际宿主版本，再提供发布说明及固定标签命令；不执行 shell，不触发安装或重启。桌面内部更新桥和 Cordis 配置重启不作为替代接口。

在独立临时 DSH_HOME、Windows / Node 24.18.0 / 实际 rc.2 宿主完成 Edge 验收：Tavern 的第八个页签「关于」可打开，项目链接为 `https://github.com/Amakurai/dsh-liketavern`；实际读取插件 0.2.5、宿主 0.1.5-rc.2，并正确识别源码开发挂载。点击「检查更新」显示禁用的检查中状态，随后从真实 GitHub 返回 v0.2.5，提示版本号一致，发布说明定位到对应标签；没有安装操作或模型调用。未来新版本、宿主不兼容、断网、超时和复制失败由手写响应与真实 React 测试覆盖。

宿主版本从本次 Node 主入口的真实路径定位，并核对最近包的名称、bin.dsh 入口和版本；不将插件旁的开发依赖当作运行宿主。无法识别的嵌入式启动仍展示插件信息，但明确说明无法判断兼容性，不生成更新命令。修正后重启临时宿主再次验证版本与真实更新检查均正常，验收页面和临时宿主已关闭。

最终构建、140 个文件 / 1982 项测试（Windows 跳过 1 项 POSIX 用例）与 425 文件发布白名单检查通过。另一运行中的宿主持有 Windows 原生动态库，仓库原位 `npm ci` 遇到占用；随后以 `npm install` 恢复完整依赖，在独立空目录使用相同 package.json、锁文件及 .npmrc 完成干净 `npm ci`，审计为 0 项已知漏洞。没有停止用户正在运行的宿主；依赖弃用边界仍见依赖安全记录。

### 2026-09-19：官方 MVU beta 入口与脚本跨窗口诊断

官方 `MagicalAstrogy/MagVarUpdate@beta/artifact/bundle.js` 纯导入与无版本入口采用同一个原生 MVU 适配，避免漏识别后加载要求 Vue 和父窗口全局对象的原版框架。只扩大到 `@beta`，未知版本、额外代码或相似地址仍保留原文。运行状态对浏览器明确拒绝的跨窗口读取显示「需要适配」，保留原始错误与 MVU 的失败阻断。

使用手写工厂快照和本次编译的 srcDoc，在独立本地测试页的真实 Edge 中验证：`sandbox="allow-scripts"` 下，关闭外部脚本和网络的官方 beta 入口成功返回就绪；读取 `parent.document` 与父窗口自定义加载标记均继续报跨域错误，并被诊断器正确识别。本次没有启动新宿主或调用模型，没有改动真实卡片和剧情；该冒烟不代表依赖酒馆主页面的状态栏、正文改写脚本已经迁移。

本次构建、147 文件 / 2090 项测试通过（Windows 跳过 1 项 POSIX 用例），`npm pack --dry-run` 和 429 文件发布白名单检查通过。原位 `npm ci` 遇到运行中进程占用原生动态库，使用锁文件恢复依赖后，在独立空目录完成相同 manifest、锁文件和 `.npmrc` 的干净安装；package.json 与锁文件未改变。测试页和测试服务器已关闭；安装验证临时目录的清理被执行策略拒绝，保留于系统临时目录，不进入仓库或发布包。

### 2026-09-19：消息卡面漏识别与加载恢复

修复孤立反引号、行内波浪号误开启代码状态，以及跨段反引号吞掉 HTML 围栏的问题；代码标记一次索引，真实代码跨度、未闭合围栏、引用与列表代码继续保持不可执行。核对实际安装的 rc.2 conversation / renderer / chat 包后，仍沿用公开 useSessions、assistant-step 与 finalNode.seq 契约。角色绑定读取失败保留同会话卡面，首次失败展示重试；切换会话不复用旧绑定。展示请求失败保留原文并允许手动重试，交互卡开关变化重新加载展示。

普通正文和已提交模板片段均返回有界、去重的展示正则失败诊断，成功规则继续生效。真实文件系统与模拟宿主测试验证重复读取不改历史或模板状态；真实 React 测试覆盖拒绝、错误响应、超时、重试、开关变化、跨会话隔离和诊断文本转义。

最终构建产物在独立本地 Edge 测试页验证三种工厂内容：孤立反引号、行内波浪号及 HTML 围栏后的卡片均出现，按钮可点击、整页重载仍正常，三个 iframe 均仅为 `sandbox="allow-scripts"`，读取父窗口继续被拒绝。此页使用真实隔离 worker、展示拆分与卡面 srcDoc；诊断外壳为测试页面，实际插件组件由 React 测试覆盖。本次未启动新宿主、调用模型或修改真实剧情，也未取得截图中角色的原始回复和展示规则，不能据此确认其唯一根因。测试页和服务器已关闭。

最终全量 149 个测试文件通过，2117 项通过、Windows 跳过 1 项 POSIX 用例；构建、`npm pack --dry-run --ignore-scripts`（此前已完成构建）与 431 文件发布白名单检查通过。本轮未更改依赖。

### 2026-09-27：rc.2 当前会话与导航接口移除

0.1.7-rc.2 的 `SessionListState` 只剩 `ids/byId/phase/projectionsBySession`，视图选择留在 UiSession 私有状态；`ISessions` 也不再有 `open`。插件此前自写的列表类型仍声明 `current`，编译无法发现，运行时 `list.getSnapshot().current` 恒为 undefined。后果是 assistant-step 从未注册：Tavern 消息全部走宿主原生 AssistantNodeView，纯文本开场白看不出问题，但 HTML 卡面显示为代码块；实时脚本事件、选项输入与开场白/分支导航同样失效，seatWatch 也会把已有会话误判为无会话。

修复后不再读取宿主当前选择：会话头部 chip 与新会话英雄区只随被显示的会话挂载，挂载期间在 `sessionViews` 登记（会话 id 与是否 Tavern），assistant-step、实时事件、选项输入、分支导航防抢焦点与 seatWatch 都读这份登记。宿主 keyed 覆盖位没有按会话筛选或渲染被遮挡原生节点的公开接口，所以仍按「有 Tavern 视图显示时接管」处理。导航改走 `uiWorkspace.openSession`，旧宿主回退 `sessions.open`，两者都缺时明确报错。

验收：使用独立临时 DSH_HOME（本机剧情数据副本，无模型凭据）与 profile/node_modules 到 checkout 的 junction 启动 `dsh web`，headless Chrome 经 CDP 打开受影响会话。修复前开场白为原生代码块、无 `.dsh-tavern-speech`；修复后显示角色气泡与 489px 高的卡面 iframe，无代码块。点击「下一条开场白」后生成「开场白 2/3」子会话并自动切换，文本开场白进入 Tavern 气泡。临时服务、浏览器与数据副本均已删除。升级宿主时须核对 `SessionListState`、`ISessions` 与 `UiWorkspace` 的实际类型，插件内的最小类型不能代替核对。

同日按 0.1.5-rc.2（本机全局安装）与 0.1.7-rc.2 的类型声明逐包比对被删成员，并核对插件经字符串、DOM 或 `unknown` 读取的宿主数据，另外发现：

- 预设 seat chip 的 title 改为「选择新任务使用的 Agent 预设 / Choose the agent preset for your new task」，seatWatch 只认旧文案会让无会话 hero 的补偿静默失效；现同时认新旧文案，并以 CSS module 的 `<hash>_seat` 类名兜底。
- conversation.chat.node 新增 `groupPart`：同时含思考与正文的 assistant 步骤会渲染两次，reasoning 段在「用时」折叠区内，折叠时隐藏但仍挂载。插件节点忽略它会在折叠区里再挂一整份角色气泡、卡面沙箱与脚本。现 reasoning 段只画思考，response 段画气泡且不重复思考，原生回退按宿主 AssistantMarkdown 同样过滤。
- 上下文用量读取 token-meter 的 `contextBreakdown` 时按扁平对象取值，实际状态为 `{ nodes, breakdown }`（0.1.5 已如此，非本次升级引入），面板构成三项恒为空；已改为读取 `breakdown`。

已核对无变化：插件使用的五个 slot 名与作用域、`SessionSnapshot.blank/promptAttempted`、assistant 块种类与 `finalNode.seq`、`turn-tail` 数据、locale `register/getSnapshot().active`、订阅的 12 个宿主事件、`agentPreset` 投影、WorkspaceRegistry `list/attachSession`、`data-composer-seat`，以及运行时上下文快照按字节去重（稳定前缀依赖此行为）。

### 2026-09-28：MVU zod 模板与原生 MVU 默认开启

用户反馈「MVU 在 0.1.7-rc.2 不能用」。独立 DSH_HOME + headless Chrome（CDP 采集沙箱 console）复现：卡片 `[MVU]…_zod` 脚本 `import { registerMvuSchema } from '…/StageDog/tavern_resource/dist/util/mvu_zod.js'` 被沙箱 CSP（`script-src 'unsafe-inline' 'unsafe-eval'`）拦截，脚本永不就绪，原生 MVU 的 `allReady` 为假，初始化任务一直 pending；另外现有绑定未开启 `helperMvu`，原生 MVU 根本不运行。两点均非本次宿主升级引入，但 MVU zod 是常见模板。

- 原文件许可证为 NOASSERTION，不随包分发；在沙箱 `installCardMvu` 内按其可观察行为本地实现 `registerMvuSchema`（开局按 schema 补全、命令逐条套用并校验、`_` 路径只读、清空命令后写入 `没有用别管这个` 标记），并只把该 URL 的顶层具名导入改写为 `window.__dshTavernMvuZod`。其它远程导入仍按 CSP 失败并显示。
- 首次绑定（或换卡）且客户端未表态时，若卡片启用的脚本包含官方 MVU 框架入口，服务端自动开启原生 MVU；显式关闭始终尊重，已有绑定不被改写。

验收：同一会话副本开启原生 MVU 后，初始化任务完成（`initialized: true`，stat_data 由卡片 `[Initvar]` 与 schema 默认值组成），无 CSP 错误与页面异常。命令更新路径以打包进 vm 同一 realm 的真实 zod 做单元验证（非法值忽略、add 只套用一次、只读路径、标记）。未调用真实模型；临时服务、浏览器与数据副本已删除。

### 2026-09-28：聊天卡面、变量与 MVU 故障回归

使用独立临时 DSH_HOME、Windows / Node 24.18.0 / dsh 0.1.7-rc.2 和本次构建，浏览器创建合成角色并编辑 HTML 开场白。确认选择页只展示互动卡面提示，进入聊天后才运行 opaque-origin iframe；卡内异步 updater 在调用方改动 option 后仍只更新原表，chat.hp=11、character.hp=99，经真实剧情保存并整页刷新后仍保留；MVU JSON Patch 修改 `_secret` 被只读规则阻止。Tavern 设置及「卡片与数据」能选择实际剧情并载入已保存快照，页面无错误日志。测试页与临时宿主已关闭，未调用真实模型或使用用户剧情。

新增 9 项回归并扩充既有 MVU 测试，覆盖角色详情刷新、变量旧运行时、备份特殊字符、MVU 通信超时/重复结果/迟到续租、失效租约重新准备及开场白只读预览。170 个测试文件、2411 项测试通过，1 项平台用例跳过；npm ci、build、pack dry-run（449 个文件）、发布白名单及 doctor/backup CLI 检查通过，lib 已重建。这些检查不代表任意第三方卡或真实模型生成效果均已验收。

### 2026-09-28：合成数据端到端冒烟（假 DeepSeek 端点）

独立 DSH_HOME 只含脚本生成的合成角色卡，profile 补丁把 `llm-deepseek` 的 baseURL 指向本机假 Messages 端点（记录请求体、返回脚本化 SSE，含 `<UpdateVariable>` 命令与缓存用量），headless Chrome 经 CDP 驱动。覆盖：无会话 hero 选 Tavern 模式与选卡开局、HTML 开场白卡面、设置面板全部页签与 390px 窄屏、提示词预览/触发日志/记忆/会话世界书对话框、真实发信、原生 MVU 自动开启与 zod 更新（非法值被 schema 拒绝）、重新生成与回退分支的 MVU 回滚、续写、跨轮请求前缀逐字节延续。

新发现并修复：

- 0.1.7 把唤醒本轮的非 user 消息画成可展开的「收到执行请求」行，续写的合成指令原文会显示在剧情里。Tavern 视图显示期间接管 `turn-trigger`：插件指令只显示「↪ 接着上一条回复续写」等简短说明，其它来源保留可展开原文。
- 布局载体的 standing 改用同一步组装实际写入 system 的钉位文本（宿主在同一步先 assemble、后 pre-step）。此前按当轮重算结果建计划；钉位复用旧字节时（如运行期手改文件未触发修订号），投影会失败或把残余文本带进 system，且「开启下一轮」无法恢复。

### 2026-09-29：停止回复的操作栏与思考折叠

在 dsh 0.1.7-rc.2 独立 bundle 安装环境中，浏览器手动停止含文本的 SSE 回复后，同层出现两组 Tavern 重新生成/回退按钮。核对已安装 `@deepseek-ai/dsh-client-ui-chat` 的 `TurnTailNodeView`：宿主在 `closing.finalNode.messageId !== undefined` 时挂载 assistant-actions，中断回复也可能已经持久化；“只有 finalized 消息”并不等于“中断回复没有操作栏”。插件现按相同 seq 与持久 messageId 判断，保留未形成对应 turn-tail 消息时按 turn 补挂的回退路径。

`groupPart='reasoning'` 已在宿主的用时/分析折叠区内，插件不再叠加第三层“思考过程”；该分段只渲染带宿主 labels 的 Markdown，不挂载角色卡 iframe。测试覆盖有/无持久消息 ID、其它 seq 的 turn-tail 以及既有图片、附件与非 Tavern 回退。手动生成、停止与重新打开历史后均复核按钮和思考层级，具体变量与分支结果见[同日手动回归记录](MANUAL_AUDIT_2026-09-29.md)。

### 2026-09-29：跨消息续写的 MVU 与流式展示

宿主续写创建新消息，不能仅解析新消息尾段。正常 stop 提交时，插件依据真实 Tavern notice、前文的内嵌 finish 与 turn/end，冻结尚未处理的截断/停止来源；合并计算只写新楼层。停用期间或明确放弃的完整回复不追补。沙箱只接受同一消息快照中的有序 assistant 下标，并在刷新后核对整份快照。

生成中使用公开 `SessionBinding.eventSource` 的 `SessionEventWindow.entries`，只读取持久 event，忽略 transient chunk；按 `TurnLocation.turn` 和最终 `seq` 延续前文展示边界。该订阅只用于流式展示，完成后仍走只读服务投影。真实页面验证“截断 → 续写 → 停止 → 再续写”、正常回复后的增量续写、刷新、回退和回退后再续写；来源剧情保持不变。

同样的宿主消息边界会截断 HTML 页面与按钮脚本。只读展示现沿真实续写 notice 带上尚未完成的 HTML 单元，旧消息保留待续写提示，新卡绑定续写气泡的 seq；原始消息上下文不伪造为合并历史。已有模板只读匹配 hash 的提交文本，未提交前文不在刷新时重新执行。真实页面复测脚本中途截断、按钮点击、继续发信时保留旧卡草稿，以及回退分支重新补全；变量与来源剧情文件均按楼层隔离。

进一步复现标签名中途截断残留 `ml>`，以及普通 JavaScript 示例的 HTML 尾段在新消息中被误当成卡片运行。续写投影现在保留 Markdown 代码语境，按组合文本确认跨消息标签/围栏，代码后的真实卡面仍可交互；完整旧卡的补写闭标签不重复启动沙箱。重启后的真实页面验证代码示例不产生 iframe、真实卡片仍可点击，helper 文件哈希保持不变。机读清理也区分同一卡面的连续消息和独立展示片段，避免误删跨消息脚本里的标签字符串。

### 2026-09-29：v0.4.6 发布前 MVU 命令边界

独立宿主中的正常回复同时含行内 `+100` 示例和真实 `+1` 更新时，旧版将 hp 从 18 写成 119；卡内脚本仅含 `_.set(local, 'hp', 999);` 字符串时也会解析失败并保留 pending。新构建重启后，该 pending 正常恢复且只增加 1。页面回退到第 18 层建立新剧情后，同样两次回复依次得到 19、20，卡内按钮仍可显示样例字符串；来源剧情文件保持不变。

解析仍在不透明 iframe 内执行；Markdown 扫描器和 JSON 复制器显式注入，不依赖宿主闭包或求值第三方代码。明确更新块兼容围栏/行内格式包装，普通示例、HTML 属性、脚本和惰性容器不参与剧情更新。172 个文件、2519 项测试通过，1 项 POSIX 用例跳过；npm ci、build、pack dry-run、459 文件白名单及 doctor/backup 检查通过。
