/** worker 的纯计算入口；不读取工作区，不接触宿主、会话或网络。 */
import { parentPort, workerData } from 'node:worker_threads'
import { assemblePrompt } from '../core/assemble.js'
import { evaluateWorldInfo } from '../core/worldbook.js'
import { applyRegexRules } from '../core/regex.js'
import { createTurnRandom } from '../core/macros.js'
import { estimateTokens } from '../core/tokenize.js'
import type { MacroContext, WorldInfoEntry } from '../core/types.js'
import type { TemplateContext, TemplateScopes, TemplateRegexDescriptor } from '../core/template.js'
import { normalizeTemplateLore } from '../core/templateLore.js'
import { assembleTemplatePlan } from './templatePlan.js'
import { parseTemplatePlacement } from '../core/templatePlacement.js'
import type { TemplateReplay } from '../core/templateReplay.js'
import type { TemplateMessageVariables } from '../core/templateMessageVariables.js'
import type { TemplateDisplayPart } from '../core/templateDisplay.js'
import { renderTemplateDisplay, presentTemplateDisplayResult } from './templateDisplay.js'
import type { TemplateContinuation } from '../core/templateContinuation.js'
import { prepareContinuedTemplate,exportTemplateContinuation } from './templateContinuation.js'
import { parseTemplateContinuation,templatePreloadRevision } from '../state/templateContinuation.js'
import { measureTemplateReplayWork, templateReplayGenerationContext } from '../core/templateReplay.js'
import { measureTemplateJson, templateExecutionBudget, type TemplateExecutionBudget } from '../core/templateBudget.js'
import { TemplateWorkerCache, templateWorkerCacheKey } from './templateWorkerCache.js'

type SerializableMacros = Omit<MacroContext, 'random' | 'onUnknown'>
export interface ComputeJobs {
  assemble: {
    input: Omit<Parameters<typeof assemblePrompt>[0], 'estimateTokens' | 'macroCtx' | 'renderTemplate' | 'transformPrompt'> & { macroCtx: SerializableMacros; seed: number; templates?: TemplateContext; templateContinuation?:TemplateContinuation; wiEvaluation?: ComputeJobs['wi']['input'] }
    output: ReturnType<typeof assemblePrompt> & { templateVariables?: TemplateScopes; templateMessageVariables?:TemplateMessageVariables; templateRegexRules?: TemplateRegexDescriptor[]; templateHasMessageRegex?: boolean; templateReplay?:TemplateReplay; templateContinuation?:TemplateContinuation; evaluatedWi?: ReturnType<typeof evaluateWorldInfo>; deltaDropped?: number }
  }
  wi: {
    input: Omit<Parameters<typeof evaluateWorldInfo>[0], 'estimateTokens' | 'random'> & { seed: number; templates?: TemplateContext }
    output: ReturnType<typeof evaluateWorldInfo>
  }
  render: {
    input: { text: string; rules: Parameters<typeof applyRegexRules>[1]; macroCtx: SerializableMacros }
    output: ReturnType<typeof applyRegexRules>
  }
  template: {
    input: { texts: string[]; context: TemplateContext; decorateOutput?: boolean; replay?:TemplateReplay; templateContinuation?:TemplateContinuation }
    output: { texts: string[]; parts:TemplateDisplayPart[][]; variables: TemplateScopes; messageVariables:TemplateMessageVariables; templateContinuation?:TemplateContinuation }
  }
  display: {
    input: {parts:TemplateDisplayPart[];rules:Parameters<typeof applyRegexRules>[1];macroCtx:SerializableMacros}
    output: ReturnType<typeof presentTemplateDisplayResult>
  }
  renderBatch: {
    input: {
      rules: Parameters<typeof applyRegexRules>[1]
      macroCtx: SerializableMacros
      items: Array<
        | { kind: 'render'; text: string }
        | { kind: 'display'; parts: TemplateDisplayPart[] }
      >
    }
    output: Array<
      | { ok: true; kind: 'render'; value: ReturnType<typeof applyRegexRules> }
      | { ok: true; kind: 'display'; value: ReturnType<typeof presentTemplateDisplayResult> }
      | { ok: false; error: string }
    >
  }
}

/** 只检查会成为正文的字段，避免为检测标记把包含重复长历史的整个任务编码两遍。 */
function hasTemplateText(value: unknown): boolean {
  if (typeof value === 'string') return value.includes('<%') || value.includes('{{outletPromptsInjected:')
  if (!value || typeof value !== 'object') return false
  if (Array.isArray(value)) return value.some(hasTemplateText)
  return Object.values(value).some(hasTemplateText)
}

const sandboxCache = new TemplateWorkerCache()
async function compute(request: typeof workerData):Promise<void> {
  let cacheKey:string|undefined,cacheHit=false
  const send=(message:Record<string,unknown>)=>parentPort!.postMessage({id:request.id,...message})
  try {
    const { kind, input } = request
    const budget: TemplateExecutionBudget = request.budget ?? templateExecutionBudget(Math.max(measureTemplateJson(input),
      input.replay ? measureTemplateReplayWork(input.replay) : 0,
      input.templateContinuation?.replay ? measureTemplateReplayWork(input.templateContinuation.replay) : 0), undefined,
      kind === 'render' || kind === 'display' || kind === 'renderBatch' ? 'display' : 'template')
    const needsTemplates = kind === 'template' || kind === 'wi' && input.templates && input.entries.some((raw: WorldInfoEntry) => {
        const entry = normalizeTemplateLore(raw)
        return entry.enabled && Boolean(entry.templateCondition)
      })
      || kind === 'assemble' && input.templates
      && (input.templateContinuation || input.templates.historyIdentities?.length || input.templates.regexRules?.length
        || [input.card, input.preset, input.personaDescription, input.history, input.wi, input.wiEvaluation?.entries,
          input.memories, input.worldDeltas, input.authorNote, input.journalText,
          input.regexRules, input.macroCtx, input.templates.variables,
          input.templates.messageVariables, input.templates.entries, input.templates.presets].some(hasTemplateText)
        || [...input.templates.entries, ...(input.wiEvaluation?.entries ?? [])].some((raw:WorldInfoEntry) => {
        const entry=normalizeTemplateLore(raw)
        // 预处理必须计入：仅靠 @@preprocessing（正文装饰器）或 [Preprocessing]（注释标记）触发的条目
        // 可能完全没有 EJS，漏判会让预处理静默不执行（键与正文不展开），而不是明确失败。
        return entry.enabled && (entry.templatePreload || entry.templatePreprocessing || /^\[Preprocessing\]/i.test(entry.comment)
          || entry.templateCondition || parseTemplatePlacement(entry.comment)
          || /^\[(InitialVariables|RENDER:BEFORE|RENDER:AFTER)\]/i.test(entry.comment)
          || /^\[(?:GENERATE|RENDER|PRELOAD)\b/i.test(entry.comment) || /^\s*@INJECT\b/.test(entry.content) || /^@INJECT\b/i.test(entry.comment))
      }))
    const templateClass = needsTemplates ? (await import('./templateSandbox.js')).TemplateSandbox : null
    // 输入解析、预加载与重放都计入计算预算；只有受信依赖和沙箱初始化走装载预算。
    await templateClass?.prepare(phase => send({ [phase]: true }))
    const beginComputing = () => send({ computing: true })
    beginComputing()
    const incomingReplay=kind==='assemble' ? input.templateContinuation?.replay : kind==='template' ? input.replay : undefined
    const incomingContext=kind==='assemble' ? input.templates : input.context
    const incomingKey='incomingKey' in request ? (request.incomingKey as string | undefined) : templateWorkerCacheKey(incomingReplay,incomingContext)
    if(!needsTemplates||kind==='render'||kind==='display'||kind==='renderBatch')cacheKey=sandboxCache.key
    else if(!incomingKey)sandboxCache.clear()
    const restoreCached=()=> {
      const cached=sandboxCache.take(incomingKey,incomingReplay,budget.inputChars)
      cacheHit=Boolean(cached)
      return cached
    }
    let value: unknown
    if (kind === 'assemble') {
      const sandbox = templateClass ? await prepareContinuedTemplate(templateClass,input.templates,input.templateContinuation,restoreCached) : null
      beginComputing()
      let retained=false
      try {
        const assembled=assembleTemplatePlan(input,sandbox)
        sandbox?.sticky('finish')
        // replay() 必须是最后一次查询；它也记录变量导出，缓存 VM 必须与回传日志精确对齐。
        const result={...assembled,...(sandbox ? {templateMessageVariables:sandbox.messageVariables(),
          templateContinuation:exportTemplateContinuation(sandbox,input.templates),templateRegexRules:sandbox.regexDescriptors(),templateHasMessageRegex:sandbox.hasMessageRegex(),templateReplay:sandbox.replay()} : {})}
        value=result
        if(sandbox && result.templateReplay) {cacheKey=sandboxCache.keep(sandbox,result.templateReplay,input.templates);retained=true}
      } finally { if(!retained)sandbox?.dispose() }
    }
    else if (kind === 'template') {
      const continuation=input.templateContinuation && parseTemplateContinuation(input.templateContinuation)
      if(continuation && (!input.replay || continuation.preloadRevision!==templatePreloadRevision(templateReplayGenerationContext(input.replay))
        || continuation.replay && JSON.stringify(continuation.replay)!==JSON.stringify(input.replay))) throw new Error('回复 sticky 状态与生成日志不一致')
      const sandbox = input.replay ? restoreCached() ?? await templateClass!.rebuild(input.replay) : await templateClass!.create(input.context)
      beginComputing()
      let retained=false
      try {
        if(input.replay)sandbox.resume(input.context)
        if(continuation && JSON.stringify(continuation.state)!==JSON.stringify(sandbox.stickyState())) throw new Error('回复 sticky 注册表与已提交状态不一致')
        const entries = (input.context as TemplateContext).entries.map(normalizeTemplateLore)
        const rendered=input.texts.map((text: string,index:number) => {
          const meta=sandbox.setMessageContext(input.context.renderMessages?.[index] ?? null)
          if(input.context.phase==='render') return renderTemplateDisplay(text,entries,sandbox,meta,Boolean(input.decorateOutput))
          const rendered=sandbox.resolveOutlets(sandbox.render(text))
          return {text:rendered,parts:[{kind:'markdown' as const,text:rendered}]}
        })
        const result = { texts:rendered.map((result:{text:string})=>result.text),parts:rendered.map((result:{parts:TemplateDisplayPart[]})=>result.parts),variables:sandbox.variables(),messageVariables:sandbox.messageVariables(),
          ...(input.templateContinuation ? {templateContinuation:{...exportTemplateContinuation(sandbox,input.context,true),preloadRevision:input.templateContinuation.preloadRevision}} : {}) }
        value=result
        if(result.templateContinuation?.replay) {cacheKey=sandboxCache.keep(sandbox,result.templateContinuation.replay,input.context);retained=true}
      }
      finally { if(!retained)sandbox.dispose() }
    }
    else if (kind === 'wi') {
      const sandbox = templateClass ? await templateClass.create(input.templates) : null
      beginComputing()
      try {
        const entries = (input.templates ? input.entries.map(normalizeTemplateLore) : input.entries).map((entry: import('../core/types.js').WorldInfoEntry) => {
          if (!entry.enabled || !entry.templateCondition) return entry
          if (!sandbox!.condition(entry.templateCondition)) return { ...entry, enabled:false }
          return { ...entry, content:`<% /* conditional lore */ %>${entry.content}` }
        })
        value = evaluateWorldInfo({ ...input, entries, estimateTokens, random: createTurnRandom(input.seed) })
      } finally { sandbox?.dispose() }
    }
    else if (kind === 'render') { beginComputing(); value = applyRegexRules(input.text, input.rules, { scope: 'output', timing: 'render' }, input.macroCtx) }
    else if (kind === 'display') { beginComputing(); value = presentTemplateDisplayResult(input.parts,input.rules,input.macroCtx) }
    else if (kind === 'renderBatch') {
      beginComputing()
      value = input.items.map((item: ComputeJobs['renderBatch']['input']['items'][number]) => {
        try {
          if (item.kind === 'render') {
            return { ok: true as const, kind: 'render' as const, value: applyRegexRules(item.text, input.rules, { scope: 'output', timing: 'render' }, input.macroCtx) }
          }
          return { ok: true as const, kind: 'display' as const, value: presentTemplateDisplayResult(item.parts, input.rules, input.macroCtx) }
        } catch (error) {
          const message = error instanceof Error ? (error.message || error.name || '展示正则计算失败') : (String(error) || '展示正则计算失败')
          return { ok: false as const, error: message }
        }
      })
    }
    else throw new Error('未知提示词任务')
    measureTemplateJson(value, budget.outputChars)
    send({ value, cacheKey, cacheHit })
  } catch (error) {
    sandboxCache.clear()
    // 空消息错误不能被 host 当成成功：这里保证 error 字段始终是非空失败原因。
    const message=error instanceof Error ? (error.message || error.name || '模板计算失败') : (String(error) || '模板计算失败')
    send({ error: message })
  }
}

if(parentPort)parentPort.on('message',request=>{void compute(request)})
