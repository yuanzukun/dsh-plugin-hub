/**
 * 会话绑定：Tavern 会话 ↔ 角色卡/预设/人设/世界书选择。
 * 存 `sessions/<sessionId>.json`（host 数据目录；不随楼层回滚——绑定不是剧情状态）。
 * SessionBinding / WalLineageEntry 是纯数据形状，定义在 core/binding（remote 契约引用），此处 re-export。
 * 读写共用 parseSessionBinding 严格校验（RPC 宽松传输、存储层严格校验的落点），不再 as 断言。
 */
import { constants, type Dirent, type Stats } from 'node:fs'
import { lstat, open, readdir, readFile, unlink } from 'node:fs/promises'
import { join } from 'node:path'
import { sessionFile, type TavernPaths } from './paths.js'
import { assertValidCardId } from '../state/workspace.js'
import type { SessionBinding, WalLineageEntry } from '../core/binding.js'
import {helperWorldbookSettingsCodec} from '../core/helperWorldbookSettings.js'
import { atomicWrite } from '../state/atomicWrite.js'
import { legacyStoryId, storyRoot } from '../state/story.js'
import { withWorkspaceLock } from '../state/workspaceLock.js'

export type { SessionBinding, WalLineageEntry } from '../core/binding.js'

/** 绑定只是小型元数据；超限文件一律按损坏引用阻断永久删除。 */
const MAX_SESSION_BINDING_BYTES = 1024 * 1024
const BINDING_READ_CHUNK_BYTES = 64 * 1024

function invalidBinding(field: string, expect: string): never {
  throw new Error(`会话绑定字段 ${field} 非法：期望${expect}`)
}

/**
 * 会话绑定的严格解析：必填字段缺失或类型错误即抛错，未知字段丢弃（对齐 RPC schema 的 strip 行为）。
 * service.setSessionBinding 与本文件的 load/save 共用这一个校验点；
 * interactiveCards（会话级交互卡开关，boolean | null）原样透传——客户端依它做渲染决策。
 */
export function parseSessionBinding(input: unknown): SessionBinding {
  if (typeof input !== 'object' || input === null || Array.isArray(input)) invalidBinding('(root)', '对象')
  const raw = input as Record<string, unknown>

  const requiredString = (field: string): string => {
    const value = raw[field]
    if (typeof value !== 'string' || value.length === 0) invalidBinding(field, '非空字符串')
    return value
  }
  const nullableString = (field: string): string | null => {
    const value = raw[field]
    if (value === null) return null
    if (typeof value !== 'string') invalidBinding(field, '字符串或 null')
    return value
  }
  const optionalString = (field: string): string | undefined => {
    const value = raw[field]
    if (value === undefined) return undefined
    if (typeof value !== 'string') invalidBinding(field, '字符串')
    return value
  }
  const optionalBoolean = (field: string): boolean | undefined => {
    const value = raw[field]
    if (value === undefined) return undefined
    if (typeof value !== 'boolean') invalidBinding(field, '布尔值')
    return value
  }

  const sessionId = requiredString('sessionId')
  const cardId = requiredString('cardId')
  // cardId 是 characters/ 下的单层目录名；格式不对直接拒绝（防路径越界，与工作区入口同一帮手）。
  assertValidCardId(cardId)
  const storyId = optionalString('storyId')
  if (storyId !== undefined) storyRoot('.', storyId)

  const lorebookIdsRaw = raw['lorebookIds']
  if (!Array.isArray(lorebookIdsRaw)) invalidBinding('lorebookIds', '字符串数组')
  const lorebookIds = lorebookIdsRaw.map((id, i) => {
    if (typeof id !== 'string') invalidBinding(`lorebookIds[${i}]`, '字符串')
    return id
  })

  const interactiveCardsRaw = raw['interactiveCards']
  let interactiveCards: boolean | null
  if (interactiveCardsRaw === null) interactiveCards = null
  else if (typeof interactiveCardsRaw === 'boolean') interactiveCards = interactiveCardsRaw
  else invalidBinding('interactiveCards', '布尔值或 null')

  const greetingIndex = raw['greetingIndex']
  if (typeof greetingIndex !== 'number' || !Number.isSafeInteger(greetingIndex) || greetingIndex < 0) {
    invalidBinding('greetingIndex', '非负整数')
  }

  const walLineageRaw = raw['walLineage']
  let walLineage: WalLineageEntry[] | undefined
  if (walLineageRaw !== undefined) {
    if (!Array.isArray(walLineageRaw)) invalidBinding('walLineage', '数组')
    walLineage = walLineageRaw.map((entry, i) => {
      if (typeof entry !== 'object' || entry === null || Array.isArray(entry)) invalidBinding(`walLineage[${i}]`, '对象')
      const item = entry as Record<string, unknown>
      const entrySessionId = item['sessionId']
      if (typeof entrySessionId !== 'string' || entrySessionId.length === 0) {
        invalidBinding(`walLineage[${i}].sessionId`, '非空字符串')
      }
      const throughTurn = item['throughTurn']
      if (typeof throughTurn !== 'number' || !Number.isSafeInteger(throughTurn) || throughTurn < 0) {
        invalidBinding(`walLineage[${i}].throughTurn`, '非负整数')
      }
      return { sessionId: entrySessionId, throughTurn }
    })
  }

  return {
    sessionId,
    cardId,
    storyId,
    cardName: optionalString('cardName'),
    presetId: nullableString('presetId'),
    personaId: nullableString('personaId'),
    lorebookIds,
    characterLorebookId: nullableString('characterLorebookId'),
    useEmbeddedLorebook: optionalBoolean('useEmbeddedLorebook'),
    characterLorebookIds: raw.characterLorebookIds===undefined?undefined:(()=>{
      if(!Array.isArray(raw.characterLorebookIds)||raw.characterLorebookIds.length>64||raw.characterLorebookIds.some(id=>typeof id!=='string'||!id))invalidBinding('characterLorebookIds','至多 64 项的非空字符串数组')
      return [...new Set(raw.characterLorebookIds as string[])]
    })(),
    worldInfo:raw.worldInfo===undefined?undefined:helperWorldbookSettingsCodec.nativePatch(raw.worldInfo),
    interactiveCards,
    helperMvu:optionalBoolean('helperMvu'),
    greetingIndex,
    authorNote: optionalString('authorNote'),
    injectJournal: optionalBoolean('injectJournal'),
    walLineage,
    createdAt: requiredString('createdAt'),
  }
}

export async function loadBinding(paths: TavernPaths, sessionId: string, strictRead = false): Promise<SessionBinding | null> {
  let content: string
  try { content = await readFile(sessionFile(paths, sessionId), 'utf8') }
  catch (error) {
    // 面板读取继续容错；保存判断必须区分缺文件与暂时 I/O 失败，不能把不确定身份当作首次绑定。
    if (strictRead && (error as NodeJS.ErrnoException).code !== 'ENOENT') throw error
    return null
  }
  try {
    const parsed = parseSessionBinding(JSON.parse(content))
    if (parsed.sessionId !== sessionId) return null
    return parsed
  } catch {
    // JSON 损坏或字段校验失败都视为未绑定（面板可重选）。
    return null
  }
}

export async function saveBinding(paths: TavernPaths, binding: SessionBinding): Promise<void> {
  // 写入侧严格校验（sessionId 非空、cardId 目录名格式在 parse 内检查）：坏数据不落盘，
  // 否则合法 JSON 但字段缺失的绑定要到使用点才抛错。
  const checked = parseSessionBinding(binding)
  await withWorkspaceLock(paths.sessions, async () => {
    await assertBindingFileIdentity(paths, checked.sessionId)
    const file = sessionFile(paths, checked.sessionId)
    const content = JSON.stringify(checked, null, 2) + '\n'
    try { await atomicWrite(file, content) }
    catch (error) {
      // rename 完成后仍可能报错；精确读回确认已提交，避免调用方把成功换绑当失败清理。
      if (await readFile(file, 'utf8').catch(() => null) !== content) throw error
    }
  })
}

/** 进程内绑定删除代数：依赖“绑定仍存在”的缓存据此整体失效（同一 DSH_HOME 只允许一个宿主进程写）。 */
let bindingDeletions = 0
export function bindingDeletionGeneration(): number {
  return bindingDeletions
}

export async function deleteBinding(paths: TavernPaths, sessionId: string): Promise<void> {
  await withWorkspaceLock(paths.sessions, async () => {
    await assertBindingFileIdentity(paths, sessionId)
    try { await unlink(sessionFile(paths, sessionId)) }
    catch (error) { if ((error as NodeJS.ErrnoException).code !== 'ENOENT') throw error }
    finally { bindingDeletions++ }
  })
}

/**
 * 净化后的文件名与 Windows 大小写别名可能碰撞；不能把另一会话的绑定当未绑定后覆盖/删除。
 * 残缺绑定仍按原有面板重选语义允许修复，但已记录的原始 sessionId 必须严格一致。
 * 调用方准备剧情时持有 sessions 锁，本函数也可独立安全调用。
 */
export async function assertBindingFileIdentity(paths: TavernPaths, sessionId: string): Promise<void> {
  await withWorkspaceLock(paths.sessions, async () => {
    const raw = await readFile(sessionFile(paths, sessionId), 'utf8').catch((error: NodeJS.ErrnoException) => {
      if (error.code === 'ENOENT') return null
      throw error
    })
    if (raw === null) return
    let value: unknown
    try { value = JSON.parse(raw) } catch { return }
    if (value && typeof value === 'object' && !Array.isArray(value)) {
      const owner = (value as Record<string, unknown>).sessionId
      if (typeof owner === 'string' && owner && owner !== sessionId) throw new Error('会话绑定文件身份冲突：文件属于另一会话')
    }
  })
}

/**
 * 扫描持久化会话中对角色的引用。永久删除必须 fail-closed：任意 `.json` 无法解析、
 * 不符合绑定 schema 或文件身份与 sessionId 不一致，都记为无法安全归属的损坏绑定。
 * 若部分损坏对象仍明确携带目标 cardId，同时记入 sessionIds，供 host 诊断；
 * 对外 RemoteError details 只传计数，不传这些文件名或会话身份。
 */
export interface BindingReferenceScan {
  sessionIds: string[]
  /** 合法绑定实际使用的剧情；旧绑定未记录 storyId 时按首次读取会迁移出的 legacy 剧情计。 */
  storyIds: string[]
  corruptFiles: string[]
}

/** 对比路径枚举、已打开句柄与读取前最终路径，拒绝中途被换成链接或另一文件。 */
function sameRegularFile(left: Stats, right: Stats): boolean {
  return left.isFile() && !left.isSymbolicLink() && right.isFile() && !right.isSymbolicLink()
    && left.dev === right.dev && left.ino === right.ino
    && left.size === right.size && left.mtimeMs === right.mtimeMs && left.birthtimeMs === right.birthtimeMs
}

/** 从已验证的普通文件句柄分块读取，多读 1 字节仅用于识别扫描期间增长。 */
async function readBoundedBinding(
  handle: Awaited<ReturnType<typeof open>>,
): Promise<{ ok: true; text: string } | { ok: false }> {
  const chunks: Buffer[] = []
  let position = 0
  while (position <= MAX_SESSION_BINDING_BYTES) {
    const length = Math.min(BINDING_READ_CHUNK_BYTES, MAX_SESSION_BINDING_BYTES + 1 - position)
    const chunk = Buffer.allocUnsafe(length)
    const { bytesRead } = await handle.read(chunk, 0, length, position)
    if (bytesRead === 0) return { ok: true, text: Buffer.concat(chunks, position).toString('utf8') }
    position += bytesRead
    chunks.push(chunk.subarray(0, bytesRead))
    if (position > MAX_SESSION_BINDING_BYTES) return { ok: false }
  }
  return { ok: false }
}

export async function listBindingReferencesForCard(paths: TavernPaths, cardId: string): Promise<BindingReferenceScan> {
  assertValidCardId(cardId)
  // Windows 的角色目录同样大小写不敏感；旧绑定可以保留调用方传入的大小写，
  // 尚未迁移成 story 时只能靠此处的绑定引用阻止误删。
  const isTargetCard = (value: unknown): boolean => typeof value === 'string'
    && (process.platform === 'win32' ? value.toLowerCase() === cardId.toLowerCase() : value === cardId)
  let entries: Dirent[]
  try {
    entries = await readdir(paths.sessions, { withFileTypes: true })
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return { sessionIds: [], storyIds: [], corruptFiles: [] }
    throw error
  }
  const references: string[] = []
  const storyIds: string[] = []
  const corruptFiles: string[] = []
  for (const entry of entries.sort((a, b) => a.name.localeCompare(b.name))) {
    const file = entry.name
    // Windows 文件名大小写不敏感：`s1.JSON` 仍可被 `s1.json` 路径读到，
    // 引用扫描必须使用同样的保守口径，否则会漏过有效绑定。
    if (!/\.json$/i.test(file)) continue
    // 第一步就拒绝 symlink/junction/目录，绝不读它们指向的外部内容。
    if (!entry.isFile() || entry.isSymbolicLink()) {
      corruptFiles.push(file)
      continue
    }
    const absolute = join(paths.sessions, file)
    let text: string
    let handle: Awaited<ReturnType<typeof open>> | undefined
    try {
      const before = await lstat(absolute)
      if (!before.isFile() || before.isSymbolicLink()) {
        corruptFiles.push(file)
        continue
      }
      // POSIX 用 O_NOFOLLOW 从 open 本身拒绝最终链接；Windows 未公开该 flag，依靠
      // lstat → open/fstat → lstat 的三方文件身份比对，且身份确认前不读任何字节。
      const noFollow = typeof constants.O_NOFOLLOW === 'number' ? constants.O_NOFOLLOW : 0
      handle = await open(absolute, constants.O_RDONLY | noFollow)
      const opened = await handle.stat()
      const after = await lstat(absolute)
      if (!sameRegularFile(before, opened) || !sameRegularFile(opened, after)
        || opened.size > MAX_SESSION_BINDING_BYTES) {
        corruptFiles.push(file)
        continue
      }
      const bounded = await readBoundedBinding(handle)
      const finalOpened = await handle.stat()
      const finalPath = await lstat(absolute)
      if (!bounded.ok || !sameRegularFile(opened, finalOpened) || !sameRegularFile(finalOpened, finalPath)) {
        corruptFiles.push(file)
        continue
      }
      text = bounded.text
    } catch (error) {
      // 扫描与删除之间被另一路显式删掉按无引用处理；其它 I/O 错误必须阻断永久删除。
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') continue
      if ((error as NodeJS.ErrnoException).code === 'ELOOP') {
        corruptFiles.push(file)
        continue
      }
      throw error
    } finally {
      await handle?.close()
    }
    let raw: unknown
    try { raw = JSON.parse(text) } catch {
      corruptFiles.push(file)
      continue
    }
    const record = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw as Record<string, unknown> : null
    let parsed: SessionBinding | null = null
    try { parsed = parseSessionBinding(raw) } catch {
      corruptFiles.push(file)
      // 虽然整体损坏，cardId 若仍明确，对内诊断仍保留该引用身份。
      if (record && isTargetCard(record.cardId)) {
        const sessionId = typeof record.sessionId === 'string' && record.sessionId ? record.sessionId : file.replace(/\.json$/i, '')
        references.push(sessionId)
        if (typeof record.storyId === 'string') {
          try { storyRoot('.', record.storyId); storyIds.push(record.storyId) } catch { /* ignore invalid storyId */ }
        } else if (record.storyId === undefined && sessionId) {
          storyIds.push(legacyStoryId(sessionId))
        }
      }
      continue
    }
    const actual = join(paths.sessions, file)
    const expected = sessionFile(paths, parsed.sessionId)
    const sameFile = process.platform === 'win32' ? actual.toLowerCase() === expected.toLowerCase() : actual === expected
    if (!sameFile) corruptFiles.push(file)
    if (isTargetCard(parsed.cardId)) {
      references.push(parsed.sessionId)
      storyIds.push(parsed.storyId ?? legacyStoryId(parsed.sessionId))
    }
  }
  return { sessionIds: [...new Set(references)].sort(), storyIds: [...new Set(storyIds)].sort(), corruptFiles: [...new Set(corruptFiles)].sort() }
}
