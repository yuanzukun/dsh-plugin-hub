import {needsMvuStatusPlaceholder,MVU_STATUS_PLACEHOLDER} from '../core/mvuStatusDisplay.js'
/**
 * TavernService：remote 方法实现（薄壳，组合 state/floors/pipeline）。
 *
 * 平台约定：方法返回裸业务值，失败抛错（FloorError.message 原样透出给 client）。
 * { ok, value | error } 信封由 typert gateway（host invokeRpc / client invoke）生成，
 * 这里不要再包一层（双层信封会让 client 的 r.value.xxx 全部读到 undefined）。
 * 每个方法的返回注解指向 ../remote.ts 的 TavernMethodResults——结果形状的单一来源，
 * client 镜像（client/types.ts）索引同一张表，两面形状漂移会立刻编译报错。
 */
import type { TavernServiceContract } from '../remote.js'
import type { Context } from '@deepseek-ai/cordis'
import type { LlmRuntime } from '@deepseek-ai/dsh-llm'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import { sessionModelRoute } from './modelRoute.js'
import { PRESET_ADAPTER_SOURCE_PROVIDER } from './presetAdapter.js'
import { measureStaleTurnContext } from './turnContextDiagnostics.js'
import type { TavernConfigRaw, TavernSettingsScope } from './config.js'
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import { estimateTokens } from '../core/tokenize.js'
import { inspectCharacterCompatibility } from '../core/characterCompatibility.js'
import { isolated } from './isolated.js'
import { collectDisplayRegexDiagnostics } from './templateDisplay.js'
import { hideIncompleteHtml, presentRenderedOutput, stripOpaqueDisplayMeta } from '../core/displaySanitize.js'
import { disableInteractiveParts, splitTemplateDisplay, TEMPLATE_DISPLAY_PARTS_VERSION, type TemplateDisplayPart } from '../core/templateDisplay.js'
import { expandIdentityMacros } from '../core/macros.js'
import { chatPickSeed } from '../core/binding.js'
import { DEFAULT_USER_NAME } from '../core/persona.js'
import { cardGreetingVariants, isTavernGreetingEvent } from '../core/greetingLog.js'
import type { MemoryEntry, PromptPreset } from '../core/types.js'
import { exportLorebook, mergeDeltasForExport, parseLorebook } from '../state/lorebook.js'
import { parseStoredPreset, parseStPreset } from '../state/presetStore.js'
import { rebuildIndex } from '../state/workspace.js'
import { assertBindingFileIdentity, parseSessionBinding, type SessionBinding } from './bindings.js'
import { writeHostForkSkipped } from './hostForkAdoption.js'
import { parseJsonCard, parsePngCard } from '../state/card.js'
import { characterEditRevision, jsonEditRevision, personaEditRevision, presetEditRevision, regexEditRevision } from '../state/characterRevision.js'
import { FloorError, continueFloor, discardHostForkAdoptionPlan, editAssistantMessage, editUserMessage, enterGreetingConversation, getFloorAssistantMessage, getFloorSiblings, getFloorUserMessage, getGreetingSwipe, regenerate, rollbackToFloor, swipeGreeting } from './floors.js'
import { impersonate } from './impersonate.js'
import { CHAT_BOOK_CORRUPT_MESSAGE, loadBoundLoreEntries, runTavernPipeline } from './pipeline.js'
import { hasEjs } from '../core/template.js'
import { templateCardData } from '../core/templateAssets.js'
import { characterPromptName } from '../core/characterData.js'
import { loadTemplateMetadata, loadTemplateOutputs, templateTextHash } from '../state/template.js'
import { loadTemplateAvatars } from './templateAvatar.js'
import { sessionCacheUsage } from './requestDiagnostics.js'
import { hasNativeMvuEntry } from '../core/cardScript.js'
import { displaySessionEventAt, displaySessionHasUserMessage, readDisplaySessionEvents } from './sessionEvents.js'
import { continuationDisplaySources, continuationDisplayText } from '../core/continuationDisplay.js'
import {getHelperWorldbookContext,helperWorldbookOperation,rebindHelperWorldbooks} from './helperWorldbook.js'
import {editHelperMessages} from './helperChatEdits.js'
import { getHelperSnapshot, commitHelperVariables, getHelperScriptBundle, loadHelperDisplaySet, sessionHelperLibraries, type HelperDisplaySet } from './helperRuntime.js'
import { helperSnapshotAt } from '../core/helperRuntime.js'
import type { HelperScriptContext } from '../core/helperScripts.js'
import type { HelperWorldbookContext } from '../core/helperWorldbook.js'
import {prepareHelperMvuJob,commitHelperMvuJob} from './helperMvu.js'
import {runHelperMvuEnable} from './helperMvuLifecycle.js'
import {abandonHelperMvu} from './helperMvuAbandon.js'
import {enableHelperMvu} from './helperMvuEnable.js'
import {getHelperEventState} from './helperEventState.js'
import {openHelperFrame,closeHelperFrame,helperFrameWriteGuard} from './helperFrameLease.js'
import type { TavernState } from './state.js'
import type { RenderedOutput, TavernMethodResults,TavernMethodRequests } from '../remote.js'
import { deleteEditorDraft, getEditorDraft, saveEditorDraft } from './editorDrafts.js'
import { createPluginAboutReader, type PluginAboutReader } from './pluginAbout.js'
import { withWorkspaceLock } from '../state/workspaceLock.js'

/** 头像缓存条数上限：卡删除/再导入会产生新 cardId，旧条目无人主动清，超上限淘汰最旧（只多一次重读，无正确性影响）。 */
const AVATAR_CACHE_MAX = 32

/** 一批展示请求共享的只读加载（见 TavernService.displayScope）。 */
interface DisplayScope {
  sessionId: string
  settings: TavernConfigRaw
  liveEvents: readonly SessionEvent[] | undefined
  canSwipeGreeting: boolean
  binding: () => Promise<SessionBinding | null>
  assets: () => Promise<{
    rules: Awaited<ReturnType<TavernState['rulesFor']>>
    ws: Awaited<ReturnType<TavernState['loadCharacter']>>
    persona: Awaited<ReturnType<TavernState['resolvePersona']>>
    names: { char: string; user: string }
    story: Awaited<ReturnType<TavernState['storyWorkspace']>>
  }>
  displayEvents: () => Promise<readonly SessionEvent[]>
  helperSet: (withSnapshot: boolean) => Promise<HelperDisplaySet>
  helperExtras: () => Promise<{ helperScripts: HelperScriptContext; helperWorldbooks: HelperWorldbookContext }>
}

/** 单个气泡的展示结果；卡面快照与脚本库、世界书只标记需要，由调用方按单条或批次组装。 */
interface DisplayDraft {
  output: Omit<RenderedOutput, 'helper' | 'helperScripts' | 'helperWorldbooks'>
  helperMessageId?: number
  helperExtras?: boolean
}

export class TavernService extends TypertRemoteService implements TavernServiceContract {
  constructor(
    ctx: Context,
    /** 运行时中枢（agent 面插件经 ctx.tavern 访问）。 */
    readonly state: TavernState,
    private readonly settingsScope: TavernSettingsScope,
  ) {
    super(ctx, 'tavern')
  }

  /**
   * 头像 dataURL 进程内缓存：getAvatar 每次调用都全文读盘 + Base64 编码整图，
   * 与会话头/英雄区的渲染频率不匹配。指纹用 WorkspaceFs.stat('card.png') 的
   * mtimeMs+size——与 state.ts 卡级正则指纹缓存同一思路：一次 stat 不读数据，
   * 且能捕获绕开写方法直写磁盘的路径（WAL 回滚 / 外部换图）。
   */
  private readonly avatarCache = new Map<string, { fingerprint: string; dataUrl: string | null }>()

  // ── 未提交的编辑器草稿 ────────────────────────────────────────────────────

  async getEditorDraft(request: { owner: string; key: string }): Promise<TavernMethodResults['getEditorDraft']> {
    return { draft: await getEditorDraft(this.state.paths.root, request.owner, request.key) }
  }

  async saveEditorDraft(request: { owner: string; key: string; value: unknown }): Promise<TavernMethodResults['saveEditorDraft']> {
    await saveEditorDraft(this.state.paths.root, request.owner, request.key, request.value)
    return { saved: true }
  }

  async deleteEditorDraft(request: { owner: string; key: string }): Promise<TavernMethodResults['deleteEditorDraft']> {
    await deleteEditorDraft(this.state.paths.root, request.owner, request.key)
    return { deleted: true }
  }

  // ── 设置 ─────────────────────────────────────────────────────────────────

  getSettings(_request: Record<string, never>): TavernMethodResults['getSettings'] {
    return { settings: this.settingsScope.get() }
  }

  async updateSettings(request: { patch: unknown }): Promise<TavernMethodResults['updateSettings']> {
    if (!request.patch || typeof request.patch !== 'object' || Array.isArray(request.patch)) throw new FloorError('invalid-settings', '设置补丁必须是对象')
    await this.settingsScope.update(request.patch)
    return { settings: this.settingsScope.get() }
  }

  // ── 角色 ─────────────────────────────────────────────────────────────────

  async listCharacters(_request: Record<string, never>): Promise<TavernMethodResults['listCharacters']> {
    return { items: await this.state.listCharacters() }
  }

  async listArchivedCharacters(_request: Record<string, never>): Promise<TavernMethodResults['listArchivedCharacters']> {
    return { items: await this.state.listArchivedCharacters() }
  }

  async archiveCharacter(request: { cardId: string }): Promise<TavernMethodResults['archiveCharacter']> {
    await this.state.archiveCharacter(request.cardId)
    return { archived: true }
  }

  async restoreCharacter(request: { cardId: string }): Promise<TavernMethodResults['restoreCharacter']> {
    await this.state.restoreCharacter(request.cardId)
    return { restored: true }
  }

  async inspectCharacter(request: { name: string; dataBase64: string }): Promise<TavernMethodResults['inspectCharacter']> {
    try {
      const bytes = Buffer.from(request.dataBase64, 'base64')
      const card = /\.png$/i.test(request.name)
        ? parsePngCard(bytes)
        : parseJsonCard(JSON.parse(new TextDecoder().decode(bytes)) as unknown)
      const bookEntries = card.characterBook?.entries
      const entryCount = Array.isArray(bookEntries) ? bookEntries.length : 0
      return {
        name: card.name,
        hasAvatar: Boolean(card.pngBytes && card.pngBytes.length > 0),
        hasCharacterBook: entryCount > 0,
        characterBookName: card.characterBook?.name ?? null,
        entryCount,
        compatibility: inspectCharacterCompatibility(card),
      }
    } catch (error) {
      throw new FloorError('invalid-card', error instanceof Error ? error.message : String(error))
    }
  }

  async importCharacter(request: { name: string; dataBase64: string; importWorldBook?: boolean }): Promise<TavernMethodResults['importCharacter']> {
    const bytes = Buffer.from(request.dataBase64, 'base64')
    const ws = await this.state.importCharacter(request.name, bytes, { importWorldBook: request.importWorldBook !== false })
    return { cardId: ws.cardId, name: ws.card.name }
  }

  async getCharacterDeletePlan(request: { cardId: string }): Promise<TavernMethodResults['getCharacterDeletePlan']> {
    return this.state.characterDeletePlan(request.cardId)
  }

  async deleteCharacter(request: { cardId: string; discardStoryIds?: string[] }): Promise<TavernMethodResults['deleteCharacter']> {
    const { salvagedLorebook } = await this.state.deleteCharacter(request.cardId, { discardStoryIds: request.discardStoryIds })
    return { deleted: true, salvagedLorebook }
  }

  async getCharacterDetail(request: { cardId: string }): Promise<TavernMethodResults['getCharacterDetail']> {
    const ws = await this.state.loadCharacter(request.cardId)
    if (!ws) throw new FloorError('card-not-found', `角色 ${request.cardId} 不存在`)
    const handle = await this.state.workspace(request.cardId)
    const { card } = ws
    return {
      cardId: ws.cardId,
      revision: characterEditRevision(card),
      name: card.name,
      description: card.description,
      personality: card.personality,
      scenario: card.scenario,
      firstMes: card.firstMes,
      alternateGreetings: card.alternateGreetings,
      mesExample: card.mesExample,
      systemPrompt: card.systemPrompt,
      postHistoryInstructions: card.postHistoryInstructions,
      creatorNotes: card.creatorNotes,
      creator: card.creator,
      characterVersion: card.characterVersion,
      tags: card.tags,
      spec: card.spec,
      hasCharacterBook: card.characterBook !== null,
      characterBookName: card.characterBook?.name ?? null,
      characterBookEntryCount: card.characterBook?.entries.length ?? 0,
      hasAvatar: await handle.fs.exists('card.png'),
      depthPrompt: card.depthPrompt,
      extensions: card.extensions,
      characterName: characterPromptName(card),
    }
  }

  async saveCharacter(request: {
    cardId: string
    expectedRevision?: string
    name?: string
    description?: string
    personality?: string
    scenario?: string
    firstMes?: string
    alternateGreetings?: string[]
    mesExample?: string
    systemPrompt?: string
    postHistoryInstructions?: string
    creatorNotes?: string
    creator?: string
    characterVersion?: string
    tags?: string[]
    depthPrompt?: { prompt: string; depth: number; role: 'system' | 'user' | 'assistant' } | null
  }): Promise<TavernMethodResults['saveCharacter']> {
    try {
      return await this.state.saveCharacter(request.cardId, {
        name: request.name,
        description: request.description,
        personality: request.personality,
        scenario: request.scenario,
        firstMes: request.firstMes,
        alternateGreetings: request.alternateGreetings,
        mesExample: request.mesExample,
        systemPrompt: request.systemPrompt,
        postHistoryInstructions: request.postHistoryInstructions,
        creatorNotes: request.creatorNotes,
        creator: request.creator,
        characterVersion: request.characterVersion,
        tags: request.tags,
        depthPrompt: request.depthPrompt,
      }, request.expectedRevision)
    } catch (error) {
      throw new FloorError('invalid-card', error instanceof Error ? error.message : String(error))
    }
  }

  async createCharacter(request: { name: string }): Promise<TavernMethodResults['createCharacter']> {
    const name = request.name?.trim()
    if (!name) throw new FloorError('invalid-card', '角色名不能为空')
    const ws = await this.state.createCharacter(name)
    return { cardId: ws.cardId, name: ws.card.name }
  }

  async exportCharacter(request: { cardId: string }): Promise<TavernMethodResults['exportCharacter']> {
    try {
      return await this.state.exportCharacter(request.cardId)
    } catch (error) {
      throw new FloorError('card-not-found', error instanceof Error ? error.message : String(error))
    }
  }

  // ── 预设 ─────────────────────────────────────────────────────────────────

  async listPresets(_request: Record<string, never>): Promise<TavernMethodResults['listPresets']> {
    return { items: await this.state.listPresetSummaries() }
  }

  async importPreset(request: { name: string; json: unknown }): Promise<TavernMethodResults['importPreset']> {
    const { preset, warnings } = parseStPreset(request.json, request.name)
    if (request.name && preset.name === '未命名预设') preset.name = request.name
    // 回显用落盘后的实际 id（identifier 含非法字符时会被净化），UI 按它打开才与磁盘一致。
    const id = await this.state.savePreset(preset)
    return { id, warnings }
  }

  async savePreset(request: TavernMethodRequests['savePreset']): Promise<TavernMethodResults['savePreset']> {
    let preset: PromptPreset
    try {
      preset = parseStoredPreset(request.preset)
    } catch (error) {
      throw new FloorError('invalid-preset', error instanceof Error ? error.message : String(error))
    }
    // 回显用落盘后的实际 id（理由同 importPreset）。
    return this.state.savePresetSnapshot(preset, { id: request.id, preserveHelperSettings: true, expectedRevision: request.expectedRevision ?? null })
  }

  async deletePreset(request: { id: string }): Promise<TavernMethodResults['deletePreset']> {
    await this.state.deletePreset(request.id)
    return { deleted: true }
  }

  async getPreset(request: { id: string }): Promise<TavernMethodResults['getPreset']> {
    const preset = await this.state.loadPreset(request.id)
    if (!preset) throw new FloorError('preset-not-found', `预设 ${request.id} 不存在`)
    return { preset, revision: presetEditRevision(preset) }
  }

  // ── 世界书库 ──────────────────────────────────────────────────────────────

  async listLorebooks(_request: Record<string, never>): Promise<TavernMethodResults['listLorebooks']> {
    return { items: await this.state.listLorebooks() }
  }

  async getLorebook(request: { name: string }): Promise<TavernMethodResults['getLorebook']> {
    const json = await this.state.loadLorebookJson(request.name)
    if (json === null) throw new FloorError('lorebook-not-found', `世界书 ${request.name} 不存在`)
    return { json, revision: jsonEditRevision(json) }
  }

  async importLorebook(request: { name: string; json: unknown }): Promise<TavernMethodResults['importLorebook']> {
    // 先归一化验证可读性，再原样落盘；回显名以落盘后的实际 id 为准（原始名带非法字符会被净化）。
    const entries = parseLorebook(request.json, { source: 'global', sourceRef: request.name })
    const id = await this.state.saveLorebook(request.name, request.json)
    return { name: id, entryCount: entries.length }
  }

  async saveLorebook(request: TavernMethodRequests['saveLorebook']): Promise<TavernMethodResults['saveLorebook']> {
    parseLorebook(request.json, { source: 'global', sourceRef: request.name })
    // 回显名以落盘后的实际 id 为准（同 importLorebook）。
    return this.state.saveLorebookSnapshot(request.name, request.json, request.expectedRevision ?? null)
  }

  async deleteLorebook(request: { name: string }): Promise<TavernMethodResults['deleteLorebook']> {
    await this.state.deleteLorebook(request.name)
    return { deleted: true }
  }

  async getCharacterLorebook(request: { cardId: string }): Promise<TavernMethodResults['getCharacterLorebook']> {
    const book = await this.state.loadCharacterLorebookRaw(request.cardId)
    if (!book) throw new FloorError('lorebook-not-found', `角色 ${request.cardId} 没有内嵌世界书`)
    return { ...book, revision: jsonEditRevision(book.json) }
  }

  async saveCharacterLorebook(request: TavernMethodRequests['saveCharacterLorebook']): Promise<TavernMethodResults['saveCharacterLorebook']> {
    parseLorebook(request.json, { source: 'character', sourceRef: request.cardId })
    return this.state.saveCharacterLorebook(request.cardId, request.json, request.expectedRevision ?? null)
  }

  async deleteEmbeddedLorebook(request: { cardId: string }): Promise<TavernMethodResults['deleteEmbeddedLorebook']> {
    await this.state.deleteCharacterLorebook(request.cardId)
    return { deleted: true }
  }

  async getChatLorebook(request: { cardId: string; storyId?: string }): Promise<TavernMethodResults['getChatLorebook']> {
    if ((await this.state.loadCharacter(request.cardId)) === null) {
      throw new FloorError('card-not-found', `角色 ${request.cardId} 不存在`)
    }
    const json = await this.state.getChatLorebook(request.cardId, request.storyId)
    return { json, revision: jsonEditRevision(json) }
  }

  async saveChatLorebook(request: TavernMethodRequests['saveChatLorebook']): Promise<TavernMethodResults['saveChatLorebook']> {
    if ((await this.state.loadCharacter(request.cardId)) === null) {
      throw new FloorError('card-not-found', `角色 ${request.cardId} 不存在`)
    }
    const revision = await this.state.saveChatLorebook(request.cardId, request.json, request.storyId, request.expectedRevision ?? jsonEditRevision({ entries: {} }))
    return { saved: true, revision }
  }

  async getJournal(request: { cardId: string; storyId?: string }): Promise<TavernMethodResults['getJournal']> {
    if ((await this.state.loadCharacter(request.cardId)) === null) {
      throw new FloorError('card-not-found', `角色 ${request.cardId} 不存在`)
    }
    return { text: await this.state.getJournal(request.cardId, request.storyId) }
  }

  async saveJournal(request: { cardId: string; storyId?: string; text: string }): Promise<TavernMethodResults['saveJournal']> {
    if ((await this.state.loadCharacter(request.cardId)) === null) {
      throw new FloorError('card-not-found', `角色 ${request.cardId} 不存在`)
    }
    await this.state.saveJournal(request.cardId, request.text ?? '', request.storyId)
    return { saved: true }
  }

  // ── 人设 ─────────────────────────────────────────────────────────────────

  async listPersonas(_request: Record<string, never>): Promise<TavernMethodResults['listPersonas']> {
    return { items: (await this.state.listPersonas()).map(persona => ({ ...persona, revision: personaEditRevision(persona) })) }
  }

  async savePersona(request: TavernMethodRequests['savePersona']): Promise<TavernMethodResults['savePersona']> {
    if (!request.persona?.id) throw new FloorError('invalid-persona', '人设缺少 id')
    // 回显与默认页都用落盘后的实际 id：id 被净化过时磁盘 JSON 里的 id 也一并改写，
    // 若继续用原始 id，默认页指向的净化文件与这里回显的 id 会各说各话。
    // 未携带版本的旧客户端只允许新建，不能无条件覆盖已有资产。
    const id = await this.state.savePersona(request.persona, request.expectedRevision ?? null)
    let defaultWarning: string | undefined
    // 人设已经写入成功；默认设置是另一项写入，失败应单独回报，不能让客户端误以为资产没保存。
    try {
      const settings = this.settingsScope.get()
      if (!settings.defaults?.personaId) {
        await this.settingsScope.update({ defaults: { ...settings.defaults, personaId: id } })
      }
    } catch (cause) {
      defaultWarning = cause instanceof Error ? cause.message : String(cause)
    }
    return { id, revision: personaEditRevision({ ...request.persona, id }), ...(defaultWarning ? { defaultWarning } : {}) }
  }

  async deletePersona(request: { id: string }): Promise<TavernMethodResults['deletePersona']> {
    const id = await this.state.deletePersona(request.id)
    const settings = this.settingsScope.get()
    const defaultId = settings.defaults?.personaId
    if (defaultId && (defaultId === request.id || defaultId === id || (process.platform === 'win32' && defaultId.toLowerCase() === id.toLowerCase()))) {
      await this.settingsScope.update({
        defaults: { ...settings.defaults, personaId: '' },
      })
    }
    return { deleted: true }
  }

  // ── 正则 ─────────────────────────────────────────────────────────────────

  async listRegexRules(_request: Record<string, never>): Promise<TavernMethodResults['listRegexRules']> {
    return this.state.getRegexRulesSnapshot()
  }

  async saveRegexRules(request: TavernMethodRequests['saveRegexRules']): Promise<TavernMethodResults['saveRegexRules']> {
    const revision = await this.state.saveRegexRules(request.rules, request.expectedRevision ?? regexEditRevision([]))
    return { count: request.rules.length, revision }
  }

  // ── 会话绑定 ──────────────────────────────────────────────────────────────

  /** 以已提交日志判定是否进入对话，避免客户端 blank 镜像滞后时误清绑定。 */
  private async conversationStarted(sessionId: string): Promise<boolean> {
    return (await readDisplaySessionEvents(this.ctx,sessionId)).some(
      (e, _i, all) => e.type === 'turn/start' || e.type === 'assistant/message' || (e.type === 'user/message' && displaySessionHasUserMessage(all)),
    ) ?? false
  }

  async getSessionBinding(request: { sessionId: string }): Promise<TavernMethodResults['getSessionBinding']> {
    const binding = await this.state.loadBinding(request.sessionId)
    const persona = binding ? await this.state.resolvePersona(binding.personaId) : null
    // 异步读资产期间可能刚写入开场白，返回前再取日志状态，避免向 hero 回传旧 blank 判定。
    const session = this.ctx.sessions.get(request.sessionId as Session['id'])
    const canSwipeGreeting = Boolean(binding && session && !displaySessionHasUserMessage(session.snapshotEvents()))
    const conversationStarted = await this.conversationStarted(request.sessionId)
    return { binding, userName: persona?.name.trim() || DEFAULT_USER_NAME, canSwipeGreeting, conversationStarted }
  }

  /** 剧情归属变更先同步取消当前宿主请求，覆盖 agent/request 之后 prepareCall 的异步准备；未来输入仍留在原生队列。 */
  private cancelChangedBinding(sessionId: string, previous: SessionBinding | null, next: SessionBinding | null): void {
    const plan = this.state.turnPlans.get(sessionId)
    // 当前读失败可按未绑定容错，活动计划仍是准备中请求的确定归属；不能在实际解除后放行旧角色请求。
    if (previous?.cardId === next?.cardId && previous?.storyId === next?.storyId
      && (!plan || plan.cardId === next?.cardId && plan.storyId === next?.storyId)) return
    const agent = this.ctx.agents?.get(sessionId as Session['id'])
    if (agent?.status === 'running') agent.cancel({ kind: 'hook', reason: 'Tavern 剧情绑定已变化' }, { keepInbox: true })
  }

  async setSessionBinding(request: { binding: unknown }): Promise<TavernMethodResults['setSessionBinding']> {
    // 宽松传输、严格校验：绑定整体过 parseSessionBinding（缺字段/类型不符抛错，不落盘），
    // 不能只抽查 sessionId/cardId 就把客户端自报的其余字段原样写盘。
    let binding: SessionBinding
    try {
      binding = parseSessionBinding(request.binding)
    } catch (error) {
      throw new FloorError('invalid-binding', error instanceof Error ? error.message : String(error))
    }
    if ((await this.state.loadCharacter(binding.cardId)) === null) {
      throw new FloorError('card-not-found', `角色 ${binding.cardId} 不存在`)
    }
    const existing = await this.state.loadBinding(binding.sessionId, true)
    // Windows 同卡别名必须先还原持久身份，后面的剧情、祖先与 MVU 判断共用它。
    if (existing && process.platform === 'win32' && existing.cardId.toLowerCase() === binding.cardId.toLowerCase()) {
      binding = { ...binding, cardId: existing.cardId }
    }
    // 会话启用的脚本含官方 MVU 入口时，首次绑定（或换卡）且客户端未表态就开启原生 MVU：
    // 否则变量永不初始化，用户只会看到「MVU 不能用」。显式关闭（false）始终尊重。
    // 同卡保存保持未表态，由页面经 enableHelperMvu 在空闲时跟随，避免生成中保存其它字段被 idle 认领拒绝。
    if (binding.helperMvu === undefined && existing?.cardId !== binding.cardId && this.state.config.interactiveCards
      && binding.interactiveCards !== false && hasNativeMvuEntry(await sessionHelperLibraries(this.state, binding))) binding = { ...binding, helperMvu: true }
    // fork WAL 祖先由 host 维护；同卡编辑绑定时保留，换卡则清空，不能信任客户端自报。
    // createdAt 由 parseSessionBinding 保证必填非空，无需再兜底。
    const save=(claimedEnable:boolean)=>withWorkspaceLock(this.state.paths.sessions,async()=>{
      // 远程请求的前置读取可能已过时；实际提交在同一绑定锁内继承当前剧情和祖先，不能换回并发请求的旧身份。
      const current=await this.state.loadBindingUnwaited(binding.sessionId,true)
      const sameCard=current!==null&&(process.platform==='win32'
        ?current.cardId.toLowerCase()===binding.cardId.toLowerCase():current.cardId===binding.cardId)
      if(!claimedEnable&&binding.helperMvu===true&&(current?.helperMvu!==true||!sameCard||current.interactiveCards===false&&binding.interactiveCards!==false))return false
      await this.state.saveBinding({
        ...binding,
        ...(sameCard?{cardId:current.cardId}:{}),
        storyId:sameCard?current.storyId:undefined,
        walLineage:sameCard?current.walLineage:undefined,
      },(previous,next)=>this.cancelChangedBinding(binding.sessionId,previous,next))
      return true
    })
    if(binding.helperMvu===true&&(existing?.helperMvu!==true||existing.cardId!==binding.cardId||existing.interactiveCards===false&&binding.interactiveCards!==false))await runHelperMvuEnable(this.ctx,this.state,binding.sessionId,()=>save(true))
    else if(!(await save(false)))await runHelperMvuEnable(this.ctx,this.state,binding.sessionId,()=>save(true))
    return { saved: true }
  }

  async clearSessionBinding(request: { sessionId: string; onlyIfBlank?: boolean }): Promise<TavernMethodResults['clearSessionBinding']> {
    if (!request.sessionId) throw new FloorError('invalid-binding', '绑定缺少 sessionId')
    const clear=()=>withWorkspaceLock(this.state.paths.sessions,async()=>{
      // 文件名别名不能借解除绑定取消另一会话；身份校验通过后、实际删除前取消准备中的旧剧情请求。
      await assertBindingFileIdentity(this.state.paths,request.sessionId)
      const current=await this.state.loadBindingUnwaited(request.sessionId)
      const live=this.ctx.sessions.get(request.sessionId as Session['id'])
      // 明确解除的合法绑定须留原种子凭据；写失败在取消/删除之前拒绝，未知接管失败不生成 skip。
      if(current&&live){
        await writeHostForkSkipped(this.state.paths,live)
        discardHostForkAdoptionPlan(this.state,request.sessionId)
      }
      this.cancelChangedBinding(request.sessionId,current,null)
      await this.state.clearBinding(request.sessionId)
    })
    if (request.onlyIfBlank === true) {
      // 与 ensureGreeting、inbox 初始化共用队列，在真正删除前重新确认状态。
      return this.state.enqueueSessionTask(request.sessionId, async () => {
        if (await this.conversationStarted(request.sessionId)) return { cleared: false }
        await clear()
        return { cleared: true }
      })
    }
    await clear()
    return { cleared: true }
  }

  // ── 开场白与楼层 ──────────────────────────────────────────────────────────

  async ensureGreeting(request: { sessionId: string }): Promise<TavernMethodResults['ensureGreeting']> {
    return this.state.enqueueSessionTask(request.sessionId, async () => ({
      created: await enterGreetingConversation(this.floorDeps(), request.sessionId),
      conversationStarted: await this.conversationStarted(request.sessionId),
    }))
  }

  async swipeGreeting(request:TavernMethodRequests['swipeGreeting']): Promise<TavernMethodResults['swipeGreeting']> {
    return this.state.enqueueSessionTask(request.sessionId, () =>
      swipeGreeting(this.floorDeps(), request.sessionId, request.index,helperFrameWriteGuard(this.state,request,request.frameLease)),
    )
  }

  async getGreetingSwipe(request: { sessionId: string; messageId: string }): Promise<TavernMethodResults['getGreetingSwipe']> {
    await this.state.waitForSessionCommits(request.sessionId)
    return getGreetingSwipe(this.floorDeps(), request.sessionId, request.messageId)
  }

  /** 分支兄弟导航是只读查询：等排队中的楼层任务落定即可，不进串行队列，也不等空闲记忆维护。 */
  async getFloorSiblings(request: { sessionId: string; messageId?: string; turn?: number }): Promise<TavernMethodResults['getFloorSiblings']> {
    await this.state.waitForSessionCommits(request.sessionId)
    return getFloorSiblings(this.floorDeps(), request.sessionId, request.messageId, request.turn)
  }

  async renderOutputText(request: { sessionId: string; text: string; messageId?: number }): Promise<TavernMethodResults['renderOutputText']> {
    await this.state.waitForSessionCommits(request.sessionId)
    const scope = this.displayScope(request.sessionId)
    const { output, helperMessageId, helperExtras } = await this.renderDisplayDraft(request, scope)
    return {
      ...output,
      ...(helperMessageId === undefined ? {} : { helper: helperSnapshotAt((await scope.helperSet(true)).base!, helperMessageId) }),
      ...(helperExtras ? await scope.helperExtras() : {}),
    }
  }

  /**
   * 长历史首屏一次挂载几十个气泡：合并为一批共享绑定、资产、历史与变量的读取，卡面快照、
   * 脚本库与世界书在响应中只出现一次，由客户端按引用重组。单项失败只影响该项。
   */
  async renderOutputTexts(request: TavernMethodRequests['renderOutputTexts']): Promise<TavernMethodResults['renderOutputTexts']> {
    await this.state.waitForSessionCommits(request.sessionId)
    const scope = this.displayScope(request.sessionId)
    const drafts = await Promise.allSettled(request.items.map((item) => this.renderDisplayDraft({ sessionId: request.sessionId, ...item }, scope)))
    const batch: TavernMethodResults['renderOutputTexts'] = { items: [] }
    for (const result of drafts) {
      if (result.status === 'rejected') {
        batch.items.push({ ok: false, error: result.reason instanceof Error ? result.reason.message : String(result.reason) })
        continue
      }
      const { output, helperMessageId, helperExtras } = result.value
      // 两类共享部分已在草稿内成功加载过；这里只取同一份备忘结果。
      if (helperMessageId !== undefined) batch.helperBase ??= (await scope.helperSet(true)).base!
      if (helperExtras && !batch.helperScripts) Object.assign(batch, await scope.helperExtras())
      batch.items.push({ ok: true, value: { ...output, ...(helperMessageId === undefined ? {} : { helperMessageId }), ...(helperExtras ? { helperExtras: true as const } : {}) } })
    }
    return batch
  }

  /** 同一批展示请求共享的只读加载：每类惰性读取一次，批内各气泡复用同一结果。 */
  private displayScope(sessionId: string): DisplayScope {
    const once = <T,>(load: () => Promise<T>) => { let value: Promise<T> | undefined; return () => (value ??= load()) }
    const settings = this.settingsScope.get()
    const liveEvents = this.ctx.sessions.get(sessionId as Session['id'])?.snapshotEvents()
    const binding = once(() => this.state.loadBinding(sessionId))
    const helperSets = [once(() => loadHelperDisplaySet(this.ctx, this.state, sessionId, false)), once(() => loadHelperDisplaySet(this.ctx, this.state, sessionId, true))] as const
    return {
      sessionId, settings, liveEvents,
      canSwipeGreeting: Boolean(liveEvents && !displaySessionHasUserMessage(liveEvents)),
      binding,
      assets: once(async () => {
        const current = (await binding())!
        const rules = await this.state.rulesFor(current)
        const ws = await this.state.loadCharacter(current.cardId)
        const persona = await this.state.resolvePersona(current.personaId)
        const names = { char: ws ? characterPromptName(ws.card) : 'Assistant', user: persona?.name ?? DEFAULT_USER_NAME }
        const story = await this.state.storyWorkspace(current.cardId, current.storyId)
        return { rules, ws, persona, names, story }
      }),
      displayEvents: once(() => readDisplaySessionEvents(this.ctx, sessionId)),
      helperSet: (withSnapshot) => helperSets[withSnapshot ? 1 : 0](),
      helperExtras: once(async () => {
        const storyId = (await binding())!.storyId!
        return { helperScripts: await this.state.getSessionHelperScripts(sessionId, storyId), helperWorldbooks: await getHelperWorldbookContext(this.state, sessionId, storyId) }
      }),
    }
  }

  private async renderDisplayDraft(request: { sessionId: string; text: string; messageId?: number }, scope: DisplayScope): Promise<DisplayDraft> {
    const text = request.text ?? ''
    const { settings, liveEvents, canSwipeGreeting } = scope
    const whitelist = [...settings.cardNetworkWhitelist]
    const binding = await scope.binding()
    if (!binding) {
      const presented = presentRenderedOutput(text, settings.interactiveCards)
      return { output: {
        ...presented,
        ...(presented.htmls.length ? {parts:splitTemplateDisplay(hideIncompleteHtml(stripOpaqueDisplayMeta(text)).text)} : {}),
        interactiveCards: settings.interactiveCards,
        whitelist,
        greetings: [] as string[],
        greetingIndex: 0,
        canSwipeGreeting: false,
      } }
    }
    const allowHtml = settings.interactiveCards && binding.interactiveCards !== false
    const { rules, ws, persona, names, story } = await scope.assets()
    // SillyTavern：先 substituteParams 再跑展示正则，开场白里的 {{user}} 才能被按名字匹配。
    let named = expandIdentityMacros(text, names)
    let templateParts: TemplateDisplayPart[] | undefined
    // 展示路径遇坏聊天书只降级（不整条渲染失败），但要在输出里留下可见标记与明确诊断。
    let chatBookCorrupt = false
    const cached = request.messageId === undefined ? undefined : (await loadTemplateOutputs(story.fs,[request.messageId]))[String(request.messageId)]
    if (cached && cached.hash === templateTextHash(text)) {
      named = expandIdentityMacros(cached.text, names)
      templateParts = cached.parts
      // 旧投影会在逐片清理时永久丢掉 opener；完整已求值文本仍在，可只读重建安全展示而不重跑模板。
      if (templateParts && cached.partsVersion !== TEMPLATE_DISPLAY_PARTS_VERSION) {
        const legacyProjection = stripOpaqueDisplayMeta(cached.text)
        if (legacyProjection !== cached.text) templateParts = splitTemplateDisplay(legacyProjection)
      }
    }
    else if (hasEjs(named)) {
      // 只有未物化 EJS 才需要核对开场白事件；普通历史气泡不再重复读取完整会话。
      const displayEvents=await scope.displayEvents()
      const greeting = request.messageId !== undefined && isTavernGreetingEvent(displaySessionEventAt(displayEvents,request.messageId)??{type:''})
      if (request.messageId !== undefined && !greeting) throw new Error('该回复的模板未成功提交或已被编辑；请查看触发日志，不会在刷新时重新执行写入')
      // 开场白/独立展示没有楼层，仅执行临时副本；浏览器传入文本永远不能落盘变量。
      const preset = binding.presetId ? await this.state.loadPreset(binding.presetId) : null
      const templates = await loadTemplateMetadata(story.fs)
      // 只读展示：坏聊天书降级为「本次未注入」并回传标记，不因一本坏书让整条气泡渲染失败。
      const lore = await loadBoundLoreEntries(this.state, binding, { onCorruptChatBook: 'report' })
      chatBookCorrupt = lore.chatBookCorrupt
      if (chatBookCorrupt) {
        try { this.ctx.logger.warn(`dsh-tavern: 展示渲染降级：${CHAT_BOOK_CORRUPT_MESSAGE}`) } catch { /* 日志失败不阻断展示 */ }
      }
      const result = await isolated('template', { texts: [named], context: {
        variables: templates.variables, ...names, card: ws ? templateCardData(ws.card) : {name:names.char},
        ...await loadTemplateAvatars(this.state,binding.cardId,persona),
        entries: lore.entries,
        presets: preset?.entries.filter(e => e.enabled) ?? [], history: [], now: Date.now(), seed: 1, phase: 'render',
        sessionId: request.sessionId, cardId: binding.cardId,
      } })
      named = result.texts[0]!
      templateParts = result.parts[0]
    }
    // 机读 opener 与未完成卡面可能在前文；只读已提交模板快照，不能借续写重跑旧模板。
    const messageId=request.messageId
    if(messageId!==undefined){
      const events=liveEvents??await scope.displayEvents()
      // 续写只沿实际来源读取快照；冷启动也不展开其他楼层的正文数据块。
      const outputs=await loadTemplateOutputs(story.fs,continuationDisplaySources(events,messageId,text).map(event=>event.seq))
      const continued=continuationDisplayText(events,messageId,text,named,event=>{
        const raw=event.data.message.content.filter(block=>block.type==='text').map(block=>block.text).join('\n')
        const previous=outputs[String(event.seq)]
        if(previous?.hash===templateTextHash(raw))return expandIdentityMacros(previous.text,names)
        return hasEjs(raw)?undefined:expandIdentityMacros(raw,names)
      })
      if(continued!==named){named=continued;if(templateParts!==undefined)templateParts=splitTemplateDisplay(named)}
    }
    // 原生 MVU 已启用且卡片明确提供状态栏时，展示层补位；历史和模板缓存仍保持原始文本。
    if(allowHtml&&binding.helperMvu===true&&request.messageId!==undefined&&needsMvuStatusPlaceholder(named,rules)){
      named+='\n'+MVU_STATUS_PLACEHOLDER
      if(templateParts!==undefined)templateParts=[...templateParts,{kind:'markdown',text:MVU_STATUS_PLACEHOLDER}]
    }
    const display = templateParts === undefined ? undefined : await isolated('display', {
      parts: templateParts.map(part => ({ ...part, text: expandIdentityMacros(part.text, names) })),
      rules, macroCtx: { ...names, outlets: {}, pickSeed: chatPickSeed(binding) },
    })
    let parts = display?.parts
    let regexDiagnostics = display?.regexDiagnostics
    if (parts !== undefined && !allowHtml) parts = disableInteractiveParts(parts)
    let presented: {htmls:string[];text:string;pendingHtml?:true}
    if(parts === undefined) {
      const rendered = await isolated('render', { text: named, rules, macroCtx: { ...names, outlets: {}, pickSeed: chatPickSeed(binding) } })
      regexDiagnostics = collectDisplayRegexDiagnostics(rendered.errors, rules)
      presented = presentRenderedOutput(rendered.text, allowHtml)
      // 普通回复与展示正则生成的片段也保留原位置，避免尾部状态栏移到台词前面。
      if(presented.htmls.length) parts = splitTemplateDisplay(hideIncompleteHtml(stripOpaqueDisplayMeta(rendered.text)).text)
    } else {
      let pendingHtml=false
      if(allowHtml){
        const visibleParts:TemplateDisplayPart[]=[]
        for(const part of parts){
          if(part.kind!=='markdown'){visibleParts.push(part);continue}
          const visible=hideIncompleteHtml(part.text)
          if(visible.pendingHtml===true){
            pendingHtml=true
            const previous=visibleParts.at(-1)
            if(!visible.text.trim()&&/^\s*<(?:script|style|template)(?=[\s/>]|$)/i.test(part.text)
              &&previous?.kind==='html'&&previous.title===undefined){
              visibleParts.pop()
            }
          }
          visibleParts.push({...part,text:visible.text})
        }
        parts=visibleParts
      }
      presented = { htmls: allowHtml ? parts.filter(part => part.kind === 'html').map(part => part.text) : [],
        text: parts.filter(part => part.kind === 'markdown' && Boolean(part.text)).map(part => part.text).join('\n') || (pendingHtml?'':presentRenderedOutput(named, false).text),
        ...(pendingHtml?{pendingHtml:true as const}:{}) }
    }
    const htmls = presented.htmls
    const greetings = (ws ? cardGreetingVariants(ws.card.firstMes, ws.card.alternateGreetings) : []).map((g) =>
      expandIdentityMacros(g, names),
    )
    // 纯文本消息也承载后台脚本发布的选项，但不应为历史中的每个气泡重复传输完整消息与变量快照。
    // 卡面快照与脚本库、世界书只在这里校验能否读取；组装时引用批次共享的同一份结果。
    const helperMessageId = allowHtml && messageId !== undefined && htmls.length
      ? (await scope.helperSet(true)).context(messageId).currentMessageId : undefined
    const helperContext = allowHtml && messageId !== undefined && !htmls.length
      ? (await scope.helperSet(false)).context(messageId) : undefined
    const helperExtras = htmls.length > 0 && messageId !== undefined
    if (helperExtras) await scope.helperExtras()
    return { helperMessageId, helperExtras, output: {
      ...(parts === undefined ? {} : { parts }),
      ...(regexDiagnostics ? { regexDiagnostics } : {}),
      ...(helperContext ? { helperContext } : {}),
      html: htmls[0] ?? null,
      htmls,
      // 坏聊天书时在展示正文尾部追加可见降级标记（不写日志、不改历史，修好后自动消失）。
      text: chatBookCorrupt ? `${presented.text}${presented.text ? '\n\n' : ''}[Tavern] ${CHAT_BOOK_CORRUPT_MESSAGE}` : presented.text,
      ...(presented.pendingHtml?{pendingHtml:true as const}:{}),
      interactiveCards: settings.interactiveCards,
      whitelist,
      greetings,
      greetingIndex: binding.greetingIndex,
      canSwipeGreeting,
      userName: names.user,
      characterName: names.char,
    } }
  }

  async getHelperEventState(request:TavernMethodRequests['getHelperEventState']):Promise<TavernMethodResults['getHelperEventState']>{
    await this.state.waitForSessionCommits(request.sessionId)
    return getHelperEventState(this.ctx,this.state,request)
  }
  openHelperFrame(request:TavernMethodRequests['openHelperFrame']):Promise<TavernMethodResults['openHelperFrame']>{
    return openHelperFrame(this.ctx,this.state,request)
  }
  async closeHelperFrame(request:TavernMethodRequests['closeHelperFrame']):Promise<void>{
    closeHelperFrame(this.state,request)
  }
  async getHelperSnapshot(request: {sessionId:string;messageId:number}): Promise<TavernMethodResults['getHelperSnapshot']> {
    await this.state.waitForSessionCommits(request.sessionId)
    return getHelperSnapshot(this.ctx,this.state,request.sessionId,request.messageId)
  }
  // MVU 准备与提交在剧情锁内经楼层 WAL 写入，只需等楼层提交；不等空闲记忆维护的辅助请求，
  // 否则客户端 20 秒请求超时会把正常排队误报为失败，状态栏也要等维护结束才更新。
  async prepareHelperMvuJob(request:TavernMethodRequests['prepareHelperMvuJob']):Promise<TavernMethodResults['prepareHelperMvuJob']>{
    await this.state.waitForSessionCommits(request.sessionId)
    return prepareHelperMvuJob(this.ctx,this.state,request)
  }
  async enableHelperMvu(request:TavernMethodRequests['enableHelperMvu']):Promise<TavernMethodResults['enableHelperMvu']>{
    await this.state.waitForSessionTasks(request.sessionId)
    return enableHelperMvu(this.ctx,this.state,request)
  }
  async abandonHelperMvu(request:TavernMethodRequests['abandonHelperMvu']):Promise<TavernMethodResults['abandonHelperMvu']>{
    await this.state.waitForSessionTasks(request.sessionId)
    return abandonHelperMvu(this.state,request)
  }
  async commitHelperMvuJob(request:TavernMethodRequests['commitHelperMvuJob']):Promise<TavernMethodResults['commitHelperMvuJob']>{
    await this.state.waitForSessionCommits(request.sessionId)
    return commitHelperMvuJob(this.ctx,this.state,request)
  }
  async getHelperScriptBundle(request:{sessionId:string}):Promise<TavernMethodResults['getHelperScriptBundle']> {
    await this.state.waitForSessionCommits(request.sessionId)
    const result=await getHelperScriptBundle(this.ctx,this.state,request.sessionId)
    return result.snapshot?{...result,worldbooks:await getHelperWorldbookContext(this.state,request.sessionId,result.storyId)}:result
  }
  getCharacterHelperScripts(request:{cardId:string}):Promise<TavernMethodResults['getCharacterHelperScripts']> {
    return this.state.getCharacterHelperScripts(request.cardId)
  }
  async editHelperMessages(request:TavernMethodRequests['editHelperMessages']):Promise<TavernMethodResults['editHelperMessages']>{await this.state.waitForSessionTasks(request.sessionId);return editHelperMessages(this.ctx,this.state,request.sessionId,request.messageId,request,helperFrameWriteGuard(this.state,request,request.frameLease))}
  rebindHelperWorldbooks(request:TavernMethodRequests['rebindHelperWorldbooks']):Promise<TavernMethodResults['rebindHelperWorldbooks']> {return rebindHelperWorldbooks(this.ctx,this.state,request.sessionId,request.messageId,request,helperFrameWriteGuard(this.state,request,request.frameLease))}
  getHelperWorldbookContext(request:TavernMethodRequests['getHelperWorldbookContext']):Promise<TavernMethodResults['getHelperWorldbookContext']> {return getHelperWorldbookContext(this.state,request.sessionId,request.storyId)}
  helperWorldbookOperation(request:TavernMethodRequests['helperWorldbookOperation']):Promise<TavernMethodResults['helperWorldbookOperation']> {return helperWorldbookOperation(this.ctx,this.state,request.sessionId,request.messageId,request,helperFrameWriteGuard(this.state,request,request.frameLease))}
  getSessionHelperScripts(request:TavernMethodRequests['getSessionHelperScripts']):Promise<TavernMethodResults['getSessionHelperScripts']> {
    return this.state.getSessionHelperScripts(request.sessionId,request.storyId)
  }
  commitSessionHelperScripts(request:TavernMethodRequests['commitSessionHelperScripts']):Promise<TavernMethodResults['commitSessionHelperScripts']> {
    return this.state.commitSessionHelperScripts(request.sessionId,request,helperFrameWriteGuard(this.state,request,request.frameLease))
  }
  getHelperScriptLibrary(request:TavernMethodRequests['getHelperScriptLibrary']):Promise<TavernMethodResults['getHelperScriptLibrary']> {
    return this.state.getHelperScriptLibrary(request.target)
  }
  saveHelperScriptLibrary(request:TavernMethodRequests['saveHelperScriptLibrary']):Promise<TavernMethodResults['saveHelperScriptLibrary']> {
    return this.state.saveHelperScriptLibrary(request.target,request.revision,request.trees)
  }
  saveCharacterHelperScripts(request:{cardId:string;revision:string;trees:unknown}):Promise<TavernMethodResults['saveCharacterHelperScripts']> {
    return this.state.saveCharacterHelperScripts(request.cardId,request.revision,request.trees)
  }

  commitHelperVariables(request:TavernMethodRequests['commitHelperVariables']): Promise<TavernMethodResults['commitHelperVariables']> {
    return this.state.enqueueSessionTask(request.sessionId,()=>commitHelperVariables(this.ctx,this.state,request,helperFrameWriteGuard(this.state,request,request.frameLease)))
  }

  regenerate(request: { sessionId: string; messageId?: string; turn?: number }): Promise<TavernMethodResults['regenerate']> {
    return this.state.enqueueSessionTask(request.sessionId, () =>
      regenerate(this.floorDeps(), request.sessionId, request.messageId, request.turn),
    )
  }

  rollbackToFloor(request: { sessionId: string; messageId?: string; turn?: number }): Promise<TavernMethodResults['rollbackToFloor']> {
    return this.state.enqueueSessionTask(request.sessionId, () =>
      rollbackToFloor(this.floorDeps(), request.sessionId, request.messageId, request.turn),
    )
  }

  async getFloorUserMessage(request: { sessionId: string; messageId: string }): Promise<TavernMethodResults['getFloorUserMessage']> {
    await this.state.waitForSessionCommits(request.sessionId)
    return getFloorUserMessage(this.floorDeps(), request.sessionId, request.messageId)
  }

  editUserMessage(request: { sessionId: string; messageId: string; text: string }): Promise<TavernMethodResults['editUserMessage']> {
    return this.state.enqueueSessionTask(request.sessionId, () =>
      editUserMessage(this.floorDeps(), request.sessionId, request.messageId, request.text),
    )
  }

  async getFloorAssistantMessage(request: { sessionId: string; messageId: string }): Promise<TavernMethodResults['getFloorAssistantMessage']> {
    await this.state.waitForSessionCommits(request.sessionId)
    return getFloorAssistantMessage(this.floorDeps(), request.sessionId, request.messageId)
  }

  editAssistantMessage(request: { sessionId: string; messageId: string; text: string }): Promise<TavernMethodResults['editAssistantMessage']> {
    return this.state.enqueueSessionTask(request.sessionId, () =>
      editAssistantMessage(this.floorDeps(), request.sessionId, request.messageId, request.text),
    )
  }

  continueFloor(request: { sessionId: string; messageId: string }): Promise<TavernMethodResults['continueFloor']> {
    return this.state.enqueueSessionTask(request.sessionId, () =>
      continueFloor(this.floorDeps(), request.sessionId, request.messageId),
    )
  }

  /** impersonate 是带外一次性调用，不进会话串行队列（不改会话状态）。 */
  impersonate(request: { sessionId: string }): Promise<TavernMethodResults['impersonate']> {
    return impersonate({ ctx: this.ctx, state: this.state }, request.sessionId)
  }

  // ── 记忆 ─────────────────────────────────────────────────────────────────

  async listStories(request: { cardId: string }): Promise<TavernMethodResults['listStories']> {
    return { items: await this.state.listStories(request.cardId) }
  }

  async getMemories(request: { cardId: string; storyId?: string }): Promise<TavernMethodResults['getMemories']> {
    const ws = await this.state.storyWorkspace(request.cardId, request.storyId)
    return { items: await ws.memory.list() }
  }

  async saveMemory(request: { cardId: string; storyId?: string; id?: string; body: string; tags?: string[]; keys?: string[] }): Promise<TavernMethodResults['saveMemory']> {
    // 面板/服务层非会话写路径一律走 plainWorkspace（floor 恒 null，绝不记 WAL）：
    // 生成进行中的面板编辑若走携带楼层的实例，会被记进当前楼层 WAL、回退时静默改回旧值。
    const ws = await this.state.plainWorkspace(request.cardId, request.storyId)
    let entry: MemoryEntry | null
    if (request.id) {
      entry = await ws.memory.update(
        request.id,
        { body: request.body, tags: request.tags, keys: request.keys },
        { listMode: 'replace' },
      )
      if (!entry) throw new FloorError('memory-not-found', `记忆 ${request.id} 不存在`)
    } else {
      entry = await ws.memory.write({ body: request.body, tags: request.tags, keys: request.keys })
    }
    await rebuildIndex(ws.fs, estimateTokens)
    return { id: entry.id }
  }

  async deleteMemory(request: { cardId: string; storyId?: string; id: string }): Promise<TavernMethodResults['deleteMemory']> {
    // 面板写路径走 plainWorkspace（理由同 saveMemory）。
    const ws = await this.state.plainWorkspace(request.cardId, request.storyId)
    const deleted = await ws.memory.delete(request.id)
    if (deleted) await rebuildIndex(ws.fs, estimateTokens)
    return { deleted }
  }

  /** 无 LLM 的确定性归并：原文逐条保留，只减少条目数，不宣称减少 token。 */
  async getStoryRecovery(request: { cardId: string; storyId?: string }): Promise<TavernMethodResults['getStoryRecovery']> {
    const ws = await this.state.storyWorkspace(request.cardId, request.storyId)
    return { floors: await ws.wal.recoveringFloors() }
  }

  /** 恢复反复失败时的受控出口：只删游标与标记，不跳过撤销；调用方仍须重新回退该楼层。 */
  async resetStoryRecovery(request: { cardId: string; storyId?: string }): Promise<TavernMethodResults['resetStoryRecovery']> {
    const ws = await this.state.storyWorkspace(request.cardId, request.storyId)
    return withWorkspaceLock(ws.fs.root, async () => {
      const floors = await ws.wal.recoveringFloors()
      for (const floor of floors) await ws.wal.resetRollbackCursor(floor)
      return { reset: floors }
    })
  }

  async compressMemories(request: { cardId: string; storyId?: string }): Promise<TavernMethodResults['compressMemories']> {
    // 面板写路径走 plainWorkspace（理由同 saveMemory）。
    const ws = await this.state.plainWorkspace(request.cardId, request.storyId)
    const batch = await ws.memory.oldest(this.state.config.memory.compressBatch)
    if (batch.length < 2) return { merged: 0 }
    const merged = batch.map((b, i) => `${i + 1}. ${b.body}`).join('\n')
    // 顺序与 memoryMaintenance.compressOldestMemories 一致：先落合并条目成功后再归档原条目——
    // 先归档的话，合并写失败会让整批从活跃库消失（丢事实）；反过来写失败批次原样保留可重试，
    // 归档中途失败的最坏结果只是新旧并存，下次压缩把残余再合并一次，有冗余但不丢事实。
    const count = await ws.memory.mergeBatch(batch, merged, 'merge')
    await rebuildIndex(ws.fs, estimateTokens)
    return { merged: count }
  }

  // ── 世界状态 ──────────────────────────────────────────────────────────────

  async getWorldDeltas(request: { cardId: string; storyId?: string }): Promise<TavernMethodResults['getWorldDeltas']> {
    const ws = await this.state.storyWorkspace(request.cardId, request.storyId)
    return { items: await ws.deltas.list({ includeRevoked: true }) }
  }

  async revokeWorldDelta(request: { cardId: string; storyId?: string; id: string }): Promise<TavernMethodResults['revokeWorldDelta']> {
    // 面板写路径走 plainWorkspace（理由同 saveMemory）。
    const ws = await this.state.plainWorkspace(request.cardId, request.storyId)
    const revoked = await ws.deltas.revoke(request.id)
    if (revoked) await rebuildIndex(ws.fs, estimateTokens)
    return { revoked }
  }

  async addWorldDelta(request: {
    cardId: string; storyId?: string
    type: 'add' | 'update' | 'invalidate'
    content: string
    ref?: string | null
    keys?: string[]
    order?: number
  }): Promise<TavernMethodResults['addWorldDelta']> {
    if (!request.content?.trim()) throw new FloorError('invalid-delta', '世界状态内容不能为空')
    if ((await this.state.loadCharacter(request.cardId)) === null) {
      throw new FloorError('card-not-found', `角色 ${request.cardId} 不存在`)
    }
    // 面板写路径走 plainWorkspace（理由同 saveMemory）。
    const ws = await this.state.plainWorkspace(request.cardId, request.storyId)
    const delta = await ws.deltas.append({
      type: request.type,
      ref: request.ref ?? null,
      content: request.content.trim(),
      keys: request.keys ?? [],
      order: request.order ?? 100,
      sourceRange: 'manual',
      expires: null,
    })
    await rebuildIndex(ws.fs, estimateTokens)
    return { id: delta.id }
  }

  async exportMergedLorebook(request: { cardId: string; storyId?: string }): Promise<TavernMethodResults['exportMergedLorebook']> {
    const charWs = await this.state.loadCharacter(request.cardId)
    if (!charWs) throw new FloorError('card-not-found', `角色 ${request.cardId} 不存在`)
    const ws = await this.state.storyWorkspace(request.cardId, request.storyId)
    const book = await this.state.loadCharacterLorebookRaw(request.cardId)
    const originals = book ? parseLorebook(book.json, { source: 'character', sourceRef: request.cardId }) : []
    const deltas = await ws.deltas.list()
    const merged = mergeDeltasForExport(originals, deltas)
    return { json: exportLorebook(merged, charWs.card.name) }
  }

  // ── 调试 ─────────────────────────────────────────────────────────────────

  getTriggerLog(request: { sessionId: string }): TavernMethodResults['getTriggerLog'] {
    return { log: this.state.triggerLogs.get(request.sessionId) ?? null }
  }

  async previewPrompt(request: { sessionId: string }): Promise<TavernMethodResults['previewPrompt']> {
    const agent = this.ctx.agents.get(request.sessionId as Session['id'])
    if (!agent) throw new FloorError('session-not-live', `会话 ${request.sessionId} 不在线，无法预览（请先打开该会话）`)
    const llm = this.ctx.get('llm') as LlmRuntime | undefined
    const result = await runTavernPipeline({ state: this.state, sessionId: request.sessionId, agent, llm, mode: 'preview' })
    if (!result) throw new FloorError('no-binding', '当前会话未绑定 Tavern 角色卡')
    return {
      actualRequest: this.state.requestDiagnostics.get(request.sessionId) ?? null,
      cacheUsage: sessionCacheUsage(agent.session),
      standing: result.standing,
      turnContext: result.turnContext,
      system: result.system,
      messages: result.messages,
      logLines: result.logLines,
      worldInfoBudget: result.wiBudget,
      assembleBudget: result.assembled.stats,
    }
  }

  /**
   * 上下文占用（宿主 rc.2 起 sessionProjections.stateOf 只读 token-meter 投影）。
   * 会话不在线、宿主未挂投影或尚无数据时 usage=null，调用方按未知处理。
   */
  getContextUsage(request: { sessionId: string }): TavernMethodResults['getContextUsage'] {
    const session = this.ctx.sessions.get(request.sessionId as Session['id'])
    if (!session) return { usage: null, staleTurnContext: null }
    // 旧 tavern:turn 快照只在非 DeepSeek 投影通道真正发给模型；投影通道仍报告数量，标记为已剔除。
    const agent = this.ctx.agents?.get(request.sessionId as Session['id'])
    const projected = Boolean(this.state.presetAdapter) && agent !== undefined
      && sessionModelRoute(agent).provider === PRESET_ADAPTER_SOURCE_PROVIDER
    // 辅助诊断不能拖垮用量本身：读取会话历史失败时只是不报告累积。
    let staleTurnContext: TavernMethodResults['getContextUsage']['staleTurnContext'] = null
    try { staleTurnContext = { ...measureStaleTurnContext(session), projected } } catch { staleTurnContext = null }
    const projections = this.ctx.get('sessionProjections') as
      | { stateOf?(s: Session, key: string): unknown }
      | undefined
    const pressure = projections?.stateOf?.(session, 'contextPressure') as
      | { contextWindow?: number; pressureTokens?: number; surfaceTokens?: number }
      | undefined
    if (!pressure || typeof pressure.surfaceTokens !== 'number') return { usage: null, staleTurnContext }
    // token-meter 的状态是 { nodes, breakdown: {...} }；此前按扁平对象读取，三项恒为 null。
    const breakdown = (projections?.stateOf?.(session, 'contextBreakdown') as
      | { breakdown?: { systemTokens?: number; toolsTokens?: number; messageTokens?: number } }
      | undefined)?.breakdown
    const percent =
      typeof pressure.pressureTokens === 'number' && typeof pressure.contextWindow === 'number' && pressure.contextWindow > 0
        ? Math.round((pressure.pressureTokens / pressure.contextWindow) * 100)
        : null
    return {
      usage: {
        surfaceTokens: pressure.surfaceTokens,
        pressureTokens: pressure.pressureTokens ?? null,
        contextWindow: pressure.contextWindow ?? null,
        percent,
        systemTokens: breakdown?.systemTokens ?? null,
        toolsTokens: breakdown?.toolsTokens ?? null,
        messageTokens: breakdown?.messageTokens ?? null,
      },
      staleTurnContext,
    }
  }

  /** 关于页只读取本机版本；版本检查按需联网，不提供安装执行入口。 */
  private pluginAboutReader?: PluginAboutReader
  private get aboutReader(): PluginAboutReader {
    return this.pluginAboutReader ??= createPluginAboutReader({ hostProfile: this.ctx.get('profileContext') })
  }

  getPluginAbout(_request: Record<string, never>): Promise<TavernMethodResults['getPluginAbout']> {
    return this.aboutReader.getPluginAbout()
  }

  checkPluginUpdate(_request: Record<string, never>): Promise<TavernMethodResults['checkPluginUpdate']> {
    return this.aboutReader.checkPluginUpdate()
  }

  /** Tavern 数据目录（$DSH_HOME/dsh-tavern），设置面板展示用。 */
  getDataInfo(_request: Record<string, never>): TavernMethodResults['getDataInfo'] {
    return { dataHome: this.state.paths.root }
  }

  async getAvatar(request: { cardId: string }): Promise<TavernMethodResults['getAvatar']> {
    const charWs = await this.state.loadCharacter(request.cardId)
    if (!charWs) return { dataUrl: null }
    const ws = await this.state.workspace(request.cardId)
    // 指纹一致直接回缓存：一次 stat 代替全文读 + Base64 编码（指纹口径见 avatarCache 注释）。
    const info = await ws.fs.stat('card.png')
    const fingerprint = info ? `${info.mtimeMs}:${info.size}` : 'missing'
    const cached = this.avatarCache.get(request.cardId)
    if (cached && cached.fingerprint === fingerprint) return { dataUrl: cached.dataUrl }
    const bytes = info ? await ws.fs.readBytes('card.png') : null
    const dataUrl = bytes ? `data:image/png;base64,${Buffer.from(bytes).toString('base64')}` : null
    if (this.avatarCache.size >= AVATAR_CACHE_MAX && !this.avatarCache.has(request.cardId)) {
      const oldest = this.avatarCache.keys().next().value
      if (oldest !== undefined) this.avatarCache.delete(oldest)
    }
    this.avatarCache.set(request.cardId, { fingerprint, dataUrl })
    return { dataUrl }
  }

  private floorDeps() {
    return { ctx: this.ctx, state: this.state }
  }
}

export function createTavernService(ctx: Context, state: TavernState, settingsScope: TavernSettingsScope): TavernService {
  return new TavernService(ctx, state, settingsScope)
}
