/**
 * 预设请求投影：用公开用户消息的来源元数据持久化冻结布局，只在适配器副本中放置插件消息。
 * 宿主历史、附件、工具配对与日志均保持原值；锚点失效时明确拒绝，绝不按正文猜位置或复活压缩历史。
 */
import { createHash } from 'node:crypto'
import type { Context } from '@deepseek-ai/cordis'
import { createUserMessage, freezeMessage, MessageId, type GenerateOptions, type LlmResolvedModelInfo, type Message, type RequestMessage, type UserMessage } from '@deepseek-ai/dsh-llm'
import { deriveEventMessage, foldSurface, type Session, type SessionSeq } from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-agent-loop'
import type {} from '@deepseek-ai/dsh-compaction-basic'
import { joinContextSections } from '@deepseek-ai/dsh-system-prompt'
import { z } from 'zod'
import { BOUND_DISCIPLINE, TURN_PLAYBOOK, isRuntimeContextMessage, isWorkspaceInstructionMessage,
  stripHarnessIdentity, turnTailHeader } from '../core/dshPrompt.js'
import { PromptLayoutSchema, type PromptHistoryAnchor, type PromptLayout, type PromptLayoutEntry } from '../core/promptLayout.js'
import { assertNoControlTokens, mayContainControlTokens } from '../core/promptSafety.js'
import { estimateTokens } from '../core/tokenize.js'

export const PRESET_PLAN_MESSAGE_TEXT = '【Tavern 提示词布局快照】'

export interface PresetRequestPlan {
  version: 1
  sessionId: string
  turn: number
  layout: PromptLayout
  /** 宿主 tavern:standing 的完整已冻结文本，包含 BOUND_DISCIPLINE。 */
  standingText: string
  /** 宿主 tavern:turn 的完整已冻结文本，包含 TURN_PLAYBOOK。 */
  contextText: string
  /**
   * 缓存优先：本轮动态的历史前条目与全部深度注入改放到本轮输入之后，system 角色改由 user 承载。
   * 它们在 ST 位置上每轮变化或随历史增长移动，会让其后的整段历史失去前缀缓存。
   * 随计划冻结，同轮各步骤一致；旧计划缺省按原位置投影。
   */
  cacheFirst?: boolean
  /** 请求副本清理开关，随计划冻结；同轮中途改设置不改变后续步骤，旧计划缺省不清理。 */
  cleanup?: PresetRequestCleanup
}

export type PresetProjectionDiagnostic = {
  kind: 'compaction-clamp'
  messageId: string
  summaryMessageId: string
} | { kind: 'leading-system-only' } | { kind: 'messages-system-layout' } | {
  kind: 'request-cleanup'
  hideHarnessIdentity: boolean
  droppedWorkspaceInstructions: number
} | {
  kind: 'text-budget'
  beforeTextTokens: number
  afterTextTokens: number
  contextWindow?: number
  reservedOutputTokens: number
  availableTextTokens?: number
  exceedsAvailable: boolean
}

type ProjectionModel = Pick<LlmResolvedModelInfo, 'systemPromptUpdate' | 'context' | 'defaultMaxTokens'>

/** 请求副本清理：只影响这次发信，不改宿主历史、段注册与 Session 日志。 */
export interface PresetRequestCleanup {
  /** 从宿主 system 里删掉 `You are an AI agent powered by DeepSeek Harness.`，让预设独占扮演框架。 */
  hideHarnessIdentity?: boolean
  /** 剔除宿主注入的工作区指令（AGENTS.md 基线）user 消息；Tavern 会话里它与角色设定竞争。 */
  dropWorkspaceInstructions?: boolean
}

export interface PresetProjectionOptions {
  onDiagnostic?: (diagnostic: PresetProjectionDiagnostic) => void
  /** 未提供时只生成逻辑布局；真实适配器必须提供本次 prepareCall 冻结的模型能力。 */
  model?: ProjectionModel
  /** DeepSeek Messages 只允许 user/tool 之后、assistant 之前或请求末尾更新 system。 */
  messagesApi?: boolean
}

declare module '@deepseek-ai/dsh-llm' {
  interface MessageSourceMap {
    'tavern-prompt-plan': { kind: 'tavern-prompt-plan'; plan: PresetRequestPlan }
  }
}

// 来源元数据会经过磁盘与分支恢复；不能把 TypeScript 类型当作 JSON 校验。
const textSchema = z.string().max(2_000_000)
const planSchema = z.strictObject({ version: z.literal(1), sessionId: z.string().min(1).max(4096), turn: z.number().int().nonnegative(),
  standingText: textSchema.min(1), contextText: textSchema, cacheFirst: z.boolean().optional(),
  cleanup: z.strictObject({ hideHarnessIdentity: z.boolean().optional(), dropWorkspaceInstructions: z.boolean().optional() }).optional(),
  layout: PromptLayoutSchema })

function parsePlan(value: unknown): PresetRequestPlan {
  const result = planSchema.safeParse(value)
  if (!result.success) throw new Error(`Tavern 提示词布局快照无效：${result.error.issues[0]?.message ?? '未知格式'}`)
  // 分块计数避免先为超量布局分配一整份巨大 JSON 字符串。
  let bytes = Buffer.byteLength(JSON.stringify({ ...result.data, layout: { version: 1, history: [], entries: [] } }))
  for (const item of [...result.data.layout.history, ...result.data.layout.entries]) {
    bytes += Buffer.byteLength(JSON.stringify(item)) + 1
    if (bytes > 8 * 1024 * 1024) throw new Error('Tavern 提示词布局快照超过 8 MiB 上限')
  }
  if (bytes > 8 * 1024 * 1024) throw new Error('Tavern 提示词布局快照超过 8 MiB 上限')
  return result.data
}

/** 交给 pre-step 的正常接收批次；本函数不写日志、不自行注入或创建模型调用。 */
export function createPresetPlanMessage(plan: PresetRequestPlan): UserMessage {
  return createUserMessage({ source: { kind: 'tavern-prompt-plan', plan: parsePlan(plan) },
    content: [{ type: 'text', text: PRESET_PLAN_MESSAGE_TEXT }] })
}

/** 在宿主已接收的最后一条用户消息附加非正文元数据；不改身份、角色、来源 kind 或任何内容块。 */
export function attachPresetPlanMessage(message: UserMessage, plan: PresetRequestPlan): UserMessage {
  return freezeMessage({ ...message, source: { ...message.source, tavernPromptPlan: parsePlan(plan) } })
}

function planFromMessage(message: Message): PresetRequestPlan | undefined {
  const value = 'tavernPromptPlan' in message.source ? message.source.tavernPromptPlan
    : message.source.kind === 'tavern-prompt-plan' ? message.source.plan : undefined
  if (value === undefined) return undefined
  if (message.role !== 'user') throw new Error('Tavern 提示词布局载体必须是 user/message')
  return parsePlan(value)
}

/** 接收批次及已持久化日志共用的轮次判定；存在但损坏的元数据仍明确失败。 */
export function hasPresetPlanMessage(message: Message, sessionId: string, turn: number): boolean {
  const plan = planFromMessage(message)
  return plan !== undefined && plan.sessionId === sessionId && plan.turn === turn
}

/** 私有布局字段只属于持久化计划；适配器副本保留其余来源字段与原始内容块。 */
function stripPlanMetadata(message: Message): Message {
  if (message.role !== 'user' || !('tavernPromptPlan' in message.source)) return message
  const { tavernPromptPlan: _plan, ...source } = message.source
  return Object.freeze({ ...message, source: Object.freeze(source) })
}

function activeTurn(session: Session): number {
  for (const event of [...session.snapshotEvents()].reverse()) {
    if (event.type === 'turn/end') throw new Error('Tavern 提示词投影没有正在进行的轮次')
    if (event.type === 'turn/start') return event.data.turn
  }
  throw new Error('Tavern 提示词投影缺少 turn/start')
}

function currentPlan(messages: readonly Message[], session: Session): { plan: PresetRequestPlan; carrier: UserMessage } {
  const turn = activeTurn(session)
  const candidates: Message[] = [...messages].reverse()
  for (const event of [...session.snapshotEvents()].reverse()) {
    if (event.type === 'user/message') candidates.push(event.data)
  }
  for (const message of candidates) {
    const plan = planFromMessage(message)
    if (!plan || plan.sessionId !== session.id || plan.turn !== turn) continue
    return { plan, carrier: message as UserMessage }
  }
  throw new Error(`Tavern 第 ${turn} 轮缺少当前会话的冻结提示词布局；旧轮次计划不能复用，请开启下一轮`)
}

function plainText(message: Message): string {
  if (message.content.some(block => block.type !== 'text')) throw new Error('宿主提示词包含非文本块，不能安全替换 Tavern 段')
  return message.content.map(block => block.type === 'text' ? block.text : '').join('\n')
}

/** 只重写宿主声明的段；其它来源、图片、工具与模型 replayState 保留同一 Message 对象。 */
function hostMessages(messages: readonly Message[], plan: PresetRequestPlan): {
  messages: Message[]
  identityStripped: boolean
  /** 待剔除的工作区指令消息；定位与插入阶段仍保留，最终输出时才跳过，模板锚点不会因此失配。 */
  workspaceInstructions: ReadonlySet<Message>
} {
  const cleanup = plan.cleanup
  const systems = messages.filter(message => message.role === 'system'
    && message.source.kind === 'system-prompt')
  const latest = systems.at(-1)
  if (!latest) throw new Error('Tavern 请求缺少宿主完整 system 消息，不能安全投影预设')
  const systemText = plainText(latest)
  const at = systemText.indexOf(plan.standingText)
  if (at < 0 || at !== systemText.lastIndexOf(plan.standingText) || !plan.standingText.includes(BOUND_DISCIPLINE)) {
    throw new Error('Tavern standing 与冻结布局不匹配，不能安全移除旧段；请开启下一轮')
  }
  const replaced = systemText.slice(0, at) + BOUND_DISCIPLINE + systemText.slice(at + plan.standingText.length)
  const cleaned = cleanup?.hideHarnessIdentity === true ? stripHarnessIdentity(replaced) : replaced
  const cleanedSystem = freezeMessage({ ...latest, content: [{ type: 'text' as const, text: cleaned }] })
  const result: Message[] = [cleanedSystem]
  const workspaceInstructions = new Set<Message>()
  for (const original of messages) {
    if (original.source.kind === 'tavern-prompt-plan') continue
    const message = stripPlanMetadata(original)
    // 工作区指令是宿主以 user 消息注入的，不属于本轮对话，也不该和角色设定抢解释权。
    // 它仍在冻结历史里，可能是模板片段的锚点，因此只标记，由最终输出跳过。
    if (cleanup?.dropWorkspaceInstructions === true && isWorkspaceInstructionMessage(message)) {
      workspaceInstructions.add(message)
      result.push(message)
      continue
    }
    if (message.role === 'system' && message.source.kind === 'system-prompt') continue
    // runtime-context 的来源声明未由宿主包入口导出；校验真实数据，避免伪造模块类型。
    if (message.role === 'user') {
      const snapshot = z.object({ kind: z.literal('runtime-context'), form: z.literal('snapshot'),
        sections: z.array(z.object({ name: z.string(), text: z.string() })) }).safeParse(message.source)
      if (snapshot.success) {
        const sections = snapshot.data.sections.filter(section => section.name !== 'tavern:turn')
        if (sections.length === snapshot.data.sections.length) { result.push(message); continue }
        const text = joinContextSections(sections)
        if (text) result.push(freezeMessage({ ...message, source: { ...message.source, sections }, content: [{ type: 'text' as const, text }] }))
        continue
      }
    }
    result.push(message)
  }
  return { messages: result, identityStripped: cleaned !== replaced, workspaceInstructions }
}

function pluginMessage(plan: PresetRequestPlan, key: string, role: 'system' | 'user' | 'assistant', content: string): Message {
  const digest = createHash('sha256').update(JSON.stringify([plan.sessionId, plan.turn, key])).digest('hex')
  const fields = { id: MessageId(`tavern-prompt-${digest}`), content: [{ type: 'text' as const, text: content }] }
  // 仅存在于适配器请求副本；不追加 assistant/message，也不伪造模型历史或重放元数据。
  if (role === 'assistant') return freezeMessage({ ...fields, role, source: { kind: 'model', provider: 'tavern-preset', model: 'instruction', tavernProjection: true } })
  if (role === 'system') return freezeMessage({ ...fields, role, source: { kind: 'system-prompt', tavernProjection: true } })
  return freezeMessage({ ...fields, role, source: { kind: 'dsh-tavern', tavernProjection: true } })
}

/**
 * 宿主 system 必须留在首条。适配器靠"开头连续的 system"识别系统提示（pi-ai 的 splitSystemPrompt、
 * DeepSeek Messages 的 in-history 判定）；一旦被插件消息挤到历史中段，系统提示就被降级成普通
 * system 更新或历史消息——请求照样发得出去，行为却变了。这种偏移必须在投影时当场失败。
 */
function assertHostSystemLeading(original: readonly Message[], projected: readonly Message[]): void {
  const host = original[0]
  if (!host || host.role !== 'system' || host.source?.kind !== 'system-prompt') return
  if ('tavernProjection' in host.source) return
  if (projected[0] === host) return
  throw new Error('Tavern 提示词布局把宿主系统提示挤出了请求首条；已拒绝投影，避免适配器把系统提示降级成历史消息')
}

/** in-history 的每条 system 是完整快照；旧模型只读首条，因此不能直接发送增量 system 片段。 */
function applySystemPolicy(messages: readonly Message[], projection: PresetProjectionOptions): Message[] {
  if (!projection.model) return [...messages]
  const first = messages[0]
  if (!first || first.role !== 'system') throw new Error('Tavern 模型请求缺少首条完整系统提示')
  const systems = messages.filter(message => message.role === 'system')
  const sections: string[] = []
  let accumulatedBytes = 0, emittedBytes = 0
  const complete = (message: Message): Message => {
    const text = plainText(message)
    accumulatedBytes += Buffer.byteLength(text) + (sections.length ? 2 : 0)
    emittedBytes += accumulatedBytes
    // 逐项计数先于拼接，阻止第三方大量深度条目造成二次方输出分配。
    if (emittedBytes > 16 * 1024 * 1024) throw new Error('Tavern 完整系统提示快照累计超过 16 MiB，请减少深度 system 条目')
    sections.push(text)
    return freezeMessage({ ...message, content: [{ type: 'text' as const, text: sections.join('\n\n') }] })
  }
  let incompatiblePosition = false
  if (projection.messagesApi) {
    let previous: Message['role'] | undefined, pending = false
    for (const message of messages) {
      if (message.role === 'system') {
        if (previous !== undefined) {
          pending = true
          if (previous !== 'user' && previous !== 'tool') incompatiblePosition = true
        }
      } else {
        if (pending && message.role !== 'assistant') incompatiblePosition = true
        previous = message.role
        pending = false
      }
    }
  }
  if (incompatiblePosition) projection.onDiagnostic?.({ kind: 'messages-system-layout' })
  if (projection.model.systemPromptUpdate === 'in-history' && !incompatiblePosition) {
    const grouped: Message[] = []
    const isTavernSystem = (message: Message) => message.role === 'system'
      && 'tavernProjection' in message.source && message.source.tavernProjection === true
    for (let index = 0; index < messages.length;) {
      const message = messages[index++]!
      if (!isTavernSystem(message)) { grouped.push(message); continue }
      // 相邻自有 system 中间没有其它消息可改变位置；合成一条后再累计，避免重复整份 SDK。
      // 用组内首条的稳定派生 ID，不跨真实聊天或其它来源的 system，也不改变持久布局。
      const parts = [plainText(message)]
      let bytes = Buffer.byteLength(parts[0]!)
      while (index < messages.length && isTavernSystem(messages[index]!)) {
        const text = plainText(messages[index++]!)
        bytes += Buffer.byteLength(text) + 2
        if (bytes > 16 * 1024 * 1024) throw new Error('Tavern 完整系统提示超过 16 MiB')
        parts.push(text)
      }
      grouped.push(parts.length === 1 ? message : freezeMessage({ ...message,
        content: [{ type: 'text' as const, text: parts.join('\n\n') }] }))
    }
    return grouped.map(message => message.role === 'system' ? complete(message) : message)
  }
  if (systems.length > 1 && !incompatiblePosition) projection.onDiagnostic?.({ kind: 'leading-system-only' })
  // 只构造一次首条完整 system，避免模型忽略中途系统指令；其它角色的相对位置保持不变。
  let bytes = 0
  const parts = systems.map(message => {
    const text = plainText(message)
    bytes += Buffer.byteLength(text) + 2
    if (bytes > 16 * 1024 * 1024) throw new Error('Tavern 完整系统提示超过 16 MiB')
    return text
  })
  return [freezeMessage({ ...first, content: [{ type: 'text' as const, text: parts.join('\n\n') }] }),
    ...messages.filter(message => message.role !== 'system')]
}

/** 只估可见 text 块与旧式 system；图片、工具参数/结果编码及 provider framing 不在此估算内。 */
function requestTextTokens(options: Readonly<GenerateOptions>, messages: readonly RequestMessage[]): number {
  let tokens = options.system ? estimateTokens(options.system) : 0
  for (const message of messages) for (const block of message.content) {
    if (block.type === 'text') tokens += estimateTokens(block.text)
  }
  return tokens
}

interface ToolSpan { start: number; end: number; complete: boolean }

/** 一个 assistant 批次的全部结果都在保护范围内，防止在并行工具结果之间插入提示词。 */
function toolSpans(messages: readonly Message[]): ToolSpan[] {
  const spans: ToolSpan[] = []
  const pending = new Map<string, { span: ToolSpan; remaining: number }>()
  messages.forEach((message, index) => {
    const calls = message.content.filter(block => block.type === 'tool-call')
    if (calls.length) {
      const group = { span: { start: index, end: messages.length, complete: false }, remaining: calls.length }
      spans.push(group.span)
      for (const call of calls) {
        if (pending.has(call.id)) throw new Error('Tavern 请求含重复的未完成工具调用 ID，不能安全定位工具配对')
        pending.set(call.id, group)
      }
    }
    if (message.role === 'tool') {
      const group = pending.get(message.toolCallId)
      if (group) {
        pending.delete(message.toolCallId)
        group.remaining--
        if (group.remaining === 0) { group.span.end = index; group.span.complete = true }
      }
    }
  })
  return spans
}

/**
 * 缓存优先计划的本轮尾块：标题 + 按投影发射顺序的尾块条目（system 改由 user 承载）。
 * 当前轮与历史轮共用同一构造，历史轮重放与当轮实际发送逐字节一致，前缀缓存才能延续。
 */
function turnTailMessages(plan: PresetRequestPlan): Message[] {
  if (!plan.cacheFirst) return []
  const entries = plan.layout.entries
  const byKey = new Map(entries.map(entry => [entry.key, entry]))
  const inTail = (entry: PromptLayoutEntry): boolean => {
    let root: PromptLayoutEntry | undefined = entry
    for (let depth = 0; root?.placement.kind === 'entry-relative'; depth++) {
      if (depth >= 512) return false
      root = byKey.get(root.placement.entryKey)
    }
    const placement = root?.placement
    return placement !== undefined && (placement.kind === 'depth' || placement.kind === 'after-history'
      || (placement.kind === 'before-history' && root!.turnLocal))
  }
  const before = new Map<string, PromptLayoutEntry[]>(), after = new Map<string, PromptLayoutEntry[]>()
  for (const entry of entries) {
    if (entry.placement.kind !== 'entry-relative') continue
    const target = entry.placement.side === 'before' ? before : after
    const siblings = target.get(entry.placement.entryKey)
    if (siblings) siblings.push(entry)
    else target.set(entry.placement.entryKey, [entry])
  }
  const out: Message[] = []
  const emit = (entry: PromptLayoutEntry, depth = 0): void => {
    if (depth >= 512) throw new Error('Tavern 模板插入位置嵌套超过 512 层')
    for (const child of before.get(entry.key) ?? []) emit(child, depth + 1)
    if (inTail(entry) && entry.content.trim()) out.push(pluginMessage(plan, entry.key, entry.role === 'system' ? 'user' : entry.role, entry.content))
    for (const child of after.get(entry.key) ?? []) emit(child, depth + 1)
  }
  for (const entry of entries) if (entry.placement.kind !== 'entry-relative') emit(entry)
  return out.length ? [pluginMessage(plan, 'host:turn-tail-header', 'user', turnTailHeader(plan.turn)), ...out] : []
}

/** 适配器边界的唯一变换：返回新请求，原请求和 Session 永远不被修改。 */
export function projectPresetRequest(options: Readonly<GenerateOptions>, session: Session, projection: PresetProjectionOptions = {}): GenerateOptions {
  if (options.purpose) return { ...options, messages: [...options.messages] }
  if (!options.sessionId || options.sessionId !== session.id) throw new Error('Tavern 请求与会话身份不匹配')
  const requestMessages = options.messages.map(message => {
    if (message.id === undefined || message.source === undefined) throw new Error('Tavern 普通聊天请求缺少持久消息身份，不能投影预设')
    return message
  })
  const { plan, carrier } = currentPlan(requestMessages, session)
  const entries = plan.layout.entries
  // 冻结期已拦过一次；这里兜住旧布局、手写计划与外部写入的正文。
  // 投影副本一样会进请求，不能因为"只是副本"就放行。
  for (const entry of entries) {
    if (mayContainControlTokens(entry.content)) assertNoControlTokens(entry.content, `Tavern 布局条目 ${entry.key}（${entry.role}）`)
  }
  if (entries.some(entry => entry.compatibilityFallback)) throw new Error('Tavern 冻结布局缺少模板精确位置，不能用于真实请求；请修订模板后开启下一轮')
  const host = hostMessages(requestMessages, plan)
  const messages = host.messages
  if (host.identityStripped || host.workspaceInstructions.size > 0) {
    projection.onDiagnostic?.({ kind: 'request-cleanup', hideHarnessIdentity: host.identityStripped,
      droppedWorkspaceInstructions: host.workspaceInstructions.size })
  }
  const positions = new Map<string, number>()
  messages.forEach((message, index) => {
    if (positions.has(message.id)) throw new Error('Tavern 请求消息 ID 重复，不能可靠定位历史')
    positions.set(message.id, index)
  })
  const anchors = new Map<number, PromptHistoryAnchor>()
  for (const anchor of plan.layout.history) {
    if (anchors.has(anchor.inputIndex)) throw new Error('Tavern 布局历史 inputIndex 重复')
    anchors.set(anchor.inputIndex, anchor)
  }
  // 只沿宿主真实 surface replacement 的被覆盖集合追踪身份；额外 source 引用不能伪装为替换关系。
  const events = session.snapshotEvents()
  const eventBySeq = new Map(events.map(event => [event.seq, event]))
  const seqByMessageId = new Map<string, SessionSeq>()
  for (const event of events) {
    const message = deriveEventMessage(event)
    if (message) seqByMessageId.set(message.id, event.seq)
  }
  const replacements = new Map<SessionSeq, SessionSeq>()
  for (const replacement of foldSurface(events).replacements) {
    for (const seq of replacement.shadowedSeqs) replacements.set(seq, replacement.seq)
  }
  const surfaceNodes = new Set(session.surface.nodes)
  const reported = new Set<string>()
  const located = new Map<number, { index: number; compacted: boolean }>()
  const locate = (anchor: PromptHistoryAnchor): { index: number; compacted: boolean } => {
    const original = anchors.get(anchor.inputIndex)
    if (!original || original.messageId !== anchor.messageId || original.role !== anchor.role || original.chat !== anchor.chat) {
      throw new Error('Tavern 布局锚点不属于冻结历史')
    }
    const cached = located.get(anchor.inputIndex)
    if (cached) return cached
    const index = anchor.messageId === undefined ? undefined : positions.get(anchor.messageId)
    if (index !== undefined) {
      if (messages[index]?.role !== anchor.role) throw new Error('Tavern 历史锚点角色已变化')
      const result = { index, compacted: false }
      located.set(anchor.inputIndex, result)
      return result
    }
    let seq = anchor.messageId === undefined ? undefined : seqByMessageId.get(anchor.messageId)
    while (seq !== undefined && replacements.has(seq)) {
      const replacementSeq = replacements.get(seq)!
      const event = eventBySeq.get(replacementSeq)
      // 官方压缩检查点来源固定 compact-checkpoint；编辑、删除、任意 producer 的替换不能按摘要放宽。
      if (!event || event.type !== 'user/message' || event.data.source.kind !== 'compact-checkpoint') break
      const summaryIndex = positions.get(event.data.id)
      if (summaryIndex !== undefined && surfaceNodes.has(replacementSeq)) {
        if (!reported.has(anchor.messageId!)) {
          reported.add(anchor.messageId!)
          projection.onDiagnostic?.({ kind: 'compaction-clamp', messageId: anchor.messageId!, summaryMessageId: event.data.id })
        }
        const result = { index: summaryIndex, compacted: true }
        located.set(anchor.inputIndex, result)
        return result
      }
      seq = replacementSeq
    }
    throw new Error('Tavern 历史锚点已缺失且没有合法压缩映射；不会恢复旧正文，请开启下一轮')
  }
  // 载体在首次接收批次末尾：后续工具步骤保留在它之后，尾条绝不重新附到工具结果之后。
  const carrierIndex = requestMessages.findIndex(message => message.id === carrier.id)
  /** 某条载体所在输入批次之后的边界（历史轮与本轮同一算法，覆盖同批次紧随其后的 runtime-context）。 */
  const frontierAt = (index: number): number => {
    let batchEnd = index
    while (requestMessages[batchEnd + 1] && isRuntimeContextMessage(requestMessages[batchEnd + 1]!)) batchEnd++
    let end = 1
    for (const message of requestMessages.slice(0, batchEnd + 1)) {
      const at = positions.get(message.id)
      if (at !== undefined) end = Math.max(end, at + 1)
    }
    return end
  }
  let frontierEnd: number | undefined
  const frontier = (): number => {
    if (frontierEnd !== undefined) return frontierEnd
    if (carrierIndex < 0) throw new Error('Tavern 首次输入边界已被压缩，不能重排本轮尾条；请开启下一轮')
    frontierEnd = frontierAt(carrierIndex)
    return frontierEnd
  }
  const spans = toolSpans(messages)
  const safeGaps = { before: new Map<number, number>(), after: new Map<number, number>() }
  const safeGap = (gap: number, side: 'before' | 'after'): number => {
    const cached = safeGaps[side].get(gap)
    if (cached !== undefined) return cached
    let result = gap
    for (const span of spans) {
      if (span.start < result && result <= span.end) {
        if (!span.complete) throw new Error('Tavern 提示词位置穿过未完成的工具调用，拒绝拆开工具配对')
        result = side === 'before' ? span.start : span.end + 1
      }
    }
    safeGaps[side].set(gap, result)
    return result
  }
  const byKey = new Map<string, PromptLayoutEntry>()
  for (const entry of entries) {
    if (byKey.has(entry.key)) throw new Error('Tavern 冻结布局条目 key 重复')
    byKey.set(entry.key, entry)
  }
  // entry-relative 跟随其目标，位置判定一律看链条根部条目。
  const rootEntry = (entry: PromptLayoutEntry): PromptLayoutEntry | undefined => {
    let current: PromptLayoutEntry | undefined = entry
    for (let depth = 0; current?.placement.kind === 'entry-relative'; depth++) {
      if (depth >= 512) return undefined
      current = byKey.get(current.placement.entryKey)
    }
    return current
  }
  // 缓存优先只移动每轮变化或随历史增长漂移的条目。
  const movesToTail = (entry: PromptLayoutEntry): boolean => {
    const root = plan.cacheFirst ? rootEntry(entry) : undefined
    return root !== undefined && (root.placement.kind === 'depth' || (root.placement.kind === 'before-history' && root.turnLocal))
  }
  // 本轮尾块：移来的条目与原本就在历史后的条目，都位于本轮输入之后。
  const inTurnTail = (entry: PromptLayoutEntry): boolean => movesToTail(entry)
    || (plan.cacheFirst === true && rootEntry(entry)?.placement.kind === 'after-history')
  const gaps = new Map<string, number>()
  const resolving = new Set<string>()
  const gapFor = (entry: PromptLayoutEntry): number => {
    const cached = gaps.get(entry.key)
    if (cached !== undefined) return cached
    if (resolving.has(entry.key)) throw new Error('Tavern 模板插入位置出现循环引用')
    if (resolving.size >= 512) throw new Error('Tavern 模板插入位置嵌套超过 512 层')
    resolving.add(entry.key)
    const placement = entry.placement
    let gap: number
    if (placement.kind !== 'entry-relative' && movesToTail(entry)) {
      gap = safeGap(frontier(), 'after')
      resolving.delete(entry.key)
      gaps.set(entry.key, gap)
      return gap
    }
    switch (placement.kind) {
      case 'entry-relative': {
        const target = byKey.get(placement.entryKey)
        if (!target) throw new Error('Tavern 模板插入目标不存在')
        gap = gapFor(target)
        break
      }
      case 'before-history': gap = placement.anchor ? safeGap(locate(placement.anchor).index, 'before') : 1; break
      case 'after-history': {
        if (placement.anchor) locate(placement.anchor)
        gap = safeGap(frontier(), 'after'); break
      }
      case 'history-relative': gap = safeGap(locate(placement.anchor).index + (placement.side === 'after' ? 1 : 0), placement.side); break
      case 'depth': {
        const previous = placement.previous ? locate(placement.previous) : undefined
        const next = placement.next ? locate(placement.next) : undefined
        if (previous !== undefined && next !== undefined && previous.index >= next.index) {
          if (previous.index !== next.index || !previous.compacted || !next.compacted) throw new Error('Tavern 冻结历史锚点顺序已变化')
          gap = safeGap(next.index + 1, 'after')
        } else gap = next !== undefined ? safeGap(next.index, 'before') : safeGap(frontier(), 'after')
        break
      }
    }
    resolving.delete(entry.key)
    gaps.set(entry.key, gap)
    return gap
  }
  for (const entry of entries) gapFor(entry)
  const slots = new Map<number, Message[]>()
  // 大量条目常共享一个尾部边界；只追加本次投影自有数组，避免反复复制造成平方级分配。
  const append = (gap: number, message: Message) => {
    const slot = slots.get(gap)
    if (slot) slot.push(message)
    else slots.set(gap, [message])
  }
  const firstChat = plan.layout.history.find(anchor => anchor.chat)
  const playbookGap = firstChat ? safeGap(locate(firstChat).index, 'before') : 1
  append(playbookGap, pluginMessage(plan, 'host:turn-playbook', 'system', TURN_PLAYBOOK))
  const before = new Map<string, PromptLayoutEntry[]>(), after = new Map<string, PromptLayoutEntry[]>()
  for (const entry of entries) {
    if (entry.placement.kind !== 'entry-relative') continue
    const target = entry.placement.side === 'before' ? before : after
    const siblings = target.get(entry.placement.entryKey)
    if (siblings) siblings.push(entry)
    else target.set(entry.placement.entryKey, [entry])
  }
  const emit = (entry: PromptLayoutEntry, depth = 0): void => {
    if (depth >= 512) throw new Error('Tavern 模板插入位置嵌套超过 512 层')
    for (const child of before.get(entry.key) ?? []) emit(child, depth + 1)
    // 尾块条目由 turnTailMessages 统一构造（system 改由 user 承载），这里只放其余条目。
    if (entry.content.trim() && !inTurnTail(entry)) append(gapFor(entry), pluginMessage(plan, entry.key, entry.role, entry.content))
    for (const child of after.get(entry.key) ?? []) emit(child, depth + 1)
  }
  // 尾块会并入玩家输入所在的 user 轮；标题与非 DeepSeek 通道一致，标明其后是系统材料。
  const currentTail = turnTailMessages(plan)
  if (currentTail.length) {
    const gap = safeGap(frontier(), 'after')
    for (const message of currentTail) append(gap, message)
  }
  // 历史轮尾块原位重放：DeepSeek 的前缀缓存覆盖上一轮请求及其生成内容（思考、工具调用、回复）。
  // 丢掉旧尾块会让前缀断在上一轮输入之后，其后的回复与工具结果每轮全价重付。
  // 载体已被压缩的轮次不再重放；元数据损坏只放弃这一轮的缓存重放，不阻断当前请求。
  if (plan.cacheFirst) {
    const replayed = new Set([`${plan.sessionId}\u0000${plan.turn}`])
    requestMessages.forEach((message, index) => {
      if (index === carrierIndex) return
      let past: PresetRequestPlan | undefined
      try { past = planFromMessage(message) } catch { return }
      if (!past?.cacheFirst) return
      const key = `${past.sessionId}\u0000${past.turn}`
      if (replayed.has(key)) return
      replayed.add(key)
      const tail = turnTailMessages(past)
      if (!tail.length) return
      const gap = safeGap(frontierAt(index), 'after')
      for (const tailMessage of tail) append(gap, tailMessage)
    })
  }
  for (const entry of entries) if (entry.placement.kind !== 'entry-relative') emit(entry)
  const projected: Message[] = []
  for (let index = 0; index <= messages.length; index++) {
    projected.push(...(slots.get(index) ?? []))
    const message = messages[index]
    // 剔除的工作区指令只在此处跳过：锚在它前后的条目已按原间隙落位，顺序不变。
    if (message && !host.workspaceInstructions.has(message)) projected.push(message)
  }
  assertHostSystemLeading(messages, projected)
  const effective = applySystemPolicy(projected, projection)
  if (projection.model) {
    const contextWindow = projection.model.context?.contextWindow
    const reservedOutputTokens = options.maxTokens ?? projection.model.defaultMaxTokens ?? 0
    const availableTextTokens = contextWindow === undefined ? undefined : Math.max(0, contextWindow - reservedOutputTokens)
    const afterTextTokens = requestTextTokens(options, effective)
    projection.onDiagnostic?.({ kind: 'text-budget', beforeTextTokens: requestTextTokens(options, options.messages), afterTextTokens,
      ...(contextWindow === undefined ? {} : { contextWindow, availableTextTokens }), reservedOutputTokens,
      exceedsAvailable: availableTextTokens !== undefined && afterTextTokens > availableTextTokens })
  }
  return { ...options, messages: effective }
}

/** 从当前 SessionStore 读取当前轮日志；注册适配器无需捕获角色资产或可变预设状态。 */
export function createPresetRequestProjector(ctx: Pick<Context, 'sessions'>, projection: Omit<PresetProjectionOptions, 'model'> = {}): {
  project(options: Readonly<GenerateOptions>, model: ProjectionModel): GenerateOptions
} {
  return { project(options, model) {
    if (options.purpose) return { ...options, messages: [...options.messages] }
    const session = options.sessionId ? ctx.sessions.get(options.sessionId) : undefined
    if (!session) throw new Error('Tavern 请求找不到当前 Session，不能读取冻结提示词布局')
    return projectPresetRequest(options, session, { ...projection, model, messagesApi: true })
  } }
}
