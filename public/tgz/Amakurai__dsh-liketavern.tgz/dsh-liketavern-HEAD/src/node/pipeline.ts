/**
 * 组装管线：绑定 + 工作区 + 预设 + 世界书/记忆/变化层 + 正则 → AssembledPrompt。
 *
 * 世界书引擎按「每 turn 只评估一次」使用（定时器以消息数为单位，多步 turn 内复用缓存），
 * 只有每轮首次评估（live 模式）才持久化新的定时状态——经 WorkspaceFs 写入，
 * 因而落入当前楼层 WAL，可随回退/swipe 回滚。
 * preview（预览提示词 / 代答）用空定时器评估，既不读也不写该缓存，见下方 cacheable。
 * 首次成功组装后冻结整轮计划；每步仍把同一份 standing/turn 安装到宿主组装结果，
 * 遗忘则按条用工具补读，而不是跳过组装。
 */
import type { Agent } from '@deepseek-ai/dsh-agent'
import type { LlmRuntime, Message } from '@deepseek-ai/dsh-llm'
import { defaultPreset, type AssembledPrompt } from '../core/assemble.js'
import { BOUND_DISCIPLINE, TURN_PLAYBOOK, isSyntheticUserText, turnTailHeader } from '../core/dshPrompt.js'
import { hashToSeed } from '../core/macros.js'
import { memoryCandidateCount, memoryQuery, memorySearchOptions, selectMemoryBodies } from '../core/memoryRetrieval.js'
import { clipToTokenBudget, estimateTokens } from '../core/tokenize.js'
import type { ChatMessage, WIEngineResult, WorldDelta, WorldInfoEntry } from '../core/types.js'
import { EMPTY_TIMER_STATE } from '../core/types.js'
import { isolated } from './isolated.js'
import { stableFingerprintHash, standingFingerprint } from '../core/standingPin.js'
import { resolvePresetSampling } from '../core/presetSampling.js'
import type { PromptLayout } from '../core/promptLayout.js'
import { DEFAULT_USER_NAME } from '../core/persona.js'
import { parseLorebook } from '../state/lorebook.js'
import { withWorkspaceLock } from '../state/workspaceLock.js'
import { loadTemplateState, saveTemplateState } from '../state/template.js'
import { loadHelperState } from '../state/helper.js'
import { latestTemplateHelperMvu, projectTemplateHelperMvu } from '../core/templateHelperMvu.js'
import { currentHelperMvuTemplateData } from './helperMvuTemplateSnapshot.js'
import { templateGenerationContext, type PreparedTemplateGeneration } from '../state/templateGeneration.js'
import { type TemplateContext } from '../core/template.js'
import { templateCardData } from '../core/templateAssets.js'
import { characterPromptName } from '../core/characterData.js'
import { normalizeTemplateLore } from '../core/templateLore.js'
import { assertTemplateReplayFormatter, type TemplateReplay } from '../core/templateReplay.js'
import { buildTemplateMessageHistory } from './templateMessageHistory.js'
import { mergeTemplateMessageVariables, visibleTemplateMessageVariables, type TemplateMessageIdentity } from '../core/templateMessageVariables.js'
import { loadTemplateAvatars } from './templateAvatar.js'
import { resolveTemplateContinuation } from '../state/templateContinuation.js'
import { sessionModelRoute, type SessionModelRoute } from './modelRoute.js'
import { chatPickSeed } from '../core/binding.js'
import type { TavernState } from './state.js'

const FALLBACK_CONTEXT_WINDOW = 131072
const FALLBACK_RESERVE_OUTPUT = 8192

export interface PipelineInput {
  state: TavernState
  sessionId: string
  /** 会话历史来源；preview 模式可传 null 并给 historyOverride。 */
  agent: Agent | null
  /** 用于解析上下文窗口；缺失或解析失败回退 128K。 */
  llm?: LlmRuntime
  mode: 'live' | 'preview'
  /** preview 且无 live agent 时的历史（纯文本）。 */
  historyOverride?: ChatMessage[]
  /**
   * ST 生成场景（injection_trigger 评估），缺省 'normal'。
   * 续写轮由 agent 面探测合成续写指令后传 'continue'；impersonate 传 'impersonate'。
   */
  generationType?: string
}

export interface PipelineResult {
  /** 首次组装的布局偏好；旧持久计划缺省保留原位置，不读取升级后的当前设置。 */
  cacheFirstLayout?: boolean
  /** 本轮冻结的模板输入；回复处理只使用这份资产与时钟快照。 */
  templateContext?: TemplateContext
  templateReplay?:TemplateReplay
  standingKey: string
  sampling: import('../core/types.js').SamplingSettings
  /** 角色定义 + 预设骨架（写入 system 段，绑定不变则字节级稳定）。 */
  standing: string
  /** 本轮世界书/记忆/变化层（写入 runtime context，不进 system 前缀）。 */
  turnContext: string
  /** standing + turnContext（预览用）。 */
  system: string
  /** ST 语义全量序列（预览用）。 */
  messages: ChatMessage[]
  /** 已冻结的预设布局；真实历史由适配器按消息身份保留。 */
  layout?: PromptLayout
  /** 入模历史（经正则与预算裁剪后）。 */
  history: ChatMessage[]
  assembled: AssembledPrompt
  logLines: string[]
  /** 当前 {{user}} 展示名；改名后须打穿 standing 钉死。 */
  userName: string
  personaDescription: string
  personaLorebookId: string | null
  wiBudget: { limit: number; used: number; overflowed: boolean }
}

/** deriveMessages 拍平：只取 text 块拼成纯文本；空消息丢弃。 */
export function flattenMessages(messages: readonly Message[], charName: string, userName: string): ChatMessage[] {
  const out: ChatMessage[] = []
  for (const m of messages) {
    if (m.role === 'tool' || m.role === 'developer') continue
    const text = m.content
      .filter((b): b is { type: 'text'; text: string } => b.type === 'text')
      .map((b) => b.text)
      .join('\n')
    if (!text.trim()) continue
    const name = m.role === 'assistant' ? charName : m.role === 'user' ? userName : undefined
    out.push({ role: m.role, content: text, ...(name ? { name } : {}) })
  }
  return out
}

/** 解析模型上下文窗口；任何失败都回退默认值。元数据经 TavernState 进程内缓存，每步调用不重复解析。 */
async function resolveContextWindow(input: PipelineInput, route: SessionModelRoute): Promise<number> {
  const { provider, model } = route
  if (!input.llm || !provider || !model) return FALLBACK_CONTEXT_WINDOW
  try {
    const info = await input.state.resolveModelInfoCached(input.llm, provider, model)
    return info.context?.contextWindow ?? FALLBACK_CONTEXT_WINDOW
  } catch {
    return FALLBACK_CONTEXT_WINDOW
  }
}

export async function loadBoundLoreEntries(state: TavernState, binding: NonNullable<Awaited<ReturnType<TavernState['loadBinding']>>>): Promise<{ entries: WorldInfoEntry[]; deltas: WorldDelta[] }> {
  const ws = await state.storyWorkspace(binding.cardId, binding.storyId)
  const groups: WorldInfoEntry[][] = []

  // 全局世界书
  for (const id of binding.lorebookIds) {
    groups.push(await state.loadLorebookEntries(id, 'global'))
  }
  // 主世界书（Character Lore）：绑定指定库文件 > 卡内嵌书（card.json / assets/character-book.json）
  if (binding.characterLorebookId) {
    groups.push(await state.loadLorebookEntries(binding.characterLorebookId, 'character'))
  } else if(binding.useEmbeddedLorebook!==false) {
    const embedded = await state.loadCharacterLorebookRaw(binding.cardId)
    if (embedded) groups.push(parseLorebook(embedded.json, { source: 'character', sourceRef: binding.cardId }))
  }
  for(const id of new Set(binding.characterLorebookIds??[])){
    if(id!==binding.characterLorebookId)groups.push(await state.loadLorebookEntries(id,'character'))
  }
  // 聊天世界书（会话级，存工作区）
  const chatRaw = await ws.fs.readText('assets/chat-lorebook.json')
  if (chatRaw !== null) {
    try {
      groups.push(parseLorebook(JSON.parse(chatRaw), { source: 'chat', sourceRef: 'chat-lorebook' }))
    } catch {
      // 坏文件跳过
    }
  }
  // 人设世界书
  const persona = await state.resolvePersona(binding.personaId)
  if (persona?.lorebookId) {
    groups.push(await state.loadLorebookEntries(persona.lorebookId, 'persona'))
  }

  const base = groups.flat()
  // 变化层：ref 的 order 解析先查 character 条目，再查其余
  const deltas = await ws.deltas.list()
  const resolveRefOrder = (ref: string): number | null => {
    const bySource = (source: WorldInfoEntry['source']) => base.find((e) => e.source === source && e.uid === ref)?.order
    return bySource('character') ?? base.find((e) => e.uid === ref)?.order ?? null
  }
  const deltaEntries = ws.deltas.toEngineEntries(deltas, resolveRefOrder)
  return { entries: [...base, ...deltaEntries], deltas }
}

/** 组装一次 Tavern 提示词。绑定缺失或角色不存在时返回 null。 */
export async function runTavernPipeline(input: PipelineInput): Promise<PipelineResult | null> {
  await input.state.waitForSessionTasks(input.sessionId)
  const binding = await input.state.loadBinding(input.sessionId)
  if (!binding) return null
  const ws = await input.state.storyWorkspace(binding.cardId, binding.storyId)
  return withWorkspaceLock(ws.fs.root, () => runTavernPipelineLocked(input, binding))
}

async function runTavernPipelineLocked(input: PipelineInput, expected: { cardId: string; storyId?: string }): Promise<PipelineResult | null> {
  const { state, sessionId } = input
  // turn/start 的监听器异步开 WAL；提示词/工具热路径必须等它完成后才能产生工作区写入。
  const binding = await state.loadBinding(sessionId)
  if (!binding) return null
  if (binding.cardId !== expected.cardId || binding.storyId !== expected.storyId) throw new Error('组装排队期间剧情绑定已变化')
  const activeTurn = state.currentTurns.get(sessionId)
  const openFloor = state.openFloors.get(sessionId)
  if (input.mode === 'live' && openFloor && (activeTurn === undefined || openFloor.floor !== `${sessionId}#t${activeTurn}`)) {
    throw new Error('提示词楼层与当前轮次不一致，请先恢复上一楼层提交')
  }
  const previous = state.turnPlans.get(sessionId)
  if (input.mode === 'live' && activeTurn !== undefined && previous?.turn === activeTurn) {
    if (previous.cardId !== binding.cardId || previous.storyId !== binding.storyId) throw new Error('生成期间绑定已变化，请在下一轮继续')
    return previous.result
  }
  const pendingPlan = state.pendingTurnPlans.get(sessionId)
  if (input.mode === 'live' && pendingPlan) {
    if (activeTurn === pendingPlan.turn) {
      if (pendingPlan.cardId !== binding.cardId || pendingPlan.storyId !== binding.storyId) throw new Error('生成期间绑定已变化，请在下一轮继续')
      return pendingPlan.publish()
    }
    state.pendingTurnPlans.delete(sessionId)
  }
  const ws = await state.storyWorkspace(binding.cardId, binding.storyId)
  const templateState = await loadTemplateState(ws.fs)
  const generation = templateState.generation
  if (input.mode==='live' && generation?.sessionId===sessionId && generation.cardId===binding.cardId && generation.storyId===binding.storyId) {
    let recoveryTurn = activeTurn
    if (recoveryTurn===undefined && generation.status==='prepared') {
      const events = input.agent?.session.snapshotEvents()
      const last = events && [...events].reverse().find(event=>event.type==='turn/start'||event.type==='turn/end')
      if (last?.type!=='turn/start' || last.data.turn!==generation.turn) throw new Error('模板计划等待恢复：请先完成当前宿主轮次，不能重新执行已提交模板')
      recoveryTurn = last.data.turn
    }
    if (recoveryTurn===generation.turn) {
      if (generation.status!=='prepared') throw new Error('该轮模板已经结束，请开启新一轮，不能重复执行')
      assertTemplateReplayFormatter(generation.replay)
      const floor = await ws.wal.validateFloor(generation.floor)
      if (floor.committed) throw new Error('模板计划恢复缺少未提交的原剧情楼层')
      const open = state.openFloors.get(sessionId)
      if (open && (open.cardId!==binding.cardId || open.storyId!==binding.storyId || open.floor!==generation.floor)) throw new Error('模板计划恢复的剧情楼层冲突')
      const restored = restorePipelineResult(generation)
      state.currentTurns.set(sessionId,generation.turn)
      state.openFloors.set(sessionId,{cardId:generation.cardId,storyId:generation.storyId,floor:generation.floor})
      state.turnPlans.set(sessionId,{turn:generation.turn,cardId:generation.cardId,storyId:generation.storyId,result:restored})
      return restored
    }
  }
  const charWs = await state.loadCharacter(binding.cardId)
  if (!charWs) return null
  const card = charWs.card
  const charName = characterPromptName(card)

  const preset = (binding.presetId ? await state.loadPreset(binding.presetId) : null) ?? defaultPreset()
  const persona = await state.resolvePersona(binding.personaId)
  const userName = persona?.name ?? DEFAULT_USER_NAME
  // 修订号可能在上述异步读取期间更新；实际已读取资产的内容才是这份快照的身份。
  // 加入正文指纹后，旧正文与新修订号即使同时出现，也不会挡住下一轮的新正文；图片不参与组装。
  const { pngBytes: _png, ...promptCard } = card
  const standingKey = standingFingerprint(binding, { name: userName, description: persona?.description ?? '' },
    [...state.standingRevTags(binding, { personaLorebookId: persona?.lorebookId ?? null }),
      `snapshot=${stableFingerprintHash({ card: promptCard, preset, persona })}`], input.generationType ?? 'normal')
  const hostMessages = input.agent?.session.deriveMessages() ?? []
  const hostHistory = hostMessages.flatMap(message => {
    if (message.role === 'tool' || message.role === 'developer') return []
    const text = flattenMessages([message], card.name, userName)[0]
    // 无文字图片仍是一条聊天消息，深度计算不能把它吞掉。
    const chat = text ?? (message.content.some(block => block.type === 'image')
      ? { role: message.role, content: '', name: message.role === 'assistant' ? card.name : userName } : undefined)
    return chat ? [{ chat, id: String(message.id), counted: message.source.kind === 'user' || message.source.kind === 'model' }] : []
  }).filter(({ chat }) => !(chat.role === 'user' && isSyntheticUserText(chat.content)))
  const rawHistory = input.agent ? hostHistory.map(item => item.chat) : (input.historyOverride ?? [])
  const history = rawHistory.filter((m) => !(m.role === 'user' && isSyntheticUserText(m.content)))

  // 待入日志的本轮输入：去重（已入日志的不再追加）。同轮第 2 步起 history 末条已是
  // assistant，只比末条会把已入日志的输入重复追加到扫描尾部——pending 按插入顺序落在
  // history 尾部，取尾部最多 pending 条数的 user 消息逐条抵消（同文本连发也只抵消
  // 已入日志的条数）。合成 user 文本（runtime context 快照、同轮写入确认、续写指令）
  // 不经 inbox 也进不了 {{lastusermessage}} 与世界书扫描——它们不是用户台词。
  const pending = (state.pendingInputs.get(sessionId) ?? []).filter((t) => !isSyntheticUserText(t))
  const identifiedPending = (state.pendingTemplateInputs.get(sessionId) ?? []).filter(item => !isSyntheticUserText(item.text))
  const havePendingIds = identifiedPending.length === pending.length && identifiedPending.every((item, index) => item.text === pending[index])
  const visibleIds = new Set(hostMessages.map(message => String(message.id)))
  const freshIdentified = identifiedPending.filter(item => !visibleIds.has(item.id))
  const pendingFresh = havePendingIds ? freshIdentified.map(item => item.text) : [...pending]
  let scannedUsers = 0
  for (let i = history.length - 1; !havePendingIds && i >= 0 && pendingFresh.length > 0 && scannedUsers < pending.length; i--) {
    const message = history[i]!
    if (message.role !== 'user') continue
    scannedUsers++
    const at = pendingFresh.lastIndexOf(message.content)
    if (at >= 0) pendingFresh.splice(at, 1)
  }
  const scanMessages: ChatMessage[] = [
    ...history,
    ...pendingFresh.map((content) => ({ role: 'user' as const, content, name: userName })),
  ]
  const chatFlags = [...history.map((message,index) => input.agent ? hostHistory[index]?.counted === true : message.role !== 'system'),
    ...pendingFresh.map((_, index) => !havePendingIds || freshIdentified[index]?.chat !== false)]
  // 插件来源可保留为显式模板索引，但不能触发角色世界书或冒充最后一句台词。
  const chatMessages = scanMessages.filter((_,index) => chatFlags[index])
  const messageProjection=input.agent ? buildTemplateMessageHistory(input.agent.session.deriveMessages(),
    state.pendingTemplateInputs.get(sessionId) ?? [],card.name,userName,input.agent.session.snapshotEvents?.() ?? []) : undefined
  const templateHistory=messageProjection?.history ?? scanMessages
  const historyIdentities:TemplateMessageIdentity[]=messageProjection?.identities ?? templateHistory.map((_,index)=>({
    messageId:`preview:${sessionId}:${state.currentTurns.get(sessionId) ?? -1}:${index}`,swipeId:0,
  }))
  // 使用宿主真实可见身份；无身份的纯文本预览不能猜测消息对应关系或读入其它剧情数据。
  let helperMvu: TemplateContext['helperMvu']
  if(messageProjection && binding.helperMvu===true && state.config.interactiveCards && binding.interactiveCards!==false) {
    const helper = await loadHelperState(ws.fs)
    const current = currentHelperMvuTemplateData(input.agent!.session.snapshotEvents(),helper.scopes)
    if(current !== undefined) helperMvu = projectTemplateHelperMvu(helper.scopes,historyIdentities,current)
  }
  const lastUserMessage = [...chatMessages].reverse().find((m) => m.role === 'user')?.content ?? ''
  const config = state.config
  const cacheFirstLayout = config.prompts.cacheFirstLayout
  const sampling = resolvePresetSampling(config.sampling, preset.sampling)
  // 会话内换模不回写 agent.options；窗口与模板 model 取会话最近实际路由。
  const route = input.agent ? sessionModelRoute(input.agent) : {}
  const contextWindow = await resolveContextWindow(input, route)
  const turn = state.currentTurns.get(sessionId) ?? -1
  const turnSeed = hashToSeed(`${sessionId}:${turn}`)
  const macroCtx = {
    char: charName,
    user: userName,
    pickSeed: chatPickSeed(binding),
    lastUserMessage,
    lastMessage: [...chatMessages].reverse().find(message => message.role === 'assistant'
      || (message.role === 'user' && !isSyntheticUserText(message.content)))?.content ?? '',
    charPrompt: config.prompts.preferCharacterPrompt ? card.systemPrompt : '',
    charInstruction: config.prompts.preferCharacterInstructions ? card.postHistoryInstructions : '',
    now: new Date(),
    readonlyStatData: latestTemplateHelperMvu(helperMvu,historyIdentities),
  }

  // ── WI / 记忆 / 变化层：每 turn 评估一次并缓存 ──
  // 缓存只服务「live 且已知 turn 号」的评估：
  // preview（预览提示词 / 代答）用空定时器评估，既不能复用本轮 live 的结果，也绝不能写进缓存——
  // 否则本 turn 的 live 评估会沿用这份无定时器的结果，sticky/cooldown 被免定时器地决定且永不落盘。
  // 且 idle 时 turn 恒为 -1，各次预览之间也不该互相复用（绑定/世界书/记忆随时可能被编辑）。
  // 代价是每次预览/代答多评估一次世界书——正确且便宜。
  const cacheable = input.mode === 'live' && turn >= 0
  let memories: string[]
  let deltas: WorldDelta[]
  let lastCharMessage: string
  let journalText: string
  const lore = await loadBoundLoreEntries(state, binding)
  lore.entries = lore.entries.map(normalizeTemplateLore)
  const templateContext: TemplateContext = {
    variables: templateState.variables, char: charName, user: userName,
    card: templateCardData(card),
    entries: lore.entries, presets: preset.entries.filter(e => e.enabled), history: templateHistory,
    historyIdentities,messageVariables:visibleTemplateMessageVariables(templateState.messageVariables,historyIdentities),
    ...(helperMvu ? {helperMvu} : {}),
    ...await loadTemplateAvatars(state,binding.cardId,persona),
    now: macroCtx.now.getTime(), seed: turnSeed, phase: 'generate',
    sessionId, cardId: binding.cardId, generationType: input.generationType ?? 'normal', model:route.model ?? '',
  }
  {
    deltas = lore.deltas

    // 记忆检索：本轮输入 + 最近 N 条历史做查询，本轮输入里的词额外加权；
    // 角色名和用户人设名是确知的名字，即使正好由功能字组成（七、月、日向）也照常参与
    const { query: queryMessages, boost } = memoryQuery(chatMessages, config.memory.queryMessages)
    memories = []
    const candidateCount = memoryCandidateCount(config.memory.retrievalTopK)
    if (queryMessages.trim() && candidateCount > 0 && Number.isFinite(config.memory.retrievalTokenBudget) && config.memory.retrievalTokenBudget >= 1) {
      const hits = await ws.memory.search(
        queryMessages,
        { ...memorySearchOptions(candidateCount, config.memory.halfLifeDays), includeSummarySources: true, ...(boost ? { boost } : {}),
          names: persona?.name ? [charName, persona.name] : [charName] },
      )
      memories = selectMemoryBodies(hits, config.memory.retrievalTokenBudget, config.memory.retrievalTopK)
    }

    // 同轮冻结的宏输入：第 1 步取当前 history 的最近 assistant 正文（{{lastcharmessage}} 用），
    // 后续步 history 增长也不变；journal 同理只在本轮首次评估读一次盘。
    lastCharMessage = [...chatMessages].reverse().find((m) => m.role === 'assistant')?.content ?? ''
    journalText = ''
    if (binding.injectJournal) {
      const rawJournal = await ws.fs.readText('journal.md')
      if (rawJournal?.trim()) journalText = clipToTokenBudget(rawJournal, 800).text
    }


  }

  const assembled = await isolated('assemble', {
    templates: templateContext,
    templateContinuation:resolveTemplateContinuation(templateState),
    wiEvaluation: {
      entries:lore.entries, messages:chatMessages, settings:state.worldInfoFor(binding),
      timerState:input.mode==='live' ? await state.loadTimers(binding.cardId,sessionId,binding.storyId) : structuredClone(EMPTY_TIMER_STATE),
      contextWindowTokens:contextWindow, reservedTokens:estimateTokens(scanMessages.map(m=>m.content).join('\n')),
      seed:turnSeed, macroCtx:{char:charName,user:userName},
    },
    preset,
    promptPreferences: config.prompts,
    card,
    personaDescription: persona?.description ?? '',
    history: scanMessages,
    historyMessageIds: [
      ...history.map((_, index) => input.agent ? hostHistory[index]?.id : undefined),
      ...pendingFresh.map((_, index) => havePendingIds ? freshIdentified[index]?.id : undefined),
    ],
    historyChatFlags: chatFlags,
    wi:null,
    memories,
    worldDeltas:deltas,
    authorNote: binding.authorNote ?? '',
    journalText,
    // 显式冻结 lastCharMessage（同轮复用缓存值），不让 assemble 回退到随 history 增长的现算值。
    macroCtx: { ...macroCtx, lastCharMessage },
    regexRules: await state.rulesFor(binding),
    // ST injection_trigger 评估用：当前正常发信是 normal；continue/impersonate 经 PipelineInput 传入。
    generationType: input.generationType ?? 'normal',
    seed: turnSeed ^ 0x9e3779b9,
    budget: {
      maxTokens: contextWindow,
      reserveForOutput: sampling.maxTokens ?? FALLBACK_RESERVE_OUTPUT,
    },
  })

  const wi = assembled.evaluatedWi!
  templateContext.regexRules = assembled.templateRegexRules
  templateContext.hasMessageRegex = assembled.templateHasMessageRegex
  // live 通道独立预算；历史的压缩由宿主处理，不能用模拟历史长度裁掉角色定义。
  // 宿主跨轮也按字节去重快照；有尾部指令时固定本轮编号，让它每轮仍在新输入之后。
  // 编号和正文同存冻结计划，后续步骤与崩溃恢复不重新计算或反复追加。
  const turnContext = input.mode === 'live' && assembled.hasTurnTail && activeTurn !== undefined
    ? `${turnTailHeader(activeTurn)}\n\n${assembled.turnContext}` : assembled.turnContext
  const minimumLiveTokens = estimateTokens([BOUND_DISCIPLINE, assembled.standing, TURN_PLAYBOOK, turnContext].join('\n\n'))
  const available = contextWindow - (sampling.maxTokens ?? FALLBACK_RESERVE_OUTPUT)
  if (input.mode === 'live' && minimumLiveTokens > available) throw new Error('角色设定与本轮上下文已超过模型可用窗口，请缩减设定或提高上下文容量')
  const logLines = formatLogs(wi, assembled)
  logLines.push(`[live:budget] 插件通道≈${minimumLiveTokens} tokens；不含宿主 system/tools/历史，模拟裁剪不影响这些通道`)
  // turn 尾巴体积(缓存观测):快照对新请求永远是未缓存前缀,体积即每轮全价重付的量。
  logLines.push(`[turn:tail] turnContext≈${estimateTokens(assembled.turnContext)} tokens`)
  if (assembled.deltaDropped) {
    logLines.push(`[turn:tail] 变化层超预算裁掉 ${assembled.deltaDropped} 条（tavern_lore_read source=delta 可补读）`)
  }
  const result: PipelineResult = {
    cacheFirstLayout,
    templateContext,
    templateReplay:assembled.templateReplay,
    standingKey,
    sampling,
    standing: assembled.standing,
    turnContext,
    system: [assembled.standing, turnContext].filter(Boolean).join('\n\n'),
    messages: assembled.messages,
    layout: assembled.layout,
    history: assembled.history,
    assembled,
    logLines,
    userName,
    personaDescription: persona?.description ?? '',
    personaLorebookId: persona?.lorebookId ?? null,
    wiBudget: wi.budget,
  }
  const entry = input.mode === 'live' ? state.openFloors.get(sessionId) : undefined
  const writable = entry && turn >= 0 && entry.floor === `${sessionId}#t${turn}`
    && entry.cardId === binding.cardId && entry.storyId === binding.storyId
  const variablesChanged = assembled.templateVariables && JSON.stringify(assembled.templateVariables) !== JSON.stringify(templateState.variables)
  if (input.mode === 'live' && (variablesChanged || result.templateReplay) && !writable) throw new Error('模板写变量需要在绑定角色后开启新的一轮')
  const persistedGeneration:PreparedTemplateGeneration | undefined = result.templateReplay && writable && binding.storyId ? {
    version:1,status:'prepared',sessionId,cardId:binding.cardId,storyId:binding.storyId,turn,floor:entry.floor,replay:result.templateReplay,
    regexRules:templateContext.regexRules,hasMessageRegex:templateContext.hasMessageRegex,
    plan:{standingKey:result.standingKey,sampling:result.sampling,standing:result.standing,turnContext:result.turnContext,messages:result.messages,
      cacheFirstLayout:result.cacheFirstLayout,
      ...(result.layout ? {layout:result.layout} : {}),
      history:result.history,logLines:result.logLines,userName:result.userName,personaDescription:result.personaDescription,
      personaLorebookId:result.personaLorebookId,wiBudget:result.wiBudget,assembleLog:result.assembled.log,stats:result.assembled.stats},
  } : undefined
  // 变量发生变化时，定时器必须与变量同文件提交；否则第二个 rename 失败会让重试多 tick 一次。
  // 先冻结待提交闭包，但不发布 turnPlans。提交报错后保留绝对快照，重试不再运行第三方代码。
  const publish = async (): Promise<PipelineResult> => {
    if (writable) {
      const latestBinding = await state.loadBinding(sessionId)
      const latestFloor = state.openFloors.get(sessionId)
      if (latestBinding?.cardId !== binding.cardId || latestBinding?.storyId !== binding.storyId
        || latestFloor?.floor !== entry.floor || latestFloor.cardId !== binding.cardId || latestFloor.storyId !== binding.storyId
        || (cacheable && (state.currentTurns.get(sessionId) !== turn || entry.floor!==`${sessionId}#t${turn}`))) throw new Error('模板提交前剧情绑定或楼层已变化')
      if (variablesChanged || persistedGeneration || assembled.templateMessageVariables) {
        await saveTemplateState(ws.fs.withFloor(entry.floor), { ...templateState, variables: assembled.templateVariables ?? templateState.variables,
          ...(assembled.templateMessageVariables ? {messageVariables:mergeTemplateMessageVariables(templateState.messageVariables,assembled.templateMessageVariables,historyIdentities)} : {}),
          ...(assembled.templateContinuation ? {continuation:assembled.templateContinuation} : {}),
          wiTimers: { ...templateState.wiTimers, [sessionId]: wi.timerState },
          ...(persistedGeneration ? {generation:persistedGeneration} : {}) })
      } else {
        await state.saveTimers(binding.cardId, sessionId, wi.timerState, entry.floor, binding.storyId)
      }
    }
    state.recordTriggerLog(sessionId, logLines)
    if (cacheable) {
      state.wiCache.set(sessionId, { turn, wi, memories, deltas, lastCharMessage, journalText })
      state.turnPlans.set(sessionId, { turn, cardId: binding.cardId, storyId: binding.storyId, result })
      state.pendingTurnPlans.delete(sessionId)
    }
    return result
  }
  if (cacheable && writable) state.pendingTurnPlans.set(sessionId, { turn, cardId: binding.cardId, storyId: binding.storyId, floor: entry.floor, publish })
  return publish()
}

/** 从单份持久快照恢复所有入模字节与采样；不读取当前资产、不重跑 WI 或模板。 */
function restorePipelineResult(generation:PreparedTemplateGeneration):PipelineResult {
  const {assembleLog,stats,...plan} = generation.plan
  const system = [plan.standing,plan.turnContext].filter(Boolean).join('\n\n')
  return {...plan,system,templateContext:templateGenerationContext(generation),templateReplay:generation.replay,
    assembled:{messages:plan.messages,history:plan.history,layout:plan.layout,standing:plan.standing,turnContext:plan.turnContext,system,log:assembleLog,stats}}
}

function formatLogs(wi: WIEngineResult, assembled: AssembledPrompt): string[] {
  const lines: string[] = []
  for (const entry of wi.log) {
    lines.push(`[wi:${entry.kind}] ${entry.entryKey} — ${entry.detail}`)
  }
  lines.push(`[wi:budget] limit=${wi.budget.limit} used=${wi.budget.used}${wi.budget.overflowed ? '（溢出）' : ''}`)
  if (wi.truncated.length > 0) {
    lines.push(`[wi:truncated] ${wi.truncated.length} 条命中但因预算未注入（快照尾部已附 uid 清单）`)
  }
  for (const entry of assembled.log) {
    lines.push(`[assemble:${entry.kind}] ${entry.detail}`)
  }
  const { tokensBefore, tokensAfter, trimmedSections } = assembled.stats
  lines.push(`[assemble:budget] ${tokensBefore} → ${tokensAfter} tokens${trimmedSections.length ? `；裁剪：${trimmedSections.join(', ')}` : ''}`)
  return lines
}
