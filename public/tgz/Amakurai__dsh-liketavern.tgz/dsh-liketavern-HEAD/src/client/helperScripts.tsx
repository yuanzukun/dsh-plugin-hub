/** 会话级隐藏后台脚本容器：管理入口统一放在设置；解绑或切换会话时卸载各自的 opaque-origin iframe。 */
import { describeError } from '../core/guards.js'
import { useEffect,useState,useRef,useCallback,useMemo } from 'react'
import { buildCardSrcDoc } from '../core/cardFrame.js'
import { helperScriptHtml,isNativeMvuFramework } from '../core/cardScript.js'
import {publishScriptStatus,clearScriptStatus,type ScriptRuntimeStatus} from './helperScriptStatus.js'
import { enabledHelperScripts,enabledHelperLibraries,type HelperScriptAsset,type HelperScript } from '../core/helperScripts.js'
import type { HelperMessageEditResult } from '../core/helperChatEdits.js'
import {HelperMvuRunner,type HelperMvuRunnerStatus} from './helperMvuRunner.js'
import {openChildSession} from './openChild.js'
import { SpeechHtmlFrame } from './speech.js'
import {CHARACTER_CHANGED_EVENT,invalidateSessionBinding} from './cache.js'
import {BINDING_CHANGED_EVENT,BRANCH_CHANGED_EVENT} from './actions.js'
import { subscribeKeyedWindowEvent } from './windowEvents.js'
import { watchHelperScripts,watchHelperScriptAssets } from './helperScriptNotifications.js'
import { notifyHelperStory,watchHelperStory } from './helperNotifications.js'
import { useDisplaySettingsRevision } from './displayPrefs.js'
import { getTavernLocale, useT } from './i18n.js'
import {cardVariableLabels} from './cardVariableLabels.js'
import { useLoader } from './util.js'
import { CARD_VARIABLE_STYLES } from './styles.js'
import type { TavernRemote } from './types.js'
import { randomUuid } from '../core/secureRandom.js'

/** 等待首条消息的退避重试：1s 起、最长 15s、最多 20 次；之后只靠剧情通知唤醒。 */
const WAIT_MESSAGE_BASE_DELAY_MS=1_000
const WAIT_MESSAGE_MAX_DELAY_MS=15_000
const WAIT_MESSAGE_MAX_ATTEMPTS=20
/** 未表态 MVU 跟随的退避重试：5s 起、最长 30s、最多 12 次；剧情通知会重置计数。 */
const MVU_FOLLOW_BASE_DELAY_MS=5_000
const MVU_FOLLOW_MAX_DELAY_MS=30_000
const MVU_FOLLOW_MAX_ATTEMPTS=12

export function HelperScripts(props:{remote:TavernRemote;sessionId:string;cardId?:string;sessions?:{open(id:string):void;refresh?:()=>Promise<void>};onCancel?:()=>Promise<void>}) {
  const {remote,sessionId}=props,t=useT(),locale=getTavernLocale()
  const displaySettingsRevision=useDisplaySettingsRevision()
  const loader=useLoader(()=>remote.getHelperScriptBundle({sessionId}),[sessionId,displaySettingsRevision],true)
  const bundle=loader.state.status==='ready'?loader.state.value:undefined
  // RPC 每次成功载入的是一组新沙箱；内容修订相同也不代表旧运行时仍在。
  const runtimeVersion=useMemo(()=>randomUuid(),[bundle])
  const currentRuntime=useRef(runtimeVersion)
  currentRuntime.current=runtimeVersion
  const [ready,setReady]=useState<Record<string,string>>({})
  const [failures,setFailures]=useState<Record<string,{version:string;error:string}>>({})
  const [editedBranch,setEditedBranch]=useState<{version:string;scriptId:string;branch:NonNullable<HelperMessageEditResult['branch']>;error:string}|null>(null)
  const owner=useRef(Symbol('script-runtime'))
  const [mvuState,setMvu]=useState<{version:string;error:string|null;busy:boolean;restartRequired:boolean;canCancel:boolean;canceling:boolean;cancelError:string|null}>({version:runtimeVersion,error:null,busy:false,restartRequired:false,canCancel:false,canceling:false,cancelError:null})
  const mvu=mvuState.version===runtimeVersion?mvuState:{error:null,busy:false,restartRequired:false,canCancel:false,canceling:false,cancelError:null}
  const activeEditedBranch=editedBranch?.version===runtimeVersion?editedBranch:null
  const retryMvu=useRef<{version:string;run:()=>void}>({version:'',run:()=>{}})
  const cancelMvu=useRef<{version:string;run?:()=>Promise<void>}>({version:''})
  /** 退避重试计数按会话+剧情保留：bundle 重拉会重建 effect，计数不能随之归零（否则退化成固定 1s/5s 轮询）。 */
  const waitAttempts=useRef<{key:string;count:number}>({key:'',count:0})
  const followAttempts=useRef<{key:string;count:number}>({key:'',count:0})
  const mvuStatus=useCallback((value:HelperMvuRunnerStatus)=>{
    if(currentRuntime.current!==runtimeVersion)return
    retryMvu.current={version:runtimeVersion,run:value.retry}
    cancelMvu.current={version:runtimeVersion,run:value.cancel}
    setMvu(current=>current.version===runtimeVersion
      &&current.error===value.error
      &&current.busy===value.busy
      &&current.restartRequired===value.restartRequired
      &&current.canCancel===value.canCancel
      &&current.canceling===value.canceling
      &&current.cancelError===value.cancelError
      ?current
      :{version:runtimeVersion,error:value.error,busy:value.busy,restartRequired:value.restartRequired,canCancel:value.canCancel,canceling:value.canceling,cancelError:value.cancelError})
  },[runtimeVersion])
  useEffect(()=>{
    if(bundle)return
    // 重读期间 iframe 与 MVU 执行器已卸载；即使资产修订不变，也不能沿用旧运行时的就绪或故障。
    setReady({});setFailures({});setEditedBranch(null);retryMvu.current={version:'',run:()=>{}};cancelMvu.current={version:''}
  },[bundle])
  // 重拉或报错期间 bundle 暂时为空：记住本会话已知 storyId 与脚本库目标，避免连续保存或修复保存的通知静默丢失。
  const [knownStory,setKnownStory]=useState<{sessionId:string;storyId:string}|null>(null)
  if(bundle&&(knownStory?.sessionId!==sessionId||knownStory.storyId!==bundle.storyId)){
    setKnownStory({sessionId,storyId:bundle.storyId})
  }
  const watchedStoryId=bundle?.storyId??(knownStory?.sessionId===sessionId?knownStory.storyId:undefined)
  useEffect(()=>watchedStoryId?watchHelperScripts(sessionId,watchedStoryId,()=>loader.reload()):undefined,[sessionId,watchedStoryId,loader.reload])
  const watchedCardId=props.cardId??bundle?.cardId
  useEffect(()=>{
    if(!watchedCardId)return
    // HeaderChip 传入绑定中的稳定 cardId；重拉期间 bundle 暂时为空也不能漏掉连续保存事件。
    return subscribeKeyedWindowEvent(CHARACTER_CHANGED_EVENT,watchedCardId,false,loader.reload)
  },[watchedCardId,loader.reload])
  const {libraries,libraryTargetKeys,scripts,scriptError,libraryTypeByScriptId}=useMemo(()=>{
    const libs:HelperScriptAsset[]=bundle?(bundle.libraries??[{target:{type:'character',cardId:bundle.cardId},revision:bundle.revision,trees:bundle.trees}]):[]
    const targetKeys=libs.map(library=>JSON.stringify(library.target))
    let enabled:HelperScript[]=[],error:string|null=null
    try{enabled=enabledHelperLibraries(libs)}catch(err){error=describeError(err)}
    const typeById=new Map<string,HelperScriptAsset['target']['type']>()
    for(const library of libs){
      for(const item of enabledHelperScripts(library.trees)){
        if(!typeById.has(item.id))typeById.set(item.id,library.target.type)
      }
    }
    return {libraries:libs,libraryTargetKeys:targetKeys,scripts:enabled,scriptError:error,libraryTypeByScriptId:typeById}
  },[bundle])
  const [knownTargets,setKnownTargets]=useState<{sessionId:string;keys:string[]}|null>(null)
  if(bundle&&(knownTargets?.sessionId!==sessionId||JSON.stringify(knownTargets.keys)!==JSON.stringify(libraryTargetKeys))){
    setKnownTargets({sessionId,keys:libraryTargetKeys})
  }
  const waitingForMessage=Boolean(bundle?.enabled&&bundle.messageId===null&&!bundle.snapshot&&!bundle.runtimeError&&!scriptError&&(scripts.length>0||bundle.helperMvu)&&scripts.length<=32)
  useEffect(()=>{
    if(!waitingForMessage||!bundle)return
    // 首条消息出现后启动等待中的脚本；已运行的沙箱自行刷新数据，不因普通剧情通知重启。
    let requested=false
    const stop=watchHelperStory(sessionId,bundle.storyId,()=>{if(!requested){requested=true;loader.reload()}})
    // 退避重试：1s 起、最长 15s，最多 20 次（约 4 分钟）；之后交给剧情通知唤醒，不再 1Hz 空转。
    // 计数放在 ref 里：loader 重拉会让 waitingForMessage 短暂翻转并重建 effect，计数不能随之归零。
    const key=`${sessionId}\0${bundle.storyId}`
    if(waitAttempts.current.key!==key)waitAttempts.current={key,count:0}
    const counter=waitAttempts.current
    let timer:ReturnType<typeof setTimeout>|undefined
    const schedule=()=>{
      if(counter.count>=WAIT_MESSAGE_MAX_ATTEMPTS)return
      const delay=Math.min(WAIT_MESSAGE_MAX_DELAY_MS,WAIT_MESSAGE_BASE_DELAY_MS*2**counter.count)
      timer=setTimeout(()=>{counter.count++;loader.reload();schedule()},delay)
    }
    schedule()
    return()=>{stop();if(timer!==undefined)clearTimeout(timer)}
  },[sessionId,bundle?.storyId,waitingForMessage,loader.reload])
  // 从未表态的绑定跟随卡片：宿主忙时开启会被 idle 认领拒绝，随剧情通知与退避重试，直到开启或不再适用。
  const enableMvu=useCallback(async(mode:'follow'|'explicit')=>{
    if(!bundle)throw new Error(t('settings.scripts.nativeUnavailable'))
    const result=await remote.enableHelperMvu({sessionId,storyId:bundle.storyId,mode})
    if(!result.ok)throw new Error(result.error.message)
    if(result.value.changed){invalidateSessionBinding(sessionId);window.dispatchEvent(new CustomEvent(BINDING_CHANGED_EVENT,{detail:sessionId}))}
    else if(mode==='explicit'&&!result.value.enabled)throw new Error(t('settings.scripts.nativeUnavailable'))
  },[remote,sessionId,bundle,t])
  const follow=bundle?.helperMvuFollow===true
  useEffect(()=>{
    if(!follow||!bundle)return
    let active=true,running=false,timer:ReturnType<typeof setTimeout>|undefined
    const attempt=()=>{if(!active||running)return;running=true;void enableMvu('follow').catch(()=>{}).finally(()=>{running=false})}
    // 退避重试：5s 起、最长 30s，最多 12 次（约 4 分钟）；之后靠剧情通知重试。
    // 计数同样放 ref：bundle 重拉会换掉 enableMvu 身份并重建 effect。
    const key=`${sessionId}\0${bundle.storyId}`
    if(followAttempts.current.key!==key)followAttempts.current={key,count:0}
    const counter=followAttempts.current
    const schedule=()=>{
      if(counter.count>=MVU_FOLLOW_MAX_ATTEMPTS)return
      const delay=Math.min(MVU_FOLLOW_MAX_DELAY_MS,MVU_FOLLOW_BASE_DELAY_MS*2**counter.count)
      timer=setTimeout(()=>{counter.count++;attempt();schedule()},delay)
    }
    attempt()
    const stop=watchHelperStory(sessionId,bundle.storyId,()=>{counter.count=0;attempt()})
    schedule()
    return()=>{active=false;stop();if(timer!==undefined)clearTimeout(timer)}
  },[follow,sessionId,bundle?.storyId,enableMvu])
  const watchedTargetKeys=bundle?libraryTargetKeys:knownTargets?.sessionId===sessionId?knownTargets.keys:null
  const watchedTargetsKey=JSON.stringify(watchedTargetKeys)
  useEffect(()=>watchHelperScriptAssets(target=>{
    const serialized=JSON.stringify(target)
    const matchesKnown=watchedTargetKeys!==null&&watchedTargetKeys.includes(serialized)
    const matchesFallback=watchedTargetKeys===null&&(target.type==='global'||target.type==='preset'||(target.type==='character'&&(!watchedCardId||target.cardId===watchedCardId)))
    if(matchesKnown||matchesFallback)loader.reload()
  }),[loader.reload,watchedTargetsKey,watchedCardId])
  const allReady=!scriptError&&!bundle?.runtimeError&&scripts.length<=32&&scripts.every(script=>ready[script.id]===runtimeVersion&&failures[script.id]?.version!==runtimeVersion)
  // 超预算时一个脚本都不会挂载：状态必须显式报错，否则谎报 running 且 MVU 永远「等待脚本就绪」。
  const scriptsBudget=bundle?.enabled===true&&scripts.length>32
  const status:ScriptRuntimeStatus={sessionId,cardId:bundle?.cardId??watchedCardId??'',nativeMvu:bundle?.helperMvu===true,mvuFollow:follow,mvuBusy:mvu.busy,mvuError:mvu.error??undefined,
    mvuRestartRequired:mvu.restartRequired||undefined,mvuCanCancel:mvu.canCancel||undefined,mvuCanceling:mvu.canceling||undefined,mvuCancelError:mvu.cancelError??undefined,
    editedBranchError:activeEditedBranch?.error,editedBranchTitle:activeEditedBranch?.branch.title,
    state:loader.state.status==='error'||scriptError||bundle?.runtimeError||mvu.error||activeEditedBranch||scriptsBudget||scripts.some(script=>failures[script.id]?.version===runtimeVersion)?'error':!bundle?'loading':!bundle.enabled?'disabled':waitingForMessage?'waiting':'running',
    error:loader.state.status==='error'?loader.state.message:scriptError??bundle?.runtimeError??(scriptsBudget?t('speech.scriptsBudget'):undefined),
    scripts:scripts.map(script=>({id:script.id,name:script.name||script.id,native:isNativeMvuFramework(script.content),state:failures[script.id]?.version===runtimeVersion?'error':ready[script.id]===runtimeVersion?'ready':'loading',error:failures[script.id]?.version===runtimeVersion?failures[script.id]?.error:undefined}))}
  const statusKey=JSON.stringify(status)
  const openEditedBranch=useCallback(async()=>{
    if(!activeEditedBranch||!props.sessions)return
    const pending=activeEditedBranch
    try{
      await openChildSession(props.sessions,pending.branch.childSessionId,pending.branch.title)
      if(currentRuntime.current!==pending.version)return
      setEditedBranch(current=>current?.version===pending.version?null:current)
      setFailures(current=>{
        if(current[pending.scriptId]?.version!==pending.version||current[pending.scriptId]?.error!==pending.error)return current
        const next={...current};delete next[pending.scriptId];return next
      })
    }catch(cause){
      if(currentRuntime.current!==pending.version)return
      const message=describeError(cause)
      setEditedBranch(current=>current?.version===pending.version?{...current,error:message}:current)
      setFailures(current=>{
        if(current[pending.scriptId]?.version!==pending.version||current[pending.scriptId]?.error!==pending.error)return current
        return {...current,[pending.scriptId]:{version:pending.version,error:message}}
      })
    }
  },[activeEditedBranch,props.sessions,sessionId])
  useEffect(()=>{
    publishScriptStatus(
      owner.current,
      status,
      ()=>{if(retryMvu.current.version===currentRuntime.current)retryMvu.current.run()},
      ()=>enableMvu('explicit'),
      {
        cancel:mvu.canCancel?async()=>{if(cancelMvu.current.version===currentRuntime.current&&cancelMvu.current.run)await cancelMvu.current.run()}:undefined,
        openBranch:activeEditedBranch&&props.sessions?openEditedBranch:undefined,
      },
    )
  },[statusKey,enableMvu,mvu.canCancel,activeEditedBranch,props.sessions,openEditedBranch])
  useEffect(()=>()=>clearScriptStatus(owner.current,sessionId),[sessionId])
  const scriptFrames=useMemo(()=>{
    if(!bundle?.enabled||bundle.runtimeError||scriptError||!bundle.snapshot||bundle.messageId===null||scripts.length>32)return []
    const snapshot=bundle.snapshot,messageId=bundle.messageId
    const assistantName=bundle.name??snapshot.messages.find(message=>message.role==='assistant')?.name??''
    const userName=bundle.userName??snapshot.messages.find(message=>message.role==='user')?.name??''
    const libraryList=libraries.map(library=>({type:library.target.type,trees:library.trees}))
    const scriptLibraryLabels={saving:t('speech.scriptSaving'),saved:t('speech.scriptSaved'),failed:t('speech.scriptSaveFailed')}
    const persistenceLabels={saving:t('speech.helperSaving'),saved:t('speech.helperSaved'),failed:t('speech.helperSaveFailed'),refresh:t('speech.helperRefresh')}
    const helperLabels={diagnostics:t('speech.helperMessages'),unsupported:t('speech.helperUnsupported')}
    const variableLabels=cardVariableLabels(t,t('speech.helperDataNote'))
    return scripts.map(script=>({
      script,snapshot,messageId,
      srcDoc:buildCardSrcDoc(helperScriptHtml(script.content),{greetings:[],greetingIndex:0,helperSnapshot:snapshot,
        worldbooks:bundle.worldbooks,scriptLibraries:bundle.scriptContext,scriptLibraryLabels,
        scriptContext:{script,trees:bundle.trees,libraryType:libraryTypeByScriptId.get(script.id),libraries:libraryList},
        helperContext:{canSwipe:false,scriptFrame:true,name:assistantName,macroName:bundle.characterName??assistantName,userName},
        connectHosts:bundle.whitelist,variableStyles:CARD_VARIABLE_STYLES,persistenceLabels,helperLabels,variableLabels}),
    }))
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[bundle,scripts,scriptError,libraries,libraryTypeByScriptId,locale])
  return <span className="dsh-tavern-scriptHost" hidden>
    {bundle?.enabled&&bundle.helperMvu&&bundle.snapshot&&<HelperMvuRunner key={runtimeVersion} remote={remote} sessionId={sessionId} storyId={bundle.storyId} snapshot={bundle.snapshot} ready={allReady} onStatus={mvuStatus} onCancel={props.onCancel}/>}
    <div>
      {scriptFrames.map(({script,snapshot,messageId,srcDoc})=>{
        return <section key={runtimeVersion+script.id}>
          {<SpeechHtmlFrame srcDoc={srcDoc} title={script.name||script.id} widget compact
            onScriptError={error=>{if(currentRuntime.current===runtimeVersion)setFailures(current=>({...current,[script.id]:{version:runtimeVersion,error}}))}}
            onScriptReset={()=>{
              if(currentRuntime.current!==runtimeVersion)return
              setFailures(current=>{if(!current[script.id])return current;const next={...current};delete next[script.id];return next})
            }}
            onScriptReady={value=>{
              if(currentRuntime.current!==runtimeVersion)return
              setReady(current=>current[script.id]===(value?runtimeVersion:'')?current:{...current,[script.id]:value?runtimeVersion:''})
            }}
            onBranchError={(branch,error)=>{
              if(currentRuntime.current!==runtimeVersion)return
              if(branch&&error)setEditedBranch({version:runtimeVersion,scriptId:script.id,branch,error})
              else setEditedBranch(current=>current?.version===runtimeVersion&&current.scriptId===script.id?null:current)
            }}
            remote={remote} helperMessageId={messageId}
            helperBinding={{sessionId,storyId:snapshot.storyId}}
            onMessageBranch={props.sessions?async branch=>{window.dispatchEvent(new CustomEvent(BRANCH_CHANGED_EVENT,{detail:props.sessionId}));await openChildSession(props.sessions!,branch.childSessionId,branch.title,props.sessionId)}:undefined}
            onMessageEdit={async request=>{const result=await remote.editHelperMessages({...request,sessionId,messageId});if(!result.ok)throw new Error(result.error.message);if(result.value.snapshot)notifyHelperStory(sessionId,result.value.snapshot.storyId);return result.value}}
            onWorldbookBind={async request=>{const result=await remote.rebindHelperWorldbooks({...request,sessionId,messageId});if(!result.ok)throw new Error(result.error.message);if(request.kind!=='chat'&&request.kind!=='ensure-chat'){invalidateSessionBinding(sessionId);window.dispatchEvent(new CustomEvent(BINDING_CHANGED_EVENT,{detail:sessionId}))}return result.value}}
            onWorldbookRequest={async request=>{const result=await remote.helperWorldbookOperation({...request,sessionId,messageId});if(!result.ok)throw new Error(result.error.message);return result.value}}
            onWorldbookRefresh={async()=>{const result=await remote.getHelperWorldbookContext({sessionId,storyId:snapshot.storyId});if(!result.ok)throw new Error(result.error.message);return result.value}}
            onScriptCommit={async request=>{const result=await remote.commitSessionHelperScripts({...request,sessionId});if(!result.ok)throw new Error(result.error.message);return result.value}}
            onScriptRefresh={async()=>{const result=await remote.getSessionHelperScripts({sessionId,storyId:snapshot.storyId});if(!result.ok)throw new Error(result.error.message);return result.value}}
            onHelperCommit={async request=>{const result=await remote.commitHelperVariables({...request,sessionId,messageId});if(!result.ok)throw new Error(result.error.message);notifyHelperStory(sessionId,result.value.storyId);return result.value}}
            onHelperRefresh={async()=>{const result=await remote.getHelperSnapshot({sessionId,messageId});if(!result.ok)throw new Error(result.error.message);return result.value}}/>}
        </section>
      })}
    </div>
  </span>
}
