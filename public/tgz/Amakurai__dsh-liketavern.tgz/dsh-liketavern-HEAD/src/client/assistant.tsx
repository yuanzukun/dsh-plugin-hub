/**
 * 接管 conversation.chat.node / assistant-step：仅 Tavern 会话用「头像 + 正文」排版，
 * 并套 output/render 正则（标记换成 HTML 封面时进 iframe）。
 *
 * 本组件只在当前会话为 Tavern 时才会被登记（见 client/index.tsx）。若仍被挂到
 * 非 Tavern 会话上（切换瞬间），立刻交回空树之外的原生 Markdown 回退，避免挡住 dsh。
 */
import { Fragment, useEffect, useMemo, useRef } from 'react'
import type { ReactNode, ComponentProps } from 'react'
import { JsonBlock, MarkdownText } from '@deepseek-ai/dsh-client-ui-primitives'
import { stripDisplayMeta } from '../core/displaySanitize.js'
import { CHARACTER_CHANGED_EVENT, cachedCharacterDetail, cachedSessionBinding, invalidateCharacter, invalidateSessionBinding } from './cache.js'
import { useMarkdownLabels, useT } from './i18n.js'
import { isTavernSession, type UseSessions } from './mode.js'
import { openChildSession } from './openChild.js'
import { BINDING_CHANGED_EVENT, BRANCH_CHANGED_EVENT, TavernInterruptedFloorActions } from './actions.js'
import { SpeechBubble } from './speech.js'
import type { TavernSessions } from './navigation.js'
import type { CharacterDetail, SessionBinding, TavernRemote } from './types.js'
import { Btn, Err, Skeleton, useLoader } from './util.js'

interface AssistantBlock {
  kind: string
  text?: string
  attachment?: unknown
  block?: unknown
}

interface AssistantNode {
  location?: { kind?: string; turn?: { status?: string; turn?: number } }
  data: {
    status: string
    blocks: AssistantBlock[]
    finalNode?: { seq?: number }
  }
}

/** 同一卡片内会改变 output/render、宏或剧情 helper 身份的绑定字段。 */
function displayBindingRevision(binding: SessionBinding, userName?: string): string {
  return JSON.stringify([
    binding.storyId,
    binding.presetId,
    binding.personaId,
    userName ?? '',
    binding.interactiveCards,
    binding.helperMvu === true,
    binding.lorebookIds,
    binding.characterLorebookId,
    binding.useEmbeddedLorebook !== false,
    binding.characterLorebookIds ?? [],
    binding.worldInfo ?? null,
    binding.greetingIndex,
  ])
}

/** 宿主 owner props 里的会话图片加载器（0.2.1-rc.1 起配合 conversation.images.content factory 渲染消息图片）。 */
type MessageImageLoader = (attachmentId: string, signal?: AbortSignal) => Promise<unknown>

/** 宿主 Slot 注入的 Factory 渲染器（调用 conversation.images.content）。 */
type RenderImagesFactorySlot = (
  name: 'conversation.images.content',
  props: {
    images: readonly { attachment: unknown }[]
    loadImage?: MessageImageLoader
    align: 'start' | 'end'
  },
) => ReactNode

/** 兼容直接传入图片渲染回调的测试与辅助调用。 */
type RenderMessageImages = (owner: {
  images: readonly { attachment: unknown }[]
  loadImage?: MessageImageLoader
  align: 'start' | 'end'
}) => ReactNode

function renderAssistantImages(
  images: readonly { attachment: unknown }[],
  renderFactorySlot?: RenderImagesFactorySlot,
  loadImage?: MessageImageLoader,
  renderMessageImages?: RenderMessageImages,
): ReactNode {
  if (images.length === 0) return null
  if (renderFactorySlot && loadImage) {
    return renderFactorySlot('conversation.images.content', { images, loadImage, align: 'start' })
  }
  if (renderMessageImages) {
    return renderMessageImages({ images, ...(loadImage ? { loadImage } : {}), align: 'start' })
  }
  if (renderFactorySlot) {
    return renderFactorySlot('conversation.images.content', { images, loadImage, align: 'start' })
  }
  return null
}

/** fileMentions 的入参（宿主 AssistantNodeView 同款：turn-tail owner）。 */
interface TurnTailOwner {
  turn: { status?: string }
  seq: number
  openFile?: (path: string) => void
}

/**
 * 宿主只允许最终 turn-tail 上已经核验过的路径变成文件链接。角色气泡和原生回退
 * 必须共用同一份解析结果，否则绑定角色后同一句 Markdown 会突然失去文件跳转能力。
 */
function useAssistantOwner(
  node: AssistantNode,
  useTurnData?: (key: string) => unknown,
  openFile?: (path: string) => void,
  fileMentions?: (owner: TurnTailOwner) => ComponentProps<typeof MarkdownText>['fileMentions'],
) {
  const turn = node.location?.kind === 'turn' || node.location?.kind === 'step' ? node.location.turn : undefined
  const tail = useTurnData?.('turn-tail') as { closing?: { finalNode?: { seq?: number; messageId?: string } } | null } | undefined
  const finalSeq = node.data.finalNode?.seq
  // 0.1.7 的中断回复也可能持久化到 turn-tail；只有这个 owner 实际提供消息 ID 时才有宿主操作栏。
  const hasTailActions = finalSeq !== undefined && tail?.closing?.finalNode?.seq === finalSeq
    && typeof tail.closing.finalNode.messageId === 'string'
  const mentionOwner = useMemo<TurnTailOwner | undefined>(() => {
    if (!turn || turn.status !== 'closed' || finalSeq === undefined) return undefined
    if (tail?.closing?.finalNode?.seq !== finalSeq) return undefined
    return { turn, seq: finalSeq, openFile }
  }, [turn, tail, finalSeq, openFile])
  const mentions = useMemo(
    () => (mentionOwner && fileMentions ? fileMentions(mentionOwner) : undefined),
    [fileMentions, mentionOwner],
  )
  return { mentions, hasTailActions }
}

function ReasoningFold(props: { text: string; streaming?: boolean }) {
  const t = useT()
  if (!props.text.trim()) return null
  return (
    <details className="dsh-tavern-reason">
      <summary>{props.streaming ? t('assistant.thinking') : t('assistant.thought')}</summary>
      <pre>{props.text}</pre>
    </details>
  )
}

export function TavernAssistantNode(props: {
  remote: TavernRemote
  sessionId: string
  sessions?: Pick<TavernSessions,'open'|'refresh'|'binding'>
  useSessions?: UseSessions
  node: AssistantNode
  /**
   * 0.1.7 起宿主把同时含思考与正文的步骤拆成两次渲染：reasoning 段放进「用时」折叠区
   * （折叠时隐藏但仍挂载），response 段是正文。忽略它会在折叠区里再挂一整份卡面与脚本。
   */
  groupPart?: string
  loadImage?: MessageImageLoader
  renderFactorySlot?: RenderImagesFactorySlot
  renderMessageImages?: RenderMessageImages
  useTurnData?: (key: string) => unknown
  openFile?: (path: string) => void
  fileMentions?: (owner: TurnTailOwner) => ComponentProps<typeof MarkdownText>['fileMentions']
}) {
  const { remote, sessionId, sessions, node } = props
  const t = useT()
  const markdownLabels = useMarkdownLabels()
  const tavern = isTavernSession(props.useSessions, sessionId)
  // 绑定/角色详情走进程内缓存（key=sessionId / cardId）：N 个 assistant 节点共享一次 RPC。
  const bindingLoader = useLoader(() => cachedSessionBinding(remote, sessionId), [sessionId], tavern)
  // 绑定/解绑或修改互动卡开关后，已渲染的楼层要随之切换排版；否则要等重新挂载才更新（操作条与 chip 同样监听）。
  useEffect(() => {
    if (!tavern || typeof window === 'undefined') return
    const changed = (event: Event) => {
      const target = (event as CustomEvent<string | undefined>).detail
      if (!target || target === sessionId) bindingLoader.reload()
    }
    window.addEventListener(BINDING_CHANGED_EVENT, changed)
    return () => window.removeEventListener(BINDING_CHANGED_EVENT, changed)
  }, [tavern, sessionId, bindingLoader.reload])
  // 重拉与读取失败时沿用同一会话上次确认的绑定，避免短暂故障卸载互动卡；成功解绑仍立即生效。
  const lastBinding = useRef<{ sessionId: string; binding: SessionBinding | null; userName?: string } | null>(null)
  if (bindingLoader.state.status === 'ready') {
    lastBinding.current = { sessionId, binding: bindingLoader.state.value.binding, userName: bindingLoader.state.value.userName }
  }
  const binding = bindingLoader.state.status === 'ready'
    ? bindingLoader.state.value.binding
    : (bindingLoader.state.status === 'loading' || bindingLoader.state.status === 'error') && lastBinding.current?.sessionId === sessionId ? lastBinding.current.binding : null
  const userName = bindingLoader.state.status === 'ready'
    ? bindingLoader.state.value.userName
    : (bindingLoader.state.status === 'loading' || bindingLoader.state.status === 'error') && lastBinding.current?.sessionId === sessionId ? lastBinding.current.userName : undefined
  const detail = useLoader(
    () => cachedCharacterDetail(remote, binding!.cardId),
    [binding?.cardId],
    tavern && binding !== null,
  )
  useEffect(() => {
    if (!tavern || !binding) return
    const changed = (event: Event) => {
      if ((event as CustomEvent<string>).detail === binding.cardId) detail.reload()
    }
    window.addEventListener(CHARACTER_CHANGED_EVENT, changed)
    return () => window.removeEventListener(CHARACTER_CHANGED_EVENT, changed)
  }, [tavern, binding?.cardId, detail.reload])
  const streaming = node.data.status === 'running'
  const eventBinding=sessions?.binding?.(sessionId)
  const interrupted = node.data.status === 'interrupted'
  const text = node.data.blocks.filter((b) => b.kind === 'text').map((b) => b.text ?? '').join('\n')
  // 详情刷新不应短暂改成通用角色名，否则 name 会改变 srcDoc，销毁卡面草稿和脚本运行时。
  const lastDetail = useRef<{ cardId: string; value: CharacterDetail } | null>(null)
  if (detail.state.status === 'ready' && binding) lastDetail.current = { cardId: binding.cardId, value: detail.state.value }
  const currentDetail = detail.state.status === 'ready' ? detail.state.value
    : binding && lastDetail.current?.cardId === binding.cardId ? lastDetail.current.value : undefined
  const name = currentDetail?.name ?? binding?.cardName ?? ''
  const hasImages = node.data.blocks.some((b) => b.kind === 'image')
  const firstImage = node.data.blocks.findIndex((block) => block.kind === 'image')
  const firstText = node.data.blocks.findIndex((block) => block.kind === 'text')
  // SpeechBubble 的卡面投影是整条文本的一次 output/render，宿主图片只能作为尾部
  // media 插槽。只接管 reasoning* → text* → image*（其间可有不可见 tool-call）；
  // 图片后还有可见块、正文后又出现 reasoning，或宿主新增未知块时回退原生节点，
  // 避免重排图片/思考过程，也不能静默丢掉未来块类型。
  const supportsBubbleBlocks = node.data.blocks.every((block) =>
    block.kind === 'reasoning' || block.kind === 'text' || block.kind === 'image' || block.kind === 'tool-call')
  const hasInterleavedImages = firstImage >= 0
    && node.data.blocks.slice(firstImage + 1).some((block) => block.kind !== 'image' && block.kind !== 'tool-call')
  const hasLateReasoning = firstText >= 0
    && node.data.blocks.slice(firstText + 1).some((block) => block.kind === 'reasoning')
  const reasoningBlocks = node.data.blocks.filter((b) => b.kind === 'reasoning')
  const { mentions, hasTailActions } = useAssistantOwner(node, props.useTurnData, props.openFile, props.fileMentions)

  const reasoningText = reasoningBlocks.map((b) => b.text ?? '').filter((chunk) => chunk.trim()).join('\n\n---\n\n')

  if (!tavern) {
    return <NativeAssistantFallback {...props} mentions={mentions} streaming={streaming} interrupted={interrupted} />
  }
  // 分段思考已经由宿主折叠；只画内容，不再要求用户多展开一层，也不挂角色气泡与脚本。
  if (props.groupPart === 'reasoning') return reasoningText.trim()
    ? <MarkdownText text={reasoningText} streaming={streaming} labels={markdownLabels} /> : null
  const showReasoning = props.groupPart !== 'response'

  // 首次绑定尚未确认时不把 HTML/EJS 原文交给原生 Markdown，避免异步回包前短暂显示源码。
  // 已知绑定的刷新沿用原气泡；失败仍提供可读回退与恢复入口。
  if (bindingLoader.state.status === 'loading' && lastBinding.current?.sessionId !== sessionId) {
    return <Skeleton height={56} />
  }

  // 失败不是“没有绑定”：保留可读正文并提供就地恢复，重试先清缓存以绕开仍挂起的旧请求。
  const bindingError = bindingLoader.state.status === 'error' ? (
    <div className="dsh-tavern-notice">
      <Err message={t('assistant.bindingLoadFailed', { message: bindingLoader.state.message })} />
      <Btn onClick={() => { invalidateSessionBinding(sessionId); bindingLoader.reload() }}>{t('assistant.retryBinding')}</Btn>
    </div>
  ) : null
  const detailError = binding && detail.state.status === 'error' ? (
    <div className="dsh-tavern-notice">
      <Err message={t('assistant.bindingLoadFailed', { message: detail.state.message })} />
      <Btn onClick={() => { invalidateCharacter(binding.cardId); detail.reload() }}>{t('assistant.retryBinding')}</Btn>
    </div>
  ) : null

  // 仅未进入宿主持久消息操作栏的中断楼层按 turn 补挂；不能因 status=interrupted 就重复挂载。
  const locationTurn =
    node.location && (node.location.kind === 'turn' || node.location.kind === 'step') ? node.location.turn?.turn : undefined
  const interruptedActions =
    interrupted && !hasTailActions && binding && typeof locationTurn === 'number' && sessions ? (
      <TavernInterruptedFloorActions remote={remote} sessionId={sessionId} sessions={sessions} turn={locationTurn} />
    ) : null

  if (binding && text && supportsBubbleBlocks && !hasInterleavedImages && !hasLateReasoning) {
    const images = hasImages
      ? renderAssistantImages(
          node.data.blocks.filter((block) => block.kind === 'image').map(({ attachment }) => ({ attachment })),
          props.renderFactorySlot,
          props.loadImage,
          props.renderMessageImages,
        )
      : null
    return (
      <div>
        {bindingError}
        {detailError}
        {showReasoning && <ReasoningFold text={reasoningText} streaming={streaming} />}
        <SpeechBubble
          remote={remote}
          sessionId={sessionId}
          cardId={binding.cardId}
          name={name || t('assistant.characterFallback')}
          characterRevision={currentDetail?.revision}
          bindingRevision={displayBindingRevision(binding, userName)}
          rawText={text}
          fileMentions={mentions}
          media={images}
          messageId={node.data.finalNode?.seq}
          streaming={streaming || node.location?.turn?.status === 'open'}
          streamSource={eventBinding?.sessionId===sessionId?eventBinding.eventSource:undefined}
          turn={node.location?.turn?.turn}
          interactiveCards={binding.interactiveCards}
          onMessageBranch={async branch=>{if(!sessions)throw new Error(t('speech.navigationUnavailable'));window.dispatchEvent(new CustomEvent(BRANCH_CHANGED_EVENT,{detail:sessionId}));await openChildSession(sessions,branch.childSessionId,branch.title,sessionId)}}
          onSwipeGreeting={async (index, frameLease) => {
            if (!sessions) throw new Error(t('speech.navigationUnavailable'))
            const r = await remote.swipeGreeting({ sessionId, index, ...(frameLease?{frameLease}:{}) })
            if (!r.ok) throw new Error(r.error.message)
            await openChildSession(sessions, r.value.childSessionId, r.value.title, sessionId)
          }}
        />
        {interrupted && <div className="dsh-tavern-notice">{t('assistant.stopped')}</div>}
        {interruptedActions}
      </div>
    )
  }

  return (
    <div>
      {bindingError}
      <NativeAssistantFallback {...props} mentions={mentions} streaming={streaming} interrupted={interrupted} stripMeta />
      {interruptedActions}
    </div>
  )
}

function NativeAssistantFallback(props: {
  node: AssistantNode
  loadImage?: MessageImageLoader
  renderFactorySlot?: RenderImagesFactorySlot
  renderMessageImages?: RenderMessageImages
  useTurnData?: (key: string) => unknown
  openFile?: (path: string) => void
  fileMentions?: (owner: TurnTailOwner) => ComponentProps<typeof MarkdownText>['fileMentions']
  mentions?: ComponentProps<typeof MarkdownText>['fileMentions']
  streaming: boolean
  interrupted: boolean
  stripMeta?: boolean
  groupPart?: string
}) {
  const { node, loadImage, renderFactorySlot, renderMessageImages, mentions, streaming, interrupted, stripMeta, groupPart } = props
  const t = useT()
  const markdownLabels = useMarkdownLabels()
  const rendered: ReactNode[] = []
  const blocks = node.data.blocks
  for (let i = 0; i < blocks.length; i++) {
    const block = blocks[i]
    if (!block) continue
    // 与宿主 AssistantMarkdown 相同的分段过滤。
    if (groupPart === 'reasoning' && block.kind !== 'reasoning') continue
    if (groupPart === 'response' && block.kind === 'reasoning') continue
    if (block.kind === 'text') {
      const shown = stripMeta ? stripDisplayMeta(block.text ?? '') : (block.text ?? '')
      rendered.push(
        <MarkdownText key={i} text={shown} streaming={streaming} fileMentions={mentions} labels={markdownLabels} />,
      )
    } else if (block.kind === 'reasoning') {
      if (stripMeta && groupPart !== 'reasoning') continue
      rendered.push(groupPart === 'reasoning'
        ? <MarkdownText key={i} text={block.text ?? ''} streaming={streaming} labels={markdownLabels} /> : (
        <details key={i} className="dsh-tavern-reason">
          <summary>{streaming ? t('assistant.thinking') : t('assistant.thought')}</summary>
          <pre>{block.text}</pre>
        </details>
      ))
    } else if (block.kind === 'image') {
      const group = [block]
      while (i + 1 < blocks.length) {
        const next = blocks[i + 1]
        if (!next || next.kind !== 'image') break
        group.push(next)
        i += 1
      }
      const imageNodes = renderAssistantImages(
        group.map(({ attachment }) => ({ attachment })),
        renderFactorySlot,
        loadImage,
        renderMessageImages,
      )
      if (imageNodes) {
        rendered.push(<Fragment key={i}>{imageNodes}</Fragment>)
      }
    } else if (block.kind === 'tool-call') {
      continue
    } else {
      rendered.push(<JsonBlock key={i} label={t('assistant.unknownBlock')} truncatedLabel={(total) => t('assistant.truncated', { total })} payload={block.block} />)
    }
  }
  return (
    <div>
      {stripMeta && groupPart === undefined ? <ReasoningFold text={node.data.blocks.filter((b) => b.kind === 'reasoning').map((b) => b.text ?? '').join('\n\n')} streaming={streaming} /> : null}
      {rendered}
      {interrupted && groupPart !== 'reasoning' ? <span>{t('assistant.stopped')}</span> : null}
    </div>
  )
}
