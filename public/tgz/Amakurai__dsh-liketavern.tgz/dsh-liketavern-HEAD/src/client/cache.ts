/**
 * 客户端进程内元数据缓存：assistant 节点 / 气泡 / 会话芯片 / 操作条各自独立读
 * 「绑定 + 角色详情 + 头像」，N 条回复放大成 ~3N 个重复 RPC + N 次头像 dataURL 传输。
 * 本模块按 key 做值缓存 + in-flight Promise 去重：同 key 并发共享一次 RPC；
 * 命中即回，过期后首个请求重拉并回填。
 *
 * TTL 口径：它只约束「下一次读取」能复用旧值多久，不是会主动唤醒 useLoader 的
 * 轮询器。本端已知写路径在成功后显式 invalidate 并广播（必须先失效再 reload，
 * 否则仍会吃到旧缓存）；模型工具、其它页签等外部写入会在组件下一次重载时收敛。
 * 失败（reject 或错误信封）不缓存，下次调用立即重试。
 * 每类缓存最多保留 128 项（包含飞行请求），优先淘汰最久未读项；每次读取清理过期项。
 * 头像另限缓存字符串的保守体积为 64 MiB；单张超限仍返回给当前读取，但不常驻缓存。
 *
 * 已知让步：getSessionBinding 的结果带 canSwipeGreeting（取决于会话是否已有用户
 * 消息），首条用户消息发出后最长 TTL 秒内可能仍读到 true；服务端仍是最终闸门。
 */
import type { Envelope, TavernRemote } from './types.js'

/** 绑定与角色详情：会话页内高频读，30s 兜底失效。 */
const META_TTL_MS = 30_000
/** 头像 dataURL 体积最大、且客户端没有改头像的写路径，放宽到 60s。 */
const AVATAR_TTL_MS = 60_000
/** 与读取界面的 20s 超时一致；断线悬挂的 RPC 不能永久占住重试入口。 */
const PENDING_TTL_MS = 20_000
/** 大量角色列表与断线 RPC 同样需要容量边界，不能只等待某次成功回包触发清理。 */
const MAX_CACHE_ENTRIES = 128
/** 按 UTF-16 每字符两字节保守估算，仅约束缓存持有的 dataURL，不包括已挂载图片的浏览器内存。 */
const MAX_AVATAR_CACHE_BYTES = 64 * 1024 * 1024

/**
 * 同页角色资产变更广播。仅清 Map 不会重新触发已经挂载的 useLoader；气泡、开场预览
 * 与会话 chip 监听此事件后按 cardId 主动 reload，避免保存成功却继续显示旧名称/设定。
 */
export const CHARACTER_CHANGED_EVENT = 'dsh-tavern:character-changed'

/** remote 方法的裸业务结果类型（信封内 value；与 service 实现同源，不另手写形状）。 */
type ResultOf<M extends keyof TavernRemote> = Awaited<ReturnType<TavernRemote[M]>> extends Envelope<infer T> ? T : never

interface CacheEntry<T> {
  at: number
  value?: Envelope<T>
  pending?: Promise<Envelope<T>>
}

interface CacheBudget<T> { maxBytes: number; bytes(value: T): number }

/** 体积和条数独立限额；只淘汰已返回值，不因另一个大头像清掉无关的飞行请求。 */
function trimValues<T>(map: Map<string, CacheEntry<T>>, budget: CacheBudget<T>): void {
  let total = 0
  for (const entry of map.values()) if (entry.value?.ok) total += budget.bytes(entry.value.value)
  for (const [key, entry] of map) {
    if (total <= budget.maxBytes) break
    if (!entry.value?.ok) continue
    total -= budget.bytes(entry.value.value)
    map.delete(key)
  }
}

/**
 * 读一条缓存：限时共享 in-flight > TTL 内命中 > 重拉。只缓存成功信封——错误信封多为
 * 上下文性失败（未绑定/服务未就绪），下次应真打 remote；reject 同理不留痕迹。
 */
function read<T>(map: Map<string, CacheEntry<T>>, key: string, ttlMs: number, load: () => Promise<Envelope<T>>, budget?: CacheBudget<T>): Promise<Envelope<T>> {
  const now = Date.now()
  for (const [cachedKey, entry] of map) {
    const age = now - entry.at
    // 系统时间校正到记录之前时失效；负年龄不能把旧值或挂起 RPC 延长到时钟追上为止。
    if (age < 0 || age >= (entry.pending ? PENDING_TTL_MS : ttlMs)) map.delete(cachedKey)
  }
  const hit = map.get(key)
  if (hit) {
    // Map 顺序表示最近读取顺序；命中不延长 TTL 或悬挂请求的重试期限。
    map.delete(key)
    map.set(key, hit)
    if (hit.pending) return hit.pending
    if (hit.value) return Promise.resolve(hit.value)
  }
  const pending = load().then(
    (r) => {
      if (r.ok) {
        // invalidate 可能在请求飞行期间发生；只有当前槽位仍属于本次请求时才允许回填。
        // 否则旧请求晚到会把新请求已经写入的值覆盖回去。
        if (map.get(key)?.pending !== pending) return r
        if (budget && budget.bytes(r.value) > budget.maxBytes) { map.delete(key); return r }
        map.set(key, { at: Date.now(), value: r })
        if (budget) trimValues(map, budget)
      } else if (map.get(key)?.pending === pending) {
        map.delete(key)
      }
      return r
    },
    (err) => {
      if (map.get(key)?.pending === pending) map.delete(key)
      throw err
    },
  )
  map.set(key, { at: now, pending })
  if (map.size > MAX_CACHE_ENTRIES) map.delete(map.keys().next().value!)
  return pending
}

interface CacheTables {
  bindings: Map<string, CacheEntry<ResultOf<'getSessionBinding'>>>
  details: Map<string, CacheEntry<ResultOf<'getCharacterDetail'>>>
  avatars: Map<string, CacheEntry<ResultOf<'getAvatar'>>>
}

/** remote 是当前宿主的身份；相同 sessionId/cardId 不能跨宿主复用值或飞行请求。 */
const caches = new WeakMap<TavernRemote, CacheTables>()
// 失效广播需覆盖仍存活的宿主，但不能因此把已卸载 remote 的头像和详情长期保留。
const cacheRefs = new Set<WeakRef<CacheTables>>()

function* liveCaches(): Generator<CacheTables> {
  for (const ref of cacheRefs) {
    const cache = ref.deref()
    if (cache) yield cache
    else cacheRefs.delete(ref)
  }
}

function cacheFor(remote: TavernRemote): CacheTables {
  const existing = caches.get(remote)
  if (existing) return existing
  const cache: CacheTables = { bindings: new Map(), details: new Map(), avatars: new Map() }
  caches.set(remote, cache)
  cacheRefs.add(new WeakRef(cache))
  return cache
}

/** 会话绑定（key=sessionId）；assistant 节点 / 会话芯片 / 英雄区 / 操作条共享一次 RPC。 */
export function cachedSessionBinding(remote: TavernRemote, sessionId: string) {
  return read(cacheFor(remote).bindings, sessionId, META_TTL_MS, () => remote.getSessionBinding({ sessionId }))
}

/** 角色详情（key=cardId）。 */
export function cachedCharacterDetail(remote: TavernRemote, cardId: string) {
  return read(cacheFor(remote).details, cardId, META_TTL_MS, () => remote.getCharacterDetail({ cardId }))
}

/** 头像缓存按字符串的最坏占用估算；正常 dataURL 为 ASCII，也不能因此依赖引擎压缩字符串。 */
const avatarBudget: CacheBudget<ResultOf<'getAvatar'>> = {
  maxBytes: MAX_AVATAR_CACHE_BYTES,
  bytes: value => typeof value?.dataUrl === 'string' ? value.dataUrl.length * 2 : 0,
}
/** 头像 dataURL（key=cardId）。 */
export function cachedAvatar(remote: TavernRemote, cardId: string) {
  return read(cacheFor(remote).avatars, cardId, AVATAR_TTL_MS, () => remote.getAvatar({ cardId }), avatarBudget)
}

/** setSessionBinding / clearSessionBinding 成功后调用（先于 reload / 广播）。 */
export function invalidateSessionBinding(sessionId: string): void {
  for (const cache of liveCaches()) cache.bindings.delete(sessionId)
}

/** 人设或默认设置变更可能改变任意会话解析出的 personaId / userName；清空绑定缓存并通知已挂载消费者重拉。 */
export function notifyAllSessionBindingsChanged(): void {
  for (const cache of liveCaches()) cache.bindings.clear()
  if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function' && typeof CustomEvent === 'function') {
    window.dispatchEvent(new CustomEvent('dsh-tavern:binding-changed'))
  }
}

/** 角色卡保存 / 删除后调用（详情与头像一起失效；删除时宿主侧绑定已清，会话绑定缓存靠 TTL 收敛）。 */
export function invalidateCharacter(cardId: string): void {
  for (const cache of liveCaches()) {
    cache.details.delete(cardId)
    cache.avatars.delete(cardId)
  }
}

/** 本端确认角色写入成功后，先失效缓存再通知所有仍挂载的消费者。 */
export function notifyCharacterChanged(cardId: string): void {
  invalidateCharacter(cardId)
  if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function' && typeof CustomEvent === 'function') {
    window.dispatchEvent(new CustomEvent(CHARACTER_CHANGED_EVENT, { detail: cardId }))
  }
}
