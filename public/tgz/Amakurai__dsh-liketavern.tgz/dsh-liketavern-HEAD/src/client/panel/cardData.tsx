/** 设置页的剧情变量管理：显式选择角色和剧情，备份已保存快照；恢复经原有楼层 WAL/CAS，草稿及失败留在设置。 */
import {useCallback,useEffect,useRef,useState} from 'react'
import {parseHelperVariableBackup,helperVariableRestoreChanges} from '../../core/helperVariableBackup.js'
import type {HelperSnapshot} from '../../core/helperRuntime.js'
import type {HelperScriptAsset} from '../../core/helperScripts.js'
import {DraftScope,useDraftGuard} from '../drafts.js'
import {useDraftState} from '../draftPersistence.js'
import {HelperScriptEditor} from '../helperScriptEditor.js'
import {notifyHelperStory} from '../helperNotifications.js'
import {notifyHelperScripts} from '../helperScriptNotifications.js'
import {useT} from '../i18n.js'
import type {TavernRemote} from '../types.js'
import {openChildSession,type SessionsPort} from '../openChild.js'
import {Btn,ConfirmDialog,Err,FileBtn,Muted,SaveBar,Section,Select,SettingsRow,Skeleton,downloadJson,useLoader,useToast} from '../util.js'

export function CardDataSettings({remote,sessions}:{remote:TavernRemote;sessions?:SessionsPort}){
  const t=useT()
  const [cardId,setCardId]=useDraftState('card-data:card','')
  const [storyId,setStoryId]=useDraftState('card-data:story','')
  const chars=useLoader(()=>remote.listCharacters({}),[])
  const stories=useLoader(()=>remote.listStories({cardId}),[cardId],Boolean(cardId))
  const items=stories.state.status==='ready'?stories.state.value.items:[]
  const story=items.find(item=>item.id===storyId)
  return <Section title={t('speech.cardDataTitle')} description={t('settings.cards.variablesDesc')}>
    <DraftScope>{request=><>
      <SettingsRow title={t('settings.cards.variableCharacter')}><Select value={cardId} title={t('settings.cards.variableCharacter')}
        disabled={chars.state.status!=='ready'}
        options={[{value:'',label:t('settings.cards.variableChoose')},...(chars.state.status==='ready'?chars.state.value.items.map(item=>({value:item.cardId,label:item.name})):[])]}
        onChange={value=>request(()=>{setCardId(value);setStoryId('')})}/></SettingsRow>
      <SettingsRow title={t('memory.story')}><Select value={storyId} title={t('memory.story')} disabled={!cardId||stories.state.status!=='ready'}
        options={[{value:'',label:t('settings.cards.variableChoose')},...items.map((item,index)=>({value:item.id,label:t('memory.storyLabel',{index:index+1,date:new Date(item.createdAt).toLocaleString()})}))]}
        onChange={value=>request(()=>setStoryId(value))}/></SettingsRow>
      {(chars.state.status==='loading'||stories.state.status==='loading')&&<Skeleton height={40}/>}
      <Err message={chars.state.status==='error'?chars.state.message:stories.state.status==='error'?stories.state.message:null}/>
      {(chars.state.status==='error'||stories.state.status==='error')&&<Btn onClick={()=>{chars.reload();stories.reload()}}>{t('action.retry')}</Btn>}
      <SessionTransfer remote={remote} sessions={sessions} sessionId={story?.sessionId}/>
      {story?<StoryVariableSettings key={JSON.stringify([cardId,storyId,story.sessionId])} remote={remote} cardId={cardId} storyId={storyId} sessionId={story.sessionId}/>:<Muted>{t('settings.cards.variableChooseStory')}</Muted>}
    </>}</DraftScope>
  </Section>
}

/** 导出当前选中剧情；导入必须选择现有工作区并先确认，失败保留文件以便重试。 */
export function SessionTransfer({remote,sessions,sessionId}:{remote:TavernRemote;sessions?:SessionsPort;sessionId?:string}){
  const t=useT(),toast=useToast(),workspaces=useLoader(()=>remote.listSessionImportWorkspaces({}),[remote])
  const active=useRef(true),pending=useRef(false)
  useEffect(()=>{active.current=true;return()=>{active.current=false}},[])
  const [workspaceId,setWorkspaceId]=useState(''),[archive,setArchive]=useState<{name:string;text:string}|null>(null)
  const [phase,setPhase]=useState<'reading'|'exporting'|'importing'|'opening'|null>(null)
  const [error,setError]=useState<string|null>(null),[confirm,setConfirm]=useState(false),[restoredSessionId,setRestoredSessionId]=useState<string|null>(null)
  const busy=phase!==null
  // 迁移文件可达 192 MiB，只在当前页面内持有；离开前保护输入，明确放弃后立即释放。
  const clearArchive=useCallback(()=>{setArchive(null);setConfirm(false)},[])
  const guard=useDraftGuard(archive!==null,busy,clearArchive)
  const exportSession=async()=>{
    if(!sessionId||pending.current)return
    pending.current=true
    setPhase('exporting');setError(null)
    try{const result=await remote.exportSessionArchive({sessionId});if(!result.ok)throw new Error(result.error.message);if(active.current)downloadJson('tavern-session.json',result.value.archive,0)}
    catch(e){if(active.current)setError(e instanceof Error?e.message:String(e))}finally{pending.current=false;if(active.current)setPhase(null)}
  }
  const choose=async(file:File)=>{
    if(pending.current)return
    setError(null)
    if(file.size>192*1024*1024){setError(t('sessionArchive.tooLarge'));return}
    pending.current=true;setPhase('reading')
    // 新文件完整读入后才替换原输入，读取失败仍可用原文件恢复中断的导入。
    try{const text=await file.text();if(active.current){setArchive({name:file.name,text});setConfirm(false);setRestoredSessionId(null)}}
    catch(e){if(active.current)setError(e instanceof Error?e.message:String(e))}finally{pending.current=false;if(active.current)setPhase(null)}
  }
  const openRestored=async(id:string)=>{
    if(!sessions)return
    try{await openChildSession({...sessions,open:target=>{if(active.current)sessions.open(target)}},id)}
    catch{if(active.current)setError(t('sessionArchive.navigationFailed'))}
  }
  const reopen=async()=>{
    if(!restoredSessionId||!sessions||pending.current)return
    pending.current=true;setPhase('opening');setError(null)
    try{await openRestored(restoredSessionId)}finally{pending.current=false;if(active.current)setPhase(null)}
  }
  const restore=async()=>{
    if(!archive||!workspaceId||pending.current)return
    pending.current=true
    setConfirm(false);setPhase('importing');setError(null)
    try{
      const result=await remote.importSessionArchive({workspaceId,archiveJson:archive.text})
      if(!result.ok)throw new Error(result.error.message)
      if(active.current){guard.clearDraft();setRestoredSessionId(result.value.sessionId);toast.show(t('sessionArchive.imported'))}
      if(sessions&&active.current){setPhase('opening');await openRestored(result.value.sessionId)}
    }catch(e){if(active.current)setError(e instanceof Error?e.message:String(e))}finally{pending.current=false;if(active.current)setPhase(null)}
  }
  const items=workspaces.state.status==='ready'?workspaces.state.value.items:[]
  return <Section title={t('sessionArchive.title')} description={t('sessionArchive.desc')}>
    {toast.node}
    <SettingsRow title={t('sessionArchive.export')} description={!sessionId?t('sessionArchive.chooseStory'):undefined}>
      <Btn disabled={!sessionId||busy} onClick={()=>void exportSession()}>{t('sessionArchive.export')}</Btn>
    </SettingsRow>
    <SettingsRow title={t('sessionArchive.workspace')}>
      <Select value={workspaceId} title={t('sessionArchive.workspace')} disabled={busy||workspaces.state.status!=='ready'}
        options={[{value:'',label:t('sessionArchive.chooseWorkspace')},...items.map(item=>({value:item.id,label:item.title}))]} onChange={setWorkspaceId}/>
    </SettingsRow>
    <SettingsRow title={t('sessionArchive.chooseFile')} description={archive?.name}>
      <FileBtn accept="application/json,.json" disabled={busy||confirm} onFile={file=>void choose(file)}>{t('sessionArchive.chooseFile')}</FileBtn>
      {archive&&<Btn disabled={busy||confirm} onClick={()=>{if(!pending.current){clearArchive();setError(null)}}}>{t('sessionArchive.clearFile')}</Btn>}
      <Btn primary disabled={busy||!archive||!workspaceId} onClick={()=>setConfirm(true)}>{t('sessionArchive.import')}</Btn>
    </SettingsRow>
    {phase&&<div role="status"><Muted>{t(`sessionArchive.${phase}`)}</Muted></div>}
    {restoredSessionId&&<SettingsRow title={t('sessionArchive.imported')}>
      {sessions&&<Btn disabled={busy} onClick={()=>void reopen()}>{t('sessionArchive.openImported')}</Btn>}
    </SettingsRow>}
    <Err message={error??(workspaces.state.status==='error'?workspaces.state.message:null)}/>
    {workspaces.state.status==='error'&&<Btn onClick={workspaces.reload}>{t('action.retry')}</Btn>}
    <ConfirmDialog open={confirm} title={t('sessionArchive.import')} description={t('sessionArchive.confirm')} busy={busy}
      onCancel={()=>setConfirm(false)} onConfirm={()=>void restore()}/>
  </Section>
}

export function StoryVariableSettings(props:{remote:TavernRemote;cardId:string;storyId:string;sessionId:string}){
  const {remote,sessionId,storyId}=props,t=useT()
  const loaded=useLoader(async()=>{
    const events=await remote.getHelperEventState({sessionId,storyId})
    if(!events.ok)return events
    const message=[...events.value.messages].reverse().find(item=>item.role==='assistant')
    if(!message)throw new Error(t('settings.cards.variableNoMessage'))
    const result=await remote.getHelperSnapshot({sessionId,messageId:message.seq})
    if(!result.ok)return result
    if(result.value.storyId!==storyId)throw new Error(t('speech.helperStoryChanged'))
    return {ok:true as const,value:{snapshot:result.value,messageId:message.seq}}
  },[sessionId,storyId])
  const [library,setLibrary]=useState<HelperScriptAsset|null>(null)
  const [scriptError,setScriptError]=useState<string|null>(null),[scriptBusy,setScriptBusy]=useState(false)
  const scriptGuard=useDraftGuard(false,scriptBusy)
  const editScripts=async()=>{
    setScriptBusy(true);setScriptError(null)
    try{
      const result=await remote.getHelperScriptLibrary({target:{type:'character',cardId:props.cardId}})
      if(!result.ok)throw new Error(result.error.message)
      setLibrary(result.value)
    }catch(error){setScriptError(error instanceof Error?error.message:String(error))}finally{setScriptBusy(false)}
  }
  return <>
    {scriptGuard.confirmation}
    <SettingsRow title={t('speech.scriptEditor')}><Btn disabled={scriptBusy} onClick={()=>void editScripts()}>{t('speech.scriptEditor')}</Btn></SettingsRow>
    <Err message={scriptError}/>
    {library&&<HelperScriptEditor remote={remote} library={library} onClose={()=>setLibrary(null)} onSaved={()=>notifyHelperScripts(sessionId,storyId)}/>}
    {loaded.state.status==='loading'&&<Skeleton height={100}/>}
    {loaded.state.status==='error'&&<><Err message={loaded.state.message}/><Btn onClick={loaded.reload}>{t('action.retry')}</Btn></>}
    {loaded.state.status==='ready'&&<VariableBackupEditor key={loaded.state.value.snapshot.historyRevision} remote={remote} sessionId={sessionId}
      snapshot={loaded.state.value.snapshot} messageId={loaded.state.value.messageId} onRefresh={loaded.reload}/>}
  </>
}

export function VariableBackupEditor(props:{remote:TavernRemote;sessionId:string;messageId:number;snapshot:HelperSnapshot;onRefresh:()=>void}){
  const t=useT(),toast=useToast()
  const [snapshot,setSnapshot]=useState(props.snapshot)
  useEffect(()=>{setSnapshot(props.snapshot)},[props.snapshot])
  const [text,setText]=useDraftState(`card-data:backup:${JSON.stringify([props.sessionId,snapshot.storyId])}`,'')
  const [error,setError]=useState<string|null>(null),[busy,setBusy]=useState(false),[confirm,setConfirm]=useState(false)
  const guard=useDraftGuard(Boolean(text.trim()),busy)
  const restore=async()=>{
    setConfirm(false);setBusy(true);setError(null)
    try{
      const target=parseHelperVariableBackup(text,snapshot.currentMessageId)
      const changes=helperVariableRestoreChanges(snapshot.scopes,target)
      if(!snapshot.writable)throw new Error(t('settings.cards.variableReadOnly'))
      if(changes.length){
        const result=await props.remote.commitHelperVariables({sessionId:props.sessionId,messageId:props.messageId,storyId:snapshot.storyId,historyRevision:snapshot.historyRevision,changes})
        if(!result.ok)throw new Error(result.error.message)
        if(result.value.storyId!==snapshot.storyId)throw new Error(t('speech.helperStoryChanged'))
        setSnapshot(result.value);notifyHelperStory(props.sessionId,snapshot.storyId)
      }else{
        // 旧快照相等不能证明服务器仍相等；只读复核后才提示无需恢复，不清掉冲突草稿。
        const fresh=await props.remote.getHelperSnapshot({sessionId:props.sessionId,messageId:props.messageId})
        if(!fresh.ok)throw new Error(fresh.error.message)
        if(fresh.value.storyId!==snapshot.storyId||fresh.value.historyRevision!==snapshot.historyRevision)throw new Error(t('speech.helperStoryChanged'))
        if(!fresh.value.writable)throw new Error(t('settings.cards.variableReadOnly'))
        if(helperVariableRestoreChanges(fresh.value.scopes,target).length)throw new Error(t('settings.cards.variableConflict'))
        setSnapshot(fresh.value)
      }
      setText('');guard.clearDraft();toast.show(t(changes.length?'speech.variableSaved':'settings.cards.variableUnchanged'))
    }catch(error){setError(error instanceof Error?error.message:String(error))}finally{setBusy(false)}
  }
  return <>
    {toast.node}{guard.confirmation}
    <Muted>{t(snapshot.writable?'settings.cards.variableLoaded':'settings.cards.variableReadOnly')}</Muted>
    <SettingsRow title={t('speech.helperRefresh')} description={t('settings.cards.variableRefreshDesc')}><Btn disabled={busy} onClick={()=>guard.request(()=>{setText('');setError(null);props.onRefresh()})}>{t('speech.helperRefresh')}</Btn></SettingsRow>
    <SettingsRow title={t('settings.cards.variableExport')}><Btn disabled={busy} onClick={()=>downloadJson('tavern-variables.json',{version:1,scopes:snapshot.scopes},0)}>{t('settings.cards.variableExport')}</Btn></SettingsRow>
    <SettingsRow stacked title={t('speech.cardDataRestore')} description={t('settings.cards.variableRestoreDesc')}>
      <textarea className="dsh-tavern-input dsh-tavern-textarea dsh-tavern-codeFont" aria-label={t('speech.cardDataText')} value={text} disabled={busy} onChange={event=>setText(event.target.value)}/>
    </SettingsRow>
    <Err message={error}/>
    <SaveBar><Btn disabled={busy||!text.trim()} onClick={()=>guard.request(()=>{setText('');setError(null)})}>{t('action.cancel')}</Btn>
      <Btn primary disabled={busy||!snapshot.writable||!text.trim()} onClick={()=>{try{helperVariableRestoreChanges(snapshot.scopes,parseHelperVariableBackup(text,snapshot.currentMessageId));setError(null);setConfirm(true)}catch(error){setError(error instanceof Error?error.message:String(error))}}}>{t('speech.cardDataRestore')}</Btn></SaveBar>
    <ConfirmDialog open={confirm} title={t('speech.cardDataRestore')} description={t('settings.cards.variableRestoreConfirm')} busy={busy}
      onCancel={()=>setConfirm(false)} onConfirm={()=>void restore()}/>
  </>
}
