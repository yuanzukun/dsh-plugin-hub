/**
 * 设置面板分区：记忆与世界状态（按角色卡查看 / 编辑 / 压缩 / 导出）。
 * 记忆/世界状态切换用 chip 段控；条目为 .dsh-tavern-memo 卡片（meta 行 + 正文 + IconBtn 操作）。
 * 压缩/导出等瞬时反馈走 useToast，上下文错误用 Err。
 */
import { useDraftGuard } from '../drafts.js'
import { PersistentEditor, useDraftRestored, useDraftState } from '../draftPersistence.js'
import { useEffect, useRef, useState } from 'react'
import { IconEditOutlineMedium, IconTrashOutlineMedium } from '@deepseek-ai/dsh-client-ui-primitives'
import type { MemoryEntry, WorldDelta } from '../../core/types.js'
import { useT } from '../i18n.js'
import type { TavernRemote } from '../types.js'
import { Badge, Btn, ConfirmDialog, Err, IconBtn, Muted, Section, Select, SettingsRow, Skeleton, downloadJson, errOf, runAsync, useLoader, useToast } from '../util.js'

/** 变化层类型徽标/选项对应的 i18n 键；渲染处经 t() 取文案。 */
const DELTA_TYPE_KEY: Record<WorldDelta['type'], string> = { add: 'memory.deltaType.add', update: 'memory.deltaType.update', invalidate: 'memory.deltaType.invalidate' }

function splitList(text: string): string[] {
  return text
    .split(/[，,\n]/)
    .map((s) => s.trim())
    .filter(Boolean)
}

function MemoryEditor(props: { remote: TavernRemote; cardId: string; storyId?: string; entry: MemoryEntry; onDone: () => void }) {
  const { entry } = props
  const t = useT()
  const draftKey = `memory:entry:${JSON.stringify([props.cardId, props.storyId ?? null, entry.id])}`
  const [body, setBody] = useDraftState(`${draftKey}:body`, entry.body)
  const [tags, setTags] = useDraftState(`${draftKey}:tags`, entry.tags.join(', '))
  const [keys, setKeys] = useDraftState(`${draftKey}:keys`, entry.keys.join(', '))
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const saving = useRef(false)
  const guard = useDraftGuard(body !== entry.body || tags !== entry.tags.join(', ') || keys !== entry.keys.join(', '), busy)
  const save = async () => {
    if (saving.current || !body.trim()) return
    saving.current = true
    try { await runAsync(setBusy, setError, async () => {
      const r = await props.remote.saveMemory({
        cardId: props.cardId,
        storyId: props.storyId,
        id: entry.id,
        body,
        tags: splitList(tags),
        keys: splitList(keys),
      })
      const err = errOf(r)
      if (err) setError(err)
      else {
        setTags(splitList(tags).join(', '))
        setKeys(splitList(keys).join(', '))
        props.onDone()
      }
    }) } finally { saving.current = false }
  }
  const cancel = () => { if (saving.current) return; guard.request(() => {
    setBody(entry.body)
    setTags(entry.tags.join(', '))
    setKeys(entry.keys.join(', '))
    props.onDone()
  }) }
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginTop: 4 }}>
      {guard.confirmation}
      <textarea aria-label={t('memory.entryBody')} className="dsh-tavern-input dsh-tavern-textarea" disabled={busy} value={body} onChange={(e) => setBody(e.target.value)} />
      <div className="dsh-tavern-fieldRow">
        <label className="dsh-tavern-field">
          <span className="dsh-tavern-fieldLabel">{t('memory.tags')}</span>
          <input className="dsh-tavern-input" disabled={busy} value={tags} onChange={(e) => setTags(e.target.value)} />
        </label>
        <label className="dsh-tavern-field">
          <span className="dsh-tavern-fieldLabel">{t('memory.keys')}</span>
          <input className="dsh-tavern-input" disabled={busy} value={keys} onChange={(e) => setKeys(e.target.value)} />
        </label>
      </div>
      <Err message={error} />
      <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
        <Btn disabled={busy} onClick={cancel}>{t('action.cancel')}</Btn>
        <Btn primary disabled={busy || !body.trim()} onClick={() => void save()}>{t('action.save')}</Btn>
      </div>
    </div>
  )
}

interface MemorySectionProps { remote: TavernRemote; initialContext?: { cardId: string; storyId: string } }

/** 聊天入口独立使用剧情草稿范围；设置面板已有范围时复用父级存储与恢复提示。 */
export function MemorySection(props: MemorySectionProps) {
  const scope = `memory:${props.initialContext ? JSON.stringify([props.initialContext.cardId, props.initialContext.storyId]) : 'panel'}`
  return <PersistentEditor remote={props.remote} scope={scope}><MemorySelection {...props} /></PersistentEditor>
}

function MemorySelection(props: MemorySectionProps) {
  const [cardId, setCardId] = useDraftState('memory:cardId', props.initialContext?.cardId ?? '')
  // 空字符串可在 JSON 中保留“初始状态”选择；undefined 会丢键，恢复时误回落聊天入口原剧情。
  const [storedStoryId, setStoredStoryId] = useDraftState('memory:storyId', props.initialContext?.storyId ?? '')
  const storyId = storedStoryId || undefined
  // 剧情切换必须重建所有编辑状态：禁止旧 journal 查询或旧字段值进入新剧情。
  return <MemoryContextSection key={JSON.stringify([cardId, storyId ?? null])} remote={props.remote}
    cardId={cardId} storyId={storyId} setCardId={setCardId} setStoryId={(value) => setStoredStoryId(value ?? '')} />
}

function MemoryContextSection(props: { remote: TavernRemote; cardId: string; storyId?: string;
  setCardId: (cardId: string) => void; setStoryId: (storyId: string | undefined) => void }) {
  const { remote } = props
  const { cardId, storyId, setCardId, setStoryId } = props
  const t = useT()
  const chars = useLoader(() => remote.listCharacters({}), [])
  const stories = useLoader(() => remote.listStories({ cardId }), [cardId], cardId !== '')
  const draftKey = `memory:context:${JSON.stringify([cardId, storyId ?? null])}`
  const [tab, setTab] = useDraftState<'memory' | 'delta' | 'journal'>(`${draftKey}:tab`, 'memory')
  const [error, setError] = useState<string | null>(null)
  const [busy, setBusy] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [editingId, setStoredEditingId] = useDraftState<string | null>(`${draftKey}:editingId`, null)
  // 同批事件也要看到刚打开的编辑器；父列表重载会卸载子编辑器并丢掉其正文。
  const editing = useRef(editingId)
  editing.current = editingId
  const pending = useRef(false)
  const setEditingId = (id: string | null) => { editing.current = id; setStoredEditingId(id) }
  const [newBody, setNewBody] = useDraftState(`${draftKey}:newBody`, '')
  const [journalText, setJournalText] = useDraftState(`${draftKey}:journalText`, '')
  const journalRestored = useDraftRestored(`${draftKey}:journalText`)
  const firstJournal = useRef(true)
  const [deltaType, setDeltaType] = useDraftState<'add' | 'update' | 'invalidate'>(`${draftKey}:deltaType`, 'add')
  const [deltaContent, setDeltaContent] = useDraftState(`${draftKey}:deltaContent`, '')
  const [deltaRef, setDeltaRef] = useDraftState(`${draftKey}:deltaRef`, '')
  const [deltaKeys, setDeltaKeys] = useDraftState(`${draftKey}:deltaKeys`, '')
  const toast = useToast()

  const memories = useLoader(() => remote.getMemories({ cardId, storyId }), [cardId, storyId], cardId !== '')
  const deltas = useLoader(() => remote.getWorldDeltas({ cardId, storyId }), [cardId, storyId], cardId !== '')
  const journal = useLoader(() => remote.getJournal({ cardId, storyId }), [cardId, storyId], cardId !== '')

  /**
   * 写操作统一外壳：busy 防连击（快速双击重复创建/并发压缩）；
   * 错误信封进 Err（上下文），传输/zod 严格校验的 reject 落 toast，不留未处理 rejection。
   */
  const op = async (fn: () => Promise<void>) => {
    if (pending.current || editing.current !== null) return
    pending.current = true
    try { await runAsync(setBusy, setError, fn, (message) => toast.show(t('memory.opFailed', { message }))) }
    finally { pending.current = false }
  }

  const journalDirty = journal.state.status === 'ready' && journalText !== journal.state.value.text
  const guard = useDraftGuard(journalDirty || !!newBody.trim() || !!deltaContent.trim() || !!deltaRef.trim() || !!deltaKeys.trim(), busy)
  const charItems = chars.state.status === 'ready' ? chars.state.value.items : []
  const memoryItems = memories.state.status === 'ready' ? memories.state.value.items : []
  const deltaItems = deltas.state.status === 'ready' ? deltas.state.value.items : []
  // keyed 上下文首挂时字段已从对应剧情恢复；首次查询不能覆盖它，后续保存重拉正常同步。
  useEffect(() => {
    if (journal.state.status !== 'ready') return
    if (!firstJournal.current || !journalRestored) setJournalText(journal.state.value.text)
    firstJournal.current = false
  }, [journal.state])
  useEffect(() => {
    // 恢复期间条目可能已被其他窗口删除；释放选择器，避免不存在的编辑器永久锁住上下文。
    if (memories.state.status === 'ready' && editingId !== null && !memories.state.value.items.some((entry) => entry.id === editingId)) {
      setEditingId(null)
    }
  }, [memories.state, editingId])

  const addMemory = () =>
    op(async () => {
      const r = await remote.saveMemory({ cardId, storyId, body: newBody.trim() })
      const err = errOf(r)
      if (err) setError(err)
      else {
        setNewBody('')
        memories.reload()
      }
    })

  const deleteMemory = (id: string) =>
    op(async () => {
      const r = await remote.deleteMemory({ cardId, storyId, id })
      const err = errOf(r)
      if (err) setError(err)
      else memories.reload()
    })

  const compress = () =>
    op(async () => {
      const r = await remote.compressMemories({ cardId, storyId })
      if (!r.ok) setError(r.error.message)
      else {
        toast.show(r.value.merged > 0 ? t('memory.compressed', { count: r.value.merged }) : t('memory.compressNoop'))
        memories.reload()
      }
    })

  const revoke = (id: string) =>
    op(async () => {
      const r = await remote.revokeWorldDelta({ cardId, storyId, id })
      const err = errOf(r)
      if (err) setError(err)
      else {
        toast.show(t('memory.revokeDone', { id }))
        deltas.reload()
      }
    })

  const exportBook = () =>
    op(async () => {
      const r = await remote.exportMergedLorebook({ cardId, storyId })
      if (!r.ok) setError(r.error.message)
      else {
        downloadJson(`lorebook-merged-${cardId}.json`, r.value.json)
        toast.show(t('memory.bookExported'))
      }
    })

  const saveJournal = () =>
    op(async () => {
      const r = await remote.saveJournal({ cardId, storyId, text: journalText })
      const err = errOf(r)
      if (err) setError(err)
      else {
        toast.show(t('memory.journalSaved'))
        journal.reload()
      }
    })

  const addDelta = () =>
    op(async () => {
      const r = await remote.addWorldDelta({
        cardId, storyId,
        type: deltaType,
        content: deltaContent.trim(),
        ref: deltaRef.trim() || null,
        keys: splitList(deltaKeys),
      })
      const err = errOf(r)
      if (err) setError(err)
      else {
        toast.show(t('memory.deltaAdded', { id: r.ok ? r.value.id : '' }))
        setDeltaContent('')
        setDeltaRef('')
        setDeltaKeys('')
        deltas.reload()
      }
    })

  return (
    <Section title={t('section.memory')} description={t('memory.desc')}>
      {toast.node}
      {guard.confirmation}
      <ConfirmDialog open={deleteId !== null} title={t('memory.deleteEntry')} description={t('memory.deleteConfirm')}
        confirmLabel={t('action.delete')} danger busy={busy} onCancel={() => { if (!busy) setDeleteId(null) }}
        onConfirm={() => { if (deleteId) void deleteMemory(deleteId).then(() => setDeleteId(null)) }} />
      <SettingsRow title={t('memory.character')} description={t('memory.characterDesc')}>
        <Select
          size="md"
          value={cardId}
          disabled={busy || editingId !== null || chars.state.status !== 'ready'} onChange={(value) => guard.request(() => { setStoryId(undefined); setCardId(value) })}
          options={[{ value: '', label: t('memory.pickCharacter') }, ...charItems.map((c) => ({ value: c.cardId, label: c.name }))]}
        />
      </SettingsRow>
      {cardId && <SettingsRow title={t('memory.story')} description={t('memory.storyDesc')}>
        <Select value={storyId ?? ''} disabled={busy || editingId !== null || stories.state.status !== 'ready'} onChange={(value) => guard.request(() => setStoryId(value || undefined))}
          options={[{ value: '', label: t('memory.initialState') }, ...(stories.state.status === 'ready' ? stories.state.value.items.map((story, index) => ({ value: story.id, label: t('memory.storyLabel', { index: index + 1, date: story.createdAt.slice(0, 10) }) })) : [])]} />
      </SettingsRow>}
      {cardId && <div className="dsh-tavern-storyContext" role="status">
        <div className="dsh-tavern-storyContextTitle">
          <strong>{charItems.find((c) => c.cardId === cardId)?.name ?? t('memory.character')}</strong>
          <Badge accent={!!storyId}>{t(storyId ? 'memory.scopeStory' : 'memory.scopeInitial')}</Badge>
        </div>
        <span>{t(storyId ? 'memory.scopeStoryDesc' : 'memory.scopeInitialDesc')}</span>
        {storyId && <span className="dsh-tavern-muted">{stories.state.status === 'ready'
          ? stories.state.value.items.find((s) => s.id === storyId)?.sessionId ?? storyId : storyId}</span>}
      </div>}
      <Err message={chars.state.status === 'error' ? chars.state.message : stories.state.status === 'error' ? stories.state.message : error} />
      {chars.state.status === 'error' && <Btn disabled={busy} onClick={chars.reload}>{t('action.retry')}</Btn>}
      {stories.state.status === 'error' && <Btn disabled={busy} onClick={stories.reload}>{t('action.retry')}</Btn>}
      {cardId && (
        <>
          <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 10, margin: '10px 0 14px' }}>
            <div className="dsh-tavern-filters" role="group" aria-label={t('section.memory')}>
              <button type="button" aria-pressed={tab === 'memory'} className="dsh-tavern-chip" data-active={tab === 'memory' ? 'true' : 'false'} disabled={busy || editingId !== null} onClick={() => setTab('memory')}>
                {t('memory.tab.memory', { count: memoryItems.length })}
              </button>
              <button type="button" aria-pressed={tab === 'delta'} className="dsh-tavern-chip" data-active={tab === 'delta' ? 'true' : 'false'} disabled={busy || editingId !== null} onClick={() => setTab('delta')}>
                {t('memory.tab.delta', { count: deltaItems.length })}
              </button>
              <button type="button" aria-pressed={tab === 'journal'} className="dsh-tavern-chip" data-active={tab === 'journal' ? 'true' : 'false'} disabled={busy || editingId !== null} onClick={() => setTab('journal')}>
                {t('memory.tab.journal')}
              </button>
            </div>
            <span style={{ flex: 1 }} />
            {tab === 'memory' && <Btn disabled={busy || editingId !== null} onClick={() => void compress()}>{t('memory.compressOldest')}</Btn>}
            {tab === 'delta' && <Btn disabled={busy} onClick={() => void exportBook()}>{t('memory.exportBook')}</Btn>}
          </div>
          {tab === 'memory' && (
            <div className="dsh-tavern-list">
              {memories.state.status === 'loading' && (
                <>
                  <Skeleton height={72} />
                  <Skeleton height={72} />
                  <Skeleton height={72} />
                </>
              )}
              {memories.state.status === 'error' && <><Err message={memories.state.message} /><Btn disabled={busy} onClick={memories.reload}>{t('action.retry')}</Btn></>}
              {memoryItems.length === 0 && memories.state.status === 'ready' && (
                <div className="dsh-tavern-empty is-compact">
                  <div className="dsh-tavern-emptyTitle">{t('memory.emptyMemories')}</div>
                  <div className="dsh-tavern-emptyDesc">{t('memory.emptyMemoriesDesc')}</div>
                </div>
              )}
              {memoryItems.map((m) => (
                <div key={m.id} className="dsh-tavern-memo">
                  <div className="dsh-tavern-memoHead">
                    <Badge>{m.id}</Badge>
                    {m.archived ? <Badge>{t('memory.archived')}</Badge> : null}
                    {m.tags.map((tag) => (
                      <Badge key={tag}>{tag}</Badge>
                    ))}
                    <span className="dsh-tavern-memoMeta">{m.updated}</span>
                    <span className="dsh-tavern-memoActions">
                      <IconBtn disabled={editingId !== null || busy} label={t('action.edit')} onClick={() => { if (!pending.current && editing.current === null) setEditingId(m.id) }}>
                        <IconEditOutlineMedium />
                      </IconBtn>
                      <IconBtn label={t('memory.deleteEntry')} danger disabled={busy || editingId !== null} onClick={() => setDeleteId(m.id)}>
                        <IconTrashOutlineMedium />
                      </IconBtn>
                    </span>
                  </div>
                  <pre className="dsh-tavern-memoBody dsh-tavern-scroll">{m.body}</pre>
                  {editingId === m.id && (
                    <MemoryEditor
                      remote={remote}
                      cardId={cardId}
                      storyId={storyId}
                      entry={m}
                      onDone={() => {
                        setEditingId(null)
                        memories.reload()
                      }}
                    />
                  )}
                </div>
              ))}
              <div className="dsh-tavern-memo is-compose">
                <textarea
                  className="dsh-tavern-input dsh-tavern-textarea"
                  aria-label={t('memory.entryBody')}
                  style={{ minHeight: 60 }}
                  placeholder={t('memory.newPlaceholder')}
                  disabled={busy}
                  value={newBody}
                  onChange={(e) => setNewBody(e.target.value)}
                />
                <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                  <Btn primary disabled={busy || editingId !== null || !newBody.trim()} onClick={() => void addMemory()}>{t('memory.addEntry')}</Btn>
                </div>
              </div>
            </div>
          )}
          {tab === 'delta' && (
            <div className="dsh-tavern-list">
              {deltas.state.status === 'loading' && (
                <>
                  <Skeleton height={72} />
                  <Skeleton height={72} />
                  <Skeleton height={72} />
                </>
              )}
              {deltas.state.status === 'error' && <><Err message={deltas.state.message} /><Btn disabled={busy} onClick={deltas.reload}>{t('action.retry')}</Btn></>}
              {deltaItems.map((d: WorldDelta) => (
                <div key={d.id} className={`dsh-tavern-memo${d.revoked ? ' is-revoked' : ''}`}>
                  <div className="dsh-tavern-memoHead">
                    <Badge>#{d.id}</Badge>
                    <Badge danger={d.type === 'invalidate'}>{t(DELTA_TYPE_KEY[d.type])}</Badge>
                    {d.ref ? <Badge>→ {d.ref}</Badge> : null}
                    {d.revoked ? <Badge danger>{t('memory.revoked')}</Badge> : null}
                    <span className="dsh-tavern-memoMeta">{d.ts}</span>
                    {!d.revoked && (
                      <span className="dsh-tavern-memoActions">
                        <Btn size="sm" disabled={busy} onClick={() => void revoke(d.id)}>{t('memory.revoke')}</Btn>
                      </span>
                    )}
                  </div>
                  <pre className="dsh-tavern-memoBody dsh-tavern-scroll">{d.content}</pre>
                </div>
              ))}
              {deltaItems.length === 0 && deltas.state.status === 'ready' && (
                <div className="dsh-tavern-empty is-compact">
                  <div className="dsh-tavern-emptyTitle">{t('memory.emptyDeltas')}</div>
                  <div className="dsh-tavern-emptyDesc">{t('memory.emptyDeltasDesc')}</div>
                </div>
              )}
              <div className="dsh-tavern-memo is-compose">
                <div className="dsh-tavern-fieldRow">
                  <label className="dsh-tavern-field">
                    <span className="dsh-tavern-fieldLabel">{t('memory.deltaType')}</span>
                    <Select
                      size="md"
                      value={deltaType}
                      disabled={busy}
                      onChange={(v) => setDeltaType(v as 'add' | 'update' | 'invalidate')}
                      options={[
                        { value: 'add', label: t(DELTA_TYPE_KEY.add) },
                        { value: 'update', label: t(DELTA_TYPE_KEY.update) },
                        { value: 'invalidate', label: t(DELTA_TYPE_KEY.invalidate) },
                      ]}
                    />
                  </label>
                  {(deltaType === 'update' || deltaType === 'invalidate') && (
                    <label className="dsh-tavern-field">
                      <span className="dsh-tavern-fieldLabel">{t('memory.deltaRef')}</span>
                      <input className="dsh-tavern-input" disabled={busy} value={deltaRef} onChange={(e) => setDeltaRef(e.target.value)} />
                    </label>
                  )}
                </div>
                <textarea
                  className="dsh-tavern-input dsh-tavern-textarea"
                  aria-label={t('memory.deltaBodyPlaceholder')}
                  style={{ minHeight: 60, marginTop: 8 }}
                  placeholder={t('memory.deltaBodyPlaceholder')}
                  disabled={busy}
                  value={deltaContent}
                  onChange={(e) => setDeltaContent(e.target.value)}
                />
                <label className="dsh-tavern-field" style={{ marginTop: 8 }}>
                  <span className="dsh-tavern-fieldLabel">{t('memory.deltaKeys')}</span>
                  <input className="dsh-tavern-input" disabled={busy} value={deltaKeys} onChange={(e) => setDeltaKeys(e.target.value)} />
                </label>
                <div style={{ display: 'flex', justifyContent: 'flex-end', marginTop: 8 }}>
                  <Btn primary disabled={busy || !deltaContent.trim()} onClick={() => void addDelta()}>{t('memory.addDelta')}</Btn>
                </div>
              </div>
            </div>
          )}
          {tab === 'journal' && (
            <div className="dsh-tavern-list">
              <Muted>{t('memory.journalHint')}</Muted>
              {/* 加载期只出骨架：输入框和骨架并排渲染的话，正文还是上一张卡的，保存就会覆盖当前卡。 */}
              {journal.state.status === 'ready' ? (
                <textarea
                  className="dsh-tavern-input dsh-tavern-textarea"
                  aria-label={t('memory.tab.journal')}
                  style={{ minHeight: 180 }}
                  disabled={busy}
                  value={journalText}
                  onChange={(e) => setJournalText(e.target.value)}
                />
              ) : journal.state.status === 'error' ? (
                <><Err message={journal.state.message} /><Btn disabled={busy} onClick={journal.reload}>{t('action.retry')}</Btn></>
              ) : (
                <Skeleton height={180} />
              )}
              <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Btn primary disabled={busy || !journalDirty || journal.state.status !== 'ready' || !cardId} onClick={() => void saveJournal()}>{t('memory.saveJournal')}</Btn>
              </div>
            </div>
          )}
        </>
      )}
    </Section>
  )
}
