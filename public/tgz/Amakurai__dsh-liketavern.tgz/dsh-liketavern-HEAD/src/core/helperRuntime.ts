/** 酒馆助手运行层的数据契约和有界 JSON 校验；浏览器与持久层共享，不执行第三方函数。 */
import type {HelperSwipeSet} from './helperSwipes.js'
export type HelperTable = Record<string, unknown>
export type HelperScopes = Record<string, HelperTable>
export interface HelperMessage {
  message_id: number
  name: string
  role: 'user' | 'assistant' | 'system'
  is_hidden: boolean
  message: string
  data: HelperTable
  extra: HelperTable
  swipe?: HelperSwipeSet
}
export interface HelperSnapshot {
  storyId: string
  historyRevision: string
  currentMessageId: number
  messages: HelperMessage[]
  scopes: HelperScopes
  writable: boolean
}
/** 一批展示气泡共用的快照公共部分；各气泡只差 currentMessageId。 */
export type HelperSnapshotBase = Omit<HelperSnapshot, 'currentMessageId'>
/** 由共享公共部分派生单个气泡快照：messages/scopes 共用引用，字段顺序与逐条快照一致。 */
export function helperSnapshotAt(base: HelperSnapshotBase, currentMessageId: number): HelperSnapshot {
  return { storyId: base.storyId, historyRevision: base.historyRevision, currentMessageId, writable: base.writable, scopes: base.scopes, messages: base.messages }
}
/**
 * 普通文本气泡只需这些不可写身份字段来匹配脚本选项并发送展示事件。
 * 完整消息、变量和写能力只随真正的 iframe 卡面传输，避免历史列表按气泡重复回传。
 */
export interface HelperDisplayContext {
  readonly storyId: string
  readonly historyRevision: string
  readonly currentMessageId: number
  readonly currentMessageRole: 'user' | 'assistant'
}
export interface HelperVariableChange { key: string; before: HelperTable; value: HelperTable }
export const HELPER_MAX_BYTES = 1024 * 1024
export function helperRecord(value: unknown): value is HelperTable {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false
  const prototype = Object.getPrototypeOf(value)
  return prototype === Object.prototype || prototype === null
}
/** 不求值 getter/toJSON；拒绝污染键、循环、非有限数和超深数据，再复制普通 JSON。 */
export function helperJson(value: unknown, maxBytes=HELPER_MAX_BYTES): unknown {
  let bytes = 0
  const active = new Set<object>(), encoder = new TextEncoder()
  function walk(item: unknown, depth: number): unknown {
    if (depth > 64) throw new Error('酒馆助手数据嵌套超过 64 层')
    let result: unknown
    if (item === null || typeof item === 'boolean') { bytes += 5; result = item }
    else if (typeof item === 'string') { bytes += encoder.encode(JSON.stringify(item)).length; result = item }
    else if (typeof item === 'number' && Number.isFinite(item)) { bytes += String(item).length; result = item }
    else {
      if (!item || typeof item !== 'object' || (!Array.isArray(item) && !helperRecord(item))) throw new Error('酒馆助手只接受普通 JSON 数据')
      if (active.has(item) || Object.getOwnPropertySymbols(item).length) throw new Error('酒馆助手数据不能包含循环或 Symbol')
      active.add(item); bytes += 2
      const descriptors = Object.getOwnPropertyDescriptors(item)
      if (Array.isArray(item)) {
        if (Object.keys(descriptors).length !== item.length + 1) throw new Error('酒馆助手数组必须连续')
        result = Array.from({length:item.length}, (_, index) => {
          const descriptor = descriptors[String(index)]
          if (!descriptor || !('value' in descriptor) || !descriptor.enumerable) throw new Error('酒馆助手数组不能包含访问器')
          bytes++; return walk(descriptor.value, depth + 1)
        })
      } else {
        const output: HelperTable = {}
        for (const key of Object.keys(descriptors).sort()) {
          const descriptor = descriptors[key]!
          if (['__proto__', 'constructor', 'prototype'].includes(key) || !('value' in descriptor) || !descriptor.enumerable) throw new Error('酒馆助手数据包含非法字段')
          bytes += encoder.encode(JSON.stringify(key)).length + 2
          output[key] = walk(descriptor.value, depth + 1)
        }
        result = output
      }
      active.delete(item)
    }
    if (bytes > maxBytes) throw new Error('酒馆助手数据超过预算')
    return result
  }
  return walk(value, 0)
}
export function helperTable(value: unknown): HelperTable {
  if (!helperRecord(value)) throw new Error('酒馆助手变量表必须是普通对象')
  return helperJson(value) as HelperTable
}
export function helperScopeKey(key: string): [string, string | number] {
  if (typeof key !== 'string' || key.length > 512) throw new Error('酒馆助手变量作用域无效')
  const parts: unknown = JSON.parse(key)
  if (!Array.isArray(parts) || parts.length !== 2 || JSON.stringify(parts) !== key) throw new Error('酒馆助手变量作用域无效')
  const [type, id] = parts
  if (!['global','character','preset','chat','message','script','extension'].includes(type)
    || !(typeof id === 'string' && id.length <= 256 || Number.isSafeInteger(id) && id >= 0)
    || ['global','character','preset','chat'].includes(type) && id !== '') throw new Error('酒馆助手变量作用域无效')
  return [type, id]
}
export function helperChanges(value: unknown): HelperVariableChange[] {
  const parsed = helperJson(value,3*HELPER_MAX_BYTES)
  if (!Array.isArray(parsed) || !parsed.length || parsed.length > 64) throw new Error('酒馆助手单次更新需包含 1–64 个变量表')
  const seen = new Set<string>()
  return parsed.map(item => {
    if (!helperRecord(item) || typeof item.key !== 'string' || !helperRecord(item.before) || !helperRecord(item.value)
      || Object.keys(item).some(key => !['key','before','value'].includes(key)) || seen.has(item.key)) throw new Error('酒馆助手变量更新无效或重复')
    helperScopeKey(item.key); seen.add(item.key)
    return {key:item.key,before:item.before,value:item.value}
  })
}
