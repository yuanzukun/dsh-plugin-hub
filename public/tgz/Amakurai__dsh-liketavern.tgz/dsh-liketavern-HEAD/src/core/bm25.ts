/**
 * BM25 内存检索索引。
 * 纯内存态、零依赖；分词复用 tokenize 模块，CJK bigram 与 ASCII 词天然同权。
 * 文档占用数值槽位，倒排表按槽位存平行数组；查询用定长数组累加，不逐条查字符串表。
 * bigram 文字的每个字另有一套倒排表：在库里或在查询里单独成词的字，检索时作为半权重的单字词，
 * 补上 bigram 表达不了的单字名与单字名词。
 */

import { isSeparatorChar, isStopBigram, isStopChar, isStopWord, isWeakBigram } from './stopwords.js'
import { analyzeText, isBigramTerm, isKana, tokenize, type TextTokens } from './tokenize.js'

// ---------------------------------------------------------------------------
// 公开契约
// ---------------------------------------------------------------------------

/** 关键词每出现一次折算的词频；正文出现一次计 1。 */
const KEY_WEIGHT = 2

/** 单字词相对 bigram / 整词的权重：单字是弱证据，同一个字出现在不同的词里并不代表相关。 */
const CHAR_WEIGHT = 0.5

/**
 * 由两个功能字组成、又不是确定的功能词的 bigram 在查询里的权重：多半是跨词的碎片（来一、里有），
 * 也可能是名字（日向、五月），分不清，所以不剔除、只减半。被 key 声明过的不减。
 */
const WEAK_TERM_WEIGHT = 0.5

/** 出现在超过这一比例文档里的字没有区分度，不作为单字词（keys 声明和纯单字查询除外）。 */
const CHAR_MAX_DF_RATIO = 0.5

/**
 * 上面的比例只在库够大时才有意义：刚开始的剧情只有三五条记忆，主角的名字出现在大半条里很正常。
 * 出现在不超过这么多条文档里的字不按比例排除。
 */
const CHAR_DF_FLOOR = 10

/** 一个字在某一侧至少要有这么多种不同的邻接情况，才算能产的构词成分（只作次级证据）。 */
const CHAR_MIN_ACCESSORS = 2

/** 单字词的两档证据：primary 可以单独带出命中，secondary 只给已有命中加分。 */
type CharEvidence = 'primary' | 'secondary'

/**
 * 写入文档。keys 为写入时提炼的关键词：每次出现按 2 倍词频计入，但不计入文档长度，
 * 否则关键词多的条目（如合并了来源 keys 的摘要）会被长度归一化压低。
 * 只有一个字或一个词的 key 同时把它声明为词：此后无论它多常见、是否在功能词表里，都照常参与检索。
 * ts 供时间衰减使用。
 */
export interface Bm25Doc<D = unknown> {
  id: string
  text: string
  keys?: string[]
  /**
   * 写入之后补上的检索别名（同义说法、类别、名字）。与 keys 一样不计入文档长度，只有一个字或一个词的别名
   * 同样把它声明为词；但别名是推测出来的，词频按正文的 1 倍计，不按关键词的 2 倍。
   */
  aliases?: readonly string[]
  /** 毫秒时间戳；仅在 search 指定 halfLifeMs 时参与衰减。 */
  ts?: number
  data?: D
}

export interface Bm25SearchOptions {
  /** 返回条数上限，默认 10。 */
  topK?: number
  /** 半衰期（毫秒）；> 0 且文档带 ts 时启用时间衰减。 */
  halfLifeMs?: number
  /** 「现在」的毫秒时间戳，默认 Date.now()；测试注入以保证确定性。 */
  now?: number
  /**
   * 需要强调的查询片段：其中的词在主查询的 1 倍之外再加 weight 倍得分（片段里的词不必出现在主查询中）。
   * 分数与主查询同一量纲，命中越强加得越多，弱命中不会因此越过主查询的强命中。weight 非正或片段为空时忽略。
   */
  boost?: { query: string; weight: number }
  /**
   * 本次查询里另外当作「已声明的词」的名字（角色名、用户人设名）：效果与写成单字 / 单词 key 相同，
   * 只对这一次查询有效。名字正好是功能字或由功能字组成时（七、月、日向）靠它检索。多于一个词的名字不声明。
   */
  names?: readonly string[]
  /**
   * 查询是使用者明确给出的检索词（记忆检索工具），不是从对话里拼出来的。这时只搜一个或几个孤立的字，
   * 就按字面匹配，功能字和假名也不例外；自动入模不设，免得一句「好。」带出所有含「好」的记忆。
   */
  explicit?: boolean
}

export interface Bm25Hit<D = unknown> {
  id: string
  score: number
  data?: D
}

// ---------------------------------------------------------------------------
// 索引实现
// ---------------------------------------------------------------------------

/** 三套倒排表在文档条目上各自的下标表字段名。 */
type PositionField = 'positions' | 'charPositions' | 'edgePositions'

interface DocEntry<D> {
  id: string
  /** 在 slots / lengths 中的下标；删除后回收复用。 */
  slot: number
  /** 文档长度：正文 token 数，不含 keys。 */
  length: number
  /** term → 本文档在该词倒排表里的下标，删除时 O(1) 定位。 */
  positions: Map<string, number>
  /** 单字 → 本文档在该字倒排表里的下标。 */
  charPositions: Map<string, number>
  /** 边界特征 → 本文档在该特征倒排表里的下标。 */
  edgePositions: Map<string, number>
  ts?: number
  data?: D
}

/** 一个词的倒排表：命中文档槽位与对应加权词频，两个数组等长同序；长度就是 df。 */
interface Posting {
  slots: number[]
  tfs: number[]
}

/**
 * 特征倒排表的键：字出现在一段文字的开头、结尾；字在某处单独成词；字在某处左侧、右侧是词的边界；
 * 字或词被只含它自己的 key 声明为词。只用到这些特征的文档数。
 */
const edgeInitial = (char: string): string => `^${char}`
const edgeFinal = (char: string): string => `${char}$`
const edgeWord = (char: string): string => `~${char}`
const edgeLeft = (char: string): string => `<${char}`
const edgeRight = (char: string): string => `${char}>`
const edgeDeclared = (token: string): string => `=${token}`

/** 一段只含一个字或一个词的文本所声明的那个词；多于一个词时不声明任何东西。 */
function declaredToken(tokens: TextTokens): string | undefined {
  if (tokens.terms.length === 0 && tokens.chars.length === 1) return tokens.chars[0]
  if (tokens.terms.length !== 1) return undefined
  const term = tokens.terms[0]!
  // bigram 必须正好覆盖两个字；整词旁不能再有单字片段（如 I型、现在 凛）。
  return tokens.chars.length === (isBigramTerm(term) ? 2 : 0) ? term : undefined
}

/** 名字里的分隔符：空白与间隔号。「艾琳·冯」「日向 夏帆」的每一段各自声明。 */
const NAME_SEPARATORS = /[\s·・•‧]+/u

/** 分数降序；并列按 id 字典序升序，保证结果确定可复现。 */
function byScoreThenId(a: Bm25Hit, b: Bm25Hit): number {
  return b.score - a.score || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0)
}

/** 与 slice(0, topK) 的有效上限一致；Infinity 取全量，NaN/负数/不足一条提前返回。 */
function resultLimit(topK: number, size: number): number {
  return Number.isNaN(topK) ? 0 : Math.min(size, Math.max(0, Math.floor(topK)))
}

/**
 * 只保留最优 K 条：堆顶是当前最差项，同分时较大的 id 更差。
 * 先完成衰减和全部加分再提交；最终只排序留下的 K 条，避免为大量落选项创建结果对象。
 * K 已覆盖所有候选时直接收集，省去维护堆的成本。
 */
class TopHits<D> {
  private readonly hits: Array<Bm25Hit<D>> = []
  private readonly bounded: boolean
  private readonly limit: number
  constructor(limit: number, candidates: number) {
    this.limit = limit
    this.bounded = limit < candidates
  }

  add(entry: DocEntry<D>, score: number): void {
    const { hits, limit } = this
    if (hits.length === limit) {
      const worst = hits[0]!
      if (score < worst.score || (score === worst.score && entry.id >= worst.id)) return
      const hit: Bm25Hit<D> = { id: entry.id, score }
      if (entry.data !== undefined) hit.data = entry.data
      let position = 0
      // 沿更差的子节点下沉，直到新项不优于任何子节点。
      while (position * 2 + 1 < hits.length) {
        let child = position * 2 + 1
        if (child + 1 < hits.length && byScoreThenId(hits[child + 1]!, hits[child]!) > 0) child++
        if (byScoreThenId(hit, hits[child]!) >= 0) break
        hits[position] = hits[child]!
        position = child
      }
      hits[position] = hit
      return
    }
    const hit: Bm25Hit<D> = { id: entry.id, score }
    if (entry.data !== undefined) hit.data = entry.data
    let position = hits.length
    hits.push(hit)
    if (!this.bounded) return
    while (position > 0) {
      const parent = (position - 1) >>> 1
      if (byScoreThenId(hit, hits[parent]!) <= 0) break
      hits[position] = hits[parent]!
      position = parent
    }
    hits[position] = hit
  }

  sorted(): Array<Bm25Hit<D>> {
    return this.hits.sort(byScoreThenId)
  }
}

export class Bm25Index<D = unknown> {
  private readonly k1: number
  private readonly b: number
  private readonly docs = new Map<string, DocEntry<D>>()
  private readonly slots: Array<DocEntry<D> | undefined> = []
  private readonly lengths: number[] = []
  private readonly freeSlots: number[] = []
  private readonly postings = new Map<string, Posting>()
  /** 单字倒排表：与 postings 分开，既不计入文档长度，也不参与写入去重的相似度。 */
  private readonly charPostings = new Map<string, Posting>()
  /** 边界特征倒排表：只用它的文档数判断一个字是否独立成词。 */
  private readonly edgePostings = new Map<string, Posting>()
  /** 字 → 以它开头 / 结尾的不同 bigram 数，即它右侧 / 左侧出现过多少种不同的字。 */
  private readonly followers = new Map<string, number>()
  private readonly leaders = new Map<string, number>()
  private totalLength = 0
  /**
   * search 复用的按槽位寻址的缓冲。每次查询结束只把用过的槽位清零，
   * 稀疏查询不必为全库分配并清零一遍。search 是同步的，不会重入。
   */
  private scores = new Float64Array(0)
  private norms = new Float64Array(0)
  private seen = new Uint8Array(0)

  constructor(options?: { k1?: number; b?: number }) {
    this.k1 = options?.k1 ?? 1.5
    this.b = options?.b ?? 0.75
  }

  get size(): number {
    return this.docs.size
  }

  has(id: string): boolean {
    return this.docs.has(id)
  }

  /** 同 id 重复 add = 覆盖（先撤掉旧统计再计入新文档）。 */
  add(doc: Bm25Doc<D>): void {
    this.remove(doc.id)
    const tf = new Map<string, number>()
    const charTf = new Map<string, number>()
    const edges = new Map<string, number>()
    const count = (tokens: TextTokens, weight: number): void => {
      for (const term of tokens.terms) tf.set(term, (tf.get(term) ?? 0) + weight)
      for (const char of tokens.chars) charTf.set(char, (charTf.get(char) ?? 0) + weight)
      for (const char of tokens.initials) edges.set(edgeInitial(char), 1)
      for (const char of tokens.finals) edges.set(edgeFinal(char), 1)
      for (const char of tokens.words) edges.set(edgeWord(char), 1)
      for (const char of tokens.lefts) edges.set(edgeLeft(char), 1)
      for (const char of tokens.rights) edges.set(edgeRight(char), 1)
    }
    const body = analyzeText(doc.text)
    count(body, 1)
    const label = (text: string, weight: number): void => {
      const tokens = analyzeText(text)
      count(tokens, weight)
      // 整个 key 只有一个字或一个词：写的人把它当作一个词
      const token = declaredToken(tokens)
      if (token !== undefined) edges.set(edgeDeclared(token), 1)
    }
    for (const key of doc.keys ?? []) label(key, KEY_WEIGHT)
    for (const alias of doc.aliases ?? []) label(alias, 1)
    const length = body.terms.length
    const slot = this.freeSlots.pop() ?? this.slots.length
    const entry: DocEntry<D> = {
      id: doc.id, slot, length,
      positions: this.attach(this.postings, tf, slot),
      charPositions: this.attach(this.charPostings, charTf, slot),
      edgePositions: this.attach(this.edgePostings, edges, slot),
      ts: doc.ts, data: doc.data,
    }
    this.docs.set(doc.id, entry)
    this.slots[slot] = entry
    this.lengths[slot] = length
    this.totalLength += length
  }

  /** 把一篇文档的词频挂进倒排表，返回各词在倒排表里的下标。 */
  private attach(postings: Map<string, Posting>, frequencies: Map<string, number>, slot: number): Map<string, number> {
    const positions = new Map<string, number>()
    for (const [term, frequency] of frequencies) {
      let posting = postings.get(term)
      if (!posting) {
        posting = { slots: [], tfs: [] }
        postings.set(term, posting)
        if (postings === this.postings) this.noteBigram(term, 1)
      }
      positions.set(term, posting.slots.length)
      posting.slots.push(slot)
      posting.tfs.push(frequency)
    }
    return positions
  }

  /** 从倒排表撤下一篇文档；field 指明被挪动的文档该更新哪一张下标表。 */
  private detach(postings: Map<string, Posting>, positions: Map<string, number>, field: PositionField): void {
    for (const [term, position] of positions) {
      const posting = postings.get(term)!
      const last = posting.slots.length - 1
      // 把末位文档挪到空出的位置再弹出末位；倒排表内顺序不影响评分。
      if (position !== last) {
        const moved = this.slots[posting.slots[last]!]!
        posting.slots[position] = moved.slot
        posting.tfs[position] = posting.tfs[last]!
        moved[field].set(term, position)
      }
      posting.slots.pop()
      posting.tfs.pop()
      if (last === 0) {
        postings.delete(term)
        if (postings === this.postings) this.noteBigram(term, -1)
      }
    }
  }

  /** 词典里新增或删掉一个 bigram 时，更新两个字各自的邻接种类数。 */
  private noteBigram(term: string, delta: 1 | -1): void {
    if (!isBigramTerm(term)) return
    const bump = (counts: Map<string, number>, char: string): void => {
      const value = (counts.get(char) ?? 0) + delta
      if (value > 0) counts.set(char, value)
      else counts.delete(char)
    }
    bump(this.followers, term[0]!)
    bump(this.leaders, term[1]!)
  }

  remove(id: string): void {
    const entry = this.docs.get(id)
    if (!entry) return
    this.docs.delete(id)
    this.totalLength -= entry.length
    this.detach(this.postings, entry.positions, 'positions')
    this.detach(this.charPostings, entry.charPositions, 'charPositions')
    this.detach(this.edgePostings, entry.edgePositions, 'edgePositions')
    this.slots[entry.slot] = undefined
    this.lengths[entry.slot] = 0
    this.freeSlots.push(entry.slot)
  }

  clear(): void {
    this.docs.clear()
    this.postings.clear()
    this.charPostings.clear()
    this.edgePostings.clear()
    this.followers.clear()
    this.leaders.clear()
    this.slots.length = 0
    this.lengths.length = 0
    this.freeSlots.length = 0
    this.totalLength = 0
  }

  /** Robertson 变体 IDF：ln(1 + (N - df + 0.5)/(df + 0.5))，保证为正。 */
  private idf(df: number): number {
    const docCount = this.docs.size
    return Math.log(1 + (docCount - df + 0.5) / (df + 0.5))
  }

  private edgeCount(key: string): number {
    return this.edgePostings.get(key)?.slots.length ?? 0
  }

  /**
   * 一个字是否是能产的构词成分：左右两侧各至少见过两种不同的邻接——不同的相邻字，或者紧挨着标点、
   * 段首段尾的文档。「打」出现在「打听、打开」里，「面」出现在「后面、见面、表面」里。
   * 这只说明它常用来构词，不说明它单独是一个词，所以只作次级证据：
   * 「周末打算去爬山」不会因为一个「打」字带出「打听」「打开」所在的记忆。
   */
  private productive(char: string): boolean {
    return (this.leaders.get(char) ?? 0) + this.edgeCount(edgeInitial(char)) >= CHAR_MIN_ACCESSORS
      && (this.followers.get(char) ?? 0) + this.edgeCount(edgeFinal(char)) >= CHAR_MIN_ACCESSORS
  }

  /**
   * 查询里的这个字能否作为单字词，以及算哪一档证据。
   * - 被单字 key 或别名声明过的字、本次查询给出的名字始终是主证据（名字正好是功能字、或者极其常见时靠这个）。
   * - 明确给出的检索词只由孤立的单字组成时，一律按字面匹配。
   * - 假名与功能字不用：它们不携带话题信息。
   * - 整个查询只由孤立的单字组成（如直接搜「樱」）时，用户要的就是这个字，其余条件不再检查。
   * - 出现在超过半数文档里的字不用（库里不到二十条时不按这个比例排除）。
   * - 主证据：库里某处把它单独当词用过（「叫樱，」「凛的」），并且它在这段查询里至少一侧是边界。
   *   两边都要：库里的「礁门自开」不该让「几点开始」命中，问句里的「怎么走」也不该命中「走私」。
   * - 主证据的另一种情况：这段查询只有被虚词隔开的单个字（「豆在哪」「药呢」），除了这个字没有别的可查；
   *   这时库里的证据可以放宽——它在一处开头、在另一处收尾即可（「豆抓伤过」「流浪猫豆是」），不必被同时夹住。
   * - 其余情况，只要它在库里或查询里单独成词过、或者是能产的构词成分，就作次级证据，只给已有命中加分：
   *   「樱的药还够吗」里的「药」能把同时提到樱和取药的那条顶上去，却不会单独带出「火药」。
   */
  private charEvidence(
    char: string,
    query: { declared: boolean; explicit: boolean; isolated: boolean; lone: boolean; word: boolean; edge: boolean },
  ): CharEvidence | undefined {
    const posting = this.charPostings.get(char)
    if (!posting) return undefined
    if (query.declared || (query.explicit && query.isolated)) return 'primary'
    if (isKana(char) || isStopChar(char)) return undefined
    if (query.isolated) return 'primary'
    if (posting.slots.length > Math.max(CHAR_DF_FLOOR, CHAR_MAX_DF_RATIO * this.docs.size)) return undefined
    const wordInStore = this.edgePostings.has(edgeWord(char))
    if (wordInStore && query.edge) return 'primary'
    if (query.lone && this.edgePostings.has(edgeLeft(char)) && this.edgePostings.has(edgeRight(char))) return 'primary'
    return wordInStore || query.word || this.productive(char) ? 'secondary' : undefined
  }

  /**
   * 查询里的这个词按几倍权重参与评分：功能词为 0（不参与），两个功能字组成的其它 bigram 减半，其余为 1。
   * 被 key 声明过的词始终按 1 倍。
   */
  private termScale(term: string, declared: boolean): number {
    if (declared) return 1
    if (isStopBigram(term) || isStopWord(term)) return 0
    return isWeakBigram(term) ? WEAK_TERM_WEIGHT : 1
  }

  search(query: string, options?: Bm25SearchOptions): Array<Bm25Hit<D>> {
    const topK = resultLimit(options?.topK ?? 10, this.docs.size)
    const halfLifeMs = options?.halfLifeMs ?? 0
    const now = options?.now ?? Date.now()
    const docCount = this.docs.size
    if (docCount === 0 || topK <= 0) return []

    // 查询去重：同一 term 重复出现不重复加分；强调片段里的词在主查询的 1 倍之外再加权。
    // 功能词（没有、什么、我们、the、is……）不参与：库不大时它们显得稀有，却只会带来偶然命中。
    // 两个功能字组成的其它 bigram 可能是名字，保留但减半。
    const boost = options?.boost && Number.isFinite(options.boost.weight) && options.boost.weight > 0 ? options.boost : undefined
    const termWeights = new Map<string, number>()
    const named = new Set<string>()
    for (const name of options?.names ?? []) {
      for (const part of name.split(NAME_SEPARATORS)) {
        const token = declaredToken(analyzeText(part))
        // 人设名叫「我」、默认名是 you 之类的不算：声明之后每句话都会命中
        if (token === undefined || isStopWord(token) || isStopBigram(token) || (token.length === 1 && isSeparatorChar(token))) continue
        named.add(token)
      }
    }
    const declared = (token: string): boolean => named.has(token) || this.edgePostings.has(edgeDeclared(token))
    const explicit = options?.explicit === true
    /** 主证据的单字与只加分的单字；一个字在主查询或强调片段任一处算主证据，就整体按主证据计。 */
    const charWeights = new Map<string, number>()
    const extraWeights = new Map<string, number>()
    const weigh = (text: string, weight: number): void => {
      const tokens = analyzeText(text)
      // 功能 bigram 所在位置不再提供单字证据，但不能连带屏蔽其它位置的同字。
      const functional = new Set<string>()
      for (const term of new Set(tokens.terms)) {
        const scale = this.termScale(term, declared(term))
        if (scale > 0) termWeights.set(term, (termWeights.get(term) ?? 0) + weight * scale)
        else if (isBigramTerm(term)) functional.add(term)
      }
      const evidenceTokens = functional.size > 0 ? analyzeText(text, functional) : tokens
      const eligibleChars = new Set(evidenceTokens.chars)
      const isolated = tokens.terms.length === 0
      const words = new Set(evidenceTokens.words)
      const sides = new Set(evidenceTokens.sides)
      for (const char of new Set(tokens.chars)) {
        // 被单字 key 声明过的字例外：「七点」是数词接量词，但「七」是名字
        const known = declared(char)
        if (!known && !eligibleChars.has(char)) continue
        const evidence = this.charEvidence(char, { declared: known, explicit, isolated, lone: tokens.lone, word: words.has(char), edge: sides.has(char) })
        if (!evidence) continue
        const added = weight * CHAR_WEIGHT
        if (evidence === 'primary' || charWeights.has(char)) {
          // 在另一段文本里只算次级的那部分权重，一并转为主证据
          charWeights.set(char, (charWeights.get(char) ?? 0) + (extraWeights.get(char) ?? 0) + added)
          extraWeights.delete(char)
        } else {
          extraWeights.set(char, (extraWeights.get(char) ?? 0) + added)
        }
      }
    }
    weigh(query, 1)
    if (boost) weigh(boost.query, boost.weight)
    if (termWeights.size === 0 && charWeights.size === 0) return []

    if (this.seen.length < this.slots.length) {
      const capacity = Math.max(this.slots.length, this.seen.length * 2)
      this.scores = new Float64Array(capacity)
      this.norms = new Float64Array(capacity)
      this.seen = new Uint8Array(capacity)
    }
    const { k1, b, lengths, scores, norms, seen } = this
    const avgdl = this.totalLength / docCount
    /** 首次命中顺序；只为这些槽位产出结果，不扫全库。 */
    const touched: number[] = []
    const accumulate = (posting: Posting, weight: number): void => {
      const { slots, tfs } = posting
      const df = slots.length
      const idf = this.idf(df)
      for (let i = 0; i < df; i++) {
        const slot = slots[i]!
        if (seen[slot] === 0) {
          seen[slot] = 1
          touched.push(slot)
          // 全部正文为空（只有 keys）时没有长度信息，归一化因子取 1。
          norms[slot] = avgdl > 0 ? 1 - b + (b * lengths[slot]!) / avgdl : 1
        }
        const tf = tfs[i]!
        scores[slot] = scores[slot]! + weight * ((idf * tf * (k1 + 1)) / (tf + k1 * norms[slot]!))
      }
    }
    try {
      for (const [term, weight] of termWeights) {
        const posting = this.postings.get(term)
        if (posting) accumulate(posting, weight)
      }
      for (const [char, weight] of charWeights) accumulate(this.charPostings.get(char)!, weight)
      // 次级证据放在最后：只加到此时已经命中的文档上，不新增命中
      for (const [char, weight] of extraWeights) {
        const { slots, tfs } = this.charPostings.get(char)!
        const idf = this.idf(slots.length)
        // 主证据很稀疏时，只核对已有候选的单字位置；否则顺序遍历短倒排表。
        // Map 查询比数组访问贵，只有候选显著更少时才切换，且两路都不新增命中。
        if (touched.length * 4 < slots.length) {
          for (const slot of touched) {
            const position = this.slots[slot]!.charPositions.get(char)
            if (position === undefined) continue
            const tf = tfs[position]!
            scores[slot] = scores[slot]! + weight * ((idf * tf * (k1 + 1)) / (tf + k1 * norms[slot]!))
          }
        } else {
          for (let i = 0; i < slots.length; i++) {
            const slot = slots[i]!
            if (seen[slot] === 0) continue
            const tf = tfs[i]!
            scores[slot] = scores[slot]! + weight * ((idf * tf * (k1 + 1)) / (tf + k1 * norms[slot]!))
          }
        }
      }

      const hits = new TopHits<D>(topK, touched.length)
      for (const slot of touched) {
        const score = scores[slot]!
        if (score <= 0) continue
        const entry = this.slots[slot]!
        let finalScore = score
        // 时间衰减：×0.5^(elapsed/halfLife)；未来时间戳按因子 1 计（不放大）
        if (halfLifeMs > 0 && entry.ts !== undefined) {
          const elapsed = now - entry.ts
          if (elapsed > 0) {
            finalScore = score * Math.pow(0.5, elapsed / halfLifeMs)
          }
        }
        hits.add(entry, finalScore)
      }
      return hits.sorted()
    } finally {
      for (const slot of touched) {
        scores[slot] = 0
        seen[slot] = 0
      }
    }
  }

  /**
   * 写入去重用的相似度，取值 (0, 1]：IDF 加权的双向覆盖率。
   * 共有权重 = 查询与文档共有的不同词的权重和；分别除以查询全部词、文档全部词的权重和，取较小值。
   * 与 BM25 原始分不同，它不随库规模和正文长度漂移：正文相同得 1，只共享人名地名的不同事实远低于 1。
   *
   * 词的权重是「其余文档」里的 IDF：与某个候选文档比较时，先把它自己从文档数和文档频率里扣掉。
   * 不扣的话，库很小时候选文档的每个词都显得全库常见，权重被压低，同一对文本在小库与大库得分不同。
   * 未入库的查询词文档频率为 0，权重最大，所以新事实里的新词会明显拉低相似度。
   * 不做时间衰减；词频、keys 加权、单字词与功能词表都不参与，只看 bigram 与整词的有无。
   */
  similarity(query: string, options?: { topK?: number }): Array<Bm25Hit<D>> {
    const topK = resultLimit(options?.topK ?? 10, this.docs.size)
    const docCount = this.docs.size
    if (docCount === 0 || topK <= 0) return []
    const terms = [...new Set(tokenize(query))]
    if (terms.length === 0) return []

    const others = docCount - 1
    const weight = (df: number): number => Math.log(1 + (others - df + 0.5) / (df + 0.5))
    /** 共有词的权重和：候选文档含有这些词，文档频率各减 1。 */
    const shared = new Float64Array(this.slots.length)
    /** 同一批共有词按「候选文档不含它」计的权重和，用来从 absent 里扣掉。 */
    const sharedAsAbsent = new Float64Array(this.slots.length)
    const touched: number[] = []
    /** 查询全部词按「候选文档不含它」计的权重和。 */
    let absent = 0
    for (const term of terms) {
      const posting = this.postings.get(term)
      const df = posting?.slots.length ?? 0
      // 每篇文档都有的词不存在「候选不含它」的情况，两边同记 0。
      const asAbsent = df > others ? 0 : weight(df)
      absent += asAbsent
      if (!posting) continue
      const asShared = weight(df - 1)
      for (const slot of posting.slots) {
        // 权重恒为正，0 即尚未命中
        if (shared[slot] === 0) touched.push(slot)
        shared[slot] = shared[slot]! + asShared
        sharedAsAbsent[slot] = sharedAsAbsent[slot]! + asAbsent
      }
    }

    const hits = new TopHits<D>(topK, touched.length)
    for (const slot of touched) {
      const entry = this.slots[slot]!
      const overlap = shared[slot]!
      const queryWeight = overlap + Math.max(0, absent - sharedAsAbsent[slot]!)
      let docWeight = 0
      for (const term of entry.positions.keys()) docWeight += weight(this.postings.get(term)!.slots.length - 1)
      // 求和顺序不同会差几个末位；舍入到 1e-12，使相同正文恰好得 1。
      const score = Math.min(1, Math.round(Math.min(overlap / queryWeight, overlap / docWeight) * 1e12) / 1e12)
      if (score <= 0) continue
      hits.add(entry, score)
    }

    return hits.sorted()
  }
}
