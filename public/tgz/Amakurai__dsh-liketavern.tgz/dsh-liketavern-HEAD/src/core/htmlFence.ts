/** 定位明确允许展示的 Markdown HTML 围栏；跳过注释、原始/惰性内容元素及其它语言代码块，保留完整围栏边界。 */
import { findHtmlDocument, findHtmlFragment, findHtmlOpaqueEnd, LENIENT_OPAQUE } from './htmlFragment.js'
import { markdownCodeScanner } from './markdownCode.js'

export function findHtmlFence(text:string,code?:ReturnType<typeof markdownCodeScanner>):{start:number;end:number;contentStart:number;contentEnd:number}|null {
  if(!text.includes('```')&&!text.includes('~~~'))return null
  const scanner=code??markdownCodeScanner(text)
  const tokens=/<!--[\s\S]*?(?:-->|$)|<(script|style|textarea|title|pre|code|template|noscript)\b(?:[^"'<>]|"[^"]*"|'[^']*')*>|`+|~{3,}/gi
  for(let token=tokens.exec(text);token;token=tokens.exec(text)) {
    const raw=token[0]
    if(raw.startsWith('<!--'))continue
    if(token[1]) {
      const end=findHtmlOpaqueEnd(text,tokens.lastIndex,token[1])
      if(end===null){if(LENIENT_OPAQUE.has(token[1].toLowerCase()))continue;return null}
      tokens.lastIndex=end;continue
    }
    const fence=scanner.fence(token.index)
    if(!fence) {
      const end=scanner.inlineEnd(token.index)
      if(end!==null)tokens.lastIndex=end
      continue
    }
    tokens.lastIndex=fence.end
    if(!fence.closed)continue
    // CommonMark 以 info 的首个单词作为语言，`html title="x"` 仍是 HTML 围栏。
    const info=fence.info.trim().split(/\s+/)[0]!.toLowerCase()
    if(!fence.standalone||!['','html','htm','xhtml','text','xml'].includes(info))continue
    const content=text.slice(fence.contentStart,fence.contentEnd),trimmed=content.trim()
    // 明确标成 html/htm/xhtml/xml 的围栏本身就是作者给出的执行边界。button、p、自定义元素等
    // 不需要再伪装成 div 才能进入沙箱；无语言/text 围栏须从首标签起就是 HTML，避免把含示例标签的普通说明提升为卡面。
    if(!trimmed)continue
    if(!['html','htm','xhtml','xml'].includes(info)) {
      if(!trimmed.includes('<'))continue
      const innerCode=markdownCodeScanner(trimmed)
      const leadingComments=/^(?:\s|<!--[\s\S]*?-->)*/.exec(trimmed)![0]!.length
      const doc=findHtmlDocument(trimmed,innerCode)
      const frag=findHtmlFragment(trimmed,innerCode)
      if((!doc||doc.start>leadingComments)&&(!frag||frag.start>leadingComments))continue
    }
    const start=fence.contentStart+content.indexOf(trimmed)
    return {start:token.index,end:fence.end,contentStart:start,contentEnd:start+trimmed.length}
  }
  return null
}
