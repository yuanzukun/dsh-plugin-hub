/**
 * 检索分词与 token 粗估。
 * 纯函数、零依赖、毫秒级；供记忆检索（BM25）与预算估算共用。
 */

import { isNamingCue, isSeparatorChar } from './stopwords.js'

// ---------------------------------------------------------------------------
// 分词
// ---------------------------------------------------------------------------

/** CJK 表意文字区间：扩展 A（U+3400–U+4DBF）+ 基本区（U+4E00–U+9FFF）。 */
function isCjkCode(code: number): boolean {
  return (code >= 0x3400 && code <= 0x4dbf) || (code >= 0x4e00 && code <= 0x9fff)
}

/**
 * 需要 bigram 切分的文字：CJK 表意 + 假名（平/片假名 U+3040–U+30FF）+
 * 片假名音标扩展（U+31F0–U+31FF）+ 谚文音节（U+AC00–U+D7A3）。
 * 这些文字不靠空格分词，整段取词不可行，统一走滑窗 bigram。
 * 刻意与 isCjkCode 分开：token 估算（estimateTokens）的口径不随分词口径变。
 */
function isBigramScript(code: number): boolean {
  return (
    isCjkCode(code) ||
    (code >= 0x3040 && code <= 0x30ff) ||
    (code >= 0x31f0 && code <= 0x31ff) ||
    (code >= 0xac00 && code <= 0xd7a3)
  )
}

/** 与 isBigramScript 一一对应的字符类；改一处必须同步改另一处。 */
const BIGRAM_CLASS = '\\u3400-\\u4dbf\\u4e00-\\u9fff\\u3040-\\u30ff\\u31f0-\\u31ff\\uac00-\\ud7a3'

/**
 * 单个词字符：任意 Unicode 字母/数字，但要排除 bigram 文字与字母类撇号 U+02BC。
 * `\p{L}` 也匹配表意字与假名，不排除的话「我喜欢apple派」会把「派」并进 `apple`。
 * 必须整体包在非捕获组里，否则后面的 `+` 只作用于字符类，前瞻只在词首生效一次。
 */
const WORD_CHAR = `(?:(?![${BIGRAM_CLASS}\\u02bc])[\\p{L}\\p{N}])`

/**
 * 切分单元：一段连续 bigram 文字（CJK/假名/谚文），或一个 Unicode 词。
 * bigram 分支必须排在前面：`\p{L}` 覆盖表意字，词分支在前会把整段中文吞成一个词。
 * 词以字母/数字为主体，涵盖拉丁扩展、西里尔、希腊等（`café`、`Привет`），
 * 允许内部含 `_`、`-` 连写（如 `foo_bar`、`long-term`）。
 * 其余标点、空白一律跳过；不同文字混排时各自成段，边界处不跨语言组词。
 */
const SEGMENT_RE = new RegExp(`[${BIGRAM_CLASS}]+|${WORD_CHAR}+(?:[_-]${WORD_CHAR}+)*`, 'gu')

/** 英文里撇号后面的词尾：it's、don't、I'd、I'm、we'll、they're、I've。 */
const CLITICS: ReadonlySet<string> = new Set(['s', 't', 'd', 'm', 'll', 're', 've'])
const APOSTROPHES = "'\u2019\u02bc"
const WORD_BEFORE_APOSTROPHE = /[\p{L}\p{N}]/u

/**
 * 这个词是否只是撇号拆出来的词尾。它们不是词：留着的话「it's」会让每条带所有格的记忆都算命中，
 * 把它们当功能词剔除又会连带剔掉以单个字母为名的角色（M、T 先生、小 S）。只在紧跟「字母 + 撇号」时才算。
 */
function isClitic(text: string, index: number, word: string): boolean {
  return CLITICS.has(word) && index >= 2 && APOSTROPHES.includes(text[index - 1]!) && WORD_BEFORE_APOSTROPHE.test(text[index - 2]!)
}

/**
 * 检索分词。
 * - 先做 NFKC 归一：全角字母数字、半角片假名、兼容表意字与对应的常规写法得到同一 token
 *   （`ＡＢＣ` → `abc`，`ｶﾞｲﾄﾞ` → `ガイド`）；只影响分词，不改调用方的原文。
 * - bigram 文字段切滑窗 bigram：「我喜欢你」→ ['我喜', '喜欢', '欢你']；单字不成词（返回空）。
 *   假名、谚文同理：「안녕하세요」→ ['안녕', '녕하', '하세', '세요']。
 * - 其余词整词保留并转小写：`Café` → `café`，`Привет` → `привет`。
 *   撇号后面的词尾不算词：`it's` → ['it']，`don't` → ['don']。
 */
export function tokenize(text: string): string[] {
  const terms: string[] = []
  const normalized = text.normalize('NFKC')
  for (const match of normalized.matchAll(SEGMENT_RE)) {
    const seg = match[0]
    if (isBigramScript(seg.charCodeAt(0))) {
      for (let i = 0; i < seg.length - 1; i++) terms.push(seg.slice(i, i + 2))
    } else {
      const word = seg.toLowerCase()
      if (isClitic(normalized, match.index, word)) continue
      terms.push(word)
    }
  }
  return terms
}

/** 一段文本的检索切分；各数组都保留重复，顺序同原文。 */
export interface TextTokens {
  /** tokenize 的结果：bigram 与整词。 */
  terms: string[]
  /**
   * bigram 文字（CJK/假名/谚文）里的每个字。bigram 表达不了单字词：
   * 「凛去哪了」与「凛的妹妹」没有共同 bigram，单独一个「樱」连一个 bigram 都切不出来。
   * 是否把某个字当作检索词由索引决定，这里只负责切分。
   */
  chars: string[]
  /**
   * 每段 bigram 文字的首字与尾字（单字成段时两者相同）。一个字紧挨着标点或别的文字出现，
   * 说明它在那一侧是词的边界；索引据此判断这个字是否独立成词。
   */
  initials: string[]
  finals: string[]
  /**
   * 在这段文本里单独成词的字：左右两侧都是边界——标点、空白、别的文字、段首段尾，或者一个虚词。
   * 「凛的妹妹叫樱，」里凛（句首 + 的）和樱（叫 + 逗号）是，妹不是；「去打听」里打不是，它只是「打听」的一部分。
   * 引出名字的字（姓、绰号、人称、唤作）后面跟一个字再跟标点时，那个字也算：「绰号鲸，」。
   * 保留重复，顺序同原文。
   */
  words: string[]
  /**
   * 至少一侧是边界的字（包含 words）。句子里当作词用的字几乎总有一侧挨着标点或虚词——
   * 主语在句首，宾语在句末或虚词前；而「几点开始」里的「开」两侧都是别的实字，只是「开始」的一部分。
   */
  sides: string[]
  /**
   * 左侧是边界的字、右侧是边界的字（sides 是两者的并集）。一个名字可能从没被两侧同时夹住，
   * 却在一处开头（「豆抓伤过」）、在另一处收尾（「流浪猫豆是」）。
   */
  lefts: string[]
  rights: string[]
  /**
   * 整段文本是否只由被虚词或标点隔开的单个字组成：没有整词，也没有两个相邻的非虚词字。
   * 「豆在哪」「药呢」「岚的腿」是，「豆今天吃了吗」不是。空文本也算。
   */
  lone: boolean
}

/** 是否为 bigram 文字切出的 bigram（两个字都属于 CJK/假名/谚文）；整词文字的两字母词不算。 */
export function isBigramTerm(term: string): boolean {
  return term.length === 2 && isBigramScript(term.charCodeAt(0)) && isBigramScript(term.charCodeAt(1))
}

/** 平假名、片假名及其音标扩展：单个假名不构成词。 */
export function isKana(char: string): boolean {
  if (char.length !== 1) return false
  const code = char.charCodeAt(0)
  return (code >= 0x3040 && code <= 0x30ff) || (code >= 0x31f0 && code <= 0x31ff)
}

/**
 * 同时切出检索词与单字；归一和分段规则与 tokenize 完全一致。
 * 查询可指定不提供单字证据的 bigram：只屏蔽与该词重叠的位置及其边界特征，
 * 不屏蔽别处出现的同字，也不改变 terms、lone 或原来的分段边界。建索引不传此参数。
 */
export function analyzeText(text: string, ignoredCharBigrams?: ReadonlySet<string>): TextTokens {
  const terms: string[] = []
  const chars: string[] = []
  const initials: string[] = []
  const finals: string[] = []
  const words: string[] = []
  const sides: string[] = []
  const lefts: string[] = []
  const rights: string[] = []
  let lone = true
  const normalized = text.normalize('NFKC')
  for (const match of normalized.matchAll(SEGMENT_RE)) {
    const seg = match[0]
    if (isBigramScript(seg.charCodeAt(0))) {
      // bigram 文字都在基本多文种平面，按 UTF-16 下标取字不会拆开代理对
      const last = seg.length - 1
      for (let i = 0; i <= last; i++) {
        if (i < last) terms.push(seg.slice(i, i + 2))
        if (i < last && !isSeparatorChar(seg[i]!) && !isSeparatorChar(seg[i + 1]!)) lone = false
        if (ignoredCharBigrams && ((i > 0 && ignoredCharBigrams.has(seg.slice(i - 1, i + 1)))
          || (i < last && ignoredCharBigrams.has(seg.slice(i, i + 2))))) continue
        chars.push(seg[i]!)
        if (i === 0) initials.push(seg[i]!)
        if (i === last) finals.push(seg[i]!)
        const left = i === 0 || isSeparatorChar(seg[i - 1]!) || (i === last && isNamingCue(seg[i - 1]!))
        const right = i === last || isSeparatorChar(seg[i + 1]!)
        if (left && right) words.push(seg[i]!)
        if (left || right) sides.push(seg[i]!)
        if (left) lefts.push(seg[i]!)
        if (right) rights.push(seg[i]!)
      }
    } else {
      const word = seg.toLowerCase()
      if (isClitic(normalized, match.index, word)) continue
      terms.push(word)
      lone = false
    }
  }
  return { terms, chars, initials, finals, words, sides, lefts, rights, lone }
}

// ---------------------------------------------------------------------------
// token 估算
// ---------------------------------------------------------------------------

export interface TokenCharCounts {
  cjk: number
  other: number
}

/** 统计文本的 (cjk, other) 字符计数；二者在拼接上严格可加，便于增量计算 JSON 输出预算。 */
export function countTokenChars(text: string): TokenCharCounts {
  let cjk = 0
  let other = 0
  for (let i = 0; i < text.length; i++) {
    if (isCjkCode(text.charCodeAt(i))) cjk++
    else other++
  }
  return { cjk, other }
}

/**
 * 统计 JSON.stringify(text) 的 (cjk, other) 字符计数（含外层双引号、控制字符转义与孤立代理项转义）。
 * 与 ES2019+ 标准 JSON 序列化逐字符一致，无需分配转义后的字符串副本。
 */
export function countJsonStringTokenChars(text: string): TokenCharCounts {
  let cjk = 0
  let other = 2
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i)
    if (code === 0x22 || code === 0x5c || code === 0x08 || code === 0x09 || code === 0x0a || code === 0x0c || code === 0x0d) {
      other += 2
    } else if (code < 0x20) {
      other += 6
    } else if (code >= 0xd800 && code <= 0xdbff) {
      const next = i + 1 < text.length ? text.charCodeAt(i + 1) : 0
      if (next >= 0xdc00 && next <= 0xdfff) {
        other += 2
        i++
      } else {
        other += 6
      }
    } else if (code >= 0xdc00 && code <= 0xdfff) {
      other += 6
    } else if (isCjkCode(code)) {
      cjk++
    } else {
      other++
    }
  }
  return { cjk, other }
}

/** CJK 码点判定（与 estimateTokens 同口径，供增量 JSON 字符串扫描复用）。 */
export function isTokenCjkCode(code: number): boolean {
  return isCjkCode(code)
}

/**
 * 确定性粗估 token 数：CJK 字符每个计 1，其余字符累计后 ÷4 向上取整，两部分相加。
 * 只用于预算分配，不追求与具体模型 tokenizer 对齐；口径固定，不跟随分词的 bigram 文字范围。
 */
export function estimateTokens(text: string): number {
  let cjk = 0
  let other = 0
  for (let i = 0; i < text.length; i++) {
    if (isCjkCode(text.charCodeAt(i))) cjk++
    else other++
  }
  return cjk + Math.ceil(other / 4)
}

/** 按估算 token 预算截断；超限时在末尾加省略标记。 */
export function clipToTokenBudget(text: string, budget: number): { text: string; truncated: boolean; tokens: number } {
  const limit = Number.isNaN(budget) ? 0 : Math.max(0, Math.floor(budget))
  if (text.length === 0) return { text: '', truncated: false, tokens: 0 }
  if (limit === 0) return { text: '', truncated: true, tokens: 0 }
  const suffix = '…（已截断）'
  // suffix = 3 CJK + 3 other（estimateTokens(suffix) = 4）；`\n${suffix}` = 3 CJK + 4 other，
  // 因此任意前缀 (cjk, other) 拼上 `\n${suffix}` 后的估算 token 恒为 cjk + 4 + ceil(other / 4)。
  let cjk = 0
  let other = 0
  let curTokens = 0
  let lo = 0
  let loCjk = 0
  let loOther = 0
  let exceeded = false
  for (let i = 0; i < text.length; i++) {
    if (isCjkCode(text.charCodeAt(i))) cjk++
    else other++
    curTokens = cjk + Math.ceil(other / 4)
    if (curTokens + 4 <= limit) {
      lo = i + 1
      loCjk = cjk
      loOther = other
    }
    if (curTokens > limit) {
      exceeded = true
      break
    }
  }
  if (!exceeded) return { text, truncated: false, tokens: curTokens }
  if (limit < 4) return { text: '…', truncated: true, tokens: 1 }
  // UTF-16 下标可能落在 emoji/扩展汉字的代理对中间；退回完整字符边界，不改变 token 估算口径。
  if (lo > 0) {
    const prev = text.charCodeAt(lo - 1)
    const next = lo < text.length ? text.charCodeAt(lo) : 0
    if (prev >= 0xd800 && prev <= 0xdbff && next >= 0xdc00 && next <= 0xdfff) {
      lo--
      loOther--
    }
  }
  const out = lo > 0 ? `${text.slice(0, lo)}\n${suffix}` : suffix
  return { text: out, truncated: true, tokens: loCjk + 4 + Math.ceil(loOther / 4) }
}
