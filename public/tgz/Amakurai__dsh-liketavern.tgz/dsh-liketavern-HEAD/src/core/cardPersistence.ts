/** iframe 剧情变量同步：同步 API 写本地快照，差异串行提交；宿主成功回执之前不声称已保存。 */
import type {HelperMessageEditResult} from './helperChatEdits.js'
import type { HelperSnapshot } from './helperRuntime.js'
export interface CardPersistenceLabels { saving:string; saved:string; failed:string; refresh?:string }
export function installCardPersistence(snapshot:HelperSnapshot,source:string,_labels:CardPersistenceLabels):()=>void {
  type Table=Record<string,unknown>
  type Scopes=Record<string,Table>
  type Change={key:string;before:Table;value:Table}
  type State={storyId:string;historyRevision:string;confirmed:Scopes}
  const root=window as unknown as Record<string,unknown>
  const runtimeId=root.__dshTavernEventRuntimeId
  if(typeof runtimeId!=='string'||!runtimeId||runtimeId.length>96)throw new Error('变量持久化缺少有效卡面运行时')
  const retained=root.__dshTavernSnapshot as HelperSnapshot|undefined
  if(retained?.storyId===snapshot.storyId) snapshot=retained
  root.__dshTavernSnapshot=snapshot
  const clone=<T>(value:T):T=>JSON.parse(JSON.stringify(value)) as T
  const equal=(a:unknown,b:unknown):boolean=>{
    if(Object.is(a,b)) return true
    if(a===null||b===null||typeof a!=='object'||typeof b!=='object') return false
    const aArr=Array.isArray(a), bArr=Array.isArray(b)
    if(aArr!==bArr) return false
    if(aArr) {
      const aa=a as unknown[], bb=b as unknown[]
      if(aa.length!==bb.length) return false
      for(let i=0;i<aa.length;i++) if(!equal(aa[i],bb[i])) return false
      return true
    }
    const ao=a as Record<string,unknown>, bo=b as Record<string,unknown>
    const aKeys=Object.keys(ao), bKeys=Object.keys(bo)
    let aDefined=0
    for(const key of aKeys) if(ao[key]!==undefined) aDefined++
    let bDefined=0
    for(const key of bKeys) if(bo[key]!==undefined) bDefined++
    if(aDefined!==bDefined) return false
    for(const key of aKeys) {
      const av=ao[key]
      if(av===undefined) continue
      if(!Object.prototype.hasOwnProperty.call(bo,key)||!equal(av,bo[key])) return false
    }
    return true
  }
  let state=root.__dshTavernPersistent as State|undefined
  if(!state||state.storyId!==snapshot.storyId||state.historyRevision!==snapshot.historyRevision) {
    state={storyId:snapshot.storyId,historyRevision:snapshot.historyRevision,confirmed:clone(snapshot.scopes)}
    root.__dshTavernPersistent=state
  }
  const holder=(root.__dshTavernVariables??={scopes:clone(snapshot.scopes)}) as {scopes:Scopes}
  const persistent=state
  const epoch=crypto.randomUUID()
  let active=true, serial=0, failure:Error|null=null, running:Promise<void>|null=null
  let refreshing:Promise<HelperSnapshot>|null=null
  let editing:Promise<void>|null=null
  let invalidated=false
  let pending:{id:string;action:string;resolve:(value:Record<string,unknown>)=>void;reject:(error:Error)=>void;timer:ReturnType<typeof setTimeout>}|null=null
  let status='saved'
  // 保存状态留在运行时 API；管理入口在设置面板，不向第三方 body 插入布局节点。
  function setStatus(value:string) {status=value}
  function report(error:unknown) {
    if(!active||root.__dshTavernEventRuntimeId!==runtimeId)return
    const callback=root.__dshTavernReportError
    if(typeof callback==='function') callback(error)
  }
  function differences():Change[] {
    return [...new Set([...Object.keys(persistent.confirmed),...Object.keys(holder.scopes)])]
      .filter(key=>!equal(persistent.confirmed[key]??{},holder.scopes[key]??{}))
      .map(key=>({key,before:clone(persistent.confirmed[key]??{}),value:clone(holder.scopes[key]??{})}))
  }
  const receive=(event:MessageEvent)=>{
    if(event.source!==parent || event.data?.runtimeId!==runtimeId) return
    const value=event.data
    if(value?.source===source&&value.action==='helperSnapshotInvalidated'&&value.storyId===persistent.storyId) {
      invalidated=true;refreshIfClean();return
    }
    if(!pending) return
    if(!value||value.source!==source||value.action!==pending.action||value.requestId!==pending.id) return
    const request=pending;pending=null;clearTimeout(request.timer)
    if(value.ok===true) request.resolve(value)
    else request.reject(new Error(typeof value.error==='string'?value.error:'酒馆助手变量保存失败'))
  }
  function refreshIfClean() {
    if(!active||root.__dshTavernDisplayLocked||!invalidated||running||refreshing||editing||differences().length||failure) return
    invalidated=false
    queueMicrotask(()=>{if(active) void refreshHelperSnapshot().catch(report)})
  }
  function request(action:string,resultAction:string,payload:Record<string,unknown>):Promise<Record<string,unknown>> {
    if(!active) return Promise.reject(new Error('卡面已关闭'))
    if(pending) return Promise.reject(new Error('卡面已有请求正在处理'))
    const id=`${epoch}:${++serial}`
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>{pending=null;reject(new Error('酒馆助手通信超时；请保留备份后刷新检查'))},15000)
      pending={id,action:resultAction,resolve,reject,timer}
      parent.postMessage({source,action,requestId:id,runtimeId,...payload},'*')
    })
  }
  function refreshHelperSnapshot(option:{discardUnsaved?:boolean}={},provided?:HelperSnapshot):Promise<HelperSnapshot> {
    if(root.__dshTavernDisplayLocked)return Promise.reject(new Error('卡面正在重绘，请等待完成'))
    if(editing) return Promise.reject(new Error('请等待消息数据编辑结束后刷新'))
    if(refreshing) return refreshing
    if(running) return Promise.reject(new Error('请等待当前变量保存结束后刷新'))
    if(differences().length && option.discardUnsaved!==true) return Promise.reject(new Error('卡面有未保存变量，请先保存或复制备份。重新打开卡面可读取已保存的数据。'))
    const before=clone(holder.scopes)
    refreshing=(async()=>{
      const response=provided?{snapshot:provided}:await request('helperSnapshotGet','helperSnapshotResult',{storyId:persistent.storyId})
      if(!active) throw new Error('卡面已关闭，刷新结果已丢弃')
      const next=response.snapshot as HelperSnapshot|undefined
      if(!next||next.storyId!==persistent.storyId||!Array.isArray(next.messages)||!next.scopes) throw new Error('剧情快照回执无效')
      if(!equal(holder.scopes,before)) throw new Error('刷新期间变量已改变，保留本地数据')
      const changed=!equal(snapshot,next)
      holder.scopes=clone(next.scopes)
      persistent.confirmed=clone(next.scopes);persistent.historyRevision=next.historyRevision
      Object.assign(snapshot,clone(next))
      root.__dshTavernSnapshotGeneration=Number(root.__dshTavernSnapshotGeneration??0)+1
      failure=null;setStatus('saved')
      const emit=root.__dshTavernEmitLocal
      // 相同快照不再次通知，避免监听器调用 refreshHelperSnapshot 后无限自触发。
      if(changed&&typeof emit==='function') void Promise.resolve(emit('dsh_helper_snapshot_refreshed')).catch(report)
      return clone(snapshot)
    })().finally(()=>{refreshing=null;refreshIfClean()})
    return refreshing
  }
  async function drain() {
    try {
      for(let changes=differences();changes.length;changes=differences()) {
        if(!active) throw new Error('卡面已关闭，变量提交已停止')
        if(!snapshot.writable) throw new Error('当前卡面快照不可写，请在生成结束后刷新')
        const batch=changes.slice(0,64)
        setStatus('pending')
        const response=await request('helperVariablesCommit','helperVariablesResult',{storyId:persistent.storyId,historyRevision:persistent.historyRevision,changes:batch})
        if(!active) throw new Error('卡面已关闭，保存结果需重新读取')
        const scopes=response.scopes as Scopes
        if(!scopes||typeof scopes!=='object'||Array.isArray(scopes)) throw new Error('变量保存回执无效')
        // 回执带上其它卡面已保存的表；只刷新本地未继续修改的表。
        const sent=new Map(batch.map(change=>[change.key,change.value]))
        for(const key of new Set([...Object.keys(scopes),...Object.keys(persistent.confirmed)])) {
          const baseline=sent.get(key)??persistent.confirmed[key]??{}
          if(equal(holder.scopes[key]??{},baseline)) holder.scopes[key]=clone(scopes[key]??{})
        }
        persistent.confirmed=clone(scopes)
        snapshot.scopes=clone(scopes)
        for(const msg of snapshot.messages){
          const nextData=clone(scopes[JSON.stringify(['message',msg.message_id])]??{})
          msg.data=nextData
          const activePage=msg.swipe?.pages[msg.swipe.active]
          if(activePage)activePage.data=clone(nextData)
        }

      }
      setStatus('saved')
    } catch(error) {failure=error instanceof Error?error:new Error(String(error));if(active){setStatus('error');report(failure)};throw failure}
  }
  function flushHelperVariables():Promise<void> {
    if(!active) return Promise.reject(new Error('卡面已关闭'))
    if(editing) return editing.then(()=>flushHelperVariables())
    if(refreshing) return refreshing.then(()=>flushHelperVariables())
    if(failure) return Promise.reject(failure)
    if(!running) running=drain().finally(()=>{running=null;refreshIfClean()})
    return running
  }
  function changed() {
    if(!active) throw new Error('卡面已关闭')
    if(failure) {setStatus('error');return}
    setStatus('pending')
    queueMicrotask(()=>{if(active) void flushHelperVariables().catch(()=>{})})
  }
  // 消息数据事务复用变量保存队列；等待期间的本地新修改保留，随后以新确认值提交。
  async function messageTransaction(action:(current:HelperSnapshot)=>Promise<HelperMessageEditResult>):Promise<HelperMessageEditResult>{
    await flushHelperVariables()
    if(refreshing)await refreshing
    if(!active)throw new Error('卡面已关闭')
    if(editing)throw new Error('消息数据编辑仍在进行')
    let release!:()=>void
    editing=new Promise<void>(resolve=>{release=resolve})
    const baseline=clone(holder.scopes)
    try{
      const result=await action({...clone(snapshot),scopes:clone(persistent.confirmed)})
      if(!active)throw new Error('卡面已关闭，保存结果需重新读取')
      if(result.snapshot){
        const next=result.snapshot
        if(next.storyId!==snapshot.storyId||next.historyRevision!==snapshot.historyRevision||!next.scopes||!Array.isArray(next.messages))throw new Error('消息数据回执无效')
        for(const key of new Set([...Object.keys(next.scopes),...Object.keys(persistent.confirmed)])){
          if(equal(holder.scopes[key]??{},baseline[key]??{}))holder.scopes[key]=clone(next.scopes[key]??{})
        }
        persistent.confirmed=clone(next.scopes);Object.assign(snapshot,clone(next))
        root.__dshTavernSnapshotGeneration=Number(root.__dshTavernSnapshotGeneration??0)+1
      }
      return result
    }finally{editing=null;release();if(active){if(differences().length)changed();else refreshIfClean()}}
  }
  root.__dshTavernPrepareMvuEvent=async(next:HelperSnapshot)=>{
    if(editing)await editing
    if(running)await running
    if(refreshing)await refreshing
    if(failure||differences().length)throw failure??new Error('卡面有未保存变量，MVU 监听未执行')
    await refreshHelperSnapshot({},next)
  }
  root.__dshTavernPrepareHostEvent=async()=>{
    // 先等待本地事务收口，再刷新实际剧情；冲突草稿不得被生命周期通知冲掉。
    if(editing)await editing
    if(running)await running
    if(refreshing)await refreshing
    if(!active)throw new Error('卡面已关闭')
    if(failure||differences().length)throw failure??new Error('卡面有未保存变量，宿主事件未执行；请保留草稿后刷新')
    await refreshHelperSnapshot()
  }
  root.__dshTavernMessageTransaction=messageTransaction
  root.__dshTavernVariableChanged=changed
  root.flushHelperVariables=flushHelperVariables
  root.refreshHelperSnapshot=refreshHelperSnapshot
  root.getHelperPersistenceStatus=()=>status
  root.TavernHelper=Object.assign(root.TavernHelper??{},{flushHelperVariables,refreshHelperSnapshot,getHelperPersistenceStatus:root.getHelperPersistenceStatus})
  window.addEventListener('message',receive)
  if(differences().length) changed()
  return ()=>{
    active=false
    window.removeEventListener('message',receive)
    if(root.__dshTavernVariableChanged===changed) delete root.__dshTavernVariableChanged
    if(pending) {clearTimeout(pending.timer);pending.reject(new Error('卡面重写或关闭，保存结果需重新读取'));pending=null}
  }
}
