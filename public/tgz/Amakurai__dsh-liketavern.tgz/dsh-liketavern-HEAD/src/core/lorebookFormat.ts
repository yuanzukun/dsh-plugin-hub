/**
 * 世界书 JSON ⇄ 归一化 WorldInfoEntry 纯函数编解码（前后端共用，无文件 I/O）。
 *
 * 兼容三种输入外形：
 * 1. SillyTavern 原生 World Info 文件：{entries: {"0": {...}}}（对象 map，map 键即 uid）。
 * 2. {entries: [...]}（数组；条目按字段特征逐个判定为原生 WI 或 character_book 形态）。
 * 3. 角色卡 character_book 的条目数组（顶层即数组，或 entries 为数组且条目带 keys/extensions 等特征）。
 *
 * 字段容错：字符串数字转 number、非 boolean 转 boolean；非法 position/selectiveLogic/role 回落默认；
 * 条目级 null（caseSensitive/matchWholeWords/scanDepth/sticky/cooldown/delay）保留 null = 跟随全局。
 *
 * 导入硬上限（第三方资产不可信，合法 JSON 也可能是体量炸弹）：条目数 / 单条正文 / 单键长度
 * 超限，或键容器、content 字段类型非法（会在下游 .map()/.includes() 处才炸的错型），
 * 一律在归一化时抛中文错误拒绝导入——统一拒绝口径，不做静默截断（截断会悄悄改写设定）。
 */
import { MAX_WI_KEY_CHARS } from './worldbook.js'
import { WIPosition, type WIRole, type WISelectiveLogic, type WISource, type WorldDelta, type WorldInfoEntry } from './types.js'
import { isRecord } from './guards.js'
import { toBool, toNum, toNumOrNull as coerceNumOrNull, toStr } from './coerce.js'

/** 单文件条目数上限：社区大书在千级，2000 已留足余量。预设（presetStore）同口径复用。 */
export const MAX_LOREBOOK_ENTRIES = 2000

/**
 * 单条正文字符数上限：≈2.5 万 token，超出任何合理条目。
 * 预设（presetStore）单条 prompt 正文同口径复用。
 */
export const MAX_LOREBOOK_CONTENT_CHARS = 100_000

export interface ParseLorebookOptions {
  source: WISource
  sourceRef: string
}

// ---------------------------------------------------------------------------
// 容错转换
// ---------------------------------------------------------------------------

/** 字符串数组：非数组 → []，元素容错转字符串并丢弃空串。 */
function toStrArr(value: unknown): string[] {
  if (!Array.isArray(value)) return []
  return value.map(toStr).filter((s) => s !== '')
}

/** 可空数字：null/undefined → null；旧格式布尔容错（true → 1，false → null）。 */
function toNumOrNull(value: unknown): number | null {
  return coerceNumOrNull(value, { booleanOne: true })
}

/** 可空布尔：null/undefined → null（跟随全局）。 */
function toBoolOrNull(value: unknown): boolean | null {
  if (value === null || value === undefined) return null
  return toBool(value, false)
}

/** position：0-7 整数，非法回落默认。 */
function toPosition(value: unknown, fallback: WIPosition = 0): WIPosition {
  const n = toNum(value, Number.NaN)
  return Number.isInteger(n) && n >= 0 && n <= 7 ? (n as WIPosition) : fallback
}

/** role：0-2，非法回落 0（system）。 */
function toRole(value: unknown): WIRole {
  const n = toNum(value, Number.NaN)
  return n === 0 || n === 1 || n === 2 ? n : 0
}

/** selectiveLogic：0-3，非法回落 0（AndAny）。 */
function toSelectiveLogic(value: unknown): WISelectiveLogic {
  const n = toNum(value, Number.NaN)
  return n === 0 || n === 1 || n === 2 || n === 3 ? (n as WISelectiveLogic) : 0
}

/** 旧格式 delayUntilRecursion 可能是布尔：true → 1，false → 0。 */
function toDelayUntilRecursion(value: unknown): number {
  if (typeof value === 'boolean') return value ? 1 : 0
  return toNum(value, 0)
}

// ---------------------------------------------------------------------------
// 条目解析
// ---------------------------------------------------------------------------

function makeKey(uid: string, opts: ParseLorebookOptions): string {
  return `${opts.source}:${opts.sourceRef}:${uid}`
}

/**
 * AtDepth（position=4）的 depth 会进入 PromptLayoutSchema 的 placement；该字段要求
 * 非负安全整数。与文件头「非法值回落默认」的口径一致，负值、小数和超安全整数都回落 4。
 * 其它位置的 depth 不参与布局，保持原有 toNum 容错结果。
 */
function normalizeDepth(value: unknown, position: WIPosition): number {
  const depth = toNum(value, 4)
  if (position !== WIPosition.AtDepth) return depth
  return Number.isSafeInteger(depth) && depth >= 0 ? depth : 4
}

/** 原生 World Info 条目（camelCase 字段）。 */
function parseNativeEntry(
  raw: Record<string, unknown>,
  uid: string,
  opts: ParseLorebookOptions,
): WorldInfoEntry {
  const position = toPosition(raw.position)
  return {
    key: makeKey(uid, opts),
    uid,
    source: opts.source,
    sourceRef: opts.sourceRef,
    keys: toStrArr(raw.key),
    secondaryKeys: toStrArr(raw.keysecondary),
    selective: toBool(raw.selective, true),
    selectiveLogic: toSelectiveLogic(raw.selectiveLogic),
    comment: toStr(raw.comment),
    content: toStr(raw.content),
    constant: toBool(raw.constant, false),
    enabled: !toBool(raw.disable, false),
    order: toNum(raw.order, 100),
    position,
    depth: normalizeDepth(raw.depth, position),
    role: toRole(raw.role),
    outletName: toStr(raw.outletName),
    probability: toNum(raw.probability, 100),
    useProbability: toBool(raw.useProbability, true),
    caseSensitive: toBoolOrNull(raw.caseSensitive),
    matchWholeWords: toBoolOrNull(raw.matchWholeWords),
    useGroupScoring: toBoolOrNull(raw.useGroupScoring),
    scanDepth: toNumOrNull(raw.scanDepth),
    excludeRecursion: toBool(raw.excludeRecursion, false),
    preventRecursion: toBool(raw.preventRecursion, false),
    delayUntilRecursion: toDelayUntilRecursion(raw.delayUntilRecursion),
    sticky: toNumOrNull(raw.sticky),
    cooldown: toNumOrNull(raw.cooldown),
    delay: toNumOrNull(raw.delay),
    ignoreBudget: toBool(raw.ignoreBudget, false),
    group: toStr(raw.group),
    groupWeight: toNum(raw.groupWeight, 100),
    groupOverride: toBool(raw.groupOverride, false),
    automationId: toStr(raw.automationId),
  }
}

/**
 * character_book 条目的 position：extensions.position 数值优先于顶层字符串。
 * 两者都缺失或非法时对齐 ST convertCharacterBook：只有 before_char 落在角色定义前，其余一律 after_char。
 */
function parseBookPosition(raw: Record<string, unknown>, ext: Record<string, unknown>): WIPosition {
  const fromExt = toNum(ext.position, Number.NaN)
  if (Number.isInteger(fromExt) && fromExt >= 0 && fromExt <= 7) return fromExt as WIPosition
  if (raw.position === 'before_char') return 0
  if (raw.position === 'after_char') return 1
  return toPosition(raw.position, 1)
}

/**
 * 角色卡 character_book 条目（顶层 snake_case + extensions 覆盖）。
 * 顶层 priority 为卡格式遗留字段，SillyTavern 与本插件均不消费，导入时忽略。
 */
function parseCharacterBookEntry(
  raw: Record<string, unknown>,
  uid: string,
  opts: ParseLorebookOptions,
): WorldInfoEntry {
  const ext = isRecord(raw.extensions) ? raw.extensions : {}
  const position = parseBookPosition(raw, ext)
  return {
    key: makeKey(uid, opts),
    uid,
    source: opts.source,
    sourceRef: opts.sourceRef,
    keys: toStrArr(raw.keys),
    secondaryKeys: toStrArr(raw.secondary_keys),
    selective: toBool(raw.selective, false),
    selectiveLogic: toSelectiveLogic(ext.selectiveLogic),
    comment: toStr(raw.comment),
    content: toStr(raw.content),
    constant: toBool(raw.constant, false),
    enabled: toBool(raw.enabled, true),
    order: toNum(raw.insertion_order, 100),
    position,
    depth: normalizeDepth(ext.depth, position),
    role: toRole(ext.role),
    outletName: toStr(ext.outlet_name),
    probability: toNum(ext.probability, 100),
    useProbability: toBool(ext.useProbability, true),
    caseSensitive: toBoolOrNull(ext.case_sensitive !== undefined ? ext.case_sensitive : raw.case_sensitive),
    matchWholeWords: toBoolOrNull(ext.match_whole_words),
    useGroupScoring: toBoolOrNull(ext.use_group_scoring !== undefined ? ext.use_group_scoring : ext.useGroupScoring),
    scanDepth: toNumOrNull(ext.scan_depth),
    excludeRecursion: toBool(ext.exclude_recursion, false),
    preventRecursion: toBool(ext.prevent_recursion, false),
    delayUntilRecursion: toDelayUntilRecursion(ext.delay_until_recursion),
    sticky: toNumOrNull(ext.sticky),
    cooldown: toNumOrNull(ext.cooldown),
    delay: toNumOrNull(ext.delay),
    ignoreBudget: toBool(ext.ignore_budget, false),
    group: toStr(ext.group),
    groupWeight: toNum(ext.group_weight !== undefined ? ext.group_weight : ext.groupWeight, 100),
    groupOverride: toBool(ext.group_override !== undefined ? ext.group_override : ext.groupOverride, false),
    automationId: toStr(ext.automation_id),
  }
}

/** 角色书使用明确的 keys/snake_case 标识；原生 key 优先，数值字符串 position 和扩展元数据不改变格式。 */
function isCharacterBookEntry(raw: Record<string, unknown>): boolean {
  if ('key' in raw || 'keysecondary' in raw) return false
  return (
    Array.isArray(raw.keys) ||
    'insertion_order' in raw ||
    'secondary_keys' in raw ||
    raw.position === 'before_char' || raw.position === 'after_char' ||
    (isRecord(raw.extensions) && !('disable' in raw) && !('order' in raw))
  )
}

function parseEntry(raw: Record<string, unknown>, uid: string, opts: ParseLorebookOptions): WorldInfoEntry {
  const entry = isCharacterBookEntry(raw) ? parseCharacterBookEntry(raw, uid, opts) : parseNativeEntry(raw, uid, opts)
  assertEntryWithinLimits(raw, entry)
  return entry
}

/**
 * 单条硬校验（统一拒绝口径，归一化时抛错，不放到落盘后由下游 .map()/.includes() 踩雷）：
 * - 键容器（key/keys/keysecondary/secondary_keys）出现但不是数组 → 拒绝（不做「也许是单键」的猜测）；
 * - content 出现但是对象/数组 → 拒绝（toStr 静默塌缩成 '' 会悄悄丢掉设定）；
 * - 单键超 MAX_WI_KEY_CHARS / 正文超 MAX_LOREBOOK_CONTENT_CHARS → 拒绝。
 */
function assertEntryWithinLimits(raw: Record<string, unknown>, entry: WorldInfoEntry): void {
  for (const field of ['key', 'keys', 'keysecondary', 'secondary_keys'] as const) {
    const value = raw[field]
    if (value !== undefined && value !== null && !Array.isArray(value)) {
      throw new Error(`世界书条目 ${entry.uid} 的 ${field} 不是数组，拒绝导入`)
    }
  }
  const content = raw.content
  if (content !== undefined && content !== null && typeof content === 'object') {
    throw new Error(`世界书条目 ${entry.uid} 的 content 不是字符串，拒绝导入`)
  }
  for (const key of [...entry.keys, ...entry.secondaryKeys]) {
    if (key.length > MAX_WI_KEY_CHARS) {
      throw new Error(`世界书条目 ${entry.uid} 的触发键超过 ${MAX_WI_KEY_CHARS} 字符上限，拒绝导入`)
    }
  }
  if (entry.content.length > MAX_LOREBOOK_CONTENT_CHARS) {
    throw new Error(`世界书条目 ${entry.uid} 的正文超过 ${MAX_LOREBOOK_CONTENT_CHARS} 字符上限，拒绝导入`)
  }
}

/** uid 解析：map 形态以 map 键为准；数组形态取 uid/id 字段，缺失用数组下标（酒馆助手桥同口径复用）。 */
export function entryUid(raw: Record<string, unknown>, fallback: string): string {
  return toStr(raw.uid ?? raw.id) || fallback
}

function parseEntryArray(entries: unknown[], opts: ParseLorebookOptions): WorldInfoEntry[] {
  if (entries.length > MAX_LOREBOOK_ENTRIES) {
    throw new Error(`世界书条目数 ${entries.length} 超过上限 ${MAX_LOREBOOK_ENTRIES}，拒绝导入`)
  }
  const out: WorldInfoEntry[] = []
  const seen = new Set<string>()
  entries.forEach((value, index) => {
    // 非对象条目静默跳过（兼容已在工作区落盘的旧导入文件，不让坏条目毁掉整本书）
    if (!isRecord(value)) return
    // 数组形态的 uid/id 由导出工具填写，可能重复。重复 uid 会让导出 map 静默丢条目、
    // 定时器与变化层 ref 混淆，这里用下标后缀区分：同一文件内稳定，不拒绝导入既有卡片。
    let uid = entryUid(value, String(index))
    while (seen.has(uid)) uid = `${uid}#${index}`
    seen.add(uid)
    out.push(parseEntry(value, uid, opts))
  })
  return out
}

/**
 * 解析世界书 JSON 为归一化条目数组。
 * 非对象/缺 entries 时抛中文错误；条目数/正文/键超限或键容器、content 错型同样抛错拒绝导入。
 */
export function parseLorebook(json: unknown, opts: ParseLorebookOptions): WorldInfoEntry[] {
  if (Array.isArray(json)) return parseEntryArray(json, opts)
  if (!isRecord(json)) throw new Error('世界书 JSON 不是对象或条目数组')
  const rawEntries = json.entries
  if (Array.isArray(rawEntries)) return parseEntryArray(rawEntries, opts)
  if (isRecord(rawEntries)) {
    const pairs = Object.entries(rawEntries)
    if (pairs.length > MAX_LOREBOOK_ENTRIES) {
      throw new Error(`世界书条目数 ${pairs.length} 超过上限 ${MAX_LOREBOOK_ENTRIES}，拒绝导入`)
    }
    const out: WorldInfoEntry[] = []
    for (const [mapKey, value] of pairs) {
      if (!isRecord(value)) continue
      out.push(parseEntry(value, mapKey, opts))
    }
    return out
  }
  throw new Error('世界书 JSON 缺少 entries（对象 map 或数组）')
}

// ---------------------------------------------------------------------------
// 导出
// ---------------------------------------------------------------------------

/**
 * 导出为角色卡 V2/V3 规范的 character_book（对齐 ST convertWorldInfoToCharacterBook）：
 * entries 是数组，字段为 keys/insertion_order/enabled，引擎细节放在 extensions 的 snake_case 键。
 * ST 读取卡内书时按数组遍历，原生世界书的 uid map 形态会让整本书无法导入。
 */
export function exportCharacterBook(entries: WorldInfoEntry[], name: string): Record<string, unknown> {
  return {
    name,
    extensions: {},
    entries: entries.map((e) => ({
      id: /^(0|[1-9]\d*)$/.test(e.uid) && Number.isSafeInteger(Number(e.uid)) ? Number(e.uid) : e.uid,
      keys: e.keys,
      secondary_keys: e.secondaryKeys,
      comment: e.comment,
      content: e.content,
      constant: e.constant,
      selective: e.selective,
      insertion_order: e.order,
      enabled: e.enabled,
      position: e.position === 0 ? 'before_char' : 'after_char',
      use_regex: true,
      extensions: {
        position: e.position,
        exclude_recursion: e.excludeRecursion,
        prevent_recursion: e.preventRecursion,
        delay_until_recursion: e.delayUntilRecursion,
        probability: e.probability,
        useProbability: e.useProbability,
        depth: e.depth,
        selectiveLogic: e.selectiveLogic,
        outlet_name: e.outletName,
        group: e.group,
        group_override: e.groupOverride,
        group_weight: e.groupWeight,
        scan_depth: e.scanDepth,
        case_sensitive: e.caseSensitive,
        match_whole_words: e.matchWholeWords,
        use_group_scoring: e.useGroupScoring ?? null,
        automation_id: e.automationId,
        role: e.role,
        sticky: e.sticky,
        cooldown: e.cooldown,
        delay: e.delay,
        ignore_budget: e.ignoreBudget,
      },
    })),
  }
}

/** 卡内书是否已是规范数组形态（且每条都是角色书条目）；是则导出时原样保留作者的额外字段。 */
export function isSpecCharacterBook(value: unknown): boolean {
  return isRecord(value) && Array.isArray(value.entries)
    && value.entries.every((entry) => isRecord(entry) && isCharacterBookEntry(entry))
}

/**
 * 导出为 SillyTavern 原生形态 {entries: {<uid>: {...}}}（camelCase 字段对齐原生 WI JSON）。
 * name 不写入文件（ST 原生世界书 JSON 无此字段），保留在签名中供调用方传递命名上下文。
 */
export function exportLorebook(entries: WorldInfoEntry[], name: string): unknown {
  void name // ST 原生世界书 JSON 无 name 字段，不写入
  const map: Record<string, unknown> = Object.create(null)
  for (const e of entries) {
    map[e.uid] = {
      uid: e.uid,
      key: e.keys,
      keysecondary: e.secondaryKeys,
      comment: e.comment,
      content: e.content,
      constant: e.constant,
      disable: !e.enabled,
      order: e.order,
      position: e.position,
      depth: e.depth,
      role: e.role,
      outletName: e.outletName,
      probability: e.probability,
      useProbability: e.useProbability,
      selective: e.selective,
      selectiveLogic: e.selectiveLogic,
      scanDepth: e.scanDepth,
      caseSensitive: e.caseSensitive,
      matchWholeWords: e.matchWholeWords,
      useGroupScoring: e.useGroupScoring ?? null,
      excludeRecursion: e.excludeRecursion,
      preventRecursion: e.preventRecursion,
      delayUntilRecursion: e.delayUntilRecursion,
      sticky: e.sticky,
      cooldown: e.cooldown,
      delay: e.delay,
      ignoreBudget: e.ignoreBudget,
      group: e.group,
      groupWeight: e.groupWeight,
      groupOverride: e.groupOverride,
      automationId: e.automationId,
    }
  }
  return { entries: map }
}

// ---------------------------------------------------------------------------
// 变化层固化
// ---------------------------------------------------------------------------

/**
 * 固化导出用：把生效中的 delta 合并进原书条目，返回新数组（不改入参）。
 * - update → 替换 ref 条目 content
 * - invalidate → 标记 ref 条目 enabled=false
 * - add → 追加新条目（source 'global'，uid `delta-<id>`，position 默认 AfterCharDefs）
 * revoked 与已过期（expires <= 当前时间）的 delta 忽略；ref 未命中的 update/invalidate 同样忽略。
 */
export function mergeDeltasForExport(originals: WorldInfoEntry[], deltas: WorldDelta[]): WorldInfoEntry[] {
  const now = Date.now()
  const result = originals.map((e) => ({ ...e, keys: [...e.keys], secondaryKeys: [...e.secondaryKeys] }))
  const byUid = new Map(result.map((e) => [e.uid, e]))

  for (const delta of deltas) {
    if (delta.revoked) continue
    if (delta.expires !== null) {
      const expiresAt = Date.parse(delta.expires)
      if (!Number.isNaN(expiresAt) && expiresAt <= now) continue
    }

    if (delta.type === 'add') {
      const baseUid = `delta-${delta.id}`
      let uid = baseUid, suffix = 0
      while (byUid.has(uid)) uid = `${baseUid}#${++suffix}`
      const entry: WorldInfoEntry = {
        key: `global:delta:${uid}`,
        uid,
        source: 'global',
        sourceRef: 'delta',
        keys: [...delta.keys],
        secondaryKeys: [],
        selective: false,
        selectiveLogic: 0,
        comment: `世界状态变化 ${delta.id}`,
        content: delta.content,
        constant: delta.keys.length === 0,
        enabled: true,
        order: delta.order,
        position: 1,
        depth: 4,
        role: 0,
        outletName: '',
        probability: 100,
        useProbability: true,
        caseSensitive: null,
        matchWholeWords: null,
        scanDepth: null,
        excludeRecursion: false,
        preventRecursion: false,
        delayUntilRecursion: 0,
        sticky: null,
        cooldown: null,
        delay: null,
        ignoreBudget: false,
        group: '',
        groupWeight: 100,
        groupOverride: false,
        automationId: '',
      }
      result.push(entry)
      byUid.set(uid, entry)
      continue
    }

    if (delta.ref === null) continue
    const target = byUid.get(delta.ref)
    if (!target) continue
    if (delta.type === 'update') target.content = delta.content
    else target.enabled = false
  }

  return result
}
