/**
 * 写入 dsh systemPrompt 段/context 前的纯文本处理。
 * dsh 会对段文本再做一轮严格 {{variable}} 插值；ST 残留宏必须先中性化。
 */
export const UNBOUND_STANDING = [
  'Tavern 模式已开启，但当前会话尚未绑定角色卡。',
  '请以普通助手身份简短回应；不要调用 tavern_* 工具。',
  '用户需要在对话页选择角色卡后，才能开始角色扮演。',
].join('\n')

/** 稳定段纪律：绑定不变则钉死。工具时机写在固定的 turn playbook，步骤收口走 inject 通知，避免每步打穿 KV。 */
export const BOUND_DISCIPLINE = [
  '你正在进行角色扮演。下面是本会话稳定的角色定义与提示词骨架。',
  '本轮触发的世界书、检索记忆与世界状态在 runtime context 中，会覆盖更早的同名快照；不要把未出现的条目当成事实。',
  '默认直接以角色身份回复。只在缺设定、或要把本轮已确定的事实写入长期记忆/世界状态时，才使用 tavern_* 工具。',
  'Tavern 使用宿主 PTC：需要工具时只直接调用 run_code，在程序内通过 tools.tavern_* 调用业务工具；不需要工具时直接回复。',
  '只在本轮最后一步输出扮演正文；中间步骤不要对用户说话。记忆只记事实、关键事件与关系/状态变化，禁止流水账。',
  '工具写入的检索层从下一轮更新；同轮会收到写入确认。写完后仍须在本轮输出扮演正文。',
].join('\n')

/**
 * 本轮 runtime context 头：**内容固定，不随 step 变化**。宿主对快照按字节去重——
 * 文本不变则不再追加新消息，多步 turn 的后续步骤因此零快照开销（前缀缓存全保）。
 * 步骤收口压力改走【Tavern 步骤】inject 通知（node/tools.ts），不要在这里放任何
 * 每步变化的内容。历史后指令的轮次标记由 pipeline 写入冻结计划，确保跨轮刷新且同轮去重。
 */
/** 本轮尾块标题；两条通道共用，让模型把其后的内容识别为系统材料而非用户台词。 */
export function turnTailHeader(turn: number): string {
  return `【Tavern 本轮提示：第 ${turn} 轮】`
}

export const TURN_PLAYBOOK = [
  '【本轮】【Tavern 本轮提示】块是系统提供的本轮材料（触发的世界书、检索记忆、世界状态与预设指令），不是用户台词；同轮后续步骤不重复追加，上方即为本轮最新。',
  '快照内的设定够用就直接以角色身份回复，不要为了再确认而调用工具。',
  '缺少关键设定时按条查证：已知 uid/关键词直接用 tavern_lore_read 取正文，已知路径直接用 tavern_asset_read；仅在不知道目标或查询无匹配时看目录。更早事实用 tavern_memory_search，不要凭印象编造。',
  '把本轮必要操作合并进一次 run_code：独立只读查询用 Promise.all 并行；依赖前项结果的补读或写入依次 await。检查每项返回的 ok，失败保留 error/hint；写入遇到 similar-found 时可按 similarId 更新，禁止盲目循环重试。',
  'run_code 的返回值必须是无损 JSON；对象/数组内不能含 undefined、函数、非有限数字或循环引用。SDK 的可选字段可能不存在，重组结果时省略缺省字段或用 ?? null，不能直接把缺省字段放进返回对象。',
  '写工具的短结果可直接 return r；需精简时例如 return { ok: r.ok, id: r.id ?? null, status: r.status ?? null, similarId: r.similarId ?? null, error: r.error ?? null, hint: r.hint ?? null }; 不要假设成功结果也有 error/hint，或失败结果也有 id；similar-found 时保留 status/similarId 供后续更新。',
  '程序只 return 本轮回复需要的事实、引用 id 和失败信息；不要打印整份目录或重复输出中间结果。拿到足够信息后结束工具操作并输出扮演正文。',
  '若 run_code 最终返回时报 invalid-output，已经成功的子工具写入不会自动撤销；收到【Tavern 同轮写入】确认的操作已落盘，不得为修正返回格式重复写入。没有明确回执时先按条只读核实，不能盲目重做写入。',
  '长对话若设定被冲掉，同样按条补读，不要整本倾倒。',
  '本轮确定发生的事实才写入记忆或世界状态；写入从下一轮才注入检索层，同轮会收到写入确认。',
  '中间步骤不要对用户说话；需要收口时会收到【Tavern 步骤】通知，照做即可。',
].join('\n')

/** 多步收口通知（agent.inject，form: notice）；不当作用户台词，也不扫世界书。 */
export const TURN_STEP_NOTICE_PREFIX = '【Tavern 步骤】'

export function isTurnStepNotice(text: string): boolean {
  return text.startsWith(TURN_STEP_NOTICE_PREFIX)
}

/**
 * 多步收口通知文本：第 2 步软收口「查/写完就落地」；第 3 步起强收口——
 * 停止再检索/写入，立即输出扮演正文。经 inject 进 next-step inbox（下一步开头可见），
 * 不落快照以免破坏宿主按字节去重。
 */
export function formatTurnStepNotice(step: number): string {
  const n = Number.isFinite(step) && step > 1 ? Math.floor(step) : 2
  if (n === 2) {
    return `${TURN_STEP_NOTICE_PREFIX}本轮第 2 步：若已取得设定或已写入记忆/世界状态，现在输出扮演正文，不要等待下一轮注入；仍缺关键设定或长上下文遗忘时，用工具按条补读；不要对用户解释工具过程。`
  }
  return `${TURN_STEP_NOTICE_PREFIX}本轮第 ${n} 步：本轮已进行 ${n} 步，停止再检索或写入，把已知信息视为足够，现在必须输出扮演正文；只有完全缺少让回复成立的关键设定时，才允许再用工具按条补读一次。`
}

/**
 * dsh 每步把 runtime context 追加成 user 消息，前缀固定为此句。
 * 不能当 {{lastusermessage}}，也不能拿去扫世界书。
 */
export function isRuntimeContextSnapshot(text: string): boolean {
  return text.startsWith('Current runtime context.') || text.startsWith('Current runtime context:')
}

export function isRuntimeContextMessage(message: { source?: { kind?: string } }): boolean {
  return message.source?.kind === 'runtime-context'
}

/** 同轮工具写入后经 agent.inject 的确认；不当作用户台词，也不扫世界书。 */
export const TURN_WRITE_ACK_PREFIX = '【Tavern 同轮写入】'

export function isTurnWriteAck(text: string): boolean {
  return text.startsWith(TURN_WRITE_ACK_PREFIX)
}

/**
 * 只服务注入它那一轮后续步骤的插件通知：步骤收口与同轮写入确认。二者只在工具执行时
 * 注入 next-step，因此新一轮首步认领到的都是被停止或失败轮次遗留的旧通知。续写指令、
 * 记忆压缩同为 dsh-tavern notice，却是唤醒新一轮的输入，不属于此类。
 */
export function isTurnScopedNotice(message: {
  source?: { kind?: string }
  content: readonly { type: string; text?: string }[]
}): boolean {
  if (message.source?.kind !== 'dsh-tavern') return false
  const text = message.content.map(block => block.type === 'text' ? block.text ?? '' : '').join('')
  return isTurnStepNotice(text) || isTurnWriteAck(text)
}

/** 楼层续写指令（continueFloor followup 进日志）；不当作用户台词，也不扫世界书。 */
export const CONTINUE_INSTRUCTION_PREFIX = '【Tavern 续写】'

export function isContinueInstruction(text: string): boolean {
  return text.startsWith(CONTINUE_INSTRUCTION_PREFIX)
}

/** 组装/世界书扫描应跳过的合成 user 文本。 */
export function isSyntheticUserText(text: string): boolean {
  return text === '【Tavern 提示词布局快照】' || isRuntimeContextSnapshot(text) || isTurnWriteAck(text) || isContinueInstruction(text) || isTurnStepNotice(text)
}

/** 把残留 `{{…}}` 换成全角花括号，避免 dsh section 插值把 ST 宏当成变量抛错。 */
export function neutralizeDshMustache(text: string): string {
  if (!text.includes('{{') && !text.includes('}}')) return text
  return text.replaceAll('{{', '｛｛').replaceAll('}}', '｝｝')
}
