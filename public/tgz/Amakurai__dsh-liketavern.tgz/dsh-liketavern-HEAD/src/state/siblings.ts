/**
 * 分支兄弟索引存储：`<数据目录根>/siblings.json`，整体读改写（文件小，记录 = 一次楼层 fork）。
 *
 * 这是导航元数据，不是剧情状态：不经 WorkspaceFs、不记 WAL——回退/回滚楼层不应撤销
 * 「这个分支会话曾经创建过」的事实（分支会话本身也仍在）。删卡/解绑清掉绑定后，
 * 读路径（node/floors.ts getFloorSiblings）按存在性剪枝并落盘。
 *
 * 所有读改写（追加登记 / 读路径剪枝）必须经 mutateSiblingForks：模块级互斥串行化，
 * 否则不同会话的并发 fork 登记 / 剪枝落盘会互相覆盖丢记录。
 */
import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { normalizeSiblingForks, recordSiblingFork, type SiblingFork } from '../core/siblings.js'
import { atomicWrite } from './atomicWrite.js'
import { withWorkspaceLock } from './workspaceLock.js'

export function siblingsFile(rootDir: string): string {
  return join(rootDir, 'siblings.json')
}

/** 读取索引并区分「文件缺失」与「文件损坏」：读路径两者都当空索引，写路径不得把损坏覆盖成空。 */
async function readSiblingForks(rootDir: string): Promise<{ forks: SiblingFork[]; corrupt: boolean }> {
  let raw: string
  try {
    raw = await readFile(siblingsFile(rootDir), 'utf8')
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return { forks: [], corrupt: false }
    throw error
  }
  try {
    const value: unknown = JSON.parse(raw)
    const forks = normalizeSiblingForks(value)
    // JSON 可解析不等于索引完整；写路径不能借容错归一化静默删除坏记录。
    return { forks, corrupt: !Array.isArray(value) || forks.length !== value.length }
  } catch {
    return { forks: [], corrupt: true }
  }
}

/** 读取索引；文件缺失或损坏视为空索引。 */
export async function loadSiblingForks(rootDir: string): Promise<SiblingFork[]> {
  return (await readSiblingForks(rootDir)).forks
}

/** 原子替换：崩溃不会留下截断的索引文件（截断后读成空索引，再一次登记就把全部导航记录永久抹掉）。 */
export async function saveSiblingForks(rootDir: string, forks: readonly SiblingFork[]): Promise<void> {
  await atomicWrite(siblingsFile(rootDir), JSON.stringify(forks, null, 2) + '\n')
}

/**
 * 互斥内的读-改-写：fn 拿到磁盘现状，返回新值（等于原值则不落盘）。
 * fn 自身不要再调 mutateSiblingForks，避免外层旧快照覆盖内层刚写入的登记。
 */
export async function mutateSiblingForks(
  rootDir: string,
  fn: (forks: SiblingFork[]) => Promise<SiblingFork[]> | SiblingFork[],
): Promise<void> {
  await withWorkspaceLock(siblingsFile(rootDir), async () => {
    const { forks, corrupt } = await readSiblingForks(rootDir)
    if (corrupt) throw new Error('分支兄弟索引 siblings.json 损坏，拒绝以空索引覆盖；请修复或删除该文件')
    const next = await fn(forks)
    if (next !== forks && JSON.stringify(next) !== JSON.stringify(forks)) {
      await saveSiblingForks(rootDir, next)
    }
  })
}

/** 读-改-写追加一条 fork 记录（recordSiblingFork 幂等）。 */
export async function appendSiblingFork(rootDir: string, entry: SiblingFork): Promise<void> {
  await mutateSiblingForks(rootDir, (forks) => recordSiblingFork(forks, entry))
}
