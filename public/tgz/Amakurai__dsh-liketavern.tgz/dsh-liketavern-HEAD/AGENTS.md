# AGENTS.md

给维护者与编码代理的约定。用户说明见 [README](README.md)，状态与提示词设计见 [架构说明](docs/ARCHITECTURE.md)，宿主版本行为见 [兼容记录](docs/HOST_COMPATIBILITY.md)。约定可以在说明理由并验证行为后修改；不要把历史实现当作不可质疑的产品要求。

## 项目与环境

dsh-liketavern 为 DeepSeek Harness 的 Tavern 插件。角色卡、预设、世界书、人设、正则、记忆、世界变化层和分支操作共用 dsh agent 运行时。普通扮演不另起发信通道；AI 代答是明确的辅助调用。

当前基线：dsh / @deepseek-ai 包 0.2.0-rc.2、Node 24、Windows；CI 为 Ubuntu。TypeScript ESM，NodeNext，strict + noUncheckedIndexedAccess，相对导入显式 `.js`。

查宿主机制先看 [官方文档](https://deepseek-harness.github.io/deepseek-harness/) 和已安装包的 `lib/`、`.d.ts`，先核对各包 package.json；不要凭旧版本记忆推断 slot、profile、patch、system-prompt 或事件时序。

## 必须保持的边界

1. **角色资产共享，剧情状态隔离。** `workspace(cardId)` 是角色资产与新会话初始状态；运行中的会话必须经绑定的 `storyId` 使用 `storyWorkspace(cardId, storyId)`。记忆、变化层、笔记、聊天世界书、定时器与 WAL 都属于剧情。不得让 agent、维护或楼层操作退回 cardId 共享可变状态。
2. **分支先准备，后发布。** 锁住来源剧情做文件快照，在草稿内回滚未继承楼层，成功后原子发布，再创建/绑定宿主子会话。不得回滚原会话状态。编辑 assistant 正文撤销该层及后续的派生事实，不自动重新提取事实；用户随后接话或手动修订。
3. **每次楼层写入先 WAL 后正文。** 每轮用 `withFloor(floor)` 派生句柄；共享句柄 floor 恒为 null。面板与维护用 `plainWorkspace(cardId, storyId)`。完整读改写、分支快照与回滚共用工作区锁。损坏日志必须在整批回滚前拒绝；恢复游标必须先于正文替换持久化。不要用“跳过坏行并标记成功”处理故障。唯一不记 WAL 的楼层写入是未结束轮次的生成恢复正文（`state/template-generation/`）：它每轮整体替换，按内容摘要由根引用，必须先于引用它的根落盘；根里的归属与摘要照常经 WAL 提交和回滚，回滚算法不读取正文。清理必须保留当前根及本层最终回滚根引用的正文，尤其不能删除楼层外手动维护打断连续写入后仍可恢复的 prepared 正文；无法确认可达性时保守保留。
4. **归档来源是数据，摘要是派生视图。** 自动摘要只接受正常 stop 终止帧，错误、截断、无终止帧或超时不能归档原文。失败保留 pending 标记等下一次 idle。检索包含活跃摘要可达的归档来源；去重只查活跃条目。回滚先展开受影响来源链，再撤销事实。
5. **模型请求遵守宿主边界。** standing 是工具说明后的 `tavern:standing`（`getSectionOrder('TOOLS_SDK') + 10`），turn 是 runtime context `tavern:turn`；绝不使用 complete 段盖掉工具前缀，不改 llm/stream 冻结请求。DeepSeek 官方普通聊天可由自持有的公开 DeepSeekAdapter 装饰器进行预设布局投影，仍由同一个 AgentLoop 发信。布局由合法 user/message 的可扩展来源元数据持久化，按消息 ID 定位并保留图片、工具与原始历史；不把插件 assistant 条目伪造为模型日志。适配器复用公开宿主配置和凭证，同代 prepareCall 不重新进入 llm/stream。其它通道沿用两段映射，历史后/depth=0 位于每轮 turn 尾。ST 全量序列仍是模拟，不能称为实际入模消息；实际投影诊断须标记边界。input/send、prompt/assemble、prompt/send 的历史改写只用于模拟与代答；live 展示规则是 output/render。

   预设投影必须使用同次 prepareCall 冻结的模型能力：`systemPromptUpdate=in-history` 的每条 system 是完整快照，不能让后置预设替代 SDK；未声明该能力时系统条目合并到唯一首条并提供兼容说明。完整快照可能增加请求长度，拼接前须有累计上限；不得把逻辑布局中的独立 system 条目直接当作供应商已支持的增量系统消息。
6. **第三方正则与模板不得在 host 主线程执行。** node 调用 `isolated()` 执行 WI、组装与渲染；EJS JavaScript 仅在 worker 内的 QuickJS/WASM 中执行，不暴露 Node、DOM、网络或模块加载器。超时、异常退出、超量输入/输出必须明确失败。core 保持纯函数，静态正则启发式只是提前拒绝，不能代替隔离。模板变量和回复快照属于剧情，预览/重绘不得写入，正常 stop 回复在 turn/end 内只提交一次。

   持久 VM 检查点只允许专属 WASM 实例、精确引擎与包装器布局、无宿主函数引用且调用栈已退出的静止点。v1 引擎的 JS 胶水、包装器、FFI 与 WASM 整包冻结在 `vendor/checkpoint-engine-v1/`；普通构建只校验并复制到发布目录，不从当前 npm 依赖重建或就地替换，新增引擎另开版本目录。模板 helper/vendor 的实现指纹与宿主通信 ABI 分别记录：仅当前受信指纹或已登记的旧指纹可按相应 ABI 恢复，保存后续检查点仍保留该堆实际运行的旧指纹；旧 helper/vendor 随旧堆保留到环境结束，不重新运行新 bootstrap 覆盖闭包。未知、已撤销或 ABI 不匹配的运行时须在开层、恢复计划和提交前拒绝；任意未来不兼容引擎仍需独立适配或迁移。

   缩减映像前须完整校验固定 dlmalloc 布局；仅清除快照副本中已释放块的载荷，保留分配器元数据和全部活对象。最高地址的连续空闲区可在副本中裁剪，至少保留 4 KiB top 并同步更新相关分配器元数据；内部空闲碎片不搬移，不能承诺无限恒定大小。v2 映像用 null 表示零页，读取仍兼容 v1。不为保存额外触发 GC，不改变 Promise 队列或 WeakRef 的原有行为。摘要校验不是存档认证；必须保留封闭宿主导入、有界解压、WASM 内存边界及 worker 超时。continuation 检查点的分页属于普通剧情状态，照常记 WAL，不能按临时生成正文删除。
7. **每轮冻结完整提示词计划。** 角色/预设/人设、修订指纹、宏时钟、检索结果与采样在首次成功组装后缓存；后续步骤重放同一份快照。资产编辑下一轮生效，不得把旧内容钉在新修订号下。工具写成功通过 notice 确认，不在同轮重评 WI。`STANDING_PIN_VERSION` 在纪律或段布局变化时递增。
8. **不把第三方代码提升到主页面权限。** 交互卡 iframe 为 `sandbox="allow-scripts"`，不加 allow-same-origin；CSP 默认禁止 connect，允许 http/https/data 图片与字体。卡面桥只开放枚举的业务操作与高度通知，不增加任意 remote 调用、文件路径或主窗口 DOM 桥，不伪造父窗口 Vue/SillyTavern。各桥共同遵守：
   - 校验事件来源窗口与事件运行时；sessionId 与宿主消息 seq 由气泡固定，写入复核 storyId、历史修订与生成状态，经剧情锁和 WAL。绑定变化或运行时切换后，旧令牌、许可与回执失效。
   - 改写历史消息（正文、data/extra、消息页、删除）在独立草稿分支中准备，撤销最早修改层起的派生事实，回执确认后才导航子会话；子会话楼层用携带 WAL 的 WorkspaceFs 写入。
   - 脚本库是共享静态资产，不记剧情 WAL；保存校验绑定令牌与资产修订，冲突拒绝覆盖。
   - 显示刷新与重绘只读，不重新提交模板变量；失败或超时解除准备锁并保留原卡。
   - 超限输入、冲突草稿和不兼容框架明确失败，不以空结果或等待队列结束冒充成功。

   各桥完整规则见 [酒馆助手运行层 · 桥接维护约束](docs/TAVERN_HELPER.md#桥接维护约束)；改动任一桥前先读该节，规则变化时同步更新。
9. **文件边界与私有数据。** 工具路径经 `resolveReadableAssetPath` 和 `WorkspaceFs`；不读取 WAL、其它 stories、内部 story.json 或二进制。卡片资产与当前剧情合成目录必须排除兄弟剧情。真实数据只在 `$DSH_HOME/dsh-tavern/`，不得进入源码、测试、Git 或 npm 包。

锁是进程内的，同一 DSH_HOME 不支持多宿主进程并发写。旧共享数据首次迁移会保留原目录并复制；已经混合的历史事实无法自动可靠拆分。详见架构说明，不要声称可以无损推断旧分支归属。

## 三面与契约

- host：`src/index.ts` 注册设置、数据目录、预设、service、remote、会话生命周期与请求诊断。
- agent：`src/agent.ts` 组装 standing/turn、合入采样、注册工具和 idle 维护。
- client：`src/client/` 注册五块 slot，只经 typert remote 访问业务状态。
- core：纯函数；state：文件存储；node：宿主编排。

`src/remote.ts` 的 METHODS 必须完整满足 TavernMethodResults 的键集合。TavernMethodRequests 从 schema 推导，TavernRemote 从请求/结果映射生成；service implements TavernServiceContract。新增方法修改 schema、结果表和 service，编译会检查缺项与类型。不再手写客户端请求镜像。

方法返回裸业务值，失败抛错，gateway 生成 `{ ok, value|error }`。复杂资产用 unknown 传输，在服务/存储边界归一化验证，不能因有 TypeScript 注解就信任 JSON。

业务工具共七个：memory_search、memory_write、memory_update、lore_read、worldstate_update、asset_list、asset_read（均带 tavern_ 前缀）。Tavern 预设使用宿主原生 PTC，模型直接调用 run_code，程序经 tools.tavern_* 使用结构化返回值；四个读工具允许并行，三个写工具保持宿主独占屏障。默认直接扮演，只有缺设定、遗忘或已确定事实需要落盘时调用；已知 uid/query/path 直接读取，未知目标才看目录，目录与结果仍有预算，禁止整本倾倒。

## 易回归的交互与宿主细节

- cardId 是净化目录名加 hash；展示永远用 card.name。同名卡不覆盖；删除后清绑定，陈旧绑定经 resolveStaleBinding 自愈。
- 导入先 inspectCharacter，不落盘；内嵌世界书由用户选择是否导入，拒绝导入时卡与资产两处都清空。
- 新会话不自动绑默认卡。默认设置只在点选卡时套用；hero 的空白判定和 seatWatch 补偿见兼容记录。
- fork 用 agents.create（session- 前缀）+ workspace.attachSession，带父会话最新 provider/model；开场白预先写进 seed。客户端先 refresh 再 open 子会话。
- 宿主消息栏「在新对话中分支」不经插件：`session/created` 时由 adoptHostFork 为已绑定来源的种子子会话准备独立剧情后绑定，接管期间 loadBinding 等待。插件自身分支在 create 前登记 pluginForkIds 排除，否则同一子会话会被准备两份剧情。
- 会话级宿主 lineage 面包屑与楼层兄弟导航互补；不要占掉原生 lineage slot。被中断 assistant 仅在没有对应 turn-tail 持久消息操作栏时由 chat.node 按 turn 补挂，避免同层重复按钮。
- runtime context、同轮写入、续写和步骤 notice 均经 isSyntheticUserText 过滤，不当作用户台词，不参与 WI、lastusermessage 或正则 depth。
- 步骤收口 notice 只在工具执行时 inject，不放 agent/pre-step，否则宿主可能多拉出孤儿步骤。
- 采样只透传 temperature/maxTokens/stop 和模型公布的 reasoningEffort；top_p、penalty 仅记录。部署锁定 thinking disabled 时插件不能强开。

## UI 与类型

使用真实 React / 宿主 primitives 类型，不添加 `any` JSX 或模块垫片来让编译通过。开发类型依赖不进入运行 bundle；平台模块保持 external。

remote 经 `$mount(TYPERT_REMOTE)` 安装，调用 `ctx.get('remote.tavern')`，不要在 inject 里声明 remote.tavern。交互组件用宿主 primitives（封装在 util.tsx）；不用原生 select 或 window.confirm。确认用 ConfirmDialog，表单用 SettingsRow/SaveBar，反馈用 Toast，加载用 Skeleton，页签用 Tabs。

样式集中 styles.ts，只用已有 --dsw-* / --tavern-accent-* 变量。动效遵守 prefers-reduced-motion。文案走 useT 与 client/locales 分模块字典，zh/en 同键完整。消息图片用 owner renderMessageImages；MarkdownText 的 labels 与 fileMentions 必须符合宿主真实类型。

## 验证与交付

```bash
npm ci
npm run build
npm test
npm pack --dry-run
```

- 改 core/state 必须有对应行为测试。涉及宿主事件、分支、请求或故障时，补真实文件系统 + 模拟宿主/适配器的集成测试；不得以“host/UI 不测”为由跳过关键路径。
- 重点回归：storyIsolation、transactionRecovery、robustBoundaries、pipelineCache、floorConcurrency、i18n。测试用手写工厂数据，不调用真实模型。
- tests 直接 import src；Node 24 下 worker 源码测试使用类型剥离，交付运行只用 lib JS。正则超时测试必须在隔离 worker 中进行。
- 每个源文件和测试用中文块注释说明职责；标识符英文。测试验证业务结果与失败边界，避免只镜像实现。
- 运行依赖为 zod、quickjs-emscripten、yaml、lodash、jsonrepair、@faker-js/faker、ejs、markdown-it、markdown-it-emoji、jquery；jquery 仅随卡面库脚本文本打包，在 opaque-origin iframe 内执行，不能在宿主或主页面执行。模板库用于实际兼容编译参数、消息格式化、schema、Lodash、模型 JSON 修复与 Faker 全语言数据，构建为带原始及传递依赖许可证的 QuickJS 内部脚本，不桥接 Node 函数。Markdown 格式化仅在可终止 worker 的 QuickJS 中执行，不生成 metadata 完整文档或标题 ID；HTML 产物只能交给原有沙箱 iframe，不能放入主页面。已移除无公开补丁的 Showdown；格式化器升级使用 replay.formatterVersion 边界，旧活动日志不能静默改 hash、丢闭包或在拒绝前推进 WAL。隔离 JavaScript、有界初值解析与新增兼容库固定公开 npm 版本，不用 node:vm 冒充安全边界。宿主包走精确 peer，开发依赖公开 npm 精确版本。禁止 file:、绝对路径或链接依赖；开发挂载仓库的 junction/symlink 是另一件事。
- lib/ 刻意入库。所有 src 改动必须重建；CI 会拦过期、缺失和未跟踪产物。不要忽略 lib/。
- npm 包白名单：lib、cordis.patch.yml、presets、README 两种语言、CHANGELOG、LICENSE。禁止 src/test/node_modules/本机数据。
- 宿主升级按 [版本核对清单](docs/HOST_COMPATIBILITY.md) 执行；构建/测试不能代替安装环境的 boot 与 UI 冒烟。
