/**
 * TavernService：remote 方法实现（薄壳，组合 state/floors/pipeline）。
 *
 * 平台约定：方法返回裸业务值，失败抛错（FloorError.message 原样透出给 client）。
 * { ok, value | error } 信封由 typert gateway（host invokeRpc / client invoke）生成，
 * 这里不要再包一层（双层信封会让 client 的 r.value.xxx 全部读到 undefined）。
 * 每个方法的返回注解指向 ../remote.ts 的 TavernMethodResults——结果形状的单一来源，
 * client 镜像（client/types.ts）索引同一张表，两面形状漂移会立刻编译报错。
 */
import type { TavernServiceContract } from '../remote.js';
import type { Context } from '@deepseek-ai/cordis';
import type { TavernSettingsScope } from './config.js';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { TavernState } from './state.js';
import type { TavernMethodResults, TavernMethodRequests } from '../remote.js';
export declare class TavernService extends TypertRemoteService implements TavernServiceContract {
    /** 运行时中枢（agent 面插件经 ctx.tavern 访问）。 */
    readonly state: TavernState;
    private readonly settingsScope;
    constructor(ctx: Context, 
    /** 运行时中枢（agent 面插件经 ctx.tavern 访问）。 */
    state: TavernState, settingsScope: TavernSettingsScope);
    listSessionImportWorkspaces(_request: TavernMethodRequests['listSessionImportWorkspaces']): Promise<TavernMethodResults['listSessionImportWorkspaces']>;
    exportSessionArchive(request: TavernMethodRequests['exportSessionArchive']): Promise<TavernMethodResults['exportSessionArchive']>;
    importSessionArchive(request: TavernMethodRequests['importSessionArchive']): Promise<TavernMethodResults['importSessionArchive']>;
    /**
     * 头像 dataURL 进程内缓存：getAvatar 每次调用都全文读盘 + Base64 编码整图，
     * 与会话头/英雄区的渲染频率不匹配。指纹用 WorkspaceFs.stat('card.png') 的
     * mtimeMs+size——与 state.ts 卡级正则指纹缓存同一思路：一次 stat 不读数据，
     * 且能捕获绕开写方法直写磁盘的路径（WAL 回滚 / 外部换图）。
     */
    private readonly avatarCache;
    getEditorDraft(request: {
        owner: string;
        key: string;
    }): Promise<TavernMethodResults['getEditorDraft']>;
    saveEditorDraft(request: {
        owner: string;
        key: string;
        value: unknown;
    }): Promise<TavernMethodResults['saveEditorDraft']>;
    deleteEditorDraft(request: {
        owner: string;
        key: string;
    }): Promise<TavernMethodResults['deleteEditorDraft']>;
    getSettings(_request: Record<string, never>): TavernMethodResults['getSettings'];
    updateSettings(request: {
        patch: unknown;
    }): Promise<TavernMethodResults['updateSettings']>;
    listCharacters(_request: Record<string, never>): Promise<TavernMethodResults['listCharacters']>;
    listArchivedCharacters(_request: Record<string, never>): Promise<TavernMethodResults['listArchivedCharacters']>;
    archiveCharacter(request: {
        cardId: string;
    }): Promise<TavernMethodResults['archiveCharacter']>;
    restoreCharacter(request: {
        cardId: string;
    }): Promise<TavernMethodResults['restoreCharacter']>;
    /** 读取前端之外的调用也先守住 PNG 编码体积；不能等 Buffer 分配完成后才在解析器拒绝。 */
    private decodeCharacterUpload;
    inspectCharacter(request: {
        name: string;
        dataBase64: string;
    }): Promise<TavernMethodResults['inspectCharacter']>;
    importCharacter(request: {
        name: string;
        dataBase64: string;
        importWorldBook?: boolean;
    }): Promise<TavernMethodResults['importCharacter']>;
    getCharacterDeletePlan(request: {
        cardId: string;
    }): Promise<TavernMethodResults['getCharacterDeletePlan']>;
    deleteCharacter(request: {
        cardId: string;
        discardStoryIds?: string[];
    }): Promise<TavernMethodResults['deleteCharacter']>;
    getCharacterDetail(request: {
        cardId: string;
    }): Promise<TavernMethodResults['getCharacterDetail']>;
    saveCharacter(request: {
        cardId: string;
        expectedRevision?: string;
        name?: string;
        description?: string;
        personality?: string;
        scenario?: string;
        firstMes?: string;
        alternateGreetings?: string[];
        mesExample?: string;
        systemPrompt?: string;
        postHistoryInstructions?: string;
        creatorNotes?: string;
        creator?: string;
        characterVersion?: string;
        tags?: string[];
        depthPrompt?: {
            prompt: string;
            depth: number;
            role: 'system' | 'user' | 'assistant';
        } | null;
    }): Promise<TavernMethodResults['saveCharacter']>;
    createCharacter(request: {
        name: string;
    }): Promise<TavernMethodResults['createCharacter']>;
    exportCharacter(request: {
        cardId: string;
    }): Promise<TavernMethodResults['exportCharacter']>;
    listPresets(_request: Record<string, never>): Promise<TavernMethodResults['listPresets']>;
    importPreset(request: {
        name: string;
        json: unknown;
    }): Promise<TavernMethodResults['importPreset']>;
    savePreset(request: TavernMethodRequests['savePreset']): Promise<TavernMethodResults['savePreset']>;
    deletePreset(request: {
        id: string;
    }): Promise<TavernMethodResults['deletePreset']>;
    getPreset(request: {
        id: string;
    }): Promise<TavernMethodResults['getPreset']>;
    listLorebooks(_request: Record<string, never>): Promise<TavernMethodResults['listLorebooks']>;
    getLorebook(request: {
        name: string;
    }): Promise<TavernMethodResults['getLorebook']>;
    importLorebook(request: {
        name: string;
        json: unknown;
    }): Promise<TavernMethodResults['importLorebook']>;
    saveLorebook(request: TavernMethodRequests['saveLorebook']): Promise<TavernMethodResults['saveLorebook']>;
    deleteLorebook(request: {
        name: string;
    }): Promise<TavernMethodResults['deleteLorebook']>;
    getCharacterLorebook(request: {
        cardId: string;
    }): Promise<TavernMethodResults['getCharacterLorebook']>;
    saveCharacterLorebook(request: TavernMethodRequests['saveCharacterLorebook']): Promise<TavernMethodResults['saveCharacterLorebook']>;
    deleteEmbeddedLorebook(request: {
        cardId: string;
    }): Promise<TavernMethodResults['deleteEmbeddedLorebook']>;
    getChatLorebook(request: {
        cardId: string;
        storyId?: string;
    }): Promise<TavernMethodResults['getChatLorebook']>;
    saveChatLorebook(request: TavernMethodRequests['saveChatLorebook']): Promise<TavernMethodResults['saveChatLorebook']>;
    getJournal(request: {
        cardId: string;
        storyId?: string;
    }): Promise<TavernMethodResults['getJournal']>;
    saveJournal(request: TavernMethodRequests['saveJournal']): Promise<TavernMethodResults['saveJournal']>;
    listPersonas(_request: Record<string, never>): Promise<TavernMethodResults['listPersonas']>;
    /** 自动默认项必须由同一修订的判断授权；只在真实配置冲突后重读，不能覆盖排队期间的用户选择。 */
    private updateDefaultPersona;
    savePersona(request: TavernMethodRequests['savePersona']): Promise<TavernMethodResults['savePersona']>;
    deletePersona(request: {
        id: string;
    }): Promise<TavernMethodResults['deletePersona']>;
    listRegexRules(_request: Record<string, never>): Promise<TavernMethodResults['listRegexRules']>;
    saveRegexRules(request: TavernMethodRequests['saveRegexRules']): Promise<TavernMethodResults['saveRegexRules']>;
    /** 以已提交日志判定是否进入对话，避免客户端 blank 镜像滞后时误清绑定。 */
    private conversationStarted;
    getSessionBinding(request: {
        sessionId: string;
    }): Promise<TavernMethodResults['getSessionBinding']>;
    /** 剧情归属变更先同步取消当前宿主请求，覆盖 agent/request 之后 prepareCall 的异步准备；未来输入仍留在原生队列。 */
    private cancelChangedBinding;
    setSessionBinding(request: {
        binding: unknown;
    }): Promise<TavernMethodResults['setSessionBinding']>;
    clearSessionBinding(request: {
        sessionId: string;
        onlyIfBlank?: boolean;
    }): Promise<TavernMethodResults['clearSessionBinding']>;
    ensureGreeting(request: {
        sessionId: string;
    }): Promise<TavernMethodResults['ensureGreeting']>;
    swipeGreeting(request: TavernMethodRequests['swipeGreeting']): Promise<TavernMethodResults['swipeGreeting']>;
    getGreetingSwipe(request: {
        sessionId: string;
        messageId: string;
    }): Promise<TavernMethodResults['getGreetingSwipe']>;
    /** 分支兄弟导航是只读查询：等排队中的楼层任务落定即可，不进串行队列，也不等空闲记忆维护。 */
    getFloorSiblings(request: {
        sessionId: string;
        messageId?: string;
        turn?: number;
    }): Promise<TavernMethodResults['getFloorSiblings']>;
    renderOutputText(request: {
        sessionId: string;
        text: string;
        messageId?: number;
    }): Promise<TavernMethodResults['renderOutputText']>;
    /**
     * 长历史首屏一次挂载几十个气泡：合并为一批共享绑定、资产、历史与变量的读取，卡面快照、
     * 脚本库与世界书在响应中只出现一次，由客户端按引用重组。单项失败只影响该项。
     */
    renderOutputTexts(request: TavernMethodRequests['renderOutputTexts']): Promise<TavernMethodResults['renderOutputTexts']>;
    /** 同一批展示请求共享的只读加载：每类惰性读取一次，批内各气泡复用同一结果。 */
    private displayScope;
    private renderDisplayDraft;
    getHelperEventState(request: TavernMethodRequests['getHelperEventState']): Promise<TavernMethodResults['getHelperEventState']>;
    openHelperFrame(request: TavernMethodRequests['openHelperFrame']): Promise<TavernMethodResults['openHelperFrame']>;
    closeHelperFrame(request: TavernMethodRequests['closeHelperFrame']): Promise<void>;
    getHelperSnapshot(request: {
        sessionId: string;
        messageId: number;
    }): Promise<TavernMethodResults['getHelperSnapshot']>;
    prepareHelperMvuJob(request: TavernMethodRequests['prepareHelperMvuJob']): Promise<TavernMethodResults['prepareHelperMvuJob']>;
    enableHelperMvu(request: TavernMethodRequests['enableHelperMvu']): Promise<TavernMethodResults['enableHelperMvu']>;
    abandonHelperMvu(request: TavernMethodRequests['abandonHelperMvu']): Promise<TavernMethodResults['abandonHelperMvu']>;
    commitHelperMvuJob(request: TavernMethodRequests['commitHelperMvuJob']): Promise<TavernMethodResults['commitHelperMvuJob']>;
    getHelperScriptBundle(request: {
        sessionId: string;
    }): Promise<TavernMethodResults['getHelperScriptBundle']>;
    getCharacterHelperScripts(request: {
        cardId: string;
    }): Promise<TavernMethodResults['getCharacterHelperScripts']>;
    editHelperMessages(request: TavernMethodRequests['editHelperMessages']): Promise<TavernMethodResults['editHelperMessages']>;
    rebindHelperWorldbooks(request: TavernMethodRequests['rebindHelperWorldbooks']): Promise<TavernMethodResults['rebindHelperWorldbooks']>;
    getHelperWorldbookContext(request: TavernMethodRequests['getHelperWorldbookContext']): Promise<TavernMethodResults['getHelperWorldbookContext']>;
    helperWorldbookOperation(request: TavernMethodRequests['helperWorldbookOperation']): Promise<TavernMethodResults['helperWorldbookOperation']>;
    getSessionHelperScripts(request: TavernMethodRequests['getSessionHelperScripts']): Promise<TavernMethodResults['getSessionHelperScripts']>;
    commitSessionHelperScripts(request: TavernMethodRequests['commitSessionHelperScripts']): Promise<TavernMethodResults['commitSessionHelperScripts']>;
    getHelperScriptLibrary(request: TavernMethodRequests['getHelperScriptLibrary']): Promise<TavernMethodResults['getHelperScriptLibrary']>;
    saveHelperScriptLibrary(request: TavernMethodRequests['saveHelperScriptLibrary']): Promise<TavernMethodResults['saveHelperScriptLibrary']>;
    saveCharacterHelperScripts(request: {
        cardId: string;
        revision: string;
        trees: unknown;
    }): Promise<TavernMethodResults['saveCharacterHelperScripts']>;
    commitHelperVariables(request: TavernMethodRequests['commitHelperVariables']): Promise<TavernMethodResults['commitHelperVariables']>;
    regenerate(request: {
        sessionId: string;
        messageId?: string;
        turn?: number;
    }): Promise<TavernMethodResults['regenerate']>;
    rollbackToFloor(request: {
        sessionId: string;
        messageId?: string;
        turn?: number;
    }): Promise<TavernMethodResults['rollbackToFloor']>;
    getFloorUserMessage(request: {
        sessionId: string;
        messageId: string;
    }): Promise<TavernMethodResults['getFloorUserMessage']>;
    editUserMessage(request: {
        sessionId: string;
        messageId: string;
        text: string;
    }): Promise<TavernMethodResults['editUserMessage']>;
    getFloorAssistantMessage(request: {
        sessionId: string;
        messageId: string;
    }): Promise<TavernMethodResults['getFloorAssistantMessage']>;
    editAssistantMessage(request: {
        sessionId: string;
        messageId: string;
        text: string;
    }): Promise<TavernMethodResults['editAssistantMessage']>;
    continueFloor(request: {
        sessionId: string;
        messageId: string;
    }): Promise<TavernMethodResults['continueFloor']>;
    /** impersonate 是带外一次性调用，不进会话串行队列（不改会话状态）。 */
    impersonate(request: {
        sessionId: string;
    }): Promise<TavernMethodResults['impersonate']>;
    listStories(request: {
        cardId: string;
    }): Promise<TavernMethodResults['listStories']>;
    getMemories(request: {
        cardId: string;
        storyId?: string;
    }): Promise<TavernMethodResults['getMemories']>;
    saveMemory(request: {
        cardId: string;
        storyId?: string;
        id?: string;
        body: string;
        tags?: string[];
        keys?: string[];
    }): Promise<TavernMethodResults['saveMemory']>;
    deleteMemory(request: {
        cardId: string;
        storyId?: string;
        id: string;
    }): Promise<TavernMethodResults['deleteMemory']>;
    /** 无 LLM 的确定性归并：原文逐条保留，只减少条目数，不宣称减少 token。 */
    getStoryRecovery(request: {
        cardId: string;
        storyId?: string;
    }): Promise<TavernMethodResults['getStoryRecovery']>;
    /** 恢复反复失败时的受控出口：只删游标与标记，不跳过撤销；调用方仍须重新回退该楼层。 */
    resetStoryRecovery(request: {
        cardId: string;
        storyId?: string;
    }): Promise<TavernMethodResults['resetStoryRecovery']>;
    compressMemories(request: {
        cardId: string;
        storyId?: string;
    }): Promise<TavernMethodResults['compressMemories']>;
    getWorldDeltas(request: {
        cardId: string;
        storyId?: string;
    }): Promise<TavernMethodResults['getWorldDeltas']>;
    revokeWorldDelta(request: {
        cardId: string;
        storyId?: string;
        id: string;
    }): Promise<TavernMethodResults['revokeWorldDelta']>;
    addWorldDelta(request: {
        cardId: string;
        storyId?: string;
        type: 'add' | 'update' | 'invalidate';
        content: string;
        ref?: string | null;
        keys?: string[];
        order?: number;
    }): Promise<TavernMethodResults['addWorldDelta']>;
    exportMergedLorebook(request: {
        cardId: string;
        storyId?: string;
    }): Promise<TavernMethodResults['exportMergedLorebook']>;
    getTriggerLog(request: {
        sessionId: string;
    }): TavernMethodResults['getTriggerLog'];
    previewPrompt(request: {
        sessionId: string;
    }): Promise<TavernMethodResults['previewPrompt']>;
    /**
     * 上下文占用（宿主 rc.2 起 sessionProjections.stateOf 只读 token-meter 投影）。
     * 会话不在线、宿主未挂投影或尚无数据时 usage=null，调用方按未知处理。
     */
    getContextUsage(request: {
        sessionId: string;
    }): TavernMethodResults['getContextUsage'];
    /** 关于页只读取本机版本；版本检查按需联网，不提供安装执行入口。 */
    private pluginAboutReader?;
    private get aboutReader();
    getPluginAbout(_request: Record<string, never>): Promise<TavernMethodResults['getPluginAbout']>;
    checkPluginUpdate(_request: Record<string, never>): Promise<TavernMethodResults['checkPluginUpdate']>;
    /** Tavern 数据目录（$DSH_HOME/dsh-tavern），设置面板展示用。 */
    getDataInfo(_request: Record<string, never>): TavernMethodResults['getDataInfo'];
    getAvatar(request: {
        cardId: string;
    }): Promise<TavernMethodResults['getAvatar']>;
    private floorDeps;
}
export declare function createTavernService(ctx: Context, state: TavernState, settingsScope: TavernSettingsScope): TavernService;
