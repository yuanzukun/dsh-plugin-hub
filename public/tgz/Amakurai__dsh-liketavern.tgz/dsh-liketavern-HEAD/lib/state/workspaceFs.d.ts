import type { Wal } from './wal.js';
/** 工作区级回滚恢复标记（相对工作区根）：存在期间任何正文写入都必须被拒绝。 */
export declare const WAL_RECOVERY_PATH = "state/wal-recovery.json";
/** WAL 目录及控制元数据（清单与恢复标记）不可作为普通楼层快照目标写入或回放。 */
export declare function isReservedWalPath(path: string): boolean;
/** 恢复期间所有写入入口统一使用的中文拒绝原因（含「回滚恢复」，供上层提示与测试匹配）。 */
export declare const WORKSPACE_RECOVERING_MESSAGE = "\u5267\u60C5\u6B63\u5728\u56DE\u6EDA\u6062\u590D\uFF1A\u8BF7\u5148\u91CD\u65B0\u6267\u884C\u56DE\u9000\u5B8C\u6210\u6062\u590D\uFF1B\u53CD\u590D\u5931\u8D25\u65F6\u53EF\u5728\u300C\u8BB0\u5FC6\u300D\u9762\u677F\u9009\u62E9\u8BE5\u5267\u60C5\u5E76\u91CD\u7F6E\u56DE\u6EDA\u6E38\u6807\u3002\u672C\u6B21\u5199\u5165\u672A\u6267\u884C";
/** 仅限 Wal 回滚内部使用：本上下文内的 WorkspaceFs 写入跳过恢复写屏障。 */
export declare function withRecoveryWriteAccess<T>(task: () => Promise<T>): Promise<T>;
/** 工作区根是否存在回滚恢复标记；读取路径不受屏障影响，恢复流程仍可读盘。 */
export declare function hasRecoveryMarker(root: string): Promise<boolean>;
/** 工作区读写拒绝磁盘链接，避免安全的相对路径实际指向 WAL、兄弟剧情或工作区外。 */
export declare class WorkspaceLinkError extends Error {
}
/** 批量读取遇到超过调用方上限的文件：不把内容读进内存，由调用方给出业务含义。 */
export declare class WorkspaceSizeError extends Error {
}
/** 按入参顺序并发执行；全部结束后报告顺序最靠前的错误，结果不取决于哪个调用先返回。 */
export declare function mapBounded<T, R>(items: readonly T[], task: (item: T, index: number) => Promise<R>): Promise<R[]>;
export declare class WorkspaceFs {
    readonly root: string;
    private readonly wal;
    /** 本实例的楼层；null 表示非会话期写入（不走 WAL）。构造后只能经 withFloor 派生改出。 */
    private floor;
    constructor(root: string, wal: Wal | null);
    get currentFloor(): string | null;
    /**
     * 派生一个共享 root 与 wal、floor 独立的新实例。会话楼层（含读路径口径统一）
     * 用它在楼层内读写：快照记进本实例的 floor，不影响共享句柄与其它会话的实例。
     */
    withFloor(floor: string | null): WorkspaceFs;
    /** 已持有工作区锁时推算本层回滚后的文本；只读且不推进恢复游标，供依赖正文的安全清理使用。 */
    rollbackSnapshot(relPath: string, current: string | null): Promise<string | null>;
    private abs;
    /**
     * WAL 记录用的规范相对路径：正斜杠、去掉 `.` 与空段。读路径可以宽松（normalize 会折叠它们），
     * 但记进日志的路径必须是 Wal.readRecords 日后接受的形状——一条 `memory/./x.md` 会让整层
     * 日志被判定损坏，进而阻断该剧情之后所有回退与分支。盘符与 WAL 自身目录同样拒绝。
     */
    private walPath;
    private lstatSafe;
    /**
     * 所有直接操作默认拒绝根与内部父路径上的链接。根的祖先可以是宿主安装挂载，
     * 但一旦进入指定工作区，链接不得改写剧情边界；WAL 整批预检也复用此只读检查。
     */
    assertSafePath(relPath: string): Promise<void>;
    /** 批量路径链接检查：共享祖先目录只做一次 lstat，与逐个 assertSafePath 拒绝口径一致。 */
    assertSafePaths(relPaths: Iterable<string>): Promise<void>;
    /**
     * 回滚恢复写屏障：本工作区存在恢复标记（或有旧版遗留游标）时，任何写/删都必须明确失败。
     * Wal 回滚自身的正文替换、摘要展开与索引重建经 withRecoveryWriteAccess 放行。
     */
    private assertWritable;
    readText(relPath: string, _options?: {
        rejectLinks?: boolean;
    }): Promise<string | null>;
    /** 判断路径是否存在（文件或目录）。 */
    exists(relPath: string): Promise<boolean>;
    /**
     * 单文件元信息（mtimeMs/size）；不存在返回 null。
     * 用途是廉价的「内容是否变过」指纹：一次 lstat 不读数据，远便宜于全文读 + 解析，
     * 且能捕获绕开本类的落盘（WAL 回滚会直接写回文件），比进程内修订号更可靠。
     */
    stat(relPath: string): Promise<{
        mtimeMs: number;
        size: number;
    } | null>;
    /**
     * 批量取文件元信息，顺序与入参一致，不存在的为 null。
     * 结果与逐个 stat 相同，但系统调用少得多：同一父目录到根的链接检查只做一次，
     * 文件本身用一次 lstat 同时判断链接和取 mtime/size（不是链接时 lstat 与 stat 结果一致）。
     * 记忆检索每次都要核对上千个归档来源的指纹，逐个 stat 是每个文件 5 次调用。
     */
    statMany(relPaths: readonly string[]): Promise<Array<{
        mtimeMs: number;
        size: number;
    } | null>>;
    /** 多个目录到根的链接检查：按深度分层有界并发，公共祖先只查一次并保留最早错误顺序。 */
    private assertNoLinksAmong;
    /**
     * 批量读取文本，顺序与入参一致，不存在的为 null。与逐个 readText 结果相同，系统调用少得多：
     * 父目录到根的链接检查每个目录只做一次，文件本身用一次 lstat 拒绝链接并核对体积。
     * 分块保存的状态一次要读上千个小文件，逐个读取是每个文件十余次调用。
     */
    readTextMany(relPaths: readonly string[], maxBytes?: number): Promise<Array<string | null>>;
    /**
     * 批量事务写入：全部前后镜像一次写进 WAL，再替换各文件正文；与逐个 writeText 的落盘结果相同。
     * 逐条记录每次都要重读并重写整份楼层日志，一次保存产生上百个新文件时代价随记录数平方增长。
     * 日志仍先于任何正文持久化；中途失败留下的记录在回滚时按「正文与写后镜像不符」保留现状。
     */
    writeTextMany(entries: ReadonlyArray<readonly [relPath: string, content: string]>): Promise<void>;
    /**
     * 从另一个工作区按相同相对路径批量复制普通文件，来源不存在的跳过；来源是链接或目录时以 reject 给出的错误拒绝。
     * 每个文件仍然原子替换并刷盘，只是并发进行：剧情快照要复制上千个小文件，逐个写入的耗时取决于刷盘次数。
     * 不记 WAL，只用于尚未发布的草稿工作区。
     */
    copyFrom(source: WorkspaceFs, relPaths: readonly string[], reject: (relPath: string) => Error): Promise<void>;
    /** 父路径已确认不经过链接时，对文件本身的一次检查：是链接就拒绝，不存在返回 null。 */
    private lstatFile;
    /** 确保目录存在（递归创建）。目录创建幂等且无内容副作用，不纳入 WAL。 */
    ensureDir(relPath?: string): Promise<void>;
    /** 读取二进制内容；不存在返回 null。 */
    readBytes(relPath: string): Promise<Uint8Array | null>;
    /** 调用方已对 abs 完成 lstatSafe 时的原始字节读取；不存在返回 null。 */
    private readBytesVerified;
    /** 事务写入：每次修改先持久化 before/after，再原子替换正文；与回退共享工作区锁。 */
    writeText(relPath: string, content: string): Promise<void>;
    /**
     * 事务写入二进制（如 card.png 头像）：语义同 writeText，
     * 已存在文件的 before 快照以 base64 + 显式编码记录，回滚时对称解码。
     */
    writeBytes(relPath: string, bytes: Uint8Array): Promise<void>;
    /**
     * 事务删除（有当前楼层时同样记录快照）。
     * 快照口径必须与 writeBytes 对称：二进制内容（严格 UTF-8 解码失败）记 base64 + 编码字段，
     * 否则回滚写回的是有损转码后的字节。无楼层时只需判存在性，不读全文。
     */
    delete(relPath: string): Promise<void>;
    /** 批量事务删除：单个锁与单次批量 WAL 记录，再有界并发删除正文。 */
    deleteMany(relPaths: readonly string[]): Promise<void>;
    /**
     * 列出 prefix 子目录下的文件（相对路径，正斜杠）。
     * 默认递归；`recursive: false` 只列本层文件（跳过子目录，不进去走）——
     * 记忆库那样「本层是热路径、子目录（archive/）只增不查」的场景必须用非递归，
     * 否则每次检索都要把归档整棵走完再丢掉，成本随归档量单调增长。
     * `skipDir` 在递归遍历遇到目录时回调（相对路径，正斜杠），返回 true 则整棵跳过——
     * state/wal、memory/archive 这类只增不查的目录应在遍历时直接排除，
     * 而不是全棵走完再由调用方过滤。
     */
    list(prefix?: string, options?: {
        recursive?: boolean;
        skipDir?: (relDir: string) => boolean;
        rejectLinks?: boolean;
    }): Promise<string[]>;
    /**
     * 列出 prefix 本层文件及其 mtime/size（非递归）。
     * 用途是廉价的「内容是否变过」指纹：N 次 stat 不读数据，远便宜于 N 次全文读 + 解析，
     * 且能捕获绕开本类的落盘（WAL 回滚会直接写回文件），故比进程内修订号更可靠。
     */
    listStats(prefix?: string): Promise<Array<{
        name: string;
        mtimeMs: number;
        size: number;
    }>>;
}
