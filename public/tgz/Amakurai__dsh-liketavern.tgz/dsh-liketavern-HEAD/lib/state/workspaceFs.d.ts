import type { Wal } from './wal.js';
/** 历史占位：旧版曾把非会话写入记入名为 non-floor 的 WAL 单元。现已不再使用。 */
export declare const NON_FLOOR = "non-floor";
/** 工作区读写拒绝磁盘链接，避免安全的相对路径实际指向 WAL、兄弟剧情或工作区外。 */
export declare class WorkspaceLinkError extends Error {
}
/** 批量读取遇到超过调用方上限的文件：不把内容读进内存，由调用方给出业务含义。 */
export declare class WorkspaceSizeError extends Error {
}
export declare class WorkspaceFs {
    readonly root: string;
    private readonly wal;
    /** 本实例的楼层；null 表示非会话期写入（不走 WAL）。构造后只能经 withFloor 派生改出。 */
    private floor;
    constructor(root: string, wal: Wal | null);
    /**
     * 遗留兼容：直接改本实例的 floor。host 路径已改用 withFloor 派生实例 +
     * wal.beginFloor/commitFloor（见文件头「楼层隔离模型」）；保留仅为既有测试与
     * 旧调用点不 break，新代码不要再用——共享句柄上的可变 floor 会让同卡并发会话
     * 互相覆盖楼层上下文。
     */
    setFloor(floor: string | null): void;
    get currentFloor(): string | null;
    /**
     * 派生一个共享 root 与 wal、floor 独立的新实例。会话楼层（含读路径口径统一）
     * 用它在楼层内读写：快照记进本实例的 floor，不影响共享句柄与其它会话的实例。
     */
    withFloor(floor: string | null): WorkspaceFs;
    /** 已持有工作区锁时推算本层回滚后的文本；只读且不推进恢复游标，供依赖正文的安全清理使用。 */
    rollbackSnapshot(relPath: string, current: string | null): Promise<string | null>;
    private abs;
    /**
     * WAL 记录用的规范相对路径：正斜杠、去掉 `.` 与空段。读路径可以宽松（normalize 会折叠它们），
     * 但记进日志的路径必须是 Wal.readRecords 日后接受的形状——一条 `memory/./x.md` 会让整层
     * 日志被判定损坏，进而阻断该剧情之后所有回退与分支。盘符与 WAL 自身目录同样拒绝。
     */
    private walPath;
    private assertNoLinks;
    /**
     * 所有直接操作默认拒绝根与内部父路径上的链接。根的祖先可以是宿主安装挂载，
     * 但一旦进入指定工作区，链接不得改写剧情边界；WAL 整批预检也复用此只读检查。
     */
    assertSafePath(relPath: string): Promise<void>;
    readText(relPath: string, _options?: {
        rejectLinks?: boolean;
    }): Promise<string | null>;
    /** 判断路径是否存在（文件或目录）。 */
    exists(relPath: string): Promise<boolean>;
    /**
     * 单文件元信息（mtimeMs/size）；不存在返回 null。
     * 用途是廉价的「内容是否变过」指纹：一次 stat 不读数据，远便宜于全文读 + 解析，
     * 且能捕获绕开本类的落盘（WAL 回滚会直接写回文件），比进程内修订号更可靠。
     */
    stat(relPath: string): Promise<{
        mtimeMs: number;
        size: number;
    } | null>;
    /**
     * 批量取文件元信息，顺序与入参一致，不存在的为 null。
     * 结果与逐个 stat 相同，但系统调用少得多：同一父目录到根的链接检查只做一次，
     * 文件本身用一次 lstat 同时判断链接和取 mtime/size（不是链接时 lstat 与 stat 结果一致）。
     * 记忆检索每次都要核对上千个归档来源的指纹，逐个 stat 是每个文件 5 次调用。
     */
    statMany(relPaths: readonly string[]): Promise<Array<{
        mtimeMs: number;
        size: number;
    } | null>>;
    /** 多个目录到根的链接检查：公共祖先只查一次。 */
    private assertNoLinksAmong;
    /**
     * 批量读取文本，顺序与入参一致，不存在的为 null。与逐个 readText 结果相同，系统调用少得多：
     * 父目录到根的链接检查每个目录只做一次，文件本身用一次 lstat 拒绝链接并核对体积。
     * 分块保存的状态一次要读上千个小文件，逐个读取是每个文件十余次调用。
     */
    readTextMany(relPaths: readonly string[], maxBytes?: number): Promise<Array<string | null>>;
    /**
     * 批量事务写入：全部前后镜像一次写进 WAL，再替换各文件正文；与逐个 writeText 的落盘结果相同。
     * 逐条记录每次都要重读并重写整份楼层日志，一次保存产生上百个新文件时代价随记录数平方增长。
     * 日志仍先于任何正文持久化；中途失败留下的记录在回滚时按「正文与写后镜像不符」保留现状。
     */
    writeTextMany(entries: ReadonlyArray<readonly [relPath: string, content: string]>): Promise<void>;
    /**
     * 从另一个工作区按相同相对路径批量复制普通文件，来源不存在的跳过；来源是链接或目录时以 reject 给出的错误拒绝。
     * 每个文件仍然原子替换并刷盘，只是并发进行：剧情快照要复制上千个小文件，逐个写入的耗时取决于刷盘次数。
     * 不记 WAL，只用于尚未发布的草稿工作区。
     */
    copyFrom(source: WorkspaceFs, relPaths: readonly string[], reject: (relPath: string) => Error): Promise<void>;
    /** 父路径已确认不经过链接时，对文件本身的一次检查：是链接就拒绝，不存在返回 null。 */
    private lstatFile;
    /** 确保目录存在（递归创建）。目录创建幂等且无内容副作用，不纳入 WAL。 */
    ensureDir(relPath?: string): Promise<void>;
    /** 读取二进制内容；不存在返回 null。 */
    readBytes(relPath: string): Promise<Uint8Array | null>;
    /** 事务写入：每次修改先持久化 before/after，再原子替换正文；与回退共享工作区锁。 */
    writeText(relPath: string, content: string): Promise<void>;
    /**
     * 事务写入二进制（如 card.png 头像）：语义同 writeText，
     * 已存在文件的 before 快照以 base64 + 显式编码记录，回滚时对称解码。
     */
    writeBytes(relPath: string, bytes: Uint8Array): Promise<void>;
    /**
     * 事务删除（有当前楼层时同样记录快照）。
     * 快照口径必须与 writeBytes 对称：二进制内容（严格 UTF-8 解码失败）记 base64 + 编码字段，
     * 否则回滚写回的是有损转码后的字节。无楼层时只需判存在性，不读全文。
     */
    delete(relPath: string): Promise<void>;
    /**
     * 列出 prefix 子目录下的文件（相对路径，正斜杠）。
     * 默认递归；`recursive: false` 只列本层文件（跳过子目录，不进去走）——
     * 记忆库那样「本层是热路径、子目录（archive/）只增不查」的场景必须用非递归，
     * 否则每次检索都要把归档整棵走完再丢掉，成本随归档量单调增长。
     * `skipDir` 在递归遍历遇到目录时回调（相对路径，正斜杠），返回 true 则整棵跳过——
     * state/wal、memory/archive 这类只增不查的目录应在遍历时直接排除，
     * 而不是全棵走完再由调用方过滤。
     */
    list(prefix?: string, options?: {
        recursive?: boolean;
        skipDir?: (relDir: string) => boolean;
        rejectLinks?: boolean;
    }): Promise<string[]>;
    /**
     * 列出 prefix 本层文件及其 mtime/size（非递归）。
     * 用途是廉价的「内容是否变过」指纹：N 次 stat 不读数据，远便宜于 N 次全文读 + 解析，
     * 且能捕获绕开本类的落盘（WAL 回滚会直接写回文件），故比进程内修订号更可靠。
     */
    listStats(prefix?: string): Promise<Array<{
        name: string;
        mtimeMs: number;
        size: number;
    }>>;
    /**
     * 遗留兼容：开始一个楼层事务并把本实例的 floor 指过去（WAL 存在时）。
     * host 路径已改为 `wal.beginFloor(floor)` + `withFloor(floor)` 派生实例；保留仅为既有测试。
     */
    beginFloor(floor: string): Promise<void>;
    /** 遗留兼容：提交本实例当前楼层并清除楼层上下文。host 路径已改为 `wal.commitFloor(floor)`。 */
    commitFloor(): Promise<void>;
}
