// dsh-lite-memory —— Client 面（浏览器 bundle，SQLite 版）
//
// 对话视图新增「记忆」tab：条目化记忆面板（标题/重要程度/来源/内容，增删改查）。
// 设置页「记忆」分区：二级菜单（记忆 / 日历 / 定时）；日历为月视图+当天时间轴+浮层编辑，
// 面板下方「待执行」「已完成」双 tab 纵向列表；定时为 cron 任务列表 + 详情表单 +
// 表达式实时预览（未来 5 次）+ 执行记录，支持手动新增/编辑/删除/启停/立即运行。
// 中英双语：跟随 DSH 设置的语言（locale 字典），无手动外观设置、默认字号。
// 与宿主端通过同源 HTTP 路由通信（/dsh-lite-memory/*）。
window.__ModuleLoader__.load({
  id: "dsh-lite-memory",
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" })
    var react = require("react")

    var name = "dsh-lite-memory"
    var inject = ["slots", "locale"]

    // ── 中英字典 ──────────────────────────────────────────────────────────────
    var NS = "dsh-lite-memory"
    var zhDict = {
      nav: "记忆",
      subMemory: "记忆",
      subCalendar: "日历",
      globalTab: "全局",
      projectTab: "项目",
      workspace: "工作区",
      addEntry: "添加条目",
      editEntry: "编辑条目",
      title: "标题",
      priority: "重要程度",
      pHigh: "高",
      pMid: "中",
      pLow: "低",
      content: "内容",
      source: "来源",
      save: "保存",
      cancel: "取消",
      edit: "编辑",
      del: "删除",
      refresh: "刷新",
      empty: "暂无记忆条目",
      titleRequired: "标题不能为空",
      contentRequired: "内容不能为空",
      itemTitle: "条目标题…",
      itemContent: "内容（第三人称客观陈述）…",
      saved: "已保存 ✓",
      saving: "保存中…",
      loading: "加载中…",
      calTitle: "日历",
      date: "日期",
      time: "时间",
      quadrant: "象限",
      note: "备注",
      optional: "可选",
      adding: "添加中…",
      add: "添加事项",
      today: "今天",
      done: "完成",
      pendingTab: "待执行",
      doneTab: "已完成",
      noPending: "暂无待执行事项",
      noDone: "暂无已完成事项",
      restore: "恢复",
      detail: "补充说明（可选）",
      clickAdd: "点击添加事件",
      daySchedule: "当天安排",
      sourceUser: "用户",
      sourceAgent: "工具",
      collapseAll: "全部折叠",
      expandAll: "全部展开",
      monthUnits: "个月",
      entryUnits: "条",
      totalEntries: "条目",
      highEntries: "高优先级",
      qUrgentImportant: "重要紧急",
      qImportant: "重要不紧急",
      qUrgent: "紧急不重要",
      qNone: "不重要不紧急",
      // ── 定时任务 ──
      subCron: "定时",
      cronAdd: "新增定时任务",
      cronEdit: "编辑定时任务",
      cronName: "任务名",
      cronNamePh: "如：每日代码巡检",
      cronExpr: "cron 表达式",
      cronExprPh: "分 时 日 月 周，如 0 9 * * *",
      cronPrompt: "提示词",
      cronPromptPh: "到点让 agent 做什么…",
      cronCwd: "工作目录",
      cronPreset: "Preset",
      cronProvider: "模型 provider",
      cronModel: "模型",
      cronEffort: "推理强度",
      cronTarget: "触发落点",
      cronTargetNew: "新建会话",
      cronTargetSession: "投递到当前会话",
      cronTimeout: "超时（秒）",
      cronNone: "（默认）",
      cronWorkspace: "工作区",
      cronWorkspaceDefault: "默认（dsh web 进程目录）",
      cronModelLabel: "模型",
      cronModelDefault: "默认（跟随部署）",
      cronModelLoading: "加载模型列表…",
      cronNameOptional: "任务名（可选）",
      cronNameAuto: "留空自动取提示词前 20 字",
      cronEffortLabel: "推理强度",
      cronEffortDefault: "默认",
      cronAdvanced: "高级设置",
      cronAdvancedHide: "收起高级",
      cronRefreshList: "刷新列表",
      cronProviderPh: "provider",
      cronModelPh: "model",
      cronRouteHint: "模型路由只对「新建会话」生效；投递型任务沿用目标会话自身的模型。留空即用默认路由。",
      cronNext: "下次",
      cronLast: "上次",
      cronNever: "不会触发",
      cronRunNow: "立即运行",
      cronEnable: "启用",
      cronDisable: "停用",
      cronRecords: "执行记录",
      cronNoJobs: "暂无定时任务",
      cronNoRuns: "暂无执行记录",
      cronExprRequired: "cron 表达式无效，需 5 字段（分 时 日 月 周）",
      cronPromptRequired: "提示词不能为空",
      cronHint: "仅在 dsh web 进程运行时触发；关闭期间错过的时刻不会补跑。",
      cronPresetHint: "无人值守执行：请确认所选 preset 的审批策略与工具限制，否则任务可能卡在审批上。",
      cronPreview: "接下来 5 次：",
      cronQuick: "常用",
      cronQuickDaily: "每天",
      cronQuickWeekly: "每周",
      cronQuickMonthly: "每月",
      cronQuickHourly: "每小时",
      cronQuickEveryN: "每 N 分钟",
      cronQuickCustom: "自定义",
      cronWeek: "星期",
      cronDay: "日",
      cronMinuteOfHour: "分钟",
      cronIntervalMin: "间隔（分钟）",
      cronTime: "时间",
      cronDescEveryMinute: "每分钟",
      cronDescEveryN: "每 {n} 分钟",
      cronDescHourly: "每小时第 {m} 分",
      cronDescDaily: "每天 {time}",
      cronDescWeekly: "每{week} {time}",
      cronDescMonthly: "每月 {day} 日 {time}",
      cronInvalid: "表达式无效",
      week0: "周日",
      week1: "周一",
      week2: "周二",
      week3: "周三",
      week4: "周四",
      week5: "周五",
      week6: "周六",
      stRunning: "运行中",
      stOk: "成功",
      stErr: "失败",
      stTimeout: "超时",
      stDelivered: "已投递",
      stSkipped: "已跳过",
      stNone: "未运行",
      cronElapsed: "耗时",
      cronOpenSession: "会话",
    }
    var enDict = {
      nav: "Memory",
      subMemory: "Memory",
      subCalendar: "Calendar",
      globalTab: "Global",
      projectTab: "Project",
      workspace: "Workspace",
      addEntry: "Add entry",
      editEntry: "Edit entry",
      title: "Title",
      priority: "Priority",
      pHigh: "High",
      pMid: "Mid",
      pLow: "Low",
      content: "Content",
      source: "Source",
      save: "Save",
      cancel: "Cancel",
      edit: "Edit",
      del: "Del",
      refresh: "Refresh",
      empty: "No memory entries",
      titleRequired: "Title required",
      contentRequired: "Content required",
      itemTitle: "Entry title…",
      itemContent: "Content…",
      saved: "Saved ✓",
      saving: "Saving…",
      loading: "Loading…",
      calTitle: "Calendar",
      date: "Date",
      time: "Time",
      quadrant: "Quadrant",
      note: "Note",
      optional: "Optional",
      adding: "Adding…",
      add: "Add",
      today: "Today",
      done: "Done",
      pendingTab: "Pending",
      doneTab: "Done",
      noPending: "No pending items",
      noDone: "No completed items",
      restore: "Undo",
      detail: "Details (optional)",
      clickAdd: "Click to add event",
      daySchedule: "Day schedule",
      sourceUser: "User",
      sourceAgent: "Agent",
      collapseAll: "Collapse all",
      expandAll: "Expand all",
      monthUnits: "mo",
      entryUnits: "entries",
      totalEntries: "Entries",
      highEntries: "High priority",
      qUrgentImportant: "Urgent & important",
      qImportant: "Important",
      qUrgent: "Urgent",
      qNone: "Neither",
      // ── scheduled tasks ──
      subCron: "Scheduled",
      cronAdd: "New task",
      cronEdit: "Edit task",
      cronName: "Name",
      cronNamePh: "e.g. Daily code review",
      cronExpr: "cron expression",
      cronExprPh: "min hour day month weekday, e.g. 0 9 * * *",
      cronPrompt: "Prompt",
      cronPromptPh: "What should the agent do at that time…",
      cronCwd: "Working dir",
      cronPreset: "Preset",
      cronProvider: "Provider",
      cronModel: "Model",
      cronEffort: "Reasoning",
      cronTarget: "Delivery",
      cronTargetNew: "New session",
      cronTargetSession: "Current session",
      cronTimeout: "Timeout (s)",
      cronNone: "(default)",
      cronWorkspace: "Workspace",
      cronWorkspaceDefault: "Default (dsh web process cwd)",
      cronModelLabel: "Model",
      cronModelDefault: "Default (follow deployment)",
      cronModelLoading: "Loading models…",
      cronNameOptional: "Name (optional)",
      cronNameAuto: "Blank = first 20 chars of the prompt",
      cronEffortLabel: "Reasoning",
      cronEffortDefault: "Default",
      cronAdvanced: "Advanced",
      cronAdvancedHide: "Hide advanced",
      cronRefreshList: "Refresh",
      cronProviderPh: "provider",
      cronModelPh: "model",
      cronRouteHint: "Model routing applies to new sessions only; delivered runs keep the target session's model. Blank = default route.",
      cronNext: "Next",
      cronLast: "Last",
      cronNever: "never",
      cronRunNow: "Run now",
      cronEnable: "Enable",
      cronDisable: "Disable",
      cronRecords: "History",
      cronNoJobs: "No scheduled tasks",
      cronNoRuns: "No runs yet",
      cronExprRequired: "Invalid cron expression: 5 fields required",
      cronPromptRequired: "Prompt required",
      cronHint: "Only fires while the dsh web process is running; missed minutes are dropped.",
      cronPresetHint: "Unattended run: check the preset's approval policy and tool limits, or the task may stall on approval.",
      cronPreview: "Next 5 runs:",
      cronQuick: "Preset",
      cronQuickDaily: "Daily",
      cronQuickWeekly: "Weekly",
      cronQuickMonthly: "Monthly",
      cronQuickHourly: "Hourly",
      cronQuickEveryN: "Every N min",
      cronQuickCustom: "Custom",
      cronWeek: "Weekday",
      cronDay: "Day",
      cronMinuteOfHour: "Minute",
      cronIntervalMin: "Interval (min)",
      cronTime: "Time",
      cronDescEveryMinute: "every minute",
      cronDescEveryN: "every {n} min",
      cronDescHourly: "hourly at :{m}",
      cronDescDaily: "daily {time}",
      cronDescWeekly: "{week} {time}",
      cronDescMonthly: "day {day} of month {time}",
      cronInvalid: "invalid expression",
      week0: "Sun",
      week1: "Mon",
      week2: "Tue",
      week3: "Wed",
      week4: "Thu",
      week5: "Fri",
      week6: "Sat",
      stRunning: "running",
      stOk: "ok",
      stErr: "failed",
      stTimeout: "timeout",
      stDelivered: "delivered",
      stSkipped: "skipped",
      stNone: "never run",
      cronElapsed: "took",
      cronOpenSession: "session",
    }

    // ── 工具 ──────────────────────────────────────────────────────────────────
    function translate(dict, key, params) {
      var tmpl = dict[key] !== undefined ? dict[key] : key
      if (params) {
        for (var k in params) {
          tmpl = String(tmpl).split("{" + k + "}").join(String(params[k]))
        }
      }
      return tmpl
    }

    function call(method, params) {
      var url = "/dsh-lite-memory/" + method
      if (params) {
        var qs = Object.keys(params).map(function (k) { return encodeURIComponent(k) + "=" + encodeURIComponent(params[k]) }).join("&")
        if (qs) url += "?" + qs
      }
      return fetch(url, { cache: "no-store", signal: AbortSignal.timeout(15000) }).then(function (r) { return r.json() })
    }
    function post(method, body) {
      return fetch("/dsh-lite-memory/" + method, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body || {}),
        cache: "no-store",
        signal: AbortSignal.timeout(15000),
      }).then(function (r) { return r.json() })
    }

    var QUADRANT_COLORS = {
      "重要紧急": "#d64545",
      "重要不紧急": "#4f7cff",
      "紧急不重要": "#e6a23c",
      "不重要不紧急": "#8a94a6",
    }
    var PRIORITY_COLORS = { "高": "#d64545", "中": "#e6a23c", "低": "#8a94a6" }

    function fmtTime(ts) {
      if (!ts) return ""
      var d = new Date(ts)
      return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0") + " " + String(d.getHours()).padStart(2, "0") + ":" + String(d.getMinutes()).padStart(2, "0")
    }

    // ── 定时任务：状态色与描述本地化 ───────────────────────────────────────────
    var CRON_STATUS_COLORS = {
      running: "#e6a23c", ok: "#3fa45b", err: "#d64545", timeout: "#d64545",
      delivered: "#4f7cff", skipped: "#8a94a6",
    }
    function cronStatusColor(status) { return CRON_STATUS_COLORS[status] || "#8a94a6" }
    function cronStatusText(tt, status) {
      if (!status) return tt("stNone")
      var key = "st" + String(status).charAt(0).toUpperCase() + String(status).slice(1)
      return tt(key)
    }
    /** 宿主返回的结构化 cron 描述 → 当前语言文案（解析留在宿主，文案留在前端）。 */
    function cronDescText(tt, d) {
      if (!d) return ""
      if (d.kind === "everyMinute") return tt("cronDescEveryMinute")
      if (d.kind === "everyNMinutes") return tt("cronDescEveryN", { n: d.n })
      if (d.kind === "hourly") return tt("cronDescHourly", { m: d.minute })
      if (d.kind === "daily") return tt("cronDescDaily", { time: d.time })
      if (d.kind === "weekly") return tt("cronDescWeekly", { week: tt("week" + d.week), time: d.time })
      if (d.kind === "monthly") return tt("cronDescMonthly", { day: d.day, time: d.time })
      if (d.kind === "invalid") return tt("cronInvalid")
      return d.expr || ""
    }
    function fmtClock(ts) {
      return ts ? fmtTime(ts) : "—"
    }
    function fmtDuration(from, to) {
      if (!from || !to || to < from) return ""
      var s = Math.round((to - from) / 1000)
      if (s < 60) return s + "s"
      return Math.floor(s / 60) + "m" + String(s % 60).padStart(2, "0") + "s"
    }
    /** 快捷档 → cron 表达式（分 时 日 月 周）。 */
    function cronQuickExpr(quick, f) {
      var parts = String(f.time || "09:00").split(":")
      var h = Number(parts[0])
      var mi = Number(parts[1])
      if (!isFinite(h)) h = 9
      if (!isFinite(mi)) mi = 0
      if (quick === "everyN") return "*/" + (Number(f.n) > 0 ? Math.floor(Number(f.n)) : 30) + " * * * *"
      if (quick === "hourly") return mi + " * * * *"
      if (quick === "daily") return mi + " " + h + " * * *"
      if (quick === "weekly") return mi + " " + h + " * * " + (Number(f.week) || 0)
      if (quick === "monthly") return mi + " " + h + " " + (Number(f.day) || 1) + " * *"
      return ""
    }

    /** 按 updatedAt 月份分组（YYYY-MM），组内按时间倒序，组间月份倒序。 */
    function groupByMonth(entries) {
      var groups = []
      var index = {}
      var sorted = (entries || []).slice().sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0) })
      for (var i = 0; i < sorted.length; i++) {
        var en = sorted[i]
        var d = en.updatedAt ? new Date(en.updatedAt) : new Date()
        var key = d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0")
        if (!index[key]) {
          index[key] = { key: key, label: key, entries: [] }
          groups.push(index[key])
        }
        index[key].entries.push(en)
      }
      return groups
    }

    /** 来源显示: user=用户输入, agent=工具写入（工作区 · 会话短 id）。 */
    function sourceLabel(en, tt) {
      if (en.sourceType === "user") return tt("sourceUser")
      var ws = en.scope === "project" ? (en.workspace || "?") : tt("globalTab")
      var sid = en.sessionId ? String(en.sessionId).slice(0, 8) : "-"
      return ws + " · " + sid
    }

    /** 按标题折叠的条目列表组件：默认仅显示标题，点击标题展开内容与操作。 */
    function MemoryList(props) {
      var h = props.el
      var tt = props.t
      var entries = props.entries
      var onEdit = props.onEdit
      var onDelete = props.onDelete
      var PRIORITY_COLORS = props.PRIORITY_COLORS

      var s0 = react.useState({})
      var expanded = s0[0]
      var setExpanded = s0[1]

      if (entries.length === 0) {
        return h("div", { className: "lmem-status lmem-center" }, tt("empty"))
      }

      var isAllOpen = entries.every(function (en) { return !!expanded[en.id] })
      var toggleOne = function (id) {
        var n = Object.assign({}, expanded)
        n[id] = !n[id]
        setExpanded(n)
      }
      var toggleAll = function () {
        var next = !isAllOpen
        var map = {}
        for (var i = 0; i < entries.length; i++) map[entries[i].id] = next
        setExpanded(map)
      }

      return h("div", { className: "lmem-list" },
        h("div", { className: "lmem-row" },
          h("button", { className: "lmem-btn lmem-btn-sm", onClick: toggleAll }, isAllOpen ? tt("collapseAll") : tt("expandAll")),
          h("span", { className: "lmem-status" }, entries.length + " " + tt("entryUnits")),
        ),
        entries.map(function (en) {
          var isOpen = !!expanded[en.id]
          return h("div", { key: en.id, className: "lmem-entry", style: { "--lmem-pri-color": (PRIORITY_COLORS[en.priority] || "#8a94a6") } },
            h("div", { className: "lmem-entry-head", onClick: function () { toggleOne(en.id) } },
              h("span", { className: "lmem-month-caret" }, isOpen ? "▾" : "▸"),
              h("span", { className: "lmem-pri", style: { background: (PRIORITY_COLORS[en.priority] || "#8a94a6") } }, en.priority),
              h("div", { className: "lmem-entry-title" }, en.title),
            ),
            isOpen ? h("div", { className: "lmem-entry-body" },
              h("div", { className: "lmem-entry-content" }, en.content),
              h("div", { className: "lmem-entry-meta" }, tt("source") + ": " + sourceLabel(en, tt) + " · " + fmtTime(en.updatedAt)),
              h("div", { className: "lmem-row lmem-entry-actions" },
                h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { onEdit(en) } }, tt("edit")),
                h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { onDelete(en.id) } }, tt("del")),
              ),
            ) : null,
          )
        }),
      )
    }

    function apply(ctx) {
      var slots = ctx.get("slots")
      var locale = ctx.get("locale")
      if (slots === undefined) return

      var t = function (key, params) { return translate(zhDict, key, params) }
      if (locale !== undefined) {
        ctx.effect(function () { return locale.register(NS, { zh: zhDict, en: enDict }) }, "dsh-lite-memory: dictionaries")
        t = locale.bind(NS)
      }

      var el = react.createElement

      // ── 对话「记忆」tab：条目化记忆面板 ────────────────────────────────────
      function MemoryView(props) {
        var sessionId = props.sessionId || ""
        var s0 = react.useState("project")
        var tab = s0[0]
        var setTab = s0[1]
        var s1 = react.useState([])
        var entries = s1[0]
        var setEntries = s1[1]
        var s2 = react.useState("")
        var ws = s2[0]
        var setWs = s2[1]
        var s3 = react.useState([])
        var workspaces = s3[0]
        var setWorkspaces = s3[1]
        var s4 = react.useState("")
        var status = s4[0]
        var setStatus = s4[1]
        var s5 = react.useState(null)
        var editing = s5[0]   // null | {id?, title, priority, content}
        var setEditing = s5[1]

        var refresh = function (which, workspace) {
          var scope = which !== undefined ? which : tab
          var w = workspace !== undefined ? workspace : ws
          setStatus(t("loading"))
          return call("entries", { scope: scope, workspace: scope === "project" ? w : "" }).then(function (r) {
            if (r && r.ok) { setEntries(r.entries || []); setStatus("") }
            else setStatus((r && r.message) || t("loading"))
          })
        }

        react.useEffect(function () {
          if (tab === "global") {
            setWs("")
            refresh("global", "")
          } else {
            Promise.all([call("workspace", { sessionId: sessionId }), call("workspaces", {})]).then(function (rs) {
              var cur = (rs[0] && rs[0].ok && rs[0].workspace) || ""
              setWs(cur)
              if (rs[1] && rs[1].ok) setWorkspaces(rs[1].workspaces || [])
              refresh("project", cur)
            })
          }
        }, [tab, sessionId])

        var saveEntry = function () {
          if (!String(editing.title || "").trim()) { setStatus(t("titleRequired")); return }
          if (!String(editing.content || "").trim()) { setStatus(t("contentRequired")); return }
          setStatus(t("saving"))
          var payload = {
            title: String(editing.title).trim(),
            priority: editing.priority || "中",
            content: String(editing.content).trim(),
          }
          var p
          if (editing.id !== undefined && editing.id !== null) {
            payload.id = editing.id
            p = post("entries/update", payload)
          } else {
            payload.scope = tab
            payload.workspace = tab === "project" ? ws : ""
            payload.sourceType = "user"   // UI 手动输入 → 来源标记为「用户」
            p = post("entries/add", payload)
          }
          p.then(function (r) {
            setStatus((r && r.message) || t("saved"))
            setEditing(null)
            refresh()
          })
        }
        var deleteEntry = function (id) {
          post("entries/delete", { id: id }).then(function () { refresh() })
        }

        var formVisible = editing !== null
        return el("div", { className: "lmem-view" },
          el("div", { className: "lmem-tabs" },
            el("button", { className: "lmem-tab" + (tab === "global" ? " active" : ""), onClick: function () { setTab("global") } }, t("globalTab")),
            el("button", { className: "lmem-tab" + (tab === "project" ? " active" : ""), onClick: function () { setTab("project") } }, t("projectTab")),
            el("span", { style: { flex: 1 } }),
            el("button", { className: "lmem-btn", onClick: function () { refresh() }, title: t("refresh") }, "⟳"),
            el("button", { className: "lmem-btn primary", onClick: function () { setEditing({ title: "", priority: "中", content: "" }) } }, "+ " + t("addEntry")),
          ),
          tab === "project" && workspaces.length > 1
            ? el("div", { className: "lmem-row" },
                el("label", { className: "lmem-field" }, t("workspace"),
                  el("select", { className: "lmem-input", value: ws, onChange: function (e) { setWs(e.target.value); refresh("project", e.target.value) } },
                    workspaces.map(function (w) { return el("option", { key: w, value: w }, w) }),
                  ),
                ),
                el("span", { className: "lmem-status" }, status),
              )
            : el("div", { className: "lmem-row" },
                el("span", { className: "lmem-status" }, status),
              ),
          formVisible
            ? el("div", { className: "lmem-form" },
                el("div", { className: "lmem-row" },
                  el("div", { className: "lmem-field lmem-grow" }, t("title"),
                    el("input", { className: "lmem-input", value: editing.title, onChange: function (e) { var n = Object.assign({}, editing); n.title = e.target.value; setEditing(n) }, placeholder: t("itemTitle") })),
                  el("div", { className: "lmem-field" }, t("priority"),
                    el("select", { className: "lmem-input", value: editing.priority, onChange: function (e) { var n = Object.assign({}, editing); n.priority = e.target.value; setEditing(n) } },
                      ["高", "中", "低"].map(function (p) { return el("option", { key: p, value: p }, t(p === "高" ? "pHigh" : p === "中" ? "pMid" : "pLow")) }),
                    )),
                ),
                el("textarea", { className: "lmem-area lmem-area-sm", value: editing.content, onChange: function (e) { var n = Object.assign({}, editing); n.content = e.target.value; setEditing(n) }, placeholder: t("itemContent") }),
                el("div", { className: "lmem-row" },
                  el("button", { className: "lmem-btn primary", onClick: saveEntry }, t("save")),
                  el("button", { className: "lmem-btn", onClick: function () { setEditing(null) } }, t("cancel")),
                ),
              )
            : null,
          !formVisible
            ? el(MemoryList, { el: el, t: t, entries: entries, PRIORITY_COLORS: PRIORITY_COLORS,
                onEdit: function (en) { setEditing({ id: en.id, title: en.title, priority: en.priority, content: en.content }) },
                onDelete: function (id) { deleteEntry(id) },
              })
            : null,
        )
      }

      // ── 设置「记忆」分区：二级菜单（记忆 / 日历）────────────────────────────
      function SettingsMemory() {
        var s0 = react.useState("calendar")
        var sub = s0[0]
        var setSub = s0[1]
        var s1 = react.useState([])
        var entries = s1[0]
        var setEntries = s1[1]
        var s2 = react.useState("")
        var status = s2[0]
        var setStatus = s2[1]
        var s3 = react.useState(null)
        var editing = s3[0]
        var setEditing = s3[1]
        // 记忆子页: scope=global | project; workspace 为项目时的工作区名
        var s4 = react.useState("global")
        var scope = s4[0]
        var setScope = s4[1]
        var s5 = react.useState("")
        var ws = s5[0]
        var setWs = s5[1]
        var s6 = react.useState([])
        var workspaces = s6[0]
        var setWorkspaces = s6[1]
        // 统计
        var s7 = react.useState({ total: 0, high: 0 })
        var stats = s7[0]
        var setStats = s7[1]

        var refresh = function (whichScope, whichWs) {
          var sc = whichScope !== undefined ? whichScope : scope
          var w = whichWs !== undefined ? whichWs : ws
          return call("entries", { scope: sc, workspace: sc === "project" ? w : "" }).then(function (r) {
            if (r && r.ok) {
              setEntries(r.entries || [])
              var list = r.entries || []
              setStats({ total: list.length, high: list.filter(function (en) { return en.priority === "高" }).length })
            }
          })
        }
        react.useEffect(function () {
          // 初始: 全局 + 工作区列表
          call("workspaces", {}).then(function (r) {
            if (r && r.ok) setWorkspaces(r.workspaces || [])
          })
          refresh("global", "")
        }, [])

        var saveEntry = function () {
          if (!String(editing.title || "").trim()) { setStatus(t("titleRequired")); return }
          if (!String(editing.content || "").trim()) { setStatus(t("contentRequired")); return }
          setStatus(t("saving"))
          var payload = { title: String(editing.title).trim(), priority: editing.priority || "中", content: String(editing.content).trim() }
          var p
          if (editing.id !== undefined && editing.id !== null) {
            payload.id = editing.id
            p = post("entries/update", payload)
          } else {
            payload.scope = scope
            payload.workspace = scope === "project" ? ws : ""
            payload.sourceType = "user"   // UI 手动输入 → 来源标记为「用户」
            p = post("entries/add", payload)
          }
          p.then(function (r) {
            setStatus((r && r.message) || t("saved"))
            setEditing(null)
            refresh()
          })
        }
        var deleteEntry = function (id) {
          post("entries/delete", { id: id }).then(function () { refresh() })
        }

        var subBody = null
        if (sub === "memory") {
          subBody = el("div", { className: "lmem-view" },
            // 范围选择器: 全局 / 工作区下拉
            el("div", { className: "lmem-scopebar" },
              el("button", { className: "lmem-tab" + (scope === "global" ? " active" : ""), onClick: function () { setScope("global"); setWs(""); refresh("global", "") } }, t("globalTab")),
              el("div", { className: "lmem-field lmem-grow" },
                el("select", { className: "lmem-input", value: scope === "project" ? ws : "", onChange: function (e) {
                    var v = e.target.value
                    if (v === "__global__") { setScope("global"); setWs(""); refresh("global", ""); return }
                    setScope("project"); setWs(v); refresh("project", v)
                  } },
                  el("option", { value: "__global__" }, t("projectTab") + " · " + t("workspace")),
                  (workspaces.length ? workspaces : ["-"]).map(function (w) { return el("option", { key: w, value: w }, w) }),
                ),
              ),
            ),
            // 统计 + 操作
            el("div", { className: "lmem-row" },
              el("span", { className: "lmem-stat" }, t("totalEntries") + ": " + stats.total),
              el("span", { className: "lmem-stat lmem-stat-high" }, t("highEntries") + ": " + stats.high),
              el("span", { style: { flex: 1 } }),
              el("button", { className: "lmem-btn primary", onClick: function () { setEditing({ title: "", priority: "中", content: "" }) } }, "+ " + t("addEntry")),
              el("button", { className: "lmem-btn", onClick: function () { refresh() } }, t("refresh")),
              el("span", { className: "lmem-status" }, status),
            ),
            editing !== null
              ? el("div", { className: "lmem-form" },
                  el("div", { className: "lmem-row" },
                    el("div", { className: "lmem-field lmem-grow" }, t("title"),
                      el("input", { className: "lmem-input", value: editing.title, onChange: function (e) { var n = Object.assign({}, editing); n.title = e.target.value; setEditing(n) }, placeholder: t("itemTitle") })),
                    el("div", { className: "lmem-field" }, t("priority"),
                      el("select", { className: "lmem-input", value: editing.priority, onChange: function (e) { var n = Object.assign({}, editing); n.priority = e.target.value; setEditing(n) } },
                        ["高", "中", "低"].map(function (p) { return el("option", { key: p, value: p }, t(p === "高" ? "pHigh" : p === "中" ? "pMid" : "pLow")) }),
                      )),
                  ),
                  el("textarea", { className: "lmem-area lmem-area-sm", value: editing.content, onChange: function (e) { var n = Object.assign({}, editing); n.content = e.target.value; setEditing(n) }, placeholder: t("itemContent") }),
                  el("div", { className: "lmem-row" },
                    el("button", { className: "lmem-btn primary", onClick: saveEntry }, t("save")),
                    el("button", { className: "lmem-btn", onClick: function () { setEditing(null) } }, t("cancel")),
                  ),
                )
              : null,
            el(MemoryList, { el: el, t: t, entries: entries, PRIORITY_COLORS: PRIORITY_COLORS,
              onEdit: function (en) { setEditing({ id: en.id, title: en.title, priority: en.priority, content: en.content }) },
              onDelete: function (id) { deleteEntry(id) },
            }),
          )
        } else if (sub === "calendar") {
          subBody = el(CalendarPanel, { t: t, el: el, call: call, post: post, QUADRANT_COLORS: QUADRANT_COLORS })
        } else {
          subBody = el(CronPanel, { t: t, el: el, call: call, post: post })
        }

        return el("div", { className: "lmem-view" },
          el("div", { className: "lmem-subtabs" },
            el("button", { className: "lmem-tab" + (sub === "memory" ? " active" : ""), onClick: function () { setSub("memory") } }, t("subMemory")),
            el("button", { className: "lmem-tab" + (sub === "calendar" ? " active" : ""), onClick: function () { setSub("calendar") } }, t("subCalendar")),
            el("button", { className: "lmem-tab" + (sub === "cron" ? " active" : ""), onClick: function () { setSub("cron") } }, t("subCron")),
          ),
          subBody,
        )
      }

      // ── 日历面板（月视图 + 当天时间轴 + 待执行/已完成双 tab）────────────────
      function CalendarPanel(props) {
        var tt = props.t
        var h = props.el
        var apiGet = props.call
        var apiPost = props.post
        var QC = props.QUADRANT_COLORS

        var s0 = react.useState([])
        var entries = s0[0]
        var setEntries = s0[1]
        var s1 = react.useState(null)
        var month = s1[0]
        var setMonth = s1[1]
        var s2 = react.useState(null)
        var dayView = s2[0]
        var setDayView = s2[1]
        var s3 = react.useState(null)
        var draft = s3[0]
        var setDraft = s3[1]
        var s4 = react.useState("pending")
        var listTab = s4[0]
        var setListTab = s4[1]
        var s5 = react.useState("")
        var msg = s5[0]
        var setMsg = s5[1]
        var s6 = react.useState(false)
        var saving = s6[0]
        var setSaving = s6[1]

        function load() {
          apiGet("calendar", {}).then(function (r) {
            if (r && r.ok) setEntries(r.entries || [])
          })
        }
        react.useEffect(function () {
          load()
          var now = new Date()
          setMonth({ year: now.getFullYear(), mon: now.getMonth() + 1 })
        }, [])

        if (!month) return null
        function dayEntries(date) {
          return (entries || []).filter(function (en) { return en.date === date })
        }
        function moveMonth(delta) {
          var y = month.year
          var m = month.mon + delta
          if (m < 1) { m = 12; y -= 1 }
          if (m > 12) { m = 1; y += 1 }
          setMonth({ year: y, mon: m })
        }
        function fmtDate(y, m, d) { return y + "-" + String(m).padStart(2, "0") + "-" + String(d).padStart(2, "0") }

        var firstDay = new Date(month.year, month.mon - 1, 1)
        var startDow = firstDay.getDay()
        var daysInMonth = new Date(month.year, month.mon, 0).getDate()
        var now = new Date()
        var today = fmtDate(now.getFullYear(), now.getMonth() + 1, now.getDate())
        var cells = []
        for (var i = 0; i < startDow; i++) cells.push(null)
        for (var d = 1; d <= daysInMonth; d++) cells.push(fmtDate(month.year, month.mon, d))
        var dowLabels = ["日", "一", "二", "三", "四", "五", "六"]

        var rows = []
        // 月网格行（卡片内部使用）
        var gridRows = []
        for (var ci = 0; ci < cells.length; ci += 7) {
          var week = []
          for (var cj = 0; cj < 7; cj++) {
            (function (cell) {
              if (!cell) { week.push(h("div", { key: "empty" + cj })); return }
              var es = dayEntries(cell)
              var isToday = cell === today
              week.push(h("div", {
                key: cell,
                className: "lmem-cal-day" + (isToday ? " today" : ""),
                onClick: function () { setDayView(cell) },
              },
                h("div", { className: "lmem-cal-daynum" }, Number(cell.slice(8))),
                es.slice(0, 3).map(function (en) {
                  return h("div", {
                    key: en.id,
                    className: "lmem-cal-chip" + (en.done ? " done" : ""),
                    title: en.time + " " + en.title,
                    onClick: function (ev) { ev.stopPropagation(); toggleDone(en) },
                    style: { background: "color-mix(in srgb, " + (QC[en.quadrant] || "#8a94a6") + " 18%, transparent)", color: (QC[en.quadrant] || "#8a94a6") },
                  }, (en.time && en.time !== "--:--" ? en.time + " " : "") + en.title)
                }),
                es.length > 3 ? h("div", { className: "lmem-cal-more" }, "+" + (es.length - 3)) : null,
              ))
            })(cells[ci + cj])
          }
          gridRows.push(h("div", { key: "w" + ci, className: "lmem-cal-gridrow" }, week))
        }
        rows.push(h("div", { className: "lmem-cal-card" },
          h("div", { className: "lmem-row" },
            h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { moveMonth(-1) } }, "◀"),
            h("span", { className: "lmem-cal-month" }, month.year + " / " + String(month.mon).padStart(2, "0")),
            h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { moveMonth(1) } }, "▶"),
            h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { var n = new Date(); setMonth({ year: n.getFullYear(), mon: n.getMonth() + 1 }) } }, tt("today")),
            h("span", { style: { flex: 1 } }),
            h("button", { className: "lmem-btn primary", onClick: function () { setDraft({ date: today, time: "09:00", quadrant: "重要不紧急", title: "", note: "" }) } }, "+ " + tt("add")),
          ),
          // 图例
          h("div", { className: "lmem-row lmem-legend" },
            Object.keys(QC).map(function (q) {
              return h("span", { key: q, className: "lmem-legend-item" },
                h("span", { style: { display: "inline-block", width: 8, height: 8, borderRadius: 2, background: QC[q], marginRight: 4 } }), tt(q === "重要紧急" ? "qUrgentImportant" : q === "重要不紧急" ? "qImportant" : q === "紧急不重要" ? "qUrgent" : "qNone"))
            }),
          ),
          // 星期表头
          h("div", { className: "lmem-cal-dow" },
            dowLabels.map(function (dl) { return h("div", { key: dl, className: "lmem-cal-dow-cell" }, dl) }),
          ),
          // 月网格
          gridRows.map(function (gr) { return gr }),
        ))

        function toggleDone(en) {
          if (saving) return
          setSaving(true)
          apiPost("calendar/done", { date: en.date, time: en.time, title: en.title }).then(function (r) {
            setMsg((r && r.message) || ""); setSaving(false); load()
          })
        }
        function saveDraft() {
          if (!draft || !String(draft.title || "").trim()) { setMsg(tt("titleRequired")); return }
          if (saving) return
          setSaving(true)
          apiPost("calendar/add", { date: draft.date, time: draft.time, quadrant: draft.quadrant, title: String(draft.title).trim(), note: String(draft.note || "").trim() }).then(function (r) {
            setMsg((r && r.message) || ""); setSaving(false); setDraft(null); load()
          })
        }

        // 当天时间轴浮层
        if (dayView) {
          var timeline = []
          for (var hourSlot = 7; hourSlot <= 22; hourSlot++) {
            (function (hourValue) {
              var hourText = String(hourValue).padStart(2, "0") + ":00"
              var hourEvents = dayEntries(dayView).filter(function (en) { return String(en.time || "").slice(0, 2) === String(hourValue).padStart(2, "0") })
              timeline.push(h("div", { key: hourText, className: "lmem-cal-slot", onClick: function () { setDayView(null); setDraft({ date: dayView, time: hourText, quadrant: "重要不紧急", title: "", note: "" }) } },
                h("div", { className: "lmem-cal-slottime" }, hourText),
                h("div", { className: "lmem-cal-slotevents" }, hourEvents.length
                  ? hourEvents.map(function (en) {
                      return h("div", {
                        key: en.id,
                        className: "lmem-cal-chip" + (en.done ? " done" : ""),
                        onClick: function (ev) { ev.stopPropagation(); toggleDone(en) },
                        style: { background: "color-mix(in srgb, " + (QC[en.quadrant] || "#8a94a6") + " 18%, transparent)", color: (QC[en.quadrant] || "#8a94a6") },
                      }, (en.time || "") + "  " + en.title + (en.note ? " · " + en.note : ""))
                    })
                  : h("span", { className: "lmem-status" }, tt("clickAdd"))),
              ))
            })(hourSlot)
          }
          rows.push(h("div", { className: "lmem-cal-modal" },
            h("div", { className: "lmem-row" },
              h("div", { className: "lmem-cal-modal-title" }, dayView + " · " + tt("daySchedule")),
              h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { setDayView(null) } }, "✕"),
            ),
            timeline,
          ))
        }
        // 添加/编辑浮层
        if (draft) {
          rows.push(h("div", { className: "lmem-cal-modal" },
            h("div", { className: "lmem-cal-modal-title" }, tt("add") + " · " + draft.date),
            h("input", { className: "lmem-input", placeholder: tt("itemTitle"), value: draft.title, autoFocus: true, onChange: function (e) { var n = Object.assign({}, draft); n.title = e.target.value; setDraft(n) } }),
            h("div", { className: "lmem-row" },
              h("input", { className: "lmem-input", type: "time", value: draft.time, onChange: function (e) { var n = Object.assign({}, draft); n.time = e.target.value || "09:00"; setDraft(n) } }),
              h("select", { className: "lmem-input", value: draft.quadrant, onChange: function (e) { var n = Object.assign({}, draft); n.quadrant = e.target.value; setDraft(n) } },
                ["重要紧急", "重要不紧急", "紧急不重要", "不重要不紧急"].map(function (q) { return h("option", { key: q, value: q }, tt(q === "重要紧急" ? "qUrgentImportant" : q === "重要不紧急" ? "qImportant" : q === "紧急不重要" ? "qUrgent" : "qNone")) }),
              ),
            ),
            h("input", { className: "lmem-input", placeholder: tt("note") + "（" + tt("optional") + "）", value: draft.note || "", onChange: function (e) { var n = Object.assign({}, draft); n.note = e.target.value; setDraft(n) } }),
            h("div", { className: "lmem-row" },
              h("button", { className: "lmem-btn primary", onClick: saveDraft, disabled: saving }, saving ? tt("saving") : tt("save")),
              h("button", { className: "lmem-btn", onClick: function () { if (!saving) setDraft(null) }, disabled: saving }, tt("cancel")),
            ),
          ))
        }
        if (msg) rows.push(h("div", { className: "lmem-status" }, msg))

        // 下方：待执行 / 已完成 双 tab 纵向列表
        var sorted = (entries || []).slice().sort(function (a, b) { return (a.date + a.time).localeCompare(b.date + b.time) })
        var pendingList = sorted.filter(function (en) { return !en.done })
        var doneList = sorted.filter(function (en) { return en.done })

        rows.push(h("div", { className: "lmem-tabs" },
          h("button", { className: "lmem-tab" + (listTab === "pending" ? " active" : ""), onClick: function () { setListTab("pending") } }, tt("pendingTab") + " (" + pendingList.length + ")"),
          h("button", { className: "lmem-tab" + (listTab === "done" ? " active" : ""), onClick: function () { setListTab("done") } }, tt("doneTab") + " (" + doneList.length + ")"),
        ))
        var listItems = listTab === "pending" ? pendingList : doneList
        rows.push(h("div", { className: "lmem-cal" },
          listItems.length === 0
            ? h("div", { className: "lmem-status lmem-center" }, listTab === "pending" ? tt("noPending") : tt("noDone"))
            : listItems.map(function (en) {
                return h("div", { key: en.id, className: "lmem-cal-item" + (en.done ? " done" : ""), style: { "--lmem-q-color": (QC[en.quadrant] || "#8a94a6") } },
                  h("span", { className: "lmem-cal-q", style: { borderColor: (QC[en.quadrant] || "#8a94a6"), color: (QC[en.quadrant] || "#8a94a6") } }, en.quadrant),
                  h("div", { className: "lmem-cal-item-body" },
                    h("div", { className: "lmem-cal-title", style: { textDecoration: en.done ? "line-through" : "none" } }, en.title),
                    h("div", { className: "lmem-cal-meta" }, en.date + " " + en.time + (en.note ? " · " + en.note : "")),
                  ),
                  h("div", { className: "lmem-row lmem-cal-actions" },
                    h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { toggleDone(en) } }, en.done ? tt("restore") : tt("done")),
                    h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () {
                      apiPost("calendar/remove", { date: en.date, time: en.time, title: en.title }).then(function () { load() })
                    } }, tt("del")),
                  ),
                )
              }),
        ))

        return h.apply(null, ["div", { className: "lmem-cal-wrap" }].concat(rows))
      }

      // ── 定时任务面板（列表 + 详情表单 + 表达式实时预览 + 执行记录）────────────
      function CronPanel(props) {
        var tt = props.t
        var h = props.el
        var apiGet = props.call
        var apiPost = props.post

        var s0 = react.useState([])
        var jobs = s0[0]
        var setJobs = s0[1]
        var s1 = react.useState(null)
        var draft = s1[0]
        var setDraft = s1[1]
        var s2 = react.useState("")
        var msg = s2[0]
        var setMsg = s2[1]
        var s3 = react.useState(false)
        var saving = s3[0]
        var setSaving = s3[1]
        var s4 = react.useState(null)
        var preview = s4[0]
        var setPreview = s4[1]
        var s5 = react.useState(null)
        var runsFor = s5[0]
        var setRunsFor = s5[1]
        var s6 = react.useState([])
        var runs = s6[0]
        var setRuns = s6[1]
        var s7 = react.useState(0)
        var busyId = s7[0]
        var setBusyId = s7[1]
        // 下拉数据源：工作区真路径 + 可选模型目录（来自 host 的 workspaceRegistry / llm）
        var s8 = react.useState({ workspaces: [], processCwd: "", providers: [], defaultModel: null })
        var opts = s8[0]
        var setOpts = s8[1]
        var s9 = react.useState(false)
        var adv = s9[0]
        var setAdv = s9[1]
        var s10 = react.useState(null)
        var modelInfo = s10[0]   // 选中具体模型后拿到它支持的推理强度
        var setModelInfo = s10[1]

        function loadOptions() {
          apiGet("cron/workspaces", {}).then(function (r) {
            if (r && r.ok) setOpts(function (prev) { return Object.assign({}, prev, { workspaces: r.workspaces || [], processCwd: r.processCwd || "" }) })
          })
          apiGet("cron/models", {}).then(function (r) {
            if (r && r.ok) setOpts(function (prev) { return Object.assign({}, prev, { providers: r.providers || [], defaultModel: r.default || null }) })
          })
        }
        react.useEffect(function () { loadOptions() }, [])

        /** 选中某个模型 → 查它支持的推理强度；选「默认」则清掉路由。 */
        function pickModel(provider, model) {
          var next = Object.assign({}, draft, { provider: provider, model: model })
          if (!provider || !model) {
            next.effort = ""
            setModelInfo(null)
            setDraft(next)
            return
          }
          setModelInfo(null)
          apiPost("cron/model-info", { provider: provider, model: model }).then(function (r) {
            if (!r || !r.ok) return
            setModelInfo(r)
            var ids = (r.efforts || []).map(function (x) { return x.id })
            if (next.effort && ids.indexOf(next.effort) < 0) setDraft(Object.assign({}, next, { effort: "" }))
          })
          setDraft(next)
        }

        function load() {
          apiGet("cron", {}).then(function (r) { if (r && r.ok) setJobs(r.jobs || []) })
        }
        function refreshRuns(id) {
          apiGet("cron/runs", { jobId: id, limit: 20 }).then(function (r) { if (r && r.ok) setRuns(r.runs || []) })
        }
        react.useEffect(function () { load() }, [])

        var exprNow = draft !== null ? String(draft.expr || "") : ""
        var draftOpen = draft !== null
        // 表达式实时预览：停止输入 250ms 后再请求，避免每击键都打后端。
        react.useEffect(function () {
          if (!draftOpen || !exprNow.trim()) { setPreview(null); return }
          var timer = setTimeout(function () {
            apiPost("cron/preview", { expr: exprNow }).then(function (r) { if (r && r.ok) setPreview(r) })
          }, 250)
          return function () { clearTimeout(timer) }
        }, [exprNow, draftOpen])

        function newDraft() {
          setMsg("")
          setPreview(null)
          setAdv(false)
          setModelInfo(null)
          setDraft({ name: "", expr: "0 9 * * *", prompt: "", cwd: "", preset: "", provider: "", model: "", effort: "", target: "new", timeoutSec: 600, quick: "daily", qf: { time: "09:00", week: 1, day: 1, n: 30 } })
        }
        function editDraft(job) {
          setMsg("")
          setPreview(null)
          setAdv(false)
          setModelInfo(null)
          setDraft({ id: job.id, name: job.name, expr: job.expr, prompt: job.prompt, cwd: job.cwd || "", preset: job.agentPreset || "", provider: job.provider || "", model: job.model || "", effort: job.effort || "", target: job.target, timeoutSec: job.timeoutSec, quick: "custom", qf: { time: "09:00", week: 1, day: 1, n: 30 } })
          if (job.provider && job.model) {
            apiPost("cron/model-info", { provider: job.provider, model: job.model }).then(function (r) { if (r && r.ok) setModelInfo(r) })
          }
        }
        function patch(p) { setDraft(Object.assign({}, draft, p)) }
        function patchQuick(quick, qfPatch) {
          var qf = Object.assign({}, draft.qf, qfPatch || {})
          var next = Object.assign({}, draft, { quick: quick, qf: qf })
          if (quick !== "custom") next.expr = cronQuickExpr(quick, qf)
          setDraft(next)
        }
        function save() {
          if (!draft) return
          if (!String(draft.prompt || "").trim()) { setMsg(tt("cronPromptRequired")); return }
          if (preview === null || preview.valid !== true) { setMsg(tt("cronExprRequired")); return }
          setSaving(true)
          var payload = {
            name: draft.name, expr: draft.expr, prompt: draft.prompt, cwd: draft.cwd,
            preset: draft.preset, provider: draft.provider, model: draft.model, effort: draft.effort,
            target: draft.target, timeoutSec: draft.timeoutSec,
          }
          var p
          if (draft.id !== undefined && draft.id !== null) { payload.id = draft.id; p = apiPost("cron/update", payload) }
          else p = apiPost("cron/add", payload)
          p.then(function (r) {
            setSaving(false)
            setMsg((r && r.message) || tt("saved"))
            if (r && r.ok) { setDraft(null); setPreview(null); load() }
          })
        }
        function removeJob(job) {
          apiPost("cron/remove", { id: job.id }).then(function (r) {
            setMsg((r && r.message) || "")
            if (runsFor === job.id) { setRunsFor(null); setRuns([]) }
            load()
          })
        }
        function toggleJob(job) {
          apiPost("cron/toggle", { id: job.id, enabled: !job.enabled }).then(function (r) { setMsg((r && r.message) || ""); load() })
        }
        function runNow(job) {
          setBusyId(job.id)
          setMsg(tt("stRunning") + "…")
          apiPost("cron/run", { id: job.id }).then(function (r) {
            setBusyId(0)
            setMsg((r && r.message) || "")
            load()
            if (runsFor === job.id) refreshRuns(job.id)
          })
        }
        function toggleRuns(job) {
          if (runsFor === job.id) { setRunsFor(null); setRuns([]); return }
          setRunsFor(job.id)
          refreshRuns(job.id)
        }

        var rows = []
        rows.push(h("div", { className: "lmem-row" },
          h("span", { className: "lmem-status" }, tt("cronHint")),
          h("span", { style: { flex: 1 } }),
          h("button", { className: "lmem-btn", onClick: function () { load() } }, tt("refresh")),
          h("button", { className: "lmem-btn primary", onClick: newDraft }, "+ " + tt("cronAdd")),
        ))
        if (msg) rows.push(h("div", { className: "lmem-status" }, msg))

        if (draft !== null) {
          var qf = draft.qf || {}
          var quickField = null
          if (draft.quick === "everyN") {
            quickField = h("div", { className: "lmem-field" }, tt("cronIntervalMin"),
              h("input", { className: "lmem-input", type: "number", min: 1, max: 59, value: qf.n, onChange: function (e) { patchQuick("everyN", { n: Number(e.target.value) }) } }))
          } else if (draft.quick === "hourly") {
            var hm = String(qf.time || "09:00").split(":")
            quickField = h("div", { className: "lmem-field" }, tt("cronMinuteOfHour"),
              h("input", { className: "lmem-input", type: "number", min: 0, max: 59, value: Number(hm[1]) || 0, onChange: function (e) { patchQuick("hourly", { time: "00:" + String(Math.min(59, Math.max(0, Number(e.target.value) || 0))).padStart(2, "0") }) } }))
          } else if (draft.quick === "weekly") {
            quickField = h("div", { className: "lmem-field" }, tt("cronWeek"),
              h("select", { className: "lmem-input", value: qf.week, onChange: function (e) { patchQuick("weekly", { week: Number(e.target.value) }) } },
                [0, 1, 2, 3, 4, 5, 6].map(function (w) { return h("option", { key: w, value: w }, tt("week" + w)) })))
          } else if (draft.quick === "monthly") {
            quickField = h("div", { className: "lmem-field" }, tt("cronDay"),
              h("input", { className: "lmem-input", type: "number", min: 1, max: 31, value: qf.day, onChange: function (e) { patchQuick("monthly", { day: Number(e.target.value) }) } }))
          }
          if (draft.quick === "daily" || draft.quick === "weekly" || draft.quick === "monthly") {
            quickField = h("span", { className: "lmem-row" }, quickField,
              h("div", { className: "lmem-field" }, tt("cronTime"),
                h("input", { className: "lmem-input", type: "time", value: qf.time || "09:00", onChange: function (e) { patchQuick(draft.quick, { time: e.target.value || "09:00" }) } })))
          }
          var previewBox = null
          if (preview !== null) {
            if (preview.valid === true) {
              previewBox = h("div", { className: "lmem-preview" },
                h("span", { className: "lmem-status" }, tt("cronPreview") + " " + cronDescText(tt, preview.description)),
                (preview.next || []).map(function (ts) { return h("span", { key: ts, className: "lmem-stat" }, fmtTime(ts)) }))
            } else {
              previewBox = h("div", { className: "lmem-status lmem-err" }, tt("cronExprRequired"))
            }
          }
          // ── 工作区下拉（真路径）─────────────────────────────────────────────
          var wsList = (opts.workspaces || [])
          var wsChildren = [h("option", { key: "__default__", value: "" }, tt("cronWorkspaceDefault") + (opts.processCwd ? " · " + opts.processCwd : ""))]
          wsList.forEach(function (w) {
            wsChildren.push(h("option", { key: w.path, value: w.path }, (w.title && w.title !== w.path ? w.title + " · " : "") + w.path))
          })
          if (draft.cwd && !wsList.some(function (w) { return w.path === draft.cwd })) {
            wsChildren.push(h("option", { key: draft.cwd, value: draft.cwd }, draft.cwd))
          }
          var workspaceSelect = h("select", { className: "lmem-input", value: draft.cwd, onChange: function (e) { patch({ cwd: e.target.value }) } }, wsChildren)

          // ── 模型下拉（按 provider 分组）─────────────────────────────────────
          var currentModel = draft.provider && draft.model ? draft.provider + "|" + draft.model : ""
          var modelChildren = [h("option", { key: "__default__", value: "" },
            tt("cronModelDefault") + (opts.defaultModel ? " · " + opts.defaultModel.provider + "/" + opts.defaultModel.model : ""))]
          var groups = []
          var modelKnown = false
          ;(opts.providers || []).forEach(function (p) {
            var items = (p.models || []).map(function (m) {
              var v = p.id + "|" + m.id
              if (v === currentModel) modelKnown = true
              return h("option", { key: v, value: v }, (m.name && m.name !== m.id ? m.name + " · " : "") + m.id)
            })
            if (items.length > 0) groups.push(h("optgroup", { key: p.id, label: p.name || p.id }, items))
          })
          modelChildren = modelChildren.concat(groups)
          if (currentModel && !modelKnown) {
            modelChildren.push(h("option", { key: currentModel, value: currentModel }, currentModel.replace("|", " / ")))
          }
          var modelSelect = h("select", {
            className: "lmem-input", value: currentModel,
            onChange: function (e) {
              var v = e.target.value
              var i = v.indexOf("|")
              if (i < 0) { pickModel("", ""); return }
              pickModel(v.slice(0, i), v.slice(i + 1))
            },
          }, modelChildren)

          // 一个模型目录都取不到时退回手填，保证不是死路
          var modelPicker = groups.length > 0
            ? modelSelect
            : h("span", { className: "lmem-row" },
              h("input", { className: "lmem-input", value: draft.provider, placeholder: tt("cronProviderPh"), onChange: function (e) { patch({ provider: e.target.value }) } }),
              h("input", { className: "lmem-input", value: draft.model, placeholder: tt("cronModelPh"), onChange: function (e) { patch({ model: e.target.value }) } }))

          // 选中具体模型后，才出现它真正支持的推理强度
          var effortField = (modelInfo !== null && (modelInfo.efforts || []).length > 0)
            ? h("div", { className: "lmem-field" }, tt("cronEffortLabel"),
              h("select", { className: "lmem-input", value: draft.effort, onChange: function (e) { patch({ effort: e.target.value }) } },
                [h("option", { key: "__default__", value: "" }, tt("cronEffortDefault"))].concat(
                  modelInfo.efforts.map(function (x) { return h("option", { key: x.id, value: x.id }, x.name) }))))
            : null

          // ── 高级设置（表达式原文 / 超时 / preset / 落点）────────────────────
          var advanced = adv
            ? h("div", { className: "lmem-form-adv" },
              h("div", { className: "lmem-row" },
                h("div", { className: "lmem-field lmem-grow" }, tt("cronExpr"),
                  h("input", { className: "lmem-input lmem-mono", value: draft.expr, readOnly: draft.quick !== "custom", placeholder: tt("cronExprPh"), onChange: function (e) { patch({ expr: e.target.value }) } })),
                h("div", { className: "lmem-field" }, tt("cronTimeout"),
                  h("input", { className: "lmem-input", type: "number", min: 30, value: draft.timeoutSec, onChange: function (e) { patch({ timeoutSec: Number(e.target.value) || 600 }) } })),
              ),
              h("div", { className: "lmem-row" },
                h("div", { className: "lmem-field lmem-grow" }, tt("cronPreset"),
                  h("input", { className: "lmem-input", value: draft.preset, placeholder: tt("cronNone"), onChange: function (e) { patch({ preset: e.target.value }) } })),
                h("div", { className: "lmem-field" }, tt("cronTarget"),
                  h("select", { className: "lmem-input", value: draft.target, onChange: function (e) { patch({ target: e.target.value }) } },
                    h("option", { value: "new" }, tt("cronTargetNew")),
                    h("option", { value: "session" }, tt("cronTargetSession")))),
              ),
              h("div", { className: "lmem-status" }, tt("cronRouteHint")),
              h("div", { className: "lmem-status" }, tt("cronPresetHint")),
            )
            : null

          rows.push(h("div", { className: "lmem-form" },
            h("div", { className: "lmem-row" },
              h("div", { className: "lmem-field lmem-grow" }, tt("cronNameOptional"),
                h("input", { className: "lmem-input", value: draft.name, placeholder: tt("cronNameAuto"), onChange: function (e) { patch({ name: e.target.value }) } })),
              h("div", { className: "lmem-field lmem-grow" }, tt("cronWorkspace"), workspaceSelect),
            ),
            h("div", { className: "lmem-row" },
              h("div", { className: "lmem-field" }, tt("cronQuick"),
                h("select", { className: "lmem-input", value: draft.quick, onChange: function (e) { patchQuick(e.target.value, {}) } },
                  [["daily", "cronQuickDaily"], ["weekly", "cronQuickWeekly"], ["monthly", "cronQuickMonthly"], ["hourly", "cronQuickHourly"], ["everyN", "cronQuickEveryN"], ["custom", "cronQuickCustom"]]
                    .map(function (o) { return h("option", { key: o[0], value: o[0] }, tt(o[1])) }))),
              quickField,
            ),
            h("div", { className: "lmem-field" }, tt("cronPrompt"),
              h("textarea", { className: "lmem-area lmem-area-sm", value: draft.prompt, placeholder: tt("cronPromptPh"), onChange: function (e) { patch({ prompt: e.target.value }) } })),
            h("div", { className: "lmem-row" },
              h("div", { className: "lmem-field lmem-grow" }, tt("cronModelLabel"), modelPicker),
              effortField,
            ),
            previewBox,
            h("div", { className: "lmem-row" },
              h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { setAdv(!adv) } }, adv ? tt("cronAdvancedHide") : tt("cronAdvanced")),
              h("button", { className: "lmem-btn lmem-btn-sm", onClick: loadOptions }, "⟳ " + tt("cronRefreshList")),
            ),
            advanced,
            h("div", { className: "lmem-row" },
              h("button", { className: "lmem-btn primary", onClick: save, disabled: saving }, saving ? tt("saving") : tt("save")),
              h("button", { className: "lmem-btn", onClick: function () { setDraft(null); setPreview(null) }, disabled: saving }, tt("cancel")),
            ),
          ))
        }

        rows.push(h("div", { className: "lmem-list" },
          jobs.length === 0
            ? h("div", { className: "lmem-status lmem-center" }, tt("cronNoJobs"))
            : jobs.map(function (job) {
              var acting = busyId === job.id || job.lastStatus === "running"
              var tone = acting ? "running" : (job.enabled ? (job.lastStatus || "") : "skipped")
              return h("div", { key: job.id, className: "lmem-entry", style: { "--lmem-pri-color": cronStatusColor(tone) } },
                h("div", { className: "lmem-entry-head" },
                  h("span", { className: "lmem-dot", style: { background: cronStatusColor(tone) }, title: cronStatusText(tt, job.lastStatus) }),
                  h("div", { className: "lmem-entry-title" }, job.name),
                  h("span", { className: "lmem-cron-expr" }, job.expr),
                ),
                h("div", { className: "lmem-entry-meta" },
                  cronDescText(tt, job.description) + " · " + tt("cronNext") + " " + (job.enabled ? fmtClock(job.nextRunAt) : tt("cronNever")) +
                  " · " + tt("cronLast") + " " + cronStatusText(tt, job.lastStatus)),
                (job.provider || job.model || job.effort || job.agentPreset)
                  ? h("div", { className: "lmem-entry-meta" },
                    [
                      (job.provider || job.model) ? (job.provider || "?") + "/" + (job.model || "?") : "",
                      job.effort ? "effort=" + job.effort : "",
                      job.agentPreset ? "preset=" + job.agentPreset : "",
                      job.cwd ? "📁 " + String(job.cwd).split(/[\\/]/).filter(Boolean).pop() : "",
                    ].filter(Boolean).join(" · "))
                  : null,
                h("div", { className: "lmem-row lmem-entry-actions" },
                  h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { toggleJob(job) } }, job.enabled ? tt("cronDisable") : tt("cronEnable")),
                  h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { runNow(job) }, disabled: acting }, acting ? tt("stRunning") : tt("cronRunNow")),
                  h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { toggleRuns(job) } }, tt("cronRecords")),
                  h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { editDraft(job) } }, tt("edit")),
                  h("button", { className: "lmem-btn lmem-btn-sm", onClick: function () { removeJob(job) } }, tt("del")),
                ),
                runsFor === job.id
                  ? h("div", { className: "lmem-runs" },
                    runs.length === 0
                      ? h("div", { className: "lmem-status" }, tt("cronNoRuns"))
                      : runs.map(function (run) {
                        return h("div", { key: run.id, className: "lmem-run", style: { "--lmem-pri-color": cronStatusColor(run.status) } },
                          h("div", { className: "lmem-row" },
                            h("span", { className: "lmem-dot", style: { background: cronStatusColor(run.status) } }),
                            h("span", { className: "lmem-run-st" }, cronStatusText(tt, run.status)),
                            h("span", { className: "lmem-status" }, fmtTime(run.startedAt)),
                            h("span", { className: "lmem-status" }, tt("cronElapsed") + " " + fmtDuration(run.startedAt, run.endedAt)),
                            run.sessionId ? h("span", { className: "lmem-status" }, tt("cronOpenSession") + " " + String(run.sessionId).slice(0, 24)) : null,
                          ),
                          h("div", { className: "lmem-run-sum" }, run.error ? run.error : String(run.summary || "").slice(0, 400)),
                        )
                      }),
                  )
                  : null,
              )
            }),
        ))

        return h.apply(null, ["div", { className: "lmem-cal-wrap" }].concat(rows))
      }

      // ── 样式 ────────────────────────────────────────────────────────────────
      var css = "" +
        ".lmem-view{display:flex;flex-direction:column;gap:10px;padding:12px 14px;height:100%;min-height:0}" +
        ".lmem-tabs{display:flex;gap:6px;align-items:center;flex-wrap:wrap}" +
        ".lmem-subtabs{display:flex;gap:6px;border-bottom:1px solid var(--border-color,rgba(128,128,128,.25));padding-bottom:8px}" +
        ".lmem-tab{padding:4px 14px;border-radius:999px;border:1px solid transparent;background:transparent;color:inherit;cursor:pointer;opacity:.7}" +
        ".lmem-tab.active{opacity:1;border-color:currentColor}" +
        ".lmem-area{flex:1;min-height:0;width:100%;resize:none;font:inherit;line-height:1.6;padding:10px;border-radius:8px;border:1px solid var(--border-color,rgba(128,128,128,.35));background:var(--input-bg,rgba(128,128,128,.08));color:inherit;box-sizing:border-box}" +
        ".lmem-area-sm{flex:none;min-height:90px}" +
        ".lmem-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}" +
        ".lmem-btn{padding:5px 14px;border-radius:8px;border:1px solid currentColor;background:transparent;color:inherit;cursor:pointer;opacity:.85}" +
        ".lmem-btn:hover{opacity:1}" +
        ".lmem-btn.primary{background:rgba(88,101,242,.85);border-color:transparent;color:#fff}" +
        ".lmem-btn:disabled{opacity:.4;cursor:default}" +
        ".lmem-btn-sm{padding:2px 9px;font-size:12px}" +
        ".lmem-status{font-size:12px;opacity:.65}" +
        ".lmem-center{text-align:center;padding:14px 0}" +
        ".lmem-input{padding:5px 9px;border-radius:7px;border:1px solid var(--border-color,rgba(128,128,128,.35));background:var(--input-bg,rgba(128,128,128,.08));color:inherit;font:inherit}" +
        "select.lmem-input{color-scheme:inherit}" +
        "body[data-ds-dark-theme] select.lmem-input{background-color:var(--input-bg,#1e1f26);color:#dcdfe6}" +
        "body[data-ds-dark-theme] select.lmem-input option{background-color:#1e1f26;color:#dcdfe6}" +
        ".lmem-field{display:flex;flex-direction:column;gap:4px;font-size:12px;opacity:.9}" +
        ".lmem-grow{flex:1}" +
        ".lmem-form{display:flex;flex-direction:column;gap:8px;padding:10px;border-radius:10px;border:1px solid var(--border-color,rgba(128,128,128,.3));background:rgba(128,128,128,.05)}" +
        ".lmem-list{display:flex;flex-direction:column;gap:8px;overflow:auto;flex:1;min-height:0}" +
        ".lmem-entry{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border-radius:10px;background:rgba(128,128,128,.07);border:1px solid transparent}" +
        ".lmem-entry:hover{border-color:var(--border-color,rgba(128,128,128,.3))}" +
        ".lmem-pri{flex:none;width:26px;height:26px;border-radius:8px;color:#fff;font-size:12px;display:flex;align-items:center;justify-content:center;margin-top:2px}" +
        ".lmem-entry-body{flex:1;min-width:0}" +
        ".lmem-entry-title{font-weight:600;margin-bottom:3px}" +
        ".lmem-entry-content{font-size:13px;opacity:.85;line-height:1.55;white-space:pre-wrap;word-break:break-word}" +
        ".lmem-entry-meta{font-size:11px;opacity:.45;margin-top:5px}" +
        ".lmem-entry-actions{flex:none}" +
        ".lmem-month{border:1px solid var(--border-color,rgba(128,128,128,.18));border-radius:10px;overflow:hidden}" +
        ".lmem-month-head{display:flex;gap:8px;align-items:center;padding:7px 10px;cursor:pointer;background:rgba(128,128,128,.05);user-select:none}" +
        ".lmem-month-head:hover{background:rgba(128,128,128,.1)}" +
        ".lmem-month-caret{font-size:11px;opacity:.7;width:12px}" +
        ".lmem-month-title{font-weight:600;font-size:13px}" +
        ".lmem-month-count{font-size:11px;opacity:.5;margin-left:auto}" +
        ".lmem-month .lmem-entry{border-radius:0;border-top:1px solid var(--border-color,rgba(128,128,128,.12));border-left:none;border-right:none}" +
        ".lmem-cal-wrap{display:flex;flex-direction:column;gap:10px;position:relative}" +
        ".lmem-cal-card{display:flex;flex-direction:column;gap:8px;padding:12px;border-radius:14px;background:rgba(128,128,128,.05);border:1px solid var(--border-color,rgba(128,128,128,.18));box-shadow:0 1px 6px rgba(0,0,0,.04)}" +
        ".lmem-cal-month{font-weight:700;min-width:96px;text-align:center}" +
        ".lmem-legend{font-size:11px;opacity:.75}" +
        ".lmem-legend-item{margin-right:10px;display:inline-flex;align-items:center}" +
        ".lmem-cal-dow{display:grid;grid-template-columns:repeat(7,1fr);gap:3px;margin-bottom:4px}" +
        ".lmem-cal-dow-cell{text-align:center;font-size:11px;opacity:.55}" +
        ".lmem-cal-gridrow{display:grid;grid-template-columns:repeat(7,1fr);gap:3px}" +
        ".lmem-cal-day{min-height:58px;padding:4px;cursor:pointer;border-radius:8px;border:1px solid color-mix(in srgb,var(--border-color,rgba(128,128,128,.3)) 55%,transparent);background:rgba(128,128,128,.04);overflow:hidden}" +
        ".lmem-cal-day:hover{border-color:var(--dsw-alias-brand-primary,#4f7cff)}" +
        ".lmem-cal-day.today{border-color:var(--dsw-alias-brand-primary,#4f7cff);background:color-mix(in srgb,var(--dsw-alias-brand-primary,#4f7cff) 10%,transparent)}" +
        ".lmem-cal-daynum{font-size:11.5px;font-weight:500;opacity:.7;margin-bottom:3px}" +
        ".lmem-cal-day.today .lmem-cal-daynum{font-weight:700;opacity:1}" +
        ".lmem-cal-chip{font-size:10.5px;line-height:1.35;padding:1px 4px;border-radius:4px;margin-bottom:2px;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}" +
        ".lmem-cal-chip.done{opacity:.5;text-decoration:line-through}" +
        ".lmem-cal-more{font-size:10px;opacity:.5}" +
        ".lmem-cal-modal{position:absolute;inset:0;z-index:10;overflow:auto;border-radius:12px;padding:14px;display:flex;flex-direction:column;gap:10px;background:var(--dsw-alias-bg-overlay,rgba(24,26,32,.94));backdrop-filter:blur(20px) saturate(1.4);border:1px solid var(--border-color,rgba(128,128,128,.35))}" +
        ".lmem-cal-modal-title{font-weight:700}" +
        ".lmem-cal-slot{display:flex;gap:8px;cursor:pointer;padding:2px 0}" +
        ".lmem-cal-slot:hover{background:rgba(128,128,128,.06);border-radius:6px}" +
        ".lmem-cal-slottime{flex:0 0 46px;font-size:11px;opacity:.65;padding-top:4px}" +
        ".lmem-cal-slotevents{min-height:30px;flex:1;border-left:2px solid color-mix(in srgb,var(--dsw-alias-brand-primary,#4f7cff) 24%,transparent);padding-left:9px}" +
        ".lmem-cal{display:flex;flex-direction:column;gap:6px}" +
        ".lmem-cal-item{display:flex;gap:10px;align-items:center;padding:8px 10px;border-radius:10px;background:rgba(128,128,128,.06);border:1px solid transparent;position:relative;overflow:hidden}" +
        ".lmem-cal-item::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--lmem-q-color,rgba(128,128,128,.4))}" +
        ".lmem-cal-item:hover{border-color:var(--border-color,rgba(128,128,128,.3))}" +
        ".lmem-cal-item.done{opacity:.55}" +
        ".lmem-cal-item-body{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}" +
        ".lmem-cal-title{font-size:13px;word-break:break-word}" +
        ".lmem-cal-meta{font-size:11px;opacity:.55}" +
        ".lmem-cal-actions{flex:none}" +
        ".lmem-cal-q{font-size:11px;padding:1px 7px;border-radius:999px;border:1px solid currentColor;opacity:.85;white-space:nowrap;flex:none}" +
        ".lmem-scopebar{display:flex;gap:8px;align-items:center;padding:8px 10px;border-radius:10px;background:rgba(128,128,128,.05);border:1px solid var(--border-color,rgba(128,128,128,.18))}" +
        ".lmem-stat{font-size:12px;padding:3px 10px;border-radius:999px;background:rgba(128,128,128,.08);opacity:.85;white-space:nowrap}" +
        ".lmem-stat-high{color:#d64545;background:rgba(214,69,69,.12)}" +
        ".lmem-entry{position:relative;overflow:hidden}" +
        ".lmem-entry::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--lmem-pri-color,rgba(128,128,128,.35));border-radius:3px 0 0 3px}" +
        ".lmem-month-head{transition:background .15s ease}" +
        ".lmem-month-count{background:rgba(128,128,128,.1);padding:1px 8px;border-radius:999px}" +
        ".lmem-cal-day{transition:border-color .15s ease,background .15s ease,transform .12s ease}" +
        ".lmem-cal-day:hover{transform:translateY(-1px)}" +
        ".lmem-entry-title{font-size:13.5px}" +
        ".lmem-entry{flex-direction:column;align-items:stretch;gap:0}" +
        ".lmem-entry-head{display:flex;gap:8px;align-items:center;cursor:pointer;user-select:none;min-width:0}" +
        ".lmem-entry-head:hover .lmem-entry-title{opacity:.75}" +
        ".lmem-entry-head .lmem-entry-title{flex:1;min-width:0;margin-bottom:0}" +
        ".lmem-btn{transition:opacity .15s ease,background .15s ease}" +
        ".lmem-dot{width:8px;height:8px;border-radius:50%;flex:none;display:inline-block}" +
        ".lmem-cron-expr{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11.5px;padding:1px 7px;border-radius:6px;background:rgba(128,128,128,.14);flex:none}" +
        ".lmem-mono{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}" +
        ".lmem-preview{display:flex;flex-wrap:wrap;gap:6px;align-items:center;padding:8px 10px;border-radius:8px;background:rgba(128,128,128,.06)}" +
        ".lmem-err{color:#d64545}" +
        ".lmem-runs{display:flex;flex-direction:column;gap:6px;margin-top:8px;padding-top:8px;border-top:1px solid var(--border-color,rgba(128,128,128,.2))}" +
        ".lmem-form-adv{display:flex;flex-direction:column;gap:8px;padding:8px 10px;border-radius:8px;background:rgba(128,128,128,.05)}" +
        ".lmem-run{display:flex;flex-direction:column;gap:3px;padding:6px 10px;border-radius:8px;background:rgba(128,128,128,.06);position:relative;overflow:hidden;font-size:12px}" +
        ".lmem-run::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--lmem-pri-color,rgba(128,128,128,.4))}" +
        ".lmem-run-st{font-weight:600}" +
        ".lmem-run-sum{opacity:.8;white-space:pre-wrap;word-break:break-word;max-height:130px;overflow:auto}" +
        ""

      // ── 样式注入（bundle 无 styles builtin，挂 <style> 到 document.head，随插件卸载清理）──
      if (typeof document !== "undefined") {
        ctx.effect(function () {
          var tag = document.createElement("style")
          tag.setAttribute("data-lmem-styles", "")
          tag.textContent = css
          document.head.appendChild(tag)
          return function () {
            if (tag.parentNode) tag.parentNode.removeChild(tag)
          }
        }, "dsh-lite-memory: styles")
      }

      // ── 注册 ────────────────────────────────────────────────────────────────
      slots.inject("conversation.view", function () {
        return slots.register(
          { name: "conversation.view", id: "memory", order: 20, priority: 0, locale: NS, label: function () { return t("nav") } },
          function (props) { return el(MemoryView, { sessionId: props.sessionId || "" }) },
        )
      })

      slots.inject("settings.section", function () {
        return slots.register(
          { name: "settings.section", id: "memory", order: 25, priority: 0, locale: NS, label: function () { return t("nav") } },
          function () { return el(SettingsMemory, null) },
        )
      })
    }

    module.exports = { name: name, inject: inject, apply: apply }
    return module.exports
  },
})
