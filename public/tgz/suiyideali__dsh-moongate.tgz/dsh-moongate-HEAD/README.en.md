![dsh-moongate](docs/social-preview.svg)

# dsh-moongate

**An auto-approval gate for DeepSeek Harness that learns from your approvals.**

> Fewer clicks over time: safe operations run automatically, repeated operations graduate into rules, dangerous operations always go to you.
>
> **Tribute to upstream**: built on [moon09300731/dsh-approval-gate](https://github.com/moon09300731/dsh-approval-gate) v0.5.0 (MIT). The name `moongate` is a nod to the author's handle `moon09300731`. See [Credits](#credits).

[简体中文](README.md) · [English](README.en.md)

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek%20Harness-0.2.x-4D6BFE)](https://www.deepseek.com/harness/)
[![CI](https://github.com/suiyideali/dsh-moongate/actions/workflows/ci.yml/badge.svg)](https://github.com/suiyideali/dsh-moongate/actions/workflows/ci.yml)
[![PRs Welcome](https://img.shields.io/badge/PRs-welcome-brightgreen.svg)](#contributing)
[![GitHub stars](https://img.shields.io/github/stars/suiyideali/dsh-moongate?style=social)](https://github.com/suiyideali/dsh-moongate)
[![awesome · DSH plugin](https://awesome-dsh-plugin.com/badge.svg)](https://awesome-dsh-plugin.com)
[![dsh.so risk](https://cdn.dsh.so/badge/dsh-moongate.svg)](https://www.dsh.so/artifact/dsh-moongate/?ref=badge)

DeepSeek Harness asks before running commands and modifying files. In real use most requests are safe, so approval turns into click fatigue. `dsh-moongate` does three things:

1. **Judge first**: sandbox escalations go to Flash, using the real tool-call arguments rather than model-written justifications;
2. **Learn from your decisions**: approvals are remembered per session, promoted across sessions, and graduated into rules — without extra interactions;
3. **Stay transparent and controllable**: a rule library with sources/hits/evidence, enable/disable/export, plus a dashboard with stats, trends and filters.

Deletion, credentials, remote/production, system paths and bulk irreversible operations are **never auto-approved and never learned**.

---

## Contents

- [Why](#why)
- [Features](#features)
- [Install](#install)
- [Quick start](#quick-start)
- [UI](#ui)
- [How it works](#how-it-works)
- [Learning model](#learning-model)
- [Configuration](#configuration)
- [Security](#security)
- [Compatibility](#compatibility)
- [Development](#development)
- [Roadmap](#roadmap)
- [FAQ](#faq)
- [Contributing](#contributing)
- [Credits](#credits)
- [License](#license)

## Why

Approval fatigue is real: users accept a very high share of permission prompts, and "Allow" becomes muscle memory. The usual extremes are:

- **Sandboxing**: safe, but every new capability needs configuration and cross-directory/network work breaks isolation;
- **Skipping permissions**: convenient, but no protection.

`dsh-moongate` takes the middle path: **model judgment + human confirmation + incremental learning**. It will not auto-approve deleting a production database, but it will remember that you approved writes in a scratch directory three times.

## Features

| Capability | Description |
| --- | --- |
| **Flash judging** | `DENY → trust roots / session memory / allowlist → Flash (SAFE / hard category / neutral) → learning` |
| **Real tool-call input** | Resolves `callId` to the actual `tool/call` arguments (redacted, truncated to 4 KB) |
| **Confirmation learning** | Neutral operations auto-approve after the threshold; fingerprint hits and semantic same-class verification |
| **Read-only fast path** | Works on first install: strictly read-only `git status` / `gh pr view` / `ls` / `cat` / `grep` / `sed -n` commands need no confirmation; only whitelisted programs, no pipes/redirection, paths inside the command cwd, and no rules/learning/snapshots written |
| **Project trust** | Opt in per project root: only `edit`/`write` and recognized `test`/`build` commands (`npm test`, `go test`, etc.) under that root are allowed; `git push`, network, and deletion still ask. Configure under ⑥ Rule library → Trusted dirs |
| **Command-intent learning** | Extracts safe command intents from real bash arguments (`git status`, `npm test`, `gh pr view`, …) and binds them to cwd; `npm test` and `npm publish` no longer share a learning key, and unrecognized commands never enter learning |
| **Semantic reuse** | After one manual approval, similar neutral operations are checked by Flash (SAME/DIFFERENT) using the real arguments and requiring the same program (bash) or tool; only the current operation is allowed, no rule is sedimented; off by default |
| **Remember / forget** | One click in the approval view; path fingerprint when available, exact-description matching otherwise; reversible |
| **Trust roots** | Configure once; operations inside a directory prefix need no prompt |
| **Session memory** | The same fingerprint approved once in a session repeats without prompting |
| **Cross-session promotion** | Multi-session approvals become global rules (path fingerprint, intent signal, no deny history) |
| **Signature graduation** | Similar operations graduate into rules after enough manual confirmations (multi-fingerprint, 2 sessions) |
| **Self-learning (on by default)** | Graduates signatures from cumulative Flash `SAFE` verdicts without human confirmation; default 3 verdicts / 1 session, thresholds and cap configurable |
| **Negative feedback** | Rejecting or reverting removes the learned rule/memory and makes the pattern permanent manual |
| **Rule library** | Allow/deny/trust/graduation in one place; search, inline edit, enable/disable, delete, JSON export, evidence |
| **Rule health check** | Flags generic `contains`, blanket mode rules and huge trust roots, with narrowing suggestions |
| **Reject escalation** | 3 consecutive / 20 total rejections → `escalate` event and a red "needs human" badge |
| **Two-stage judging** | Fast `ALLOW/REVIEW` screen + deep re-check; off by default |
| **Shadow mode** | Records “would auto-approve” candidates while still asking you; candidates write no rules, learning or snapshots; repeated candidates are grouped by command/directory with one-click rule suggestions |
| **Stop-loss observation (P0)** | Records an operation signature, repeat count and touched-file count (scratch directories excluded) on every approval; observation only — no blocking, rules or learning writes; feeds P1 thresholds |
| **Approval dashboard** | Stat cards, five-segment decision mix plus a separate observation count, 7-day trend, top tools, per-project aggregation, filters/search, date-grouped timeline |
| **UI language** | Chinese by default; choose **Chinese / English / Follow system** in **Approval → Settings → Interface language**; the page refreshes after switching (English covers the main views first; Settings is being translated) |

## Install

> Targets **DeepSeek Harness 0.2.x** (verified on 0.2.2-rc.1). Reload the plugin after host changes (toggle the plugin row or restart the app); client-only changes need a page refresh.
>
> **Desktop note**: DSH Desktop manages the `desktop` profile itself; `dsh plugin --profile desktop ...` is rejected (`profile "desktop" is managed exclusively by the Electron application`). Use the app's plugin manager instead. The CLI examples below use `<profile>` for a CLI-managed profile such as `web`; do not substitute `desktop`.
>
> **Primary install method: use the DSH app.** No CLI needed; Desktop users should start with Option 1.
>
> **No setup needed on first use**: after installing and enabling the `auto-approve` preset, strictly read-only commands (`git status`, `gh pr view`, `ls`, `cat`, `grep`, `sed -n`, …) are approved directly. **Self-learning is on by default**, so a few approvals become reusable rules across sessions. Writes, cross-workspace work, network/push operations still ask, so onboarding does not become a click marathon.

### Option 1: install in the DSH app (recommended)

No CLI needed. In the DSH sidebar:

1. Open the **Plugins** page.
2. Open the arrow next to **Add plugin** (**Choose how to add a plugin**) and choose **Install a third-party plugin**. Clicking **Add plugin** opens the same dialog.
3. In the package field, enter:

   ```text
   github:suiyideali/dsh-moongate
   ```

4. Click **Install**, then **Enable now** when the install finishes, and reload/refresh when prompted.
5. Open **Approval → Settings → Permission preset**, click **Configure permission preset**, then restart DSH. Or add it manually to the profile `cordis.patch.yml` as described below.

> The dialog also accepts an npm package name, a tarball, or an absolute local path. This example uses the Git address, so no npm release is required. The Desktop `desktop` profile is managed by the app, so the in-app plugin manager is the correct install path there.

### Option 2: install with the CLI (CLI-managed profiles only)

```sh
dsh plugin --profile <profile> add github:suiyideali/dsh-moongate
# after publishing to npm:
# dsh plugin --profile <profile> add dsh-moongate
```

### Migrating from upstream on Desktop

1. Back up `~/.dsh/auto-approve/`, the profile's `cordis.patch.yml`, and `pnpm-workspace.yaml`.
2. Disable/remove `dsh-approval-gate` in the plugin manager, then delete the `'dsh-approval-gate@0.5.0': ...` line from `patchedDependencies`.
3. Install `dsh-moongate`; after a reload, confirm it is the only approval plugin in the profile.
4. The data directory stays `~/.dsh/auto-approve/`, so existing rules and learning history carry over; the `auto-approve` permission preset stays in place.

> Do not enable `dsh-approval-gate` and `dsh-moongate` together; both would compete for `approval/request`.

### Option 3: patch the upstream package

For a CLI-managed profile that already has upstream `dsh-approval-gate@0.5.0`:

```sh
dsh plugin --profile <profile> add dsh-approval-gate@0.5.0
cp patches/dsh-approval-gate@0.5.0.patch ~/.dsh/profiles/<profile>/patches/
# add to ~/.dsh/profiles/<profile>/pnpm-workspace.yaml:
# patchedDependencies:
#   'dsh-approval-gate@0.5.0': patches/dsh-approval-gate@0.5.0.patch
cd ~/.dsh/profiles/<profile>
pnpm install
```

> The patch option keeps the upstream package name and internal id (`dsh-approval-gate`), for people already on upstream; do not install it alongside the fork package `dsh-moongate`. Both use `~/.dsh/auto-approve/`.

### Permission preset (required for all install options)

The preset table is frozen at composition time. After installing, use **Approval → Settings → Permission preset → Configure permission preset** (it writes the currently running profile; restart DSH to apply), or add the entry manually to the profile `cordis.patch.yml`:

```yaml
- id: permission
  name: '@deepseek-ai/dsh-permission-presets'
  config:
    presets:
      read-only:
        sandbox: read-only
        approval: ask
      workspace-write:
        sandbox: workspace-write
        approval: ask
      danger-full-access:
        sandbox: danger-full-access
        approval: never
      auto-approve:
        sandbox: workspace-write
        approval: ask
        name: 自动审批（Flash）
        description: Learning auto-approval: workspace writes run, confirmed patterns auto-approve, dangerous operations go manual.
```

After a reload, the session permission dropdown shows **自动审批（Flash）**.

## Quick start

1. Select **自动审批（Flash）** in the session permission dropdown — per session only.
2. **No learning setup is required**: self-learning, session memory, and cross-session promotion are on by default. The first time you open **Approval → Settings**, a short note explains:
   - **Default**: after 3 cumulative Flash `SAFE` verdicts (at least 1 session), a rule is learned; session memory / promotion / graduation are also on;
   - **More conservative**: turn self-learning off or raise the thresholds in ⑤;
   - **Faster**: lower the thresholds; click **Trust** on a project-stat row, or add trust roots / project trust in ⑥.
3. Work normally: safe operations run silently, uncertain ones prompt you; approved repeats are reused in this session and promoted to global rules across sessions.
4. For control: **Remember this operation** per row, manage everything in **⑥ Rule library** (including inline editing), tune thresholds in **⑤ Learning & sedimentation**.

## UI

The approval view (right of the trajectory) is a **dashboard**, not a simple list; it puts "see exceptions, understand the decision, control learning" in one place.

### Records tab

| Area | What it shows | Question it answers |
| --- | --- | --- |
| **Needs attention** | Rejected + escalated summary (only shown when such records exist), with a "show only these" action | Is there anything I need to handle? |
| **Overview** (expanded by default, collapsible) | Five decision cards (auto / Shadow / manual / rejected / needs-human, with percentages) plus a separate stop-loss observation count | What is the approval mix in this session? |
| | Six-segment distribution bar + rule overview: total / self-learned / graduated / trust roots | How much is automated, and how much has been learned? |
| | 7-day approval trend + top tools | When, and with which tools, do approvals happen? |
| | Per-project/directory aggregation (all sessions): name, path, auto-rate bar, total/auto/rejected/Shadow | Which projects trigger approvals most, and how automated are they? |
| **Filters** | All / auto / Shadow / stop-loss observation / manual / rejected / escalated / attention chips + search over tool, reason and arguments | Find a class of records quickly |
| **Timeline** | Date-grouped rows with tool, verdict tag, time, reason, real arguments, remember/forget, files and diff snapshots | What exactly happened, why was it allowed, and can I undo it? |

> The overview is expanded by default so the stats come first; collapse it to prioritize the timeline. Rows with a snapshot show "已保留改动快照 · 可在下方 diff 中撤销", keeping the undo path next to the decision.

![Approval view schematic (Records tab, overview expanded)](docs/approval-view.svg)

> Schematic only; the actual rendering depends on the plugin.

### Settings tab

The approval view embeds the full Auto approval settings; this is the **only entry point**:

- sticky sub-navigation: Setup / Pipeline / ① DENY / ② Allowlist / ③ denyRules / ④ Flash / Shadow / Stop-loss observation / ⑤ Learning & sedimentation / ⑥ Rule library;
- click to scroll to the card; changes apply hot without leaving the view;
- click a card title to collapse / expand it (collapsed by default); clicking a top chip expands then scrolls.
- the DSH global Settings page no longer duplicates the Auto approval entry; configure everything from the Approval tab.

Eight configuration cards:

| Card | Content |
| --- | --- |
| ① DENY | Irreversible danger keywords |
| ② Allowlist | Auto-approve rules with source and hit count |
| ③ denyRules | Permanently manual rules |
| ④ Flash | `judgeTimeoutMs` |
| Shadow | Observation toggle; candidates are recorded, not auto-approved |
| Stop-loss observation | P0 observation toggle; records signature/repeats/files without changing approval outcomes |
| ⑤ Learning & sedimentation | `riskyThreshold`, manual-confirmation keys/threshold + session memory, promotion, graduation, self-learning, two-stage, semantic reuse |
| ⑥ Rule library | Unified rule management + inline editing + health check + export |

> **Shadow boundary**: during observation, rejected candidates are **not** written to `denyRules` — Shadow produces no learning side effects at all. After turning Shadow off, add a permanent-manual rule (or keep the existing deny rule) if you want an operation to remain manual.

> **Stop-loss observation (P0)**: `guard` is observation-only. When enabled, every approval adds a `guard-candidate` event with an `operationSignature`, same-signature repeat count, touched-file count (`/tmp`, `/private/var/folders` and similar scratch dirs excluded) and cwd. Approval outcomes, rules, learning counters and snapshots are unchanged. Filter by “Stop-loss observation” in Records; P1 will derive soft thresholds from this data.

## How it works

```mermaid
flowchart TD
  A[Sandbox escalation approval/request] --> B{Session preset = auto-approve?}
  B -- No --> H[Human / other answerers]
  B -- Yes --> C{DENY keywords}
  C -- Hit --> H
  C -- Miss --> D{Trust roots / session memory / allowlist}
  D -- Hit --> E[Auto approve]
  D -- Miss --> F[Flash judging<br/>tool + real arguments]
  F -- SAFE --> E
  F -- Hard category --> H
  F -- Neutral --> G[Confirmation learning n/N]
  G -- Approved --> I[Count / sample / promotion / graduation]
  G -- Rejected --> J[denyRule, permanently manual]
```

- Only sandbox escalations go through it; normal workspace operations do not.
- Per-session gating: sessions not on the preset are untouched.
- Fail-safe: Flash timeout/error/unparseable output → manual.
- Real arguments come from `tool/call` events via `callId`, with secret redaction and an 8 KB cache cap.

## Learning model

| Layer | Signal | Scope | Default |
| --- | --- | --- | --- |
| Remember (manual) | "Remember this operation" | Global rule | Available |
| Trust roots | Explicit configuration | Directory prefix | Empty |
| Command intent | Safe command + cwd from real bash arguments | Same command and directory | On (conservative) |
| Session memory | Manual approvals in this session | Session | On |
| Cross-session promotion | Manual approvals in multiple sessions | Global rule | On (2 sessions) |
| Signature graduation | Repeated manual approvals of similar ops | Global rule | On (3 / 2 sessions) |
| Self-learning | Consecutive Flash `SAFE` verdicts | Global rule | **On** (3 verdicts / 1 session; can be turned off) |

Self-learning is on by default so a new user can reduce repeat approvals without studying the settings first. It is still the only layer without a human label, so guardrails apply: path signature, no deny history, verdict/session thresholds, a 50-rule cap; dangerous categories never enter learning, and rejection/revert removes the rule and progress. Turn it off in ⑤ for a fully conservative setup; an explicit `false` is never overridden by an upgrade.

### How cross-session learning works

| Path | Trigger | Result |
| --- | --- | --- |
| Session memory | You approved the same operation in this session | Reused in this session (12h TTL) |
| Cross-session promotion | Same operation approved in at least 2 sessions | Global allow rule |
| Signature graduation | Same class approved 3 times across 2 sessions with no deny history | Global signature rule |
| Self-learning | 3 cumulative Flash `SAFE` verdicts in at least 1 session | Global rule (no human label) |

These rules are **global**: a test command or project write learned in session A also applies in session B. Audit or delete them by source, hit count, and evidence in ⑥ Rules.

## Configuration

Everything lives in `~/.dsh/auto-approve/`; edits to `allowlist.json` are hot-reloaded.

| Field | Default | Meaning |
| --- | --- | --- |
| `denyKeywords` | built-in | Always manual |
| `allowRules` | workspace-write | Allowlist rules (`tool/mode/category/contains/signature/disabled`) |
| `denyRules` | `[]` | Permanently manual rules |
| `hardCategories` | deletion/credential/remote/system/bulk | Never learned |
| `riskyThreshold` | 3 | Neutral confirmation threshold |
| `judgeTimeoutMs` | 20000 | Flash judge timeout (1 retry) |
| `trustRoots` | `[]` | Trusted directories |
| `sessionMemory` | true | Session-scoped approval memory |
| `promotionSessions` | 2 | Sessions for cross-session promotion (3 without intent signal) |
| `graduationThreshold` | 3 | Manual confirmations for graduation (4 without intent signal) |
| `graduationSessions` | 2 | Sessions for graduation |
| `selfLearn` | true | Self-learning switch (explicit false stays off) |
| `selfLearnThreshold` | 3 | Consecutive SAFE verdicts |
| `selfLearnSessions` | 1 | Sessions for self-learning |
| `selfLearnMaxRules` | 50 | Self-learned rule cap |
| `twoStage` | false | Two-stage judging switch |
| `shadow` | false | Shadow observation mode; candidates are recorded but not auto-approved |
| `guard` | false | P0 stop-loss observation; records signature/repeats/files without changing outcomes |
| `semanticReuse` | false | After one manual approval, semantically verify similar neutral operations with Flash; no rule sedimentation |
| `stage1Provider` / `stage1Model` | empty | Fast-screen model |
| `denyEscalateConsecutive` | 3 | Consecutive rejection escalation |
| `denyEscalateTotal` | 20 | Total rejection escalation |

Files: `allowlist.json` (rules/config), `learning.json` (confirmation learning), `memory.json` (cross-session/graduation/self-learning progress), `audit.log`, `events.jsonl`, `snapshots/` (pre-write snapshots for diff/revert).

## Security

- Hard-risk categories are never auto-approved or learned.
- Denied fingerprints/signatures become permanently manual; rejection also removes learned rules and memory.
- Reverting an auto-approved change triggers negative feedback and removes the matching rule.
- Real arguments are redacted and truncated before model input.
- Every rule has source/createdAt/hitCount/lastHit; remember/self-learning rules carry evidence events.
- Rule health check flags generic `contains`, blanket rules, and `~`/`/` trust roots with enable/disable controls.

> ⚠️ Auto approval significantly reduces human oversight. Use in trusted environments; keep manual approval for production, payments and remote systems.

## Compatibility

- Targets **DeepSeek Harness 0.2.x**, verified on 0.2.2-rc.1.
- Includes fixes for the upstream `permissionPresets.current(session)` API and Flash `reasoningEffort: off` compatibility.
- Re-verify after DSH upgrades; issues/PRs welcome.

## Development

```sh
npm test   # node --check + smoke tests
```

CI (`.github/workflows/ci.yml`) runs syntax checks, smoke tests, verifies the patch applies to upstream `0.5.0`, and checks the license.

Local loop: host changes need a plugin reload; client changes need a page refresh; run `npm test` before committing.

## Roadmap

- [x] Inline rule editing (tool/mode/category/contains/description);
- [x] Semantic reuse (Flash verifies similar operations after one approval using real args and the same program/tool; allows only the current operation);
- [x] Shadow mode: record "would auto-approve" candidates before enabling;
- [x] Per-project stats (all sessions, unknown-directory fallback);
- [x] i18n (Chinese by default; switch Chinese/English/Follow system in settings);
- [x] Command-intent learning (safe bash commands + cwd get separate counters/rules; unrecognized commands are not learned);
- [x] Shadow candidate grouping and rule suggestions (same command/directory candidates aggregate; create a rule manually);
- [x] P0 stop-loss observation (signature/repeat/file-count recording, observe-only);
- [x] First-use read-only fast path (strictly read-only, inside cwd, no pipes/redirection, no setup).
- [x] Project-level trust: allow edit/write and recognized test/build inside a project root; push/network/deletion still ask.
- [x] Onboarding and default self-learning: a first-run note explains cross-session learning; self-learning defaults to 3 SAFE verdicts / 1 session.

## FAQ

**Why is self-learning on by default?** It lets a new user reduce repeat approvals without configuration; dangerous categories, deny history, and explicit permanent-manual rules still win, and rejection/revert removes learned rules. Turn it off in ⑤ if you prefer a conservative setup; upgrades preserve that choice.

**Can I install it alongside upstream?** Not recommended; both compete for the `auto-approve` preset and `approval/request`.

**Where is learning data?** `~/.dsh/auto-approve/`; reinstalling the plugin does not delete it. Back it up before DSH upgrades.

**How do I trust a directory?** Add it in ⑥ (for example `~/src`); it bypasses prompts but not DENY/hard-risk rules.

**Why is the approval view empty?** No sandbox escalations yet, or the session is not on the auto-approve preset.

## Contributing

- Open an issue first for behavior changes;
- Keep `npm test` green and add smoke assertions for new behavior;
- Do not commit local paths, credentials or test leftovers;
- Security-semantics changes must describe the threat model and rollback.

## Credits

This project is based on **[moon09300731/dsh-approval-gate](https://github.com/moon09300731/dsh-approval-gate)** v0.5.0 (MIT):

- Upstream: <https://github.com/moon09300731/dsh-approval-gate>
- Author: moon09300731
- Inherited: Flash judging pipeline, confirmation-based learning, settings rule cards, approval view, diff revert and snapshots
- Added by this fork: real tool arguments, remember/forget, trust roots, session memory/cross-session promotion, signature graduation, self-learning, rule library, approval dashboard, and more (see [FORK-CHANGES.md](FORK-CHANGES.md))

The name `moongate` is a nod to the author's handle `moon09300731`. Thanks to the upstream author; if you like the idea, please give upstream a star.

Original copyright remains with the upstream author; modifications are released under MIT. See [LICENSE](LICENSE).

## License

[MIT](LICENSE) © 2026 moon09300731 (upstream) and dsh-moongate contributors. Modifications provided without warranty.

[![Star History Chart](https://api.star-history.com/svg?repos=suiyideali/dsh-moongate&type=Date)](https://star-history.com/#suiyideali/dsh-moongate&Date)
