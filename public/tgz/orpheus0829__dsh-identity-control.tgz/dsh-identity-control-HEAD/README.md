# dsh-identity-control

DSH（DeepSeek Harness）的自定义人设控制插件。对话输入栏旁提供一个入口，可以自己填人设文本，开启后新对话会自动带上，关掉就恢复默认。

[![License](https://img.shields.io/badge/license-MIT-3d6fe0)](LICENSE)
[![Version](https://img.shields.io/badge/version-0.1.0-3d6fe0)](package.json)

## 为什么写这个

市面上的人设插件大多是写死的一种风格，只能开关。这个插件把控制权交给你：人设文本由你自己写，界面里填、随时改、一键开关。

## 功能

- 输入栏旁有个人设按钮，点开是编辑面板，里面一个多行文本框 + 启用开关
- 填好保存后，所有新对话自动带上这段人设
- 关闭开关立即恢复默认人设，不用重启
- 人设只是注入提示词，不覆盖 DSH 的安全规则

## 安装

```bash
dsh plugin --profile web add github:orpheus0829/dsh-identity-control
```

装完重启 DSH 界面，输入栏右侧出现人设按钮。

本地调试时也可以用 link 方式：

```bash
dsh plugin --profile web add link:<本地路径>
```

## 使用

1. 点输入栏右侧的人设按钮
2. 在文本框里写人设，勾上启用
3. 保存，开聊

人设文本留空或没勾启用时，插件什么都不注入，DSH 保持默认行为。

## 结构

```
lib/
  index.mjs   # host 侧：读配置，开启且文本非空时注入人设段
  client.js   # 浏览器侧：输入栏入口 + 编辑面板
cordis.patch.yml
package.json
```

配置存在 DSH settings 的 `identity-control` 命名空间里（enabled / text 两个字段），状态会持久化。

## Credits

人设注入的整体思路参考了 DSH 社区的人设类插件，在此致谢。

## License

MIT
