// @ts-check
import { test } from "node:test";
import assert from "node:assert/strict";
import { sendTextMessage, getUpdates } from "../src/weixin-api.js";

const CREDS = {
	botToken: "test-token",
	ilinkBotId: "acct-1",
	baseUrl: "https://ilinkai.weixin.qq.com",
	cdnBaseUrl: "https://novac2c.cdn.weixin.qq.com/c2c",
};

/** Install a fetch stub answering every call with the given JSON body. */
function withFetch(body, status = 200, fn) {
	const real = global.fetch;
	global.fetch = async () => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json" } });
	return Promise.resolve(fn()).finally(() => { global.fetch = real; });
}

test("sendTextMessage rejects on business error inside HTTP 200 (errcode -14)", async () => {
	await withFetch({ errcode: -14, errmsg: "session timeout" }, 200, async () => {
		await assert.rejects(
			() => sendTextMessage(CREDS, "peer", "hi", "tok"),
			/code=-14 session timeout/,
		);
	});
});

test("sendTextMessage resolves on errcode 0 and on bodies without errcode", async () => {
	await withFetch({ errcode: 0 }, 200, async () => {
		const r = await sendTextMessage(CREDS, "peer", "hi", "tok");
		assert.ok(r.clientId);
	});
	await withFetch({ client_id_list: [] }, 200, async () => {
		await assert.doesNotReject(() => sendTextMessage(CREDS, "peer", "hi", "tok"));
	});
});

test("getUpdates passes business errors through as data for the poll loop", async () => {
	await withFetch({ errcode: -14, errmsg: "session timeout" }, 200, async () => {
		const resp = await getUpdates(CREDS, "");
		assert.equal(resp.errcode, -14); // must NOT throw — poll loop pauses on it
		assert.deepEqual(resp.msgs, undefined);
	});
});

test("non-JSON bodies still throw", async () => {
	const real = global.fetch;
	global.fetch = async () => new Response("<html>gateway</html>", { status: 200 });
	try {
		await assert.rejects(() => sendTextMessage(CREDS, "peer", "hi", "tok"), /non-JSON/);
	} finally {
		global.fetch = real;
	}
});

test("sendTextMessage rejects on ret-code rejections (prepare failed)", async () => {
	await withFetch({ ret: -2, errmsg: "prepare failed" }, 200, async () => {
		await assert.rejects(
			sendTextMessage(CREDS, "peer-x", "hi", "ctx-tok"),
			/WeChat API sendmessage failed: code=-2 prepare failed/,
		);
	});
});

test("ret:0 passes as success (getconfig success shape)", async () => {
	const { default: assertNoop } = await import("node:assert");
	await withFetch({ ret: 0, typing_ticket: "T" }, 200, async () => {
		const { sendTyping } = await import("../src/weixin-api.js");
		// sendtyping goes through weixinRequest; ret:0 must resolve, not throw.
		await assert.doesNotReject(sendTyping(CREDS, "peer-x", "ticket", 1));
		assertNoop(true);
	});
});
