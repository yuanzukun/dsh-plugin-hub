# Changelog

All notable changes to this plugin are documented in this file.

## [Unreleased]

- feat(notify): per-workspace muting for one-way notifications. Settings →
  微信桥接 → 会话通知 gains a compact 「静音工作区」 row: chips of currently
  muted workspaces (click to unmute) plus a lazy ＋ picker that only fetches
  the workspace list from /api/workspace.list when expanded. Sessions inside
  muted workspaces never trigger a push; the filter re-reads both the
  settings namespace and the workspace registry on every event, so changes
  apply immediately without restarts. Stored as notifyMutedWorkspaces
  [{id,title}] in settings.yaml; exposed via GET /status and accepted by
  POST /config (sanitized). +2 pure-helper tests.

- fix(api): recognize BOTH ilink business-error shapes inside HTTP-200
  bodies. Besides `{errcode:-14}` the server also rejects sends with
  `{ret:-2, errmsg:"prepare failed"}` (send-plane rejection while polling
  and getconfig stay healthy); weixinRequest only checked `errcode`, so
  these passed as success and notifications/replies were dropped with a
  green ✓ (lastNotify ok=1 while nothing was delivered). Both shapes now
  throw as `code=<n> <errmsg>` so failures surface in lastNotify,
  notify-test results, and enter the catch-up backlog. +2 tests.

- fix(notify): one-way notifications no longer appear to require a two-way
  exchange each new day. They never depended on the day session (created
  lazily on inbound); the real gate is the peer context_token's server-side
  TTL. Failed pushes (errcode -14 etc.) now enter a per-peer backlog
  (≤20 entries, 24h TTL, exact-dedupe) that is merged-delivered
  automatically when the next inbound message refreshes the token —
  overnight turns are caught up after the first morning message instead of
  being lost. Store records `contextTokenAt` refresh times;
  GET /status exposes `notifyBacklog` + `peerTokenAgeHours`; the
  notification card explains the catch-up behavior and shows a
  「待补发 N 条」 indicator; send-test also flushes the backlog. +1 store test.

- fix(api): ilink business errors arrive INSIDE HTTP-200 bodies
  (`errcode:-14 "session timeout"`); weixinRequest now throws on them so
  silent message loss becomes a visible, loggable failure. getupdates opts
  out — its errcode contract belongs to the poll loop, which pauses 60m and
  marks the account `session-expired`.
- Root-caused flaky/vanishing one-way notifications: the peer context_token
  expires server-side after a while, and every later proactive push was
  rejected with errcode -14 while the client treated it as success.
  Two-way replies kept working because they ride the fresh token of each
  inbound message.
- Diagnostics: POST /wechat-bridge/notify-test performs one real proactive
  send per reachable target and returns per-target outcomes (+「发送测试」
  button in the notification card); GET /status now exposes lastNotify and
  per-account health; the poller re-reads account credentials every cycle,
  so a QR re-login recovers polling without disable/enable or restart.

- fix(notify): the id badge in the notification header sliced the raw
  session id head, rendering the constant prefix ("sessio") for ids like
  `session-abcdef12-…`. New `sessionIdBadge()` strips a leading
  `session-`/`wechat-` marker first (case-insensitive) and falls back to
  the raw id when nothing remains (+1 test).

- Surface real model-call failures to WeChat instead of a generic
  「(空回复)」: when the driven turn ends with reason.kind === 'error' and
  produced no assistant text, the bridge now replies
  「⚠️ 模型调用失败（provider/model）：<上游错误原文>」
  (new pure helper `formatTurnErrorReply`, +3 tests).
- 默认模型 card + docs now state explicitly that the pinned
  defaultProvider/defaultModel is re-installed on EVERY inbound message —
  switching models inside a WeChat session from the web GUI does not affect
  WeChat replies (this caused the confusing "switched to openrouter but
  still API key invalid" case: the calls were still going out on the old
  pinned provider with its dead key).

- Settings-tab allowlist editor (「入站白名单」card): edit `allowedPeers`
  directly (normalized comma-separated), persisted via
  POST /wechat-bridge/config → settings.yaml. Shows clickable
  「已对话过的 ID」chips built from stored context tokens — the opaque
  internal peer ids only become known through an actual conversation, so
  denied peers now also get their context token recorded and their id
  echoed back by the bot. Card carries an explicit hint that these ids are
  NOT WeChat aliases/nicknames.
- Settings-tab toggle for one-way session notifications (「会话通知」card,
  persisted via POST /wechat-bridge/config → settings.yaml).
- One-way session turn-end notifications (`notifyEnabled`, default ON): every
  top-level DSH session's finished turn pings the allowlisted peers with a
  fixed two-line template (session name ≤15 chars + session id first 6 chars,
  then the turn response ≤200 chars) — no LLM summarization.
  Notifications go straight through the WeChat API and are never written into
  any session: the daily bridge conversation neither sees nor is extended by
  them (mutual non-pollution). Bridge-owned sessions and subagent children are
  skipped; reload-artifact `interrupted` turn closers are skipped too.

## [0.1.0] - 2026-08-16

- Initial release of the WeChat (ilink bot) bridge for DeepSeek Harness.
- Multi-account polling of the WeChat ilink bot API with one session per peer per day.
- Cross-process poll lock, per-chat serialization, inbound dedupe, and corrupt-log self-heal.
- Runtime hot-plug from the Settings UI tab, `/wechat` slash commands, or `settings.yaml`.
- QR-code account binding from the Settings tab.
- Context parity with GUI sessions: injects the user-global `AGENTS.md` and the skill catalog.
- Inbound media download + AES decrypt; outbound media via the `wechat_send_file` tool.
