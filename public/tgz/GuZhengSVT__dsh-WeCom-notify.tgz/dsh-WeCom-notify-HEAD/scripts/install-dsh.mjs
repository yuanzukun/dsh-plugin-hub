/**
 * 一键安装脚本：`npm run install-dsh`
 * 1. 构建插件（npm run build：esbuild host + tsdown client）
 * 2. 更新 dsh web profile 的 patch，指向编译产物（含 client 设置面板）
 * 3. 提示重启 dsh web 生效
 *
 * 要求：dsh 已安装（npm 全局）；本脚本只写 ~/.dsh/profiles/web/cordis.patch.yml。
 * 即装即用：patch 不写任何配置——安装后在 dsh 设置 → 企业微信通知 里粘贴
 * webhook key（可多个，同时通知所有群）保存即可。
 */
import { execSync } from 'node:child_process'
import { writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('..', import.meta.url))
const entryUrl = `file://${join(root, 'lib', 'index.js')}`
const profilePatch = join(homedir(), '.dsh', 'profiles', 'web', 'cordis.patch.yml')

console.log('→ 构建插件（host + client 设置面板）...')
execSync('npm run build', { stdio: 'inherit', cwd: root })

const content = `# wechat-notify plugin (installed via npm run install-dsh)
# 重新安装即重建此文件；如改过请合并后再跑。
# 即装即用：无需在此填配置——在 dsh 设置 → 企业微信通知 里填 webhook key 即可。
- insert:
    - id: wechat-notify
      name: '${entryUrl}'
`

writeFileSync(profilePatch, content)
console.log(`✅ patch 已写入：${profilePatch}`)
console.log(`   插件入口：${entryUrl}`)
console.log('→ 重启 dsh web 生效（日志出现 [wechat-notify] plugin loaded 即加载成功）')
console.log('→ 打开 dsh 设置 → 企业微信通知，粘贴 webhook key 保存，即可收到通知')
