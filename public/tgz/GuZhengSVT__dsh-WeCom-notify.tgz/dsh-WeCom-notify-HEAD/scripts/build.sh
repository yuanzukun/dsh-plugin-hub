#!/bin/bash
# Build dsh-wecom-notify:
#   1) esbuild 编译 host（src/index.ts → lib/index.js，external @deepseek-ai/*）
#   2) tsdown 编译 client 设置面板（src/client/index.ts → lib/client.js，ModuleLoader bundle）
#   3) 构建前 link client 依赖包（dsh-client-ui-slots / dsh-client-runtime）
# Requires: esbuild + tsdown（devDependencies），以及 dsh checkout / 全局安装。
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

# ── 探测 dsh 安装根 ──
DSH_ROOT="${DSH_CHECKOUT:-}"
if [ -z "$DSH_ROOT" ] && [ -d "$ROOT/../deepseek-harness/packages/client/ui-slots" ]; then
  DSH_ROOT="$(cd "$ROOT/../deepseek-harness" && pwd)"
fi
if [ -z "$DSH_ROOT" ] || [ ! -d "$DSH_ROOT/packages/client/ui-slots" ]; then
  GLOBAL="$(npm root -g)/@deepseek-ai/dsh"
  if [ -d "$GLOBAL" ]; then
    # 全局安装形态：client 包在其 node_modules 下
    if [ -d "$GLOBAL/node_modules/@deepseek-ai/dsh-client-ui-slots" ]; then
      DSH_ROOT="$GLOBAL"
    fi
  fi
fi
if [ -z "$DSH_ROOT" ] || { [ ! -d "$DSH_ROOT/packages/client/ui-slots" ] && [ ! -d "$DSH_ROOT/node_modules/@deepseek-ai/dsh-client-ui-slots" ]; }; then
  echo "build: cannot locate the dsh installation (set DSH_CHECKOUT)" >&2
  exit 1
fi
echo "=== dsh root: $DSH_ROOT ==="

link_pkg() {
  local name="$1"
  local target="$2"
  local link="node_modules/@deepseek-ai/$name"
  node -e "
    const fs = require('fs');
    const path = require('path');
    const link = path.resolve(process.argv[1]);
    const target = path.resolve(process.argv[2]);
    fs.rmSync(link, { recursive: true, force: true });
    fs.mkdirSync(path.dirname(link), { recursive: true });
    fs.symlinkSync(target, link, process.platform === 'win32' ? 'junction' : 'dir');
  " "$link" "$target"
}

echo "=== Linking client build dependencies ==="
mkdir -p node_modules/@deepseek-ai
if [ -d "$DSH_ROOT/packages/client/ui-slots" ]; then
  link_pkg dsh-client-ui-slots "$DSH_ROOT/packages/client/ui-slots"
  link_pkg dsh-client-runtime "$DSH_ROOT/packages/client/runtime"
else
  link_pkg dsh-client-ui-slots "$DSH_ROOT/node_modules/@deepseek-ai/dsh-client-ui-slots"
  link_pkg dsh-client-runtime "$DSH_ROOT/node_modules/@deepseek-ai/dsh-client-runtime"
fi

echo "=== Compiling host (esbuild) ==="
npx esbuild src/index.ts --bundle --format=esm --platform=node --target=node20 \
  --outfile=lib/index.js --external:@deepseek-ai/* --sourcemap

echo "=== Compiling client (tsdown) ==="
# 优先本地 tsdown；缺失时 fallback 到 dsh checkout 的（npm install 可能因
# 上游 rc 包未发布而失败——@deepseek-ai/dsh-compact 404，见 README FAQ）
TSDOWN_BIN="$(command -v tsdown || true)"
if [ -z "$TSDOWN_BIN" ] && [ -x "$DSH_ROOT/node_modules/.bin/tsdown" ]; then
  TSDOWN_BIN="$DSH_ROOT/node_modules/.bin/tsdown"
fi
if [ -z "$TSDOWN_BIN" ]; then
  echo "build: tsdown not found (npm i 失败可改用 DSH_CHECKOUT 内的 tsdown)" >&2
  exit 1
fi
"$TSDOWN_BIN"

echo "=== Type-checking client (optional; fails soft) ==="
if [ -x "$DSH_ROOT/node_modules/.bin/tsc" ]; then
  "$DSH_ROOT/node_modules/.bin/tsc" --noEmit -p tsconfig.client.json || echo "  ⚠️ client typecheck 有告警（不影响产物）"
fi

echo "=== Build complete ==="
ls -la lib/
