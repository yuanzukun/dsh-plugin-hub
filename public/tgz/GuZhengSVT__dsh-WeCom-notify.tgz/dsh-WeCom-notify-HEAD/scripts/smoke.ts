/**
 * 冒烟测试：向企业微信群发一条真实消息，验证通道与 key 可用。
 * 用法：WECHAT_WEBHOOK_KEY=<你的key> node scripts/smoke.ts
 * 多 key：WECHAT_WEBHOOK_KEYS='key1,key2' node scripts/smoke.ts
 */
import { loadConfig } from '../src/config.ts'
import { targetsOf } from '../src/notifier.ts'
import { sendWechatTargets } from '../src/client.ts'

const cfg = loadConfig()
const targets = targetsOf(cfg)
const result = await sendWechatTargets(
  targets,
  '## ✅ dsh 插件冒烟测试\n\n如果你在群里看到这条消息，说明 dsh → 企业微信通知链路已打通。',
)

if (result.ok) {
  console.log(`✅ 冒烟测试已发送到 ${targets.length} 个群：${result.detail}`)
} else {
  console.error(`❌ 冒烟测试失败：${result.detail}`)
  process.exit(1)
}
