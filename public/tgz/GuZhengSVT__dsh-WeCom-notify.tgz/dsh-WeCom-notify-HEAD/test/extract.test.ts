import { test } from 'node:test'
import assert from 'node:assert/strict'
import { isMainSession, isAssistantMessage, isTurnEnd, assistantText } from '../src/extract.ts'

test('isMainSession: 主会话（无 parentSession）为 true', () => {
  assert.equal(isMainSession({ header: {} }), true)
  assert.equal(isMainSession({}), true)
  assert.equal(isMainSession({ header: { parentSession: null } }), true)
})

test('isMainSession: subagent 会话（有 parentSession）为 false', () => {
  assert.equal(isMainSession({ header: { parentSession: 'main-session-id' } }), false)
})

test('isAssistantMessage / isTurnEnd: 事件类型判断', () => {
  assert.equal(isAssistantMessage({ type: 'assistant/message' }), true)
  assert.equal(isAssistantMessage({ type: 'turn/end' }), false)
  assert.equal(isTurnEnd({ type: 'turn/end' }), true)
  assert.equal(isTurnEnd({ type: 'assistant/message' }), false)
})

test('assistantText: 提取文本块并拼接', () => {
  const event = {
    type: 'assistant/message',
    data: {
      message: {
        role: 'assistant',
        content: [
          { type: 'text', text: '第一段' },
          { type: 'tool-call', name: 'bash' },
          { type: 'text', text: '第二段' },
        ],
      },
    },
  }
  assert.equal(assistantText(event), '第一段\n\n第二段')
})

test('assistantText: 无文本块返回 null', () => {
  assert.equal(assistantText({ type: 'assistant/message', data: { message: { content: [{ type: 'tool-call' }] } } }), null)
  assert.equal(assistantText({ type: 'assistant/message' }), null)
  assert.equal(assistantText({ type: 'turn/end' }), null)
})

test('assistantText: 纯空白文本忽略', () => {
  const event = {
    type: 'assistant/message',
    data: { message: { content: [{ type: 'text', text: '   ' }] } },
  }
  assert.equal(assistantText(event), null)
})
