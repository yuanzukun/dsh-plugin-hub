import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createNotifier } from '../src/notifier.ts'
import type { NotifyConfig } from '../src/config.ts'

const OK = { errcode: 0, errmsg: 'ok' }

function makeConfig(overrides: Partial<NotifyConfig> = {}): NotifyConfig {
  return {
    webhookKeys: ['test-key'],
    webhookUrl: null,
    mentionUserid: null,
    minIntervalMs: 10_000,
    dedupeWindowMs: 30_000,
    triggerOnAgentIdle: false,
    turnSummaryEnabled: true,
    maxBytes: 3800,
    ...overrides,
  }
}

function mockFetch(handler: (url: string, init: RequestInit) => Promise<Response>): { calls: () => number; restore: () => void } {
  const original = globalThis.fetch
  let calls = 0
  globalThis.fetch = (async (url: unknown, init?: unknown) => {
    calls++
    return handler(String(url), (init ?? {}) as RequestInit)
  }) as typeof fetch
  return { calls: () => calls, restore: () => { globalThis.fetch = original } }
}

const wait = (ms: number) => new Promise((r) => setTimeout(r, ms))
const noSleep = async () => {}

test('notifier: 未配置时返回提示且不发请求', async () => {
  const m = mockFetch(async () => jsonResponse(OK))
  try {
    const notifier = createNotifier(makeConfig({ webhookKeys: [], webhookUrl: null }))
    const result = await notifier.push({ kind: 'custom', text: 'hi' })
    assert.match(result, /webhook key/i)
    await wait(20)
    assert.equal(m.calls(), 0)
  } finally {
    m.restore()
  }
})

test('notifier: 去重窗口内相同内容只发一次', async () => {
  const m = mockFetch(async () => jsonResponse(OK))
  try {
    const notifier = createNotifier(makeConfig({ minIntervalMs: 0, dedupeWindowMs: 60_000 }), console, { sleep: noSleep })
    const first = await notifier.push({ kind: 'custom', text: '相同的消息' })
    const second = await notifier.push({ kind: 'custom', text: '相同的消息' })
    assert.match(first, /已受理/)
    assert.match(second, /已去重/)
    await wait(20)
    assert.equal(m.calls(), 1)
  } finally {
    m.restore()
  }
})

test('notifier: 节流时第二条排队，两条最终都发出', async () => {
  const m = mockFetch(async () => jsonResponse(OK))
  try {
    const notifier = createNotifier(makeConfig({ minIntervalMs: 60_000, dedupeWindowMs: 0 }), console, { sleep: noSleep })
    const first = await notifier.push({ kind: 'custom', text: '第一条' })
    const second = await notifier.push({ kind: 'custom', text: '第二条' })
    assert.match(first, /已受理/)
    assert.match(second, /已排队/)
    await wait(20)
    assert.equal(m.calls(), 2)
  } finally {
    m.restore()
  }
})

test('notifier: 节流间隔内第二条消息延迟到间隔后发送', async () => {
  const timestamps: number[] = []
  const m = mockFetch(async () => {
    timestamps.push(Date.now())
    return jsonResponse(OK)
  })
  try {
    const notifier = createNotifier(makeConfig({ minIntervalMs: 80, dedupeWindowMs: 0 }))
    await notifier.push({ kind: 'custom', text: '第一条' })
    await notifier.push({ kind: 'custom', text: '第二条' })
    await wait(250)
    assert.equal(m.calls(), 2)
    assert.ok(timestamps[1] - timestamps[0] >= 80, `实际间隔 ${timestamps[1] - timestamps[0]}ms < 80ms`)
  } finally {
    m.restore()
  }
})

test('notifier: 配置 mentionUserid 时走 text 消息', async () => {
  const m = mockFetch(async (_url, init) => {
    const body = JSON.parse(String(init.body))
    assert.equal(body.msgtype, 'text')
    assert.deepEqual(body.text.mentioned_list, ['zhangsan'])
    return jsonResponse(OK)
  })
  try {
    const notifier = createNotifier(makeConfig({ mentionUserid: 'zhangsan' }), console, { sleep: noSleep })
    await notifier.push({ kind: 'custom', text: 'hi' })
    await wait(20)
    assert.equal(m.calls(), 1)
  } finally {
    m.restore()
  }
})

test('notifier: 多个 webhook key 同时通知所有群（每个 key 一次请求）', async () => {
  const urls: string[] = []
  const m = mockFetch(async (url) => {
    urls.push(url)
    return jsonResponse(OK)
  })
  try {
    const notifier = createNotifier(
      makeConfig({ webhookKeys: ['key-1', 'key-2', 'key-3'], minIntervalMs: 0 }),
      console,
      { sleep: noSleep },
    )
    const result = await notifier.push({ kind: 'custom', text: '群发' })
    assert.match(result, /3 个群/)
    await wait(20)
    assert.equal(m.calls(), 3)
    assert.ok(urls.every((u) => u.includes('qyapi.weixin.qq.com')))
    assert.ok(urls.some((u) => u.includes('key-1')))
    assert.ok(urls.some((u) => u.includes('key-3')))
  } finally {
    m.restore()
  }
})

test('notifier: updateConfig 热更新后按新配置发送', async () => {
  const m = mockFetch(async () => jsonResponse(OK))
  try {
    const notifier = createNotifier(makeConfig({ webhookKeys: ['old'] }), console, { sleep: noSleep })
    notifier.updateConfig(makeConfig({ webhookKeys: ['new-1', 'new-2'], minIntervalMs: 0 }))
    const result = await notifier.push({ kind: 'custom', text: 'hi' })
    assert.match(result, /2 个群/)
    assert.equal(notifier.getConfig().webhookKeys.length, 2)
    await wait(20)
    assert.equal(m.calls(), 2)
  } finally {
    m.restore()
  }
})

test('notifier: 发送失败只记日志不抛异常', async () => {
  const m = mockFetch(async () => jsonResponse({ errcode: 40013, errmsg: 'invalid key' }))
  const warns: string[] = []
  try {
    const notifier = createNotifier(makeConfig(), { warn: (msg) => warns.push(msg) }, { sleep: noSleep })
    await notifier.push({ kind: 'custom', text: 'hi' })
    await wait(20)
    assert.equal(m.calls(), 1)
    assert.ok(warns.some((w) => w.includes('发送失败')))
  } finally {
    m.restore()
  }
})

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}
