import { test } from 'node:test'
import assert from 'node:assert/strict'
import { sendWechat, sendWechatTargets, resolveWebhookUrl, describeTarget } from '../src/client.ts'

const OK = { errcode: 0, errmsg: 'ok' }
const noSleep = async () => {}

/** 覆盖全局 fetch，返回恢复函数 */
function mockFetch(handler: (url: string, init: RequestInit) => Promise<Response>): () => void {
  const original = globalThis.fetch
  globalThis.fetch = (async (url: unknown, init?: unknown) =>
    handler(String(url), (init ?? {}) as RequestInit)) as typeof fetch
  return () => {
    globalThis.fetch = original
  }
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

test('resolveWebhookUrl: key 拼成完整地址', () => {
  assert.equal(
    resolveWebhookUrl({ webhookUrl: null, webhookKey: 'abc' }),
    'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=abc',
  )
})

test('resolveWebhookUrl: 完整地址优先', () => {
  assert.equal(resolveWebhookUrl({ webhookUrl: 'https://x', webhookKey: 'abc' }), 'https://x')
})

test('resolveWebhookUrl: 未配置返回 null', () => {
  assert.equal(resolveWebhookUrl({ webhookUrl: null, webhookKey: null }), null)
})

test('sendWechat: 成功返回 ok，默认用 markdown', async () => {
  const restore = mockFetch(async (_url, init) => {
    const body = JSON.parse(String(init.body))
    assert.equal(body.msgtype, 'markdown')
    assert.equal(body.markdown.content, '你好')
    return jsonResponse(OK)
  })
  try {
    const r = await sendWechat({ webhookUrl: null, webhookKey: 'abc' }, '你好')
    assert.equal(r.ok, true)
  } finally {
    restore()
  }
})

test('sendWechat: 有 @ 目标时用 text + mentioned_list', async () => {
  const restore = mockFetch(async (_url, init) => {
    const body = JSON.parse(String(init.body))
    assert.equal(body.msgtype, 'text')
    assert.deepEqual(body.text.mentioned_list, ['zhangsan'])
    return jsonResponse(OK)
  })
  try {
    const r = await sendWechat({ webhookUrl: null, webhookKey: 'abc' }, 'hi', ['zhangsan'])
    assert.equal(r.ok, true)
  } finally {
    restore()
  }
})

test('sendWechat: 业务错误返回详情', async () => {
  const restore = mockFetch(async () => jsonResponse({ errcode: 40013, errmsg: 'invalid key' }))
  try {
    const r = await sendWechat({ webhookUrl: null, webhookKey: 'abc' }, 'x')
    assert.equal(r.ok, false)
    assert.match(r.detail, /40013/)
  } finally {
    restore()
  }
})

test('sendWechat: 93000 限频退避重试后成功', async () => {
  let calls = 0
  const restore = mockFetch(async () => {
    calls++
    if (calls === 1) return jsonResponse({ errcode: 93000, errmsg: 'freq' })
    return jsonResponse(OK)
  })
  try {
    const r = await sendWechat({ webhookUrl: null, webhookKey: 'abc' }, 'x', [], { maxRetry: 2, sleep: noSleep })
    assert.equal(r.ok, true)
    assert.ok(calls >= 2)
  } finally {
    restore()
  }
})

test('sendWechat: 未配置返回可读提示', async () => {
  const r = await sendWechat({ webhookUrl: null, webhookKey: null }, 'x')
  assert.equal(r.ok, false)
  assert.match(r.detail, /webhook key/i)
})

test('sendWechat: 网络错误按上限重试后失败', async () => {
  let calls = 0
  const restore = mockFetch(async () => {
    calls++
    throw new Error('ECONNRESET')
  })
  try {
    const r = await sendWechat({ webhookUrl: null, webhookKey: 'abc' }, 'x', [], { maxRetry: 2, sleep: noSleep })
    assert.equal(r.ok, false)
    assert.equal(calls, 3) // 初始 1 次 + 重试 2 次
    assert.match(r.detail, /网络失败/)
  } finally {
    restore()
  }
})

// ── 多目标发送 ──

test('sendWechatTargets: 空目标返回可读提示', async () => {
  const r = await sendWechatTargets([], 'x')
  assert.equal(r.ok, false)
  assert.match(r.detail, /webhook key/i)
})

test('sendWechatTargets: 全部成功时汇总', async () => {
  const restore = mockFetch(async () => jsonResponse(OK))
  try {
    const targets = [
      { webhookUrl: null, webhookKey: 'k1' },
      { webhookUrl: null, webhookKey: 'k2' },
    ]
    const r = await sendWechatTargets(targets, '群发')
    assert.equal(r.ok, true)
    assert.match(r.detail, /全部 2 个群/)
  } finally {
    restore()
  }
})

test('sendWechatTargets: 部分失败时逐目标报告', async () => {
  const restore = mockFetch(async (url) => {
    if (url.includes('k1')) return jsonResponse(OK)
    return jsonResponse({ errcode: 40013, errmsg: 'invalid key' })
  })
  try {
    const targets = [
      { webhookUrl: null, webhookKey: 'k1' },
      { webhookUrl: null, webhookKey: 'k2' },
      { webhookUrl: 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=k3', webhookKey: null },
    ]
    const r = await sendWechatTargets(targets, '群发')
    assert.equal(r.ok, true) // 至少一个成功
    assert.match(r.detail, /1\/3/)
    assert.match(r.detail, /key…k1/)
    assert.match(r.detail, /key…k2/)
    assert.match(r.detail, /40013/)
  } finally {
    restore()
  }
})

test('sendWechatTargets: 全失败时 ok=false', async () => {
  const restore = mockFetch(async () => jsonResponse({ errcode: 40013, errmsg: 'invalid key' }))
  try {
    const targets = [
      { webhookUrl: null, webhookKey: 'bad1' },
      { webhookUrl: null, webhookKey: 'bad2' },
    ]
    const r = await sendWechatTargets(targets, 'x')
    assert.equal(r.ok, false)
    assert.match(r.detail, /0\/2/)
  } finally {
    restore()
  }
})

test('describeTarget: key 脱敏只露后 4 位', () => {
  assert.equal(describeTarget({ webhookUrl: null, webhookKey: 'abcdef12' }), 'key…ef12')
  assert.equal(describeTarget({ webhookUrl: 'https://x/abc', webhookKey: null }), 'URL(…/abc)')
})
