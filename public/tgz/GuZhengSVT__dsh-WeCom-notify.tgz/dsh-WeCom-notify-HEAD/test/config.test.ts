import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtempSync, rmSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, dirname } from 'node:path'
import {
  loadConfig,
  Config,
  readStoredConfig,
  writeStoredConfig,
  applyStored,
  toStored,
  isConfigured,
  targetCount,
  configFilePath,
  userHomeDir,
  DEFAULT_MIN_INTERVAL_MS,
  DEFAULT_DEDUPE_WINDOW_MS,
  DEFAULT_MAX_BYTES,
  MAX_BYTES_CAP,
  type NotifyConfig,
} from '../src/config.ts'

test('loadConfig: 空 config 与空环境变量使用默认值', () => {
  const cfg = loadConfig({}, {})
  assert.deepEqual(cfg.webhookKeys, [])
  assert.equal(cfg.webhookUrl, null)
  assert.equal(cfg.mentionUserid, null)
  assert.equal(cfg.minIntervalMs, DEFAULT_MIN_INTERVAL_MS)
  assert.equal(cfg.dedupeWindowMs, DEFAULT_DEDUPE_WINDOW_MS)
  assert.equal(cfg.triggerOnAgentIdle, false)
  assert.equal(cfg.turnSummaryEnabled, true) // 每轮总结默认开
  assert.equal(cfg.maxBytes, DEFAULT_MAX_BYTES)
  assert.equal(isConfigured(cfg), false)
  assert.equal(targetCount(cfg), 0)
})

test('loadConfig: 环境变量覆盖默认值（含多 key 逗号分隔）', () => {
  const cfg = loadConfig({}, {
    WECHAT_WEBHOOK_KEYS: 'key-1, key-2;key-3',
    WECHAT_WEBHOOK_KEY: 'legacy-key',
    WECHAT_WEBHOOK_URL: 'https://example.com/send',
    WECHAT_MENTION_USERID: 'zhangsan',
    NOTIFY_MIN_INTERVAL_MS: '5000',
    NOTIFY_DEDUPE_WINDOW_MS: '60000',
    NOTIFY_TRIGGER_AGENT_IDLE: 'true',
    NOTIFY_TURN_SUMMARY: 'false',
  } as NodeJS.ProcessEnv)
  assert.deepEqual(cfg.webhookKeys, ['key-1', 'key-2', 'key-3', 'legacy-key'])
  assert.equal(cfg.webhookUrl, 'https://example.com/send')
  assert.equal(cfg.mentionUserid, 'zhangsan')
  assert.equal(cfg.minIntervalMs, 5000)
  assert.equal(cfg.dedupeWindowMs, 60000)
  assert.equal(cfg.triggerOnAgentIdle, true)
  assert.equal(cfg.turnSummaryEnabled, false)
  assert.equal(isConfigured(cfg), true)
  assert.equal(targetCount(cfg), 5) // 4 keys + 1 url
})

test('loadConfig: cordis.yml config 优先于环境变量，多 key 合并去重保序', () => {
  const cfg = loadConfig(
    {
      webhookKeys: ['config-key', 'shared'],
      minIntervalMs: 1234,
      turnSummaryEnabled: false,
    },
    {
      WECHAT_WEBHOOK_KEYS: 'env-key, shared',
      NOTIFY_MIN_INTERVAL_MS: '9999',
      NOTIFY_TURN_SUMMARY: 'true',
    } as NodeJS.ProcessEnv,
  )
  assert.deepEqual(cfg.webhookKeys, ['config-key', 'shared', 'env-key']) // config 在前，去重
  assert.equal(cfg.minIntervalMs, 1234)
  assert.equal(cfg.turnSummaryEnabled, false)
  // 未在 config 中声明的字段仍由环境变量提供
  assert.equal(cfg.webhookUrl, null)
  assert.equal(cfg.dedupeWindowMs, DEFAULT_DEDUPE_WINDOW_MS)
})

test('loadConfig: 旧版单 key（config.webhookKey / WECHAT_WEBHOOK_KEY）并入 webhookKeys', () => {
  // config 的 webhookKey 优先于 env 的 WECHAT_WEBHOOK_KEY（同一旧字段的两层）
  const cfg = loadConfig(
    { webhookKey: 'old-config-key' },
    { WECHAT_WEBHOOK_KEY: 'old-env-key' } as NodeJS.ProcessEnv,
  )
  assert.deepEqual(cfg.webhookKeys, ['old-config-key'])
  // 未在 config 声明时回退到 env
  const cfgEnv = loadConfig({}, { WECHAT_WEBHOOK_KEY: 'old-env-key' } as NodeJS.ProcessEnv)
  assert.deepEqual(cfgEnv.webhookKeys, ['old-env-key'])
})

test('loadConfig: 非法数字回退默认值', () => {
  const cfg = loadConfig({}, { NOTIFY_MIN_INTERVAL_MS: 'abc', NOTIFY_DEDUPE_WINDOW_MS: '-1' } as NodeJS.ProcessEnv)
  assert.equal(cfg.minIntervalMs, DEFAULT_MIN_INTERVAL_MS)
  assert.equal(cfg.dedupeWindowMs, DEFAULT_DEDUPE_WINDOW_MS)
})

test('loadConfig: NOTIFY_MAX_BYTES 生效且封顶 4096', () => {
  const small = loadConfig({}, { NOTIFY_MAX_BYTES: '1000' } as NodeJS.ProcessEnv)
  assert.equal(small.maxBytes, 1000)
  const capped = loadConfig({}, { NOTIFY_MAX_BYTES: '99999' } as NodeJS.ProcessEnv)
  assert.equal(capped.maxBytes, MAX_BYTES_CAP)
  const invalid = loadConfig({}, { NOTIFY_MAX_BYTES: 'abc' } as NodeJS.ProcessEnv)
  assert.equal(invalid.maxBytes, DEFAULT_MAX_BYTES)
})

test('Config: Schemastery schema 校验合法对象并透传字段（含数组）', () => {
  const value = Config({
    webhookKeys: ['k1', 'k2'],
    minIntervalMs: 5,
    triggerOnAgentIdle: true,
  })
  assert.deepEqual(value.webhookKeys, ['k1', 'k2'])
  assert.equal(value.minIntervalMs, 5)
  assert.equal(value.triggerOnAgentIdle, true)
})

test('Config: Schemastery schema 拒绝类型错误的字段', () => {
  assert.throws(() => Config({ minIntervalMs: '不是数字' } as unknown as Config))
  assert.throws(() => Config({ turnSummaryEnabled: 'yes' } as unknown as Config))
  assert.throws(() => Config({ webhookKeys: '不是数组' } as unknown as Config))
})

// ── 持久化文件层 ──

function makeTempHome(): string {
  return mkdtempSync(join(tmpdir(), 'wecom-notify-test-'))
}

function makeCfg(): NotifyConfig {
  return loadConfig({
    webhookKeys: ['a', 'b'],
    mentionUserid: 'u1',
    minIntervalMs: 5000,
    dedupeWindowMs: 60000,
    triggerOnAgentIdle: true,
    turnSummaryEnabled: false,
    maxBytes: 3000,
  })
}

test('writeStoredConfig/readStoredConfig: 往返一致且权限 0600', () => {
  const home = makeTempHome()
  try {
    const path = configFilePath(home)
    assert.ok(path.includes('wecom-notify'))
    writeStoredConfig(toStored(makeCfg()), path)
    const raw = JSON.parse(readFileSync(path, 'utf8'))
    assert.deepEqual(raw.webhookKeys, ['a', 'b'])
    assert.equal(raw.mentionUserid, 'u1')
    const stored = readStoredConfig(path)
    assert.ok(stored)
    assert.deepEqual(stored.webhookKeys, ['a', 'b'])
    assert.equal(stored.minIntervalMs, 5000)
  } finally {
    rmSync(home, { recursive: true, force: true })
  }
})

test('readStoredConfig: 文件不存在返回 null；损坏 JSON 返回 null', () => {
  const home = makeTempHome()
  try {
    assert.equal(readStoredConfig(configFilePath(home)), null)
  } finally {
    rmSync(home, { recursive: true, force: true })
  }
})

test('applyStored: 文件存在时字段整体覆盖（含空值 = 显式清空）', () => {
  const staticCfg = loadConfig({ webhookKeys: ['from-static'] })
  const stored = readStoredConfig(join(makeTempHome(), 'nope.json')) // null
  const noFile = applyStored(staticCfg, stored)
  assert.deepEqual(noFile.webhookKeys, ['from-static'])

  const withFile = applyStored(staticCfg, {
    webhookKeys: [],
    webhookUrl: null,
    mentionUserid: null,
    minIntervalMs: 111,
    dedupeWindowMs: 222,
    triggerOnAgentIdle: true,
    turnSummaryEnabled: false,
    maxBytes: 333,
  })
  assert.deepEqual(withFile.webhookKeys, []) // 文件里清空了就是清空
  assert.equal(withFile.minIntervalMs, 111)
  assert.equal(withFile.turnSummaryEnabled, false)
  assert.equal(isConfigured(withFile), false)
})

test('readStoredConfig: 容忍损坏/旧字段并回退默认', () => {
  const home = makeTempHome()
  try {
    const path = configFilePath(home)
    // 手写一个不完整文件
    mkdirSync(dirname(path), { recursive: true })
    writeFileSync(path, JSON.stringify({ webhookKeys: ['x', 42], minIntervalMs: 'abc' }))
    const stored = readStoredConfig(path)
    assert.ok(stored)
    assert.deepEqual(stored.webhookKeys, ['x']) // 非字符串被过滤
    assert.equal(stored.minIntervalMs, DEFAULT_MIN_INTERVAL_MS) // 非法数字回退
  } finally {
    rmSync(home, { recursive: true, force: true })
  }
})

test('userHomeDir: 尊重 DSH_HOME 覆盖', () => {
  assert.equal(userHomeDir({ DSH_HOME: '/tmp/x' } as NodeJS.ProcessEnv), '/tmp/x')
  assert.equal(userHomeDir({} as NodeJS.ProcessEnv).endsWith('.dsh'), true)
})
