import { test } from 'node:test'
import assert from 'node:assert/strict'
import { renderNotice, escapeMarkdown, truncateUtf8, formatTime } from '../src/templates.ts'

test('renderNotice: done 类型包含完成标题、目标与顶部时间行', () => {
  const out = renderNotice({ kind: 'done', objective: '写一份方案' })
  assert.match(out, /✅ dsh 任务完成/)
  assert.match(out, /目标：写一份方案/)
  assert.match(out, /dsh 自动通知/)
  // 时间行：> 🕐 YYYY-MM-DD HH:mm:ss
  assert.match(out, /> 🕐 \d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}/)
})

test('formatTime: 固定格式 YYYY-MM-DD HH:mm:ss', () => {
  const d = new Date(2025, 0, 15, 9, 5, 7) // 2025-01-15 09:05:07
  assert.equal(formatTime(d), '2025-01-15 09:05:07')
})

test('renderNotice: maxBytes 参数生效（超长截断）', () => {
  const longText = '很长'.repeat(200) // 600 字节
  const out = renderNotice({ kind: 'turn', text: longText }, 120)
  assert.ok(Buffer.byteLength(out, 'utf8') <= 120 + 64)
  assert.match(out, /…\[已截断\]/)
})

test('renderNotice: blocked 类型包含原因', () => {
  const out = renderNotice({ kind: 'blocked', objective: '部署服务', blockedReason: '端口被占用' })
  assert.match(out, /⛔ dsh 任务阻塞/)
  assert.match(out, /原因：端口被占用/)
})

test('renderNotice: custom 类型直接透传正文', () => {
  const out = renderNotice({ kind: 'custom', text: '进度汇报：已完成 80%' })
  assert.match(out, /进度汇报：已完成 80%/)
})

test('renderNotice: turn 类型（每轮总结）带对话完成标题与回复内容', () => {
  const out = renderNotice({ kind: 'turn', text: '本轮已完成：分析完毕，结论如下。' })
  assert.match(out, /📣 dsh 对话完成/)
  assert.match(out, /本轮已完成：分析完毕，结论如下。/)
})

test('escapeMarkdown: 转义 markdown 特殊字符', () => {
  assert.equal(escapeMarkdown('# 标题'), '\\# 标题')
  assert.equal(escapeMarkdown('a|b'), 'a\\|b')
  assert.equal(escapeMarkdown('**加粗**'), '\\*\\*加粗\\*\\*')
  assert.equal(escapeMarkdown('`代码`'), '\\`代码\\`')
})

test('truncateUtf8: 短文本不截断', () => {
  assert.equal(truncateUtf8('你好', 3800), '你好')
})

test('truncateUtf8: 按字节截断且码点完整', () => {
  // 每个中文字符 3 字节：10 个 = 30 字节，限 15 字节 → 截 5 个字符
  const out = truncateUtf8('一二三四五六七八九十', 15)
  assert.equal(out, '一二三四五\n…[已截断]')
  assert.ok(Buffer.byteLength(out, 'utf8') <= 15 + Buffer.byteLength('\n…[已截断]', 'utf8'))
})

test('truncateUtf8: 不截断代理对（emoji）', () => {
  const emoji = '👍'.repeat(20) // 每个 emoji 4 字节
  const out = truncateUtf8(emoji, 30) // 30 字节 → 7 个完整 emoji
  assert.equal(out, '👍'.repeat(7) + '\n…[已截断]')
})
