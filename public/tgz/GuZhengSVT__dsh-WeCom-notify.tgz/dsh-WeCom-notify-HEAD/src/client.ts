/**
 * 通道层：企业微信群机器人 webhook 客户端。
 * 核心入口 sendWechatTargets()：多目标（多个群）并发发送并汇总结果；
 * sendWechat() 单目标发送保留（测试 / 冒烟脚本用）。
 * 未来换 Server酱 / PushPlus / 钉钉 / 飞书时替换本文件即可。
 */
const WEBHOOK_BASE = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send'
const MAX_RETRY = 3
const TIMEOUT_MS = 10_000

export interface SendResult {
  ok: boolean
  detail: string
}

export interface WebhookTarget {
  webhookUrl: string | null
  webhookKey: string | null
}

export interface SendOptions {
  /** 重试次数上限（默认 3） */
  maxRetry?: number
  /** 退避 sleep（默认指数退避；测试可注入即时返回） */
  sleep?: (ms: number) => Promise<void>
}

/** 由单个目标解析出完整 webhook 地址；未配置返回 null。 */
export function resolveWebhookUrl(cfg: WebhookTarget): string | null {
  if (cfg.webhookUrl) return cfg.webhookUrl
  if (cfg.webhookKey) return `${WEBHOOK_BASE}?key=${cfg.webhookKey}`
  return null
}

/** 目标的可读标签（key 脱敏，只露后 4 位）。 */
export function describeTarget(target: WebhookTarget): string {
  if (target.webhookUrl) return `URL(…${mask(target.webhookUrl)})`
  if (target.webhookKey) return `key…${mask(target.webhookKey)}`
  return '(未配置)'
}

function mask(value: string): string {
  const v = value.trim()
  if (v.length <= 6) return v
  return v.slice(-4)
}

/**
 * 发送一条消息到单个企业微信群。
 * - 有 @ 目标时用 text + mentioned_list（@ 仅在 text 消息生效）
 * - 否则用 markdown（支持标题/加粗/引用）
 * - 网络异常与限频（errcode 93000）做指数退避重试
 */
export async function sendWechat(
  cfg: WebhookTarget,
  content: string,
  mentionUserids: string[] = [],
  opts: SendOptions = {},
): Promise<SendResult> {
  const maxRetry = opts.maxRetry ?? MAX_RETRY
  const sleepImpl = opts.sleep ?? sleep
  const url = resolveWebhookUrl(cfg)
  if (!url) {
    return {
      ok: false,
      detail: '未配置微信发送目标：请在 dsh 设置 → 企业微信通知 里填写 webhook key。',
    }
  }

  const payload = mentionUserids.length > 0
    ? { msgtype: 'text', text: { content, mentioned_list: mentionUserids } }
    : { msgtype: 'markdown', markdown: { content } }

  let attempt = 0
  for (;;) {
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: AbortSignal.timeout(TIMEOUT_MS),
      })
      const json = await res.json().catch(() => null)
      if (json && json.errcode === 0) return { ok: true, detail: 'ok' }
      // 频率限制：退避后重试
      if (json && json.errcode === 93000 && attempt < maxRetry) {
        await sleepImpl(1000 * 2 ** attempt)
        attempt++
        continue
      }
      const msg = json
        ? `errcode=${json.errcode} ${json.errmsg ?? ''}`
        : `HTTP ${res.status}`
      return { ok: false, detail: msg.trim() }
    } catch (error) {
      if (attempt >= maxRetry) {
        return { ok: false, detail: `网络失败（已重试 ${maxRetry} 次）：${String(error)}` }
      }
      await sleepImpl(1000 * 2 ** attempt)
      attempt++
    }
  }
}

/**
 * 多目标发送：同一内容并发发送到所有目标（各群独立限频，互不拖累）。
 * 返回汇总结果：全部成功 / 部分成功（逐目标详情）/ 全失败。
 */
export async function sendWechatTargets(
  targets: WebhookTarget[],
  content: string,
  mentionUserids: string[] = [],
  opts: SendOptions = {},
): Promise<SendResult> {
  if (targets.length === 0) {
    return {
      ok: false,
      detail: '未配置微信发送目标：请在 dsh 设置 → 企业微信通知 里填写 webhook key（可多个，同时通知）。',
    }
  }
  if (targets.length === 1) {
    return sendWechat(targets[0], content, mentionUserids, opts)
  }
  const settled = await Promise.allSettled(
    targets.map((target) => sendWechat(target, content, mentionUserids, opts)),
  )
  const okCount = settled.filter((r) => r.status === 'fulfilled' && r.value.ok).length
  if (okCount === settled.length) {
    return { ok: true, detail: `已发送到全部 ${settled.length} 个群` }
  }
  const details = settled.map((r, i) => {
    const label = describeTarget(targets[i])
    return r.status === 'fulfilled'
      ? `${label}: ${r.value.detail}`
      : `${label}: ${String(r.reason)}`
  })
  return {
    ok: okCount > 0,
    detail: `发送到 ${okCount}/${settled.length} 个群：${details.join('；')}`,
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
