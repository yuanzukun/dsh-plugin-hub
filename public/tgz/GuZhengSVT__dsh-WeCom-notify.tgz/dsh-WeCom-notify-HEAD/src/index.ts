/**
 * dsh-WeCom-notify 插件入口
 * - 事件驱动 1：订阅 session/event，每轮对话完成（turn/end）推送该轮总结
 * - 事件驱动 2：订阅 goal/changed（完成/阻塞）自动推送，不依赖 LLM 记得调用工具
 * - 工具兜底：wechat_notify 供 agent 主动汇报
 * - 设置面板：注册 webServer API（/wecom-notify/api），供 dsh 设置页「企业微信通知」
 *   面板读写配置（多 webhook key，同时通知多个群），保存即热生效并持久化。
 */
import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import {
  loadConfig,
  applyStored,
  toStored,
  isConfigured,
  readStoredConfig,
  writeStoredConfig,
  configFilePath,
  targetCount,
  type Config,
  type NotifyConfig,
} from './config.ts'
import { createNotifier } from './notifier.ts'
import { describeTarget, sendWechat } from './client.ts'
import type { WebhookTarget } from './client.ts'
import type { Notice } from './templates.ts'
import { formatTime } from './templates.ts'
import {
  assistantText,
  isAssistantMessage,
  isMainSession,
  isTurnEnd,
  type SessionEvent,
} from './extract.ts'

export const name = 'wechat-notify'
export const inject = ['tools', 'webServer']

/** 需要推送的 goal 操作：complete（完成）、block（阻塞）。 */
const RELEVANT_OPERATIONS = new Set(['complete', 'block'])

/** 设置面板 API 前缀（与 client 同源 fetch）。 */
const API_PREFIX = '/wecom-notify/api'

/** dsh 运行时向 Context 注入 webServer 服务（@deepseek-ai/dsh-host-webserver 声明合并的薄描述）。 */
declare module '@deepseek-ai/cordis' {
  interface Context {
    webServer: {
      register(options: {
        kind: 'prefix'
        path: string
        handler: (req: import('node:http').IncomingMessage, res: import('node:http').ServerResponse) => void | Promise<void>
      }): () => void
    }
  }
}

/**
 * goal/changed 事件 payload（docs 真源：@deepseek-ai/dsh-goal 的 GoalChanged）：
 * `(payload: { agent, change: { operation, ref, goal? } })`，agent 作用域广播，
 * 全局插件需 `{ global: true }` 才能收到。
 * 事件名类型由 @deepseek-ai/dsh-goal 声明合并提供；本项目不引该包，
 * 用结构类型自行约束并桥接 ctx.on 的 keyof Events 检查。
 */
interface GoalChangedPayload {
  agent: unknown
  change: {
    operation: string
    ref: unknown
    goal?: {
      objective?: string
      blockedReason?: string
    }
  }
}

/** agent/status 事件 payload：`(payload: { agent, status: 'idle' | 'running' })`。 */
interface AgentStatusPayload {
  agent: unknown
  status: string
}

interface SessionLike {
  header?: { parentSession?: string | null }
}

export function apply(ctx: Context, config: Config): void {
  // 配置加载：静态（cordis config + 环境变量）→ 合并设置面板持久化文件（文件优先）
  const staticCfg = loadConfig(config)
  let stored = readStoredConfig(configFilePath())
  let cfg: NotifyConfig = applyStored(staticCfg, stored)
  const notifier = createNotifier(cfg, ctx.logger)

  ctx.logger.info(
    `[wechat-notify] plugin loaded：${targetCount(cfg)} 个通知目标${isConfigured(cfg) ? '' : '（未配置 webhook key，通知将降级为日志提示——可在 dsh 设置 → 企业微信通知 里填写）'}`,
  )

  /** 保存配置：写持久化文件 + 热更新 notifier（无需重启）。 */
  function applyAndPersist(next: NotifyConfig): void {
    cfg = next
    notifier.updateConfig(next)
    writeStoredConfig(toStored(next))
  }

  // 主触发 1：每轮对话完成 → 推送该轮总结（默认开）
  // assistant/message 逐条缓存主会话的最新回复，turn/end（一轮结束）时推送并清缓存。
  const latestReply = new Map<object, string>()
  ctx.on(
    'session/event',
    (session: SessionLike, event: SessionEvent) => {
      try {
        if (!cfg.turnSummaryEnabled) return
        if (!isMainSession(session)) return // 跳过 subagent 会话
        if (isAssistantMessage(event)) {
          const text = assistantText(event)
          if (text) latestReply.set(session as object, text)
          return
        }
        if (isTurnEnd(event)) {
          const text = latestReply.get(session as object)
          latestReply.delete(session as object)
          if (text) {
            notifier.push({ kind: 'turn', text }).catch(() => {})
          }
        }
      } catch {
        /* 事件监听器永不抛异常 */
      }
    },
    { global: true },
  )

  // 主触发 2：goal 生命周期完成 / 阻塞 → 自动推送
  // 事件在 agent 作用域广播，全局插件必须 { global: true }；payload 是第一个参数。
  ctx.on('goal/changed' as any, (payload: GoalChangedPayload) => {
    const operation = payload?.change?.operation
    if (!operation || !RELEVANT_OPERATIONS.has(operation)) return
    const goal = payload.change.goal
    const notice: Notice = {
      kind: operation === 'block' ? 'blocked' : 'done',
      objective: goal?.objective,
      blockedReason: goal?.blockedReason,
    }
    notifier.push(notice).catch(() => {
      /* 事件监听器永不抛异常 */
    })
  }, { global: true })

  // 主触发 3：agent 一轮工作结束（默认关，防噪音）
  ctx.on('agent/status', (payload: AgentStatusPayload) => {
    if (cfg.triggerOnAgentIdle && payload?.status === 'idle') {
      notifier.push({ kind: 'idle' }).catch(() => {
        /* 事件监听器永不抛异常 */
      })
    }
  }, { global: true })

  // 辅触发：agent 主动汇报进度（保留工具，走同一调度器）
  ctx.tools.register(defineTool({
    name: 'wechat_notify',
    description: '通过企业微信群机器人给用户发一条通知（支持中文与 markdown；配置了多个 webhook key 时同时通知所有群）。',
    parameters: {
      message: {
        type: 'string',
        required: true,
        description: '通知正文（支持中文与 markdown）',
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args: unknown, value: string) => [{ type: 'text', text: value }],
    },
    async execute(args: { message?: string }) {
      const message = args?.message
      if (!message || !message.trim()) {
        return '微信通知发送失败：message 不能为空。'
      }
      return await notifier.push({ kind: 'custom', text: message })
    },
  }))

  // ── 设置面板 API（dsh 设置 → 企业微信通知）──
  // GET  /config  读取当前生效配置
  // POST /config  保存配置（写 <DSH_HOME>/wecom-notify/config.json + 热生效）
  // POST /test    发送测试消息（可用表单中的 key 覆盖，先测后存）
  ctx.effect(() => ctx.webServer.register({
    kind: 'prefix',
    path: API_PREFIX,
    handler: async (req: any, res: any) => {
      const send = (code: number, obj: unknown): void => {
        res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' })
        res.end(JSON.stringify(obj))
      }
      try {
        const url = new URL(req.url ?? '/', 'http://localhost')
        const path = url.pathname.replace(API_PREFIX, '') || '/'
        if (req.method === 'GET' && path === '/config') {
          return send(200, {
            ok: true,
            config: {
              webhookKeys: cfg.webhookKeys,
              webhookUrl: cfg.webhookUrl,
              mentionUserid: cfg.mentionUserid,
              minIntervalMs: cfg.minIntervalMs,
              dedupeWindowMs: cfg.dedupeWindowMs,
              triggerOnAgentIdle: cfg.triggerOnAgentIdle,
              turnSummaryEnabled: cfg.turnSummaryEnabled,
              maxBytes: cfg.maxBytes,
            },
            storagePath: configFilePath(),
            source: stored ? 'file' : 'static',
            targetCount: targetCount(cfg),
          })
        }
        if (req.method === 'POST' && path === '/config') {
          const body = JSON.parse(await readBody(req)) as Partial<NotifyConfig>
          const next: NotifyConfig = {
            webhookKeys: Array.isArray(body.webhookKeys)
              ? body.webhookKeys.filter((k): k is string => typeof k === 'string' && k.trim().length > 0)
              : cfg.webhookKeys,
            webhookUrl: typeof body.webhookUrl === 'string' && body.webhookUrl.trim()
              ? body.webhookUrl.trim()
              : (body.webhookUrl === null ? null : cfg.webhookUrl),
            mentionUserid: typeof body.mentionUserid === 'string' && body.mentionUserid.trim()
              ? body.mentionUserid.trim()
              : (body.mentionUserid === null ? null : cfg.mentionUserid),
            minIntervalMs: typeof body.minIntervalMs === 'number' && body.minIntervalMs > 0
              ? Math.round(body.minIntervalMs)
              : cfg.minIntervalMs,
            dedupeWindowMs: typeof body.dedupeWindowMs === 'number' && body.dedupeWindowMs > 0
              ? Math.round(body.dedupeWindowMs)
              : cfg.dedupeWindowMs,
            triggerOnAgentIdle: typeof body.triggerOnAgentIdle === 'boolean'
              ? body.triggerOnAgentIdle
              : cfg.triggerOnAgentIdle,
            turnSummaryEnabled: typeof body.turnSummaryEnabled === 'boolean'
              ? body.turnSummaryEnabled
              : cfg.turnSummaryEnabled,
            maxBytes: typeof body.maxBytes === 'number'
              ? Math.min(Math.max(Math.round(body.maxBytes), 100), 4096)
              : cfg.maxBytes,
          }
          applyAndPersist(next)
          stored = toStored(next) // 内存态与文件态一致（后续 GET 反映新值）
          ctx.logger.info(`[wechat-notify] 配置已更新：${targetCount(next)} 个通知目标（保存至 ${configFilePath()}）`)
          return send(200, { ok: true, config: next, storagePath: configFilePath() })
        }
        if (req.method === 'POST' && path === '/test') {
          const body = (await readBody(req).then((s) => (s ? JSON.parse(s) : {})).catch(() => ({}))) as {
            webhookKeys?: string[]
            webhookUrl?: string
            mentionUserid?: string
          }
          const testKeys = Array.isArray(body.webhookKeys)
            ? body.webhookKeys.filter((k): k is string => typeof k === 'string' && k.trim().length > 0)
            : cfg.webhookKeys
          const testUrl = typeof body.webhookUrl === 'string' && body.webhookUrl.trim()
            ? body.webhookUrl.trim()
            : cfg.webhookUrl
          const mention = typeof body.mentionUserid === 'string' && body.mentionUserid.trim()
            ? body.mentionUserid.trim()
            : cfg.mentionUserid
          const targets: WebhookTarget[] = [
            ...testKeys.map((key) => ({ webhookUrl: null, webhookKey: key })),
            ...(testUrl ? [{ webhookUrl: testUrl, webhookKey: null }] : []),
          ]
          if (targets.length === 0) {
            return send(400, { ok: false, error: '请至少填写一个 webhook key 再测试。' })
          }
          const content = `## ✅ 企业微信通知配置测试\n\n> 🕐 ${formatTime()}\n\n这是一条来自 dsh-WeCom-notify 的测试消息。\n如果你在群里看到它，说明配置已生效，通知链路已打通。`
          const settled = await Promise.allSettled(
            targets.map((t) => sendWechat(t, content, mention ? [mention] : [])),
          )
          const perTarget = settled.map((r, i) => ({
            label: describeTarget(targets[i]),
            ok: r.status === 'fulfilled' && r.value.ok,
            detail: r.status === 'fulfilled' ? r.value.detail : String(r.reason),
          }))
          const okCount = perTarget.filter((p) => p.ok).length
          return send(200, {
            ok: okCount > 0,
            detail: `测试消息发送到 ${okCount}/${perTarget.length} 个群`,
            perTarget,
          })
        }
        return send(404, { ok: false, error: 'not found: ' + path })
      } catch (e) {
        return send(500, { ok: false, error: String(e instanceof Error ? e.message : e) })
      }
    },
  }), 'wechat-notify: settings-api')
}

async function readBody(req: any): Promise<string> {
  const chunks: Buffer[] = []
  for await (const c of req) chunks.push(Buffer.from(c))
  return Buffer.concat(chunks).toString('utf8')
}
