/**
 * 配置层：设置面板持久化文件 > cordis.yml `config` > 环境变量 > 默认值。
 * - 设置面板保存的 `~/.dsh/wecom-notify/config.json` 是用户最近意愿，优先级最高；
 *   保存的是「完整生效快照」，面板中清空字段 = 显式清空（含空值覆盖静态配置）。
 * - 未保存过文件时回退到 cordis.yml config，再回退到环境变量与默认值。
 * - 零落盘承诺的例外：仅当用户在设置面板保存过配置才会写文件（含密钥，权限 0600）。
 */
import Schema from '@deepseek-ai/schemastery'
import { homedir } from 'node:os'
import { join, dirname } from 'node:path'
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs'

export interface NotifyConfig {
  /** 群机器人 webhook 的 key（URL 中的 key 参数）；可多个，同时通知所有群 */
  webhookKeys: string[]
  /** 附加的完整 webhook 地址（优先级独立的额外目标，兼容旧版） */
  webhookUrl: string | null
  /** 通知时 @ 的企业微信 userid（可选） */
  mentionUserid: string | null
  /** 两条通知的最小间隔（节流，毫秒） */
  minIntervalMs: number
  /** 相同内容去重窗口（毫秒） */
  dedupeWindowMs: number
  /** agent 空闲时是否也发通知（默认关，防噪音） */
  triggerOnAgentIdle: boolean
  /** 每轮对话完成时推送该轮总结（默认开） */
  turnSummaryEnabled: boolean
  /** 单条消息最大字节数（webhook 上限 4096，默认 3800；超长截断） */
  maxBytes: number
}

/** cordis.yml `config` 字段；全部可选，未填字段回退到环境变量 / 默认值。 */
export interface Config {
  /** 多个 webhook key（推荐） */
  webhookKeys?: string[]
  /** 单个 webhook key（旧版兼容，并入 webhookKeys） */
  webhookKey?: string
  /** 完整 webhook 地址（附加目标，旧版兼容） */
  webhookUrl?: string
  mentionUserid?: string
  minIntervalMs?: number
  dedupeWindowMs?: number
  triggerOnAgentIdle?: boolean
  turnSummaryEnabled?: boolean
  maxBytes?: number
}

export const Config: Schema<Config> = Schema.object({
  webhookKeys: Schema.array(Schema.string()),
  webhookKey: Schema.string(),
  webhookUrl: Schema.string(),
  mentionUserid: Schema.string(),
  minIntervalMs: Schema.number(),
  dedupeWindowMs: Schema.number(),
  triggerOnAgentIdle: Schema.boolean(),
  turnSummaryEnabled: Schema.boolean(),
  maxBytes: Schema.number(),
})

/** 设置面板持久化文件的磁盘形态（可 JSON 序列化）。 */
export interface StoredConfig {
  webhookKeys: string[]
  webhookUrl: string | null
  mentionUserid: string | null
  minIntervalMs: number
  dedupeWindowMs: number
  triggerOnAgentIdle: boolean
  turnSummaryEnabled: boolean
  maxBytes: number
}

export const DEFAULT_MIN_INTERVAL_MS = 10_000
export const DEFAULT_DEDUPE_WINDOW_MS = 30_000
export const DEFAULT_MAX_BYTES = 3800
export const MAX_BYTES_CAP = 4096

/** DSH 用户数据目录（尊重 DSH_HOME 覆盖，默认 ~/.dsh）。 */
export function userHomeDir(env: NodeJS.ProcessEnv = process.env): string {
  return env.DSH_HOME || join(homedir(), '.dsh')
}

/** 设置面板持久化文件路径：`<DSH_HOME>/wecom-notify/config.json`。 */
export function configFilePath(homeDir: string = userHomeDir()): string {
  return join(homeDir, 'wecom-notify', 'config.json')
}

/** 读取持久化配置；文件不存在或损坏返回 null（调用方降级为静态配置）。 */
export function readStoredConfig(path: string = configFilePath()): StoredConfig | null {
  try {
    const raw = readFileSync(path, 'utf8')
    const parsed = JSON.parse(raw) as Partial<StoredConfig>
    if (!parsed || typeof parsed !== 'object') return null
    return normalizeStored(parsed)
  } catch {
    return null
  }
}

/** 写入持久化配置（0600，含密钥；目录自动创建）。 */
export function writeStoredConfig(cfg: StoredConfig, path: string = configFilePath()): void {
  mkdirSync(dirname(path), { recursive: true })
  writeFileSync(path, JSON.stringify(cfg, null, 2) + '\n', { mode: 0o600 })
}

/** 容忍损坏/旧字段：逐字段回退到默认，webhookKeys 强转字符串数组。 */
function normalizeStored(raw: Partial<StoredConfig>): StoredConfig {
  return {
    webhookKeys: Array.isArray(raw.webhookKeys)
      ? raw.webhookKeys.filter((k): k is string => typeof k === 'string' && k.trim().length > 0)
      : [],
    webhookUrl: typeof raw.webhookUrl === 'string' && raw.webhookUrl.trim() ? raw.webhookUrl : null,
    mentionUserid: typeof raw.mentionUserid === 'string' && raw.mentionUserid.trim() ? raw.mentionUserid : null,
    minIntervalMs: toPositiveInt(String(raw.minIntervalMs ?? ''), DEFAULT_MIN_INTERVAL_MS),
    dedupeWindowMs: toPositiveInt(String(raw.dedupeWindowMs ?? ''), DEFAULT_DEDUPE_WINDOW_MS),
    triggerOnAgentIdle: Boolean(raw.triggerOnAgentIdle),
    turnSummaryEnabled: raw.turnSummaryEnabled !== false,
    maxBytes: Math.min(toPositiveInt(String(raw.maxBytes ?? ''), DEFAULT_MAX_BYTES), MAX_BYTES_CAP),
  }
}

/** 从静态配置（config + env）构造 StoredConfig 形态。 */
export function toStored(cfg: NotifyConfig): StoredConfig {
  return {
    webhookKeys: [...cfg.webhookKeys],
    webhookUrl: cfg.webhookUrl,
    mentionUserid: cfg.mentionUserid,
    minIntervalMs: cfg.minIntervalMs,
    dedupeWindowMs: cfg.dedupeWindowMs,
    triggerOnAgentIdle: cfg.triggerOnAgentIdle,
    turnSummaryEnabled: cfg.turnSummaryEnabled,
    maxBytes: cfg.maxBytes,
  }
}

/**
 * 合并持久化配置：文件存在时文件字段整体优先（含空值 = 用户显式清空）。
 * 文件不存在时原样返回静态配置。
 */
export function applyStored(cfg: NotifyConfig, stored: StoredConfig | null): NotifyConfig {
  if (!stored) return cfg
  return {
    webhookKeys: stored.webhookKeys,
    webhookUrl: stored.webhookUrl,
    mentionUserid: stored.mentionUserid,
    minIntervalMs: stored.minIntervalMs,
    dedupeWindowMs: stored.dedupeWindowMs,
    triggerOnAgentIdle: stored.triggerOnAgentIdle,
    turnSummaryEnabled: stored.turnSummaryEnabled,
    maxBytes: stored.maxBytes,
  }
}

function splitKeys(value: string | undefined): string[] {
  if (!value) return []
  return value
    .split(/[,，;\n]/)
    .map((s) => s.trim())
    .filter(Boolean)
}

/** 环境变量 / config 解析出完整生效配置（未合并持久化文件）。 */
export function loadConfig(config: Config = {}, env: NodeJS.ProcessEnv = process.env): NotifyConfig {
  const envKeys = splitKeys(env.WECHAT_WEBHOOK_KEYS)
  const cfgKeys = config.webhookKeys ?? []
  const legacyKey = config.webhookKey ?? (env.WECHAT_WEBHOOK_KEY || null)
  // 去重保序：config 声明优先，其次环境变量，其次旧版单 key
  const webhookKeys = [...new Set([...cfgKeys, ...envKeys, ...(legacyKey ? [legacyKey] : [])])]
  return {
    webhookKeys,
    webhookUrl: config.webhookUrl ?? (env.WECHAT_WEBHOOK_URL || null),
    mentionUserid: config.mentionUserid ?? (env.WECHAT_MENTION_USERID || null),
    minIntervalMs: config.minIntervalMs ?? toPositiveInt(env.NOTIFY_MIN_INTERVAL_MS, DEFAULT_MIN_INTERVAL_MS),
    dedupeWindowMs: config.dedupeWindowMs ?? toPositiveInt(env.NOTIFY_DEDUPE_WINDOW_MS, DEFAULT_DEDUPE_WINDOW_MS),
    triggerOnAgentIdle: config.triggerOnAgentIdle ?? toBoolean(env.NOTIFY_TRIGGER_AGENT_IDLE, false),
    turnSummaryEnabled: config.turnSummaryEnabled ?? toBoolean(env.NOTIFY_TURN_SUMMARY, true),
    maxBytes: Math.min(
      config.maxBytes ?? toPositiveInt(env.NOTIFY_MAX_BYTES, DEFAULT_MAX_BYTES),
      MAX_BYTES_CAP,
    ),
  }
}

/** 是否已配置可用通道（至少一个 key 或一个完整 URL）。 */
export function isConfigured(cfg: NotifyConfig): boolean {
  return cfg.webhookKeys.length > 0 || Boolean(cfg.webhookUrl)
}

/** 目标数量（多 key 每个算一个，附加 URL 算一个）。 */
export function targetCount(cfg: NotifyConfig): number {
  return cfg.webhookKeys.length + (cfg.webhookUrl ? 1 : 0)
}

function toPositiveInt(value: string | undefined, fallback: number): number {
  if (!value) return fallback
  const n = Number.parseInt(value, 10)
  return Number.isFinite(n) && n > 0 ? n : fallback
}

function toBoolean(value: string | undefined, fallback: boolean): boolean {
  if (value === '1' || value === 'true') return true
  if (value === '0' || value === 'false') return false
  return fallback
}
