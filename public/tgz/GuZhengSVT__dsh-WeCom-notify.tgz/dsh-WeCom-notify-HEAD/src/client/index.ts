/**
 * dsh-WeCom-notify 设置面板（dsh 设置 → 企业微信通知，settings.section 插槽）。
 * 功能：多个 webhook key 编辑（同时通知所有群）、@ 成员、节流/去重参数、
 *       「保存配置」（写 <DSH_HOME>/wecom-notify/config.json，host 热生效）、
 *       「发送测试」（用表单当前值先测后存，逐群显示结果）。
 * 通信：同源 fetch → host webServer API（/wecom-notify/api）。
 *
 * ⚠️ 组件形态（关键）：settings.section 的 component 必须是 React 组件，且作为
 * `slots.register(options, component)` 的**第二参数**传入（SlotRegistry 契约）。
 * 早期版本照抄 dsh-super-injector 的 `component: () => ({ render() {...} })` 写法——
 * 该写法 component 永远为 undefined，web-react renderer 渲染空白。本版本改为
 * React 组件外壳 + useEffect 挂载命令式 DOM（保留全部交互逻辑）。
 */
import { createElement, useEffect, useRef } from 'react'

/**
 * SlotsService 的结构类型（@deepseek-ai/dsh-client-runtime 的 SlotRegistry 运行
 * 时注入；此处按使用面自描述，避免依赖包类型版本漂移）。
 */
interface SlotsService {
  inject(key: string, callback: () => unknown): unknown
  register(options: {
    name: string
    id: string
    order?: number
    label?: string | (() => string)
  }, component: unknown): unknown
}

type ClientContext = {
  slots: SlotsService
  effect(fn: () => unknown, label?: string): unknown
}

export const inject = ['slots']

const API = '/wecom-notify/api'

function el(tag: string, cls?: string, text?: string): HTMLElement {
  const e = document.createElement(tag)
  if (cls) e.className = cls
  if (text !== void 0) e.textContent = text
  return e
}

function btn(tag: 'button', cls?: string, text?: string): HTMLButtonElement {
  return el(tag, cls, text) as HTMLButtonElement
}

const styles = `
.wn-page{font-family:ui-monospace,monospace;font-size:12px;line-height:1.6;padding:14px 16px;max-width:720px}
.wn-page h3{margin:0 0 6px;font-size:13px}
.wn-desc{color:var(--theme-text-secondary,#999);margin:0 0 12px;font-size:11px}
.wn-status{display:inline-block;font-size:10px;padding:2px 8px;border-radius:10px;margin-bottom:10px}
.wn-status.on{background:rgba(46,204,113,.15);color:#2ecc71}
.wn-status.off{background:rgba(255,193,7,.12);color:#f1c40f}
.wn-field{margin-bottom:10px}
.wn-label{display:block;font-size:11px;color:var(--theme-text-secondary,#999);margin-bottom:4px}
.wn-key-row{display:flex;gap:6px;margin-bottom:6px}
.wn-input{flex:1;background:var(--theme-input-bg,#111);color:var(--theme-text,#ddd);border:1px solid var(--theme-border,#333);border-radius:6px;padding:6px 8px;font-size:12px;font-family:ui-monospace,monospace}
.wn-input.small{max-width:130px}
.wn-btn{background:var(--theme-accent,#4a9eff);color:#fff;border:none;border-radius:6px;padding:6px 12px;cursor:pointer;font-size:12px;white-space:nowrap}
.wn-btn.ghost{background:transparent;border:1px solid var(--theme-border,#444);color:var(--theme-text,#ccc)}
.wn-btn.danger{background:transparent;border:1px solid #d33;color:#d33}
.wn-btn:disabled{opacity:.45;cursor:not-allowed}
.wn-add{margin-top:2px}
.wn-actions{display:flex;gap:8px;margin-top:14px}
.wn-msg{margin-top:10px;padding:8px 10px;border-radius:6px;background:var(--theme-input-bg,#111);border:1px solid var(--theme-border,#333);white-space:pre-wrap;max-height:200px;overflow:auto;font-size:11px}
.wn-msg.err{border-color:#d33}
.wn-details{margin-top:8px}
.wn-details summary{cursor:pointer;color:var(--theme-text-secondary,#999);font-size:11px}
.wn-advanced{padding:10px;border:1px solid var(--theme-border,#333);border-radius:8px;margin-top:8px}
.wn-check{display:flex;align-items:center;gap:6px;margin-bottom:8px;font-size:12px}
.wn-check input{accent-color:var(--theme-accent,#4a9eff)}
.wn-row{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.wn-row .wn-label{margin:0;min-width:120px}
.wn-per{font-size:11px;margin:2px 0;padding:4px 8px;border-radius:6px;background:var(--theme-input-bg,#111)}
.wn-per.ok{color:#2ecc71}
.wn-per.bad{color:#e74c3c}
`

interface ApiConfig {
  webhookKeys: string[]
  webhookUrl: string | null
  mentionUserid: string | null
  minIntervalMs: number
  dedupeWindowMs: number
  triggerOnAgentIdle: boolean
  turnSummaryEnabled: boolean
}

function fetchJson(path: string, init?: RequestInit): Promise<any> {
  return fetch(API + path, {
    headers: { 'content-type': 'application/json' },
    ...init,
  }).then((r) => r.json())
}

export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.slots.inject('settings.section', () =>
    ctx.slots.register({
      name: 'settings.section',
      id: 'wecom-notify',
      order: 40,
      label: () => '企业微信通知',
    }, WecomNotifyPanel),
  ), 'wecom-notify: settings page')
}

/** React 组件外壳：挂载命令式 DOM 面板；卸载时清理。 */
function WecomNotifyPanel() {
  const hostRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const root = hostRef.current
    if (!root) return
    const page = buildPage()
    root.appendChild(page)
    return () => {
      root.textContent = ''
    }
  }, [])
  return createElement('div', { ref: hostRef })
}

/** 命令式构建整个面板 DOM（含事件绑定与初次加载），返回页面根元素。 */
function buildPage(): HTMLElement {
  const style = document.createElement('style')
  style.textContent = styles

  const page = el('div', 'wn-page')
  const h = el('h3', undefined, '企业微信通知（dsh-WeCom-notify）')
  const desc = el('p', 'wn-desc',
    '在下方填写群机器人 webhook 的 key（企业微信群 → 群机器人 → 添加，复制 webhook 地址中的 key 参数）。' +
    '支持多个 key，通知会同时发送到所有群。保存后立即生效，无需重启。')
  const status = el('span', 'wn-status off')
  page.append(style, h, desc, status)

  // ── webhook keys ──
  const keysLabel = el('label', 'wn-label', 'Webhook Key（可多个，同时通知）')
  const keysBox = el('div')
  const keyRows: HTMLInputElement[] = []

  const addKeyRow = (value: string): void => {
    const row = el('div', 'wn-key-row')
    const input = el('input', 'wn-input') as HTMLInputElement
    input.placeholder = '如 8f6b-…-a1b2'
    input.value = value
    input.spellcheck = false
    const delBtn = btn('button', 'wn-btn danger', '删除')
    delBtn.addEventListener('click', () => {
      const idx = keyRows.indexOf(input)
      if (idx >= 0) keyRows.splice(idx, 1)
      row.remove()
    })
    keyRows.push(input)
    row.append(input, delBtn)
    keysBox.append(row)
  }

  const addBtn = btn('button', 'wn-btn ghost wn-add', '＋ 添加一个群')
  addBtn.addEventListener('click', () => addKeyRow(''))
  page.append(keysLabel, keysBox, addBtn)

  // ── 附加完整 URL（可选）──
  const urlLabel = el('label', 'wn-label', '附加完整 Webhook URL（可选，旧版兼容；与上面的 key 同时生效）')
  const urlInput = el('input', 'wn-input') as HTMLInputElement
  urlInput.placeholder = 'https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=…'
  page.append(urlLabel, urlInput)

  // ── @ 成员 ──
  const mentionLabel = el('label', 'wn-label', '@ 成员 userid（可选；企业微信管理后台通讯录可查）')
  const mentionInput = el('input', 'wn-input') as HTMLInputElement
  mentionInput.placeholder = '如 zhangsan'
  page.append(mentionLabel, mentionInput)

  // ── 高级参数 ──
  const details = el('details', 'wn-details')
  const summary = el('summary', undefined, '高级参数（节流 / 去重 / 推送开关）')
  const advanced = el('div', 'wn-advanced')
  const minIntervalInput = el('input', 'wn-input small') as HTMLInputElement
  const dedupeInput = el('input', 'wn-input small') as HTMLInputElement
  const turnOn = el('input') as HTMLInputElement
  turnOn.type = 'checkbox'
  const idleOn = el('input') as HTMLInputElement
  idleOn.type = 'checkbox'

  const fieldRow = (labelText: string, input: HTMLElement): HTMLElement => {
    const row = el('div', 'wn-row')
    const lbl = el('span', 'wn-label', labelText)
    row.append(lbl, input)
    return row
  }
  const checkRow = (labelText: string, input: HTMLInputElement): HTMLElement => {
    const row = el('div', 'wn-check')
    row.append(input, el('span', undefined, labelText))
    return row
  }
  advanced.append(
    fieldRow('节流间隔 ms', minIntervalInput),
    fieldRow('去重窗口 ms', dedupeInput),
    checkRow('每轮对话完成推送总结（默认开）', turnOn),
    checkRow('agent 空闲时也通知（默认关，防噪音）', idleOn),
  )
  details.append(summary, advanced)
  page.append(details)

  // ── 操作按钮 ──
  const actions = el('div', 'wn-actions')
  const saveBtn = btn('button', 'wn-btn', '保存配置')
  const testBtn = btn('button', 'wn-btn ghost', '发送测试消息')
  actions.append(saveBtn, testBtn)
  page.append(actions)

  const msg = el('div', 'wn-msg')
  msg.style.display = 'none'
  page.append(msg)

  const say = (text: string, isErr = false): void => {
    msg.textContent = text
    msg.style.display = text ? 'block' : 'none'
    msg.classList.toggle('err', isErr)
  }

  const currentKeys = (): string[] => keyRows.map((i) => i.value.trim()).filter(Boolean)

  const formConfig = (): ApiConfig => ({
    webhookKeys: currentKeys(),
    webhookUrl: urlInput.value.trim() || null,
    mentionUserid: mentionInput.value.trim() || null,
    minIntervalMs: Number.parseInt(minIntervalInput.value, 10) || 10000,
    dedupeWindowMs: Number.parseInt(dedupeInput.value, 10) || 30000,
    triggerOnAgentIdle: idleOn.checked,
    turnSummaryEnabled: turnOn.checked,
  })

  const fillForm = (c: ApiConfig): void => {
    keyRows.length = 0
    keysBox.textContent = ''
    const keys = c.webhookKeys?.length ? c.webhookKeys : ['']
    for (const k of keys) addKeyRow(k)
    urlInput.value = c.webhookUrl ?? ''
    mentionInput.value = c.mentionUserid ?? ''
    minIntervalInput.value = String(c.minIntervalMs)
    dedupeInput.value = String(c.dedupeWindowMs)
    turnOn.checked = c.turnSummaryEnabled
    idleOn.checked = c.triggerOnAgentIdle
  }

  const refresh = (): void => {
    fetchJson('/config')
      .then((d) => {
        if (!d?.ok) return say(JSON.stringify(d), true)
        const c = d.config as ApiConfig
        fillForm(c)
        const n = d.targetCount ?? (c.webhookKeys?.length ?? 0) + (c.webhookUrl ? 1 : 0)
        status.textContent = n > 0 ? `已配置 ${n} 个通知目标（${d.source === 'file' ? '设置面板保存' : '静态配置'}）` : '未配置 webhook key'
        status.className = 'wn-status ' + (n > 0 ? 'on' : 'off')
        say('')
      })
      .catch((err) => say('加载配置失败: ' + err, true))
  }

  const doSave = (): void => {
    saveBtn.disabled = true
    saveBtn.textContent = '保存中…'
    fetchJson('/config', { method: 'POST', body: JSON.stringify(formConfig()) })
      .then((r) => {
        if (!r?.ok) return say(JSON.stringify(r), true)
        const n = r.config?.webhookKeys?.length ?? 0
        status.textContent = n > 0 ? `已配置 ${n} 个通知目标（设置面板保存）` : '未配置 webhook key'
        status.className = 'wn-status ' + (n > 0 ? 'on' : 'off')
        say('✅ 配置已保存并立即生效。')
      })
      .catch((err) => say('保存失败: ' + err, true))
      .finally(() => { saveBtn.disabled = false; saveBtn.textContent = '保存配置' })
  }

  const doTest = (): void => {
    testBtn.disabled = true
    testBtn.textContent = '发送中…'
    say('')
    const c = formConfig()
    fetchJson('/test', { method: 'POST', body: JSON.stringify(c) })
      .then((r) => {
        if (!r?.ok && !r?.perTarget) return say(JSON.stringify(r), true)
        const lines = [`${r.detail}`]
        for (const p of (r.perTarget ?? []) as Array<{ label: string; ok: boolean; detail: string }>) {
          lines.push(`  ${p.ok ? '✅' : '❌'} ${p.label} — ${p.detail}`)
        }
        say(lines.join('\n'), !r?.ok)
      })
      .catch((err) => say('测试请求失败: ' + err, true))
      .finally(() => { testBtn.disabled = false; testBtn.textContent = '发送测试消息' })
  }

  saveBtn.addEventListener('click', doSave)
  testBtn.addEventListener('click', doTest)
  refresh()

  return page
}
