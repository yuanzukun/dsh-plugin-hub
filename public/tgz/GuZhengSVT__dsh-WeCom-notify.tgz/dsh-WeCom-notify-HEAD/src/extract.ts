/**
 * 从 session/event 事件流中提取「每轮对话总结」所需的纯函数。
 * 事件结构（dsh-session 广播，判别联合）：
 *   - assistant/message: { type, data: { message: { role, content: [{ type: 'text', text } | { type: 'tool-call', ... }] } } }
 *   - turn/end:          { type, data: { turn, reason } }
 * data 在监听器层放宽为 unknown（不同事件分支结构不同），读取处再收窄。
 * 主会话识别：session.header.parentSession 为空（subagent 会话会指向父会话）。
 */

export interface SessionLike {
  header?: {
    parentSession?: string | null
  }
}

export interface SessionEvent {
  type: string
  data?: unknown
}

/** 主会话（无父会话）才推送，subagent 会话跳过。 */
export function isMainSession(session: SessionLike): boolean {
  return !session?.header?.parentSession
}

export function isAssistantMessage(event: SessionEvent): boolean {
  return event.type === 'assistant/message'
}

export function isTurnEnd(event: SessionEvent): boolean {
  return event.type === 'turn/end'
}

/**
 * 从 assistant/message 事件提取文本块拼接；
 * 该消息没有文本（如纯工具调用）时返回 null。
 */
export function assistantText(event: SessionEvent): string | null {
  const data = event.data as { message?: { content?: unknown[] } } | undefined
  const message = data?.message
  if (!message || !Array.isArray(message.content)) return null
  const parts: string[] = []
  for (const block of message.content) {
    if (
      block !== null &&
      typeof block === 'object' &&
      (block as { type?: string }).type === 'text' &&
      typeof (block as { text?: unknown }).text === 'string'
    ) {
      const text = (block as { text: string }).text.trim()
      if (text) parts.push(text)
    }
  }
  const joined = parts.join('\n\n').trim()
  return joined || null
}
