/**
 * 模板层：消息渲染、markdown 转义、UTF-8 截断。
 * 安全要点：objective/blockedReason 可能来自被注入的上下文，统一转义，防止格式破坏与伪造。
 */
export type NoticeKind = 'done' | 'blocked' | 'idle' | 'turn' | 'custom'

export interface Notice {
  kind: NoticeKind
  objective?: string
  blockedReason?: string
  /** custom / turn 类型时的正文 */
  text?: string
}

/** 企业微信 markdown 消息体上限 4096 字节，默认留余量 */
export const DEFAULT_MAX_BYTES = 3800

/** 时间格式：2025-01-15 14:32:05 */
export function formatTime(now: Date = new Date()): string {
  const pad = (x: number) => String(x).padStart(2, '0')
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`
}

export function renderNotice(n: Notice, maxBytes: number = DEFAULT_MAX_BYTES): string {
  const head = headOf(n.kind)
  const body = n.kind === 'custom' || n.kind === 'turn'
    ? n.text ?? ''
    : `> 目标：${escapeMarkdown(n.objective ?? '(无)')}${n.blockedReason ? `\n> 原因：${escapeMarkdown(n.blockedReason)}` : ''}`
  const ts = formatTime()
  // 时间行放正文顶部，醒目；脚注保留来源标记
  return truncateUtf8(`## ${head}\n\n> 🕐 ${ts}\n\n${body}\n\n—— dsh 自动通知`, maxBytes)
}

function headOf(kind: NoticeKind): string {
  switch (kind) {
    case 'done': return '✅ dsh 任务完成'
    case 'blocked': return '⛔ dsh 任务阻塞'
    case 'turn': return '📣 dsh 对话完成'
    default: return '📣 dsh 通知'
  }
}

const MARKDOWN_SPECIAL = /[\\`*_\[\]{}()#+.!>|-]/g

/** 转义 markdown 特殊字符，防止外部文本破坏格式或注入伪造消息。 */
export function escapeMarkdown(input: string): string {
  return input.replace(MARKDOWN_SPECIAL, '\\$&')
}

/** 按 UTF-8 字节数截断（按码点切，不截断代理对），超长加省略标记。 */
export function truncateUtf8(input: string, maxBytes: number): string {
  if (Buffer.byteLength(input, 'utf8') <= maxBytes) return input
  const chars = [...input]
  let bytes = 0
  let index = 0
  for (const ch of chars) {
    const len = Buffer.byteLength(ch, 'utf8')
    if (bytes + len > maxBytes) break
    bytes += len
    index += 1
  }
  return `${chars.slice(0, index).join('')}\n…[已截断]`
}
