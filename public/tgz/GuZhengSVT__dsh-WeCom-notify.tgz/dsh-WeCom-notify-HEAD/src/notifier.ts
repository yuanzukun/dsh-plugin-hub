/**
 * 调度层：串行队列 + 节流 + 去重 + 多目标并发发送。
 * 异步非阻塞：全程不阻塞事件循环（对比原方案 execFileSync）。
 * 节流在 drain 中强制生效：即使多条消息同时入队，也会按 minIntervalMs 间隔逐个发送。
 * 配置热更新：设置面板保存后通过 updateConfig() 替换生效配置，无需重启。
 */
import { createHash } from 'node:crypto'
import type { NotifyConfig } from './config.ts'
import { sendWechatTargets } from './client.ts'
import type { WebhookTarget } from './client.ts'
import type { Notice } from './templates.ts'
import { renderNotice } from './templates.ts'

export interface Notifier {
  /** 提交一条通知；返回给调用方的可读结果（工具输出 / 调试用）。 */
  push(notice: Notice): Promise<string>
  /** 热更新生效配置（设置面板保存后调用；立即作用于后续通知）。 */
  updateConfig(cfg: NotifyConfig): void
  /** 当前生效配置（只读引用）。 */
  getConfig(): NotifyConfig
}

interface LoggerLike {
  warn(message: string): void
}

export interface NotifierOptions {
  /** 节流等待的实现；测试可注入即时返回以加速。 */
  sleep?: (ms: number) => Promise<void>
}

/** 多目标并发发送的提取点：notifier 持有当前配置，导出 targets。 */
export function targetsOf(cfg: NotifyConfig): WebhookTarget[] {
  const targets: WebhookTarget[] = cfg.webhookKeys.map((key) => ({ webhookUrl: null, webhookKey: key }))
  if (cfg.webhookUrl) targets.push({ webhookUrl: cfg.webhookUrl, webhookKey: null })
  return targets
}

export function createNotifier(
  cfg: NotifyConfig,
  logger: LoggerLike = console,
  opts: NotifierOptions = {},
): Notifier {
  const sleepImpl = opts.sleep ?? sleep
  const queue: Notice[] = []
  const lastSentAt = new Map<string, number>()
  let inFlight = false
  let nextAllowedAt = 0
  // 可变引用：updateConfig 整体替换，push 读取时取当前
  let current = cfg

  async function push(notice: Notice): Promise<string> {
    const cfgNow = current
    const targets = targetsOf(cfgNow)
    if (targets.length === 0) {
      return '微信通知未发送：未配置 webhook key——请在 dsh 设置 → 企业微信通知 里填写（可多个，同时通知）。'
    }
    const content = renderNotice(notice, cfgNow.maxBytes)
    const key = hash(content)
    const now = Date.now()

    // 去重：相同内容在窗口内只发一次
    const previous = lastSentAt.get(key) ?? 0
    if (now - previous < cfgNow.dedupeWindowMs) {
      return '已去重：相同通知在去重窗口内已发送，未重复推送。'
    }
    lastSentAt.set(key, now)

    // 节流：当前在窗口内或队列非空 → 排队；实际发送间隔由 drain 统一保证
    const willQueue = now < nextAllowedAt || queue.length > 0
    queue.push(notice)
    void drain()
    return willQueue
      ? `微信通知已排队（触发节流，稍后发送到 ${targets.length} 个群）。`
      : `微信通知已受理（发送到 ${targets.length} 个群）。`
  }

  /** 串行取队首发送；同一时刻只有一个批次在途；每条发送前强制等待节流间隔。 */
  async function drain(): Promise<void> {
    if (inFlight) return
    inFlight = true
    try {
      while (queue.length > 0) {
        const cfgNow = current
        const waitMs = nextAllowedAt - Date.now()
        if (waitMs > 0) await sleepImpl(waitMs)
        const notice = queue.shift()!
        // 发送前锁定下一次允许时间，避免并发 push 在竞态窗口内绕过节流
        nextAllowedAt = Date.now() + cfgNow.minIntervalMs
        const content = renderNotice(notice, cfgNow.maxBytes)
        const mention = cfgNow.mentionUserid ? [cfgNow.mentionUserid] : []
        const result = await sendWechatTargets(targetsOf(cfgNow), content, mention)
        if (!result.ok) {
          logger.warn(`[wechat-notify] 发送失败：${result.detail}`)
        }
      }
    } finally {
      inFlight = false
    }
  }

  return {
    push,
    updateConfig(cfgNext: NotifyConfig) {
      current = cfgNext
    },
    getConfig() {
      return current
    },
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}

function hash(input: string): string {
  return createHash('sha256').update(input, 'utf8').digest('hex')
}
