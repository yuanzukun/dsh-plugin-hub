# Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 格式，版本号遵循 [Semantic Versioning](https://semver.org/zh-CN/)。

## v0.9.1 — 2026-11-06

### Fixed
- **Antigravity 请求身份对齐**：`requestId` 改为 `agent-<token>` 前缀；`sessionId` 按首条用户消息 SHA-256 生成 Antigravity 风格的负整数（有 DSH sessionId 时作为兜底）；`User-Agent` 改为 `antigravity/hub/<version> os/arch`，不再固定旧的 `antigravity/1.15.8`。
- **无 project 账号自动 onboard**：`loadCodeAssist` 没返回 project 时，按 `defaultTier` 调用 `onboardUser` 创建（带 Antigravity `ide_version` / `ide_name` 与 onboarding headers），不再直接用本地生成的稳定 UUID。
- **按具体模型额度调度**：`quotaFractionForAccount(account, category, modelId)` 优先读该模型 `catalogModels[].remainingFraction` / `quota.models[].remainingFraction`，再回退账号组 5h/weekly，避免 Gemini 4 Argon 等独立额度被普通 Gemini 组覆盖。
- **模型目录收敛**：隐藏 Antigravity 不提供给聊天选择器的 `gemini-2.5-pro` / `gemini-2.5-flash-thinking`（对齐 magpie `antigravityHidden`）；无实时目录时改用 6 个保守 fallback 模型；被 Google 400 拒绝的 tier 缓存 24 小时，避免每次刷新先撞 400。

### 验证
- `npm run check` 119/119（新增 onboarding 1 项、模型额度 1 项、隐藏模型 1 项、请求信封身份 1 项；原 115 项全保留）。
- `onboardUser` 单测覆盖 loadCodeAssist → listCloudAICompanionProjects → onboardUser 的完整路径。
- 请求信封单测断言 `requestId` 前缀 `agent-`、`sessionId` 为 `-<数字>`、`User-Agent` 为 `antigravity/hub/...`。

## v0.9.0 — 2026-11-06

### Fixed
- **设置页把账号没有的模型标成可用（#15、#16）**：`parseCatalogModels()` 此前遍历静态 `MODELS` 时无条件写 `available: true`，并在没有匹配行时拿任意一条 Gemini 额度当兜底；`publicModelMatchNeedles()` 还把 3.8 的匹配词硬绑到 3.7。现在模型目录只从该账号真实的 `fetchAvailableModels` 结果生成：`disabled`、`chat_*`、`tab_*` 与内部模型直接剔除；一个模型族只有至少列出一个可用 variant 才出现；3.8/3.7 不再互相别名。设置页对遗留目录里不可用的模型置灰并标注「当前账号不可用」，不再诱导用户选中后 404。
- **模型目录被单个账号覆盖**：以前每次额度刷新都把一个账号的 `catalogModels` 写进全局设置，后刷新的账号会覆盖前一个账号的模型。现在 `syncModelCatalogFromPool()` 对所有账号取并集，并保留每个账号自己的 runtime variant 映射；请求调度前按账号目录过滤，避免把某账号没有的模型发给它。
- **自动均衡退化为单账号硬抗（#14）**：`getCandidateAccounts()` 读的是 `groups[].limits[]`，而 `parseQuotaSummary()` 写入的是 `groups[].buckets[]`，导致每个账号的额度权重恒为 1.0、永远先打主账号直到 429。现在按 `buckets[].window`（5h → weekly → 最小值）计算权重，并用平滑加权轮询把请求前置分散到多个账号；429 只作为兜底。
- **DSH 0.2.2 图像预算契约**：0.2.2 移除了 `offloadRequestImagesWithPolicy`。插件改为在存在 `requiredImageOffload` / `projectOffloadedImages` 时自行计算历史图片预算并在超限时抛 `IMAGE_OFFLOAD_REQUIRED`（带 `offloadImages`），由宿主 `dsh-compaction-image-offload` 持久化 offload；旧版宿主继续走原 helper。
- **Cordis 4.1 事件表空键语义**：`isVisionBridgeHookLive()` 在 cordis 4.1 删除最后一个监听器后把 `_hooks[event] === undefined` 误报为「总线不可读」。现在可读的空表返回 `false`，只有无法读取的布局才返回 `undefined`。

### Added
- **Gemini 4 Argon 动态接入（#17）**：模型目录按 Antigravity 实时返回的 id 自动折叠新模型族，`gemini-4-argon-low/medium/high` 会合并为一个 `gemini-4-argon`（名字、上下文、输出上限、图片能力均取服务端值）；`gemini-4-argon-disabled` 等 `disabled: true` 条目不会出现。无需再改静态表。
- **多账号额度查看下拉（#14）**：设置页账号卡片区新增账号下拉，可只看单个账号的额度/重置时间/状态；多账号默认仍展示全部卡片。
- **Tier entitlement 探测**：`fetchAvailableModels` 会先带 `entitlement.userTier`（paid tier → current tier）再回退到不带 tier 的请求，避免付费账号的模型列表被无 tier 请求截窄（Gemini 4 Argon 的典型症状）。
- **模型族折叠与多账号并集测试**、**平滑加权调度测试**：新增 `test/catalog.test.mjs` 6 项与 `test/pool-scheduling.test.mjs` 4 项。

### Changed
- **DSH 兼容基线升级到 0.2.2-rc.1**：devDependencies 从 0.1.7-rc.2 全部升到 0.2.2-rc.1，`engines.dsh` 改为 `>=0.2.0-rc.2 <0.3.0`，`engines.node` 改为 `>=24.9`（与 0.2.2 的最低 Node 要求一致）。
- **Antigravity endpoint 列表**新增 `https://daily-cloudcode-pa.googleapis.com`（Antigravity 客户端实际使用的 daily 通道），保留旧 sandbox host 作最后回退。
- **Gemini 3/4 文本模型统一发送 `thinkingLevel`**：此前只有 3.8/3.7 tiered id 设置 `thinkingConfig`，带工具时新模型可能几乎不思考；现在按 effort 映射 low/medium/high，图片模型不发送。

### 文档
- README 中英新增 v0.9.0 重点、兼容性矩阵与 v0.8.x 升级说明；架构图更新为 `agent/pre-step` 视觉旁路 + 实时模型目录 + 加权调度；`SECURITY.md` 增加支持版本表。

### 验证
- `npm run check` 115/115（原 103 项全保留 + catalog 6 项 + scheduling 4 项 + 设置页多账号/不可用模型渲染 2 项）。
- 用 magpie 的真实 `antigravity-models-2026-10-20.json` 夹具跑目录生成：输出仅包含该账号实际拥有的 `gemini-3.8-flash` 家族、`gemini-3.5-flash`、`gemini-3.1-flash-image` 等，不再出现 3.7/3.8 的虚假条目；`gemini-4-argon-*` 在单独注入时可正确折叠。
- 在隔离 `gemini-smoke` profile（web 模板）安装本插件并启动 DSH 0.2.2-rc.1：插件加载无异常，`/antigravity/api/status` 鉴权后返回 200，`/antigravity/api/doctor` 未鉴权返回 401（路由与准入栅栏均在）。

## v0.8.2 — 2026-10-05

### Fixed
- **DSH Desktop 用户代理不生效，登录永远拿不到账号（#12，PR #13）**：宿主只在启动时从 harness home 的 `.env` 读取 `HTTP_PROXY` / `HTTPS_PROXY` / `ALL_PROXY` / `NO_PROXY`（这几个名字写在其它任何 `.env` 里都会被宿主拒绝），而 DSH Desktop 的 harness home 不是 `~/.dsh`——Windows 在 `%APPDATA%\dsh-desktop\harness`，macOS 在 `~/Library/Application Support/dsh-desktop/harness`。README 此前只写抽象的 `$DSH_HOME`，桌面用户把代理写进 `~/.dsh/.env` 完全不生效：浏览器授权成功，换 token 阶段直连超时（`UND_ERR_CONNECT_TIMEOUT`，约 10.6 s），账号不落盘。现 README（中英同步）新增「🧱 网络环境（需要代理时）」一节：给出 CLI 与桌面版两种安装方式的实际 `.env` 路径、「写完必须完全退出并重启 DSH」的提醒与自检方法（直连 vs 走代理各请求一次 token 端点，走通返回 400）；「账号池与调度」小节同步标注桌面版凭证存储路径
- 换 token 的三处 `fetch(TOKEN_URL)`（`loginAntigravity` / `exchangeOAuthCode` / `refreshAntigravityToken`）封装为 `requestToken()`：传输层失败（`ENOTFOUND` / `ECONNREFUSED` / `ETIMEDOUT` / `UND_ERR_CONNECT_TIMEOUT` / `UND_ERR_SOCKET` / `fetch failed` 等 9 个标记，取 `error.cause.code ?? error.code` 加 message 匹配）时，错误信息直接附上「疑似需要代理 + `.env` 该放哪」的自查指引（`proxyRemedy()`），不再以裸 `TypeError` 冒出。HTTP 层错误（`!response.ok`）的既有文案与行为不变；`refreshAntigravityToken` 的 30 s `AbortController` 透传语义不变——abort 归入非网络分支并保留 `cause`，不会误报「需要代理」

### 验证
- `npm run check` 103/103（v0.8.1 基线 98 项全保留 + 新增 `test/token-transport.test.mjs` 5 项：remedy 路径格式、不可达标记识别与 enrichment、非网络错误不带代理指引、fetch mock 成功响应透传与传输失败 enrich 两路）
- fork PR 的 workflow 因首次贡献需维护者批准未自动触发，已按 CI 同款步骤（`npm install --no-audit --no-fund` + `npm run check`）本地复跑替代；根因与三组运行时实测（直连 10753 ms 超时 → 系统代理 400/722 ms → 桌面自带运行时与真实 `loadLayeredEnv()` 路径 400/1213 ms）见 issue #12

## v0.8.1 — 2026-10-05

### Security
- **`/antigravity/api` 前缀接入宿主准入栅栏**：此前插件全部 web 路由（status / doctor / quota / login / logout / accounts\* / config / models）在 dispatcher 层无鉴权——宿主组合层的既有姿态是「鉴权属各路由 owner」，而本插件从未认领。现路由 handler 开头调用宿主 `connection.admit(request)`（与宿主自有 `/api` 通道和 WebSocket 升级同一原语）：Host/Origin 信任检查不过返回 403、无 DSH 浏览器会话返回 401，拒绝发生在任何路由逻辑之前（池状态、凭证、doctor 输出均不可达）。设置页卡片与已登录浏览器同源携带会话 cookie，不受影响；Google 登录的 OAuth 回调走独立本地端口（`ANTIGRAVITY_CALLBACK_PORT`），与栅栏无关。注入声明由 `["webServer"]` 改为 `["webServer", "connection"]`

### Fixed
- **自动看图桥接改写蒸发，模型始终收到占位文本（Refs #7，断点⑤）**：桥原挂在宿主 `llm/stream` 事件，监听器把改写后的消息作为 `next()` 参数传递；而 cordis waterfall 的 `next` 是零参闭包（监听器传入的参数被静默丢弃），`llm/stream` 内建又闭包捕获原始请求、忽略一切调用参数——改写从未到达 provider。日志层 `rewrote` 行照常出现，成为假阳性；历史「隔离环境正常」实为 `antigravity_read_image` 工具回退被误归因。修复：桥迁至 `agent/pre-step`（沿用宿主 `installModelSelection` 的「`await next()` 后改写、返回新 decision」模式，宿主消费返回值并随会话持久化）。`isEnabled` / `isTextOnlyModel` 门、池转述调用、进程内缓存、fail-open、决策链日志语义全部保留；`antigravity_read_image` 工具路径不变。覆盖边界：贴图（本步新输入）走桥；工具结果图片块（如宿主 `read_image` 返回）不经桥，保持占位文本加工具回退
- `/antigravity-doctor` 的 `visionBridge` 行改为读取时实时探测事件总线：`registered`＝桥此刻在线；新增 `dropped`＝注册成功后已从总线消失（issue #7 故障签名），重启宿主或重载插件可恢复；总线布局不可读（宿主漂移）时回退注册簿记值，不误报
- README 排障段措辞修正：doctor 返回的 vision 状态是三行（含 `visionEnabled`），原文「查看两行」已改为「vision 三行」（中英同步）

### Added
- **对话命令真实注册（兑现 README 命令表）**：`/antigravity-login`、`/antigravity-quota`、`/antigravity-doctor`、`/antigravity-logout` 此前只是文档承诺——宿主 `commands` 注册表里从未挂载（与 PR #9 补齐的 doctor 路由同类的文档-代码缺口）。现经宿主 `commands` 服务真实注册，handler 复用 web API 路由的同款进程内函数（单一代码路径，无 HTTP 往返）：login 返回授权链接、quota 刷新并按账号列额度、doctor 返回自检全文、logout 须显式带 `confirm` 参数（防误触移除全部凭证）。宿主未提供 `commands` 服务时优雅降级：不注册、不影响插件加载，web API 与 `antigravity-login` CLI 仍可用（中英 README 命令表同步更新）
- `/antigravity-doctor` 可调用入口（Refs #7）：`GET /antigravity/api/doctor` 返回 doctor 全文（含 `visionEnabled` / `visionBridge` / `visionShim` 三行），只读、拒绝非 GET。README 排障段此前让用户「运行 /antigravity-doctor」，但路由表从未提供该入口（PR #8 遗留缺口），现已按真实入口改写调用说明（中英同步）；快速开始版本口径同步如实区分（整包 0.2.0-rc.2 / 视觉路径另在 0.2.1-alpha.1 验证）
- 看图桥接决策链可观测（Refs #7）：桥在每条异步路径输出一行判定日志（请求进入、模型判定、改写结果或放行原因），贴图后服务端日志里零 `[Antigravity Pool Vision]` 前缀行，就是「事件没有到达桥」的直接证据；模型判定 resolver 的 unavailable / error 两态、shim 安装结果全部落日志；`/antigravity-doctor` 新增 `visionEnabled` / `visionBridge` / `visionShim` 三行组装状态；池 init 失败不再静默（记入 doctor 状态并告警）。纯观测改动：桥所有分支的判定与放行行为与 v0.8.0 等价（根因修复见上方 Fixed）

### 验证
- `npm run check` 84/84（v0.8.0 基线 75 项全保留 + 新增 9 项：决策日志契约、四种失败注入读出两两可区分、doctor 段）；两处 mutation 反证（入口正向控制日志、doctor vision 行）先红后恢复；semgrep 1 findings 为 v0.8.0 已记录的 buildModelMatchRegex 基线项，本次新增代码零 findings
- 桥迁移（Fixed）验证：`npm run check` 87/87（pre-step 契约全套重写：enter 改写 / reject 与无图与非纯文本透传 / gate 抛错 / 缓存与并发 / fail-open；存活探针回归含真实 cordis 注册→注销翻转）；隔离 web 副本（DSH 0.2.1-alpha.1）GUI 贴图端到端：决策链三行日志、用户消息持久化为池转述、模型零工具调用直答内容与测试图真实几何吻合，轨迹解码确认模型侧无占位文本
- doctor 入口（Added）验证：`npm run check` 88/88（新增路由测试：GET `/antigravity/api/doctor` 返回含三行状态、非 GET 405）
- 对话命令（Added）验证：`npm run check` 全绿（新增 `test/commands.test.mjs` 8 项：四命令注册与统一注销、无 commands 服务不抛错、login 展示授权链接、quota 逐账号刷新并触发适配器更新与额度行渲染、空池引导文案、doctor 原文透传、logout 无 confirm 拒绝且 confirm 后全量移除、handler 异常沉降为 error 结果）
- 准入栅栏（Security）验证：`npm run check` 全绿（vision-diagnostics 新增 401/403 两态用例：admit 拒绝时 doctor 与 login 路由在任何业务逻辑前返回对应状态码与 unauthorized/forbidden 文本；既有 200/405 用例在 admit 通过态下不变）

## v0.8.0 — 2026-10-01

### Added
- 视觉旁路：主模型无视觉时贴图由池内 Gemini 转述为文字回喂。新增 `antigravity_read_image` 工具（接受附件哈希前缀 / 本地路径 / data: URL / http(s) 公网图片链接）、贴图准入 shim（给纯文本模型的 `resolveModelInfo` 补报 image 模态，`ANTIGRAVITY_VISION_ENABLED=false` 或 `visionEnabled: false` 可关）、`visionEnabled` / `visionModel` 池配置字段
- 自动看图桥接（llm/stream）：无视觉主模型贴图时，发往模型的请求里图片块自动替换为池内 Gemini 的文字转述，模型无感获得看图能力；同一张图进程内缓存只转述一次，转述失败自动退回宿主占位路径不阻塞对话，转述文本附原始哈希可供 `antigravity_read_image` 显式细看；`visionEnabled` 开关同时控制贴图准入与自动转述
- `antigravity_read_image` 支持 http(s) 图片 URL：仅限公网地址（DNS 解析后逐记录校验，防 loopback / 内网 / 云元数据目标与 DNS rebinding）、redirect 手动跟随且每跳重校验（上限 3 跳）、15 秒超时、仅接受 image/* 响应、10 MiB 字节上限（content-length 预检 + 流式计数双保险）
- 设置页新增「视觉旁路」卡片：`visionEnabled` 开关与 `visionModel` 代看模型下拉（非生图 Gemini 模型），与自动桥接共享同一开关语义

### Security
- CI 加固：`.github/workflows/check.yml` 的 actions/checkout 与 actions/setup-node 从 mutable tag 钉到 commit SHA（dependabot 仍会提 PR 更新）；`.github/dependabot.yml` 两组依赖各加 14 天冷却期，降低新发布版本的供应链风险
- `buildModelMatchRegex` 入口加输入类型与长度防御（超 200 字符直接返回永不匹配模式），动态正则路径不再可能被超长输入触达（semgrep ReDoS 基线项，原实现输入已转义、风险本就很低）
- `antigravity_read_image` 的本地路径输入限制在工作区根与 DSH 附件库之内，越界即拒绝——此前模型可传任意绝对/穿越路径读取进程可访问的文件并上传 Google（Codex review P1）
- 附件对象与本地文件的 MIME 类型改为字节魔数嗅探（PNG/JPEG/WEBP/GIF），不再恒报 image/png

### Fixed
- 生图结果卡片的渲染文本此前显示 undefined：DSH 宿主调用工具 `output.render` 时第一个参数是调用入参、第二个才是 execute 返回值，`antigravity_image_generate` 的 render 按单参数声明取错了位置。改为双参形态，路径与 markdown 从返回值取
- `visionEnabled` 支持热切换：准入 shim 每次调用运行时判定开关状态（env 覆盖 + 池配置），设置页开关即刻生效，无需重启宿主
- 视觉池请求的 SSE error 帧不再被静默吞掉：quota 错误帧现在正确触发账号冷却与切换，不会再返回截断描述或抛笼统错误
- 视觉池请求的 fallback runtime 候选真正生效：主 runtime 遇 retryable 状态（404/429/5xx）自动换下一候选，与流式路径双层循环对齐；请求整体加 60 秒超时
- 显式配置的 `visionModel` 需通过能力校验（Gemini 且接受图片输入且非生图模型），选了纯文本或生图模型时回落自动挑选并告警

### 验证
- `npm run check` 69/69（v0.7.3 基线 34 项全保留 + 新增 35 项：视觉工具/桥接 waterfall 契约/SSRF 守卫/shim 分支/render 签名回归）；先红后绿证据留存
- 装包实测（隔离 profile + GLM-5.3 无视觉主模型）：贴图零工具调用、模型直接给出图片精确描述（区分下拉选中态与悬停态）；设置页卡片渲染与开关交互实测；三轮 GUI 实测含两个真实 bug 的发现与修复（render 签名、waterfall 契约）
- semgrep：v0.7.3 的 5 项基线 findings 全部消除，新增代码零 findings

## v0.7.3 — 2026-09-30

### Added
- `package.json` 的 `engines` 新增 `dsh` 声明：`">=0.1.7-rc.2 <0.3.0"`。npm 包发布后，dsh-market 插件市场的卡片会读取 npm manifest 里的 `engines.dsh` 显示宿主版本要求（此前 GitHub-only 分发，市场显示「未声明宿主要求」）。范围下限对齐 devDependencies 钉住的 0.1.7-rc.2，0.2.0-rc.2 宿主在范围内

### 验证
- `npm run check` 34 项全绿；`npm pack --dry-run` 核对发布清单

## v0.7.2 — 2026-09-29

### Changed
- README（中英同步）：删除 v0.6.0 曾融合 dsh-codearts-auth 的历史叙述句——历史归 CHANGELOG，不挂在 README 给新用户添噪音；「快速开始」新增环境要求声明：适配 DSH 0.2.0-rc.2（`dsh --version` 查看）

### 验证
- 文档-only 变更；`npm run check` 34 项全绿，确认无意外波及

## v0.7.1 — 2026-09-29

### Fixed
- **带图会话整轮失败（严重，[PR #3](https://github.com/qikairo7/dsh-gemini-pool/pull/3)，作者 [tensor-x](https://github.com/tensor-x)）**：`prepareRequestImages` 调用宿主 `attachments.readImageRequest` 时传的是 `{ maxPixels, maxBytes }`，而 DSH 的 `ImageRequestTarget` 契约要求 `width` / `height` 为安全正整数（`dsh-attachment` 的 `validateTarget` 逐一校验，缺 width 即抛 `Image request width must be a positive integer.`）——消息里只要有图片附件，本轮请求在组装阶段就抛错。修复为从附件 ref 自带的 `width` / `height` 出发，vendored 一份 `dsh-attachment` 的规范函数 `requestImageDimensions(width, height, maxPixels)`（按 `REQUEST_IMAGE_MAX_PIXELS` = 2048×2048 等比缩小），与 `{ maxBytes }` 合并成合法 target 传入。附件 ref 的 `width` / `height` 由 DSH 附件存储发布时写入（`ImageAttachmentRef` 必填字段），插件侧直接使用即类型安全；未带 `attachmentId` 的 inline 图仍走原有 legacy base64 路径，不受影响

### Added
- `test/adapter-image-target.test.mjs`（作者 tensor-x）：走真实路径的回归测试——真实 `AccountPoolManager` + `AntigravityPoolAdapter` 构造，fake attachments 捕获实际收到的 target，断言 `width` / `height` / `maxBytes` 均为安全正整数

### Removed
- 移除过期的 `PROJECT_STATUS.md`：内容冻结在 v0.5.3 时代（2026-09-26），与当前仓库状态不符；仓库现状以 README 与 CHANGELOG 为准

### 验证
- 守卫先证红：在未修复的 master（ad8fecb）上仅带入新测试文件运行，1 项失败（`AssertionError: width must be positive int`，旧代码传出的 target 无 width），精确复现线上症状；修复分支上 `npm run check` 34 项全绿（含 `node --check` 六文件）

## v0.7.0 — 2026-09-28

### Removed
- **移除融合的 dsh-codearts-auth provider，回归 Gemini 单渠道**：不再捆绑 `codearts` / `buddy` / `workbuddy` / `lobsterai` / `qoder` / `trae` / `cline` / `loomy` / `raccoon` 九条第三方路由。需要这些通道请单独安装 [dsh-codearts-auth](https://gitee.com/iJetLi/deepseek-harness-codearts)（作者 Jet，MIT）
  - 删除 `lib/vendor/codearts/`（77 个文件，含 `qoder-auth-wasm.wasm`）及 `lib/index.js` 中对上游 `apply(ctx)` 的调用；`lib/client.js` 移除 id 为 `dsh-codearts-auth` 的 Jet Hub 客户端块，文件约 196KB → 65KB
  - 设置页只剩 Antigravity（Gemini 账号池）面板，`antigravity` 路由行为不变
- `package.json`：移除 `dependencies` 里的 `jose`（仅上游使用，运行时零依赖）；`description` 与 `keywords` 去掉 Cloud Code Assist，改标 `gemini`

### Changed
- 插件 `inject` 由 `["llm", "credentials", "commands"]` 回落为 `["llm"]`（`export const inject` 与 `apply.inject` 同步），不再依赖宿主的 credentials / commands 服务
- `test/client-render.test.mjs`：`loadGeminiSource()` 的截取逻辑保留，注释更新为单模块现状

### 验证
- `npm run check`：`node --check` 全部通过，`node --test` 33 项全绿（渲染回归、池状态机、探活、适配器错误路径）

## v0.6.0 — 2026-09-26

### Added
- **融合 dsh-codearts-auth 的 9 条 provider 路由**：`codearts`、`buddy`、`workbuddy`、`lobsterai`、`qoder`、`trae`、`cline`、`loomy`、`raccoon`。装本插件即同时具备这 9 条通道与原有的 `antigravity`，不必再单独安装 [dsh-codearts-auth](https://gitee.com/iJetLi/deepseek-harness-codearts)（作者 Jet，MIT）
  - 复用而非重写：上游 TypeScript 源码经 esbuild 转译为 ESM 后整体置于 `lib/vendor/codearts/`（77 个文件，含 `qoder-auth-wasm.wasm`），其 MIT 许可证原文保留在同目录 `LICENSE`。本插件只做了接入，没有改上游实现
  - 接入方式：`lib/index.js` 的 `apply()` 末尾调用上游的 `apply(ctx)`，一个调用注册全部 9 条路由，与 `ctx.llm.registerAdapter` 同源（上下游都从 `@deepseek-ai/dsh-llm` 取 `LlmAdapter`）
  - 前端同理：上游 Jet Hub 客户端 bundle 以独立的 `window.__ModuleLoader__.load({ id: "dsh-codearts-auth" })` 块并入 `lib/client.js`，与本插件的设置页块并列，各自注册 `settings.section`
  - **失败隔离**：这 9 条路由依赖宿主的 `credentials` / `commands` 服务。上游 `apply()` 包在 try/catch 内，服务缺失或版本不匹配时只放弃这 9 条路由并打一条 warn，`antigravity` 路由照常注册
- `package.json`：`dependencies` 新增 `jose`（DPoP 签名，上游运行时依赖）；`peerDependencies` 新增 `@deepseek-ai/cordis`、`@deepseek-ai/dsh-credentials`、`@deepseek-ai/schemastery`（均 optional，由宿主提供）

### Changed
- 插件 `inject` 由 `["llm"]` 改为 `["llm", "credentials", "commands"]`（`export const inject` 与 `apply.inject` 同步）
- `test/client-render.test.mjs` 与 `test/client-render-populated.test.mjs`：新增 `loadGeminiSource()`，只取 `lib/client.js` 中 id 为 `dsh-gemini-pool` 的那个模块块做静态扫描与执行；`__ModuleLoader__.load` 的桩也改为按 id 过滤。原因是 client.js 现在含两个模块块，不区分会让上游 Jet Hub 块的组件覆盖被捕获的本插件组件，导致 7 项渲染测试误报失败

### 本版本未覆盖的验证
- **9 条融合路由的真实登录与调用未做端到端验证** —— 需要各平台的真实账号，当前环境没有。已验证的是：77 个 vendor 模块可正常 import、上游 `apply()` 可被调用、失败隔离生效（无宿主服务时只 warn 不崩）、原有 33 项测试全绿
- `npm install` 在本机需用 `--legacy-peer-deps`：仓库原有的 `@deepseek-ai/dsh-host-webserver` 与 `dsh-invariants` peer 冲突在本次改动前就存在，未在本次修改

## v0.5.3 — 2026-09-26

### Fixed
- **设置页整页空白（严重）**：设置页组件引用了两个从未声明的变量（`localeRev` / `setLocaleRev`，本意是语言切换后重渲染）。该引用位于组件渲染函数体内，一执行就抛 `ReferenceError`，React 随即卸载整个设置分区——表现就是「打开设置，插件卡片是空白的」。补上缺失的状态声明。已用真实渲染测试复现：修复前 18 项渲染测试中 13 项失败（失败栈为 `ReferenceError: localeRev is not defined at GeminiSettingsPage`），修复后 33 项全绿

### Added
- **客户端渲染回归测试（9 项）**：此前所有检查都是静态的（语法检查、i18n 键覆盖、模块导入、HTTP 接口探测），全部通过却漏掉了「组件根本渲染不出来」这类问题。新增测试会真正执行组件渲染函数：
  - `test/client-render.test.mjs`——空数据渲染不抛错、渲染输出非空且含预期标题、所有被调用的 `set*` 与 hook 依赖项都有声明
  - `test/client-render-populated.test.mjs`——用真实接口响应（已脱敏）渲染，断言账号行、额度行、模型列表都出现在输出里，并断言「打开面板即自动刷新额度」这条行为
  - 两个文件都做了反向验证：把修复回退后测试确实变红，确认它们真能抓住这个缺陷
- `scripts/build-status-fixture.mjs`——从本机 `/antigravity/api/status` 抓取真实响应生成测试夹具，自动脱敏（邮箱、账号 id、令牌），若发现未脱敏邮箱则拒绝写入。该脚本刻意放在 `test/` 之外，避免被 `node --test` 自动执行而改写已提交的夹具

## v0.5.2 — 2026-09-25

### Fixed
- **账号在重启后丢失（严重）**：账号池加载校验的是一个实际不存在的字段（`accessToken`），而账号真正持有的是 `access` / `refresh`——导致每次进程重启从磁盘读回时，已保存的账号在校验阶段抛错、被静默吞掉，池加载为空（有旧凭证文件时甚至被单账号迁移覆盖）。改为校验真正的持久字段 `refresh`（access 是临时令牌、可按需刷新，legacy 迁移账号允许为空）。已用「保存→新实例重载」实测复现并验证修复
- **损坏的池文件不再静默丢弃**：池文件存在但无法解析时立即报错（携带文件路径与原因），不再静默清空并让迁移逻辑覆盖可恢复的文件

### Added
- 3 项账号池持久化回归测试（重载存活 / 空 access 仍可加载 / 损坏文件报错且不被覆盖）

### Changed
- 设置页无障碍与打磨：表单控件与 `<label>` 显式关联、额度条补 `role="progressbar"` 与 aria 值、错误/保存提示加 live region、折叠区补 `aria-expanded`、`:focus-visible` 焦点环、点按反馈与 `prefers-reduced-motion` 适配；「当前使用」标签补中英双语（行为、接口、数据流未变）
- 文档梳理：README 中英去营销腔并对齐、修英文版破损 HTML 与语义漂移、CHANGELOG/SECURITY 轻度润色

## v0.5.1 — 2026-09-25

### Fixed
- **请求失败路径崩溃修复**：`triedEndpoints` / `lastNetworkError` 原声明在候选循环内部、却在循环外的错误分支被引用，导致任一请求彻底失败时抛 `ReferenceError` 而非分类后的 `LlmError`。该 `ReferenceError` 无法被 `isQuotaOrRateLimitError()` 识别，使得账号在「所有候选均 429」的常见场景下既不进入冷却、也不自动切号——多账号 429 容灾在该路径下形同虚设。现将两变量提升至请求级作用域
- **并发刷新令牌加锁**：同一账号的多路请求 / 后台探活并发触发刷新时，会用同一个（旧的）`refresh_token` 同时打 Google 令牌端点；Google 每次刷新都会轮换 refresh_token，并发刷新可能互相作废并导致账号被刷废。新增 `refreshAccountTokenOnce()` 按账号合并在途刷新

### Added
- 回归测试：所有候选 429 耗尽时须抛出限流错误（非 ReferenceError）并正确记一次冷却

### Docs
- README 手动安装示例的包名去掉写死版本号，改用 `dsh-gemini-pool-*.tgz` 通配

## v0.5.0 — 2026-09-25

### Changed
- **探活恢复改为递减信任制**：后台探活成功后账号重新启用，但 `failureCount` 只递减 1（新 `recordProbeSuccess()`）——一次探活成功不再把真实失败史一笔勾销，账号需连续多次探活成功才能完全重获信任；设置页手动「重新启用」仍为全重置语义

### Security / Hardening
- 生图产物落盘前校验大小（上限 20 MiB），拒绝无界 base64 写盘
- 设置页 Web API 请求体上限 2 MiB，超限拒绝
- 账号池加载：结构性损坏（缺 `id` / `accessToken`）立即报错并携带坏值，不再静默吞掉坏条目
- 设置页表单：冷却参数未配置时显示为空，不再用硬编码默认值伪装成“已配置”
- 可重试状态码收敛为 `RETRYABLE_STATUSES` / `PROBE_RETRYABLE_STATUSES` 两个单一常量（原先三处独立硬编码数组）

### Added
- 3 项探活恢复行为测试（递减信任 / 不穿透零下限 / 手动解禁全重置）

### Internal
- 诊断单例显式化：`lib/diagnostics.js`（`createDiagnostics()` 工厂 + 共享实例），为后续模块拆分铺路
- 模块拆分持续推进：`lib/models.js`、`lib/text-and-format.js` 已剥离（行为零变化，导出面 32 不变）

## v0.4.1 — 2026-09-25

### Fixed
- 账号成功响应不再清零累计失败计数：间歇性坏号的退避阶梯与 `disableThreshold` 退役机制恢复生效（新增 `clearCooldownUntil()` 只清冷却窗口；`clearCooldown()` 保留手动解禁的全重置语义）
- 禁用账号的探活恢复改走真实 `streamGenerateContent` 文本通道（1-token 最小探测）：配额元数据查询不再能“假阳性复活”被限流的账号
- 账号池整体耗尽时报 `EXHAUSTED` 而非 `AUTH`，不再误导用户重新登录
- 生图路径与流路径统一使用同一配额/限流判定（收紧后的 `isQuotaOrRateLimitError`），400 类错误文本中偶然出现的 "quota" 字样不再误伤账号
- 流式输出中途遭遇 429 时同样标记冷却（不再换号续流，保持响应完整性）
- 生图成功路径补漏 `await`；修正 `package.json` 的 `files` 字段：把已改名的 README.zh.md 更正为 README.en.md

### Added
- GitHub Actions：push / PR 自动跑 `npm run check`（零依赖，无 install）
- 6 项行为回归测试（冷却语义 / 探活通道与模型 / 池耗尽错误码 / 中流 429 / 生图误判），全部先以失败态验证过对应 bug 真实存在

## v0.4.0 — 2026-09-25

### Added
- 首次公开版本：Google AI Pro / Ultra 订阅账号池接入 DSH（Antigravity / Cloud Code Assist 通道）
- 多账号额度均衡、429 自动切换、坏号冷却与探活恢复、设置页账号卡片与每周 / 5 小时额度展示、生图工具接入
