/**
 * The model-facing `muapi_generate` tool: submit a generation request to any
 * MuApi model endpoint (image, video, audio, 3D, ...) and poll until it
 * completes.
 *
 * MuApi exposes every model as `POST {baseUrl}/{model}` with a model-specific
 * JSON body (see https://muapi.ai/playground/{model}/api for the schema of a
 * given model, or https://muapi.ai/playground/{model}/llms.txt for an
 * agent-readable version). The call returns immediately with
 * `{ request_id, status: "processing" }`; the result is fetched by polling
 * `GET {baseUrl}/predictions/{request_id}/result` until `status` is
 * `completed` or `failed`.
 *
 * @module dsh-plugin-muapi/muapi-tool
 */
import type { Context } from '@deepseek-ai/cordis';
import { defineTool } from '@deepseek-ai/dsh-tools';
import { credentialRef } from '@deepseek-ai/dsh-credentials';
// Side-effect import: augments `Context` with `ctx.systemPrompt`.
import '@deepseek-ai/dsh-system-prompt';
import type { ResolvedPluginConfig } from './config.js';

const TOOL_SECTION = 'tool:muapi_generate';

interface SubmitResponse {
  request_id?: string;
  status?: string;
  error?: string;
}

interface ResultResponse {
  status?: string;
  error?: string | null;
  outputs?: unknown;
  images?: unknown;
  urls?: { get?: string };
}

/** Parse and validate the `muapi_generate` arguments. */
function parseArgs(args: Record<string, unknown>): { model: string; input: Record<string, unknown> } {
  const model = typeof args.model === 'string' ? args.model.trim().replace(/^\/+|\/+$/g, '') : '';
  if (model.length === 0) {
    throw new Error('muapi_generate: "model" must be a non-empty MuApi model slug, e.g. "flux-schnell-image" (see https://muapi.ai/playground for the full catalog)');
  }
  const input = args.input;
  if (typeof input !== 'object' || input === null || Array.isArray(input)) {
    throw new Error('muapi_generate: "input" must be an object of model-specific parameters (e.g. { "prompt": "..." })');
  }
  return { model, input: input as Record<string, unknown> };
}

async function sleep(ms: number, signal: AbortSignal): Promise<void> {
  if (signal.aborted) return;
  await new Promise<void>((resolve) => {
    const timer = setTimeout(resolve, ms);
    signal.addEventListener('abort', () => {
      clearTimeout(timer);
      resolve();
    }, { once: true });
  });
}

/**
 * Register the `muapi_generate` tool plus system-prompt guidance.
 *
 * @returns a disposer that removes both registrations made by this function.
 */
export function registerMuapiTool(ctx: Context, get: () => ResolvedPluginConfig): () => void {
  const disposePrompt = ctx.systemPrompt.section({
    name: TOOL_SECTION,
    order: 165,
    text: 'Use the muapi_generate tool to generate images, video, audio, or 3D assets when the user asks for AI media generation. Pass "model" as a MuApi model slug (e.g. "flux-schnell-image", "kling-v2-1-image-to-video") and "input" as that model\'s parameter object. Look up a model\'s exact parameters at https://muapi.ai/playground/{model}/llms.txt, or browse the catalog at https://muapi.ai/playground. The tool submits the job and polls until it completes, returning the output URLs.'
  });
  const disposeTool = ctx.tools.register(defineTool({
    name: 'muapi_generate',
    description: 'Generate images, video, audio, or 3D assets via any MuApi model. Submits the job (POST /{model}) and polls the result until completion, returning output URLs.',
    parameters: {
      model: {
        type: 'string',
        required: true,
        description: 'MuApi model slug, e.g. "flux-schnell-image" or "kling-v2-1-image-to-video". Browse https://muapi.ai/playground for the full catalog.'
      },
      input: {
        type: 'object',
        additionalProperties: true,
        required: true,
        description: 'Model-specific parameters as a JSON object, e.g. { "prompt": "a serene mountain lake at dawn" }.'
      }
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          content: { type: 'string' },
          requestId: { type: 'string' },
          outputs: { type: 'array', items: { type: 'string' } }
        }
      },
      render: (_args, value) => [{ type: 'text', text: value.content ?? '' }],
      presentationMeta: (_args, value) => value
    },
    timeoutMs: get().tool.timeoutMs,
    async execute(args, exec) {
      const input = parseArgs(args);
      const config = get().tool;
      if (!config.enabled) {
        throw new Error('muapi_generate: the tool is disabled — enable it under Settings → muapi');
      }
      if (config.apiKeyEnv === undefined) {
        throw new Error('muapi_generate: no MuApi API key configured — set one under Settings → muapi (create a key at https://muapi.ai/access-keys)');
      }
      const resolved = await ctx.credentials.resolve(credentialRef(config.apiKeyEnv));
      const apiKey = resolved?.value;
      if (apiKey === undefined || apiKey.length === 0) {
        throw new Error(`muapi_generate: could not resolve MuApi API key from credential reference "${config.apiKeyEnv}"`);
      }

      const headers: Record<string, string> = {
        'x-api-key': apiKey,
        'content-type': 'application/json'
      };

      const submitResponse = await fetch(`${config.baseUrl}/${input.model}`, {
        method: 'POST',
        headers,
        body: JSON.stringify(input.input),
        signal: exec.signal
      });
      const submitBody = await submitResponse.json().catch(() => ({})) as SubmitResponse;
      if (!submitResponse.ok || submitBody.request_id === undefined) {
        const detail = submitBody.error ?? JSON.stringify(submitBody);
        throw new Error(`muapi_generate: submitting "${input.model}" failed (${submitResponse.status}): ${detail}`);
      }

      const requestId = submitBody.request_id;
      const deadline = Date.now() + config.timeoutMs;
      let result: ResultResponse | undefined;
      while (Date.now() < deadline) {
        if (exec.signal.aborted) {
          throw new Error('muapi_generate: cancelled while waiting for the result');
        }
        const pollResponse = await fetch(`${config.baseUrl}/predictions/${requestId}/result`, {
          method: 'GET',
          headers: { 'x-api-key': apiKey },
          signal: exec.signal
        });
        const body = await pollResponse.json().catch(() => ({})) as ResultResponse;
        if (body.status === 'completed') {
          result = body;
          break;
        }
        if (body.status === 'failed' || (!pollResponse.ok && pollResponse.status !== 202)) {
          throw new Error(`muapi_generate: job ${requestId} failed: ${body.error ?? 'unknown error'}`);
        }
        await sleep(config.pollIntervalMs, exec.signal);
      }
      if (result === undefined) {
        throw new Error(`muapi_generate: job ${requestId} did not complete within ${config.timeoutMs}ms — poll it later at ${config.baseUrl}/predictions/${requestId}/result`);
      }

      const rawOutputs = result.outputs ?? result.images ?? [];
      const outputs = (Array.isArray(rawOutputs) ? rawOutputs : [rawOutputs])
        .filter((item): item is string => typeof item === 'string');

      return {
        content: outputs.length > 0
          ? `Generated via ${input.model}:\n${outputs.map((url) => `- ${url}`).join('\n')}`
          : `Job ${requestId} completed with no recognizable output URLs: ${JSON.stringify(result)}`,
        requestId,
        outputs
      };
    }
  }));

  return () => {
    disposePrompt();
    disposeTool();
  };
}
