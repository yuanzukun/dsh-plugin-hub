/**
 * dsh-plugin-muapi — MuApi model access for DeepSeek Harness.
 *
 * Exposes the `muapi_generate` tool: submit a job to any MuApi model
 * (image, video, audio, 3D) and poll it to completion.
 *
 * @module dsh-plugin-muapi
 */
import type { Context } from '@deepseek-ai/cordis';
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings';
import { Config, PLUGIN_ID, PLUGIN_NAME, resolvePluginConfig, type PluginConfig, type ResolvedPluginConfig } from './config.js';
import { registerMuapiTool } from './muapi-tool.js';

export { Config, PLUGIN_NAME, resolvePluginConfig } from './config.js';
export { registerMuapiTool } from './muapi-tool.js';

/** Cordis plugin name used by loader diagnostics. */
export const name = PLUGIN_NAME;

/** Services required by `muapi_generate`. */
export const inject = ['tools', 'systemPrompt', 'settings', 'credentials'];

const NS = settingsNamespace(PLUGIN_ID);

/** Cordis plugin entry. */
export function apply(ctx: Context, config: PluginConfig): void {
  let current = () => config;
  let lastRaw: PluginConfig | undefined;
  let lastGood: ResolvedPluginConfig | undefined;
  const resolved = (): ResolvedPluginConfig => {
    const raw = current();
    if (raw === lastRaw && lastGood !== undefined) return lastGood;
    try {
      const next = resolvePluginConfig(raw);
      lastRaw = raw;
      lastGood = next;
      return next;
    } catch (error) {
      if (lastGood === undefined) throw error;
      lastRaw = raw;
      ctx.logger.error('dsh-plugin-muapi: keeping the last good configuration after an invalid settings section');
      ctx.logger.error(error);
      return lastGood;
    }
  };

  let toolDisposer: (() => void) | undefined;
  const disposeTool = (): void => {
    const disposer = toolDisposer;
    toolDisposer = undefined;
    disposer?.();
  };
  const reconcileTool = (): void => {
    if (resolved().tool.enabled) {
      if (toolDisposer === undefined) {
        toolDisposer = registerMuapiTool(ctx, resolved);
      }
      return;
    }
    disposeTool();
  };

  ctx.effect(() => () => {
    disposeTool();
  }, 'dsh-plugin-muapi: muapi_generate tool lifecycle');

  installSettingsSection(ctx, NS, Config, config, {
    setSource: (source) => {
      current = source;
    },
    onChange: reconcileTool,
    validate: resolvePluginConfig
  });

  reconcileTool();
}
