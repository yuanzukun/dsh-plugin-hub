/**
 * Plugin configuration: schemastery schema, runtime validation, and the
 * resolved snapshot consumed by the tool.
 *
 * @module dsh-plugin-muapi/config
 */
import z from '@deepseek-ai/schemastery';

/** Stable plugin id / npm package name recorded with plugin-sourced messages. */
export const PLUGIN_NAME = '@dsh-plugin/dsh-plugin-muapi';

/** Short kebab-case id for the settings namespace (`[a-z0-9-]` only). */
export const PLUGIN_ID = 'dsh-plugin-muapi';

export const DEFAULT_BASE_URL = 'https://api.muapi.ai/api/v1';
export const DEFAULT_POLL_INTERVAL_MS = 3000;
export const DEFAULT_TIMEOUT_MS = 600000;

/** Plugin entry / settings schema. Field defaults live here so the UI can render them. */
const Config = z.object({
  tool: z.object({
    enabled: z.boolean().default(true).description('Expose the muapi_generate tool to the agent.'),
    apiKeyEnv: z.string().description('Credential reference for your MuApi API key (create one at https://muapi.ai/access-keys).'),
    baseUrl: z.string().default(DEFAULT_BASE_URL).description('MuApi API base URL.'),
    pollIntervalMs: z.number().step(100).min(500).default(DEFAULT_POLL_INTERVAL_MS),
    timeoutMs: z.number().step(1000).min(5000).default(DEFAULT_TIMEOUT_MS)
  })
});

/** Inferred plugin configuration value. */
export type PluginConfig = typeof Config extends z<infer T> ? T : never;

/** Resolved `muapi_generate` tool policy. */
export interface ResolvedToolConfig {
  readonly enabled: boolean;
  readonly apiKeyEnv: string | undefined;
  readonly baseUrl: string;
  readonly pollIntervalMs: number;
  readonly timeoutMs: number;
}

/** The complete resolved, frozen plugin snapshot. */
export interface ResolvedPluginConfig {
  readonly tool: ResolvedToolConfig;
}

/** Resolve and validate one untrusted plugin-config snapshot into the frozen runtime shape. */
export function resolvePluginConfig(config: PluginConfig): ResolvedPluginConfig {
  const tool = config.tool ?? {};
  const apiKeyEnv = typeof tool.apiKeyEnv === 'string' && tool.apiKeyEnv.length > 0 ? tool.apiKeyEnv : undefined;
  const baseUrl = typeof tool.baseUrl === 'string' && tool.baseUrl.length > 0 ? tool.baseUrl.replace(/\/+$/, '') : DEFAULT_BASE_URL;
  return Object.freeze({
    tool: Object.freeze({
      enabled: tool.enabled ?? true,
      apiKeyEnv,
      baseUrl,
      pollIntervalMs: tool.pollIntervalMs ?? DEFAULT_POLL_INTERVAL_MS,
      timeoutMs: tool.timeoutMs ?? DEFAULT_TIMEOUT_MS
    })
  });
}

export { Config };
