# dsh-mermaid-image-preview

[![Awesome DSH Plugin](https://awesome-dsh-plugin.com/badge.svg)](https://awesome-dsh-plugin.com/p/baconbao/dsh-mermaid-image-preview/)
![DSH Plugin Profile Badge](https://img.shields.io/badge/DSH%20profile-Web%20%2F%20Desktop-5B4CF0)
![DSH Plugin Works-on Badge](https://img.shields.io/endpoint?url=https%3A%2F%2Fbaconbao.github.io%2Fbadge-endpoints%2Fdsh-mermaid-image-preview%2Fworks-on.json)
[![Release Badge](https://img.shields.io/github/v/release/baconbao/dsh-mermaid-image-preview)](https://github.com/baconbao/dsh-mermaid-image-preview/releases)
[![License Badge](https://img.shields.io/github/license/baconbao/dsh-mermaid-image-preview)](./LICENSE)

A DeepSeek Harness Plugin for Previewing Mermaid Diagram Images

Preview Mermaid syntax as images via local rendering in DSH when a chat message contains a Mermaid fenced code block (` ```mermaid ` or ` ```mmd `).

![dsh-mermaid-image-preview](https://raw.githubusercontent.com/baconbao/dsh-mermaid-image-preview/ce80d380212961ea8ee0294dc1b28584c4b9cc1e/docs/img/dsh-mermaid-image-preview.png)

## Features and how it works

- **Preview mermaid diagrams by rendering images directly!**
- **Local renderer first!** If it fails, it can fall back to an external or self-hosted rendering engine by configuring a fallback server.
- **Nothing gets replaced:** the preview is added below the agent's reply, so
  the original messages are not covered up or changed.
- Settings in Plugin page: adjust the plugin's runtime settings in the Plugins panel - no restart needed.
- Light/dark themes follow the UI automatically.

## Support diagram types

The plugin renders diagrams locally with a built-in renderer. It supports
13 diagram types out of the box.

**Rendered locally:** flowchart, sequenceDiagram, classDiagram, stateDiagram, erDiagram, pie, journey, gitGraph, requirementDiagram, timeline, quadrantChart, packet-beta, xychart-beta

**Expand:** gantt, mindmap, block-beta, sankey-beta, architecture-beta, zenuml, C4Context

> [!NOTE]
> You can enable the fallback to render expanded types — see **Configuration** below.

## Installation

### Install from `github`

#### Install with DeepSeek Harness Desktop (the `desktop` profile)

In **DeepSeek Harness (Desktop)**, go to the **Plugins** panel, click the **+ Add plugin** button,
paste one of the URLs below, then click the **Install** button.

```markdown
### latest release version
https://github.com/baconbao/dsh-mermaid-image-preview
### specific version
https://github.com/baconbao/dsh-mermaid-image-preview#<VERSION_TAG|GIT_TAG>
### dev version
https://github.com/baconbao/dsh-mermaid-image-preview#dev
```

> [!NOTE]
> Make sure Git is installed on your machine before installing.


#### Install with DeepSeek Harness WebUI (the `web` profile)

```bash
### latest release version
$ npx @deepseek-ai/dsh plugin --profile web add github:baconbao/dsh-mermaid-image-preview

### specific version
$ npx @deepseek-ai/dsh plugin --profile web add github:baconbao/dsh-mermaid-image-preview#<VERSION_TAG|GIT_TAG>

### dev version
$ npx @deepseek-ai/dsh plugin --profile web add github:baconbao/dsh-mermaid-image-preview#dev
```

### Install from source code

```bash
$ git clone https://github.com/baconbao/dsh-mermaid-image-preview
$ cd dsh-mermaid-image-preview
$ pnpm install
$ dsh plugin --profile web add .
```

> [!IMPORTANT]
> Restart DSH after installing.

## Configuration

### Change runtime settings on the plugin page

![dsh-mermaid-image-preview_settings](https://raw.githubusercontent.com/baconbao/dsh-mermaid-image-preview/ce80d380212961ea8ee0294dc1b28584c4b9cc1e/docs/img/dsh-mermaid-image-preview_setting.png)

The **Plugins** panel lists this plugin under **Installed**; open its page and the
configuration block carries the runtime settings - no restart needed.
Values are stored in localStorage and applied immediately across all sessions.

### Change render server via configuration file

Diagrams are rendered locally by default. To use your own render server or
enable the external fallback, edit the profile's `cordis.patch.yml` (e.g.
`~/.dsh/profiles/web/cordis.patch.yml` for WebUI, or `~/.dsh/profiles/desktop/cordis.patch.yml` for Desktop):

```yaml
- id: ui-dsh-mermaid-image-preview
  config:
    enableLocalRender: true
    fallbackRenderUrl: https://mermaid.ink
    enableFallback: false
```

- `enableLocalRender`: render locally (default `true`). Set it to `false` to always use the fallback server (`enableFallback` is ignored).
- `fallbackRenderUrl`: fallback render server (default `https://mermaid.ink`).
- `enableFallback`: use the fallback server when local rendering fails (default `false`).
- Restart DSH after changing these settings.
- To host your own fallback render server, see <https://github.com/jihchi/mermaid.ink> for the details.

## Uninstallation

#### Unstall with DeepSeek Harness Desktop (the `desktop` profile)

Open this plugin's page in the **Plugins** panel, then click **Uninstall**.

#### Unstall with DeepSeek Harness WebUI (the `web` profile)

```bash
$ dsh plugin --profile web remove @baconbao/dsh-mermaid-image-preview
```

> [!NOTE]
> Since **v0.2.0**, the plugin/package ID has been `@baconbao/dsh-mermaid-image-preview` (it was `dsh-mermaid-image-preview` before).

## Test

Ask the agent to produce:

````
```mermaid
graph TD
  A[Start] --> B{Success?}
  B -->|Yes| C[Done]
  B -->|No| D[Retry]
```
````

## Compatibility

| This plugin version | Supported DSH version |
| --- | --- |
| **v0.4.0** and later | **0.1.6-alpha.2** and later |
| **v0.3.2** and earlier | **0.1.0-rc.6** – **0.1.6-alpha.1** |

---

## Author

baconbao, vibe coding with AI

## License

[MIT](./LICENSE)
