/**
 * Unit checks for the annotation half: the message it composes, and that the dock
 * sends exactly that message once and then empties.
 *
 * Usage: `node test/annotate.spec.mjs`.
 */
import { pathToFileURL } from 'node:url'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = join(dirname(fileURLToPath(import.meta.url)), '..')

let failures = 0
const check = (label, condition, detail = '') => {
  if (condition) console.log(`  ok   ${label}`)
  else {
    failures += 1
    console.log(`  FAIL ${label} ${detail}`)
  }
}

//#region browser stubs
/** Document listeners the plugin registers, so the suite can fire real events at it. */
const documentListeners = new Map()

const windowStub = { __ModuleLoader__: { load: (spec) => { windowStub.spec = spec } }, addEventListener: () => {}, removeEventListener: () => {}, scrollX: 0, scrollY: 0, getSelection: () => null }
const documentStub = {
  querySelector: () => null,
  createElement: () => ({ setAttribute: () => {}, appendChild: () => {}, addEventListener: () => {}, style: {}, classList: { add: () => {} }, remove: () => {}, focus: () => {}, textContent: '', append: () => {} }),
  head: { appendChild: () => {} },
  body: { appendChild: () => {} },
  addEventListener: (name, fn) => { const list = documentListeners.get(name) ?? []; list.push(fn); documentListeners.set(name, list) },
  removeEventListener: () => {},
  documentElement: { clientWidth: 1200 },
}
globalThis.window = windowStub
globalThis.document = documentStub

await import(pathToFileURL(join(root, 'client/client.js')).href)
const spec = windowStub.spec
check('the bundle registers itself under the plugin id', spec?.id === 'dsh-annotate')
//#endregion

const React = {
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  useState: () => [null, () => {}],
  useEffect: () => {},
}
const exports = spec.factory((name) => (name === 'react' ? React : undefined))
check('the client half exports apply and inject', typeof exports.apply === 'function' && Array.isArray(exports.inject))
check('it injects the slots, sessions, locale and conversation services',
  ['slots', 'sessions', 'locale', 'uiConversation'].every(name => exports.inject.includes(name)), JSON.stringify(exports.inject))

// The real dictionary reads as prose; the suite only needs the labels to be present.
const t = (key, vars) => (vars === undefined ? key : `${key}:${String(vars.count ?? '')}`)

console.log('the message it composes')
const composed = exports.composeBatch([
  { quote: '这一步会覆盖原文件', comment: '这里应该先备份' },
  { quote: '大约 3 秒', comment: '这个数字是怎么来的？' },
], t)
check('it opens by presenting the annotations', composed.startsWith('intro'), JSON.stringify(composed.slice(0, 40)))
check('every quote is numbered and quoted', composed.includes('1. quoteLabel：「这一步会覆盖原文件」') && composed.includes('2. quoteLabel：「大约 3 秒」'), composed)
check('every comment follows its quote', composed.includes('commentLabel：这里应该先备份') && composed.includes('commentLabel：这个数字是怎么来的？'), composed)
check('nothing waiting composes nothing', exports.composeBatch([], t) === '')
check('a multi-line selection stays on one line', exports.composeBatch([{ quote: 'a\nb', comment: 'c\nd' }], t).includes('「a b」') && exports.composeBatch([{ quote: 'a\nb', comment: 'c\nd' }], t).includes('commentLabel：c d'))

/** Every button in a rendered tree, in document order. */
const buttonsIn = (node, found = []) => {
  if (node === null || typeof node !== 'object') return found
  if (node.type === 'button') found.push(node)
  for (const child of node.children ?? []) buttonsIn(child, found)
  return found
}

console.log('the chip row sends the batch through the conversation face')
const sent = []
const registration = {}
const ctx = {
  effect: (fn) => { fn(); return () => {} },
  locale: { register: () => {}, bind: () => t },
  sessions: {
    list: {
      getSnapshot: () => ({ ids: ['a'], byId: { a: { id: 'a', retainedBy: { mainView: 1 } } } }),
      subscribe: () => () => {},
    },
    scope: () => ({ id: 'scope' }),
    sessionOf: () => ({ prompt: (parts, mode) => { sent.push(`${mode}:${parts[0].text}`); return Promise.resolve({ ok: true }) } }),
  },
  uiConversation: { send: (text) => { sent.push(text); return Promise.resolve() } },
  slots: {
    inject: (name, factory) => { factory({}) },
    register: (options, component) => { registration.options = options; registration.component = component; return () => {} },
  },
}
exports.apply(ctx)
check('it registers into the composer dock', registration.options.name === 'conversation.input.dock')
exports.pending.set('a', [{ quote: 'q', comment: 'c' }])
const element = registration.component({ t, sessionId: 'a' })
check('the row renders while something waits', element !== null, String(element))
const buttons = buttonsIn(element)
check('a chip carries only its own remove action', buttons.length === 1, JSON.stringify(buttons.map(button => button.children?.[0])))
exports.pending.set('a', [])
check('an empty list renders nothing', registration.component({ t, sessionId: 'a' }) === null)

console.log('removing one chip keeps the rest')
exports.pending.set('a', [{ quote: 'one', comment: 'c1' }, { quote: 'two', comment: 'c2' }])
const xMarks = buttonsIn(registration.component({ t, sessionId: 'a' })).filter(button => button.children?.[0] === '✕')
xMarks[0].props.onClick()
check('only the chosen annotation left', exports.pending.get('a').length === 1 && exports.pending.get('a')[0].quote === 'two', JSON.stringify(exports.pending.get('a')))


console.log('the floating card stays on screen')
const size = { width: 340, height: 200 }
const viewport = { width: 1000, height: 800 }
check('below the selection when it fits',
  JSON.stringify(exports.placeMath({ rect: { left: 100, top: 100, bottom: 120 }, size, viewport })) === JSON.stringify({ left: 100, top: 128 }))
check('above it when the bottom is out of room',
  JSON.stringify(exports.placeMath({ rect: { left: 100, top: 700, bottom: 720 }, size, viewport })) === JSON.stringify({ left: 100, top: 492 }))
check('clamped inward when neither side fits',
  exports.placeMath({ rect: { left: 100, top: 300, bottom: 320 }, size: { width: 340, height: 790 }, viewport }).top === 8)
check('and clamped away from the right edge',
  exports.placeMath({ rect: { left: 990, top: 0, bottom: 20 }, size, viewport }).left === 1000 - 340 - 8)


console.log('only the Session text can be annotated')
const selectionOf = (node, text = 'some text') => ({
  isCollapsed: false,
  toString: () => text,
  anchorNode: node,
  rangeCount: 0,
  getRangeAt: () => undefined,
})
const tag = { nodeType: 3, parentElement: { closest: (selector) => (selector.includes('contenteditable') ? {} : null) } }
check('a composer selection is refused', exports.readSelection(selectionOf(tag)) === undefined)
const message = { nodeType: 3, parentElement: { closest: (selector) => (String(selector).includes('data-chat-turn') ? {} : null) } }
check('a message selection is accepted', exports.readSelection(selectionOf(message))?.text === 'some text')
const own = { nodeType: 3, parentElement: { closest: (selector) => (selector.includes('data-dsh-annotate') ? {} : null) } }
check('a selection inside this plugin UI is refused', exports.readSelection(selectionOf(own)) === undefined)


console.log('Enter in the composer sends the draft and the annotations as one message')
const drafted = []
ctx.sessions.sessionOf = () => ({ prompt: (parts, mode) => { drafted.push(`${mode}:${parts[0].text}`); return Promise.resolve({ ok: true }) } })
exports.pending.set('a', [{ quote: 'q', comment: 'c' }])
const composer = { isContentEditable: true, innerText: '我的问题', focus: () => {}, closest: () => null }
let prevented = false
const written = []
const composerActions = { setDraft: (text) => { written.push(text) } }
registration.component({ t, sessionId: 'a', inputActions: composerActions })
const enter = {
  key: 'Enter', shiftKey: false, isComposing: false, target: composer,
  preventDefault: () => { prevented = true }, stopPropagation: () => {},
}
for (const listener of documentListeners.get('keydown') ?? []) listener(enter)
await new Promise((resolve) => { setTimeout(resolve, 20) })
check('the composer submit is taken over', prevented === true)
check('one queue message carrying both', drafted.length === 1 && drafted[0].startsWith('queue:我的问题') && drafted[0].includes('quoteLabel：「q」'), JSON.stringify(drafted))
check('and the chips cleared', exports.pending.get('a').length === 0)
// The merged message goes through the composer's draft; the empty write is the fallback's clear.
check('and the merged text was handed to the composer draft',
  written.length >= 1 && String(written[0]).includes('quoteLabel：「q」'), JSON.stringify(written))
check('and the composer was emptied afterwards', String(written.at(-1)) === '', JSON.stringify(written))



console.log('pressing outside takes the button away before the release')
check('a press inside the plugin UI is ignored', exports.pressAction({ inside: true, open: false, sinceOpened: 9e9 }) === 'ignore')
check('the press that opened the card does not close it', exports.pressAction({ inside: false, open: true, sinceOpened: 120 }) === 'ignore')
check('a later press closes the card', exports.pressAction({ inside: false, open: true, sinceOpened: 900 }) === 'close')
check('with no card, a press drops the button', exports.pressAction({ inside: false, open: false, sinceOpened: 0 }) === 'drop')

console.log('only a new selection earns a button back')
check('a plain click on a table cell does not', exports.offerAction({ inside: false, open: false, pressed: 'old text', current: 'old text' }) === false)
check('a drag that changed the selection does', exports.offerAction({ inside: false, open: false, pressed: 'old', current: 'old and more' }) === true)
check('a click that collapsed the selection does', exports.offerAction({ inside: false, open: false, pressed: 'old', current: '' }) === true)
check('a press inside the plugin UI never does', exports.offerAction({ inside: true, open: false, pressed: null, current: 'x' }) === false)

console.log('the annotation box leaves a composing Enter to the input method')
check('a composing key is not a save', exports.composingEnter({ isComposing: true, keyCode: 13, composing: false }) === true)
check('keyCode 229 is not a save', exports.composingEnter({ isComposing: false, keyCode: 229, composing: false }) === true)
check('an open composition is not a save', exports.composingEnter({ isComposing: false, keyCode: 13, composing: true }) === true)
check('a plain Enter is a save', exports.composingEnter({ isComposing: false, keyCode: 13, composing: false }) === false)


console.log('saving an annotation returns the keyboard to the composer')
const fakeComposer = { focused: 0, focus() { this.focused += 1 } }
globalThis.document.querySelector = (selector) => (String(selector).includes('data-composer-card') ? fakeComposer : null)
check('the composer takes the focus', exports.focusComposer() === true && fakeComposer.focused === 1)
globalThis.document.querySelector = () => null
check('and a missing composer is reported, not thrown', exports.focusComposer() === false)


console.log('only conversation rows are annotatable')
const rowClosest = (hit) => (selector) => (hit.includes(String(selector).slice(0, 20)) || String(selector).includes('data-chat-turn') ? {} : null)
check('a settings panel is refused', exports.annotatableTarget({ closest: () => null }) === false)
check('a dialog inside a row is refused',
  exports.annotatableTarget({ closest: (selector) => (String(selector).includes('role="dialog"') ? {} : {}) }) === false)
check('an answer inside a conversation row is accepted',
  exports.annotatableTarget({ closest: (selector) => (String(selector).includes('data-chat-turn') ? {} : null) }) === true)
check('the composer is refused even inside a row', exports.annotatableTarget({ closest: () => ({}) }) === false)

console.log('an empty draft gains the placeholder so the button can be pressed')
{
  const written = []
  const drafts = { value: '' }
  exports.__setTestHooks?.({
    inputActions: { setDraft: (text) => { drafts.value = text; written.push(text) } },
    getDraft: () => drafts.value,
  })
  exports.syncPlaceholderForTest(true)
  check('the placeholder lands in the empty draft', written.length === 1 && written[0] === exports.PLACEHOLDER, JSON.stringify(written))
  exports.syncPlaceholderForTest(false)
  check('and leaves once nothing waits', drafts.value === '' && written.length === 2, JSON.stringify(written))
}

console.log('the composer keeps its send button operable while annotations wait')
check('a draft holding only the placeholder reads as blank', exports.blankDraft('\u200b') === true)
check('and a real draft does not', exports.blankDraft('hi') === false)
check('the placeholder is exported so the composer path can strip it', typeof exports.PLACEHOLDER === 'string')

console.log('the message presents the annotations without demanding per-item answers')
const presentation = exports.composeBatch([{ quote: 'q', comment: 'c' }], (key) => key)
check('it opens by saying these are annotations', presentation.startsWith('intro'), presentation.split('\n')[0])
check('and does not ask for a point-by-point reply',
  !/逐条|address each|reply to each/i.test(presentation), presentation.split('\n')[0])

console.log(failures === 0 ? "\nPASS" : `\n${String(failures)} FAILURE(S)`)
process.exit(failures === 0 ? 0 : 1)
