// verify.mjs — 验证 dsh-word-complete（host 词频逻辑 + client bundle）。
import { readFileSync, writeFileSync, mkdtempSync, rmSync, existsSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import vm from "node:vm";

const results = [];
function check(label, ok) {
  results.push([label, !!ok]);
  console.log(`${ok ? "PASS" : "FAIL"}  ${label}`);
}

// ════════════ host ════════════
const host = await import(new URL("./lib/index.js", import.meta.url));
check("host 导出", typeof host.apply === "function" && Array.isArray(host.inject) && host.name === "word-complete");
check("host inject 含 sessions", host.inject.includes("webServer") && host.inject.includes("sessions"));

// 分词
const words1 = host.extractWords("Hello world hello, 插件管理器 和 dsh-session-nav!");
check("extractWords: 中英混合提取", words1.includes("Hello") && words1.includes("插件管理器") && words1.includes("session"));
check("extractWords: 过滤纯数字与短词", !host.extractWords("a 12 3456 ok").includes("a") && !host.extractWords("a 12 3456 ok").includes("12") && host.extractWords("a 12 3456 ok").includes("ok"));
check("extractWords: 中文提取", host.extractWords("设置标签").includes("设置标签"));

// 词频合并 + topN
const base = [{ w: "alpha", c: 5 }, { w: "beta", c: 3 }];
const added = new Map([["beta", 2], ["gamma", 4]]);
const merged = host.mergeWordCounts(base, added, 10);
check("mergeWordCounts: 合并计数", merged.find((x) => x.w === "beta").c === 5 && merged.find((x) => x.w === "gamma").c === 4);
check("mergeWordCounts: 频次降序+同频词典序", merged[0].w === "alpha" && merged[1].w === "beta" && merged[2].w === "gamma");
const limited = host.mergeWordCounts(base, added, 2);
check("mergeWordCounts: topN 截断", limited.length === 2);

// wordsFor：缓存 + 增量 + 持久化（临时 DSH_HOME）
const tmpHome = mkdtempSync(join(tmpdir(), "dsh-wc-"));
const prevHome = process.env.DSH_HOME;
process.env.DSH_HOME = tmpHome;
const mkEvent = (seq, type, text) => {
  if (type === "user/message") return { seq, type, surfaceOp: "append", data: { source: { kind: "user" }, content: [{ type: "text", text }] } };
  return { seq, type, surfaceOp: "append", data: { message: { content: [{ type: "text", text }] } } };
};
const session1 = {
  id: "wc1",
  seq: 4,
  events: [
    mkEvent(0, "user/message", "hello world hello"),
    mkEvent(1, "assistant/message", "the world is wide"),
    mkEvent(2, "assistant/chunk", "ignored"),
    mkEvent(3, "user/message", "会话标签 和 标签"),
  ],
};
const w1 = host.wordsFor(session1);
check("wordsFor: 统计词频（world=2）", w1.find((x) => x.w === "world")?.c === 2 && w1.find((x) => x.w === "hello")?.c === 2);
check("wordsFor: 中文词", w1.some((x) => x.w === "标签"));
const w1again = host.wordsFor(session1);
check("wordsFor: 缓存命中（同引用）", w1again === w1);
const grown = { id: "wc1", seq: 5, events: [...session1.events, mkEvent(4, "user/message", "hello again")] };
const w2 = host.wordsFor(grown);
check("wordsFor: 增量合并（hello=3）", w2.find((x) => x.w === "hello")?.c === 3 && w2 !== w1);
check("wordsFor: 持久化文件", existsSync(join(tmpHome, "word-complete.json")));
const persisted = JSON.parse(readFileSync(join(tmpHome, "word-complete.json"), "utf8"));
check("wordsFor: 持久化内容", persisted.wc1?.lastSeq === 5 && Array.isArray(persisted.wc1?.words));
process.env.DSH_HOME = prevHome;
rmSync(tmpHome, { recursive: true, force: true });

// ════════════ client bundle ════════════
const src = readFileSync(new URL("./lib/client.js", import.meta.url), "utf8");
let loaded = null;
const sandbox = {
  window: {
    __ModuleLoader__: { load: (p) => { loaded = p; } },
    setTimeout: (fn) => { return 0; },
    requestAnimationFrame: (fn) => { return 0; },
  },
  document: {
    querySelector: () => null,
    querySelectorAll: () => [],
    addEventListener: () => {},
    removeEventListener: () => {},
    createElement: () => ({ dataset: {}, textContent: "" }),
    head: { appendChild: () => {} },
  },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({ words: [{ w: "hello", c: 3 }, { w: "world", c: 2 }], lastSeq: 9 }) }),
};
vm.createContext(sandbox);
vm.runInContext(src, sandbox, { filename: "client.js" });
check("bundle load + id", loaded?.id === "dsh-word-complete");

let stateSeq = 0;
const reactMock = {
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children: children.flat() }),
  useState: (init) => { const pair = [init, () => {}]; stateSeq += 1; return pair; },
  useMemo: (fn) => fn(),
  useEffect: (fn) => { try { fn(); } catch (e) {} return () => {}; },
  useRef: (init) => ({ current: init }),
};
const mod = loaded.factory((spec) => {
  if (spec === "react") return reactMock;
  throw new Error("unexpected require: " + spec);
});
check("导出 apply/inject", typeof mod.apply === "function" && Array.isArray(mod.inject));
check("inject 含 slots/sessions", mod.inject.includes("slots") && mod.inject.includes("sessions"));

// 纯函数
const t = mod.extractTest;
check("prefixAt: 英文前缀", JSON.stringify(t.prefixAt("hello wor", 9)) === JSON.stringify({ start: 6, end: 9 }));
check("prefixAt: 英文不足2字符不激活", t.prefixAt("h", 1) === null);
check("prefixAt: 中文1字激活", JSON.stringify(t.prefixAt("标", 1)) === JSON.stringify({ start: 0, end: 1 }));
check("prefixAt: 行首", JSON.stringify(t.prefixAt("hel", 3)) === JSON.stringify({ start: 0, end: 3 }));
check("prefixAt: 非法 caret", t.prefixAt("abc", 0) === null && t.prefixAt("abc", 99) === null);
check("prefixAt: / 后不激活", t.prefixAt("/skill", 6) === null);
check("prefixAt: \\ 后不激活", t.prefixAt("C:\\Users\\foo", 12) === null);
check("matchWords: 完全匹配最前且过滤不相关词", JSON.stringify(t.matchWords([{ w: "hello", c: 3 }, { w: "help", c: 2 }, { w: "hell", c: 5 }, { w: "world", c: 1 }], "hell")) === JSON.stringify(["hell", "hello"]));
check("matchWords: 前缀匹配按附加字符升序", JSON.stringify(t.matchWords([{ w: "hello", c: 3 }, { w: "help", c: 2 }, { w: "world", c: 1 }], "hel")) === JSON.stringify(["help", "hello"]));
check("matchWords: 以输入内容开头的词才会出现（ds→dsh 系列）", JSON.stringify(t.matchWords([{ w: "dsh", c: 5 }, { w: "dsh_workspace", c: 4 }, { w: "dsh-word-complete", c: 3 }, { w: "workspace", c: 2 }], "ds")) === JSON.stringify(["dsh", "dsh_workspace", "dsh-word-complete"]));
check("matchWords: 输入内容在后面的词被排除（adds/cards/words）", JSON.stringify(t.matchWords([{ w: "dsh", c: 5 }, { w: "dsh_workspace", c: 4 }, { w: "dsh-word-complete", c: 3 }, { w: "adds", c: 9 }, { w: "cards", c: 8 }, { w: "words", c: 7 }], "ds")) === JSON.stringify(["dsh", "dsh_workspace", "dsh-word-complete"]));
check("matchWords: 不以输入内容开头的词被过滤", JSON.stringify(t.matchWords([{ w: "receive", c: 5 }, { w: "received", c: 4 }, { w: "receiver", c: 2 }, { w: "hello", c: 1 }], "recieve")) === JSON.stringify([]));

// slot 注册 + inject 工厂
let reg = null;
const fakeActx = { bail: () => true };
const fakeCtx = {
  slots: { register: (o, c) => { reg = { o, c }; return () => {}; } },
  sessions: { scope: () => fakeActx },
  effect: (fn) => { fn(); return () => {}; },
};
mod.apply(fakeCtx);
check("注册 slot", reg?.o?.name === "conversation.input.overlay" && reg?.o?.id === "word-complete");
const injected = reg.o.inject("s1");
check("inject 返回 insertWord", typeof injected?.insertWord === "function");
check("insertWord 走 bail 事件", injected.insertWord("hello", { start: 0, end: 3, draftRev: 1 }) === true);

// 组件渲染（useInput mock：draft 空 → 不激活 → 渲染 null 不崩）
const useInput = (sel) => sel({ draft: "", draftRev: 0 });
const el = typeof reg.c === "function" ? reg.c({ sessionId: "s1", useInput, insertWord: injected.insertWord }) : null;
check("组件渲染不崩（无激活时返回 null）", el === null || el !== undefined);

const ok = results.every(([, v]) => v);
console.log(ok ? "\nALL PASS" : "\nHAS FAILURES");
process.exit(ok ? 0 : 1);
