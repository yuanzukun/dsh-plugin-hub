# dsh-word-complete 设计说明

Notepad++ Word Completion 风格的会话单词自动完成插件。本文记录关键设计决策与实现依据，便于后续维护与评审。

## 1. 总体架构

```
┌─────────────────────────── host（lib/index.js）───────────────────────────┐
│ 会话事件（sessions）→ 增量词频统计 → 内存缓存 + $DSH_HOME/word-complete.json │
│                         ↓ webServer                                      │
│              GET /api/word-complete/words?sessionId=                     │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓ JSON {words:[{w,c}],lastSeq}
┌─────────────────────────── client（lib/client.js）────────────────────────┐
│ 注册官方 slot conversation.input.overlay                                  │
│ 前缀检测 → 建议列表 → 光标定位（Range + 官方镜像）→ Portal 浮窗             │
│ 键盘 ↑/↓/Enter/ESC → 官方 slash/input-insert-text 事件插入                │
└───────────────────────────────────────────────────────────────────────────┘
```

## 2. host：词频管线（轻量、增量、零热路径磁盘 IO）

- **分词**（`extractWords`）：英文/标识符 `[A-Za-z0-9_$]+`、中文 `[\u4e00-\u9fff]+`、日文假名、韩文段；长度 2–40；纯数字丢弃（补全提示意义小）。短横线词（如 `dsh-session-nav`）被切分，与官方会话标题分词行为一致。
- **增量扫描**（`collectWordFreq`）：从 `lastSeq` 起只统计新增事件；`user/message` 与 `assistant/message` 两种事件类型。
- **合并**（`mergeWordCounts`）：Map 合并基线 + 增量，按词频降序、同频词典序，截断 topN（2000）。
- **缓存与持久化**（`wordsFor`）：内存缓存（50 会话）→ 未命中时增量扫描 → 冷启动读 `$DSH_HOME/word-complete.json` 基线；有新增时写回并做粗粒度清理（保留最近 30 个会话）。
- **信任边界**（`isTrusted`）：仅 loopback 或 `webRuntime.trustedHosts` 内的 Host 可访问端点，响应带 `no-cache`。

## 3. client：为什么这样测量光标

官方 InputBar 的 auto-grow 结构（`dsh-client-ui-conversation` 的 InputBar.module.css）：

- `.overlayAnchor{height:0; position:absolute; inset:0 0 auto}` —— overlay 槽位锚点是**卡片顶部 0 高度**元素，不适合做光标定位基准；
- textarea 是 `position:absolute; inset:0; overflow:hidden; color:#0000`（透明文字，视觉文本由 backdrop 层渲染），**自身永不滚动**；滚动发生在 `[data-input-scroll]` 容器上；
- textarea / `[data-input-mirror]` / backdrop 三者共享同一排版规则：`font-family:"DshChipCell",var(--dsw-font-family); padding:4px 12px 0 16px; white-space:pre-wrap; word-break:break-word; overflow-wrap:anywhere`，其中 DshChipCell 是官方 @font-face，保证 chip 占位符 U+FFFC 的宽度与真实芯片一致。

因此**在官方 mirror 的文本节点上用 Range 定位 caret 偏移**，`getBoundingClientRect()` 就是光标真实视口坐标：与 textarea 排版逐像素一致（含芯片宽度）、随滚动容器一起移动（无需手动修正 scrollTop）、不需要复制任何样式。mirror 不可用时退化为自建 mirror（复制 textarea 计算样式 + 滚动容器修正）。

浮窗经 `react-dom` 的 `createPortal` 渲染到 `document.body`（`position:fixed`），彻底脱离 overlay 锚点与 transform 祖先的干扰；定位公式：窗口底边在光标行顶上方 8px（上方空间不足则顶边在行底下方 8px），水平对齐光标 x 并 clamp 进视口。

## 4. 插入与交互决策

- **插入走官方事件** `actx.bail("slash/input-insert-text", {text, span})`（`span` 带 `draftRev` CAS 与撤销）——不直接操作 store，兼容后续官方改动。
- **回车确认 / ESC 关闭**后进入抑制状态，直到输入新的可打印字符或 Backspace/Delete（后者用于编辑刚插入的词后立即重新弹出）。
- **空格键完全放行**：不做空格确认（用户明确要求只保留回车确认），避免与正常输入冲突。
- **所选词与当前前缀完全相同**时，官方 `insertText` 是恒等替换（不产生草稿变化、界面无反应），因此特判为「确认当前词」：直接关闭窗口（同 ESC 路径），光标保持在词尾。
- **斜杠/反斜杠后不触发**：正在输入的词前紧邻 `/` 或 `\`（斜杠命令、文件路径、URL）时不激活补全，避免打扰用户通过 `/` 查找 skill 或输入路径。
- **只联想以输入内容开头的词**：为保证相关性，候选必须以当前输入内容**开头**（前缀匹配）；`adds`、`cards`、`words` 这类把输入放在中间的词即使词频很高也不会出现。例如输入 `ds` 会联想 `dsh`、`dsh_workspace`、`dsh-word-complete`。
- **建议按接近程度排序**：完全匹配（当前输入词本身）最前，其次附加字符更少（更接近），再词频更高，最后词典序，最多返回 8 条。因此窗口总是先显示「当前输入词本身或最接近的候选」，随后差异逐渐变大。
- 输入法组合（composition）期间不弹出；英文前缀 ≥2 字符、中日韩 1 字符即触发。

## 5. 验证

- `verify.mjs`：33 项断言，覆盖 host 分词/合并/持久化/增量、client bundle 形状、prefixAt/matchWords 纯函数、slot 注册与 insertWord 事件路径（vm 沙箱加载，无需浏览器）。
- 运行时验证清单：窗口出现在光标正上方并逐字跟随、多行草稿中跟随所在行、回车确定/↑↓ 选择/确定后 Backspace 重新弹出、输入框高度不受影响（浮窗经 Portal 渲染，不参与卡片布局）。
