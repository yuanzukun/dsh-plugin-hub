// src/index.ts — host plugin entry.
// Exposes /bilingual-reader/* HTTP routes so the client tab can extract PDF text and
// translate. Translation runs through the injected `llm` service in an ISOLATED call
// (never appends to the main conversation).
import { promises as fs } from 'node:fs';
import { createRequire } from 'node:module';
import * as path from 'node:path';
import { extractPdf } from './host/pdf.js';
import { chunkDocument } from './host/chunk.js';
import { extractGlossary } from './host/glossary.js';
import { createLlmGateway, type LlmGateway } from './host/llmClient.js';
import { translateSelection, detectTextLanguage, detectDomain } from './host/translate.js';
import { resolveModel } from './host/model.js';
import { startClipboardWatcher, type ClipboardWatcher } from './host/clipboard.js';
import type { TranslateRequest } from './types.js';

export const inject = ['llm', 'webServer'];

interface HttpReq { method?: string; url?: string; on: (e: 'data' | 'end' | 'error', cb: (...a: any[]) => void) => void }
interface HttpRes { writeHead: (code: number, headers?: Record<string, string>) => void; end: (body?: string | Buffer | Uint8Array) => void }

export function apply(ctx: { llm: unknown; webServer: unknown; effect: (fn: () => unknown, label?: string) => unknown }): void {
  const gateway: LlmGateway = createLlmGateway(ctx.llm);
  const nodeRequire = createRequire(import.meta.url);
  const pdfjsDir = path.dirname(nodeRequire.resolve('pdfjs-dist/package.json'));
  const ws = ctx.webServer as { register: (r: { kind: string; path: string; handler: (req: HttpReq, res: HttpRes) => void }) => () => void };

  // Single-document state: the extracted glossary is reused by /translate-selection.
  // Scoped inside `apply` so a hot reload creates a fresh set and the old fiber's
  // route disposer (see below) stops the stale one from being reachable.
  let glossary: Record<string, string> = {};

  // OS-clipboard watcher (no Electron): started lazily on the first clipboard
  // request and killed when the fiber unloads. DSH >= 2.0.9 runs the host in an
  // Electron utilityProcess where `require('electron')` is unavailable, so the
  // old electron.clipboard path is only a best-effort fast path now.
  let clipWatcher: ClipboardWatcher | null = null;
  const ensureClipWatcher = (): ClipboardWatcher => (clipWatcher ??= startClipboardWatcher());
  ctx.effect(() => () => { try { clipWatcher?.dispose(); } catch { /* ignore */ } clipWatcher = null; },
    'dsh-bilingual-reader: clipboard watcher');

  // Route registration goes through ctx.effect: the disposer returned by
  // webServer.register is collected and auto-invoked when the fiber unloads,
  // so HMR removes the old /bilingual-reader route (and its stale state)
  // before the reloaded plugin re-registers it.
  ctx.effect(() => ws.register({ kind: 'prefix', path: '/bilingual-reader', handler: async (req, res) => {
    const u = new URL(req.url ?? '/', 'http://x');
    const pathname = u.pathname;
    try {
      // Serve pdf.js CMap / standard-font data so the client's text layer can render
      // CJK + non-embedded fonts correctly (otherwise it falls back to a wrong font,
      // causing the text layer to misalign).
      if ((pathname.startsWith('/bilingual-reader/cmaps/') || pathname.startsWith('/bilingual-reader/standard_fonts/')) && req.method === 'GET') {
        const sub = pathname.startsWith('/bilingual-reader/cmaps/')
          ? path.join(pdfjsDir, 'cmaps', path.basename(pathname))
          : path.join(pdfjsDir, 'standard_fonts', path.basename(pathname));
        try {
          res.writeHead(200, { 'content-type': 'application/octet-stream', 'cache-control': 'no-cache' });
          res.end(await fs.readFile(sub));
        } catch { res.writeHead(404); res.end(); }
        return;
      }
      // Serve the original PDF so the client can embed it as the "原文".
      if (pathname === '/bilingual-reader/file' && req.method === 'GET') {
        const file = decodeURIComponent(u.searchParams.get('path') || '');
        const data = await fs.readFile(file);
        res.writeHead(200, { 'content-type': 'application/pdf', 'cache-control': 'no-cache' });
        res.end(data);
        return;
      }
      // Read the OS clipboard. Prefer Electron's clipboard when the host still
      // runs in an Electron process (older DSH); otherwise use the OS-level
      // watcher (DSH >= 2.0.9 host runs in a utilityProcess with no `electron`).
      if (pathname === '/bilingual-reader/clipboard' && req.method === 'GET') {
        let text = ''; let available = false; let debug: any = null;
        try {
          const electron = nodeRequire('electron') as any;
          if (electron?.clipboard?.readText) {
            available = true; text = String(electron.clipboard.readText() ?? '');
            debug = { source: 'electron' };
          }
        } catch { available = false; }
        if (!available) {
          const w = ensureClipWatcher();
          available = w.available();
          text = w.read();
          debug = { source: 'watcher', ...w.debug() };
        }
        return json(res, 200, { text, available, debug });
      }
      // Serve pdf.js's browser build + worker so the client can import them at runtime
      // (avoids bundling pdf.js into the __ModuleLoader__ client, and no native canvas).
      if (pathname === '/bilingual-reader/pdf.mjs' && req.method === 'GET') {
        const p = nodeRequire.resolve('pdfjs-dist/build/pdf.mjs');
        res.writeHead(200, { 'content-type': 'text/javascript; charset=utf-8', 'cache-control': 'no-cache' });
        res.end(await fs.readFile(p));
        return;
      }
      if (pathname === '/bilingual-reader/pdf.worker.mjs' && req.method === 'GET') {
        const p = nodeRequire.resolve('pdfjs-dist/build/pdf.worker.mjs');
        res.writeHead(200, { 'content-type': 'text/javascript; charset=utf-8', 'cache-control': 'no-cache' });
        res.end(await fs.readFile(p));
        return;
      }
      const body = await readJson(req);
      // List .pdf files under a workdir (recursively, bounded) so the loader tab can
      // offer a "browse" picker — no manual copy/paste of a full path. Self-contained
      // (Node fs), so the plugin stays independent of better-sidebar's internal API.
      if (pathname === '/bilingual-reader/list-pdfs' && req.method === 'POST') {
        const root = String(body?.dir ?? '');
        const limit = Math.max(1, Math.min(500, Number(body?.limit ?? 200) || 200));
        const depth = Math.max(0, Math.min(10, Number(body?.depth ?? 3) || 3));
        const files = await listPdfs(root, limit, depth);
        return json(res, 200, { dir: root, files });
      }
      if (pathname === '/bilingual-reader/extract' && req.method === 'POST') {
        const file = String(body?.path ?? '');
        const text = await extractPdf(file);
        // Only `text` and `glossary` travel back. Returning the chunks too used to
        // send the document twice — a PDF has no markdown headings, so the single
        // chunk holds the entire fullText verbatim.
        glossary = extractGlossary(chunkDocument(text));
        return json(res, 200, { text, glossary });
      }
      if (pathname === '/bilingual-reader/translate-selection' && req.method === 'POST') {
        const reqBody = body as unknown as TranslateRequest & { selection?: string; context?: string };
        const requestId = `sel-${Date.now()}`;
        const out = await translateSelection(gateway, reqBody.selection ?? '', reqBody.context ?? '', { ...reqBody, kind: 'selection', glossary }, new AbortController().signal, () => {}, requestId);
        return json(res, 200, { requestId, text: out });
      }
      // Classify a snippet's language (no translation). Used when the source is
      // "auto" and the heuristic detector is ambiguous.
      if (pathname === '/bilingual-reader/detect-language' && req.method === 'POST') {
        const text = String(body?.text ?? '');
        const p = typeof body?.provider === 'string' ? body.provider : undefined;
        const m = typeof body?.model === 'string' ? body.model : undefined;
        const lang = await detectTextLanguage(gateway, text, { provider: p, model: m });
        return json(res, 200, { lang });
      }
      // Classify a paper/snippet's field (no translation). Shown to the user so
      // they can see the judged domain (and optionally pin it).
      if (pathname === '/bilingual-reader/detect-domain' && req.method === 'POST') {
        const text = String(body?.text ?? '');
        const p = typeof body?.provider === 'string' ? body.provider : undefined;
        const m = typeof body?.model === 'string' ? body.model : undefined;
        const domain = await detectDomain(gateway, text, { provider: p, model: m });
        return json(res, 200, { domain });
      }
      return json(res, 404, { error: 'unknown route ' + pathname });
    } catch (e) {
      return json(res, 500, { error: e instanceof Error ? e.message : String(e) });
    }
  } }), 'dsh-bilingual-reader: /bilingual-reader routes');
}

function readJson(req: HttpReq): Promise<Record<string, unknown> | undefined> {
  return new Promise((resolve, reject) => {
    const parts: Buffer[] = [];
    req.on('data', (c: Buffer) => parts.push(c));
    req.on('end', () => {
      try { resolve(parts.length ? JSON.parse(Buffer.concat(parts).toString('utf8')) : undefined); }
      catch (e) { reject(e); }
    });
    req.on('error', (e) => reject(e));
  });
}

function json(res: HttpRes, code: number, payload: unknown): void {
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

// Recursively collect .pdf files under `dir` (bounded by count + depth so a huge
// or deeply nested workspace never hangs the request). Skips hidden dirs and
// node_modules. Returns paths sorted with newest first (most recent PDF on top).
async function listPdfs(dir: string, limit: number, depth: number): Promise<{ path: string; name: string }[]> {
  const out: { path: string; name: string; mtime: number }[] = [];
  const seen = new Set<string>();
  const skip = new Set(['node_modules', '.git', '.dsh', 'dist', 'build', '.pnpm-store', '.npm-cache']);
  const walk = async (d: string, level: number): Promise<void> => {
    if (out.length >= limit || level > depth) return;
    let entries;
    try { entries = await fs.readdir(d, { withFileTypes: true }); }
    catch { return; }
    for (const e of entries) {
      if (out.length >= limit) return;
      const full = path.join(d, e.name);
      if (!seen.has(full)) seen.add(full);
      if (e.isDirectory()) {
        if (e.name.startsWith('.') || skip.has(e.name)) continue;
        await walk(full, level + 1);
      } else if (e.isFile() && e.name.toLowerCase().endsWith('.pdf')) {
        try {
          const st = await fs.stat(full);
          out.push({ path: full, name: e.name, mtime: st.mtimeMs });
        } catch { /* ignore unreadable */ }
      }
    }
  };
  await walk(dir, 0);
  out.sort((a, b) => b.mtime - a.mtime);
  return out.slice(0, limit).map(({ path, name }) => ({ path, name }));
}
