// src/client/app.ts — client factory: (require) => module { inject, apply }.
// Registers a proper better-sidebar TAB and gives it a fetch-based controller that
// calls the host /bilingual-reader/* routes (extract + isolated translate).
// React is sourced from the factory's `require` (single DSH React instance).
import { makeReader } from './reader.js';
import { BTN_CLS, inputBase, injectPluginStyles } from './styles.js';
import type * as ReactNS from 'react';

async function post(path: string, body: unknown): Promise<any> {
  const res = await fetch(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body ?? {}),
  });
  // The host reports failures as { error } with a non-2xx status. Parsing that
  // like a normal result made a failed request indistinguishable from an empty
  // one: a rejected PDF load came back as `undefined`, and the reader then blamed
  // the PDF for having no extractable text instead of showing the real reason.
  // Always throw on a non-OK status so the message actually reaches the user.
  // The body is read as text first, because a fenced route answers with plain
  // "forbidden" and JSON.parse would then hide the status entirely.
  const raw = await res.text();
  let data: any = null;
  try { data = raw ? JSON.parse(raw) : null; } catch { /* not JSON (e.g. 403 text) */ }
  if (!res.ok) {
    const detail = (data && typeof data.error === 'string')
      ? data.error
      : (raw ? raw.slice(0, 300) : '(空响应)');
    throw new Error(`HTTP ${res.status} ${detail}`);
  }
  return data;
}

// A "translate / languages" glyph matching better-sidebar's 16px outline icon
// style: stroke uses currentColor, no fill, so it inherits the tab's ink and
// adapts to light/dark automatically. Hand-built SVG (no icon dep).
function languageIcon(h: (...args: any[]) => any, size: number): any {
  return h('svg', {
    width: size, height: size, viewBox: '0 0 24 24',
    fill: 'none', stroke: 'currentColor', strokeWidth: 2,
    strokeLinecap: 'round', strokeLinejoin: 'round',
  },
    h('path', { d: 'M5 8l6 6' }),
    h('path', { d: 'M4 14l6-6 2-3' }),
    h('path', { d: 'M2 5h12' }),
    h('path', { d: 'M7 2h1' }),
    h('path', { d: 'm22 22-5-10-5 10' }),
    h('path', { d: 'M14 18h6' }),
  );
}

export function makeClientFactory(): (require: (m: string) => unknown) => { inject: string[]; apply: (ctx: unknown) => void } {
  return (require) => {
    const react = require('react') as typeof ReactNS;
    const { useState, useEffect } = react;
    const h = react.createElement as any;
    const BilingualReader = makeReader({ h, useState, useEffect: react.useEffect as any, useCallback: react.useCallback as any, useRef: react.useRef as any });

    const controller = {
      loadDocument: (file: string) => post('/bilingual-reader/extract', { path: file }),
      listPdfs: (dir: string, limit = 200) => post('/bilingual-reader/list-pdfs', { dir, limit }),
      detectLanguage: async (text: string) => {
        const r = await post('/bilingual-reader/detect-language', { text });
        return (r && typeof r.lang === 'string') ? r.lang : '';
      },
      detectDomain: async (text: string) => {
        const r = await post('/bilingual-reader/detect-domain', { text });
        return (r && typeof r.domain === 'string') ? r.domain : '';
      },
      translateSelection: async (req: any, _signal: AbortSignal, _emit: (e: any) => void) => {
        const r = await post('/bilingual-reader/translate-selection', req);
        if (r && typeof r.text === 'string') return r.text;
        throw new Error((r && r.error) || ('translate-selection failed: ' + JSON.stringify(r)));
      },
    };

    function ReaderTab(props: any): any {
      const scope = props?.scope;
      const cwd: string = scope?.cwd ?? '';
      const [path, setPath] = useState('');
      const [chosen, setChosen] = useState('');
      const [browsing, setBrowsing] = useState(false);
      const [pdfs, setPdfs] = useState<{ path: string; name: string }[]>([]);
      const [browseErr, setBrowseErr] = useState('');
      const [loading, setLoading] = useState(false);

      // Lazy-load the PDF list when the picker is opened.
      useEffect(() => {
        if (!browsing || !cwd) return;
        let cancelled = false;
        setLoading(true);
        setBrowseErr('');
        controller.listPdfs(cwd, 200)
          .then((r: any) => { if (!cancelled) setPdfs(Array.isArray(r?.files) ? r.files : []); })
          .catch((e: any) => { if (!cancelled) { setPdfs([]); setBrowseErr('列出 PDF 失败：' + (e instanceof Error ? e.message : String(e))); } })
          .finally(() => { if (!cancelled) setLoading(false); });
        return () => { cancelled = true; };
      }, [browsing, cwd]);

      const pick = (p: string) => { setPath(p); setChosen(p); setBrowsing(false); };

      return h('div', { style: { padding: 12, display: 'flex', flexDirection: 'column', gap: 8, height: '100%' } },
        h('div', { style: { display: 'flex', gap: 8 } },
          h('input', { value: path, placeholder: '粘贴或输入 PDF 路径…', onChange: (e: any) => setPath(e.target.value), style: { ...inputBase, flex: 1 } }),
          h('button', { onClick: () => setChosen(path), className: BTN_CLS }, '加载'),
          h('button', { onClick: () => setBrowsing(v => !v), className: BTN_CLS }, '浏览…'),
        ),
        browsing
          ? h('div', { style: { border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 6, maxHeight: 300, overflow: 'auto', padding: 8, display: 'flex', flexDirection: 'column', gap: 4 } },
              loading
                ? h('p', { style: { color: 'var(--dsw-alias-label-tertiary)', fontSize: 13, padding: '6px 8px' } }, '正在扫描 PDF…')
                : browseErr
                  ? h('p', { style: { color: 'var(--dsw-alias-state-error-primary)', fontSize: 13, padding: '6px 8px' } }, browseErr)
                  : pdfs.length === 0
                    ? h('p', { style: { color: 'var(--dsw-alias-label-tertiary)', fontSize: 13, padding: '6px 8px' } }, cwd ? ('未找到 PDF：' + cwd) : '未提供工作区目录。')
                    : pdfs.map((p) => {
                        const idx = p.path.lastIndexOf('\\');
                        const dir = idx >= 0 ? p.path.slice(0, idx) : '';
                        const file = idx >= 0 ? p.path.slice(idx + 1) : p.path;
                        return h('button', {
                          key: p.path,
                          onClick: () => pick(p.path),
                          style: { textAlign: 'left', border: 'none', background: 'transparent', color: 'var(--dsw-alias-label-primary)', borderRadius: 4, padding: '6px 8px', cursor: 'pointer', display: 'flex', flexDirection: 'column', gap: 2, width: '100%' },
                        },
                          h('span', { style: { fontSize: 13, fontWeight: 500, wordBreak: 'break-all' } }, file),
                          dir ? h('span', { style: { fontSize: 11, color: 'var(--dsw-alias-label-tertiary)', wordBreak: 'break-all', lineHeight: 1.4 } }, dir) : undefined,
                        );
                      }),
            )
          : undefined,
        chosen
          ? h(BilingualReader, { file: chosen, controller })
          : h('p', { style: { color: 'var(--dsw-alias-label-tertiary)', fontSize: 13 } }, '输入一个 PDF 路径，点「加载」开始双语阅读；或点「浏览…」从工作区选择。'),
      );
    }

    const inject = ['betterSidebar', 'slots', 'locale'];
    const apply = (ctx: unknown) => {
      const c = ctx as {
        betterSidebar?: unknown;
        locale?: { getSnapshot: () => { active: string } };
        effect: (fn: () => unknown, label?: string) => unknown;
      };
      const bs = c.betterSidebar as { registerTab: (d: unknown) => () => void } | undefined;
      if (!bs) return;
      // Inject the plugin's shared CSS via ctx.effect so a hot reload (fiber
      // unload) removes the old <style> tag instead of leaking it.
      c.effect(() => injectPluginStyles(), 'dsh-bilingual-reader: plugin styles');
      // DSH i18n: the active locale comes from ctx.locale (same source better-sidebar's
      // own tabs use). This `title` feeds the + menu and the settings card, so there we
      // show the localized name: Chinese UI → "翻译", English UI → "translator".
      const isZh = () =>
        (c.locale?.getSnapshot?.().active ?? (typeof navigator !== 'undefined' ? navigator.language : ''))
          .toLowerCase()
          .startsWith('zh');
      c.effect(() =>
        bs.registerTab({
          id: 'bilingual-reader',
          title: () => (isZh() ? '翻译' : 'translator'),
          icon: (size: number) => languageIcon(h, size),
          // Tab-BAR label. The tab bar renders the title frozen into tab.title when the
          // tab is opened (it does NOT call title() live like the + menu does), so the
          // user wants the tab strip to always read English "translator". We mint the
          // tab ourselves so the stored title is a fixed English string regardless of
          // the active UI language.
          single: true,
          createTab: () => ({
            tab: { id: 'bilingual-reader', type: 'bilingual-reader', title: 'translator' },
          }),
          component: ReaderTab,
        }),
      );
    };

    return { inject, apply };
  };
}
