import type { TranslateEvent, TranslateRequest } from '../types.js';
import type { LlmGateway } from './llmClient.js';
export declare function translateSelection(llm: LlmGateway, selection: string, context: string, req: TranslateRequest, signal: AbortSignal, emit: (e: TranslateEvent) => void, requestId: string): Promise<string>;
export declare function detectTextLanguage(llm: LlmGateway, text: string, overrides?: {
    provider?: string;
    model?: string;
}): Promise<string>;
export declare function detectDomain(llm: LlmGateway, text: string, overrides?: {
    provider?: string;
    model?: string;
}): Promise<string>;
