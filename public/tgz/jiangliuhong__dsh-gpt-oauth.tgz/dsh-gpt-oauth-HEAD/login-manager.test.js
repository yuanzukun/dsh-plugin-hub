import test from 'node:test'
import assert from 'node:assert/strict'
import { LoginManager } from './login-manager.js'

const provider = { id: 'openai-codex-gptoauth' }

function store() {
  let value
  return {
    read: async () => value,
    list: async () => [],
    modify: async (_id, mutate) => { value = (await mutate(value)) ?? value; return value },
    delete: async () => { value = undefined },
    seed: (next) => { value = next },
  }
}

test('starts device-code login, exposes verification details, and succeeds', async () => {
  const credentials = store()
  let release
  const finished = new Promise((resolve) => { release = resolve })
  const manager = new LoginManager({
    provider,
    credentials,
    authContext: {},
    modelsFactory: () => ({
      setProvider() {},
      async login(id, type, interaction) {
        assert.equal(id, provider.id)
        assert.equal(type, 'oauth')
        assert.equal(await interaction.prompt({ type: 'select', message: 'Method', options: [{ id: 'device_code', label: 'Device' }] }), 'device_code')
        interaction.notify({ type: 'device_code', verificationUri: 'https://example.test/device', userCode: 'ABCD-EFGH', expiresInSeconds: 60 })
        await finished
        credentials.seed({ type: 'oauth', access: 'opaque' })
      },
    }),
  })

  const started = await manager.start()
  assert.equal(started.status, 'starting')
  await new Promise(setImmediate)
  assert.equal((await manager.status()).session.status, 'awaiting_authorization')
  assert.equal((await manager.status()).session.userCode, 'ABCD-EFGH')
  release()
  await new Promise(setImmediate)
  assert.equal((await manager.status()).session.status, 'succeeded')
  assert.equal((await manager.status()).configured, true)
})

test('returns the active session and cancellation aborts it', async () => {
  const credentials = store()
  const manager = new LoginManager({
    provider,
    credentials,
    authContext: {},
    modelsFactory: () => ({
      setProvider() {},
      login: (_id, _type, interaction) => new Promise((_resolve, reject) => {
        interaction.signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true })
      }),
    }),
  })

  const first = await manager.start()
  const second = await manager.start()
  assert.equal(second.id, first.id)
  assert.equal(manager.cancel().status, 'cancelled')
  await new Promise(setImmediate)
  assert.equal((await manager.status()).session.status, 'cancelled')
})

test('logout removes the stored grant', async () => {
  const credentials = store()
  credentials.seed({ type: 'oauth', access: 'opaque' })
  const manager = new LoginManager({ provider, credentials, authContext: {}, modelsFactory: () => ({}) })
  assert.equal((await manager.status()).configured, true)
  await manager.logout()
  assert.equal((await manager.status()).configured, false)
  assert.equal((await manager.status()).session, null)
})
