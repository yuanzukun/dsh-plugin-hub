# dsh-login-chatgpt

[English](README.md) | 中文

这是一个 DeepSeek Harness 插件，用于添加 `openai-codex-gptoauth` Provider 路由和独立的 **ChatGPT Login** 设置页面。该路由继承已安装的 `openai-codex` 模型目录，并使用 Pi 官方的 ChatGPT OAuth 设备码登录流程，无需 OpenAI API Key。

## 安装

### 从 npm 安装（推荐）

```sh
dsh plugin --profile web add dsh-login-chatgpt
```

安装指定版本：

```sh
dsh plugin --profile web add dsh-login-chatgpt@0.2.5
```

npm 包：<https://www.npmjs.com/package/dsh-login-chatgpt>

### 从本地源码安装（开发用途）

```sh
git clone git@github.com:jiangliuhong/dsh-gpt-oauth.git
cd dsh-gpt-oauth
npm install
dsh plugin --profile web add "$PWD"
```

插件包会自动安装 authorization 服务，并使用标准 `web` profile 提供的 `llm` 和 `credentials` 服务。

启动 Harness：

```sh
dsh web
```

## 使用

1. 打开 **Settings → ChatGPT Login**。
2. 点击 **Login with ChatGPT**。
3. 打开页面中显示的 OpenAI 授权地址，并输入一次性设备码。
4. 等待设置页面显示 **Connected**。
5. 在会话输入区域点击 **Select model**。
6. 点击 **Model / Select model** 条目，打开完整模型目录。
7. 滚动到 `openai-codex-gptoauth`，选择其中一个 GPT 模型。

该路由显示在会话的模型选择器中，不会显示在 **Models** 设置页面。

登录凭据由 DSH credentials 服务保存在 `llm-pi-ai/openai-codex-gptoauth` 下。模型请求会自动复用并刷新该 OAuth 凭据。OAuth Token 不会返回浏览器；浏览器只会收到登录状态、验证地址和一次性设备码。

## 本地登录接口

客户端插件通过 `127.0.0.1:3091` 上仅监听回环地址的辅助服务完成登录。该服务只接受来自回环地址 Origin 的浏览器请求。如果端口被占用，插件会明确启动失败，而不会静默禁用登录功能。

## 开发检查

```sh
node --check index.js
node --check login-manager.js
node --check client.js
node --test login-manager.test.js
```

## 发布

在 `package.json` 和 `package-lock.json` 中更新版本号并提交，然后推送匹配的 Tag。支持 `0.2.0` 和 `v0.2.0` 两种格式：

```sh
npm version 0.2.1 --no-git-tag-version
git add package.json package-lock.json
git commit -m "release: v0.2.1"
git tag v0.2.1
git push origin main v0.2.1
```

Tag 工作流会运行检查，按照 `package.json` 中的版本发布 npm 包，并通过 npm Trusted Publishing（OIDC）创建带 provenance 的包和 GitHub Release。完成首次包初始化后，后续发布不再需要 npm Token 或本地执行 `npm publish`。

## 致谢

感谢 [LINUX DO](https://linux.do/) 社区一直以来的支持。
