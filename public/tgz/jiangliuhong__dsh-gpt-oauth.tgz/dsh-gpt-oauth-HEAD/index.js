import { createServer } from 'node:http'
import { createModels } from '@earendil-works/pi-ai'
import { builtinProviders } from '@earendil-works/pi-ai/providers/all'
import { PiAiAdapter } from '@deepseek-ai/dsh-llm-pi-ai'
import { credentialKey } from '@deepseek-ai/dsh-credentials'
import { LoginManager } from './login-manager.js'

export const name = 'login-chatgpt'
export const inject = ['llm', 'authorization', 'credentials']

const SOURCE_PROVIDER = 'openai-codex'
const PROVIDER = 'openai-codex-gptoauth'
const KEY = credentialKey('llm-pi-ai', PROVIDER)
const LOGIN_PORT = 3091

export async function apply(ctx) {
  const source = builtinProviders().find((entry) => entry.id === SOURCE_PROVIDER)
  if (!source?.auth?.oauth) throw new Error(`${name}: installed pi-ai has no ChatGPT OAuth provider`)

  const sourceModels = await source.getModels()
  const aliasedModels = sourceModels.map((model) => ({ ...model, provider: PROVIDER }))
  const provider = {
    ...source,
    id: PROVIDER,
    name: PROVIDER,
    getModels: () => aliasedModels,
    stream: (model, context, options) => source.stream(model, context, options),
    streamSimple: (model, context, options) => source.streamSimple(model, context, options),
  }
  const credentials = credentialStore(ctx.get('credentials'))
  const authContext = {
    async env(variable) { return process.env[variable] },
    async fileExists() { return false },
  }
  const profile = {
    provider: PROVIDER,
    displayName: PROVIDER,
    piProvider: provider,
    configuredMaxTokens: new Map(),
    streamIdleTimeoutMs: 300000,
    maxRequestImageBytes: 20 * 1024 * 1024,
    requestImagePixelBudget: 4 * 1024 * 1024,
    requestImageMaxBytes: 1024 * 1024,
  }
  const profiles = new Map([[PROVIDER, profile]])
  const adapter = new PiAiAdapter({
    profiles: () => profiles,
    resolveApiKey: async () => undefined,
    auth: { credentials, authContext },
    resolveAttachments: () => ctx.get('attachments'),
  })

  ctx.llm.registerAdapter([PROVIDER], adapter)

  const manager = new LoginManager({ provider, credentials, authContext })
  const server = createLoginServer(manager)
  await listen(server, LOGIN_PORT)
  ctx.effect(() => () => server.close(), `${name}: close login server`)
  ctx.logger.info(`${name}: registered ${PROVIDER} (${aliasedModels.length} models); login UI API on http://127.0.0.1:${LOGIN_PORT}`)

  if (!ctx.authorization.describe(KEY)) {
    ctx.authorization.registerFlow({
      key: KEY,
      label: 'ChatGPT for openai-codex-gptoauth',
      methods: [{ id: 'oauth', label: 'Login with ChatGPT' }],
      async run(session) {
        const models = createModels({ credentials, authContext })
        models.setProvider(provider)
        await models.login(PROVIDER, 'oauth', {
          signal: session.signal,
          notify: (event) => notify(session, event),
          prompt: (prompt) => session.prompt(toAuthorizationPrompt(prompt)),
        })
      },
    })
  }
}

function createLoginServer(manager) {
  return createServer(async (request, response) => {
    try {
      const origin = request.headers.origin
      if (origin && !isLoopbackOrigin(origin)) return json(response, 403, { error: 'Origin not allowed' })
      if (origin) response.setHeader('Access-Control-Allow-Origin', origin)
      response.setHeader('Vary', 'Origin')
      response.setHeader('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS')
      response.setHeader('Access-Control-Allow-Headers', 'Content-Type')
      if (request.method === 'OPTIONS') return void response.writeHead(204).end()

      const url = new URL(request.url ?? '/', 'http://127.0.0.1')
      if (url.pathname === '/dsh-login-chatgpt/status' && request.method === 'GET') {
        return json(response, 200, await manager.status())
      }
      if (url.pathname === '/dsh-login-chatgpt/login' && request.method === 'POST') {
        return json(response, 202, await manager.start())
      }
      if (url.pathname === '/dsh-login-chatgpt/login' && request.method === 'DELETE') {
        return json(response, 200, { session: manager.cancel() })
      }
      if (url.pathname === '/dsh-login-chatgpt/credential' && request.method === 'DELETE') {
        await manager.logout()
        return json(response, 200, { configured: false, session: null })
      }
      return json(response, 404, { error: 'Not found' })
    } catch (error) {
      ctxlessError(error)
      return json(response, 500, { error: error instanceof Error ? error.message : 'Internal error' })
    }
  })
}

function listen(server, port) {
  return new Promise((resolve, reject) => {
    server.once('error', reject)
    server.listen(port, '127.0.0.1', () => {
      server.off('error', reject)
      resolve()
    })
  })
}

function json(response, status, value) {
  response.statusCode = status
  response.setHeader('Content-Type', 'application/json; charset=utf-8')
  response.setHeader('Cache-Control', 'no-store')
  response.end(JSON.stringify(value))
}

function isLoopbackOrigin(origin) {
  try {
    const url = new URL(origin)
    return (url.protocol === 'http:' || url.protocol === 'https:') &&
      (url.hostname === '127.0.0.1' || url.hostname === 'localhost' || url.hostname === '::1')
  } catch {
    return false
  }
}

function ctxlessError(error) {
  console.error(`${name}: login API failed`, error)
}

function notify(session, event) {
  if (event.type === 'device_code') {
    session.notify({ message: 'Enter this code on the ChatGPT verification page.', url: event.verificationUri, code: event.userCode })
  } else if (event.type === 'auth_url') {
    session.notify({ message: event.instructions ?? 'Continue signing in in your browser.', url: event.url })
  } else if (event.type === 'info' || event.type === 'progress') {
    session.notify({ message: event.message, ...(event.links?.[0] ? { url: event.links[0].url } : {}) })
  }
}

function toAuthorizationPrompt(prompt) {
  if (prompt.type === 'select') return { kind: 'select', message: prompt.message, options: prompt.options, ...(prompt.signal ? { signal: prompt.signal } : {}) }
  return { kind: prompt.type === 'secret' ? 'secret' : 'text', message: prompt.message, ...(prompt.placeholder ? { placeholder: prompt.placeholder } : {}), ...(prompt.signal ? { signal: prompt.signal } : {}) }
}

function credentialStore(credentials) {
  return {
    async read(providerId) {
      if (providerId !== PROVIDER) return undefined
      const record = await credentials.readRecord(KEY)
      return record?.kind === 'grant' ? record.payload : undefined
    },
    async list() {
      const record = await credentials.readRecord(KEY)
      return record?.kind === 'grant'
        ? [{ providerId: PROVIDER, type: record.payload.type }]
        : []
    },
    async modify(providerId, mutate) {
      if (providerId !== PROVIDER) return undefined
      const record = await credentials.modifyRecord(KEY, async (current) => {
        const next = await mutate(current?.kind === 'grant' ? current.payload : undefined)
        return next === undefined ? current : { kind: 'grant', payload: next }
      })
      return record?.kind === 'grant' ? record.payload : undefined
    },
    async delete(providerId) {
      if (providerId === PROVIDER) await credentials.deleteRecord(KEY)
    },
  }
}
