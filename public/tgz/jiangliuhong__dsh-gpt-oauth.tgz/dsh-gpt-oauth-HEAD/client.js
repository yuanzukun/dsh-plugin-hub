window.__ModuleLoader__.load({
  id: 'dsh-login-chatgpt',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
    const React = require('react')

    const API = `http://${window.location.hostname === 'localhost' ? 'localhost' : '127.0.0.1'}:3091/dsh-login-chatgpt`
    const inject = ['slots']

    function ChatGptLoginSection() {
      const [state, setState] = React.useState({ configured: false, session: null })
      const [loading, setLoading] = React.useState(true)
      const [busy, setBusy] = React.useState(false)
      const [error, setError] = React.useState(null)
      const active = state.session?.status === 'starting' || state.session?.status === 'awaiting_authorization'

      const refresh = React.useCallback(async () => {
        try {
          const response = await fetch(`${API}/status`, { cache: 'no-store' })
          if (!response.ok) throw new Error(await responseError(response))
          setState(await response.json())
          setError(null)
        } catch (failure) {
          setError(failure instanceof Error ? failure.message : 'Unable to check ChatGPT login status')
        } finally {
          setLoading(false)
        }
      }, [])

      React.useEffect(() => { void refresh() }, [refresh])
      React.useEffect(() => {
        if (!active) return undefined
        const timer = window.setInterval(() => void refresh(), 1000)
        return () => window.clearInterval(timer)
      }, [active, refresh])

      async function action(path, method) {
        setBusy(true)
        setError(null)
        try {
          const response = await fetch(`${API}/${path}`, { method })
          if (!response.ok) throw new Error(await responseError(response))
          await refresh()
        } catch (failure) {
          setError(failure instanceof Error ? failure.message : 'ChatGPT action failed')
        } finally {
          setBusy(false)
        }
      }

      const session = state.session
      return React.createElement('div', { className: 'dsh-gpt-oauth-page', style: styles.page },
        React.createElement('style', null, '@media (max-width: 600px) { .dsh-gpt-oauth-page { position: fixed; inset: 80px 16px 16px; z-index: 1000; overflow: auto; padding: 0; background: var(--background, #2b2b2d); } }'),
        React.createElement('div', { style: styles.card },
          React.createElement('div', { style: styles.headingRow },
            React.createElement('div', null,
              React.createElement('h2', { style: styles.heading }, 'ChatGPT Login'),
              React.createElement('p', { style: styles.subheading }, 'Authenticate openai-codex-gptoauth with your ChatGPT Plus or Pro account.'),
            ),
            React.createElement('span', { style: state.configured ? styles.goodBadge : styles.mutedBadge }, state.configured ? 'Connected' : 'Not connected'),
          ),
          loading ? React.createElement('p', { style: styles.muted }, 'Checking login status…') : null,
          session?.status === 'starting' ? React.createElement('p', { style: styles.muted }, 'Requesting a device code from ChatGPT…') : null,
          session?.status === 'awaiting_authorization' ? React.createElement('div', { style: styles.codePanel },
            React.createElement('p', { style: styles.muted }, 'Open the ChatGPT authorization page and enter this one-time code:'),
            React.createElement('div', { style: styles.code }, session.userCode),
            React.createElement('a', { href: session.verificationUri, target: '_blank', rel: 'noreferrer', style: styles.primaryLink }, 'Open ChatGPT authorization'),
          ) : null,
          session?.status === 'succeeded' ? React.createElement('p', { style: styles.success }, 'ChatGPT authorization completed. You can now select openai-codex-gptoauth models.') : null,
          session?.status === 'failed' ? React.createElement('p', { style: styles.error }, session.error || 'ChatGPT login failed') : null,
          error ? React.createElement('p', { style: styles.error }, error) : null,
          React.createElement('div', { style: styles.actions },
            active
              ? React.createElement('button', { type: 'button', disabled: busy, onClick: () => void action('login', 'DELETE'), style: styles.secondaryButton }, 'Cancel login')
              : state.configured
                ? React.createElement('button', { type: 'button', disabled: busy, onClick: () => void action('credential', 'DELETE'), style: styles.dangerButton }, busy ? 'Disconnecting…' : 'Disconnect ChatGPT')
                : React.createElement('button', { type: 'button', disabled: busy || loading, onClick: () => void action('login', 'POST'), style: styles.primaryButton }, busy ? 'Starting…' : 'Login with ChatGPT'),
            React.createElement('button', { type: 'button', disabled: busy, onClick: () => void refresh(), style: styles.secondaryButton }, 'Refresh'),
          ),
        ),
        React.createElement('div', { style: styles.card },
          React.createElement('h3', { style: styles.smallHeading }, 'Use the model'),
          React.createElement('ol', { style: styles.steps },
            React.createElement('li', null, 'Complete ChatGPT login above.'),
            React.createElement('li', null, 'Close Settings and click Select model in the conversation composer.'),
            React.createElement('li', null, 'Click the Model / Select model row to open the full catalog.'),
            React.createElement('li', null, 'Scroll to ', React.createElement('code', { style: styles.inlineCode }, 'openai-codex-gptoauth'), ' and choose a GPT model.'),
          ),
          React.createElement('p', { style: styles.muted }, 'This route appears in the conversation model selector, not on the Models settings page. OAuth credentials stay in the DSH server credential store and are never returned to this browser.'),
        ),
      )
    }

    async function responseError(response) {
      try { return (await response.json()).error || `Request failed (${response.status})` }
      catch { return `Request failed (${response.status})` }
    }

    const styles = {
      page: { display: 'grid', gap: '16px', maxWidth: '760px', minWidth: 0 },
      card: { border: '1px solid var(--border, #d8d8d8)', borderRadius: '12px', padding: '14px', background: 'var(--surface, transparent)', minWidth: 0, overflow: 'hidden', overflowWrap: 'anywhere' },
      headingRow: { display: 'grid', gap: '10px', minWidth: 0 },
      heading: { margin: 0, fontSize: '20px' },
      smallHeading: { margin: '0 0 12px', fontSize: '16px' },
      subheading: { margin: '8px 0 16px', color: '#a3a3a3', lineHeight: 1.5 },
      muted: { color: '#a3a3a3', lineHeight: 1.5 },
      goodBadge: { padding: '4px 9px', borderRadius: '999px', color: '#166534', background: '#dcfce7', fontSize: '12px', justifySelf: 'start' },
      mutedBadge: { padding: '4px 9px', borderRadius: '999px', color: '#525252', background: '#e5e5e5', fontSize: '12px', justifySelf: 'start' },
      codePanel: { padding: '16px', borderRadius: '10px', background: 'var(--muted, #f5f5f5)', margin: '12px 0' },
      code: { fontFamily: 'monospace', fontWeight: 700, fontSize: '20px', letterSpacing: '2px', textAlign: 'center', margin: '16px 0', userSelect: 'all', overflowWrap: 'anywhere' },
      primaryLink: { display: 'block', padding: '10px', borderRadius: '8px', background: '#2563eb', color: '#fff', textAlign: 'center', textDecoration: 'none', overflowWrap: 'anywhere' },
      actions: { display: 'grid', gap: '10px', marginTop: '16px' },
      primaryButton: { width: '100%', padding: '9px 10px', borderRadius: '8px', border: 0, background: '#2563eb', color: '#fff', cursor: 'pointer', whiteSpace: 'normal', overflowWrap: 'anywhere' },
      secondaryButton: { width: '100%', padding: '9px 10px', borderRadius: '8px', border: '1px solid #a3a3a3', background: 'transparent', color: 'inherit', cursor: 'pointer', whiteSpace: 'normal' },
      dangerButton: { width: '100%', padding: '9px 10px', borderRadius: '8px', border: 0, background: '#dc2626', color: '#fff', cursor: 'pointer', whiteSpace: 'normal' },
      success: { color: '#15803d' },
      error: { color: '#dc2626', whiteSpace: 'pre-wrap' },
      steps: { paddingLeft: '18px', lineHeight: 1.8, overflowWrap: 'anywhere' },
      inlineCode: { padding: '2px 5px', borderRadius: '4px', background: 'rgba(127,127,127,.2)', color: 'inherit' },
    }

    function apply(ctx) {
      ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: 'chatgpt-login',
        order: 15,
        label: () => 'ChatGPT Login',
      }, ChatGptLoginSection))
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  },
})
