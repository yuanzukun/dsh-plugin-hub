import { randomUUID } from 'node:crypto'
import { createModels } from '@earendil-works/pi-ai'

const SESSION_TTL_MS = 10 * 60 * 1000
const RETENTION_MS = 5 * 60 * 1000

export class LoginManager {
  constructor({ provider, credentials, authContext, now = Date.now, modelsFactory }) {
    this.provider = provider
    this.credentials = credentials
    this.authContext = authContext
    this.now = now
    this.modelsFactory = modelsFactory ?? (() => createModels({ credentials, authContext }))
    this.sessions = new Map()
  }

  async status() {
    this.cleanup()
    const record = await this.credentials.read(this.provider.id)
    const active = [...this.sessions.values()].find((entry) => isActive(entry.status))
    const latest = active ?? [...this.sessions.values()].sort((a, b) => b.createdAt - a.createdAt)[0]
    return {
      configured: record !== undefined,
      session: latest ? snapshot(latest) : null,
    }
  }

  async start() {
    this.cleanup()
    const active = [...this.sessions.values()].find((entry) => isActive(entry.status))
    if (active) return snapshot(active)

    const createdAt = this.now()
    const session = {
      id: randomUUID(),
      status: 'starting',
      verificationUri: null,
      userCode: null,
      error: null,
      createdAt,
      expiresAt: createdAt + SESSION_TTL_MS,
      removeAt: createdAt + SESSION_TTL_MS + RETENTION_MS,
      controller: new AbortController(),
    }
    this.sessions.set(session.id, session)
    session.task = this.run(session)
    return snapshot(session)
  }

  cancel() {
    const session = [...this.sessions.values()].find((entry) => isActive(entry.status))
    if (!session) return null
    session.status = 'cancelled'
    session.error = null
    session.controller.abort()
    return snapshot(session)
  }

  async logout() {
    this.cancel()
    await this.credentials.delete(this.provider.id)
    this.sessions.clear()
  }

  async run(session) {
    try {
      const models = this.modelsFactory()
      models.setProvider(this.provider)
      await models.login(this.provider.id, 'oauth', {
        signal: session.controller.signal,
        notify: (event) => {
          if (event.type !== 'device_code') return
          session.status = 'awaiting_authorization'
          session.verificationUri = event.verificationUri
          session.userCode = event.userCode
          if (event.expiresInSeconds) {
            session.expiresAt = this.now() + event.expiresInSeconds * 1000
            session.removeAt = session.expiresAt + RETENTION_MS
          }
        },
        prompt: async (prompt) => {
          if (prompt.type === 'select') {
            const deviceCode = prompt.options.find((option) => option.id === 'device_code')
            if (deviceCode) return deviceCode.id
          }
          throw new Error(`Unsupported ChatGPT login prompt: ${prompt.type}`)
        },
      })
      if (session.status !== 'cancelled') {
        session.status = 'succeeded'
        session.error = null
      }
    } catch (error) {
      if (session.status === 'cancelled') return
      session.status = 'failed'
      session.error = error instanceof Error ? error.message : 'ChatGPT login failed'
    }
  }

  cleanup() {
    const now = this.now()
    for (const [id, session] of this.sessions) {
      if (isActive(session.status) && session.expiresAt <= now) {
        session.status = 'failed'
        session.error = 'ChatGPT login session expired'
        session.controller.abort()
      }
      if (!isActive(session.status) && session.removeAt <= now) this.sessions.delete(id)
    }
  }
}

function isActive(status) {
  return status === 'starting' || status === 'awaiting_authorization'
}

function snapshot(session) {
  return {
    id: session.id,
    status: session.status,
    verificationUri: session.verificationUri,
    userCode: session.userCode,
    error: session.error,
    expiresAt: new Date(session.expiresAt).toISOString(),
  }
}
