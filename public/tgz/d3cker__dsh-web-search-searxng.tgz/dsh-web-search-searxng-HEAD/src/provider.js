/**
 * `SearxngSearchProvider`: a `WebSearchProvider` backed by a self-hosted
 * SearXNG instance's JSON API (`GET {base}/search?q=...&format=json`).
 * Maps each `results[]` entry's `content` to `snippet`, `publishedDate` to
 * `publishedAt`, and omits `content` because SearXNG returns no generated
 * answer.
 *
 * Plain ESM — no build step — so it runs inside a dsh profile directly.
 */

import { WebError } from '@deepseek-ai/dsh-web'

/** Stable id this provider registers under. */
export const SEARXNG_PROVIDER_ID = 'searxng'

/** Default SearXNG endpoint base; the search operation is `{base}/search`. */
export const SEARXNG_DEFAULT_BASE_URL = 'http://localhost:8888'

/** Default result count when a request carries no `maxResults`. */
export const SEARXNG_DEFAULT_NUM_RESULTS = 10

/** Attribution header sent on every request. */
const USER_AGENT = 'dsh-web-search-searxng/0.1.0'

/**
 * Map one SearXNG result to a normalized source, or `undefined` when it has no
 * URL (an entry without a URL cannot be cited and is dropped). A blank snippet
 * is omitted rather than invented.
 * @param result - one entry of SearXNG's `results[]`.
 * @returns the normalized source, or `undefined` when the entry has no URL.
 */
export function mapSearxngResult(result) {
  if (result.url == null || result.url.length === 0) return undefined
  return {
    url: result.url,
    ...(result.title != null && result.title.length > 0 ? { title: result.title } : {}),
    ...(result.content != null && result.content.trim().length > 0 ? { snippet: result.content } : {}),
    ...(result.publishedDate != null && result.publishedDate.length > 0 ? { publishedAt: result.publishedDate } : {}),
  }
}

/**
 * Map a SearXNG JSON response envelope to a normalized search result. Entries
 * without a URL are dropped; everything else maps, preserving the instance's
 * relevance order.
 * @param response - the parsed `GET /search` response body.
 * @returns the normalized result.
 */
export function mapSearxngResponse(response) {
  const sources = (response.results ?? [])
    .map(mapSearxngResult)
    .filter((source) => source !== undefined)
  // SearXNG returns no generated answer, so `content` is omitted. The web
  // service owns the final `maxResults` truncation, so this provider reports
  // `truncated: false`.
  return { sources, truncated: false }
}

/** The SearXNG-backed search provider; HTTP redirects fail as `WEB_PROVIDER_ERROR`. */
export class SearxngSearchProvider {
  constructor(resolveOptions) {
    /** Stable id this provider registers under. */
    this.id = SEARXNG_PROVIDER_ID
    /**
     * The options for the NEXT operation, snapshotted once at each operation's
     * entry. A thunk so settings changes apply to the next search without
     * re-registering the provider.
     */
    this.resolveOptions = resolveOptions
  }

  available() {
    const options = this.resolveOptions()
    return URL.canParse(options.baseURL)
      && (options.numResults === undefined || Number.isInteger(options.numResults) && options.numResults > 0)
  }

  async search(request, signal) {
    const options = this.resolveOptions()
    const endpoint = new URL('/search', options.baseURL)
    endpoint.searchParams.set('q', request.query)
    endpoint.searchParams.set('format', 'json')
    if (options.apiKey != null && options.apiKey.length > 0) {
      endpoint.searchParams.set('preference[api_key]', options.apiKey)
    }

    let response
    try {
      response = await fetch(endpoint, {
        method: 'GET',
        redirect: 'error',
        headers: {
          'accept': 'application/json',
          'user-agent': USER_AGENT,
        },
        ...(signal !== undefined ? { signal } : {}),
      })
    } catch (error) {
      if (isAbortError(error)) throw new WebError('SearXNG search aborted', 'WEB_ABORTED', { cause: error })
      throw new WebError(`SearXNG search request failed: ${String(error)}`, 'WEB_PROVIDER_ERROR', { cause: error })
    }

    if (!response.ok) {
      const status = response.status
      let message = `SearXNG API error (HTTP ${status})`
      try {
        const parsed = await response.json()
        const detail = parsed?.error ?? parsed?.message
        if (detail != null && detail.length > 0) message = detail
      } catch (error) {
        if (isAbortError(error)) throw new WebError('SearXNG search aborted', 'WEB_ABORTED', { cause: error })
      }
      throw new WebError(message, 'WEB_PROVIDER_ERROR')
    }

    try {
      const payload = await response.json()
      return mapSearxngResponse(payload)
    } catch (error) {
      if (isAbortError(error)) throw new WebError('SearXNG search aborted', 'WEB_ABORTED', { cause: error })
      throw new WebError(`SearXNG returned an unprocessable response body: ${String(error)}`, 'WEB_PROVIDER_ERROR', { cause: error })
    }
  }
}

/** True for a fetch/`AbortSignal` abort, surfaced as `WEB_ABORTED`. */
export function isAbortError(error) {
  return error instanceof DOMException && error.name === 'AbortError'
}
