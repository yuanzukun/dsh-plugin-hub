/**
 * `dsh-web-search-searxng`: registers a SearXNG-backed `WebSearchProvider`
 * with `ctx.web`, plus an editable settings section. A function/namespace
 * plugin (NOT a default-export service): it registers INTO the seam, which is
 * owned by `@deepseek-ai/dsh-web`.
 *
 * Plain ESM — no build step.
 */

import { launchEnvironmentOf } from '@deepseek-ai/dsh-launch-environment'
import z from '@deepseek-ai/schemastery'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import {
  SearxngSearchProvider,
  SEARXNG_DEFAULT_BASE_URL,
  SEARXNG_DEFAULT_NUM_RESULTS,
  SEARXNG_PROVIDER_ID,
} from './provider.js'

export { SEARXNG_PROVIDER_ID, SEARXNG_DEFAULT_BASE_URL, SEARXNG_DEFAULT_NUM_RESULTS, SearxngSearchProvider } from './provider.js'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'web-search-searxng'

/** The web seam this provider registers into. */
export const inject = ['web']

/** Settings namespace carrying this provider's endpoint, result count, and optional key. */
export const SEARXNG_SETTINGS_NAMESPACE = settingsNamespace('web-search-searxng')

/** The plugin's config schema. All fields optional — defaults apply otherwise. */
export const Config = z.object({
  apiKey: z.string().role('secret'),
  baseURL: z.string(),
  numResults: z.number().step(1).min(1),
})

/**
 * Project one resolved section into the options the provider serves its next
 * search with. Environment fallbacks stay here rather than in the provider:
 * every value it reads is already fully defaulted.
 */
function resolveOptions(ctx, config) {
  const literalApiKey = config.apiKey !== undefined && config.apiKey.length > 0
    ? config.apiKey
    : undefined
  return {
    apiKey: literalApiKey ?? launchEnvironmentOf(ctx).get('SEARXNG_API_KEY')?.value ?? '',
    baseURL: config.baseURL ?? SEARXNG_DEFAULT_BASE_URL,
    numResults: config.numResults ?? SEARXNG_DEFAULT_NUM_RESULTS,
  }
}

/**
 * Register the SearXNG search provider with `ctx.web` and expose its config
 * as a settings section.
 * @param ctx - plugin context.
 * @param config - the composition-entry configuration for this row.
 */
export function apply(ctx, config) {
  // The provider reads the active config source per search, so a committed
  // settings change needs no re-registration.
  let current = () => config
  installSettingsSection(ctx, SEARXNG_SETTINGS_NAMESPACE, Config, config, {
    setSource: (source) => { current = source },
    onChange: () => {},
  })
  ctx.web.registerSearchProvider(
    new SearxngSearchProvider(() => resolveOptions(ctx, current())),
  )
}
