/**
 * Behavior spec for the standalone SearXNG plugin. Mirrors the upstream
 * suite (34 tests) and runs with vitest. The package's peer dependencies
 * (`@deepseek-ai/dsh-web`, `@deepseek-ai/cordis`, …) must be resolvable:
 * in a DeepSeek Harness checkout they resolve from the profile module
 * fallback, so running `pnpm test` here with `NODE_PATH` pointing at the
 * checked-out harness usually just works too.
 */
import { describe, it, expect, vi, afterEach } from 'vitest'
import * as searxngPlugin from '../src/index.js'
import { SearxngSearchProvider, SEARXNG_DEFAULT_NUM_RESULTS, SEARXNG_PROVIDER_ID } from '../src/provider.js'
import { mapSearxngResponse, mapSearxngResult } from '../src/provider.js'

const options = { apiKey: '', baseURL: 'https://searxng.test', numResults: 5 }

/** Wrap provider options in the resolve thunk the provider snapshots per search. */
function provider(opts = options) {
  return new SearxngSearchProvider(() => opts)
}

function jsonResponse(body, init = {}) {
  return new Response(JSON.stringify(body), { status: 200, headers: { 'content-type': 'application/json' }, ...init })
}

afterEach(() => {
  vi.unstubAllGlobals()
})

describe('SearXNG result mapping', () => {
  it('maps a full result entry', () => {
    expect(mapSearxngResult({
      url: 'https://a.test',
      title: 'A',
      content: 'snippet text',
      publishedDate: '2026-01-01',
    })).toEqual({ url: 'https://a.test', title: 'A', snippet: 'snippet text', publishedAt: '2026-01-01' })
  })

  it('drops a result with no URL (uncitable)', () => {
    expect(mapSearxngResult({ url: '', title: 'no url' })).toBeUndefined()
  })

  it('omits null/empty optional fields rather than emitting them', () => {
    expect(mapSearxngResult({ url: 'https://a.test', title: null, content: null, publishedDate: null }))
      .toEqual({ url: 'https://a.test' })
    expect(mapSearxngResult({ url: 'https://a.test', title: '', content: '', publishedDate: '' }))
      .toEqual({ url: 'https://a.test' })
  })

  it('trims whitespace-only snippets out', () => {
    expect(mapSearxngResult({ url: 'https://a.test', content: '   ' })).toEqual({ url: 'https://a.test' })
  })

  it('maps a response to a result with no content and filtered sources', () => {
    const result = mapSearxngResponse({
      query: 'q',
      results: [
        { url: 'https://a.test', content: 'one' },
        { url: '', title: 'no url' },
        { url: 'https://c.test', title: 'C', content: 'three' },
      ],
    })
    expect(result).toEqual({
      sources: [
        { url: 'https://a.test', snippet: 'one' },
        { url: 'https://c.test', title: 'C', snippet: 'three' },
      ],
      truncated: false,
    })
    expect(result.content).toBeUndefined()
  })

  it('tolerates a missing results array', () => {
    expect(mapSearxngResponse({ query: 'q', results: undefined }).sources).toEqual([])
  })
})

describe('SearxngSearchProvider availability', () => {
  it('is available with a parseable base URL', () => {
    expect(provider().available()).toBe(true)
  })

  it('is misconfigured when the base URL is unparseable', () => {
    expect(provider({ ...options, baseURL: 'not a url' }).available()).toBe(false)
  })

  it('is misconfigured when numResults is set but not a positive integer', () => {
    expect(provider({ ...options, numResults: 0 }).available()).toBe(false)
    expect(provider({ ...options, numResults: 1.5 }).available()).toBe(false)
  })

  it('is available without a key', () => {
    expect(provider({ ...options, apiKey: '' }).available()).toBe(true)
  })
})

describe('SearxngSearchProvider request mapping', () => {
  it('sends q and format=json, no key, on a GET with redirects rejected', async () => {
    const fetchMock = vi.fn(() => Promise.resolve(jsonResponse({ query: 'hello', results: [] })))
    vi.stubGlobal('fetch', fetchMock)

    await provider().search({ query: 'hello', maxResults: 5 })

    expect(fetchMock).toHaveBeenCalledOnce()
    const [url, init] = fetchMock.mock.calls[0]
    expect(String(url)).toBe('https://searxng.test/search?q=hello&format=json')
    expect(init).toMatchObject({ method: 'GET', redirect: 'error' })
    expect(init.body).toBeUndefined()
  })

  it('encodes queries into the URL', async () => {
    const fetchMock = vi.fn(() => Promise.resolve(jsonResponse({ query: 'a b&c', results: [] })))
    vi.stubGlobal('fetch', fetchMock)
    await provider().search({ query: 'a b&c' })
    const [url] = fetchMock.mock.calls[0]
    expect(String(url)).toContain('q=a+b%26c')
  })

  it('sends the api key as preference[api_key] when configured', async () => {
    const fetchMock = vi.fn(() => Promise.resolve(jsonResponse({ query: 'q', results: [] })))
    vi.stubGlobal('fetch', fetchMock)
    await provider({ ...options, apiKey: 'secret' }).search({ query: 'q' })
    const [url] = fetchMock.mock.calls[0]
    expect(String(url)).toContain('preference%5Bapi_key%5D=secret')
  })

  it('forwards the abort signal', async () => {
    const fetchMock = vi.fn(() => Promise.resolve(jsonResponse({ query: 'q', results: [] })))
    vi.stubGlobal('fetch', fetchMock)
    const controller = new AbortController()
    await provider().search({ query: 'q' }, controller.signal)
    const [, init] = fetchMock.mock.calls[0]
    expect(init.signal).toBe(controller.signal)
  })
})

describe('SearxngSearchProvider error handling', () => {
  it('maps an HTTP error to WEB_PROVIDER_ERROR with the provider message', async () => {
    vi.stubGlobal('fetch', () => Promise.resolve(jsonResponse({ error: 'bad key' }, { status: 401 })))
    await expect(provider().search({ query: 'q' }))
      .rejects.toThrow(expect.objectContaining({ code: 'WEB_PROVIDER_ERROR', message: 'bad key' }))
  })

  it('keeps a status-line message when the error body is not JSON', async () => {
    vi.stubGlobal('fetch', () => Promise.resolve(new Response('gateway down', { status: 502 })))
    await expect(provider().search({ query: 'q' }))
      .rejects.toThrow(expect.objectContaining({ code: 'WEB_PROVIDER_ERROR', message: 'SearXNG API error (HTTP 502)' }))
  })

  it('maps a network failure to WEB_PROVIDER_ERROR', async () => {
    vi.stubGlobal('fetch', () => Promise.reject(new TypeError('connection refused')))
    await expect(provider().search({ query: 'q' }))
      .rejects.toThrow(expect.objectContaining({ code: 'WEB_PROVIDER_ERROR' }))
  })

  it('maps an abort to WEB_ABORTED', async () => {
    vi.stubGlobal('fetch', () => Promise.reject(new DOMException('aborted', 'AbortError')))
    await expect(provider().search({ query: 'q' }))
      .rejects.toThrow(expect.objectContaining({ code: 'WEB_ABORTED' }))
  })

  it('maps an unparseable success body to WEB_PROVIDER_ERROR', async () => {
    vi.stubGlobal('fetch', () => Promise.resolve(new Response('not json', { status: 200 })))
    await expect(provider().search({ query: 'q' }))
      .rejects.toThrow(expect.objectContaining({ code: 'WEB_PROVIDER_ERROR' }))
  })
})

describe('plugin surface', () => {
  it('exposes stable constants', () => {
    expect(SEARXNG_PROVIDER_ID).toBe('searxng')
    expect(SEARXNG_DEFAULT_NUM_RESULTS).toBe(10)
    expect(searxngPlugin.SEARXNG_PROVIDER_ID).toBe('searxng')
    expect(typeof searxngPlugin.apply).toBe('function')
  })
})
