/**
 * Custom instructions editor client plugin — registers the settings page
 * (设置 → 自定义指令) into `settings.section`. The page edits the global
 * instruction file (~/.dsh/AGENTS.md) served by the host route family.
 */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls the renderer-owned ctx.slots service merge in DSH 0.1.2+.
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
// Type-only: pulls the settings-surface SlotMap merge (the 'settings.section'
// entry).
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import {
  CSS,
  CustomInstructionsSection,
  DICTIONARIES,
  LOCALE_NS,
} from './InstructionsSection.tsx'

/** Required services. */
export const inject = ['slots', 'locale']

/**
 * Register the custom-instructions settings page.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(
    () => ctx.locale.register(LOCALE_NS, DICTIONARIES),
    'custom-instructions: locale',
  )

  ctx.effect(() => {
    const style = document.createElement('style')
    style.dataset.plugin = '@huanghai-lab/dsh-custom-instructions'
    style.textContent = CSS
    document.head.appendChild(style)
    return () => style.remove()
  }, 'custom-instructions: styles')

  const t = ctx.locale.bind(LOCALE_NS)
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'custom-instructions',
    order: 25,
    label: () => t('sectionLabel'),
    locale: LOCALE_NS,
  }, CustomInstructionsSection))
}
