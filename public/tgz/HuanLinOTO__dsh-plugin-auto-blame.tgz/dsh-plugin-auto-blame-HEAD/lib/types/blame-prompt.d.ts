/**
 * Pure prompt construction + response parsing for auto-blame.
 *
 * These functions have zero runtime dependencies on DSH platform packages —
 * they take plain data and return plain data. The host-side LLM call lives
 * in {@link ./blame-llm.ts}, which imports the DSH LLM and session seams.
 *
 * @module @huanlin/dsh-plugin-auto-blame/blame-prompt
 */
import type { Message } from '@deepseek-ai/dsh-llm';
import type { BlameSuggestion } from './types.ts';
/** The system instruction that frames the LLM as a cynical reader. */
export declare const BLAME_SYSTEM_PROMPT: string;
/** The number of trailing messages to feed the LLM as context. */
export declare const CONTEXT_MESSAGE_COUNT = 3;
/** The exact number of suggestions the LLM must produce. */
export declare const EXPECTED_SUGGESTION_COUNT = 3;
/** Hard cap on suggestion length, to keep bubbles readable. */
export declare const MAX_SUGGESTION_CHARS = 200;
/** Cap on LLM output tokens; three short sentences never need more. */
export declare const MAX_OUTPUT_TOKENS = 1024;
/**
 * Build the user-facing prompt that carries the recent conversation.
 * @param messages - the last up-to-three surface messages.
 * @returns the user-role content, or null when there is nothing to blame.
 */
export declare function buildBlameUserPrompt(messages: Message[]): string | null;
/**
 * Parse the LLM's raw text output into exactly three suggestions. Accepts a
 * bare JSON object `{"suggestions": [...]}`. Strips a single ```json fenced
 * block if present (defensive — the system prompt forbids it). Rejects any
 * shape that does not yield exactly three non-empty trimmed strings.
 * @param raw - the assembled LLM output.
 * @returns the three suggestions, or null when the output is unparseable.
 */
export declare function parseBlameSuggestions(raw: string): BlameSuggestion[] | null;
