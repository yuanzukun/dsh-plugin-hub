/**
 * dsh-auto-blame — host plugin entry.
 *
 * Listens on `agent/turn-stopping` (serial). When a turn closes, the listener
 * gates on the `enabled` settings flag — false returns immediately, no LLM
 * call, no projection event, no bubbles. True fires off a background LLM
 * call that asks the agent's own provider for three cynical follow-up
 * prompts based on the last three surface messages. The call is fire-and-
 * forget — the listener returns immediately so the serial checkpoint is not
 * delayed; the LLM may take hundreds of milliseconds and that is fine, the
 * bubbles fade in when they arrive.
 *
 * On success the host appends an `auto-blame/suggestions` session event
 * (non-surface, never enters model-visible history) carrying the three
 * suggestions. The `autoBlame` projection unit folds that event into the
 * `autoBlame` cell, which the api-proxy carrier serves on the history tail
 * page and the `session/projection` push frame. The browser half reads it
 * through `useProjection('autoBlame')` and renders click-to-send bubbles in
 * `conversation.composer.dock`.
 *
 * Any failure (no `llm` service, no provider/model, LLM error, unparseable
 * output) resolves to null and the listener skips the append — the user sees
 * no bubbles for that turn, no log pollution.
 *
 * The `enabled` master switch persists through the settings seam under the
 * `auto-blame` namespace in `$DSH_HOME/settings.yaml` when a settings
 * provider is mounted; the cordis.yml `enabled` field is the composition
 * `base` (first-boot seed). The browser half's settings page reads/writes
 * the flag through a dedicated `/auto-blame` RPC channel. Headless
 * assemblies without a settings provider fall back to in-memory state
 * (cordis.yml seed only, no persistence).
 *
 * @module @huanlin/dsh-plugin-auto-blame
 */
import type { Context } from '@deepseek-ai/cordis';
import z from 'schemastery';
export type * from './types.ts';
export declare const name = "dsh-auto-blame";
/** `connection` is required for the RPC channel that backs the settings page. */
export declare const inject: string[];
/** Settings namespace under which the `enabled` flag persists (`$DSH_HOME/settings.yaml`). */
export declare const SETTINGS_NAMESPACE: import("@deepseek-ai/dsh-settings").SettingsNamespace;
export interface Config {
    enabled: boolean;
}
export declare const Config: z<Config>;
/**
 * Plugin body: register the projection unit, the turn-stopping listener
 * (gated on `enabled`), and the RPC channel for the settings page.
 *
 * Persistence: when a settings service is mounted, the `enabled` flag lives
 * under the `auto-blame` namespace in `$DSH_HOME/settings.yaml`; the
 * cordis.yml `enabled` field is the composition `base` (first-boot seed).
 * External edits (a hand-edited yaml) reload the in-memory value; the next
 * turn-stopping reads through. Headless assemblies without a settings
 * provider fall back to in-memory state (cordis.yml seed, no persistence).
 * @param ctx - host context carrying `connection`.
 * @param config - resolved config (seed `enabled`).
 */
export declare function apply(ctx: Context, config: Config): void;
