/**
 * The `autoBlame` projection unit: folds `auto-blame/generating` and
 * `auto-blame/suggestions` session events into the latest state.
 * `generating: true` while the LLM call is in-flight; `generating: false`
 * with the suggestions array once results land. `null` before the first
 * generation and cleared on `turn/start`.
 *
 * @module @huanlin/dsh-plugin-auto-blame/projection
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { AutoBlameProjection } from './types.ts';
/**
 * Pure fold: previous state + one committed event → next state. Returns the
 * same state reference for events that are not ours (an unchanged reference
 * produces zero downstream work per the projection contract). Exported for
 * direct unit testing.
 * @param state - the current projection state.
 * @param event - the next committed session event.
 * @returns the next state (same reference when the event is not ours).
 */
export declare function foldAutoBlame(state: AutoBlameProjection, event: SessionEvent): AutoBlameProjection;
/**
 * Register the `autoBlame` projection unit on the session-projection registry,
 * if the registry is composed. Headless assemblies without the seam stay
 * unaffected. `stateVersion: 3` — the state now carries a `generating` flag.
 * @param ctx - the host context that may carry `ctx.sessionProjections`.
 */
export declare function registerAutoBlameProjection(ctx: Context): void;
