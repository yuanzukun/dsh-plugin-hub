/**
 * dsh-auto-blame — browser half.
 *
 * Two registrations:
 *   - `conversation.composer.dock` list slot (id `dsh-auto-blame`, order 60) —
 *     renders three click-to-send cynical follow-up bubbles. The host
 *     generates them from the last three surface messages via an LLM call on
 *     `agent/turn-stopping` (gated by the `enabled` settings flag); the
 *     `autoBlame` projection cell carries them to the client through the
 *     standard-kit `useProjection` seat. When the host `enabled` flag is
 *     false, no LLM call runs, the projection stays null, and this component
 *     renders nothing — the gate is host-side, not client-side.
 *   - `settings.section` list slot (id `dsh-auto-blame`, order 70) — the
 *     master `enabled` toggle. Reads/writes through the `/auto-blame` RPC
 *     channel, which the host persists to `$DSH_HOME/settings.yaml`.
 *
 * A click feeds the suggestion text to the input machine — the same path the
 * InputBar uses: `inputActions.setDraft(text)` then `inputActions.submit()`.
 *
 * @module @huanlin/dsh-plugin-auto-blame/client
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type AutoBlameKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The bubble title + send-hint copy + settings page labels. */
        'dsh-auto-blame': AutoBlameKey;
    }
}
/** Required services: slots + locale + connection (for the settings RPC). */
export declare const inject: string[];
/**
 * Client plugin body: register the suggestion bubbles in the composer dock
 * and the master toggle in the settings dialog.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
