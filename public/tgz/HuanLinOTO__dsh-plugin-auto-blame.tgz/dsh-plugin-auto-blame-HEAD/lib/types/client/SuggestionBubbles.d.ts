/**
 * SuggestionBubbles — three click-to-send cynical follow-up prompts.
 *
 * Reads the `autoBlame` projection (host-generated LLM suggestions for the
 * just-closed turn) through the standard-kit `useProjection` seat. While the
 * host LLM call is in-flight (`generating: true`), renders the "领导视野"
 * label with a DeepSeek-brand shimmer gradient (matching the "Deep diving..."
 * turn-status effect). When suggestions land, the label transitions to its
 * normal color and the bubbles fade-slide in with a staggered entrance.
 *
 * A click feeds the text to the input machine — `inputActions.setDraft(text)`
 * then `inputActions.submit()` — the same path the InputBar uses.
 *
 * The click is ignored while the input machine is not in the `plain` phase
 * (e.g. while a turn is streaming) to avoid clobbering an in-flight submit.
 *
 * @module @huanlin/dsh-plugin-auto-blame/client/SuggestionBubbles
 */
import type { PropsRuntime, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
/** Full props: dock runtime share + locale seat. */
type SuggestionBubblesProps = PropsRuntime<'conversation.composer.dock'> & PropsLocale<'dsh-auto-blame'>;
/**
 * Render the suggestion bubbles or the loading shimmer.
 * @param props - dock runtime share + locale seat.
 * @returns the bubble row, the loading label, or null.
 */
export declare function SuggestionBubbles({ useProjection, useInput, inputActions, t }: SuggestionBubblesProps): import("react").JSX.Element | null;
export {};
