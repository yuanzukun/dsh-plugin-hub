/**
 * AutoBlameSection — the `dsh-auto-blame` settings page: a master toggle.
 *
 * Registered as a `settings.section` slot entry. One row: the `enabled`
 * switch and its description. Styled with inline rules, mirroring
 * dsh-anti-ads's section — every colour is inherited or a neutral alpha so
 * the page follows the host's light and dark themes without knowing which
 * one is on.
 *
 * The toggle writes through the `/auto-blame` RPC channel
 * (`auto-blame/settings.set`), which the host persists through the settings
 * seam to `$DSH_HOME/settings.yaml`. The host's `agent/turn-stopping`
 * listener reads the same flag on the next turn and skips the LLM call
 * entirely when false — no token cost, no projection event, no bubbles.
 * This is a true host-side gate, not a client-side hide.
 *
 * @module @huanlin/dsh-plugin-auto-blame/client/AutoBlameSection
 */
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ClientConnectionRpc } from '@deepseek-ai/dsh-client-connection/client';
/** Inject face: RPC handle for the `/auto-blame` channel. */
export interface AutoBlameSectionInjected {
    readonly rpc: ClientConnectionRpc;
}
/** Full props: settings.section runtime share + locale seat + inject. */
type AutoBlameSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'dsh-auto-blame'> & AutoBlameSectionInjected;
/**
 * Render the auto-blame settings page.
 *
 * Loads the current `enabled` value through RPC on mount; the toggle writes
 * through RPC and optimistically updates the local state. A failed load
 * falls back to `true` (a freshly installed plugin runs) and surfaces the
 * error so the user knows the host round-trip failed.
 * @param props - settings.section runtime share + locale + inject.
 * @returns the section content column.
 */
export declare function AutoBlameSection({ rpc, t }: AutoBlameSectionProps): import("react").JSX.Element;
export {};
