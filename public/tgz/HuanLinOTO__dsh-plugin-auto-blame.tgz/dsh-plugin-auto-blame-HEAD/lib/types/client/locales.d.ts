/**
 * Locale dictionaries for the `dsh-auto-blame` namespace.
 *
 * @module @huanlin/dsh-plugin-auto-blame/client/locales
 */
/** The locale keys the bubbles component + settings page read. */
export type AutoBlameKey = 'title' | 'send' | 'empty' | 'settings.nav' | 'settings.enabled.label' | 'settings.enabled.description' | 'settings.disabled.note';
/** The locale namespace name; matches the `locale: NS` passed at slot register. */
export declare const NS = "dsh-auto-blame";
/** English dictionary. */
export declare const en: Record<AutoBlameKey, string>;
/** Chinese dictionary. */
export declare const zh: Record<AutoBlameKey, string>;
