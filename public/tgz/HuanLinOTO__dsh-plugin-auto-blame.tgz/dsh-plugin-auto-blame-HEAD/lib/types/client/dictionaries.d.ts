/**
 * Override dictionaries for the `dsh-auto-blame` namespace, keyed by the
 * language ids the better-locale plugin ships. Keys mirror the `en`/`zh`
 * dictionaries in `locales.ts`; this module is registered with the
 * better-locale override store when that plugin is installed.
 *
 * @module @huanlin/dsh-plugin-auto-blame/client/dictionaries
 */
import type { AutoBlameKey } from './locales.ts';
export declare const dicts: Record<string, Record<AutoBlameKey, string>>;
