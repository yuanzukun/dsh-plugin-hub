/**
 * Host-side LLM call for auto-blame: derive recent messages, build the call
 * options, drain the stream, and parse the three suggestions.
 *
 * This module imports the DSH LLM and session seams at runtime; the pure
 * prompt/parsing functions live in {@link ./blame-prompt.ts} so they can be
 * unit-tested without resolving the DSH workspace packages.
 *
 * @module @huanlin/dsh-plugin-auto-blame/blame-llm
 */
import type { Context } from '@deepseek-ai/cordis';
import type { GenerateOptions, Message, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { Session } from '@deepseek-ai/dsh-session';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { BlameSuggestion } from './types.ts';
/**
 * Derive the last {@link CONTEXT_MESSAGE_COUNT} model-visible messages from
 * the session surface. The surface already excludes chunks, boundaries, and
 * empty-content assistant messages, so what remains is the human-readable
 * conversation. Empty session → empty array.
 * @param session - the agent's live session.
 * @returns the last up-to-three messages, oldest-first.
 */
export declare function deriveRecentMessages(session: Session): Message[];
/**
 * Assemble the {@link GenerateOptions} for the blame call. Uses the agent's
 * own provider/model, a tight max-tokens cap, and no tools — the LLM has one
 * job: emit three short strings.
 * @param agent - the agent whose turn just closed.
 * @param userPrompt - the user-role content carrying the recent conversation.
 * @returns the assembled options, ready for `ctx.llm.stream()`.
 */
export declare function buildBlameCallOptions(agent: Agent, userPrompt: string): GenerateOptions;
/**
 * Drain an LLM stream into a single string. Adapters emit `block-start` /
 * `text-delta` / `block-end` / `finish`; this consumes text-delta only and
 * returns the assembled text. A non-`stop` finish or an empty result yields
 * null so the caller can skip the session append.
 * @param stream - the async iterable of chunks from `ctx.llm.stream()`.
 * @returns the assembled text, or null on empty/aborted/error finish.
 */
export declare function drainTextStream(stream: AsyncIterable<StreamChunk>): Promise<string | null>;
/**
 * Pre-check: whether all conditions for generation are met (llm service
 * available, provider/model set, non-empty session). Used by the caller to
 * decide whether to emit the `auto-blame/generating` loading signal — if this
 * returns false, generation would be silently skipped, so no loading UI.
 * @param ctx - host context carrying the `llm` service.
 * @param agent - the agent whose turn just closed.
 * @returns true if `generateBlameSuggestions` will proceed past pre-checks.
 */
export declare function canGenerateBlame(ctx: Context, agent: Agent): boolean;
/**
 * End-to-end: derive recent messages, build the prompt, call the LLM, parse
 * the three suggestions. Resolves to null on any failure (empty session, no
 * provider/model, LLM error, unparseable output) so the caller can skip the
 * session append without a try/catch ladder.
 * @param ctx - host context carrying the `llm` service.
 * @param agent - the agent whose turn just closed.
 * @returns three suggestions, or null.
 */
export declare function generateBlameSuggestions(ctx: Context, agent: Agent): Promise<BlameSuggestion[] | null>;
