/**
 * RPC handler: the `enabled` master switch over a dedicated Connection
 * channel (`/auto-blame`). The shared `/api` channel is reserved for a
 * single interceptor; ordinary plugins register their own channel with
 * `ctx.connection.rpc.handle(channel, ...)`.
 *
 * Endpoints (all POST, payload shape noted):
 *   - `settings.get`  payload: {}                    → { enabled: boolean }
 *   - `settings.set`  payload: { enabled: boolean }  → { enabled: boolean } | error
 *
 * Returns the existing RpcResult shape; business errors use the `internal`
 * code with a descriptive message (the RpcError code union is closed; we do
 * not extend it for plugin-specific failures).
 *
 * @module @huanlin/dsh-plugin-auto-blame/rpc
 */
import type { Context } from '@deepseek-ai/cordis';
/** Wire shape for `auto-blame/settings.get` and `settings.set` responses. */
export interface SettingsResponse {
    readonly enabled: boolean;
}
/** Wire shape for `auto-blame/settings.set` request payloads. */
export interface SettingsSetPayload {
    readonly enabled: boolean;
}
/** The dedicated RPC channel carrying every dsh-auto-blame endpoint. */
export declare const CHANNEL = "/auto-blame";
/**
 * Register the dsh-auto-blame RPC channel.
 *
 * The `getEnabled` thunk reads through to the settings scope when one is
 * attached (live value), or the in-memory fallback otherwise. The
 * `setEnabled` writer persists through the scope when available, or updates
 * the in-memory fallback (no persistence across restarts in headless mode).
 *
 * Uses `ctx.inject(['connection'], ...)` so the channel installs when the
 * connection service is ready and rolls back automatically on fiber
 * disposal.
 * @param ctx - host context.
 * @param getEnabled - thunk returning the current `enabled` value.
 * @param setEnabled - writer persisting the next `enabled` value.
 */
export declare function registerAutoBlameRpc(ctx: Context, getEnabled: () => boolean, setEnabled: (enabled: boolean) => Promise<void>): void;
