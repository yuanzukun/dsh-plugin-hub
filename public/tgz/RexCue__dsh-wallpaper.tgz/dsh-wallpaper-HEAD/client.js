window.__ModuleLoader__.load({
	id: "dsh-wallpaper",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });

		// ─────────────────────────────────────────────────────────────
		// dsh-wallpaper — 图片壁纸皮肤插件
		// 原理：在 <body> 里插入两个固定全屏层（背景 <img> + 压暗遮罩），
		// 并把 #root 抬到 z-index:1，再把 --dsw-alias-* 语义 token 改成
		// 半透明，让图片从所有面板后面透出来。
		// 右下角小面板可调：图片透明度 / 面板透明度 / 压暗遮罩 / 模糊。
		// 配置存在 localStorage，纯 DOM 实现，不依赖任何框架服务。
		// ─────────────────────────────────────────────────────────────

		const LS_KEY = "dsh-wallpaper:v1";

		// localStorage 一个 key 约 5MB（按 UTF-16 单元计）。base64 会比原文件
		// 大 1/3，所以安全上限定在 4M 字符，留出余量。
		const QUOTA_SAFE_CHARS = 4_000_000;
		// 本地文件超过该体积直接提示，避免读入超大文件（之后会自动压缩缩放）。
		const MAX_SOURCE_BYTES = 20 * 1024 * 1024;
		// 压缩时把长边压到该像素以内，壁纸不需要原图级别的分辨率。
		const MAX_DIM = 1920;

		const DEFAULTS = {
			image: "",
			imageOpacity: 1,
			panelOpacity: 0.8,
			mask: 0.2,
			blur: 0
		};

		function loadCfg() {
			try {
				const raw = localStorage.getItem(LS_KEY);
				if (!raw) return { ...DEFAULTS };
				const parsed = JSON.parse(raw);
				return {
					image: typeof parsed.image === "string" ? parsed.image : "",
					imageOpacity: clamp01(parsed.imageOpacity, DEFAULTS.imageOpacity),
					panelOpacity: clamp01(parsed.panelOpacity, DEFAULTS.panelOpacity),
					mask: clamp01(parsed.mask, DEFAULTS.mask),
					blur: Number.isFinite(parsed.blur) ? Math.max(0, Math.min(40, parsed.blur)) : DEFAULTS.blur
				};
			} catch {
				return { ...DEFAULTS };
			}
		}

		function clamp01(v, fallback) {
			return typeof v === "number" && Number.isFinite(v) ? Math.max(0, Math.min(1, v)) : fallback;
		}

		function saveCfg(cfg) {
			try {
				localStorage.setItem(LS_KEY, JSON.stringify(cfg));
				return true;
			} catch (err) {
				console.error("[dsh-wallpaper] 保存配置失败（图片可能过大）:", err);
				return false;
			}
		}

		// ── 图片解码 / 加载探测 ────────────────────────────────────

		function loadImage(url) {
			return new Promise((resolve, reject) => {
				const img = new Image();
				img.decoding = "async";
				// 很多图床按 Referer 防盗链，去掉 referer 通常能绕过。
				img.referrerPolicy = "no-referrer";
				img.onload = () => resolve(img);
				img.onerror = () => reject(new Error("图片无法加载"));
				img.src = url;
			});
		}

		function readFileAsDataURL(file) {
			return new Promise((resolve, reject) => {
				const reader = new FileReader();
				reader.onload = () => resolve(String(reader.result));
				reader.onerror = () => reject(new Error("读取文件失败"));
				reader.readAsDataURL(file);
			});
		}

		// 本地图片：先探测能否解码，再把过大的图缩放到合理分辨率、转 JPEG，
		// 让 base64 稳定落进 localStorage 配额内。返回最终 dataURL。
		async function normalizeLocalImage(file) {
			if (file.size > MAX_SOURCE_BYTES) {
				throw new Error("图片超过 20MB，请换一张小一点的");
			}
			const dataUrl = await readFileAsDataURL(file);
			const img = await loadImage(dataUrl); // HEIC / 损坏文件会在这里失败
			return downscaleToDataUrl(img, dataUrl);
		}

		function downscaleToDataUrl(img, original) {
			const srcW = img.naturalWidth || 0;
			const srcH = img.naturalHeight || 0;
			if (!srcW || !srcH) return original;
			if (srcW <= MAX_DIM && srcH <= MAX_DIM && original.length <= QUOTA_SAFE_CHARS) {
				return original;
			}
			const scale = Math.min(1, MAX_DIM / srcW, MAX_DIM / srcH);
			const w = Math.max(1, Math.round(srcW * scale));
			const h = Math.max(1, Math.round(srcH * scale));
			const canvas = document.createElement("canvas");
			canvas.width = w;
			canvas.height = h;
			const ctx = canvas.getContext("2d");
			if (!ctx) return original;
			ctx.fillStyle = "#ffffff";
			ctx.fillRect(0, 0, w, h);
			ctx.drawImage(img, 0, 0, w, h);
			try {
				const jpeg = canvas.toDataURL("image/jpeg", 0.9);
				return jpeg.length < original.length ? jpeg : original;
			} catch {
				return original;
			}
		}

		async function normalizeUrlImage(value) {
			const url = String(value).trim();
			if (!/^(https?:\/\/|data:|blob:)/i.test(url)) {
				throw new Error("链接需以 http:// 或 https:// 开头");
			}
			await loadImage(url); // 404 / 防盗链 / 失效链接会在这里失败
			return url;
		}

		function friendlyImageError(file) {
			if (file && file.type && /heic|heif/i.test(file.type)) {
				return "该文件是 HEIC 格式（iPhone 照片常见），多数浏览器无法显示，请先转成 JPG/PNG";
			}
			return "图片无法加载或格式不支持，请换一张 JPG/PNG/WebP/GIF 试试";
		}

		// ── 应用 / 渲染 ─────────────────────────────────────────────

		let bgEl = null;
		let maskEl = null;
		let currentSrc = "";

		function applyWallpaper(cfg) {
			const root = document.documentElement;
			root.style.setProperty("--dsh-wallpaper-image-opacity", String(cfg.imageOpacity));
			root.style.setProperty("--dsh-wallpaper-panel-opacity", String(cfg.panelOpacity));
			root.style.setProperty("--dsh-wallpaper-mask", String(cfg.mask));
			root.style.setProperty("--dsh-wallpaper-blur", `${cfg.blur}px`);
			root.classList.toggle("dsh-wallpaper-on", Boolean(cfg.image));
			renderBg(cfg.image);
		}

		function renderBg(src) {
			if (bgEl === null) return;
			if (src) {
				if (currentSrc !== src) {
					bgEl.referrerPolicy = "no-referrer";
					bgEl.src = src;
					currentSrc = src;
				}
				bgEl.style.display = "block";
			} else {
				bgEl.removeAttribute("src");
				bgEl.style.display = "none";
				currentSrc = "";
			}
		}

		// ── 注入样式 ────────────────────────────────────────────────

		const CSS = `
/* ===== dsh-wallpaper：html 兜底底色（图片层会盖住它） ===== */
html.dsh-wallpaper-on { background-color: #0f1115; }
/* ===== dsh-wallpaper：背景图层（垫在 #root 下面） ===== */
#dsh-wallpaper-bg {
  position: fixed;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  width: 100%;
  height: 100%;
  object-fit: cover;
  object-position: center;
  opacity: var(--dsh-wallpaper-image-opacity, 1);
  filter: blur(var(--dsh-wallpaper-blur, 0px));
  transition: opacity 0.15s ease;
}
/* ===== dsh-wallpaper：压暗遮罩（提升可读性，盖在背景图上） ===== */
#dsh-wallpaper-mask {
  position: fixed;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  background: rgba(0, 0, 0, var(--dsh-wallpaper-mask, 0));
}
/* 应用内容抬升到背景层之上 */
html.dsh-wallpaper-on #root {
  position: relative;
  z-index: 1;
}
/* ===== dsh-wallpaper：让面板半透明，图片透出来（浅色） ===== */
html.dsh-wallpaper-on body {
  --dsw-alias-bg-base: color-mix(in srgb, var(--dsw-static-neutral-bluish-00) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-layer-1: color-mix(in srgb, var(--dsw-static-neutral-bluish-00) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-layer-2: color-mix(in srgb, var(--dsw-static-neutral-bluish-00) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-layer-3: color-mix(in srgb, var(--dsw-static-neutral-bluish-00) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-overlay: color-mix(in srgb, var(--dsw-static-neutral-bluish-150) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-module-platform: color-mix(in srgb, var(--dsw-static-neutral-bluish-60) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-multi-select: color-mix(in srgb, var(--dsw-static-neutral-bluish-60) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-sidebar-fill: color-mix(in srgb, var(--dsw-static-neutral-bluish-50) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-input-major: color-mix(in srgb, var(--dsw-static-neutral-bluish-00) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-login-input: color-mix(in srgb, var(--dsw-static-neutral-bluish-50) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-selector: color-mix(in srgb, var(--dsw-static-neutral-bluish-60) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-tip: color-mix(in srgb, var(--dsw-static-neutral-bluish-60) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-bubble: color-mix(in srgb, var(--dsw-static-deepseek-50) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-bubble-highlight: color-mix(in srgb, var(--dsw-static-deepseek-200) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-markdown-code-block: color-mix(in srgb, var(--dsw-static-neutral-bluish-50) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-markdown-code-block-banner: color-mix(in srgb, var(--dsw-static-neutral-bluish-50) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-markdown-inline-code: color-mix(in srgb, var(--dsw-static-neutral-bluish-100) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-markdown-citation: color-mix(in srgb, var(--dsw-static-neutral-bluish-100) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-scrollbar-bg-l1: color-mix(in srgb, var(--dsw-static-neutral-200) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-scrollbar-bg-l2: color-mix(in srgb, var(--dsw-static-neutral-200) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-scrollbar-hover-l1: color-mix(in srgb, var(--dsw-static-neutral-300) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-scrollbar-hover-l2: color-mix(in srgb, var(--dsw-static-neutral-300) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
}
/* ===== 深色模式下对应的静态底色 ===== */
html.dsh-wallpaper-on body[data-ds-dark-theme] {
  --dsw-alias-bg-base: color-mix(in srgb, var(--dsw-static-neutral-bluish-950) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-layer-1: color-mix(in srgb, var(--dsw-static-neutral-bluish-875) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-layer-2: color-mix(in srgb, var(--dsw-static-neutral-bluish-850) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-layer-3: color-mix(in srgb, var(--dsw-static-neutral-bluish-800) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-overlay: color-mix(in srgb, var(--dsw-static-neutral-bluish-700) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-module-platform: color-mix(in srgb, var(--dsw-static-neutral-bluish-800) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-bg-multi-select: color-mix(in srgb, var(--dsw-static-neutral-bluish-850) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-sidebar-fill: color-mix(in srgb, var(--dsw-static-neutral-bluish-900) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-input-major: color-mix(in srgb, var(--dsw-static-neutral-bluish-850) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-login-input: color-mix(in srgb, var(--dsw-static-neutral-bluish-900) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-selector: color-mix(in srgb, var(--dsw-static-neutral-bluish-800) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-tip: color-mix(in srgb, var(--dsw-static-neutral-bluish-800) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-bubble: color-mix(in srgb, var(--dsw-static-neutral-bluish-850) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-specific-bubble-highlight: color-mix(in srgb, var(--dsw-static-neutral-bluish-750) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-markdown-code-block: color-mix(in srgb, var(--dsw-static-neutral-bluish-900) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-markdown-code-block-banner: color-mix(in srgb, var(--dsw-static-neutral-bluish-850) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-markdown-inline-code: color-mix(in srgb, var(--dsw-static-neutral-bluish-850) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-markdown-citation: color-mix(in srgb, var(--dsw-static-neutral-bluish-800) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-scrollbar-bg-l1: color-mix(in srgb, var(--dsw-static-neutral-700) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-scrollbar-bg-l2: color-mix(in srgb, var(--dsw-static-neutral-600) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-scrollbar-hover-l1: color-mix(in srgb, var(--dsw-static-neutral-600) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
  --dsw-alias-scrollbar-hover-l2: color-mix(in srgb, var(--dsw-static-neutral-550) calc(var(--dsh-wallpaper-panel-opacity, 1) * 100%), transparent) !important;
}
/* ===== 控制面板本体（Apple / iOS 毛玻璃风） ===== */
#dsh-wallpaper-toggle {
  --dswp-accent: #007aff;
  position: fixed;
  right: 14px;
  bottom: 14px;
  z-index: 2147483001;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  border: 1px solid rgba(0, 0, 0, 0.08);
  background: rgba(255, 255, 255, 0.72);
  color: #1c1c1e;
  font-size: 18px;
  line-height: 1;
  cursor: pointer;
  -webkit-backdrop-filter: blur(20px) saturate(180%);
  backdrop-filter: blur(20px) saturate(180%);
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.14), inset 0 0.5px 0 rgba(255, 255, 255, 0.8);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: transform 0.18s cubic-bezier(0.22, 1, 0.36, 1), background 0.18s ease;
}
#dsh-wallpaper-toggle:hover { transform: scale(1.06); }
#dsh-wallpaper-toggle:active { transform: scale(0.96); }
body[data-ds-dark-theme] #dsh-wallpaper-toggle {
  --dswp-accent: #0a84ff;
  border-color: rgba(255, 255, 255, 0.16);
  background: rgba(30, 30, 32, 0.55);
  color: #f2f2f7;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.4), inset 0 0.5px 0 rgba(255, 255, 255, 0.12);
}
#dsh-wallpaper-panel {
  --dswp-bg: rgba(247, 248, 250, 0.72);
  --dswp-field: rgba(255, 255, 255, 0.65);
  --dswp-text: #1c1c1e;
  --dswp-text-2: #6e6e73;
  --dswp-border: rgba(0, 0, 0, 0.09);
  --dswp-hairline: rgba(255, 255, 255, 0.7);
  --dswp-accent: #007aff;
  --dswp-accent-soft: rgba(0, 122, 255, 0.12);
  --dswp-track: rgba(0, 0, 0, 0.12);
  --dswp-ok: #1f9d55;
  --dswp-err: #d70015;
  position: fixed;
  right: 14px;
  bottom: 68px;
  z-index: 2147483002;
  width: 316px;
  box-sizing: border-box;
  border-radius: 18px;
  border: 1px solid var(--dswp-border);
  background: var(--dswp-bg);
  color: var(--dswp-text);
  font: 13px/1.5 -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
  letter-spacing: -0.01em;
  -webkit-backdrop-filter: blur(28px) saturate(180%);
  backdrop-filter: blur(28px) saturate(180%);
  box-shadow: 0 24px 60px rgba(0, 0, 0, 0.22), 0 2px 8px rgba(0, 0, 0, 0.06), inset 0 0.5px 0 var(--dswp-hairline);
  padding: 16px 18px;
  display: none;
  flex-direction: column;
  gap: 12px;
}
body[data-ds-dark-theme] #dsh-wallpaper-panel {
  --dswp-bg: rgba(30, 30, 32, 0.55);
  --dswp-field: rgba(255, 255, 255, 0.08);
  --dswp-text: #f2f2f7;
  --dswp-text-2: #98989d;
  --dswp-border: rgba(255, 255, 255, 0.14);
  --dswp-hairline: rgba(255, 255, 255, 0.12);
  --dswp-accent: #0a84ff;
  --dswp-accent-soft: rgba(10, 132, 255, 0.2);
  --dswp-track: rgba(255, 255, 255, 0.22);
  --dswp-ok: #30d158;
  --dswp-err: #ff453a;
}
#dsh-wallpaper-panel.dsh-open { display: flex; }
#dsh-wallpaper-panel .dswp-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 15px;
  font-weight: 600;
  letter-spacing: -0.02em;
}
#dsh-wallpaper-panel .dswp-close {
  background: none;
  border: none;
  color: var(--dswp-text-2);
  font-size: 15px;
  line-height: 1;
  cursor: pointer;
  width: 44px;
  height: 44px;
  margin: -8px -10px -8px 0;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.15s ease, color 0.15s ease;
}
#dsh-wallpaper-panel .dswp-close:hover { background: var(--dswp-accent-soft); color: var(--dswp-text); }
#dsh-wallpaper-panel .dswp-row { display: flex; flex-direction: column; gap: 6px; }
#dsh-wallpaper-panel .dswp-label {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  color: var(--dswp-text-2);
  font-size: 12px;
  font-weight: 500;
}
#dsh-wallpaper-panel .dswp-label b {
  color: var(--dswp-text);
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}
/* range slider（iOS 风格圆钮） */
#dsh-wallpaper-panel input[type="range"] {
  -webkit-appearance: none;
  appearance: none;
  width: 100%;
  height: 24px;
  background: transparent;
  cursor: pointer;
}
#dsh-wallpaper-panel input[type="range"]::-webkit-slider-runnable-track {
  height: 4px;
  border-radius: 2px;
  background: var(--dswp-track);
}
#dsh-wallpaper-panel input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 20px;
  height: 20px;
  margin-top: -8px;
  border-radius: 50%;
  border: none;
  background: #fff;
  box-shadow: 0 0.5px 1px rgba(0, 0, 0, 0.2), 0 2px 6px rgba(0, 0, 0, 0.2);
}
#dsh-wallpaper-panel input[type="range"]::-moz-range-track {
  height: 4px;
  border-radius: 2px;
  background: var(--dswp-track);
}
#dsh-wallpaper-panel input[type="range"]::-moz-range-thumb {
  width: 20px;
  height: 20px;
  border: none;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 0.5px 1px rgba(0, 0, 0, 0.2), 0 2px 6px rgba(0, 0, 0, 0.2);
}
#dsh-wallpaper-panel input[type="text"] {
  width: 100%;
  box-sizing: border-box;
  border-radius: 10px;
  border: 1px solid var(--dswp-border);
  background: var(--dswp-field);
  color: var(--dswp-text);
  padding: 9px 11px;
  font: 13px/1.4 inherit;
  transition: border-color 0.15s ease, box-shadow 0.15s ease;
}
#dsh-wallpaper-panel input[type="text"]:focus {
  outline: none;
  border-color: var(--dswp-accent);
  box-shadow: 0 0 0 3px var(--dswp-accent-soft);
}
#dsh-wallpaper-panel input[type="text"]::placeholder { color: var(--dswp-text-2); }
#dsh-wallpaper-panel input[type="file"] { font: 12px/1.4 inherit; color: var(--dswp-text-2); }
#dsh-wallpaper-panel input[type="file"]::file-selector-button {
  margin-right: 10px;
  border: 1px solid var(--dswp-border);
  border-radius: 8px;
  background: var(--dswp-field);
  color: var(--dswp-accent);
  font: 600 12px/1 inherit;
  padding: 9px 12px;
  cursor: pointer;
  transition: background 0.15s ease;
}
#dsh-wallpaper-panel input[type="file"]::file-selector-button:hover { background: var(--dswp-accent-soft); }
#dsh-wallpaper-panel .dswp-btns { display: flex; gap: 8px; }
#dsh-wallpaper-panel button.dswp-btn {
  flex: 1;
  min-height: 44px;
  border-radius: 11px;
  border: 1px solid var(--dswp-border);
  background: var(--dswp-field);
  color: var(--dswp-text);
  padding: 0 12px;
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.15s ease, transform 0.1s ease;
}
#dsh-wallpaper-panel button.dswp-btn:hover { background: var(--dswp-accent-soft); }
#dsh-wallpaper-panel button.dswp-btn:active { transform: scale(0.98); }
#dsh-wallpaper-panel button.dswp-btn.dswp-primary {
  background: var(--dswp-accent);
  border-color: var(--dswp-accent);
  color: #fff;
  font-weight: 600;
}
#dsh-wallpaper-panel button.dswp-btn.dswp-primary:hover { background: var(--dswp-accent); filter: brightness(1.08); }
#dsh-wallpaper-panel .dswp-thumb {
  max-width: 100%;
  max-height: 76px;
  border-radius: 12px;
  object-fit: cover;
  display: none;
  border: 1px solid var(--dswp-border);
}
#dsh-wallpaper-panel .dswp-thumb.dswp-show { display: block; }
#dsh-wallpaper-panel .dswp-status {
  font-size: 12px;
  line-height: 1.45;
  border-radius: 10px;
  padding: 8px 10px;
  display: none;
  word-break: break-all;
}
#dsh-wallpaper-panel .dswp-status.dswp-show { display: block; }
#dsh-wallpaper-panel .dswp-status.dswp-ok { background: rgba(31, 157, 85, 0.14); color: var(--dswp-ok); }
#dsh-wallpaper-panel .dswp-status.dswp-err { background: rgba(215, 0, 21, 0.12); color: var(--dswp-err); }
/* 焦点可见性 + 减少动态 */
#dsh-wallpaper-toggle:focus-visible,
#dsh-wallpaper-panel button:focus-visible,
#dsh-wallpaper-panel input:focus-visible {
  outline: 2px solid var(--dswp-accent, #007aff);
  outline-offset: 2px;
}
@media (prefers-reduced-motion: reduce) {
  #dsh-wallpaper-toggle,
  #dsh-wallpaper-panel button.dswp-btn,
  #dsh-wallpaper-panel .dswp-close { transition: none; }
}
`;

		function injectStyle() {
			const tagId = "dsh-wallpaper/styles";
			if (document.querySelector(`style[data-plugin-css="${tagId}"]`) !== null) return;
			const tag = document.createElement("style");
			tag.dataset.plugin = "dsh-wallpaper";
			tag.dataset.pluginCss = tagId;
			tag.textContent = CSS;
			document.head.append(tag);
		}

		// ── 背景层（<img> 方式，支持 referrerpolicy 与加载失败检测） ──

		function ensureLayers() {
			if (bgEl === null) {
				maskEl = document.createElement("div");
				maskEl.id = "dsh-wallpaper-mask";
				bgEl = document.createElement("img");
				bgEl.id = "dsh-wallpaper-bg";
				bgEl.alt = "";
				bgEl.draggable = false;
				bgEl.style.display = "none";
				bgEl.addEventListener("error", () => {
					bgEl.style.display = "none";
					if (typeof reportBgError === "function") reportBgError();
				});
				// prepend 顺序：mask 先入，img 后入 → DOM 顺序 [img, mask] → mask 画在 img 上面
				document.body.prepend(maskEl);
				document.body.prepend(bgEl);
			}
		}

		let reportBgError = null;

		// ── 控制面板 ────────────────────────────────────────────────

		function el(tag, attrs = {}, children = []) {
			const node = document.createElement(tag);
			for (const [k, v] of Object.entries(attrs)) {
				if (k === "class") node.className = v;
				else if (k === "text") node.textContent = v;
				else if (k.startsWith("on")) node.addEventListener(k.slice(2).toLowerCase(), v);
				else node.setAttribute(k, v);
			}
			for (const child of children) node.append(child);
			return node;
		}

		function buildPanel(cfg, onChange) {
			const panel = el("div", { id: "dsh-wallpaper-panel" });
			panel.append(el("div", { class: "dswp-head" }, [
				el("span", { text: "🖼 壁纸背景" }),
				el("button", { class: "dswp-close", text: "✕", onclick: () => { panel.classList.remove("dsh-open"); } })
			]));

			const status = el("div", { class: "dswp-status" });
			function showStatus(msg, kind) {
				if (!msg) {
					status.classList.remove("dswp-show");
					return;
				}
				status.textContent = msg;
				status.className = "dswp-status dswp-show " + (kind === "ok" ? "dswp-ok" : "dswp-err");
			}
			reportBgError = () => showStatus("图片加载失败：链接失效、被防盗链拦截，或格式浏览器不支持", "err");
			panel.append(status);

			// 图片选择
			const fileInput = el("input", { type: "file", accept: "image/*" });
			const thumb = el("img", { class: "dswp-thumb" });
			thumb.referrerPolicy = "no-referrer";
			fileInput.addEventListener("change", async () => {
				const file = fileInput.files && fileInput.files[0];
				if (!file) return;
				try {
					const dataUrl = await normalizeLocalImage(file);
					if (dataUrl.length > QUOTA_SAFE_CHARS) {
						throw new Error("图片压缩后仍超过浏览器本地存储上限，请换一张更小的");
					}
					cfg.image = dataUrl;
					const saved = onChange(cfg);
					showStatus(saved ? "图片已应用" : "图片已应用，但太大未能保存，刷新后会丢失", saved ? "ok" : "err");
				} catch (err) {
					showStatus(friendlyImageError(file), "err");
					console.error("[dsh-wallpaper] 本地图片处理失败:", err);
				} finally {
					fileInput.value = "";
				}
			});
			panel.append(el("div", { class: "dswp-row" }, [
				el("label", { class: "dswp-label", text: "选择本地图片" }),
				fileInput,
				thumb
			]));

			// 图片链接
			const urlInput = el("input", { type: "text", placeholder: "或粘贴图片链接 (http/https)…" });
			panel.append(el("div", { class: "dswp-row" }, [
				el("label", { class: "dswp-label", text: "使用图片链接" }),
				urlInput,
				el("div", { class: "dswp-btns" }, [
					el("button", { class: "dswp-btn dswp-primary", text: "应用链接", onclick: async () => {
						const value = urlInput.value.trim();
						if (!value) return;
						try {
							const url = await normalizeUrlImage(value);
							cfg.image = url;
							const saved = onChange(cfg);
							showStatus(saved ? "图片已应用" : "图片已应用，但未能保存，刷新后会丢失", saved ? "ok" : "err");
						} catch (err) {
							showStatus("图片链接加载失败：链接失效、被防盗链拦截，或格式不支持", "err");
							console.error("[dsh-wallpaper] 链接图片加载失败:", err);
						}
					} }),
					el("button", { class: "dswp-btn", text: "移除图片", onclick: () => {
						cfg.image = "";
						urlInput.value = "";
						showStatus("");
						onChange(cfg);
					} })
				])
			]));

			// 滑块
			const sliders = [
				["图片透明度", "imageOpacity", 0, 100, 1],
				["面板透明度", "panelOpacity", 0, 100, 1],
				["压暗遮罩", "mask", 0, 100, 0],
				["背景模糊", "blur", 0, 40, 0]
			];
			for (const [label, key, min, max, step] of sliders) {
				const valueEl = el("b", { text: "" });
				const slider = el("input", {
					type: "range", min: String(min), max: String(max), step: String(step)
				});
				const render = () => {
					const v = cfg[key];
					slider.value = String(key === "blur" ? v : Math.round(v * 100));
					valueEl.textContent = key === "blur" ? `${v}px` : `${Math.round(v * 100)}%`;
				};
				slider.addEventListener("input", () => {
					cfg[key] = key === "blur" ? Number(slider.value) : Number(slider.value) / 100;
					valueEl.textContent = key === "blur" ? `${cfg[key]}px` : `${slider.value}%`;
					onChange(cfg);
				});
				panel.append(el("div", { class: "dswp-row" }, [
					el("label", { class: "dswp-label" }, [el("span", { text: label }), valueEl]),
					slider
				]));
				panel._render = panel._render || [];
				panel._render.push(render);
				render();
			}

			// 底部按钮
			panel.append(el("div", { class: "dswp-btns" }, [
				el("button", { class: "dswp-btn", text: "恢复默认", onclick: () => {
					Object.assign(cfg, DEFAULTS);
					urlInput.value = "";
					fileInput.value = "";
					showStatus("");
					onChange(cfg);
					for (const fn of panel._render) fn();
				} }),
				el("button", { class: "dswp-btn", text: "收起面板", onclick: () => { panel.classList.remove("dsh-open"); } })
			]));

			// 缩略图同步
			const syncThumb = () => {
				if (cfg.image) {
					thumb.src = cfg.image;
					thumb.classList.add("dswp-show");
				} else {
					thumb.removeAttribute("src");
					thumb.classList.remove("dswp-show");
				}
			};
			panel._syncThumb = syncThumb;

			return panel;
		}

		function init() {
			injectStyle();
			ensureLayers();
			const cfg = loadCfg();
			applyWallpaper(cfg);

			const toggle = el("button", {
				id: "dsh-wallpaper-toggle",
				title: "壁纸背景设置",
				text: "🖼"
			});
			const panel = buildPanel(cfg, (next) => {
				applyWallpaper(next);
				const saved = saveCfg(next);
				panel._syncThumb();
				return saved;
			});
			toggle.addEventListener("click", () => panel.classList.toggle("dsh-open"));
			document.body.append(toggle);
			document.body.append(panel);
			panel._syncThumb();
		}

		// ── 插件入口 ────────────────────────────────────────────────

		const inject = [];
		function apply() {
			if (typeof document === "undefined" || typeof localStorage === "undefined") return;
			if (document.readyState === "loading") {
				document.addEventListener("DOMContentLoaded", init, { once: true });
			} else {
				init();
			}
		}

		exports.apply = apply;
		exports.inject = inject;
		return module.exports;
	}
});
