// dsh-wallpaper host half — intentionally inert. All logic lives in the
// browser half (./client.js): the wallpaper layer, translucency token
// overrides, and the control panel are pure client-side DOM work.
export function apply() {}
export const inject = [];
