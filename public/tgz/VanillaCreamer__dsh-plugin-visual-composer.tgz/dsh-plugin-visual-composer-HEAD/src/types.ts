export type FiberPhase = 'pending' | 'loading' | 'active' | 'failed' | 'unloading' | 'inactive'

export interface ComposerNode {
  id: string
  name: string
  label: string
  parentId?: string
  group: boolean
  disabled: boolean
  phase: FiberPhase
  config?: unknown
  configRedacted: boolean
  inject?: unknown
  protected: boolean
  managed: boolean
  children: ComposerNode[]
}

export interface ComposerOverride {
  id: string
  name: string
  disabled?: boolean
  config?: unknown
}

export interface ComposerInsertionEntry {
  id: string
  name: string
  group?: boolean
  disabled?: boolean
  config?: unknown
}

export interface ComposerInsertion {
  key: string
  parentId?: string
  entry: ComposerInsertionEntry
}

export interface ComposerDraft {
  overrides: ComposerOverride[]
  insertions: ComposerInsertion[]
}

export interface ComposerSnapshot {
  csrfToken: string
  revision: string
  profileName: string
  patchPath: string
  liveReloadAvailable: boolean
  nodes: ComposerNode[]
  draft: ComposerDraft
  redactedDraftIds: string[]
  protectedIds: string[]
  lastFailure?: string
}

export interface ComposerPreview {
  revision: string
  patchPath: string
  previewToken: string
  diff: string
  warnings: string[]
  summary: {
    overrides: number
    insertions: number
    disabled: number
  }
}

export interface ApplyResult {
  revision: string
  backupId: string
  restartRequired: boolean
  message: string
}

export interface ApiError {
  error: {
    code: string
    message: string
  }
}

export type ComposerAction =
  | { action: 'preview'; revision: string; draft: ComposerDraft }
  | { action: 'apply'; revision: string; draft: ComposerDraft; previewToken: string }
  | { action: 'rollback'; revision: string; backupId?: string }
