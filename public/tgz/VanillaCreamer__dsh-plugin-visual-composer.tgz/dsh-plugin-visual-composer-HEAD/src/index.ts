import { createHmac, randomBytes, timingSafeEqual } from 'node:crypto'
import { Buffer } from 'node:buffer'
import { lstat, mkdir, readFile, readdir, realpath, rename, unlink, writeFile } from 'node:fs/promises'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { createRequire } from 'node:module'
import { basename, isAbsolute, join, relative, resolve, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import type { Context, FiberState } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/cordis-plugin-hmr'
import type { Entry, EntryOptions } from '@deepseek-ai/cordis-plugin-loader'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import {
  compactDiff,
  composePatchFile,
  parseManagedDraft,
  revisionOf,
  validateDraft,
} from './patch.js'
import type {
  ApiError,
  ApplyResult,
  ComposerAction,
  ComposerDraft,
  ComposerNode,
  ComposerPreview,
  ComposerSnapshot,
  FiberPhase,
} from './types.js'

export type * from './types.js'

export const name = 'dsh-visual-composer'
export const inject = ['webServer', 'loader']

const API_PATH = '/dsh-visual-composer/api'
const PATCH_FILENAME = 'cordis.patch.yml'
const BACKUP_DIRECTORY = '.dsh-visual-composer/backups'
const MAX_BODY_BYTES = 512 * 1024
const MAX_BACKUPS = 20
const SECRET_KEY = /(?:api[_-]?key|token|secret|password|credential|private[_-]?key|signing[_-]?key|encryption[_-]?key|authorization|cookie|dsn|auth)/i
const EXPRESSION_KEY = /^(?:\$dshExpression|__jsExpr)$/

const DEFAULT_PROTECTED_IDS = [
  'include',
  'timer',
  'hmr',
  'visual-composer',
  'webserver',
  'web-runtime',
  'modules',
  'connection',
  'api-gateway',
  'api-remotes',
  'client-runtime',
  'client-hmr',
  'ui-layout',
  'ui-sidebar',
  'ui-settings',
  'ui-settings-plugin-inventory',
]

export interface Config {
  protectedIds?: string[]
}

class HttpError extends Error {
  constructor(
    readonly status: number,
    readonly code: string,
    message: string,
  ) {
    super(message)
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function sendJson(res: ServerResponse, status: number, value: unknown): void {
  const body = JSON.stringify(value)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(body),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
  })
  res.end(body)
}

function sendError(res: ServerResponse, error: unknown): void {
  const value = error instanceof HttpError
    ? error
    : new HttpError(500, 'INTERNAL_ERROR', errorMessage(error))
  const body: ApiError = { error: { code: value.code, message: value.message } }
  sendJson(res, value.status, body)
}

function isLoopbackHostname(hostname: string): boolean {
  if (hostname === 'localhost' || hostname === '[::1]') return true
  const octets = hostname.split('.')
  return octets.length === 4
    && octets[0] === '127'
    && octets.every(octet => /^\d{1,3}$/.test(octet) && Number(octet) <= 255)
}

function isLoopbackRemoteAddress(address: string | undefined): boolean {
  if (!address) return false
  const normalized = address.toLowerCase().split('%', 1)[0] ?? ''
  if (normalized === '::1') return true
  const ipv4 = normalized.startsWith('::ffff:') ? normalized.slice(7) : normalized
  const octets = ipv4.split('.')
  return octets.length === 4
    && octets[0] === '127'
    && octets.every(octet => /^\d{1,3}$/.test(octet) && Number(octet) <= 255)
}

function assertLocalApiRequest(req: IncomingMessage): void {
  if (!isLoopbackRemoteAddress(req.socket.remoteAddress)) {
    throw new HttpError(403, 'LOOPBACK_CLIENT_REQUIRED', 'Visual Composer accepts connections only from the local machine.')
  }
  const host = req.headers.host
  if (typeof host !== 'string') throw new HttpError(403, 'HOST_REQUIRED', 'Request Host header is required.')
  let hostUrl: URL
  try {
    hostUrl = new URL(`http://${host}`)
  } catch {
    throw new HttpError(403, 'HOST_INVALID', 'Request Host header is invalid.')
  }
  if (!isLoopbackHostname(hostUrl.hostname)) {
    throw new HttpError(403, 'LOOPBACK_REQUIRED', 'Visual Composer is available only through localhost or a loopback IP address.')
  }
  if (req.headers['sec-fetch-site'] === 'cross-site') {
    throw new HttpError(403, 'CROSS_SITE_REJECTED', 'Cross-site browser requests are not allowed.')
  }
  const origin = req.headers.origin
  if (origin === undefined) return
  try {
    if (new URL(origin).host === hostUrl.host) return
  } catch {
    // Fall through to a stable rejection below.
  }
  throw new HttpError(403, 'ORIGIN_REJECTED', 'Request Origin does not match this local DSH Web authority.')
}

function assertSameOrigin(req: IncomingMessage): void {
  const origin = req.headers.origin
  const host = req.headers.host
  if (typeof origin !== 'string' || typeof host !== 'string') {
    throw new HttpError(403, 'ORIGIN_REQUIRED', 'Mutating requests require a same-origin browser Origin header.')
  }
  let originHost: string
  try {
    originHost = new URL(origin).host
  } catch {
    throw new HttpError(403, 'ORIGIN_INVALID', 'Request Origin is invalid.')
  }
  if (originHost.toLowerCase() !== host.toLowerCase()) {
    throw new HttpError(403, 'ORIGIN_REJECTED', 'Cross-origin mutation is not allowed.')
  }
}

async function readAction(req: IncomingMessage, csrfToken: string): Promise<ComposerAction> {
  assertSameOrigin(req)
  if (req.headers['x-dsh-composer-token'] !== csrfToken) {
    throw new HttpError(403, 'CSRF_REJECTED', 'Composer request token is missing or stale. Reload the page.')
  }
  const contentType = req.headers['content-type']?.split(';', 1)[0]?.trim().toLowerCase()
  if (contentType !== 'application/json') throw new HttpError(415, 'JSON_REQUIRED', 'Content-Type must be application/json.')
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const part = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += part.length
    if (size > MAX_BODY_BYTES) {
      req.resume()
      throw new HttpError(413, 'BODY_TOO_LARGE', 'Composer request exceeds 512 KiB.')
    }
    chunks.push(part)
  }
  let value: unknown
  try {
    value = JSON.parse(Buffer.concat(chunks).toString('utf8'))
  } catch {
    throw new HttpError(400, 'JSON_INVALID', 'Request body is not valid JSON.')
  }
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new HttpError(400, 'ACTION_INVALID', 'Request body must be an action object.')
  }
  const action = (value as { action?: unknown }).action
  if (action !== 'preview' && action !== 'apply' && action !== 'rollback') {
    throw new HttpError(400, 'ACTION_INVALID', 'Unknown Composer action.')
  }
  return value as ComposerAction
}

function resolveProfileDirectory(ctx: Context): string {
  if (!ctx.baseUrl?.startsWith('file:')) {
    throw new Error('Cannot infer the active DSH profile directory from the Loader base URL.')
  }
  return fileURLToPath(new URL('.', ctx.baseUrl))
}

async function assertRegularFileOrMissing(path: string): Promise<void> {
  try {
    const info = await lstat(path)
    if (info.isSymbolicLink() || !info.isFile()) {
      throw new Error(`Refusing non-regular config path: ${path}`)
    }
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return
    throw error
  }
}

async function readPatch(path: string): Promise<string> {
  await assertRegularFileOrMissing(path)
  try {
    return await readFile(path, 'utf8')
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return '[]\n'
    throw error
  }
}

interface RedactedValue {
  value: unknown
  redacted: boolean
}

function looksSensitiveString(value: string): boolean {
  if (/^[A-Za-z][A-Za-z0-9+.-]*:\/\/[^\s/@:]+:[^\s/@]+@/.test(value)) return true
  if (/^(?:bearer|basic)\s+\S+/i.test(value)) return true
  if (/^(?:sk|pk|key|token|secret|gh[pousr])[-_][A-Za-z0-9._-]{8,}$/i.test(value)) return true
  return false
}

function redact(value: unknown, key = '', seen = new WeakSet<object>()): RedactedValue {
  if (SECRET_KEY.test(key) || EXPRESSION_KEY.test(key)) return { value: '<redacted>', redacted: true }
  if (typeof value === 'string' && looksSensitiveString(value)) return { value: '<redacted>', redacted: true }
  const kind = typeof value
  if (value === null || kind === 'string' || kind === 'boolean') return { value, redacted: false }
  if (kind === 'number') return Number.isFinite(value) ? { value, redacted: false } : { value: '<non-finite number>', redacted: true }
  if (kind === 'undefined' || kind === 'function' || kind === 'symbol' || kind === 'bigint') {
    return { value: `<non-json ${kind}>`, redacted: true }
  }
  if (typeof value !== 'object') return { value: '<unsupported>', redacted: true }
  if (seen.has(value)) return { value: '<circular>', redacted: true }
  seen.add(value)
  if (Array.isArray(value)) {
    let redacted = false
    const result = value.map(item => {
      const next = redact(item, '', seen)
      redacted ||= next.redacted
      return next.value
    })
    return { value: result, redacted }
  }
  const prototype = Object.getPrototypeOf(value) as object | null
  if (prototype !== null && prototype !== Object.prototype) {
    const constructorName = (value as { constructor?: { name?: string } }).constructor?.name ?? 'object'
    return { value: `<non-json ${constructorName}>`, redacted: true }
  }
  let redacted = false
  const result: Record<string, unknown> = {}
  for (const [childKey, childValue] of Object.entries(value as Record<string, unknown>)) {
    const next = redact(childValue, childKey, seen)
    redacted ||= next.redacted
    result[childKey] = next.value
  }
  return { value: result, redacted }
}

function sanitizeDraft(draft: ComposerDraft): { draft: ComposerDraft; redactedIds: Set<string> } {
  const safe = structuredClone(draft)
  const redactedIds = new Set<string>()
  for (const override of safe.overrides) {
    if (override.config === undefined) continue
    const result = redact(override.config)
    if (result.redacted) {
      delete override.config
      redactedIds.add(override.id)
    }
  }
  for (const insertion of safe.insertions) {
    if (insertion.entry.config === undefined) continue
    const result = redact(insertion.entry.config)
    if (result.redacted) {
      delete insertion.entry.config
      redactedIds.add(insertion.entry.id)
    }
  }
  return { draft: safe, redactedIds }
}

function hydrateRedactedDraft(
  submitted: ComposerDraft,
  current: ComposerDraft,
  redactedIds: ReadonlySet<string>,
): ComposerDraft {
  const hydrated = structuredClone(submitted)
  const currentOverrides = new Map(current.overrides.map(item => [item.id, item]))
  const currentInsertions = new Map(current.insertions.map(item => [item.entry.id, item]))
  for (const override of hydrated.overrides) {
    if (!redactedIds.has(override.id)) continue
    if (override.config !== undefined) throw new Error(`Config for ${override.id} is protected and cannot be replaced.`)
    const original = currentOverrides.get(override.id)
    if (original?.config !== undefined) override.config = original.config
  }
  for (const insertion of hydrated.insertions) {
    if (!redactedIds.has(insertion.entry.id)) continue
    if (insertion.entry.config !== undefined) throw new Error(`Config for ${insertion.entry.id} is protected and cannot be replaced.`)
    const original = currentInsertions.get(insertion.entry.id)
    if (original?.entry.config !== undefined) insertion.entry.config = original.entry.config
  }
  return hydrated
}

const PHASES: Record<number, FiberPhase> = {
  0: 'pending',
  1: 'loading',
  2: 'active',
  3: 'failed',
  4: 'inactive',
  5: 'unloading',
}

function runtimeNodes(
  ctx: Context,
  protectedIds: ReadonlySet<string>,
  managedIds: ReadonlySet<string>,
  redactedDraftIds: ReadonlySet<string> = new Set(),
): ComposerNode[] {
  const entries = [...ctx.loader.entries()]
  const byId = new Map<string, ComposerNode>()
  const parents = new Map<string, string | undefined>()

  for (const entry of entries) {
    const options = entry.options
    if (typeof options.id !== 'string' || typeof options.name !== 'string') continue
    if (options.id === 'include' && options.name === 'cordis:include') continue
    const parentEntry = entry.parent.ctx.fiber.entry as Entry | undefined
    const parentId = parentEntry?.options.name === 'cordis:include'
      ? undefined
      : typeof parentEntry?.options.id === 'string' ? parentEntry.options.id : undefined
    const safeConfig = options.group ? { value: undefined, redacted: false } : redact(options.config)
    const node: ComposerNode = {
      id: options.id,
      name: options.name,
      label: typeof (options as EntryOptions & { label?: unknown }).label === 'string'
        ? String((options as EntryOptions & { label?: string }).label)
        : options.id,
      group: options.group === true,
      disabled: entry.disabled,
      phase: entry.fiber === undefined ? 'inactive' : (PHASES[entry.fiber.state as FiberState] ?? 'inactive'),
      configRedacted: safeConfig.redacted || redactedDraftIds.has(options.id),
      protected: protectedIds.has(options.id),
      managed: managedIds.has(options.id),
      children: [],
    }
    if (parentId !== undefined) node.parentId = parentId
    if (safeConfig.value !== undefined) node.config = safeConfig.value
    if (options.inject !== undefined) node.inject = options.inject
    byId.set(options.id, node)
    parents.set(options.id, parentId)
  }

  const roots: ComposerNode[] = []
  for (const node of byId.values()) {
    const parentId = parents.get(node.id)
    const parent = parentId === undefined ? undefined : byId.get(parentId)
    if (parent?.group) parent.children.push(node)
    else roots.push(node)
  }
  return roots
}

function profileLabel(profileDir: string): string {
  return basename(profileDir) || profileDir
}

function parentEntryId(entry: Entry): string | undefined {
  const parentEntry = entry.parent.ctx.fiber.entry as Entry | undefined
  if (parentEntry?.options.name === 'cordis:include') return undefined
  return typeof parentEntry?.options.id === 'string' ? parentEntry.options.id : undefined
}

function jsonEqual(left: unknown, right: unknown): boolean {
  try {
    return JSON.stringify(left) === JSON.stringify(right)
  } catch {
    return false
  }
}

function draftIsApplied(ctx: Context, draft: ComposerDraft, previousDraft: ComposerDraft): boolean {
  const entries = new Map<string, Entry>()
  for (const entry of ctx.loader.entries()) {
    if (typeof entry.options.id === 'string') entries.set(entry.options.id, entry)
  }
  const nextIds = new Set(draft.insertions.map(item => item.entry.id))
  for (const previous of previousDraft.insertions) {
    if (!nextIds.has(previous.entry.id) && entries.has(previous.entry.id)) return false
  }
  for (const insertion of draft.insertions) {
    const actual = entries.get(insertion.entry.id)
    if (!actual || actual.options.name !== (insertion.entry.group ? 'cordis:group' : insertion.entry.name)) return false
    if (parentEntryId(actual) !== insertion.parentId) return false
    if (insertion.entry.disabled !== undefined && actual.options.disabled !== insertion.entry.disabled) return false
    if (!insertion.entry.group && insertion.entry.config !== undefined && !jsonEqual(actual.options.config, insertion.entry.config)) return false
    if (actual.fiber?.state === 3) return false
  }
  for (const override of draft.overrides) {
    const actual = entries.get(override.id)
    if (!actual || actual.options.name !== override.name) return false
    if (override.disabled !== undefined && actual.options.disabled !== override.disabled) return false
    if (override.config !== undefined && !jsonEqual(actual.options.config, override.config)) return false
    if (actual.fiber?.state === 3) return false
  }
  return true
}

function resolvePluginSpecifier(profileDir: string, profileRequire: NodeJS.Require, specifier: string): void {
  if (specifier === '.' || specifier === '..'
    || specifier.startsWith('.') && !specifier.startsWith('./')
    || isAbsolute(specifier)
    || /^[A-Za-z][A-Za-z+.-]*:/.test(specifier)
    || /[\u0000-\u001f]/.test(specifier)) {
    throw new Error(`Unsafe plugin module specifier: ${specifier}`)
  }
  const resolved = profileRequire.resolve(specifier)
  const pathFromProfile = relative(profileDir, resolved)
  if (pathFromProfile === '..' || pathFromProfile.startsWith(`..${sep}`) || isAbsolute(pathFromProfile)) {
    throw new Error(`Plugin module resolves outside the active profile: ${specifier}`)
  }
}

async function atomicReplace(path: string, content: string, expectedSource: string): Promise<void> {
  await assertRegularFileOrMissing(path)
  const temporary = join(resolve(path, '..'), `.${basename(path)}.${process.pid}.${randomBytes(5).toString('hex')}.tmp`)
  await writeFile(temporary, content, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
  try {
    if (await readPatch(path) !== expectedSource) {
      throw new HttpError(409, 'REVISION_CONFLICT', 'cordis.patch.yml changed while preparing the write. No file was replaced.')
    }
    await rename(temporary, path)
  } catch (error) {
    await unlink(temporary).catch(() => undefined)
    throw error
  }
}

async function ensureBackupDirectory(profileDir: string): Promise<string> {
  const directory = join(profileDir, BACKUP_DIRECTORY)
  await mkdir(directory, { recursive: true, mode: 0o700 })
  const info = await lstat(directory)
  if (info.isSymbolicLink() || !info.isDirectory()) throw new Error('Composer backup path must be a real directory.')
  const [profileReal, directoryReal] = await Promise.all([realpath(profileDir), realpath(directory)])
  const relativePath = relative(profileReal, directoryReal)
  if (relativePath === '..' || relativePath.startsWith(`..${sep}`) || isAbsolute(relativePath)) {
    throw new Error('Composer backup directory escapes the active profile.')
  }
  return directory
}

async function listBackups(profileDir: string): Promise<string[]> {
  const directory = await ensureBackupDirectory(profileDir)
  return (await readdir(directory)).filter(name => /^[\w.-]+\.yml$/.test(name)).sort().reverse()
}

async function createBackup(profileDir: string, source: string): Promise<string> {
  const directory = await ensureBackupDirectory(profileDir)
  const backupId = `${new Date().toISOString().replace(/[:.]/g, '-')}-${randomBytes(4).toString('hex')}.yml`
  await writeFile(join(directory, backupId), source, { encoding: 'utf8', mode: 0o600, flag: 'wx' })
  const backups = await listBackups(profileDir)
  await Promise.all(backups.slice(MAX_BACKUPS).map(name => unlink(join(directory, name)).catch(() => undefined)))
  return backupId
}

function assertRevision(source: string, revision: string): void {
  if (revisionOf(source) !== revision) {
    throw new HttpError(409, 'REVISION_CONFLICT', 'cordis.patch.yml changed since this page loaded. Reload before applying.')
  }
}

function ensureDraft(value: unknown): ComposerDraft {
  if (value === null || typeof value !== 'object'
    || !Array.isArray((value as { overrides?: unknown }).overrides)
    || !Array.isArray((value as { insertions?: unknown }).insertions)) {
    throw new HttpError(400, 'DRAFT_INVALID', 'Draft must contain override and insertion arrays.')
  }
  return value as ComposerDraft
}

export function apply(ctx: Context, config: Config = {}): void {
  const profileDir = resolveProfileDirectory(ctx)
  const patchPath = join(profileDir, PATCH_FILENAME)
  const backupDir = join(profileDir, BACKUP_DIRECTORY)
  const profileRequire = createRequire(join(profileDir, 'package.json'))
  const csrfToken = randomBytes(24).toString('base64url')
  const previewSecret = randomBytes(32)
  const protectedIds = new Set([...DEFAULT_PROTECTED_IDS, ...(config.protectedIds ?? [])])
  let lastFailure = false
  let failureGeneration = 0
  let includeCommitGeneration = 0
  let mutation = Promise.resolve()

  ctx.on('loader/partial-dispose', (entry) => {
    if (entry.options.id === 'include' && entry.options.name === 'cordis:include') {
      includeCommitGeneration += 1
    }
  })

  ctx.on('hmr/config-update-failed', (filename) => {
    if (resolve(filename) === resolve(patchPath)) {
      lastFailure = true
      failureGeneration += 1
    }
  })

  const snapshot = async (): Promise<ComposerSnapshot> => {
    const source = await readPatch(patchPath)
    const currentDraft = parseManagedDraft(source)
    const sanitized = sanitizeDraft(currentDraft)
    const managedIds = new Set(currentDraft.insertions.map(item => item.entry.id))
    const value: ComposerSnapshot = {
      csrfToken,
      revision: revisionOf(source),
      profileName: profileLabel(profileDir),
      patchPath,
      liveReloadAvailable: ctx.get('hmr') !== undefined,
      nodes: runtimeNodes(ctx, protectedIds, managedIds, sanitized.redactedIds),
      draft: sanitized.draft,
      redactedDraftIds: [...sanitized.redactedIds].sort(),
      protectedIds: [...protectedIds].sort(),
    }
    if (lastFailure) value.lastFailure = 'The most recent Cordis config update failed. Review the local DSH log for details.'
    return value
  }

  const previewTokenFor = (revision: string, draft: ComposerDraft): string => createHmac('sha256', previewSecret)
    .update(revision)
    .update('\0')
    .update(JSON.stringify(draft))
    .digest('base64url')

  const previewTokenMatches = (actual: unknown, expected: string): boolean => {
    if (typeof actual !== 'string') return false
    const left = Buffer.from(actual)
    const right = Buffer.from(expected)
    return left.length === right.length && timingSafeEqual(left, right)
  }

  interface PreviewComputation {
    response: ComposerPreview
    candidate: string
    effectiveDraft: ComposerDraft
    currentDraft: ComposerDraft
  }

  const preview = async (revision: string, draftValue: unknown): Promise<PreviewComputation> => {
    const source = await readPatch(patchPath)
    assertRevision(source, revision)
    const submittedDraft = ensureDraft(draftValue)
    const currentDraft = parseManagedDraft(source)
    const sanitized = sanitizeDraft(currentDraft)
    const draft = hydrateRedactedDraft(submittedDraft, currentDraft, sanitized.redactedIds)
    const managedIds = new Set(currentDraft.insertions.map(item => item.entry.id))
    const nodes = runtimeNodes(ctx, protectedIds, managedIds, sanitized.redactedIds)
    let warnings: string[]
    let candidate: string
    try {
      warnings = validateDraft(draft, nodes, protectedIds, currentDraft)
      for (const insertion of draft.insertions) {
        if (insertion.entry.group) continue
        try {
          resolvePluginSpecifier(profileDir, profileRequire, insertion.entry.name)
        } catch (error) {
          const message = error instanceof Error && error.message.startsWith('Unsafe')
            ? error.message
            : `Plugin module is not installed safely in profile “${profileLabel(profileDir)}”: ${insertion.entry.name}`
          throw new Error(message)
        }
      }
      candidate = composePatchFile(source, draft)
    } catch (error) {
      throw new HttpError(422, 'DRAFT_REJECTED', errorMessage(error))
    }
    const safeBefore = composePatchFile('[]\n', sanitized.draft)
    const safeAfter = composePatchFile('[]\n', sanitizeDraft(draft).draft)
    return {
      candidate,
      effectiveDraft: draft,
      currentDraft,
      response: {
        revision,
        patchPath,
        previewToken: previewTokenFor(revision, submittedDraft),
        diff: compactDiff(safeBefore, safeAfter),
        warnings,
        summary: {
          overrides: draft.overrides.length,
          insertions: draft.insertions.length,
          disabled: draft.overrides.filter(item => item.disabled === true).length
            + draft.insertions.filter(item => item.entry.disabled === true).length,
        },
      },
    }
  }

  const runExclusive = async <T>(operation: () => Promise<T>): Promise<T> => {
    const previous = mutation
    let release!: () => void
    mutation = new Promise<void>(resolvePromise => { release = resolvePromise })
    await previous
    try {
      return await operation()
    } finally {
      release()
    }
  }

  const waitForHmr = async (
    draft: ComposerDraft,
    previousDraft: ComposerDraft,
    startedAtFailure: number,
    startedAtCommit: number,
  ): Promise<void> => {
    const deadline = Date.now() + 15_000
    while (Date.now() < deadline) {
      if (failureGeneration !== startedAtFailure) {
        throw new Error('Cordis rejected the config update. Review the local DSH log for details.')
      }
      if (includeCommitGeneration > startedAtCommit
        && draftIsApplied(ctx, draft, previousDraft)) return
      await new Promise(resolvePromise => setTimeout(resolvePromise, 100))
    }
    throw new Error('Timed out waiting for the root Include transaction to commit the generated patch layer.')
  }

  const hasRootInclude = (): boolean => [...ctx.loader.entries()]
    .some(entry => entry.options.id === 'include' && entry.options.name === 'cordis:include')

  const handlePost = async (action: ComposerAction): Promise<ComposerPreview | ApplyResult> => {
    if (action.action === 'preview') return (await preview(action.revision, action.draft)).response
    if (action.action === 'apply') {
      return runExclusive(async () => {
        const result = await preview(action.revision, action.draft)
        if (!previewTokenMatches(action.previewToken, result.response.previewToken)) {
          throw new HttpError(409, 'PREVIEW_STALE', 'The draft no longer matches the reviewed preview. Preview it again before saving.')
        }
        const source = await readPatch(patchPath)
        assertRevision(source, action.revision)
        if (JSON.stringify(result.effectiveDraft) === JSON.stringify(result.currentDraft)) {
          return { revision: action.revision, backupId: '', restartRequired: false, message: 'No Composer changes to apply.' }
        }
        const live = ctx.get('hmr') !== undefined
        if (live && !hasRootInclude()) {
          throw new HttpError(503, 'HMR_CONFIRMATION_UNAVAILABLE', 'The active profile Include could not be located safely.')
        }
        const backupId = await createBackup(profileDir, source)
        const startedAtFailure = failureGeneration
        const startedAtCommit = includeCommitGeneration
        lastFailure = false
        await atomicReplace(patchPath, result.candidate, source)
        if (live) {
          try {
            await waitForHmr(result.effectiveDraft, result.currentDraft, startedAtFailure, startedAtCommit)
          } catch {
            await atomicReplace(patchPath, source, result.candidate)
            throw new HttpError(422, 'HMR_REJECTED', 'Cordis rejected the patch; the previous file was restored. Review the local DSH log for details.')
          }
        }
        return {
          revision: revisionOf(result.candidate),
          backupId,
          restartRequired: !live,
          message: live
            ? 'Patch saved after the root Include transaction committed.'
            : 'Patch saved. This Web profile has config HMR disabled, so restart DSH to activate it.',
        }
      })
    }
    return runExclusive(async () => {
      const source = await readPatch(patchPath)
      assertRevision(source, action.revision)
      const names = await listBackups(profileDir)
      const backupId = action.backupId ?? names[0]
      if (!backupId || !names.includes(backupId)) throw new HttpError(404, 'BACKUP_NOT_FOUND', 'No matching Composer backup exists.')
      const backupPath = join(backupDir, backupId)
      await assertRegularFileOrMissing(backupPath)
      const restored = await readFile(backupPath, 'utf8')
      const restoredDraft = parseManagedDraft(restored)
      composePatchFile(restored, restoredDraft)
      const previousDraft = parseManagedDraft(source)
      if (JSON.stringify(restoredDraft) === JSON.stringify(previousDraft)) {
        return { revision: action.revision, backupId, restartRequired: false, message: 'The selected backup already has the current Composer state.' }
      }
      const live = ctx.get('hmr') !== undefined
      if (live && !hasRootInclude()) {
        throw new HttpError(503, 'HMR_CONFIRMATION_UNAVAILABLE', 'The active profile Include could not be located safely.')
      }
      await createBackup(profileDir, source)
      const startedAtFailure = failureGeneration
      const startedAtCommit = includeCommitGeneration
      lastFailure = false
      await atomicReplace(patchPath, restored, source)
      if (live) {
        try {
          await waitForHmr(restoredDraft, previousDraft, startedAtFailure, startedAtCommit)
        } catch {
          await atomicReplace(patchPath, source, restored)
          throw new HttpError(422, 'ROLLBACK_REJECTED', 'Cordis rejected the backup; the current file was restored. Review the local DSH log for details.')
        }
      }
      return {
        revision: revisionOf(restored),
        backupId,
        restartRequired: !live,
        message: live ? 'Backup restored after the root Include transaction committed.' : 'Backup restored. Restart DSH to activate it.',
      }
    })
  }

  const route: WebRoute = {
    kind: 'exact',
    path: API_PATH,
    handler: async (req, res) => {
      try {
        assertLocalApiRequest(req)
        if (req.method === 'GET' || req.method === 'HEAD') {
          const value = await snapshot()
          if (req.method === 'HEAD') {
            res.writeHead(200, { 'cache-control': 'no-store' })
            res.end()
          } else {
            sendJson(res, 200, value)
          }
          return
        }
        if (req.method === 'POST') {
          const action = await readAction(req, csrfToken)
          sendJson(res, 200, await handlePost(action))
          return
        }
        res.writeHead(405, { allow: 'GET, HEAD, POST' })
        res.end()
      } catch (error) {
        ctx.logger.warn(error instanceof Error ? error : new Error(String(error)))
        sendError(res, error)
      }
    },
  }

  ctx.effect(() => ctx.webServer.register(route), 'visual-composer: API route')
}

export default { name, inject, apply }
