import { useEffect, useMemo, useState, type DragEvent, type ReactNode } from 'react'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type {
  ApplyResult,
  ComposerDraft,
  ComposerInsertion,
  ComposerNode,
  ComposerPreview,
  ComposerSnapshot,
} from '../types.js'

export const inject = ['slots']
const API = '/dsh-visual-composer/api'

const CSS = `
.dvc{--vc-border:var(--vscode-widget-border,#d0d7de);--vc-muted:var(--vscode-descriptionForeground,#667085);color:var(--vscode-foreground,inherit);font:13px/1.45 var(--vscode-font-family,system-ui);min-height:520px}.dvc *{box-sizing:border-box}.dvc button,.dvc input,.dvc textarea{font:inherit}.dvc button{border:0;border-radius:6px;padding:7px 11px;color:var(--vscode-button-foreground,#fff);background:var(--vscode-button-background,#3b82f6);cursor:pointer}.dvc button:hover{background:var(--vscode-button-hoverBackground,#2563eb)}.dvc button:disabled{opacity:.45;cursor:not-allowed}.dvc button.secondary{color:var(--vscode-foreground,inherit);background:var(--vscode-button-secondaryBackground,#e5e7eb)}.dvc input,.dvc textarea{width:100%;border:1px solid var(--vc-border);border-radius:6px;padding:7px 8px;color:var(--vscode-input-foreground,inherit);background:var(--vscode-input-background,transparent)}.dvc textarea{min-height:170px;resize:vertical;font-family:var(--vscode-editor-font-family,monospace)}.dvc-head{display:flex;align-items:flex-start;gap:10px;margin-bottom:14px}.dvc-head h2{font-size:18px;margin:0}.dvc-head p{color:var(--vc-muted);margin:2px 0 0}.dvc-actions{display:flex;gap:7px;margin-left:auto;flex-wrap:wrap}.dvc-banner{padding:9px 11px;margin-bottom:10px;border-left:3px solid var(--vscode-editorWarning-foreground,#d97706);background:var(--vscode-textBlockQuote-background,#fff8e6);border-radius:4px}.dvc-banner.error{border-color:var(--vscode-errorForeground,#dc2626)}.dvc-grid{display:grid;grid-template-columns:minmax(170px,22%) minmax(300px,1fr) minmax(220px,30%);gap:10px;min-height:470px}.dvc.busy .dvc-grid{pointer-events:none;opacity:.72}.dvc-pane{border:1px solid var(--vc-border);border-radius:9px;padding:11px;overflow:auto;background:var(--vscode-editor-background,transparent)}.dvc-pane h3{font-size:11px;text-transform:uppercase;letter-spacing:.08em;color:var(--vc-muted);margin:0 0 10px}.dvc-field{display:block;margin:9px 0 4px;color:var(--vc-muted);font-size:12px}.dvc-palette button{width:100%;margin-top:7px}.dvc-help{font-size:12px;color:var(--vc-muted);margin-top:10px}.dvc-canvas{min-height:410px;border:1px dashed var(--vc-border);border-radius:7px;padding:7px}.dvc-node{margin:6px 0;border:1px solid var(--vc-border);border-left:3px solid #5b8def;border-radius:6px;padding:7px 8px;background:var(--vscode-sideBar-background,rgba(127,127,127,.04));cursor:pointer}.dvc-node.managed{border-left-color:#16a34a}.dvc-node.group{border-left-color:#9333ea}.dvc-node.disabled{opacity:.55}.dvc-node.selected{outline:1px solid var(--vscode-focusBorder,#3b82f6)}.dvc-node.protected{background:repeating-linear-gradient(-45deg,transparent,transparent 8px,rgba(127,127,127,.06) 8px,rgba(127,127,127,.06) 16px)}.dvc-node-head{display:flex;align-items:center;gap:6px}.dvc-node-title{font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dvc-badge{margin-left:auto;padding:1px 5px;border:1px solid var(--vc-border);border-radius:99px;color:var(--vc-muted);font-size:9px}.dvc-meta{color:var(--vc-muted);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dvc-children{margin:6px 0 0 12px;padding-left:9px;border-left:1px dashed var(--vc-border);min-height:7px}.dvc-drop{outline:2px solid var(--vscode-focusBorder,#3b82f6)}.dvc-row{display:flex;gap:7px;align-items:center}.dvc-row input[type=checkbox]{width:auto}.dvc-inspector-title{font-size:15px;font-weight:650}.dvc-warning{font-size:12px;color:var(--vscode-editorWarning-foreground,#b45309);margin:8px 0}.dvc-error{white-space:pre-wrap;color:var(--vscode-errorForeground,#dc2626)}.dvc-status{color:var(--vc-muted);text-align:center;padding:30px 12px}.dvc-diff{white-space:pre;overflow:auto;max-height:330px;padding:10px;border:1px solid var(--vc-border);border-radius:6px;background:var(--vscode-textCodeBlock-background,#111827);color:var(--vscode-editor-foreground,#e5e7eb);font:11px/1.45 var(--vscode-editor-font-family,monospace)}.dvc-summary{display:flex;gap:6px;margin:8px 0}.dvc-summary span{border:1px solid var(--vc-border);border-radius:99px;padding:2px 7px;font-size:11px}@media(max-width:900px){.dvc-grid{grid-template-columns:1fr}.dvc-pane{max-height:none}}
`

function cloneDraft(draft: ComposerDraft): ComposerDraft {
  return structuredClone(draft)
}

function flatten(nodes: readonly ComposerNode[]): ComposerNode[] {
  return nodes.flatMap(node => [node, ...flatten(node.children)])
}

function wouldCreateCycle(draft: ComposerDraft, id: string, parentId: string | undefined): boolean {
  const byId = new Map(draft.insertions.map(item => [item.entry.id, item]))
  const visited = new Set([id])
  let cursor = parentId
  while (cursor !== undefined) {
    if (visited.has(cursor)) return true
    visited.add(cursor)
    cursor = byId.get(cursor)?.parentId
  }
  return false
}

function draftSubtreeIds(draft: ComposerDraft, rootId: string): Set<string> {
  const result = new Set([rootId])
  let changed = true
  while (changed) {
    changed = false
    for (const item of draft.insertions) {
      if (item.parentId && result.has(item.parentId) && !result.has(item.entry.id)) {
        result.add(item.entry.id)
        changed = true
      }
    }
  }
  return result
}

function materialize(snapshot: ComposerSnapshot, draft: ComposerDraft): ComposerNode[] {
  const runtime = flatten(snapshot.nodes)
  const runtimeById = new Map(runtime.map(node => [node.id, node]))
  const managedIds = new Set(snapshot.draft.insertions.map(item => item.entry.id))
  const redactedDraftIds = new Set(snapshot.redactedDraftIds)
  const roots = structuredClone(snapshot.nodes).filter(node => !managedIds.has(node.id))
  const removeManagedChildren = (items: ComposerNode[]): void => {
    for (const node of items) {
      node.children = node.children.filter(child => !managedIds.has(child.id))
      removeManagedChildren(node.children)
    }
  }
  removeManagedChildren(roots)
  const byId = new Map(flatten(roots).map(node => [node.id, node]))

  for (const override of draft.overrides) {
    const node = byId.get(override.id)
    if (!node) continue
    if (override.disabled !== undefined) node.disabled = override.disabled
    if (override.config !== undefined) node.config = override.config
  }

  const pending = [...draft.insertions]
  let progress = true
  while (pending.length && progress) {
    progress = false
    for (let index = pending.length - 1; index >= 0; index -= 1) {
      const item = pending[index]
      if (!item) continue
      if (item.parentId && !byId.has(item.parentId)) continue
      const runtimeNode = runtimeById.get(item.entry.id)
      const node: ComposerNode = {
        id: item.entry.id,
        name: item.entry.group ? 'cordis:group' : item.entry.name,
        label: item.entry.id,
        group: item.entry.group === true,
        disabled: item.entry.disabled === true,
        phase: runtimeNode?.phase ?? 'inactive',
        config: redactedDraftIds.has(item.entry.id) ? undefined : item.entry.config,
        configRedacted: redactedDraftIds.has(item.entry.id) || runtimeNode?.configRedacted === true,
        protected: false,
        managed: true,
        children: [],
      }
      if (item.parentId) node.parentId = item.parentId
      const parent = item.parentId ? byId.get(item.parentId) : undefined
      if (parent) parent.children.push(node)
      else roots.push(node)
      byId.set(node.id, node)
      pending.splice(index, 1)
      progress = true
    }
  }
  return roots
}

async function parseResponse<T>(response: Response): Promise<T> {
  const value = await response.json() as T | { error?: { message?: string } }
  if (!response.ok) {
    const message = 'error' in (value as object) ? (value as { error?: { message?: string } }).error?.message : undefined
    throw new Error(message || `HTTP ${response.status}`)
  }
  return value as T
}

async function getSnapshot(): Promise<ComposerSnapshot> {
  return parseResponse(await fetch(API, { cache: 'no-store', credentials: 'same-origin' }))
}

async function postAction<T>(token: string, body: unknown): Promise<T> {
  return parseResponse(await fetch(API, {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'content-type': 'application/json', 'x-dsh-composer-token': token },
    body: JSON.stringify(body),
  }))
}

function nodeMatches(node: ComposerNode, query: string): boolean {
  return query === '' || `${node.id} ${node.name} ${node.label}`.toLocaleLowerCase().includes(query)
    || node.children.some(child => nodeMatches(child, query))
}

interface TreeNodeProps {
  node: ComposerNode
  selectedId: string | null
  query: string
  onSelect: (id: string) => void
  onMove: (key: string, parentId?: string) => void
}

function TreeNode({ node, selectedId, query, onSelect, onMove }: TreeNodeProps): ReactNode {
  if (!nodeMatches(node, query)) return null
  const drag = node.managed
  const classes = ['dvc-node', node.managed ? 'managed' : '', node.group ? 'group' : '', node.disabled ? 'disabled' : '', node.protected ? 'protected' : '', selectedId === node.id ? 'selected' : ''].filter(Boolean).join(' ')
  const start = (event: DragEvent<HTMLDivElement>): void => {
    if (!drag) return
    event.stopPropagation()
    event.dataTransfer.setData('text/dsh-composer-id', node.id)
    event.dataTransfer.effectAllowed = 'move'
  }
  return (
    <div
      className={classes}
      draggable={drag}
      onDragStart={start}
      onDragOver={(event) => {
        if (!node.group) return
        event.preventDefault()
        event.stopPropagation()
        event.currentTarget.classList.add('dvc-drop')
      }}
      onDragLeave={(event) => { event.currentTarget.classList.remove('dvc-drop') }}
      onDrop={(event) => {
        if (!node.group) return
        event.preventDefault()
        event.stopPropagation()
        event.currentTarget.classList.remove('dvc-drop')
        onMove(event.dataTransfer.getData('text/dsh-composer-id'), node.id)
      }}
      onClick={(event) => { event.stopPropagation(); onSelect(node.id) }}
    >
      <div className="dvc-node-head">
        <span aria-hidden="true">{node.group ? '◇' : node.disabled ? '○' : '●'}</span>
        <span className="dvc-node-title" title={node.label}>{node.label}</span>
        <span className="dvc-badge">{node.protected ? 'CORE' : node.managed ? 'DRAFT' : node.phase.toUpperCase()}</span>
      </div>
      <div className="dvc-meta" title={node.name}>{node.id} · {node.name}</div>
      {node.group ? (
        <div
          className="dvc-children"
          onDragOver={(event) => { event.preventDefault(); event.stopPropagation(); event.currentTarget.classList.add('dvc-drop') }}
          onDragLeave={(event) => { event.currentTarget.classList.remove('dvc-drop') }}
          onDrop={(event) => {
            event.preventDefault()
            event.stopPropagation()
            event.currentTarget.classList.remove('dvc-drop')
            onMove(event.dataTransfer.getData('text/dsh-composer-id'), node.id)
          }}
        >
          {node.children.map(child => <TreeNode key={child.id} node={child} selectedId={selectedId} query={query} onSelect={onSelect} onMove={onMove} />)}
        </div>
      ) : null}
    </div>
  )
}

interface InspectorProps {
  node: ComposerNode | undefined
  draft: ComposerDraft
  onChange: (draft: ComposerDraft) => void
  onClearSelection: () => void
}

function Inspector({ node, draft, onChange, onClearSelection }: InspectorProps): ReactNode {
  const [disabled, setDisabled] = useState(false)
  const [configText, setConfigText] = useState('{}')
  const [parseError, setParseError] = useState('')

  useEffect(() => {
    setDisabled(node?.disabled ?? false)
    setConfigText(JSON.stringify(node?.config ?? {}, null, 2))
    setParseError('')
  }, [node?.id, node?.disabled, node?.config])

  if (!node) return <div className="dvc-status">选择一个插件查看和编辑配置。</div>
  const insertion = draft.insertions.find(item => item.entry.id === node.id)
  const override = draft.overrides.find(item => item.id === node.id)
  const editable = !node.protected && !node.configRedacted

  const applyEditor = (): void => {
    let config: unknown
    if (!node.group) {
      try {
        config = JSON.parse(configText)
      } catch (error) {
        setParseError(error instanceof Error ? error.message : String(error))
        return
      }
    }
    const next = cloneDraft(draft)
    const targetInsertion = next.insertions.find(item => item.entry.id === node.id)
    if (targetInsertion) {
      targetInsertion.entry.disabled = disabled
      if (!node.group) targetInsertion.entry.config = config
    } else {
      let target = next.overrides.find(item => item.id === node.id)
      if (!target) {
        target = { id: node.id, name: node.name }
        next.overrides.push(target)
      }
      target.disabled = disabled
      if (!node.group) target.config = config
    }
    setParseError('')
    onChange(next)
  }

  const removeDraft = (): void => {
    const next = cloneDraft(draft)
    const removedIds = draftSubtreeIds(next, node.id)
    next.insertions = next.insertions.filter(item => !removedIds.has(item.entry.id))
    next.overrides = next.overrides.filter(item => !removedIds.has(item.id))
    onChange(next)
    onClearSelection()
  }

  const removeOverride = (): void => {
    const next = cloneDraft(draft)
    next.overrides = next.overrides.filter(item => item.id !== node.id)
    onChange(next)
  }

  return (
    <div>
      <div className="dvc-inspector-title">{node.label}</div>
      <div className="dvc-meta">{node.id} · {node.name}</div>
      {node.protected ? <div className="dvc-warning">核心 Web/Composer 节点受保护，不能通过此界面覆盖。</div> : null}
      {node.configRedacted ? <div className="dvc-warning">配置包含密钥或凭据字段，已脱敏。为避免覆盖秘密值，界面禁止编辑完整配置。</div> : null}
      <label className="dvc-field dvc-row"><input type="checkbox" checked={disabled} disabled={!editable} onChange={event => { setDisabled(event.currentTarget.checked) }} /> Disabled</label>
      {!node.group ? <><label className="dvc-field">完整 Config 覆盖（JSON）</label><textarea value={configText} disabled={!editable} spellCheck={false} onChange={event => { setConfigText(event.currentTarget.value) }} /></> : <p className="dvc-help">Group 接收拖拽的草稿节点。当前版本不编辑 isolate/intercept。</p>}
      {parseError ? <p className="dvc-error">{parseError}</p> : null}
      <div className="dvc-actions" style={{ marginTop: 10, marginLeft: 0 }}>
        <button type="button" disabled={!editable} onClick={applyEditor}>应用到草稿</button>
        {override ? <button type="button" className="secondary" onClick={removeOverride}>清除覆盖</button> : null}
        {insertion ? <button type="button" className="secondary" onClick={removeDraft}>移除草稿节点</button> : null}
      </div>
      <p className="dvc-help">Cordis 的 config patch 是完整替换，不是深合并。保存前请检查 YAML Diff。</p>
    </div>
  )
}

function ComposerTab(_props: PropsRuntime<'settings.plugins.tab'>): ReactNode {
  const [snapshot, setSnapshot] = useState<ComposerSnapshot | null>(null)
  const [draft, setDraft] = useState<ComposerDraft>({ overrides: [], insertions: [] })
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [moduleName, setModuleName] = useState('')
  const [entryId, setEntryId] = useState('')
  const [query, setQuery] = useState('')
  const [preview, setPreview] = useState<ComposerPreview | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')

  const load = async (): Promise<void> => {
    setBusy(true)
    setError('')
    try {
      const next = await getSnapshot()
      setSnapshot(next)
      setDraft(cloneDraft(next.draft))
      setPreview(null)
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => { void load() }, [])
  const nodes = useMemo(() => snapshot ? materialize(snapshot, draft) : [], [snapshot, draft])
  const selected = selectedId ? flatten(nodes).find(node => node.id === selectedId) : undefined
  const normalizedQuery = query.trim().toLocaleLowerCase()
  const dirty = JSON.stringify(draft) !== JSON.stringify(snapshot?.draft ?? { overrides: [], insertions: [] })

  const addInsertion = (group: boolean): void => {
    const name = group ? 'cordis:group' : moduleName.trim()
    if (!group && !name) return
    const id = entryId.trim() || `visual-${crypto.randomUUID().slice(0, 8)}`
    const entry: ComposerInsertion['entry'] = group
      ? { id, name, group: true, config: [] }
      : { id, name, config: {} }
    setDraft(current => ({ ...cloneDraft(current), insertions: [...current.insertions, { key: `draft:${id}`, entry }] }))
    setSelectedId(id)
    setModuleName('')
    setEntryId('')
    setPreview(null)
  }

  const move = (id: string, parentId?: string): void => {
    const item = draft.insertions.find(insertion => insertion.entry.id === id)
    if (!item) return
    if (wouldCreateCycle(draft, id, parentId)) {
      setError('不能把 Group 拖入自身或其后代节点。')
      return
    }
    const next = cloneDraft(draft)
    const target = next.insertions.find(insertion => insertion.entry.id === id)
    if (!target) return
    if (parentId) target.parentId = parentId
    else delete target.parentId
    setDraft(next)
    setError('')
    setPreview(null)
  }

  const runPreview = async (): Promise<void> => {
    if (!snapshot) return
    setBusy(true); setError(''); setNotice('')
    try {
      setPreview(await postAction(snapshot.csrfToken, { action: 'preview', revision: snapshot.revision, draft }))
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    } finally { setBusy(false) }
  }

  const applyDraft = async (): Promise<void> => {
    if (!snapshot || !preview) return
    setBusy(true); setError('')
    try {
      const result = await postAction<ApplyResult>(snapshot.csrfToken, {
        action: 'apply', revision: snapshot.revision, draft, previewToken: preview.previewToken,
      })
      setNotice(result.message)
      await load()
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    } finally { setBusy(false) }
  }

  const rollback = async (): Promise<void> => {
    if (!snapshot) return
    setBusy(true); setError('')
    try {
      const result = await postAction<ApplyResult>(snapshot.csrfToken, { action: 'rollback', revision: snapshot.revision })
      setNotice(result.message)
      await load()
    } catch (reason) {
      setError(reason instanceof Error ? reason.message : String(reason))
    } finally { setBusy(false) }
  }

  if (!snapshot) return <div className="dvc"><style>{CSS}</style><div className="dvc-status">{busy ? '正在读取 Cordis 插件树…' : error || '尚未加载。'}</div></div>

  return (
    <div className={`dvc${busy ? ' busy' : ''}`} aria-busy={busy}>
      <style>{CSS}</style>
      <header className="dvc-head">
        <div><h2>Visual Composer</h2><p>{snapshot.profileName} · {snapshot.nodes.length} root entries</p></div>
        <div className="dvc-actions">
          <button type="button" className="secondary" disabled={busy} onClick={() => {
            if (!dirty || window.confirm('放弃尚未保存的 Visual Composer 草稿并重新加载？')) void load()
          }}>刷新</button>
          <button type="button" className="secondary" disabled={busy} onClick={() => {
            if (window.confirm('恢复最近一次 Visual Composer 备份？当前 Patch 会先自动备份。')) void rollback()
          }}>回滚最近备份</button>
          <button type="button" disabled={busy} onClick={() => { void runPreview() }}>预览变更</button>
        </div>
      </header>
      {!snapshot.liveReloadAvailable ? <div className="dvc-banner">当前 Web Profile 禁用了配置 HMR：保存会持久化到 <code>cordis.patch.yml</code>，重启 DSH 后生效。</div> : null}
      {snapshot.lastFailure ? <div className="dvc-banner error">最近一次 HMR 应用失败：{snapshot.lastFailure}</div> : null}
      {notice ? <div className="dvc-banner">{notice}</div> : null}
      {error ? <div className="dvc-banner error">{error}</div> : null}
      <div className="dvc-grid">
        <aside className="dvc-pane dvc-palette">
          <h3>Plugin palette</h3>
          <label className="dvc-field">模块名</label>
          <input value={moduleName} placeholder="@scope/plugin 或 ./local.js" onChange={event => { setModuleName(event.currentTarget.value) }} />
          <label className="dvc-field">Entry ID（可选，留空自动生成）</label>
          <input value={entryId} placeholder="my-plugin" onChange={event => { setEntryId(event.currentTarget.value) }} />
          <button type="button" disabled={!moduleName.trim()} onClick={() => { addInsertion(false) }}>添加插件</button>
          <button type="button" className="secondary" onClick={() => { addInsertion(true) }}>添加 Group</button>
          <label className="dvc-field">过滤插件树</label>
          <input type="search" value={query} placeholder="id / module / label" onChange={event => { setQuery(event.currentTarget.value) }} />
          <p className="dvc-help">绿色节点属于 Composer 草稿，可拖入 Root 或任意 Group。Bundle 原有节点只允许覆盖，不能用 Patch 改变顺序。</p>
        </aside>
        <main className="dvc-pane">
          <h3>Effective Cordis tree</h3>
          <div
            className="dvc-canvas"
            onDragOver={event => { event.preventDefault(); event.currentTarget.classList.add('dvc-drop') }}
            onDragLeave={event => { event.currentTarget.classList.remove('dvc-drop') }}
            onDrop={event => {
              event.preventDefault(); event.currentTarget.classList.remove('dvc-drop')
              move(event.dataTransfer.getData('text/dsh-composer-id'))
            }}
          >
            {nodes.filter(node => nodeMatches(node, normalizedQuery)).map(node => <TreeNode key={node.id} node={node} selectedId={selectedId} query={normalizedQuery} onSelect={setSelectedId} onMove={move} />)}
          </div>
        </main>
        <aside className="dvc-pane">
          <h3>{preview ? 'YAML change preview' : 'Inspector'}</h3>
          {preview ? (
            <div>
              <div className="dvc-summary"><span>{preview.summary.overrides} overrides</span><span>{preview.summary.insertions} inserts</span><span>{preview.summary.disabled} disabled</span></div>
              {preview.warnings.map(warning => <div className="dvc-warning" key={warning}>{warning}</div>)}
              <pre className="dvc-diff">{preview.diff}</pre>
              <div className="dvc-actions" style={{ marginTop: 10, marginLeft: 0 }}>
                <button type="button" disabled={busy} onClick={() => { void applyDraft() }}>确认并保存</button>
                <button type="button" className="secondary" onClick={() => { setPreview(null) }}>返回编辑</button>
              </div>
            </div>
          ) : <Inspector node={selected} draft={draft} onChange={next => { setDraft(next); setPreview(null) }} onClearSelection={() => { setSelectedId(null) }} />}
        </aside>
      </div>
      <p className="dvc-help">Patch: {snapshot.patchPath} · Revision: {snapshot.revision}</p>
    </div>
  )
}

export function apply(ctx: ClientContext): void {
  ctx.slots.inject('settings.plugins.tab', () => ctx.slots.register({
    name: 'settings.plugins.tab',
    id: 'visual-composer',
    order: 30,
    label: 'Visual Composer',
  }, ComposerTab))
}

export default { inject, apply }
