import { createHash, randomUUID } from 'node:crypto'
import { DEFAULT_SCHEMA, Type, load, dump } from 'js-yaml'
import type { EntryOptions } from '@deepseek-ai/cordis-plugin-loader'

interface PatchOptions extends Partial<EntryOptions> {
  id?: string
  insert?: EntryOptions[]
  remove?: string[]
}

const cordisSchema = DEFAULT_SCHEMA.extend([
  new Type('tag:yaml.org,2002:js', {
    kind: 'scalar',
    resolve: value => typeof value === 'string',
    construct: value => ({ $dshExpression: value }),
  }),
])
import type {
  ComposerDraft,
  ComposerInsertion,
  ComposerInsertionEntry,
  ComposerNode,
  ComposerOverride,
} from './types.js'

export const MANAGED_START = '# >>> dsh-visual-composer managed block'
export const MANAGED_END = '# <<< dsh-visual-composer managed block'

export function emptyDraft(): ComposerDraft {
  return { overrides: [], insertions: [] }
}

export function revisionOf(source: string): string {
  return createHash('sha256').update(source).digest('hex').slice(0, 20)
}

function parsePatchList(source: string, label: string): PatchOptions[] {
  let value: unknown
  try {
    value = load(source, { schema: cordisSchema })
  } catch (error) {
    throw new Error(`${label} is not valid Cordis YAML: ${error instanceof Error ? error.message : String(error)}`)
  }
  if (!Array.isArray(value)) throw new Error(`${label} must be a top-level YAML array.`)
  for (const [index, row] of value.entries()) {
    if (row === null || typeof row !== 'object' || Array.isArray(row)) {
      throw new Error(`${label} entry ${index + 1} must be a mapping.`)
    }
  }
  return value as PatchOptions[]
}

interface ManagedSplit {
  base: string
  managed?: string
}

function markerMatches(source: string, marker: string): RegExpMatchArray[] {
  const escaped = marker.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
  return [...source.matchAll(new RegExp(`^${escaped}\\r?$`, 'gm'))]
}

export function splitManagedBlock(source: string): ManagedSplit {
  const starts = markerMatches(source, MANAGED_START)
  const ends = markerMatches(source, MANAGED_END)
  if (starts.length === 0 && ends.length === 0) return { base: source }
  if (starts.length !== 1 || ends.length !== 1) {
    throw new Error(starts.length === 0 || ends.length === 0
      ? 'The Visual Composer marker block is incomplete.'
      : 'The patch file contains more than one Visual Composer block.')
  }
  const start = starts[0]
  const end = ends[0]
  if (!start || !end || start.index === undefined || end.index === undefined) {
    throw new Error('The Visual Composer marker block is incomplete.')
  }
  const managedStart = start.index + start[0].length
  if (end.index < managedStart) throw new Error('The Visual Composer marker block is incomplete.')
  const managed = source.slice(managedStart, end.index).replace(/^\r?\n/, '').replace(/\s*$/, '')
  const after = source.slice(end.index + end[0].length).replace(/^\r?\n/, '')
  let base = `${source.slice(0, start.index).trimEnd()}\n${after}`
  if (meaningfulLines(base).length === 0) base = `${base.trimEnd()}\n[]\n`
  return { base, managed }
}

function insertionFromEntry(entry: EntryOptions, parentId?: string): ComposerInsertion {
  if (typeof entry.id !== 'string' || typeof entry.name !== 'string') {
    throw new Error('Managed inserted entries require string id and name fields.')
  }
  const insertionEntry: ComposerInsertionEntry = { id: entry.id, name: entry.name }
  if (entry.group === true) insertionEntry.group = true
  if (typeof entry.disabled === 'boolean') insertionEntry.disabled = entry.disabled
  if ('config' in entry) insertionEntry.config = entry.config
  const insertion: ComposerInsertion = { key: `managed:${entry.id}`, entry: insertionEntry }
  if (parentId !== undefined) insertion.parentId = parentId
  return insertion
}

export function parseManagedDraft(source: string): ComposerDraft {
  const { managed } = splitManagedBlock(source)
  if (managed === undefined || managed.trim() === '') return emptyDraft()
  const patches = parsePatchList(managed, 'Visual Composer block')
  const draft = emptyDraft()
  for (const patch of patches) {
    if (Array.isArray(patch.insert)) {
      for (const entry of patch.insert) draft.insertions.push(insertionFromEntry(entry, patch.id))
      continue
    }
    if (typeof patch.id !== 'string' || typeof patch.name !== 'string') {
      throw new Error('Managed overrides require string id and name fields.')
    }
    const override: ComposerOverride = { id: patch.id, name: patch.name }
    if (typeof patch.disabled === 'boolean') override.disabled = patch.disabled
    if ('config' in patch) override.config = patch.config
    draft.overrides.push(override)
  }
  return draft
}

export function draftToPatches(draft: ComposerDraft): PatchOptions[] {
  const patches: PatchOptions[] = draft.overrides.map(override => {
    const row: PatchOptions = { id: override.id, name: override.name }
    if (override.disabled !== undefined) row.disabled = override.disabled
    if (override.config !== undefined) row.config = override.config
    return row
  })
  const byParent = new Map<string, EntryOptions[]>()
  for (const insertion of orderInsertions(draft)) {
    const parent = insertion.parentId ?? ''
    const list = byParent.get(parent) ?? []
    const row: EntryOptions = {
      id: insertion.entry.id,
      name: insertion.entry.group ? 'cordis:group' : insertion.entry.name,
    }
    if (insertion.entry.group) {
      row.group = true
      row.config = []
    } else if (insertion.entry.config !== undefined) {
      row.config = insertion.entry.config
    }
    if (insertion.entry.disabled !== undefined) row.disabled = insertion.entry.disabled
    list.push(row)
    byParent.set(parent, list)
  }
  for (const [parent, insert] of byParent) patches.push(parent ? { id: parent, insert } : { insert })
  return patches
}

function meaningfulLines(source: string): string[] {
  return source.split(/\r?\n/).map(line => line.trim()).filter(line => line !== '' && !line.startsWith('#'))
}

function baseForAppend(source: string): string {
  const lines = meaningfulLines(source)
  if (lines.length === 1 && lines[0] === '[]') {
    return source.split(/\r?\n/).filter(line => line.trim() !== '[]').join('\n').trimEnd()
  }
  if (lines[0]?.startsWith('[')) {
    throw new Error('A non-empty flow-style patch array cannot be extended safely. Convert it to block-style YAML first.')
  }
  return source.trimEnd()
}

export function composePatchFile(source: string, draft: ComposerDraft): string {
  const split = splitManagedBlock(source)
  parsePatchList(split.base, 'Existing cordis.patch.yml')
  const patches = draftToPatches(draft)
  if (patches.length === 0) return `${split.base.trimEnd()}\n`
  const base = baseForAppend(split.base)
  const managed = dump(patches, { schema: cordisSchema, noRefs: true, lineWidth: 100, noCompatMode: true }).trimEnd()
  const candidate = `${base ? `${base}\n\n` : ''}${MANAGED_START}\n${managed}\n${MANAGED_END}\n`
  parsePatchList(candidate, 'Generated cordis.patch.yml')
  return candidate
}

function flatten(nodes: readonly ComposerNode[]): ComposerNode[] {
  return nodes.flatMap(node => [node, ...flatten(node.children)])
}

const ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/

function assertJsonValue(value: unknown, path: string, seen = new WeakSet<object>()): void {
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return
  if (typeof value === 'number' && Number.isFinite(value)) return
  if (typeof value !== 'object') throw new Error(`${path} must contain only finite JSON values.`)
  if (seen.has(value)) throw new Error(`${path} must not contain circular values.`)
  seen.add(value)
  if (Array.isArray(value)) {
    value.forEach((item, index) => assertJsonValue(item, `${path}[${index}]`, seen))
    return
  }
  const prototype = Object.getPrototypeOf(value) as object | null
  if (prototype !== null && prototype !== Object.prototype) throw new Error(`${path} must be a plain JSON object.`)
  for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
    if (key === '__proto__' || key === 'constructor' || key === 'prototype' || key === '$dshExpression') {
      throw new Error(`${path} contains a forbidden object key: ${key}`)
    }
    assertJsonValue(child, `${path}.${key}`, seen)
  }
}

function assertDraftTopology(draft: ComposerDraft, byId: ReadonlyMap<string, ComposerNode>): void {
  const insertedById = new Map(draft.insertions.map(item => [item.entry.id, item]))
  for (const insertion of draft.insertions) {
    const parentId = insertion.parentId
    if (parentId === undefined) continue
    const parent = byId.get(parentId)
    const draftParent = insertedById.get(parentId)
    if (!parent?.group && !draftParent?.entry.group) {
      throw new Error(`Insertion parent is not an existing group: ${parentId}`)
    }
    const visited = new Set([insertion.entry.id])
    let cursor: string | undefined = parentId
    while (cursor !== undefined) {
      if (visited.has(cursor)) throw new Error(`Insertion parent graph contains a cycle at ${cursor}.`)
      visited.add(cursor)
      cursor = insertedById.get(cursor)?.parentId
    }
  }
}

function orderInsertions(draft: ComposerDraft): ComposerInsertion[] {
  const pending = [...draft.insertions]
  const emitted = new Set<string>()
  const result: ComposerInsertion[] = []
  while (pending.length) {
    let progressed = false
    for (let index = 0; index < pending.length;) {
      const item = pending[index]
      if (!item) break
      const parentIsPending = item.parentId !== undefined && pending.some(candidate => candidate.entry.id === item.parentId)
      if (parentIsPending && !emitted.has(item.parentId as string)) {
        index += 1
        continue
      }
      result.push(item)
      emitted.add(item.entry.id)
      pending.splice(index, 1)
      progressed = true
    }
    if (!progressed) throw new Error('Insertion parent graph contains a cycle.')
  }
  return result
}

export function validateDraft(
  draft: ComposerDraft,
  nodes: readonly ComposerNode[],
  protectedIds: ReadonlySet<string>,
  previousDraft: ComposerDraft,
): string[] {
  if (!Array.isArray(draft.overrides) || !Array.isArray(draft.insertions)) throw new Error('Draft shape is invalid.')
  if (draft.overrides.length + draft.insertions.length > 500) throw new Error('A draft may contain at most 500 operations.')
  const current = flatten(nodes)
  const byId = new Map(current.map(node => [node.id, node]))
  const priorManaged = new Set(previousDraft.insertions.map(item => item.entry.id))
  const insertedIds = new Set(draft.insertions.map(item => item.entry.id))
  const seen = new Set<string>()
  const warnings: string[] = []

  for (const override of draft.overrides) {
    if (insertedIds.has(override.id)) throw new Error(`Entry cannot be both inserted and overridden: ${override.id}`)
    if (!ID_PATTERN.test(override.id)) throw new Error(`Invalid override id: ${override.id}`)
    const target = byId.get(override.id)
    if (!target) throw new Error(`Cannot override missing entry: ${override.id}`)
    if (target.name !== override.name) throw new Error(`Plugin identity changed for ${override.id}; expected ${target.name}.`)
    if (protectedIds.has(override.id)) throw new Error(`Protected entry cannot be overridden: ${override.id}`)
    if (seen.has(`override:${override.id}`)) throw new Error(`Duplicate override: ${override.id}`)
    seen.add(`override:${override.id}`)
    if (target.configRedacted && override.config !== undefined) {
      throw new Error(`Config for ${override.id} contains redacted values and cannot be safely replaced.`)
    }
    if (override.config !== undefined) assertJsonValue(override.config, `Override ${override.id} config`)
  }

  for (const insertion of draft.insertions) {
    const entry = insertion.entry
    if (!ID_PATTERN.test(entry.id)) throw new Error(`Invalid inserted entry id: ${entry.id}`)
    if (entry.name.trim() === '' || /[\u0000-\u001f]/.test(entry.name)) throw new Error(`Invalid module specifier for ${entry.id}.`)
    if (protectedIds.has(entry.id)) throw new Error(`Inserted id is reserved: ${entry.id}`)
    if (seen.has(`insert:${entry.id}`)) throw new Error(`Duplicate inserted entry id: ${entry.id}`)
    seen.add(`insert:${entry.id}`)
    if (byId.has(entry.id) && !priorManaged.has(entry.id)) throw new Error(`Entry id already exists: ${entry.id}`)
    if (entry.config !== undefined) assertJsonValue(entry.config, `Insertion ${entry.id} config`)
    if (entry.group && entry.name !== 'cordis:group') warnings.push(`Group ${entry.id} will use cordis:group regardless of its module field.`)
  }
  assertDraftTopology(draft, byId)
  return warnings
}

export function createInsertion(name: string, group = false): ComposerInsertion {
  const id = `visual-${randomUUID().slice(0, 8)}`
  return {
    key: `draft:${id}`,
    entry: group
      ? { id, name: 'cordis:group', group: true, config: [] }
      : { id, name, config: {} },
  }
}

export function compactDiff(before: string, after: string): string {
  if (before === after) return 'No changes.'
  const left = before.split(/\r?\n/)
  const right = after.split(/\r?\n/)
  let prefix = 0
  while (prefix < left.length && prefix < right.length && left[prefix] === right[prefix]) prefix += 1
  let suffix = 0
  while (suffix < left.length - prefix && suffix < right.length - prefix
    && left[left.length - 1 - suffix] === right[right.length - 1 - suffix]) suffix += 1
  const contextStart = Math.max(0, prefix - 3)
  const removedEnd = left.length - suffix
  const addedEnd = right.length - suffix
  const lines = ['--- cordis.patch.yml', '+++ cordis.patch.yml']
  for (const line of left.slice(contextStart, prefix)) lines.push(` ${line}`)
  for (const line of left.slice(prefix, removedEnd)) lines.push(`-${line}`)
  for (const line of right.slice(prefix, addedEnd)) lines.push(`+${line}`)
  for (const line of right.slice(addedEnd, Math.min(right.length, addedEnd + 3))) lines.push(` ${line}`)
  return lines.join('\n')
}
