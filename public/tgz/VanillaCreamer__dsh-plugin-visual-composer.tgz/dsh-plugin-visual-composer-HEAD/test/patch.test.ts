import { describe, expect, it } from 'vitest'
import {
  MANAGED_END,
  MANAGED_START,
  compactDiff,
  composePatchFile,
  draftToPatches,
  parseManagedDraft,
  revisionOf,
  validateDraft,
} from '../src/patch.js'
import type { ComposerDraft, ComposerNode } from '../src/types.js'

const baseNode: ComposerNode = {
  id: 'demo',
  name: 'plugin-demo',
  label: 'demo',
  group: false,
  disabled: false,
  phase: 'active',
  config: { timeout: 10 },
  configRedacted: false,
  protected: false,
  managed: false,
  children: [],
}

function draft(): ComposerDraft {
  return {
    overrides: [{ id: 'demo', name: 'plugin-demo', disabled: true, config: { timeout: 20 } }],
    insertions: [{ key: 'draft:new-tool', parentId: 'tools', entry: { id: 'new-tool', name: 'plugin-new', config: {} } }],
  }
}

describe('managed Cordis patch block', () => {
  it('replaces an empty array while preserving comments and round-trips the draft', () => {
    const source = '# user comment\n[]\n'
    const candidate = composePatchFile(source, draft())
    expect(candidate).toContain('# user comment')
    expect(candidate).toContain(MANAGED_START)
    expect(candidate).toContain(MANAGED_END)
    expect(candidate).not.toContain('\n[]\n')
    const parsed = parseManagedDraft(candidate)
    expect(parsed.overrides).toEqual(draft().overrides)
    expect(parsed.insertions).toEqual([{ ...draft().insertions[0], key: 'managed:new-tool' }])
    expect(() => composePatchFile(candidate, parsed)).not.toThrow()
  })

  it('preserves non-managed YAML byte-for-byte around its owned block', () => {
    const source = `# hand written\n- id: agent\n  config:\n    model: !!js process.env.MODEL\n\n${MANAGED_START}\n- id: demo\n  name: plugin-demo\n  disabled: true\n${MANAGED_END}\n# tail\n`
    const next: ComposerDraft = { overrides: [], insertions: [{ key: 'x', entry: { id: 'next', name: 'plugin-next', config: {} } }] }
    const candidate = composePatchFile(source, next)
    expect(candidate).toContain('# hand written\n- id: agent\n  config:\n    model: !!js process.env.MODEL')
    expect(candidate).toContain('# tail')
    expect(candidate.match(new RegExp(MANAGED_START, 'g'))).toHaveLength(1)
  })

  it('rejects malformed or duplicate managed markers', () => {
    expect(() => composePatchFile(`${MANAGED_START}\n- id: x\n`, draft())).toThrow('incomplete')
    expect(() => composePatchFile(`${MANAGED_START}\n[]\n${MANAGED_END}\n${MANAGED_START}\n[]\n${MANAGED_END}\n`, draft())).toThrow('more than one')
  })

  it('does not treat marker text inside a YAML block scalar as an owned section', () => {
    const source = `- id: note\n  config:\n    text: |\n      ${MANAGED_START}\n      keep this user text\n      ${MANAGED_END}\n`
    const candidate = composePatchFile(source, draft())
    expect(candidate).toContain(`      ${MANAGED_START}\n      keep this user text\n      ${MANAGED_END}`)
    expect(candidate.match(new RegExp(`^${MANAGED_START}$`, 'gm'))).toHaveLength(1)
    expect(parseManagedDraft(candidate).overrides).toEqual(draft().overrides)
  })

  it('rejects extending a non-empty flow-style array rather than reformatting user YAML', () => {
    expect(() => composePatchFile('[{ id: demo, disabled: true }]\n', draft())).toThrow('flow-style')
  })
})

describe('draft validation', () => {
  const group: ComposerNode = { ...baseNode, id: 'tools', name: 'cordis:group', label: 'tools', group: true, config: undefined, children: [] }

  it('accepts overrides and group insertions', () => {
    expect(validateDraft(draft(), [baseNode, group], new Set(), { overrides: [], insertions: [] })).toEqual([])
  })

  it('blocks protected entries and duplicate ids', () => {
    expect(() => validateDraft(draft(), [baseNode, group], new Set(['demo']), { overrides: [], insertions: [] })).toThrow('Protected')
    const duplicate = draft()
    duplicate.insertions.push({ key: 'other', entry: { id: 'new-tool', name: 'another' } })
    expect(() => validateDraft(duplicate, [baseNode, group], new Set(), { overrides: [], insertions: [] })).toThrow('Duplicate')
  })

  it('blocks replacing a redacted config', () => {
    const secret = { ...baseNode, configRedacted: true }
    expect(() => validateDraft(draft(), [secret, group], new Set(), { overrides: [], insertions: [] })).toThrow('redacted')
  })

  it('orders a newly inserted parent group before a child patch regardless of UI order', () => {
    const nested: ComposerDraft = {
      overrides: [],
      insertions: [
        { key: 'child', parentId: 'parent', entry: { id: 'child', name: 'plugin-child', config: {} } },
        { key: 'parent', entry: { id: 'parent', name: 'cordis:group', group: true, config: [] } },
      ],
    }
    expect(validateDraft(nested, [], new Set(), { overrides: [], insertions: [] })).toEqual([])
    expect(draftToPatches(nested)).toEqual([
      { insert: [{ id: 'parent', name: 'cordis:group', group: true, config: [] }] },
      { id: 'parent', insert: [{ id: 'child', name: 'plugin-child', config: {} }] },
    ])
  })

  it('rejects cyclic parents, insert/override overlap, and expression sentinel injection', () => {
    const cycle: ComposerDraft = {
      overrides: [],
      insertions: [
        { key: 'a', parentId: 'b', entry: { id: 'a', name: 'cordis:group', group: true } },
        { key: 'b', parentId: 'a', entry: { id: 'b', name: 'cordis:group', group: true } },
      ],
    }
    expect(() => validateDraft(cycle, [], new Set(), { overrides: [], insertions: [] })).toThrow('cycle')

    const overlap: ComposerDraft = {
      overrides: [{ id: 'demo', name: 'plugin-demo', disabled: true }],
      insertions: [{ key: 'demo', entry: { id: 'demo', name: 'plugin-demo' } }],
    }
    expect(() => validateDraft(overlap, [baseNode], new Set(), { overrides: [], insertions: [] })).toThrow('both inserted and overridden')

    const expression = draft()
    expression.overrides[0]!.config = { value: { $dshExpression: 'process.env.SECRET' } }
    expect(() => validateDraft(expression, [baseNode, group], new Set(), { overrides: [], insertions: [] })).toThrow('forbidden object key')
  })
})

describe('diagnostics', () => {
  it('creates stable short revisions and compact diffs', () => {
    expect(revisionOf('same')).toBe(revisionOf('same'))
    expect(revisionOf('same')).not.toBe(revisionOf('other'))
    expect(compactDiff('a\nb\nc\n', 'a\nB\nc\n')).toContain('-b\n+B')
  })
})
