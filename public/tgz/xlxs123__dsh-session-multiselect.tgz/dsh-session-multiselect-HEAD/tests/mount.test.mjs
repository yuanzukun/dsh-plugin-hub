/**
 * Mount tests for the dsh-session-multiselect client bundle.
 *
 * These drive the real bundle the way the page does: a fake
 * `window.__ModuleLoader__` captures the registration, `factory()` is invoked
 * with a fake `require` backed by stand-ins for the module table, and the
 * exported `apply(ctx)` runs against a fake Cordis client context. That covers
 * what unit tests of the pure helpers cannot: the dictionary key set, the slot
 * registration, the store shape, the rendered panel, and that a batch action
 * reaches the service layer.
 *
 * Run: node --test tests/mount.test.mjs
 */
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'

const here = dirname(fileURLToPath(import.meta.url))
const bundlePath = join(here, '..', 'lib', 'client.js')

// --- stand-ins for the browser module table ---------------------------------

/** Store factory stand-in with real snapshot/subscribe semantics. */
function makeStore(initState, persistedKey) {
	let state = initState
	const listeners = new Set()
	return {
		getSnapshot: () => state,
		subscribe(fn) {
			listeners.add(fn)
			return () => listeners.delete(fn)
		},
		update(mutator) {
			const draft = JSON.parse(JSON.stringify(state))
			mutator(draft)
			state = draft
			if (persistedKey !== undefined) globalThis.localStorage?.setItem(persistedKey, JSON.stringify(state))
			for (const fn of [...listeners]) fn()
		},
		set(next) {
			state = next
			for (const fn of [...listeners]) fn()
		}
	}
}

const clientStore = {
	defineStore(decl) {
		return {
			spec: decl,
			create(scopeKey) {
				const persistKey = decl.persist === undefined ? undefined : scopeKey === undefined ? decl.persist : `${decl.persist}.${scopeKey}`
				const store = makeStore(decl.init(), persistKey)
				const actions = {}
				for (const key of Object.keys(decl.actions)) {
					actions[key] = (...params) => {
						store.update((draft) => {
							decl.actions[key](draft, ...params)
						})
					}
				}
				return { actions, getSnapshot: () => store.getSnapshot(), subscribe: (fn) => store.subscribe(fn), store }
			}
		}
	},
	createSnapshotStore(init, opts) {
		return makeStore(init, opts?.persist?.name)
	}
}

/** Fragment identity shared by the React and jsx-runtime stand-ins. */
const FRAGMENT = Symbol('Fragment')

/** Primitives stand-in: every required export exists, is named, and records props. */
function makePrimitives(rendered) {
	/** Build a named component function so assertions can identify it. */
	const named = (name) => {
		const component = (props) => {
			rendered.push({ name, props })
			return { type: component, props }
		}
		Object.defineProperty(component, 'name', { value: name })
		return component
	}
	const required = [
		// The 0.10 names: this stub mirrors what the installed primitives ship, so
		// a test that silently depended on an older spelling would fail here.
		'Modal', 'Button', 'Input', 'Tooltip',
		'IconSearchOutlineRegular', 'IconChecklistOutlineRegular', 'IconLoadingOutlineRegular'
	]
	const table = {}
	for (const name of required) table[name] = named(name)
	return table
}

/**
 * React stand-in with real state semantics, so a test can drive a component the
 * way a user does: call a setter, then re-render. Hooks are namespaced per
 * component, because real React keeps a separate hook slot per component 鈥攐ne
 * shared cursor would wrongly collide a child's `useState` with its parent's.
 */
function makeReact() {
	const runtime = {
		slots: new Map(),
		active: 'anonymous',
		cursor: 0,
		effects: [],
		/**
		 * One hook cell per call position, in call order 鈥攖he same discipline
		 * React enforces. `useState` and `useRef` must therefore not share a
		 * cursor, or a ref would read a state's slot.
		 */
		hook(make) {
			const slot = runtime.slot()
			const index = runtime.cursor
			runtime.cursor += 1
			if (slot.hooks.length <= index) slot.hooks.push(make())
			return { slot, index }
		},
		useState(init) {
			const { slot, index } = runtime.hook(() => ({
				kind: 'state',
				value: typeof init === 'function' ? init() : init
			}))
			if (slot.hooks[index].setter === undefined) {
				slot.hooks[index].setter = (next) => {
					const cell = slot.hooks[index]
					cell.value = typeof next === 'function' ? next(cell.value) : next
				}
			}
			return [slot.hooks[index].value, slot.hooks[index].setter]
		},
		useRef(init) {
			const { slot, index } = runtime.hook(() => ({ kind: 'ref', value: { current: init } }))
			return slot.hooks[index].value
		},
		useMemo(fn) { return fn() },
		useCallback(fn) { return fn },
		useEffect(fn) { runtime.effects.push(fn) },
		useSyncExternalStore(subscribe, getSnapshot) { return getSnapshot() },
		// The panel's error boundary is a class component; React ships the base
		// class on the same module, so the stand-in must too.
		Component: class Component {
			constructor(props) { this.props = props; this.state = {} }
			setState(next) { this.state = { ...this.state, ...next } }
		},
		Fragment: FRAGMENT,
		/** Current component's hook slot, created on first use. */
		slot() {
			let slot = runtime.slots.get(runtime.active)
			if (slot === undefined) {
				slot = { hooks: [] }
				runtime.slots.set(runtime.active, slot)
			}
			return slot
		},
		/** Run one component body as its own hook namespace. */
		withHooks(name, fn) {
			const previous = runtime.active
			runtime.active = name
			runtime.cursor = 0
			try {
				return fn()
			} finally {
				runtime.active = previous
			}
		},
		/** Setter of the nth `useState` call of one component, in call order. */
		setterOf(name, stateIndex) {
			const states = (runtime.slots.get(name)?.hooks ?? []).filter((cell) => cell.kind === 'state')
			return states[stateIndex]?.setter
		}
	}
	return runtime
}

/**
 * jsx-runtime stand-in. The bundle passes children on `props` and uses the
 * trailing argument for `key`, so elements are recorded verbatim; inventing
 * extra folding here would diverge from what React actually receives.
 */
const jsxRuntime = {
	jsx: (type, props) => ({ type, props: { ...props } }),
	jsxs: (type, props) => ({ type, props: { ...props } }),
	Fragment: FRAGMENT
}

/** Load the bundle once and hand back an instantiator bound to fresh modules. */
function loadBundle() {
	const source = readFileSync(bundlePath, 'utf8')
	let registration
	// The frame clock and observer are inert here: this suite covers the panel,
	// not the header injection (see inline.test.mjs for that path).
	const window = {
		__ModuleLoader__: { load: (value) => { registration = value } },
		requestAnimationFrame: () => 1,
		cancelAnimationFrame: () => {}
	}
	globalThis.window = window
	globalThis.MutationObserver = class {
		observe() {}
		disconnect() {}
	}
	new Function('window', 'globalThis', source)(window, globalThis)
	return {
		registration,
		/**
		 * Materialize the bundle with the given primitives table and React
		 * runtime. Each call gets its own module table, so hook state never
		 * leaks between tests.
		 */
		instantiate(primitives, reactRuntime = makeReact()) {
			const table = new Map([
				['@deepseek-ai/dsh-client-store', clientStore],
				['@deepseek-ai/dsh-client-ui-primitives', primitives],
				['react', reactRuntime],
				// react-dom/client is only used for the header injection, which the
				// mount suite does not exercise; a stub keeps the module table whole.
				['react-dom/client', { createRoot: () => ({ render() {}, unmount() {} }) }],
				['react/jsx-runtime', jsxRuntime]
			])
			return {
				exports: registration.factory((spec) => {
					if (!table.has(spec)) throw new Error(`unexpected require(${spec})`)
					return table.get(spec)
				}),
				react: reactRuntime
			}
		}
	}
}

/** Fake Cordis client context capturing every effect and registration. */
function makeCtx({ sessions, workspaces }) {
	const registrations = []
	const dictionaries = new Map()
	const effects = []
	const ctx = {
		effect(fn, label) {
			effects.push({ label, dispose: fn() })
			return () => {}
		},
		locale: {
			register(ns, dicts) {
				dictionaries.set(ns, dicts)
				return () => {}
			},
			subscribe: () => () => {}
		},
		slots: {
			inject(key, fn) {
				registrations.push({ key, entry: fn() })
				return () => {}
			},
			register(options, component) {
				return { options, component }
			}
		},
		// The workspace service is fetched lazily, never injected (a build without
		// it must still mount), so the stand-in answers `get` like Cordis does:
		// the service, or undefined.
		get: (name) => (name === 'workspaces' ? workspaces : undefined),
		sessions
	}
	return { ctx, registrations, dictionaries, effects }
}

/**
 * Fake `sessions` service matching the Session Controller client surface.
 *
 * `shape` picks the snapshot the controller actually hands out: the normalized
 * `{ ids, byId, 鈥?}` one (what the workspace and other clients read) or the
 * flattened `{ items, 鈥?}` projection. Both must list sessions.
 */
function makeSessions({ items = [], records = {}, onCreate = () => 'new-session', shape = 'normalized', trashEntries = [], openOnDelete = [], liveIds = [] } = {}) {
	const calls = { deleted: [], forked: [], created: [], prompted: [], opened: [], refreshed: 0, deleteRequests: 0, trashRequests: 0, restored: [], purged: [], purgeRequests: 0, probes: [] }
	/** Set by the fetch stub below; restores the real `fetch` for this world. */
	let restoreFetch = () => {}
	let summaries = [...items]
	/** Rebuild the snapshot in the shape under test. */
	const buildState = () => {
		const base = { current: undefined, state: 'idle', phase: 'ready', error: null }
		if (shape === 'items') return { ...base, items: summaries }
		const byId = {}
		for (const summary of summaries) {
			// Faithful to the controller's projection: each value carries the id as
			// `id` and a derived `displayTitle`; `sessionId` and `title` are not part
			// of it. Fixtures keeping the friendly names would hide exactly the bug
			// where every row ends up keyed on a missing `sessionId` 鈥?one click
			// then selects every row.
			const { sessionId, title, ...rest } = summary
			byId[sessionId] = {
				id: sessionId,
				...(title === undefined ? {} : { displayTitle: title }),
				...rest
			}
		}
		return { ...base, ids: summaries.map((summary) => summary.sessionId), byId }
	}
	let listState = buildState()
	const listListeners = new Set()
	/**
	 * Deletion is a host route, not a client method.
	 *
	 * DSH's client `sessions` service has no `delete` (that missing method was
	 * the bug this suite used to encode), so the bundle requests
	 * `GET /session-multiselect/delete?ids=…` and the Node half removes the
	 * directories. The stub below mirrors that route's response contract —
	 * per-id `{ ok, removed, reason }` — and keeps mutating the list feed so
	 * every assertion about the panel refreshing still means something. The
	 * `refresh()` method mirrors the controller call the bundle makes after a
	 * successful delete so the rows leave the panel without a page reload.
	 */
	const realFetch = globalThis.fetch
	globalThis.fetch = async (input, init = {}) => {
		const url = typeof input === 'string' ? input : String(input?.url ?? input)
		// The delete route's read-only probe: the panel asks before deleting which
		// selected conversations the host still holds open.
		if (url.includes('/session-multiselect/delete') && new URL(url, 'http://dsh.internal').searchParams.get('dry') === '1') {
			const probeIds = [...new URL(url, 'http://dsh.internal').searchParams.getAll('ids')]
			calls.probes.push(...probeIds)
			return {
				ok: true,
				status: 200,
				async json() {
					return { ok: true, dry: true, results: probeIds.map((id) => ({ id, live: liveIds.includes(id), present: true })) }
				}
			}
		}
		// The trash listing and the restore call, mirroring the host half.
		if (url.includes('/session-multiselect/trash')) {
			calls.trashRequests += 1
			return {
				ok: true,
				status: 200,
				async json() {
					return { ok: true, retentionDays: 7, entries: trashEntries }
				}
			}
		}
		if (url.includes('/session-multiselect/restore')) {
			const requested = [...new URL(url, 'http://dsh.internal').searchParams.getAll('ids')]
			calls.restored.push(...requested)
			const results = requested.map((id) => ({ id, ok: true, restored: true }))
			return {
				ok: true,
				status: 200,
				async json() {
					return { ok: true, restored: results.length, results }
				}
			}
		}
		if (url.includes('/session-multiselect/purge')) {
			calls.purgeRequests += 1
			const purgeUrl = new URL(url, 'http://dsh.internal')
			if (purgeUrl.searchParams.get('all') === '1') {
				calls.purged.push('all')
				return { ok: true, status: 200, async json() { return { ok: true, all: true, purged: trashEntries.length, results: [] } } }
			}
			const purgeIds = purgeUrl.searchParams.getAll('ids')
			calls.purged.push(...purgeIds)
			return { ok: true, status: 200, async json() { return { ok: true, purged: purgeIds.length, results: purgeIds.map((id) => ({ id, ok: true, purged: true })) } } }
		}
		if (!url.includes('/session-multiselect/delete')) {
			if (realFetch === undefined) throw new Error(`unexpected fetch: ${init.method ?? 'GET'} ${url}`)
			return realFetch(input, init)
		}
		const requested = [...new URL(url, 'http://dsh.internal').searchParams.getAll('ids')]
		calls.deleteRequests += 1
		const results = []
		for (const sessionId of requested) {
			calls.deleted.push(sessionId)
			const index = summaries.findIndex((item) => item.sessionId === sessionId)
			if (index === -1) {
				results.push({ id: sessionId, ok: true, removed: false, reason: 'not found' })
				continue
			}
			// A live row stays in the Host's list until the process restarts; the
			// stub keeps it, and the panel is expected to hide it locally.
			if (!openOnDelete.includes(sessionId)) summaries = summaries.filter((item) => item.sessionId !== sessionId)
			// `live` mirrors the host route's answer for a session it still held
			// open in memory: trashed on disk, but the row lingers until restart.
			results.push({ id: sessionId, ok: true, removed: true, ...(openOnDelete.includes(sessionId) ? { live: true } : {}) })
		}
		listState = buildState()
		for (const fn of [...listListeners]) fn()
		return {
			ok: true,
			status: 200,
			async json() {
				return { ok: true, removed: results.filter((r) => r.removed).length, results }
			}
		}
	}
	/** Put the real fetch back once this world is done with. */
	restoreFetch = () => {
		if (realFetch === undefined) delete globalThis.fetch
		else globalThis.fetch = realFetch
	}
	const service = {
		list: {
			getSnapshot: () => listState,
			subscribe(fn) {
				listListeners.add(fn)
				return () => listListeners.delete(fn)
			}
		},
		get(sessionId) {
			const entries = (records[sessionId] ?? []).map((event) => ({ event }))
			return {
				open: async () => { calls.opened.push(sessionId) },
				loadOlder: async () => {},
				getSnapshot: () => ({ hasMore: false, openState: 'open' }),
				get events() {
					return { entries: () => entries }
				},
				prompt: async (content, mode) => {
					calls.prompted.push({ sessionId, content, mode })
					return { ok: true, value: { accepted: true } }
				}
			}
		},
		async fork(opts) {
			calls.forked.push(opts.sessionId)
			return `${opts.sessionId}-fork`
		},
		async create(opts) {
			calls.created.push(opts)
			return onCreate(opts)
		},
		open(sessionId) { calls.opened.push(sessionId) },
		/** The controller's baseline re-pull, which the bundle calls after a delete. */
		async refresh() {
			calls.refreshed += 1
			listState = buildState()
			for (const fn of [...listListeners]) fn()
		},
		calls
	}
	service.restoreFetch = () => restoreFetch()
	return service
}

/**
 * Fake `workspaces` service, matching the client Workspace Controller.
 *
 * Pinning and archiving live here rather than on `sessions`: this is the service
 * that moves a row into DSH's own pinned group or archive section, and the
 * snapshot is where the panel reads that membership from.
 * @param options - `pinned`/`archived` seed the sets the host would report.
 */
function makeWorkspaces({ pinned = [], archived = [] } = {}) {
	const calls = { pinned: [], unpinned: [], archived: [], unarchived: [] }
	const listeners = new Set()
	let state = { pinnedSessionIds: [...pinned], archivedSessionIds: [...archived] }
	const publish = (next) => {
		state = next
		for (const fn of [...listeners]) fn()
	}
	return {
		calls,
		list: {
			getSnapshot: () => state,
			subscribe(fn) {
				listeners.add(fn)
				return () => listeners.delete(fn)
			}
		},
		async pinSession(sessionId) {
			calls.pinned.push(sessionId)
			publish({ ...state, pinnedSessionIds: [sessionId, ...state.pinnedSessionIds.filter((id) => id !== sessionId)] })
		},
		async unpinSession(sessionId) {
			calls.unpinned.push(sessionId)
			publish({ ...state, pinnedSessionIds: state.pinnedSessionIds.filter((id) => id !== sessionId) })
		},
		async archiveSession(sessionId) {
			calls.archived.push(sessionId)
			publish({ ...state, archivedSessionIds: [...state.archivedSessionIds.filter((id) => id !== sessionId), sessionId] })
		},
		async unarchiveSession(sessionId) {
			calls.unarchived.push(sessionId)
			publish({ ...state, archivedSessionIds: state.archivedSessionIds.filter((id) => id !== sessionId) })
		}
	}
}

/** Let queued microtasks (the async batch actions) settle. */
const flush = () => new Promise((resolve) => { setImmediate(resolve) })

/** Mount the plugin and return everything a test needs to drive it. */
function mount({ items = [], records, onCreate, shape, workspaces, trashEntries, openOnDelete, liveIds } = {}) {
	const bundle = loadBundle()
	const primitives = makePrimitives([])
	const react = makeReact()
	const { exports } = bundle.instantiate(primitives, react)
	const sessions = makeSessions({ items, records, onCreate, shape, trashEntries, openOnDelete, liveIds })
	const { ctx, registrations, dictionaries, effects } = makeCtx({ sessions, workspaces })
	exports.apply(ctx)
	const registration = registrations[0]
	const injected = registration.entry.options.inject()
	// DSH's slot renderer reserves the key `hooks` in an entry's inject() face:
	// it binds every member as a `use<Name>` prop and REMOVES the key before the
	// component sees it (`runInject` → `bindInjectSources` in
	// dsh-client-ui-renderer). Mirror that transformation here — otherwise a
	// regression that puts the plugin's stores back under `hooks` would pass in
	// these tests and crash in the real slots (which is exactly what happened:
	// the footer entry was retired with active:false for weeks).
	const rendererFace = { ...injected }
	delete rendererFace.hooks
	// A convenience view for the helpers below: the same injected face, with the
	// stores also reachable under `hooks` (tests drive the stores directly, not
	// through the component's props).
	const face = { ...injected, hooks: injected.seats ?? injected.hooks }
	const props = {
		...rendererFace,
		// The slot hands the component every surviving injected prop; the resolved
		// icons and the tooltip helper travel with it.
		t: (key, params) => (params === undefined ? key : `${key}${JSON.stringify(params)}`)
	}
	const renderEntry = () => react.withHooks('MultiSelectEntry', () => registration.entry.component(props))
	/**
	 * Open the panel the way the document-level trigger does 鈥?through the
	 * plugin's own store 鈥?then render the entry that should show it.
	 */
	const openAndRender = () => {
		face.hooks.panel.set({ open: true })
		return renderEntry()
	}
	/**
	 * The panel element the open entry renders: the modal holds the error
	 * boundary, and the boundary holds the panel.
	 */
	const panelElementOf = () => openAndRender().props.children[1].props.children.props.children
	/**
	 * Render the open entry and return the rendered panel body. The jsx
	 * stand-in records elements without invoking them (React does that at
	 * commit), so the panel is driven explicitly here.
	 */
	const renderPanelBody = (overrides = {}) => {
		const panelElement = panelElementOf()
		return react.withHooks('MultiSelectPanel', () => panelElement.type({ ...panelElement.props, ...overrides }))
	}
	return {
		exports,
		registration: bundle.registration,
		primitives,
		react,
		sessions,
		workspaces,
		dictionaries,
		effects,
		slotKey: registration.key,
		entry: registration.entry,
		face,
		props,
		renderEntry,
		panelElementOf,
		openAndRender,
		renderPanelBody,
		/** Run the effect callbacks the component body queued (the stand-in never commits). */
		runEffects: () => { for (const fn of react.effects.splice(0)) fn() }
	}
}

// --- tests ------------------------------------------------------------------

test('apply registers dictionaries, a store, and the footer slot entry', () => {
	const world = mount()
	assert.deepEqual(world.exports.inject, ['slots', 'locale', 'sessions'])
	assert.equal(world.registration.id, 'dsh-session-multiselect')

	const options = world.entry.options
	assert.equal(world.slotKey, 'sidebar.footer.action')
	assert.equal(options.name, 'sidebar.footer.action')
	assert.equal(options.id, 'session-multiselect')
	assert.equal(options.locale, 'sessionMultiselect')
	assert.equal(typeof world.entry.component, 'function')

	for (const method of ['deleteSessions', 'markInlineProven']) {
		assert.equal(typeof world.face.actions[method], 'function', `actions.${method}`)
	}
	assert.equal(typeof world.face.hooks.sessions.getSnapshot, 'function')
	assert.equal(typeof world.face.hooks.sessions.subscribe, 'function')
	assert.equal(typeof world.face.hooks.store.getSnapshot, 'function')
	assert.equal(typeof world.face.hooks.store.actions.setArchived, 'function')

	const dicts = world.dictionaries.get('sessionMultiselect')
	assert.ok(dicts.zh !== undefined && dicts.en !== undefined)
	assert.deepEqual(Object.keys(dicts.zh).sort(), Object.keys(dicts.en).sort(), 'zh and en must share a key set')
	for (const key of Object.keys(dicts.zh)) {
		assert.equal(typeof dicts.zh[key], 'string', `zh.${key}`)
		assert.equal(typeof dicts.en[key], 'string', `en.${key}`)
	}
	assert.ok(world.effects.some((effect) => effect.label.includes('dictionaries')))
})

test('the footer inject face keeps the stores out of the renderer-reserved `hooks` key', () => {
	// dsh-client-ui-renderer's runInject() treats an inject() face's `hooks`
	// member as its injected-hook DSL: every entry becomes a `use<Name>` prop and
	// the key is deleted before the component renders. Shipping the plugin's
	// snapshot stores under that name handed the footer entry `undefined` and
	// crashed it, so the slot retired the entry — the fallback button was dead
	// while the header button hid the failure.
	const world = mount({ items: [{ sessionId: 'a', title: 'Alpha', updatedAt: 30 }] })
	const injected = world.entry.options.inject()
	assert.equal(Object.hasOwn(injected, 'hooks'), false, 'inject() must not use the renderer-reserved `hooks` key')
	assert.equal(typeof injected.seats?.panel?.subscribe, 'function', 'the stores travel as `seats`')
	// Rendered with the renderer-shaped props (which omit `hooks`), the entry
	// still paints — the component no longer depends on the reserved key.
	assert.doesNotThrow(() => world.renderEntry(), 'the footer entry renders without a `hooks` prop')
})

test('every locale key the panel asks for exists in both dictionaries', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20, running: true }
		]
	})
	const dicts = world.dictionaries.get('sessionMultiselect')
	const asked = new Set()
	const record = (key, params) => {
		asked.add(key)
		return params === undefined ? key : `${key}${JSON.stringify(params)}`
	}
	world.renderPanelBody({ t: record })
	assert.deepEqual([...asked].filter((key) => !(key in dicts.zh)), [], 'keys missing from the zh dictionary')
	assert.deepEqual([...asked].filter((key) => !(key in dicts.en)), [], 'keys missing from the en dictionary')
	assert.ok(asked.size > 10, `the panel should ask for a real set of labels, saw ${String(asked.size)}`)
})

test('apply mounts with its own dialog when the platform seeds no primitives', () => {
	// DSH 0.2 seeds React, Cordis and static libraries only, and its authoring
	// guide says not to require a Harness client package at all. A build like that
	// must cost chrome, never the feature: the plugin draws its own dialog, its own
	// controls, and its own store.
	const bundle = loadBundle()
	const { exports } = bundle.instantiate({}, makeReact())
	const { ctx, registrations, dictionaries } = makeCtx({ sessions: makeSessions() })
	exports.apply(ctx)

	const face = registrations[0].entry.options.inject()
	assert.equal(typeof face.icons.checklist, 'function', 'the icons fall back to their own artwork')
	assert.equal(typeof face.actions.entry, 'function', 'and the actions are all there')
	assert.ok(dictionaries.has('sessionMultiselect'), 'the dictionaries registered as usual')

	// The entry's dialog is this bundle's own implementation, driven by the same
	// props the primitives' Modal takes. The props are the renderer-shaped ones:
	// the reserved `hooks` key never reaches the component.
	const rendererFace = { ...face }
	delete rendererFace.hooks
	const rendered = makeReact().withHooks('MultiSelectEntry', () => registrations[0].entry.component({
		...rendererFace,
		t: (key) => key
	}))
	const modal = rendered.props.children[1]
	assert.equal(modal.type, exports.LocalModal, 'the dialog is the local one')
	assert.equal(modal.props.open, false, 'closed until the button is clicked')
	assert.equal(modal.props.title, 'panel.title')

	// The store fallback keeps the preferences the panel reads, with the same
	// surface: getSnapshot / subscribe / actions.
	const store = face.seats.store
	assert.equal(typeof store.getSnapshot, 'function')
	assert.equal(typeof store.subscribe, 'function')
	assert.equal(store.getSnapshot().groupByWorkspace, true, 'the fallback store seeds its defaults')
	assert.deepEqual(Object.keys(store.getSnapshot()).sort(), ['archivedIds', 'filter', 'groupByWorkspace', 'groupMode', 'inlineProven', 'pinnedIds'])
})

test('a renamed or missing icon falls back to its own artwork instead of failing the mount', () => {
	const bundle = loadBundle()
	const primitives = makePrimitives([])
	// DSH 0.10 renamed every icon; a build that renames them again must cost a
	// glyph, not the feature.
	delete primitives.IconChecklistOutlineRegular
	delete primitives.IconSearchOutlineRegular
	delete primitives.IconLoadingOutlineRegular
	const { exports } = bundle.instantiate(primitives, makeReact())
	const { ctx, registrations } = makeCtx({ sessions: makeSessions() })
	exports.apply(ctx)
	const face = registrations[0].entry.options.inject()
	assert.equal(typeof face.icons.checklist, 'function')
	assert.notEqual(face.icons.checklist, primitives.IconChecklistOutlineRegular)
	// The fallback is a real inline icon: an svg with the shipped path data.
	const rendered = face.icons.checklist({ size: 16 })
	assert.equal(rendered.type, 'svg')
	assert.equal(rendered.props.viewBox, '0 0 16 16')
	assert.ok(rendered.props.children.length > 0)
})

test('a primitives table without Tooltip still renders a working entry button', () => {
	const bundle = loadBundle()
	const primitives = makePrimitives([])
	delete primitives.Tooltip
	const { exports } = bundle.instantiate(primitives, makeReact())
	const { ctx, registrations } = makeCtx({ sessions: makeSessions() })
	exports.apply(ctx)
	const face = registrations[0].entry.options.inject()
	const button = face.tip('tip text', { type: 'button' })
	assert.equal(button.type, 'button', 'the tooltip wrapper is skipped, the button is not')
})

test('store setArchived adds and removes ids, and nothing else', () => {
	const world = mount()
	const store = world.face.hooks.store

	assert.deepEqual(store.getSnapshot().archivedIds, [], 'nothing is archived to begin with')
	store.actions.setArchived(['a', 'b'], true)
	assert.deepEqual([...store.getSnapshot().archivedIds].sort(), ['a', 'b'])
	store.actions.setArchived(['b'], false)
	assert.deepEqual([...store.getSnapshot().archivedIds], ['a'])
	// The pin mark has no local fallback (it is either a real pin or nothing), so
	// the plugin store holds: the fallback archive mark, the grouping preference,
	// and the proof flag.
	assert.deepEqual(Object.keys(store.getSnapshot()).sort(), ['archivedIds', 'filter', 'groupByWorkspace', 'groupMode', 'inlineProven', 'pinnedIds'])
	assert.deepEqual(store.getSnapshot().pinnedIds, [], 'pinning never writes a private mark')
})


test('deleteSessions reports per-session failures without aborting the batch', async () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'A', updatedAt: 3 },
			{ sessionId: 'b', title: 'B', updatedAt: 2 }
		]
	})
	// `missing` is not in the list: the host route reports it as already gone
	// (`ok: true, removed: false`), which the panel counts as deleted — the
	// user's intent is "this row must not come back". Every id still reaches the
	// route, and the batch is not aborted by the odd one out.
	const result = await world.face.actions.deleteSessions(['a', 'missing', 'b'])
	assert.equal(result.ok, 3, 'an already-gone session counts as deleted')
	assert.equal(result.failed.length, 0)
	assert.deepEqual(world.sessions.calls.deleted, ['a', 'missing', 'b'])
	world.sessions.restoreFetch()
})

test('a missing delete route blames the un-restarted host, not the session', async () => {
	const world = mount({
		items: [{ sessionId: 'a', title: 'A', updatedAt: 3 }]
	})
	// This is the state the user actually hit: the client half shipped, the Node
	// half in the running DSH did not (host plugins do not hot-reload). A bare
	// 404 would read like "no such session" and send them looking in the wrong
	// place, so the reason must name the restart.
	const realFetch = globalThis.fetch
	globalThis.fetch = async () => ({ status: 404, ok: false, async json() { return {} } })
	try {
		const result = await world.face.actions.deleteSessions(['a'])
		assert.equal(result.ok, 0)
		assert.equal(result.failed.length, 1)
		assert.equal(result.failed[0].id, 'a')
		assert.match(result.failed[0].reason, /重启 DSH/u)
		assert.doesNotMatch(result.failed[0].reason, /not a function/u)
	} finally {
		globalThis.fetch = realFetch
		world.sessions.restoreFetch()
	}
})

test('the entry renders closed, and opening it reveals the panel', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30 },
			{ sessionId: 'blank', blank: true, updatedAt: 20 }
		]
	})
	const closed = world.renderEntry()
	const [wrapper, modal] = closed.props.children
	assert.equal(wrapper.type, world.primitives.Tooltip, 'the footer entry is tooltipped')
	assert.equal(modal.type, world.primitives.Modal)
	assert.equal(modal.props.open, false, 'the modal starts closed')
	assert.equal(modal.props.children, null, 'a closed modal renders no panel body')

	const open = world.openAndRender()
	const openModal = open.props.children[1]
	assert.equal(openModal.props.open, true)
	assert.equal(openModal.props.title, 'panel.title')
	assert.ok(openModal.props.children !== null, 'an open modal renders the panel body')
	// The panel sits inside the error boundary: a render crash then shows as a
	// message in the dialog instead of unmounting the button that opened it.
	const boundary = openModal.props.children
	assert.equal(boundary.type, world.exports.PanelBoundary, 'the panel is wrapped in the error boundary')
	assert.equal(boundary.props.children.type, world.exports.MultiSelectPanel, 'and the boundary holds the panel')
	assert.equal(typeof boundary.props.format, 'function', 'the boundary can phrase the failure')
})

test('a crashed panel reports the reason instead of unmounting the view', () => {
	const world = mount()
	const Boundary = world.exports.PanelBoundary
	const healthy = new Boundary({ format: (reason) => `failed: ${reason}`, children: null })
	assert.equal(healthy.render(), null, 'a healthy boundary renders its children')
	healthy.state = { error: new Error('boom') }
	const fallback = healthy.render()
	assert.equal(fallback.props['data-tone'], 'error', 'the fallback reads as an error')
	assert.match(fallback.props.children, /failed: boom/u, 'and it carries the reason')
})

/**
 * The panel's list element, plus readers for the two kinds of child it paints.
 *
 * Grouping interleaves workspace headings with rows, so a test that wants rows
 * has to ask for rows: positional indexing into the child array would silently
 * start reading headings after a layout change like that one.
 */
function listOf(body) {
	return body.props.children[1]
}

/** The list's children as an array; the empty state is a single element. */
function listChildren(body) {
	const children = listOf(body).props.children
	return Array.isArray(children) ? children : []
}

function toolbarButton(toolbar, label) {
	const button = toolbar.props.children.find((child) => child !== null && child !== undefined && child.props !== undefined && child.props.children === label)
	assert.ok(button !== undefined, `the toolbar must offer "${label}"`)
	return button
}

/** Concatenate the text a rendered subtree would show. */
function treeText(node) {
	if (node === null || node === undefined || typeof node === 'boolean') return ''
	if (typeof node === 'string' || typeof node === 'number') return String(node)
	if (Array.isArray(node)) return node.map(treeText).join('')
	if (typeof node === 'object' && node.props !== undefined) return treeText(node.props.children)
	return ''
}

function listRows(body) {
	return listChildren(body).filter((node) => node.props.className === 'dsh-msel-row')
}

/**
 * The buttons of the confirmation strip.
 *
 * A title-list line was added between the copy and the buttons, so index-based
 * walks through the strip are brittle; find its toolbar by class instead.
 */
function confirmButtons(body) {
	const bar = body.props.children[2]
	assert.ok(bar !== null && bar !== undefined, 'a confirmation strip must be open')
	const toolbar = bar.props.children.find((child) => child !== null && child !== undefined && child.props !== undefined && child.props.className === 'dsh-msel-toolbar')
	assert.ok(toolbar !== undefined, 'the confirmation strip has a toolbar')
	return toolbar.props.children
}

function listGroups(body) {
	return listChildren(body).filter((node) => node.props.className === 'dsh-msel-group')
}

/** The conversation title a rendered row shows. */
function rowTitle(row) {
	return row.props.children[1].props.children[0].props.children
}

test('both session-list snapshot shapes list the same sessions', () => {
	const rowsOf = (shape) => {
		const world = mount({
			shape,
			items: [
				{ sessionId: 'a', title: 'Alpha', updatedAt: 30, cwd: 'D:\\x' },
				{ sessionId: 'b', blank: true, updatedAt: 20 },
				{ sessionId: 'c', title: 'Gamma', updatedAt: 10 }
			]
		})
		return listRows(world.renderPanelBody()).map(rowTitle)
	}
	const normalized = rowsOf('normalized')
	// The controller hands the UI `{ ids, byId }`; reading only a flattened
	// `items` array is how the panel ends up listing nothing at all.
	assert.deepEqual(normalized, ['Alpha', 'Gamma'], 'the controller鈥檚 { ids, byId } snapshot lists sessions')
	assert.deepEqual(rowsOf('items'), normalized, 'and so does the flattened projection')
})

test('selecting one row selects exactly that row, not every row', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30, cwd: 'D:\\x' },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20 },
			{ sessionId: 'c', title: 'Gamma', updatedAt: 10 }
		]
	})
	const rows = listRows(world.renderPanelBody())
	// Drive the row the way a user does. Every row used to share one key because
	// the snapshot files sessions under `id` while the panel read `sessionId`,
	// so this single toggle marked all three.
	rows[0].props.onClick({ shiftKey: false, ctrlKey: false, metaKey: false })
	const after = listRows(world.renderPanelBody())
	const selected = after.filter((row) => row.props['aria-selected'] === true)
	assert.equal(selected.length, 1, 'exactly one row is selected')
	assert.equal(rowTitle(selected[0]), 'Alpha')
	assert.equal(after[1].props['aria-selected'], false, 'and the others are not')
})

test('the panel shows localized copy even when no slot provides a translator', () => {
	const helpers = globalThis.__DSH_SESSION_MULTISELECT__
	const english = helpers.makeTranslator({ zh: helpers.dicts.zh, en: helpers.dicts.en, active: () => 'en' })
	const chinese = helpers.makeTranslator({ zh: helpers.dicts.zh, en: helpers.dicts.en, active: () => 'zh' })
	// The header panel used to fall back to the identity function, which put
	// `panel.title` on screen verbatim.
	assert.notEqual(english('panel.title'), 'panel.title')
	assert.equal(chinese('panel.title'), helpers.dicts.zh['panel.title'])
	assert.equal(english('panel.title'), helpers.dicts.en['panel.title'])
	// `{name}` interpolation, and an unknown key surviving as itself.
	assert.match(chinese('count.selected', { n: 2, m: 5 }), /2/u)
	assert.equal(chinese('no.such.key'), 'no.such.key')
})

test('a summary filed under `id` still lists with its title', () => {
	const world = mount({ items: [{ sessionId: 'a', title: 'Alpha', updatedAt: 30 }] })
	const rows = listRows(world.renderPanelBody())
	assert.equal(rows.length, 1, 'the real byId shape lists a row')
	assert.equal(rowTitle(rows[0]), 'Alpha', 'its displayTitle is used')
})

test('the open panel lists one row per selectable session and hides blank ones', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30, cwd: 'D:\\x' },
			{ sessionId: 'blank', blank: true, updatedAt: 20 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 10, running: true }
		]
	})
	const body = world.renderPanelBody()
	const list = listOf(body)
	const rows = listRows(body)
	assert.equal(rows.length, 2, 'blank sessions must not render a row')
	assert.deepEqual(rows.map(rowTitle), ['Alpha', 'Beta'])
	assert.match(rows[0].props.className, /dsh-msel-row/u)
	assert.equal(rows[0].props['aria-selected'], false)
	assert.equal(rows[0].props['data-selected'], 'false')
	assert.equal(list.props.role, 'listbox')
	assert.equal(list.props['aria-multiselectable'], 'true')
})

test('the panel hides subagent sessions the shell itself never lists', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30, cwd: 'D:\\x' },
			// `origin: 'subagent'` is how DSH's own sidebar decides a session is a
			// session-log internal: it badges the parent with a running-child count
			// and never renders a row. Its bare-UUID id is what used to poison a
			// delete batch, so the panel must not offer it either.
			{ sessionId: '11111111-1111-1111-1111-111111111111', title: 'Child agent', updatedAt: 25, cwd: 'D:\\x', origin: 'subagent', parentId: 'a' },
			{ sessionId: 'b', title: 'Beta', updatedAt: 10, cwd: 'D:\\x' }
		]
	})
	const rows = listRows(world.renderPanelBody())
	assert.deepEqual(rows.map(rowTitle), ['Alpha', 'Beta'], 'no row for the subagent session')
	// The group heading counts only real conversations, too.
	const heading = listGroups(world.renderPanelBody())[0]
	assert.equal(heading.props.children[2].props.children, 'group.count{"n":0,"m":2}')
})

test('the restore view lists trashed conversations and puts one back', async () => {
	const world = mount({
		items: [{ sessionId: 'a', title: 'Alpha', updatedAt: 30 }],
		trashEntries: [{ id: 'gone', title: 'Gone', workspace: 'D:\\x', deletedAt: 1700000000000, entry: '1-gone' }]
	})
	const body = world.renderPanelBody()
	const toolbar = body.props.children[0]
	const trashButton = toolbar.props.children[toolbar.props.children.length - 1]
	assert.equal(trashButton.props.children, 'trash.open', 'the toolbar offers the restore view')

	trashButton.props.onClick()
	await flush()
	const trashView = world.renderPanelBody()
	assert.equal(trashView.props.children[0].props.children[0].props.children, 'trash.title', 'the toolbar switches to the trash')
	const rows = trashView.props.children[1].props.children
	assert.equal(rows.length, 1)
	assert.ok(rows[0].props.className.includes('dsh-msel-trashRow'), 'that row is a trash entry')
	// Two lines: title on its own line (full width), workspace + deleted time under
	// it. The old single-line layout collapsed the title to zero width whenever the
	// encoded workspace name was long, which it always is.
	const main = rows[0].props.children[1]
	assert.equal(main.props.className, 'dsh-msel-trashMain')
	assert.equal(main.props.children[0].props.className, 'dsh-msel-trashTitle')
	assert.equal(main.props.children[0].props.children, 'Gone', 'the captured title is shown')
	const sub = main.props.children[1]
	assert.equal(sub.props.className, 'dsh-msel-trashSub')
	assert.equal(sub.props.children[1].props.className, 'dsh-msel-trashWhen')
	assert.match(String(sub.props.children[1].props.children), /trash\.deletedAt/u)
	assert.equal(sub.props.children[2].props.className, 'dsh-msel-trashRemaining', 'the remaining days are shown')
	assert.match(String(sub.props.children[2].props.children), /trash\.remaining/u)
	const trashActions = rows[0].props.children[2]
	assert.equal(trashActions.props.className, 'dsh-msel-trashAction')
	const restoreButton = trashActions.props.children[0]
	assert.equal(restoreButton.props.children, 'trash.restore')
	assert.equal(trashActions.props.children[1].props.children, 'trash.purge', 'each row can be purged for good')

	restoreButton.props.onClick()
	for (let tick = 0; tick < 5; tick += 1) await flush()
	assert.deepEqual(world.sessions.calls.restored, ['gone'], 'restore goes through the host route')
	assert.equal(world.sessions.calls.trashRequests, 2, 'the restore view reloads after the restore')
	assert.equal(world.sessions.calls.refreshed, 1, 'the session list is re-pulled so the row comes back')
	const status = world.renderPanelBody().props.children.find((child) => child !== null && child !== undefined && child.props !== undefined && child.props['data-tone'] !== undefined)
	assert.match(String(status.props.children), /trash\.restored/u)

	// Back to the conversation list: the session row is there again.
	toolbarButton(trashView.props.children[0], 'trash.back').props.onClick()
	const back = world.renderPanelBody()
	const backToolbar = back.props.children[0]
	assert.equal(backToolbar.props.children[backToolbar.props.children.length - 1].props.children, 'trash.open', 'the toolbar offers the trash again')
	assert.deepEqual(listRows(back).map(rowTitle), ['Alpha'])
})

test('the trash can permanently delete one entry and be emptied in one go', async () => {
	const world = mount({
		items: [{ sessionId: 'a', title: 'Alpha', updatedAt: 30 }],
		trashEntries: [
			{ id: 'gone', title: 'Gone', workspace: 'D:\\x', deletedAt: 1700000000000, entry: '1-gone' },
			{ id: 'gone2', title: 'Gone2', workspace: 'D:\\x', deletedAt: 1700000000000, entry: '2-gone2' }
		]
	})
	world.renderPanelBody()
	const openToolbar = world.renderPanelBody().props.children[0]
	openToolbar.props.children[openToolbar.props.children.length - 1].props.onClick() // open the trash
	await flush()

	// Per-row permanent delete asks first, then purges exactly that entry.
	const trashView = world.renderPanelBody()
	const purgeButton = trashView.props.children[1].props.children[0].props.children[2].props.children[1]
	assert.equal(purgeButton.props.children, 'trash.purge')
	purgeButton.props.onClick()
	await flush()
	const oneConfirm = world.renderPanelBody().props.children[2]
	assert.ok(oneConfirm !== null, 'the purge asks for confirmation')
	assert.match(String(oneConfirm.props.children[0].props.children), /trash\.purgeOneConfirm/u)
	assert.match(String(oneConfirm.props.children[0].props.children), /Gone/u, 'the confirmation names the conversation')
	confirmButtons(world.renderPanelBody())[0].props.onClick()
	for (let tick = 0; tick < 5; tick += 1) await flush()
	assert.deepEqual(world.sessions.calls.purged, ['gone'], 'only the confirmed entry is purged')
	assert.equal(world.sessions.calls.purgeRequests, 1)

	// The empty-trash button in the trash toolbar purges everything.
	const trashToolbar = world.renderPanelBody().props.children[0]
	const emptyButton = toolbarButton(trashToolbar, 'trash.purgeAll')
	assert.equal(emptyButton.props.children, 'trash.purgeAll')
	emptyButton.props.onClick()
	await flush()
	const allConfirm = world.renderPanelBody().props.children[2]
	assert.match(String(allConfirm.props.children[0].props.children), /trash\.purgeAllConfirm/u)
	confirmButtons(world.renderPanelBody())[0].props.onClick()
	for (let tick = 0; tick < 5; tick += 1) await flush()
	assert.equal(world.sessions.calls.purged.at(-1), 'all', 'the whole trash is purged')
	world.sessions.restoreFetch()
})

test('trash rows can be selected and restored or purged as a batch', async () => {
	const world = mount({
		items: [{ sessionId: 'a', title: 'Alpha', updatedAt: 30 }],
		trashEntries: [
			{ id: 'gone', title: 'Gone', workspace: 'D:\\x', deletedAt: 1700000000000, entry: '1-gone' },
			{ id: 'gone2', title: 'Gone2', workspace: 'D:\\y', deletedAt: 1700000000000, entry: '2-gone2' }
		]
	})
	world.renderPanelBody()
	toolbarButton(world.renderPanelBody().props.children[0], 'trash.open').props.onClick()
	await flush()

	// Clicking a trash row checks it; the toolbar count follows.
	let view = world.renderPanelBody()
	const rows = view.props.children[1].props.children
	assert.equal(rows.length, 2)
	assert.equal(rows[0].props['aria-selected'], false)
	rows[0].props.onClick()
	view = world.renderPanelBody()
	assert.deepEqual(view.props.children[1].props.children.map((row) => row.props['aria-selected']), [true, false])
	assert.match(String(view.props.children[0].props.children[4].props.children), /"n":1/u, 'the selected count updates')

	// The batch row offers restore/purge and restore sends exactly the checked ids.
	const actions = view.props.children[3].props.children
	assert.equal(actions[0].props.children, 'trash.restoreSelected')
	assert.equal(actions[1].props.children, 'trash.purgeSelected')
	actions[0].props.onClick()
	for (let tick = 0; tick < 6; tick += 1) await flush()
	assert.deepEqual(world.sessions.calls.restored, ['gone'], 'only the checked entry is restored')
	assert.equal(world.sessions.calls.refreshed, 1, 'the session list is re-pulled after a batch restore')

	// Select all, then purge the whole selection behind one confirmation.
	view = world.renderPanelBody()
	toolbarButton(view.props.children[0], 'all.select').props.onClick()
	view = world.renderPanelBody()
	assert.equal(view.props.children[1].props.children.filter((row) => row.props['aria-selected'] === true).length, 2)
	view.props.children[3].props.children[1].props.onClick()
	view = world.renderPanelBody()
	assert.match(String(view.props.children[2].props.children[0].props.children), /trash\.purgeBatchConfirm/u)
	confirmButtons(view)[0].props.onClick()
	for (let tick = 0; tick < 6; tick += 1) await flush()
	assert.deepEqual(world.sessions.calls.purged, ['gone', 'gone2'], 'both checked entries are purged')
	world.sessions.restoreFetch()
})

test('the panel marks a row the host still holds open', async () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20 }
		],
		liveIds: ['a']
	})
	world.renderPanelBody()
	world.runEffects()
	for (let tick = 0; tick < 4; tick += 1) await flush()
	const rendered = world.renderPanelBody()
	assert.match(treeText(listRows(rendered)[0].props.children[1]), /row\.open/u, 'the open row carries the badge')
	assert.doesNotMatch(treeText(listRows(rendered)[1].props.children[1]), /row\.open/u)
	world.sessions.restoreFetch()
})

test('the delete confirmation pre-checks running and open conversations', async () => {
	const world = mount({
		items: [
			{ sessionId: 'busy', title: 'Busy', updatedAt: 30, running: true },
			{ sessionId: 'open', title: 'Open', updatedAt: 20 }
		],
		liveIds: ['busy', 'open']
	})
	world.renderPanelBody()
	world.react.setterOf('MultiSelectPanel', 2)(new Set(['busy', 'open']))
	world.renderPanelBody().props.children[3].props.children[0].props.onClick() // arm the delete
	for (let tick = 0; tick < 4; tick += 1) await flush()
	const confirmText = treeText(world.renderPanelBody().props.children[2])
	assert.match(confirmText, /confirm\.deleteRunning\{"n":"1"\}/u, 'a running conversation is called out')
	assert.match(confirmText, /confirm\.deleteOpen\{"n":"1"\}/u, 'an idle-but-open conversation is called out')
	world.sessions.restoreFetch()
})

test('the panel supports keyboard select-all, toggling and row navigation', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 3 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 2 },
			{ sessionId: 'c', title: 'Gamma', updatedAt: 1 }
		]
	})
	const body = world.renderPanelBody()
	// Ctrl+A on the panel root selects every visible row.
	body.props.onKeyDown({ key: 'a', ctrlKey: true, preventDefault() {} })
	let rows = listRows(world.renderPanelBody())
	assert.deepEqual(rows.map((row) => row.props['data-selected']), ['true', 'true', 'true'])

	// Space toggles the focused row only.
	rows[0].props.onKeyDown({ key: ' ', preventDefault() {} })
	rows = listRows(world.renderPanelBody())
	assert.deepEqual(rows.map((row) => row.props['data-selected']), ['false', 'true', 'true'])

	// ArrowDown moves the active row and takes the browser focus with it.
	rows[0].props.onKeyDown({ key: 'ArrowDown', preventDefault() {} })
	rows = listRows(world.renderPanelBody())
	assert.deepEqual(rows.map((row) => row.props['data-active']), ['false', 'true', 'false'])

	// Delete opens the confirmation for the current selection.
	world.renderPanelBody().props.onKeyDown({ key: 'Delete', preventDefault() {} })
	assert.ok(world.renderPanelBody().props.children[2] !== null, 'Delete arms the confirmation')
})

test('the trash can be searched and filtered by workspace', async () => {
	const world = mount({
		items: [{ sessionId: 'a', title: 'Alpha', updatedAt: 30 }],
		trashEntries: [
			{ id: 'gone', title: 'Gone', workspace: '--D-x--', deletedAt: 1700000000000, entry: '1-gone' },
			{ id: 'gone2', title: 'Gone2', workspace: '--D-y--', deletedAt: 1700000000000, entry: '2-gone2' }
		]
	})
	world.renderPanelBody()
	toolbarButton(world.renderPanelBody().props.children[0], 'trash.open').props.onClick()
	await flush()

	// The search box narrows by title or decoded workspace path.
	let view = world.renderPanelBody()
	let toolbar = view.props.children[0]
	assert.equal(toolbar.props.children[1].props.placeholder, 'trash.searchPlaceholder')
	toolbar.props.children[1].props.onChange({ target: { value: 'gone2' } })
	view = world.renderPanelBody()
	assert.equal(view.props.children[1].props.children.length, 1)
	assert.match(treeText(view.props.children[1]), /Gone2/u)

	// Clearing the search restores both rows; the workspace select narrows to one.
	view.props.children[0].props.children[1].props.onChange({ target: { value: '' } })
	view = world.renderPanelBody()
	assert.equal(view.props.children[1].props.children.length, 2)
	const select = view.props.children[0].props.children[2]
	assert.equal(select.props.className, 'dsh-msel-select')
	assert.equal(select.props.children[0].props.children, 'trash.allWorkspaces')
	const optionY = select.props.children.find((option) => option.props.value === '--D-y--')
	assert.equal(optionY.props.children, 'D:\\y', 'the workspace is decoded for the filter')
	select.props.onChange({ target: { value: '--D-y--' } })
	view = world.renderPanelBody()
	assert.equal(view.props.children[1].props.children.length, 1)
	assert.match(treeText(view.props.children[1]), /Gone2/u)

	// Ctrl+A selects only what the filter shows, and the count follows.
	world.renderPanelBody().props.onKeyDown({ key: 'a', ctrlKey: true, preventDefault() {} })
	const selectedCount = world.renderPanelBody().props.children[0].props.children[4].props.children
	assert.match(String(selectedCount), /"n":1/u)

	// A search with no match shows the filtered empty state, not the trash-empty one.
	world.renderPanelBody().props.children[0].props.children[1].props.onChange({ target: { value: 'zzz' } })
	view = world.renderPanelBody()
	assert.match(treeText(view.props.children[1]), /list\.emptyFiltered/u)
})

test('the panel can group by date and filter to running or pinned rows', () => {
	const now = Date.now()
	const items = [
		{ sessionId: 'a', title: 'Today', updatedAt: now - 1000, cwd: 'D:\\alpha', running: true },
		{ sessionId: 'b', title: 'Older', updatedAt: now - (3 * 86400000), cwd: 'D:\\beta' },
		{ sessionId: 'c', title: 'Oldest', updatedAt: now - (30 * 86400000), cwd: 'D:\\alpha' }
	]
	const world = mount({ items })
	world.face.hooks.store.actions.setGroupMode('date')
	let body = world.renderPanelBody()
	const headings = listGroups(body).map((group) => treeText(group))
	assert.ok(headings.some((heading) => heading.includes('date.today')), 'today gets its own heading')
	assert.ok(headings.some((heading) => heading.includes('date.week')), 'the older row is under last 7 days')
	assert.ok(headings.some((heading) => heading.includes('date.earlier')), 'the oldest row is under earlier')
	assert.equal(listRows(body).length, 3)

	// Filtering keeps the list honest: running shows one, pinned shows the pinned one.
	const filterSelect = () => world.renderPanelBody().props.children[0].props.children
		.find((node) => node.props.className === 'dsh-msel-select' && node.props['aria-label'] === 'filter.by')
	filterSelect().props.onChange({ target: { value: 'running' } })
	assert.deepEqual(listRows(world.renderPanelBody()).map(rowTitle), ['Today'])
	world.face.hooks.store.actions.setFilter('all')
	filterSelect().props.onChange({ target: { value: 'pinned' } })
	assert.deepEqual(listRows(world.renderPanelBody()).map(rowTitle), [])
	world.face.hooks.store.actions.setFilter('all')
})

test('the visible list can be copied as Markdown', async () => {
	const copied = []
	const hadNavigator = globalThis.navigator !== undefined
	const clipboard = { writeText: async (value) => { copied.push(value) } }
	if (hadNavigator) Object.defineProperty(globalThis.navigator, 'clipboard', { value: clipboard, configurable: true })
	else Object.defineProperty(globalThis, 'navigator', { value: { clipboard }, configurable: true })
	try {
		const world = mount({
			items: [
				{ sessionId: 'session-aaaaaaaa-1111', title: 'Alpha', updatedAt: 1700000000000, cwd: 'D:\\alpha' },
				{ sessionId: 'session-bbbbbbbb-2222', title: 'Beta|pipe', updatedAt: 1700000000000, cwd: '' }
			]
		})
		const body = world.renderPanelBody()
		const copyButton = body.props.children[3].props.children.find((node) => node.props.children === 'export.copy')
		assert.ok(copyButton !== undefined, 'the action row offers the copy button')
		copyButton.props.onClick()
		for (let tick = 0; tick < 4; tick += 1) await flush()
		assert.equal(copied.length, 1, 'the clipboard received the table')
		assert.match(copied[0], /\| export\.title \|/u, 'the table has a localized header')
		assert.match(copied[0], /Alpha/u)
		assert.match(copied[0], /Beta.*pipe/u, 'the pipe is escaped inside the cell')
		const status = world.renderPanelBody().props.children.find((child) => child !== null && child !== undefined && child.props !== undefined && child.props['data-tone'] !== undefined)
		assert.match(String(status.props.children), /export\.copied/u)
		world.sessions.restoreFetch()
	} finally {
		if (hadNavigator) delete globalThis.navigator.clipboard
		else delete globalThis.navigator
	}
})

test('the panel heads every workspace group and selects one with a single click', () => {
	const items = [
		{ sessionId: 'a', title: 'Alpha', updatedAt: 30, cwd: 'D:\\alpha' },
		{ sessionId: 'b', title: 'Beta', updatedAt: 20, cwd: 'D:\\beta' },
		{ sessionId: 'c', title: 'Gamma', updatedAt: 10, cwd: 'D:\\alpha' },
		{ sessionId: 'd', title: 'Delta', updatedAt: 5 }
	]
	const world = mount({ items })
	const body = world.renderPanelBody()
	const groups = listGroups(body)
	assert.equal(groups.length, 3, 'one heading per workspace, plus the unnamed remainder')
	// The workspace whose newest conversation is newest leads; sessions with no
	// workspace trail, so the named headings stay meaningful.
	assert.deepEqual(groups.map((group) => group.props['data-workspace']), ['D:\\alpha', 'D:\\beta', ''])
	// The heading carries the whole path 鈥?two workspaces can share a last segment.
	assert.deepEqual(groups.map((group) => group.props.children[1].props.children), ['D:\\alpha', 'D:\\beta', 'group.noWorkspace'])
	assert.match(groups[1].props.children[0].props['aria-label'], /beta$/u, 'the accessible name stays short and readable')
	assert.deepEqual(listRows(body).map(rowTitle), ['Alpha', 'Gamma', 'Beta', 'Delta'], 'each row stays under its own heading')
	assert.equal(listOf(body).props.children.length, 7, 'headings and rows are interleaved, nothing else paints')

	groups[0].props.onClick()
	const after = listRows(world.renderPanelBody())
	assert.deepEqual(after.map((row) => row.props['aria-selected']), [true, true, false, false], 'one click takes the whole workspace')
	assert.equal(listGroups(world.renderPanelBody())[1].props['data-complete'], 'false', 'an untouched group is not marked complete')
	assert.equal(listGroups(world.renderPanelBody())[0].props['data-complete'], 'true')
})

test('turning grouping off paints one flat recency list', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30, cwd: 'D:\\alpha' },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20, cwd: 'D:\\beta' },
			{ sessionId: 'c', title: 'Gamma', updatedAt: 10, cwd: 'D:\\alpha' }
		]
	})
	const body = world.renderPanelBody()
	const groupSelect = body.props.children[0].props.children
		.find((node) => node.props.className === 'dsh-msel-select' && node.props['aria-label'] === 'group.mode')
	assert.equal(groupSelect.props.value, 'workspace', 'grouping by workspace is the default')
	groupSelect.props.onChange({ target: { value: 'none' } })
	const flat = world.renderPanelBody()
	assert.equal(listGroups(flat).length, 0, 'no headings once grouping is off')
	assert.deepEqual(listRows(flat).map(rowTitle), ['Alpha', 'Beta', 'Gamma'], 'and rows fall back to plain recency')
})

test('a selected row updates the count and enables the batch actions', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20 }
		]
	})
	world.renderPanelBody() // first paint, so the panel's own setters exist
	// Panel hook order: [0] query, [1] showArchived, [2] selection, [3] cursor.
	world.react.setterOf('MultiSelectPanel', 2)((current) => new Set([...current, 'a']))
	const body = world.renderPanelBody()
	const rows = listRows(body)
	assert.equal(rows[0].props['aria-selected'], true, 'the selected row reports selection')
	assert.equal(rows[0].props['data-selected'], 'true')
	assert.equal(rows[1].props['aria-selected'], false)
	const toolbar = body.props.children[0]
	// The toolbar now ends with the trash toggle; the selected count is beside it.
	const count = toolbar.props.children[toolbar.props.children.length - 2]
	assert.match(count.props.children, /count\.selected/u)
	assert.match(count.props.children, /"n":1/u)
	const actionRow = body.props.children[3]
	assert.equal(actionRow.props.children[0].props.disabled, false, 'delete is enabled with a selection')
})

test('the panel shows the empty state for an empty list', () => {
	const world = mount()
	const body = world.renderPanelBody()
	const list = listOf(body)
	assert.equal(list.type, 'div', 'the list container is a plain element')
	assert.equal(list.props.children.type, 'div', 'a single empty-state element renders as one child')
	assert.match(list.props.children.props.className, /dsh-msel-empty/u)
	assert.equal(list.props.children.props.children, 'list.empty')
	// With nothing selectable, every batch action stays disabled.
	const actionRow = body.props.children[3]
	for (const button of actionRow.props.children) {
		assert.equal(button.props.disabled, true, 'batch actions stay disabled with no selection')
	}
})

test('select-all selects every visible row and then offers to clear', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20 }
		]
	})
	world.renderEntry()
	const body = world.renderPanelBody()
	const selectAll = body.props.children[0].props.children[1]
	assert.equal(selectAll.props.children, 'all.select')
	assert.equal(selectAll.props.disabled, false)
	selectAll.props.onClick()
	const next = world.renderPanelBody()
	const rows = listRows(next)
	assert.deepEqual(rows.map((row) => row.props['aria-selected']), [true, true])
	const toolbar = next.props.children[0]
	assert.equal(toolbar.props.children[1].props.children, 'all.clear')
	assert.match(toolbar.props.children[toolbar.props.children.length - 2].props.children, /"n":2/u)
})

test('delete asks for confirmation, then re-pulls the list so the row leaves', async () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20 }
		]
	})
	world.renderPanelBody() // first paint, so the panel's own setters exist
	world.react.setterOf('MultiSelectPanel', 2)(new Set(['a']))
	const before = world.renderPanelBody()
	assert.equal(before.props.children[2], null, 'no confirmation panel before the click')

	// The delete button only arms the confirmation.
	before.props.children[3].props.children[0].props.onClick()
	const armed = world.renderPanelBody()
	const confirmPanel = armed.props.children[2]
	assert.ok(confirmPanel !== null, 'the confirmation panel appears')
	assert.match(confirmPanel.props.children[0].props.children, /confirm\.delete/u)
	const listed = confirmPanel.props.children[1]
	assert.ok(listed !== null && listed !== undefined, 'the confirmation lists the selected conversations')
	assert.match(String(listed.props.children[0].props.children), /Alpha/u)
	assert.deepEqual(world.sessions.calls.deleted, [], 'nothing is deleted before confirmation')

	// Confirming starts the deletion (the batch runs asynchronously).
	assert.deepEqual(confirmButtons(armed)[0].props.children, 'confirm.yes', 'the strip offers the confirm button')
	confirmButtons(armed)[0].props.onClick()
	assert.deepEqual(world.sessions.calls.deleted, ['a'])
	await flush()
	assert.equal(world.sessions.calls.refreshed, 1, 'the deleted row must leave the list without a reload')
	// The row is gone; the other one is untouched.
	assert.deepEqual(listRows(world.renderPanelBody()).map(rowTitle), ['Beta'])
})

test('a running conversation is refused locally, by title, and never reaches the route', async () => {
	const world = mount({
		items: [
			{ sessionId: 'busy', title: 'Busy', updatedAt: 30, running: true },
			{ sessionId: 'idle', title: 'Idle', updatedAt: 20 }
		]
	})
	world.renderPanelBody()
	world.react.setterOf('MultiSelectPanel', 2)(new Set(['busy', 'idle']))
	world.renderPanelBody().props.children[3].props.children[0].props.onClick() // arm the confirmation
	confirmButtons(world.renderPanelBody())[0].props.onClick()
	for (let tick = 0; tick < 6; tick += 1) await flush()

	assert.deepEqual(world.sessions.calls.deleted, ['idle'], 'a running conversation is not sent')
	const status = world.renderPanelBody().props.children.find((child) => child !== null && child !== undefined && child.props !== undefined && child.props['data-tone'] !== undefined)
	assert.equal(status.props['data-tone'], 'error')
	assert.match(String(status.props.children), /status\.deleteFailed/u)
	assert.match(String(status.props.children), /「Busy」/u, 'the failure names the conversation by title')
	assert.match(String(status.props.children), /会话正在运行|conversation is running|会话正在/u, 'the reason explains why it was skipped')
})

test('a deleted conversation that DSH still holds open says when its row leaves', async () => {
	const world = mount({
		items: [{ sessionId: 'opened', title: 'Opened', updatedAt: 30 }],
		openOnDelete: ['opened']
	})
	world.renderPanelBody()
	world.react.setterOf('MultiSelectPanel', 2)(new Set(['opened']))
	world.renderPanelBody().props.children[3].props.children[0].props.onClick()
	confirmButtons(world.renderPanelBody())[0].props.onClick()
	for (let tick = 0; tick < 6; tick += 1) await flush()

	assert.deepEqual(world.sessions.calls.deleted, ['opened'])
	const status = world.renderPanelBody().props.children.find((child) => child !== null && child !== undefined && child.props !== undefined && child.props['data-tone'] !== undefined)
	assert.equal(status.props['data-tone'], 'info')
	assert.match(String(status.props.children), /status\.deletedOpen/u)
	// The Host keeps the live row in its list; the panel must hide it locally so
	// the conversation does not look undeleted while the files are in the trash.
	assert.deepEqual(listRows(world.renderPanelBody()), [], 'the deleted row is hidden until restart')
})

test('a selection larger than one route batch travels as sequential requests', async () => {
	// Ids ride in the query string, so the host caps one request at 200 ids and
	// the panel chunks at the same size: a very large selection deletes 200 at a
	// time instead of failing once as an opaque request-line (431) error.
	const items = Array.from({ length: 250 }, (_, index) => ({
		sessionId: `session-${String(index).padStart(4, '0')}-1111-1111-1111-111111111111`,
		title: `Session ${String(index)}`,
		updatedAt: 1000 - index
	}))
	const world = mount({ items })
	world.renderPanelBody()
	world.react.setterOf('MultiSelectPanel', 2)(new Set(items.map((item) => item.sessionId)))
	world.renderPanelBody().props.children[3].props.children[0].props.onClick() // arm the confirmation
	confirmButtons(world.renderPanelBody())[0].props.onClick()
	for (let tick = 0; tick < 10; tick += 1) await flush()
	assert.equal(world.sessions.calls.deleted.length, 250, 'every id was sent')
	assert.equal(world.sessions.calls.deleteRequests, 2, '250 ids travel as 200 + 50')
	assert.equal(world.sessions.calls.refreshed, 1, 'the list is re-pulled once after both batches')
})

test('the panel offers three actions, and the last two work in both directions', async () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20 }
		]
	})
	world.renderPanelBody() // first paint, so the panel's own setters exist
	world.react.setterOf('MultiSelectPanel', 2)(new Set(['a', 'b']))
	const body = world.renderPanelBody()
	const actionRow = body.props.children[3]
	assert.deepEqual(actionRow.props.children.map((button) => button.props.children),
		['action.delete', 'action.archive', 'action.pin', 'export.copy'], 'delete, archive, pin — nothing else')

	// Archiving hides the rows (the panel lists unarchived rows only), and the
	// button flips to the reverse direction for the archived selection.
	actionRow.props.children[1].props.onClick()
	await flush()
	// No workspace service in this mount, so the mark is this plugin's own — and
	// the status line has to say so rather than claim a real archive.
	assert.deepEqual([...world.face.hooks.marks.getSnapshot().archivedIds].sort(), ['a', 'b'])
	assert.equal(world.face.hooks.marks.getSnapshot().real, false)
	assert.equal(listRows(world.renderPanelBody()).length, 0, 'archived rows leave the default list')

	world.react.setterOf('MultiSelectPanel', 1)(true) // "show archived"
	const shown = world.renderPanelBody()
	assert.equal(listRows(shown).length, 2)
	const shownActions = shown.props.children[3]
	assert.equal(shownActions.props.children[1].props.children, 'action.unarchive', 'the button offers the way back')
	assert.equal(shownActions.props.children[1].props.disabled, false, 'the selection is still there')
	shownActions.props.children[1].props.onClick()
	await flush()
	assert.deepEqual([...world.face.hooks.marks.getSnapshot().archivedIds], [])
})

test('archive and pin reach the workspace service when the build has one', async () => {
	const workspaces = makeWorkspaces()
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha', updatedAt: 30 },
			{ sessionId: 'b', title: 'Beta', updatedAt: 20 }
		],
		workspaces
	})
	assert.equal(world.face.hooks.marks.getSnapshot().real, true, 'the panel reads the service’s marks')
	world.renderPanelBody()
	world.react.setterOf('MultiSelectPanel', 2)(new Set(['a', 'b']))
	world.renderPanelBody().props.children[3].props.children[1].props.onClick()
	await flush()
	assert.deepEqual(workspaces.calls.archived, ['a', 'b'], 'archiving goes through archiveSession')
	// The service publishes the new set, so the panel follows DSH's own list.
	assert.deepEqual([...world.face.hooks.marks.getSnapshot().archivedIds].sort(), ['a', 'b'])
	assert.equal(world.face.hooks.marks.getSnapshot().real, true)
	assert.equal(listRows(world.renderPanelBody()).length, 0, 'the archived rows leave the list')

	// The same service answers the pin button, in both directions.
	workspaces.calls.archived.length = 0
	const fresh = mount({
		items: [{ sessionId: 'a', title: 'Alpha', updatedAt: 30 }],
		workspaces: makeWorkspaces()
	})
	fresh.renderPanelBody()
	fresh.react.setterOf('MultiSelectPanel', 2)(new Set(['a']))
	const pinRow = fresh.renderPanelBody().props.children[3]
	assert.equal(pinRow.props.children[2].props.children, 'action.pin')
	pinRow.props.children[2].props.onClick()
	await flush()
	assert.deepEqual(fresh.workspaces.calls.pinned, ['a'], 'pinning goes through pinSession')
	const pinnedRow = fresh.renderPanelBody()
	assert.equal(pinnedRow.props.children[3].props.children[2].props.children, 'action.unpin', 'and the button flips')
	// Row meta: the tags come first, so a pinned row is recognisable even when the
	// pinned group heading is out of view.
	const meta = listRows(pinnedRow)[0].props.children[1].props.children[1]
	assert.equal(meta.props.children[0].props.children, 'row.pinned', 'the row carries the pinned tag')
	pinnedRow.props.children[3].props.children[2].props.onClick()
	await flush()
	assert.deepEqual(fresh.workspaces.calls.unpinned, ['a'])
})

test('a build without a pinning API says so instead of pretending', async () => {
	const world = mount({ items: [{ sessionId: 'a', title: 'Alpha', updatedAt: 30 }] })
	world.renderPanelBody()
	world.react.setterOf('MultiSelectPanel', 2)(new Set(['a']))
	world.renderPanelBody().props.children[3].props.children[2].props.onClick()
	await flush()
	assert.deepEqual(world.face.hooks.marks.getSnapshot().pinnedIds, [], 'nothing was pinned')
	assert.deepEqual(world.face.hooks.store.getSnapshot().archivedIds, [], 'and nothing else changed')
})




test('searching filters the rows and reports an empty result', () => {
	const world = mount({
		items: [
			{ sessionId: 'a', title: 'Alpha work', updatedAt: 30 },
			{ sessionId: 'b', title: 'Beta work', updatedAt: 20 }
		]
	})
	world.renderEntry()
	world.renderPanelBody()
	// Panel hook order: [0] query.
	world.react.setterOf('MultiSelectPanel', 0)('beta')
	const body = world.renderPanelBody()
	const rows = listRows(body)
	assert.equal(rows.length, 1)
	assert.equal(rowTitle(rows[0]), 'Beta work')

	world.react.setterOf('MultiSelectPanel', 0)('nothing matches this')
	const empty = world.renderPanelBody()
	assert.equal(listOf(empty).props.children.props.children, 'list.emptyFiltered')
})
