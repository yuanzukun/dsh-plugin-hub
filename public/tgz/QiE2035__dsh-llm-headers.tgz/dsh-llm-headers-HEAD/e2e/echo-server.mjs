/** Echo server for the llm-headers e2e smoke: records incoming request headers and returns a canned DeepSeek-style stream. */
import http from 'node:http'

const port = Number(process.env.PORT ?? 8734)
const seen = []

const server = http.createServer((req, res) => {
  seen.push({ url: req.url, headers: req.headers })
  console.log(`[echo] ${req.method} ${req.url}`)
  console.log(`[echo] user-agent: ${typeof req.headers['user-agent'] === 'string' ? req.headers['user-agent'] : '(missing)'}`)
  res.writeHead(200, { 'content-type': 'text/event-stream' })
  const chunk = (content, finish = false) => JSON.stringify({
    id: 'e2e-1',
    object: 'chat.completion.chunk',
    created: 1,
    model: 'deepseek-v4-flash',
    choices: [{ index: 0, delta: { role: 'assistant', content }, finish_reason: finish ? 'stop' : null }],
  })
  res.write(`data: ${chunk('ECHO-SENTINEL')}\n\n`)
  res.write(`data: ${chunk('', true)}\n\n`)
  res.write('data: [DONE]\n\n')
  res.end()
})

server.listen(port, () => {
  console.log(`[echo] listening on ${port}`)
})

async function shutdown() {
  console.log(`[echo] requests seen: ${seen.length}`)
  for (const entry of seen) {
    console.log(`[echo] ${entry.url}`)
    console.log(`[echo] user-agent: ${typeof entry.headers['user-agent'] === 'string' ? entry.headers['user-agent'] : '(missing)'}`)
  }
  server.close()
  process.exit(0)
}

process.on('SIGINT', shutdown)
process.on('SIGTERM', shutdown)