import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    include: ['test/**/*.test.{ts,tsx}'],
    environment: 'node',
    coverage: {
      provider: 'v8',
      // .tsx: client components are gated like everything else (jsdom lane).
      include: ['src/**/*.{ts,tsx}'],
      // 100% or it doesn't merge; per-file so a well-covered big file can't
      // subsidize a bare one.
      thresholds: {
        perFile: true,
        statements: 100,
        branches: 100,
        functions: 100,
        lines: 100,
      },
      reporter: process.env.CI ? ['text'] : ['text', 'html'],
    },
  },
})