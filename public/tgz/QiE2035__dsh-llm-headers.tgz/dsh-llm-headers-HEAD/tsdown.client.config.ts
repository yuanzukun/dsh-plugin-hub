import { defineConfig } from 'tsdown'

/**
 * Browser-half bundle: a closure-factory artifact the web client module loader
 * registers (`window.__ModuleLoader__.load({ id, factory })`). The factory's
 * `require` resolves externals through the loader module table — react and the
 * Host's client services — never globals or an import map.
 */
const PLUGIN_ID = 'dsh-llm-headers'

export default defineConfig({
  entry: ['src/client/index.ts'],
  outDir: 'lib',
  format: ['cjs'],
  platform: 'browser',
  target: 'es2022',
  clean: false,
  dts: false,
  deps: {
    neverBundle: ['react', 'react/jsx-runtime'],
  },
  outputOptions: {
    entryFileNames: 'client.js',
    banner: `window.__ModuleLoader__.load({ id: ${JSON.stringify(PLUGIN_ID)}, factory: (require) => {`,
    intro: 'var module = { exports: {} }; var exports = module.exports;',
    footer: 'return module.exports; } });',
  },
})