// @vitest-environment jsdom

/**
 * Card component tests: render every interactive branch of the llm-headers
 * card against a stubbed snapshot, asserting the copy, the draft lifecycle
 * (edit → save/discard/reset), the failure surfaces, and the disabled state
 * while a write is in flight. The locale dictionary is the real `en` copy.
 */

import { cleanup, fireEvent, render, screen } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { CardSnapshot } from '../src/client/controller.ts'
import { LlmHeadersCard, type LlmHeadersCardProps } from '../src/client/LlmHeadersCard.tsx'
import { en } from '../src/client/locales.ts'

const SERVER_VALUE = { headers: { 'user-agent': 'opencode/1.0' }, urlPatterns: ['/chat/completions'] }

function baseSnapshot(): CardSnapshot {
  return {
    available: true,
    value: SERVER_VALUE,
    saving: false,
    failed: false,
    conflict: false,
    revision: 3,
    save: vi.fn(async () => true),
    refresh: vi.fn(async () => {}),
    reset: vi.fn(async () => true),
  }
}

/** Render the card over a snapshot stub; the returned snapshot carries the spies. */
function mount(overrides: Partial<CardSnapshot> = {}) {
  const snapshot = { ...baseSnapshot(), ...overrides }
  const props: LlmHeadersCardProps = {
    t: key => en[key],
    useLlmHeadersCard: selector => selector(snapshot),
  }
  const view = render(<LlmHeadersCard {...props} />)
  return { ...view, snapshot }
}

afterEach(() => {
  cleanup()
})

describe('LlmHeadersCard', () => {
  it('renders the title and description', () => {
    mount()
    expect(screen.getByText(en.title)).toBeTruthy()
    expect(screen.getByText(en.description)).toBeTruthy()
  })

  it('shows the unavailable state without controls', () => {
    mount({ available: false, value: undefined })
    expect(screen.getByText(en.unavailable)).toBeTruthy()
    expect(screen.queryByRole('button', { name: en.addHeader })).toBeNull()
    expect(screen.queryByText(en.dirtyHint)).toBeNull()
  })

  it('collapses the controls until the header is clicked', () => {
    mount()
    expect(screen.getByRole('button', { expanded: false })).toBeTruthy()
    expect(screen.queryByPlaceholderText(en.headerName)).toBeNull()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    expect(screen.getByRole('button', { expanded: true })).toBeTruthy()
    expect(screen.getByPlaceholderText(en.headerName)).toBeTruthy()
  })

  it('reveals the server rows and disables the actions until dirty', async () => {
    mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    expect(screen.getByDisplayValue('opencode/1.0')).toBeTruthy()
    expect(screen.getByDisplayValue('/chat/completions')).toBeTruthy()
    expect(screen.queryByText(en.dirtyHint)).toBeNull()
    const save = screen.getByRole('button', { name: en.save }) as HTMLButtonElement
    const discard = screen.getByRole('button', { name: en.discard }) as HTMLButtonElement
    const reset = screen.getByRole('button', { name: en.reset }) as HTMLButtonElement
    expect(save.disabled).toBe(true)
    expect(discard.disabled).toBe(true)
    // Reset only yields to a write in flight, so it stays available pre-dirty.
    expect(reset.disabled).toBe(false)
    await flushLater()
  })

  it('marks the draft dirty on edits and saves the built section', async () => {
    const { snapshot } = mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.change(screen.getByPlaceholderText(en.headerName), { target: { value: 'x-brand' } })
    fireEvent.change(screen.getByPlaceholderText(en.headerValue), { target: { value: 'acme' } })
    expect(screen.getByText(en.dirtyHint)).toBeTruthy()
    const save = screen.getByRole('button', { name: en.save }) as HTMLButtonElement
    expect(save.disabled).toBe(false)
    fireEvent.click(save)
    await vi.waitFor(() => {
      expect(snapshot.save).toHaveBeenCalledWith({
        headers: { 'x-brand': 'acme' },
        urlPatterns: ['/chat/completions'],
      })
    })
    // Accepted save re-seeds the draft from the server value and clears the dirty flag.
    await vi.waitFor(() => { expect(screen.queryByText(en.dirtyHint)).toBeNull() })
    expect(screen.getByDisplayValue('opencode/1.0')).toBeTruthy()
  })

  it('edits a pattern and persists it with the draft', async () => {
    const { snapshot } = mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.change(screen.getByPlaceholderText(en.patternPlaceholder), { target: { value: '/v1/chat/completions' } })
    expect(screen.getByText(en.dirtyHint)).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: en.save }))
    await vi.waitFor(() => {
      expect(snapshot.save).toHaveBeenCalledWith({
        headers: { 'user-agent': 'opencode/1.0' },
        urlPatterns: ['/v1/chat/completions'],
      })
    })
  })

  it('keeps the draft and reports the failure when the save is rejected', async () => {
    mount({ save: vi.fn(async () => false), failed: true })
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.change(screen.getByPlaceholderText(en.headerName), { target: { value: 'x-brand' } })
    fireEvent.click(screen.getByRole('button', { name: en.save }))
    await vi.waitFor(() => { expect(screen.getByText(en.saveFailed)).toBeTruthy() })
    expect(screen.getByText(en.dirtyHint)).toBeTruthy()
    expect(screen.getByDisplayValue('x-brand')).toBeTruthy()
  })

  it('distinguishes a conflict from a plain rejection', async () => {
    mount({ save: vi.fn(async () => false), failed: true, conflict: true })
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    expect(screen.getByText(en.saveConflict)).toBeTruthy()
  })

  it('disables every control while a save is in flight', () => {
    mount({ saving: true })
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    expect(screen.getByText(en.saving)).toBeTruthy()
    const inputs = screen.getAllByRole('textbox') as HTMLInputElement[]
    expect(inputs.every(input => input.disabled)).toBe(true)
    const buttons = [
      new RegExp(en.addHeader),
      new RegExp(en.addPattern),
      new RegExp(en.saving),
      en.discard,
      en.reset,
    ]
    for (const name of buttons) {
      expect(screen.getByRole<HTMLButtonElement>('button', { name }).disabled).toBe(true)
    }
  })

  it('adds and removes header rows', async () => {
    mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.click(screen.getByRole('button', { name: new RegExp(en.addHeader) }))
    expect(screen.getAllByPlaceholderText(en.headerName)).toHaveLength(2)
    fireEvent.click(screen.getAllByRole('button', { name: en.removeRow })[1]!)
    expect(screen.getAllByPlaceholderText(en.headerName)).toHaveLength(1)
    await flushLater()
  })

  it('adds and removes pattern rows', async () => {
    mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.click(screen.getByRole('button', { name: new RegExp(en.addPattern) }))
    expect(screen.getAllByPlaceholderText(en.patternPlaceholder)).toHaveLength(2)
    fireEvent.click(screen.getAllByRole('button', { name: en.removeRow })[1]!)
    expect(screen.getAllByPlaceholderText(en.patternPlaceholder)).toHaveLength(1)
    await flushLater()
  })

  it('patches only the targeted row and pattern', () => {
    mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.click(screen.getByRole('button', { name: new RegExp(en.addHeader) }))
    fireEvent.click(screen.getByRole('button', { name: new RegExp(en.addPattern) }))
    fireEvent.change(screen.getAllByPlaceholderText(en.headerName)[0]!, { target: { value: 'x-brand' } })
    fireEvent.change(screen.getAllByPlaceholderText(en.patternPlaceholder)[0]!, { target: { value: '/v1/x' } })
    expect((screen.getAllByPlaceholderText(en.headerName)[1]! as HTMLInputElement).value).toBe('')
    expect((screen.getAllByPlaceholderText(en.patternPlaceholder)[1]! as HTMLInputElement).value).toBe('')
  })

  it('discards the draft back to the server value', () => {
    mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.change(screen.getByPlaceholderText(en.headerName), { target: { value: 'x-brand' } })
    expect(screen.getByText(en.dirtyHint)).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: en.discard }))
    expect(screen.queryByText(en.dirtyHint)).toBeNull()
    expect(screen.getByDisplayValue('opencode/1.0')).toBeTruthy()
  })

  it('clears the dirty flag when the reset is accepted and keeps it otherwise', async () => {
    const accepted = mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.change(screen.getByPlaceholderText(en.headerName), { target: { value: 'x-brand' } })
    fireEvent.click(screen.getByRole('button', { name: en.reset }))
    await vi.waitFor(() => { expect(accepted.snapshot.reset).toHaveBeenCalled() })
    await vi.waitFor(() => { expect(screen.queryByText(en.dirtyHint)).toBeNull() })

    cleanup()
    const rejected = mount({ reset: vi.fn(async () => false) })
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.change(screen.getByPlaceholderText(en.headerName), { target: { value: 'x-brand' } })
    fireEvent.click(screen.getByRole('button', { name: en.reset }))
    await vi.waitFor(() => { expect(rejected.snapshot.reset).toHaveBeenCalled() })
    await vi.waitFor(() => { expect(screen.getByText(en.dirtyHint)).toBeTruthy() })
  })

  it('adopts a server value that arrived after the initial seed', () => {
    const first = mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    const serverAfter = { ...SERVER_VALUE, headers: { 'user-agent': 'opencode/2.0' } }
    first.rerender(
      <LlmHeadersCard
        t={key => en[key]}
        useLlmHeadersCard={selector => selector({ ...first.snapshot, value: serverAfter })}
      />,
    )
    expect(screen.getByDisplayValue('opencode/2.0')).toBeTruthy()
  })

  it('keeps an in-progress draft when the server value changes', () => {
    const first = mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.change(screen.getByPlaceholderText(en.headerName), { target: { value: 'x-brand' } })
    const serverAfter = { ...SERVER_VALUE, headers: { 'user-agent': 'opencode/2.0' } }
    first.rerender(
      <LlmHeadersCard
        t={key => en[key]}
        useLlmHeadersCard={selector => selector({ ...first.snapshot, value: serverAfter })}
      />,
    )
    expect(screen.getByDisplayValue('x-brand')).toBeTruthy()
    expect(screen.getByText(en.dirtyHint)).toBeTruthy()
  })

  it('refreshes the server snapshot once when the card opens', async () => {
    const { snapshot } = mount()
    expect(snapshot.refresh).not.toHaveBeenCalled()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    await vi.waitFor(() => { expect(snapshot.refresh).toHaveBeenCalledTimes(1) })
  })

  it('tracks focus and hover element state', () => {
    mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    const input = screen.getByPlaceholderText(en.headerName) as HTMLInputElement
    fireEvent.focus(input)
    fireEvent.blur(input)
    // A plain Firefox-safe probe: the element survives the state round-trips.
    expect(screen.getByPlaceholderText(en.headerName)).toBe(input)
    const remove = screen.getAllByRole('button', { name: en.removeRow })[0]!
    fireEvent.mouseEnter(remove)
    fireEvent.mouseLeave(remove)
    expect(screen.getAllByRole('button', { name: en.removeRow })).toHaveLength(2)
  })

  it('tracks the discard hover next to a dirty draft', () => {
    mount()
    fireEvent.click(screen.getByRole('button', { expanded: false }))
    fireEvent.change(screen.getByPlaceholderText(en.headerName), { target: { value: 'x-brand' } })
    const discard = screen.getByRole('button', { name: en.discard })
    fireEvent.mouseEnter(discard)
    fireEvent.mouseLeave(discard)
    expect(screen.getByRole<HTMLButtonElement>('button', { name: en.discard }).disabled).toBe(false)
  })

  it('tracks the card-shell hover state', () => {
    mount()
    const shell = document.querySelector<HTMLElement>('[data-plugin-card="llm-headers"]')!
    fireEvent.mouseEnter(shell)
    fireEvent.mouseLeave(shell)
    expect(shell.getAttribute('data-plugin-card')).toBe('llm-headers')
  })
})

/** Settle React state flushes that leave no observable waitable element. */
async function flushLater(): Promise<void> {
  await Promise.resolve()
  await Promise.resolve()
}
