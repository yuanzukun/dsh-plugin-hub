import { describe, expect, it, vi } from 'vitest'
import { installFetchProxy, type FetchProxyOptions } from '../src/fetch-proxy.ts'

/** A fetch stub capturing every call and returning a bare ok Response. */
function stubFetch() {
  return vi.fn<typeof fetch>(async () => new Response(null, { status: 200 }))
}

function headersOf(call: Parameters<typeof fetch>[1]): Headers {
  return new Headers(call?.headers)
}

const DEFAULT_OPTIONS = {
  headers: { 'user-agent': 'opencode/1.0' },
  urlPatterns: ['/chat/completions'],
}

describe('installFetchProxy', () => {
  it('injects configured headers into a matching request', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, DEFAULT_OPTIONS)
    await proxy('https://gateway.example/chat/completions', {
      method: 'POST',
      headers: { authorization: 'Bearer key' },
    })
    expect(original).toHaveBeenCalledTimes(1)
    const headers = headersOf(original.mock.calls[0]![1])
    expect(headers.get('user-agent')).toBe('opencode/1.0')
    // Host-provided headers survive untouched.
    expect(headers.get('authorization')).toBe('Bearer key')
  })

  it('passes a non-matching request through untouched', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, DEFAULT_OPTIONS)
    const init = { headers: { authorization: 'Bearer key' } }
    await proxy('https://example.com/robots.txt', init)
    expect(original).toHaveBeenCalledTimes(1)
    expect(original.mock.calls[0]![1]).toBe(init)
  })

  it('overwrites an existing user-agent on the request', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, DEFAULT_OPTIONS)
    await proxy('https://gateway.example/chat/completions', {
      headers: { 'user-agent': 'deepseek-harness/0.1.0 (+https://github.com/deepseek-ai/deepseek-harness)' },
    })
    expect(headersOf(original.mock.calls[0]![1]).get('user-agent')).toBe('opencode/1.0')
  })

  it('normalizes Headers-instance and array init forms', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, DEFAULT_OPTIONS)
    await proxy('https://gateway.example/chat/completions', {
      headers: new Headers({ 'x-extra': 'one' }),
    })
    await proxy('https://gateway.example/chat/completions', {
      headers: [['x-extra', 'two']],
    })
    expect(headersOf(original.mock.calls[0]![1]).get('user-agent')).toBe('opencode/1.0')
    expect(headersOf(original.mock.calls[0]![1]).get('x-extra')).toBe('one')
    expect(headersOf(original.mock.calls[1]![1]).get('x-extra')).toBe('two')
  })

  it('classifies a URL-instance input by its href', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, DEFAULT_OPTIONS)
    await proxy(new URL('https://gateway.example/chat/completions'), { headers: { authorization: 'Bearer key' } })
    expect(original).toHaveBeenCalledTimes(1)
    expect(headersOf(original.mock.calls[0]![1]).get('user-agent')).toBe('opencode/1.0')
  })

  it('classifies a same-realm Request input by its url', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, DEFAULT_OPTIONS)
    await proxy(new Request('https://gateway.example/chat/completions'), { headers: { authorization: 'Bearer key' } })
    expect(original).toHaveBeenCalledTimes(1)
    expect(headersOf(original.mock.calls[0]![1]).get('user-agent')).toBe('opencode/1.0')
  })

  it('rewrites a Request input by its own URL, preserving its own headers', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, DEFAULT_OPTIONS)
    const request = new Request('https://gateway.example/chat/completions', {
      headers: { authorization: 'Bearer key' },
    })
    await proxy(request)
    // Without an init object the wrapper seeds from the Request's own headers,
    // so injection must not strip what the caller already put on it.
    const headers = headersOf(original.mock.calls[0]![1])
    expect(headers.get('user-agent')).toBe('opencode/1.0')
    expect(headers.get('authorization')).toBe('Bearer key')
  })

  it('passes all requests through untouched when urlPatterns is empty', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, { headers: { 'user-agent': 'opencode/1.0' }, urlPatterns: [] })
    const init = { headers: { authorization: 'Bearer key' } }
    await proxy('https://gateway.example/chat/completions', init)
    expect(original.mock.calls[0]![1]).toBe(init)
  })

  it('drops empty-string patterns instead of matching every URL', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, { headers: { 'user-agent': 'opencode/1.0' }, urlPatterns: [''] })
    const init = { headers: { authorization: 'Bearer key' } }
    await proxy('https://gateway.example/chat/completions', init)
    // The sole empty pattern must not make every URL match.
    expect(original.mock.calls[0]![1]).toBe(init)
    // Non-empty patterns alongside empty ones survive derivation.
    const { proxy: proxy2 } = installFetchProxy(original, { headers: { 'user-agent': 'opencode/1.0' }, urlPatterns: ['', '/chat/completions'] })
    await proxy2('https://gateway.example/chat/completions', init)
    expect(headersOf(original.mock.calls[1]![1]).get('user-agent')).toBe('opencode/1.0')
    await proxy2('https://example.com/robots.txt', init)
    expect(original.mock.calls[2]![1]).toBe(init)
  })

  it('tolerates a configuration missing urlPatterns through update', async () => {
    const original = stubFetch()
    const { proxy, update } = installFetchProxy(original, DEFAULT_OPTIONS)
    // The type requires urlPatterns; the defensive runtime path is exercised
    // against a config that omits it (a direct caller or a bare settings layer).
    update({ headers: { 'user-agent': 'opencode/2.0' } } as unknown as FetchProxyOptions)
    const init = { headers: { authorization: 'Bearer key' } }
    await proxy('https://gateway.example/chat/completions', init)
    // No patterns means no match: untouched, and no `.some` of undefined throw.
    expect(original.mock.calls[0]![1]).toBe(init)
  })

  it('tolerates a configuration missing headers through update', async () => {
    const original = stubFetch()
    const { proxy, update } = installFetchProxy(original, DEFAULT_OPTIONS)
    // The type requires headers; the defensive runtime path is exercised
    // against a config that omits it (a direct caller or a bare settings layer).
    update({ urlPatterns: ['/chat/completions'] } as unknown as FetchProxyOptions)
    const init = { headers: { authorization: 'Bearer key' } }
    await proxy('https://gateway.example/chat/completions', init)
    // No headers means nothing to inject: the init passes through untouched.
    expect(original.mock.calls[0]![1]).toBe(init)
  })

  it('skips a redundant update that passes the same options reference', async () => {
    const original = stubFetch()
    const { proxy, update } = installFetchProxy(original, DEFAULT_OPTIONS)
    await proxy('https://gateway.example/chat/completions')
    // Settings attach fires the resolved config twice at boot; the second call
    // with the identical reference must be a no-op, not a re-derivation.
    update(DEFAULT_OPTIONS)
    update(DEFAULT_OPTIONS)
    await proxy('https://gateway.example/chat/completions')
    expect(original).toHaveBeenCalledTimes(2)
    expect(headersOf(original.mock.calls[1]![1]).get('user-agent')).toBe('opencode/1.0')
  })

  it('passes an unclassifiable (foreign-realm) request through untouched', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, DEFAULT_OPTIONS)
    // A plain object with a matching `url` is not a same-realm Request, so the
    // wrapper cannot read it safely and must pass it through unchanged.
    const input = { url: 'https://gateway.example/chat/completions' } as unknown as RequestInfo
    const init = { headers: { authorization: 'Bearer key' } }
    await proxy(input, init)
    expect(original).toHaveBeenCalledTimes(1)
    expect(original.mock.calls[0]![0]).toBe(input)
    expect(original.mock.calls[0]![1]).toBe(init)
  })

  it('passes everything through when headers are empty', async () => {
    const original = stubFetch()
    const { proxy } = installFetchProxy(original, { headers: {}, urlPatterns: ['/chat/completions'] })
    const init = { headers: { authorization: 'Bearer key' } }
    await proxy('https://gateway.example/chat/completions', init)
    expect(original.mock.calls[0]![1]).toBe(init)
  })

  it('applies an updated configuration to the next request', async () => {
    const original = stubFetch()
    const { proxy, update } = installFetchProxy(original, DEFAULT_OPTIONS)
    await proxy('https://gateway.example/chat/completions')
    update({
      headers: { 'user-agent': 'opencode/2.0', 'x-brand': 'acme' },
      urlPatterns: ['/chat/completions'],
    })
    await proxy('https://gateway.example/chat/completions')
    expect(headersOf(original.mock.calls[0]![1]).get('user-agent')).toBe('opencode/1.0')
    const second = headersOf(original.mock.calls[1]![1])
    expect(second.get('user-agent')).toBe('opencode/2.0')
    expect(second.get('x-brand')).toBe('acme')
  })

  it('exposes the captured original for later restoration', () => {
    const original = stubFetch()
    const { proxy, original: captured } = installFetchProxy(original, DEFAULT_OPTIONS)
    expect(proxy).not.toBe(original)
    expect(captured).toBe(original)
  })
})
