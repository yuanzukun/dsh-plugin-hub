/**
 * Client-side pure logic tests: draft narrowing, section normalization, the
 * RPC envelope, and the controller's snapshot state machine. All run in the
 * node environment — the wire is exercised against a stubbed `globalThis.fetch`.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { buildSection, draftOf } from '../src/client/draft.ts'
import { LlmHeadersController, normalize } from '../src/client/controller.ts'
import { loadSection, saveSection } from '../src/client/headers-wire.ts'

/** A fetch stub echoing the request's rpcId and answering per-endpoint results. */
function stubFetch(results: { get: unknown; set: unknown }) {
  const calls: Array<{ method: string; payload: unknown; input: string }> = []
  const mock = vi.fn<(input: string | URL, init?: RequestInit) => Promise<Response>>(async (input, init) => {
    const body = JSON.parse(init?.body as string) as { type?: string; rpcId?: string; method?: string; payload?: unknown }
    calls.push({ method: body.method ?? '', payload: body.payload, input: input instanceof URL ? input.href : input })
    return new Response(JSON.stringify({
      type: 'server-response',
      rpcId: body.rpcId ?? 'missing',
      result: results[body.method === 'set' ? 'set' : 'get'],
    }), { status: 200, headers: { 'content-type': 'application/json' } })
  })
  return { mock, calls }
}

const LOADED = {
  value: { headers: { 'user-agent': 'opencode/1.0' }, urlPatterns: ['/chat/completions'] },
  revision: 3,
}

describe('draft helpers', () => {
  it('seeds an empty draft from no section', () => {
    expect(draftOf(undefined)).toEqual({ headers: [], urlPatterns: [] })
  })

  it('seeds rows from a server section', () => {
    expect(draftOf(LOADED.value)).toEqual({
      headers: [{ name: 'user-agent', value: 'opencode/1.0' }],
      urlPatterns: ['/chat/completions'],
    })
  })

  it('builds a section that drops unnamed rows and empty patterns', () => {
    const next = buildSection({
      headers: [
        { name: '', value: 'stray' },
        { name: 'x-empty', value: '' },
        { name: 'x-brand', value: 'acme' },
      ],
      urlPatterns: ['/chat/completions', ''],
    })
    // An empty header VALUE survives; an empty NAME and an empty pattern do not.
    expect(next).toEqual({
      headers: { 'x-empty': '', 'x-brand': 'acme' },
      urlPatterns: ['/chat/completions'],
    })
  })
})

describe('normalize', () => {
  it('tolerates an absent section', () => {
    expect(normalize(undefined)).toEqual({ headers: {}, urlPatterns: [] })
    expect(normalize(null)).toEqual({ headers: {}, urlPatterns: [] })
  })

  it('keeps only string header values and string patterns', () => {
    expect(normalize({
      headers: { a: 1, b: 'ok' },
      urlPatterns: ['/chat/completions', 7, null],
    })).toEqual({ headers: { b: 'ok' }, urlPatterns: ['/chat/completions'] })
  })
})

describe('headers wire envelope', () => {
  let harness: ReturnType<typeof stubFetch>

  beforeEach(() => {
    harness = stubFetch({ get: { ok: true, value: LOADED }, set: { ok: true, value: { ...LOADED, revision: 4 } } })
    vi.stubGlobal('fetch', harness.mock)
  })
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('loads with a get envelope on the channel path', async () => {
    const result = await loadSection()
    expect(harness.calls[0]).toMatchObject({ method: 'get', input: 'http://dsh.internal/llm-headers/get' })
    expect(harness.calls[0]!.payload).toEqual({})
    expect(result).toEqual({ ok: true, value: LOADED })
  })

  it('saves with the expected revision when one is held', async () => {
    const result = await saveSection({ headers: {}, urlPatterns: [] }, 3)
    const payload = harness.calls[0]!.payload as { section: unknown; expectedRevision: number }
    expect(payload.section).toEqual({ headers: {}, urlPatterns: [] })
    expect(payload.expectedRevision).toBe(3)
    expect(result).toEqual({ ok: true, value: { ...LOADED, revision: 4 } })
  })

  it('omits the expected revision when none is held', async () => {
    await saveSection({ headers: {}, urlPatterns: [] })
    const payload = harness.calls[0]!.payload as Record<string, unknown>
    expect('expectedRevision' in payload).toBe(false)
  })

  it('throws on an HTTP failure', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('nope', { status: 500 })))
    await expect(loadSection()).rejects.toThrow('HTTP 500')
  })

  it('throws on an rpcId mismatch', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
      type: 'server-response',
      rpcId: 'different',
      result: { ok: true, value: {} },
    }), { status: 200, headers: { 'content-type': 'application/json' } })))
    await expect(loadSection()).rejects.toThrow('rpcId mismatch')
  })
})

describe('LlmHeadersController', () => {
  let results: { get: unknown; set: unknown }
  let calls: Array<{ method: string; payload: unknown }>
  let controller: LlmHeadersController

  beforeEach(() => {
    results = { get: { ok: true, value: LOADED }, set: { ok: true, value: { ...LOADED, revision: 4 } } }
    const harness = stubFetch(results)
    calls = harness.calls
    vi.stubGlobal('fetch', harness.mock)
    controller = new LlmHeadersController()
  })
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  it('loads an available snapshot with the revision', async () => {
    await controller.load()
    const snapshot = controller.getSnapshot()
    expect(snapshot.available).toBe(true)
    expect(snapshot.value).toEqual(LOADED.value)
    expect(snapshot.revision).toBe(3)
    expect(snapshot.failed).toBe(false)
  })

  it('stays unavailable when the channel refuses', async () => {
    results.get = { ok: false, error: { code: 'not-found', message: 'x', details: {} } }
    await controller.load()
    expect(controller.getSnapshot()).toMatchObject({ available: false, value: undefined })
  })

  it('stays unavailable on a transport failure', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('network down') }))
    await controller.load()
    expect(controller.getSnapshot()).toMatchObject({ available: false, value: undefined })
  })

  it('keeps the last good value when a later refresh fails', async () => {
    await controller.load()
    vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('network down') }))
    await controller.load()
    expect(controller.getSnapshot()).toMatchObject({ available: true, value: LOADED.value })
  })

  it('keeps the last good value when a later read is refused', async () => {
    await controller.load()
    results.get = { ok: false, error: { code: 'not-found', message: 'x', details: {} } }
    await controller.load()
    expect(controller.getSnapshot()).toMatchObject({ available: true, value: LOADED.value })
  })

  it('delegates the snapshot verbs to the controller methods', async () => {
    await controller.load()
    const snapshot = controller.getSnapshot()
    expect(await snapshot.save({ headers: { 'user-agent': 'v9' }, urlPatterns: ['/x'] })).toBe(true)
    await snapshot.refresh()
    expect(await snapshot.reset()).toBe(true)
  })

  it('saves through the channel with the held revision', async () => {
    await controller.load()
    const accepted = await controller.save({ headers: { 'user-agent': 'v2' }, urlPatterns: ['/chat/completions'] })
    expect(accepted).toBe(true)
    const snapshot = controller.getSnapshot()
    expect(snapshot.saving).toBe(false)
    expect(snapshot.failed).toBe(false)
    expect(snapshot.value).toEqual({ headers: { 'user-agent': 'v2' }, urlPatterns: ['/chat/completions'] })
    expect(snapshot.revision).toBe(4)
    const payload = calls.find(call => call.method === 'set')!.payload as { expectedRevision: number }
    expect(payload.expectedRevision).toBe(3)
  })

  it('reports a conflict and refreshes against the moved section', async () => {
    await controller.load()
    results.set = { ok: false, error: { code: 'conflict', message: 'moved', details: {} } }
    results.get = {
      ok: true,
      value: { value: { headers: { 'user-agent': 'elsewhere' }, urlPatterns: ['/x'] }, revision: 9 },
    }
    const accepted = await controller.save({ headers: { 'user-agent': 'mine' }, urlPatterns: ['/chat/completions'] })
    expect(accepted).toBe(false)
    expect(controller.getSnapshot()).toMatchObject({ failed: true, conflict: true, value: LOADED.value })
    // The fire-and-forget refresh lands after the save settles; drain the
    // whole microtask chain (fetch resolution + json parsing + publish).
    await new Promise(resolve => setTimeout(resolve, 0))
    expect(controller.getSnapshot()).toMatchObject({
      value: { headers: { 'user-agent': 'elsewhere' }, urlPatterns: ['/x'] },
      revision: 9,
    })
  })

  it('marks a save failed on transport failure without a conflict', async () => {
    await controller.load()
    vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('network down') }))
    const accepted = await controller.save({ headers: {}, urlPatterns: [] })
    expect(accepted).toBe(false)
    expect(controller.getSnapshot()).toMatchObject({ failed: true, conflict: false })
  })

  it('marks a save failed without a conflict on a plain refusal', async () => {
    await controller.load()
    results.set = { ok: false, error: { code: 'settings-rejected', message: 'x', details: {} } }
    const accepted = await controller.save({ headers: {}, urlPatterns: [] })
    expect(accepted).toBe(false)
    expect(controller.getSnapshot()).toMatchObject({ failed: true, conflict: false })
  })

  it('keeps the held revision when the save response omits one', async () => {
    await controller.load()
    results.set = { ok: true, value: { value: { headers: {}, urlPatterns: [] } } }
    const accepted = await controller.save({ headers: {}, urlPatterns: ['/chat/completions'] })
    expect(accepted).toBe(true)
    expect(controller.getSnapshot().revision).toBe(3)
  })

  it('resets the user layer to an empty section and re-reads the resolved value', async () => {
    await controller.load()
    const accepted = await controller.reset()
    expect(accepted).toBe(true)
    const payload = calls.find(call => call.method === 'set')!.payload as { section: unknown; expectedRevision: number }
    expect(payload.section).toEqual({ headers: {}, urlPatterns: [] })
    expect(payload.expectedRevision).toBe(3)
    // After the reset the resolved value is re-fetched from the channel.
    expect(calls.filter(call => call.method === 'get')).toHaveLength(2)
    expect(controller.getSnapshot()).toMatchObject({ available: true, value: LOADED.value, failed: false })
  })

  it('surfaces a conflict on reset', async () => {
    await controller.load()
    results.set = { ok: false, error: { code: 'conflict', message: 'moved', details: {} } }
    const accepted = await controller.reset()
    expect(accepted).toBe(false)
    expect(controller.getSnapshot()).toMatchObject({ failed: true, conflict: true })
  })

  it('marks a reset failed without a conflict on a plain refusal', async () => {
    await controller.load()
    results.set = { ok: false, error: { code: 'settings-rejected', message: 'x', details: {} } }
    const accepted = await controller.reset()
    expect(accepted).toBe(false)
    expect(controller.getSnapshot()).toMatchObject({ failed: true, conflict: false })
  })

  it('marks a reset failed on transport failure', async () => {
    await controller.load()
    vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('network down') }))
    const accepted = await controller.reset()
    expect(accepted).toBe(false)
    expect(controller.getSnapshot()).toMatchObject({ saving: false, failed: true, conflict: false })
  })

  it('unsubscribes a listener and stops notifying it', async () => {
    await controller.load()
    const listener = vi.fn()
    const disposer = controller.subscribe(listener)
    disposer()
    await controller.save({ headers: {}, urlPatterns: [] })
    expect(listener).not.toHaveBeenCalled()
  })

  it('notifies subscribers on every snapshot change', async () => {
    const listener = vi.fn()
    controller.subscribe(listener)
    await controller.load()
    expect(listener).toHaveBeenCalled()
  })

  it('reports whether the boot retry budget is spent', async () => {
    expect(controller.attemptsExhausted()).toBe(false)
    for (const _ of Array.from({ length: 5 })) {
      vi.stubGlobal('fetch', vi.fn(async () => { throw new Error('network down') }))
      await controller.load()
    }
    expect(controller.attemptsExhausted()).toBe(true)
  })
})
