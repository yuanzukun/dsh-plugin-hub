/**
 * Shared fakes for host-side tests: a minimal cordis-like context (inject /
 * effect with service properties), a connection service capturing the RPC
 * channel, and a settings service approximating dsh-settings' register /
 * replace / describe surface with real conflict semantics. Deliberately small:
 * they model the seams the plugin reads, not the whole framework.
 */

import { Config, type Config as ConfigType } from '../src/index.ts'
import { NS } from '../src/host-rpc.ts'
import { SettingsConflictError } from '@deepseek-ai/dsh-settings'

export interface FakeContext {
  /** Services land on the context itself, mirroring cordis injection. */
  [key: string]: unknown
  fiber: { state: number }
  _disposers: Array<() => void>
  inject(names: readonly string[], callback: (sctx: FakeContext) => void): void
  effect(callback: () => () => void): void
}

/** A fake cordis context: services provided up front, `inject` fires synchronously. */
export function createFakeContext(services: Record<string, unknown>): FakeContext {
  const ctx = {
    fiber: { state: 0 },
    _disposers: [] as Array<() => void>,
    inject(names: readonly string[], callback: (sctx: FakeContext) => void) {
      if (names.every(name => services[name] !== undefined)) callback(ctx)
    },
    effect(callback: () => () => void) {
      ctx._disposers.push(callback())
    },
  }
  Object.assign(ctx, services)
  return ctx
}

/** A connection service whose RPC registration hands back the channel handler. */
export function createFakeConnection() {
  const state: {
    channel: string | undefined
    authority: unknown
    handler: ((endpoint: string, payload: unknown, signal?: AbortSignal) => Promise<unknown>) | undefined
  } = {
    channel: undefined,
    authority: undefined,
    handler: undefined,
  }
  return {
    connection: {
      rpc: {
        handle(
          channel: string,
          handler: (endpoint: string, payload: unknown, signal?: AbortSignal) => Promise<unknown>,
          options: { authority: 'trusted-host' | 'loopback' },
        ) {
          state.channel = channel
          state.handler = handler
          state.authority = options.authority
          return async () => {}
        },
      },
    },
    state,
  }
}

/**
 * A settings service close enough for this plugin: `register` hands the owner
 * scope, `replace` enforces the expected revision like the real service, and
 * `describe` reports the revision. `rejectNext` lets a test refuse one write.
 */
export function createFakeSettings(base: ConfigType | undefined) {
  let user: Record<string, unknown> = {}
  let revision = 0
  let resolved = resolve()
  const watchers = new Set<(next: unknown, prev: unknown) => void>()
  let rejectNext: Error | null = null

  function resolve(): ConfigType {
    // Intentional: unwrap the resolved config's own fields into a plain object
    // before merging the user layer.
    // oxlint-disable-next-line typescript/no-misused-spread
    return Config({ ...(base ?? {}), ...user } as unknown as ConfigType)
  }

  return {
    rejectNext(error: Error): void {
      rejectNext = error
    },
    register() {
      return {
        get: () => resolved,
        watch: (callback: (next: unknown, prev: unknown) => void) => {
          watchers.add(callback)
          return () => watchers.delete(callback)
        },
        update: async () => {},
        replace: async () => {},
      }
    },
    async replace(ns: unknown, section: object, expectedRevision?: number): Promise<void> {
      if (expectedRevision !== undefined && expectedRevision !== revision) {
        throw new SettingsConflictError(ns as never, expectedRevision, revision)
      }
      if (rejectNext !== null) {
        const error = rejectNext
        rejectNext = null
        throw error
      }
      user = { ...section }
      const previous = resolved
      resolved = resolve()
      revision += 1
      for (const callback of [...watchers]) callback(resolved, previous)
    },
    describe() {
      return [{ ns: NS, revision, value: resolved, schema: null, applies: 'live' }]
    },
  }
}

/** Settle the microtask queue a couple of turns. */
export async function flush(): Promise<void> {
  await Promise.resolve()
  await Promise.resolve()
}
