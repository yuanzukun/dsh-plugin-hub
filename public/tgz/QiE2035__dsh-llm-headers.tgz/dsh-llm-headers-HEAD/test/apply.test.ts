/**
 * Plugin-entry integration tests: `apply` wired against the fake services,
 * covering the closed loop the unit tests only see in pieces — fetch wrapper
 * installation, settings resolution, RPC set propagation to the wrapper, and
 * stack-safe restoration on dispose.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import type { Context } from '@deepseek-ai/cordis'
import { apply, type Config as ConfigType } from '../src/index.ts'
import { createFakeConnection, createFakeContext, createFakeSettings, flush } from './harness.ts'

const COMPOSED: ConfigType = { headers: { 'user-agent': 'composed/1' }, urlPatterns: ['/chat/completions'] }

describe('apply wiring', () => {
  let originalFetch: typeof fetch
  let stub: ReturnType<typeof vi.fn<typeof fetch>>

  beforeEach(() => {
    originalFetch = globalThis.fetch
    stub = vi.fn<typeof fetch>(async () => new Response('ok', { status: 200 }))
    globalThis.fetch = stub
  })
  afterEach(() => {
    globalThis.fetch = originalFetch
  })

  function headerOf(call: Parameters<typeof fetch>[1]): Headers {
    return new Headers(call?.headers)
  }

  /** Apply the plugin against the given services and settle the wiring. */
  async function applyWith(services: Record<string, unknown>) {
    const ctx = createFakeContext(services)
    apply(ctx as unknown as Context, COMPOSED)
    await flush()
    return ctx
  }

  it('installs the wrapper on the headless path and restores fetch on dispose', async () => {
    const ctx = await applyWith({})
    await globalThis.fetch('https://gateway.example/chat/completions', { headers: { authorization: 'Bearer x' } })
    expect(stub).toHaveBeenCalledTimes(1)
    expect(headerOf(stub.mock.calls[0]![1]).get('user-agent')).toBe('composed/1')

    for (const dispose of ctx._disposers) dispose()
    expect(globalThis.fetch).toBe(stub)
  })

  it('does not clobber a later wrapper when disposing out of turn', async () => {
    const ctx = await applyWith({})
    const later = vi.fn<typeof fetch>(async () => new Response('later', { status: 200 }))
    globalThis.fetch = later
    for (const dispose of ctx._disposers) dispose()
    // A plugin that wrapped fetch after us stays in charge.
    expect(globalThis.fetch).toBe(later)
  })

  it('propagates an RPC set to the fetch wrapper through the settings watcher', async () => {
    const settings = createFakeSettings(COMPOSED)
    const connection = createFakeConnection()
    await applyWith({ settings, connection: connection.connection })

    // The resolved scope (composition base) is live before any user write.
    await globalThis.fetch('https://gateway.example/chat/completions', { headers: { authorization: 'Bearer x' } })
    expect(headerOf(stub.mock.calls[0]![1]).get('user-agent')).toBe('composed/1')

    // The card's write crosses the channel: settings replaces the user layer,
    // the section watcher re-resolves, and the wrapper picks it up.
    const result = await connection.state.handler!('set', {
      section: { headers: { 'user-agent': 'v2' }, urlPatterns: ['/chat/completions'] },
      expectedRevision: 0,
    })
    expect(result).toMatchObject({ ok: true })
    await flush()

    await globalThis.fetch('https://gateway.example/chat/completions', { headers: {} })
    expect(headerOf(stub.mock.calls[1]![1]).get('user-agent')).toBe('v2')
  })

  it('keeps the composition config when settings never attach', async () => {
    await applyWith({})
    await globalThis.fetch('https://gateway.example/chat/completions', { headers: {} })
    expect(headerOf(stub.mock.calls[0]![1]).get('user-agent')).toBe('composed/1')
  })
})
