/**
 * Host RPC channel tests: endpoint routing, revision round-trips, and error
 * mapping, driven against the fake connection and settings services.
 */

import { describe, expect, it } from 'vitest'
import type { Context } from '@deepseek-ai/cordis'
import { installHostRpc, RPC_CHANNEL } from '../src/host-rpc.ts'
import type { Config as ConfigType } from '../src/index.ts'
import { createFakeConnection, createFakeContext, createFakeSettings, flush } from './harness.ts'

const ENTRY: ConfigType = { headers: { 'user-agent': 'entry/1' }, urlPatterns: ['/chat/completions'] }

/** Install the channel with a fixed reader and return the captured handler. */
async function channelWith(read: () => ConfigType, base: ConfigType) {
  const settings = createFakeSettings(base)
  const connection = createFakeConnection()
  const ctx = createFakeContext({ settings, connection: connection.connection })
  installHostRpc(ctx as unknown as Context, read)
  await flush()
  return { settings, connection, handler: connection.state.handler!, ctx }
}

describe('installHostRpc channel', () => {
  it('registers under the owned channel path with loopback authority', async () => {
    const { connection } = await channelWith(() => ({ headers: {}, urlPatterns: [] }), ENTRY)
    expect(connection.state.channel).toBe(RPC_CHANNEL)
    expect(connection.state.authority).toBe('loopback')
  })

  it('serves get with the resolved section and its revision', async () => {
    const { handler } = await channelWith(() => ({ headers: { 'user-agent': 'x' }, urlPatterns: ['/a'] }), ENTRY)
    const result = await handler('get', {})
    expect(result).toEqual({
      ok: true,
      value: { value: { headers: { 'user-agent': 'x' }, urlPatterns: ['/a'] }, revision: 0 },
    })
  })

  it('sets the section with the caller revision and reports the fresh revision', async () => {
    const { handler, settings } = await channelWith(() => {
      const doc = settings.describe()[0]!
      return doc.value
    }, ENTRY)
    const result = await handler('set', {
      section: { headers: { 'user-agent': 'v2' }, urlPatterns: ['/chat/completions'] },
      expectedRevision: 0,
    })
    expect(result).toMatchObject({ ok: true })
    const value = (result as { ok: true; value: { revision: number } }).value
    expect(value.revision).toBe(1)
  })

  it('refuses a stale write with a conflict error', async () => {
    const { handler } = await channelWith(() => ({ headers: {}, urlPatterns: [] }), ENTRY)
    // First write without a revision moves the namespace to revision 1...
    await handler('set', { section: { headers: { 'user-agent': 'v1' }, urlPatterns: ['/c'] } })
    // ...so a write still expecting revision 0 is refused, not silently merged.
    const result = await handler('set', {
      section: { headers: { 'user-agent': 'v2' }, urlPatterns: ['/c'] },
      expectedRevision: 0,
    })
    expect(result).toMatchObject({ ok: false, error: { code: 'conflict' } })
  })

  it('rejects a non-object section as bad-request', async () => {
    const { handler } = await channelWith(() => ({ headers: {}, urlPatterns: [] }), ENTRY)
    await expect(handler('set', { section: 'nope' })).resolves.toMatchObject({
      ok: false,
      error: { code: 'bad-request' },
    })
    await expect(handler('set', { section: [] })).resolves.toMatchObject({
      ok: false,
      error: { code: 'bad-request' },
    })
    await expect(handler('set', null)).resolves.toMatchObject({
      ok: false,
      error: { code: 'bad-request' },
    })
  })

  it('reports no revision when the namespace is absent from describe', async () => {
    const connection = createFakeConnection()
    const ctx = createFakeContext({
      settings: {
        describe: () => [] as Array<{ ns: string; revision: number }>,
        replace: async () => {},
      },
      connection: connection.connection,
    })
    installHostRpc(ctx as unknown as Context, () => ({ headers: {}, urlPatterns: [] }))
    await flush()
    const result = await connection.state.handler!('get', {})
    expect(result).toEqual({ ok: true, value: { value: { headers: {}, urlPatterns: [] }, revision: undefined } })
  })

  it('maps a settings rejection to settings-rejected', async () => {
    const { handler, settings } = await channelWith(() => ({ headers: {}, urlPatterns: [] }), ENTRY)
    settings.rejectNext(new TypeError('schema rejects this section'))
    const result = await handler('set', { section: { headers: { a: 'b' }, urlPatterns: ['/c'] } })
    expect(result).toMatchObject({ ok: false, error: { code: 'settings-rejected' } })
  })

  it('stringifies a non-Error settings rejection', async () => {
    const { handler, settings } = await channelWith(() => ({ headers: {}, urlPatterns: [] }), ENTRY)
    settings.rejectNext('schema rejects this section' as unknown as Error)
    const result = await handler('set', { section: { headers: { a: 'b' }, urlPatterns: ['/c'] } })
    expect(result).toMatchObject({ ok: false, error: { code: 'settings-rejected', message: 'schema rejects this section' } })
  })

  it('answers unknown endpoints with not-found', async () => {
    const { handler } = await channelWith(() => ({ headers: {}, urlPatterns: [] }), ENTRY)
    const result = await handler('delete', {})
    expect(result).toMatchObject({ ok: false, error: { code: 'not-found' } })
  })

  it('registers nothing when the connection service is absent', async () => {
    const settings = createFakeSettings(ENTRY)
    const ctx = createFakeContext({ settings })
    // Headless profiles have no connection service; the channel must no-op
    // rather than throw.
    expect(() => { installHostRpc(ctx as unknown as Context, () => ({ headers: {}, urlPatterns: [] })) }).not.toThrow()
    await flush()
  })

  it('disposes the channel handler with the fiber', async () => {
    const { connection, ctx } = await channelWith(() => ({ headers: {}, urlPatterns: [] }), ENTRY)
    for (const dispose of ctx._disposers) dispose()
    expect(connection.state.channel).toBe(RPC_CHANNEL)
  })
})
