// @vitest-environment jsdom

/**
 * Client-entry tests: `apply` against fake locale/slots services, covering
 * the boot-read retry loop (stop on the first resolved read or when the
 * budget is spent) and the slot registration that hands the Host the
 * controller-backed hooks.
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { apply, type ClientCtx } from '../src/client/index.ts'

/** A fake client context: locale registry, slots injector, and the effect hook. */
function clientContext() {
  const registered: Array<{ ns: string; locale: string }> = []
  const registrations: Array<{ options: unknown; component: unknown }> = []
  const disposers: Array<() => void> = []
  const ctx: ClientCtx = {
    locale: {
      register(ns: string, locale: string) {
        registered.push({ ns, locale })
        return () => {}
      },
    },
    slots: {
      inject(_key: string, callback: () => () => void) {
        return callback()
      },
      register(options: object, component: unknown) {
        registrations.push({ options, component })
        return () => {}
      },
    },
    effect(callback: () => () => void) {
      disposers.push(callback())
    },
  }
  return { ctx, registered, registrations, disposers }
}

/** A channel-shaped response echoing the request's rpcId for a successful boot read. */
function okResponse(init?: RequestInit) {
  const body = JSON.parse(init?.body as string) as { rpcId?: string }
  return new Response(JSON.stringify({
    type: 'server-response',
    rpcId: body.rpcId ?? 'missing',
    result: {
      ok: true,
      value: { value: { headers: {}, urlPatterns: ['/chat/completions'] }, revision: 1 },
    },
  }), { status: 200, headers: { 'content-type': 'application/json' } })
}

let fetchMock: ReturnType<typeof vi.fn<typeof fetch>>

beforeEach(() => {
  fetchMock = vi.fn<typeof fetch>(async (_input, init) => okResponse(init))
  vi.stubGlobal('fetch', fetchMock)
})

afterEach(() => {
  vi.useRealTimers()
  vi.unstubAllGlobals()
})

describe('client apply', () => {
  it('registers both locale dictionaries and the fiber disposer', () => {
    const { ctx, registered, disposers } = clientContext()
    apply(ctx)
    expect(registered).toEqual([
      { ns: 'llm-headers-card', locale: 'zh' },
      { ns: 'llm-headers-card', locale: 'en' },
    ])
    expect(disposers).toHaveLength(1)
    expect(() => { for (const dispose of disposers) dispose() }).not.toThrow()
  })

  it('registers the card slot with controller-backed hooks', async () => {
    const { ctx, registrations } = clientContext()
    apply(ctx)
    await microtasks()
    expect(registrations).toHaveLength(1)
    const { options, component } = registrations[0]!
    const opts = options as {
      name: string
      id: string
      locale: string
      inject: () => {
        hooks: {
          llmHeadersCard: {
            getSnapshot: () => { available: boolean }
            subscribe: (listener: () => void) => () => void
          }
        }
      }
    }
    expect(component).toBeTruthy()
    expect(opts.name).toBe('settings.plugin.item')
    expect(opts.id).toBe('llm-headers')
    expect(opts.locale).toBe('llm-headers-card')
    const hooks = opts.inject().hooks.llmHeadersCard
    expect(hooks.getSnapshot().available).toBe(true)
    const listener = vi.fn()
    const unsubscribe = hooks.subscribe(listener)
    unsubscribe()
    expect(listener).not.toHaveBeenCalled()
  })

  it('retries the boot read until the channel answers', async () => {
    vi.useFakeTimers()
    let failures = 1
    fetchMock = vi.fn<typeof fetch>(async (_input, init) => {
      if (failures > 0) {
        failures -= 1
        throw new Error('channel not served yet')
      }
      return okResponse(init)
    })
    vi.stubGlobal('fetch', fetchMock)
    const { ctx, registrations } = clientContext()
    apply(ctx)
    await microtasks()
    // First read failed: still unavailable, the retry loop owns the next tick.
    const hooks = (registrations[0]!.options as {
      inject: () => { hooks: { llmHeadersCard: { getSnapshot: () => { available: boolean } } } }
    }).inject().hooks.llmHeadersCard
    expect(hooks.getSnapshot().available).toBe(false)
    vi.advanceTimersByTime(1000)
    await microtasks()
    expect(hooks.getSnapshot().available).toBe(true)
    const callsAfterAvailable = fetchMock.mock.calls.length
    // The retry loop stopped: no further reads while the interval would tick.
    vi.advanceTimersByTime(3000)
    await microtasks()
    expect(fetchMock.mock.calls.length).toBe(callsAfterAvailable)
  })

  it('stops retrying once the boot budget is spent', async () => {
    vi.useFakeTimers()
    fetchMock = vi.fn<typeof fetch>(async () => { throw new Error('channel never served') })
    vi.stubGlobal('fetch', fetchMock)
    apply(clientContext().ctx)
    await microtasks()
    for (let attempt = 0; attempt < 5; attempt += 1) {
      vi.advanceTimersByTime(1000)
      await microtasks()
    }
    const callsBeforeExhaustion = fetchMock.mock.calls.length
    expect(callsBeforeExhaustion).toBeGreaterThanOrEqual(5)
    vi.advanceTimersByTime(4000)
    await microtasks()
    expect(fetchMock.mock.calls.length).toBe(callsBeforeExhaustion)
  })
})

/** Settle the promise queue deep enough for a full fetch resolution chain. */
async function microtasks(): Promise<void> {
  for (let turn = 0; turn < 10; turn += 1) await Promise.resolve()
}
