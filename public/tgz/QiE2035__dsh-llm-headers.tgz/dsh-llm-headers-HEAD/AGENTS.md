# AGENTS.md

`dsh-llm-headers` 是 DeepSeek Harness 的 out-of-tree 插件 bundle：包装 `globalThis.fetch`，对 URL 匹配 `urlPatterns` 的 LLM provider 请求注入配置的 `headers`（典型用途：网关要求的 user-agent 白标替换）。配置经 `llm-headers` 用户设置命名空间（cordis.yml / settings.yaml / Web UI 卡片）写入并 live 生效。原理、安装与配置说明见 [README.md](README.md)，不在此重复。

插件最终运行在 deepseek-harness 上（profile 的 bundle 层）；宿主仓库的 [AGENTS.md](https://github.com/deepseek-ai/deepseek-harness/blob/master/AGENTS.md) 中插件式架构、Registrations are effects、Model-visible ⟺ logged 等规则同样适用。本文件只记录本仓库与宿主不同的部分。

## 命令

```sh
pnpm install      # 依赖全部来自 npm registry，一次装齐（peer 包由宿主安装提供）
pnpm typecheck    # tsc --noEmit（strict + noUncheckedIndexedAccess）
pnpm test         # vitest node 环境，fetch 代理行为矩阵，无需 API key
pnpm test:coverage  # CI 覆盖率门禁：v8 对 src 逐文件 100%（阈值、豁免语义与宿主一致；组件走 jsdom lane）
pnpm lint         # oxlint + @stylistic/eslint-plugin + sonarjs，规则集与 deepseek-harness 一致（无分号、单引号、2 空格、max-len 140）
pnpm lint:fix     # 全仓自动修复；pre-commit 钩子用 .oxlintrc.staged.json 只修暂存文件
pnpm duplication  # jscpd 重复检测（.jscpd.json，minTokens 60 / mild）
pnpm hygiene      # build 后 knip + publint 发布前检查；publint 只以 error 失败（./client 的 CJS/ESM 形态 warning 与宿主同类包一致，接受）
pnpm build        # scripts/clean-lib.mjs 清 lib/，tsdown 产出 node ESM，再 tsdown -c tsdown.client.config.ts 产出 browser 闭包工厂
```

## 布局

```
src/index.ts          插件入口：Config schema、apply()、settings 段落与 RPC 通道装配；latest/source/configure 是 fetch wrapper 与 RPC 共读的唯一配置源
src/fetch-proxy.ts    唯一行为核心：installFetchProxy 纯函数（无副作用、可单测）；模式与 header 条目在 update() 时派生缓存，空模式会被过滤
src/host-rpc.ts       /llm-headers RPC 通道（get/set + revision 乐观并发），绕过 settings describe allowlist；NS 命名空间常量唯一来源
src/client/           Web 端：index.ts 入口、controller.ts 快照状态机、headers-wire.ts 信封调用、draft.ts 草稿纯函数、LlmHeadersCard.tsx、locales.ts
test/                 vitest 行为矩阵 + 集成：fetch-proxy / client-logic / host-rpc / apply（harness.ts 提供假服务）；修改任何行为必须同步测试
e2e/                  echo-server.mjs、overlay.yml、smoke.mjs 自动化冒烟（需真实 profile 与 DEEPSEEK_API_KEY，流程见 README）
```

## 约定

- 相对导入带 `.ts` 扩展名（ESM + `allowImportingTsExtensions`），与宿主一致；目标 es2024。
- `@deepseek-ai/cordis`、`@deepseek-ai/dsh-settings`、`@deepseek-ai/schemastery`、react 均为 peerDependencies，由宿主提供；新增依赖需同时加入 devDependencies 供本地开发。
- 每个模块顶部 JSDoc 说明非显然契约（`@module`、`@param`、`@returns`），沿用现有完整契约叙述风格。
- 浏览器端不得 import 任何 client 包值：卡片与 Host 通信必须走插件自有 RPC 通道（plain POST 信封），这是跨宿主版本兼容的硬约束；新增通道端点需同步 `headers-wire.ts` 调用方。
- 空 `catch` 必须命名其吞掉的原因（参见 `controller.ts` 的传输失败分支注释）。
- 修改 `Config` schema 时联动检查四处：`Schema` 默认值、RPC `set` 校验（`isSection`）、客户端 `normalize`、卡片 locales；settings.yaml 热重载与 UI 保存两条路径都要验证。

## 陷阱

- `lib/` 是构建产物（`scripts/clean-lib.mjs` 管理），不直接编辑；发布/冒烟形态加载 `lib/index.js`，源码改动后先 `pnpm build`。
- `pnpm-lock.yaml` 纳入版本控制（与宿主一致，锁版本供应链）；`pnpm-workspace.yaml` 只声明 `allowBuilds`（esbuild/lefthook），新增带 install 脚本的依赖必须显式放行。
- fetch 包装是栈式的：卸载时只在 `globalThis.fetch` 仍等于自己的 `proxy` 时才恢复 `original`，无条件恢复会切断后续包装者的配置。
- `headers` 为空时保持惰性：请求 init 对象原样透传（测试 `toBe(init)` 断言同一引用）；不要为此路径引入任何拷贝。
- e2e 冒烟临时改写 `$DSH_HOME/settings.yaml` 中当前 provider 的 `baseURL` 指向 echo 服务器，验证后必须还原；overlay 中 Windows 绝对路径必须写成 `file:///E:/...`（裸 `E:/` 会被解析为不支持协议）。
- 客户端通道在 Host 启动早期可能尚未就绪：卡片加载走 `controller.load()` 重试循环（5 次），新增读取逻辑应复用该状态机而非自行重试。
- 启动宿主时优先用 `pnpx @deepseek-ai/dsh`（发布包，构建好的产物；headless 任务、`web` 别名均适用），不要 `pnpm dsh` 从源码启动——后者要编译/加载整个 monorepo，明显更慢。
