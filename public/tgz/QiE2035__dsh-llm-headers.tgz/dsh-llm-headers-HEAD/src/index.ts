/**
 * `llm-headers` plugin: inject deployment-configured HTTP headers into LLM
 * provider requests, selected by URL patterns.
 *
 * The plugin wraps `globalThis.fetch` once at load; every request whose URL
 * matches `urlPatterns` gets `headers` applied. Because the configuration
 * rides the user-settings surface (`installSettingsSection`), the Web UI
 * settings page renders a `llm-headers` section for the same fields and
 * changes apply live on the next request. An empty `headers` map leaves every
 * request untouched, so the bundle is inert until configured.
 * @module dsh-llm-headers
 */

import type { Context } from '@deepseek-ai/cordis'
import Schema from '@deepseek-ai/schemastery'
import { installSettingsSection } from '@deepseek-ai/dsh-settings'
import { installFetchProxy } from './fetch-proxy.ts'
import { installHostRpc, NS } from './host-rpc.ts'

/**
 * The plugin's configurable surface, exposed both as cordis.yml entry config
 * and as the `llm-headers` user-settings section.
 */
export interface Config {
  /**
   * Header names to values injected into matching requests. Every entry is
   * `set()` on the request — overwriting the adapter's own value for that
   * name, including the mandatory attribution `user-agent` (the white-label
   * case). An empty map leaves every request untouched.
   */
  headers: Record<string, string>
  /**
   * URL substrings selecting which requests receive the headers; a request
   * URL containing any substring is rewritten. The default matches the
   * OpenAI-compatible chat-completions endpoints all providers use.
   */
  urlPatterns: string[]
}

export const Config: Schema<Config> = Schema.object({
  headers: Schema.dict(Schema.string()).default({}),
  urlPatterns: Schema.array(Schema.string()).default(['/chat/completions']),
})

export function apply(ctx: Context, config: Config) {
  const handle = installFetchProxy(globalThis.fetch, config)
  globalThis.fetch = handle.proxy
  ctx.effect(() => () => {
    // Restore only our own wrapper: a later plugin may have wrapped fetch
    // again, and replacing its proxy would strand its configuration.
    if (globalThis.fetch === handle.proxy) globalThis.fetch = handle.original
  })
  // The single source the fetch wrapper and the host RPC channel both read:
  // the composition entry until a settings provider attaches, then the
  // resolved settings scope (schema defaults + base + user layer). `latest`
  // holds whatever is authoritative now; `configure` applies it to the proxy.
  let latest: Config = config
  /* v8 ignore next -- the headless source is replaced by setSource before any settings-attached read calls it. */
  let source: () => Config = () => config
  const configure = (): void => {
    handle.update(latest)
  }
  // Applies the composition config now — the headless path, where no settings
  // provider ever mounts. When one attaches, installSettingsSection's initial
  // `onChange` re-runs this with the same value first; `update` skips the
  // identical reference, so the duplicate call is a no-op.
  configure()
  // Optional-settings wiring: while a settings provider is mounted, register
  // this namespace (composition entry as `base`) and live-update the wrapper.
  installSettingsSection(ctx, NS, Config, config, {
    setSource: (next) => {
      source = next
      latest = next()
      configure()
    },
    onChange: () => {
      latest = source()
      configure()
    },
  })
  // Own RPC channel so the Web UI card can read and write this namespace
  // without the settings RPC allowlist (`settings.describe` only serves
  // namespaces apiproxy explicitly exposes; this channel is ours).
  installHostRpc(ctx, () => latest)
}
