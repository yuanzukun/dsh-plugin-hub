/**
 * The plugin's own Host-side RPC channel.
 *
 * The framework's settings RPC surface (`settings.describe`) only serves
 * namespaces on an explicit allowlist decided in `dsh-host-apiproxy`
 * (`exposedNamespaces()`), and that allowlist is not extensible from a
 * plugin. Generic Connection RPC channels are the opposite: any plugin can
 * register a channel under its own absolute path with
 * `ctx.connection.rpc.handle()`, and browser code can call it with a plain
 * POST. The card therefore reads and writes this namespace through this
 * channel instead of the settings wire — the Host half persists with the
 * settings provider directly, which has no allowlist, and the settings
 * section's own watcher picks the change up for the fetch wrapper.
 *
 * The channel only exists while the `connection` service is mounted (web and
 * automation profiles); headless profiles have no browser to serve, so their
 * configuration keeps working through cordis.yml and the settings document.
 * @module dsh-llm-headers/host-rpc
 */

import type { Context } from '@deepseek-ai/cordis'
import { SettingsConflictError, settingsNamespace } from '@deepseek-ai/dsh-settings'
import type { Config } from './index.ts'

/** Wire-shaped RPC error the Connection handler must surface. */
interface RpcError {
  code: string
  message: string
  details: Record<string, unknown>
}

/** Wire-shaped RPC result: success carries `value`, failure carries `error`. */
type RpcResult<T> = { ok: true; value: T } | { ok: false; error: RpcError }

/**
 * One connection-served channel: `handle` registers an absolute path.
 * Minimal structural mirror of the Host connection service's typed surface;
 * kept local so this plugin depends on no client package value or type.
 */
interface ConnectionRpc {
  handle(
    channel: string,
    handler: (
      endpoint: string,
      payload: unknown,
      signal: AbortSignal,
    ) => Promise<RpcResult<unknown>>,
    options: { authority: 'trusted-host' | 'loopback' },
  ): () => Promise<void>
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    /** Host connection transport; present in web and automation profiles. */
    connection?: { rpc: ConnectionRpc }
  }
}

/** The channel path this plugin owns. */
export const RPC_CHANNEL = '/llm-headers'
/** The namespace the channel reads and writes; single source for the Host side. */
export const NS = settingsNamespace('llm-headers')

/**
 * Read the namespace's current raw-section revision from the settings service,
 * so the browser can send it back as `expectedRevision` on the next write. The
 * descriptor also carries the resolved value, but `read()` already has that;
 * only the monotonic revision is needed here.
 */
function revisionOf(settings: {
  describe(options?: { redactSecrets?: boolean }): Array<{ ns: string; revision: number }>
}): number | undefined {
  return settings.describe({ redactSecrets: true }).find(descriptor => descriptor.ns === NS)?.revision
}

/** A `set` payload narrowed from the wire: the section plus an optional expected revision. */
interface SetPayload {
  section?: unknown
  expectedRevision?: unknown
}

/**
 * Register the plugin's own RPC channel, if the `connection` service is
 * mounted. The channel serves `get` (read the resolved section and its
 * revision) and `set` (wholesale-replace the user layer, with the caller's
 * last-read revision as an optimistic-concurrency guard) against the settings
 * provider, so the browser card edits the same document the fetch wrapper
 * watches.
 * @param ctx - the plugin's apply context.
 * @param read - current resolved section (schema defaults + base + user).
 * @returns nothing; the channel lives and dies with the caller fiber.
 */
export function installHostRpc(ctx: Context, read: () => Config): void {
  ctx.inject(['connection', 'settings'], (sctx) => {
    const connection = sctx.connection
    /* v8 ignore next -- all-or-nothing inject keeps missing services from reaching this guard; it stays for partial hosts. */
    if (connection === undefined) return
    const dispose = connection.rpc.handle(RPC_CHANNEL, async (endpoint, payload) => {
      if (endpoint === 'get') {
        return ok({ value: read(), revision: revisionOf(sctx.settings) })
      }
      if (endpoint === 'set') {
        const { section, expectedRevision } = (payload as SetPayload | null) ?? {}
        if (!isSection(section)) {
          return err('bad-request', 'set payload must be a section object', {})
        }
        try {
          await sctx.settings.replace(NS, section, typeof expectedRevision === 'number' ? expectedRevision : undefined)
          return ok({ value: read(), revision: revisionOf(sctx.settings) })
        } catch (error: unknown) {
          if (error instanceof SettingsConflictError) {
            return err('conflict', error.message, { expected: error.expected, actual: error.actual })
          }
          return err('settings-rejected', error instanceof Error ? error.message : String(error), {})
        }
      }
      return err('not-found', `unknown endpoint ${JSON.stringify(endpoint)}`, { endpoint })
    }, { authority: 'loopback' })
    sctx.effect(() => () => { void dispose() })
  })
}

/** Narrow an arbitrary JSON value to a plain section object. */
function isSection(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function ok<T>(value: T): RpcResult<T> {
  return { ok: true, value }
}

function err<T>(code: string, message: string, details: Record<string, unknown>): RpcResult<T> {
  return { ok: false, error: { code, message, details } }
}
