/**
 * Browser caller for the plugin's own `/llm-headers` RPC channel.
 *
 * The Host half registers the channel with Connection's generic RPC registry
 * (`ctx.connection.rpc.handle`), which serves any browser POST carrying the
 * standard client-request envelope. That envelope — `{ type, rpcId, method,
 * payload }` in, `{ type, rpcId, result }` out — is the same shape the web
 * connection client uses for its own channels, reimplemented here so this
 * plugin's bundle imports no client package value. The channel bypasses the
 * settings RPC allowlist, which is what lets an out-of-tree plugin's
 * namespace reach the browser at all.
 * @module dsh-llm-headers/client/headers-wire
 */

/** Result of one channel call: value for a success, structured error for a failure. */
export type WireResult<T> =
  | { ok: true; value: T }
  | { ok: false; error: { code: string; message: string; details: Record<string, unknown> } }

/** The section this card reads and writes. */
export interface HeadersSection {
  headers: Record<string, string>
  urlPatterns: string[]
}

/**
 * One `get`/`set` success value: the resolved section plus the raw-section
 * revision the Host read it at. `revision` may be absent from an older Host
 * that predates optimistic concurrency — the caller simply stops guarding.
 */
export interface HeadersRead {
  value: HeadersSection
  revision?: number
}

/** Response envelope for one unary RPC call. */
interface ServerResponse {
  type: 'server-response'
  rpcId: string
  result: WireResult<unknown>
}

/**
 * Call one endpoint on the plugin's RPC channel.
 * @param endpoint - channel-relative endpoint (`get` or `set`).
 * @param payload - channel-owned request payload.
 * @returns the channel's result, or throws on transport failure.
 */
async function callHeadersRpc(endpoint: string, payload: unknown): Promise<WireResult<unknown>> {
  const origin = browserOrigin()
  const base = origin !== undefined && origin !== 'null' ? origin : 'http://dsh.internal'
  const rpcId = crypto.randomUUID()
  const response = await globalThis.fetch(new URL(`/llm-headers/${endpoint}`, base), {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify({ type: 'client-request', rpcId, method: endpoint, payload }),
  })
  if (!response.ok) {
    throw new Error(`llm-headers RPC ${endpoint}: HTTP ${response.status}`)
  }
  const envelope = await response.json() as ServerResponse
  if (envelope.rpcId !== rpcId) {
    throw new Error(`llm-headers RPC ${endpoint}: rpcId mismatch`)
  }
  return envelope.result
}

/** The enclosing page origin; undefined outside a browser (node test runners). */
function browserOrigin(): string | undefined {
  return (globalThis as { location?: { origin: string } }).location?.origin
}

/** Read the resolved section and its revision from the Host. */
export async function loadSection(): Promise<WireResult<HeadersRead>> {
  return callHeadersRpc('get', {}) as Promise<WireResult<HeadersRead>>
}

/**
 * Wholesale-replace the user section on the Host, optionally guarded by the
 * revision the caller last read; a section that moved past it is refused as a
 * `conflict` error instead of being silently overwritten.
 */
export async function saveSection(section: HeadersSection, expectedRevision?: number): Promise<WireResult<HeadersRead>> {
  return callHeadersRpc('set', {
    section,
    ...(expectedRevision === undefined ? {} : { expectedRevision }),
  }) as Promise<WireResult<HeadersRead>>
}
