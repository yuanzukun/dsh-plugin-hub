/**
 * The plugin's browser half: registers the llm-headers card into the settings
 * "Plugin configuration" section (`settings.plugin.item` slot) and keeps the
 * Host document writes flowing through the plugin's own RPC channel.
 *
 * No client-package value import: the card reaches the Host through the
 * plugin's `/llm-headers` channel (plain POST envelope), so the browser
 * bundle stays compatible across Host releases that evolve their client
 * packages — and independent of the settings RPC allowlist, which never
 * lists an out-of-tree plugin's namespace.
 * @module dsh-llm-headers/client
 */

import { LlmHeadersCard } from './LlmHeadersCard.tsx'
import { LlmHeadersController } from './controller.ts'
import { en, zh } from './locales.ts'

/** The card's locale dictionary namespace. */
const CARD_LOCALE_NS = 'llm-headers-card'

/** Services this plugin's fiber consumes; declared for the client runner's injection. */
export const inject = ['slots', 'locale']

/** Minimal context surface this plugin needs, matching the Host's merged services. */
export interface ClientCtx {
  locale: {
    register(ns: string, locale: string, dict: object): () => void
  }
  slots: {
    inject(key: string, callback: () => () => void | Iterable<() => void>): () => void
    register(options: {
      name: string
      id?: string
      order?: number
      locale?: string
      inject?: () => unknown
    }, component?: unknown): () => void
  }
  effect(callback: () => () => void): void
}

export function apply(ctx: ClientCtx) {
  const controller = new LlmHeadersController()
  void controller.load()
  // The namespace registers on the Host while the browser boots; retry a few
  // times so the card never lands on a transiently-empty describe.
  const retry = window.setInterval(() => {
    if (controller.getSnapshot().available || controller.attemptsExhausted()) {
      window.clearInterval(retry)
      return
    }
    void controller.load()
  }, 1000)

  ctx.locale.register(CARD_LOCALE_NS, 'zh', zh)
  ctx.locale.register(CARD_LOCALE_NS, 'en', en)

  ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
    name: 'settings.plugin.item',
    id: 'llm-headers',
    order: 20,
    locale: CARD_LOCALE_NS,
    inject: () => ({
      hooks: {
        llmHeadersCard: {
          getSnapshot: () => controller.getSnapshot(),
          subscribe: (listener: () => void) => controller.subscribe(listener),
        },
      },
    }),
  }, LlmHeadersCard))

  ctx.effect(() => () => {
    // Unload the boot retry loop with the fiber; a reload must not leave the
    // old controller polling a channel whose Host-side registration is gone.
    window.clearInterval(retry)
  })
}
