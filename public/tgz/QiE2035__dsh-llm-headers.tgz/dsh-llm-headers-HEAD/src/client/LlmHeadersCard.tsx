/**
 * The llm-headers plugin card: a self-drawn form over the `llm-headers`
 * settings namespace. The section owning the `settings.plugin.item` slot only
 * stacks cards, so the card owns its chrome and its interactions.
 */

import { useEffect, useRef, useState, type CSSProperties, type InputHTMLAttributes, type ReactNode } from 'react'
import type { CardSnapshot, ServerConfig } from './controller.ts'
import { buildSection, draftOf, type Draft } from './draft.ts'
import type { LlmHeadersLocale } from './locales.ts'

export interface LlmHeadersCardProps {
  /** The card's locale copy: a translate function over the card's dictionary. */
  t: (key: keyof LlmHeadersLocale) => string
  /** The controller's snapshot hook, injected by the slot renderer under the hooks key. */
  useLlmHeadersCard: (selector: (state: CardSnapshot) => unknown) => unknown
}

/** Hover tracker: lets inline styles reproduce a Host `:hover` rule. */
function useHovered(): readonly [boolean, () => void, () => void] {
  const [hovered, setHovered] = useState(false)
  return [hovered, () => { setHovered(true) }, () => { setHovered(false) }]
}

/**
 * A text input whose focus border comes from element state — the Host's
 * field stylesheet expresses it with `:focus-visible`, which inline styles
 * cannot reach.
 */
function FocusedInput({ onFocus, onBlur, ...rest }: InputHTMLAttributes<HTMLInputElement>) {
  const [focused, setFocused] = useState(false)
  return (
    <input
      {...rest}
      style={{
        ...inputStyle,
        ...(focused ? inputFocusStyle : {}),
        ...(rest.disabled ? inputDisabledStyle : {}),
      }}
      onFocus={(event) => { setFocused(true); onFocus?.(event) }}
      onBlur={(event) => { setFocused(false); onBlur?.(event) }}
    />
  )
}

/** A host-styled text link; its hover color comes from element state. */
function LinkButton({ children, disabled, onClick }: { children: ReactNode; disabled?: boolean; onClick: () => void }) {
  const [hovered, onMouseEnter, onMouseLeave] = useHovered()
  return (
    <button
      type="button"
      style={{
        ...linkButtonStyle,
        ...(hovered && !disabled ? { color: 'var(--dsw-alias-label-primary)' } : {}),
        ...(disabled ? { cursor: 'default' } : {}),
      }}
      disabled={disabled}
      onMouseEnter={onMouseEnter}
      onMouseLeave={onMouseLeave}
      onClick={onClick}
    >
      {children}
    </button>
  )
}

/** Render the plugin card. */
export function LlmHeadersCard({ t, useLlmHeadersCard }: LlmHeadersCardProps) {
  const snapshot = useLlmHeadersCard(state => state) as CardSnapshot
  const [open, setOpen] = useState(false)
  const [hovered, setHovered] = useState(false)
  const [discardHovered, setDiscardHovered] = useState(false)
  const [draft, setDraft] = useState<Draft>(() => draftOf(snapshot.value))
  const [dirty, setDirty] = useState(false)
  const lastValue = useRef(snapshot.value)

  // Adopt a server value that arrived after the initial seed and clear the
  // draft only when it did not change under the user, so an external edit
  // surfaces while an in-progress draft stays put.
  useEffect(() => {
    if (snapshot.value !== lastValue.current && !dirty) {
      lastValue.current = snapshot.value
      setDraft(draftOf(snapshot.value))
    }
  }, [snapshot.value, dirty])

  // A reopened card re-reads the server so external edits (settings.yaml hot
  // reload, another client) surface instead of the card serving a stale value
  // that a later save would silently overwrite. `refresh` is controller-bound
  // and stable across snapshot replacements, so this fires on open changes only.
  useEffect(() => {
    if (open) void snapshot.refresh()
  }, [open, snapshot.refresh])

  if (!snapshot.available) {
    return (
      <li style={cardChrome(false, false)}>
        <div style={{ ...headTextStyle, padding: '14px 16px' }}>
          <strong style={nameStyle}>{t('title')}</strong>
          <p style={descriptionStyle}>{t('unavailable')}</p>
        </div>
      </li>
    )
  }

  // The channel owns no writable concept: a save is accepted unless the
  // Host's settings provider rejects it, which the response reports.
  const disabled = snapshot.saving

  const patchHeader = (index: number, field: 'name' | 'value', text: string) => {
    setDraft((previous) => {
      const headers = previous.headers.map((row, at) => at === index ? { ...row, [field]: text } : row)
      return { ...previous, headers }
    })
    setDirty(true)
  }

  const removeHeader = (index: number) => {
    setDraft(previous => ({ ...previous, headers: previous.headers.filter((_, at) => at !== index) }))
    setDirty(true)
  }

  const addHeader = () => {
    setDraft(previous => ({ ...previous, headers: [...previous.headers, { name: '', value: '' }] }))
    setDirty(true)
  }

  const patchPattern = (index: number, text: string) => {
    setDraft(previous => ({ ...previous, urlPatterns: previous.urlPatterns.map((value, at) => at === index ? text : value) }))
    setDirty(true)
  }

  const removePattern = (index: number) => {
    setDraft(previous => ({ ...previous, urlPatterns: previous.urlPatterns.filter((_, at) => at !== index) }))
    setDirty(true)
  }

  const addPattern = () => {
    setDraft(previous => ({ ...previous, urlPatterns: [...previous.urlPatterns, ''] }))
    setDirty(true)
  }

  const save = async () => {
    const next: ServerConfig = buildSection(draft)
    const accepted = await snapshot.save(next)
    if (accepted) {
      lastValue.current = next
      setDraft(draftOf(next))
      setDirty(false)
    }
  }

  const reset = async () => {
    const accepted = await snapshot.reset()
    if (accepted) setDirty(false)
  }

  const discard = () => {
    setDraft(draftOf(lastValue.current))
    setDirty(false)
  }

  const actionsDisabled = disabled || !dirty

  return (
    <li
      style={cardChrome(open, hovered)}
      data-plugin-card="llm-headers"
      onMouseEnter={() => { setHovered(true) }}
      onMouseLeave={() => { setHovered(false) }}
    >
      <button type="button" style={headerStyle} aria-expanded={open} onClick={() => { setOpen(!open) }}>
        <span style={headTextStyle}>
          <strong style={nameStyle}>{t('title')}</strong>
          <span style={descriptionStyle}>{t('description')}</span>
        </span>
        {dirty && <span style={pendingStyle}>{t('dirtyHint')}</span>}
        <span style={{ ...chevronStyle, ...(open ? chevronOpenStyle : {}) }} aria-hidden>
          <span style={chevronMarkStyle} />
        </span>
      </button>
      {open && (
        <div style={bodyStyle}>

          <div style={sectionTitle}>{t('headersTitle')}</div>
          <p style={hintStyle}>{t('headersHint')}</p>
          {draft.headers.map((row, index) => (
            <div key={index} style={rowStyle}>
              <FocusedInput
                placeholder={t('headerName')}
                aria-label={t('headerName')}
                value={row.name}
                disabled={disabled}
                onChange={(event) => { patchHeader(index, 'name', event.target.value) }}
              />
              <FocusedInput
                placeholder={t('headerValue')}
                aria-label={t('headerValue')}
                value={row.value}
                disabled={disabled}
                onChange={(event) => { patchHeader(index, 'value', event.target.value) }}
              />
              <LinkButton disabled={disabled} onClick={() => { removeHeader(index) }}>
                {t('removeRow')}
              </LinkButton>
            </div>
          ))}
          <button type="button" style={addButtonStyle} disabled={disabled} onClick={addHeader}>
            ＋ {t('addHeader')}
          </button>

          <div style={sectionTitle}>{t('patternTitle')}</div>
          <p style={hintStyle}>{t('patternHint')}</p>
          {draft.urlPatterns.map((value, index) => (
            <div key={index} style={rowStyle}>
              <FocusedInput
                placeholder={t('patternPlaceholder')}
                value={value}
                disabled={disabled}
                onChange={(event) => { patchPattern(index, event.target.value) }}
              />
              <LinkButton disabled={disabled} onClick={() => { removePattern(index) }}>
                {t('removeRow')}
              </LinkButton>
            </div>
          ))}
          <button type="button" style={addButtonStyle} disabled={disabled} onClick={addPattern}>
            ＋ {t('addPattern')}
          </button>

          <div style={footerStyle}>
            {snapshot.failed && (
              <p style={failedStyle} role="status">
                {snapshot.conflict ? t('saveConflict') : t('saveFailed')}
              </p>
            )}
            <button
              type="button"
              style={resetStyle}
              disabled={disabled}
              onClick={() => { void reset() }}
            >
              {t('reset')}
            </button>
            <button
              type="button"
              style={{
                ...discardStyle,
                ...(discardHovered && !actionsDisabled ? discardHoverStyle : {}),
                ...(actionsDisabled ? disabledActionStyle : {}),
              }}
              disabled={actionsDisabled}
              onMouseEnter={() => { setDiscardHovered(true) }}
              onMouseLeave={() => { setDiscardHovered(false) }}
              onClick={discard}
            >
              {t('discard')}
            </button>
            <button type="button" style={{ ...saveStyle, ...(actionsDisabled ? disabledActionStyle : {}) }} disabled={actionsDisabled} onClick={() => { void save() }}>
              {snapshot.saving ? t('saving') : t('save')}
            </button>
          </div>
        </div>
      )}
    </li>
  )
}

// The card draws its own chrome with inline styles; the Host theme tokens are
// exposed as CSS variables on :root, so the card stays theme-consistent
// without importing UI primitives. Host pseudo-class chrome (hover, focus) is
// reproduced from element state by the components above.

/** The card shell: matches the Host PluginCard, stepped one layer up when open and border-dimmed on hover. */
const cardChrome = (open: boolean, hovered: boolean): CSSProperties => ({
  listStyle: 'none',
  border: `1px solid ${open || hovered ? 'var(--dsw-alias-label-dimmed)' : 'var(--dsw-alias-border-l2)'}`,
  borderRadius: 12,
  background: open ? 'var(--dsw-alias-bg-layer-2)' : 'var(--dsw-alias-bg-layer-3)',
  transition: 'border-color .16s, background .16s',
})

/** The disclosing header: unstyled button chrome around the head text. */
const headerStyle: CSSProperties = {
  width: '100%',
  appearance: 'none',
  border: 0,
  background: 'none',
  font: 'inherit',
  color: 'inherit',
  textAlign: 'left',
  cursor: 'pointer',
  display: 'flex',
  alignItems: 'center',
  gap: 12,
  padding: '14px 16px',
  borderRadius: 12,
}

/** Name over description: the description tells the plugins apart, so it gets its own line. */
const headTextStyle: CSSProperties = {
  flex: 1,
  minWidth: 0,
  display: 'flex',
  flexDirection: 'column',
  gap: 4,
}

const nameStyle: CSSProperties = {
  fontSize: 15,
  fontWeight: 600,
  lineHeight: 1.4,
  color: 'var(--dsw-alias-label-primary)',
}

const descriptionStyle: CSSProperties = {
  margin: 0,
  fontSize: 13,
  lineHeight: 1.5,
  color: 'var(--dsw-alias-label-tertiary)',
}

/** Carried on the header so a collapsed card still says it holds edits. */
const pendingStyle: CSSProperties = {
  flex: 'none',
  borderRadius: 999,
  padding: '1px 8px',
  fontSize: 11,
  // React emits a number as a unitless multiplier (17 × 11px), where the
  // Host's stylesheet writes the explicit pixel value.
  lineHeight: '17px',
  fontWeight: 500,
  whiteSpace: 'nowrap',
  background: 'var(--dsw-alias-bg-module-platform)',
  color: 'var(--dsw-alias-label-secondary)',
}

/** Down chevron drawn from two borders; rotated 180° when open. */
const chevronStyle: CSSProperties = {
  flex: 'none',
  color: 'var(--dsw-alias-label-tertiary)',
  display: 'inline-flex',
  alignItems: 'center',
  transition: 'transform .16s',
}
const chevronMarkStyle: CSSProperties = {
  width: 7,
  height: 7,
  borderRight: '1.5px solid currentColor',
  borderBottom: '1.5px solid currentColor',
  transform: 'rotate(45deg)',
  marginBottom: 2,
}
const chevronOpenStyle: CSSProperties = { transform: 'rotate(180deg)' }

/** The expanded controls, separated from the header by a hairline. */
const bodyStyle: CSSProperties = {
  borderTop: '1px solid var(--dsw-alias-border-l2)',
  margin: '0 16px',
  paddingBottom: 8,
  display: 'flex',
  flexDirection: 'column',
  gap: 6,
}

const sectionTitle: CSSProperties = {
  marginTop: 12,
  fontSize: 13,
  fontWeight: 500,
  lineHeight: 1.5,
  color: 'var(--dsw-alias-label-primary)',
}

const hintStyle: CSSProperties = {
  margin: 0,
  fontSize: 12,
  lineHeight: 1.5,
  color: 'var(--dsw-alias-label-tertiary)',
}

const rowStyle: CSSProperties = { display: 'flex', gap: 8, alignItems: 'center' }

/** A text input matching the Host field control. */
const inputStyle: CSSProperties = {
  flex: 1,
  minWidth: 0,
  height: 34,
  padding: '0 12px',
  border: '1px solid var(--dsw-alias-border-l2)',
  borderRadius: 8,
  background: 'var(--dsw-alias-bg-layer-3)',
  font: 'inherit',
  fontSize: 13,
  lineHeight: 1.5,
  color: 'var(--dsw-alias-label-primary)',
}
const inputFocusStyle: CSSProperties = { outline: 'none', borderColor: 'var(--dsw-alias-brand-primary)' }
const inputDisabledStyle: CSSProperties = { color: 'var(--dsw-alias-label-tertiary)', cursor: 'default' }

const addButtonStyle: CSSProperties = {
  alignSelf: 'flex-start',
  color: 'var(--dsw-alias-brand-primary)',
  background: 'transparent',
  border: 'none',
  padding: '4px 0',
  fontSize: 12,
  lineHeight: 1.5,
  cursor: 'pointer',
}

const linkButtonStyle: CSSProperties = {
  color: 'var(--dsw-alias-label-secondary)',
  background: 'transparent',
  border: 'none',
  padding: 0,
  fontSize: 12,
  lineHeight: 1.5,
  cursor: 'pointer',
}

/** The save row: hairline over the controls, actions right-aligned. */
const footerStyle: CSSProperties = {
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'flex-end',
  gap: 8,
  padding: '12px 0 4px',
  borderTop: '1px solid var(--dsw-alias-border-l2)',
}

const failedStyle: CSSProperties = {
  flex: 1,
  minWidth: 0,
  margin: 0,
  fontSize: 12,
  lineHeight: 1.5,
  color: 'var(--dsw-alias-label-error)',
}

const actionButtonStyle: CSSProperties = {
  appearance: 'none',
  border: '1px solid transparent',
  borderRadius: 8,
  padding: '5px 14px',
  font: 'inherit',
  fontSize: 13,
  lineHeight: 1.5,
  cursor: 'pointer',
}

const discardStyle: CSSProperties = {
  ...actionButtonStyle,
  borderColor: 'var(--dsw-alias-border-l2)',
  background: 'none',
  color: 'var(--dsw-alias-label-secondary)',
}
const discardHoverStyle: CSSProperties = {
  color: 'var(--dsw-alias-label-primary)',
  borderColor: 'var(--dsw-alias-label-dimmed)',
}

/** The reset affordance: an action-button-weight link, so it reads as less destructive than discard. */
const resetStyle: CSSProperties = {
  ...actionButtonStyle,
  borderColor: 'transparent',
  color: 'var(--dsw-alias-label-secondary)',
  paddingRight: 6,
  paddingLeft: 6,
}

const saveStyle: CSSProperties = {
  ...actionButtonStyle,
  background: 'var(--dsw-alias-label-primary)',
  color: 'var(--dsw-alias-bg-layer-3)',
}

const disabledActionStyle: CSSProperties = { opacity: 0.4, cursor: 'default' }
