/**
 * Card copy for the `llm-headers` card, registered under the plugin's own
 * namespace to keep the Host dictionaries untouched.
 * @module dsh-llm-headers/client/locales
 */

export interface LlmHeadersLocale {
  title: string
  description: string
  headersTitle: string
  headersHint: string
  patternTitle: string
  patternHint: string
  addHeader: string
  addPattern: string
  headerName: string
  headerValue: string
  patternPlaceholder: string
  removeRow: string
  save: string
  discard: string
  reset: string
  dirtyHint: string
  saving: string
  saveFailed: string
  saveConflict: string
  unavailable: string
}

export const zh: LlmHeadersLocale = {
  title: 'LLM 请求头',
  description: '对匹配的 provider 请求注入自定义 HTTP Headers（可改写 user-agent）。',
  headersTitle: 'Headers',
  headersHint: '命中的请求将逐项 set() 这些头，覆盖同名值（含强制 attribution 的 user-agent）。',
  patternTitle: 'URL 匹配规则',
  patternHint: '请求 URL 包含任一子串即注入；默认匹配 /chat/completions。',
  addHeader: '添加 Header',
  addPattern: '添加规则',
  headerName: '名称',
  headerValue: '值',
  patternPlaceholder: '例如 /chat/completions',
  removeRow: '删除',
  save: '保存',
  discard: '放弃',
  reset: '恢复默认',
  dirtyHint: '有未保存的修改',
  saving: '保存中…',
  saveFailed: '保存被拒绝，请重试',
  saveConflict: '配置已被其他来源修改，已刷新显示，请重新保存',
  unavailable: '该命名空间当前不可用',
}

export const en: LlmHeadersLocale = {
  title: 'LLM headers',
  description: 'Inject custom HTTP headers into matching provider requests (user-agent etc.).',
  headersTitle: 'Headers',
  headersHint: 'Matching requests get each header set(), overwriting same-name values (the mandatory attribution user-agent included).',
  patternTitle: 'URL patterns',
  patternHint: 'A request URL containing any substring is rewritten; defaults to /chat/completions.',
  addHeader: 'Add header',
  addPattern: 'Add pattern',
  headerName: 'Name',
  headerValue: 'Value',
  patternPlaceholder: 'e.g. /chat/completions',
  removeRow: 'Remove',
  save: 'Save',
  discard: 'Discard',
  reset: 'Reset to defaults',
  dirtyHint: 'Unsaved changes',
  saving: 'Saving…',
  saveFailed: 'Save rejected, try again',
  saveConflict: 'Config changed elsewhere; it was refreshed — please save again',
  unavailable: 'This namespace is not available',
}
