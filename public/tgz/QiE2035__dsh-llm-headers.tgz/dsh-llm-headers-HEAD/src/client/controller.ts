/**
 * The card's server snapshot: reads and writes the `llm-headers` namespace
 * through the plugin's own RPC channel instead of the settings wire, because
 * `settings.describe` only serves namespaces on apiproxy's explicit allowlist
 * and an out-of-tree plugin's namespace can never be listed there. The card
 * owns no persistence: every write goes through the Host's settings provider
 * (`settings.replace` in the channel handler), so the same change arrives at
 * the plugin's `installSettingsSection` hook and the fetch wrapper.
 */

import { loadSection, saveSection } from './headers-wire.ts'

/** The subset of the namespace section this card edits. */
export interface ServerConfig {
  headers: Record<string, string>
  urlPatterns: string[]
}

/** The card's read state, published to the renderer. */
export interface CardSnapshot {
  /** False while the channel is not served to this client; the card renders nothing. */
  available: boolean
  /** The last accepted resolved section; undefined before the first load, or when the channel refused. */
  value: ServerConfig | undefined
  /** Whether a save is crossing the wire. */
  saving: boolean
  /** Whether the last save was rejected; cleared by the next edit or save. */
  failed: boolean
  /** Whether the last rejection was a concurrency conflict (the section moved since read). */
  conflict: boolean
  /** The namespace's raw-section revision the last snapshot was read at; guards stale writes. */
  revision: number | undefined
  /** Persist a new section value. */
  save: (next: ServerConfig) => Promise<boolean>
  /** Re-read the server snapshot (e.g. when the card reopens). */
  refresh: () => Promise<void>
  /** Reset the user layer to the composition base and schema defaults. */
  reset: () => Promise<boolean>
}

export class LlmHeadersController {
  private readonly listeners = new Set<() => void>()
  private attempts = 0
  /** Whether a load ever resolved the channel; mid-life failures keep the last good value. */
  private hadValue = false
  private snapshot: CardSnapshot = {
    available: false,
    value: undefined,
    saving: false,
    failed: false,
    conflict: false,
    revision: undefined,
    save: next => this.save(next),
    refresh: () => this.load(),
    reset: () => this.reset(),
  }

  /** @returns the current snapshot; stable until the next change. */
  getSnapshot(): CardSnapshot {
    return this.snapshot
  }

  /** Observe snapshot replacements. @param listener - called after each change. @returns the disposer. */
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  /** Refresh the server snapshot. @returns settlement once the read settled. */
  async load(): Promise<void> {
    this.attempts += 1
    try {
      const response = await loadSection()
      if (!response.ok) {
        this.publish({ available: this.hadValue, value: this.hadValue ? this.snapshot.value : undefined })
        return
      }
      this.hadValue = true
      this.publish({
        available: true,
        value: normalize(response.value.value),
        revision: response.value.revision,
      })
    } catch {
      // Transport failure before the channel answers (or a mid-life refresh
      // against a dropped channel): keep an earlier resolved value if one was
      // ever seen, else stay unavailable so the caller's retry loop picks the
      // channel up once it is served.
      this.publish({ available: this.hadValue, value: this.hadValue ? this.snapshot.value : undefined })
    }
  }

  /**
   * Persist a new section value through the channel, guarded by the last-read
   * revision so a write against a section that moved elsewhere is refused
   * instead of silently overwritten.
   * @param next - the section the user's draft became.
   * @returns whether the Host accepted the write.
   */
  async save(next: ServerConfig): Promise<boolean> {
    this.snapshot = { ...this.snapshot, saving: true }
    this.notify()
    try {
      const response = await saveSection(next, this.snapshot.revision)
      if (!response.ok) {
        return this.reject(response.error.code === 'conflict')
      }
      this.publish({
        saving: false,
        failed: false,
        conflict: false,
        value: next,
        revision: response.value.revision ?? this.snapshot.revision,
      })
      return true
    } catch {
      this.publish({ saving: false, failed: true, conflict: false })
      return false
    }
  }

  /**
   * Reset the user layer to the composition base and schema defaults by
   * replacing it with an empty section, then re-read the resolved value.
   * @returns whether the Host accepted the write.
   */
  async reset(): Promise<boolean> {
    this.snapshot = { ...this.snapshot, saving: true }
    this.notify()
    try {
      const response = await saveSection({ headers: {}, urlPatterns: [] }, this.snapshot.revision)
      if (!response.ok) {
        return this.reject(response.error.code === 'conflict')
      }
      this.publish({ saving: false, failed: false, conflict: false })
      await this.load()
      return true
    } catch {
      this.publish({ saving: false, failed: true, conflict: false })
      return false
    }
  }

  /**
   * Mark a refused write failed and, on a conflict, re-read the section that
   * moved under us so the next edit starts from fresh ground.
   * @param conflict - whether the refuse was a concurrency conflict.
   * @returns `false` so callers return it as the write outcome.
   */
  private reject(conflict: boolean): false {
    this.publish({
      saving: false,
      failed: true,
      conflict,
      value: this.snapshot.value,
      revision: this.snapshot.revision,
    })
    if (conflict) void this.load()
    return false
  }

  private publish(patch: Partial<CardSnapshot>): void {
    this.snapshot = { ...this.snapshot, ...patch }
    this.notify()
  }

  private notify(): void {
    for (const listener of this.listeners) listener()
  }

  /** Whether the initial registration retry budget is spent. */
  attemptsExhausted(): boolean {
    return this.attempts >= 5
  }
}

/** Narrow an arbitrary section into the shape this card edits, tolerating absent fields. */
export function normalize(section: unknown): ServerConfig {
  const raw = (section ?? {}) as { headers?: unknown; urlPatterns?: unknown }
  const headers: Record<string, string> = {}
  if (typeof raw.headers === 'object' && raw.headers !== null) {
    for (const [name, value] of Object.entries(raw.headers)) {
      if (typeof value === 'string') headers[name] = value
    }
  }
  const urlPatterns = Array.isArray(raw.urlPatterns)
    ? raw.urlPatterns.filter((value): value is string => typeof value === 'string')
    : []
  return { headers, urlPatterns }
}
