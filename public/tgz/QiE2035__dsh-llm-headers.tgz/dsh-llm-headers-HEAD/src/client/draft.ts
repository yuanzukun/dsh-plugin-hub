/**
 * Pure draft helpers shared by the card and its tests: a row-based editing
 * draft over the namespace section, seeded from a server value and narrowed
 * to a saveable section at save time. Kept free of React and the controller
 * so the card's edit semantics are unit-testable without a DOM.
 * @module dsh-llm-headers/client/draft
 */

import type { ServerConfig } from './controller.ts'

/** One editable header row in the draft. */
interface HeaderRow {
  name: string
  value: string
}

/** The draft the user is editing; empty rows are dropped at save. */
export interface Draft {
  headers: HeaderRow[]
  urlPatterns: string[]
}

/** Seed a draft from a server section, or empty rows for no section yet. */
export function draftOf(server: ServerConfig | undefined): Draft {
  return {
    headers: Object.entries(server?.headers ?? {}).map(([name, value]) => ({ name, value })),
    urlPatterns: [...(server?.urlPatterns ?? [])],
  }
}

/**
 * Narrow a draft to a saveable section: header rows without a name and empty
 * URL patterns are dropped. A header with an empty value survives — setting a
 * header to the empty string is legal.
 */
export function buildSection(draft: Draft): ServerConfig {
  return {
    headers: Object.fromEntries(
      draft.headers.filter(row => row.name.length > 0).map(row => [row.name, row.value]),
    ),
    urlPatterns: draft.urlPatterns.filter(value => value.length > 0),
  }
}
