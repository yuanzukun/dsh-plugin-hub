/**
 * Request-scoped HTTP header injection for `fetch`.
 *
 * The DeepSeek Harness provider adapters (`dsh-llm-deepseek`, `dsh-llm-pi-ai`)
 * issue every model request through the global `fetch`, building a plain
 * header object that always carries the mandatory attribution User-Agent (see
 * `dsh-llm/src/attribution.ts`). Wrapping `fetch` here lets a deployment
 * override any header on the wire — a white-label identity for a gateway that
 * requires its own brand, such as a proxy enforcing a `user-agent` — without
 * touching the adapters, and it covers every provider at once.
 *
 * The wrapper keeps its configuration behind an updater so a live settings
 * change takes effect on the next request, with no plugin reload.
 * @module dsh-llm-headers/fetch-proxy
 */

export interface FetchProxyOptions {
  /**
   * Header names to values. Each entry is `set()` on the outgoing request,
   * overwriting an existing value (the attribution User-Agent included);
   * headers the caller sent that are absent here are preserved.
   */
  headers: Readonly<Record<string, string>>
  /** URL substrings selecting which requests receive the headers; a request URL containing any substring is rewritten. */
  urlPatterns: readonly string[]
}

export interface FetchProxyHandle {
  /** The wrapped function to install as `globalThis.fetch`. */
  proxy: typeof fetch
  /** The original fetch captured at install time. */
  original: typeof fetch
  /** Swap the live configuration; the next request through `proxy` picks it up. */
  update: (options: FetchProxyOptions) => void
}

/**
 * Install a fetch wrapper that injects `options.headers` into every request
 * whose URL contains one of `options.urlPatterns`. Requests that do not match
 * (or that cannot be classified) pass through completely untouched.
 *
 * The per-request matcher state (`urlPatterns`, `headers` entries) is derived
 * once per configuration and swapped by `update`, so a matching request pays
 * no allocation for either; empty patterns are dropped at derivation time, so
 * a stray `''` cannot accidentally match every URL.
 * @param original - the fetch to delegate to, usually `globalThis.fetch` at install time.
 * @param initial - the starting configuration.
 * @returns the proxy, the captured original, and the live updater.
 */
export function installFetchProxy(
  original: typeof fetch,
  initial: FetchProxyOptions,
): FetchProxyHandle {
  let options: FetchProxyOptions = initial
  // Derived matcher state; rebuilt only by `update` (or the initial `initial`).
  let urlPatterns = derivePatterns(initial.urlPatterns)
  let entries = deriveEntries(initial.headers)
  const proxy: typeof fetch = (input, init) => {
    const url = requestUrl(input)
    if (url === undefined || !urlPatterns.some(pattern => url.includes(pattern))) {
      return original(input, init)
    }
    // An empty map keeps the wrapper fully inert: the request init object
    // (identity included) passes through unchanged.
    if (entries.length === 0) return original(input, init)
    // Seed from the caller's headers: the init object when one is present
    // (native semantics: init.headers replaces a Request's own), else the
    // Request's own headers so injecting never strips them.
    const source = input instanceof Request && init?.headers === undefined ? input.headers : init?.headers
    const headers = new Headers(source)
    for (const [name, value] of entries) {
      headers.set(name, value)
    }
    return original(input, { ...init, headers })
  }
  return {
    proxy,
    original,
    update(next) {
      // A settings attach fires the same configuration twice at boot; skipping
      // the identical reference keeps that duplicate call a no-op.
      if (next === options) return
      options = next
      urlPatterns = derivePatterns(next.urlPatterns)
      entries = deriveEntries(next.headers)
    },
  }
}

/**
 * Derive the matcher patterns: non-empty substrings only. A config that omits
 * `urlPatterns` (a direct call, or a settings layer without the field) matches
 * nothing rather than throwing on `.some` of undefined.
 */
function derivePatterns(urlPatterns: readonly string[] | undefined): string[] {
  return urlPatterns?.filter(pattern => pattern.length > 0) ?? []
}

/** Derive the header entry list the proxy iterates per matching request. */
function deriveEntries(headers: Readonly<Record<string, string>> | undefined): [string, string][] {
  return Object.entries(headers ?? {})
}

/** Extract the request URL as a string, or undefined for a request we cannot classify. */
function requestUrl(input: RequestInfo | URL): string | undefined {
  if (typeof input === 'string') return input
  if (input instanceof URL) return input.href
  if (typeof Request !== 'undefined' && input instanceof Request) return input.url
  // A Request from another realm fails the instanceof checks above; pass it
  // through untouched rather than risk rewriting a request we misread.
  return undefined
}
