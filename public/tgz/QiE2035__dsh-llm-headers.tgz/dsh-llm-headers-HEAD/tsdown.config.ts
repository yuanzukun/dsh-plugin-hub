import { defineConfig } from 'tsdown'

/** Bundle the plugin entry; the peer framework packages stay external for the host to provide. */
export default defineConfig({
  entry: ['src/index.ts'],
  outDir: 'lib',
  format: ['esm'],
  platform: 'node',
  target: 'es2024',
  // Emit lib/index.js / lib/index.d.ts, matching the manifest's `exports`.
  fixedExtension: false,
  dts: true,
  clean: true,
})