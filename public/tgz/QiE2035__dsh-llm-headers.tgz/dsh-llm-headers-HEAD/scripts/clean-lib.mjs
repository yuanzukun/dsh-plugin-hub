/** Remove the build output directory before a fresh two-pass build. */
import { rmSync } from 'node:fs'

rmSync(new URL('../lib', import.meta.url), { recursive: true, force: true })