<p align="center">
  <a href="https://dshfind.com/zh/plugins/huanlinoto/dsh-plugin-ya-workspace-sidebar"><img src="https://dshfind.com/api/card/huanlinoto/dsh-plugin-ya-workspace-sidebar?lang=zh" alt="dsh-plugin-ya-workspace-sidebar card"></a>
</p>

# ya-workspace-sidebar

[![npm version](https://img.shields.io/npm/v/@huanlin/dsh-plugin-ya-workspace-sidebar)](https://www.npmjs.com/package/@huanlin/dsh-plugin-ya-workspace-sidebar)

![cover](assets/cover.webp)

DSH Web 工作区侧栏替代插件。顶部以虚拟滚动展示全局最近会话（完整列表，不限于 5 条），与下方 Workspace → Session 二级菜单之间有一条可拖拽分隔条（也支持方向键微调、双击复位），面包屑导航与选中工作区的会话按本地日历日期分组（今天/昨天/更早）；搜索、添加工作区、重命名、删除、Fork 与归档继续使用 DSH 原生 Host 能力。会话行支持右键菜单（与 … 按钮菜单一致）：置顶（本地，置顶行浮于日期分组之上）、重命名、标记未读（本地蓝点，打开会话自动清除）、在资源管理器中打开工作目录、复制路径 / 任务路径 / 日志路径 / 会话 ID。任务路径与日志路径仅文件型（jsonl）持久化部署可用；sqlite 型部署（如 @morlay/better-session）对应菜单项自动禁用。工作区行不设悬停按钮，右键直接弹出菜单（新建会话 / 在资源管理器中打开 / 复制路径 / 重命名 / 删除）；标题超宽时以渐隐（mask 渐变）截断、不显示省略号，路径保持左对齐省略号硬截断。

## 运行

插件采用 bundle 形式，`cordis.patch.yml` 会禁用官方 `ui-workspace` 并插入 `@huanlin/dsh-plugin-ya-workspace-sidebar`。DSH v0.1.2-alpha.1 起，官方 `ui-sidebar` / `ui-conversation` / `ui-agent-preset` 及目录选择器组合包会注入 `ctx.uiWorkspace` 服务，本插件 client entry 通过 `src/client/navigation.ts` 自供该服务的替身（含复用/新建会话导航、current/recent 回退、归档清理与启动自动选择策略），否则这些条目会永久 pending 导致 WebUI 启动死锁。自 dsh `0.2.1-alpha.5` 起，替身同时透传官方服务面新增的参数：`startSession`/`connectWorkspace`/`openWorkspace` 的 `StartSessionOptions`（Agent 预设 `agentPreset` 与草稿初始化内容——`ui-agent-preset` 的预设启动即走该路径）、`forkSession` 的 `allowMigration`；无参数的「新建会话」按上游新语义直接创建新会话而不再复用挂载中的 blank；空 profile 启动时先引导默认工作区再自动选择。安装：

```powershell
# 从 npm 安装（推荐）：
dsh plugin --profile web add @huanlin/dsh-plugin-ya-workspace-sidebar

# 本地开发（热更新）：
dsh plugin --profile web add "link:D:/Projects/deepseek-harness/ya-workspace-sidebar"
```

修改源码后重新运行 `pnpm run build`，再重启 `dsh web` 并硬刷新浏览器。

## 开发

```powershell
pnpm install
pnpm run typecheck
pnpm run typecheck:tests
pnpm test
pnpm run build
```

`dsh/` 仅作为类型和行为参考，插件不会修改 DSH checkout。浏览器产物预构建到 `lib/client.js`，因此仓库发布时必须提交 `lib/`。

## 检查

```powershell
pnpm run typecheck
pnpm run typecheck:tests
pnpm test
pnpm run build
```

构建后确认 `lib/index.js`、`lib/client.js` 和 `lib/types/` 存在，并确认 `lib/client.js` 使用 `window.__ModuleLoader__.load()` 包装。

> 本包自 v0.1.2-rc.1 起不再发布 `./invariant` 导出：本插件贡献的均为 client-only slot 条目，无独立可分歧的观察，按新 invariant 规则省略其源码与接线。
