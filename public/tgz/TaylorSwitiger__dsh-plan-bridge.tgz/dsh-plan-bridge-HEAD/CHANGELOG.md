# Changelog

## 0.3.2 (2026-09-04)

- npm 包名改为 `@taylorswitiger/dsh-plan-bridge`：非作用域名 `dsh-plan-bridge` 被 registry
  以与既有包 `dsh-planbridge` 过于相似为由拒绝（防抢注规则）；作用域名不受此限，
  发布需 `npm publish --access=public`

## 0.3.1 (2026-09-03)

- 文档措辞清理，安装说明改为 GitHub 仓库地址（npm 未发布），安装命令经临时 profile 实测
- 代码清理：合并重复导入、移除未用导入、修正 JSDoc 笔误、清除注释里的不可见字符
- smoke 脚本收尾关闭监听并退出，不再挂起；调试日志写入收敛为 util.debugLogger()
- `pnpm run check` 增加 package.json 与 lib/index.js 的版本一致性校验
- 仓库加 .gitattributes 统一 LF；LICENSE 版权人改为作者

## 0.3.0 (2026-09-02)

- 新增 zcode（BigModel GLM Coding Plan）与 qwen（阿里云百炼 Token Plan）适配器，均为
  API-key 型；`apikey-plan.js` 工厂一份 spec 生成一个完整适配器
- 接入改为用户显式选择：每行一键接入 / 停用；新增 `provision.disable` 端点（该套餐为
  默认模型指向时拒绝停用）
- 新增「不可用」状态：本机无凭据的套餐如实显示并附凭据指引
- 修复重复 provision 的幂等误报：settings 往返会补上空默认值，比较前先归一
- 修复闲置实例上「不可用」被显示为「需先登录厂商 CLI」

## 0.2.0 (2026-09-01)

- 多套餐架构：一个 loopback 进程按路径前缀分流
- codex 适配器：OAuth token 续期写回、SSE 透传
- claude 适配器（beta）：订阅 OAuth 续期与 anthropic-messages 转发
- Connection RPC 渠道 `/dsh-plan-bridge`：plans.list / plan.status / provision.begin
- 设置页「套餐接入」卡片，中英文案
