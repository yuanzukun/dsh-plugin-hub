/**
 * Standalone smoke test: boot the bridge outside dsh with a mock cordis ctx
 * on a private port, hit /health, then shut down cleanly. Verifies that every
 * adapter loads and the listener answers.
 *
 * Usage: node scripts/smoke.mjs   (SMOKE_PORT overrides the port)
 */
import { apply } from '../lib/index.js'

const port = Number(process.env.SMOKE_PORT ?? 8418)
const disposers = []
const ctx = {
  logger: console,
  effect: (register) => { disposers.push(register()); return () => {} },
  inject: null,
}
await apply(ctx, { port })

const { ok, plans } = await (await fetch(`http://127.0.0.1:${port}/health`)).json()
if (ok !== true) throw new Error('smoke: /health answered not-ok')
console.log(`smoke: bridge up, plans: ${plans.join(', ')}`)

for (const dispose of disposers) await dispose()
console.log('smoke: clean exit')
