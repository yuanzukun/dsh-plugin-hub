/**
 * Build entry: the client half is a hand-written module-table bundle (no
 * bundler needed), so "building" this package means verifying every shipped
 * artifact parses and carries the wrapper the client module system expects.
 * A real bundler step can be added later without changing this contract.
 *
 * Usage: node scripts/build.mjs [--check]  (--check exits non-zero on failure)
 */
import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

const packageRoot = join(dirname(fileURLToPath(import.meta.url)), '..')
const hostFiles = [
  'lib/index.js', 'lib/server.js', 'lib/provision.js',
  'lib/adapters/index.js', 'lib/adapters/util.js', 'lib/adapters/apikey-plan.js',
  'lib/adapters/codex.js', 'lib/adapters/claude.js',
  'lib/adapters/zcode.js', 'lib/adapters/qwen.js',
]

const failures = []
const fail = (message) => { failures.push(message); console.error(`build: FAIL ${message}`) }

// 1. Host files: node --check (parse as ES modules).
for (const relative of hostFiles) {
  const absolute = join(packageRoot, relative)
  try {
    execFileSync(process.execPath, ['--check', absolute], { stdio: 'pipe' })
    console.log(`build: ok ${relative}`)
  } catch (error) {
    fail(`${relative} does not parse: ${String(error.stderr)}`)
  }
}

// 2. Client bundle: parse + wrapper + react external through the factory require.
try {
  const source = readFileSync(join(packageRoot, 'lib/client.js'), 'utf8')
  new Function(source)
  if (!source.includes("window.__ModuleLoader__.load({") || !source.includes("id: 'dsh-plan-bridge'")) {
    fail('lib/client.js lost its module-table wrapper')
  }
  if (!source.includes("require('react')")) {
    fail('lib/client.js must resolve react through the factory require (shell-shared external)')
  }
  console.log('build: ok lib/client.js (wrapper + externals)')
} catch (error) {
  fail(`lib/client.js does not parse: ${String(error)}`)
}

// 3. Packaging contract: exports, dsh declarations, patch rows.
try {
  const pkg = JSON.parse(readFileSync(join(packageRoot, 'package.json'), 'utf8'))
  if (pkg.name !== '@taylorswitiger/dsh-plan-bridge') fail('package.json name must be @taylorswitiger/dsh-plan-bridge')
  if (pkg.exports?.['./client'] !== './lib/client.js') fail('package.json exports["./client"] missing')
  if (pkg.dsh?.client?.platform !== 'web') fail('dsh.client.platform must be web')
  if (!Array.isArray(pkg.dsh?.client?.inject) || pkg.dsh.client.inject.length === 0) fail('dsh.client.inject missing')
  if (pkg.dsh?.bundle?.patch !== './cordis.patch.yml') fail('dsh.bundle.patch missing')
  if (pkg.dependencies !== undefined) fail('runtime dependencies must stay empty')
  const indexSource = readFileSync(join(packageRoot, 'lib/index.js'), 'utf8')
  const declared = indexSource.match(/const VERSION = '([^']+)'/)?.[1]
  if (declared !== pkg.version) fail(`version drift: package.json ${pkg.version} vs lib/index.js VERSION ${declared}`)
  console.log('build: ok package.json contract')
} catch (error) {
  fail(`package.json unreadable: ${String(error)}`)
}
try {
  const patch = readFileSync(join(packageRoot, 'cordis.patch.yml'), 'utf8')
  if (!patch.includes("name: 'dsh-plan-bridge'") || !patch.includes('id: plan-bridge')) {
    fail('cordis.patch.yml must insert id plan-bridge / name dsh-plan-bridge')
  }
  console.log('build: ok cordis.patch.yml')
} catch (error) {
  fail(`cordis.patch.yml unreadable: ${String(error)}`)
}

if (failures.length > 0) {
  console.error(`build: ${failures.length} failure(s)`)
  process.exit(1)
}
console.log('build: all artifacts verified')
