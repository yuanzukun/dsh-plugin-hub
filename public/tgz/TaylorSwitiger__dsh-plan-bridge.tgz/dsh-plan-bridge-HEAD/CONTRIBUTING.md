# 贡献

## 开发安装

pnpm 的 `file:` 依赖是拷贝。改完源码要重新装到 profile 并重启对应 host，否则跑的还是旧代码：

```sh
dsh plugin --profile <name> add -w file:<repo 路径>
```

## 检查

```sh
pnpm run check          # 全部文件解析 + 打包契约断言（exports、patch 行、零依赖）
node scripts/smoke.mjs  # 不经 dsh 独立起一个桥接（SMOKE_PORT 改端口），验证适配器加载
```

## 测试注意

dsh 内置浏览器的合成点击只产生 hover，不激活按钮。验证卡片交互用真实浏览器加 CDP：
web 用 headless Chromium 的 evaluate + DOM 断言，桌面用 `--remote-debugging-port` 加 Input
domain 真点击。

## 改动范围

- 框架文件（server.js、index.js、provision.js）不需要因为新套餐而改动；新套餐只加
  `lib/adapters/` 下一个文件并在注册表加一行，同时把它加进 `scripts/build.mjs` 的清单
- 上游端点与模型元数据优先取自 pi-ai 内置 catalog，保证与 dsh 原生路由同源
- 不要在代码、日志、README 里写任何真实 token、key 或账号；账号展示一律掩码
