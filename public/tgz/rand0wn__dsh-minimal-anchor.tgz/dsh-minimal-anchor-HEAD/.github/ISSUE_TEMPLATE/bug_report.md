---
name: Bug report
about: Something isn't pruning, injecting, or loading correctly
labels: bug
---

**What happened**

**What you expected**

**Output of `dsh --profile <name> --dump-config` (the `minimal-anchor` entry, or its absence)**

```yaml

```

**Plugin config, if not defaults**

```yaml

```

**`dsh` version (`dsh --version`) and profile (`web` / `headless` / other)**
