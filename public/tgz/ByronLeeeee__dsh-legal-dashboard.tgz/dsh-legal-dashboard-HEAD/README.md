# DSH Legal Dashboard

English | [中文](README.zh.md)

[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek%20Harness-0.1.0--rc.7-4f46e5)](https://github.com/deepseek-ai/deepseek-harness)
[![DSH Plugin](https://img.shields.io/badge/DSH-community%20plugin-0f766e)](https://github.com/topics/dsh-plugin)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

A matter-aware legal workspace for [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness). It turns each Harness workspace into a focused environment for litigation, arbitration, investigations, contract review, due diligence, advisory work, and other legal matters.

> [!IMPORTANT]
> This is a community plugin for the DeepSeek Harness developer preview. Version `0.2.x` has been tested with `@deepseek-ai/dsh 0.1.0-rc.7`. It uses rc7's `shell.overlay` surface so the matter workspace, document preview, and native tool details can coexist.

## Highlights

- **Matter workspace:** a right-side panel for overview, files, tasks, and matter-specific settings without covering the conversation area.
- **Legal file intelligence:** recursive file tree, folder collapsing, search, DOCX/PDF text indexing, and PDF classification as text, scanned, mixed, or unknown.
- **Document preview:** PDF, image, plain-text, and extracted DOCX previews inside the workspace.
- **Matter-aware checklist:** automatic or manual matter classification with checklists for litigation, arbitration, criminal, administrative, complaint, contract review, due diligence, advisory, and special non-contentious work.
- **Legal document operations:** create DOCX/PDF deliverables, extract text, revise DOCX files, and save new versions without silently overwriting originals.
- **OCR workflow:** prepare scanned PDFs and images, request explicit approval before external transmission, call an OpenAI-compatible vision model, and persist reviewed Markdown results.
- **Native Harness tasks:** create long-term goals through `/goal` and display live goals and todos in the Tasks tab.
- **Adaptive bilingual UI:** all plugin UI follows the Harness `Chinese / English` language preference immediately, including matter types, checklists, and file categories.

## Compatibility

| Component | Supported configuration |
| --- | --- |
| DeepSeek Harness | `0.1.0-rc.7` (verified) |
| Surface | Harness Web UI |
| Languages | English and Simplified Chinese |
| Distribution | GitHub DSH bundle with prebuilt client assets |
| Host platforms | Windows tested; host logic is Node.js-based |

## Installation

Install the plugin into the standard Web profile:

```powershell
dsh plugin --profile web add "github:ByronLeeeee/dsh-legal-dashboard#main"
dsh web
```

For a reproducible installation, replace `main` with a trusted commit SHA:

```powershell
dsh plugin --profile web add "github:ByronLeeeee/dsh-legal-dashboard#<commit-sha>"
```

Only install Git dependencies whose source you trust. See the Harness guide on [packaging and installing plugins](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.md).

### Uninstall

```powershell
dsh plugin --profile web remove dsh-legal-dashboard
```

## Getting started

1. Run `dsh web` and open `http://localhost:3080/`.
2. Select **Add workspace** and choose the folder containing the matter files.
3. Select the workspace and click **Matter** in the left sidebar.
4. Use **Overview** for the checklist and quick actions, **Files** for search and preview, **Tasks** for goals and todos, and **Settings** for matter type and OCR configuration.

Example prompts:

```text
Review all matter files and identify disputed issues and missing evidence.
Prepare an evidence index with the source and purpose of proof for each item.
Draft a statement of claim and save it as Work Product/Statement of Claim.docx.
Run OCR on Evidence/Chat Records.pdf and save the reviewed result as Markdown.
/goal Complete matter review, drafting, and final delivery.
```

## OCR configuration

The main conversation can continue to use DeepSeek. OCR uses a separate OpenAI-compatible vision endpoint. Open **Matter → Settings → OCR** and configure:

- Base URL, such as `https://api.openai.com/v1`
- An image-capable model name
- API key
- Maximum pages, output tokens, and timeout

The API key is stored through the Harness credential service or read from `DSH_LEGAL_OCR_API_KEY`; it should not be committed to YAML. Leaving the Base URL or model empty disables external OCR.

Before external OCR sends any page image, Harness asks for explicit approval. OCR results are cached against the source file signature and reused only while current.

## Security model

- Every file operation resolves from the active Agent session's workspace.
- Absolute paths, path traversal, symbolic links, non-regular files, and access outside the registered workspace are rejected.
- Document operations create new files or revised copies by default and do not silently overwrite source documents.
- Local indexes are written to `.legal-index`; temporary OCR pages are written to `.legal-ocr`.
- External OCR is optional, requires configuration, and passes through an approval boundary before file content leaves the machine.
- Generated analysis and documents require professional review before use or delivery.

## Windows launcher

Windows users may run [`desktop/启动律师工作台.cmd`](desktop/%E5%90%AF%E5%8A%A8%E5%BE%8B%E5%B8%88%E5%B7%A5%E4%BD%9C%E5%8F%B0.cmd). The launcher reuses an existing service on port 3080 or starts its own hidden Harness process and opens an Edge app window. It only stops a service that it started itself.

## Development and verification

Install dependencies and run the host-side syntax and behavior checks:

```powershell
npm ci
npm run check
```

The current suite covers workspace containment, file walking and search, document operations, PDF/OCR workflows, matter profiling, and Harness tool registration. The prebuilt Web client is committed under `lib/` for GitHub installation.

## Project status

This project follows the rapid development of DeepSeek Harness. Compatibility fixes and narrowly scoped contributions are welcome through [issues](https://github.com/ByronLeeeee/dsh-legal-dashboard/issues) and pull requests.

## License

[MIT](LICENSE)
