# DSH Legal Dashboard

[English](README.md) | 中文

[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek%20Harness-0.1.0--rc.7-4f46e5)](https://github.com/deepseek-ai/deepseek-harness)
[![DSH Plugin](https://img.shields.io/badge/DSH-community%20plugin-0f766e)](https://github.com/topics/dsh-plugin)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

面向 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的法律项目工作台。它将每个 Harness Workspace 组织为专注于诉讼、仲裁、调查、合同审查、尽职调查、法律顾问及其他法律事项的工作环境。

> [!IMPORTANT]
> 本项目是 DeepSeek Harness 开发者预览版的社区插件。`0.2.x` 已在 `@deepseek-ai/dsh 0.1.0-rc.7` 上完成验证，并改用 rc7 的 `shell.overlay`：案件工作台、文档预览与 Harness 原生工具详情可以同时存在。

## 主要能力

- **案件工作台：** 提供概览、材料、任务和项目配置的右侧栏，打开时不覆盖会话区域。
- **法律材料分析：** 支持递归文件树、目录折叠、文本检索、DOCX/PDF 全文索引，以及 PDF 文本件、扫描件、混合文档和待判断文档分类。
- **文档预览：** 在工作台中预览 PDF、图片、普通文本和已提取的 DOCX 内容。
- **项目清单：** 自动识别或手动选择诉讼、仲裁、刑事、行政、投诉举报、合同审查、尽职调查、法律顾问和专项非诉类型，生成对应材料清单。
- **法律文档操作：** 创建 DOCX/PDF 交付成果、提取文本、修订 DOCX 并另存新版本，不静默覆盖原文件。
- **OCR 工作流：** 处理扫描 PDF 和图片，外传前明确请求批准，调用 OpenAI 兼容视觉模型，并保存经校对的 Markdown 结果。
- **Harness 原生任务：** 通过 `/goal` 创建长期目标，在任务页同步显示目标和待办。
- **中英文自适应：** 插件界面即时跟随 Harness“中文 / English”语言设置，包括事项类型、项目清单和材料分类。

## 兼容性

| 组件 | 支持情况 |
| --- | --- |
| DeepSeek Harness | `0.1.0-rc.7`（已验证） |
| 交互界面 | Harness Web UI |
| 语言 | English 和简体中文 |
| 分发方式 | GitHub DSH Bundle，包含预构建客户端产物 |
| 主机平台 | Windows 已测试；主机逻辑基于 Node.js |

## 安装

安装到标准 Web Profile：

```powershell
dsh plugin --profile web add "github:ByronLeeeee/dsh-legal-dashboard#main"
dsh web
```

如需可复现安装，请将 `main` 替换为已审核的提交 SHA：

```powershell
dsh plugin --profile web add "github:ByronLeeeee/dsh-legal-dashboard#<commit-sha>"
```

只应安装源码可信的 Git 依赖。详见 Harness 官方的[插件打包与安装指南](https://github.com/deepseek-ai/deepseek-harness/blob/master/docs/user/develop/basic/publish.zh.md)。

### 卸载

```powershell
dsh plugin --profile web remove dsh-legal-dashboard
```

## 开始使用

1. 运行 `dsh web`，打开 `http://localhost:3080/`。
2. 选择“添加工作区”，导入存放项目材料的文件夹。
3. 选择该 Workspace，再点击左侧的“案件”。
4. 在“概览”中使用清单和快捷工作，在“材料”中检索与预览，在“任务”中查看目标与待办，在“配置”中设置事项类型和 OCR。

指令示例：

```text
梳理当前案件材料，列出争议焦点和待补证据。
基于当前材料编制证据目录，注明来源文件和证明目的。
起草民事起诉状，并保存为 工作成果/民事起诉状.docx。
对 证据/聊天记录.pdf 执行 OCR，并将校对结果保存为 Markdown。
/goal 完成该案件的材料审查、文书起草和最终交付。
```

## OCR 配置

主对话模型可继续使用 DeepSeek。OCR 使用独立的 OpenAI 兼容视觉服务。打开“**案件 → 配置 → OCR**”并设置：

- Base URL，例如 `https://api.openai.com/v1`
- 支持图像输入的模型名称
- API Key
- 最多页数、输出 Tokens 和超时时间

API Key 通过 Harness 凭据服务保存，或从 `DSH_LEGAL_OCR_API_KEY` 读取；不应提交到 YAML。Base URL 或模型留空时，外部 OCR 保持禁用。

向外部 OCR 发送任何页面图像前，Harness 会请求明确批准。OCR 结果会按源文件特征缓存，仅在缓存仍有效时复用。

## 安全边界

- 所有文件操作均从当前 Agent Session 的 Workspace 解析。
- 拒绝绝对路径、目录逃逸、符号链接、非普通文件及已登记 Workspace 之外的访问。
- 文档操作默认创建新文件或另存修订版，不静默覆盖源文档。
- 本地索引写入 `.legal-index`；OCR 临时页写入 `.legal-ocr`。
- 外部 OCR 默认关闭，需完成配置，且文件内容离开本机前必须通过批准边界。
- 自动生成的分析和文档在使用或交付前必须经专业人员复核。

## Windows 启动器

Windows 用户可运行 [`desktop/启动律师工作台.cmd`](desktop/%E5%90%AF%E5%8A%A8%E5%BE%8B%E5%B8%88%E5%B7%A5%E4%BD%9C%E5%8F%B0.cmd)。启动器会复用已经监听 3080 端口的服务；如服务未运行，则在后台启动 Harness，并打开 Edge 应用窗口。它只会停止由自身启动的服务。

## 开发与验证

安装依赖，并运行主机端语法及行为检查：

```powershell
npm ci
npm run check
```

当前测试覆盖 Workspace 边界、文件遍历与检索、文档操作、PDF/OCR 工作流、事项类型分析和 Harness 工具注册。为支持 GitHub 直接安装，预构建 Web 客户端产物已提交到 `lib/`。

## 项目状态

本项目会跟随 DeepSeek Harness 的快速迭代持续更新。欢迎通过 [Issues](https://github.com/ByronLeeeee/dsh-legal-dashboard/issues) 反馈兼容性问题，或提交范围明确的 Pull Request。

## 许可证

[MIT](LICENSE)

