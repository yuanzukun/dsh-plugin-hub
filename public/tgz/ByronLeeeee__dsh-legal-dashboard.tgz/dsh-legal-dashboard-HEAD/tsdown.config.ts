import { clientBundle } from '../deepseek-harness-rc7/packages/client/tsdown.client.ts'

const bundle = clientBundle('dsh-legal-dashboard', [])

export default (options: Parameters<typeof bundle>[0]) =>
  bundle(options).filter(config => config.name === 'dsh-legal-dashboard/client')
