import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import { mkdir, realpath } from 'node:fs/promises'
import { homedir } from 'node:os'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const SCRIPT = fileURLToPath(new URL('../runtime/document_ops.py', import.meta.url))

function inside(root, candidate) {
  const prefix = root.endsWith(path.sep) ? root : `${root}${path.sep}`
  return candidate.startsWith(prefix)
}

export async function resolveWorkspaceOutput(root, relativePath, extensions) {
  if (typeof relativePath !== 'string' || relativePath.length === 0 || path.isAbsolute(relativePath)) {
    throw new Error('outputPath must be relative to the current workspace')
  }
  const canonicalRoot = await realpath(root)
  const output = path.resolve(canonicalRoot, relativePath)
  if (!inside(canonicalRoot, output)) throw new Error('outputPath escapes the current workspace')
  if (!extensions.includes(path.extname(output).toLowerCase())) {
    throw new Error(`outputPath must end with ${extensions.join(' or ')}`)
  }
  await mkdir(path.dirname(output), { recursive: true })
  return output
}

export function runDocumentOperation(pythonExecutable, payload) {
  return new Promise((resolve, reject) => {
    const bundledPython = path.join(homedir(), '.cache', 'codex-runtimes', 'codex-primary-runtime', 'dependencies', 'python', process.platform === 'win32' ? 'python.exe' : 'bin/python')
    const executable = pythonExecutable === 'auto'
      ? (existsSync(bundledPython) ? bundledPython : process.platform === 'win32' ? 'python' : 'python3')
      : pythonExecutable
    const child = spawn(executable, [SCRIPT], {
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
      shell: false,
      env: { ...process.env, PYTHONUTF8: '1', PYTHONIOENCODING: 'utf-8' },
    })
    const stdout = []
    const stderr = []
    child.stdout.on('data', chunk => stdout.push(chunk))
    child.stderr.on('data', chunk => stderr.push(chunk))
    child.on('error', error => reject(new Error(`document runtime failed to start: ${error.message}`)))
    child.on('close', code => {
      const output = Buffer.concat(stdout).toString('utf8')
      const errorText = Buffer.concat(stderr).toString('utf8').trim()
      if (code !== 0) return reject(new Error(errorText || output || `document runtime exited with ${code}`))
      try { resolve(JSON.parse(output)) } catch { reject(new Error('document runtime returned invalid JSON')) }
    })
    child.stdin.end(JSON.stringify(payload))
  })
}
