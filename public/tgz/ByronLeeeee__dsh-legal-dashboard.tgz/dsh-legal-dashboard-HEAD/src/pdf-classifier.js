import { walkProject } from './project-scan.js'
import { runDocumentOperation } from './document-runtime.js'

const cache = new Map()

export async function classifyWorkspacePdfs(root, options = {}) {
  const walked = await walkProject(root, options)
  const pdfs = walked.files.filter(file => file.extension === '.pdf')
  const pending = []
  const results = new Map()

  for (const file of pdfs) {
    const key = `${file.absolute}\0${file.size}\0${file.modifiedAt}`
    const cached = cache.get(key)
    if (cached === undefined) pending.push({ file, key })
    else results.set(file.relative, cached)
  }

  if (pending.length > 0) {
    const classified = await runDocumentOperation(options.pythonExecutable ?? 'auto', {
      operation: 'classify_pdfs',
      samplePages: options.samplePages ?? 5,
      documents: pending.map(({ file }) => ({ input: file.absolute, path: file.relative })),
    })
    for (const document of classified.documents) {
      const item = pending.find(({ file }) => file.relative === document.path)
      if (item !== undefined) cache.set(item.key, document)
      results.set(document.path, document)
    }
  }

  return pdfs.map(file => results.get(file.relative) ?? {
    path: file.relative, kind: 'unknown', pages: 0, sampledPages: 0, textCharacters: 0,
  })
}
