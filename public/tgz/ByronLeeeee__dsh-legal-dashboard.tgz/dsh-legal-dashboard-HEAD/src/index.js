import path from 'node:path'
import { mkdir, readFile, writeFile } from 'node:fs/promises'
import z from '@deepseek-ai/schemastery'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { settingsNamespace } from '@deepseek-ai/dsh-settings'
import { legalCaseDashboard, projectOverview, searchProject } from './project-scan.js'
import { readWorkspaceFile, resolveWorkspaceFile, workspaceTree } from './workspace-files.js'
import { resolveWorkspaceOutput, runDocumentOperation } from './document-runtime.js'
import { buildDocumentIndex, searchDocumentIndex } from './document-index.js'
import { formatOcrMarkdown, recognizePages } from './ocr-provider.js'
import { classifyWorkspacePdfs } from './pdf-classifier.js'
import { analyzeWorkspaceMatter, MATTER_TYPES } from './matter-profile.js'
import { freshOcrResult, ocrStatusForDocuments, recordOcrResult } from './ocr-manifest.js'

export const name = 'legal-office'
export const inject = ['systemPrompt', 'tools']
const SETTINGS_NAMESPACE = settingsNamespace('legal-office')

const DEFAULT_QUICK_ACTIONS = Object.freeze([
  { label: '案件梳理', prompt: '梳理当前案件目录中的全部材料，区分已确认事实、当事人陈述、推断和待核实事项，列出争议焦点与下一步工作。' },
  { label: '材料缺口', prompt: '审查当前案件材料完整性，按主体身份、事实依据、请求依据、程序材料和授权手续列出缺失材料，并标注优先级。' },
  { label: '证据目录', prompt: '基于当前案件材料编制证据目录，逐项注明证据名称、来源文件和证明目的，输出为 工作成果/证据目录.docx。' },
  { label: '文书起草', prompt: '基于当前案件材料判断应当优先起草的法律文书；信息不足时先列出待确认问题，信息充分时输出为 工作成果/文书初稿.docx。' },
  { label: '期限核查', prompt: '核查当前案件材料中的程序期限候选，逐项说明原始文件位置、日期依据、待核事项和风险，不得把自动识别日期直接视为法定期限。' },
  { label: 'OCR 扫描件', prompt: '识别当前案件中无法提取文本的扫描 PDF 或图片，执行 OCR 并将校对结果按原文件名保存到 工作成果/OCR。' },
])

export const Config = z.object({
  maxFiles: z.number().min(1).step(1).default(5000),
  maxSearchFileBytes: z.number().min(1).step(1).default(2 * 1024 * 1024),
  defaultMaxResults: z.number().min(1).max(200).step(1).default(50),
  pythonExecutable: z.string().default('auto'),
  excludedDirectories: z.array(z.string()).default(['.git', '.svn', 'node_modules', '.legal-index', '.legal-ocr']),
  matterType: z.string().default('auto'),
  ocrBaseURL: z.string().default(''),
  ocrModel: z.string().default(''),
  ocrApiKeyEnv: z.string().role('credential-ref').default('DSH_LEGAL_OCR_API_KEY'),
  ocrMaxPages: z.number().min(1).max(100).step(1).default(30),
  ocrMaxTokens: z.number().min(1).max(32768).step(1).default(4096),
  ocrTimeoutMs: z.number().min(1000).max(600000).step(1000).default(120000),
  quickActions: z.array(z.object({
    label: z.string(),
    prompt: z.string(),
  })).default(DEFAULT_QUICK_ACTIONS),
})

const LEGAL_PERSONA = `You are a legal-office agent assisting a legal professional with the current folder-based project.

Treat the current workspace directory as the boundary of the current matter or legal project. Do not mix facts, parties, documents, or conclusions from another workspace.

Separate confirmed facts, user assertions, inferences, and unresolved questions. Mark unsupported material facts as "待核实". When relying on a project document, identify the file and a line, page, sheet, or other locator when available. Never invent a statute, case, quotation, citation, filing status, deadline, or document content.

Analysis and drafts are working products, not final legal advice or a filed document. Before overwriting an existing document, sending material externally, filing, signing, deleting, or changing an official deadline, obtain explicit user approval through the available approval mechanism.`

function projectRoot(exec) {
  const root = exec.agent?.session?.header?.cwd
  if (typeof root !== 'string' || root.length === 0) {
    throw new Error('This tool requires a session attached to a folder workspace.')
  }
  return root
}

function scanOptions(config) {
  return {
    maxFiles: config.maxFiles,
    maxFileBytes: config.maxSearchFileBytes,
    excludedDirectories: config.excludedDirectories,
  }
}

async function jsonBody(req) {
  const chunks = []
  let bytes = 0
  for await (const chunk of req) {
    bytes += chunk.length
    if (bytes > 256 * 1024) throw new Error('request body is too large')
    chunks.push(chunk)
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'))
}

function validateWorkbenchConfig(value) {
  if (!Array.isArray(value.quickActions) || value.quickActions.length > 20) throw new Error('quickActions must contain at most 20 items')
  const quickActions = value.quickActions.map((item) => {
    const label = String(item?.label ?? '').trim()
    const prompt = String(item?.prompt ?? '').trim()
    if (label.length < 1 || label.length > 30) throw new Error('quick action label must contain 1 through 30 characters')
    if (prompt.length < 1 || prompt.length > 4000) throw new Error('quick action prompt must contain 1 through 4000 characters')
    return { label, prompt }
  })
  const ocrBaseURL = String(value.ocrBaseURL ?? '').trim()
  const ocrModel = String(value.ocrModel ?? '').trim()
  if (ocrBaseURL.length > 1000 || ocrModel.length > 200) throw new Error('OCR provider setting is too long')
  if (ocrBaseURL !== '') {
    const url = new URL(ocrBaseURL)
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('ocrBaseURL must use http or https')
  }
  const matterType = String(value.matterType ?? 'auto')
  if (!MATTER_TYPES.includes(matterType)) throw new Error('unknown matterType')
  const integer = (candidate, min, max, name) => {
    if (!Number.isInteger(candidate) || candidate < min || candidate > max) throw new Error(`${name} is outside the allowed range`)
    return candidate
  }
  return {
    quickActions,
    matterType,
    ocrBaseURL,
    ocrModel,
    ocrApiKeyEnv: 'DSH_LEGAL_OCR_API_KEY',
    ocrMaxPages: integer(value.ocrMaxPages, 1, 100, 'ocrMaxPages'),
    ocrMaxTokens: integer(value.ocrMaxTokens, 1, 32768, 'ocrMaxTokens'),
    ocrTimeoutMs: integer(value.ocrTimeoutMs, 1000, 600000, 'ocrTimeoutMs'),
  }
}

export function apply(ctx, config) {
  let configSource = () => config
  let settingsScope
  ctx.inject(['settings'], (settingsCtx) => {
    const scope = settingsCtx.settings.register(SETTINGS_NAMESPACE, Config, { base: config })
    configSource = () => scope.get()
    settingsScope = scope
    settingsCtx.effect(() => () => {
      configSource = () => config
      settingsScope = undefined
    }, 'legal-office: settings source')
  })
  ctx.systemPrompt.section({
    name: 'legal-office:persona',
    order: 10,
    text: LEGAL_PERSONA,
  })
  ctx.systemPrompt.section({
    name: 'legal-office:ocr', order: 11,
    text: `Before substantive work on an unfamiliar matter, call legal_case_dashboard. It reports the configured or recommended matter type, an evidence-backed dynamic checklist, PDF text/scanned/mixed classification, and OCR cache status. Treat scanned and mixed PDFs with ocr="missing" as OCR candidates when their content is needed. legal_ocr_run first reuses a fresh prior OCR result when available; only a missing or stale result is sent to the separately configured multimodal provider, with explicit approval. Continue the original task by reading the returned OCR Markdown path. Quick actions never force OCR.`,
  })
  ctx.systemPrompt.context({
    name: 'legal-office:workspace',
    order: 10,
    text: (assembly) => {
      const cwd = assembly.agent?.session?.header?.cwd
      if (typeof cwd !== 'string' || cwd.length === 0) {
        return 'Legal project context: no folder workspace is attached to this session.'
      }
      return `Legal project context:\n- Project: ${path.basename(cwd)}\n- Workspace root: ${cwd}\n- File scope: this workspace only`
    },
  })

  ctx.tools.register(defineTool({
    name: 'legal_project_overview',
    description: 'Inspect the current legal project folder and return file counts, types, size, and recently modified files. Use before beginning work on an unfamiliar project.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(_args, exec) {
      const overview = await projectOverview(projectRoot(exec), scanOptions(config))
      return JSON.stringify(overview, null, 2)
    },
    presentCall: () => ({ card: 'generic', title: 'Inspect legal project', kind: 'search' }),
  }))

  ctx.on('tools/pre-execute', async (exec, next) => {
    if (exec.name !== 'legal_ocr_run') return next()
    const active = configSource()
    if (active.ocrBaseURL?.trim() === '' || active.ocrModel?.trim() === '') return next()
    const args = exec.arguments
    if (args && typeof args === 'object' && typeof args.inputPath === 'string') {
      const cached = await freshOcrResult(projectRoot(exec), args.inputPath).catch(() => undefined)
      if (cached !== undefined) return next()
    }
    return { kind: 'ask', reason: 'OCR 将把所选案件材料页面发送到已配置的外部多模态模型，是否允许本次传输？' }
  })

  ctx.tools.register(defineTool({
      name: 'legal_ocr_run',
      description: 'OCR an image or scanned PDF through the separately configured OpenAI-compatible multimodal provider and save page-preserving Markdown. This uploads rendered pages to that external provider and therefore always requires explicit user approval.',
      parameters: {
        inputPath: { type: 'string', required: true, description: 'Workspace-relative PDF, PNG, JPEG, GIF, or WebP path.' },
        outputPath: { type: 'string', required: true, description: 'New workspace-relative .md or .txt output path.' },
        maxPages: { type: 'integer', description: 'Maximum pages to OCR, from 1 through 100. Defaults to the plugin setting.' },
      },
      output: {
        schema: { type: 'string' },
        render: (_args, value) => [{ type: 'text', text: value }],
      },
      async execute(args, exec) {
        const active = configSource()
        const root = projectRoot(exec)
        const cached = await freshOcrResult(root, args.inputPath)
        if (cached !== undefined) return JSON.stringify({
          inputPath: args.inputPath, outputPath: cached.outputPath, pages: cached.pages,
          reused: true, provider: cached.provider,
        }, null, 2)
        if (active.ocrBaseURL?.trim() === '' || active.ocrModel?.trim() === '') throw new Error('OCR provider is not configured; open 案件工作台 → 配置')
        const maxPages = args.maxPages ?? active.ocrMaxPages
        if (!Number.isInteger(maxPages) || maxPages < 1 || maxPages > 100) throw new Error('maxPages must be an integer from 1 through 100')
        const input = await resolveWorkspaceFile(root, args.inputPath)
        const extension = path.extname(input.absolute).toLowerCase()
        if (!['.pdf', '.png', '.jpg', '.jpeg', '.gif', '.webp'].includes(extension)) throw new Error('unsupported OCR input type')
        const output = await resolveWorkspaceOutput(root, args.outputPath, ['.md', '.txt'])
        const safeStem = path.basename(input.absolute, extension).replace(/[^\p{L}\p{N}._-]+/gu, '-').slice(0, 80) || 'document'
        const outputDir = path.join(root, '.legal-ocr', safeStem)
        await mkdir(outputDir, { recursive: true })
        const prepared = await runDocumentOperation(active.pythonExecutable, {
          operation: 'prepare_ocr', input: input.absolute, outputDir, maxPages,
        })
        const pages = await Promise.all(prepared.pages.map(async pagePath => ({ bytes: await readFile(pagePath), mimeType: 'image/png' })))
        const credential = await ctx.get('credentials')?.resolve(active.ocrApiKeyEnv)
        const apiKey = credential?.value ?? process.env[active.ocrApiKeyEnv]
        const recognized = await recognizePages({
          baseURL: active.ocrBaseURL,
          model: active.ocrModel,
          apiKey,
          pages,
          maxTokens: active.ocrMaxTokens,
          timeoutMs: active.ocrTimeoutMs,
          signal: exec.signal,
        })
        const markdown = formatOcrMarkdown(recognized, { sourcePath: args.inputPath, truncated: prepared.truncated })
        await writeFile(output, markdown, { encoding: 'utf8', flag: 'wx' })
        const outputPath = path.relative(root, output).split(path.sep).join('/')
        const provider = { baseURL: active.ocrBaseURL, model: active.ocrModel }
        await recordOcrResult(root, args.inputPath, { outputPath, pages: recognized.length, provider })
        return JSON.stringify({
          inputPath: args.inputPath,
          outputPath,
          pages: recognized.length,
          truncated: prepared.truncated,
          reused: false,
          provider,
        }, null, 2)
      },
      presentCall: args => ({ card: 'generic', title: `OCR document: ${args.inputPath}`, kind: 'write' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_ocr_prepare',
    description: 'Prepare an image or scanned PDF for multimodal OCR by rendering it into ordered PNG pages inside the current matter. After this call, inspect every returned page with the image-reading tool and save the faithful transcription with legal_ocr_save.',
    parameters: {
      inputPath: { type: 'string', required: true, description: 'Workspace-relative PDF, PNG, JPEG, GIF, or WebP path.' },
      maxPages: { type: 'integer', description: 'Maximum PDF pages to render, from 1 through 100. Defaults to 30.' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      if (args.maxPages !== undefined && (!Number.isInteger(args.maxPages) || args.maxPages < 1 || args.maxPages > 100)) {
        throw new Error('maxPages must be an integer from 1 through 100')
      }
      const root = projectRoot(exec)
      const input = await resolveWorkspaceFile(root, args.inputPath)
      const extension = path.extname(input.absolute).toLowerCase()
      if (!['.pdf', '.png', '.jpg', '.jpeg', '.gif', '.webp'].includes(extension)) throw new Error('unsupported OCR input type')
      const safeStem = path.basename(input.absolute, extension).replace(/[^\p{L}\p{N}._-]+/gu, '-').slice(0, 80) || 'document'
      const outputDir = path.join(root, '.legal-ocr', safeStem)
      await mkdir(outputDir, { recursive: true })
      const result = await runDocumentOperation(config.pythonExecutable, {
        operation: 'prepare_ocr', input: input.absolute, outputDir, maxPages: args.maxPages ?? 30,
      })
      return JSON.stringify({
        ...result, inputPath: args.inputPath,
        pages: result.pages.map(item => path.relative(root, item).split(path.sep).join('/')),
      }, null, 2)
    },
    presentCall: args => ({ card: 'generic', title: `Prepare OCR: ${args.inputPath}`, kind: 'read' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_ocr_save',
    description: 'Save a reviewed multimodal OCR transcription as UTF-8 Markdown in the current matter. Preserve page headings and use [无法辨认] for illegible text.',
    parameters: {
      outputPath: { type: 'string', required: true, description: 'Workspace-relative .md or .txt path.' },
      text: { type: 'string', required: true, description: 'Complete reviewed OCR transcription.' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      const root = projectRoot(exec)
      const output = await resolveWorkspaceOutput(root, args.outputPath, ['.md', '.txt'])
      await writeFile(output, args.text, { encoding: 'utf8', flag: 'wx' })
      return JSON.stringify({ outputPath: path.relative(root, output).split(path.sep).join('/'), characters: args.text.length }, null, 2)
    },
    presentCall: args => ({ card: 'generic', title: `Save OCR: ${args.outputPath}`, kind: 'write' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_document_create',
    description: 'Create a professionally formatted Chinese legal-office DOCX or PDF in the current matter. Content accepts plain text and simple Markdown headings/lists. Use a new project-relative output path; never overwrite an existing file without explicit approval.',
    parameters: {
      outputPath: { type: 'string', required: true, description: 'New workspace-relative .docx or .pdf path.' },
      title: { type: 'string', required: true, description: 'Document title.' },
      content: { type: 'string', required: true, description: 'Complete document body in plain text or simple Markdown.' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      const root = projectRoot(exec)
      const extension = path.extname(args.outputPath).toLowerCase()
      const format = extension === '.docx' ? 'docx' : extension === '.pdf' ? 'pdf' : undefined
      if (format === undefined) throw new Error('outputPath must end with .docx or .pdf')
      const output = await resolveWorkspaceOutput(root, args.outputPath, ['.docx', '.pdf'])
      const result = await runDocumentOperation(config.pythonExecutable, {
        operation: 'create', format, output, title: args.title, content: args.content,
      })
      return JSON.stringify({ ...result, outputPath: path.relative(root, output).split(path.sep).join('/') }, null, 2)
    },
    presentCall: args => ({ card: 'generic', title: `Create document: ${args.outputPath}`, kind: 'write' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_document_extract',
    description: 'Extract searchable text from a DOCX or text-based PDF inside the current matter. Scanned documents may return little text and should then be sent to the OCR workflow.',
    parameters: {
      inputPath: { type: 'string', required: true, description: 'Workspace-relative .docx or .pdf path.' },
      maxCharacters: { type: 'integer', description: 'Maximum returned characters. Defaults to 100000.' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      if (args.maxCharacters !== undefined && (!Number.isInteger(args.maxCharacters) || args.maxCharacters < 1 || args.maxCharacters > 500000)) {
        throw new Error('maxCharacters must be an integer from 1 through 500000')
      }
      const root = projectRoot(exec)
      const input = await resolveWorkspaceFile(root, args.inputPath)
      if (!['.docx', '.pdf'].includes(path.extname(input.absolute).toLowerCase())) throw new Error('inputPath must end with .docx or .pdf')
      const result = await runDocumentOperation(config.pythonExecutable, {
        operation: 'extract', input: input.absolute, maxCharacters: args.maxCharacters ?? 100000,
      })
      return JSON.stringify({ ...result, inputPath: args.inputPath }, null, 2)
    },
    presentCall: args => ({ card: 'generic', title: `Read document: ${args.inputPath}`, kind: 'read' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_document_edit',
    description: 'Create a revised DOCX by applying exact text replacements to an existing DOCX. The output must be a different workspace-relative path so the source remains recoverable.',
    parameters: {
      inputPath: { type: 'string', required: true, description: 'Existing workspace-relative .docx path.' },
      outputPath: { type: 'string', required: true, description: 'Different workspace-relative .docx path for the revision.' },
      replacements: {
        type: 'array', required: true, description: 'Exact text replacements.',
        items: {
          type: 'object', additionalProperties: false,
          properties: {
            find: { type: 'string', required: true },
            replace: { type: 'string', required: true },
          },
        },
      },
      requireAll: { type: 'boolean', description: 'Fail without writing if any search text is absent. Defaults to true.' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      if (args.replacements.length === 0) throw new Error('replacements must not be empty')
      const root = projectRoot(exec)
      const input = await resolveWorkspaceFile(root, args.inputPath)
      const output = await resolveWorkspaceOutput(root, args.outputPath, ['.docx'])
      if (path.extname(input.absolute).toLowerCase() !== '.docx') throw new Error('inputPath must end with .docx')
      if (input.absolute.toLowerCase() === output.toLowerCase()) throw new Error('outputPath must differ from inputPath')
      const result = await runDocumentOperation(config.pythonExecutable, {
        operation: 'edit', input: input.absolute, output,
        replacements: args.replacements, requireAll: args.requireAll ?? true,
      })
      return JSON.stringify({ ...result, inputPath: args.inputPath, outputPath: args.outputPath }, null, 2)
    },
    presentCall: args => ({ card: 'generic', title: `Revise document: ${args.outputPath}`, kind: 'write' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_project_search',
    description: 'Search filenames and supported plain-text files inside the current legal project. Results include project-relative paths and line locations. For DOCX and PDF contents, use legal_index_build followed by legal_index_search.',
    parameters: {
      query: { type: 'string', required: true, description: 'Exact text or filename fragment to find.' },
      maxResults: { type: 'integer', description: 'Maximum matches to return, from 1 through 200.' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      if (args.maxResults !== undefined && (!Number.isInteger(args.maxResults) || args.maxResults < 1 || args.maxResults > 200)) {
        throw new Error('maxResults must be an integer from 1 through 200')
      }
      const result = await searchProject(projectRoot(exec), args.query, {
        ...scanOptions(config),
        maxResults: args.maxResults ?? config.defaultMaxResults,
      })
      return JSON.stringify(result, null, 2)
    },
    presentCall: args => ({ card: 'generic', title: `Search project: ${args.query}`, kind: 'search' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_index_build',
    description: 'Create or incrementally refresh the private full-text index for DOCX and text-based PDF files in the current matter. Scanned PDFs should be OCRed first. Unchanged documents reuse cached extraction.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(_args, exec) {
      const root = projectRoot(exec)
      return JSON.stringify(await buildDocumentIndex(root, {
        ...scanOptions(config), pythonExecutable: config.pythonExecutable,
      }), null, 2)
    },
    presentCall: () => ({ card: 'generic', title: 'Index case documents', kind: 'search' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_index_search',
    description: 'Search the extracted DOCX and PDF content index for the current matter and return document-relative line locations and snippets.',
    parameters: {
      query: { type: 'string', required: true, description: 'Exact text to find.' },
      maxResults: { type: 'integer', description: 'Maximum matches, from 1 through 200. Defaults to 50.' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args, exec) {
      const maxResults = args.maxResults ?? 50
      if (!Number.isInteger(maxResults) || maxResults < 1 || maxResults > 200) throw new Error('maxResults must be an integer from 1 through 200')
      return JSON.stringify(await searchDocumentIndex(projectRoot(exec), args.query, maxResults), null, 2)
    },
    presentCall: args => ({ card: 'generic', title: `Search documents: ${args.query}`, kind: 'search' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_case_dashboard',
    description: 'Build a structured case dashboard for the current workspace, including preliminary text/scanned/mixed PDF classification, legal-document categories, missing material groups, and date candidates.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(_args, exec) {
      const active = configSource()
      const root = projectRoot(exec)
      const [dashboard, classifiedPdfs] = await Promise.all([
        legalCaseDashboard(root, scanOptions(active)),
        classifyWorkspacePdfs(root, { ...scanOptions(active), pythonExecutable: active.pythonExecutable }),
      ])
      const [pdfDocuments, matter] = await Promise.all([
        ocrStatusForDocuments(root, classifiedPdfs),
        analyzeWorkspaceMatter(root, { ...scanOptions(active), pythonExecutable: active.pythonExecutable, matterType: active.matterType }, classifiedPdfs),
      ])
      return JSON.stringify({ ...dashboard, matter, checklist: matter.checklist, pdfDocuments }, null, 2)
    },
    presentCall: () => ({ card: 'generic', title: 'Build case dashboard', kind: 'search' }),
  }))

  ctx.tools.register(defineTool({
    name: 'legal_deadline_scan',
    description: 'Scan the current matter for date strings near procedural deadline keywords. Every result is only a candidate and must be verified against the original document and applicable rules.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(_args, exec) {
      const dashboard = await legalCaseDashboard(projectRoot(exec), scanOptions(config))
      return JSON.stringify({ disclaimer: dashboard.disclaimer, deadlines: dashboard.deadlines }, null, 2)
    },
    presentCall: () => ({ card: 'generic', title: 'Scan deadline candidates', kind: 'search' }),
  }))

  ctx.inject(['webServer', 'workspaceRegistry'], (webCtx) => {
    const workspaceFor = (requestUrl) => {
      const workspaceId = requestUrl.searchParams.get('workspaceId')
      return workspaceId === null
        ? undefined
        : webCtx.workspaceRegistry.list().find(item => String(item.id) === workspaceId)
    }
    const publicConfig = async () => {
      const active = configSource()
      const credentialInfo = await webCtx.get('credentials')?.describe(active.ocrApiKeyEnv)
      return {
        quickActions: active.quickActions ?? DEFAULT_QUICK_ACTIONS,
        matterType: active.matterType ?? 'auto',
        ocrBaseURL: active.ocrBaseURL ?? '',
        ocrModel: active.ocrModel ?? '',
        ocrMaxPages: active.ocrMaxPages ?? 30,
        ocrMaxTokens: active.ocrMaxTokens ?? 4096,
        ocrTimeoutMs: active.ocrTimeoutMs ?? 120000,
        ocrCredential: credentialInfo ?? { configured: false, writable: false },
      }
    }

    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: '/api/legal-office/config',
      handler: async (req, res) => {
        try {
          if (req.method === 'GET') {
            res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
            res.end(JSON.stringify(await publicConfig()))
            return
          }
          if (req.method !== 'POST') { res.writeHead(405, { Allow: 'GET, POST' }); res.end(); return }
          if (settingsScope === undefined) throw new Error('settings service is unavailable')
          const body = await jsonBody(req)
          const patch = validateWorkbenchConfig(body)
          await settingsScope.update(patch)
          const credentials = webCtx.get('credentials')
          if (body.clearApiKey === true) {
            if (credentials === undefined) throw new Error('credentials service is unavailable')
            await credentials.unset(patch.ocrApiKeyEnv)
          } else if (typeof body.apiKey === 'string' && body.apiKey.trim() !== '') {
            if (credentials === undefined) throw new Error('credentials service is unavailable')
            await credentials.set(patch.ocrApiKeyEnv, body.apiKey.trim())
          }
          res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
          res.end(JSON.stringify(await publicConfig()))
        } catch (error) {
          res.writeHead(400, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
          res.end(JSON.stringify({ error: error instanceof Error ? error.message : String(error) }))
        }
      },
    }), 'legal-office: config route')

    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: '/api/legal-office/dashboard',
      handler: async (req, res) => {
      if (req.method !== 'GET') {
        res.writeHead(405, { Allow: 'GET' })
        res.end()
        return
      }
      const requestUrl = new URL(req.url ?? '/', 'http://127.0.0.1')
        const workspace = workspaceFor(requestUrl)
      if (workspace === undefined) {
        res.writeHead(404, { 'Content-Type': 'application/json; charset=utf-8' })
        res.end(JSON.stringify({ error: 'unknown workspace' }))
        return
      }
        const active = configSource()
        const [dashboard, classifiedPdfs] = await Promise.all([
          legalCaseDashboard(workspace.path, scanOptions(active)),
          classifyWorkspacePdfs(workspace.path, { ...scanOptions(active), pythonExecutable: active.pythonExecutable }),
        ])
        const [pdfDocuments, matter] = await Promise.all([
          ocrStatusForDocuments(workspace.path, classifiedPdfs),
          analyzeWorkspaceMatter(workspace.path, { ...scanOptions(active), pythonExecutable: active.pythonExecutable, matterType: active.matterType }, classifiedPdfs),
        ])
        res.writeHead(200, {
          'Content-Type': 'application/json; charset=utf-8',
          'Cache-Control': 'no-store',
        })
        res.end(JSON.stringify({
          ...dashboard,
          matter,
          checklist: matter.checklist,
          pdfDocuments,
          quickActions: active.quickActions ?? DEFAULT_QUICK_ACTIONS,
          ocrProvider: {
            configured: active.ocrBaseURL?.trim() !== '' && active.ocrModel?.trim() !== '',
            model: active.ocrModel?.trim() !== '' ? active.ocrModel : undefined,
          },
        }))
      },
    }), 'legal-office: dashboard route')

    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: '/api/legal-office/tree',
      handler: async (req, res) => {
        if (req.method !== 'GET') { res.writeHead(405, { Allow: 'GET' }); res.end(); return }
        const requestUrl = new URL(req.url ?? '/', 'http://127.0.0.1')
        const workspace = workspaceFor(requestUrl)
        if (workspace === undefined) { res.writeHead(404); res.end(); return }
        const tree = await workspaceTree(workspace.path, {
          maxEntries: config.maxFiles,
          excludedDirectories: config.excludedDirectories,
        })
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' })
        res.end(JSON.stringify(tree))
      },
    }), 'legal-office: tree route')

    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: '/api/legal-office/file',
      handler: async (req, res) => {
        if (req.method !== 'GET') { res.writeHead(405, { Allow: 'GET' }); res.end(); return }
        const requestUrl = new URL(req.url ?? '/', 'http://127.0.0.1')
        const workspace = workspaceFor(requestUrl)
        const relativePath = requestUrl.searchParams.get('path')
        if (workspace === undefined || relativePath === null) { res.writeHead(404); res.end(); return }
        try {
          const file = await readWorkspaceFile(workspace.path, relativePath)
          res.writeHead(200, {
            'Content-Type': file.mime,
            'Content-Length': String(file.size),
            'Content-Disposition': 'inline',
            'Cache-Control': 'no-store',
            'X-Content-Type-Options': 'nosniff',
          })
          res.end(file.bytes)
        } catch {
          res.writeHead(404)
          res.end()
        }
      },
    }), 'legal-office: file route')

    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: '/api/legal-office/extract',
      handler: async (req, res) => {
        if (req.method !== 'GET') { res.writeHead(405, { Allow: 'GET' }); res.end(); return }
        const requestUrl = new URL(req.url ?? '/', 'http://127.0.0.1')
        const workspace = workspaceFor(requestUrl)
        const relativePath = requestUrl.searchParams.get('path')
        if (workspace === undefined || relativePath === null) { res.writeHead(404); res.end(); return }
        try {
          const input = await resolveWorkspaceFile(workspace.path, relativePath)
          if (path.extname(input.absolute).toLowerCase() !== '.docx') throw new Error('unsupported preview')
          const result = await runDocumentOperation(config.pythonExecutable, {
            operation: 'extract', input: input.absolute, maxCharacters: 250000,
          })
          res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' })
          res.end(result.text)
        } catch {
          res.writeHead(404)
          res.end()
        }
      },
    }), 'legal-office: document preview route')
  })
}
