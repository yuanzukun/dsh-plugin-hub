const OCR_SYSTEM_PROMPT = `You are a document OCR engine for Chinese legal work.
Transcribe every visible character faithfully in reading order. Preserve headings, paragraphs, lists, tables, stamps, signatures, handwritten notes, page numbers, and form fields when visible. Do not summarize, translate, correct, or infer missing text. Mark illegible content as [无法辨认]. Return Markdown only.`

function endpointOf(baseURL) {
  if (typeof baseURL !== 'string' || baseURL.trim() === '') throw new Error('OCR provider baseURL is not configured')
  const value = baseURL.trim().replace(/\/+$/u, '')
  const url = new URL(value)
  if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('OCR provider baseURL must use http or https')
  return value.endsWith('/chat/completions') ? value : `${value}/chat/completions`
}

function messageText(payload) {
  const content = payload?.choices?.[0]?.message?.content
  if (typeof content === 'string' && content.trim() !== '') return content.trim()
  if (Array.isArray(content)) {
    const text = content.map(item => typeof item?.text === 'string' ? item.text : '').join('\n').trim()
    if (text !== '') return text
  }
  throw new Error('OCR provider returned no text content')
}

function requestSignal(parent, timeoutMs) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(new Error('OCR provider request timed out')), timeoutMs)
  const abort = () => controller.abort(parent?.reason)
  parent?.addEventListener('abort', abort, { once: true })
  return {
    signal: controller.signal,
    dispose() { clearTimeout(timer); parent?.removeEventListener('abort', abort) },
  }
}

export async function recognizePage(options) {
  const endpoint = endpointOf(options.baseURL)
  if (typeof options.model !== 'string' || options.model.trim() === '') throw new Error('OCR provider model is not configured')
  const controlled = requestSignal(options.signal, options.timeoutMs ?? 120000)
  try {
    const headers = { 'Content-Type': 'application/json' }
    if (typeof options.apiKey === 'string' && options.apiKey !== '') headers.Authorization = `Bearer ${options.apiKey}`
    const response = await (options.fetchImpl ?? fetch)(endpoint, {
      method: 'POST',
      headers,
      signal: controlled.signal,
      body: JSON.stringify({
        model: options.model.trim(),
        temperature: 0,
        max_tokens: options.maxTokens ?? 4096,
        messages: [
          { role: 'system', content: OCR_SYSTEM_PROMPT },
          {
            role: 'user',
            content: [
              { type: 'text', text: `Transcribe page ${options.pageNumber}. Return only the page transcription.` },
              { type: 'image_url', image_url: { url: `data:${options.mimeType ?? 'image/png'};base64,${options.bytes.toString('base64')}`, detail: 'high' } },
            ],
          },
        ],
      }),
    })
    if (!response.ok) {
      const detail = (await response.text()).slice(0, 1000)
      throw new Error(`OCR provider request failed (${response.status}): ${detail || response.statusText}`)
    }
    return messageText(await response.json())
  } finally {
    controlled.dispose()
  }
}

export async function recognizePages(options) {
  const results = []
  for (let index = 0; index < options.pages.length; index += 1) {
    results.push(await recognizePage({ ...options, ...options.pages[index], pageNumber: index + 1 }))
  }
  return results
}

export function formatOcrMarkdown(pages, metadata = {}) {
  const heading = metadata.sourcePath === undefined ? [] : [`# ${metadata.sourcePath}`, '']
  const body = pages.flatMap((text, index) => [`## 第 ${index + 1} 页`, '', text.trim(), ''])
  if (metadata.truncated === true) body.push('> 文档页数超过本次 OCR 上限，结果未包含全部页面。', '')
  return [...heading, ...body].join('\n').trimEnd() + '\n'
}
