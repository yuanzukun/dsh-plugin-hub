import { mkdir, readFile, rename, stat, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { resolveWorkspaceFile } from './workspace-files.js'

const MANIFEST = path.join('.legal-ocr', 'manifest.json')

async function readManifest(root) {
  try {
    const value = JSON.parse(await readFile(path.join(root, MANIFEST), 'utf8'))
    return value?.version === 1 && value.entries && typeof value.entries === 'object' ? value : { version: 1, entries: {} }
  } catch {
    return { version: 1, entries: {} }
  }
}

async function signature(root, inputPath) {
  const source = await resolveWorkspaceFile(root, inputPath)
  return { source, size: source.info.size, modifiedAtMs: source.info.mtimeMs }
}

export async function freshOcrResult(root, inputPath) {
  const current = await signature(root, inputPath)
  const manifest = await readManifest(root)
  const entry = manifest.entries[inputPath]
  if (entry?.size !== current.size || entry?.modifiedAtMs !== current.modifiedAtMs || typeof entry.outputPath !== 'string') return undefined
  try {
    const output = await resolveWorkspaceFile(root, entry.outputPath)
    await stat(output.absolute)
    return { ...entry, source: current.source }
  } catch {
    return undefined
  }
}

export async function recordOcrResult(root, inputPath, value) {
  const current = await signature(root, inputPath)
  const manifest = await readManifest(root)
  manifest.entries[inputPath] = {
    size: current.size,
    modifiedAtMs: current.modifiedAtMs,
    outputPath: value.outputPath,
    pages: value.pages,
    provider: value.provider,
    completedAt: new Date().toISOString(),
  }
  const directory = path.join(root, '.legal-ocr')
  await mkdir(directory, { recursive: true })
  const temporary = path.join(directory, `manifest-${process.pid}.tmp`)
  await writeFile(temporary, JSON.stringify(manifest, null, 2), 'utf8')
  await rename(temporary, path.join(root, MANIFEST))
}

export async function ocrStatusForDocuments(root, documents) {
  return Promise.all(documents.map(async document => {
    const fresh = await freshOcrResult(root, document.path).catch(() => undefined)
    return { ...document, ocr: fresh === undefined ? 'missing' : 'current', ocrOutputPath: fresh?.outputPath }
  }))
}
