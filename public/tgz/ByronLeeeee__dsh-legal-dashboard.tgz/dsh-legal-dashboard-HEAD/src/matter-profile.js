import { readFile } from 'node:fs/promises'
import { walkProject, DEFAULT_TEXT_EXTENSIONS } from './project-scan.js'
import { runDocumentOperation } from './document-runtime.js'

export const MATTER_TYPES = Object.freeze([
  'auto', 'general', 'litigation', 'arbitration', 'criminal', 'administrative',
  'complaint', 'contract-review', 'due-diligence', 'advisory', 'non-litigation',
])

export const MATTER_TYPE_LABELS = Object.freeze({
  auto: '自动识别', general: '通用法律事项', litigation: '民商事诉讼', arbitration: '仲裁',
  criminal: '刑事', administrative: '行政', 'contract-review': '合同审查',
  complaint: '投诉举报',
  'due-diligence': '尽职调查', advisory: '法律顾问', 'non-litigation': '专项非诉',
})

const TYPE_RULES = Object.freeze([
  ['litigation', /起诉|答辩|法院|案号|原告|被告|上诉|判决|裁定|开庭|举证/u],
  ['arbitration', /仲裁|仲裁委|仲裁庭|仲裁申请|仲裁答辩/u],
  ['criminal', /刑事|公安|检察院|犯罪嫌疑人|被告人|辩护|取保候审|拘留|逮捕/u],
  ['administrative', /行政复议|行政诉讼|行政处罚|行政机关|听证|政府信息公开/u],
  ['complaint', /投诉|举报|12345|市场监督|消费者协会|消协|被举报人/u],
  ['due-diligence', /尽职调查|尽调|数据室|权属核查|合规核查|风险清单/u],
  ['contract-review', /合同审查|协议审查|条款修改|修订稿|交易合同|合同风险/u],
  ['advisory', /常年法律顾问|法律咨询|咨询意见|法律意见|顾问单位/u],
  ['non-litigation', /专项法律服务|非诉|交易结构|谈判|交割|备案|股权激励|公司治理/u],
])

const BASE_CHECKLIST = Object.freeze([
  ['identity', '委托人与相关主体材料', /身份证|营业执照|统一社会信用代码|主体资格|法定代表人/u],
  ['authorization', '委托、授权与利益冲突材料', /委托代理|授权委托|法律服务合同|聘用律师|利益冲突/u],
  ['background', '事项背景与事实材料', /情况说明|事实经过|事项背景|案情|时间线|会议纪要|访谈记录/u],
  ['communications', '关键往来与沟通记录', /聊天记录|邮件|函件|通知|沟通记录|会议纪要|催告/u],
])

const TYPE_CHECKLISTS = Object.freeze({
  general: [
    ['request', '工作目标与具体需求', /工作目标|委托事项|法律问题|咨询事项|工作范围/u],
    ['deliverable', '分析、意见或交付成果', /法律意见|分析报告|工作报告|审查意见|交付稿/u],
  ],
  litigation: [
    ['claims', '诉讼请求、答辩意见或代理方案', /诉讼请求|民事起诉状|答辩状|代理方案|代理词/u],
    ['evidence', '证据材料与证明目的', /证据目录|证明目的|证据材料|质证意见/u],
    ['procedure', '法院程序、送达与期限材料', /法院|传票|送达|开庭|举证期限|裁定|判决/u],
  ],
  arbitration: [
    ['claims', '仲裁请求、答辩意见或代理方案', /仲裁请求|仲裁申请书|仲裁答辩|代理方案/u],
    ['evidence', '证据材料与证明目的', /证据目录|证明目的|质证意见/u],
    ['procedure', '仲裁程序、组庭与期限材料', /仲裁委|仲裁庭|组庭|开庭|送达|期限/u],
  ],
  criminal: [
    ['stage', '案件阶段与强制措施材料', /侦查|审查起诉|一审|二审|拘留|逮捕|取保候审/u],
    ['accusation', '指控、证据与辩护材料', /起诉书|指控|证据卷|辩护意见|辩护词/u],
    ['meeting', '会见、阅卷与办案记录', /会见笔录|阅卷笔录|办案记录/u],
  ],
  administrative: [
    ['act', '行政行为及依据材料', /行政处罚|行政决定|行政许可|行政行为|执法依据/u],
    ['remedy', '复议、诉讼或听证请求材料', /行政复议|行政诉讼|听证|申请书/u],
    ['procedure', '送达、期限与程序材料', /送达|期限|告知书|听证通知/u],
  ],
  complaint: [
    ['request', '投诉举报请求与受理机关', /投诉请求|举报请求|受理机关|12345|市场监督|消费者协会/u],
    ['evidence', '交易、产品服务与证明材料', /订单|付款|产品|服务|承诺|证据材料|照片|视频/u],
    ['handling', '沟通、处置与反馈记录', /聊天记录|售后|客服|处理结果|答复|反馈|退货|退款/u],
  ],
  'contract-review': [
    ['draft', '待审合同及历次版本', /合同|协议|草案|修订稿|对比稿/u],
    ['business', '交易背景与商业条件', /交易背景|商业条件|报价|需求说明|合作模式/u],
    ['issues', '风险问题与修改意见', /风险提示|审查意见|修改意见|问题清单/u],
  ],
  'due-diligence': [
    ['scope', '尽调范围与资料清单', /尽调范围|资料清单|尽调清单|核查范围/u],
    ['subject', '目标主体与业务资料', /目标公司|主体资料|公司章程|股权|业务合同/u],
    ['findings', '核查发现、风险与报告', /核查发现|风险清单|尽调报告|补充资料/u],
  ],
  advisory: [
    ['request', '顾问需求与咨询记录', /咨询事项|顾问需求|法律问题|咨询记录/u],
    ['basis', '分析依据与研究材料', /法律依据|法规|案例|检索报告|研究记录/u],
    ['deliverable', '法律意见与交付记录', /法律意见|咨询回复|工作报告|交付记录/u],
  ],
  'non-litigation': [
    ['scope', '专项范围与工作计划', /工作范围|专项计划|项目计划|任务清单/u],
    ['transaction', '交易、治理或申报材料', /交易文件|公司治理|股权|备案|申报|谈判/u],
    ['deliverable', '专项成果与交付记录', /法律意见|专项报告|交付稿|定稿/u],
  ],
})

const analysisCache = new Map()

function evidenceFor(pattern, records) {
  const content = records.filter(item => item.text !== '' && pattern.test(item.text)).map(item => item.path).slice(0, 5)
  const names = records.filter(item => pattern.test(item.path)).map(item => item.path).slice(0, 5)
  const files = [...new Set([...content, ...names])].slice(0, 5)
  return { status: content.length > 0 ? 'confirmed' : names.length > 0 ? 'possible' : 'missing', files }
}

export async function analyzeWorkspaceMatter(root, options = {}, pdfDocuments = []) {
  const walked = await walkProject(root, options)
  const cacheKey = `${options.matterType ?? 'auto'}\0${walked.files.map(file => `${file.relative}:${file.size}:${file.modifiedAt}`).join('|')}`
  const cached = analysisCache.get(walked.root)
  if (cached?.key === cacheKey) return cached.value
  const textExtensions = new Set(DEFAULT_TEXT_EXTENSIONS)
  const records = walked.files.map(file => ({ path: file.relative, text: '' }))
  const byPath = new Map(records.map(item => [item.path, item]))
  await Promise.all(walked.files.filter(file => textExtensions.has(file.extension) && file.size <= 2 * 1024 * 1024).map(async file => {
    byPath.get(file.relative).text = (await readFile(file.absolute, 'utf8')).slice(0, 50000)
  }))
  const pdfKinds = new Map(pdfDocuments.map(item => [item.path, item.kind]))
  const extractable = walked.files.filter(file => file.extension === '.docx' || (file.extension === '.pdf' && ['text', 'mixed'].includes(pdfKinds.get(file.relative))))
  if (extractable.length > 0) {
    const extracted = await runDocumentOperation(options.pythonExecutable ?? 'auto', {
      operation: 'extract_samples', maxCharacters: 50000,
      documents: extractable.slice(0, 40).map(file => ({ input: file.absolute, path: file.relative })),
    })
    for (const item of extracted.documents) if (byPath.has(item.path)) byPath.get(item.path).text = item.text
  }
  const corpus = records.map(item => `${item.path}\n${item.text}`).join('\n')
  const scores = TYPE_RULES.map(([type, pattern]) => ({ type, score: [...corpus.matchAll(new RegExp(pattern.source, 'gu'))].length }))
    .sort((a, b) => b.score - a.score)
  const recommendation = scores[0]?.score > 0 ? scores[0].type : 'general'
  const selected = options.matterType && options.matterType !== 'auto' ? options.matterType : recommendation
  const rules = [...BASE_CHECKLIST, ...(TYPE_CHECKLISTS[selected] ?? TYPE_CHECKLISTS.general)]
  const checklist = rules.map(([key, label, pattern]) => ({ key, label, ...evidenceFor(pattern, records) }))
  const value = {
    selectedType: selected,
    selectedLabel: MATTER_TYPE_LABELS[selected],
    configuredType: options.matterType ?? 'auto',
    recommendedType: recommendation,
    recommendedLabel: MATTER_TYPE_LABELS[recommendation],
    confidence: scores[0]?.score >= 5 ? 'high' : scores[0]?.score >= 2 ? 'medium' : 'low',
    checklist,
  }
  analysisCache.set(walked.root, { key: cacheKey, value })
  return value
}
