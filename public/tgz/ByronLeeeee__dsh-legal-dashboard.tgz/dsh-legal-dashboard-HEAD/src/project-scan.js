import { opendir, readFile, realpath, stat } from 'node:fs/promises'
import path from 'node:path'

export const DEFAULT_TEXT_EXTENSIONS = Object.freeze([
  '.txt', '.md', '.markdown', '.csv', '.tsv', '.json', '.jsonl', '.yaml', '.yml',
  '.xml', '.html', '.htm', '.log', '.ini', '.conf', '.rtf',
])

const DISPLAY_EXTENSION = '(no extension)'

const LEGAL_CATEGORIES = Object.freeze([
  { key: 'pleadings', label: '诉讼文书', pattern: /起诉|诉状|答辩|反诉|申请书|代理词|辩护词|仲裁|上诉|再审/u },
  { key: 'evidence', label: '证据材料', pattern: /证据|合同|协议|发票|收据|流水|聊天|录音|录像|照片|鉴定|证人|工资|考勤/u },
  { key: 'court', label: '法院及程序材料', pattern: /法院|法庭|判决|裁定|决定书|传票|送达|开庭|庭审|调解书|执行/u },
  { key: 'correspondence', label: '往来沟通', pattern: /函|邮件|通知|沟通|催告|回复|谈判|会议纪要/u },
  { key: 'research', label: '法规与检索', pattern: /法律|法规|司法解释|案例|检索|研究|类案|法条/u },
  { key: 'finance', label: '费用与计算', pattern: /费用|金额|利息|赔偿|损失|违约金|账|报价|清单/u },
])

const DEADLINE_KEYWORDS = /日期|期限|截止|到期|开庭|举证|答辩|上诉|申请|提交|送达|履行|付款|支付/u
const DATE_PATTERN = /(?<!\d)(20\d{2})[年\-/.](0?[1-9]|1[0-2])[月\-/.](0?[1-9]|[12]\d|3[01])日?(?!\d)/gu

function toPortablePath(value) {
  return value.split(path.sep).join('/')
}

function extensionOf(filename) {
  return path.extname(filename).toLowerCase() || DISPLAY_EXTENSION
}

function categoryOf(relativePath) {
  return LEGAL_CATEGORIES.find(category => category.pattern.test(relativePath))
    ?? { key: 'other', label: '其他材料' }
}

function normalizedDate(year, month, day) {
  return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`
}

function assertPositiveInteger(value, name) {
  if (!Number.isInteger(value) || value <= 0) {
    throw new TypeError(`${name} must be a positive integer`)
  }
}

export async function resolveProjectRoot(root) {
  if (typeof root !== 'string' || root.length === 0) {
    throw new TypeError('project root must be a non-empty path')
  }
  const canonical = await realpath(root)
  const info = await stat(canonical)
  if (!info.isDirectory()) throw new Error(`project root is not a directory: ${canonical}`)
  return canonical
}

export async function walkProject(root, options = {}) {
  const maxFiles = options.maxFiles ?? 5000
  assertPositiveInteger(maxFiles, 'maxFiles')
  const excluded = new Set(options.excludedDirectories ?? [])
  const canonicalRoot = await resolveProjectRoot(root)
  const files = []
  let directoryCount = 0
  let truncated = false
  const pending = [canonicalRoot]

  while (pending.length > 0 && !truncated) {
    const directory = pending.pop()
    const handle = await opendir(directory)
    for await (const entry of handle) {
      if (entry.isSymbolicLink()) continue
      const absolute = path.join(directory, entry.name)
      if (entry.isDirectory()) {
        if (!excluded.has(entry.name)) {
          directoryCount += 1
          pending.push(absolute)
        }
        continue
      }
      if (!entry.isFile()) continue
      if (files.length >= maxFiles) {
        truncated = true
        break
      }
      const info = await stat(absolute)
      files.push({
        absolute,
        relative: toPortablePath(path.relative(canonicalRoot, absolute)),
        extension: extensionOf(entry.name),
        size: info.size,
        modifiedAt: info.mtime.toISOString(),
      })
    }
  }

  files.sort((a, b) => a.relative.localeCompare(b.relative, 'en'))
  return { root: canonicalRoot, files, directoryCount, truncated }
}

export async function projectOverview(root, options = {}) {
  const walked = await walkProject(root, options)
  const textExtensions = new Set(options.textExtensions ?? DEFAULT_TEXT_EXTENSIONS)
  const counts = new Map()
  let bytes = 0
  for (const file of walked.files) {
    bytes += file.size
    counts.set(file.extension, (counts.get(file.extension) ?? 0) + 1)
  }
  const byExtension = [...counts.entries()]
    .map(([extension, count]) => ({ extension, count }))
    .sort((a, b) => b.count - a.count || a.extension.localeCompare(b.extension, 'en'))
  const recentFiles = [...walked.files]
    .sort((a, b) => b.modifiedAt.localeCompare(a.modifiedAt))
    .slice(0, options.recentLimit ?? 20)
    .map(file => ({
      path: file.relative,
      extension: file.extension,
      size: file.size,
      modifiedAt: file.modifiedAt,
      textSearchable: textExtensions.has(file.extension),
    }))
  return {
    root: walked.root,
    title: path.basename(walked.root),
    files: walked.files.length,
    directories: walked.directoryCount,
    bytes,
    truncated: walked.truncated,
    byExtension,
    recentFiles,
  }
}

async function deadlineCandidates(walked, options = {}) {
  const maxFileBytes = options.maxFileBytes ?? 2 * 1024 * 1024
  const maxDeadlines = options.maxDeadlines ?? 30
  const textExtensions = new Set(options.textExtensions ?? DEFAULT_TEXT_EXTENSIONS)
  const candidates = []
  const seen = new Set()
  for (const file of walked.files) {
    if (candidates.length >= maxDeadlines) break
    const filenameDates = [...file.relative.matchAll(DATE_PATTERN)]
    for (const match of filenameDates) {
      const key = `${file.relative}:0:${match[0]}`
      if (seen.has(key)) continue
      seen.add(key)
      candidates.push({
        date: normalizedDate(match[1], match[2], match[3]),
        path: file.relative,
        line: 0,
        snippet: file.relative,
        source: 'filename',
      })
    }
    if (!textExtensions.has(file.extension) || file.size > maxFileBytes) continue
    const text = await readFile(file.absolute, 'utf8')
    const lines = text.split(/\r?\n/u)
    for (let index = 0; index < lines.length && candidates.length < maxDeadlines; index += 1) {
      const line = lines[index]
      if (!DEADLINE_KEYWORDS.test(line)) continue
      for (const match of line.matchAll(DATE_PATTERN)) {
        const key = `${file.relative}:${index + 1}:${match[0]}`
        if (seen.has(key)) continue
        seen.add(key)
        candidates.push({
          date: normalizedDate(match[1], match[2], match[3]),
          path: file.relative,
          line: index + 1,
          snippet: line.trim().slice(0, 300),
          source: 'content',
        })
      }
    }
  }
  return candidates.sort((a, b) => a.date.localeCompare(b.date) || a.path.localeCompare(b.path, 'zh-CN'))
}

export async function legalCaseDashboard(root, options = {}) {
  const walked = await walkProject(root, options)
  const categories = new Map()
  for (const file of walked.files) {
    const category = categoryOf(file.relative)
    const current = categories.get(category.key) ?? { key: category.key, label: category.label, count: 0, files: [] }
    current.count += 1
    if (current.files.length < 8) current.files.push(file.relative)
    categories.set(category.key, current)
  }
  const categoryList = [...categories.values()]
    .sort((a, b) => b.count - a.count || a.label.localeCompare(b.label, 'zh-CN'))
  const present = new Set(categoryList.filter(item => item.count > 0).map(item => item.key))
  const checklist = [
    { key: 'pleadings', label: '诉讼请求、答辩意见或代理方案' },
    { key: 'evidence', label: '证据材料及证据目录' },
    { key: 'court', label: '法院、仲裁委或行政机关程序材料' },
    { key: 'correspondence', label: '当事人与对方的关键往来记录' },
  ].map(item => ({ ...item, present: present.has(item.key) }))
  const bytes = walked.files.reduce((sum, file) => sum + file.size, 0)
  return {
    root: walked.root,
    title: path.basename(walked.root),
    generatedAt: new Date().toISOString(),
    summary: {
      files: walked.files.length,
      directories: walked.directoryCount,
      bytes,
      truncated: walked.truncated,
    },
    categories: categoryList,
    deadlines: await deadlineCandidates(walked, options),
    checklist,
    disclaimer: '日期为自动识别的待核候选项，必须结合送达时间、程序规则和原始材料人工确认。',
  }
}

function contentMatches(text, needle, relativePath, remaining) {
  const results = []
  const lines = text.split(/\r?\n/u)
  for (let index = 0; index < lines.length && results.length < remaining; index += 1) {
    const line = lines[index]
    const column = line.toLowerCase().indexOf(needle)
    if (column === -1) continue
    results.push({
      kind: 'content',
      path: relativePath,
      line: index + 1,
      column: column + 1,
      snippet: line.trim().slice(0, 500),
    })
  }
  return results
}

export async function searchProject(root, query, options = {}) {
  const normalizedQuery = query.trim()
  if (normalizedQuery.length === 0) throw new Error('query must not be empty')
  const maxResults = options.maxResults ?? 50
  const maxFileBytes = options.maxFileBytes ?? 2 * 1024 * 1024
  assertPositiveInteger(maxResults, 'maxResults')
  assertPositiveInteger(maxFileBytes, 'maxFileBytes')
  const textExtensions = new Set(options.textExtensions ?? DEFAULT_TEXT_EXTENSIONS)
  const walked = await walkProject(root, options)
  const needle = normalizedQuery.toLowerCase()
  const results = []
  let searchedFiles = 0
  let skippedFiles = 0

  for (const file of walked.files) {
    if (results.length >= maxResults) break
    if (file.relative.toLowerCase().includes(needle)) {
      results.push({ kind: 'filename', path: file.relative, line: 0, column: 0, snippet: file.relative })
      if (results.length >= maxResults) break
    }
    if (!textExtensions.has(file.extension) || file.size > maxFileBytes) {
      skippedFiles += 1
      continue
    }
    const text = await readFile(file.absolute, 'utf8')
    searchedFiles += 1
    results.push(...contentMatches(text, needle, file.relative, maxResults - results.length))
  }

  return {
    query: normalizedQuery,
    searchedFiles,
    skippedFiles,
    truncated: walked.truncated || results.length >= maxResults,
    results,
  }
}
