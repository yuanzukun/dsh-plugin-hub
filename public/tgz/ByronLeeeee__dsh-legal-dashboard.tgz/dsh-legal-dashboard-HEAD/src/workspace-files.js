import { lstat, opendir, readFile, realpath, stat } from 'node:fs/promises'
import path from 'node:path'

const MIME = Object.freeze({
  '.txt': 'text/plain; charset=utf-8', '.md': 'text/markdown; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.csv': 'text/csv; charset=utf-8',
  '.html': 'text/html; charset=utf-8', '.xml': 'application/xml; charset=utf-8',
  '.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
})

const portable = value => value.split(path.sep).join('/')

export async function resolveWorkspaceFile(root, relativePath) {
  if (typeof relativePath !== 'string' || relativePath.length === 0 || path.isAbsolute(relativePath)) {
    throw new Error('invalid workspace-relative path')
  }
  const canonicalRoot = await realpath(root)
  const candidate = path.resolve(canonicalRoot, relativePath)
  const prefix = canonicalRoot.endsWith(path.sep) ? canonicalRoot : `${canonicalRoot}${path.sep}`
  if (!candidate.startsWith(prefix)) throw new Error('path escapes workspace')
  const info = await lstat(candidate)
  if (info.isSymbolicLink() || !info.isFile()) throw new Error('path is not a regular workspace file')
  const canonicalFile = await realpath(candidate)
  if (!canonicalFile.startsWith(prefix)) throw new Error('file resolves outside workspace')
  return { absolute: canonicalFile, info }
}

export async function workspaceTree(root, options = {}) {
  const maxEntries = options.maxEntries ?? 5000
  const excluded = new Set(options.excludedDirectories ?? [])
  const canonicalRoot = await realpath(root)
  const nodes = []

  async function visit(directory, parent = '') {
    if (nodes.length >= maxEntries) return
    const entries = []
    const handle = await opendir(directory)
    for await (const entry of handle) entries.push(entry)
    entries.sort((a, b) => Number(b.isDirectory()) - Number(a.isDirectory()) || a.name.localeCompare(b.name, 'zh-CN'))
    for (const entry of entries) {
      if (nodes.length >= maxEntries || entry.isSymbolicLink()) continue
      const relative = portable(path.join(parent, entry.name))
      const absolute = path.join(directory, entry.name)
      if (entry.isDirectory()) {
        if (excluded.has(entry.name)) continue
        nodes.push({ type: 'directory', name: entry.name, path: relative, depth: parent === '' ? 0 : relative.split('/').length - 1 })
        await visit(absolute, relative)
      } else if (entry.isFile()) {
        const info = await stat(absolute)
        const extension = path.extname(entry.name).toLowerCase()
        nodes.push({
          type: 'file', name: entry.name, path: relative,
          depth: parent === '' ? 0 : relative.split('/').length - 1,
          size: info.size, modifiedAt: info.mtime.toISOString(),
          mime: MIME[extension] ?? 'application/octet-stream',
        })
      }
    }
  }

  await visit(canonicalRoot)
  return { nodes, truncated: nodes.length >= maxEntries }
}

export async function readWorkspaceFile(root, relativePath) {
  const resolved = await resolveWorkspaceFile(root, relativePath)
  const extension = path.extname(resolved.absolute).toLowerCase()
  return {
    bytes: await readFile(resolved.absolute),
    mime: MIME[extension] ?? 'application/octet-stream',
    size: resolved.info.size,
  }
}
