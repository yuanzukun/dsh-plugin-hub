import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { walkProject } from './project-scan.js'
import { runDocumentOperation } from './document-runtime.js'

const DOCUMENT_EXTENSIONS = new Set(['.docx', '.pdf'])

export async function buildDocumentIndex(root, options) {
  const indexDir = path.join(root, '.legal-index')
  const indexPath = path.join(indexDir, 'documents.json')
  let previous = { documents: [] }
  try { previous = JSON.parse(await readFile(indexPath, 'utf8')) } catch {}
  const cached = new Map(previous.documents.map(document => [`${document.path}:${document.modifiedAt}:${document.size}`, document]))
  const walked = await walkProject(root, options)
  const candidates = walked.files.filter(file => DOCUMENT_EXTENSIONS.has(file.extension) && file.size <= (options.maxDocumentBytes ?? 30 * 1024 * 1024))
  const documents = []
  const errors = []
  let reused = 0
  for (const file of candidates) {
    const key = `${file.relative}:${file.modifiedAt}:${file.size}`
    const existing = cached.get(key)
    if (existing !== undefined) {
      documents.push(existing)
      reused += 1
      continue
    }
    try {
      const result = await runDocumentOperation(options.pythonExecutable, {
        operation: 'extract', input: file.absolute, maxCharacters: options.maxCharactersPerDocument ?? 500000,
      })
      documents.push({
        path: file.relative, modifiedAt: file.modifiedAt, size: file.size,
        text: result.text, truncated: result.truncated,
      })
    } catch (error) {
      errors.push({ path: file.relative, error: error instanceof Error ? error.message : String(error) })
    }
  }
  const payload = { version: 1, generatedAt: new Date().toISOString(), documents, errors }
  await mkdir(indexDir, { recursive: true })
  const temp = path.join(indexDir, `documents.${process.pid}.tmp`)
  await writeFile(temp, JSON.stringify(payload), 'utf8')
  await rename(temp, indexPath)
  return { indexPath: '.legal-index/documents.json', indexed: documents.length, extracted: documents.length - reused, reused, errors }
}

export async function searchDocumentIndex(root, query, maxResults = 50) {
  const normalized = query.trim()
  if (normalized === '') throw new Error('query must not be empty')
  let index
  try { index = JSON.parse(await readFile(path.join(root, '.legal-index', 'documents.json'), 'utf8')) } catch {
    throw new Error('document index is missing; run legal_index_build first')
  }
  const needle = normalized.toLowerCase()
  const results = []
  for (const document of index.documents ?? []) {
    const lines = String(document.text ?? '').split(/\r?\n/u)
    for (let line = 0; line < lines.length && results.length < maxResults; line += 1) {
      const column = lines[line].toLowerCase().indexOf(needle)
      if (column === -1) continue
      results.push({ path: document.path, line: line + 1, column: column + 1, snippet: lines[line].trim().slice(0, 500) })
    }
    if (results.length >= maxResults) break
  }
  return { query: normalized, results, indexedDocuments: index.documents?.length ?? 0, generatedAt: index.generatedAt }
}
