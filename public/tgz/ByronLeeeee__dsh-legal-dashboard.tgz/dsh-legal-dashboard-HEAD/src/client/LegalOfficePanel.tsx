import { useEffect, useMemo, useState, useSyncExternalStore } from 'react'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { SessionId, SessionProjectionMap } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import css from './LegalOfficePanel.module.css'
import { DEFAULT_ACTION_EN, SERVER_LABEL_EN } from './locales.ts'

interface FileNode {
  type: 'file' | 'directory'
  name: string
  path: string
  depth: number
  size?: number
  mime?: string
}

interface CaseDashboard {
  summary: { files: number; directories: number; bytes: number; truncated: boolean }
  categories: Array<{ key: string; label: string; count: number; files: string[] }>
  deadlines: Array<{ date: string; path: string; line: number; snippet: string; source: string }>
  checklist: Array<{ key: string; label: string; status: 'confirmed' | 'possible' | 'missing' | 'not_applicable'; files: string[] }>
  ocrProvider?: { configured: boolean; model?: string }
  quickActions?: QuickAction[]
  pdfDocuments?: Array<{ path: string; kind: 'text' | 'scanned' | 'mixed' | 'unknown'; pages: number; sampledPages: number; textCharacters: number; ocr?: 'current' | 'missing'; ocrOutputPath?: string }>
  matter?: { selectedType: string; selectedLabel: string; configuredType: string; recommendedType: string; recommendedLabel: string; confidence: string }
}

interface QuickAction { label: string; prompt: string }
interface WorkbenchConfig {
  quickActions: QuickAction[]
  matterType: string
  ocrBaseURL: string
  ocrModel: string
  ocrMaxPages: number
  ocrMaxTokens: number
  ocrTimeoutMs: number
  ocrCredential: { configured: boolean; writable: boolean; source?: string }
}

type CaseButtonProps = PropsRuntime<'sidebar.footer.action'> & PropsLocale<'legal-office'> & { toggle: () => void }
interface ObservableFace<T> {
  getSnapshot(): T
  subscribe(listener: () => void): () => void
}
interface WorkbenchControllerFace {
  getSnapshot(): { open: boolean; width: number }
  subscribe(listener: () => void): () => void
  resize: (width: number) => void
}
type WorkspacePanelProps = PropsRuntime<'shell.overlay'> & PropsLocale<'legal-office'> & {
  sessionId: SessionId
  projectionFace: (sessionId: SessionId, key: string) => ObservableFace<unknown> | undefined
  resize: (width: number) => void
  fillDraft: (sessionId: SessionId, prompt: string) => void
  createGoal: (sessionId: SessionId, objective: string) => Promise<void>
}
type WorkspaceOverlayProps = PropsRuntime<'shell.overlay'> & PropsLocale<'legal-office'> & {
  controller: WorkbenchControllerFace
  projectionFace: WorkspacePanelProps['projectionFace']
  fillDraft: WorkspacePanelProps['fillDraft']
  createGoal: WorkspacePanelProps['createGoal']
}

const RESET_PREVIEW_EVENT = 'legal-office:reset-preview'
const WORKBENCH_WIDTH = 360
const WORKBENCH_WITH_PREVIEW_WIDTH = 820
const QUICK_ACTIONS = [
  { label: '案件梳理', prompt: '梳理当前案件目录中的全部材料，区分已确认事实、当事人陈述、推断和待核实事项，列出争议焦点与下一步工作。' },
  { label: '材料缺口', prompt: '审查当前案件材料完整性，按主体身份、事实依据、请求依据、程序材料和授权手续列出缺失材料，并标注优先级。' },
  { label: '证据目录', prompt: '基于当前案件材料编制证据目录，逐项注明证据名称、来源文件和证明目的，输出为 工作成果/证据目录.docx。' },
  { label: '文书起草', prompt: '基于当前案件材料判断应当优先起草的法律文书；信息不足时先列出待确认问题，信息充分时输出为 工作成果/文书初稿.docx。' },
  { label: '期限核查', prompt: '核查当前案件材料中的程序期限候选，逐项说明原始文件位置、日期依据、待核事项和风险，不得把自动识别日期直接视为法定期限。' },
  { label: 'OCR 扫描件', prompt: '识别当前案件中无法提取文本的扫描 PDF 或图片，执行 OCR 并将校对结果按原文件名保存到 工作成果/OCR。' },
] as const

function CaseGlyph() {
  return <svg viewBox="0 0 20 20" width="18" height="18" aria-hidden><path d="M3.5 6.5h13v10h-13zM7 6.5V4.75c0-.7.55-1.25 1.25-1.25h3.5c.7 0 1.25.55 1.25 1.25V6.5M3.5 10h13" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" /></svg>
}

export function CaseButton({ wide, toggle, t }: CaseButtonProps) {
  return <button type="button" className={css.caseButton} onClick={() => {
    window.dispatchEvent(new Event(RESET_PREVIEW_EVENT))
    toggle()
  }} aria-label={t('button.toggle')}>
    <CaseGlyph />{wide && <span>{t('nav.case')}</span>}
  </button>
}

export function LegalWorkspaceOverlay({
  useSessions, useWorkspaces, controller, projectionFace, fillDraft, createGoal, t,
}: WorkspaceOverlayProps) {
  const state = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot)
  const sessionId = useSessions(snapshot => snapshot.current)
  if (!state.open || sessionId === undefined) return null
  return <aside className={css.overlayPanel} style={{ width: `${state.width}px` }} aria-label={t('button.toggle')}>
    <LegalWorkspacePanel
      sessionId={sessionId}
      useSessions={useSessions}
      useWorkspaces={useWorkspaces}
      projectionFace={projectionFace}
      resize={controller.resize}
      fillDraft={fillDraft}
      createGoal={createGoal}
      t={t}
    />
  </aside>
}

function fileUrl(workspaceId: string, filePath: string) {
  return `/api/legal-office/file?workspaceId=${encodeURIComponent(workspaceId)}&path=${encodeURIComponent(filePath)}`
}

function formatSize(size = 0) {
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${Math.round(size / 1024)} KB`
  return `${(size / 1024 / 1024).toFixed(1)} MB`
}

export function LegalWorkspacePanel({
  sessionId, useSessions, useWorkspaces, projectionFace, resize, fillDraft, createGoal, t,
}: WorkspacePanelProps) {
  const isEnglish = t('locale.id') === 'en'
  const localizeServerLabel = (label: string | undefined) => label === undefined ? undefined : isEnglish ? (SERVER_LABEL_EN[label] ?? label) : label
  const localizeAction = (action: QuickAction): QuickAction => isEnglish && DEFAULT_ACTION_EN[action.label] !== undefined
    ? DEFAULT_ACTION_EN[action.label]
    : action
  const workspaces = useWorkspaces(state => state.items)
  const session = useSessions(state => state.byId[sessionId])
  const workspace = useMemo(() => workspaces.find(item => item.sessionIds.includes(sessionId)
    || (session?.cwd !== undefined && item.path === session.cwd)), [session?.cwd, sessionId, workspaces])
  const [tab, setTab] = useState<'overview' | 'files' | 'tasks' | 'settings'>('overview')
  const [configTab, setConfigTab] = useState<'matter' | 'quick-actions' | 'ocr'>('matter')
  const [nodes, setNodes] = useState<FileNode[]>([])
  const [dashboard, setDashboard] = useState<CaseDashboard>()
  const [selected, setSelected] = useState<FileNode>()
  const [text, setText] = useState<string>()
  const [loading, setLoading] = useState(false)
  const [query, setQuery] = useState('')
  const [actionStatus, setActionStatus] = useState<string>()
  const [goalDraft, setGoalDraft] = useState('')
  const [goalEditing, setGoalEditing] = useState(false)
  const [configuration, setConfiguration] = useState<WorkbenchConfig>()
  const [apiKey, setApiKey] = useState('')
  const [configStatus, setConfigStatus] = useState<string>()
  const [pendingDeleteAction, setPendingDeleteAction] = useState<number>()
  const [collapsed, setCollapsed] = useState<Set<string>>(() => new Set())
  const goalFace = useMemo(() => projectionFace(sessionId, 'goal'), [projectionFace, sessionId])
  const todosFace = useMemo(() => projectionFace(sessionId, 'todos'), [projectionFace, sessionId])
  const goalProjection = useSyncExternalStore(
    goalFace?.subscribe ?? (() => () => {}),
    goalFace?.getSnapshot ?? (() => undefined),
    goalFace?.getSnapshot ?? (() => undefined),
  ) as SessionProjectionMap['goal'] | undefined
  const todos = useSyncExternalStore(
    todosFace?.subscribe ?? (() => () => {}),
    todosFace?.getSnapshot ?? (() => undefined),
    todosFace?.getSnapshot ?? (() => undefined),
  ) as SessionProjectionMap['todos'] | undefined

  const workspaceId = workspace === undefined ? undefined : String(workspace.workspaceId)
  useEffect(() => {
    const reset = () => { setSelected(undefined) }
    window.addEventListener(RESET_PREVIEW_EVENT, reset)
    return () => { window.removeEventListener(RESET_PREVIEW_EVENT, reset) }
  }, [])
  useEffect(() => {
    if (workspaceId === undefined) return
    let disposed = false
    setLoading(true)
    const refresh = () => {
      Promise.all([
        fetch(`/api/legal-office/tree?workspaceId=${encodeURIComponent(workspaceId)}`)
          .then(async response => response.ok ? await response.json() as { nodes: FileNode[] } : { nodes: [] }),
        fetch(`/api/legal-office/dashboard?workspaceId=${encodeURIComponent(workspaceId)}`)
          .then(async response => response.ok ? await response.json() as CaseDashboard : undefined),
      ])
        .then(([tree, nextDashboard]) => {
          if (!disposed) { setNodes(tree.nodes); setDashboard(nextDashboard) }
        })
        .finally(() => { if (!disposed) setLoading(false) })
    }
    refresh()
    const timer = window.setInterval(refresh, 5000)
    window.addEventListener('focus', refresh)
    return () => { disposed = true; window.clearInterval(timer); window.removeEventListener('focus', refresh) }
  }, [workspaceId])

  useEffect(() => {
    if (workspaceId === undefined) return
    let disposed = false
    fetch(`/api/legal-office/config?workspaceId=${encodeURIComponent(workspaceId)}`)
      .then(async response => response.ok ? await response.json() as WorkbenchConfig : undefined)
      .then(value => { if (!disposed) setConfiguration(value) })
    return () => { disposed = true }
  }, [workspaceId])

  useEffect(() => {
    setText(undefined)
    if (selected?.type !== 'file' || workspaceId === undefined) return
    const isText = selected.mime?.startsWith('text/') || selected.mime?.includes('json') || selected.mime?.includes('xml')
    const isDocx = selected.mime?.includes('wordprocessingml')
    if (!isText && !isDocx) return
    const controller = new AbortController()
    const url = isDocx
      ? `/api/legal-office/extract?workspaceId=${encodeURIComponent(workspaceId)}&path=${encodeURIComponent(selected.path)}`
      : fileUrl(workspaceId, selected.path)
    fetch(url, { signal: controller.signal })
      .then(async response => response.ok ? await response.text() : '')
      .then(value => { if (!controller.signal.aborted) setText(value) })
    return () => { controller.abort() }
  }, [selected, workspaceId])

  const choose = (node: FileNode) => {
    if (node.type === 'directory') {
      setCollapsed(previous => {
        const next = new Set(previous)
        if (next.has(node.path)) next.delete(node.path); else next.add(node.path)
        return next
      })
      return
    }
    setSelected(node)
    resize(WORKBENCH_WITH_PREVIEW_WIDTH)
  }

  const closePreview = () => {
    setSelected(undefined)
    resize(WORKBENCH_WIDTH)
  }

  const openPath = (filePath: string) => {
    const node = nodes.find(item => item.type === 'file' && item.path === filePath)
    if (node !== undefined) choose(node)
  }

  const startAction = (label: string, prompt: string) => {
    try {
      fillDraft(sessionId, prompt)
      setActionStatus(t('status.actionFilled', { label }))
    } catch {
      setActionStatus(t('status.actionFailed', { label }))
    }
  }

  const submitGoal = () => {
    const objective = goalDraft.trim()
    if (objective === '') return
    setActionStatus(t('status.goalCreating'))
    void createGoal(sessionId, objective).then(() => {
      setGoalDraft('')
      setGoalEditing(false)
      setActionStatus(t('status.goalCreated'))
    }).catch(() => { setActionStatus(t('status.goalFailed')) })
  }

  const saveConfiguration = () => {
    if (configuration === undefined || workspaceId === undefined) return
    setConfigStatus(t('status.saving'))
    fetch(`/api/legal-office/config?workspaceId=${encodeURIComponent(workspaceId)}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...configuration, ...(apiKey.trim() === '' ? {} : { apiKey: apiKey.trim() }) }),
    }).then(async response => {
      const value = await response.json() as WorkbenchConfig & { error?: string }
      if (!response.ok) throw new Error(value.error ?? t('status.saveFailed'))
      setConfiguration(value)
      setApiKey('')
      setDashboard(previous => previous === undefined ? previous : {
        ...previous,
        quickActions: value.quickActions,
        ocrProvider: { configured: value.ocrBaseURL.trim() !== '' && value.ocrModel.trim() !== '', model: value.ocrModel },
      })
      setConfigStatus(t('status.saved'))
    }).catch((error: unknown) => { setConfigStatus(error instanceof Error ? error.message : t('status.saveFailed')) })
  }

  const clearOcrCredential = () => {
    if (configuration === undefined || workspaceId === undefined) return
    setConfigStatus(t('status.clearingKey'))
    fetch(`/api/legal-office/config?workspaceId=${encodeURIComponent(workspaceId)}`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...configuration, clearApiKey: true }),
    }).then(async response => {
      const value = await response.json() as WorkbenchConfig & { error?: string }
      if (!response.ok) throw new Error(value.error ?? t('status.clearFailed'))
      setConfiguration(value)
      setApiKey('')
      setConfigStatus(t('status.keyCleared'))
    }).catch((error: unknown) => { setConfigStatus(error instanceof Error ? error.message : t('status.clearFailed')) })
  }

  const normalizedQuery = query.trim().toLocaleLowerCase('zh-CN')
  const visibleNodes = nodes.filter(node => {
    if (normalizedQuery !== '') {
      const ownMatch = node.path.toLocaleLowerCase('zh-CN').includes(normalizedQuery)
      const childMatch = node.type === 'directory' && nodes.some(child =>
        child.path.startsWith(`${node.path}/`) && child.path.toLocaleLowerCase('zh-CN').includes(normalizedQuery))
      if (!ownMatch && !childMatch) return false
    }
    const parts = node.path.split('/')
    for (let index = 1; index < parts.length; index++) {
      if (collapsed.has(parts.slice(0, index).join('/'))) return false
    }
    return true
  })
  const goal = goalProjection?.goal
  const goalPhase = goal?.phase === 'active' ? t('phase.active') : goal?.phase === 'paused' ? t('phase.paused') : goal?.phase === 'blocked' ? t('phase.blocked') : t('phase.complete')
  const missingCount = dashboard?.checklist.filter(item => item.status === 'missing').length ?? 0
  const pdfKinds = useMemo(() => new Map(dashboard?.pdfDocuments?.map(item => [item.path, item]) ?? []), [dashboard?.pdfDocuments])
  const pdfKindLabel = (filePath: string) => {
    const document = pdfKinds.get(filePath)
    const kind = document?.kind
    const type = kind === 'scanned' ? t('pdf.scanned') : kind === 'text' ? t('pdf.text') : kind === 'mixed' ? t('pdf.mixed') : kind === 'unknown' ? t('pdf.unknown') : undefined
    return type === undefined ? undefined : `${type}${document?.ocr === 'current' ? t('pdf.ocrCurrent') : ''}`
  }

  return <div className={`${css.workspaceRoot}${selected === undefined ? '' : ` ${css.previewOpen}`}`}>
    <section className={css.workbenchPane}>
      <header className={css.workspaceHeader}>
        <strong>{workspace?.title ?? t('nav.case')}</strong>
        <nav className={css.primaryNav} aria-label={t('aria.primary')}>
          <button type="button" aria-selected={tab !== 'settings'} onClick={() => { if (tab === 'settings') setTab('overview') }}>{t('nav.case')}</button>
          <button type="button" aria-selected={tab === 'settings'} onClick={() => { setTab('settings') }}>{t('nav.settings')}</button>
        </nav>
        {tab !== 'settings' && <nav className={css.secondaryNav} aria-label={t('aria.caseSecondary')}>
          <button type="button" aria-selected={tab === 'overview'} onClick={() => { setTab('overview') }}>{t('nav.overview')}</button>
          <button type="button" aria-selected={tab === 'files'} onClick={() => { setTab('files') }}>{t('nav.files')}</button>
          <button type="button" aria-selected={tab === 'tasks'} onClick={() => { setTab('tasks') }}>{t('nav.tasks')}</button>
        </nav>}
        {tab === 'settings' && <nav className={css.secondaryNav} aria-label={t('aria.configSecondary')}>
          <button type="button" aria-selected={configTab === 'matter'} onClick={() => { setConfigTab('matter') }}>{t('nav.matter')}</button>
          <button type="button" aria-selected={configTab === 'quick-actions'} onClick={() => { setConfigTab('quick-actions') }}>{t('nav.quickActions')}</button>
          <button type="button" aria-selected={configTab === 'ocr'} onClick={() => { setConfigTab('ocr') }}>{t('nav.ocr')}</button>
        </nav>}
      </header>
      <main className={css.workspaceBody}>
      {tab === 'overview' && <div className={css.overview}>
        {loading && dashboard === undefined && <div className={css.status}>{t('status.analyzing')}</div>}
        {dashboard !== undefined && <>
          <section className={css.metrics} aria-label={t('metric.summary')}>
            <div><strong>{dashboard.summary.files}</strong><span>{t('metric.files')}</span></div>
            <div><strong>{dashboard.categories.length}</strong><span>{t('metric.categories')}</span></div>
            <div data-alert={missingCount > 0 || undefined}><strong>{missingCount}</strong><span>{t('metric.missing')}</span></div>
            <div data-alert={dashboard.deadlines.length > 0 || undefined}><strong>{dashboard.deadlines.length}</strong><span>{t('metric.deadlines')}</span></div>
          </section>
          <section className={css.overviewSection}>
            <h3>{t('section.quickActions')}</h3>
            <div className={css.quickGrid}>
              {(dashboard.quickActions ?? QUICK_ACTIONS).map(localizeAction).map((action, index) => <button type="button" key={`${index}:${action.label}`}
                onClick={() => { startAction(action.label, action.prompt) }}>{action.label}</button>)}
            </div>
            {actionStatus !== undefined && <div className={css.actionStatus}>{actionStatus}</div>}
          </section>
          <section className={css.overviewSection}>
            <div className={css.sectionHeading}><h3>{t('section.checklist')}</h3><span>{localizeServerLabel(dashboard.matter?.selectedLabel) ?? t('matter.generic')} · {dashboard.checklist.length - missingCount}/{dashboard.checklist.length}</span></div>
            <div className={css.checklist}>
              {dashboard.checklist.map(item => <button type="button" key={item.key} data-status={item.status}
                title={item.files.length === 0 ? t('check.noMaterial') : item.files.join('\n')}
                onClick={() => { if (item.files[0] !== undefined) openPath(item.files[0]) }}>
                <span className={css.checkMark} />
                <span>{localizeServerLabel(item.label)}</span>
                <strong>{item.status === 'confirmed' ? t('check.confirmed') : item.status === 'possible' ? t('check.possible') : item.status === 'not_applicable' ? t('check.notApplicable') : t('check.missing')}</strong>
              </button>)}
            </div>
          </section>
          <section className={css.overviewSection}>
            <div className={css.sectionHeading}><h3>{t('section.distribution')}</h3><span>{t('unit.items', { count: dashboard.summary.files })}</span></div>
            <div className={css.categories}>
              {dashboard.categories.slice(0, 6).map(category => <div key={category.key}>
                <span>{localizeServerLabel(category.label)}</span><strong>{category.count}</strong>
              </div>)}
            </div>
          </section>
          <section className={css.overviewSection}>
            <div className={css.sectionHeading}><h3>{t('section.deadlines')}</h3><span>{t('hint.manualCheck')}</span></div>
            {dashboard.deadlines.length === 0
              ? <div className={css.emptyLine}>{t('empty.deadlines')}</div>
              : <div className={css.deadlines}>{dashboard.deadlines.slice(0, 5).map(item => <button type="button"
                key={`${item.path}:${item.line}:${item.date}`} onClick={() => { openPath(item.path) }}>
                <time>{item.date}</time><span>{item.path}</span>
              </button>)}</div>}
          </section>
        </>}
      </div>}
      {tab === 'files' && <div className={css.materials}>
        <div className={css.searchBox}><input value={query} onChange={event => { setQuery(event.target.value) }} placeholder={t('files.search')} aria-label={t('files.search')} /></div>
        <div className={css.fileTree} role="tree" aria-label={t('files.tree')}>
        {loading && <div className={css.status}>{t('status.loading')}</div>}
        {!loading && visibleNodes.map(node => <button
          type="button" role="treeitem" key={node.path} className={css.fileRow}
          style={{ paddingLeft: `${12 + node.depth * 16}px` }}
          data-type={node.type} data-selected={selected?.path === node.path || undefined} onClick={() => { choose(node) }} title={node.path}
        >
          <span className={css.nodeIcon}>{node.type === 'directory' ? (collapsed.has(node.path) ? '›' : '⌄') : ''}</span>
          <span className={css.nodeName}>{node.name}</span>
          {node.type === 'file' && pdfKindLabel(node.path) !== undefined && <span className={css.pdfKind} data-kind={pdfKinds.get(node.path)?.kind}>{pdfKindLabel(node.path)}</span>}
          {node.type === 'file' && <span className={css.nodeSize}>{formatSize(node.size)}</span>}
        </button>)}
        </div>
      </div>}
      {tab === 'tasks' && <div className={css.taskList}>
        {goal !== undefined && goal.phase !== 'complete' && <section className={css.goalCard}>
          <div className={css.taskHeading}><strong>{t('goal.longTerm')}</strong><span>{goalPhase}</span></div>
          <p>{goal.objective}</p>
        </section>}
        {Array.isArray(todos) && todos.length > 0 && <section className={css.todoGroup}>
          <div className={css.taskHeading}><strong>{t('goal.currentTasks')}</strong><span>{todos.filter(item => item.status === 'completed').length}/{todos.length}</span></div>
          {todos.map(item => <div className={css.todoRow} key={`${item.status}:${item.content}`} data-status={item.status}>
            <span className={css.todoMark} />
            <span>{item.content}</span>
          </div>)}
        </section>}
        {(goal === undefined || goal.phase === 'complete') && <section className={css.goalCreator}>
          {!goalEditing
            ? <button type="button" onClick={() => { setGoalEditing(true) }}>{t('goal.new')}</button>
            : <div><textarea value={goalDraft} onChange={event => { setGoalDraft(event.target.value) }} placeholder={t('goal.placeholder')} aria-label={t('goal.aria')} />
              <div className={css.formActions}><button type="button" onClick={() => { setGoalEditing(false); setGoalDraft('') }}>{t('action.cancel')}</button><button type="button" disabled={goalDraft.trim() === ''} onClick={submitGoal}>{t('action.create')}</button></div>
            </div>}
        </section>}
        {(goal === undefined || goal.phase === 'complete') && (!Array.isArray(todos) || todos.length === 0) && !goalEditing && <div className={css.emptyLine}>{t('empty.tasks')}</div>}
      </div>}
      {tab === 'settings' && <div className={css.configPage}>
        {configuration === undefined
          ? <div className={css.status}>{t('status.readingConfig')}</div>
          : <>
            {configTab === 'matter' && <section className={css.configSection}>
              <div className={css.configHeading}><h3>{t('config.matterType')}</h3><span>{dashboard?.matter?.configuredType === 'auto' ? t('config.recommended', { label: localizeServerLabel(dashboard.matter.recommendedLabel) }) : t('config.manual')}</span></div>
              <div className={css.configFields}>
                <label><span>{t('config.currentType')}</span><select value={configuration.matterType} onChange={event => { setConfiguration({ ...configuration, matterType: event.target.value }) }}>
                  <option value="auto">{localizeServerLabel('自动识别')}</option><option value="general">{localizeServerLabel('通用法律事项')}</option><option value="litigation">{localizeServerLabel('民商事诉讼')}</option>
                  <option value="arbitration">{localizeServerLabel('仲裁')}</option><option value="criminal">{localizeServerLabel('刑事')}</option><option value="administrative">{localizeServerLabel('行政')}</option>
                  <option value="complaint">{localizeServerLabel('投诉举报')}</option>
                  <option value="contract-review">{localizeServerLabel('合同审查')}</option><option value="due-diligence">{localizeServerLabel('尽职调查')}</option>
                  <option value="advisory">{localizeServerLabel('法律顾问')}</option><option value="non-litigation">{localizeServerLabel('专项非诉')}</option>
                </select></label>
              </div>
            </section>}
            {configTab === 'quick-actions' && <section className={css.configSection}>
              <div className={css.configHeading}><h3>{t('section.quickActions')}</h3><button type="button" onClick={() => {
                setConfiguration(current => current === undefined ? current : { ...current, quickActions: [...current.quickActions, { label: t('config.newAction'), prompt: '' }] })
              }}>{t('config.add')}</button></div>
              <div className={css.actionEditors}>
                {configuration.quickActions.map((action, index) => <div className={css.actionEditor} key={index}>
                  <div className={css.actionEditorTop}>
                    <input aria-label={t('config.actionName', { index: index + 1 })} value={action.label} maxLength={30} onChange={event => {
                      setConfiguration(current => current === undefined ? current : { ...current, quickActions: current.quickActions.map((item, itemIndex) => itemIndex === index ? { ...item, label: event.target.value } : item) })
                    }} />
                    <div className={css.actionDelete}>
                      {pendingDeleteAction === index && <button type="button" onClick={() => { setPendingDeleteAction(undefined) }}>{t('action.cancel')}</button>}
                      <button type="button" data-confirm={pendingDeleteAction === index || undefined}
                        aria-label={pendingDeleteAction === index ? t('config.confirmDeleteAction', { index: index + 1 }) : t('config.deleteAction', { index: index + 1 })}
                        onClick={() => {
                          if (pendingDeleteAction !== index) { setPendingDeleteAction(index); return }
                          setConfiguration(current => current === undefined ? current : { ...current, quickActions: current.quickActions.filter((_item, itemIndex) => itemIndex !== index) })
                          setPendingDeleteAction(undefined)
                        }}>{pendingDeleteAction === index ? t('action.confirmDelete') : t('action.delete')}</button>
                    </div>
                  </div>
                  <textarea aria-label={t('config.actionPrompt', { index: index + 1 })} value={action.prompt} maxLength={4000} onChange={event => {
                    setConfiguration(current => current === undefined ? current : { ...current, quickActions: current.quickActions.map((item, itemIndex) => itemIndex === index ? { ...item, prompt: event.target.value } : item) })
                  }} />
                </div>)}
              </div>
            </section>}
            {configTab === 'ocr' && <section className={css.configSection}>
              <div className={css.configHeading}><h3>{t('config.ocrModel')}</h3><span>{configuration.ocrCredential.configured ? t('config.keyConfigured') : t('config.keyMissing')}</span></div>
              <div className={css.configFields}>
                <label><span>Base URL</span><input value={configuration.ocrBaseURL} placeholder="https://api.openai.com/v1" onChange={event => { setConfiguration({ ...configuration, ocrBaseURL: event.target.value }) }} /></label>
                <label><span>{t('config.model')}</span><input value={configuration.ocrModel} placeholder={t('config.modelPlaceholder')} onChange={event => { setConfiguration({ ...configuration, ocrModel: event.target.value }) }} /></label>
                <label><span>API Key</span><input type="password" value={apiKey} placeholder={configuration.ocrCredential.configured ? t('config.keepKey') : t('config.enterKey')} onChange={event => { setApiKey(event.target.value) }} /></label>
                <div className={css.numberFields}>
                  <label><span>{t('config.maxPages')}</span><input type="number" min="1" max="100" value={configuration.ocrMaxPages} onChange={event => { setConfiguration({ ...configuration, ocrMaxPages: Number(event.target.value) }) }} /></label>
                  <label><span>{t('config.outputTokens')}</span><input type="number" min="1" max="32768" value={configuration.ocrMaxTokens} onChange={event => { setConfiguration({ ...configuration, ocrMaxTokens: Number(event.target.value) }) }} /></label>
                  <label><span>{t('config.timeoutMs')}</span><input type="number" min="1000" max="600000" step="1000" value={configuration.ocrTimeoutMs} onChange={event => { setConfiguration({ ...configuration, ocrTimeoutMs: Number(event.target.value) }) }} /></label>
                </div>
              </div>
              {configuration.ocrCredential.configured && configuration.ocrCredential.writable && <button type="button" className={css.clearCredential} onClick={clearOcrCredential}>{t('config.clearKey')}</button>}
            </section>}
            <div className={css.configFooter}><span>{configStatus}</span><button type="button" onClick={saveConfiguration}>{t('config.save')}</button></div>
          </>}
      </div>}
      </main>
    </section>
    {selected !== undefined && workspaceId !== undefined && <aside className={css.preview} aria-label={t('preview.aria')}>
      <div className={css.fileMeta}>
        <strong>{selected.name}</strong><span>{formatSize(selected.size)}</span>
        <button type="button" onClick={closePreview} aria-label={t('preview.close')}>
          <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden><path d="M4 4l8 8M12 4l-8 8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg>
        </button>
      </div>
      {selected.mime === 'application/pdf'
        ? <iframe title={selected.name} src={fileUrl(workspaceId, selected.path)} />
        : selected.mime?.startsWith('image/')
          ? <div className={css.imageStage}><img src={fileUrl(workspaceId, selected.path)} alt={selected.name} /></div>
          : text !== undefined
            ? <pre>{text}</pre>
            : <div className={css.status}>{t('preview.unsupported')}</div>}
    </aside>}
  </div>
}
