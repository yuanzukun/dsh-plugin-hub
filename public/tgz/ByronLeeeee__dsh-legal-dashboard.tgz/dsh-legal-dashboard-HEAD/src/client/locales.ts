export const LEGAL_OFFICE_NS = 'legal-office'

export const zh = {
  'locale.id': 'zh',
  'button.toggle': '展开或收起案件工作台',
  'nav.case': '案件', 'nav.settings': '配置', 'nav.overview': '概览', 'nav.files': '材料', 'nav.tasks': '任务',
  'nav.matter': '项目', 'nav.quickActions': '快捷工作', 'nav.ocr': 'OCR',
  'aria.primary': '工作台一级标签', 'aria.caseSecondary': '案件二级标签', 'aria.configSecondary': '配置二级标签',
  'status.analyzing': '正在分析案件材料', 'status.loading': '加载中', 'status.readingConfig': '正在读取配置',
  'metric.summary': '案件概况', 'metric.files': '材料', 'metric.categories': '类别', 'metric.missing': '缺口', 'metric.deadlines': '日期候选',
  'section.quickActions': '快捷工作', 'section.checklist': '项目清单', 'section.distribution': '材料分布', 'section.deadlines': '期限候选',
  'matter.generic': '通用法律事项', 'unit.items': '{count} 项', 'hint.manualCheck': '需人工核对', 'empty.deadlines': '未发现日期候选',
  'check.noMaterial': '未发现对应材料', 'check.confirmed': '已确认', 'check.possible': '可能已有', 'check.notApplicable': '不适用', 'check.missing': '未发现',
  'files.search': '搜索案件材料', 'files.tree': '案件材料',
  'goal.longTerm': '长期目标', 'goal.currentTasks': '当前任务', 'goal.new': '新建长期任务', 'goal.placeholder': '输入需要持续完成的案件目标',
  'goal.aria': '长期任务目标', 'action.cancel': '取消', 'action.create': '创建', 'empty.tasks': '暂无执行中的任务',
  'phase.active': '执行中', 'phase.paused': '已暂停', 'phase.blocked': '受阻', 'phase.complete': '已完成',
  'status.actionFilled': '{label}已填入输入框', 'status.actionFailed': '{label}填入失败',
  'status.goalCreating': '正在创建长期任务', 'status.goalCreated': '长期任务已创建', 'status.goalFailed': '长期任务创建失败',
  'error.sessionUnavailable': '案件会话不可用', 'error.conversationUnavailable': '对话服务不可用',
  'status.saving': '正在保存', 'status.saved': '已保存', 'status.saveFailed': '保存失败',
  'status.clearingKey': '正在清除密钥', 'status.keyCleared': '密钥已清除', 'status.clearFailed': '清除失败',
  'config.matterType': '项目类型', 'config.recommended': '推荐：{label}', 'config.manual': '手动指定', 'config.currentType': '当前类型',
  'config.add': '添加', 'config.newAction': '新工作', 'config.actionName': '快捷工作 {index} 名称', 'config.actionPrompt': '快捷工作 {index} 提示词',
  'config.deleteAction': '删除快捷工作 {index}', 'config.confirmDeleteAction': '确认删除快捷工作 {index}', 'action.delete': '删除', 'action.confirmDelete': '确认删除',
  'config.ocrModel': 'OCR 模型', 'config.keyConfigured': '密钥已配置', 'config.keyMissing': '密钥未配置', 'config.model': '模型',
  'config.modelPlaceholder': '支持图像输入的模型名称', 'config.keepKey': '留空保持现有密钥', 'config.enterKey': '输入模型服务密钥',
  'config.maxPages': '最多页数', 'config.outputTokens': '输出 Tokens', 'config.timeoutMs': '超时毫秒', 'config.clearKey': '清除密钥', 'config.save': '保存配置',
  'preview.aria': '文档预览', 'preview.close': '关闭文档预览', 'preview.unsupported': '无法预览此格式',
  'pdf.scanned': '扫描件', 'pdf.text': '文本 PDF', 'pdf.mixed': '混合 PDF', 'pdf.unknown': '待判断', 'pdf.ocrCurrent': ' · OCR 已有',
} as const

export type LegalOfficeLocaleKey = keyof typeof zh

export const en: Record<LegalOfficeLocaleKey, string> = {
  'locale.id': 'en',
  'button.toggle': 'Open or close the matter workspace',
  'nav.case': 'Matter', 'nav.settings': 'Settings', 'nav.overview': 'Overview', 'nav.files': 'Files', 'nav.tasks': 'Tasks',
  'nav.matter': 'Matter', 'nav.quickActions': 'Quick actions', 'nav.ocr': 'OCR',
  'aria.primary': 'Workspace primary tabs', 'aria.caseSecondary': 'Matter tabs', 'aria.configSecondary': 'Settings tabs',
  'status.analyzing': 'Analyzing matter files', 'status.loading': 'Loading', 'status.readingConfig': 'Loading settings',
  'metric.summary': 'Matter summary', 'metric.files': 'Files', 'metric.categories': 'Categories', 'metric.missing': 'Missing', 'metric.deadlines': 'Date candidates',
  'section.quickActions': 'Quick actions', 'section.checklist': 'Matter checklist', 'section.distribution': 'File distribution', 'section.deadlines': 'Deadline candidates',
  'matter.generic': 'General legal matter', 'unit.items': '{count} items', 'hint.manualCheck': 'Manual review required', 'empty.deadlines': 'No date candidates found',
  'check.noMaterial': 'No matching files found', 'check.confirmed': 'Confirmed', 'check.possible': 'Possibly available', 'check.notApplicable': 'Not applicable', 'check.missing': 'Not found',
  'files.search': 'Search matter files', 'files.tree': 'Matter files',
  'goal.longTerm': 'Long-term goal', 'goal.currentTasks': 'Current tasks', 'goal.new': 'Create long-term task', 'goal.placeholder': 'Describe the matter goal that should be pursued over time',
  'goal.aria': 'Long-term task objective', 'action.cancel': 'Cancel', 'action.create': 'Create', 'empty.tasks': 'No active tasks',
  'phase.active': 'Active', 'phase.paused': 'Paused', 'phase.blocked': 'Blocked', 'phase.complete': 'Completed',
  'status.actionFilled': '{label} added to the composer', 'status.actionFailed': 'Failed to add {label}',
  'status.goalCreating': 'Creating long-term task', 'status.goalCreated': 'Long-term task created', 'status.goalFailed': 'Failed to create long-term task',
  'error.sessionUnavailable': 'Matter session is unavailable', 'error.conversationUnavailable': 'Conversation service is unavailable',
  'status.saving': 'Saving', 'status.saved': 'Saved', 'status.saveFailed': 'Save failed',
  'status.clearingKey': 'Clearing API key', 'status.keyCleared': 'API key cleared', 'status.clearFailed': 'Clear failed',
  'config.matterType': 'Matter type', 'config.recommended': 'Recommended: {label}', 'config.manual': 'Manually selected', 'config.currentType': 'Current type',
  'config.add': 'Add', 'config.newAction': 'New action', 'config.actionName': 'Quick action {index} name', 'config.actionPrompt': 'Quick action {index} prompt',
  'config.deleteAction': 'Delete quick action {index}', 'config.confirmDeleteAction': 'Confirm deletion of quick action {index}', 'action.delete': 'Delete', 'action.confirmDelete': 'Confirm delete',
  'config.ocrModel': 'OCR model', 'config.keyConfigured': 'API key configured', 'config.keyMissing': 'API key not configured', 'config.model': 'Model',
  'config.modelPlaceholder': 'Name of an image-capable model', 'config.keepKey': 'Leave blank to keep the existing key', 'config.enterKey': 'Enter the model provider API key',
  'config.maxPages': 'Max pages', 'config.outputTokens': 'Output tokens', 'config.timeoutMs': 'Timeout (ms)', 'config.clearKey': 'Clear API key', 'config.save': 'Save settings',
  'preview.aria': 'Document preview', 'preview.close': 'Close document preview', 'preview.unsupported': 'Preview is unavailable for this format',
  'pdf.scanned': 'Scanned', 'pdf.text': 'Text PDF', 'pdf.mixed': 'Mixed PDF', 'pdf.unknown': 'Unknown', 'pdf.ocrCurrent': ' · OCR available',
}

export const SERVER_LABEL_EN: Record<string, string> = {
  '自动识别': 'Automatic', '通用法律事项': 'General legal matter', '民商事诉讼': 'Civil and commercial litigation', '仲裁': 'Arbitration', '刑事': 'Criminal', '行政': 'Administrative',
  '投诉举报': 'Complaint and reporting', '合同审查': 'Contract review', '尽职调查': 'Due diligence', '法律顾问': 'Legal advisory', '专项非诉': 'Special non-contentious matter',
  '诉讼文书': 'Pleadings', '证据材料': 'Evidence', '法院及程序材料': 'Court and procedural files', '往来沟通': 'Correspondence', '法规与检索': 'Law and research', '费用与计算': 'Fees and calculations', '其他材料': 'Other files',
  '委托人与相关主体材料': 'Client and related-party identity documents', '委托、授权与利益冲突材料': 'Engagement, authorization, and conflict materials',
  '事项背景与事实材料': 'Background and factual materials', '关键往来与沟通记录': 'Key correspondence and communications',
  '工作目标与具体需求': 'Objectives and requirements', '分析、意见或交付成果': 'Analysis, advice, or deliverables',
  '诉讼请求、答辩意见或代理方案': 'Claims, defenses, or representation strategy', '证据材料与证明目的': 'Evidence and purposes of proof',
  '法院程序、送达与期限材料': 'Court procedure, service, and deadline materials', '仲裁请求、答辩意见或代理方案': 'Arbitration claims, defenses, or representation strategy',
  '仲裁程序、组庭与期限材料': 'Arbitration procedure, tribunal, and deadline materials', '案件阶段与强制措施材料': 'Case stage and compulsory-measure materials',
  '指控、证据与辩护材料': 'Charges, evidence, and defense materials', '会见、阅卷与办案记录': 'Client meetings, file review, and case notes',
  '行政行为及依据材料': 'Administrative act and legal-basis materials', '复议、诉讼或听证请求材料': 'Review, litigation, or hearing requests', '送达、期限与程序材料': 'Service, deadline, and procedural materials',
  '投诉举报请求与受理机关': 'Complaint requests and receiving authority', '交易、产品服务与证明材料': 'Transaction, product/service, and supporting materials', '沟通、处置与反馈记录': 'Communications, handling, and feedback',
  '待审合同及历次版本': 'Contract drafts and prior versions', '交易背景与商业条件': 'Transaction background and commercial terms', '风险问题与修改意见': 'Risk issues and revision comments',
  '尽调范围与资料清单': 'Due diligence scope and document request list', '目标主体与业务资料': 'Target entity and business materials', '核查发现、风险与报告': 'Findings, risks, and report',
  '顾问需求与咨询记录': 'Advisory requests and consultation records', '分析依据与研究材料': 'Legal bases and research', '法律意见与交付记录': 'Legal advice and delivery records',
  '专项范围与工作计划': 'Project scope and work plan', '交易、治理或申报材料': 'Transaction, governance, or filing materials', '专项成果与交付记录': 'Project deliverables and delivery records',
}

export const DEFAULT_ACTION_EN: Record<string, { label: string; prompt: string }> = {
  '案件梳理': { label: 'Matter review', prompt: 'Review all files in the current matter. Separate confirmed facts, client statements, inferences, and issues requiring verification, then identify disputed issues and next steps.' },
  '材料缺口': { label: 'Missing files', prompt: 'Review the completeness of the current matter files. List missing identity, factual, claim-supporting, procedural, and authorization materials, with priorities.' },
  '证据目录': { label: 'Evidence index', prompt: 'Prepare an evidence index from the current matter files. For each item, state its name, source file, and purpose of proof, and save it as 工作成果/证据目录.docx.' },
  '文书起草': { label: 'Draft document', prompt: 'Determine which legal document should be drafted first from the current matter files. If information is missing, list questions to confirm; otherwise save the draft as 工作成果/文书初稿.docx.' },
  '期限核查': { label: 'Deadline review', prompt: 'Review procedural deadline candidates in the current matter. For each, identify its source location, date basis, open verification issues, and risk. Do not treat automatically detected dates as legal deadlines.' },
  'OCR 扫描件': { label: 'OCR scans', prompt: 'Identify scanned PDFs or images in the current matter that have no extractable text. Run OCR and save reviewed results under 工作成果/OCR using the original filenames.' },
}

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'legal-office': LegalOfficeLocaleKey
  }
}
