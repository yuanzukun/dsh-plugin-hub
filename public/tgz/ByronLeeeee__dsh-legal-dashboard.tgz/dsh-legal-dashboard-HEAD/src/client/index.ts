import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { IConversation } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import { CaseButton, LegalWorkspaceOverlay } from './LegalOfficePanel.tsx'
import { en, LEGAL_OFFICE_NS, zh } from './locales.ts'

export const inject = ['slots', 'locale', 'sessions', 'conversation']

interface WorkbenchSnapshot {
  open: boolean
  width: number
}

class WorkbenchController {
  private snapshot: WorkbenchSnapshot = { open: false, width: 360 }
  private readonly listeners = new Set<() => void>()

  readonly getSnapshot = (): WorkbenchSnapshot => this.snapshot
  readonly subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  readonly toggle = (): void => {
    this.update({ ...this.snapshot, open: !this.snapshot.open })
  }

  readonly resize = (width: number): void => {
    if (this.snapshot.width === width) return
    this.update({ ...this.snapshot, width })
  }

  private update(next: WorkbenchSnapshot): void {
    this.snapshot = next
    document.documentElement.style.setProperty('--legal-office-width', `${next.width}px`)
    if (next.open) document.body.setAttribute('data-legal-office-open', 'true')
    else document.body.removeAttribute('data-legal-office-open')
    for (const listener of this.listeners) listener()
  }

  readonly dispose = (): void => {
    document.body.removeAttribute('data-legal-office-open')
    document.documentElement.style.removeProperty('--legal-office-width')
    this.listeners.clear()
  }
}

export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(LEGAL_OFFICE_NS, { zh, en }), 'legal-office: locale dictionaries')
  const t = ctx.locale.bind(LEGAL_OFFICE_NS)
  const workbench = new WorkbenchController()
  ctx.effect(() => workbench.dispose, 'legal-office: restore shell layout')

  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'legal-office-dashboard',
    order: 20,
    label: '案件台',
    locale: LEGAL_OFFICE_NS,
    inject: () => ({ toggle: workbench.toggle }),
  }, CaseButton))

  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'legal-office-workspace',
    order: 0,
    locale: LEGAL_OFFICE_NS,
    inject: () => ({
      controller: workbench,
      projectionFace: (sessionId: SessionId, key: string) => ctx.sessions.binding(sessionId)?.session.projections.faceOf(key),
      fillDraft: (sessionId: SessionId, prompt: string) => {
        const actx = ctx.sessions.scope(sessionId)
        if (actx === undefined) throw new Error(t('error.sessionUnavailable'))
        const conversation = actx.get('conversation') as IConversation | undefined
        if (conversation === undefined) throw new Error(t('error.conversationUnavailable'))
        const input = conversation.input.for(actx)
        const current = input.state.getSnapshot().draft
        input.setDraft(current.trim() === '' ? prompt : `${current}\n\n${prompt}`)
      },
      createGoal: async (sessionId: SessionId, objective: string) => {
        const session = ctx.sessions.binding(sessionId)?.session
        if (session === undefined) throw new Error(t('error.sessionUnavailable'))
        const result = await session.command(`/goal ${objective}`)
        if (!result.ok) throw new Error(result.error?.message ?? t('status.goalFailed'))
      },
    }),
  }, LegalWorkspaceOverlay))
}
