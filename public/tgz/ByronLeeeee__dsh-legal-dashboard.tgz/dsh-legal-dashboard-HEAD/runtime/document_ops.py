from __future__ import annotations

import json
import os
import re
import sys
from pathlib import Path


def fail(message: str) -> None:
    raise RuntimeError(message)


def markdown_blocks(content: str):
    for raw in content.replace("\r\n", "\n").split("\n"):
        line = raw.rstrip()
        if not line:
            yield ("blank", "")
        elif line.startswith("### "):
            yield ("heading3", line[4:])
        elif line.startswith("## "):
            yield ("heading2", line[3:])
        elif line.startswith("# "):
            yield ("heading1", line[2:])
        elif re.match(r"^[-*]\s+", line):
            yield ("bullet", re.sub(r"^[-*]\s+", "", line))
        elif re.match(r"^\d+[.)]\s+", line):
            yield ("number", re.sub(r"^\d+[.)]\s+", "", line))
        else:
            yield ("paragraph", line)


def create_docx(request: dict) -> dict:
    from docx import Document
    from docx.enum.section import WD_SECTION
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt, RGBColor

    output = Path(request["output"])
    document = Document()
    section = document.sections[0]
    section.top_margin = Cm(2.54)
    section.bottom_margin = Cm(2.54)
    section.left_margin = Cm(3.0)
    section.right_margin = Cm(2.6)

    styles = document.styles
    normal = styles["Normal"]
    normal.font.name = "SimSun"
    normal._element.rPr.rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(12)
    normal.paragraph_format.line_spacing = 1.5
    normal.paragraph_format.first_line_indent = Cm(0.74)
    normal.paragraph_format.space_after = Pt(0)
    for style_name, font_name, size in (("Title", "SimHei", 22), ("Heading 1", "SimHei", 16), ("Heading 2", "SimHei", 14), ("Heading 3", "SimHei", 12)):
        style = styles[style_name]
        style.font.name = font_name
        style._element.rPr.rFonts.set(qn("w:eastAsia"), "黑体")
        style.font.size = Pt(size)
        style.font.color.rgb = RGBColor(0, 0, 0)
        paragraph_properties = style._element.pPr
        if paragraph_properties is not None:
            borders = paragraph_properties.find(qn("w:pBdr"))
            if borders is not None:
                paragraph_properties.remove(borders)

    title = str(request.get("title", "")).strip()
    if title:
        paragraph = document.add_paragraph(title, style="Title")
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for kind, text in markdown_blocks(str(request.get("content", ""))):
        if kind == "blank":
            document.add_paragraph("")
        elif kind.startswith("heading"):
            document.add_paragraph(text, style=f"Heading {kind[-1]}")
        elif kind == "bullet":
            document.add_paragraph(text, style="List Bullet")
        elif kind == "number":
            document.add_paragraph(text, style="List Number")
        else:
            paragraph = document.add_paragraph(text)
            paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY

    core = document.core_properties
    core.title = title
    core.subject = "律师工作文稿"
    document.save(output)
    return {"operation": "create", "format": "docx", "outputPath": str(output), "paragraphs": len(document.paragraphs)}


def find_cjk_font():
    candidates = [
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts/msyh.ttc",
        Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts/simsun.ttc",
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
        Path("/System/Library/Fonts/PingFang.ttc"),
    ]
    return next((item for item in candidates if item.exists()), None)


def create_pdf(request: dict) -> dict:
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import cm
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import ListFlowable, ListItem, Paragraph, SimpleDocTemplate, Spacer

    output = Path(request["output"])
    font_name = "Helvetica"
    cjk = find_cjk_font()
    if cjk is not None:
        font_name = "LegalCJK"
        pdfmetrics.registerFont(TTFont(font_name, str(cjk), subfontIndex=0))
    styles = getSampleStyleSheet()
    body = ParagraphStyle("LegalBody", parent=styles["BodyText"], fontName=font_name, fontSize=12, leading=21, alignment=TA_JUSTIFY, firstLineIndent=24, spaceAfter=0)
    title_style = ParagraphStyle("LegalTitle", parent=styles["Title"], fontName=font_name, fontSize=22, leading=32, alignment=TA_CENTER, spaceAfter=18)
    headings = {i: ParagraphStyle(f"LegalH{i}", parent=styles[f"Heading{i}"], fontName=font_name, fontSize=18 - i * 2, leading=26 - i * 2, spaceBefore=12, spaceAfter=6) for i in (1, 2, 3)}
    story = []
    title = str(request.get("title", "")).strip()
    if title:
        story.append(Paragraph(title, title_style))
    for kind, text in markdown_blocks(str(request.get("content", ""))):
        safe = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        if kind == "blank":
            story.append(Spacer(1, 8))
        elif kind.startswith("heading"):
            story.append(Paragraph(safe, headings[int(kind[-1])]))
        elif kind in ("bullet", "number"):
            story.append(ListFlowable([ListItem(Paragraph(safe, body))], bulletType="bullet" if kind == "bullet" else "1", leftIndent=24))
        else:
            story.append(Paragraph(safe, body))
    doc = SimpleDocTemplate(str(output), pagesize=A4, rightMargin=2.6 * cm, leftMargin=3.0 * cm, topMargin=2.54 * cm, bottomMargin=2.54 * cm, title=title, author="法律办公工作台")
    doc.build(story)
    return {"operation": "create", "format": "pdf", "outputPath": str(output)}


def extract(request: dict) -> dict:
    source = Path(request["input"])
    if source.suffix.lower() == ".docx":
        from docx import Document
        document = Document(source)
        chunks = [paragraph.text for paragraph in document.paragraphs]
        for table in document.tables:
            chunks.extend("\t".join(cell.text for cell in row.cells) for row in table.rows)
        text = "\n".join(chunk for chunk in chunks if chunk.strip())
    elif source.suffix.lower() == ".pdf":
        from pypdf import PdfReader
        reader = PdfReader(source)
        text = "\n\n".join(page.extract_text() or "" for page in reader.pages)
    else:
        fail("extract supports .docx and .pdf")
    return {"operation": "extract", "inputPath": str(source), "text": text[: request.get("maxCharacters", 100000)], "truncated": len(text) > request.get("maxCharacters", 100000)}


def classify_pdfs(request: dict) -> dict:
    from pypdf import PdfReader

    documents = []
    sample_pages = max(1, min(int(request.get("samplePages", 5)), 20))
    for item in request.get("documents", []):
        source = Path(item["input"])
        result = {"path": item["path"], "kind": "unknown", "pages": 0, "sampledPages": 0, "textCharacters": 0}
        try:
            reader = PdfReader(source)
            pages = len(reader.pages)
            counts = []
            large_image_pages = 0
            for page in reader.pages[:sample_pages]:
                text = page.extract_text() or ""
                counts.append(len(re.sub(r"\s+", "", text)))
                try:
                    if any((image.image.width * image.image.height) >= 1_000_000 for image in page.images):
                        large_image_pages += 1
                except Exception:
                    pass
            total = sum(counts)
            dense_text_pages = sum(1 for count in counts if count >= 80)
            bytes_per_page = source.stat().st_size // max(pages, 1)
            average_text = total / max(len(counts), 1)
            if not counts:
                kind = "unknown"
            elif total < 20:
                kind = "scanned"
            elif large_image_pages >= max(1, (len(counts) + 1) // 2):
                kind = "scanned"
            elif average_text < 80 and bytes_per_page >= 250_000:
                kind = "scanned"
            elif large_image_pages == 0 and bytes_per_page < 250_000:
                kind = "text"
            elif dense_text_pages == len(counts) or average_text >= 160:
                kind = "text"
            else:
                kind = "mixed"
            result.update({
                "kind": kind,
                "pages": pages,
                "sampledPages": len(counts),
                "textCharacters": total,
                "largeImagePages": large_image_pages,
                "bytesPerPage": bytes_per_page,
            })
        except Exception as error:
            result["error"] = str(error)[:300]
        documents.append(result)
    return {"operation": "classify_pdfs", "documents": documents}


def extract_samples(request: dict) -> dict:
    documents = []
    max_characters = int(request.get("maxCharacters", 50000))
    for item in request.get("documents", []):
        try:
            result = extract({"input": item["input"], "maxCharacters": max_characters})
            documents.append({"path": item["path"], "text": result["text"], "truncated": result["truncated"]})
        except Exception as error:
            documents.append({"path": item["path"], "text": "", "error": str(error)[:300]})
    return {"operation": "extract_samples", "documents": documents}


def edit_docx(request: dict) -> dict:
    from docx import Document
    source = Path(request["input"])
    output = Path(request["output"])
    document = Document(source)
    replacements = request.get("replacements", [])
    counts = {item["find"]: 0 for item in replacements}

    def replace_paragraph(paragraph):
        original = paragraph.text
        updated = original
        for item in replacements:
            count = updated.count(item["find"])
            if count:
                updated = updated.replace(item["find"], item["replace"])
                counts[item["find"]] += count
        if updated != original:
            for run in paragraph.runs:
                run.text = ""
            if paragraph.runs:
                paragraph.runs[0].text = updated
            else:
                paragraph.add_run(updated)

    for paragraph in document.paragraphs:
        replace_paragraph(paragraph)
    for table in document.tables:
        for row in table.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    replace_paragraph(paragraph)
    if request.get("requireAll", True):
        missing = [key for key, count in counts.items() if count == 0]
        if missing:
            fail("text not found: " + ", ".join(missing))
    document.save(output)
    return {"operation": "edit", "format": "docx", "inputPath": str(source), "outputPath": str(output), "replacementCounts": counts}


def prepare_ocr(request: dict) -> dict:
    from PIL import Image, ImageOps

    source = Path(request["input"])
    output_dir = Path(request["outputDir"])
    output_dir.mkdir(parents=True, exist_ok=True)
    max_pages = int(request.get("maxPages", 30))
    paths = []
    if source.suffix.lower() == ".pdf":
        import pypdfium2 as pdfium
        pdf = pdfium.PdfDocument(str(source))
        for index in range(min(len(pdf), max_pages)):
            image = pdf[index].render(scale=2.2).to_pil().convert("RGB")
            target = output_dir / f"page-{index + 1:04d}.png"
            image.save(target, "PNG", optimize=True)
            paths.append(str(target))
        total_pages = len(pdf)
    else:
        image = ImageOps.exif_transpose(Image.open(source)).convert("RGB")
        target = output_dir / "page-0001.png"
        image.save(target, "PNG", optimize=True)
        paths.append(str(target))
        total_pages = 1
    return {"operation": "prepare_ocr", "inputPath": str(source), "pages": paths, "totalPages": total_pages, "truncated": total_pages > len(paths)}


def main() -> None:
    request = json.load(sys.stdin)
    operation = request.get("operation")
    if operation == "create":
        result = create_docx(request) if request.get("format") == "docx" else create_pdf(request)
    elif operation == "extract":
        result = extract(request)
    elif operation == "classify_pdfs":
        result = classify_pdfs(request)
    elif operation == "extract_samples":
        result = extract_samples(request)
    elif operation == "edit":
        result = edit_docx(request)
    elif operation == "prepare_ocr":
        result = prepare_ocr(request)
    else:
        fail("unsupported document operation")
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(str(error), file=sys.stderr)
        raise SystemExit(1)
