import assert from 'node:assert/strict'
import test from 'node:test'
import { formatOcrMarkdown, recognizePage } from '../src/ocr-provider.js'

test('OpenAI-compatible OCR sends a high-detail data URL and returns text', async () => {
  let captured
  const text = await recognizePage({
    baseURL: 'https://vision.example/v1/',
    model: 'vision-model',
    apiKey: 'secret-value',
    bytes: Buffer.from('page-image'),
    mimeType: 'image/png',
    pageNumber: 2,
    timeoutMs: 1000,
    fetchImpl: async (url, init) => {
      captured = { url, init, body: JSON.parse(init.body) }
      return new Response(JSON.stringify({ choices: [{ message: { content: '识别结果' } }] }), {
        status: 200, headers: { 'Content-Type': 'application/json' },
      })
    },
  })

  assert.equal(text, '识别结果')
  assert.equal(captured.url, 'https://vision.example/v1/chat/completions')
  assert.equal(captured.init.headers.Authorization, 'Bearer secret-value')
  assert.equal(captured.body.model, 'vision-model')
  assert.equal(captured.body.messages[1].content[1].image_url.detail, 'high')
  assert.match(captured.body.messages[1].content[1].image_url.url, /^data:image\/png;base64,/u)
})

test('OCR markdown preserves page boundaries and truncation notice', () => {
  const markdown = formatOcrMarkdown(['第一页', '第二页'], { sourcePath: '证据/扫描件.pdf', truncated: true })
  assert.match(markdown, /^# 证据\/扫描件\.pdf/u)
  assert.match(markdown, /## 第 1 页\n\n第一页/u)
  assert.match(markdown, /## 第 2 页\n\n第二页/u)
  assert.match(markdown, /未包含全部页面/u)
})

test('OCR provider errors do not expose a successful empty response', async () => {
  await assert.rejects(recognizePage({
    baseURL: 'https://vision.example/v1', model: 'vision-model', bytes: Buffer.from('x'), pageNumber: 1,
    fetchImpl: async () => new Response('{"error":"bad request"}', { status: 400 }),
  }), /request failed \(400\)/u)
})
