import assert from 'node:assert/strict'
import { mkdir, mkdtemp, rm, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import test from 'node:test'
import { legalCaseDashboard, projectOverview, searchProject, walkProject } from '../src/project-scan.js'

async function fixture(run) {
  const root = await mkdtemp(path.join(tmpdir(), 'dsh-legal-office-'))
  try {
    await mkdir(path.join(root, '证据'))
    await mkdir(path.join(root, '.git'))
    await writeFile(path.join(root, '案情.md'), '劳动合同争议\n解除日期：2026-08-01\n', 'utf8')
    await writeFile(path.join(root, '证据', '工资.csv'), '月份,金额\n七月,10000\n', 'utf8')
    await writeFile(path.join(root, '.git', 'secret.txt'), 'must not be found', 'utf8')
    await run(root)
  } finally {
    await rm(root, { recursive: true, force: true })
  }
}

test('walkProject excludes configured directories', async () => {
  await fixture(async (root) => {
    const walked = await walkProject(root, { maxFiles: 20, excludedDirectories: ['.git'] })
    assert.deepEqual(walked.files.map(file => file.relative), ['案情.md', '证据/工资.csv'])
    assert.equal(walked.directoryCount, 1)
  })
})

test('projectOverview reports project totals and extensions', async () => {
  await fixture(async (root) => {
    const overview = await projectOverview(root, { maxFiles: 20, excludedDirectories: ['.git'] })
    assert.equal(overview.title, path.basename(root))
    assert.equal(overview.files, 2)
    assert.deepEqual(overview.byExtension, [
      { extension: '.csv', count: 1 },
      { extension: '.md', count: 1 },
    ])
  })
})

test('searchProject returns filename and line-located content matches', async () => {
  await fixture(async (root) => {
    const content = await searchProject(root, '解除日期', {
      maxFiles: 20,
      maxResults: 10,
      maxFileBytes: 1024,
      excludedDirectories: ['.git'],
    })
    assert.equal(content.results.length, 1)
    assert.deepEqual(content.results[0], {
      kind: 'content',
      path: '案情.md',
      line: 2,
      column: 1,
      snippet: '解除日期：2026-08-01',
    })

    const filename = await searchProject(root, '工资', {
      maxFiles: 20,
      maxResults: 10,
      maxFileBytes: 1024,
      excludedDirectories: ['.git'],
    })
    assert.equal(filename.results[0].kind, 'filename')
    assert.equal(filename.results[0].path, '证据/工资.csv')
  })
})

test('legalCaseDashboard classifies materials and extracts deadline candidates', async () => {
  await fixture(async (root) => {
    await writeFile(path.join(root, '证据', '劳动合同.pdf'), 'binary-placeholder', 'utf8')
    const dashboard = await legalCaseDashboard(root, {
      maxFiles: 20,
      maxFileBytes: 1024,
      excludedDirectories: ['.git'],
    })
    assert.equal(dashboard.categories.find(item => item.key === 'evidence')?.count, 2)
    assert.deepEqual(dashboard.deadlines.map(item => item.date), ['2026-08-01'])
    assert.equal(dashboard.checklist.find(item => item.key === 'evidence')?.present, true)
    assert.equal(dashboard.checklist.find(item => item.key === 'court')?.present, false)
  })
})

test('walkProject does not traverse symbolic links', async (t) => {
  if (process.platform === 'win32') {
    t.skip('creating directory symlinks requires Windows developer mode or elevation')
    return
  }
  await fixture(async (root) => {
    const outside = await mkdtemp(path.join(tmpdir(), 'dsh-legal-outside-'))
    try {
      await writeFile(path.join(outside, 'outside.txt'), 'private', 'utf8')
      await symlink(outside, path.join(root, 'linked'), 'dir')
      const walked = await walkProject(root, { maxFiles: 20, excludedDirectories: ['.git'] })
      assert.equal(walked.files.some(file => file.relative.includes('outside.txt')), false)
    } finally {
      await rm(outside, { recursive: true, force: true })
    }
  })
})
