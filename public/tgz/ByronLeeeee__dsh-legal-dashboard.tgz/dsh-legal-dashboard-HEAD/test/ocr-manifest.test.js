import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import test from 'node:test'
import { freshOcrResult, recordOcrResult } from '../src/ocr-manifest.js'

test('OCR manifest reuses only results matching the current source signature', async t => {
  const root = await mkdtemp(path.join(tmpdir(), 'legal-ocr-manifest-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  await writeFile(path.join(root, '扫描.pdf'), 'first')
  await writeFile(path.join(root, '结果.md'), 'ocr')
  await recordOcrResult(root, '扫描.pdf', { outputPath: '结果.md', pages: 1, provider: { model: 'vision' } })
  assert.equal((await freshOcrResult(root, '扫描.pdf'))?.outputPath, '结果.md')
  await new Promise(resolve => setTimeout(resolve, 10))
  await writeFile(path.join(root, '扫描.pdf'), 'changed')
  assert.equal(await freshOcrResult(root, '扫描.pdf'), undefined)
})
