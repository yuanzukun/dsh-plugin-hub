import assert from 'node:assert/strict'
import { mkdtemp, rm, stat } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import test from 'node:test'

import { resolveWorkspaceOutput, runDocumentOperation } from '../src/document-runtime.js'

test('document runtime creates, reads, and revises DOCX', async t => {
  const root = await mkdtemp(path.join(tmpdir(), 'legal-doc-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const original = await resolveWorkspaceOutput(root, '文书/起诉状.docx', ['.docx'])
  const created = await runDocumentOperation('auto', {
    operation: 'create', format: 'docx', output: original,
    title: '民事起诉状', content: '## 诉讼请求\n1. 请求判令被告支付款项。\n\n## 事实与理由\n原告主张待核实。',
  })
  assert.equal(created.format, 'docx')
  assert.equal((await stat(original)).size > 1000, true)

  const extracted = await runDocumentOperation('auto', { operation: 'extract', input: original, maxCharacters: 10000 })
  assert.match(extracted.text, /请求判令被告支付款项/u)

  const revision = await resolveWorkspaceOutput(root, '文书/起诉状-修订.docx', ['.docx'])
  const edited = await runDocumentOperation('auto', {
    operation: 'edit', input: original, output: revision,
    replacements: [{ find: '待核实', replace: '以证据为准' }], requireAll: true,
  })
  assert.equal(edited.replacementCounts['待核实'], 1)
  const revisedText = await runDocumentOperation('auto', { operation: 'extract', input: revision, maxCharacters: 10000 })
  assert.match(revisedText.text, /以证据为准/u)
})

test('document runtime creates an extractable PDF with Chinese text', async t => {
  const root = await mkdtemp(path.join(tmpdir(), 'legal-pdf-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const output = await resolveWorkspaceOutput(root, '法律意见.pdf', ['.pdf'])
  await runDocumentOperation('auto', {
    operation: 'create', format: 'pdf', output,
    title: '法律意见书', content: '## 初步结论\n现有材料不足，关键事实待核实。',
  })
  assert.equal((await stat(output)).size > 1000, true)
  const extracted = await runDocumentOperation('auto', { operation: 'extract', input: output, maxCharacters: 10000 })
  assert.match(extracted.text, /关键事实待核实/u)
  const classified = await runDocumentOperation('auto', {
    operation: 'classify_pdfs', samplePages: 5,
    documents: [{ input: output, path: '法律意见.pdf' }],
  })
  assert.equal(classified.documents[0].path, '法律意见.pdf')
  assert.equal(classified.documents[0].kind, 'text')
  assert.equal(classified.documents[0].pages, 1)
})

test('document outputs cannot escape the workspace', async t => {
  const root = await mkdtemp(path.join(tmpdir(), 'legal-output-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  await assert.rejects(resolveWorkspaceOutput(root, '../outside.docx', ['.docx']), /escapes/)
  await assert.rejects(resolveWorkspaceOutput(root, 'draft.exe', ['.docx']), /must end with/)
})

test('OCR preparation renders PDF pages to ordered PNG files', async t => {
  const root = await mkdtemp(path.join(tmpdir(), 'legal-ocr-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const source = await resolveWorkspaceOutput(root, '扫描件.pdf', ['.pdf'])
  await runDocumentOperation('auto', {
    operation: 'create', format: 'pdf', output: source,
    title: '证据材料', content: '第一页内容。',
  })
  const prepared = await runDocumentOperation('auto', {
    operation: 'prepare_ocr', input: source, outputDir: path.join(root, '.legal-ocr', '扫描件'), maxPages: 10,
  })
  assert.equal(prepared.totalPages, 1)
  assert.equal(prepared.pages.length, 1)
  assert.equal(path.basename(prepared.pages[0]), 'page-0001.png')
  assert.equal((await stat(prepared.pages[0])).size > 1000, true)
})
