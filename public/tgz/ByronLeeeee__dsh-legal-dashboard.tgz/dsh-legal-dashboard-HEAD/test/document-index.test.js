import assert from 'node:assert/strict'
import { mkdtemp, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import test from 'node:test'

import { buildDocumentIndex, searchDocumentIndex } from '../src/document-index.js'
import { resolveWorkspaceOutput, runDocumentOperation } from '../src/document-runtime.js'

test('document index extracts, reuses, and searches DOCX/PDF content', async t => {
  const root = await mkdtemp(path.join(tmpdir(), 'legal-index-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  const docx = await resolveWorkspaceOutput(root, '合同.docx', ['.docx'])
  const pdf = await resolveWorkspaceOutput(root, '意见.pdf', ['.pdf'])
  await runDocumentOperation('auto', { operation: 'create', format: 'docx', output: docx, title: '合同', content: '付款期限为收到发票后十日。' })
  await runDocumentOperation('auto', { operation: 'create', format: 'pdf', output: pdf, title: '意见', content: '管辖条款需要进一步核实。' })

  const first = await buildDocumentIndex(root, { maxFiles: 20, excludedDirectories: ['.legal-index'], pythonExecutable: 'auto' })
  assert.deepEqual({ indexed: first.indexed, extracted: first.extracted, reused: first.reused }, { indexed: 2, extracted: 2, reused: 0 })
  const result = await searchDocumentIndex(root, '管辖条款', 10)
  assert.equal(result.results[0].path, '意见.pdf')

  const second = await buildDocumentIndex(root, { maxFiles: 20, excludedDirectories: ['.legal-index'], pythonExecutable: 'auto' })
  assert.deepEqual({ extracted: second.extracted, reused: second.reused }, { extracted: 0, reused: 2 })
})
