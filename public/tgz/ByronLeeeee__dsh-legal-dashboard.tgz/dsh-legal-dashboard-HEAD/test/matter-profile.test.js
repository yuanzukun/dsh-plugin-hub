import assert from 'node:assert/strict'
import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import test from 'node:test'
import { analyzeWorkspaceMatter } from '../src/matter-profile.js'

test('matter profile uses document content and builds a non-litigation checklist', async t => {
  const root = await mkdtemp(path.join(tmpdir(), 'legal-matter-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  await writeFile(path.join(root, '材料.txt'), '本项目为目标公司尽职调查，需形成尽调范围、资料清单、风险清单和尽调报告。', 'utf8')
  const result = await analyzeWorkspaceMatter(root, { matterType: 'auto', excludedDirectories: [] }, [])
  assert.equal(result.selectedType, 'due-diligence')
  assert.equal(result.checklist.some(item => item.key === 'findings'), true)
  assert.equal(result.checklist.find(item => item.key === 'findings')?.status, 'confirmed')
})

test('manual matter type overrides the recommendation', async t => {
  const root = await mkdtemp(path.join(tmpdir(), 'legal-matter-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  await writeFile(path.join(root, '起诉材料.txt'), '原告准备向法院起诉被告。', 'utf8')
  const result = await analyzeWorkspaceMatter(root, { matterType: 'contract-review', excludedDirectories: [] }, [])
  assert.equal(result.selectedType, 'contract-review')
  assert.equal(result.recommendedType, 'litigation')
})
