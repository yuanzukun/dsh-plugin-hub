import assert from 'node:assert/strict'
import { Context } from '@deepseek-ai/cordis'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import test from 'node:test'
import * as LegalOffice from '../src/index.js'

const config = {
  maxFiles: 100,
  maxSearchFileBytes: 1024 * 1024,
  defaultMaxResults: 5,
  excludedDirectories: ['.git', 'node_modules'],
  pythonExecutable: 'auto',
}

async function runtime(overrides = {}) {
  const ctx = new Context()
  await ctx.plugin(SystemPrompt, { persona: '' })
  await ctx.plugin(ToolRuntime, { mode: 'native', maxParallelSubCalls: 10 })
  await ctx.plugin(LegalOffice, { ...config, ...overrides })
  return ctx
}

function testAgent(ctx) {
  return {
    ctx,
    session: {
      header: { cwd: process.cwd() },
      append() {},
    },
  }
}

test('plugin contributes legal prompt, workspace context, and tools', async () => {
  const ctx = await runtime()
  const agent = testAgent(ctx)
  const assembly = await ctx.systemPrompt.assemble({ agent })
  assert.equal(assembly.sections.some(section => section.name === 'legal-office:persona'), true)
  assert.match(
    assembly.contexts.find(context => context.name === 'legal-office:workspace')?.text ?? '',
    /Workspace root:/u,
  )
  assert.deepEqual(
    assembly.tools.map(tool => tool.name).filter(name => name.startsWith('legal_')),
    ['legal_case_dashboard', 'legal_deadline_scan', 'legal_document_create', 'legal_document_edit', 'legal_document_extract', 'legal_index_build', 'legal_index_search', 'legal_ocr_prepare', 'legal_ocr_run', 'legal_ocr_save', 'legal_project_overview', 'legal_project_search'],
  )
})

test('configured external OCR contributes a guarded OCR tool', async () => {
  const ctx = await runtime({
    ocrBaseURL: 'https://vision.example/v1',
    ocrModel: 'vision-model',
    ocrApiKeyEnv: 'TEST_OCR_KEY',
    ocrMaxPages: 5,
    ocrMaxTokens: 2048,
    ocrTimeoutMs: 5000,
  })
  const assembly = await ctx.systemPrompt.assemble({ agent: testAgent(ctx) })
  assert.equal(assembly.tools.some(tool => tool.name === 'legal_ocr_run'), true)

  const result = await ctx.tools.execute({
    callId: 'legal-office-ocr-approval',
    name: 'legal_ocr_run',
    arguments: { inputPath: 'private.pdf', outputPath: 'private-OCR.md' },
    signal: new AbortController().signal,
    agent: testAgent(ctx),
  })
  assert.equal(result.isError, true)
  assert.match(result.error?.message ?? '', /外部多模态模型/u)
})

test('legal_project_search executes through the Harness tool pipeline', async () => {
  const ctx = await runtime()
  const result = await ctx.tools.execute({
    callId: 'legal-office-test-call',
    name: 'legal_project_search',
    arguments: { query: 'workspace' },
    signal: new AbortController().signal,
    agent: testAgent(ctx),
  })
  assert.notEqual(result.isError, true)
  const payload = JSON.parse(result.content[0].text)
  assert.equal(payload.query, 'workspace')
  assert.equal(payload.results.length > 0, true)
})

test('tool calls without a folder workspace fail closed', async () => {
  const ctx = await runtime()
  const result = await ctx.tools.execute({
    callId: 'legal-office-no-workspace',
    name: 'legal_project_overview',
    arguments: {},
    signal: new AbortController().signal,
  })
  assert.equal(result.isError, true)
  assert.match(result.error?.message ?? '', /attached to a folder workspace/u)
})
