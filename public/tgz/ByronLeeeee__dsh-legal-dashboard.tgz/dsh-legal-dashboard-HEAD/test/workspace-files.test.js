import assert from 'node:assert/strict'
import { mkdtemp, mkdir, rm, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'
import test from 'node:test'

import { readWorkspaceFile, resolveWorkspaceFile, workspaceTree } from '../src/workspace-files.js'

async function fixture(t) {
  const root = await mkdtemp(path.join(tmpdir(), 'dsh-legal-office-'))
  t.after(async () => { await rm(root, { recursive: true, force: true }) })
  await mkdir(path.join(root, '材料'))
  await writeFile(path.join(root, '案情.md'), '# 案情')
  await writeFile(path.join(root, '材料', '证据.json'), '{"有效":true}')
  return root
}

test('workspaceTree returns portable, typed nodes', async t => {
  const root = await fixture(t)
  const result = await workspaceTree(root)
  assert.equal(result.truncated, false)
  assert.deepEqual(result.nodes.map(node => [node.type, node.path, node.depth, node.mime]), [
    ['directory', '材料', 0, undefined],
    ['file', '材料/证据.json', 1, 'application/json; charset=utf-8'],
    ['file', '案情.md', 0, 'text/markdown; charset=utf-8'],
  ])
})

test('workspace files cannot escape the registered root', async t => {
  const root = await fixture(t)
  await assert.rejects(resolveWorkspaceFile(root, '../outside.txt'), /escapes workspace/)
  await assert.rejects(resolveWorkspaceFile(root, path.resolve(root, '案情.md')), /workspace-relative/)
  await assert.rejects(resolveWorkspaceFile(root, ''), /workspace-relative/)
  await assert.rejects(resolveWorkspaceFile(root, '材料'), /regular workspace file/)
})

test('readWorkspaceFile returns bytes and a safe MIME type', async t => {
  const root = await fixture(t)
  const result = await readWorkspaceFile(root, '案情.md')
  assert.equal(result.bytes.toString('utf8'), '# 案情')
  assert.equal(result.mime, 'text/markdown; charset=utf-8')
})

test('symlinks are excluded from trees and direct reads', async t => {
  const root = await fixture(t)
  const target = path.join(root, '案情.md')
  const link = path.join(root, '案情链接.md')
  try {
    await symlink(target, link, 'file')
  } catch (error) {
    if (error?.code === 'EPERM') return t.skip('Windows symlink privilege is unavailable')
    throw error
  }
  const result = await workspaceTree(root)
  assert.equal(result.nodes.some(node => node.name === '案情链接.md'), false)
  await assert.rejects(resolveWorkspaceFile(root, '案情链接.md'), /not a regular workspace file/)
})
