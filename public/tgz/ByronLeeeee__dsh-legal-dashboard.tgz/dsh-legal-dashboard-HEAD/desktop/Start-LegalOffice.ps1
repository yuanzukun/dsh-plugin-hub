[CmdletBinding()]
param(
  [int]$Port = 3080,
  [switch]$KeepServer
)

$ErrorActionPreference = 'Stop'
$pluginRoot = Split-Path -Parent $PSScriptRoot
$harnessRoot = Join-Path (Split-Path -Parent $pluginRoot) 'deepseek-harness-master'
$cli = Join-Path $harnessRoot 'apps\cli\lib\bin.js'
$nodeCandidates = @(
  (Join-Path $env:ProgramFiles 'nodejs\node.exe'),
  (Get-Command node -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source -First 1)
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }
$edgeCandidates = @(
  (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
  (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) }

if (-not (Test-Path -LiteralPath $cli)) {
  throw "Harness CLI not found: $cli"
}
if ($nodeCandidates.Count -eq 0) {
  throw 'Node.js was not found.'
}
if ($edgeCandidates.Count -eq 0) {
  throw 'Microsoft Edge was not found.'
}

$node = $nodeCandidates[0]
$edge = $edgeCandidates[0]
$origin = "http://127.0.0.1:$Port/"
$startedServer = $false
$serverProcess = $null
$logDir = Join-Path $pluginRoot '.desktop'
New-Item -ItemType Directory -Path $logDir -Force | Out-Null

function Test-LegalOfficeServer {
  try {
    $response = Invoke-WebRequest -UseBasicParsing -Uri $origin -TimeoutSec 1
    return $response.StatusCode -eq 200
  } catch {
    return $false
  }
}

try {
  if (-not (Test-LegalOfficeServer)) {
    $serverProcess = Start-Process -FilePath $node -ArgumentList $cli, 'web' -WorkingDirectory $harnessRoot `
      -RedirectStandardOutput (Join-Path $logDir 'harness.stdout.log') `
      -RedirectStandardError (Join-Path $logDir 'harness.stderr.log') -WindowStyle Hidden -PassThru
    $startedServer = $true
    $ready = $false
    for ($attempt = 0; $attempt -lt 40; $attempt += 1) {
      Start-Sleep -Milliseconds 250
      if ($serverProcess.HasExited) {
        throw "Harness exited during startup. See $logDir\harness.stderr.log"
      }
      if (Test-LegalOfficeServer) { $ready = $true; break }
    }
    if (-not $ready) { throw "Harness did not become ready at $origin" }
  }

  $appProcess = Start-Process -FilePath $edge -ArgumentList "--app=$origin", '--no-first-run' -PassThru
  Wait-Process -Id $appProcess.Id
} finally {
  if ($startedServer -and -not $KeepServer -and $serverProcess -and -not $serverProcess.HasExited) {
    Stop-Process -Id $serverProcess.Id
  }
}
