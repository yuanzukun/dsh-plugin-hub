# Changelog

## v0.1.2 (2026-08-18)

- 修复桌面图标白板：创建快捷方式时把图标复制到 `<dshHome>/dsh-quick-launch/icons/active.ico` 永久保存，快捷方式引用稳定路径——插件更新/改名/卸载不再影响已创建快捷方式的图标

## v0.1.1 (2026-08-18)

- 客户端 UI 升级：DeepSeek 鲸鱼标悬浮按钮（蓝/白/金配色），可拖动定位并记忆位置；点击旋转 90° 从按钮弹出面板
- 素材许可调整：`LICENSE` 改为 CC BY-NC-SA 4.0 全文（素材），代码 MIT 移至 `LICENSE-MIT`；`NOTICE` 改为双语署名链
- README 精简重构（仿 maid-atelier 风格）+ 效果预览截图
- 改名 `dsh-quick-launch`（避免与市场已有同名插件冲突）

## v0.1.0 (2026-08-18)

- 首个版本：一键创建/更新/删除 DeepSeek Harness 桌面快捷方式，图标可自定义上传切换
- 启动脚本三级 dsh 入口解析链（记录真实入口 → PATH 上的 dsh → npx 兜底）
- 蓝白金鲸鱼悬浮按钮 + 弹出面板交互
- 零运行时依赖：纯 Node 宿主 half + 纯 DOM 客户端 half
