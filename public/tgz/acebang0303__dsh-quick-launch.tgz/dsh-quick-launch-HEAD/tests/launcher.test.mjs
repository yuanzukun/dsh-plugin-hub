// dsh-quick-launch 单元测试（node:test，零依赖，纯逻辑面）。
import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import {
  BUILTIN_ICONS, DEFAULT_NAME, ICON_DIR, LAUNCHER_DIR, MAX_ICON_BYTES, STATE_FILE,
  launcherScript, lnkScript, pngToIcoScript, validateIconId, validateName, validateUrl,
} from '../lib/launcher.mjs'

const ASSETS = fileURLToPath(new URL('../assets/', import.meta.url))

test('validateName：合法名称通过', () => {
  assert.equal(validateName('deepseek harness桌面快捷方式'), 'deepseek harness桌面快捷方式')
  assert.equal(validateName('  My Launcher  '), 'My Launcher')
  assert.equal(validateName('a'.repeat(32)), 'a'.repeat(32))
})

test('validateName：非法名称拒绝', () => {
  assert.equal(validateName(''), null)
  assert.equal(validateName('   '), null)
  assert.equal(validateName('a'.repeat(33)), null)
  assert.equal(validateName('a<b'), null)
  assert.equal(validateName('a>b'), null)
  assert.equal(validateName('a:b'), null)
  assert.equal(validateName('a"b'), null)
  assert.equal(validateName('a/b'), null)
  assert.equal(validateName('a\\b'), null)
  assert.equal(validateName('a|b'), null)
  assert.equal(validateName('a?b'), null)
  assert.equal(validateName('a*b'), null)
  assert.equal(validateName('a\x00b'), null)
  assert.equal(validateName('CON'), null)
  assert.equal(validateName('con'), null)
  assert.equal(validateName('LPT1'), null)
  assert.equal(validateName('name.'), null)
  assert.equal(validateName(42), null)
})

test('validateIconId：白名单校验', () => {
  assert.equal(validateIconId('default'), 'default')
  assert.equal(validateIconId('custom-abc123'), 'custom-abc123')
  assert.equal(validateIconId(''), null)
  assert.equal(validateIconId('a b'), null)
  assert.equal(validateIconId('../x'), null)
  assert.equal(validateIconId('a/b'), null)
  assert.equal(validateIconId(42), null)
})

test('validateUrl：仅 http(s) origin', () => {
  assert.equal(validateUrl('http://127.0.0.1:3080'), 'http://127.0.0.1:3080')
  assert.equal(validateUrl('https://example.com'), 'https://example.com')
  assert.equal(validateUrl('javascript:alert(1)'), null)
  assert.equal(validateUrl('http://x/path'), null)
  assert.equal(validateUrl('http://x y'), null)
  assert.equal(validateUrl(42), null)
})

test('launcherScript：记录入口 + 单引号转义', () => {
  const script = launcherScript({
    name: "O'Brien",
    nodePath: 'D:\\node.exe',
    binPath: 'D:\\dsh\\bin.js',
    url: 'http://127.0.0.1:3080',
  })
  assert.match(script, /'D:\\node\.exe'/)
  assert.match(script, /\$recorded = 'D:\\dsh\\bin\.js'/)
  assert.match(script, /'http:\/\/127\.0\.0\.1:3080'/)
  assert.match(script, /O''Brien/) // 单引号翻倍
  assert.match(script, /Get-NetTCPConnection -LocalPort \$port/)
  assert.match(script, /Get-Command dsh/) // PATH 兜底存在
  assert.match(script, /npx -y @deepseek-ai\/dsh web/) // npx 兜底存在
})

test('launcherScript：binPath 缺失时走解析链', () => {
  const script = launcherScript({ name: 'test', nodePath: 'n', binPath: null, url: 'http://127.0.0.1:3080' })
  assert.match(script, /\$recorded = \$null/)
  assert.match(script, /Get-Command dsh/)
  assert.match(script, /npx -y @deepseek-ai\/dsh web/)
})

test('lnkScript：路径/参数/图标注入正确', () => {
  const script = lnkScript({
    name: 'deepseek harness桌面快捷方式',
    scriptPath: 'C:\\Users\\x\\.dsh\\dsh-quick-launch\\launcher.ps1',
    icoPath: 'C:\\Users\\x\\.dsh\\dsh-quick-launch\\icons\\custom-x.ico',
    home: 'C:\\Users\\x\\.dsh',
  })
  assert.match(script, /deepseek harness桌面快捷方式\.lnk/)
  assert.match(script, /-File "C:\\Users\\x\\.dsh\\dsh-quick-launch\\launcher\.ps1"/)
  assert.match(script, /custom-x\.ico,0/)
  assert.match(script, /GetFolderPath\('Desktop'\)/)
  assert.match(script, /WindowStyle = 7/)
})

test('lnkScript：测试用 desktopOverride 生效', () => {
  const script = lnkScript({
    name: 't', scriptPath: 's', icoPath: 'i', home: 'h', desktopOverride: 'D:\\tmp',
  })
  assert.match(script, /D:\\tmp/)
  assert.doesNotMatch(script, /GetFolderPath/)
})

test('pngToIcoScript：System.Drawing 转换脚本', () => {
  const script = pngToIcoScript('C:\\a.png', 'C:\\a.ico')
  assert.match(script, /Add-Type -AssemblyName System.Drawing/)
  assert.match(script, /BinaryWriter/)
  assert.match(script, /Write-Output 'OK'/)
})

test('内置图标资产随包分发', () => {
  for (const id of BUILTIN_ICONS) {
    assert.equal(existsSync(join(ASSETS, `${id}.ico`)), true, `${id}.ico 缺失`)
    assert.equal(existsSync(join(ASSETS, `${id}.png`)), true, `${id}.png 缺失`)
  }
})

test('默认名称合法且长度受限', () => {
  assert.equal(validateName(DEFAULT_NAME), DEFAULT_NAME)
  assert.equal(DEFAULT_NAME.length <= 32, true)
})

test('运行时路径位于 <dshHome> 下', () => {
  assert.equal(typeof LAUNCHER_DIR, 'string')
  assert.equal(typeof STATE_FILE, 'string')
  assert.equal(typeof ICON_DIR, 'string')
})

test('launcherScript：名称含单引号与中文时转义安全', () => {
  const script = launcherScript({
    name: "它's 快捷方式",
    nodePath: 'D:\\node.exe',
    binPath: null,
    url: 'http://127.0.0.1:3080',
  })
  assert.match(script, /它''s 快捷方式/) // 单引号翻倍
  assert.match(script, /'http:\/\/127\.0\.0\.1:3080'/)
})

test('lnkScript：路径含空格与引号时参数正确', () => {
  const script = lnkScript({
    name: 'test',
    scriptPath: "C:\\My Apps\\它's\\launcher.ps1",
    icoPath: 'C:\\My Apps\\icon.ico',
    home: 'C:\\Users\\x',
  })
  assert.match(script, /-File "C:\\My Apps\\它''s\\launcher\.ps1"/)
  assert.match(script, /'C:\\My Apps\\icon\.ico,0'/)
})

test('默认名称长度边界', () => {
  assert.equal(DEFAULT_NAME.length <= 32, true)
  assert.equal(validateName('a'.repeat(32)) !== null, true)
  assert.equal(validateName('a'.repeat(33)), null)
})

test('图标大小上限为 2.5MB', () => {
  assert.equal(typeof MAX_ICON_BYTES, 'number')
  assert.equal(MAX_ICON_BYTES > 0 && MAX_ICON_BYTES <= 10 * 1024 * 1024, true)
  assert.equal(MAX_ICON_BYTES, 2.5 * 1024 * 1024)
})
