// 一次性工具：把 DeepSeek 鲸鱼标路径注入 lib/client.js 的 @WHALE_PATH@ 占位符。
// 用法：node scripts/inject-whale.mjs <favicon.svg 路径>
import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const clientPath = fileURLToPath(new URL('../lib/client.js', import.meta.url))
const faviconPath = process.argv[2]

if (!faviconPath) {
  console.error('用法: node scripts/inject-whale.mjs <favicon.svg>')
  process.exit(1)
}

const svg = readFileSync(faviconPath, 'utf8')
// 取 <path ... d="..."> 中的 d 属性（注意避开 id="path" 里的 d=）
const m = /<path[^>]*\sd="([^"]+)"/.exec(svg)
if (m === null) {
  console.error('favicon.svg 中未找到 path d 属性')
  process.exit(1)
}
const d = m[1]
if (d.length < 1000) {
  console.error(`d 属性异常偏短(${d.length})，中止`)
  process.exit(1)
}

const client = readFileSync(clientPath, 'utf8')
if (!client.includes('@WHALE_PATH@')) {
  console.error('client.js 中未找到 @WHALE_PATH@ 占位符')
  process.exit(1)
}
writeFileSync(clientPath, client.replace('@WHALE_PATH@', d), 'utf8')
console.log(`whale path injected: ${d.length} chars -> ${clientPath}`)
