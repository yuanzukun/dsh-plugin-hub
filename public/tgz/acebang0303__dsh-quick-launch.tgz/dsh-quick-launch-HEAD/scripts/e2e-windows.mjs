// Windows 端到端自检（可选运行）：在临时目录验证 .lnk 生成与 PNG→ICO 转换，
// 不触碰真实桌面。用法：node scripts/e2e-windows.mjs
import { mkdtempSync, mkdirSync, existsSync, readFileSync, rmSync } from 'node:fs'
import { platform, tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { launcherScript, lnkScript, pngToIcoScript, runPowershell } from '../lib/launcher.mjs'

if (platform() !== 'win32') {
  console.log('SKIP: e2e-windows 仅支持 Windows（.lnk / powershell 依赖）')
  process.exit(0)
}

const ASSETS = fileURLToPath(new URL('../assets/', import.meta.url))
const tmp = mkdtempSync(join(tmpdir(), 'dla-e2e-'))
const desktop = join(tmp, 'desktop')
mkdirSync(desktop, { recursive: true })
let failed = false

function check(cond, label) {
  console.log((cond ? 'PASS' : 'FAIL') + '  ' + label)
  if (!cond) failed = true
}

function psQuote(value) {
  return `'${String(value).replace(/'/g, "''")}'`
}

try {
  // 1) PNG → ICO
  const ico = join(tmp, 'out.ico')
  await runPowershell(pngToIcoScript(join(ASSETS, 'default.png'), ico))
  check(existsSync(ico), 'PNG→ICO 转换产物存在')
  const head = existsSync(ico) ? readFileSync(ico).subarray(0, 6) : Buffer.alloc(0)
  check(head.length === 6 && head[0] === 0 && head[1] === 0 && head[2] === 1, 'ICO 头部有效（ICONDIR）')

  // 2) 生成 launcher.ps1 并做语法检查（只解析不执行）
  const launcher = launcherScript({
    name: 'E2E测试快捷方式',
    nodePath: process.execPath,
    binPath: join(tmp, 'bin.js'),
    url: 'http://127.0.0.1:3080',
  })
  const syntax = await runPowershell(`$null = [scriptblock]::Create(${psQuote(launcher)}); Write-Output 'SYNTAX-OK'`)
  check(syntax.stdout.includes('SYNTAX-OK'), 'launcher.ps1 语法有效')

  // 3) .lnk 创建（临时桌面）
  const lnkName = 'E2E测试快捷方式'
  await runPowershell(lnkScript({
    name: lnkName,
    scriptPath: join(tmp, 'launcher.ps1'),
    icoPath: ico,
    home: tmp,
    desktopOverride: desktop,
  }))
  const lnkPath = join(desktop, `${lnkName}.lnk`)
  check(existsSync(lnkPath), '.lnk 创建于临时桌面')

  // 4) 读回快捷方式属性
  const props = await runPowershell([
    `$ws = New-Object -ComObject WScript.Shell`,
    `$l = $ws.CreateShortcut(${psQuote(lnkPath)})`,
    `Write-Output ('TARGET=' + $l.TargetPath)`,
    `Write-Output ('ICON=' + $l.IconLocation)`,
    `Write-Output ('ARGS=' + $l.Arguments)`,
    `Write-Output ('STYLE=' + $l.WindowStyle)`,
  ].join('\n'))
  check(props.stdout.includes('TARGET=') && props.stdout.includes('powershell.exe'), 'TargetPath 指向 powershell.exe')
  check(props.stdout.includes('ICON=') && props.stdout.includes(ico), 'IconLocation 指向生成的 .ico')
  check(props.stdout.includes('launcher.ps1'), 'Arguments 指向启动脚本')
  check(props.stdout.includes('STYLE=7'), 'WindowStyle 为最小化（7）')
} catch (error) {
  failed = true
  console.error('E2E 异常：', error.message)
} finally {
  rmSync(tmp, { recursive: true, force: true })
  console.log(failed ? '\nE2E 存在失败项' : '\nE2E 全部通过')
  process.exit(failed ? 1 : 0)
}
