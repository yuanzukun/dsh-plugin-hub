// 一键验证：语法检查 + 单元测试；Windows 上追加 E2E 自检。
// 用法：npm run check 或 node scripts/check.mjs
import { spawnSync } from 'node:child_process'
import { platform } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = fileURLToPath(new URL('..', import.meta.url))
let failed = false

const syntaxFiles = [
  'lib/launcher.mjs',
  'lib/index.mjs',
  'lib/client.js',
  'tests/launcher.test.mjs',
  'scripts/check.mjs',
  'scripts/e2e-windows.mjs',
  'scripts/inject-whale.mjs',
]
for (const f of syntaxFiles) {
  const r = spawnSync(process.execPath, ['--check', join(root, f)], { encoding: 'utf8' })
  if (r.status !== 0) {
    failed = true
    console.error(`SYNTAX FAIL: ${f}\n${r.stderr}`)
  }
}
console.log(failed ? 'syntax: FAIL' : 'syntax: OK')

const test = spawnSync(process.execPath, [join(root, 'tests', 'launcher.test.mjs')], { encoding: 'utf8' })
if (test.status !== 0) {
  failed = true
  console.error(`unit tests: FAIL\n${test.stdout}\n${test.stderr}`)
} else {
  console.log('unit tests: OK')
}

if (platform() === 'win32') {
  const e2e = spawnSync(process.execPath, [join(root, 'scripts', 'e2e-windows.mjs')], { encoding: 'utf8', stdio: 'inherit' })
  if (e2e.status !== 0) failed = true
} else {
  console.log('e2e-windows: SKIP（仅 Windows）')
}

process.exit(failed ? 1 : 0)
