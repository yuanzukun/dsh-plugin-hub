// 生成 E2E 用 PS 脚本文件（供沙箱环境经 pwsh 直接执行验证；含 BOM 保证 PS 5.1 中文不乱码）。
import { mkdirSync, mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { lnkScript, pngToIcoScript } from '../lib/launcher.mjs'

const ASSETS = fileURLToPath(new URL('../assets/', import.meta.url))
const dir = mkdtempSync(join(tmpdir(), 'dla-gen-'))
const desktop = join(dir, 'desktop')
mkdirSync(desktop, { recursive: true })
const ico = join(dir, 'out.ico')
const lnkName = 'E2E测试快捷方式'
const bom = '\uFEFF'

writeFileSync(join(dir, 'gen-ico.ps1'), bom + pngToIcoScript(join(ASSETS, 'default.png'), ico), 'utf8')
writeFileSync(join(dir, 'gen-lnk.ps1'), bom + lnkScript({
  name: lnkName,
  scriptPath: join(dir, 'launcher.ps1'),
  icoPath: ico,
  home: dir,
  desktopOverride: desktop,
}), 'utf8')

console.log(JSON.stringify({ dir, desktop, ico, lnkName }))
