# assets/ —— 角色素材声明

本目录素材为「鲸鱼娘」角色的**衍生创作**，依 **CC BY-NC-SA 4.0**（署名-非商业性使用-相同方式共享）发布，禁止商业性使用。

- 鲸鱼娘形象（原创作者 @上善无形）：“鲸鱼娘形象，此内容遵守 CC BY-NC-SA 4.0 协议。”
- 鲸鱼女仆形象（二创作者）：“鲸鱼娘形象基于 @上善无形 原创角色二创，依 CC BY-NC-SA 4.0 非商业使用，二创同协议授权。”
- default.png / default.ico 为本仓库作者基于上述角色生成的 AI 二创贴纸图（非商用），同协议发布。

版权所有人：上善（上善无形）· 原作，Pixiv https://www.pixiv.net/users/62155430 / Bilibili https://b23.tv/8h5L4xz；ZipZipPipe · 表情包版，Pixiv https://www.pixiv.net/users/18604994 / Bilibili https://b23.tv/Pnw6nG8

**任何人提取本目录素材使用，必须保留本声明**：署名（原创作者 @上善无形 及上游来源）＋ 非商业 ＋ 相同方式共享（CC BY-NC-SA 4.0）。
协议全文：https://creativecommons.org/licenses/by-nc-sa/4.0/deed.zh
