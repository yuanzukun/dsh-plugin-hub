/** Private Usage Ledger worker entry; never exposed as a public CLI binary. */

import { once } from 'node:events'
import { createInterface } from 'node:readline'
import { UsageLedgerDatabase, openUsageLedgerDatabase } from './host/database.ts'
import { UsageLedgerReducer } from './host/reducer.ts'
import type { UsageSessionEvent } from './host/event-types.ts'
import {
  decodeWorkerFrame,
  encodeWorkerFrame,
  isUnreadableSourceFailure,
  USAGE_LEDGER_WORKER_PROTOCOL,
} from './host/worker-protocol.ts'
import type {
  WorkerInitFrame,
  WorkerListedSession,
  WorkerLiveFrame,
  WorkerReaderModule,
  WorkerRequestFrame,
  WorkerResponseFrame,
  WorkerSession,
} from './host/worker-protocol.ts'

type SessionTask = {
  readonly session: WorkerSession
  readonly kind: 'history' | 'rescan' | 'live'
  /** Count a preempted history item only after its final reader pass completes. */
  readonly countHistory?: boolean
}

const input = createInterface({ input: process.stdin, crlfDelay: Infinity })
let stopped = false
let initialized = false
let init: WorkerInitFrame | undefined
let database: UsageLedgerDatabase | undefined
let reader: WorkerReaderModule | undefined
let readerLoad: Promise<void> | undefined
let history: AsyncIterator<WorkerSession> | undefined
let historyReady: Promise<void> | undefined
let historyDone = false
const priority = new Map<string, SessionTask>()
const deferredRescans = new Map<string, SessionTask>()
const liveEvents = new Map<string, Map<number, UsageSessionEvent>>()
// Unresolved per-lifecycle read failures; an entry is cleared only by that session reaching EOF.
const unresolvedFailures = new Map<string, string>()
const retriedSessions = new Set<string>()
// Stored generations this reader refuses to decode; re-reading the same revision can never succeed.
const unreadableSessions = new Set<string>()
let unreadableReason: string | undefined
let queuedUnreadable = 0
let pumping = false
let outputChain = Promise.resolve()
let processedSessions = 0
let processedEvents = 0
let reusedSessions = 0
let totalSessions = 0
let discoveredSessions = 0
let historyPrepared = false
const historyOutstanding = new Map<string, number>()
let lastProgressAt = 0
let pace: { mode: 'run' | 'pause'; delayMs: number } = { mode: 'run', delayMs: 0 }
let wake: (() => void) | undefined
const startupLive = new Map<string, WorkerLiveFrame>()
const startupControl = new Map<string, WorkerRequestFrame>()

function send(frame: WorkerResponseFrame): Promise<void> {
  outputChain = outputChain.then(async () => {
    if (stopped) return
    const line = encodeWorkerFrame(frame)
    if (process.stdout.write(line)) return
    await once(process.stdout, 'drain')
  }).catch(() => {
    stopped = true
    closeDatabase()
  })
  return outputChain
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

function notifyWake(): void {
  const current = wake
  wake = undefined
  current?.()
}

function waitForWake(): Promise<void> {
  return new Promise(resolve => { wake = resolve })
}

async function waitForHistoryPermit(): Promise<void> {
  while (!stopped && historyPaused()) await waitForWake()
}

/** Queue one priority task without dropping a preempted history item's completion marker. */
function queuePriority(task: SessionTask): void {
  const previous = priority.get(task.session.id)
  priority.set(task.session.id, previous?.countHistory === true && task.countHistory !== true ? { ...task, countHistory: true } : task)
}

/** Defer one task for resumed pacing, keeping the same completion marker. */
function queueDeferred(task: SessionTask): void {
  const previous = deferredRescans.get(task.session.id)
  deferredRescans.set(task.session.id, previous?.countHistory === true && task.countHistory !== true ? { ...task, countHistory: true } : task)
}

function queueLive(session: WorkerSession, event: UsageSessionEvent): void {
  const bySeq = liveEvents.get(session.id) ?? new Map<number, UsageSessionEvent>()
  bySeq.set(event.seq, event)
  // Missing rows are recoverable from a later provider-owned scan. Bound only
  // the notification cache, never the durable source log.
  if (bySeq.size > 2048) {
    const oldest = bySeq.keys().next().value as number | undefined
    if (oldest !== undefined) bySeq.delete(oldest)
  }
  liveEvents.set(session.id, bySeq)
  queuePriority({ session, kind: 'live' })
  notifyWake()
}

function queueRescan(session: WorkerSession): void {
  const task: SessionTask = { session, kind: 'rescan' }
  if (pace.mode === 'pause') {
    queueDeferred(task)
  } else {
    queuePriority(task)
  }
  notifyWake()
}

function moveDeferredRescans(): void {
  if (pace.mode === 'pause') return
  for (const task of deferredRescans.values()) queuePriority(task)
  deferredRescans.clear()
}

function historyPaused(): boolean {
  return pace.mode === 'pause'
}

function markProgress(
  status: 'idle' | 'running' | 'paused' | 'failed',
  currentSessionId?: string,
): Promise<void> {
  return send({
    type: 'progress',
    status,
    totalSessions,
    processedSessions,
    processedEvents,
    reusedSessions,
    discoveredSessions,
    historyComplete: historyPrepared && historyDone
      && processedSessions + queuedUnreadable >= totalSessions
      && unresolvedFailures.size === 0,
    failedSessions: unresolvedFailures.size,
    unreadableSessions: unreadableSessions.size,
    ...(unreadableReason === undefined ? {} : { unreadableReason }),
    // The Host owns the worker's budget, so every status carries the footprint it paid for.
    workerRssMiB: Math.round(process.memoryUsage().rss / (1024 * 1024)),
    ...(currentSessionId === undefined ? {} : { currentSessionId }),
    backfillDays: init?.config.backfillDays ?? 0,
  })
}

async function loadReader(): Promise<void> {
  if (readerLoad !== undefined) return readerLoad
  readerLoad = (async () => {
    const spec = init?.readerSpec
    if (spec === undefined) return
    if (spec.protocolVersion !== USAGE_LEDGER_WORKER_PROTOCOL) {
      throw new Error(`unsupported background reader protocol ${String(spec.protocolVersion)}`)
    }
    const imported = await import(spec.workerModule) as unknown as Partial<WorkerReaderModule> & { default?: Partial<WorkerReaderModule> }
    if (typeof imported.readSessionBatches !== 'function'
      && typeof imported.default?.readSessionBatches !== 'function') {
      throw new TypeError('provider-owned background reader does not export readSessionBatches')
    }
    reader = typeof imported.readSessionBatches === 'function'
      ? imported as WorkerReaderModule
      : imported.default as WorkerReaderModule
  })()
  return readerLoad
}

function asWorkerSession(entry: WorkerListedSession): WorkerSession {
  return {
    id: entry.id,
    createdAt: entry.createdAt,
    ...(entry.cwd === undefined ? {} : { cwd: entry.cwd }),
    inheritedEventCount: 0,
    ...(entry.source === undefined || entry.fingerprint === undefined ? {} : { stamp: { source: entry.source, fingerprint: entry.fingerprint } }),
  }
}

function sessionHeaderLister(): NonNullable<WorkerReaderModule['listSessionHeaders']> | undefined {
  const lister = reader?.listSessionHeaders
  return init?.readerSpec?.supportsSessionListing === true && lister !== undefined
    ? lister
    : undefined
}

/** Discover source changes once; only unmatched durable EOF proofs become replay tasks. */
async function* historySessions(): AsyncGenerator<WorkerSession> {
  // One header enumeration carries each source fingerprint, so discovery never stats per session.
  if (init === undefined) return
  const cutoff=Date.now()-init.config.backfillDays*24*60*60*1000
  const lister=sessionHeaderLister()
  if(lister===undefined) {
    for(const session of init.sessions)if(init.config.backfillScope==='all'||session.createdAt>=cutoff)yield session
    return
  }
  for await(const entry of lister(init.readerSpec?.options,{
    ...(init.config.backfillScope==='recent'?{createdAtAfter:cutoff}:{}),
  })) {
    await waitForHistoryPermit()
    if(stopped)return
    if(init.config.backfillScope==='recent'&&entry.createdAt<cutoff)continue
    yield asWorkerSession(entry)
  }
}

async function* plannedHistory(sessions: readonly WorkerSession[]): AsyncGenerator<WorkerSession> {
  yield* sessions
}

async function prepareHistory(): Promise<void> {
  try {
    await loadReader()
  } catch (error: unknown) {
    reader = undefined
    readerLoad = Promise.resolve()
    await send({ type: 'error', message: `provider-owned reader disabled: ${errorMessage(error)}` })
  }
  if (reader === undefined) {
    totalSessions = 0
    historyDone = true
    return
  }
  await markProgress('running')
  const pending: WorkerSession[]=[]
  for await(const session of historySessions()) {
    await waitForHistoryPermit()
    if(stopped)return
    discoveredSessions+=1
    const stamp=session.stamp
    // A listing fingerprint without a stored cursor is not an EOF proof; such a source is queued.
    const unchanged=stamp!==undefined && !liveEvents.has(session.id) && requireDatabase().sourceUnchangedAtSavedCursor(session,stamp)
    // A generation this reader already refused is not pending work: it is decoded once, not per pass.
    const refused=unchanged||stamp===undefined?undefined:requireDatabase().unreadableSourceReason(session,stamp)
    if(unchanged)reusedSessions+=1
    else if(refused!==undefined) {
      unreadableSessions.add(session.id)
      unreadableReason ??= refused
    }
    else {
      pending.push(session)
      historyOutstanding.set(session.id,session.createdAt)
    }
    if (performance.now() - lastProgressAt > 500) {
      lastProgressAt = performance.now()
      await markProgress('running')
    }
  }
  pending.sort((left,right)=>right.createdAt-left.createdAt)
  totalSessions=pending.length
  history=plannedHistory(pending)
  historyPrepared=true
}

async function takeNextTask(): Promise<SessionTask | undefined> {
  const nextPriority = priority.values().next().value as SessionTask | undefined
  if (nextPriority !== undefined) {
    priority.delete(nextPriority.session.id)
    return nextPriority
  }
  if (pace.mode === 'pause' || historyDone) return undefined
  if (historyReady === undefined) {
    historyReady = prepareHistory()
  }
  await historyReady
  const next = await history?.next()
  if (next === undefined || next.done) {
    historyDone = true
    return undefined
  }
  return { session: next.value, kind: 'history', countHistory: true }
}

async function persistMutations(
  session: WorkerSession,
  reducer: UsageLedgerReducer,
  mutations: ReturnType<UsageLedgerReducer['applyBatch']>,
): Promise<void> {
  if (mutations.length === 0) return
  requireDatabase().applyMutations(mutations)
  const cursor = reducer.cursor(session)
  if (cursor !== undefined) {
    await send({ type: 'checkpoint', sessionId: session.id, observedSeq: cursor.observedSeq })
  }
}

async function processLive(session: WorkerSession, reducer: UsageLedgerReducer): Promise<boolean> {
  const events = liveEvents.get(session.id)
  if (events === undefined || events.size === 0) return true
  const ordered = [...events.entries()]
    .sort(([left], [right]) => left - right)
    .map(([, event]) => event)
  if (reader !== undefined && ordered[0] !== undefined && ordered[0].seq > reducer.resumeSeq(session)) {
    queueRescan(session)
    return false
  }
  liveEvents.delete(session.id)
  const mutations = reducer.applyBatch(session, ordered)
  processedEvents += ordered.length
  await persistMutations(session, reducer, mutations)
  return true
}

async function processReaderBatch(
  session: WorkerSession,
  reducer: UsageLedgerReducer,
  current: { readonly meta: { readonly id: string }; readonly inheritedEventCount: number; readonly events: readonly UsageSessionEvent[] },
): Promise<void> {
  const effective = current.meta.id === session.id
    ? { ...session, inheritedEventCount: current.inheritedEventCount }
    : session
  const mutations = reducer.applyBatch(effective, current.events)
  processedEvents += current.events.length
  await persistMutations(session, reducer, mutations)
}

async function yieldForPace(): Promise<void> {
  if (historyPaused()) {
    await waitForWake()
    return
  }
  if (pace.delayMs > 0) {
    await Promise.race([
      new Promise<void>(resolve => setTimeout(resolve, pace.delayMs)),
      waitForWake(),
    ])
    return
  }
  await new Promise<void>(resolve => setImmediate(resolve))
}

/**
 * Process one session until its current slice completes. A saved cursor makes
 * a preempted scan resume from disk without retaining prior calls in memory.
 */
async function processSession(task: SessionTask): Promise<boolean> {
  if (init === undefined || reader === undefined && task.kind !== 'live') return false
  const session = task.session
  const seed = requireDatabase().sessionSeed(session.id, session.createdAt, init.config.workerMaxActiveAttempts)
  const reducer = new UsageLedgerReducer(seed, init.config.workerMaxActiveAttempts)
  let sliceStarted = performance.now()
  await processLive(session, reducer)
  if (task.kind === 'live') return true
  if (pace.mode === 'pause') {
    queueDeferred(task)
    return false
  }
  if (reader === undefined) return false
  // Reuse needs the cursor stored by this connection, so a pre-queue listing fingerprint cannot
  // authorize it. Readers without listing fingerprints are observed here instead.
  const observed = session.stamp ?? await reader.getSourceStamp?.(init.readerSpec?.options, { session, phase: 'lookup' })
  if (observed !== undefined && requireDatabase().sourceUnchanged(session,observed,reducer.resumeSeq(session)-1)) {
    return true
  }
  const batches = reader.readSessionBatches(
    init.readerSpec?.options,
    {
      session: { id: session.id, ...(session.cwd === undefined ? {} : { cwd: session.cwd }) },
      fromSeq: reducer.resumeSeq(session),
      batchEvents: init.config.workerBatchEvents,
    },
  )
  for await (const current of batches) {
    if (stopped) return false
    await processReaderBatch(session, reducer, current)
    await processLive(session, reducer)
    if (performance.now() - sliceStarted < init.config.workerSliceMs) continue
    await markProgress('running', session.id)
    await yieldForPace()
    if (historyPaused()) {
      queueDeferred(task)
      return false
    }
    if (priority.size > 0) {
      queuePriority({ session, kind: 'rescan', countHistory: task.countHistory })
      return false
    }
    sliceStarted = performance.now()
  }
  if (stopped) return false
  // Record EOF only from a fresh observation of this session, so a source that changed during the
  // pass is not marked complete by the listing fingerprint taken before it.
  const after = await reader.getSourceStamp?.(init.readerSpec?.options,{session,phase:'verify'})
  // A source that moved during the pass is not complete: only a matching fresh observation is stored.
  if(observed!==undefined && after!==undefined && after.source===observed.source && after.fingerprint===observed.fingerprint) {
    requireDatabase().completeSource(session,after,reducer.resumeSeq(session)-1)
  }
  return true
}

async function pump(): Promise<void> {
  if (pumping || stopped || !initialized) return
  pumping = true
  try {
    while (!stopped) {
      const task = await takeNextTask()
      if (task === undefined) break
      try {
        await markProgress('running', task.session.id)
        const completed = await processSession(task)
        if (completed && task.kind !== 'live') {
          unresolvedFailures.delete(task.session.id)
          if (historyOutstanding.get(task.session.id) === task.session.createdAt) {
            historyOutstanding.delete(task.session.id)
            processedSessions += 1
          }
        }
      } catch (error: unknown) {
        const message = errorMessage(error)
        if (isUnreadableSourceFailure(error)) {
          // A read never rewrites the refused generation, so retrying the same revision cannot
          // succeed. Settle it once, remember it, and keep the rest of the pass healthy.
          unresolvedFailures.delete(task.session.id)
          const stamp = task.session.stamp
          if (stamp !== undefined) requireDatabase().markSourceUnreadable(task.session, stamp, message)
          if (historyOutstanding.get(task.session.id) === task.session.createdAt) {
            historyOutstanding.delete(task.session.id)
            queuedUnreadable += 1
          }
          unreadableSessions.add(task.session.id)
          unreadableReason ??= message
        } else {
          // One bounded retry absorbs a transient read failure; a repeat stays unresolved so a
          // later pass repairs it instead of the drain reporting a healthy idle ledger.
          if (task.kind === 'history' && !retriedSessions.has(task.session.id)) {
            retriedSessions.add(task.session.id)
            queuePriority(task)
          } else {
            unresolvedFailures.set(task.session.id, message)
          }
          await send({ type: 'error', message, sessionId: task.session.id })
        }
      }
      if (performance.now() - lastProgressAt > 500) {
        lastProgressAt = performance.now()
        await markProgress('running')
      }
    }
    if (!stopped) await markProgress(unresolvedFailures.size > 0 ? 'failed' : pace.mode === 'pause' && !historyDone ? 'paused' : reader === undefined ? 'paused' : 'idle')
  } catch (error: unknown) {
    await send({ type: 'error', message: errorMessage(error), fatal: true })
    await markProgress('failed')
  } finally {
    pumping = false
    if (!stopped && (priority.size > 0 || !historyDone && pace.mode === 'run')) void pump()
  }
}

function requireDatabase(): UsageLedgerDatabase {
  if (database === undefined) throw new Error('usage ledger database is not initialized')
  return database
}

function closeDatabase(): void {
  const current = database
  database = undefined
  current?.close()
}

async function failInitialization(message: string): Promise<void> {
  await send({ type: 'error', message, fatal: true })
  stopped = true
  notifyWake()
  input.close()
  closeDatabase()
}

async function initialize(frame: WorkerInitFrame): Promise<void> {
  database = await openUsageLedgerDatabase(frame.config.databasePath)
  init = frame
  initialized = true
  const controls = [...startupControl.values()]
  const live = [...startupLive.values()]
  startupControl.clear()
  startupLive.clear()
  for (const queued of controls) handleFrame(queued)
  for (const queued of live) handleFrame(queued)
  void pump()
}

function queueBeforeInitialization(frame: Exclude<WorkerRequestFrame, WorkerInitFrame>): void {
  if (frame.type === 'live') {
    startupLive.set(frame.session.id, frame)
    while (startupLive.size > 1_024) {
      const id = startupLive.keys().next().value as string | undefined
      if (id === undefined) break
      startupLive.delete(id)
    }
    return
  }
  if (frame.type === 'dispose') {
    startupLive.delete(frame.session.id)
    startupControl.set(frame.session.id, frame)
    return
  }
  if (frame.type === 'rescan') {
    startupControl.set(frame.session.id, frame)
    return
  }
  if (frame.type === 'pace') {
    startupControl.set('pace', frame)
    return
  }
  stopped = true
  notifyWake()
  input.close()
}

function handleFrame(frame: WorkerRequestFrame): void {
  switch (frame.type) {
    case 'init':
      if (initialized) return
      if (frame.protocolVersion !== USAGE_LEDGER_WORKER_PROTOCOL) {
        void failInitialization('unsupported worker protocol ' + String(frame.protocolVersion))
        return
      }
      void initialize(frame).catch(error => {
        void failInitialization(errorMessage(error))
      })
      return
    default:
      if (!initialized) {
        queueBeforeInitialization(frame)
        return
      }
      break
  }
  switch (frame.type) {
    case 'live':
      queueLive(frame.session, frame.event)
      void pump()
      return
    case 'rescan':
      queueRescan(frame.session)
      void pump()
      return
    case 'dispose':
      liveEvents.delete(frame.session.id)
      priority.delete(frame.session.id)
      deferredRescans.delete(frame.session.id)
      return
    case 'pace':
      pace = { mode: frame.mode, delayMs: frame.delayMs }
      if (pace.mode === 'run') moveDeferredRescans()
      notifyWake()
      void pump()
      return
    case 'stop':
      stopped = true
      notifyWake()
      input.close()
      closeDatabase()
      return
  }
}

input.on('line', (line) => {
  const frame = decodeWorkerFrame(line)
  if (frame === undefined) {
    void send({ type: 'error', message: 'invalid worker protocol frame' })
    return
  }
  handleFrame(frame)
})

input.on('close', () => {
  stopped = true
  notifyWake()
  closeDatabase()
})
