import {
  LlmAdapter,
  ReasoningEffortId,
  type StreamChunk,
  type LlmModelInfo,
  type LlmResolvedModelInfo,
} from '@deepseek-ai/dsh-llm';
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import { AcpClient } from './acp/client.js';
import { EventMapper, finishReason } from './acp/events.js';
import { aborted, acpError, classify } from './acp/errors.js';
import { modelCatalog } from './models.js';
import { buildPrompt } from './prompt.js';
import type { Config } from './config.js';
import { ToolSessions } from './mcp/sessions.js';
import type { AcpGenerateOptions as GenerateOptions } from './request.js';

/**
 * DSH 0.2.1-rc.3 requires every model entry to declare reasoning metadata
 * before a request carrying a `reasoningEffort` is accepted; without it the
 * host throws UNSUPPORTED_REASONING_EFFORT for any effort, including `off`.
 *
 * Antigravity encodes the thinking level into the model ID suffix
 * (`-low` / `-medium` / `-high`) and this adapter never consumes
 * `options.reasoningEffort`, so a full host-neutral effort list is declared
 * purely to satisfy the host contract. See
 * https://github.com/dannndouglas/dsh-antigravity-acp/issues/1
 */
const REASONING_META = {
  efforts: [
    { id: ReasoningEffortId('off'), name: 'Off' },
    { id: ReasoningEffortId('low'), name: 'Low' },
    { id: ReasoningEffortId('medium'), name: 'Medium' },
    { id: ReasoningEffortId('high'), name: 'High' },
    { id: ReasoningEffortId('max'), name: 'Max' },
  ],
};

/** Stable route that follows `defaultModel` or the server's current model; persisted selections stay valid. */
export const SERVER_DEFAULT = 'server-default';

export class AntigravityAcpAdapter extends LlmAdapter {
  private controlClient: AcpClient;
  private tools: ToolSessions;
  private tail: Promise<void> = Promise.resolve();
  private disposed = false;
  private lifetime = new AbortController();
  private generations = 0;
  private warnedTools = false;
  private catalog: { id: string; name: string }[] = [];
  constructor(
    readonly config: Config,
    private runtime: SubprocessRuntime,
    private warn: (message: string) => void = () => {},
  ) {
    super();
    this.controlClient = new AcpClient(config, runtime, warn);
    this.tools = new ToolSessions(config, runtime, warn);
  }
  get client(): AcpClient {
    return this.controlClient;
  }
  providerInfo(provider: string) {
    return { id: provider, name: 'Antigravity (official ACP)' };
  }

  private async acquire(signal?: AbortSignal): Promise<() => void> {
    if (this.disposed) throw acpError('Antigravity adapter has been disposed.', 'ACP_DISPOSED');
    if (signal?.aborted) throw aborted();
    const previous = this.tail;
    let release!: () => void;
    this.tail = new Promise<void>((resolve) => {
      release = resolve;
    });
    let onAbort: (() => void) | undefined;
    try {
      const abort = new Promise<never>((_, reject) => {
        onAbort = () => reject(aborted());
        signal?.addEventListener('abort', onAbort, { once: true });
        if (signal?.aborted) onAbort();
      });
      await Promise.race([previous, abort]);
      if (this.disposed) throw acpError('Antigravity adapter has been disposed.', 'ACP_DISPOSED');
      return release;
    } catch (error) {
      void previous.then(release);
      throw error;
    } finally {
      if (onAbort) signal?.removeEventListener('abort', onAbort);
    }
  }
  async listModels(provider: string): Promise<readonly LlmModelInfo[]> {
    const release = await this.acquire(this.lifetime.signal);
    try {
      let failure: ReturnType<typeof classify> | undefined;
      if (!this.catalog.length) {
        try {
          this.catalog = modelCatalog(await this.client.newSession(this.lifetime.signal, false));
          if (
            this.config.toolPolicy === 'bridge' &&
            this.catalog.length &&
            this.client.initializeResult?.agentCapabilities?.mcpCapabilities?.http
          ) {
            const ready = this.controlClient;
            this.controlClient = new AcpClient(this.config, this.runtime, this.warn);
            await this.tools.acceptReadyClient(ready);
          }
        } catch (error) {
          await this.client.reset();
          failure = classify(error);
          this.warn(failure.message);
        }
      }
      const entries = new Map(
        [...this.catalog, ...this.config.models.map((id) => ({ id, name: id }))].map((m) => [
          m.id,
          { ...m, description: 'Official ACP backend with DSH tools through MCP' },
        ]),
      );
      // Discovery itself never opens a browser. An unexpected failure is raised so
      // the DSH model picker shows it; a missing login keeps the stable
      // server-default route, whose first message opens the official login.
      if (!entries.size && failure && failure.code !== 'ACP_AUTH_REQUIRED') throw failure;
      entries.set(SERVER_DEFAULT, {
        id: SERVER_DEFAULT,
        ...(this.catalog.length
          ? {
              name: 'Server default',
              description: this.config.defaultModel
                ? `Uses the configured default model ${this.config.defaultModel}`
                : "Uses the official server's current default model",
            }
          : {
              name: 'Sign in to Antigravity',
              description:
                'Send a message to open the official Google login; the model list appears afterwards',
            }),
      });
      return [...entries.values()].map((m) => ({
        ...m,
        provider,
        inputModalities: ['text'],
        reasoning: REASONING_META,
      }));
    } finally {
      release();
    }
  }
  async resolveModel(
    provider: string,
    model: string,
    signal?: AbortSignal,
  ): Promise<LlmResolvedModelInfo> {
    if (signal?.aborted) throw aborted();
    const target = model === SERVER_DEFAULT ? this.config.defaultModel : model;
    return {
      provider,
      id: model,
      name:
        model === SERVER_DEFAULT
          ? 'Server default'
          : (this.catalog.find((m) => m.id === model)?.name ?? model),
      inputModalities: ['text'],
      // The usable window is bounded by the per-request prompt budget, not the
      // model, so DSH compaction must run before history outgrows that budget.
      context: {
        contextWindow: this.config.contextWindows[target] ?? this.config.contextWindow,
      },
      reasoning: REASONING_META,
    };
  }
  diagnostics() {
    return {
      connected: this.client.connected || this.tools.connected,
      processStarts: this.client.processStarts + this.tools.processStarts,
      authentications: this.client.authentications + this.tools.authentications,
      generations: this.generations + this.tools.generations,
      activeToolSessions: this.tools.active,
      idleToolProcesses: this.tools.idle,
    };
  }
  async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    options = {
      ...options,
      signal: options.signal
        ? AbortSignal.any([options.signal, this.lifetime.signal])
        : this.lifetime.signal,
    };
    if (this.config.toolPolicy === 'bridge' && (options.tools?.length || this.tools.has(options))) {
      yield* this.tools.stream(options);
      return;
    }
    const prompt = buildPrompt(options, this.config); // Validate before spawning or authenticating.
    const release = await this.acquire(options.signal);
    const borrowed = this.tools.borrowReadyClient();
    const client = borrowed ?? this.client;
    const mapper = new EventMapper();
    let sessionId: string | undefined,
      completed = false,
      promptStarted = false;
    const queue: StreamChunk[] = [];
    let wake: (() => void) | undefined;
    let error: unknown;
    let done = false;
    try {
      if (options.tools?.length && !this.warnedTools) {
        this.warnedTools = true;
        this.warn(
          'Antigravity ACP is a text-only route: DSH tool schemas are omitted and tool execution is unavailable (toolPolicy: text-only).',
        );
      }
      const session = client.takeUnusedSession() ?? (await client.newSession(options.signal));
      sessionId = session.sessionId;
      this.catalog = modelCatalog(session);
      await client.selectModel(session, options.model, options.signal);
      this.generations++;
      const nativeTools = () => {
        error = acpError(
          'Antigravity attempted native agent tool activity. This provider supports text only; tools remain unavailable on this route.',
          'ACP_NATIVE_TOOLS_UNSUPPORTED',
        );
        done = true;
        wake?.();
      };
      client.onPermission = nativeTools;
      client.onUpdate = (event) => {
        if (event.sessionId !== sessionId || done) return;
        if (
          event.update.sessionUpdate === 'tool_call' ||
          event.update.sessionUpdate === 'tool_call_update'
        ) {
          nativeTools();
          return;
        }
        queue.push(...mapper.update(event.update));
        wake?.();
      };
      let stop = '';
      promptStarted = true;
      const pending = client.prompt(sessionId, prompt, options.signal).then(
        (result) => {
          stop = result.stopReason;
          done = true;
          wake?.();
        },
        (failure) => {
          error = failure;
          done = true;
          wake?.();
        },
      );
      while (!done || queue.length) {
        while (queue.length) {
          if (options.signal?.aborted) throw aborted();
          yield queue.shift()!;
        }
        if (!done)
          await new Promise<void>((resolve) => {
            wake = resolve;
          });
      }
      if (error) throw error;
      await pending;
      if (options.signal?.aborted) throw aborted();
      if (!mapper.hasText && stop === 'end_turn')
        throw acpError(
          'Official ACP server ended the turn without assistant text.',
          'EMPTY_RESPONSE',
        );
      yield* mapper.end();
      // ACP usage_update reports current context occupancy, not per-call token billing.
      completed = stop === 'end_turn';
      yield { type: 'finish', reason: finishReason(stop) };
    } catch (failure) {
      throw options.signal?.aborted ? aborted() : classify(failure);
    } finally {
      client.onUpdate = undefined;
      client.onPermission = undefined;
      try {
        if (completed && !options.signal?.aborted && borrowed)
          await this.tools.acceptReadyClient(client);
        else if (!completed || options.signal?.aborted)
          await client.cancelAndReset(promptStarted ? sessionId : undefined);
      } finally {
        try {
          if (borrowed && (!completed || options.signal?.aborted))
            await this.tools.discardReadyClient(client);
        } finally {
          release();
        }
      }
    }
  }
  async dispose(): Promise<void> {
    this.disposed = true;
    this.lifetime.abort();
    await Promise.all([this.client.dispose(), this.tools.dispose()]);
  }
}
