/**
 * dsh-vision-primitives — browser half: the plugin configuration card shown
 * in 设置 → 插件配置 (the `settings.plugin.item` slot).
 *
 * Mirrors the official web-search card pattern:
 * - apiKey is a credentials-domain literal (ref MIMO_API_KEY); the card only
 *   learns whether one is configured and never rides a response.
 * - baseUrl / model / timeoutMs live in the `vision-primitives` settings
 *   namespace, staged through the settingsScope transport.
 *
 * This file is loaded by dsh-client-modules as `/plugins/dsh-vision-primitives/client.js`
 * (declared via package.json `dsh.client` + `exports["./client"]`), so it
 * uses the platform `__ModuleLoader__` factory format and requires only
 * platform seed words (react, @deepseek-ai/cordis, dsh-client-* services).
 */
window.__ModuleLoader__.load({
  id: 'dsh-vision-primitives',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })
    var react = require('react')
    var h = react.createElement
    var useState = react.useState
    var useEffect = react.useEffect
    var useSyncExternalStore = react.useSyncExternalStore

    /** Namespace of the vision-primitives settings section. */
    var NS = 'vision-primitives'
    /** Credential reference the provider resolves for the MiMo API key. */
    var CRED_REF = 'MIMO_API_KEY'
    /** Injected style tag, claimed by the client module system. */
    var css = ''

    /* ---------- 聊天框图片粘贴 → 路径/证据文本 (paste-to-path) ----------
     * 参考 liustack/modlens 的社区解法, 原生实现:
     *  - capture 阶段 paste 监听, 剪贴板带图片文件时先问 Host
     *    (GET /vision-primitives/paste?model=<label>) 是否接管;
     *  - 视觉模型不被劫持 (原生缩略图附件), 纯文本模型接管:
     *    preventDefault 抑制默认附件摄入 (避免 "model does not support
     *    images" 报错), 图片字节 POST 给 Host, 返回的路径与 MiMo 摘要
     *    作为纯文本插入输入框;
     *  - Host 路由关闭 (pasteToPath=false) 时 GET 返回 404, 客户端完全让行。 */
    function imageFilesOf(event) {
      var items = event.clipboardData && event.clipboardData.items
      if (!items) return []
      var files = []
      for (var i = 0; i < items.length; i++) {
        var item = items[i]
        if (item.kind !== 'file') continue
        var file = item.getAsFile()
        if (file && /^image\//.test(file.type)) files.push(file)
      }
      return files
    }
    function insertText(target, text) {
      var el = target && (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT') ? target : document.activeElement
      if (!el || (el.tagName !== 'TEXTAREA' && el.tagName !== 'INPUT')) return
      el.focus()
      var inserted = false
      try {
        inserted = document.execCommand('insertText', false, text)
      } catch (e) {
        inserted = false
      }
      if (!inserted) {
        var proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype
        var setter = Object.getOwnPropertyDescriptor(proto, 'value').set
        setter.call(el, el.value + text)
        el.dispatchEvent(new Event('input', { bubbles: true }))
      }
    }
    function uploadOne(file) {
      return file.arrayBuffer().then(function (buffer) {
        return fetch('/vision-primitives/paste?type=' + encodeURIComponent(file.type || 'image/png'), {
          method: 'POST',
          body: buffer
        }).then(function (res) {
          if (!res.ok) {
            return res.json().catch(function () { return {} }).then(function (body) {
              var error = new Error(body.error || 'paste upload failed (' + res.status + ')')
              error.status = res.status
              throw error
            })
          }
          return res.json()
        })
      })
    }
    function currentModelLabel() {
      var buttons = document.querySelectorAll('button[aria-label]')
      for (var i = 0; i < buttons.length; i++) {
        var label = buttons[i].getAttribute('aria-label') || ''
        if (/选择模型|select model|current model/i.test(label)) return label
      }
      return ''
    }
    var pasteRouteAvailable = true
    var pasteVerdicts = {}
    var PASTE_VERDICT_MAX_AGE_MS = 60000
    function refreshPasteVerdict(label) {
      if (!pasteRouteAvailable) return
      var cached = pasteVerdicts[label]
      if (cached && cached.pending) return
      var entry = { pending: true, takeover: cached ? cached.takeover : false, at: cached ? cached.at : 0 }
      pasteVerdicts[label] = entry
      fetch('/vision-primitives/paste?model=' + encodeURIComponent(label))
        .then(function (res) {
          if (res.status === 404) {
            pasteRouteAvailable = false
            entry.pending = false
            return null
          }
          if (!res.ok) throw new Error('policy ' + res.status)
          return res.json()
        })
        .then(function (body) {
          entry.pending = false
          if (body) {
            entry.takeover = body.takeover === true
            entry.at = Date.now()
          }
        })
        .catch(function () {
          entry.pending = false
        })
    }
    function onPasteFocusIn() {
      refreshPasteVerdict(currentModelLabel())
    }
    /* DSH 的图片准入检查在 window 层先于我们运行, 其"模型不支持图片"
       提示条可能在我们接管成功后仍然挂着。接管成功时主动清除该提示
       (MutationObserver 观察新增节点, 命中文案即移除; 12s 后停止观察)。 */
    var ERR_HINTS = ['不支持图片', 'does not support images', 'image.*not supported', 'not support.*image']
    var errObserver = null
    var errDismissTimer = null
    function dismissModelImageError() {
      if (typeof document === 'undefined') return
      var sweep = function (root) {
        var hits = []
        var walker = document.createTreeWalker(root || document.body, NodeFilter.SHOW_ELEMENT)
        var el
        while ((el = walker.nextNode())) {
          var text = (el.childNodes.length === 1 && el.childNodes[0].nodeType === 3) ? el.textContent : ''
          if (!text) continue
          var hit = false
          for (var i = 0; i < ERR_HINTS.length; i++) {
            try { if (new RegExp(ERR_HINTS[i], 'i').test(text)) { hit = true; break } } catch (e) {}
          }
          if (hit) hits.push(el)
        }
        for (var j = 0; j < hits.length; j++) {
          // 只移除提示条链上的容器, 不碰聊天消息
          var node = hits[j]
          var guard = 0
          while (node && node !== document.body && guard++ < 8) {
            var role = node.getAttribute && node.getAttribute('role')
            var cls = String(node.className || '')
            if (role === 'status' || role === 'alert' || /toast|banner|notice|error/i.test(cls)) { node.remove(); break }
            node = node.parentElement
          }
        }
      }
      sweep(document.body)
      if (errObserver) return
      errObserver = new MutationObserver(function () {
        sweep(document.body)
      })
      errObserver.observe(document.body, { childList: true, subtree: true })
      if (errDismissTimer) clearTimeout(errDismissTimer)
      errDismissTimer = setTimeout(function () {
        if (errObserver) { errObserver.disconnect(); errObserver = null }
        errDismissTimer = null
      }, 12000)
    }
    function onPaste(event) {
      if (!pasteRouteAvailable) return
      var files = imageFilesOf(event)
      if (files.length === 0) return
      var label = currentModelLabel()
      var cached = pasteVerdicts[label]
      refreshPasteVerdict(label)
      if (!cached || cached.at === 0 || cached.takeover !== true || Date.now() - cached.at > PASTE_VERDICT_MAX_AGE_MS) return
      event.preventDefault()
      event.stopImmediatePropagation()
      var target = event.target
      Promise.all(files.map(uploadOne))
        .then(function (results) {
          var parts = []
          for (var i = 0; i < results.length; i++) {
            var r = results[i]
            if (!r || !r.path) continue
            var line = r.path
            var a = r.analysis
            if (a && a.ok) {
              if (a.caption) line += '\n【图片分析】' + a.caption
              if (a.elements && a.elements.length) {
                var els = []
                for (var j = 0; j < a.elements.length; j++) {
                  var el = a.elements[j]
                  var s = el.label
                  if (el.text) s += '「' + el.text + '」'
                  if (el.grid_cell) s += ' @格子' + el.grid_cell
                  els.push(s)
                }
                line += '\n关键元素: ' + els.join('; ')
              }
            }
            parts.push(line)
          }
          if (parts.length) {
            insertText(target, parts.join('\n') + '\n')
            dismissModelImageError()
          }
        })
        .catch(function (error) {
          if (error && error.status === 404) {
            pasteRouteAvailable = false
            pasteVerdicts = {}
          }
          console.error('[vision-primitives] paste-to-path failed: ' + (error && error.message ? error.message : error))
        })
    }

    function field(id, label, hint, value, onChange, opts) {
      return h('label', { className: 'vpr-field', key: id }, [
        h('span', { className: 'vpr-label' }, label),
        h('input', {
          className: 'vpr-input',
          type: opts && opts.secret ? 'password' : 'text',
          value: value == null ? '' : String(value),
          placeholder: opts && opts.placeholder ? opts.placeholder : '',
          disabled: opts && opts.disabled,
          onChange: (e) => onChange(e.target.value)
        }),
        hint ? h('span', { className: 'vpr-hint' }, hint) : null
      ])
    }

    /**
     * The card: official PluginCard-style collapsible container (collapsed by
     * default — title, description and a status badge in the header; the form
     * fields unfold on click). Staged form over the settings scope plus the
     * credential literal; one 保存 button commits everything the card shows.
     */
    function VprCard(props) {
      var t = props.t
      var snapshot = useSyncExternalStore(props.subscribe, props.getSnapshot)
      var value = snapshot && snapshot.value ? snapshot.value : {}
      var base = snapshot && snapshot.base ? snapshot.base : {}
      var [open, setOpen] = useState(false)
      var [baseUrl, setBaseUrl] = useState(value.baseUrl != null ? value.baseUrl : (base.baseUrl != null ? base.baseUrl : ''))
      var [model, setModel] = useState(value.model != null ? value.model : (base.model != null ? base.model : ''))
      var [timeoutMs, setTimeoutMs] = useState(value.timeoutMs != null ? value.timeoutMs : (base.timeoutMs != null ? base.timeoutMs : 300000))
      var [apiKey, setApiKey] = useState('')
      var [configured, setConfigured] = useState(props.credentialConfigured)
      var [saving, setSaving] = useState(false)
      var [message, setMessage] = useState('')
      var [pasteToPath, setPasteToPath] = useState(value.pasteToPath !== false)
      var [autoDescribe, setAutoDescribe] = useState(value.autoDescribe !== false)
      var [sendTimeConvert, setSendTimeConvert] = useState(value.sendTimeConvert !== false)

      useEffect(() => {
        if (value.baseUrl != null && value.baseUrl !== baseUrl) setBaseUrl(value.baseUrl)
        if (value.model != null && value.model !== model) setModel(value.model)
        if (value.timeoutMs != null && value.timeoutMs !== timeoutMs) setTimeoutMs(value.timeoutMs)
        if (typeof value.pasteToPath === 'boolean' && value.pasteToPath !== pasteToPath) setPasteToPath(value.pasteToPath)
        if (typeof value.autoDescribe === 'boolean' && value.autoDescribe !== autoDescribe) setAutoDescribe(value.autoDescribe)
        if (typeof value.sendTimeConvert === 'boolean' && value.sendTimeConvert !== sendTimeConvert) setSendTimeConvert(value.sendTimeConvert)
        setConfigured(props.credentialConfigured)
        // eslint-disable-next-line react-hooks/exhaustive-deps
      }, [snapshot, props.credentialConfigured])

      var writable = snapshot ? snapshot.writable !== false : true

      function save() {
        if (!writable) return
        setSaving(true)
        setMessage('')
        props.save({
          apiKey: apiKey.trim(),
          baseUrl: baseUrl.trim(),
          model: model.trim(),
          timeoutMs: Number(timeoutMs),
          pasteToPath: pasteToPath,
          autoDescribe: autoDescribe,
          sendTimeConvert: sendTimeConvert
        }).then((ok) => {
          setApiKey('')
          if (ok.configured != null) setConfigured(ok.configured)
          setMessage(ok.ok ? t('saved') : t('saveFailed'))
          setSaving(false)
        })
      }

      function checkbox(id, label, hint, checked, onChange) {
        return h('label', { className: 'vpr-check', key: id }, [
          h('input', {
            type: 'checkbox',
            checked: checked,
            onChange: (e) => onChange(e.target.checked)
          }),
          h('span', { className: 'vpr-label' }, label),
          hint ? h('span', { className: 'vpr-hint' }, hint) : null
        ])
      }

      return h('li', { className: 'vpr-card' + (open ? ' vpr-card-open' : '') }, [
        h('button', {
          type: 'button',
          className: 'vpr-header',
          'aria-expanded': open,
          'aria-label': (open ? t('collapse') : t('expand')) + ': ' + t('title'),
          onClick: () => setOpen(!open)
        }, [
          h('span', { className: 'vpr-head-text' }, [
            h('span', { className: 'vpr-name' }, t('title')),
            h('span', { className: 'vpr-desc' }, t('description'))
          ]),
          h('span', { className: 'vpr-badge' + (configured ? '' : ' vpr-badge-muted') }, configured ? t('apiKeySet') : t('apiKeyUnset')),
          h('span', { className: 'vpr-chevron' + (open ? ' vpr-chevron-open' : '') }, '▾')
        ]),
        open ? h('div', { className: 'vpr-body' }, [
          field('apiKey', t('apiKey'), configured ? t('apiKeySet') : t('apiKeyUnset'), apiKey, setApiKey, { secret: true, placeholder: configured ? '••••••••' : '' }),
          field('baseUrl', t('baseUrl'), t('baseUrlHint'), baseUrl, setBaseUrl),
          field('model', t('model'), t('modelHint'), model, setModel),
          field('timeoutMs', t('timeoutMs'), t('timeoutMsHint'), String(timeoutMs), setTimeoutMs),
          checkbox('pasteToPath', t('pasteToPath'), t('pasteToPathHint'), pasteToPath, setPasteToPath),
          checkbox('autoDescribe', t('autoDescribe'), t('autoDescribeHint'), autoDescribe, setAutoDescribe),
          checkbox('sendTimeConvert', t('sendTimeConvert'), t('sendTimeConvertHint'), sendTimeConvert, setSendTimeConvert),
          h('div', { className: 'vpr-actions' }, [
            h('button', { className: 'vpr-button', disabled: saving || !writable, onClick: save }, saving ? t('saving') : t('save')),
            message ? h('span', { className: 'vpr-message' }, message) : null
          ])
        ]) : null
      ])
    }

    /** Bind the settings scope and the credentials wire onto the card. */
    function CardController(ctx, scope, api) {
      this.ctx = ctx
      this.scope = scope
      this.api = api
      this.credentialConfigured = false
      var self = this
      scope.subscribe(function () {
        self.refreshCredential()
      })
      this.refreshCredential()
    }
    CardController.prototype.refreshCredential = function () {
      var self = this
      this.api.credentials.describe({ refs: [CRED_REF] }).then(function (response) {
        if (!response.result.ok) return
        var view = response.result.value.credentials[CRED_REF]
        var next = view ? view.configured === true : false
        if (next !== self.credentialConfigured) self.credentialConfigured = next
      }).catch(function () {})
    }
    CardController.prototype.save = function (patch) {
      var self = this
      var writes = []
      if (patch.apiKey && patch.apiKey.length > 0) {
        writes.push(this.api.credentials.set({ ref: CRED_REF, value: patch.apiKey }).then(function (r) {
          return r && r.result ? r.result.ok : false
        }).catch(function () { return false }))
      }
      if (patch.baseUrl && patch.baseUrl.length > 0) writes.push(this.scope.set('baseUrl', patch.baseUrl))
      if (patch.model && patch.model.length > 0) writes.push(this.scope.set('model', patch.model))
      if (Number.isFinite(patch.timeoutMs) && patch.timeoutMs > 0) writes.push(this.scope.set('timeoutMs', patch.timeoutMs))
      if (typeof patch.pasteToPath === 'boolean') writes.push(this.scope.set('pasteToPath', patch.pasteToPath))
      if (typeof patch.autoDescribe === 'boolean') writes.push(this.scope.set('autoDescribe', patch.autoDescribe))
      if (typeof patch.sendTimeConvert === 'boolean') writes.push(this.scope.set('sendTimeConvert', patch.sendTimeConvert))
      if (writes.length === 0) return Promise.resolve({ ok: true, configured: this.credentialConfigured })
      return Promise.all(writes).then(function () {
        self.refreshCredential()
        return { ok: true, configured: self.credentialConfigured }
      }).catch(function () {
        return { ok: false, configured: self.credentialConfigured }
      })
    }
    CardController.prototype.inject = function () {
      var self = this
      return {
        hooks: { vprCard: {
          getSnapshot: function () { return self.scope.getSnapshot() },
          subscribe: function (listener) { return self.scope.subscribe(listener) }
        } },
        subscribe: function (listener) { return self.scope.subscribe(listener) },
        getSnapshot: function () { return self.scope.getSnapshot() },
        credentialConfigured: function () { return self.credentialConfigured },
        save: function (patch) { return self.save(patch) }
      }
    }

    /**
     * Required services (cordis fiber inject). These are CORDIS SERVICE NAMES —
     * the `@deepseek-ai/dsh-client-*` package specifiers belong in package.json
     * `dsh.client.inject` (module dependency graph), never here. Waiting on the
     * package names blocks activation forever (the "pending" boot failure).
     */
    var inject = [
      'slots',
      'locale',
      'connection',
      'remote',
      'settingsScope'
    ]

    /** Mount the configuration card into the plugins settings section. */
    function apply(ctx) {
      var api = ctx.get('connection').api
      var t = ctx.locale.bind(NS)
      ctx.effect(function () {
        return ctx.locale.register(NS, {
          zh: {
            title: 'Vision Primitives(视觉交互推理)',
            description: 'MiMo 后端配置:未填 API Key 时仅本地视觉原语(网格/缩放/标注/测量/差分/颜色/OCR)可用;describe/locate 与 mimo 模型路由需要 Key。',
            apiKey: 'API Key(MiMo)',
            apiKeySet: '已配置',
            apiKeyUnset: '未配置',
            baseUrl: 'Base URL',
            baseUrlHint: 'MiMo OpenAI 兼容端点,默认 https://api.xiaomimimo.com/v1',
            model: '模型',
            modelHint: '默认 mimo-v2.5',
            timeoutMs: '超时(毫秒)',
            timeoutMsHint: '单次 MiMo 调用超时,默认 300000',
            pasteToPath: '纯文本模型贴图接管',
            pasteToPathHint: '开启后,纯文本模型下聊天框粘贴图片自动转为"路径 + 内容摘要"文本(社区 paste-to-path 方案)',
            autoDescribe: '粘贴自动描述',
            autoDescribeHint: '粘贴图片后用 MiMo 生成内容摘要插入输入框(需 API Key)',
            sendTimeConvert: '发送时图片桥接',
            sendTimeConvertHint: '开启后,纯文本模型可正常粘贴/拖动图片:发送时图片缓存为工作区文件,以 "[Attached image: 路径]" 文本交给模型(可用 read_image / vision_analyze 查看)',
            expand: '展开',
            collapse: '收起',
            save: '保存',
            saving: '保存中…',
            saved: '已保存',
            saveFailed: '保存失败'
          },
          en: {
            title: 'Vision Primitives (visual reasoning)',
            description: 'MiMo backend settings: without an API key only the local vision primitives (grid/zoom/annotate/measure/diff/color/OCR) work; describe/locate and the mimo model route need a key.',
            apiKey: 'API Key (MiMo)',
            apiKeySet: 'Configured',
            apiKeyUnset: 'Not configured',
            baseUrl: 'Base URL',
            baseUrlHint: 'MiMo OpenAI-compatible endpoint, default https://api.xiaomimimo.com/v1',
            model: 'Model',
            modelHint: 'Default mimo-v2.5',
            timeoutMs: 'Timeout (ms)',
            timeoutMsHint: 'Per-call timeout, default 300000',
            pasteToPath: 'Paste takeover for text-only models',
            pasteToPathHint: 'When on, pasting an image with a text-only model inserts "path + content summary" text instead (paste-to-path)',
            autoDescribe: 'Auto-describe pastes',
            autoDescribeHint: 'Generate a MiMo content summary for pasted images (needs API key)',
            sendTimeConvert: 'Send-time image bridge',
            sendTimeConvertHint: 'When on, text-only models can paste/drag images: at send time images are cached as workspace files and handed to the model as "[Attached image: path]" text (readable via read_image / vision_analyze)',
            autoDescribeHint: 'Generate a MiMo content summary for pasted images (needs API key)',
            expand: 'Expand',
            collapse: 'Collapse',
            save: 'Save',
            saving: 'Saving…',
            saved: 'Saved',
            saveFailed: 'Save failed'
          }
        })
      })
      var scope = ctx.settingsScope.bind({ namespace: NS })
      var controller = new CardController(ctx, scope, api)
      var registered = false
      function renderCard() {
        var hooks = controller.inject()
        return h(VprCard, {
          t: t,
          subscribe: hooks.subscribe,
          getSnapshot: hooks.getSnapshot,
          credentialConfigured: hooks.credentialConfigured(),
          save: hooks.save
        })
      }
      ctx.slots.inject('settings.plugin.item', function* () {
        if (registered) return
        registered = true
        yield ctx.slots.register({
          name: 'settings.plugin.item',
          id: 'vision-primitives',
          order: 30,
          locale: NS,
          inject: function () {
            return {
              hooks: { vprCard: {
                getSnapshot: function () { return scope.getSnapshot() },
                subscribe: function (listener) { return scope.subscribe(listener) }
              } },
              subscribe: function (listener) { return scope.subscribe(listener) },
              getSnapshot: function () { return scope.getSnapshot() },
              credentialConfigured: function () { return controller.credentialConfigured },
              save: function (patch) { return controller.save(patch) }
            }
          }
        }, renderCard)
      })
      ctx.effect(function () {
        if (typeof document === 'undefined') return function () {}
        if (!css) {
          // 主题安全: 边框/背景 fallback 一律用中性值, 文字 color:inherit —
          // 避免浅色主题下深色 fallback 造成的"黑底黑字"。
          css = '.vpr-card{list-style:none;border:1px solid var(--border-color,rgba(127,127,127,.4));border-radius:8px;background:var(--surface-color,transparent);overflow:hidden}' +
            '.vpr-header{display:flex;align-items:center;gap:10px;width:100%;padding:12px;background:none;border:none;color:inherit;cursor:pointer;text-align:left;font:inherit}' +
            '.vpr-head-text{display:flex;flex-direction:column;gap:2px;flex:1;min-width:0}' +
            '.vpr-name{font-weight:600;font-size:14px}.vpr-desc{font-size:12px;opacity:.75}' +
            '.vpr-badge{flex:none;font-size:11px;padding:2px 8px;border-radius:999px;border:1px solid var(--border-color,rgba(127,127,127,.4))}.vpr-badge-muted{opacity:.6}' +
            '.vpr-chevron{flex:none;opacity:.7;transition:transform .15s ease}.vpr-chevron-open{transform:rotate(180deg)}' +
            '.vpr-body{display:flex;flex-direction:column;gap:8px;padding:0 12px 12px}' +
            '.vpr-field{display:flex;flex-direction:column;gap:4px;font-size:13px}' +
            '.vpr-label{opacity:.9}.vpr-input{padding:6px 8px;border:1px solid var(--border-color,rgba(127,127,127,.4));border-radius:6px;background:transparent;color:inherit;font:inherit}' +
            '.vpr-hint{font-size:11px;opacity:.6}.vpr-check{display:flex;align-items:center;gap:8px;font-size:13px}.vpr-check .vpr-hint{display:block;width:100%}' +
            '.vpr-actions{display:flex;align-items:center;gap:10px;margin-top:4px}' +
            '.vpr-button{padding:6px 14px;border-radius:6px;border:1px solid var(--border-color,rgba(127,127,127,.4));background:var(--accent-color,#2d6cdf);color:#fff;cursor:pointer;font:inherit}' +
            '.vpr-button:disabled{opacity:.5;cursor:default}.vpr-message{font-size:12px;opacity:.8}'
          var el = document.createElement('style')
          el.textContent = css
          document.head.append(el)
        }
        return function () {}
      })
      // paste-to-path: capture-phase listeners, removed on plugin disposal.
      ctx.effect(function () {
        if (typeof document === 'undefined') return function () {}
        document.addEventListener('paste', onPaste, true)
        document.addEventListener('focusin', onPasteFocusIn, true)
        // 启动预取: 页面渲染出模型按钮后立刻建立裁决缓存, 使"第一次贴图"
        // 即按裁决接管 (两个时点, 覆盖慢渲染; focusin 预取继续兜底)。
        var boot1 = setTimeout(function () { refreshPasteVerdict(currentModelLabel()) }, 1500)
        var boot2 = setTimeout(function () { refreshPasteVerdict(currentModelLabel()) }, 4500)
        return function () {
          clearTimeout(boot1)
          clearTimeout(boot2)
          document.removeEventListener('paste', onPaste, true)
          document.removeEventListener('focusin', onPasteFocusIn, true)
        }
      }, 'vision-primitives: paste-to-path listener')
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  }
})
