// 快照的 skills 根：repository（= 快照目录名）→ 上游放 SKILL.md 的相对子路径。
// provider 的 customSkillDirs、test/packaging.test.mjs 的反查路径、test/persona.test.mjs 的
// files 登记都从这里取，所以"第三颗快照的 skill 不在 <repo>/skills/"这种结构差异只需要改一处。
// 上游目录结构本身不动（见 docs/dev/selected-skills.md §8.6）。
export const SELECTED_SKILL_SKILL_DIRS = Object.freeze({
  'investment-skills': 'skills',
  'china-stock-research-skills': 'skills',
  InvestSkill: 'plugins/us-stock-analysis/skills',
  // 上游把 SKILL.md 放在仓库根，快照因此套了一层 skills/<name>/（理由见该快照的 UPSTREAM.md）。
  'peter-lynch-skill': 'skills',
  // 上游把 skill 按主题分了两层（skills/<domain>/<name>/），provider 只枚举 skills 根的直接子目录，
  // 指上去等于发现 0 颗：快照因此平铺掉 <domain>/ 这一层（每颗的 references/、assets/ 跟着走，
  // 正文链接都在自己目录内，不破）。理由与逐颗原分组记在该快照的 UPSTREAM.md。
  'trading-skills': 'skills',
  // 上游有六个 skills 根（vertical-plugins/<条线>/skills/），并且 agent-plugins/<角色>/skills/ 是它自己
  // vendored 的副本（上游 CLAUDE.md 规定"不许直接改 bundled copies"）。provider 只扫一个根，
  // 因此只登记规范根那一条线：vertical-plugins/china-finance/skills —— 上游自己写明 skill 正文就 authored 在这里。
  // 另外五条线（投行 / PE / 基金运营 / 财富 / 账户）与副本留在快照里当材料，不进可选清单。
  'claude-for-financial-services-cn': 'vertical-plugins/china-finance/skills',
  // 上游就是扁平的 skills/<name>/SKILL.md（48 颗一层到底，frontmatter name 与目录名逐颗一致，
  // 正文链接全部落在自己目录内），所以前六颗踩过的套一层 / 平铺 / 多根取一都不用做。
  financeskills: 'skills',
  // 第八颗（Howard-Jerry/quant-agent-skills）：上游把三颗 skill 直接放在**仓库根**，而这三颗都是
  // 自述的编排器、正文指挥公开版不附带的私有数据层，一颗都不能进可选清单（判据见该快照 UPSTREAM.md）。
  // 快照因此另起一个 skills/ 根，里面只放本仓自持的那一颗入口；上游三颗完整住在 git、由快照自己的
  // .npmignore 挡在发布包之外，provider 的 skills 根里根本没有它们，list()/get() 也谈不上过滤。
  'quant-agent-skills': 'skills',
})

// Selected-skill metadata owned by Capital Generation. Upstream snapshots remain unchanged.
// 能力标签的词表由文件末尾的 SELECTED_SKILL_TAGS 注册表现算派生（SELECTED_SKILL_TAG_LABELS）：
// 卡片按条目实际用到的标签现算筛选条，少一套语言的显示名就会露出英文原词（test/capital-config.test.mjs
// 钉着）；tags 同时决定条目进哪几颗任务型内置 skill 的索引，所以登记一处、两处生效。
export const SELECTED_SKILL_CATALOG = Object.freeze([
  {
    key: 'buffettFramework',
    name: 'buffett-investment-framework',
    label: { zh: 'Buffett Investment Framework', en: 'Buffett Investment Framework' },
    description: {
      zh: '以证据为基础的商业质量、资本配置、估值和风险分析框架。主要源于美股语境。',
      en: 'Evidence-led business quality, capital allocation, valuation, and risk analysis. Primarily US-market oriented.',
    },
    owner: 'finterm-ai',
    repository: 'investment-skills',
    status: 'experimental',
    lastCommit: '2026-07-22',
    reviewBy: '2026-11-06',
    tags: ['business-analysis', 'cash-flow', 'perspective', 'risk', 'valuation'],
    riskNote: {
      zh: '实验性质；不能直接当作 A 股规则或投资建议。',
      en: 'Experimental; do not treat it as A-share rules or investment advice.',
    },
  },
  {
    key: 'financialHealth',
    name: 'financial-health',
    label: { zh: '财务健康', en: 'Financial Health' },
    description: {
      zh: '检查盈利质量、现金转换、营运资本、杠杆和资产负债表风险。',
      en: 'Checks earnings quality, cash conversion, working capital, leverage, and balance-sheet risk.',
    },
    owner: 'spikeHongg',
    repository: 'china-stock-research-skills',
    status: 'watchlist',
    lastCommit: '2026-03-09',
    reviewBy: '2026-11-06',
    tags: ['a-share', 'cash-flow', 'financial-health', 'risk'],
    riskNote: {
      zh: '冷启动实验；上游维护较久未更新，启用前请自行复核内容和来源。',
      en: 'Cold-start experiment; upstream has been quiet, so review content and sources before use.',
    },
  },
  {
    key: 'riskWarningCatalysts',
    name: 'risk-warning-catalysts',
    label: { zh: '风险与催化剂监控', en: 'Risk Warning Catalysts' },
    description: {
      zh: '把研究结论转成带来源、阈值和复查频率的风险与催化剂监控项。',
      en: 'Turns research into source-backed risk and catalyst monitoring with thresholds and review cadence.',
    },
    owner: 'spikeHongg',
    repository: 'china-stock-research-skills',
    status: 'watchlist',
    lastCommit: '2026-03-09',
    reviewBy: '2026-11-06',
    tags: ['a-share', 'monitoring', 'risk'],
    riskNote: {
      zh: '冷启动实验；不负责估值或交易决策。',
      en: 'Cold-start experiment; it does not make valuation or trading decisions.',
    },
  },
  {
    key: 'valuationInvestmentStrategy',
    name: 'valuation-investment-strategy',
    label: { zh: '估值与情景分析', en: 'Valuation Investment Strategy' },
    description: {
      zh: '在事实基础完成后构建带假设、情景和失效条件的估值框架。',
      en: 'Builds valuation scenarios with assumptions and invalidation conditions after the factual base is ready.',
    },
    owner: 'spikeHongg',
    repository: 'china-stock-research-skills',
    status: 'watchlist',
    lastCommit: '2026-03-09',
    reviewBy: '2026-11-06',
    tags: ['a-share', 'risk', 'valuation'],
    riskNote: {
      zh: '冷启动实验；输出不等于买卖或仓位建议。',
      en: 'Cold-start experiment; output is not a buy, sell, or position-size recommendation.',
    },
  },
  {
    key: 'strategyBusinessTransition',
    name: 'strategy-business-transition',
    label: { zh: '战略与业务转型', en: 'Strategy Business Transition' },
    description: {
      zh: '检验公司战略叙事、业务迁移、资本配置和转型里程碑。',
      en: 'Tests strategy narratives, business migration, capital allocation, and transition milestones.',
    },
    owner: 'spikeHongg',
    repository: 'china-stock-research-skills',
    status: 'watchlist',
    lastCommit: '2026-03-09',
    reviewBy: '2026-11-06',
    tags: ['a-share', 'strategy', 'risk'],
    riskNote: {
      zh: '冷启动实验；不负责估值或交易计划。',
      en: 'Cold-start experiment; it does not make valuation or trading plans.',
    },
  },
  {
    key: 'industryCompetitionMoat',
    name: 'industry-competition-moat',
    label: { zh: '行业竞争与护城河', en: 'Industry Competition Moat' },
    description: {
      zh: '分析行业结构、竞争格局、供需和公司差异化是否可持续。',
      en: 'Analyzes industry structure, competition, supply-demand, and sustainable differentiation.',
    },
    owner: 'spikeHongg',
    repository: 'china-stock-research-skills',
    status: 'watchlist',
    lastCommit: '2026-03-09',
    reviewBy: '2026-11-06',
    tags: ['a-share', 'business-analysis', 'competition', 'risk'],
    riskNote: {
      zh: '冷启动实验；行业判断仍需回到公开证据。',
      en: 'Cold-start experiment; industry conclusions still require public evidence.',
    },
  },
  {
    key: 'businessDecompositionOrderQuality',
    name: 'business-decomposition-order-quality',
    label: { zh: '业务拆解与订单质量', en: 'Business Decomposition Order Quality' },
    description: {
      zh: '拆解产品、客户、项目和订单，检查增长能否转化为收入和现金。',
      en: 'Breaks down products, customers, projects, and orders to test conversion into revenue and cash.',
    },
    owner: 'spikeHongg',
    repository: 'china-stock-research-skills',
    status: 'watchlist',
    lastCommit: '2026-03-09',
    reviewBy: '2026-11-06',
    tags: ['a-share', 'business-analysis', 'cash-flow', 'orders', 'risk'],
    riskNote: {
      zh: '冷启动实验；不负责最终估值或买卖建议。',
      en: 'Cold-start experiment; it does not make final valuation or trading recommendations.',
    },
  },
  {
    key: 'tenKDigest',
    name: '10k-digest',
    label: { zh: '年报（10-K）逐节精读', en: '10-K Report Digest' },
    description: {
      zh: '逐节精读美股年报 10-K，产出摘要、分节要点、关键指标与可核对的出处引用。',
      en: 'Reads a 10-K section by section into an abstract, section summaries, key metrics and sourced references.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'filings', 'business-analysis'],
    riskNote: {
      zh: '实验性质；章节口径按美股 10-K 写，A 股年报的披露结构不同，不能直接平移。',
      en: 'Experimental; the section map follows US 10-K disclosure and does not transfer to A-share annual reports.',
    },
  },
  {
    key: 'bearCase',
    name: 'bear-case',
    label: { zh: '空头视角红队反驳', en: 'Bear Case Red Team' },
    description: {
      zh: '针对一个看多论点刻意构建最强的反面论证，逐条找出反证与脆弱假设。',
      en: 'Builds the strongest deliberate short-side counter-argument to a bullish thesis, with counterevidence.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'risk', 'perspective'],
    riskNote: {
      zh: '实验性质；只做反面论证，不构成卖出或做空建议，也不预测跌幅。',
      en: 'Experimental; a counter-argument only, not a sell or short recommendation and no downside forecast.',
    },
  },
  {
    key: 'catalystCalendar',
    name: 'catalyst-calendar',
    label: { zh: '90 天催化剂日历', en: 'Catalyst Calendar' },
    description: {
      zh: '列出未来 90 天的事件催化剂与预期影响，用来安排复查节奏。',
      en: 'Lists upcoming catalysts over a 90-day window with expected impact and a review cadence.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'earnings', 'monitoring'],
    riskNote: {
      zh: '实验性质；事件影响是定性判断，不预测具体涨跌。',
      en: 'Experimental; catalyst impact is qualitative and does not forecast price moves.',
    },
  },
  {
    key: 'competitorAnalysis',
    name: 'competitor-analysis',
    label: { zh: '直接对手与护城河', en: 'Competitor Analysis' },
    description: {
      zh: '围绕一家公司与其直接对手做护城河、市场地位与行业格局分析。',
      en: 'Moat, market position and industry dynamics for one company against its direct rivals.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'competition', 'business-analysis', 'risk'],
    riskNote: {
      zh: '与「行业竞争与护城河」视角重叠，同业名单与口径按美股披露取材；结论仍要回到公开证据。',
      en: 'Overlaps the industry/moat lens; peer sets follow US disclosure, so conclusions still need public evidence.',
    },
  },
  {
    key: 'dividendAnalysis',
    name: 'dividend-analysis',
    label: { zh: '分红回购与资本配置', en: 'Dividend & Capital Allocation' },
    description: {
      zh: '把分红、回购、并购、债务管理与自由现金流去向合起来看资本配置纪律。',
      en: 'Reviews dividends, buybacks, M&A, debt and FCF deployment as one capital-allocation discipline.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'capital-allocation', 'cash-flow', 'valuation'],
    riskNote: {
      zh: '实验性质；不承诺股息可持续性，也不预测收益。',
      en: 'Experimental; it does not promise dividend sustainability or returns.',
    },
  },
  {
    key: 'earningsCallAnalysis',
    name: 'earnings-call-analysis',
    label: { zh: '业绩电话会文本分析', en: 'Earnings Call Analysis' },
    description: {
      zh: '从业绩电话会纪要里读情绪、主题与管理层口径的变化。',
      en: 'Reads sentiment, themes and shifts in management tone from earnings call transcripts.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'earnings', 'perspective'],
    riskNote: {
      zh: '必须先拿到纪要原文；没有原文时不许凭印象补写管理层表态。',
      en: 'Needs the actual transcript; never reconstruct management remarks from memory.',
    },
  },
  {
    key: 'earningsPreview',
    name: 'earnings-preview',
    label: { zh: '财报前三档情景推演', en: 'Earnings Preview' },
    description: {
      zh: '对比一致预期与期权隐含波动，给出超预期/符合/不及三档情景与各自要盯的指标。',
      en: 'Compares consensus with the implied move and lays out beat / in-line / miss scenarios with watch KPIs.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'earnings', 'risk', 'monitoring'],
    riskNote: {
      zh: '实验性质；正文每档情景带仓位写法，只当推演练习，不是交易指令。',
      en: 'Experimental; each scenario carries position wording — read it as a rehearsal, not a trade instruction.',
    },
  },
  {
    key: 'economicsAnalysis',
    name: 'economics-analysis',
    label: { zh: '美国宏观指标解读', en: 'US Economics Analysis' },
    description: {
      zh: '解读美国宏观数据与利率路径，并交代它传导到市场的路径。',
      en: 'Interprets US macro prints and the rate path, and spells out the transmission to markets.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'macro', 'risk'],
    riskNote: {
      zh: '口径是美国宏观，对 A 股只能当外部环境变量，不直接推政策。',
      en: 'US macro only; for A-shares treat it as an external condition, not a policy read.',
    },
  },
  {
    key: 'etfAnalysis',
    name: 'etf-analysis',
    label: { zh: 'ETF 尽调与契合度评分', en: 'ETF Analysis' },
    description: {
      zh: '费率、跟踪误差、流动性、成分集中度与持仓重叠，汇成一枚 ETF 契合度评分。',
      en: 'Expense ratio, tracking difference, liquidity, concentration and overlap rolled into a fitness score.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'instruments', 'portfolio', 'risk'],
    riskNote: {
      zh: '实验性质；评分衡量结构特征，不代表收益预期。',
      en: 'Experimental; the score describes structure, not expected return.',
    },
  },
  {
    key: 'factCheck',
    name: 'fact-check',
    label: { zh: '逐条主张核验与补引用', en: 'Fact Check' },
    description: {
      zh: '把报告里的每个数字与事实主张拆出来逐条比对一手来源，标注已核验/不符/无法核验并回填引用。',
      en: 'Extracts every figure and claim, checks each against a primary source, and marks verified / mismatch / unverifiable.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'filings', 'verification'],
    riskNote: {
      zh: '一手来源清单按 SEC 文件、公司 IR、FRED 与交易所数据写；A 股材料要换成公告与官方披露。',
      en: 'Its primary-source list is SEC / IR / FRED / exchange data; swap in announcements and official disclosure for A-shares.',
    },
  },
  {
    key: 'financialReportAnalyst',
    name: 'financial-report-analyst',
    label: { zh: '财报质量与红旗解读', en: 'Financial Report Analyst' },
    description: {
      zh: '从 10-K / 10-Q 读报表质量、异常红旗与一个可交代出处的信号。',
      en: 'Reads statement quality, red flags and one sourced signal from 10-K / 10-Q filings.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'filings', 'financial-health', 'risk'],
    riskNote: {
      zh: '实验性质；红旗是提示复查的线索，不是结论。',
      en: 'Experimental; red flags are prompts to re-check, not conclusions.',
    },
  },
  {
    key: 'industryMap',
    name: 'industry-map',
    label: { zh: '产业链地图与咽喉点', en: 'Industry Map' },
    description: {
      zh: '把上下游画成有向图，定位公司位置、找供需瓶颈与利润池，并派生二线线索。',
      en: 'Maps the value chain as a directed graph to locate the company, find chokepoints and second-order ideas.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'macro', 'competition', 'business-analysis'],
    riskNote: {
      zh: '实验性质；产业链判断仍需逐条回到公开证据。',
      en: 'Experimental; value-chain reads still need claim-by-claim public evidence.',
    },
  },
  {
    key: 'insiderTrading',
    name: 'insider-trading',
    label: { zh: '内部人增减持追踪', en: 'Insider Trading' },
    description: {
      zh: '从 SEC Form 4 追踪高管与董事的增减变动并做解读。',
      en: 'Tracks executive and director buying and selling from SEC Form 4 filings.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'filings', 'monitoring', 'perspective'],
    riskNote: {
      zh: '依赖美国内部人申报制度；A 股要换成大股东与董监高变动公告，口径不可直接平移。',
      en: 'Assumes US insider filings; A-shares need major-holder and director-change announcements instead.',
    },
  },
  {
    key: 'institutionalOwnership',
    name: 'institutional-ownership',
    label: { zh: '机构持仓变动', en: 'Institutional Ownership' },
    description: {
      zh: '从 13F 文件读机构持仓变化，识别机构资金的迁移方向。',
      en: 'Reads changes in institutional holdings from 13F filings to spot where the money is moving.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'filings', 'monitoring'],
    riskNote: {
      zh: '13F 有一个季度滞后且不含空头仓位；读成趋势之前先记住这两点。',
      en: '13F lags a quarter and omits shorts — remember both before reading it as a trend.',
    },
  },
  {
    key: 'learningCoach',
    name: 'learning-coach',
    label: { zh: '把分析讲成课程', en: 'Learning Coach' },
    description: {
      zh: '像导师一样逐指标解释一份分析结果，再反问 3–5 个检验理解的问题。',
      en: 'Explains an analysis metric by metric in plain words, then asks 3–5 Socratic questions.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['education', 'perspective'],
    riskNote: {
      zh: '教学性质；它解释的是上游分析的口径，不额外产生投资判断。',
      en: 'Educational; it explains the analysis it is handed and forms no investment view of its own.',
    },
  },
  {
    key: 'optionsAnalysis',
    name: 'options-analysis',
    label: { zh: '期权希腊字母与隐波', en: 'Options Analysis' },
    description: {
      zh: '看希腊字母、隐含波动率与策略适配度，用来理解期权的风险形状。',
      en: 'Reviews Greeks, implied volatility and strategy fit to characterise an options risk shape.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'instruments', 'risk'],
    riskNote: {
      zh: '实验性质；只解释期权风险，不推荐具体合约或策略组合。',
      en: 'Experimental; it explains options risk and does not recommend contracts or spreads.',
    },
  },
  {
    key: 'portfolioReview',
    name: 'portfolio-review',
    label: { zh: '组合表现与配置偏离', en: 'Portfolio Review' },
    description: {
      zh: '复盘组合的收益来源、集中度与配置偏离，并列出需要盯的观察项。',
      en: 'Reviews portfolio performance, concentration and allocation drift, with items to watch.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'portfolio', 'risk'],
    riskNote: {
      zh: '与本插件自带的组合复盘流程重叠；这条按美股语境给观察清单，仓位动作仍由使用者决定。',
      en: 'Overlaps the built-in portfolio review; this one gives a US-context watchlist and leaves position moves to you.',
    },
  },
  {
    key: 'positionLadder',
    name: 'position-ladder',
    label: { zh: '分批建仓与摊薄节奏', en: 'Position Ladder' },
    description: {
      zh: '把建仓拆成分批的股数上下限与加减仓节奏，并检查批次记账、洗售窗口与总收益口径。',
      en: 'Plans a staged entry with share-count floors and ceilings, trim/re-add cadence, lot and wash-sale checks.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'portfolio', 'monitoring'],
    riskNote: {
      zh: '正文里的股数区间是推演用的练习，不是买卖指令；本插件没有券商接口、不替使用者下单，仓位决定在使用者。',
      en: 'Its share-count ranges are rehearsal arithmetic, not orders; this plugin holds no broker interface and places nothing for you — the sizing call stays with you.',
    },
  },
  {
    key: 'resultValidator',
    name: 'result-validator',
    label: { zh: '分析结果置信度评分', en: 'Result Validator' },
    description: {
      zh: '从数据质量、方法一致性与信号冲突三个维度，给一份分析结果打置信度分。',
      en: 'Scores an analysis\'s confidence across data quality, methodology and signal consistency.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['verification', 'perspective'],
    riskNote: {
      zh: '打的是数据与方法自洽度，不等于预测准确率，也不承诺表现。',
      en: 'It grades internal data/method consistency, not forecast accuracy or future performance.',
    },
  },
  {
    key: 'riskStressTest',
    name: 'risk-stress-test',
    label: { zh: '组合压力测试与风险预算', en: 'Risk Stress Test' },
    description: {
      zh: 'beta 加权敞口、历史情景重放、VaR / CVaR、最大回撤估计与流动性退出天数。',
      en: 'Beta-weighted exposure, historical scenario replay, VaR / CVaR, drawdown estimates and days to exit.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'portfolio', 'risk', 'macro'],
    riskNote: {
      zh: '模型化估计，假设一变结果就变；不构成风控额度，也不是减仓指令。',
      en: 'Model output moves with every assumption; this is not a risk limit or a de-risking order.',
    },
  },
  {
    key: 'sectorAnalysis',
    name: 'sector-analysis',
    label: { zh: '板块相对强弱与轮动', en: 'Sector Analysis' },
    description: {
      zh: '看美国各板块的相对强弱与轮动线索，并交代判断依据。',
      en: 'Reviews US sector positioning and rotation clues, and states what each read rests on.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'macro', 'competition'],
    riskNote: {
      zh: '板块分类按美股口径，与 A 股行业分类不可直接对照。',
      en: 'Sector taxonomy is US-market; it does not line up with A-share industry classification.',
    },
  },
  {
    key: 'shortInterest',
    name: 'short-interest',
    label: { zh: '空头持仓与挤压条件', en: 'Short Interest' },
    description: {
      zh: '读空头比例、回补成本与挤压条件，并检查利空堆积信号。',
      en: 'Analyses short ratio, cost to cover, squeeze conditions and bearish positioning signals.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'filings', 'monitoring', 'risk'],
    riskNote: {
      zh: '空头数据是滞后披露；当成实时结论之前先核对口径与截止日期。',
      en: 'Short data is reported with a lag — check basis and as-of date before reading it as live.',
    },
  },
  {
    key: 'stockEval',
    name: 'stock-eval',
    label: { zh: '基本面与估值综合评估', en: 'Stock Evaluation' },
    description: {
      zh: '把财务质量、成长、估值与风险合到一次综合评估里，并输出一个可交代出处的结论。',
      en: 'Combines quality, growth, valuation and risk into one evaluation with a sourced conclusion.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'business-analysis', 'financial-health', 'valuation', 'risk'],
    riskNote: {
      zh: '上游已把 fundamental-analysis 合入本条；综合结论仍是美股口径，不替代本插件既有研究流程。',
      en: 'Upstream folded fundamental-analysis in; the read is US-context and does not replace Capital\'s own research flow.',
    },
  },
  {
    key: 'stockScreener',
    name: 'stock-screener',
    label: { zh: '多标的横向打分排序', en: 'Stock Screener' },
    description: {
      zh: '按估值、质量、动量、情绪与成长五个维度给一篮子标的打分并排序。',
      en: 'Screens and ranks a list of US stocks across valuation, quality, momentum, sentiment and growth.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'valuation', 'business-analysis', 'technicals'],
    riskNote: {
      zh: '排序只反映当期打分口径，不预测未来表现；标的清单与数据来源仍要走本插件的取数链路。',
      en: 'Ranking reflects the current scoring inputs only, not future performance; data still comes via Capital\'s own sources.',
    },
  },
  {
    key: 'stockValuation',
    name: 'stock-valuation',
    label: { zh: '四方法估值区间', en: 'Stock Valuation' },
    description: {
      zh: 'DCF、可比公司、EV 倍数与剩余收益一起出估值区间，并逐条交代假设。',
      en: 'Values a company with DCF, comparables, EV multiples and residual income, stating every assumption.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'valuation', 'cash-flow'],
    riskNote: {
      zh: '区间随假设大幅移动；输出不等于目标价，也不是买卖建议。',
      en: 'Ranges swing with assumptions; the output is not a price target or a trade call.',
    },
  },
  {
    key: 'taxLens',
    name: 'tax-lens',
    label: { zh: '美国税务视角检视清单', en: 'Tax Lens' },
    description: {
      zh: '长短期资本利得、洗售窗口、合格股息持有期、批次选择与年度税负拖累的检视清单。',
      en: 'Checks short vs. long-term gains, wash-sale windows, qualified dividends, lot selection and estimated tax drag.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'tax', 'portfolio'],
    riskNote: {
      zh: '只讲美国税制且止于教育口径；中国大陆的税务与账户安排请咨询专业人士。',
      en: 'US tax mechanics, educational only; get professional advice for mainland-China tax and account matters.',
    },
  },
  {
    key: 'technicalAnalysis',
    name: 'technical-analysis',
    label: { zh: '技术面与指标解读', en: 'Technical Analysis' },
    description: {
      zh: '用均线、成交量、RSI / MACD 等指标读趋势、关键价位与复查触发条件。',
      en: 'Reads trend and key levels with moving averages, volume, RSI and MACD, plus re-check triggers.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'technicals', 'monitoring'],
    riskNote: {
      zh: '技术信号只给复查条件，不预测方向；不要把图形结论写成事实。',
      en: 'Technical signals are re-check triggers, not direction forecasts — do not present them as facts.',
    },
  },
  {
    key: 'thesisTracker',
    name: 'thesis-tracker',
    label: { zh: '投资论点存档与复核', en: 'Thesis Tracker' },
    description: {
      zh: '写下论点的 KPI、失效条件与催化剂，之后按新数据复查并给出维持 / 走弱 / 失效。',
      en: 'Records KPIs, invalidation triggers and catalysts, then re-checks them as INTACT / WEAKENED / BROKEN.',
    },
    owner: 'yennanliu',
    repository: 'InvestSkill',
    status: 'experimental',
    lastCommit: '2026-09-25',
    reviewBy: '2026-11-06',
    tags: ['us-stock', 'verification', 'monitoring', 'perspective'],
    riskNote: {
      zh: '上游假设能把论点落盘；在本插件下文件写在工作目录并服从当前会话权限。',
      en: 'Upstream assumes it can save files; under Capital it writes into the session workspace and obeys its permissions.',
    },
  },
  {
    key: 'peterLynchResearch',
    name: 'peter-lynch-skill',
    label: { zh: '彼得·林奇式个股研究', en: 'Peter Lynch Research' },
    description: {
      zh: '给一个代码或公司名，走快筛（SKIP / WATCHLIST / DEEP RESEARCH）或完整尽调，生意理解、分类与估值放在同一套检查里，每条主张配可点开的来源链接。美股与境外上市口径。',
      en: 'Screens a ticker or company fast (SKIP / WATCHLIST / DEEP RESEARCH) or runs full due diligence, with linked sources under every claim. US and overseas-listing conventions.',
    },
    owner: 'DjNero11',
    repository: 'peter-lynch-skill',
    status: 'watchlist',
    lastCommit: '2026-06-28',
    reviewBy: '2026-11-06',
    tags: ['peter-lynch', 'us-stock', 'valuation', 'risk', 'verification'],
    riskNote: {
      zh: '冷启动实验；上游仅两次提交、自 2026-06-28 起无更新，启用前请自行复核来源。X/10 衡量的是论点自洽度与结构特征，不预测表现，也不构成买卖建议。',
      en: 'Cold-start experiment; upstream has two commits and has been quiet since 2026-06-28, so review the sources before use. The X/10 score rates thesis consistency and structure, not forecast performance, and is not investment advice.',
    },
  },
  {
    key: 'catalystMap',
    name: 'catalyst-map',
    label: { zh: '催化剂地图', en: 'Catalyst Map' },
    description: {
      zh: '把要发生的事件按"影响什么、什么时候影响、会传导到谁"排成注意力优先级，并标出依赖同一事件链的持仓。美股与境外宏观日历口径。',
      en: 'Ranks upcoming events by what they move, when, and how they transmit across related names, and flags positions hanging on the same event chain. US and overseas calendar conventions.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'macro', 'monitoring', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。它排的是注意力优先级，不预测价格走向，也不构成买卖建议。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. The map ranks attention, not price direction, and is not investment advice.',
    },
  },
  {
    key: 'watchlistReview',
    name: 'watchlist-review',
    label: { zh: '自选股分诊', en: 'Watchlist Review' },
    description: {
      zh: '对使用者给出的自选清单做分诊：哪些值得盯、哪些只作背景、哪些理由已经不成立，并说清移出的是清单条目而不是持仓。',
      en: 'Triages the watchlist the user supplies into active focus, background monitoring, or removal, and says that what comes off is a list entry, not a position.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'portfolio', 'monitoring', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。分诊只作用于自选清单，不构成买卖动作；本插件读不到券商账户。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. The triage acts on the watchlist only, is not a buy or sell action, and this plugin cannot read a brokerage account.',
    },
  },
  {
    key: 'evidenceGapCheck',
    name: 'evidence-gap-check',
    label: { zh: '证据缺口检查', en: 'Evidence Gap Check' },
    description: {
      zh: '把一笔想法还缺的事实、假设与未解问题按"会不会改变判断"排序，说清哪些缺口必须先补、哪些只是降低置信度。',
      en: 'Ranks the missing facts, assumptions and open questions behind an idea by whether they change the judgement, and separates blocking gaps from confidence gaps.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'verification', 'risk'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。它只列证据缺口，不给评级、不替使用者决定这笔做不做。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. It lists evidence gaps only: no rating, and no decision about whether to take the trade.',
    },
  },
  {
    key: 'thesisValidation',
    name: 'thesis-validation',
    label: { zh: '论点压力测试', en: 'Thesis Validation' },
    description: {
      zh: '把一个说法压成可检验的主张：论点、证据、失效条件与时间窗分开写，再判它够不够格进入结构检查。',
      en: 'Turns a claim into something testable — thesis, evidence, invalidation, timeframe — then judges whether it is ready to be built on.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'verification', 'risk'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。判的是论点是否自洽可检验，不预测表现，也不构成买卖建议。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. It tests whether a thesis is coherent and falsifiable, not how it will perform, and is not investment advice.',
    },
  },
  {
    key: 'riskRewardSanityCheck',
    name: 'risk-reward-sanity-check',
    label: { zh: '盈亏比自洽检查', en: 'Risk-Reward Sanity Check' },
    description: {
      zh: '按入场、止损与目标算出盈亏比，再检查这个结构是否自洽：目标是否落在噪声里、止损是否在明显的流动性聚集处。',
      en: 'Works out the reward-to-risk ratio from entry, stop and target, then tests whether the structure holds — targets inside noise, stops sitting in obvious liquidity pools.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'risk', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。比值衡量的是结构自洽与失败面，不是胜率或收益承诺，本插件也不据它给仓位数字。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. The ratio measures structural coherence and failure modes, not win rate or returns, and this plugin derives no position size from it.',
    },
  },
  {
    key: 'executionPlanCheck',
    name: 'execution-plan-check',
    label: { zh: '执行计划检查', en: 'Execution Plan Check' },
    description: {
      zh: '检查一份交易计划在操作上是否真的能落地：订单类型与紧迫度是否匹配、流动性与点差风险、事件时点、止损能否成交。',
      en: 'Checks whether a plan is operationally workable: order type against urgency, liquidity and spread risk, event timing, and whether a stop would actually fill.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'risk', 'monitoring', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。检查的是计划的可操作性：本插件没有券商接口，不下单、不改单，也不会替你执行任何一笔。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. It reviews whether a plan is executable: this plugin has no broker interface, places and amends no orders and executes nothing for you.',
    },
  },
  {
    key: 'portfolioConcentration',
    name: 'portfolio-concentration',
    label: { zh: '组合集中度检查', en: 'Portfolio Concentration' },
    description: {
      zh: '看组合是否过度压在同一批发行人、行业、主题或相关暴露上，并写清这个判断需要哪些持仓数据才成立。',
      en: 'Shows whether a book leans too hard on a few issuers, sectors, themes or correlated exposures, and what holdings data that verdict needs to stand.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'portfolio', 'risk'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。文中的 5%／10% 一类是经验口径不是普适规则；持仓只以使用者自报的标记为准（本插件读不到券商账户），也不构成加减仓建议。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. The 5% / 10% bands are practical review thresholds, not universal laws; the book comes only from positions the user marked as held (this plugin cannot read a brokerage account), and it is not advice to add or reduce.',
    },
  },
  {
    key: 'journalPatternAnalyzer',
    name: 'journal-pattern-analyzer',
    label: { zh: '交易日志模式分析', en: 'Journal Pattern Analyzer' },
    description: {
      zh: '从使用者自己的交易日志里找重复出现的优势与失误、它们各自发生在什么环境下，并为小样本设护栏。',
      en: 'Finds the repeated strengths and mistakes in the user’s own trade journal, groups them by environment, and keeps small samples from hardening into lessons.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'education', 'portfolio'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。胜率、期望值这类数字是对已有日志的描述，不证明可持续的优势，也不构成投资建议。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. Win rate and expectancy describe the log you already have: they prove no durable edge and are not investment advice.',
    },
  },
  {
    key: 'postTradeReview',
    name: 'post-trade-review',
    label: { zh: '交易复盘', en: 'Post-Trade Review' },
    description: {
      zh: '按论点、setup、执行、守规与结果几条线复盘一笔已经平掉的交易，避免用后视镜编造教训。',
      en: 'Reviews a closed trade across thesis, setup, execution, adherence and outcome without rewriting it with hindsight.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'education'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。复盘得出的"下次要改的规则"属于过程推演，本插件不据它替使用者调整持仓或下单。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. The rule changes it suggests are process exercises: this plugin adjusts no holdings and places no orders on them.',
    },
  },
  {
    key: 'positionSizing',
    name: 'position-sizing',
    label: { zh: '入场仓位测算', en: 'Position Sizing' },
    description: {
      zh: '从账户规模、单笔风险预算、入场价与止损价反推一个可辩护的仓位，并把摩擦成本、事件风险与流动性挡在公式之外——它只算大小，不评判这笔该不该做。',
      en: 'Works a defensible size back from account equity, a per-trade risk budget, entry and stop, with trading friction taken into account; it sizes the trade and deliberately does not judge the thesis.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'risk', 'portfolio', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。它给出的仓位数字是方法推演，不是订单：本插件没有券商接口，不据它下单，也不替你动任何一笔仓；账户规模与风险预算由你提供，取不到就停下而不是猜。止损、滑点、合约乘数与流动性那一档按美股／境外口径写（A 股 T+1、涨跌停与集合竞价都不成立）。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. The size it produces is a method exercise, not an order: this plugin holds no broker interface, places nothing on it and moves no position for you. Account equity and risk budget come from you — if they are missing it stops rather than guesses. Stops, slippage, contract multipliers and liquidity assumptions are US / offshore conventions (A-share T+1, daily limits and the call auction do not map onto them).',
    },
  },
  {
    key: 'positionManagement',
    name: 'position-management',
    label: { zh: '持仓论点复核', en: 'Position Management' },
    description: {
      zh: '对照原始论点、失效条件、催化剂日历与执行约束复查一笔在手仓位，给出继续持有、减仓、收紧止损还是离场的判断，并交代这个判断建立在哪些证据上。',
      en: 'Revisits an open position against the original thesis, its invalidation logic, the catalyst calendar and execution constraints, then argues hold, trim, tighten or exit on stated evidence.',
    },
    owner: 'marian2js',
    repository: 'trading-skills',
    status: 'watchlist',
    lastCommit: '2026-03-16',
    reviewBy: '2026-11-06',
    tags: ['trade-discipline', 'monitoring', 'portfolio', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游自 2026-03-16 起无提交，启用前请自行复核来源。持仓加减（持有 / 减仓 / 收紧 / 离场）属于方法推演，本插件没有券商接口、不代你执行任何一笔；原始论点或持仓信息缺失时它按临时口径复查并点名缺口，不编一份干净的事前计划。期权、盘后时段与执行约束那一档按美股／境外口径写，A 股的 T+1、涨跌停与集合竞价在正文里没有对应物。',
      en: 'Cold-start experiment; upstream has been quiet since 2026-03-16, so review the sources before use. The hold / trim / tighten / exit call is a method exercise: this plugin holds no broker interface and executes nothing for you. When the original plan or position detail is missing it reviews provisionally and names the gap instead of inventing a tidy prior plan. Options, extended hours and execution constraints follow US / offshore conventions — A-share T+1, daily price limits and the call auction have no counterpart in the text.',
    },
  },
  {
    key: 'chinaEarningsAnalysis',
    name: 'china-earnings-analysis',
    label: { zh: 'A 股业绩点评', en: 'A-Share Earnings Review' },
    description: {
      zh: '把已覆盖公司的季报或年报写成 A 股卖方体例的点评：实际 / 一致预期 / 上期的差异表、收入与利润率分解、资产负债表与现金流关注点，再落到估值与风险。',
      en: 'Writes a quarterly or annual update in Chinese sell-side format: an actual / consensus / prior variance table, revenue and margin decomposition, balance-sheet and cash-flow focus, then valuation and risks.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'earnings', 'filings', 'financial-health'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。本插件没有一致预期的结构化取数面：那一列取不到就留空并点名缺失，不用记忆补。报告里的评级与目标价段落属于推演练习，不构成买卖建议。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. This plugin has no consensus endpoint: that column stays empty and the gap is named rather than remembered. The rating and target-price paragraphs are exercises, not investment advice.',
    },
  },
  {
    key: 'chinaEarningsPreview',
    name: 'china-earnings-preview',
    label: { zh: 'A 股财报前瞻', en: 'A-Share Earnings Preview' },
    description: {
      zh: '公布前把关注点排好：历史基线、要盯的三到五个指标、乐观 / 基准 / 悲观三档情景与触发条件，按 A 股披露节奏（业绩预告、快报、正式报告）写前瞻。',
      en: 'Sets up the pre-release frame: historical baseline, the three to five metrics that matter, bull / base / bear scenarios with their triggers, all on the A-share rhythm of 预告, 快报 and the full report.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'earnings', 'monitoring'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。宿主取不到一致预期时，情景对比写在历史与自家披露口径上，并标明那是你自己的基线；文中的仓位与交易策略设想属于推演练习。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. With no retrievable consensus, scenarios are framed against history and the company’s own disclosed range, labelled as your baseline; the sizing and trade ideas it sketches are exercises.',
    },
  },
  {
    key: 'chinaCompsAnalysis',
    name: 'china-comps-analysis',
    label: { zh: 'A 股可比公司倍数', en: 'A-Share Comparable Multiples' },
    description: {
      zh: '按 A 股口径搭同业倍数表：板块分组与市值 / 增速 / 盈利性筛选，P/E（动态·静态·TTM）、P/B、EV/EBITDA 与溢价折价的解释，最后收敛成一个估值区间。',
      en: 'Builds a peer multiple table on A-share conventions: sector grouping with size, growth and profitability screens, dynamic / static / TTM P/E, P/B and EV/EBITDA, premium and discount explanations, and a resulting valuation range.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'valuation', 'competition'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。区间随倍数假设大幅移动，末尾的目标价与投资建议属于推演练习，本插件没有券商接口，不据它下单，也不会替你执行任何一笔。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. The range moves with the multiple assumptions, and the closing target price and recommendation are exercises: this plugin has no broker interface and places no order on them.',
    },
  },
  {
    key: 'chinaDcf',
    name: 'china-dcf',
    label: { zh: 'A 股 DCF 口径', en: 'A-Share DCF Conventions' },
    description: {
      zh: '用中国财报口径跑 DCF：无风险利率取十年期国债收益率、A 股股权风险溢价、25% 税率（高新技术企业 15%）、本币终值增长，再把 WACC 与敏感性摊开。',
      en: 'Runs a DCF on Chinese conventions: a 10-year government bond yield as the risk-free rate, A-share equity risk premium, 25% tax (15% for 高新技术企业), local-currency terminal growth, then WACC and sensitivities.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'valuation', 'cash-flow'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。国债收益率或 β 取不到时按假设区间做敏感性并写明假设，不假设一个点位；行业利润率的默认值是这个模型的输入，不是对公司的预测。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. If the bond yield or beta cannot be retrieved, the model runs as a labelled sensitivity band rather than a guessed level; the sector margin defaults are inputs to this model, not forecasts of the company.',
    },
  },
  {
    key: 'chinaSectorOverview',
    name: 'china-sector-overview',
    label: { zh: 'A 股行业全景', en: 'A-Share Sector Landscape' },
    description: {
      zh: '画一张 A 股行业地图：市场规模与集中度、政策与监管框架、竞争格局与按板块的关键 KPI（批价、装机量、NIM 一类），再落到主题与估值对照。',
      en: 'Maps an A-share industry: market size and concentration, the policy and regulatory frame, competitive structure with sector-specific KPIs (批价, 装机量, NIM and the like), then themes and valuation context.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'macro', 'competition', 'business-analysis'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。行业口径的统计取不到就写成缺口，不折算成记忆里的数；多空一览与"重点标的、目标价、评级"一节属于推演练习，本插件没有券商接口，不据它下单，也不会替你执行任何一笔。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. Industry statistics that do not come back stay a named gap rather than a remembered figure; the long / short list and the 重点标的、目标价、评级 section are exercises, and this plugin — with no broker interface — places no order on them.',
    },
  },
  {
    key: 'chinaCatalystCalendar',
    name: 'china-catalyst-calendar',
    label: { zh: 'A 股催化剂日历', en: 'A-Share Catalyst Calendar' },
    description: {
      zh: '把 A 股的披露与事件按时间排成注意力日历：财报与业绩预告、股东大会、解禁与分红回购、政策与行业会议，并标出压在同一个事件链上的公司。',
      en: 'Lays A-share disclosures and events out as an attention calendar: earnings and 业绩预告, shareholder meetings, lockup expiries, dividends and buybacks, policy and industry events, flagging names hanging on the same event chain.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'monitoring', 'macro', 'earnings'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。与美股口径的「催化剂地图」同族，但换成 A 股披露节奏；日期没取回来就标成未确认，不编日历，也不预测价格走向。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. The same family as the US-market Catalyst Map, retuned to A-share disclosure rhythm; a date that did not come back is marked unconfirmed rather than invented, and the calendar forecasts no price direction.',
    },
  },
  {
    key: 'chinaBreakTrace',
    name: 'china-break-trace',
    label: { zh: 'A 股财务核查', en: 'A-Share Forensic Review' },
    description: {
      zh: '对 A 股财报做取证式核查：科目勾稽、利润与现金流的背离、应收与存货异常、营运资本口径，再读审计意见类型、交易所问询与处罚公告里的信号。',
      en: 'Works through A-share statements forensically: line-item tie-outs, the gap between earnings and cash flow, receivable and inventory anomalies, working-capital behaviour, then what auditor opinions, exchange inquiries and penalties signal.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'risk', 'financial-health', 'verification'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。它列的是"该去查什么"，不是指控，也不构成买卖建议；与「风险与催化剂监控」部分重叠，这颗按报表科目与监管文书走。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. It lists what to investigate, not an accusation, and is not investment advice; it overlaps the risk-and-catalyst module but works from statement lines and regulatory documents.',
    },
  },
  {
    key: 'chinaVarianceCommentary',
    name: 'china-variance-commentary',
    label: { zh: 'A 股业绩差异表述', en: 'A-Share Variance Commentary' },
    description: {
      zh: '把差异写成读得懂的中文：超预期 / 低于预期怎么分类、驱动因素归因到哪一层、口径与单位一致性怎么交代，以及"这个变化意味着什么"的句子级写法。',
      en: 'Turns variances into readable Chinese commentary: how to classify beat / miss / in-line, where to attribute the driver, how to keep 口径 and units consistent, and how to say what the change actually means.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'earnings', 'verification'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。宿主取不到一致预期时，差异就写在去年同期、先前口径与披露区间上，并说明那是哪种基线，不冒充市场共识。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. Without a retrievable consensus, variances are stated against prior-year, your own earlier figures and the disclosed range — labelled as which baseline, never dressed up as market consensus.',
    },
  },
  {
    key: 'chinaInitiatingCoverage',
    name: 'china-initiating-coverage',
    label: { zh: 'A 股首次覆盖', en: 'A-Share Initiation Report' },
    description: {
      zh: '按券商研究所体例搭一份 A 股首次覆盖：公司与行业分析、三表建模、估值与倍数区间、图表清单与报告骨架，一路写到评级与目标价那一节。',
      en: 'Assembles an initiation report in Chinese sell-side form: company and industry analysis, three-statement modelling, valuation and multiple ranges, the exhibit list and the report skeleton, through to the rating and target-price section.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'valuation', 'business-analysis', 'filings'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。五档评级与目标价是把材料写成一个结论的推演练习，本插件没有券商接口，不据它下单，也不会替你执行任何一笔；报告写在最终答复里、不产出文件，页数只是体量参考。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. The five-tier rating and target price are a conclusion exercise: this plugin has no broker interface and places no order on them. The report is written into the final reply rather than a file, and the page counts are only a sense of scale.',
    },
  },
  {
    key: 'chinaMorningNote',
    name: 'china-morning-note',
    label: { zh: 'A 股晨会纪要', en: 'A-Share Morning Note' },
    description: {
      zh: '按国内卖方晨会节奏（开盘前 7:00–8:30）写一份当日策略：隔夜与外盘变化、盘前情绪、当日解禁与披露事件、盯盘要点，收到 2–4 条当日想法。',
      en: 'Writes the pre-open desk note on Chinese sell-side timing (07:00–08:30): overnight and external markets, pre-market sentiment, today’s unlock and disclosure events, what to watch intraday, distilled into 2–4 ideas for the session.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'monitoring', 'portfolio'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。晨会里的方向（Long / Short / Watch）、止损位与仓位写法都是推演练习：本插件没有券商接口，不据它下单，也不替你动仓。行情、公告与事件一律走宿主取数通道，没回来的字段写成缺口。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. The Long / Short / Watch calls, stop levels and sizing language in the note are a rehearsal exercise: this plugin holds no broker interface, places no order on them and moves no position for you. Quotes, filings and events come through the host retrieval channel, and anything that does not come back is written up as a gap.',
    },
  },
  {
    key: 'chinaThesisTracker',
    name: 'china-thesis-tracker',
    label: { zh: 'A 股持仓论点跟踪', en: 'A-Share Thesis Tracker' },
    description: {
      zh: '为持仓与自选逐只维护投资逻辑：记下论点前提、跟踪关键数据点与催化剂、按新披露更新有效性，并给出维持 / 加仓 / 减仓 / 离场的判断与目标价、止损位。',
      en: 'Keeps a live thesis per holding and watchlist name: states the premises, tracks the key data points and catalysts, updates validity as new filings land, and argues maintain / add / reduce / exit with a target price and a stop.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'monitoring', 'portfolio'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。加仓 / 减仓 / 离场与目标价、止损位属于推演练习：本插件没有券商接口，不据它执行任何一笔，也不掌握你的实际持仓与成本——那些得由你给，缺了就只复查逻辑不动作。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. The add / reduce / exit calls with target price and stop are a rehearsal exercise: this plugin holds no broker interface, executes nothing on them and does not know your actual holdings or cost basis — provide them, and with them missing it reviews the logic without recommending action.',
    },
  },
  {
    key: 'chinaIdeaGeneration',
    name: 'china-idea-generation',
    label: { zh: 'A 股选股与机会生成', en: 'A-Share Idea Screening' },
    description: {
      zh: '按量化筛选、主题线索与形态识别三条线系统性地找 A 股标的：多空两侧各出清单，逐条写催化剂、为什么现在、信念档与验证下一步。',
      en: 'Surfaces A-share names along three rails — quantitative screens, thematic leads and pattern recognition — producing long and short lists with, per name, the catalyst, why now, a conviction tier and the next check.',
    },
    owner: 'jwangkun',
    repository: 'claude-for-financial-services-cn',
    status: 'watchlist',
    lastCommit: '2026-09-14',
    reviewBy: '2026-11-08',
    tags: ['a-share', 'technicals', 'portfolio'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-09-14，启用前请自行复核来源。清单里的 Long / Short 方向、信念档与仓位建议属于推演练习，不是订单：本插件没有券商接口，也不据它们替你下任何一笔；筛选条件要的数字取不到就点名缺口，不用记忆里的数补齐。',
      en: 'Cold-start experiment; upstream last moved on 2026-09-14, so review the sources before use. The Long / Short directions, conviction tiers and sizing suggestions on the list are a rehearsal exercise, not orders: this plugin holds no broker interface and places nothing for you on them. Numbers a screen needs but retrieval cannot get are named as gaps rather than filled from memory.',
    },
  },
  {
    key: 'companyValuation',
    name: 'company-valuation',
    label: { zh: '企业估值与股权价值桥', en: 'Company Valuation' },
    description: {
      zh: '三条路估企业价值与股权价值：先剥离一次性项目做 DCF，再用同业倍数与先例交易交叉验证，最后把企业价值换成股权价值——有息负债、少数股东权益、参股公司、养老金缺口逐笔列出。',
      en: 'Triangulates enterprise and equity value: a DCF on normalized earnings, cross-checked against peer multiples and precedent deal multiples, then an explicit enterprise-to-equity bridge that itemizes debt-like charges, minority interests, associates and any pension deficit.',
    },
    owner: 'GAJETOso',
    repository: 'financeskills',
    status: 'watchlist',
    lastCommit: '2026-10-01',
    reviewBy: '2026-11-15',
    tags: ['valuation', 'cash-flow', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-10-01，启用前请自行复核来源。这颗按 IFRS 与美股估值惯例写：先例交易倍数、控制权溢价 20–35% 与 EV/EBITDA 那套倍数在 A 股披露里常常拿不到同口径数据，取不到就点名缺口，不用记忆里的数补齐。它给出的估值区间与"哪几条假设真正决定答案"属于方法推演，不是订单——本插件没有券商接口，也不据它下单。',
      en: 'Cold-start experiment; upstream last moved on 2026-10-01, so review the sources before use. The method is written to IFRS and US valuation practice: precedent-transaction multiples, the 20–35% control premium and the EV/EBITDA comp set often have no same-basis counterpart in A-share disclosure — name the gap instead of filling it from memory. The concluded range and the "assumptions that actually move the answer" are a rehearsal exercise, not orders: this plugin holds no broker interface and places nothing for you.',
    },
  },
  {
    key: 'waccComputation',
    name: 'wacc-computation',
    label: { zh: 'WACC 与资本成本估算', en: 'WACC Computation' },
    description: {
      zh: '把折现率拆开估：CAPM 各输入（无风险利率、β、股权风险溢价、规模与国家风险溢价）、可比 β 的去杠杆与再杠杆、按市值加权的税后债务成本，最后交出一张 β × 风险溢价的敏感性区间。',
      en: 'Builds the discount rate piece by piece — CAPM inputs (risk-free rate, beta, equity risk premium, size and country premia), unlevering and relevering peer betas on the target\u0027s capital structure, market-value weights on the after-tax cost of debt — and ends on a beta-by-premium sensitivity range.',
    },
    owner: 'GAJETOso',
    repository: 'financeskills',
    status: 'watchlist',
    lastCommit: '2026-10-01',
    reviewBy: '2026-11-15',
    tags: ['valuation', 'risk', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-10-01，启用前请自行复核来源。正文的数字基准是美国的：无风险利率取 10 年期美债、风险溢价用美股 ERP、税率按美国边际税率。用于 A 股要换成中国 10 年期国债、境内 ERP 与 15% / 25% 那一档实际税率，这些替换值本插件没有现成来源时一律留空点名，不凭记忆填。算出的 WACC 是推演输入，不是对任何标的的判断。',
      en: 'Cold-start experiment; upstream last moved on 2026-10-01, so review the sources before use. Its numeric anchors are American: a 10-year Treasury as the risk-free rate, US equity risk premium, a US marginal tax rate. Applying it to A-shares means a China 10-year government bond yield, a local ERP and the 15% / 25% statutory rate actually paid — where this plugin has no source for the replacement value, leave it blank and say so rather than quoting memory. The computed WACC is an input to a rehearsal, not a verdict on anything.',
    },
  },
  {
    key: 'threeStatementModeling',
    name: 'three-statement-modeling',
    label: { zh: '三表勾稽建模与诊断', en: 'Three-Statement Modeling' },
    description: {
      zh: '按固定顺序搭一张联动的三表模型：驱动因子集中一处、收入构建利润表、固定资产与营运资本与债务三张附表推动资产负债表、现金流量表完全由前两表的差额倒推，每一期都摆一行"不平就点名"的平衡检查。',
      en: 'Assembles a linked three-statement model in a fixed order — one place for drivers, an income statement built from revenue, PP&E / working-capital / debt schedules driving the balance sheet, a cash flow statement derived entirely from the deltas — with a balance check on every period that names the ones that do not tie.',
    },
    owner: 'GAJETOso',
    repository: 'financeskills',
    status: 'watchlist',
    lastCommit: '2026-10-01',
    reviewBy: '2026-11-15',
    tags: ['financial-health', 'cash-flow', 'business-analysis'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-10-01，启用前请自行复核来源。科目表按 IFRS / US GAAP 列示，A 股报表另有一批需要自己映射的行次（其他应收、合同资产与合同负债、少数股东权益等）——这颗只讲勾稽形状，不替你判断哪一笔该归哪一科目。它建的是模型骨架，产出的预测数字属于推演；需要的历史报表或附注明细取不到就点名缺口。',
      en: 'Cold-start experiment; upstream last moved on 2026-10-01, so review the sources before use. Its chart of accounts is IFRS / US GAAP, so A-share statements need their own mapping for lines such as other receivables, contract assets and liabilities, and minority interests — this skill teaches the linkage, not where a given item belongs. What it produces is a model skeleton whose projected numbers are a rehearsal; historical statements or note detail it cannot retrieve are named as gaps.',
    },
  },
  {
    key: 'creditAnalysis',
    name: 'credit-analysis',
    label: { zh: '偿债能力与债务容量分析', en: 'Credit Analysis' },
    description: {
      zh: '回答一件事：这家公司能不能穿过周期把钱还上。杠杆、利息覆盖、DSCR、自由现金流对债务、流动性五组算式各算正常口径与压力口径，再看担保折价、清收顺序、契约余量与"谁替它兜底"。',
      en: 'Answers one question: can this borrower service and repay through the cycle. Five ratio families — leverage, interest coverage, DSCR, free cash flow to debt, liquidity — each on a normalized and a stressed basis, then collateral haircuts, recovery ranking, covenant headroom and who actually stands behind it.',
    },
    owner: 'GAJETOso',
    repository: 'financeskills',
    status: 'watchlist',
    lastCommit: '2026-10-01',
    reviewBy: '2026-11-15',
    tags: ['risk', 'financial-health', 'us-stock'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-10-01，启用前请自行复核来源。正文的"舒适阈值"（杠杆 3.0x、DSCR 1.2x 一类）是国际公司贷款的惯例值，不是任何市场的监管线；境内公司债、可转债与银行授信的契约条款和定义各不相同，要按募集说明书与年报原文核对。它写出的 approve / decline / 结构建议属信用侧的方法推演，既不是授信意见也不是订单——本插件不代你下单。',
      en: 'Cold-start experiment; upstream last moved on 2026-10-01, so review the sources before use. Its comfort thresholds (3.0x leverage, 1.2x DSCR and the rest) are international corporate-lending conventions, not any market\u0027s regulatory line; domestic bond, convertible and bank-facility covenants differ in both level and definition, so check them against the offering circular and the annual report as filed. The approve / decline / restructure it writes is a credit-side rehearsal, neither a credit opinion nor an order — this plugin places nothing for you.',
    },
  },
  {
    key: 'eclComputation',
    name: 'ecl-computation',
    label: { zh: '预期信用损失与三阶段减值', en: 'Expected Credit Loss' },
    description: {
      zh: '按 IFRS 9 的三阶段思路把减值拆开：阶段划分与迁徙判断、PD / LGD / EAD 三参数、应收账龄的准备矩阵简化法、宏观情景加权与覆盖率，再问一句"下行情景概率提高 10% 会怎样"。',
      en: 'Takes the IFRS 9 impairment logic apart: stage assignment and migration, the PD / LGD / EAD parameters, the simplified provision matrix over aging buckets, macro scenario weighting and coverage ratios, then one more question — what changes if the downside scenario gains ten points of probability.',
    },
    owner: 'GAJETOso',
    repository: 'financeskills',
    status: 'watchlist',
    lastCommit: '2026-10-01',
    reviewBy: '2026-11-15',
    tags: ['risk', 'financial-health', 'filings'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-10-01，启用前请自行复核来源。中国《企业会计准则第 22 号》已与 IFRS 9 的三阶段框架对齐，但披露粒度不同：上市公司年报给出阶段余额与减值准备，不给出 PD / LGD 参数。所以这颗更适合用来判断别人披露的减值合不合理，而不是自己算出一个准备数；需要而取不到的明细一律点名缺口，不用合计倒推。',
      en: 'Cold-start experiment; upstream last moved on 2026-10-01, so review the sources before use. China\u0027s Accounting Standard for Business Enterprises No. 22 already follows the IFRS 9 three-stage framework, but disclosure granularity differs: listed issuers give stage balances and impairment charges, not PD / LGD parameters. Use this skill to judge whether a disclosed provision is defensible rather than to compute your own; detail that retrieval cannot get is named as a gap, never back-derived from a total.',
    },
  },
  {
    key: 'insuranceReserving',
    name: 'insurance-reserving',
    label: { zh: '保险准备金与综合成本率', en: 'Insurance Reserving' },
    description: {
      zh: '一条准备金链条走到底：赔款发展三角、年龄到年龄因子、链式法与 Bornhuetter-Ferguson、IBNR，再落到综合成本率——把"未决赔款估得准不准"和"这单承保业务到底赚不赚钱"分成两件事。',
      en: 'Runs the reserve chain end to end: loss development triangles, age-to-age factors, chain ladder and Bornhuetter-Ferguson, IBNR, then the combined ratio — keeping "are unpaid claims estimated well" and "does this book actually earn" as two separate questions.',
    },
    owner: 'GAJETOso',
    repository: 'financeskills',
    status: 'watchlist',
    lastCommit: '2026-10-01',
    reviewBy: '2026-11-15',
    tags: ['risk', 'financial-health'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-10-01，启用前请自行复核来源。精算假设、折现与负债计量按 IFRS 17 与一般精算惯例写，境内上市险企的法定准备金、折现率参考曲线与保户储金口径另有规定。发展三角要按险种和年度拆开的赔款明细，这类粒度在公开披露里常常取不到——点名缺口，不要拿合计数摊。',
      en: 'Cold-start experiment; upstream last moved on 2026-10-01, so review the sources before use. Its actuarial assumptions, discounting and measurement follow IFRS 17 and general actuarial practice; statutory reserves, the reference yield curve and policyholder-deposit treatment for listed Chinese insurers follow separate rules. A development triangle needs claims detail split by line and accident year — granularity public disclosure often does not give, so name the gap instead of spreading a total across it.',
    },
  },
  {
    key: 'bankingCompliance',
    name: 'banking-compliance',
    label: { zh: '银行资本与流动性指标', en: 'Bank Capital Ratios' },
    description: {
      zh: '银行股最硬的几张表：CET1 / Tier 1 / 总资本充足率、风险加权资产及其权重结构、杠杆率与 LCR / NSFR，加一套"违约打进来后资本够不够"的压力形状。',
      en: 'The hardest numbers on a bank name: CET1 / Tier 1 / total capital adequacy, risk-weighted assets and their weight structure, the leverage ratio, LCR and NSFR, plus a pass that asks whether capital still holds once defaults arrive.',
    },
    owner: 'GAJETOso',
    repository: 'financeskills',
    status: 'watchlist',
    lastCommit: '2026-10-01',
    reviewBy: '2026-11-15',
    tags: ['risk', 'financial-health', 'macro'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-10-01，启用前请自行复核来源。阈值按巴塞尔原值写（4.5% / 6% / 8%）：中国大陆适用《商业银行资本管理办法》，核心一级最低 5% 之上还有储备资本与系统重要性附加，资本定义与风险权重也另有表——这颗的比率形状可以用，数字只能当境外参照，不能当境内合规判断。风险权重明细与 LCR 分项在 A 股年报里的披露粒度不一，取不到就点名缺口。',
      en: 'Cold-start experiment; upstream last moved on 2026-10-01, so review the sources before use. Its thresholds are Basel originals (4.5% / 6% / 8%): mainland China applies the Capital Rules for Commercial Banks, where the 5% minimum CET1 sits on top of a conservation buffer and system-importance add-ons, and capital definitions and risk-weight tables differ again. Use the ratio shapes, treat the numbers as an overseas reference, and never as a domestic compliance judgement; risk-weight and LCR detail varies by filing, so missing lines are named as gaps.',
    },
  },
  {
    key: 'forensicAccounting',
    name: 'forensic-accounting',
    label: { zh: '账务异常与数字分布排查', en: 'Forensic Ledger Screening' },
    description: {
      zh: '拿账和数字做取证式排查：首位数字的 Benford 分布检验、整数与重复金额、资金循环路径、供应商与关联方重合，并把结论写成一条经得起复核与质询的证据链。',
      en: 'Screens a ledger forensically: Benford first-digit tests, round-number and repeated-amount patterns, round-trip flows, vendor and related-party overlaps — written up as an evidence chain that can survive review and cross-examination.',
    },
    owner: 'GAJETOso',
    repository: 'financeskills',
    status: 'watchlist',
    lastCommit: '2026-10-01',
    reviewBy: '2026-11-15',
    tags: ['verification', 'risk', 'financial-health'],
    riskNote: {
      zh: '冷启动实验；上游最近一次提交是 2026-10-01，启用前请自行复核来源。除首位数字检验可以只对公开报表做以外，这颗的主要路径（银行流水、员工与供应商信息比对、企业内部系统）需要使用者自己提供账务明细：本插件不连企业内部系统，也没有那些数据源。它给出的"疑似"清单是排查线索，不是舞弊认定，也不构成审计或法律意见；样本量不足时首位数字检验本身不成立，正文的门槛要照做。',
      en: 'Cold-start experiment; upstream last moved on 2026-10-01, so review the sources before use. Only the first-digit test can run on published statements; the rest of this skill\u0027s paths — bank statements, employee-versus-vendor matching, internal ERP systems — require the user to supply the accounting detail, since this plugin connects to no corporate system and holds no such source. What it returns is a list of leads, not a fraud finding, and neither an audit nor a legal opinion; a Benford test on too small a sample is void, and the sample thresholds in the text stand.',
    },
  },
  // 第八颗（Howard-Jerry/quant-agent-skills）：上游三颗正文都是自述的**编排器**、且指挥公开版
  // 根本不附带的私有数据层（实测三颗 SKILL.md 点名的本地路径一个都不在仓里），一颗都不进可选清单；
  // 逐条判据与 132 处闸门命中的分布见该快照 UPSTREAM.md。这里开放的是本仓自持的一颗入口，
  // 它只挂载上游那两份零执行面、零私有引用的跨市场选线口径（逐字复制，非改写）。
  {
    key: 'crossMarketListingChoice',
    name: 'cross-market-listing-choice',
    label: { zh: '跨市场选线（A/H · ADR/HK）', en: 'Cross-Market Listing Choice' },
    description: {
      zh: '同一家公司在多个市场各有上市线时，选一条来持有、加仓或观察：A/H 溢价与币种股息税、流动性与通道、ADR 换算比例与披露文件路径。公司层面只研究一次——A 与 H 是同一家公司的两条线，变的只有价差、税、币种和你能不能买到。',
      en: 'Picks which listing of a single issuer to hold, add, or watch: A/H premium and currency/dividend withholding, liquidity and channel access, ADR conversion ratios and filing paths. The company is researched once — A and H are two lines of the same business, so what changes is spread, tax, currency and whether you can reach it.',
    },
    owner: 'Howard-Jerry',
    repository: 'quant-agent-skills',
    status: 'watchlist',
    lastCommit: '2026-08-05',
    reviewBy: '2026-11-15',
    tags: ['a-share', 'us-stock', 'portfolio', 'risk'],
    riskNote: {
      zh: '冷启动实验：上游五次提交全落在 2026-08-05 同一天，之后无维护，作者声明正文来自其私有量化系统（数据层尚未开源）。这颗只做选线，不重做公司研究——公司本身的结论交给既有研究路径。本插件没有现成的 A/H 溢价或 ADR 平价条目：溢价必须由两条线同一 as-of 交易日的收盘价加上当日汇率现算，这三项任一项取不到就不给溢价数字，只报告缺哪一项；汇率条目按次消耗上游积分，凭据缺失、限流与后端错误一律不重试，也不许用记忆里的近似汇率补数。本插件不持有使用者的成交账本，持仓与成本价只能按你在对话里当场给出的信息回答，回答完就放下，不持久化。价差是当天的事实，"折价的那条线会涨回来"不是这颗的结论，历史价差区间只是参照、不是目标。本插件不提供交易执行界面，不构成投资建议，动哪条线与动多少由使用者自己决定并自己执行。',
      en: 'Cold-start experiment: all five upstream commits landed on 2026-08-05 with nothing since, and the author states the text comes from a private quant system whose data layer is not yet open. This skill only picks a listing — it never re-runs the company research, which stays with the existing paths. This plugin has no ready-made A/H premium or ADR parity entry: the premium must be computed from both lines\u0027 closes on the same as-of trading day plus that day\u0027s FX, and if any of the three is missing you report which one instead of publishing a premium. FX entries consume upstream quota; missing credentials, throttling and backend errors are never retried, and an approximate rate from memory is not a substitute. This plugin holds no user trade ledger — position and cost basis can only be answered from what the user states in the conversation, and nothing is persisted. A spread is a same-day fact; "the cheaper line will converge" is not a conclusion of this skill, and a historical range is a reference, not a target. No trading interface is provided and nothing here is investment advice: which line to take, and how much, stays with the user.',
    },
  },
])

// ── 能力标签注册表：索引与筛选的唯一来源 ─────────────────────────────────────────
//
// 一条精选 skill 的 tags 同时决定两件事：① 设置卡片左侧筛选条怎么分类它；② 它进哪几颗
// **任务型内置 skill** 的索引。所以标签不是"展示分类"，而是"路由声明"——登记一次，两处生效。
//
// 新增一个标签 = 在 SELECTED_SKILL_TAGS 里加一行（zh / en 本来就必须填，`capital-config.test.mjs`
// 钉着），`serves` 或 `fallback` 顺带填掉。没有第二处要改，也没有任何东西会因为"忘了挂"而静默变成孤儿：
// 下面四条闸门（`test/selected-skill-tags.test.mjs`）会把漏挂、拼错、孤儿和上限都打红。

/**
 * 任务型内置 skill：正文会被补上"外部精选 skill 索引"的那几颗（住 `preset/capital-generation/skills/`）。
 * 其余五颗内置 skill 是协议 / 流程类（data / web / chart / visualization / orchestration），读者是
 * 特定角色或特定工具调用，不是"用户提了一个研究任务"的入口，因此不接索引。
 */
export const SELECTED_SKILL_TASK_IDS = Object.freeze([
  'capital-equity-research',
  'capital-event-impact',
  'capital-portfolio-review',
])

/** 没有任何归属的标签，其条目兜底进这一颗（2026-10-13 决策：一切兜底都往 equity 里装）。 */
export const SELECTED_SKILL_FALLBACK_TASK = 'capital-equity-research'

/**
 * 标签轴。`routes: false` 的轴只做**标注**，不决定条目进哪颗任务型 skill；`routes: true` 的轴参与路由。
 *
 * 市场口径轴是**不路由**的，这一点被实测纠过一次：最初把它写成"对所有任务型 skill 生效"，结果
 * 你这 10 个启用项（9 颗带 `a-share`）在三颗任务型 skill 里得到**完全相同**的清单，索引等于失效；
 * 修成不路由之后，`10k-digest`（美股 10-K 深读）只进 equity / event-impact，`tax-lens` 只进
 * portfolio。判据因此是："是 A 股"不蕴含"服务单股研究 / 事件影响 / 组合复盘"。
 *
 * 好处顺带落在自动化上：**新增一个市场口径标签零决策**——不写 serves、不重跑任何分配，
 * 只登记一行（zh/en/axis）即可。新增一个 routing 轴 = 这里加一行，该轴的标签各自带 `axis`。
 */
export const SELECTED_SKILL_TAG_AXES = Object.freeze({
  market: Object.freeze({ routes: false }),
  capability: Object.freeze({ routes: true }),
  topic: Object.freeze({ routes: true }),
})

/**
 * 能力标签注册表。键集 ≡ 标签词表（`SELECTED_SKILL_TAG_LABELS` 由它派生）。三轴判据：
 *   market     —— 什么市场口径（A 股 / 美股 / 将来的港股…），**不路由**，只做标注；
 *   capability —— 调用什么分析方法（估值 / 财务健康 / 证据核验…）；
 *   topic      —— 落在什么场景或对象上（组合、监控、税务…）。
 * routing 轴（capability / topic）的 `serves` 与 `fallback` 二选一：前者点名接收它的任务型 skill
 * （允许重叠），后者是"还没想好挂哪颗"的显式承认。两者都不给 = 孤儿，闸门会红——不写成"静默不出现"，
 * 因为静默正是这套东西最容易坏的地方。
 */
export const SELECTED_SKILL_TAGS = Object.freeze({
  'a-share': { zh: 'A 股', en: 'A-share', axis: 'market', serves: [] },
  'business-analysis': { zh: '业务分析', en: 'Business analysis', axis: 'capability', serves: ['capital-equity-research'] },
  'capital-allocation': { zh: '资本配置', en: 'Capital allocation', axis: 'capability', serves: ['capital-equity-research'] },
  'cash-flow': { zh: '现金流', en: 'Cash flow', axis: 'capability', serves: ['capital-equity-research', 'capital-event-impact'] },
  competition: { zh: '竞争格局', en: 'Competition', axis: 'topic', serves: ['capital-equity-research'] },
  earnings: { zh: '业绩与电话会', en: 'Earnings', axis: 'capability', serves: ['capital-equity-research', 'capital-event-impact'] },
  // `education` 是这张表里最勉强的一条：post-trade-review / journal-pattern-analyzer 确实服务组合复盘，
  // learning-coach 则哪边都不像。归到 portfolio 是先给一个明确归属，而不是让它掉进兜底。
  education: { zh: '教学', en: 'Education', axis: 'topic', serves: ['capital-portfolio-review'] },
  filings: { zh: '披露文件', en: 'Filings', axis: 'capability', serves: ['capital-equity-research', 'capital-event-impact'] },
  'financial-health': { zh: '财务健康', en: 'Financial health', axis: 'capability', serves: ['capital-equity-research', 'capital-event-impact'] },
  instruments: { zh: '期权与基金', en: 'Options & funds', axis: 'topic', serves: ['capital-portfolio-review'] },
  macro: { zh: '宏观与行业', en: 'Macro & industry', axis: 'topic', serves: ['capital-equity-research', 'capital-event-impact'] },
  monitoring: { zh: '监控', en: 'Monitoring', axis: 'topic', serves: ['capital-event-impact', 'capital-portfolio-review'] },
  orders: { zh: '订单', en: 'Orders', axis: 'topic', serves: ['capital-equity-research'] },
  perspective: { zh: '分析视角', en: 'Perspective', axis: 'topic', serves: ['capital-equity-research', 'capital-event-impact'] },
  'peter-lynch': { zh: '彼得·林奇', en: 'Peter Lynch', axis: 'topic', serves: ['capital-equity-research'] },
  portfolio: { zh: '组合与仓位', en: 'Portfolio', axis: 'topic', serves: ['capital-portfolio-review'] },
  risk: { zh: '风险', en: 'Risk', axis: 'topic', serves: ['capital-equity-research', 'capital-event-impact', 'capital-portfolio-review'] },
  strategy: { zh: '战略', en: 'Strategy', axis: 'topic', serves: ['capital-equity-research'] },
  tax: { zh: '税务', en: 'Tax', axis: 'topic', serves: ['capital-portfolio-review'] },
  technicals: { zh: '技术面', en: 'Technicals', axis: 'topic', serves: ['capital-event-impact', 'capital-portfolio-review'] },
  'trade-discipline': { zh: '交易纪律', en: 'Trade discipline', axis: 'topic', serves: ['capital-portfolio-review'] },
  'us-stock': { zh: '美股', en: 'US equity', axis: 'market', serves: [] },
  valuation: { zh: '估值', en: 'Valuation', axis: 'capability', serves: ['capital-equity-research', 'capital-event-impact'] },
  verification: { zh: '证据核验', en: 'Verification', axis: 'capability', serves: ['capital-equity-research', 'capital-event-impact', 'capital-portfolio-review'] },
})

/**
 * 设置卡片最多能同时勾选的精选 skill 数。**只约束"能勾几个"，不约束"已勾的生效"**：
 * 运行期 provider 不按这个数截断——老配置多于 6 个时照常全部生效并提示收敛，否则就是
 * "卡片上开着 10 个、会话里只有 6 个"那种静默砍功能（AGENTS.md §9.7）。
 */
export const SELECTED_SKILLS_MAX_ENABLED = 6

/** 标签的显示名（含恒在第一格的「全部」）。键集恒等于注册表，所以新标签只登记一次。 */
export const SELECTED_SKILL_TAG_LABELS = Object.freeze({
  zh: Object.freeze({
    all: '全部',
    ...Object.fromEntries(Object.entries(SELECTED_SKILL_TAGS).map(([tag, meta]) => [tag, meta.zh])),
  }),
  en: Object.freeze({
    all: 'All',
    ...Object.fromEntries(Object.entries(SELECTED_SKILL_TAGS).map(([tag, meta]) => [tag, meta.en])),
  }),
})

/** 该标签服务的任务型 skill（不路由的轴 → 空；未登记的标签 → 空）。 */
export function taggedTaskSkills(tag) {
  const meta = SELECTED_SKILL_TAGS[tag]
  if (meta === undefined) return []
  const axis = SELECTED_SKILL_TAG_AXES[meta.axis]
  if (axis === undefined || !axis.routes) return []
  return [...meta.serves]
}

/** 该任务型 skill 收到的全部标签。派生自注册表：反向可达闸门与文档读它，不手写清单。 */
export function taskSkillTags(taskId) {
  return Object.keys(SELECTED_SKILL_TAGS).filter((tag) => taggedTaskSkills(tag).includes(taskId))
}

/** 该条目是否挂上了至少一颗任务型 skill——没挂上的按兜底规则进 `SELECTED_SKILL_FALLBACK_TASK`。 */
function entryRoutesAnywhere(entry) {
  return entry.tags.some((tag) => taggedTaskSkills(tag).length > 0)
}

/**
 * **唯一实现**：已启用（按运行时 skill name）的精选条目里，某颗任务型 skill 应当索引到哪几条。
 * 目录（provider 的 `list()`）、任务型 skill 的索引块、测试三处都调这一个函数，不许各自重算
 * （AGENTS.md §9.7：两份实现必然漂移，而漂移的表现是"某一处少了/多了一条"，零报错）。
 * `enabledNames` 由调用方在**调用期**现读开关得到——开关是 settings 偏好，不许在装配期定格。
 */
export function selectedSkillsForTask(taskId, enabledNames) {
  const enabled = new Set(enabledNames)
  return SELECTED_SKILL_CATALOG.filter((entry) => {
    if (!enabled.has(entry.name)) return false
    if (entry.tags.some((tag) => taggedTaskSkills(tag).includes(taskId))) return true
    // 兜底只在 equity 生效（2026-10-13 决策）：一条都挂不上的条目，宁可多给它看一条，
    // 也不要静默不出现。`fallback: true` 的标签走的就是这条路。
    return taskId === SELECTED_SKILL_FALLBACK_TASK && !entryRoutesAnywhere(entry)
  })
}

/** 只靠兜底才看得见的条目（当前应为空）。闸门钉住它：新增孤儿会当场点名，而不是静默消失。 */
export function fallbackOnlySkillNames() {
  return SELECTED_SKILL_CATALOG.filter((entry) => !entryRoutesAnywhere(entry)).map((entry) => entry.name)
}
