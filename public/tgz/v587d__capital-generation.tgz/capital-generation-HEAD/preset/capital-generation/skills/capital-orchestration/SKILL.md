---
name: capital-orchestration
description: Use when delegating in Capital mode — running the per-round list_agents preflight, matching or reusing a data_collector / data_junior / web_retriever child by role label, deciding which role owns a request, recording a delegation checklist, or handling a preflight anomaly. Also indexes the exact data payloads in capital-data-protocol.
---

# Capital 委派编排（完整版）

主 persona 只保留每轮都要生效的硬规则；本文件是同一套编排的完整细则、异常分支与清单格式。
规则冲突时以主 persona 为准。

## 1. 每轮预检（不可跳过）

- 触发点：**每次新的用户请求或新一轮任务**。在"本轮第一次调用任何创建工具"之前完成。
- 创建工具指：`subagent_data_collector`、`subagent_data_junior`、`subagent_web_retriever`，以及今后新增的任何**专用**委派工具。
- 查询方式：`list_agents(scope="children")`，一次即可。
- 不要把它当成"仅在会话恢复时才做的回忆步骤"：上一轮查到的空列表不能代替本轮查询。
- 一次查询结果覆盖本轮所有角色，不要为每个角色重复查询；等待回传期间也不要轮询。

## 1.1 Canonical task_id（不可分叉）

主 Agent 在本轮第一次委派前先确定一个唯一的 `task_id`，并把它原样写入所有 `data_collector`、`data_junior` 和需要可视化的任务 prompt。子 Agent 不得自行生成替代 task_id；收到缺失或不同值时必须回告主 Agent，不要默默创建新任务。

委派清单的 `task_id` 是授权账本，不是描述性备注。`DatasetRef.task_id`、`profile_ref.task_id`、`chart_source_ref` 和 `chart_ref` 必须能沿同一个值对账。引用 chart receipt 前先核对它绑定的 task；若错误返回 `expected_task_id`，使用错误中给出的实际绑定值修正，不要猜测或反复试不同 id。


只处理 `kind=child`。按 `label` 匹配三个稳定角色标签：`data_collector`、
`data_junior`、`web_retriever`。

1. **标签非标准但已映射**：历史 child 的 label 仍是旧任务标题时，只要委派清单或工具回执
   已经把它映射到某个角色的 durable id，就必须沿用该 id，不得因为 label 非标准而新建。
2. **状态判定**：`list_agents` 只报两态——`running` 与 `inactive`，**两种都可直接投**：同角色
   只要出现在列表里，就用该 id 调 `send_message` 派发本次任务。`running` 在其最近的 step 边界
   接收消息；`inactive` 带着自己的上下文开一个新回合。
   不得因为"空闲""上一任务已完成""任务标题变了""想并行"而创建第二个同角色 Agent。
3. **诊断/暂时不可用**：已记录 id 但列表出现 diagnostic 或暂时不可用，先用该 id 尝试
   `send_message`，或重新 `list_agents` 核验；不得直接创建第二个同角色 Agent。
4. **确实不存在**：只有确认该 child 不存在且没有可用复用 id，才进入创建分支。

### 2.1 ID 纪律（防长上下文抄错 id）

child id 是随机 UUID、无语义可校验，长会话里凭记忆/从历史轮次复述 id 极易抄错，甚至把
A 角色的请求投给 B 角色。官方机制是 **`list_agents` 即权威 id 存储**——id 不需要被记住，
只需要在用之前查一次：

- `send_message` 的 `agent_id` 只从**最近一次 `list_agents` 的渲染输出**复制（每行就是
  `id [status] — label`）；不从早前轮次的上下文、委派清单或旧工具回执里复述 id。
- `list_agents` 与 `send_message` 之间不要插入其他工具调用；中间隔了长回传或多轮消息，
  就重新 `list_agents` 一次再发。
- 发送前三行核对：这一行 id 的 `label` 是不是目标角色、状态是否可投（`running` 与 `inactive`
  均可投）、本次任务是否确实属于该角色。
- **错投补救**：若消息发出后目标 child 的回应与角色不符（例如行情请求被 data_junior
  认领），用 `interrupt_agent` 停其当前轮（已结束则为 no-op），重新 `list_agents` 后向
  正确 id 重发。因此每条委派消息正文必须自带角色字样与任务标识，让错投可被及时发现。
- `send_message` 失败时报"不存在/无效 id"，同样回到 `list_agents` 拿新鲜 id 重发，
  禁止凭记忆换一个 id 再试。

## 3. 创建

- 只有本轮 `list_agents` 明确没有该角色标签时，才允许调用对应专用创建工具。
- `description` **必须原样使用角色标签**：`data_collector` / `data_junior` / `web_retriever`。
  任务标题、标的、参数只能写进 `prompt`。写进 description 会让下一轮无法可靠识别角色。
- `prompt` 只写本次委托上下文；**不需要复制任何模板**——身份、职责与工具边界由委派行配置注入。
- 创建返回 durable `subagentId` 后，立即把 id、角色标签、本次任务记入委派清单。
- 每会话只需一个 `data_collector`、一个 `data_junior`、一个 `web_retriever`，不要反复创建。

## 4. 委派清单（会话内维护）

回传可能交错到达，清单是逐一核对与后续复用的唯一依据：

| 角色 | durable id | task_id | 委派内容 | 状态 | 回传引用 |
|------|-----------|---------|----------|------|----------|
| data_collector | … | task_… | 贵州茅台近一年日线 | running | — |
| data_junior | … | task_… | 质检 ds_… | done | profile_ref |
| web_retriever | … | task_… | 交易所公告原文 | done | url + 正文要点 |

状态取值：`running` / `done` / `failed` / `waiting_data`（子 Agent 已发 `data_gap` 或
就绪登记、正等主 Agent 补数据）。collector 的 `dataset_ready` 是进度，不是 `done`；
收到 `data_collection_completed` 才可标记取数结束。回传引用只记 DatasetRef、profile_ref、URL 等标识，
**不记原始数据行**。

## 5. 路由表

| 诉求 | 归属 |
|------|------|
| 行情、财务、历史、交易日历等结构化数据 | `data_collector` |
| 数据集质量检查、缺失/重复/时间范围/基础统计 | `data_junior` |
| 网页材料、公告、新闻、传闻原文、公司背景、需要最新信息的事实 | `web_retriever` |
| 专业分析（Python、回测、统计检验） | 尚未启用——先由 `data_junior` 出基础 profile，并如实告知用户 |

- 拿不准归属就按四问过一遍，别凭"看起来像不像数据"：① 每行同构、可分页、同参数能复现出同形状吗？
  不能 → `web_retriever`；② 使用者要拿它做算术（聚合、排序、时序对比、进图）吗？要 → `data_collector`；
  ③ 文本是内容本身（正文、纪要、新闻）还是行上的一个标注字段（标题、简称）？前者 → `web_retriever`；
  ④ 需要对单位、缺失值含义、时间口径做承诺吗？要 → `data_collector`。
- 终判据是**错法**而不是形状：`data_collector` 出错给响亮错误码，`web_retriever` 抓到什么算什么、
  上游改版只会静默变样。**凡要写进用户结论的数字，一律委派 `data_collector`**；网页里的数字只能当线索
  或异常抽样，回传里标明"来源是某篇文章"而不是承诺口径。
- 多角色可并行委派，但每个角色都必须先按第 2 节复用或创建，各记清单，等结算通知齐了再综合
  （齐不齐按 §6.1 的对账表逐行判定，不靠"看起来都回了"）。
- 主 Agent 给 collector 的问题写清标的、时间范围、证据用途和所需新鲜度，由 collector 按目录选足能力，不预设“只取一个”或固定上限。
- 给 `web_retriever` 的事实核查委派**分级写需求**：核心事实（直接改变结论或风险判断的——审计意见、
  商誉、质押/担保/资金占用、现金流与利润背离、有息负债、再融资/重组等）≤10 条逐条核验、每条一行
  来源；外围事实（分红方案、互动平台问答、媒体花絮）一句话清单即可。不预设"每条 URL+日期+原文/
  转述双分类"的审计级格式；发现质押、商誉、现金流异常再对该项深挖（回传格式同口径，见
  `capital-web-evidence` §5）。
- 主 Agent 不自行调用任何网络检索/抓取/搜索类工具；外部检索入口只有 `web_retriever` 的回传。
- **没有通用委派出口**：直接子角色只有 `data_collector`、`data_junior`、`web_retriever` 三颗创建工具（专员归 junior）；不属于它们的活你自己做，或如实说明缺口。

## 6. 回合纪律与结算

- 子 Agent 完成会通过**结算通知**唤醒你；在它尚未结束前不要向用户断言其已完成。
- **中途消息是工单，不是完成**：collector 的 `dataset_ready` 每到一份就立即登记并转发
  给同一个 data_junior（先限定「只到 profile」；用户没提图也照转），按 task_id + dataset_id 去重；收到
  `data_collection_completed` 后才让 junior 综合既有 profile 并完成可视化 gate。
  子 Agent 也可能发来就绪登记或 `data_gap`（补数据）。就绪登记继续等；`data_gap` 按清单复用对应角色补齐，再用 `send_message` 把结果发回
  **同一个**子 Agent；这不算新任务，不必重跑预检，不要新建同角色 Agent。
  取数失败要回一条失败消息，不能让它一直等。
- **结算通知 ≠ 任务完成**：collector 未发 `data_collection_completed`，或者清单里标 `waiting_data` 的子 Agent 结束本轮是在等回信，
  不要向用户断言它已完成，也不要新建替代实例。
- 等待回传期间：不做任何外部检索/抓取、不反复 `list_agents`、不轮询等待。
- 回传到达后集中核对材料与结论，再决定继续委派或汇总输出。
- **收口顺序（硬）**：所有委派行结算 → 对账通过 → 有 `chart_refs` 先 `present_charts` 一次
  （全部 ref；记不清就传 `task_id`）→ 再写最终答复；登记必须早于最终答复。
- 已答复后被唤醒且无新信息：不输出可见正文，或重发自足总结（§6.1）；绝不写“已完成/见上”。
- 永远不要设置 `run_in_background: false`；所有委派必须是 continuable。

### 6.1 结算对账表（写结论前必交，硬）

**「收齐了吗」不靠印象回答，靠一张表。** 想写最终结论时，先在本步逐行列出本回合委派过的
每个子 Agent（含孙 Agent `visualization_specialist` 的父链即 data_junior），一行一个：

```text
结算对账｜task_id=...
- data_collector  <id 尾段>  最后交互：<turn N 的 send_message>  结算已收 ✓
- data_junior     <id 尾段>  最后交互：<turn N 的 send_message>  结算 ✗ 未收
- web_retriever   <id 尾段>  最后交互：<turn N 的 send_message>  结算已收 ✓
```

判据只有一条：**✗ 只能被结算通知翻正**。

- 子 Agent 的 `send_message` 回传正文**无论写得多像完成**（「7/7 profile 完成」「pending = 0」
  「本阶段全部完成」）都**不构成 ✓**——那是工单回执，不是生命周期事件。它下面紧跟的
  「本轮工作已全部完成并回传主 Agent」之类的收尾正文，同样不构成 ✓（那正是结算通知的正文，
  收到它才算 ✓）。
- 有任何一行是 ✗ → 本步**只写等待行**（欠谁、在等什么），结论留到 ✗ 全部翻正的那一步。
- 这张表写在 reasoning 里即可，不要作为正文发给用户（用户只看到结论）。

**为什么必须等：** 真机上结论生成 156 秒、汇总回执比结算通知早到 14 秒——先综合，结算通知必然落在
结论之后，框架会再开一个 step 投递，结论被切成两条消息。

**已经被追上（结论后才有结算）**：

- 无新信息/纠正 → **不要写一行确认**（它会成为折叠后唯一可见的最后一轮）：要么不输出可见正文，
  要么重发自足总结（结论/证据/来源、局限、观察/验证/防守）；**绝不写
  “分析已完成/结论见上/如上”**。
- 有新事实或推翻口径 → 重写一份完整结论，不要只补一段。
- 补齐后重新对账：这步之后又有人被唤醒，回到本节重来。

## 7. 异常分支

| 现象 | 处理 |
|------|------|
| `list_agents` 出现 diagnostic / 条目暂时不可用 | 先用已知 id 试 `send_message` 或重查一次；仍不可用才考虑创建，且必须先确认该角色确实不存在 |
| `send_message` 失败 | 重新 `list_agents` 确认 id 与状态，从新鲜输出复制 id 重发；禁止凭记忆换一个 id 再试；不要立刻新建同角色 Agent |
| 子 Agent 中途发来 `data_gap` 补数据请求 | 按清单复用对应角色取数，`send_message` 发回同一个子 Agent；取数失败也要回执，不能让它一直等 |
| 清单里有 `waiting_data` 的子 Agent 发来结算通知 | 那是它在等补数据，不是完成：不要向用户断言完成，也不要新建同角色实例 |
| 只有回传、没有结算通知，却"想写结论了" | 按 §6.1 先交对账表：✗ 未被结算翻正就本步只写等待行，结论留到收齐那一步 |
| 结论已输出后才被结算通知唤醒 | 无新增信息/纠正 → 不输出可见正文或重发自足总结，禁止一行“已完成/见上”；有新事实或推翻口径 → 重写完整结论（§6.1） |
| `send_message` 投错对象（目标 child 的回应与角色不符） | `interrupt_agent` 停当前轮（已结束为 no-op）→ 重新 `list_agents` → 向正确 id 重发；委派正文自带角色字样与任务标识，错投可被及时发现 |
| 子 Agent 回告「工具未挂载」 | 如实转述状态与检查建议，不要编造工具或数据；数据侧提示检查 `request_data`/`list_capabilities`，统计侧提示检查 `inspect_dataset`/`profile_dataset` |
| 子 Agent 回传 `failed` | 按 `error` 与 `code` 判断：参数问题修正后 `send_message` 重试；网络/服务类最多重试 1 次；同一请求累计最多重试 2 次仍失败就如实告知用户 |
| 子 Agent 回传 wind_docs 失败（AUTH/RATE_LIMIT/额度类） | Wind 能力暂不可用（Key 缺失/过期/额度不足）：如实告知用户；本轮材料由 anysearch 承担（公告线索 + 官方披露页 fetch），不要重试 Wind、不要索取或改配 Key |
| 出现「想直接读取 Dataset 内容」的冲动 | 改为委派 `data_junior`（`inspect_dataset` / `profile_dataset`）；主 Agent 直接调用 Dataset 系列工具会被工具层拒绝（`dataset_session_mismatch`），被拒后不要重试直读，改走委派 |
| 任务需要分钟级数据 | 检查 `tencent_kline`：支持 m1/m5/m15/m30/m60，仅支持最近 `count` 根（最多 320），无 `start/end` 历史区间；旧分钟历史不可编造，不满足就披露边界 |
| 需要周期刷新（如每日收盘快照） | 用 `send_message` 指示 `data_collector` 再次获取并回传；不存在订阅机制——新需求 = 新消息，回传即唤醒 |

载荷字段、`force_refresh` 语义与 dataset 逐份回传见 skill `capital-data-protocol`；profile 回传与
时间轴见 `capital-data-profile`；`query_request` / QuerySpec 与派生算术见 `capital-data-query`。
