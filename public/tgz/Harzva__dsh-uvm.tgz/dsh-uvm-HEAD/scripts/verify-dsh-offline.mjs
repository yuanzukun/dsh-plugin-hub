import { createServer } from 'node:http'
import { spawn, spawnSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'

const require = createRequire(import.meta.url)
const packagePath = require.resolve('@deepseek-ai/dsh/package.json')
const dshPackage = JSON.parse(await readFile(packagePath, 'utf8'))
const cli = resolve(dirname(packagePath), typeof dshPackage.bin === 'string' ? dshPackage.bin : dshPackage.bin.dsh)
const artifact = resolve(process.argv[2] ?? 'artifacts/harness-flow-dsh-uvm-0.1.0-alpha.1.tgz')
const tempRoot = resolve('../../work/dsh-uvm-offline-verification')

// Without an explicit artifact, pack a fresh tarball from the current tree —
// verifying the stale artifact from an earlier pack would test old code.
if (process.argv[2] === undefined) {
  const pnpmBin = process.platform === 'win32' ? 'pnpm.cmd' : 'pnpm'
  const pack = spawnSync(pnpmBin, ['pack', '--pack-destination', 'artifacts'], { encoding: 'utf8', windowsHide: true })
  if (pack.status !== 0) throw new Error(`pnpm pack failed: ${pack.stderr || pack.stdout}`)
}

function run(home, args) {
  return spawnSync(process.execPath, [cli, ...args], { env: { ...process.env, DSH_HOME: home }, encoding: 'utf8', windowsHide: true })
}

function requireSuccess(result, label) {
  if (result.status !== 0) throw new Error(`${label} failed: ${result.stderr || result.stdout}`)
  return result
}

async function freePort() {
  const server = createServer()
  await new Promise((resolveListen, reject) => server.once('error', reject).listen(0, '127.0.0.1', resolveListen))
  const address = server.address()
  const port = typeof address === 'object' && address !== null ? address.port : 0
  await new Promise(resolveClose => server.close(resolveClose))
  return port
}

async function stop(child) {
  if (child.exitCode !== null) return
  child.kill('SIGTERM')
  const result = await Promise.race([new Promise(resolveExit => child.once('exit', resolveExit)), new Promise(resolveTimeout => setTimeout(() => resolveTimeout('timeout'), 10_000))])
  if (result === 'timeout') child.kill('SIGKILL')
}

await mkdir(tempRoot, { recursive: true })
const home = await mkdtemp(join(tempRoot, 'run-'))
const envRoot = await mkdtemp(join(tempRoot, 'envs-'))
let child
let projectDir
try {
  requireSuccess(run(home, ['--profile', 'web', '--dump-default-config']), 'profile bootstrap')
  requireSuccess(run(home, ['plugin', '--profile', 'web', 'add', artifact, '--save-exact', '--ignore-scripts', '--reporter=silent']), 'plugin install')
  requireSuccess(run(home, ['--profile', 'web', '--dump-config']), 'dump-config')
  const port = await freePort()
  const origin = `http://127.0.0.1:${port}`
  child = spawn(process.execPath, [cli, '--profile', 'web', '--host', '127.0.0.1', '--port', String(port)], { env: { ...process.env, DSH_HOME: home, DSH_UVM_ENV_ROOT: envRoot }, stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true })
  let stderr = ''
  child.stderr.on('data', chunk => { stderr = `${stderr}${String(chunk)}`.slice(-8_000) })
  const deadline = Date.now() + 60_000
  let bootstrap
  while (Date.now() < deadline) {
    if (child.exitCode !== null) throw new Error(`DSH Web exited: ${child.exitCode}; ${stderr}`)
    try {
      const response = await fetch(`${origin}/dsh-uvm/api/bootstrap`, { signal: AbortSignal.timeout(2_000) })
      bootstrap = { status: response.status, body: await response.json() }
      break
    } catch {}
    await new Promise(resolveWait => setTimeout(resolveWait, 250))
  }
  if (bootstrap?.status !== 200 || bootstrap.body?.ok !== true) throw new Error(`unexpected bootstrap: ${JSON.stringify(bootstrap)}`)
  if (typeof bootstrap.body?.envRoot !== 'string' || bootstrap.body.envRoot === '') throw new Error(`missing envRoot: ${JSON.stringify(bootstrap)}`)
  const client = await fetch(`${origin}/plugins/@harness-flow/dsh-uvm/client.js`, { signal: AbortSignal.timeout(10_000) })
  const clientText = await client.text()
  if (client.status !== 200 || !clientText.includes('@harness-flow/dsh-uvm')) throw new Error('DSH client module did not load')

  // Full lifecycle E2E against the live booted DSH, inside the throwaway env root.
  let e2e = 'skipped-no-uv'
  if (bootstrap.body.toolchain.uv.available === true) {
    const call = async (path, init) => {
      const response = await fetch(`${origin}${path}`, { ...init, signal: AbortSignal.timeout(150_000) })
      const body = await response.json()
      if (!response.ok || body.ok === false) throw new Error(`${path} -> ${response.status}: ${JSON.stringify(body)}`)
      return body
    }
    const created = await call('/dsh-uvm/api/envs', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'e2e-smoke' }),
    })
    if (created.env?.name !== 'e2e-smoke') throw new Error(`unexpected create: ${JSON.stringify(created)}`)
    const install = await call('/dsh-uvm/api/envs/e2e-smoke/install', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ packages: ['six'] }),
    })
    if (install.result?.code !== 0) throw new Error(`install failed: ${JSON.stringify(install)}`)
    const packages = await call('/dsh-uvm/api/envs/e2e-smoke/packages')
    if (!packages.packages?.some(line => line.startsWith('six=='))) throw new Error(`six missing: ${JSON.stringify(packages)}`)
    const run = await call('/dsh-uvm/api/envs/e2e-smoke/run', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ command: 'python', args: ['-V'] }),
    })
    if (run.result?.code !== 0 || !/Python 3\./.test(run.result?.stdout ?? '')) throw new Error(`run failed: ${JSON.stringify(run)}`)
    const sync = await call('/dsh-uvm/api/envs/e2e-smoke/sync', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ requirements: 'six==1.17.0\n' }),
    })
    if (sync.result?.code !== 0) throw new Error(`sync failed: ${JSON.stringify(sync)}`)
    projectDir = await mkdtemp(join(tempRoot, 'proj-'))
    await writeFile(join(projectDir, 'pyproject.toml'), [
      '[project]',
      'name = "e2e-smoke-proj"',
      'version = "0.1.0"',
      'requires-python = ">=3.9"',
      'dependencies = ["six==1.17.0"]',
      '',
    ].join('\n'))
    const projectPreview = await call('/dsh-uvm/api/envs/e2e-smoke/project-preview', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ project: projectDir }),
    })
    if (projectPreview.preview?.summary?.total !== 1 || projectPreview.preview?.dependencies?.[0]?.status !== 'installed') throw new Error(`project preview failed: ${JSON.stringify(projectPreview)}`)
    const projectApply = await call('/dsh-uvm/api/envs/e2e-smoke/project-sync', {
      method: 'POST', headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ project: projectDir }),
    })
    if (projectApply.skipped !== true || projectApply.result?.code !== 0) throw new Error(`project sync failed: ${JSON.stringify(projectApply)}`)
    const removed = await call('/dsh-uvm/api/envs/e2e-smoke', { method: 'DELETE' })
    if (removed.removed !== 'e2e-smoke') throw new Error(`remove failed: ${JSON.stringify(removed)}`)
    const after = await call('/dsh-uvm/api/bootstrap')
    if (after.envs?.some(env => env.name === 'e2e-smoke')) throw new Error('env left behind after delete')
    const forbidden = await fetch(`${origin}/dsh-uvm/api/envs`, {
      method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://evil.example' },
      body: JSON.stringify({ name: 'x' }),
    })
    if (forbidden.status !== 403) throw new Error(`origin guard failed: ${forbidden.status}`)
    e2e = 'passed'
  }
  process.stdout.write(`${JSON.stringify({ ok: true, dshVersion: dshPackage.version, web: 200, uvmBootstrap: 200, toolchain: { uv: bootstrap.body.toolchain.uv.available, pip: bootstrap.body.toolchain.pip.available, conda: bootstrap.body.toolchain.conda.available }, clientModule: 200, e2e, userProfileTouched: false })}\n`)
} finally {
  if (child) await stop(child)
  await rm(home, { recursive: true, force: true })
  await rm(envRoot, { recursive: true, force: true })
  if (projectDir) await rm(projectDir, { recursive: true, force: true })
}
