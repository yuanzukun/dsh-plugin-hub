# dsh-uvm 路线图

| 状态 | 能力 |
|---|---|
| ✅ 已实现 | 工具链医生：uv / pip / conda 探测与版本 |
| ✅ 已实现 | `uv python list --only-installed` 版本清单 |
| ✅ 已实现 | 托管环境列表（pyvenv.cfg 解析，uv/pip 来源标注） |
| ✅ 已实现 | 创建 / 删除环境（uv venv，pip 回退，路径遏制） |
| ✅ 已实现 | 安装 / 卸载包（uv pip，pip 回退） |
| ✅ 已实现 | requirements 经 stdin 同步（uv pip install -r -） |
| ✅ 已实现 | 环境内运行 python / pip，60s 超时与输出上限 |
| ✅ 已实现 | conda 环境只读列表 |
| ✅ 已实现 | loopback + 同源守卫、无 shell 派生、输入白名单 |
| ✅ 已实现 | 隔离 DSH 配置实机验证脚本 |
| ✅ 已实现 | 项目级 `uv sync` 差异预览：静态解析 `pyproject.toml` 依赖 + `uv.lock` 锁定版本，与环境 freeze 做 PEP 503 归一化比对（已满足 / 缺失 / 版本漂移），预览零网络 |
| ✅ 已实现 | 项目依赖应用同步：缺失/漂移规格经 stdin 走 `uv pip install -r -`（pip 回退），无变更自动跳过 |
| 🚧 计划 | 环境规格文件：`uvm.toml` 声明 python 版本 + 依赖 + requirements 路径，实现 `环境 → 锁定 → 同步` 三阶段 |
| 🚧 计划 | 长任务化：安装/同步改为后台任务 + 进度流，而不是阻塞 HTTP 请求 |
| 🚧 计划 | 环境克隆、重命名与磁盘占用统计 |
| 🚧 计划 | Windows 专用回归（当前验证目标为 macOS + DSH 0.1.0-rc.6） |
| 🚧 计划 | 注册 DSH Agent 工具（`uvm_list` / `uvm_install` / `uvm_run`），让 Agent 直接管理环境 |
| ❌ 不做 | 托管 conda 生命周期（只读可见，写操作永远留给用户自己的 conda） |
| ❌ 不做 | 上传环境清单、包数据或任何诊断到远端 |

## 里程碑

- **M1 ✅**：单机 uv 生命周期闭环 + 隔离实机验证 + 18 项自动化测试。
- **M2 ✅（当前）**：项目级 `uv sync` dry-run 差异预览与应用同步。
- **M3**：`uvm.toml` 环境规格 + Agent 工具。
