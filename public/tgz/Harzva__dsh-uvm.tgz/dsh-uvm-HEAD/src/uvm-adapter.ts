import { spawn } from 'node:child_process'
import { accessSync, constants as fsConstants } from 'node:fs'
import { mkdir, readFile, readdir, rm, stat } from 'node:fs/promises'
import { homedir } from 'node:os'
import { basename, delimiter, isAbsolute, join, resolve, sep } from 'node:path'

export const DEFAULT_ENV_ROOT = join(homedir(), '.dsh-uvm', 'envs')
export const ENV_NAME_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/
export const PACKAGE_SPEC_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._~^!+*=<>,-]{0,127}$/
export const PYTHON_VERSION_PATTERN = /^[\w.+-]{1,64}$/
export const MAX_PACKAGES = 100
export const MAX_RUN_ARGS = 64
export const MAX_RUN_ARG_LENGTH = 256
export const MAX_REQUIREMENTS_BYTES = 256 * 1024
export const MAX_OUTPUT_BYTES = 512 * 1024
export const CREATE_TIMEOUT_MS = 180_000
export const MUTATE_TIMEOUT_MS = 120_000
export const RUN_TIMEOUT_MS = 60_000
export const QUERY_TIMEOUT_MS = 30_000

export interface ToolInfo {
  available: boolean
  path: string | null
  version: string | null
}

export interface PipInfo {
  available: boolean
  python: string | null
  pipVersion: string | null
}

export interface Toolchain {
  uv: ToolInfo
  pip: PipInfo
  conda: ToolInfo
}

export interface ManagedEnv {
  name: string
  path: string
  python: string | null
  source: 'uv' | 'pip'
}

export interface CondaEnv {
  name: string
  path: string
}

export interface ProcessResult {
  code: number
  stdout: string
  stderr: string
  timedOut: boolean
}

export interface RunProcessOptions {
  input?: string
  timeoutMs?: number
  cwd?: string
}

export interface CreateEnvOptions {
  root: string
  name: string
  python?: string
  toolchain: Toolchain
}

// ---- child process ------------------------------------------------------

function capture(chunk: Buffer, current: string): { text: string; full: boolean } {
  const text = current + chunk.toString('utf8')
  if (text.length > MAX_OUTPUT_BYTES) return { text: text.slice(0, MAX_OUTPUT_BYTES), full: true }
  return { text, full: false }
}

export function runProcess(command: string, args: string[], options: RunProcessOptions = {}): Promise<ProcessResult> {
  const timeoutMs = options.timeoutMs ?? MUTATE_TIMEOUT_MS
  return new Promise<ProcessResult>((resolvePromise) => {
    let stdout = ''
    let stderr = ''
    let stdoutFull = false
    let stderrFull = false
    let timedOut = false
    let settled = false
    let killTimer: ReturnType<typeof setTimeout> | null = null

    const finish = (code: number): void => {
      if (settled) return
      settled = true
      if (killTimer !== null) {
        clearTimeout(killTimer)
        killTimer = null
      }
      resolvePromise({ code, stdout, stderr, timedOut })
    }

    const child = spawn(command, args, {
      env: { ...process.env, UV_NO_PROGRESS: '1', PIP_DISABLE_PIP_VERSION_CHECK: '1', PYTHONUNBUFFERED: '1' },
      cwd: options.cwd,
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    })

    child.on('error', (error) => {
      if (settled) return
      const code = (error as NodeJS.ErrnoException).code
      stderr = code === 'ENOENT' ? 'tool-not-found' : `spawn-${code ?? 'error'}`
      finish(127)
    })

    child.stdout?.on('data', (chunk: Buffer) => {
      if (stdoutFull) return
      const captured = capture(chunk, stdout)
      stdout = captured.text
      stdoutFull = captured.full
    })
    child.stderr?.on('data', (chunk: Buffer) => {
      if (stderrFull) return
      const captured = capture(chunk, stderr)
      stderr = captured.text
      stderrFull = captured.full
    })

    child.stdin?.end(options.input)

    child.on('close', (code) => finish(code ?? 0))

    killTimer = setTimeout(() => {
      timedOut = true
      child.kill('SIGTERM')
      setTimeout(() => child.kill('SIGKILL'), 3_000).unref()
    }, timeoutMs)
  })
}

async function firstLine(command: string, args: string[]): Promise<string | null> {
  try {
    const result = await runProcess(command, args, { timeoutMs: QUERY_TIMEOUT_MS })
    if (result.code !== 0) return null
    const line = `${result.stdout}\n${result.stderr}`.split('\n').map(item => item.trim()).find(item => item !== '')
    return line ?? null
  } catch {
    return null
  }
}

// ---- toolchain detection --------------------------------------------------

export function findOnPath(name: string, envPath: string = process.env.PATH ?? ''): string | null {
  const candidates = process.platform === 'win32' ? [`${name}.exe`, `${name}.cmd`, name] : [name]
  for (const dir of envPath.split(delimiter)) {
    if (dir === '') continue
    for (const candidate of candidates) {
      const path = join(dir, candidate)
      try {
        accessSync(path, fsConstants.X_OK)
        return path
      } catch {
        // keep searching
      }
    }
  }
  return null
}

export async function detectToolchain(config: { uvPath?: string; pythonPath?: string } = {}): Promise<Toolchain> {
  const uvPath = config.uvPath?.trim() || findOnPath('uv')
  const uvVersion = uvPath === null ? null : await firstLine(uvPath, ['--version'])

  const python = config.pythonPath?.trim() || findOnPath('python3') || findOnPath('python')
  const pipVersion = python === null ? null : await firstLine(python, ['-m', 'pip', '--version'])

  const condaPath = findOnPath('conda')
  const condaVersion = condaPath === null ? null : await firstLine(condaPath, ['--version'])

  return {
    uv: { available: uvPath !== null, path: uvPath, version: uvVersion },
    pip: { available: python !== null, python, pipVersion },
    conda: { available: condaPath !== null, path: condaPath, version: condaVersion },
  }
}

// ---- validation ------------------------------------------------------------

export function validateEnvName(value: unknown): string {
  if (typeof value !== 'string' || !ENV_NAME_PATTERN.test(value)) throw new Error('invalid-env-name')
  return value
}

export function validateCreateInput(value: unknown): { name: string; python?: string } {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) throw new Error('invalid-create-input')
  const record = value as Record<string, unknown>
  const allowed = new Set(['name', 'python'])
  if (Object.keys(record).some(key => !allowed.has(key))) throw new Error('invalid-create-input')
  const name = validateEnvName(record.name)
  if (record.python !== undefined) {
    if (typeof record.python !== 'string' || !PYTHON_VERSION_PATTERN.test(record.python)) throw new Error('invalid-python-version')
    return { name, python: record.python }
  }
  return { name }
}

export function validatePackageSpecs(value: unknown): string[] {
  if (!Array.isArray(value) || value.length === 0 || value.length > MAX_PACKAGES) throw new Error('invalid-packages')
  return value.map((item, index) => {
    if (typeof item !== 'string' || !PACKAGE_SPEC_PATTERN.test(item)) throw new Error(`invalid-package-${index}`)
    return item
  })
}

export function validateRequirements(value: unknown): string {
  if (typeof value !== 'string' || value.length === 0) throw new Error('invalid-requirements')
  if (Buffer.byteLength(value, 'utf8') > MAX_REQUIREMENTS_BYTES) throw new Error('requirements-too-large')
  return value
}

export function validateRunInput(value: unknown): { command: 'python' | 'pip'; args: string[] } {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) throw new Error('invalid-run-input')
  const record = value as Record<string, unknown>
  if (record.command !== 'python' && record.command !== 'pip') throw new Error('invalid-run-command')
  if (!Array.isArray(record.args) || record.args.length > MAX_RUN_ARGS) throw new Error('invalid-run-args')
  const args = record.args.map((item, index) => {
    if (typeof item !== 'string' || item.length === 0 || item.length > MAX_RUN_ARG_LENGTH || /[\u0000-\u001f\u007f]/.test(item)) throw new Error(`invalid-run-arg-${index}`)
    return item
  })
  return { command: record.command, args }
}

// ---- managed env paths -------------------------------------------------------

export function normalizeEnvRoot(value?: string): string {
  if (value === undefined || value.trim() === '') return DEFAULT_ENV_ROOT
  return resolve(value.trim())
}

export function resolveEnvPath(root: string, name: string): string {
  validateEnvName(name)
  const base = resolve(root)
  const candidate = resolve(base, name)
  if (candidate !== base && candidate.startsWith(base + sep)) return candidate
  throw new Error('env-path-escape')
}

export function envPythonPath(env: ManagedEnv): string {
  return process.platform === 'win32' ? join(env.path, 'Scripts', 'python.exe') : join(env.path, 'bin', 'python')
}

async function readManagedEnv(root: string, name: string): Promise<ManagedEnv | null> {
  const envPath = resolveEnvPath(root, name)
  try {
    const text = await readFile(join(envPath, 'pyvenv.cfg'), 'utf8')
    let python: string | null = null
    let source: 'uv' | 'pip' = 'pip'
    for (const line of text.split('\n')) {
      const index = line.indexOf('=')
      if (index < 0) continue
      const key = line.slice(0, index).trim()
      const value = line.slice(index + 1).trim()
      if (key === 'version') python = value
      if (key === 'uv') source = 'uv'
    }
    return { name, path: envPath, python, source }
  } catch {
    return null
  }
}

export async function listManagedEnvs(root: string): Promise<ManagedEnv[]> {
  await mkdir(root, { recursive: true })
  const entries = await readdir(root, { withFileTypes: true })
  const envs: ManagedEnv[] = []
  for (const entry of entries) {
    if (!entry.isDirectory() || !ENV_NAME_PATTERN.test(entry.name)) continue
    const env = await readManagedEnv(root, entry.name)
    if (env !== null) envs.push(env)
  }
  return envs.sort((a, b) => a.name.localeCompare(b.name))
}

// ---- environment operations ---------------------------------------------------

export async function createEnv(options: CreateEnvOptions): Promise<ManagedEnv> {
  const name = validateEnvName(options.name)
  const envPath = resolveEnvPath(options.root, name)
  await mkdir(options.root, { recursive: true })
  const python = options.python?.trim()
  if (python !== undefined && python !== '' && !PYTHON_VERSION_PATTERN.test(python)) throw new Error('invalid-python-version')

  if (options.toolchain.uv.available && options.toolchain.uv.path !== null) {
    const result = await runProcess(options.toolchain.uv.path, ['venv', envPath, ...(python !== undefined && python !== '' ? ['--python', python] : [])], { timeoutMs: CREATE_TIMEOUT_MS })
    if (result.code !== 0) throw new Error('uv-create-failed')
  } else if (options.toolchain.pip.available && options.toolchain.pip.python !== null) {
    const result = await runProcess(options.toolchain.pip.python, ['-m', 'venv', envPath], { timeoutMs: CREATE_TIMEOUT_MS })
    if (result.code !== 0) throw new Error('venv-create-failed')
  } else {
    throw new Error('no-python-toolchain')
  }
  const env = await readManagedEnv(options.root, name)
  if (env === null) throw new Error('env-create-verify-failed')
  return env
}

export async function removeEnv(root: string, name: string): Promise<void> {
  const env = await readManagedEnv(root, validateEnvName(name))
  if (env === null) throw new Error('env-not-found')
  await rm(env.path, { recursive: true, force: true })
}

export async function installPackages(env: ManagedEnv, packages: string[], toolchain: Toolchain): Promise<ProcessResult> {
  const specs = validatePackageSpecs(packages)
  if (toolchain.uv.available && toolchain.uv.path !== null) {
    return runProcess(toolchain.uv.path, ['pip', 'install', '--python', envPythonPath(env), '--no-progress', ...specs], { timeoutMs: MUTATE_TIMEOUT_MS })
  }
  return runProcess(envPythonPath(env), ['-m', 'pip', 'install', ...specs], { timeoutMs: MUTATE_TIMEOUT_MS })
}

export async function uninstallPackages(env: ManagedEnv, packages: string[], toolchain: Toolchain): Promise<ProcessResult> {
  const specs = validatePackageSpecs(packages)
  if (toolchain.uv.available && toolchain.uv.path !== null) {
    return runProcess(toolchain.uv.path, ['pip', 'uninstall', '--python', envPythonPath(env), ...specs], { timeoutMs: MUTATE_TIMEOUT_MS })
  }
  return runProcess(envPythonPath(env), ['-m', 'pip', 'uninstall', '-y', ...specs], { timeoutMs: MUTATE_TIMEOUT_MS })
}

export async function syncRequirements(env: ManagedEnv, requirements: string, toolchain: Toolchain): Promise<ProcessResult> {
  const text = validateRequirements(requirements)
  if (toolchain.uv.available && toolchain.uv.path !== null) {
    return runProcess(toolchain.uv.path, ['pip', 'install', '--python', envPythonPath(env), '--no-progress', '-r', '-'], { input: text, timeoutMs: MUTATE_TIMEOUT_MS })
  }
  return runProcess(envPythonPath(env), ['-m', 'pip', 'install', '-r', '-'], { input: text, timeoutMs: MUTATE_TIMEOUT_MS })
}

export async function freezePackages(env: ManagedEnv, toolchain: Toolchain): Promise<string[]> {
  const result = toolchain.uv.available && toolchain.uv.path !== null
    ? await runProcess(toolchain.uv.path, ['pip', 'freeze', '--python', envPythonPath(env)], { timeoutMs: QUERY_TIMEOUT_MS })
    : await runProcess(envPythonPath(env), ['-m', 'pip', 'freeze'], { timeoutMs: QUERY_TIMEOUT_MS })
  if (result.code !== 0) throw new Error('freeze-failed')
  return result.stdout.split('\n').map(line => line.trim()).filter(line => line !== '' && !line.startsWith('#'))
}

export async function runInEnv(env: ManagedEnv, command: 'python' | 'pip', args: string[], toolchain: Toolchain): Promise<ProcessResult> {
  const python = envPythonPath(env)
  return command === 'python'
    ? runProcess(python, args, { timeoutMs: RUN_TIMEOUT_MS })
    : runProcess(python, ['-m', 'pip', ...args], { timeoutMs: RUN_TIMEOUT_MS })
}

// ---- read-only inventory -------------------------------------------------------

export async function listPythonVersions(toolchain: Toolchain): Promise<string[]> {
  if (!toolchain.uv.available || toolchain.uv.path === null) return []
  try {
    const result = await runProcess(toolchain.uv.path, ['python', 'list', '--only-installed'], { timeoutMs: QUERY_TIMEOUT_MS })
    if (result.code !== 0) return []
    const versions: string[] = []
    for (const line of result.stdout.split('\n')) {
      const match = /^[a-z]+-(\d+\.\d+(?:\.\d+)?)/.exec(line.trim())
      const version = match?.[1]
      if (version !== undefined && !versions.includes(version)) versions.push(version)
    }
    return versions
  } catch {
    return []
  }
}

export async function listCondaEnvs(toolchain: Toolchain): Promise<CondaEnv[]> {
  if (!toolchain.conda.available || toolchain.conda.path === null) return []
  try {
    const result = await runProcess(toolchain.conda.path, ['env', 'list', '--json'], { timeoutMs: QUERY_TIMEOUT_MS })
    if (result.code !== 0) return []
    const parsed = JSON.parse(result.stdout) as { envs?: unknown }
    if (!Array.isArray(parsed.envs)) return []
    return parsed.envs.slice(0, 200).flatMap((item): CondaEnv[] => {
      if (typeof item === 'string') return [{ name: basename(item) || item, path: item }]
      if (typeof item === 'object' && item !== null) {
        const record = item as Record<string, unknown>
        const path = typeof record.prefix === 'string' ? record.prefix : typeof record.path === 'string' ? record.path : null
        const name = typeof record.name === 'string' ? record.name : null
        if (path === null) return []
        return [{ name: name ?? basename(path), path }]
      }
      return []
    })
  } catch {
    return []
  }
}

// ---- project sync (M2) ---------------------------------------------------------

export const MAX_PROJECT_PATH_LENGTH = 512
export const MAX_PROJECT_FILE_BYTES = 256 * 1024
export const MAX_PROJECT_DEPS = 200

export interface ProjectDepStatus {
  spec: string
  name: string
  installed: string | null
  locked: string | null
  status: 'installed' | 'missing' | 'drift'
}

export interface ProjectSyncPreview {
  projectPath: string
  pyproject: boolean
  lockfile: boolean
  requiresPython: string | null
  dependencies: ProjectDepStatus[]
  summary: { total: number; installed: number; missing: number; drift: number }
}

export interface ProjectManifest {
  dependencies: string[]
  requiresPython: string | null
  unparsed: boolean
}

export function validateProjectPath(value: unknown): string {
  if (typeof value !== 'string') throw new Error('invalid-project-path')
  const trimmed = value.trim()
  if (trimmed.length === 0 || trimmed.length > MAX_PROJECT_PATH_LENGTH) throw new Error('invalid-project-path')
  if (/[\u0000-\u001f\u007f]/.test(trimmed) || !isAbsolute(trimmed)) throw new Error('invalid-project-path')
  return resolve(trimmed)
}

export function normalizePackageName(name: string): string {
  return name.trim().toLowerCase().replace(/[-_.]+/g, '-')
}

/**
 * Parse the `[project]` table of a pyproject.toml: the flat string-array
 * `dependencies` and `requires-python`. Deliberately narrow — no external
 * TOML dependency; anything fancier marks the manifest `unparsed`.
 */
export function parseProjectManifest(toml: string): ProjectManifest {
  const manifest: ProjectManifest = { dependencies: [], requiresPython: null, unparsed: false }
  const lines = toml.split(/\r?\n/)
  let inProject = false
  for (let i = 0; i < lines.length; i += 1) {
    const trimmed = lines[i]!.trim()
    const header = /^\[([^\]]+)\]/.exec(trimmed)
    if (header !== null) {
      inProject = header[1] === 'project'
      continue
    }
    if (!inProject || trimmed === '' || trimmed.startsWith('#')) continue
    const requires = /^requires-python\s*=\s*"([^"]*)"(?:\s+#.*)?$/.exec(trimmed)
    if (requires !== null) {
      manifest.requiresPython = requires[1] ?? null
      continue
    }
    const depStart = /^dependencies\s*=/.exec(trimmed)
    if (depStart === null) continue
    const values: string[] = []
    let depth = 0
    let sawOpen = false
    let plain = true
    let closed = false
    outer: for (let j = i; j < lines.length && !closed; j += 1) {
      const rawLine = lines[j]!
      const line = j === i ? rawLine.slice(rawLine.indexOf('=') + 1) : rawLine
      let k = 0
      while (k < line.length) {
        const char = line[k]!
        if (char === '#') break // comment runs to end of line
        if (char === '[') { depth += 1; sawOpen = true; k += 1; continue }
        if (char === ']') {
          depth -= 1
          k += 1
          if (depth === 0 && sawOpen) { closed = true; break outer }
          continue
        }
        if (char === '"' || char === "'") {
          const quote = char
          let out = ''
          let escaped = false
          k += 1
          while (k < line.length) {
            const c = line[k]!
            if (escaped) { out += c; escaped = false; k += 1; continue }
            if (c === '\\' && quote === '"') { escaped = true; k += 1; continue }
            if (c === quote) break
            out += c
            k += 1
          }
          k += 1
          values.push(out)
          continue
        }
        if (char === ',' || /\s/.test(char)) { k += 1; continue }
        plain = false // nested tables or expressions are not a flat string array
        k += 1
      }
    }
    if (!sawOpen || !closed || !plain) {
      manifest.unparsed = true
      continue
    }
    manifest.dependencies.push(...values.map(value => value.trim()).filter(value => value !== ''))
  }
  return manifest
}

/** Extract `name` → `version` from a uv.lock, first package entry per name wins. */
export function parseLockVersions(lock: string): Map<string, string> {
  const versions = new Map<string, string>()
  let currentName: string | null = null
  for (const raw of lock.split(/\r?\n/)) {
    const line = raw.trim()
    if (line.startsWith('[[package]]')) {
      currentName = null
      continue
    }
    const name = /^name\s*=\s*"([^"]+)"/.exec(line)
    if (name !== null) {
      currentName = name[1] ?? null
      continue
    }
    if (currentName !== null) {
      const version = /^version\s*=\s*"([^"]+)"/.exec(line)
      if (version !== null) {
        const key = normalizePackageName(currentName)
        if (!versions.has(key)) versions.set(key, version[1]!)
        currentName = null
      }
    }
  }
  return versions
}

export function parsePackageSpec(spec: string): { name: string; pinned: string | null } {
  const text = spec.trim()
  const match = /^([A-Za-z0-9][A-Za-z0-9._-]*)/.exec(text)
  const name = match?.[1] ?? ''
  const rest = text.slice(name.length).trim()
  const pinnedMatch = /^==\s*([A-Za-z0-9][A-Za-z0-9._+!-]*)/.exec(rest)
  return { name, pinned: pinnedMatch?.[1] ?? null }
}

function parseFreezeLines(freeze: string[]): Map<string, string> {
  const installed = new Map<string, string>()
  for (const line of freeze) {
    if (line.startsWith('#')) continue
    const eq = line.indexOf('==')
    if (eq <= 0) continue
    installed.set(normalizePackageName(line.slice(0, eq)), line.slice(eq + 2).split(';')[0]?.trim() ?? '')
  }
  return installed
}

/**
 * Dry-run project sync: statically parse the project's dependency declaration
 * and lock file, then diff them against the environment's freeze — no network,
 * no full dependency resolution. Version drift is judged only for `==`-pinned
 * specs or uv.lock-locked versions; bounded specs (>= etc.) report the installed
 * version and leave resolution to uv at apply time.
 */
export async function previewProjectSync(env: ManagedEnv, projectPath: unknown, toolchain: Toolchain): Promise<ProjectSyncPreview> {
  const project = validateProjectPath(projectPath)
  let tomlText: string
  try {
    const info = await stat(join(project, 'pyproject.toml'))
    if (!info.isFile()) throw new Error('project-toml-not-found')
    const buffer = await readFile(join(project, 'pyproject.toml'))
    if (buffer.byteLength > MAX_PROJECT_FILE_BYTES) throw new Error('project-toml-too-large')
    tomlText = buffer.toString('utf8')
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('project-')) throw error
    throw new Error('project-toml-not-found')
  }
  const manifest = parseProjectManifest(tomlText)
  if (manifest.unparsed) throw new Error('project-dependencies-unsupported')
  if (manifest.dependencies.length === 0) throw new Error('project-no-dependencies')
  if (manifest.dependencies.length > MAX_PROJECT_DEPS) throw new Error('project-deps-too-many')

  let lockfile = false
  let locked = new Map<string, string>()
  try {
    const info = await stat(join(project, 'uv.lock'))
    if (info.isFile()) {
      lockfile = true
      const buffer = await readFile(join(project, 'uv.lock'))
      if (buffer.byteLength <= MAX_PROJECT_FILE_BYTES) locked = parseLockVersions(buffer.toString('utf8'))
    }
  } catch {
    // the lock file is advisory; an unreadable one does not block the preview
  }

  const installed = parseFreezeLines(await freezePackages(env, toolchain))
  const dependencies: ProjectDepStatus[] = []
  let installedCount = 0
  let missingCount = 0
  let driftCount = 0
  for (const spec of manifest.dependencies) {
    const { name, pinned } = parsePackageSpec(spec)
    const key = normalizePackageName(name)
    const installedVersion = installed.get(key) ?? null
    const lockedVersion = locked.get(key) ?? null
    let status: ProjectDepStatus['status']
    if (installedVersion === null) status = 'missing'
    else if (pinned !== null && pinned !== installedVersion) status = 'drift'
    else if (lockedVersion !== null && lockedVersion !== installedVersion) status = 'drift'
    else status = 'installed'
    if (status === 'installed') installedCount += 1
    if (status === 'missing') missingCount += 1
    if (status === 'drift') driftCount += 1
    dependencies.push({ spec, name, installed: installedVersion, locked: lockedVersion, status })
  }
  return {
    projectPath: project,
    pyproject: true,
    lockfile,
    requiresPython: manifest.requiresPython,
    dependencies,
    summary: { total: dependencies.length, installed: installedCount, missing: missingCount, drift: driftCount },
  }
}

export async function applyProjectSync(env: ManagedEnv, projectPath: unknown, toolchain: Toolchain): Promise<{ result: ProcessResult; preview: ProjectSyncPreview; skipped: boolean }> {
  const preview = await previewProjectSync(env, projectPath, toolchain)
  if (preview.summary.missing === 0 && preview.summary.drift === 0) {
    return { result: { code: 0, stdout: '', stderr: '', timedOut: false }, preview, skipped: true }
  }
  const requirements = preview.dependencies
    .filter(item => item.status !== 'installed')
    .map(item => (item.locked !== null && !item.spec.includes('[') && !item.spec.includes(';') ? `${normalizePackageName(item.name)}==${item.locked}` : item.spec))
    .join('\n') + '\n'
  const result = await syncRequirements(env, requirements, toolchain)
  return { result, preview, skipped: false }
}
