import { useCallback, useEffect, useState, type ChangeEvent, type FormEvent, type ReactNode } from 'react'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'

export const inject = ['slots']

interface ToolInfo { available: boolean, path: string | null, version: string | null }
interface PipInfo { available: boolean, python: string | null, pipVersion: string | null }
interface ManagedEnv { name: string, path: string, python: string | null, source: 'uv' | 'pip' }
interface CondaEnv { name: string, path: string }
interface Bootstrap {
  ok: boolean
  envRoot: string
  toolchain: { uv: ToolInfo, pip: PipInfo, conda: ToolInfo }
  pythons: string[]
  envs: ManagedEnv[]
  condaEnvs: CondaEnv[]
  error?: string
}
interface ProcessResult { code: number, stdout: string, stderr: string, timedOut: boolean }
interface ProjectDepStatus { spec: string, name: string, installed: string | null, locked: string | null, status: 'installed' | 'missing' | 'drift' }
interface ProjectSyncPreview { projectPath: string, pyproject: boolean, lockfile: boolean, requiresPython: string | null, dependencies: ProjectDepStatus[], summary: { total: number, installed: number, missing: number, drift: number } }
type ApiBody<T> = T & { ok?: boolean, error?: string }
type Mode = 'packages' | 'install' | 'sync' | 'run' | 'project' | null

const EMPTY_BOOTSTRAP: Bootstrap = {
  ok: false,
  envRoot: '',
  toolchain: {
    uv: { available: false, path: null, version: null },
    pip: { available: false, python: null, pipVersion: null },
    conda: { available: false, path: null, version: null },
  },
  pythons: [],
  envs: [],
  condaEnvs: [],
  error: 'uvm-bridge-unavailable',
}

function message(error: unknown): string {
  return error instanceof Error ? error.message : 'unknown'
}

async function api<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, { cache: 'no-store', ...init })
  const body = await response.json() as ApiBody<T>
  if (!response.ok || body.ok === false) throw new Error(body.error ?? `http-${response.status}`)
  return body
}

function UvmPanel(): ReactNode {
  const [bootstrap, setBootstrap] = useState<Bootstrap | null>(null)
  const [selected, setSelected] = useState<string | null>(null)
  const [mode, setMode] = useState<Mode>(null)
  const [packages, setPackages] = useState<string[] | null>(null)
  const [packagesLoading, setPackagesLoading] = useState(false)
  const [nameInput, setNameInput] = useState('')
  const [pythonInput, setPythonInput] = useState('')
  const [installInput, setInstallInput] = useState('')
  const [requirementsInput, setRequirementsInput] = useState('')
  const [runCommand, setRunCommand] = useState<'python' | 'pip'>('python')
  const [runArgs, setRunArgs] = useState('')
  const [result, setResult] = useState<ProcessResult | null>(null)
  const [status, setStatus] = useState('')
  const [busy, setBusy] = useState(false)

  const refresh = useCallback(async () => {
    try {
      const body = await api<Bootstrap>('/dsh-uvm/api/bootstrap')
      setBootstrap(body)
      setSelected(current => current !== null && body.envs.some(env => env.name === current) ? current : body.envs[0]?.name ?? null)
      setPythonInput(current => current === '' ? body.pythons[0] ?? '' : current)
    } catch (error) {
      setBootstrap(current => current ?? { ...EMPTY_BOOTSTRAP, error: message(error) })
    }
  }, [])
  useEffect(() => { void refresh() }, [refresh])

  const fetchPackages = useCallback(async () => {
    if (selected === null) return
    try {
      const body = await api<{ packages: string[] }>(`/dsh-uvm/api/envs/${encodeURIComponent(selected)}/packages`)
      setPackages(body.packages)
    } catch (error) {
      setStatus(`读取包列表失败：${message(error)}`)
    }
  }, [selected])

  const loadPackages = useCallback(async () => {
    setMode('packages')
    setResult(null)
    setPackagesLoading(true)
    try { await fetchPackages() } finally { setPackagesLoading(false) }
  }, [fetchPackages])

  const create = async (event: FormEvent) => {
    event.preventDefault()
    const name = nameInput.trim()
    if (name === '' || busy) return
    setBusy(true)
    setStatus(`正在创建环境 ${name}…`)
    try {
      const body = await api<{ env: ManagedEnv }>('/dsh-uvm/api/envs', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ name, ...(pythonInput === '' ? {} : { python: pythonInput }) }),
      })
      setNameInput('')
      await refresh()
      setSelected(body.env.name)
      setStatus(`已创建环境 ${body.env.name}`)
    } catch (error) {
      setStatus(`创建失败：${message(error)}`)
    } finally {
      setBusy(false)
    }
  }

  const remove = async (name: string) => {
    if (!window.confirm(`确定删除环境「${name}」？该操作不可恢复。`)) return
    setBusy(true)
    setStatus(`正在删除环境 ${name}…`)
    try {
      await api<{ removed: string }>(`/dsh-uvm/api/envs/${encodeURIComponent(name)}`, { method: 'DELETE' })
      if (selected === name) {
        setSelected(null)
        setMode(null)
        setPackages(null)
        setResult(null)
      }
      await refresh()
      setStatus(`已删除环境 ${name}`)
    } catch (error) {
      setStatus(`删除失败：${message(error)}`)
    } finally {
      setBusy(false)
    }
  }

  const installOrUninstall = async (kind: 'install' | 'uninstall') => {
    if (selected === null || busy) return
    const specs = installInput.split(/[\s,]+/).map(item => item.trim()).filter(item => item !== '')
    if (specs.length === 0) return
    setBusy(true)
    setResult(null)
    setStatus(kind === 'install' ? `正在安装 ${specs.length} 个包…` : `正在卸载 ${specs.length} 个包…`)
    try {
      const body = await api<{ result: ProcessResult }>(`/dsh-uvm/api/envs/${encodeURIComponent(selected)}/${kind}`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ packages: specs }),
      })
      setResult(body.result)
      setStatus(body.result.code === 0 ? (kind === 'install' ? '安装完成' : '卸载完成') : `${kind === 'install' ? '安装' : '卸载'}结束（退出码 ${body.result.code}）`)
      if (body.result.code === 0) {
        setInstallInput('')
        if (packages !== null) void fetchPackages()
      }
    } catch (error) {
      setStatus(`${kind === 'install' ? '安装' : '卸载'}失败：${message(error)}`)
    } finally {
      setBusy(false)
    }
  }

  const sync = async () => {
    if (selected === null || busy) return
    const requirements = requirementsInput
    if (requirements.trim() === '') return
    setBusy(true)
    setResult(null)
    setStatus('正在按 requirements 同步环境…')
    try {
      const body = await api<{ result: ProcessResult }>(`/dsh-uvm/api/envs/${encodeURIComponent(selected)}/sync`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ requirements }),
      })
      setResult(body.result)
      setStatus(body.result.code === 0 ? '同步完成' : `同步结束（退出码 ${body.result.code}）`)
      if (body.result.code === 0 && packages !== null) void fetchPackages()
    } catch (error) {
      setStatus(`同步失败：${message(error)}`)
    } finally {
      setBusy(false)
    }
  }

  const run = async () => {
    if (selected === null || busy) return
    const args = runArgs.trim() === '' ? [] : runArgs.split(/\s+/)
    setBusy(true)
    setResult(null)
    setStatus('正在环境中运行…')
    try {
      const body = await api<{ result: ProcessResult }>(`/dsh-uvm/api/envs/${encodeURIComponent(selected)}/run`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ command: runCommand, args }),
      })
      setResult(body.result)
      setStatus(body.result.timedOut ? '运行超时' : `运行结束（退出码 ${body.result.code}）`)
    } catch (error) {
      setStatus(`运行失败：${message(error)}`)
    } finally {
      setBusy(false)
    }
  }

  const [projectInput, setProjectInput] = useState('')
  const [projectPreview, setProjectPreview] = useState<ProjectSyncPreview | null>(null)
  const [projectLoading, setProjectLoading] = useState(false)

  const previewProject = async () => {
    if (selected === null || busy) return
    const project = projectInput.trim()
    if (project === '') return
    setBusy(true)
    setProjectLoading(true)
    setResult(null)
    setStatus('正在解析项目并比对环境差异…')
    try {
      const body = await api<{ preview: ProjectSyncPreview }>(`/dsh-uvm/api/envs/${encodeURIComponent(selected)}/project-preview`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ project }),
      })
      setProjectPreview(body.preview)
      const { missing, drift } = body.preview.summary
      setStatus(missing === 0 && drift === 0 ? '预览完成：环境已满足项目依赖，无需变更。' : `预览完成：${missing} 个缺失、${drift} 个版本漂移。`)
    } catch (error) {
      setProjectPreview(null)
      setStatus(`差异预览失败：${message(error)}`)
    } finally {
      setBusy(false)
      setProjectLoading(false)
    }
  }

  const applyProject = async () => {
    if (selected === null || busy || projectPreview === null) return
    const { missing, drift } = projectPreview.summary
    if (missing === 0 && drift === 0) {
      setStatus('环境已满足项目依赖，无需变更。')
      return
    }
    if (!window.confirm(`将按项目依赖同步环境「${selected}」：安装 ${missing} 个缺失依赖，修正 ${drift} 个版本漂移。继续？`)) return
    setBusy(true)
    setResult(null)
    setStatus('正在按项目依赖同步环境…')
    try {
      const body = await api<{ result: ProcessResult, skipped: boolean }>(`/dsh-uvm/api/envs/${encodeURIComponent(selected)}/project-sync`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ project: projectPreview.projectPath }),
      })
      setResult(body.result)
      if (body.skipped) {
        setStatus('无需变更。')
      } else {
        setStatus(body.result.code === 0 ? '项目同步完成，可重新预览确认差异已消除。' : `项目同步结束（退出码 ${body.result.code}）`)
        if (body.result.code === 0) {
          setProjectPreview(null)
          if (packages !== null) void fetchPackages()
        }
      }
    } catch (error) {
      setStatus(`项目同步失败：${message(error)}`)
    } finally {
      setBusy(false)
    }
  }

  const ready = bootstrap?.ok === true
  const env = ready ? bootstrap.envs.find(item => item.name === selected) ?? null : null
  const uv = ready ? bootstrap.toolchain.uv : EMPTY_BOOTSTRAP.toolchain.uv
  const pip = ready ? bootstrap.toolchain.pip : EMPTY_BOOTSTRAP.toolchain.pip
  const conda = ready ? bootstrap.toolchain.conda : EMPTY_BOOTSTRAP.toolchain.conda
  const output = result === null ? '' : `${result.stdout}${result.stderr === '' ? '' : `\n[stderr]\n${result.stderr}`}`.trim()

  return <section className="dshUvm">
    <style>{`
      .dshUvm{--uv:#8b5cf6;--line:color-mix(in srgb,currentColor 14%,transparent);min-height:520px;padding:22px;border:1px solid var(--line);border-radius:18px;background:radial-gradient(circle at 90% 0,color-mix(in srgb,var(--uv) 12%,transparent),transparent 34%);font-family:"Aptos","Noto Sans SC",sans-serif}.dshUvm *{box-sizing:border-box}.dshUvm header{display:flex;justify-content:space-between;gap:18px;align-items:flex-start}.dshUvm h2{margin:3px 0;font-size:28px}.dshUvm p{line-height:1.6}.uvmKicker{margin:0;font:700 10px/1.2 ui-monospace,monospace;letter-spacing:.16em;color:var(--uv)}.uvmState{display:inline-flex;align-items:center;gap:7px;padding:7px 10px;border:1px solid var(--line);border-radius:999px;font-size:12px}.uvmState i{width:8px;height:8px;border-radius:50%;background:${uv.available ? 'var(--uv)' : '#d66'}}.uvmTools{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-top:18px}.uvmTool{border:1px solid var(--line);border-radius:12px;padding:12px 14px}.uvmTool b{font:700 11px/1.2 ui-monospace,monospace;letter-spacing:.12em;opacity:.75}.uvmTool p{margin:6px 0 0;font-size:13px;overflow-wrap:anywhere}.uvmTool .ok{color:var(--uv)}.uvmRoot{margin:12px 2px 0;font:11px/1.5 ui-monospace,monospace;opacity:.65;overflow-wrap:anywhere}.uvmGrid{display:grid;grid-template-columns:minmax(240px,300px) minmax(0,1fr);gap:16px;margin-top:14px}.uvmSide,.uvmDetail{border:1px solid var(--line);border-radius:14px;padding:14px}.uvmCreate label{display:block;font-size:12px;margin:8px 0 4px}.uvmCreate input,.uvmCreate select,.uvmForm input,.uvmForm select,.uvmForm textarea{width:100%;min-height:44px;border:1px solid var(--line);border-radius:9px;background:transparent;color:inherit;padding:9px 11px;font:inherit}.uvmCreate button,.uvmForm button,.uvmEnvDel,.uvmAction,.uvmRetry{min-height:44px;border:1px solid var(--line);border-radius:9px;background:transparent;color:inherit;padding:7px 11px;cursor:pointer}.uvmCreate button[type="submit"],.uvmAction.isActive,.uvmInstall{background:var(--uv);color:#160b26;border-color:transparent;font-weight:700}.uvmCreate button:disabled,.uvmForm button:disabled,.uvmAction:disabled{opacity:.45;cursor:not-allowed}.uvmEnvList{list-style:none;margin:10px 0 0;padding:0;display:flex;flex-direction:column;gap:8px}.uvmEnv{display:flex;gap:6px}.uvmEnvPick{flex:1;min-height:48px;text-align:left;border:1px solid var(--line);border-radius:9px;background:transparent;color:inherit;padding:7px 11px;cursor:pointer}.uvmEnvPick[aria-pressed="true"]{border-color:var(--uv)}.uvmEnvPick b{display:block;font-size:14px}.uvmEnvPick small{opacity:.65;font-size:12px}.uvmEnvPick em{float:right;font:700 10px/1.6 ui-monospace,monospace;font-style:normal;padding:1px 7px;border-radius:999px;background:color-mix(in srgb,var(--uv) 18%,transparent);color:var(--uv)}.uvmEnvDel{min-height:48px;font-size:12px}.uvmEnvDel:hover{color:#d66}.uvmConda{margin-top:16px;border-top:1px solid var(--line);padding-top:10px}.uvmConda small{font-size:12px;opacity:.65}.uvmConda li{font:11px/1.6 ui-monospace,monospace;overflow-wrap:anywhere}.uvmEnvHead{display:flex;align-items:baseline;gap:10px;flex-wrap:wrap;border-bottom:1px solid var(--line);padding-bottom:10px}.uvmEnvHead h3{margin:0;font-size:20px}.uvmEnvHead small{opacity:.65}.uvmEnvHead .del{margin-left:auto}.uvmActions{display:flex;gap:8px;flex-wrap:wrap;margin:12px 0}.uvmBody{min-height:220px}.uvmForm label{display:block;font-size:12px;margin:8px 0 4px}.uvmForm textarea{min-height:140px;resize:vertical;font-family:ui-monospace,monospace;font-size:12px}.uvmFormRow{display:flex;gap:8px;margin-top:10px}.uvmHint{font-size:12px;opacity:.65}.uvmPkgList{list-style:none;margin:6px 0;padding:0;display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:6px}.uvmPkgList li{border:1px solid var(--line);border-radius:8px;padding:7px 10px;font:12px/1.5 ui-monospace,monospace;overflow-wrap:anywhere}.uvmOutput{white-space:pre-wrap;overflow-wrap:anywhere;border:1px solid var(--line);border-radius:9px;padding:11px;font:12px/1.55 ui-monospace,monospace;max-height:280px;overflow:auto;margin-top:10px}.uvmStatus{min-height:20px;font-size:12px}.uvmStatus{margin-top:10px}@media (prefers-reduced-motion: reduce){.dshUvm *{transition:none!important;animation:none!important}}@media (max-width:760px){.uvmGrid{grid-template-columns:minmax(0,1fr)}.uvmTools{grid-template-columns:minmax(0,1fr)}}
    `}</style>
    <style>{`
      .uvmProjList{list-style:none;margin:10px 0 0;padding:0;display:grid;gap:6px;max-height:280px;overflow:auto}
      .uvmProjList li{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:10px;align-items:center;border:1px solid var(--line);border-radius:9px;padding:8px 10px;font-size:13px}
      .uvmProjList b{font-family:ui-monospace,monospace}
      .uvmProjList li[data-status="missing"] b{color:#d66}
      .uvmProjList li[data-status="drift"] b{color:#d99}
      .uvmProjList li[data-status="installed"] b{color:var(--uv)}
      .uvmProjList code{overflow-wrap:anywhere}
      .uvmProjList small{opacity:.75;overflow-wrap:anywhere}
      .uvmProjResult{margin-top:12px}
      .uvmProjResult code{font-family:ui-monospace,monospace;font-size:12px}
    `}</style>
    <header>
      <div>
        <p className="uvmKicker">DSH / UV ENVIRONMENT MANAGER</p>
        <h2>uv 环境管理</h2>
        <p>以 uv 为主管理器创建、安装、同步与运行 Python 虚拟环境；无 uv 时回退 pip，conda 环境只读可见。</p>
      </div>
      <span className="uvmState"><i />{uv.available ? `${uv.version ?? 'uv'} · 本机` : '未检测到 uv'}</span>
    </header>
    {!ready
      ? <p className="uvmHint">{bootstrap?.error ?? '无法连接本地环境桥。'}<button type="button" className="uvmRetry" onClick={() => void refresh()}>重试</button></p>
      : <>
        <div className="uvmTools">
          <div className="uvmTool"><b>UV</b><p className={uv.available ? 'ok' : ''}>{uv.available ? uv.version : '未检测到'}</p></div>
          <div className="uvmTool"><b>PIP 回退</b><p className={pip.available ? 'ok' : ''}>{pip.available ? pip.pipVersion : '未检测到'}</p></div>
          <div className="uvmTool"><b>CONDA 只读</b><p className={conda.available ? 'ok' : ''}>{conda.available ? conda.version : '未检测到'}</p></div>
        </div>
        <p className="uvmRoot">环境根目录：{bootstrap.envRoot}</p>
        <div className="uvmGrid">
          <aside className="uvmSide">
            <form className="uvmCreate" onSubmit={event => void create(event)}>
              <b>创建环境</b>
              <label htmlFor="uvmName">名称（字母数字开头，≤64 字符）</label>
              <input id="uvmName" value={nameInput} maxLength={64} pattern="[A-Za-z0-9][A-Za-z0-9._-]*" placeholder="my-project" onChange={(event: ChangeEvent<HTMLInputElement>) => setNameInput(event.target.value)} />
              <label htmlFor="uvmPython">Python 版本</label>
              <select id="uvmPython" value={pythonInput} onChange={(event: ChangeEvent<HTMLSelectElement>) => setPythonInput(event.target.value)}>
                <option value="">默认（uv 自选）</option>
                {bootstrap.pythons.map(version => <option key={version} value={version}>{version}</option>)}
              </select>
              <p><button type="submit" disabled={busy || nameInput.trim() === ''}>{busy ? '创建中…' : '创建环境'}</button></p>
            </form>
            <div className="uvmEnvList" role="list">
              <b>已管理环境（{bootstrap.envs.length}）</b>
              {bootstrap.envs.map(item => (
                <div className="uvmEnv" role="listitem" key={item.name}>
                  <button type="button" className="uvmEnvPick" aria-pressed={selected === item.name} onClick={() => { setSelected(item.name); setMode(null); setPackages(null); setResult(null); setStatus('') }}>
                    <em>{item.source === 'uv' ? 'uv' : 'pip'}</em><b>{item.name}</b><small>python {item.python ?? '未知'}</small>
                  </button>
                  <button type="button" className="uvmEnvDel" aria-label={`删除环境 ${item.name}`} disabled={busy} onClick={() => void remove(item.name)}>删除</button>
                </div>
              ))}
              {bootstrap.envs.length === 0 && <p className="uvmHint">还没有托管环境，先在上方创建一个。</p>}
            </div>
            <div className="uvmConda">
              <small>conda 环境（只读，不参与管理）{conda.available ? '' : '· 未安装 conda'}</small>
              <ul>{bootstrap.condaEnvs.map(item => <li key={item.path}>{item.name}</li>)}</ul>
            </div>
          </aside>
          <main className="uvmDetail">
            {env === null
              ? <p className="uvmHint">在左侧选择或创建一个环境，即可查看包、安装依赖、按 requirements 同步、或运行 python / pip 命令。所有操作都在本机环境根目录内完成。</p>
              : <>
                <div className="uvmEnvHead">
                  <h3>{env.name}</h3>
                  <small>python {env.python ?? '未知'} · {env.source === 'uv' ? 'uv 创建' : 'pip 创建'}</small>
                  <button type="button" className="uvmEnvDel del" disabled={busy} onClick={() => void remove(env.name)}>删除环境</button>
                </div>
                <div className="uvmActions">
                  <button type="button" className={`uvmAction${mode === 'packages' ? ' isActive' : ''}`} onClick={() => void loadPackages()}>包列表</button>
                  <button type="button" className={`uvmAction${mode === 'install' ? ' isActive' : ''}`} onClick={() => { setMode('install'); setResult(null) }}>安装 / 卸载</button>
                  <button type="button" className={`uvmAction${mode === 'sync' ? ' isActive' : ''}`} onClick={() => { setMode('sync'); setResult(null) }}>同步</button>
                  <button type="button" className={`uvmAction${mode === 'run' ? ' isActive' : ''}`} onClick={() => { setMode('run'); setResult(null) }}>运行</button>
                  <button type="button" className={`uvmAction${mode === 'project' ? ' isActive' : ''}`} onClick={() => { setMode('project'); setResult(null); setProjectPreview(null) }}>项目同步</button>
                </div>
                <div className="uvmBody">
                  {mode === 'packages' && (
                    packagesLoading
                      ? <p className="uvmHint">正在读取已安装包…</p>
                      : <>
                        <p className="uvmHint">{packages?.length ?? 0} 个已安装包</p>
                        <ul className="uvmPkgList">{(packages ?? []).map(item => <li key={item}>{item}</li>)}</ul>
                        {packages !== null && packages.length === 0 && <p className="uvmHint">环境还是空的。</p>}
                      </>
                  )}
                  {mode === 'install' && <div className="uvmForm">
                    <label htmlFor="uvmInstall">包规格（空格或逗号分隔，如 requests numpy&gt;=2.0）</label>
                    <input id="uvmInstall" value={installInput} maxLength={2000} placeholder="requests numpy>=2.0" onChange={(event: ChangeEvent<HTMLInputElement>) => setInstallInput(event.target.value)} />
                    <div className="uvmFormRow">
                      <button type="button" className="uvmInstall" disabled={busy || installInput.trim() === ''} onClick={() => void installOrUninstall('install')}>安装</button>
                      <button type="button" disabled={busy || installInput.trim() === ''} onClick={() => void installOrUninstall('uninstall')}>卸载</button>
                    </div>
                  </div>}
                  {mode === 'sync' && <div className="uvmForm">
                    <label htmlFor="uvmSync">requirements 内容（写入环境，等价于 uv pip install -r -）</label>
                    <textarea id="uvmSync" value={requirementsInput} maxLength={256 * 1024} placeholder={'requests>=2.0\nnumpy'} onChange={(event: ChangeEvent<HTMLTextAreaElement>) => setRequirementsInput(event.target.value)} />
                    <div className="uvmFormRow"><button type="button" className="uvmInstall" disabled={busy || requirementsInput.trim() === ''} onClick={() => void sync()}>同步环境</button></div>
                  </div>}
                  {mode === 'run' && <div className="uvmForm">
                    <label htmlFor="uvmRunCmd">命令</label>
                    <select id="uvmRunCmd" value={runCommand} onChange={(event: ChangeEvent<HTMLSelectElement>) => setRunCommand(event.target.value === 'pip' ? 'pip' : 'python')}>
                      <option value="python">python（环境内解释器）</option>
                      <option value="pip">pip（python -m pip）</option>
                    </select>
                    <label htmlFor="uvmRunArgs">参数（空格分隔，如 -m http.server 8000）</label>
                    <input id="uvmRunArgs" value={runArgs} maxLength={2000} placeholder="-V" onChange={(event: ChangeEvent<HTMLInputElement>) => setRunArgs(event.target.value)} />
                    <div className="uvmFormRow"><button type="button" className="uvmInstall" disabled={busy} onClick={() => void run()}>运行（60 秒超时）</button></div>
                    <p className="uvmHint">输出上限 512 KB；只在本机环境内执行，不经过任何远程服务。</p>
                  </div>}
                  {mode === 'project' && <div className="uvmForm uvmProj">
                    <label htmlFor="uvmProject">本地项目路径（读取 pyproject.toml / uv.lock，仅本机解析，不上传）</label>
                    <input id="uvmProject" value={projectInput} maxLength={512} placeholder="/Users/me/projects/demo" onChange={(event: ChangeEvent<HTMLInputElement>) => { setProjectInput(event.target.value); setProjectPreview(null) }} />
                    <div className="uvmFormRow">
                      <button type="button" className="uvmInstall" disabled={busy || projectInput.trim() === ''} onClick={() => void previewProject()}>{projectLoading ? '解析中…' : '预览差异'}</button>
                      <button type="button" disabled={busy || projectPreview === null || (projectPreview.summary.missing === 0 && projectPreview.summary.drift === 0)} onClick={() => void applyProject()}>应用同步</button>
                    </div>
                    {projectPreview !== null && <div className="uvmProjResult">
                      <p className="uvmHint">
                        <code>{projectPreview.projectPath}</code>
                        {' · '}{projectPreview.pyproject ? 'pyproject.toml ✓' : '✗'}{' · '}{projectPreview.lockfile ? 'uv.lock ✓' : '无 uv.lock'}
                        {projectPreview.requiresPython !== null && <> · requires-python {projectPreview.requiresPython}</>}
                      </p>
                      <p className="uvmHint">依赖 {projectPreview.summary.total} 个：已满足 {projectPreview.summary.installed} · 缺失 {projectPreview.summary.missing} · 版本漂移 {projectPreview.summary.drift}</p>
                      <ul className="uvmProjList">
                        {projectPreview.dependencies.map(item => (
                          <li key={item.name} data-status={item.status}>
                            <b>{item.status === 'installed' ? '✓' : item.status === 'missing' ? '＋' : '≅'}</b>
                            <code>{item.spec}</code>
                            <small>{item.installed ?? '未安装'}{item.locked !== null && item.locked !== item.installed ? ` · 锁定 ${item.locked}` : ''}</small>
                          </li>
                        ))}
                      </ul>
                      <p className="uvmHint">预览只读取依赖声明并与环境已装包比对，不访问网络；应用同步把缺失/漂移的依赖规格经 stdin 交给 uv pip install（无 uv 时回退 pip）。</p>
                    </div>}
                  </div>}
                  {result !== null && <pre className="uvmOutput">{output === '' ? '（无输出）' : output}</pre>}
                </div>
                <p className="uvmStatus" role="status">{status}</p>
              </>}
          </main>
        </div>
      </>}
  </section>
}

export function apply(ctx: ClientContext): void {
  ctx.slots.inject('settings.plugins.tab', () => ctx.slots.register({ name: 'settings.plugins.tab', id: 'dsh-uvm', order: 40, label: () => 'uv 环境' }, UvmPanel))
}
