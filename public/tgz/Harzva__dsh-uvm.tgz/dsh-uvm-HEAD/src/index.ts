import type { IncomingMessage, ServerResponse } from 'node:http'
import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-host-webserver'
import {
  applyProjectSync,
  createEnv,
  detectToolchain,
  freezePackages,
  installPackages,
  listCondaEnvs,
  listManagedEnvs,
  listPythonVersions,
  normalizeEnvRoot,
  previewProjectSync,
  removeEnv,
  runInEnv,
  syncRequirements,
  uninstallPackages,
  validateCreateInput,
  validateEnvName,
  validatePackageSpecs,
  validateRequirements,
  validateRunInput,
  type Toolchain,
} from './uvm-adapter.js'

export const inject = ['webServer']

export interface Config {
  envRoot?: string
  uvPath?: string
  pythonPath?: string
}

const API_PATH = '/dsh-uvm/api'
const MAX_BODY_BYTES = 300 * 1024

const SPAWN_ERRORS = new Set([
  'invalid-env-name',
  'invalid-create-input',
  'invalid-python-version',
  'invalid-packages',
  'invalid-requirements',
  'requirements-too-large',
  'invalid-run-input',
  'invalid-run-command',
  'invalid-run-args',
  'env-path-escape',
  'env-not-found',
  'no-python-toolchain',
  'uv-create-failed',
  'venv-create-failed',
  'env-create-verify-failed',
  'freeze-failed',
  'invalid-project-path',
  'project-toml-not-found',
  'project-toml-too-large',
  'project-no-dependencies',
  'project-dependencies-unsupported',
  'project-deps-too-many',
])

function json(res: ServerResponse, status: number, body: unknown): void {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' })
  res.end(JSON.stringify(body))
}

function isLoopback(req: IncomingMessage): boolean {
  const address = req.socket.remoteAddress ?? ''
  return address === '127.0.0.1' || address === '::1' || address === '::ffff:127.0.0.1'
}

function sameOrigin(req: IncomingMessage): boolean {
  const origin = req.headers.origin
  const host = req.headers.host
  if (origin === undefined) return true
  if (host === undefined) return false
  try { return new URL(origin).host === host } catch { return false }
}

async function readJson(req: IncomingMessage): Promise<unknown> {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    const buffer = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
    size += buffer.byteLength
    if (size > MAX_BODY_BYTES) throw new Error('invalid-request-too-large')
    chunks.push(buffer)
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8')) as unknown
}

function safeError(error: unknown): string {
  if (!(error instanceof Error)) return 'uvm-unavailable'
  const message = error.message
  if (SPAWN_ERRORS.has(message)) return message
  if (/^invalid-/.test(message)) return message
  return 'uvm-unavailable'
}

export function apply(ctx: Context, config: Config = {}): void {
  const root = normalizeEnvRoot(config.envRoot)
  const toolchainPromise: Promise<Toolchain> = detectToolchain({ uvPath: config.uvPath, pythonPath: config.pythonPath })

  const handler = async (req: IncomingMessage, res: ServerResponse): Promise<void> => {
    const pathname = new URL(req.url ?? '/', 'http://local').pathname
    if (pathname !== API_PATH && !pathname.startsWith(`${API_PATH}/`)) {
      json(res, 404, { ok: false, error: 'not-found' })
      return
    }
    if (!isLoopback(req) || !sameOrigin(req)) {
      json(res, 403, { ok: false, error: 'local-same-origin-required' })
      return
    }

    const toolchain = await toolchainPromise

    if (pathname === `${API_PATH}/bootstrap` && req.method === 'GET') {
      try {
        const [pythons, envs, condaEnvs] = await Promise.all([
          listPythonVersions(toolchain),
          listManagedEnvs(root),
          listCondaEnvs(toolchain),
        ])
        json(res, 200, { ok: true, envRoot: root, toolchain, pythons, envs, condaEnvs })
      } catch (error) {
        json(res, 503, { ok: false, error: safeError(error) })
      }
      return
    }

    if (pathname === `${API_PATH}/envs` && req.method === 'POST') {
      try {
        const env = await createEnv({ root, ...validateCreateInput(await readJson(req)), toolchain })
        json(res, 201, { ok: true, env })
      } catch (error) {
        const message = safeError(error)
        json(res, message === 'no-python-toolchain' || message === 'uv-create-failed' || message === 'venv-create-failed' ? 502 : 400, { ok: false, error: message })
      }
      return
    }

    const envMatch = /^\/dsh-uvm\/api\/envs\/([^/]+)(?:\/(packages|install|uninstall|sync|run|project-preview|project-sync))?$/.exec(pathname)
    if (envMatch === null || envMatch[1] === undefined) {
      json(res, 404, { ok: false, error: 'not-found' })
      return
    }

    let name: string
    try {
      name = validateEnvName(decodeURIComponent(envMatch[1]))
    } catch {
      json(res, 400, { ok: false, error: 'invalid-env-name' })
      return
    }
    const action = envMatch[2]

    try {
      const envs = await listManagedEnvs(root)
      const env = envs.find(item => item.name === name)

      if (action === undefined && req.method === 'DELETE') {
        if (env === undefined) {
          json(res, 404, { ok: false, error: 'env-not-found' })
          return
        }
        await removeEnv(root, name)
        json(res, 200, { ok: true, removed: name })
        return
      }

      if (env === undefined) {
        json(res, 404, { ok: false, error: 'env-not-found' })
        return
      }

      if (action === 'packages' && req.method === 'GET') {
        json(res, 200, { ok: true, packages: await freezePackages(env, toolchain) })
        return
      }
      if ((action === 'install' || action === 'uninstall') && req.method === 'POST') {
        const packages = validatePackageSpecs((await readJson(req) as Record<string, unknown>).packages)
        const result = action === 'install' ? await installPackages(env, packages, toolchain) : await uninstallPackages(env, packages, toolchain)
        json(res, 200, { ok: result.code === 0, result })
        return
      }
      if (action === 'sync' && req.method === 'POST') {
        const requirements = validateRequirements((await readJson(req) as Record<string, unknown>).requirements)
        const result = await syncRequirements(env, requirements, toolchain)
        json(res, 200, { ok: result.code === 0, result })
        return
      }
      if (action === 'project-preview' && req.method === 'POST') {
        const project = (await readJson(req) as Record<string, unknown>).project
        const preview = await previewProjectSync(env, project, toolchain)
        json(res, 200, { ok: true, preview })
        return
      }
      if (action === 'project-sync' && req.method === 'POST') {
        const project = (await readJson(req) as Record<string, unknown>).project
        const outcome = await applyProjectSync(env, project, toolchain)
        json(res, 200, { ok: outcome.result.code === 0, result: outcome.result, skipped: outcome.skipped })
        return
      }
      if (action === 'run' && req.method === 'POST') {
        const input = validateRunInput(await readJson(req))
        const result = await runInEnv(env, input.command, input.args, toolchain)
        json(res, 200, { ok: true, result })
        return
      }
      json(res, 404, { ok: false, error: 'not-found' })
    } catch (error) {
      const message = safeError(error)
      json(res, message === 'env-not-found' ? 404 : message.includes('invalid-') || message === 'requirements-too-large' || message.startsWith('project-') ? 400 : 502, { ok: false, error: message })
    }
  }

  ctx.effect(
    () => ctx.webServer.register({ kind: 'prefix', path: API_PATH, handler }),
    'dsh-uvm: local uv environment bridge',
  )
}
