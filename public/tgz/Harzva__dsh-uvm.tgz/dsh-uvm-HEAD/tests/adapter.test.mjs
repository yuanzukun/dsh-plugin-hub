import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, mkdir, readFile, writeFile, chmod, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { delimiter, join, sep } from 'node:path'
import {
  applyProjectSync, createEnv, detectToolchain, findOnPath, freezePackages, installPackages,
  listCondaEnvs, listManagedEnvs, listPythonVersions, normalizeEnvRoot, normalizePackageName,
  parseLockVersions, parseProjectManifest, previewProjectSync, removeEnv, resolveEnvPath,
  runInEnv, runProcess, validateCreateInput, validateEnvName, validatePackageSpecs,
  validateProjectPath, validateRunInput, DEFAULT_ENV_ROOT,
} from '../lib/uvm-adapter.js'

async function writeScript(dir, name, body) {
  const path = join(dir, name)
  await writeFile(path, `#!/bin/sh\n${body}\n`)
  await chmod(path, 0o755)
  return path
}

async function makeFakeToolchain() {
  const bin = await mkdtemp(join(tmpdir(), 'uvm-fake-bin-'))
  const uv = await writeScript(bin, 'uv', `
if [ "$1" = "--version" ]; then
  echo "uv 0.9.9 (fake)"
  exit 0
fi
if [ "$1" = "python" ] && [ "$2" = "list" ]; then
  echo "cpython-3.12.1-macos-aarch64-none  /fake/python3.12"
  echo "cpython-3.11.8-macos-aarch64-none  /fake/python3.11"
  exit 0
fi
if [ "$1" = "pip" ] && [ "$2" = "freeze" ]; then
  echo "six==1.17.0"
  echo "# editable install"
  echo "requests==2.32.0"
  exit 0
fi
if [ "$1" = "venv" ]; then
  target="$2"
  mkdir -p "$target"
  printf 'home = /fake\\nversion = 3.12.1\\nuv = 0.9.9\\n' > "$target/pyvenv.cfg"
  exit 0
fi
if [ "$1" = "pip" ] && [ "$2" = "install" ]; then
  echo "Installed fake packages"
  exit 0
fi
echo "fake uv: unknown command $1" >&2
exit 2`)
  await writeScript(bin, 'python3', `
if [ "$1" = "-m" ] && [ "$2" = "pip" ]; then
  shift 2
  if [ "$1" = "--version" ]; then echo "pip 25.1 from /fake (python 3.12)"; exit 0; fi
  if [ "$1" = "freeze" ]; then echo "six==1.17.0"; exit 0; fi
  echo "pip done"
  exit 0
fi
echo "Python 3.12.1"
exit 0`)
  await writeScript(bin, 'conda', `
if [ "$1" = "--version" ]; then echo "conda 24.5.0"; exit 0; fi
if [ "$1" = "env" ] && [ "$2" = "list" ]; then echo '{"envs":["/opt/conda/envs/base"]}'; exit 0; fi
exit 2`)
  await writeScript(bin, 'sleeper', 'exec sleep 30')
  return bin
}

test('env name and package spec validation rejects traversal and shell characters', () => {
  assert.equal(validateEnvName('my-env_1'), 'my-env_1')
  for (const bad of ['', '..', '../x', 'a/b', '.hidden', '-lead', 'a'.repeat(65), 'a b']) assert.throws(() => validateEnvName(bad), /invalid-env-name/)
  assert.deepEqual(validatePackageSpecs(['requests', 'numpy>=2.0', 'six==1.17.0']), ['requests', 'numpy>=2.0', 'six==1.17.0'])
  for (const bad of [[], ['-e .'], ['a;rm'], ['a b'], ['`id`'], ['a$(id)'], ['--help']]) assert.throws(() => validatePackageSpecs(bad), /invalid-package/)
  assert.deepEqual(validateCreateInput({ name: 'demo', python: '3.12' }), { name: 'demo', python: '3.12' })
  assert.throws(() => validateCreateInput({ name: 'demo', python: '3.12; rm' }), /invalid-python-version/)
  assert.throws(() => validateCreateInput({ name: 'demo', extra: true }), /invalid-create-input/)
  assert.deepEqual(validateRunInput({ command: 'python', args: ['-m', 'http.server'] }), { command: 'python', args: ['-m', 'http.server'] })
  assert.throws(() => validateRunInput({ command: 'sh', args: [] }), /invalid-run-command/)
  assert.throws(() => validateRunInput({ command: 'python', args: ['x\u0000y'] }), /invalid-run-arg/)
})

test('env root resolution is contained and defaults under the user home', async () => {
  assert.equal(normalizeEnvRoot(undefined), DEFAULT_ENV_ROOT)
  assert.equal(resolveEnvPath('/tmp/uvm-root', 'demo'), join(sep, 'tmp', 'uvm-root', 'demo'))
  assert.throws(() => resolveEnvPath('/tmp/uvm-root', '../x'), /invalid-env-name/)
  assert.throws(() => resolveEnvPath('/tmp/uvm-root', 'a/b'), /invalid-env-name/)
})

test('fake toolchain is detected and inventoried without real uv', async () => {
  const bin = await makeFakeToolchain()
  const savedPath = process.env.PATH
  process.env.PATH = `${bin}${delimiter}${savedPath ?? ''}`
  try {
    const toolchain = await detectToolchain()
    assert.equal(toolchain.uv.available, true)
    assert.equal(toolchain.uv.version, 'uv 0.9.9 (fake)')
    assert.equal(toolchain.pip.available, true)
    assert.match(toolchain.pip.pipVersion ?? '', /^pip 25\.1/)
    assert.equal(toolchain.conda.available, true)
    assert.deepEqual(await listPythonVersions(toolchain), ['3.12.1', '3.11.8'])
    assert.deepEqual(await listCondaEnvs(toolchain), [{ name: 'base', path: '/opt/conda/envs/base' }])
    assert.equal(findOnPath('uv'), join(bin, 'uv'))
  } finally {
    process.env.PATH = savedPath
    await rm(bin, { recursive: true, force: true })
  }
})

test('managed env listing reads pyvenv.cfg and marks the uv source', async () => {
  const root = await mkdtemp(join(tmpdir(), 'uvm-root-'))
  try {
    await mkdir(join(root, 'alpha'))
    await writeFile(join(root, 'alpha', 'pyvenv.cfg'), 'home = /opt/python\nversion = 3.12.1\nuv = 0.9.9\n')
    await mkdir(join(root, 'beta'))
    await writeFile(join(root, 'beta', 'pyvenv.cfg'), 'home = /opt/python\nversion = 3.11.8\n')
    await mkdir(join(root, 'not-an-env'))
    const envs = await listManagedEnvs(root)
    assert.deepEqual(envs.map(env => env.name), ['alpha', 'beta'])
    assert.equal(envs[0].source, 'uv')
    assert.equal(envs[0].python, '3.12.1')
    assert.equal(envs[1].source, 'pip')
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('create, install, freeze, run, and remove flow against the fake toolchain', async () => {
  const bin = await makeFakeToolchain()
  const root = await mkdtemp(join(tmpdir(), 'uvm-flow-'))
  const savedPath = process.env.PATH
  process.env.PATH = `${bin}${delimiter}${savedPath ?? ''}`
  try {
    const toolchain = await detectToolchain()
    const env = await createEnv({ root, name: 'demo', python: '3.12', toolchain })
    assert.equal(env.name, 'demo')
    assert.equal(env.source, 'uv')
    assert.equal(env.python, '3.12.1')
    const install = await installPackages(env, ['requests', 'numpy>=2.0'], toolchain)
    assert.equal(install.code, 0)
    assert.deepEqual(await freezePackages(env, toolchain), ['six==1.17.0', 'requests==2.32.0'])
    const run = await runInEnv(env, 'python', ['-V'], toolchain)
    assert.equal(run.timedOut, false)
    await removeEnv(root, 'demo')
    assert.deepEqual(await listManagedEnvs(root), [])
    await assert.rejects(removeEnv(root, 'missing'), /env-not-found/)
  } finally {
    process.env.PATH = savedPath
    await rm(bin, { recursive: true, force: true })
    await rm(root, { recursive: true, force: true })
  }
})

test('runProcess enforces the timeout and reports timedOut', async () => {
  const bin = await makeFakeToolchain()
  try {
    const result = await runProcess(join(bin, 'sleeper'), [], { timeoutMs: 400 })
    assert.equal(result.timedOut, true)
    const missing = await runProcess(join(bin, 'does-not-exist'), [])
    assert.equal(missing.code, 127)
    assert.equal(missing.stderr, 'tool-not-found')
  } finally {
    await rm(bin, { recursive: true, force: true })
  }
})

test('real uv smoke: create, install, freeze, run, remove (skips when uv is absent)', async () => {
  if (findOnPath('uv') === null) return
  const toolchain = await detectToolchain()
  assert.equal(toolchain.uv.available, true)
  const root = await mkdtemp(join(tmpdir(), 'uvm-real-'))
  try {
    const env = await createEnv({ root, name: 'smoke', toolchain })
    assert.equal(env.source, 'uv')
    const install = await installPackages(env, ['six'], toolchain)
    assert.equal(install.code, 0, install.stderr)
    const frozen = await freezePackages(env, toolchain)
    assert.ok(frozen.some(line => line.startsWith('six==')))
    const run = await runInEnv(env, 'python', ['-V'], toolchain)
    assert.equal(run.code, 0)
    assert.match(run.stdout, /Python 3\.\d+/)
    await removeEnv(root, 'smoke')
    assert.deepEqual(await listManagedEnvs(root), [])
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('uvm-adapter keeps the raw pyvenv.cfg content private to the host process', async () => {
  const root = await mkdtemp(join(tmpdir(), 'uvm-cfg-'))
  try {
    await mkdir(join(root, 'env'))
    await writeFile(join(root, 'env', 'pyvenv.cfg'), 'home = /secret/home\nversion = 3.12.1\n')
    const envs = await listManagedEnvs(root)
    assert.equal(envs[0].python, '3.12.1')
    assert.equal(JSON.stringify(envs).includes('/secret/home'), false)
    const raw = await readFile(join(root, 'env', 'pyvenv.cfg'), 'utf8')
    assert.match(raw, /secret/)
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('pyproject manifest parser reads flat dependency arrays and requires-python', () => {
  const manifest = parseProjectManifest(`
[project]
name = "demo"
version = "0.1.0"
requires-python = ">=3.9"
dependencies = [
  "requests>=2.0", # runtime
  'six==1.17.0',
  "typing-extensions ; python_version < '3.11'",
]
`)
  assert.equal(manifest.requiresPython, '>=3.9')
  assert.equal(manifest.unparsed, false)
  assert.deepEqual(manifest.dependencies, ['requests>=2.0', 'six==1.17.0', "typing-extensions ; python_version < '3.11'"])

  const withMarkers = parseProjectManifest('[project]\ndependencies = ["flask",]\n')
  assert.deepEqual(withMarkers.dependencies, ['flask'])

  const nested = parseProjectManifest('[project]\ndependencies = [{ include = "x" }]\n')
  assert.equal(nested.unparsed, true)
  const noDeps = parseProjectManifest('[project]\nname = "demo"\n')
  assert.deepEqual(noDeps.dependencies, [])
  const otherSection = parseProjectManifest('[tool.uv]\nx = 1\n')
  assert.deepEqual(otherSection.dependencies, [])
})

test('uv.lock parser extracts first name-to-version mapping per package', () => {
  const versions = parseLockVersions(`
version = 1
revision = 1

[[package]]
name = "six"
version = "1.17.0"
source = { registry = "https://pypi.org/simple" }

[[package]]
name = "requests"
version = "2.31.0"
`)
  assert.equal(versions.get('six'), '1.17.0')
  assert.equal(versions.get('requests'), '2.31.0')
  assert.equal(normalizePackageName('Flask-Cors'), 'flask-cors')
  assert.equal(normalizePackageName('zope.interface'), 'zope-interface')
})

test('project path validation requires an absolute, control-character-free path', () => {
  assert.equal(validateProjectPath('/Users/demo/project'), '/Users/demo/project')
  for (const bad of ['', '   ', 'relative/path', '/x\u0000y', '/x'.repeat(300)]) {
    assert.throws(() => validateProjectPath(bad), /invalid-project-path/)
  }
})

test('project sync preview diffs declared deps against the env freeze without a resolver', async () => {
  const bin = await makeFakeToolchain()
  const root = await mkdtemp(join(tmpdir(), 'uvm-proj-'))
  const savedPath = process.env.PATH
  process.env.PATH = `${bin}${delimiter}${savedPath ?? ''}`
  try {
    const toolchain = await detectToolchain()
    const project = await mkdtemp(join(root, 'proj-'))
    await writeFile(join(project, 'pyproject.toml'), [
      '[project]',
      'name = "demo-proj"',
      'version = "0.1.0"',
      'requires-python = ">=3.9"',
      'dependencies = ["six==1.17.0", "requests>=2.0", "flask"]',
      '',
    ].join('\n'))
    await writeFile(join(project, 'uv.lock'), [
      'version = 1',
      '[[package]]',
      'name = "requests"',
      'version = "2.31.0"',
      '',
    ].join('\n'))
    const env = { name: 'demo', path: join(root, 'demo'), python: '3.12.1', source: 'uv' }
    const preview = await previewProjectSync(env, project, toolchain)
    assert.equal(preview.pyproject, true)
    assert.equal(preview.lockfile, true)
    assert.equal(preview.requiresPython, '>=3.9')
    assert.deepEqual(preview.summary, { total: 3, installed: 1, missing: 1, drift: 1 })
    const six = preview.dependencies.find(item => item.name === 'six')
    assert.equal(six.status, 'installed')
    assert.equal(six.installed, '1.17.0')
    const requests = preview.dependencies.find(item => item.name === 'requests')
    assert.equal(requests.status, 'drift')
    assert.equal(requests.locked, '2.31.0')
    assert.equal(requests.installed, '2.32.0')
    const flask = preview.dependencies.find(item => item.name === 'flask')
    assert.equal(flask.status, 'missing')
    assert.equal(flask.installed, null)
  } finally {
    process.env.PATH = savedPath
    await rm(bin, { recursive: true, force: true })
    await rm(root, { recursive: true, force: true })
  }
})

test('project sync preview fails cleanly on missing or unsupported projects', async () => {
  const bin = await makeFakeToolchain()
  const root = await mkdtemp(join(tmpdir(), 'uvm-projerr-'))
  const savedPath = process.env.PATH
  process.env.PATH = `${bin}${delimiter}${savedPath ?? ''}`
  try {
    const toolchain = await detectToolchain()
    const env = { name: 'demo', path: join(root, 'demo'), python: '3.12.1', source: 'uv' }
    const empty = await mkdtemp(join(root, 'empty-'))
    await assert.rejects(previewProjectSync(env, empty, toolchain), /project-toml-not-found/)
    const noDeps = await mkdtemp(join(root, 'nodeps-'))
    await writeFile(join(noDeps, 'pyproject.toml'), '[project]\nname = "x"\n')
    await assert.rejects(previewProjectSync(env, noDeps, toolchain), /project-no-dependencies/)
    const fancy = await mkdtemp(join(root, 'fancy-'))
    await writeFile(join(fancy, 'pyproject.toml'), '[project]\ndependencies = [{ include = "x" }]\n')
    await assert.rejects(previewProjectSync(env, fancy, toolchain), /project-dependencies-unsupported/)
    await assert.rejects(previewProjectSync(env, 'relative', toolchain), /invalid-project-path/)
  } finally {
    process.env.PATH = savedPath
    await rm(bin, { recursive: true, force: true })
    await rm(root, { recursive: true, force: true })
  }
})

test('project sync apply skips a satisfied env and installs only what is missing', async () => {
  const bin = await makeFakeToolchain()
  const root = await mkdtemp(join(tmpdir(), 'uvm-apply-'))
  const savedPath = process.env.PATH
  process.env.PATH = `${bin}${delimiter}${savedPath ?? ''}`
  try {
    const toolchain = await detectToolchain()
    const env = { name: 'demo', path: join(root, 'demo'), python: '3.12.1', source: 'uv' }
    const satisfied = await mkdtemp(join(root, 'sat-'))
    await writeFile(join(satisfied, 'pyproject.toml'), '[project]\ndependencies = ["six==1.17.0"]\n')
    const skipped = await applyProjectSync(env, satisfied, toolchain)
    assert.equal(skipped.skipped, true)
    assert.equal(skipped.result.code, 0)
    assert.equal(skipped.result.stdout, '')

    const needsInstall = await mkdtemp(join(root, 'need-'))
    await writeFile(join(needsInstall, 'pyproject.toml'), '[project]\ndependencies = ["six==1.17.0", "flask"]\n')
    const applied = await applyProjectSync(env, needsInstall, toolchain)
    assert.equal(applied.skipped, false)
    assert.equal(applied.result.code, 0)
    assert.match(applied.result.stdout, /Installed fake packages/)
  } finally {
    process.env.PATH = savedPath
    await rm(bin, { recursive: true, force: true })
    await rm(root, { recursive: true, force: true })
  }
})

