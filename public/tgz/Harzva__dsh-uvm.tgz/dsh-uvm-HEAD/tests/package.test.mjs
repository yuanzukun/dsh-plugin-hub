import test from 'node:test'
import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'

test('package is a native DSH bundle with a cordis patch and no vendor trees', async () => {
  const pkg = JSON.parse(await readFile('package.json', 'utf8'))
  assert.equal(pkg.name, '@harness-flow/dsh-uvm')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.ok(pkg.keywords.includes('dsh'))
  assert.ok(pkg.keywords.includes('uv'))
  assert.ok(pkg.files.includes('cordis.patch.yml'))
  assert.ok(pkg.files.includes('README.md'))
  assert.ok(pkg.files.includes('LICENSE'))
  assert.equal(pkg.files.some(path => path.includes('vendor-') || path.includes('reference')), false)
  assert.equal(pkg.dsh.client.platform, 'web')
  assert.deepEqual(pkg.dsh.client.inject, ['@deepseek-ai/dsh-client-runtime', '@deepseek-ai/dsh-client-ui-settings'])
  assert.equal(pkg.repository?.url, 'git+https://github.com/Harzva/dsh-uvm.git')
})

test('host plugin guards every route with loopback and same-origin checks', async () => {
  const source = await readFile('src/index.ts', 'utf8')
  assert.match(source, /isLoopback/)
  assert.match(source, /sameOrigin/)
  assert.match(source, /local-same-origin-required/)
  assert.match(source, /register\(\{ kind: 'prefix'/)
  assert.match(source, /const API_PATH = '\/dsh-uvm\/api'/)
  assert.match(source, /bootstrap/)
  assert.match(source, /envs/)
  assert.match(source, /project-preview/)
  assert.match(source, /project-sync/)
  assert.doesNotMatch(source, /from 'node:child_process'|execSync|spawnSync/)
})

test('client uses the official additive DSH settings slot and only same-origin APIs', async () => {
  const source = await readFile('src/client.tsx', 'utf8')
  assert.match(source, /settings\.plugins\.tab/)
  assert.match(source, /\/dsh-uvm\/api\/bootstrap/)
  assert.match(source, /\/dsh-uvm\/api\/envs/)
  assert.match(source, /project-preview/)
  assert.match(source, /project-sync/)
  assert.match(source, /min-height:44px/)
  assert.match(source, /aria-pressed=/)
  assert.match(source, /role="status"/)
  assert.match(source, /prefers-reduced-motion/)
  assert.match(source, /window\.confirm/)
  assert.doesNotMatch(source, /fetch\(['"]https?:|window\.open|iframe|eval\(/i)
})

test('cordis patch inserts one loader row that only needs the web server', async () => {
  const patch = await readFile('cordis.patch.yml', 'utf8')
  assert.match(patch, /id: dsh-uvm/)
  assert.match(patch, /name: '@harness-flow\/dsh-uvm'/)
  assert.match(patch, /inject: \[webServer\]/)
  assert.match(patch, /DSH_UVM_ENV_ROOT/)
  assert.match(patch, /DSH_UVM_UV_PATH/)
  assert.match(patch, /DSH_UVM_PYTHON_PATH/)
})
