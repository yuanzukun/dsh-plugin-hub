/**
 * 通用快捷命令插件 host 半:设置载体(quick-commands 设置表单)。
 *
 * 纯配置载体——不注册任何 host 命令(客户端贡献与 host 命令同名会在
 * 菜单合成时 fail-loud 抛错,行为在浏览器侧,host 无逻辑可执行)。
 * 0.2.1 起 schema 即设置表单(见 settings.ts 的 Config),host 只需注册
 * "自带页面"策略(替代旧 installSection)。
 * @module quick-commands
 */

import type { Context } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-settings'

export const name = 'quick-commands'

export function apply(ctx: Context): void {
  // 设置面板:本插件自带页面(客户端 plugins.item,「插件列表」条目详情),关掉按 schema
  // 自动生成表单的策略(0.2.1 起替代旧 installSection;策略不移除配置读写)。
  ctx.inject(['settings'], (child) => {
    child.effect(() => child.settings.configure({ auto: false }, ctx.fiber))
  })
}

export {
  QUICK_COMMANDS_NS, Config, QUICK_COMMANDS_DEFAULTS,
} from './settings.js'
export type { QuickCommandsConfig, QuickCommandsInput, QuickCommand } from './settings.js'
