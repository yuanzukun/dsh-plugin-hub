// catalog.mjs — 数据核心：tgz 严格解析、条目校验、只增不更新合并、diff、digest、
// pi-ai 安装定位。合并语义「只增不更新」（ADR 0001）：已有 id 的元数据永不覆盖。
import { createHash, randomUUID } from "node:crypto";
import { closeSync, existsSync, openSync, readFileSync, realpathSync, unlinkSync } from "node:fs";
import { dirname, join } from "node:path";
import { gunzipSync } from "node:zlib";

// github-copilot 目录的三种 wire 协议（白名单，目录外协议拒绝）。
export const SUPPORTED_APIS = ["anthropic-messages", "openai-completions", "openai-responses"];

const TGZ_ENTRY_PATH = "package/dist/providers/data/github-copilot.json";

// 严格 ustar 解析：checksum 逐块校验、尺寸越界即截断、目录/pax 条目跳过内容、
// 其余类型拒绝。返回 [{ name, type, content }]。
function parseTar(tar) {
  const entries = [];
  let offset = 0;
  while (offset + 512 <= tar.length) {
    const header = tar.subarray(offset, offset + 512);
    if (header.every((b) => b === 0)) break; // 结束零块
    const magic = header.subarray(257, 262).toString("latin1");
    if (magic !== "ustar") throw new Error(`not a ustar archive (magic=${JSON.stringify(magic)})`);
    const stored = Number.parseInt(header.subarray(148, 156).toString("latin1").trim() || "0", 8);
    let sum = 0;
    for (let i = 0; i < 512; i++) sum += i >= 148 && i < 156 ? 32 : header[i];
    if (sum !== stored) throw new Error("tar checksum mismatch");
    const name = header.subarray(0, 100).toString("latin1").replace(/\0.*$/s, "");
    const sizeField = header.subarray(124, 136).toString("latin1").replace(/\0.*$/s, "").trim();
    const size = Number.parseInt(sizeField || "0", 8);
    if (!Number.isFinite(size) || size < 0) throw new Error(`bad tar size field for ${name}`);
    const type = String.fromCharCode(header[156]);
    offset += 512;
    if (offset + size > tar.length) throw new Error(`truncated tar (entry ${name})`);
    const content = tar.subarray(offset, offset + size);
    offset += Math.ceil(size / 512) * 512;
    if (type === "0" || type === "\0") entries.push({ name, type, content });
    else if (type === "5" || type === "x" || type === "g") continue; // 目录 / pax：跳过
    else throw new Error(`unsupported tar entry type ${JSON.stringify(type)} for ${name}`);
  }
  return entries;
}

// 从 pi-ai tgz 中精确提取 github-copilot.json。路径精确匹配（前缀不误判）、
// 重复条目抛错；maxBytes 经 gunzipSync maxOutputLength 落地（防 gzip bomb）。
export function extractTgzEntry(buf, { maxBytes } = {}) {
  let tar;
  try {
    tar = gunzipSync(buf, maxBytes ? { maxOutputLength: maxBytes } : {});
  } catch (err) {
    if (err instanceof RangeError || /maxOutputLength|too large/i.test(String(err?.message))) {
      throw new Error(`catalog archive too large (decompressed cap ${maxBytes} bytes)`);
    }
    throw err;
  }
  const matches = parseTar(tar).filter((e) => e.name === TGZ_ENTRY_PATH);
  if (matches.length === 0) throw new Error(`entry not found: ${TGZ_ENTRY_PATH}`);
  if (matches.length > 1) throw new Error(`duplicate entry: ${TGZ_ENTRY_PATH}`);
  return matches[0].content;
}

// 单条目校验：true 合法；否则返回原因字符串。唯一调用点是 mergeCatalog（Y2-7）。
export function validateCatalog(api, id, entry) {
  if (!SUPPORTED_APIS.includes(api)) return `unsupported api: ${api}`;
  if (!entry || typeof entry !== "object" || Array.isArray(entry)) return "entry is not an object";
  if (entry.id !== id) return `id mismatch: key=${id} entry.id=${entry.id}`;
  if (entry.api !== api) return `api mismatch: section=${api} entry.api=${entry.api}`;
  if (entry.provider !== "github-copilot") return `unexpected provider: ${entry.provider}`;
  for (const field of ["contextWindow", "maxTokens"]) {
    if (typeof entry[field] !== "number" || !Number.isFinite(entry[field]) || entry[field] <= 0) {
      return `${field} must be a positive number`;
    }
  }
  return true;
}

// 只增不更新合并。added = 展示数组 [{id, api}]；addedOverlay = catalog-shaped
// 增量（供 journal/自愈，仅含本次合法新增）；skipped = 非法条目 [{api, id, reason}]；
// 已有 id（任一层）静默跳过——不覆盖、不进 added/skipped。
export function mergeCatalog(local, remote) {
  const merged = {};
  for (const [api, section] of Object.entries(local ?? {})) merged[api] = { ...(section ?? {}) };
  const have = new Set(Object.values(merged).flatMap((s) => Object.keys(s)));
  const added = [];
  const skipped = [];
  const addedOverlay = {};
  for (const [api, section] of Object.entries(remote ?? {})) {
    for (const [id, entry] of Object.entries(section ?? {})) {
      if (have.has(id)) continue; // 只增不更新
      const why = validateCatalog(api, id, entry);
      if (why !== true) {
        skipped.push({ api, id, reason: why });
        continue;
      }
      (merged[api] ??= {})[id] = entry;
      (addedOverlay[api] ??= {})[id] = entry;
      added.push({ id, api });
      have.add(id);
    }
  }
  return { merged, added, addedOverlay, skipped };
}

// ==================== 远端目录的形状规范化（pi-ai ≥0.99.0 的 chat: 键） ====================
// pi-ai ≥0.99.0（实测 0.99.2 / 1.0.0，两份字节相同）把目录 JSON 的键改成
// `chat:<内层裸 id>`（flattenChatModelCatalog 的产物）：这不是改名——运行时仍按条目
// 内层的裸 id 编键，github-copilot 的 filterModels 也按裸 id 与账号可用集匹配。
// 本模块的 mergeCatalog/validateCatalog 假定「键 == 条目内层 id」，因此远端目录
// 必须先规范化回三段式裸 id 形状，两个世代的语义才一致。
export const CHAT_KEY_PREFIX = "chat:";

// 把远端目录（0.87.x 裸键 / ≥0.99.0 `chat:` 键）规范化为 `{ api: { 裸id: entry } }`。
// 条目内层 id 与键冲突的条目一律跳过并记录（宁可少一个模型，不可写坏目录）。
// allowedKeys 非空时按本机目录已见字段集合裁剪（见 trimEntryToShape）。
// 返回 { catalog, renamed, skipped }。
export function normalizeRemoteCatalog(data, { allowedKeys } = {}) {
  const catalog = {};
  const skipped = [];
  let renamed = 0;
  for (const [api, section] of Object.entries(data ?? {})) {
    if (!section || typeof section !== "object" || Array.isArray(section)) {
      skipped.push({ api, id: null, reason: "section is not an object" });
      continue;
    }
    for (const [key, entry] of Object.entries(section)) {
      const prefixed = key.startsWith(CHAT_KEY_PREFIX);
      const id = prefixed ? key.slice(CHAT_KEY_PREFIX.length) : key;
      if (id.length === 0) {
        skipped.push({ api, id: key, reason: "empty id after prefix strip" });
        continue;
      }
      if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
        skipped.push({ api, id, reason: "entry is not an object" });
        continue;
      }
      if (typeof entry.id === "string" && entry.id !== id) {
        skipped.push({ api, id, reason: `id mismatch: key=${key} entry.id=${entry.id}` });
        continue;
      }
      if (prefixed) renamed += 1;
      (catalog[api] ??= {})[id] = trimEntryToShape(entry, allowedKeys);
    }
  }
  return { catalog, renamed, skipped };
}

// 把条目裁剪到本机运行时已见过的字段集合（allowedKeys 来自 catalogShapeKeys）。
// 典型漂移：≥0.99.0 的条目多一个 `type: "chat"`，0.87.x 的模型对象里没有这个概念。
// allowedKeys 为空集时不裁剪——拿不到参考形状时宁可不裁剪，也不误删必需字段。
export function trimEntryToShape(entry, allowedKeys) {
  if (!allowedKeys || allowedKeys.size === 0) return { ...entry };
  const out = {};
  for (const [k, v] of Object.entries(entry)) {
    if (allowedKeys.has(k)) out[k] = v;
  }
  return out;
}

// 本机目录条目的字段并集——注入/规范化条目的裁剪基准。
export function catalogShapeKeys(localCatalog) {
  const keys = new Set();
  for (const section of Object.values(localCatalog ?? {})) {
    for (const entry of Object.values(section ?? {})) {
      if (entry && typeof entry === "object" && !Array.isArray(entry)) {
        for (const k of Object.keys(entry)) keys.add(k);
      }
    }
  }
  return keys;
}

// R3：removed 以 target 为准，不以 available 为准——available 但目录不可解析的
// 当前模型必须进 removed（settings 校验拒绝目录外 id，保留必报错）。
export function diffModels(currentIds, availableIds, catalogIds) {
  const target = [...new Set(availableIds)].filter((id) => catalogIds.has(id));
  const targetSet = new Set(target);
  const current = [...new Set(currentIds)];
  return {
    target,
    added: target.filter((id) => !current.includes(id)),
    removed: current.filter((id) => !targetSet.has(id)),
    kept: current.filter((id) => targetSet.has(id)),
  };
}

// canonical JSON：递归键排序；保留 undefined 与缺失键、空数组与空对象的区别
// （字段级定制变化必须使 settings digest 漂移，R3-2）。
function canonicalize(v) {
  if (v === undefined) return "undefined";
  if (v === null || typeof v !== "object") return JSON.stringify(v) ?? "undefined";
  if (Array.isArray(v)) return `[${v.map(canonicalize).join(",")}]`;
  return `{${Object.keys(v)
    .sort()
    .map((k) => `${JSON.stringify(k)}:${canonicalize(v[k])}`)
    .join(",")}}`;
}

export function digest(x) {
  const h = createHash("sha256");
  if (Buffer.isBuffer(x)) h.update(x);
  else if (typeof x === "string") h.update(x);
  else h.update(canonicalize(x), "utf8");
  return h.digest("hex");
}

// 从进程入口（或注入的 startPath）逐级向上定位 pi-ai 安装根；catalog 文件与
// version 取自同一解析根的 package.json（防版本与被写文件不属同一副本，R3-8）。
export function findPiAiInstallation({ startPath } = {}) {
  try {
    let dir = startPath ?? dirname(realpathSync(process.argv?.[1] ?? ""));
    for (let depth = 0; depth < 8; depth++) {
      const root = join(dir, "node_modules", "@earendil-works", "pi-ai");
      const catalogFile = join(root, "dist", "providers", "data", "github-copilot.json");
      const packageJsonFile = join(root, "package.json");
      if (existsSync(catalogFile) && existsSync(packageJsonFile)) {
        const pkg = JSON.parse(readFileSync(packageJsonFile, "utf8"));
        return { catalogFile, packageJsonFile, version: pkg.version };
      }
      const parent = dirname(dir);
      if (parent === dir) return null;
      dir = parent;
    }
  } catch { /* 安装树结构变化 → null（调用方降级） */ }
  return null;
}

// ==================== 安装目标可写性分类（desktop asar 只读问题，ADR 0002） ====================
// dsh-desktop（Electron）把整个运行时树打进 resources/app.asar，pi-ai 是其中唯一副本：
// asar 虚拟文件系统读没问题、创建/写入必被拒（ENOENT "... not found in <archive>"）。
// 数据级目录补丁在写盘前必须先分类目标，把"物理不可写"变成结构化错误而不是天书 ENOENT。

// Electron 的 asar 拦截按"路径中任一段以 .asar 结尾"判定（大小写不敏感，分隔符 / 与 \ 都认，
// Win 路径在 POSIX 主机上测试时也要能识别）。.asar.unpacked 不以 .asar 结尾，不会误判。
export function isAsarPath(p) {
  const s = String(p ?? "");
  if (/\.asar$/i.test(s)) return true;
  return s.split(/[\\/]/).some((seg) => /\.asar$/i.test(seg));
}

// 功能性可写探测：在目录内排他创建 + 删除一个探针文件。覆盖 asar 之外的不可写形态
// （只读卷、根属主安装、ACL 拒绝——win32 chmod 弱语义下唯一可靠的通用手段）。
// 探针文件名带 UUID，排他创建，任何失败路径都尝试清理并返回 false。
export function probeWritable(dir) {
  const probe = join(dir, `.copilot-auth-write-probe-${randomUUID()}`);
  let fd;
  try {
    fd = openSync(probe, "wx");
    closeSync(fd);
    fd = undefined;
    return true;
  } catch {
    return false;
  } finally {
    if (fd !== undefined) {
      try { closeSync(fd); } catch { /* 已关闭 */ }
    }
    try { unlinkSync(probe); } catch { /* 探针可能未创建成功 */ }
  }
}

// 分类结果平铺进安装对象：writable: boolean；不可写时 unwritableReason: "asar" | "probe-failed"。
// writableProbe 仅作测试注入钩子（生产恒用默认实现）。
export function classifyCatalogTarget(catalogFile, writableProbe = probeWritable) {
  if (isAsarPath(catalogFile)) return { writable: false, unwritableReason: "asar" };
  if (!writableProbe(dirname(catalogFile))) return { writable: false, unwritableReason: "probe-failed" };
  return { writable: true, unwritableReason: null };
}
