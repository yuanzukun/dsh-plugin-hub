# dsh-progress — 别憋着

> 2026-10-21 晚写。他一句「我想让你把这个能力写成插件」。

## 它治什么

家里的规矩写着：**动手前说一句要干什么，每过一个阶段丢一句，出岔子当场说；连着两次工具调用没吐一句人话，就是憋住了。**

规矩靠自觉，而自觉在长任务里最先失效。就 2026-10-21 一天：

- 凌晨写 `dsh-wakeup`，摸 API、写代码、跑测试十几分钟，中间一句话没有；
- 中午做那三版文本框，LibreOffice 崩了、文字被裁、换方案，全程不吭声，最后等来一句「停 我自己做吧」；
- 傍晚查 WPS 那个报错窗口，半个多小时一个字没回，他连着催了两回。

所以把「憋住了」这件事交给机器判：**连着几步模型输出里一个 `text` 都没有，就往会话里塞一条提醒。**

## 判据

DSH 每完成一次模型调用会提交一条 `assistant/message`，`content` 是 `ContentBlock[]`（`text` / `reasoning` / `tool-call` / ...）。

**只认 `text`。** 心里的盘算（`reasoning`）不算说话——这正是病根：我可以在肚子里转几十圈，对他一个字不说。

结构认不出（版本换了字段）时**当作说了话**，宁可漏报，不可误报。

## 怎么工作

不轮询、不重扫事件日志，只增量消费 `session/event`：

| 事件 | 动作 |
|---|---|
| `assistant/message` 里有 `text` | 沉默计数归零、工具计数归零 |
| `assistant/message` 里没 `text` | 沉默计数 +1 |
| `tool/call` | 工具计数 +1 |
| `turn/start` / `turn/end` | 两个计数和本轮提醒额度一起归零 |

沉默计数到 `silentSteps` 就 `agent.inject()` 一条提醒——它会在**下一个被接纳的 step** 里出现在模型眼前。

同一轮最多提醒 `maxPerTurn` 次（默认 1），不刷屏。

subagent 不管：那是临时工，它埋头不关我的事。

## 配置

在 profile 的 `cordis.patch.yml` 里覆盖，或改包自己的 `cordis.patch.yml`：

```yaml
- id: progress
  name: dsh-progress
  config:
    silentSteps: 2    # 连着几步没吐 text 就提醒（1–50，默认 2）
    maxPerTurn: 1     # 每轮最多提醒几次（0–20，默认 1；0 = 只盯着不吭声）
    enabled: true
```

## 冒烟测试

不启动 DSH，用假的 ctx / agent 跑整条链路：

```bash
node test/smoke.mjs
```

验五件事：判据（text / reasoning / tool-call / 结构不明）、计数（阈值、归零、一轮上限、坏配置兜底）、链路（挂得上、注得进、source.kind 认得出、不串台）、边界（subagent 不管、一直说话的人不被打扰）、纪律（源码零外部依赖、manifest 指得到实处）。

## 安装（手工，这台没有 `plugin_manager`）

1. 包放到 `~/.dsh/plugins/dsh-progress`
2. profile 的 `node_modules` 里建联接：`dsh-progress -> ~/.dsh/plugins/dsh-progress`
3. profile `package.json`：
   - `dependencies` 加 `"dsh-progress": "file:../../plugins/dsh-progress"`
   - `dsh.profile.bundles` 加 `"dsh-progress"`
4. **重启 DSH**

不要手改 profile 的 `cordis.yml`（那是组合后的生成物）；插件行的插入来自本包自己的 `cordis.patch.yml`。

## 设计约束

照 `dsh-wakeup` 的路子：不 import 任何外部包（宿主 peer 依赖版本跟实际跑的不是同一份），只用 node 内置；任何异常都吞掉并记日志——提醒失败绝不能把正在跑的轮次搞崩。

## 还没做的

- **卡住提醒**：现在只管「不说话」，不管「一个工具跑了十分钟没结果」。要加的话得配一个 `agent.followup()` 唤醒。
- **写了一堆但全是交作业**：这个判不出，得靠 `说话的规矩.md`。