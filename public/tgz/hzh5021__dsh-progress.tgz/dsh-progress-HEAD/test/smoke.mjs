/**
 * dsh-progress 离线冒烟测试。
 *
 * 不启动 DSH，用假的 ctx / agent 把 apply() 挂起来，验六件事：
 *   1. 判据：`text` 才算说话，reasoning 和 tool-call 都不算，认不出结构时不误报；
 *   2. 计数：连着几步没说话才触发，说了话就归零，一轮不超过 maxPerTurn；
 *   3. 链路：session/event 挂在**插件**的 ctx 上（第一版挂在 agent.ctx，一个事件
 *      都收不到）、按 session 认人、正好注入一条、source.kind 认得出、resume 接得住；
 *   4. 撞锁重试：宿主正在发布 append 时会被拒（`session append cannot reenter...`），
 *      退避重试要能救回来；一直拒就干脆放弃，不许无限重试；
 *   5. 边界：subagent 不管，enabled:false 什么都不挂，探针按需写；
 *   6. 纪律：源码只 import node 内置，manifest 里的 exports 都指得到实处。
 *
 * 注入是异步的（先 setTimeout 让出当前 append 窗口），所以断言前要 await tick()。
 *
 * 跑法（用 DSH 自带的 node）：
 *   node test/smoke.mjs
 */

import { strict as assert } from "node:assert";
import { readFile, rm } from "node:fs/promises";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const here = dirname(fileURLToPath(import.meta.url));
const root = join(here, "..");

const plugin = await import("../lib/index.js");
const { apply, _internals } = plugin;

const logs = [];

/** 让出事件循环：插件的提醒是在 setTimeout 里落地的。 */
const tick = (ms = 0) => new Promise(resolve => setTimeout(resolve, ms));

console.log("=== 1. 判据：什么算说话 ===");

const msg = (...content) => ({ type: "assistant/message", data: { turn: 1, step: 1, message: { role: "assistant", content } } });
const text = value => ({ type: "text", text: value });
const toolCall = () => ({ type: "tool-call", name: "ops_bash", arguments: "{}" });
const reasoning = () => ({ type: "reasoning", text: "嗯，先看看这个" });

assert.equal(_internals.spokeInEvent(msg(text("我去看看"))), true, "有 text 就是说了话");
assert.equal(_internals.spokeInEvent(msg(text("  "))), false, "空白 text 不算说话");
assert.equal(_internals.spokeInEvent(msg(toolCall())), false, "只调工具没说话");
assert.equal(_internals.spokeInEvent(msg(reasoning(), toolCall())), false, "心里盘算不算说话（这正是病根）");
assert.equal(_internals.spokeInEvent(msg(reasoning(), text("报一句"), toolCall())), true, "说了话就算说");
assert.equal(_internals.spokeInEvent({ data: { message: {} } }), null, "结构变了要能认出来，不能瞎判");
assert.equal(_internals.spokeInEvent({}), null);
console.log("text/reasoning/tool-call/结构不明 —— 判据都对");

console.log("\n=== 2. 计数：什么时候该响 ===");

const opts = _internals.resolveOptions({});
assert.equal(opts.silentSteps, 2, "默认连着 2 步没说话就提醒");
assert.equal(opts.maxPerTurn, 1, "默认一轮最多提醒一次");
assert.equal(opts.enabled, true);
assert.equal(opts.probeFile, "", "默认不写探针");
assert.equal(_internals.resolveOptions({ silentSteps: "坏值" }).silentSteps, 2, "坏值退回默认");
assert.equal(_internals.resolveOptions({ silentSteps: 999 }).silentSteps, 50, "越界卡到上限");
assert.equal(_internals.resolveOptions({ enabled: false }).enabled, false, "enabled:false 要认");

const state = { silent: 0, tools: 0, nudges: 0 };
const tool = { type: "tool/call", data: { turn: 1, step: 1, name: "ops_grep" } };

assert.equal(_internals.advance(null, msg(toolCall()), state, opts), null, "才沉默 1 步，还不到点");
assert.equal(state.silent, 1);
_internals.advance(null, tool, state, opts);
_internals.advance(null, tool, state, opts);
assert.equal(state.tools, 2, "工具调用要攒着");

const firstNudge = _internals.advance(null, msg(toolCall()), state, opts);
assert.ok(firstNudge, "连着 2 步没说话该响了");
assert.ok(firstNudge.includes("<dsh-progress>"), "提醒要有开标记");
assert.ok(firstNudge.includes("停一下，说句话"), "提醒要说人话");
assert.ok(firstNudge.includes("连着 2 步"), "提醒要报清沉默了几步");
assert.ok(firstNudge.includes("2 次工具"), "提醒要报清中间跑了多少工具");
assert.equal(state.nudges, 1, "记一次数");
assert.equal(state.silent, 0, "响过之后重新计数");

_internals.advance(null, msg(toolCall()), state, opts);
assert.equal(_internals.advance(null, msg(toolCall()), state, opts), null, "同一轮不再响");
assert.equal(state.nudges, 1, "maxPerTurn 没有被顶穿");

_internals.advance(null, { type: "turn/start" }, state, opts);
assert.equal(state.nudges, 0, "新一轮重置额度");
assert.equal(state.silent, 0);

const speakState = { silent: 1, tools: 3, nudges: 0 };
_internals.advance(null, msg(text("报一句进度")), speakState, opts);
assert.equal(speakState.silent, 0, "说了话就归零");
assert.equal(speakState.tools, 0, "工具计数跟着归零");

const blind = { silent: 0, tools: 0, nudges: 0 };
_internals.advance(null, { type: "assistant/message", data: { message: {} } }, blind, opts);
assert.equal(blind.silent, 0, "结构认不出时不误报");

const muted = { silent: 1, tools: 0, nudges: 0 };
assert.equal(
  _internals.advance(null, msg(toolCall()), muted, _internals.resolveOptions({ maxPerTurn: 0 })),
  null,
  "maxPerTurn:0 时永远不注入",
);
console.log("阈值、归零、一轮上限、坏配置 —— 都对");

console.log("\n=== 3. 链路：挂得上、认得人、注得进 ===");

const listeners = new Map();
const ctx = {
  logger: { info: (...args) => logs.push(args.join(" ")) },
  on: (event, handler) => { listeners.set(event, handler); return () => listeners.delete(event); },
  effect: callback => { const dispose = callback(); return typeof dispose === "function" ? dispose : () => {}; },
};

apply(ctx, {});
assert.ok(listeners.has("agent/created"), "没挂 agent/created");
assert.ok(listeners.has("agent/session-start"), "没挂 agent/session-start");
assert.ok(listeners.has("agent/disposed"), "没挂 agent/disposed");
assert.ok(
  listeners.has("session/event"),
  "session/event 必须挂在插件自己的 ctx 上 —— 第一版挂在 agent.ctx，一个事件都收不到",
);

const created = listeners.get("agent/created");
const emit = (session, event) => listeners.get("session/event")(session, event);

let seq = 0;
function makeAgent({ origin = "user", session = null } = {}) {
  return {
    status: "running",
    session: session ?? { id: `s${++seq}`, header: { origin }, ownEvents: () => [] },
    inbox: {},
    injected: [],
    inject(message) { this.injected.push(message); },
  };
}

const mine = makeAgent();
const ret = created({ agent: mine, source: "user" });
assert.equal(ret, undefined, "串行分发要求监听器 resolve 成 undefined");

emit(mine.session, tool);
emit(mine.session, msg(toolCall()));
assert.equal(mine.injected.length, 0, "才沉默一步不该响");
emit(mine.session, msg(toolCall()));
await tick();
assert.equal(mine.injected.length, 1, "连着两步没说话，该注入一条");
assert.equal(mine.injected[0].role, "user");
assert.equal(mine.injected[0].source.kind, "plugin:dsh-progress");
assert.ok(mine.injected[0].content[0].text.includes("停一下"), "注入的正文要对");
assert.ok(_internals.isProgressMessage(mine.injected[0]), "自己塞的自己要认得出来");

// 不是自己盯的会话，事件再多也不该串台
const stranger = makeAgent();
emit(stranger.session, msg(toolCall()));
emit(stranger.session, msg(toolCall()));
await tick();
assert.equal(stranger.injected.length, 0, "没盯过的会话不该被响");
assert.equal(mine.injected.length, 1, "别人的事件不该让我的计数往前走");

// 两个都盯着，各数各的
const a = makeAgent();
const b = makeAgent();
created({ agent: a, source: "user" });
created({ agent: b, source: "user" });
emit(b.session, msg(text("我先说一句")));
emit(a.session, msg(toolCall()));
emit(a.session, msg(toolCall()));
await tick();
assert.equal(a.injected.length, 1, "a 沉默了，该响 a");
assert.equal(b.injected.length, 0, "b 说过话，不该被带响");

// resume：同一个 session 换了 agent 实例，计数接着走，注入打到新 agent 上
const shared = { id: "shared", header: { origin: "user" }, ownEvents: () => [] };
const before = makeAgent({ session: shared });
const after = makeAgent({ session: shared });
created({ agent: before, source: "resume" });
emit(shared, msg(toolCall()));
assert.equal(before.injected.length, 0, "第一步还不该响");
created({ agent: after, source: "resume" });
emit(shared, msg(toolCall()));
await tick();
assert.equal(after.injected.length, 1, "resume 之后计数要接着走，注入打到新 agent");
assert.equal(before.injected.length, 0, "别再往旧实例里塞");

// agent 没了就划掉名册
const gone = makeAgent();
created({ agent: gone, source: "user" });
listeners.get("agent/disposed")({ agent: gone });
emit(gone.session, msg(toolCall()));
emit(gone.session, msg(toolCall()));
await tick();
assert.equal(gone.injected.length, 0, "dispose 之后不该再注入");

console.log("\n=== 4. 撞锁重试：宿主正在发布 append 时 ===");

// 2026-10-25 的真实现场：`session.append()` 拒绝重入，探针里 43 次全失败。
// 头两次抛、第三次成功 —— 退避重试要能把它救回来。
const REFUSED = "session append cannot reenter while another append is being published";
listeners.clear();
apply(ctx, {});
const busyCreated = listeners.get("agent/created");
const busyEmit = (session, event) => listeners.get("session/event")(session, event);

const busy = makeAgent();
let refusals = 0;
busy.inject = function (message) {
  if (refusals < 2) {
    refusals += 1;
    throw new Error(REFUSED);
  }
  this.injected.push(message);
};
busyCreated({ agent: busy, source: "user" });
busyEmit(busy.session, msg(toolCall()));
busyEmit(busy.session, msg(toolCall()));
await tick();
assert.equal(busy.injected.length, 0, "头两次被拒，先别算成功");
await tick(80);
assert.equal(refusals, 2, "应该正好被拒两次");
assert.equal(busy.injected.length, 1, "第三次成功了，提醒落地");

// 一直拒就放弃：1 次首发 + 7 次重试 = 8 次，不许无限重试。
const stubborn = makeAgent();
let stubbornTries = 0;
stubborn.inject = function () {
  stubbornTries += 1;
  throw new Error(REFUSED);
};
busyCreated({ agent: stubborn, source: "user" });
busyEmit(stubborn.session, msg(toolCall()));
busyEmit(stubborn.session, msg(toolCall()));
await tick(5000);
assert.equal(stubbornTries, 8, "试满 8 次就停手");
assert.equal(stubborn.injected.length, 0);

// 不是撞锁的错，立即停手，别拿重试盖住真 bug。
const broken = makeAgent();
let brokenTries = 0;
broken.inject = function () {
  brokenTries += 1;
  throw new Error("agent 已经被丢掉了");
};
busyCreated({ agent: broken, source: "user" });
busyEmit(broken.session, msg(toolCall()));
busyEmit(broken.session, msg(toolCall()));
await tick(40);
assert.equal(brokenTries, 1, "别的错不重试");
console.log("撞锁退避重试、试满放弃、别的错不重试 —— 都对");

console.log("\n=== 5. 边界 ===");

const child = makeAgent({ origin: "subagent" });
created({ agent: child, source: "subagent" });
emit(child.session, msg(toolCall()));
emit(child.session, msg(toolCall()));
await tick();
assert.equal(child.injected.length, 0, "subagent 不该被盯");

const quiet = makeAgent();
created({ agent: quiet, source: "user" });
emit(quiet.session, msg(text("我先说一句要干什么")));
emit(quiet.session, msg(text("摸清了")));
await tick();
assert.equal(quiet.injected.length, 0, "一直说话的人不该被打扰");

// 老版本路径：agent/created 没有 source，由 session-start 补位
listeners.clear();
apply(ctx, {});
const legacy = makeAgent();
listeners.get("agent/session-start")({ agent: legacy });
emit(legacy.session, msg(toolCall()));
emit(legacy.session, msg(toolCall()));
await tick();
assert.equal(legacy.injected.length, 1, "session-start 那条路也要盯上");

// 探针：配了才写
// 探针写到临时目录：插件家目录在会话工作区之外，沙箱里写不进去（appendFileSync 会被吞），
// 那不是插件的问题，是测试不该挑一个自己都没权限的地方。
const probePath = join(process.env.TEMP ?? here, `dsh-progress-probe-${process.pid}.log`);
await rm(probePath, { force: true });
listeners.clear();
apply(ctx, { probeFile: probePath });
const probeCreated = listeners.get("agent/created");
const watched = makeAgent();
probeCreated({ agent: watched, source: "user" });
emit(watched.session, msg(toolCall()));
emit(watched.session, msg(toolCall()));
await tick();
const probeText = await readFile(probePath, "utf8");
assert.ok(probeText.includes("apply ok"), "探针要记 apply");
assert.ok(probeText.includes("watching"), "探针要记 watching");
assert.ok(probeText.includes("nudged"), "探针要记 nudged");
assert.ok(probeText.includes("spoke=false"), "探针要记每条 assistant/message 的判据");
await rm(probePath, { force: true });

// enabled:false 什么都不挂
listeners.clear();
apply(ctx, { enabled: false });
assert.equal(listeners.size, 0, "enabled:false 时什么都不挂");

console.log("\n=== 6. 纪律 ===");

const source = await readFile(join(root, "lib", "index.js"), "utf8");
const imports = [...source.matchAll(/^\s*import\s[^;]*?from\s+["']([^"']+)["']/gm)].map(m => m[1]);
assert.ok(imports.length > 0, "至少要 import node 内置");
for (const spec of imports) {
  assert.ok(spec.startsWith("node:"), `只许 import node 内置（宿主 peer 版本不一致），发现：${spec}`);
}
assert.ok(!/require\(/.test(source), "源码不许 require");
assert.ok(source.includes("export function apply"), "要有 apply");
assert.ok(source.includes("export const inject = []"), "要声明 inject");

const manifest = JSON.parse(await readFile(join(root, "package.json"), "utf8"));
assert.equal(manifest.type, "module");
assert.equal(manifest.dsh.bundle.patch, "./cordis.patch.yml");
for (const key of [".", "./package.json", "./locale/*.json", "./icon"]) {
  assert.ok(manifest.exports[key], `exports 缺 ${key}`);
}
const yml = await readFile(join(root, "cordis.patch.yml"), "utf8");
assert.ok(yml.includes("id: progress"), "patch 里要有 id: progress");
assert.ok(yml.includes("name: dsh-progress"), "patch 里要有 name: dsh-progress");
for (const locale of ["zh", "en"]) {
  const data = JSON.parse(await readFile(join(root, "locale", `${locale}.json`), "utf8"));
  assert.ok(data.meta.title, `${locale}.json 缺 meta.title`);
  assert.ok(data.meta.description, `${locale}.json 缺 meta.description`);
}
const icon = await readFile(join(root, "icon.svg"), "utf8");
assert.ok(icon.trimStart().startsWith("<svg"), "图标要是 SVG");
console.log("只 import node 内置、manifest、locale、图标、patch —— 都在");

console.log("\n日志:", logs.length, "条，最后一条:", logs[logs.length - 1]);
console.log("\nOK —— 判据、计数、注入、重试、边界、manifest 全部通过。");