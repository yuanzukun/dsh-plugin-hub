import { createDenialTickets, executeEventMatch as executeReminderMatch, createBoundedMatcher } from '@leolee9086/dsh-rule-engine'
import type { EventRuntimeOptions as RuntimeOptions } from '@leolee9086/dsh-rule-engine'
import test, { after, type TestContext } from 'node:test'
import { eventRule } from './event-rule.js'
import assert from 'node:assert/strict'

import { createReminderRuntime } from './reminder-runtime-fixture.ts'


// 真实执行端口：匹配、判定器、线程池全是真的，测试只驱动事件与边界。
const matcher = createBoundedMatcher({ timeoutMs: 2000, startupMs: 5000 })
after(async () => { await matcher.close() })
const port: NonNullable<RuntimeOptions['execute']> = (input, signal, timing) => matcher.detect(input, signal, timing)

const verdict = { sourceId: 's', ruleId: 'r', reason: '不得删除文件' }
const tickets = () => createDenialTickets()
type Runtime = ReturnType<typeof createReminderRuntime>
type Handle = ReturnType<Runtime['registerSource']>
type Outcome = { kind: 'allow' } | { kind: 'deny'; reason: string }

/** A live reminder runtime whose matching is the shipped implementation, not a stub. */
function runtime(t: TestContext, options: Partial<RuntimeOptions> = {}) {
  const instance = createReminderRuntime({ config: { ruleTimeoutMs: 2000, roundTimeoutMs: 5000 },
    execute: port, ...options })
  t.after(() => instance.close())
  return instance
}

const denyRule = (reason: string, tool = 'blocked') => eventRule('tool.before-execute', { id: 'blocked', event: { tool } },
  { template: '这次调用被规则拦下', deny: { dangerous: true, reason } })
const remindRule = eventRule('tool.succeeded', { event: { tool: 'probe' } })

/** One tool call through the real pre-execute then guard sequence. */
let calls = 0
async function callWith(instance: Runtime, name: string, id = `call-${++calls}`, args: unknown = {}): Promise<Outcome> {
  const key = {}
  await instance.prepareToolExecution({ key, sessionId: 's', name, arguments: args, callId: id, rootCallId: id })
  const outcome = instance.decideToolExecution(key)
  instance.settleToolExecution(key)
  return outcome
}
const call = (instance: Runtime, name: string) => callWith(instance, name)

/** The reason a call ended with, so a failure names the exact branch. */
function reason(outcome: Outcome) { return outcome.kind === 'deny' ? outcome.reason : 'allow' }

// ---------------------------------------------------------------------------
// The ticket contract: a verdict is issued once, and an unfinished round denies.
// ---------------------------------------------------------------------------

test('只有评估完成且未命中的票据才授权执行', () => {
  const api = tickets()
  const clean = {}, denied = {}, unfinished = {}
  const generation = api.current()
  api.record(clean, undefined, true, generation)
  api.record(denied, verdict, true, generation)
  // A round cut short before finishing cannot authorize: an unfinished check is not permission.
  api.record(unfinished, undefined, false, generation)
  assert.deepEqual(api.decide(clean), { kind: 'allow' })
  assert.deepEqual(api.decide(denied), { kind: 'deny', reason: '不得删除文件' })
  assert.equal(api.decide(unfinished).kind, 'deny')
})

test('缺少票据仍拒绝，已完成结论只随执行结算或策略变更失效', () => {
  const api = tickets()
  assert.equal(api.decide({}).kind, 'deny')
  const live = {}
  api.record(live, undefined, true, api.current())
  assert.deepEqual(api.decide(live), { kind: 'allow' })
  api.settle(live)
  assert.equal(api.decide(live).kind, 'deny')
})

test('票据按执行令牌区分，调用ID重用不会继承他人结论', () => {
  const api = tickets()
  const first = {}
  api.record(first, undefined, true, api.current())
  // The second call has its own token and was never evaluated.
  assert.equal(api.decide({}).kind, 'deny')
  assert.deepEqual(api.decide(first), { kind: 'allow' })
})

test('政策变更只作废旧票据，之后仍然签发并生效', () => {
  const api = tickets()
  const before = {}
  api.record(before, undefined, true, api.current())
  api.invalidate()
  // The verdict was reached under the previous rule set, so it cannot authorize this call.
  assert.deepEqual(api.decide(before), { kind: 'deny', reason: '提醒策略已变更，本次调用需重新评估' })
  // Retirement is not a shutdown: the next round is recorded and honoured.
  const after = {}
  api.record(after, undefined, true, api.current())
  assert.deepEqual(api.decide(after), { kind: 'allow' })
  assert.equal(api.decide({}).kind, 'deny')
})

test('已结算的票据不再生效，停用后一律拒绝', () => {
  const api = tickets()
  const settled = {}
  api.record(settled, undefined, true, api.current())
  api.settle(settled)
  assert.equal(api.decide(settled).kind, 'deny')
  const closing = tickets()
  const live = {}
  closing.record(live, undefined, true, closing.current())
  closing.dispose()
  assert.deepEqual(closing.decide(live), { kind: 'deny', reason: '提醒策略服务已停止，本次调用未执行' })
  const late = {}
  closing.record(late, undefined, true, closing.current())
  assert.equal(closing.decide(late).kind, 'deny')
})

// ---------------------------------------------------------------------------
// The invariant this file exists to pin: every tool call ends with a verdict.
// A preparation that returns without recording one is the bug class that locked
// every tool in a session, so each exit below names the outcome it must produce.
// ---------------------------------------------------------------------------

interface Exit {
  name: string
  expected: string
  options?: Partial<RuntimeOptions>
  scope?: unknown
  rules?: unknown[]
  drive?: (instance: Runtime, handle: Handle) => Promise<Outcome>
}

const exits: Exit[] = [
  { name: '本会话没有前置规则时放行', rules: [remindRule], expected: 'allow' },
  { name: '会话连任何规则都没有时放行', rules: [], expected: 'allow' },
  { name: '前置规则存在但工具名不同时放行', rules: [denyRule('不得删除文件')], expected: 'allow' },
  { name: '工具名相同但参数条件不满足时放行', rules: [eventRule('tool.before-execute', { id: 'blocked', event: { tool: 'blocked', arguments: { path: { regex: '^D:' } } } },
    { template: '只能读 D 盘', deny: { dangerous: true, reason: '只能读 D 盘' } })],
    drive: instance => callWith(instance, 'blocked', undefined, {}) , expected: 'allow' },
  { name: '规则范围不含本会话时放行', rules: [denyRule('不得删除文件')], scope: { sessionIds: ['other'] }, expected: 'allow' },
  { name: '规则被开关关闭时放行，不把停用当成拒绝', rules: [denyRule('不得删除文件')],
    options: { eligible: () => false }, drive: instance => call(instance, 'blocked'), expected: 'allow' },
  { name: '命中拒绝规则时用规则自己的理由', rules: [denyRule('不得删除文件')],
    drive: instance => call(instance, 'blocked'), expected: '不得删除文件' },
  { name: '评估期间来源被替换时拒绝并要求重评', rules: [denyRule('不得删除文件')],
    drive: async (instance, handle) => {
      // The round reads the old rule set; a verdict from it must not authorize under the new one.
      const key = {}
      const pending = instance.prepareToolExecution({ key, sessionId: 's', name: 'blocked', arguments: {},
        callId: 'call-race', rootCallId: 'call-race' })
      handle.replace({ sourceId: 'policy', plugin: 'test', revision: 2, rules: [denyRule('新的理由')] })
      await pending
      const outcome = instance.decideToolExecution(key)
      instance.settleToolExecution(key)
      return outcome
    }, expected: '提醒策略已变更，本次调用需重新评估' },
  { name: '同一个调用ID被重复评估时拒绝，不去猜旧结论', rules: [denyRule('不得删除文件')],
    drive: async instance => { await callWith(instance, 'blocked', 'call-twice'); return callWith(instance, 'blocked', 'call-twice') },
    // 第二次同 callId 的调用没有属于自己的评估，所以拒绝。原因是「重复」而不是「规则没评完」：
    // 两者都拒绝，但一个是入口去重、一个是规则超时，修起来完全不是一回事。
    expected: '同一调用已有一次未完成的评估，本次调用未执行' },
  { name: '一次拒绝不污染后一次调用', rules: [denyRule('不得删除文件')],
    drive: async instance => { assert.equal(reason(await call(instance, 'blocked')), '不得删除文件'); return call(instance, 'read') },
    expected: 'allow' },
  { name: '一次放行不授权后一次命中', rules: [denyRule('不得删除文件')],
    drive: async instance => { assert.equal(reason(await call(instance, 'read')), 'allow'); return call(instance, 'blocked') },
    expected: '不得删除文件' },
  { name: '服务关闭后迟到的一次调用拒绝', rules: [denyRule('不得删除文件')],
    drive: async instance => { assert.equal(reason(await call(instance, 'read')), 'allow'); await instance.close(); return call(instance, 'read') },
    expected: '提醒策略服务已停止，本次调用未执行' },
]

for (const phase of ['identity', 'identity-recheck', 'native-event', 'eligible', 'handoff', 'evaluation'] as const) {
  test(`preparation exposes the original ${phase} exception without misclassifying it`, async t => {
    const cause = new Error('underlying storage detail')
    const failure = new TypeError(`original-${phase}`, { cause })
    const reported: unknown[] = []
    let identityReads = 0
    let epochReads = 0
    const instance = runtime(t, {
      report: error => { reported.push(error) },
      resolveIdentity: () => {
        identityReads++
        if (phase === 'identity' || (phase === 'identity-recheck' && identityReads === 2)) throw failure
        return {}
      },
      resolveEvent: async event => { if (phase === 'native-event') throw failure; return event },
      eligible: () => { if (phase === 'eligible') throw failure; return true },
      wasHanded: async () => { if (phase === 'handoff') throw failure; return false },
      // The second epoch read happens in evaluate(), beyond the admission promise.
      epoch: () => { if (phase === 'evaluation' && ++epochReads === 2) throw failure; return 0 },
    })
    instance.registerSource({ sourceId: 'policy', plugin: 'test', revision: 1, rules: [denyRule('rule-denial')] })
    const key = {}
    await instance.prepareToolExecution({ key, sessionId: 's', name: 'blocked', arguments: {},
      callId: phase, rootCallId: phase, ...(phase === 'native-event' ? { native: { type: 'tool-call', seq: 0 } as const } : {}) })
    const outcome = instance.decideToolExecution(key)
    assert.equal(outcome.kind, 'deny')
    assert.ok(outcome.kind === 'deny' && outcome.error)
    const expected = phase.startsWith('identity') ? 'identity' : phase === 'native-event' ? 'native-event' : 'unclassified'
    assert.equal(outcome.error.phase, expected)
    assert.equal(outcome.error.cause, failure, 'retain the same Error object, including its stack and cause')
    assert.equal(failure.cause, cause)
    assert.match(outcome.reason, new RegExp(`original-${phase}`))
    if (expected !== 'identity') assert.doesNotMatch(outcome.reason, /会话归属/)
    instance.settleToolExecution(key)
    await instance.settle('s')
    assert.ok(reported.includes(failure), 'the logger receives the original exception rather than only its message')
  })
}

test('serialization failure settles preparation with the original parse error', async t => {
  const instance = runtime(t)
  instance.registerSource({ sourceId: 'policy', plugin: 'test', revision: 1, rules: [denyRule('rule-denial')] })
  const args: { self?: object } = {}
  args.self = args
  const key = {}
  await instance.prepareToolExecution({ key, sessionId: 's', name: 'blocked', arguments: args, callId: 'cyclic', rootCallId: 'cyclic' })
  const outcome = instance.decideToolExecution(key)
  assert.ok(outcome.kind === 'deny' && outcome.error)
  assert.equal(outcome.error.phase, 'parse-failed')
  assert.ok(outcome.error.cause instanceof TypeError)
  assert.match(outcome.reason, /circular/i)
  assert.doesNotMatch(outcome.reason, /会话归属/)
})

for (const exit of exits) {
  test(`工具调用的每条出口都有结论：${exit.name}`, async t => {
    const instance = runtime(t, exit.options)
    const handle = instance.registerSource({ sourceId: 'policy', plugin: 'test', revision: 1,
      ...(exit.scope === undefined ? {} : { scope: exit.scope }), rules: exit.rules ?? [denyRule('不得删除文件')] })
    const outcome = await (exit.drive ?? (instance => call(instance, 'read')))(instance, handle)
    assert.equal(reason(outcome), exit.expected)
  })
}
