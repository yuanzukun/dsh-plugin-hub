import { ScopedPromptConfig, selectScopedPrompts, loopNeedsReminder, REWRITER_NAME, createStreamWatch, createStreamNoticeActions, shouldNotify, planDeliveryInputs, collectDeliveryInputs, filterDeliveryMessages } from '@leolee9086/dsh-rule-engine'
import { z } from 'zod'
import { ensureSessionLog } from '../lib/session-log.js'
import { snoozeOutput, snoozeResult } from '../lib/reminder-runtime/snooze.js'
import { createUserMessage } from './message.js'
import { producedBy, producerKind } from './producer-source.js'
import { calculateState, GUIDANCE, renderState, resolveConfig } from './policy.js'
import { createMaintenanceController, pruneThenMeasure } from './maintenance-policy.js'
import { contextBudget, budgetPolicy } from './context-budget.js'
import { recoveryProof } from './recovery-proof.js'
import { captureInputPricing } from './input-pricing.js'
import { createSummaryExecutor } from './summary-executor.js'
import { repairSummaryImages } from './image-repair.js'
import { runMaintenance } from './maintenance-journal.js'
import { createMaintenanceOperations } from './maintenance-operations.js'

import { contextCareProjection } from './projection.js'
import { selectClearRange, selectRestRange, selectMaintenanceRange } from './selection.js'
import { createProposalExecutor } from './summary-proposals.js'
import { maintenancePassLimit } from './summary-request.js'
import { clearRange } from './deep-rest.js'
import { alreadyWarned, detectLoop, loopNoticeText } from './loop-guard.js'

import { installNoticeRules } from './notice-rules.js'
import { NOTICE_CHANNEL, sharedNoticeChannel } from './notice-channel.js'
import { lastAssistantMessage, lastAssistantText, lastUserMessage, textOf } from './prompt-text.js'
import { createRequestRewriter } from './request-rewrite.js'
import { createTransformLog } from './transform-log.js'
import { createRewriteJournal } from './rewrite-journal.js'
import { CARE_SOURCE, LOOP_IDS, runtimeControlSource, legacyControlSource, controlledEngineRules, controlledGuidance, controlledState } from './control-catalog.js'

export const name = 'dsh-context-care'
export const inject = ['agents', 'sessions', 'tools', 'systemPrompt', 'tokenMeter', 'llm', 'compaction', 'sessionProjections', 'contextCareRequests']
// Standard Schema is consumed by Cordis before activation; no DSH schema helper.
export const Config = z.object({
  budgetRatio: z.number().optional(), wakefulnessRatio: z.number().optional(),
  fatigueExponent: z.number().optional(), retainRatio: z.number().optional(),
  rangeStrategy: z.enum(['basic-prefix', 'target-prefix']).optional(), expectedCheckpointTokens: z.number().int().nonnegative().optional(),
  minFreshTokens: z.number().int().optional(), minNoteChars: z.number().int().optional(), maxNoteChars: z.number().int().optional(),
  softBudgetRatio: z.number().optional(), hardBudgetRatio: z.number().optional(),
  hysteresisRatio: z.number().optional(), maxPasses: z.number().int().optional(),
  auxiliaryBudgetRatio: z.number().optional(),
  modelScopedPrompts: z.array(ScopedPromptConfig).optional(),
  maxSummaryRepairRetries: z.number().int().nonnegative().optional(), maxSummaryCallsPerAction: z.number().int().positive().optional(),
  summary: z.object({ provider: z.string().min(1).optional(), model: z.string().min(1).optional(),
    maxTokens: z.number().int().positive().optional(), maxRetries: z.number().int().nonnegative().optional() }).strict().optional(),
  safetyTokens: z.number().int().nonnegative().optional(), burstTokens: z.number().int().nonnegative().optional(),
  releaseMarginTokens: z.number().int().nonnegative().optional(), summarySafetyTokens: z.number().int().nonnegative().optional(),
  maxOverflowRetries: z.number().int().nonnegative().optional(), retainTokens: z.number().int().nonnegative().optional(),
  contextBudgetTokens: z.number().int().positive().optional(), billingInputCeilingTokens: z.number().int().positive().optional(),
  routeBudgets: z.array(z.object({ provider: z.string().min(1), model: z.string().min(1), purpose: z.enum(['conversation', 'compaction', 'session-title']),
    contextBudgetTokens: z.number().int().positive().optional(), billingInputCeilingTokens: z.number().int().positive().optional() }).strict()).optional(),
}).strict().prefault({})

const requestPlugin = `${name}:request`
const statePlugin = `${name}:state`
const loopPlugin = `${name}:loop`
/** 每个流式模式一个独立的 plugin 标识 —— alreadyWarned 据此按模式去重。 */
const watchPlugin = triggerId => `${name}:watch:${triggerId}`

function notice(plugin, text, summary, state, extra) {
  return createUserMessage({
    content: [{ type: 'text', text }],
    source: { kind: producerKind(plugin), form: 'notice', summary,
      ...(state ? { contextCare: { fatigueValue: state.fatigueValue, wakefulnessValue: state.wakefulnessValue } } : {}),
      ...extra,
    },
  })
}

/**
 * 时间规划提醒：词表命中只说明出现了相关措辞，不能判断任务有没有期限。
 * 真人给出的期限和已提供的时间可用于规划；未提供的运行额度仍应按未知处理。
 * Seraph 是所参考的 S-forge 提醒名称，不表示接入了心理医生服务。
 */
function timeAnxietyText() {
  return [
    '<context-care>',
    '[Seraph · 上下文照料提醒]',
    '',
    '如果正在规划时间与调用次数，请核对依据：',
    '真人明确给出的期限、当前时间和已知运行限制可以用于规划；未提供的剩余运行额度按未知处理。',
    '依据实际目标、工作进度和验证需求安排下一步；需要整理上下文时，保存交接并在合适的工作边界处理。',
    '</context-care>',
  ].join('\n')
}

/**
 * 上下文规划提醒，使用最近一次状态报告的估计，不据词表命中推断心理状态。
 * 流式广播同步读取 previousState；缺少数值时提示查询当前计量。
 */
function contextAnxietyText(state) {
  const measured = Number.isFinite(state?.fatigueValue) && Number.isFinite(state?.wakefulnessValue)
  return [
    '<context-care>',
    '[Seraph · 上下文照料提醒]',
    '',
    '如果你正在盘算上下文还剩多少，先看这个盘算的依据：',
    measured
      ? `上下文占用是有测量的——最近一次报告为 fatigue ${state.fatigueValue}%、wakefulness ${state.wakefulnessValue}%。`
      : '上下文占用是有测量的，随时可以调用 context_status 查看。',
    '这些指标是请求负载与留存信息量的估计。结合实际工作步骤、当前计量、交接和找回路径安排整理时机。',
    '压缩前把当前目标、已验证结果、未完成工作和关键路径记清；原始细节可从会话日志或检查点核对。',
    '维护完成后核对报告，再继续任务。',
    '</context-care>',
  ].join('\n')
}

/**
 * 每个模式命中后要说的话。模式只交证据，措辞在这里定 ——
 * 所以加一种检测方式时，要么复用已有文案，要么在这里加一行。
 */
export const WATCH_NOTICES = {
  'line-repeat': { summary: 'Output loop aborted', text: hit => loopNoticeText(hit, true) },
  'time-anxiety': { summary: 'Time planning reminder', text: () => timeAnxietyText() },
  // 上下文长度焦虑：文案要用最近一次状态报告里的数值给证据，所以接第二个参数。
  'context-anxiety': { summary: 'Context planning reminder', text: (_hit, state) => contextAnxietyText(state) },
}

/** Read only the latest retained state; no process-local state can leak across sessions. */
export function previousState(session, history) {
  const values = history.projectSurface(session, previousState, ({ event }) => {
    if (event.type !== 'user/message' || !producedBy(event.data.source, statePlugin)) return []
    const message = history.messageAt(session, event.seq)
    return [{ text: textOf(message), fatigueValue: message.source.contextCare?.fatigueValue,
      wakefulnessValue: message.source.contextCare?.wakefulnessValue }]
  }, true)
  return values.at(-1)
}

/**
 * Notify only when the model-visible status or outcome changes.
 *
 * Numeric values live in source metadata for the UI; the model-facing text deliberately
 * contains only grades and guidance. A numeric-only change therefore adds no information
 * to the model, but it does append another user message and can make the status look like
 * a countdown. Keep the notification keyed to the text the model can actually read.
 */


/** Attach tools and durable boundary-time status, leaving the compaction provider unchanged. */
export function apply(ctx, raw = {}) {
  return installContextCare(ctx, raw, ctx.compaction)
}

/**
 * Shared installer. `compactionSource` is either the compaction provider itself
 * (the agent-scoped `/agent` entry, where the service is already scoped) or a
 * resolver `agent => provider | undefined` (the root entry, where the provider
 * differs per agent and is resolved at the boundary that uses it).
 */
/** 有限数原样返回,其它一律 null —— 表示"此刻不可知",不是 0。 */
function finiteOrNull(value) {
  return typeof value === 'number' && Number.isFinite(value) ? value : null
}

/** 最后一个已开始的轮号;一个都没有时给 null。 */
function lastTurnNumber(log) {
  const event = log.last('turn/start')
  return event?.type === 'turn/start' && Number.isFinite(event.data.turn) ? event.data.turn : null
}

/**
 * 把这一轮的实测值摊成规则能用的指标。
 *
 * **键名是跨插件的契约**:写规则的插件按这些名字用 when.numbers。只增不改 ——
 * 改名等于改了契约,得先跟用它的人说。引擎不认识这些名字,它只按 key 取值比较。
 *
 * 算不出来的给 null(finiteOrNull),**不给 undefined**:后者会被引擎当成
 * "规则写错或调用方漏填"而抛错,连累同一批里别的规则。
 *
 * @param {object|undefined} current sample() 的结果。
 * @param {import('../lib/session-log.js').SessionLogRead} log 当前日志视图,只读取最近轮次。
 * @returns {object} 指标名 → 有限数或 null。
 */
function careFacts(current, log) {
  const state = current?.state ?? {}
  const measurement = current?.measurement
  return {
    fatigue: finiteOrNull(state.fatigueValue),
    wakefulness: finiteOrNull(state.wakefulnessValue),
    totalTokens: finiteOrNull(measurement?.totalTokens),
    surfaceTokens: finiteOrNull(measurement?.surfaceTokens),
    // 轮次跟时间无关,所以「聊了 N 轮还没记东西」这类判据在从没记过的会话上也成立 ——
    // 这正是 idle 那条规则漏掉的情况。
    turns: finiteOrNull(lastTurnNumber(log)),
  }
}
export function installContextCare(ctx, raw, compactionSource) {
  const resolveCompaction = typeof compactionSource === 'function' ? compactionSource : () => compactionSource
  const spec = resolveConfig(raw)
  const engine = ctx.contextCareRequests.engine
  const controls = ctx.contextCareRequests.controls
  const enabled = (sessionId, ruleId, actionId) => controls.enabled(String(sessionId), CARE_SOURCE, ruleId, actionId)
  const stateText = (agent, state, outcome, explicit = false) => controlledState(state, outcome,
    (ruleId, actionId) => enabled(agent.session.id, ruleId, actionId), explicit)
  const operations = createMaintenanceOperations()
  ctx.effect(() => () => operations.dispose())
  const history = ensureSessionLog(ctx)
  const compactSummary = createSummaryExecutor({ meter: ctx.tokenMeter, llm: ctx.llm, requests: ctx.contextCareRequests, spec, history,
    eligible: (agent, reason) => reason === 'requested' || enabled(agent.session.id, reason === 'overflow' ? 'overflow' : 'maintenance', 'summary'),
    recover: payload => ctx.waterfall('compaction/summary-error', payload, () => false)
      || repairSummaryImages(ctx.sessions, payload, history) })
  const executeProposal = createProposalExecutor(ctx.contextCareRequests, compactSummary, history)
  const propose = (agent, current, allowFallback) => history.withLive(agent.session, log => selectMaintenanceRange(agent.session, current.measurement, {
    // 容量未知只让压力预估不可用。主动请求仍可按显式尾部设置选区，
    // 缺省保留最近完整单元，再由摘要路由或自定义 provider 处理实际输入。
    retainTokens: current.budget?.retainTail ?? spec.retainTokens ?? 0, minFreshTokens: spec.minFreshTokens, pluginName: name,
    deficitTokens: current.loadTokens === undefined || current.budget?.releaseTarget === undefined
      ? 0 : Math.max(0, current.loadTokens - current.budget.releaseTarget), rangeStrategy: spec.rangeStrategy,
    expectedCheckpointTokens: spec.expectedCheckpointTokens, allowFallback,
  }, log))
  const maintain = (session, pricing, action, reason, run) => runMaintenance({ requests: ctx.contextCareRequests, session, pricing, action, reason, run, history })
  const prune = (agent, pricing, reason) => {
    const pruner = resolvePruner(agent)
    return pruner === undefined ? undefined : { pruneSession: session => maintain(session, pricing, 'prune', reason, () => {
      if (reason !== 'requested' && !enabled(session.id, reason === 'overflow' ? 'overflow' : 'maintenance', 'prune')) return undefined
      return pruner.pruneSession(session)
    }) }
  }
  if (typeof ctx.tokenMeter.estimateMessage !== 'function') {
    throw new Error('context-care requires the public tokenMeter.estimateMessage estimator')
  }
  // This gate is the only automatic maintenance decision in context-care. The
  // Basic backend is configured with auto:false in the authored composition so
  // it remains an executor for explicit requests, never a second controller.
  const maintenanceBySession = new WeakMap()
  function maintenanceFor(session) {
    let controller = maintenanceBySession.get(session)
    if (controller === undefined) {
      controller = createMaintenanceController({
        softBudgetRatio: spec.softBudgetRatio,
        hardBudgetRatio: spec.hardBudgetRatio,
        hysteresisRatio: spec.hysteresisRatio,
        maxPasses: spec.maxPasses,
        auxiliaryBudgetRatio: spec.auxiliaryBudgetRatio,
      })
      maintenanceBySession.set(session, controller)
    }
    return controller
  }
  const resolvePruner = agent => ctx.get('agentPresets')?.serviceFor(agent, 'toolResultPruner') ?? ctx.get('toolResultPruner')
  ctx.effect(() => ctx.sessionProjections.register(contextCareProjection))
  ctx.effect(() => ctx.systemPrompt.context({ name, order: 90, text: ({ scope }) => scope?.session === undefined ? GUIDANCE
    : controlledGuidance((ruleId, actionId) => enabled(scope.session.id, ruleId, actionId)) }))

  // ---------------------------------------------------------- 提示规则
  //
  // 规则由别的插件声明(索引插件的 memoryNoticeRules 服务)。
  // 引擎库负责判定、冷却与命中证据；本插件提供原生事实并创建提醒消息。
  // ---------------------------------------------------------- 变换记录
  //
  // Evaluations attached to delivered notices already live in the Session log; runtime diagnostics use the logger.
  const transformLog = createTransformLog({ ctx })
  // 改写由本插件的 Host 持久域保管，不依赖可选索引服务。
  // 索引属性表仍可写副本用于 JOIN；在调用边界现取，允许它晚于本插件注册。
  const rewriteJournal = createRewriteJournal({
    logs: history, owner: id => ctx.sessions.get(id),
    store: () => ctx.get('sessionBlockQuery'),
    durable: {
      put(entry) {
        const session = ctx.sessions.get(entry.sessionId)
        if (!session) throw new Error(`context-care: rewrite session unavailable: ${entry.sessionId}`)
        return ctx.contextCareRequests.recordAction(session, { action: 'request-rewrite', phase: 'recorded', rewrite: entry })
      },
      async list(sessionId) {
        return ctx.contextCareRequests.rewriteRecords(sessionId)
      },
    },
    warn: message => ctx.logger.warn(message),
  })
  ctx.effect(() => () => rewriteJournal.close())
  /** 运行诊断写 logger；已投递提示的依据由消息中的 contextCareTrace 保留。 */
  const recordHit = (layer, record, where) => transformLog.record({ ...record, ...where, layer })

  const noticeRules = installNoticeRules(ctx, {
    engine,
    plugin: name, history,
    rulesFor: (sessionId, evidence) => controlledEngineRules(controls, String(sessionId), 'notify', evidence),
    onHit: (record, where) => recordHit('notice', record, where),
  })

  // ---------------------------------------------------------- 通知通道
  //
  // 通用通道:别的插件有话要告诉模型时,注册一个源;这里在每个请求边界问一遍。
  // 通道不认识「召回」「分数」这些东西 —— 它只知道要通知什么、什么时候能通知。
  const noticeChannel = sharedNoticeChannel({ engine, warn: message => ctx.logger.warn(message) })
  // 两个入口都会跑到这里,而服务名只有一个 —— 已经有了就不再注册。
  // 注册两次会让插件的 agent 行挂载失败(见 notice-channel.js 里的报错原文)。
  if (ctx.get(NOTICE_CHANNEL) === undefined) {
    ctx.provide(NOTICE_CHANNEL, { register: noticeChannel.register })
  }

  // ---------------------------------------------------------- 循环清理
  //
  // 输出循环的清理改在**请求层**执行(2026-09-23):执行点就是下面 requestRewrite
  // 登记的那个改写器 —— 请求体里就是完整 messages,上一轮助手输出在里面,
  // 这正是 pre-step 够不着的部分。清理不写任何会话事件:
  // 自定义事件被 DSH 读侧校验否决(重启拒载),而且清理本来也不需要事件 ——
  // 它只是"这一次不把循环发出去",日志原文不动。
  // 判定逻辑在 loop-clean.js(模式表);loop-clean-projection.js 的 pendingLoopClean
  // 保留但已不再被引用;投影注册不再需要 —— 投影靠决策事件驱动,没有事件就没载体。

  // ---------------------------------------------------------- 请求层篡改
  //
  // 篡改的执行在请求层,那里看得见整段组装好的请求体。执行者由别的插件提供
  // (fetch-router 的 requestRewrite 服务);没装就没有执行者,篡改规则不生效,
  // 引擎会在 gate 阶段判掉并留下 no-consumer 记录 —— 请求保持原样。
  // 清理执行者在不在：严重档的兜底提醒要用它（见 loop-guard.js 的 loopNeedsReminder）——
  // fetch-router 没装或没启用时这段 inject 不会跑，严重循环就清不掉，那就必须提醒，
  // 不能既不清也不说。
  let cleanupActive = false
  ctx.inject(['requestRewrite'], (scope) => {
    const rewrite = createRequestRewriter({
      engine,
      // 跟提醒规则共用一个服务:规则里用 placement 区分它该在哪一层生效。
      rules: sessionId => controlledEngineRules(controls, sessionId, 'transform'),
      cleanPatterns: sessionId => {
        const session = ctx.sessions.get(sessionId)
        const seq = session === undefined ? undefined : history.lastSurface(session, 'assistant/message')?.seq
        return LOOP_IDS.filter(id => enabled(sessionId, `loop-${id}`, 'clean')
          && (controls.sinceSeq(sessionId, CARE_SOURCE, `loop-${id}`) < 0 || seq > controls.sinceSeq(sessionId, CARE_SOURCE, `loop-${id}`)))
      },
      revision: sessionId => JSON.stringify([controls.revision(sessionId), controls.epoch(sessionId, CARE_SOURCE, 'state')]),
      // 改写记录必须交给改写器,否则被改过的文本在界面上看不出来 ——
      // 卡片认的是内容哈希,哈希只有改写器算得出来。
      journal: rewriteJournal,
      onRecord(record, where) {
        recordHit('request', record, where)
        if (record.outcome !== 'applied') {
          ctx.logger.warn(`context-care: 请求层规则 ${record.ruleId} 未生效(${record.outcome})${record.detail === undefined ? '' : ': ' + record.detail}`)
          return
        }
        ctx.logger.info(`context-care: 请求层改写 ${record.ruleId},废掉 ${(record.loss * 100).toFixed(2)}% 缓存`)
      },
    })
    const dispose = scope.requestRewrite.register(REWRITER_NAME, rewrite)
    cleanupActive = true
    ctx.effect(() => () => { cleanupActive = false })
    return dispose
  })

  // ---------------------------------------------------------- 流式监视
  //
  // 「检测模式 → 执行操作」两段式：stream-watch 只管维护视图和调度，
  // 判定由模式（DETECTORS）负责，行为由下面的 actions 表负责。这里不认识"循环"。
  //
  // 与下面 pre-step 那条事后路径的分工：
  //   · 流式路径抢在生成过程中动手，命中的那一轮当场掐断，不会再刷屏；
  //   · pre-step 路径是兜底 —— 阈值没到、或者哪个模式没命中，下一个请求边界仍会提醒一次。
  // 两条路共用同一份文案；窗口参数共用 stream-watch 的常量，只有阈值不同：
  // 掐断宁可漏也不误杀（长清单、代码、表格都可能出现稀疏重复）。
  // 词表/阈值与文案属于声明；去重、续接额度及动作顺序由库管理。
  const streamNotices = createStreamNoticeActions({
    maxAutoResume: 1,
    key: agent => String(agent.id),
    epoch: (agent, trigger) => controls.epoch(String(agent.session.id), CARE_SOURCE, `stream-${trigger.id}`),
    enabled: (agent, trigger, actionId) => enabled(agent.session.id, `stream-${trigger.id}`, actionId),
    available: trigger => WATCH_NOTICES[trigger.id] !== undefined,
    notice({ agent, trigger, hit }) {
      const wording = WATCH_NOTICES[trigger.id]
      const state = agent.session === undefined ? undefined : previousState(agent.session, history)
      agent.inject(notice(watchPlugin(trigger.id), trigger.id === 'line-repeat' ? loopNoticeText(hit, false) : wording.text(hit, state),
        trigger.id === 'line-repeat' ? 'Output loop detected' : wording.summary, undefined,
        { contextCareTrace: { trigger: 'stream-watch', detector: trigger.id, evidence: hit } }))
    },
    abort({ agent, hit }) {
      agent.cancel({ kind: 'hook', reason: `output loop: ${hit.line}` }, { keepInbox: true })
    },
    resume({ agent, trigger, hit, includeNotice }) {
      const wording = WATCH_NOTICES[trigger.id]
      const text = includeNotice ? wording.text(hit)
        : '上一轮输出因循环已中止，现在续接任务。'
      agent.steer(notice(watchPlugin(trigger.id), text, wording.summary, undefined,
        { contextCareTrace: { trigger: 'stream-resume', detector: trigger.id, evidence: hit } }))
    },
  })

  const streamWatch = createStreamWatch({
    enabled: (agent, trigger, actionId) => enabled(agent.session.id, `stream-${trigger.id}`, actionId),
    epoch: (agent, trigger) => controls.epoch(String(agent.session.id), CARE_SOURCE, `stream-${trigger.id}`),
    triggers: [
      {
        id: 'line-repeat',
        kind: 'line-repeat',
        scope: 'combined',
        everyBytes: 300,
        minLines: 30,
        minCount: 30,
        minRatio: 0.35,
        minRun: 12,
        actions: ['notice', 'abort', 'resume'],
      },
      {
        // 时间焦虑：只认思考块 —— 正文里讨论「时间成本」是正常讨论。
        // 词表刻意避开「尽快」「赶紧」这类泛词：它们在正常的任务描述里太常见，会误杀。
        id: 'time-anxiety',
        kind: 'phrase',
        scope: 'reasoning',
        phrases: [
          '时间不够', '时间有限', '时间不多', '时间紧迫', '没时间了', '来不及',
          '加快速度', '得加快', '抓紧时间', '节省时间', '浪费时间', '太耗时', '时间成本',
        ],
        // 只提醒，不掐断：时间焦虑不会毁掉这一轮的产出，掐断反而会打断本来正确的作答。
        // 需要中止的是循环 —— 那种输出会一直刷到把整屏烧完。
        actions: ['notice'],
      },
      {
        // 上下文长度焦虑：同样只认思考块 —— 正文里讨论上下文占用、压缩策略是正常工作。
        //
        // 词表只收**把资源当威胁**的表述，不收**把资源当工具**的表述：
        //   · 盘算余量（上下文不够 / 快满 / 压力 / 成本）—— 跟"时间不够"对称；
        //   · "抢在某个事件之前"的结构（趁还没压缩 / 免得被压缩）。
        // 刻意**不**收「该压缩了」这类 —— 主动压缩是健康行为，把工具当工具用不该被监控，
        // 把工具当成要躲的事件才该。判据是施动者：我是施动者就正常，压缩成了施动者才是歪曲。
        id: 'context-anxiety',
        kind: 'phrase',
        scope: 'reasoning',
        phrases: [
          '上下文不够', '上下文有限', '上下文不多', '上下文快满', '上下文紧张', '上下文吃紧',
          '上下文压力', '上下文成本', '节省上下文', '省点上下文', '会话太长',
          '趁还没压缩', '趁压缩之前', '趁上下文还够', '免得被压缩',
        ],
        // 只提醒，不掐断：跟时间焦虑同理，它不会毁掉这一轮的产出。
        actions: ['notice'],
      },
    ],
    actions: streamNotices.actions,
    onError(error, context) {
      ctx.logger.warn(`context-care: stream-watch ${context}: ${error instanceof Error ? error.message : String(error)}`)
    },
  })

  ctx.effect(() => ctx.on('agent/assistant-stream', ({ agent, frame }) => {
    // 一个会话只由一个实现监视。预设里挂了 `/agent` 入口时，作用域注册会遮蔽全局注册，
    // 根实现必须退让 —— 否则两个实例各注入一条一模一样的提醒。pre-step 那条路早就有这个
    // 退让，流式这条路一开始漏了，实测出来的现象就是「每次命中都收到两条」。
    if (typeof ctx.tools.get === 'function') {
      const visible = ctx.tools.get('context_rest', agent)
      if (visible !== undefined && visible !== contextRestTool) return
    }
    streamWatch.observe(agent, frame)
  }))

  // ------------------------------------------------------ 思考档位降档
  //
  // 【暂未启用，整段注释】哥哥的诊断：DeepSeek V4 Flash 开 max 思考时容易进输出循环，
  // 压缩 + 切 high 聊几轮就能恢复。所以循环被掐断之后，接下来几轮应该临时降档。
  //
  // 先注释掉的原因：`agent/request` 是 waterfall，返回改过的 LlmCallConfig，
  // 但**还没实测**它会不会被后面的 resolveCallConfig 覆盖。验证通过再启用。
  // 另外 call-config.ts 的注释写明 reasoningEffort 属于 request-header 状态，
  // 改它会让这次请求的 header 快照变化、缓存复用断一次 —— 所以只在真掐断过之后才动它。
  //
  // const downgrades = new Map()
  // /** 降到哪一档，以及维持几轮。 */
  // const DOWNGRADE_TO = 'high'
  // const DOWNGRADE_ROUNDS = 3
  //
  // // abort 里登记：downgrades.set(key, { to: DOWNGRADE_TO, remaining: DOWNGRADE_ROUNDS })
  // ctx.effect(() => ctx.on('agent/request', async ({ agent }, next) => {
  //   const config = await next()
  //   const key = String(agent.id)
  //   const pending = downgrades.get(key)
  //   if (pending === undefined || config.reasoningEffort === undefined) return config
  //   if (pending.remaining <= 0) {
  //     downgrades.delete(key)
  //     return config
  //   }
  //   // 当前档位已经不是我们设的那个，说明用户或别的插件改过 —— 以他们为准，放弃恢复。
  //   if (pending.expected !== undefined && config.reasoningEffort !== pending.expected) {
  //     downgrades.delete(key)
  //     return config
  //   }
  //   pending.remaining -= 1
  //   pending.expected = pending.to
  //   return { ...config, reasoningEffort: pending.to }
  // }))

  async function sample(agent, signal, proposed = [], includeState = false, operation) {
    signal.throwIfAborted()
    const pricing = operation ?? captureInputPricing({ history, meter: ctx.tokenMeter, llm: ctx.llm, session: agent.session, requests: ctx.contextCareRequests })
    const measurement = pricing.measure()
    const config = pricing.pricingBasis.header?.config
    // The first envelope has no routed capacity; final dispatch owns its check.
    if (!config?.provider || !config.model) return { state: { fatigue: 'unknown', fatigueValue: null, wakefulness: 'unknown', wakefulnessValue: null }, measurement }
    const info = await ctx.llm.resolveModelInfo(config.provider, config.model, signal)
    signal.throwIfAborted()
    const physicalCapacity = info.context?.contextWindow
    const policy = budgetPolicy(spec, config)
    const incoming = pricing.priceMessages(proposed)
    // Output accounting is diagnostic only. The meter owns text calibration,
    // including large valid ratios; pending inputs use that same frozen basis.
    const retained = measurement.surfaceTokens
    const baseRequest = { ...config, purpose: 'conversation', messages: [...history.messages(agent.session), ...proposed],
      tools: pricing.pricingBasis.header?.tools }
    const preview = ctx.contextCareRequests.preview?.(agent.session, baseRequest).request ?? baseRequest
    const promptCost = pricing.priceRequest(preview) - pricing.priceRequest(baseRequest)
    let load = Math.ceil(measurement.inputTokens + incoming + promptCost)
    if (includeState) {
      const capacity = Math.min(...[physicalCapacity, policy.contextBudgetTokens].filter(value => value !== undefined))
      const state = calculateState(load, retained, Number.isFinite(capacity) ? capacity : undefined, spec)
      const text = stateText(agent, state)
      if (text && shouldNotify(previousState(agent.session, history), text, state)) load = Math.ceil(load + pricing.priceMessages([notice(statePlugin, text, 'Context state', state)]))
    }
    const budget = contextBudget({ inputTokens: load, physicalCapacity, policyCapacity: policy.contextBudgetTokens,
      billingInputCeilingTokens: policy.billingInputCeilingTokens, maxTokens: config.maxTokens, defaultMaxTokens: info.defaultMaxTokens,
      safetyTokens: spec.safetyTokens, burstTokens: spec.burstTokens, releaseMarginTokens: spec.releaseMarginTokens,
      softRatio: spec.budgetRatio, retainRatio: spec.retainRatio, retainTokens: spec.retainTokens })
    return {
      state: calculateState(load, retained, budget.capacity, spec),
      measurement,
      budget,
      capacity: budget.capacity,
      loadTokens: load,
    }
  }

  const contextStatusTool = {
    name: 'context_status',
    description: '读取实测的上下文疲劳度与唤醒值。这些是估计，不是记忆丢失的诊断，也不是任务的截止时间。用来判断一次检查点有没有用；不要反复轮询。',
    parameters: { type: 'object', properties: {}, additionalProperties: false },
    output: { schema: { type: 'string' }, render: (_args, text) => [{ type: 'text', text }] },
    async execute(args, exec) {
      if (!args || typeof args !== 'object' || Array.isArray(args) || Object.keys(args).length) throw new Error('context_status 只接受一个空对象')
      if (!exec.agent) throw new Error('context_status 需要一个所属会话')
      const { state } = await sample(exec.agent, exec.signal)
      controls.sample(String(exec.agent.session.id), state)
      return stateText(exec.agent, state, undefined, true)
    },
    presentCall: () => ({ card: 'generic', title: 'Context state', kind: 'read' }),
  }

  // 模型不擅长精确计数：提示以 8000 字符为目标，内部保留默认 10000 的宽限。
  // 不把提示上限写成 JSON Schema maxLength，否则前置校验会吃掉执行层的宽限。
  const notePromptMaxChars = Math.min(spec.maxNoteChars, Math.max(8000, spec.minNoteChars))
  const contextRestTool = {
    name: 'context_rest',
    description: '在下一个安全的请求边界请求一次历史压缩，即使还没到自动压力阈值。给一段交接笔记（宜细不宜粗）；近况和这条笔记会留下来。这只是排定压缩，不会删除文件、不会结束任务，也不是睡眠计时器。按报告出来的结果继续。deep 为真时历史是被清空而不是被摘要，只剩笔记和找回路径。',
    parameters: {
      type: 'object', additionalProperties: false, required: ['note'],
      properties: {
        // 下限不是防呆，是**要求写细**：几百字的笔记下一个自己还得回去翻日志。
        note: { type: 'string', minLength: spec.minNoteChars, description: `交接笔记：当前目标、已验证的进度、没做完的工作、重要路径。${spec.minNoteChars}~${notePromptMaxChars} 字符，宜细不宜粗；不可复原的细节先落盘到文件。` },
        deep: { type: 'boolean', description: '用完整交接与找回路径替换历史而不调用摘要模型。替换必须比所选历史更小；保留的正文量和负载会重新计量。身份、目标与判断归属保持原有设定，缺失细节从原始日志或检查点核对。' },
        recovery: { type: 'string', minLength: spec.minNoteChars, description: `deep 为真时必填。下一个你怎样把细节找回来：用哪些关键词搜会话日志、读哪些文件、任务材料放在哪里。要写搜索真能命中的词、真存在的路径。${spec.minNoteChars}~${notePromptMaxChars} 字符。` },
      },
    },
    output: { schema: { type: 'string' }, render: (_args, text) => [{ type: 'text', text }] },
    async execute(args, exec) {
      if (!exec.agent) throw new Error('context_rest 需要一个所属会话')
      exec.signal.throwIfAborted()
      const keys = args && typeof args === 'object' && !Array.isArray(args) ? Object.keys(args) : []
      if (keys.some(key => key !== 'note' && key !== 'deep' && key !== 'recovery')) throw new Error('context_rest 只接受 note、deep 和 recovery 三个参数')
      // 长度**按 trim 后算**：一串空白不算"写细了"。
      // 下限是要求（宜细不宜粗），不是防呆 —— 几百字的笔记下一个自己还得回去翻日志。
      const noteLength = typeof args?.note === 'string' ? args.note.trim().length : 0
      if (noteLength < spec.minNoteChars || noteLength > spec.maxNoteChars) {
        throw new Error(`context_rest 的 note 需要 ${spec.minNoteChars}-${notePromptMaxChars} 个字符（宜细不宜粗），实际 ${noteLength} 个`)
      }
      const deep = args.deep === true
      const recovery = args.recovery
      const recoveryLength = typeof recovery === 'string' ? recovery.trim().length : 0
      if (recovery !== undefined
        && (typeof recovery !== 'string' || recoveryLength < spec.minNoteChars || recoveryLength > spec.maxNoteChars)) {
        throw new Error(`context_rest 的 recovery 需要 ${spec.minNoteChars}-${notePromptMaxChars} 个字符的字符串（宜细不宜粗），实际 ${recoveryLength} 个`)
      }
      if (deep && (typeof recovery !== 'string' || recovery.trim().length === 0)) throw new Error('deep 为真时 context_rest 需要 recovery：历史被清空之后，那段文字是下一个请求把细节找回来的唯一途径')
      const sections = [`历史压缩的交接笔记（你自己写的）：\n${args.note}`]
      if (typeof recovery === 'string' && recovery.trim().length > 0) {
        sections.push(`被清空历史的找回路径（你自己写的）：\n${recovery}`)
      }
      // Inbox insertion is durable. All calls in this batch settle before pre-step claims it.
      exec.agent.inject(notice(requestPlugin, sections.join('\n\n'),
        deep ? 'Deep rest requested' : 'History compaction requested', undefined,
        { contextRest: { deep }, contextCareTrace: { trigger: 'context_rest', deep } }))
      return deep
        ? '深度休息已经排定在下一个请求边界。它还没完成；下一次上下文状态会报告结果。'
        : '历史压缩已经排定在下一个请求边界。它还没完成；下一次上下文状态会报告结果，之后继续任务。'
    },
    presentCall: () => ({ card: 'generic', title: 'Request history compaction', kind: 'other' }),
  }

  ctx.effect(() => ctx.tools.register(contextStatusTool))
  ctx.effect(() => ctx.tools.register(contextRestTool))
  ctx.effect(() => ctx.tools.register({
    name: 'reminder_snooze',
    description: '当人类伙伴说今晚不再提醒时，暂停当前会话的时间窗口提醒，窗口结束后自动恢复。不传标识时暂停所有当前窗口提醒；只暂停一条时同时传 sourceId 和 ruleId。',
    parameters: { type: 'object', additionalProperties: false, properties: {
      sourceId: { type: 'string', minLength: 1 }, ruleId: { type: 'string', minLength: 1 },
    } },
    output: snoozeOutput,
    async execute(args, exec) {
      if (!exec.agent) throw new Error('reminder_snooze 需要一个所属会话')
      exec.signal.throwIfAborted()
      const reminders = ctx.get('reminderRules')
      if (!reminders?.prepareSnooze) throw new Error('当前提醒服务不支持时间窗口暂缓')
      const sessionId = String(exec.agent.session.id)
      const windows = await reminders.prepareSnooze({ sessionId, sourceId: args.sourceId, ruleId: args.ruleId })
      exec.signal.throwIfAborted()
      return snoozeResult(sessionId, windows)
    },
    presentCall: () => ({ card: 'generic', title: '暂停当前窗口提醒', kind: 'other' }),
  }))

  const requestOwner = {
    /** @param {import('@deepseek-ai/dsh-agent').Agent} agent */
    owns: agent => ctx.tools.get('context_rest', agent) === contextRestTool,
    /** @param {import('@deepseek-ai/dsh-session').SessionId} sessionId */
    controlSources(sessionId) {
      const agent = ctx.agents.get(sessionId)
      return [runtimeControlSource({ prompts: spec.modelScopedPrompts, cleanupActive,
        pruner: resolvePruner(agent) !== undefined, compaction: resolveCompaction(agent) !== undefined }),
      legacyControlSource(ctx.get('memoryNoticeRules') ?? [], cleanupActive), ...noticeChannel.catalog()]
    },
    /** @param {string} sessionId */
    promptRulesFor: sessionId => spec.modelScopedPrompts.filter(rule => enabled(sessionId, `prompt:${rule.ruleId}`, 'notice')),
    prompts: spec.modelScopedPrompts.length === 0 ? undefined :
      /** @param {import('@deepseek-ai/dsh-llm').GenerateOptions} request @param {import('@deepseek-ai/dsh-llm').LlmCallConfig | undefined} previousRoute */
      (request, previousRoute) => selectScopedPrompts(requestOwner.promptRulesFor(request.sessionId), request, previousRoute),
    /** @param {import('./request-types.js').RequestCall} call @param {import('./request-types.js').ReadyRequest} ready */
    check(call, ready) {
      const request = ready.request
      const { provider, model, reasoningEffort, temperature, maxTokens } = request
      const header = { config: { provider, model, reasoningEffort, temperature, maxTokens }, tools: request.tools,
        adapterDefaults: call.session.requestHeader()?.adapterDefaults }
      // Bind the final route's attachment prices, including an explicitly absent
      // projection. Middleware route changes cannot reuse the previous route.
      const pricing = captureInputPricing({ history, meter: ctx.tokenMeter, llm: ctx.llm, session: call.session, header,
        imageRequestPricing: ready.imageRequestPricing, requests: ctx.contextCareRequests })
      const inputTokens = pricing.priceRequest(request)
      const policy = budgetPolicy(spec, request, request.purpose ?? 'conversation')
      return { pricing, budget: contextBudget({ inputTokens, physicalCapacity: ready.model.context?.contextWindow, policyCapacity: policy.contextBudgetTokens,
        billingInputCeilingTokens: policy.billingInputCeilingTokens, maxTokens: request.maxTokens, defaultMaxTokens: ready.model.defaultMaxTokens,
        safetyTokens: request.purpose === 'compaction' ? (spec.summarySafetyTokens ?? spec.safetyTokens) : spec.safetyTokens,
        burstTokens: request.purpose === 'compaction' ? 0 : spec.burstTokens, releaseMarginTokens: 0,
        softRatio: spec.budgetRatio, retainRatio: request.purpose === 'compaction' ? 0 : spec.retainRatio,
        retainTokens: request.purpose === 'compaction' ? 0 : spec.retainTokens }) }
    },
  }
  ctx.effect(() => ctx.contextCareRequests.register(requestOwner))

  const overflowRetries = new WeakMap()
  ctx.on('agent/status', ({ agent, status }) => { if (status === 'idle') overflowRetries.delete(agent) })
  ctx.on('agent/assistant-stream', ({ agent, frame }) => {
    if (frame.type !== 'end' || frame.outcome.kind !== 'committed') return
    const outcome = frame.outcome
    const event = history.withLive(agent.session, log => log.at(outcome.seq))
    if (event?.type === 'assistant/message' && !event.data.interrupted) overflowRetries.delete(agent)
  })
  ctx.on('agent/request-error', async ({ agent, failure, signal }, next) => {
    const delegated = await next()
    const requests = ctx.contextCareRequests
    const failed = requests.failed(agent)
    if (failed?.owner !== requestOwner) return delegated
    try {
      if (delegated?.kind === 'retry' || signal.aborted || !['REQUEST_BUDGET_EXCEEDED', 'CONTEXT_WINDOW_EXCEEDED'].includes(failure.code)) return delegated
      if (!['prune', 'summary', 'retry'].some(action => enabled(agent.session.id, 'overflow', action))) return delegated
      const retries = overflowRetries.get(agent) ?? 0
      if (retries >= spec.maxOverflowRetries || failed.dispatchPricing === undefined) return delegated
      overflowRetries.set(agent, retries + 1)
      const session = agent.session
      return await operations.run(session, signal, async signal => {
      try {
        const pruner = enabled(session.id, 'overflow', 'prune') ? prune(agent, failed.dispatchPricing, 'overflow') : undefined
        if (pruner !== undefined) await pruner.pruneSession(session)
        signal.throwIfAborted()
        const compaction = resolveCompaction(agent)
        if (compaction !== undefined && enabled(session.id, 'overflow', 'summary')) {
          const measured = failed.dispatchPricing.measure()
          const range = history.withLive(session, log => selectRestRange(session, measured, 0, 0, name, log))
          if (range !== null) await compactSummary(compaction, { ...range, minFreshTokens: 0 }, agent, signal, failed.dispatchPricing,
            { ...failed.ready.request, messages: history.messages(session) }, { reason: 'overflow', callId: failed.callId })
        }
      } catch (error) {
        if (signal.aborted) throw error
        // A committed prune can still qualify even when summary generation failed.
        ctx.logger.warn(`context-care: overflow maintenance failed: ${error instanceof Error ? error.message : String(error)}`)
      }
      signal.throwIfAborted()
      const proof = history.withLive(session, log => recoveryProof(session, failed, failed.dispatchPricing.priceMessages, log, history.messages(session)))
      if (!proof.progressed) return delegated
      // Keep the exact dispatched one-shot system/tools and replace the
      // logged history, including its system head, just as the Agent does.
      const after = failed.dispatchPricing.priceRequest({ ...failed.ready.request, messages: history.messages(session) })
      if (failure.code === 'REQUEST_BUDGET_EXCEEDED' && after > failed.dispatchBudget.hardInput) return delegated
      return enabled(session.id, 'overflow', 'retry') ? { kind: 'retry' } : delegated
      })
    } finally {
      requests.release(failed.callId)
    }
  }, { prepend: true })

  async function collectInputs(agent, signal, accepted, current) {
    let messages = planDeliveryInputs(accepted)
    const reminders = ctx.get('reminderRules')
    if (reminders) {
      try {
        const sessionId = String(agent.session.id), visible = history.messages(agent.session)
        // Presence reads only the recent log tail; it does not materialize a full-session snapshot.
        const recent = history.live(agent.session)
        try { messages = await collectDeliveryInputs(reminders, { sessionId, events: recent, visible, accepted, signal }) }
        finally { recent[Symbol.dispose]() }
      }
      catch (error) { if (signal.aborted) throw error; ctx.logger.warn(`context-care: 规则提醒收集失败: ${error.message}`) }
    }
    try {
      const facts = ensureSessionLog(ctx).withLive(agent.session, log => careFacts(current, log))
      messages.push(...noticeRules.collect({ agent, messages: accepted, facts }))
    } catch (error) {
      ctx.logger.warn(`context-care: 提示规则没有跑起来: ${error instanceof Error ? error.message : String(error)}`)
    }
    try {
      const user = lastUserMessage(accepted)
      const assistant = lastAssistantMessage(accepted)
      const notices = await noticeChannel.collect({ agentId: agent.id,
        userText: user === undefined ? '' : textOf(user), assistantText: assistant === undefined ? lastAssistantText(agent.session, history) : textOf(assistant), signal }, {
          enabled: (sourceId, ruleId) => controls.enabled(String(agent.session.id), sourceId, ruleId, 'notice'),
          epoch: (sourceId, ruleId) => controls.epoch(String(agent.session.id), sourceId, ruleId),
          sinceSeq: (sourceId, ruleId) => controls.sinceSeq(String(agent.session.id), sourceId, ruleId),
        })
      for (const incoming of notices) messages.push(notice(`${name}:notice:${incoming.source}`, incoming.text, incoming.summary ?? `Notice from ${incoming.source}`, undefined,
        { contextCareTrace: { trigger: 'notice-channel', provider: incoming.source } }))
    } catch (error) {
      if (signal.aborted) throw error
      ctx.logger.warn(`context-care: 通知通道没有跑起来: ${error instanceof Error ? error.message : String(error)}`)
    }
    const assistantSeq = history.lastSurface(agent.session, 'assistant/message')?.seq
    const loop = detectLoop(agent.session, LOOP_IDS.filter(id => enabled(agent.session.id, `loop-${id}`, 'notice')
      && assistantSeq > controls.sinceSeq(String(agent.session.id), CARE_SOURCE, `loop-${id}`)), -1, history)
    if (loopNeedsReminder(loop, loop !== undefined && enabled(agent.session.id, `loop-${loop.pattern}`, 'clean')) && !alreadyWarned(agent.session, loopPlugin, history)) messages.push(notice(loopPlugin, loopNoticeText(loop), 'Output loop detected', undefined,
      { contextCareTrace: { trigger: 'loop-guard', evidence: loop } }))
    return messages
  }

  ctx.on('agent/pre-step', async ({ agent, signal }, next) => {
    const generation = agent.session.surface.replaceGeneration
    // Let normal admission and existing automatic safety compaction settle first.
    const decision = await next()
    if (decision.kind === 'reject' || signal.aborted) return decision
    // 原生边界确认真人输入，库据此重新允许本回合的提醒。
    if (decision.messages.some(message => message.source?.kind === 'user')) streamNotices.humanInput(agent)
    // One implementation owns one agent. When this agent's own scope registered
    // the tool (a preset mounted `/agent`), that scoped registration shadows
    // this global one, and the scoped instance must be the only one notifying
    // and compacting — the root entry stands down instead of doing it twice.
    if (typeof ctx.tools.get === 'function') {
      const visible = ctx.tools.get('context_rest', agent)
      if (visible !== undefined && visible !== contextRestTool) return decision
    }
    return operations.run(agent.session, signal, async signal => {
    const restRequest = decision.messages.find(message => producedBy(message.source, requestPlugin))
    const requested = restRequest !== undefined
    let outcome
    let deepCompleted = false
    let current
    let messages = [...decision.messages]
    try {
      // Completion settlement is emitted asynchronously. Await its journal ACK
      // before freezing maintenance prices; ready-time checks would be too late
      // to plan this boundary with the previous completed request's scale.
      await ctx.contextCareRequests.flush?.(agent.session.id)
      const operation = captureInputPricing({ history, meter: ctx.tokenMeter, llm: ctx.llm, session: agent.session, requests: ctx.contextCareRequests })
      current = await sample(agent, signal, messages, false, operation)
      messages = await collectInputs(agent, signal, decision.messages, current)
      current = await sample(agent, signal, messages, true, operation)
      if (!requested && current.capacity !== undefined && current.loadTokens !== undefined) {
        const maintenanceResult = await pruneThenMeasure({
          session: agent.session,
          measure: async () => {
            const measured = await sample(agent, signal, messages, true, operation)
            return { ...measured, totalTokens: measured.loadTokens ?? measured.measurement.totalTokens }
          },
          pruner: enabled(agent.session.id, 'maintenance', 'prune') ? prune(agent, operation, 'automatic') : undefined,
          controller: maintenanceFor(agent.session),
        })
        current = maintenanceResult.after
        let pressure = maintenanceResult.pressure
        const compaction = resolveCompaction(agent)
        const passLimit = maintenancePassLimit(compaction, agent, raw?.maxPasses, spec.maxPasses)
        let passes = 0
        while (pressure.shouldMaintain && compaction !== undefined && passes < passLimit && enabled(agent.session.id, 'maintenance', 'summary')) {
          const proposal = propose(agent, current, true)
          if (proposal === null) break
          const result = await executeProposal(compaction, proposal, agent, signal, operation, spec, requested ? 'requested' : 'automatic')
          if (result === null) break
          passes += 1
          current = await sample(agent, signal, messages, true, operation)
          pressure = maintenanceFor(agent.session).observeBudget(current.budget)
        }
        if (passes > 0) {
          outcome = pressure.shouldMaintain
            ? `自动维护已执行 ${passes} 次，容量仍在硬预算以上`
            : `自动维护已执行 ${passes} 次，已回到安全预算`
        }
      }
      if (restRequest !== undefined) {
        const deep = restRequest.source.contextRest?.deep === true
        // A delegated summary can satisfy normal rest. Explicit deep rest still
        // owns its handoff and recovery path, even after another replacement.
        if (!deep && agent.session.surface.replaceGeneration !== generation) {
          outcome = '历史已经被本边界的自动维护减少过，不再额外压缩'
        } else if (deep) {
          // 清空不经过 compaction provider：替换物是模型自己写的那条消息，
          // 不需要另起一次 LLM 调用，也就没有"摘要不可能比区间小"那道墙。
          const range = history.withLive(agent.session, log => selectClearRange(agent.session, log))
          if (range === null) {
            outcome = '没有执行——系统提示词之外没有可清空的内容'
          } else {
            const text = restRequest.content.filter(block => block.type === 'text').map(block => block.text).join('\n')
            await maintain(agent.session, operation, 'deep-rest', 'requested', () => history.withLive(agent.session, log => clearRange(agent.session, ctx.tokenMeter, range, text, operation, log)))
            deepCompleted = true
            outcome = '历史已用交接和找回路径替换'
            current = await sample(agent, signal, messages.filter(message => message !== restRequest), true, operation)
          }
        } else {
          const compaction = resolveCompaction(agent)
          if (!compaction) {
            outcome = '没有执行——这个会话没有可用的压缩提供方，历史保留'
          } else {
            const proposal = propose(agent, current, false)
            if (proposal === null) {
              outcome = '没有执行——留存近况之外没有足够大的新鲜前缀或可合并检查点'
            } else {
              const result = await executeProposal(compaction, proposal, agent, signal, operation, spec, requested ? 'requested' : 'automatic')
              outcome = result === null ? '没有执行——同一选区已验证无法缩小，历史保留' : '较早的历史已摘要，近况与交接笔记保留'
              current = await sample(agent, signal, messages, true, operation)
            }
          }
        }
      }
    } catch (error) {
      await ctx.get('reminderRules')?.rollback(String(agent.session.id), messages)
        .catch(failure => ctx.logger.warn(`reminder rollback: ${failure.message}`))
      if (signal.aborted) throw error
      if (!requested) throw error
      ctx.logger.warn(`context-care: ${error instanceof Error ? error.message : String(error)}`)
      outcome = requested ? '请求没有正常结束；不要假定压缩已经完成；再发下一个请求之前先检查检查点' : undefined
      current = { state: { fatigue: 'unknown', fatigueValue: null, wakefulness: 'unknown', wakefulnessValue: null } }
    }
    if (deepCompleted) messages = messages.filter(message => message !== restRequest)
    const commitInputs = filtered => {
      controls.sample(String(agent.session.id), current.state)
      const text = stateText(agent, current.state, outcome, requested)
      const previous = previousState(agent.session, history)
      if (!text || (!requested && !shouldNotify(previous, text, current.state))) {
        // 即便状态没变，只要循环提醒挂上了就得把消息带回去。
        return filtered.length === decision.messages.length && filtered.every((message, index) => message === decision.messages[index])
          ? decision : { ...decision, messages: filtered }
      }
      filtered.push(notice(statePlugin, text, 'Context state', current.state,
        { contextCareTrace: { trigger: requested ? 'rest-result' : 'budget-state', budget: current.budget, outcome } }))
      return { ...decision, messages: filtered }
    }
    const reminderService = ctx.get('reminderRules')
    return reminderService ? filterDeliveryMessages({ runtime: reminderService, sessionId: String(agent.session.id), messages,
      visible: () => history.messages(agent.session), commit: commitInputs,
      onRollbackError: error => ctx.logger.warn('reminder rollback: ' + (error instanceof Error ? error.message : String(error))) })
      : commitInputs(messages)
    })
  }, { prepend: true })

  // 交给 host 入口去注册路由 —— 客户端卡片靠它拿到「哪些内容被改写过」。
  // 记录本身与路由分开:记录在改写路径上,路由是纯读取。
  return { rewriteJournal, requestOwner }
}
