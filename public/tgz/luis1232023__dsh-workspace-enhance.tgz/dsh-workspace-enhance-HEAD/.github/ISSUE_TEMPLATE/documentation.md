---
name: 📄 文档问题
about: README / CONTRIBUTING / CHANGELOG 等文档的缺失、错误或改进建议
title: '[docs] '
labels: ['documentation']
assignees: ''
---

**涉及文档**

<!-- README.md / CONTRIBUTING.md / CHANGELOG.md / 注释，或其它。 -->

**问题类型**

- [ ] 描述与实现不一致（文档漂移）
- [ ] 缺失内容（安装、开发、测试、已知限制等）
- [ ] 错别字 / 排版 / 链接失效
- [ ] 其它

**问题描述与建议**

<!-- 具体位置（小节 / 行）与修改建议。 -->
