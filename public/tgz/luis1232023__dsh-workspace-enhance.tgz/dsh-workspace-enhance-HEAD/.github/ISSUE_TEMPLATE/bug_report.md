---
name: 🐛 Bug 报告
about: 提交一个可复现的缺陷（请先搜索是否已有相同 Issue）
title: '[bug] '
labels: ['bug']
assignees: ''
---

**描述缺陷**

<!-- 清晰描述问题是什么。 -->

**复现步骤**

1. 打开 DSH Web 并启用插件
2. 执行 ...
3. 观察 ...

**期望行为**

<!-- 你期望发生什么。 -->

**实际行为**

<!-- 实际发生了什么；如有报错信息 / 截图请附上。 -->

**环境**

- DSH 版本：<!-- `dsh --version` -->
- Profile：<!-- web / 其它 -->
- 插件版本：<!-- package.json 的 version -->
- 操作系统：<!-- Windows / macOS / Linux -->
- 浏览器：<!-- Chrome / Edge / Firefox + 版本 -->

**日志与上下文**

<!-- 如涉及 node 半边，`debug/report` 输出或控制台日志；涉及会话删除等危险操作请先确认。 -->
