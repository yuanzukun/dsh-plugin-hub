---
name: Pull Request
about: 提交改动（请先阅读 CONTRIBUTING.md 并勾选检查清单）
title: ''
labels: ''
assignees: ''
---

## 改动内容

<!-- 用几句话说明这个 PR 做了什么、动机是什么。关联 Issue 请写 #issue 编号。 -->

## 贡献前检查清单（对应 [CONTRIBUTING.md](../CONTRIBUTING.md)）

### 代码

- [ ] `npm run typecheck` 通过（tsc strict）
- [ ] `npm run build` 通过
- [ ] `npm test` 全绿（test-node / dry-run-client / test-real-store）
- [ ] 涉及 UI 的改动，渲染测试通过（`scripts/render-tabs-test.tsx` / `scripts/render-git-test.tsx`）
- [ ] 新增 / 修改 RPC 端点时，`lib/index.js`、`src/contract.ts`、README 三处一致
- [ ] client 半边改动只改 `src/`，未手改 `lib/client.js`；构建产物已同步
- [ ] 样式复用 `--dsw-*` 变量，未引入独立主题
- [ ] 命名与注释规范（模块头 JSDoc、类型注释）

### 文档

- [ ] 行为变化已同步 `README.md`（功能表 / 端点表 / 已知限制）
- [ ] `CHANGELOG.md` 已增加对应条目
- [ ] 删除 / 变更已有能力时，相关文档已同步

## 验证证据

<!-- 粘贴关键测试输出 / 截图 / 复现与修复说明。 -->

## 备注

<!-- 其它需要 review 注意的点。 -->
