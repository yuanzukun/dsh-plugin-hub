/**
 * Ambient typings for the prismjs subpaths this plugin bundles.
 *
 * prismjs ships no .d.ts for `components/*` or `plugins/*` (only the main
 * `prismjs` entry has community types, and this project deliberately bundles
 * the core + a curated language set via subpath imports to keep the client
 * bundle small). These declarations type only the surface the plugin uses;
 * the literal `prism-core` declaration wins over the wildcard below.
 */

declare module 'prismjs/components/prism-core' {
  /** A Prism grammar object (token definition map). */
  export interface PrismGrammar {
    [key: string]: unknown;
  }

  /** Environment object passed to hook callbacks. */
  export interface PrismHookEnv {
    code?: string;
    element?: Element;
    language?: string;
    [key: string]: unknown;
  }

  export interface PrismStatic {
    languages: Record<string, PrismGrammar>;
    plugins: Record<string, unknown>;
    util: {
      isActive(el: Element, className: string): boolean;
      clone(o: unknown): unknown;
      encode(o: unknown): unknown;
    };
    hooks: {
      add(name: string, callback: (env: PrismHookEnv) => void): void;
      run(name: string, env: PrismHookEnv): void;
    };
    highlight(text: string, grammar: PrismGrammar, language?: string): string;
    tokenize(text: string, grammar: PrismGrammar): unknown;
    Token: {
      stringify(...args: unknown[]): string;
    };
  }

  const Prism: PrismStatic;
  export default Prism;
}

/** Language components auto-register with the global Prism when imported. */
declare module 'prismjs/components/prism-*' {
  const _: void;
  export default _;
}

/** Official line-numbers plugin (hooks only; rows are rendered statically). */
declare module 'prismjs/plugins/line-numbers/prism-line-numbers' {
  const _: void;
  export default _;
}