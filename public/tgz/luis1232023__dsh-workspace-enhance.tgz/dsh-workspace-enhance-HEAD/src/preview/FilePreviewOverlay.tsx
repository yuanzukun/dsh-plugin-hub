/**
 * Right-side file preview panel, registered into the additive `shell.overlay`
 * list slot. Renders nothing until a file is opened from the File Browser;
 * supports text (Prism.js with line numbers), images (data URL), binary
 * placeholders, and loading/error states. The inject face arrives as top-level
 * props (spread by the renderer); the overlay only needs the store for preview
 * state.
 */
import { useEffect, useMemo, useState } from 'react';
import type { GlobalStandardProps, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { EnhanceStoreHandle } from '../store';
import type { EnhanceInjected } from '../injected';
import { highlightPre } from '../highlight';
import { markdownToHtml } from '../markdown';
import { formatSize } from '../ui';
import { closePreview } from '../preview';

export type FilePreviewOverlayProps = GlobalStandardProps &
  PropsStore<EnhanceStoreHandle> &
  EnhanceInjected;

export function FilePreviewOverlay(props: FilePreviewOverlayProps) {
  const { useStore, actions } = props;
  const preview = useStore((s) => s.preview);
  // Markdown files default to the rendered preview; 源码 switches to source.
  const [mdView, setMdView] = useState<'preview' | 'source'>('preview');

  // Reset to the rendered preview whenever a different file is opened.
  useEffect(() => {
    setMdView('preview');
  }, [preview?.path]);

  // Esc closes the panel.
  useEffect(() => {
    if (!preview) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') closePreview(actions);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [preview, actions]);

  const html = useMemo(() => {
    if (!preview || preview.status !== 'ready' || preview.read?.kind !== 'text') return '';
    // Full <pre> block: Prism tokens + line-numbers gutter.
    return highlightPre(preview.read.content, preview.read.language || undefined);
  }, [preview]);

  const mdHtml = useMemo(() => {
    if (!preview || preview.status !== 'ready' || preview.read?.kind !== 'text') return '';
    if (preview.read.language !== 'markdown') return '';
    return markdownToHtml(preview.read.content);
  }, [preview]);

  if (!preview) return null;

  const body = () => {
    if (preview.status === 'loading') {
      return (
        <div className="dwe-preview-message">
          <span className="dwe-spinner" /> 加载中…
        </div>
      );
    }
    if (preview.status === 'error') {
      return <div className="dwe-preview-message dwe-error">读取失败：{preview.message}</div>;
    }
    const read = preview.read;
    if (!read) return null;
    if (read.kind === 'text') {
      const isMd = read.language === 'markdown';
      return (
        <>
          {isMd ? (
            <div className="dwe-preview-tabs">
              <button
                type="button"
                className="dwe-preview-tab"
                data-active={mdView === 'preview' || undefined}
                onClick={() => setMdView('preview')}
              >
                预览
              </button>
              <button
                type="button"
                className="dwe-preview-tab"
                data-active={mdView === 'source' || undefined}
                onClick={() => setMdView('source')}
              >
                源码
              </button>
            </div>
          ) : null}
          {isMd && mdView === 'preview' ? (
            <div className="dwe-preview-md" dangerouslySetInnerHTML={{ __html: mdHtml }} />
          ) : (
            <div className="dwe-preview-code-wrap" dangerouslySetInnerHTML={{ __html: html }} />
          )}
          {read.truncated ? (
            <div className="dwe-hint" style={{ padding: '8px 0' }}>
              ⚠ 文件较大，仅显示前 {formatSize(512 * 1024)}（共 {formatSize(read.size)}）。
            </div>
          ) : null}
        </>
      );
    }
    if (read.kind === 'image') {
      return (
        <div className="dwe-preview-image">
          <img src={read.dataUrl} alt={read.name} />
        </div>
      );
    }
    return (
      <div className="dwe-preview-message">
        二进制文件（{formatSize(read.size)}），暂不支持预览。
      </div>
    );
  };

  return (
    <div className="dwe-preview">
      <div className="dwe-preview-header">
        <span className="dwe-preview-name">{preview.name}</span>
        <span className="dwe-preview-path">{preview.path}</span>
        <button
          type="button"
          className="dwe-iconbtn"
          title="关闭 (Esc)"
          onClick={() => closePreview(actions)}
        >
          ✕
        </button>
      </div>
      <div className="dwe-preview-body">{body()}</div>
    </div>
  );
}
