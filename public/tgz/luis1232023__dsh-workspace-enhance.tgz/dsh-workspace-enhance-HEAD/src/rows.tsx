/**
 * Row primitives aligned with the built-in workspace browser
 * (ui-workspace Rows.module.css): project rows (34px) with a folder icon that
 * shows the OPEN state on hover, session rows (32px) with the status dot slot
 * to the LEFT of the title, right-aligned time hidden on hover in favour of
 * the row actions menu.
 */
import { useState } from 'react';
import type { SessionSummary } from '@deepseek-ai/dsh-client-runtime/client';
import { IconEllipsisOutline16, IconFolderClose16, IconFolderOpen16, IconPlusOutline16 } from '@deepseek-ai/dsh-client-ui-primitives';
import { Menu, SessionStatusDot, anchorOf, timeAgo } from './ui';
import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client';

export function ProjectRow({
  title,
  open,
  active,
  onToggle,
  onAddSession,
  onMenu,
}: {
  title: string;
  open: boolean;
  active?: boolean;
  onToggle: () => void;
  onAddSession: () => void;
  onMenu: (anchor: { x: number; y: number }) => void;
}) {
  // The icon strictly reflects the expansion state: open folder while
  // expanded, closed folder while collapsed (hover never overrides it).
  return (
    <div
      className="dwe-row dwe-project-row"
      data-active={active || undefined}
      role="treeitem"
      aria-expanded={open}
      onClick={onToggle}
    >
      <span className="dwe-slot dwe-folder-slot" data-active={active || undefined}>
        {open ? <IconFolderOpen16 size={16} /> : <IconFolderClose16 size={16} />}
      </span>
      <span className="dwe-project-text">
        <span className="dwe-title">{title}</span>
      </span>
      <span className="dwe-row-actions">
        <button
          type="button"
          className="dwe-iconbtn"
          title="新建任务"
          onClick={(e) => {
            e.stopPropagation();
            onAddSession();
          }}
        >
          <IconPlusOutline16 size={16} />
        </button>
        <button
          type="button"
          className="dwe-iconbtn"
          title="工作区操作"
          onClick={(e) => {
            e.stopPropagation();
            onMenu(anchorOf(e));
          }}
        >
          <IconEllipsisOutline16 size={16} />
        </button>
      </span>
    </div>
  );
}

export function SessionRow({
  session,
  current,
  onOpen,
  onRename,
  onArchive,
  onDelete,
}: {
  session: SessionSummary;
  current?: boolean;
  onOpen: (id: SessionId) => void;
  onRename: (id: SessionId) => void;
  onArchive: (id: SessionId) => void;
  onDelete: (id: SessionId) => void;
}) {
  const [menu, setMenu] = useState<{ x: number; y: number } | null>(null);
  return (
    <div
      className="dwe-row dwe-session-row"
      data-current={current || undefined}
      onClick={() => onOpen(session.id)}
    >
      <span className="dwe-slot">
        <SessionStatusDot session={session} current={current} />
      </span>
      <span className="dwe-title">{session.displayTitle}</span>
      <span className="dwe-time">{timeAgo(session.updatedAt)}</span>
      <span className="dwe-row-actions">
        <button
          type="button"
          className="dwe-iconbtn"
          title="操作"
          onClick={(e) => {
            e.stopPropagation();
            setMenu(anchorOf(e));
          }}
        >
          <IconEllipsisOutline16 size={16} />
        </button>
      </span>
      {menu ? (
        <Menu
          anchor={menu}
          onClose={() => setMenu(null)}
          items={[
            { label: '打开', onSelect: () => onOpen(session.id) },
            { label: '重命名', onSelect: () => onRename(session.id) },
            { label: '归档', onSelect: () => onArchive(session.id) },
            { label: '彻底删除', danger: true, onSelect: () => onDelete(session.id) },
          ]}
        />
      ) : null}
    </div>
  );
}
