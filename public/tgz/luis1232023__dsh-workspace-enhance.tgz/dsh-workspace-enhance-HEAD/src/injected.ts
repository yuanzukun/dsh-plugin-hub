/**
 * The registrant business face shared by the sidebar entry and the overlay
 * entry: session/workspace actions bound to the client services plus the RPC
 * api and the preview open flow.
 */
import type { SessionId, SessionSearchResultItem, WorkspaceId } from '@deepseek-ai/dsh-client-runtime/client';
import type { EnhanceApi } from './rpc';

export interface EnhanceInjected {
  api: EnhanceApi;
  openSession: (id: SessionId) => void;
  startSession: (workspaceId?: WorkspaceId) => void;
  connectWorkspace: (workspaceId: WorkspaceId) => Promise<SessionId>;
  renameSession: (id: SessionId, title: string) => Promise<void>;
  renameWorkspace: (id: WorkspaceId, title: string) => Promise<void>;
  deleteWorkspace: (id: WorkspaceId) => Promise<void>;
  archiveSession: (id: SessionId) => Promise<void>;
  createWorkspace: (path: string) => Promise<void>;
  pickWorkspaceDir: () => Promise<string | null>;
  refreshSessions: () => Promise<void>;
  /** Search the host's message-content index (mirrors the built-in browser). */
  searchSessions: (query: string, signal: AbortSignal) => Promise<{ items: SessionSearchResultItem[]; hasMore: boolean }>;
  openFile: (path: string, name: string) => void;
}
