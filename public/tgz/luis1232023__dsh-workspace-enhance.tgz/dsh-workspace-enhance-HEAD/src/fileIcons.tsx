/**
 * Colored 16px file/folder icons for the file tree (inline SVGs).
 *
 * - Folders follow the Windows Explorer look: a two-tone yellow folder with a
 *   back tab, closed vs open variants.
 * - Files get a type-colored page-icon set (js / ts / json / markdown /
 *   image / text / config / code / default) so different file types are
 *   distinguishable at a glance. SVG keeps the icons crisp at any size and
 *   needs no extra assets.
 */
import type { ReactNode } from 'react';
import type { FsEntry } from './contract';

type Props = { size?: number };

/* ── folders (Windows-style, two-tone yellow) ─────────────────────────── */

export function FolderClosedIcon({ size = 16 }: Props) {
  return (
    <svg
      className="dwe-tree-icon"
      width={size}
      height={size}
      viewBox="0 0 16 16"
      aria-hidden
    >
      {/* back: tab + body (darker) */}
      <path
        d="M1.75 3.5h4.15c.31 0 .6.13.8.36l.85 1.02c.2.23.49.36.8.36h4.9c.41 0 .75.34.75.75v5.76c0 .41-.34.75-.75.75H2.5a.75.75 0 0 1-.75-.75V3.5z"
        fill="#E7B64C"
        stroke="#B98A1F"
        strokeWidth=".75"
        strokeLinejoin="round"
      />
      {/* front pocket (lighter) */}
      <path
        d="M2.5 5.9h11c.28 0 .5.22.5.5v4.6c0 .41-.34.75-.75.75H3.25a.75.75 0 0 1-.75-.75V6.4c0-.28.22-.5.5-.5z"
        fill="#FBCA5C"
        stroke="#B98A1F"
        strokeWidth=".75"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function FolderOpenIcon({ size = 16 }: Props) {
  return (
    <svg
      className="dwe-tree-icon"
      width={size}
      height={size}
      viewBox="0 0 16 16"
      aria-hidden
    >
      {/* interior (darker, visible once the pocket opens) */}
      <path
        d="M1.75 3.5h4.15c.31 0 .6.13.8.36l.85 1.02c.2.23.49.36.8.36h4.9c.41 0 .75.34.75.75v2.6H2.5v5.16c0 .41-.34.75-.75.75H2.5a.75.75 0 0 1-.75-.75V3.5z"
        fill="#D9A02E"
        stroke="#B98A1F"
        strokeWidth=".75"
        strokeLinejoin="round"
      />
      {/* open front pocket: downward flap */}
      <path
        d="M2.5 6.6h11l-.95 3.15a1 1 0 0 1-.96.75H4.41a1 1 0 0 1-.96-.75L2.5 6.6z"
        fill="#FBCA5C"
        stroke="#B98A1F"
        strokeWidth=".75"
        strokeLinejoin="round"
      />
    </svg>
  );
}

/* ── file pages: body + folded corner ─────────────────────────────────── */

function Page({ body, fold, children }: { body: string; fold: string; children?: ReactNode }) {
  return (
    <svg
      className="dwe-tree-icon"
      width={16}
      height={16}
      viewBox="0 0 16 16"
      aria-hidden
    >
      <path
        d="M4 1.75h5.15c.2 0 .39.08.53.22l2.35 2.35c.14.14.22.33.22.53V13.5c0 .41-.34.75-.75.75H4A.75.75 0 0 1 3.25 13.5V2.5c0-.41.34-.75.75-.75z"
        fill={body}
      />
      <path d="M9.45 2.02 12.25 4.8H9.45z" fill={fold} />
      {children}
    </svg>
  );
}

function Lines({ y }: { y: number }) {
  return (
    <g stroke="#9AA3AE" strokeWidth="1" strokeLinecap="round">
      <path d={`M5 ${y}h6`} />
      <path d={`M5 ${y + 2}h4.5`} />
      <path d={`M5 ${y + 4}h5.5`} />
    </g>
  );
}

export const FileJsIcon = () => (
  <Page body="#F7DF1E" fold="#D3B915">
    <path d="M9.6 5.4a1.7 1.7 0 0 1 .85.3 1.6 1.6 0 0 1 .5.6l-.75.45a1 1 0 0 0-.85-.5.5.5 0 0 0-.32.45c0 .17.06.27.5.5l.6.26c.85.36 1.05.8 1.05 1.3a1.6 1.6 0 0 1-2.2 1.25c-.5-.22-.7-.6-.8-.9l.8-.47c.06.25.15.5.4.6.18.08.42.1.52-.05a.45.45 0 0 0-.05-.5c-.14-.12-.4-.22-.7-.38-.45-.24-.75-.55-.75-1.05a1.35 1.35 0 0 1 1.15-1.41z" fill="#3B3B3B" />
  </Page>
);

export const FileTsIcon = () => (
  <Page body="#3178C6" fold="#255E96">
    <path d="M8 4.6h2.9v.9h-1v4.7H8.9V5.5h-.9z" fill="#fff" />
    <path d="M8.05 8.05v.85h2.3a2 2 0 0 1 0 .6c-.05.5-.2.85-.42 1.05-.25.25-.6.38-1.05.38-.5 0-.85-.15-1.1-.4a1.7 1.7 0 0 1-.25-.4l.85-.5c.1.2.2.4.4.5.15.1.35.15.55.15.3 0 .5-.1.6-.3.1-.2.12-.45.15-.7h-1.9a1.6 1.6 0 0 1-1.5-1.9c0-.55.2-1 .55-1.3.35-.3.8-.45 1.3-.45.55 0 1 .15 1.3.45.2.25.35.55.4.95H9.3a1.1 1.1 0 0 0-.2-.6.8.8 0 0 0-.65-.25c-.3 0-.55.1-.7.3-.15.2-.2.45-.2.85 0 .4.05.65.2.85.1.15.25.22.3.27z" fill="#fff" />
  </Page>
);

export const FileJsonIcon = () => (
  <Page body="#FBC02D" fold="#D19A1B">
    <g stroke="#4A3B00" strokeWidth=".9" strokeLinecap="round" fill="none">
      <path d="M6.1 5.3c-.5.3-.75.8-.75 1.45 0 .45-.15.75-.5.9.35.15.5.45.5.9 0 .65.25 1.15.75 1.45" />
      <path d="M9.9 5.3c.5.3.75.8.75 1.45 0 .45.15.75.5.9-.35.15-.5.45-.5.9 0 .65-.25 1.15-.75 1.45" />
      <path d="M7.3 4.9l1.4 2.9" />
    </g>
  </Page>
);

export const FileMarkdownIcon = () => (
  <Page body="#519ABA" fold="#3E7B97">
    <path d="M5 6.3v4h1.05V8.6l1.05 1.3 1.05-1.3v1.7H9.2v-4h-1.05L7.1 7.6 6.05 6.3z" fill="#fff" />
  </Page>
);

export const FileImageIcon = () => (
  <Page body="#E9ECF1" fold="#C3CAD3">
    <circle cx="10.2" cy="5.4" r="1.1" fill="#FBBF24" />
    <path d="M4.6 10.4 6.4 8.2l1.5 1.7 1.1-1.2 2.4 2.7v.1a.5.5 0 0 1-.4.5H5.1a.5.5 0 0 1-.5-.5v-.1z" fill="#34D399" />
  </Page>
);

export const FileTextIcon = () => (
  <Page body="#E9ECF1" fold="#C3CAD3">
    <Lines y={6.1} />
  </Page>
);

export const FileConfigIcon = () => (
  <Page body="#4EC9B0" fold="#3BA08C">
    <g fill="#fff">
      <path d="M7.2 4.9h1.6v.4l.55.2.4-.4.9.9-.4.4.2.55h.4v1.6h-.4l-.2.55.4.4-.9.9-.4-.4-.55.2v.4H7.2v-.4l-.55-.2-.4.4-.9-.9.4-.4-.2-.55h-.4V6.05h.4l.2-.55-.4-.4.9-.9.4.4.55-.2z" />
      <circle cx="8" cy="7.5" r="1.1" fill="#2E8C7A" />
    </g>
  </Page>
);

export const FileCodeIcon = () => (
  <Page body="#4F8CFF" fold="#3B6FD6">
    <path d="M6 5.4 4.2 7.5 6 9.6M10 5.4l1.8 2.1-1.8 2.1M8.6 5l-1.2 4.6" stroke="#fff" strokeWidth=".95" strokeLinecap="round" fill="none" />
  </Page>
);

export const FileDefaultIcon = () => (
  <Page body="#C8CDD4" fold="#AAB2BC">
    <Lines y={6.1} />
  </Page>
);

/** Pick the icon for a tree entry: folder (open/closed) or a type-colored page. */
export function fileIconFor(entry: Pick<FsEntry, 'name' | 'isDir'>, isOpen: boolean): ReactNode {
  if (entry.isDir) return isOpen ? <FolderOpenIcon /> : <FolderClosedIcon />;
  const dot = entry.name.lastIndexOf('.');
  const ext = dot >= 0 ? entry.name.slice(dot + 1).toLowerCase() : '';
  switch (ext) {
    case 'js':
    case 'jsx':
    case 'mjs':
    case 'cjs':
      return <FileJsIcon />;
    case 'ts':
    case 'tsx':
    case 'mts':
    case 'cts':
      return <FileTsIcon />;
    case 'json':
    case 'jsonc':
      return <FileJsonIcon />;
    case 'md':
    case 'markdown':
    case 'mdx':
      return <FileMarkdownIcon />;
    case 'png':
    case 'jpg':
    case 'jpeg':
    case 'gif':
    case 'webp':
    case 'bmp':
    case 'ico':
    case 'avif':
    case 'svg':
      return <FileImageIcon />;
    case 'txt':
    case 'log':
    case 'csv':
      return <FileTextIcon />;
    case 'yml':
    case 'yaml':
    case 'toml':
    case 'ini':
    case 'env':
    case 'editorconfig':
      return <FileConfigIcon />;
    case 'py':
    case 'go':
    case 'rs':
    case 'java':
    case 'c':
    case 'h':
    case 'cc':
    case 'cpp':
    case 'hpp':
    case 'rb':
    case 'php':
    case 'html':
    case 'css':
    case 'scss':
    case 'less':
    case 'vue':
    case 'svelte':
    case 'sql':
    case 'sh':
    case 'bat':
    case 'ps1':
    case 'lua':
    case 'dart':
    case 'kt':
    case 'swift':
    case 'cs':
      return <FileCodeIcon />;
    default:
      return <FileDefaultIcon />;
  }
}
