/**
 * Prism.js setup: bundle the core plus a curated, explicitly-registered
 * language set, and expose small highlight helpers.
 *
 * Design (per the project's choice of a light static preview):
 *  - No auto-detection: the caller names the language (the host resolves it
 *    from the file extension in lib/index.js; markdown fences pass their own
 *    ` ```lang ` tag). Unknown/absent grammars fall back to escaped plain
 *    text — explicit mapping keeps file switching cheap and deterministic.
 *  - On-demand language set: only the components below are statically
 *    imported, so esbuild tree-shakes everything else out of lib/client.js.
 *    Import order matters for grammar inheritance (cpp extends c, tsx extends
 *    jsx, scala extends java, scss/less extend css, markdown extends markup);
 *    the Prism core assigns `window.Prism`/`global.Prism` first, and the
 *    components register themselves against it.
 *  - Line numbers: the official `line-numbers` plugin contract (`.line-numbers`
 *    class on the <pre>, a `<span class="line-numbers-rows">` child with one
 *    empty `<span>` per line, CSS counters for the digits) is reproduced
 *    statically by `highlightPre` so the panel stays a pure
 *    dangerouslySetInnerHTML render — no DOM post-processing on file switch.
 *
 * Everything is inlined into lib/client.js at build time (prismjs is a
 * devDependency — it never needs to be installed into the profile at runtime).
 */
import Prism from 'prismjs/components/prism-core';

// Base grammars used by the languages below (order matters).
import 'prismjs/components/prism-clike';
import 'prismjs/components/prism-markup';
import 'prismjs/components/prism-markup-templating'; // php's hook dependency
import 'prismjs/components/prism-css';
import 'prismjs/components/prism-javascript';
import 'prismjs/components/prism-c';
import 'prismjs/components/prism-java';
import 'prismjs/components/prism-jsx';
import 'prismjs/components/prism-typescript';

// The curated language set (popular + this project's workspace types).
import 'prismjs/components/prism-bash';
import 'prismjs/components/prism-batch';
import 'prismjs/components/prism-cpp';
import 'prismjs/components/prism-csharp';
import 'prismjs/components/prism-dart';
import 'prismjs/components/prism-diff';
import 'prismjs/components/prism-docker';
import 'prismjs/components/prism-fsharp';
import 'prismjs/components/prism-go';
import 'prismjs/components/prism-groovy';
import 'prismjs/components/prism-ini';
import 'prismjs/components/prism-json';
import 'prismjs/components/prism-kotlin';
import 'prismjs/components/prism-less';
import 'prismjs/components/prism-lua';
import 'prismjs/components/prism-markdown';
import 'prismjs/components/prism-perl';
import 'prismjs/components/prism-php';
import 'prismjs/components/prism-powershell';
import 'prismjs/components/prism-python';
import 'prismjs/components/prism-r';
import 'prismjs/components/prism-ruby';
import 'prismjs/components/prism-rust';
import 'prismjs/components/prism-scala';
import 'prismjs/components/prism-scss';
import 'prismjs/components/prism-sql';
import 'prismjs/components/prism-swift';
import 'prismjs/components/prism-toml';
import 'prismjs/components/prism-tsx';
import 'prismjs/components/prism-visual-basic';
import 'prismjs/components/prism-yaml';

// Official line-numbers plugin (imported for its documented contract; rows are
// synthesized statically below, so the hooks stay inert for string rendering).
import 'prismjs/plugins/line-numbers/prism-line-numbers';

/**
 * File-extension / fence short-names / legacy highlight.js ids → Prism
 * language id. Prism registers its own aliases (js, ts, py, sh, rb, rs, …);
 * this map covers what Prism does not alias natively.
 */
const ALIASES: Record<string, string> = {
  js: 'javascript',
  mjs: 'javascript',
  cjs: 'javascript',
  ts: 'typescript',
  mts: 'typescript',
  cts: 'typescript',
  py: 'python',
  rb: 'ruby',
  rs: 'rust',
  cs: 'csharp',
  'c#': 'csharp',
  'c++': 'cpp',
  cc: 'cpp',
  cxx: 'cpp',
  hpp: 'cpp',
  hh: 'cpp',
  h: 'c',
  html: 'markup',
  htm: 'markup',
  xml: 'markup',
  svg: 'markup',
  sh: 'bash',
  shell: 'bash',
  zsh: 'bash',
  yml: 'yaml',
  md: 'markdown',
  ps1: 'powershell',
  ps: 'powershell',
  kt: 'kotlin',
  kts: 'kotlin',
  gradle: 'groovy',
  dockerfile: 'docker',
  docker: 'docker',
  vb: 'visual-basic',
  vba: 'visual-basic',
  vbnet: 'visual-basic', // legacy highlight.js id / server map pre-upgrade
  bat: 'batch',
  cmd: 'batch',
  patch: 'diff',
};

const LANG_CACHE: Record<string, string | undefined> = Object.create(null);

/**
 * Resolve a loose language name to a registered Prism id ('' = plaintext).
 * The alias table wins first so Prism's built-in aliases (js, ts, sh, …)
 * normalize back to canonical ids; the exact/lowercase grammar match follows.
 */
export function resolveLanguage(name?: string): string | undefined {
  if (!name) return undefined;
  const key = name.toLowerCase();
  if (key in LANG_CACHE) return LANG_CACHE[key] || undefined;
  let resolved: string | undefined;
  const alias = ALIASES[key];
  if (alias && Prism.languages[alias]) resolved = alias;
  else if (Prism.languages[name]) resolved = name;
  else if (Prism.languages[key]) resolved = key;
  if (resolved && !Prism.languages[resolved]) resolved = undefined;
  LANG_CACHE[key] = resolved ?? '';
  return resolved;
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/**
 * Highlight `code` with `language`, returning the token HTML for a <code>
 * body (no wrapper). Falls back to escaped plain text when the grammar is
 * unknown — no auto-detection, matching Prism's design.
 */
export function highlightCode(code: string, language?: string): string {
  const id = resolveLanguage(language);
  if (id) {
    try {
      return Prism.highlight(code, Prism.languages[id], id);
    } catch {
      /* fall through to plain text */
    }
  }
  return escapeHtml(code);
}

/** Number of visual rows, mirroring the official line-numbers plugin
 * (`\n` not followed by end-of-string, plus one). */
function lineCount(code: string): number {
  const m = code.match(/\n(?!$)/g);
  return (m ? m.length : 0) + 1;
}

export interface HighlightPreOptions {
  /** Emit the line-numbers gutter (default true). */
  lineNumbers?: boolean;
}

/**
 * Render a full highlighted <pre> block for the file preview, with the
 * `line-numbers` plugin's DOM (`<span class="line-numbers-rows">` of empty
 * spans; CSS counters paint the digits). Pure string output so switching
 * files never touches the DOM after the initial render.
 */
export function highlightPre(
  code: string,
  language?: string,
  opts: HighlightPreOptions = {},
): string {
  const id = resolveLanguage(language);
  const langClass = id ? `language-${id}` : '';
  const body = highlightCode(code, language);
  const ln = opts.lineNumbers !== false;
  const rows = ln
    ? `<span class="line-numbers-rows" aria-hidden="true">${'<span></span>'.repeat(lineCount(code))}</span>`
    : '';
  const classes = ['dwe-preview-code', langClass, ln ? 'line-numbers' : '']
    .filter(Boolean)
    .join(' ');
  return `<pre class="${classes}"><code class="${langClass}">${body}</code>${rows}</pre>`;
}