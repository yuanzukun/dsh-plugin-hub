/**
 * Typed RPC helpers over the generic connection channel. The node half
 * registers `/dsh-workspace-enhance`; failures surface as thrown Errors with
 * the host's message text.
 *
 * The browser-side `ctx.connection` (ConnectionHandle with `.rpc.call`) has
 * no published client Context augmentation in this release, so the carrier
 * shape is declared structurally here; at runtime the connection plugin
 * provides exactly this face.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type {
  FsListResult,
  FsReadResult,
  FsRoot,
  GitBranchesResult,
  GitLogResult,
  GitShowResult,
  GitStatusResult,
  SessionDeleteResult,
} from './contract';

type RpcResult<T> = { ok: true; value: T } | { ok: false; error: { message: string } };

/** The browser connection face this plugin consumes. */
export interface RpcCarrier {
  connection: {
    rpc: {
      call(
        channel: string,
        endpoint: string,
        payload: unknown,
        signal?: AbortSignal,
      ): Promise<RpcResult<unknown>>;
    };
  };
}

export type EnhanceClientContext = ClientContext & RpcCarrier;

const CHANNEL = '/dsh-workspace-enhance';

async function call<T>(ctx: EnhanceClientContext, endpoint: string, payload: unknown): Promise<T> {
  const res = await ctx.connection.rpc.call(CHANNEL, endpoint, payload);
  if (!res.ok) throw new Error(res.error.message || endpoint);
  return res.value as T;
}

export const api = (ctx: EnhanceClientContext) => ({
  fsRoot: () => call<FsRoot>(ctx, 'fs/root', {}),
  fsList: (path?: string) => call<FsListResult>(ctx, 'fs/list', { path }),
  fsRead: (path: string) => call<FsReadResult>(ctx, 'fs/read', { path }),
  gitLog: (path: string, count?: number, graph?: boolean, branch?: string) =>
    call<GitLogResult>(ctx, 'git/log', { path, count, graph, branch }),
  gitShow: (path: string, hash: string) => call<GitShowResult>(ctx, 'git/show', { path, hash }),
  gitStatus: (path: string) => call<GitStatusResult>(ctx, 'git/status', { path }),
  gitBranches: (path: string) => call<GitBranchesResult>(ctx, 'git/branches', { path }),
  sessionDelete: (sessionId: string) => call<SessionDeleteResult>(ctx, 'session/delete', { sessionId }),
  debugReport: (kind: string, message: string, detail: string, stack: string) =>
    call<{ written: true }>(ctx, 'debug/report', { kind, message, detail, stack }),
});

export type EnhanceApi = ReturnType<typeof api>;
