/**
 * dsh-workspace-enhance — browser half entry.
 *
 * Registers two slot contributions:
 *   1. `sidebar.workspaces` (priority -1, shadowing the built-in browser):
 *      the workspace-folder region — each folder expands into per-folder
 *      任务 / 文件浏览 / Git sub-tabs (Git only when the folder is a repo).
 *   2. `shell.overlay` (additive list entry): the right-side file preview
 *      panel.
 *
 * Both share one store (preview, deleted-session tombstones, per-workspace
 * tab) and one injected business face (session/workspace actions + the RPC
 * api). The inject factories receive the store's baked actions, which the
 * preview flow uses to dispatch loading/ready/error states.
 *
 * Diagnostics: browser errors are reported to the host log through the
 * `debug/report` RPC endpoint (throttled) so crashes surface in
 * $DSH_HOME/storages/dwe-errors.log.
 *
 * The type-only imports at the bottom load the SlotMap augmentations of
 * `sidebar.workspaces` (ui-sidebar) and `shell.overlay` (ui-layout) into the
 * program so `ctx.slots` accepts those keys; they erase at build time.
 */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { ILayout } from '@deepseek-ai/dsh-client-ui-layout/client';
import type { SidebarSectionOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client';
import { api, type EnhanceClientContext } from './rpc';
import { createEnhanceStore } from './store';
import { CSS } from './styles';
import { openFile, type OpenFileActions } from './preview';
import type { EnhanceInjected } from './injected';
import { WorkspaceRegion } from './tabs/WorkspaceRegion';
import { FilePreviewOverlay } from './preview/FilePreviewOverlay';

export const name = 'dsh-workspace-enhance';

/** Required client services (cordis fiber inject). */
export const inject = ['slots', 'sessions', 'workspaces', 'connection'];

const PLUGIN_ID = 'dsh-workspace-enhance';
const CSS_ID = 'dsh-workspace-enhance-css';

function ensureStyle(): void {
  if (typeof document === 'undefined') return;
  if (document.querySelector(`style[data-plugin-css="${CSS_ID}"]`)) return;
  const tag = document.createElement('style');
  tag.setAttribute('data-plugin', PLUGIN_ID);
  tag.setAttribute('data-plugin-css', CSS_ID);
  tag.textContent = CSS;
  document.head.appendChild(tag);
}

export function apply(ctx: ClientContext): void {
  ensureStyle();

  const store = createEnhanceStore();
  const rpc = api(ctx as EnhanceClientContext);

  // ── diagnostics: report browser errors to the host log (throttled) ──────
  let lastReport = 0;
  const report = (kind: string, message: string, detail: string, stack: string) => {
    const now = Date.now();
    if (now - lastReport < 5000) return;
    lastReport = now;
    void rpc
      .debugReport(kind, message, detail, stack)
      .catch(() => {});
  };
  if (typeof window !== 'undefined') {
    window.addEventListener('error', (e) => {
      report(
        'window-error',
        e.message ?? String(e.error ?? ''),
        '',
        e.error instanceof Error && e.error.stack ? e.error.stack : '',
      );
    });
    window.addEventListener('unhandledrejection', (e) => {
      const r = e.reason;
      report(
        'unhandledrejection',
        r instanceof Error ? r.message : String(r),
        '',
        r instanceof Error && r.stack ? r.stack : '',
      );
    });
    ctx.slots.onEntryError((slotKey, _entry, error) => {
      report(
        `slot-entry:${slotKey}`,
        error instanceof Error ? error.message : String(error),
        '',
        error instanceof Error && error.stack ? error.stack : '',
      );
    });
  }

  const sessionOps = (): Omit<EnhanceInjected, 'api' | 'openFile'> => ({
    openSession: (id) => ctx.sessions.open(id),
    startSession: (workspaceId) => ctx.workspaces.startSession(workspaceId),
    connectWorkspace: (workspaceId) => ctx.workspaces.connectWorkspace(workspaceId),
    renameSession: async (id, title) => {
      const binding = ctx.sessions.binding(id);
      if (!binding) throw new Error('任务不可用');
      const result = await binding.session.rename(title);
      if (!result.ok) throw new Error(result.error.message);
    },
    renameWorkspace: async (id, title) => {
      await ctx.workspaces.rename(id, title);
    },
    deleteWorkspace: async (id) => {
      await ctx.workspaces.delete(id);
    },
    archiveSession: async (id) => {
      await ctx.workspaces.archiveSession(id);
    },
    createWorkspace: async (path) => {
      await ctx.workspaces.create({ path });
    },
    pickWorkspaceDir: () => ctx.workspaces.pickDirectory(),
    // `refresh` lives on the concrete runtime (SessionRuntime), not on the
    // outward ISessions face — access it explicitly.
    refreshSessions: () =>
      (ctx.sessions as unknown as { refresh(): Promise<void> }).refresh(),
    searchSessions: async (query, signal) => {
      const result = await ctx.sessions.search(query, signal);
      if (!result.ok) throw new Error(result.error.message);
      return result.value;
    },
  });

  const makeFace = (actions: OpenFileActions): EnhanceInjected => ({
    ...sessionOps(),
    api: rpc,
    openFile: (path, name) => {
      void openFile(rpc, actions, path, name);
    },
  });

  ctx.slots.inject('sidebar.workspaces', () =>
    ctx.slots.register(
      {
        name: 'sidebar.workspaces',
        priority: -1,
        store,
        inject: (actions) => makeFace(actions),
      },
      WorkspaceRegion,
    ),
  );

  ctx.slots.inject('shell.overlay', () =>
    ctx.slots.register(
      {
        name: 'shell.overlay',
        id: 'dsh-workspace-enhance.preview',
        order: 100,
        store,
        inject: (actions) => makeFace(actions),
      },
      FilePreviewOverlay,
    ),
  );
}

// Referenced solely to load the sidebar/layout SlotMap augmentations.
type _AugmentationLoaders = [SidebarSectionOwnerProps, ILayout];
