/**
 * Preview load flow: guards against stale responses when the user clicks
 * files quickly. The request token lives at module level because the store
 * actions (dispatch) and the async fetch are split across call sites.
 */
import type { PreviewState } from './contract';
import type { EnhanceApi } from './rpc';

let seq = 0;

export interface OpenFileActions {
  openPreview: (path: string, name: string) => void;
  setPreview: (preview: PreviewState) => void;
}

export interface ClosePreviewActions {
  closePreview: () => void;
}

/** Open a file in the preview panel; loads content through the host RPC. */
export async function openFile(
  api: EnhanceApi,
  actions: OpenFileActions,
  path: string,
  name: string,
): Promise<void> {
  const mySeq = ++seq;
  actions.openPreview(path, name);
  try {
    const read = await api.fsRead(path);
    if (mySeq !== seq) return;
    actions.setPreview({ path, name, status: 'ready', read });
  } catch (e) {
    if (mySeq !== seq) return;
    actions.setPreview({
      path,
      name,
      status: 'error',
      message: e instanceof Error ? e.message : String(e),
    });
  }
}

/** Dismiss the preview (and invalidate any in-flight load). */
export function closePreview(actions: ClosePreviewActions): void {
  seq += 1;
  actions.closePreview();
}
