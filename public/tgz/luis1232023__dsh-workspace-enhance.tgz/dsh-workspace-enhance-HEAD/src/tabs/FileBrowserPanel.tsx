/**
 * 文件浏览 tab: a lazy directory tree over the host filesystem, rooted at the
 * owning workspace folder. Clicking a file opens it in the right-side preview
 * panel. Read-only in v1.
 */
import { Fragment, useEffect, useState } from 'react';
import type { ReactNode } from 'react';
import { IconEllipsisOutline16 } from '@deepseek-ai/dsh-client-ui-primitives';
import type { FsEntry } from '../contract';
import type { EnhanceApi } from '../rpc';
import { Menu, anchorOf, formatSize } from '../ui';
import { fileIconFor } from '../fileIcons';

export function FileBrowserPanel({
  root,
  api,
  openFile,
}: {
  root: string;
  api: EnhanceApi;
  openFile: (path: string, name: string) => void;
}) {
  const [cache, setCache] = useState<Record<string, FsEntry[]>>({});
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [loadingDirs, setLoadingDirs] = useState<Set<string>>(new Set());
  const [error, setError] = useState<string | null>(null);
  const [showHidden, setShowHidden] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);
  const [menu, setMenu] = useState<{ x: number; y: number } | null>(null);

  // Load the root listing whenever the root or a refresh changes.
  useEffect(() => {
    let cancelled = false;
    setError(null);
    api
      .fsList(root)
      .then((r) => {
        if (!cancelled) setCache((prev) => ({ ...prev, [r.path]: r.entries }));
      })
      .catch((e) => {
        if (!cancelled) setError(e instanceof Error ? e.message : String(e));
      });
    return () => {
      cancelled = true;
    };
  }, [root, reloadKey]); // eslint-disable-line react-hooks/exhaustive-deps

  const toggleDir = async (entry: FsEntry) => {
    const key = entry.path;
    if (expanded.has(key)) {
      const next = new Set(expanded);
      next.delete(key);
      setExpanded(next);
      return;
    }
    setLoadingDirs((prev) => new Set(prev).add(key));
    try {
      const r = await api.fsList(key);
      setCache((prev) => ({ ...prev, [key]: r.entries }));
      const next = new Set(expanded);
      next.add(key);
      setExpanded(next);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoadingDirs((prev) => {
        const next = new Set(prev);
        next.delete(key);
        return next;
      });
    }
  };

  const renderNode = (entry: FsEntry, depth: number): ReactNode => {
    if (entry.hidden && !showHidden) return null;
    const isOpen = expanded.has(entry.path);
    const busy = loadingDirs.has(entry.path);
    return (
      <Fragment key={entry.path}>
        <div
          className="dwe-tree-row"
          style={{ paddingLeft: 6 + depth * 14 }}
          data-dir={entry.isDir || undefined}
          onClick={() => {
            if (entry.isDir) void toggleDir(entry);
            else openFile(entry.path, entry.name);
          }}
        >
          <span className="dwe-row-sub">{entry.isDir ? (busy ? '◌' : isOpen ? '▾' : '▸') : ''}</span>
          {fileIconFor(entry, isOpen)}
          <span className="dwe-tree-label">{entry.name}</span>
          {!entry.isDir ? <span className="dwe-tree-meta">{formatSize(entry.size)}</span> : null}
        </div>
        {entry.isDir && isOpen && cache[entry.path]
          ? cache[entry.path].map((c) => renderNode(c, depth + 1))
          : null}
      </Fragment>
    );
  };

  const entries = cache[root];

  return (
    <div className="dwe-panel" style={{ paddingTop: 4 }}>
      <div className="dwe-toolbar">
        <span className="dwe-row-path" style={{ flex: 1 }}>
          {root}
        </span>
        <button
          type="button"
          className="dwe-iconbtn28"
          title="更多操作"
          onClick={(e) => setMenu(anchorOf(e))}
        >
          <IconEllipsisOutline16 size={16} />
        </button>
      </div>

      {menu ? (
        <Menu
          anchor={menu}
          onClose={() => setMenu(null)}
          items={[
            {
              label: '刷新文件夹',
              onSelect: () => setReloadKey((k) => k + 1),
            },
            {
              label: showHidden ? '隐藏 dot 文件' : '显示 dot 文件',
              onSelect: () => setShowHidden((v) => !v),
            },
          ]}
        />
      ) : null}

      {error ? <div className="dwe-error">{error}</div> : null}
      {!entries ? (
        <div className="dwe-hint">加载中…</div>
      ) : (
        <div className="dwe-tree">{entries.map((e) => renderNode(e, 0))}</div>
      )}
    </div>
  );
}
