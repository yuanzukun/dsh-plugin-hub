/**
 * 任务 tab (scoped to one workspace folder): sessions of that workspace with
 * open / rename / archive / hard-delete actions, using the built-in-aligned
 * SessionRow (status dot left of the title, time hidden on hover).
 */
import { useMemo, useState } from 'react';
import type { SessionId, SessionListState, SessionSummary, WorkspaceListState, WorkspaceView } from '@deepseek-ai/dsh-client-runtime/client';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import { ConfirmModal, PromptModal } from '../ui';
import { SessionRow } from '../rows';
import type { EnhanceInjected } from '../injected';

type Dialog =
  | { kind: 'rename-session'; id: SessionId; title: string }
  | { kind: 'delete-session'; id: SessionId; title: string };

export function SessionsPanel({
  workspace,
  useSessions,
  useWorkspaces,
  deletedSessionIds,
  markSessionDeleted,
  actions,
}: {
  workspace: WorkspaceView | undefined; // undefined = ungrouped bucket
  useSessions: SnapshotSelectorHook<SessionListState>;
  useWorkspaces: SnapshotSelectorHook<WorkspaceListState>;
  deletedSessionIds: readonly string[];
  markSessionDeleted: (id: SessionId) => void;
  actions: EnhanceInjected;
}) {
  const sessions = useSessions((s) => s);
  const workspaces = useWorkspaces((s) => s);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [busy, setBusy] = useState(false);
  const [dialogError, setDialogError] = useState<string | null>(null);

  const deleted = useMemo(() => new Set(deletedSessionIds), [deletedSessionIds]);

  const rows = useMemo(() => {
    const wsPaths = new Set(workspaces.items.map((w) => w.path));
    const out: SessionSummary[] = [];
    for (const id of sessions.ids) {
      const s = sessions.byId[id];
      if (!s || deleted.has(id) || s.blank) continue;
      const inWorkspace = workspace
        ? s.cwd === workspace.path || (workspace.sessionIds as readonly string[]).includes(id)
        : !(s.cwd && wsPaths.has(s.cwd)) && !workspaces.items.some((w) => (w.sessionIds as readonly string[]).includes(id));
      if (inWorkspace) out.push(s);
    }
    out.sort((a, b) => b.updatedAt - a.updatedAt);
    return out;
  }, [sessions.ids, sessions.byId, deleted, workspace, workspaces.items]);

  const runDialog = async (fn: () => Promise<void>) => {
    setBusy(true);
    setDialogError(null);
    try {
      await fn();
      setDialog(null);
    } catch (e) {
      setDialogError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  const handleDeleteSession = async (id: SessionId) => {
    await runDialog(async () => {
      const res = await actions.api.sessionDelete(id);
      if (!res.deleted) throw new Error(res.reason ?? '删除失败');
      markSessionDeleted(id);
      await actions.refreshSessions();
      if (sessions.current === id) {
        const next = sessions.ids.find((x) => x !== id && !deleted.has(x));
        if (next) actions.openSession(next);
      }
    });
  };

  if (rows.length === 0) {
    return (
      <div className="dwe-empty" style={{ paddingTop: 4 }}>
        暂无任务
      </div>
    );
  }

  return (
    <div className="dwe-list" style={{ paddingTop: 2 }}>
      {rows.map((s) => (
        <SessionRow
          key={s.id}
          session={s}
          current={s.id === sessions.current}
          onOpen={(id) => actions.openSession(id)}
          onRename={(id) => {
            const s2 = sessions.byId[id];
            setDialog({ kind: 'rename-session', id, title: s2?.displayTitle ?? '' });
          }}
          onArchive={(id) => {
            void actions.archiveSession(id).catch(() => {});
          }}
          onDelete={(id) => {
            const s2 = sessions.byId[id];
            setDialog({ kind: 'delete-session', id, title: s2?.displayTitle ?? '' });
          }}
        />
      ))}

      {dialog?.kind === 'rename-session' ? (
        <PromptModal
          title="重命名任务"
          initial={dialog.title}
          placeholder="任务标题"
          busy={busy}
          error={dialogError}
          onCancel={() => setDialog(null)}
          onConfirm={(v) => runDialog(() => actions.renameSession(dialog.id, v))}
        />
      ) : null}

      {dialog?.kind === 'delete-session' ? (
        <ConfirmModal
          title="彻底删除任务"
          danger
          busy={busy}
          error={dialogError}
          confirmLabel="彻底删除"
          onCancel={() => setDialog(null)}
          onConfirm={() => handleDeleteSession(dialog.id)}
        >
          将永久删除任务「{dialog.title || dialog.id}」的全部日志与记录，<b>无法恢复</b>。确定继续吗？
        </ConfirmModal>
      ) : null}
    </div>
  );
}
