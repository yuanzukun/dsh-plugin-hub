/**
 * Git tab: read-only view for one repository directory (the owning workspace
 * folder — the folder only shows this tab when git/status reported isRepo).
 * The top offers two sub-views:
 *   - Changes: the working-tree status entries (click a file to preview it).
 *   - Graph: the commit history with an ASCII branch graph (click a commit for
 *     its metadata, changed files, and the diff patch).
 */
import { useEffect, useMemo, useState } from 'react';
import { IconEllipsisOutline16 } from '@deepseek-ai/dsh-client-ui-primitives';
import type { GitCommit, GitShowResult, GitStatusResult } from '../contract';
import type { EnhanceApi } from '../rpc';
import { highlightCode } from '../highlight';
import { Menu, anchorOf, formatDate } from '../ui';

const STATUS_LABEL: Record<string, string> = {
  A: '新增',
  M: '修改',
  D: '删除',
  R: '重命名',
  C: '复制',
  T: '类型变更',
  U: '未合并',
  '?': '未跟踪',
};

/** Porcelain status letter -> color token. */
function statusColor(status: string): string {
  if (status === '?') return 'var(--dsw-alias-label-secondary)';
  if (status === 'D') return 'var(--dsw-alias-state-error-primary)';
  if (status === 'A' || status === 'R' || status === 'C') return 'var(--dsw-alias-state-success-primary)';
  return 'var(--dsw-alias-state-warn-primary)';
}

/** Combine the staged/unstaged porcelain pair into a short display label. */
function entryLabel(e: { x: string; y: string }): string {
  if (e.x === '?' && e.y === '?') return '?';
  const x = e.x !== ' ' ? e.x : '';
  const y = e.y !== ' ' && e.y !== e.x ? e.y : '';
  return (x + y) || e.x.trim() || e.y.trim() || '?';
}

export function GitPanel({
  repoPath,
  api,
  openFile,
}: {
  repoPath: string;
  api: EnhanceApi;
  openFile: (path: string, name: string) => void;
}) {
  const [view, setView] = useState<'changes' | 'graph'>('changes');
  const [status, setStatus] = useState<GitStatusResult | null>(null);
  const [commits, setCommits] = useState<GitCommit[]>([]);
  const [branches, setBranches] = useState<string[]>([]);
  const [branch, setBranch] = useState<string>('');
  const [logError, setLogError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [show, setShow] = useState<GitShowResult | null>(null);
  const [showLoading, setShowLoading] = useState(false);
  const [loadKey, setLoadKey] = useState(0);
  const [menu, setMenu] = useState<{ x: number; y: number } | null>(null);

  const loadRepo = async (dir: string) => {
    setLoading(true);
    setLogError(null);
    setSelected(null);
    setShow(null);
    try {
      const [st, lg, br] = await Promise.all([
        api.gitStatus(dir),
        api.gitLog(dir, 100, true),
        api.gitBranches(dir),
      ]);
      setStatus(st);
      if (br.isRepo) {
        setBranches(br.branches);
        // Default the branch selector to the current branch (fall back to the
        // first branch when the current one is missing, e.g. detached HEAD).
        setBranch(br.current && br.branches.includes(br.current) ? br.current : (br.branches[0] ?? ''));
      } else {
        setBranches([]);
        setBranch('');
      }
      if (lg.isRepo) setCommits(lg.commits);
      else {
        setCommits([]);
        setLogError(lg.error ?? '不是 git 仓库');
      }
    } catch (e) {
      setLogError(e instanceof Error ? e.message : String(e));
      setStatus(null);
      setCommits([]);
      setBranches([]);
      setBranch('');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadRepo(repoPath);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [repoPath, loadKey]);

  /** Re-fetch the commit graph for the selected branch. */
  const selectBranch = async (name: string) => {
    setBranch(name);
    setSelected(null);
    setShow(null);
    setLoading(true);
    setLogError(null);
    try {
      const lg = await api.gitLog(repoPath, 100, true, name);
      if (lg.isRepo) setCommits(lg.commits);
      else {
        setCommits([]);
        setLogError(lg.error ?? '加载提交失败');
      }
    } catch (e) {
      setLogError(e instanceof Error ? e.message : String(e));
      setCommits([]);
    } finally {
      setLoading(false);
    }
  };

  const openCommit = async (hash: string) => {
    setSelected(hash);
    setShowLoading(true);
    setShow(null);
    try {
      const r = await api.gitShow(repoPath, hash);
      setShow(r);
      if (!r.isRepo) setLogError(r.error ?? '加载提交失败');
    } catch (e) {
      setLogError(e instanceof Error ? e.message : String(e));
    } finally {
      setShowLoading(false);
    }
  };

  const absPath = (rel: string) => `${repoPath}\\${rel.replace(/\//g, '\\')}`;

  const dirtyCount = status?.entries.length ?? 0;
  const patchHtml = useMemo(() => {
    if (!show?.patch) return '';
    return highlightCode(show.patch, 'diff');
  }, [show]);

  // ── commit detail (from Graph) ───────────────────────────────────────────
  if (selected && (show || showLoading)) {
    return (
      <div className="dwe-panel" style={{ paddingTop: 4 }}>
        <div className="dwe-toolbar">
          <button type="button" className="dwe-btn" onClick={() => setSelected(null)}>
            ‹ 返回
          </button>
          <button
            type="button"
            className="dwe-btn"
            onClick={() => selected && void openCommit(selected)}
          >
            刷新
          </button>
        </div>
        {showLoading ? (
          <div className="dwe-hint">
            <span className="dwe-spinner" /> 加载提交…
          </div>
        ) : show && show.meta ? (
          <div className="dwe-git-detail">
            <div>
              <div className="dwe-git-subject">{show.meta.subject}</div>
              {show.meta.refs ? (
                <div className="dwe-git-meta-line" style={{ color: 'var(--dsw-alias-state-warn-primary)' }}>
                  {show.meta.refs}
                </div>
              ) : null}
              <div className="dwe-git-meta-line">{show.meta.shortHash}</div>
              <div className="dwe-git-meta-line">
                {show.meta.author} &lt;{show.meta.email}&gt; · {formatDate(show.meta.date)}
              </div>
              {show.meta.committer && show.meta.committer !== show.meta.author ? (
                <div className="dwe-git-meta-line">
                  提交者: {show.meta.committer} · {formatDate(show.meta.commitDate)}
                </div>
              ) : null}
            </div>
            {show.meta.body ? (
              <div className="dwe-modal-body" style={{ whiteSpace: 'pre-wrap' }}>
                {show.meta.body}
              </div>
            ) : null}
            <div className="dwe-sep" />
            <div className="dwe-git-meta-line">变更文件 ({show.files.length})</div>
            <div className="dwe-git-files">
              {show.files.map((f, i) => (
                <div key={i} className="dwe-git-file">
                  <span
                    className="dwe-git-status"
                    style={{ color: statusColor(f.status[0] ?? '') }}
                    title={STATUS_LABEL[f.status[0]] ?? f.status}
                  >
                    {f.status[0]}
                  </span>
                  <span className="dwe-tree-label">
                    {f.oldPath && f.oldPath !== f.path ? `${f.oldPath} → ${f.path}` : f.path}
                  </span>
                </div>
              ))}
            </div>
            {show.patch ? (
              <>
                <div className="dwe-sep" />
                <div className="dwe-git-meta-line">
                  Diff{show.patchTruncated ? '（已截断）' : ''}
                </div>
                <pre className="dwe-git-patch">
                  <code dangerouslySetInnerHTML={{ __html: patchHtml }} />
                </pre>
              </>
            ) : null}
          </div>
        ) : null}
      </div>
    );
  }

  // ── list views ───────────────────────────────────────────────────────────
  return (
    <div className="dwe-panel" style={{ paddingTop: 4 }}>
      <div className="dwe-toolbar">
        <div className="dwe-git-views">
          <button
            type="button"
            className="dwe-git-view"
            data-active={view === 'changes' || undefined}
            onClick={() => setView('changes')}
          >
            Changes
          </button>
          <button
            type="button"
            className="dwe-git-view"
            data-active={view === 'graph' || undefined}
            onClick={() => setView('graph')}
          >
            Graph
          </button>
        </div>
        <button
          type="button"
          className="dwe-iconbtn28"
          style={{ marginLeft: 'auto' }}
          title="更多操作"
          onClick={(e) => setMenu(anchorOf(e))}
        >
          <IconEllipsisOutline16 size={16} />
        </button>
      </div>

      {menu ? (
        <Menu
          anchor={menu}
          onClose={() => setMenu(null)}
          items={[
            {
              label: '刷新',
              onSelect: () => setLoadKey((k) => k + 1),
            },
          ]}
        />
      ) : null}

      {logError ? <div className="dwe-error">{logError}</div> : null}
      {loading ? (
        <div className="dwe-hint">
          <span className="dwe-spinner" /> 加载…
        </div>
      ) : null}

      {view === 'changes' ? (
        <>
          {status && status.isRepo ? (
            <div className="dwe-hint">
              {status.branch}
              {status.upstream ? ` → ${status.upstream}` : ''}
              {status.ahead > 0 ? ` · ahead ${status.ahead}` : ''}
              {status.behind > 0 ? ` · behind ${status.behind}` : ''}
              {dirtyCount > 0 ? ` · ${dirtyCount} 处改动` : ' · 干净'}
            </div>
          ) : null}
          {!loading && status && status.isRepo && dirtyCount === 0 ? (
            <div className="dwe-empty">工作区干净，无改动</div>
          ) : null}
          <div className="dwe-git-files">
            {status?.entries.map((e, i) => {
              const label = entryLabel(e);
              const full = absPath(e.path);
              const name = e.path.split('/').pop() ?? e.path;
              return (
                <div
                  key={i}
                  className="dwe-git-file"
                  data-clickable={true}
                  onClick={() => openFile(full, name)}
                  title="点击在右侧预览"
                >
                  <span className="dwe-git-status" style={{ color: statusColor(label[0]) }} title={STATUS_LABEL[label[0]] ?? label}>
                    {label}
                  </span>
                  <span className="dwe-tree-label">{e.path}</span>
                </div>
              );
            })}
          </div>
        </>
      ) : (
        <>
          {/* Branch selector row below the Changes/Graph tabs (left-aligned),
              defaulting to the current branch; switching re-fetches the graph. */}
          <div className="dwe-git-branchbar">
            <select
              className="dwe-select"
              value={branch}
              title="分支"
              aria-label="分支"
              onChange={(e) => void selectBranch(e.target.value)}
            >
              {branches.length === 0 ? <option value="">（无分支）</option> : null}
              {branches.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>
          </div>
          <div className="dwe-git-files">
            {commits.map((c) => (
              <div
                key={c.hash}
                className="dwe-git-commit"
                data-active={selected === c.hash || undefined}
                onClick={() => void openCommit(c.hash)}
              >
                <span className="dwe-git-subject">
                  {c.graph ? <span className="dwe-git-graph">{c.graph}</span> : null}
                  <span style={{ color: 'var(--dsw-alias-label-secondary)' }}>{c.shortHash}</span>{' '}
                  {c.refs ? <span style={{ color: 'var(--dsw-alias-state-warn-primary)' }}>[{c.refs}] </span> : null}
                  {c.subject}
                </span>
                <span className="dwe-git-meta-line">
                  {c.author} · {formatDate(c.date)}
                </span>
              </div>
            ))}
            {commits.length === 0 && !logError && !loading ? (
              <div className="dwe-empty">该仓库暂无提交记录。</div>
            ) : null}
          </div>
        </>
      )}
    </div>
  );
}
