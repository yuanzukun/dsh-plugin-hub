/**
 * The sidebar region entry (shadows the built-in workspace browser via
 * priority -1): a workspace-folder list aligned with the default browser —
 * built-in row styles (34px project rows with folder icon + hover chevron,
 * 32px session rows with the status dot left of the title), the right-aligned
 * section header (expandable search / add workspace / view options), group and
 * flat view modes, and an ungrouped bucket. Each folder expands into per-folder
 * sub-tabs (任务 / 文件浏览 / Git).
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import type { SessionId, SessionSearchResultItem, SessionSummary, WorkspaceId, WorkspaceView } from '@deepseek-ai/dsh-client-runtime/client';
import type { BakedActions, GlobalStandardProps, PropsStore, SnapshotSelectorHook, StoreHandle } from '@deepseek-ai/dsh-client-ui-slots';
import type { SidebarSectionOwnerProps } from '@deepseek-ai/dsh-client-ui-sidebar/client';
import { IconPersonalizationOutline16, IconPlusOutline16, IconSearchOutline16 } from '@deepseek-ai/dsh-client-ui-primitives';
import type { EnhanceState, EnhanceStoreHandle } from '../store';
import type { EnhanceInjected } from '../injected';
import type { TabId } from '../contract';
import { WorkspaceFolderTabs } from './WorkspaceFolderTabs';
import { SessionsPanel } from './SessionsPanel';
import { SessionRow, ProjectRow } from '../rows';
import { ConfirmModal, Menu, PromptModal, SessionStatusDot, anchorOf, timeAgo } from '../ui';
import { PanelErrorBoundary } from '../ErrorBoundary';

type EnhanceActions = EnhanceStoreHandle extends StoreHandle<infer T, infer A> ? BakedActions<T, A> : never;

export type WorkspaceRegionProps = SidebarSectionOwnerProps &
  GlobalStandardProps &
  PropsStore<EnhanceStoreHandle> &
  EnhanceInjected;

type Dialog =
  | { kind: 'rename-workspace'; id: WorkspaceId; title: string }
  | { kind: 'delete-workspace'; id: WorkspaceId; title: string }
  | { kind: 'rename-session'; id: SessionId; title: string }
  | { kind: 'delete-session'; id: SessionId; title: string };

export function WorkspaceRegion(props: WorkspaceRegionProps) {
  const { wide, expandSidebar, useSessions, useWorkspaces, useStore, actions, ...injected } = props;
  const face = injected as EnhanceInjected;

  const sessions = useSessions((s) => s);
  const workspaces = useWorkspaces((s) => s);
  const deletedSessionIds = useStore((s) => s.deletedSessionIds);
  const groupBy = useStore((s) => s.view.groupBy);
  const orderBy = useStore((s) => s.view.orderBy);

  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [menu, setMenu] = useState<{ anchor: { x: number; y: number }; id: string } | null>(null);
  const [viewMenu, setViewMenu] = useState<{ x: number; y: number } | null>(null);
  const [dialog, setDialog] = useState<Dialog | null>(null);
  const [busy, setBusy] = useState(false);
  const [dialogError, setDialogError] = useState<string | null>(null);
  const [addingWorkspace, setAddingWorkspace] = useState(false);
  const [wsPath, setWsPath] = useState('');
  const [wsError, setWsError] = useState<string | null>(null);

  // ── search ───────────────────────────────────────────────────────────────
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [contentHits, setContentHits] = useState<SessionSearchResultItem[]>([]);
  const [searchBusy, setSearchBusy] = useState(false);
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  const trimmed = query.trim();
  const deleted = useMemo(() => new Set(deletedSessionIds), [deletedSessionIds]);

  // Debounced content search against the host index (like the built-in).
  useEffect(() => {
    if (!trimmed) {
      setContentHits([]);
      setSearchBusy(false);
      return;
    }
    setSearchBusy(true);
    const ctrl = new AbortController();
    const handle = setTimeout(() => {
      face
        .searchSessions(trimmed, ctrl.signal)
        .then((res) => {
          setContentHits(res.items);
          setSearchBusy(false);
        })
        .catch(() => {
          setContentHits([]);
          setSearchBusy(false);
        });
    }, 250);
    return () => {
      clearTimeout(handle);
      ctrl.abort();
    };
  }, [trimmed]); // eslint-disable-line react-hooks/exhaustive-deps

  // Client-side metadata matches (title / workspace / path).
  const metaMatches = useMemo(() => {
    if (!trimmed) return [];
    const q = trimmed.toLowerCase();
    const out: { session: SessionSummary; workspaceTitle?: string }[] = [];
    for (const id of sessions.ids) {
      const s = sessions.byId[id];
      if (!s || s.blank || deleted.has(id)) continue;
      const ws = workspaces.items.find(
        (w) => w.path === s.cwd || (w.sessionIds as readonly string[]).includes(id),
      );
      const hay = `${s.displayTitle} ${s.cwd ?? ''} ${ws?.title ?? ''}`.toLowerCase();
      if (hay.includes(q)) out.push({ session: s, workspaceTitle: ws?.title });
    }
    return out;
  }, [trimmed, sessions, deleted, workspaces.items]);

  // Merged search results: metadata hits first, then content hits.
  const searchResults = useMemo(() => {
    if (!trimmed) return null;
    const byId = new Map<string, { session: SessionSummary; workspaceTitle?: string; snippet?: string }>();
    for (const m of metaMatches) byId.set(m.session.id, m);
    for (const c of contentHits) {
      const existing = byId.get(c.sessionId);
      if (existing) existing.snippet = c.snippet;
      else {
        const s = sessions.byId[c.sessionId];
        if (s && !deleted.has(s.id)) {
          const ws = workspaces.items.find(
            (w) => w.path === s.cwd || (w.sessionIds as readonly string[]).includes(s.id),
          );
          byId.set(c.sessionId, { session: s, workspaceTitle: ws?.title, snippet: c.snippet });
        }
      }
    }
    return [...byId.values()];
  }, [trimmed, metaMatches, contentHits, sessions.byId, deleted, workspaces.items]);

  // ── derived lists ────────────────────────────────────────────────────────
  const activeWorkspaceId = useMemo(() => {
    if (!sessions.current) return undefined;
    const cur = sessions.byId[sessions.current];
    if (!cur) return undefined;
    return workspaces.items.find(
      (w) => w.path === cur.cwd || (w.sessionIds as readonly string[]).includes(cur.id),
    )?.workspaceId;
  }, [sessions.current, sessions.byId, workspaces.items]);

  const liveSessions = useMemo(() => {
    const out: SessionSummary[] = [];
    for (const id of sessions.ids) {
      const s = sessions.byId[id];
      if (s && !deleted.has(id) && !s.blank) out.push(s);
    }
    return out;
  }, [sessions.ids, sessions.byId, deleted]);

  const flatSessions = useMemo(() => {
    const out = [...liveSessions];
    if (orderBy === 'updated') out.sort((a, b) => b.updatedAt - a.updatedAt);
    return out;
  }, [liveSessions, orderBy]);

  const ungroupedSessions = useMemo(() => {
    const wsPaths = new Set(workspaces.items.map((w) => w.path));
    return liveSessions.filter(
      (s) =>
        !(s.cwd && wsPaths.has(s.cwd)) &&
        !workspaces.items.some((w) => (w.sessionIds as readonly string[]).includes(s.id)),
    );
  }, [liveSessions, workspaces.items]);

  const isExpanded = (key: string) => expanded[key] ?? true;
  const toggleExpanded = (key: string) =>
    setExpanded((prev) => ({ ...prev, [key]: !(prev[key] ?? true) }));

  // Clicking a workspace folder switches the right-side task workspace to
  // that folder: open its most recent session, or connect its blank session
  // when it has none. Making that session current also lights the folder row
  // blue (data-active follows the current session's workspace) and makes the
  // built-in "新会话" button create new sessions in this folder's directory
  // (startSession resolves the current session's workspace first).
  const selectWorkspace = (w: WorkspaceView) => {
    toggleExpanded(`ws:${w.workspaceId}`);
    const latest = (w.sessionIds as readonly string[])
      .map((id) => sessions.byId[id])
      .filter((s) => s && !deleted.has(s.id) && !s.blank)
      .sort((a, b) => b.updatedAt - a.updatedAt)[0];
    if (latest) {
      face.openSession(latest.id);
    } else {
      void face
        .connectWorkspace(w.workspaceId)
        .then((id) => face.openSession(id))
        .catch(() => {});
    }
  };

  const runDialog = async (fn: () => Promise<void>) => {
    setBusy(true);
    setDialogError(null);
    try {
      await fn();
      setDialog(null);
    } catch (e) {
      setDialogError(e instanceof Error ? e.message : String(e));
    } finally {
      setBusy(false);
    }
  };

  // ── add workspace (built-in flow: native directory picker) ──────────────
  const handleAddWorkspace = async () => {
    setWsError(null);
    try {
      const p = await face.pickWorkspaceDir();
      if (p) await face.createWorkspace(p);
    } catch (e) {
      // Picker unavailable — fall back to the manual path row.
      setWsError(e instanceof Error ? e.message : String(e));
      setAddingWorkspace(true);
    }
  };

  const handleAddWorkspacePath = async () => {
    const p = wsPath.trim();
    if (!p) return;
    setWsError(null);
    try {
      await face.createWorkspace(p);
      setWsPath('');
      setAddingWorkspace(false);
    } catch (e) {
      setWsError(e instanceof Error ? e.message : String(e));
    }
  };

  const folderMenuItems = (w: WorkspaceView) => [
    { label: '新建任务', onSelect: () => face.startSession(w.workspaceId) },
    {
      label: '重命名',
      onSelect: () => setDialog({ kind: 'rename-workspace', id: w.workspaceId, title: w.title }),
    },
    {
      label: '删除工作区',
      danger: true,
      onSelect: () => setDialog({ kind: 'delete-workspace', id: w.workspaceId, title: w.title }),
    },
  ];

  // ── rail mode (collapsed sidebar) ────────────────────────────────────────
  if (!wide) {
    return (
      <div className="dwe-rail">
        {(
          [
            ['sessions', '💬'],
            ['files', '📁'],
            ['git', '⎇'],
          ] as const
        ).map(([id, icon]) => (
          <button
            key={id}
            type="button"
            className="dwe-rail-button"
            title={{ sessions: '任务', files: '文件', git: 'Git' }[id]}
            onClick={() => {
              const cur = sessions.current ? sessions.byId[sessions.current] : undefined;
              const target =
                workspaces.items.find(
                  (w) => cur && (w.path === cur.cwd || (w.sessionIds as readonly string[]).includes(cur.id)),
                ) ?? workspaces.items[0];
              if (target) actions.setWorkspaceTab(target.workspaceId, id);
              expandSidebar();
            }}
          >
            {icon}
          </button>
        ))}
      </div>
    );
  }

  const searching = searchOpen && trimmed.length > 0;

  return (
    <div className="dwe-tabs">
      {/* ── section header: label / search / add / view (built-in aligned) ── */}
      <div className="dwe-section-header">
        <span className="dwe-section-label" data-hidden={searchOpen || undefined}>
          {groupBy === 'flat' ? '任务' : '工作区'}
        </span>
        <span className="dwe-search-slot" data-open={searchOpen || undefined}>
          <div className="dwe-search" data-open={searchOpen || undefined}>
            <button
              type="button"
              className="dwe-search-button"
              aria-label="搜索任务"
              title="搜索任务"
              onClick={() => {
                const next = !searchOpen;
                setSearchOpen(next);
                if (next) requestAnimationFrame(() => searchInputRef.current?.focus());
                else {
                  setQuery('');
                  setContentHits([]);
                }
              }}
            >
              <IconSearchOutline16 size={searchOpen ? 11 : 14} />
            </button>
            <input
              ref={searchInputRef}
              className="dwe-search-input"
              placeholder="搜索任务…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Escape') {
                  setSearchOpen(false);
                  setQuery('');
                }
              }}
            />
            {trimmed ? (
              <button
                type="button"
                className="dwe-clear-button"
                title="清除"
                onClick={() => {
                  setQuery('');
                  setContentHits([]);
                }}
              >
                ✕
              </button>
            ) : null}
          </div>
        </span>
        <span className="dwe-header-actions" data-hidden={searchOpen || undefined}>
          <button
            type="button"
            className="dwe-iconbtn28"
            aria-label="添加工作区"
            title="添加工作区"
            onClick={() => void handleAddWorkspace()}
          >
            <IconPlusOutline16 size={16} />
          </button>
          <button
            type="button"
            className="dwe-iconbtn28"
            aria-label="视图选项"
            title="视图选项"
            onClick={(e) => setViewMenu(anchorOf(e))}
          >
            <IconPersonalizationOutline16 size={16} />
          </button>
        </span>
      </div>

      {addingWorkspace ? (
        <div className="dwe-toolbar" style={{ padding: '0 8px 4px' }}>
          <input
            className="dwe-input"
            placeholder="输入工作区目录绝对路径…"
            value={wsPath}
            onChange={(e) => setWsPath(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') void handleAddWorkspacePath();
            }}
          />
          <button
            type="button"
            className="dwe-btn dwe-btn-primary"
            onClick={() => void handleAddWorkspacePath()}
          >
            添加
          </button>
        </div>
      ) : null}
      {wsError ? (
        <div className="dwe-error" style={{ padding: '0 8px 4px' }}>
          {wsError}
        </div>
      ) : null}

      {/* ── body ── */}
      <div className="dwe-scroll">
        {searching ? (
          <div className="dwe-search-tree">
            {searchResults && searchResults.length > 0 ? (
              searchResults.map((r) => (
                <div
                  key={r.session.id}
                  className="dwe-search-result-row"
                  data-current={r.session.id === sessions.current || undefined}
                  onClick={() => face.openSession(r.session.id)}
                >
                  <span className="dwe-search-result-heading">
                    <SessionStatusDot session={r.session} current={r.session.id === sessions.current} />
                    <span className="dwe-search-result-title">{r.session.displayTitle}</span>
                  </span>
                  <span className="dwe-search-result-meta">
                    {r.workspaceTitle ? (
                      <span className="dwe-search-result-workspace">{r.workspaceTitle}</span>
                    ) : null}
                    <span className="dwe-search-result-snippet">
                      {r.snippet ?? timeAgo(r.session.updatedAt)}
                    </span>
                  </span>
                </div>
              ))
            ) : searchBusy ? (
              <div className="dwe-search-status">搜索中…</div>
            ) : (
              <div className="dwe-search-status">无匹配任务</div>
            )}
          </div>
        ) : groupBy === 'flat' ? (
          <div className="dwe-list dwe-flat-list">
            {flatSessions.map((s) => (
              <SessionRow
                key={s.id}
                session={s}
                current={s.id === sessions.current}
                onOpen={(id) => face.openSession(id)}
                onRename={(id) => {
                  const s2 = sessions.byId[id];
                  setDialog({ kind: 'rename-session', id, title: s2?.displayTitle ?? '' });
                }}
                onArchive={(id) => {
                  void face.archiveSession(id).catch(() => {});
                }}
                onDelete={(id) => {
                  const s2 = sessions.byId[id];
                  setDialog({ kind: 'delete-session', id, title: s2?.displayTitle ?? '' });
                }}
              />
            ))}
            {flatSessions.length === 0 ? (
              <div className="dwe-empty">暂无任务</div>
            ) : null}
          </div>
        ) : (
          <>
            {workspaces.items.length === 0 && ungroupedSessions.length === 0 ? (
              <div className="dwe-empty">
                暂无工作区与任务。点击右上角「＋」添加工作区，或从新建任务开始。
              </div>
            ) : null}

            {workspaces.items.map((w) => {
              const key = `ws:${w.workspaceId}`;
              const open = isExpanded(key);
              return (
                <div key={w.workspaceId} className="dwe-group-section">
                  <ProjectRow
                    title={w.title}
                    open={open}
                    active={activeWorkspaceId === w.workspaceId}
                    onToggle={() => selectWorkspace(w)}
                    onAddSession={() => face.startSession(w.workspaceId)}
                    onMenu={(anchor) => setMenu({ anchor, id: w.workspaceId })}
                  />
                  {open ? (
                    <div className="dwe-folder-body">
                      <PanelErrorBoundary>
                        <WorkspaceFolderTabs
                          workspace={w}
                          useSessions={useSessions}
                          useWorkspaces={useWorkspaces}
                          useStore={useStore}
                          actions={actions}
                          face={face}
                        />
                      </PanelErrorBoundary>
                    </div>
                  ) : null}
                </div>
              );
            })}

            {ungroupedSessions.length > 0 ? (
              <div className="dwe-group-section">
                <ProjectRow
                  title={`未分组 (${ungroupedSessions.length})`}
                  open={isExpanded('ws:__ungrouped__')}
                  onToggle={() => toggleExpanded('ws:__ungrouped__')}
                  onAddSession={() => face.startSession()}
                  onMenu={() => {}}
                />
                {isExpanded('ws:__ungrouped__') ? (
                  <div className="dwe-folder-body">
                    <PanelErrorBoundary>
                      <SessionsPanel
                        workspace={undefined}
                        useSessions={useSessions}
                        useWorkspaces={useWorkspaces}
                        deletedSessionIds={deletedSessionIds}
                        markSessionDeleted={actions.markSessionDeleted}
                        actions={face}
                      />
                    </PanelErrorBoundary>
                  </div>
                ) : null}
              </div>
            ) : null}
          </>
        )}
      </div>

      {/* ── menus ── */}
      {menu ? (
        <Menu
          anchor={menu.anchor}
          onClose={() => setMenu(null)}
          items={(() => {
            const w = workspaces.items.find((x) => x.workspaceId === menu.id);
            return w ? folderMenuItems(w) : [];
          })()}
        />
      ) : null}

      {viewMenu ? (
        <Menu
          anchor={viewMenu}
          onClose={() => setViewMenu(null)}
          items={[
            {
              label: groupBy === 'workspace' ? '分组：按工作区 ✓' : '分组：按工作区',
              onSelect: () => actions.setGroupBy('workspace'),
            },
            {
              label: groupBy === 'flat' ? '分组：平铺列表 ✓' : '分组：平铺列表',
              onSelect: () => actions.setGroupBy('flat'),
            },
            {
              label: orderBy === 'updated' ? '排序：最近更新 ✓' : '排序：最近更新',
              onSelect: () => actions.setOrderBy('updated'),
            },
            {
              label: orderBy === 'manual' ? '排序：手动 ✓' : '排序：手动',
              onSelect: () => actions.setOrderBy('manual'),
            },
            { label: '—', onSelect: () => {} },
            {
              label: '按路径添加工作区…',
              onSelect: () => setAddingWorkspace(true),
            },
          ]}
        />
      ) : null}

      {/* ── dialogs ── */}
      {dialog?.kind === 'rename-workspace' ? (
        <PromptModal
          title="重命名工作区"
          initial={dialog.title}
          placeholder="工作区标题"
          busy={busy}
          error={dialogError}
          onCancel={() => setDialog(null)}
          onConfirm={(v) => runDialog(() => face.renameWorkspace(dialog.id, v))}
        />
      ) : null}

      {dialog?.kind === 'delete-workspace' ? (
        <ConfirmModal
          title="删除工作区"
          danger
          busy={busy}
          error={dialogError}
          confirmLabel="删除"
          onCancel={() => setDialog(null)}
          onConfirm={() => runDialog(() => face.deleteWorkspace(dialog.id))}
        >
          删除工作区「{dialog.title}」只会移除其注册记录，目录与其中的任务日志都会保留，任务将转入未分组。
        </ConfirmModal>
      ) : null}

      {dialog?.kind === 'rename-session' ? (
        <PromptModal
          title="重命名任务"
          initial={dialog.title}
          placeholder="任务标题"
          busy={busy}
          error={dialogError}
          onCancel={() => setDialog(null)}
          onConfirm={(v) => runDialog(() => face.renameSession(dialog.id, v))}
        />
      ) : null}

      {dialog?.kind === 'delete-session' ? (
        <ConfirmModal
          title="彻底删除任务"
          danger
          busy={busy}
          error={dialogError}
          confirmLabel="彻底删除"
          onCancel={() => setDialog(null)}
          onConfirm={() =>
            runDialog(async () => {
              const res = await face.api.sessionDelete(dialog.id);
              if (!res.deleted) throw new Error(res.reason ?? '删除失败');
              actions.markSessionDeleted(dialog.id);
              await face.refreshSessions();
              if (sessions.current === dialog.id) {
                const next = sessions.ids.find((x) => x !== dialog.id && !deleted.has(x));
                if (next) face.openSession(next);
              }
            })
          }
        >
          将永久删除任务「{dialog.title || dialog.id}」的全部日志与记录，<b>无法恢复</b>。确定继续吗？
        </ConfirmModal>
      ) : null}
    </div>
  );
}
