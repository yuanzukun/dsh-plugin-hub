/**
 * Per-workspace sub-tabs: 任务 / 文件浏览 / Git under one workspace folder.
 * The Git tab only appears once the host confirms the folder is a git
 * repository (git/status isRepo); non-repo folders never show it.
 */
import { useEffect, useState } from 'react';
import type { SessionListState, WorkspaceListState, WorkspaceView } from '@deepseek-ai/dsh-client-runtime/client';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import type { EnhanceState } from '../store';
import type { EnhanceInjected } from '../injected';
import type { TabId } from '../contract';
import type { GitStatusResult } from '../contract';
import { SessionsPanel } from './SessionsPanel';
import { FileBrowserPanel } from './FileBrowserPanel';
import { GitPanel } from './GitPanel';
import { PanelErrorBoundary } from '../ErrorBoundary';

export interface WorkspaceFolderTabsProps {
  workspace: WorkspaceView;
  useSessions: SnapshotSelectorHook<SessionListState>;
  useWorkspaces: SnapshotSelectorHook<WorkspaceListState>;
  useStore: SnapshotSelectorHook<EnhanceState>;
  actions: {
    setWorkspaceTab: (workspaceId: string, tab: TabId) => void;
    markSessionDeleted: (sessionId: string) => void;
  };
  face: EnhanceInjected;
}

export function WorkspaceFolderTabs({
  workspace,
  useSessions,
  useWorkspaces,
  useStore,
  actions,
  face,
}: WorkspaceFolderTabsProps) {
  const deletedSessionIds = useStore((s) => s.deletedSessionIds);

  // ── git facts: is this folder a repo? drives the Git tab ─────────────────
  const [gitState, setGitState] = useState<'checking' | 'yes' | 'no'>('checking');

  // Ask the host whether this folder is a git repository; drives the Git tab.
  useEffect(() => {
    let cancelled = false;
    setGitState('checking');
    face.api
      .gitStatus(workspace.path)
      .then((st: GitStatusResult) => {
        if (cancelled) return;
        setGitState(st.isRepo ? 'yes' : 'no');
      })
      .catch(() => {
        if (!cancelled) setGitState('no');
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [workspace.path]);

  const tab = useStore((s) => s.workspaceTabs[workspace.workspaceId] ?? ('sessions' as TabId));
  const effectiveTab: TabId = tab === 'git' && gitState !== 'yes' ? 'sessions' : tab;

  const tabs: { id: TabId; label: string }[] = [
    { id: 'sessions', label: '任务' },
    { id: 'files', label: '文件' },
  ];
  if (gitState === 'yes') tabs.push({ id: 'git', label: 'Git' });

  const select = (id: TabId) => {
    if (id === 'git' && gitState !== 'yes') return;
    actions.setWorkspaceTab(workspace.workspaceId, id);
  };

  return (
    <div className="dwe-folder">
      <div className="dwe-folder-tabs">
        {tabs.map((t) => (
          <button
            key={t.id}
            type="button"
            className="dwe-tab"
            data-active={effectiveTab === t.id || undefined}
            onClick={() => select(t.id)}
          >
            {t.label}
          </button>
        ))}
        {gitState === 'checking' ? <span className="dwe-folder-git-hint">git…</span> : null}
      </div>
      <PanelErrorBoundary>
        {effectiveTab === 'sessions' ? (
          <SessionsPanel
            workspace={workspace}
            useSessions={useSessions}
            useWorkspaces={useWorkspaces}
            deletedSessionIds={deletedSessionIds}
            markSessionDeleted={actions.markSessionDeleted}
            actions={face}
          />
        ) : null}
        {effectiveTab === 'files' ? (
          <FileBrowserPanel root={workspace.path} api={face.api} openFile={face.openFile} />
        ) : null}
        {effectiveTab === 'git' ? (
          <GitPanel repoPath={workspace.path} api={face.api} openFile={face.openFile} />
        ) : null}
      </PanelErrorBoundary>
    </div>
  );
}
