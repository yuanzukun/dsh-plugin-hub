/**
 * Shared browser store (v3): the open file preview, local tombstones for
 * hard-deleted sessions, the per-workspace active tab (each workspace folder
 * owns its own 任务/文件浏览/Git selection), and the list view mode
 * (grouping + ordering) mirroring the built-in workspace browser.
 */
import { defineStore } from '@deepseek-ai/dsh-client-runtime/client';
import type { PreviewState, TabId } from './contract';

export type GroupBy = 'workspace' | 'flat';
export type OrderBy = 'updated' | 'manual';

export interface EnhanceState {
  /** Open file preview; null = panel hidden. */
  preview: PreviewState | null;
  /** Sessions locally hard-deleted this session (filtered from lists). */
  deletedSessionIds: string[];
  /** Active sub-tab per workspace id; absent = 'sessions'. */
  workspaceTabs: Record<string, TabId>;
  /** List view mode (mirrors the built-in browser's view options). */
  view: {
    groupBy: GroupBy;
    orderBy: OrderBy;
  };
}

export function createEnhanceStore() {
  return defineStore({
    init: (): EnhanceState => ({
      preview: null,
      deletedSessionIds: [],
      workspaceTabs: {},
      view: { groupBy: 'workspace', orderBy: 'updated' },
    }),
    persist: 'dsh.workspace.enhance.v3',
    actions: {
      openPreview: (d, path: string, name: string) => {
        d.preview = { path, name, status: 'loading' };
      },
      setPreview: (d, preview: PreviewState) => {
        d.preview = preview;
      },
      closePreview: (d) => {
        d.preview = null;
      },
      markSessionDeleted: (d, sessionId: string) => {
        if (!d.deletedSessionIds.includes(sessionId)) d.deletedSessionIds.push(sessionId);
      },
      setWorkspaceTab: (d, workspaceId: string, tab: TabId) => {
        d.workspaceTabs[workspaceId] = tab;
      },
      setGroupBy: (d, groupBy: GroupBy) => {
        d.view.groupBy = groupBy;
      },
      setOrderBy: (d, orderBy: OrderBy) => {
        d.view.orderBy = orderBy;
      },
    },
  });
}

export type EnhanceStoreHandle = ReturnType<typeof createEnhanceStore>;
