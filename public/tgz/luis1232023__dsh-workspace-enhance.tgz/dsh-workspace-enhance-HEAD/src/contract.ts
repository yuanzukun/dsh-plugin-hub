/**
 * Shared contract types for the browser half. Mirrors the node half's RPC
 * payload/result shapes (lib/index.js). Types only — erased at build time.
 */

export interface FsRoot {
  cwd: string;
  home: string;
  dshHome: string;
}

export interface FsEntry {
  name: string;
  path: string;
  isDir: boolean;
  hidden: boolean;
  size: number;
  mtimeMs: number;
}

export interface FsListResult {
  path: string;
  entries: FsEntry[];
  truncated: boolean;
}

export type FsReadResult =
  | { kind: 'text'; name: string; path: string; size: number; truncated: boolean; language: string; content: string }
  | { kind: 'image'; name: string; path: string; size: number; mime: string; dataUrl: string }
  | { kind: 'binary'; name: string; path: string; size: number };

export interface GitCommit {
  hash: string;
  shortHash: string;
  author: string;
  email: string;
  date: string;
  subject: string;
  refs: string;
  /** ASCII graph prefix when requested with graph mode (git log --graph). */
  graph?: string;
}

export interface GitLogResult {
  isRepo: boolean;
  commits: GitCommit[];
  error?: string;
}

export interface GitStatusEntry {
  x: string;
  y: string;
  path: string;
}

export interface GitStatusResult {
  isRepo: boolean;
  branch: string;
  upstream?: string;
  ahead: number;
  behind: number;
  noCommits: boolean;
  entries: GitStatusEntry[];
  error?: string;
}

export interface GitBranchesResult {
  isRepo: boolean;
  branches: string[];
  current?: string;
  error?: string;
}

export interface GitShowFile {
  status: string;
  path: string;
  oldPath?: string;
}

export interface GitShowResult {
  isRepo: boolean;
  meta?: {
    hash: string;
    shortHash: string;
    author: string;
    email: string;
    date: string;
    committer: string;
    committerEmail: string;
    commitDate: string;
    subject: string;
    body: string;
    refs: string;
  };
  files: GitShowFile[];
  patch: string;
  patchTruncated: boolean;
  error?: string;
}

export interface SessionDeleteResult {
  deleted: boolean;
  reason?: string;
  removedDirs?: string[];
}

export interface PreviewState {
  path: string;
  name: string;
  status: 'loading' | 'ready' | 'error';
  message?: string;
  read?: FsReadResult;
}

export type TabId = 'sessions' | 'files' | 'git';
