/**
 * Markdown → HTML renderer for the preview panel (GFM).
 *
 * Pipeline: micromark (+ GFM extensions) → mdast → hast → HTML string.
 * Code blocks are syntax-highlighted with the same Prism pipeline as the
 * source view. Raw HTML in the markdown source is escaped by micromark
 * (allowDangerousHtml stays off), so the output only ever contains markup we
 * generated ourselves — the `allowDangerousHtml: true` below only re-enables
 * the `raw` nodes OUR code handler produces.
 *
 * The mdast/hast packages are bundled into lib/client.js at build time
 * (devDependencies), like prismjs.
 */
import { fromMarkdown } from 'mdast-util-from-markdown';
import { gfm } from 'micromark-extension-gfm';
import { gfmFromMarkdown } from 'mdast-util-gfm';
import { toHast } from 'mdast-util-to-hast';
import { toHtml } from 'hast-util-to-html';
import { highlightCode } from './highlight';

export function markdownToHtml(md: string): string {
  const tree = fromMarkdown(md, {
    extensions: [gfm()],
    mdastExtensions: [gfmFromMarkdown()],
  });
  const hast = toHast(tree, {
    handlers: {
      // Syntax-highlight fenced code blocks with the plugin's Prism pipeline.
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      code(state, node: any) {
        const lang = node.lang || '';
        const cls = lang ? `language-${lang}` : '';
        const body = highlightCode(node.value, lang || undefined);
        return {
          type: 'raw',
          value: `<pre class="${cls}"><code class="${cls}">${body}</code></pre>`,
          // `raw` is a hast-util-to-html-only node; cast to satisfy toHast's
          // handler return type.
        } as never;
      },
    },
  });
  return toHtml(hast as never, { allowDangerousHtml: true });
}
