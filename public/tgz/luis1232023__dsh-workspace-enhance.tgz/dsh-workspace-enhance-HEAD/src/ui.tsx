/**
 * Small shared UI primitives for the plugin: status dots, dropdown menus,
 * modals (confirm / prompt), and formatting helpers. All styling lives in
 * styles.ts under the dwe- prefix.
 */
import { useEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import type { SessionSummary } from '@deepseek-ai/dsh-client-runtime/client';
import { StateDot } from '@deepseek-ai/dsh-client-ui-primitives';

export function timeAgo(ms: number): string {
  const diff = Date.now() - ms;
  const min = Math.floor(diff / 60000);
  if (min < 1) return '刚刚';
  if (min < 60) return `${min}分钟前`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${hr}小时前`;
  const day = Math.floor(hr / 24);
  if (day < 30) return `${day}天前`;
  const mon = Math.floor(day / 30);
  if (mon < 12) return `${mon}个月前`;
  return `${Math.floor(mon / 12)}年前`;
}

export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function formatDate(iso: string): string {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString();
}

/**
 * Status dot for a session row, mirroring the built-in browser: pending
 * interaction = warning dot, running = animated ongoing matrix, otherwise the
 * done dot. The CURRENT session's idle dot lights up blue — matching the
 * folder row's active state — while only non-current idle sessions keep the
 * gray dot. Rendered in the row's status slot to the LEFT of the title.
 */
export function SessionStatusDot({ session, current }: { session: SessionSummary; current?: boolean }) {
  if (session.pendingInteraction) {
    return <StateDot state="warning" className="dwe-dot-slot" />;
  }
  if (session.running) {
    return <StateDot state="ongoing" className="dwe-dot-slot" />;
  }
  return <StateDot state="done" className={current ? 'dwe-dot-slot dwe-dot-current' : 'dwe-dot-slot'} />;
}

export interface MenuItem {
  label: string;
  danger?: boolean;
  onSelect: () => void;
}

/** Fixed-position dropdown menu anchored at an element; closes on outside click. */
export function Menu({
  anchor,
  items,
  onClose,
}: {
  anchor: { x: number; y: number } | null;
  items: MenuItem[];
  onClose: () => void;
}) {
  const ref = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!anchor) return;
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [anchor, onClose]);

  if (!anchor) return null;
  const style: React.CSSProperties = {
    left: Math.min(anchor.x, window.innerWidth - 160),
    top: Math.min(anchor.y, window.innerHeight - items.length * 30 - 12),
  };
  return (
    <div ref={ref} className="dwe-menu" style={style}>
      {items.map((it, i) => (
        <button
          key={i}
          type="button"
          className="dwe-menu-item"
          data-danger={it.danger || undefined}
          onClick={() => {
            onClose();
            it.onSelect();
          }}
        >
          {it.label}
        </button>
      ))}
    </div>
  );
}

export function Modal({
  title,
  children,
  onClose,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
}) {
  return (
    <div className="dwe-backdrop" onMouseDown={onClose}>
      <div className="dwe-modal" onMouseDown={(e) => e.stopPropagation()}>
        <div className="dwe-modal-title">{title}</div>
        {children}
      </div>
    </div>
  );
}

export function ConfirmModal({
  title,
  children,
  confirmLabel = '确定',
  danger,
  busy,
  error,
  onConfirm,
  onCancel,
}: {
  title: string;
  children: ReactNode;
  confirmLabel?: string;
  danger?: boolean;
  busy?: boolean;
  error?: string | null;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  return (
    <Modal title={title} onClose={onCancel}>
      <div className="dwe-modal-body">{children}</div>
      {error ? <div className="dwe-error">{error}</div> : null}
      <div className="dwe-modal-actions">
        <button type="button" className="dwe-btn" onClick={onCancel} disabled={busy}>
          取消
        </button>
        <button
          type="button"
          className={danger ? 'dwe-btn dwe-btn-danger' : 'dwe-btn dwe-btn-primary'}
          onClick={onConfirm}
          disabled={busy}
        >
          {confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

export function PromptModal({
  title,
  placeholder,
  initial = '',
  confirmLabel = '确定',
  busy,
  error,
  onConfirm,
  onCancel,
}: {
  title: string;
  placeholder?: string;
  initial?: string;
  confirmLabel?: string;
  busy?: boolean;
  error?: string | null;
  onConfirm: (value: string) => void;
  onCancel: () => void;
}) {
  const [value, setValue] = useState(initial);
  return (
    <Modal title={title} onClose={onCancel}>
      <input
        autoFocus
        className="dwe-input"
        placeholder={placeholder}
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !busy) onConfirm(value);
          if (e.key === 'Escape') onCancel();
        }}
      />
      {error ? <div className="dwe-error">{error}</div> : null}
      <div className="dwe-modal-actions">
        <button type="button" className="dwe-btn" onClick={onCancel} disabled={busy}>
          取消
        </button>
        <button
          type="button"
          className="dwe-btn dwe-btn-primary"
          onClick={() => onConfirm(value)}
          disabled={busy}
        >
          {confirmLabel}
        </button>
      </div>
    </Modal>
  );
}

/** Menu anchor helper: convert a mouse event into fixed coordinates. */
export function anchorOf(e: React.MouseEvent): { x: number; y: number } {
  return { x: e.clientX, y: e.clientY };
}
