/**
 * Plugin stylesheet, injected as a <style data-plugin> tag by the client
 * apply. Uses the app's --dsw-* alias variables (with neutral fallbacks) so
 * the surfaces follow the active theme.
 */
export const CSS = `
.dwe-tabs {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.dwe-scroll {
  flex: 1;
  min-height: 0;
  overflow: auto;
  padding-bottom: 8px;
}

/* ── per-folder sub-tabs ─────────────────────────────────── */
.dwe-folder {
  display: flex;
  flex-direction: column;
  min-height: 0;
}

/* ── section header (built-in aligned: search / add / view) ── */
.dwe-section-header {
  box-sizing: border-box;
  height: 36px;
  color: var(--dsw-alias-label-tertiary, #8a8f98);
  border-radius: 12px;
  flex: none;
  justify-content: flex-end;
  align-items: center;
  gap: 4px;
  margin: 2px -4px 4px;
  padding-left: 4px;
  display: flex;
  overflow: hidden;
}

.dwe-section-label {
  white-space: nowrap;
  opacity: 1;
  visibility: visible;
  min-width: 0;
  max-width: 45%;
  transition: max-width 0.18s var(--ds-ease-in-out, ease),
    margin-right 0.18s var(--ds-ease-in-out, ease),
    opacity 0.12s var(--ds-ease-in-out, ease),
    transform 0.18s var(--ds-ease-in-out, ease), visibility 0s linear;
  flex: none;
  line-height: 20px;
  font-size: 13px;
  overflow: hidden;
}

.dwe-section-label[data-hidden='true'] {
  opacity: 0;
  visibility: hidden;
  max-width: 0;
  margin-right: -4px;
  transition-delay: 0s, 0s, 0s, 0s, 0.18s;
  transform: translate(-4px);
}

.dwe-iconbtn28 {
  cursor: pointer;
  width: 28px;
  height: 28px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  background: transparent;
  border: none;
  border-radius: 50%;
  flex: none;
  justify-content: center;
  align-items: center;
  padding: 0;
  display: inline-flex;
}

.dwe-iconbtn28:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128, 128, 128, 0.12));
}

.dwe-search-slot {
  box-sizing: border-box;
  min-width: 0;
  max-width: 28px;
  transition: max-width 0.18s var(--ds-ease-in-out, ease);
  flex: 1;
  align-items: center;
  margin-left: auto;
  padding-left: 0;
  display: flex;
}

.dwe-search-slot[data-open='true'] {
  max-width: 100%;
}

.dwe-search {
  box-sizing: border-box;
  cursor: text;
  width: 100%;
  height: 28px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  transition: width 0.18s var(--ds-ease-in-out, ease), padding 0.18s var(--ds-ease-in-out, ease),
    border-color 0.18s var(--ds-ease-in-out, ease), background-color 0.18s var(--ds-ease-in-out, ease);
  background: transparent;
  border: none;
  border-radius: 50%;
  flex: none;
  align-items: center;
  gap: 0;
  margin: 0;
  padding: 0;
  display: flex;
  overflow: hidden;
}

.dwe-search[data-open='true'] {
  border: 1px solid var(--dsw-alias-border-l2, rgba(128, 128, 128, 0.3));
  width: calc(100% + 4px);
  height: 30px;
  color: var(--dsw-alias-label-caption, #6a6f76);
  background: transparent;
  border-radius: 10px;
  margin-inline: -2px;
  padding: 0 4px 0 0;
}

.dwe-search-button {
  cursor: pointer;
  width: 28px;
  height: 28px;
  color: inherit;
  background: transparent;
  border: none;
  border-radius: 50%;
  flex: none;
  justify-content: center;
  align-items: center;
  padding: 0;
  display: inline-flex;
}

.dwe-search[data-open='true'] .dwe-search-button {
  width: 28px;
  height: 30px;
}

.dwe-search-button:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128, 128, 128, 0.12));
}

.dwe-search[data-open='true'] .dwe-search-button:hover {
  background: transparent;
}

.dwe-search-input {
  opacity: 0;
  pointer-events: none;
  width: 0;
  min-width: 0;
  color: var(--dsw-alias-label-primary, #e8eaed);
  transition: opacity 0.12s var(--ds-ease-in-out, ease);
  background: transparent;
  border: none;
  outline: none;
  flex: 1;
  font-size: 13px;
  line-height: 18px;
}

.dwe-search[data-open='true'] .dwe-search-input {
  opacity: 1;
  pointer-events: auto;
  margin-left: -2px;
}

.dwe-search-input::placeholder {
  color: var(--dsw-alias-label-tertiary, #8a8f98);
}

.dwe-clear-button {
  cursor: pointer;
  width: 24px;
  height: 24px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  background: transparent;
  border: none;
  border-radius: 50%;
  flex: none;
  justify-content: center;
  align-items: center;
  padding: 0;
  display: inline-flex;
  font-size: 12px;
}

.dwe-clear-button:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128, 128, 128, 0.12));
}

.dwe-header-actions {
  opacity: 1;
  visibility: visible;
  max-width: 76px;
  padding-right: 16px;
  transition: max-width 0.18s var(--ds-ease-in-out, ease), opacity 0.12s var(--ds-ease-in-out, ease),
    transform 0.18s var(--ds-ease-in-out, ease), visibility 0s linear, padding-right 0.18s var(--ds-ease-in-out, ease);
  flex: none;
  align-items: center;
  gap: 4px;
  display: flex;
  overflow: hidden;
}

.dwe-header-actions[data-hidden='true'] {
  opacity: 0;
  visibility: hidden;
  pointer-events: none;
  max-width: 0;
  padding-right: 0;
  transition-delay: 0s, 0s, 0s, 0.18s, 0s;
  transform: translate(4px);
}

/* ── rows (built-in aligned) ─────────────────────────────── */
.dwe-row.dwe-project-row,
.dwe-row.dwe-session-row {
  border-radius: 8px;
  align-items: center;
  gap: 6px;
  padding: 0 8px;
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-row.dwe-project-row {
  box-sizing: border-box;
  height: 34px;
}

.dwe-row.dwe-session-row {
  height: 32px;
  gap: 0;
  animation: dwe-row-in 0.15s var(--ds-ease-in-out, ease);
}

@keyframes dwe-row-in {
  0% {
    opacity: 0;
  }
}

.dwe-slot {
  width: 16px;
  height: 20px;
  color: var(--dsw-alias-label-tertiary, #8a8f98);
  flex: none;
  justify-content: center;
  align-items: center;
  display: inline-flex;
}

.dwe-dot-slot {
  flex: none;
}

/* done/idle sessions: gray dot (override the default green 'done' color) */
span.dwe-dot-slot[data-state='done'] {
  color: var(--dsw-alias-label-tertiary, #8a8f98);
}

/* current session: lit blue dot, same color as the folder row's active state */
span.dwe-dot-slot[data-state='done'].dwe-dot-current {
  color: var(--dsw-alias-state-business-primary, #4f8cff);
}

/* selected workspace folder: blue-tinted row + blue folder icon (mirrors
   the built-in browser's active-folder treatment, extended to the row) */
.dwe-row.dwe-project-row[data-active='true'] {
  background: rgba(79, 140, 255, 0.12);
  background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4f8cff) 12%, transparent);
}

.dwe-folder-slot[data-active='true'] {
  color: var(--dsw-alias-state-business-primary, #4f8cff);
}

.dwe-project-text {
  flex-direction: column;
  flex: 1;
  gap: 2px;
  min-width: 0;
  display: flex;
}

.dwe-title {
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  font-size: 14px;
  line-height: 20px;
  overflow: hidden;
}

.dwe-session-row .dwe-title {
  flex: 1;
  margin: 0 6px 0 4px;
  /* Match the sub-tab label size: text below the tabs is the same size as
     the tab text. */
  font-size: 12px;
}

.dwe-time {
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--dsw-alias-label-tertiary, #8a8f98);
  flex: none;
  font-size: 10px;
  line-height: 20px;
  overflow: hidden;
}

.dwe-row-actions {
  flex: none;
  align-items: center;
  gap: 12px;
  display: none;
}

.dwe-project-row:hover .dwe-row-actions,
.dwe-session-row:hover .dwe-row-actions,
.dwe-project-row[data-menu-open='true'] .dwe-row-actions,
.dwe-session-row[data-menu-open='true'] .dwe-row-actions {
  display: inline-flex;
}

.dwe-session-row:hover .dwe-time {
  display: none;
}

/* ── lists / search results ──────────────────────────────── */
.dwe-list {
  display: flex;
  flex-direction: column;
}

.dwe-flat-list > * + *,
.dwe-search-tree > * + *,
.dwe-group-section > * + * {
  margin-top: 2px;
}

.dwe-group-section {
  position: relative;
}

.dwe-group-section + .dwe-group-section {
  margin-top: 4px;
}

.dwe-folder-body {
  padding-left: 8px;
}

.dwe-empty {
  color: var(--dsw-alias-label-tertiary, #8a8f98);
  padding: 16px 12px;
  font-size: 10px;
}

.dwe-search-status {
  color: var(--dsw-alias-label-tertiary, #8a8f98);
  padding: 10px 12px;
  font-size: 12px;
  line-height: 18px;
}

.dwe-search-result-row {
  box-sizing: border-box;
  cursor: pointer;
  text-align: left;
  width: 100%;
  min-height: 48px;
  color: var(--dsw-alias-label-primary, #e8eaed);
  background: transparent;
  border: none;
  border-radius: 8px;
  flex-direction: column;
  align-items: stretch;
  padding: 4px 8px;
  display: flex;
}

.dwe-search-result-row:hover,
.dwe-search-result-row[data-current='true'] {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128, 128, 128, 0.12));
}

.dwe-search-result-heading {
  align-items: center;
  min-width: 0;
  display: flex;
}

.dwe-search-result-title {
  text-overflow: ellipsis;
  white-space: nowrap;
  min-width: 0;
  margin-left: 4px;
  font-size: 14px;
  line-height: 20px;
  overflow: hidden;
}

.dwe-search-result-meta {
  align-items: center;
  gap: 6px;
  min-width: 0;
  margin-left: 20px;
  display: flex;
}

.dwe-search-result-workspace,
.dwe-search-result-snippet {
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12px;
  line-height: 17px;
  overflow: hidden;
}

.dwe-search-result-workspace {
  max-width: 40%;
  color: var(--dsw-alias-label-tertiary, #8a8f98);
  flex: none;
}

.dwe-search-result-snippet {
  min-width: 0;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  flex: 1;
}

@media (prefers-reduced-motion: reduce) {
  .dwe-session-row,
  .dwe-chevron,
  .dwe-search,
  .dwe-search-slot,
  .dwe-search-input,
  .dwe-header-actions {
    transition: none;
    animation: none;
  }
}

/* folder icon + chevron in group headers (mirrors the built-in browser) */
.dwe-folder-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: 16px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
}

.dwe-folder-icon svg {
  display: block;
}

.dwe-folder-icon[data-active='true'] {
  color: var(--dsw-alias-brand-primary, #4f8cff);
}

.dwe-folder-arrow {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  width: 12px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  transition: transform 0.12s ease;
}

.dwe-folder-arrow svg {
  display: block;
}

.dwe-folder-arrow[data-open='true'] {
  transform: rotate(90deg);
}

.dwe-folder-tabs {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 2px 4px 0 10px;
  flex: none;
}

.dwe-folder-tabs .dwe-tab {
  font-size: 12px;
  padding: 5px 10px 7px;
}

.dwe-folder-git-hint {
  font-size: 10.5px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  padding-left: 4px;
}

.dwe-tabbar {
  display: flex;
  gap: 2px;
  padding: 6px 8px 0;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.22));
  flex: none;
}

.dwe-tab {
  appearance: none;
  background: transparent;
  border: none;
  border-bottom: 1px solid transparent;
  /* The active underline hangs 1px BELOW the tab box (overlapping the
     tabbar divider), giving the label room above the line. */
  margin-bottom: -1px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  font: inherit;
  font-size: 12px;
  line-height: 1;
  padding: 7px 12px 9px;
  border-radius: 6px 6px 0 0;
  cursor: pointer;
  user-select: none;
}

.dwe-tab:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12));
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-tab[data-active='true'] {
  color: var(--dsw-alias-label-primary, #e8eaed);
  border-bottom-color: var(--dsw-alias-brand-primary, #4f8cff);
  box-shadow: none;
}

.dwe-panel {
  flex: 1;
  min-height: 0;
  overflow: auto;
  padding: 8px;
  padding-left: 20px;
  display: flex;
  flex-direction: column;
  gap: 6px;
}

/* ── rail (collapsed sidebar) ─────────────────────────────── */
.dwe-rail {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 4px;
  padding: 8px 0;
}

.dwe-rail-button {
  appearance: none;
  background: transparent;
  border: none;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  width: 36px;
  height: 36px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 15px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.dwe-rail-button:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12));
  color: var(--dsw-alias-label-primary, #e8eaed);
}

/* ── generic rows ─────────────────────────────────────────── */
.dwe-row {
  display: flex;
  align-items: center;
  gap: 6px;
  border-radius: 6px;
  padding: 4px 6px;
  cursor: pointer;
  user-select: none;
  min-width: 0;
}

.dwe-row:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.10));
}

.dwe-row[data-current='true'] {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.16));
}

.dwe-row-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12px;
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-row-sub {
  font-size: 11px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  white-space: nowrap;
}

.dwe-row-path {
  font-size: 10.5px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.dwe-group-header {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 3px 4px;
  margin-top: 6px;
  cursor: pointer;
  user-select: none;
  border-radius: 6px;
}

.dwe-group-header:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.10));
}

.dwe-group-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-group-count {
  font-size: 10.5px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
}

/* ── icon buttons / menus ─────────────────────────────────── */
.dwe-iconbtn {
  appearance: none;
  background: transparent;
  border: none;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  width: 22px;
  height: 22px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 12px;
  line-height: 1;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
}

.dwe-iconbtn:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.18));
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-menu {
  position: fixed;
  z-index: 1000;
  min-width: 150px;
  padding: 4px;
  border-radius: 8px;
  background: var(--dsw-alias-bg-overlay, #23262b);
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.3));
  box-shadow: 0 8px 24px rgba(0,0,0,.35);
}

.dwe-menu-item {
  display: block;
  width: 100%;
  text-align: left;
  appearance: none;
  background: transparent;
  border: none;
  color: var(--dsw-alias-label-primary, #e8eaed);
  font: inherit;
  font-size: 12.5px;
  padding: 6px 10px;
  border-radius: 5px;
  cursor: pointer;
}

.dwe-menu-item:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.14));
}

.dwe-menu-item[data-danger='true'] {
  color: var(--dsw-alias-state-error-primary, #f87171);
}

.dwe-menu-item[data-danger='true']:hover {
  background: color-mix(in srgb, var(--dsw-alias-state-error-primary, #f87171) 16%, transparent);
}

/* ── modal ────────────────────────────────────────────────── */
.dwe-backdrop {
  position: fixed;
  inset: 0;
  z-index: 900;
  background: rgba(0,0,0,.45);
  display: flex;
  align-items: center;
  justify-content: center;
}

.dwe-modal {
  width: min(420px, 86vw);
  border-radius: 10px;
  background: var(--dsw-alias-bg-overlay, #23262b);
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.3));
  box-shadow: 0 16px 48px rgba(0,0,0,.4);
  padding: 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.dwe-modal-title {
  font-size: 13.5px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-modal-body {
  font-size: 12.5px;
  color: var(--dsw-alias-label-secondary, #b6bcc4);
  line-height: 1.5;
  overflow-wrap: anywhere;
}

.dwe-modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}

.dwe-btn {
  appearance: none;
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.3));
  background: transparent;
  color: var(--dsw-alias-label-primary, #e8eaed);
  font: inherit;
  font-size: 12.5px;
  padding: 5px 12px;
  border-radius: 6px;
  cursor: pointer;
}

.dwe-btn:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12));
}

.dwe-btn-primary {
  background: var(--dsw-alias-brand-primary, #4f8cff);
  border-color: transparent;
  color: #fff;
}

.dwe-btn-primary:hover {
  filter: brightness(1.1);
}

.dwe-btn-danger {
  background: var(--dsw-alias-state-error-primary, #f87171);
  border-color: transparent;
  color: #fff;
}

.dwe-btn-danger:hover {
  filter: brightness(1.1);
}

.dwe-input {
  width: 100%;
  box-sizing: border-box;
  appearance: none;
  background: var(--dsw-alias-bg-layer-1, #1c1e22);
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.3));
  color: var(--dsw-alias-label-primary, #e8eaed);
  font: inherit;
  font-size: 12.5px;
  padding: 6px 8px;
  border-radius: 6px;
}

.dwe-input:focus {
  outline: none;
  border-color: var(--dsw-alias-brand-primary, #4f8cff);
}

.dwe-toolbar {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: none;
}

.dwe-toolbar .dwe-input {
  flex: 1;
  min-width: 0;
}

.dwe-error {
  font-size: 12px;
  color: var(--dsw-alias-state-error-primary, #f87171);
  overflow-wrap: anywhere;
}

.dwe-hint {
  font-size: 12px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
}

.dwe-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid var(--dsw-alias-border-l2, rgba(128,128,128,.3));
  border-top-color: var(--dsw-alias-brand-primary, #4f8cff);
  border-radius: 50%;
  animation: dwe-spin .8s linear infinite;
  flex: none;
}

@keyframes dwe-spin {
  to { transform: rotate(360deg); }
}

/* ── status dots ──────────────────────────────────────────── */
.dwe-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  flex: none;
}

.dwe-dot-running { background: var(--dsw-alias-brand-primary, #4f8cff); }
.dwe-dot-done { background: var(--dsw-alias-state-success-primary, #34d399); }
.dwe-dot-pending { background: var(--dsw-alias-state-warn-primary, #fbbf24); }

/* ── file tree ────────────────────────────────────────────── */
.dwe-tree {
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.dwe-tree-row {
  display: flex;
  align-items: center;
  gap: 4px;
  border-radius: 5px;
  padding: 2px 4px;
  cursor: pointer;
  user-select: none;
  min-width: 0;
  white-space: nowrap;
}

.dwe-tree-row:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.10));
}

.dwe-tree-row[data-dir='true'] .dwe-tree-label {
  font-weight: 500;
}

.dwe-tree-label {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size: 12px;
  color: var(--dsw-alias-label-primary, #e8eaed);
}

/* Colored file/folder icon slot (16px inline SVG) */
.dwe-tree-icon {
  flex: none;
  display: block;
  margin: 0 1px;
  vertical-align: middle;
}

.dwe-tree-meta {
  font-size: 10.5px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
}

/* ── git ──────────────────────────────────────────────────── */
.dwe-git-views {
  display: inline-flex;
  gap: 2px;
  padding: 2px;
  border-radius: 8px;
  background: var(--dsw-alias-interactive-bg-hover, rgba(128, 128, 128, 0.12));
  flex: none;
}

.dwe-git-view {
  appearance: none;
  background: transparent;
  border: none;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  font: inherit;
  font-size: 12px;
  line-height: 1;
  padding: 5px 12px;
  border-radius: 6px;
  cursor: pointer;
}

.dwe-git-view:hover {
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-git-view[data-active='true'] {
  background: var(--dsw-alias-bg-overlay, #23262b);
  color: var(--dsw-alias-label-primary, #e8eaed);
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.25);
}

/* Branch selector row inside the Graph view (left-aligned, 12px like tabs) */
.dwe-git-branchbar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 8px 2px;
  flex: none;
}

.dwe-select {
  appearance: none;
  background: var(--dsw-alias-bg-layer-1, #1c1e22);
  color: var(--dsw-alias-label-primary, #e8eaed);
  border: 1px solid var(--dsw-alias-border-l1, rgba(128, 128, 128, 0.22));
  border-radius: 6px;
  font-size: 12px;
  line-height: 1;
  padding: 4px 8px;
  max-width: 200px;
  cursor: pointer;
}

.dwe-select:hover {
  border-color: var(--dsw-alias-brand-primary, #4f8cff);
}

.dwe-git-graph {
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  color: var(--dsw-alias-label-tertiary, #8a8f98);
  white-space: pre;
  margin-right: 6px;
}

.dwe-git-file[data-clickable='true'] {
  cursor: pointer;
}

.dwe-git-commit {
  display: flex;
  flex-direction: column;
  gap: 2px;
  border-radius: 6px;
  padding: 6px 8px;
  cursor: pointer;
  border: 1px solid transparent;
}

.dwe-git-commit:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.10));
}

.dwe-git-commit[data-active='true'] {
  border-color: var(--dsw-alias-brand-primary, #4f8cff);
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.12));
}

.dwe-git-subject {
  font-size: 12px;
  color: var(--dsw-alias-label-primary, #e8eaed);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.dwe-git-meta-line {
  font-size: 11px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.dwe-git-detail {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.dwe-git-files {
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.dwe-git-file {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  padding: 2px 4px;
  border-radius: 4px;
}

.dwe-git-file:hover {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,.10));
}

.dwe-git-status {
  font-size: 10px;
  font-weight: 700;
  width: 20px;
  flex: none;
  text-align: center;
}

.dwe-git-file path {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-git-patch {
  margin: 0;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 11px;
  line-height: 1.5;
  color: var(--dsw-alias-label-primary, #e8eaed);
  background: var(--dsw-alias-markdown-code-block, #fafbfc);
  border: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.18));
  border-radius: 6px;
  padding: 8px;
  overflow: auto;
  white-space: pre;
  max-height: 60vh;
}

/* ── preview overlay ──────────────────────────────────────── */
.dwe-preview {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  width: min(48vw, 680px);
  z-index: 500;
  display: flex;
  flex-direction: column;
  background: var(--dsw-alias-bg-overlay, #23262b);
  border-left: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,.3));
  box-shadow: -12px 0 32px rgba(0,0,0,.25);
}

.dwe-preview-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(128,128,128,.2));
  flex: none;
}

.dwe-preview-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 12.5px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-preview-path {
  font-size: 10.5px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 60%;
}

.dwe-preview-body {
  flex: 1;
  min-height: 0;
  overflow: auto;
  display: flex;
  flex-direction: column;
}

.dwe-preview-code {
  margin: 0;
  padding: 10px 12px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
  line-height: 1.55;
  color: var(--dsw-alias-label-primary, #e8eaed);
  white-space: pre;
  tab-size: 2;
  /* Code surface: follow the host's code-block background (light #f9fafb /
     dark #1b1b1c) so preview code matches in-app markdown code blocks; used
     to be transparent, which showed the panel's gray overlay color through. */
  position: relative; /* line-numbers gutter anchor */
  background: var(--dsw-alias-markdown-code-block, #fafbfc);
  border-radius: 8px;
}

.dwe-preview-code code {
  font-family: inherit;
}

/* ── markdown preview: 预览/源码 tabs + rendered typography ── */
.dwe-preview-tabs {
  display: flex;
  gap: 2px;
  padding: 2px 4px 0 6px;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(128, 128, 128, 0.22));
  flex: none;
}

.dwe-preview-tab {
  appearance: none;
  background: transparent;
  border: none;
  border-bottom: 2px solid transparent;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  font: inherit;
  font-size: 12px;
  line-height: 1;
  padding: 6px 10px 8px;
  cursor: pointer;
  user-select: none;
}

.dwe-preview-tab:hover {
  color: var(--dsw-alias-label-primary, #e8eaed);
}

.dwe-preview-tab[data-active='true'] {
  color: var(--dsw-alias-label-primary, #e8eaed);
  border-bottom-color: var(--dsw-alias-brand-primary, #4f8cff);
}

.dwe-preview-md {
  padding: 10px 14px;
  font-size: 13px;
  line-height: 1.65;
  color: var(--dsw-alias-label-primary, #e8eaed);
  overflow-wrap: break-word;
}

.dwe-preview-md h1,
.dwe-preview-md h2,
.dwe-preview-md h3,
.dwe-preview-md h4,
.dwe-preview-md h5,
.dwe-preview-md h6 {
  margin: 14px 0 6px;
  line-height: 1.3;
}

.dwe-preview-md h1 {
  font-size: 20px;
}

.dwe-preview-md h2 {
  font-size: 17px;
}

.dwe-preview-md h3 {
  font-size: 15px;
}

.dwe-preview-md p {
  margin: 6px 0;
}

.dwe-preview-md code {
  background: rgba(128, 128, 128, 0.14);
  border-radius: 4px;
  padding: 1px 5px;
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 12px;
}

.dwe-preview-md pre {
  background: var(--dsw-alias-markdown-code-block, #fafbfc);
  border-radius: 8px;
  padding: 8px 10px;
  overflow: auto;
}

.dwe-preview-md pre code {
  background: none;
  padding: 0;
  font-size: 12px;
  line-height: 1.55;
}

.dwe-preview-md a {
  color: var(--dsw-alias-state-business-primary, #4f8cff);
}

.dwe-preview-md blockquote {
  margin: 6px 0;
  padding: 2px 10px;
  border-left: 3px solid var(--dsw-alias-border-l1, rgba(128, 128, 128, 0.22));
  color: var(--dsw-alias-label-secondary, #8a8f98);
}

.dwe-preview-md ul,
.dwe-preview-md ol {
  margin: 6px 0;
  padding-left: 22px;
}

.dwe-preview-md table {
  border-collapse: collapse;
  margin: 8px 0;
}

.dwe-preview-md th,
.dwe-preview-md td {
  border: 1px solid var(--dsw-alias-border-l1, rgba(128, 128, 128, 0.22));
  padding: 4px 8px;
}

.dwe-preview-md th {
  background: rgba(128, 128, 128, 0.1);
}

.dwe-preview-md img {
  max-width: 100%;
  border-radius: 6px;
}

.dwe-preview-md hr {
  border: none;
  border-top: 1px solid var(--dsw-alias-border-l1, rgba(128, 128, 128, 0.22));
  margin: 10px 0;
}

.dwe-preview-image {
  padding: 12px;
  display: flex;
  align-items: flex-start;
  justify-content: center;
}

.dwe-preview-image img {
  max-width: 100%;
  max-height: 70vh;
  object-fit: contain;
  border-radius: 6px;
}

.dwe-preview-message {
  padding: 24px 16px;
  font-size: 12.5px;
  color: var(--dsw-alias-label-secondary, #8a8f98);
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
}

/* ── Prism.js code view: surfaces + palette follow the app theme ── */
/* Wrapper for the injected <pre>: pads the code "card" inside the body. */
.dwe-preview-code-wrap {
  flex: 1;
  min-height: 0;
  padding: 10px 12px 12px;
}

.dwe-preview-code.line-numbers {
  padding-left: calc(12px + 3.2em);
  counter-reset: linenumber;
}

.dwe-preview-code.line-numbers > code {
  position: relative;
  display: block;
  white-space: inherit;
}

.dwe-preview-code .line-numbers-rows {
  position: absolute;
  top: 10px; /* pre top padding */
  bottom: 10px; /* pre bottom padding */
  left: 0;
  width: 3.2em;
  overflow: hidden;
  text-align: right;
  color: var(--dsw-alias-label-tertiary, #8a8f98);
  border-right: 1px solid var(--dsw-alias-border-l1, rgba(128, 128, 128, 0.22));
  user-select: none;
  pointer-events: none;
  font-variant-numeric: tabular-nums;
}

.dwe-preview-code .line-numbers-rows > span {
  display: block;
  counter-increment: linenumber;
}

.dwe-preview-code .line-numbers-rows > span::before {
  content: counter(linenumber);
  display: block;
  padding-right: 0.8em;
}

/* Token palette — follows the active DSH skin (light = default body, dark =
   body[data-ds-dark-theme]), GitHub-Light / GitHub-Dark flavors. Colors are
   CSS variables set once per theme below; the .token.* rules that follow
   stay theme-neutral. Scoped to every surface that renders Prism output —
   the host's own shiki markdown also uses .token classes, so never style
   .token unscoped. */
.dwe-preview-code,
.dwe-preview-md,
.dwe-git-patch {
  --dwe-tok-comment: #6a737d;
  --dwe-tok-punct: #6a737d;
  --dwe-tok-prop: #d73a49;
  --dwe-tok-number: #005cc5;
  --dwe-tok-string: #032f62;
  --dwe-tok-operator: #005cc5;
  --dwe-tok-keyword: #d73a49;
  --dwe-tok-func: #6f42c1;
  --dwe-tok-var: #e36209;
}

body[data-ds-dark-theme] .dwe-preview-code,
body[data-ds-dark-theme] .dwe-preview-md,
body[data-ds-dark-theme] .dwe-git-patch {
  --dwe-tok-comment: #7d8799;
  --dwe-tok-punct: #9aa4b2;
  --dwe-tok-prop: #f97583;
  --dwe-tok-number: #f0883e;
  --dwe-tok-string: #96d0ff;
  --dwe-tok-operator: #79b8ff;
  --dwe-tok-keyword: #ff7b72;
  --dwe-tok-func: #d2a8ff;
  --dwe-tok-var: #ffab70;
}

.dwe-preview-code .token.comment,
.dwe-preview-code .token.prolog,
.dwe-preview-code .token.doctype,
.dwe-preview-code .token.cdata,
.dwe-preview-md .token.comment,
.dwe-preview-md .token.prolog,
.dwe-preview-md .token.doctype,
.dwe-preview-md .token.cdata,
.dwe-git-patch .token.comment,
.dwe-git-patch .token.prolog,
.dwe-git-patch .token.doctype,
.dwe-git-patch .token.cdata {
  color: var(--dwe-tok-comment);
  font-style: italic;
}

.dwe-preview-code .token.punctuation,
.dwe-preview-md .token.punctuation,
.dwe-git-patch .token.punctuation {
  color: var(--dwe-tok-punct);
}

.dwe-preview-code .token.property,
.dwe-preview-code .token.tag,
.dwe-preview-code .token.constant,
.dwe-preview-code .token.symbol,
.dwe-preview-code .token.deleted,
.dwe-preview-md .token.property,
.dwe-preview-md .token.tag,
.dwe-preview-md .token.constant,
.dwe-preview-md .token.symbol,
.dwe-preview-md .token.deleted,
.dwe-git-patch .token.property,
.dwe-git-patch .token.tag,
.dwe-git-patch .token.constant,
.dwe-git-patch .token.symbol,
.dwe-git-patch .token.deleted {
  color: var(--dwe-tok-prop);
}

.dwe-preview-code .token.boolean,
.dwe-preview-code .token.number,
.dwe-preview-md .token.boolean,
.dwe-preview-md .token.number,
.dwe-git-patch .token.boolean,
.dwe-git-patch .token.number {
  color: var(--dwe-tok-number);
}

.dwe-preview-code .token.selector,
.dwe-preview-code .token.attr-name,
.dwe-preview-code .token.string,
.dwe-preview-code .token.char,
.dwe-preview-code .token.builtin,
.dwe-preview-code .token.inserted,
.dwe-preview-md .token.selector,
.dwe-preview-md .token.attr-name,
.dwe-preview-md .token.string,
.dwe-preview-md .token.char,
.dwe-preview-md .token.builtin,
.dwe-preview-md .token.inserted,
.dwe-git-patch .token.selector,
.dwe-git-patch .token.attr-name,
.dwe-git-patch .token.string,
.dwe-git-patch .token.char,
.dwe-git-patch .token.builtin,
.dwe-git-patch .token.inserted {
  color: var(--dwe-tok-string);
}

.dwe-preview-code .token.operator,
.dwe-preview-code .token.entity,
.dwe-preview-code .token.url,
.dwe-preview-code .language-css .token.string,
.dwe-preview-code .style .token.string,
.dwe-preview-md .token.operator,
.dwe-preview-md .token.entity,
.dwe-preview-md .token.url,
.dwe-preview-md .language-css .token.string,
.dwe-preview-md .style .token.string,
.dwe-git-patch .token.operator,
.dwe-git-patch .token.entity,
.dwe-git-patch .token.url,
.dwe-git-patch .language-css .token.string,
.dwe-git-patch .style .token.string {
  color: var(--dwe-tok-operator);
}

.dwe-preview-code .token.atrule,
.dwe-preview-code .token.attr-value,
.dwe-preview-code .token.keyword,
.dwe-preview-md .token.atrule,
.dwe-preview-md .token.attr-value,
.dwe-preview-md .token.keyword,
.dwe-git-patch .token.atrule,
.dwe-git-patch .token.attr-value,
.dwe-git-patch .token.keyword {
  color: var(--dwe-tok-keyword);
}

.dwe-preview-code .token.function,
.dwe-preview-code .token.class-name,
.dwe-preview-md .token.function,
.dwe-preview-md .token.class-name,
.dwe-git-patch .token.function,
.dwe-git-patch .token.class-name {
  color: var(--dwe-tok-func);
}

.dwe-preview-code .token.regex,
.dwe-preview-code .token.important,
.dwe-preview-code .token.variable,
.dwe-preview-md .token.regex,
.dwe-preview-md .token.important,
.dwe-preview-md .token.variable,
.dwe-git-patch .token.regex,
.dwe-git-patch .token.important,
.dwe-git-patch .token.variable {
  color: var(--dwe-tok-var);
}

.dwe-preview-code .token.important,
.dwe-preview-code .token.bold,
.dwe-preview-md .token.important,
.dwe-preview-md .token.bold,
.dwe-git-patch .token.important,
.dwe-git-patch .token.bold {
  font-weight: 600;
}

.dwe-preview-code .token.italic,
.dwe-preview-md .token.italic,
.dwe-git-patch .token.italic {
  font-style: italic;
}

.dwe-sep {
  height: 1px;
  background: var(--dsw-alias-border-l1, rgba(128,128,128,.18));
  margin: 4px 0;
  flex: none;
}
`;
