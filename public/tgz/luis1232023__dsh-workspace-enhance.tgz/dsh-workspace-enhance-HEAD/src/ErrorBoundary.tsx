/**
 * Inline error boundary: a panel crash renders the error message inside the
 * sidebar instead of letting the whole slot entry abdicate (which would
 * silently swap the region back to the built-in browser).
 */
import { Component } from 'react';
import type { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  onError?: (error: unknown) => void;
}

interface State {
  error: Error | null;
}

export class PanelErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: unknown): State {
    return { error: error instanceof Error ? error : new Error(String(error)) };
  }

  componentDidCatch(error: unknown) {
    console.error('[dsh-workspace-enhance] panel crashed:', error);
    this.props.onError?.(error);
  }

  render() {
    if (this.state.error) {
      return (
        <div className="dwe-panel">
          <div className="dwe-error">
            面板渲染出错：{this.state.error.message}
          </div>
          <div className="dwe-hint" style={{ overflowWrap: 'anywhere' }}>
            {this.state.error.stack}
          </div>
          <button
            type="button"
            className="dwe-btn"
            onClick={() => this.setState({ error: null })}
          >
            重试
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}
