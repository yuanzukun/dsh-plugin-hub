/**
 * Build the browser half (lib/client.js) in the DSH web2 ModuleLoader format.
 *
 * The web shell mounts a client module loader (window.__ModuleLoader__) whose
 * `load({ id, factory })` registers one plugin bundle; the factory receives a
 * synchronous `require` that resolves peer specifiers (react, @deepseek-ai/*)
 * through the shell's module table. Every dsh-client-* package ships exactly
 * this shape, so we emit it here.
 *
 * The esbuild native binary is spawned directly with stdio: 'inherit' (the
 * JS API spawns its service with piped stdio, which the file sandbox denies).
 *
 * `npm run watch` rebuilds are picked up by the dsh-client-hmr node half
 * (it stat-polls boot-graph bundles), giving no-refresh hot reload of the
 * browser half while the web profile runs.
 */

import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const watch = process.argv.includes('--watch');

// Locate the esbuild native binary (installed via @esbuild/win32-x64).
const candidates = [
  path.join(here, 'node_modules', '@esbuild', 'win32-x64', 'esbuild.exe'),
  path.join(here, 'node_modules', 'esbuild', 'bin', 'esbuild.exe'),
];
const bin = candidates.find((c) => existsSync(c));
if (!bin) {
  console.error('[dsh-workspace-enhance] esbuild binary not found; run `npm install --ignore-scripts` first.');
  process.exit(1);
}

const banner = `window.__ModuleLoader__.load({\n  id: "dsh-workspace-enhance",\n  factory: (require) => {\n    var module = { exports: {} };\n    var exports = module.exports;\n    Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });\n`;

const footer = `\n    return module.exports;\n  }\n});\n`;

const args = [
  'src/client.tsx',
  '--bundle',
  '--outfile=lib/client.js',
  '--format=cjs',
  '--platform=browser',
  '--target=es2020',
  '--jsx=automatic',
  '--sourcemap=linked',
  '--log-level=info',
  '--external:react',
  '--external:react/jsx-runtime',
  '--external:react/jsx-dev-runtime',
  '--external:react-dom',
  '--external:@deepseek-ai/*',
  `--banner:js=${banner}`,
  `--footer:js=${footer}`,
];
if (watch) args.push('--watch');

const child = spawn(bin, args, {
  cwd: here,
  stdio: 'inherit',
  windowsHide: true,
});

// Keep the profile's installed copy (pnpm `file:` deps are packed copies, not
// links) in sync so the running host serves the fresh bundle. Sync only the
// built artifacts the host resolves.
const profileCopy = 'C:/Users/yicheng/.dsh/profiles/web/node_modules/dsh-workspace-enhance/lib';

child.on('exit', async (code) => {
  if (code === 0) {
    try {
      const { copyFileSync, existsSync } = await import('node:fs');
      if (existsSync(profileCopy)) {
        for (const f of ['client.js', 'client.js.map', 'index.js']) {
          copyFileSync(path.join(here, 'lib', f), path.join(profileCopy, f));
        }
        console.log(`[dsh-workspace-enhance] synced lib/* into ${profileCopy}`);
      }
    } catch (e) {
      console.warn('[dsh-workspace-enhance] profile sync skipped:', e.message);
    }
  }
  process.exit(code ?? 1);
});
