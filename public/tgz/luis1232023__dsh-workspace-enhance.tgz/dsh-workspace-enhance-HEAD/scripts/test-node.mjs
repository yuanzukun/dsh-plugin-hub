/**
 * Standalone integration test for the node half: captures the RPC handler
 * registered by apply() and exercises every endpoint against a scratch
 * directory (real files + a real git repo + a fake session dir).
 *
 * Run: node scripts/test-node.mjs
 */
import { apply } from '../lib/index.js';
import { execFileSync } from 'node:child_process';
import * as fsp from 'node:fs/promises';
import * as path from 'node:path';
import os from 'node:os';

let handler = null;
const fakeCtx = {
  connection: {
    rpc: {
      handle: (_channel, fn, _opts) => {
        handler = fn;
        return async () => {};
      },
    },
  },
  effect: (fn) => {
    const it = fn();
    if (it && typeof it.next === 'function') {
      let res = it.next();
      while (!res.done) res = it.next();
    }
  },
};
apply(fakeCtx);

if (!handler) {
  console.error('FAIL: handler not registered');
  process.exit(1);
}

const root = path.join(os.tmpdir(), 'dwe-test-' + Date.now());
const repo = path.join(root, 'repo');
const git = (args, cwd = repo) => execFileSync('git', args, { cwd, encoding: 'utf8' });

let failures = 0;
const check = (name, cond, extra) => {
  if (cond) console.log(`  ok  ${name}`);
  else {
    failures += 1;
    console.error(`FAIL  ${name}${extra ? ` — ${extra}` : ''}`);
  }
};

const call = async (endpoint, payload) => {
  const res = await handler(endpoint, payload, new AbortController().signal);
  if (!res.ok) throw new Error(res.error.message);
  return res.value;
};

await fsp.mkdir(repo, { recursive: true });
git(['init', '-b', 'main']);
await fsp.writeFile(path.join(repo, 'a.js'), 'console.log(1)\n', 'utf8');
await fsp.writeFile(path.join(repo, 'notes.md'), '# hi\n', 'utf8');
git(['add', '-A']);
git(['-c', 'user.email=t@t', '-c', 'user.name=t', 'commit', '-m', 'first']);
await fsp.writeFile(path.join(repo, 'a.js'), 'console.log(2)\n// more\n', 'utf8');
git(['add', '-A']);
git(['-c', 'user.email=t@t', '-c', 'user.name=t', 'commit', '-m', 'second']);

// fs/root
const r = await call('fs/root', {});
check('fs/root home', typeof r.home === 'string' && r.home.length > 0);

// fs/list
const listing = await call('fs/list', { path: repo });
check('fs/list entries', listing.entries.some((e) => e.name === 'a.js'));
const dir = listing.entries.find((e) => e.name === 'a.js');
check('fs/list file size > 0', dir && dir.size > 0);

// fs/read text
const text = await call('fs/read', { path: path.join(repo, 'a.js') });
check('fs/read text', text.kind === 'text' && text.content.includes('console.log'));
check('fs/read language', text.language === 'javascript');
const md = await call('fs/read', { path: path.join(repo, 'notes.md') });
check('fs/read markdown language', md.kind === 'text' && md.language === 'markdown');

// git/status (clean after commit)
const st = await call('git/status', { path: repo });
check('git/status clean', st.isRepo && st.entries.length === 0 && st.branch === 'main', JSON.stringify(st));

// fs/read binary (write a small PNG header — untracked, so do this after the clean check)
const binPath = path.join(repo, 'img.png');
await fsp.writeFile(binPath, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 1, 2, 3]));
const bin = await call('fs/read', { path: binPath });
check('fs/read image dataUrl', bin.kind === 'image' && bin.dataUrl.startsWith('data:image/png;base64,'));

// git/log
const log = await call('git/log', { path: repo, count: 10 });
check('git/log isRepo', log.isRepo === true);
check('git/log commits', log.commits.length === 2);
check('git/log refs on head', log.commits[0].refs.includes('HEAD'));
check('git/log field order', log.commits[0].subject === 'second' && log.commits[1].subject === 'first');

// git/log with graph — regression: `--graph` must be a git-log option (after
// the subcommand), not a global one (`git --graph log ...` fails with
// "unknown option: --graph").
const logGraph = await call('git/log', { path: repo, count: 10, graph: true });
check('git/log graph isRepo', logGraph.isRepo === true);
check(
  'git/log graph commits',
  logGraph.commits.length === 2 && /^[0-9a-f]{40}$/.test(logGraph.commits[0].hash),
  JSON.stringify(logGraph),
);
check('git/log graph subjects', logGraph.commits[0].subject === 'second' && logGraph.commits[1].subject === 'first');

// git/status dirty
await fsp.writeFile(path.join(repo, 'a.js'), 'dirty\n', 'utf8');
const st2 = await call('git/status', { path: repo });
check('git/status dirty', st2.entries.some((e) => e.path === ' a.js' || e.path === 'a.js'));

// git/show
const show = await call('git/show', { path: repo, hash: log.commits[0].hash });
check('git/show meta', show.isRepo && show.meta && show.meta.subject === 'second');
check('git/show files', show.files.length === 1 && show.files[0].status === 'M');
check('git/show patch', show.patch.includes('console.log'));

// git/branches + branch-filtered git/log
const branches = await call('git/branches', { path: repo });
check('git/branches list', branches.isRepo && branches.branches.includes('main'), JSON.stringify(branches));
check('git/branches current', branches.current === 'main', JSON.stringify(branches));
git(['checkout', '-b', 'feature']);
await fsp.writeFile(path.join(repo, 'feature.txt'), 'f\n', 'utf8');
git(['add', '-A']);
git(['-c', 'user.email=t@t', '-c', 'user.name=t', 'commit', '-m', 'feature commit']);
const logMainOnly = await call('git/log', { path: repo, count: 10, branch: 'main' });
check(
  'git/log branch main filters',
  logMainOnly.isRepo && logMainOnly.commits.length === 2,
  JSON.stringify(logMainOnly.commits.map((c) => c.subject)),
);
const logFeat = await call('git/log', { path: repo, count: 10, graph: true, branch: 'feature' });
check(
  'git/log branch feature graph',
  logFeat.isRepo && logFeat.commits.length === 3,
  JSON.stringify(logFeat.commits.map((c) => c.subject)),
);
const br2 = await call('git/branches', { path: repo });
check(
  'git/branches current after checkout',
  br2.branches.length === 2 && br2.current === 'feature',
  JSON.stringify(br2),
);

// git/log on non-repo
const notRepo = await call('git/log', { path: os.tmpdir() });
check('git/log non-repo isRepo=false', notRepo.isRepo === false && typeof notRepo.error === 'string');

// session/delete: fake session dir under a fake DSH_HOME
const fakeHome = path.join(root, 'fake-dsh');
const scope = path.join(fakeHome, 'sessions', '--D-test--');
const sessionDir = path.join(scope, 'session-deadbeef-0000-0000-0000-000000000000');
await fsp.mkdir(sessionDir, { recursive: true });
await fsp.writeFile(path.join(sessionDir, 'session.jsonl'), 'x\n', 'utf8');
const oldHome = process.env.DSH_HOME;
process.env.DSH_HOME = fakeHome;
const del = await call('session/delete', { sessionId: 'session-deadbeef-0000-0000-0000-000000000000' });
process.env.DSH_HOME = oldHome;
check('session/delete removed', del.deleted === true && del.removedDirs.length === 1);
const gone = await fsp.stat(sessionDir).then(() => false, () => true);
check('session/delete dir gone', gone === true);
const del2 = await call('session/delete', { sessionId: 'session-deadbeef-0000-0000-0000-000000000000' });
check('session/delete second = not found', del2.deleted === false);
// session/delete: invalid ids are rejected (error result, not deletion)
const bad = await handler('session/delete', { sessionId: '../../evil' }, new AbortController().signal);
check('session/delete rejects traversal', bad.ok === false);

// unknown endpoint
const unk = await handler('nope', {}, new AbortController().signal);
check('unknown endpoint error', unk.ok === false);

await fsp.rm(root, { recursive: true, force: true });

if (failures === 0) {
  console.log('\nALL NODE HALF TESTS PASSED');
} else {
  console.error(`\n${failures} FAILURES`);
  process.exit(1);
}
