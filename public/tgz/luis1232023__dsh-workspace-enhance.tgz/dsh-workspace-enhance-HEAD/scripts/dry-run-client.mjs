/**
 * Dry-run of the built browser bundle in a Node VM: stubs the web shell
 * (window.__ModuleLoader__ + the loader `require` table) and a minimal
 * client ctx, then materializes lib/client.js and runs its apply().
 *
 * Verifies, without a browser/server:
 *   - the bundle registers via window.__ModuleLoader__.load with our id
 *   - the factory materializes (prism.js registration, externals resolve)
 *   - exports { name, inject, apply } match the loader's expectations — taken
 *     from the factory return value, exactly as the shell consumes it
 *   - apply() injects style and registers both slot contributions with the
 *     right priority / list id / store / inject face
 *
 * Run: node scripts/dry-run-client.mjs
 */
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const bundlePath = path.join(here, '..', 'lib', 'client.js');
const code = readFileSync(bundlePath, 'utf8');

let registered = null;
const registrations = [];

// ── shell stubs ───────────────────────────────────────────────────────────
const fakeWindow = {
  __ModuleLoader__: {
    load: (spec) => {
      if (registered) throw new Error('duplicate load');
      registered = spec;
    },
  },
  // apply() attaches error listeners on the real window.
  addEventListener: () => {},
  removeEventListener: () => {},
};
globalThis.window = fakeWindow;

const requireStub = (specifier) => {
  if (specifier === 'react') {
    return { createElement: () => null, Fragment: Symbol('Fragment'), Component: class {} };
  }
  if (specifier === 'react/jsx-runtime') return { jsx: () => null, jsxs: () => null, Fragment: Symbol('Fragment') };
  if (specifier === '@deepseek-ai/dsh-client-runtime/client') {
    return {
      defineStore: (spec) => ({ spec }),
      // types only — nothing else is used at runtime
    };
  }
  if (specifier === '@deepseek-ai/dsh-client-ui-primitives') {
    // Components/icons are only dereferenced at render time; a no-op proxy
    // lets the module evaluate and apply() register the slots without a DOM.
    return new Proxy({}, { get: () => () => {} });
  }
  throw new Error(`unexpected external require: ${specifier}`);
};

// ── document stub (only ensureStyle touches it) ───────────────────────────
const styleTags = [];
const fakeDocument = {
  // Models the real DOM: ensureStyle() skips injection once the tag exists,
  // which is what the idempotency check below asserts.
  querySelector: (sel) =>
    sel === 'style[data-plugin-css="dsh-workspace-enhance-css"]' ? styleTags[0] ?? null : null,
  createElement: (tag) => ({
    tagName: tag,
    attrs: {},
    textContent: '',
    setAttribute(k, v) {
      this.attrs[k] = v;
    },
  }),
  head: {
    appendChild: (el) => {
      styleTags.push(el);
    },
  },
};
globalThis.document = fakeDocument;

// ── client ctx stub ───────────────────────────────────────────────────────
const captured = { sidebar: null, overlay: null };
const fakeCtx = {
  effect: (fn) => {
    const it = fn();
    if (it && typeof it.next === 'function') {
      let r = it.next();
      while (!r.done) r = it.next();
    }
  },
  slots: {
    inject: (key, cb) => {
      captured[key === 'sidebar.workspaces' ? 'sidebar' : 'overlay'] = cb;
      return () => {};
    },
    register: (options, component) => {
      registrations.push({ options, componentName: component?.name ?? 'anonymous' });
      return () => {};
    },
    onEntryError: () => {},
  },
  sessions: {},
  workspaces: {},
  connection: {},
};

// ── execute the bundle the way the shell does ─────────────────────────────
// The bundle body only registers itself via window.__ModuleLoader__.load(...);
// exports are assigned inside the factory closure and returned from it. The
// shell calls factory(require) and consumes the return value, so we run the
// bundle once to capture the spec, then materialize the module via the factory.
const runBundle = new Function('require', 'module', 'exports', 'window', 'document', code);
const moduleObj = { exports: {} };
runBundle(requireStub, moduleObj, moduleObj.exports, fakeWindow, fakeDocument);
const exports_ = registered?.factory ? registered.factory(requireStub) : moduleObj.exports;

let failures = 0;
const check = (name, cond, extra) => {
  if (cond) console.log(`  ok  ${name}`);
  else {
    failures += 1;
    console.error(`FAIL  ${name}${extra ? ` — ${extra}` : ''}`);
  }
};

check('bundle called __ModuleLoader__.load once', registered !== null);
check('bundle id', registered?.id === 'dsh-workspace-enhance', String(registered?.id));
check('bundle factory is a function', typeof registered?.factory === 'function');
check('exports.name', exports_.name === 'dsh-workspace-enhance', String(exports_.name));
check(
  'exports.inject',
  Array.isArray(exports_.inject) && exports_.inject.includes('slots') && exports_.inject.includes('connection'),
  JSON.stringify(exports_.inject),
);
check('exports.apply', typeof exports_.apply === 'function');

// Run the factory the way the loader would, then apply().
exports_.apply(fakeCtx);

check('style tag injected with data-plugin', styleTags.length === 1 && styleTags[0].attrs['data-plugin'] === 'dsh-workspace-enhance');

check('sidebar inject registered', typeof captured.sidebar === 'function');
check('overlay inject registered', typeof captured.overlay === 'function');

if (captured.sidebar) {
  captured.sidebar();
  const reg = registrations[0];
  check('sidebar registration priority -1', reg?.options?.priority === -1, String(reg?.options?.priority));
  check('sidebar registration name', reg?.options?.name === 'sidebar.workspaces');
  check('sidebar component', reg?.componentName === 'WorkspaceRegion', String(reg?.componentName));
  check('sidebar store declared', reg?.options?.store != null);
  if (reg?.options?.inject) {
    const face = reg.options.inject({
      openPreview: () => {},
      setPreview: () => {},
      closePreview: () => {},
    });
    check('sidebar inject face has api', typeof face?.api?.fsRead === 'function');
    check('sidebar inject face has openSession', typeof face?.openSession === 'function');
    check('sidebar inject face has openFile', typeof face?.openFile === 'function');
    check('sidebar inject face has refreshSessions', typeof face?.refreshSessions === 'function');
  }
}

if (captured.overlay) {
  captured.overlay();
  const reg = registrations[1];
  check('overlay registration list id', reg?.options?.id === 'dsh-workspace-enhance.preview', String(reg?.options?.id));
  check('overlay registration name', reg?.options?.name === 'shell.overlay');
  check('overlay component', reg?.componentName === 'FilePreviewOverlay', String(reg?.componentName));
}

// Style injection is idempotent.
exports_.apply(fakeCtx);
check('style injected once', styleTags.length === 1, `tags=${styleTags.length}`);

if (failures === 0) {
  console.log('\nCLIENT BUNDLE DRY-RUN PASSED');
} else {
  console.error(`\n${failures} FAILURES`);
  process.exit(1);
}
