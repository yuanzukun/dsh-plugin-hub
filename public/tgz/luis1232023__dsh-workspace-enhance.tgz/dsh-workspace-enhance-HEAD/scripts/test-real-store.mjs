/**
 * Real-store engine test: loads the ACTUAL @deepseek-ai/dsh-client-runtime
 * client bundle through a ModuleLoader stub, takes its real defineStore,
 * builds OUR store spec, and exercises actions + persist rehydration
 * (including an old-shaped persisted state).
 */
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const profileRequire = createRequire('C:/Users/yicheng/.dsh/profiles/web/package.json');

const cordis = profileRequire('@deepseek-ai/cordis');
const slots = profileRequire('@deepseek-ai/dsh-client-ui-slots');

// ── localStorage stub ──────────────────────────────────────────────────────
const storage = new Map();
const localStorage = {
  getItem: (k) => (storage.has(k) ? storage.get(k) : null),
  setItem: (k, v) => storage.set(k, String(v)),
  removeItem: (k) => storage.delete(k),
  clear: () => storage.clear(),
};
globalThis.localStorage = localStorage;

// ── load the runtime client bundle through a loader stub ───────────────────
const runtimePath = profileRequire.resolve('@deepseek-ai/dsh-client-runtime/client');
const runtimeCode = readFileSync(runtimePath, 'utf8');
let runtimeExports = null;
const window = {
  __ModuleLoader__: {
    load: (spec) => {
      runtimeExports = spec.factory((id) => {
        if (id === '@deepseek-ai/cordis') return cordis;
        if (id === '@deepseek-ai/dsh-client-ui-slots') return slots;
        throw new Error(`runtime stub require: ${id}`);
      });
    },
  },
};
globalThis.window = window;
new Function('window', runtimeCode)(window);
const { defineStore } = runtimeExports ?? {};
if (!defineStore) {
  console.error('FAIL: defineStore not exported from runtime bundle');
  process.exit(1);
}

let failures = 0;
const check = (name, cond, extra) => {
  if (cond) console.log(`  ok  ${name}`);
  else {
    failures += 1;
    console.error(`FAIL  ${name}${extra ? ` — ${extra}` : ''}`);
  }
};

// ── our store spec, compiled inline (mirrors src/store.ts) ─────────────────
const createStore = () =>
  defineStore({
    init: () => ({
      tab: 'sessions',
      filesRoot: undefined,
      gitRepo: undefined,
      preview: null,
      deletedSessionIds: [],
    }),
    persist: 'dsh.workspace.enhance.v1',
    actions: {
      setTab: (d, tab) => {
        d.tab = tab;
      },
      setFilesRoot: (d, root) => {
        d.filesRoot = root;
      },
      setGitRepo: (d, repo) => {
        d.gitRepo = repo;
      },
      openPreview: (d, p, n) => {
        d.preview = { path: p, name: n, status: 'loading' };
      },
      setPreview: (d, preview) => {
        d.preview = preview;
      },
      closePreview: (d) => {
        d.preview = null;
      },
      markSessionDeleted: (d, id) => {
        if (!d.deletedSessionIds.includes(id)) d.deletedSessionIds.push(id);
      },
    },
  });

const store = createStore().create();
check('initial tab sessions', store.getSnapshot().tab === 'sessions');

// exercise every action
store.actions.setTab('git');
check('setTab works', store.getSnapshot().tab === 'git');
store.actions.openPreview('D:\\a.txt', 'a.txt');
check('openPreview works', store.getSnapshot().preview?.status === 'loading');
store.actions.setPreview({ path: 'D:\\a.txt', name: 'a.txt', status: 'ready' });
check('setPreview works', store.getSnapshot().preview?.status === 'ready');
store.actions.closePreview();
check('closePreview works', store.getSnapshot().preview === null);
store.actions.markSessionDeleted('s1');
store.actions.markSessionDeleted('s1');
check('markSessionDeleted dedupes', store.getSnapshot().deletedSessionIds.length === 1);

// persisted state was written
const raw = localStorage.getItem('dsh.workspace.enhance.v1');
check('persist wrote state', typeof raw === 'string' && raw.includes('"git"'), String(raw));

// rehydration: a second instance reloads the persisted state (page reload)
const store2 = createStore().create();
check('rehydrated tab from persisted', store2.getSnapshot().tab === 'git');
check('rehydrated deleted ids', store2.getSnapshot().deletedSessionIds.length === 1);

// rehydration with an OLD-shaped persisted state (missing newer keys):
// simulate a state written by a previous plugin version without deletedSessionIds
storage.set('dsh.workspace.enhance.v1', JSON.stringify({ tab: 'files', filesRoot: undefined, gitRepo: undefined, preview: null }));
let store3;
try {
  store3 = createStore().create();
  const snap = store3.getSnapshot();
  check('old-shape rehydrate survives', snap.tab === 'files');
  check('old-shape missing key is undefined', snap.deletedSessionIds === undefined);
  // Rehydration with a partial (old-shaped) state leaves newer keys undefined.
  // The session list consumes this via `new Set(deletedSessionIds)`; in JS
  // `new Set(undefined)` is an empty set, so the guard pattern is safe.
  check('missing key is safe under new Set(undefined)', new Set(snap.deletedSessionIds).size === 0);
} catch (e) {
  check('old-shape rehydrate survives', false, String(e));
}

if (failures === 0) {
  console.log('\nREAL STORE TEST PASSED');
} else {
  console.error(`\n${failures} FAILURES`);
  process.exitCode = 1;
}
