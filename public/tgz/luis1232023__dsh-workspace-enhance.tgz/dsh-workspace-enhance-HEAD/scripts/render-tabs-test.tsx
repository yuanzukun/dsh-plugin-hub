/**
 * Full WorkspaceRegion render test (v2 per-folder tabs): mounts the region
 * with mocked hooks/store, expands a workspace folder, switches its sub-tabs
 * (会话 -> 文件浏览 -> Git), exercises the file tree + preview + git detail,
 * and verifies the ungrouped bucket and rail mode.
 */
import './hook-resolver';
import { create, act } from 'react-test-renderer';
import React from 'react';
import { WorkspaceRegion } from '../src/tabs/WorkspaceRegion';
import type { EnhanceState } from '../src/store';
import type { TabId } from '../src/contract';

// Node has no rAF; the search button focuses via requestAnimationFrame.
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(globalThis as any).requestAnimationFrame = (cb: () => void) => setTimeout(cb, 0) as unknown as number;

// The Menu component reads window geometry and attaches document listeners.
const noop = () => {};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(globalThis as any).window = { innerWidth: 1280, innerHeight: 800 };
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(globalThis as any).document = { addEventListener: noop, removeEventListener: noop };

// ── fake store (v2 shape) ──────────────────────────────────────────────────
let state: EnhanceState = {
  preview: null,
  deletedSessionIds: [],
  workspaceTabs: {},
  view: { groupBy: 'workspace', orderBy: 'updated' },
};

const actions = {
  openPreview: (path: string, name: string) => {
    state = { ...state, preview: { path, name, status: 'loading' } };
  },
  setPreview: (preview: EnhanceState['preview']) => {
    state = { ...state, preview };
  },
  closePreview: () => {
    state = { ...state, preview: null };
  },
  markSessionDeleted: (id: string) => {
    state = { ...state, deletedSessionIds: [...state.deletedSessionIds, id] };
  },
  setWorkspaceTab: (workspaceId: string, tab: TabId) => {
    state = { ...state, workspaceTabs: { ...state.workspaceTabs, [workspaceId]: tab } };
  },
  setGroupBy: (groupBy: EnhanceState['view']['groupBy']) => {
    state = { ...state, view: { ...state.view, groupBy } };
  },
  setOrderBy: (orderBy: EnhanceState['view']['orderBy']) => {
    state = { ...state, view: { ...state.view, orderBy } };
  },
};

const useStore = (sel: (s: EnhanceState) => unknown) => sel(state);

const sessions = {
  current: 's1',
  ids: ['s1', 's2', 's3'],
  byId: {
    s1: { id: 's1', cwd: 'D:\\luisdesk\\other', displayTitle: '会话A', updatedAt: Date.now(), running: false, blank: false },
    s2: { id: 's2', cwd: 'D:\\luisdesk\\other', displayTitle: '会话B', updatedAt: Date.now() - 1000, running: true, blank: false },
    s3: { id: 's3', cwd: 'C:\\elsewhere', displayTitle: '未分组会话', updatedAt: Date.now() - 2000, running: false, blank: false },
  },
};
const workspaces = {
  items: [
    { workspaceId: 'w1', path: 'D:\\luisdesk\\other', title: 'other', sessionIds: ['s1', 's2'], createdAt: 'x', updatedAt: 'x' },
  ],
};

const fakeApi = {
  fsRoot: async () => ({ cwd: 'D:\\luisdesk\\other', home: 'C:\\Users\\yicheng', dshHome: 'C:\\Users\\yicheng\\.dsh' }),
  fsList: async (p?: string) => {
    const dir = p ?? 'D:\\luisdesk\\other';
    const isSrc = dir.endsWith('\\src') || dir.endsWith('/src');
    return {
      path: dir,
      truncated: false,
      entries: isSrc
        ? [
            { name: 'file1.js', path: dir + '\\file1.js', isDir: false, hidden: false, size: 50, mtimeMs: 0 },
            { name: 'file2.ts', path: dir + '\\file2.ts', isDir: false, hidden: false, size: 60, mtimeMs: 0 },
          ]
        : [
            { name: 'src', path: 'D:\\luisdesk\\other\\src', isDir: true, hidden: false, size: 0, mtimeMs: 0 },
            { name: 'package.json', path: 'D:\\luisdesk\\other\\package.json', isDir: false, hidden: false, size: 100, mtimeMs: 0 },
            { name: '.git', path: 'D:\\luisdesk\\other\\.git', isDir: true, hidden: true, size: 0, mtimeMs: 0 },
          ],
    };
  },
  fsRead: async (p: string) => ({ kind: 'text', name: 'package.json', path: p, size: 100, truncated: false, language: 'json', content: '{}\n' }),
  gitStatus: async () => ({
    isRepo: true,
    branch: 'main',
    upstream: undefined,
    ahead: 1,
    behind: 0,
    noCommits: false,
    entries: [
      { x: 'M', y: ' ', path: 'a.txt' },
      { x: '?', y: '?', path: 'new.txt' },
    ],
    error: undefined,
  }),
  gitLog: async () => ({
    isRepo: true,
    commits: [
      { hash: 'abc1234abc1234abc1234abc1234abc1234abc1', shortHash: 'abc1234', author: 't', email: 't@t', date: '2026-08-16T10:00:00+08:00', subject: 'a commit', refs: 'HEAD -> main', graph: '* ' },
    ],
    error: undefined,
  }),
  gitBranches: async () => ({
    isRepo: true,
    branches: ['main'],
    current: 'main',
    error: undefined,
  }),
  gitShow: async () => ({
    isRepo: true,
    meta: { hash: 'abc', shortHash: 'abc1234', author: 't', email: 't@t', date: '2026-08-16T10:00:00+08:00', committer: 't', committerEmail: 't@t', commitDate: '2026-08-16T10:00:00+08:00', subject: 'a commit', body: '', refs: 'HEAD -> main' },
    files: [{ status: 'M', path: 'x.txt' }],
    patch: 'diff',
    patchTruncated: false,
    error: undefined,
  }),
  sessionDelete: async () => ({ deleted: true, removedDirs: [] }),
  debugReport: async () => ({ written: true }),
};

const injected = {
  api: fakeApi,
  openSession: () => {},
  startSession: () => {},
  connectWorkspace: async () => 'new' as never,
  renameSession: async () => {},
  renameWorkspace: async () => {},
  deleteWorkspace: async () => {},
  archiveSession: async () => {},
  createWorkspace: async () => {},
  pickWorkspaceDir: async () => null,
  refreshSessions: async () => {},
  searchSessions: async () => ({ items: [], hasMore: false }),
  openFile: (path: string, name: string) => {
    actions.openPreview(path, name);
  },
};

let failures = 0;
const check = (name: string, cond: boolean, extra?: string) => {
  if (cond) console.log(`  ok  ${name}`);
  else {
    failures += 1;
    console.error(`FAIL  ${name}${extra ? ` — ${extra}` : ''}`);
  }
};

const props = {
  wide: true,
  expandSidebar: () => {},
  useSessions: (sel: (s: unknown) => unknown) => sel(sessions),
  useWorkspaces: (sel: (s: unknown) => unknown) => sel(workspaces),
  useStore,
  actions,
  ...injected,
};

async function main() {
  let renderer;
  await act(async () => {
    renderer = create(React.createElement(WorkspaceRegion, props));
  });
  await act(async () => {
    await new Promise((r) => setTimeout(r, 60));
  });

  let text = JSON.stringify(renderer.toJSON());
  check('folder header rendered', text.includes('other'));
  check('section label shows 工作区 (grouped)', text.includes('dwe-section-label') && text.includes('工作区'));
  check('folder sub-tabs include 文件', text.includes('dwe-folder-tabs') && text.includes('文件'));
  check('folder sub-tabs include Git (repo)', text.includes('Git'));
  check('session rows under folder', text.includes('会话A') && text.includes('会话B'));
  check('ungrouped bucket present', text.includes('未分组') && text.includes('未分组会话'));

  // switch folder sub-tab to files
  await act(async () => {
    actions.setWorkspaceTab('w1', 'files');
    renderer.update(React.createElement(WorkspaceRegion, props));
  });
  await act(async () => {
    await new Promise((r) => setTimeout(r, 50));
  });
  text = JSON.stringify(renderer.toJSON());
  check('files tree rendered', text.includes('package.json') && text.includes('src'));

  // file browser overflow menu: 刷新文件夹 / 显示 dot 文件
  const moreBtn = renderer.root.findAll((n) => n.props?.className === 'dwe-iconbtn28' && n.props?.title === '更多操作')[0];
  check('file browser more button found', !!moreBtn);
  if (moreBtn) {
    await act(async () => {
      moreBtn.props.onClick({ clientX: 200, clientY: 200 });
    });
    text = JSON.stringify(renderer.toJSON());
    check('file menu shows 刷新文件夹 / 显示 dot 文件', text.includes('刷新文件夹') && text.includes('显示 dot 文件'));
  }

  // expand src dir and click a file
  const dirRow = renderer.root.findAll((n) => n.props?.className === 'dwe-tree-row' && n.props?.['data-dir'])[0];
  check('dir row found', !!dirRow);
  if (dirRow) {
    await act(async () => {
      dirRow.props.onClick();
    });
    await act(async () => {
      await new Promise((r) => setTimeout(r, 50));
    });
  }
  const fileRow = renderer.root.findAll((n) => n.props?.className === 'dwe-tree-row' && !n.props?.['data-dir'])[0];
  check('file row found', !!fileRow);
  if (fileRow) {
    await act(async () => {
      fileRow.props.onClick();
    });
    check('preview opened in store', state.preview?.status === 'loading');
  }

  // switch folder sub-tab to git
  await act(async () => {
    actions.setWorkspaceTab('w1', 'git');
    renderer.update(React.createElement(WorkspaceRegion, props));
  });
  await act(async () => {
    await new Promise((r) => setTimeout(r, 80));
  });
  text = JSON.stringify(renderer.toJSON());
  check('git Changes view default', text.includes('Changes') && text.includes('Graph'));
  check('changes list shows status entries', text.includes('a.txt') && text.includes('new.txt'));

  // click a changed file -> preview opens
  const changeRow = renderer.root.findAll((n) => n.props?.className === 'dwe-git-file' && n.props?.['data-clickable'])[0];
  check('change row found', !!changeRow);
  if (changeRow) {
    await act(async () => {
      changeRow.props.onClick();
    });
    check('change click opens preview', state.preview?.status === 'loading');
  }

  // git overflow menu: 刷新 folded into ⋯
  const gitMoreBtn = renderer.root.findAll((n) => n.props?.className === 'dwe-iconbtn28' && n.props?.title === '更多操作')[0];
  check('git more button found', !!gitMoreBtn);
  if (gitMoreBtn) {
    await act(async () => {
      gitMoreBtn.props.onClick({ clientX: 300, clientY: 300 });
    });
    text = JSON.stringify(renderer.toJSON());
    check('git menu shows 刷新', text.includes('刷新'));
  }

  // switch to Graph view
  const graphBtn = renderer.root.findAll((n) => n.props?.className === 'dwe-git-view' && String(n.props.children ?? '') === 'Graph')[0];
  check('graph view button found', !!graphBtn);
  if (graphBtn) {
    await act(async () => {
      graphBtn.props.onClick();
    });
    await act(async () => {
      await new Promise((r) => setTimeout(r, 30));
    });
    text = JSON.stringify(renderer.toJSON());
    check('graph view renders commits', text.includes('abc1234') && text.includes('a commit'));
  }

  const commitRow = renderer.root.findAll((n) => n.props?.className === 'dwe-git-commit')[0];
  check('commit row found', !!commitRow);
  if (commitRow) {
    await act(async () => {
      commitRow.props.onClick();
    });
    await act(async () => {
      await new Promise((r) => setTimeout(r, 50));
    });
    text = JSON.stringify(renderer.toJSON());
    check('commit detail rendered', text.includes('x.txt'));
  }

  // rail mode
  await act(async () => {
    renderer.update(React.createElement(WorkspaceRegion, { ...props, wide: false }));
  });
  text = JSON.stringify(renderer.toJSON());
  check('rail renders three icons', (text.match(/dwe-rail-button/g) ?? []).length === 3);

  // back to wide; exercise the section header search + view menu
  await act(async () => {
    renderer.update(React.createElement(WorkspaceRegion, { ...props, wide: true }));
  });
  // open search, type a query, expect metadata results
  const searchBtn = renderer.root.findAll((n) => n.props?.className === 'dwe-search-button')[0];
  check('search button found', !!searchBtn);
  if (searchBtn) {
    await act(async () => {
      searchBtn.props.onClick();
    });
    const input = renderer.root.findAll((n) => n.props?.className === 'dwe-search-input')[0];
    check('search input found', !!input);
    if (input) {
      await act(async () => {
        input.props.onChange({ target: { value: '会话A' } });
      });
      await act(async () => {
        await new Promise((r) => setTimeout(r, 60));
      });
      text = JSON.stringify(renderer.toJSON());
      check('search results show matching session', text.includes('dwe-search-result-row') && text.includes('会话A'));
      check('search hides folder list', !text.includes('dwe-project-row'));
    }
    // clear search
    await act(async () => {
      renderer.root.findAll((n) => n.props?.className === 'dwe-search-input')[0]?.props.onChange({ target: { value: '' } });
    });
    await act(async () => {
      await new Promise((r) => setTimeout(r, 60));
    });
  }

  // view menu -> flat list
  const viewBtn = renderer.root.findAll((n) => n.props?.className === 'dwe-iconbtn28' && n.props?.['aria-label'] === '视图选项')[0];
  check('view button found', !!viewBtn);
  if (viewBtn) {
    await act(async () => {
      viewBtn.props.onClick({ clientX: 100, clientY: 100 });
    });
    text = JSON.stringify(renderer.toJSON());
    check('view menu renders', text.includes('平铺列表') && text.includes('最近更新'));
    const flatItem = renderer.root.findAll((n) => n.props?.className === 'dwe-menu-item' && String(n.props.children ?? '').includes('平铺列表'))[0];
    check('flat list menu item found', !!flatItem);
    if (flatItem) {
      await act(async () => {
        flatItem.props.onClick();
      });
      await act(async () => {
        renderer.update(React.createElement(WorkspaceRegion, props));
      });
      text = JSON.stringify(renderer.toJSON());
      check('flat view renders all sessions', text.includes('会话A') && text.includes('未分组会话') && !text.includes('dwe-project-row'));
      // reset to grouped
      await act(async () => {
        actions.setGroupBy('workspace');
        renderer.update(React.createElement(WorkspaceRegion, props));
      });
    }
  }

  // non-repo folder must not show a Git sub-tab
  const noRepoApi = { ...fakeApi, gitStatus: async () => ({ isRepo: false, branch: '', upstream: undefined, ahead: 0, behind: 0, noCommits: false, entries: [], error: 'not a repo' }) };
  const noRepoProps = { ...props, api: noRepoApi };
  let renderer2;
  await act(async () => {
    renderer2 = create(React.createElement(WorkspaceRegion, noRepoProps));
  });
  await act(async () => {
    await new Promise((r) => setTimeout(r, 80));
  });
  const noRepoText = JSON.stringify(renderer2.toJSON());
  check('non-repo folder hides Git tab', !noRepoText.includes('Git'), noRepoText.slice(0, 200));

  if (failures === 0) {
    console.log('\nWORKSPACEREGION RENDER TEST PASSED');
  } else {
    console.error(`\n${failures} FAILURES`);
    process.exitCode = 1;
  }
}

void main();
