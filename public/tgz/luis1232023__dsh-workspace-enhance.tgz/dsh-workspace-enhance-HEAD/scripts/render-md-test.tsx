/**
 * Render-test for the markdown preview (FilePreviewOverlay): a markdown file
 * defaults to the RENDERED preview (预览), with a 源码 tab switching to the
 * highlighted source; non-markdown files show no tabs.
 * Built to CJS by esbuild and run with node.
 */
import './hook-resolver';
import { create, act } from 'react-test-renderer';
import React from 'react';
import { FilePreviewOverlay } from '../src/preview/FilePreviewOverlay';

// Node has no document; the overlay attaches an Esc listener only.
const noop = () => {};
// eslint-disable-next-line @typescript-eslint/no-explicit-any
(globalThis as any).document = { addEventListener: noop, removeEventListener: noop };

const MD = `# Title

**bold** and \`inline\`.

\`\`\`js
const x = 1;
\`\`\`

| a | b |
|---|---|
| 1 | 2 |
`;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const state: any = {
  preview: {
    path: 'D:\\x.md',
    name: 'x.md',
    status: 'ready',
    read: {
      kind: 'text',
      name: 'x.md',
      path: 'D:\\x.md',
      size: MD.length,
      truncated: false,
      language: 'markdown',
      content: MD,
    },
  },
};

const props = {
  useStore: (sel: (s: unknown) => unknown) => sel(state),
  actions: { closePreview: () => {}, api: {} },
};

let failures = 0;
const check = (name: string, cond: boolean, extra?: string) => {
  if (cond) console.log(`  ok  ${name}`);
  else {
    failures += 1;
    console.error(`FAIL  ${name}${extra ? ` — ${extra}` : ''}`);
  }
};

async function main() {
  let renderer: { toJSON(): unknown; root: { findAll(fn: (n: { props?: Record<string, unknown> }) => boolean): { props: Record<string, unknown> }[] } };
  await act(async () => {
    renderer = create(React.createElement(FilePreviewOverlay, props));
  });
  const text = JSON.stringify(renderer.toJSON());
  check('markdown preview renders h1', text.includes('<h1') && text.includes('Title'), text.slice(0, 300));
  check('markdown preview renders bold', text.includes('<strong') && text.includes('bold'));
  check('markdown default = rendered preview', text.includes('dwe-preview-md') && !text.includes('dwe-preview-code'));
  check('code block highlighted', text.includes('language-js') && text.includes('token '));
  check('gfm table rendered', text.includes('<table') && text.includes('<th'));

  // 源码 tab → highlighted markdown source.
  const sourceTab = renderer.root.findAll((n) => n.props?.children === '源码')[0];
  check('source tab found', !!sourceTab);
  if (sourceTab) {
    await act(async () => {
      sourceTab.props.onClick();
    });
    const srcText = JSON.stringify(renderer.toJSON());
    check('source view shows highlighted code', srcText.includes('dwe-preview-code') && srcText.includes('line-numbers-rows'));
    check('source view hides rendered html', !srcText.includes('<h1'));
  }

  // 预览 tab → back to rendered.
  const previewTab = renderer.root.findAll((n) => n.props?.children === '预览')[0];
  check('preview tab found', !!previewTab);
  if (previewTab) {
    await act(async () => {
      previewTab.props.onClick();
    });
    check('back to rendered preview', JSON.stringify(renderer.toJSON()).includes('dwe-preview-md'));
  }

  // Non-markdown text file: highlighted source, no 预览/源码 tabs.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const jsState: any = {
    preview: {
      ...state.preview,
      read: { ...state.preview.read, language: 'javascript', content: 'const a = 1;\n' },
    },
  };
  let r2: { toJSON(): unknown };
  await act(async () => {
    r2 = create(
      React.createElement(FilePreviewOverlay, {
        ...props,
        useStore: (sel: (s: unknown) => unknown) => sel(jsState),
      }),
    );
  });
  const jsText = JSON.stringify(r2.toJSON());
  check('code file has no md tabs', !jsText.includes('预览') && !jsText.includes('源码'));
  check('code file highlighted by language', jsText.includes('token '));

  if (failures === 0) {
    console.log('\nMARKDOWN PREVIEW RENDER TEST PASSED');
  } else {
    console.error(`\n${failures} FAILURES`);
    process.exitCode = 1;
  }
}

void main();
