/**
 * Test-only module resolver hook: maps @deepseek-ai/dsh-client-ui-primitives
 * to a stub so the render test stays hermetic (the real package lives in the
 * web profile's node_modules, not in the plugin's dev node_modules).
 * Must be imported FIRST in the test driver.
 */
import Module from 'node:module';
import path from 'node:path';

const stubPath = path.join(__dirname, '.stubs', 'primitives.cjs');

// eslint-disable-next-line @typescript-eslint/no-explicit-any
const origResolve = (Module as any)._resolveFilename as (...args: unknown[]) => string;

// eslint-disable-next-line @typescript-eslint/no-explicit-any
(Module as any)._resolveFilename = function (request: string, ...args: unknown[]) {
  if (request === '@deepseek-ai/dsh-client-ui-primitives') return stubPath;
  return origResolve.call(this, request, ...args);
};

export {};
