/**
 * Render-test driver for GitPanel (and the crash path): mounts GitPanel with
 * mocked hooks/api, flushes the async load, then opens a commit detail.
 * Built to CJS by esbuild and run with node.
 */
import './hook-resolver';
import { create, act } from 'react-test-renderer';
import React from 'react';
import { GitPanel } from '../src/tabs/GitPanel';

const sessions = {
  current: 's1',
  ids: ['s1'],
  byId: { s1: { id: 's1', cwd: 'D:\\luisdesk\\other', displayTitle: 'other', updatedAt: Date.now() } },
};
const workspaces = {
  items: [
    { workspaceId: 'w1', path: 'D:\\luisdesk\\other', title: 'other', sessionIds: [], createdAt: 'x', updatedAt: 'x' },
  ],
};

const commit = {
  hash: '8d6921415651f8ca3531269d9d8d0cf258b4be9a',
  shortHash: '8d69214',
  author: 't',
  email: 't@t',
  date: '2026-08-16T23:32:28+08:00',
  subject: 'second: add sub/c.md',
  refs: 'HEAD -> main',
};

const api = {
  gitStatus: async () => ({
    isRepo: true,
    branch: 'main',
    upstream: undefined,
    ahead: 0,
    behind: 0,
    noCommits: false,
    entries: [],
    error: undefined,
  }),
  gitLog: async () => ({ isRepo: true, commits: [commit], error: undefined }),
  gitBranches: async () => ({
    isRepo: true,
    branches: ['main', 'feature'],
    current: 'main',
    error: undefined,
  }),
  gitShow: async () => ({
    isRepo: true,
    meta: { ...commit, body: 'body text', committer: 't', committerEmail: 't@t', commitDate: commit.date },
    files: [
      { status: 'M', path: 'a.txt' },
      { status: 'R100', path: 'sub/c.md', oldPath: 'sub/b.md' },
    ],
    patch: 'diff --git a/a.txt b/a.txt\n@@ -1 +1 @@\n-old\n+new\n',
    patchTruncated: false,
    error: undefined,
  }),
};

const props = {
  api,
  useSessions: (sel) => sel(sessions),
  useWorkspaces: (sel) => sel(workspaces),
  gitRepo: undefined,
  setGitRepo: () => {},
};

let failures = 0;
const check = (name, cond, extra) => {
  if (cond) console.log(`  ok  ${name}`);
  else {
    failures += 1;
    console.error(`FAIL  ${name}${extra ? ` — ${extra}` : ''}`);
  }
};

async function main() {
  let renderer;
  await act(async () => {
    renderer = create(React.createElement(GitPanel, props));
  });
  // Let the async loadRepo settle (status + log round trip).
  await act(async () => {
    await new Promise((r) => setTimeout(r, 80));
  });
  const json = renderer.toJSON();
  const text = JSON.stringify(json);
  check('list renders', text.includes('main') || text.includes('提交记录'));
  check('no crash face', !text.includes('data-slot-error'));

  // GitPanel defaults to the Changes view; switch to Graph to surface the
  // commit list before asserting on commit rows.
  await act(async () => {
    const graphBtn = renderer.root.findAll((n) => {
      const c = n.props?.children;
      return Array.isArray(c) ? c.includes('Graph') : c === 'Graph';
    })[0];
    if (graphBtn) graphBtn.props.onClick();
  });
  await act(async () => {
    await new Promise((r) => setTimeout(r, 80));
  });
  const graphText = JSON.stringify(renderer.toJSON());
  check('commit row rendered', graphText.includes(commit.shortHash) && graphText.includes(commit.subject));
  check('branch selector lists branches', graphText.includes('feature') && graphText.includes('main'));
  const row = renderer.root.findAll((n) => n.props?.className === 'dwe-git-commit')[0];
  check('found commit row', !!row);

  // Branch switch: selecting another branch re-fetches and keeps the graph.
  const sel = renderer.root.findAll((n) => n.props?.className === 'dwe-select')[0];
  check('branch selector found', !!sel);
  if (sel) {
    await act(async () => {
      sel.props.onChange({ target: { value: 'feature' } });
    });
    await act(async () => {
      await new Promise((r) => setTimeout(r, 80));
    });
    const afterSwitch = JSON.stringify(renderer.toJSON());
    check('branch switch keeps graph', afterSwitch.includes(commit.shortHash));
  }
  if (row) {
    await act(async () => {
      row.props.onClick();
    });
    await act(async () => {
      await new Promise((r) => setTimeout(r, 80));
    });
    const detail = JSON.stringify(renderer.toJSON());
    check('detail shows subject', detail.includes(commit.subject));
    check('detail shows changed files', detail.includes('a.txt') && detail.includes('sub/c.md'));
    check('detail shows patch', detail.includes('@@ -1 +1 @@'));
  }

  if (failures === 0) {
    console.log('\nGITPANEL RENDER TEST PASSED');
  } else {
    console.error(`\n${failures} FAILURES`);
    process.exitCode = 1;
  }
}

void main();
