# 贡献者公约（CODE_OF_CONDUCT）

本仓库遵循 [Contributor Covenant 2.1](https://www.contributor-covenant.org/) 行为准则。
参与本项目，即表示你同意遵守以下条款。中文翻译见文末（官方译本）；如有出入，以
英文原文为准。

---

## Our Pledge

We as members, contributors, and leaders pledge to make participation in our
community a harassment-free experience for everyone, regardless of age, body
size, visible or invisible disability, ethnicity, sex characteristics, gender
identity and expression, level of experience, education, socio-economic status,
nationality, personal appearance, race, caste, color, religion, or sexual
identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming,
diverse, inclusive, and healthy community.

## Our Standards

Examples of behavior that contributes to a positive environment for our
community include:

- Demonstrating empathy and kindness toward other people
- Being respectful of differing opinions, viewpoints, and experiences
- Giving and gracefully accepting constructive feedback
- Accepting responsibility and apologizing to those affected by our mistakes,
  and learning from the experience
- Focusing on what is best not just for us as individuals, but for the overall
  community

Examples of unacceptable behavior include:

- The use of sexualized language or imagery, and sexual attention or advances of
  any kind
- Trolling, insulting or derogatory comments, and personal or political attacks
- Public or private harassment
- Publishing others' private information, such as a physical or email address,
  without their explicit permission
- Other conduct which could reasonably be considered inappropriate in a
  professional setting

## Enforcement Responsibilities

Community leaders are responsible for clarifying and enforcing our standards of
acceptable behavior and will take appropriate and fair corrective action in
response to any behavior that they deem inappropriate, threatening, offensive,
or harmful.

Community leaders have the right and responsibility to remove, edit, or reject
comments, commits, code, wiki edits, issues, and other contributions that are
not aligned to this Code of Conduct, and will communicate reasons for moderation
decisions when appropriate.

## Scope

This Code of Conduct applies within all community spaces, and also applies when
an individual is officially representing the community in public spaces.
Examples of representing our community include using an official email address,
posting via an official social media account, or acting as an appointed
representative at an online or offline event.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be
reported to the community leaders responsible for enforcement at the repository
owner's contact address (see [SECURITY.md](./SECURITY.md)). All complaints will
be reviewed and investigated promptly and fairly.

All community leaders are obligated to respect the privacy and security of the
reporter of any incident.

## Attribution

This Code of Conduct is adapted from the
[Contributor Covenant](https://www.contributor-covenant.org),
version 2.1, available at
<https://www.contributor-covenant.org/version/2/1/code_of_conduct.html>.

---

## 中文译本（官方 2.1 译本）

### 我们的承诺

身为社区成员、贡献者和领袖，我们承诺使社区参与者不受骚扰，无论其年龄、体型、
有形或无形的残障、族裔、性征、性别认同与表达、经验级别、教育程度、社会经济地位、
国籍、个人外貌、种族、种姓、肤色、宗教信仰或性取向如何。

我们承诺以有助于建立开放、友善、多元、包容、健康社区的方式行事和互动。

### 我们的准则

有助于为我们的社区创造积极环境的行为例子包括但不限于：

- 以同理心和善良待人
- 尊重不同的意见、观点和经历
- 给予并优雅地接受建设性意见
- 承担责任并向受我们错误影响的人道歉，从经验中学习
- 关注不仅对我们个人，而且对整个社区最有利的事情

不可接受的行为例子包括：

- 使用与性有关的语言或意象，以及任何形式的性关注或性暗示
- 挑衅、侮辱或贬损性评论，以及人身或政治攻击
- 公开或私下的骚扰
- 未经明确许可，发布他人的私人信息，如住址或电子邮件地址
- 其他在专业环境中可被合理认为不恰当的行为

### 执行责任

社区领袖负责澄清和执行我们认可的行为标准，并将对他们认为不适当、威胁、冒犯或
有害的行为采取适当和公正的纠正措施。

社区领袖有权和责任删除、编辑或拒绝不符合本行为准则的评论、提交、代码、维基编辑、
议题和其他贡献，并在适当情况下沟通处理决定的原因。

### 适用范围

本行为准则适用于所有社区空间，也适用于个人在公共场所正式代表社区时的情形。
代表我们社区的例子包括使用官方电子邮件地址、通过官方社交媒体账户发布信息，或
在线上或线下活动中担任指定代表。

### 执行

如有滥用、骚扰或其他不可接受行为，可通过仓库所有者的联系方式（见
[SECURITY.md](./SECURITY.md)）向负责执行的社区领袖举报。所有投诉都将得到及时
、公正的审查和调查。

所有社区领袖都有义务尊重任何事件举报人的隐私和安全。

### 出处

本行为准则改编自 [Contributor Covenant](https://www.contributor-covenant.org/)
2.1 版，见 <https://www.contributor-covenant.org/version/2/1/code_of_conduct.html>。
