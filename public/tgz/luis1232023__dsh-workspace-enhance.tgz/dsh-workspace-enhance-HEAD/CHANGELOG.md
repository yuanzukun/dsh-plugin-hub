# Changelog

本文件遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 规范，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [Unreleased]

### 变更

- UI：移除展开文件夹时的「Agent Workspace 汇总条」（正在工作 Agent 数 / 任务数 / 文件改动数 /
  当前分支），恢复为直接显示子 Tab 与列表，保持列表紧凑。

### 新增

- 仓库规范化：新增 `CONTRIBUTING.md`（贡献规范，对照
  [github/explore 的 CONTRIBUTING.md](https://github.com/github/explore/blob/main/CONTRIBUTING.md)
  结构）、`LICENSE`（MIT）、`CODE_OF_CONDUCT.md`、`SECURITY.md`、`CHANGELOG.md`。
- 社区健康文件：`.github/PULL_REQUEST_TEMPLATE.md`、
  `.github/ISSUE_TEMPLATE/`（bug / 功能请求 / 文档三类模板）。
- 工程规范：`package.json` 补全 `repository` / `homepage` / `keywords` /
  `author` / `bugs` / `engines`，新增 `typecheck` 与 `test` 脚本。
- CI：`.github/workflows/ci.yml`（install → typecheck → build → test）。
- 功能：Git Graph 视图新增分支选择列表（顶部左侧一行，默认选中当前分支），
  切换分支后重新拉取该分支的提交图；新增只读 RPC 端点 `git/branches`，
  `git/log` 支持按分支过滤。
- 功能：文件树新增彩色图标——文件夹为 Windows 资源管理器风格的黄色文件夹
  （区分展开/收起），文件按扩展名区分类型（JS/TS/JSON/Markdown/图片/文本/
  配置/代码/通用），全部为内联 SVG（`src/fileIcons.tsx`）。
- 功能：Markdown 文件在右侧预览默认渲染为 HTML 预览（GFM 语法：标题/表格/
  任务列表/代码块语法高亮），顶部「预览 / 源码」Tab 可切换；渲染管线
  （micromark + mdast/hast）与 prismjs 一样内联打包进 client bundle
  （新增 devDependencies 声明，`src/markdown.ts`）。
- README：新增徽章、贡献指引、Staying informed 与 FAQ 小节。

### 变更

- UI：工作区文件夹下的子 Tab「会话」更名为「任务」（任务 / 文件 / Git），相关
  菜单、弹窗、空态、搜索等用户可见文案同步更新。
- UI：当前任务所在行的状态圆点点亮为蓝色（与文件夹行的激活态同色），仅非当前
  空闲任务保持灰色圆点。
- UI：统一子 Tab（任务 / 文件 / Git）标签与下方内容文字大小为 12px——会话行标题、
  文件树、Git 提交标题、搜索结果行此前分别为 14px / 12px / 12.5px / 12.5px。

### 修复

- `scripts/dry-run-client.mjs`：按 shell 实际契约（loader `factory(require)` 的
  返回值）物化 bundle 导出，补齐 `dsh-client-ui-primitives` / `window` /
  `slots.onEntryError` stub 与样式幂等查询，修正组件名断言（`WorkspaceRegion`），
  使测试真实通过（此前为失效断言，从未执行到）。
- `scripts/test-real-store.mjs`：修正 `new Set(undefined)` 会抛错的错误前提
  （JS 中返回空集），改为验证部分状态重水合下防护模式的安全性。
- `lib/index.js`：修复 Git Graph 视图报 `unknown option: --graph` ——
  `--graph` 被 `unshift` 到了 `log` 子命令之前（`git --graph log …`），改为追加
  到选项末尾（`git log … --graph`）；同时把 `-n <count>` 拆成独立参数；
  新增 graph 模式回归测试。
- `scripts/render-git-test.tsx`：补上缺失的 `./hook-resolver` 导入（与
  render-tabs 测试一致，对 primitives 做隔离——否则会加载真实的
  `dsh-client-ui-primitives`，其顶层 `katex` CSS 导入在 Node 下直接崩溃）；
  并在断言提交行前先切换到 Graph 视图（GitPanel 默认视图为 Changes，
  旧产物与当前源码已脱节）。

## [0.1.0] - 2025-01-01

### 新增

- 初始版本：DSH Web 侧栏工作区增强插件。
- 会话：每个工作区文件夹下的会话打开 / 重命名 / 归档 / 彻底删除；文件夹行
  新建会话 / 重命名 / 删除工作区；顶部「＋新会话」。
- 文件：以文件夹为根的文件树（懒加载、dot 按钮切换隐藏文件），点击文件在
  右侧预览（文本语法高亮 / 图片 / 二进制占位）。
- Git：Changes / Graph 双视图（仅 git 仓库显示）；Graph 支持 ASCII 分支图与
  单次提交元信息 / 变更文件 / diff 查看。
- 区头：搜索（展开式输入 + 内容搜索）、添加工作区（系统目录选择器）、
  视图选项（按工作区 / 平铺、最近更新 / 手动）。
- 架构：node 半边 RPC 通道（`fs/root`、`fs/list`、`fs/read`、`git/log`、
  `git/show`、`git/status`、`session/delete`、`debug/report`）；client 半边
  注册 `sidebar.workspaces`（priority -1）与 `shell.overlay` 槽位。
- 样式对齐默认工作区（`--dsw-*` 变量、34px / 32px 行高、运行中动画点等）。
