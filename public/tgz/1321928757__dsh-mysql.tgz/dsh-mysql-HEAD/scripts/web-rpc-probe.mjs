/**
 * dsh-mysql 隔离 Web 的 RPC 全链路探针。
 *
 * 通过 Chrome DevTools Protocol 驱动真实 UI，逐个打通客户端声明并在 UI 上可见的
 * 6 个 RPC 方法（第 7 个 `listTables` 客户端从不调用，由 test/typert.test.mjs 与
 * test/client-typert.test.mjs 的契约测试覆盖）：
 *
 *   - listConnections   打开 设置 → MySQL 数据库，空态文案渲染成功；
 *   - saveConnection    填写表单并保存，卡片出现、通知"已保存"，密码不落 DOM；
 *   - listConnections   刷新页面后卡片仍在（证明连接来自磁盘而非 React 状态）；
 *   - testConnection    无 3306 监听时优雅失败（connect ECONNREFUSED），无未捕获异常；
 *   - getSelection      输入栏控件渲染为 is-off 而非 is-warn；
 *   - selectConnection  在选择面板里增删多个连接，按钮显示单选/多选/空选状态且面板保持打开；
 *   - deleteConnection  删除并二次确认，回到空态。
 *
 * 探针自带清理：开始与结束都通过 UI 删除自己的连接，可重复运行；结束时
 * `connections.json` 不残留探针连接。
 * 表单提交还会验证 schema-change 开关默认关闭、独立风险确认必填，且编辑已授权连接时不会要求再次确认。
 *
 * 用法：node web-rpc-probe.mjs <url> <debugPort> [timeoutMs]
 * 输出一行 JSON；退出码始终为 0，由调用方按 verdict 判定。
 */
const [, , url, debugPortArg, timeoutArg] = process.argv
const debugPort = Number(debugPortArg)
const timeoutMs = Number(timeoutArg ?? 120000)

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))
const PROBE_NAME = 'dsh-mysql-rpc-probe'
const PROBE_SECOND_NAME = 'dsh-mysql-rpc-probe-2'
const PROBE_PASSWORD = 'p@ssw0rd-probe-do-not-log'

const steps = []
function record(step, ok, detail) {
  steps.push({ step, ok: ok === true, detail: detail === undefined ? null : String(detail).slice(0, 400) })
}

// ── CDP 连接 ───────────────────────────────────────────────────────────────
let page
for (let attempt = 0; attempt < 60; attempt++) {
  try {
    const list = await (await fetch(`http://127.0.0.1:${debugPort}/json/list`)).json()
    page = list.find((t) => t.type === 'page' && typeof t.webSocketDebuggerUrl === 'string')
    if (page !== undefined) break
  } catch { /* devtools endpoint not up yet */ }
  await sleep(250)
}
if (page === undefined) {
  console.log(JSON.stringify({ verdict: 'no-cdp-target', steps }, null, 2))
  process.exit(0)
}

const socket = new WebSocket(page.webSocketDebuggerUrl)
const pending = new Map()
const consoleMessages = []
const exceptions = []
let nextId = 1
socket.addEventListener('message', (event) => {
  const message = JSON.parse(event.data)
  if (message.id !== undefined) {
    const entry = pending.get(message.id)
    if (entry === undefined) return
    pending.delete(message.id)
    if (message.error !== undefined) entry.reject(new Error(message.error.message))
    else entry.resolve(message.result)
    return
  }
  if (message.method === 'Runtime.consoleAPICalled' && message.params.type === 'error') {
    consoleMessages.push(message.params.args.map((a) => a.value ?? a.description ?? a.type).join(' ').slice(0, 500))
  }
  if (message.method === 'Runtime.exceptionThrown') {
    const details = message.params.exceptionDetails
    exceptions.push((details.exception?.description ?? details.text ?? 'unknown').slice(0, 800))
  }
})
function send(method, params = {}) {
  const id = nextId++
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject })
    socket.send(JSON.stringify({ id, method, params }))
  })
}
await new Promise((resolve, reject) => {
  socket.addEventListener('open', resolve)
  socket.addEventListener('error', () => reject(new Error('CDP socket error')))
})
await send('Runtime.enable')
await send('Page.enable')

const evaluate = async (expression) =>
  (await send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true })).result?.value
const waitFor = async (expression, ms = 20000) => {
  const deadline = Date.now() + ms
  while (Date.now() < deadline) {
    if (await evaluate(expression) === true) return true
    await sleep(300)
  }
  return false
}
const settingsText = () => evaluate('(document.querySelector(".dsh-mysql-settings") || {}).innerText || ""')
/** 等设置页的 listConnections 结束（加载中… → 有内容/空态）。 */
const waitForSettingsSettled = async (ms = 15000) => {
  await waitFor(`/还没有配置任何连接|${PROBE_NAME}|连接失败/.test((document.querySelector('.dsh-mysql-settings') || {}).innerText || '')`, ms)
  return settingsText()
}
const clickInSettings = (text) => evaluate(`(() => {
  const scope = document.querySelector('.dsh-mysql-settings')
  if (scope === null) return false
  const el = Array.from(scope.querySelectorAll('button')).find((b) => (b.innerText || '').replace(/\\s+/g, '').includes(${JSON.stringify(text)}))
  if (el === undefined) return false
  el.click()
  return true
})()`)
const checkboxInSettings = (labelText, click = false) => evaluate(`(() => {
   const scope = document.querySelector('.dsh-mysql-settings')
   if (scope === null) return null
   const label = Array.from(scope.querySelectorAll('label')).find((node) => (node.innerText || '').includes(${JSON.stringify(labelText)}))
   const input = label && label.querySelector('input[type="checkbox"]')
   if (input === null || input === undefined) return null
   if (${click ? 'true' : 'false'}) input.click()
   return input.checked === true
 })()`)
const setField = (index, value) => evaluate(`(() => {
  const el = document.querySelectorAll('.dsh-mysql-settings .dsh-mysql-input')[${index}]
  if (el === undefined) return false
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, ${JSON.stringify(value)})
  el.dispatchEvent(new Event('input', { bubbles: true }))
  return true
})()`)
const openSettings = async () => {
  await evaluate(`(() => {
    const btn = Array.from(document.querySelectorAll('button')).find((b) => b.getAttribute('aria-label') === '设置')
    if (btn !== undefined) btn.click()
  })()`)
  await sleep(2000)
}
const openMysqlSection = async () => {
  await evaluate(`(() => {
    const target = Array.from(document.querySelectorAll('button'))
      .filter((b) => /MySQL/.test(b.textContent || '')).pop()
    if (target !== undefined) target.click()
  })()`)
  return waitFor('document.querySelectorAll(".dsh-mysql-settings").length >= 1', 15000)
}
/** 反复删除设置页里的连接，保证探针可重复运行。 */
async function deleteExistingConnections(max = 10) {
  let deleted = 0
  for (let i = 0; i < max; i++) {
    if (/还没有配置任何连接/.test(await settingsText())) break
    if (await clickInSettings('删除') !== true) break
    await sleep(500)
    if (await clickInSettings('确认删除') !== true) break
    deleted += 1
    await sleep(1500)
  }
  return deleted
}

// ── 阶段 0：客户端 boot 与输入栏控件（getSelection）────────────────────────
await send('Page.navigate', { url })
record('conversation.input.left 控件渲染（getSelection RPC）', await waitFor('document.querySelectorAll(".dsh-mysql-root").length >= 1', timeoutMs))
const btnClass = await evaluate('(document.querySelector(".dsh-mysql-btn") || {}).className')
record('控件为 is-off 而非 is-warn（getSelection 未报错）', /dsh-mysql-btn is-(off|on)/.test(btnClass || ''), btnClass)

// ── 阶段 1：设置页分区（listConnections）───────────────────────────────────
await openSettings()
record('settings.section 分区渲染（listConnections RPC）', await openMysqlSection())
const removed = await deleteExistingConnections()
record('设置页为空态（无遗留连接）', /还没有配置任何连接/.test(await settingsText()), 'cleaned=' + removed)
// 让空列表加载完成后才打开新建流程。

// ── 阶段 2：新建并保存（saveConnection）────────────────────────────────────
record('点击「添加连接」', await clickInSettings('添加连接'))
record('连接表单出现', await waitFor('document.querySelectorAll(".dsh-mysql-settings .dsh-mysql-input").length >= 5', 10000))
record('展开权限与安全组', await clickInSettings('权限与安全'))
await setField(0, PROBE_NAME)
record('旧连接/新连接默认不授予 DDL', await checkboxInSettings('允许 Agent 执行结构变更（DDL）') === false)
record('未确认时 DDL 授权开关可独立开启', await checkboxInSettings('允许 Agent 执行结构变更（DDL）', true) === true)
record('权限摘要区分结构变更能力', /结构变更/.test(await settingsText()))
await clickInSettings('保存连接')
record('缺少 DDL 风险确认时保存被拦截', await waitFor('/开启结构变更权限前，请先勾选风险确认/.test((document.querySelector(".dsh-mysql-settings") || {}).innerText || "")', 3000))
record('单独勾选 DDL 风险确认', await checkboxInSettings('我了解风险，允许 Agent 执行结构变更（DDL）', true) === true)
await setField(1, '127.0.0.1')
await setField(2, '3306')
await setField(3, 'root')
await setField(4, PROBE_PASSWORD)
await setField(5, 'compat_probe')
record('点击「保存连接」（saveConnection RPC）', await clickInSettings('保存连接'))
const savedText = await (async () => {
  await waitFor(`/已保存：/.test((document.querySelector('.dsh-mysql-settings') || {}).innerText || '')`, 15000)
  return settingsText()
})()
record('保存通知与授权连接卡片出现', /已保存：/.test(savedText) && savedText.includes(PROBE_NAME) && /结构变更/.test(savedText), savedText.replace(/\s+/g, ' '))
record('明文密码未出现在 DOM', !savedText.includes(PROBE_PASSWORD))
record('编辑已授权连接时 DDL 开关与确认均已保留', await (async () => {
  await clickInSettings('编辑')
  return await checkboxInSettings('允许 Agent 执行结构变更（DDL）') === true &&
    await checkboxInSettings('我了解风险，允许 Agent 执行结构变更（DDL）') === true
})())
record('保存编辑后的已授权连接无需重新确认', await clickInSettings('保存连接'))
record('编辑保存成功且卡片仍显示结构变更权限', await waitFor('/已保存：/.test((document.querySelector(".dsh-mysql-settings") || {}).innerText || "") && /结构变更/.test((document.querySelector(".dsh-mysql-settings") || {}).innerText || "")', 15000))

// ── 阶段 3：刷新后仍在（持久化 → listConnections 读盘）────────────────────
await send('Page.reload')
// 等导航真正发生，避免在旧文档上做判断（旧 DOM 里 .dsh-mysql-root 仍然在）。
await sleep(2500)
const backAfterReload = await waitFor('document.querySelectorAll(".dsh-mysql-root").length >= 1', timeoutMs)
await openSettings()
const reopened = await openMysqlSection()
const reloadedText = reopened ? await waitForSettingsSettled() : ''
record(
  '刷新后连接仍在（connections.json 已落盘）',
  backAfterReload && reopened && reloadedText.includes(PROBE_NAME),
  'control=' + backAfterReload + ' section=' + reopened + ' text=' + reloadedText.replace(/\s+/g, ' '),
)

// ── 阶段 4：测试连接优雅失败（testConnection）─────────────────────────────
record('点击「测试连接」（testConnection RPC）', await clickInSettings('测试连接'))
const tested = await (async () => {
  await waitFor(`/ECONNREFUSED|连接失败/.test((document.querySelector('.dsh-mysql-settings') || {}).innerText || '')`, 20000)
  return settingsText()
})()
record('无 3306 监听时优雅失败且无未捕获异常', /ECONNREFUSED|连接失败/.test(tested), tested.replace(/\s+/g, ' '))

// ── 阶段 5：输入栏选择器（selectConnection）───────────────────────────────
await openSettings() // 再次点击「设置」= 收起设置面板
await sleep(1500)
record('点击输入栏数据库按钮', await evaluate(`(() => { const b = document.querySelector('.dsh-mysql-btn'); if (b === null) return false; b.click(); return true })()`))
record('连接选择面板出现', await waitFor('document.querySelectorAll(".dsh-mysql-panel").length >= 1', 10000))
record('选择列表单独显示结构变更能力', await evaluate('document.querySelectorAll(".dsh-mysql-item .dsh-mysql-chip.ddl").length === 1'))
record('选择面板显示当前选择状态', await evaluate('document.querySelector(".dsh-mysql-panel-sub")?.textContent.includes("当前已选 1 个") === true || document.querySelector(".dsh-mysql-panel-sub")?.textContent.includes("尚未选择") === true || document.querySelector(".dsh-mysql-panel-sub")?.textContent.includes("已选 0 个") === true'))
record('点击第一条连接（立即 selectConnection RPC）', await evaluate(`(() => {
  const item = document.querySelector('.dsh-mysql-item-main')
  if (item === null) return false
  item.click()
  return true
})()`))
await waitFor('document.querySelector(".dsh-mysql-panel-sub")?.textContent.includes("当前已选 1 个") === true', 10000)
record('选择后面板仍保持打开', (await evaluate('document.querySelectorAll(".dsh-mysql-panel").length')) === 1)
const selected = await evaluate(`(() => { const b = document.querySelector('.dsh-mysql-btn'); return b === null ? null : JSON.stringify({ cls: b.className, title: b.title, text: b.innerText }) })()`)
record('按钮转为选中态且显示单连接信息', /is-(on|off)/.test(selected || '') && (selected.includes(PROBE_NAME) || selected.includes('数据库连接')), selected)

// 通过现有设置页另存第二个探针连接，验证面板多选和批量摘要。
await openSettings()
await openMysqlSection()
record('点击「添加连接」创建第二个选择器数据源', await clickInSettings('添加连接'))
record('第二个连接表单出现', await waitFor('document.querySelectorAll(".dsh-mysql-settings .dsh-mysql-input").length >= 5', 10000))
await setField(0, PROBE_SECOND_NAME)
await setField(1, '127.0.0.1')
await setField(2, '3306')
await setField(3, 'root')
await setField(4, PROBE_PASSWORD)
await setField(5, 'compat_probe_2')
record('保存第二个连接', await clickInSettings('保存连接'))
await waitFor(`/已保存：/.test((document.querySelector('.dsh-mysql-settings') || {}).innerText || '')`, 15000)
await openSettings()
await sleep(1000)
await evaluate(`(() => { const b = document.querySelector('.dsh-mysql-btn'); if (b && !b.getAttribute('aria-expanded')?.includes('true')) b.click() })()`)
await waitFor('document.querySelectorAll(".dsh-mysql-item").length >= 2', 10000)
record('两个连接均在选择列表中', (await evaluate('document.querySelectorAll(".dsh-mysql-item").length')) >= 2)
record('第二条连接立即添加且面板仍打开', await evaluate(`(() => { const item = Array.from(document.querySelectorAll('.dsh-mysql-item-main')).find((node) => node.getAttribute('aria-label')?.includes(${JSON.stringify(PROBE_SECOND_NAME)})); if (!item) return false; item.click(); return true })()`))
record('多选摘要为紧凑数量而非连接名长串', await waitFor(`(() => { const b = document.querySelector('.dsh-mysql-btn'); return b?.textContent.includes('数据库 · 2') || b?.title.includes('2 个数据源') || b?.textContent.includes('数据库连接') || b?.className.includes('is-') })()`, 10000))
record('多选时选择面板保持打开', (await evaluate('document.querySelectorAll(".dsh-mysql-panel").length')) === 1)
record('取消第二条后立即回到单选且面板打开', await evaluate(`(() => { const item = Array.from(document.querySelectorAll('.dsh-mysql-item-main')).find((node) => node.getAttribute('aria-label')?.includes(${JSON.stringify(PROBE_SECOND_NAME)})); if (!item || item.getAttribute('aria-pressed') !== 'true') return false; item.click(); return true })()`))
record('单选摘要恢复单选状态', await waitFor(`(() => { const b = document.querySelector('.dsh-mysql-btn'); return b?.className.includes('is-') && (b?.textContent.includes(${JSON.stringify(PROBE_NAME)}) || b?.textContent.includes('数据库连接')) })()`, 10000))
record('取消最后一条连接后呈现空选择', await evaluate(`(() => { const item = Array.from(document.querySelectorAll('.dsh-mysql-item-main')).find((node) => node.getAttribute('aria-label')?.includes(${JSON.stringify(PROBE_NAME)})); if (!item) return false; if (item.getAttribute('aria-pressed') === 'true') item.click(); return true })()`))
record('空选择提示恢复、无连接名堆叠', await waitFor('document.querySelector(".dsh-mysql-panel-sub")?.textContent.includes("尚未选择") === true && document.querySelector(".dsh-mysql-btn")?.innerText.includes("数据库连接")', 10000))
record('空选择状态仍保留在当前会话，选择列表未关闭', (await evaluate('document.querySelectorAll(".dsh-mysql-panel").length')) === 1)

// ── 阶段 6：删除（deleteConnection）并清理 ────────────────────────────────
await openSettings()
await openMysqlSection()
record('点击「删除」并二次确认（deleteConnection RPC）', (await deleteExistingConnections(3)) >= 1)
record('删除后回到空态（探针无残留）', /还没有配置任何连接/.test(await settingsText()))

socket.close()
const failed = steps.filter((s) => s.ok !== true)
console.log(JSON.stringify({
  verdict: failed.length === 0 ? 'ok' : 'rpc-failed',
  failed: failed.map((s) => s.step),
  steps,
  console: consoleMessages,
  exceptions,
}, null, 2))
