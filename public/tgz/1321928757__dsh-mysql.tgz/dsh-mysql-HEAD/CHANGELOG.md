# Changelog

## v0.3.3

- 修复连接选择面板「透字」：面板背景用的是 DSH 菜单材质（`--dsw-menu-surface-fill`，浅色 α 0.58 / 深色 α 0.45），而材质必须与 `--dsw-menu-backdrop-filter`（`blur(40px) saturate(150%)`）成对使用。此前只取了填充、没取模糊，于是面板变成一块无模糊的半透明板，对话正文原样透出。现两者均通过 `--dm-panel-fill` / `--dm-panel-blur` 收口，换回实体面板只需改这两行。
- 粘性页眉/页脚不再 `background: inherit`（继承的是半透明值），改用 `--dsw-alias-menu-group-header-fill`（α 0.94）并叠同款模糊，滚动时行内容不再从页眉/页脚下方透出；两者补 `z-index: 1`，避免后置的行元素画在页眉之上。
- 面板边缘改用 `--dsw-elevation-prominent`（0.5px 描边 + 柔和投影）替代 `1px border-l1` + `--dsw-shadow-lv3`；圆角对齐 DSH 半径刻度（16px）。新增 `@supports` 降级：渲染器不支持背景模糊、或宿主没有材质 token 时自动退回不透明面板，不会停在「无模糊半透明」状态。
- 修复搜索框与设置页输入框「只有边框、没有底色」：`--dsw-alias-bg-input` 在 DSH 0.2.1 中已不存在（整包扫描 0 命中），所有 `var(--dsw-alias-bg-input, transparent)` 都静默退化为透明。选择面板的搜索框改用 6% `label-primary` 混合色（浅色偏暗、深色偏亮），并对无 `color-mix` 能力的环境回退到 `--dsw-alias-bg-module-platform`。
- 行状态重排：去掉常驻的测试状态行（成功/失败改由右侧操作列的图标 + `title`/`aria-label` 承载，仅失败时在行内补一行原因），行高从约 99px 降到 70.8px，同样高度能多显示 2~3 个连接；hover 与选中态分别使用 `--dsw-alias-interactive-bg-hover` / `-active`，选中仍由左侧对勾与「已选择」角标承担。
- 标签（只读/可写/结构变更/全部表/表名）对齐 DSH 官方 tag 量纲：11px / 17px 行高 / `1px 8px` 内边距 / 字重 500 / 有底色不描边 / `corner-shape: round`；默认态（只读、全部表）降为纯文字，只有异常能力（可写、结构变更）带底色，结构变更由墨色改为业务蓝，避免与「已选择」角标和主按钮混淆。表名单行容量 4 → 3，溢出的 `+N 表` 悬停可看完整列表。
- 面板高度按触发器上方实测空间钳制（打开与窗口 resize 时重算），窗口偏矮时不再顶出视口。
- 新增 `docs/dsh-menu-surface-guide.md`：DSH 插件弹层「透字」的成因、两种修法、可直接粘贴的审计脚本（已在夹具上验证）与验收清单，供其它存在同类问题的插件参考。

## v0.3.2

- 修复 Gemini 等原生 FunctionDeclaration 严格校验下的调用失败：`mysql_query`、`mysql_execute`、`mysql_ddl` 的 `params` 原来是 `{ type: 'array' }`，缺少 `items`，整个 `GenerateContentRequest` 会被服务端以 HTTP 400 拒绝（`items: {}` 同样无效）。现统一声明为 `items: { type: 'string' }`，位置参数本就是字符串数组。
- 三处 `params` 抽成 `lib/index.js` 中的共享常量 `SQL_PARAMS_SCHEMA`，避免三份声明各自漂移；其余 schema 字段（`connectionId`/`sql`/`table` 声明、`required: ['sql']`、`additionalProperties`、`output`、`timeoutMs`）与执行路径均未改动，`params` 仍为可选参数。
- `test/host-tools.test.mjs` 新增递归不变量测试：遍历所有已注册工具的 schema，任何 `type: 'array'` 节点都必须带有声明了 `type` 的 `items`，失败时打印具体 schema 路径；测试按实际注册的 schema 驱动，新增数组参数会自动纳入覆盖。

## v0.3.1

- 新增会话级多数据源选择：每个会话可选择零个、一个或多个数据源；多选时每次工具调用必须明确指定一个 `connectionId`，不会广播或合并结果。
- `mysql_query`、`mysql_tables`、`mysql_execute`、`mysql_ddl` 均按目标数据源独立执行并保留各自的连接池、表白名单、默认库、写权限与 DDL 权限。
- 选择器支持即时增删、取消最后一个数据源、紧凑的多选数量摘要和可访问的选中状态；补充 Host/Client 测试、隔离 DSH 验收脚本与中英文使用说明。

## v0.3.0

- 新增每连接独立、默认关闭的 `allowDdl` 授权与单独风险确认；通过专用 `mysql_ddl` 工具执行受限的表/视图/索引结构变更。表白名单约束改动/删除目标，跨库目标（包括 ALTER RENAME 新目标及 CREATE ... AS SELECT 来源表）、账号/权限语句、库级 DDL 与多语句拒绝；DDL 使用文本协议执行。
- 设置页连接卡片、权限摘要、输入栏连接状态和运行时上下文区分行写与结构变更能力；更新中英文 README、建表示例与隔离 Host 冒烟断言。
- 修复 `mysql_tables` 在驱动返回大写 information_schema 字段标签时将表名/列名错误序列化为字面量 `undefined` 的问题；现在不区分字段标签大小写，并对必需元数据缺失 fail closed。

## v0.2.0

- **BREAKING：适配 DSH 0.2.0-rc.2 的 Typert 契约。** Host 与 Client 两侧的 strict RPC codec 都改为运行时要求的 `create()` factory 形状（旧形状只带 `schema` 字段，会被 `typert: ... strict codec has no create() factory` 拒绝），修复桌面端启动报 `web boot: 1 entry did not activate / dsh-mysql: failed`、`mysql` 服务无法注册的问题。
- 声明兼容范围：`engines.dsh = ">=0.2.0-rc.2 <0.3.0"`、`node >= 20`，`@deepseek-ai/cordis` peer 收紧到 `~4.0.4`；本版本不再支持 DSH 0.1.x（该环境请继续使用 0.1.11）。
- 新增 Typert 契约测试：`test/typert.test.mjs` 校验 Host 清单（7 方法、`create()` factory、reflection 身份、无残留 `schema` 字段），`test/client-typert.test.mjs` 在受控环境里物化 `lib/client.js` 并按真实 0.2 校验规则驱动 `apply()`，含「旧的 schema-only 形态必须被拒绝」的回归护栏。
- 新增隔离验收脚本：`scripts/dsh02-headless-smoke.ps1`（一次性 profile 的 Host/loader/工具注册冒烟，不依赖 LLM 与网络）与 `scripts/dsh02-web-smoke.ps1` + `scripts/web-boot-probe.mjs`（一次性 profile/端口 + 真实无头浏览器，验证 boot 图含 `dsh-mysql`、无失败遮罩、输入栏连接控件真的渲染）。两者都绝不重启或修改既有的 3080 实例。
- 新增 `scripts/web-rpc-probe.mjs`（可用 `scripts/dsh02-web-smoke.ps1 -RpcProbe` 启用）：用真实 UI 逐个打通 UI 上可见的 6 个 RPC 方法，并校验明文密码不落 DOM、刷新后连接仍在（已落盘）、探针结束后自行清理。
- 修复报错文案退化：MySQL（或前置代理）返回 message 为空的错误包时，此前只会显示「查询失败：Error」/「Unknown error 1146」，把 `ER_PARSE_ERROR 1064`、`ER_NO_SUCH_TABLE 42S02` 这类关键线索丢掉了。现在 `mysql_query` / `mysql_tables` / `mysql_execute` / 测试连接 / 表列表 / 连接保存删除统一走 `describeDbError()`：message 信息量为零（空串或 `Unknown error <errno>`）时补上 `code` / `errno` / `sqlState`，而完整可读的报错（ECONNREFUSED、ENOENT、真实 MySQL 错误描述）保持原样、不追加噪音。

## v0.1.11

- 对齐 DSH Web 输入栏与设置页的交互样式，收敛按钮层级、悬浮态、展开态和焦点态。
- 更新真实界面截图，统一使用 ASCII 文件名，并同步 README 与 `screenshots.json`。

## v0.1.10

- 修复 `mysql_query` 返回日期/时间字段的时区偏移：连接池启用 `dateStrings: true`，原样返回 MySQL 的日期/时间字符串，不再按本机时区转 `Date` 后再 `toISOString()` 成 UTC。

## v0.1.9

- 已连接按钮更轻量：去掉选中态边框，背景改为极浅品牌色（8% 透明度，无 mix 支持时透明），连接状态只靠绿点、▾ 与品牌蓝图标表达；hover 时仅显示浅色底、不再出现边框。

## v0.1.8

- 输入栏已选连接按钮不再显示「数据库 ·」前缀，只显示连接名，最多 6 个字符、超出以省略号截断（完整名称保留在 tooltip），按钮 `max-width` 收紧到 160px，避免长连接名撑爆输入栏按钮行导致换行；
- 连接选择面板选中态简化：去掉左侧蓝色强调条与品牌色浅蓝高亮，选中与 hover 统一为浅灰底 + 常规细边框，贴合官方菜单样式。

## v0.1.7

- 强调色与 dsh 官方主题完全对齐：按钮/选中态/标签/链接的着色由「品牌蓝 + 38% 青色混合」改为**纯官方品牌蓝**（`--dsw-alias-brand-primary`），设置页「保存连接」「添加连接」「测试连接」等按钮不再是墨绿色；
- 绿色仅保留给数据库连接状态（输入栏绿点、连接正常/测试成功文案与图标），红色仅用于错误与删除，橙色仅用于写权限警示。

## v0.1.6

- 输入栏按钮对齐 dsh 官方浅色风格：已连接态由深色渐变胶囊改为「浅蓝灰底 + 品牌色低透明边框 + 深色文字 + 绿色状态点 + ▾」，异常态改浅红底红字；`min-width` 稳定按钮宽度，长连接名省略号 + tooltip；切换中按钮内 spinner 并禁用（不再弹气泡遮挡输入区）；
- 切换/操作反馈改为右下角固定 toast（图标 + 文字三态，2s 自动消失，不遮挡输入内容）；
- 连接选择面板：搜索框统一 32px；连接卡片重构为「可点击主区 + 独立操作列」，测试状态行常驻（测试中 spinner / 成功绿勾+延迟 / 失败红警示+原因+可重试），卡片高度不再跳动；名称溢出省略 + tooltip；方向键/Home/End 键盘导航；圆角统一 12px；
- 设置页：权限/表范围 badge 紧跟连接名，状态药丸靠右；卡片内边距统一 16px、圆角 12px；「添加连接」改浅色次级按钮（页面仅保留「保存连接」一个主按钮）；「测试连接」按钮文案恒定、测试时前置 spinner；消息条可手动关闭、成功类 5s 自动消失；
- 新增连接表单：权限与安全组可折叠（标题行显示「只读 / 读写·已确认」摘要，勾选读写自动展开），表单打开时内容底部留白，粘性操作栏不再遮挡最后字段；取消 / 放弃未保存修改时弹窗确认；
- 设计 token 统一：圆角 8/12/16 刻度、新增 accent 低透明边框与 danger 浅底令牌，全部沿用 `--dsw-*` 主题变量，亮/暗主题均可工作。

## v0.1.5

- 输入栏按钮三态（未连接灰 / 已连接品牌色 / 异常红），显示「数据库 · 连接名」，🐬 emoji 换成数据库 SVG 图标，切换成功有瞬态气泡反馈；
- 连接选择面板升级：宽度 400px、选中项左侧蓝条 + 「当前使用」徽标、连接数 ≥3 时显示搜索、每连接卡片支持内联测试（失败原因展示在卡片内）、tab 改为「只读/可写/全部表」标签、"管理数据库连接"入口；
- 设置页卡片两列层级：连接状态药丸（● 连接正常/异常 · X 秒前测试，Host 内存态 lastTest）+ 测试连接（主）/ 编辑（次）/ 删除（文字按钮，二次确认）按钮层级；
- 新增连接表单按「基本信息 / 数据库范围 / 权限与安全」三组分区：主机/端口与用户名/密码两列布局、密码显示/隐藏、访问模式单选（只读推荐 / 读写需风险提示 + 二次确认勾选）、表白名单改为标签式输入（表访问范围单选），底部固定操作栏（保存连接 / 测试连接 / 取消）；
- 术语统一：全部表（未限制）→ 全部表、已存密码 → 密码已保存、新建连接 → 添加数据库连接、测试 → 测试连接 等；--dm-warn 区分警示橙（写权限）与危险红（删除/错误）。

## v0.1.4

- 连接上下文改为 `systemPrompt.context`（对话尾部的动态运行时快照），切换连接 / 编辑连接不再让该会话的上下文前缀缓存失效；
- 精简三个工具的 description，模型调用更稳。

## v0.1.3

- 连接保存后所有读取路径立即生效（`ensureLoaded` 返回实时快照，不再读到启动时的旧快照）；
- 写盘失败内存回滚，与磁盘保持一致；启动诊断日志增强。

## v0.1.2

- 修复设置页首次渲染崩溃（connections 为 null 时无条件 map）。

## v0.1.1

- 补全 Typert model 块（loader 强制校验，缺失会导致整个 typert-loader 行激活失败）；
- 输入栏按钮紧凑布局；设置页加载失败提示；Host 启动诊断日志（boot.log）。

## v0.1.0

- 首个发布：设置页连接管理（增删改 / 测试 / 表白名单 / 写权限）、会话级连接切换（输入栏 🐬 按钮）、全局 `mysql_query` / `mysql_tables` / `mysql_execute` 工具。