# S7R — System 7 Reimagined for DeepSeek Harness

[![CI](https://github.com/hunter118/dsh-s7r/actions/workflows/ci.yml/badge.svg)](https://github.com/hunter118/dsh-s7r/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/hunter118/dsh-s7r)](https://github.com/hunter118/dsh-s7r/releases/latest)
[![License: MIT](https://img.shields.io/badge/license-MIT-black.svg)](./LICENSE)
[![DSH: 0.1.7-rc.2](https://img.shields.io/badge/DSH-0.1.7--rc.2-666.svg)](./COMPATIBILITY.md)

S7R is an original retro macOS/System 7-style workstation shell for the [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) Web UI. It turns real DSH Agents, Workspaces, files, terminals, tools, jobs, and persisted history into a coherent multi-window desktop instead of placing a visual skin over a chat page.

**S7R** is the desktop environment. **Knowledge Desk** is its Workspace, Agent, and conversation application.

![An Expanded S7R desktop with Knowledge Desk naturally overlapping an Agent, Finder, Monitor, and Clock](./docs/screenshots/s7r-desktop.png)

*Expanded 1024 × 768 at native 1× magnification. Knowledge Desk, an active Agent, Finder, Monitor, Clock, desktop aliases, and Trash share one persistent desktop.*

DSH remains the source of truth. S7R does not duplicate conversations into a private chat database, start an unrelated shell server, or expose arbitrary host paths. It adds a desktop, applications, and browser-local presentation preferences around DSH's public services.

> [!IMPORTANT]
> S7R 0.10 targets DeepSeek Harness `0.1.7-rc.2`. Older S7R 0.9.x releases are the appropriate line for older DSH installations. Read [DSH compatibility](./COMPATIBILITY.md) before mixing release lines.

## Start here

Requirements: Node.js `22.19+` or `24+`, DeepSeek Harness `0.1.7-rc.2`, and pnpm for profile management or source development.

1. Download `dsh-s7r-0.10.0.tgz` and `SHA256SUMS` from the [latest release](https://github.com/hunter118/dsh-s7r/releases/latest).
2. Install the plugin into the DSH Web profile:

   ```sh
   dsh plugin --profile web add ./dsh-s7r-0.10.0.tgz
   dsh --profile web --dump-config
   dsh web
   ```

3. Open the loopback URL printed by DSH, normally `http://127.0.0.1:3080`.
4. In S7R, open **S7R → Settings…** to configure `DEEPSEEK_API_KEY` when DSH does not already receive it from its launch environment.
5. Choose **File → Choose Folder…**, then create an Agent in that Workspace.

For checksum verification, source installation, upgrades, removal, and the complete first-run tour, use the [Getting started guide](./docs/getting-started.md).

## What S7R includes

| Area | Highlights | Documentation |
| --- | --- | --- |
| **Knowledge Desk** | Explicit current Workspace; Agent search, scope and status filters; recency/name/status sorting; rename, export, archive, restore, and desktop placement. | [Workspaces and Agents](./docs/workspaces-and-agents.md) |
| **Agent windows** | Real DSH streaming and history, steering/cancellation, safe completed-output Markdown, context pressure and composition, compaction, summary handoff, and a folded full-event Timeline. | [Workspaces and Agents](./docs/workspaces-and-agents.md) |
| **Native DSH controls** | Agent Presets, provider models and reasoning effort, slash-command modes, project Skills, plugin-loader inventory, credentials, Jobs, and native archive state. | [DSH integration](./docs/dsh-integration.md) |
| **Stationery and setup** | A fixed New Agent setup window for Preset/model/reasoning plus a deliberately small DSH Agent Preset Stationery Pad with optional name and opening prompt. | [Workspaces and Agents](./docs/workspaces-and-agents.md) |
| **Files and terminal** | Workspace-contained Finder, conflict-aware TextEdit, local PDF/image Preview, portable path drops, and an owner-scoped `/bin/zsh -f -i` line console. | [Files, Terminal, and Find](./docs/files-terminal-and-search.md) |
| **Global Find** | Independent scopes for names, source contents, visible conversation messages, or every persisted Agent event, across one or all Workspaces/Agents. | [Files, Terminal, and Find](./docs/files-terminal-and-search.md) |
| **Desktop** | Restored windows and z-order, aliases, marquee selection, group dragging, context menus, Get Info, reversible alias-only Trash, tiling, and minimal completion notices. | [Desktop and applications](./docs/desktop-and-apps.md) |
| **Monitor and accessories** | Agent/context state, DSH background Jobs, host CPU and active RAM, process RSS, Scrapbook, Clock, and an always-solvable Puzzle. | [Desktop and applications](./docs/desktop-and-apps.md) |
| **Display** | Fit Browser or period-style work areas, native 10px/12px bitmap masters, exact 1×/2× magnification, monochrome/muted color, Preview filters, and pixel-processed wallpaper. | [Display and wallpaper](./docs/display-and-wallpaper.md) |
| **Help and accessibility** | Keyboard-navigable menus, S7R-owned text/context menus, optional edge-aware Balloon Help, visible focus, and no advertised browser-owned shortcuts that cannot work reliably. | [Reference](./docs/reference.md) |

## Documentation

The complete manual is split into linked guides so each workflow has one maintained home.

- **[Documentation index](./docs/README.md)** — choose a guide by task or audience.
- **[Getting started](./docs/getting-started.md)** — install, first run, upgrade, and remove.
- **[Workspaces and Agents](./docs/workspaces-and-agents.md)** — Knowledge Desk, lifecycle, streaming, Context, Timeline, export, and Stationery.
- **[Files, Terminal, and Find](./docs/files-terminal-and-search.md)** — Finder, TextEdit, Preview, zsh, path drops, and search scopes.
- **[Desktop and applications](./docs/desktop-and-apps.md)** — windows, aliases, menus, Trash, Monitor, Scrapbook, and desk accessories.
- **[Display and wallpaper](./docs/display-and-wallpaper.md)** — resolution, fonts, magnification, appearance, filters, and imports.
- **[DSH integration](./docs/dsh-integration.md)** — Control Center, authoritative ownership, services, credentials, and compatibility boundaries.
- **[Reference](./docs/reference.md)** — menu map, persistence, limits, security, and data ownership.
- **[Troubleshooting](./docs/troubleshooting.md)** — command, installation, credential, Workspace, Terminal, display, and reset problems.

Technical and project documentation:

- [Architecture](./ARCHITECTURE.md)
- [Compatibility notes](./COMPATIBILITY.md)
- [Product and design specification](./docs/design-spec.md)
- [Development notes](./docs/development-notes.md)
- [Changelog](./CHANGELOG.md)
- [Contributing and documentation maintenance](./CONTRIBUTING.md)
- [Security policy](./SECURITY.md)

## Install from source

```sh
git clone https://github.com/hunter118/dsh-s7r.git
cd dsh-s7r
corepack enable
pnpm install --frozen-lockfile
pnpm check
dsh plugin --profile web add .
dsh web
```

`pnpm check` validates documentation links, performs strict host/client type checks, runs the deterministic test suite, and builds the production host/client bundles. See [Contributing](./CONTRIBUTING.md) for the repository map, browser verification loop, and the required documentation update matrix.

## Compatibility and limitations

This release targets the official DSH `0.1.7-rc.2` package graph, verified 2026-09-29. The 0.10 line uses DSH's controller, Chat projection, typed Remote, Jobs, scoped persistence, and native archive APIs; the removed `dsh-client-runtime` is not required.

Important boundaries:

- DSH's terminal service is line-oriented and does not publish raw browser PTY bytes or post-spawn PTY resizing.
- TextEdit is a conflict-aware plain-text/code editor, not an IDE or language server.
- Preview rasterizes PDFs but does not provide a selectable PDF text layer.
- DSH's plugin inventory is read-only; profile plugin enable/disable remains a DSH CLI operation.
- S7R replaces the root Web UI slot intentionally; it does not mix the native DSH UI into the simulated desktop.

See [Compatibility notes](./COMPATIBILITY.md) and [Troubleshooting](./docs/troubleshooting.md) for details.

## License and provenance

S7R is MIT licensed. It is an independent project and is not affiliated with or endorsed by Apple Inc. or DeepSeek. No Apple artwork, system files, proprietary fonts, sounds, screenshots, or extracted resources are bundled.

The browser bundle includes Fusion Pixel Font faces under SIL OFL 1.1 and PDF.js under Apache-2.0. Notices and license texts are in [THIRD_PARTY_NOTICES.md](./THIRD_PARTY_NOTICES.md) and [`THIRD_PARTY_LICENSES/`](./THIRD_PARTY_LICENSES/).
