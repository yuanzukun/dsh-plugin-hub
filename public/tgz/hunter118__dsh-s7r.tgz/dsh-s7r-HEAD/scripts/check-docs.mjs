import { access, readdir, readFile } from 'node:fs/promises'
import path from 'node:path'

const repositoryRoot = process.cwd()
const excludedDirectories = new Set(['.git', 'node_modules', 'lib', 'coverage', 'release-artifacts'])

async function markdownFiles(directory) {
  const entries = await readdir(directory, { withFileTypes: true })
  const files = []
  for (const entry of entries) {
    if (entry.isDirectory() && excludedDirectories.has(entry.name)) continue
    const absolute = path.join(directory, entry.name)
    if (entry.isDirectory()) files.push(...await markdownFiles(absolute))
    else if (entry.isFile() && entry.name.endsWith('.md')) files.push(absolute)
  }
  return files
}

function localTarget(raw) {
  const trimmed = raw.trim()
  const target = trimmed.startsWith('<') && trimmed.includes('>')
    ? trimmed.slice(1, trimmed.indexOf('>'))
    : trimmed.split(/\s+(?=["'])/, 1)[0]
  if (target === undefined || target === '' || target.startsWith('#')) return null
  if (/^[a-z][a-z\d+.-]*:/i.test(target) || target.startsWith('//')) return null
  const withoutFragment = target.split('#', 1)[0]?.split('?', 1)[0]
  if (withoutFragment === undefined || withoutFragment === '') return null
  try { return decodeURIComponent(withoutFragment) } catch { return withoutFragment }
}

const files = await markdownFiles(repositoryRoot)
const failures = []
const markdownLink = /!?\[[^\]]*\]\(([^)]+)\)/g

for (const file of files) {
  const text = await readFile(file, 'utf8')
  for (const match of text.matchAll(markdownLink)) {
    const target = localTarget(match[1])
    if (target === null) continue
    const resolved = path.resolve(path.dirname(file), target)
    try {
      await access(resolved)
    } catch {
      failures.push(`${path.relative(repositoryRoot, file)}: missing target ${target}`)
    }
  }
}

const docsIndexPath = path.join(repositoryRoot, 'docs', 'README.md')
const docsIndex = await readFile(docsIndexPath, 'utf8')
const docsPages = (await readdir(path.join(repositoryRoot, 'docs'), { withFileTypes: true }))
  .filter(entry => entry.isFile() && entry.name.endsWith('.md') && entry.name !== 'README.md')
  .map(entry => entry.name)

for (const page of docsPages) {
  if (!docsIndex.includes(`./${page}`)) failures.push(`docs/README.md: does not index ./${page}`)
}

const projectReadme = await readFile(path.join(repositoryRoot, 'README.md'), 'utf8')
if (!projectReadme.includes('./docs/README.md')) failures.push('README.md: does not link to ./docs/README.md')

if (failures.length > 0) {
  console.error(`Documentation validation failed (${failures.length}):`)
  for (const failure of failures) console.error(`- ${failure}`)
  process.exitCode = 1
} else {
  console.log(`Documentation validation passed: ${files.length} Markdown files, ${docsPages.length} indexed docs pages.`)
}
