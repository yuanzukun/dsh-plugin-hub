import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-api-job-controller/client'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type {} from '@deepseek-ai/dsh-api-session-controller/client'
import type {} from '@deepseek-ai/dsh-api-workspace-controller/client'
import type {} from '@deepseek-ai/dsh-client-connection/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-session/client'
import type {} from '@deepseek-ai/dsh-client-ui-workspace/client'
import { DshClientAdapter } from '../dsh-compat/client.ts'
import { DesktopRoot } from '../desktop/Desktop.tsx'
import { installSystem7Styles } from '../system7/styles.ts'

export const inject = [
  'slots', 'sessions', 'workspaces', 'connection', 'remote',
  'remote.session', 'remote.agentPresets', 'remote.skills', 'remote.commands',
  'remote.pluginInventory', 'remote.credentials',
  'uiSession', 'uiWorkspace', 'uiConversation', 'jobs',
]

export function apply(ctx: ClientContext): void {
  const adapter = new DshClientAdapter(ctx)
  ctx.effect(() => installSystem7Styles(), 'knowledge-desk: System 7 stylesheet')
  ctx.effect(() => () => { adapter.dispose() }, 'knowledge-desk: release retained sessions')
  ctx.effect(() => ctx.slots.register({
    name: 'root',
    priority: -100,
    inject: () => ({ adapter }),
  }, DesktopRoot), 'knowledge-desk: root desktop shell')
}
