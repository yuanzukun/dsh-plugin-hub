import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type { IJobs } from '@deepseek-ai/dsh-api-job-controller/client'
import type { ClientRemote, RemoteResult } from '@deepseek-ai/dsh-api-remotes/client'
import type { ISessions, SessionFace, SessionReference, SessionSnapshot } from '@deepseek-ai/dsh-api-session-controller/client'
import type { ModelCatalog, ModelSelection, SkillEntry } from '@deepseek-ai/dsh-api-session-controller/types'
import type { IWorkspaces, WorkspaceId, WorkspaceView } from '@deepseek-ai/dsh-api-workspace-controller/client'
import type { ChatSnapshot, LegacyConversationSlice } from '@deepseek-ai/dsh-client-ui-chat/client'
import type { UiConversation } from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { UiWorkspace } from '@deepseek-ai/dsh-client-ui-workspace/client'
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { SessionId } from '@deepseek-ai/dsh-session/types'
import type { CompatRpcResult, SessionExportView } from './protocol.ts'
import { KNOWLEDGE_DESK_RPC_ROUTE } from './protocol.ts'

declare module '@deepseek-ai/dsh-api-session-controller/client' {
  interface SessionReferenceSourceMap {
    s7r: unknown
  }
}

// api-remotes bundles these standard DSH namespaces at runtime. Their owning
// packages are Host-side implementation details, so keep the small Client
// contract local instead of forcing consumers to install Host packages.
type S7Remote = ClientRemote & {
  credentials: {
    describe(refs: string[]): Promise<RemoteResult<Record<string, CredentialInfoView>>>
    set(ref: string, value: string): Promise<RemoteResult<void>>
    unset(ref: string): Promise<RemoteResult<void>>
  }
  pluginInventory: {
    list(): Promise<RemoteResult<PluginInventorySnapshotView>>
  }
}

export interface ObservableView<T> {
  getSnapshot(): T
  subscribe(listener: () => void): () => void
}

export type ConversationSnapshotView = SessionSnapshot & LegacyConversationSlice

export interface SessionHandle {
  id: string
  face: SessionFace
}

export interface AgentPresetView {
  id: string
  isDefault: boolean
  name?: string
  description?: string
  broken?: string
}

export interface NativeSessionView {
  sessionId: string
  blank: boolean
  running: boolean
  updatedAt: number
  cwd?: string
  agentPreset?: string
}

export interface NativeCommandView {
  name: string
  description: string
  input?: { hint: string; attachments?: boolean }
}

export interface PluginInventoryEntryView {
  entryId: string
  moduleName: string
  enabled: boolean
  fiberPhase: 'pending' | 'loading' | 'active' | 'failed' | 'unloading' | null
}

interface PluginInventorySnapshotView {
  entries: readonly PluginInventoryEntryView[]
}

export interface CredentialInfoView {
  configured: boolean
  source?: string
  writable: boolean
}

export interface JobViewCompat {
  id: string
  kind: string
  label: string
  owner?: string
  status: 'running' | 'stopping' | 'completed' | 'killed' | 'failed'
  progress?: string
  detail?: string
  startedAt: number
  finishedAt?: number
}

export interface JobsSnapshotView {
  rows: Readonly<Record<string, readonly JobViewCompat[]>>
  observed: Readonly<Record<string, unknown>>
}

export interface SessionModelsView extends ModelCatalog {
  current: ModelSelection
}

interface CachedConversationSource extends ObservableView<ConversationSnapshotView> {
  readonly binding: object
}

function remoteError(response: Extract<RemoteResult<unknown>, { ok: false }>): Error & { code: string; details: object } {
  const error = new Error(response.error.message) as Error & { code: string; details: object }
  error.code = response.error.code
  error.details = response.error.details ?? {}
  return error
}

export class DshClientAdapter {
  private readonly connection: ConnectionHandle
  private readonly sessions: ISessions
  private readonly workspaces: IWorkspaces
  private readonly uiWorkspace: UiWorkspace
  private readonly uiConversation: UiConversation
  private readonly jobs: IJobs
  private readonly remote: S7Remote
  private readonly request: typeof fetch
  private readonly references = new Map<string, SessionReference>()
  private readonly conversationSources = new Map<string, CachedConversationSource>()

  constructor(ctx: ClientContext) {
    this.connection = (ctx as ClientContext & { connection: ConnectionHandle }).connection
    this.sessions = ctx.sessions
    this.workspaces = ctx.workspaces
    this.uiWorkspace = ctx.uiWorkspace
    this.uiConversation = ctx.uiConversation
    this.jobs = ctx.jobs
    this.remote = ctx.remote as S7Remote
    this.request = (ctx as ClientContext & { __s7rFetch?: typeof fetch }).__s7rFetch ?? globalThis.fetch.bind(globalThis)
  }

  dispose(): void {
    for (const reference of this.references.values()) reference.release()
    this.references.clear()
    this.conversationSources.clear()
  }

  private unwrapRemote<T>(response: RemoteResult<T>): T {
    if (response.ok) return response.value
    throw remoteError(response)
  }

  async rpc<T>(endpoint: string, payload: Record<string, unknown> = {}): Promise<T> {
    const response = await this.request(KNOWLEDGE_DESK_RPC_ROUTE, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ endpoint, payload }),
    })
    if (!response.ok) throw new Error(`S7R Host request failed with HTTP ${response.status}`)
    const result = await response.json() as CompatRpcResult<T>
    if (!result.ok) {
      const tagged = /^\[([a-z0-9-]+)\]\s*(.*)$/i.exec(result.error.message)
      const error = new Error(tagged?.[2] ?? result.error.message) as Error & { code: string; details: Record<string, unknown> }
      error.code = tagged?.[1] ?? result.error.code
      error.details = result.error.details
      throw error
    }
    return result.value
  }

  private retain(sessionId: string): SessionReference {
    const existing = this.references.get(sessionId)
    if (existing !== undefined) return existing
    const reference = this.sessions.retain(sessionId as SessionId, { source: 's7r' })
    this.references.set(sessionId, reference)
    return reference
  }

  session(sessionId: string): SessionHandle | undefined {
    const binding = this.sessions.binding(sessionId as SessionId)
    return binding === undefined ? undefined : { id: sessionId, face: binding.session }
  }

  conversation(sessionId: string): ObservableView<ConversationSnapshotView> | undefined {
    const binding = this.sessions.binding(sessionId as SessionId)
    if (binding === undefined) return undefined
    const cached = this.conversationSources.get(sessionId)
    if (cached?.binding === binding) return cached
    const face = binding.session
    const chat = this.uiConversation.binding(binding).target('chat')
    let lastSession: SessionSnapshot | undefined
    let lastChat: ChatSnapshot | undefined
    let lastValue: ConversationSnapshotView | undefined
    const source: CachedConversationSource = {
      binding,
      getSnapshot: () => {
        const sessionValue = face.getSnapshot()
        const chatValue = chat.getSnapshot()
        if (lastValue !== undefined && lastSession === sessionValue && lastChat === chatValue) return lastValue
        lastSession = sessionValue
        lastChat = chatValue
        const legacy: LegacyConversationSlice = chatValue?.legacy ?? {
          nodes: [],
          turnTimings: new Map(),
          turnEnds: new Map(),
          partial: null,
          runningCalls: [],
        }
        const next: ConversationSnapshotView = { ...sessionValue, ...legacy }
        lastValue = next
        return next
      },
      subscribe: listener => {
        const stopSession = face.subscribe(listener)
        const stopChat = chat.subscribe(listener)
        return () => { stopChat(); stopSession() }
      },
    }
    this.conversationSources.set(sessionId, source)
    return source
  }

  openSession(sessionId: string): void {
    this.retain(sessionId)
    this.uiWorkspace.openSession(sessionId as SessionId)
  }

  async prepareSession(sessionId: string): Promise<void> {
    const reference = this.retain(sessionId)
    await reference.ready
  }

  async newSession(cwd?: string): Promise<string> {
    const sessionId = await this.sessions.create(cwd === undefined ? {} : { cwd })
    this.openSession(String(sessionId))
    return String(sessionId)
  }

  async newSessionFromPreset(input: { workspaceId?: string; cwd?: string; agentPreset: string }): Promise<{ sessionId: string; agentPreset?: string }> {
    const value = this.unwrapRemote(await this.remote.session.create({
      ...(input.workspaceId === undefined ? {} : { workspaceId: input.workspaceId as WorkspaceId }),
      ...(input.workspaceId !== undefined || input.cwd === undefined ? {} : { cwd: input.cwd }),
      agentPreset: input.agentPreset,
    }))
    this.openSession(String(value.sessionId))
    return { sessionId: String(value.sessionId), ...(value.agentPreset === undefined ? {} : { agentPreset: value.agentPreset }) }
  }

  async listAgentPresets(): Promise<AgentPresetView[]> {
    const value = this.unwrapRemote(await this.remote.agentPresets.list())
    return value.presets.map(preset => ({
      id: preset.id,
      isDefault: preset.isDefault,
      ...(preset.name === undefined ? {} : { name: preset.name }),
      ...(preset.description === undefined ? {} : { description: preset.description }),
      ...(preset.broken === undefined ? {} : { broken: preset.broken }),
    }))
  }

  async listNativeSessions(): Promise<NativeSessionView[]> {
    const value = this.unwrapRemote(await this.remote.session.list({}))
    return value.items.map(item => {
      const agentPreset = item.projections?.values.agentPreset
      return {
        sessionId: String(item.sessionId), blank: item.blank, running: item.running, updatedAt: item.updatedAt,
        ...(item.cwd === undefined ? {} : { cwd: item.cwd }),
        ...(typeof agentPreset === 'string' ? { agentPreset } : {}),
      }
    })
  }

  async selectAgentPreset(sessionId: string, agentPreset: string): Promise<string> {
    return this.unwrapRemote(await this.remote.agentPresets.select(sessionId as SessionId, agentPreset))
  }

  async sessionModels(sessionId: string): Promise<SessionModelsView> {
    await this.sessions.refreshProjections(sessionId as SessionId)
    const catalog = this.unwrapRemote(await this.remote.session.modelCatalog())
    const current = this.sessions.list.getSnapshot().byId[sessionId as SessionId]?.projectionValues?.modelSelection?.next ?? catalog.default
    return { ...catalog, current }
  }

  async selectModel(sessionId: string, selection: ModelSelection): Promise<ModelSelection> {
    const value = this.unwrapRemote(await this.remote.session.selectModel({ sessionId: sessionId as SessionId, ...selection }))
    return value.selected
  }

  async listSkills(sessionId: string): Promise<readonly SkillEntry[]> {
    return this.unwrapRemote(await this.remote.skills.list({ sessionId: sessionId as SessionId })).skills
  }

  async listCommands(sessionId: string): Promise<readonly NativeCommandView[]> {
    return this.unwrapRemote(await this.remote.commands.list(sessionId as SessionId)).map(command => ({
      name: command.name,
      description: command.description,
      ...(command.input === undefined ? {} : { input: command.input }),
    }))
  }

  async listPlugins(): Promise<readonly PluginInventoryEntryView[]> {
    const value = this.unwrapRemote(await this.remote.pluginInventory.list())
    return value.entries.map(entry => ({
      entryId: String(entry.entryId),
      moduleName: entry.moduleName,
      enabled: entry.enabled,
      fiberPhase: entry.fiberPhase,
    }))
  }

  jobsSnapshot(): ObservableView<JobsSnapshotView> {
    return this.jobs.state as ObservableView<JobsSnapshotView>
  }

  watchJobs(sessionId: string): () => void {
    return this.jobs.watchRows(sessionId as SessionId)
  }

  async ensureTerminalOwner(input: { preferredSessionId?: string; workspaceId?: string; cwd?: string }): Promise<string> {
    const live = await this.rpc<Array<{ sessionId: string }>>('agents/list')
    if (input.preferredSessionId !== undefined && live.some(agent => agent.sessionId === input.preferredSessionId)) return input.preferredSessionId
    const sessionId = await this.sessions.create(input.workspaceId === undefined
      ? (input.cwd === undefined ? {} : { cwd: input.cwd })
      : { workspaceId: input.workspaceId as WorkspaceId })
    this.openSession(String(sessionId))
    return String(sessionId)
  }

  async chooseWorkspace(): Promise<{ path: string; workspace: WorkspaceView; sessionId: string } | null> {
    const path = await this.uiWorkspace.pickDirectory()
    if (path === null) return null
    const workspace = await this.workspaces.create({ path })
    const sessionId = await this.uiWorkspace.connectWorkspace(workspace.workspaceId)
    this.openSession(String(sessionId))
    return { path, workspace, sessionId: String(sessionId) }
  }

  async openWorkspace(workspaceId: string): Promise<string> {
    const sessionId = await this.uiWorkspace.connectWorkspace(workspaceId as WorkspaceId)
    this.openSession(String(sessionId))
    return String(sessionId)
  }

  async archiveSession(sessionId: string): Promise<void> {
    await this.uiWorkspace.archiveSession(sessionId as SessionId)
  }

  async unarchiveSession(sessionId: string): Promise<void> {
    await this.uiWorkspace.unarchiveSession(sessionId as SessionId)
  }

  async renameSession(sessionId: string, title: string): Promise<string> {
    await this.prepareSession(sessionId)
    const handle = this.session(sessionId)
    if (handle === undefined) throw new Error(`session ${sessionId} is unavailable`)
    const result = await handle.face.rename(title)
    if (!result.ok) throw remoteError(result)
    return result.value.title
  }

  async command(sessionId: string, line: string): Promise<void> {
    await this.prepareSession(sessionId)
    const handle = this.session(sessionId)
    if (handle === undefined) throw new Error(`session ${sessionId} is unavailable`)
    const result = await handle.face.command(line)
    if (!result.ok) throw remoteError(result)
    if (!result.value.matched) throw new Error(`DSH does not provide the ${line.split(/\s+/)[0]} command in this profile.`)
  }

  async exportSession(sessionId: string, format: 'markdown' | 'json', title?: string): Promise<SessionExportView> {
    return await this.rpc<SessionExportView>('session/export', { sessionId, format, ...(title === undefined ? {} : { title }) })
  }

  async connectWorkspacePath(path: string): Promise<string> {
    const workspace = await this.workspaces.create({ path })
    return await this.openWorkspace(String(workspace.workspaceId))
  }

  async deepSeekCredential(): Promise<CredentialInfoView> {
    const value = this.unwrapRemote(await this.remote.credentials.describe(['DEEPSEEK_API_KEY']))
    return value.DEEPSEEK_API_KEY ?? { configured: false, writable: false }
  }

  async setDeepSeekCredential(value: string): Promise<void> {
    if (value.trim() === '') throw new Error('API key cannot be empty.')
    this.unwrapRemote(await this.remote.credentials.set('DEEPSEEK_API_KEY', value))
  }

  async unsetDeepSeekCredential(): Promise<void> {
    this.unwrapRemote(await this.remote.credentials.unset('DEEPSEEK_API_KEY'))
  }

  async prompt(sessionId: string, text: string, mode: 'queue' | 'steer' = 'queue'): Promise<void> {
    await this.prepareSession(sessionId)
    const handle = this.session(sessionId)
    if (handle === undefined) throw new Error(`session ${sessionId} is unavailable`)
    const submission = handle.face.beginSubmission({ mode, text, attachments: [] })
    try {
      const result = await handle.face.prompt([{ type: 'text', text }], mode, undefined, submission.requestId)
      if (!result.ok) throw remoteError(result)
    } catch (error) {
      submission.abandon()
      throw error
    }
  }

  async cancel(sessionId: string): Promise<void> {
    await this.prepareSession(sessionId)
    const handle = this.session(sessionId)
    if (handle === undefined) throw new Error(`session ${sessionId} is unavailable`)
    const result = await handle.face.cancel()
    if (!result.ok) throw remoteError(result)
  }

  async loadOlder(sessionId: string): Promise<void> {
    await this.prepareSession(sessionId)
    const handle = this.session(sessionId)
    if (handle === undefined) throw new Error(`session ${sessionId} is unavailable`)
    await handle.face.loadOlder()
  }

  async attachmentDataUrl(sessionId: string, attachment: { id?: unknown; mimeType?: unknown }): Promise<string> {
    await this.prepareSession(sessionId)
    const handle = this.session(sessionId)
    if (handle === undefined) throw new Error(`session ${sessionId} is unavailable`)
    const id = attachment.id
    if (typeof id !== 'string') throw new Error('image attachment has no id')
    const result = await handle.face.readAttachment(id as never)
    if (!result.ok) throw remoteError(result)
    const bytes = result.value.data
    let binary = ''
    const stride = 0x8000
    for (let index = 0; index < bytes.length; index += stride) binary += String.fromCharCode(...bytes.subarray(index, index + stride))
    const mime = typeof attachment.mimeType === 'string' ? attachment.mimeType : result.value.attachment.mimeType
    return `data:${mime};base64,${btoa(binary)}`
  }
}
