import { useEffect, useState, useSyncExternalStore } from 'react'
import type { ConversationSnapshotView, DshClientAdapter, ObservableView } from '../dsh-compat/client.ts'
import type { ContextUsageView } from '../dsh-compat/protocol.ts'

export function useConversationSource(adapter: DshClientAdapter, sessionId: string): ObservableView<ConversationSnapshotView> | undefined {
  const [source, setSource] = useState(() => adapter.conversation(sessionId))
  useEffect(() => {
    let cancelled = false
    const attach = () => {
      const next = adapter.conversation(sessionId)
      setSource(previous => previous === next ? previous : next)
      return next !== undefined
    }
    attach()
    void adapter.prepareSession(sessionId).then(() => {
      if (!cancelled) attach()
    }, () => {
      // The surrounding unavailable state remains authoritative when a cold
      // Session cannot be retained (for example while it is being archived).
    })
    const timer = window.setInterval(attach, 250)
    return () => { cancelled = true; window.clearInterval(timer) }
  }, [adapter, sessionId])
  return source
}

function BoundSessionSnapshot({ source, children }: { source: ObservableView<ConversationSnapshotView>; children: (snapshot: ConversationSnapshotView) => React.ReactNode }) {
  const snapshot = useSyncExternalStore(
    listener => source.subscribe(listener),
    () => source.getSnapshot(),
    () => source.getSnapshot(),
  )
  return children(snapshot)
}

export function SessionSnapshot({ adapter, sessionId, children, unavailable }: {
  adapter: DshClientAdapter
  sessionId: string
  children: (snapshot: ConversationSnapshotView) => React.ReactNode
  unavailable?: React.ReactNode
}) {
  const source = useConversationSource(adapter, sessionId)
  if (source === undefined) return unavailable ?? <div className="kd-empty">Session unavailable.</div>
  return <BoundSessionSnapshot source={source}>{children}</BoundSessionSnapshot>
}

export function formatTime(time: number): string {
  try { return new Date(time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) } catch { return '—' }
}

export function formatBytes(size: number | undefined): string {
  if (size === undefined) return '—'
  if (size < 1024) return `${size} B`
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`
  if (size < 1024 * 1024 * 1024) return `${(size / (1024 * 1024)).toFixed(1)} MB`
  return `${(size / (1024 * 1024 * 1024)).toFixed(1)} GB`
}

export function formatTokenCount(tokens: number): string {
  if (tokens < 1000) return `${tokens}`
  if (tokens < 1_000_000) return `${(tokens / 1000).toFixed(tokens < 10_000 ? 1 : 0)}K`
  return `${(tokens / 1_000_000).toFixed(tokens < 10_000_000 ? 1 : 0)}M`
}

export function formatContextUsage(context: ContextUsageView | undefined): string | undefined {
  if (context === undefined) return undefined
  const used = formatTokenCount(context.contextTokens)
  if (context.contextWindow === undefined) return `${used} tok`
  const percent = context.contextTokens / context.contextWindow * 100
  return `${used} / ${formatTokenCount(context.contextWindow)} · ${percent.toFixed(0)}%`
}

export function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

export function pathExtension(path: string): string {
  const name = path.split(/[\\/]/).pop() ?? ''
  const index = name.lastIndexOf('.')
  return index < 0 ? '' : name.slice(index + 1).toLowerCase()
}

export function pathBasename(path: string): string {
  return path.replace(/[\\/]+$/, '').split(/[\\/]/).pop() ?? path
}
