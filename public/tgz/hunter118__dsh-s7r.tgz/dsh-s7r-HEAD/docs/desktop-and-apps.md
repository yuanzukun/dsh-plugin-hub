# Desktop and applications

← [Files, Terminal, and Find](./files-terminal-and-search.md) · [Documentation index](./README.md) · [Display and wallpaper](./display-and-wallpaper.md) →

S7R treats the desktop as a working surface. Windows, aliases, selection, context menus, Trash, help, and utility applications share the same logical coordinate system at both 1× and 2×.

## Window system

Windows can be focused, moved, resized when allowed, collapsed, zoomed, closed, and selected from the **Window** menu. S7R persists bounds, z-order, collapse state, and zoom state.

### Tile and restore

**Window → Tile Windows** arranges open resizable windows in the current work area. Before tiling, S7R records the exact layout. **Restore Previous Layout** returns to those bounds even if Tile was chosen more than once.

Clock, Puzzle, and New Agent setup are fixed-size windows. They do not become arbitrary resizable panels and are excluded from normal zoom/tile resizing.

### Open windows and recent Agents

The Window menu contains:

- an **Open Windows** section ordered by z-index, with the active window checked;
- an **Agents** section containing the most recently used Agents.

Set the recent Agent count from 1–9 in **S7R → Settings…**; the default is 5. Knowledge Desk remains the complete searchable Agent browser.

## Desktop aliases

S7R supports four desktop object kinds:

- Workspace;
- Agent;
- Finder file/folder;
- individual Scrapbook card.

An alias is a browser-local pointer to the real object. Opening it routes to the Workspace, Session, file, or card. Removing an alias never deletes the target.

### Folder meanings

A folder can have two explicit alias behaviors:

- **Finder Alias** — browse the directory within its existing Workspace.
- **Workspace Alias** — register/activate the directory as a Workspace and connect its Agent workflow.

This distinction avoids making a double-click unexpectedly change the current Workspace.

### Selection and group dragging

- Click empty desktop space and drag to marquee-select aliases.
- Shift-click or Command-click toggles an alias in the current selection.
- Drag any selected alias to move the whole group while retaining relative positions.
- **Special → Clean Up Desktop** arranges aliases into a grid.
- Delete/Backspace moves selected aliases to Trash when focus is not in an editable field.

S7R maps pointer positions back to logical coordinates before moving objects, so exact 2× magnification does not double drag distance.

## Trash

Trash contains only S7R desktop aliases.

- Drop aliases on the bottom-right Trash icon or press Delete/Backspace.
- Double-click Trash or choose **Special → Open Trash**.
- Select records and choose **Put Away**, or restore everything with **Put Away All**.
- **Special → Empty Trash…** permanently removes alias records after confirmation.

Trash never deletes files, folders, Workspace registration, DSH Agent history, or Scrapbook cards. Agent archive is a separate reversible DSH operation.

## Context menus and Get Info

S7R suppresses the browser's native context menu throughout the simulated desktop. Right-clicking meaningful objects opens an S7R menu; right-clicking an area with no useful operation does nothing.

Context menus cover:

- empty desktop space;
- desktop aliases;
- Trash;
- Knowledge Desk Agent and Workspace rows;
- Finder entries;
- editable inputs and text areas.

Depending on the object, actions include Open, DSH Controls, Open in Terminal, Finder/Workspace alias placement, Rename, Export, Archive, copy relative path, copy absolute path, Get Info, Move to Trash, and Empty Trash.

Editable fields receive S7R-owned Undo, Cut, Copy, Paste, and Select All. Browser security rules still govern clipboard access.

Get Info reports object-specific facts such as type, path, Session/Workspace ID, alias behavior, resolution, scale, or deletion semantics. It is informational and does not expose stored secrets.

## Drag and drop

S7R drag objects can travel among Finder, Knowledge Desk, Agent composers, Scrapbook, the desktop, and Trash.

| Source → destination | Result |
| --- | --- |
| Finder → desktop | File/folder alias |
| Workspace → desktop | Workspace alias |
| Agent → desktop | Agent alias |
| Scrapbook → desktop | Single-card alias |
| Alias group → desktop | Group move |
| Alias/group → Trash | Reversible alias-only deletion |
| Finder item → Agent | Relative path inside the Agent Workspace, otherwise absolute path |
| Agent/Workspace/Scrapbook alias → Agent | Explicit textual reference |

## Menu bar

The menu bar is application-aware. It contains S7R, File, Edit, Window, Special, and Help; the redundant View menu is intentionally absent.

- **S7R** contains settings and system applications, then a separator before Clock and Puzzle desk accessories.
- **File** contains creation, folder, Finder, Terminal, Find, active-application actions, and Close Window.
- **Edit** exposes text operations when the active application supports them.
- **Window** manages geometry and switching.
- **Special** contains desktop cleanup and Trash.
- **Help** controls Balloon Help and opens the short in-app guide.

The complete item-by-item map is in [Reference](./reference.md).

## Balloon Help

Turn on **Help → Show Balloon Help**. Marked controls show a delayed explanatory balloon on pointer hover or keyboard focus.

Behavior is designed for the simulated desktop:

- gray in default Monochrome mode and softly tinted in Muted Color mode;
- dismissed by typing, clicking, or scrolling;
- suppressed while a menu or modal dialog is open;
- flipped and clamped at desktop edges;
- positioned from logical coordinates, so 2× does not introduce an extra offset;
- persisted in the current browser profile.

Use Balloon Help for discovery, not as the only location of required instructions. The full behavior stays documented here.

## Notifications

S7R shows a minimal desktop notice when an Agent crosses into a completed state. Selecting the notice opens that Agent. Notices are intentionally restrained and are not a replacement for durable Agent state in Knowledge Desk or Monitor.

## Monitor

Open **S7R → Monitor**. Monitor combines system pressure, Agent state, and DSH background work.

### System summary

- **CPU** — host-wide usage and logical core count.
- **Active RAM** on macOS — active + wired + compressed pages; reusable inactive/file cache is excluded.
- **RAM** on other supported systems — total minus immediately free memory when that is the available accounting.
- **DSH process RSS** — displayed with Agent/process information so one process is not confused with whole-machine memory pressure.

### Agents tab

Shows live DSH Agents with state, model when available, last update, context length, and provider-reported pressure. Double-clicking/focusing routes to the Agent.

### Background tab

Shows DSH Jobs that may keep running after an Agent window closes, including Agent, kind, status, task label, and detail. S7R observes authoritative Jobs state; it does not invent a parallel task queue.

## Scrapbook

Scrapbook is a browser-local collection of editable cards.

- **Add to Scrapbook** captures a user or assistant message and its source Agent reference.
- **New Card** creates an empty card.
- Cards have a title, kind, body, and optional source.
- Previous/next controls navigate the collection.
- **Copy** copies the complete card body without manual selection and gives visible feedback.
- **Open Source** returns to the source Agent or file when available.
- **Desktop** places only the current card as an alias.
- **Delete** removes the local Scrapbook copy after confirmation; it does not affect the source.

Scrapbook cards and aliases are separate. Trashing an alias preserves its card; deleting the card may leave no content for an old alias to open.

## Clock and Puzzle

Clock is a fixed-size live analog/digital desk accessory.

Puzzle is an original fixed-size 4×4 sliding-number game. **New Game** starts from the solved board and performs only legal moves, so every shuffled board is reachable and solvable. **Solve** restores the solved state; the toolbar records move count.

System applications belong near the top of the S7R menu. Clock and Puzzle appear after a separator at the bottom because they are desk accessories rather than configuration tools.

## In-app guide

**Help → S7R Guide…** provides a compact workflow reminder for folder selection, New Agent setup, Stationery, right-click actions, Find, desktop selection, Trash, Context, Balloon Help, files, Terminal, and display settings. The multi-page documentation you are reading is authoritative when the short guide omits detail.

## Persistence exceptions

Most desktop state returns after reload. Two windows are intentionally not restored:

- live Terminal windows, because a serialized window cannot safely reattach an owner-scoped process;
- incomplete New Agent setup windows, because no durable Agent configuration exists yet.

See [Reference](./reference.md) for the full storage ownership table.
