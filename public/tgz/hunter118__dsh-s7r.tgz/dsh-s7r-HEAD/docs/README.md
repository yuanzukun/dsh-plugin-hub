# S7R documentation

[Project README](../README.md) · [Latest release](https://github.com/hunter118/dsh-s7r/releases/latest) · [Report a problem](https://github.com/hunter118/dsh-s7r/issues)

This is the complete documentation index for S7R. The public [project README](../README.md) is the short overview; the pages below are the maintained source of detailed user and contributor guidance.

## Choose a path

### I am installing S7R

Start with [Getting started](./getting-started.md). It covers requirements, release and source installation, checksum verification, first run, upgrade, removal, and the first Workspace/Agent workflow.

If a command is missing or the Web UI does not load, go directly to [Troubleshooting](./troubleshooting.md).

### I am using S7R

| Guide | Use it for |
| --- | --- |
| [Workspaces and Agents](./workspaces-and-agents.md) | Knowledge Desk, Workspace selection, New Agent setup, Agent Preset Stationery, conversation controls, Context, Timeline, export, archive, restore, and desktop Agent aliases. |
| [Files, Terminal, and Find](./files-terminal-and-search.md) | Finder, TextEdit, Preview, zsh, path handling, source limits, and every Global Find scope. |
| [Desktop and applications](./desktop-and-apps.md) | Windows, menus, aliases, drag and drop, group selection, Trash, context menus, Balloon Help, notifications, Monitor, Scrapbook, Clock, and Puzzle. |
| [Display and wallpaper](./display-and-wallpaper.md) | Fit Browser/fixed work areas, bitmap font sizes, exact magnification, monochrome/muted color, Preview filters, built-in wallpaper, Cat tile, and imported images. |
| [DSH integration](./dsh-integration.md) | DSH Control Center, Agent Presets, models/reasoning, commands/modes, Skills, plugin inventory, credentials, Jobs, archive ownership, and service boundaries. |
| [Reference](./reference.md) | Complete menu map, data ownership, persistence, keyboard behavior, limits, security summary, and feature-to-data map. |
| [Troubleshooting](./troubleshooting.md) | Installation, PATH, version, API key, folder picker, Terminal, display, stale state, logs, and safe reset procedures. |

## I am developing or reviewing S7R

Read these in order when making a change:

1. [Product and design specification](./design-spec.md) — the product contract and non-goals.
2. [Architecture](../ARCHITECTURE.md) — package shape, adapters, persistence, and application boundaries.
3. [DSH compatibility](../COMPATIBILITY.md) — the exact supported Harness seam and current limitations.
4. [Contributing](../CONTRIBUTING.md) — setup, checks, pull request expectations, and the documentation update matrix.
5. [Development notes](./development-notes.md) — implementation milestones and the latest verification record.
6. [Changelog](../CHANGELOG.md) — user-visible release history.

Security-sensitive work must also follow [SECURITY.md](../SECURITY.md). Third-party assets and code are recorded in [THIRD_PARTY_NOTICES.md](../THIRD_PARTY_NOTICES.md).

## Documentation ownership

Each subject has one primary page to reduce drift:

| Change | Primary documentation | Also check |
| --- | --- | --- |
| Installation, CLI, requirements, or upgrades | [Getting started](./getting-started.md) | Project README, Troubleshooting, release workflow |
| Workspace, Agent, Context, Timeline, or lifecycle behavior | [Workspaces and Agents](./workspaces-and-agents.md) | Reference, Changelog |
| Finder, TextEdit, Preview, Terminal, or Find | [Files, Terminal, and Find](./files-terminal-and-search.md) | Reference, Troubleshooting |
| Desktop, menus, windows, accessories, or Monitor | [Desktop and applications](./desktop-and-apps.md) | Reference, screenshots |
| Fonts, scaling, filters, appearance, or wallpaper | [Display and wallpaper](./display-and-wallpaper.md) | Reference, screenshots |
| DSH APIs, versions, ownership, or capability exposure | [DSH integration](./dsh-integration.md) | Compatibility, Architecture, Development notes |
| Storage, limits, shortcuts, security, or exhaustive behavior | [Reference](./reference.md) | Troubleshooting, Security policy |

The enforceable checklist and link validation command are documented in [Contributing](../CONTRIBUTING.md). Run `pnpm docs:check` after editing any Markdown file.

## Version scope

These pages describe S7R `0.10.x` with DeepSeek Harness `0.1.7-rc.2` unless a page says otherwise. Historical behavior belongs in the [Changelog](../CHANGELOG.md), not in the current user guide.
