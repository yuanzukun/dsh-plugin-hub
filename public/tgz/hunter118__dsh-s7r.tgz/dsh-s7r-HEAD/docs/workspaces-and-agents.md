# Workspaces and Agents

← [Documentation index](./README.md) · [Files, Terminal, and Find](./files-terminal-and-search.md) →

Knowledge Desk is S7R's Workspace launcher, Agent browser, and conversation application. It presents real DSH state: opening, closing, renaming, archiving, or restoring an Agent acts on the same DSH Session rather than creating a browser-local copy.

![An Agent conversation with Context Inspector open while Finder, Monitor, Clock, and Knowledge Desk remain visible](./screenshots/s7r-agent.png)

## The Workspace model

A Workspace is a folder registered with DSH. S7R always makes the current Workspace visible because it determines where new Agents and file tools operate.

Choose **File → Choose Folder…** to register an external folder. Selecting a Workspace row in Knowledge Desk makes it current; double-clicking it opens Finder. The current Workspace controls:

- **New Agent Here** and **File → New Agent**;
- Finder's root and every TextEdit/Preview file request;
- Terminal's default working directory;
- relative-path conversion for Finder items dropped into an Agent;
- the default file scope in Global Find.

Host paths are validated again for every request. Registering a Workspace is not permission to browse unrelated parent or sibling paths.

### Workspace actions

From Knowledge Desk you can:

- select a Workspace as current;
- open its root in Finder;
- create a new Agent there;
- place a Workspace alias on the desktop;
- right-click for Open, desktop placement, path copy, and Get Info.

A desktop folder can mean one of two things. A **Finder Alias** opens a directory inside an existing Workspace. A **Workspace Alias** registers/activates that folder as a Workspace and connects its Agent workflow. S7R asks which meaning you want when necessary.

## Browse and find Agents

Knowledge Desk has Active and Archived views.

The search field matches Agent title, path, or Session ID. The controls beside it can:

- restrict results to the current Workspace or show all Workspaces;
- filter by All, Running, Idle, or Completed;
- sort by Recent, Name, or Status.

When all Workspaces are visible, Agents are grouped beneath their Workspace; unassigned Sessions appear separately. The Archived view uses the same Workspace and text scopes and shows the authoritative DSH archive plus any readable pre-0.10 migration records.

Double-click a row or choose **Open** to bind the existing DSH Session and its Chat projection. No second conversation is created.

## Create an Agent

### New Agent setup

**File → New Agent** and **New Agent Here** open a fixed-size setup window before the conversation appears. It selects:

1. the owning Workspace;
2. an installed, usable DSH Agent Preset;
3. a provider/model when a prepared Agent can supply DSH's model catalog;
4. a reasoning effort when that model exposes supported efforts.

The Preset default remains usable when no model catalog is available. For a newly registered Workspace, S7R may prepare its new blank Session so the selected Preset/model can be applied before the first turn. DSH locks composition after work begins to keep logged tools reproducible.

### Agent Preset Stationery

**File → New from Stationery…** is a smaller, repeatable creation workflow based entirely on DSH Agent Presets. Choose:

- Workspace;
- Agent Preset;
- optional display name;
- optional opening prompt.

The Preset supplies the real DSH composition, model-facing plugins, and tools. Preset names, descriptions, default status, and broken status come from DSH; S7R does not create a second template format.

Use regular New Agent setup when you want to choose model/reasoning before opening. Use Stationery when the Preset itself is the reusable starting point and you may want to send a first task immediately.

## Conversation window

The top line stays intentionally compact:

- **RUNNING** or **IDLE** reflects the live Session state.
- **Context** opens context diagnostics and management.
- **Timeline** opens the complete event ledger.
- **Other…** opens lifecycle and display actions.

The status bar shows Workspace, provider-reported context usage when available, visible record count, and a shortened Session ID.

The conversation is DSH's authoritative Chat projection. S7R renders user and steering messages; assistant text, reasoning, images, and tool calls; tool results/failures; context records; retries, token-limit and compaction notices; command and turn errors; attachments; and active streamed blocks/tools. It does not reconstruct a second conversation from transport frames.

### Prompt, steering, and cancellation

- Press Enter to send; Shift-Enter inserts a newline.
- When idle, the composer queues a normal prompt.
- When running, the composer sends steering for the current execution.
- Use **Other… → Stop Running Agent** or **File → Stop Running Agent** to request cancellation.

The prompt area accepts S7R drag items. A file inside the Agent's Workspace becomes `./relative/path`; a path outside that Workspace remains absolute. Agent, Workspace, and Scrapbook drops insert explicit textual references.

### Streaming and reading position

S7R follows new output only while the reader is already near the bottom. If you scroll upward during a run, the reading position remains stable and a **New output ↓** control appears. It reports fresh content and returns to the live edge when selected.

Streaming text stays plain until a message completes. This avoids repeatedly reparsing an unfinished Markdown structure.

### Markdown display

Open **Other…** to turn completed-output Markdown rendering on or off. The setting persists in the browser profile and does not rewrite DSH history.

The renderer supports:

- multiple heading levels;
- emphasis and strong emphasis;
- inline and fenced code;
- ordered and unordered lists;
- block quotes;
- basic tables;
- safe links and plain text.

It builds restricted React nodes and never injects raw HTML. LaTeX remains source text; S7R does not claim a pixel-native equation renderer. Emoji are mapped to monochrome pixel-font symbols or short text where possible so color platform emoji do not dominate the interface.

### Add to Scrapbook

Each user or assistant message can be copied to Scrapbook. Selecting **Add to Scrapbook** immediately changes the action to a visited-style **Added to Scrapbook** state. The card retains its Agent reference, remains editable, can be copied with one action, and can be placed on the desktop. See [Desktop and applications](./desktop-and-apps.md).

## Context Inspector

Open **Context** from an Agent window. S7R shows provider-reported context length and usage percentage when DSH supplies them, plus diagnostic shares for:

- user text;
- assistant output;
- reasoning;
- tools;
- Workspace/context material.

The shares are character-based composition diagnostics, not invented token accounting. S7R warns at roughly 75% and marks pressure critical at roughly 90%.

Available actions:

- **Compact Now** sends DSH's `/compact` command. DSH owns the resulting summary and event sequence.
- **New Agent with Current Summary** creates a fresh current summary, opens a successor Agent in the same Workspace, and supplies that summary as its starting context.

The second action is useful when you want a clean context window while preserving an explicit handoff. It creates a new Agent; it does not mutate or delete the original.

## Timeline

Timeline reads the complete live or cold persisted event ledger, not only the conversation records currently projected into the Agent window.

It includes messages, reasoning, context, tools, chunks, and other DSH event types. Adjacent same-type records—especially long runs of `assistant/chunk`—are folded into an expandable group. Individual events retain sequence and time, raw structured data, Agent navigation, and file navigation when an event carries a path.

Use Timeline when:

- the rendered conversation omits implementation-level events;
- a tool or file action needs inspection;
- Global Find opened an exact event match;
- persisted history must be checked after the live view is gone.

## Agent lifecycle

| Action | Result |
| --- | --- |
| **Close Window** | Closes only the S7R view. The DSH Session remains available. |
| **Open** | Rebinds the same Session and its persisted history. |
| **Rename** | Changes the human-facing DSH Session title without changing its ID. |
| **Export → Markdown** | Downloads a readable transcript built from the complete persisted event history. |
| **Export → JSON** | Downloads a machine-readable archive of the complete persisted event history. |
| **Archive** | Uses DSH's reversible native archive operation; history is preserved. A running Agent cannot be archived from Knowledge Desk. |
| **Restore** | Removes the Session from DSH's archive and makes it active in Knowledge Desk again. |
| **Desktop** | Creates a browser-local alias that reopens the Agent; removing the alias does not archive the Agent. |

Rename, export, archive, and desktop placement are available from Knowledge Desk, the Agent's **Other…** panel, and applicable right-click menus. The right-click **DSH Controls…** action opens Control Center on that Agent.

## Window menu Agent switcher

The **Window** menu lists every open window and a recent Agent section. **S7R → Settings…** controls whether that section contains 1–9 Agents; the default is 5. It is a recency switcher, not an exhaustive list—use Knowledge Desk for the full searchable inventory.

## What persists

DSH owns Agent events, titles, Workspace association, live state, jobs, model composition, and native archive state. S7R stores only presentation state such as Agent window geometry, Markdown preference, desktop aliases, and readable metadata needed to migrate old local archives.

Closing or reloading the page never deliberately deletes a DSH Session. Incomplete New Agent setup windows do not return after reload because they are not yet meaningful durable work.

## Related documentation

- [DSH integration](./dsh-integration.md) for Control Center and service ownership.
- [Files, Terminal, and Find](./files-terminal-and-search.md) for Workspace files, path drops, and Agent search.
- [Reference](./reference.md) for the complete menu and persistence map.
