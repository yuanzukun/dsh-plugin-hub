# Getting started

← [Documentation index](./README.md) · [Troubleshooting](./troubleshooting.md) →

This guide takes a new installation from download to a working Agent. It also explains source installation, upgrades, removal, and which state survives each operation.

## Requirements

- Node.js `22.19+` or `24+`.
- DeepSeek Harness `0.1.7-rc.2` for S7R `0.10.x`.
- pnpm `11.19.0` for DSH profile plugin management and source development.
- A modern Chromium-based browser for the primary tested Web UI path.
- A DeepSeek API key unless the chosen DSH provider/model uses another configured credential.

Install DeepSeek Harness using its upstream instructions. Confirm that the commands you will use are visible before adding S7R:

```sh
node --version
pnpm --version
dsh --version
```

If `pnpm` or `dsh` is not found, do not continue with a partial install; use the [command-not-found troubleshooting steps](./troubleshooting.md).

## Install a release archive

1. Download `dsh-s7r-0.10.0.tgz` and `SHA256SUMS` from the [latest S7R release](https://github.com/hunter118/dsh-s7r/releases/latest).
2. Verify the archive.

   On macOS:

   ```sh
   shasum -a 256 -c SHA256SUMS
   ```

   On Linux:

   ```sh
   sha256sum -c SHA256SUMS
   ```

3. Add it to the DSH Web profile and inspect the resolved profile:

   ```sh
   dsh plugin --profile web add ./dsh-s7r-0.10.0.tgz
   dsh --profile web --dump-config
   ```

4. Start DSH Web:

   ```sh
   dsh web
   ```

5. Open the loopback address printed by DSH, normally `http://127.0.0.1:3080`.

S7R intentionally occupies the Web root slot. Seeing the S7R menu bar and desktop confirms that the profile loaded the plugin.

## Install from source

Use this path for development or to validate an unreleased commit:

```sh
git clone https://github.com/hunter118/dsh-s7r.git
cd dsh-s7r
corepack enable
pnpm install --frozen-lockfile
pnpm check
pnpm build
dsh plugin --profile web add .
dsh --profile web --dump-config
dsh web
```

The source directory remains the plugin location. Rebuild after code changes, then restart `dsh web` and reload the browser. For contributor checks and the documentation contract, read [Contributing](../CONTRIBUTING.md).

## First run

### 1. Configure model access

Open **S7R → Settings…**.

- If DSH already receives `DEEPSEEK_API_KEY` from its launch environment, the panel reports it as configured and shows the source when available.
- Otherwise, paste the key and choose **Save Key**. The key is sent to DSH's loopback credential service.
- S7R can read configured/source/writable status, but it cannot read a stored secret back into the page.
- **Remove Stored Key…** removes the DSH-managed value without deleting Agents or history.

New model operations use the updated credential immediately. If the credential source is not writable, change it where DSH reports that it originated.

### 2. Choose a Workspace

Choose **File → Choose Folder…**. DSH's native folder picker registers the selected external folder as a real Workspace. S7R is not limited to the directory where `dsh web` was launched.

The current Workspace becomes the boundary for:

- new Agents;
- Finder, TextEdit, and Preview;
- Terminal working directories;
- file-name and source-content Find;
- relative paths dropped into an Agent.

S7R remembers the most recently used valid Workspace and can reopen it on a later visit.

### 3. Create an Agent

Choose **File → New Agent** or **New Agent Here** in Knowledge Desk. The fixed setup window asks for:

- Workspace;
- installed DSH Agent Preset;
- provider/model, when DSH can obtain a model catalog from a prepared Agent;
- reasoning effort, when the selected model exposes it.

If no prior Agent is available to supply a model catalog, the Preset default remains valid. Creating the Agent opens its conversation window.

For a Preset-first workflow with an optional Agent name and first prompt, choose **File → New from Stationery…**. Read [Workspaces and Agents](./workspaces-and-agents.md) for the differences.

### 4. Send a prompt

Type in the composer and press Enter. Shift-Enter inserts a line break. While the Agent is running, the same composer sends steering rather than silently queueing an unrelated conversation.

The Agent window exposes Context, Timeline, and Other panels; the complete lifecycle is in [Workspaces and Agents](./workspaces-and-agents.md).

### 5. Open files or a Terminal

- **File → Browse Current Workspace** opens Finder.
- **File → New Terminal** opens a Workspace-scoped `/bin/zsh -f -i` line console even if no Agent window is visible.
- **File → Find…** searches files and/or Agents using explicit scopes.

See [Files, Terminal, and Find](./files-terminal-and-search.md).

## Upgrade S7R

Read the target release's [Changelog](../CHANGELOG.md) and [Compatibility notes](../COMPATIBILITY.md) first. Stop the running DSH Web process, then remove the old profile entry before adding the replacement:

```sh
dsh plugin --profile web remove dsh-s7r
dsh plugin --profile web add ./dsh-s7r-NEW_VERSION.tgz
dsh --profile web --dump-config
dsh web
```

Reload the Web page after DSH restarts. Do not install two S7R copies into the same profile.

An S7R package upgrade does not delete:

- DSH Agents and durable event logs;
- Workspace registration and project files;
- DSH-managed credentials;
- browser-local S7R display, desktop, Trash, Scrapbook, and help preferences in the same browser profile/origin.

A DSH upgrade can change public service seams. Only combine versions declared compatible in [COMPATIBILITY.md](../COMPATIBILITY.md).

## Remove S7R

```sh
dsh plugin --profile web remove dsh-s7r
```

Removing the plugin does not delete DSH Agent history, Workspace files, or credentials. Browser-local S7R data may remain for the same loopback origin; clear that site's data only if you also want to reset the desktop, wallpaper library, Scrapbook, Trash, and preferences.

## What to read next

- [Workspaces and Agents](./workspaces-and-agents.md) for the main daily workflow.
- [Desktop and applications](./desktop-and-apps.md) for windows, aliases, context menus, and utilities.
- [Display and wallpaper](./display-and-wallpaper.md) before changing resolution or 2× magnification.
- [Troubleshooting](./troubleshooting.md) if any command, service, or window does not behave as described.
