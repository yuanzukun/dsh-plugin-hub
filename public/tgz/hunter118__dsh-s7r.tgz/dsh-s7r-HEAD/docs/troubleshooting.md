# Troubleshooting

← [Reference](./reference.md) · [Documentation index](./README.md) · [Getting started](./getting-started.md) →

Start with exact versions and the resolved DSH profile. S7R `0.10.x` is documented against DSH `0.1.7-rc.2`; a superficially similar prerelease may expose different browser or host services.

## Collect safe diagnostics

Run:

```sh
node --version
pnpm --version
dsh --version
dsh --profile web --dump-config
```

Record the S7R version, DSH version, operating system, browser version, exact reproduction steps, sanitized host output, and sanitized browser-console errors.

Before sharing anything, remove:

- API keys and authorization headers;
- personal home-directory paths when not required;
- private conversation text;
- source code or filenames you cannot publish;
- terminal output containing secrets.

Use the [bug report template](https://github.com/hunter118/dsh-s7r/issues/new?template=bug_report.yml) after checking the cases below.

## `zsh: command not found: pnpm`

S7R source development and current DSH profile management expect pnpm. With a compatible Node installation:

```sh
corepack enable
corepack prepare pnpm@11.19.0 --activate
pnpm --version
```

If Corepack is unavailable, install the pinned package manager explicitly:

```sh
npm install --global pnpm@11.19.0
```

If installation succeeds but a new shell still cannot find it, compare:

```sh
npm prefix --global
which node
echo "$PATH"
```

The global npm executable directory for the active Node installation must be in `PATH`. When using nvm, initialize nvm in the shell and select the same Node version where the package was installed.

## `zsh: command not found: dsh`

The DSH CLI is provided by `@deepseek-ai/dsh`, not by S7R. For the S7R 0.10 baseline:

```sh
npm install --global @deepseek-ai/dsh@0.1.7-rc.2
dsh --version
```

If it remains missing, check whether Node changed after installation:

```sh
which node
npm prefix --global
npm root --global
```

nvm keeps global packages per Node version. Installing under one version and switching to another removes those executables from the active `PATH`; reinstall in the active version or switch back.

## `dsh web` fails before S7R appears

1. Confirm `dsh --version` matches [COMPATIBILITY.md](../COMPATIBILITY.md).
2. Inspect the Web profile:

   ```sh
   dsh --profile web --dump-config
   ```

3. Confirm `dsh-s7r` and the official terminal service/backend appear only once.
4. Remove and re-add the plugin:

   ```sh
   dsh plugin --profile web remove dsh-s7r
   dsh plugin --profile web add ./dsh-s7r-0.10.0.tgz
   dsh --profile web --dump-config
   dsh web
   ```

5. Use the loopback URL printed by this process; do not reuse an old port blindly.

If DSH itself fails before serving a URL, the host log is more useful than the browser console. If the root page loads but S7R does not appear, capture both.

## S7R version and DSH version do not match

Use declared release pairs:

- S7R `0.10.x` → DSH `0.1.7-rc.2`.
- Older S7R `0.9.x` → use the exact older pairing documented by that release.

Do not assume semver-compatible release candidates have compatible controller architecture. Remove the incompatible S7R profile entry, install the correct archive, restart DSH, and reload the page.

The npm `next` DSH line is not automatically supported. See [COMPATIBILITY.md](../COMPATIBILITY.md).

## API key is missing or cannot be saved

Open **S7R → Settings…** and choose **Refresh Status**.

- **Configured** means DSH already has a value; S7R will not reveal it.
- **API key missing** means the default DeepSeek provider cannot authenticate until a value is supplied.
- **Writable: false** means the reported source must be changed outside S7R, such as the environment that launched DSH.

After saving, the input is cleared intentionally. The status should become configured. If it does not, check the DSH host log and confirm the page is using the same live process/profile you configured.

Never paste a real key into an issue, screenshot, exported transcript, shell history excerpt, or browser console report.

## Folder picker cannot select an external directory

Use **File → Choose Folder…**, not a browser file input. DSH owns the native picker and Workspace registration.

If it fails:

1. confirm the DSH Web process has OS permission to access the directory;
2. keep the DSH host terminal open and inspect its error;
3. try a small, ordinary local folder to separate permission/provider problems from path-specific problems;
4. confirm the folder appears in Knowledge Desk Workspaces after selection.

Finder intentionally cannot navigate above the registered root. That is containment, not a broken Parent button.

## Agent creation has no model list

The model catalog is Agent-scoped. A new Workspace with no prepared Agent may show **Preset default** and a notice that no prior catalog is available. Choose a usable Preset and create/open the Agent; DSH can then prepare the Session and expose its supported providers/models.

If an existing Agent also has no models, open DSH Control Center and inspect per-provider failure messages. Check API-key status and the host log.

## Skills are empty but other DSH controls work

A cold Agent may not have its project Skill service attached. Open/prepare that Agent, then refresh DSH Control Center. Skill failure is intentionally independent from models, Presets, commands, and plugins.

## Plugin switches are missing

This is expected. DSH exposes authoritative loader inventory to S7R but not a supported browser mutation API. Add/remove plugins with `dsh plugin --profile ...`, restart DSH, and inspect the Plugins tab again.

## Terminal reports a Knowledge Desk/owner error

Current S7R can open Terminal with no visible Agent by creating a fresh blank owner in the current/recent Workspace. If an owner error still appears:

1. choose or reselect a valid Workspace;
2. close the failed Terminal and create a new one;
3. verify `knowledge-desk-terminal-service` and `knowledge-desk-terminal-backend` in `dsh --profile web --dump-config`;
4. inspect the DSH host log for Session/Agent creation failure;
5. confirm S7R and DSH versions match.

A restored old Terminal window is never valid; live Terminal windows are intentionally excluded from desktop restore.

## Terminal feels different from a native terminal

DSH's public API is line-oriented. Send a complete line with Enter/**Send Line**. Full-screen TUIs, per-keystroke applications, and resize-sensitive programs cannot behave like xterm because DSH does not publish raw PTY bytes or post-spawn resizing.

S7R starts `/bin/zsh -f -i`, acknowledges the line immediately, and polls retained output at low latency. If ordinary commands are slow, compare host CPU/RAM in Monitor and inspect the DSH process/log; do not enable large shell startup files, because `-f` intentionally bypasses them.

## TextEdit refuses to save

If the file changed on disk after S7R read it, the version guard reports a conflict. Preserve your edited text, refresh/reopen the file to inspect the external version, merge deliberately, and save again. S7R will not silently overwrite concurrent changes.

Other failures usually mean the path is outside the Workspace, the file is no longer writable, or the DSH filesystem service rejected it. Check the host error.

## Find misses a file or result

Confirm the selected scopes and target Workspace/Agent. Remember the deliberate bounds:

- hidden directories and `node_modules` are skipped;
- at most 5,000 files are traversed;
- source files above 1 MiB are not read;
- only eligible text/source extensions are searched for contents;
- at most 200 results are returned.

Use Names for navigation, Source contents for code/text, Conversation messages for visible dialog, and All event streams for reasoning/tools/context/chunks.

## Context percentage is missing

S7R always shows provider-reported length when available. It can compute a percentage only when the active model/provider advertised a context-window capacity. It does not guess a denominator. Character-based composition shares can still appear and are labelled as diagnostics rather than token accounting.

## RAM looks higher than expected

On macOS, S7R reports active + wired + compressed memory and excludes inactive/file cache. DSH process RSS is shown separately. Compare the label—**Active RAM** versus **RAM**—before comparing it with another utility that may count cached pages differently.

## Display is blurry, offset, too small, or slow

1. Set browser zoom to 100%.
2. Use S7R's exact 1× or 2× magnification instead of fractional browser zoom.
3. Try **Fit Browser** and **Comfortable 12px**.
4. Reload after confirming the active loopback page is not an old build tab.
5. Check whether browser hardware acceleration is disabled.

S7R uses live DOM and discrete bitmap masters; it does not screenshot/pixelate the whole desktop. Imported wallpaper is preprocessed once. If only one imported image is soft, re-import it with 1px/2px block treatment rather than scaling an already softened output.

## Windows or controls return in bad positions

Change to Fit Browser once to reflow bounds. **Window → Tile Windows** followed by **Restore Previous Layout** can recover an intentional layout. If a stored record is malformed, S7R should fail closed automatically.

For a complete browser-local reset, clear site data for the exact loopback origin. This removes S7R window/layout/display/wallpaper/Scrapbook/Trash preferences but does not delete DSH Agents, Workspaces, files, credentials, or history. Export any Scrapbook content you need first.

## Conversation history appears different after reinstall

DSH owns conversations; S7R owns only browser presentation. If you launched a different DSH profile, Node installation, user account, data directory, or loopback process, it may point to different Session persistence even though the browser still has the same S7R settings or DSH credential source.

Compare `dsh --profile web --dump-config`, the DSH version, launch environment, and data location. The fact that an API key remains configured does not prove that the same Session store is active; credentials and event persistence are separate DSH concerns.

## Build or documentation check fails

For a clean source tree:

```sh
corepack enable
pnpm install --frozen-lockfile
pnpm docs:check
pnpm check
pnpm pack
```

`pnpm docs:check` reports broken relative Markdown links or missing local targets. `pnpm check` also runs it along with typecheck, tests, and production build.

If frozen installation fails after a dependency change, the lockfile and `package.json` are inconsistent; do not bypass that in CI. For contribution requirements, read [CONTRIBUTING.md](../CONTRIBUTING.md).
