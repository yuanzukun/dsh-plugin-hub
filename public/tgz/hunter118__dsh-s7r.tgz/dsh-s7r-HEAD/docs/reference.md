# Reference

← [DSH integration](./dsh-integration.md) · [Documentation index](./README.md) · [Troubleshooting](./troubleshooting.md) →

This page collects menu items, persistence ownership, input behavior, limits, and security boundaries in one place. Workflow explanations remain in the linked guides.

## Menu reference

### S7R menu

| Item | Action |
| --- | --- |
| **About S7R…** | Version identity, independence, and project attribution. |
| **Settings…** | DeepSeek API-key status/write/remove and recent-Agent menu count. |
| **DSH Control Center…** | Native Agent model/reasoning, Preset, commands/modes, Skills, and plugin inventory. |
| **Scrapbook** | Browser-local editable source-aware cards. |
| **Monitor** | System metrics, live Agents/context, and DSH background Jobs. |
| **Display Control Panel…** | Work area, UI master, magnification, appearance, filters, and wallpaper. |
| **Clock** | Fixed-size live desk accessory. |
| **Puzzle** | Fixed-size solvable 4×4 sliding-number desk accessory. |

Clock and Puzzle appear below a separator to distinguish desk accessories from system applications.

### File menu

| Item | Action |
| --- | --- |
| **New Agent** | Opens fixed Preset/model/reasoning setup for the current Workspace. |
| **New from Stationery…** | Creates from a DSH Agent Preset with optional name and opening prompt. |
| **Open Agent…** | Opens Knowledge Desk's Agent/Workspace browser. |
| **Choose Folder…** | Uses DSH's native picker to register a Workspace. |
| **Browse Current Workspace** | Opens Finder at the current Workspace root. |
| **New Terminal** | Opens a Workspace-scoped zsh line console. |
| **Find…** | Opens scoped Global Find. |
| **Save** | Appears for TextEdit and saves with a version guard. |
| **Open Agent Timeline** | Appears for an Agent window and opens its complete event ledger. |
| **Stop Running Agent** | Appears for a running Agent and requests DSH cancellation. |
| **Close Window** | Closes the active S7R view; dirty TextEdit content requires confirmation. |

### Edit menu

Undo, Cut, Copy, Paste, and Select All use browser editing commands inside supported S7R applications. The same operations are available in S7R context menus for editable fields. Clipboard availability still follows browser permission/security rules.

### Window menu

| Item | Action |
| --- | --- |
| **Zoom** | Toggles the active resizable window between its prior bounds and work-area zoom. |
| **Collapse** | Collapses/expands the active window. |
| **Tile Windows** | Tiles eligible open windows and records the pre-tile layout. |
| **Restore Previous Layout** | Restores the recorded pre-tile bounds. |
| **Open Windows** | Focuses an open window; the active window is checked. |
| **Agents** | Opens one of the 1–9 most recent Agents (default 5). |

### Special menu

- **Clean Up Desktop** arranges aliases into a grid.
- **Open Trash** opens reversible alias Trash.
- **Empty Trash…** permanently removes only alias records after confirmation.

### Help menu

- **Show Balloon Help** toggles persistent delayed help.
- **S7R Guide…** opens the compact in-app workflow reference.

## Input and keyboard behavior

| Input | Behavior |
| --- | --- |
| Enter in Agent composer | Send prompt when idle; steer while running. |
| Shift-Enter in Agent composer | Insert newline. |
| Delete/Backspace on selected desktop aliases | Move aliases to Trash unless focus is editable. |
| Shift/Command-click alias | Toggle additive desktop selection. |
| Drag empty desktop | Marquee-select aliases. |
| Arrow Up/Down in open menu | Move among enabled items. |
| Home/End in open menu | Move to first/last enabled item. |
| Escape in open menu | Close menu. |
| Right-click editable text | S7R Undo/Cut/Copy/Paste/Select All. |

Browser-owned shortcuts such as Command-N and Command-W are intentionally not advertised as S7R commands because the page cannot reliably prevent the browser from creating or closing a tab.

## Application reference

| Application | Durable authority | Restored window? | Main limits |
| --- | --- | ---: | --- |
| Knowledge Desk/Agent | DSH Session + Chat projection | Yes | Context % depends on provider capacity data. |
| Finder | DSH Workspace filesystem | Yes | Cannot leave Workspace root; no file deletion. |
| TextEdit | DSH filesystem | Yes | Plain text/code; version-guarded save; no IDE features. |
| Preview | DSH file read + browser render | Yes | 25 MiB binary cap; raster PDF; no text layer. |
| Terminal | DSH terminal service | No | Line-oriented; no raw byte stream or PTY resize. |
| Timeline | DSH live/cold event ledger | Yes | Raw event representation, with adjacent-type folding. |
| Find | DSH files/events | Yes | Bounded traversal/result count. |
| Monitor | DSH live Agents/Jobs + host metrics | Yes | First CPU sample reports sampling; live Agents only in Agent tab. |
| Scrapbook | S7R browser storage | Yes | Local copy; not part of DSH history. |
| Clock/Puzzle | Ephemeral UI | Yes | Fixed size. |
| Display/Settings/Control Center | Browser preferences or DSH services | Yes | Capabilities follow DSH. |
| New Agent setup | Pre-creation UI | No | Fixed size; model catalog may fall back to Preset default. |

## Data ownership and persistence

### DSH-owned

- Session/Agent identity, title, status, event history, attachments, and archive state;
- Workspace registration and project files;
- model/Provider route, reasoning choice, Agent Preset, commands, Skills, and plugins;
- terminal owner/process/output/signals;
- credentials;
- background Jobs.

### S7R browser-owned

- display preferences and processed imported wallpaper;
- window bounds, z-order, zoom/collapse state, and tile-restore layout;
- desktop aliases and reversible alias Trash;
- Scrapbook cards;
- Markdown, Balloon Help, and recent-Agent-count preferences;
- pre-0.10 archive metadata used only for migration.

Browser records are versioned and validated. Malformed or unsupported records fail closed. Clearing site data resets the S7R-owned list but does not delete DSH-owned data.

### Ephemeral

- visible notifications;
- current Balloon Help bubble;
- open menu/context menu/dialog state;
- live Terminal windows across reload;
- incomplete New Agent setup.

## Operational limits

| Area | Limit |
| --- | --- |
| Binary file read | 25 MiB |
| Find traversal | 5,000 files |
| Find source read | 1 MiB per eligible file |
| Find result count | 200 |
| Find directory exclusions | Hidden directories and `node_modules` |
| Recent Agents in Window menu | 1–9, default 5 |
| UI master sizes | Native 10px or 12px base; native 8px or 10px semantic small text |
| Pixel magnification | Exact 1× or 2× |
| Imported wallpaper output | Bounded around 512px before placement |
| Terminal resize | Unsupported by current DSH public service |
| Plugin toggling | Not exposed; inventory is read-only |
| Markdown | Restricted safe subset; no raw HTML or rendered LaTeX |

## Context metrics

S7R shows the latest provider-reported prompt length. Percentage appears only when the active model advertised a context-window capacity. Composition shares are character-based estimates and exclude redundant streaming chunks where final message content already exists.

Monitor and Context Inspector do not fabricate unavailable values. Warnings begin at approximately 75% and become critical at approximately 90%.

## System metrics

CPU is sampled from deltas in host OS cumulative counters; the first observation is labelled sampling. On macOS, Active RAM is active + wired + compressed memory and excludes inactive/file cache. On other platforms, S7R uses total minus immediately free memory when that is the supported accounting. DSH process RSS is separate from whole-system RAM.

## Security summary

- The browser receives credential status, never stored secret readback.
- Package-specific host operations use an authenticated exact loopback route.
- All identifiers crossing that route are validated.
- File paths are re-contained under the inspected Workspace on every request.
- Existing-file writes require the previously read version.
- Terminal IDs remain bound to their live Agent owner.
- Markdown never injects raw HTML.
- Exports and screenshots must be checked for secrets, private conversation text, and personal paths.

Report credential exposure, path traversal, unsafe writes, terminal ownership errors, or injection using [SECURITY.md](../SECURITY.md).

## Visual and asset policy

S7R is inspired by System 7-era desktop interfaces but is not an Apple product. It ships no Apple logo, copied icon, system screenshot, proprietary font, sound, or extracted resource. UI icons/patterns and the Cat tile are original constructions. Fusion Pixel Font and PDF.js are documented in [THIRD_PARTY_NOTICES.md](../THIRD_PARTY_NOTICES.md).

## Additional references

- [Product and design specification](./design-spec.md)
- [Architecture](../ARCHITECTURE.md)
- [Compatibility](../COMPATIBILITY.md)
- [Troubleshooting](./troubleshooting.md)
