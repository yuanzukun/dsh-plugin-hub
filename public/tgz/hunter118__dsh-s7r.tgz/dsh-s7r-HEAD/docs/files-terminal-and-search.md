# Files, Terminal, and Find

← [Workspaces and Agents](./workspaces-and-agents.md) · [Documentation index](./README.md) · [Desktop and applications](./desktop-and-apps.md) →

S7R's file and shell tools operate through DSH and stay contained within registered Workspaces. They are working applications, not decorative Finder or Terminal mockups.

![A Workspace terminal overlapping native DSH Commands and Modes, Global Find, Knowledge Desk, and Monitor](./screenshots/s7r-workflows.png)

## Safety boundary

Choosing a folder registers a DSH Workspace. Every file operation resolves its requested path against the selected live or persisted Workspace root and rejects an escape.

This applies to:

- directory listing;
- text and binary reads;
- TextEdit saves;
- Preview reads;
- Find traversal;
- terminal working directories;
- file/event navigation from Timeline or search results.

Binary reads are capped at 25 MiB. Source-search reads have a smaller limit described under Global Find.

## Finder

Open Finder with **File → Browse Current Workspace**, by opening a Workspace row, or from a desktop alias.

Finder supports:

- directory navigation by double-click;
- **↑ Parent** navigation that stops at the Workspace root;
- manual **Refresh**;
- file type and size columns;
- **Open in Terminal** at the displayed directory;
- double-click routing to TextEdit or Preview;
- dragging entries to an Agent or the desktop;
- right-click Open, Open in Terminal, relative/absolute path copy, desktop placement, Workspace placement for folders, and Get Info.

Finder's context menu never offers destructive deletion of a real file. S7R Trash is only for desktop aliases.

## TextEdit

Text and source files open in a plain-text editor. TextEdit provides:

- editable text/code content;
- a dirty-state Save action in the toolbar and **File → Save**;
- **Run in Terminal** for the current file;
- Code or Plain Text status;
- S7R-owned Undo, Cut, Copy, Paste, and Select All menus.

### Conflict-aware saves

Reading an existing file returns a filesystem version. Save supplies that version back to DSH. If another process changed the file after the read, S7R reports a conflict rather than silently overwriting the newer content.

TextEdit is not a syntax-highlighting IDE, language server, or rich document editor. Its job is safe Workspace-contained plain-text editing.

## Preview

Images and PDFs open in Preview.

For images, Preview shows the detected MIME type and lets you switch temporarily between filtered and original display.

For PDFs, Preview uses bundled PDF.js code and worker support; no CDN is required. It provides:

- previous/next page;
- page count;
- zoom out/in;
- Fit Page;
- Fit Width;
- filtered/original inspection.

PDF pages are rasterized for display. There is no selectable PDF text layer and Preview does not edit the source file.

### Preview filters

Display Control Panel can filter image previews and PDF pages independently. The shared style is either:

- **1-bit Dither** — pure black/white ordered patterns simulate tonal range;
- **Direct Grayscale** — continuous luminance gray.

Filtering is cached and non-destructive. It does not modify the file, conversation images, code, or source text. See [Display and wallpaper](./display-and-wallpaper.md).

## Paths and drag-and-drop

Dragging a Finder item into an Agent inserts a textual path:

- inside that Agent's Workspace: `./relative/path`;
- outside that Agent's Workspace: the absolute path.

The rule is automatic and deterministic; there is no modifier-key behavior that a browser cannot reliably guarantee.

Dragging a file/folder to the desktop creates an alias. A directory can be represented as either a Finder alias or a Workspace alias; see [Desktop and applications](./desktop-and-apps.md).

## Terminal

Terminal uses DSH's official terminal service and terminal-bash backend. The configured shell is:

```text
/bin/zsh -f -i
```

`-f` avoids user startup files that can make behavior slow or unpredictable; `-i` supplies an interactive zsh environment. DSH owns process spawning, sandbox policy, identity, signaling, retained output, and cleanup.

### Open a Terminal

- **File → New Terminal** starts in the current/recent Workspace.
- Finder's **Open in Terminal** starts in the displayed directory.
- TextEdit's **Run in Terminal** opens a terminal and runs the current path through the supported line interface.

Terminal does not require a visible Agent. When no live owner exists, S7R creates a fresh blank DSH owner in the current/recent Workspace so the shell does not fail with a missing Knowledge Desk Session.

### Interaction model

Type a command and choose **Send Line** or press Enter. S7R acknowledges the submitted line immediately and polls DSH's retained foreground output without overlapping reads. **Interrupt** sends `SIGINT` through DSH.

DSH `0.1.7-rc.2` does not expose a raw browser keystroke stream or a post-spawn PTY resize method. The result is a responsive real line console, not an xterm-style raw attachment:

- full-screen TUI programs are not the target interaction;
- terminal window resizing reflows the local output view but does not change backend PTY rows/columns;
- the backend terminal identity remains owner-scoped;
- live Terminal windows are not restored after a page reload because a serialized window cannot safely reattach its process.

## Global Find

Open **File → Find…**. File and Agent scopes are independent, so one query can search a combination of them.

### File scopes

**File and folder names** searches names without reading content. It is the fastest way to navigate a large Workspace.

**Source/text contents** reads eligible text/code and returns matching snippets and line numbers.

The folder selector can target one registered Workspace or all registered Workspaces.

### Agent scopes

Choose one:

- **Do not search Agents**;
- **Conversation messages** for projected user/assistant text;
- **All event streams** for complete persisted logs including messages, tools, reasoning, chunks, and context records.

The Agent selector can target the current Agent or all Agents. All-event search includes messages; enabling it does not require a second message search.

### Result navigation

Opening a result routes according to its type:

- folder name → Finder at that directory;
- file name → Finder/TextEdit/Preview as appropriate;
- source match → TextEdit at the file context;
- conversation message → the Agent;
- event match → the exact Agent Timeline record.

### Search bounds

File traversal deliberately stops at safe, predictable limits:

- at most 5,000 files are traversed;
- hidden directories and `node_modules` are skipped;
- at most 1 MiB is read from each source file;
- at most 200 results are returned.

These are product limits, not claims that no larger Workspace exists. Use a dedicated repository search tool when you need exhaustive analysis beyond them.

## Common distinctions

| Need | Use |
| --- | --- |
| Find a file without reading it | Names scope |
| Search code/text | Source contents |
| Search what the user and Agent said | Conversation messages |
| Search tool calls, reasoning, context, or chunks | All event streams |
| Inspect events in sequence | Timeline |
| Edit safely | TextEdit |
| Run a normal line command | Terminal |
| Run a full-screen raw TUI | Use an external terminal; DSH does not expose the required raw/resize seam |

## Related documentation

- [Workspaces and Agents](./workspaces-and-agents.md) for current Workspace selection and path drops.
- [Display and wallpaper](./display-and-wallpaper.md) for Preview filters.
- [Troubleshooting](./troubleshooting.md) for Terminal, folder picker, save, and search issues.
