# Display and wallpaper

← [Desktop and applications](./desktop-and-apps.md) · [Documentation index](./README.md) · [DSH integration](./dsh-integration.md) →

Display Control Panel separates logical work area, UI master size, integer magnification, System UI appearance, content filters, and wallpaper. Keeping these concerns separate is what lets S7R stay sharp instead of scaling one large rendered image.

![Display Control Panel scrolled to wallpaper options while the Cat tile and several applications remain visible](./screenshots/s7r-display.png)

Open **S7R → Display Control Panel…**.

## Desktop work area

Choose one logical layout:

| Setting | Logical size | Purpose |
| --- | ---: | --- |
| **Fit Browser** | Recomputed from viewport | Uses available browser space and adapts after resize. |
| **Classic** | 512 × 342 | Very compact period-style canvas. |
| **Compact** | 640 × 480 | Familiar small desktop with more usable room. |
| **Standard** | 832 × 624 | Mid-sized fixed workspace. |
| **Expanded** | 1024 × 768 | Documentation/screenshot baseline and highest fixed information capacity. |

Fixed work areas preserve their logical size and may require browser scrolling when magnified. Fit Browser recomputes its logical dimensions so the desktop continues to fit.

Changing the work area clamps windows and aliases to safe bounds. Window positions remain logical coordinates rather than physical device pixels.

## Interface size

S7R has two separate bitmap UI masters:

- **Compact — 10px** base text with native 8px semantic small text;
- **Comfortable — 12px** base text with native 10px semantic small text.

Menus, title bars, controls, spacing, scrollbars, window defaults, and small-text faces change together. S7R does not fake the compact setting by shrinking a larger font, which would break the pixel grid.

The bundled proportional and monospaced Fusion Pixel Font faces cover Simplified Chinese at the supported masters. Buttons use the common base control size; semantic small text is reserved for metadata, headings, badges, paths, and status detail.

## Integer pixel magnification

Choose:

- **1×** for native logical pixels;
- **2×** for exact integer magnification.

At 2×, the whole logical UI is magnified by an integer and uses pixel-preserving rendering. Pointer deltas, menu/help placement, drag/drop coordinates, window constraints, and wallpaper tiles are converted through the same logical coordinate system.

With Fit Browser, S7R halves the logical work area before exact 2× magnification. This preserves a fitted desktop rather than creating a giant scroll surface.

Do not use browser zoom as a replacement for S7R magnification. Fractional browser zoom can resample bitmap fonts, one-pixel borders, and patterns.

## System UI appearance

### Monochrome

The default uses classic grayscale System UI. Balloon Help remains gray and status states rely on value, shape, and pattern instead of color alone.

### Muted Color

Muted Color keeps the desktop and windows largely neutral and adds restrained low-saturation accents to:

- Balloon Help;
- status lights;
- notifications;
- exceptional/warning states;
- coordinated built-in wallpapers.

It is intentionally not a bright full-color theme. Information and focus remain readable in monochrome.

## Preview content filters

Two independent switches control whether S7R filters:

- images in Preview;
- rasterized PDF pages in Preview.

The shared filter style is:

- **1-bit Dither** — an ordered black/white pattern simulates gray levels;
- **Direct Grayscale** — continuous luminance gray.

Preview's **Inspect Original** temporarily bypasses the active filter. The filter is visual and cached; it never modifies the file. Agent images, source code, and text remain unchanged.

## Built-in wallpaper

Classic Dots is the default. The built-in set is:

- **Classic Dots**;
- **Desk Gray**;
- **Pinstripes**;
- **Cat**.

Monochrome mode uses grayscale variants. Muted Color switches built-ins to coordinated low-saturation blue-green variants. Patterns remain aligned to logical pixels at both magnifications.

### Cat tile

Cat is an original seamless repeating tile designed so the edge fragments match when repeated horizontally and vertically. It is rendered through the same low-resolution treatment options as imports, which prevents a high-resolution illustration from looking pasted over a pixel UI.

Changing wallpaper filter style or pixel block size re-renders Cat.

## Import wallpaper

Choose treatment before importing:

- 1-bit Dither or Direct Grayscale;
- **Fine — 1px blocks** or **Classic — 2px blocks**;
- **Tile** or **Fill** placement.

Then choose **Import Image…**. Supported input types are PNG, JPEG, GIF, and WebP.

The import pipeline:

1. decodes the selected image locally;
2. samples a genuine low-resolution grid;
3. applies grayscale or 1-bit dithering on that grid;
4. bakes an integer nearest-neighbor enlargement, capped around 512px;
5. stores the processed PNG in the browser-local wallpaper library.

This order matters. Enlarging first and applying a CSS filter would preserve too much source detail and create soft or noisy edges.

Imported images accumulate in a named dropdown with processed dimensions. **Remove Selected** removes that processed browser-local wallpaper. S7R does not retain the original source file after processing; re-import the original to apply a different treatment.

### Tile versus Fill

- **Tile** repeats at pixel size and is best for seamless patterns or compact processed images.
- **Fill** covers the desktop and may crop to preserve coverage.

An arbitrary imported image is not automatically made seamless. The built-in Cat is explicitly designed as a tile; other images may show boundaries unless their source edges already match.

## Performance notes

S7R uses CSS patterns and preprocessed bitmap assets instead of applying a live full-desktop pixelation filter each frame. This keeps window dragging and streaming responsive. Preview filtering is limited to Preview content and cached; imported wallpaper is processed once on import rather than on every repaint.

If movement looks blurry or slow:

1. return browser zoom to 100%;
2. use S7R's 1× or 2× setting;
3. try Fit Browser at 1×;
4. avoid extremely large animated source images;
5. confirm hardware acceleration has not been disabled in the browser.

More display recovery steps are in [Troubleshooting](./troubleshooting.md).

## Persistence

Display preferences and the processed import library are separate versioned browser-local records. Malformed data fails closed to defaults. Clearing site data resets display choices and deletes processed imports, but does not affect DSH Workspaces, files, Agents, credentials, or history.
