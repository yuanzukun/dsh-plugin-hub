# DSH integration

← [Display and wallpaper](./display-and-wallpaper.md) · [Documentation index](./README.md) · [Reference](./reference.md) →

S7R is a DeepSeek Harness plugin, not an independent chat client. It projects DSH's public state into a System 7-style workstation and keeps DSH authoritative for anything that affects an Agent, Workspace, file, process, credential, or durable event log.

## DSH Control Center

Open **S7R → DSH Control Center…** or use an Agent context menu/**Other…** panel. Select an Agent at the top; each tab reads that Agent's real DSH services.

### Model and Preset

The Agent tab shows:

- provider/model route;
- supported reasoning efforts and current selection;
- installed DSH Agent Presets;
- whether the Agent is still blank enough to accept a different Preset;
- model-catalog failures reported by individual providers.

DSH permits Preset recomposition only while an Agent is blank. After the first turn, Control Center explains the lock instead of drawing a control that cannot safely reproduce the logged tool composition. Use Stationery or New Agent setup for a different composition.

### Commands and modes

The Commands tab lists the selected Agent's registered slash commands with descriptions and argument hints. Modes such as Plan appear only when that Agent's Preset registered them. Running an action uses the same DSH command path as the conversation composer.

S7R does not hard-code a list of modes because the actual command catalog belongs to the deployed composition.

### Skills

The Skills tab lists project Skills visible to the Agent, including description, optional usage guidance, and whether the model may invoke the Skill itself or it is user-only. **Invoke** follows DSH's `/skill` path.

A cold Agent may need to be opened/prepared before DSH attaches its project Skill catalog. Skill failure is isolated: it does not hide models, Presets, commands, or process-wide plugin inventory.

### Plugins

The Plugins tab provides searchable loader inventory:

- module name;
- entry ID;
- enabled/disabled loader status;
- active/off/not-mounted fiber phase;
- enabled and active totals.

DSH `0.1.7-rc.2` exposes this inventory as read-only. S7R intentionally does not show enable/disable switches that the runtime cannot commit safely. Add or remove DSH profile plugins with the DSH CLI, then restart the profile.

## New Agent setup and Stationery

Both creation surfaces consume DSH Agent Presets.

- **New Agent setup** adds model and reasoning selection before opening a conversation.
- **Agent Preset Stationery** keeps the interface small: Workspace, Preset, optional name, optional opening prompt.

Neither stores an S7R-only composition. Preset descriptions, default/broken state, model-facing plugins, and tools remain owned by DSH.

See [Workspaces and Agents](./workspaces-and-agents.md) for the full workflow.

## Credentials

**S7R → Settings…** is an adapter over DSH's credential service.

S7R can:

- report whether `DEEPSEEK_API_KEY` is configured;
- report the source label when DSH provides one;
- report whether that source is writable;
- set/replace a DSH-managed value;
- remove a writable DSH-managed value.

S7R cannot read a stored secret back into the browser. Credentials are not serialized into desktop state, Agent exports, Scrapbook, logs, screenshots, or fixtures. Credential operations use DSH's authenticated loopback service.

## What DSH owns

| Domain | DSH authority used by S7R |
| --- | --- |
| Session catalog and control | Creation, retain/release, prompt, steer, cancel, rename, history pagination, attachments, live status |
| Conversation | Authoritative Chat projection from `UiConversation` |
| Workspaces | Folder picker, registration, connection, navigation, archive/unarchive routing |
| Agent archive | Native reversible archive set and operations |
| Jobs | Observable per-Session background roster |
| Models and Presets | Typed Remote catalogs and mutation routes |
| Commands and Skills | Agent-scoped typed catalogs and invocation paths |
| Plugins | Process-wide read-only loader inventory |
| Credentials | Value-free status plus write/remove operations |
| Event history | Live immutable event snapshots and cold persistence read handles |
| Filesystem | Resolution, listing, versioned reads, version-guarded writes under inspected Session cwd |
| Terminal | Owner identity, backend choice, process, retained output, signals, and close |

## What S7R owns

S7R browser storage is restricted to presentation and reversible convenience state:

- display preferences and processed imported wallpaper;
- window geometry, z-order, zoom/collapse state, and restorable tile layout;
- desktop aliases, alias selection positions, and alias-only Trash;
- Scrapbook cards;
- Markdown-reading and Balloon Help preferences;
- recent-Agent menu limit;
- pre-0.10 local archive metadata retained only for migration.

S7R does not become the source of truth for the real object referenced by an alias or card.

## Browser integration

S7R registers the supported DSH Web root slot at higher priority and supplies the complete desktop shell. It does not query, hide, or mutate DSH DOM nodes. Native controller/hooks remain the data and control source even though the visible root is replaced.

The Agent window retains a DSH Session, combines its control snapshot with the Chat target from `UiConversation`, and releases retained references when S7R unloads. Multiple windows can bind different Sessions—or the same Session—without duplicating host Agents.

Typed Remote endpoints provide credentials, model routes, Presets, Skills, commands, and plugin inventory. Each catalog is loaded independently so one unavailable service does not blank unrelated controls.

## Host integration

S7R's host plugin exposes bounded package-specific operations through an authenticated exact Connection Fetch route at `/api/knowledge-desk`. The browser cannot ask it to execute arbitrary host code.

Host operations use DSH services for:

- live Agent roster and exact terminal owner identity;
- immutable live event snapshots;
- scoped cold persistence read handles;
- Workspace-contained filesystem access;
- terminal operations;
- CPU/RAM/process metrics.

Identifiers crossing the route are validated. Every file path is re-resolved beneath the inspected Workspace. The route stays inside DSH Connection's loopback trust/authentication fence.

## Archive, Trash, and deletion

These concepts are deliberately separate:

- **Archive Agent** calls DSH's native reversible archive operation. Durable history remains.
- **Restore Agent** calls native unarchive.
- **Trash alias** moves only a browser-local desktop pointer into reversible S7R Trash.
- **Delete Scrapbook card** removes only a browser-local copy.
- **Real file deletion** is not offered by Finder.

Pre-0.10 local Agent archive records stay readable only as a migration layer. All new Agent archive state is DSH-owned.

## Jobs and Monitor

Monitor's Background tab observes DSH Jobs. Closing an Agent window does not imply that every job stopped, and S7R does not maintain a competing background queue. The live Agent tab intentionally reports live Agents; Timeline, Find, export, Finder, TextEdit, and Preview can also inspect cold persisted Sessions.

## Known DSH boundaries

- Terminal has line send/read/signals/close but no raw browser byte stream or supported PTY resize.
- Plugin inventory is read-only.
- A cold Agent's project Skill catalog may not exist until the Agent is prepared.
- Context percentage appears only when DSH/provider data includes a context-window capacity.
- The public interfaces may change while DSH remains in release-candidate development.

The exact package baseline and migration seams live in [COMPATIBILITY.md](../COMPATIBILITY.md). The implementation boundary is described in [ARCHITECTURE.md](../ARCHITECTURE.md).

## Compatibility policy

S7R does not declare support based only on TypeScript compilation. A DSH baseline is supported after exact dependency installation, typechecks, deterministic tests, production builds, packed-plugin installation into a clean DSH Web profile, browser workflow checks, and clean diagnostics.

S7R `0.10.x` supports DSH `0.1.7-rc.2`. The npm `next` line is an early-warning target, not a supported production pairing until the same gate passes.
