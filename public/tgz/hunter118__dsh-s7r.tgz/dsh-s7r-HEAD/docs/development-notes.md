# Development notes

This is a concise engineering record for contributors. Release-facing changes are tracked in [`../CHANGELOG.md`](../CHANGELOG.md); the stable product intent lives in [`design-spec.md`](./design-spec.md).

## Baseline

- Runtime-tested DSH target: `0.1.7-rc.2` (npm `latest`)
- S7R compatibility line: `0.10.x`
- Audited preview: `0.2.0-rc.1` (npm `next`; not claimed as supported)
- Latest audit date: 2026-09-29
- Node target: 22.19+ or 24+
- Package manager: pnpm 11.19.0

DSH is in developer preview and permits compatibility-breaking changes. All version-sensitive access therefore remains under `src/dsh-compat/`.

## Implementation milestones

- **0.1** established the dual-face DSH bundle, loopback RPC boundary, System 7 primitives, desktop/window reducer, and first Agent/Timeline/File applications.
- **0.2** added secure credential setup, native folder selection, Agent reopening, independent zsh launch, and browser-safe menu behavior.
- **0.3** replaced whole-desktop rasterization with native bitmap fonts and discrete component-level pixel metrics.
- **0.4** introduced Fit Browser, 10px/12px UI sizing, grayscale depth, streamlined Preview filters, Agent removal/archive handling, faster Terminal polling, and S7R/Knowledge Desk naming.
- **0.5** added system metrics, Puzzle, wallpaper import/processing, and the seamless Cat pattern.
- **0.6** added the Workspace launcher, Agent search/rename/export/archive restore, global Find, integrated background monitor, Context Inspector, desktop aliases, state restore, and notifications.
- **0.7** completed desktop multi-select/Trash, Agent side panels, safe Markdown rendering, relative path drops, toolbar reflow fixes, and Classic Dots defaults.
- **0.8** made Workspace selection and Agent browsing explicit, added non-disruptive stream following, contextual menus, an Agent switcher, and reversible window tiling.
- **0.9** completed object-level contextual menus, native DSH model/Preset/command/Skill/plugin surfaces, Agent Preset Stationery, and exact-scale Balloon Help.
- **0.9.1** added native 8px small-text faces and removed larger-master downscaling from every semantic small-text surface.
- **0.9.2** contained the long plugin inventory, unified DSH Control Center tab typography, and runtime-validated the compatibility boundary against the rc.8 source merge.
- **0.9.3** added S7R-owned text editing menus, guided Agent setup, muted period color, coordinated blue-green wallpapers, fixed desk accessories, and a scale-safe Stationery action bar.
- **0.9.4** moved the installed/runtime baseline to Harness `0.1.1-rc.2`, retained the rc.7/rc.8 peer branch, and recorded the incompatible `0.1.2-alpha.1` client architecture boundary.
- **0.10.0** migrated to Harness `0.1.7-rc.2`: retained Sessions plus the Chat projection, Workspace UI navigation, typed Remote catalogs, Jobs observation, scoped persistence reads, and native archive/unarchive.

## Architecture decisions

- DSH remains authoritative for sessions, events, filesystem access, terminal ownership, credentials, and background jobs.
- Browser-local state is reserved for S7R presentation and reversible convenience state; DSH owns Agent archive state.
- The root slot is replaced through the supported slot service; no DSH DOM is queried or hidden.
- The client bundle embeds PDF.js so Preview needs no CDN or runtime network access.
- Pixel presentation uses native font masters and integer CSS/layout metrics. Only content images are raster-filtered.
- Desktop Trash contains aliases only and cannot delete real user data.
- Pre-0.10 local archive records remain readable for migration; all new archive/restore actions use DSH's native reversible API.

## Verification summary

The 0.10.0 release candidate has passed:

- strict host and client TypeScript checks;
- 17 Vitest files / 70 deterministic tests;
- production host and self-contained client builds;
- clean tarball installation through the official Harness `0.1.7-rc.2` CLI into an isolated Web profile;
- root replacement, multi-window focus/move/resize/zoom/collapse/tile/reflow;
- Workspace choice, Agent creation/reopen/rename/export/archive/restore;
- current-Workspace Agent grouping/filtering/sorting and Workspace-targeted creation;
- global Find at file-name, source, message, and all-event depth;
- persisted Timeline, folded chunks, Monitor system/background views, and Context Inspector;
- Finder navigation, version-guarded TextEdit saves, image/PDF Preview;
- independent real zsh launch with retained low-latency output;
- Scrapbook, Clock, solvable Puzzle, wallpaper import, and seamless Cat tiling;
- Fit Browser and fixed resolutions at 1×/2× with 10px/12px UI metrics;
- desktop aliases, marquee multi-selection, group dragging, Trash restore, and state reload;
- contextual menu contents, keyboard menu navigation, Agent switching, and exact post-tile layout restoration;
- native DSH model/reasoning, Preset, command/mode, Skill, and plugin inventory views;
- DSH Agent Preset Stationery and persistent Balloon Help at Fit Browser 1×/2×;
- non-disruptive streamed-output following with an explicit new-output return control;
- safe Markdown on/off and monochrome Emoji normalization;
- clean browser diagnostics apart from expected restart warnings and PDF.js's bundled worker-fallback warning.

## Known upstream limitation

DSH 0.1.7's terminal API exposes spawn, line send, retained read, signal, status, and close. It does not expose a raw browser PTY byte stream or post-spawn terminal resizing. S7R therefore provides a real line-oriented zsh terminal, reflows its local viewport, reports `terminalResize: false`, and keeps the future resize adapter isolated. It does not reach into private backend state.

## Contributor verification loop

For normal changes:

```sh
pnpm install --frozen-lockfile
pnpm docs:check
pnpm check
pnpm pack
```

`pnpm check` includes the documentation validator, strict typechecks, deterministic tests, and production builds. The documentation ownership matrix in [`../CONTRIBUTING.md`](../CONTRIBUTING.md) is part of the change contract: user-visible work updates its primary guide and the Unreleased changelog in the same pull request.

For changes touching DSH adapters or layout, additionally install the tarball into a disposable DSH Web profile and smoke-test Fit Browser at 1×/2×. Update [`../COMPATIBILITY.md`](../COMPATIBILITY.md), [`dsh-integration.md`](./dsh-integration.md), and architecture notes whenever an upstream seam changes.
