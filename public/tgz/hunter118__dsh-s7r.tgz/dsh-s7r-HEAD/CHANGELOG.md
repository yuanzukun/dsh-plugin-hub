# Changelog

All notable user-facing changes to S7R are documented here. The project follows semantic versioning while its DSH dependency remains in release-candidate status.

## Unreleased

### Documentation

- Reorganized the public README as a concise project entry point and added a linked multi-page manual covering installation, Workspaces/Agents, files/Terminal/Find, desktop applications, display/wallpaper, native DSH integration, exhaustive reference, and troubleshooting.
- Added an indexed documentation ownership matrix, contributor maintenance rules, pull-request documentation checklist, and a local-link/index validator that now runs as part of `pnpm check`.
- Corrected stale documentation references to the removed View menu, monochrome Balloon Help, DSH 0.1.7 plugin inventory, and the current compatibility baseline.

## 0.10.0 - 2026-09-29

### Changed

- Migrated the complete browser integration to the DeepSeek Harness `0.1.7-rc.2` controller architecture and removed the retired `dsh-client-runtime` dependency.
- Agent windows now retain/release Sessions explicitly and render the authoritative `UiConversation` Chat projection; folder choice uses `UiWorkspace`, and DSH Control Center catalogs use typed Remote endpoints.
- Monitor background work now follows the DSH Jobs controller, while Agent archive and restore use DSH's native reversible operations.
- Host event and cold-history access now use `snapshotEvents()` and scoped persistence read handles, matching the current public DSH APIs.

### Compatibility

- Requires DSH `0.1.7-rc.2`; S7R 0.9.x remains available for earlier DSH release candidates.
- Retains read compatibility for pre-0.10 S7R local archive records and older chunk-based token ledgers without making them the source of truth for new state.

### Verified

- Passed strict TypeScript checks, 17 Vitest files / 70 deterministic tests, production Host/client builds, frozen-lockfile installation, package inspection, and clean-profile DSH Web validation.

## 0.9.4 - 2026-08-29

### Changed

- Raised the installed and runtime-tested DeepSeek Harness baseline to npm `0.1.1-rc.2` while preserving the explicit `0.1.0-rc.7`/`0.1.0-rc.8` compatibility branch.
- Rebuilt the lockfile against the complete rc.2 package graph and documented the separate `0.1.2-alpha.1` client-runtime/APIProxy migration boundary.

### Verified

- Installed the packed plugin through the official `0.1.1-rc.2` CLI into a clean Web profile and confirmed root replacement, Knowledge Desk, the 142-entry native plugin inventory, Terminal services, and an error-free browser console.

## 0.9.3 - 2026-08-20

### Added

- A fixed New Agent setup window selects the DSH Agent Preset, provider model, and reasoning level before opening the conversation.
- Display Control Panel can switch between the default monochrome System UI and restrained period-style color accents.
- Muted Color gives every built-in wallpaper a coordinated low-saturation blue-green palette, including a pixel-preserving tinted Cat tile.
- Editable fields now use S7R-owned Undo/Cut/Copy/Paste/Select All contextual menus while native browser context menus are suppressed throughout the desktop.

### Changed

- Balloon Help is gray in monochrome mode and softly tinted only in color mode.
- Clock and Puzzle are fixed-size desk accessory windows and remain fixed when other windows are tiled.
- The redundant View menu was removed; Clock and Puzzle now occupy a separated accessory group at the bottom of the S7R menu.

### Fixed

- Stationery Pad now keeps its action bar outside the scrolling form, so the Opening prompt field cannot show through beneath Choose Folder and Create Agent at either 1× or 2×.

## 0.9.2 - 2026-08-20

### Changed

- Built and browser-tested S7R against the official DSH `0.1.0-rc.8` source merge while retaining the published-package `0.1.0-rc.7` install baseline.
- Preserved the new optional image-capability metadata on native DSH commands so it is not discarded by the S7R adapter.

### Fixed

- The long Plugins inventory is now clipped and scrolled inside the DSH Control Center body instead of painting over its toolbar or tabs.
- Model & Preset, Commands & Modes, Skills, and Plugins tabs now use the same base bitmap font and control height as every other button.

## 0.9.1 - 2026-08-20

### Fixed

- Small labels now use native Fusion Pixel Font masters instead of rendering the active 10px/12px face at a smaller CSS size.
- Compact UI uses the Simplified Chinese 8px proportional/monospaced faces for menu section headings, metadata, badges, desktop labels, and other semantic small text; Comfortable UI uses the native 10px faces for the same role.
- View/Window menu headings such as **Open Windows** and **Agents** now retain their intended pixel grid.

## 0.9.0 - 2026-08-20

### Added

- System 7-style contextual menus for the desktop, aliases, Trash, Knowledge Desk Agents and Workspaces, and Finder entries, including Open, Get Info, portable/absolute path copy, desktop placement, Agent management, and safe alias-only deletion.
- A native DSH Control Center for model and reasoning routes, blank-Agent Preset selection, registered commands/modes, project Skills, and authoritative plugin-loader inventory.
- DSH Agent Preset Stationery for creating a new Workspace-owned Agent from an installed Preset with an optional name and opening prompt.
- Optional persistent Balloon Help with delayed pointer hover, keyboard-focus support, dialog/menu suppression, edge-aware placement, and exact 1×/2× logical-coordinate mapping.

### Changed

- DSH capabilities are loaded independently so an unavailable cold-session Skill catalog does not hide model, command, Preset, or plugin data.
- The in-app guide now documents contextual menus, Stationery, DSH controls, Trash safety, and Balloon Help.

## 0.8.0 - 2026-08-20

### Added

- Explicit current-Workspace selection with Workspace-scoped Agent creation and browsing.
- Agent filters for Workspace scope and run state, plus recent/name/status sorting and Workspace grouping.
- A reversible **Window → Tile Windows / Restore Previous Layout** workflow.
- A live Agent switcher in the Window menu and keyboard navigation within menus.
- A Settings control for showing 1–9 recent Agents in the Window menu (default 5).
- A **New output** control when fresh streamed content arrives while reading earlier conversation history.

### Changed

- File, View, and Window menus now follow the active application and avoid irrelevant or duplicate commands.
- Knowledge Desk opens at a productive two-pane size and safely enlarges undersized restored launcher/Agent windows once.
- Live output follows the bottom only while the reader is already there, so streaming no longer steals the scroll position.
- The highlighted new-output button now uses a System 7 gray control with a black label, avoiding inverse-text rendering during active streaming.

## 0.7.0 - 2026-08-19

### Added

- Desktop marquee multi-selection, group dragging, alias-only Trash, Put Away, and Empty Trash.
- Agent Context and Other side panels with rename, export, archive, desktop placement, manual compaction, summarized handoff, and Markdown preference.
- Safe completed-output Markdown for headings, emphasis, code, lists, quotes, and tables.
- Relative Workspace-path drops into Agent composers.

### Changed

- Classic Dots is now the default wallpaper.
- Agent and Scrapbook toolbars have larger minimum widths and single-line status controls.
- Agent menu actions live under File; desk accessories remain in the S7R application menu.

## 0.6.0 - 2026-08-18

### Added

- Workspace launcher and persisted desktop/window restoration.
- Agent search, rename, reversible archive/restore, and complete Markdown/JSON export.
- Global Find across file names, source contents, conversations, and complete event streams.
- Integrated Monitor background-work view and on-demand Agent Context Inspector.
- Desktop aliases for Workspaces, Agents, files/folders, and Scrapbook cards.
- Minimal completion notifications.

## 0.5.0 - 2026-08-18

### Added

- Host CPU, active RAM, and DSH process RSS metrics.
- Solvable 4×4 Puzzle desk accessory.
- Built-in wallpapers, imported wallpaper library, 1-bit/grayscale processing, and seamless Cat tiling.

## 0.4.0 - 2026-08-18

### Added

- Fit Browser layout, exact 1×/2× magnification, Compact 10px and Comfortable 12px UI sizes.
- Direct grayscale and ordered 1-bit Preview filters.
- Agent deletion/archive UI, faster Terminal output polling, Timeline chunk folding, and Scrapbook copy actions.

### Changed

- Renamed the workstation shell to S7R and retained Knowledge Desk as the Workspace/Agent application.
- Replaced whole-desktop pixel filtering with native bitmap fonts and component-level pixel design.

## 0.3.0 - 2026-08-18

### Changed

- Rebuilt the interface around native Fusion Pixel Font masters and discrete System 7-style control metrics for crisp interaction.

## 0.2.0 - 2026-08-17

### Added

- Secure `DEEPSEEK_API_KEY` settings, native folder selection, Agent reopening, and independent zsh launch.

## 0.1.0 - 2026-08-17

### Added

- Initial DSH dual-face plugin, System 7 desktop/window manager, Knowledge Desk, Finder, TextEdit, Preview, Terminal, Timeline, Monitor, Scrapbook, Clock, and Display.
