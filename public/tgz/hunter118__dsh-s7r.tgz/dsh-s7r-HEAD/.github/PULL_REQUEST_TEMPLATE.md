## Summary

Describe the user-visible or engineering change.

## Why

Explain the workflow problem or compatibility issue being solved.

## Verification

- [ ] `pnpm check`
- [ ] `pnpm pack`
- [ ] Browser smoke test when UI or DSH adapters changed
- [ ] No secrets, personal paths, or private conversation data in fixtures/screenshots

## Documentation

- [ ] Updated the primary guide named in the documentation matrix, or this change has no user-visible/documented effect
- [ ] Updated `CHANGELOG.md` for a user-visible change
- [ ] Updated `COMPATIBILITY.md`, `ARCHITECTURE.md`, and DSH integration docs when an upstream seam changed
- [ ] Updated screenshots when the documented visual workflow materially changed
- [ ] `pnpm docs:check`
