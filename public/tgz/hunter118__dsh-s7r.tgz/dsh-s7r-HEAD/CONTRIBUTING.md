# Contributing to S7R

Thank you for improving S7R. Changes should preserve both halves of the project: a useful DeepSeek Harness workstation and a coherent bitmap-oriented System 7-era interface.

Read the [documentation index](./docs/README.md), [product specification](./docs/design-spec.md), [architecture](./ARCHITECTURE.md), and [compatibility notes](./COMPATIBILITY.md) before changing behavior.

## Development setup

Required baseline:

- Node.js `22.19+` or `24+`;
- pnpm `11.19.0` through Corepack or an equivalent pinned installation;
- DeepSeek Harness `0.1.7-rc.2` for installed browser testing.

```sh
corepack enable
pnpm install --frozen-lockfile
pnpm check
pnpm pack
```

`pnpm check` runs, in order:

1. documentation link/index validation;
2. strict host and client TypeScript checks;
3. deterministic Vitest coverage;
4. production host and self-contained browser builds.

Install a source checkout into the Web profile for interactive validation:

```sh
dsh plugin --profile web add .
dsh --profile web --dump-config
dsh web
```

When replacing another S7R build, stop DSH and remove the existing profile entry first:

```sh
dsh plugin --profile web remove dsh-s7r
```

## Repository map

| Path | Responsibility |
| --- | --- |
| `src/index.ts` | DSH host plugin registration and authenticated package route. |
| `src/client/` | Browser plugin entry and DSH root-slot integration. |
| `src/dsh-compat/` | All version-sensitive DSH browser/host adapters and protocol types. |
| `src/desktop/` | Desktop root, window reducer, menu bar, resolution, aliases, context menus, and persistence wiring. |
| `src/system7/` | Shared bitmap-oriented primitives, window chrome, help, and visual metrics. |
| `src/apps/` | Knowledge Desk, DSH controls/Stationery, files, Find, Monitor, accessories, Timeline, and Trash. |
| `src/display/` | Display preferences, content filters, and wallpaper processing. |
| `src/storage/` | Validated/versioned browser-local records. |
| `tests/` | Deterministic behavior and adapter tests. |
| `docs/` | User guides, screenshots, product specification, and development notes. |

Keep unstable DSH assumptions inside `src/dsh-compat/`. Do not reach into private Session maps, terminal backend maps, subprocess handles, or DSH's rendered DOM.

## Normal verification loop

For every change:

```sh
pnpm docs:check
pnpm typecheck
pnpm test
pnpm build
pnpm pack
```

`pnpm check` is the shorter equivalent of the first four commands. Inspect the packed archive when package files, assets, or documentation change.

For UI changes, smoke-test:

- Fit Browser at 1× and 2×;
- Compact 10px and Comfortable 12px when typography or control geometry changed;
- Expanded 1024 × 768 when screenshots or dense layouts changed;
- keyboard focus and context menus;
- reload/restore behavior;
- browser console and DSH host output.

For DSH adapter changes, use a clean isolated Web profile and verify folder choice, Agent creation, prompt/steer, Context, Timeline/export, archive/restore, credentials, Control Center, Jobs/Monitor, Finder, and Terminal. Compilation alone is not compatibility evidence.

## Documentation is part of the change

User-visible behavior is not complete until its documentation is updated. Do not postpone documentation to a later cleanup pull request.

Use this ownership matrix:

| Change area | Required primary page | Also inspect |
| --- | --- | --- |
| Install, CLI, Node/pnpm, first run, upgrade, remove | [`docs/getting-started.md`](./docs/getting-started.md) | `README.md`, Troubleshooting, release workflow |
| Workspace, Knowledge Desk, Agent, Context, Timeline, Stationery | [`docs/workspaces-and-agents.md`](./docs/workspaces-and-agents.md) | Reference, in-app Guide, Changelog |
| Finder, TextEdit, Preview, Terminal, path rules, Find | [`docs/files-terminal-and-search.md`](./docs/files-terminal-and-search.md) | Reference, Troubleshooting |
| Desktop, windows, aliases, menus, Trash, Monitor, accessories | [`docs/desktop-and-apps.md`](./docs/desktop-and-apps.md) | Reference, screenshots, in-app Guide |
| Resolution, fonts, scaling, appearance, filters, wallpaper | [`docs/display-and-wallpaper.md`](./docs/display-and-wallpaper.md) | Reference, screenshots |
| DSH service/API/version/capability | [`docs/dsh-integration.md`](./docs/dsh-integration.md) | `COMPATIBILITY.md`, `ARCHITECTURE.md`, development notes |
| Persistence, security, input behavior, or hard limits | [`docs/reference.md`](./docs/reference.md) | Troubleshooting, `SECURITY.md` |
| A new failure mode or workaround | [`docs/troubleshooting.md`](./docs/troubleshooting.md) | Primary feature page |

Every user-visible change also needs an entry under **Unreleased** in [`CHANGELOG.md`](./CHANGELOG.md). Update the project README only when the public summary, requirements, quick start, compatibility headline, or documentation map changes.

### Add or remove a documentation page

1. Put detailed user guides in `docs/` with a clear title and links back to `docs/README.md`.
2. Add the page to [`docs/README.md`](./docs/README.md); `pnpm docs:check` enforces this for top-level docs pages.
3. Link it from the owning guide or project README when it is a primary entry point.
4. Remove or redirect obsolete links when deleting/renaming a page.
5. Run `pnpm docs:check` and inspect rendered Markdown tables/images on GitHub.

The link checker validates local Markdown/image targets and ensures every top-level `docs/*.md` page is indexed. It intentionally does not make network requests to validate external sites.

### Screenshots

Update screenshots only when they materially explain the current workflow. Use Expanded 1024 × 768 at native 1× unless a screenshot demonstrates scaling. Arrange windows naturally with useful overlap, avoid private data/personal paths/API keys, and show several related features when that remains readable.

Keep screenshot filenames stable when replacing the same documented view. If a visual change does not invalidate a screenshot's teaching purpose, no cosmetic churn is required.

## Pull requests

Keep changes focused and describe:

- the user or compatibility problem;
- the chosen behavior and important tradeoffs;
- verification performed;
- documentation and screenshots updated;
- any known limitation that remains.

Before requesting review, complete `.github/PULL_REQUEST_TEMPLATE.md`. “Not applicable” is acceptable only when the change truly has no user-visible, compatibility, persistence, security, or maintenance effect.

Never commit API keys, credential status payloads containing secret values, private conversation data, personal absolute paths, or unsanitized terminal logs.

## Assets and licensing

Do not submit Apple artwork, copied system icons, proprietary fonts, screenshots of copyrighted system software, or extracted resources. New third-party code, fonts, images, or generated assets require clear provenance and license review. Update [`THIRD_PARTY_NOTICES.md`](./THIRD_PARTY_NOTICES.md) and the matching license files when needed.

## Conduct

Be specific, constructive, and respectful. Technical disagreement should stay focused on reproducible behavior, product principles, and evidence from the supported DSH baseline.
