// usage-store.ts — tersio-owned usage.db. A cache of the live parse, not a fork; no SQLite → sync false / read null.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { sqliteExec, sqliteRead } from './sqlite.ts';
import type {
  OpencodeClassification,
  OpencodeDbRow,
  OpencodeMessage,
  RunStatus,
  SessionLineRow,
  SessionTokens,
  ToolFact,
} from './usage-ledger.ts';
import {
  agentOfSessionText,
  canonicalModelId,
  classifyOpencodeMessage,
  classifySessionLine,
  type ClaudeParseState,
  collectToolResults,
  costOf,
  type DshParseState,
  dshSessionFiles,
  durOf,
  hostOfSessionFile,
  ingestSessionRow,
  messageRowId,
  newSessionAccum,
  OPENCODE_DB_OVERLAP_MS,
  opencodeDbPath,
  opencodeSessionsDir,
  opencodeToolNames,
  readOpencodeDbRows,
  readSessionText,
  RECENT_LIMIT,
  sessionsDirs,
  usdCost,
  walkJsonl,
} from './usage-ledger.ts';
import { tersioDataPath } from './utils.ts';
import { createDataBackup, newestDataBackup, readSnapshotMember, restoreSnapshotMember } from './snapshots.ts';
import { MODEL_ALIASES } from './pricing.ts';
import { readRetentionDays, tersioSettingsFile } from './plugin-settings.ts';
import { codexModelIdentity, looksLikeCodexTranscript, parseCodexTranscript } from './codex-transcript.ts';

export function usageDbPath(): string {
  const override = process.env.TERSIO_USAGE_DB;
  if (override) return override;
  return tersioDataPath('usage.db', 'tersio-usage.db');
}

export interface StoredUsage {
  tokens: SessionTokens;
  syncedAt: number;
}

function esc(v: string): string {
  return `'${v.replace(/'/g, "''")}'`;
}

function intOf(v: unknown): number {
  return typeof v === 'number' && Number.isFinite(v) && v > 0 ? Math.floor(v) : 0;
}

function nullNum(v: number | undefined): string {
  return v === undefined ? 'NULL' : String(v);
}

function nullStr(v: string | undefined): string {
  return v === undefined ? 'NULL' : esc(v);
}

// A failed INSERT stops before COMMIT, so it leaves no DELETEs behind.
function run(db: string, sql: string): void {
  sqliteExec(db, sql);
}

function query(db: string, sql: string): string[][] {
  return sqliteRead(db, sql)
    .split('\n')
    .filter((line) => line.trim())
    .map((line) => line.split('\t'));
}

// Bump on a parse change: unchanged transcripts are never re-read.
const PARSER_VERSION = '19';

/** OpenCode rows gained tool names; re-read by id, since a PARSER_VERSION bump drops rotated history. */
const OPENCODE_TOOLS_VERSION = '1';

// A re-parse keeping under half the rows means transcripts vanished mid-migration; the backup is restored instead.
const REPARSE_GUARD_RATIO = 0.5;

let guardReport: string | null = null;

/** Why the last sync refused to publish a re-parse, if it did. */
export function reparseGuardReport(): string | null {
  return guardReport;
}

const SCHEMA_SQL =
  `CREATE TABLE IF NOT EXISTS meta (k TEXT PRIMARY KEY, v TEXT NOT NULL);` +
  `CREATE TABLE IF NOT EXISTS files (id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT UNIQUE NOT NULL, mtime REAL NOT NULL, size INTEGER NOT NULL);` +
  `CREATE TABLE IF NOT EXISTS messages (file_id INTEGER NOT NULL REFERENCES files(id), t REAL, model TEXT NOT NULL,` +
  ` i INTEGER NOT NULL, o INTEGER NOT NULL, d REAL, tf REAL, cr INTEGER NOT NULL, cw INTEGER NOT NULL,` +
  ` usd REAL, usd_estimated INTEGER NOT NULL DEFAULT 0, st TEXT NOT NULL, code REAL, note TEXT, tools TEXT NOT NULL DEFAULT '[]', h TEXT, a TEXT, id TEXT, tc TEXT, p TEXT, cwd TEXT);` +
  // Every read filters or orders by one of these three; without them each sync and read scans the table.
  `CREATE INDEX IF NOT EXISTS idx_messages_file ON messages(file_id);` +
  `CREATE INDEX IF NOT EXISTS idx_messages_t ON messages(t);` +
  `CREATE INDEX IF NOT EXISTS idx_messages_h_t ON messages(h, t);` +
  `CREATE INDEX IF NOT EXISTS idx_messages_model ON messages(model);` +
  // One row per assistant message id: a branched transcript repeats the same call.
  `CREATE UNIQUE INDEX IF NOT EXISTS idx_messages_id ON messages(id) WHERE id IS NOT NULL;`;

/** WAL + a checkpoint: the write path avoids an fsync per commit, and usage.db alone holds every row. */
function pragmas(db: string): void {
  run(
    db,
    'PRAGMA journal_mode=WAL;' +
      'PRAGMA synchronous=NORMAL;' +
      'PRAGMA wal_autocheckpoint=256;' +
      'PRAGMA cache_size=-8000;' +
      'PRAGMA temp_store=MEMORY;' +
      'PRAGMA mmap_size=268435456;' +
      // Cheap unless the planner's statistics are stale, and it keeps range queries on the right index.
      'PRAGMA optimize;',
  );
}

function storedParserVersion(db: string): string | null {
  try {
    const stored = query(db, `SELECT v FROM meta WHERE k='parser_version';`);
    return stored.length ? stored[0][0] : null;
  } catch {
    return null;
  }
}

// A store written by a newer tersio: no forward migration, so a re-parse would swap rotated history for what is left.
function isDowngrade(stored: string | null): boolean {
  if (stored === null) return false;
  const storedNum = Number(stored);
  const currentNum = Number(PARSER_VERSION);
  return Number.isFinite(storedNum) && Number.isFinite(currentNum) && storedNum > currentNum;
}

function countMessages(db: string): number {
  try {
    const rows = query(db, `SELECT COUNT(*) FROM messages;`);
    return Number(rows[0]?.[0]) || 0;
  } catch {
    return 0;
  }
}

// Watermark for the sqlite scan: the newest opencode row already stored.
function newestOpencodeMs(db: string): number | null {
  try {
    const rows = query(db, `SELECT MAX(t) FROM messages WHERE h='opencode';`);
    const v = Number(rows[0]?.[0]);
    return Number.isFinite(v) && v > 0 ? v : null;
  } catch {
    return null;
  }
}

/** Whether the OpenCode tools backfill ran; unfilled rows stay empty, so this widens the scan once. */
function opencodeToolsBackfilled(db: string): boolean {
  try {
    const rows = query(db, `SELECT v FROM meta WHERE k='opencode_tools';`);
    return rows.length > 0 && rows[0][0] === OPENCODE_TOOLS_VERSION;
  } catch (error) {
    if (process.env.TERSIO_DEBUG_SYNC) console.error('sync: preamble', error);
    return false;
  }
}

// Same pre-migration state as the newest snapshot: another copy churns the rotation for nothing.
function newestBackupMatches(stored: string | null): boolean {
  if (stored === null) return false;
  const newest = newestDataBackup();
  const body = newest ? readSnapshotMember(newest, path.basename(usageDbPath())) : null;
  if (!body) return false;
  const copy = path.join(os.tmpdir(), `tersio-guard-${process.pid}.db`);
  try {
    fs.writeFileSync(copy, body);
    const out = query(copy, `SELECT v FROM meta WHERE k='parser_version';`);
    return out.length > 0 && out[0][0] === stored;
  } catch {
    return false;
  } finally {
    fs.rmSync(copy, { force: true });
  }
}

// v9 shape (path-keyed rows) migrates in place with zero re-parse, so history survives even without transcripts.
function canMigrateInPlace(db: string): boolean {
  try {
    const names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
    return names.includes('file') && names.includes('h') && !names.includes('file_id');
  } catch (error) {
    if (process.env.TERSIO_DEBUG_SYNC) console.error('sync: walk', error);
    return false;
  }
}

function migrateInPlace(db: string, preCount: number): boolean {
  const cols = `t, model, i, o, d, cr, cw, usd, st, code, note, tools, h`;
  try {
    run(
      db,
      `BEGIN;` +
        `CREATE TABLE files_new (id INTEGER PRIMARY KEY AUTOINCREMENT, path TEXT UNIQUE NOT NULL, mtime REAL NOT NULL, size INTEGER NOT NULL);` +
        `INSERT INTO files_new (path, mtime, size) SELECT path, mtime, size FROM files;` +
        `CREATE TABLE messages_new (file_id INTEGER NOT NULL REFERENCES files_new(id), t REAL, model TEXT NOT NULL,` +
        ` i INTEGER NOT NULL, o INTEGER NOT NULL, d REAL, tf REAL, cr INTEGER NOT NULL, cw INTEGER NOT NULL,` +
        ` usd REAL, usd_estimated INTEGER NOT NULL DEFAULT 0, st TEXT NOT NULL, code REAL, note TEXT, tools TEXT NOT NULL DEFAULT '[]', h TEXT, a TEXT, id TEXT, tc TEXT, cwd TEXT);` +
        `INSERT INTO messages_new (file_id, ${cols}) SELECT (SELECT id FROM files_new WHERE files_new.path = messages.file), ${cols} FROM messages;` +
        `DROP TABLE messages;DROP TABLE files;` +
        `ALTER TABLE files_new RENAME TO files;ALTER TABLE messages_new RENAME TO messages;` +
        `CREATE INDEX idx_messages_file ON messages(file_id);` +
        `COMMIT;`,
    );
  } catch {
    return false;
  }
  try {
    const names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
    return names.includes('file_id') && !names.includes('file') && countMessages(db) === preCount;
  } catch {
    return false;
  }
}

// v12 adds the agent kind with a bare ALTER; existing rows read NULL and report under the main agent.
function canAddAgent(db: string): boolean {
  try {
    const names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
    return names.includes('file_id') && !names.includes('a');
  } catch {
    return false;
  }
}

function addAgentColumn(db: string): boolean {
  try {
    run(db, `ALTER TABLE messages ADD COLUMN a TEXT;`);
  } catch {
    return false;
  }
  return true;
}

// v13 shape gains the first-token latency with a bare ALTER, so no row moves and no wipe runs.
function canAddTtft(db: string): boolean {
  try {
    const names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
    return names.includes('file_id') && !names.includes('tf');
  } catch {
    return false;
  }
}

// The column is additive, and a rotated transcript cannot be re-parsed, so the ALTER precedes the backfill.
function addTtftColumn(db: string): boolean {
  try {
    run(db, `ALTER TABLE messages ADD COLUMN tf REAL;`);
  } catch {
    return false;
  }
  return !canAddTtft(db);
}

/** First-token-latency marker; unchanged transcripts are never revisited, so old stores stay null. */
const TTFT_VERSION = '1';

/** Tool-facts marker: rows written before it carry names only, so one backfill fills sizes and errors. */
const TOOL_FACTS_VERSION = '1';
/** Codex facts gained cwd, tool timing, and request status; one transcript re-read fills them. */
const CODEX_FACTS_VERSION = '2';
const USD_ESTIMATE_VERSION = '1';

function toolFactsBackfilled(db: string): boolean {
  try {
    const rows = query(db, `SELECT v FROM meta WHERE k='tool_facts';`);
    return rows.length > 0 && rows[0][0] === TOOL_FACTS_VERSION;
  } catch {
    return false;
  }
}

function codexFactsBackfilled(db: string): boolean {
  try {
    const rows = query(db, `SELECT v FROM meta WHERE k='codex_facts';`);
    return rows.length > 0 && rows[0][0] === CODEX_FACTS_VERSION;
  } catch {
    return false;
  }
}

function usdEstimatesBackfilled(db: string): boolean {
  try {
    const rows = query(db, `SELECT v FROM meta WHERE k='usd_estimates';`);
    return rows.length > 0 && rows[0][0] === USD_ESTIMATE_VERSION;
  } catch {
    return false;
  }
}

// Codex stores only tokens; OpenCode rows without reported costs may use a known rate, never the default.
function backfillUsdEstimates(db: string): void {
  const rows = query(
    db,
    `SELECT rowid, model, i, o, cr, cw FROM messages WHERE h='codex' OR (h='opencode' AND usd IS NULL);`,
  );
  const statements: string[] = [];
  let statementBytes = 0;
  const flush = (): void => {
    if (!statements.length) return;
    run(db, `BEGIN;${statements.join('')}COMMIT;`);
    statements.length = 0;
    statementBytes = 0;
  };
  for (const row of rows) {
    const rowid = Number(row[0]);
    if (!Number.isSafeInteger(rowid)) continue;
    const price = usdCost(
      {
        input: intOf(Number(row[2])),
        output: intOf(Number(row[3])),
        cacheRead: intOf(Number(row[4])),
        cacheWrite: intOf(Number(row[5])),
      },
      row[1] ?? '',
    );
    const statement = `UPDATE messages SET usd=${price.priced ? String(price.usd) : 'NULL'},usd_estimated=${price.priced ? 1 : 0} WHERE rowid=${rowid};`;
    statements.push(statement);
    statementBytes += statement.length;
    if (statementBytes >= 100_000) flush();
  }
  flush();
  run(db, `INSERT OR REPLACE INTO meta (k, v) VALUES ('usd_estimates','${USD_ESTIMATE_VERSION}');`);
}

// The tool facts are additive too: a bare ALTER, then one transcript re-read fills them.
function canAddToolFacts(db: string): boolean {
  try {
    const names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
    return names.includes('file_id') && !names.includes('tc');
  } catch {
    return false;
  }
}

function addToolFactsColumn(db: string): boolean {
  try {
    run(db, `ALTER TABLE messages ADD COLUMN tc TEXT;`);
  } catch {
    return false;
  }
  return !canAddToolFacts(db);
}

// v14 adds the named gateway; the model id cannot show it, so a bare ALTER plus one re-read fills it.
function canAddGateway(db: string): boolean {
  try {
    const names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
    return names.includes('file_id') && !names.includes('p');
  } catch {
    return false;
  }
}

function addGatewayColumn(db: string): boolean {
  try {
    run(db, `ALTER TABLE messages ADD COLUMN p TEXT;`);
  } catch {
    return false;
  }
  if (canAddGateway(db)) return false;
  markTranscriptsDirty(db);
  return true;
}

function ttftBackfilled(db: string): boolean {
  try {
    const rows = query(db, `SELECT v FROM meta WHERE k='ttft_backfill';`);
    return rows.length > 0 && rows[0][0] === TTFT_VERSION;
  } catch {
    return false;
  }
}

/** Clears ledger mtimes so every transcript re-reads; synthetic `db#row-id` OpenCode keys stay untouched. */
function markTranscriptsDirty(db: string): void {
  try {
    run(db, `UPDATE files SET mtime = 0 WHERE path NOT LIKE '%#%';`);
  } catch {
    /* a store with no files table yet, or a read-only file: nothing to backfill */
  }
}

// v10 shape gains the message id with a bare ALTER: no rows move, so no re-parse and no guard trip.
function canAlterInPlace(db: string): boolean {
  try {
    const names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
    return names.includes('file_id') && !names.includes('id');
  } catch {
    return false;
  }
}

function alterInPlace(db: string): boolean {
  try {
    run(db, `ALTER TABLE messages ADD COLUMN id TEXT;`);
  } catch {
    return false;
  }
  return !canAlterInPlace(db);
}

/**
 * Every column the schema names, with the type an old store is missing. A bump adds these instead of
 * dropping the table, so rows whose transcript has rotated away survive the migration.
 */
const MESSAGE_COLUMNS: ReadonlyArray<readonly [string, string]> = [
  ['d', 'REAL'],
  ['tf', 'REAL'],
  ['usd', 'REAL'],
  ['usd_estimated', 'INTEGER NOT NULL DEFAULT 0'],
  ['code', 'REAL'],
  ['note', 'TEXT'],
  ['tools', "TEXT NOT NULL DEFAULT '[]'"],
  ['h', 'TEXT'],
  ['a', 'TEXT'],
  ['id', 'TEXT'],
  ['tc', 'TEXT'],
  ['p', 'TEXT'],
  ['cr', 'INTEGER NOT NULL DEFAULT 0'],
  ['cw', 'INTEGER NOT NULL DEFAULT 0'],
  ['cwd', 'TEXT'],
];

/** Adds each column the store is missing; returns true when one landed. */
function addMissingColumns(db: string): boolean {
  let names: string[] = [];
  try {
    names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
  } catch {
    return false;
  }
  let added = false;
  for (const [name, type] of MESSAGE_COLUMNS) {
    if (names.includes(name)) continue;
    try {
      run(db, `ALTER TABLE messages ADD COLUMN ${name} ${type};`);
      added = true;
    } catch {
      /* a store that refuses the column keeps running on the ones it has */
    }
  }
  return added;
}
/** One row per assistant message id: a resumed or branched transcript repeats the same call, and counting it twice
 * inflates every total. Rows without an id are kept, since nothing proves they are the same call. */
function dedupeMessages(db: string): void {
  try {
    run(
      db,
      `DELETE FROM messages WHERE id IS NOT NULL AND rowid NOT IN (
      SELECT MIN(rowid) FROM messages WHERE id IS NOT NULL GROUP BY id);`,
    );
  } catch {
    /* a store without the column keeps what it has */
  }
}

function ensureSchema(db: string, forceWipe: boolean): void {
  fs.mkdirSync(path.dirname(db), { recursive: true });
  // Fold in rows stored under a pre-alias spelling; the mtime ledger will not re-read those transcripts.
  const rekeys = MODEL_ALIASES.map((a) => `UPDATE messages SET model='${a.id}' WHERE model='${a.feed}';`).join('');
  const stored = storedParserVersion(db);
  pragmas(db);
  // Before the unique index is created, so a store that already counted a call twice can still take the index.
  dedupeMessages(db);
  // Forced: the operator accepts the loss and asks for a clean rebuild from what is on disk.
  if (forceWipe) {
    run(
      db,
      `DROP TABLE IF EXISTS messages;DROP TABLE IF EXISTS files;` +
        SCHEMA_SQL +
        `INSERT OR REPLACE INTO meta (k,v) VALUES ('parser_version','${PARSER_VERSION}');`,
    );
    return;
  }
  if (stored === PARSER_VERSION) {
    // A store this build already wrote still gains a column added since, without a version bump.
    run(db, SCHEMA_SQL + rekeys);
    const added = addAdditiveColumns(db);
    const missing = addMissingColumns(db);
    if (added || missing) run(db, `INSERT OR REPLACE INTO meta (k, v) VALUES ('parser_version','${PARSER_VERSION}');`);
    return;
  }
  // A newer store keeps its rows: only an explicit force re-parse may wipe it.
  if (!forceWipe && isDowngrade(stored)) {
    run(db, SCHEMA_SQL + rekeys);
    return;
  }
  // A version bump rebuilds both tables, so no ALTER patchwork survives a migration.
  try {
    if (countMessages(db) > 0 && !newestBackupMatches(stored)) snapshotData();
    if (stored !== null && canMigrateInPlace(db) && migrateInPlace(db, countMessages(db))) {
      run(db, `INSERT OR REPLACE INTO meta (k,v) VALUES ('parser_version','${PARSER_VERSION}');`);
      try {
        run(db, `VACUUM;`);
      } catch {
        /* best-effort */
      }
      return;
    }
    if (stored !== null && canAlterInPlace(db) && alterInPlace(db)) {
      run(db, `INSERT OR REPLACE INTO meta (k,v) VALUES ('parser_version','${PARSER_VERSION}');`);
      return;
    }
    // Every additive column lands in one pass: an older store may miss more than one.
    if (stored !== null && addAdditiveColumns(db)) {
      addMissingColumns(db);
      run(db, `INSERT OR REPLACE INTO meta (k, v) VALUES ('parser_version','${PARSER_VERSION}');`);
      return;
    }
    // Last resort: keep both tables. Missing columns are added and every transcript is marked dirty, so
    // the new parser re-reads what is still on disk. Rows whose transcript rotated away stay counted.
    run(db, SCHEMA_SQL + rekeys);
    addMissingColumns(db);
    markTranscriptsDirty(db);
    run(db, `INSERT OR REPLACE INTO meta (k,v) VALUES ('parser_version','${PARSER_VERSION}');`);
  } catch {
    /* fresh db, nothing to invalidate */
  }
}

/** Adds each missing additive column: the agent kind, the first-token latency, and the tool facts. */
function addAdditiveColumns(db: string): boolean {
  let added = false;
  if (canAddAgent(db) && addAgentColumn(db)) added = true;
  if (canAddTtft(db) && addTtftColumn(db)) added = true;
  if (canAddToolFacts(db) && addToolFactsColumn(db)) added = true;
  if (canAddGateway(db) && addGatewayColumn(db)) added = true;
  return added;
}

// The one destructive thing we do; the snapshot rotation keeps a bad bump recoverable.
export function snapshotData(): void {
  try {
    createDataBackup();
  } catch {
    /* a missing snapshot must not block the sync */
  }
}

const SCHEDULE_MS: Record<string, number> = { daily: 86_400_000, weekly: 604_800_000, monthly: 2_592_000_000 };

/** Read the schedule straight from settings; this module must not import cli/. */
export function readBackupSchedule(): string {
  try {
    const raw = JSON.parse(fs.readFileSync(tersioSettingsFile(), 'utf8')) as { backupSchedule?: unknown };
    return typeof raw?.backupSchedule === 'string' ? raw.backupSchedule : 'monthly';
  } catch {
    return 'monthly';
  }
}

/** Drop transcript rows past the window. The file rows stay, so a later sync appends the new turns instead of re-reading the old ones. */
function pruneRetention(db: string): void {
  const days = readRetentionDays();
  if (days <= 0) return;
  const cutoff = Date.now() - days * 86_400_000;
  try {
    run(db, `DELETE FROM messages WHERE t IS NOT NULL AND t < ${cutoff};`);
  } catch {
    /* a store without the table */
  }
}

/** Snapshot on the schedule, skipping when the newest one is still fresh. */
export function maybeScheduledBackup(): boolean {
  const every = SCHEDULE_MS[readBackupSchedule()];
  if (!every) return false;
  try {
    const newest = newestDataBackup();
    if (newest && Date.now() - newest.mtime < every) return false;
    createDataBackup();
    return true;
  } catch {
    return false;
  }
}

function readFiles(db: string): Record<string, { mtime: number; size: number }> {
  const known: Record<string, { mtime: number; size: number }> = {};
  try {
    for (const [p, mtime, size] of query(db, `SELECT path, mtime, size FROM files;`)) {
      known[p] = { mtime: Number(mtime) || 0, size: Number(size) || 0 };
    }
  } catch {
    /* fresh db */
  }
  return known;
}

// One parsed assistant message. `t` is null with no usable timestamp: still counted, but skipped in the recent list.
interface StoredRow {
  t: number | null;
  model: string;
  i: number;
  o: number;
  d: number | undefined;
  /** First-token latency in ms. Only omp records it; the rest read null rather than a guess. */
  tf: number | undefined;
  cr: number;
  cw: number;
  usd: number | undefined;
  usdEstimated: boolean;
  st: RunStatus;
  code: number | undefined;
  note: string | undefined;
  tools: string[];
  /** Name, argument bytes, result bytes, and error flag per call. Absent for a name-only row. */
  toolFacts?: ToolFact[];
  host?: string;
  /** `main` or `subagent`; null on a row written before the store carried it. */
  agent?: string | null;
  id?: string;
  /** The session's working directory, from Codex's session metadata. */
  cwd?: string;
  /** The gateway the transcript named, e.g. `commandcode`. Null on rows written before it was kept. */
  gateway?: string;
}

// OpenCode rows carry only tokens, msg id, and tools; they record as the main agent, so no NULL kind.
function opencodeStoredRow(
  oc: NonNullable<OpencodeClassification>,
  host: string | undefined,
  id: string | undefined,
  tools: string[],
): StoredRow {
  const model = canonicalModelId(oc.model);
  const usage = {
    input: intOf(oc.usage.input),
    output: intOf(oc.usage.output),
    cacheRead: intOf(oc.usage.cacheRead),
    cacheWrite: intOf(oc.usage.cacheWrite),
  };
  const measured = costOf(oc.usage);
  const priced = measured === undefined ? usdCost(usage, model) : undefined;
  return {
    t: oc.ms ?? null,
    model,
    i: usage.input,
    o: usage.output,
    d: durOf(oc.durMs),
    tf: durOf(oc.ttftMs),
    cr: usage.cacheRead,
    cw: usage.cacheWrite,
    usd: measured ?? (priced?.priced ? priced.usd : undefined),
    usdEstimated: measured === undefined && priced?.priced === true,
    st: 'completed',
    code: undefined,
    note: undefined,
    tools,
    host,
    agent: 'main',
    id,
  };
}

function parseFile(text: string, host?: string, file?: string, agent?: string): StoredRow[] {
  const rows: StoredRow[] = [];
  // Guarded: a JSONL transcript must fall through, not abort the sync.
  let oc: OpencodeClassification | null = null;
  try {
    const message = JSON.parse(text) as OpencodeMessage;
    oc = classifyOpencodeMessage(message);
    if (oc) {
      rows.push(
        opencodeStoredRow(
          oc,
          host,
          file ? path.basename(file).replace(/\.[^.]+$/, '') : undefined,
          opencodeToolNames(message),
        ),
      );
      return rows;
    }
  } catch {
    /* JSONL */
  }
  if (looksLikeCodexTranscript(text)) {
    const parsed = parseCodexTranscript(text);
    return parsed.requests.map((request) => {
      const identity = codexModelIdentity(request.model, request.provider);
      const model = canonicalModelId(identity.model);
      const price = usdCost(request.usage, model);
      return {
        t: request.endTs || null,
        model,
        i: request.usage.input,
        o: request.usage.output,
        d: durOf(request.durationMs),
        tf: durOf(request.ttftMs),
        cr: request.usage.cacheRead,
        cw: request.usage.cacheWrite,
        usd: price.priced ? price.usd : undefined,
        usdEstimated: price.priced,
        st: request.status,
        code: request.code,
        note: request.note,
        tools: request.tools,
        toolFacts: request.toolFacts,
        host: host ?? 'codex',
        agent,
        id: request.id,
        gateway: identity.provider,
        cwd: request.cwd,
      };
    });
  }
  // A call's result arrives on a later line, so the whole file is scanned for results first.
  const results = collectToolResults(text);
  // Per file: the DSH model and step starts must not outlive this transcript.
  const dsh: DshParseState = { steps: new Map() };
  const claude: ClaudeParseState = { requests: new Map() };
  let codexProvider: string | null = null;
  let codexModel: string | null = null;
  let dshModel: string | null = null;
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      const row = JSON.parse(line) as SessionLineRow;
      const parsed = classifySessionLine(row, results, dsh, claude);
      const rid = parsed.id ?? messageRowId(row);
      if (parsed.kind === 'codex_provider') {
        if (parsed.provider) codexProvider = parsed.provider;
        continue;
      }
      if (parsed.kind === 'codex_model') {
        if (parsed.model) codexModel = parsed.model;
        continue;
      }
      if (parsed.kind === 'dsh_model') {
        if (parsed.model) dshModel = parsed.model;
        continue;
      }
      const ts = row.timestamp ?? row.time;
      const ms = ts === undefined ? NaN : typeof ts === 'number' ? ts : Date.parse(ts);
      const t = Number.isFinite(ms) ? ms : null;
      if (parsed.kind === 'token_row') {
        const provider = parsed.provider ?? codexProvider;
        const usage = parsed.usage ?? {};
        rows.push({
          t,
          model: canonicalModelId(
            provider ? (codexModel ? `codex/${provider}/${codexModel}` : `codex/${provider}`) : 'codex',
          ),
          i: intOf(usage.input),
          o: intOf(usage.output),
          d: undefined,
          tf: undefined,
          cr: intOf(usage.cacheRead),
          cw: intOf(usage.cacheWrite),
          usd: costOf(usage),
          usdEstimated: false,
          st: 'completed',
          code: undefined,
          note: undefined,
          tools: [],
          host,
          agent,
          id: rid,
        });
        continue;
      }
      // A DeepSeek Harness row names no model itself; the session's last model/selection does.
      const model = parsed.model ?? (row.type === 'assistant/message' ? (dshModel ?? undefined) : undefined);
      if (parsed.kind !== 'assistant_row' || !model || !parsed.usage) continue;
      const usage = parsed.usage;
      const dur = durOf(parsed.durMs);
      const runInfo = parsed.run ?? { st: 'completed' as RunStatus };
      const note = runInfo.note?.replace(/[\t\n\r]/g, ' ').slice(0, 180);
      rows.push({
        t,
        model: canonicalModelId(model),
        i: intOf(usage.input),
        o: intOf(usage.output),
        d: dur,
        tf: durOf(parsed.ttftMs),
        cr: intOf(usage.cacheRead),
        cw: intOf(usage.cacheWrite),
        usd: costOf(usage),
        usdEstimated: false,
        st: runInfo.st,
        code: runInfo.code,
        note,
        tools: parsed.tools ?? [],
        toolFacts: parsed.toolFacts,
        host,
        agent,
        id: rid,
        gateway: parsed.provider,
      });
    } catch {
      /* skip corrupt lines */
    }
  }
  return rows;
}

function insertSql(file: string, r: StoredRow): string {
  return (
    `INSERT OR IGNORE INTO messages (file_id, t, model, i, o, d, tf, cr, cw, usd, usd_estimated, st, code, note, tools, h, a, id, tc, p, cwd) VALUES (` +
    `(SELECT id FROM files WHERE path=${esc(file)}),${r.t === null ? 'NULL' : String(r.t)},${esc(r.model)},${r.i},${r.o},` +
    `${nullNum(r.d)},${nullNum(r.tf)},${r.cr},${r.cw},${nullNum(r.usd)},${r.usdEstimated ? 1 : 0},${esc(r.st)},` +
    `${nullNum(r.code)},${nullStr(r.note)},${esc(JSON.stringify(r.tools))},${nullStr(r.host)},${nullStr(r.agent ?? undefined)},${nullStr(r.id)},` +
    `${r.toolFacts && r.toolFacts.length > 0 ? esc(JSON.stringify(r.toolFacts)) : 'NULL'},${nullStr(r.gateway)},${nullStr(r.cwd)});`
  );
}

// Unchanged transcripts are skipped via mtime+size; rows for deleted ones are kept so rotation never erases history.
export function syncUsageDb(): boolean {
  let db: string;
  guardReport = null;
  let preWipe = -1;
  let migrated = false;
  try {
    db = usageDbPath();
    const stored = storedParserVersion(db);
    // The operator deleted sessions on purpose and wants the mirror to match: bypass the guard.
    const forced = process.env.TERSIO_FORCE_REPARSE === '1';
    // A downgrade keeps its rows: the wipe below cannot rebuild them from rotated transcripts.
    const downgrade = !forced && isDowngrade(stored);
    migrated = stored !== null && stored !== PARSER_VERSION && !downgrade;
    if (downgrade)
      guardReport = `store was written by a newer tersio (parser ${stored} > ${PARSER_VERSION}); kept its rows and skipped the re-parse`;
    if (migrated && !forced) preWipe = countMessages(db);
    ensureSchema(db, forced);
    if (!downgrade && !usdEstimatesBackfilled(db)) {
      if (!forced && !migrated && countMessages(db) > 0) snapshotData();
      backfillUsdEstimates(db);
    }
    // One rewrite so the additive columns' NULL rows gain latency and tool facts; runs while a marker is absent.
    if (!downgrade && (!ttftBackfilled(db) || !toolFactsBackfilled(db) || !codexFactsBackfilled(db)))
      markTranscriptsDirty(db);
    maybeScheduledBackup();
    // Retention applies even on a sync with nothing new, so a quiet machine still lets old rows age out.
    pruneRetention(db);
  } catch {
    return false;
  }
  const files: string[] = [];
  const ocFiles: string[] = [];
  try {
    for (const dir of sessionsDirs()) walkJsonl(dir, files, 2000);
    // DeepSeek Harness keeps zstd transcripts under its own tree, not the pi/omp JSONL dirs.
    if (process.env.TERSIO_SESSIONS_DIR === undefined) files.push(...dshSessionFiles());
    // OpenCode stores one JSON document per message, not JSONL.
    if (process.env.TERSIO_SESSIONS_DIR === undefined || process.env.TERSIO_OPENCODE_DIR !== undefined) {
      walkJsonl(opencodeSessionsDir(), ocFiles, 5000, '.json');
    }
  } catch {
    return false;
  }
  files.push(...ocFiles);
  // v2 hosts keep messages in sqlite; rows past the watermark are new. Overlap re-reads the tail idempotently.
  const ocDbRows: OpencodeDbRow[] = [];
  const ocDbPath = opencodeDbPath();
  if (process.env.TERSIO_SESSIONS_DIR === undefined || process.env.TERSIO_OPENCODE_DB !== undefined) {
    const newest = newestOpencodeMs(db);
    // A store predating the tool names re-reads the whole table once; the marker closes the window.
    const since = newest === null || !opencodeToolsBackfilled(db) ? 0 : newest - OPENCODE_DB_OVERLAP_MS;
    if (newest !== null || fs.existsSync(ocDbPath)) {
      ocDbRows.push(...readOpencodeDbRows(ocDbPath, since));
    }
  }
  const known = readFiles(db);
  const current: Record<string, { mtime: number; size: number }> = {};
  const changed: string[] = [];
  for (const file of files) {
    let st: fs.Stats;
    try {
      st = fs.statSync(file);
    } catch {
      continue;
    }
    const entry = { mtime: st.mtimeMs, size: st.size };
    current[file] = entry;
    const prev = known[file];
    if (!prev || prev.mtime !== entry.mtime || prev.size !== entry.size) changed.push(file);
  }
  // `ocDbRows` is non-empty whenever the backfill window is open, so this never skips it.
  if (!changed.length && !ocDbRows.length) return true;
  const chunks: string[] = [];
  let chunkBytes = 0;
  const flush = (): boolean => {
    if (!chunks.length) return true;
    try {
      run(db, `BEGIN;${chunks.join('')}COMMIT;`);
    } catch {
      return false;
    }
    chunks.length = 0;
    chunkBytes = 0;
    return true;
  };
  const push = (sql: string): boolean => {
    chunks.push(sql);
    chunkBytes += sql.length;
    // One argv string caps at 128KB on Linux (E2BIG); stay well under it.
    if (chunkBytes < 100_000) return true;
    return flush();
  };
  for (const file of changed) {
    const entry = current[file];
    if (
      !push(
        `INSERT INTO files (path, mtime, size) VALUES (${esc(file)},${entry.mtime},${entry.size})` +
          ` ON CONFLICT(path) DO UPDATE SET mtime=excluded.mtime,size=excluded.size;` +
          `DELETE FROM messages WHERE file_id=(SELECT id FROM files WHERE path=${esc(file)});`,
      )
    )
      return false;
  }
  try {
    for (const file of changed) {
      // zstd transcripts are decompressed here; a plain JSONL reads as its own bytes.
      const text = readSessionText(file);
      if (text === null) continue;
      for (const r of parseFile(text, hostOfSessionFile(file), file, agentOfSessionText(text))) {
        if (!push(insertSql(file, r))) return false;
      }
    }
    for (const row of ocDbRows) {
      const parsed = classifyOpencodeMessage(row.row);
      if (!parsed) continue;
      // One synthetic path per row id, so the delete-and-reinsert that follows is idempotent.
      const key = `${ocDbPath}#${row.id}`;
      if (
        !push(
          `INSERT INTO files (path, mtime, size) VALUES (${esc(key)},${row.created},0)` +
            ` ON CONFLICT(path) DO UPDATE SET mtime=excluded.mtime;` +
            `DELETE FROM messages WHERE file_id=(SELECT id FROM files WHERE path=${esc(key)});` +
            insertSql(key, opencodeStoredRow(parsed, 'opencode', row.id, opencodeToolNames(row.row, row.tools))),
        )
      )
        return false;
    }
  } catch {
    return false;
  }
  if (!push(`INSERT OR REPLACE INTO meta (k, v) VALUES ('last_sync',${esc(String(Date.now()))});`)) return false;
  // Only once the rows are written, so a sync that fails midway widens the scan again.
  if (ocDbRows.length > 0) {
    if (!push(`INSERT OR REPLACE INTO meta (k, v) VALUES ('opencode_tools','${OPENCODE_TOOLS_VERSION}');`))
      return false;
  }
  // Set only after the rewrite commits: a crash mid-backfill leaves mtimes cleared and the marker absent.
  if (changed.length > 0) {
    if (!push(`INSERT OR REPLACE INTO meta (k, v) VALUES ('ttft_backfill','${TTFT_VERSION}');`)) return false;
    if (!push(`INSERT OR REPLACE INTO meta (k, v) VALUES ('tool_facts','${TOOL_FACTS_VERSION}');`)) return false;
    if (!push(`INSERT OR REPLACE INTO meta (k, v) VALUES ('codex_facts','${CODEX_FACTS_VERSION}');`)) return false;
  }
  if (!flush()) return false;
  if (preWipe > 0) {
    const kept = countMessages(db);
    if (kept < preWipe * REPARSE_GUARD_RATIO) {
      const newest = newestDataBackup();
      const ledger = path.basename(usageDbPath());
      if (newest && restoreSnapshotMember(newest, ledger)) {
        guardReport = `re-parse kept ${kept} of ${preWipe} rows; restored ${newest.name} (set TERSIO_FORCE_REPARSE=1 to accept the loss)`;
        return false;
      }
    }
  }
  // Reclaim the migration's DELETE storm so the file stays small.
  if (migrated) {
    try {
      run(db, `VACUUM;`);
    } catch {
      /* best-effort */
    }
  }
  // Fold the WAL back into the main file. Snapshots read through the WAL themselves, so this only keeps the ledger's own directory small.
  try {
    run(db, `PRAGMA wal_checkpoint(TRUNCATE);`);
  } catch {
    /* best-effort */
  }
  return true;
}

export function readUsageDb(): StoredUsage | null {
  const db = usageDbPath();
  try {
    if (!fs.existsSync(db)) return null;
  } catch {
    return null;
  }
  let rows: string[][];
  // A reset marks a timestamp; the rows it hides stay in the table for a later restore.
  let resetAt = 0;
  try {
    const marked = query(db, `SELECT v FROM meta WHERE k='reset_at';`);
    if (marked.length) resetAt = Number(marked[0][0]) || 0;
  } catch {
    /* a store with no meta row yet */
  }
  try {
    // The wide `tools` column is read as one string and skipped in JS; a pre-agent store is read without it.
    const names = query(db, `PRAGMA table_info(messages);`).map((r) => r[1]);
    const agentCol = names.includes('a') ? 'a' : "''";
    // A store predating first-token latency has no `tf` column; read NULL so the row still loads.
    const tfCol = names.includes('tf') ? 'tf' : 'NULL';
    const usdEstimatedCol = names.includes('usd_estimated') ? 'usd_estimated' : '0';
    rows = query(
      db,
      `SELECT t, model, i, o, d, cr, cw, usd, ${usdEstimatedCol}, st, code, note, tools, h, ${agentCol}, id, ${tfCol} FROM messages${resetAt > 0 ? ` WHERE t IS NULL OR t >= ${resetAt}` : ''};`,
    );
  } catch {
    return null;
  }
  const accum = newSessionAccum();
  for (const [t, model, i, o, d, cr, cw, usd, usdEstimated, st, code, note, tools, h, a, id, tf] of rows) {
    const ts = t === '' ? undefined : Number(t);
    let toolNames: string[] = [];
    if (tools && tools !== '[]' && tools !== '') {
      try {
        const parsed: unknown = JSON.parse(tools);
        if (Array.isArray(parsed)) toolNames = parsed.filter((x): x is string => typeof x === 'string');
      } catch {
        /* keep empty */
      }
    }
    const usage: Record<string, unknown> = {
      input: Number(i) || 0,
      output: Number(o) || 0,
      cacheRead: Number(cr) || 0,
      cacheWrite: Number(cw) || 0,
    };
    if (usd !== '' && usdEstimated !== '1') {
      const measured = Number(usd);
      if (Number.isFinite(measured)) usage.cost = measured;
    }
    ingestSessionRow(
      accum,
      model || 'unknown',
      usage,
      Number.isFinite(ts) ? (ts as number) : undefined,
      d === '' ? undefined : Number(d),
      {
        st: st === 'error' || st === 'aborted' ? st : 'completed',
        code: code === '' ? undefined : Number(code),
        note: note === '' ? undefined : note,
      },
      toolNames,
      h === '' ? undefined : h,
      id === '' || id === undefined ? undefined : id,
      a === '' ? undefined : a,
      tf === undefined || tf === '' ? undefined : Number(tf),
    );
  }
  accum.recent.sort((a, b) => b.t - a.t);
  let syncedAt = 0;
  try {
    const meta = query(db, `SELECT v FROM meta WHERE k='last_sync';`);
    if (meta.length) syncedAt = Number(meta[0][0]) || 0;
  } catch {
    /* keep 0 */
  }
  return {
    tokens: {
      messages: accum.messages,
      totals: accum.totals,
      byModel: accum.byModel,
      byDay: accum.byDay,
      byDayModel: accum.byDayModel,
      byTool: accum.byTool,
      byModelMessages: accum.byModelMessages,
      byHost: accum.byHost,
      byAgent: accum.byAgent,
      byAgentMessages: accum.byAgentMessages,
      byModelMeasured: accum.byModelMeasured,
      byModelCostMessages: accum.byModelCostMessages,
      costMeasured: accum.costMeasured,
      recent: accum.recent.slice(0, RECENT_LIMIT),
    },
    syncedAt,
  };
}

// Reset hides the rows instead of deleting them, so a reset is never a data loss. TERSIO_RESET_PURGE=1
// still removes the file for a hard wipe. Returns 1 when the reset landed, 0 when there was nothing to reset.
export function clearUsageDb(): number {
  const db = usageDbPath();
  if (process.env.TERSIO_RESET_PURGE === '1') {
    try {
      fs.unlinkSync(db);
      return 1;
    } catch {
      return 0;
    }
  }
  try {
    if (!fs.existsSync(db)) return 0;
    run(db, `INSERT OR REPLACE INTO meta (k, v) VALUES ('reset_at', ${Date.now()});`);
    return 1;
  } catch {
    return 0;
  }
}
