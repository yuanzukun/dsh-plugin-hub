// Usage ledger: append-only JSON lines, read by the CLI, `/tersio`, and the Dashboard. Corrupt lines are skipped.
import fs from 'node:fs';
import path from 'node:path';
import * as zlib from 'node:zlib';
import { homeDir, isPiProcess, isPigProcess, pigAgentDir, piAgentDir, resolveRtkBinary, tersioDataPath } from './utils.ts';
import { tersioStateFile } from './state.ts';
import { eligibleHeads } from './rtk-eligible.ts';
import { sqliteRead } from './sqlite.ts';
import { patchState, readState, takeLegacy } from './state.ts';

export type UsageKind = 'command' | 'toggle' | 'install' | 'update' | 'rtk-audit';

export interface UsageRow {
  ts: number;
  kind: UsageKind;
  detail: string;
}

export function ledgerPath(): string {
  const override = process.env.TERSIO_USAGE_FILE;
  if (override) return override;
  return tersioDataPath('usage.jsonl', 'tersio-usage.jsonl');
}

// Reset watermark: views filter rows older than it, so nothing else is deleted. The env override still names a file.
export function resetMarkerPath(): string {
  const override = process.env.TERSIO_RESET_FILE;
  if (override) return override;
  return tersioStateFile();
}

export function readResetWatermark(): number {
  const override = process.env.TERSIO_RESET_FILE;
  if (!override) {
    const value = readState().reset;
    if (typeof value === 'number' && Number.isFinite(value) && value > 0) return value;
    const legacy = takeLegacy(tersioDataPath('reset.json', 'tersio-reset.json'), (raw) => {
      try {
        const ts = (JSON.parse(raw) as { ts?: unknown }).ts;
        return typeof ts === 'number' && Number.isFinite(ts) && ts > 0 ? ts : null;
      } catch {
        return null; // takeLegacy already guards, but the parse owns its own boundary
      }
    });
    if (legacy !== null) {
      patchState({ reset: legacy });
      return legacy;
    }
    return 0;
  }
  try {
    const raw = JSON.parse(fs.readFileSync(override, 'utf8')) as { ts?: unknown };
    return typeof raw.ts === 'number' && Number.isFinite(raw.ts) && raw.ts > 0 ? raw.ts : 0;
  } catch {
    return 0;
  }
}

export function markReset(now = Date.now()): number {
  if (process.env.TERSIO_RESET_FILE) {
    try {
      fs.mkdirSync(path.dirname(resetMarkerPath()), { recursive: true });
      fs.writeFileSync(resetMarkerPath(), JSON.stringify({ ts: now }) + '\n', 'utf8');
    } catch { /* best-effort */ }
    return now;
  }
  patchState({ reset: now });
  return now;
}

export function appendUsage(kind: UsageKind, detail: string): void {
  const row = JSON.stringify({ ts: Date.now(), kind, detail }) + '\n';
  try {
    fs.mkdirSync(path.dirname(ledgerPath()), { recursive: true });
    fs.appendFileSync(ledgerPath(), row, 'utf8');
  } catch { /* ledger is best-effort; never break the caller */ }
}

// Session tokens: assistant messages in the host transcripts carry usage, model, and a timestamp.
export interface TokenBreakdown {
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
}

// `toolUse` is an ordinary turn that handed off to tools, so it reads completed.
export type RunStatus = 'completed' | 'aborted' | 'error';

export interface RecentRequest {
  m: string;
  i: number;
  o: number;
  t: number;
  d?: number;
  /** First-token latency, when the host recorded one. */
  tf?: number;
  /** Which agent wrote the session: pi, omp, or codex. */
  h?: string;
  cr?: number;
  cw?: number;
  // Undefined when the host recorded no cost; never backfilled.
  usd?: number;
  st: RunStatus;
  code?: number;
  note?: string;
  /** Message id when the host provides one (transcript row id, opencode msg file). */
  id?: string;
}

export interface SessionTokens {
  messages: number;
  totals: TokenBreakdown;
  byModel: Record<string, TokenBreakdown>;
  byDay: Record<string, TokenBreakdown>;
  byDayModel: Record<string, Record<string, number>>;
  byTool: Record<string, number>;
  byModelMessages: Record<string, number>;
  byHost: Record<string, Record<string, TokenBreakdown>>;
  /** Model -> agent kind (`main`, `subagent`), so a subagent's work reads apart from its root's. */
  byAgent: Record<string, Record<string, TokenBreakdown>>;
  /** Model -> agent kind -> message count, so a share can read requests beside the tokens. */
  byAgentMessages: Record<string, Record<string, number>>;
  /** Model -> cost the host reported, over the messages that carried one. */
  byModelMeasured: Record<string, number>;
  /** Model -> messages that carried a cost. Compare to `byModelMessages` before trusting the sum. */
  byModelCostMessages: Record<string, number>;
  costMeasured: number;
  recent: RecentRequest[];
}

export interface RtkHostAdoption {
  bashCalls: number;
  eligibleCalls: number;
  rtkCalls: number;
  missedCalls: number;
  adoptionPct: number;
}

export interface RtkAdoption {
  sessions: number;
  bashCalls: number;
  eligibleCalls: number;
  rtkCalls: number;
  missedCalls: number;
  adoptionPct: number;
  /** One entry per host that recorded bash calls, so a blended number cannot hide a host. */
  byHost: Record<string, RtkHostAdoption>;
}

function zeroBreakdown(): TokenBreakdown {
  return { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 };
}
function stampMs(ts: string | number | undefined): number {
  return ts === undefined ? NaN : typeof ts === 'number' ? ts : Date.parse(ts);
}

export function durOf(v: unknown): number | undefined {
  return typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : undefined;
}

// Measured cost: usage.cost.total, or a bare number in old fixtures. Anything else means unrecorded, not 0.
export function costOf(usage: Record<string, unknown>): number | undefined {
  const c = usage.cost;
  if (typeof c === 'number') return Number.isFinite(c) ? c : undefined;
  if (c && typeof c === 'object') {
    const total = (c as { total?: unknown }).total;
    if (typeof total === 'number' && Number.isFinite(total)) return total;
  }
  return undefined;
}

// First line only: real messages carry multi-line provider errors, and this ends up in a tooltip.
export function statusOf(msg: { stopReason?: unknown; errorStatus?: unknown; errorMessage?: unknown; isError?: unknown }): { st: RunStatus; code?: number; note?: string } {
  const stop = typeof msg.stopReason === 'string' ? msg.stopReason : '';
  const note = typeof msg.errorMessage === 'string' && msg.errorMessage.trim()
    ? msg.errorMessage.split('\n')[0].trim().slice(0, 180)
    : undefined;
  if (stop === 'error' || msg.isError === true) {
    const code = typeof msg.errorStatus === 'number' && Number.isFinite(msg.errorStatus) ? msg.errorStatus : undefined;
    return { st: 'error', code, note };
  }
  if (stop === 'aborted') return { st: 'aborted', note };
  return { st: 'completed', note };
}

function addInto(into: TokenBreakdown, u: { input?: unknown; output?: unknown; cacheRead?: unknown; cacheWrite?: unknown }): void {
  for (const k of ['input', 'output', 'cacheRead', 'cacheWrite'] as const) {
    const v = u[k];
    if (typeof v === 'number' && Number.isFinite(v) && v > 0) into[k] += Math.floor(v);
  }
}

export function sessionsDirs(): string[] {
  const override = process.env.TERSIO_SESSIONS_DIR;
  if (override) return [override];
  // All hosts, not just the running one: a session is missing if we stop at the first existing directory.
  const dirs = isPigProcess()
    ? [path.join(pigAgentDir(), 'sessions'), path.join(piAgentDir(), 'sessions'), path.join(homeDir(), '.omp', 'agent', 'sessions')]
    : isPiProcess()
      ? [path.join(piAgentDir(), 'sessions'), path.join(pigAgentDir(), 'sessions'), path.join(homeDir(), '.omp', 'agent', 'sessions')]
      : [path.join(homeDir(), '.omp', 'agent', 'sessions'), path.join(piAgentDir(), 'sessions'), path.join(pigAgentDir(), 'sessions')];
  const found = dirs.filter((dir) => fs.existsSync(dir));
  return found.length > 0 ? found : [dirs[0]];
}

/** DeepSeek Harness keeps one zstd-compressed JSONL per session, under a workspace/session tree. */
export function dshSessionFiles(cap = 2000): string[] {
  const out: string[] = [];
  walkJsonl(path.join(homeDir(), '.dsh', 'sessions'), out, cap, '.zstd');
  return out;
}

/** A transcript's text, decompressing the zstd files DeepSeek Harness writes; null when unreadable. */
export function readSessionText(file: string): string | null {
  try {
    const raw = fs.readFileSync(file);
    if (!file.endsWith('.zstd')) return raw.toString('utf8');
    // zstd arrived in Node 22.15/23.8; an older Node skips these sessions instead of failing the sync.
    const decompress = (zlib as { zstdDecompressSync?: (body: Buffer) => Buffer }).zstdDecompressSync;
    if (typeof decompress !== 'function') return null;
    return decompress(raw).toString('utf8');
  } catch {
    return null;
  }
}

// One JSON file per message; probe XDG, then local, then macOS default.
export function opencodeSessionsDir(): string {
  const override = process.env.TERSIO_OPENCODE_DIR;
  if (override) return override;
  const xdg = process.env.XDG_DATA_HOME;
  if (xdg && xdg.trim() !== '') return path.join(xdg, 'opencode', 'storage', 'message');
  const local = path.join(homeDir(), '.local', 'share', 'opencode', 'storage', 'message');
  try {
    if (fs.existsSync(local)) return local;
  } catch { /* fall through to the platform default */ }
  return path.join(homeDir(), 'Library', 'Application Support', 'opencode', 'storage', 'message');
}

// OpenCode v2 keeps messages in sqlite; the JSON tree above is only the pre-v2 layout.
export function opencodeDbPath(): string {
  const override = process.env.TERSIO_OPENCODE_DB;
  if (override) return override;
  const xdg = process.env.XDG_DATA_HOME;
  if (xdg && xdg.trim() !== '') return path.join(xdg, 'opencode', 'opencode.db');
  const local = path.join(homeDir(), '.local', 'share', 'opencode', 'opencode.db');
  try {
    if (fs.existsSync(local)) return local;
  } catch { /* fall through to the platform default */ }
  return path.join(homeDir(), 'Library', 'Application Support', 'opencode', 'opencode.db');
}

export interface OpencodeDbRow {
  id: string;
  created: number;
  row: OpencodeMessage;
  /** Tool names this message called, comma-joined. Empty when it called none. */
  tools?: string;
}

// `message` vs `session_message`: read scalars only, since the blob's newlines break the row-per-line output.
const OC_DB_ORDER = ' ORDER BY time_created;';
const OC_DB_COLUMNS =
  'json_extract(data,\'$.time.created\'), json_extract(data,\'$.time.streamed\'), json_extract(data,\'$.time.completed\'),' +
  ' json_extract(data,\'$.tokens.input\'), json_extract(data,\'$.tokens.output\'),' +
  ' json_extract(data,\'$.tokens.cache.read\'), json_extract(data,\'$.tokens.cache.write\'), json_extract(data,\'$.cost\')';
const OC_DB_TOOLS =
  '(SELECT group_concat(json_extract(j.value,\'$.name\')) FROM json_each(data,\'$.content\') j' +
  ' WHERE json_extract(j.value,\'$.type\')=\'tool\')';
const ocDbLegacy = (since: number): string =>
  `SELECT id, time_created, json_extract(data,'$.role'), json_extract(data,'$.providerID'), json_extract(data,'$.modelID'), ${OC_DB_COLUMNS}, ${OC_DB_TOOLS}` +
  ` FROM message WHERE json_extract(data,'$.role')='assistant' AND time_created > ${since}${OC_DB_ORDER}`;
const ocDbCurrent = (since: number): string =>
  `SELECT id, time_created, 'assistant', json_extract(data,'$.model.providerID'), json_extract(data,'$.model.id'), ${OC_DB_COLUMNS}, ${OC_DB_TOOLS}` +
  ` FROM session_message WHERE type='assistant' AND time_created > ${since}${OC_DB_ORDER}`;

// A re-scan window covers tokens that land after the row was created, so a late fill is not lost.
export const OPENCODE_DB_OVERLAP_MS = 3_600_000;

/** Tab-split fields: empty and non-finite text read as absent. */
function tabNum(v: string | undefined): number | undefined {
  return v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : undefined;
}

// Empty when no SQLite is available or the db is unreadable; that is a sync skip, not a failure.
export function readOpencodeDbRows(db: string, sinceMs: number): OpencodeDbRow[] {
  if (!Number.isFinite(sinceMs)) return [];
  try {
    if (!fs.existsSync(db)) return [];
    const since = Math.max(0, Math.floor(sinceMs));
    // Separate calls: a db holding only one table must not cancel the other.
    const run = (sql: string): string => sqliteRead(db, sql);
    let out = '';
    try { out += run(ocDbLegacy(since)); } catch { /* no legacy table or unreadable */ }
    try { out += run(ocDbCurrent(since)); } catch { /* no session_message table or unreadable */ }
    const rows: OpencodeDbRow[] = [];
    for (const line of out.split('\n')) {
      if (!line.trim()) continue;
      const [id, created, role, providerID, modelID, tCreated, tStreamed, tCompleted, input, output, cacheRead, cacheWrite, cost, tools] = line.split('\t');
      rows.push({
        id,
        created: Number(created),
        tools: tools ?? '',
        row: {
          role,
          modelID,
          providerID,
          tokens: { input: tabNum(input), output: tabNum(output), cache: { read: tabNum(cacheRead), write: tabNum(cacheWrite) } },
          time: { created: tabNum(tCreated), streamed: tabNum(tStreamed), completed: tabNum(tCompleted) },
          cost: tabNum(cost),
        },
      });
    }
    return rows;
  } catch {
    return [];
  }
}

/** Zero-padded two-digit number, for the day keys. */
function pad2(n: number): string {
  return String(n).padStart(2, '0');
}

export function dayKey(ts: string | number): string | null {
  const ms = typeof ts === 'number' ? ts : Date.parse(ts);
  if (!Number.isFinite(ms)) return null;
  const d = new Date(ms);
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

// OpenCode tool parts carry the command in the message blob; sqliteRead is line-based, so newlines are flattened in SQL.
const OC_BASH_CMD = "replace(replace(json_extract(j.value,'$.state.input.command'), char(10), ' '), char(13), ' ')";
const OC_BASH_TOOL = "json_extract(j.value,'$.type')='tool' AND (json_extract(j.value,'$.name')='bash' OR json_extract(j.value,'$.name')='shell')";
const ocBashLegacy = `SELECT message.id, json_extract(message.data,'$.sessionID'), ${OC_BASH_CMD} FROM message, json_each(message.data,'$.content') j WHERE json_extract(message.data,'$.role')='assistant' AND ${OC_BASH_TOOL}`;
const ocBashCurrent = `SELECT session_message.id, session_message.session_id, ${OC_BASH_CMD} FROM session_message, json_each(session_message.data,'$.content') j WHERE session_message.type='assistant' AND ${OC_BASH_TOOL}`;

export interface OpencodeBashRow {
  id: string;
  sessionId: string;
  command: string;
}

/** Every executed bash command in an OpenCode db, v2 first and the legacy table second. */
export function readOpencodeBashRows(db: string): OpencodeBashRow[] {
  const rows: OpencodeBashRow[] = [];
  try {
    if (!fs.existsSync(db)) return rows;
    let out = '';
    try { out += sqliteRead(db, ocBashCurrent); } catch { /* no v2 table */ }
    try { out += sqliteRead(db, ocBashLegacy); } catch { /* no legacy table */ }
    for (const line of out.split('\n')) {
      if (!line.trim()) continue;
      const [id, sessionId, command] = line.split('\t');
      if (typeof command !== 'string' || !command.trim()) continue;
      rows.push({ id: id ?? '', sessionId: sessionId ?? '', command });
    }
  } catch { /* an unreadable db is a skip, not a failure */ }
  return rows;
}

// Pre-v2 OpenCode stores one message per JSON file; the same tool-part shape holds the command.
function opencodeFileBash(file: string): { commands: string[]; sessionId: string } {
  try {
    const message = JSON.parse(fs.readFileSync(file, 'utf8')) as { sessionID?: unknown; content?: unknown };
    const parts = Array.isArray(message.content) ? message.content : [];
    const commands: string[] = [];
    for (const part of parts) {
      const p = part as { type?: unknown; name?: unknown; state?: { input?: { command?: unknown } } };
      if (p?.type !== 'tool') continue;
      if (p.name !== 'bash' && p.name !== 'shell') continue;
      const command = p.state?.input?.command;
      if (typeof command === 'string' && command) commands.push(command);
    }
    return { commands, sessionId: typeof message.sessionID === 'string' ? message.sessionID : '' };
  } catch {
    return { commands: [], sessionId: '' };
  }
}
export function walkJsonl(dir: string, out: string[], cap: number, ext = '.jsonl'): void {
  let entries: fs.Dirent[];
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const e of entries) {
    if (out.length >= cap) return;
    const full = path.join(dir, e.name);
    if (e.isDirectory()) walkJsonl(full, out, cap, ext);
    else if (e.isFile() && e.name.endsWith(ext)) out.push(full);
  }
}
// Recent rows are a newest-first window over lifetime history; aggregates keep everything.
export const RECENT_LIMIT = 2000;
const FREE_SUFFIX = /(?::free|-free)$/i;
// Parse buffer shared by live reads and usage.db syncs, so the store is a cache and never a fork.
export interface SessionAccum {
  byModel: Record<string, TokenBreakdown>;
  byDay: Record<string, TokenBreakdown>;
  byDayModel: Record<string, Record<string, number>>;
  byTool: Record<string, number>;
  byModelMessages: Record<string, number>;
  byHost: Record<string, Record<string, TokenBreakdown>>;
  /** Model -> agent kind (`main`, `subagent`), so a subagent's work reads apart from its root's. */
  byAgent: Record<string, Record<string, TokenBreakdown>>;
  /** Model -> agent kind -> message count. */
  byAgentMessages: Record<string, Record<string, number>>;
  /** Model -> cost the host itself reported, summed over the messages that carried one. */
  byModelMeasured: Record<string, number>;
  /** Model -> messages that carried a cost. Compare to `byModelMessages` before trusting the sum. */
  byModelCostMessages: Record<string, number>;
  totals: TokenBreakdown;
  messages: number;
  costMeasured: number;
  recent: RecentRequest[];
  /** Oldest timestamp held in `recent`, so the list stays bounded instead of growing with the store. */
  recentFloor: number;
}
export function newSessionAccum(): SessionAccum {
  return { byModel: {}, byDay: {}, byDayModel: {}, byTool: {}, byModelMessages: {}, byHost: {}, byAgent: {}, byAgentMessages: {}, byModelMeasured: {}, byModelCostMessages: {}, totals: zeroBreakdown(), messages: 0, costMeasured: 0, recent: [], recentFloor: Number.POSITIVE_INFINITY };
}
/** Positive numbers floor to an int; anything else counts as 0. */
function positiveInt(v: unknown): number {
  return typeof v === 'number' && Number.isFinite(v) && v > 0 ? Math.floor(v) : 0;
}

export function ingestSessionRow(accum: SessionAccum, model: string, usage: Record<string, unknown>, ts: string | number | undefined, durMs?: unknown, run?: { st: RunStatus; code?: number; note?: string }, toolNames?: string[], host?: string, id?: string, agent?: string, ttftMs?: unknown): boolean {
  const watermark = readResetWatermark();
  const ms = ts === undefined ? NaN : typeof ts === 'number' ? ts : Date.parse(ts);
  if (watermark > 0 && (!Number.isFinite(ms) || ms < watermark)) return false;
  addInto(accum.totals, usage);
  const key = model.replace(FREE_SUFFIX, '').toLowerCase();
  accum.byModel[key] ??= zeroBreakdown();
  addInto(accum.byModel[key], usage);
  accum.byModelMessages[key] = (accum.byModelMessages[key] ?? 0) + 1;
  if (host) {
    const hs = (accum.byHost[key] ??= {});
    hs[host] ??= zeroBreakdown();
    addInto(hs[host], usage);
  }
  if (agent) {
    const as = (accum.byAgent[key] ??= {});
    as[agent] ??= zeroBreakdown();
    addInto(as[agent], usage);
    const am = (accum.byAgentMessages[key] ??= {});
    am[agent] = (am[agent] ?? 0) + 1;
  }
  if (Number.isFinite(ms)) {
    const outcome = run ?? { st: 'completed' as RunStatus };
    // Only the newest rows are read: skip below the floor, and a 50k-row store costs 2000 rows of memory.
    if (accum.recent.length < RECENT_LIMIT || ms >= accum.recentFloor) {
      accum.recent.push({ m: key, i: positiveInt(usage.input), o: positiveInt(usage.output), t: ms, d: durOf(durMs), tf: durOf(ttftMs), h: host, cr: positiveInt(usage.cacheRead), cw: positiveInt(usage.cacheWrite), usd: costOf(usage), st: outcome.st, code: outcome.code, note: outcome.note, id });
      if (accum.recent.length > RECENT_LIMIT) {
        let drop = 0;
        for (let k = 1; k < accum.recent.length; k += 1) if (accum.recent[k].t < accum.recent[drop].t) drop = k;
        accum.recent.splice(drop, 1);
        accum.recentFloor = accum.recent.reduce((lo, r) => Math.min(lo, r.t), Number.POSITIVE_INFINITY);
      } else if (ms < accum.recentFloor) {
        accum.recentFloor = ms;
      }
    }
  }
  const day = ts !== undefined ? dayKey(ts) : null;
  if (day) {
    accum.byDay[day] ??= zeroBreakdown();
    addInto(accum.byDay[day], usage);
    const sum = ['input', 'output', 'cacheRead', 'cacheWrite'].reduce((a, k) => a + (typeof usage[k] === 'number' && Number.isFinite(usage[k]) ? Math.floor(usage[k] as number) : 0), 0);
    if (sum > 0) {
      accum.byDayModel[day] ??= {};
      accum.byDayModel[day][key] = (accum.byDayModel[day][key] ?? 0) + sum;
    }
  }
  accum.messages += 1;
  const measured = costOf(usage);
  if (measured !== undefined) {
    accum.costMeasured += measured;
    accum.byModelMeasured[key] = (accum.byModelMeasured[key] ?? 0) + measured;
    accum.byModelCostMessages[key] = (accum.byModelCostMessages[key] ?? 0) + 1;
  }
  for (const name of toolNames ?? []) accum.byTool[name] = (accum.byTool[name] ?? 0) + 1;
  return true;
}
export type SessionLineKind = 'codex_provider' | 'codex_model' | 'dsh_model' | 'token_row' | 'assistant_row' | 'skip';

/** One tool call with the facts the Tools page reads: name, argument bytes, result bytes, error flag. */
export interface ToolFact {
  n: string;
  a: number;
  r: number;
  e: number;
}

/** Result text length and error flag per call id: both sit on the `toolResult` line, not on the call. */
export type ToolResults = Map<string, { chars: number; error: boolean }>;

/** The bytes a JSON value serializes to, which is what the model sent and the host stored. */
function jsonChars(value: unknown): number {
  if (value === undefined) return 0;
  try {
    return JSON.stringify(value).length;
  } catch {
    return 0;
  }
}

/** Every `toolResult` line in a transcript, keyed by the call it closes. */
export function collectToolResults(text: string): ToolResults {
  const found: ToolResults = new Map();
  for (const line of text.split('\n')) {
    if (!line.includes('toolResult')) continue;
    try {
      const row = JSON.parse(line) as { message?: { role?: unknown; toolCallId?: unknown; content?: unknown; isError?: unknown } };
      const msg = row.message;
      if (!msg || msg.role !== 'toolResult' || typeof msg.toolCallId !== 'string' || !msg.toolCallId) continue;
      const parts = Array.isArray(msg.content) ? msg.content as Array<Record<string, unknown>> : [];
      const chars = parts.reduce((sum, part) => sum + (typeof part.text === 'string' ? part.text.length : 0), 0);
      found.set(msg.toolCallId, { chars, error: msg.isError === true });
    } catch { /* skip a corrupt line */ }
  }
  return found;
}

/** A transcript line as every host writes it. Only the fields the parse reads are named. */
export interface SessionLineRow {
  timestamp?: string | number;
  type?: unknown;
  message?: {
    role?: unknown;
    model?: unknown;
    provider?: unknown;
    usage?: Record<string, unknown>;
    duration?: unknown;
    ttft?: unknown;
    completedAt?: unknown;
    timestamp?: unknown;
    stopReason?: unknown;
    errorStatus?: unknown;
    errorMessage?: unknown;
    isError?: unknown;
    content?: Array<{ type?: unknown; name?: unknown; id?: unknown; arguments?: unknown }>;
  };
  payload?: { type?: unknown; model?: unknown; model_provider?: unknown; info?: { last_token_usage?: Record<string, unknown> } };
  /** DeepSeek Harness writes `{ type, seq, time, data }` rows; the model arrives on its own event. */
  time?: number;
  data?: {
    model?: unknown;
    provider?: unknown;
    usage?: Record<string, unknown>;
    turn?: number;
    step?: number;
    header?: { config?: { provider?: unknown; model?: unknown } };
    stream?: Array<{ time?: number }>;
    message?: { role?: unknown; id?: unknown; content?: Array<{ type?: unknown; name?: unknown }> };
  };
}

/** What one transcript line classifies to. `assistant_row` carries the usage and the tool facts. */
export interface SessionLine {
  kind: SessionLineKind;
  provider?: string;
  model?: string;
  usage?: Record<string, unknown>;
  durMs?: number;
  ttftMs?: number;
  run?: { st: RunStatus; code?: number; note?: string };
  tools?: string[];
  toolFacts?: ToolFact[];
  ms?: number;
  /** The host's own message id, when the transcript carries one. */
  id?: string;
}

/** What a DeepSeek Harness transcript reveals across lines: the active model and each step's start. */
export interface DshParseState {
  model?: string;
  provider?: string;
  steps: Map<string, number>;
}

export function classifySessionLine(row: SessionLineRow, results?: ToolResults, dsh?: DshParseState): SessionLine {
  // DeepSeek Harness states the model once on `model/selection`, and again on each request header.
  if (row.type === 'model/selection' && row.data && typeof row.data.model === 'string' && row.data.model) {
    if (dsh) dsh.model = row.data.model;
    return { kind: 'dsh_model', model: row.data.model, provider: typeof row.data.provider === 'string' ? row.data.provider : undefined };
  }
  if (row.type === 'request/header' && row.data?.header?.config) {
    const config = row.data.header.config;
    if (typeof config.model === 'string' && config.model) {
      if (dsh) {
        dsh.model = config.model;
        dsh.provider = typeof config.provider === 'string' ? config.provider : dsh.provider;
      }
      return { kind: 'dsh_model', model: config.model, provider: typeof config.provider === 'string' ? config.provider : undefined };
    }
  }
  // The step's start turns the message's own time into a duration, and its first stream chunk into a TTFT.
  if (row.type === 'step/start' && dsh && typeof row.time === 'number' && row.data) {
    dsh.steps.set(`${row.data.turn}:${row.data.step}`, row.time);
    return { kind: 'skip' };
  }
  if (row.type === 'assistant/message' && row.data?.usage) {
    const usage = row.data.usage;
    const tools: string[] = [];
    for (const part of row.data.message?.content ?? []) {
      if (part?.type === 'tool-call' && typeof part.name === 'string' && part.name) tools.push(part.name);
    }
    const mapped = {
      input: usage['inputTokens'],
      output: usage['outputTokens'],
      cacheRead: usage['cacheReadTokens'],
      cacheWrite: usage['cacheWriteTokens'],
    };
    if (hasPositiveUsage(mapped)) {
      const start = dsh?.steps.get(`${row.data.turn}:${row.data.step}`);
      const first = row.data.stream?.find((entry) => typeof entry.time === 'number')?.time;
      const durMs = start !== undefined && typeof row.time === 'number' && row.time > start ? row.time - start : undefined;
      const ttftMs = start !== undefined && first !== undefined && first > start ? first - start : undefined;
      const id = typeof row.data.message?.id === 'string' ? row.data.message.id : undefined;
      const provider = dsh?.provider;
      return { kind: 'assistant_row', usage: mapped, tools, ms: row.time, durMs, ttftMs, id, provider, run: { st: 'completed' } };
    }
  }
  const payload = row.payload;
  if (payload && typeof payload === 'object') {
    if (row.type === 'session_meta' && typeof payload.model_provider === 'string') return { kind: 'codex_provider', provider: payload.model_provider };
    // A Codex transcript states the model once per turn, in turn_context.
    if (row.type === 'turn_context' && typeof payload.model === 'string' && payload.model) {
      return { kind: 'codex_model', model: payload.model };
    }
    if (payload.type === 'token_count') {
      const last = payload.info?.last_token_usage;
      if (last) {
        const provider = typeof payload.model_provider === 'string' ? payload.model_provider : undefined;
        const ts = row.timestamp === undefined ? NaN : typeof row.timestamp === 'number' ? row.timestamp : Date.parse(row.timestamp);
        return { kind: 'token_row', provider, model: 'codex', usage: { input: last['input_tokens'], output: last['output_tokens'], cacheRead: last['cached_input_tokens'], cacheWrite: last['cache_write_input_tokens'] }, ms: Number.isFinite(ts) ? ts : undefined };
      }
    }
  }
  const msg = row.message;
  if (!msg || msg.role !== 'assistant' || !msg.usage) return { kind: 'skip' };
  const model = typeof msg.model === 'string' && msg.model ? msg.model : 'unknown';
  // pi omits duration, so derive Elapsed/Speed from the timestamp pair.
  const startMs = typeof msg.timestamp === 'number' ? msg.timestamp : undefined;
  const endMs = typeof msg.completedAt === 'number' ? msg.completedAt : stampMs(row.timestamp);
  const computedDur = startMs !== undefined && Number.isFinite(endMs) && endMs > startMs ? endMs - startMs : undefined;
  const tools: string[] = [];
  const toolFacts: ToolFact[] = [];
  for (const part of msg.content ?? []) {
    if (part?.type !== 'toolCall' || typeof part.name !== 'string' || !part.name) continue;
    const name = part.name === 'bash'
      ? `bash:${leadBinary((part.arguments as { command?: unknown } | null)?.command)}`
      : part.name;
    tools.push(name);
    const result = typeof part.id === 'string' ? results?.get(part.id) : undefined;
    toolFacts.push({ n: name, a: jsonChars(part.arguments), r: result?.chars ?? 0, e: result?.error ? 1 : 0 });
  }
  // The gateway that served the turn: `commandcode` for `deepseek/...`, which the model id cannot show.
  const provider = typeof msg.provider === 'string' && msg.provider ? msg.provider : undefined;
  return { kind: 'assistant_row', model, provider, usage: msg.usage, durMs: typeof msg.duration === 'number' ? msg.duration : computedDur, ttftMs: typeof msg.ttft === 'number' ? msg.ttft : undefined, run: statusOf(msg), tools, toolFacts };
}
// True when at least one token bucket holds a positive finite count.
export function hasPositiveUsage(usage: Record<string, unknown>): boolean {
  for (const k of ['input', 'output', 'cacheRead', 'cacheWrite']) {
    const v = usage[k];
    if (typeof v === 'number' && Number.isFinite(v) && v > 0) return true;
  }
  return false;
}

export interface OpencodeMessage {
  role?: unknown;
  tokens?: { input?: unknown; output?: unknown; reasoning?: unknown; cache?: { read?: unknown; write?: unknown } } | null;
  modelID?: unknown;
  providerID?: unknown;
  time?: { created?: unknown; streamed?: unknown; completed?: unknown } | null;
  cost?: unknown;
  finish?: unknown;
  /** The message's parts. Tool calls sit here, named under a part of type `tool`. */
  content?: unknown;
}

/** Tool names an OpenCode message called; v2 passes SQL's comma-joined string as the blob holds newlines. */
export function opencodeToolNames(message: OpencodeMessage, joined?: string): string[] {
  if (joined !== undefined) return joined === '' ? [] : joined.split(',');
  const parts = message?.content;
  if (!Array.isArray(parts)) return [];
  const names: string[] = [];
  for (const part of parts) {
    if (!part || typeof part !== 'object') continue;
    if ((part as Record<string, unknown>).type !== 'tool') continue;
    const name = (part as Record<string, unknown>).name;
    if (typeof name === 'string' && name) names.push(name);
  }
  return names;
}

/** One OpenCode assistant message, as the shared accumulator reads it. */
export interface OpencodeClassification {
  model: string;
  usage: Record<string, unknown>;
  ms: number | undefined;
  durMs: number | undefined;
  ttftMs: number | undefined;
}

/** Positive finite numbers pass through; anything else reads as absent. */
function posNum(v: unknown): number | undefined {
  return typeof v === 'number' && Number.isFinite(v) && v > 0 ? v : undefined;
}

// One OpenCode message file; assistant rows carry the token buckets.
export function classifyOpencodeMessage(obj: OpencodeMessage | null | undefined): OpencodeClassification | null {
  if (!obj || typeof obj !== 'object' || obj.role !== 'assistant') return null;
  const t = obj.tokens;
  if (!t || typeof t !== 'object') return null;
  const usage: Record<string, unknown> = {
    input: t.input,
    output: t.output,
    cacheRead: t.cache?.read,
    cacheWrite: t.cache?.write,
    cost: (obj as Record<string, unknown>).cost,
  };
  if (!hasPositiveUsage(usage)) return null;
  const provider = typeof obj.providerID === 'string' && obj.providerID ? obj.providerID : 'unknown';
  const model = typeof obj.modelID === 'string' && obj.modelID ? obj.modelID : 'unknown';
  const created = posNum(obj.time?.created);
  const completed = posNum(obj.time?.completed);
  // `streamed` is when the first token arrived, so it is the host's own first-token latency.
  const streamed = posNum(obj.time?.streamed);
  return {
    model: `opencode/${provider}/${model}`,
    usage,
    ms: created,
    durMs: created !== undefined && completed !== undefined && completed > created ? completed - created : undefined,
    ttftMs: created !== undefined && streamed !== undefined && streamed > created ? streamed - created : undefined,
  };
}

export function processOpencodeFile(accum: SessionAccum, text: string, file?: string): void {
  let obj: unknown;
  try {
    obj = JSON.parse(text);
  } catch {
    return;
  }
  const message = obj as OpencodeMessage;
  const parsed = classifyOpencodeMessage(message);
  if (!parsed) return;
  const id = file ? path.basename(file).replace(/\.[^.]+$/, '') || undefined : undefined;
  ingestSessionRow(accum, parsed.model, parsed.usage, parsed.ms, parsed.durMs, { st: 'completed' as RunStatus }, opencodeToolNames(message), 'opencode', id, 'main', parsed.ttftMs);
}

// One v2 message row into the shared accum. The msg id is the row primary key.
export function ingestOpencodeDbRow(accum: SessionAccum, row: OpencodeDbRow): void {
  const parsed = classifyOpencodeMessage(row.row);
  if (!parsed) return;
  ingestSessionRow(accum, parsed.model, parsed.usage, parsed.ms, parsed.durMs, { st: 'completed' as RunStatus }, opencodeToolNames(row.row, row.tools), 'opencode', row.id, 'main', parsed.ttftMs);
}

// Fold `:free`/`-free` suffixes and case variants into one chart key.
export function canonicalModelId(model: string): string {
  return canonicalPriceId(model.replace(FREE_SUFFIX, ''));
}
// Transcript row id when the host provides one; anything else is not an id.
export function messageRowId(row: unknown): string | undefined {
  const id = (row as { id?: unknown }).id;
  return typeof id === 'string' && id ? id : undefined;
}

// Vendor names mirror the dashboard map; family first, so gateway segments shadow it (minimaxai holds xai).
const VENDOR_RES: Array<[RegExp, string]> = [
  [/inclusionai|ling-/i, 'InclusionAI'],
  [/minimax/i, 'MiniMax'],
  [/grok|xai/i, 'xAI'],
  [/stealth|space-bunny/i, 'Stealth'],
  [/^beam$/i, 'Beam'],
  [/openai|codex|gpt-|o1/i, 'OpenAI'],
  [/muse|llama/i, 'Meta'],
  [/deepseek/i, 'DeepSeek'],
  [/qwen|qwq/i, 'Alibaba'],
  [/glm|z-ai|zhipu/i, 'Z.ai'],
  [/mimo/i, 'Xiaomi'],
  [/kimi|moonshot/i, 'Moonshot'],
  [/mistral/i, 'Mistral'],
  [/claude|anthropic/i, 'Anthropic'],
  [/gemini|google|gemma/i, 'Google'],
  [/nemotron|nvidia/i, 'NVIDIA'],
  [/devin|cognition|^swe[-/]/i, 'Cognition'],
];

function modelVendor(model: string): string {
  // Tail first: gateway prefixes ("codex/openai/...") must not shadow the model author, so a DeepSeek or GLM run through Codex still reads as DeepSeek or Z.ai.
  const segs = String(model).split('/').filter(Boolean);
  for (let i = segs.length - 1; i >= 0; i--) {
    for (const [re, name] of VENDOR_RES) {
      if (re.test(segs[i])) return name;
    }
  }
  // A pattern may span segments ("typesafe/jev"), so the whole string still gets one pass.
  for (const [re, name] of VENDOR_RES) {
    if (re.test(String(model))) return name;
  }
  return 'Other';
}

// Gateway variants of one model share a row under the display label.
export function foldModelsByLabel(
  byModel: Record<string, TokenBreakdown>,
  byModelMessages: Record<string, number>,
): { byModel: Record<string, TokenBreakdown>; byModelMessages: Record<string, number> } {
  const folded: Record<string, TokenBreakdown> = {};
  const messages: Record<string, number> = {};
  for (const [model, t] of Object.entries(byModel)) {
    const label = displayModelId(model);
    folded[label] ??= { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 };
    const into = folded[label];
    into.input += t.input;
    into.output += t.output;
    into.cacheRead += t.cacheRead;
    into.cacheWrite += t.cacheWrite;
    messages[label] = (messages[label] ?? 0) + (byModelMessages[model] ?? 0);
  }
  return { byModel: folded, byModelMessages: messages };
}
/** Capitalize one word the way each vendor spells itself: GPT, SWE, AI, d4-style codes. */
function capWord(s: string): string {
  const low = s.toLowerCase();
  if (low === 'openai') return 'OpenAI';
  if (low === 'gpt') return 'GPT';
  if (low === 'swe') return 'SWE';
  if (low === 'ai') return 'AI';
  if (/^\d+[a-z]+$/.test(low)) return low.toUpperCase();
  if (s.length <= 2) return s.toUpperCase();
  return s[0].toUpperCase() + s.slice(1).toLowerCase();
}

function seg(s: string): string {
  return s.split('.').map(capWord).join('.');
}

function words(s: string): string {
  return s.split(/[-_:]+/).filter(Boolean).map(seg).join('-');
}

// Vendor-first labels, same fold as the dashboard: "Anthropic - Claude - Haiku-4.5".
export function displayModelId(model: string): string {
  const bare = model.replace(FREE_SUFFIX, '');
  // The report already folds keys; folding again would lowercase the caps.
  if (bare.includes(' - ')) return bare;
  const segs = bare.split('/').filter(Boolean);
  const tail = segs[segs.length - 1] ?? bare;
  // One free model under two spellings; fold the alpha variant onto it.
  const pretty = /^space-bunny(-alpha)?$/i.test(tail) ? 'Space-Bunny' : words(tail);
  const vendor = modelVendor(bare);
  if (vendor === 'Other') return segs.length > 1 ? `${words(segs[segs.length - 2])} - ${pretty}` : pretty;
  const claude = pretty.match(/^claude[-_](.+)$/i);
  if (vendor === 'Anthropic' && claude) return `Anthropic - Claude - ${claude[1]}`;
  // GLM is always uppercase, and the vendor names Z.ai, so the label folds the same way.
  const glm = pretty.match(/^glm[-_](.+)$/i);
  if (vendor === 'Z.ai' && glm) return `Z.ai - GLM - ${glm[1]}`;
  if (pretty.toLowerCase().startsWith(vendor.toLowerCase())) return pretty;
  return `${vendor} - ${pretty}`;
}

export function importSessionTokens(): SessionTokens {
  const accum = newSessionAccum();
  const files: string[] = [];
  for (const dir of sessionsDirs()) walkJsonl(dir, files, 2000);
  // OpenCode message bodies are single JSON documents, not JSONL.
  const ocFiles: string[] = [];
  if (process.env.TERSIO_SESSIONS_DIR === undefined || process.env.TERSIO_OPENCODE_DIR !== undefined) {
    walkJsonl(opencodeSessionsDir(), ocFiles, 5000, '.json');
  }
  for (const file of ocFiles) {
    let text: string;
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch {
      continue;
    }
    processOpencodeFile(accum, text, file);
  }
  // v2 hosts write sqlite, not the JSON tree above.
  if (process.env.TERSIO_SESSIONS_DIR === undefined || process.env.TERSIO_OPENCODE_DB !== undefined) {
    for (const row of readOpencodeDbRows(opencodeDbPath(), 0)) ingestOpencodeDbRow(accum, row);
  }
  const dshFiles = process.env.TERSIO_SESSIONS_DIR === undefined ? dshSessionFiles() : [];
  for (const file of [...files, ...dshFiles]) {
    const text = readSessionText(file);
    if (text === null) continue;
    processSessionText(accum, { codexProvider: null, codexModel: null, dshModel: null }, text, hostOfSessionFile(file), agentOfSessionText(text));
  }
  accum.recent.sort((a, b) => b.t - a.t);
  return { messages: accum.messages, totals: accum.totals, byModel: accum.byModel, byDay: accum.byDay, byDayModel: accum.byDayModel, byTool: accum.byTool, byModelMessages: accum.byModelMessages, byHost: accum.byHost, byAgent: accum.byAgent, byAgentMessages: accum.byAgentMessages, byModelMeasured: accum.byModelMeasured, byModelCostMessages: accum.byModelCostMessages, costMeasured: accum.costMeasured, recent: accum.recent.slice(0, RECENT_LIMIT) };
}

// Which agent wrote a session file, from the directory it sits in.
export function hostOfSessionFile(file: string): string {
  const norm = file.replace(/\\/g, '/');
  if (norm.includes('/.dsh/')) return 'dsh';
  if (norm.includes('/.omp/')) return 'omp';
  if (norm.includes('/.codex/')) return 'codex';
  if (norm.includes('/opencode/')) return 'opencode';
  return 'pi';
}

// A transcript with a parent session ran as a subagent; the host's own row, so a mirror answers the same.
export function agentOfSessionText(text: string): string {
  // DeepSeek Harness marks a child by its delegation depth on the opening session event.
  if (/"delegationDepth"\s*:\s*[1-9]/.test(text.slice(0, 4000))) return 'subagent';
  if (!text.includes('parentSession')) return 'main';
  for (const line of text.split('\n')) {
    if (!line.includes('parentSession')) continue;
    try {
      const row = JSON.parse(line) as { type?: unknown; parentSession?: unknown };
      if (row.type === 'session' && typeof row.parentSession === 'string' && row.parentSession !== '') return 'subagent';
    } catch { /* skip a corrupt line */ }
  }
  return 'main';
}

const adoptionFileCache = new Map<string, { size: number; mtimeMs: number; heads: string; counts: BashCounts }>();

interface BashCounts { bashCalls: number; eligibleCalls: number; rtkCalls: number }

function countBashCommands(commands: readonly string[], eligible: ReadonlySet<string>, counts: BashCounts): void {
  for (const command of commands) {
    counts.bashCalls += 1;
    const head = leadBinary(command);
    if (eligible.has(head)) counts.eligibleCalls += 1;
    if (head === 'rtk') counts.rtkCalls += 1;
  }
}

interface PiToolCall {
  type?: unknown;
  name?: unknown;
  id?: unknown;
  arguments?: unknown;
}

function parseAdoptionFile(file: string, eligible: ReadonlySet<string>): { counts: BashCounts; sessions: number } {
  const counts: BashCounts = { bashCalls: 0, eligibleCalls: 0, rtkCalls: 0 };
  let text: string;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch {
    return { counts, sessions: 0 };
  }
  // omp emits a custom row per tool start; pi records the same call inside the assistant message. A host that writes both shapes would double every call, so the custom ids gate the message pass.
  const commands: string[] = [];
  const customIds = new Set<string>();
  const messageCalls: Array<{ id: string | undefined; command: string }> = [];
  for (const line of text.split('\n')) {
    if (!line.includes('tool_execution_start') && !line.includes('"toolCall"')) continue;
    try {
      const row = JSON.parse(line) as {
        type?: unknown;
        customType?: unknown;
        data?: { toolCallId?: unknown; toolName?: unknown; args?: { command?: unknown } };
        message?: { content?: unknown };
      };
      if (row.type === 'custom' && row.customType === 'tool_execution_start' && row.data?.toolName === 'bash') {
        const command = row.data.args?.command;
        if (typeof command !== 'string') continue;
        if (typeof row.data.toolCallId === 'string') customIds.add(row.data.toolCallId);
        commands.push(command);
        continue;
      }
      const content = row.message?.content;
      if (row.type !== 'message' || !Array.isArray(content)) continue;
      for (const part of content) {
        if (typeof part !== 'object' || part === null) continue;
        const call: PiToolCall = part;
        if (call.type !== 'toolCall' || call.name !== 'bash') continue;
        const args = call.arguments;
        if (typeof args !== 'object' || args === null || !('command' in args)) continue;
        const command = args.command;
        if (typeof command !== 'string') continue;
        messageCalls.push({ id: typeof call.id === 'string' ? call.id : undefined, command });
      }
    } catch { /* skip corrupt line */ }
  }
  for (const call of messageCalls) {
    if (call.id !== undefined && customIds.has(call.id)) continue;
    commands.push(call.command);
  }
  countBashCommands(commands, eligible, counts);
  return { counts, sessions: commands.length > 0 ? 1 : 0 };
}

export function clearRtkAdoptionCache(): void {
  adoptionFileCache.clear();
}

/** Rewrites the hook performed on hosts whose transcript records the pre-hook command, by host. */
function countRtkAuditRows(): Record<string, number> {
  const byHost: Record<string, number> = {};
  let text: string;
  try { text = fs.readFileSync(ledgerPath(), 'utf8'); } catch { return byHost; }
  for (const line of text.split('\n')) {
    if (!line.includes('rtk-audit')) continue;
    try {
      const row = JSON.parse(line) as { kind?: unknown; detail?: unknown };
      if (row.kind !== 'rtk-audit' || typeof row.detail !== 'string') continue;
      const host = row.detail.split(' ')[0];
      if (!host) continue;
      byHost[host] = (byHost[host] ?? 0) + 1;
    } catch { /* skip corrupt line */ }
  }
  return byHost;
}

export function readRtkAdoption(): RtkAdoption {
  // The eligible set comes from rtk's rewrite contract, cached per binary version.
  const eligible = eligibleHeads(resolveRtkBinary());
  // A cached count is only valid for the head set that produced it.
  const headsKey = [...eligible].toSorted().join(',');
  const files: string[] = [];
  for (const dir of sessionsDirs()) walkJsonl(dir, files, 2000);
  const live = new Set(files);
  for (const file of adoptionFileCache.keys()) {
    if (!live.has(file)) adoptionFileCache.delete(file);
  }
  let bashCalls = 0;
  let eligibleCalls = 0;
  let rtkCalls = 0;
  let sessions = 0;
  const byHost: Record<string, BashCounts> = {};
  const hostCounts = (host: string, counts: BashCounts): void => {
    const into = byHost[host] ?? { bashCalls: 0, eligibleCalls: 0, rtkCalls: 0 };
    into.bashCalls += counts.bashCalls;
    into.eligibleCalls += counts.eligibleCalls;
    into.rtkCalls += counts.rtkCalls;
    byHost[host] = into;
  };
  for (const file of files) {
    let stat: fs.Stats;
    try {
      stat = fs.statSync(file);
    } catch {
      continue;
    }
    let entry = adoptionFileCache.get(file);
    if (!entry || entry.size !== stat.size || entry.mtimeMs !== stat.mtimeMs || entry.heads !== headsKey) {
      const parsed = parseAdoptionFile(file, eligible);
      entry = { size: stat.size, mtimeMs: stat.mtimeMs, heads: headsKey, counts: parsed.counts };
      adoptionFileCache.set(file, entry);
      sessions += parsed.sessions;
    } else if (entry.counts.bashCalls > 0) {
      sessions += 1;
    }
    bashCalls += entry.counts.bashCalls;
    eligibleCalls += entry.counts.eligibleCalls;
    rtkCalls += entry.counts.rtkCalls;
    hostCounts(hostOfSessionFile(file), entry.counts);
  }
  // OpenCode keeps its own store: a v2 sqlite db, or one JSON file per message before v2.
  const opencode: BashCounts = { bashCalls: 0, eligibleCalls: 0, rtkCalls: 0 };
  const opencodeSessions = new Set<string>();
  if (process.env.TERSIO_SESSIONS_DIR === undefined || process.env.TERSIO_OPENCODE_DB !== undefined) {
    for (const row of readOpencodeBashRows(opencodeDbPath())) {
      countBashCommands([row.command], eligible, opencode);
      if (row.sessionId) opencodeSessions.add(row.sessionId);
    }
  }
  const ocFiles: string[] = [];
  if (process.env.TERSIO_SESSIONS_DIR === undefined || process.env.TERSIO_OPENCODE_DIR !== undefined) {
    walkJsonl(opencodeSessionsDir(), ocFiles, 5000, '.json');
    for (const file of ocFiles) {
      const parsed = opencodeFileBash(file);
      countBashCommands(parsed.commands, eligible, opencode);
      if (parsed.sessionId) opencodeSessions.add(parsed.sessionId);
    }
  }
  bashCalls += opencode.bashCalls;
  eligibleCalls += opencode.eligibleCalls;
  rtkCalls += opencode.rtkCalls;
  sessions += opencodeSessions.size;
  if (opencode.bashCalls > 0) hostCounts('opencode', opencode);
  // The hook audit carries rewrites on pi and opencode, whose transcripts record the pre-hook command.
  for (const [host, rows] of Object.entries(countRtkAuditRows())) {
    rtkCalls += rows;
    hostCounts(host, { bashCalls: 0, eligibleCalls: 0, rtkCalls: rows });
  }
  const missedCalls = Math.max(0, eligibleCalls - rtkCalls);
  const host = (counts: BashCounts): RtkHostAdoption => ({
    bashCalls: counts.bashCalls,
    eligibleCalls: counts.eligibleCalls,
    rtkCalls: counts.rtkCalls,
    missedCalls: Math.max(0, counts.eligibleCalls - counts.rtkCalls),
    adoptionPct: counts.eligibleCalls ? (counts.rtkCalls / counts.eligibleCalls) * 100 : 0,
  });
  return {
    sessions,
    bashCalls,
    eligibleCalls,
    rtkCalls,
    missedCalls,
    adoptionPct: eligibleCalls ? (rtkCalls / eligibleCalls) * 100 : 0,
    byHost: Object.fromEntries(Object.entries(byHost).map(([name, counts]) => [name, host(counts)])),
  };
}
export function processSessionText(accum: SessionAccum, state: { codexProvider: string | null; codexModel?: string | null; dshModel?: string | null }, text: string, host?: string, agent?: string): void {
  // A call's result arrives on a later line, so the whole file is scanned for results first.
  const results = collectToolResults(text);
  // Per file: a transcript's model and step starts must not leak into the next file.
  const dsh: DshParseState = { steps: new Map() };
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      const row = JSON.parse(line) as SessionLineRow;
      const parsed = classifySessionLine(row, results, dsh);
      const rid = parsed.id ?? messageRowId(row);
      if (parsed.kind === 'codex_provider') {
        if (parsed.provider) state.codexProvider = parsed.provider;
        continue;
      }
      if (parsed.kind === 'codex_model') {
        if (parsed.model) state.codexModel = parsed.model;
        continue;
      }
      if (parsed.kind === 'dsh_model') {
        if (parsed.model) state.dshModel = parsed.model;
        continue;
      }
      if (parsed.kind === 'token_row') {
        const base = parsed.provider ? `codex/${parsed.provider}` : (state.codexProvider ? `codex/${state.codexProvider}` : 'codex');
        // The provider alone told you nothing about which model ran.
        const model = state.codexModel ? `${base}/${state.codexModel}` : base;
        ingestSessionRow(accum, model, parsed.usage ?? {}, row.timestamp, parsed.durMs, { st: 'completed' as RunStatus }, undefined, host ?? 'codex', rid, agent);
        continue;
      }
      // A DeepSeek Harness row names no model itself; the session's last model/selection does.
      const model = parsed.model ?? (row.type === 'assistant/message' ? state.dshModel ?? undefined : undefined);
      if (parsed.kind !== 'assistant_row' || !model || !parsed.usage) continue;
      ingestSessionRow(accum, model, parsed.usage, row.timestamp ?? row.time, parsed.durMs, parsed.run, parsed.tools, host, rid, agent, parsed.ttftMs);
    } catch { /* skip corrupt lines */ }
  }
}

// Lead binary of a shell string: first segment past `cd` chains and VAR=x assignments. Falls back to `bash`.
const SKIP_HEADS = ['cd', 'echo', 'export', 'true', 'false'];
export function leadBinary(command: unknown): string {
  if (typeof command !== 'string' || !command.trim()) return 'bash';
  for (const chunk of command.split(/&&|;|\n|\|(?!\|)/)) {
    const toks = chunk.trim().split(/\s+/).filter(Boolean);
    let i = 0;
    while (i < toks.length && (toks[i] === 'sudo' || /^[A-Za-z_][A-Za-z0-9_]*=/.test(toks[i]))) i++;
    const head = (toks[i] ?? '').replace(/^['"]|['"]$/g, '').split('/').pop() ?? '';
    if (head && !SKIP_HEADS.includes(head)) return head;
  }
  return 'bash';
}

// Pricing lives in ./pricing.ts (live LiteLLM cache + fallback table).
import { DEFAULT_PRICE, PRICE_TIERS_FIRM, canonicalPriceId, priceFor, pricesOverridePath, refreshPricesIfStale, type PriceHit, type PriceTier } from './pricing.ts';
import { co2GramsFor, energyWhFor } from './carbon.ts';
import type { ModelPrice } from './pricing.ts';

export { DEFAULT_PRICE, PRICE_TIERS_FIRM, priceFor, pricesOverridePath, refreshPricesIfStale };
export { co2GramsFor, energyWhFor };
export type { PriceHit, PriceTier, ModelPrice };

/** Price one model's tokens; `measured` outranks every rate card, so pass undefined when unreported. */
export function usdCost(t: TokenBreakdown, model?: string, measured?: number): { usd: number; priced: boolean; tier: PriceTier; buckets: { input: number; output: number; cacheRead: number; cacheWrite: number } } {
  const m = 1 / 1_000_000;
  if (measured !== undefined) {
    // Only a bare total arrives, so it attributes to input, the largest bucket for every model here.
    return {
      usd: measured,
      priced: true,
      tier: 'measured',
      buckets: { input: measured, output: 0, cacheRead: 0, cacheWrite: 0 },
    };
  }
  const hit: PriceHit = model ? priceFor(model) : { price: DEFAULT_PRICE, known: false, live: false, tier: 'default' };
  const price = hit.price;
  const buckets = {
    input: t.input * price.input * m,
    output: t.output * price.output * m,
    cacheRead: t.cacheRead * price.cacheRead * m,
    cacheWrite: t.cacheWrite * price.cacheWrite * m,
  };
  return {
    usd: buckets.input + buckets.output + buckets.cacheRead + buckets.cacheWrite,
    // `tail`/`default` are estimates; summing them beside measured cost reads as a bill it is not.
    priced: PRICE_TIERS_FIRM.includes(hit.tier),
    tier: hit.tier,
    buckets,
  };
}

export function co2Grams(outputTokens: number, model?: string): number {
  return co2GramsFor(model ?? 'gpt-4o', outputTokens);
}

export function readUsage(): UsageRow[] {
  let text: string;
  try {
    text = fs.readFileSync(ledgerPath(), 'utf8');
  } catch {
    return [];
  }
  const rows: UsageRow[] = [];
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      const row = JSON.parse(line) as Partial<UsageRow>;
      if (typeof row.ts === 'number' && typeof row.kind === 'string' && typeof row.detail === 'string') {
        rows.push({ ts: row.ts, kind: row.kind as UsageKind, detail: row.detail });
      }
    } catch { /* skip corrupt lines */ }
  }
  return rows;
}

// Delete the ledger file and return the rows cleared. Tersio-owned data only: transcripts and the RTK database stay.
export function clearUsageLedger(): number {
  const rows = readUsage().length;
  try {
    fs.unlinkSync(ledgerPath());
  } catch { /* already absent */ }
  return rows;
}