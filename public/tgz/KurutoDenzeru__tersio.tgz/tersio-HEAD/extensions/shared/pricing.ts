// pricing.ts — model pricing from LiteLLM. Exact id → prefix strip → default, known:false if unpriced.
import fs from 'node:fs';
import path from 'node:path';
import { cacheGet, cachePut, cacheStamp } from './cache-store.ts';
import { readPluginSettings, tersioSettingsFile } from './plugin-settings.ts';
import { tersioDataPath, tersioHome } from './utils.ts';

export interface ModelPrice {
  input: number;
  output: number;
  cacheRead: number;
  cacheWrite: number;
}

// Sonnet-class default for unpriced models; always paired with known:false.
export const DEFAULT_PRICE: ModelPrice = { input: 2, output: 10, cacheRead: 0.2, cacheWrite: 2.5 };

/** How a price was found, strongest first; `tail` and `default` are estimates. */
export type PriceTier = 'measured' | 'override' | 'exact' | 'alias' | 'tail' | 'default';

/** Tiers firm enough to call a price; `tail` and `default` are estimates. */
export const PRICE_TIERS_FIRM: readonly PriceTier[] = ['measured', 'override', 'exact', 'alias'];

export interface PriceHit {
  price: ModelPrice;
  known: boolean;
  live: boolean;
  tier: PriceTier;
}

const LITELLM_URL = 'https://raw.githubusercontent.com/BerriAI/litellm/main/model_prices_and_context_window.json';
// Readers use the file even when stale; one refresh per process. `tersio update` still forces a fresh fetch.
const CACHE_TTL_MS = 7 * 24 * 3600 * 1000;
let refreshInflight: Promise<boolean> | null = null;

/** The cache key the price table lives under, beside the usage ledger. */
const PRICES_KEY = 'prices';

/** The legacy file, read once so an existing cache survives the move. */
export function pricesCachePath(): string {
  return tersioDataPath('prices.json', 'tersio-prices.json');
}

/** Operator prices keyed as the transcript spells a model; a `*` prefix matches any gateway suffix. */
export function pricesOverridePath(): string {
  const override = process.env.TERSIO_PRICES_OVERRIDE_FILE;
  if (override) return override;
  return path.join(tersioHome(), 'prices.local.json');
}

/** The cached feed text: the env file when a caller pins one, else the ledger. */
function readCacheText(): string | null {
  const file = process.env.TERSIO_PRICES_FILE;
  if (file) {
    try { return fs.readFileSync(file, 'utf8'); } catch { return null; }
  }
  const stored = cacheGet(PRICES_KEY);
  if (stored !== null) return stored;
  // One-time import: a cache written by an older build keeps working, then leaves the data home.
  try {
    const text = fs.readFileSync(pricesCachePath(), 'utf8');
    cachePut(PRICES_KEY, text);
    fs.rmSync(pricesCachePath(), { force: true });
    return text;
  } catch {
    return null;
  }
}

/** Changes whenever the cache changes, so the in-process memo can tell. */
function cacheToken(): string | number {
  const file = process.env.TERSIO_PRICES_FILE;
  if (file) {
    try { const s = fs.statSync(file); return `${s.mtimeMs}:${s.size}`; } catch { return 'missing'; }
  }
  return cacheStamp(PRICES_KEY);
}

function writeCacheText(text: string): boolean {
  const file = process.env.TERSIO_PRICES_FILE;
  if (file) {
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true });
      fs.writeFileSync(file, text, 'utf8');
      return true;
    } catch { return false; }
  }
  return cachePut(PRICES_KEY, text);
}

/** The override map: the env file, else the settings store, else the legacy file imported once. */
function overrideSource(): { text: string | null; stamp: number } {
  const envFile = process.env.TERSIO_PRICES_OVERRIDE_FILE;
  if (envFile) {
    try { const s = fs.statSync(envFile); return { text: fs.readFileSync(envFile, 'utf8'), stamp: s.mtimeMs }; } catch { return { text: null, stamp: 0 }; }
  }
  const block = readPluginSettings().prices;
  if (block && typeof block === 'object' && !Array.isArray(block)) {
    let stamp = 0;
    try { stamp = fs.statSync(tersioSettingsFile()).mtimeMs; } catch { stamp = 0; }
    return { text: JSON.stringify(block), stamp };
  }
  const legacy = pricesOverridePath();
  try {
    const text = fs.readFileSync(legacy, 'utf8');
    const parsed = JSON.parse(text) as Record<string, unknown>;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      savePricesOverride(parsed);
      fs.rmSync(legacy, { force: true });
      let stamp = 0;
      try { stamp = fs.statSync(tersioSettingsFile()).mtimeMs; } catch { stamp = 0; }
      return { text, stamp };
    }
  } catch { /* no legacy overrides */ }
  return { text: null, stamp: 0 };
}

/** Writes the `prices` block the settings file owns, so an operator edits one store, not a second file. */
export function savePricesOverride(prices: Record<string, unknown>): boolean {
  try {
    const file = tersioSettingsFile();
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const stored = readPluginSettings();
    fs.writeFileSync(file, `${JSON.stringify({ ...stored, prices }, null, 2)}\n`, 'utf8');
    return true;
  } catch {
    return false;
  }
}

/** The override's mtime, or 0 when absent. A stat only, because this sits on the price lookup path. */
function overrideStamp(): number {
  const envFile = process.env.TERSIO_PRICES_OVERRIDE_FILE;
  if (envFile) {
    try { return fs.statSync(envFile).mtimeMs; } catch { return 0; }
  }
  try { return fs.statSync(tersioSettingsFile()).mtimeMs; } catch { return 0; }
}

let overrideCache: { stamp: number; exact: Map<string, ModelPrice>; tails: Array<[string, ModelPrice]> } | null = null;

/** Reads the override file, keeping a `*`-prefixed entry as a suffix matcher. */
function loadOverrides(stamp = overrideStamp()): { exact: Map<string, ModelPrice>; tails: Array<[string, ModelPrice]> } | null {
  if (overrideCache && overrideCache.stamp === stamp) return overrideCache;
  const exact = new Map<string, ModelPrice>();
  const tails: Array<[string, ModelPrice]> = [];
  try {
    const source = overrideSource().text;
    if (source === null) return null;
    const parsed = JSON.parse(source) as Record<string, unknown>;
    for (const [id, row] of Object.entries(parsed ?? {})) {
      const price = asPrice(row);
      if (!price) continue;
      if (id.startsWith('*')) tails.push([id.slice(1).toLowerCase(), price]);
      else exact.set(id, price);
    }
  } catch { /* an unreadable override is empty, not fatal */ }
  overrideCache = { stamp, exact, tails };
  return overrideCache;
}

export function pricesUrl(): string {
  return process.env.TERSIO_PRICES_URL || LITELLM_URL;
}

export interface LivePrices {
  fetchedAt: number;
  // Tuples [input, output, cacheRead, cacheWrite] per LiteLLM id — the full feed caches to ~1MB, not multi-MB objects.
  exact: Record<string, [number, number, number, number]>;
  deprecated?: string[];
}

function toPrice(t: [number, number, number, number]): ModelPrice {
  return { input: t[0], output: t[1], cacheRead: t[2], cacheWrite: t[3] };
}

// Tolerate both cache shapes (compact tuples and ModelPrice objects) so a version bump never orphans the cache.
function asPrice(v: unknown): ModelPrice | null {
  if (Array.isArray(v) && v.length === 4 && v.every((n) => typeof n === 'number' && Number.isFinite(n) && n >= 0)) {
    return toPrice(v as [number, number, number, number]);
  }
  if (v && typeof v === 'object') {
    const o = v as Record<string, unknown>;
    if (['input', 'output', 'cacheRead', 'cacheWrite'].every((k) => typeof o[k] === 'number' && Number.isFinite(o[k]) && (o[k] as number) >= 0)) {
      // SAFETY: the line above verified all four keys are finite numbers >= 0, which is the whole of ModelPrice.
      return o as unknown as ModelPrice;
    }
  }
  return null;
}

let liveCache: { token: string | number; prices: LivePrices } | null = null;

export function loadLivePrices(): LivePrices | null {
  // One stamp per call beats a full parse; the token changes on a write, so a refresh is seen at once.
  const token = cacheToken();
  if (liveCache && liveCache.token === token) return liveCache.prices;
  const prices = readLivePrices();
  if (prices) liveCache = { token, prices };
  return prices;
}

function readLivePrices(): LivePrices | null {
  const raw = readCacheText();
  if (raw === null) return null;
  try {
    const parsed = JSON.parse(raw) as { fetchedAt?: unknown; exact?: unknown; deprecated?: unknown };
    if (typeof parsed.fetchedAt !== 'number' || !parsed.exact || typeof parsed.exact !== 'object') return null;
    const exact: Record<string, [number, number, number, number]> = {};
    for (const [k, v] of Object.entries(parsed.exact as Record<string, unknown>)) {
      const p = asPrice(v);
      if (p) exact[k] = [p.input, p.output, p.cacheRead, p.cacheWrite];
    }
    if (!Object.keys(exact).length) return null;
    // Stale entries stay usable; refreshPricesIfStale refreshes in background.
    const deprecated = Array.isArray(parsed.deprecated) ? (parsed.deprecated as unknown[]).filter((d): d is string => typeof d === 'string') : [];
    return { fetchedAt: parsed.fetchedAt, exact, deprecated };
  } catch {
    return null;
  }
}

function num(v: unknown): number | null {
  return typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : null;
}

// Transcripts and the feed spell one model differently; aliases stop a free model reporting the default price.
export const MODEL_ALIASES: ReadonlyArray<{ id: string; feed: string }> = [
  { id: 'space-bunny', feed: 'stealth/space-bunny-alpha' },
];

export function canonicalPriceId(model: string): string {
  const key = model.toLowerCase();
  // Suffix match: gateways prefix the id (opencode/kilo/stealth/space-bunny-alpha).
  return MODEL_ALIASES.find((a) => a.id === key || a.feed === key || key.endsWith(`/${a.id}`) || key.endsWith(`/${a.feed}`))?.id ?? key;
}

export function priceFor(model: string, live?: LivePrices | null): PriceHit {
  const table = live === undefined ? loadLivePrices() : live;
  if (live === undefined) {
    // An operator who edits the override file expects the new price at once, not after a refresh.
    const stamp = overrideStamp();
    if (memoTable !== table || memoStamp !== stamp) {
      memoTable = table;
      memoStamp = stamp;
      memo = new Map();
    }
    const hit = memo.get(model);
    if (hit) return hit;
    const resolved = resolvePrice(model, table, stamp);
    memo.set(model, resolved);
    return resolved;
  }
  return resolvePrice(model, table, overrideStamp());
}

// Recent rows repeat a few models; the memo turns thousands of lookups into one per model. Cleared on table change.
let memoTable: LivePrices | null | undefined;
let memoStamp = 0;
let memo = new Map<string, PriceHit>();

// Validated once per table instead of once per lookup.
let compiledTable: LivePrices | null = null;
let compiledEntries: Array<[string, ModelPrice]> = [];

function priceEntries(table: LivePrices): Array<[string, ModelPrice]> {
  if (compiledTable === table) return compiledEntries;
  const entries: Array<[string, ModelPrice]> = [];
  for (const [k, v] of Object.entries(table.exact)) {
    const price = asPrice(v);
    if (price) entries.push([k, price]);
  }
  compiledTable = table;
  compiledEntries = entries;
  return entries;
}

function resolvePrice(model: string, table: LivePrices | null, stamp = overrideStamp()): PriceHit {
  // The operator's file wins outright: it is the only source that can name what a gateway charges.
  const overrides = loadOverrides(stamp);
  if (overrides) {
    const own = overrides.exact.get(model) ?? overrides.exact.get(model.toLowerCase());
    if (own) return { price: own, known: true, live: false, tier: 'override' };
    const low = model.toLowerCase();
    for (const [suffix, price] of overrides.tails) {
      if (low === suffix || low.endsWith(`/${suffix}`)) {
        return { price, known: true, live: false, tier: 'override' };
      }
    }
  }

  // An alias runs the same chain, so it still resolves when the feed keys it under a provider prefix.
  const alias = MODEL_ALIASES.find((a) => a.id === model.toLowerCase());
  const id = alias?.feed ?? model;
  if (table) {
    const entries = priceEntries(table);
    // The id verbatim, then case-folded; nothing guessed.
    const hit = entries.find(([k]) => k === id) ?? entries.find(([k]) => k === id.toLowerCase());
    if (hit) return { price: hit[1], known: true, live: true, tier: alias ? 'alias' : 'exact' };

    const lower = id.toLowerCase();
    const tail = lower.split('/').pop() ?? lower;
    // Bare name under any provider (need not be the billing one); tier `tail` keeps it out of a firm total.
    const bare = entries.find(([k]) => {
      const lk = k.toLowerCase();
      return lk === tail || lk.endsWith(`/${tail}`);
    });
    if (bare) return { price: bare[1], known: true, live: true, tier: 'tail' };
  }
  return { price: DEFAULT_PRICE, known: false, live: false, tier: 'default' };
}
// Fetch LiteLLM pricing and write the cache. False on any failure — callers fall back silently.
export async function refreshPrices(): Promise<boolean> {
  if (refreshInflight) return refreshInflight;
  refreshInflight = (async () => {
    let res: Response;
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 15000);
      try {
        res = await fetch(pricesUrl(), { signal: ctl.signal });
      } finally {
        clearTimeout(timer);
      }
      if (!res.ok) return false;
    } catch {
      return false;
    }
    let data: Record<string, Record<string, unknown>>;
    try {
      data = (await res.json()) as Record<string, Record<string, unknown>>;
    } catch {
      return false;
    }
    const exact: Record<string, [number, number, number, number]> = {};
    const deprecated: string[] = [];
    for (const [id, row] of Object.entries(data)) {
      if (!row || typeof row !== 'object') continue;
      const input = num(row.input_cost_per_token);
      const output = num(row.output_cost_per_token);
      if (input === null || output === null) continue;
      exact[id] = [
        input * 1e6,
        output * 1e6,
        (num(row.cache_read_input_token_cost) ?? input) * 1e6,
        (num(row.cache_creation_input_token_cost) ?? input) * 1e6,
      ];
      if (typeof row.deprecation_date === 'string' && row.deprecation_date) deprecated.push(id);
    }
    if (!Object.keys(exact).length) return false;
    try {
      return writeCacheText(JSON.stringify({ fetchedAt: Date.now(), exact, deprecated }));
    } catch {
      return false;
    }
  })();
  try {
    return await refreshInflight;
  } finally {
    refreshInflight = null;
  }
}

// Fire-and-forget refresh when the cache is stale; readers keep the stale file, so pricing never blocks.
export function refreshPricesIfStale(): void {
  const live = loadLivePrices();
  if (live && Date.now() - live.fetchedAt <= CACHE_TTL_MS) return;
  void refreshPrices().catch(() => false);
}
