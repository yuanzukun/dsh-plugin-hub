// /headroom session mode: tracks the user's Headroom (headroomlabs-ai) install. Opt-in, so no preset turns it on.

import {
  getSharedComboState,
  hasModeState,
  isOmpSubagentPrompt,
  lastCustomValue,
  normalizeInputCommand,
  normalizeMode,
  reconcileSharedComboEntries,
  sessionEntries,
  setSharedComboListener,
  setSharedComboMode,
  systemPromptIncludes,
} from '../shared/session-state.ts';
import { hostIdOf, injectPromptText, onHostEvent, sessionChangeEvents, setExtensionLabel } from '../shared/host.ts';
import { announceStatus } from '../shared/status.ts';
import { readHeadroomDefault, saveModeState } from '../shared/plugin-settings.ts';
import type { HostScope } from '../shared/plugin-settings.ts';
import { resolveHeadroomBinary } from '../shared/utils.ts';
import { headroomHostSupported, headroomProxyUrl } from '../shared/headroom-proxy.ts';
import { describeHeadroomRoute, readHeadroomRoute } from '../shared/headroom-routing.ts';
import { headroomRoutedHosts, repairHeadroomRoute } from '../shared/headroom-routes.ts';
import { ensureHeadroomRuntime, releaseHeadroomLease, touchHeadroomLease } from '../shared/headroom-runtime.ts';
import { ensureTersioMcp } from '../shared/mcp-config.ts';
import type { HeadroomRoute } from '../shared/headroom-routing.ts';
import type { ExtensionApi, ExtensionCtx, InputEvent, SessionEntry, SystemPromptEvent } from '../shared/types.ts';

const DEFAULT_MODE = 'off';

/** True when this session needs the proxy: the mode compresses traffic, or a route points at it. */
export function needsHeadroomProxy(mode: string, routed: boolean): boolean {
  return mode === 'on' || routed;
}
export const HEADROOM_INSTALL_HINT = 'pip install "headroom-ai[all]"';

// A successful probe holds for longer than a miss, so a turn never pays the timeout twice in a row.
const probeCache: { url: string; at: number; up: boolean } = { url: '', at: 0, up: false };

/**
 * True when anything on this machine expects the proxy: this host's route, any other agent's route,
 * or a headroom default saved for any scope. One proxy serves them all, so any of them counts.
 */
export function headroomWanted(host: string): boolean {
  if (readHeadroomRoute(host).routed || headroomRoutedHosts().length > 0) return true;
  // The shared default plus every scope the settings store names; dsh inherits the shared one.
  const scopes: Array<HostScope | null> = [null, 'omp', 'pi', 'pig', 'opencode'];
  return scopes.some((id) => normalizeMode('headroom', readHeadroomDefault(id)) === 'on');
}

/** True when headroom's proxy answers: with none, no traffic compresses and the block would lie. */
export async function headroomProxyUp(url: string = headroomProxyUrl(), budgetMs = 400): Promise<boolean> {
  const now = Date.now();
  if (probeCache.url === url && now - probeCache.at < (probeCache.up ? 30_000 : 10_000)) return probeCache.up;
  let up = false;
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(budgetMs) });
    await res.body?.cancel();
    up = true;
  } catch {
    /* refused or too slow: the runtime is down */
  }
  probeCache.url = url;
  probeCache.at = now;
  probeCache.up = up;
  return up;
}

// The proxy compresses traffic below the shell layer, so the block only tells the model what changes and how to recover detail.
export function headroomInstruction(route?: HeadroomRoute): string {
  const scope = route?.routed
    ? `Compression applies to ${route.model} via ${route.provider ?? 'its provider'}.`
    : 'Headroom compression is enabled for this session.';
  return `🍃 HEADROOM MODE ACTIVE — level: on\n${scope} Tool outputs, file reads, and history may be compressed before reaching you. A compressed result can elide details; treat its elision markers as real. Recover the original by hash with the tersio_headroom MCP tool ({action:"retrieve", hash:"<HASH>"}). If that tool is not available, re-run the source command or re-read the file.`;
}

function resolveMode(entries: SessionEntry[] | null | undefined, fallback: string = DEFAULT_MODE): string {
  return lastCustomValue(entries, 'headroom-mode', (data) => normalizeMode('headroom', data?.mode)) ?? fallback;
}

// The shared off phrase; every mode honours it, so one word clears the session.
function isOffCommand(text: unknown): boolean {
  return normalizeInputCommand(text) === 'normal mode';
}

export default function headroomSessionExtension(pi: ExtensionApi): void {
  const host = hostIdOf(pi);
  // A host without a known model route would get a promise its traffic never fulfils.
  const supported = headroomHostSupported(host);
  let currentMode = DEFAULT_MODE;
  let lastInjected: string | undefined = undefined;
  let unroutedNotified = false;
  let lastRepairedModel = '';
  function setMode(mode: string, ctx?: ExtensionCtx): boolean {
    if (!supported) return false;
    const normalized = normalizeMode('headroom', mode);
    if (!normalized) return false;
    currentMode = normalized;
    unroutedNotified = false;
    pi.appendEntry?.('headroom-mode', { mode: normalized });
    setSharedComboMode('headroom', normalized);
    saveModeState(host, getSharedComboState());
    // Turning the mode on is the moment the agent needs the retrieve tool; wiring is idempotent.
    if (normalized === 'on') ensureTersioMcp(host);
    announceStatus(ctx);
    return true;
  }

  // One agent process holds one lease. A session that dies without a shutdown stops refreshing it,
  // so the proxy is not held forever by a process that is gone.
  const sessionId = String(process.pid);

  setExtensionLabel(pi, 'Headroom session toggle');

  // Adopt a /tersio or /combo switch at once, so the next turn needs no reload.
  function syncFromShared(state: { headroom: string }): void {
    const mode = normalizeMode('headroom', state.headroom);
    if (mode) currentMode = mode;
  }
  setSharedComboListener('headroom', syncFromShared);

  pi.registerCommand?.('headroom', {
    description: 'Toggle the Headroom token-saver mode for this session',
    handler: async (args, ctx) => {
      const arg = String(args || '')
        .trim()
        .toLowerCase();
      if (!supported && arg !== 'status') {
        ctx?.ui?.notify?.('Headroom has no route for this agent.', 'warning');
        return;
      }
      if (!arg || arg === 'on') {
        setMode('on', ctx);
        // The mode can be on while the tool is absent; never silent about it, never installing on our own.
        if (!resolveHeadroomBinary()) {
          ctx?.ui?.notify?.(
            `Headroom binary not found on PATH. Install it yourself with: ${HEADROOM_INSTALL_HINT}`,
            'warning',
          );
        }
        return;
      }
      if (arg === 'status') {
        announceStatus(ctx);
        return;
      }
      if (!setMode(arg, ctx)) {
        ctx?.ui?.notify?.('Usage: /headroom [on|off|status]', 'warning');
      }
    },
  });

  onHostEvent<InputEvent>(pi, 'input', async (event) => {
    if (event?.source === 'extension') return;
    if (currentMode !== 'off' && isOffCommand(event?.text)) setMode('off');
  });

  function restoreMode(ctx?: ExtensionCtx): void {
    unroutedNotified = false;
    lastRepairedModel = '';
    const entries = sessionEntries(ctx);
    // A subagent's branch has no Tersio entries; reconciling it would wipe shared state.
    if (hasModeState(entries)) reconcileSharedComboEntries(entries);
    // Persisted state wins, then a mode already chosen, then the configured default. `off` is the start value, not unset.
    if (!supported) {
      currentMode = DEFAULT_MODE;
      announceStatus(ctx);
      return;
    }
    const persisted = resolveMode(entries, '');
    const alreadyChosen = currentMode !== DEFAULT_MODE;
    currentMode =
      persisted || (alreadyChosen ? currentMode : normalizeMode('headroom', readHeadroomDefault(host))) || DEFAULT_MODE;
    announceStatus(ctx);
  }

  // A route outlives a reboot; the proxy does not, and a route to a dead port fails the first request.
  // Fire-and-forget: the session starts now, and headroom answers within its own wait window.
  function startRuntime(): void {
    // One proxy serves the machine, so any reason it is wanted counts: this host's mode, this host's
    // route, another agent's route, or a headroom default saved for some host.
    if (!needsHeadroomProxy(currentMode, headroomWanted(host))) return;
    const bin = resolveHeadroomBinary();
    if (!bin) return;
    // The claim is written first, so a stop from another session sees this one and leaves the proxy up.
    touchHeadroomLease(sessionId);
    // ensureHeadroomRuntime probes /readyz first, so a proxy that is already up costs one request.
    void ensureHeadroomRuntime(bin).catch(() => {
      /* the next session retries */
    });
  }

  // Start, resume, and branch all land here, so every session type shows it.
  pi.on('session_start', async (_event, ctx) => {
    restoreMode(ctx);
    startRuntime();
  });

  // The host adapter names the switch events it emits, so this stays free of any one host's naming.
  for (const event of sessionChangeEvents(pi)) {
    onHostEvent(pi, event, async (_event, ctx) => {
      restoreMode(ctx);
    });
  }

  // The proxy is session-scoped: it stops on quit unless another agent still holds it. A reload keeps
  // it, because the same process relaunches and claims it again.
  pi.on('session_shutdown', async (event) => {
    const reason = (event as { reason?: unknown } | undefined)?.reason;
    if (reason === 'reload' || reason === 'new' || reason === 'resume' || reason === 'fork') return;
    await releaseHeadroomLease(sessionId, resolveHeadroomBinary(), { fast: true }).catch(() => {
      /* a stop that fails is retried by the next session */
    });
  });

  pi.on<SystemPromptEvent>('before_agent_start', async (event: SystemPromptEvent, ctx?: ExtensionCtx) => {
    const mode = isOmpSubagentPrompt(event.systemPrompt) ? getSharedComboState().headroom : currentMode;
    if (!mode || mode === 'off') return;
    // Nothing is compressed when the tool is absent, so the block would lie to the model.
    if (!resolveHeadroomBinary()) return;
    // The same rule applies to a binary with no runtime behind it: headroom's proxy is what compresses.
    if (!(await headroomProxyUp())) return;
    // A live proxy is not enough: the configured model must actually point at it.
    let route = readHeadroomRoute(host);
    // When the active model is not routed yet, route it automatically on the fly.
    const repairKey = `${route.provider ?? ''}:${route.model ?? ''}`;
    if (!route.routed && repairKey !== lastRepairedModel) {
      lastRepairedModel = repairKey;
      const repaired = await repairHeadroomRoute(host);
      if (repaired.ok) {
        route = readHeadroomRoute(host);
        ctx?.ui?.notify?.(
          `Headroom: another tool reset this agent's route. ${repaired.detail}. Reopen /model so this session uses it.`,
          'info',
        );
      }
    }
    if (!route.measured || !route.routed) {
      if (!unroutedNotified) {
        unroutedNotified = true;
        ctx?.ui?.notify?.(
          `Headroom is on, but this agent does not route through it. ${describeHeadroomRoute(route)}. Route it with: tersio install --host ${host} --headroom-default on.`,
          'warning',
        );
      }
      return;
    }
    const instruction = headroomInstruction(route);
    // Match the whole instruction, so a re-presented prompt cannot stack it.
    if (systemPromptIncludes(event.systemPrompt, instruction)) return;
    // The previous block is replaced, not stacked on.
    const stale = lastInjected;
    lastInjected = instruction;
    return injectPromptText(pi, event, { text: instruction, staleMarker: stale, sectionTag: 'headroom' });
  });
}
