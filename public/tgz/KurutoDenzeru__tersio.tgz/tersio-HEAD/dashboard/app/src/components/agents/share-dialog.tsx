// The share card: an SVG of the range, rasterized at 1200 wide for a PNG; a text line covers image-less networks.
import { useEffect, useMemo, useRef, useState } from "react"
import { Dialog, DialogContent, DialogTitle } from "@/components/ui/dialog"
import { Icon } from "@/components/icon"
import { useToast } from "@/components/toaster"
import { useAgentData } from "@/lib/data"
import { AGENT_RANGE_LABEL } from "@/lib/data"
import {
  STRIP_MAX_WEEKS,
  BAND_MAX_WEEKS,
  dayFactsOf,
  graphOf,
  graphWeeks,
  monthBandsOf,
  stripOf,
  streaksOf,
} from "@/lib/graph"
import type { ActivityBar, GraphCell, GraphStreaks, MonthBand } from "@/lib/graph"
import type { AgentRange, AgentStats } from "@/lib/data"
import { fmt, fmtElapsed, fmtShort, pct } from "@/lib/format"

/** The figures the card and the share text both read. */
interface Card {
  range: string
  tokens: number
  requests: number
  costUsd: number
  cacheRate: number
  errorRate: number
  /** Which activity picture the window earns: a bar strip, month bands, the calendar, or none. */
  kind: "empty" | "strip" | "bands" | "calendar"
  strip: { unit: string; bars: ActivityBar[] }
  graph: GraphCell[]
  weeks: number
  bands: MonthBand[]
  streaks: GraphStreaks
  /** The longest single request in the range; null when none carries a duration. */
  maxDurationMs: number | null
}

function cardOf(agent: AgentStats): Card {
  const facts = dayFactsOf(agent)
  const graph = graphOf(agent)
  const weeks = graphWeeks(graph)
  const bands = monthBandsOf(facts, facts.peakTokens)
  const strip = stripOf(agent)
  // A window that holds no activity at all draws the empty state rather than a picture of it.
  const quiet = bands.every((band) => band.cells.every((cell) => cell.tokens <= 0))
  return {
    range: AGENT_RANGE_LABEL[agent.range],
    tokens: agent.overall.total,
    requests: agent.overall.requests,
    costUsd: agent.overall.costUsd,
    cacheRate: agent.overall.cacheRate,
    errorRate: agent.overall.errorRate,
    // All time always earns the calendar: the whole year, the way a contribution log reads.
    kind: quiet
      ? "empty"
      : agent.cutoff === 0
        ? "calendar"
        : weeks <= STRIP_MAX_WEEKS && strip.bars.length > 0
          ? "strip"
          : weeks <= BAND_MAX_WEEKS && bands.length > 0
            ? "bands"
            : "calendar",
    strip,
    graph,
    weeks,
    bands,
    streaks: streaksOf(facts),
    maxDurationMs: agent.overall.maxDurationMs,
  }
}

/** The card, rasterized for a PNG and inlined for the preview. Width is fixed; height follows the layout. */
const CARD_W = 1200
const CARD_H = 850
/** The calendar's grid is bound by its 53-week width, so its card is shorter and the figures sit nearer it. */
const CALENDAR_H = 780
const cardHeight = (card: Card): number => (card.kind === "calendar" ? CALENDAR_H : CARD_H)
function cardSvg(card: Card, money: (v: number) => string, brand: string | null): string {
  const e = (x: string): string => x.replace(/&/g, "&amp;").replace(/</g, "&lt;")
  const svgHeight = cardHeight(card)
  const statsY = card.kind === "calendar" ? 588 : 664
  // The bolt is a watermark pinned near the bottom edge; it rides the shorter card.
  const bolt = card.kind === "calendar" ? ` transform="translate(0 ${svgHeight - 860})"` : ""
  // Canvas reads live tokens off <html> since it cannot resolve var().
  const computed = getComputedStyle(document.documentElement)
  const token = (name: string, fallback: string): string =>
    computed.getPropertyValue(name).trim() || fallback
  const bg = token("--bg", "#09090b")
  const ink = token("--ink", "#f4f4f5")
  const dim = token("--dim", "#a1a1aa")
  const accent = token("--accent", "#34d399")
  const left = 64
  const boxRight = 1136
  const gridLeft = left + 44
  const emptyInk = token("--cell-0", "rgba(24,24,27,.07)")
  const levelInk = [emptyInk, ...[1, 2, 3, 4].map((level) => token(`--cell-${level}`, accent))]
  const s = card.streaks
  const figure = (x: number, y: number, label: string, value: string): string =>
    `<text x="${x}" y="${y}" font-family="monospace" font-size="20" letter-spacing="3" fill="${dim}">${e(label)}</text>` +
    `<text x="${x}" y="${y + 44}" font-family="monospace" font-size="38" font-weight="bold" fill="${ink}">${e(value)}</text>`

  let graph = ""
  let months = ""
  let legend = ""
  let note = ""
  const empty = (): string =>
    `<text x="${left}" y="430" font-family="monospace" font-size="22" letter-spacing="2" fill="${dim}">${e("no activity in this range")}</text>`

  if (card.kind === "empty") {
    return (
      `<svg xmlns="http://www.w3.org/2000/svg" width="${CARD_W}" height="${svgHeight}" viewBox="0 0 ${CARD_W} ${svgHeight}">` +
      `<rect width="${CARD_W}" height="${svgHeight}" rx="28" fill="${bg}"/>` +
      `<path d="M1090 700 L980 800 h70 l-8 60 80 -96 h-70 l8 -64 z" fill="none" stroke="${accent}" stroke-width="14" opacity="0.08" stroke-linejoin="round"/>` +
      `<text x="64" y="80" font-family="monospace" font-size="26" letter-spacing="6" fill="${accent}">${e(`TERSIO · ${card.range.toUpperCase()}`)}</text>` +
      empty() +
      "</svg>"
    )
  } else if (card.kind === "strip") {
    // One bar per slot, height against the busiest slot, and a faint stub where a slot is quiet.
    const { bars } = card.strip
    const box = boxRight - left
    const slot = box / bars.length
    const width = Math.max(3, Math.floor(slot) - 2)
    const radius = Math.min(3, Math.round(width / 4))
    const top = 372
    const baseY = top + 170
    const peak = Math.max(...bars.map((bar) => bar.tokens), 0)
    for (const [i, bar] of bars.entries()) {
      const x = left + Math.round(i * slot + (slot - width) / 2)
      const height =
        bar.tokens <= 0 || peak <= 0 ? 2 : Math.max(3, Math.round((bar.tokens / peak) * 170))
      graph += `<g><title>${e(bar.label)}: ${fmtShort(bar.tokens)} tokens</title><rect x="${x}" y="${baseY - height}" width="${width}" height="${height}" rx="${radius}" fill="${bar.tokens > 0 ? levelInk[4] : emptyInk}"/></g>`
    }
    // The two ends name the window, since a strip has no axis of its own.
    const first = bars[0]!
    const last = bars[bars.length - 1]!
    const dayFormat = { month: "short", day: "numeric", timeZone: "UTC" } as const
    const startText =
      card.strip.unit === "day"
        ? new Date(first.ts).toLocaleDateString("en-US", dayFormat)
        : new Date(first.ts).toISOString().slice(11, 16)
    const endText =
      card.strip.unit === "day"
        ? new Date(last.ts).toLocaleDateString("en-US", dayFormat)
        : new Date(last.ts).toISOString().slice(11, 16)
    months =
      `<text x="${left}" y="${baseY + 34}" font-family="monospace" font-size="18" letter-spacing="1" fill="${dim}">${e(startText)}</text>` +
      `<text x="${boxRight}" y="${baseY + 34}" text-anchor="end" font-family="monospace" font-size="18" letter-spacing="1" fill="${dim}">${e(endText)}</text>`
    note = `activity per ${card.strip.unit}`
  } else if (card.kind === "bands") {
    // One row per calendar month, current month last, so a three-month window reads as three even rows.
    const maxCells = Math.max(...card.bands.map((band) => band.cells.length), 1)
    const gap = 3
    const labelW = 92
    const bandLeft = left + labelW
    const cell = Math.max(8, Math.floor((boxRight - bandLeft - (maxCells - 1) * gap) / maxCells))
    const rowGap = 34
    const top = 366
    for (const [i, band] of card.bands.entries()) {
      const y = top + i * (cell + rowGap)
      // The row label, with its year under it, so the eye follows the row's start.
      months +=
        `<text x="${left}" y="${y + Math.round(cell * 0.82)}" font-family="monospace" font-size="20" font-weight="bold" letter-spacing="2" fill="${ink}">${e(band.label.toUpperCase())}</text>` +
        `<text x="${left}" y="${y + cell + 15}" font-family="monospace" font-size="13" letter-spacing="1" fill="${dim}">${e(String(band.year))}</text>`
      for (const [d, c] of band.cells.entries()) {
        const x = bandLeft + d * (cell + gap)
        // A day before the window opened still draws a lighter box, so the row keeps its length and the edge stays visible.
        const fill = c.level > 0 ? levelInk[c.level] : emptyInk
        const opacity = c.inWindow ? 1 : 0.3
        graph += `<g><title>${e(band.title)} ${new Date(c.ts).getUTCDate()}: ${fmtShort(c.tokens)} tokens${c.inWindow ? "" : " (outside the range)"}</title><rect x="${x}" y="${y}" width="${cell}" height="${cell}" rx="${Math.min(4, Math.round(cell / 5))}" fill="${fill}" opacity="${opacity}"/></g>`
      }
    }
    // The legend sits at the bottom right of the graph region, as GitHub's own does.
    const legendY = top + card.bands.length * (cell + rowGap) + 4
    const lessW = 46
    const swatchW = 5 * (cell + gap)
    const moreW = 50
    const legendLeft = boxRight - lessW - swatchW - moreW
    const swatches = levelInk
      .map(
        (fill, level) =>
          `<rect x="${legendLeft + lessW + level * (cell + gap)}" y="${legendY - cell}" width="${cell}" height="${cell}" rx="${Math.min(4, Math.round(cell / 5))}" fill="${fill}"/>`,
      )
      .join("")
    legend =
      `<text x="${legendLeft}" y="${legendY}" font-family="monospace" font-size="16" letter-spacing="1" fill="${dim}">${e("less")}</text>` +
      swatches +
      `<text x="${legendLeft + lessW + swatchW + 8}" y="${legendY}" font-family="monospace" font-size="16" letter-spacing="1" fill="${dim}">${e("more")}</text>`
    note = `${s.activeDays} active days across ${card.bands.length} months`
  } else if (card.kind === "calendar") {
    // GitHub proportions: rounded squares on a three-pixel gap, one column per week, Mon/Wed/Fri left, months above.
    const top = 366
    const gap = 3
    const box = boxRight - gridLeft
    const colWidth = Math.max(10, Math.min(22, Math.floor(box / Math.max(1, card.weeks))))
    const cell = colWidth - gap
    const radius = Math.min(3, Math.round(cell / 5))
    // A short window keeps its cell size and centers, so the board never sits in one corner.
    const startLeft = gridLeft + Math.round((box - card.weeks * colWidth) / 2)
    const weekText = ["Mon", "Wed", "Fri"]
    for (const [i, row] of [1, 3, 5].entries()) {
      const y = top + row * (cell + gap) + Math.round(cell * 0.82)
      months += `<text x="${left}" y="${y}" font-family="monospace" font-size="15" letter-spacing="1" fill="${dim}">${e(weekText[i]!)}</text>`
    }
    // Month labels sit above the column opening the month; one touching the previous drops, so the row never collides.
    // Column zero is the Sunday before the window, so it usually carries the previous month's name in its first days.
    // Labelling it would print that month twice, so only a month that starts inside the grid earns a label.
    const seenMonths = new Set<string>()
    let lastLabelX = -Infinity
    for (const c of card.graph) {
      const x = startLeft + c.week * colWidth
      const y = top + c.day * (cell + gap)
      const fill = levelInk[c.level] ?? levelInk[0]!
      const at = new Date(c.ts)
      graph += `<g><title>${e(at.toISOString().slice(0, 10))}: ${fmtShort(c.tokens)} tokens</title><rect x="${x}" y="${y}" width="${cell}" height="${cell}" rx="${radius}" fill="${fill}"/></g>`
      // The first week only earns a label when the month itself opens there; a column that merely catches
      // the tail of an earlier month would print that month twice.
      if (c.day === 0 && at.getUTCDate() <= 7 && !seenMonths.has(c.month) && x - lastLabelX >= 48) {
        seenMonths.add(c.month)
        lastLabelX = x
        months += `<text x="${x}" y="${top - 10}" font-family="monospace" font-size="17" letter-spacing="1" fill="${dim}">${e(at.toLocaleDateString("en-US", { month: "short", timeZone: "UTC" }))}</text>`
      }
    }
    const legendY = top + 7 * colWidth + 18
    const lessW = 46
    const swatchW = 5 * (cell + gap)
    const moreW = 50
    const legendLeft = boxRight - lessW - swatchW - moreW
    const swatches = levelInk
      .map(
        (fill, level) =>
          `<rect x="${legendLeft + lessW + level * (cell + gap)}" y="${legendY - cell}" width="${cell}" height="${cell}" rx="${radius}" fill="${fill}"/>`,
      )
      .join("")
    legend =
      `<text x="${legendLeft}" y="${legendY}" font-family="monospace" font-size="16" letter-spacing="1" fill="${dim}">${e("less")}</text>` +
      swatches +
      `<text x="${legendLeft + lessW + swatchW + 8}" y="${legendY}" font-family="monospace" font-size="16" letter-spacing="1" fill="${dim}">${e("more")}</text>`
    note = `${card.weeks} ${card.weeks === 1 ? "week" : "weeks"} of activity`
  }

  // Brand mark, rounded via clip path since `rx` is not an `<image>` attribute; a refused data URL still shows it.
  const avatar =
    brand === null
      ? ""
      : `<defs><clipPath id="tersio-brand"><rect x="1040" y="40" width="96" height="96" rx="22"/></clipPath></defs>` +
        `<image href="${brand}" x="1040" y="40" width="96" height="96" preserveAspectRatio="xMidYMid slice" clip-path="url(#tersio-brand)"/>`

  return (
    `<svg xmlns="http://www.w3.org/2000/svg" width="${CARD_W}" height="${svgHeight}" viewBox="0 0 ${CARD_W} ${svgHeight}">` +
    `<rect width="${CARD_W}" height="${svgHeight}" rx="28" fill="${bg}"/>` +
    `<g${bolt}><path d="M1090 700 L980 800 h70 l-8 60 80 -96 h-70 l8 -64 z" fill="none" stroke="${accent}" stroke-width="14" opacity="0.08" stroke-linejoin="round"/></g>` +
    `<text x="64" y="80" font-family="monospace" font-size="26" letter-spacing="6" fill="${accent}">${e(`TERSIO · ${card.range.toUpperCase()}`)}</text>` +
    `<text x="60" y="230" font-family="monospace" font-size="130" font-weight="bold" fill="${ink}">${e(`${fmtShort(card.tokens)} tokens`)}</text>` +
    `<text x="64" y="278" font-family="monospace" font-size="30" fill="${dim}">${e(`across ${fmt(card.requests)} agent requests`)}</text>` +
    (note
      ? `<text x="${boxRight}" y="330" text-anchor="end" font-family="monospace" font-size="20" letter-spacing="2" fill="${dim}">${e(note)}</text>`
      : "") +
    avatar +
    months +
    graph +
    legend +
    figure(64, statsY, "API-EQUIVALENT", money(card.costUsd)) +
    figure(448, statsY, "CACHE RATE", pct(card.cacheRate)) +
    figure(832, statsY, "ERROR RATE", pct(card.errorRate)) +
    figure(64, statsY + 90, "PEAK DAY", fmtShort(s.peakTokens)) +
    figure(320, statsY + 90, "LONGEST TASK", fmtElapsed(card.maxDurationMs)) +
    figure(576, statsY + 90, "LONGEST STREAK", `${s.longest.days}d`) +
    figure(832, statsY + 90, "CURRENT STREAK", `${s.current.days}d`) +
    "</svg>"
  )
}

function shareText(card: Card, money: (v: number) => string): string {
  return (
    `${fmtShort(card.tokens)} tokens / ${fmt(card.requests)} requests / ${pct(card.cacheRate)} cached. ` +
    `Estimated ${money(card.costUsd)} at public rates over ${card.range}. My AI usage, tracked with Tersio.`
  )
}

export function ShareDialog({
  open,
  onClose,
  range,
  money,
}: {
  open: boolean
  onClose: () => void
  range: AgentRange
  money: (v: number) => string
}) {
  const toast = useToast()
  const { agent } = useAgentData(range, "overview")
  const [busy, setBusy] = useState(false)
  // The brand mark, read once as a data URL so the card and its PNG stay self-contained.
  const [brand, setBrand] = useState<string | null>(null)
  const svgRef = useRef<HTMLDivElement | null>(null)
  // Memoised so the raster effect runs once per range, not once per render.
  const card = useMemo(() => (agent ? cardOf(agent) : null), [agent])
  const text = card ? shareText(card, money) : ""

  useEffect(() => {
    let live = true
    // A missing or blocked mark leaves the card without it; every other figure still draws.
    fetch("brand.webp")
      .then((res) => (res.ok ? res.blob() : null))
      .then((blob) => {
        if (!live || blob === null) return
        const reader = new FileReader()
        // addEventListener rather than onload: assigning replaces any handler already set.
        reader.addEventListener("load", () => {
          if (live && typeof reader.result === "string") setBrand(reader.result)
        })
        reader.readAsDataURL(blob)
      })
      .catch(() => undefined)
    return () => {
      live = false
    }
  }, [])

  // Rasterize once per open, so both copy and download read the same bytes.
  useEffect(() => {
    if (!open || !card) return undefined
    let live = true
    const img = new Image()
    const url = URL.createObjectURL(
      new Blob([cardSvg(card, money, brand)], { type: "image/svg+xml;charset=utf-8" }),
    )
    img.onload = () => {
      if (!live) return
      const canvas = document.createElement("canvas")
      canvas.width = CARD_W
      canvas.height = cardHeight(card)
      const context = canvas.getContext("2d")
      if (!context) return
      context.drawImage(img, 0, 0, CARD_W, cardHeight(card))
      if (svgRef.current) {
        // The same SVG the PNG rasterizes, scaled by the wrapper's aspect ratio.
        svgRef.current.innerHTML = cardSvg(card, money, brand)
      }
    }
    img.onerror = () => undefined
    img.src = url
    return () => {
      live = false
      URL.revokeObjectURL(url)
    }
  }, [open, card, money, brand])

  /** Renders the card to PNG bytes. Both copy and download read these bytes. */
  const raster = (): Promise<Blob | null> => {
    if (!card) return Promise.resolve(null)
    const { promise, resolve } = Promise.withResolvers<Blob | null>()
    const img = new Image()
    const url = URL.createObjectURL(
      new Blob([cardSvg(card, money, brand)], { type: "image/svg+xml;charset=utf-8" }),
    )
    const done = (blob: Blob | null): void => {
      URL.revokeObjectURL(url)
      resolve(blob)
    }
    img.onload = () => {
      const height = cardHeight(card)
      const canvas = document.createElement("canvas")
      canvas.width = CARD_W
      canvas.height = height
      const context = canvas.getContext("2d")
      if (!context) {
        done(null)
        return
      }
      context.drawImage(img, 0, 0, CARD_W, height)
      canvas.toBlob(done, "image/png")
    }
    img.onerror = () => done(null)
    img.src = url
    return promise
  }

  const downloadPng = async (): Promise<void> => {
    if (!card) return
    setBusy(true)
    const blob = await raster()
    setBusy(false)
    if (!blob) {
      toast("Save failed", "Browser blocked the render.", "circle-exclamation-point")
      return
    }
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = "tersio-usage.png"
    link.click()
    setTimeout(() => URL.revokeObjectURL(link.href), 5000)
    toast("Saved", "Card downloaded as PNG.", "download")
  }

  /**
   * Hands the card to the operating system's own share sheet, which is the only channel that carries file bytes
   * to another app. The sheet lists whatever the machine has installed, so one button covers every network
   * without Tersio naming any of them. The PNG travels as a real `File`, so the target receives an attachment.
   *
   * A platform without file sharing falls back to the clipboard: the picture is copied and a note says to paste.
   */
  const shareCard = async (): Promise<void> => {
    if (!card) return
    setBusy(true)
    const blob = await raster()
    setBusy(false)
    if (!blob) {
      toast("Share failed", "Browser blocked the render.", "circle-exclamation-point")
      return
    }

    if (typeof navigator.canShare === "function") {
      const file = new File([blob], "tersio-usage.png", { type: "image/png" })
      if (navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({ files: [file], text })
          return
        } catch (error) {
          // A cancelled sheet is the user's choice, not a failure.
          if ((error as Error)?.name === "AbortError") return
        }
      }
    }

    try {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })])
      toast("Image copied", "This system has no share sheet here; paste the image where you need it.", "image")
      return
    } catch {
      /* no image clipboard either: the file itself is still available below */
    }
    toast("Paste the image", "Copy it from the button below, then paste it where you need it.", "image")
  }

  // The clipboard gets the picture; a browser without image clipboard still gets the file, pasting into most hosts.
  const copyImage = async (): Promise<void> => {
    if (!card) return
    setBusy(true)
    const blob = await raster()
    setBusy(false)
    if (!blob) {
      toast("Copy failed", "Browser blocked the render.", "circle-exclamation-point")
      return
    }
    try {
      await navigator.clipboard.write([new ClipboardItem({ "image/png": blob })])
      toast("Copied", "Card copied as an image.", "image")
      return
    } catch {
      await downloadPng()
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        if (!next) onClose()
      }}
    >
      <DialogContent
        className="gap-0 overflow-hidden rounded-2xl border border-line bg-panel p-5 text-ink shadow-[0_16px_48px_rgba(0,0,0,.35)] sm:max-w-[660px]"
        showCloseButton={false}
        aria-describedby={undefined}
      >
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <DialogTitle className="m-0 flex items-center gap-2 text-base font-bold tracking-[-0.01em]">
              <Icon name="share-2" className="size-4 shrink-0 text-dim" />
              Share usage
            </DialogTitle>
            <p className="mono mt-1 text-xs text-dim">
              {card
                ? `${card.range} across ${fmt(card.requests)} requests`
                : "Reading the agent databases…"}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="grid size-8 shrink-0 place-items-center rounded-lg border border-line text-dim hover:text-ink [transition:transform_.12s,background_.2s] hover:bg-accent-soft active:scale-[.96]"
          >
            <Icon name="x" className="size-4" />
          </button>
        </div>

        <div
          ref={svgRef}
          aria-hidden="true"
          style={{
            aspectRatio: card ? `${CARD_W} / ${cardHeight(card)}` : `${CARD_W} / ${CARD_H}`,
          }}
          className="mt-4 w-full overflow-hidden rounded-xl border border-line bg-panel [&_svg]:block [&_svg]:h-full [&_svg]:w-full"
        />

        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={busy || !card}
            onClick={() => void shareCard()}
            className="inline-flex cursor-pointer items-center gap-1.5 rounded-[10px] border border-line bg-transparent px-3 py-[7px] text-xs text-ink hover:border-accent [transition:transform_.12s,background_.2s] hover:bg-accent-soft active:scale-[.96] disabled:opacity-50"
          >
            <Icon name="share-2" className="size-3.5 shrink-0" />
            <span>Share</span>
          </button>
          <span className="ml-auto flex items-center gap-2">
            <button
              type="button"
              disabled={busy || !card}
              onClick={() => void copyImage()}
              className="inline-flex cursor-pointer items-center gap-1.5 rounded-[10px] border border-line bg-transparent px-3 py-[7px] text-xs text-ink hover:border-accent [transition:transform_.12s,background_.2s] hover:bg-accent-soft active:scale-[.96] disabled:opacity-50"
            >
              <Icon name="image" className="size-3.5" />
              <span>Copy image</span>
            </button>
            <button
              type="button"
              disabled={busy || !card}
              onClick={downloadPng}
              className="inline-flex cursor-pointer items-center gap-1.5 rounded-[10px] border border-accent bg-accent-soft px-3 py-[7px] text-xs font-semibold text-accent hover:brightness-110 disabled:opacity-50 [transition:transform_.12s,background_.2s] active:scale-[.96]"
            >
              <Icon name="download" className="size-3.5" />
              <span>{busy ? "Rendering…" : "Download PNG"}</span>
            </button>
          </span>
        </div>
      </DialogContent>
    </Dialog>
  )
}
