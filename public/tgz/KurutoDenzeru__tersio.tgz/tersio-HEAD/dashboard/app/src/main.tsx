import { StrictMode } from "react"
import { createRoot } from "react-dom/client"

import "./index.css"
import "./textures.css"
import App from "./App.tsx"
import { ThemeProvider } from "@/components/theme-provider.tsx"

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <ThemeProvider storageKey="tersio-theme">
      <App />
    </ThemeProvider>
  </StrictMode>
)
