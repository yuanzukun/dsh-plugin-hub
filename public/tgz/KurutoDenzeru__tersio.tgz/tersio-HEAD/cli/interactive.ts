// cli/interactive.ts — TTY layer: readline, Clack spinners, selects, task phases.
import readline from 'node:readline';
import {
  cancel as clackCancel,
  confirm as clackConfirm,
  log as clackLog,
  select as clackSelect,
  spinner as clackSpinner,
  tasks as clackTasks,
} from '@clack/prompts';
import type { SpinnerResult } from '@clack/prompts';
import { execP } from './common.ts';
import type { ExecOptions } from './common.ts';

// Opened on first use, never at import: the entry hands the run to bun, and a reader here would eat the child's stdin.
let RL: readline.Interface | null = null;
let rlOpen = true;
function ask(q: string): Promise<string> {
  return new Promise<string>((resolve) => {
    if (!rlOpen) {
      resolve('');
      return;
    }
    try {
      (RL ??= readline.createInterface({ input: process.stdin, output: process.stdout })).question(q, resolve);
    } catch {
      resolve('');
    }
  });
}
function closeRL(): void {
  if (rlOpen) {
    RL?.close();
    RL = null;
    rlOpen = false;
  }
}

function tty(): boolean {
  return Boolean(process.stdin.isTTY && process.stdout.isTTY);
}

type InteractiveChoice = { status: 'selected'; value: string } | { status: 'cancelled' | 'unavailable' };

type InteractiveConfirm = { status: 'confirmed'; value: boolean } | { status: 'cancelled' | 'unavailable' };

let spinnerDepth = 0;

// Clack's spinner stop writes an extra newline under CI, shifting later output by a row.
async function withInteractiveSpinner<T>(
  message: string,
  work: (update: (message: string) => void) => Promise<T>,
): Promise<T> {
  if (!tty() || spinnerDepth > 0 || process.env.CI === 'true') return work(() => {});
  // Clack manages stdin itself. Close the legacy question interface first; non-interactive callers skip it.
  closeRL();
  const active: SpinnerResult = clackSpinner({ indicator: 'timer' });
  active.start(message);
  spinnerDepth += 1;
  try {
    return await work((next: string) => {
      active.message(next);
    });
  } finally {
    active.clear();
    spinnerDepth -= 1;
  }
}

async function askInteractiveChoice(
  message: string,
  options: Array<{ value: string; label: string; hint?: string; disabled?: boolean }>,
  initialValue: string,
): Promise<InteractiveChoice> {
  if (!tty()) return { status: 'unavailable' };
  closeRL();
  try {
    const choice = await clackSelect({ message, options, initialValue });
    if (typeof choice !== 'string') {
      clackCancel('Aborted.');
      return { status: 'cancelled' };
    }
    return { status: 'selected', value: choice };
  } finally {
  }
}
async function askInteractiveConfirm(message: string, initialValue = true): Promise<InteractiveConfirm> {
  if (!tty()) return { status: 'unavailable' };
  closeRL();
  try {
    const answer = await clackConfirm({ message, initialValue });
    if (typeof answer !== 'boolean') {
      clackCancel('Aborted.');
      return { status: 'cancelled' };
    }
    return { status: 'confirmed', value: answer };
  } finally {
  }
}
// Confirm a destructive run: a Clack dialog at a terminal, a plain prompt in a pipe. False means declined or aborted.
async function confirmDestructive(message: string): Promise<boolean> {
  if (tty()) {
    closeRL();
    const answer = await clackConfirm({ message, initialValue: false });
    if (typeof answer !== 'boolean') {
      clackCancel('Aborted.');
      closeRL();
      return false;
    }
    if (!answer) {
      console.log('Aborted.');
      closeRL();
      return false;
    }
    return true;
  }
  const typed = await ask('\nProceed? [y/N]: ');
  if (!typed.toLowerCase().startsWith('y')) {
    console.log('Aborted.');
    closeRL();
    return false;
  }
  return true;
}

// Run collecting work under one TTY-only Clack task; callers print after it, so output stays out of the spinner.
async function runInteractivePhase<T>(title: string, collect: () => Promise<T>): Promise<T> {
  if (!tty()) return collect();
  closeRL();
  let result!: T;
  try {
    await clackTasks([
      {
        title,
        task: async () => {
          result = await collect();
        },
      },
    ]);
  } finally {
  }
  return result;
}
// Tagged lines log on TTY but stay byte-identical when piped.
type SayKind = 'info' | 'success' | 'warn' | 'error' | 'step' | 'message';
const TAG_KIND: Record<string, SayKind> = {
  fail: 'error',
  warn: 'warn',
  hint: 'info',
  ok: 'success',
  note: 'message',
  write: 'step',
  rm: 'step',
  migrate: 'step',
  skip: 'info',
  'dry-run': 'info',
};
function sayTagged(line: string): void {
  const m = /^\s*\[([\w-]+)\]\s?([\s\S]*)$/.exec(line);
  const kind: SayKind = (m && TAG_KIND[m[1]]) || 'info';
  if (tty() && m) clackLog[kind](m[2]);
  else console.log(line);
}
// One live-updating task line instead of a spinner per step.
async function withInteractiveTask<T>(
  title: string,
  work: (update: (message: string) => void) => Promise<T>,
): Promise<T> {
  if (!tty()) return work(() => {});
  closeRL();
  let result!: T;
  const spin = clackSpinner();
  spin.start(title);
  try {
    result = await work((message) => spin.message(message));
    spin.stop('done');
  } catch (e) {
    spin.error(shortSpinnerError(e));
    throw e;
  } finally {
  }
  return result;
}
function shortSpinnerError(e: unknown): string {
  const msg = e instanceof Error ? e.message : String(e);
  return (msg.split('\n')[0] || 'failed').slice(0, 120);
}
async function execNetwork(
  label: string,
  cmd: string,
  args: string[],
  opts: ExecOptions = {},
): Promise<{ stdout: string; stderr: string }> {
  return withInteractiveSpinner(label, () => execP(cmd, args, opts));
}

export {
  ask,
  closeRL,
  tty,
  withInteractiveSpinner,
  withInteractiveTask,
  execNetwork,
  sayTagged,
  askInteractiveChoice,
  askInteractiveConfirm,
  confirmDestructive,
  runInteractivePhase,
};
export type { SayKind, InteractiveChoice, InteractiveConfirm };
