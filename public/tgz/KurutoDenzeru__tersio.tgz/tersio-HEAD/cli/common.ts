// cli/common.ts — shared foundation: CLI flags, paths, exec, file/config helpers.
import { execFile } from 'node:child_process';
import { existsSync, promises as fs } from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { findPackageRoot, readTextIfExists } from '../extensions/shared/utils.ts';
import { parseCurrencyFlag, readStoredCurrency } from './currency.ts';
import { recordActivity, shortPath } from './activity.ts';
import type { CurrencyCode } from './currency.ts';

const IS_WINDOWS = process.platform === 'win32';
const RTK_BINARY_NAME = IS_WINDOWS ? 'rtk.exe' : 'rtk';
const HOME = process.env.HOME || process.env.USERPROFILE || '';
const OMP_AGENT_DIR = path.join(HOME, '.omp', 'agent');
const OMP_PLUGINS_DIR = path.join(HOME, '.omp', 'plugins');
const BUN_BIN_DIR = path.join(HOME, '.bun', 'bin');
const OMP_BIN = IS_WINDOWS ? 'omp.cmd' : 'omp';
// npm and bun are `.cmd` shims on Windows, and CreateProcess spawns neither a bare name nor a shim, so the spawn name itself carries the extension the way `omp.cmd` does.
const NPM_BIN = IS_WINDOWS ? 'npm.cmd' : 'npm';
const BUN_BIN = IS_WINDOWS ? 'bun.cmd' : 'bun';

const PACKAGE_NAME = '@krtclcdy/tersio';
const PACKAGE_BIN = 'tersio';
const { version: PACKAGE_VERSION } = createRequire(import.meta.url)(
  path.join(findPackageRoot(path.dirname(fileURLToPath(import.meta.url))), 'package.json'),
) as { version: string };

interface InstallOptions {
  dryRun: boolean;
  verbose: boolean;
  yes: boolean;
  reinstall: boolean;
  quiet?: boolean;
}

interface PluginsPackage {
  name?: string;
  private?: boolean;
  dependencies?: Record<string, string>;
  [key: string]: unknown;
}

const CAVEMAN_DEFAULTS = new Set(['off', 'lite', 'full', 'ultra', 'megacave-lite', 'megacave-full', 'megacave-ultra']);
// The dashboard's accent picker; the ids match lib/accent.ts, and a new port cannot keep them.
const ACCENT_DEFAULTS = new Set(['emerald', 'violet', 'slate', 'cyan', 'rose', 'amber', 'orange']);
const PONYTAIL_DEFAULTS = new Set(['off', 'lite', 'full', 'ultra']);
const PSTACK_DEFAULTS = new Set(['off', 'on']);
const HEADROOM_DEFAULTS = new Set(['off', 'on']);
const RTK_DEFAULTS = new Set(['on', 'off']);

// Mirrors COMBO_LEVELS in extensions/shared/session-state.ts: a preset owns three modes, and pstack stays opt-in.
const COMBO_PRESET_MODES: Record<string, { caveman: string; rtk: boolean; ponytail: string }> = {
  off: { caveman: 'off', rtk: false, ponytail: 'off' },
  lite: { caveman: 'lite', rtk: true, ponytail: 'lite' },
  balanced: { caveman: 'full', rtk: true, ponytail: 'full' },
  max: { caveman: 'ultra', rtk: true, ponytail: 'ultra' },
};
const COMBO_DEFAULTS = new Set(Object.keys(COMBO_PRESET_MODES));
// The retired name for the lite preset, so a scripted `--combo-default medium` keeps working.
const COMBO_RETIRED = new Set(['medium']);

function parseEnum(value: string | undefined, valid: Set<string>, flag: string): string | undefined {
  if (value === undefined) return undefined;
  const v = value.trim().toLowerCase();
  if (!valid.has(v)) {
    console.error(`[fail] Invalid ${flag}: ${value}. Valid: ${[...valid].join(', ')}`);
    process.exit(1);
  }
  return v;
}

function flagValue(name: string): string | undefined {
  const i = args.indexOf(name);
  if (i !== -1) return args[i + 1];
  const prefix = `${name}=`;
  return args.find((arg) => arg.startsWith(prefix))?.slice(prefix.length);
}

const COMMANDS: Record<string, true> = {
  install: true,
  update: true,
  doctor: true,
  uninstall: true,
  dashboard: true,
  upstream: true,
  mcp: true,
  modes: true,
  'codex-hook': true,
  version: true,
  help: true,
};
/** Flags whose next token is a value, so `--host omp` never reads `omp` as the command. */
const VALUE_FLAGS = new Set([
  '--host',
  '--bind',
  '--port',
  '--export',
  '--currency',
  '--scope',
  '--write',
  '--combo-default',
  '--caveman-default',
  '--ponytail-default',
  '--pstack-default',
  '--headroom-default',
  '--rtk-default',
]);
const args = process.argv.slice(2);
const commandArg = args.find((arg, i) => !arg.startsWith('-') && !VALUE_FLAGS.has(args[i - 1]));
const command = commandArg?.toLowerCase() || null;
const unknownCommand = command !== null && !COMMANDS[command];
const install = command === 'install';
const update = command === 'update';
const showVersion = command === 'version' || args.includes('--version') || args.includes('-v');
const showHelp = command === 'help' || args.includes('--help') || args.includes('-h');
const applyUpdate = args.includes('--apply-update');
const dryRun = args.includes('--dry-run');
const assumeYes = args.includes('--yes') || args.includes('-y');
// `yes` also quiets the commands that never prompt on their own; `assumeYes` is the operator saying so.
const yes = assumeYes || install || update || applyUpdate;
const verbose = args.includes('--verbose');
// Off by default: an unverified RTK binary runs with the user's privileges.
const doctor = command === 'doctor' || args.includes('--doctor');
const fix = args.includes('--fix') || args.some((a) => a.startsWith('--fix='));
const dashboard = command === 'dashboard';
const mcp = command === 'mcp';
const modes = command === 'modes';
const codexHook = command === 'codex-hook';
const upstream = command === 'upstream' || args.includes('--upstream');
const dashboardPort = Number.parseInt(flagValue('--port') ?? '', 10) || 0;
// The dashboard listens on loopback unless asked otherwise: `--lan`, `--bind <addr>`, or `--host lan`. `--host` names an agent for install, so only a value that is not an agent id reads as an address.
const hostArg = flagValue('--host');
const dashboardBind = args.includes('--local')
  ? '127.0.0.1'
  : args.includes('--lan')
    ? 'lan'
    : (flagValue('--bind') ??
      (hostArg && !['omp', 'pi', 'pig', 'opencode', 'dsh', 'codex'].includes(hostArg) ? hostArg : null));
const dashboardOpen = args.includes('--open');
// Watch mode: the server supervises a child that restarts on source change, and vite rebuilds the UI.
const dashboardWatch = args.includes('--watch');
const dashboardExport = flagValue('--export') ?? null;
// Display currency: --currency flag, then the stored default, then USD.
const currency: CurrencyCode = parseCurrencyFlag(flagValue('--currency')) ?? readStoredCurrency();
const currencyGiven = flagValue('--currency') !== undefined;
const uninstall = command === 'uninstall' || args.includes('--uninstall');
const removePonytail = args.includes('--remove-ponytail');
const keepPonytail = args.includes('--keep-ponytail');
const removeRtk = args.includes('--remove-rtk');

// User scope only (all OMP sessions). A bare `--scope user` still parses for old scripts; anything else fails.
const legacyScope = flagValue('--scope')?.toLowerCase() ?? null;
if (legacyScope !== null && legacyScope !== 'user') {
  console.error(`[fail] Invalid --scope: ${legacyScope}. Project scope was removed; tersio installs user-level only.`);
  process.exit(1);
}
// --- Profile selection (session-start mode defaults) ---

// `medium` is the retired name for `lite`, so a scripted flag written before the rename still lands. It is accepted by the parser and mapped after, because parseEnum exits on an unknown value.
/** `inherit` clears this agent's override, so it parses before the value sets do. */
function parseModeFlag(flag: string, valid: Set<string>): string | undefined {
  return flagValue(flag)?.trim().toLowerCase() === 'inherit' ? 'inherit' : parseEnum(flagValue(flag), valid, flag);
}
const rawComboFlag = parseModeFlag('--combo-default', new Set([...COMBO_DEFAULTS, ...COMBO_RETIRED]));
const comboDefaultFlag = rawComboFlag && COMBO_RETIRED.has(rawComboFlag) ? 'lite' : rawComboFlag;
const cavemanDefaultFlag = parseModeFlag('--caveman-default', CAVEMAN_DEFAULTS);
const ponytailDefaultFlag = parseModeFlag('--ponytail-default', PONYTAIL_DEFAULTS);
const pstackDefaultFlag = parseModeFlag('--pstack-default', PSTACK_DEFAULTS);
const headroomDefaultFlag = parseModeFlag('--headroom-default', HEADROOM_DEFAULTS);
const rtkDefaultFlag = parseModeFlag('--rtk-default', RTK_DEFAULTS);

const profileFlagsGiven = [
  comboDefaultFlag,
  cavemanDefaultFlag,
  rtkDefaultFlag,
  ponytailDefaultFlag,
  pstackDefaultFlag,
  headroomDefaultFlag,
].some((flag) => flag !== undefined);

function debug(...a: unknown[]): void {
  if (verbose) console.log('  [debug]', ...a);
}

const execFileP = promisify(execFile);

export interface ExecOptions {
  timeout?: number;
  cwd?: string;
  encoding?: BufferEncoding;
  maxBuffer?: number;
  windowsHide?: boolean;
  shell?: boolean | string;
  env?: NodeJS.ProcessEnv;
}

/** Windows has no real `omp`, `npm`, or `pgrep`: `.cmd` shims throw EINVAL when spawned, so a bare name wraps through cmd.exe only when a `<name>.cmd` really sits on PATH. */
export function shimCommand(cmd: string, argv: string[]): { cmd: string; args: string[] } {
  if (!IS_WINDOWS) return { cmd, args: argv };
  if (/\.(?:cmd|bat)$/i.test(cmd)) {
    return { cmd: process.env.ComSpec || 'cmd.exe', args: ['/d', '/s', '/c', cmd, ...argv] };
  }
  if (hasCmdShim(cmd)) {
    return { cmd: process.env.ComSpec || 'cmd.exe', args: ['/d', '/s', '/c', cmd, ...argv] };
  }
  return { cmd, args: argv };
}

function hasCmdShim(cmd: string): boolean {
  if (cmd.includes('/') || cmd.includes('\\')) return false;
  return (process.env.PATH || '').split(path.delimiter).some((dir) => dir && existsSync(path.join(dir, `${cmd}.cmd`)));
}

async function execP(cmd: string, argv: string[], opts: ExecOptions = {}): Promise<{ stdout: string; stderr: string }> {
  const shim = shimCommand(cmd, argv);
  return execFileP(shim.cmd, shim.args, {
    timeout: opts.timeout || 120000,
    encoding: 'utf8',
    ...opts,
  }) as Promise<{ stdout: string; stderr: string }>;
}

interface WriteOptions {
  dryRun?: boolean;
  quiet?: boolean;
  verbose?: boolean;
  /** Copy the previous file aside first. Opt in for a file the user owns; a shipped asset is reproducible. */
  backup?: boolean;
}

async function writeIfChanged(dest: string, content: string, options: WriteOptions = {}): Promise<boolean> {
  const existing = await readTextIfExists(dest);
  if (existing === content) {
    debug(`${dest} already up to date`);
    return false;
  }
  if (options.dryRun) {
    if (verbose) console.log(`  [dry-run] would write ${dest}`);
    return true;
  }
  await fs.mkdir(path.dirname(dest), { recursive: true });
  if (existing !== null && options.backup === true) {
    await fs.copyFile(dest, `${dest}.bak`);
    debug(`${path.basename(dest)} → ${path.basename(dest)}.bak`);
  }
  await fs.writeFile(dest, content, 'utf8');
  recordActivity('file', `Wrote ${shortPath(dest)}`, dest);
  if (verbose && !options.quiet) console.log(`  [write] ${dest}`);
  return true;
}

// omp ships 'extensions: null'; normalize it to a mapping key first, or YAML rejects the list items.
const EXTENSIONS_KEY_RE = /^\s*extensions\s*:/i;
const EXTENSIONS_NULL_RE = /^\s*extensions\s*:\s*(?:\[\s*\]|null|~)?\s*$/i;

function normalizeExtensionsKey(lines: string[]): boolean {
  const idx = lines.findIndex((l) => EXTENSIONS_NULL_RE.test(l));
  if (idx === -1) return false;
  lines[idx] = 'extensions:';
  return true;
}

async function writeConfigLines(
  configPath: string,
  lines: string[],
  logMsg: string,
  options: WriteOptions = {},
): Promise<void> {
  await fs.mkdir(path.dirname(configPath), { recursive: true });
  await fs.copyFile(configPath, `${configPath}.bak`).catch(() => {});
  await fs.writeFile(configPath, lines.join('\n'), 'utf8');
  if (verbose && !options.quiet) console.log(logMsg);
}

async function ensureExtensionInConfig(
  configPath: string,
  extensionPath: string,
  label: string,
  options: WriteOptions = {},
): Promise<boolean> {
  const normalizedPath = extensionPath.replace(/\\/g, '/');
  const line = `  - ${normalizedPath}`;

  const raw = await readTextIfExists(configPath);
  let lines = (raw || '').split('\n');

  // Drop legacy compiled twins (.js beside the name): OMP must never load both. Matched on the trailing path.
  if (normalizedPath.endsWith('.ts')) {
    const legacyTail = `${normalizedPath.slice(0, -3)}.js`.split('/').slice(-2).join('/');
    lines = lines.filter((l) => !l.trim().replace(/^\.\//, '').endsWith(legacyTail));
  }

  const matchingEntries = lines.filter(
    (entry) =>
      entry
        .trim()
        .replace(/^-\s*/, '')
        .replace(/^['"]|['"]$/g, '') === normalizedPath,
  );
  if (matchingEntries.length > 1) {
    if (options.dryRun) {
      if (verbose && !options.quiet)
        console.log(
          `  [dry-run] would remove ${matchingEntries.length - 1} duplicate ${label} registration${matchingEntries.length === 2 ? '' : 's'}`,
        );
      return true;
    }
    let kept = false;
    lines = lines.filter((entry) => {
      if (
        entry
          .trim()
          .replace(/^-\s*/, '')
          .replace(/^['"]|['"]$/g, '') !== normalizedPath
      )
        return true;
      if (kept) return false;
      kept = true;
      return true;
    });
    await writeConfigLines(configPath, lines, `  [write] Removed duplicate ${label} registration`, options);
    return true;
  }
  if (matchingEntries.length === 1) {
    debug(`${label} already in config.yml`);
    return false;
  }

  const extLineIdx = lines.findIndex((l) => EXTENSIONS_KEY_RE.test(l));

  if (options.dryRun) {
    if (verbose && !options.quiet) console.log(`  [dry-run] would add ${label} to config.yml`);
    return true;
  }

  if (normalizeExtensionsKey(lines)) {
    lines.splice(extLineIdx + 1, 0, line, '');
  } else if (extLineIdx === -1) {
    lines.push('extensions:');
    lines.push(line);
    lines.push('');
  } else {
    lines.splice(extLineIdx + 1, 0, line);
  }

  await writeConfigLines(configPath, lines, `  [write] Added ${label} to config.yml`, options);
  return true;
}

async function removeExtensionFromConfig(
  configPath: string,
  extensionPath: string,
  label: string,
  options: WriteOptions = {},
): Promise<boolean> {
  const normalizedPath = extensionPath.replace(/\\/g, '/').replace(/^\.\//, '');
  const extensionSuffix = normalizedPath.includes('/extensions/')
    ? normalizedPath.slice(normalizedPath.indexOf('/extensions/') + 1)
    : normalizedPath;
  const raw = await readTextIfExists(configPath);
  if (raw === null) return false;
  const lines = raw.split('\n');
  const matches = (entry: string): boolean => {
    const value = entry
      .trim()
      .replace(/^-\s*/, '')
      .replace(/^['"]|['"]$/g, '')
      .replace(/\\/g, '/')
      .replace(/^\.\//, '');
    return value === extensionSuffix || value.endsWith(`/${extensionSuffix}`);
  };
  const kept = lines.filter((entry) => !matches(entry));
  const removed = lines.length - kept.length;
  if (removed === 0) return false;
  if (options.dryRun) {
    if (verbose && !options.quiet)
      console.log(`  [dry-run] would remove ${label} registration${removed === 1 ? '' : 's'}`);
    return true;
  }
  await writeConfigLines(configPath, kept, `  [write] Removed duplicate ${label} registration`, options);
  return true;
}

function readPonytailConfig(): { dir: string; path: string } {
  const dir = process.env.XDG_CONFIG_HOME
    ? path.join(process.env.XDG_CONFIG_HOME, 'ponytail')
    : path.join(HOME, '.config', 'ponytail');
  return { dir, path: path.join(dir, 'config.json') };
}

interface PonytailConfig {
  defaultMode?: string;
  hideStatus?: boolean;
  [key: string]: unknown;
}

function parseJsonObject<T extends Record<string, unknown>>(text: string | null): T | null {
  if (!text) return null;
  try {
    const parsed: unknown = JSON.parse(text.replace(/^\uFEFF/, ''));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    return parsed as T;
  } catch {
    return null;
  }
}

function parsePonytailConfig(existing: string | null): PonytailConfig {
  return parseJsonObject<PonytailConfig>(existing) ?? {};
}

async function patchPonytailConfig(
  apply: (cfg: PonytailConfig) => boolean,
  dryRunNote: string,
  writeNote: string,
  options: WriteOptions = {},
): Promise<void> {
  const config = readPonytailConfig();
  if (options.dryRun) {
    if (verbose && !options.quiet) console.log(`  [dry-run] ${dryRunNote}`);
    return;
  }
  const cfg = parsePonytailConfig(await readTextIfExists(config.path));
  if (!apply(cfg)) {
    debug('Ponytail config already up to date');
    return;
  }
  await fs.mkdir(config.dir, { recursive: true });
  await fs.writeFile(config.path, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
  if (verbose && !options.quiet) console.log(`  [write] ${writeNote}`);
}

async function ensurePonytailConfigValue<K extends keyof PonytailConfig>(
  key: K,
  value: PonytailConfig[K],
  options: WriteOptions = {},
): Promise<void> {
  await patchPonytailConfig(
    (cfg) => {
      if (cfg[key] === value) return false;
      cfg[key] = value;
      return true;
    },
    `would set Ponytail ${key}=${value}`,
    `Set Ponytail ${key}=${value}`,
    options,
  );
}

// Read plugins/package.json tolerantly; a corrupt or missing file starts fresh with installer-managed defaults.
async function readPluginsPackage(pkgPath: string): Promise<PluginsPackage & { dependencies: Record<string, string> }> {
  const pkg = parseJsonObject<PluginsPackage>(await readTextIfExists(pkgPath)) ?? {};
  return { ...pkg, name: pkg.name || 'omp-plugins', private: true, dependencies: pkg.dependencies || {} };
}

function relTime(ageMs: number): string {
  const mins = Math.floor(ageMs / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min${mins === 1 ? '' : 's'} ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  const days = Math.floor(hours / 24);
  if (days < 14) return `${days} day${days === 1 ? '' : 's'} ago`;
  const weeks = Math.floor(days / 7);
  return `${weeks} week${weeks === 1 ? '' : 's'} ago`;
}

function pad(s: string, n: number): string {
  return s.length >= n ? s : s + ' '.repeat(n - s.length);
}

// Box-drawing table, plain text (piped-safe, byte-stable). Numbers right-align; long cells truncate with an ellipsis.
function textTable(headers: string[], rows: string[][], right: boolean[] = [], maxW = 32): string[] {
  const cells = [headers, ...rows].map((r) => r.map((c) => (c.length > maxW ? c.slice(0, maxW - 1) + '…' : c)));
  const widths = headers.map((_, i) => Math.max(...cells.map((r) => r[i].length)));
  const line = (l: string, m: string, r: string): string => l + widths.map((w) => '─'.repeat(w + 2)).join(m) + r;
  const row = (cs: string[]): string =>
    '│ ' + cs.map((c, i) => (right[i] ? c.padStart(widths[i]) : pad(c, widths[i]))).join(' │ ') + ' │';
  const out = [line('┌', '┬', '┐'), row(cells[0]), line('├', '┼', '┤')];
  for (const r of cells.slice(1)) out.push(row(r));
  out.push(line('└', '┴', '┘'));
  return out.map((l) => '  ' + l);
}

export {
  IS_WINDOWS,
  RTK_BINARY_NAME,
  HOME,
  OMP_AGENT_DIR,
  OMP_PLUGINS_DIR,
  BUN_BIN_DIR,
  OMP_BIN,
  NPM_BIN,
  BUN_BIN,
  PACKAGE_NAME,
  PACKAGE_BIN,
  PACKAGE_VERSION,
  CAVEMAN_DEFAULTS,
  PONYTAIL_DEFAULTS,
  PSTACK_DEFAULTS,
  HEADROOM_DEFAULTS,
  RTK_DEFAULTS,
  COMBO_PRESET_MODES,
  COMBO_DEFAULTS,
  ACCENT_DEFAULTS,
  parseEnum,
  flagValue,
  COMMANDS,
  commandArg,
  command,
  unknownCommand,
  mcp,
  modes,
  codexHook,
  install,
  update,
  showVersion,
  showHelp,
  applyUpdate,
  args,
  dryRun,
  yes,
  assumeYes,
  verbose,
  doctor,
  fix,
  uninstall,
  dashboard,
  upstream,
  dashboardPort,
  dashboardBind,
  dashboardOpen,
  dashboardWatch,
  dashboardExport,
  currency,
  currencyGiven,
  removePonytail,
  keepPonytail,
  removeRtk,
  comboDefaultFlag,
  cavemanDefaultFlag,
  ponytailDefaultFlag,
  pstackDefaultFlag,
  headroomDefaultFlag,
  rtkDefaultFlag,
  profileFlagsGiven,
  debug,
  execFileP,
  execP,
  writeIfChanged,
  normalizeExtensionsKey,
  writeConfigLines,
  ensureExtensionInConfig,
  removeExtensionFromConfig,
  readPonytailConfig,
  parseJsonObject,
  parsePonytailConfig,
  patchPonytailConfig,
  ensurePonytailConfigValue,
  readPluginsPackage,
  relTime,
  textTable,
};
export type { InstallOptions, PluginsPackage, PonytailConfig, WriteOptions };
