# Derivation of this package

This package is a maintained fork of `dsh-opencode-go`, redistributed here so the
upstream's silent model-loss paths are fixed and so a collision with the
baseline can no longer take down the whole plugin tree. It is not a rewrite: the
wire protocol work, the settings UI, and the conversion modules are unchanged.

## Provenance

| Layer | Origin | License |
|---|---|---|
| Adapter, settings UI, `src/conversion/{context,stream,replay}.ts` | [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) | MIT |
| Package shell, build, tests, `docs/`, `examples/` | [`Duskriver/dsh-opencode-go`](https://github.com/Duskriver/dsh-opencode-go) | MIT |
| This fork's host-side fixes | This repository | MIT |

`dsh-opencode-go@0.1.2` is the baseline. That version is itself a fork of the
user's working copy of DeepSeek Harness on branch `oh-my-dsh`
(HEAD `2c8555b323f3b49eac743bafd527f9f3238bf548`); see the upstream's
`docs/independent-package.md` for how that extraction was done.

## What this fork changes

Exactly two artefacts carry code differences: `lib/index.js` (the five changes
below) and the three type declarations that describe the surface those changes
add — `lib/types/catalog.d.ts`, `lib/types/config.d.ts`, `lib/types/index.d.ts`.
Everything else is byte-identical to the baseline: `lib/client.js`, the other
`lib/types/**` modules, the bundle manifest (`cordis.patch.yml` apart from the
entry id), and the client manifest inside `package.json`.

### Guarding the second all-or-nothing registration

Upstream guarded `registerAdapter()` and missed the other registration that is
just as unconditional: `ctx.llm.registerModelDiscovery(settingsNs, discover)`,
keyed by the settings namespace, which throws `DUPLICATE_DISCOVERY`. This
package keeps the baseline's namespace on purpose, so installing both makes the
second one throw — from inside the loader's own effect, uncaught, which fails
the entire plugin tree rather than just that entry. Measured: with this package
first and the baseline second, `dsh web` exits 1 and every unrelated plugin in
the profile goes down with it.

The registration now happens before any route is claimed, inside a try/catch
that recognises only the duplicate, logs the remedy, and returns from `apply()`
— leaving the plugin inert (no route, no settings section) instead of taking the
tree down. Any other failure is rethrown. The discovery handler also compares
against `adapter.route` rather than `PROVIDER_ID`, so it stays correct when the
route fallback is in play.

### `FALLBACK_PROVIDER_ID`

`registerAdapter()` rejects any route another adapter already holds, with
`DUPLICATE_ADAPTER`, all-or-nothing. Upstream caught that and stopped, which
withdrew the entire dynamic catalog; the usual occupier is a model list that
dsh materialized into `settings.yaml` under `llm-pi-ai.providers.opencode-go`,
and such a list cannot grow, so newly published models never appear.

The fork retries under `opencode-go-plus` and warns with the exact remedy. The
route id is threaded through `curatedModels`, `adaptModelFromFamily`,
`buildProvider`, and `OpencodeGoCatalog` because the runtime rejects a catalog
whose entries name a provider other than the one registered
(`INVALID_CATALOG`); `OpencodeGoAdapter.route` is set before each registration
attempt for the same reason.

### Borrowed adaptation for unseen families

`adaptModelFromFamily()` required a same-family curated model to clone from and
returned `undefined` otherwise. A brand-new family therefore never reached the
picker. The fork falls back to the whole curated table, scoring by token
overlap, then majority protocol, then id-length proximity. `/models` returns
only `id`/`object`/`created`/`owned_by`, so the parameters remain estimates —
but an estimate the user can override beats an omission they cannot see.

### Self-check logging

`OpencodeGoCatalog` gained an `onResolved` observer reporting
`curated` / `listed` / `adapted` / `omitted` / `served` / `missing` per
resolution. `omitted` and `missing` are warnings, because both mean a model the
user might expect is absent.

### `catalogAdditions` setting

The hardcoded `CATALOG_ADDITIONS` constant became the default value of a
`schemastery` array field. schemastery passes object members through without
validating them, so `usableAdditions()` filters entries at use: a partially
spelled entry would otherwise seed a model with no wire protocol.

### 0.3.0 — the settings surface moved into Settings → Models

Through 0.2.1 this package registered a settings section of its own
(`settings.section`, id `opencode-go`), which put a second OpenCode Go entry in
the Settings sidebar next to the provider row the Models page already drew from
`llm-pi-ai`'s directory. 0.3.0 removes that section and gives the route a row
on the Models page that belongs to this package:

- **Host half (`lib/index.js`)** — `apply()` now calls
  `ctx.llm.registerConfigurableProviders([...])` for the route, with the
  `llm-opencode-go` namespace and an EMPTY `settingsPath` (the section root is
  the profile). This is what makes the Models page treat the row as configured
  and addressable.
- **Client half (`lib/client.js`)** — the `settings.section` registration, the
  settings scope that fed it, and the credential-invalidation effect that kept
  its badge fresh were deleted. The composer's usage pill is untouched and still
  registers into `conversation.input.right`.
- **Manifest (`package.json`)** — `dsh.client.inject` no longer lists
  `@deepseek-ai/dsh-client-ui-settings`, and that package is no longer a peer:
  nothing in this bundle reads the settings scope service any more.

#### Why the row's provider is `opencode-go-plus`, not `opencode-go`

`registerConfigurableProviders` rejects a second declaration of the same
provider, and `opencode-go` is **already declared** by
`@deepseek-ai/dsh-llm-pi-ai`, whose installed pi-ai catalog ships a route by
that name. Measured here: pi-ai's directory lists `opencode-go` with
`declared: false` before this package is loaded at all. Declaring it here does
not merely lose the row — the throw is `DUPLICATE_DIRECTORY`, it comes out of
`apply()`, and every statement after it never runs, so the route is never
claimed either and the plugin goes completely inert. The fallback id
`opencode-go-plus` is free in that directory, and it is also the route this
package actually serves whenever `opencode-go` was taken — the normal state on
any installation that also runs the pi-ai catalog.

#### What the row does and does not offer

The row shows the display name, the route, and the page's credential dot. Its
edit card offers the generic credential field: because the Models editor selects
its curated field set by settings namespace and knows only `llm-deepseek` and
`llm-pi-ai`, the card for `llm-opencode-go` states that the remaining fields live
in `settings.yaml`. That is deliberate — `refreshMinutes`, `autoDiscover`, the
image budgets, and `catalogAdditions` stay in `settings.yaml`, which the row
reports instead of half-editing. The row resolves its credential reference from
the section (`apiKeyEnv`), so its dot reports the key the plugin actually uses.

## What is intentionally unchanged

- Settings namespace stays `llm-opencode-go`, so existing configuration keeps working.
  The cost of that choice is that the baseline cannot share a profile with this
  package; see `examples/migrate-from-fork.patch.yml` for the measured outcomes.
- The only new setting key is `catalogAdditions`.
- Request headers, replay behaviour, and usage reporting are untouched. Image
  handling changed once, in 0.4.5, for the reason recorded below.

## Verifying a rebuild

The tarball ships the compiled `lib/` only; no source tree is included, so there
is no build step. To check a package against the baseline:

```sh
mkdir -p /tmp/base && tar -xzf dsh-opencode-go-0.1.2.tgz -C /tmp/base
diff -rq /tmp/base/package/lib ./lib
```

Five paths should differ, and nothing should be reported as "Only in" — an extra
module means the build leaked a private file:

```none
lib/index.js                # the host-side changes above
lib/client.js               # 0.3.0: the settings section registration removed
lib/types/catalog.d.ts      # declarations for FALLBACK_PROVIDER_ID / onResolved
lib/types/config.d.ts       # declaration for the catalogAdditions setting
lib/types/index.d.ts        # re-exports of the above
```

From 0.2.1 to 0.3.0 the set is smaller and easier to audit: only three paths
change — `package.json` (version, description, client inject list, dropped peer),
`lib/index.js` (the configurable-provider declaration), and `lib/client.js` (the
section registration and its scope/section-controller wiring removed). Every
declaration under `lib/types/**` is unchanged, including the ones that still
describe the section: they are additive type surface, not shipped behaviour.

## 0.4.1 — script-free plugin installation

The runtime now imports a checked-in, limited pi-ai bundle instead of installing the
complete provider SDK tree. The OpenCode Go catalog and its three protocols are
unchanged from pi-ai 0.85.1. The former runtime dependency is an optional, type-only
peer so Harness does not install it. See [vendored runtime](vendored-runtime.md) for
reproduction, license provenance, and checks. No lifecycle script or pnpm approval
exception was added to the plugin.

## 0.4.2 — credentials and connection status inside the Models card

The stock 0.1.7-rc.2 editor hardcodes the llm-deepseek and llm-pi-ai namespaces,
so a third-party namespace displays only a configuration-file hint. The plugin
now registers the keyed settings.models.provider-card slot for llm-opencode-go.
It does not alter the host editor or add another settings section.

The browser source lives in scripts/client; rebuild it into the existing prebuilt
lib/client.js with node scripts/build-client.mjs after installing the maintenance
tools in scripts/vendor. The new host connection service exposes only credential
metadata and bounded status values. The credential write still uses the host's
credentials service. Manual checks call the usage endpoint, then force a new live
catalog snapshot. Model requests and installation dependencies are unchanged.

Tests: node --test scripts/connection-test.mjs scripts/runtime-test.mjs
scripts/connection-host-test.mjs (set HARNESS_TEST_MODULES for host checks).
The published client was also exercised in Chrome with mocked RPC responses,
including missing keys, saving, 401, transport errors, React StrictMode and mobile
layout. Actual paid-account authentication was not performed.

## 0.4.3 — the card stops reading forever, accepts a key, and folds

Three symptoms reported from the desktop build traced to the browser half alone;
the host RPC was re-checked end to end against the real 0.1.7-rc.2 tree and was
sound.

The key field was disabled whenever the card had no status yet, so a first
status() that rejected — host not up, gateway call stalled — left the card reading
forever with a field that silently swallowed both typing and paste. The field now
disables only for a read-only credential or an in-flight save. Status reads are
wrapped in a 15s deadline and retried with exponential backoff, but only while no
status has ever arrived; once one exists, a failed refresh keeps the last known
status and hands retrying back to the user. Note the deliberate asymmetry: the
timeout timer must stay ref'd, because it is the only thing that turns a stalled
call into a visible failure, while the retry timer is unref'd so it cannot hold the
process open.

The card is now a details/summary disclosure whose body collapses, matching the
host's own disclosure styling, with a tone-coloured status line in the summary and
the duplicated status block removed. A details child that sets its own display
outranks the UA's closed-details rule, so the collapse rule is stated explicitly;
the shipped bundle is asserted against it. describe() and parseConnectionStatus
also default absent fields and an unreadable credential store into an actionable
state instead of blanking the card or failing the RPC.

Tests: node --test scripts/connection-test.mjs (21) and
scripts/connection-host-test.mjs (1). The card was re-checked in a live dsh web
profile: folded and unfolded, status tone, and a typed key enabling save. Real OS
clipboard paste could not be exercised in this environment — the automation
session has no clipboard access — so paste is covered indirectly: no paste or key
handler is registered, the field is enabled and writable, and onChange updates
state.

## 0.4.4 and 0.4.5 — the conversion layer meets the current session format

Both releases fix the same inheritance problem: the conversion modules in
`lib/index.js` came from the harness as it stood when the baseline was extracted,
and the harness has moved since.

0.4.4 repaired the bundled runtime's cold-start reasoning helpers (see
`docs/verification.md`, "2026-09-27: cold-start reasoning model repair").

0.4.5 repairs the history conversion. Session format v4 **retired the
`tool-result` content wrapper**: a tool result is now its own `role: "tool"`
message carrying raw blocks, which is what `createToolResultMessage` writes and
what the harness's own pi-ai adapter reads back through its `toolResultOf`. The
conversion here only knew the v3 shape — a wrapper nested inside a user message —
so on `0.1.7-rc.2`:

- a plain tool result was folded into a **user** turn, leaving the assistant's
  tool call unanswered in the request; and
- a tool result that carried an image threw, because the image-role guard
  accepted only `user`:

  ```none
  LlmError: pi-ai cannot represent an image in an in-history tool message
    code: UNSUPPORTED_CONTENT
  ```

The second one is reachable in normal use: `read_image` gates on the calling
route's declared image input, and this adapter publishes the live catalog's
modalities, so the tool is offered exactly when its result cannot come back. A
recorded image is durable, so every later request in that session re-throws.

The fix mirrors the harness's own adapter:

- `assertSupportedImageRoles` accepts `tool` as well as `user`;
- a `toolResultOf` helper rebuilds one pi-ai `toolResult` from a tool-role
  message, carrying its `toolCallId`, its `toolName` recovered from the preceding
  tool call, and — on the image path — the resolved image and its handle text;
- both conversion paths take that branch for a `role: "tool"` message that does
  not contain a nested wrapper, so the v3 shape keeps converting exactly as
  before.

`lib/types/conversion/context.d.ts` states the new rule; `scripts/conversion-test.mjs`
pins all of it (see `docs/verification.md`).
