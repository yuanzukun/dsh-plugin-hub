import { useEffect, useRef, useState } from 'react'
import { Button, IconCloseOutlineRegular, Tooltip } from '@deepseek-ai/dsh-client-ui-primitives'
import { defineStore } from '@deepseek-ai/dsh-client-store'

const NS = 'browserctl'
const STYLE_ID = 'browserctl/styles'

// 插件版本号(「关于」面板展示)。单一来源 = package.json 的 version:
// build.mjs 用 esbuild --define:__DSHREMOTE_VERSION__ 注入,浏览器端只认这个注入值
// (不能 import fs/package.json,浏览器 bundle 里没有 Node 能力);源码未构建时显示 dev。
const VERSION = typeof __DSHREMOTE_VERSION__ === 'string' ? __DSHREMOTE_VERSION__ : 'dev'
// 「关于」面板外部链接,集中一处管理,日后发布一次改齐
const ABOUT_LINKS = {
  website: 'https://remote.ymzcc.com/dsh-remote/',
  github: 'https://github.com/Memorial-coder/dsh-remote-plugin',
  app: 'https://github.com/Memorial-coder/dsh-remote-plugin/releases/latest',
  qq: 'https://qm.qq.com/q/K6RXqOKLAu',
}
function lsGet(k) { try { return window.localStorage.getItem(k) || '' } catch (e) { return '' } }
function lsSet(k, v) { try { window.localStorage.setItem(k, v) } catch (e) {} }

// ---------- 顶栏「通知中心」本地水位(未登录已读判断) ----------
// 值 = 最后一次打开通知列表时见过的最大 createdAt(毫秒);新于水位即视为未读。
const MSG_SEEN_KEY = 'dsh_msg_seen_' + NS
function msgSeenTs() { const v = parseInt(lsGet(MSG_SEEN_KEY), 10); return Number.isFinite(v) ? v : 0 }
function msgIsSeen(msg) { return (Number(msg && msg.createdAt) || 0) <= msgSeenTs() }
function fmtMsgTime(ts) {
  const t = Number(ts)
  if (!t) return ''
  const d = new Date(t)
  const p = n => (n < 10 ? '0' : '') + n
  return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes())
}

// ---------- API 路径前缀(远程访问适配) ----------
// 面板不只跑在本机(127.0.0.1:<dsh端口>),还会被手机/外网浏览器经隧道访问,页面带路径前缀:
//   /p/<port>/...            → nginx 多用户块(按端口查 registry 验签后转发闸机)
//   /dsh-remote/p/<uid>/...  → 官网服务端 uid 稳定代理(按 uid 解析当前端口转发)
// 本插件所有 fetch 都是绝对路径('/browserctl/api/*'、'/browserctl-gate/*'),不加前缀会
// 落到域名根路径的静态反代 location(proxy_pass 指向生成时的固定端口)→ 端口一变就 502,
// 表现为「桌面正常、扫码进远控端后面板全部接口 502」。所以请求统一带上页面自身的前缀。
function apiPrefix() {
  try {
    const p = String((typeof location !== 'undefined' && location.pathname) || '')
    let m = /^\/p\/(1[6-9]\d{4})(?=\/|$)/.exec(p)
    if (m) return '/p/' + m[1]
    m = /^\/dsh-remote\/p\/([a-z0-9]{8,32})(?=\/|$)/.exec(p)
    if (m) return '/dsh-remote/p/' + m[1]
  } catch {}
  return '' // 本机直连(桌面)无前缀
}
const API_P = apiPrefix()

// ---------- 用户协议 / 隐私政策(「关于」面板内点击展开,参照桃源乡 legalDocuments 结构) ----------
const LEGAL_VERSION = '2026-11-09'
const LEGAL_EFFECTIVE = '2026年11月9日'
const LEGAL_AGE = '本工具仅面向年满 18 周岁的用户'

const LEGAL_TERMS = {
  id: 'terms',
  title: '用户协议',
  subtitle: `更新生效日期：${LEGAL_EFFECTIVE}。凡安装、使用本插件/面板（DSH 远程助手），通过手机或外网浏览器远程访问本机 DeepSeek 助手面板，即视为您已完整阅读、理解并同意本协议全部条款。`,
  sections: [
    {
      title: '适用对象与效力声明',
      paragraphs: [
        '本协议适用于所有安装、启动、使用本插件/面板、通过手机或外网浏览器远程访问本机面板、参与测试与反馈的全部用户。',
        '凡下载、安装、使用本工具、开启隧道、扫码或通过链接远程访问本机面板，即视为您已完整阅读、逐条理解、自愿同意并接受本协议全部条款，并自行承担全部使用风险。',
        '若您不同意本协议任意条款，请立即停止安装与使用，并卸载相关插件、清除本地配置。',
        LEGAL_AGE + '。您确认使用本服务时已年满 18 周岁；若未满 18 周岁，请立即停止使用。',
      ],
    },
    {
      title: '第一章 总则',
      paragraphs: [
        '1.1 服务定位。本工具（DSH 远程助手，含浏览器控制插件、本机闸机与配套 App）为个人独立开发的公益免费远程协助工具，用于把本机 DeepSeek 助手 Web 面板通过加密隧道安全穿透到手机或外网浏览器，实现随时随地远程控制，无任何商业上架资质与强制收费。本工具不处理、不存储、不查看您的对话内容与面板内业务数据。',
        '1.2 使用前提。远程访问依赖网络、frp 隧道与本机闸机服务，存在波动与中断的可能；不同终端、浏览器可用功能可能存在差异，以您实际使用的版本界面为准。',
        '1.3 协议组成。本《用户协议》与《隐私政策》共同构成完整约定；就特定功能（如 2FA、配对、黑名单、推送、工单诊断日志、官网账号与签到时长、设备授权）另有页面提示或规则的，构成补充约定，补充约定与本协议冲突时，就该功能以更具体的补充约定为准。',
        '1.4 收费说明。本服务目前完全免费，不收取任何费用，也没有付费解锁、会员订阅或内购项目。若未来因运营成本调整收费方式，我们会提前在面板内显著公告并征得您的同意，您可以在此之前继续免费使用或停止使用。',
        '1.5 服务变更与终止。本工具为个人独立开发，可能因个人精力、依赖环境或不可抗力调整或停止部分功能乃至整体服务；涉及整体停止时，我们会尽可能提前在官网与面板公告。自建部署不受官方托管服务调整的影响；本服务免费，不承诺任何服务年限。',
      ],
    },
    {
      title: '第二章 服务使用规范与用户义务',
      paragraphs: [
        '2.1 授权访问。您仅可为本人或经您明确授权的设备、人员提供远程访问。严禁将配对二维码、引导链接、登录 Cookie、访问口令分享、转售给未授权第三方。',
        '2.2 禁止行为。严禁对服务实施反向代理、抓包封装、破解或绕过鉴权与签名校验、恶意高频请求、漏洞扫描、流量攻击、批量爬取等破坏性行为；严禁利用本工具从事任何违法违规活动。',
        '2.3 凭据保管。配对链接、引导链接、Cookie 与动态验证码属于敏感凭据，请妥善保管，勿截图长期留档、勿发公开群。因您泄露凭据导致的未授权访问，由您自行承担。',
        '2.4 2FA 使用。本服务存在两类两步验证：面板/闸机两步验证——开启后新设备首次连接需输入验证器 6 位动态码，验证通过的设备 30 天内免重复验证；官网账号两步验证——在个人中心开启后，每次登录官网账号均需输入动态码或备用码。请勿将动态码与备用码告知他人；开启/关闭两步验证会使原有登录令牌立即失效，需重新登录。',
        '2.5 内容合规。本工具用于访问 AI 助手面板，请勿利用其生成、传播违法违规、暴力、色情、侵权或损害他人权益的内容。',
        '2.6 开源与非商业。本项目遵循开源许可发布，允许个人学习、非商用使用与合规二创；禁止一切未经授权的商业用途、抹除署名的二次分发与转售。',
        '2.7 官网账号注册与使用。注册需提供可用邮箱并完成验证码验证；为保证账号质量，仅接受常见主流邮箱域名，暂不支持临时/一次性邮箱。请勿批量注册、转让或出借账号，请勿使用他人邮箱注册。您应妥善保管账号密码；遗忘密码可通过邮箱验证码登录或联系管理员处理。违规注册、刷接口或滥用账号的，我们有权拒绝注册、停用或删除账号。',
        '2.8 时长余额与签到。官方托管模式下，远程使用时长消耗账号的时长余额；您可通过每日签到等方式获得时长，余额用尽时将无法建立新的远程连接。时长仅用于本服务的公平使用分配，请勿以脚本、多账号等方式刷取或囤积时长；管理员有权对异常获取的时长进行调整，并对滥用账号采取限制措施。',
        '2.9 App 安装与更新。配套 App 以 APK 形式通过官网直链或官方 GitHub 仓库分发，未经任何应用商店上架。请仅从上述官方渠道下载安装，并在安装前自行核验来源；App 内更新检查仅查询版本信息，更新与否由您自行决定。',
        '2.10 工单与诊断日志提交。在工单中附带诊断日志或自行上传日志文件，属于完全自愿的行为，且必须先由您在预览界面查看完整内容、勾选确认「不含敏感信息」后才会提交上传；不附带不影响工单的正常处理。请您在确认前自行核对内容中不含他人个人信息、商业机密、账号密码、API 密钥等敏感信息：诊断日志中的常见敏感字段（访问令牌、Cookie、签名、密码字段、IP 末两段、账号目录路径等）由系统自动打码，但自动打码无法保证覆盖所有情形，您自行挑选上传的日志文件更是原样上传、不做打码。因您上传内容引发的信息泄露、侵权或合规风险由您自行承担；您上传即视为授权我们在该工单故障排查的必要范围内查看、存储与处理该内容，并在工单删除时一并删除。',
      ],
    },
    {
      title: '第三章 安全机制与设备管理',
      paragraphs: [
        '3.1 身份验证。面板访问采用「设备信任 + 可选 TOTP 两步验证（RFC 6238）」机制，连错 5 次冻结 15 分钟，同码防重放；官网账号登录支持密码、邮箱验证码与（开启后的）两步验证，多次失败将触发临时锁定或 IP 级限速。',
        '3.2 会话与凭据。面板验证通过后签发有效期为 30 天的 bc-gate 记忆 Cookie，用于免验证直连；官网登录令牌有效期同为 30 天，开启/关闭两步验证或管理员撤销后立即失效。您可随时通过面板「踢下线」或「全部踢下线」使指定设备或全部设备重新认证。',
        '3.3 设备登记。验证通过的设备会记录匿名设备标识、IP、User-Agent 等必要信息用于会话与风控；您可在面板与个人中心查看在线/历史设备，并拉黑指定 IP。',
        '3.4 引导链接。为无 App 设备生成的引导链接为明文，请在有效期内使用并按需控制有效期；介意风险的请用后轮换。',
        '3.5 设备授权。插件登录支持设备授权流程（RFC 8628）：插件向您展示一次性授权码，您需在浏览器中登录官网账号并亲自点击「确认授权」后方可生效；授权码 15 分钟有效、单次使用，未确认不会产生任何登录。请勿在非本人操作的授权页面上点击确认。',
      ],
    },
    {
      title: '第四章 免责声明与责任限制',
      paragraphs: [
        '4.1 本工具以「现状提供」为原则，为个人独立公益开发，不保证服务零中断、零故障、全终端兼容；因网络波动、隧道中断、设备故障、系统更新导致的访问异常，开发方在能力范围内尽力恢复，但不作绝对承诺。',
        '4.2 远程访问本身存在安全风险（如设备被他人物理接触、系统被入侵、网络被监听）。请您确保本机与设备的系统、密码、密钥安全；因本机或设备安全失守导致的损失由您自行承担。',
        '4.3 本服务目前完全免费，我们不向您收取任何费用。在法律允许的最大范围内，开发方对任何间接、附带、后果性损害不承担责任；因本服务引起争议需承担责任的，责任上限以您就相关事项向开发方实际支付的费用为限（目前为 0），法律法规另有强制规定的除外。',
        '4.4 第三方资源（如 frps 服务器、云基础设施、隧道服务、邮件服务商、IP 归属地查询服务）由相应第三方提供，其故障与政策变化不构成本方违约。',
      ],
    },
    {
      title: '第五章 违规处理与争议解决',
      paragraphs: [
        '5.1 对违反本协议、破坏服务安全或损害他人权益的用户，开发方有权采取阻断访问、封禁 IP/设备、限制功能、踢出全部会话、停用或删除账号等措施。被处置用户可通过官方渠道提出申诉，我们核实后据实处理。',
        '5.2 争议协商优先；协商不成，适用中华人民共和国现行有效法律，并向开发方所在地有管辖权的人民法院提起诉讼。',
        '5.3 条款独立性：本协议任意条款被认定为无效、不可执行的，不影响其余条款的效力。',
      ],
    },
    {
      title: '第六章 协议修订与生效',
      paragraphs: [
        '6.1 本协议将根据法律法规、产品迭代与安全需要适时修订，修订后的版本在面板「关于」内公布；对您权益产生重大影响的变更将显著提示。',
        '6.2 继续使用即视为接受修订后的协议；不同意者可停止使用并清除本地数据。',
        '6.3 本协议最终解释权归开发方所有（法律法规另有强制规定的除外）。',
      ],
    },
  ],
}

const LEGAL_PRIVACY = {
  id: 'privacy',
  title: '隐私政策',
  subtitle: `更新生效日期：${LEGAL_EFFECTIVE}。适用产品：DSH 远程助手（浏览器控制插件、本机闸机、配套 App 及网页面板）。本政策与《用户协议》一并适用，请重点阅读与信息收集、Cookie、共享、权利行使相关的条款。`,
  sections: [
    {
      title: '前言',
      paragraphs: [
        'DSH 远程助手开发方（以下简称「我们」）承诺保护使用本工具之用户（以下统称「您」）的个人信息和隐私安全。本工具为个人独立公益开发，坚持最小必要、自愿授权、非强制收集、禁止将数据用于商业变现的原则。',
        '本服务目前完全免费，不向您收取任何费用；正因为不收费，我们更不会以出售、出租或商业变现您的个人信息作为收入来源。',
        '适用法规依据包括但不限于《中华人民共和国个人信息保护法》《中华人民共和国网络安全法》及相关监管规范。',
        LEGAL_AGE + '。',
      ],
    },
    {
      title: '特别提示',
      paragraphs: [
        '1. 本政策与《用户协议》同时对您产生效力；同类条款不一致时，就个人信息处理事项以本政策为准，其余以《用户协议》为准。',
        '2. 只有当您开启远程访问、注册账号、配对、推送等功能时，为实现该功能我们才会处理对应信息；不开启相关功能则不处理对应的个人信息。',
        '3. 使用前请仔细阅读本政策。若您不同意，请立即停止访问/使用。',
        '4. 本政策目录：一、适用范围；二、我们如何收集和使用信息；三、Cookie 与同类技术；四、共享、转移或公开；五、存储与保护；六、您的权利；七、未成年人保护；八、修订和通知；九、如何联系我们。',
      ],
    },
    {
      title: '一、适用范围',
      paragraphs: [
        '本政策适用于本机闸机、浏览器控制插件、配套 App、官网（含登录页、个人中心、消息中心、工单系统）、官网账号后端及随技术发展出现的新形态。',
        '本政策不适用于第三方独立运营的服务（如 frps 服务器商、云基础设施、邮件服务商、IP 归属地查询服务、您自行配置的隧道服务等），该等服务适用其各自规则；涉及向其提供信息的情况见「四、共享、转移或公开」。',
        '特别地：远程访问的对象是您本机的 DeepSeek 助手（DSH）面板。本工具不处理、不存储、不查看您的对话内容与面板内业务数据，该等内容由 DSH 及其服务方按其自身政策处理。',
      ],
    },
    {
      title: '二、我们如何收集和使用您的个人信息',
      paragraphs: [
        '（一）远程访问与设备验证',
        '1. 当您通过手机或外网浏览器访问面板时，本机闸机会在本地记录必要信息：访问 IP 地址、设备标识（客户端生成的匿名 devid）、User-Agent、访问时间与验证事件，用于设备信任、会话管理、异常识别与安全审计。',
        '2. 开启面板两步验证后，验证过程仅在本机完成动态码比对（TOTP），验证码不对第三方传输；验证通过的设备 30 天内免重复验证。',
        '3. 配对二维码与引导链接由本机生成，用于一次性/限时授权，不在服务端留存明文凭据。',
        '4. 官方托管模式下的心跳与用量上报：本机闸机会按使用周期向官方服务器上报在线状态心跳，内容包括在线秒数、在线设备明细（设备名/设备标识、IP、User-Agent）与最近请求元数据（见本节「日志与诊断」），用于在线状态展示、时长余额扣减、用量统计与设备管理；设备明细按环形方式仅保留最近 200 条。上述上报不包含对话内容与请求正文。自建模式下这些信息只留存在您自己的服务器。',
        '（二）官网账号与个人中心',
        '当您注册或登录官网账号（用于插件/App 配对、个人中心、消息中心与工单）时，我们会处理：',
        '1. 注册信息：邮箱地址、用户名；密码仅以 argon2id（或回退 scrypt）慢哈希保存，明文不落盘、不可还原。邮箱仅用于账号标识、登录与验证邮件投递。为防止临时邮箱批量注册，仅接受常见主流邮箱域名注册。',
        '2. 验证码邮件：注册、验证码登录、修改邮箱时发送 6 位数字验证码（10 分钟内有效，验证通过或过期即从内存删除）。邮件经由第三方邮件服务商投递，即仅就该目的向其提供收件邮箱地址与邮件内容。为便于排障，服务器保留发送统计（收件地址、主题与正文快照，环形保留最近 200 条），仅管理员可查看。',
        '3. 登录与令牌：登录成功后签发有效期 30 天的登录令牌；同时下发本机闸机与官方服务器之间的门禁凭据（linkSecret），该凭据仅用于您自己的闸机与服务器握手，不向他人展示。我们记录最后登录时间用于账号管理。',
        '4. 账号两步验证（可选）：开启后每次登录官网账号需输入验证器动态码或备用码。TOTP 密钥以 AES-256-GCM 加密存储于官方服务器；备用码仅存哈希值，明文只在生成时向您展示一次；验证失败次数与临时锁定时间一并记录。',
        '5. 签到与时长余额：每日签到记录（按月明细与累计聚合）和时长余额（分钟）保存在您的账号下，用于免费用量的公平分配。',
        '6. 消息中心：官方公告、面向您的定向消息及其已读状态保存在服务器，用于跨设备同步。',
        '7. 个人中心展示：登录设备列表、用量曲线与逐请求明细由您的账号数据聚合而来，您可随时查看自己的记录。',
        '（三）安全与风控',
        '1. 为识别异常登录、暴力破解、接口滥用与攻击，可能记录访问时间序列、请求来源、失败次数、IP 黑名单等，并采取限流、冻结、封禁等措施；限速计数保存在内存并定期清理。',
        '2. IP 封禁列表（IP、理由、期限、操作者）与审计日志（环形保留最近 2000 条：管理员操作、封禁、签到等管理事件）仅用于安全处置，不用于商业画像。对封禁或处置有异议的，可通过官方渠道申诉，我们核实后处理。',
        '（四）推送（可选）',
        '仅当您开启推送时，安全事件（设备连入、被踢、黑名单、2FA、配对）与系统消息才会经本机闸机转送至您的手机；关闭后不再处理。官网公告的弹窗提醒同样经由闸机心跳搭车下发，尊重您的推送总开关。',
        '（五）日志与诊断',
        '为排查故障，本机保存运行日志（不含密钥）；日志仅用于技术维护与服务优化。',
        '运行日志默认只留在本机。仅在您主动提交工单并确认附带时，日志才会按下一小节所述的方式上传。此外，官方托管模式下面板会按周期向官方服务器批量上报逐请求元数据（时间、方法、路径、状态码、耗时、来源 IP 与设备名，不含请求内容与对话正文），用于用量统计与故障排查；逐请求记录按环形方式仅保留最近 5 万条，个人中心可查看您自己的记录，管理员后台可见。',
        '（六）工单诊断日志（可选，需您明确确认）',
        '提交工单时，您可以自行选择是否随工单附带「诊断日志」，用于加快故障定位。该功能完全自愿：不附带同样可以提交工单，我们也会照常处理您的工单。',
        '诊断日志可能包含：运行环境（操作系统、浏览器/内核版本、屏幕分辨率、时区与语言、User-Agent）；客户端设备信息（仅 App：机型、系统版本、WebView 版本、网络类型、电量）；闸机与隧道状态（是否运行、本地与公网端口、隧道是否就绪、最近一次错误、延迟）；最近请求流水（时间、方法、路径、状态码与耗时）；前端错误与失败请求（仅错误与警告级别，不含您的输入内容）。',
        '上传前您会先看到完整内容：只有当您勾选「我已预览，确认不含敏感信息」并确认后，日志才会随工单上传。生成诊断日志时我们会自动对常见敏感字段打码，包括访问令牌（token / Bearer / JWT）、Cookie、签名（sig）、密码字段、IP 地址末两段、账号目录路径，以及除您本人邮箱之外的其他邮箱地址；您自行挑选上传的本地日志文件则原样上传、不做自动打码，请在确认前自行检查。',
        '您也可以选择不随工单上传，而将诊断包导出为本地文件自行保管；导出的文件保存在您选择的位置，不会自动上传。',
        '工单标题、正文、回复与附件（图片/日志）保存在官方服务器，仅用于工单排障，仅工单处理人员（管理员）可查看，不用于广告画像或商业用途；工单被删除时附件一并删除。您也可以随时要求删除相关日志，或按本政策「六、您的权利」行使权利。',
        '（七）数据大屏与 IP 归属地',
        '为在管理后台展示访问来源的宏观分布（国家/省市），官方服务器会将记录到的访问来源 IP 通过第三方 ip-api.com 查询大致归属地并做内存缓存。查询时该第三方会收到 IP 地址本身；结果仅用于统计展示，不与对话内容关联，不用于广告或商业画像。介意此处理的，可联系管理员要求排除。',
        '（八）App 版本更新检查',
        'App 检查更新时会向官网查询最新版本号、下载地址与更新说明；该接口公开且不携带账号信息。下载 APK 的安装行为本身不回传数据。',
        '（九）App 权限申请',
        '配套 App 仅在对应功能场景申请以下系统权限，用于实现相应功能，不用于其他目的：通知权限（可选，接收推送提醒，拒绝后收不到推送但不影响其余功能）；相机（扫描配对二维码）；文件访问（系统选择器，由您主动挑选本地日志文件随工单上传，自愿）；前台服务与开机自启（保持推送轮询与连接状态检查，可在系统设置关闭，推送随之失效）；电池优化豁免（可选，避免后台轮询被休眠中断）；网络（与您的电脑及官网通信的基础权限）。',
        '（十）原则声明',
        '我们不收集：真实姓名、身份证号、通讯录、短信、通话记录、精确地理位置、银行卡与支付流水；不以广告追踪或商业变现为目的收集个人信息。',
      ],
    },
    {
      title: '三、Cookie 与同类技术',
      paragraphs: [
        '我们可能通过 Cookie、localStorage 或同类技术保存必要状态：登录/会话状态（如 30 天 bc-gate 记忆 Cookie、官网登录令牌）、设置项、协议同意记录、本地配对状态。App 端的登录凭据以加密形式保存在系统应用私有存储中，不与其他应用共享。',
        '我们不会将 Cookie 用于本政策所述目的之外的用途，不用于跨站广告追踪或与真实身份信息不当关联。',
        '您可通过浏览器或系统设置拒绝、管理或删除 Cookie 与本地存储；停用后可能需要重新验证或重新同意协议，部分功能可能无法正常使用。',
      ],
    },
    {
      title: '四、共享、转移或公开',
      paragraphs: [
        '我们仅在合法、正当、必要范围内处理信息，不以商业广告投放或个性化推送为目的向第三方共享您的个人信息。',
        '为实现服务，可能向以下第三方提供有限信息：邮件服务商（发送注册/登录/改邮箱验证码时，提供收件邮箱地址与邮件内容）；ip-api.com（查询访问来源 IP 的大致归属地用于统计，仅提供 IP 地址本身）；云服务器、frps 隧道服务等基础设施，我们会评估其必要性并要求其采取保护措施。',
        '仅在下述情形下公开信息：依您要求并取得单独同意；依法或应执法机关要求；为保护您或他人生命财产安全所必需。',
        '对已匿名化且无法复原识别的信息，其共享/转移/公开不视为个人信息对外提供。',
      ],
    },
    {
      title: '五、存储与保护',
      paragraphs: [
        '（一）存储',
        '本地记录（会话、设备、事件、黑名单、日志）保存在您本机，随本机清理、卸载或删除而移除；官方托管模式下按前文所述上报的数据保存在官方服务器（容器数据目录，可选数据库），包括账号数据、消息中心、工单与附件、邮件发送统计、审计与封禁记录、逐请求日志（环形最近 5 万条）、设备明细（环形最近 200 条）、使用会话记录（环形最近 2000 条），其中账号数据保留至账号注销或删除，工单与消息保留至相应内容删除或管理员清理，封禁记录按封禁期限保存（最长 10 年）；自建模式下这些数据只留存在您自己的服务器。在线运行态数据仅在服务运行期间存在，不做商业用途。',
        '（二）保护',
        '1. 传输采用加密隧道（HTTPS/frp），签名采用 HMAC-SHA256 校验；密码以慢哈希（argon2id/scrypt）保存；账号两步验证密钥以 AES-256-GCM 加密；登录令牌带版本号，开启/关闭两步验证或管理员撤销后旧令牌立即失效。',
        '2. 密钥与凭据以受限文件权限存储，不写入公开仓库；最小化授权接触数据的人员并要求保密；发生安全事件时立即处置，并按法律法规要求及时通知受影响用户。',
        '3. 互联网并非绝对安全。请妥善保管设备、配对链接、Cookie、登录凭据与验证码/备用码；发现泄露请立即通过面板踢出会话、重置两步验证并轮换密钥，必要时联系管理员撤销全部登录。',
      ],
    },
    {
      title: '六、您的权利',
      paragraphs: [
        '（一）查阅与控制：您可在面板查看在线/历史设备，主动踢出设备、拉黑 IP、全部踢下线；在个人中心查看登录设备、用量与逐请求明细，修改邮箱、密码，开启/关闭两步验证，查看与清空消息。上述记录您可在界面内查看并自行复制保存；需要其他数据导出协助的，可通过官方渠道联系我们。',
        '（二）撤回同意：您可通过关闭推送、关闭两步验证、停止服务、卸载插件/App、清除本地数据等方式撤回授权；工单诊断日志与日志附件始终是「逐次勾选确认」后才会上传，不勾选即不附带，也可在工单中要求删除已上传的日志。',
        '（三）删除与注销：本地会话、事件与设备记录可随踢出与清理删除；清除站点数据即清除本地 Cookie 与设置。如需注销官网账号并删除服务器上的账号及关联数据，请通过官网或面板「关于」中的联系方式联系管理员，核实身份后办理（工单附件随工单删除）。',
        '（四）响应与例外：对重复、超范围或滥用权利的不合理请求，可依法拒绝或收取成本费用；法律另有规定的从其规定。',
      ],
    },
    {
      title: '七、未成年人保护',
      paragraphs: [
        LEGAL_AGE + '，不面向未成年人提供服务，我们不以面向未成年人的方式收集其信息。',
        '若您是未成年人，请立即停止使用；监护人发现未成年人使用的，可通过下方渠道联系我们，我们将在核实后删除相关数据或采取限制措施。',
      ],
    },
    {
      title: '八、修订和通知',
      paragraphs: [
        '我们可能根据产品更新及法律法规适时修改本政策，并在面板「关于」内公布；重大变更将显著提示。',
        '若您不同意变更，请停止使用；继续使用即视为知悉并接受更新后的政策。',
        '如需将信息用于本政策未载明的其他用途，或额外收集未提及的信息，将另行征得同意。',
      ],
    },
    {
      title: '九、如何联系我们',
      paragraphs: [
        '如您对本政策或个人信息保护有任何疑问、投诉或建议，可通过以下官方渠道与我们联系：官网 https://remote.ymzcc.com、官方 GitHub 仓库 github.com/Memorial-coder/dsh-remote-plugin、官方 QQ 群（通过官网或 App「关于」中的加群入口加入）。我们将在核验身份后于十五个工作日内回复。',
        '如对我们的回复不满意，可向消费者权益保护部门投诉或向有管辖权的人民法院提起诉讼。',
        '本隐私政策最终解释权归开发方所有（法律法规另有强制规定的除外）。',
      ],
    },
  ],
}

const css = `
.dshBrowserCtlLauncher {
  flex: none;
  box-sizing: border-box;
  width: calc(100% + 4px);
  height: 42px;
  margin: 4px -2px;
  padding: 0 10px 0 8px;
  gap: 8px;
  justify-content: flex-start;
  overflow: hidden;
  border-radius: 12px;
  white-space: nowrap;
}
.dshBrowserCtlLauncher[data-wide='false'] {
  width: 36px;
  height: 36px;
  margin: 8px 0 10px;
  justify-content: center;
  gap: 0;
  padding: 0;
  border-radius: 50%;
}
.dshBrowserCtlOverlay {
  position: fixed;
  inset: 0;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  pointer-events: auto;
}
.dshBrowserCtlOverlayMask {
  position: absolute;
  inset: 0;
  border: none;
  padding: 0;
  background: rgba(8, 10, 14, 0.45);
  cursor: default;
}
.dshBrowserCtlPanel {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 10px;
  width: min(880px, 94vw);
  max-height: min(680px, 90vh);
  box-sizing: border-box;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  touch-action: pan-y;
  overscroll-behavior: contain;
  padding: 18px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 16px;
  background: var(--dsw-alias-bg-layer-2, #1b1d22);
  color: var(--dsw-alias-label-primary, inherit);
  box-shadow: 0 16px 48px rgba(0,0,0,0.4);
}
/* 宽屏两栏(左:二维码/链接/操作  右:2FA/在线设备);窄屏自动堆叠 */
.dshBrowserCtlGrid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 12px;
  align-items: start;
}
.dshBrowserCtlCol {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
}
/* 左列:占满网格整行高度,垂直居中(扩展开启时与右列等高,不偏左上) */
.dshBrowserCtlColLeft {
  align-self: stretch;
  justify-content: center;
}
@media (max-width: 540px) {
  .dshBrowserCtlGrid { grid-template-columns: minmax(0, 1fr); gap: 8px; }
}
.dshBrowserCtlHeader {
  display: flex;
  align-items: center;
  gap: 10px;
}
.dshBrowserCtlHeader > div {
  flex: 1;
  min-width: 0;
}
.dshBrowserCtlHeader h1 {
  margin: 0;
  font-size: 15px;
  line-height: 22px;
  font-weight: 600;
}
.dshBrowserCtlHeader p {
  margin: 2px 0 0;
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlStatus {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlStatus::before {
  content: '';
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--dsw-alias-label-tertiary, #8b8f98);
  flex: none;
}
.dshBrowserCtlStatus[data-ok='true'] { color: var(--dsw-alias-state-success-primary, #34b371); }
.dshBrowserCtlStatus[data-ok='true']::before { background: var(--dsw-alias-state-success-primary, #34b371); }
.dshBrowserCtlStatus[data-ok='false'] { color: var(--dsw-alias-state-error-primary, #e5655c); }
.dshBrowserCtlStatus[data-ok='false']::before { background: var(--dsw-alias-state-error-primary, #e5655c); }
/* 异步操作(启动/停止隧道等)的转圈加载指示:跟随当前文字颜色,放进按钮/状态栏/占位框 */
.dshBrowserCtlSpinner {
  display: inline-block;
  width: 13px;
  height: 13px;
  border: 2px solid rgba(128,128,128,.35);
  border-top-color: currentColor;
  border-radius: 50%;
  animation: dshBrowserCtlSpin .7s linear infinite;
  flex: none;
  vertical-align: -2px;
}
/* 二维码占位框里的加载态:spinner + 提示文字一行居中 */
.dshBrowserCtlQrLoading {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  font-size: 13px;
  padding: 0 14px;
  text-align: center;
}
/* 顶部功能页签:连接 / 设备 / 2FA / 黑名单 / 日志,一次只显示一个功能区 */
.dshBrowserCtlTabs {
  display: flex;
  gap: 4px;
  padding: 3px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 10px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
  overflow-x: auto;
  flex: none;
}
.dshBrowserCtlTab {
  flex: 1;
  min-width: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  padding: 6px 6px;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  font-size: 12.5px;
  line-height: 17px;
  font-weight: 500;
  cursor: pointer;
  white-space: nowrap;
  transition: background .15s ease, color .15s ease;
}
.dshBrowserCtlTab:hover {
  background: var(--dsw-alias-bg-layer-2, rgba(255,255,255,0.06));
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlTab[data-active='true'] {
  background: var(--dsw-alias-bg-layer-3, #2b2e36);
  color: var(--dsw-alias-label-primary, inherit);
  box-shadow: 0 1px 3px rgba(0,0,0,0.35);
}
.dshBrowserCtlTab:disabled { opacity: .55; cursor: not-allowed; }
.dshBrowserCtlTabBody {
  display: flex;
  flex-direction: column;
  gap: 10px;
  min-height: 0;
  /* 内容区独立滚动：头部/页签钉住，内容超出面板高度时在此滚动（比整卡滚动更可靠） */
  flex: 1 1 auto;
  overflow-y: auto;
  overscroll-behavior: contain;
  -webkit-overflow-scrolling: touch;
}
/* flex 列的子元素默认 flex-shrink:1，在有界高度里会被压扁/裁切而不是溢出滚动。
   必须禁止收缩，子元素保持自然高度，由内容区自身滚动（实测：不加则卡片 body 被裁）。 */
.dshBrowserCtlTabBody > * {
  flex: 0 0 auto;
}
.dshBrowserCtlQrBox {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 12px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 12px;
  background: #fff;
  align-self: center;
}
.dshBrowserCtlQrBox img,
.dshBrowserCtlQrBox svg {
  width: 180px;
  height: 180px;
  display: block;
}
/* 卡片头部描述文字(图二:卡片下方一小行灰色说明) */
.dshBrowserCtlCardDesc {
  margin: 0;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
/* 卡片头部右侧状态文字 */
.dshBrowserCtlCardStat {
  margin-left: auto;
  font-size: 12px;
  font-weight: 500;
  white-space: nowrap;
}
/* 进行中操作:整卡半透明,提示"正在处理" */
.dshBrowserCtlCard[data-busy='true'] {
  opacity: 0.65;
  pointer-events: none;
}
.dshBrowserCtlUrlRow {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
  padding: 7px 10px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 9px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.04));
}
.dshBrowserCtlUrl {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
}
.dshBrowserCtlActions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  justify-content: center;
}
.dshBrowserCtlCard {
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 12px;
  overflow: hidden;
}
.dshBrowserCtlCardHead {
  display: flex;
  align-items: center;
  gap: 8px;
  width: 100%;
  box-sizing: border-box;
  padding: 10px 12px;
  border: none;
  background: transparent;
  color: inherit;
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  text-align: left;
}
.dshBrowserCtlCardHead:hover { background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.04)); }
.dshBrowserCtlCardArrow {
  margin-left: auto;
  display: inline-flex;
  transition: transform 0.15s ease;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlCardHead[data-open='true'] .dshBrowserCtlCardArrow { transform: rotate(90deg); }
.dshBrowserCtlCardBody {
  display: flex;
  flex-direction: column;
  gap: 8px;
  max-height: 0;
  opacity: 0;
  overflow: hidden;
  padding: 0 12px;
  transition: max-height 0.28s ease, opacity 0.22s ease, padding 0.25s ease;
}
.dshBrowserCtlCardBody[data-open='true'] {
  max-height: 450px;
  opacity: 1;
  padding: 2px 12px 12px;
}
/* 高内容卡片(二维码 + 设备/推送列表):450px 会把底部列表裁掉且无法滚动。
   放宽到 2400px,内容超高时由外层 TabBody 负责滚动,不再藏内容。 */
.dshBrowserCtlCardBodyTall[data-open='true'] {
  max-height: 2400px;
}
.dshBrowserCtlCardBodyRow {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
  line-height: 16px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  padding: 4px 0;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.04));
}
.dshBrowserCtlCardBodyRow:last-child { border-bottom: none; }
.dshBrowserCtlCardBodyRowT { margin-left: auto; font-size: 11px; color: var(--dsw-alias-label-tertiary, #8b8f98); white-space: nowrap; }
.dshBrowserCtlActions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  justify-content: center;
}
.dshBrowserCtlSecretRow {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 8px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 9px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.04));
}
.dshBrowserCtlSecret {
  flex: 1;
  min-width: 0;
  font-size: 11px;
  line-height: 16px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  font-family: ui-monospace, Consolas, Menlo, monospace;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.dshBrowserCtlTotpQr {
  display: flex;
  justify-content: center;
  padding: 8px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 10px;
  background: #fff;
  align-self: center;
}
.dshBrowserCtlTotpQr img,
.dshBrowserCtlTotpQr svg {
  width: 132px;
  height: 132px;
  display: block;
}
.dshBrowserCtlDevices {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.dshBrowserCtlDevice {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 8px;
  font-size: 12px;
  line-height: 17px;
}
.dshBrowserCtlDeviceInfo {
  flex: 1;
  min-width: 0;
}
.dshBrowserCtlDeviceIp {
  color: var(--dsw-alias-label-primary, inherit);
  font-weight: 500;
}
.dshBrowserCtlDeviceMeta {
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
/* 在线设备:独立可滚动区,始终可见(对齐 Claude 遥控的设备表) */
.dshBrowserCtlDevicesCard {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 10px 12px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 12px;
}

/* App 配对页签:已配对手机列表 */
.dshBrowserCtlPairedList {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 10px 12px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 12px;
}
.dshBrowserCtlPairedHead {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
}
.dshBrowserCtlPairedCount {
  margin-left: auto;
  font-weight: 500;
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlPairedRow {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 8px;
  font-size: 12px;
  line-height: 17px;
}
.dshBrowserCtlPairedInfo {
  flex: 1;
  min-width: 0;
}
.dshBrowserCtlPairedName {
  color: var(--dsw-alias-label-primary, inherit);
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.dshBrowserCtlPairedMeta {
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
/* 来源徽标:App=蓝字浅蓝底,网页=灰字描边(设备行/配对行通用) */
.dshBrowserCtlPairedNameRow {
  display: flex;
  align-items: center;
  min-width: 0;
}
.dshBrowserCtlPairedNameRow .dshBrowserCtlPairedName {
  flex: 0 1 auto;
  min-width: 0;
}
.dshBrowserCtlKindTag {
  display: inline-flex;
  align-items: center;
  flex: 0 0 auto;
  height: 16px;
  padding: 0 6px;
  margin-left: 6px;
  border-radius: 4px;
  font-size: 10px;
  line-height: 1;
  font-weight: 600;
}
.dshBrowserCtlKindTag[data-kind='app'] {
  color: #8ab4ff;
  border: 1px solid rgba(138, 180, 255, .4);
  background: rgba(138, 180, 255, .08);
}
.dshBrowserCtlKindTag[data-kind='web'] {
  color: var(--dsw-alias-label-tertiary, #9aa0a8);
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  background: transparent;
}
.dshBrowserCtlPairedEmpty {
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  padding: 4px 0;
}
.dshBrowserCtlPairedMsg {
  font-size: 12px;
  text-align: center;
  color: var(--dsw-alias-state-success-primary, #34b371);
  padding-top: 2px;
}
.dshBrowserCtlDevHead {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  font-weight: 600;
}
.dshBrowserCtlDevHead .dshBrowserCtlDevCount {
  margin-left: auto;
  font-weight: 500;
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlDevBody {
  display: flex;
  flex-direction: column;
  gap: 4px;
  max-height: 150px;
  overflow-y: auto;
}
.dshBrowserCtlDevTable {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 8px;
  font-size: 12px;
  line-height: 16px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
}
.dshBrowserCtlDevInfo {
  flex: 1;
  min-width: 0;
}
.dshBrowserCtlDevTop {
  display: flex;
  align-items: baseline;
  gap: 6px;
  min-width: 0;
}
.dshBrowserCtlDevPlatform {
  font-weight: 500;
  color: var(--dsw-alias-label-primary, inherit);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.dshBrowserCtlDevIp {
  color: var(--dsw-alias-label-secondary, #a6aab2);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.dshBrowserCtlDevSeen {
  margin-left: auto;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  font-size: 11px;
  white-space: nowrap;
  flex: none;
}
.dshBrowserCtlDevActions {
  display: flex;
  align-items: center;
  gap: 4px;
  flex: none;
}
/* 历史在线设备:现在在线 / 历史在线两组 */
.dshBrowserCtlHistLabel {
  font-size: 11px;
  font-weight: 600;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  margin: 6px 2px 3px;
}
.dshBrowserCtlHistGroup + .dshBrowserCtlHistGroup {
  margin-top: 2px;
}
.dshBrowserCtlHistDot {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlHistDot i {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  flex: none;
  background: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlHistDot[data-on="true"] {
  color: var(--dsw-alias-state-success-primary, #34b371);
}
.dshBrowserCtlHistDot[data-on="true"] i {
  background: var(--dsw-alias-state-success-primary, #34b371);
}
/* 黑名单 */
.dshBrowserCtlBanBody {
  display: flex;
  flex-direction: column;
  gap: 4px;
  max-height: 150px;
  overflow-y: auto;
}
.dshBrowserCtlBanRow {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 5px 6px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.04));
  border-radius: 7px;
  font-size: 11.5px;
  line-height: 16px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
}
.dshBrowserCtlBanInfo {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.dshBrowserCtlBanReason {
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  font-size: 10.5px;
}
.dshBrowserCtlDevEmpty {
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  font-size: 12px;
  line-height: 17px;
  padding: 2px 0;
}
/* 运行日志:可折叠,最多显示一屏,内部滚动 */
.dshBrowserCtlLogBody {
  max-height: 168px;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.dshBrowserCtlLogRow {
  display: flex;
  align-items: baseline;
  gap: 6px;
  font-size: 11.5px;
  line-height: 17px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  padding: 2px 0;
  border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.04));
}
.dshBrowserCtlLogRow:last-child { border-bottom: none; }
.dshBrowserCtlLogType {
  flex: none;
  font-size: 11px;
}
.dshBrowserCtlLogMsg {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.dshBrowserCtlLogTime {
  flex: none;
  font-size: 10.5px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  font-variant-numeric: tabular-nums;
}
/* footer 槽位锚点:renderSlot 默认给 display:contents(内联样式),
   多个 launchers 会变成横向 flex 兄弟互相叠压。强制纵向紧凑堆叠。 */
div[data-slot='sidebar.footer.action'] {
  display: flex !important;
  flex-direction: column;
  align-items: stretch;
  gap: 2px;
}
/* 关键:禁止子元素纵向拉伸,否则 desktop 端 footer 有空余高度时
   "用量统计"等条目会被拉成一大块(带滚动条的高盒子) */
div[data-slot='sidebar.footer.action'] > * {
  flex: none !important;
  margin: 2px -2px !important;
  width: calc(100% + 4px);
  align-self: stretch;
}
/* 头部小浮层:关于 / 配置(复用主浮层遮罩与面板,仅收窄宽度) */
.dshBrowserCtlPanelNested { width: min(460px, 94vw); }
.dshBrowserCtlPanelCfg { width: min(520px, 94vw); }
/* 关于面板 */
.dshBrowserCtlAboutApp {
  display: flex;
  align-items: baseline;
  gap: 8px;
}
.dshBrowserCtlAboutAppName {
  font-size: 16px;
  font-weight: 700;
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlAboutAppVersion {
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlAboutDesc {
  margin: 0;
  font-size: 12.5px;
  line-height: 19px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
}
.dshBrowserCtlAboutLinks {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 2px;
}
.dshBrowserCtlAboutLink {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 10px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
  color: var(--dsw-alias-label-primary, inherit);
  font-size: 13px;
  text-decoration: none;
  transition: background .15s ease;
}
.dshBrowserCtlAboutLink:hover {
  background: var(--dsw-alias-bg-layer-2, rgba(255,255,255,0.06));
}
.dshBrowserCtlAboutLink > span:first-child {
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
/* 顶栏「账号登录」按钮 */
.dshBrowserCtlHeaderAcct {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  max-width: 150px;
}
.dshBrowserCtlHeaderAcctLabel {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  max-width: 96px;
}
/* 未登录时启动远程的提示弹窗 */
.dshBrowserCtlLoginPrompt .dshBrowserCtlPanel {
  width: min(380px, 94vw);
}
.dshBrowserCtlLoginPromptBody {
  display: flex;
  flex-direction: column;
  gap: 14px;
  padding: 4px 2px 2px;
}
.dshBrowserCtlLoginPromptText {
  margin: 0;
  font-size: 13px;
  line-height: 1.7;
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlLoginPromptActions {
  display: flex;
  gap: 10px;
  justify-content: flex-end;
}
/* 检查更新:42px 三态按钮 + 版本对比 + 下载 + 更新说明 */
.dshBrowserCtlAboutUpdate {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 2px;
}
.dshBrowserCtlAboutUpdateBtn {
  height: 42px !important;
  margin: 4px 0 !important;
}
.dshBrowserCtlAboutUpdateRow {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
}
.dshBrowserCtlAboutUpdateVal {
  margin-left: auto;
  color: var(--dsw-alias-label-primary, inherit);
  font-weight: 500;
  font-variant-numeric: tabular-nums;
}
.dshBrowserCtlAboutUpdateFound {
  margin: 0;
  font-size: 13px;
  font-weight: 600;
  color: var(--dsw-alias-state-success-primary, #34b371);
}
.dshBrowserCtlAboutUpdateLatest {
  margin: 0;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
}
.dshBrowserCtlAboutUpdateNotes {
  margin: 0;
  padding-left: 18px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
}
.dshBrowserCtlAboutUpdateErr {
  margin: 0;
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-state-error-primary, #e5655c);
}
/* 「关于」面板底部:用户协议 / 隐私政策(下划线文字,点击展开) */
.dshBrowserCtlAboutLegal {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  margin-top: 2px;
  font-size: 12px;
  line-height: 17px;
}
.dshBrowserCtlAboutLegalLink {
  appearance: none;
  border: none;
  background: none;
  padding: 0;
  margin: 0;
  cursor: pointer;
  font: inherit;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  text-decoration: underline;
  text-underline-offset: 3px;
  text-decoration-color: var(--dsw-alias-border-l3, rgba(255,255,255,0.25));
  transition: color .15s ease, text-decoration-color .15s ease;
}
.dshBrowserCtlAboutLegalLink:hover,
.dshBrowserCtlAboutLegalLink:focus-visible {
  color: var(--dsw-alias-label-primary, inherit);
  text-decoration-color: currentColor;
  outline: none;
}
.dshBrowserCtlAboutLegalSep {
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  user-select: none;
}
/* 协议弹窗:正文独立滚动,不撑爆面板 */
.dshBrowserCtlLegalPanel { width: min(560px, 94vw); }
.dshBrowserCtlLegalBody {
  display: flex;
  flex-direction: column;
  gap: 12px;
  min-height: 0;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior: contain;
  padding-right: 4px;
  font-size: 12.5px;
  line-height: 20px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
}
/* flex 列滚动容器必须禁子元素收缩,否则内容会被压扁而不是滚动 */
.dshBrowserCtlLegalBody > * { flex: 0 0 auto; }
.dshBrowserCtlLegalSubtitle {
  margin: 0;
  font-size: 12px;
  line-height: 19px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlLegalSection {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.dshBrowserCtlLegalSection h3 {
  margin: 0;
  font-size: 13px;
  line-height: 19px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlLegalSection p {
  margin: 0;
}
.dshBrowserCtlLegalFooter {
  display: flex;
  justify-content: center;
}
.dshBrowserCtlLegalFooter .dshBrowserCtlAboutUpdateBtn {
  min-width: 160px;
}
/* 配置面板 */
.dshBrowserCtlCfgModes {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.dshBrowserCtlCfgMode {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 12px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 10px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
  cursor: pointer;
  font-size: 12.5px;
}
.dshBrowserCtlCfgMode input {
  margin-top: 3px;
  flex: none;
  accent-color: var(--dsw-alias-state-success-primary, #34b371);
}
.dshBrowserCtlCfgModeTitle {
  display: block;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlCfgModeDesc {
  display: block;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  margin-top: 2px;
}
.dshBrowserCtlCfgOfficialNote {
  margin: 0;
  padding: 10px 12px;
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  border: 1px dashed var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 10px;
}
.dshBrowserCtlCfgFields {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.dshBrowserCtlCfgField {
  display: flex;
  flex-direction: column;
  gap: 5px;
  font-size: 12px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
}
.dshBrowserCtlCfgFieldRow {
  display: flex;
  gap: 10px;
}
.dshBrowserCtlCfgFieldRow .dshBrowserCtlCfgField {
  flex: 1;
  min-width: 0;
}
.dshBrowserCtlCfgField input {
  height: 36px;
  padding: 0 10px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.04));
  color: var(--dsw-alias-label-primary, inherit);
  font-size: 13px;
  font-family: ui-monospace, Consolas, Menlo, monospace;
  box-sizing: border-box;
}
.dshBrowserCtlCfgField input:focus {
  outline: none;
  border-color: var(--dsw-alias-state-success-primary, #34b371);
}
/* 消息内容多行框:与 CfgField input 同族,但用正文字体、可换行 */
.dshBrowserCtlCfgField textarea {
  min-height: 64px;
  padding: 8px 10px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 8px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.04));
  color: var(--dsw-alias-label-primary, inherit);
  font-size: 13px;
  line-height: 18px;
  font-family: inherit;
  resize: none;
  box-sizing: border-box;
}
.dshBrowserCtlCfgField textarea:focus {
  outline: none;
  border-color: var(--dsw-alias-state-success-primary, #34b371);
}
.dshBrowserCtlCfgNote {
  margin: 0;
  font-size: 11.5px;
  line-height: 16px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlCfgErr {
  margin: 0;
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-state-error-primary, #e5655c);
}
.dshBrowserCtlCfgOauthCode {
  font-size: 24px;
  font-weight: 700;
  letter-spacing: 2px;
  font-family: ui-monospace, Consolas, Menlo, monospace;
  text-align: center;
  padding: 12px 8px;
  border: 1px dashed var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 10px;
  color: var(--dsw-alias-state-info-primary, #4da3ff);
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
}
.dshBrowserCtlCfgActions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}
/* 保存按钮三态(idle/loading/done),42px 高 + 上下 4px margin 与邻居对齐 */
.dshBrowserCtlCfgSave {
  height: 42px !important;
  margin: 4px 0 !important;
  min-width: 96px;
}
/* 推送页签:开关行 */
.dshBrowserCtlSwitchRow {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 10px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 10px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
}
.dshBrowserCtlSwitchLabel {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.dshBrowserCtlSwitchTitle {
  font-size: 12.5px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlSwitchHint {
  font-size: 11px;
  line-height: 15px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlSwitch {
  position: relative;
  flex: none;
  width: 42px;
  height: 24px;
  border-radius: 12px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  background: var(--dsw-alias-bg-layer-2, rgba(255,255,255,0.06));
  cursor: pointer;
  padding: 0;
  transition: background .15s ease, border-color .15s ease;
}
.dshBrowserCtlSwitch[data-on='true'] {
  background: var(--dsw-alias-state-success-primary, #34b371);
  border-color: transparent;
}
.dshBrowserCtlSwitch:disabled { opacity: .65; cursor: not-allowed; }
.dshBrowserCtlSwitchKnob {
  position: absolute;
  top: 3px;
  left: 3px;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: #fff;
  box-shadow: 0 1px 3px rgba(0,0,0,.3);
  transition: transform .15s ease;
}
.dshBrowserCtlSwitch[data-on='true'] .dshBrowserCtlSwitchKnob { transform: translateX(18px); }
/* loading 态:隐藏旋钮,轨道内转圈 */
.dshBrowserCtlSwitch[data-busy='true'] .dshBrowserCtlSwitchKnob { opacity: 0; }
.dshBrowserCtlSwitchBusy {
  position: absolute;
  top: 4px;
  left: 13px;
  width: 14px;
  height: 14px;
  border: 2px solid rgba(128,128,128,.35);
  border-top-color: var(--dsw-alias-label-secondary, #a6aab2);
  border-radius: 50%;
  animation: dshBrowserCtlSpin .7s linear infinite;
}
.dshBrowserCtlSwitch[data-on='true'] .dshBrowserCtlSwitchBusy {
  border-color: rgba(255,255,255,.35);
  border-top-color: #fff;
}
@keyframes dshBrowserCtlSpin { to { transform: rotate(360deg); } }
/* 测试推送按钮:42px 三态 */
.dshBrowserCtlPushBtn {
  height: 42px !important;
  margin: 4px 0 !important;
  min-width: 128px;
}
/* 手动推送消息编辑器 */
.dshBrowserCtlMsgCard {
  display: flex;
  flex-direction: column;
  gap: 8px;
  padding: 10px;
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 10px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
}
.dshBrowserCtlMsgHead {
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.dshBrowserCtlMsgTitle {
  font-size: 12.5px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlMsgHint {
  font-size: 11px;
  line-height: 15px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlMsgFoot {
  display: flex;
  align-items: center;
  gap: 8px;
}
.dshBrowserCtlMsgCount {
  flex: 1;
  text-align: right;
  font-size: 10.5px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlMsgSendBtn {
  height: 42px !important;
  min-width: 96px;
}
/* 最近推送列表 */
.dshBrowserCtlPushList {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.dshBrowserCtlPushRow {
  display: flex;
  gap: 8px;
  padding: 6px 8px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(255,255,255,0.04));
  border-radius: 8px;
  font-size: 12px;
  line-height: 16px;
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.02));
}
.dshBrowserCtlPushAside {
  flex: none;
  width: 78px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 2px;
}
.dshBrowserCtlPushType {
  font-size: 10.5px;
  font-weight: 600;
  color: var(--dsw-alias-label-secondary, #a6aab2);
}
.dshBrowserCtlPushTime {
  font-size: 10.5px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}
.dshBrowserCtlPushMain {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.dshBrowserCtlPushTitle {
  font-weight: 500;
  color: var(--dsw-alias-label-primary, inherit);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.dshBrowserCtlPushBody {
  color: var(--dsw-alias-label-secondary, #a6aab2);
  font-size: 11.5px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
/* ---------- 顶栏「通知中心」铃铛 + 下拉列表 ---------- */
.dshBrowserCtlAboutBtn { position: relative; display: inline-flex; }
.dshBrowserCtlBadgeDot {
  position: absolute;
  top: 3px;
  right: 3px;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: #ff4d4f;
  border: 1.5px solid var(--dsw-panel-bg, #fff);
  pointer-events: none;
}
.dshBrowserCtlMsgMask {
  position: fixed;
  inset: 0;
  z-index: 40;
  border: none;
  background: transparent;
  padding: 0;
  cursor: default;
}
.dshBrowserCtlMsgPop {
  position: absolute;
  top: calc(100% + 6px);
  right: 0;
  z-index: 41;
  width: min(340px, 88vw);
  max-height: min(420px, 70vh);
  display: flex;
  flex-direction: column;
  background: var(--dsw-alias-bg-layer-1, #1b1c20);
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 12px;
  box-shadow: 0 12px 32px rgba(0, 0, 0, 0.35);
  overflow: hidden;
}
.dshBrowserCtlMsgPopHead {
  flex: 0 0 auto;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 12px 8px;
  font-size: 13px;
  font-weight: 600;
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlMsgList {
  flex: 1 1 auto;
  min-height: 0;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
  overscroll-behavior: contain;
  display: flex;
  flex-direction: column;
  padding: 0 8px 8px;
}
/* flex 列滚动容器必须禁子元素收缩,否则内容被压扁而不是滚动(kb/10) */
.dshBrowserCtlMsgList > * { flex: 0 0 auto; }
.dshBrowserCtlMsgItem {
  padding: 10px 10px 9px;
  border-radius: 10px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.dshBrowserCtlMsgItem:hover { background: var(--dsw-alias-bg-layer-2, rgba(255,255,255,0.05)); }
.dshBrowserCtlMsgKind {
  font-size: 11px;
  line-height: 16px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  display: flex;
  align-items: center;
  gap: 6px;
}
.dshBrowserCtlMsgKindTag {
  padding: 0 6px;
  border-radius: 6px;
  font-size: 10.5px;
  line-height: 17px;
  color: var(--dsw-alias-state-success-primary, #34b371);
  background: rgba(52, 179, 113, 0.13);
}
.dshBrowserCtlMsgKindTag[data-personal='true'] {
  color: var(--dsw-alias-accent-primary, #4c8bf5);
  background: rgba(76, 139, 245, 0.13);
}
.dshBrowserCtlMsgTitle {
  font-size: 13px;
  line-height: 19px;
  font-weight: 400;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  display: flex;
  align-items: baseline;
  gap: 6px;
  word-break: break-word;
}
.dshBrowserCtlMsgItem[data-unread='true'] .dshBrowserCtlMsgTitle {
  font-weight: 600;
  color: var(--dsw-alias-label-primary, inherit);
}
.dshBrowserCtlMsgUnreadDot {
  flex: 0 0 auto;
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ff4d4f;
  transform: translateY(-1px);
}
.dshBrowserCtlMsgBody {
  margin: 0;
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-label-secondary, #a6aab2);
  white-space: pre-wrap;
  word-break: break-word;
}
.dshBrowserCtlMsgLink {
  font-size: 12px;
  line-height: 18px;
  color: var(--dsw-alias-accent-primary, #4c8bf5);
  text-decoration: none;
  cursor: pointer;
  align-self: flex-start;
}
.dshBrowserCtlMsgLink:hover { text-decoration: underline; }
.dshBrowserCtlMsgTime {
  font-size: 11px;
  line-height: 16px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
  font-variant-numeric: tabular-nums;
}
.dshBrowserCtlMsgEmpty {
  padding: 26px 12px;
  text-align: center;
  font-size: 12px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
.dshBrowserCtlMsgErr {
  margin: 0;
  padding: 0 12px 10px;
  font-size: 11.5px;
  line-height: 17px;
  color: var(--dsw-alias-state-error-primary, #e5655c);
}
.dshBrowserCtlMsgFoot {
  flex: 0 0 auto;
  padding: 8px 12px 10px;
  border-top: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  font-size: 11px;
  line-height: 16px;
  color: var(--dsw-alias-label-tertiary, #8b8f98);
}
/* ---------- 工单反馈弹窗(导出日志 → 选去向) ---------- */
.dshBrowserCtlPanelTicket { width: min(600px, 94vw); overflow: hidden; }
.dshBrowserCtlTicketBody {
  display: flex;
  flex-direction: column;
  gap: 10px;
  min-height: 0;
  flex: 1 1 auto;
  overflow-y: auto;
  overscroll-behavior: contain;
  -webkit-overflow-scrolling: touch;
  padding-right: 2px;
}
.dshBrowserCtlTicketBody > * { flex: 0 0 auto; }
.dshBrowserCtlTicketInput {
  width: 100%;
  box-sizing: border-box;
  padding: 8px 10px;
  font: inherit;
  font-size: 13px;
  line-height: 19px;
  color: var(--dsw-alias-label-primary, inherit);
  background: var(--dsw-alias-bg-layer-1, rgba(255,255,255,0.03));
  border: 1px solid var(--dsw-alias-border-l2, #2a2c33);
  border-radius: 9px;
  outline: none;
}
.dshBrowserCtlTicketInput:focus { border-color: var(--dsw-alias-state-success-primary, #34b371); }
.dshBrowserCtlTicketDest {
  display: flex; flex-direction: column; gap: 3px; width: 100%;
  margin: 0 0 8px; padding: 10px 12px; text-align: left;
  border-radius: 9px; border: 1px solid var(--dsw-alias-border-secondary, #3a3c41);
  background: transparent; color: inherit; font: inherit; cursor: pointer;
}
.dshBrowserCtlTicketDest:hover { background: var(--dsw-alias-bg-layer-2, rgba(255,255,255,0.06)); }
.dshBrowserCtlTicketDest:disabled { opacity: .5; cursor: default; }
.dshBrowserCtlTicketDestTitle { font-size: 13px; font-weight: 600; line-height: 18px; }
.dshBrowserCtlTicketDestDesc { font-size: 11.5px; line-height: 16px; color: var(--dsw-alias-label-tertiary, #8b8f98); }
`

function installStyles() {
  // 注意:client 半是热更新的 —— GUI 刷新时 JS 模块会重新执行,但 DOM 里的 <style> 不会重建。
  // 以前「已存在就直接 return」会让旧样式永远生效:新版本加的 CSS 全都不生效,表现为
  // 「弹窗里的元素没样式、挤在一起」,只有彻底重启 DSH 才恢复。
  // 所以这里必须每次把 textContent 对齐到当前 css,而不是跳过。
  let style = document.querySelector(`style[data-plugin="${STYLE_ID}"]`)
  if (style === null) {
    style = document.createElement('style')
    style.dataset.plugin = STYLE_ID
    document.head.append(style)
  }
  if (style.textContent !== css) style.textContent = css
  return () => {}
}

function CtlIcon({ size = 16 }) {
  return (
    <svg
      data-icon="browserctl"
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >
      <rect x="1.5" y="2.5" width="13" height="9" rx="1.5" stroke="currentColor" strokeWidth="1.25" />
      <path d="M5 14h6M8 11.5V14" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
      <path d="M4.5 6.5 6.5 8.5 4.5 10.5" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M8.5 10.5h3" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
    </svg>
  )
}

function useQr(open, reloadToken, uses) {
  const [data, setData] = useState(null)
  const [error, setError] = useState(null)
  const [expiresAt, setExpiresAt] = useState(0) // >0 表示一次性配对,按秒倒数
  const [status, setStatus] = useState(null)    // { uses, remaining } 配对码剩余次数
  const [retrying, setRetrying] = useState(false) // 隧道自愈中,正在自动重试(不需要用户再点一次)
  const [refreshTick, setRefreshTick] = useState(0)
  const usesRef = useRef(uses)
  usesRef.current = uses || 1
  // 生成配对码(闸机不可达时回退长期链接)
  // ★ 自动重试(2026-11-07):闸机在「frpc 正在启动 / 看门狗重拉 / claim 换端口」的头几秒里
  //   会回 503 + tunnel.pending=true。旧代码只请求一次,失败就把红字钉死在二维码位置,
  //   必须再点一次「开始控制」才能恢复 —— 这就是用户说的"还要再点一次"。
  //   现在遇到隧道类瞬时失败会自动轮询(1.5s × 30 ≈ 45s),隧道一就绪立刻出二维码;
  //   只有真正的硬失败(闸机没启动 / 路由没加载)才立刻放弃,把「开始控制」留给用户。
  useEffect(() => {
    if (!open) return
    let alive = true
    let timer = null
    let tries = 0
    const MAX_TRIES = 30
    setError(null)
    setRetrying(false)
    // 返回 { ok, retryable, error }:retryable = 隧道还没就绪但在自愈中,值得再等一会儿
    async function load() {
      try {
        const r = await fetch(API_P + '/browserctl/api/pair?uses=' + usesRef.current, { method: 'POST', cache: 'no-store' })
        const tx = await r.text()
        let j
        try { j = JSON.parse(tx) } catch { return { ok: false, retryable: false, error: '路由未加载(HTTP ' + r.status + ');请重启 DSH 后重试' } }
        if (!alive) return { ok: false, retryable: false }
        if (j.error) {
          // 带 tunnel 字段 = 被隧道门禁拦下的(隧道还没就绪 / 正在自愈):属于瞬时态
          return { ok: false, retryable: !!(j.tunnel && j.tunnel.ok === false), error: j.error }
        }
        setError(null)
        setData(j)
        setStatus({ uses: j.uses || 1, remaining: j.remaining || 1 })
        setExpiresAt(Date.now() + (j.ttl || 60) * 1000)
        return { ok: true }
      } catch (e1) {
        // 配对码端点不可用(老闸机/请求被拒)→ 回退长期链接
        try {
          const r2 = await fetch(API_P + '/browserctl/api/qr', { cache: 'no-store' })
          const tx2 = await r2.text()
          let j2
          try { j2 = JSON.parse(tx2) } catch { return { ok: false, retryable: false, error: '路由未加载(HTTP ' + r2.status + ');请重启 DSH 后重试' } }
          if (!alive) return { ok: false, retryable: false }
          if (j2.error) {
            return { ok: false, retryable: !!(j2.tunnel && j2.tunnel.ok === false), error: j2.error }
          }
          setError(null)
          setData(j2)
          setExpiresAt(0)
          return { ok: true }
        } catch (e2) {
          if (!alive) return { ok: false, retryable: false }
          return { ok: false, retryable: false, error: String((e2 && e2.message) || e2) }
        }
      }
    }
    async function loop() {
      const res = await load()
      if (!alive) return
      if (res.ok) { setRetrying(false); return }
      // 清掉旧二维码,让"开始控制"按钮出现,避免停止后只剩"停止控制"卡死
      setData(null)
      setError(res.error || null)
      if (!res.retryable || tries >= MAX_TRIES) {
        if (res.retryable) {
          setError((res.error || '') + '\n隧道仍在自愈中,等待超时;可再点一次「开始控制」重试。')
        }
        setRetrying(false)
        return
      }
      tries += 1
      setRetrying(true)
      timer = setTimeout(loop, 1500)
    }
    loop()
    return () => { alive = false; if (timer) clearTimeout(timer) }
  }, [open, reloadToken, refreshTick, uses])
  // 轮询配对码状态:检测到有人扫码(剩余次数减少)→ 用尽自动换码
  useEffect(() => {
    if (!open || !data || !data.grant) return
    let alive = true
    const tick = async () => {
      try {
        const r = await fetch(API_P + '/browserctl/api/pair-status?g=' + encodeURIComponent(data.grant), { cache: 'no-store' })
        const j = await r.json()
        if (!alive || !j || !j.ok) return
        const remaining = j.exists ? (j.remaining | 0) : 0
        setStatus({ uses: j.uses || data.uses || 1, remaining })
        if (remaining <= 0) setRefreshTick(x => x + 1) // 用尽(或一次性码被扫)→ 自动换新码
      } catch {}
    }
    tick()
    const id = setInterval(tick, 1500)
    return () => { alive = false; clearInterval(id) }
  }, [open, data])
  return { data, error, expiresAt, status, retrying, refresh: () => setRefreshTick(x => x + 1) }
}

function useCountdown(expiresAt) {
  const [left, setLeft] = useState(0)
  useEffect(() => {
    if (!expiresAt) { setLeft(0); return }
    const tick = () => setLeft(Math.max(0, Math.round((expiresAt - Date.now()) / 1000)))
    tick()
    const id = setInterval(tick, 1000)
    return () => clearInterval(id)
  }, [expiresAt])
  return left
}

/* ---------- 内联 SVG 图标（替代 emoji，保持跨平台一致渲染） ---------- */
const svgProps = { width: 14, height: 14, viewBox: '0 0 24 24', fill: 'none',
                   stroke: 'currentColor', strokeWidth: 1.8,
                   strokeLinecap: 'round', strokeLinejoin: 'round',
                   style: { verticalAlign: '-2px', marginRight: 3, flex: 'none' } }
const Svg = {
  phone: (
    <svg {...svgProps}><rect x="5.5" y="2.5" width="13" height="19" rx="2.5" /><path d="M10.5 18.5h3" /></svg>
  ),
  iphone: (
    <svg {...svgProps}><rect x="6" y="2.5" width="12" height="19" rx="2.8" /><path d="M9.8 4.8h4.4" /><path d="M10.8 18.6h2.4" /></svg>
  ),
  desk: (
    <svg {...svgProps}><rect x="2.5" y="3.5" width="19" height="13" rx="2" /><path d="M8.5 20.5h7M12 16.5v4" /></svg>
  ),
  lap: (
    <svg {...svgProps}><rect x="4" y="4.5" width="16" height="11" rx="1.8" /><path d="M2 19.5h20" /></svg>
  ),
  robot: (
    <svg {...svgProps}><rect x="4" y="7" width="16" height="12" rx="3" /><path d="M12 3v4" /><circle cx="9" cy="12.5" r="1.2" fill="currentColor" stroke="none" /><circle cx="15" cy="12.5" r="1.2" fill="currentColor" stroke="none" /><path d="M9.5 16h5" /></svg>
  ),
  peng: (
    <svg {...svgProps}><ellipse cx="12" cy="13" rx="7" ry="8.5" /><path d="M12 4.5v3" /><circle cx="9.2" cy="10.5" r="1.1" fill="currentColor" stroke="none" /><circle cx="14.8" cy="10.5" r="1.1" fill="currentColor" stroke="none" /><path d="M9.8 16.5q2.2 1.8 4.4 0" /></svg>
  ),
  wrench: (
    <svg {...svgProps}><path d="M14.5 6.5a4 4 0 1 0 4.9 4.9l-2.6-2.6 2-2z" /><path d="M11.8 9.2 3.5 17.5a2 2 0 0 0 2.8 2.8l8.3-8.3" /></svg>
  ),
  globe: (
    <svg {...svgProps}><circle cx="12" cy="12" r="9" /><path d="M3 12h18" /><path d="M12 3a14 14 0 0 1 3.6 9A14 14 0 0 1 12 21a14 14 0 0 1-3.6-9A14 14 0 0 1 12 3z" /></svg>
  ),
  shield: (
    <svg {...svgProps}><path d="M12 2.5 19.5 6v5.5c0 4.4-3.2 8.3-7.5 9.5-4.3-1.2-7.5-5.1-7.5-9.5V6z" /></svg>
  ),
  check: (
    <svg {...svgProps}><path d="m4.5 12.5 5 5 10-11" /></svg>
  ),
  ban: (
    <svg {...svgProps}><circle cx="12" cy="12" r="9" /><path d="m5.7 5.7 12.6 12.6" /></svg>
  ),
  lock: (
    <svg {...svgProps}><rect x="4.5" y="10.5" width="15" height="10.5" rx="2.5" /><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5" /><circle cx="12" cy="15.5" r="1.3" fill="currentColor" stroke="none" /></svg>
  ),
  clip: (
    <svg {...svgProps}><rect x="8" y="2.5" width="8" height="4" rx="1.5" /><path d="M16 4.5h1.5A2.5 2.5 0 0 1 20 7v13a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 20V7a2.5 2.5 0 0 1 2.5-2.5H8" /></svg>
  ),
  link: (
    <svg {...svgProps}><path d="M10 13a5 5 0 0 0 7.5.5l2.5-2.5a5 5 0 0 0-7-7L11.5 5.5" /><path d="M14 11a5 5 0 0 0-7.5-.5L4 13a5 5 0 0 0 7 7l1.5-1.5" /></svg>
  ),
  bell: (
    <svg {...svgProps}><path d="M18 8a6 6 0 0 0-12 0c0 7-3 8-3 8h18s-3-1-3-8" /><path d="M10 20a2.2 2.2 0 0 0 4 0" /></svg>
  ),
  // 头部「通知中心」铃铛:去掉通用图标外边距,与 info/gear 等头部小图标对齐
  bellHead: (
    <svg {...svgProps} style={{ ...svgProps.style, marginRight: 0 }}><path d="M18 8a6 6 0 0 0-12 0c0 7-3 8-3 8h18s-3-1-3-8" /><path d="M10 20a2.2 2.2 0 0 0 4 0" /></svg>
  ),
  // 头部小图标按钮专用:去掉通用图标的外边距,保持按钮内居中对齐
  info: (
    <svg {...svgProps} style={{ ...svgProps.style, marginRight: 0 }}><circle cx="12" cy="12" r="9" /><path d="M12 11v5.5" /><path d="M12 7.5h.01" /></svg>
  ),
  gear: (
    <svg {...svgProps} style={{ ...svgProps.style, marginRight: 0 }}><circle cx="12" cy="12" r="3" /><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.2 5.2l2.1 2.1M16.7 16.7l2.1 2.1M18.8 5.2l-2.1 2.1M7.3 16.7l-2.1 2.1" /></svg>
  ),
  download: (
    <svg {...svgProps}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
  ),
  person: (
    <svg {...svgProps} style={{ ...svgProps.style, marginRight: 0 }}><circle cx="12" cy="7.5" r="3.5" /><path d="M4.5 20a7.5 7.5 0 0 1 15 0" /></svg>
  ),
  ticket: (
    <svg {...svgProps} style={{ ...svgProps.style, marginRight: 0 }}><path d="M21 12a8 8 0 0 1-8 8H4.5l2.4-2.4A8 8 0 1 1 21 12z" /><path d="M8.5 10.5h7M8.5 13.5h4.5" /></svg>
  ),
  group: (
    <svg {...svgProps}><circle cx="9" cy="8.5" r="3.2" /><path d="M3.5 19.5a5.5 5.5 0 0 1 11 0" /><circle cx="16.5" cy="9.5" r="2.6" /><path d="M15.5 14.6a4.8 4.8 0 0 1 5 4.9" /></svg>
  ),
}

function fmtPlatform(ua) {
  const u = (ua || '').toLowerCase()
  if (!u) return 'unknown'
  if (/iphone|ipad|ios/.test(u)) return 'iOS'
  if (/android/.test(u)) return 'Android'
  if (/windows|win64|win32/.test(u)) return 'Windows'
  if (/macintosh|mac os/.test(u)) return 'macOS'
  if (/linux/.test(u)) return 'Linux'
  if (/curl|wget|python|httpclient|okhttp/.test(u)) return '脚本/API'
  return '浏览器'
}

function DevicesSection({ t, reloadToken, onRefresh, disabled }) {
  const [data, setData] = useState(null)
  const [open, setOpen] = useState(true) // 在线设备默认展开,方便直接看到/踢设备
  const [histOpen, setHistOpen] = useState(true) // 历史在线设备默认展开
  const [busy, setBusy] = useState(false)
  const [kicking, setKicking] = useState(null)
  const [kickMsg, setKickMsg] = useState('')
  const [banning, setBanning] = useState(null)
  const [banMsg, setBanMsg] = useState('')
  const [banOk, setBanOk] = useState(true)
  const anyBusy = disabled || busy
  useEffect(() => {
    let alive = true
    fetch(API_P + '/browserctl/api/totp', { cache: 'no-store' })
      .then(r => r.text().then(tx => { try { return JSON.parse(tx) } catch { return { error: 'HTTP ' + r.status } } }))
      .then(j => { if (alive) setData(j) })
      .catch(() => {})
    return () => { alive = false }
  }, [reloadToken])
  // 心跳保活已上移到面板根(BrowserCtlOverlay):任意页签打开都算在线,
  // 否则切到别的页签 10 分钟后设备会被误判为"离线"。
  useEffect(() => { if (!kickMsg) return; const id = setTimeout(() => setKickMsg(''), 2200); return () => clearTimeout(id) }, [kickMsg])
  useEffect(() => { if (!banMsg) return; const id = setTimeout(() => setBanMsg(''), 2200); return () => clearTimeout(id) }, [banMsg])

  const sessions = Array.isArray(data?.sessions) ? data.sessions : []
  const devices = Array.isArray(data?.devices) ? data.devices : []

  // "在线"判定以会话最近活动时间(ts)为准,不看 registry 的 online 标记 ——
  // 2FA 开启时会话会保留 30 天,标记在线只代表"受信任",不代表"此刻连着"。
  // 面板每 2 分钟心跳一次,超过 10 分钟没有活动就算离线。
  const nowSec = Date.now() / 1000
  const isFresh = ts => !!ts && (nowSec - ts) < 600
  const groupKey = (ip, name) => (ip || '') + '\u0000' + (name || '')
  const devByKey = new Map(devices.map(d => [d.key, d]))
  const onlineSessions = sessions.filter(s => isFresh(s.ts || s.since))
  const onlineGroups = new Set(onlineSessions.map(s => groupKey(s.ip, s.name)))
  // "在线 X 分钟"要算的是"这一轮连续在线了多久":
  // 会话的 since 是首次验证时间(2FA 下能保留 30 天),重启闸机后复用的老会话会显示成
  // "在线 19 小时";设备档案的 online_since 才是本次真正上线的时间点,优先用它。
  const onlineSince = (s) => {
    const d = devByKey.get(s.devid || s.dev)
    const since = (d && d.online_since) || 0
    return since > 0 ? since : s.since
  }
  // 历史设备:按 (ip, name) 聚合成一台(退出重扫不算新设备),并排除当前在线的那几台,
  // 避免和上面的"在线设备"卡片重复统计。
  const histMap = new Map()
  for (const d of devices) {
    const g = groupKey(d.ip, d.name)
    if (onlineGroups.has(g)) continue
    const prev = histMap.get(g)
    if (!prev || (d.last_seen || 0) > (prev.last_seen || 0)) histMap.set(g, d)
  }
  const historical = [...histMap.values()].sort((a, b) => (b.last_seen || 0) - (a.last_seen || 0))

  function fmtWhen(ts) {
    if (!ts) return ''
    const mins = Math.max(0, Math.round((Date.now() - ts * 1000) / 60000))
    if (mins < 1) return '刚刚'
    if (mins < 60) return mins + ' 分钟前'
    const hrs = Math.round(mins / 60)
    if (hrs < 24) return hrs + ' 小时前'
    return Math.round(hrs / 24) + ' 天前'
  }

  function fmtOnline(since) {
    if (!since) return ''
    const mins = Math.max(0, Math.round((Date.now() - since * 1000) / 60000))
    if (mins < 1) return '不到 1 分钟'
    if (mins < 60) return mins + ' 分钟'
    const hrs = Math.round(mins / 60)
    if (hrs < 24) return hrs + ' 小时'
    const days = Math.round(hrs / 24)
    return days + ' 天'
  }

  function fmtDuration(ms) {
    if (!ms || ms < 0) return ''
    const totalSec = Math.round(ms / 1000)
    const mins = Math.floor(totalSec / 60)
    const secs = totalSec % 60
    if (mins < 1) return secs + ' 秒'
    const hrs = Math.floor(mins / 60)
    const remainMins = mins % 60
    if (hrs < 1) return mins + ' 分钟'
    if (hrs < 24) return hrs + ' 小时 ' + remainMins + ' 分钟'
    const days = Math.floor(hrs / 24)
    return days + ' 天 ' + (hrs % 24) + ' 小时'
  }

  async function kick(dev) {
    setBusy(true)
    setKicking(dev || 'all')
    setKickMsg('')
    // 本地面板 DSH 会排空请求体 + 无 bc-gate cookie:优先闸机端点(公网面板可用),
    // 失败回退插件本地端点(参数走查询串,绕开 body 被排空的问题)。
    const body = JSON.stringify(dev ? { dev } : {})
    try {
      let r = await fetch(dev ? API_P + '/browserctl-gate/kick' : API_P + '/browserctl-gate/kick-all', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body,
      }).catch(() => null)
      if (!r || !r.ok) {
        const q = dev ? '?dev=' + encodeURIComponent(dev) : ''
        r = await fetch(API_P + '/browserctl/api/totp-kick' + q, { cache: 'no-store' }).catch(() => null)
      }
      if (r && r.ok) {
        setKickMsg(dev ? '已踢出设备' : '全部踢下线成功')
        // 乐观更新:立即从列表移除;等闸机落盘(约 1.5s)后再拉取同步,
        // 避免立即刷新把尚未处理完的设备又读回来(闪动)。
        setData(d => {
          if (!d) return d
          const list = Array.isArray(d.sessions) ? d.sessions : []
          return { ...d, sessions: dev ? list.filter(s => s.dev !== dev) : [] }
        })
        setTimeout(() => onRefresh(), 1500)
      } else {
        setKickMsg('踢出失败')
      }
    } catch {
      setKickMsg('网络错误')
    } finally {
      setBusy(false)
      setKicking(null)
    }
  }

  async function ban(dev, ip, name) {
    if (!dev && !ip) return
    setBusy(true)
    setBanning(dev || ip || '')
    setBanMsg('')
    try {
      // 与解禁同思路:闸机端点失败时回退插件本地端点(查询串参数)
      let r = await fetch(API_P + '/browserctl-gate/blacklist', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ dev, ip, name: name || '未知', reason: '管理员封禁' }),
      }).catch(() => null)
      if (!r || !r.ok) {
        const q = new URLSearchParams({ dev: dev || '', ip: ip || '', name: name || '未知', reason: '管理员封禁' }).toString()
        r = await fetch(API_P + '/browserctl/api/blacklist-add?' + q, { cache: 'no-store' }).catch(() => null)
      }
      const ok = !!(r && r.ok)
      setBanOk(ok)
      setBanMsg(ok ? ('已拉黑 ' + (name || ip || '')) : '拉黑失败')
      onRefresh()
    } catch {
      setBanOk(false)
      setBanMsg('网络错误')
    } finally {
      setBusy(false)
      setBanning(null)
    }
  }

  // 2FA 关闭时也要能看到在线设备(踢下线/拉黑照常可用)
  if (!data) return null

  return (
    <div className="dshBrowserCtlCard" data-busy={anyBusy ? 'true' : 'false'}>
      <button type="button" className="dshBrowserCtlCardHead" data-open={open ? 'true' : 'false'} onClick={() => setOpen(o => !o)}>
        {Svg.desk}
        <span>{t('devicesTitle')}</span>
        <span className="dshBrowserCtlCardStat" style={{ color: onlineSessions.length ? 'var(--dsw-alias-label-primary,inherit)' : 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>
          {t('devicesOnline').replace('{n}', onlineSessions.length)}
        </span>
        <span className="dshBrowserCtlCardArrow" aria-hidden="true">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M4 2.5 7.5 6 4 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>
      <div className="dshBrowserCtlCardBody" data-open={open}>
        <p className="dshBrowserCtlCardDesc">{t('noDevicesHint')}</p>
        {onlineSessions.length === 0 ? (
          <div className="dshBrowserCtlDevEmpty">{t('noOnlineDevices')}</div>
        ) : (
          <div className="dshBrowserCtlDevBody">
            {onlineSessions.map(s => (
              <div key={s.dev} className="dshBrowserCtlDevTable">
                <div className="dshBrowserCtlDevInfo">
                  <div className="dshBrowserCtlDevTop">
                    <span className="dshBrowserCtlDevPlatform" title={s.ua || ''}>{s.name || fmtPlatform(s.ua)}</span>
                    <KindTag item={s} />
                    <span className="dshBrowserCtlDevSeen">
                      <span className="dshBrowserCtlHistDot" data-on="true"><i />在线 {fmtOnline(onlineSince(s))}</span>
                    </span>
                  </div>
                  <div className="dshBrowserCtlDevIp">{s.ip || 'unknown'}{s.loc ? <span style={{ marginLeft: 6, opacity: 0.6, fontSize: 10 }}>{s.loc}</span> : null}</div>
                </div>
                <div className="dshBrowserCtlDevActions">
                  <Button variant="ghost" size="sm" disabled={anyBusy} onClick={() => kick(s.dev)}>
                    {kicking === s.dev ? '踢出中…' : t('deviceKick')}
                  </Button>
                  <Button variant="ghost" size="sm" disabled={anyBusy} onClick={() => ban(s.dev, s.ip, s.name)}>
                    {banning === s.dev ? '拉黑中…' : <>{Svg.shield} 拉黑</>}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
        {sessions.length > 0 && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: 8 }}>
            <Button variant="secondary" size="sm" disabled={anyBusy} onClick={() => kick(null)}>
              {kicking === 'all' ? '踢出中…' : t('totpKick')}
            </Button>
          </div>
        )}
        {kickMsg && (
          <div style={{ textAlign:'center', fontSize:12, color:'var(--dsw-alias-state-success-primary,#34b371)', padding:'4px 0 0' }}>
            {kickMsg}
          </div>
        )}
      </div>
      {/* ---- 历史在线设备:只列"当前不在线"的设备,按 (ip,name) 聚合成一台 ---- */}
      {devices.length > 0 && (
        <div className="dshBrowserCtlCard" data-busy={anyBusy ? 'true' : 'false'} style={{ marginTop: 2 }}>
          <button type="button" className="dshBrowserCtlCardHead" data-open={histOpen ? 'true' : 'false'} onClick={() => setHistOpen(o => !o)}>
            {Svg.desk}
            <span>{'历史在线设备'}</span>
            <span className="dshBrowserCtlCardStat" style={{ color: 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>
              共 {historical.length} 台
            </span>
            <span className="dshBrowserCtlCardArrow" aria-hidden="true">
              <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
                <path d="M4 2.5 7.5 6 4 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
          </button>
          <div className="dshBrowserCtlCardBody" data-open={histOpen}>
            {historical.length === 0 ? (
              <div className="dshBrowserCtlDevEmpty">{'暂无历史设备'}</div>
            ) : (
              <div className="dshBrowserCtlDevBody">
                {historical.map(d => (
                  <div key={d.key} className="dshBrowserCtlDevTable">
                    <div className="dshBrowserCtlDevInfo">
                      <div className="dshBrowserCtlDevTop">
                        <span className="dshBrowserCtlDevPlatform" title={d.ua || ''}>
                          {d.name || '未知设备'}
                        </span>
                        <KindTag item={d} />
                        <span className="dshBrowserCtlDevSeen">
                          <span className="dshBrowserCtlHistDot" data-on="false">
                            <i />{fmtAgoLong(d.last_seen) + '在线'}
                          </span>
                        </span>
                      </div>
                      <div className="dshBrowserCtlDevIp">
                        {d.ip || 'unknown'}
                        {d.loc ? <span style={{ marginLeft: 6, opacity: 0.6, fontSize: 10 }}>{d.loc}</span> : null}
                        <span style={{ color: 'var(--dsw-alias-label-tertiary,#8b8f98)', fontSize: 10 }}>
                          {' · 已连 ' + (d.times || 1) + ' 次'}
                          {(d.total_online || 0) > 0 ? ' · 累计 ' + fmtDuration(d.total_online * 1000) : ''}
                        </span>
                      </div>
                    </div>
                    <div className="dshBrowserCtlDevActions">
                      <Button variant="ghost" size="sm" disabled={anyBusy} onClick={() => ban(d.key, d.ip, d.name)}>
                        {banning === d.key ? '拉黑中…' : <>{Svg.shield} 拉黑</>}
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
      {banMsg && (
        <div style={{ textAlign:'center', fontSize:12, color: banOk ? 'var(--dsw-alias-state-success-primary,#34b371)' : 'var(--dsw-alias-state-warning-primary,#d08030)', padding:'2px 0 0' }}>
          {banMsg}
        </div>
      )}
    </div>
  )
}

const LOG_ICON = { verify: 'check', kick: 'ban', totp: 'lock', ban: 'shield' }

/* ---- 日志行图标(SVG 代替 emoji) ---- */
const LogIcon = ({ typ }) => {
  const props = { width: 14, height: 14, viewBox: '0 0 16 16', fill: 'none', style: { flex: 'none' } }
  const color = 'currentColor'
  switch (typ) {
    case 'verify':
      return <svg {...props}><circle cx="8" cy="8" r="7" stroke={color} strokeWidth="1.2"/><path d="M5 8.5l2 2 4-4.5" stroke={color} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
    case 'kick':
      return <svg {...props}><circle cx="8" cy="8" r="7" stroke={color} strokeWidth="1.2"/><path d="M5.5 5.5l5 5M10.5 5.5l-5 5" stroke={color} strokeWidth="1.3" strokeLinecap="round"/></svg>
    case 'totp':
      return <svg {...props}><rect x="4.5" y="7" width="7" height="6" rx="1.5" stroke={color} strokeWidth="1.2"/><path d="M5.5 7V4.5a2.5 2.5 0 015 0V7" stroke={color} strokeWidth="1.2" strokeLinecap="round"/><circle cx="8" cy="9.5" r="1" fill={color}/></svg>
    case 'ban':
      return <svg {...props}><path d="M3 5.5V8c0 2.8 2 5.2 5 6 3-.8 5-3.2 5-6V5.5L8 3l-5 2.5z" stroke={color} strokeWidth="1.2" strokeLinejoin="round"/><path d="M6 8.5l1.5 1.5 3-3" stroke={color} strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round"/></svg>
    default:
      return <span style={{ width: 14, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontSize: 10, color: 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>·</span>
  }
}

function fmtClock(ts) {
  if (!ts) return ''
  const d = new Date(ts * 1000)
  const p = n => String(n).padStart(2, '0')
  return p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds())
}

function LogCard({ t, reloadToken }) {
  const [open, setOpen] = useState(true) // 独立页签内默认展开
  const [events, setEvents] = useState(null)
  useEffect(() => {
    let alive = true
    // 优先闸机端点(公网面板同源可达,无需 DSH 重启);本机直开面板回退到插件 API。
    fetch(API_P + '/browserctl-gate/events', { cache: 'no-store' })
      .then(r => (r.ok ? r.json() : Promise.reject()))
      .then(j => { if (alive) setEvents(Array.isArray(j.events) ? j.events : []) })
      .catch(() => fetch(API_P + '/browserctl/api/totp', { cache: 'no-store' })
        .then(r => r.json())
        .then(j => { if (alive) setEvents(Array.isArray(j.events) ? j.events : []) })
        .catch(() => { if (alive) setEvents([]) }))
    return () => { alive = false }
  }, [reloadToken])
  const list = (events || []).slice().reverse()

  return (
    <div className="dshBrowserCtlCard">
      <button
        type="button"
        className="dshBrowserCtlCardHead"
        data-open={open ? 'true' : 'false'}
        onClick={() => setOpen(o => !o)}
      >
        {Svg.clip}
        <span>{t('logTitle')}</span>
        <span style={{ fontWeight: 500, fontSize: 12, color: 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>
          {list.length ? list.length + ' 条' : '暂无'}
        </span>
        <span className="dshBrowserCtlCardArrow" aria-hidden="true">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M4 2.5 7.5 6 4 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>
      <div className="dshBrowserCtlCardBody" data-open={open}>
        {list.length === 0 ? (
          <div className="dshBrowserCtlDevEmpty">{t('logEmpty')}</div>
        ) : (
          <div className="dshBrowserCtlLogBody">
            {list.map((e, i) => (
              <div key={i} className="dshBrowserCtlLogRow">
                <span className="dshBrowserCtlLogType"><LogIcon typ={e.typ} /></span>
                <span className="dshBrowserCtlLogMsg" title={e.msg || ''}>{e.msg || ''}</span>
                <span className="dshBrowserCtlLogTime">{fmtClock(e.t)}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function BlacklistCard({ t, reloadToken, disabled }) {
  const [open, setOpen] = useState(true) // 独立页签内默认展开
  const [data, setData] = useState(null)
  const [busy, setBusy] = useState(false)
  const anyBusy = disabled || busy
  useEffect(() => {
    let alive = true
    fetch(API_P + '/browserctl-gate/blacklist', { cache: 'no-store' })
      .then(r => r.ok ? r.json() : Promise.reject())
      .then(j => { if (alive) setData(Array.isArray(j.blacklist) ? j.blacklist : []) })
      .catch(() => { if (alive) setData([]) })
    return () => { alive = false }
  }, [reloadToken])
  const list = data || []
  async function unban(ip) {
    setBusy(true)
    try {
      // 本地面板无 bc-gate cookie + DSH 排空请求体:闸机端点失败时回退插件本地端点(查询串参数)
      let r = await fetch(API_P + '/browserctl-gate/blacklist/remove', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ ip }),
      }).catch(() => null)
      if (!r || !r.ok) {
        r = await fetch(API_P + '/browserctl/api/blacklist-remove?ip=' + encodeURIComponent(ip), { cache: 'no-store' })
          .catch(() => null)
      }
      if (r && r.ok) setData(d => (d || []).filter(x => x.ip !== ip))
    } catch {} finally {
      setBusy(false)
    }
  }
  return (
    <div className="dshBrowserCtlCard" data-busy={anyBusy ? 'true' : 'false'}>
      <button type="button" className="dshBrowserCtlCardHead" data-open={open ? 'true' : 'false'} onClick={() => setOpen(o => !o)}>
        {Svg.shield}
        <span>{t('banTitle')}</span>
        <span className="dshBrowserCtlCardStat" style={{ color: list.length ? 'var(--dsw-alias-label-primary,inherit)' : 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>
          {list.length ? list.length + ' 个' : '无'}
        </span>
        <span className="dshBrowserCtlCardArrow" aria-hidden="true">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M4 2.5 7.5 6 4 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>
      <div className="dshBrowserCtlCardBody" data-open={open}>
        {list.length === 0 ? (
          <div className="dshBrowserCtlDevEmpty">{t('banEmpty')}</div>
        ) : (
          <div className="dshBrowserCtlBanBody">
            {list.map((r, i) => (
              <div key={i} className="dshBrowserCtlBanRow">
                <span className="dshBrowserCtlBanInfo" title={r.ip}>
                  <span style={{ color: 'var(--dsw-alias-label-primary,inherit)', fontWeight: 500 }}>{r.name || 'unknown'}</span>
                  {' '}
                  <span style={{ color: 'var(--dsw-alias-label-secondary,#a6aab2)' }}>{r.ip}</span>
                  <span className="dshBrowserCtlBanReason">{r.reason ? ' · ' + r.reason : ''}</span>
                </span>
                <Button variant="ghost" size="sm" disabled={anyBusy} onClick={() => unban(r.ip)}>解禁</Button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

function AppPairCard({ t, reloadToken }) {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [copied, setCopied] = useState(false)
  const [open, setOpen] = useState(true)
  const [sessions, setSessions] = useState([])
  const [webCount, setWebCount] = useState(0)
  const [kicking, setKicking] = useState(null)
  const [kickMsg, setKickMsg] = useState('')

  async function load() {
    setLoading(true)
    try {
      const r = await fetch(API_P + '/browserctl/api/pair-long', { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) {
        setData({ error: (j && j.error) || ('HTTP ' + r.status) })
        return
      }
      if (!j.url || !j.svg) {
        setData({ error: (j && j.error) || '配对码响应不完整' })
        return
      }
      setData(j)
    } catch (e) {
      setData({ error: String((e && e.message) || e) })
    } finally {
      setLoading(false)
    }
  }

  // 轮询长期配对码状态:检测到有人扫码(剩余次数用尽) → 自动换新码
  useEffect(() => {
    if (!data || !data.grant) return
    let alive = true
    const tick = async () => {
      try {
        const r = await fetch(API_P + '/browserctl/api/pair-status?g=' + encodeURIComponent(data.grant), { cache: 'no-store' })
        const j = await r.json()
        if (!alive || !j || !j.ok) return
        const remaining = j.exists ? (j.remaining | 0) : 0
        if (remaining <= 0) load()
      } catch {}
    }
    tick()
    const id = setInterval(tick, 1500)
    return () => { alive = false; clearInterval(id) }
  }, [data])

  async function loadDevices() {
    try {
      const r = await fetch(API_P + '/browserctl/api/totp', { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      const list = Array.isArray(j?.sessions) ? j.sessions : []
      // 只显示通过「App 配对」绑定的手机（kind=app;旧会话没 kind,按名字兜底）
      setSessions(list.filter(s => kindOf(s) === 'app'))
      setWebCount(list.filter(s => kindOf(s) === 'web').length)
    } catch {}
  }

  async function kick(dev) {
    setKicking(dev)
    setKickMsg('')
    const body = JSON.stringify({ dev })
    try {
      // 两个请求都必须带超时:否则闸机偶尔持锁做 SSH 清理时第一个 fetch 会
      // 长时间挂起,按钮永远停在「解除中…」(实测踩过,没有 finally 重置的机会)。
      // 用 AbortController 而非 AbortSignal.timeout(后者 Chrome 103+ 才有,兼容旧 WebView)
      const ac1 = new AbortController()
      const t1 = setTimeout(() => ac1.abort(), 8000)
      let r = await fetch(API_P + '/browserctl-gate/kick', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body,
        signal: ac1.signal,
      }).catch(() => null).finally(() => clearTimeout(t1))
      if (!r || !r.ok) {
        const ac2 = new AbortController()
        const t2 = setTimeout(() => ac2.abort(), 8000)
        r = await fetch(API_P + '/browserctl/api/totp-kick?dev=' + encodeURIComponent(dev), { cache: 'no-store', signal: ac2.signal }).catch(() => null).finally(() => clearTimeout(t2))
      }
      if (r && r.ok) {
        setKickMsg('已解除该设备配对')
        setSessions(list => list.filter(s => s.dev !== dev))
        // 同步踢出(闸机直调)返回时 sessions.json 已更新,1.2s 后重拉只是确认;
        // 若闸机此刻不可达走了 state 队列兜底,巡检 ≤2s 才消费,2.5s 再补拉一次
        setTimeout(loadDevices, 1200)
        setTimeout(loadDevices, 2500)
      } else {
        setKickMsg('解除失败')
      }
    } catch {
      setKickMsg('网络错误')
    } finally {
      setKicking(null)
    }
  }

  useEffect(() => { load(); loadDevices() }, [reloadToken])
  useEffect(() => {
    if (!copied) return
    const id = setTimeout(() => setCopied(false), 1600)
    return () => clearTimeout(id)
  }, [copied])
  useEffect(() => {
    if (!kickMsg) return
    const id = setTimeout(() => setKickMsg(''), 2400)
    return () => clearTimeout(id)
  }, [kickMsg])

  const ok = !!(data && data.url && !data.error)

  return (
    <div className="dshBrowserCtlCard">
      <button
        type="button"
        className="dshBrowserCtlCardHead"
        data-open={open ? 'true' : 'false'}
        onClick={() => setOpen(o => !o)}
      >
        {Svg.phone}
        <span>{t('tabApp')}</span>
        <span style={{
          fontWeight: 500,
          fontSize: 12,
          color: ok ? 'var(--dsw-alias-state-success-primary,#34b371)' : 'var(--dsw-alias-label-tertiary,#8b8f98)',
        }}>{ok ? t('appReady') : (loading ? '…' : t('appNoQr'))}</span>
        <span className="dshBrowserCtlCardArrow" aria-hidden="true">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M4 2.5 7.5 6 4 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>
      <div className="dshBrowserCtlCardBody dshBrowserCtlCardBodyTall" data-open={open}>
        <p className="dshBrowserCtlCardDesc">{t('appSubtitle')}</p>
        {ok ? (
          <>
            <div className="dshBrowserCtlQrBox">
              {data.svg
                ? <img alt={t('appQrAlt')} src={'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(data.svg)} />
                : <span style={{ color: '#666', fontSize: 12 }}>{t('appNoQr')}</span>}
            </div>
            <p className="dshBrowserCtlCardDesc" style={{ textAlign: 'center' }}>{t('appOnceHint')}</p>
            <div className="dshBrowserCtlUrlRow">
              <div className="dshBrowserCtlUrl" title={data.url}>{data.url}</div>
              <Button variant="ghost" size="sm" onClick={() => {
                navigator.clipboard?.writeText(data.url).then(() => setCopied(true)).catch(() => {})
              }}>{copied ? t('copied') : t('appCopyLink')}</Button>
            </div>
          </>
        ) : (
          <div className="dshBrowserCtlQrBox" style={{ height: 120 }}>
            <span style={{ color: '#666', fontSize: 12, padding: '0 14px', textAlign: 'center' }}>
              {loading ? t('appLoading') : (data && data.error) || t('appNoQr')}
            </span>
          </div>
        )}
        <div className="dshBrowserCtlActions">
          <Button variant="secondary" size="sm" disabled={loading} onClick={load}>
            {loading ? '…' : t('appRefresh')}
          </Button>
        </div>

        {/* 已配对手机列表 */}
        <div className="dshBrowserCtlPairedList">
          <div className="dshBrowserCtlPairedHead">
            <span>已配对的手机</span>
            <span className="dshBrowserCtlPairedCount">{sessions.length}</span>
          </div>
          {sessions.length === 0 ? (
            <div className="dshBrowserCtlPairedEmpty">还没有手机通过扫码配对</div>
          ) : (
            sessions.map(s => (
              <div key={s.dev} className="dshBrowserCtlPairedRow">
                <div className="dshBrowserCtlPairedInfo">
                  <div className="dshBrowserCtlPairedNameRow">
                    <div className="dshBrowserCtlPairedName">{s.name || '手机 App'}</div>
                    <KindTag item={s} />
                  </div>
                  <div className="dshBrowserCtlPairedMeta">
                    {s.ip || 'unknown'}{s.ts ? ' · ' + fmtAgo(s.ts) : ''}
                  </div>
                </div>
                <Button variant="ghost" size="sm" disabled={kicking === s.dev}
                  onClick={() => kick(s.dev)}>
                  {kicking === s.dev ? '解除中…' : '解除配对'}
                </Button>
              </div>
            ))
          )}
          {webCount > 0 && (
            <div className="dshBrowserCtlPairedEmpty" style={{ paddingTop: 2 }}>
              另有 {webCount} 个网页登录会话（浏览器打开，未长期绑定），在「设备」页签查看/踢出
            </div>
          )}
          {kickMsg && (
            <div className="dshBrowserCtlPairedMsg">{kickMsg}</div>
          )}
        </div>
      </div>
    </div>
  )
}

function fmtAgo(ts) {
  if (!ts) return ''
  const mins = Math.max(0, Math.round((Date.now() - ts * 1000) / 60000))
  if (mins < 1) return '刚刚'
  if (mins < 60) return mins + ' 分钟前'
  const hrs = Math.round(mins / 60)
  if (hrs < 24) return hrs + ' 小时前'
  return Math.round(hrs / 24) + ' 天前'
}

/* 设备来源:kind=app(扫码长期配对的 App)/web(浏览器登录)。旧会话/旧设备档案没有
   kind 字段,按名字兜底(App 的名字都以 DSH Remote 开头或叫 手机 App)。 */
function kindOf(s) {
  if (s && s.kind) return s.kind
  const n = (s && s.name) || ''
  return n.indexOf('DSH Remote') === 0 || n === '手机 App' ? 'app' : 'web'
}

function KindTag({ item }) {
  const k = kindOf(item)
  return <span className="dshBrowserCtlKindTag" data-kind={k}>{k === 'app' ? 'App' : '网页'}</span>
}

// 更细的"多久以前":小时带分钟("2 小时 5 分钟前"),给历史设备行用,
// 拼上"在线"就是"2 小时 5 分钟前在线"。
function fmtAgoLong(ts) {
  if (!ts) return ''
  const mins = Math.max(0, Math.round((Date.now() - ts * 1000) / 60000))
  if (mins < 1) return '刚刚'
  if (mins < 60) return mins + ' 分钟前'
  const hrs = Math.floor(mins / 60)
  const rem = mins % 60
  if (hrs < 24) return hrs + ' 小时' + (rem ? ' ' + rem + ' 分钟' : '') + '前'
  const days = Math.floor(hrs / 24)
  const remH = hrs % 24
  return days + ' 天' + (remH ? ' ' + remH + ' 小时' : '') + '前'
}

/* ---------- 「iOS / 无 App 设备」引导链接卡片 ---------- */
function fmtLinkExpiry(exp) {
  const d = new Date(Number(exp) * 1000)
  if (!exp || Number.isNaN(d.getTime())) return ''
  const p = n => String(n).padStart(2, '0')
  return `${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`
}

function IosGuideCard({ t, reloadToken }) {
  const [open, setOpen] = useState(false) // 默认收起，让「连接」页签初始不溢出；头部常驻并显示生成状态
  const [ttl, setTtl] = useState(86400)
  const [uses, setUses] = useState(1) // 1=一次性(默认)；0=不限次数
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [copied, setCopied] = useState(false)
  const [bump, setBump] = useState(0)

  useEffect(() => {
    let alive = true
    setLoading(true)
    setError('')
    fetch(API_P + '/browserctl/api/link?ttl=' + ttl + '&uses=' + uses, { cache: 'no-store' })
      .then(async r => {
        const j = await r.json().catch(() => ({}))
        if (!alive) return
        if (!r.ok || !j.url) {
          setData(null)
          setError(j.error || ('HTTP ' + r.status))
          return
        }
        setData(j)
      })
      .catch(e => {
        if (!alive) return
        setData(null)
        setError(String((e && e.message) || e))
      })
      .finally(() => { if (alive) setLoading(false) })
    return () => { alive = false }
  }, [ttl, uses, bump, reloadToken])

  useEffect(() => {
    if (!copied) return
    const id = setTimeout(() => setCopied(false), 1600)
    return () => clearTimeout(id)
  }, [copied])

  const ok = !!(data && data.url)
  const expText = ok ? fmtLinkExpiry(data.exp) : ''
  return (
    <div className="dshBrowserCtlCard" style={{ marginTop: 10 }}>
      <button
        type="button"
        className="dshBrowserCtlCardHead"
        data-open={open ? 'true' : 'false'}
        onClick={() => setOpen(o => !o)}
      >
        {Svg.iphone}
        <span>{t('linkTitle')}</span>
        <span className="dshBrowserCtlCardStat" style={{
          color: ok ? 'var(--dsw-alias-state-success-primary,#34b371)' : 'var(--dsw-alias-label-tertiary,#8b8f98)',
        }}>{ok ? t('linkReady') : (loading ? '…' : '')}</span>
        <span className="dshBrowserCtlCardArrow" aria-hidden="true">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M4 2.5 7.5 6 4 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>
      <div className="dshBrowserCtlCardBody dshBrowserCtlCardBodyTall" data-open={open}>
        <p className="dshBrowserCtlCardDesc">{t('linkSubtitle')}</p>
        {ok && data.svg && (
          <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6, marginTop: 10 }}>
            <div className="dshBrowserCtlQrBox">
              <img
                alt={t('linkQrAlt')}
                style={{ width: 200, height: 200 }}
                src={'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(data.svg)}
              />
            </div>
            <p className="dshBrowserCtlCardDesc" style={{ margin: 0, textAlign: 'center' }}>{t('linkScanHint')}</p>
          </div>
        )}
        <div className="dshBrowserCtlUrlRow" style={{ marginTop: 8, gap: 8, flexWrap: 'wrap' }}>
          <span style={{ fontSize: 12, color: 'var(--dsw-alias-label-tertiary,#8b8f98)', whiteSpace: 'nowrap' }}>{t('linkTtlLabel')}</span>
          <select
            value={ttl}
            disabled={loading}
            onChange={e => setTtl(parseInt(e.target.value, 10) || 86400)}
            style={{
              fontSize: 12, padding: '2px 4px', borderRadius: 6,
              border: '1px solid rgba(128,128,128,.35)', background: 'transparent',
              color: 'inherit', flex: 'none',
            }}
          >
            <option value={3600}>{t('linkTtl1h')}</option>
            <option value={86400}>{t('linkTtl24h')}</option>
            <option value={604800}>{t('linkTtl7d')}</option>
          </select>
          <span style={{ fontSize: 12, color: 'var(--dsw-alias-label-tertiary,#8b8f98)', whiteSpace: 'nowrap' }}>{t('linkUsesLabel')}</span>
          <select
            value={uses}
            disabled={loading}
            onChange={e => setUses(parseInt(e.target.value, 10) || 0)}
            style={{
              fontSize: 12, padding: '2px 4px', borderRadius: 6,
              border: '1px solid rgba(128,128,128,.35)', background: 'transparent',
              color: 'inherit', flex: 'none',
            }}
          >
            <option value={1}>{t('linkUses1')}</option>
            <option value={3}>{t('linkUses3')}</option>
            <option value={5}>{t('linkUses5')}</option>
            <option value={0}>{t('linkUsesUnlimited')}</option>
          </select>
          <Button variant="secondary" size="sm" disabled={loading} onClick={() => setBump(x => x + 1)}>
            {loading ? t('linkGenerating') : (ok ? t('linkRegenerate') : t('linkGenerate'))}
          </Button>
        </div>
        {ok && (
          <>
            <div className="dshBrowserCtlUrlRow" style={{ marginTop: 6 }}>
              <div className="dshBrowserCtlUrl" title={data.url}>{data.url}</div>
              <Button variant="ghost" size="sm" onClick={() => {
                navigator.clipboard?.writeText(data.url).then(() => setCopied(true)).catch(() => {})
              }}>{copied ? t('linkCopied') : t('linkCopy')}</Button>
            </div>
            {expText && (
              <p className="dshBrowserCtlCardDesc" style={{ marginTop: 4 }}>
                {t('linkExpires').replace('{t}', expText)}
                {' · '}
                {data.uses ? t('linkUsesSuffix').replace('{n}', String(data.uses)) : t('linkUsesUnlimited')}
              </p>
            )}
          </>
        )}
        {error && (
          <p className="dshBrowserCtlCardDesc" style={{ marginTop: 4, color: 'var(--dsw-alias-state-error-primary,#e5655c)' }}>
            {error}
          </p>
        )}
        <p className="dshBrowserCtlCardDesc" style={{ marginTop: 10, fontWeight: 500, color: 'var(--dsw-alias-label-secondary,#a6aab2)' }}>{t('linkStepsTitle')}</p>
        <ol style={{ margin: '4px 0 0', paddingLeft: 18, fontSize: 11.5, lineHeight: '18px', color: 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>
          <li>{t('linkStep1')}</li>
          <li>{t('linkStep2')}</li>
          <li>{t('linkStep3')}</li>
          <li>{t('linkStep4')}</li>
        </ol>
        <p className="dshBrowserCtlCardDesc" style={{ marginTop: 8 }}>{t('linkNote')}</p>
      </div>
    </div>
  )
}

function TotpCard({ t, reloadToken, onRefresh, disabled }) {
  const [data, setData] = useState(null)
  const [busy, setBusy] = useState(false)
  const [open, setOpen] = useState(true) // 独立页签内默认展开
  const anyBusy = disabled || busy
  useEffect(() => {
    let alive = true
    fetch(API_P + '/browserctl/api/totp', { cache: 'no-store' })
      .then(r => r.text().then(tx => { try { return JSON.parse(tx) } catch { return { error: 'HTTP ' + r.status } } }))
      .then(j => { if (alive) setData(j) })
      .catch(() => {})
    return () => { alive = false }
  }, [reloadToken])

  async function toggle(enable, reset) {
    setBusy(true)
    try {
      // DSH webServer 排空请求体:参数走查询串
      const q = new URLSearchParams({ enabled: enable ? '1' : '0', reset: reset ? '1' : '0' }).toString()
      const r = await fetch(API_P + '/browserctl/api/totp-toggle?' + q, { cache: 'no-store' })
      let j = {}
      try { j = await r.json() } catch { j = { ok: false, error: 'HTTP ' + r.status } }
      if (j.ok) onRefresh()
      else if (j.error) setData(d => ({ ...d, error: j.error }))
    } finally {
      setBusy(false)
    }
  }

  async function kick(dev) {
    setBusy(true)
    try {
      const q = dev ? '?dev=' + encodeURIComponent(dev) : ''
      await fetch(API_P + '/browserctl/api/totp-kick' + q, { cache: 'no-store' })
      onRefresh()
    } finally {
      setBusy(false)
    }
  }

  function fmtWhen(ts) {
    if (!ts) return ''
    const mins = Math.max(0, Math.round((Date.now() - ts * 1000) / 60000))
    if (mins < 1) return '刚刚'
    if (mins < 60) return mins + ' 分钟前'
    const hrs = Math.round(mins / 60)
    if (hrs < 24) return hrs + ' 小时前'
    return Math.round(hrs / 24) + ' 天前'
  }

  const sessions = Array.isArray(data?.sessions) ? data.sessions : []
  const status = data
    ? (data.enabled
        ? (sessions.length > 0 ? t('totpOn') + ' · ' + t('devicesOnline').replace('{n}', sessions.length) : t('totpOn'))
        : t('totpOff'))
    : '…'
  const [copiedSecret, setCopiedSecret] = useState(false)
  useEffect(() => {
    if (!copiedSecret) return
    const id = setTimeout(() => setCopiedSecret(false), 1600)
    return () => clearTimeout(id)
  }, [copiedSecret])

  return (
    <div className="dshBrowserCtlCard">
      <button
        type="button"
        className="dshBrowserCtlCardHead"
        data-open={open ? 'true' : 'false'}
        onClick={() => setOpen(o => !o)}
      >
        {Svg.lock}
        <span>{t('totpTitle')}</span>
        <span style={{
          fontWeight: 500,
          fontSize: 12,
          color: data?.enabled ? 'var(--dsw-alias-state-success-primary,#34b371)' : 'var(--dsw-alias-label-tertiary,#8b8f98)',
        }}>{status}</span>
        <span className="dshBrowserCtlCardArrow" aria-hidden="true">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M4 2.5 7.5 6 4 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>
      <div className="dshBrowserCtlCardBody" data-open={open}>
        <p style={{ margin: 0, fontSize: 12, lineHeight: '17px', color: 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>
          {t('totpHintShort')}
        </p>
        {data?.enabled && data?.svg && (
          <div className="dshBrowserCtlTotpQr">
            <img alt={t('totpBind')} src={'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(data.svg)} />
          </div>
        )}
        {data?.secret && (
          <div className="dshBrowserCtlSecretRow">
            <div className="dshBrowserCtlSecret" title={data.secret}>{t('totpSecretLabel')}: {data.secret}</div>
            <Button variant="ghost" size="sm" onClick={() => {
              navigator.clipboard?.writeText(data.secret).then(() => setCopiedSecret(true)).catch(() => {})
            }}>{copiedSecret ? t('copied') : t('copySecret')}</Button>
          </div>
        )}
        <div className="dshBrowserCtlActions">
          {data?.enabled ? (
            <>
              <Button variant="secondary" size="sm" disabled={anyBusy} onClick={() => toggle(false)}>{t('totpDisable')}</Button>
              <Button variant="secondary" size="sm" disabled={anyBusy} onClick={() => toggle(true, true)}>{t('totpReset')}</Button>
            </>
          ) : (
            <Button variant="primary" size="sm" disabled={anyBusy || !data} onClick={() => toggle(true)}>{t('totpEnable')}</Button>
          )}
        </div>
      </div>
    </div>
  )
}

/* ---------- 「推送」页签:接收手机推送 + 系统安全事件 + 测试推送 + 最近推送 ---------- */
const PUSH_KIND = { test: 'Test', verify: 'Verify', kick: 'Kick', ban: 'Ban', totp: 'Totp', pair: 'Pair', join: 'Join', dev: 'Dev', msg: 'Msg', announce: 'Announce' }

function pushKindLabel(t, kind) {
  const key = PUSH_KIND[kind]
  return key ? t('pushKind' + key) : (kind || '')
}

function fmtPushTime(ts) {
  if (!ts) return ''
  const d = new Date(ts * 1000)
  const p = n => String(n).padStart(2, '0')
  return p(d.getMonth() + 1) + '-' + p(d.getDate()) + ' ' + p(d.getHours()) + ':' + p(d.getMinutes())
}

function PushCard({ t, reloadToken }) {
  const [cfg, setCfg] = useState(null)          // { enabled, system, since }
  const [cfgErr, setCfgErr] = useState('')
  const [busy, setBusy] = useState('')          // '' | 'enabled' | 'system' —— 开关 loading 态
  const [testState, setTestState] = useState('idle') // idle | loading
  const [msgTitle, setMsgTitle] = useState('')  // 手动推送:标题(可选)
  const [msgBody, setMsgBody] = useState('')    // 手动推送:内容
  const [msgState, setMsgState] = useState('idle') // idle | loading
  const [toast, setToast] = useState(null)      // { text, ok } | null,2.2s 自动消失
  const [items, setItems] = useState(null)
  const [polling, setPolling] = useState(false)
  const [open, setOpen] = useState(true)

  const enabled = !!(cfg && cfg.enabled)
  const system = !!(cfg && cfg.system)

  // 读 push-config 初始化开关
  useEffect(() => {
    let alive = true
    fetch(API_P + '/browserctl-gate/push-config', { cache: 'no-store' })
      .then(r => r.text().then(tx => { try { return JSON.parse(tx) } catch { return { error: 'HTTP ' + r.status } } }))
      .then(j => {
        if (!alive) return
        if (j && j.ok) setCfg({ enabled: !!j.enabled, system: !!j.system, since: j.since || 0 })
        else setCfgErr((j && j.error) || t('pushPollFailed'))
      })
      .catch(() => { if (alive) setCfgErr(t('pushPollFailed')) })
    return () => { alive = false }
  }, [reloadToken])

  // 成功/失败 toast 2.2s 自动消失
  useEffect(() => {
    if (!toast) return
    const id = setTimeout(() => setToast(null), 2200)
    return () => clearTimeout(id)
  }, [toast])

  // 切换开关:参数走查询串(POST push-config?enabled=1|0&system=1|0)
  async function toggle(which) {
    if (busy || !cfg) return
    setBusy(which)
    setToast(null)
    const next = which === 'enabled' ? !enabled : !system
    try {
      const q = new URLSearchParams({
        enabled: which === 'enabled' ? (next ? '1' : '0') : (enabled ? '1' : '0'),
        system: which === 'system' ? (next ? '1' : '0') : (system ? '1' : '0'),
      }).toString()
      const r = await fetch(API_P + '/browserctl-gate/push-config?' + q, { method: 'POST', cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (r.ok && j.ok) {
        setCfg(c => ({ ...(c || {}), enabled: !!j.enabled, system: !!j.system, since: j.since || (c && c.since) || 0 }))
      } else {
        setToast({ text: (j && j.error) || t('pushSaveFailed'), ok: false })
      }
    } catch {
      setToast({ text: t('pushSaveFailed'), ok: false })
    } finally {
      setBusy('')
    }
  }

  // 发送测试推送(loopback)
  async function sendTest() {
    if (testState === 'loading' || !enabled || busy) return
    setTestState('loading')
    setToast(null)
    try {
      const q = new URLSearchParams({ kind: 'test', title: t('pushTestTitle'), body: t('pushTestBody') }).toString()
      const r = await fetch(API_P + '/browserctl-gate/notify?' + q, { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      const ok = !!(r.ok && j && j.ok)
      setToast({ text: ok ? t('pushTestOk') : ((j && j.error) || t('pushTestFail')), ok })
      if (ok) loadPoll()   // 主动刷新「最近推送」:否则按钮看起来没生效,用户会连点刷屏(kb/10)
    } catch {
      setToast({ text: t('pushTestFail'), ok: false })
    } finally {
      setTestState('idle')
    }
  }

  // 手动推送一条消息:入队后手机 App 与本机 Windows 通知中心(win_push)都会弹出(kind=msg)
  async function sendMessage() {
    if (msgState === 'loading') return
    const body = msgBody.trim()
    if (!body) return
    setMsgState('loading')
    setToast(null)
    try {
      if (!enabled) {
        // 总开关没开就不打闸机,直接给明确提示(反馈要可懂,不留死按钮)
        setToast({ text: t('pushSendOff'), ok: false })
        return
      }
      const q = new URLSearchParams({ kind: 'msg', title: msgTitle.trim().slice(0, 120), body: body.slice(0, 500) }).toString()
      const r = await fetch(API_P + '/browserctl-gate/notify?' + q, { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      const ok = !!(r.ok && j && j.ok && j.pushed !== false)
      if (ok) {
        setMsgTitle('')
        setMsgBody('')
        loadPoll()   // 主动刷新「最近推送」:否则按钮看起来没生效,用户会连点刷屏(kb/10)
      }
      setToast({ text: ok ? t('pushSendOk') : (j && j.pushed === false ? t('pushSendOff') : ((j && j.error) || t('pushSendFail'))), ok })
    } catch {
      setToast({ text: t('pushSendFail'), ok: false })
    } finally {
      setMsgState('idle')
    }
  }

  // 拉最近推送(newest first,取 ~10 条)
  async function loadPoll() {
    if (polling) return
    setPolling(true)
    try {
      const r = await fetch(API_P + '/browserctl-gate/push-poll?last=0', { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (r.ok && j.ok) {
        setItems(Array.isArray(j.items) ? j.items.slice(0, 10) : [])
        setCfg(c => ({ ...(c || {}), enabled: !!j.enabled, since: j.since || (c && c.since) || 0 }))
        setCfgErr('')   // 闸机已应答:清掉可能过期的红字(如短暂 401/离线后恢复)
      }
    } catch {
      // 闸机未运行等场景:保持列表不变
    } finally {
      setPolling(false)
    }
  }

  useEffect(() => { loadPoll() }, [reloadToken])

  const list = items || []
  const switchDisabled = !!busy || !cfg

  return (
    <div className="dshBrowserCtlCard">
      <button type="button" className="dshBrowserCtlCardHead" data-open={open ? 'true' : 'false'} onClick={() => setOpen(o => !o)}>
        {Svg.bell}
        <span>{t('pushTitle')}</span>
        <span className="dshBrowserCtlCardStat" style={{ color: enabled ? 'var(--dsw-alias-state-success-primary,#34b371)' : 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>
          {cfg ? (enabled ? t('pushOn') : t('pushOff')) : '…'}
        </span>
        <span className="dshBrowserCtlCardArrow" aria-hidden="true">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
            <path d="M4 2.5 7.5 6 4 9.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>
      <div className="dshBrowserCtlCardBody dshBrowserCtlCardBodyTall" data-open={open}>
        <p className="dshBrowserCtlCardDesc">{t('pushDesc')}</p>
        <div className="dshBrowserCtlSwitchRow">
          <span className="dshBrowserCtlSwitchLabel">
            <span className="dshBrowserCtlSwitchTitle">{t('pushEnabledLabel')}</span>
            <span className="dshBrowserCtlSwitchHint">{t('pushEnabledHint')}</span>
          </span>
          <button
            type="button"
            role="switch"
            aria-checked={enabled}
            aria-label={t('pushEnabledLabel')}
            className="dshBrowserCtlSwitch"
            data-on={enabled ? 'true' : 'false'}
            data-busy={busy === 'enabled' ? 'true' : 'false'}
            disabled={switchDisabled}
            onClick={() => toggle('enabled')}
          >
            <span className="dshBrowserCtlSwitchKnob" aria-hidden="true" />
            {busy === 'enabled' && <span className="dshBrowserCtlSwitchBusy" aria-hidden="true" />}
          </button>
        </div>
        <div className="dshBrowserCtlSwitchRow">
          <span className="dshBrowserCtlSwitchLabel">
            <span className="dshBrowserCtlSwitchTitle">{t('pushSystemLabel')}</span>
            <span className="dshBrowserCtlSwitchHint">{t('pushSystemHint')}</span>
          </span>
          <button
            type="button"
            role="switch"
            aria-checked={system}
            aria-label={t('pushSystemLabel')}
            className="dshBrowserCtlSwitch"
            data-on={system ? 'true' : 'false'}
            data-busy={busy === 'system' ? 'true' : 'false'}
            disabled={switchDisabled}
            onClick={() => toggle('system')}
          >
            <span className="dshBrowserCtlSwitchKnob" aria-hidden="true" />
            {busy === 'system' && <span className="dshBrowserCtlSwitchBusy" aria-hidden="true" />}
          </button>
        </div>
        {cfgErr && <p className="dshBrowserCtlCardDesc" style={{ color: 'var(--dsw-alias-state-error-primary,#e5655c)' }}>{cfgErr}</p>}
        {/* 手动发送消息:手机 App + 本机通知中心都会弹出 */}
        <div className="dshBrowserCtlMsgCard">
          <div className="dshBrowserCtlMsgHead">
            <span className="dshBrowserCtlMsgTitle">{t('pushComposerTitle')}</span>
            <span className="dshBrowserCtlMsgHint">{t('pushComposerHint')}</span>
          </div>
          <label className="dshBrowserCtlCfgField">
            <span>{t('pushMsgTitleLabel')}</span>
            <input
              value={msgTitle}
              onChange={e => setMsgTitle(e.target.value)}
              placeholder={t('pushMsgTitlePh')}
              maxLength={120}
              spellCheck={false}
              disabled={msgState === 'loading'}
            />
          </label>
          <label className="dshBrowserCtlCfgField">
            <span>{t('pushMsgBodyLabel')}</span>
            <textarea
              value={msgBody}
              onChange={e => setMsgBody(e.target.value)}
              placeholder={t('pushMsgBodyPh')}
              maxLength={500}
              rows={3}
              disabled={msgState === 'loading'}
            />
          </label>
          <div className="dshBrowserCtlMsgFoot">
            <span className="dshBrowserCtlMsgCount">{msgBody.length}/500</span>
            <Button
              variant="primary"
              size="sm"
              className="dshBrowserCtlMsgSendBtn"
              disabled={msgState === 'loading' || !msgBody.trim()}
              onClick={sendMessage}
            >
              {msgState === 'loading' ? t('pushSending') : t('pushSend')}
            </Button>
          </div>
        </div>
        <div className="dshBrowserCtlActions">
          <Button
            variant="secondary"
            size="sm"
            className="dshBrowserCtlPushBtn"
            disabled={testState === 'loading' || !enabled || !!busy}
            onClick={sendTest}
          >
            {testState === 'loading' ? t('pushTesting') : t('pushTest')}
          </Button>
        </div>
        {toast && (
          <div className="dshBrowserCtlPairedMsg" style={{ color: toast.ok ? 'var(--dsw-alias-state-success-primary,#34b371)' : 'var(--dsw-alias-state-error-primary,#e5655c)' }}>
            {toast.text}
          </div>
        )}
        {/* 最近推送列表 */}
        <div className="dshBrowserCtlPairedList">
          <div className="dshBrowserCtlPairedHead">
            <span>{t('pushRecent')}</span>
            <Button variant="ghost" size="sm" disabled={polling} onClick={loadPoll}>
              {polling ? t('pushRefreshing') : t('pushRefresh')}
            </Button>
          </div>
          {list.length === 0 ? (
            <div className="dshBrowserCtlPairedEmpty">{t('pushEmpty')}</div>
          ) : (
            <div className="dshBrowserCtlPushList">
              {list.map(it => (
                <div key={it.id || (it.t + (it.title || ''))} className="dshBrowserCtlPushRow">
                  <span className="dshBrowserCtlPushAside">
                    <span className="dshBrowserCtlPushType">{pushKindLabel(t, it.kind)}</span>
                    <span className="dshBrowserCtlPushTime">{fmtPushTime(it.t)}</span>
                  </span>
                  <span className="dshBrowserCtlPushMain">
                    <span className="dshBrowserCtlPushTitle" title={it.title || ''}>{it.title || ''}</span>
                    {it.body ? <span className="dshBrowserCtlPushBody" title={it.body}>{it.body}</span> : null}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

/* ---------- 「关于」面板:应用名 + 版本 + 简介 + 外部链接 + 检查更新 ---------- */
function AboutPanel({ t, onClose }) {
  // 检查更新按钮三态: idle(检查更新) / loading(检查中…) / done(重新检查)
  const [checkState, setCheckState] = useState('idle')
  const [checkResult, setCheckResult] = useState(null)
  // 用户协议 / 隐私政策弹窗: null=不显示, 否则为要展示的文档对象
  const [legalDoc, setLegalDoc] = useState(null)
  const links = [
    { key: 'website', href: ABOUT_LINKS.website, icon: 'globe', label: t('aboutWebsite') },
    { key: 'github', href: ABOUT_LINKS.github, icon: 'link', label: t('aboutGithub') },
    { key: 'app', href: ABOUT_LINKS.app, icon: 'phone', label: t('aboutApp') },
    { key: 'qq', href: ABOUT_LINKS.qq, icon: 'group', label: t('aboutQq') },
  ]
  async function checkUpdate() {
    if (checkState === 'loading') return
    setCheckState('loading')
    setCheckResult(null)
    try {
      const r = await fetch(API_P + '/browserctl/api/update-check', { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      setCheckResult(j)
    } catch (e) {
      setCheckResult({ ok: false, error: String((e && e.message) || e) })
    } finally {
      setCheckState('done')
    }
  }
  const err = checkResult && !checkResult.ok ? (checkResult.error || t('updateFailed')) : ''
  const hasUpdate = !!(checkResult && checkResult.ok && checkResult.hasUpdate)
  const upToDate = !!(checkResult && checkResult.ok && !checkResult.hasUpdate)
  const notes = hasUpdate && Array.isArray(checkResult.notes) ? checkResult.notes : []
  const downloadUrl = hasUpdate ? (checkResult.downloadUrl || ABOUT_LINKS.app) : ABOUT_LINKS.app
  return (
    <div className="dshBrowserCtlOverlay" role="dialog" aria-modal="true" aria-label={t('about')}>
      <button className="dshBrowserCtlOverlayMask" type="button" aria-label={t('close')} onClick={onClose} />
      <section className="dshBrowserCtlPanel dshBrowserCtlPanelNested">
        <header className="dshBrowserCtlHeader">
          <div>
            <h1>{t('about')}</h1>
          </div>
          <Tooltip label={t('close')}>
            <Button variant="ghost" size="sm" aria-label={t('close')} icon={<IconCloseOutlineRegular />} onClick={onClose} />
          </Tooltip>
        </header>
        <div className="dshBrowserCtlAboutApp">
          <span className="dshBrowserCtlAboutAppName">{t('tab')}</span>
          <span className="dshBrowserCtlAboutAppVersion">v{VERSION}</span>
        </div>
        <p className="dshBrowserCtlAboutDesc">{t('aboutDesc')}</p>
        <div className="dshBrowserCtlAboutLinks">
          {links.map(l => (
            <a key={l.key} className="dshBrowserCtlAboutLink" href={l.href} target="_blank" rel="noopener noreferrer">
              <span aria-hidden="true">{Svg[l.icon]}</span>
              <span>{l.label}</span>
            </a>
          ))}
        </div>
        <div className="dshBrowserCtlAboutLegal">
          <button type="button" className="dshBrowserCtlAboutLegalLink" onClick={() => setLegalDoc(LEGAL_TERMS)}>
            {t('legalTerms')}
          </button>
          <span className="dshBrowserCtlAboutLegalSep" aria-hidden="true">·</span>
          <button type="button" className="dshBrowserCtlAboutLegalLink" onClick={() => setLegalDoc(LEGAL_PRIVACY)}>
            {t('legalPrivacy')}
          </button>
        </div>
        <div className="dshBrowserCtlAboutUpdate">
          <Button
            variant="secondary"
            size="sm"
            className="dshBrowserCtlAboutUpdateBtn"
            disabled={checkState === 'loading'}
            onClick={checkUpdate}
          >
            {checkState === 'loading' ? t('updateChecking') : checkState === 'done' ? t('updateRecheck') : t('updateCheck')}
          </Button>
          {checkState === 'done' && (
            <>
              {(hasUpdate || upToDate) && (
                <>
                  <div className="dshBrowserCtlAboutUpdateRow">
                    <span>{t('updateCur')}</span>
                    <span className="dshBrowserCtlAboutUpdateVal">v{checkResult.current}</span>
                  </div>
                  <div className="dshBrowserCtlAboutUpdateRow">
                    <span>{t('updateLst')}</span>
                    <span className="dshBrowserCtlAboutUpdateVal">v{checkResult.latest}</span>
                  </div>
                </>
              )}
              {hasUpdate && (
                <>
                  <p className="dshBrowserCtlAboutUpdateFound">{t('updateFound').replace('{v}', checkResult.latest)}</p>
                  <div className="dshBrowserCtlUrlRow">
                    <div className="dshBrowserCtlUrl" title={downloadUrl}>{downloadUrl}</div>
                    <Button variant="secondary" size="sm" onClick={() => window.open(downloadUrl, '_blank')}>
                      {t('updateDownload')}
                    </Button>
                  </div>
                  {notes.length > 0 && (
                    <>
                      <p className="dshBrowserCtlCardDesc">{t('updateNotesTitle')}</p>
                      <ul className="dshBrowserCtlAboutUpdateNotes">
                        {notes.map((n, i) => <li key={i}>{n}</li>)}
                      </ul>
                    </>
                  )}
                </>
              )}
              {upToDate && <p className="dshBrowserCtlAboutUpdateLatest">{t('updateUpToDate')}</p>}
              {err && <p className="dshBrowserCtlAboutUpdateErr">{err}</p>}
            </>
          )}
        </div>
        {legalDoc && <LegalDialog t={t} doc={legalDoc} onClose={() => setLegalDoc(null)} />}
      </section>
    </div>
  )
}

/* ---------- 用户协议 / 隐私政策弹窗(「关于」面板内点击展开) ---------- */
function LegalDialog({ t, doc, onClose }) {
  if (!doc) return null
  return (
    <div className="dshBrowserCtlOverlay" role="dialog" aria-modal="true" aria-label={doc.title}>
      <button className="dshBrowserCtlOverlayMask" type="button" aria-label={t('close')} onClick={onClose} />
      <section className="dshBrowserCtlPanel dshBrowserCtlPanelNested dshBrowserCtlLegalPanel">
        <header className="dshBrowserCtlHeader">
          <div>
            <h1>{doc.title}</h1>
            <p>{t('legalMeta').replace('{d}', LEGAL_EFFECTIVE).replace('{v}', LEGAL_VERSION)}</p>
          </div>
          <Tooltip label={t('close')}>
            <Button variant="ghost" size="sm" aria-label={t('close')} icon={<IconCloseOutlineRegular />} onClick={onClose} />
          </Tooltip>
        </header>
        <div className="dshBrowserCtlLegalBody">
          <p className="dshBrowserCtlLegalSubtitle">{doc.subtitle}</p>
          {doc.sections.map(sec => (
            <section className="dshBrowserCtlLegalSection" key={sec.title}>
              <h3>{sec.title}</h3>
              {sec.paragraphs.map((p, i) => <p key={i}>{p}</p>)}
            </section>
          ))}
        </div>
        <div className="dshBrowserCtlLegalFooter">
          <Button variant="secondary" size="sm" className="dshBrowserCtlAboutUpdateBtn" onClick={onClose}>
            {t('legalAck')}
          </Button>
        </div>
      </section>
    </div>
  )
}

/* ---------- 「配置」面板:服务器选择(官方 / 自建) ---------- */
function ConfigPanel({ t, onClose, onSaved }) {
  const [cfg, setCfg] = useState(null)
  const [mode, setMode] = useState('official')
  const [host, setHost] = useState('')
  const [port, setPort] = useState('17000')
  const [remotePort, setRemotePort] = useState('')
  const [token, setToken] = useState('')
  const [saving, setSaving] = useState('') // '' | 'loading' | 'done'
  const [err, setErr] = useState('')

  // 打开时读取当前配置(官方模式不返回 host/port/token,仅 selfhost 返回)
  useEffect(() => {
    let alive = true
    fetch(API_P + '/browserctl/api/config', { cache: 'no-store' })
      .then(r => r.text().then(tx => { try { return JSON.parse(tx) } catch { return { error: 'HTTP ' + r.status } } }))
      .then(j => {
        if (!alive) return
        if (j.error) { setErr(j.error); return }
        setCfg(j)
        setMode(j.mode === 'selfhost' ? 'selfhost' : 'official')
        if (j.mode === 'selfhost') {
          setHost(j.host || '')
          setPort(String(j.port || 17000))
          setRemotePort(j.remotePort ? String(j.remotePort) : '')
        }
      })
      .catch(() => {})
    return () => { alive = false }
  }, [])

  const save = async () => {
    if (saving === 'loading') return
    setErr('')
    const params = new URLSearchParams()
    if (mode === 'selfhost') {
      const h = host.trim()
      if (!h) { setErr(t('configHostRequired')); return }
      params.set('mode', 'selfhost')
      params.set('host', h)
      params.set('port', String(parseInt(port, 10) || 17000))
      if (remotePort.trim()) params.set('remotePort', String(parseInt(remotePort, 10) || ''))
      // frp_token 不再进 URL（kb/24）：query 会进闸机 reqlog 并被自动上报官方，改走 POST body
    } else {
      params.set('mode', 'official')
    }
    setSaving('loading')
    try {
      // frp token 放 POST JSON body(字段名 frp_token,与 secrets 字段对齐),不再进 URL query:
      // query 里的 token 会进闸机 reqlog(完整路径被记录)并随日志自动上报官方。
      // 留空 = 保持现有 token,此时 body 为空对象。
      const r = await fetch(API_P + '/browserctl/api/config?' + params.toString(), {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(token ? { frp_token: token } : {}),
        cache: 'no-store',
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || j.error) {
        setErr(j.error || ('HTTP ' + r.status))
        setSaving('')
        return
      }
      setSaving('done')
      setToken('') // 保存成功后清空 token 输入框,避免下次误提交
      onSaved() // 保存后主动刷新主面板(二维码/面板链接)
      setTimeout(() => setSaving(''), 2200) // 成功 toast 2.2s 自动消失
    } catch (e) {
      setErr(String((e && e.message) || e))
      setSaving('')
    }
  }

  return (
    <div className="dshBrowserCtlOverlay" role="dialog" aria-modal="true" aria-label={t('config')}>
      <button className="dshBrowserCtlOverlayMask" type="button" aria-label={t('close')} onClick={onClose} />
      <section className="dshBrowserCtlPanel dshBrowserCtlPanelNested dshBrowserCtlPanelCfg">
        <header className="dshBrowserCtlHeader">
          <div>
            <h1>{t('config')}</h1>
            <p>{t('configSubtitle')}</p>
          </div>
          <Tooltip label={t('close')}>
            <Button variant="ghost" size="sm" aria-label={t('close')} icon={<IconCloseOutlineRegular />} onClick={onClose} />
          </Tooltip>
        </header>
        <div className="dshBrowserCtlCfgModes">
          <label className="dshBrowserCtlCfgMode">
            <input type="radio" name="browserctl-mode" checked={mode === 'official'} onChange={() => setMode('official')} />
            <span>
              <span className="dshBrowserCtlCfgModeTitle">{t('configOfficial')}</span>
              <span className="dshBrowserCtlCfgModeDesc">{t('configOfficialHint')}</span>
            </span>
          </label>
          <label className="dshBrowserCtlCfgMode">
            <input type="radio" name="browserctl-mode" checked={mode === 'selfhost'} onChange={() => setMode('selfhost')} />
            <span>
              <span className="dshBrowserCtlCfgModeTitle">{t('configSelfhost')}</span>
              <span className="dshBrowserCtlCfgModeDesc">{t('configSelfhostHint')}</span>
            </span>
          </label>
        </div>
        {mode === 'official' ? (
          <p className="dshBrowserCtlCfgOfficialNote">{t('configOfficialNote')}</p>
        ) : (
          <div className="dshBrowserCtlCfgFields">
            <label className="dshBrowserCtlCfgField">
              <span>{t('configHost')}</span>
              <input value={host} onChange={e => setHost(e.target.value)} placeholder={t('configHostPh')} spellCheck={false} />
            </label>
            <div className="dshBrowserCtlCfgFieldRow">
              <label className="dshBrowserCtlCfgField">
                <span>{t('configPort')}</span>
                <input value={port} onChange={e => setPort(e.target.value)} inputMode="numeric" />
              </label>
              <label className="dshBrowserCtlCfgField">
                <span>{t('configRemotePort')}</span>
                <input value={remotePort} onChange={e => setRemotePort(e.target.value)} inputMode="numeric" />
              </label>
            </div>
            <label className="dshBrowserCtlCfgField">
              <span>{t('configToken')}</span>
              <input
                type="password"
                value={token}
                onChange={e => setToken(e.target.value)}
                placeholder={cfg && cfg.hasToken ? t('configTokenKeep') : t('configTokenPh')}
                autoComplete="new-password"
                spellCheck={false}
              />
            </label>
            <p className="dshBrowserCtlCfgNote">{t('configTokenNote')}</p>
          </div>
        )}
        {err && <p className="dshBrowserCtlCfgErr">{err}</p>}
        <div className="dshBrowserCtlCfgActions">
          <Button variant="secondary" size="sm" className="dshBrowserCtlCfgSave" disabled={saving === 'loading'} onClick={onClose}>
            {t('cancel')}
          </Button>
          <Button variant="primary" size="sm" className="dshBrowserCtlCfgSave" disabled={saving === 'loading'} onClick={save}>
            {saving === 'loading' ? t('saving') : saving === 'done' ? (<><span aria-hidden="true">{Svg.check}</span>{t('saved')}</>) : t('save')}
          </Button>
        </div>
      </section>
    </div>
  )
}

// 官方多用户账号卡:设备授权流(RFC 8628)登录/注册/退出。
// 点「登录」→ host 拿 device_code → 打开浏览器跳官网授权页 → 用户在网页登录/注册并
// 确认 → 这里轮询 /server/oauth/poll 换 token(host 落 per-user 密钥与端口),随后
// 重启隧道(stop+ensure)让 frpc 用新端口重新拨号。账号密码不在插件内出现。
function OfficialAccountCard({ t, onSaved }) {
  const [acct, setAcct] = useState(null)        // /server/me 或 config.account 的合并视图
  const [busy, setBusy] = useState('')          // '' | 'begin' | 'logout'
  const [err, setErr] = useState('')
  const [msg, setMsg] = useState('')
  const [pending, setPending] = useState(null)  // {deviceCode, userCode, verificationUri, interval}
  const pollTimer = useRef(null)
  const pendingRef = useRef(null)                 // 闭包安全:poll 读这个而非 pending(state 跨 render 会变)
  const [copiedOauth, setCopiedOauth] = useState(false)

  const loadAcct = async () => {
    try {
      const r = await fetch(API_P + '/browserctl/api/server/me', { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (j && j.loggedIn) {
        setAcct({ email: j.email, remotePort: j.remotePort, status: j.status })
      } else if (j && j.ok === false && j.error) {
        setErr(t('configAcctLoadFail'))
      } else {
        setAcct(null)
      }
    } catch (e) {
      setErr(t('configAcctLoadFail'))
    }
  }
  useEffect(() => { loadAcct() }, [])

  const clearPoll = () => {
    if (pollTimer.current) { clearTimeout(pollTimer.current); pollTimer.current = null }
    pendingRef.current = null
  }
  useEffect(() => () => clearPoll(), [])

  const restartTunnel = async () => {
    try {
      await fetch(API_P + '/browserctl/api/stop', { method: 'POST', cache: 'no-store' })
      await new Promise(r => setTimeout(r, 1500))
      await fetch(API_P + '/browserctl/api/ensure', { method: 'POST', cache: 'no-store' })
      return true
    } catch (e) {
      return false
    }
  }

  const openAuthPage = async (url) => {
    if (!url) return false
    try {
      const r = await fetch(API_P + '/browserctl/api/server/oauth/open?url=' + encodeURIComponent(url), { method: 'POST', cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j.ok) {
        setErr((j && j.error) || t('configAcctOauthOpenFail'))
        return false
      }
      setErr('')
      return true
    } catch (e) {
      setErr(t('configAcctOauthOpenFail'))
      return false
    }
  }

  const copyOauthUrl = (url) => {
    if (!url) return
    navigator.clipboard?.writeText(url).then(() => {
      setCopiedOauth(true)
      setTimeout(() => setCopiedOauth(false), 1600)
    }).catch(() => {})
  }

  const poll = async () => {
    const pd = pendingRef.current
    if (!pd) return
    try {
      const r = await fetch(API_P + '/browserctl/api/server/oauth/poll?device_code=' + encodeURIComponent(pd.deviceCode), { method: 'POST', cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (j && j.ok) {
        clearPoll()
        setPending(null)
        pendingRef.current = null
        setAcct({ email: j.email, remotePort: j.remotePort })
        setMsg(t('configAcctOauthDone'))
        onSaved()
        const okRestart = await restartTunnel()
        if (!okRestart) { setErr(t('configAcctRestartFail')); setMsg('') }
        setBusy('')
        return
      }
      if (j && j.pending) {
        const interval = Math.max(3, Number(j.interval) || 5) * 1000
        pollTimer.current = setTimeout(poll, interval)
        return
      }
      // 失败/过期/拒绝
      clearPoll()
      setPending(null); setBusy('')
      setErr(j && j.error ? (t('configAcctOauthFail') + ' ' + j.error) : t('configAcctOauthExpired'))
    } catch (e) {
      clearPoll()
      setPending(null); setBusy('')
      setErr(t('configAcctOauthNetwork'))
    }
  }

  const startOAuth = async () => {
    if (busy) return
    setErr(''); setMsg('')
    setBusy('begin')
    try {
      const r = await fetch(API_P + '/browserctl/api/server/oauth/begin', { method: 'POST', cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j.ok) {
        setErr(j.error || ('HTTP ' + r.status))
        setBusy('')
        return
      }
      setPending({
        deviceCode: j.deviceCode,
        userCode: j.userCode,
        verificationUri: j.verificationUri,
        interval: Math.max(3, Number(j.interval) || 5),
      })
      pendingRef.current = { deviceCode: j.deviceCode, userCode: j.userCode, verificationUri: j.verificationUri }
      setBusy('polling')
      await openAuthPage(j.verificationUri)
      pollTimer.current = setTimeout(poll, 1500)
    } catch (e) {
      setErr(t('configAcctOauthNetwork'))
      setBusy('')
    }
  }

  const cancelOAuth = () => {
    clearPoll()
    setPending(null)
    pendingRef.current = null
    setBusy('')
  }

  const logout = async () => {
    if (busy) return
    setErr(''); setMsg('')
    setBusy('logout')
    try {
      await fetch(API_P + '/browserctl/api/server/logout', { method: 'POST', cache: 'no-store' })
      setAcct(null)
      setMsg(t('configAcctLoggedOut'))
      onSaved()
    } catch (e) {
      setErr(String((e && e.message) || e))
    }
    setBusy('')
  }

  const working = busy !== ''

  if (acct) {
    return (
      <div className="dshBrowserCtlCfgFields">
        <div className="dshBrowserCtlCfgFieldRow">
          <label className="dshBrowserCtlCfgField">
            <span>{t('configAcctTitle')}</span>
            <span className="dshBrowserCtlCfgAcctLine">
              {t('configAcctLoggedIn')} · {acct.email}
              {Number(acct.remotePort) > 0 ? ' · ' + t('configAcctPort') + ' ' + acct.remotePort : ''}
            </span>
          </label>
        </div>
        {msg && <p className="dshBrowserCtlCfgNote">{msg}</p>}
        {err && <p className="dshBrowserCtlCfgErr">{err}</p>}
        <Button variant="secondary" size="sm" disabled={working} onClick={logout}>
          {busy === 'logout' ? t('configAcctLoggingOut') : t('configAcctLogout')}
        </Button>
      </div>
    )
  }

  if (pending) {
    return (
      <div className="dshBrowserCtlCfgFields">
        <label className="dshBrowserCtlCfgField">
          <span>{t('configAcctTitle')}</span>
          <span className="dshBrowserCtlCfgAcctLine">{t('configAcctOauthWait')}</span>
        </label>
        <p className="dshBrowserCtlCfgNote">{t('configAcctOauthOpenBrowser')}</p>
        <div className="dshBrowserCtlCfgOauthCode">{pending.userCode}</div>
        <p className="dshBrowserCtlCfgNote">
          <a href={pending.verificationUri} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--dsw-alias-accent-strong,#4da3ff)', wordBreak: 'break-all' }}>
            {pending.verificationUri}
          </a>
        </p>
        <div className="dshBrowserCtlCfgFieldRow">
          <Button variant="secondary" size="sm" onClick={() => openAuthPage(pending.verificationUri)}>
            {t('configAcctOauthOpenAgain')}
          </Button>
          <Button variant="secondary" size="sm" onClick={() => copyOauthUrl(pending.verificationUri)}>
            {copiedOauth ? t('configAcctCopied') : t('configAcctCopy')}
          </Button>
          <Button variant="secondary" size="sm" onClick={cancelOAuth}>
            {t('configAcctOauthCancel')}
          </Button>
        </div>
        {msg && <p className="dshBrowserCtlCfgNote">{msg}</p>}
        {err && <p className="dshBrowserCtlCfgErr">{err}</p>}
      </div>
    )
  }

  return (
    <div className="dshBrowserCtlCfgFields">
      <label className="dshBrowserCtlCfgField">
        <span>{t('configAcctTitle')}</span>
        <span className="dshBrowserCtlCfgAcctLine">{t('configAcctOauthHint')}</span>
      </label>
      {msg && <p className="dshBrowserCtlCfgNote">{msg}</p>}
      {err && <p className="dshBrowserCtlCfgErr">{err}</p>}
      <Button variant="primary" size="sm" disabled={working} onClick={startOAuth}>
        {busy === 'begin' ? t('configAcctOauthOpening') : t('configAcctOauthBtn')}
      </Button>
    </div>
  )
}

/* ---------- 账号登录弹窗(顶栏「账号登录」按钮打开,复用 OfficialAccountCard) ---------- */
function AccountLoginModal({ t, onClose, onSaved }) {
  return (
    <div className="dshBrowserCtlOverlay" role="dialog" aria-modal="true" aria-label={t('configAcctTitle')}>
      <button className="dshBrowserCtlOverlayMask" type="button" aria-label={t('close')} onClick={onClose} />
      <section className="dshBrowserCtlPanel dshBrowserCtlPanelNested dshBrowserCtlPanelCfg">
        <header className="dshBrowserCtlHeader">
          <div>
            <h1>{t('configAcctTitle')}</h1>
            <p>{t('configOfficialHint')}</p>
          </div>
          <Tooltip label={t('close')}>
            <Button variant="ghost" size="sm" aria-label={t('close')} icon={<IconCloseOutlineRegular />} onClick={onClose} />
          </Tooltip>
        </header>
        <OfficialAccountCard t={t} onSaved={onSaved} />
      </section>
    </div>
  )
}

/* ---------- 顶栏「通知中心」下拉(铃铛) ---------- */
// 数据源:官方服务器「消息中心」(管理后台发放,定向到账号或全员)。
// 已登录 → host /server/messages 带 Bearer 拉定向+全员,未读数用服务端(与官网/App 跨端同步);
// 未登录 → 同一接口自动退回公开公告(全员公告免登录可见),未读用本地水位(localStorage)判断。
// 打开列表即全部已读:登录态调 /server/messages/read(服务端已读),未登录只推进本地水位。
function MsgCenter({ t, loggedInHint, onClose }) {
  const [msgs, setMsgs] = useState(null) // null=加载中
  const [err, setErr] = useState('')
  const [loggedIn, setLoggedIn] = useState(false)
  useEffect(() => {
    let alive = true
    fetch(API_P + '/browserctl/api/server/messages', { cache: 'no-store' })
      .then(r => r.json().catch(() => ({ ok: false, error: 'HTTP ' + r.status })))
      .then(j => {
        if (!alive) return
        if (!j || j.ok === false) { setErr((j && j.error) || t('msgLoadFail')); setMsgs([]); return }
        setErr('')
        setLoggedIn(!!j.loggedIn)
        setMsgs(Array.isArray(j.messages) ? j.messages : [])
      })
      .catch(e => { if (alive) { setErr(String((e && e.message) || e)); setMsgs([]) } })
    return () => { alive = false }
    // 仅挂载时拉一次(下拉每次打开重新挂载);依赖里放 t 会在父组件重渲染时反复请求
  }, [])
  // 打开即全部已读(与官网个人中心一致):登录态走服务端,未登录只推进本地水位。
  // 推进动作放在渲染后的 effect:首次渲染仍按旧水位显示未读点,关掉重开才消失。
  useEffect(() => {
    if (!msgs || !msgs.length) return
    const maxTs = msgs.reduce((m, x) => Math.max(m, Number(x.createdAt) || 0), 0)
    lsSet(MSG_SEEN_KEY, String(maxTs))
    if (loggedIn) fetch(API_P + '/browserctl/api/server/messages/read', { method: 'POST', cache: 'no-store' }).catch(() => {})
  }, [msgs, loggedIn])
  return (
    <>
      <button className="dshBrowserCtlMsgMask" type="button" aria-label={t('close')} onClick={onClose} />
      <div className="dshBrowserCtlMsgPop" role="dialog" aria-label={t('msgCenter')}>
        <div className="dshBrowserCtlMsgPopHead">
          <span>{t('msgCenter')}</span>
          <Button variant="ghost" size="sm" aria-label={t('close')} icon={<IconCloseOutlineRegular />} onClick={onClose} />
        </div>
        <div className="dshBrowserCtlMsgList">
          {msgs === null ? (
            <div className="dshBrowserCtlMsgEmpty">{t('ticketLoading')}</div>
          ) : !msgs.length ? (
            <div className="dshBrowserCtlMsgEmpty">{t('msgEmpty')}</div>
          ) : msgs.map(m => <MsgItem key={m.id} t={t} msg={m} seen={msgIsSeen(m)} />)}
        </div>
        {err ? <p className="dshBrowserCtlMsgErr">{t('msgLoadFail')}: {err}</p> : null}
        {!loggedIn && !err ? <div className="dshBrowserCtlMsgFoot">{loggedInHint}</div> : null}
      </div>
    </>
  )
}

function MsgItem({ t, msg, seen }) {
  const official = msg.kind !== 'personal'
  return (
    <div className="dshBrowserCtlMsgItem" data-unread={!seen && !msg.read ? 'true' : 'false'}>
      <div className="dshBrowserCtlMsgKind">
        <span className="dshBrowserCtlMsgKindTag" data-personal={official ? 'false' : 'true'}>
          {official ? t('msgOfficial') : t('msgPersonal')}
        </span>
      </div>
      <div className="dshBrowserCtlMsgTitle">
        {!msg.read && !seen ? <span className="dshBrowserCtlMsgUnreadDot" aria-hidden="true" /> : null}
        <span>{msg.title}</span>
      </div>
      {msg.body ? <p className="dshBrowserCtlMsgBody">{msg.body}</p> : null}
      {msg.link ? (
        <a className="dshBrowserCtlMsgLink" href={msg.link} target="_blank" rel="noopener noreferrer">
          {t('msgOpenLink')}
        </a>
      ) : null}
      <div className="dshBrowserCtlMsgTime">{fmtMsgTime(msg.createdAt)}</div>
    </div>
  )
}

/* ---------- 工单反馈弹窗(导出日志 → 选去向:官网工单 / 存本地文件夹 / 复制内容) ---------- */
// 插件端不再内嵌提交表单(表单在窄面板里体验差,且官方账号登录态与网页端是两套)。
// 2026-11-09 起:先「生成并导出诊断日志」(host 组装+脱敏,落到桌面/下载,可另存自选目录),
// 再从三个去向里选:
//   1) 打开网页版工单 —— 跳官网 /app.html#tickets;未登录会被登录页接住(?next=),登录后直达工单页
//   2) 存到其他文件夹 —— 浏览器支持目录选择器就直接选目录写入;不支持就退回手填路径(host 校验后写入)
//   3) 复制日志内容 —— 已脱敏全文进剪贴板,可粘到聊天/文本框
// 日志只在本机生成,不会自动上传;何时传、传不传完全由用户在网页端决定。
const TICKET_PAGE_URL = 'https://remote.ymzcc.com/dsh-remote/app.html#tickets'

async function ticketCopyText(s) {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(s)
      return true
    }
  } catch (e) { /* 非安全上下文/权限拒绝 → 走 execCommand 兜底 */ }
  try {
    const ta = document.createElement('textarea')
    ta.value = s
    ta.setAttribute('readonly', '')
    ta.style.position = 'fixed'
    ta.style.opacity = '0'
    document.body.appendChild(ta)
    ta.select()
    const ok = document.execCommand('copy')
    ta.remove()
    return ok
  } catch (e) { return false }
}

function TicketModal({ t, onClose }) {
  const [busy, setBusy] = useState('')            // '' | export | save | reveal
  const [err, setErr] = useState('')
  const [info, setInfo] = useState('')
  const [exported, setExported] = useState(null)  // {name,path,bytes,content?}
  const [pickMode, setPickMode] = useState(false) // 无目录选择器时的路径输入
  const [pickPath, setPickPath] = useState('')

  const doExport = async (dir, tag) => {
    if (busy) return
    setBusy(tag || 'export'); setErr(''); setInfo('')
    try {
      const q = '?withText=1' + (dir ? '&dir=' + encodeURIComponent(dir) : '')
      const r = await fetch(API_P + '/browserctl/api/ticket/export-diag' + q, { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j.ok) {
        // 404 = 宿主还是旧版本(新路由要 DSH 真正重启才会注册),给一句能照做的提示
        setErr(r.status === 404
          ? t('ticketExportHostOld')
          : ((j && j.error) || ('HTTP ' + r.status)))
        return
      }
      setExported(j)
      setPickMode(false)
      if (dir) setInfo(t('ticketSaveOk') + (j.path || ''))
    } catch (e) {
      setErr(String((e && e.message) || e))
    } finally { setBusy('') }
  }
  const openWeb = () => { try { window.open(TICKET_PAGE_URL, '_blank', 'noopener') } catch (e) {} }

  const revealFolder = async () => {
    if (!exported || busy) return
    setBusy('reveal'); setErr(''); setInfo('')
    try {
      const r = await fetch(API_P + '/browserctl/api/ticket/reveal?path=' + encodeURIComponent(exported.path || ''), { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j.ok) setErr((j && j.error) || ('HTTP ' + r.status))
    } catch (e) {
      setErr(String((e && e.message) || e))
    } finally { setBusy('') }
  }

  const copyContent = async () => {
    if (!exported) return
    if (!exported.content) { setErr(t('ticketNoContent')); return }
    const ok = await ticketCopyText(exported.content)
    setErr('')
    setInfo(ok ? t('ticketCopyOk') : t('ticketCopyFail'))
  }

  const copyPath = async () => {
    if (!exported) return
    const ok = await ticketCopyText(exported.path || '')
    if (ok) { setErr(''); setInfo(t('ticketCopyPathOk')) }
  }

  const saveToFolder = async () => {
    if (!exported || busy) return
    if (!exported.content) { setErr(t('ticketNoContent')); return }
    // 优先目录选择器(Chromium/Electron 较新才有;选完直接把文件写进去)
    if (typeof window.showDirectoryPicker === 'function') {
      try {
        const dir = await window.showDirectoryPicker()
        const fh = await dir.getFileHandle(exported.name, { create: true })
        const w = await fh.createWritable()
        await w.write(exported.content || '')
        await w.close()
        setErr(''); setInfo(t('ticketSaveOk') + exported.name)
        return
      } catch (e) {
        if (e && e.name === 'AbortError') return // 用户取消选择,不算错误
        /* 选择器不可用/权限拒绝 → 退回手填路径 */
      }
    }
    setPickMode(true)
  }

  const destStyle = { margin: '0 0 10px', fontSize: 12.5, lineHeight: 1.6, color: 'var(--dsw-alias-label-secondary,#a6aab2)' }
  return (
    <div className="dshBrowserCtlOverlay" role="dialog" aria-modal="true" aria-label={t('tickets')}>
      <button className="dshBrowserCtlOverlayMask" type="button" aria-label={t('close')} onClick={onClose} />
      <section className="dshBrowserCtlPanel dshBrowserCtlPanelNested dshBrowserCtlPanelTicket">
        <header className="dshBrowserCtlHeader">
          <div>
            <h1>{t('tickets')}</h1>
            <p>{t('ticketExportSubtitle')}</p>
          </div>
          <Tooltip label={t('close')}>
            <Button variant="ghost" size="sm" aria-label={t('close')} icon={<IconCloseOutlineRegular />} onClick={onClose} />
          </Tooltip>
        </header>
        <div className="dshBrowserCtlTicketBody">
          {err ? <p className="dshBrowserCtlCfgErr">{err}</p> : null}
          {info ? <p className="dshBrowserCtlCfgNote" style={{ marginTop: 0 }}>{info}</p> : null}
          <div className="dshBrowserCtlActions" style={{ justifyContent: 'flex-start' }}>
            <Button variant="primary" size="sm" disabled={!!busy} onClick={() => doExport('', 'export')}>
              {busy === 'export'
                ? (<><span className="dshBrowserCtlSpinner" aria-hidden="true" /> {t('ticketExporting')}</>)
                : (exported ? t('ticketExportAgain') : t('ticketExportDo'))}
            </Button>
          </div>
          {exported ? (
            <div style={{
              margin: '12px 0 2px', padding: '10px 12px', borderRadius: 9,
              background: 'rgba(52,179,113,0.12)', border: '1px solid rgba(52,179,113,0.35)',
            }}>
              <div style={{ fontSize: 12.5, color: 'var(--dsw-alias-state-success-primary,#34b371)', marginBottom: 4 }}>
                {t('ticketExportDone')}
              </div>
              <div style={{
                fontSize: 11.5, lineHeight: 1.5, wordBreak: 'break-all',
                fontFamily: 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace',
                color: 'var(--dsw-alias-label-secondary,#a6aab2)',
              }}>{exported.path}</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                <Button variant="secondary" size="sm" disabled={!!busy} onClick={revealFolder}>
                  {busy === 'reveal'
                    ? (<><span className="dshBrowserCtlSpinner" aria-hidden="true" /> {t('ticketOpening')}</>)
                    : t('ticketOpenFolder')}
                </Button>
                <Button variant="secondary" size="sm" onClick={copyPath}>{t('ticketCopyPath')}</Button>
              </div>
            </div>
          ) : null}
          <p style={{ ...destStyle, margin: '14px 0 6px', fontWeight: 600, color: 'var(--dsw-alias-label-primary,inherit)' }}>{t('ticketDestTitle')}</p>
          <button type="button" className="dshBrowserCtlTicketDest" onClick={openWeb}>
            <span className="dshBrowserCtlTicketDestTitle">{t('ticketOpenWeb')}</span>
            <span className="dshBrowserCtlTicketDestDesc">{t('ticketOpenWebDesc')}</span>
          </button>
          <button type="button" className="dshBrowserCtlTicketDest" disabled={!exported} onClick={saveToFolder}>
            <span className="dshBrowserCtlTicketDestTitle">{t('ticketSaveOther')}</span>
            <span className="dshBrowserCtlTicketDestDesc">{t('ticketSaveOtherDesc')}</span>
          </button>
          <button type="button" className="dshBrowserCtlTicketDest" disabled={!exported} onClick={copyContent}>
            <span className="dshBrowserCtlTicketDestTitle">{t('ticketCopyContent')}</span>
            <span className="dshBrowserCtlTicketDestDesc">{t('ticketCopyContentDesc')}</span>
          </button>
          {pickMode ? (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10, alignItems: 'center' }}>
              <input
                className="dshBrowserCtlTicketInput"
                style={{ flex: '1 1 220px', minWidth: 0 }}
                placeholder={t('ticketSavePathPh')}
                value={pickPath}
                onChange={e => setPickPath(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); if (pickPath.trim()) doExport(pickPath.trim(), 'save') } }}
              />
              <Button variant="secondary" size="sm" disabled={!!busy || !pickPath.trim()} onClick={() => doExport(pickPath.trim(), 'save')}>
                {busy === 'save'
                  ? (<><span className="dshBrowserCtlSpinner" aria-hidden="true" /> {t('ticketSaving')}</>)
                  : t('ticketSaveGo')}
              </Button>
            </div>
          ) : null}
          <p className="dshBrowserCtlCfgNote" style={{ marginTop: 12 }}>{t('ticketExportNote')}</p>
        </div>
      </section>
    </div>
  )
}

function BrowserCtlOverlay({ useStore, actions, t, initialTab }) {
  const open = useStore(state => state.open)
  const [reloadToken, setReloadToken] = useState(0)
  const [copied, setCopied] = useState(false)
  // 全局忙碌标记:任一操作进行中,禁用面板内所有按钮,杜绝连点/排队/误触
  const [busy, setBusy] = useState('')
  // 顶部功能页签:connect / devices / totp / ban / log
  const [tab, setTab] = useState(initialTab || 'connect')
  // 配对码可用次数:1=一次性(扫完自动换码);>1 可多台设备共用同一个码
  const [uses, setUses] = useState(1)
  // 头部小浮层:关于 / 配置(点击头部图标按钮打开)
  const [aboutOpen, setAboutOpen] = useState(false)
  const [configOpen, setConfigOpen] = useState(false)
  // 顶栏「账号登录」弹窗 + 未登录启动远程时的提示
  const [accountOpen, setAccountOpen] = useState(false)
  const [loginPrompt, setLoginPrompt] = useState(false)
  // 工单反馈弹窗(独立浮层;内部复用 AccountLoginModal 处理未登录)
  const [ticketOpen, setTicketOpen] = useState(false)
  // 启动失败的具体原因(如「找不到 Python」)。以前只 console.error,界面什么都不显示,
  // 用户只看到「点了没反应」,所以这里必须把原因原样呈现出来。
  const [startErr, setStartErr] = useState('')
  // 提权(UAC)通道是否可用(只有 Windows 有);以及「该用提权补偿哪个动作」:
  // '' 不需要 / 'start' 启动失败后重试 / 'stop' 普通权限停不掉。
  // 提权按钮只在失败之后出现,点击才弹 UAC,绝不在启动时自动弹。
  const [canElevate, setCanElevate] = useState(false)
  const [elevNeed, setElevNeed] = useState('')
  // 顶栏账号按钮的登录态(登录后显示邮箱)
  const [acctMe, setAcctMe] = useState(null)
  // 顶栏「通知中心」:消息列表 + 登录态 + 服务端未读数(未登录未读走本地水位)
  const [msgData, setMsgData] = useState({ messages: [], loggedIn: false, unread: 0 })
  const [msgPopOpen, setMsgPopOpen] = useState(false)
  // 当前连接模式(official/selfhost),用于判断未登录时是否显示二维码
  const [cfgMode, setCfgMode] = useState('official')
  const panel = useRef(null)
  const { data, error, expiresAt, status, retrying, refresh } = useQr(open, reloadToken, uses)
  const left = useCountdown(expiresAt)
  const run = async (label, fn) => {
    if (busy) return
    setBusy(label)
    try { await fn() } finally { setBusy('') }
  }
  const refreshAll = () => run('refresh', async () => {
    await new Promise(r => setTimeout(r, 60))
    setReloadToken(x => x + 1)
  })
  const loadAcctMe = async () => {
    try {
      const r = await fetch(API_P + '/browserctl/api/server/me', { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      setAcctMe(j && j.loggedIn ? j : null)
    } catch { setAcctMe(null) }
  }
  useEffect(() => { if (open) loadAcctMe() }, [open, reloadToken])
  // 通知中心:面板打开即拉一次,之后每 60s 轮询红点(与闸机 2 分钟心跳错开也够用);
  // 关闭下拉时再拉一次——刚在列表里标了已读,徽标要立即归零,不等下一轮询。
  const loadMsgs = async () => {
    try {
      const r = await fetch(API_P + '/browserctl/api/server/messages', { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (j && j.ok) setMsgData({ messages: Array.isArray(j.messages) ? j.messages : [], loggedIn: !!j.loggedIn, unread: Number(j.unread) || 0 })
    } catch {}
  }
  useEffect(() => { if (open) loadMsgs() }, [open, reloadToken])
  useEffect(() => {
    if (!open) return
    const h = setInterval(loadMsgs, 60000)
    return () => clearInterval(h)
  }, [open])
  const closeMsgPop = () => { setMsgPopOpen(false); loadMsgs() }
  // 徽标:登录态用服务端未读数(与官网/App 跨端同步);未登录用本地水位数「新于水位的全员公告」。
  // 下拉开着时不显示红点(列表已在眼前)。
  const msgUnreadCount = msgData.loggedIn
    ? (msgData.unread || 0)
    : (msgData.messages || []).filter(m => !msgIsSeen(m)).length
  const msgShowDot = !msgPopOpen && msgUnreadCount > 0
  // 加载连接模式(用于判断未登录时是否隐藏二维码)
  useEffect(() => {
    if (!open) return
    fetch(API_P + '/browserctl/api/config', { cache: 'no-store' })
      .then(r => r.json().then(j => {
        if (j && j.mode) setCfgMode(j.mode)
        if (j && typeof j.canElevate === 'boolean') setCanElevate(j.canElevate)
      }).catch(() => {}))
      .catch(() => {})
  }, [open])
  const startChain = async () => {
    // 官方模式且未登录 → 弹提示先去登录,不直接启动
    try {
      const c = await fetch(API_P + '/browserctl/api/config', { cache: 'no-store' }).then(r => r.json()).catch(() => ({}))
      if (c && c.mode === 'official') {
        const m = await fetch(API_P + '/browserctl/api/server/me', { cache: 'no-store' }).then(r => r.json()).catch(() => ({}))
        if (!(m && m.loggedIn)) { setLoginPrompt(true); return }
      }
    } catch {}
    setStartErr('') // 重新启动前清掉上一次的失败原因
    run('start', async () => {
      // Phase 1: 触发 ensure（偶发网络抖动/端口竞争时最多重试 3 次）
      let lastErr = ''
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          const r = await fetch(API_P + '/browserctl/api/ensure', { cache: 'no-store' })
          const j = await r.json().catch(() => ({}))
          if (j && (j.ok || j.pending)) { lastErr = ''; break }
          lastErr = (j && j.error) || ('HTTP ' + r.status)
        } catch (e) {
          lastErr = String((e && e.message) || e)
        }
        if (attempt < 3) await new Promise(r => setTimeout(r, attempt * 1000))
      }
      // Phase 2: ensure 已接受（ok 或 pending），轮询直到「闸机 3080 + frp 隧道」都真正就绪。
      // 只判断 forwarder 不够:browserctl.py start 现在会自己等最多 15s 到 frpc 日志出现
      // `start proxy success`,ensure 最长约 26s 才返回;并发点击时拿到 pending 的这一侧
      // 也可能要等到隧道就绪,所以这里给 30s 并把 status.tunnel.ok 一起当就绪条件。
      if (!lastErr) {
        const deadline = Date.now() + 30000
        let fwd = false
        let tunnelErr = ''
        while (Date.now() < deadline) {
          try {
            const r = await fetch(API_P + '/browserctl/api/status', { cache: 'no-store' })
            const j = await r.json().catch(() => ({}))
            fwd = !!j.forwarder
            const tun = j.tunnel
            // 旧闸机没有 tunnel 字段 → 视为就绪(保持旧行为,不拦老环境)
            const tunnelOk = !tun || tun.ok !== false
            if (!tunnelOk && tun && tun.error) tunnelErr = String(tun.error)
            if (fwd && tunnelOk) break
            // 后台 ensure 已经失败:立刻取回原因,不用空等到超时
            if (j.startError) { lastErr = String(j.startError); break }
          } catch { fwd = false }
          await new Promise(r => setTimeout(r, 300))
        }
        // 等满 30 秒还没起来:再探一次把原因取回来(以前这里直接放弃,
        // 面板就永远停在"隧道正在建立",用户看不到任何失败原因)
        if (!lastErr && !fwd) {
          try {
            const r = await fetch(API_P + '/browserctl/api/status', { cache: 'no-store' })
            const j = await r.json().catch(() => ({}))
            lastErr = String(j.startError || '')
              || (j.tunnel && j.tunnel.error ? String(j.tunnel.error) : '')
              || '本机闸机(127.0.0.1:3080)在 30 秒内没有就绪。\n'
               + '请查看 kit 目录下的 browserctl_start.log 与 browserctl_fwd.log;\n'
               + '最常见原因是安全软件拦截 frpc.exe(详见 INSTALL.md 常见问题第 1 条)。'
          } catch {
            lastErr = '本机闸机(127.0.0.1:3080)在 30 秒内没有就绪,请查看 kit 目录下的日志文件。'
          }
        }
        // 闸机在跑但 frp 隧道没连上:把 tunnel_error(多行中文,可能含 frpc 日志尾部)作为原因
        if (!lastErr && tunnelErr) lastErr = tunnelErr
      }
      if (lastErr) console.error('[browserctl] ensure 全部重试失败:', lastErr)
      setStartErr(lastErr)
      // 启动失败后把「以管理员身份启动」的入口放出来(典型原因:Defender/杀软按 PUA 拦
      // frpc.exe 导致 WinError 5 拒绝访问、状态文件被管理员进程占用)。只有用户点按钮
      // 才弹 UAC,不是启动时自动弹。
      setElevNeed(lastErr ? 'start' : '')
      await new Promise(r => setTimeout(r, 600))
      setReloadToken(x => x + 1)
    })
  }
  const stopChain = () => run('stop', async () => {
    // 停止浏览器控制:关闭整个穿透隧道(fwd/frpc/watchdog 全部结束),
    // 公网面板 URL 立即不可访问。
    try { await fetch(API_P + '/browserctl/api/stop', { cache: 'no-store' }) } catch {}
    // stop 是分离进程,命令返回时闸机可能还没关完(端口未释放)。
    // 必须轮询等到 3080 真正关闭再刷新二维码,否则旧二维码不消失、开始按钮不出现。
    const deadline = Date.now() + 12000
    let still = false
    for (;;) {
      let fwd = true
      try {
        const r = await fetch(API_P + '/browserctl/api/status', { cache: 'no-store' })
        const j = await r.json()
        fwd = !!j.forwarder
      } catch { fwd = false }
      if (!fwd) break
      if (Date.now() >= deadline) { still = true; break }
      await new Promise(r => setTimeout(r, 300))
    }
    // 12 秒了闸机还在跑:最常见原因是这套 fwd/frpc 是「以管理员身份」起的,
    // 普通权限的 DSH 杀不掉它(OpenProcess 拒绝访问 → taskkill 失败但没人报错)。
    // 这种情况下只能再走一次 UAC 提权停止。
    setElevNeed(still ? 'stop' : '')
    if (still) setStartErr(t('elevateStopHint'))
    await new Promise(r => setTimeout(r, 200))
    setReloadToken(x => x + 1)
  })
  // 「打开面板」:不能直接 window.open(data.panel)。裸面板 URL 在闸机侧是
  // 「裸 URL 一律拒绝」(2026-11-07 安全策略:2FA 关时也必须已配对)——浏览器拿到的是
  // <title>403</title> 的纯黑页,而桌面浏览器没有任何获取会话的入口(手机走扫码、
  // iOS 走引导链接)。这里改为:点击 → 开一个新标签 → 现取一条一次性引导链接
  // (/link → 闸机 bootstrap?k=)写进该标签:闸机种下 30 天会话 Cookie 后 302 回面板根
  // (2FA 开启时先显示动态码验证页,验证一次同样 30 天免登)。
  // 必须先同步 window.open 再异步 fetch:否则经过 await 后再开窗会被弹窗拦截器吞掉。
  const openPanelChain = () => run('open', async () => {
    const w = window.open('', '_blank')
    const esc = (s) => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]))
    const fail = (msg) => {
      try {
        if (w && !w.closed) {
          w.document.title = t('openFailed')
          w.document.body.style.cssText = 'margin:0;background:#141519;color:#d8dade;' +
            "font-family:system-ui,'Segoe UI',sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh"
          w.document.body.innerHTML =
            '<div style="max-width:460px;padding:0 24px;text-align:center">' +
            '<div style="font-size:15px;margin-bottom:10px">' + esc(t('openFailed')) + '</div>' +
            '<div style="font-size:12px;line-height:1.7;opacity:.75;white-space:pre-wrap;text-align:left">' + esc(msg) + '</div>' +
            '</div>'
        }
      } catch {}
    }
    try {
      const r = await fetch(API_P + '/browserctl/api/link?ttl=600&uses=1', { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!r.ok || !j.url) { fail((j && j.error) || ('HTTP ' + r.status)); return }
      if (w && !w.closed) w.location.href = j.url
      else window.open(j.url, '_blank')
    } catch (e) {
      fail(String((e && e.message) || e))
    }
  })
  // 提权启动/停止:只在用户点按钮后触发,requested 是 'start' 或 'stop'。
  // 提权进程是分离的,接口只回 UAC 的结果;真正是否起来由这里轮询 /status 判断。
  const elevateChain = (requested) => run('elevate', async () => {
    const act = requested === 'stop' ? 'stop' : 'start'
    let lastErr = ''
    try {
      const r = await fetch(API_P + '/browserctl/api/elevate?action=' + act, { cache: 'no-store' })
      const j = await r.json().catch(() => ({}))
      if (!j || !j.ok) lastErr = (j && j.error) || ('HTTP ' + r.status)
    } catch (e) {
      lastErr = String((e && e.message) || e)
    }
    if (!lastErr) {
      // 管理员进程起来后要重新读 state:start 等 3080 + tunnel 都就绪,stop 等 3080 关闭。
      const wantUp = act === 'start'
      const deadline = Date.now() + 45000
      let fwd = !wantUp
      while (Date.now() < deadline) {
        try {
          const j = await fetch(API_P + '/browserctl/api/status', { cache: 'no-store' }).then(x => x.json())
          fwd = !!j.forwarder
          const tun = j.tunnel
          const tunnelOk = !tun || tun.ok !== false
          if (wantUp ? (fwd && tunnelOk) : !fwd) break
          if (wantUp && j.startError) { lastErr = String(j.startError); break }
        } catch { fwd = false }
        await new Promise(r => setTimeout(r, 400))
      }
      if (!lastErr && wantUp && !fwd) {
        lastErr = '提权启动后 45 秒内闸机(3080)仍未就绪,请查看 browserctl_start.log 与 browserctl_fwd.log。'
      }
      if (!lastErr && !wantUp && fwd) {
        lastErr = '提权停止后闸机(3080)仍在运行,请查看 browserctl_fwd.log。'
      }
    }
    setStartErr(lastErr)
    setElevNeed(lastErr ? act : '')
    await new Promise(r => setTimeout(r, 400))
    setReloadToken(x => x + 1)
  })

  useEffect(() => {
    if (!open) return
    panel.current?.querySelector('button')?.focus()
    const onKeyDown = (event) => {
      if (event.key !== 'Escape') return
      if (loginPrompt) { setLoginPrompt(false); return }
      if (msgPopOpen) { closeMsgPop(); return }
      if (accountOpen) { setAccountOpen(false); return }
      if (aboutOpen) { setAboutOpen(false); return }
      if (configOpen) { setConfigOpen(false); return }
      if (document.querySelectorAll('[role="dialog"]').length > 1) return
      actions.close()
    }
    document.addEventListener('keydown', onKeyDown)
    return () => document.removeEventListener('keydown', onKeyDown)
  }, [actions, open, aboutOpen, configOpen, accountOpen, loginPrompt, msgPopOpen])

  // 心跳保活:面板一打开(任意页签)就每 2 分钟向闸机报一次活动,
  // "在线设备"卡片据此判断谁还在线;关闭面板即停止上报,10 分钟后自动转为历史设备。
  useEffect(() => {
    if (!open) return
    let alive = true
    const beat = () => fetch(API_P + '/browserctl-gate/heartbeat', { cache: 'no-store' }).catch(() => {})
    beat().then(() => { if (alive) setTimeout(() => setReloadToken(x => x + 1), 400) })
    const hb = setInterval(beat, 120000)
    return () => { alive = false; clearInterval(hb) }
  }, [open])

  useEffect(() => {
    if (!copied) return
    const id = setTimeout(() => setCopied(false), 1600)
    return () => clearTimeout(id)
  }, [copied])

  const gating = !!busy
  const TABS = [
    { id: 'connect', icon: 'link', label: t('tabConnect') },
    { id: 'devices', icon: 'desk', label: t('tabDevices') },
    { id: 'totp', icon: 'lock', label: t('tab2fa') },
    { id: 'app', icon: 'phone', label: t('tabApp') },
    { id: 'push', icon: 'bell', label: t('tabPush') },
    { id: 'ban', icon: 'shield', label: t('tabBan') },
    { id: 'log', icon: 'clip', label: t('tabLog') },
  ]
  if (!open) return null
  return (
    <div className="dshBrowserCtlOverlay" role="dialog" aria-modal="true" aria-label={t('tab')}>
      <button className="dshBrowserCtlOverlayMask" type="button" aria-label={t('close')} onClick={() => actions.close()} />
      <section ref={panel} className="dshBrowserCtlPanel">
        <header className="dshBrowserCtlHeader">
          <div>
            <h1>{t('tab')}</h1>
            <p>{t('subtitle')}</p>
          </div>
          {busy && (
            <span style={{ fontSize: 11.5, color: 'var(--dsw-alias-label-tertiary,#8b8f98)', whiteSpace: 'nowrap', display: 'inline-flex', alignItems: 'center', gap: 5 }}>
              <span className="dshBrowserCtlSpinner" aria-hidden="true" />
              {busy === 'start' ? t('starting') : busy === 'stop' ? t('stopping') : t('refresh') + '…'}
            </span>
          )}
          <Tooltip label={acctMe ? (acctMe.email || t('configAcctTitle')) : t('aboutAccount')}>
            <Button
              variant="ghost"
              size="sm"
              className="dshBrowserCtlHeaderAcct"
              aria-label={t('configAcctTitle')}
              data-logged-in={acctMe ? 'true' : 'false'}
              onClick={() => setAccountOpen(true)}
            >
              <span aria-hidden="true">{Svg.person}</span>
              <span className="dshBrowserCtlHeaderAcctLabel">
                {acctMe ? (acctMe.email || t('aboutAccountLogged')) : t('aboutAccount')}
              </span>
            </Button>
          </Tooltip>
          <Tooltip label={t('tickets')}>
            <Button
              variant="ghost"
              size="sm"
              aria-label={t('tickets')}
              icon={Svg.ticket}
              onClick={() => setTicketOpen(true)}
            />
          </Tooltip>
          <Tooltip label={t('msgCenter')}>
            <span className="dshBrowserCtlAboutBtn">
              <Button
                variant="ghost"
                size="sm"
                aria-label={t('msgCenter')}
                aria-haspopup="dialog"
                aria-expanded={msgPopOpen}
                icon={Svg.bellHead}
                onClick={() => (msgPopOpen ? closeMsgPop() : setMsgPopOpen(true))}
              />
              {msgShowDot && <span className="dshBrowserCtlBadgeDot" />}
              {msgPopOpen && (
                <MsgCenter t={t} loggedInHint={t('msgGuestHint')} onClose={closeMsgPop} />
              )}
            </span>
          </Tooltip>
          <Tooltip label={t('about')}>
            <Button variant="ghost" size="sm" aria-label={t('about')} icon={Svg.info} onClick={() => setAboutOpen(true)} />
          </Tooltip>
          <Tooltip label={t('config')}>
            <Button variant="ghost" size="sm" aria-label={t('config')} icon={Svg.gear} onClick={() => setConfigOpen(true)} />
          </Tooltip>
          <Tooltip label={t('close')}>
            <Button
              variant="ghost"
              size="sm"
              aria-label={t('close')}
              icon={<IconCloseOutlineRegular />}
              onClick={() => actions.close()}
            />
          </Tooltip>
        </header>
        <div
          className="dshBrowserCtlStatus"
          data-ok={data ? (data.forwarder === false ? 'wait' : 'true') : (busy === 'start' || retrying ? 'wait' : (error ? 'false' : 'wait'))}
        >
          {data
            ? (data.forwarder === false ? t('statusTunnelStarting') : t('statusReady'))
            : (busy === 'start' ? t('starting') : (retrying ? t('statusTunnelBuilding') : (error ? t('statusNoSecret') : t('statusLoading'))))}
          {error && busy !== 'start' && !retrying ? <span title={error} style={{ opacity: 0.8, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{error}</span> : null}
        </div>
        <div className="dshBrowserCtlTabs">
          {TABS.map(tb => (
            <button
              key={tb.id}
              type="button"
              className="dshBrowserCtlTab"
              data-active={tab === tb.id ? 'true' : 'false'}
              disabled={gating}
              onClick={() => setTab(tb.id)}
            >
              <span aria-hidden="true">{Svg[tb.icon]}</span>
              <span>{tb.label}</span>
            </button>
          ))}
        </div>
        <div className="dshBrowserCtlTabBody">
          {tab === 'connect' && (
            <>
              {data && data.svg ? (
                cfgMode === 'official' && !acctMe ? (
                  <div className="dshBrowserCtlQrBox" style={{ height: 128, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <span style={{ color: '#666', fontSize: 12, padding: '0 14px', textAlign: 'center' }}>
                      {t('loginRequiredDesc')}
                    </span>
                  </div>
                ) : (
                <div>
                  <div className="dshBrowserCtlQrBox">
                    <img alt={t('qrAlt')} src={'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(data.svg)} />
                  </div>
                  <p style={{
                    margin: '4px 0 0', fontSize: 12, textAlign: 'center',
                    color: left > 0 ? 'var(--dsw-alias-label-tertiary,#8b8f98)' : 'var(--dsw-alias-state-error-primary,#e5655c)',
                  }}>
                    {left > 0
                      ? <span>
                          {status && status.uses > 1
                            ? <span style={{ color: 'var(--dsw-alias-label-secondary,#666)' }}>{t('pairUses')} {status.remaining}/{status.uses} · </span>
                            : <span>{t('pairOnce')} · </span>}
                          <span style={{ color: left <= 10 ? 'var(--dsw-alias-state-error-primary,#e5655c)' : 'inherit' }}>{t('pairLeft')} {left}s</span>
                        </span>
                      : (data.once ? <span>{t('pairExpired')}</span> : <span style={{ color: 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>{t('pairStatic')}</span>)}
                  </p>
                  {data.once ? (
                    <p style={{ margin: '4px 0 0', fontSize: 11, textAlign: 'center', color: 'var(--dsw-alias-label-tertiary,#8b8f98)' }}>
                      {t('pairAppTempNote')}
                    </p>
                  ) : null}
                </div>
                )
              ) : (
                <div className="dshBrowserCtlQrBox" style={{ height: 128 }}>
                  {busy === 'start' ? (
                    <span className="dshBrowserCtlQrLoading">
                      <span className="dshBrowserCtlSpinner" aria-hidden="true" />
                      {t('starting')}
                    </span>
                  ) : retrying ? (
                    // 隧道正在自愈:自动轮询中,二维码一就绪就会出现,不需要用户再点一次
                    <span className="dshBrowserCtlQrLoading">
                      <span className="dshBrowserCtlSpinner" aria-hidden="true" />
                      {t('statusTunnelBuilding')}
                    </span>
                  ) : startErr ? (
                    <span style={{
                      color: 'var(--dsw-alias-state-error-primary,#e5655c)', fontSize: 11,
                      padding: '0 12px', textAlign: 'left', whiteSpace: 'pre-wrap',
                      overflowY: 'auto', maxHeight: 120, lineHeight: 1.5, display: 'block',
                    }}>
                      {t('startFailed')}{'\n'}{startErr}
                    </span>
                  ) : error ? (
                    // 二维码/配对接口失败(最常见:frp 隧道未连通,host 半直接回 503)时
                    // 把原因原文显示在二维码位置,而不是只显示一句"没有可用链接"让用户猜。
                    <span style={{
                      color: 'var(--dsw-alias-state-error-primary,#e5655c)', fontSize: 11,
                      padding: '0 12px', textAlign: 'left', whiteSpace: 'pre-wrap',
                      overflowY: 'auto', maxHeight: 120, lineHeight: 1.5, display: 'block',
                    }}>
                      {error}
                    </span>
                  ) : (
                    <span style={{ color: '#666', fontSize: 12, padding: '0 14px', textAlign: 'center' }}>
                      {t('statusLoading')}
                    </span>
                  )}
                </div>
              )}
              {data && !(cfgMode === 'official' && !acctMe) && (
                <div className="dshBrowserCtlUrlRow">
                  <div className="dshBrowserCtlUrl" title={data.url}>{data.url}</div>
                  <Button variant="ghost" size="sm" onClick={() => {
                    navigator.clipboard?.writeText(data.url).then(() => setCopied(true)).catch(() => {})
                  }}>{copied ? t('copied') : t('copyLink')}</Button>
                </div>
              )}
              {data && data.grant && !(cfgMode === 'official' && !acctMe) && (
                <div className="dshBrowserCtlUrlRow" style={{ marginTop: 6, gap: 6 }}>
                  <span style={{ fontSize: 12, color: 'var(--dsw-alias-label-tertiary,#8b8f98)', whiteSpace: 'nowrap' }}>{t('pairUsesLabel')}</span>
                  <select
                    value={uses}
                    disabled={gating}
                    onChange={e => setUses(parseInt(e.target.value, 10) || 1)}
                    style={{
                      fontSize: 12, padding: '2px 4px', borderRadius: 6,
                      border: '1px solid rgba(128,128,128,.35)', background: 'transparent',
                      color: 'inherit', flex: 'none',
                    }}
                  >
                    {[1, 2, 3, 5, 10].map(n => (
                      <option key={n} value={n}>{n === 1 ? t('pairUsesOne') : n + ' ' + t('pairUsesTimes')}</option>
                    ))}
                  </select>
                  <Button variant="ghost" size="sm" disabled={gating} onClick={refresh}>{t('pairSwap')}</Button>
                </div>
              )}
              <IosGuideCard t={t} reloadToken={reloadToken} />
              {elevNeed && canElevate && (
                <div style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6,
                  margin: '8px 0 0', flex: '0 0 auto',
                }}>
                  <span style={{
                    fontSize: 11, lineHeight: 1.5, textAlign: 'center',
                    color: 'var(--dsw-alias-state-error-primary,#e5655c)',
                  }}>
                    {elevNeed === 'stop' ? t('elevateStopHint') : t('elevateHint')}
                  </span>
                  <Button variant="secondary" size="sm" disabled={gating} onClick={() => elevateChain(elevNeed)}>
                    {busy === 'elevate'
                      ? (<><span className="dshBrowserCtlSpinner" aria-hidden="true" /> {t('elevating')}</>)
                      : (elevNeed === 'stop' ? t('elevateStop') : t('elevateStart'))}
                  </Button>
                </div>
              )}
              <div className="dshBrowserCtlActions">
                {!data && (
                  <Button variant="primary" size="sm" disabled={gating} onClick={startChain}>
                    {busy === 'start'
                      ? (<><span className="dshBrowserCtlSpinner" aria-hidden="true" /> {t('starting')}</>)
                      : t('startCtl')}
                  </Button>
                )}
                <Button variant="secondary" size="sm" disabled={gating} onClick={refreshAll}>
                  {busy === 'refresh' ? t('refresh') + '…' : t('refresh')}
                </Button>
                {data && data.panel && !(cfgMode === 'official' && !acctMe) && (
                  <Button variant="primary" size="sm" disabled={gating} onClick={openPanelChain}>
                    {busy === 'open'
                      ? (<><span className="dshBrowserCtlSpinner" aria-hidden="true" /> {t('opening')}</>)
                      : t('openPanel')}
                  </Button>
                )}
                {data && !data.panel && !(cfgMode === 'official' && !acctMe) && (
                  <span style={{ fontSize: 12, color: 'var(--dsw-alias-label-tertiary,#8b8f98)', display: 'inline-flex', alignItems: 'center' }}>{t('loginRequired')}</span>
                )}
                {data && (
                  <Button variant="secondary" size="sm" disabled={gating} onClick={stopChain}
                      style={{ color: 'var(--dsw-alias-state-error-primary,#e5655c)' }}>
                      {busy === 'stop'
                        ? (<><span className="dshBrowserCtlSpinner" aria-hidden="true" /> {t('stopping')}</>)
                        : t('stopCtl')}
                    </Button>
                )}
              </div>
            </>
          )}
          {tab === 'devices' && (
            <DevicesSection t={t} reloadToken={reloadToken} onRefresh={() => setReloadToken(x => x + 1)} disabled={gating} />
          )}
          {tab === 'totp' && (
            <TotpCard t={t} reloadToken={reloadToken} onRefresh={() => setReloadToken(x => x + 1)} disabled={gating} />
          )}
          {tab === 'app' && (
            <AppPairCard t={t} reloadToken={reloadToken} />
          )}
          {tab === 'push' && (
            <PushCard t={t} reloadToken={reloadToken} />
          )}
          {tab === 'ban' && (
            <BlacklistCard t={t} reloadToken={reloadToken} disabled={gating} />
          )}
          {tab === 'log' && (
            <LogCard t={t} reloadToken={reloadToken} />
          )}
        </div>
      </section>
      {aboutOpen && <AboutPanel t={t} onClose={() => setAboutOpen(false)} />}
      {configOpen && <ConfigPanel t={t} onClose={() => setConfigOpen(false)} onSaved={refreshAll} />}
      {accountOpen && (
        <AccountLoginModal t={t} onClose={() => setAccountOpen(false)} onSaved={refreshAll} />
      )}
      {ticketOpen && (
        <TicketModal t={t} onClose={() => setTicketOpen(false)} />
      )}
      {loginPrompt && (
        <div className="dshBrowserCtlOverlay dshBrowserCtlLoginPrompt" role="dialog" aria-modal="true" aria-label={t('loginRequired')}>
          <button className="dshBrowserCtlOverlayMask" type="button" aria-label={t('close')} onClick={() => setLoginPrompt(false)} />
          <section className="dshBrowserCtlPanel">
            <header className="dshBrowserCtlHeader">
              <div>
                <h1>{t('loginRequired')}</h1>
              </div>
              <Tooltip label={t('close')}>
                <Button variant="ghost" size="sm" aria-label={t('close')} icon={<IconCloseOutlineRegular />} onClick={() => setLoginPrompt(false)} />
              </Tooltip>
            </header>
            <div className="dshBrowserCtlLoginPromptBody">
              <p className="dshBrowserCtlLoginPromptText">{t('loginRequiredDesc')}</p>
              <div className="dshBrowserCtlLoginPromptActions">
                <Button variant="secondary" size="sm" onClick={() => setLoginPrompt(false)}>
                  {t('cancel')}
                </Button>
                <Button variant="primary" size="sm" onClick={() => { setLoginPrompt(false); setAccountOpen(true) }}>
                  {t('aboutAccount')}
                </Button>
              </div>
            </div>
          </section>
        </div>
      )}
    </div>
  )
}

function BrowserCtlButton({ wide, useStore, actions, t }) {
  const open = useStore(state => state.open)
  return (
    <Tooltip label={t('tab')} delayMs={500} disabled={wide}>
      <Button
        variant="ghost"
        className="dshBrowserCtlLauncher"
        data-wide={wide ? 'true' : 'false'}
        aria-label={t('tab')}
        aria-haspopup="dialog"
        aria-expanded={open}
        icon={<CtlIcon size={wide ? 16 : 18} />}
        onClick={() => {
          // 点按钮时顺手拉起隧道(不阻塞打开弹窗)
          fetch(API_P + '/browserctl/api/ensure', { cache: 'no-store' }).catch(() => {})
          actions.open()
        }}
      >
        {wide ? t('tab') : null}
      </Button>
    </Tooltip>
  )
}


export const inject = ['slots', 'locale']

export function apply(ctx) {
  const view = defineStore({
    init: () => ({ open: false }),
    actions: {
      open: draft => { draft.open = true },
      close: draft => { draft.open = false },
    },
  })
  ctx.effect(() => ctx.locale.register(NS, {
    zh: {
      tab: 'DSH 远程助手',
      tabConnect: '连接',
      tabDevices: '设备',
      tab2fa: '2FA',
      tabBan: '黑名单',
      tabLog: '日志',
      tabApp: 'App 配对',
      tabPush: '推送',
      appSubtitle: '手机 App 扫一次,之后打开免扫码直连',
      appQrAlt: '手机 App 长期配对二维码',
      appLoading: '正在生成长期配对码…',
      appReady: '长期配对码已生成',
      appFailed: '配对码生成失败',
      appOnceHint: '这是长期配对码:手机 App 扫码后登记设备并保存登录状态,之后打开免扫码直连。若扫「连接」页的一次性二维码,只会获得 1 小时临时会话,不会长期绑定。',
      appRefresh: '刷新配对码',
      appCopyLink: '复制配对链接',
      appNoQr: '长期配对码不可用',
      subtitle: '手机扫码或复制链接,直接打开本机助手面板',
      about: '关于',
      config: '配置',
      aboutAccount: '账号登录',
      aboutAccountLogged: '已登录',
      loginRequired: '需要先登录',
      loginRequiredDesc: '使用官方服务器需要先登录账号,登录后才会分配专属入口。点击下方按钮前往登录。',
      startFailed: '启动失败:',
      aboutDesc: '把本机 DeepSeek 助手 Web 面板安全穿透到手机或外网浏览器,随时随地远程控制。',
      aboutWebsite: '官网',
      aboutGithub: 'GitHub',
      aboutApp: 'App 下载',
      aboutQq: '加入QQ群',
      updateCheck: '检查更新',
      updateChecking: '检查中…',
      updateRecheck: '重新检查',
      updateCur: '当前版本',
      updateLst: '最新版本',
      updateFound: '发现新版本 v{v}',
      updateDownload: '下载新版本',
      updateNotesTitle: '更新说明',
      updateUpToDate: '已是最新版本',
      updateFailed: '更新检查失败',
      legalTerms: '用户协议',
      legalPrivacy: '隐私政策',
      legalMeta: '生效 {d} · 版本 {v}',
      legalAck: '我知道了',
      configSubtitle: '选择连接官方服务器或你自己的 frps 服务器',
      configOfficial: '官方服务器',
      configOfficialHint: '注册 / 登录官方账号,开箱即用',
      configOfficialNote: '使用官方服务器:登录(或注册)账号后自动分配专属入口,无需手工填写任何服务器信息。',
      configAcctTitle: '官方账号',
      configAcctLoggedIn: '已登录',
      configAcctPort: '专属端口',
      configAcctLogout: '退出登录',
      configAcctLoggingOut: '退出中…',
      configAcctLoggedOut: '已退出(隧道将断开,重新登录可恢复)',
      configAcctOauthBtn: '登录 / 注册官方账号',
      configAcctOauthHint: '将打开浏览器跳转官网,在网页完成登录/注册后自动回调',
      configAcctOauthOpening: '正在打开浏览器…',
      configAcctOauthWait: '等待授权…',
      configAcctOauthOpenBrowser: '已打开浏览器:请在官网页面登录账号并点「确认授权」。若未自动打开,请点下方按钮重试。',
      configAcctOauthOpenAgain: '重新打开授权页',
      configAcctOauthOpenFail: '自动打开浏览器失败:请点下方链接手动打开授权页。',
      configAcctCopy: '复制链接',
      configAcctCopied: '已复制',
      configAcctOauthCancel: '取消',
      configAcctOauthExpired: '授权已过期,请重新发起。',
      configAcctOauthFail: '授权失败:',
      configAcctOauthNetwork: '官方服务器暂时不可达,请稍后再试。',
      configAcctOauthDone: '授权成功,正在应用账号与专属端口…',
      configAcctRestartFail: '登录成功,但隧道重启失败:请点「开始控制」手动启动。',
      configAcctLoadFail: '官方服务器暂时不可达,请稍后再试。',
      configSelfhost: '自建服务器',
      configSelfhostHint: '使用你自己的 frps 服务器',
      configHost: '服务器地址 (host)',
      configHostPh: '例如 frps.example.com',
      configPort: 'frps 端口',
      configRemotePort: '远程端口 (可选)',
      configToken: 'FRP token',
      configTokenPh: '输入 frps 认证 token',
      configTokenKeep: '已保存(留空保持不变)',
      configTokenNote: 'Token 仅保存在本机 browserctl_secrets.json(已被 gitignore 排除,不会提交或上传)。',
      configHostRequired: '请填写服务器地址',
      save: '保存',
      saving: '保存中…',
      saved: '已保存',
      cancel: '取消',
      close: '关闭',
      startCtl: '开始控制',
      starting: '正在启动隧道…',
      stopCtl: '停止控制',
      stopping: '正在停止…',
      elevateStart: '以管理员身份启动',
      elevateStop: '以管理员身份停止',
      elevating: '等待提权确认…',
      elevateHint: '若失败原因是杀软拦了 frpc.exe 或被权限挡住,点下面按钮用管理员权限重试(Windows 会弹 UAC 确认框)。',
      elevateStopHint: '停止没生效:这套进程可能以管理员身份在跑,普通权限杀不掉。',
      copyLink: '复制链接',
      copied: '已复制',
      refresh: '刷新二维码',
      openPanel: '打开面板',
      opening: '正在打开…',
      openFailed: '打开面板失败',
      qrAlt: '配对二维码',
      pairOnce: '一次性配对链接',
      pairLeft: '剩余',
      pairExpired: '配对已过期,点"刷新二维码"重新生成',
      pairStatic: '引导链接(24 小时有效)',
      pairAppTempNote: '手机 App 扫此码只获得 1 小时临时会话,不会长期绑定;要长期免扫码请用「App 配对」页签。',
      pairUses: '已扫码',
      pairUsesLabel: '扫码次数',
      pairUsesOne: '1 次(扫完换码)',
      pairUsesTimes: '次',
      pairSwap: '换一个码',
      linkTitle: 'iOS / 无 App 设备',
      linkSubtitle: '给没有 App 的设备(iPhone / iPad)生成一条长期引导链接:打开一次即免验证 30 天,再「添加到主屏幕」当 App 用。',
      linkTtlLabel: '链接有效期',
      linkTtl1h: '1 小时',
      linkTtl24h: '24 小时',
      linkTtl7d: '7 天',
      linkGenerate: '生成引导链接',
      linkGenerating: '正在生成…',
      linkRegenerate: '重新生成',
      linkCopy: '复制链接',
      linkCopied: '已复制',
      linkReady: '链接已生成',
      linkQrAlt: '引导链接二维码',
      linkScanHint: '用 iPhone 相机直接扫这个码即可打开(也可复制下方链接)。',
      linkExpires: '有效期至 {t}',
      linkUsesLabel: '可用次数',
      linkUses1: '1 次(一次性)',
      linkUses3: '3 次',
      linkUses5: '5 次',
      linkUsesUnlimited: '不限次数',
      linkUsesSuffix: '可用 {n} 次',
      linkStepsTitle: 'iPhone 操作步骤',
      linkStep1: '用 Safari 打开这条链接并完成一次验证,进入面板(地址栏应以 /p/<端口>/ 或 /dsh-remote/p/… 开头;不要用微信内置浏览器,不要开无痕模式)',
      linkStep2: '在面板页面上点 Safari 底部「分享」→「添加到主屏幕」(不要在引导链接页上加:这条链接是一次性的,用完即失效)',
      linkStep3: '从主屏幕图标打开:这是独立窗口,Cookie 与 Safari 互不相通,需要再完成一次动态码验证',
      linkStep4: '之后点主屏图标 30 天内免验证;Safari 与主屏 App 各自独立,互不影响',
      linkNote: '链接是明文,别发公开群;介意就把有效期调短,用完后可「重新生成」。',
      statusLoading: '正在生成二维码…',
      statusReady: '隧道就绪,扫码即可打开面板',
      statusTunnelStarting: '隧道正在建立,请稍候几秒后刷新二维码',
      statusTunnelBuilding: '隧道正在建立,几秒后自动出二维码(无需再点「开始控制」)',
      statusNoSecret: '隧道未就绪:点下方"开始控制"启动本机穿透,几秒后自动出二维码',
      totpTitle: '两步验证 (2FA)',
      totpOn: '已启用',
      totpOff: '未启用',
      totpHint: '启用后,所有设备打开面板前必须先输入验证器 6 位动态码(RFC 6238);连错 5 次冻结 15 分钟,同码防重放。绑定方式:用手机验证器扫描下方二维码或手动输入密钥。',
      totpHintShort: '开启后,手机打开面板需先输入验证器 6 位动态码;连错 5 次冻结 15 分钟。',
      totpBind: '2FA 绑定二维码',
      totpSecretLabel: '密钥(手动输入用)',
      totpEnable: '启用 2FA',
      totpDisable: '禁用 2FA',
      totpReset: '重置密钥',
      totpKick: '全部踢下线',
      devicesTitle: '在线设备',
      devicesOnline: '在线 {n} 台',
      noDevices: '暂无已验证设备',
      noOnlineDevices: '当前没有设备在线',
      noDevicesHint: '手机扫码打开面板并通过动态码验证后,设备会显示在这里;本机直开的面板不计入。',
      deviceSeen: '活跃:',
      deviceKick: '踢下线',
      copySecret: '复制密钥',
      logTitle: '运行日志',
      logEmpty: '暂无日志。设备验证、踢下线、2FA 开关都会记录在这里。',
      banTitle: 'IP 黑名单',
      banEmpty: '暂无被封禁的 IP 地址。在设备列表点“拉黑”可添加。',
      pushTitle: '消息推送',
      pushDesc: '把设备连入、被踢、黑名单、2FA、配对等安全事件,以及系统消息实时推送到你的手机。',
      pushOn: '已开启',
      pushOff: '未开启',
      pushEnabledLabel: '接收手机推送',
      pushEnabledHint: '总开关:开启后手机可收到本机面板的推送消息',
      pushSystemLabel: '系统安全事件',
      pushSystemHint: '设备连入 / 被踢 / 黑名单 / 2FA / 配对',
      pushTest: '发送测试推送',
      pushTesting: '发送中…',
      pushTestTitle: '测试推送',
      pushTestBody: '这是一条来自 DSH 远程助手的测试推送消息',
      pushTestOk: '测试推送已发送',
      pushTestFail: '测试推送发送失败',
      pushComposerTitle: '发送消息',
      pushComposerHint: '发送后,手机 App 与本机通知中心都会弹出这条消息',
      pushMsgTitleLabel: '标题(可选)',
      pushMsgTitlePh: '不填则只显示消息内容',
      pushMsgBodyLabel: '内容',
      pushMsgBodyPh: '输入要推送的消息…',
      pushSend: '发送',
      pushSending: '发送中…',
      pushSendOk: '消息已推送',
      pushSendOff: '推送开关未开启,消息未发出',
      pushSendFail: '消息发送失败',
      pushSaveFailed: '设置保存失败',
      pushRecent: '最近推送',
      pushRefresh: '刷新',
      pushRefreshing: '刷新中…',
      pushEmpty: '暂无推送。开启推送后,安全事件会显示在这里。',
      pushPollFailed: '读取推送配置失败',
      pushKindTest: '测试',
      pushKindVerify: '验证',
      pushKindKick: '踢下线',
      pushKindBan: '黑名单',
      pushKindTotp: '2FA',
      pushKindPair: '配对',
      pushKindJoin: '设备连入',
      pushKindDev: '设备',
      pushKindMsg: '消息',
      // ---- 顶栏通知中心(铃铛) ----
      msgCenter: '通知中心',
      msgEmpty: '暂无通知',
      msgLoadFail: '通知加载失败',
      msgOfficial: '官方公告',
      msgPersonal: '发给我的',
      msgOpenLink: '查看链接',
      msgGuestHint: '当前显示全员公告;登录官方账号后可接收发给你的定向消息。',
      // ---- 工单反馈(导出日志 → 网页端提交) ----
      tickets: '工单反馈',
      ticketExportSubtitle: '导出本机诊断日志（自动打码），然后选择日志去向。',
      ticketExportDo: '生成并导出诊断日志',
      ticketExporting: '正在导出…',
      ticketExportAgain: '重新导出',
      ticketExportDone: '已导出到：',
      ticketDestTitle: '导出去向',
      ticketOpenWeb: '打开网页版工单',
      ticketOpenWebDesc: '推荐：登录后在网页端提交工单，并把这份 txt 作为「运行日志」上传。',
      ticketSaveOther: '存到其他文件夹',
      ticketSaveOtherDesc: '把这份日志再存一份到你选的文件夹。',
      ticketCopyContent: '复制日志内容',
      ticketCopyContentDesc: '把已打码的全文复制到剪贴板，可直接粘贴给别人。',
      ticketOpenFolder: '打开所在文件夹',
      ticketOpening: '正在打开…',
      ticketCopyPath: '复制路径',
      ticketCopyPathOk: '路径已复制',
      ticketCopyOk: '日志内容已复制到剪贴板',
      ticketCopyFail: '复制失败，请打开导出的 txt 手动复制。',
      ticketSavePathPh: '粘贴文件夹完整路径，如 C:\\Users\\你\\Documents',
      ticketSaveGo: '保存到这里',
      ticketSaving: '正在保存…',
      ticketSaveOk: '已另存到：',
      ticketNoContent: '日志还没生成，请先「生成并导出诊断日志」。',
      ticketExportNote: '日志只在本机生成、不会自动上传；何时上传、上传哪一版完全由你在网页端决定。',
      ticketExportHostOld: '插件宿主还是旧版本（新功能要完全重启 DSH 才生效）。请彻底退出 DSH 再重新打开，然后重试。',
      pushKindAnnounce: '公告',
    },
    en: {
      tab: 'DshRemote',
      tabConnect: 'Connect',
      tabDevices: 'Devices',
      tab2fa: '2FA',
      tabBan: 'Blacklist',
      tabLog: 'Log',
      tabApp: 'App Pairing',
      tabPush: 'Push',
      appSubtitle: 'Scan once to pair; the app reconnects without scanning',
      appQrAlt: 'Long-term pairing QR code',
      appLoading: 'Generating long-term pairing code…',
      appReady: 'Long-term pairing code ready',
      appFailed: 'Failed to generate pairing code',
      appOnceHint: 'This is a long-term pairing code: the app registers the device and saves its login, then reconnects without scanning. Scanning the one-time QR on the "Connect" tab only grants a 1-hour temporary session, not a persistent binding.',
      appRefresh: 'Refresh pairing code',
      appCopyLink: 'Copy pairing link',
      appNoQr: 'Long-term pairing code unavailable',
      subtitle: 'Scan or copy the link to open this panel from any device',
      about: 'About',
      config: 'Settings',
      aboutAccount: 'Sign in',
      aboutAccountLogged: 'Signed in',
      loginRequired: 'Sign in required',
      loginRequiredDesc: 'Using the official server requires signing in first; a dedicated entry is assigned after login. Tap below to sign in.',
      startFailed: 'Start failed:',
      aboutDesc: 'Securely tunnel this DeepSeek assistant web panel to your phone or any browser for remote control, anywhere.',
      aboutWebsite: 'Website',
      aboutGithub: 'GitHub',
      aboutApp: 'App Download',
      aboutQq: 'QQ Group',
      updateCheck: 'Check for updates',
      updateChecking: 'Checking…',
      updateRecheck: 'Check again',
      updateCur: 'Current version',
      updateLst: 'Latest version',
      updateFound: 'New version v{v} available',
      updateDownload: 'Download',
      updateNotesTitle: 'Release notes',
      updateUpToDate: 'You are up to date',
      updateFailed: 'Update check failed',
      legalTerms: 'User Agreement',
      legalPrivacy: 'Privacy Policy',
      legalMeta: 'Effective {d} · Version {v}',
      legalAck: 'Got it',
      configSubtitle: 'Connect to the official server or your own frps server',
      configOfficial: 'Official server',
      configOfficialHint: 'Register / sign in to your official account — works out of the box',
      configOfficialNote: 'Official server: sign in (or register) and a dedicated entry is assigned automatically — no server details to fill in.',
      configAcctTitle: 'Official account',
      configAcctLoggedIn: 'Signed in',
      configAcctPort: 'Dedicated port',
      configAcctLogout: 'Sign out',
      configAcctLoggingOut: 'Signing out…',
      configAcctLoggedOut: 'Signed out (tunnel will disconnect; sign in again to restore)',
      configAcctOauthBtn: 'Sign in / Register',
      configAcctOauthHint: 'Your browser will open the official site to sign in / register, then come back automatically',
      configAcctOauthOpening: 'Opening browser…',
      configAcctOauthWait: 'Waiting for approval…',
      configAcctOauthOpenBrowser: 'Browser opened: sign in to your account on the site and click "Approve". If it did not open, use the button below.',
      configAcctOauthOpenAgain: 'Reopen approval page',
      configAcctOauthOpenFail: 'Could not open your browser automatically — open the approval page via the link below.',
      configAcctCopy: 'Copy link',
      configAcctCopied: 'Copied',
      configAcctOauthCancel: 'Cancel',
      configAcctOauthExpired: 'Authorization expired, please start again.',
      configAcctOauthFail: 'Authorization failed:',
      configAcctOauthNetwork: 'Official server unreachable, please try again later.',
      configAcctOauthDone: 'Authorized — applying your account and dedicated port…',
      configAcctRestartFail: 'Signed in, but tunnel restart failed: press "Start" to launch it manually.',
      configAcctLoadFail: 'Official server unreachable, please try again later.',
      configSelfhost: 'Self-hosted server',
      configSelfhostHint: 'Use your own frps server',
      configHost: 'Server address (host)',
      configHostPh: 'e.g. frps.example.com',
      configPort: 'frps port',
      configRemotePort: 'Remote port (optional)',
      configToken: 'FRP token',
      configTokenPh: 'Enter the frps auth token',
      configTokenKeep: 'Saved (leave blank to keep)',
      configTokenNote: 'Token is stored only in local browserctl_secrets.json (gitignored, never committed or uploaded).',
      configHostRequired: 'Server address is required',
      save: 'Save',
      saving: 'Saving…',
      saved: 'Saved',
      cancel: 'Cancel',
      close: 'Close',
      startCtl: 'Start control',
      starting: 'Starting tunnel…',
      stopCtl: 'Stop control',
      stopping: 'Stopping…',
      elevateStart: 'Start as administrator',
      elevateStop: 'Stop as administrator',
      elevating: 'Waiting for elevation…',
      elevateHint: 'If antivirus blocked frpc.exe or permissions got in the way, retry with administrator rights below (Windows will show a UAC prompt).',
      elevateStopHint: 'Stop did not take effect: these processes may be running as administrator.',
      copyLink: 'Copy link',
      copied: 'Copied',
      refresh: 'Refresh QR',
      openPanel: 'Open panel',
      opening: 'Opening…',
      openFailed: 'Failed to open panel',
      qrAlt: 'Pairing QR code',
      pairOnce: 'One-time pairing link',
      pairLeft: 'expires in',
      pairExpired: 'Pairing expired — refresh to generate a new one',
      pairStatic: 'Bootstrap link (valid for 24 hours)',
      pairAppTempNote: 'Scanning this code with the app grants only a 1-hour temporary session; for long-term pairing use the "App pairing" tab.',
      pairUses: 'used',
      pairUsesLabel: 'Uses',
      pairUsesOne: '1 use (rotate after scan)',
      pairUsesTimes: 'uses',
      pairSwap: 'New code',
      linkTitle: 'iOS / No-App devices',
      linkSubtitle: 'Generate a long-lived bootstrap link for devices without the app (iPhone / iPad): open it once to skip verification for 30 days, then "Add to Home Screen" to use it like an app.',
      linkTtlLabel: 'Link validity',
      linkTtl1h: '1 hour',
      linkTtl24h: '24 hours',
      linkTtl7d: '7 days',
      linkGenerate: 'Generate link',
      linkGenerating: 'Generating…',
      linkRegenerate: 'Regenerate',
      linkCopy: 'Copy link',
      linkCopied: 'Copied',
      linkReady: 'Link ready',
      linkQrAlt: 'Bootstrap link QR code',
      linkScanHint: 'Scan this code with the iPhone camera to open it (or copy the link below).',
      linkExpires: 'Valid until {t}',
      linkUsesLabel: 'Max uses',
      linkUses1: '1 (single use)',
      linkUses3: '3 times',
      linkUses5: '5 times',
      linkUsesUnlimited: 'Unlimited',
      linkUsesSuffix: '{n} use(s)',
      linkStepsTitle: 'iPhone steps',
      linkStep1: 'Open the link in Safari and verify once to enter the panel (the address bar should start with /p/<port>/ or /dsh-remote/p/…; not WeChat in-app browser, not private mode)',
      linkStep2: 'On the panel page, tap Share → "Add to Home Screen" (never on the invite page itself: that link is one-time and dies after first use)',
      linkStep3: 'Open the home-screen icon: it is a standalone window with storage separate from Safari, so verify once more there',
      linkStep4: 'Launching from the icon stays verification-free for 30 days; Safari and the home-screen app are independent',
      linkNote: 'The link is plain text — don\'t post it publicly; shorten the validity if concerned, and regenerate after use.',
      statusLoading: 'Generating QR code…',
      statusReady: 'Tunnel ready — scan to open the panel',
      statusTunnelStarting: 'Tunnel starting; refresh the QR in a few seconds',
      statusTunnelBuilding: 'Tunnel is starting — the QR appears automatically in a few seconds (no need to click Start again)',
      statusNoSecret: 'Tunnel not ready: click "Start control" below, QR appears in a few seconds',
      totpTitle: 'Two-Factor Auth (2FA)',
      totpOn: 'Enabled',
      totpOff: 'Disabled',
      totpHint: 'When enabled, every device must pass a 6-digit authenticator code (RFC 6238) before opening the panel; 5 wrong tries lock for 15 minutes; replayed codes are rejected.',
      totpHintShort: 'Devices must enter a 6-digit code to open the panel; 5 wrong tries lock for 15 minutes.',
      totpBind: '2FA binding QR code',
      totpSecretLabel: 'Secret (manual entry)',
      totpEnable: 'Enable 2FA',
      totpDisable: 'Disable 2FA',
      totpReset: 'Reset secret',
      totpKick: 'Kick all devices',
      devicesTitle: 'Online devices',
      devicesOnline: '{n} online',
      noDevices: 'No verified devices yet',
      noOnlineDevices: 'No devices online right now',
      noDevicesHint: 'Devices appear here after opening the panel via the QR link and passing the 2FA code; locally opened panels are not counted.',
      deviceSeen: 'Active:',
      deviceKick: 'Kick',
      copySecret: 'Copy secret',
      logTitle: 'Event log',
      logEmpty: 'No events yet. Device verifications, kicks and 2FA toggles are recorded here.',
      banTitle: 'IP Blacklist',
      banEmpty: 'No banned IPs. Click "Ban" on a device to add.',
      pushTitle: 'Push Notifications',
      pushDesc: 'Realtime push of security events — device connect / kick / blacklist / 2FA / pairing — plus system messages to your phone.',
      pushOn: 'On',
      pushOff: 'Off',
      pushEnabledLabel: 'Receive phone push',
      pushEnabledHint: 'Master switch: receive push from this panel on your phone',
      pushSystemLabel: 'Security events',
      pushSystemHint: 'Device connect / kick / blacklist / 2FA / pairing',
      pushTest: 'Send test push',
      pushTesting: 'Sending…',
      pushTestTitle: 'Test push',
      pushTestBody: 'This is a test push from DSH Remote Assistant',
      pushTestOk: 'Test push sent',
      pushTestFail: 'Failed to send test push',
      pushComposerTitle: 'Send a message',
      pushComposerHint: 'The message pops up on the phone App and in this PC\'s notification centre',
      pushMsgTitleLabel: 'Title (optional)',
      pushMsgTitlePh: 'Leave empty to show the message only',
      pushMsgBodyLabel: 'Content',
      pushMsgBodyPh: 'Type the message to push…',
      pushSend: 'Send',
      pushSending: 'Sending…',
      pushSendOk: 'Message pushed',
      pushSendOff: 'Push is off — message not sent',
      pushSendFail: 'Failed to send message',
      pushSaveFailed: 'Failed to save settings',
      pushRecent: 'Recent pushes',
      pushRefresh: 'Refresh',
      pushRefreshing: 'Refreshing…',
      pushEmpty: 'No pushes yet. Security events will appear here once push is enabled.',
      pushPollFailed: 'Failed to load push config',
      pushKindTest: 'Test',
      pushKindVerify: 'Verify',
      pushKindKick: 'Kick',
      pushKindBan: 'Ban',
      pushKindTotp: '2FA',
      pushKindPair: 'Pair',
      pushKindJoin: 'Connect',
      pushKindDev: 'Device',
      pushKindMsg: 'Message',
      // ---- Header notification centre (bell) ----
      msgCenter: 'Notifications',
      msgEmpty: 'No notifications',
      msgLoadFail: 'Failed to load notifications',
      msgOfficial: 'Announcement',
      msgPersonal: 'For you',
      msgOpenLink: 'Open link',
      msgGuestHint: 'Showing public announcements; sign in to the official account to receive direct messages.',
      // ---- ticket feedback (export logs -> choose destination) ----
      tickets: 'Ticket Feedback',
      ticketExportSubtitle: 'Export the local diagnostic log (auto-redacted), then choose where it goes.',
      ticketExportDo: 'Export diagnostic logs',
      ticketExporting: 'Exporting…',
      ticketExportAgain: 'Export again',
      ticketExportDone: 'Exported to:',
      ticketDestTitle: 'Where the log goes',
      ticketOpenWeb: 'Open web ticket page',
      ticketOpenWebDesc: 'Recommended: sign in, submit the ticket on the web and upload this txt as a log file.',
      ticketSaveOther: 'Save to another folder',
      ticketSaveOtherDesc: 'Keep another copy of this log in a folder you choose.',
      ticketCopyContent: 'Copy log content',
      ticketCopyContentDesc: 'Copy the redacted full text to the clipboard for pasting into a chat.',
      ticketOpenFolder: 'Open folder',
      ticketOpening: 'Opening…',
      ticketCopyPath: 'Copy path',
      ticketCopyPathOk: 'Path copied',
      ticketCopyOk: 'Log content copied to clipboard',
      ticketCopyFail: 'Copy failed — open the exported txt and copy manually.',
      ticketSavePathPh: 'Paste a full folder path, e.g. C:\\Users\\you\\Documents',
      ticketSaveGo: 'Save here',
      ticketSaving: 'Saving…',
      ticketSaveOk: 'Saved to: ',
      ticketNoContent: 'Log not generated yet — click "Export diagnostic logs" first.',
      ticketExportNote: 'Logs are generated locally and never uploaded automatically; you decide what to upload on the web.',
      ticketExportHostOld: 'The plugin host is still the old version (this feature needs a full DSH restart). Quit DSH completely, reopen it, then try again.',
      pushKindAnnounce: 'Announcement',
    },
  }), 'browserctl: dictionaries')
  ctx.effect(() => installStyles(), 'browserctl: styles')
  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'browserctl',
    order: 30,
    label: () => ctx.locale.bind(NS)('tab'),
    locale: NS,
    store: view,
  }, BrowserCtlButton))
  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'browserctl',
    order: 30,
    locale: NS,
    store: view,
  }, BrowserCtlOverlay))
}

// ---- 演示壳导出（只读复用，不影响 apply/inject 运行） ----
export const __demoPanel = { BrowserCtlOverlay, installStyles }
