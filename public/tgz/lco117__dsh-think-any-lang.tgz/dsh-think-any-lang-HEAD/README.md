# dsh-think-any-lang

<p align="center">
  <img src="https://img.shields.io/badge/DeepSeek%20Harness-Plugin-4D6BFE?style=for-the-badge&logo=deepseek" alt="DeepSeek Harness Plugin">
</p>

<div align="center">

[![GitHub Stars](https://img.shields.io/github/stars/lco117/dsh-think-any-lang?style=social)](https://github.com/lco117/dsh-think-any-lang/stargazers)
[![GitHub Forks](https://img.shields.io/github/forks/lco117/dsh-think-any-lang?style=social)](https://github.com/lco117/dsh-think-any-lang/network/members)
[![GitHub Issues](https://img.shields.io/github/issues/lco117/dsh-think-any-lang)](https://github.com/lco117/dsh-think-any-lang/issues)
[![GitHub Pull Requests](https://img.shields.io/github/issues-pr/lco117/dsh-think-any-lang)](https://github.com/lco117/dsh-think-any-lang/pulls)
[![License](https://img.shields.io/badge/License-MIT-blue)](LICENSE)
[![English](https://img.shields.io/badge/🇺🇸_English-Current-blue)](README.en-US.md)
[![简体中文](https://img.shields.io/badge/🇨🇳_简体中文-Available-green)](README.md)

</div>

<div align="center">

[![dsh-plugin](https://img.shields.io/badge/dsh--plugin-46C6FF?style=flat-square&logo=github)](https://github.com/topics/dsh-plugin)
[![Languages](https://img.shields.io/badge/languages-13-4D6BFE?style=flat-square)](index.js)
[![Zero latency](https://img.shields.io/badge/zero%20latency-zero%20extra%20calls-2ea44f?style=flat-square)](index.js)
[![Plain JS](https://img.shields.io/badge/plain%20JS-no%20build-F7DF1E?style=flat-square)](client.js)

</div>

A DeepSeek Harness plugin that adds a **Thinking Language** dropdown under **Settings → General**, letting you choose which language the model uses for its reasoning / chain of thought (中文, English, 日本語, 한국어, Deutsch, …). **The final reply stays in the user's language.**

<p align="center">
  <a href="#screenshots">Screenshots</a> · <a href="#features">Features</a> · <a href="#how-it-works">How it works</a> · <a href="#installation">Installation</a> · <a href="#usage">Usage</a> · <a href="#development">Development</a> · <a href="#publishing">Publishing</a> · <a href="#star-history">Star History</a>
</p>

---


## Screenshots

<table>
  <tr>
    <td align="center" width="50%"><img src="screenshots/01.webp" alt="Thinking language selector in Settings → General"><br><b>Selector in General settings</b><br><sub>Pick it right from the settings page</sub></td>
    <td align="center" width="50%"><img src="screenshots/04.webp" alt="The thinking-language selector box"><br><b>The selector box</b><br><sub>Click to expand and pick a language</sub></td>
  </tr>
  <tr>
    <td align="center" width="50%"><img src="screenshots/02.webp" alt="Expanded language dropdown"><br><b>All languages in one dropdown</b><br><sub>off plus 12 languages in one list</sub></td>
    <td align="center" width="50%"><img src="screenshots/03.webp" alt="dsh-think-any-lang in the plugin list"><br><b>In the plugin list</b><br><sub>Listed under plugin management after install</sub></td>
  </tr>
</table>

---


## Features

- **Settings → General → Thinking Language**: a dropdown to pick the language the model thinks in.
- **Zero latency, zero extra calls**: implemented as a system-prompt instruction (`systemPrompt.section`) — no extra model calls or response delay like "translate the reasoning" approaches.
- **Instructions written in the target language**: each instruction is written in its own language (e.g. the English instruction is written in English), which improves model adherence.
- **Persisted**: the choice is stored in the user settings document (settings service) and survives restarts.
- **Plain JS, no build step**: both the host and browser halves are hand-written JavaScript; install straight from GitHub with zero friction.

Supported languages: `off` (follow default, no instruction), Simplified Chinese, English, 日本語, 한국어, Deutsch, Français, Español, Português, Русский, Italiano, العربية, हिन्दी.

---


## How it works

| Half | Responsibility |
|---|---|
| `index.js` (host half) | Registers the `think-any-lang` settings namespace (`language` field, enum, default `zh`); watches for changes and mounts `systemPrompt.section` (named `think-any-lang`) when non-`off`, unmounts on `off`; also registers a private loopback RPC channel `/think-any-lang` (`get`/`set`) that the browser half uses to read/write the namespace |
| `client.js` (browser half) | Registers a `settings.general.item` row via the `window.__ModuleLoader__.load` contract; renders the dropdown and reads/writes the setting through the host half's `/think-any-lang` RPC channel |

> **Why a private RPC channel instead of the settings RPC surface?** `dsh-host-apiproxy` only exposes an explicit allowlist of settings namespaces to configuration clients (`WEB_SETTINGS_NAMESPACES` / `PRODUCT_SETTINGS_NAMESPACES`); a third-party namespace answers `settings-not-exposed`, so the selection would never persist. The browser half therefore talks to a private channel registered in-process (`ctx.connection.rpc.handle`), and in-process `ctx.settings` access is not filtered by that allowlist — persistence and the `systemPrompt` linkage stay unchanged.

> The language table is maintained in two places — `index.js` (instruction texts) and `client.js` (display labels): the browser factory's `require` only resolves platform modules and cannot read local modules, so each half keeps its own language view. Keep both files in sync when adding a language.

---


## Installation

Requirements: `dsh` CLI installed with an initialized profile (`dsh plugin --profile <name> add` auto-initializes).

### From GitHub (recommended)

```sh
dsh plugin --profile web add github:lco117/dsh-think-any-lang
```

> The package is pure JS with no `prepare` build script, so no pnpm ≥10 `allowBuilds` approval is needed — install straight from GitHub. Pinning to a commit is recommended as in the official docs: `github:lco117/dsh-think-any-lang#<commit-sha>`.

### From a local directory (development)

```sh
dsh plugin --profile web add ./dsh-think-any-lang
```

### Verify

```sh
dsh --profile web --dump-config   # should show a "# == dsh-think-any-lang" layer
```

---


## Usage

1. Start `dsh web`.
2. Open **Settings → General**.
3. Pick a language in the **Thinking Language** dropdown (default: Chinese).
4. Subsequent model calls receive the thinking-language instruction in the system prompt; DeepSeek reasoning models typically output `reasoning_content` in the chosen language.

---


## Development

```
dsh-think-any-lang/
├── package.json       # declares dsh.bundle and dsh.client
├── cordis.patch.yml   # plugin row: mounts both halves of this package
├── index.js           # host half: settings namespace + systemPrompt.section
├── client.js          # browser half: settings row UI (hand-written factory bundle)
├── README.md          # 中文说明
├── README.en-US.md    # English docs
└── screenshots/       # README screenshots (webp)
```

---


## Tech Stack

| Category | Tech |
|------|------|
| Plugin platform | [DeepSeek Harness (DSH)](https://github.com/deepseek-ai/dsh) |
| Plugin framework | Cordis |
| Language | JavaScript (ESM) |
| Schema | @deepseek-ai/schemastery |
| Build | None (plain JS, install straight from GitHub) |

---

## License

[MIT](LICENSE) © 2026 lco117

---


## ⭐ Star History

If this project helps you, give it a ⭐ to help more people discover dsh-think-any-lang.

<a href="https://www.repostars.dev/?repos=lco117%2Fdsh-think-any-lang&theme=ocean">
  <img alt="Star History Chart" src="https://www.repostars.dev/api/embed?repo=lco117%2Fdsh-think-any-lang&theme=ocean" />
</a>