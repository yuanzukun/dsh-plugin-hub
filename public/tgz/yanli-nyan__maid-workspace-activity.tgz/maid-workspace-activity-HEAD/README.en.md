# maid-workspace-activity · Workspace running badge

![Workspace running badge](icon.svg)

[简体中文](README.md) · **English**

Under the **深海女仆工坊** (Maid Atelier) skin (`@smalltailqwq/dsh-client-ui-skin-maid-atelier`),
lets the left sidebar **show at a glance which workspaces have a task running**, without expanding them one by one.

**The skin package is untouched** — this is an independent DSH client UI plugin, so skin upgrades
(0.1.8 → …) never override it.

| Item | Detail |
| --- | --- |
| UI display name | **工作区运行徽标** (from `locale/zh.json`) |
| Package | `@local/maid-workspace-activity` |
| Version | `1.1.0` |
| Shape | DSH web client plugin (the host-side half is an empty stub) |
| Required skin | `@smalltailqwq/dsh-client-ui-skin-maid-atelier` |
| Modifies the skin? | **No**, not a single byte |

## The problem

When the host plugin `@deepseek-ai/dsh-client-ui-workspace` renders the sidebar:

- **workspace group rows** (`ProjectRowItem`, `data-row-key="workspace:<key>"`) only render a folder
  icon, a chevron, a title and a menu button — **there is no running-state slot at all**;
- the status dot (`StateDot`) is attached to **session rows** only: `showStatus = primaryStatus.state !== "idle"`;
- more importantly, in `deriveGroups` the collapsed state is `sessions: expanded ? … : []`, so
  **group rows do not even carry child session data**.

So "which workspaces have a task running" has **nowhere to be shown** at the workspace level;
you have to expand them one by one.

The maid skin turns workspace rows into a visual focal point (54px row height, ribbons, embossed
folders) but inherits this gap from the host, which makes the problem especially glaring under
that skin. The skin itself has no bug — this is how the host is designed.

## How it works

The plugin does three things, none of which touches any rule of the skin or the host:

**1. Workspace row badge**

It writes "workspace → number of running sessions" back onto the host workspace row's **own attributes**:

```html
<!-- this workspace itself has something running -->
<div data-row-key="workspace:ws-xxx" data-maidrun="run" data-maidrun-count="2">

<!-- this one is idle, but collapsed descendants are running (speaks for the subtree) -->
<div data-row-key="workspace:ws-yyy" data-maidrun="run" data-maidrun-count="3" data-maidrun-subtree="1">
```

The badge is drawn entirely by the plugin's **own stylesheet via `::after`** (a breathing
gold-blue gem dot). **No React node is inserted and no host or skin rule is overridden** — the
skin uses no `::after` on workspace rows, so adding one cannot conflict. With
`data-maidrun-subtree="1"` an extra pale-gold ring distinguishes "somewhere in my subtree" from
"this very row is running".

**2. Collapse-aware subtree aggregation**

In **"workspace tree"** group mode the host removes the rows of child workspaces from the DOM when
a parent is collapsed:

```js
// host session tree renderGroup (_asar_ws_client.js:3161)
const childRows = group.expanded ? children.map((child) => renderGroup(child, depth + 1)) : [];
```

Removed rows have nowhere to render, so the plugin **folds their running counts into the nearest
ancestor still in the DOM**: the parent row speaks for the subtree you cannot see, so you can tell
something is running in there without expanding. Once expanded, the child rows come back, each
shows its own state, and the aggregation is undone automatically. With multiple nesting levels it
skips the absent intermediate levels and attributes to the nearest present ancestor.

Parent/child relationships are decided with **exactly the host's own path rules**
(`owningParentFolder` / `folderPath`: Windows backslash normalisation, case-sensitive), so it
matches the host's collapse behaviour.

**3. Persistent capsule + running overlay (bottom left)**

A frame-level persistent component is registered in `shell.overlay` — the only seat that is both
globally persistent and has access to the standard hooks:

| hook | Used for |
|---|---|
| `useWorkspaces` | workspace → `sessionIds` ownership, `path` (parent/child), `title` |
| `useSessionStatus` | whether each session is `running` |

- **Nothing running**: shrinks to a 12px gold ring, not clickable, unobtrusive.
- **Something running**: expands into an "N sessions running" capsule with a pulsing gold dot.
  **Clicking expands the overlay**, listing every running workspace in sidebar order with its
  running session count; **clicking an entry jumps to a running session of that workspace**
  (via the host's `uiWorkspace.openSession`). Click outside or press Esc to close.

The overlay reads the **data layer** rather than the DOM, so it is unaffected by collapsing and is
a reliable fallback for collapsed subtrees: even if row badges break after a host change, the
capsule and overlay keep working.

When row elements are rebuilt, a `MutationObserver` replays the attributes (`childList` plus the
skin marker attribute on body); the plugin writes only `data-maidrun*`, which is not among the
observed attributes, so it never triggers itself. A change in running state also rewrites the
attributes directly through a `useEffect` dependency — sessions starting or stopping usually does
not change DOM structure, only re-renders the same row elements.

## Scope

- **JS**: rows are located only through the host's `data-row-key^="workspace:"`, so it works even
  during the window before the skin has stamped `data-maid-workspace-row` onto a row.
- **CSS**: everything is scoped by `body[data-dsh-maid-atelier]`.
- **When the maid skin is not active the component returns `null`**: all styles are scoped to the
  skin, so rendering elsewhere would expose unstyled bare text. The aggregation logic keeps running
  (hooks must be called unconditionally) — it just draws nothing.

## Semantics

Two states, as required: `running === true` means running, everything else means not running.

> The host also has a `pendingInteraction` state ("waiting for your answer/approval", yellow warning
> dot). This plugin **does not** mark it; it only answers "is a task running". If that distinction
> is wanted later, one more state is enough — the aggregation layer already has room for it.

## Install

### Option 1: the DSH Plugins page (recommended)

In **DSH Desktop → "Plugins" in the left sidebar → Install**, enter any one of these **absolute paths**:

```text
<clone of this repo>\maid-workspace-activity              # directory path, installed with link:
<clone of this repo>\build\maid-workspace-activity-1.1.0.tgz   # build output (build/ is not in git)
<downloaded maid-workspace-activity-1.1.0.tgz>        # or a tarball from Releases, absolute path
```

A directory path is installed with `link:` (that directory **must not be deleted or moved**);
a path ending in `.tgz` is installed as a tarball. Quit and reopen DSH Desktop when done.

> The `desktop` profile is managed exclusively by the Electron application; an independently
> installed `dsh` CLI is rejected (`error: profile "desktop" is managed exclusively by the Electron application`),
> so please use the GUI Plugins page.

### Option 2: the plugin manager inside a dsh session

Use `plugin_manager`'s `install_bundle` with the **absolute directory** above as `target` — equivalent.
("inside a session" here means a dsh CLI session, not this repository.)

## Uninstall

Remove the bundle from the Plugins page (or `remove_bundle`). The injected
`<style id="dsh-maid-workspace-activity">` and every `data-maidrun*` attribute are cleaned up when
the plugin unloads; the skin stays untouched throughout.

## Files

| File | Purpose |
|---|---|
| `package.json` | `dsh.bundle.patch` + `dsh.client` (`platform:"web"`, `immediately:true`) |
| `index.js` | Host-side half, empty implementation |
| `client.js` | Browser half: row badge attributes + collapsed-subtree aggregation + capsule and overlay + stylesheet |
| `cordis.patch.yml` | Mounts the `dsh.client` entry into the web plugin registry |
| `locale/zh.json`, `locale/en.json` | `meta.title` / `meta.description` read by the Plugin Manager |
| `icon.svg` | Plugin icon (original to this plugin, MIT) |
| `README.md` | Chinese README (the default) |
| `README.en.md` | This file |

## Detailed guide

This file covers "install it and use it". The three badge states, the collapsed-subtree
aggregation criteria, the overlay's interaction details and the known limits are all in:

- [docs/详细说明.md](docs/详细说明.md) **(in this repo, written in Chinese)**
- Online: https://github.com/yanli-nyan/maid-workspace-activity/blob/main/docs/详细说明.md

## Tuning points (without touching the plugin)

Badge and capsule positions are exposed as CSS variables; override them in your own skin styles or
any custom stylesheet — **no need to modify this plugin**:

```css
body[data-dsh-maid-atelier] {
  /* distance from the right edge of a workspace row; larger pushes it left. default 11px */
  --maid-workspace-run-badge-inset: 11px;
  /* where the capsule sits in the bottom-left corner. default 14px / 14px */
  --maid-workspace-run-capsule-inset: 14px;
  --maid-workspace-run-capsule-bottom: 14px;
}
```

The overlay's bottom edge follows `--maid-workspace-run-capsule-bottom` (+34px) automatically, so
changing only the capsule variable will not separate the two.

## Known limits

- It depends on the host workspace row attribute `data-row-key="workspace:<id>"`. If the host
  renames it, the badge disappears silently (the capsule and overlay keep working and raise no
  error — they read the data layer, not the DOM).
- Collapsed-subtree aggregation only applies while **rows are genuinely absent from the DOM**. If
  the host later renders collapsed rows but hides them, aggregation stops working; the criterion
  then needs changing (aggregation and rendering are separate layers).
- Navigation uses the host's `uiWorkspace.openSession`. It is a **hard dependency** and is listed
  in `inject` (`['slots', 'locale', 'uiWorkspace']`), with two fallbacks kept: `ctx.get` and
  "click the host's session row".
  > A pitfall we hit: at first only `ctx.get('uiWorkspace')` was used, an optional access of an
  > undeclared dependency. When it failed, overlay rows silently became `disabled` — and
  > **browsers do not dispatch clicks on disabled buttons**, so it looked like "visible, clickable,
  > no reaction whatsoever". Lesson: if you need a Cordis service, declare it in `inject`; do not
  > gamble on `ctx.get`.
- The capsule and overlay use `position: fixed` in the bottom-left corner. If something occludes
  the bottom of the sidebar, `bottom` / `inset-inline-start` may need tuning.
- No pixel-level visual verification has been done in a real browser; further limits are in
  [docs/详细说明.md](docs/详细说明.md).

## Versions

| Version | Changes |
| --- | --- |
| `1.1.0` | Chinese display name, Chinese description, icon and Chinese README; English README added as `README.en.md` |
| `1.0.0` | First release |
