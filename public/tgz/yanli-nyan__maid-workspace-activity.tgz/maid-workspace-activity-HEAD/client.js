// maid-workspace-activity — 浏览器半边。
//
// 问题：宿主 @deepseek-ai/dsh-client-ui-workspace 的工作区分组行（ProjectRowItem）
// 只渲染文件夹图标、箭头、标题与菜单按钮，**没有任何运行状态位**；状态点
// （StateDot）只挂在会话行上。更关键的是折叠状态下 deriveGroups 里
// `sessions: expanded ? ... : []`，组行连子会话数据都不携带。于是"哪些工作区
// 有任务正在跑"在工作区这一级结构上无处可看，必须逐个展开。
//
// 女仆皮肤把工作区行放大成视觉焦点（54px 高、缎带、浮雕文件夹），却继承了宿主
// 的这个缺口，所以问题在皮肤下更刺眼。
//
// 本模块做三件事，皮肤包零改动：
//  1) 工作区行徽标：把「工作区 → 运行中会话数」写回宿主工作区行的自有属性
//     data-maidrun / data-maidrun-count / data-maidrun-subtree，徽标完全由本插件
//     自己的样式表用 ::after 绘制。不插入 React 节点、不覆盖宿主或皮肤的任何规则。
//  2) 折叠感知的子树聚合：宿主在「工作区树」分组下会整段移除被折叠父工作区的
//     子工作区行（renderGroup 里 `group.expanded ? … : []`），那些行不再存在于
//     DOM。所以某工作区的行缺席时，本模块把它的运行数并入最近的已渲染祖先，
//     父行替看不见的子树说话（标 data-maidrun-subtree），不展开也能看出哪里在跑。
//  3) 常驻胶囊 + 运行浮层：在 shell.overlay 注册一个帧级组件，聚合出运行中的
//     工作区；左下角常驻胶囊显示总数，点击展开浮层列出每个运行中的工作区，
//     点一项直接跳到该工作区正在跑的会话。浮层读的是数据层，不受 DOM 折叠影响，
//     所以它同时是被折叠子树的可靠后备。
//
// 皮肤已给工作区行打上 data-maid-workspace-row，但本模块不依赖它（只用
// data-row-key，皮肤未及打标的窗口期同样生效）；CSS 则统一用
// body[data-dsh-maid-atelier] 作用域限定，所以离开女仆皮肤后本插件不产生视觉。
window.__ModuleLoader__.load({
  id: '@local/maid-workspace-activity',
  factory(require) {
    const React = require('react');
    const h = React.createElement;

    const NS = 'maid-workspace-activity';
    const STYLE_ID = 'dsh-maid-workspace-activity';
    const ROW_FLAG = 'data-maidrun';
    const COUNT_FLAG = 'data-maidrun-count';
    const SUBTREE_FLAG = 'data-maidrun-subtree';
    const ROW_KEY_PREFIX = 'workspace:';
    const ROW_SELECTOR = '[data-row-key^="workspace:"]';
    const SKIN_SCOPE_ATTR = 'data-dsh-maid-atelier';
    const CAPSULE_CLASS = 'dsh-maidrun-capsule';
    const PANEL_CLASS = 'dsh-maidrun-panel';

    /**
     * 运行时文案。字典必须扁平（LocaleDict = Record<string, string>），键用点号分段；
     * 包内 locale/*.json 只供插件管理页读 meta，与这里的运行时字典是两件事。
     */
    const DICTS = {
      zh: {
        'capsule.running': '{n} 个会话运行中',
        'capsule.idle': '当前没有任务在运行',
        'capsule.tip': '点击查看运行中的工作区',
        'panel.title': '运行中的工作区',
        'panel.sessions': '{n} 个会话',
        'panel.ungrouped': '未分组',
        'panel.empty': '现在没有正在运行的任务',
      },
      en: {
        'capsule.running': '{n} running',
        'capsule.idle': 'No task running',
        'capsule.tip': 'Click to see running workspaces',
        'panel.title': 'Running workspaces',
        'panel.sessions': '{n} session(s)',
        'panel.ungrouped': 'Ungrouped',
        'panel.empty': 'Nothing is running right now',
      },
    };

    const CSS = `/* 深海女仆工坊：工作区运行徽标 + 常驻运行胶囊 / 浮层（本插件自绘，不覆盖皮肤规则） */

/* ---- 工作区行徽标 ---- */
html body[${SKIN_SCOPE_ATTR}] [data-row-key^="workspace:"][${ROW_FLAG}="run"]::after {
  content: "";
  position: absolute;
  z-index: 3;
  top: 50%;
  /* 距行右边缘的距离，值越大徽标越靠左。可在不改本插件的情况下覆盖这个变量微调。 */
  inset-inline-end: var(--maid-workspace-run-badge-inset, 11px);
  width: 11px;
  height: 11px;
  margin-top: -5.5px;
  border-radius: 50%;
  pointer-events: none;
  background:
    radial-gradient(circle at 36% 30%, #fffaf0f2 0 .6px, #0000 .8px),
    radial-gradient(circle, #b3c6ef 0 1.15px, #6480c0 1.3px 2px, #1b3672 2.15px 3.2px, #0000 3.4px);
  box-shadow: 0 0 7px #e7c780a6;
  animation: dsh-maidrun-breathe 1.6s ease-in-out infinite;
  transition: opacity .18s ease;
}
/* 自身没在跑、纯粹替被折叠的后代说话：加一圈淡金外环，与"就是我本行在跑"区分开。 */
html body[${SKIN_SCOPE_ATTR}] [data-row-key^="workspace:"][${ROW_FLAG}="run"][${SUBTREE_FLAG}="1"]::after {
  outline: 1px solid #c5a46859;
  outline-offset: 2px;
}
html body[${SKIN_SCOPE_ATTR}] [data-row-key^="workspace:"][${ROW_FLAG}="run"]:hover::after {
  opacity: 0;
}

/* ---- 左下角常驻胶囊 ---- */
html body[${SKIN_SCOPE_ATTR}] .${CAPSULE_CLASS} {
  position: fixed;
  z-index: 40;
  /* 同样做成变量，方便不改插件就微调胶囊的落点。 */
  inset-inline-start: var(--maid-workspace-run-capsule-inset, 14px);
  bottom: var(--maid-workspace-run-capsule-bottom, 14px);
  display: inline-flex;
  align-items: center;
  gap: 8px;
  box-sizing: border-box;
  height: 26px;
  padding: 0 13px 0 8px;
  margin: 0;
  border-radius: 999px;
  border: 1px solid #c5a46880;
  color: #f3e3c0;
  font-family: inherit;
  font-size: 12px;
  font-weight: 500;
  line-height: 1;
  letter-spacing: .3px;
  white-space: nowrap;
  appearance: none;
  background: linear-gradient(135deg, #42588fef, #152652f5);
  box-shadow:
    0 10px 24px #02081c7a,
    0 2px 6px #02081c59,
    inset 0 1px #e1cfaa38,
    inset 0 -1px #02081c59;
  cursor: pointer;
  pointer-events: auto;
  transition: transform .18s ease, box-shadow .18s ease, border-color .18s ease,
              height .22s ease, width .22s ease, padding .22s ease, opacity .22s ease;
}
html body[${SKIN_SCOPE_ATTR}] .${CAPSULE_CLASS}:hover {
  border-color: #e0c484d9;
  background: linear-gradient(135deg, #5068a6f5, #1c3062f7);
  box-shadow:
    0 12px 28px #02081c8c,
    0 0 0 1px #c5a4682e,
    inset 0 1px #f0e0be4d;
  transform: translateY(-1px);
}
html body[${SKIN_SCOPE_ATTR}] .${CAPSULE_CLASS}:active {
  transform: translateY(0);
}
html body[${SKIN_SCOPE_ATTR}] .${CAPSULE_CLASS}:focus-visible {
  outline: 2px solid #e0c484d9;
  outline-offset: 2px;
}
/* 无运行：收缩成一枚含蓄的小金环，不打扰，也不可点。 */
html body[${SKIN_SCOPE_ATTR}] .${CAPSULE_CLASS}[data-maidrun-state="idle"] {
  width: 12px;
  height: 12px;
  padding: 0;
  gap: 0;
  border-radius: 50%;
  border-color: #c5a46847;
  background: #c5a46838;
  box-shadow: 0 2px 8px #02081c59, inset 0 1px #e1cfaa26;
  cursor: default;
  pointer-events: none;
}
html body[${SKIN_SCOPE_ATTR}] .${CAPSULE_CLASS}[data-maidrun-state="idle"] .dsh-maidrun-capsule-label {
  display: none;
}
html body[${SKIN_SCOPE_ATTR}] .${CAPSULE_CLASS}[data-maidrun-state="idle"] .dsh-maidrun-capsule-dot {
  width: 6px;
  height: 6px;
  background: #c5a46880;
  box-shadow: none;
  animation: none;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-capsule-dot {
  flex: none;
  width: 9px;
  height: 9px;
  border-radius: 50%;
  background:
    radial-gradient(circle at 35% 30%, #fffcf4f2 0 .7px, #0000 .9px),
    radial-gradient(circle, #ecc97f 0 1.6px, #c39a4e 1.9px 3px, #78561ae6 3.2px 4px, #0000 4.3px);
  box-shadow: 0 0 8px #e7c780b3;
  animation: dsh-maidrun-breathe 1.7s ease-in-out infinite;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-capsule-label {
  white-space: nowrap;
}

/* ---- 运行中工作区浮层 ---- */
html body[${SKIN_SCOPE_ATTR}] .${PANEL_CLASS} {
  position: fixed;
  z-index: 41;
  /* 跟着胶囊走：胶囊底距 + 胶囊高 26px + 8px 间距。 */
  inset-inline-start: var(--maid-workspace-run-capsule-inset, 14px);
  bottom: calc(var(--maid-workspace-run-capsule-bottom, 14px) + 34px);
  box-sizing: border-box;
  width: 252px;
  max-height: 46vh;
  display: flex;
  flex-direction: column;
  padding: 6px;
  border-radius: 14px;
  border: 1px solid #c5a4686b;
  color: #f2e4c4;
  font-family: inherit;
  font-size: 12px;
  background: linear-gradient(160deg, #2b3c6ef7, #0f1b3cfa);
  box-shadow: 0 18px 40px #02081c99, inset 0 1px #e1cfaa29;
  pointer-events: auto;
  animation: dsh-maidrun-panel-in .16s ease-out;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-head {
  display: flex;
  align-items: center;
  gap: 7px;
  padding: 4px 8px 7px;
  margin-bottom: 4px;
  border-bottom: 1px solid #c5a4682e;
  color: #d9bd83;
  font-size: 11px;
  letter-spacing: .6px;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-title {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-dot,
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-item-dot {
  flex: none;
  border-radius: 50%;
  background:
    radial-gradient(circle at 35% 30%, #fffcf4e6 0 .5px, #0000 .7px),
    radial-gradient(circle, #ecc97f 0 1.2px, #c39a4e 1.5px 2.3px, #78561ad9 2.5px 3.2px, #0000 3.5px);
  box-shadow: 0 0 6px #e7c7808c;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-dot {
  width: 8px;
  height: 8px;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-item-dot {
  width: 7px;
  height: 7px;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-total,
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-count {
  flex: none;
  color: #d9bd83;
  font-variant-numeric: tabular-nums;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-height: 0;
  overflow-y: auto;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-item {
  display: flex;
  align-items: center;
  gap: 8px;
  box-sizing: border-box;
  width: 100%;
  padding: 7px 9px;
  margin: 0;
  border: 0;
  border-radius: 8px;
  color: inherit;
  font-family: inherit;
  font-size: 12px;
  line-height: 1.35;
  text-align: start;
  appearance: none;
  background: #0000;
  cursor: pointer;
  transition: background .14s ease;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-item:hover {
  background: #5b77bc3d;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-item:focus-visible {
  outline: 1px solid #e0c484b3;
  outline-offset: -1px;
}
/* 无处可跳的行：明确画成"说明性"而非"可点"，避免看起来能点却没反应。 */
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-item[data-maidrun-static="1"] {
  cursor: default;
  opacity: .72;
  padding-inline-start: 6px;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-item[data-maidrun-static="1"]:hover {
  background: #0000;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-name {
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-panel-empty {
  padding: 14px 10px 16px;
  color: #cbb489;
  text-align: center;
}

@keyframes dsh-maidrun-breathe {
  0%, 100% { opacity: 1; }
  50% { opacity: .38; }
}
@keyframes dsh-maidrun-panel-in {
  from { opacity: 0; transform: translateY(6px); }
  to { opacity: 1; transform: translateY(0); }
}
@media (prefers-reduced-motion: reduce) {
  html body[${SKIN_SCOPE_ATTR}] [data-row-key^="workspace:"][${ROW_FLAG}="run"]::after,
  html body[${SKIN_SCOPE_ATTR}] .dsh-maidrun-capsule-dot {
    animation: none;
  }
  html body[${SKIN_SCOPE_ATTR}] .${PANEL_CLASS} {
    animation: none;
  }
  html body[${SKIN_SCOPE_ATTR}] .${CAPSULE_CLASS} {
    transition: none;
  }
}
`;

    /** 插入（或重插）样式表，返回移除函数。 */
    function installStyles() {
      const previous = document.getElementById(STYLE_ID);
      if (previous) previous.remove();
      const tag = document.createElement('style');
      tag.id = STYLE_ID;
      tag.setAttribute('data-dsh-maid-workspace-activity', '1');
      tag.textContent = CSS;
      (document.head || document.documentElement).appendChild(tag);
      return () => tag.remove();
    }

    /** head 还没出现时等它就绪，返回移除函数。 */
    function installStylesWhenReady() {
      if (document.head) return installStyles();
      let dispose = null;
      const observer = new MutationObserver(() => {
        if (!document.head) return;
        observer.disconnect();
        dispose = installStyles();
      });
      observer.observe(document.documentElement, { childList: true, subtree: true });
      return () => {
        observer.disconnect();
        if (dispose) dispose();
      };
    }

    /** 是否有会话正在运行。只认 running；等待审批/回答不属于本次的两态语义。 */
    function isRunning(status) {
      return status !== undefined && status !== null && status.running === true;
    }

    /** 路径归一化。与宿主 folderPath 同规则，保证父子判定一致。 */
    function folderPath(path) {
      if (typeof path !== 'string') return '';
      const win = /^[A-Za-z]:[/\\]/.test(path) || path.startsWith('\\\\');
      return (win ? path.replaceAll('\\', '/') : path).replace(/\/+$/, '');
    }

    /**
     * 找最近的已注册祖先目录（不含自身）。与宿主 owningParentFolder 同规则：
     * 路径用 Host 原样拼写、大小写敏感。
     */
    function owningParentFolder(path, parents) {
      const child = folderPath(path);
      let owner;
      let length = -1;
      for (let i = 0; i < parents.length; i += 1) {
        const root = folderPath(parents[i]);
        if (root.length > length && child !== root && child.startsWith(root + '/')) {
          owner = parents[i];
          length = root.length;
        }
      }
      return owner;
    }

    /** 工作区展示名：优先 title，退回目录名，再退回 id。 */
    function workspaceTitle(workspace) {
      const title = workspace && workspace.title;
      if (typeof title === 'string' && title.trim() !== '') return title;
      const path = workspace && workspace.path;
      if (typeof path === 'string' && path !== '') {
        const parts = path.replace(/[/\\]+$/, '').split(/[/\\]/);
        const last = parts[parts.length - 1];
        if (last) return last;
        return path;
      }
      return String((workspace && workspace.workspaceId) || '');
    }

    /**
     * locale 座位缺席时的内联兜底：只认 zh 文案，其余返回键名。
     * 注意 t 本身不做插值（pet 也是 t(key).replace("{n}", …)），所以这里统一
     * 把 {n} 替换交给 fill()。
     */
    function fallbackTranslate(key) {
      const template = DICTS.zh[key];
      return template === undefined ? key : template;
    }

    /**
     * 把 t 的产物里的 {n} 换成实际数字。宿主 locale 的 translate 只做查表，
     * 不解析占位符（pet 同样自己 replace），所以插值必须由调用方完成。
     */
    function fill(text, n) {
      if (typeof text !== 'string') return String(text === undefined ? '' : text);
      return text.replace('{n}', String(n));
    }

    /**
     * 取翻译函数。优先用 locale 服务绑定的 t；一旦它没命中字典（返回值等于键名，
     * 说明该命名空间的字典没注册上，或当前语言缺这一条），就回落到内联 zh 字典，
     * 保证界面上永远不会出现 `capsule.running` 这样的原始键。
     */
    function makeTranslate(ctx) {
      const locale = ctx && ctx.locale;
      const bound = locale && typeof locale.bind === 'function' ? locale.bind(NS) : null;
      if (typeof bound !== 'function') return fallbackTranslate;
      return function t(key) {
        try {
          const text = bound(key);
          if (typeof text === 'string' && text !== '' && text !== key) return text;
        } catch (error) {
          // 查表抛错时同样回落，不让文案问题拖垮组件。
        }
        return fallbackTranslate(key);
      };
    }

    /** 清掉本插件写下的所有徽标属性（卸载，以及离开皮肤时的残留清理）。 */
    function clearRowFlags() {
      const stale = document.querySelectorAll('[' + ROW_FLAG + '], [' + SUBTREE_FLAG + ']');
      for (let i = 0; i < stale.length; i += 1) {
        stale[i].removeAttribute(ROW_FLAG);
        stale[i].removeAttribute(COUNT_FLAG);
        stale[i].removeAttribute(SUBTREE_FLAG);
      }
    }

    /**
     * 把「工作区 → 运行中会话数」写到宿主工作区行的自有属性上。
     * 只写本插件自己的属性，不触碰宿主的 class / aria / style。
     *
     * 折叠感知：宿主在「工作区树」分组下折叠父工作区时会把子工作区行整段从 DOM
     * 移除（renderGroup 里 `group.expanded ? children.map(…) : []`）。这些行不再有
     * 落点，所以把它们各自的运行数并入「最近的仍在 DOM 中的祖先」，父行就能替
     * 看不见的子树说话。展开后子行重新出现，就会各自就地显示，聚合自动撤销。
     */
    function applyRowFlags(marks) {
      if (!document.body || !document.body.hasAttribute(SKIN_SCOPE_ATTR)) {
        // 换到别的皮肤、或皮肤尚未给 body 打标时，把上一轮写下的属性收干净，
        // 不让残迹留在 DOM 上。
        clearRowFlags();
        return;
      }

      const nodes = document.querySelectorAll(ROW_SELECTOR);
      const nodeById = new Map();
      for (let i = 0; i < nodes.length; i += 1) {
        const node = nodes[i];
        const raw = node.getAttribute('data-row-key') || '';
        nodeById.set(raw.slice(ROW_KEY_PREFIX.length), node);
      }

      const counts = marks.counts;
      const parentOf = marks.parentOf;
      const own = new Map();
      const effective = new Map();

      counts.forEach((count, id) => {
        if (nodeById.has(id)) {
          // 本行在场：就地显示自己的运行数。
          own.set(id, count);
          effective.set(id, (effective.get(id) || 0) + count);
          return;
        }
        // 本行缺席（被折叠的子树，或尚未加载完）：并入最近的在场所祖先。
        let owner = parentOf ? parentOf.get(id) : undefined;
        let guard = 0;
        while (owner !== undefined && !nodeById.has(owner) && guard < 64) {
          owner = parentOf.get(owner);
          guard += 1;
        }
        if (owner !== undefined && nodeById.has(owner)) {
          effective.set(owner, (effective.get(owner) || 0) + count);
        }
      });

      nodeById.forEach((node, id) => {
        const count = effective.get(id) || 0;
        if (count <= 0) {
          node.removeAttribute(ROW_FLAG);
          node.removeAttribute(COUNT_FLAG);
          node.removeAttribute(SUBTREE_FLAG);
          return;
        }
        node.setAttribute(ROW_FLAG, 'run');
        node.setAttribute(COUNT_FLAG, String(count));
        if (count > (own.get(id) || 0)) node.setAttribute(SUBTREE_FLAG, '1');
        else node.removeAttribute(SUBTREE_FLAG);
      });

      // 行被换成别的 key、或干脆被移除后留下的属性的兜底清理。
      const live = new Set(nodeById.values());
      const stale = document.querySelectorAll('[' + ROW_FLAG + '], [' + SUBTREE_FLAG + ']');
      for (let i = 0; i < stale.length; i += 1) {
        const node = stale[i];
        if (live.has(node)) continue;
        node.removeAttribute(ROW_FLAG);
        node.removeAttribute(COUNT_FLAG);
        node.removeAttribute(SUBTREE_FLAG);
      }
    }

    /** 皮肤是否给 body 打了标（本插件的一切可见效果都以此为前提）。 */
    function skinActive() {
      return Boolean(document.body && document.body.hasAttribute(SKIN_SCOPE_ATTR));
    }

    /**
     * 跟随 body 上的皮肤标记。本插件全部 CSS 都限定在女仆皮肤作用域内，
     * 所以离开皮肤时必须什么都不渲染，否则会露出一段没有样式的裸文本。
     */
    function useSkinActive() {
      const [active, setActive] = React.useState(() => skinActive());
      React.useEffect(() => {
        if (!document.body) return undefined;
        const sync = () => setActive(skinActive());
        sync();
        const observer = new MutationObserver(sync);
        observer.observe(document.body, {
          attributes: true,
          attributeFilter: [SKIN_SCOPE_ATTR],
        });
        return () => observer.disconnect();
      }, []);
      return active;
    }

    /** 座位缺少某个标准 hook 时的空实现（保持调用点无条件，避免条件式 hook）。 */
    function noopHook() {
      return undefined;
    }

    /**
     * 帧级常驻组件工厂：唯一一个全局常驻、又能拿到标准 hooks 的座位。
     * 它维护行徽标属性，并画出左下角常驻胶囊与运行浮层。
     *
     * hooks 与 t 都从座位 props 走（shell.overlay 的标准 props 里带
     * useWorkspaces / useSessionStatus），所以这里不需要自己去找服务。
     */
    function makeActivityCapsule(t, canOpenSession, openSession) {
      return function ActivityCapsule(props) {
        const skin = useSkinActive();
        // 两个 hook 无条件调用，只在函数缺失时换成空实现。
        const useStatus = typeof props.useSessionStatus === 'function' ? props.useSessionStatus : noopHook;
        const useWorkspaces = typeof props.useWorkspaces === 'function' ? props.useWorkspaces : noopHook;
        const statuses = useStatus((s) => s);
        const items = useWorkspaces((s) => (s ? s.items : undefined));

        const [open, setOpen] = React.useState(false);

        const marks = React.useMemo(() => {
          const counts = new Map();
          const firstSession = new Map();
          const parentOf = new Map();
          const list = [];
          let total = 0;
          const hasStatuses = statuses && typeof statuses.forEach === 'function';
          const hasLookup = statuses && typeof statuses.get === 'function';

          if (hasStatuses) {
            statuses.forEach((status) => {
              if (isRunning(status)) total += 1;
            });
          }

          if (Array.isArray(items)) {
            const accounted = new Set();

            for (let i = 0; i < items.length; i += 1) {
              const workspace = items[i];
              const id = String(workspace.workspaceId);
              const ids = workspace.sessionIds;
              let count = 0;
              if (Array.isArray(ids) && hasLookup) {
                for (let j = 0; j < ids.length; j += 1) {
                  const sessionId = ids[j];
                  accounted.add(sessionId);
                  if (!isRunning(statuses.get(sessionId))) continue;
                  if (count === 0) firstSession.set(id, sessionId);
                  count += 1;
                }
              }
              if (count > 0) counts.set(id, count);
            }

            // 未分组会话（不属于任何工作区）在侧栏同样是一个组，key 为空串。
            if (hasStatuses && hasLookup) {
              let strayCount = 0;
              let strayFirst;
              statuses.forEach((status, sessionId) => {
                if (!isRunning(status)) return;
                if (accounted.has(sessionId)) return;
                if (strayCount === 0) strayFirst = sessionId;
                strayCount += 1;
              });
              if (strayCount > 0) {
                counts.set('', strayCount);
                firstSession.set('', strayFirst);
              }
            }

            // 父子关系：与宿主 workspace-tree 分组同一套 path 规则。
            const keysByPath = new Map();
            for (let i = 0; i < items.length; i += 1) {
              const workspace = items[i];
              if (typeof workspace.path === 'string') keysByPath.set(workspace.path, String(workspace.workspaceId));
            }
            const paths = [...keysByPath.keys()];
            for (let i = 0; i < items.length; i += 1) {
              const workspace = items[i];
              const id = String(workspace.workspaceId);
              const owner = owningParentFolder(workspace.path, paths);
              parentOf.set(id, owner === undefined ? undefined : keysByPath.get(owner));
            }

            // 浮层列表按侧栏顺序，保证和用户看到的顺序一致。
            for (let i = 0; i < items.length; i += 1) {
              const workspace = items[i];
              const id = String(workspace.workspaceId);
              const count = counts.get(id);
              if (count === undefined) continue;
              list.push({
                id,
                title: workspaceTitle(workspace),
                count,
                sessionId: firstSession.get(id),
              });
            }
            if (counts.has('')) {
              list.push({
                id: '',
                title: t('panel.ungrouped'),
                count: counts.get(''),
                sessionId: firstSession.get(''),
              });
            }
          }

          return { counts, parentOf, list, total };
        }, [statuses, items]);

        const marksRef = React.useRef(marks);
        marksRef.current = marks;

        // 状态一变就立刻重写徽标。这一步不能只靠 DOM 观察者兜底：会话开始/结束
        // 几乎不改动侧栏结构，只会让宿主重渲同一批行元素，没有 childList 变动。
        React.useEffect(() => {
          applyRowFlags(marks);
        }, [marks]);

        React.useEffect(() => {
          const apply = () => applyRowFlags(marksRef.current);
          let frame = 0;
          const schedule = () => {
            if (frame) return;
            frame = requestAnimationFrame(() => {
              frame = 0;
              apply();
            });
          };
          // 侧栏树由另一个 React 根渲染，行元素的新建/重建本插件看不到。
          // 另外皮肤给 body 打 data-dsh-maid-atelier 可能晚于本插件激活，所以那条
          // 属性也要监听，否则徽标会一直不出现。本插件自己只写 data-maidrun*，
          // 不在 attributeFilter 内，不会自触发。
          const observer = new MutationObserver(schedule);
          observer.observe(document.body, {
            childList: true,
            subtree: true,
            attributes: true,
            attributeFilter: [SKIN_SCOPE_ATTR],
          });
          return () => {
            observer.disconnect();
            if (frame) cancelAnimationFrame(frame);
            clearRowFlags();
          };
        }, []);

        // 离开皮肤时收起浮层，避免留下一个无样式面板。
        React.useEffect(() => {
          if (!skin) setOpen(false);
        }, [skin]);

        // 浮层开着时：点外部或按 Esc 关闭。
        React.useEffect(() => {
          if (!open) return undefined;
          const onPointerDown = (event) => {
            const target = event.target;
            if (target && typeof target.closest === 'function'
              && target.closest('.' + CAPSULE_CLASS + ', .' + PANEL_CLASS)) return;
            setOpen(false);
          };
          const onKeyDown = (event) => {
            if (event.key === 'Escape') setOpen(false);
          };
          document.addEventListener('mousedown', onPointerDown, true);
          document.addEventListener('keydown', onKeyDown, true);
          return () => {
            document.removeEventListener('mousedown', onPointerDown, true);
            document.removeEventListener('keydown', onKeyDown, true);
          };
        }, [open]);

        // 不在女仆皮肤下就彻底不渲染：聚合照旧跑（hook 必须无条件调用），
        // 但既不画胶囊，也不给工作区行写徽标。
        if (!skin) return null;

        const total = marks.total;
        const running = total > 0;
        const label = running ? fill(t('capsule.running'), total) : '';

        const capsuleProps = {
          key: 'capsule',
          className: CAPSULE_CLASS,
          'data-maidrun-state': running ? 'run' : 'idle',
        };
        if (running) {
          capsuleProps.type = 'button';
          capsuleProps.title = t('capsule.tip');
          capsuleProps['aria-label'] = t('capsule.tip') + ' ' + label;
          capsuleProps['aria-haspopup'] = 'dialog';
          capsuleProps['aria-expanded'] = open;
          capsuleProps.onClick = () => setOpen((value) => !value);
        } else {
          capsuleProps.role = 'status';
          capsuleProps['aria-label'] = t('capsule.idle');
        }
        const capsule = h(running ? 'button' : 'div', capsuleProps, [
          h('span', { key: 'dot', className: 'dsh-maidrun-capsule-dot', 'aria-hidden': true }),
          h('span', { key: 'label', className: 'dsh-maidrun-capsule-label' }, label),
        ]);

        if (!open || !running) return capsule;

        const panel = h('div', {
          key: 'panel',
          className: PANEL_CLASS,
          role: 'dialog',
          'aria-label': t('panel.title'),
        }, [
          h('div', { key: 'head', className: 'dsh-maidrun-panel-head' }, [
            h('span', { key: 'dot', className: 'dsh-maidrun-panel-dot', 'aria-hidden': true }),
            h('span', { key: 'title', className: 'dsh-maidrun-panel-title' }, t('panel.title')),
            h('span', { key: 'total', className: 'dsh-maidrun-panel-total' }, String(total)),
          ]),
          h(
            'div',
            { key: 'list', className: 'dsh-maidrun-panel-list' },
            marks.list.length === 0
              ? [h('div', { key: 'empty', className: 'dsh-maidrun-panel-empty' }, t('panel.empty'))]
              : marks.list.map((row) => {
                // 逐行判定可点性：uiWorkspace 可用，或该会话行此刻在 DOM 中
                // （可走行点击兜底）。两者都不满足才降级为静态行。
                const target = row.sessionId !== undefined && canOpenSession(row.sessionId)
                  ? row.sessionId
                  : undefined;
                const itemProps = {
                  key: row.id === '' ? 'ungrouped' : row.id,
                  className: 'dsh-maidrun-panel-item',
                  title: row.title,
                };
                if (target !== undefined) {
                  itemProps.type = 'button';
                  itemProps.onClick = () => {
                    setOpen(false);
                    openSession(target);
                  };
                } else {
                  itemProps.type = 'button';
                  itemProps['data-maidrun-static'] = '1';
                  itemProps.disabled = true;
                }
                return h('button', itemProps, [
                  h('span', { key: 'dot', className: 'dsh-maidrun-panel-item-dot', 'aria-hidden': true }),
                  h('span', { key: 'name', className: 'dsh-maidrun-panel-name' }, row.title),
                  h('span', { key: 'count', className: 'dsh-maidrun-panel-count' }, fill(t('panel.sessions'), row.count)),
                ]);
              }),
          ),
        ]);

        return h(React.Fragment, null, capsule, panel);
      };
    }

    return {
      // 插件名：决定 slot 注册诊断里的 registrant 归属（dsh-pet 同样用
      // exports.name 声明自己，缺省会被并进宿主根 fiber）。
      name: 'maid-workspace-activity',
      // 与 dsh-pet 同样的座位：slots 注册界面，locale 提供字典与 t。
      // uiWorkspace 是硬依赖：契约里明确给出 hardDependency 形式
      // （inject: ["uiWorkspace"]），而该服务确实常驻。用它换掉原来的
      // ctx.get() 可选获取——未声明的服务在 Cordis 里可能取不到，
      // 那会让浮层行静默变成 disabled（禁用按钮不派发 click），
      // 表现就是"能点、但完全没反应"。
      inject: ['slots', 'locale', 'uiWorkspace'],
      apply(ctx) {
        ctx.effect(() => installStylesWhenReady(), 'maid-workspace-activity: badge styles');

        // 两参形式：一次交齐全部分语言，缺一门会在注册时抛错（双语平衡）。
        // 字典走多语言注册，界面文案随语言切换自动跟随。
        ctx.effect(() => ctx.locale.register(NS, DICTS), 'maid-workspace-activity: dictionaries');
        const t = makeTranslate(ctx);

        // uiWorkspace 走 inject 声明（硬依赖），所以优先读 ctx.uiWorkspace；
        // 同时保留 ctx.get 兜底，兼容不同装配方式下的取值差异。
        const serviceOrGet = () => {
          const injected = ctx.uiWorkspace;
          if (injected && typeof injected.openSession === 'function') return injected;
          const got = typeof ctx.get === 'function' ? ctx.get('uiWorkspace') : undefined;
          return got && typeof got.openSession === 'function' ? got : undefined;
        };

        // 跳转走宿主的 uiWorkspace 服务。它是可选服务（契约里
        // requiresUndefinedCheck: true），所以不能假定一定拿得到；拿不到时
        // 退回直接点宿主自己的会话行 `data-row-key="session:<id>"`，那条路
        // 不依赖任何服务，只要该行在 DOM 里就能跳。
        const sessionRowInDom = (sessionId) => {
          if (sessionId === undefined || typeof document === 'undefined') return null;
          const wanted = 'session:' + String(sessionId);
          const rows = document.querySelectorAll('[data-row-key^="session:"]');
          for (let i = 0; i < rows.length; i += 1) {
            if (rows[i].getAttribute('data-row-key') === wanted) return rows[i];
          }
          return null;
        };
        const openSession = (sessionId) => {
          const service = serviceOrGet();
          if (service && typeof service.openSession === 'function') {
            try {
              service.openSession(sessionId);
              return true;
            } catch (error) {
              console.warn('maid-workspace-activity: 打开会话失败，改用行点击兜底', error);
            }
          }
          // 兜底：点宿主会话行。React 的事件委托挂在根节点上，真实 DOM 的
          // click() 会冒泡上去，从而触发宿主自己的 onClick。
          const row = sessionRowInDom(sessionId);
          if (!row || typeof row.click !== 'function') return false;
          try {
            row.click();
            return true;
          } catch (error) {
            console.warn('maid-workspace-activity: 会话行点击兜底也失败', error);
            return false;
          }
        };
        const canOpenSession = (sessionId) => {
          const service = serviceOrGet();
          if (service && typeof service.openSession === 'function') return true;
          // 服务缺席时逐行判定：该会话行此刻在 DOM 里才可点。
          return sessionRowInDom(sessionId) !== null;
        };

        // 该 slot 的 catalog 只声明 id / order / label，不传 locale / inject，
        // 免得撞上注册校验；t 与跳转函数由上面的闭包工厂带进组件。
        const ActivityCapsule = makeActivityCapsule(t, canOpenSession, openSession);
        ctx.slots.inject('shell.overlay', () => ctx.slots.register({
          name: 'shell.overlay',
          id: 'maid-workspace-activity',
          order: 1500,
        }, ActivityCapsule));
      },
    };
  },
});
