/** 宿主半边：本 bundle 全部工作在浏览器半边，这里保持空实现。 */
export function apply() {}
