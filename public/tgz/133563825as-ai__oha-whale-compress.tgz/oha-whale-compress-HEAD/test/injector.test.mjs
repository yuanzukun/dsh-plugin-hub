import { test } from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, mkdir, writeFile, readFile, readdir } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  STOCK_ENGINE, WHALE_ENGINE, findEngineRows, replaceRow, injectPreset,
  injectEngineRow, restoreEngineRow, injectEngineRows, restoreEngineRows, MANAGED_OPEN
} from '../src/injector.js'

const FIXTURE = [
  '# 顶部注释必须原样保留',
  '- id: compaction',
  '  name: cordis:group',
  '  group: true',
  '  isolate:',
  '    compaction: true',
  '  config:',
  "    - id: compaction-basic",
  `      name: '${STOCK_ENGINE}'`,
  '',
  '    - id: command-compact',
  "      name: '@deepseek-ai/dsh-command-compact'",
  ''
].join('\n')

test('findEngineRows 找到唯一一行并带出缩进', () => {
  const rows = findEngineRows(FIXTURE, STOCK_ENGINE)
  assert.equal(rows.length, 1)
  assert.equal(rows[0].indent, '      ')
})

test('replaceRow 只改那一行，其余字节完全不变', () => {
  const result = replaceRow(FIXTURE, STOCK_ENGINE, WHALE_ENGINE)
  assert.equal(result.ok, true)
  assert.equal(result.text, FIXTURE.replace(`name: '${STOCK_ENGINE}'`, `name: '${WHALE_ENGINE}'`))
  assert.ok(result.text.startsWith('# 顶部注释必须原样保留'))
  assert.equal(result.text.length, FIXTURE.length - STOCK_ENGINE.length + WHALE_ENGINE.length)
})

test('replaceRow 找不到时报 not-found，绝不编造', () => {
  assert.deepEqual(replaceRow('# 空文件\n', STOCK_ENGINE, WHALE_ENGINE), { ok: false, reason: 'not-found' })
})

test('replaceRow 多处匹配时报 ambiguous 并给出数量', () => {
  const twice = FIXTURE + FIXTURE
  assert.deepEqual(replaceRow(twice, STOCK_ENGINE, WHALE_ENGINE), { ok: false, reason: 'ambiguous', count: 2 })
})

async function presetFixture (body = FIXTURE) {
  const root = await mkdtemp(join(tmpdir(), 'whale-root-'))
  const dir = join(root, 'maomao')
  await mkdir(dir, { recursive: true })
  const file = join(dir, 'agent.cordis.yml')
  await writeFile(file, body)
  return { root, dir, file }
}

test('injectPreset 注入成功并留下备份', async () => {
  const { root, file } = await presetFixture()
  const r = await injectPreset({ presetPath: file, userRoot: root, mode: 'inject' })
  assert.equal(r.status, 'ok')
  assert.ok(r.backup.includes('.bak-'), '必须留下备份文件')
  assert.ok((await readFile(file, 'utf8')).includes(`name: '${WHALE_ENGINE}'`))
  assert.equal((await readFile(r.backup, 'utf8')), FIXTURE)
})

test('injectPreset 幂等：已是引擎行则跳过且不再备份', async () => {
  const { root, file } = await presetFixture()
  await injectPreset({ presetPath: file, userRoot: root, mode: 'inject' })
  const before = (await readdir(join(root, 'maomao'))).filter((n) => n.includes('.bak-')).length
  const second = await injectPreset({ presetPath: file, userRoot: root, mode: 'inject' })
  assert.equal(second.status, 'already')
  const after = (await readdir(join(root, 'maomao'))).filter((n) => n.includes('.bak-')).length
  assert.equal(after, before)
})

test('injectPreset 还原回原生引擎，且逐字节回到原文', async () => {
  const { root, file } = await presetFixture()
  await injectPreset({ presetPath: file, userRoot: root, mode: 'inject' })
  const injected = await readFile(file, 'utf8')
  assert.ok(injected.includes(MANAGED_OPEN), '注入必须带上托管 config 块')

  const back = await injectPreset({ presetPath: file, userRoot: root, mode: 'restore' })
  assert.equal(back.status, 'restored')
  assert.equal(await readFile(file, 'utf8'), FIXTURE, '注入再还原必须逐字节回到原文，托管块不能残留')
})

test('injectPreset 拒绝写 user 根之外的文件（shipped preset）', async () => {
  const { file } = await presetFixture()
  const otherRoot = await mkdtemp(join(tmpdir(), 'whale-other-'))
  const r = await injectPreset({ presetPath: file, userRoot: otherRoot, mode: 'inject' })
  assert.equal(r.status, 'refused')
  assert.match(r.reason, /user/)
  assert.equal(await readFile(file, 'utf8'), FIXTURE, '拒绝时绝不能写入')
})

test('injectPreset 结构不认识时拒绝，不做任何写入', async () => {
  const { root, file } = await presetFixture('# 没有 compaction 行\n- id: x\n  name: y\n')
  const r = await injectPreset({ presetPath: file, userRoot: root, mode: 'inject' })
  assert.equal(r.status, 'not-found')
  assert.equal((await readdir(join(root, 'maomao'))).filter((n) => n.includes('.bak-')).length, 0)
})

test('injectEngineRow 挂上托管块，其余字节逐一保留', () => {
  const r = injectEngineRow(FIXTURE)
  assert.equal(r.ok, true)
  assert.ok(r.text.includes(`name: '${WHALE_ENGINE}'`))
  assert.ok(r.text.includes(MANAGED_OPEN))
  assert.ok(r.text.includes('thresholdRatio: 0.02'), '父类阈值必须被让到哑值')
  assert.ok(r.text.includes('retainTokens: 40000'), '保留量用绝对值，绕开 ratio 校验')
  assert.ok(r.text.startsWith('# 顶部注释必须原样保留'), '顶部注释不得被动')
  assert.ok(r.text.endsWith("      name: '@deepseek-ai/dsh-command-compact'\n"), '尾行不得被动')
})

test('restoreEngineRow 抹掉托管块；手改过没有块的文件只换回 name 行', () => {
  const injected = injectEngineRow(FIXTURE)
  assert.equal(injected.ok, true)
  const back = restoreEngineRow(injected.text)
  assert.equal(back.ok, true)
  assert.equal(back.text, FIXTURE, '注入再还原必须逐字节回到原文')

  // 有人手工把 name 改了、却没带托管块：只能还原 name，不能顺手删人家自己的配置
  const handEdited = FIXTURE.replace(`name: '${STOCK_ENGINE}'`, `name: '${WHALE_ENGINE}'`)
  const back2 = restoreEngineRow(handEdited)
  assert.equal(back2.ok, true)
  assert.equal(back2.text, FIXTURE)
})

test('restoreEngineRow 在文件里找不到鲸鱼引擎时报 not-found', () => {
  assert.deepEqual(restoreEngineRow(FIXTURE), { ok: false, reason: 'not-found' })
})

test('批量注入：一个文件里四处引擎行全部换掉，且互不串位', () => {
  const four = FIXTURE + '\n' + FIXTURE + '\n' + FIXTURE + '\n' + FIXTURE
  const r = injectEngineRows(four)
  assert.equal(r.ok, true)
  assert.equal(r.count, 4)
  assert.equal(findEngineRows(r.text, STOCK_ENGINE).length, 0)
  assert.equal(findEngineRows(r.text, WHALE_ENGINE).length, 4)
  // 四个托管块都得在，不能只挂第一个
  assert.equal(r.text.split(MANAGED_OPEN).length - 1, 4)
})

test('批量注入：没有可换的行时报 not-found', () => {
  assert.deepEqual(injectEngineRows('# 空文件\n'), { ok: false, reason: 'not-found' })
})

test('批量还原：四处一起还原，逐字节回到原文', () => {
  const four = FIXTURE + '\n' + FIXTURE + '\n' + FIXTURE + '\n' + FIXTURE
  const injected = injectEngineRows(four)
  assert.equal(injected.ok, true)
  const back = restoreEngineRows(injected.text)
  assert.equal(back.ok, true)
  assert.equal(back.count, 4)
  assert.equal(back.text, four, '四处一起注入再还原必须逐字节回到原文')
})

test('injectPreset 期望数量对不上就拒绝写入（宁可不改也不猜）', async () => {
  const { root, file } = await presetFixture(FIXTURE + '\n' + FIXTURE)
  const r = await injectPreset({ presetPath: file, userRoot: root, mode: 'inject', expectedCount: 4 })
  assert.equal(r.status, 'count-mismatch')
  assert.equal(r.count, 2)
  assert.equal(r.expected, 4)
  assert.equal(await readFile(file, 'utf8'), FIXTURE + '\n' + FIXTURE, '拒绝时绝不能写入')
  assert.equal((await readdir(join(root, 'maomao'))).filter((n) => n.includes('.bak-')).length, 0)
})

test('injectPreset 数量吻合时批量注入', async () => {
  const { root, file } = await presetFixture(FIXTURE + '\n' + FIXTURE)
  const r = await injectPreset({ presetPath: file, userRoot: root, mode: 'inject', expectedCount: 2 })
  assert.equal(r.status, 'ok')
  assert.equal(findEngineRows(await readFile(file, 'utf8'), WHALE_ENGINE).length, 2)
})
