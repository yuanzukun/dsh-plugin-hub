import { copyFile, readFile, writeFile } from 'node:fs/promises'
import { resolve, sep } from 'node:path'

/** 框架原生的压缩引擎包名（preset 行里现在写的那个）。 */
export const STOCK_ENGINE = '@deepseek-ai/dsh-compaction-basic'
/** 我们的压缩引擎子路径。 */
export const WHALE_ENGINE = 'dsh-oha-whale-compress/engine'

/**
 * 注入时写给父类的「哑阈值」。
 *
 * 父类的自动压缩按 `contextWindow * thresholdRatio` 判定，是**比例**而不是绝对值，
 * 表达不了「到 400K 就压」。这里把它让到极低，父类从此不再具备实际把关能力，
 * 真正的触发线交给插件按 `autoThresholdTokens` 看守（见 `src/engine.js`）。
 * 保留 0.02 而不是更低，是为了万一插件那条路径失效时父类仍在 2% 窗口处兜底，
 * 不至于彻底失控。
 */
export const DUMMY_THRESHOLD_RATIO = 0.02
/**
 * 压缩后保留的尾部 token 绝对量。
 *
 * 用绝对值而不是 `retainRatio`，一是语义直接，二是能绕开上游
 * `retainRatio < thresholdRatio` 的加载期校验（那条校验只在比例存在时触发）。
 */
export const RETAIN_TOKENS = 40000

/** 托管块起止标记。restore 只删这一段，绝不碰 user 自己写的 config。 */
export const MANAGED_OPEN = '# >>> dsh-oha-whale-compress managed block — do not edit >>>'
export const MANAGED_CLOSE = '# <<< dsh-oha-whale-compress managed block <<<'

/** 转义正则元字符。 */
function escapeRegExp (value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
}

/**
 * 找出所有形如 `  name: '<engine>'` 的整行。
 *
 * 只匹配**独占一行**的 name 行，避免误伤注释或行内出现同名字符串。
 * @param {string} text - composition 文件全文。
 * @param {string} name - 要匹配的包名。
 * @returns {Array<{ index: number, indent: string, raw: string }>} 匹配到的行。
 */
export function findEngineRows (text, name) {
  // 必须用「不含换行的空白」[^\S\n]，不能用 \s —— \s 会把行尾的换行一起吞掉，
  // 使 row.raw 跨到下一行，替换后就会静默丢掉一个空行（会破坏「其余字节不变」的保证）。
  const re = new RegExp(`^([^\\S\\n]*)name:[^\\S\\n]*'${escapeRegExp(name)}'[^\\S\\n]*$`, 'gm')
  const found = []
  let match
  while ((match = re.exec(text)) !== null) {
    found.push({ index: match.index, indent: match[1], raw: match[0] })
  }
  return found
}

/**
 * 把一行引擎名替换成另一个（不带附加配置）。
 *
 * **绝不重新序列化 YAML** —— 那会抹掉全部注释与 `!!js` 表达式。这里只做字节级
 * 的单行替换，文件的其余部分保持不变。
 * @param {string} text - 原文。
 * @param {string} from - 原引擎包名。
 * @param {string} to - 目标引擎包名。
 * @returns {{ ok: true, text: string } | { ok: false, reason: 'not-found' | 'ambiguous', count?: number }} 结果。
 */
export function replaceRow (text, from, to) {
  const rows = findEngineRows(text, from)
  if (rows.length === 0) return { ok: false, reason: 'not-found' }
  if (rows.length > 1) return { ok: false, reason: 'ambiguous', count: rows.length }
  const row = rows[0]
  const replacement = `${row.indent}name: '${to}'`
  return { ok: true, text: text.slice(0, row.index) + replacement + text.slice(row.index + row.raw.length) }
}

/**
 * 生成随引擎行一起写入的托管块（含前导换行）。
 * @param {string} indent - name 行的缩进，config 块与之同级。
 * @returns {string} 待插入的文本片段。
 */
export function managedBlock (indent) {
  return [
    '',
    `${indent}${MANAGED_OPEN}`,
    `${indent}config:`,
    `${indent}  thresholdRatio: ${DUMMY_THRESHOLD_RATIO}`,
    `${indent}  retainTokens: ${RETAIN_TOKENS}`,
    `${indent}${MANAGED_CLOSE}`
  ].join('\n')
}

/**
 * 注入：把原生引擎行换成鲸鱼引擎，并在其后挂上托管 config 块。
 * @param {string} text - 原文。
 * @returns {{ ok: true, text: string } | { ok: false, reason: 'not-found' | 'ambiguous', count?: number }} 结果。
 */
export function injectEngineRow (text) {
  const rows = findEngineRows(text, STOCK_ENGINE)
  if (rows.length === 0) return { ok: false, reason: 'not-found' }
  if (rows.length > 1) return { ok: false, reason: 'ambiguous', count: rows.length }
  const row = rows[0]
  const nameLine = `${row.indent}name: '${WHALE_ENGINE}'`
  return {
    ok: true,
    text: text.slice(0, row.index) + nameLine + managedBlock(row.indent) + text.slice(row.index + row.raw.length)
  }
}

/**
 * 批量注入：把文件里**每一处**原生引擎行都换掉。
 *
 * `profiles/web/cordis.patch.yml` 一个文件里内联了四个 preset，每个各有一行引擎，
 * 单行版会因 `ambiguous` 直接拒绝。这里从后往前替换，避免前面的改动让后面的
 * 索引漂移。
 * @param {string} text - 原文。
 * @returns {{ ok: true, text: string, count: number } | { ok: false, reason: 'not-found' }} 结果。
 */
export function injectEngineRows (text) {
  const rows = findEngineRows(text, STOCK_ENGINE)
  if (rows.length === 0) return { ok: false, reason: 'not-found' }
  let out = text
  for (let i = rows.length - 1; i >= 0; i -= 1) {
    const row = rows[i]
    const nameLine = `${row.indent}name: '${WHALE_ENGINE}'`
    out = out.slice(0, row.index) + nameLine + managedBlock(row.indent) + out.slice(row.index + row.raw.length)
  }
  return { ok: true, text: out, count: rows.length }
}

/**
 * 还原：把鲸鱼引擎行换回原生引擎，并抹掉紧随其后的托管块。
 * @param {string} text - 原文。
 * @returns {{ ok: true, text: string } | { ok: false, reason: 'not-found' | 'ambiguous', count?: number }} 结果。
 */
export function restoreEngineRow (text) {
  const rows = findEngineRows(text, WHALE_ENGINE)
  if (rows.length === 0) return { ok: false, reason: 'not-found' }
  if (rows.length > 1) return { ok: false, reason: 'ambiguous', count: rows.length }
  const row = rows[0]
  const head = text.slice(0, row.index) + `${row.indent}name: '${STOCK_ENGINE}'`
  let tail = text.slice(row.index + row.raw.length)
  // 托管块紧贴在 name 行之后；没有（例如手改过）就只还原 name 行，不猜。
  const block = new RegExp(`^\\n[^\\S\\n]*${escapeRegExp(MANAGED_OPEN)}[\\s\\S]*?${escapeRegExp(MANAGED_CLOSE)}`).exec(tail)
  if (block !== null) tail = tail.slice(block[0].length)
  return { ok: true, text: head + tail }
}

/**
 * 批量还原：把文件里每一处鲸鱼引擎行换回原生引擎，并抹掉各自的托管块。
 * @param {string} text - 原文。
 * @returns {{ ok: true, text: string, count: number } | { ok: false, reason: 'not-found' }} 结果。
 */
export function restoreEngineRows (text) {
  const rows = findEngineRows(text, WHALE_ENGINE)
  if (rows.length === 0) return { ok: false, reason: 'not-found' }
  let out = text
  for (let i = rows.length - 1; i >= 0; i -= 1) {
    const row = rows[i]
    let tail = out.slice(row.index + row.raw.length)
    const block = new RegExp(`^\\n[^\\S\\n]*${escapeRegExp(MANAGED_OPEN)}[\\s\\S]*?${escapeRegExp(MANAGED_CLOSE)}`).exec(tail)
    if (block !== null) tail = tail.slice(block[0].length)
    out = out.slice(0, row.index) + `${row.indent}name: '${STOCK_ENGINE}'` + tail
  }
  return { ok: true, text: out, count: rows.length }
}

/** 生成备份文件名后缀，例如 20260911-120000。 */
function stamp (now) {
  const pad = (n) => String(n).padStart(2, '0')
  return `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`
}

/**
 * 就地对一个 preset 的 composition 做注入 / 还原。
 *
 * 五条安全规则（spec §8.2）：只写 user 根、绝不重新序列化、唯一性硬检查、
 * 先备份、幂等。
 * @param {{ presetPath: string, userRoot: string, mode: 'inject' | 'restore', now?: Date, expectedCount?: number }} opts - 参数。
 * @returns {Promise<object>} 结果对象，`status` 取值 ok / already / restored / refused / not-found / ambiguous / count-mismatch。
 */
export async function injectPreset (opts) {
  const file = resolve(opts.presetPath)
  const root = resolve(opts.userRoot)
  const restore = opts.mode === 'restore'

  // 规则 1：只写 user 根之内
  if (file !== root && !file.startsWith(root + sep)) {
    return { status: 'refused', file, reason: `只能修改 user 根（${root}）之内的 preset；shipped preset 会被升级覆盖` }
  }

  const text = await readFile(file, 'utf8')

  // 已经是目标状态的行 / 还要换的行
  const filled = findEngineRows(text, restore ? STOCK_ENGINE : WHALE_ENGINE)
  const pending = findEngineRows(text, restore ? WHALE_ENGINE : STOCK_ENGINE)

  // 规则 5：幂等 —— 没有待换的行就收工。区分「已经换过了」与「文件里压根没这结构」。
  if (pending.length === 0) {
    return { status: filled.length > 0 ? 'already' : 'not-found', file }
  }

  // 期望数量校验：`profiles/web/cordis.patch.yml` 里应当正好四个 preset 各一行。
  // 数量对不上说明文件结构变了 —— 宁可不写，也不猜。
  const expected = opts.expectedCount
  if (expected !== undefined && pending.length !== expected) {
    return { status: 'count-mismatch', file, count: pending.length, expected }
  }

  const result = restore ? restoreEngineRows(text) : injectEngineRows(text)
  if (!result.ok) return { status: result.reason, file, ...(result.count === undefined ? {} : { count: result.count }) }

  // 规则 4：先备份
  const backup = `${file}.bak-${stamp(opts.now ?? new Date())}`
  await copyFile(file, backup)
  await writeFile(file, result.text, 'utf8')

  return { status: restore ? 'restored' : 'ok', file, backup }
}
