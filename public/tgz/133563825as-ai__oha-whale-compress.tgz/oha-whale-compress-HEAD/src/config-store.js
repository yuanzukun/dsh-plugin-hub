import { join } from 'node:path'
import { mkdir, readFile, writeFile } from 'node:fs/promises'

/** 自动压缩的默认触发线（token）。400K 只是出厂值，面板可改。 */
export const DEFAULT_AUTO_THRESHOLD_TOKENS = 409600

const DEFAULTS = {
  provider: '',
  model: '',
  promptTemplate: 'native',
  prompt: '',
  /** 自动压缩总开关：关闭后步进压力一路完全不压。 */
  autoCompress: true,
  /** 自动压缩触发线（绝对 token 数，不看模型窗口比例）。 */
  autoThresholdTokens: DEFAULT_AUTO_THRESHOLD_TOKENS,
  /** 输入框下方常驻按钮的显隐。 */
  dockButton: true
}

/**
 * 只保留已知字段。
 *
 * 旧版本往 config.json 里写过的键（例如已移除的 `keepN`）在这里被静默丢弃 ——
 * 否则它们会跟着 `{...DEFAULTS, ...parsed}` 一起被读进内存、再被 save 写回去，
 * 删了 UI 却删不掉数据。
 * @param {unknown} source - 磁盘上解析出来的对象。
 * @returns {object} 归一化后的配置。
 */
function normalize (source) {
  const out = { ...DEFAULTS }
  if (source === null || typeof source !== 'object' || Array.isArray(source)) return out
  for (const key of Object.keys(DEFAULTS)) {
    if (source[key] !== undefined) out[key] = source[key]
  }
  return out
}

/**
 * 轻量配置存储：持久化到 ~/.dsh/storages/dsh-oha-whale-compress/config.json。
 * @param {string} home - dsh home 目录。
 * @returns {{ get: () => Promise<object>, save: (patch: object) => Promise<object>, file: string }}
 */
export function createConfigStore (home) {
  const dir = join(home, 'storages', 'dsh-oha-whale-compress')
  const file = join(dir, 'config.json')
  let cache = null

  async function load () {
    if (cache !== null) return cache
    try {
      const raw = await readFile(file, 'utf8')
      cache = normalize(JSON.parse(raw))
    } catch {
      cache = { ...DEFAULTS }
    }
    return cache
  }

  async function get () {
    return { ...(await load()) }
  }

  async function save (patch) {
    const current = await load()
    const next = { ...current, ...(patch && typeof patch === 'object' && !Array.isArray(patch) ? patch : {}) }
    await mkdir(dir, { recursive: true })
    await writeFile(file, JSON.stringify(next, null, 2) + '\n', 'utf8')
    cache = next
    return { ...next }
  }

  return { get, save, file }
}
