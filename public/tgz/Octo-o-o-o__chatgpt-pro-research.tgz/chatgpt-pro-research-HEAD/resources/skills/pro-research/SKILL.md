---
name: pro-research
description: 用 ChatGPT 网页会话做无人值守的多轮调研或设计；只在用户明确要求 ChatGPT 调研/设计、或同意你的提议时使用。
argument-hint: <目标> [--rounds N]
display-name: Pro Research
short-description: Bounded, resumable ChatGPT web research with local records
---

# Pro 调研

只在用户明确说「用 ChatGPT 调研 / 用 Pro 调研 / 让 ChatGPT 看看」或同意你的提议时启动。普通问答、需要跑代码验证的任务、不能外发的材料，不要用。

网页通道固定为**单账号、单会话**：两个插件共用本机 Google Chrome 与 `~/.dsh/pro-research/browser`，不并行多账号、不扇出、不合并多份答复；原会话可用时续用，会话丢失时由宿主生成 `context.md` 显式重建，并在记录里标注，不承诺永久记忆。

模型默认 `prefer-pro`：优先使用可用 Pro，没有才沿用网页当前模型；禁用、锁定和升级入口不算可用 Pro。显式 `auto` 保留当前选择，指定其他模型仍须核验。旧设置或旧主题保留原模型；需要默认策略时提示设为 `prefer-pro` 后新建主题。

## 启动：先给研究卡，不要直接跑

研究卡必须包含：

1. 主题与一句话研究问题；
2. **成功判据**（可判定的句子；自动裁决和提前停止都靠它）；
3. 准备发送的材料（路径 + 文件数 + 是否含敏感项）与 brief 要点；
4. 通道（ChatGPT 网页）、模型（默认 prefer-pro）、轮次上限（默认 3）、记录位置（project / local）；
5. 产物路径。

请用户确认，然后调用 `pro_research`：
`action=start, confirmed=true, title, question, brief, criteria[], materials[], rounds, store`。

`store` 必须与研究卡一致（`local` 或 `project`）；读取工具返回的 `store` 和 `path` 核对实际位置，不能只在文字里承诺本机保存。已有主题继续使用原位置，不隐式迁移。

local 与 project 均通过插件的 `read_round`、`read_report`、`write_report` 整理交付稿。无需宿主通用文件工具访问 local 目录；这些动作仍经过 DSH 工具权限检查。不要修改宿主权限、改写记录位置或使用外部脚本代写。

不要用自己写的摘要替代原始材料；`materials` 是相对当前工作目录的路径，工具会做密钥扫描和清单哈希。

## 运行期间

发出去就不要再逐轮汇报。只有用户主动问才 `action=status`；卡住时工具会把状态变成 `stalled`，并在 `stall_reason` 里给出 login / upload / ui / timeout / config / worker / unknown_submission。

- `stalled` 先读取 `status` 的 `last_round`，区分发送前失败、已发送和提交不明，不凭错误文案猜测。
- `last_round.submissionState=not_sent` 表示驱动确认在点击发送前停止；任务已获授权且原因已解决或仅为临时导航超时时，可以 `resume` 重试原轮一次，不新建主题。仍失败就报告现场，不循环重试。其他未确认提交仍走 `human_check`。
- `unknown_submission` 必须由用户核对后调用 `action=human_check`（conclusion=submitted / not_submitted / reopen，note 必填）。
- 登录失效：请用户运行 `action=login`，完成后再 `action=resume`。
- 账号、ToS、页面改版风险随任务说明；不要承诺一定能跑完。

## 答复回来之后

宿主模型负责裁决，不把 Pro 的话直接当结论：

1. 读原始答复与各轮 `verdict.md`（逐条判据表在“## 判据”一节）；
2. 对照成功判据逐条判断：采纳 / 部分采纳 / 有依据驳回；
3. 把裁决写进项目文档，保留分歧和未决项；
4. 只把变化送进下一轮（工具会在同一主题里续轮次），不重复已确认内容。

`final.md` 是运行汇总（自动生成），不是交付物。宿主应整理 `report.md`：

1. 当前结论与适用条件；
2. 成功判据逐条：met / partial / unmet / unknown + 对应轮次或答复证据；
3. 未决问题；
4. 产物与轮次入口。

面板优先展示 `report.md`；没有时明确显示“宿主尚未整理交付稿”。

先用 `status` 获取版本/轮次，再用 `read_round(topic_id, round)` 核对对应回答和裁决，`read_report(topic_id)` 获取旧稿与 `report.revision`。完成正文后调用 `write_report(topic_id, markdown, generation, through_round, expected_revision, confirmed=true)`；没有旧稿时 `expected_revision=""`。用户已授权当前任务与交付时无需重复确认。插件只写该主题的 `report.md`，自动添加真实覆盖范围文件头；拒绝跨项目写入、运行中的主题、过时轮次及旧 revision。正文不要自行添加文件头。发生冲突时重新读取证据和旧稿后整合，不能盲目覆盖。

没有文件头的旧稿显示“覆盖范围未确认”；续轮或重做后显示“交付稿待更新”，旧稿仍可阅读。不要只更新覆盖范围来冒充已整合新证据。工具权限被拒绝时尊重拒绝并向用户说明，不改用其他通道写入。

自动裁决失败时主题停在 `reviewing`（`review_from=answered`），答复和产物都保留：按成功判据选择 `accept` / `continue` / `regenerate`，或修好 `judgeProvider` / `judgeModel` 后 `resume` 重试。不要把这种情况说成运行失败。

## 追问

在同一主题上追加一轮用：

`pro_research(action="continue", topic_id=..., brief=..., confirmed=true)`

只送变化：上一轮裁决 + 新 brief + 新增/修改的材料。原会话丢了由宿主生成 `context.md` 重开；不要新建平行主题。已达轮次上限的主题，`continue` 会显式加一并留下记录；先向用户说明这是加轮。

整版不满意用 `regenerate`（保留历史、开新版本），`note` 写不满意点，可附 `materials=[...]`（相对主题项目根目录）补充新材料。

终态主题（完成/取消/到顶/失败/卡住）确认后可 `delete`：删除主题目录、原始答复与面板记录，不可恢复，先向用户说明。

## 边界

- 不自动 push，不把 GitHub 当唯一材料通道；已提交内容可给提交号 + 路径，让 Pro 自己决定要不要读。
- 密钥、凭据、`.env` 不进材料；扫描命中就换材料，不要绕过。
- 不重发提交状态未知的轮次；不把失败说成完成。
- 不能仅凭耗时短断言“没有读附件”；核对实际答复、上传回执和完成信号。只收到开场白时，应先排查是否提前截取了仍在生成的回答。
- 同一主题只有一份记录；换 `store` 需要显式迁移，不要两处各写一半。
