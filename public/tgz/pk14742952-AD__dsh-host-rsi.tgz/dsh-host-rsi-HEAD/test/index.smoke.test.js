import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { apply } from '../index.js';
import { openStore } from '../lib/store.js';
import { SOFT_STEER } from '../lib/convergence.js';

test('Config is not exported - cordis resolveConfig would crash on a plain object', async () => {
  const mod = await import('../index.js');
  assert.equal('Config' in mod, false);
  assert.equal(typeof mod.apply, 'function');
});

test('apply() with a minimal/unknown ctx never throws and returns a cleanup', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-idx-'));
  const cleanup = apply({ someUnknownCtx: true }, { enabled: true, dir, flushMs: 500 });
  assert.equal(typeof cleanup, 'function');
  cleanup();
});

test('apply() with enabled=false is a full no-op (data dir untouched)', () => {
  const cleanup = apply({}, { enabled: false, dir: 'C:/should-not-be-created' });
  assert.equal(typeof cleanup, 'function');
  cleanup();
  assert.ok(!fs.existsSync('C:/should-not-be-created'));
});

function makeHarness(dir, injectOverrides = {}) {
  const ctx = {
    events: {},
    injected: [],
    on(name, cb) {
      ctx.events[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register() {
        return () => {};
      },
    },
  };
  const cfg = {
    enabled: true,
    dir,
    flushMs: 100000,
    dashboard: { enabled: false, webserver: false },
    inject: {
      enabled: true,
      topK: 3,
      tokenBudget: 1000,
      candCap: 40,
      includeQuarantined: false,
      oncePerTask: false,
      maxInjectsPerTask: 2,
      reinjectOn: ['tool-failure', 'repeated-failure'],
      compactTopK: 1,
      compactTokenBudget: 300,
      ...injectOverrides,
    },
    capture: { enabled: true, maxPerSession: 10, minChars: 300, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  };
  const cleanup = apply(ctx, cfg);
  return { ctx, cleanup };
}

test('balanced injection: same task can receive one compact re-inject after a tool failure', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-bal-'));
  const store = openStore(dir, { flushMs: 100000 });
  store.ensureLayout();
  store.addLesson({
    domain: 'sql',
    tags: ['sql', 'join'],
    summary: 'always add a join condition before scanning',
    fix: 'add WHERE before executing',
    layer: 'L1',
    trusted: true,
  });
  store.flushSync();

  const { ctx, cleanup } = makeHarness(dir);
  const agent = { inject: (block) => ctx.injected.push(block) };
  ctx.events['agent/pre-step']({ task: 'sql join', agent }, () => {});
  assert.equal(ctx.injected.length, 1);
  assert.match(ctx.injected[0], /join condition/);

  ctx.events['turn/end']({
    task: 'sql join',
    assistantText: 'query failed',
    toolResults: [{ name: 'sql', ok: false }],
  });
  ctx.events['agent/pre-step']({ task: 'sql join', agent }, () => {});
  assert.equal(ctx.injected.length, 2, 'failure should allow one compact re-inject');
  assert.match(ctx.injected[1], /join condition/);

  cleanup();
});

test('oncePerTask=true restores strict single injection for the same task', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-once-'));
  const store = openStore(dir, { flushMs: 100000 });
  store.ensureLayout();
  store.addLesson({
    domain: 'sql',
    tags: ['sql'],
    summary: 'check indexes before optimizing',
    layer: 'L2',
    trusted: true,
  });
  store.flushSync();

  const { ctx, cleanup } = makeHarness(dir, { oncePerTask: true });
  const agent = { inject: (block) => ctx.injected.push(block) };
  ctx.events['agent/pre-step']({ task: 'sql tuning', agent }, () => {});
  ctx.events['turn/end']({
    task: 'sql tuning',
    assistantText: 'error again',
    toolResults: [{ name: 'sql', ok: false }],
  });
  ctx.events['agent/pre-step']({ task: 'sql tuning', agent }, () => {});
  assert.equal(ctx.injected.length, 1, 'oncePerTask mode must not re-inject on failure');

  cleanup();
});

test('user message injects when pre-step is unavailable', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-uminject-'));
  const store = openStore(dir, { flushMs: 100000 });
  store.ensureLayout();
  store.addLesson({
    domain: 'sql',
    tags: ['sql'],
    summary: 'check indexes before optimizing',
    layer: 'L2',
    trusted: true,
  });
  store.flushSync();

  const { ctx, cleanup } = makeHarness(dir);
  const agent = { inject: (block) => ctx.injected.push(block) };
  ctx.agent = agent;
  ctx.events['session/event']({ id: 'session-1' }, { type: 'user/message', sessionId: 'session-1', data: { content: 'sql tuning please', source: { kind: 'user' }, role: 'user' } });
  assert.equal(ctx.injected.length, 1, 'user/message should inject the trusted lesson');
  assert.match(ctx.injected[0], /indexes/);
  cleanup();
});

test('injection uses DSH systemPrompt.section name/order shape', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-spinject-'));
  const store = openStore(dir, { flushMs: 100000 });
  store.ensureLayout();
  store.addLesson({
    domain: 'sql',
    tags: ['sql'],
    summary: 'always filter before scan',
    layer: 'L2',
    trusted: true,
  });
  store.flushSync();

  const sections = [];
  const eventHandlers = {};
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    get(name) {
      if (name === 'systemPrompt') {
        return {
          section(section) {
            sections.push(section);
            return () => {};
          },
        };
      }
      return undefined;
    },
    tools: {
      register() {
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    inject: { enabled: true, topK: 3, tokenBudget: 1000, candCap: 40, includeQuarantined: false, oncePerTask: false, maxInjectsPerTask: 2, reinjectOn: ['tool-failure', 'repeated-failure'], compactTopK: 1, compactTokenBudget: 300 },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  eventHandlers['session/event']({ id: 's1' }, { type: 'user/message', sessionId: 's1', data: { content: 'sql scan please', source: { kind: 'user' }, role: 'user' } });
  assert.equal(sections.some((s) => s.name === 'rsi-inject' && Number.isFinite(s.order) && /filter/.test(s.text)), true, 'DSH systemPrompt.section must receive name/order');
  cleanup();
});

test('apply registers DSH event aliases + rsi_events/rsi_demo_capture diagnostic tools', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-fallback-'));
  const eventNames = [];
  const toolNames = [];
  const ctx = {
    events: {},
    on(name, cb) {
      eventNames.push(name);
      ctx.events[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register(opts) {
        toolNames.push(opts.name);
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  for (const name of ['agent/pre-step', 'pre-step', 'turn/end', 'agent/turn/end', 'message', 'agent/message', 'chat/message']) {
    assert.ok(eventNames.includes(name), `expected fallback event ${name}`);
  }
  assert.ok(toolNames.includes('rsi_events'), 'rsi_events diagnostic tool should be registered');
  assert.ok(toolNames.includes('rsi_demo_capture'), 'rsi_demo_capture tool should be registered');

  cleanup();
});

test('user correction after an assistant reply is captured as a trusted L3 lesson', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-correction-'));
  const eventHandlers = {};
  const toolRuns = {};
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register(opts) {
        toolRuns[opts.name] = opts.run;
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8, captureUserCorrections: true },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  eventHandlers.message({ role: 'user', sessionId: 's1', content: '写一个 Python 下载脚本' });
  eventHandlers.message({ role: 'assistant', sessionId: 's1', content: '给你一个 requests 实现' });
  eventHandlers.message({ role: 'user', sessionId: 's1', content: '不要用 requests，改用 httpx' });

  const recs = await toolRuns.rsi_records({ limit: 10 });
  const correction = Array.isArray(recs) ? recs.find((r) => r.domain === 'user-correction') : null;
  assert.ok(correction, 'user correction lesson should be recorded');
  assert.equal(correction.trusted, true);
  assert.equal(correction.layer, 'L3');

  cleanup();
});

test('explicit user instruction/preference is captured as a trusted L3 lesson', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-instruction-'));
  const eventHandlers = {};
  const toolRuns = {};
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register(opts) {
        toolRuns[opts.name] = opts.run;
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8, captureUserInstructions: true },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  eventHandlers.message({ role: 'user', sessionId: 's2', content: '以后都用 httpx，不要用 requests' });

  const recs = await toolRuns.rsi_records({ limit: 10 });
  const instruction = Array.isArray(recs) ? recs.find((r) => r.domain === 'user-instruction') : null;
  assert.ok(instruction, 'user instruction lesson should be recorded');
  assert.equal(instruction.trusted, true);
  assert.equal(instruction.layer, 'L3');

  cleanup();
});

test('DSH data.message content shape triggers correction + instruction capture', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-dsh-shape-'));
  const eventHandlers = {};
  const toolRuns = {};
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register(opts) {
        toolRuns[opts.name] = opts.run;
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8, captureUserInstructions: true, captureUserCorrections: true },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  eventHandlers['user/message']({
    type: 'user/message',
    sessionId: 's3',
    data: { message: { content: '以后都用 httpx，不要用 requests', source: { kind: 'user' } } },
  });
  eventHandlers['assistant/message']({
    type: 'assistant/message',
    sessionId: 's3',
    data: { message: { content: [{ type: 'text', text: '给你一个 requests 实现' }], source: { kind: 'model' } } },
  });
  eventHandlers['user/message']({
    type: 'user/message',
    sessionId: 's3',
    data: { message: { content: '不要用 requests，改用 httpx', source: { kind: 'user' } } },
  });

  const recs = await toolRuns.rsi_records({ limit: 20 });
  const instruction = Array.isArray(recs) ? recs.find((r) => r.domain === 'user-instruction') : null;
  const correction = Array.isArray(recs) ? recs.find((r) => r.domain === 'user-correction') : null;
  assert.ok(instruction, 'DSH user/message data shape should record user-instruction');
  assert.equal(instruction.layer, 'L3');
  assert.ok(correction, 'DSH user/message data shape after assistant should record user-correction');
  assert.equal(correction.trusted, true);

  cleanup();
});

test('session/event subscribes to DSH lifecycle and records ordinary user input', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-session-event-'));
  const eventHandlers = {};
  const toolRuns = {};
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register(opts) {
        toolRuns[opts.name] = opts.run;
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8, captureUserInstructions: true },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  eventHandlers['session/event']({ id: 's4' }, {
    type: 'user/message',
    data: { message: { content: '帮我写一个 Python 下载脚本', source: { kind: 'user' } } },
  });

  const recs = await toolRuns.rsi_records({ limit: 10 });
  const task = Array.isArray(recs) ? recs.find((r) => r.domain === 'user-instruction') : null;
  assert.ok(task, 'session/event user message should be recorded');
  assert.equal(task.layer, 'Q');
  assert.equal(task.trusted, false);

  cleanup();
});

test('session/event user/message with data.content records instruction', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-session-content-'));
  const eventHandlers = {};
  const toolRuns = {};
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register(opts) {
        toolRuns[opts.name] = opts.run;
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8, captureUserInstructions: true },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  eventHandlers['session/event']({ id: 's5' }, {
    type: 'user/message',
    data: {
      role: 'user',
      source: { kind: 'user' },
      content: [{ type: 'text', text: '帮我写一个 Python 下载脚本' }],
    },
  });

  const recs = await toolRuns.rsi_records({ limit: 10 });
  const task = Array.isArray(recs) ? recs.find((r) => r.domain === 'user-instruction') : null;
  assert.ok(task, 'session/event data.content user message should be recorded');
  assert.equal(task.layer, 'Q');
  assert.equal(task.trusted, false);

  cleanup();
});

test('convergence hooks steer shells after repeated passing checks and reset on edit', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-cvg-'));
  const ctx = {
    events: {},
    on(name, cb) {
      ctx.events[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register() {
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  assert.equal(typeof ctx.events['tools/pre-execute'], 'function');
  assert.equal(typeof ctx.events['tools/post-execute'], 'function');

  const agent = { session: { requestContext: () => ({ model: 'qwen3-27b' }) } };
  const exec = { agent, name: 'pwsh', arguments: { command: 'npm test' } };
  const result = { isError: false, content: [{ type: 'text', text: '1 passed' }] };
  const next = async () => ({ additionalContexts: [] });
  let out;
  for (let i = 0; i < 3; i += 1) out = await ctx.events['tools/post-execute'](exec, result, next);
  assert.equal(out?.additionalContexts?.[0]?.content?.[0]?.text, SOFT_STEER, 'third repeated pass should soft-steer');
  // Regression: the steer context MUST be an identified user-role message
  // (id + role + content[] + source.kind). A bare {content, source} object
  // corrupts the stored session on persist ("lacks an identified message").
  const steerMsg = out?.additionalContexts?.[0];
  assert.ok(steerMsg, 'a steer context must be produced');
  assert.equal(typeof steerMsg.id, 'string', 'steer context must carry a non-empty string id');
  assert.ok(steerMsg.id.length > 0, 'steer context id must be non-empty');
  assert.equal(steerMsg.role, 'user', 'steer context must be a user-role message');
  assert.ok(Array.isArray(steerMsg.content), 'steer context content must be an array');
  assert.equal(steerMsg.source?.kind, 'dsh-host-rsi', 'steer context source.kind must be set');

  ctx.events['tools/pre-execute']({ agent, name: 'edit' }, () => {});
  out = await ctx.events['tools/post-execute'](exec, result, next);
  assert.ok(!out?.additionalContexts?.length, 'after a source edit the pass counter restarts');

  cleanup();
});

test('convergence gating: an explicit *27b* list excludes non-27b models', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-cvg-gate-'));
  const ctx = {
    events: {},
    on(name, cb) {
      ctx.events[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register() {
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
    convergence: { models: ['*27b*'] },
  });

  const agent = { session: { requestContext: () => ({ model: 'deepseek-v4.1-flash' }) } };
  const exec = { agent, name: 'pwsh', arguments: { command: 'npm test' } };
  const result = { isError: false, content: [{ type: 'text', text: '1 passed' }] };
  const next = async () => ({ additionalContexts: [] });
  let out;
  for (let i = 0; i < 6; i += 1) out = await ctx.events['tools/post-execute'](exec, result, next);
  assert.ok(!out?.additionalContexts?.length, 'non-matching models must never receive a convergence steer');

  cleanup();
});

test('convergence defaults apply to every model, including Flash/API shells', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-cvg-all-'));
  const ctx = {
    events: {},
    on(name, cb) {
      ctx.events[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    tools: {
      register() {
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  const agent = { session: { requestContext: () => ({ model: 'deepseek-v4.1-flash' }) } };
  const exec = { agent, name: 'pwsh', arguments: { command: 'npm test' } };
  const result = { isError: false, content: [{ type: 'text', text: '1 passed' }] };
  const next = async () => ({ additionalContexts: [] });
  let out;
  for (let i = 0; i < 3; i += 1) out = await ctx.events['tools/post-execute'](exec, result, next);
  assert.equal(out?.additionalContexts?.[0]?.content?.[0]?.text, SOFT_STEER, 'default config must steer non-27b models too');
  // Regression: identified user-message shape on the Flash path too.
  const steerMsg = out?.additionalContexts?.[0];
  assert.equal(typeof steerMsg?.id, 'string', 'Flash steer must carry a string id');
  assert.equal(steerMsg?.role, 'user', 'Flash steer must be a user-role message');

  cleanup();
});

test('delivery guard schedules one correction round and marks rescue when fixed', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-guard-'));
  const eventHandlers = {};
  const toolRuns = {};
  const followups = [];
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    agent: {
      followup(p) {
        followups.push(p);
      },
    },
    tools: {
      register(opts) {
        toolRuns[opts.name] = opts.run;
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  eventHandlers['turn/end']({ task: 'write a script', assistantText: '', finishReason: 'length', sessionId: 'g1' });
  assert.equal(followups.length, 1, 'a truncated empty turn should schedule exactly one correction round');
  let diag = await toolRuns.rsi_events({});
  assert.equal(diag.guard.fired, 1);
  assert.equal(diag.guard.retries, 1);
  assert.equal(diag.guard.undelivered, 0);

  eventHandlers['turn/end']({
    task: 'write a script',
    assistantText: 'done, script written to tests/out.js',
    toolResults: [{ name: 'pwsh', ok: true }],
    sessionId: 'g1',
  });
  diag = await toolRuns.rsi_events({});
  assert.equal(diag.guard.rescued, 1, 'a complete tool-backed turn rescues the awaited correction');
  assert.equal(diag.guard.fired, 1);

  cleanup();
});

test('delivery guard final chance: one session-level ultimatum after the retry budget is exhausted, then undelivered', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-guard-fc-'));
  const eventHandlers = {};
  const toolRuns = {};
  const followups = [];
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    agent: {
      followup(p) {
        followups.push(p);
      },
    },
    tools: {
      register(opts) {
        toolRuns[opts.name] = opts.run;
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  // three empty budget-burned turns: correct. rounds 1+2 exhaust the correction budget
  // (maxRetries 2); the third must be the ONE session-level final chance, not undelivered
  for (let i = 0; i < 3; i += 1) {
    eventHandlers['turn/end']({ task: 'write a script', assistantText: '', finishReason: 'length', sessionId: 'gfc1' });
  }
  assert.equal(followups.length, 3, 'two correction rounds + one final chance');
  assert.match(followups[2], /\[rsi-guard\]\[final\]/, 'third followup is the final ultimatum');
  let diag = await toolRuns.rsi_events({});
  assert.equal(diag.guard.fired, 3);
  assert.equal(diag.guard.retries, 2);
  assert.equal(diag.guard.finalChances, 1);
  assert.equal(diag.guard.undelivered, 0, 'final chance must not yet be counted undelivered');

  // a real deliverable after the ultimatum still counts as rescued
  eventHandlers['turn/end']({
    task: 'write a script',
    assistantText: 'done, script written to tests/out.js',
    toolResults: [{ name: 'pwsh', ok: true }],
    sessionId: 'gfc1',
  });
  diag = await toolRuns.rsi_events({});
  assert.equal(diag.guard.rescued, 1, 'deliverable after the final chance rescues the session');
  assert.equal(diag.guard.undelivered, 0);

  cleanup();
});

test('delivery guard final chance: only once per session, then undelivered is recorded', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'rsi-guard-fc2-'));
  const eventHandlers = {};
  const toolRuns = {};
  const followups = [];
  const ctx = {
    events: {},
    on(name, cb) {
      eventHandlers[name] = cb;
      return () => {};
    },
    inject() {
      return () => {};
    },
    agent: {
      followup(p) {
        followups.push(p);
      },
    },
    tools: {
      register(opts) {
        toolRuns[opts.name] = opts.run;
        return () => {};
      },
    },
  };
  const cleanup = apply(ctx, {
    enabled: true,
    dir,
    dashboard: { enabled: false, webserver: false },
    capture: { enabled: true, maxPerSession: 10, minChars: 120, dedupeThreshold: 0.8 },
    escalate: { enabled: true, maxCriticsPerSession: 3, selfConsistency: 1, threshold: 0.6 },
  });

  // 4 empty length-burned turns: EMPTY has priority over FIXED_POINT, so each turn trips
  // the guard; after retry-2 the budget is exhausted -> final chance once -> undelivered
  for (let i = 0; i < 4; i += 1) {
    eventHandlers['turn/end']({ task: 'write a script', assistantText: '', finishReason: 'length', sessionId: 'gfc2' });
  }
  assert.equal(followups.length, 3, 'still exactly two correction rounds + one final chance');
  const diag = await toolRuns.rsi_events({});
  assert.equal(diag.guard.finalChances, 1, 'the final chance fires exactly once');
  assert.equal(diag.guard.undelivered, 1, 'the fourth empty turn is recorded undelivered');
  assert.equal(diag.guard.fired, 4);

  cleanup();
});
