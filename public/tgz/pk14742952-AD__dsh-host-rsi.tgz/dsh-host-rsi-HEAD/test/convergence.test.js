import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  STRONG_STEER,
  SOFT_STEER,
  POLICY_TEXT,
  createState,
  resetState,
  isSourceEdit,
  isShellTool,
  commandOf,
  resultText,
  normalizeModels,
  isModelActive,
  observeShell,
  looksPassed,
  classifyCheck,
} from '../lib/convergence.js';

test('state: create/reset are idempotent and isolate counters', () => {
  const s = createState();
  assert.equal(s.steered, false);
  assert.equal(s.passedFamilies.size, 0);
  assert.equal(s.fingerprintCounts.size, 0);
  s.passedFamilies.add('test');
  s.fingerprintCounts.set('x', 1);
  resetState(s);
  assert.equal(s.passedFamilies.size, 0);
  assert.equal(s.fingerprintCounts.size, 0);
  assert.equal(s.steered, false);
});

test('tool classification: source edits reset, shells are observed', () => {
  assert.equal(isSourceEdit('edit'), true);
  assert.equal(isSourceEdit('write'), true);
  assert.equal(isSourceEdit('pwsh'), false);
  assert.equal(isShellTool('pwsh'), true);
  assert.equal(isShellTool('bash'), true);
  assert.equal(isShellTool('edit'), false);
});

test('commandOf/resultText read DSH exec shapes', () => {
  assert.equal(commandOf({ command: 'npm test' }), 'npm test');
  assert.equal(commandOf({}), '');
  assert.equal(resultText({ content: [{ type: 'text', text: '1 passed' }, { type: 'image', url: 'x' }] }), '1 passed');
  assert.equal(resultText({ content: 'not-an-array' }), '');
});

test('normalizeModels: undefined/null means all models, [] means all, strings kept', () => {
  assert.deepEqual(normalizeModels(undefined), []);
  assert.deepEqual(normalizeModels(null), []);
  assert.deepEqual(normalizeModels([]), []);
  assert.deepEqual(normalizeModels('*27b*'), ['*27b*']);
  assert.deepEqual(normalizeModels(['*27b*', '']), ['*27b*']);
});

test('isModelActive: wildcard 27b matching, case-insensitive, fail-closed', () => {
  assert.equal(isModelActive('qwen3-27b-instruct', ['*27b*']), true);
  assert.equal(isModelActive('Qwen3-27B-MTP', ['*27b*']), true);
  assert.equal(isModelActive('deepseek-v4.1-flash', ['*27b*']), false);
  assert.equal(isModelActive('', ['*27b*']), false);
  assert.equal(isModelActive('anything', []), true);
  assert.equal(isModelActive(undefined, []), true);
});

test('observeShell: repeated passing check emits one soft steer, then stays silent', () => {
  const s = createState();
  const args = { command: 'python -m pytest tests/test_x.py -q' };
  const text = '2 passed in 0.5s';
  assert.equal(observeShell(s, commandOf(args), text, 3), null);
  assert.equal(observeShell(s, commandOf(args), text, 3), null);
  assert.equal(observeShell(s, commandOf(args), text, 3), SOFT_STEER);
  assert.equal(observeShell(s, commandOf(args), text, 3), null, 'steer is emitted only once until reset');
});

test('observeShell: two distinct passing families emit strong steer', () => {
  const s = createState();
  const pytest = { command: 'python -m pytest tests/test_a.py' };
  const build = { command: 'npm run build' };
  assert.equal(observeShell(s, commandOf(pytest), '1 passed', 3), null);
  assert.equal(observeShell(s, commandOf(build), 'Build succeeded', 3), STRONG_STEER);
  assert.equal(observeShell(s, commandOf(build), 'Build succeeded', 3), null, 'strong steer is also emitted once');
});

test('observeShell: failures and unknown commands are ignored', () => {
  const s = createState();
  assert.equal(observeShell(s, 'npm test', '1 failed', 3), null);
  assert.equal(observeShell(s, 'ls -la', 'some listing', 3), null);
  assert.equal(s.passedFamilies.size, 0);
  assert.equal(s.consecutivePassCount, 0);
});

test('observeShell: edit/write resets the convergence state', () => {
  const s = createState();
  const args = { command: 'npm test' };
  const text = '1 passed';
  observeShell(s, commandOf(args), text, 3);
  observeShell(s, commandOf(args), text, 3);
  resetState(s); // host calls this on tools/pre-execute for edit/write
  assert.equal(observeShell(s, commandOf(args), text, 3), null, 'counter restarts after a source edit');
});

test('looksPassed: "N passed; 0 failed" reports are PASSING, not failing', () => {
  // Old rule: t.includes("failed") -> not passed, so "3 passed; 0 failed" counted as
  // a failure and the convergence steer never fired on the plugin's own happy path.
  assert.equal(looksPassed('3 passed; 0 failed; 0 ignored', 'test'), true);
  assert.equal(looksPassed('121 pass / 0 fail', 'test'), true);
  assert.equal(looksPassed('Tests: 2 failed, 8 passed', 'test'), false);
  assert.equal(looksPassed('1 failed', 'test'), false);
  assert.equal(looksPassed('Compiled successfully', 'build'), true);
  assert.equal(looksPassed('BUILD FAILED in 2.1s', 'build'), false);
  assert.equal(looksPassed('returned 200 items', 'runtime'), true);
});

test('classifyCheck: known command shapes map to the right family', () => {
  assert.equal(classifyCheck('python -m pytest tests/test_a.py -q').family, 'test');
  assert.equal(classifyCheck('npm run build').family, 'build');
  assert.equal(classifyCheck('npm test').family, 'test');
  assert.equal(classifyCheck('ls -la'), null);
});

test('observeShell: a zero-failure test report participates in convergence', () => {
  const s = createState();
  const cmd = 'node --test test/*.test.js';
  assert.equal(observeShell(s, cmd, '3 passed; 0 failed', 3), null);
  assert.equal(observeShell(s, cmd, '3 passed; 0 failed', 3), null);
  assert.equal(observeShell(s, cmd, '3 passed; 0 failed', 3), SOFT_STEER);
});

test('observeShell: the SOFT_STEER decision uses the sliding window, not the cumulative histogram (issue#3 S1)', () => {
  // The same fingerprint appears 3 times SPREAD OUT across the session (never consecutively,
  // so the consecutivePassCount guard stays under threshold). A cumulative histogram would
  // see count=3 and over-trigger a steer inside a long, healthy session; the ring window of
  // 4 only ever sees at most 2 of those repeats -> no steer. This is the "cure, don't
  // interrupt" property from the report.
  const s = createState();
  const cmd = 'node --test test/a.test.js'; // fingerprint npm_test:default
  const other = 'python -m pytest tests/ -q'; // fingerprint pytest:all, same family
  const ok = '2 passed; 0 failed';
  const W = 4;
  // Positions 1,3,5 hold the tracked fingerprint; 2,4,6 hold the distractors.
  assert.equal(observeShell(s, cmd, ok, 3, W), null);
  assert.equal(observeShell(s, other, ok, 3, W), null);
  assert.equal(observeShell(s, cmd, ok, 3, W), null);
  assert.equal(observeShell(s, other, ok, 3, W), null);
  assert.equal(observeShell(s, cmd, ok, 3, W), null, 'cumulative count 3 but windowed count 2 < threshold 3 -> no steer');
  assert.equal(observeShell(s, other, ok, 3, W), null);
  assert.equal(observeShell(s, cmd, ok, 3, W), null, 'tracked fingerprint keeps steering off even after more passes');
  // Cumulative histogram keeps full history; the window does not:
  assert.equal(s.fingerprintCounts.get(classifyCheck(cmd).fingerprint), 4, 'cumulative histogram still counts 4 (positions 1,3,5,7)');
});

test('observeShell: the window never shrinks the original "3 repeats -> steer" contract', () => {
  const s = createState();
  const args = { command: 'npm test' };
  const text = '1 passed';
  assert.equal(observeShell(s, commandOf(args), text, 3), null);
  assert.equal(observeShell(s, commandOf(args), text, 3), null);
  assert.equal(observeShell(s, commandOf(args), text, 3), SOFT_STEER, 'default window preserves 3x repeat behaviour');
});

test('POLICY_TEXT exists and is a stable completion policy', () => {
  assert.match(POLICY_TEXT, /TASK COMPLETION POLICY/);
  assert.match(POLICY_TEXT, /within 8000 tokens/);
});
