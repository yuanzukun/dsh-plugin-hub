<h1 align="center">dsh-minimal-vision</h1>

<p align="center"><strong>Preserve minimal mode's context boundary while adding vision on demand</strong></p>

<p align="center">
  <a href="./README.md">中文</a> · <strong>English</strong>
</p>

<p align="center">
  🎬 <strong>Introduction video: </strong><a href="https://www.bilibili.com/video/BV1odbi6rE69"><strong>Open-source DSH Minimal Mode Vision Plugin 👀 Lightweight + Clean</strong></a>
</p>

<p align="center">
  <img src="./docs/assets/visual-in-minimal-mode.png" alt="See first, then answer: vision in minimal mode" width="820">
</p>

> Vision is not a new chat model or a third resident tool. It enters the Agent workflow only when needed, through hidden context and Bash.

## Why minimal mode?

Minimal mode is valuable not only because it has fewer tools, but because the first request starts with a clean, stable system prompt and tool surface. The DS behavior observed in gray testing depends on that starting point; extra system prompts, chat tools, or a registered vision model can change it.

This plugin does not rewrite minimal mode's system prompt or register a vision provider as a chat model. Vision instructions, image paths, and document paths arrive as one collapsed context message alongside the user request. The original two tools remain unchanged, providing image understanding while preserving minimal-mode behavior as far as possible.

| Constraint | Implementation |
| --- | --- |
| Preserve the original tool surface | Only <code>persistent-bash</code> and <code>str_replace_editor</code> remain exposed to the model |
| Keep the system prompt clean | Attachment paths and usage instructions live in collapsed context |
| Invoke vision on demand | The Agent calls <code>dsh-vision</code> through Bash only when visual evidence is needed |
| Keep document work separate | PDF, Word, and PowerPoint reading, export, cropping, stitching, and editing remain Agent tasks |

<p align="center">
  <img src="./docs/assets/clean-context-workflow.png" alt="Minimal surface, full capability: vision enters on demand" width="760">
</p>

## 🧭 Workflow

1. The user drops an image or document in <code>vision-assist</code> mode.
2. <code>sharp</code> normalizes images and caps the long edge at 1600 px; PDF, DOC, DOCX, PPT, and PPTX files are stored unchanged.
3. The plugin places local attachment paths in hidden context, keeping the user message bubble clean.
4. The Agent decides how to inspect or export documents with Bash and calls the vision model only when visual evidence is useful.

PNG, JPEG, WebP, GIF, PDF, DOC, DOCX, PPT, and PPTX are supported, with up to four images per request. “Test connection” sends only a minimal text request and never uploads an attachment. Vision settings stay separate from the chat model list.

Attachments are written to the local <code>$DSH_HOME/cache/dsh-tool-vision/</code> cache when sent, while hidden context contains only local paths. Documents are never sent directly to the vision endpoint; only images explicitly passed to <code>dsh-vision</code> by the Agent are sent to the configured vision service.

## 📦 Install

> ⚠️ **Compatibility notice: Native Windows PowerShell is not supported yet. The current version requires a Bash environment and has been tested on Ubuntu and WSL2. Windows users should install and run DSH and this plugin inside WSL2 for now. Native Windows PowerShell support is coming soon.**

~~~bash
git clone https://github.com/Flora233333/dsh-minimal-vision.git
cd dsh-minimal-vision
npm install
dsh plugin --profile web add .
dsh web
~~~

Select “Vision Assist” after startup, then configure the provider under “Settings -> Vision”.

## Configuration

| Field | Description |
| --- | --- |
| API protocol | OpenAI Completions or Gemini |
| Base URL | The endpoint supplied by the vision provider |
| Model | The provider's vision model ID |
| API key | Stored by DSH as <code>VISION_API_KEY</code> |

No provider endpoint is hard-coded. The CLI reads <code>$DSH_HOME/settings.yaml</code> and <code>$DSH_HOME/.credentials.yaml</code> on every call; the <code>VISION_API_KEY</code> environment variable takes precedence.

## CLI

~~~bash
"${DSH_HOME:-$HOME/.dsh}/bin/dsh-vision" \
  analyze --task custom --instructions "Describe the visible content" -- /path/to/image.png
~~~

Built-in tasks: <code>custom</code>, <code>slide_review</code>, <code>figure_semantics</code>, <code>caption_grounding</code>, and <code>flowchart_extract</code>. Export PPT/PPTX/PDF pages to images before calling the CLI.

## Development

~~~bash
npm install
npm run check
npm test
~~~

Do not commit <code>node_modules/</code>, <code>.playwright-cli/</code>, <code>.env</code>, or DSH credential files.
