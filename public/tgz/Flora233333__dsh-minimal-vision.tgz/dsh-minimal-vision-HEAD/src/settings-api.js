import { normalizeVisionBaseUrl, VISION_CREDENTIAL_REF } from './config.js'

export const VISION_CONFIG_PATH = '/dsh-vision/api/config'

const API_STYLES = new Set(['openai_chat_completions', 'gemini_generate_content'])
const MAX_BODY_BYTES = 16384

function sendJson(response, status, value, headers = {}) {
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    ...headers
  })
  response.end(JSON.stringify(value))
}

async function readJson(request) {
  let raw = ''
  for await (const chunk of request) {
    raw += chunk
    if (Buffer.byteLength(raw) > MAX_BODY_BYTES) throw new Error('配置请求过大')
  }
  try {
    return JSON.parse(raw || '{}')
  } catch {
    throw new Error('配置请求不是有效 JSON')
  }
}

async function publicState(settingsScope, credentials) {
  const credential = await credentials.describe(VISION_CREDENTIAL_REF)
  return {
    ok: true,
    config: settingsScope.get(),
    credential
  }
}

export function createVisionConfigHandler({ settingsScope, credentials }) {
  return async function visionConfigHandler(request, response) {
    if (request.method === 'GET') {
      sendJson(response, 200, await publicState(settingsScope, credentials))
      return
    }
    if (request.method !== 'POST') {
      sendJson(response, 405, { ok: false, error: '仅支持 GET 和 POST 请求' }, { allow: 'GET, POST' })
      return
    }
    if (request.headers['x-dsh-vision-settings'] !== '1') {
      sendJson(response, 403, { ok: false, error: '无效的配置请求' })
      return
    }

    try {
      const body = await readJson(request)
      const apiStyle = String(body.apiStyle ?? '')
      if (!API_STYLES.has(apiStyle)) throw new Error('不支持的 API 协议')
      const baseUrl = normalizeVisionBaseUrl(body.baseUrl ?? '')
      const model = String(body.model ?? '').trim()
      if (!baseUrl) throw new Error('API 地址不能为空')
      if (!model) throw new Error('模型不能为空')

      await settingsScope.replace({ baseUrl, model, apiStyle })
      if (body.clearApiKey === true) {
        await credentials.unset(VISION_CREDENTIAL_REF)
      } else if (typeof body.apiKey === 'string' && body.apiKey.length > 0) {
        const key = body.apiKey.trim()
        if (!/^[\x21-\x7e]+$/.test(key)) throw new Error('API Key 包含空格或不支持的字符')
        await credentials.set(VISION_CREDENTIAL_REF, key)
      }
      sendJson(response, 200, await publicState(settingsScope, credentials))
    } catch (error) {
      sendJson(response, 400, {
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      })
    }
  }
}
