const pendingBySession = new Map()

export function recordPendingVisionFile(sessionId, file) {
  const files = pendingBySession.get(sessionId) ?? []
  files.push(file)
  pendingBySession.set(sessionId, files)
}

export function takePendingVisionFiles(sessionId) {
  const files = pendingBySession.get(sessionId) ?? []
  pendingBySession.delete(sessionId)
  return files
}
