import { chmodSync, mkdirSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

export function dshHome() {
  return process.env.DSH_HOME?.trim() || join(homedir(), '.dsh')
}

export function visionCliPath() {
  return fileURLToPath(new URL('./cli.js', import.meta.url))
}

export function visionLauncherPath(home = dshHome()) {
  return join(home, 'bin', 'dsh-vision')
}

export function shellQuote(value) {
  return `'${String(value).replaceAll("'", `'"'"'`)}'`
}

export function renderVisionLauncher(options = {}) {
  const home = options.home ?? dshHome()
  const node = options.node ?? process.execPath
  const cli = options.cli ?? visionCliPath()
  return [
    '#!/bin/sh',
    `export DSH_HOME=${shellQuote(home)}`,
    `exec ${shellQuote(node)} ${shellQuote(cli)} "$@"`,
    ''
  ].join('\n')
}

export function installVisionLauncher(home = dshHome()) {
  const launcher = visionLauncherPath(home)
  mkdirSync(join(home, 'bin'), { recursive: true })
  writeFileSync(launcher, renderVisionLauncher({ home }), { encoding: 'utf8', mode: 0o755 })
  chmodSync(launcher, 0o755)
  return launcher
}

export function visionCommand(home = dshHome()) {
  return `DSH_HOME=${shellQuote(home)} ${shellQuote(visionLauncherPath(home))}`
}
