import { readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { homedir } from 'node:os'
import yaml from 'js-yaml'

export const VISION_SETTINGS_NAMESPACE = 'dsh-tool-vision'
export const VISION_CREDENTIAL_REF = 'VISION_API_KEY'

export const DEFAULT_VISION_PROVIDER = Object.freeze({
  baseUrl: '',
  model: '',
  apiStyle: 'openai_chat_completions',
  timeoutMs: 120000
})

export function normalizeVisionBaseUrl(value) {
  const baseUrl = String(value ?? '').trim()
  if (!baseUrl) return ''

  let parsed
  try {
    parsed = new URL(baseUrl)
  } catch {
    throw new Error('Vision baseURL must be a valid URL')
  }

  if (!['http:', 'https:'].includes(parsed.protocol)) {
    throw new Error('Vision baseURL must use http:// or https://')
  }

  return baseUrl
}

async function readYaml(path) {
  try {
    return yaml.load(await readFile(path, 'utf8')) ?? {}
  } catch (error) {
    if (error?.code === 'ENOENT') return {}
    throw new Error(`cannot read ${path}: ${error.message}`, { cause: error })
  }
}

function credentialValue(value) {
  if (typeof value === 'string') return value
  if (value && typeof value.value === 'string') return value.value
  return ''
}

function legacyApiStyle(api) {
  if (!api || api === 'openai-completions') return 'openai_chat_completions'
  if (['google-generative-ai', 'google-gemini', 'gemini'].includes(api)) {
    return 'gemini_generate_content'
  }
  throw new Error(`unsupported Vision API protocol "${api}"`)
}

function legacyProvider(settings) {
  const provider = settings?.['llm-pi-ai']?.providers?.vision
  if (!provider) return undefined
  const modelEntry = Array.isArray(provider.models) ? provider.models[0] : undefined
  return {
    baseUrl: provider.baseURL ?? '',
    model: (typeof modelEntry === 'string' ? modelEntry : modelEntry?.id) ?? '',
    apiStyle: legacyApiStyle(provider.api),
    timeoutMs: Number(provider.timeoutMs) || DEFAULT_VISION_PROVIDER.timeoutMs
  }
}

export function normalizeVisionConfig(raw, apiKey = '') {
  const baseUrl = normalizeVisionBaseUrl(raw?.baseUrl ?? '')
  const model = String(raw?.model ?? '').trim()
  const apiStyle = raw?.apiStyle ?? DEFAULT_VISION_PROVIDER.apiStyle
  if (!baseUrl) throw new Error('Vision baseURL is not configured; configure it in Settings > Vision')
  if (!model) throw new Error('Vision model is not configured; configure it in Settings > Vision')
  if (!['openai_chat_completions', 'gemini_generate_content'].includes(apiStyle)) {
    throw new Error(`unsupported Vision API protocol "${apiStyle}"`)
  }
  if (!apiKey && !/^https?:\/\/(localhost|127\.0\.0\.1)(?::|\/|$)/i.test(baseUrl)) {
    throw new Error(`credential ${VISION_CREDENTIAL_REF} is missing; configure the API key in Settings > Vision`)
  }
  return {
    provider: 'vision',
    model,
    baseUrl,
    apiKey,
    apiKeyEnv: VISION_CREDENTIAL_REF,
    apiStyle,
    timeoutMs: Number(raw?.timeoutMs) || DEFAULT_VISION_PROVIDER.timeoutMs
  }
}

export async function readVisionConfig(options = {}) {
  const home = options.dshHome ?? (process.env.DSH_HOME?.trim() || join(homedir(), '.dsh'))
  const settings = await readYaml(join(home, 'settings.yaml'))
  const credentials = await readYaml(join(home, '.credentials.yaml'))
  const config = {
    ...DEFAULT_VISION_PROVIDER,
    ...(settings?.[VISION_SETTINGS_NAMESPACE] ?? legacyProvider(settings) ?? {})
  }
  const apiKey = process.env[VISION_CREDENTIAL_REF] || credentialValue(credentials?.[VISION_CREDENTIAL_REF])
  return normalizeVisionConfig(config, apiKey)
}
