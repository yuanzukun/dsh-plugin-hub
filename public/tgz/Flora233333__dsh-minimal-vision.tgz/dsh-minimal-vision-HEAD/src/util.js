// Small, dependency-free helpers. Everything here is synchronous and total.

export function truncateText(text, maxChars) {
  if (maxChars <= 0) return ''
  if (typeof text !== 'string') text = String(text ?? '')
  if (text.length <= maxChars) return text
  return text.slice(0, maxChars) + `… (truncated to ${maxChars} chars)`
}

export function stripJsonFences(text) {
  if (typeof text !== 'string') return text
  let out = text.trim()
  out = out.replace(/^```(?:json|JSON)?\s*/i, '')
  out = out.replace(/\s*```$/, '')
  return out.trim()
}

export function parseJsonObject(text) {
  const stripped = stripJsonFences(text)
  let lastError

  // Models sometimes surround the object with prose, emit two objects, or
  // include braces inside a quoted value. Find balanced object candidates and
  // validate each one independently instead of slicing from first to last brace.
  for (let start = 0; start < stripped.length; start += 1) {
    if (stripped[start] !== '{') continue
    let depth = 0
    let inString = false
    let escaped = false
    for (let index = start; index < stripped.length; index += 1) {
      const char = stripped[index]
      if (inString) {
        if (escaped) escaped = false
        else if (char === '\\') escaped = true
        else if (char === '"') inString = false
        continue
      }
      if (char === '"') {
        inString = true
        continue
      }
      if (char === '{') depth += 1
      else if (char === '}') {
        depth -= 1
        if (depth === 0) {
          const candidate = stripped.slice(start, index + 1)
          try {
            const value = JSON.parse(candidate)
            if (value && typeof value === 'object' && !Array.isArray(value)) return value
          } catch (error) {
            lastError = error
          }
          break
        }
      }
    }
  }

  if (lastError) {
    throw new Error(`Invalid JSON object in model output: ${lastError.message}`)
  }
  throw new Error(`No JSON object found in model output (${text.length} chars)`)
}

export function assertPlainObject(value, label = 'value') {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error(`${label} must be a JSON object`)
  }
  return value
}

export function trimBaseUrl(value) {
  return String(value ?? '').trim().replace(/\/+$/, '')
}

export function chatCompletionsUrl(baseUrl) {
  const base = trimBaseUrl(baseUrl)
  if (!base) throw new Error('baseUrl is empty')
  if (/\/v1$/i.test(base)) return `${base}/chat/completions`
  return `${base}/v1/chat/completions`
}

export function geminiGenerateContentUrl(baseUrl, model) {
  const base = trimBaseUrl(baseUrl)
  if (!base) throw new Error('baseUrl is empty')
  if (/\/v1beta$/i.test(base)) return `${base}/models/${encodeURIComponent(model)}:generateContent`
  return `${base}/v1beta/models/${encodeURIComponent(model)}:generateContent`
}
