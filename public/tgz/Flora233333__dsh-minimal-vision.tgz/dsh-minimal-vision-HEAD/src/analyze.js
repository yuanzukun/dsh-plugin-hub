import { resolveImageFile } from './image.js'
import { buildVisionMessages, getTask } from './tasks.js'
import { analyzeWithProvider } from './providers.js'
import { assertPlainObject, parseJsonObject, truncateText } from './util.js'

export const MAX_IMAGES_PER_CALL = 4

function schemaAllowsNull(schema) {
  return Array.isArray(schema?.type) && schema.type.includes('null')
}

function normalizeTaskResult(value, task) {
  if (task.id === 'caption_grounding' && value.caption_match === null) {
    return { ...value, matched_caption: null, correct_caption: null }
  }
  return value
}

function parseResult(text, task, maxOutputChars) {
  const value = normalizeTaskResult(assertPlainObject(parseJsonObject(text), 'vision result'), task)
  const required = task.jsonSchema?.required ?? []
  const missing = required.filter((key) => value[key] === undefined || (value[key] === null && !schemaAllowsNull(task.jsonSchema?.properties?.[key])))
  if (missing.length) throw new Error(`vision result is missing: ${missing.join(', ')}`)
  const raw = JSON.stringify(value)
  if (raw.length <= maxOutputChars) return { value, truncated: false }
  return {
    value: {
      _truncated: true,
      original_json_chars: raw.length,
      preview: truncateText(raw, maxOutputChars)
    },
    truncated: true
  }
}

async function callAndParse(settings, task, messages, imageDataUrls, maxOutputChars, signal) {
  const request = {
    system: messages.system,
    user: messages.user,
    imageDataUrls,
    jsonSchema: task.jsonSchema,
    maxOutputTokens: task.maxOutputTokens
  }
  const response = await analyzeWithProvider(settings, request, signal)
  try {
    return { ...parseResult(response.text, task, maxOutputChars), apiStyle: response.apiStyle }
  } catch (error) {
    return {
      value: {
        _unparsed: true,
        parse_error: error instanceof Error ? error.message : String(error),
        raw_text: truncateText(response.text, maxOutputChars)
      },
      truncated: response.text.length > maxOutputChars,
      apiStyle: response.apiStyle
    }
  }
}

export async function analyzeImages({ settings, task: taskId, instructions, imagePaths, signal, maxImages = MAX_IMAGES_PER_CALL, maxImageBytes = 20 * 1024 * 1024, maxOutputChars = 16000 }) {
  const started = Date.now()
  if (!Array.isArray(imagePaths) || imagePaths.length === 0) throw new Error('provide at least one image after --')
  if (imagePaths.length > maxImages) throw new Error(`at most ${maxImages} images are accepted per call`)
  if (!String(instructions ?? '').trim()) throw new Error('--instructions must not be empty')
  const task = getTask(taskId)
  const images = await Promise.all(imagePaths.map((path) => resolveImageFile(path, maxImageBytes)))
  const parsed = await callAndParse(
    settings,
    task,
    buildVisionMessages(task, instructions, images.length),
    images.map((image) => image.dataUrl),
    maxOutputChars,
    signal
  )
  return {
    provider: 'vision',
    model: settings.model,
    api_style: parsed.apiStyle,
    task: task.id,
    images: images.map(({ path, mimeType, bytes, inputMimeType, inputBytes, width, height }) => ({
      path,
      mime_type: mimeType,
      bytes,
      input_mime_type: inputMimeType,
      input_bytes: inputBytes,
      width,
      height
    })),
    result: parsed.value,
    latency_ms: Date.now() - started,
    truncated: parsed.truncated
  }
}
