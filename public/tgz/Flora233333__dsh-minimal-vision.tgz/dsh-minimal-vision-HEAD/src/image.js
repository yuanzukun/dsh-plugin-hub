import { readFile, stat } from 'node:fs/promises'
import { resolve } from 'node:path'
import sharp from 'sharp'

export const DEFAULT_MAX_EDGE = 1600
export const DEFAULT_JPEG_QUALITY = 85

const EXT_MIME = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif'
}

const MAGIC = [
  { mime: 'image/png', check: (b) => b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 },
  { mime: 'image/jpeg', check: (b) => b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff },
  { mime: 'image/webp', check: (b) => b.length > 12 && b.toString('latin1', 0, 4) === 'RIFF' && b.toString('latin1', 8, 12) === 'WEBP' },
  { mime: 'image/gif', check: (b) => b.length > 6 && ['GIF87a', 'GIF89a'].includes(b.toString('latin1', 0, 6)) }
]

export function mimeFromPath(path) {
  const lower = String(path).toLowerCase()
  const extension = Object.keys(EXT_MIME).sort((a, b) => b.length - a.length).find((ext) => lower.endsWith(ext))
  return extension ? EXT_MIME[extension] : undefined
}

export function sniffMime(bytes) {
  return MAGIC.find((entry) => entry.check(bytes))?.mime
}

export async function optimizeImageBuffer(bytes, options = {}) {
  const input = Buffer.isBuffer(bytes) ? bytes : Buffer.from(bytes)
  const detectedMime = sniffMime(input)
  if (!detectedMime) throw new Error('unsupported or invalid image bytes (use PNG/JPEG/WebP/GIF)')
  if (options.declaredMime && options.declaredMime !== detectedMime) {
    throw new Error(`image bytes do not match ${options.declaredMime}`)
  }

  const maxEdge = Number(options.maxEdge) || DEFAULT_MAX_EDGE
  const quality = Number(options.quality) || DEFAULT_JPEG_QUALITY
  const output = await sharp(input, {
    failOn: 'error',
    limitInputPixels: 64 * 1024 * 1024,
    animated: false
  })
    .rotate()
    .resize({
      width: maxEdge,
      height: maxEdge,
      fit: 'inside',
      withoutEnlargement: true,
      kernel: sharp.kernel.lanczos3
    })
    .flatten({ background: '#ffffff' })
    .jpeg({
      quality,
      progressive: true,
      chromaSubsampling: '4:4:4',
      mozjpeg: true
    })
    .toBuffer()

  const metadata = await sharp(output).metadata()
  return {
    bytes: output,
    mimeType: 'image/jpeg',
    width: metadata.width,
    height: metadata.height,
    inputMimeType: detectedMime,
    inputBytes: input.length
  }
}

export async function resolveImageFile(imagePath, maxImageBytes = 20 * 1024 * 1024) {
  if (!imagePath || !String(imagePath).trim()) throw new Error('image path must be non-empty')
  const path = resolve(String(imagePath).trim())
  const declaredMime = mimeFromPath(path)
  if (!declaredMime) throw new Error(`unsupported image type: "${path}" (use PNG/JPEG/WebP/GIF)`)
  const info = await stat(path)
  if (!info.isFile()) throw new Error(`image path is not a regular file: ${path}`)
  if (info.size > maxImageBytes) throw new Error(`image exceeds ${maxImageBytes} bytes: ${path}`)
  const input = await readFile(path)
  let optimized
  if (declaredMime === 'image/jpeg' && path.endsWith('.dsv.jpg')) {
    if (sniffMime(input) !== declaredMime) throw new Error(`image bytes do not match ${declaredMime}: ${path}`)
    const metadata = await sharp(input).metadata()
    optimized = {
      bytes: input,
      mimeType: declaredMime,
      width: metadata.width,
      height: metadata.height,
      inputMimeType: declaredMime,
      inputBytes: input.length
    }
  } else {
    optimized = await optimizeImageBuffer(input, { declaredMime })
  }
  return {
    path,
    mimeType: optimized.mimeType,
    bytes: optimized.bytes.length,
    inputMimeType: optimized.inputMimeType,
    inputBytes: optimized.inputBytes,
    width: optimized.width,
    height: optimized.height,
    dataUrl: `data:${optimized.mimeType};base64,${optimized.bytes.toString('base64')}`
  }
}
