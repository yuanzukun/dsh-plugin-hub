import { chatCompletionsUrl, geminiGenerateContentUrl, trimBaseUrl, truncateText } from './util.js'

export const API_STYLES = Object.freeze(['openai_chat_completions', 'gemini_generate_content'])
export const PROVIDER_MODES = Object.freeze(['ollama', 'llamastudio', 'cloud'])

const RESPONSE_SUCCESS_READ_LIMIT = 1024 * 1024
const RESPONSE_ERROR_READ_LIMIT = 16000

function timeoutSignal(parentSignal, timeoutMs) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(new Error(`vision provider timed out after ${timeoutMs}ms`)), timeoutMs)
  const onAbort = () => {
    clearTimeout(timer)
    controller.abort(parentSignal?.reason ?? new Error('vision request aborted'))
  }
  if (parentSignal?.aborted) {
    onAbort()
  } else {
    parentSignal?.addEventListener('abort', onAbort, { once: true })
  }
  return { signal: controller.signal, cleanup: () => { clearTimeout(timer); parentSignal?.removeEventListener('abort', onAbort) } }
}

async function readBounded(response, maxChars = RESPONSE_SUCCESS_READ_LIMIT) {
  if (!response.body) return truncateText(await response.text(), maxChars)
  const reader = response.body.getReader()
  const decoder = new TextDecoder()
  let out = ''
  try {
    while (out.length < maxChars) {
      const { done, value } = await reader.read()
      if (done) break
      out += decoder.decode(value, { stream: true })
    }
    out += decoder.decode()
  } finally {
    reader.releaseLock()
  }
  return truncateText(out, maxChars)
}

async function fetchJson(url, options, timeoutMs, signal) {
  const { signal: merged, cleanup } = timeoutSignal(signal, timeoutMs)
  try {
    const response = await fetch(url, { ...options, signal: merged, redirect: 'error' })
    const body = await readBounded(
      response,
      response.ok ? RESPONSE_SUCCESS_READ_LIMIT : RESPONSE_ERROR_READ_LIMIT
    )
    if (!response.ok) {
      const err = new Error(`vision provider HTTP ${response.status}: ${body}`)
      err.code = 'VISION_PROVIDER_HTTP'
      err.status = response.status
      throw err
    }
    return { response, body }
  } catch (error) {
    if (merged.aborted || error?.name === 'AbortError') {
      const err = signal?.aborted
        ? new Error('vision provider request was cancelled')
        : new Error(`vision provider timed out after ${timeoutMs}ms`)
      err.code = signal?.aborted ? 'VISION_PROVIDER_CANCELLED' : 'VISION_PROVIDER_TIMEOUT'
      throw err
    }
    throw error
  } finally {
    cleanup()
  }
}

export async function analyzeWithOpenAiCompatible({ baseUrl, model, apiKey = '', system, user, imageDataUrls, jsonSchema, maxOutputTokens, timeoutMs = 120000, signal, useJsonFormat = true }) {
  const url = chatCompletionsUrl(baseUrl)
  const content = [{ type: 'text', text: user }]
  for (const imageUrl of imageDataUrls) {
    content.push({ type: 'image_url', image_url: { url: imageUrl } })
  }
  const body = {
    model,
    temperature: 0,
    messages: [
      { role: 'system', content: system },
      { role: 'user', content }
    ]
  }
  if (useJsonFormat) body.response_format = { type: 'json_object' }
  if (Number.isInteger(maxOutputTokens) && maxOutputTokens > 0) body.max_tokens = maxOutputTokens

  const headers = { 'Content-Type': 'application/json' }
  if (apiKey && apiKey.trim()) headers.Authorization = `Bearer ${apiKey.trim()}`

  let result
  try {
    result = await fetchJson(url, { method: 'POST', headers, body: JSON.stringify(body) }, timeoutMs, signal)
  } catch (error) {
    // Some OpenAI-compatible gateways reject response_format but accept the
    // same request without it. Retry once with prompt-only JSON enforcement.
    if (useJsonFormat && (error?.status === 400 || error?.status === 404 || error?.status === 422)) {
      return analyzeWithOpenAiCompatible({ baseUrl, model, apiKey, system, user, imageDataUrls, jsonSchema, maxOutputTokens, timeoutMs, signal, useJsonFormat: false })
    }
    throw error
  }

  let parsed
  try {
    parsed = JSON.parse(result.body)
  } catch {
    const err = new Error(`vision provider returned non-JSON body: ${truncateText(result.body, 300)}`)
    err.code = 'VISION_PROVIDER_BAD_RESPONSE'
    throw err
  }
  const message = parsed?.choices?.[0]?.message
  const contentText = message?.content
  const reasoningText = message?.reasoning_content ?? message?.reasoning
  if (typeof contentText !== 'string' || contentText.trim() === '') {
    if (typeof reasoningText === 'string' && reasoningText.trim()) {
      return { text: reasoningText, body: parsed, apiStyle: 'openai_chat_completions' }
    }
    const err = new Error(`vision provider returned no assistant content: ${truncateText(result.body, 500)}`)
    err.code = 'VISION_PROVIDER_EMPTY_CONTENT'
    throw err
  }
  return { text: contentText, body: parsed, apiStyle: 'openai_chat_completions' }
}

export async function analyzeWithGemini({ baseUrl, model, apiKey = '', system, user, imageDataUrls, jsonSchema, maxOutputTokens, timeoutMs = 120000, signal }) {
  const url = geminiGenerateContentUrl(baseUrl, model)
  const parts = [{ text: `${system}\n\n${user}` }]
  for (const dataUrl of imageDataUrls) {
    const comma = dataUrl.indexOf(',')
    if (comma < 0) throw new Error('internal error: invalid image data URL')
    const meta = dataUrl.slice(0, comma)
    const mime = meta.match(/data:([^;]+);base64/)?.[1]
    const data = dataUrl.slice(comma + 1)
    parts.push({ inline_data: { mime_type: mime, data } })
  }
  const body = {
    contents: [{ role: 'user', parts }],
    generationConfig: {
      temperature: 0,
      responseMimeType: 'application/json',
      ...(Number.isInteger(maxOutputTokens) && maxOutputTokens > 0 ? { maxOutputTokens } : {})
    }
  }
  const headers = { 'Content-Type': 'application/json' }
  if (apiKey && apiKey.trim()) headers['x-goog-api-key'] = apiKey.trim()
  const result = await fetchJson(url, { method: 'POST', headers, body: JSON.stringify(body) }, timeoutMs, signal)
  let parsed
  try {
    parsed = JSON.parse(result.body)
  } catch {
    const err = new Error(`vision provider returned non-JSON body: ${truncateText(result.body, 300)}`)
    err.code = 'VISION_PROVIDER_BAD_RESPONSE'
    throw err
  }
  const partsOut = parsed?.candidates?.[0]?.content?.parts
  const text = Array.isArray(partsOut) ? partsOut.map((part) => part?.text ?? '').join('') : ''
  if (!text.trim()) {
    const err = new Error(`vision provider returned no candidate text: ${truncateText(result.body, 500)}`)
    err.code = 'VISION_PROVIDER_EMPTY_CONTENT'
    throw err
  }
  return { text, body: parsed, apiStyle: 'gemini_generate_content' }
}

export function normalizeSettings(settings) {
  const raw = settings ?? {}
  const baseUrl = trimBaseUrl(raw.baseUrl ?? '')
  const model = String(raw.model ?? '').trim()
  const apiKey = String(raw.apiKey ?? '').trim()
  if (!baseUrl) throw new Error('vision settings: baseUrl is empty')
  if (!model) throw new Error('vision settings: model is empty')
  return {
    mode: raw.mode ?? 'cloud',
    model,
    baseUrl,
    apiKey,
    apiStyle: raw.apiStyle ?? 'openai_chat_completions',
    timeoutMs: Number.isFinite(Number(raw.timeoutMs)) ? Number(raw.timeoutMs) : 120000
  }
}

export async function analyzeWithProvider(settings, payload, signal) {
  const normalized = normalizeSettings(settings)
  const common = {
    baseUrl: normalized.baseUrl,
    model: normalized.model,
    apiKey: normalized.apiKey,
    system: payload.system,
    user: payload.user,
    imageDataUrls: payload.imageDataUrls,
    jsonSchema: payload.jsonSchema,
    maxOutputTokens: payload.maxOutputTokens,
    timeoutMs: normalized.timeoutMs,
    signal
  }
  if (normalized.apiStyle === 'gemini_generate_content') {
    return analyzeWithGemini(common)
  }
  if (normalized.apiStyle === 'openai_chat_completions') {
    return analyzeWithOpenAiCompatible(common)
  }
  throw new Error(`unsupported vision apiStyle "${normalized.apiStyle}". Supported: ${API_STYLES.join(', ')}`)
}
