import { cpSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import z from '@deepseek-ai/schemastery'
import { createVisionTestHandler, VISION_TEST_PATH } from './connection-test.js'
import {
  DEFAULT_VISION_PROVIDER,
  normalizeVisionConfig,
  VISION_CREDENTIAL_REF,
  VISION_SETTINGS_NAMESPACE
} from './config.js'
import { createVisionConfigHandler, VISION_CONFIG_PATH } from './settings-api.js'
import { createVisionUploadHandler, VISION_UPLOAD_PATH } from './upload-api.js'
import { recordPendingVisionImage } from './pending-images.js'
import { createVisionFileUploadHandler, VISION_FILE_UPLOAD_PATH } from './file-upload-api.js'
import { recordPendingVisionFile } from './pending-files.js'
import { dshHome, installVisionLauncher } from './runtime-paths.js'

export const name = 'dsh-tool-vision'
export const inject = ['webServer', 'settings', 'credentials']

const PRESET_ID = 'vision-assist'
const SOURCE_DIR = fileURLToPath(new URL('../presets/vision-assist/', import.meta.url))

// The bundle row runs at DSH boot and keeps the packaged preset in sync.
export function apply(ctx) {
  const home = dshHome()
  const target = join(home, '.agent-presets', PRESET_ID)
  mkdirSync(target, { recursive: true })
  cpSync(SOURCE_DIR, target, { recursive: true, force: true })
  const launcher = installVisionLauncher(home)
  console.log(`[${name}] preset "${PRESET_ID}" -> ${target}; launcher -> ${launcher}`)

  if (!ctx?.webServer || !ctx?.settings || !ctx?.credentials) return

  const settingsScope = ctx.settings.register(VISION_SETTINGS_NAMESPACE, z.object({
    baseUrl: z.string().default(DEFAULT_VISION_PROVIDER.baseUrl),
    model: z.string().default(DEFAULT_VISION_PROVIDER.model),
    apiStyle: z.union(['openai_chat_completions', 'gemini_generate_content'])
      .default(DEFAULT_VISION_PROVIDER.apiStyle)
  }))
  const loadConfig = async () => {
    const credential = await ctx.credentials.resolve(VISION_CREDENTIAL_REF)
    return normalizeVisionConfig(settingsScope.get(), credential?.value ?? '')
  }
  const registerRoutes = () => {
    const disposeConfig = ctx.webServer.register({
      kind: 'exact',
      path: VISION_CONFIG_PATH,
      handler: createVisionConfigHandler({ settingsScope, credentials: ctx.credentials })
    })
    const disposeTest = ctx.webServer.register({
      kind: 'exact',
      path: VISION_TEST_PATH,
      handler: createVisionTestHandler({ loadConfig })
    })
    const disposeUpload = ctx.webServer.register({
      kind: 'exact',
      path: VISION_UPLOAD_PATH,
      handler: createVisionUploadHandler({ onStored: recordPendingVisionImage })
    })
    const disposeFileUpload = ctx.webServer.register({
      kind: 'exact',
      path: VISION_FILE_UPLOAD_PATH,
      handler: createVisionFileUploadHandler({ onStored: recordPendingVisionFile })
    })
    return () => {
      disposeFileUpload()
      disposeUpload()
      disposeTest()
      disposeConfig()
    }
  }
  ctx.effect(registerRoutes, `${name}: settings and connection test routes`)
}
