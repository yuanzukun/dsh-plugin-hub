#!/usr/bin/env node
import { analyzeImages } from './analyze.js'
import { readVisionConfig } from './config.js'

const USAGE = `Usage:
  dsh-vision analyze --task <task> --instructions <question> -- <image paths...>

Tasks: custom, slide_review, figure_semantics, caption_grounding, flowchart_extract
Input: PNG/JPEG/WebP/GIF; at most 4 images per call.`

function parseArgs(argv) {
  if (argv.includes('--help') || argv.includes('-h')) return { help: true }
  if (argv[0] !== 'analyze') throw new Error(USAGE)
  const separator = argv.indexOf('--')
  if (separator < 0) throw new Error(`missing -- before image paths\n\n${USAGE}`)
  const options = argv.slice(1, separator)
  const imagePaths = argv.slice(separator + 1)
  const parsed = { imagePaths }
  for (let index = 0; index < options.length; index += 2) {
    const flag = options[index]
    const value = options[index + 1]
    if (!value) throw new Error(`missing value for ${flag}`)
    if (flag === '--task') parsed.task = value
    else if (flag === '--instructions') parsed.instructions = value
    else throw new Error(`unknown option: ${flag}`)
  }
  if (!parsed.task) throw new Error('--task is required')
  if (!parsed.instructions) throw new Error('--instructions is required')
  return parsed
}

try {
  const args = parseArgs(process.argv.slice(2))
  if (args.help) {
    console.log(USAGE)
  } else {
    const settings = await readVisionConfig()
    const result = await analyzeImages({ settings, ...args })
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`)
  }
} catch (error) {
  console.error(`dsh-vision: ${error.message}`)
  if (process.env.DSH_VISION_DEBUG === '1') console.error(error.stack)
  process.exitCode = 1
}
