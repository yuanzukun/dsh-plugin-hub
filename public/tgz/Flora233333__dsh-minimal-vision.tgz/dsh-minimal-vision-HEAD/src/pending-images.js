const pendingBySession = new Map()

export function recordPendingVisionImage(sessionId, image) {
  const images = pendingBySession.get(sessionId) ?? []
  images.push(image)
  pendingBySession.set(sessionId, images)
}

export function takePendingVisionImages(sessionId) {
  const images = pendingBySession.get(sessionId) ?? []
  pendingBySession.delete(sessionId)
  return images
}
