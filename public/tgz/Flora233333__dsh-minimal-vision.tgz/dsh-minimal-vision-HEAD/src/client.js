window.__ModuleLoader__.load({
  id: 'dsh-tool-vision',
  factory: (require) => {
    const module = { exports: {} }
    const exports = module.exports
    const React = require('react')
    const { jsx, jsxs } = require('react/jsx-runtime')

    const css = '.dsv-section{max-width:720px;color:var(--dsw-alias-label-primary);display:flex;flex-direction:column;gap:14px}.dsv-title{margin:0;font-size:16px;font-weight:500;line-height:24px}.dsv-form{display:flex;flex-direction:column;gap:12px}.dsv-field{display:flex;flex-direction:column;gap:6px}.dsv-label{color:var(--dsw-alias-label-secondary);font-size:12px;font-weight:500;line-height:18px}.dsv-key-label{display:flex;align-items:center;justify-content:space-between;gap:10px}.dsv-key-state{font-size:12px;font-weight:400}.dsv-key-set{color:var(--dsw-alias-state-success-primary)}.dsv-key-missing{color:var(--dsw-alias-label-tertiary)}.dsv-input{box-sizing:border-box;width:100%;height:36px;border:1px solid var(--dsw-alias-border-l2);border-radius:8px;background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);padding:0 10px;font:inherit;font-size:14px;line-height:22px}.dsv-input:focus{border-color:var(--dsw-alias-brand-primary);outline:none}.dsv-input::placeholder{color:var(--dsw-alias-label-dimmed)}.dsv-input:disabled{cursor:default;opacity:.6}.dsv-actions{display:flex;align-items:center;flex-wrap:wrap;gap:8px;margin-top:4px}.dsv-button{box-sizing:border-box;height:36px;padding:0 14px;border-radius:18px;font:inherit;font-size:14px;line-height:22px;cursor:pointer}.dsv-primary{border:0;background:var(--dsw-alias-button-primary-fill);color:var(--dsw-alias-label-primary-foreground)}.dsv-primary:hover:not(:disabled){background:var(--dsw-alias-button-primary-hover)}.dsv-secondary{border:1px solid var(--dsw-alias-border-l2);background:transparent;color:var(--dsw-alias-label-primary)}.dsv-secondary:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}.dsv-danger{border:0;background:transparent;color:var(--dsw-alias-state-error-primary)}.dsv-danger:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover-danger)}.dsv-button:focus-visible{outline:none;box-shadow:0 0 0 2px var(--dsw-alias-border-l3)}.dsv-button:disabled{opacity:.45;cursor:default}.dsv-status{min-height:22px;margin:0;font-size:13px;line-height:22px;overflow-wrap:anywhere}.dsv-status-idle{color:var(--dsw-alias-label-tertiary)}.dsv-status-success{color:var(--dsw-alias-state-success-primary)}.dsv-status-error{color:var(--dsw-alias-state-error-primary)}@media(max-width:520px){.dsv-section{padding-top:40px}.dsv-actions{align-items:stretch;flex-direction:column}.dsv-button{width:100%}.dsv-status{font-size:12px;line-height:18px}}'
    if (typeof document !== 'undefined' && document.querySelector('style[data-plugin-css="dsh-tool-vision/client"]') === null) {
      const style = document.createElement('style')
      style.dataset.plugin = 'dsh-tool-vision'
      style.dataset.pluginCss = 'dsh-tool-vision/client'
      style.textContent = css
      document.head.appendChild(style)
    }

    function friendlyError(message) {
      const credential = message.match(/credential ([A-Z0-9_]+) is missing/i)
      if (credential) return `未配置 API Key（${credential[1]}）。`
      if (/Vision baseURL is (?:empty|not configured)/i.test(message)) return '尚未配置 API 地址。'
      if (/Vision model is (?:empty|not configured)/i.test(message)) return '尚未配置模型。'
      if (/HTTP (401|403)/i.test(message)) return '认证失败，请检查 API Key。'
      if (/timed out/i.test(message)) return '请求超时，请检查 API 地址和网络。'
      return message
    }

    async function readResponse(response) {
      const body = await response.json().catch(() => ({}))
      if (!response.ok || body.ok !== true) {
        throw new Error(body.error || `请求失败（HTTP ${response.status}）`)
      }
      return body
    }

    async function uploadVisionImage(file, sessionId) {
      const response = await fetch('/dsh-vision/api/images', {
        method: 'POST',
        headers: {
          'content-type': file.type,
          'x-dsh-vision-upload': '1',
          'x-dsh-session-id': sessionId
        },
        body: file
      })
      return (await readResponse(response)).image
    }

    async function uploadVisionFile(file, sessionId) {
      const response = await fetch('/dsh-vision/api/files', {
        method: 'POST',
        headers: {
          'content-type': file.type || 'application/octet-stream',
          'x-dsh-vision-file': '1',
          'x-dsh-session-id': sessionId,
          'x-dsh-file-name': encodeURIComponent(file.name)
        },
        body: file
      })
      return (await readResponse(response)).file
    }

    const VISION_PRESET = 'vision-assist'
    const VISION_IMAGE_NAME = /\.(?:png|jpe?g|webp|gif)$/i
    const VISION_FILE_NAME = /\.(?:pdf|docx?|pptx?)$/i

    function isVisionAssistSession(ctx, session) {
      const summary = ctx.sessions?.list?.getSnapshot?.().byId?.[session.sessionId]
      return summary?.agentPreset === VISION_PRESET
    }

    function isVisionImageFile(file) {
      return VISION_IMAGE_NAME.test(String(file?.name ?? ''))
    }

    function isVisionDocumentFile(file) {
      return VISION_FILE_NAME.test(String(file?.name ?? ''))
    }

    async function createDocumentPlaceholder(file) {
      const extension = String(file.name).split('.').pop()?.toUpperCase() || 'FILE'
      const canvas = document.createElement('canvas')
      canvas.width = 128
      canvas.height = 128
      const context = canvas.getContext('2d')
      if (!context) throw new Error('无法创建文件预览')
      context.fillStyle = '#f4f5f6'
      context.fillRect(0, 0, 128, 128)
      context.fillStyle = '#ffffff'
      context.strokeStyle = '#b8bec6'
      context.lineWidth = 4
      context.fillRect(26, 14, 76, 100)
      context.strokeRect(26, 14, 76, 100)
      context.fillStyle = '#3f464d'
      context.font = '600 22px sans-serif'
      context.textAlign = 'center'
      context.textBaseline = 'middle'
      context.fillText(extension.slice(0, 5), 64, 66)
      const blob = await new Promise((resolve, reject) => {
        canvas.toBlob((value) => value ? resolve(value) : reject(new Error('无法创建文件预览')), 'image/png')
      })
      return new File([blob], file.name, {
        type: 'image/png',
        lastModified: file.lastModified
      })
    }

    function dismissNativeDropOverlay() {
      if (typeof window.dispatchEvent !== 'function' || typeof Event !== 'function') return
      window.dispatchEvent(new Event('dragend'))
    }

    function installVisionSendBridge(ctx) {
      const conversation = ctx.get('conversation')
      if (!conversation) throw new Error('dsh-tool-vision: conversation service is unavailable')
      const documentDrafts = new Map()
      const original = conversation.sendSession
      const originalReleaseDraftImage = conversation.releaseDraftImage
      const originalReleaseDraftImages = conversation.releaseDraftImages

      const releaseDraftImage = function (id) {
        documentDrafts.delete(id)
        return originalReleaseDraftImage.call(this, id)
      }
      const releaseDraftImages = function (attachments) {
        for (const attachment of attachments) documentDrafts.delete(attachment.id)
        return originalReleaseDraftImages.call(this, attachments)
      }
      conversation.releaseDraftImage = releaseDraftImage
      conversation.releaseDraftImages = releaseDraftImages

      const onDrop = (event) => {
        const files = [...(event.dataTransfer?.files ?? [])]
        if (files.length === 0 || !files.some(isVisionDocumentFile)) return
        if (!files.every((file) => isVisionImageFile(file) || isVisionDocumentFile(file))) return

        const sessionId = ctx.sessions?.list?.getSnapshot?.().current
        if (!sessionId || !isVisionAssistSession(ctx, { sessionId })) return
        const scope = ctx.sessions.scope?.(sessionId)
        const input = scope ? conversation.input?.for?.(scope) : undefined
        if (!input) return

        event.preventDefault()
        event.stopImmediatePropagation()
        dismissNativeDropOverlay()
        void (async () => {
          const prepared = await Promise.all(files.map((file) => (
            isVisionDocumentFile(file) ? createDocumentPlaceholder(file) : file
          )))
          const attachments = conversation.createDraftImages(prepared)
          attachments.forEach((attachment, index) => {
            if (isVisionDocumentFile(files[index])) documentDrafts.set(attachment.id, files[index])
          })
          if (!input.addImages(attachments.map((attachment) => attachment.id))) {
            conversation.releaseDraftImages(attachments)
            input.notify('error', '当前无法添加附件')
            return
          }
          input.notify('info', `已添加 ${files.length} 个附件`)
        })().catch((error) => {
          input.notify('error', error instanceof Error ? error.message : String(error))
        })
      }
      document.addEventListener('drop', onDrop, true)

      const wrapped = async function (session, text, imageIds, mode) {
        if (imageIds.length === 0) {
          return original.call(this, session, text, imageIds, mode)
        }
        if (!isVisionAssistSession(ctx, session)) {
          return original.call(this, session, text, imageIds, mode)
        }

        let attachments
        try {
          attachments = conversation.draftImages(imageIds)
        } catch {
          return original.call(this, session, text, imageIds, mode)
        }
        if (attachments.length !== imageIds.length) {
          return original.call(this, session, text, imageIds, mode)
        }
        const uploads = attachments.map((attachment) => {
          const sourceFile = documentDrafts.get(attachment.id)
          if (sourceFile) return { kind: 'file', file: sourceFile }
          if (isVisionImageFile(attachment?.file)) return { kind: 'image', file: attachment.file }
          return null
        })
        if (uploads.some((upload) => upload === null)) {
          return original.call(this, session, text, imageIds, mode)
        }
        await Promise.all(uploads.map((upload) => upload.kind === 'file'
          ? uploadVisionFile(upload.file, session.sessionId)
          : uploadVisionImage(upload.file, session.sessionId)))
        const hasDocuments = uploads.some((upload) => upload.kind === 'file')
        const prompt = text.trim() === ''
          ? (hasDocuments ? '请处理这些附件。' : '请分析这些图片。')
          : text
        const result = await session.prompt([{ type: 'text', text: prompt }], mode)
        if (!result.ok) throw new Error(`conversation.send failed: ${result.error.code}: ${result.error.message}`)
        conversation.releaseDraftImages(attachments)
      }
      conversation.sendSession = wrapped
      return () => {
        document.removeEventListener('drop', onDrop, true)
        if (conversation.sendSession === wrapped) conversation.sendSession = original
        if (conversation.releaseDraftImage === releaseDraftImage) conversation.releaseDraftImage = originalReleaseDraftImage
        if (conversation.releaseDraftImages === releaseDraftImages) conversation.releaseDraftImages = originalReleaseDraftImages
        documentDrafts.clear()
      }
    }

    function VisionSection() {
      const [config, setConfig] = React.useState({
        apiStyle: 'openai_chat_completions',
        baseUrl: '',
        model: ''
      })
      const [apiKey, setApiKey] = React.useState('')
      const [credential, setCredential] = React.useState({ configured: false, writable: true })
      const [busy, setBusy] = React.useState('load')
      const [status, setStatus] = React.useState({ kind: 'idle', text: '正在加载…' })

      React.useEffect(() => {
        let active = true
        fetch('/dsh-vision/api/config')
          .then(readResponse)
          .then((body) => {
            if (!active) return
            setConfig(body.config)
            setCredential(body.credential)
            setStatus({ kind: 'idle', text: '配置已加载' })
          })
          .catch((error) => {
            if (active) setStatus({ kind: 'error', text: friendlyError(error.message) })
          })
          .finally(() => {
            if (active) setBusy(null)
          })
        return () => { active = false }
      }, [])

      const persist = async (clearApiKey = false) => {
        const payload = { ...config, clearApiKey }
        if (apiKey.length > 0) payload.apiKey = apiKey
        const response = await fetch('/dsh-vision/api/config', {
          method: 'POST',
          headers: {
            'content-type': 'application/json',
            'x-dsh-vision-settings': '1'
          },
          body: JSON.stringify(payload)
        })
        const body = await readResponse(response)
        setConfig(body.config)
        setCredential(body.credential)
        setApiKey('')
        return body
      }

      const save = async () => {
        setBusy('save')
        setStatus({ kind: 'idle', text: '正在保存…' })
        try {
          await persist()
          setStatus({ kind: 'success', text: '配置已保存' })
        } catch (error) {
          setStatus({ kind: 'error', text: friendlyError(error.message) })
        } finally {
          setBusy(null)
        }
      }

      const clearKey = async () => {
        if (!window.confirm('确定清除 Vision API Key？')) return
        setBusy('clear')
        try {
          await persist(true)
          setStatus({ kind: 'success', text: 'API Key 已清除' })
        } catch (error) {
          setStatus({ kind: 'error', text: friendlyError(error.message) })
        } finally {
          setBusy(null)
        }
      }

      const testConnection = async () => {
        setBusy('test')
        setStatus({ kind: 'idle', text: '正在请求 Vision 模型…' })
        try {
          await persist()
          const body = await readResponse(await fetch('/dsh-vision/api/test', {
            method: 'POST',
            headers: { 'x-dsh-vision-test': '1' }
          }))
          const protocol = body.apiStyle === 'gemini_generate_content' ? 'Gemini' : 'OpenAI 兼容'
          setStatus({
            kind: 'success',
            text: `连接成功 · ${body.model} · ${protocol} · ${body.latencyMs} ms`
          })
        } catch (error) {
          setStatus({ kind: 'error', text: `连接失败：${friendlyError(error.message)}` })
        } finally {
          setBusy(null)
        }
      }

      const disabled = busy !== null
      const setField = (field, value) => setConfig((current) => ({ ...current, [field]: value }))

      return jsxs('section', {
        className: 'dsv-section',
        children: [
          jsx('h2', { className: 'dsv-title', children: 'Vision' }),
          jsxs('div', {
            className: 'dsv-form',
            children: [
              jsxs('label', {
                className: 'dsv-field',
                children: [
                  jsx('span', { className: 'dsv-label', children: 'API 协议' }),
                  jsxs('select', {
                    className: 'dsv-input',
                    value: config.apiStyle,
                    disabled,
                    onChange: (event) => setField('apiStyle', event.target.value),
                    children: [
                      jsx('option', { value: 'openai_chat_completions', children: 'OpenAI Chat Completions' }),
                      jsx('option', { value: 'gemini_generate_content', children: 'Google Gemini' })
                    ]
                  })
                ]
              }),
              jsxs('label', {
                className: 'dsv-field',
                children: [
                  jsx('span', { className: 'dsv-label', children: 'API 地址' }),
                  jsx('input', {
                    className: 'dsv-input',
                    type: 'url',
                    value: config.baseUrl,
                    placeholder: '请输入 API 地址',
                    disabled,
                    onChange: (event) => setField('baseUrl', event.target.value)
                  })
                ]
              }),
              jsxs('label', {
                className: 'dsv-field',
                children: [
                  jsx('span', { className: 'dsv-label', children: '视觉模型' }),
                  jsx('input', {
                    className: 'dsv-input',
                    type: 'text',
                    value: config.model,
                    placeholder: '请输入视觉模型 ID',
                    disabled,
                    onChange: (event) => setField('model', event.target.value)
                  })
                ]
              }),
              jsxs('label', {
                className: 'dsv-field',
                children: [
                  jsxs('span', {
                    className: 'dsv-label dsv-key-label',
                    children: [
                      jsx('span', { children: 'API Key' }),
                      jsx('span', {
                        className: `dsv-key-state ${credential.configured ? 'dsv-key-set' : 'dsv-key-missing'}`,
                        children: credential.configured ? '已配置' : '未配置'
                      })
                    ]
                  }),
                  jsx('input', {
                    className: 'dsv-input',
                    type: 'password',
                    autoComplete: 'new-password',
                    value: apiKey,
                    placeholder: credential.configured ? '留空则保留现有 Key' : '请输入 API Key',
                    disabled: disabled || credential.writable === false,
                    onChange: (event) => setApiKey(event.target.value)
                  })
                ]
              })
            ]
          }),
          jsxs('div', {
            className: 'dsv-actions',
            children: [
              jsx('button', {
                type: 'button',
                className: 'dsv-button dsv-primary',
                disabled,
                onClick: save,
                children: busy === 'save' ? '保存中…' : '保存配置'
              }),
              jsx('button', {
                type: 'button',
                className: 'dsv-button dsv-secondary',
                disabled,
                onClick: testConnection,
                children: busy === 'test' ? '测试中…' : '测试连接'
              }),
              credential.configured && credential.writable !== false ? jsx('button', {
                type: 'button',
                className: 'dsv-button dsv-danger',
                disabled,
                onClick: clearKey,
                children: busy === 'clear' ? '清除中…' : '清除 Key'
              }) : null
            ]
          }),
          jsx('p', {
            className: `dsv-status dsv-status-${status.kind}`,
            role: 'status',
            'aria-live': 'polite',
            children: status.text
          })
        ]
      })
    }

    const inject = ['slots', 'conversation', 'sessions']
    function apply(ctx) {
      ctx.effect(() => installVisionSendBridge(ctx), 'dsh-tool-vision: image send bridge')
      ctx.slots.inject('settings.section', () => ctx.slots.register({
        name: 'settings.section',
        id: 'vision',
        order: 15,
        label: () => 'Vision'
      }, VisionSection))
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  }
})
