import { randomUUID } from 'node:crypto'
import { mkdir, writeFile } from 'node:fs/promises'
import { basename, extname, join } from 'node:path'
import { homedir } from 'node:os'

export const VISION_FILE_UPLOAD_PATH = '/dsh-vision/api/files'
export const MAX_FILE_UPLOAD_BYTES = 100 * 1024 * 1024
export const SUPPORTED_FILE_EXTENSIONS = Object.freeze(['.pdf', '.doc', '.docx', '.ppt', '.pptx'])

function sendJson(response, status, value, headers = {}) {
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    ...headers
  })
  response.end(JSON.stringify(value))
}

async function readBody(request, maxBytes) {
  const chunks = []
  let bytes = 0
  for await (const chunk of request) {
    bytes += chunk.length
    if (bytes > maxBytes) throw new Error(`文件超过 ${maxBytes} 字节`)
    chunks.push(chunk)
  }
  if (bytes === 0) throw new Error('文件内容为空')
  return Buffer.concat(chunks)
}

function safeSessionId(value) {
  const id = String(value ?? '').trim()
  return /^[a-zA-Z0-9_-]{1,128}$/.test(id) ? id : 'unscoped'
}

function safeFileName(value) {
  let decoded = String(value ?? '').trim()
  try {
    decoded = decodeURIComponent(decoded)
  } catch {}
  const name = basename(decoded.replaceAll('\\', '/'))
    .replace(/[\u0000-\u001f\u007f]/g, '_')
    .trim()
    .slice(-180)
  if (!name) throw new Error('文件名为空')
  const extension = extname(name).toLowerCase()
  if (!SUPPORTED_FILE_EXTENSIONS.includes(extension)) {
    throw new Error('仅支持 PDF、Word（DOC/DOCX）和 PowerPoint（PPT/PPTX）文件')
  }
  return { name, extension }
}

export function defaultFileUploadRoot() {
  const home = process.env.DSH_HOME?.trim() || join(homedir(), '.dsh')
  return join(home, 'cache', 'dsh-tool-vision', 'files')
}

export function createVisionFileUploadHandler(options = {}) {
  const root = options.root ?? defaultFileUploadRoot()
  const maxUploadBytes = options.maxUploadBytes ?? MAX_FILE_UPLOAD_BYTES
  const onStored = options.onStored ?? (() => {})

  return async function visionFileUploadHandler(request, response) {
    if (request.method !== 'POST') {
      sendJson(response, 405, { ok: false, error: '仅支持 POST 请求' }, { allow: 'POST' })
      return
    }
    if (request.headers['x-dsh-vision-file'] !== '1') {
      sendJson(response, 403, { ok: false, error: '无效的文件上传请求' })
      return
    }

    try {
      const { name, extension } = safeFileName(request.headers['x-dsh-file-name'])
      const input = await readBody(request, maxUploadBytes)
      const sessionId = safeSessionId(request.headers['x-dsh-session-id'])
      const sessionDir = join(root, sessionId)
      await mkdir(sessionDir, { recursive: true })
      const path = join(sessionDir, `${randomUUID()}${extension}`)
      await writeFile(path, input, { mode: 0o600 })
      const stored = {
        name,
        path,
        mimeType: String(request.headers['content-type'] ?? 'application/octet-stream').split(';', 1)[0],
        bytes: input.length
      }
      await onStored(sessionId, stored)
      sendJson(response, 200, { ok: true, file: stored })
    } catch (error) {
      sendJson(response, 400, {
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      })
    }
  }
}
