// Built-in task templates. A task owns its VLM system prompt, its user
// instructions and the JSON Schema it promises to return. The main model only
// supplies `instructions`; it never invents wire-level prompts or schemas.

const SCHEMA_HINT = 'The JSON Schema is authoritative. Do not add, omit or rename top-level fields.'

export const TASKS = {
  slide_review: {
    id: 'slide_review',
    label: 'Review one rendered slide for layout and visual quality',
    system:
      'You are a meticulous presentation QA reviewer. You look at rendered slides and report only observable layout, overlap, overflow, alignment, typography, contrast and caption problems. Use normalized bounding boxes: x, y, width, height are floats from 0 to 1 relative to the full image.',
    user:
      'Review the supplied slide image(s). Identify concrete visual defects. Distinguish real defects from intentional minimal design. For every issue give an evidence-based detail and an actionable suggested fix. If no issue is found, return an empty issues array. When more than one image is supplied, include image_index (0-based input order) on every issue and caption check.',
    jsonSchema: {
      type: 'object',
      additionalProperties: false,
      properties: {
        summary: { type: 'string', description: 'One-paragraph factual summary of the slide' },
        issues: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              bbox_xywh: { type: 'array', items: { type: 'number' }, minItems: 4, maxItems: 4 },
              image_index: { type: 'integer', minimum: 0, description: '0-based input image index; required for multi-image calls' },
              severity: { type: 'string', enum: ['high', 'medium', 'low'] },
              type: {
                type: 'string',
                enum: ['text_overflow', 'overlap', 'misalignment', 'spacing', 'color_contrast', 'font_inconsistency', 'caption_mismatch', 'image_quality', 'other']
              },
              detail: { type: 'string' },
              suggested_fix: { type: 'string' }
            },
            required: ['bbox_xywh', 'severity', 'type', 'detail', 'suggested_fix']
          }
        },
        caption_checks: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              caption_text: { type: 'string' },
              image_index: { type: 'integer', minimum: 0, description: '0-based input image index; required for multi-image calls' },
              figure_bbox_xywh: { type: 'array', items: { type: 'number' }, minItems: 4, maxItems: 4 },
              match: { type: 'boolean' },
              mismatch_detail: { type: ['string', 'null'] }
            },
            required: ['caption_text', 'match', 'mismatch_detail']
          }
        },
        style_consistency_score: { type: 'number', minimum: 0, maximum: 1 }
      },
      required: ['summary', 'issues', 'caption_checks', 'style_consistency_score']
    }
  },

  figure_semantics: {
    id: 'figure_semantics',
    label: 'Classify what a research figure or photo actually shows',
    system:
      'You are a wind-turbine blade inspection image analyst. You classify the visual evidence in an image and never guess from filenames. Every judgment must include observable evidence.',
    user:
      'Classify the supplied image(s). Consider subject, framing, background, overlays, masks, skeletons and annotations. If the view type is ambiguous, lower view_confidence below 0.6 and set needs_human to true.',
    jsonSchema: {
      type: 'object',
      additionalProperties: false,
      properties: {
        content_type: { type: 'string' },
        view_type: {
          type: 'string',
          enum: ['blade_wide_shot', 'blade_closeup', 'blade_mask', 'blade_skeleton', 'flattened_strip', 'dataset_grid', 'chart_or_diagram', 'uav_scene', 'other']
        },
        subject: { type: 'string' },
        scene_description: { type: 'string' },
        evidence: { type: 'string' },
        text_overlays: { type: 'array', items: { type: 'string' } },
        caption_suggestion: { type: 'string' },
        view_confidence: { type: 'number', minimum: 0, maximum: 1 },
        needs_human: { type: 'boolean' }
      },
      required: ['content_type', 'view_type', 'scene_description', 'evidence', 'view_confidence', 'needs_human']
    }
  },

  caption_grounding: {
    id: 'caption_grounding',
    label: 'Check whether a caption is grounded in the figure it labels',
    system:
      'You are a precise figure-caption auditor. You compare candidate captions with the image content and report whether each caption is supported by visible evidence.',
    user:
      'The caller will list one or more candidate captions in instructions. For each caption decide match or mismatch using only image content. Never infer from file names or external knowledge. If the caller did not provide candidate captions, return caption_match: null, matched_caption: null, correct_caption: null, and explain in evidence that no candidate caption was supplied; do not invent a caption from the image.',
    jsonSchema: {
      type: 'object',
      additionalProperties: false,
      properties: {
        caption_match: { type: ['boolean', 'null'] },
        matched_caption: { type: ['string', 'null'] },
        correct_caption: { type: ['string', 'null'] },
        evidence: { type: 'string' },
        confidence: { type: 'number', minimum: 0, maximum: 1 },
        mismatched_captions: { type: 'array', items: { type: 'string' } }
      },
      required: ['caption_match', 'correct_caption', 'evidence', 'confidence']
    }
  },

  flowchart_extract: {
    id: 'flowchart_extract',
    label: 'Extract nodes and edges from a flowchart image',
    maxOutputTokens: 4096,
    system:
      'You extract flowchart structure from images into a lossless node/edge representation. Nodes use normalized bounding boxes. Preserve node labels exactly, including abbreviations and punctuation.',
    user:
      'Extract the flowchart. Infer edge direction from arrows. Identify the entry and exit nodes when visible. If the image is not a flowchart, return empty nodes and edges and set is_flowchart to false.',
    jsonSchema: {
      type: 'object',
      additionalProperties: false,
      properties: {
        is_flowchart: { type: 'boolean' },
        nodes: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              id: { type: 'string' },
              label: { type: 'string' },
              shape: { type: 'string', enum: ['rect', 'rounded_rect', 'diamond', 'ellipse', 'other'] },
              bbox_xywh: { type: 'array', items: { type: 'number' }, minItems: 4, maxItems: 4 }
            },
            required: ['id', 'label', 'bbox_xywh']
          }
        },
        edges: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            properties: {
              from: { type: 'string' },
              to: { type: 'string' },
              label: { type: ['string', 'null'] }
            },
            required: ['from', 'to']
          }
        },
        entry: { type: ['string', 'null'] },
        exit: { type: ['string', 'null'] },
        branch_points: { type: 'array', items: { type: 'string' } }
      },
      required: ['is_flowchart', 'nodes', 'edges']
    }
  },

  custom: {
    id: 'custom',
    label: 'Ask a focused visual question and receive a structured JSON answer',
    maxOutputTokens: 1200,
    system:
      'You are a precise visual analysis assistant. You answer the caller question from image evidence only and always return a compact JSON object. Keep the whole response concise.',
    user:
      'Answer the caller question. Keep the result small and factual. Put the main answer in summary and include at most three short observations.',
    jsonSchema: {
      type: 'object',
      additionalProperties: true,
      properties: {
        summary: { type: 'string' },
        observations: { type: 'array', items: { type: 'string' }, maxItems: 3 },
        confidence: { type: 'number', minimum: 0, maximum: 1 }
      },
      required: ['summary', 'observations', 'confidence']
    }
  }
}

export const TASK_IDS = Object.freeze(Object.keys(TASKS))

export function getTask(taskId) {
  const task = TASKS[taskId]
  if (!task) throw new Error(`unknown vision task "${taskId}". Available: ${TASK_IDS.join(', ')}`)
  return task
}

export function buildVisionMessages(task, instructions, imageCount = 1) {
  const instructionText = String(instructions ?? '').trim()
  const contract = [
    SCHEMA_HINT,
    instructionText ? `CALLER INSTRUCTIONS:\n${instructionText}` : '',
    'HARD RULES:',
    '- Return exactly one JSON object.',
    '- No markdown fences, no commentary before or after the JSON.',
    '- If a judgment is uncertain, lower confidence and say so in evidence; never fabricate.',
    imageCount > 1
      ? `- This request contains ${imageCount} input images in order. For every issue or caption check, include image_index as a 0-based integer matching that order.`
      : '',
    `JSON SCHEMA:\n${JSON.stringify(task.jsonSchema)}`
  ].filter(Boolean).join('\n\n')
  return {
    system: task.system,
    user: contract
  }
}
