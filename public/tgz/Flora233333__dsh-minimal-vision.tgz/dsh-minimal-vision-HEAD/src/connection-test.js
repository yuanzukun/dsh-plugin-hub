import { readVisionConfig } from './config.js'
import { analyzeWithProvider } from './providers.js'

export const VISION_TEST_PATH = '/dsh-vision/api/test'
export const VISION_TEST_TIMEOUT_MS = 15000

function statusFor(error) {
  if (error?.code === 'VISION_PROVIDER_TIMEOUT') return 504
  if (Number.isInteger(error?.status) && error.status >= 400 && error.status < 500) return error.status
  if (/credential|baseURL|model is (?:empty|not configured)|unsupported Vision API protocol/i.test(error?.message ?? '')) return 400
  return 502
}

function sendJson(response, status, value, headers = {}) {
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    ...headers
  })
  response.end(JSON.stringify(value))
}

export async function testVisionConnection(options = {}) {
  const config = options.loadConfig
    ? await options.loadConfig()
    : await readVisionConfig({ dshHome: options.dshHome })
  const timeoutMs = options.timeoutMs ?? VISION_TEST_TIMEOUT_MS
  const startedAt = Date.now()

  await analyzeWithProvider({ ...config, timeoutMs }, {
    system: 'This is a connection test. Follow the user request exactly.',
    user: 'Reply with a short JSON object containing only {"ok":true}.',
    imageDataUrls: [],
    jsonSchema: { type: 'object', properties: { ok: { type: 'boolean' } } }
  }, options.signal)

  return {
    ok: true,
    model: config.model,
    apiStyle: config.apiStyle,
    latencyMs: Date.now() - startedAt
  }
}

export function createVisionTestHandler(options = {}) {
  return async function visionTestHandler(request, response) {
    if (request.method !== 'POST') {
      sendJson(response, 405, { ok: false, error: '仅支持 POST 请求' }, { allow: 'POST' })
      return
    }
    if (request.headers['x-dsh-vision-test'] !== '1') {
      sendJson(response, 403, { ok: false, error: '无效的测试请求' })
      return
    }

    try {
      sendJson(response, 200, await testVisionConnection(options))
    } catch (error) {
      sendJson(response, statusFor(error), {
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      })
    }
  }
}
