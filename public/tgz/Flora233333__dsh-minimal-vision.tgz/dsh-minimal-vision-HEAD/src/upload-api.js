import { randomUUID } from 'node:crypto'
import { mkdir, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { homedir } from 'node:os'
import { optimizeImageBuffer } from './image.js'

export const VISION_UPLOAD_PATH = '/dsh-vision/api/images'
export const MAX_UPLOAD_BYTES = 20 * 1024 * 1024

function sendJson(response, status, value, headers = {}) {
  response.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    ...headers
  })
  response.end(JSON.stringify(value))
}

async function readBody(request, maxBytes) {
  const chunks = []
  let bytes = 0
  for await (const chunk of request) {
    bytes += chunk.length
    if (bytes > maxBytes) throw new Error(`图片超过 ${maxBytes} 字节`)
    chunks.push(chunk)
  }
  if (bytes === 0) throw new Error('图片内容为空')
  return Buffer.concat(chunks)
}

function safeSessionId(value) {
  const id = String(value ?? '').trim()
  return /^[a-zA-Z0-9_-]{1,128}$/.test(id) ? id : 'unscoped'
}

export function defaultUploadRoot() {
  const home = process.env.DSH_HOME?.trim() || join(homedir(), '.dsh')
  return join(home, 'cache', 'dsh-tool-vision', 'images')
}

export function createVisionUploadHandler(options = {}) {
  const root = options.root ?? defaultUploadRoot()
  const maxUploadBytes = options.maxUploadBytes ?? MAX_UPLOAD_BYTES
  const onStored = options.onStored ?? (() => {})

  return async function visionUploadHandler(request, response) {
    if (request.method !== 'POST') {
      sendJson(response, 405, { ok: false, error: '仅支持 POST 请求' }, { allow: 'POST' })
      return
    }
    if (request.headers['x-dsh-vision-upload'] !== '1') {
      sendJson(response, 403, { ok: false, error: '无效的图片上传请求' })
      return
    }

    try {
      const declaredMime = String(request.headers['content-type'] ?? '').split(';', 1)[0].trim().toLowerCase()
      const input = await readBody(request, maxUploadBytes)
      const image = await optimizeImageBuffer(input, { declaredMime })
      const sessionId = safeSessionId(request.headers['x-dsh-session-id'])
      const sessionDir = join(root, sessionId)
      await mkdir(sessionDir, { recursive: true })
      const path = join(sessionDir, `${randomUUID()}.dsv.jpg`)
      await writeFile(path, image.bytes, { mode: 0o600 })
      const stored = {
        path,
        mimeType: image.mimeType,
        width: image.width,
        height: image.height,
        bytes: image.bytes.length,
        inputBytes: image.inputBytes
      }
      await onStored(sessionId, stored)
      sendJson(response, 200, {
        ok: true,
        image: stored
      })
    } catch (error) {
      sendJson(response, 400, {
        ok: false,
        error: error instanceof Error ? error.message : String(error)
      })
    }
  }
}
