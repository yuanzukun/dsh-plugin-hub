import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { takePendingVisionImages } from './pending-images.js'
import { takePendingVisionFiles } from './pending-files.js'
import { visionCommand } from './runtime-paths.js'

export const name = 'dsh-vision-injector'

export const VISION_USAGE = `<vision-assist>
You can inspect rendered images with the existing persistent-bash tool. No extra vision tool is registered.
Use this exact launcher command; do not reconstruct a profile, package, HOME, or node_modules path. One call accepts at most 4 images:
${visionCommand()} analyze --task <task> --instructions "<focused visual question>" -- <image paths...>
Tasks: custom, slide_review, figure_semantics, caption_grounding, flowchart_extract.
Task choice: custom is the required default for ordinary descriptions, explanations, comparisons, diagram summaries, and focused visual questions. Use slide_review only for slide layout QA, figure_semantics only for classifying a research figure/photo, caption_grounding only for caption verification, and flowchart_extract only when exact machine-readable nodes and edges are explicitly needed.
Make one dsh-vision call at a time. Do not chain fallback calls with || and do not repeat a failed call automatically; the CLI returns usable raw_text when a model response is not valid JSON.
dsh-vision accepts only PNG/JPEG/WebP/GIF and returns JSON on stdout. For PDF/DOC/DOCX/PPT/PPTX, use Bash to inspect, extract, or render the document first; document processing and editing remain your job. Pass only rendered images to dsh-vision, and invoke it only when visual evidence is needed.
</vision-assist>`

export function visionAttachmentText(images) {
  return [
    '<vision-attachments>',
    'The attached images were converted to local files before this prompt reached the text-only chat model:',
    ...images.map((image, index) => `${index + 1}. ${image.path} (${image.width}x${image.height}, ${image.bytes} bytes)`),
    'Use the injected dsh-vision Bash workflow when visual evidence is needed. These paths are images, not native chat attachments.',
    '</vision-attachments>'
  ].join('\n')
}

export function visionFileText(files) {
  return [
    '<vision-files>',
    'The following source files were saved locally before this prompt reached the agent:',
    ...files.map((file, index) => `${index + 1}. ${file.path} (${file.name}, ${file.mimeType}, ${file.bytes} bytes)`),
    'Inspect or convert these files with Bash. They are source documents, not direct dsh-vision inputs.',
    '</vision-files>'
  ].join('\n')
}

function attachmentSummary(images, files) {
  if (images.length > 0 && files.length === 0) return `已准备 ${images.length} 张图片供视觉分析`
  if (files.length > 0 && images.length === 0) return `已准备 ${files.length} 个文件供 Agent 处理`
  return `已准备 ${images.length} 张图片和 ${files.length} 个文件`
}

export function injectVisionContext(payload, decision, images = [], files = []) {
  if (decision.kind !== 'enter' || payload.step !== 1) return decision
  if (!decision.messages.some((message) => message.role === 'user' && (!message.source || message.source.kind === 'user'))) {
    return decision
  }
  const includeUsage = payload.turn === 1
  if (!includeUsage && images.length === 0 && files.length === 0) return decision

  const text = [
    images.length > 0 ? visionAttachmentText(images) : null,
    files.length > 0 ? visionFileText(files) : null,
    includeUsage ? VISION_USAGE : null
  ].filter(Boolean).join('\n\n')
  const message = createUserMessage({
    content: [{ type: 'text', text }],
    source: {
      kind: 'plugin',
      plugin: 'dsh-tool-vision',
      form: 'notice',
      summary: images.length > 0 || files.length > 0 ? attachmentSummary(images, files) : '视觉辅助说明'
    }
  })
  return {
    kind: 'enter',
    messages: [...decision.messages, message]
  }
}

export function apply(ctx) {
  ctx.on('agent/pre-step', async (payload, next) => {
    const decision = await next()
    if (decision.kind !== 'enter' || payload.step !== 1) return decision
    if (!decision.messages.some((message) => message.role === 'user' && (!message.source || message.source.kind === 'user'))) {
      return decision
    }
    return injectVisionContext(
      payload,
      decision,
      takePendingVisionImages(payload.agent.id),
      takePendingVisionFiles(payload.agent.id)
    )
  })
}
