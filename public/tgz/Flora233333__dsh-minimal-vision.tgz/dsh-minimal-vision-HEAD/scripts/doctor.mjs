#!/usr/bin/env node
import { access, readFile } from 'node:fs/promises'
import { constants } from 'node:fs'
import { join } from 'node:path'
import {
  dshHome,
  renderVisionLauncher,
  visionCliPath,
  visionLauncherPath
} from '../src/runtime-paths.js'

const home = dshHome()
const profile = process.env.DSH_PROFILE?.trim() || 'web'
const profileDir = join(home, 'profiles', profile)
const packageFile = join(profileDir, 'node_modules', 'dsh-tool-vision', 'package.json')
const presetFile = join(home, '.agent-presets', 'vision-assist', 'agent.cordis.yml')
const launcherFile = visionLauncherPath(home)
const cliFile = visionCliPath()
const problems = []

async function exists(path) {
  try {
    await access(path, constants.F_OK)
    return true
  } catch {
    return false
  }
}

if (!(await exists(packageFile))) problems.push('package is not installed in the selected profile')
try {
  await access(launcherFile, constants.X_OK)
  if (await readFile(launcherFile, 'utf8') !== renderVisionLauncher({ home })) {
    problems.push('stable launcher is stale; boot DSH once to refresh it')
  }
} catch {
  problems.push('stable launcher is missing or not executable; boot DSH once to create it')
}
try {
  await access(process.execPath, constants.X_OK)
} catch {
  problems.push(`Node runtime is not executable: ${process.execPath}`)
}
if (!(await exists(cliFile))) problems.push(`resolved CLI target is missing: ${cliFile}`)
if (!(await exists(presetFile))) {
  problems.push('vision-assist preset is not installed; boot DSH once after adding the plugin')
} else if (!(await readFile(presetFile, 'utf8')).includes('dsh-tool-vision/injector')) {
  problems.push('installed vision-assist preset is from the old tool-based version; boot DSH once to update it')
}

console.log(`dsh-vision doctor: profile=${profile}`)
if (problems.length === 0) {
  console.log('OK: bundle and vision-assist preset are present')
  console.log(`OK: stable launcher is executable (${launcherFile})`)
  console.log(`OK: Node runtime and CLI target are present (${process.execPath}, ${cliFile})`)
} else {
  for (const problem of problems) console.error(`ERROR: ${problem}`)
  process.exitCode = 1
}
