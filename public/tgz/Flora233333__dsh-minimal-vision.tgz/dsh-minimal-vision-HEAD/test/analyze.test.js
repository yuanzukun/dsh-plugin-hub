import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'
import { once } from 'node:events'
import { mkdtemp, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import sharp from 'sharp'
import { analyzeImages } from '../src/analyze.js'

test('invalid model JSON returns one raw fallback without a second vision request', async () => {
  let requests = 0
  const server = http.createServer(async (request, response) => {
    for await (const _chunk of request) {}
    requests += 1
    response.setHeader('content-type', 'application/json')
    response.end(JSON.stringify({ choices: [{ message: { content: 'plain visual answer' } }] }))
  })
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const dir = await mkdtemp(join(tmpdir(), 'dsh-vision-analyze-'))
  const image = join(dir, 'sample.png')
  await writeFile(image, await sharp({
    create: { width: 32, height: 24, channels: 3, background: '#ffffff' }
  }).png().toBuffer())

  try {
    const output = await analyzeImages({
      settings: {
        baseUrl: `http://127.0.0.1:${server.address().port}`,
        model: 'test-vl',
        apiStyle: 'openai_chat_completions'
      },
      task: 'custom',
      instructions: 'describe it',
      imagePaths: [image]
    })
    assert.equal(requests, 1)
    assert.equal(output.result._unparsed, true)
    assert.equal(output.result.raw_text, 'plain visual answer')
  } finally {
    server.close()
  }
})

test('caption_grounding accepts an explicit no-candidate result', async () => {
  const server = http.createServer(async (_request, response) => {
    for await (const _chunk of _request) {}
    response.setHeader('content-type', 'application/json')
    response.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify({
      caption_match: null,
      matched_caption: null,
      correct_caption: 'invented caption that must be discarded',
      evidence: 'No candidate caption was supplied.',
      confidence: 0,
      mismatched_captions: []
    }) } }] }))
  })
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const dir = await mkdtemp(join(tmpdir(), 'dsh-vision-caption-'))
  const image = join(dir, 'sample.png')
  await writeFile(image, await sharp({
    create: { width: 16, height: 16, channels: 3, background: '#ffffff' }
  }).png().toBuffer())

  try {
    const output = await analyzeImages({
      settings: {
        baseUrl: `http://127.0.0.1:${server.address().port}`,
        model: 'test-vl',
        apiStyle: 'openai_chat_completions'
      },
      task: 'caption_grounding',
      instructions: 'Check captions against figures',
      imagePaths: [image]
    })
    assert.equal(output.result.caption_match, null)
    assert.equal(output.result.matched_caption, null)
    assert.equal(output.result.correct_caption, null)
  } finally {
    server.close()
  }
})

test('multi-image requests include an image index contract in the prompt', async () => {
  let requestBody
  const server = http.createServer(async (request, response) => {
    let raw = ''
    for await (const chunk of request) raw += chunk
    requestBody = JSON.parse(raw)
    response.setHeader('content-type', 'application/json')
    response.end(JSON.stringify({ choices: [{ message: { content: JSON.stringify({ summary: 'ok', observations: [], confidence: 1 }) } }] }))
  })
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const dir = await mkdtemp(join(tmpdir(), 'dsh-vision-multi-'))
  const images = await Promise.all(['one.png', 'two.png'].map(async (name) => {
    const path = join(dir, name)
    await writeFile(path, await sharp({ create: { width: 16, height: 16, channels: 3, background: '#ffffff' } }).png().toBuffer())
    return path
  }))

  try {
    await analyzeImages({
      settings: { baseUrl: `http://127.0.0.1:${server.address().port}`, model: 'test-vl', apiStyle: 'openai_chat_completions' },
      task: 'custom',
      instructions: 'summarize both images',
      imagePaths: images
    })
    assert.match(requestBody.messages[1].content[0].text, /2 input images/)
    assert.match(requestBody.messages[1].content[0].text, /image_index/)
  } finally {
    server.close()
  }
})
