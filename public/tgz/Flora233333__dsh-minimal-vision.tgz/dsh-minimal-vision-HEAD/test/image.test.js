import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import sharp from 'sharp'
import { mimeFromPath, optimizeImageBuffer, resolveImageFile, sniffMime } from '../src/image.js'

async function png(width = 32, height = 24) {
  return sharp({
    create: {
      width,
      height,
      channels: 4,
      background: { r: 30, g: 120, b: 200, alpha: 0.5 }
    }
  }).png().toBuffer()
}

test('resolves and compresses a supported image into a JPEG data URL', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-vision-image-'))
  const path = join(dir, 'sample.png')
  const input = await png(3000, 1000)
  await writeFile(path, input)
  const image = await resolveImageFile(path)
  assert.equal(image.mimeType, 'image/jpeg')
  assert.equal(image.inputMimeType, 'image/png')
  assert.equal(image.inputBytes, input.length)
  assert.equal(image.width, 1600)
  assert.ok(image.height <= 1600)
  assert.ok(image.dataUrl.startsWith('data:image/jpeg;base64,'))
})

test('optimizer flattens transparency and honors a custom max edge', async () => {
  const image = await optimizeImageBuffer(await png(400, 800), { maxEdge: 256 })
  const metadata = await sharp(image.bytes).metadata()
  assert.equal(metadata.format, 'jpeg')
  assert.equal(metadata.width, 128)
  assert.equal(metadata.height, 256)
  assert.equal(metadata.hasAlpha, false)
})

test('reuses plugin-prepared JPEG bytes without a second lossy encode', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-vision-image-'))
  const prepared = await optimizeImageBuffer(await png(800, 400))
  const path = join(dir, 'prepared.dsv.jpg')
  await writeFile(path, prepared.bytes)
  const image = await resolveImageFile(path)
  const encoded = Buffer.from(image.dataUrl.slice(image.dataUrl.indexOf(',') + 1), 'base64')
  assert.deepEqual(encoded, prepared.bytes)
})

test('rejects unsupported extensions, oversized files, and magic mismatches', async () => {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-vision-image-'))
  const input = await png()
  const pngPath = join(dir, 'sample.png')
  const jpgPath = join(dir, 'sample.jpg')
  await writeFile(pngPath, input)
  await writeFile(jpgPath, input)
  await assert.rejects(resolveImageFile(join(dir, 'sample.bmp')), /unsupported image type/)
  await assert.rejects(resolveImageFile(pngPath, 2), /exceeds/)
  await assert.rejects(resolveImageFile(jpgPath), /bytes do not match/)
})

test('mime mapping and sniffing are case-insensitive and aligned', async () => {
  const input = await png()
  assert.equal(mimeFromPath('A.PNG'), 'image/png')
  assert.equal(mimeFromPath('b.webp'), 'image/webp')
  assert.equal(sniffMime(input), 'image/png')
})
