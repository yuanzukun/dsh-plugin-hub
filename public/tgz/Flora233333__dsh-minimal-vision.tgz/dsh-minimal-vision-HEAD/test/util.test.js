import test from 'node:test'
import assert from 'node:assert/strict'
import { parseJsonObject } from '../src/util.js'

test('parseJsonObject accepts prose, markdown fences, and trailing text', () => {
  assert.deepEqual(parseJsonObject('before\n```json\n{"ok":true}\n```\nafter'), { ok: true })
})

test('parseJsonObject returns the first valid object when outputs are concatenated', () => {
  assert.deepEqual(parseJsonObject('{"ok":true}{"other":false}'), { ok: true })
})

test('parseJsonObject ignores braces inside JSON strings', () => {
  assert.deepEqual(parseJsonObject('answer: {"text":"literal { brace } and \\\"quote\\\""}'), {
    text: 'literal { brace } and "quote"'
  })
})

test('parseJsonObject reports truncated JSON', () => {
  assert.throws(() => parseJsonObject('{"ok":true'), /No JSON object found|Invalid JSON object/)
})
