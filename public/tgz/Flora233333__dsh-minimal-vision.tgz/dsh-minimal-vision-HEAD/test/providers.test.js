import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'
import { once } from 'node:events'
import { analyzeWithOpenAiCompatible, analyzeWithGemini, normalizeSettings } from '../src/providers.js'

async function listen(handler) {
  const server = http.createServer(handler)
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  return server
}

test('openai-compatible posts to /v1/chat/completions with image data URLs', async () => {
  let seen
  const server = await listen(async (req, res) => {
    let body = ''
    for await (const chunk of req) body += chunk
    seen = JSON.parse(body)
    res.setHeader('content-type', 'application/json')
    res.end(JSON.stringify({ choices: [{ message: { content: '{"ok":true}' } }] }))
  })
  try {
    const out = await analyzeWithOpenAiCompatible({
      baseUrl: `http://127.0.0.1:${server.address().port}/`,
      model: 'test-vl',
      apiKey: 'secret',
      system: 'sys',
      user: 'user',
      imageDataUrls: ['data:image/png;base64,AAAA'],
      maxOutputTokens: 800,
      timeoutMs: 5000,
      signal: AbortSignal.timeout(5000)
    })
    assert.deepEqual(out.apiStyle, 'openai_chat_completions')
    assert.equal(out.text, '{"ok":true}')
    assert.equal(seen.messages[0].role, 'system')
    assert.equal(seen.messages[1].content[0].type, 'text')
    assert.equal(seen.messages[1].content[1].image_url.url, 'data:image/png;base64,AAAA')
    assert.equal(seen.response_format.type, 'json_object')
    assert.equal(seen.max_tokens, 800)
  } finally {
    server.close()
  }
})

test('openai-compatible retries once without response_format on 400', async () => {
  let attempts = 0
  const server = await listen(async (req, res) => {
    let body = ''
    for await (const chunk of req) body += chunk
    attempts += 1
    if (attempts === 1) {
      assert.ok(JSON.parse(body).response_format)
      res.statusCode = 400
      res.setHeader('content-type', 'application/json')
      res.end(JSON.stringify({ error: { message: 'response_format unsupported' } }))
      return
    }
    assert.equal(JSON.parse(body).response_format, undefined)
    res.setHeader('content-type', 'application/json')
    res.end(JSON.stringify({ choices: [{ message: { content: '{"ok":true}' } }] }))
  })
  try {
    const out = await analyzeWithOpenAiCompatible({
      baseUrl: `http://127.0.0.1:${server.address().port}`,
      model: 'test-vl',
      apiKey: '',
      system: 'sys',
      user: 'user',
      imageDataUrls: [],
      timeoutMs: 5000,
      signal: AbortSignal.timeout(5000)
    })
    assert.equal(out.text, '{"ok":true}')
    assert.equal(attempts, 2)
  } finally {
    server.close()
  }
})

test('openai-compatible parses successful response envelopes larger than 16 KB', async () => {
  const server = await listen(async (_req, res) => {
    for await (const _chunk of _req) {}
    res.setHeader('content-type', 'application/json')
    res.end(JSON.stringify({
      choices: [{ message: { reasoning_content: 'x'.repeat(20000), content: '{"ok":true}' } }]
    }))
  })
  try {
    const out = await analyzeWithOpenAiCompatible({
      baseUrl: `http://127.0.0.1:${server.address().port}`,
      model: 'test-vl',
      system: 'sys',
      user: 'user',
      imageDataUrls: [],
      timeoutMs: 5000
    })
    assert.equal(out.text, '{"ok":true}')
  } finally {
    server.close()
  }
})

test('openai-compatible exposes reasoning as raw fallback when final content is empty', async () => {
  const server = await listen(async (_req, res) => {
    for await (const _chunk of _req) {}
    res.setHeader('content-type', 'application/json')
    res.end(JSON.stringify({
      choices: [{ message: { reasoning_content: 'Observed a likely overlap.', content: '' } }]
    }))
  })
  try {
    const out = await analyzeWithOpenAiCompatible({
      baseUrl: `http://127.0.0.1:${server.address().port}`,
      model: 'test-vl',
      system: 'sys',
      user: 'user',
      imageDataUrls: [],
      timeoutMs: 5000
    })
    assert.equal(out.text, 'Observed a likely overlap.')
  } finally {
    server.close()
  }
})

test('openai-compatible surfaces bounded HTTP errors and does not retry auth failures', async () => {
  let attempts = 0
  const server = await listen(async (_req, res) => {
    attempts += 1
    res.statusCode = 401
    res.setHeader('content-type', 'application/json')
    res.end(JSON.stringify({ error: { message: 'bad key' } }))
  })
  try {
    await assert.rejects(
      analyzeWithOpenAiCompatible({
        baseUrl: `http://127.0.0.1:${server.address().port}`,
        model: 'test-vl',
        apiKey: 'bad',
        system: 'sys',
        user: 'user',
        imageDataUrls: [],
        timeoutMs: 5000,
        signal: AbortSignal.timeout(5000)
      }),
      (error) => error.status === 401 && error.message.includes('bad key')
    )
    assert.equal(attempts, 1)
  } finally {
    server.close()
  }
})

test('provider requests reject redirects without contacting the redirect target', async () => {
  let leaked = false
  const target = await listen(async (_req, res) => {
    leaked = true
    res.end('{}')
  })
  const redirect = await listen(async (_req, res) => {
    res.statusCode = 302
    res.setHeader('location', `http://127.0.0.1:${target.address().port}/leak`)
    res.end()
  })
  try {
    await assert.rejects(analyzeWithOpenAiCompatible({
      baseUrl: `http://127.0.0.1:${redirect.address().port}`,
      model: 'test-vl',
      apiKey: 'secret',
      system: 'sys',
      user: 'user',
      imageDataUrls: [],
      timeoutMs: 5000,
      signal: AbortSignal.timeout(5000)
    }))
    assert.equal(leaked, false)
  } finally {
    redirect.close()
    target.close()
  }
})

test('gemini provider posts inline_data and parses candidate parts', async () => {
  let seen
  let requestUrl
  let requestHeaders
  const server = await listen(async (req, res) => {
    requestUrl = req.url
    requestHeaders = req.headers
    let body = ''
    for await (const chunk of req) body += chunk
    seen = JSON.parse(body)
    res.setHeader('content-type', 'application/json')
    res.end(JSON.stringify({ candidates: [{ content: { parts: [{ text: '{"ok":true}' }] } }] }))
  })
  try {
    const out = await analyzeWithGemini({
      baseUrl: `http://127.0.0.1:${server.address().port}`,
      model: 'gemini-vl',
      apiKey: 'key',
      system: 'sys',
      user: 'user',
      imageDataUrls: ['data:image/jpeg;base64,BBBB'],
      maxOutputTokens: 700,
      timeoutMs: 5000,
      signal: AbortSignal.timeout(5000)
    })
    assert.equal(out.text, '{"ok":true}')
    assert.equal(requestUrl.includes('key='), false)
    assert.equal(requestHeaders['x-goog-api-key'], 'key')
    assert.equal(seen.contents[0].parts[0].text.includes('sys'), true)
    assert.deepEqual(seen.contents[0].parts[1].inline_data, { mime_type: 'image/jpeg', data: 'BBBB' })
    assert.equal(seen.generationConfig.responseMimeType, 'application/json')
    assert.equal(seen.generationConfig.maxOutputTokens, 700)
  } finally {
    server.close()
  }
})

test('normalizeSettings rejects empty baseUrl or model', () => {
  assert.throws(() => normalizeSettings({ baseUrl: '', model: 'm' }), /baseUrl/)
  assert.throws(() => normalizeSettings({ baseUrl: 'http://x', model: ' ' }), /model/)
})
