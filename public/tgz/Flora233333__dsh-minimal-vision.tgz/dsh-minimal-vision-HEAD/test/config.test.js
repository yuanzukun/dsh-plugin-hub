import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { readVisionConfig } from '../src/config.js'

test('reads the plugin-owned Vision settings and managed credential', async () => {
  const home = await mkdtemp(join(tmpdir(), 'dsh-vision-config-'))
  await writeFile(join(home, 'settings.yaml'), `dsh-tool-vision:\n  apiStyle: openai_chat_completions\n  baseUrl: http://127.0.0.1:9911/v1\n  model: test-vl\n`)
  await writeFile(join(home, '.credentials.yaml'), 'VISION_API_KEY: managed-key\n')

  const managed = await readVisionConfig({ dshHome: home })
  assert.equal(managed.apiKey, 'managed-key')
  assert.equal(managed.baseUrl, 'http://127.0.0.1:9911/v1')
  assert.equal(managed.model, 'test-vl')

  const previous = process.env.VISION_API_KEY
  process.env.VISION_API_KEY = 'environment-key'
  try {
    assert.equal((await readVisionConfig({ dshHome: home })).apiKey, 'environment-key')
  } finally {
    if (previous === undefined) delete process.env.VISION_API_KEY
    else process.env.VISION_API_KEY = previous
  }
})

test('rejects an unconfigured plugin instead of using a packaged endpoint', async () => {
  const home = await mkdtemp(join(tmpdir(), 'dsh-vision-config-'))
  const previous = process.env.VISION_API_KEY
  process.env.VISION_API_KEY = 'test-key'
  try {
    await assert.rejects(readVisionConfig({ dshHome: home }), /baseURL is not configured/)
  } finally {
    if (previous === undefined) delete process.env.VISION_API_KEY
    else process.env.VISION_API_KEY = previous
  }
})

test('rejects non-HTTP(S) Vision endpoints from existing settings', async () => {
  for (const baseUrl of ['file:///tmp/secret', 'gopher://127.0.0.1:70']) {
    const home = await mkdtemp(join(tmpdir(), 'dsh-vision-config-'))
    await writeFile(join(home, 'settings.yaml'), `dsh-tool-vision:\n  baseUrl: ${baseUrl}\n  model: test-vl\n`)
    await assert.rejects(readVisionConfig({ dshHome: home }), /http:\/\/ or https:\/\//)
  }
})

test('reads a complete legacy Vision route for one-time migration compatibility', async () => {
  const home = await mkdtemp(join(tmpdir(), 'dsh-vision-config-'))
  await writeFile(join(home, 'settings.yaml'), `llm-pi-ai:\n  providers:\n    vision:\n      api: google-generative-ai\n      baseURL: http://127.0.0.1:9912\n      models:\n        - id: legacy-vl\n`)
  await writeFile(join(home, '.credentials.yaml'), 'VISION_API_KEY: managed-key\n')

  const config = await readVisionConfig({ dshHome: home })
  assert.equal(config.model, 'legacy-vl')
  assert.equal(config.apiStyle, 'gemini_generate_content')
})
