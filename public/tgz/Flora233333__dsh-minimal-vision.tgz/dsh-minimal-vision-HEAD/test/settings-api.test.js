import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'
import { once } from 'node:events'
import { createVisionConfigHandler } from '../src/settings-api.js'

async function listen(handler) {
  const server = http.createServer(handler)
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  return server
}

function fixture() {
  let config = { baseUrl: '', model: '', apiStyle: 'openai_chat_completions' }
  let key = ''
  return {
    settingsScope: {
      get: () => config,
      replace: async (next) => { config = next }
    },
    credentials: {
      describe: async () => ({ configured: key.length > 0, writable: true }),
      set: async (_ref, value) => { key = value },
      unset: async () => { key = '' }
    },
    key: () => key
  }
}

test('Vision config API stores plugin settings and keeps the key write-only', async () => {
  const state = fixture()
  const server = await listen(createVisionConfigHandler(state))
  const url = `http://127.0.0.1:${server.address().port}`
  try {
    const saved = await fetch(url, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-dsh-vision-settings': '1'
      },
      body: JSON.stringify({
        baseUrl: 'https://vision.example/v1',
        model: 'vision-vl',
        apiStyle: 'openai_chat_completions',
        apiKey: 'secret-key'
      })
    })
    const savedBody = await saved.json()
    assert.equal(saved.status, 200)
    assert.equal(savedBody.config.model, 'vision-vl')
    assert.equal(savedBody.credential.configured, true)
    assert.equal(JSON.stringify(savedBody).includes('secret-key'), false)
    assert.equal(state.key(), 'secret-key')

    const loadedBody = await (await fetch(url)).json()
    assert.equal(loadedBody.config.baseUrl, 'https://vision.example/v1')
    assert.equal(JSON.stringify(loadedBody).includes('secret-key'), false)
  } finally {
    server.close()
  }
})

test('Vision config API can clear its managed credential', async () => {
  const state = fixture()
  await state.credentials.set('VISION_API_KEY', 'secret-key')
  const server = await listen(createVisionConfigHandler(state))
  try {
    const response = await fetch(`http://127.0.0.1:${server.address().port}`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-dsh-vision-settings': '1'
      },
      body: JSON.stringify({
        baseUrl: 'http://127.0.0.1:11434/v1',
        model: 'local-vl',
        apiStyle: 'openai_chat_completions',
        clearApiKey: true
      })
    })
    assert.equal(response.status, 200)
    assert.equal(state.key(), '')
  } finally {
    server.close()
  }
})

test('Vision config API rejects non-HTTP(S) endpoint schemes', async () => {
  const state = fixture()
  const server = await listen(createVisionConfigHandler(state))
  try {
    for (const baseUrl of ['file:///tmp/secret', 'gopher://127.0.0.1:70']) {
      const response = await fetch(`http://127.0.0.1:${server.address().port}`, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          'x-dsh-vision-settings': '1'
        },
        body: JSON.stringify({
          baseUrl,
          model: 'vision-vl',
          apiStyle: 'openai_chat_completions'
        })
      })
      const body = await response.json()
      assert.equal(response.status, 400)
      assert.match(body.error, /http:\/\/ or https:\/\//)
    }
  } finally {
    server.close()
  }
})
