import test from 'node:test'
import assert from 'node:assert/strict'
import { mkdtemp, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import yaml from 'js-yaml'
import { apply as installPreset } from '../src/index.js'
import { injectVisionContext, VISION_USAGE } from '../src/injector.js'

test('bundle installs the plugin without registering a Vision chat provider', async () => {
  const manifest = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'))
  const patchText = await readFile(new URL('../cordis.patch.yml', import.meta.url), 'utf8')
  const patch = yaml.load(patchText)
  assert.equal(manifest.dsh.bundle.patch, './cordis.patch.yml')
  assert.equal(manifest.exports['./client'], './src/client.js')
  assert.deepEqual(manifest.dsh.client.inject, [
    '@deepseek-ai/dsh-client-runtime',
    '@deepseek-ai/dsh-client-ui-conversation',
    '@deepseek-ai/dsh-client-ui-settings'
  ])
  assert.equal(manifest.dependencies.sharp.startsWith('^0.35.'), true)
  assert.equal(manifest.bin['dsh-vision'], 'src/cli.js')
  assert.equal(manifest.bin['dsh-vision-doctor'], 'scripts/doctor.mjs')
  assert.equal(patch.length, 1)
  assert.equal(patch[0].insert[0].name, 'dsh-tool-vision')
  assert.ok(!patchText.includes('llm-pi-ai'))
  assert.ok(!patchText.includes('poke2api'))
})

test('client bundle owns Vision configuration and connection testing', async () => {
  const client = await readFile(new URL('../src/client.js', import.meta.url), 'utf8')
  assert.ok(client.includes("id: 'vision'"))
  assert.ok(client.includes("'测试连接'"))
  assert.ok(client.includes("fetch('/dsh-vision/api/config'"))
  assert.ok(client.includes("fetch('/dsh-vision/api/test'"))
  assert.ok(client.includes("fetch('/dsh-vision/api/images'"))
  assert.ok(client.includes("fetch('/dsh-vision/api/files'"))
  assert.ok(client.includes("const VISION_PRESET = 'vision-assist'"))
  assert.ok(client.includes('function isVisionAssistSession(ctx, session)'))
  assert.ok(client.includes('function isVisionImageFile(file)'))
  assert.ok(client.includes('function isVisionDocumentFile(file)'))
  assert.ok(client.includes('function createDocumentPlaceholder(file)'))
  assert.ok(client.includes('VISION_IMAGE_NAME'))
  assert.ok(!client.includes('api.agentPresets.select({'))
  assert.ok(!client.includes('agent-preset/selected'))
  assert.ok(client.includes('if (!isVisionAssistSession(ctx, session))'))
  assert.ok(client.includes("document.addEventListener('drop', onDrop, true)"))
  assert.ok(client.includes("hasDocuments ? '请处理这些附件。' : '请分析这些图片。'"))
  assert.ok(client.includes("session.prompt([{ type: 'text', text: prompt }]"))
  assert.ok(client.includes("children: '视觉模型'"))
  assert.ok(client.includes('未配置 API Key'))
})

test('vision instructions and image paths are one separate hidden context message', () => {
  const user = { id: 'user-1', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'hello' }] }
  const initial = { kind: 'enter', messages: [user] }
  const images = [{ path: '/tmp/image.jpg', width: 800, height: 600, bytes: 1234 }]
  const first = injectVisionContext({ turn: 1, step: 1 }, initial, images)
  assert.equal(first.messages.length, 2)
  assert.equal(first.messages[0], user)
  assert.equal(first.messages[0].content[0].text, 'hello')
  assert.equal(first.messages[1].role, 'user')
  assert.equal(first.messages[1].source.kind, 'plugin')
  assert.equal(first.messages[1].source.form, 'notice')
  assert.equal(first.messages[1].source.summary, '已准备 1 张图片供视觉分析')
  assert.ok(first.messages[1].content[0].text.includes('/tmp/image.jpg'))
  assert.ok(first.messages[1].content[0].text.includes(VISION_USAGE))
  assert.ok(VISION_USAGE.includes('custom is the required default'))
  assert.ok(VISION_USAGE.includes('Do not chain fallback calls with ||'))
  assert.ok(VISION_USAGE.includes('/bin/dsh-vision'))
  assert.ok(!VISION_USAGE.includes('profiles/web'))
  assert.ok(!VISION_USAGE.includes('node_modules/.bin'))
  assert.equal(injectVisionContext({ turn: 1, step: 2 }, initial, images), initial)
  assert.equal(injectVisionContext({ turn: 2, step: 1 }, initial), initial)
  assert.equal(injectVisionContext({ turn: 1, step: 1 }, { kind: 'reject' }, images).kind, 'reject')
  assert.equal(injectVisionContext({ turn: 1, step: 1 }, {
    kind: 'enter',
    messages: [{ role: 'user', source: { kind: 'plugin', plugin: 'other' }, content: [{ type: 'text', text: 'context' }] }]
  }, images).messages.length, 1)
})

test('later-turn image paths remain hidden context without repeating usage', () => {
  const initial = { kind: 'enter', messages: [{ id: 'user-2', role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'again' }] }] }
  const result = injectVisionContext({ turn: 2, step: 1 }, initial, [
    { path: '/tmp/later.jpg', width: 400, height: 300, bytes: 500 }
  ])
  assert.equal(result.messages.length, 2)
  assert.ok(result.messages[1].content[0].text.includes('/tmp/later.jpg'))
  assert.ok(!result.messages[1].content[0].text.includes(VISION_USAGE))
})

test('document paths are injected as hidden context without treating documents as vision inputs', () => {
  const initial = { kind: 'enter', messages: [{ role: 'user', source: { kind: 'user' }, content: [{ type: 'text', text: 'review this' }] }] }
  const result = injectVisionContext({ turn: 1, step: 1 }, initial, [], [
    { name: 'report.pdf', path: '/tmp/report.pdf', mimeType: 'application/pdf', bytes: 1024 }
  ])
  assert.equal(result.messages.length, 2)
  assert.equal(result.messages[1].source.summary, '已准备 1 个文件供 Agent 处理')
  assert.ok(result.messages[1].content[0].text.includes('/tmp/report.pdf'))
  assert.ok(result.messages[1].content[0].text.includes('not direct dsh-vision inputs'))
})

test('preset preserves the minimal two-tool surface and adds only the injector', async () => {
  const preset = await readFile(new URL('../presets/vision-assist/agent.cordis.yml', import.meta.url), 'utf8')
  assert.ok(preset.includes('text: You are a helpful software engineer assistant.'))
  assert.ok(preset.includes("name: '@deepseek-ai/dsh-tool-bash-persistent'"))
  assert.ok(preset.includes("name: '@deepseek-ai/dsh-tool-str-replace-editor'"))
  assert.ok(preset.includes('name: dsh-tool-vision/injector'))
  assert.ok(!preset.includes('vision_analyze'))
})

test('bundle plugin installs the packaged preset under DSH_HOME', async () => {
  const home = await mkdtemp(join(tmpdir(), 'dsh-vision-home-'))
  const previous = process.env.DSH_HOME
  process.env.DSH_HOME = home
  try {
    installPreset()
    const installed = await readFile(join(home, '.agent-presets', 'vision-assist', 'agent.cordis.yml'), 'utf8')
    assert.ok(installed.includes('dsh-tool-vision/injector'))
  } finally {
    if (previous === undefined) delete process.env.DSH_HOME
    else process.env.DSH_HOME = previous
  }
})
