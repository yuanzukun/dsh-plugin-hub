import test from 'node:test'
import assert from 'node:assert/strict'
import { access, mkdtemp, readFile } from 'node:fs/promises'
import { constants } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import {
  installVisionLauncher,
  renderVisionLauncher,
  shellQuote,
  visionCommand,
  visionLauncherPath
} from '../src/runtime-paths.js'

test('stable launcher pins DSH_HOME, Node, and the real packaged CLI', async () => {
  const home = await mkdtemp(join(tmpdir(), 'dsh-vision-launcher-'))
  const launcher = installVisionLauncher(home)
  assert.equal(launcher, visionLauncherPath(home))
  assert.equal(await readFile(launcher, 'utf8'), renderVisionLauncher({ home }))
  await access(launcher, constants.X_OK)
  assert.ok(visionCommand(home).startsWith(`DSH_HOME=${shellQuote(home)} `))
  assert.ok(!visionCommand(home).includes('profiles/web'))
  assert.ok(!visionCommand(home).includes('node_modules/.bin'))
})

test('shell quoting preserves spaces and apostrophes', () => {
  assert.equal(shellQuote('/tmp/a b'), "'/tmp/a b'")
  assert.equal(shellQuote("/tmp/a'b"), "'/tmp/a'\"'\"'b'")
})
