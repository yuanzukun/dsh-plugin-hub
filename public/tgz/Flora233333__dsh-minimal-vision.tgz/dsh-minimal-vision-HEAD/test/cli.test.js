import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'
import { once } from 'node:events'
import { spawn } from 'node:child_process'
import { mkdtemp, writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import sharp from 'sharp'

test('CLI reads DSH settings, calls an OpenAI-compatible VLM, and prints JSON', async () => {
  let requestBody
  const server = http.createServer(async (request, response) => {
    let raw = ''
    for await (const chunk of request) raw += chunk
    requestBody = JSON.parse(raw)
    response.setHeader('content-type', 'application/json')
    response.end(JSON.stringify({
      choices: [{ message: { content: JSON.stringify({ summary: 'visible', observations: ['one'], confidence: 1 }) } }]
    }))
  })
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')

  const home = await mkdtemp(join(tmpdir(), 'dsh-vision-cli-'))
  const image = join(home, 'sample.png')
  await writeFile(image, await sharp({
    create: { width: 32, height: 24, channels: 3, background: '#1677ff' }
  }).png().toBuffer())
  await writeFile(join(home, 'settings.yaml'), `dsh-tool-vision:\n  apiStyle: openai_chat_completions\n  baseUrl: http://127.0.0.1:${server.address().port}/v1\n  model: fake-vl\n`)
  await writeFile(join(home, '.credentials.yaml'), 'VISION_API_KEY: fake-key\n')

  try {
    const child = spawn(process.execPath, [
      fileURLToPath(new URL('../src/cli.js', import.meta.url)),
      'analyze', '--task', 'custom', '--instructions', 'what is visible?', '--', image
    ], { env: { ...process.env, DSH_HOME: home } })
    let stdout = ''
    let stderr = ''
    child.stdout.on('data', (chunk) => { stdout += chunk })
    child.stderr.on('data', (chunk) => { stderr += chunk })
    const [code] = await once(child, 'close')
    assert.equal(code, 0, stderr)
    const output = JSON.parse(stdout)
    assert.equal(output.model, 'fake-vl')
    assert.equal(output.result.summary, 'visible')
    assert.equal(requestBody.model, 'fake-vl')
    assert.equal(requestBody.messages[1].content[1].type, 'image_url')
    assert.ok(requestBody.messages[1].content[1].image_url.url.startsWith('data:image/jpeg;base64,'))
  } finally {
    server.close()
  }
})
