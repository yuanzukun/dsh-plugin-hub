import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'
import { once } from 'node:events'
import { mkdtemp, readFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import sharp from 'sharp'
import { createVisionUploadHandler } from '../src/upload-api.js'
import { createVisionFileUploadHandler } from '../src/file-upload-api.js'

test('upload API stores a compressed session-scoped JPEG', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-vision-upload-'))
  let recorded
  const server = http.createServer(createVisionUploadHandler({
    root,
    onStored: (sessionId, image) => { recorded = { sessionId, image } }
  }))
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const input = await sharp({
    create: { width: 3200, height: 1600, channels: 4, background: { r: 255, g: 0, b: 0, alpha: 0.4 } }
  }).png().toBuffer()

  try {
    const response = await fetch(`http://127.0.0.1:${server.address().port}`, {
      method: 'POST',
      headers: {
        'content-type': 'image/png',
        'x-dsh-vision-upload': '1',
        'x-dsh-session-id': 'session-test'
      },
      body: input
    })
    const body = await response.json()
    assert.equal(response.status, 200)
    assert.equal(body.ok, true)
    assert.equal(body.image.width, 1600)
    assert.equal(body.image.height, 800)
    assert.ok(body.image.path.startsWith(join(root, 'session-test')))
    assert.ok(body.image.path.endsWith('.dsv.jpg'))
    assert.equal(recorded.sessionId, 'session-test')
    assert.equal(recorded.image.path, body.image.path)
    const stored = await readFile(body.image.path)
    const metadata = await sharp(stored).metadata()
    assert.equal(metadata.format, 'jpeg')
    assert.equal(metadata.hasAlpha, false)
  } finally {
    server.close()
  }
})

test('upload API rejects invalid image bytes and missing request marker', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-vision-upload-'))
  const server = http.createServer(createVisionUploadHandler({ root }))
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const url = `http://127.0.0.1:${server.address().port}`
  try {
    const forbidden = await fetch(url, { method: 'POST', body: Buffer.from('x') })
    assert.equal(forbidden.status, 403)
    const invalid = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'image/png', 'x-dsh-vision-upload': '1' },
      body: Buffer.from('not an image')
    })
    assert.equal(invalid.status, 400)
  } finally {
    server.close()
  }
})

test('file upload API stores supported documents without parsing them', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-vision-files-'))
  let recorded
  const server = http.createServer(createVisionFileUploadHandler({
    root,
    onStored: (sessionId, file) => { recorded = { sessionId, file } }
  }))
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const input = Buffer.from('%PDF-raw-test')
  try {
    const response = await fetch(`http://127.0.0.1:${server.address().port}`, {
      method: 'POST',
      headers: {
        'content-type': 'application/pdf',
        'x-dsh-vision-file': '1',
        'x-dsh-session-id': 'session-test',
        'x-dsh-file-name': encodeURIComponent('../report.pdf')
      },
      body: input
    })
    const body = await response.json()
    assert.equal(response.status, 200)
    assert.equal(body.ok, true)
    assert.equal(body.file.name, 'report.pdf')
    assert.equal(body.file.mimeType, 'application/pdf')
    assert.equal(recorded.sessionId, 'session-test')
    assert.deepEqual(await readFile(body.file.path), input)
  } finally {
    server.close()
  }
})

test('file upload API rejects unsupported extensions and missing request marker', async () => {
  const root = await mkdtemp(join(tmpdir(), 'dsh-vision-files-'))
  const server = http.createServer(createVisionFileUploadHandler({ root }))
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  const url = `http://127.0.0.1:${server.address().port}`
  try {
    const forbidden = await fetch(url, { method: 'POST', body: Buffer.from('x') })
    assert.equal(forbidden.status, 403)
    const unsupported = await fetch(url, {
      method: 'POST',
      headers: { 'x-dsh-vision-file': '1', 'x-dsh-file-name': 'archive.zip' },
      body: Buffer.from('x')
    })
    assert.equal(unsupported.status, 400)
  } finally {
    server.close()
  }
})
