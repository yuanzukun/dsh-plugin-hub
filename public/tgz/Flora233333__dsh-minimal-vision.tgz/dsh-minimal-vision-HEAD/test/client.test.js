import test from 'node:test'
import assert from 'node:assert/strict'
import vm from 'node:vm'
import { Blob, File } from 'node:buffer'
import { readFile } from 'node:fs/promises'

async function createBridge({ preset, attachments, responseOk = true } = {}) {
  const source = await readFile(new URL('../src/client.js', import.meta.url), 'utf8')
  let definition
  let fetchCalls = 0
  const listeners = new Map()
  const windowEvents = []
  const sandbox = {
    window: {
      dispatchEvent(event) {
        windowEvents.push(event.type)
      },
      __ModuleLoader__: {
        load(value) {
          definition = value
        }
      }
    },
    document: {
      querySelector: () => null,
      createElement: (tag) => tag === 'canvas'
        ? {
            width: 0,
            height: 0,
            getContext: () => ({
              fillStyle: '',
              strokeStyle: '',
              lineWidth: 0,
              font: '',
              textAlign: '',
              textBaseline: '',
              fillRect() {},
              strokeRect() {},
              fillText() {}
            }),
            toBlob: (callback) => callback(new Blob(['placeholder'], { type: 'image/png' }))
          }
        : { dataset: {} },
      addEventListener: (name, handler) => listeners.set(name, handler),
      removeEventListener: (name, handler) => {
        if (listeners.get(name) === handler) listeners.delete(name)
      },
      head: { appendChild() {} }
    },
    Blob,
    Event,
    File,
    fetch: async () => {
      fetchCalls += 1
      return {
        ok: responseOk,
        status: responseOk ? 200 : 500,
        json: async () => responseOk
          ? { ok: true, image: { path: '/tmp/photo.dsv.jpg' } }
          : { ok: false, error: 'upload failed' }
      }
    }
  }
  vm.runInNewContext(source, sandbox, { filename: 'client.js' })

  const nativeCalls = []
  const prompts = []
  const released = []
  const drafts = new Map()
  let draftCalls = 0
  const conversation = {
    async sendSession(...args) {
      nativeCalls.push(args)
      return 'native'
    },
    draftImages(ids) {
      draftCalls += 1
      if (attachments) return attachments
      return ids.map((id) => drafts.get(id)).filter(Boolean)
    },
    createDraftImages(files) {
      return files.map((file, index) => {
        const attachment = { kind: 'image', id: `draft-${index + 1}`, file, previewUrl: '' }
        drafts.set(attachment.id, attachment)
        return attachment
      })
    },
    releaseDraftImage(id) {
      drafts.delete(id)
    },
    releaseDraftImages(value) {
      released.push(value)
      for (const attachment of value) drafts.delete(attachment.id)
    }
  }
  const ctx = {
    get(name) {
      assert.equal(name, 'conversation')
      return conversation
    },
    sessions: {
      list: {
        getSnapshot: () => ({
          current: 'session-1',
          byId: { 'session-1': { agentPreset: preset } }
        })
      },
      scope: () => ({})
    },
    effect(effect) {
      this.cleanup = effect()
    },
    slots: {
      inject() {},
      register() {}
    },
    _listeners: listeners
  }
  const inputNotices = []
  ctx.get = (name) => {
    assert.equal(name, 'conversation')
    conversation.input = {
      for: () => ({
        addImages: () => true,
        notify: (_level, text) => inputNotices.push(text)
      })
    }
    return conversation
  }
  const react = { useState() {}, useEffect() {} }
  const runtime = { jsx() {}, jsxs() {} }
  const exported = definition.factory((name) => name === 'react' ? react : runtime)
  exported.apply(ctx)

  const session = {
    sessionId: 'session-1',
    async prompt(content, mode) {
      prompts.push({ content, mode })
      return { ok: true }
    }
  }
  return {
    send: (...args) => conversation.sendSession(...args),
    nativeCalls,
    prompts,
    released,
    get draftCalls() { return draftCalls },
    get fetchCalls() { return fetchCalls },
    inputNotices,
    windowEvents,
    async drop(file) {
      const handler = listeners.get('drop')
      assert.ok(handler)
      const event = {
        dataTransfer: { files: [file] },
        preventDefault() { this.defaultPrevented = true },
        stopImmediatePropagation() { this.stopped = true }
      }
      handler(event)
      await new Promise((resolve) => setTimeout(resolve, 0))
      return event
    },
    drafts,
    session,
    cleanup: ctx.cleanup
  }
}

test('non-vision sessions leave every attachment to native DSH handling', async () => {
  for (const file of [
    { name: 'slides.pdf', type: 'application/pdf' },
    { name: 'photo.png', type: 'image/png' }
  ]) {
    const bridge = await createBridge({ preset: 'minimal', attachments: [{ file }] })
    const result = await bridge.send(bridge.session, 'inspect', ['attachment-1'], 'normal')
    assert.equal(result, 'native')
    assert.equal(bridge.nativeCalls.length, 1)
    assert.equal(bridge.draftCalls, 0)
    assert.equal(bridge.prompts.length, 0)
    assert.equal(bridge.released.length, 0)
  }
})

test('vision sessions fall back to native handling for unmanaged attachments', async () => {
  for (const attachments of [
    [{ file: { name: 'slides.pdf', type: 'application/pdf' } }],
    [
      { file: { name: 'diagram.png', type: 'image/png' } },
      { file: { name: 'slides.pptx', type: 'application/vnd.openxmlformats-officedocument.presentationml.presentation' } }
    ]
  ]) {
    const bridge = await createBridge({ preset: 'vision-assist', attachments })
    const result = await bridge.send(bridge.session, 'inspect', attachments.map((_, i) => `attachment-${i}`), 'normal')
    assert.equal(result, 'native')
    assert.equal(bridge.nativeCalls.length, 1)
    assert.equal(bridge.prompts.length, 0)
    assert.equal(bridge.released.length, 0)
  }
})

test('vision sessions upload only supported image extensions and prompt the agent', async () => {
  const bridge = await createBridge({
    preset: 'vision-assist',
    attachments: [{ file: { name: 'PHOTO.JPEG', type: 'image/jpeg' } }]
  })
  await bridge.send(bridge.session, 'describe this', ['attachment-1'], 'normal')
  assert.equal(bridge.nativeCalls.length, 0)
  assert.equal(bridge.prompts.length, 1)
  assert.equal(bridge.prompts[0].content.length, 1)
  assert.equal(bridge.prompts[0].content[0].type, 'text')
  assert.equal(bridge.prompts[0].content[0].text, 'describe this')
  assert.equal(bridge.fetchCalls, 1)
  assert.equal(bridge.released.length, 1)
})

test('vision sessions accept document drops and upload the original file', async () => {
  const bridge = await createBridge({ preset: 'vision-assist' })
  const event = await bridge.drop(new File(['pdf-bytes'], 'report.pdf', { type: 'application/pdf' }))
  assert.equal(event.defaultPrevented, true)
  assert.equal(event.stopped, true)
  assert.deepEqual(bridge.windowEvents, ['dragend'])
  assert.deepEqual(bridge.inputNotices, ['已添加 1 个附件'])
  assert.equal(bridge.drafts.size, 1)

  await bridge.send(bridge.session, '', ['draft-1'], 'normal')
  assert.equal(bridge.nativeCalls.length, 0)
  assert.equal(bridge.fetchCalls, 1)
  assert.equal(bridge.prompts[0].content[0].text, '请处理这些附件。')
  assert.equal(bridge.released.length, 1)
})
