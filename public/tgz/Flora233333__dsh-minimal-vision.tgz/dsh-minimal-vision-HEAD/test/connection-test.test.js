import test from 'node:test'
import assert from 'node:assert/strict'
import http from 'node:http'
import { once } from 'node:events'
import { mkdtemp, writeFile } from 'node:fs/promises'
import { join } from 'node:path'
import { tmpdir } from 'node:os'
import { createVisionTestHandler } from '../src/connection-test.js'

async function listen(handler) {
  const server = http.createServer(handler)
  server.listen(0, '127.0.0.1')
  await once(server, 'listening')
  return server
}

async function visionHome(port, key = 'test-key') {
  const home = await mkdtemp(join(tmpdir(), 'dsh-vision-test-'))
  await writeFile(join(home, 'settings.yaml'), `dsh-tool-vision:\n  apiStyle: openai_chat_completions\n  baseUrl: http://127.0.0.1:${port}/v1\n  model: test-vl\n`)
  await writeFile(join(home, '.credentials.yaml'), `VISION_API_KEY: ${key}\n`)
  return home
}

async function callTestRoute(options = {}) {
  const server = await listen(createVisionTestHandler(options))
  const url = `http://127.0.0.1:${server.address().port}`
  return {
    server,
    fetch: (init = {}) => fetch(url, {
      method: 'POST',
      headers: { 'x-dsh-vision-test': '1' },
      ...init
    })
  }
}

test('connection test sends a text-only request and reports the active model', async () => {
  let body
  const provider = await listen(async (request, response) => {
    let raw = ''
    for await (const chunk of request) raw += chunk
    body = JSON.parse(raw)
    response.setHeader('content-type', 'application/json')
    response.end(JSON.stringify({ choices: [{ message: { content: '{"ok":true}' } }] }))
  })
  const route = await callTestRoute({ dshHome: await visionHome(provider.address().port) })
  try {
    const response = await route.fetch()
    const result = await response.json()
    assert.equal(response.status, 200)
    assert.equal(result.ok, true)
    assert.equal(result.model, 'test-vl')
    assert.equal(result.apiStyle, 'openai_chat_completions')
    assert.equal(body.messages[1].content.length, 1)
    assert.equal(body.messages[1].content[0].type, 'text')
  } finally {
    route.server.close()
    provider.close()
  }
})

test('connection test reports provider authentication failures without exposing the key', async () => {
  const provider = await listen((_request, response) => {
    response.statusCode = 401
    response.end('{"error":{"message":"bad key"}}')
  })
  const route = await callTestRoute({ dshHome: await visionHome(provider.address().port, 'never-return-this-key') })
  try {
    const response = await route.fetch()
    const result = await response.json()
    assert.equal(response.status, 401)
    assert.equal(result.ok, false)
    assert.match(result.error, /HTTP 401/)
    assert.doesNotMatch(JSON.stringify(result), /never-return-this-key/)
  } finally {
    route.server.close()
    provider.close()
  }
})

test('connection test reports provider timeouts', async () => {
  const provider = await listen(() => {})
  const route = await callTestRoute({
    dshHome: await visionHome(provider.address().port),
    timeoutMs: 25
  })
  try {
    const response = await route.fetch()
    const result = await response.json()
    assert.equal(response.status, 504)
    assert.match(result.error, /timed out/)
  } finally {
    route.server.closeAllConnections()
    route.server.close()
    provider.closeAllConnections()
    provider.close()
  }
})

test('connection test route rejects non-POST and unmarked requests', async () => {
  const route = await callTestRoute()
  try {
    assert.equal((await route.fetch({ method: 'GET' })).status, 405)
    assert.equal((await route.fetch({ headers: {} })).status, 403)
  } finally {
    route.server.close()
  }
})
