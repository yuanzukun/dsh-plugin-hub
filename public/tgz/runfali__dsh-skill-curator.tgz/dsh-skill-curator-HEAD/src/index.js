/**
 * dsh-skill-curator — 自动技能策展 bundle 插件（Host 半）。
 *
 * 把 hermes 的「后台评审自动提炼 skill」闭环移植到 DSH（零侵入，不改 dsh 源码）：
 *
 *   1. 触发：agent/created 闭包注册 agent 级 turn-stopping（serial）监听，
 *      每 N 轮真实对话（默认 3）计数达标后异步调度一次评审（fire-and-forget，
 *      绝不阻塞 turn 关闭；子代理 session 不计数、不递归）。
 *   2. 评审：起一个 spawn 子代理，注入「会话摘要 + 评审指令」；toolFilter
 *      allow 白名单把它限制为只能调用 skill-library-* 工具（hermes 运行时
 *      白名单的工具级等价物）；结果经日志/状态面板回显，不污染父会话。
 *   3. 写盘：~/.dsh/skills/<name>/SKILL.md（中文正文 + 双语描述）。评审可对库内
 *      任意 skill 增删改（excludedSkills 保护名单除外）：动笔前必须 skill-library-read
 *      取 sha256 并在写入时回传（硬约束「先读后改」），每次写入前自动备份。
 *   4. 手动：/skill-refine [focus] 命令立即对当前会话发起评审。
 *
 * 已知平台约束（docs/COMPARISON.md）：
 *   - 触发计数用 agent/created 闭包注册 agent.ctx 子监听（scoped 监听天然多会话隔离）；
 *     turn-stopping 载荷经 agentEvents 的 fused() 注入 agent（0.1.7-rc.2 源码核对：
 *     dsh-agent-loop/lib/index.js:984 dispatch.serial("agent/turn-stopping", {turn,signal})
 *     走 agent-scoped carrier），但闭包取 agent 同样正确，不依赖该字段的稳定性；
 *   - 回调里不往父会话注入任何事件（防污染会话历史与记忆）；
 *   - 评审异步执行，与主线完全解耦。
 */
import { mkdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { randomUUID } from 'node:crypto'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { Config, createSettings } from './settings.js'
import { createCounter } from './counters.js'
import { buildDigest, truncateDigest } from './digest.js'
import { buildReviewPrompt } from './review-prompt.js'
import { runSkillReview, REVIEW_AGENT_PRESET } from './reviewer.js'
import { createSkillToolDefinitions, TOOL_NAMES, TOOLS_READY_SERVICE, CURATOR_AUTHOR, skillsRoot, gitRootOf, listSkills, runGit, SKILL_ID } from './skill-tools.js'
import { createHistoryStore, defaultHistoryPath } from './history-store.js'
import { createLifecycleStore } from './lifecycle.js'
import { usageCandidates } from './usage-scan.js'
import { CURATOR_SKILL } from './runtime-skill.js'

/** Cordis 插件短名（路由/日志用）。 */
export const name = 'skill-curator'

/** 需要这些服务就绪再 apply。 */
export const inject = ['settings', 'tools']

// 0.1.7 起设置命名空间注册已移除：Config 必须从插件模块导出（宿主按 runtime.Config
// 枚举设置视图），命名空间 = cordis 行 id 'skill-curator'。未导出 = 插件页无配置入口。
export { Config }

/** 单次 UI 归档批量的上限（防一次误传整个库）。 */
const MAX_ARCHIVE_BATCH = 50
/** UI 归档请求体上限（50 个技能名 × ~64 字节，留足余量）。 */
const MAX_ARCHIVE_BODY_BYTES = 64 * 1024
/**
 * status 磁盘对账的最小间隔（毫秒）。
 *
 * 为什么需要：面板每 30 秒轮询一次 /status，而对账要 readdir 整个技能库。
 * 68 个目录只需几毫秒，但节流能防止「多个面板同时开着 / 快速刷新」时的重复扫描。
 */
const STATUS_RECONCILE_MS = 5_000

/**
 * 让生命周期表跟磁盘对账（只登记/清理/复活，**绝不**改使用时间戳、绝不归档）。
 *
 * 为什么挂在 status 上：syncWith 原本只在评审收尾时跑，而评审间隔 3 轮对话 ——
 * 「刚新建 / 删除 / git 恢复一个技能」后，面板要等下一轮评审才反映，极端情况下
 * 永远不刷新（只能重启 dsh）。面板展示的是磁盘现状，磁盘变了就该立刻看到。
 *
 * 为什么**不**在这里跑 transitions()：status 是 UI 每 30 秒轮询的只读接口，
 * 在里面标 stale / 归档等于把轮询变成破坏性操作。判定留给评审。
 *
 * @param {object} lifecycle - createLifecycleStore 的实例。
 * @param {object} spec - 当前生效设置（要 skillsRoot / excludedSkills）。
 * @param {{ran:boolean, reason?:string, seeded?:number, dropped?:number, restored?:number}} state
 *   调用方的节流状态（闭包持有，测试可各自独立）。
 * @returns {Promise<object>}
 */
async function reconcileLifecycle(lifecycle, spec, state, nowMs = Date.now()) {
  if (nowMs - state.at < STATUS_RECONCILE_MS) return { ran: false, reason: 'throttled' }
  state.at = nowMs
  try {
    const excluded = Array.isArray(spec.excludedSkills) ? spec.excludedSkills.map(String) : []
    const names = (await listSkills(skillsRoot(spec), excluded)).map((k) => k.name)
    return { ran: true, ...lifecycle.syncWith(skillsRoot(spec), names) }
  } catch (error) {
    // 对账失败绝不能拖垮 status：面板看上一份快照，总比报 500 好。
    return { ran: false, reason: String((error && error.message) || error) }
  }
}

/**
 * 读取请求体（带上限）。超限返回 null —— 调用方回 413。
 * @param {object} req - http.IncomingMessage
 * @param {number} limit - 字节上限
 * @returns {Promise<string|null>}
 */
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0
    const chunks = []
    req.on('data', (chunk) => {
      size += chunk.length
      if (size > limit) {
        resolve(null)
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')))
    req.on('error', reject)
  })
}

/** 插件版本（读自 package.json，状态接口回显用）。 */
const VERSION = (() => {
  try {
    return JSON.parse(readFileSync(join(dirname(fileURLToPath(import.meta.url)), '..', 'package.json'), 'utf8')).version || '0.0.0'
  } catch {
    return '0.0.0'
  }
})()

/**
 * 宿主侧评审历史（持久化：<DSH_HOME>/skill-curator/reviews.json，patch
 * config.historyPath 可覆盖）。卸载/重装/重启后记录仍在。模块级存储工厂：
 * 默认路径在模块加载时按环境初始化（apply 必须同步），config.historyPath
 * 覆盖在 apply 时重建 store 并立即可用（2026-09-01 修复：原实现仅打日志
 * 提示「下次启动生效」，本进程内覆盖不生效）。
 */
export function createReviewLog(overrideFile) {
  return createHistoryStore({
    file: overrideFile || process.env.DSH_CURATOR_HISTORY || undefined,
    log: (level, message) => console.log(`[${level}] ${message}`)
  })
}

/** 默认历史存储（显式覆盖路径时由 apply 重建）。 */
export let reviewLog = createReviewLog(undefined)

/**
 * 读取评审 preset 的活体状态（诊断用，永不抛错）。
 *
 * `agentPresets.list()` 每次调用都会重跑 `diagnostic()`（registry 源码
 * :570-581），所以返回值是**当下**能不能组装会话，而不是 activate 时的一次性
 * 快照——这正是排查「preset 永久 broken」时需要的东西（`record.broken` 只在
 * activate 失败时写死，之后 Loader 行照样显示 active，看行状态会误判为正常）。
 *
 * @param {object} ctx - 宿主上下文（须能取到 agentPresets 服务）。
 * @returns {Promise<{id:string, broken?:string}|{error:string}>} 该 preset 的状态。
 */
export async function reviewPresetStatus(ctx) {
  try {
    const registry = ctx.get('agentPresets')
    if (!registry || typeof registry.list !== 'function') return { error: 'agentPresets service unavailable' }
    const roster = await registry.list()
    const row = roster.find((p) => p.id === REVIEW_AGENT_PRESET)
    if (!row) return { error: `preset ${REVIEW_AGENT_PRESET} not declared` }
    return row.broken === undefined ? { id: row.id, ok: true } : { id: row.id, broken: row.broken }
  } catch (error) {
    return { error: String((error && error.message) || error) }
  }
}

/**
 * @param {object} ctx - cordis 上下文（settings/tools 注入）。
 * @param {object} config - composition 补丁配置（可含 skillsRoot / historyPath）。
 */
export function apply(ctx, config = {}) {
  const settings = createSettings(ctx, config)
  // config.historyPath 覆盖：重建 store（读新路径历史），立即生效——
  // 原实现只提示「下次启动生效」，覆盖在本进程内不生效（审计 P2-1）。
  if (config.historyPath && reviewLog.path !== config.historyPath) {
    reviewLog = createReviewLog(config.historyPath)
    ctx.logger.info('skill-curator: historyPath override applied → %s (prev %s)', config.historyPath, reviewLog.path)
  }

  /**
   * 评审收尾自动 commit：把技能库的改动落进 git。
   *
   * 为什么放在插件侧而不是让子代理自己调：子代理的 git 工具（skill-library-git）只是
   * 给它自查用的；真正「每次评审都有版本兜底」必须由主线保证，否则子代理漏调就没了。
   * @returns {Promise<object|null>} { committed, sha?, reason? }；非 git 库或失败返回 null/原因。
   */
  async function autoCommit(ctxRef, spec, actions, agentRef) {
    try {
      const root = skillsRoot(spec)
      const repo = await gitRootOf(root)
      if (repo === null) return { committed: false, reason: 'skills root is not a git work tree' }
      const summary = actions.length > 0
        ? actions.join(' · ').slice(0, 160)
        : 'review produced no skill change'
      const session = (agentRef.session && agentRef.session.id) || 'unknown'
      const message = `skill-curator: ${summary}\n\nsession: ${session}`
      const res = await runGit(repo, ['add', '-A', '--', '.'])
      if (res.code !== 0) return { committed: false, reason: `git add failed: ${res.stderr.trim()}` }
      const status = await runGit(repo, ['status', '--porcelain', '--untracked-files=all'])
      if (!status.stdout.trim()) return { committed: false, reason: 'nothing to commit' }
      const commit = await runGit(repo, ['commit', '-m', message])
      if (commit.code !== 0) return { committed: false, reason: `git commit failed: ${commit.stderr.trim()}` }
      const head = await runGit(repo, ['rev-parse', '--short', 'HEAD'])
      const out = { committed: true, sha: head.stdout.trim() }
      ctxRef.logger.info('skill-curator: auto-committed review changes → %s', out.sha)
      console.log(`skill-curator: 💾 已提交技能库改动 ${out.sha}`)
      return out
    } catch (error) {
      ctxRef.logger.warn('skill-curator: auto-commit failed: %s', (error && error.message) || error)
      return { committed: false, reason: String((error && error.message) || error) }
    }
  }

  // ---------------------------------------------------------------------
  // 使用观测：什么算「用了一次技能」由 ./usage-scan.js 单点决定
  // ---------------------------------------------------------------------
  // 为什么用 tools/pre-execute 而不是 ctx.tools.guard()：
  //   guard 的语义是「同步拒绝」（返回字符串即拦下工具），而观测是纯副作用，
  //   不该占用拒绝通道；pre-execute 是官方扩展点（宿主先例：dsh-tool-jobs:235、
  //   dsh-experimental-auto-review:462、dsh-hooks-claude-code:248），签名 (exec, next)。
  // 为什么必须 return next()：这是 waterfall，不返回等于把工具拦掉。
  //
  // 判据（2026-10-30 修）：旧实现只认 `skill` 工具 + 只算主会话，真机统计下
  // test-driven-development 追踪期内 28 次加载全来自子代理 → 永远「从未使用」；
  // llm-wiki 10 天 22 次直接读脚本/参考文件 → 全部漏记。
  // 现在：skill 工具（含子代理，评审会话除外）+ 参数里命中技能目录 + 维护动作排除，
  // 全部收在 usageCandidates() 里，历史回填脚本复用同一函数（判据不能有两套）。
  //
  // 定义位置必须在工具注册循环之前：Task 4 会把 lifecycle 传给
  // createSkillToolDefinitions(() => settings.spec(), () => lifecycle)，
  // 定义在 ctx.provide 之后会让那个引用落在 TDZ（ReferenceError）。
  const lifecycle = config.__lifecycle || createLifecycleStore({
    file: config.lifecyclePath || undefined,
    log: (level, message) => (level === 'warn' ? ctx.logger.warn(message) : ctx.logger.info(message))
  })
  ctx.effect(() => ctx.on('tools/pre-execute', (exec, next) => {
    try {
      const fromSkillTool = Boolean(exec && exec.name === 'skill')
      const names = usageCandidates({
        tool: exec && exec.name,
        args: exec && exec.arguments,
        agent: exec && exec.agent
      })
      for (const name of names) {
        // 路径命中只刷新**已知**技能（磁盘技能由 syncWith 登记，运行时技能由 skill 工具登记）。
        // 不设这道闸，任何提到过某个已删除技能路径的命令都会造出一条 origin='runtime'
        // 的幽灵记录 —— 而 syncWith 永远不删 runtime origin，于是「在用 N」只增不减。
        if (!fromSkillTool && !lifecycle.has(name)) continue
        lifecycle.markUsed(name)
      }
    } catch (error) {
      ctx.logger.warn('skill-curator: usage observation failed: %s', (error && error.message) || error)
    }
    return next()
  }), 'skill-curator: usage observation')

  // 运行态锁：<lifecycle.json 同目录>/lifecycle.lock（内含 pid）。
  // 回填脚本靠它判断「dsh 是否在跑」——比探测 HTTP 端口可靠：端口是可配的，
  // 探错端口就会边跑边写，插件下一次 persist 会把回填结果整份覆盖。
  const lockPath = join(dirname(lifecycle.path), 'lifecycle.lock')
  // nonce：settings 热重载是**同进程**换 fiber，新旧实例的 pid 相同。只比 pid 的话，
  // 旧 fiber 的 disposer 会把新 fiber 刚写的锁删掉（2026-10-30 复审）。
  const lockNonce = randomUUID()
  try {
    mkdirSync(dirname(lockPath), { recursive: true })
    writeFileSync(lockPath, JSON.stringify({ pid: process.pid, nonce: lockNonce, at: Date.now() }))
  } catch (error) {
    ctx.logger.warn('skill-curator: lifecycle lock write failed: %s', (error && error.message) || error)
  }

  // 卸载/热重载：先释放锁，再把最后一次使用落盘（markUsed 有 60s 节流，
  // 进程正好在窗口内退出会丢掉这次使用 —— 2026-10-30 查到的 cloud-cost-estimation）。
  ctx.effect(() => () => {
    try {
      // 只在锁仍是**本实例**的才删：desktop + web 共用 DSH_HOME 双开时，
      // 先退出的实例会删掉另一实例的锁，回填护栏随之失效（2026-10-30 复审）。
      const held = JSON.parse(readFileSync(lockPath, 'utf8'))
      if (held && held.pid === process.pid && held.nonce === lockNonce) rmSync(lockPath, { force: true })
    } catch { /* 锁不存在或内容坏了：不动它 */ }
    lifecycle.flush()
  }, 'skill-curator: lifecycle flush on dispose')

  // ---------------------------------------------------------------------
  // 工具注册：skill-library-*（全局注册；语义无害，写入受 excludedSkills 与「先读后改」约束）
  // ---------------------------------------------------------------------
  // 注意：必须传 spec()（已解引用 volatile 活引用），不能传 base()（原始 config）。
  // base() 里的 excludedSkills 是 {get()} 对象，Array.isArray 判为 false →
  // 保护名单会静默失效（写入保护形同虚设）。skillsRoot/backupRoot 是普通字段，spec() 同样带出。
  for (const definition of createSkillToolDefinitions(() => settings.spec(), () => lifecycle)) {
    ctx.tools.register(definition)
  }
  // 就绪标记：必须在工具注册**之后**发布。preset 里的 preset-guard 靠它
  // 决定何时调 tools.restrict({allow: TOOL_NAMES})——restrict 用
  // view(scope).restrictableNames 校验名字，而它只收继承面
  // （dsh-tools/lib/index.js:3058-3070），profile 各行又是 Promise.all 并发
  // 创建的，抢先调用会抛 "names unknown global tools" 并被 registry 写死成
  // 永久 broken。顺序颠倒 = 白名单守卫失效（详见 src/preset-guard.js 头注）。
  ctx.provide(TOOLS_READY_SERVICE, { names: [...TOOL_NAMES] })
  ctx.logger.info(
    `skill-curator: registered ${TOOL_NAMES.length} skill-library tools ` +
    `(curator author: ${CURATOR_AUTHOR}); ${TOOLS_READY_SERVICE} ready`
  )

  // ---------------------------------------------------------------------
  // 运行时技能：把这 11 个工具的用法写进主会话的技能目录
  // ---------------------------------------------------------------------
  // 等待式注入：skills 服务由 dsh-base 的 dsh-skill 行提供，与本插件 apply 时序不保证。
  // 一次性 ctx.get('skills') 在服务未就绪时拿到 undefined → 静默不注册（第七路盲区同源）。
  ctx.inject(['skills'], (sctx) => {
    try {
      if (typeof sctx.skills.register !== 'function') {
        ctx.logger.warn('skill-curator: skills.register unavailable; runtime skill not registered')
        return
      }
      // 官方范例（dsh-client-connection/lib/index.js:843）：注册必须包在 effect 里，
      // 卸载时 disposer 由 fiber 收口，避免热重载后残留旧技能。
      sctx.effect(() => sctx.skills.register({
        name: CURATOR_SKILL.name,
        description: CURATOR_SKILL.description,
        whenToUse: CURATOR_SKILL.whenToUse,
        source: 'custom',
        content: CURATOR_SKILL.content
      }), 'skill-curator: runtime skill')
    } catch (error) {
      ctx.logger.warn('skill-curator: runtime skill registration failed: %s', (error && error.message) || error)
    }
  })

  // ---------------------------------------------------------------------
  // 触发：agent/created → agent 级 turn-stopping 计数
  // ---------------------------------------------------------------------
  const running = new WeakSet() // 同会话互斥：一次只跑一个评审
  const tracked = new WeakSet() // 同 agent 幂等：agent/created 与补注册共用 installAgentTrack

  /**
   * 异步后台评审（不阻塞调用方；全异常兜底，绝不炸主线）。
   * @param {object} agent
   * @param {string} [focus] - /skill-refine 附加关注点
   */
  function scheduleReview(agent, focus) {
    if (running.has(agent)) {
      ctx.logger.info('skill-curator: review already running for %s; skipped', agent.session && agent.session.id)
      return
    }
    running.add(agent)
    const done = () => running.delete(agent)
    // 微任务延后：turn-stopping 的 serial 事务结束后再跑评审
    Promise.resolve()
      .then(async () => {
        const s = settings.spec()
        // dsh 0.1.2-alpha.4 起 Session 不再暴露 events 属性（prototype 实证仅有
        // snapshotEvents()）——旧读法恒为 undefined → 摘要恒空 → 每次评审被
        // 「no user/model turns」静默跳过且不留任何记录（2026-09-02 修复）。
        // 保留 events 兜底以兼容旧版 dsh 与测试 mock。
        const session = agent.session
        const rawEvents = session
          ? (typeof session.snapshotEvents === 'function' ? session.snapshotEvents() : session.events)
          : undefined
        const events = Array.isArray(rawEvents) ? [...rawEvents] : []
        const { text, stats } = buildDigest(events, { tail: s.digestTail })
        // 无实质对话内容（events 全为 tool/plugin/系统事件）时不起评审
        if (stats.total === 0) {
          ctx.logger.info(
            'skill-curator: review skipped for %s (no user/model turns in %d events)',
            agent.session && agent.session.id,
            events.length
          )
          return
        }
        const digestText = truncateDigest(text, s.digestMaxChars)
        const prompt = buildReviewPrompt({ digestText, focus })
        ctx.logger.info(
          'skill-curator: review started for %s (events=%d compressed=%d chars=%d)',
          agent.session && agent.session.id,
          stats.total,
          stats.compressed,
          digestText.length
        )
        const out = await runSkillReview(ctx, agent, {
          prompt,
          spec: s,
          // 自定义端点 adapter 每次请求现读设置（热改即时生效）
          getSpec: () => settings.spec()
        })
        const actions = out.actions || []
        // 生命周期迁移挂在评审流程上（评审每 N 轮必跑，无需独立定时器）。
        // 判定与执行分离：archiveEnabled 默认 false → 只报告不动磁盘。
        // transitions() 对非有限 staleDays/archiveDays 会抛错（响亮失败设计），
        // 所以必须包 try/catch：设置项被写坏时只跳过本轮，绝不炸掉整个评审。
        let lifecycleCounts = null
        try {
          const excluded = Array.isArray(s.excludedSkills) ? s.excludedSkills.map(String) : []
          const names = (await listSkills(skillsRoot(s), excluded)).map((k) => k.name)
          lifecycle.syncWith(skillsRoot(s), names)
          lifecycleCounts = lifecycle.transitions({
            staleDays: s.staleDays,
            archiveDays: s.archiveDays,
            archiveEnabled: s.archiveEnabled,
            // 与工具层 skill-library-lifecycle 同源的保护名单守卫：listSkills() 只把
            // excluded 用于填 protected 标记、**不过滤**，所以保护名单必须在这里再拦一道，
            // 否则开关一开，受保护技能照样被移出技能库（2026-10-20 评审发现）。
            archiveFn: (name) => (excluded.includes(name) ? false : lifecycle.archive(name, skillsRoot(s)))
          })
        } catch (error) {
          ctx.logger.warn('skill-curator: lifecycle pass failed: %s', (error && error.message) || error)
        }
        // 收尾自动 commit（2026-09-28 发哥拍板）：评审写进技能库的改动立刻进 git，
        // 否则「子代理写了什么」既无历史也无 diff 兜底。失败只告警，绝不影响评审结论。
        let versionBackstop = null
        if (out.ok) versionBackstop = await autoCommit(ctx, settings.spec(), actions, agent)
        reviewLog.record({
          at: new Date().toISOString(),
          sessionId: agent.session && agent.session.id,
          ok: out.ok,
          stopReason: out.stopReason,
          actions,
          summary: out.summary,
          diagnostic: out.diagnostic || undefined,
          fallback: out.fallback,
          lifecycle: lifecycleCounts || undefined,
          commit: versionBackstop || undefined
        })
        const notify = String(s.notifyMode || 'on')
        if (notify !== 'off') {
          const headline = actions.length > 0
            ? `💾 Skill review: ${actions.join(' · ')}`
            : '💾 Skill review: 无需保存'
          const fallbackMark = out.fallback ? ' [已回退主模型]' : ''
          const line = `skill-curator: ${headline}${fallbackMark} (session=${agent.session && agent.session.id})`
          // 双通道：ctx.logger 进结构化日志；console.log 直出宿主 stdout
          //（dsh 的 LoggerService 默认不透出 info 级别到 stdout）
          ctx.logger.info(line)
          console.log(line)
          if (notify === 'verbose' && out.summary) {
            const detail = `skill-curator: [detail] ${out.summary.slice(0, 2000)}`
            ctx.logger.info(detail)
            console.log(detail)
          }
        }
      })
      .catch((error) => {
        reviewLog.record({
          at: new Date().toISOString(),
          sessionId: agent.session && agent.session.id,
          ok: false,
          error: String((error && error.message) || error)
        })
        ctx.logger.warn('skill-curator: review failed: %s', (error && error.message) || error)
      })
      .finally(done)
  }

  // 全局监听 agent/created（载荷 {agent}），在 agent 级 scoped ctx 上注册
  // turn-stopping。0.1.7-rc.2 源码核对（dsh-agent-loop/lib/index.js:984）：该事件经 agentEvents 的 fused() 注入 agent
  // （载荷 {agent, turn, signal}），但会话标识仍从闭包拿——不依赖事件字段，更稳。
  // cordis 的 on 第三参数是过滤器，绝不能当 label 传。
  // 计数按 sessionId（非 agent 对象）维护：agent 重建（/compact、会话恢复）时继承计数，
  // 避免触发间隔被重置（审计 P2-2）；agent/disposed 时清理。
  const countersBySession = new Map()

  /**
   * 给单个 agent 挂 turn-stopping 计数钩子（agent/created 与 apply 期补注册
   * 共用；幂等保护：同会话重复到达不重挂、不重置计数——审计 P2-2）。
   * @param {object} agent
   * @returns {boolean} 是否实际挂上（guard 不过或重复到达为 false）
   */
  function installAgentTrack(agent) {
    if (!agent || !agent.ctx || !agent.session) return false
    if (tracked.has(agent)) return false
    tracked.add(agent)
    const header = agent.session.header || {}
    // 评审子代理自身不参与触发（双保险：origin 标记 + 委派深度）
    if (header.origin === 'subagent') return false
    if (typeof header.delegationDepth === 'number' && header.delegationDepth > 0) return false
    const sessionId = agent.session.id
    let counter = countersBySession.get(sessionId)
    let ownsCounter = false
    if (!counter) {
      counter = createCounter()
      countersBySession.set(sessionId, counter)
      ownsCounter = true
    }
    agent.ctx.on('agent/turn-stopping', () => {
      try {
        const s = settings.spec()
        if (!s.enabled) return
        let fired = false
        try {
          fired = counter.bump(s.skillNudgeInterval)
        } catch {
          fired = false
        }
        if (fired) scheduleReview(agent)
      } catch (error) {
        ctx.logger.warn('skill-curator: turn-stopping handler error: %s', (error && error.message) || error)
      }
    })
    agent.ctx.on('agent/disposed', () => {
      // 仅当该 session 的计数仍由本 agent 首次创建时清理；
      // 若重建后的新 agent 已继承（ownsCounter=false），延迟到达的
      // 旧 agent disposed 不得误删新计数（审计复核 P2-2 边界）。
      if (ownsCounter && countersBySession.get(sessionId) === counter) {
        countersBySession.delete(sessionId)
      }
    })
    return true
  }

  // 触发路径一：agent/created（新创建的 agent）。
  ctx.effect(() => ctx.on('agent/created', (payload) => {
    try {
      installAgentTrack(payload && payload.agent)
    } catch (error) {
      ctx.logger.warn('skill-curator: agent/created handler error: %s', (error && error.message) || error)
    }
  }), 'skill-curator: agent track')

  // 触发路径二：补注册已存在的 agent（2026-09-02 修复，2026-09-28 修正时序）。
  // dsh 重启后 resume 的 agent（及任何插件晚于 agent 创建的时序），其
  // agent/created 在本监听注册之前已经 emit——错过即永久错过，resume 会话
  // 永远挂不上 turn-stopping（症状：重启后当前会话 3 轮结束不触发评审；
  // 同坑先例 = dsh-mem0-plugins 2026-08-25 补注册修复）。
  //
  // ⚠️ 必须是**等待式注入**，不能用一次性 ctx.get('agents')：
  // agents 由 dsh-base 的 agent 行提供，与本插件 apply 的时序不保证 ——
  // 服务未就绪时一次性读拿到 undefined，补注册被静默跳过、零日志，
  // 症状是「重启后第一个会话永远不被策展」（2026-09-28 实测：同一形态
  // 先在 webServer 上爆发过一次，这里同源）。
  // installAgentTrack 幂等，与路径一重复到达不会双挂。
  ctx.inject(['agents'], (agentCtx) => {
    try {
      const existing = agentCtx.agents && typeof agentCtx.agents.list === 'function'
        ? agentCtx.agents.list()
        : []
      if (existing && existing.length) {
        for (const agent of existing) installAgentTrack(agent)
        ctx.logger.info('skill-curator: backfilled %d existing agent(s)', existing.length)
      }
    } catch (error) {
      ctx.logger.warn('skill-curator: existing-agent backfill failed: %s', (error && error.message) || error)
    }
  })

  // ---------------------------------------------------------------------
  // 手动命令：/skill-refine [focus]
  // ---------------------------------------------------------------------
  // ⚠️ 必须走等待式 ctx.inject(['commands'])，**不能**用一次性 ctx.get('commands')：
  //   commands 由 dsh-base 的 dsh-commands 行提供（bundle 0），与本插件 apply
  //   时序不保证。一次性读在服务未就绪时拿到 undefined → `if (undefined !== undefined)`
  //   直接跳过 → **静默不注册 /skill-refine**，零日志、零报错（与本仓修过的
  //   webServer / agents / skills 三条「第七路盲区」完全同源）。
  //   官方命令插件一律把 commands 放进 inject 等待就绪：
  //   dsh-command-goal:10、dsh-command-compact:9、dsh-command-feedback:66。
  //   注册成功打一行 info：否则「命令没出现」与「命令注册失败」在真机上无法区分。
  ctx.inject(['commands'], (commandCtx) => {
    try {
      commandCtx.commands.register({
        name: 'skill-refine',
        description: '立即对本次会话发起一次后台技能评审（可附加关注点：/skill-refine <focus>）',
        handler: ({ agent, rawInput, signal }) => {
          try {
            scheduleReview(agent, (rawInput || '').trim())
            return {
              kind: 'success',
              text: '🎓 技能评审已在后台启动，完成后结果会出现在宿主日志与设置卡片。'
            }
          } catch (error) {
            return { kind: 'error', text: `技能评审启动失败：${(error && error.message) || error}` }
          }
        }
      })
      ctx.logger.info('skill-curator: /skill-refine command registered')
    } catch (error) {
      ctx.logger.warn('skill-curator: /skill-refine registration failed: %s', (error && error.message) || error)
    }
  })

  // ---------------------------------------------------------------------
  // 状态接口：GET /api/skill-curator/status（设置卡片轮询展示）
  // ---------------------------------------------------------------------
  // 等待式注入（第七路盲区，2026-09-28 实测踩中）：
  // webServer 由 dsh-web-app 组合挂载，与本插件的 apply 时序不保证——
  // 用一次性 ctx.get('webServer') 会在服务未就绪时静默空转（状态接口永不注册，
  // 设置卡「最近评审」永远拿不到数据，且没有任何报错）。正确形态是 ctx.inject 等待就绪。
  const LOOPBACK = /^(127\.0\.0\.1|\[::1\]|localhost)(:\d+)?$/i
  // status 磁盘对账的节流状态（每次 apply 一份，随 fiber 一起走）。
  // at = -Infinity：**第一次请求必须立即对账**，否则「启动后首次打开面板」
  // 要等 5s 节流窗口，看起来像面板没数据。
  const reconcileState = { at: -Infinity }
  const sameOrigin = (req) => {
    // 同源守卫（对齐 dsh-config-center 先例）：/api 信任围栏校验 Host/Origin
    const host = String(req.headers && (req.headers.host || req.headers.Host) || '')
    if (!LOOPBACK.test(host)) return false
    const origin = req.headers && (req.headers.origin || req.headers.Origin)
    if (!origin) return true // 同源 GET 可能不带 Origin
    try {
      return LOOPBACK.test(new URL(String(origin)).host)
    } catch {
      return false
    }
  }
  ctx.inject(['webServer'], (wsCtx) => {
    // 官方范例（dsh-client-connection/lib/index.js:843）：注册必须包在 effect 里，
    // 卸载时 disposer 由 fiber 收口，避免热重载后残留旧路由。
    wsCtx.effect(() => wsCtx.webServer.register({
      kind: 'exact',
      path: '/api/skill-curator/status',
      handler: async (req, res) => {
        try {
          if (!sameOrigin(req)) {
            res.writeHead(403, { 'content-type': 'application/json; charset=utf-8' })
            res.end(JSON.stringify({ ok: false, error: 'forbidden: cross-origin' }))
            return
          }
          if (req.method !== 'GET' && req.method !== 'HEAD') {
            res.writeHead(405, { allow: 'GET' })
            res.end('method not allowed')
            return
          }
          const spec = settings.spec()
          // 磁盘对账：不评审也要「及时」。只 syncWith（登记/清理/复活），
          // 不跑 transitions —— status 是只读轮询，绝不能在这里标 stale / 归档。
          // 节流 5s，防止多面板/快速刷新重复 readdir。
          await reconcileLifecycle(lifecycle, spec, reconcileState)
          const body = JSON.stringify({
            ok: true,
            name,
            version: VERSION,
            enabled: spec.enabled,
            interval: spec.skillNudgeInterval,
            // 诊断：这两个字段只在带「就绪握手」的版本里存在，出现即证明新代码已载入。
            toolsReadyService: TOOLS_READY_SERVICE,
            // 验收判据：评审 preset 是否还能组装会话。registry.list() 每次读取都会
            // 重跑 diagnostic()（dsh-agent-preset-registry/lib/index.js:570-581），
            // 所以这里的 broken 是**活体**状态，不是 activate 时的一次性快照。
            // 期望 'ok'；若为 broken 文本，说明 preset 里的 guard 仍在报错。
            reviewPreset: await reviewPresetStatus(ctx),
            // 传 archiveDays 才带 wouldArchive —— UI「够格归档」的候选集必须与
            // transitions() 同源，否则面板会推荐一个 archive() 拒绝做的动作。
            lifecycle: {
              ...lifecycle.summary({ archiveDays: spec.archiveDays }),
              // 面板的三组年龄数字（从未使用 / N 天未用 / 够格归档）。
              // 挂在 REST 上而不是 summary() 里：summary 同时喂给
              // skill-library-lifecycle 工具，评审 prompt 已声明它「不含逐技能时间戳」，
              // 往里加字段会改变评审子代理看到的契约。
              //
              // 降级而不是 500：usageReport 对坏阈值会响亮抛错（与 transitions 同款设计），
              // 但 /status 是面板唯一数据源 —— 一个写坏的设置项不该让整个面板变瞎子
              // （连归档/恢复按钮都跟着消失）。失败时给 null，前端自动退回旧摘要。
              usage: (() => {
                try {
                  return lifecycle.usageReport({ staleDays: spec.staleDays, archiveDays: spec.archiveDays })
                } catch (error) {
                  ctx.logger.warn('skill-curator: usage report failed: %s', (error && error.message) || error)
                  return null
                }
              })()
            },
            archiveEnabled: spec.archiveEnabled,
            reviews: reviewLog.recent().slice(0, 5)
          })
          res.writeHead(200, { 'content-type': 'application/json; charset=utf-8' })
          res.end(body)
        } catch (error) {
          res.writeHead(500, { 'content-type': 'application/json; charset=utf-8' })
          res.end(JSON.stringify({ ok: false, error: String(error && error.message || error) }))
        }
      }
    }), 'skill-curator: status route')

    // -------------------------------------------------------------------
    // POST /api/skill-curator/archive —— UI 一键归档（批量）
    // -------------------------------------------------------------------
    // 为什么需要独立路由：归档是**破坏性动作**（移目录），但可 restore，属可逆。
    // 放 GET /status 里做会让「刷新面板」变成破坏性操作；必须显式 POST。
    // 守卫（与工具层 / 自动归档路径同源，三处一致）：
    //   ① sameOrigin（页面同源才能调）；② 只接受 POST；
    //   ③ excludedSkills 保护名单拒archived；④ 运行时技能拒（不在磁盘，必失败）；
    //   ⑤ 每次最多 50 个（防一次误传整个库）。
    /**
     * 批量动作路由的共用骨架（archive / restore 只差中间那一段）。
     *
     * 抽出来的理由：两条路由的守卫**必须完全同源**（同源检查、只接受 POST、
     * 体积上限、批量上限、JSON 解析）。复制两份的话，日后改一处忘另一处，
     * 就会出现「归档拦了跨源、恢复没拦」这类安全缺口。
     *
     * @param {(payload: {names: string[], spec: object}) => Promise<{ok: boolean, [k: string]: any}>} run
     * @param {string} label - 日志标签（'archive' / 'restore'）
     */
    function batchRoute(run, label) {
      return async (req, res) => {
        const json = (code, payload) => {
          res.writeHead(code, { 'content-type': 'application/json; charset=utf-8' })
          res.end(JSON.stringify(payload))
        }
        try {
          if (!sameOrigin(req)) return json(403, { ok: false, error: 'forbidden: cross-origin' })
          if (req.method !== 'POST') return json(405, { ok: false, error: 'method not allowed' })

          const raw = await readBody(req, MAX_ARCHIVE_BODY_BYTES)
          if (raw === null) return json(413, { ok: false, error: 'body too large' })
          let parsed
          try {
            parsed = JSON.parse(raw || '{}')
          } catch {
            return json(400, { ok: false, error: 'invalid JSON body' })
          }
          const names = Array.isArray(parsed && parsed.names) ? parsed.names.map(String) : null
          if (!names || names.length === 0) return json(400, { ok: false, error: 'names[] required' })
          if (names.length > MAX_ARCHIVE_BATCH) {
            return json(400, { ok: false, error: `too many names (max ${MAX_ARCHIVE_BATCH})` })
          }

          const spec = settings.spec()
          const result = await run({ names, spec })
          ctx.logger.info(
            'skill-curator: UI %s — ok=%d skipped=%d failed=%d',
            label,
            (result[`${label}d`] || result.archived || result.restored || []).length,
            (result.skipped || []).length,
            (result.failed || []).length
          )
          return json(200, result)
        } catch (error) {
          return json(500, { ok: false, error: String((error && error.message) || error) })
        }
      }
    }

    wsCtx.effect(() => wsCtx.webServer.register({
      kind: 'exact',
      path: '/api/skill-curator/archive',
      handler: batchRoute(async ({ names, spec }) => {
        const excluded = Array.isArray(spec.excludedSkills) ? spec.excludedSkills.map(String) : []
        const root = skillsRoot(spec)
        const archived = []
        const skipped = []
        const failed = []
        for (const name of names) {
          if (!SKILL_ID.test(name)) {
            failed.push({ name, error: 'invalid skill name' })
            continue
          }
          if (excluded.includes(name)) {
            skipped.push({ name, reason: 'protected' })
            continue
          }
          const rec = lifecycle.snapshot().skills[name]
          if (!rec) {
            skipped.push({ name, reason: 'unknown' })
            continue
          }
          if (rec.origin === 'runtime') {
            skipped.push({ name, reason: 'runtime' })
            continue
          }
          if (lifecycle.archive(name, root)) archived.push(name)
          else failed.push({ name, error: 'archive failed (missing, or archive target already exists)' })
        }
        return { ok: true, archived, skipped, failed }
      }, 'archive')
    }), 'skill-curator: archive route')

    // -------------------------------------------------------------------
    // POST /api/skill-curator/restore —— UI 一键恢复（归档的逆操作）
    // -------------------------------------------------------------------
    // 「能归档不能恢复」是不对称的产品缺陷：归档可逆，UI 就该给回去的路。
    // 守卫与 archive 完全同源（共用 batchRoute）：
    //   ① 只接受 POST（GET 绝不改磁盘）；② 同源；③ 体积/批量上限。
    // 额外规则：
    //   ④ 保护名单成员也允许恢复 —— 保护的是「别删/别改内容」，不是「别救回来」；
    //   ⑤ 技能库已有同名 → 跳过（绝不覆盖，与 archive 的「不覆盖旧归档」对称）；
    //   ⑥ **不改 lastUsedAt** —— 恢复 ≠ 使用（否则刚救回来的老技能会被刷成"新鲜"）。
    wsCtx.effect(() => wsCtx.webServer.register({
      kind: 'exact',
      path: '/api/skill-curator/restore',
      handler: batchRoute(async ({ names, spec }) => {
        const root = skillsRoot(spec)
        const restored = []
        const skipped = []
        const failed = []
        for (const name of names) {
          if (!SKILL_ID.test(name)) {
            failed.push({ name, error: 'invalid skill name' })
            continue
          }
          const rec = lifecycle.snapshot().skills[name]
          if (!rec) {
            skipped.push({ name, reason: 'unknown' })
            continue
          }
          if (rec.state !== 'archived') {
            skipped.push({ name, reason: 'not-archived' })
            continue
          }
          if (lifecycle.restore(name, root)) restored.push(name)
          else failed.push({ name, error: 'restore failed (archive missing, or a skill with that name already exists)' })
        }
        return { ok: true, restored, skipped, failed }
      }, 'restore')
    }), 'skill-curator: restore route')
  })
}