/**
 * dsh-skill-curator — 评审自定义端点适配器。
 *
 * 发哥要求评审子代理的 base_url / model_id / api_key / provider 全部可自定义。
 * DSH 的 AgentOptions 只承载 provider/model/maxTokens（无端点与凭据字段），
 * 所以自定义端点走 llm.registerAdapter 路由：插件注册一个专用 provider 路由
 * （默认 'skill-curator-review'），adapter 在每次 stream 时从设置闭包读取
 * reviewBaseUrl / reviewApiKey（设置热改即时生效，无需重注册）。
 *
 * 实现为鸭子对象（非 extends LlmAdapter）。宿主对 adapter 的调用面是**整个
 * LlmAdapter 基类**（抽象类只有 stream() 是 abstract，但基类实现了 providerInfo /
 * providerRetryPolicy / imageRequestPricing / listModels / resolveModel /
 * prepareCall 六个具体方法）——鸭子对象享受不到基类默认实现，必须**逐个自备**
 * （2026-09-10 0.1.5-rc.1 适配实证：缺 imageRequestPricing 会在 token 计量时
 * TypeError，见下）。wire 格式为 OpenAI 兼容 /chat/completions（非流式），输出转成
 * StreamChunk 协议（block-start → deltas → block-end → finish），并正确
 * 表达模型发起的工具调用（tool-call 块），使评审子代理的 skill-library-*
 * 工具链路可用。
 *
 * 归因契约：每个 provider 请求必须携带 attributionHeaders()（user-agent，
 * dsh-llm 导出；省略无法抑制归因）。
 */
import { attributionHeaders } from '@deepseek-ai/dsh-llm'

/** 消息内容块 → OpenAI content 文本（text/tool-result 等非图块）。 */
export function blocksToOpenAiText(content) {
  const parts = []
  for (const block of content || []) {
    if (!block || typeof block !== 'object') continue
    if (block.type === 'text' && typeof block.text === 'string') parts.push(block.text)
    else if (block.type === 'tool-result') {
      parts.push(`[tool result ${block.toolCallId}: ${typeof block.content === 'string' ? block.content : JSON.stringify(block.content)}]`)
    } else {
      parts.push(`[${block.type} block]`)
    }
  }
  return parts.join('\n')
}

/** role 归一化（tool 结果在 OpenAI 兼容端点里以 user 角色回灌）。 */
export function openAiRole(role) {
  if (role === 'assistant' || role === 'user' || role === 'system') return role
  return 'user'
}

/** 终端块索引：文本块 0，工具调用块 1..n（每组 start→end 完整）。 */
export async function* streamChunksFromOpenAi(data) {
  const choice = data && data.choices && data.choices[0]
  const message = choice && choice.message
  const text = message && typeof message.content === 'string' ? message.content : ''
  const toolCalls = message && Array.isArray(message.tool_calls) ? message.tool_calls : []

  let index = 0
  if (text) {
    yield { type: 'block-start', index, blockType: 'text' }
    if (text) yield { type: 'text-delta', index, text }
    yield { type: 'block-end', index, block: { type: 'text', text } }
    index += 1
  }
  for (const tc of toolCalls) {
    const id = String((tc && tc.id) || `call_${index}`)
    const name = tc && tc.function && typeof tc.function.name === 'string' ? tc.function.name : ''
    const args = tc && tc.function && typeof tc.function.arguments === 'string' ? tc.function.arguments : '{}'
    yield { type: 'block-start', index, blockType: 'tool-call' }
    yield { type: 'tool-call-delta', index, id, name, argumentsDelta: args }
    yield { type: 'block-end', index, block: { type: 'tool-call', id, name, arguments: args } }
    index += 1
  }
  if (choice && choice.finish_reason === 'tool_calls') {
    yield { type: 'finish', reason: 'tool-calls' }
  } else {
    yield { type: 'finish', reason: choice && choice.finish_reason === 'length' ? 'max-tokens' : 'stop' }
  }
}

/**
 * 创建自定义端点适配器（鸭子实现）。
 *
 * @param {() => object} getSpec - 读取当前设置快照（reviewBaseUrl/reviewApiKey/reviewModel）。
 * @param {string} route - 注册给该适配器的 provider 路由名。
 */
export function createCustomAdapter(getSpec, route) {
  const endpoints = () => {
    const s = getSpec() || {}
    return {
      baseUrl: String(s.reviewBaseUrl || '').trim().replace(/\/+$/, ''),
      apiKey: String(s.reviewApiKey || ''),
      model: String(s.reviewModel || '').trim()
    }
  }
  const modelInfo = (provider, model) => ({ provider, id: model, name: model })

  return {
    providerInfo(provider) {
      return { id: provider, name: `Skill review (${provider})` }
    },
    providerRetryPolicy() {
      return undefined
    },
    // 宿主对 adapter 的调用面 = LlmAdapter 基类全体方法。抽象类只有 stream() 是
    // abstract，其余六个由基类给默认实现——鸭子对象拿不到，必须显式补全。
    // 漏掉 imageRequestPricing 的实证后果（0.1.5-rc.1）：dsh-token-meter 的
    // measure() 无条件调用 llm.imageRequestPricing()，其内部无条件调用
    // adapter.imageRequestPricing()（无 optional-call 保护）→ TypeError。
    // 走自定义端点评审过的子代理 session 头里长存本路由，之后每次计量（agent/pre-step
    // 压实、会话导出等）都会炸：压实路径有 try/catch → 每步刷 "step compaction failed"
    // 且该子代理自动压实静默失效；compactNow()/acp 计量路径无兜底 → 直接抛。
    // 声明"本路由不提供图片计费"，与基类默认语义一致。
    imageRequestPricing() {
      return undefined
    },
    // 0.2.1-rc.2 新增（dsh-llm lib/index.js:1706，抽象类签名见 typert.host.js）。
    // 基类默认 = 原样透传归一化图片的尺寸与字节预算，不缩放。
    // 本评审路由走 OpenAI 兼容 /chat/completions 且只发文本块，永不含图片；
    // 但声明面必须齐备——缺它则宿主 facade 的 `adapter.imageRequestTarget(...)`
    // 表达式 TypeError（同 imageRequestPricing 的失败形态）。
    imageRequestTarget(_provider, _model, image) {
      return {
        width: image.width,
        height: image.height,
        maxBytes: image.bytes
      }
    },
    async listModels(provider) {
      const c = endpoints()
      return c.model ? [modelInfo(provider, c.model)] : []
    },
    async resolveModel(provider, model, _signal) {
      const c = endpoints()
      return modelInfo(provider, model || c.model || 'unknown')
    },
    async prepareCall(provider, model, signal) {
      const info = await this.resolveModel(provider, model, signal)
      return { model: info, stream: (options) => this.stream(options) }
    },
    async *stream(options) {
      const c = endpoints()
      if (!c.baseUrl) throw new Error(`custom review endpoint not configured (provider=${options.provider}); set reviewBaseUrl + reviewModel + reviewApiKey`)
      const baseUrl = c.baseUrl.includes('/chat/completions') ? c.baseUrl : `${c.baseUrl}/chat/completions`
      const payload = {
        model: options.model || c.model,
        messages: (options.messages || []).map((m) => ({
          role: openAiRole(m.role),
          content: blocksToOpenAiText(m.content)
        })),
        ...(options.tools && options.tools.length
          ? { tools: options.tools.map((t) => ({ type: 'function', function: { name: t.name, description: t.description, parameters: t.parameters || {} } })) }
          : {}),
        ...(typeof options.maxTokens === 'number' ? { max_tokens: options.maxTokens } : {}),
        ...(options.temperature !== undefined ? { temperature: options.temperature } : {}),
        stream: false
      }
      const res = await fetch(baseUrl, {
        method: 'POST',
        headers: {
          'content-type': 'application/json',
          accept: 'application/json',
          ...attributionHeaders(),
          ...(c.apiKey ? { authorization: `Bearer ${c.apiKey}` } : {})
        },
        body: JSON.stringify(payload),
        signal: options.signal
      })
      if (!res.ok) {
        const detail = await res.text().catch(() => '')
        throw new Error(`custom review endpoint HTTP ${res.status}: ${detail.slice(0, 300)}`)
      }
      const data = await res.json()
      yield* streamChunksFromOpenAi(data)
    }
  }
}