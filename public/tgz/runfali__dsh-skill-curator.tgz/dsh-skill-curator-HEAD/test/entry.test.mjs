/**
 * dsh-skill-curator — 宿主入口与声明契约守护测试（0.1.7-rc.2 适配轮更新）。
 *
 * 历史教训（dsh-plugin-audit 的第 0/1/4 路盲区）：
 *   - \`node --check\` 只查语法不查模块解析；smoke 只测零依赖逻辑模块；client-smoke
 *     只测 client 半——三路都绕开宿主入口的真实加载路径。真实 P0（schemastery 只有
 *     default export 却被 named import）就是靠 entry 直载才炸出来的。
 *   - 顶层 \`inject\` 写错服务名不会报错，插件会永远 pending（静默不生效）。
 *   - 「声明适配 X」必须有测试证明 engines 区间覆盖 X（npm semver 预发布规则：
 *     预发布只被「区间内含同 [major,minor,patch] 元组预发布」的区间满足）。
 *
 * 运行：node --test test/entry.test.mjs
 */
import assert from 'node:assert/strict'
import { readFileSync, readdirSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { createRequire } from 'node:module'

const PASS = []
const ok = (label) => { PASS.push(label); console.log('  ✓ ' + label) }
const here = dirname(fileURLToPath(import.meta.url))
const root = join(here, '..')

// ---------------------------------------------------------------------------
// 1. 真实入口加载（P0 守卫：import 期错误当场炸出）
// ---------------------------------------------------------------------------
const mod = await import('../src/index.js')
assert.equal(typeof mod.apply, 'function', 'src/index.js 必须导出 apply 函数')
assert.equal(mod.name, 'skill-curator', 'Cordis 插件短名必须是 skill-curator')
assert.ok(Array.isArray(mod.inject), '顶层 inject 必须是数组')
assert.deepEqual([...mod.inject].sort(), ['settings', 'tools'], '顶层 inject 面必须恰为 settings + tools')
// 0.1.7：设置命名空间 = cordis 行 id，宿主按 runtime.Config 枚举设置视图——
// 不从插件模块导出 Config，插件页就不会出现配置入口（且完全静默）。
// schemastery 的 Schema 是可调用对象（typeof 'function'）+ 带 ~standard 校验协议，
// 宿主正是按 entry.fiber.runtime.Config 的 ~standard 校验并枚举 volatile 字段。
assert.equal(typeof mod.Config, 'function', 'src/index.js 必须 re-export Config（0.1.7 设置契约）')
assert.ok(mod.Config['~standard'] && typeof mod.Config['~standard'].validate === 'function', 'Config 必须是 schemastery schema（带 ~standard 校验协议）')
assert.ok(mod.Config.dict && Object.keys(mod.Config.dict).length > 0, 'Config 必须声明字段（否则插件页无配置入口）')
ok('宿主入口真实 import 成功（apply / name / inject / Config 面齐备）')

// ---------------------------------------------------------------------------
// 2. 声明面：版本号、exports、bundle 挂载三面、client 半
// ---------------------------------------------------------------------------
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'))
assert.equal(typeof pkg.version, 'string', 'package.json 缺 version')
assert.equal(pkg.version, '0.2.2-rc.1', '版本号必须跟宿主发布号（家族惯例）')
assert.equal(pkg.type, 'module', '必须是 ESM 包')
assert.equal(pkg.exports['.'], './src/index.js', 'exports["."] 必须指向宿主入口')
assert.equal(pkg.exports['./client'], './lib/client.js', 'exports["./client"] 必须指向 client bundle')
assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml', 'dsh.bundle.patch 必须声明（装上≠挂载：无声明不进组合树）')
assert.equal(pkg.dsh.client.platform, 'web', 'dsh.client.platform 必须是 web')
const bundleNames = Array.isArray(pkg.dsh.bundle) ? [] : null
void bundleNames
ok('package.json 版本/导出/挂载声明齐备（version=' + pkg.version + '）')

// ---------------------------------------------------------------------------
// 3. dsh.engines.dsh 区间守护（内置判定表，不引 semver 依赖，防测试自身漂移）
// ---------------------------------------------------------------------------
const range = pkg.dsh && pkg.dsh.engines && pkg.dsh.engines.dsh
assert.equal(typeof range, 'string', 'package.json 缺 dsh.engines.dsh 声明')
ok('package.json 声明了 dsh.engines.dsh：' + range)

/** 手写 semver 比较器：只处理本仓区间用到的形状（不引依赖，防测试自身依赖漂移）。 */
function parseVersion(v) {
  const m = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(String(v).trim())
  if (!m) throw new Error('unparseable version: ' + v)
  return { nums: [Number(m[1]), Number(m[2]), Number(m[3])], pre: m[4] ? m[4].split('.') : [] }
}
function cmpPre(a, b) {
  for (let i = 0; i < Math.max(a.length, b.length); i += 1) {
    const x = a[i]
    const y = b[i]
    if (x === undefined) return -1
    if (y === undefined) return 1
    const nx = /^\d+$/.test(x)
    const ny = /^\d+$/.test(y)
    if (nx && ny) {
      if (Number(x) !== Number(y)) return Number(x) < Number(y) ? -1 : 1
      continue
    }
    if (nx !== ny) return nx ? -1 : 1
    if (x !== y) return x < y ? -1 : 1
  }
  return 0
}
function compare(a, b) {
  for (let i = 0; i < 3; i += 1) {
    if (a.nums[i] !== b.nums[i]) return a.nums[i] < b.nums[i] ? -1 : 1
  }
  if (a.pre.length === 0 && b.pre.length === 0) return 0
  if (a.pre.length === 0) return 1
  if (b.pre.length === 0) return -1
  return cmpPre(a.pre, b.pre)
}
/** npm semver 预发布可见性规则：预发布版本只被「区间内含同 [M,m,p] 元组预发布」的区间满足。 */
function preReleaseVisible(version, comparators) {
  if (version.pre.length === 0) return true
  return comparators.some((c) => {
    const mv = parseVersion(c.version)
    return mv.nums[0] === version.nums[0] && mv.nums[1] === version.nums[1] && mv.nums[2] === version.nums[2] && mv.pre.length > 0
  })
}
function satisfies(version, rng) {
  const v = parseVersion(version)
  for (const group of String(rng).split('||')) {
    const parts = group.trim().split(/\s+/).filter(Boolean)
    const comparators = []
    let groupOk = true
    for (const part of parts) {
      const m = /^(>=|<=|>|<|=)?\s*(.+)$/.exec(part)
      const op = m[1] || '='
      comparators.push({ op, version: m[2] })
      const c = compare(v, parseVersion(m[2]))
      if (op === '>=' && c < 0) groupOk = false
      else if (op === '<=' && c > 0) groupOk = false
      else if (op === '>' && c <= 0) groupOk = false
      else if (op === '<' && c >= 0) groupOk = false
      else if (op === '=' && c !== 0) groupOk = false
    }
    if (groupOk && preReleaseVisible(v, comparators)) return true
  }
  return false
}

const TABLE = [
  ['0.1.2-alpha.3', true],
  ['0.1.2-rc.1', true],
  ['0.1.5-alpha.1', true],
  ['0.1.5-alpha.2', true],
  ['0.1.5-rc.1', true],
  ['0.1.5', true],
  ['0.1.6', true],
  ['0.1.7-alpha.0', true],
  ['0.1.7-rc.1', true],
  ['0.1.7-rc.2', true],
  ['0.1.3-alpha.1', false],
  ['0.1.4', true],
  // 0.2.0 适配轮（2026-09-29）：宿主实测 0.2.0-rc.1，新区间必须放行 0.2.x 全系。
  // 上一轮这里断言 0.2.0 === false（当时未验证，故意拦住），本轮已验证 → 有意翻转。
  ['0.2.0-alpha.0', true],
  ['0.2.0-rc.1', true],
  ['0.2.0', true],
  ['0.2.3', true],
  // 0.2.1 适配轮（2026-10-18）：宿主实测 0.2.1-rc.2（settleRun 与 subagents.start
  // 双双移除，见 test/review-run-contract.test.mjs）→ 必须显式放行 0.2.1 预发布。
  // 严格模式下 0.2.1-rc.2 不被 `>=0.2.0-alpha.0 <0.3.0` 覆盖（区间内无同元组预发布），
  // 故新增的 0.2.1 段非冗余声明。
  ['0.2.1-alpha.0', true],
  ['0.2.1-rc.2', true],
  ['0.2.1', true],
  // 0.2.2 适配轮（2026-11-06）：宿主实测 0.2.2-rc.1（LlmAdapter / SubagentRuntime 方法面
  // 与 0.2.1-rc.2 逐字一致，零改码）→ 同样必须显式放行 0.2.2 预发布：
  // 严格模式下 0.2.2-rc.1 不被前五段覆盖（无同元组预发布），故 0.2.2 段非冗余。
  ['0.2.2-alpha.0', true],
  ['0.2.2-rc.1', true],
  ['0.2.2', true],
  ['0.2.9', true],
  ['0.1.8', false],
  ['0.3.0', false],
  ['0.0.1', false]
]
for (const [version, expected] of TABLE) {
  assert.equal(satisfies(version, range), expected, 'engines 区间对 ' + version + ' 的判定应为 ' + expected + '（区间=' + range + '）')
}
ok('engines 判定表 ' + TABLE.length + ' 行逐行通过（含 0.1.5-rc.1 / 0.1.7-rc.2 / 0.2.0 / 0.2.1 / 0.2.2 覆盖，0.1.8 与 0.3.0 排除）')

// 反证：旧单区间不覆盖预发布 —— 这正是必须加析取的原因
assert.equal(satisfies('0.1.5-rc.1', '>=0.1.2-alpha.3 <0.2.0'), false, '旧单区间本不应覆盖 0.1.5-rc.1，判定器写反了')
assert.equal(satisfies('0.1.7-rc.2', '>=0.1.2-alpha.3 <0.2.0'), false, '旧单区间本不应覆盖 0.1.7-rc.2，判定器写反了')
ok('反证：旧单区间不覆盖 0.1.5-rc.1 / 0.1.7-rc.2（故必须加析取，非冗余声明）')

// 反证：0.2.0 适配轮——旧三段区间不覆盖 0.2.0-rc.1，故新段非冗余。
// 真机证据：未加新段时宿主启动闸打印 `skipping profile bundle "dsh-skill-curator"`，
// 整个 bundle 不加载。
const OLD_THREE_CLAUSE = '>=0.1.2-alpha.3 <0.1.8 || >=0.1.5-alpha.1 <0.1.6 || >=0.1.7-alpha.0 <0.1.8'
assert.equal(satisfies('0.2.0-rc.1', OLD_THREE_CLAUSE), false, '旧三段区间本不应覆盖 0.2.0-rc.1，判定器写反了')
assert.equal(satisfies('0.2.0-rc.1', range), true, '新区间必须覆盖 0.2.0-rc.1')
ok('反证：旧三段区间不覆盖 0.2.0-rc.1（故新段非冗余声明）')

// 反证：0.2.1 适配轮——旧四段区间在**严格模式**下不覆盖 0.2.1-rc.2，故 0.2.1 段非冗余。
// 根因是 npm 预发布可见性规则：`>=0.2.0-alpha.0 <0.3.0` 里带预发布的比较器只有 0.2.0-alpha.0
// （元组 0.2.0），而 0.2.1-rc.2 的元组是 0.2.1 → 无同元组预发布 → 严格模式判 false。
// 真机证据：不补该段时宿主启动闸会跳过整个 bundle（`skipping profile bundle`）。
const OLD_FOUR_CLAUSE = OLD_THREE_CLAUSE + ' || >=0.2.0-alpha.0 <0.3.0'
assert.equal(satisfies('0.2.1-rc.2', OLD_FOUR_CLAUSE), false, '旧四段区间本不应覆盖 0.2.1-rc.2，判定器写反了')
assert.equal(satisfies('0.2.1-rc.2', range), true, '新区间必须覆盖 0.2.1-rc.2')
ok('反证：旧四段区间不覆盖 0.2.1-rc.2（故 0.2.1 段非冗余声明）')

// 反证：0.2.2 适配轮——旧五段区间在**严格模式**下不覆盖 0.2.2-rc.1，故 0.2.2 段非冗余。
// 同一条预发布可见性规则：前五段里带预发布的比较器元组最高到 0.2.1，
// 而 0.2.2-rc.1 的元组是 0.2.2 → 无同元组预发布 → 严格模式判 false（pnpm 安装期会拒）。
const OLD_FIVE_CLAUSE = OLD_FOUR_CLAUSE + ' || >=0.2.1-alpha.0 <0.3.0'
assert.equal(satisfies('0.2.2-rc.1', OLD_FIVE_CLAUSE), false, '旧五段区间本不应覆盖 0.2.2-rc.1，判定器写反了')
assert.equal(satisfies('0.2.2-rc.1', range), true, '新区间必须覆盖 0.2.2-rc.1')
ok('反证：旧五段区间不覆盖 0.2.2-rc.1（故 0.2.2 段非冗余声明）')

// 交叉验证：同一判定表与宿主真实 semver 逐行一致（宿主不可解析则显式跳过，不假绿）
// 解析路径按实测顺序（本仓 pnpm 布局）：semver 是 @deepseek-ai/dsh 的依赖，落点是
// `node_modules/.pnpm/semver@<ver>/node_modules/semver`（顶层无裸 semver），
// 因此除裸名外还扫 .pnpm 目录——版本号不写死，避免升级后静默跳过交叉验证。
const req = createRequire(import.meta.url)
function loadHostSemver() {
  for (const candidate of ['semver', '@deepseek-ai/dsh/node_modules/semver']) {
    try { return req(candidate) } catch { /* next */ }
  }
  try {
    const pnpmDir = join(root, 'node_modules', '.pnpm')
    for (const entry of readdirSync(pnpmDir)) {
      if (!entry.startsWith('semver@')) continue
      try { return req(join(pnpmDir, entry, 'node_modules', 'semver')) } catch { /* next */ }
    }
  } catch { /* .pnpm absent */ }
  return null
}
const semver = loadHostSemver()
if (semver && typeof semver.satisfies === 'function') {
  // 两种模式都要对：严格模式（pnpm 安装期）与宿主闸模式（includePrerelease，决定能否加载）。
  for (const [version, expected] of TABLE) {
    assert.equal(semver.satisfies(version, range), expected, '宿主 semver（严格模式）对 ' + version + ' 的判定与内置判定表不一致')
  }
  ok('内置判定器与宿主真实 semver.satisfies 逐行一致（' + TABLE.length + '/' + TABLE.length + '）')
} else {
  ok('宿主 semver 不可解析，跳过交叉验证（不假绿）')
}

// 0.1.7 起 dsh-* 一律走 peerDependencies（宿主运行时是唯一事实来源，插件不再各自
// 装一份 @deepseek-ai/dsh-* 实体副本——两份副本会让 defineTool/schemastery 身份分裂）。
// devDependencies 里保留一份「源码级契约副本」，只为本地跑测试时能解析到真模块。
const PEER = ['@deepseek-ai/dsh-llm', '@deepseek-ai/dsh-settings', '@deepseek-ai/dsh-subagent', '@deepseek-ai/dsh-tools']
assert.equal(pkg.dependencies, undefined, 'runtime dependencies 必须为空（dsh-* 全部走 peerDependencies）')
for (const dep of PEER) {
  const spec = (pkg.peerDependencies || {})[dep]
  assert.equal(typeof spec, 'string', dep + ' 必须在 peerDependencies 里声明')
  assert.ok(satisfies(pkg.version, spec), dep + ' 的 peer 区间必须覆盖当前版本 ' + pkg.version + '（区间=' + spec + '）')
  assert.equal(typeof (pkg.devDependencies || {})[dep], 'string', dep + ' 需要 devDependencies 副本供本地测试解析')
  // 兼容闸（dsh-app-boot 的 evaluatePluginCompatibility）**只**遍历 peerDependencies 里
  // @deepseek-ai/dsh* 的条目，**从不读 dsh.engines.dsh**（全树 grep 零消费者）。
  // 因此 peer 才是决定插件生死的声明；engines 只影响 pnpm 安装期。两者必须逐字一致。
  assert.equal(spec, pkg.dsh.engines.dsh, dep + ' 的 peer 区间必须与 dsh.engines.dsh 逐字一致（闸只认 peer）')
}
ok('4 个 @deepseek-ai/dsh-* 依赖面 = peer（区间覆盖 ' + pkg.version + '，且与 engines 逐字一致）+ dev 副本，runtime dependencies 为空')

// ---------------------------------------------------------------------------
// 4. 宿主服务名真实存在（顶层 inject 写错名 = 插件永远 pending，且完全静默）
// ---------------------------------------------------------------------------
// 宿主包从 devDependencies 解析（真实 0.2.2-rc.1 夹具），不再写死 Linux 绝对路径——
// 写死路径在 Windows 上永远不存在，这条守护此前一直「跳过」= 假绿（2026-11-06 修）。
const serviceOwners = {
  settings: '@deepseek-ai/dsh-settings',
  tools: '@deepseek-ai/dsh-tools'
}
let hostChecked = 0
for (const svc of mod.inject) {
  const pkgName = serviceOwners[svc]
  assert.ok(pkgName, 'inject 声明了未知服务名：' + svc)
  let src
  try { src = readFileSync(req.resolve(pkgName), 'utf8') } catch { continue }
  // 变量名不可写死：0.2.2-rc.1 的 settings 服务是 super(ownerContext, "settings")，
  // 旧断言找 super(ctx, "settings") 会假红。只认「某个上下文变量 + 服务名」这个形状。
  assert.match(
    src,
    new RegExp('super\\([A-Za-z_$][\\w$]*,\\s*"' + svc + '"\\)'),
    '宿主源码里找不到服务 "' + svc + '" 的注册点（文件名或服务名漂移）'
  )
  hostChecked += 1
}
assert.equal(hostChecked, mod.inject.length, '宿主包不可解析，服务名核验未真正执行（不静默跳过）')
ok('顶层 inject 的 ' + hostChecked + ' 个服务名均在宿主真实源码中找到注册点')

// ---------------------------------------------------------------------------
// 5. 键集合一致性（host Config ↔ client FIELDS 逐键相等）
//    不等 = 「设置页调不到该开关」且完全静默（dsh-plugin-audit 第八路盲区）。
// ---------------------------------------------------------------------------
const hostSrc = readFileSync(join(root, 'src', 'settings.js'), 'utf8')
const clientSrc = readFileSync(join(root, 'lib', 'client.js'), 'utf8')
const configBlock = /export const Config = z\.object\(\{([\s\S]*?)\n\}\)/.exec(hostSrc)
assert.ok(configBlock, 'src/settings.js 里找不到 Config schema（键集合守卫失效）')
const hostKeys = [...configBlock[1].matchAll(/^\s{2}([A-Za-z_][\w]*):/gm)].map((m) => m[1]).sort()
const fieldsBlock = /const FIELDS = \[([\s\S]*?)\n    \]/.exec(clientSrc)
assert.ok(fieldsBlock, 'lib/client.js 里找不到 FIELDS（键集合守卫失效）')
const clientKeys = [...fieldsBlock[1].matchAll(/key: "([^"]+)"/g)].map((m) => m[1]).sort()
assert.deepEqual(clientKeys, hostKeys, 'client FIELDS 键集合必须与 host Config 键集合逐键相等（缺一键 = 设置页调不到该开关）')
assert.equal(hostKeys.length, 16, 'host Config 键数为 16（漂移则同步本断言与文档）')
// 0.1.7 热编辑的前提：每个可编辑字段都必须 .volatile()（非 volatile = 改一次重启一次 fiber）
const volatileCount = (configBlock[1].match(/\.volatile\(\)/g) || []).length
assert.equal(volatileCount, hostKeys.length, 'host Config 全部字段都必须 .volatile()（' + volatileCount + '/' + hostKeys.length + '）')
// 枚举字面量三处一致：host schema default / client 分段按钮选项 / 展示文案
for (const literal of ['off', 'on', 'verbose']) {
  assert.ok(hostSrc.includes("'" + literal + "'"), 'host schema 缺 notifyMode 字面量 ' + literal)
  assert.ok(clientSrc.includes('"' + literal + '"'), 'client 缺 notifyMode 字面量 ' + literal)
}
ok('键集合逐键相等（host Config ↔ client FIELDS，共 ' + hostKeys.length + ' 键）+ notifyMode 枚举三字面量一致')

// ---------------------------------------------------------------------------
// 5b. FIELDS ⊆ GROUPS（集合覆盖守护）
//     面板只渲染 GROUPS 里列出的键 —— 一个字段进了 FIELDS 却漏进 GROUPS 的
//     keys，就等于「设置页里静默消失」：键集合守卫（上面那条）照样全绿，
//     因为两边 FIELDS/Config 都有它。实测把 group.base 的 "notifyMode" 去掉，
//     全套 client-smoke 8/8 依然绿。
// ---------------------------------------------------------------------------
const groupsBlock = /const GROUPS = \[([\s\S]*?)\n    \]/.exec(clientSrc)
assert.ok(groupsBlock, 'lib/client.js 里找不到 GROUPS（覆盖守卫失效）')
const groupedKeys = new Set([...groupsBlock[1].matchAll(/keys: \[([^\]]*)\]/g)]
  .flatMap((m) => [...m[1].matchAll(/"([^"]+)"/g)].map((k) => k[1])))
const ungrouped = clientKeys.filter((k) => !groupedKeys.has(k))
assert.deepEqual(
  ungrouped,
  [],
  'FIELDS 里每个键都必须出现在某个 GROUPS.keys 里（漏掉 = 设置页静默少一个开关）：' + ungrouped.join(', ')
)
// 反向也守：GROUPS 引用的键必须在 FIELDS 里，否则渲染期 FIELDS.find() 返回
// undefined → spec.type 直接 TypeError 崩掉整张卡片。
const phantom = [...groupedKeys].filter((k) => !clientKeys.includes(k))
assert.deepEqual(phantom, [], 'GROUPS 引用了 FIELDS 里不存在的键（渲染期会 TypeError）：' + phantom.join(', '))
ok('FIELDS ⊆ GROUPS.keys 且 GROUPS.keys ⊆ FIELDS（共 ' + clientKeys.length + ' 键全覆盖）')

// ---------------------------------------------------------------------------
// 6. 依赖卫生（家族硬要求：无安装脚本副作用 / 无原生编译 / 仅 @deepseek-ai 系）
// ---------------------------------------------------------------------------
const scripts = pkg.scripts || {}
for (const key of ['preinstall', 'install', 'postinstall', 'prepare', 'prepublishOnly']) {
  assert.equal(scripts[key], undefined, '包内不得声明安装类脚本副作用：' + key)
}
assert.equal(pkg.optionalDependencies, undefined, '不得声明 optionalDependencies')
for (const dep of Object.keys(pkg.peerDependencies || {})) {
  assert.ok(dep.startsWith('@deepseek-ai/'), 'peerDependencies 只允许 @deepseek-ai/* 系列（零 gyp 风险）：' + dep)
}
for (const dep of Object.keys(pkg.devDependencies || {})) {
  assert.ok(dep.startsWith('@deepseek-ai/'), 'devDependencies 只允许 @deepseek-ai/* 系列：' + dep)
}
// 不装 @deepseek-ai/dsh 伞包：它会把整棵宿主依赖树（数百包）拖进插件仓，
// 并往 pnpm-workspace.yaml 写一串 "set this to true or false" 噪声。源码里没有任何 import 用到它。
assert.equal((pkg.devDependencies || {})['@deepseek-ai/dsh'], undefined, 'devDependencies 不得声明 @deepseek-ai/dsh 伞包')
ok('依赖卫生：无安装脚本、无 optionalDependencies、依赖面仅 @deepseek-ai/*')

console.log('\nentry OK: ' + PASS.length + ' 组守护通过（判定表 ' + TABLE.length + ' 行交叉验证）')