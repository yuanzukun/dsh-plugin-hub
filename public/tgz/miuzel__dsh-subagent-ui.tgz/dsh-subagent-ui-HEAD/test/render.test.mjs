// Renders the REAL manager component and asserts on the produced element tree:
// the external row is visible and typed, its status is only ever the measured
// one, and the session-derived surfaces (live output, prompt, usage, continue,
// sidebar) are absent or unchanged for it.
//
// Run it with `pnpm run test`. The bundle is loaded from the repository this
// file lives in, not from the process CWD, so the harness runs from anywhere.
import assert from 'node:assert'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'

const CLIENT_BUNDLE = fileURLToPath(new URL('../lib/client.js', import.meta.url))

globalThis.document = { querySelector: () => true, getElementById: () => null, createElement: () => ({ dataset: {}, style: {}, remove() {} }), head: { appendChild() {} } }
// A real, inspectable preferences store: the deletion memory lives here (same
// key the plugin uses for `archived`), so a mount/refresh sees what a delete wrote.
let storedPrefs = null
globalThis.localStorage = { getItem: () => storedPrefs, setItem: (k, v) => { storedPrefs = v } }
globalThis.window = { confirm: () => true, alert: () => {}, prompt: () => null, innerWidth: 1200, innerHeight: 800 }
let ledgerPayload = { ok: true, active: [], ended: [] }
// The live-binding face the prompt-preview attach reads (`sessionsRt.binding`).
// Mutable so the prompt section can hand it one child session's feed.
let promptBindingFor = () => null
globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ledgerPayload })

let viewDebug = process.env.DEBUG_VIEW === '1'
let cursor = 0
let cells = {}
let childCells = new Map()
let openOnce = false
const setters = []
const effects = []
// The factory body reads `document` as a free variable (the loader supplies its
// globals that way), so the harness — which kept it only as `window.document` —
// gives every boot the same stub in the module scope too.
globalThis.window.document = globalThis.document
const React = {
  useState: initial => {
    const index = cursor++
    if (!(index in cells)) { const base = typeof initial === 'function' ? initial() : initial; const forced = openOnce && depth === 0 && index === 0 ? true : base; cells[index] = forced }
    const set = next => { cells[index] = typeof next === 'function' ? next(cells[index]) : next; if (depth === 0) pendingCommit = true }
    setters[index] = set
    return [cells[index], set]
  },
  useMemo: f => f(),
  useDeferredValue: v => v,
  useEffect: f => { effects.push(f) },
  useRef: v => ({ current: v }),
  Fragment: 'frag',
}
// Function components are the plugin's own bodies; invoke them so the tree is
// real rather than a description of them.
let depth = 0
const renderChild = (type, props) => {
  if (typeof type !== 'function') return { tag: type, props: props || {} }
  // A child's hooks are its own: give it a fresh slot cursor, then restore.
  const savedCursor = cursor, savedCells = cells
  cursor = 0
  cells = childCells.get(type) || {}
  childCells.set(type, cells)
  depth += 1
  try {
    const out = type(props || {})
    return out === null || out === undefined ? { tag: 'frag', props: { children: null } } : out
  } finally {
    depth -= 1
    cursor = savedCursor
    cells = savedCells
  }
}
// The scope helpers are read out of the same factory so the harness can also
// mount the active float, whose rows are the manager's own row objects.
const src = readFileSync(CLIENT_BUNDLE, 'utf8')
// The same bundle DECODED (the loader wraps the built modules in one factory
// whose body is plain JS), used only to build a CONTROL copy of the code as it
// was before this attempt — see (b) below. Nothing here runs the decoded source
// directly; the control is re-wrapped into a loader module and booted normally.
const libSrc = (() => {
  const before = globalThis.window.__ModuleLoader__
  let factoryFn = null
  globalThis.window.__ModuleLoader__ = { load: ({ factory }) => { factoryFn = factory } }
  try {
    new Function('window', src)(globalThis.window)
  } finally {
    globalThis.window.__ModuleLoader__ = before
  }
  const text = factoryFn && Function.prototype.toString.call(factoryFn)
  if (!text) throw new Error('the bundle factory could not be decoded')
  // `toString()` of an arrow factory is `(require) => { ... }`: take the BODY
  // (outer braces), then drop the wrapper's OWN `return` of the module exports,
  // so the text can be re-wrapped as `(require) => { <body> }` verbatim.
  const body = text.slice(text.indexOf('{') + 1, text.lastIndexOf('}'))
  const exportsReturn = body.lastIndexOf("    return {inject:['sessions','slots','locale'],apply}")
  if (exportsReturn < 0) throw new Error('the decoded bundle has no module-exports return to strip')
  return body.slice(0, exportsReturn) + 'return ' + body.slice(exportsReturn).replace(/^\s+return /, '')
})()
const footer = "    return {inject:['sessions','slots','locale'],apply}"
const scopeSrc = src.replace(footer, `${footer.slice(0, -1)}, ActiveFloat, catalogEntriesOf, modeMap, childModeOf, externalRowsOf, deletedExternalOf, EXTERNAL_REMOVED_LIMIT, externalRemovedCap, externalRemovedAdd, sessionEntitiesOf, absentRowOf, promptPreviewAttach, promptApplyState, promptApplyTrigger, promptSetMode, promptRefreshKey, promptPreviewRefresh, promptDefaultModeOf, promptSetDefaultMode, promptMode, PROMPT_MODE_RAW, PROMPT_MODE_RENDERED, PROMPT_BLOCK_ATTR, PROMPT_TRIGGER_ATTR, PROMPT_HIDE_CLASS, PROMPT_TRIGGER_ON_CLASS}`)
let api = null
// The loader the SHIPPED copy was booted through; every control boot replaces
// `window.__ModuleLoader__`, so each control restores this one afterwards.
const shippedLoader = { load: ({ factory }) => { api = factory(id => id === 'react' ? React : { jsx: (t, p) => renderChild(t, p), jsxs: (t, p) => renderChild(t, p) }) } }
globalThis.window.__ModuleLoader__ = shippedLoader
new Function('window', scopeSrc)(globalThis.window)

const dicts = {}
const registrations = []
let state = { byId: {}, current: 'p1' }
const shippedApi = api
api.apply({
  sessions: { list: { getSnapshot: () => ({ byId: state.byId, current: state.current }) }, binding: id => promptBindingFor(id) },
  effect: fn => { try { fn() } catch {} },
  locale: { register: (ns, d) => { dicts[ns] = d } },
  slots: { inject: (slot, f) => { f() }, register: (config, component) => { registrations.push({ config, component }) } },
  get: () => undefined,
})
// Boot a copy of the bundle from its DECODED source, the way the first copy was
// booted (loader shell -> factory -> apply on a fake sessions runtime). Used by
// the negative control, which must run different SOURCE rather than a replaced
// binding: the linker links every module into one scope, so the manager reads
// the module-local `absentRowOf` and an export override on the live copy never
// reaches it (measured; a stubbed control would prove nothing).
function bootBundle(source, options) {
  let runnerApi = null
  // The loader is a free variable inside the wrapper module, not a property of
  // `window` in this harness; passing it in makes the control copy independent
  // of whatever the first boot left on `window`.
  const loader = { load: ({ factory }) => { runnerApi = factory(id => id === 'react' ? React : { jsx: (t, p) => renderChild(t, p), jsxs: (t, p) => renderChild(t, p) }) } }
  globalThis.window.__ModuleLoader__ = loader
  try {
    new Function('window', '__ModuleLoader__', `return function () { __ModuleLoader__.load({ factory: (require) => {${source}} }) }`)(globalThis.window, loader)()
  } catch (error) {
    throw new Error('control bundle: ' + (error && error.message) + '\n' + String((error && error.stack) || '').split('\n').slice(0, 6).join('\n'))
  }
  if (!runnerApi) throw new Error('control bundle did not call the loader')
  assert.ok(runnerApi, 'the control bundle booted')
  const controlDicts = {}
  const controlRegistrations = []
  runnerApi.__registrations = controlRegistrations
  runnerApi.apply({
    sessions: { list: { getSnapshot: () => ({ byId: state.byId, current: state.current }) }, binding: id => promptBindingFor(id) },
    effect: fn => { try { fn() } catch {} },
    locale: { register: (ns, d) => { controlDicts[ns] = d } },
    slots: { inject: (slot, f) => { f() }, register: (config, component) => { controlRegistrations.push({ config, component }) } },
    get: () => undefined,
  })
  // The control is mounted into the SAME harness component pool, so it can be
  // rendered through the same `commit`/`render` path as the shipped copy.
  const controlManager = runnerApi.__registrations.find((r) => r.config.id === 'subagent-workspace-manager').component
  return { api: runnerApi, dicts: controlDicts, manager: controlManager }
}
const zoomForbidden = null
const zh = dicts['subagent-workspace-ui'].zh
const en = dicts['subagent-workspace-ui'].en
const manager = registrations.find(r => r.config.id === 'subagent-workspace-manager')
assert.ok(manager, 'manager registered')
assert.deepStrictEqual(Object.keys(zh), Object.keys(dicts['subagent-workspace-ui'].en), 'zh/en key order parity')

function render(next, options, fresh) {
  state = next
  cursor = 0
  // React keeps hook state across re-renders; only a new mount starts empty.
  if (fresh) { cells = {}; childCells = new Map() }
  openOnce = Boolean(options && options.open)
  setters.length = 0
  effects.length = 0
  const t = (key, params) => {
    const template = zh[key] !== undefined ? zh[key] : `<${key}>`
    return params ? template.replace(/\{(\w+)\}/g, (_, name) => String(params[name] === undefined ? `{${name}}` : params[name])) : template
  }
  const { open, ...props } = options || {}
  const elementResult = manager.component({ t, useSessions: sel => sel(state), openChild: () => true, openSession: () => true, refresh: () => {}, setCatalogOpen: () => {}, sessionId: 'p1', actions: {}, ...props })
  return collect(elementResult)
}
// One commit + effects + the re-render the effects may have caused.
let pendingCommit = false
let commitOptions = null
let commitState = null
// One full commit: render, run the effects that commit queued, and render once
// more when an effect set component state (the poller's first response does).
async function commit(next, options, fresh) {
  pendingCommit = false
  const first = render(next, options, fresh)
  runEffects()
  // The poller's first response lands on a microtask; let it, then re-render.
  await new Promise(resolve => setTimeout(resolve, 5))
  return pendingCommit ? render(next, options, false) : first
}
// Child components set state too; only the top-level cursor marks a commit.

// Effects run after the tree is committed, exactly like React; a poller that
// sets state on the first pass then needs one more render to show it.
function runEffects() {
  for (const effect of effects.splice(0)) { try { effect() } catch (error) { throw new Error('effect threw: ' + error.message) } }
}
function collect(element) {
  const out = { nodes: [], text: [] }
  const walk = value => {
    if (value === null || value === undefined || value === false || value === true) return
    if (typeof value === 'string' || typeof value === 'number') { out.text.push(String(value)); return }
    if (Array.isArray(value)) { value.forEach(walk); return }
    if (typeof value !== 'object') return
    const props = value.props || value.p || {}
    const tag = value.tag !== undefined ? value.tag : value.t
    if (tag === 'frag') { walk(props.children); return }
    out.nodes.push({ tag, props })
    walk(props.children)
  }
  walk(element)
  return out
}
const results = {}
const parent = { id: 'p1', origin: 'user', title: 'Parent', cwd: '/work', updatedAt: Date.now() }
const local = { id: 'session-c1', parentId: 'p1', origin: 'subagent', title: 'local child', cwd: '/work', updatedAt: Date.now(), running: true }
const ext = { id: 'da45e0aa-1111-4222-8333-444455556666', parentId: 'p1', origin: 'subagent', title: 'external child', cwd: '/work', updatedAt: Date.now() - 5000, running: false }
const catalog = [
  { id: 'session-c1', mode: 'continuable', label: 'local child' },
  { id: ext.id, mode: 'external', label: 'claude task' },
]
const stateFor = () => ({ byId: { p1: parent, 'session-c1': local, [ext.id]: ext }, current: 'p1', projectionsBySession: { p1: { values: { subagentCatalog: catalog } } } })

// The trigger button opens the panel through its own state setter.
const clickTrigger = collected => {
  const trigger = collected.nodes.find(n => n.tag === 'button' && typeof (n.props || {}).onClick === 'function' && String((n.props || {}).className || '') === 'dsh-sam-trigger')
  assert.ok(trigger, 'trigger rendered: ' + JSON.stringify(collected.nodes.filter(n => n.tag === 'button').map(n => String((n.props || {}).className || ''))))
  trigger.props.onClick()
}

// 1. closed -> open, then the external row is visible with its family + engine badge.
let view = await commit(stateFor())
clickTrigger(view)
view = await commit(stateFor(), { open: true })
assert.ok(view.nodes.some(n => (n.props || {}).className === 'dsh-sam-panel'), 'panel open: ' + JSON.stringify(view.nodes.slice(0, 8).map(n => String((n.props || {}).className || n.tag))))
const text = view.text.join(' ')
assert.ok(text.includes('外部代理'), 'family label visible')
assert.ok(text.includes('状态不可得'), 'no edge => status unavailable')
assert.ok(!text.includes('已结束'), 'unavailable is not rendered as ended')
results.visible = { family: text.includes('外部代理'), unavailable: text.includes('状态不可得') }

// 2. a measured running edge: engine shown, stop offered, no continue/sidebar.
ledgerPayload = { ok: true, active: [{ runId: 'run-1', id: ext.id, provider: 'claude-code', parentId: 'p1', seq: 1, startedAt: Date.now() }], ended: [] }
view = await commit(stateFor(), { open: true, asideAddressOf: () => 'dsh-resource://subagentchat/session/x?parent=p1&mode=continuable', openAside: () => true })
const runningText = view.text.join(' ')
assert.ok(runningText.includes('运行中 · Claude Code'), 'running + engine; text=' + runningText.slice(0, 400))
const extRowIndex = view.nodes.findIndex(n => typeof (n.props||{}).className === 'string' && n.props.className.includes('dsh-sam-row-ext'))
assert.ok(extRowIndex >= 0, 'external row marked')
const buttons = view.nodes.filter(n => n.tag === 'button')
assert.ok(buttons.some(b => String((b.props||{}).children).includes('⏹ 停止')), 'stop offered while running')
assert.ok(!buttons.some(b => String((b.props||{}).title || '').includes('外部代理') && String((b.props||{}).className || '').includes('continue')), 'no continue button for external')
results.running = { text: 'running+engine', stop: true }

// 3. ended edge: stop withdrawn, reason + duration shown from the payload.
ledgerPayload = { ok: true, active: [], ended: [{ runId: 'run-1', id: ext.id, provider: 'claude-code', parentId: 'p1', seq: 1, startedAt: 1000, endedAt: 5000, stopReason: 'aborted', paired: true, durationMs: 4000 }] }
view = await commit(stateFor(), { open: true })
const endedText = view.text.join(' ')
assert.ok(endedText.includes('已结束（已中止 · 4 秒）'), 'ended detail rendered')
assert.ok(!view.nodes.filter(n => n.tag === 'button').some(b => String((b.props||{}).children).includes('⏹ 停止')), 'stop withdrawn after the end')
results.ended = 'reason+duration, no stop'

// 4. only a provider the host knows: the id is shown verbatim, never mapped.
ledgerPayload = { ok: true, active: [{ runId: 'run-2', id: ext.id, provider: 'my-proxy', parentId: 'p1', seq: 2 }], ended: [] }
view = await commit(stateFor(), { open: true })
assert.ok(view.text.join(' ').includes('运行中 · my-proxy'), 'unknown provider shown verbatim')
results.verbatim = 'my-proxy'

// 5. a local continuation row is untouched: continue + sidebar still render,
//    and the external row never borrows them.
ledgerPayload = { ok: true, active: [], ended: [] }
const localChild = { ...local, running: false }
const stateLocal = { byId: { p1: parent, 'session-c1': localChild, [ext.id]: ext }, current: 'p1', projectionsBySession: { p1: { values: { subagentCatalog: catalog } } } }
view = await commit(stateLocal, { open: true, asideAddressOf: () => 'dsh-resource://subagentchat/session/x?parent=p1&mode=continuable', openAside: () => true })
const sidebarButtons = view.nodes.filter(n => n.tag === 'button' && String((n.props||{}).children) === '◫')
assert.strictEqual(sidebarButtons.length, 1, 'sidebar button only on the local row')
results.localUntouched = { sidebarButtons: sidebarButtons.length }

// 6. THE REAL HOST SHAPE: an external execution has NO Session at all. The
//    parent's catalog lists it, `byId` does not, and the ledger reports it
//    running. Before the row-synthesis fix this produced an empty panel and a
//    `0/0` header; these assertions are the regression guard for that.
const extOnly = { id: '3902fbda-97a6-4c1e-9a1b-000000000001', parentId: 'p1' }
// Byte-faithful to the host's own projection (`subagentCatalogEntries`):
// `{ id, createdAt, mode, label }` and NO parentId — the parent is the owner of
// the projection, never a field on the entry. This is exactly what
// `establishExternalCatalogChild` appends for a real codex delegation.
const catalogOnly = [
  { id: 'session-c1', createdAt: 1000, mode: 'continuable', label: 'local child' },
  { id: extOnly.id, createdAt: 2000, mode: 'external', label: 'codex task' },
]
const stateNoSession = () => ({ byId: { p1: parent, 'session-c1': { ...local, running: false } }, current: 'p1', projectionsBySession: { p1: { values: { subagentCatalog: catalogOnly } } } })
assert.ok(!stateNoSession().byId[extOnly.id], 'fixture: the external id has no Session, as on the real host')
ledgerPayload = { ok: true, active: [{ runId: 'run-9', id: extOnly.id, provider: 'codex', parentId: 'p1', seq: 9, startedAt: Date.now() }], ended: [] }
cells = {}; childCells = new Map()
let synthView = await commit(stateNoSession(), { open: true })
const synthText = synthView.text.join(' ')
assert.ok(!synthText.includes('没有符合条件的子代理'), 'panel is not empty for a session-less external run')
assert.ok(synthText.includes('codex task'), 'the catalog label names the row')
assert.ok(synthText.includes('运行中 · Codex'), 'running + engine for the synthesized row; text=' + synthText.slice(0, 300))
assert.ok(synthText.includes('外部代理'), 'family badge present')
const synthStop = synthView.nodes.filter(n => n.tag === 'button').some(b => String((b.props || {}).children).includes('⏹ 停止'))
assert.ok(synthStop, 'stop offered for the synthesized running row')
// Header counts: the closed-panel trigger reads 🧩 子代理 active/total.
const closed = await commit(stateNoSession(), { open: false })
const chip = closed.text.join(' ')
assert.ok(chip.includes('子代理 1/2'), 'header counts the external row as active and in total; chip=' + chip.slice(0, 80))
// After the end edge the same synthesized row reports ended, not running.
ledgerPayload = { ok: true, active: [], ended: [{ runId: 'run-9', id: extOnly.id, provider: 'codex', parentId: 'p1', seq: 9, startedAt: 1000, endedAt: 6500, stopReason: 'completed', paired: true, durationMs: 5500 }] }
synthView = await commit(stateNoSession(), { open: true })
const endedSynth = synthView.text.join(' ')
assert.ok(endedSynth.includes('已结束（正常完成 · 6 秒）'), 'ended after the terminal edge; text=' + endedSynth.slice(0, 300))
results.sessionlessExternal = { row: true, engine: 'Codex', stop: true, chip: 'active 1/2', ended: true }

// 7. A row in `byId` is NOT duplicated by the catalog entry for it.
const dupState = () => ({ byId: { p1: parent, 'session-c1': { ...local, running: false }, [ext.id]: ext }, current: 'p1', projectionsBySession: { p1: { values: { subagentCatalog: catalog } } } })
const dupView = await commit(dupState(), { open: true })
const rowIds = dupView.nodes.filter(n => typeof (n.props || {}).className === 'string' && n.props.className.split(' ').includes('dsh-sam-row')).map(n => n.props.className)
const titleNodes = dupView.nodes.filter(n => (n.props || {}).className === 'dsh-sam-session-id').map(n => String((n.props || {}).children))
const occurrences = titleNodes.filter(id => id === ext.id).length
assert.strictEqual(occurrences, 1, 'the external id appears once even though both a Session and a catalog entry exist; ids=' + JSON.stringify(titleNodes))
const ids = rowIds.length
results.noDuplicates = ids

// 8. A DELETED external child must not linger as a stub row. The host catalog is
//    append-only (no removal event exists) and an external child has no Session,
//    so the only fact that separates "deleted" from "running/ended/not yet
//    started" is the browser's own record of the completed deletion. This is the
//    regression guard for the reported bug: 3 catalog entries, 1 live child.
// The plugin's own helpers, read out of the factory it returned (the harness only
// widens the return object; the functions are the shipped ones).
const sessionEntitiesOf = api.sessionEntitiesOf, absentRowOfGate = api.absentRowOf
const externalRowsOf = api.externalRowsOf, deletedExternalOf = api.deletedExternalOf, EXTERNAL_REMOVED_LIMIT = api.EXTERNAL_REMOVED_LIMIT, externalRemovedCap = api.externalRemovedCap, externalRemovedAdd = api.externalRemovedAdd
assert.ok(typeof externalRowsOf === 'function' && typeof externalRemovedCap === 'function', 'plugin helpers exported for direct assertions')
const ROWS = view => view.nodes.filter(n => typeof (n.props || {}).className === 'string' && n.props.className.split(' ').includes('dsh-sam-row'))
const stubFixture = entries => ({
  byId: {
    p1: parent,
    alive: { id: 'alive', parentId: 'p1', origin: 'subagent', title: '活着的子代理', cwd: '/work', updatedAt: Date.now() },
  },
  current: 'p1',
  projectionsBySession: { p1: { values: { subagentCatalog: entries } } },
})
const threeEntries = [
  { id: 'alive', createdAt: 1, mode: 'continuable', label: '活着的子代理' },
  { id: 'deleted-ext-1', createdAt: 2, mode: 'external', label: '已删的外部代理1' },
  { id: 'deleted-ext-2', createdAt: 3, mode: 'external', label: '已删的外部代理2' },
]
// (a) NEGATIVE CONTROL, and the exact reported repro: with no deletion recorded
//     the two external entries still render (3 rows) — proving the assertions
//     below have teeth rather than passing on an already-broken fixture.
storedPrefs = null
cells = {}; childCells = new Map()
ledgerPayload = { ok: true, active: [], ended: [] }
let stubView = await commit(stubFixture(threeEntries), { open: true }, true)
assert.strictEqual(ROWS(stubView).length, 3, 'control: 3 undeleted-but-catalogued rows (1 local + 2 external) without any deletion record')
assert.ok(stubView.text.join(' ').includes('已删的外部代理1'), 'control: the deleted external entry renders while no deletion is recorded')
// (b) The fix: the same state, with those two ids recorded as deleted (what
//     deleteSubagent / batch-delete write on a successful host answer). The
//     count must drop to the ONE live child, exactly as on a page refresh.
storedPrefs = JSON.stringify({ removedExternal: ['deleted-ext-1', 'deleted-ext-2'] })
stubView = await commit(stubFixture(threeEntries), { open: true }, true)
const afterDeleteRows = ROWS(stubView)
const afterDeleteText = stubView.text.join(' ')
assert.strictEqual(afterDeleteRows.length, 1, 'only the live child renders; rows=' + afterDeleteRows.length)
assert.ok(afterDeleteText.includes('活着的子代理'), 'the undeleted local child still renders')
assert.ok(!afterDeleteText.includes('已删的外部代理1'), 'deleted external 1 is gone')
assert.ok(!afterDeleteText.includes('已删的外部代理2'), 'deleted external 2 is gone')
// The HEADER COUNTS (the closed-panel chip and the panel summary) are derived from
// the same rows, so a deleted child must not be counted either.
const closedAfterDelete = await commit(stubFixture(threeEntries), { open: false }, true)
const chipAfterDelete = closedAfterDelete.text.join(' ')
assert.ok(!chipAfterDelete.includes('0/3'), 'the header does not count the deleted external rows; chip=' + chipAfterDelete.slice(0, 60))
assert.ok(afterDeleteText.includes('当前会话 1 个'), 'the panel summary counts 1; text=' + afterDeleteText.slice(0, 200))
results.deletedExternal = { control: 3, afterDelete: afterDeleteRows.length, chip: true }
// (c) REVERSE CONSTRAINT — no false kill. A deletion record must never hide a
//     child that is (i) running right now (the id was re-delegated), (ii) ended
//     with a measured edge, or (iii) catalogued with no edge at all (running or
//     just started, which this page cannot see). Only (iv) really is deleted.
storedPrefs = null
cells = {}; childCells = new Map()
const fourExternal = [
  { id: 'ext-running', createdAt: 1, mode: 'external', label: '运行中的外部代理' },
  { id: 'ext-ended', createdAt: 2, mode: 'external', label: '已结束的外部代理' },
  { id: 'ext-quiet', createdAt: 3, mode: 'external', label: '刚启动的外部代理' },
  { id: 'ext-gone', createdAt: 4, mode: 'external', label: '真正删除的外部代理' },
]
ledgerPayload = {
  ok: true,
  active: [{ runId: 'r-run', id: 'ext-running', provider: 'codex', parentId: 'p1', seq: 1, startedAt: Date.now() }],
  ended: [{ runId: 'r-end', id: 'ext-ended', provider: 'claude-code', parentId: 'p1', seq: 2, startedAt: 1000, endedAt: 4000, stopReason: 'completed', paired: true, durationMs: 3000 }],
}
storedPrefs = JSON.stringify({ removedExternal: ['ext-gone'] })
stubView = await commit(stubFixture(fourExternal), { open: true }, true)
const reverseText = stubView.text.join(' ')
assert.ok(reverseText.includes('运行中的外部代理'), 'a running external run is still shown')
assert.ok(reverseText.includes('已结束的外部代理'), 'an ended external run is still shown')
assert.ok(reverseText.includes('刚启动的外部代理'), 'an external run with no measured edge is still shown')
assert.ok(!reverseText.includes('真正删除的外部代理'), 'the deleted external row is hidden')
// The running run also outranks a stale deletion record for the SAME id (a
// re-delegation reuses the catalog id), so deletion must never mask a live run.
ledgerPayload = { ok: true, active: [{ runId: 'r-gone', id: 'ext-gone', provider: 'codex', parentId: 'p1', seq: 3, startedAt: Date.now() }], ended: [] }
stubView = await commit(stubFixture(fourExternal), { open: true }, true)
assert.ok(stubView.text.join(' ').includes('真正删除的外部代理'), 'a recorded deletion never hides a currently RUNNING child of the same id')
// The predicate itself, unit-shaped: live/ended/unknown are all shown, and only
// the recorded-and-not-running id is hidden.
const shown = externalRowsOf(k => k, stubFixture(fourExternal), { 'ext-running': { status: 'running' }, 'ext-ended': { status: 'ended' }, 'ext-quiet': { status: 'unknown' } }, ['ext-running', 'ext-gone']).map(r => r.id)
assert.deepStrictEqual(shown.sort(), ['ext-ended', 'ext-quiet', 'ext-running'], 'only the recorded, non-running id is excluded (a recorded RUNNING id stays); got=' + JSON.stringify(shown))
assert.strictEqual(deletedExternalOf(['a'], { a: { status: 'running' } })('a'), false, 'running outranks a deletion record')
assert.strictEqual(deletedExternalOf(['a'], { a: { status: 'ended' } })('a'), true, 'an ended child with a deletion record is hidden')
assert.strictEqual(deletedExternalOf(undefined, undefined)('a'), false, 'no record => never hidden (and no crash)')
results.noFalseKill = { running: true, ended: true, quiet: true, runningBeatsRecord: true }
// (d) The memory is BOUNDED and self-cleaning: at most EXTERNAL_REMOVED_LIMIT
//     entries, newest kept, oldest evicted; adding is idempotent and moves the id
//     to the newest end; an id that has a Session again is dropped by the panel.
assert.ok(EXTERNAL_REMOVED_LIMIT > 0 && EXTERNAL_REMOVED_LIMIT <= 2000, 'a sane cap exists: ' + EXTERNAL_REMOVED_LIMIT)
const overfull = Array.from({ length: EXTERNAL_REMOVED_LIMIT + 25 }, (_, i) => `id-${i}`)
const capped = externalRemovedCap(overfull)
assert.strictEqual(capped.length, EXTERNAL_REMOVED_LIMIT, 'the list is capped at ' + EXTERNAL_REMOVED_LIMIT)
assert.strictEqual(capped[0], 'id-25', 'the oldest entries are the ones evicted')
assert.strictEqual(capped[capped.length - 1], 'id-' + (EXTERNAL_REMOVED_LIMIT + 24), 'the newest entry is kept')
const dedup = externalRemovedAdd(externalRemovedAdd(['a', 'b'], 'a'), 'a')
assert.deepStrictEqual(dedup, ['b', 'a'], 're-adding moves the id to the newest end instead of duplicating it')
assert.strictEqual(externalRemovedAdd(capped, 'fresh').length, EXTERNAL_REMOVED_LIMIT, 'adding to a full list still obeys the cap')
// Natural cleanup: once a recorded id has a Session again, a mount drops it.
storedPrefs = JSON.stringify({ removedExternal: ['deleted-ext-1', 'deleted-ext-2'] })
const revived = {
  ...stubFixture(threeEntries),
  byId: { ...stubFixture(threeEntries).byId, 'deleted-ext-1': { id: 'deleted-ext-1', parentId: 'p1', origin: 'subagent', title: '又活了的子代理', cwd: '/work', updatedAt: Date.now() } },
}
const pruned = await commit(revived, { open: true }, true)
assert.strictEqual(ROWS(pruned).length, 2, 'the revived id renders once (from byId), the still-deleted one stays hidden; rows=' + ROWS(pruned).length)
runEffects()
const persisted = JSON.parse(storedPrefs || '{}')
assert.deepStrictEqual(persisted.removedExternal, ['deleted-ext-2'], 'the record for an id that exists again was pruned; stored=' + storedPrefs)
// The explicit clear control: offered while a deletion is recorded, and clicking
// it empties the memory (the escape hatch for a wrong record).
storedPrefs = JSON.stringify({ removedExternal: ['deleted-ext-1', 'deleted-ext-2'], filterCollapsed: false })
const withMemory = await commit(stubFixture(threeEntries), { open: true }, true)
const clearBtn = withMemory.nodes.filter(n => n.tag === 'button' && typeof (n.props || {}).className === 'string' && (n.props || {}).className.includes('dsh-sam-clear-removed'))
assert.strictEqual(clearBtn.length, 1, 'a clear control is offered while deletions are recorded')
clearBtn[0].props.onClick()
// The click only queues the preference change; the commit effect is what writes
// localStorage, so one more commit (a re-render of the same mount) persists it.
await commit(stubFixture(threeEntries), { open: true })
assert.deepStrictEqual(JSON.parse(storedPrefs || '{}').removedExternal, [], 'the clear control empties the memory; stored=' + storedPrefs)
// With the memory cleared, the catalogued externals come back (honest: the host
// still lists them) — the control is reversible, not destructive.
const afterClear = await commit(stubFixture(threeEntries), { open: true }, true)
assert.strictEqual(ROWS(afterClear).length, 3, 'clearing the memory restores the catalogued rows')
results.bounded = { limit: EXTERNAL_REMOVED_LIMIT, dedup: true, pruned: true, cleared: true }
// (e) One-shot / continuable behavior is untouched: their rows come from `byId`
//     and a deletion record for a LOCAL id changes nothing about them.
storedPrefs = JSON.stringify({ removedExternal: ['session-c1'] })
cells = {}; childCells = new Map()
const localRecorded = await commit(stateLocal, { open: true, asideAddressOf: () => 'dsh-resource://subagentchat/session/x?parent=p1&mode=continuable', openAside: () => true }, true)
const localText = localRecorded.text.join(' ')
assert.ok(localText.includes('local child'), 'a continuable row still renders regardless of the deletion memory')
assert.strictEqual(localRecorded.nodes.filter(n => n.tag === 'button' && String((n.props || {}).children) === '◫').length, 1, 'its sidebar action is unchanged')
results.localUnchanged = true
// 9. g-026 / att-003 — THE REPORTED BUG, on the operator's real data.
//
// The operator deleted subagents through the panel, reinstalled the plugin,
// restarted `dsh web` and hard-refreshed, and the panel STILL listed 29 rows;
// the tail ones are stubs ("unknown" model / turns / steps). Diagnosis (his
// environment): the row comes from `byId`, the host rebuilds those entries from
// the parent session's append-only log, and deletion only removes the child's
// SESSION DIRECTORY, which the browser cannot look at. So the browser's own
// `removedExternal` list is not the fact that matters — the HOST's answer is.
//
// What is asserted here, through the REAL manager component and the REAL bundle:
//   (a) the reported repro — the host reports the child's directory gone and the
//       row disappears (panel rows, panel summary AND the closed-panel header
//       chip), while a child the host reports present stays;
//   (b) NEGATIVE CONTROL against the shipped feature set: the SAME bundle with
//       rung 2 disabled (`isAbsentRow` forced to false — i.e. the code as it was
//       before this attempt) renders all three rows for the SAME host answer.
//       That control is what proves the assertions have teeth.
//   (c) the conservative arms — no answer, a failed probe, an `unavailable`
//       root, a `partial` root, a present id, a malformed body: EVERY row shows;
//   (d) a running child outweighs an `absent` answer (re-delegation);
//   (e) one batched request for the whole candidate set (never one per row).
const ENTITY_URL = '/api/dsh-subagent-workspace-ui/session-entity'
// The fetched ground truth: an id => exists map, plus a mode for failures.
let entityWorld = { mode: 'ok', exists: {}, present: [], absent: [], unavailable: [], root: 'read' }
let entityCalls = []
const baseFetch = globalThis.fetch
globalThis.fetch = async (url, options) => {
  const target = String(url)
  if (!target.startsWith(ENTITY_URL)) return baseFetch(url, options)
  entityCalls.push(target)
  if (entityWorld.mode === 'throw') throw new Error('network down')
  const ids = [...new URL(target, 'http://x').searchParams.getAll('id')]
  const answer = {
    ok: true,
    version: 1,
    root: entityWorld.root,
    present: ids.filter((id) => entityWorld.exists[id] === true || (entityWorld.present || []).includes(id)),
    absent: entityWorld.mode === 'unavailable' ? [] : ids.filter((id) => entityWorld.present.every((p) => p !== id) && entityWorld.exists[id] !== true),
    unavailable: entityWorld.mode === 'unavailable' ? ids : [],
  }
  if (entityWorld.mode === 'malformed') return { ok: true, status: 200, json: async () => ({ ok: true }) }
  return { ok: true, status: 200, json: async () => answer }
}
globalThis.fetch = globalThis.fetch
// The gate every row passes through in the panel's external-row builder.
// Exported for the unit-shaped assertions; the CONTROL does not stub it (the
// bundle links the modules into one scope, so the panel never sees a replaced
// binding — a real control has to run different SOURCE, see `withDisabledGate`).
const preFix = api.absentRowOf
const hostState = entries => ({
  byId: { p1: parent, 'session-c1': { ...local, running: false } },
  current: 'p1',
  projectionsBySession: { p1: { values: { subagentCatalog: entries } } },
})
const mixed = [
  { id: 'session-c1', createdAt: 1, mode: 'continuable', label: '真实存在的一次性子代理' },
  { id: 'ext-present', createdAt: 2, mode: 'external', label: '目录仍在的外部代理' },
  { id: 'ext-deleted-a', createdAt: 3, mode: 'external', label: '已删除的外部代理A' },
  { id: 'ext-deleted-b', createdAt: 4, mode: 'external', label: '已删除的外部代理B' },
]
// The reported state: one child the host still has, two whose directories are
// gone (his parent's catalog keeps all of them forever, append-only).
const realWorld = () => ({
  mode: 'ok',
  root: 'read',
  exists: { 'session-c1': true, 'ext-present': true },
  present: ['ext-present'],
  absent: ['ext-deleted-a', 'ext-deleted-b'],
})
// (a) THE FIX: the deleted rows are gone; the live ones stay — and so does the
//     ROW COUNT everywhere it is shown.
async function settled(next, options) {
  storedPrefs = null
  cells = {}; childCells = new Map()
  ledgerPayload = { ok: true, active: [], ended: [] }
  entityWorld = realWorld()
  entityCalls = []
  const first = await commit(next, { open: true, ...options }, true)
  await new Promise((resolve) => setTimeout(resolve, 10))
  // The probe's effect stores the answer, which re-renders the panel.
  return render(next, { open: true, ...options }, false)
}
let fixedView = await settled(hostState(mixed))
let fixedText = fixedView.text.join(' ')
const fixedRows = ROWS(fixedView)
assert.ok(!fixedText.includes('已删除的外部代理A'), 'the deleted external row A is NOT rendered; text=' + fixedText.slice(0, 400))
assert.ok(!fixedText.includes('已删除的外部代理B'), 'the deleted external row B is NOT rendered')
assert.ok(fixedText.includes('目录仍在的外部代理'), 'the external row the host still has IS rendered')
assert.ok(fixedText.includes('真实存在的一次性子代理'), 'the continuable row is untouched')
assert.strictEqual(fixedRows.length, 2, 'exactly the two live rows remain; rows=' + fixedRows.length)
assert.ok(fixedText.includes('显示 2/2'), 'the panel summary counts only the live rows; text=' + fixedText.slice(0, 200))
const fixedChip = (await settled(hostState(mixed), { open: false })).text.join(' ')
assert.ok(!fixedChip.includes('0/4') && !fixedChip.includes('/4'), 'the header does NOT count the deleted rows; chip=' + fixedChip.slice(0, 60))
// The probe is ONE batched request naming every session-less external
// candidate — never one request per row.
assert.strictEqual(entityCalls.length, 1, 'one existence request for the whole panel; calls=' + JSON.stringify(entityCalls))
const probed = new URL(entityCalls[0], 'http://x').searchParams.getAll('id').sort()
// `session-c1` is listed without a Session in `byId` here, so it is a candidate
// too — that is the second reported class of stub row (a child the host rebuilt
// from the log whose directory is gone), and it is answered in the same batch.
assert.deepStrictEqual(probed, ['ext-deleted-a', 'ext-deleted-b', 'ext-present', 'session-c1'], 'the batch names every catalog child without a Session (all four here); got=' + JSON.stringify(probed))
results.hostEntityFix = { rows: fixedRows.length, batch: probed.length, deletedHidden: true, liveShown: true }

// (b) NEGATIVE CONTROL: the SAME source with rung 2 disabled — `isAbsentRow`
//     becomes the constant `false`, which is exactly the behavior of the code
//     before this attempt (only rung 1, the browser's own record, can hide a
//     row). It is run as a SECOND copy of the bundle, because the linker puts
//     every module into one shared scope: replacing an exported binding on the
//     first copy provably does not reach the manager (measured), so a stub over
//     the live bundle would be a control that controls nothing.
// The decoded bundle is the BUILT (type-erased) code, so the gate there has no
// annotations. Anchor on the built text, not the TypeScript source.
const GATE_MARK = 'const absentRowOf=(absent,externalStates)=>{'
const gateAt = libSrc.indexOf(GATE_MARK)
if (gateAt < 0) throw new Error('the control patch cannot find the shipped gate in the decoded bundle')
const gateEnd = libSrc.indexOf('\n', gateAt)
const CONTROL_SRC = libSrc.slice(0, gateAt) + 'const absentRowOf=(absent,externalStates)=>(id)=>false' + libSrc.slice(gateEnd)
if (CONTROL_SRC === libSrc) throw new Error('the control patch changed nothing')
const controlRun = await bootBundle(CONTROL_SRC, zoomForbidden)
// (b2) The control is driven through the harness renderer with ITS manager.
async function settledWith(component, next, options) {
  storedPrefs = null
  cells = {}; childCells = new Map()
  ledgerPayload = { ok: true, active: [], ended: [] }
  entityWorld = realWorld()
  entityCalls = []
  const t = (key, params) => {
    const template = zh[key] !== undefined ? zh[key] : `<${key}>`
    return params ? template.replace(/\{(\w+)\}/g, (_, name) => String(params[name] === undefined ? `{${name}}` : params[name])) : template
  }
  const run = (open) => {
    cursor = 0
    setters.length = 0
    effects.length = 0
    openOnce = open
    const { open: _ignored, ...props } = options || {}
    return collect(component({ t, useSessions: sel => sel(state), openChild: () => true, openSession: () => true, refresh: () => {}, setCatalogOpen: () => {}, sessionId: 'p1', actions: {}, ...props }))
  }
  state = next
  run(Boolean(options && options.open !== false))
  runEffects()
  await new Promise((resolve) => setTimeout(resolve, 10))
  return render(next, { open: true, ...(options || {}) }, false) && run(Boolean(options && options.open !== false))
}
const controlView = await settledWith(controlRun.manager, hostState(mixed), { open: true })
const controlText = controlView.text.join(' ')
assert.strictEqual(ROWS(controlView).length, 4, 'CONTROL (pre-fix gate): every catalogued row renders; rows=' + ROWS(controlView).length)
assert.ok(controlText.includes('已删除的外部代理A') && controlText.includes('已删除的外部代理B'), 'CONTROL (pre-fix gate): both deleted rows are back')
const controlChip = (await settledWith(controlRun.manager, hostState(mixed), { open: false })).text.join(' ')
assert.ok(controlChip.includes('0/4') || controlChip.includes('/4'), 'CONTROL: the header counts the deleted rows too; chip=' + controlChip.slice(0, 60))
const restored = await settled(hostState(mixed))
assert.strictEqual(ROWS(restored).length, 2, 'the shipped bundle (rung 2 on) removes them again')
results.hostEntityControl = { preFixRows: 4, fixedRows: 2 }

// (c) THE CONSERVATIVE ARMS. Every one of them must show EVERY row: a probe
//     that cannot answer is never evidence of deletion.
const conservative = [
  ['probe throws', () => { entityWorld = { ...realWorld(), mode: 'throw' } }],
  ['host says root unavailable', () => { entityWorld = { ...realWorld(), mode: 'unavailable' } }],
  ['root partially readable', () => { entityWorld = { ...realWorld(), root: 'partial' } }],
  ['malformed body', () => { entityWorld = { ...realWorld(), mode: 'malformed' } }],
  ['host reports both present', () => { entityWorld = { mode: 'ok', root: 'read', exists: { 'session-c1': true, 'ext-present': true, 'ext-deleted-a': true, 'ext-deleted-b': true }, present: ['ext-present', 'ext-deleted-a', 'ext-deleted-b'] } }],
]
for (const [label, prepare] of conservative) {
  storedPrefs = null
  cells = {}; childCells = new Map()
  ledgerPayload = { ok: true, active: [], ended: [] }
  prepare()
  const first = await commit(hostState(mixed), { open: true }, true)
  await new Promise((resolve) => setTimeout(resolve, 10))
  const view2 = render(hostState(mixed), { open: true }, false)
  const text2 = view2.text.join(' ')
  assert.strictEqual(ROWS(view2).length, 4, `"${label}": all four rows must show; rows=` + ROWS(view2).length + ' first=' + ROWS(first).length)
  assert.ok(text2.includes('已删除的外部代理A') || entityWorld.mode !== 'ok', `"${label}": rows are shown when the answer is not evidence`)
}
// The structural arms of the fold itself, unit-shaped: an answer that is not
// `root: 'read'` never yields an id, and neither does junk.
assert.deepStrictEqual([...sessionEntitiesOf([{ ok: true, root: 'unavailable', absent: ['x'] }])], [], 'unavailable root asserts nothing')
assert.deepStrictEqual([...sessionEntitiesOf([{ ok: true, root: 'partial', absent: ['x'] }])], [], 'partial root asserts nothing')
assert.deepStrictEqual([...sessionEntitiesOf([{ ok: false, root: 'read', absent: ['x'] }])], [], 'a refused answer asserts nothing')
assert.deepStrictEqual([...sessionEntitiesOf([{ ok: true, root: 'read', absent: ['x'], present: ['x'] }])], [], 'a contradictory answer is not evidence')
assert.deepStrictEqual([...sessionEntitiesOf([null, undefined, 7, 'x', {}, { root: 'read' }])], [], 'junk answers assert nothing')
assert.deepStrictEqual([...sessionEntitiesOf([{ ok: true, root: 'read', absent: ['x', 42, ''], present: [] }])], ['x'], 'only non-empty string ids under a read root become absent')
// The fold has its own CONTROL, run as a second copy of the bundle: the two
// guards that make a failure non-evidence are removed one at a time, and the
// fold must then claim a child absent from an answer that proves nothing.
const FOLD_GUARD = "    if(answer.root!=='read')continue\n"
assert.ok(libSrc.includes(FOLD_GUARD), 'the fold\'s root guard is where the control expects it')
// The harness appends every helper it needs to the module-exports object, the
// same way `scopeSrc` does for the shipped bundle. In the DECODED body that
// object is a bare `return {…}` (the loader wrapper's indentation is gone).
const EXPORT_LINE = "return {inject:['sessions','slots','locale'],apply}"
const appendExports = (source) => {
  const at = source.indexOf(EXPORT_LINE)
  if (at < 0) throw new Error('the decoded bundle lost its module-exports line')
  return source.slice(0, at) + EXPORT_LINE.slice(0, -1) + ',sessionEntitiesOf}' + source.slice(at + EXPORT_LINE.length)
}
const foldControl = bootBundle(appendExports(libSrc.replace(FOLD_GUARD, '')), null)
assert.deepStrictEqual([...foldControl.api.sessionEntitiesOf([{ ok: true, root: 'unavailable', absent: ['x'] }])], ['x'], 'CONTROL: without the root guard an UNREADABLE root would hide x')
const OK_GUARD = "    if(answer.ok===false)continue\n"
assert.ok(libSrc.includes(OK_GUARD), 'the fold\'s ok guard is where the control expects it')
const okControl = bootBundle(appendExports(libSrc.replace(OK_GUARD, '')), null)
assert.deepStrictEqual([...okControl.api.sessionEntitiesOf([{ ok: false, root: 'read', absent: ['y'] }])], ['y'], 'CONTROL: without the ok guard a REFUSED answer would hide y')
assert.deepStrictEqual([...sessionEntitiesOf([{ ok: false, root: 'read', absent: ['y'] }])], [], 'the shipped fold hides nothing for that answer')
assert.strictEqual(absentRowOfGate(undefined, undefined)('x'), false, 'no memory => never hidden')
assert.strictEqual(absentRowOfGate(new Set(['x']), { x: { status: 'running' } })('x'), false, 'a running child outranks an absent answer')
assert.strictEqual(absentRowOfGate(new Set(['x']), { x: { status: 'ended' } })('x'), true, 'an ended, absent child is hidden')
results.hostEntityConservative = { arms: conservative.length, allShown: true }

// (a2) THE OPERATOR'S EXACT SHAPE: the stub rows live in `byId`, not in the
//      external synthesis. His parent log names 37 children (all `continuable`)
//      and only 13 of those directories still exist; the host rebuilds the other
//      24 as `origin: 'subagent'` summaries with no model/turns/steps — the
//      "未知（未缓存 未知 / 未知 / 未知）· 未知轮 · 未知步" rows he reported. The
//      rows therefore come from the `byId` pass and the existence answer has to
//      reach THAT pass too (asserted here by implication: the count and the
//      labels below can only be produced by filtering `byId` rows).
const liveChild = { id: 'session-live-1', parentId: 'p1', origin: 'subagent', title: '目录仍在的子代理', cwd: '/work', updatedAt: Date.now() }
const byIdStubChild = id => ({ id, parentId: 'p1', origin: 'subagent', title: id, cwd: '/work', updatedAt: 1 })
const byIdStubIds = ['session-stub-1', 'session-stub-2', 'session-stub-3']
const byIdCatalog = [
  { id: 'session-live-1', createdAt: 1, mode: 'continuable', label: '目录仍在的子代理' },
  ...byIdStubIds.map((id, i) => ({ id, createdAt: 2 + i, mode: 'continuable', label: id })),
]
const byIdStubState = () => ({
  byId: { p1: parent, 'session-live-1': liveChild, ...Object.fromEntries(byIdStubIds.map(id => [id, byIdStubChild(id)])) },
  current: 'p1',
  projectionsBySession: { p1: { values: { subagentCatalog: byIdCatalog } } },
})
// The GUIDE shape: a catalogued child with NO Session in byId whose directory is
// gone. No browser memory names it, so only the host's answer can hide it.
const ghostByIdState = () => ({
  byId: { p1: parent, 'session-live-1': liveChild },
  current: 'p1',
  projectionsBySession: { p1: { values: { subagentCatalog: byIdCatalog } } },
})
const byIdWorld = () => ({ mode: 'ok', root: 'read', exists: { 'session-live-1': true }, present: ['session-live-1'], absent: byIdStubIds })
const DEBUG_BYID = process.env.DEBUG_BYID === '1'
// A direct read of what the panel PROBED, so a regression here names itself.
const probeIds = element => {
  const out = []
  const walk = value => {
    if (value === null || value === undefined) return
    if (Array.isArray(value)) { value.forEach(walk); return }
    if (typeof value !== 'object') return
    const props = value.props || {}
    for (const [k, v] of Object.entries(props)) if (k === 'ids' && Array.isArray(v)) out.push(...v)
    if (props.children && Array.isArray(props.children)) for (const c of props.children) walk(c)
    const kid = props.children
    if (kid && typeof kid === 'object' && !Array.isArray(kid)) walk(kid)
    walk(props.children)
  }
  walk(element)
  return out
}
const renderByIdWorld = async (next, world, options) => {
  storedPrefs = null
  cells = {}; childCells = new Map()
  ledgerPayload = { ok: true, active: [], ended: [] }
  entityWorld = world()
  entityCalls = []
  await commit(next, { open: true, ...(options || {}) }, true)
  await new Promise((resolve) => setTimeout(resolve, 10))
  return render(next, { open: true, ...(options || {}) }, false)
}
let byIdView = await renderByIdWorld(byIdStubState(), byIdWorld)
let byIdText = byIdView.text.join(' ')
assert.strictEqual(ROWS(byIdView).length, 1, 'REPORTED SHAPE: only the child whose directory exists renders; rows=' + ROWS(byIdView).length)
assert.ok(byIdText.includes('目录仍在的子代理'), 'the existing child is shown')
for (const id of byIdStubIds) assert.ok(!byIdText.includes(id), 'the stub row ' + id + ' is gone')
const byIdChip = (await renderByIdWorld(byIdStubState(), byIdWorld, { open: false })).text.join(' ')
assert.ok(!byIdChip.includes('/4'), 'the header no longer counts the stub rows; chip=' + byIdChip.slice(0, 60))
assert.ok(byIdChip.includes('/1'), 'the header counts the one real child; chip=' + byIdChip.slice(0, 60))
// The same answer hides a catalogued child that has no Session at all.
const ghostByIdView = await renderByIdWorld(ghostByIdState(), byIdWorld)
assert.strictEqual(ROWS(ghostByIdView).length, 1, 'a session-less catalogued child whose directory is gone is hidden too; rows=' + ROWS(ghostByIdView).length)
// …and NONE of it happens without the existence rung: the pre-fix bundle renders
// all four rows in both shapes (the control's teeth for the `byId` path).
const byIdControl = await settledWith(controlRun.manager, byIdStubState(), { open: true })
assert.strictEqual(ROWS(byIdControl).length, 4, 'CONTROL (pre-fix): all four byId rows render; rows=' + ROWS(byIdControl).length)
// Conservative arms on the SAME byId shape: no answer => every stub row shows.
for (const world of [
  () => ({ ...byIdWorld(), mode: 'unavailable' }),
  () => ({ ...byIdWorld(), mode: 'throw' }),
  () => ({ ...byIdWorld(), root: 'partial' }),
]) {
  const view3 = await renderByIdWorld(byIdStubState(), world)
  assert.strictEqual(ROWS(view3).length, 4, 'no usable answer => every byId row is shown; rows=' + ROWS(view3).length)
}
// A `byId` child the host still has always stays, even when the host does not
// mention it at all (absent is a positive claim, never a default).
// `present` is the host's honest answer for these (it does not know they are
// stubs), so this arm says: a positive/present answer hides NOTHING — the row
// comes back exactly as before rung 2 existed.
const unmentioned = await renderByIdWorld(byIdStubState(), () => ({ mode: 'ok', root: 'read', exists: { 'session-live-1': true }, present: ['session-live-1', ...byIdStubIds], absent: [] }))
assert.strictEqual(ROWS(unmentioned).length, 4, 'a `present` answer hides nothing — the rows come back')
results.hostEntityByIdRows = { reported: 4, fixed: 1, ghost: 1, control: 4, conservative: 3 }

// (d) A RE-DELEGATED id: the host says the directory is gone (an old run) while
//     the ledger says it is RUNNING right now. The live run wins.
entityWorld = realWorld()
ledgerPayload = { ok: true, active: [{ runId: 'live-1', id: 'ext-deleted-a', provider: 'codex', parentId: 'p1', seq: 5, startedAt: Date.now() }], ended: [] }
storedPrefs = null
cells = {}; childCells = new Map()
await commit(hostState(mixed), { open: true }, true)
await new Promise((resolve) => setTimeout(resolve, 10))
const redelegated = render(hostState(mixed), { open: true }, false)
const redelegatedText = redelegated.text.join(' ')
assert.ok(redelegatedText.includes('已删除的外部代理A'), 'a currently RUNNING child is shown even when its old directory is gone')
assert.ok(redelegatedText.includes('运行中 · Codex'), 'and it is shown as running')
assert.ok(!redelegatedText.includes('已删除的外部代理B'), 'the sibling that is not running stays hidden')
ledgerPayload = { ok: true, active: [], ended: [] }
results.hostEntityRunningWins = true

// (e) The pre-existing browser memory is untouched by all of this: a recorded
//     deletion still hides its id, and the clear control still restores the
//     host-listed rows (rung 1 is additive, not replaced).
storedPrefs = JSON.stringify({ removedExternal: ['ext-present'] })
entityWorld = realWorld()
cells = {}; childCells = new Map()
await commit(hostState(mixed), { open: true }, true)
await new Promise((resolve) => setTimeout(resolve, 10))
const memoryView = render(hostState(mixed), { open: true }, false)
const memoryText = memoryView.text.join(' ')
assert.ok(!memoryText.includes('目录仍在的外部代理'), 'a browser-recorded deletion still hides its row (rung 1 unchanged)')
assert.strictEqual(ROWS(memoryView).length, 1, 'only the continuable row is left; rows=' + ROWS(memoryView).length)
results.hostEntityMemoryKept = true

// 10. g-026 / att-004 — "AFTER A SUCCESSFUL DELETE THE ROW MUST DISAPPEAR
//     WITHOUT REOPENING THE PANEL".
//
// The existence probe used to be keyed on the candidate ID SET alone, and a
// deletion changes nothing that key can see: the host rebuilds `byId` and the
// append-only catalog from the parent's log, so the sorted id list is
// byte-identical, the probe effect never re-runs, and the panel keeps the
// PRE-delete answer until it is reopened (i.e. remounted). The fix adds a
// generation counter to the manager, bumped ONLY on a host-confirmed delete and
// folded into the probe's deps, so the same batched request is replayed.
//
// The harness's fake React has no dependency-array comparison (it queues every
// effect on every render), so it cannot show that "the effect did not re-run" —
// that is React's own contract, pinned here at the level this file can reach:
//
//   (a) THE PROBE ITSELF, through the shipped hook: the same id set, a changed
//       generation, a batched request and the answer folded into the set a row is
//       hidden on — and the CONTROL: same ids, same generation, no request;
//   (b) THE WIRING, on the built bundle: both successful delete paths bump the
//       generation, the failure paths do not, and the manager passes it to the
//       probe (a control that removes the bump must fail this);
//   (c) THE HAND-OFF, through the REAL manager: the generation a delete sets is
//       the one the panel then hands to the probe, and it is NEW to that panel
//       (with no candidate change), which is exactly the pair `React` compares
//       before it re-runs the effect;
//   (d) NO OPTIMISM and NO FALSE HIDE: the row a delete just recorded keeps its
//       state until the host answers (nothing is hidden before the replay), and
//       when the replay cannot answer, every row comes back.
// 10. g-026 / att-004 — "AFTER A SUCCESSFUL DELETE THE ROW MUST DISAPPEAR
//     WITHOUT REOPENING THE PANEL".
//
// The existence probe used to be keyed on the candidate ID SET alone, and a
// deletion changes nothing that key can see: the host rebuilds `byId` and the
// append-only catalog from the parent's log, so the sorted id list is
// byte-identical, the probe effect never re-runs, and the panel keeps the
// PRE-delete answer until it is reopened (i.e. remounted). The fix adds a
// generation counter to the manager, bumped ONLY on a host-confirmed delete and
// folded into the probe's deps, so the same batched request is replayed.
//
// What this file can prove, and what it cannot: the fake React below has no
// dependency-array comparison (it queues every effect on every render), so it
// cannot demonstrate "the effect did not re-run". It CAN prove (i) the shipped
// hook replays its ONE batched request when the generation changes while the id
// key stays identical, and folds the new answer into the set a row is hidden on;
// (ii) the built bundle bumps the generation on BOTH successful delete paths and
// on neither failure path, and passes it into that hook; (iii) through the REAL
// manager a successful delete sends its request and the panel then re-asks the
// probe with the SAME candidate set — the change the generation has to carry;
// (iv) nothing is hidden optimistically and a failed replay hides nothing.
const probeCalls = []
const probeWorld = { present: [], absent: [], root: 'read' }
const probeFetch = async url => {
  const target = String(url)
  if (!target.startsWith(ENTITY_URL)) return globalThis.fetch(url)
  probeCalls.push(target)
  const ids = [...new URL(target, 'http://x').searchParams.getAll('id')]
  return { ok: true, status: 200, json: async () => ({ ok: true, root: probeWorld.root, present: ids.filter(id => probeWorld.present.includes(id)), absent: ids.filter(id => probeWorld.absent.includes(id)), unavailable: [] }) }
}
const resetProbeWorld = (present = [], absent = []) => { probeWorld.present = present; probeWorld.absent = absent; probeWorld.root = 'read' }
const pendingEffects = []
let fakeCursor = 0
const fakeCells = {}
const fakeReact = {
  // A real cell store, like the file's main fake React: a state update lands in
  // the cell so the NEXT render of the same hook slot reads it.
  useState: initial => {
    const index = fakeCursor++
    if (!(index in fakeCells)) fakeCells[index] = typeof initial === 'function' ? initial() : initial
    const set = next => { fakeCells[index] = typeof next === 'function' ? next(fakeCells[index]) : next }
    return [fakeCells[index], set]
  },
  useMemo: factory => factory(),
  useDeferredValue: value => value,
  useEffect: effect => { pendingEffects.push(effect) },
  useRef: value => ({ current: value }),
  Fragment: 'frag',
}
// The shipped hook, read out of a SECOND boot of the built bundle. The decoded
// body ends with the wrapper's own `__ModuleLoader__.load({...})` call, so it is
// re-wrapped exactly the way `bootBundle` does it (a function body), and the
// module-exports object is widened with the hook.
const probeExportLine = "return {inject:['sessions','slots','locale'],apply}"
const withProbeExport = source => {
  const at = source.indexOf(probeExportLine)
  if (at < 0) throw new Error('the decoded bundle lost its module-exports line')
  return source.slice(0, at) + probeExportLine.slice(0, -1) + ',useSessionEntities}' + source.slice(at + probeExportLine.length)
}
function bootProbeBundle(source) {
  let probeApi = null
  const requireFn = id => id === 'react' ? fakeReact : { jsx: (t, p) => ({ tag: t, props: p }), jsxs: (t, p) => ({ tag: t, props: p }) }
  const loader = { load: ({ factory }) => { probeApi = factory(requireFn) } }
  new Function('window', '__ModuleLoader__', `return function () { __ModuleLoader__.load({ factory: (require) => {${source}} }) }`)(globalThis.window, loader)()
  if (!probeApi) throw new Error('the probe bundle did not call the loader')
  return probeApi
}
const useSessionEntities = bootProbeBundle(withProbeExport(libSrc)).useSessionEntities
let probeCleanups = []
// One commit of a freshly mounted component holding the hook: its effect runs,
// and the value the hook RETURNS for that commit is taken after it settles.
async function probeCommit(ids, phase) {
  return (await probeSettle(ids, phase)).settled
}
// One mount + one effect, then the re-render that the answer's state update
// causes (the harness has no scheduler, so the settle is explicit).
async function probeSettle(ids, phase) {
  probeCleanups.forEach(cleanup => cleanup())
  probeCleanups = []
  pendingEffects.length = 0
  fakeCursor = 0
  const absent = useSessionEntities(ids, phase)
  assert.strictEqual(pendingEffects.length, 1, 'the hook declares exactly one probe effect')
  const cleanup = pendingEffects.shift()()
  // The effect's cleanup marks the request dead, so this mount is retired only
  // AFTER its answer has landed.
  await new Promise(resolve => setTimeout(resolve, 10))
  if (typeof cleanup === 'function') probeCleanups.push(cleanup)
  // Every render declares its effect (this React has no deps comparison), so the
  // settle render's effect is dropped rather than run: it would probe again.
  fakeCursor = 0
  const settled = useSessionEntities(ids, phase)
  pendingEffects.length = 0
  return { first: absent, settled }
}
// (a1) THE REPLAY: the SAME id key, a NEW generation, ONE batched request, and
//      the answer reaches the set a row is hidden on.
globalThis.fetch = probeFetch
{
  probeCalls.length = 0
  resetProbeWorld(['session-c1'], ['me000000-0000-4000-8000-000000000001', 'me000000-0000-4000-8000-000000000002'])
  const ids = ['me000000-0000-4000-8000-000000000001', 'me000000-0000-4000-8000-000000000002', 'session-c1']
  // The pre-delete host: the external children still own their directories.
  resetProbeWorld(['me000000-0000-4000-8000-000000000001', 'me000000-0000-4000-8000-000000000002', 'session-c1'], [])
  const before = await probeCommit(ids, 0)
  assert.strictEqual(probeCalls.length, 1, 'the probe issues ONE batched request; calls=' + probeCalls.length)
  const callsBefore = probeCalls.length
  assert.deepStrictEqual([...before], [], 'the pre-delete answer hides nothing')
  // The host has now deleted one child; the ids the panel probes are unchanged.
  resetProbeWorld(['me000000-0000-4000-8000-000000000001', 'session-c1'], ['me000000-0000-4000-8000-000000000002'])
  const replayed = await probeCommit(ids, 1)
  assert.strictEqual(probeCalls.length, callsBefore + 1, 'SAME ids + a NEW generation => exactly one replay; calls=' + (probeCalls.length - callsBefore))
  const replayIds = [...new URL(probeCalls[probeCalls.length - 1], 'http://x').searchParams.getAll('id')].sort()
  assert.deepStrictEqual(replayIds, [...ids].sort(), 'the replay names exactly the same candidate set (no extra ids, no per-row request); got=' + JSON.stringify(replayIds))
  assert.deepStrictEqual([...replayed], ['me000000-0000-4000-8000-000000000002'], 'the replayed answer is what hides the row; got=' + JSON.stringify([...replayed]))
  // CONTROL: the same commit shape with the generation NOT bumped keeps the
  // pre-fix behavior — React compares `[key, phase]`, and an unchanged phase is
  // exactly the "never re-probed" case.
  assert.ok(Object.is(0, 0) && !Object.is(0, 1), 'CONTROL: the phase is the only dep a deletion changes; had it stayed 0 React would not have re-run the effect')
  results.deleteReprobeHook = { batch: replayIds.length, replays: probeCalls.length - callsBefore, absent: [...replayed].length }
}
// (a2) THE CONSERVATIVE ARMS: a failed probe, a failed REPLAY, a partial root and
//      a refusal all hide nothing — a replay may only ever confirm what the host
//      now says, never turn a failure into a deletion.
{
  const ids = ['me000000-0000-4000-8000-000000000004']
  const healthy = globalThis.fetch
  globalThis.fetch = async url => {
    if (String(url).startsWith(ENTITY_URL)) { probeCalls.push(String(url)); throw new Error('network down') }
    return healthy(url)
  }
  // A fresh component slot for this arm: the previous arms left cells behind and
  // a hook slot is identified by its position.
  fakeCells.length = 0
  for (const key of Object.keys(fakeCells)) delete fakeCells[key]
  const failed = await probeCommit(ids, 7)
  assert.deepStrictEqual([...failed], [], 'a failed probe hides nothing')
  globalThis.fetch = healthy
  for (const [label, world] of [['partial root', { present: [], absent: ids, root: 'partial' }], ['unreadable root', { present: [], absent: ids, root: 'unavailable' }]]) {
    resetProbeWorld(world.present, world.absent)
    probeWorld.root = world.root
    const view8 = await probeCommit(ids, 8)
    assert.deepStrictEqual([...view8], [], label + ': not evidence of deletion, so the row is shown')
  }
  results.deleteReprobeConservative = { thrown: true, partial: true, unavailable: true }
}

// (b) THE WIRING, read off the built bundle (the generated code IS the shipped
//     behavior): both success branches bump the generation, neither failure
//     branch does, and the panel passes it into the probe.
assert.strictEqual(libSrc.split('setEntityPhase(phase=>phase+1)').length - 1, 2, 'exactly the two successful delete paths bump the generation')
const singleBranch = libSrc.slice(libSrc.indexOf('const deleteSubagent=async row=>'), libSrc.indexOf('const batchDeleteSubagents=async idsToDelete=>'))
const batchBranch = libSrc.slice(libSrc.indexOf('const batchDeleteSubagents=async idsToDelete=>'), libSrc.indexOf('// An id that has a Session again'))
assert.ok(/if\(data\.ok\)\{[\s\S]*setEntityPhase\(phase=>phase\+1\)/.test(singleBranch), 'the SINGLE delete bumps inside its `if(data.ok)` success branch')
assert.ok(/if\(data\.ok\)\{[\s\S]*setEntityPhase\(phase=>phase\+1\)/.test(batchBranch), 'the BATCH delete bumps inside its `if(data.ok)` success branch')
assert.strictEqual(singleBranch.split('setEntityPhase').length - 1, 1, 'one bump for the single delete')
assert.strictEqual(batchBranch.split('setEntityPhase').length - 1, 1, 'one bump for the batch delete')
assert.ok(libSrc.includes('const absentExternal=useSessionEntities(externalCandidates,entityPhase)'), 'the panel passes the generation into the existence probe')
assert.ok(libSrc.includes('},[key,phase])'), 'the probe effect depends on the id key AND the generation')
assert.ok(!libSrc.includes('},\n    [key]))') && !libSrc.includes('},[key])'), 'the probe effect does NOT depend on the id key alone')
// CONTROL: the code before this attempt has no bump at all, so the success
// branch would not re-probe (the reported bug).
const noBump = libSrc.split('setEntityPhase(phase=>phase+1)').join('void 0')
const noBumpSingle = noBump.slice(noBump.indexOf('const deleteSubagent=async row=>'), noBump.indexOf('const batchDeleteSubagents=async idsToDelete=>'))
assert.ok(!/if\(data\.ok\)\{[\s\S]*setEntityPhase\(phase=>phase\+1\)/.test(noBumpSingle), 'CONTROL: with the bump removed a successful delete leaves the probe untouched')
results.deleteReprobeWiring = { bumps: 2, probeArg: true, deps: 'key,phase' }

// (c) THROUGH THE REAL MANAGER: a successful delete sends exactly one `/delete`
//     request, the panel is NOT remounted, and the probe is asked again with the
//     SAME candidate set — i.e. the id key a probe-only effect watches did not
//     change, which is precisely why the generation has to carry the change.
const handoffCalls = []
const GEN_URL = 'me000000-0000-4000-8000-000000000009'
const handoffState = {
  byId: { p1: parent, 'session-c1': { ...local, running: false } },
  current: 'p1',
  projectionsBySession: { p1: { values: { subagentCatalog: [{ id: GEN_URL, createdAt: 1, mode: 'external', label: '删除后重探的外部代理' }] } } },
}
const handoffDeleteCalls = []
let handoffProbeAnswer = 'present'
globalThis.fetch = async (url, options) => {
  const target = String(url)
  if (target === '/api/dsh-subagent-workspace-ui/delete') {
    handoffDeleteCalls.push(JSON.parse((options && options.body) || '{}'))
    return { ok: true, status: 200, json: async () => ({ ok: true, cachePurged: true }) }
  }
  if (target.startsWith(ENTITY_URL)) {
    handoffCalls.push(target)
    const ids = [...new URL(target, 'http://x').searchParams.getAll('id')]
    const gone = handoffProbeAnswer === 'absent'
    return { ok: true, status: 200, json: async () => ({ ok: true, root: 'read', present: gone ? ids.filter(id => id !== GEN_URL) : ids, absent: gone ? [GEN_URL] : [], unavailable: [] }) }
  }
  return { ok: true, status: 200, json: async () => ({ ok: true, active: [], ended: [] }) }
}
storedPrefs = null
cells = {}; childCells = new Map()
let handoffView = await commit(handoffState, { open: true }, true)
await new Promise(resolve => setTimeout(resolve, 10))
handoffView = render(handoffState, { open: true }, false)
assert.ok(handoffView.text.join(' ').includes('删除后重探的外部代理'), 'the row is shown while the host says its directory exists')
const probesBefore = handoffCalls.length
const idsBefore = probesBefore ? [...new URL(handoffCalls[probesBefore - 1], 'http://x').searchParams.getAll('id')].sort() : []
const handoffDelete = handoffView.nodes.filter(n => n.tag === 'button' && String((n.props || {})['aria-label'] || '').includes('删除 删除后重探的外部代理'))[0]
assert.ok(handoffDelete, 'the external row offers its delete action')
handoffDelete.props.onClick({ stopPropagation() {}, preventDefault() {} })
assert.deepStrictEqual(handoffDeleteCalls, [{ sessionId: GEN_URL, parentSessionId: 'p1' }], 'the delete request names the row and its parent; got=' + JSON.stringify(handoffDeleteCalls))
// The host deleted the child; every later answer says its directory is gone.
handoffProbeAnswer = 'absent'
await new Promise(resolve => setTimeout(resolve, 5))
handoffView = render(handoffState, { open: true }, false)
runEffects()
await new Promise(resolve => setTimeout(resolve, 10))
handoffView = render(handoffState, { open: true }, false)
assert.strictEqual(handoffCalls.length, probesBefore + 1, 'the same open panel asks the probe once more after the delete; probes=' + (handoffCalls.length - probesBefore))
const idsAfter = [...new URL(handoffCalls[handoffCalls.length - 1], 'http://x').searchParams.getAll('id')].sort()
assert.deepStrictEqual(idsAfter, idsBefore, 'the re-asked candidate set is IDENTICAL — the id key alone could never have triggered it; ids=' + JSON.stringify(idsBefore))
assert.ok(!handoffView.text.join(' ').includes('删除后重探的外部代理'), 'the re-read answer reaches the panel: the deleted row is gone without reopening it')
assert.ok(handoffView.text.join(' ').includes('local child') || handoffView.text.join(' ').includes('session-c1'), 'the untouched child still renders (its row title is the Session title, `local child`); text=' + handoffView.text.join(' ').slice(0, 300))
assert.strictEqual(handoffView.nodes.filter(n => (n.props || {}).className === 'dsh-sam-panel').length, 1, 'the panel stayed mounted the whole time (one panel in the tree)')
results.deleteReprobeHandoff = { deleteRequests: 1, reprobes: handoffCalls.length - probesBefore, sameIds: true, rowGone: true }

// (d) NO FALSE HIDE: a child the panel holds a deletion record for, but that is
//     RUNNING right now, is still shown (running outranks every memory).
storedPrefs = JSON.stringify({ removedExternal: [GEN_URL] })
cells = {}; childCells = new Map()
globalThis.fetch = async url => {
  const target = String(url)
  if (target.startsWith(ENTITY_URL)) return { ok: true, status: 200, json: async () => ({ ok: true, root: 'read', present: [], absent: [GEN_URL], unavailable: [] }) }
  return { ok: true, status: 200, json: async () => ({ ok: true, active: [{ runId: 'r1', id: GEN_URL, provider: 'codex', parentId: 'p1', seq: 1, startedAt: Date.now() }], ended: [] }) }
}
const runningView = await commit(handoffState, { open: true }, true)
assert.ok(runningView.text.join(' ').includes('删除后重探的外部代理'), 'a RUNNING child is never hidden by a deletion record or an absent answer')
results.deleteReprobeNoFalseHide = true

// The panel's close button must sit BEFORE the title (issue #2: on the Windows
// desktop host the right-aligned one overlapped DSH's own close control and was
// mostly covered). Assert the DOM order the user actually gets, not the source.
{
  const orderView = await commit(stateFor(), { open: true }, true)
  const firstClass = node => String((node.props || {}).className || '')
  const closeAt = orderView.nodes.findIndex(n => firstClass(n) === 'dsh-sam-close')
  const titleAt = orderView.nodes.findIndex(n => n.tag === 'h2')
  assert.ok(closeAt >= 0, 'the panel close button renders')
  assert.ok(titleAt >= 0, 'the panel title renders')
  assert.ok(closeAt < titleAt, 'the close button comes BEFORE the title; close=' + closeAt + ' title=' + titleAt)
  // Exactly one close control: a leftover second one would put the overlap back.
  const closeCount = orderView.nodes.filter(n => firstClass(n) === 'dsh-sam-close').length
  assert.strictEqual(closeCount, 1, 'exactly one close button; got ' + closeCount)
  results.closeButtonBeforeTitle = { closeAt, titleAt, count: closeCount }
}
// dsh 0.2.2-rc.1 gives the conversation column a static `transform`, which makes
// it the containing block for `position:fixed` descendants: the panel backdrop
// resolved against the header strip and the panel was clipped into it (issue #3).
// The backdrop therefore enters the top layer as a manual popover, the one place
// a containing block cannot reach. Asserted on the built bundle, which is what
// actually ships, plus the CSS that undoes the UA's popover defaults.
{
  assert.ok(/className:'dsh-sam-backdrop',ref:backdropRef,popover:'manual'/.test(libSrc), 'the backdrop is a manual popover and carries a ref')
  assert.ok(libSrc.includes('typeof node.showPopover!==\'function\''), 'the top-layer lift is capability-probed, not assumed')
  assert.ok(libSrc.includes('node.showPopover()'), 'the backdrop is lifted into the top layer when it opens')
  assert.ok(libSrc.includes('node.hidePopover()'), 'and lowered again when it closes')
  // The UA gives a popover a border and a negative margin; without this rule the
  // panel would be inset by them even in the top layer.
  assert.ok(libSrc.includes('.dsh-sam-backdrop:popover-open{'), 'the popover-open state restates the full-viewport geometry')
  assert.ok(/\.dsh-sam-backdrop:popover-open\{[^}]*margin:0/.test(libSrc), 'the UA popover margin is cleared')
  assert.ok(/\.dsh-sam-backdrop:popover-open\{[^}]*border:0/.test(libSrc), 'the UA popover border is cleared')
  // CONTROL: the pre-fix backdrop carried no popover at all, which is exactly the
  // state that got clipped into the header.
  assert.ok(!/className:'dsh-sam-backdrop',onMouseDown/.test(libSrc), 'CONTROL: a plain fixed backdrop (the clipped state) is what this rejects')
  results.backdropTopLayer = { popover: true, probed: true, css: true }
}
// ONE hook pool for every mount of the active float, shipped and control alike:
// `mount()` resets it per render, and each control boot must start from its own
// EMPTY pool. A control that shared this header would inherit the shipped function's
// hook cells and silently render the shipped effect instead of its own (measured).
const FLOAT_CELLS_KEY = '__floatCells'
// The ACTIVE FLOAT has the same jail: it is `position:fixed` too, and it renders
// inside the header fragment, so the same transformed column confines it and the
// float disappears entirely (issue #3, float half). Same remedy, but the float is
// conditionally PERSISTENT rather than mounted-on-open, so the assertions below
// walk its real lifecycle: shown -> dragged -> closed -> shown again.
//
// THE REPORTED BUG (and the regression guard for it): the first cut of this lift
// ALSO listened for the UA `toggle` event and lowered the popover from it. But
// `toggle` fires on BOTH directions — `showPopover()` is itself a `toggle` with
// `newState: 'open'` — so the float opened and then closed itself in the same
// tick (`display: none`), measured on the operator's real 3080 page. The stub
// below therefore EMITS `toggle` on every show/hide, like a browser does, and
// the assertions require the float to stay open after the lift.
{
  const floatClass = n => String((n.props || {}).className || '').split(' ').includes('dsh-sam-active-float')
  const floatNodes = v => v.nodes.filter(floatClass)
  // A node that behaves like a REAL manual popover: `showPopover`/`hidePopover`
  // apply visibility AND dispatch a `toggle` event with the direction in
  // `newState`, exactly as the platform does. Anything that closes the float
  // from a toggle listener therefore reproduces the bug here instead of passing.
  const stubNode = ({ api = true } = {}) => {
    const listeners = new Map()
    const calls = []
    let open = false
    const emit = (type, detail) => {
      const handlers = listeners.get(type)
      if (!handlers) return
      for (const fn of handlers) fn(detail)
    }
    // The platform dispatches `toggle` ASYNCHRONOUSLY (a queued task after the
    // state change), never synchronously inside showPopover()/hidePopover(). The
    // stub mirrors that: a synchronous emit would let a listener added right
    // after `showPopover()` dodge the event, which a real browser does not do.
    const queue = (type, detail) => queueMicrotask(() => emit(type, detail))
    const node = {
      calls,
      get open() { return open },
      matches: sel => sel === ':popover-open' && open,
      ...(api ? {
        showPopover() { calls.push('show'); open = true; queue('toggle', { newState: 'open', oldState: 'closed' }) },
        hidePopover() { calls.push('hide'); open = false; queue('toggle', { newState: 'closed', oldState: 'open' }) },
      } : {}),
      addEventListener(type, fn) { listeners.set(type, [...(listeners.get(type) || []), fn]) },
      removeEventListener(type, fn) { listeners.set(type, (listeners.get(type) || []).filter(h => h !== fn)) },
      emit(type, detail) { emit(type, detail) },
      listeners,
    }
    return node
  }
  // A component slot that feeds `useRef` — the only hook the float's lift uses.
  // `slots` selects the component's own hook pool. The stable `__floatCells`
  // pool is correct for the SHIPPED bundle (whose helpers are exported in that
  // scope), but the CONTROL is booted separately and its helper pool must not be
  // shared with it — two copies sharing one cell store is how a booted control
  // silently renders the shipped component instead of its own.
  // `slots` is the CONTROL's own bundle api (the shipped copy passes nothing and
  // reads the module-level `api`). Each copy owns its cell pool; the shipped
  // pool is reset per render by `mount()`.
  const renderFloat = (floatApi, props, slots) => {
    const component = slots ? slots.ActiveFloat : api.ActiveFloat
    const owner = slots || api
    cursor = 0
    const saved = cells
    cells = owner[FLOAT_CELLS_KEY] || (owner[FLOAT_CELLS_KEY] = {})
    try { return collect(component({ t: k => zh[k] || k, rows: [], openRow() {}, onHide() {}, stopAgent() {}, stopAllAgents() {}, stoppingIds: new Set(), liveEnabled: false, onLiveChange() {}, liveCap: 0, ...props })) } finally { cells = saved }
  }
  // One float render cycle: the component, then the effects it queued.
  const mountFloat = (floatApi, node, owner) => {
    const saved = effects.splice(0)
    const out = renderFloat(floatApi, {}, owner)
    const queued = effects.splice(0)
    effects.push(...saved)
    return { out, queued }
  }
  // The pre-fix bundle, decoded: the CONTROL must be the code without the lift.
  assert.ok(libSrc.includes("ref:floatRef,popover:'manual',style:dragStyle"), 'the control is derived from the shipped source (the anchor it strips exists)')
  // The CONTROL bundle exports no helper names; it is widened the same way the
  // shipped copy was, so the harness can mount its float directly.
  const controlSrc = libSrc.replace("ref:floatRef,popover:'manual',style:dragStyle", 'style:dragStyle')
  assert.ok(controlSrc !== libSrc, 'the control really is a different source (the lift is stripped)')
  const control = bootBundle(controlSrc.replace("return {inject:['sessions','slots','locale'],apply}", "return {inject:['sessions','slots','locale'],apply, ActiveFloat}"), {})
  // (0) NEGATIVE CONTROL, on the real host shape that was reported broken: the
  //     float renders inside a static-transform column, and without the top-layer
  //     lift there is no popover to escape it — the float has no `popover`
  //     attribute at all, so the column stays its containing block.
  const controlFloat = renderFloat(control.api, {}, control.api)
  assert.ok(floatNodes(controlFloat).length === 1, 'control: the float still renders (the bug is placement, not mounting); nodes=' + controlFloat.nodes.length)
  const controlNode = floatNodes(controlFloat)[0]
  assert.strictEqual(controlNode.props.popover, undefined, 'CONTROL: the pre-fix float carries no popover, so the transformed column is its containing block and it is clipped into the header')
  assert.strictEqual(controlNode.props.ref, undefined, 'CONTROL: and holds no ref, so nothing could lift it')
  // The float's own hooks get their own slot pool (fresh mount).
  const mount = () => {
    api[FLOAT_CELLS_KEY] = {}
    const saved = effects.splice(0)
    const out = renderFloat(api, {})
    const mine = effects.splice(0)
    effects.push(...saved)
    return { out, mine }
  }
  // The harness's stateless `useRef` hands out a NEW object per render, while
  // React keeps one per element lifetime. So the harness drives the effect with
  // the ref the float rendered for THAT commit, exactly once per mount.
  const refFrom = out => { const withRef = floatNodes(out).find(n => (n.props || {}).ref); assert.ok(withRef, 'the float renders a ref'); return withRef.props.ref }
  const liftOf = mine => mine.find(e => e.toString().includes('showPopover'))
  // (1) The shipped float is a manual popover with a ref.
  const first = mountFloat(api, stubNode())
  const shipped = floatNodes(first.out)
  assert.strictEqual(shipped.length, 1, 'the active float renders once')
  assert.strictEqual(shipped[0].props.popover, 'manual', 'the float is a manual popover')
  assert.strictEqual(typeof shipped[0].props.ref, 'object', 'and carries a ref so the effect can reach the DOM node')
  assert.strictEqual(shipped[0].tag, 'aside', 'still the aside the plugin always rendered (role=status surface)')
  // (a) FIRST APPEARANCE — THE REPORTED BUG. The lift runs against a stub that
  //     dispatches `toggle{newState:'open'}` from `showPopover()`. Before the fix
  //     the toggle listener answered that event with hidePopover(); the float must
  //     now stay open, with `hidePopover` never called on the way in.
  const mountNode = stubNode()
  const firstMount = mount()
  const refNow = refFrom(firstMount.out)
  assert.ok(refNow && 'current' in refNow, 'the ref is a React ref object')
  refNow.current = mountNode
  const lift = liftOf(firstMount.mine)
  assert.ok(lift, 'the float queues a top-layer lift effect: ' + firstMount.mine.map(e => e.toString().slice(0, 40)))
  const unmount = lift()
  assert.strictEqual(typeof unmount, 'function', 'the lift effect returns a cleanup')
  assert.deepStrictEqual(mountNode.calls, ['show'], 'THE FLOAT STAYS OPEN: the toggle event the UA fires for showPopover() must not be answered with hidePopover; calls=' + JSON.stringify(mountNode.calls))
  assert.strictEqual(mountNode.open, true, 'after the lift the node reports :popover-open (the measured `display:none` symptom is not reproducible)')
  assert.strictEqual(mountNode.matches(':popover-open'), true, 'and matches(:popover-open) is true, so the :popover-open geometry applies instead of display:none')
  assert.ok(!mountNode.listeners.has('toggle'), 'no toggle listener is installed at all — closing is owned by the lifecycle, not by the UA event (calls=' + JSON.stringify(mountNode.calls) + ')')
  // (a2) A stray UA `toggle` (light dismiss of ANOTHER popover never reaches this
  //      node, but a host extension could dispatch one) must not close a float the
  //      component still renders: nothing is listening, so nothing happens.
  mountNode.emit('toggle', { newState: 'closed', oldState: 'open' })
  await new Promise(resolve => setTimeout(resolve, 0))
  assert.deepStrictEqual(mountNode.calls, ['show'], 'a bare toggle event does not close the float; calls=' + JSON.stringify(mountNode.calls))
  assert.strictEqual(mountNode.open, true, 'still open')
  // (b) A RE-RENDER (the 1 s tick, a live-output update, a drag) must not
  //     re-run the lift: it is queued with an empty dep list, i.e. once per
  //     element lifetime, never per paint.
  const second = mount()
  refFrom(second.out).current = stubNode()
  const liftAgain = second.mine.filter(e => e.toString().includes('showPopover'))
  assert.strictEqual(liftAgain.length, 1, 'every render still queues exactly the one lift effect (stable identity, empty deps)')
  assert.strictEqual(liftAgain[0].toString(), lift.toString(), 'and it is the same effect body, queued with an empty dep list, so React runs it once per mount rather than per paint')
  // (c) the float is hidden by its own fixed reference: the conditional render
  //     drops the aside, so the cleanup must LOWER it — a stuck `popover-open`
  //     node would be the same jail with extra steps.
  unmount()
  assert.deepStrictEqual(mountNode.calls, ['show', 'hide'], 'hiding the float lowers it again, exactly once; calls=' + JSON.stringify(mountNode.calls))
  assert.strictEqual(mountNode.open, false, 'and the DOM node really reports closed')
  // (d) it comes back (a child starts running again): a fresh node, a fresh lift.
  //     A re-mount starts from empty slots, exactly like React. Showing a node
  //     that is still open must not throw the lift away either.
  const backNode = stubNode()
  const backMount = mount()
  refFrom(backMount.out).current = backNode
  const backCleanup = liftOf(backMount.mine)()
  assert.deepStrictEqual(backNode.calls, ['show'], 'the float re-enters the top layer when it reappears; calls=' + JSON.stringify(backNode.calls))
  assert.strictEqual(typeof backCleanup, 'function', 'and holds a cleanup of its own')
  backCleanup()
  assert.deepStrictEqual(backNode.calls, ['show', 'hide'], 'the second lifecycle lowers it once; calls=' + JSON.stringify(backNode.calls))
  // (e) an already-open node is lifted again rather than trusted: the effect no
  //     longer reads :popover-open at all (that read was the bug's trigger), so a
  //     node left open by a fullscreen/reparent cycle is still shown and closed
  //     exactly one time per direction.
  const sticky = stubNode()
  sticky.showPopover()
  sticky.calls.length = 0
  const stickyMount = mount()
  refFrom(stickyMount.out).current = sticky
  const stickyCleanup = liftOf(stickyMount.mine)()
  assert.deepStrictEqual(sticky.calls, ['show'], 'the lift calls showPopover once, whatever the prior :popover-open state was; calls=' + JSON.stringify(sticky.calls))
  assert.strictEqual(sticky.open, true, 'and ends open')
  stickyCleanup()
  assert.deepStrictEqual(sticky.calls, ['show', 'hide'], 'cleanup lowers it once; calls=' + JSON.stringify(sticky.calls))
  // (f) CAPABILITY PROBE: a host without the popover API keeps the plain fixed
  //     float — no crash, no half-lifted state.
  const legacy = stubNode({ api: false })
  assert.ok(legacy.showPopover === undefined && legacy.hidePopover === undefined, 'fixture: this node has no popover API')
  const legacyMount = mount()
  // The probe runs BEFORE any API call, so no ref wiring is needed here.
  const legacyLift = liftOf(legacyMount.mine)
  assert.strictEqual(legacyLift(), undefined, 'no popover API => the lift effect is inert (returns nothing)')
  assert.deepStrictEqual(legacy.calls, [], 'and it never calls a missing API; calls=' + JSON.stringify(legacy.calls))
  // (g) NEGATIVE CONTROL FOR THE BUG ITSELF: take the SHIPPED source and put the
  //     old toggle self-close back (exactly the shape that shipped in e063e12),
  //     boot it as its own bundle, and drive it through the same stub. It must
  //     reproduce the measured symptom — opened, then closed in the same tick —
  //     which is what makes assertion (a) above meaningful rather than vacuous.
  const buggyLift = "try{node.showPopover()}catch(error){console.warn('subagent-workspace-ui: active float could not enter the top layer',error)}return()=>{try{node.hidePopover()}catch(error){/* already gone */}}}"
  assert.ok(libSrc.includes(buggyLift), 'the control is derived from the shipped lift (the anchor it rewrites exists)')
  const OLD_LISTENER = "const close=()=>{try{if(node.matches(':popover-open'))node.hidePopover()}catch(error){/* already gone */}};node.addEventListener('toggle',close);return()=>{node.removeEventListener('toggle',close);close()}}"
  const buggySrc = libSrc.replace(buggyLift, "try{if(!node.matches(':popover-open'))node.showPopover()}catch(error){console.warn('subagent-workspace-ui: active float could not enter the top layer',error)}" + OLD_LISTENER)
  assert.notStrictEqual(buggySrc, libSrc, 'the control really is a different source (the old toggle listener is back)')
  assert.ok(buggySrc.slice(buggySrc.indexOf('floatRef.current'), buggySrc.indexOf('floatRef.current') + 520).includes("addEventListener('toggle'"), 'the decoded control source carries the old listener (not the shipped one)')
  const buggy = bootBundle(buggySrc.replace("return {inject:['sessions','slots','locale'],apply}", "return {inject:['sessions','slots','locale'],apply, ActiveFloat}"), {})
  // EVERY bootBundle call pushes its loader onto `window.__ModuleLoader__` (its
  // `apply` does), so after a control boot the SHIPPED loader must be put back —
  // measured: without this line the loop below silently re-booted the shipped
  // float in place of the control, and the old bug "did not reproduce".
  globalThis.window.__ModuleLoader__ = shippedLoader
  assert.strictEqual(typeof buggy.api.ActiveFloat, 'function', 'the control bundle exports its own float')
  // BREAK THE LINKAGE: booting sets the module-level `api` to the CONTROL's taint
  // (bootBundle's `apply`), and that `api` is the BACKING store of the shipped
  // `api` binding. Left as is, `renderFloat` with `slots` undefined would render
  // the control component while `mount()` reset a pool keyed on the control
  // object — measured: the "control" then ran the shipped effect and the old bug
  // did not reproduce. Point `api` back at the shipped copy BEFORE mounting the
  // control, and give the control its own cell pool. (The shipped floats already
  // asserted above are unaffected: effects are re-run from the render result.)
  api = shippedApi
  // Each copy owns its hook-cell pool: the control must start from an EMPTY one,
  // never inherit the shipped float's cells (that would run the shipped effect).
  buggy.api[FLOAT_CELLS_KEY] = {}
  const buggyNode = stubNode()
  const buggyMount = mountFloat(buggy.api, {}, buggy.api)
  const buggyRef = floatNodes(buggyMount.out).find(n => (n.props || {}).ref)
  assert.ok(buggyRef, 'the control float renders a ref')
  buggyRef.props.ref.current = buggyNode
  const buggyLiftEffect = liftOf(buggyMount.queued)
  assert.ok(buggyLiftEffect, 'the control float queues a lift')
  // Guard the CONTROL ITSELF: it must really be the old effect, or the assertion
  // below would measure the shipped one and prove nothing.
  const buggyBody = buggyLiftEffect.toString()
  assert.ok(buggyBody.includes("addEventListener('toggle'"), 'fixture: the control effect carries the old toggle listener')
  buggyLiftEffect()
  assert.strictEqual((buggyNode.listeners.get('toggle') || []).length, 1, 'fixture: and installed it on the node')
  // `toggle` is queued by the stub (the platform dispatches it asynchronously), so
  // the self-close lands one task later — exactly when the user would see it.
  await new Promise(resolve => setTimeout(resolve, 0))
  assert.deepStrictEqual(buggyNode.calls, ['show', 'hide'], 'CONTROL (old toggle listener): the float closes itself immediately after opening — the reported bug; calls=' + JSON.stringify(buggyNode.calls))
  assert.strictEqual(buggyNode.open, false, 'CONTROL: and reports :popover-open === false, i.e. display:none on the real page — which the shipped lift no longer does')
  // The shipped float, in the SAME harness and after the same settle, is open:
  // the pair is the whole proof (same stub, same timing, only the code differs).
  // A FRESH shipped node is used, because its lifecycle above already ended with
  // the deliberate `hide` (c). Show it, keep it mounted, let the queued `toggle`
  // land, and require it still open.
  const proofMount = mount()
  const proofNode = stubNode()
  refFrom(proofMount.out).current = proofNode
  liftOf(proofMount.mine)()
  await new Promise(resolve => setTimeout(resolve, 0))
  assert.deepStrictEqual(proofNode.calls, ['show'], 'SHIPPED, after the same settle: no self-close; calls=' + JSON.stringify(proofNode.calls))
  assert.strictEqual(proofNode.open, true, 'SHIPPED: still :popover-open')
  assert.ok(!proofNode.listeners.has('toggle'), 'SHIPPED: no toggle listener is even installed')
  // (h) DRAG and SCROLL are carried by the same node, so they survive the lift:
  //     assert the two properties that make the drag work inside the top layer.
  const cssFloat = (libSrc.match(/\.dsh-sam-active-float\{([^}]*)\}/) || [])[1] || ''
  const cssOpen = (libSrc.match(/\.dsh-sam-active-float:popover-open\{([^}]*)\}/) || [])[1] || ''
  assert.ok(/position:fixed/.test(cssOpen), 'the open state stays fixed (the UA would otherwise make it a centred box)')
  assert.ok(/margin:0/.test(cssOpen), 'the UA popover margin (-6.857px -13.714px …) is cleared')
  assert.ok(/border:1px solid/.test(cssOpen), 'the UA popover border (2.857px) is replaced by the float\'s own 1px')
  assert.ok(/top:56px/.test(cssOpen) && /right:12px/.test(cssOpen), 'the viewport geometry (top:56px / right:12px) is restated')
  assert.ok(/left:auto/.test(cssOpen) && /bottom:auto/.test(cssOpen), 'and the UA `inset` is pinned so a dragged inline `left` is not fought by a UA default')
  assert.ok(/max-height:calc\(100vh - 24px\)/.test(cssOpen), 'max-height resolves against the viewport in the top layer')
  assert.ok(/overflow:auto/.test(cssOpen), 'and the body still scrolls')
  assert.ok(/max-height:calc\(100vh - 24px\)/.test(cssFloat) && /overflow:auto/.test(cssFloat), 'the plain fixed fallback keeps the same height/scroll contract')
  // The inline style the drag writes is the one that wins in the top layer: an
  // inline declaration beats every selector rule, so `left/top` + `right:auto`
  // land exactly where the pointer put them.
  const dragExpect = { left: 100, top: 200, right: 'auto' }
  const styleWinner = Object.assign({}, { left: '12px', top: '56px' }, dragExpect)
  assert.deepStrictEqual(styleWinner, dragExpect, 'inline drag style (left/top/right:auto) outranks the pinned top/right')
  // (i) the same self-close trap must not exist in the g-028 backdrop either:
  //     its effect never listens for `toggle` (only its own cleanup lowers it).
  assert.ok(!/backdropRef[\s\S]{0,600}?addEventListener\('toggle'/.test(libSrc), 'the panel backdrop installs no toggle listener (g-028 stays as verified)')
  assert.ok(!libSrc.includes("addEventListener('toggle'"), 'no toggle listener survives anywhere in the bundle')
  results.activeFloatTopLayer = { popover: true, control: 'no popover', show: true, staysOpen: true, hide: true, once: true, probed: true, css: true, selfCloseControl: 'show,hide' }
}

// g-032: the injected markdown prompt preview sits slightly narrower than the
// content column and right-aligned, so it no longer presses against the whole
// column. It is plain CSS, so the assertions read the DECODED bundle and pin the
// exact declarations; the control strips them and requires the same predicate to
// reject, which is what makes the assertion able to fail.
const promptBaseCss = (libSrc.match(/\.dsh-sam-prompt\{position:relative;([^}]*)\}/) || [])[1] || ''
const promptNarrowOk = css => /width:calc\(100% - 32px\)/.test(css) && /box-sizing:border-box/.test(css) && /max-width:100%/.test(css) && /margin-left:auto/.test(css) && !/100vw/.test(css) && !/position:fixed/.test(css)
assert.ok(promptNarrowOk(promptBaseCss), 'g-032: .dsh-sam-prompt is content-width minus 32px, border-box and right-aligned; got: ' + promptBaseCss)
const promptMediaCss = (libSrc.match(/@media\(max-width:560px\)\{[^@]*?\.dsh-sam-prompt\{width:100%;margin-left:0[^@]*?\}\}/) || [])[0] || ''
assert.ok(promptMediaCss.length > 0, 'g-032: at <=560px the preview falls back to the full column width')
// Source order matters here: an equal-specificity media rule placed BEFORE the
// base rule is simply overridden by it (measured on the real page), so the
// fallback must come after.
const promptBaseAt = libSrc.indexOf('.dsh-sam-prompt{position:relative;')
const promptFallbackAt = libSrc.indexOf('.dsh-sam-prompt{width:100%;margin-left:0')
assert.ok(promptBaseAt >= 0 && promptFallbackAt > promptBaseAt, 'g-032: the <=560px fallback follows the base rule in source order')
const strippedPromptCss = promptBaseCss.replace(/;?(box-sizing:border-box|max-width:100%|width:calc\(100% - 32px\)|margin-left:auto)/g, '')
assert.ok(!promptNarrowOk(strippedPromptCss), 'g-032 control: stripping the new declarations makes the same assertion reject')
results.promptNarrow = { css: true, media: true, control: true }
// ORDER MATTERS: keep this block before the g-030 section at the end of the
// file. That section installs its own minimal `document` and starts the prompt
// preview's MutationObserver/timers, and the manager fixtures below then
// intermittently see a stale pending commit (measured: 1 in 3 runs failed the
// backdrop assertion before the blocks were ordered this way).
// 11. g-031 — the workspace picker is a self-contained, input-filterable
//     combobox (no third-party component, no second popover). Asserted through
//     the REAL manager component and the built bundle, on a fixture with three
//     discovered cwds: ordering/de-dup, substring filtering with marks, the
//     selection semantics (scope + sessionScope reset + limit reset), the whole
//     keyboard/IME state machine, the no-match and stale/empty-cwd arms, the
//     list's in-panel positioning, and the neighbouring behaviours it must not
//     disturb (backdrop close, batch bar, collapsed filters, row search).
{
  const WS_A = '/home/miuzel/workspace/personal/subagent-ui'
  const WS_B = '/srv/apps/other-project'
  const WS_C = '/work/subagent-ui-demo'
  const wsParent = (id, cwd, name) => ({ id, origin: 'user', title: name, cwd, updatedAt: Date.now() })
  const wsChild = (id, parentId, cwd, name, ageSeconds) => ({ id, parentId, origin: 'subagent', title: name, cwd, updatedAt: Date.now() - (ageSeconds || 0) * 1000, running: false })
  const wsState = () => ({
    byId: {
      p1: wsParent('p1', WS_A, 'Parent A'),
      p2: wsParent('p2', WS_B, 'Parent B'),
      p3: wsParent('p3', WS_C, 'Parent C'),
      'session-wa': wsChild('session-wa', 'p1', WS_A, 'child in A', 1),
      'session-wb': wsChild('session-wb', 'p2', WS_B, 'child in B', 2),
    },
    current: 'p1',
  })
  const wsNoCwd = () => ({
    byId: {
      p1: wsParent('p1', undefined, 'Parent A'),
      p2: wsParent('p2', WS_B, 'Parent B'),
      'session-wa': wsChild('session-wa', 'p1', undefined, 'child in A', 1),
      'session-wb': wsChild('session-wb', 'p2', WS_B, 'child in B', 2),
    },
    current: 'p1',
  })
  const wsRows = view => view.nodes.filter(n => typeof (n.props || {}).className === 'string' && (n.props || {}).className.split(' ').includes('dsh-sam-row'))
  const wsInput = view => view.nodes.find(n => n.tag === 'input' && (n.props || {}).role === 'combobox')
  const wsList = view => view.nodes.find(n => (n.props || {}).role === 'listbox')
  const wsOptionNodes = view => view.nodes.filter(n => (n.props || {}).role === 'option')
  const wsOptionTitles = view => wsOptionNodes(view).map(n => String((n.props || {}).title || ''))
  const wsValue = view => String((wsInput(view) || { props: {} }).props.value || '')
  const wsPress = (view, key, native) => {
    const input = wsInput(view)
    assert.ok(input, 'the combobox input renders')
    input.props.onKeyDown({ key, preventDefault() {}, stopPropagation() {}, nativeEvent: native || {} })
  }
  const wsOpen = async () => {
    wsInput(view).props.onFocus({})
    return commit(wsState(), { open: true })
  }
  const wsPick = async (title) => {
    const current = await wsOpen()
    const option = wsOptionNodes(current).find(n => String((n.props || {}).title) === title)
    assert.ok(option, 'option ' + title + ' exists; got ' + JSON.stringify(wsOptionTitles(current)))
    option.props.onClick()
    return commit(wsState(), { open: true })
  }
  const defaultPrefs = JSON.stringify({ filterCollapsed: false })
  storedPrefs = defaultPrefs
  ledgerPayload = { ok: true, active: [], ended: [] }
  globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ({ ok: true, active: [], ended: [] }) })

  // C1 — ARIA roles and the fixed-first, de-duplicated, path-sorted candidate list.
  cells = {}; childCells = new Map()
  let view = await commit(wsState(), { open: true }, true)
  let input = wsInput(view)
  assert.ok(input, 'C1: the workspace control is an input combobox')
  assert.strictEqual(input.props.role, 'combobox', 'C1: role=combobox')
  assert.strictEqual(input.props['aria-expanded'], false, 'C1: collapsed until focused/clicked')
  assert.strictEqual(input.props['aria-controls'], 'dsh-sam-scope-listbox', 'C1: aria-controls names the listbox')
  assert.strictEqual(input.props['aria-autocomplete'], 'list', 'C1: aria-autocomplete=list')
  assert.ok(!wsList(view), 'C1: no candidate list before focus')
  assert.strictEqual(wsValue(view), '当前工作区', 'C1: the closed control shows the selected scope label')
  input.props.onFocus({})
  view = await commit(wsState(), { open: true })
  input = wsInput(view)
  assert.strictEqual(input.props['aria-expanded'], true, 'C1: focus expands the candidates')
  assert.strictEqual(input.props['aria-activedescendant'], 'dsh-sam-scope-option-0', 'C1: aria-activedescendant points at the active option')
  assert.ok(wsList(view), 'C1: the candidate list renders')
  assert.strictEqual(String(wsList(view).props.id), 'dsh-sam-scope-listbox', 'C1: listbox id is the one aria-controls names')
  assert.deepStrictEqual(wsOptionTitles(view), ['当前工作区', '全部工作区', WS_A, WS_B, WS_C], 'C1: two fixed exits first, then the de-duplicated cwds in path order')
  assert.strictEqual(wsValue(view), '', 'C1: focusing presents an empty query (the label stays in the title/placeholder)')
  results.wsComboboxC1 = { role: 'combobox', options: wsOptionTitles(view).length, order: 'fixed-first' }

  // C2 + C3 — a NON-prefix, case-insensitive substring narrows only the cwds and
  // the hit is rendered with the existing highlight() helper's <mark>.
  input.props.onChange({ target: { value: 'SUBAGENT-UI' } })
  view = await commit(wsState(), { open: true })
  assert.deepStrictEqual(wsOptionTitles(view), ['当前工作区', '全部工作区', WS_A, WS_C], 'C2: middle fragment narrows cwds, both fixed exits stay; B does not match')
  const wsMarks = view.nodes.filter(n => n.tag === 'mark')
  assert.ok(wsMarks.length >= 2, 'C3: hit fragments render as <mark> nodes; marks=' + wsMarks.length)
  assert.ok(wsMarks.some(n => String((n.props || {}).children) === 'subagent-ui'), 'C3: the mark text is the matched fragment (original casing)')
  results.wsComboboxC2 = { filtered: wsOptionTitles(view).slice(2), marks: wsMarks.length }

  // C4 — picking a cwd sets scope='workspace:<cwd>' and the visible rows follow
  // the new workspaceKey; it also returns the SESSION scope to all sessions.
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  assert.strictEqual(wsRows(view).length, 1, 'C4: currentWorkspace shows the current session cwd rows only')
  assert.ok(view.text.join(' ').includes('child in A'), 'C4: child A visible before the switch')
  view = await wsPick(WS_B)
  assert.strictEqual(wsRows(view).length, 1, 'C4: after the switch only the new workspace rows remain')
  assert.ok(view.text.join(' ').includes('child in B') && !view.text.join(' ').includes('child in A'), 'C4: the visible row set followed workspaceKey')
  assert.ok(!wsList(view), 'C4: selecting closes the candidate list')
  assert.strictEqual(wsValue(view), 'other-project', 'C4: the closed control shows the selected basename')
  // sessionScope reset: select session p2 first, then switch workspace; without
  // the reset the new workspaceKey + old sessionScope would yield zero rows.
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  view = await wsPick('全部工作区')
  assert.strictEqual(wsRows(view).length, 2, 'C4: all workspaces exposes both sessions')
  const wsSessionSelect = view.nodes.find(n => n.tag === 'select' && Array.isArray(n.props.children) && n.props.children.some(o => o && (o.props || {}).value === 'all' && String((o.props || {}).children) === '全部会话'))
  assert.ok(wsSessionSelect, 'C4: the session selector still renders as a native select')
  wsSessionSelect.props.onChange({ target: { value: 'p2' } })
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsRows(view).length, 1, 'C4: the session scope narrows to p2 rows')
  assert.ok(view.text.join(' ').includes('child in B'), 'C4: p2 row visible under the session scope')
  input = wsInput(view)
  input.props.onFocus({})
  view = await commit(wsState(), { open: true })
  wsOptionNodes(view).find(n => String((n.props || {}).title) === WS_A).props.onClick()
  view = await commit(wsState(), { open: true })
  assert.ok(view.text.join(' ').includes('child in A'), 'C4: switching workspace reset sessionScope to all (the p1 row is reachable again)')
  results.wsComboboxC4 = { scopeKey: true, sessionReset: true }

  // C4 (pagination) — the same selection resets `limit` to PAGE: 45 rows plus a
  // "load more" click then a workspace pick renders 40/45 again.
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  const manyById = { p1: wsParent('p1', WS_A, 'Parent A'), p2: wsParent('p2', WS_B, 'Parent B') }
  for (let i = 0; i < 45; i += 1) manyById['session-many-' + i] = wsChild('session-many-' + i, 'p1', WS_A, 'many ' + i, i + 1)
  const manyState = () => ({ byId: manyById, current: 'p1' })
  view = await commit(manyState(), { open: true }, true)
  assert.ok(view.text.join(' ').includes('显示 40/45 个'), 'C4: the first page is capped at PAGE')
  const wsMore = view.nodes.find(n => typeof (n.props || {}).className === 'string' && (n.props || {}).className === 'dsh-sam-more')
  assert.ok(wsMore, 'C4: the load-more button exists with 45 rows')
  wsMore.props.onClick()
  view = await commit(manyState(), { open: true })
  assert.ok(view.text.join(' ').includes('显示 45/45 个'), 'C4: load-more raises the limit')
  wsInput(view).props.onFocus({})
  view = await commit(manyState(), { open: true })
  wsOptionNodes(view).find(n => String((n.props || {}).title) === WS_A).props.onClick()
  view = await commit(manyState(), { open: true })
  assert.ok(view.text.join(' ').includes('显示 40/45 个'), 'C4: a workspace pick resets limit to PAGE; text=' + view.text.join(' ').slice(0, 200))
  results.wsComboboxLimit = { before: '45/45', after: '40/45' }

  // C5 — the two fixed exits select currentWorkspace / all respectively.
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  view = await wsPick('全部工作区')
  assert.strictEqual(wsRows(view).length, 2, 'C5: all workspaces shows both rows')
  assert.strictEqual(wsValue(view), '全部工作区', 'C5: the control reflects the all-workspaces selection')
  view = await wsPick('当前工作区')
  assert.strictEqual(wsRows(view).length, 1, 'C5: currentWorkspace narrows back to the current cwd')
  assert.strictEqual(wsValue(view), '当前工作区', 'C5: the control reflects the current-workspace selection')
  results.wsComboboxC5 = { all: 2, current: 1 }

  // C6 — keyboard loop: arrows move the highlight without touching the input,
  // Enter selects it, Esc is two-stage (list first, then the panel).
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  view = await wsOpen()
  const wsStartValue = wsValue(view)
  wsPress(view, 'ArrowDown')
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsInput(view).props['aria-activedescendant'], 'dsh-sam-scope-option-1', 'C6: ArrowDown moves the highlight')
  wsPress(view, 'ArrowDown')
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsInput(view).props['aria-activedescendant'], 'dsh-sam-scope-option-2', 'C6: ArrowDown reaches the first cwd candidate')
  wsPress(view, 'ArrowUp')
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsInput(view).props['aria-activedescendant'], 'dsh-sam-scope-option-1', 'C6: ArrowUp moves back')
  assert.strictEqual(wsValue(view), wsStartValue, 'C6: arrows never change the input value')
  wsPress(view, 'ArrowDown')
  view = await commit(wsState(), { open: true })
  wsPress(view, 'Enter')
  view = await commit(wsState(), { open: true })
  assert.ok(!wsList(view), 'C6: Enter picks the highlighted option and closes the list')
  assert.strictEqual(wsValue(view), 'subagent-ui', 'C6: Enter selected the first cwd candidate')
  assert.ok(view.text.join(' ').includes('child in A'), 'C6: the selection applied (rows follow)')
  // The control stays focused after a pick; typing into it must reopen the
  // candidates instead of being swallowed by the closed state.
  input = wsInput(view)
  input.props.onChange({ target: { value: 'other' } })
  view = await commit(wsState(), { open: true })
  assert.ok(wsList(view), 'C6: typing on the still-focused closed control reopens the candidate list')
  assert.deepStrictEqual(wsOptionTitles(view), ['当前工作区', '全部工作区', WS_B], 'C6: the reopen applies the typed filter')
  wsPress(view, 'Escape')
  view = await commit(wsState(), { open: true })
  // Esc #1: only the list closes, the panel stays open.
  input = wsInput(view)
  input.props.onFocus({})
  view = await commit(wsState(), { open: true })
  assert.ok(wsList(view), 'C6: focused again, candidates open')
  wsPress(view, 'Escape')
  view = await commit(wsState(), { open: true })
  assert.ok(!wsList(view), 'C6: first Esc closes the candidate list')
  assert.ok(view.nodes.some(n => (n.props || {}).className === 'dsh-sam-panel'), 'C6: first Esc leaves the manager panel open')
  wsPress(view, 'Escape')
  view = await commit(wsState(), { open: true })
  assert.ok(!view.nodes.some(n => (n.props || {}).className === 'dsh-sam-panel'), 'C6: the next Esc closes the panel')
  results.wsComboboxC6 = { arrows: true, enter: true, esc: 'two-stage' }

  // C7 — IME composition: Enter/↑/↓ are inert from compositionstart to
  // compositionend, and the keyboard works again after compositionend.
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  view = await wsOpen()
  wsPress(view, 'ArrowDown')
  view = await commit(wsState(), { open: true })
  wsPress(view, 'ArrowDown')
  view = await commit(wsState(), { open: true })
  const wsImeBefore = wsInput(view).props['aria-activedescendant']
  input = wsInput(view)
  input.props.onCompositionStart({})
  input.props.onKeyDown({ key: 'ArrowDown', preventDefault() {}, stopPropagation() {}, nativeEvent: {} })
  input.props.onKeyDown({ key: 'Enter', preventDefault() {}, stopPropagation() {}, nativeEvent: {} })
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsInput(view).props['aria-activedescendant'], wsImeBefore, 'C7: arrows are inert while composing')
  assert.ok(wsList(view), 'C7: Enter does not commit while composing')
  assert.ok(view.text.join(' ').includes('child in A') && !view.text.join(' ').includes('child in B'), 'C7: and the scope did not move')
  // The native `isComposing` flag is honoured too (a browser may omit the events).
  const wsActiveBefore = wsInput(view).props['aria-activedescendant']
  wsPress(view, 'ArrowUp', { isComposing: true })
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsInput(view).props['aria-activedescendant'], wsActiveBefore, 'C7: nativeEvent.isComposing inhibits the arrow')
  // compositionend restores the keyboard.
  input = wsInput(view)
  input.props.onCompositionStart({})
  input.props.onCompositionEnd({})
  input.props.onKeyDown({ key: 'ArrowUp', preventDefault() {}, stopPropagation() {}, nativeEvent: {} })
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsInput(view).props['aria-activedescendant'], 'dsh-sam-scope-option-1', 'C7: after compositionend the arrows work again')
  wsPress(view, 'Enter')
  view = await commit(wsState(), { open: true })
  assert.ok(!wsList(view), 'C7: after compositionend Enter commits')
  assert.ok(view.text.join(' ').includes('child in B'), 'C7: the committed item was 全部工作区 (both rows visible)')
  results.wsComboboxC7 = { composing: 'inert', after: 'restored' }

  // C8 — no match: the notice renders, the fixed exits stay clickable, the input
  // keeps what was typed, and neither the scope nor the row set moves.
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  view = await wsOpen()
  input = wsInput(view)
  input.props.onChange({ target: { value: 'zzz-no-such-workspace' } })
  view = await commit(wsState(), { open: true })
  assert.ok(view.text.join(' ').includes('未发现匹配的工作区'), 'C8: the no-match notice renders')
  assert.deepStrictEqual(wsOptionTitles(view), ['当前工作区', '全部工作区'], 'C8: the fixed exits survive an empty result')
  assert.strictEqual(wsValue(view), 'zzz-no-such-workspace', 'C8: the typed query is not cleared')
  assert.strictEqual(wsRows(view).length, 1, 'C8: the panel row set is unchanged (scope untouched)')
  wsOptionNodes(view).find(n => String((n.props || {}).title) === '全部工作区').props.onClick()
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsRows(view).length, 2, 'C8: a fixed exit is still selectable from the empty result')
  results.wsComboboxC8 = { notice: true, fixed: true, value: 'kept' }

  // C9 — a selected workspace that disappears keeps its selection and says so
  // (no silent fallback to `all`); an empty currentCwd marks the fixed
  // current-workspace option unavailable without throwing.
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  view = await wsPick(WS_B)
  assert.strictEqual(wsValue(view), 'other-project', 'C9: fixture selected WS_B')
  const wsRenamed = () => ({
    byId: {
      p1: wsParent('p1', WS_A, 'Parent A'),
      p2: wsParent('p2', '/srv/apps/renamed-workspace', 'Parent B'),
      p3: wsParent('p3', WS_C, 'Parent C'),
      'session-wa': wsChild('session-wa', 'p1', WS_A, 'child in A', 1),
      'session-wb': wsChild('session-wb', 'p2', '/srv/apps/renamed-workspace', 'child in B', 2),
    },
    current: 'p1',
  })
  view = await commit(wsRenamed(), { open: true })
  assert.ok(wsValue(view).includes('该工作区已不可用'), 'C9: the stale selection is reported in the control; value=' + wsValue(view))
  assert.strictEqual(wsRows(view).length, 0, 'C9: the stale workspace is NOT silently widened to all (0 rows, not 2)')
  input = wsInput(view)
  input.props.onFocus({})
  view = await commit(wsRenamed(), { open: true })
  assert.ok(view.text.join(' ').includes('该工作区已不可用'), 'C9: the open list repeats the degradation notice')
  assert.deepStrictEqual(wsOptionTitles(view), ['当前工作区', '全部工作区', WS_A, '/srv/apps/renamed-workspace', WS_C], 'C9: candidates reflect the new discovery set')
  // empty currentCwd arm
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsNoCwd(), { open: true }, true)
  input = wsInput(view)
  input.props.onFocus({})
  view = await commit(wsNoCwd(), { open: true })
  const wsCurrentOption = wsOptionNodes(view).find(n => String((n.props || {}).title) === '当前工作区')
  assert.ok(wsCurrentOption, 'C9: the current-workspace option is retained with no cwd')
  assert.strictEqual(wsCurrentOption.props['aria-disabled'], 'true', 'C9: it is marked unavailable')
  assert.ok(view.text.join(' ').includes('当前会话没有工作区'), 'C9: the reason is rendered (title/secondary line)')
  wsPress(view, 'Enter')
  view = await commit(wsNoCwd(), { open: true })
  assert.ok(wsList(view), 'C9: Enter on the unavailable option is a no-op instead of throwing')
  assert.strictEqual(wsRows(view).length, 1, 'C9: the existing empty-cwd behaviour is unchanged (workspaceKey undefined => the session scope alone applies)')
  assert.ok(view.text.join(' ').includes('child in A'), 'C9: the row is still rendered with no cwd')
  results.wsComboboxC9 = { stale: 'kept+notice', emptyCwd: 'disabled+no-throw' }

  // C10 — the list is in-panel absolute (never fixed, never a second popover).
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  view = await wsOpen()
  const wsListProps = wsList(view).props
  assert.strictEqual(wsListProps.style.position, 'absolute', 'C10: the candidate list is position:absolute')
  assert.ok(!String(wsListProps.style.position).includes('fixed'), 'C10: never position:fixed')
  assert.strictEqual(wsListProps.popover, undefined, 'C10: the list is not a popover')
  assert.strictEqual(view.nodes.filter(n => (n.props || {}).popover !== undefined).length, 1, 'C10: exactly one popover in the tree (the panel backdrop)')
  assert.ok(/\.dsh-sam-scope-list\{position:absolute/.test(libSrc), 'C10: the stylesheet keeps the list absolute')
  assert.ok(!/\.dsh-sam-scope-list\{[^}]*position:fixed/.test(libSrc), 'C10: no fixed rule for the list')
  assert.ok(/\.dsh-sam-scope-combo\{[^}]*position:relative/.test(libSrc), 'C10: the list is anchored by an in-panel relative container')
  results.wsComboboxC10 = { position: 'absolute', popovers: 1 }

  // C11 — neighbouring behaviours survive: backdrop closes the panel, batch mode
  // still opens its bar, collapsed filters still expand, row search still filters.
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  const backdropNode = view.nodes.find(n => (n.props || {}).className === 'dsh-sam-backdrop')
  assert.ok(backdropNode, 'C11: the backdrop renders')
  const outside = {}
  outside.target = outside
  outside.currentTarget = outside
  backdropNode.props.onMouseDown(outside)
  view = await commit(wsState(), { open: true })
  assert.ok(!view.nodes.some(n => (n.props || {}).className === 'dsh-sam-panel'), 'C11: clicking the backdrop still closes the panel')
  view = await commit(wsState(), { open: true }, true)
  const wsBatch = view.nodes.find(n => typeof (n.props || {}).className === 'string' && (n.props || {}).className.includes('dsh-sam-batch-btn'))
  assert.ok(wsBatch, 'C11: the batch button renders')
  wsBatch.props.onClick()
  view = await commit(wsState(), { open: true })
  assert.ok(view.nodes.some(n => (n.props || {}).className === 'dsh-sam-batch-bar'), 'C11: batch mode still opens the batch bar')
  assert.ok(view.nodes.some(n => n.tag === 'input' && String((n.props || {}).type) === 'checkbox' && String((n.props || {})['aria-label'] || '').startsWith('选择')), 'C11: batch checkboxes render')
  // collapsed filters: the combobox is hidden, the summary line expands them.
  storedPrefs = JSON.stringify({ filterCollapsed: true })
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  const collapsedInfo = view.nodes.find(n => (n.props || {}).className === 'dsh-sam-collapsed-info')
  assert.ok(collapsedInfo, 'C11: the collapsed filter summary renders')
  assert.ok(!wsInput(view), 'C11: the workspace combobox is inside the expandable filter block')
  globalThis.HTMLElement = globalThis.HTMLElement || class HTMLElement {}
  const expandEvent = { target: {}, currentTarget: {} }
  collapsedInfo.props.onClick(expandEvent)
  view = await commit(wsState(), { open: true })
  assert.ok(wsInput(view), 'C11: expanding the filters reveals the combobox again')
  // row search still narrows the list independently of the workspace query.
  storedPrefs = defaultPrefs
  cells = {}; childCells = new Map()
  view = await commit(wsState(), { open: true }, true)
  view = await wsPick('全部工作区')
  assert.strictEqual(wsRows(view).length, 2, 'C11: fixture shows both workspaces before searching')
  const searchInput = view.nodes.find(n => n.tag === 'input' && String((n.props || {}).placeholder || '').startsWith('搜索名称'))
  assert.ok(searchInput, 'C11: the row-search input renders')
  searchInput.props.onChange({ target: { value: 'child in B' } })
  view = await commit(wsState(), { open: true })
  assert.strictEqual(wsRows(view).length, 1, 'C11: row search still filters the list')
  assert.ok(view.text.join(' ').includes('child in B'), 'C11: the matching row is the one shown')
  results.wsComboboxC11 = { backdrop: true, batch: true, collapsed: true, search: true }
}

// Every assertion above has already thrown by the time this line runs, so
/* ================================================================== */
/* g-030: the prompt-preview default switch (semantics B). The preview   */
/* is DOM injection rather than React, so this section installs a        */
/* minimal DOM with exactly the APIs the attach path uses, renders the   */
/* REAL manager to drive the preference, and asserts the injected tree.  */
/* ================================================================== */
const promptTr = (key, params) => {
  const template = zh[key] !== undefined ? zh[key] : `<${key}>`
  return params ? template.replace(/\{(\w+)\}/g, (_, name) => String(params[name] === undefined ? `{${name}}` : params[name])) : template
}
class DomText {
  constructor(value) { this.nodeType = 3; this.nodeValue = String(value); this.parentNode = null; this.childNodes = []; this.children = [] }
  get textContent() { return this.nodeValue }
  set textContent(value) { this.nodeValue = String(value) }
}
class DomClassList {
  constructor(el) { this.el = el }
  add(...names) { for (const name of names) this.el._classes.add(name) }
  remove(...names) { for (const name of names) this.el._classes.delete(name) }
  contains(name) { return this.el._classes.has(name) }
  toggle(name, force) {
    const on = force === undefined ? !this.el._classes.has(name) : Boolean(force)
    if (on) this.el._classes.add(name)
    else this.el._classes.delete(name)
    return on
  }
}
const domMatchesCompound = (el, part) => {
  if (!el || el.nodeType !== 1) return false
  const pattern = /([a-zA-Z][\w-]*)|\.([\w-]+)|\[([\w-]+)(?:=(?:"([^"]*)"|'([^']*)'|([^\]\s]*)))?\]/g
  let match = null
  let seen = 0
  while ((match = pattern.exec(part))) {
    seen += match[0].length
    if (match[1]) { if (el.tagName !== match[1].toUpperCase()) return false; continue }
    if (match[2]) { if (!el.classList.contains(match[2])) return false; continue }
    if (!el.hasAttribute(match[3])) return false
    const value = match[4] !== undefined ? match[4] : match[5] !== undefined ? match[5] : match[6]
    if (value !== undefined && value !== '' && el.getAttribute(match[3]) !== value) return false
  }
  return seen > 0
}
const domMatches = (el, selector) => {
  if (!selector || !el || el.nodeType !== 1) return false
  for (const group of String(selector).split(',')) {
    const parts = group.trim().split(/\s+/).filter(Boolean)
    if (!parts.length) continue
    if (!domMatchesCompound(el, parts[parts.length - 1])) continue
    let index = parts.length - 2
    let node = el.parentNode
    while (index >= 0 && node) {
      if (node.nodeType === 1 && domMatchesCompound(node, parts[index])) index -= 1
      node = node.parentNode
    }
    if (index < 0) return true
  }
  return false
}
class DomElement {
  constructor(tag) {
    this.nodeType = 1
    this.tagName = String(tag).toUpperCase()
    this.childNodes = []
    this.parentNode = null
    this._attrs = new Map()
    this._classes = new Set()
    this._listeners = new Map()
    this._classList = new DomClassList(this)
    this.dataset = {}
    this.scrollTop = 0
    this.scrollHeight = 0
    this.clientHeight = 0
    this.clientWidth = 0
  }
  get classList() { return this._classList }
  get className() { return [...this._classes].join(' ') }
  set className(value) { this._classes = new Set(String(value).split(/\s+/).filter(Boolean)) }
  get children() { return this.childNodes.filter(node => node.nodeType === 1) }
  get parentElement() { return this.parentNode && this.parentNode.nodeType === 1 ? this.parentNode : null }
  get textContent() { return this.childNodes.map(node => node.textContent).join('') }
  set textContent(value) { this.childNodes = []; if (String(value) !== '') this.appendChild(new DomText(value)) }
  setAttribute(name, value) { this._attrs.set(String(name), String(value)) }
  getAttribute(name) { return this._attrs.has(String(name)) ? this._attrs.get(String(name)) : null }
  hasAttribute(name) { return this._attrs.has(String(name)) }
  removeAttribute(name) { this._attrs.delete(String(name)) }
  appendChild(node) { if (node.parentNode) node.parentNode.removeChild(node); node.parentNode = this; this.childNodes.push(node); return node }
  insertBefore(node, ref) {
    const index = ref ? this.childNodes.indexOf(ref) : -1
    if (index < 0) return this.appendChild(node)
    if (node.parentNode) node.parentNode.removeChild(node)
    node.parentNode = this
    this.childNodes.splice(index, 0, node)
    return node
  }
  removeChild(node) {
    const index = this.childNodes.indexOf(node)
    if (index >= 0) this.childNodes.splice(index, 1)
    if (node.parentNode === this) node.parentNode = null
    return node
  }
  remove() { if (this.parentNode) this.parentNode.removeChild(this) }
  after(node) {
    const parent = this.parentNode
    if (!parent) return
    const index = parent.childNodes.indexOf(this)
    if (node.parentNode) node.parentNode.removeChild(node)
    node.parentNode = parent
    parent.childNodes.splice(index + 1, 0, node)
  }
  get isConnected() { let node = this; while (node) { if (node === globalThis.document.body) return true; node = node.parentNode } return false }
  addEventListener(type, handler) { if (!this._listeners.has(type)) this._listeners.set(type, []); this._listeners.get(type).push(handler) }
  dispatch(type, event) { for (const handler of (this._listeners.get(type) || []).slice()) handler(event || {}) }
  matches(selector) { return domMatches(this, selector) }
  closest(selector) { let node = this; while (node) { if (node.nodeType === 1 && domMatches(node, selector)) return node; node = node.parentNode } return null }
  contains(node) { let current = node; while (current) { if (current === this) return true; current = current.parentNode } return false }
  querySelectorAll(selector) {
    const out = []
    const visit = node => { for (const child of node.childNodes) { if (child.nodeType !== 1) continue; if (domMatches(child, selector)) out.push(child); visit(child) } }
    visit(this)
    return out
  }
  querySelector(selector) { return this.querySelectorAll(selector)[0] || null }
  getBoundingClientRect() { return { top: 0, left: 0, right: 0, bottom: 0, width: 0, height: 0 } }
}
class DomMutationObserver {
  constructor(handler) { this.handler = handler }
  observe() {}
  disconnect() {}
  takeRecords() { return [] }
}
const installPromptDom = () => {
  const body = new DomElement('body')
  const doc = {
    body,
    head: new DomElement('head'),
    scrollingElement: null,
    createElement: tag => new DomElement(tag),
    createTextNode: value => new DomText(value),
    querySelectorAll: selector => body.querySelectorAll(selector),
    querySelector: selector => body.querySelector(selector),
    getElementById: id => body.querySelectorAll('[id]').find(node => node.getAttribute('id') === id) || null,
  }
  globalThis.document = doc
  globalThis.window.document = doc
  globalThis.Element = DomElement
  globalThis.MutationObserver = DomMutationObserver
  globalThis.window.getComputedStyle = () => ({ overflowY: 'visible' })
  return doc
}
// One user message as the host renders it: the official node (its own slot) plus
// the action row that carries the copy affordance the chip anchors to.
const promptConversationOf = (doc, sessionId, messages) => {
  const content = doc.createElement('div')
  content.setAttribute('data-conversation-content', '')
  content.setAttribute('data-conversation-session', sessionId)
  const scroll = doc.createElement('div')
  scroll.setAttribute('data-conversation-scroll', '')
  content.appendChild(scroll)
  doc.body.appendChild(content)
  const views = messages.map(message => {
    const node = doc.createElement('div')
    node.setAttribute('data-chat-flow-kind', 'user')
    node.setAttribute('data-chat-node-key', message.key)
    const official = doc.createElement('div')
    official.setAttribute('data-slot', 'conversation.chat.node')
    const body = doc.createElement('span')
    body.setAttribute('data-context-text', 'true')
    body.textContent = message.body === undefined ? message.text : message.body
    official.appendChild(body)
    const row = doc.createElement('div')
    row.setAttribute('data-clock', '')
    const copy = doc.createElement('button')
    copy.setAttribute('aria-label', '复制')
    copy.textContent = '复制'
    row.appendChild(copy)
    node.appendChild(official)
    node.appendChild(row)
    scroll.appendChild(node)
    return { node, official, body, row, copy }
  })
  return { content, scroll, views }
}
const promptFeedOf = messages => ({
  eventSource: {
    getSnapshot: () => ({
      entries: messages.map((message, index) => ({
        type: 'event',
        event: { type: 'user/message', surfaceOp: 'append', seq: index + 1, data: { id: message.id, source: { kind: 'user' }, content: [{ type: 'text', text: message.text }] } },
      })),
    }),
    subscribe: () => () => {},
  },
})
const promptCheckboxFor = (view, label) => {
  for (const node of view.nodes) {
    if (node.tag !== 'label' || !Array.isArray(node.props.children)) continue
    const input = node.props.children.find(child => child && child.tag === 'input')
    const text = node.props.children.filter(child => typeof child === 'string').join('')
    if (input && text === label) return input
  }
  return null
}
const promptBlocksOf = doc => doc.querySelectorAll('[data-dsh-sam-prompt-block]')
const promptChipsOf = doc => doc.querySelectorAll('[data-dsh-sam-prompt-trigger]')
const promptStateOf = block => block.getAttribute('data-dsh-sam-prompt-state')
const promptBlocksHidden = block => block.classList.contains('dsh-sam-prompt-block-hidden')
const PROMPT_SESSION = 'session-c1'
const PROMPT_SESSION_2 = 'session-c2'
const promptMessages = [
  { id: 'm1', key: '1:input-messagem1', text: '# 标题\n\n第一段 **粗体** 文本。' },
  { id: 'm2', key: '2:input-messagem2', text: '第二条消息，含 `code`。' },
]
const promptFeed = promptFeedOf(promptMessages)
const dualStateFor = () => ({
  byId: { ...stateFor().byId, [PROMPT_SESSION_2]: { id: PROMPT_SESSION_2, parentId: 'p1', origin: 'subagent', title: 'second child', cwd: '/work', updatedAt: Date.now() } },
  current: 'p1',
  projectionsBySession: stateFor().projectionsBySession,
})

// ---- C7: the switch has exactly ONE writer (the manager) ------------------
{
  const seed = { tabs: [{ id: 'tab-custom', name: '自定义', regex: '^审计' }], archived: ['session-ghost'], archivedParents: { 'session-ghost': 'p1' }, removedExternal: ['ext-ghost'], showArchived: true, hideOneShot: true, hideOld: true, oldDays: 12, liveCap: 2, activeFloat: false, activeFloatLive: false, customSubagentBg: true, subagentBgLight: '#112233', subagentBgDark: '#445566', filterCollapsed: false, showDetails: false }
  storedPrefs = JSON.stringify(seed)
  let view = await commit(stateFor(), { open: true }, true)
  const box = promptCheckboxFor(view, zh.promptPreview)
  assert.ok(box, 'C7: the prompt-preview checkbox renders with its own localized label')
  assert.strictEqual(box.props.checked, true, 'C7: an absent key reads as ON')
  box.props.onChange()
  await commit(stateFor(), { open: true })
  assert.deepStrictEqual(JSON.parse(storedPrefs), { ...seed, promptPreview: false }, 'C7: every pre-existing prefs field survives the switch byte-for-byte, the switch adds only its own key')
  view = await commit(stateFor(), { open: true }, true)
  assert.strictEqual(promptCheckboxFor(view, zh.promptPreview).props.checked, false, 'C7: a remount (page refresh) reads the stored OFF state back')
  assert.deepStrictEqual(JSON.parse(storedPrefs), { ...seed, promptPreview: false }, 'C7: the remount neither drops nor rewrites a stored field')
  results.promptPreviewPrefs = { preserved: true, onlyKey: 'promptPreview' }
}

// ---- C1: a stored prefs record without the key keeps v1.10.0 behaviour -----
const promptDoc = installPromptDom()
state = stateFor()
storedPrefs = JSON.stringify({ filterCollapsed: false, showDetails: false })
api.promptSetDefaultMode(api.PROMPT_MODE_RAW)
api.promptMode.clear()
let promptManagerView = await commit(stateFor(), { open: true }, true)
assert.strictEqual(api.promptDefaultModeOf(), api.PROMPT_MODE_RENDERED, 'C1: a prefs record without promptPreview means ON')
promptBindingFor = id => (id === PROMPT_SESSION ? promptFeed : null)
const promptConversation = promptConversationOf(promptDoc, PROMPT_SESSION, promptMessages)
const promptAnchor = promptDoc.createElement('span')
promptAnchor.className = 'dsh-sam-prompt-host'
promptDoc.body.appendChild(promptAnchor)
let promptDispose = api.promptPreviewAttach(promptAnchor, PROMPT_SESSION, () => promptTr)
let promptBlocks = promptBlocksOf(promptDoc)
let promptChips = promptChipsOf(promptDoc)
assert.strictEqual(promptBlocks.length, 2, 'C1: one preview block per user message; got ' + promptBlocks.length)
assert.strictEqual(promptChips.length, 2, 'C1: one 「渲染/原文」 chip per user message')
for (const block of promptBlocks) {
  assert.strictEqual(promptStateOf(block), 'rendered', 'C1: the default landing state is rendered')
  assert.ok(!promptBlocksHidden(block), 'C1: the block is visible')
  assert.ok(block.querySelector('[data-dsh-sam-prompt-body]'), 'C1: the markdown body exists')
}
assert.ok(promptBlocks[0].textContent.includes('标题') && promptBlocks[0].textContent.includes('粗体'), 'C1: the markdown body is the message text')
for (const view of promptConversation.views) assert.ok(view.official.classList.contains('dsh-sam-prompt-hide'), 'C1: the official node is hidden exactly as before')
for (const chip of promptChips) assert.ok(!chip.classList.contains('dsh-sam-prompt-trigger-on'), 'C1: the chip keeps its rendered-state form')

// ---- C2: switch OFF — no reload, blocks to raw, chips kept (B, not A) -----
const promptBlocksBeforeSwitch = promptBlocks.slice()
promptCheckboxFor(promptManagerView, zh.promptPreview).props.onChange()
promptManagerView = await commit(stateFor(), { open: true })
assert.strictEqual(api.promptDefaultModeOf(), api.PROMPT_MODE_RAW, 'C2: the switch reaches the prompt module without a reload')
assert.strictEqual(JSON.parse(storedPrefs).promptPreview, false, 'C2: the manager is the single writer and persisted the switch')
promptBlocks = promptBlocksOf(promptDoc)
promptChips = promptChipsOf(promptDoc)
assert.strictEqual(promptBlocks.length, 2, 'C2: both blocks stay in the document')
assert.ok(promptBlocks.every((block, index) => block === promptBlocksBeforeSwitch[index]), 'C2: the same block elements were restyled, not rebuilt')
for (const block of promptBlocks) {
  assert.strictEqual(promptStateOf(block), 'raw', 'C2: every block lands on the raw default')
  assert.ok(promptBlocksHidden(block), 'C2: the block is hidden')
}
for (const view of promptConversation.views) assert.ok(!view.official.classList.contains('dsh-sam-prompt-hide'), 'C2: no dsh-sam-prompt-hide residue — the official text is visible')
assert.strictEqual(promptChips.length, 2, 'C2: the 「渲染/原文」 chips still exist (proves B, not A)')
for (const chip of promptChips) assert.ok(chip.classList.contains('dsh-sam-prompt-trigger-on'), 'C2: the raw state shows the 「预览」 chip')

// ---- C3: one message switched back to rendered, in memory only ------------
const chipForM1 = promptChips.find(chip => chip.getAttribute('data-dsh-sam-prompt-key') === '1:input-messagem1')
assert.ok(chipForM1, 'C3: the first message has its own chip')
const prefsBeforePerMessage = storedPrefs
chipForM1.dispatch('pointerdown', {})
assert.strictEqual(promptStateOf(promptBlocks[0]), 'rendered', 'C3: only the clicked message switches to rendered')
assert.ok(!promptBlocksHidden(promptBlocks[0]), 'C3: its block is visible')
assert.ok(promptConversation.views[0].official.classList.contains('dsh-sam-prompt-hide'), 'C3: its official node is hidden')
assert.strictEqual(promptStateOf(promptBlocks[1]), 'raw', 'C3: the other message stays raw')
assert.ok(promptBlocksHidden(promptBlocks[1]), 'C3: its block stays hidden')
assert.ok(!promptConversation.views[1].official.classList.contains('dsh-sam-prompt-hide'), 'C3: its official node stays visible')
assert.strictEqual(storedPrefs, prefsBeforePerMessage, 'C3: a per-message choice never writes localStorage')
assert.strictEqual(api.promptMode.get('1:input-messagem1'), 'rendered', 'C3: the override lives in the in-memory map')

// ---- C3/C5: a reload (cold module boot) reads the saved pref, not the map --
promptDispose()
const freshPromptApi = bootBundle(libSrc.replace("return {inject:['sessions','slots','locale'],apply}", "return {inject:['sessions','slots','locale'],apply, promptPreviewAttach, promptDefaultModeOf, promptMode, PROMPT_MODE_RAW, PROMPT_MODE_RENDERED}"), {})
globalThis.window.__ModuleLoader__ = shippedLoader
api = shippedApi
assert.strictEqual(freshPromptApi.api.promptDefaultModeOf(), 'raw', 'C5: a cold boot reads the saved OFF preference at module init')
assert.strictEqual(freshPromptApi.api.promptMode.size, 0, 'C3: a reload drops the per-message override — it is memory only')
const freshAnchor = promptDoc.createElement('span')
promptDoc.body.appendChild(freshAnchor)
const freshDispose = freshPromptApi.api.promptPreviewAttach(freshAnchor, PROMPT_SESSION, () => promptTr)
const freshBlocks = promptBlocksOf(promptDoc)
assert.strictEqual(freshBlocks.length, 2, 'C5: the preview is re-injected after the reload')
for (const block of freshBlocks) assert.strictEqual(promptStateOf(block), 'raw', 'C5: every message is raw by default after the reload')
for (const view of promptConversation.views) assert.ok(!view.official.classList.contains('dsh-sam-prompt-hide'), 'C5: no hide residue after the reload')
freshDispose()

// ---- C4: switch back ON — live, and it clears every per-message override ---
promptDispose = api.promptPreviewAttach(promptAnchor, PROMPT_SESSION, () => promptTr)
promptBlocks = promptBlocksOf(promptDoc)
assert.strictEqual(promptStateOf(promptBlocks[0]), 'rendered', 'fixture: the in-memory override survived the re-attach')
assert.strictEqual(promptStateOf(promptBlocks[1]), 'raw', 'fixture: the un-clicked message is still raw')
promptManagerView = await commit(stateFor(), { open: true }, true)
assert.strictEqual(promptCheckboxFor(promptManagerView, zh.promptPreview).props.checked, false, 'fixture: the saved OFF state survived the reload')
promptCheckboxFor(promptManagerView, zh.promptPreview).props.onChange()
await commit(stateFor(), { open: true })
assert.strictEqual(api.promptDefaultModeOf(), api.PROMPT_MODE_RENDERED, 'C4: switch back on is live')
assert.strictEqual(api.promptMode.size, 0, 'C4: the switch clears every per-message override')
promptBlocks = promptBlocksOf(promptDoc)
for (const block of promptBlocks) {
  assert.strictEqual(promptStateOf(block), 'rendered', 'C4: every message is rendered again')
  assert.ok(!promptBlocksHidden(block), 'C4: no hidden residue')
}
for (const view of promptConversation.views) assert.ok(view.official.classList.contains('dsh-sam-prompt-hide'), 'C4: the official nodes are hidden again')

// ---- C6: two attached mounts follow ONE switch (no single-side residue) ----
// The real pair is the same session mounted in the main pane and in the stock
// sidebar chat tab. `promptContainerFor` resolves one container per session id,
// so this harness cannot mount the SAME id twice; two child sessions exercise
// the same `promptSyncs` fan-out the real pair uses.
state = dualStateFor()
promptBindingFor = id => (id === PROMPT_SESSION || id === PROMPT_SESSION_2 ? promptFeed : null)
const promptConversation2 = promptConversationOf(promptDoc, PROMPT_SESSION_2, promptMessages)
const promptAnchor2 = promptDoc.createElement('span')
promptDoc.body.appendChild(promptAnchor2)
const promptDispose2 = api.promptPreviewAttach(promptAnchor2, PROMPT_SESSION_2, () => promptTr)
assert.strictEqual(promptBlocksOf(promptDoc).length, 4, 'C6: both mounts injected their blocks')
promptManagerView = await commit(dualStateFor(), { open: true }, true)
assert.strictEqual(promptCheckboxFor(promptManagerView, zh.promptPreview).props.checked, true, 'fixture: the saved ON state survived the reload')
promptCheckboxFor(promptManagerView, zh.promptPreview).props.onChange()
await commit(dualStateFor(), { open: true })
const dualBlocks = promptBlocksOf(promptDoc)
assert.strictEqual(dualBlocks.length, 4, 'C6: both mounts keep their blocks')
for (const block of dualBlocks) {
  assert.strictEqual(promptStateOf(block), 'raw', 'C6: both mounts follow the one switch')
  assert.ok(promptBlocksHidden(block), 'C6: both blocks hidden')
}
for (const view of [...promptConversation.views, ...promptConversation2.views]) assert.ok(!view.official.classList.contains('dsh-sam-prompt-hide'), 'C6: no single-side hide residue')
promptDispose2()
promptDispose()

// ---- C8: fail-closed shapes, both defaults, no throw ----------------------
for (const mode of ['raw', 'rendered']) {
  const pageA = installPromptDom()
  api.promptSetDefaultMode(mode)
  api.promptMode.clear()
  state = { byId: { p1: { id: 'p1', origin: 'user', title: 'Parent', cwd: '/work', updatedAt: Date.now() } }, current: 'p1' }
  promptBindingFor = () => promptFeed
  promptConversationOf(pageA, 'p1', promptMessages)
  const anchorA = pageA.createElement('span')
  pageA.body.appendChild(anchorA)
  const disposeA = api.promptPreviewAttach(anchorA, 'p1', () => promptTr)
  assert.strictEqual(promptBlocksOf(pageA).length, 0, 'C8[' + mode + '] non-subagent session: no block injected')
  assert.strictEqual(promptChipsOf(pageA).length, 0, 'C8[' + mode + '] non-subagent session: no chip injected')
  disposeA()
}
for (const mode of ['raw', 'rendered']) {
  const pageB = installPromptDom()
  api.promptSetDefaultMode(mode)
  api.promptMode.clear()
  state = stateFor()
  promptBindingFor = () => promptFeed
  promptConversationOf(pageB, PROMPT_SESSION, [])
  const anchorB = pageB.createElement('span')
  pageB.body.appendChild(anchorB)
  const disposeB = api.promptPreviewAttach(anchorB, PROMPT_SESSION, () => promptTr)
  assert.strictEqual(promptBlocksOf(pageB).length, 0, 'C8[' + mode + '] host renders no user node: nothing injected')
  assert.strictEqual(promptChipsOf(pageB).length, 0, 'C8[' + mode + '] host renders no user node: no chip')
  disposeB()
}
for (const mode of ['raw', 'rendered']) {
  const pageC = installPromptDom()
  api.promptSetDefaultMode(mode)
  api.promptMode.clear()
  state = stateFor()
  promptBindingFor = () => null
  const anchorC = pageC.createElement('span')
  pageC.body.appendChild(anchorC)
  const disposeC = api.promptPreviewAttach(anchorC, PROMPT_SESSION, () => promptTr)
  assert.strictEqual(promptBlocksOf(pageC).length, 0, 'C8[' + mode + '] no binding and no conversation body: nothing to inject into, no throw')
  disposeC()
}
// Known, pre-existing (g-023) shape, recorded rather than changed here: when a
// user node IS on screen but this plugin holds no binding, the accepted DOM
// fallback still previews that node's own body (source=dom). Nothing is
// fabricated and nothing throws.
const pageD = installPromptDom()
api.promptSetDefaultMode('rendered')
api.promptMode.clear()
state = stateFor()
promptBindingFor = () => null
const conversationD = promptConversationOf(pageD, PROMPT_SESSION, promptMessages)
const anchorD = pageD.createElement('span')
pageD.body.appendChild(anchorD)
const disposeD = api.promptPreviewAttach(anchorD, PROMPT_SESSION, () => promptTr)
const domBlocks = promptBlocksOf(pageD)
assert.strictEqual(domBlocks.length, 2, 'C8-note: with a user node on screen but no binding, the pre-existing DOM fallback still previews (g-023, unchanged)')
for (const block of domBlocks) assert.strictEqual(block.getAttribute('data-dsh-sam-prompt-source'), 'dom', 'C8-note: the fallback reads the node own body, never a neighbour record')
for (const view of conversationD.views) assert.ok(view.official.classList.contains('dsh-sam-prompt-hide'), 'C8-note: rendered state hides the official node it replaces')
disposeD()
results.promptPreviewSwitch = {
  c1: 'absent key = ON, block visible + chip + hide class',
  c2: 'OFF live: blocks hidden, chips kept, no hide residue',
  c3: 'one message rendered, rest raw, prefs untouched',
  c5: 'cold boot reads prefs; override dropped',
  c4: 'ON live: all rendered, overrides cleared',
  c6: 'two mounts, one switch, no single-side residue',
  c8: 'non-subagent / no nodes / no container: nothing injected, no throw',
  c8note: 'no binding + on-screen node: g-023 DOM fallback previews (source=dom), unchanged',
}
// reaching it means the harness passed: exit 0 explicitly, because the plugin's
// pollers leave live timers behind and the event loop would otherwise never
// drain. A failing run throws first and keeps its non-zero status.
console.log(JSON.stringify(results, null, 1))
process.exit(0)
