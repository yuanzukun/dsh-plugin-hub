import { NS, zh, en } from './i18n'
import { Manager } from './manager'
import { PromptPreview } from './prompt-view'
import { retainReleaseAll } from './retain'
import type { LineageShadowProps, PluginCtx, UiWorkspaceRuntime } from './types'
// Navigation capability probe. Order matters: sessions.openSubagent(address) is
// object-capable and present through 0.1.6-alpha.1, while uiWorkspace.openSession
// only accepts a SessionTarget from 0.1.6-alpha.2 on (before that it is
// openSession(sessionId) -> sessions.open(id) and throws on an address), so
// uiWorkspace is the fallback for the hosts where the sessions methods are gone.
const uiWorkspaceOf=ctx=>{try{const ws=ctx.get?.('uiWorkspace');return typeof ws?.openSession==='function'?ws:null}catch{return null}}
// Optional-service probe. Every right-sidebar face is optional here: an absent
// service must degrade to "no sidebar button", never to a plugin that fails to
// activate (the manager itself has to keep working on hosts without a sidebar).
const serviceOf=(ctx,name)=>{try{const value=ctx.get?.(name);return value??null}catch(error){console.warn('subagent-workspace-ui: service probe failed for',name,error);return null}}
// Lineage shadow. The manager reuses the stock ui-subagent plugin (its
// right-sidebar chat tab is what the new button opens), so that plugin stays
// enabled and this registration is what keeps its lineage dropdown invisible: a
// `single` slot renders its lowest-priority winner, and -1 outranks the stock
// registration's default 0 without colliding with it.
//
// The shadow renders no dropdown. It DOES re-render the breadcrumb title for a
// crumb that is itself a subagent session, because `renderSlot` REPLACES the
// caller's fallback once an entry exists (the conversation draws the title
// itself for every other crumb, so those must render nothing here): a literally
// empty shadow would delete the current subagent session's title from the
// header. The title is drawn with the conversation's own crumb metrics (see the
// dsh-sam-lineage-* rules in styles.ts) and keeps the ancestor-crumb click that
// the fallback button had.
const LineageShadow=({displayTitle,lineageSessionId,useSessions,openTitle}:LineageShadowProps)=>{
  const isSubagent=typeof useSessions==='function'?useSessions(s=>s?.byId?.[lineageSessionId]?.origin==='subagent'):false
  if(!isSubagent||!displayTitle)return null
  const open=typeof openTitle==='function'?openTitle:null
  return jsx('button',{type:'button',className:open?'dsh-sam-lineage-title':'dsh-sam-lineage-title dsh-sam-lineage-current',disabled:!open,title:displayTitle,onClick:open||undefined,children:displayTitle})
}
// Header-actions shadow. The stock ui-subagent plugin registers a SECOND entry
// into `conversation.session.header.actions` — `id: "subagent-catalog"`,
// `order: -30` — which draws the official "N subagents" count dropdown as soon
// as the current session's catalog projection is loaded. That registration
// arrived in dsh 0.1.7-rc.1 and never collided with the manager, because a `list`
// slot gives every `id` its own cell: the manager owns
// `subagent-workspace-manager` and the stock catalog owned its own, so both
// showed. The manager already covers this surface, so the declarative shadow is
// extended to it: a cell renders its lowest-priority live entry, and -1 outranks
// the stock registration's default 0 without colliding with it (the stock
// plugin's four other registrations, including the `subagentchat` right-sidebar
// tab the manager reuses, are untouched). This entry renders nothing.
const CatalogShadow=()=>null
// Shared by both shadows. The slots core rejects a second registration at a
// (cell, priority) pair that is already taken, so a host that later ships its
// own lineage entry or its own `subagent-catalog` at -1 must cost that shadow
// only. The inject callback runs inside the host's effect machinery, where an
// escaping throw tears down the injection — and the synchronous one from
// `inject` itself would fail the whole apply — so catch, warn, and leave the
// official entry visible instead.
const registerShadow=(ctx,slot,options,component)=>ctx.slots.inject(slot,()=>{
  try{return ctx.slots.register(options,component)}
  catch(error){console.warn('subagent-workspace-ui: unable to shadow',options.id??slot,error);return()=>{}}
})
// Canonical `subagentchat` resource address. The stock ui-subagent bundle keeps
// both the prefix and its builder inside its own module closure (it exports only
// `inject` and `apply`, so `require()` cannot hand the builder over), which
// leaves rebuilding the address in the canonical form its tab type parses. The
// rebuild is never trusted on its own: `sidebarRightTabs.candidates(address)`
// runs that type's own `canOpen` — which re-parses the parent and the routing
// mode — before a row offers the button at all, so a drifted format degrades to
// an unavailable button instead of throwing when the user clicks.
const SUBAGENT_CHAT_PREFIX='dsh-resource://subagentchat/session/'
const subagentChatAddressOf=address=>`${SUBAGENT_CHAT_PREFIX}${encodeURIComponent(address.childSessionId)}?${new URLSearchParams({parent:address.parentSessionId,mode:address.mode})}`
export function apply(ctx:PluginCtx){
  sessionsRt=ctx.sessions
  ctx.effect(()=>ctx.locale.register(NS,{zh,en}),'subagent-workspace-ui: dictionaries')
  // Plugin disposal is the last paired release: nothing may outlive the surfaces.
  ctx.effect(()=>()=>retainReleaseAll(),'subagent-workspace-ui: retained live bindings')
  // Catalog hooks are optional host capability, probed at every call and never
  // version-checked: dsh 0.1.7-rc.1 removed setSubagentCatalogOpen outright and
  // replaced refreshSubagents(parentSessionId) with refreshProjections(sessionId)
  // (same session argument, "load all Session projections once per connection"),
  // so an unguarded call threw out of the panel's open effect and the React error
  // boundary killed the whole header slot. Both stay plain functions (the manager
  // calls them unconditionally), turning into a no-op on a host that publishes
  // neither, and the refresh prefers the replacement so a 0.1.7 host still pulls
  // the parent catalog the panel needs. A projection read is fire-and-forget: the
  // UI re-reads the store, so a failed load already falls back to the existing
  // "type loading" text and must not surface as an unhandled rejection.
  const fireAndForget=pending=>{if(pending&&typeof pending.catch==='function')pending.catch(error=>console.warn('subagent-workspace-ui: unable to refresh session projections',error))},
    refreshCatalog=p=>{if(typeof ctx.sessions?.refreshProjections==='function'){fireAndForget(ctx.sessions.refreshProjections(p));return}if(typeof ctx.sessions?.refreshSubagents==='function')fireAndForget(ctx.sessions.refreshSubagents(p))}
  const actions={openChild:a=>{if(typeof ctx.sessions?.openSubagent==='function'){ctx.sessions.openSubagent(a);return true}const ws=uiWorkspaceOf(ctx);if(ws){ws.openSession(a);return true}if(a?.childSessionId)return actions.openSession(a.childSessionId);return false},openSession:id=>{if(typeof ctx.sessions?.open==='function'){ctx.sessions.open(id);return true}const ws=uiWorkspaceOf(ctx);if(ws){ws.openSession(id);return true}return false},refresh:refreshCatalog,setCatalogOpen:(p,o)=>{if(typeof ctx.sessions?.setSubagentCatalogOpen==='function')ctx.sessions.setSubagentCatalogOpen(p,o)}}
  // The right-sidebar faces are resolved per call, never once at activation:
  // dsh 0.1.7-rc.1 publishes sidebarRight/sidebarRightTabs after this plugin's
  // apply runs, so a one-time probe silently removed the row's sidebar button on
  // that host. A host that never publishes them keeps the previous surface
  // (`undefined` renders no button at all), while an available face whose row
  // address does not validate keeps the existing disabled button.
  const sidebarServices=()=>{const sidebarRight=serviceOf(ctx,'sidebarRight'),tabs=serviceOf(ctx,'sidebarRightTabs'),sessions=ctx.sessions;return typeof sidebarRight?.openResource==='function'&&typeof tabs?.candidates==='function'&&typeof sessions?.subagentAddress==='function'?{sidebarRight,tabs,sessions}:null},
    asideAddressOf=row=>{
      const services=sidebarServices()
      if(!services)return undefined
      try{
        const address=services.sessions.subagentAddress(row.id)
        if(!address||!address.parentSessionId||!address.childSessionId||!address.mode)return null
        const value=subagentChatAddressOf(address)
        if(services.tabs.candidates(value).length===0)return null
        return value
      }catch(error){console.warn('subagent-workspace-ui: unable to resolve a sidebar address',error);return null}
    },
    openAside=address=>{
      // `preferNewPane` is the placement the stock "open aside" action uses, so a
      // split-capable column keeps the main conversation visible. openResource
      // expands the column itself; toggling it here would fight that.
      const services=sidebarServices()
      if(!services)return false
      try{services.sidebarRight.openResource(address,{preferNewPane:true});return true}catch(error){console.warn('subagent-workspace-ui: unable to open the sidebar resource',address,error);return false}
    },
    face=()=>({...actions,asideAddressOf,openAside})
  ctx.slots.inject('conversation.session.header.actions',()=>ctx.slots.register({name:'conversation.session.header.actions',id:'subagent-workspace-manager',order:100,locale:NS,inject:face},Manager))
  // g-023 prompt preview. A second, headless cell in the same list slot: the
  // component renders one hidden anchor and drives DOM injection into the chat
  // flow of the conversation it belongs to (see prompt-view.ts). A list cell of
  // its own keeps the official `conversation.chat.node` renderer untouched, and
  // the cell is inert on any host that renders no user nodes.
  ctx.slots.inject('conversation.session.header.actions',()=>ctx.slots.register({name:'conversation.session.header.actions',id:'subagent-prompt-preview',order:101,locale:NS},PromptPreview))
  registerShadow(ctx,'conversation.session.header.actions',{name:'conversation.session.header.actions',id:'subagent-catalog',priority:-1},CatalogShadow)
  registerShadow(ctx,'conversation.session.header.lineage',{name:'conversation.session.header.lineage',priority:-1},LineageShadow)
}
