# 变更记录

本项目按语义化版本记录用户可见变化。

## 0.1.7 - 2026-10-27

- 将 DSH 宿主兼容范围与固定的开发测试版本分离，统一声明 `>=0.2.1-rc.2 <0.2.2-0`，修复 rc.3 安装时被精确 peer 版本拒绝的问题。
- 保持业务代码与 DSH 开发依赖不变，补充兼容范围边界和清单一致性回归测试。
- 更新中英文安装说明，区分已验证版本与范围内尚未实测版本。

## 0.1.6 - 2026-10-18

- 适配并限定验证基线为 DeepSeek Harness 0.2.1-rc.2；对齐 Cordis 4.0.5、Schemastery 3.18.5 和 DSH 组件依赖。
- 对齐 0.1.5 已发布制品的 MCP 启动入口、插件 patch 和 auto 认证模式，修复源码重新构建时的功能回退。
- 清除 API Key 或取消 OAuth 后检查有效凭据；环境变量等来源仍生效时明确提示，避免误报成功及错误切换。
- 修复 JSX / DOM 类型配置，从插件入口回归 MCP 连接、工具调用、4 个 Skill 注册及卸载。
- 通过新版 DSH 隔离安装、设置页与认证弹窗验证；本次仅生成下载制品，不发布 npm。

## 0.1.5 - 2026-09-04

- 适配 DeepSeek Harness 0.1.2-rc.1：设置页使用 Remote 凭据接口，移除已下线的 client-runtime 加载依赖。
- 跟随新版 credentials/reference-updated 事件，在保存或移除 API Key、发起或取消 OAuth 后更新连接状态。
- 使用新版 Cordis、UI renderer 和工具类型验证插件，补充 Remote 成功/失败与凭据变化回归测试。
- 最低支持版本调整为 DSH 0.1.2-rc.1；旧版 DSH 请继续使用插件 0.1.4。

## 0.1.4 - 2026-08-25

### 新增

- 公开仓库 CI、依赖更新配置、安全策略、贡献指南和行为准则。
- HTTP 请求超时、工具发现分页边界、重复 cursor 检查和日志脱敏。
- OAuth loopback 回调安全响应头与测试覆盖率门禁。
- 混合许可范围说明、DeepSeek Harness 完整 MIT 声明和英文 README。

### 变更

- 非本机 MCP endpoint 现在强制使用 HTTPS。
- 工具整代注册失败时尝试恢复上一代工具。
- 插件版本从 `package.json` 统一注入服务端和客户端。
- 构建改为生成可审计的 source map，不再混淆服务端代码。
- 升级 `@modelcontextprotocol/sdk` 至 1.30.0、`yaml` 至 2.9.0，并将 Node 类型对齐 22.x。

### 移除

- 移除来源未记录的 `assets/scale.svg`，设置导航使用 Unicode 天平符号。
