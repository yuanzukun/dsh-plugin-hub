# Changelog

All notable changes to this plugin are documented here.

## 1.0.0 — 2026-08-30

- Initial release: register the MathWorks MATLAB/Simulink MCP server into a
  DeepSeek Harness profile, giving agent sessions `mcp__matlab__*` tools for
  controlling MATLAB and reading, building, and testing Simulink models.
- Cross-platform one-click installers (`install.ps1` / `install.sh`) with
  prerequisite checks and profile selection.
