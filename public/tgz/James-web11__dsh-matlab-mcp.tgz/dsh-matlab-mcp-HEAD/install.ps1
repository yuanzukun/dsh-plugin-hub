# dsh-matlab-mcp — one-click setup (Windows / PowerShell)
# Registers the MathWorks MATLAB/Simulink MCP server into a DeepSeek Harness
# profile so agent sessions get mcp__matlab__* tools.
#
# Usage:
#   .\install.ps1                 # install into the default "web" profile
#   .\install.ps1 -Profile tui    # install into another profile
#   .\install.ps1 -DshCommand npx -SkipChecks  # advanced: explicit launcher
param(
  [string]$Profile = "web",
  [string]$DshCommand = "",
  [switch]$SkipChecks
)
$ErrorActionPreference = "Stop"

function Find-DshLauncher {
  if ($DshCommand) { return $DshCommand }
  $cmd = Get-Command dsh -ErrorAction SilentlyContinue
  if ($cmd) { return "dsh" }
  # fall back to npx (reuses the local @deepseek-ai/dsh cache)
  if (Get-Command npx -ErrorAction SilentlyContinue) { return "npx -y @deepseek-ai/dsh" }
  throw "Cannot find the dsh launcher. Install it (npm i -g @deepseek-ai/dsh) or pass -DshCommand."
}

Write-Host "== dsh-matlab-mcp installer ==" -ForegroundColor Cyan

# --- pnpm: required by `dsh plugin` (it forwards pnpm args) ---
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
  Write-Warning "pnpm was not found on PATH. `dsh plugin` forwards to pnpm."
  Write-Warning "Install it first:  npm install -g pnpm"
  throw "pnpm is required."
}

# --- prerequisites ---
if (-not $SkipChecks) {
  $toolkitRoot = Join-Path $env:USERPROFILE ".matlab\agentic-toolkits"
  $bin = Join-Path $toolkitRoot "bin\matlab-mcp-server.exe"
  if (-not (Test-Path $bin)) {
    throw "matlab-mcp-server.exe not found at $bin.`nInstall the MATLAB Agentic Toolkit first: in MATLAB run setupAgenticToolkit(""install"") (or see the README for manual download)."
  }
  if (-not (Test-Path (Join-Path $toolkitRoot "simulink\tools\tools.json"))) {
    throw "Simulink extension tools file missing: simulink\tools\tools.json under $toolkitRoot. Re-run setupAgenticToolkit and select the Simulink toolkit."
  }
  if (-not (Get-Process matlab -ErrorAction SilentlyContinue)) {
    Write-Warning "MATLAB does not appear to be running. The MCP server attaches to a RUNNING MATLAB (sessionMode=existing) — start MATLAB before using the tools."
  }
}

# --- install the bundle into the profile ---
$launcher = Find-DshLauncher
$pkgDir = $PSScriptRoot
Write-Host "Installing bundle from: $pkgDir"
Write-Host "Target profile: $Profile"
& $launcher plugin --profile $Profile add $pkgDir
if ($LASTEXITCODE -ne 0) { throw "dsh plugin add failed (exit $LASTEXITCODE)." }

Write-Host ""
Write-Host "== Done. Next steps ==" -ForegroundColor Green
Write-Host "1. Restart the dsh GUI (quit and relaunch it)."
Write-Host "2. Make sure MATLAB is running, and in that MATLAB session run once:"
Write-Host "   addpath('C:\Users\$env:USERNAME\.matlab\agentic-toolkits\simulink')"
Write-Host "   satk_initialize"
Write-Host "3. Verify: ask the agent to run 'detect_matlab_toolboxes' or 'model_overview'."
Write-Host ""
Write-Host "Uninstall later:  $launcher plugin --profile $Profile remove dsh-matlab-mcp"
