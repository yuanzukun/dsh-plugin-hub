#!/usr/bin/env bash
# dsh-matlab-mcp — one-click setup (macOS / Linux)
# Registers the MathWorks MATLAB/Simulink MCP server into a DeepSeek Harness
# profile so agent sessions get mcp__matlab__* tools.
#
# Usage:
#   ./install.sh                 # install into the default "web" profile
#   ./install.sh -p tui          # install into another profile
set -euo pipefail

PROFILE="${1:-web}"   # optional first arg: profile name (default web)

echo "== dsh-matlab-mcp installer =="

# --- pnpm: required by `dsh plugin` (it forwards pnpm args) ---
if ! command -v pnpm >/dev/null 2>&1; then
  echo "ERROR: pnpm not found on PATH. Install it first: npm install -g pnpm" >&2
  exit 1
fi

# --- locate the dsh launcher ---
if command -v dsh >/dev/null 2>&1; then
  DSH="dsh"
elif command -v npx >/dev/null 2>&1; then
  DSH="npx -y @deepseek-ai/dsh"
else
  echo "ERROR: cannot find the dsh launcher (dsh or npx)." >&2
  exit 1
fi

# --- prerequisites ---
HOME_DIR="${HOME:-$USERPROFILE}"
TOOLKIT="$HOME_DIR/.matlab/agentic-toolkits"
BIN="$TOOLKIT/bin/matlab-mcp-server"
if [ ! -x "$BIN" ]; then
  echo "ERROR: $BIN not found." >&2
  echo "Install the MATLAB Agentic Toolkit first: in MATLAB run setupAgenticToolkit(\"install\") (see README)." >&2
  exit 1
fi
if [ ! -f "$TOOLKIT/simulink/tools/tools.json" ]; then
  echo "ERROR: Simulink extension tools file missing under $TOOLKIT/simulink/tools." >&2
  echo "Re-run setupAgenticToolkit and select the Simulink toolkit." >&2
  exit 1
fi
if ! pgrep -x MATLAB >/dev/null 2>&1; then
  echo "WARNING: MATLAB does not appear to be running. The MCP server attaches to a RUNNING MATLAB (sessionMode=existing)." >&2
fi

# --- install the bundle into the profile ---
PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
echo "Installing bundle from: $PKG_DIR"
echo "Target profile: $PROFILE"
# shellcheck disable=SC2086
$DSH plugin --profile "$PROFILE" add "$PKG_DIR"

echo
echo "== Done. Next steps =="
echo "1. Restart the dsh GUI (quit and relaunch it)."
echo "2. Make sure MATLAB is running, and in that MATLAB session run once:"
echo "   addpath('$TOOLKIT/simulink')"
echo "   satk_initialize"
echo "3. Verify: ask the agent to run 'detect_matlab_toolboxes' or 'model_overview'."
echo
echo "Uninstall later:  $DSH plugin --profile $PROFILE remove dsh-matlab-mcp"
