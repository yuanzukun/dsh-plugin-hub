import Schema from '@deepseek-ai/schemastery'
import { createReadStream, existsSync, readdirSync } from 'node:fs'
import { mkdir, rm, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'dsh-theme-bside-olivia-lin'

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

export const PLUGIN_ID = 'dsh-theme-bside-olivia-lin'
export const CONFIG_ENDPOINT = '/plugins/dsh-theme-bside-olivia-lin/config'
export const ASSETS_PREFIX = '/plugins/dsh-theme-bside-olivia-lin/assets/'
export const CUSTOM_PREFIX = '/plugins/dsh-theme-bside-olivia-lin/custom/'
export const UPLOAD_ENDPOINT = '/plugins/dsh-theme-bside-olivia-lin/background'

/** File extension → content type for preset images. */
const PRESET_TYPES = Object.freeze({
  svg: 'image/svg+xml; charset=utf-8',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webp: 'image/webp',
  gif: 'image/gif',
})

const PRESET_FILE_RE = /^([a-zA-Z0-9_-]+)\.(svg|png|jpe?g|webp|gif)$/

/** Package asset directory (this file's ../assets/backgrounds). */
const ASSETS_DIR = fileURLToPath(new URL('../assets/backgrounds/', import.meta.url))

/** Content-type → stored extension for user-uploaded backgrounds. */
const UPLOAD_TYPES = Object.freeze({
  'image/png': 'png',
  'image/jpeg': 'jpg',
  'image/webp': 'webp',
  'image/gif': 'gif',
})

const MAX_UPLOAD_BYTES = 20 * 1024 * 1024

// ---------------------------------------------------------------------------
// Palette helpers (mirrored in lib/client.js — keep both halves in sync)
// ---------------------------------------------------------------------------

export const DEFAULT_ACCENT = '#d9a066'

export function isHex(value) {
  return typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value)
}

/** '#rrggbb' → 'r, g, b'. */
export function hexToRgbString(hex) {
  const value = hex.replace('#', '')
  return `${parseInt(value.slice(0, 2), 16)}, ${parseInt(value.slice(2, 4), 16)}, ${parseInt(value.slice(4, 6), 16)}`
}

export function hexToRgba(hex, alpha) {
  return `rgba(${hexToRgbString(hex)}, ${alpha})`
}

/** Channel-wise lerp between two hex colors; t = 0 → a, t = 1 → b. */
export function mixHex(a, b, t) {
  const pa = a.replace('#', '')
  const pb = b.replace('#', '')
  const ch = (s, i) => parseInt(s.slice(i, i + 2), 16)
  const out = [0, 2, 4]
    .map((i) => Math.round(ch(pa, i) + (ch(pb, i) - ch(pa, i)) * t))
    .map((v) => v.toString(16).padStart(2, '0'))
  return `#${out.join('')}`
}

/** A valid #rrggbb, or the fallback. */
export function pickColor(value, fallback) {
  return isHex(value) ? value : fallback
}

// ---------------------------------------------------------------------------
// Settings schema + defaults
// ---------------------------------------------------------------------------

export const Config = Schema.object({
  background: Schema.string()
    .description('背景：预设 id，或 custom:<扩展名>；空字符串 = 深色用默认壁纸')
    .default(''),
  maskOpacity: Schema.number()
    .min(0)
    .max(1)
    .step(0.05)
    .default(0.5)
    .role('slider')
    .description('蒙版不透明度：0 = 原图效果，越高越不透明，1 = 完全覆盖为主题底色'),
  accentColor: Schema.string()
    .description('强调色（琥珀色）；空字符串 = 使用默认 #d9a066')
    .default(''),
  fontColor: Schema.string()
    .description('字体颜色（空字符串 = 跟随明暗配色的默认色）')
    .default(''),
  inputColor: Schema.string()
    .description('输入框颜色（空字符串 = 跟随明暗配色的默认色；输入框固定 80% 不透明）')
    .default(''),
  sidebarColor: Schema.string()
    .description('侧边栏颜色（空字符串 = 跟随明暗配色的默认色；侧边栏始终不透明）')
    .default(''),
  rainEffect: Schema.boolean().description('雨夜氛围：细雨斜织的动态雨幕').default(true),
  filmGrain: Schema.boolean().description('胶片颗粒：老电影质感的噪点层').default(true),
  glowTitle: Schema.boolean().description('当前会话标题使用琥珀渐变高亮特效').default(true),
}).description('BSide Olivia Lin 主题设置')

const defaults = Object.freeze({
  background: '',
  maskOpacity: 0.5,
  accentColor: '',
  fontColor: '',
  inputColor: '',
  sidebarColor: '',
  rainEffect: true,
  filmGrain: true,
  glowTitle: true,
})

/**
 * Per-scheme defaults applied when the stored setting is empty. The theme is
 * dark-first (the registered theme declares colorScheme "dark"); the light
 * branch exists so an override never goes illegible if the host flips schemes.
 */
const SCHEME_DEFAULTS = {
  light: {
    background: 'rainy-window',
    inputColor: '#faf6f0',
    sidebarColor: '#efe7db',
    fontColor: '',
  },
  dark: {
    background: 'olivia-night',
    inputColor: '#171310',
    sidebarColor: '#120e0b',
    fontColor: '',
  },
}

/** Resolve one setting for a color scheme: stored override, else scheme default. */
export function schemeValue(field, config, scheme) {
  const stored = config[field]
  if (typeof stored === 'string' && stored.trim() !== '') return stored
  return SCHEME_DEFAULTS[scheme][field]
}

export function publicConfig(config = {}) {
  const out = {}
  for (const key of Object.keys(defaults)) out[key] = config[key] ?? defaults[key]
  return out
}

// ---------------------------------------------------------------------------
// Preset backgrounds
// ---------------------------------------------------------------------------

/**
 * Scan the preset asset directory. Every image file becomes a preset
 * (id = filename stem). Re-scanned per call so files added mid-session
 * appear on the next request.
 */
export function listPresets() {
  const found = []
  try {
    for (const entry of readdirSync(ASSETS_DIR)) {
      const match = PRESET_FILE_RE.exec(entry)
      if (!match) continue
      found.push({ id: match[1], file: entry, type: PRESET_TYPES[match[2]] })
    }
  } catch {
    // Asset dir missing (unlikely) — treat as empty.
  }
  found.sort((a, b) => a.id.localeCompare(b.id))
  return found
}

/** Resolve the background setting for one scheme to a served URL (or null). */
export function resolveBackgroundUrl(config, scheme) {
  const presets = listPresets()
  const bg = schemeValue('background', config, scheme)
  if (typeof bg === 'string' && bg.startsWith('custom:')) {
    const ext = bg.slice('custom:'.length).replace(/[^a-z0-9]/gi, '')
    if (ext) return `${CUSTOM_PREFIX}custom-bg.${ext}`
  } else {
    const preset = presets.find((candidate) => candidate.id === bg)
    if (preset) return `${ASSETS_PREFIX}${preset.file}`
  }
  const fallback = presets.find((p) => p.id === 'olivia-night') ?? presets[0]
  return fallback ? `${ASSETS_PREFIX}${fallback.file}` : null
}

// ---------------------------------------------------------------------------
// Token builders (mirrored in lib/client.js buildDynTokens — keep in sync)
// ---------------------------------------------------------------------------

const LIGHT = { input: '#faf6f0', sidebar: '#efe7db', mask: '250, 246, 240' }
const DARK = { input: '#171310', sidebar: '#120e0b', mask: '23, 19, 15' }

const LIGHT_LABELS = {
  '--dsw-alias-label-primary': '#3a2c1e',
  '--dsw-alias-label-secondary': '#6b5844',
  '--dsw-alias-label-tertiary': '#94826d',
  '--dsw-alias-label-caption': '#94826d',
  '--dsw-alias-label-dimmed': '#94826d',
}
const DARK_LABELS = {
  '--dsw-alias-label-primary': '#f3ead9',
  '--dsw-alias-label-secondary': '#cbbca6',
  '--dsw-alias-label-tertiary': '#9c8e79',
  '--dsw-alias-label-caption': '#9c8e79',
  '--dsw-alias-label-dimmed': '#7d7264',
}

function labelPair(fontColor, fallback) {
  if (isHex(fontColor)) {
    return {
      '--dsw-alias-label-primary': fontColor,
      '--dsw-alias-label-secondary': hexToRgba(fontColor, 0.82),
      '--dsw-alias-label-tertiary': hexToRgba(fontColor, 0.62),
      '--dsw-alias-label-caption': hexToRgba(fontColor, 0.62),
      '--dsw-alias-label-dimmed': hexToRgba(fontColor, 0.62),
    }
  }
  return fallback
}

/**
 * Surface translucency tokens for one scheme. The main content areas follow
 * the mask (maskOpacity 0 = wallpaper shows pure through the panels; 1 =
 * fully covered by the theme base). The input box is fixed at 80% opacity;
 * the sidebar keeps its opaque base so text never sits on a busy photo.
 */
export function surfaceTokens(scheme, maskAlpha, config) {
  const S = scheme === 'dark' ? DARK : LIGHT
  const a = Math.min(1, Math.max(0, Number(maskAlpha) || 0))
  const input = hexToRgbString(pickColor(schemeValue('inputColor', config, scheme), S.input))
  const sidebar = hexToRgbString(pickColor(schemeValue('sidebarColor', config, scheme), S.sidebar))
  if (scheme === 'dark') {
    return {
      '--dsw-alias-bg-base': `rgba(23, 19, 15, ${a})`,
      '--dsw-specific-input-major': `rgba(${input}, 0.8)`,
      '--dsw-specific-tip': `rgba(28, 22, 17, ${a})`,
      '--dsw-specific-bubble': `rgba(28, 22, 17, ${a})`,
      '--dsw-specific-bubble-highlight': `rgba(38, 32, 25, ${a})`,
      '--dsw-specific-sidebar-fill': `rgb(${sidebar})`,
    }
  }
  return {
    '--dsw-alias-bg-base': `rgba(250, 246, 240, ${a})`,
    '--dsw-specific-input-major': `rgba(${input}, 0.8)`,
    '--dsw-specific-tip': `rgba(247, 243, 237, ${a})`,
    '--dsw-specific-bubble': `rgba(246, 240, 232, ${a})`,
    '--dsw-specific-bubble-highlight': `rgba(240, 230, 218, ${a})`,
    '--dsw-specific-sidebar-fill': `rgb(${sidebar})`,
  }
}

/** Accent-derived tokens (brand/buttons/scrollbar/borders/hovers). */
export function accentTokens(accentColor) {
  const accent = pickColor(accentColor, DEFAULT_ACCENT)
  const soft = mixHex(accent, '#ffffff', 0.14)
  return {
    '--dsw-alias-brand-primary': accent,
    '--dsw-alias-brand-text': soft,
    '--dsw-alias-brand-primary-invert': '#241505',
    '--dsw-alias-button-primary-fill': accent,
    '--dsw-alias-button-primary-hover': mixHex(accent, '#ffffff', 0.1),
    '--dsw-alias-button-primary-dimmed': hexToRgba(accent, 0.14),
    '--dsw-specific-sidebar-nav-item-active-accent': accent,
    '--dsw-alias-scrollbar-bg-l1': hexToRgba(accent, 0.26),
    '--dsw-alias-scrollbar-bg-l2': hexToRgba(accent, 0.32),
    '--dsw-alias-scrollbar-hover-l1': hexToRgba(accent, 0.48),
    '--dsw-alias-scrollbar-hover-l2': hexToRgba(accent, 0.55),
    '--dsw-alias-border-l1': hexToRgba(accent, 0.14),
    '--dsw-alias-border-l2': hexToRgba(accent, 0.22),
    '--dsw-alias-border-l4': hexToRgba(accent, 0.38),
    '--dsw-alias-interactive-bg-hover': hexToRgba(accent, 0.09),
    '--dsw-alias-interactive-bg-active': hexToRgba(accent, 0.15),
    '--dsw-alias-interactive-bg-hover-accent': hexToRgba(accent, 0.16),
  }
}

/** Full per-scheme token block pair for one resolved config. */
export function buildSchemeTokens(config) {
  const maskAlpha = Math.min(1, Math.max(0, Number(config.maskOpacity) || 0))
  return {
    light: {
      ...surfaceTokens('light', maskAlpha, config),
      ...labelPair(schemeValue('fontColor', config, 'light'), LIGHT_LABELS),
      ...accentTokens(config.accentColor),
    },
    dark: {
      ...surfaceTokens('dark', maskAlpha, config),
      ...labelPair(schemeValue('fontColor', config, 'dark'), DARK_LABELS),
      ...accentTokens(config.accentColor),
    },
  }
}

// ---------------------------------------------------------------------------
// Static theme layer (webServer.tapIndex seam)
// ---------------------------------------------------------------------------

/** Grain texture as an inline SVG data URI (no binary asset needed). */
const GRAIN_URI =
  "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.55'/%3E%3C/svg%3E\")"

function tokenBlock(selector, tokens) {
  const body = Object.entries(tokens).map(([name, value]) => `${name}:${value}`).join(';')
  return `${selector}{${body}}`
}

/**
 * Build the static theme <style> for one config.
 *
 * Layering:
 *   body::before  wallpaper photo   (z -2)
 *   body::after   charcoal veil     (z -1, --bside-mask-alpha)
 *   html::before  film grain        (top, gated by data-bside-grain)
 *   html::after   rain curtain      (top, gated by data-bside-rain)
 *
 * Everything is wrapped in `html:not([data-bside-off="1"])`: first paint
 * always shows the themed look, and the browser half sets that attribute
 * when the user actively picked another theme.
 */
export function buildStaticStyle(config) {
  const c = publicConfig(config)
  const urlLight = resolveBackgroundUrl(c, 'light')
  const urlDark = resolveBackgroundUrl(c, 'dark')
  const bgLight = urlLight ? `url("${urlLight}")` : 'none'
  const bgDark = urlDark ? `url("${urlDark}")` : 'none'
  const maskAlpha = Math.min(1, Math.max(0, Number(c.maskOpacity) || 0))
  const tokens = buildSchemeTokens(c)
  const guard = `html:not([data-bside-off="1"])`
  return `<style data-plugin="${PLUGIN_ID}" data-bside-static="1">` +
    // Wallpaper + veil custom properties: light values on :root, dark values
    // re-declared on body[data-ds-dark-theme] (mirrors the proven columbina
    // pattern; the browser half overrides --bside-bg-image inline per scheme).
    `:root{--bside-bg-image:${bgLight};--bside-mask-alpha:${maskAlpha};--bside-mask-rgb:${LIGHT.mask}}` +
    `body[data-ds-dark-theme]{--bside-bg-image:${bgDark};--bside-mask-rgb:${DARK.mask}}` +
    `${guard} body::before{content:"";position:fixed;inset:0;z-index:-2;background:var(--bside-bg-image) center/cover no-repeat;pointer-events:none}` +
    `${guard} body::after{content:"";position:fixed;inset:0;z-index:-1;background:rgba(var(--bside-mask-rgb),var(--bside-mask-alpha));pointer-events:none}` +
    `${tokenBlock('html body', tokens.light)}${tokenBlock('html body[data-ds-dark-theme]', tokens.dark)}` +
    `${guard} html[data-bside-grain="on"]::before{content:"";position:fixed;inset:-120px;z-index:2147483646;pointer-events:none;background-image:${GRAIN_URI};background-repeat:repeat;opacity:.05;mix-blend-mode:overlay;animation:bside-grain-shift .9s steps(4) infinite}` +
    `@keyframes bside-grain-shift{0%{transform:translate(0,0)}25%{transform:translate(-42px,28px)}50%{transform:translate(34px,-40px)}75%{transform:translate(-22px,-24px)}100%{transform:translate(0,0)}}` +
    `${guard} html[data-bside-rain="on"]::after{content:"";position:fixed;inset:0;z-index:2147483645;pointer-events:none;opacity:.5;background-image:repeating-linear-gradient(102deg,transparent 0 46px,rgba(148,180,205,.055) 46px 47px),repeating-linear-gradient(99deg,transparent 0 92px,rgba(202,222,238,.045) 92px 93px);animation:bside-rain-fall 1.15s linear infinite}` +
    `@keyframes bside-rain-fall{from{background-position:0 0,0 0}to{background-position:-130px 920px,-72px 720px}}` +
    `body[data-bside-glow="on"] [role="treeitem"][aria-selected="true"]{background:linear-gradient(90deg,rgba(217,160,102,0.28),rgba(217,160,102,0.10) 55%,rgba(217,160,102,0.03))!important}` +
    `@supports ((-webkit-background-clip:text) or (background-clip:text)){body[data-bside-glow="on"] [role="treeitem"][aria-selected="true"]>span[class$="_title"]{background:linear-gradient(92deg,#e8b87c 0%,#d9a066 45%,#aebfce 115%);-webkit-background-clip:text;background-clip:text;color:transparent;font-weight:600;filter:drop-shadow(0 0 6px rgba(217,160,102,0.45))}}` +
    `@media (prefers-reduced-motion: reduce){${guard} html[data-bside-grain="on"]::before{animation:none}${guard} html[data-bside-rain="on"]::after{animation:none}}` +
    `</style>`
}

/** Insert the static <style> into <head> and the effect-attrs boot script after <body>. */
export function injectStaticTheme(html, config) {
  const c = publicConfig(config)
  const style = buildStaticStyle(c)
  const head = /<head(?:\s[^>]*)?>/i.exec(html)
  let out = head
    ? `${html.slice(0, head.index + head[0].length)}${style}${html.slice(head.index + head[0].length)}`
    : `${style}${html}`
  const boot = `<script>(function(){var d=document.documentElement;d.setAttribute('data-bside-rain','${c.rainEffect === false ? 'off' : 'on'}');d.setAttribute('data-bside-grain','${c.filmGrain === false ? 'off' : 'on'}')})();<\/script>`
  const body = /<body(?:\s[^>]*)?>/i.exec(out)
  if (body) out = `${out.slice(0, body.index + body[0].length)}${boot}${out.slice(body.index + body[0].length)}`
  if (c.glowTitle !== false) {
    const glow = `<script>document.body&&document.body.setAttribute('data-bside-glow','on')<\/script>`
    const body2 = /<body(?:\s[^>]*)?>/i.exec(out)
    if (body2) out = `${out.slice(0, body2.index + body2[0].length)}${glow}${out.slice(body2.index + body2[0].length)}`
  }
  return out
}

// ---------------------------------------------------------------------------
// Data dir + upload storage
// ---------------------------------------------------------------------------

/** Plugin-owned data directory under the DSH home (custom uploads). */
export function dataDir() {
  const home = process.env.DSH_HOME || join(homedir(), '.dsh')
  return join(home, 'storages', PLUGIN_ID)
}

function customFilePath(ext) {
  return join(dataDir(), `custom-bg.${ext}`)
}

export function currentCustomUrl() {
  for (const ext of Object.values(UPLOAD_TYPES)) {
    if (existsSync(customFilePath(ext))) return `${CUSTOM_PREFIX}custom-bg.${ext}`
  }
  return null
}

function contentTypeFor(ext) {
  const table = { png: 'image/png', jpg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', svg: 'image/svg+xml' }
  return table[ext] ?? 'application/octet-stream'
}

// ---------------------------------------------------------------------------
// HTTP plumbing
// ---------------------------------------------------------------------------

function isLoopback(address) {
  return address === '127.0.0.1' || address === '::1' || address === '::ffff:127.0.0.1'
}

function jsonResponse(res, status, body) {
  const payload = JSON.stringify(body)
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(payload),
  })
  res.end(payload)
}

/** Local-only guard shared by the config and upload endpoints. */
function localOnly(req, res) {
  if (!isLoopback(req.socket?.remoteAddress)) {
    jsonResponse(res, 403, { error: 'local access only' })
    return false
  }
  const origin = req.headers?.origin
  if (origin) {
    let originHost
    try {
      originHost = new URL(origin).host
    } catch {}
    if (!originHost || originHost !== req.headers.host) {
      jsonResponse(res, 403, { error: 'origin mismatch' })
      return false
    }
  }
  return true
}

async function readPatch(req) {
  const chunks = []
  let bytes = 0
  for await (const chunk of req) {
    bytes += chunk.length
    if (bytes > 8192) throw new Error('request body is too large')
    chunks.push(chunk)
  }
  const value = JSON.parse(Buffer.concat(chunks).toString('utf8'))
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('patch must be an object')
  const allowed = new Set(Object.keys(defaults))
  if (Object.keys(value).some((key) => !allowed.has(key))) throw new Error('patch contains an unknown setting')
  return value
}

async function readBody(req, limit) {
  const chunks = []
  let bytes = 0
  for await (const chunk of req) {
    bytes += chunk.length
    if (bytes > limit) throw new Error('upload is too large')
    chunks.push(chunk)
  }
  return Buffer.concat(chunks)
}

export function createConfigHandler(settings) {
  const view = () => ({
    ...settings.get(),
    customBackground: currentCustomUrl(),
    presets: listPresets().map(({ id, file }) => ({ id, file })),
  })
  return async (req, res) => {
    if (!localOnly(req, res)) return
    if (req.method === 'GET') {
      jsonResponse(res, 200, view())
      return
    }
    if (req.method !== 'PATCH') {
      jsonResponse(res, 405, { error: 'method not allowed' })
      return
    }
    try {
      await settings.update(await readPatch(req))
      jsonResponse(res, 200, view())
    } catch (error) {
      jsonResponse(res, 400, { error: error instanceof Error ? error.message : String(error) })
    }
  }
}

export function createUploadHandler(settings) {
  return async (req, res) => {
    if (!localOnly(req, res)) return
    if (req.method === 'GET') {
      jsonResponse(res, 200, { url: currentCustomUrl() })
      return
    }
    if (req.method !== 'POST') {
      jsonResponse(res, 405, { error: 'method not allowed' })
      return
    }
    const declared = String(req.headers['content-type'] ?? '').split(';')[0].trim()
    const ext = UPLOAD_TYPES[declared]
    if (!ext) {
      jsonResponse(res, 415, { error: `unsupported content type "${declared}" — use png, jpeg, webp or gif` })
      return
    }
    try {
      const body = await readBody(req, MAX_UPLOAD_BYTES)
      if (body.length === 0) throw new Error('empty upload')
      await mkdir(dataDir(), { recursive: true })
      // Clear previous uploads so only the newest custom image resolves.
      for (const other of Object.values(UPLOAD_TYPES)) {
        if (other !== ext) await rm(customFilePath(other), { force: true })
      }
      await writeFile(customFilePath(ext), body)
      const url = `${CUSTOM_PREFIX}custom-bg.${ext}`
      // Point the active background at the freshly uploaded image.
      await settings.update({ background: `custom:${ext}` }).catch(() => {})
      jsonResponse(res, 200, { url, background: `custom:${ext}` })
    } catch (error) {
      jsonResponse(res, 400, { error: error instanceof Error ? error.message : String(error) })
    }
  }
}

/** Serve one preset image (id resolved through the live asset scan). */
export function servePreset(res, id) {
  const preset = listPresets().find((candidate) => candidate.id === id)
  const file = preset ? join(ASSETS_DIR, preset.file) : null
  if (!file || !existsSync(file)) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('not found')
    return
  }
  res.writeHead(200, { 'content-type': preset.type, 'cache-control': 'public, max-age=86400' })
  createReadStream(file).pipe(res)
}

/** Serve an uploaded custom background (exact stored filename only). */
export function serveCustom(res, name) {
  const match = /^custom-bg\.(png|jpg|webp|gif)$/.exec(name)
  if (!match) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('not found')
    return
  }
  const file = join(dataDir(), name)
  if (!existsSync(file)) {
    res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' })
    res.end('not found')
    return
  }
  res.writeHead(200, { 'content-type': contentTypeFor(match[1]), 'cache-control': 'public, max-age=86400' })
  createReadStream(file).pipe(res)
}

// ---------------------------------------------------------------------------
// Mount
// ---------------------------------------------------------------------------

function mount(ctx, config = {}) {
  const base = publicConfig(config)
  const settings = ctx.settings.register(PLUGIN_ID, Config, {
    base,
    applies: 'live',
  })

  if (typeof ctx.inject === 'function') {
    ctx.inject(['webServer'], (httpCtx) => {
      httpCtx.effect(
        () => httpCtx.webServer.tapIndex((html) => injectStaticTheme(html, settings.get())),
        'dsh-theme-bside-olivia-lin: static theme style',
      )
      httpCtx.effect(
        () => httpCtx.webServer.register({ kind: 'exact', path: CONFIG_ENDPOINT, handler: createConfigHandler(settings) }),
        'dsh-theme-bside-olivia-lin: config endpoint',
      )
      httpCtx.effect(
        () => httpCtx.webServer.register({ kind: 'exact', path: UPLOAD_ENDPOINT, handler: createUploadHandler(settings) }),
        'dsh-theme-bside-olivia-lin: upload endpoint',
      )
      httpCtx.effect(
        () => httpCtx.webServer.register({
          kind: 'prefix',
          path: ASSETS_PREFIX.slice(0, -1),
          handler: (req, res) => {
            const stem = decodeURIComponent(req.url?.slice(ASSETS_PREFIX.length) ?? '').replace(/\.(svg|png|jpe?g|webp|gif)$/i, '')
            servePreset(res, stem)
          },
        }),
        'dsh-theme-bside-olivia-lin: preset assets route',
      )
      httpCtx.effect(
        () => httpCtx.webServer.register({
          kind: 'prefix',
          path: CUSTOM_PREFIX.slice(0, -1),
          handler: (req, res) => {
            const name = decodeURIComponent(req.url?.slice(CUSTOM_PREFIX.length) ?? '')
            serveCustom(res, name)
          },
        }),
        'dsh-theme-bside-olivia-lin: custom background route',
      )
    })
  }
}

export function apply(ctx, config = {}) {
  if (typeof ctx.inject === 'function') {
    ctx.inject(['settings'], (settingsCtx) => mount(settingsCtx, config))
    return
  }
  mount(ctx, config)
}
