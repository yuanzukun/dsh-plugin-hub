# dsh-theme-bside-olivia-lin

**BSide: Olivia Lin（林离）主题** —— DeepSeek Harness Web GUI 的角色主题插件。

> 黑胶琥珀 × 雨夜蓝灰 × 深炭棕。
> 主修钢琴、辅修心理学的上海女生林离，钟爱黑胶、老电影和雨天 ——
> 这个主题把她的琴房搬进了 DSH：暖色台灯、胶片颗粒，和一层缓缓落下的细雨。

灵感来源于 Steam 游戏《[BSide: Olivia Lin](https://store.steampowered.com/app/4532590/)》。

## 功能

| 能力 | 实现 |
| --- | --- |
| 注册主题 | 客户端通过 `ctx.theme.register()` 注册可选主题 `bside-olivia-lin`（深色），首次安装自动激活；之后可在 DSH 外观设置中自由切换 |
| 设计令牌 | 覆盖全套 `--dsw-alias-*` / `--dsw-specific-*` / `--dsw-static-*` 令牌：表面、标签、品牌色、按钮、边框、状态色、Markdown/代码块、滚动条等 |
| 设置界面 | 通过 `settings.plugin.item` 插槽注入设置卡片：壁纸预设九宫格、蒙版不透明度、强调色/字体/输入框/侧栏颜色、雨夜氛围、胶片颗粒、标题高亮开关 |
| 背景管理 | 内置 6 张游戏官方场景预设；支持上传自定义图片（存入 `$DSH_HOME/storages/dsh-theme-bside-olivia-lin/`，经本地回环 + Origin 校验的专用端点伺服） |
| 持久化 | 全部偏好经 `ctx.settings.register()` 存入 Host 用户设置文档，重启自动恢复；服务端还把当前配置烘焙进每个页面的首屏 `<style>`，刷新零闪烁 |

## 安装

```bash
# 从 GitHub 安装
dsh plugin --profile web add github:Leoq-bit/dsh-theme-bside-olivia-lin

# 从 zip 安装（Release 附件或本地构建）
dsh plugin --profile web add <path-to>/dsh-theme-bside-olivia-lin-<version>.zip
```

安装后刷新 DSH Web 页面即可。首次加载会自动切换到该主题；
想换回去时在「设置 → 外观」选择其它主题即可（本插件会自动让位，
不会再抢回激活状态）。

## 预设壁纸

| 预设 id | 场景 |
| --- | --- |
| `olivia-night` | 深夜氛围（默认深色壁纸） |
| `vinyl-lounge` | 黑胶暖调客厅 |
| `piano-warmth` | 琴房暖光 |
| `rainy-window` | 雨窗蓝灰（默认浅色壁纸） |
| `stage-dim` | 幕后暗场 |
| `monochrome` | 黑白胶片 |

## 配色

| 座位 | 值 |
| --- | --- |
| 强调色（琥珀 / 台灯） | `#d9a066` |
| 辅助色（雨夜蓝灰） | `#7f98ad` |
| 表面基色（深炭棕） | `#171310` → `#2a221a` |
| 标签文字（暖纸白） | `#f3ead9` / `#cbbca6` / `#9c8e79` |
| 错误 / 成功 / 警告 | 砖红 `#c9564a` / 鼠尾草绿 `#97b07f` / 蜜黄 `#d9a24a` |

## HTTP 端点（仅本地回环）

- `GET/PATCH /plugins/dsh-theme-bside-olivia-lin/config` — 读取/更新设置
- `POST /plugins/dsh-theme-bside-olivia-lin/background` — 上传自定义壁纸（png/jpeg/webp/gif ≤ 20MB）
- `GET /plugins/dsh-theme-bside-olivia-lin/assets/<preset>.jpg` — 预设壁纸
- `GET /plugins/dsh-theme-bside-olivia-lin/custom/custom-bg.<ext>` — 上传的壁纸

## 目录结构

```
dsh-theme-bside-olivia-lin/
├─ package.json          # 插件清单（dsh.client 注入声明）
├─ cordis.patch.yml       # bundle 补丁：注册插件与默认配置
├─ src/index.js           # 服务端半边：设置持久化 / 端点 / 首屏样式烘焙
├─ lib/client.js          # 浏览器半边：主题注册 / 动态令牌 / 设置卡片
└─ assets/backgrounds/    # 预设壁纸（放入新图片文件即可增加预设）
```

## 素材说明

`assets/backgrounds/` 内的图片取自《BSide: Olivia Lin》Steam 商店页面公开宣传素材，
版权归原权利方所有，此处仅作非商业的主题美化用途。若你是权利人并希望移除，
请提 issue。

## License

MIT（素材除外，见上）
