/**
 * dsh-llm-wechat：微信网关（chatapi.weixin.qq.com）DeepSeek 适配插件。
 * 复用 DeepSeekAdapter + 流式 think 标签转译层。
 */

import type { Context } from "@deepseek-ai/cordis";
import type { DeepSeekAdapter } from "@deepseek-ai/dsh-llm-deepseek";

/** 插件名。 */
export const name: "llm-wechat";

/** 依赖的服务：llm（dsh-llm 注册中心）。 */
export const inject: ["llm"];

/** 本插件独占的 provider route。 */
export const PROVIDER: "wechat";

/** 配置 schema（schemastery）。 */
export const Config: import("@deepseek-ai/schemastery").Schema<{
  apiKeyEnv?: string;
  baseURL?: string;
  thinking?: "enabled" | "disabled";
  reasoningEffort?: "off" | "high" | "max";
  maxTokens?: number;
  defaultContextWindow?: number;
  models?: { id: string; name?: string; description?: string; contextWindow?: number; maxTokens?: number }[];
  streamIdleTimeoutMs?: number;
  requestTimeoutMs?: number;
  retryPolicy?: unknown;
  stripThinkingTags?: boolean;
}>;

/**
 * WechatAdapter：继承官方 DeepSeekAdapter，
 * 在响应侧把微信塞进 content 的 think 标签段重排进 reasoning_content，
 * 并过滤工具调用 delta 里的 null id/name。
 */
export class WechatAdapter extends DeepSeekAdapter {
  /** 是否启用 think 标签剥离（由 stripThinkingTags 控制）。 */
  strip: boolean;
  /** system prompt 增强（缓解微信模型直接调用 collapsed 工具）。 */
  _enhanceSystem(system: string | undefined): string | undefined;
}

/** 从原始配置解析连接事实。 */
export function resolveAdapterOptions(config: unknown, environment?: { get(name: string): { value: string } | undefined }): {
  apiKeyEnv: unknown;
  baseURL: string;
  defaults: { thinking: "enabled" | "disabled" | undefined; reasoningEffort: "off" | "high" | "max" | undefined };
  maxTokens: number;
  defaultContextWindow: number;
  models: unknown[];
  streamIdleTimeoutMs: number;
  requestTimeoutMs: number;
  retryPolicy: unknown;
};

/** 插件主体。 */
export function apply(ctx: Context, config: unknown): void;

export const DEFAULT_MAX_TOKENS: number;
export const DEFAULT_CONTEXT_WINDOW: number;
export const DEFAULT_STREAM_IDLE_TIMEOUT_MS: number;
export const DEFAULT_WECHAT_REQUEST_TIMEOUT_MS: number;
