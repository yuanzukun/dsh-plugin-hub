/** dsh-llm-wechat 的不变量入口（无额外声明）。 */
export {};
