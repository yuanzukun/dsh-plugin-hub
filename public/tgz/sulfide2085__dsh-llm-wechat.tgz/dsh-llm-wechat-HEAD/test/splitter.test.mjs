(async () => {
  const { ThinkTagSplitter } = await import("../lib/wechat-translate.js");
  let pass = 0, fail = 0;
  function check(name, got, want) {
    const ok = JSON.stringify(got) === JSON.stringify(want);
    if (ok) pass++; else { fail++; console.log("FAIL:", name, "\n  got:", JSON.stringify(got), "\n  want:", JSON.stringify(want)); }
  }
  const CLOSE = "</" + "t" + "hink>";
  const OPEN = "<" + "think>";
  function runStream(chunks, enabled = true) {
    const s = new ThinkTagSplitter({ enabled });
    const out = { content: "", reasoning: "" };
    for (const c of chunks) {
      const r = s.push(c);
      if (r.content) out.content += r.content;
      if (r.reasoning) out.reasoning += r.reasoning;
    }
    const f = s.flush();
    if (f.content) out.content += f.content;
    if (f.reasoning) out.reasoning += f.reasoning;
    return out;
  }
  check("真实格式单块", runStream(["We need answer compute. " + CLOSE + "141.37"]), { content: "141.37", reasoning: "We need answer compute. " });
  check("跨chunk标签", runStream(["We need answer compute. <", "/thi", "nk>141.3717"]), { content: "141.3717", reasoning: "We need answer compute. " });
  check("无标签", runStream(["你好，这是正文"]), { content: "你好，这是正文", reasoning: "" });
  check("disabled透传", runStream(["We need " + CLOSE + "141"], false), { content: "We need " + CLOSE + "141", reasoning: "" });
  check("开标签无闭", runStream(["a " + OPEN + "思考中"]), { content: "a ", reasoning: "思考中" });
  check("思考含尖括号", runStream(["x " + OPEN + "a<b>c " + CLOSE + "y"]), { content: "x y", reasoning: "a<b>c " });
  check("开闭对", runStream(["pre " + OPEN + "思考" + CLOSE + " post"]), { content: "pre  post", reasoning: "思考" });
  check("无正文", runStream(["only think " + CLOSE]), { content: "", reasoning: "only think " });
  check("隐式思考增量流出", new ThinkTagSplitter({ enabled: true }).push("这是一段还没有闭合标签的思考内容").reasoning !== undefined, true);
  console.log("结果:", pass, "通过,", fail, "失败");
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error("EXC:", e); process.exit(1); });