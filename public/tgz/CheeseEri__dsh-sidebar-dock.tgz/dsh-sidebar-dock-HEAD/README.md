# dsh-sidebar-dock

> DeepSeek Harness 左侧栏入口的收纳盒：一键收起 / 展开全局入口，拖动排序，把常用插件钉在收起后仍然可见的位置。

[![license](https://img.shields.io/badge/license-MIT-blue)](LICENSE)
[![dsh](https://img.shields.io/badge/DeepSeek%20Harness-plugin-4B6BFB)](https://github.com/CheeseEri/dsh-sidebar-dock)

DeepSeek Harness 的左侧栏会堆着越来越多的全局入口（各类插件页、归档会话、设置入口……），装得越多越挤成一列。
`dsh-sidebar-dock` 给它们加了一个「收纳盒」：平时一键收起只留常用项，需要时向下展开；顺序、常用、首次打开时的默认状态都由你自己定。

| 展开（默认） | 收起后 |
| --- | --- |
| ![侧栏展开](docs/sidebar-expanded.png) | ![侧栏收起](docs/sidebar-collapsed.png) |

管理器页（顺序、常用、首次打开时）：

![入口管理页](docs/manager.png)

## 功能

- **一键收起 / 展开**：入口列表最上面是一行「收起 / 展开侧栏入口」。收起时只留下常用入口与固定入口（`插件`、这一行本身），其余入口带动画**向下**收起；再点一下按原顺序向下展开。管理器页头部也有同样的开关。
- **拖动排序**：在「入口管理」里直接拖动行，或用行尾的 ↑ / ↓ 按钮。顺序保存在本机。
- **常用固定**：点亮星标把入口放进「常用入口」分组——收起后依然显示，并排在列表最前面。常用入口之间也可以互相拖动排序；把行拖到另一个分组会切换常用状态。
- **首次打开时**：可选 `默认收起`（出厂值）、`默认展开`、`保持上次状态`。这里的「第一次打开」指**完全退出 DeepSeek Harness 桌面版后再进入**；在同一个窗口里刷新页面不算新的一次启动，不会被重新摆一遍。
- **不会锁死自己**：`插件` 入口与「收起 / 展开侧栏入口」行永远不会被收起，避免把开关藏起来。
- **不改别人的设置**：宿主自带的 Pin（「更多」菜单里的显隐）原样保留，本插件只调整自己管的这些行的顺序与可见性。
- **可完全撤销**：所有改动都是加在侧边栏行容器上的内联样式与 `data-sdsem-*` 标记，插件停用 / 卸载后立即还原。

## 安装

### 从 GitHub 安装（推荐，给使用者）

```bash
dsh plugin --profile desktop add github:CheeseEri/dsh-sidebar-dock
```

装好后**完全退出并重新打开** DeepSeek Harness（或重新加载 `desktop` profile）。卸载：

```bash
dsh plugin --profile desktop rm dsh-sidebar-dock
```

> 仓库名与包名都是 `dsh-sidebar-dock`（卸载时用包名）。

### 从本地目录安装（给开发者）

```bash
dsh plugin --profile desktop add link:D:/path/to/dsh-sidebar-dock
```

也可以在 Harness 的 **插件** 页面里安装该目录，bundle patch 会把插件插入 profile 的配置树。装好后刷新页面。

## 使用

1. 侧栏顶部点「收起 / 展开侧栏入口」即可收起或展开整个入口列表。
2. 点侧栏里的「入口管理」打开管理器：
   - 拖动行或点 ↑ / ↓ 调整顺序；
   - 点星标把入口放进「常用入口」；
   - 顶部「首次打开时」选择下次启动时的默认状态；
   - 右上「恢复默认顺序」只重置顺序与收起状态，不会动常用入口。
3. 收起状态下想进管理器：先点「收起 / 展开侧栏入口」展开，再点「入口管理」。

## 存储

偏好写入浏览器 `localStorage`，键 `dsh-sidebar-dock:prefs`：

```json
{
  "v": 1,
  "order": ["studyhub", "plugins", "archived-sessions"],
  "favourites": ["studyhub"],
  "collapsed": false,
  "onLaunch": "collapsed"
}
```

- `onLaunch`：`collapsed` / `expanded` / `remember`。
- 另用 `sessionStorage` 的 `dsh-sidebar-dock:launched` 记住「这个窗口已经处理过启动状态」，所以刷新不会重复应用；会话存储随窗口结束清空，下次启动重新按 `onLaunch` 摆一次。
- 偏好只存在本机，不会同步到其他设备；清掉这两个键即恢复默认。

## 实现说明

侧边栏的全局入口由宿主 `dsh-client-ui-sidebar` 渲染，顺序来自各插件注册的 `order`，宿主**没有**提供重排或分组 API。因此本插件采取「官方插槽 + 可逆 DOM 增强」的混合方案：

- 官方插槽：`sidebar.panellist`（「入口管理」行、`order: 100` ＋「收起 / 展开侧栏入口」行、`order: -1000` 置顶）与 `main`（key = `dsh-sidebar-dock` 的管理器页）。
- 行排序 / 分组 / 收起：只在侧边栏行按钮的外层容器上设置 `style.order`、`style.display`、`max-height`、`opacity` 和 `data-sdsem-*` 标记，不新增或删除宿主节点，卸载时全部清除。
- 行与入口 id 的对应：优先用 `aria-label` 与槽位 label 对齐，其次按宿主相同的 `(order, 注册顺序)` 兜底。
- 动画：逐行 `max-height + opacity` 过渡约 200ms，结束后才落 `display:none`；展开相反。开关行本身不参与动画，只做一次箭头翻转。
- 启动状态：客户端加载时立即执行 `applyLaunchMode()`，所以冷启动那一刻侧栏就已经是收起 / 展开好的，不会先展开再收。

已知限制：

- 这一版宿主的「更多」菜单只列插件市场动作（浏览更多插件 / 创建你的插件），**不列**被收起的入口，所以收起状态下管理器页要从开关行展开后再进。
- 宿主升级若改动侧边栏行结构，`aria-label` 对齐可能需要适配；届时插件会退化为「不改动」而不是报错。

## 目录结构

```
.
├── package.json         # 插件清单（name 为 dsh-sidebar-dock）
├── cordis.patch.yml     # bundle patch：把插件插入 profile 配置树
├── icon.svg
├── lib/
│   ├── index.js         # 宿主侧入口（空 apply）
│   └── client.js        # 客户端：侧栏增强 + 管理器页
├── locale/
│   ├── zh.json
│   └── en.json
├── docs/                # README 用截图（展开态 / 收起态 / 管理页）
├── LICENSE
├── .gitignore
└── README.md
```

## 开发

```bash
# 本地目录安装（改完重启 Harness 即生效）
dsh plugin --profile desktop add link:D:/path/to/dsh-sidebar-dock
```

插件通过 `window.__ModuleLoader__.load({ id, factory(require) {...} })` 注册客户端模块，文件是纯 CommonJS 风格、无构建步骤。

## 许可

[MIT](LICENSE)

---

### English

`dsh-sidebar-dock` is a DeepSeek Harness sidebar plugin: collapse / expand the global sidebar entries with an animation, reorder them by dragging, pin frequently used ones so they stay visible when collapsed, and choose how the sidebar looks on the first launch after quitting the app (`collapsed`, `expanded`, or `remember last`). All changes are reversible inline styles on the host's own rows — no host code is patched.
