/**
 * One Claude Agent SDK query: options assembly, process seam projection, and
 * the headless interaction policy. The driver runs exactly one query per dsh
 * step; this module owns no session state.
 *
 * @module dsh-omniloop/engine-claude/sdk
 */

import type {
  Options,
  PermissionMode,
  SpawnOptions,
} from '@anthropic-ai/claude-agent-sdk'
import type { SubprocessHandle, SubprocessSpawnSpec } from '@deepseek-ai/dsh-subprocess'
import { scrubbedParentEnv } from '@deepseek-ai/dsh-subprocess'
import type { ClaudeCodeBackend } from './types.ts'
import { ManagedClaudeCodeProcess, claudeSpawnSpec } from './process.ts'

/** Native lock-down mode fixed for every query unless deployment overrides it. */
export const DEFAULT_PERMISSION_MODE = 'dontAsk' as const
/** Grace in milliseconds for Claude Code process-tree termination. */
export const DEFAULT_DISPOSE_GRACE_MS = 3000
/** A non-interactive submission can auto-deny or accept edits, but never blocks. */
const UNATTENDED_DIALOG_KINDS = ['refusal_fallback_prompt'] satisfies NonNullable<Options['supportedDialogKinds']>

export type { PermissionMode }

/** Deployment-owned process-spawn capability handed over from the plugin. */
export type SpawnCapability = (spec: SubprocessSpawnSpec) => SubprocessHandle

/** Everything one SDK query needs, resolved at step time. */
export interface ClaudeCodeQuerySpec {
  /** Absolute workspace the Claude Code process runs in. */
  readonly cwd: string
  /** Native permission handling for this query. */
  readonly permissionMode: PermissionMode
  /** Explicit environment entries layered over the scrubbed parent environment. */
  readonly env?: Record<string, string>
  /**
   * Provider routing derived from dsh's own LLM configuration, when the model
   * selection named a route this plugin could resolve.
   *
   * Kept separate from {@link env} because it does not merely add entries: a
   * derived route is authoritative about which backend the child speaks, so
   * every *other* backend's keys are removed rather than left to out-rank it.
   * The deployment's `env` still layers on top, so an explicit override wins.
   */
  readonly providerEnv?: Record<string, string>
  /** Grace in milliseconds for process-tree termination. */
  readonly disposeGraceMs: number
  /** Model override for the SDK, when a selection or the deployment pins one. */
  readonly model?: string
  /** Provider route the model id belongs to, used to diagnose a backend mismatch. */
  readonly provider?: string
  /** Provider backend the child is pointed at; defaults to `auto`. */
  readonly backend?: ClaudeCodeBackend
  /** Cap on the number of conversation turns before the query stops. */
  readonly maxTurns?: number
  /**
   * Decide one native permission request through the dsh approval seam.
   * When present, `canUseTool` forwards to it instead of auto-denying.
   */
  readonly onToolPermission?: (toolName: string, input: Record<string, unknown>, signal: AbortSignal) => Promise<'allow' | 'deny'>
  /** Spawn the Claude Code child under the shared process owner. */
  readonly spawn: SpawnCapability
  /** Receive a human-readable denial or decline for one unattended interaction. */
  readonly onUnattended?: (description: string) => void
}

/**
 * Diagnose one auto-answered interaction in headless mode.
 * @param mode - permission mode in force.
 * @param kind - what the interaction was.
 * @param answer - what the driver did.
 * @param why - reason the driver cannot forward the interaction.
 * @returns a stable one-line diagnostic.
 */
export function unattendedDiagnostic(
  mode: PermissionMode,
  kind: string,
  answer: string,
  why: string,
): string {
  return `claude-code: ${kind} ${answer} (mode ${mode}): ${why}`
}

/**
 * Backend-selecting env keys, grouped because the CLI resolves them by
 * precedence rather than by merging: with `CLAUDE_CODE_USE_BEDROCK` set, an
 * `ANTHROPIC_BASE_URL` pointing at a relay is ignored outright, and a model the
 * relay serves comes back as "not available on your bedrock deployment".
 *
 * So exactly one group is forwarded and the rest are actively removed. Order
 * is the `auto` precedence: a relay is a deliberate local choice, so it wins
 * over ambient cloud credentials that a login may have left behind.
 */
const BACKEND_ENV_GROUPS = [
  {
    /**
     * Native protocol against an explicit endpoint — typically a local relay,
     * where AUTH_TOKEN is often a placeholder.
     */
    id: 'relay',
    selector: 'ANTHROPIC_BASE_URL',
    keys: ['ANTHROPIC_BASE_URL', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_API_KEY'],
  },
  {
    /** Bedrock, direct or behind a corporate gateway. */
    id: 'bedrock',
    selector: 'CLAUDE_CODE_USE_BEDROCK',
    keys: [
      'CLAUDE_CODE_USE_BEDROCK',
      'ANTHROPIC_BEDROCK_BASE_URL',
      'AWS_BEARER_TOKEN_BEDROCK',
      // A gateway terminating TLS with a private CA, or rejecting HTTP/2,
      // hangs without these rather than failing loudly.
      'AWS_BEDROCK_FORCE_HTTP1',
      'AWS_ACCESS_KEY_ID',
      'AWS_SECRET_ACCESS_KEY',
      'AWS_SESSION_TOKEN',
      'AWS_REGION',
      'AWS_DEFAULT_REGION',
      'AWS_PROFILE',
    ],
  },
  {
    /** Vertex. */
    id: 'vertex',
    selector: 'CLAUDE_CODE_USE_VERTEX',
    keys: ['CLAUDE_CODE_USE_VERTEX', 'CLOUD_ML_REGION', 'ANTHROPIC_VERTEX_PROJECT_ID'],
  },
  {
    /** Direct Anthropic with no explicit endpoint. */
    id: 'anthropic',
    selector: 'ANTHROPIC_API_KEY',
    keys: ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN'],
  },
] as const satisfies readonly {
  id: ClaudeCodeBackend
  selector: string
  keys: readonly string[]
}[]

/**
 * Env keys forwarded regardless of backend: model routing, transport, and
 * chatter suppression. None of these select a backend, so no group owns them
 * and no backend choice — inherited or derived — may drop them.
 *
 * The proxy trio survives scrubbedParentEnv() on its own (it matches no
 * sensitive pattern) and is listed for readability — one table describing
 * everything the child needs to reach a provider.
 */
const SHARED_ENV_KEYS = [
  'ANTHROPIC_MODEL',
  'ANTHROPIC_DEFAULT_OPUS_MODEL',
  'ANTHROPIC_DEFAULT_SONNET_MODEL',
  'ANTHROPIC_DEFAULT_HAIKU_MODEL',
  'ANTHROPIC_SMALL_FAST_MODEL',
  'NODE_TLS_REJECT_UNAUTHORIZED',
  'HTTP_PROXY',
  'HTTPS_PROXY',
  'NO_PROXY',
  'http_proxy',
  'https_proxy',
  'no_proxy',
  'DISABLE_NON_ESSENTIAL_MODEL_CALLS',
  'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC',
] as const

/**
 * Re-inherit the credentials and routing the CLI needs, forwarding exactly one
 * backend so a second cannot take precedence over the intended endpoint.
 *
 * @param backend - the deployment's choice; `auto` takes the first configured.
 * @returns env entries to lay over the scrubbed parent environment.
 */
function inheritedLlmCredentials(backend: ClaudeCodeBackend): Record<string, string> {
  const creds: Record<string, string> = {}
  const chosen = backend === 'auto'
    ? BACKEND_ENV_GROUPS.find((group) => process.env[group.selector] !== undefined)
    : BACKEND_ENV_GROUPS.find((group) => group.id === backend)
  for (const key of chosen?.keys ?? []) {
    const value = process.env[key]
    if (value !== undefined) creds[key] = value
  }
  return creds
}

/**
 * Re-inherit the entries that hold for every backend.
 *
 * Kept apart from {@link inheritedLlmCredentials} because the two are inherited
 * for opposite reasons. Backend groups are mutually exclusive — the CLI resolves
 * them by precedence rather than by merging, so forwarding two silently runs the
 * child on the wrong one. Nothing here selects a backend: a proxy, a TLS
 * setting, or a model alias is equally true whichever endpoint the child talks
 * to. Folding them into the backend choice meant a derived route, which
 * displaces that choice entirely, also lost its proxy and TLS settings.
 *
 * @returns env entries to lay over the scrubbed parent environment.
 */
function inheritedSharedEnv(): Record<string, string> {
  const shared: Record<string, string> = {}
  for (const key of SHARED_ENV_KEYS) {
    const value = process.env[key]
    if (value !== undefined) shared[key] = value
  }
  return shared
}

/**
 * Compose the child environment: the scrubbed parent, minus every backend the
 * caller did not select, plus the selected backend's credentials and routing,
 * the resolved model, and the deployment's explicit entries last.
 *
 * The subtraction matters. scrubbedParentEnv() only drops secrets, so plain
 * selectors like `CLAUDE_CODE_USE_BEDROCK` reach the child on their own and
 * outrank a relay's `ANTHROPIC_BASE_URL` — leaving the CLI on the wrong
 * backend even though nothing re-inherited it.
 *
 * A derived `providerEnv` displaces *backend* inheritance entirely rather than
 * merging with it: dsh's own configuration is a better answer than whatever
 * shell launched the host, and a half-inherited second backend would out-rank it
 * by the CLI's own precedence rules. So when one is present, every backend key
 * outside it is removed and no backend is re-inherited.
 *
 * The shared entries are inherited either way. They select no backend, so the
 * displacement that protects the route's endpoint has no reason to reach them —
 * and a derived route needs a corporate proxy or a private CA's TLS setting at
 * least as much as an inherited one does. The route's own entries sit above
 * them, so a `childEnv` naming the same key wins.
 *
 * `ANTHROPIC_MODEL` sits below `spec.env` so a deployment that pins one in
 * config still beats the dsh selection, and above the inherited value so the
 * selection beats whatever shell launched the host.
 *
 * @param spec - the query spec carrying the model and the deployment's env overlay.
 * @returns the child environment.
 */
function claudeChildEnv(spec: ClaudeCodeQuerySpec): Record<string, string> {
  const derived = spec.providerEnv
  const selected = derived ?? inheritedLlmCredentials(spec.backend ?? 'auto')
  const env: Record<string, string> = { ...scrubbedParentEnv() }
  for (const group of BACKEND_ENV_GROUPS) {
    for (const key of group.keys) {
      if (!(key in selected)) delete env[key]
    }
  }
  return {
    ...env,
    ...inheritedSharedEnv(),
    ...selected,
    ...spec.model === undefined ? {} : { ANTHROPIC_MODEL: spec.model },
    ...spec.env,
  }
}

/**
 * Describe the backend the child will actually run on.
 *
 * A misrouted child fails far from its cause: with nothing configured the CLI
 * falls back to its own login state and reports "Not logged in", and with the
 * wrong backend it reports a model that is "not available". Neither names the
 * environment, so state the resolved routing up front.
 *
 * @param env - the composed child environment.
 * @param backend - the deployment's choice.
 * @returns a one-line diagnostic, or undefined when routing is unambiguous.
 */
export function backendDiagnostic(
  env: Record<string, string>,
  backend: ClaudeCodeBackend,
): string | undefined {
  const active = BACKEND_ENV_GROUPS.find((group) => env[group.selector] !== undefined)
  if (active === undefined) {
    return `claude-code: no provider backend configured (backend ${backend}); `
      + 'the CLI will fall back to its own login state. Set ANTHROPIC_BASE_URL '
      + 'for a relay, or CLAUDE_CODE_USE_BEDROCK/CLAUDE_CODE_USE_VERTEX, via the '
      + "plugin's `env` config or the environment dsh was launched from."
  }
  if (backend === 'auto' && active.id !== BACKEND_ENV_GROUPS[0].id) {
    return `claude-code: routing to ${active.id} (backend auto)`
  }
  return undefined
}

/**
 * Flag a model the active backend is unlikely to serve.
 *
 * The dsh selection names a provider route, and only a relay's endpoint is
 * deployment-chosen — so a selection routed at some other provider reaching a
 * cloud backend is a mismatch the child will discover as an opaque
 * model-not-found. The id is still sent as-is: the caller asked for it, the
 * provider lists it, and refusing here would substitute a model the user did
 * not pick.
 *
 * @param model - the resolved model id.
 * @param provider - the provider route the selection named, when it named one.
 * @param env - the composed child environment.
 * @returns a one-line diagnostic, or undefined when nothing looks wrong.
 */
export function modelDiagnostic(
  model: string | undefined,
  provider: string | undefined,
  env: Record<string, string>,
): string | undefined {
  if (model === undefined || provider === undefined) return undefined
  const active = BACKEND_ENV_GROUPS.find((group) => env[group.selector] !== undefined)
  // A relay endpoint is whatever the deployment pointed it at, so any provider
  // may legitimately be behind it; only a cloud backend implies a fixed catalog.
  if (active === undefined || active.id === 'relay') return undefined
  return `claude-code: selected model "${model}" (provider ${provider}) may not be `
    + `served by the ${active.id} backend; sending it as-is.`
}

/**
 * Build the fixed official SDK options for one step's query.
 * @param spec - workspace, environment, process seam, and disposal policy.
 * @param controller - per-query cancellation owner.
 * @returns the options for one stateless query.
 */
export function claudeQueryOptions(
  spec: ClaudeCodeQuerySpec,
  controller: AbortController,
): Options {
  const report = spec.onUnattended ?? (() => {})
  const forward = spec.onToolPermission
  const childEnv = claudeChildEnv(spec)
  const routing = backendDiagnostic(childEnv, spec.backend ?? 'auto')
  if (routing !== undefined) report(routing)
  // A derived route cannot be a mismatch: the backend was built *from* the
  // provider the model belongs to, so the catalog check below would only ever
  // report the pairing it just constructed.
  if (spec.providerEnv === undefined) {
    const mismatch = modelDiagnostic(spec.model, spec.provider, childEnv)
    if (mismatch !== undefined) report(mismatch)
  }
  return {
    abortController: controller,
    cwd: spec.cwd,
    env: childEnv,
    // Emit `stream_event` partial messages so the loop can forward token
    // deltas to the dsh session as `assistant/chunk` events (the web surface
    // streams those). Without it the SDK yields only complete `assistant`
    // messages, so the surface renders each response all at once.
    includePartialMessages: true,
    // Forward subagent text and thinking blocks so the driver can render a
    // nested transcript inside the parent step. Without it the SDK yields
    // only heartbeat tool_use/tool_result frames for subagents, and the
    // parent session shows the Task tool call with no inner visibility.
    forwardSubagentText: true,
    persistSession: true,
    disallowedTools: spec.permissionMode === 'plan'
      ? ['AskUserQuestion', 'ExitPlanMode']
      : ['AskUserQuestion'],
    permissionMode: spec.permissionMode,
    ...spec.model === undefined ? {} : { model: spec.model },
    ...spec.maxTurns === undefined ? {} : { maxTurns: spec.maxTurns },
    ...spec.permissionMode === 'bypassPermissions'
      ? { allowDangerouslySkipPermissions: true }
      : {
        canUseTool: forward === undefined
          ? (): Promise<{ behavior: 'deny'; message: string }> => {
            report(unattendedDiagnostic(
              spec.permissionMode,
              'tool permission',
              'denied',
              'the Claude Code driver does not request human approval',
            ))
            return Promise.resolve({
              behavior: 'deny',
              message: 'This unattended Claude Code driver cannot request human approval.',
            })
          }
          : async (toolName, input, { signal }) => {
            const verdict = await forward(toolName, input, signal)
            return verdict === 'allow'
              ? { behavior: 'allow' as const, updatedInput: input }
              : { behavior: 'deny' as const, message: 'The dsh user rejected this action.' }
          },
      },
    onElicitation: (): Promise<{ action: 'decline' }> => {
      report(unattendedDiagnostic(
        spec.permissionMode,
        'MCP elicitation',
        'declined',
        'the driver does not collect interactive MCP input',
      ))
      return Promise.resolve({ action: 'decline' })
    },
    onUserDialog: (): Promise<{ behavior: 'cancelled' }> => {
      report(unattendedDiagnostic(
        spec.permissionMode,
        'user dialog',
        'cancelled',
        'the driver does not render blocking dialogs',
      ))
      return Promise.resolve({ behavior: 'cancelled' })
    },
    supportedDialogKinds: UNATTENDED_DIALOG_KINDS,
    spawnClaudeCodeProcess: (options: SpawnOptions) => {
      const child = spec.spawn(claudeSpawnSpec(options, spec.disposeGraceMs))
      return new ManagedClaudeCodeProcess(child)
    },
  }
}
