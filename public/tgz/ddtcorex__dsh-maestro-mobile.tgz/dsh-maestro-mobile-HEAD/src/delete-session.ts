/**
 * dsh-maestro-mobile, host half: session deletion.
 *
 * The host session menu knows rename / fork / archive; archive only hides a
 * row. Deleting a session is the one host capability the mobile drawer needs
 * and the harness does not provide.
 *
 * Ported from mexiaosqwq/dsh-web-mobile v2.4.1 (`src/delete-session.ts`), which
 * itself ports community-fork wzxmt-zhc v2.7.0. Adapted and re-verified
 * against the host this plugin runs on (DSH 0.2.0-rc.2 and later):
 *
 * 1. `persistence.list()` returns snapshots that carry `.header`.
 * 2. Live-session teardown uses the agent disposal face (`cancel` +
 *    `whenIdle`), which every supported host's `Agent` exposes; a live
 *    session that does not converge to idle is refused with 409 `session-busy`.
 * 3. Workspace accounting is optional per workspace: `detachSession` may not
 *    exist, and a failing account must never fail a finished deletion.
 *
 * The JSONL backend stores one directory per session under its public
 * `config.root`:
 *
 *   <root>/<projectKey(cwd)>/<encodeSegment(id)>/
 *
 * `projectKey` / `encodeSegment` here mirror
 * `@deepseek-ai/dsh-session-persistence-jsonl` `src/format.ts` byte for byte and
 * are pinned by unit tests against goldens taken from that module plus this
 * machine's live storage layout. The resolved path is refused when it does not
 * sit inside the storage root.
 *
 * The directory is MOVED INTO A TRASH, not removed: the canonical payloads are
 * renamed with a `.trash` suffix and the directory is stashed under
 * `<root>/.sessions-trash/<timestamp>-<project>-<id>/`, with a best-effort
 * `manifest.json` recording the restore mapping. The rename order is
 * load-bearing — see `moveToTrash`. Entries older than 24 hours are purged,
 * best effort, on a later deletion; no timer is ever created. A failure after a
 * LIVE session was already stopped reports `cleanup-failed` with
 * `deletedLiveSession`, so the caller is never told a session is intact when it
 * is already gone.
 *
 * Attachment bytes are content-addressed in a shared backend and are NOT
 * removed; they only become unreachable garbage once no log references them.
 */
import { mkdir, readdir, rename, rm, stat, writeFile } from 'node:fs/promises'
import type { Dirent } from 'node:fs'
import { join, relative, resolve, sep } from 'node:path'

/** How long to wait for a live agent to converge to idle before refusing. */
const IDLE_TIMEOUT_MS = 20_000

/** Where deleted session directories are stashed, under the storage root. */
export const TRASH_DIR_NAME = '.sessions-trash'

/** Trash entries older than this are purged (best effort) after a later move. */
export const TRASH_TTL_MS = 24 * 60 * 60 * 1000

/**
 * The canonical payload names the host's session scan recognizes, mirroring
 * `sessionFormatLogFilename` + the compression suffix
 * (`packages/session/session-format/src/filename.ts`): the v0 name is
 * `session.jsonl`, later generations are `session.vN.jsonl`, and either carries
 * `.zstd` under the compressed encoding. Temporary, uppercase, leading-zero and
 * `.v0`-tagged names are not canonical, so the pattern must not widen to accept
 * them — its whole job is to decide which files the host is still able to see.
 */
const PAYLOAD_NAME = /^session(?:\.v[1-9][0-9]*)?\.jsonl(?:\.zstd)?$/

/**
 * Which stage of the trash move failed, carried on the thrown error so the
 * caller can describe the state that actually obtains.
 *
 * - `rename-payloads`: no canonical payload was renamed, the directory is
 *   exactly as it was;
 * - `stash`: the payloads were renamed (the session is already hidden from the
 *   host list) but the directory itself is still in place.
 */
type TrashStage = 'rename-payloads' | 'stash'

/** A failed trash move, tagged with the stage it failed in. */
class TrashMoveError extends Error {
  readonly stage: TrashStage

  constructor(stage: TrashStage, cause: unknown) {
    super(errorMessage(cause))
    this.stage = stage
  }
}

/** One entry of `persistence.list()`: a snapshot carrying the session header. */
interface PersistenceListEntry {
  readonly header?: { readonly id?: unknown; readonly cwd?: unknown }
}

/** The `Agent` disposal face the teardown drives. */
interface AgentDisposal {
  cancel(cause: { kind: 'disposed' }): void
  whenIdle(): Promise<void>
}

/** Structural host services the deletion flow depends on (no harness import). */
export interface DeleteSessionDeps {
  persistence: {
    /** The JSONL backend exposes its configured root publicly (`config.root`). */
    config?: { root?: string }
    list(): Promise<readonly PersistenceListEntry[]>
  }
  sessions?: {
    get(id: string): unknown
    flush(session: unknown): Promise<unknown>
  }
  agents?: {
    get(id: string): AgentDisposal | undefined
  }
  workspaceRegistry?: {
    list(): readonly { detachSession?(id: string): Promise<void> }[]
  }
}

/** Which optional host faces the deletion flow can use on this host. */
export interface DeleteCapabilities {
  /** The JSONL backend publishes its storage root (`config.root`). */
  readonly storageRoot: boolean
  /** The live-agent/session teardown faces (`store`, `detach`, `detachEntered`) are present. */
  readonly liveTeardown: boolean
}

/**
 * Probe the host faces this flow reads through non-contractual members.
 *
 * `sessions.store`/`entry.detach()`, `agents.store`/`detachEntered()` and
 * `persistence.config.root` all exist on 0.2.2-alpha.2 but are declared
 * `private` in the shipped types. A TypeScript `private` is erased at runtime,
 * so the read works today; this probe turns a future rename into one warning at
 * load time instead of a delete that reports success and leaves the session
 * registered.
 * @param deps - the injected host services.
 * @returns which optional faces are usable here.
 */
export function deleteCapabilities(deps: DeleteSessionDeps): DeleteCapabilities {
  const root = deps.persistence.config?.root
  const sessions = deps.sessions as unknown as { store?: unknown } | undefined
  const agents = deps.agents as unknown as
    | { store?: unknown; detachEntered?: unknown }
    | undefined
  const sessionFace = sessions?.store instanceof Map
  const agentFace = agents?.store instanceof Map && typeof agents.detachEntered === 'function'
  return {
    storageRoot: typeof root === 'string' && root !== '',
    liveTeardown: sessionFace || agentFace,
  }
}

/** Structured outcome the HTTP layer maps to a status code. */
export type DeleteSessionResult =
  | { status: 200; ok: true; deleted: string }
  | { status: 404; ok: false; error: { code: 'session-not-found'; message: string } }
  | { status: 409; ok: false; error: { code: 'session-busy'; message: string } }
  | {
    status: 500
    ok: false
    /**
     * Set when the session was already stopped and unregistered before the
     * failure, so the caller can tell "nothing happened" from "the session is
     * gone, only the leftovers remain".
     */
    deletedLiveSession?: true
    error: { code: 'delete-lookup-failed' | 'delete-failed' | 'cleanup-failed'; message: string }
  }
  | { status: 503; ok: false; error: { code: 'persistence-unavailable'; message: string } }

/**
 * Escape one raw session id into one filesystem-safe path segment, mirroring
 * the backend: safe code units stay literal, everything else (including `~`)
 * becomes `~XXXX`, and `.` / `..` are special-cased so an otherwise safe whole
 * segment cannot traverse.
 * @param raw - the string to encode; must be non-empty.
 * @returns the escaped single path segment.
 */
export function encodeSegment(raw: string): string {
  if (raw.length === 0) throw new Error('cannot encode an empty path segment')
  if (raw === '.') return '~002E'
  if (raw === '..') return '~002E~002E'
  let out = ''
  for (let i = 0; i < raw.length; i++) {
    const code = raw.charCodeAt(i)
    const ch = String.fromCharCode(code)
    if (ch !== '~' && /^[A-Za-z0-9._-]$/.test(ch)) {
      out += ch
    } else {
      out += '~' + code.toString(16).toUpperCase().padStart(4, '0')
    }
  }
  return out
}

/**
 * Build the readable directory key for a project path, mirroring the backend:
 * separators collapse into `-`, unsafe code units use the `~XXXX` escape, and
 * the result is bounded for filesystem component limits.
 * @param cwd - the session's project directory.
 * @returns a single filesystem-safe project directory name.
 */
export function projectKey(cwd: string): string {
  if (cwd.length === 0) throw new Error('cannot encode an empty project path')
  let readable = ''
  let separatorRun = false
  for (let i = 0; i < cwd.length; i++) {
    const code = cwd.charCodeAt(i)
    const ch = String.fromCharCode(code)
    if (ch === '/' || ch === '\\' || ch === ':') {
      if (!separatorRun) readable += '-'
      separatorRun = true
    } else if (ch !== '~' && /^[A-Za-z0-9._-]$/.test(ch)) {
      readable += ch
      separatorRun = false
    } else {
      readable += '~' + code.toString(16).toUpperCase().padStart(4, '0')
      separatorRun = false
    }
  }
  const slug = readable.replace(/^-+/, '') || 'root'
  return `--${slug.slice(0, 251)}--`
}

/**
 * The directory one session owns under the storage root.
 * @param root - the backend's configured session root.
 * @param cwd - the session's project directory (`undefined` → `_no-cwd`).
 * @param id - the session id, encoded to one safe path segment.
 * @returns the absolute-ish session directory path.
 */
export function sessionDir(root: string, cwd: string | undefined, id: string): string {
  const project = cwd === undefined ? '_no-cwd' : projectKey(cwd)
  return join(root, project, encodeSegment(id))
}

/** Whether `target` resolves to a path inside `root` (escape defence). */
function isInside(root: string, target: string): boolean {
  const rel = relative(root, target)
  return rel !== '..' && !rel.startsWith('..' + sep) && rel !== ''
}

/** Bound a promise with a rejection deadline so a stuck agent cannot hang the endpoint. */
function withTimeout<T>(promise: Promise<T>, ms: number, message: string): Promise<T> {
  return new Promise((resolvePromise, reject) => {
    const timer = setTimeout(() => reject(new Error(message)), ms)
    promise.then(
      (value) => { clearTimeout(timer); resolvePromise(value) },
      (error) => { clearTimeout(timer); reject(error) },
    )
  })
}

/** Unregister a live agent through runtime-visible store internals, if present. */
function detachLiveAgent(agents: DeleteSessionDeps['agents'] | undefined, id: string): void {
  const registry = agents as unknown as
    | { store?: Map<string, unknown>; detachEntered?: (entry: unknown) => void }
    | undefined
  const entry = registry?.store?.get(id)
  if (entry !== undefined) registry?.detachEntered?.(entry)
}

/** Unregister a live session through runtime-visible store internals, if present. */
function detachLiveSession(sessions: DeleteSessionDeps['sessions'] | undefined, id: string): void {
  const store = sessions as unknown as
    | { store?: Map<string, { detach?: () => void }> }
    | undefined
  store?.store?.get(id)?.detach?.()
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}

/** Whether one failure means "the path is not there" (an idempotent delete). */
function isEnoent(error: unknown): boolean {
  return typeof error === 'object' && error !== null
    && (error as { code?: unknown }).code === 'ENOENT'
}

/**
 * Remove a deleted session from every workspace account. Optional per
 * workspace, and never allowed to fail an already-finished deletion: a stale id
 * stays in the record until the host reconciles it.
 */
async function detachFromWorkspaces(deps: DeleteSessionDeps, sessionId: string): Promise<void> {
  if (deps.workspaceRegistry === undefined) return
  for (const workspace of deps.workspaceRegistry.list()) {
    try {
      await workspace.detachSession?.(sessionId)
    } catch {
      // Accounting is best-effort; the log is already gone.
    }
  }
}

/**
 * Move one session's stored directory into the trash instead of removing it.
 *
 * The two stages are ordered deliberately. The canonical payloads are renamed
 * with a `.trash` suffix FIRST, because the host treats every directory under
 * the storage root as a project directory and scans each of its children as a
 * session directory — so it descends into the trash root. A canonical payload
 * name there makes the host compare a stored header against the trash
 * directory's derived identity, and the plain error that raises is not among
 * the failures `listArtifacts` filters, so the WHOLE session list fails to
 * load. Renaming first makes the entry invisible before it moves.
 *
 * `manifest.json` records the restore mapping, but the mapping is also
 * deterministic without it: strip the `.trash` suffix.
 * @param root - the resolved session storage root.
 * @param dir - the session directory to stash.
 * @param cwd - the session's project directory, for the trash entry name.
 * @param sessionId - the session being deleted.
 */
async function moveToTrash(
  root: string,
  dir: string,
  cwd: string | undefined,
  sessionId: string,
): Promise<void> {
  let entries: Dirent[]
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch (error) {
    // Nothing stored: the delete is idempotent and there is nothing to stash.
    if (isEnoent(error)) return
    throw new TrashMoveError('rename-payloads', error)
  }

  const renamed: { from: string; to: string }[] = []
  for (const entry of entries) {
    if (!entry.isFile() || !PAYLOAD_NAME.test(entry.name)) continue
    const to = `${entry.name}.trash`
    try {
      await rename(join(dir, entry.name), join(dir, to))
    } catch (error) {
      throw new TrashMoveError('rename-payloads', error)
    }
    renamed.push({ from: entry.name, to })
  }

  const trashRoot = join(root, TRASH_DIR_NAME)
  const project = cwd === undefined ? '_no-cwd' : projectKey(cwd)
  const trashDir = join(trashRoot, `${new Date().toISOString().replaceAll(':', '-')}-${project}-${encodeSegment(sessionId)}`)
  try {
    await mkdir(trashRoot, { recursive: true })
    await rename(dir, trashDir)
  } catch (error) {
    throw new TrashMoveError('stash', error)
  }

  try {
    const manifest = { id: sessionId, cwd, deletedAt: new Date().toISOString(), files: renamed }
    await writeFile(join(trashDir, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`)
  } catch {
    // The entry is already invisible to the host scan, so a failed manifest
    // only degrades the restore info; the mapping stays deterministic.
  }

  await purgeStaleTrash(trashRoot)
}

/**
 * Delete trash entries older than {@link TRASH_TTL_MS}. Runs inline after a
 * successful move rather than on a timer: the plugin owns no long-lived
 * background work, and a deletion is exactly when trash grows.
 */
async function purgeStaleTrash(trashRoot: string): Promise<void> {
  try {
    const cutoff = Date.now() - TRASH_TTL_MS
    for (const name of await readdir(trashRoot)) {
      try {
        const stats = await stat(join(trashRoot, name))
        if (stats.mtimeMs < cutoff) await rm(join(trashRoot, name), { recursive: true, force: true })
      } catch {
        // An entry that vanished or cannot be stat-ed is skipped; the purge is
        // best effort and must never fail the deletion that triggered it.
      }
    }
  } catch {
    // An unreadable trash root only skips the purge; the deletion already
    // succeeded and is not affected.
  }
}

/**
 * Read the id and cwd off one `persistence.list()` snapshot. Entries without a
 * usable id are skipped.
 * @param entry - one list entry.
 * @returns the id and optional cwd, or undefined when unusable.
 */
function entryHeader(entry: PersistenceListEntry): { id: string; cwd?: string } | undefined {
  const header = entry.header
  if (header === undefined || typeof header.id !== 'string' || header.id === '') return undefined
  return {
    id: header.id,
    cwd: typeof header.cwd === 'string' ? header.cwd : undefined,
  }
}

/**
 * Delete one session: stop it if live, remove its persisted directory, and
 * detach it from every workspace account.
 * @param deps - injected host services; the flow never imports the harness.
 * @param sessionId - the session to delete.
 * @returns a structured result the caller maps to an HTTP response.
 */
export async function deleteSession(deps: DeleteSessionDeps, sessionId: string): Promise<DeleteSessionResult> {
  const root = deps.persistence.config?.root
  if (root === undefined || root === '') {
    return {
      status: 503,
      ok: false,
      error: {
        code: 'persistence-unavailable',
        message: 'session persistence is not configured with a storage root',
      },
    }
  }

  let snapshot: { id: string; cwd?: string } | undefined
  try {
    snapshot = (await deps.persistence.list())
      .map(entryHeader)
      .find((header) => header !== undefined && header.id === sessionId)
  } catch (error) {
    return {
      status: 500,
      ok: false,
      error: {
        code: 'delete-lookup-failed',
        message: `failed to look up the session: ${errorMessage(error)}`,
      },
    }
  }
  if (snapshot === undefined) {
    return {
      status: 404,
      ok: false,
      error: { code: 'session-not-found', message: `no such session '${sessionId}'` },
    }
  }

  // Live sessions: stop the agent (cancel + whenIdle), flush and detach before
  // the log is moved; a session that cannot be stopped is refused with 409.
  const live = deps.sessions?.get(sessionId)
  if (live !== undefined && deps.sessions !== undefined) {
    const handle = deps.agents?.get(sessionId)
    try {
      if (handle !== undefined) {
        handle.cancel({ kind: 'disposed' })
        await withTimeout(
          handle.whenIdle(),
          IDLE_TIMEOUT_MS,
          `agent for session '${sessionId}' did not converge to idle within ${IDLE_TIMEOUT_MS}ms`,
        )
      }
      await deps.sessions.flush(live)
      detachLiveAgent(deps.agents, sessionId)
      detachLiveSession(deps.sessions, sessionId)
    } catch (error) {
      return {
        status: 409,
        ok: false,
        error: {
          code: 'session-busy',
          message: `cannot delete session '${sessionId}': it is running and could not be stopped: ${errorMessage(error)}`,
        },
      }
    }
  }

  const resolvedRoot = resolve(root)
  const dir = sessionDir(resolvedRoot, snapshot.cwd, sessionId)
  if (!isInside(resolvedRoot, dir)) {
    return {
      status: 500,
      ok: false,
      error: {
        code: 'delete-failed',
        message: `refusing to remove '${dir}': it resolves outside the session storage root`,
      },
    }
  }
  try {
    await moveToTrash(resolvedRoot, dir, snapshot.cwd, sessionId)
  } catch (error) {
    const stage = error instanceof TrashMoveError ? error.stage : 'stash'
    if (live !== undefined) {
      // The live session was already stopped, flushed and unregistered above, so
      // settle the workspace accounting now and name the real state: a plain
      // failure would imply a session that no longer exists and would leave the
      // account holding a zombie id.
      await detachFromWorkspaces(deps, sessionId)
      return {
        status: 500,
        ok: false,
        deletedLiveSession: true,
        error: {
          code: 'cleanup-failed',
          message: stage === 'rename-payloads'
            ? `session '${sessionId}' was stopped and unregistered, but its log directory could not be moved to the trash and remains untouched in place: ${errorMessage(error)}; the session will not resume — retry the delete to clean up the leftover files`
            : `session '${sessionId}' was stopped and unregistered, but its log directory could only be partially stashed (payloads renamed, directory still in place): ${errorMessage(error)}; the session will not resume — its payloads carry a ".trash" suffix and the session is hidden from the list: restore the original names (strip the suffix) and delete again to finish the move, or remove the directory manually`,
        },
      }
    }
    return {
      status: 500,
      ok: false,
      error: {
        code: 'delete-failed',
        message: stage === 'rename-payloads'
          ? `failed to move the session log to the trash: ${errorMessage(error)} (the directory is untouched)`
          : `failed to stash the session log directory: ${errorMessage(error)} (payloads were renamed, so the session is hidden from the list until restored)`,
      },
    }
  }

  await detachFromWorkspaces(deps, sessionId)
  return { status: 200, ok: true, deleted: sessionId }
}
