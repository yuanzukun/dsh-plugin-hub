# dsh-maestro-mobile

Mobile adaptation for the DeepSeek Harness (DSH) Web UI. On touch-primary devices it turns the sidebar into an overlay drawer, sheets the dialogs, tunes the composer for phones, and adds session deletion to the session-row menu; a mouse-driven window, at every width, is a complete no-op.

Names by boundary: npm package = `@ddtcorex/dsh-maestro-mobile`; Cordis patch row id = `maestro-mobile` (see `cordis.patch.yml`).

## Layout

- `src/index.ts` — host half: transparent response compression (`compress.ts`) plus the session-delete route; `src/delete-session.ts` is the harness-free deletion core and `src/delete-route.ts` the request gate.
- `src/client/index.tsx` — browser half. Injects `['slots','layout','locale','sessionLogDownload','sessions','workspaces']`, registers locale dictionaries, injects one `<style data-plugin>` tag, installs effects, and registers three slots:
  - `shell.overlay` → `ShellOverlay`: backdrop + FAB
  - `conversation.session.header.actions` → `MobileNavToggle`: drawer toggle + Files button
  - `sidebar.footer.action` → `MobileDrawerFooter`: Files + session-log actions
- `src/client/effects/` — DOM effects grouped by domain. `src/client/core/reconciler-core.ts` is a DOM-free engine (task registry, dirty-key routing, coalesced rAF flushing, per-task error isolation). `phone-chrome.ts` is the thin browser adapter: one `MutationObserver` on `document.documentElement` maps mutations to dirty keys and drives `installMobileEffect`.
- `src/client/styles/` — CSS as TypeScript string modules. `index.ts` concatenates `tokens → base → layout → sheet → explorer-sheet → composer → settings-sheet → misc` in that order into one `<style>` tag. Mobile rules target `(max-width: 1023px)`; desktop rules hide mobile controls and must preserve the uninstalled layout.
- `lib/` — gitignored build output (host ESM + inlined client bundle + d.ts). Generated; do not hand-edit, never commit.
- `scripts/` — custom client bundler (`build-client.mjs`), the CDP smoke probe (`cdp-probe.mjs`), the upstream contract scanner (`cdp-compat-contracts.mjs`) and one probe per risky behaviour under `scripts/probes/`.
- `docs/upstream/` — `compat-contracts.json` (every upstream marker / class fragment this plugin depends on, with the rule that needs it) and `upgrade-runbook.md` (the post-upgrade checklist).
- `docs/maintenance/pitfalls.md` — traps that already cost debugging time here; read it before writing a probe.
- `tests/` — `node:test` unit tests.

## Development

Run from the repository root:

```sh
pnpm install        # pnpm@11.7.0, lockfile v9
pnpm verify         # type-check host + client (tsc --noEmit)
pnpm test           # node --test tests/*.test.ts  (full suite: unit + CSS contract)
pnpm test:core      # node --test tests/reconciler-core.test.ts tests/composer-keyboard-touch.test.ts
pnpm build          # tsc host + client && node scripts/build-client.mjs  -> lib/
```

`pnpm build` is the required gate after any source change; `lib/` is gitignored, so rebuild locally after pull and before restart — a change is incomplete until the build refreshes it. `pnpm verify` + `pnpm test` are the local checks; `pnpm test:core` is the fast subset.

## Git workflow

- `master` is the default branch; do not commit directly to `master` — use `feat/<topic>` / `fix/<topic>` and a PR against `ddtcorex/dsh-maestro-mobile` (small doc fixes may use same PR flow).
- Conventional commits, imperative mood: `fix(mobile): ...`, `feat(mobile): ...`.
- One logical change = one commit. Never commit while `pnpm verify` is red.
- **Always request approval before merge or release:** never merge a PR/MR or publish a release (`git tag`/`pnpm publish`/`gh release`) without an explicit human `APPROVED` — request review (`gh pr ready` / `gh pr request-review` / ask in chat) and wait for `APPROVED`. Rebase feature branches when the base moves.

## Conventions

- **DSH peer range is `>=0.2.0-rc.2 <0.3.0-0 || >=0.2.2-0 <0.3.0-0`** on every `@deepseek-ai/dsh-*` peer. The second clause is not decoration: semver admits a prerelease only when a comparator names that exact `[major, minor, patch]` tuple, so the old single clause rejected `0.2.2-alpha.2` — the host this plugin runs on. `tests/dsh-peer-range.test.ts` asserts satisfiability with semver (bump `HOST_RELEASE_UNDER_TEST` with every host upgrade, or set `DSH_HOST_VERSION`), and the devDependencies pin the same packages to the release being verified so `pnpm verify` can never again type-check against a host the peers reject. A peer edit must ship with its `pnpm-lock.yaml` update.
- Keep the host/client split intact; the host half owns the session-delete route and the conditional compression patch, the browser half owns every DOM effect.
- **The compression patch installs only when the host does not compress.** 0.2.2 ships `compression@1.8.2` and the deployed profile enables it, and that middleware intercepts `writeHead` before a patched `ServerResponse.prototype` sees it, so the patch is inert there (measured: identical brotli body with and without it). `hostCompressionEnabled()` gates the install and fails OPEN on an unreadable host shape, because the host default is `compression: 'none'` and a default deployment still relies on it.
- Prefer stable `data-*` markers and structural selectors over hashed classes. For unavoidable hashed classes use substring matching (`[class*=_frag]`), never attribute-suffix (`[class$=…]`); scope to the owning region and guard prefix-overlapping fragments with `:not`.
- Put every long-lived style tag, listener, timer, or `MutationObserver` inside `ctx.effect(() => { ...; return disposer }, label)`. Re-arm query-sensitive effects through `installMobileEffect` (it owns the `matchMedia` + change listener) so wide→narrow and pointer changes work; pass `TOUCH_QUERY` for the features that have no desktop equivalent.
- **The mobile branch is pointer-gated, not width-gated.** `MOBILE_QUERY = '(max-width: 1023px) and (pointer: coarse)'` in `src/client/effects/phone-chrome.ts` is the single source of truth: JS effects and every narrow CSS block must use the identical predicate, and the desktop blocks use its exact complement `(min-width: 1024px), (pointer: fine), (pointer: none)`. A mouse-driven window of any width stays desktop. Headless Chrome reports `(pointer: none)` unless touch emulation is on — probes must call `Emulation.setTouchEmulationEnabled` (see `scripts/cdp-probe.mjs`) and assert the query.
- Treat DOM markers as the cross-module state contract: `data-mobile-nav="frame"`, `data-sidebar-collapsed`, `data-aionui-explorer-open`, `data-aionui-preview-open`, `data-mobile-preview-full`.
- **Identify an upstream trigger by what it declares or contains, never by being the first of its kind in a slot.** Upstream extends slots between releases (0.1.7 moved the subagent catalog into the session header's actions band ahead of the jobs control), so a first-match rule silently marks the wrong control. The jobs chip is identified by the popup roles its neighbours declare plus its own leading count badge or state dot, and the task refuses an ambiguous band; `pnpm probe:jobs-chip` gates it. The header band paints one 8px gap across its residents — no per-resident gutter, and never let it shrink below its content.
- **A scope that must survive upstream rebuilds follows a marker this plugin sets or a role upstream draws unconditionally — never a CSS-module hash.** The lineage chip's synthetic-hover swallow was scoped with the hashes of the day and matched nothing after 0.1.7 rebuilt the package, so it silently stopped firing; the chip's box now carries `data-lineage-root` and its portalled catalog is named by `role="tree"`. `pnpm probe:lineage-chip` gates mark/scope/swallow/toggle, and `tests/no-hashed-class-prefix.test.ts` fails the build on a hash prefix anywhere in `src/client`.
- **Draggable widgets yield the drawer swipe through `data-mobile-nav-dragging`.** A component that drags under the pointer must set that attribute while its drag is live — on the element the pointer is holding, on an ancestor, or globally on `body` / `documentElement`; set it in your `pointerdown`/first `pointermove` handler. The gesture layer (`src/client/effects/drag-yield.ts`) reads the mark when a stroke arms and again before the axis locks, and abandons the whole stroke, so a drag can never open the drawer mid-motion. Widgets that ship no mark are caught by a positional fallback (`position: fixed|absolute`, box ≤ 200px, outside our own frame subtree); that heuristic is an approximation — a real widget that misses it should adopt the mark.
- Use idempotent `ensure()` / reparent logic when injecting nodes into React-owned DOM; clean up moved nodes and listeners on disposal.
- Client runtime effects are synchronous DOM work. TypeScript style: single quotes, no semicolons, explicit exported return types, installer names `install<Domain>`.
- Keep CSS in `src/client/styles/`, not in component files. Preserve the `tokens → base → layout → sheet → explorer-sheet → composer → settings-sheet → misc` concatenation order and complete section boundaries.
- Preserve mobile-only behavior and modal precedence: capture-phase drawer handlers must yield to `[aria-modal="true"]` dialogs and ignore session-row action buttons. `transform: none` is required for the open drawer so fixed descendants keep the correct containing block.
- Never edit `lib/` directly; rebuild and include generated artifacts after any source/config change.

## Validation

After source / layout changes, verify in a real browser at both sides of the breakpoint (live DSH Web, not just curl/grep):

- **Phone ~390px** (touch emulation on): rail hidden; drawer / FAB / backdrop open and close; Escape; session-row action menus do not close the drawer; Settings usable; Files opens explorer/preview sheets; session-log/footer actions work; preview fullscreen opens and resets.
- **Narrow desktop window ~900px** (touch emulation off): the plugin is a complete no-op — no frame marker, no toggle/FAB, no stylesheet effect. This is the regression the pointer gate exists for.
- **Tablet 768–1023px**: centered, width-constrained sheet geometry.
- **Desktop ≥1024px**: compare with the plugin disabled — no layout or interaction change.

For phone debugging, add `?dsh-maestro-mobile-debug=1` to show live viewport / frame / floating-panel / JS-error state.

Optional CDP probe: `DSH_PROBE_SESSION_ID=<id> pnpm smoke:cdp` (env `DSH_PROBE_URL`, `DSH_PROBE_CHROME`), against a local DSH Web at `127.0.0.1:3080`.

## Security

The plugin carries no secrets, but it is no longer browser-only: the host half registers `POST /api/mobile-nav.session.delete`, which **destroys a session log**. Treat that route as a destructive surface:

- **It authenticates through the host, and that is not optional.** The launch-token fence on `:3082` is a `/api` PREFIX route owned by `dsh-client-connection`, and the web server matches an exact route before a prefix route, so a route registered on `webServer` alone never sees it (measured before the fix: `GET /api/file` answered 401 without a credential while this route's handler ran). `admitRequest()` therefore calls `connection.requestRejection(request)` on every request and **fails closed** (503 `admission-unavailable`) when the host publishes no such service. On top of that it keeps `delete-route.ts` defence in depth — POST only, reject `Sec-Fetch-Site: cross-site`, require an `Origin` whose host matches the request `Host` when one is present, treat a malformed `Origin` as hostile, and accept exactly one non-empty string `sessionId` in a byte-capped JSON body (64 KiB; an oversized body is drained and answered 413 `payload-too-large`, never destroyed mid-stream — destroying races the response).
- **Deletion is recoverable, not destructive.** The session directory moves into `<root>/.sessions-trash/` with every canonical payload renamed to `<name>.trash` plus a best-effort `manifest.json`; restoring is "strip the suffix". The rename MUST precede the directory move: the host scans every directory under the storage root, trash included, and a canonical payload name there breaks the whole session list (`docs/maintenance/pitfalls.md`). Entries expire after 24h, purged inline on a later deletion — never add a timer for it.
- **A failure after a LIVE session was torn down reports `cleanup-failed` with `deletedLiveSession: true`** and still settles the workspace accounting: the session is already stopped and unregistered, so a plain `delete-failed` would both mislead and leave a zombie id.
- Never widen the flow past confirmation-first: the mutation exists only behind the dialog's confirm button, and the client refuses to guess a row it cannot resolve with certainty.
- Never print, commit, or add fixture values for real tokens or PINs in tests or docs; tests use placeholder paths and derive live paths from `homedir()` / `import.meta.url`.
- Keep the host/client split intact; never modify third-party source packages to add behavior — use scoped DOM markers and CSS overrides.
