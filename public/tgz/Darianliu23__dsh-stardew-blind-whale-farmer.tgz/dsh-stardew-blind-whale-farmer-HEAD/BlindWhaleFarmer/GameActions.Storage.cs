using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using StardewValley;
using StardewValley.Objects;

namespace BlindWhaleFarmer
{
    internal sealed partial class GameActions
    {
        // ───────────────────────── 箱子存取 ─────────────────────────

        /// <summary>
        /// 当前地点里玩家放的箱子：给了坐标就用那一格，否则用最近的一个。
        /// 开局礼物箱（giftbox）不算，它打开就消失。
        /// </summary>
        private static Chest FindChest(int? x, int? y, out Point tile, out string error)
        {
            tile = default;
            error = null;
            if (x.HasValue && y.HasValue)
            {
                tile = new Point(x.Value, y.Value);
                if (Loc.objects.TryGetValue(new Vector2(x.Value, y.Value), out var o) && o is Chest c && c.playerChest.Value && !c.giftbox.Value)
                    return c;
                // 说清楚那格其实是什么、这里的箱子都在哪，AI 一步就能改对
                string here = WhatIsAt(tile);
                var chests = Loc.objects.Pairs.Where(p => p.Value is Chest pc && pc.playerChest.Value && !pc.giftbox.Value)
                    .Select(p => $"({(int)p.Key.X},{(int)p.Key.Y})").ToList();
                error = $"({x},{y}) 不是箱子，" + (here != null ? $"那里是{here}" : "那里什么都没有")
                    + (chests.Count > 0 ? $"。{Loc.NameOrUniqueName} 的箱子在：{string.Join("、", chests.Take(8))}（不传坐标就用最近的一个）"
                        : $"。{Loc.NameOrUniqueName} 里没有箱子（箱子的坐标只在放它的那张地图上有效，先 travel_to 过去）");
                return null;
            }
            var me = Player.TilePoint;
            var nearest = Loc.objects.Pairs
                .Where(p => p.Value is Chest c && c.playerChest.Value && !c.giftbox.Value)
                .OrderBy(p => Math.Abs(p.Key.X - me.X) + Math.Abs(p.Key.Y - me.Y))
                .FirstOrDefault();
            if (nearest.Value == null)
            {
                error = "这里没有箱子。先 craft Chest（50 木材），再 place_item 放在农场上（比如出货箱旁边）";
                return null;
            }
            tile = new Point((int)nearest.Key.X, (int)nearest.Key.Y);
            return (Chest)nearest.Value;
        }

        /// <summary>items 为空或 "all" 表示全部；否则用逗号/顿号分隔的名字（包含匹配）。</summary>
        private static Func<Item, bool> ItemFilter(string items)
        {
            if (string.IsNullOrWhiteSpace(items) || items.Trim().Equals("all", StringComparison.OrdinalIgnoreCase) || items.Trim() == "全部")
                return _ => true;
            var names = items.Split(new[] { ',', '，', '、', ';', '；' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(Util.StripQuality).ToArray();
            return i => names.Any(n => i.DisplayName.Contains(n, StringComparison.OrdinalIgnoreCase) || i.Name.Contains(n, StringComparison.OrdinalIgnoreCase));
        }

        private static string ChestSummary(Chest chest)
        {
            var items = chest.GetItemsForPlayer().Where(i => i != null).ToList();
            return items.Count == 0
                ? "箱子是空的"
                : $"箱子里（{items.Count}/{chest.GetActualCapacity()} 格）：{string.Join("、", items.Select(i => $"{i.DisplayName}x{i.Stack}"))}";
        }

        /// <summary>把背包里的东西存进箱子（工具和武器只存点了全名的，比如“训练用鱼竿”）。和箱子界面里点背包物品一样：chest.addItem，全放进去才从背包移除。</summary>
        public IEnumerable<object> StoreItems(string items, int? x, int? y)
        {
            // 没指定箱子：同样的东西存到已经放着它的箱子里，不是一律塞进最近的那个
            if (!x.HasValue || !y.HasValue)
            {
                foreach (var s in StoreItemsSorted(items))
                    yield return s;
                yield break;
            }
            var chest = FindChest(x, y, out var tile, out string error);
            if (chest == null)
            {
                yield return ActionResult.Fail(error);
                yield break;
            }
            var o = new Outcome();
            foreach (var s in GoAdjacent(tile, o))
                yield return s;
            if (!o.Ok)
            {
                yield return ActionResult.Fail(o.Message);
                yield break;
            }
            var filter = ItemFilter(items);
            // 工具和武器只存点了全名的（“剑”这种模糊的名字会把手上最好的武器也存掉）
            var toolNames = string.IsNullOrWhiteSpace(items) ? new HashSet<string>()
                : items.Split(new[] { ',', '，', '、', ';', '；' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToHashSet(StringComparer.OrdinalIgnoreCase);
            bool Wanted(Item i) => i is Tool ? toolNames.Contains(i.DisplayName) || toolNames.Contains(i.Name) : filter(i);
            var stored = new List<string>();
            bool full = false;
            foreach (var item in Player.Items.Where(i => i != null && Wanted(i)).ToList())
            {
                int before = item.Stack;
                string name = item.DisplayName;
                var left = chest.addItem(item);
                if (left == null)
                {
                    Player.removeItemFromInventory(item);
                    stored.Add($"{name}x{before}");
                }
                else
                {
                    full = true;
                    if (left.Stack < before)
                        stored.Add($"{name}x{before - left.Stack}");
                }
            }
            chest.clearNulls();
            if (stored.Count == 0)
            {
                yield return ActionResult.Fail((full ? "箱子满了，" : "背包里没有符合的东西可存（工具要写全名才存），") + ChestSummary(chest));
                yield break;
            }
            yield return ActionResult.Success($"存进 ({tile.X},{tile.Y}) 的箱子：{string.Join("、", stored)}{(full ? "；箱子满了，剩下的还在背包里" : "")}。{ChestSummary(chest)}");
        }

        /// <summary>
        /// 不指定箱子的 store_items：每样东西放进已经有它的箱子（能叠就叠），没有就放进装着同一类东西的箱子，再没有才放最近的有空位的箱子。
        /// </summary>
        private IEnumerable<object> StoreItemsSorted(string items)
        {
            if (!PlayerChests(Loc).Any())
            {
                yield return ActionResult.Fail("这里没有箱子。先 craft Chest（50 木材），再 place_item 放在农场上（比如出货箱旁边）；箱子在别的地方就先 travel_to 过去");
                yield break;
            }
            var filter = ItemFilter(items);
            // 工具和武器只存点了全名的（“剑”这种模糊的名字会把手上最好的武器也存掉）
            var toolNames = string.IsNullOrWhiteSpace(items) ? new HashSet<string>()
                : items.Split(new[] { ',', '，', '、', ';', '；' }, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToHashSet(StringComparer.OrdinalIgnoreCase);
            bool Wanted(Item i) => i is Tool ? toolNames.Contains(i.DisplayName) || toolNames.Contains(i.Name) : filter(i);
            var toStore = Player.Items.Where(i => i != null && Wanted(i)).ToList();
            if (toStore.Count == 0)
            {
                yield return ActionResult.Fail("背包里没有符合的东西可存（工具要写全名才存）");
                yield break;
            }
            var stored = new List<string>();
            foreach (var s in StoreIntoChests(toStore, stored))
                yield return s;
            var left = toStore.Where(i => Player.Items.Contains(i)).Select(i => i.DisplayName).Distinct().ToList();
            string rest = left.Count > 0 ? $"；箱子都满了（或者走不过去），{string.Join("、", left)} 还在背包里：craft Chest（50 木材）再放一个箱子" : "";
            yield return stored.Count > 0
                ? ActionResult.Success($"存进了 {string.Join("；", stored)}{rest}。背包空位 {Player.freeSpotsInInventory()} 个")
                : ActionResult.Fail("一样也没存进去" + rest);
        }

        /// <summary>从箱子取东西回背包。和箱子界面里点箱子物品一样：先确认背包装得下再从箱子移除。</summary>
        public IEnumerable<object> TakeItems(string items, int? x, int? y)
        {
            var chest = FindChest(x, y, out var tile, out string error);
            if (chest == null)
            {
                yield return ActionResult.Fail(error);
                yield break;
            }
            var o = new Outcome();
            foreach (var s in GoAdjacent(tile, o))
                yield return s;
            if (!o.Ok)
            {
                yield return ActionResult.Fail(o.Message);
                yield break;
            }
            var filter = ItemFilter(items);
            var taken = new List<string>();
            bool bagFull = false;
            foreach (var item in chest.GetItemsForPlayer().Where(i => i != null && filter(i)).ToList())
            {
                if (!Player.couldInventoryAcceptThisItem(item))
                {
                    bagFull = true;
                    continue;
                }
                chest.GetItemsForPlayer().Remove(item);
                taken.Add($"{item.DisplayName}x{item.Stack}");
                var left = Player.addItemToInventory(item);
                if (left != null)
                    chest.addItem(left);
            }
            chest.clearNulls();
            if (taken.Count == 0)
            {
                yield return ActionResult.Fail((bagFull ? "背包满了，" : "箱子里没有符合的东西，") + ChestSummary(chest));
                yield break;
            }
            yield return ActionResult.Success($"从箱子取出：{string.Join("、", taken)}{(bagFull ? "；背包满了，还有的没取" : "")}。{ChestSummary(chest)}");
        }
    }
}
