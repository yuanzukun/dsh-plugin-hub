using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using StardewValley;
using StardewValley.Locations;
using StardewValley.Menus;
using SObject = StardewValley.Object;

namespace BlindWhaleFarmer
{
    /// <summary>
    /// 游戏数据里的“知识”：村民送礼喜好、社区中心收集包、博物馆捐赠。
    /// 观察（Observer）和动作（GameActions）共用这里的解析。
    /// </summary>
    internal static class Knowledge
    {
        // ───────────────────────── 节日 ─────────────────────────

        internal sealed class FestivalInfo
        {
            public string Name;
            public string Location;
            public int Start;
            public int End;

            /// <summary>现在走进节日地图会不会直接开始节日（和 Game1.warpFarmer 里的判断一样：开始时间 ≤ 现在 ≤ 结束时间）。</summary>
            public bool EnteringStartsFestival => Game1.timeOfDay >= Start && Game1.timeOfDay <= End;

            public override string ToString() => $"{Name}（{Location}，{Util.TimeString(Start)}-{Util.TimeString(End)}）";
        }

        /// <summary>今天的节日。和 Game1 一样读 Data\Festivals\&lt;季节&gt;&lt;日&gt; 的 conditions，例如 "Town/900 1400"。</summary>
        public static FestivalInfo TodaysFestival()
        {
            if (!Utility.isFestivalDay())
                return null;
            try
            {
                var data = Game1.temporaryContent.Load<Dictionary<string, string>>($"Data\\Festivals\\{Game1.currentSeason}{Game1.dayOfMonth}");
                string[] cond = data["conditions"].Split('/');
                string[] hours = ArgUtility.SplitBySpace(cond[1]);
                return new FestivalInfo
                {
                    Name = data.TryGetValue("name", out var n) ? n : "节日",
                    Location = cond[0],
                    Start = Convert.ToInt32(hours[0]),
                    End = Convert.ToInt32(hours[1])
                };
            }
            catch
            {
                return null;
            }
        }

        // ───────────────────────── 送礼 ─────────────────────────

        public static string TasteName(int taste) => taste switch
        {
            NPC.gift_taste_love or NPC.gift_taste_stardroptea => "最爱",
            NPC.gift_taste_like => "喜欢",
            NPC.gift_taste_dislike => "不喜欢",
            NPC.gift_taste_hate => "讨厌",
            _ => "一般"
        };

        public static bool IsGiftable(Item item) => item is SObject && item.canBeGivenAsGift();

        /// <summary>背包里每件可送的物品对这个村民来说是什么喜好（同一物品只列一次）。</summary>
        public static Dictionary<int, List<string>> InventoryTastes(NPC npc)
        {
            var result = new Dictionary<int, List<string>>();
            var seen = new HashSet<string>();
            foreach (var item in Game1.player.Items)
            {
                if (!IsGiftable(item) || !seen.Add(item.QualifiedItemId + "@" + item.Quality))
                    continue;
                int taste = npc.getGiftTasteForThisItem(item);
                if (taste == NPC.gift_taste_stardroptea)
                    taste = NPC.gift_taste_love;
                if (!result.TryGetValue(taste, out var list))
                    result[taste] = list = new List<string>();
                list.Add(item.DisplayName);
            }
            return result;
        }

        /// <summary>从 Data/NPCGiftTastes 读这个村民的最爱/喜欢/讨厌清单（不含全体通用喜好）。</summary>
        public static (List<string> love, List<string> like, List<string> hate) GiftTasteLists(string npcName)
        {
            var love = new List<string>();
            var like = new List<string>();
            var hate = new List<string>();
            if (Game1.NPCGiftTastes != null && Game1.NPCGiftTastes.TryGetValue(npcName, out string raw))
            {
                // 格式：最爱台词/最爱ID/喜欢台词/喜欢ID/不喜欢台词/ID/讨厌台词/ID/一般台词/ID
                var parts = raw.Split('/');
                love = ResolveIds(parts.ElementAtOrDefault(1));
                like = ResolveIds(parts.ElementAtOrDefault(3));
                hate = ResolveIds(parts.ElementAtOrDefault(7));
            }
            return (love, like, hate);
        }

        private static List<string> ResolveIds(string ids)
        {
            var list = new List<string>();
            if (string.IsNullOrWhiteSpace(ids))
                return list;
            foreach (string id in ids.Split(' ', StringSplitOptions.RemoveEmptyEntries))
            {
                try
                {
                    if (int.TryParse(id, out int n) && n < 0)
                        list.Add("[类别]" + SObject.GetCategoryDisplayName(n));
                    else
                    {
                        var data = ItemRegistry.GetData(id.StartsWith("(") ? id : "(O)" + id);
                        if (data != null)
                            list.Add(data.DisplayName);
                    }
                }
                catch
                {
                    // 个别 ID 可能是上下文标签，跳过
                }
            }
            return list;
        }

        // ───────────────────────── 社区中心收集包 ─────────────────────────

        internal sealed class BundleInfo
        {
            public string Key;          // 例如 Pantry/0
            public string AreaName;     // 英文区域名
            public int Area;
            public int Index;
            public string DisplayName;
            public string Reward;
            public int SlotsNeeded;
            public int SlotsDone;
            public List<BundleIngredientDescription> Ingredients = new();
            public bool Complete => SlotsDone >= SlotsNeeded;
        }

        public static string AreaDisplayName(int area) => area switch
        {
            0 => "茶水间(Pantry)",
            1 => "工艺室(Crafts Room)",
            2 => "鱼缸(Fish Tank)",
            3 => "锅炉房(Boiler Room)",
            4 => "金库(Vault)",
            5 => "公告栏(Bulletin Board)",
            6 => "废弃的 Joja 超市",
            _ => "区域" + area
        };

        internal const string FarmhandCommunityCenterNote =
            "社区中心还没开放：开门的剧情只有主机能触发（第 5 天起的晴天 8:00-13:00，主机从巴士站走进小镇）。你怎么走都触发不了，门也打不开，别在这上面花时间：用 say 跟主机说一声，然后接着干别的";

        /// <summary>社区中心当前状态：不可用时返回原因，否则返回 null。</summary>
        public static string CommunityCenterUnavailable()
        {
            // 开门和路线都记在主机身上（游戏 WarpCommunityCenter 看的也是 MasterPlayer），联机时农场工人自己的记录里没有
            var master = Game1.MasterPlayer;
            if (master.mailReceived.Contains("JojaMember"))
                return "已经选了 Joja 路线，社区中心收集包不再可用";
            if (!master.mailReceived.Contains("ccDoorUnlock") && !Game1.IsMasterGame)
                return FarmhandCommunityCenterNote;
            if (!master.mailReceived.Contains("ccDoorUnlock"))
                // 事件 611439 的条件：j 4（玩满 4 天，即第 5 天起）/ t 800 1300 / w sunny / a 0 54（从巴士站那边进镇的落脚点）/ H（只有主机）
                return "社区中心还没开放：第 5 天起的晴天 8:00-13:00，从巴士站（BusStop）走进小镇（Town）就会触发镇长带你去社区中心的剧情"
                    + "（从农场 travel_to Town 正好经过巴士站；从海滩、森林等其他方向进镇不会触发）";
            if (master.hasCompletedCommunityCenter())
                return "社区中心已经全部修复完成";
            return null;
        }

        public static List<BundleInfo> Bundles()
        {
            var list = new List<BundleInfo>();
            var cc = Game1.getLocationFromName("CommunityCenter") as CommunityCenter;
            if (cc == null)
                return list;
            foreach (var pair in Game1.netWorldState.Value.BundleData)
            {
                var keyParts = pair.Key.Split('/');
                if (keyParts.Length < 2 || !int.TryParse(keyParts[1], out int index))
                    continue;
                var f = pair.Value.Split('/');
                if (f.Length < 3)
                    continue;
                var info = new BundleInfo
                {
                    Key = pair.Key,
                    AreaName = keyParts[0],
                    Area = CommunityCenter.getAreaNumberFromName(keyParts[0]),
                    Index = index,
                    DisplayName = f.Length > 6 && !string.IsNullOrWhiteSpace(f[6]) ? f[6] : f[0],
                    Reward = f[1]
                };
                cc.bundles.TryGetValue(index, out bool[] done);
                var raw = f[2].Split(' ', StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i + 2 < raw.Length; i += 3)
                {
                    bool completed = done != null && i / 3 < done.Length && done[i / 3];
                    info.Ingredients.Add(new BundleIngredientDescription(raw[i], int.Parse(raw[i + 1]), int.Parse(raw[i + 2]), completed));
                    if (completed)
                        info.SlotsDone++;
                }
                info.SlotsNeeded = f.Length > 4 && int.TryParse(f[4], out int n) ? n : info.Ingredients.Count;
                list.Add(info);
            }
            return list.OrderBy(b => b.Area).ThenBy(b => b.Index).ToList();
        }

        /// <summary>收集包当前能不能看到/提交（对应区域的祝尼魔便条已经出现，且区域没完成）。</summary>
        public static bool IsBundleAvailable(BundleInfo b)
        {
            var cc = Game1.getLocationFromName("CommunityCenter") as CommunityCenter;
            if (cc == null || b.Area < 0 || b.Area > 5)
                return false;
            return !cc.areasComplete[b.Area] && cc.shouldNoteAppearInArea(b.Area);
        }

        /// <summary>金库（Vault）交钱收集包的金额；不是交钱收集包返回 0。</summary>
        public static int VaultCost(int area, IReadOnlyList<BundleIngredientDescription> ingredients)
        {
            if (area != CommunityCenter.AREA_Vault || ingredients == null || ingredients.Count == 0)
                return 0;
            var last = ingredients[^1];
            return last.category == -1 && last.stack > 0 ? last.stack : 0;
        }

        public static int VaultCost(BundleInfo b) => b == null ? 0 : VaultCost(b.Area, b.Ingredients);

        public static string IngredientName(BundleIngredientDescription ing)
        {
            if (ing.category == -1)
                return $"{ing.stack}g";
            string name;
            if (ing.category.HasValue)
                name = "任意" + SObject.GetCategoryDisplayName(ing.category.Value);
            else
                name = ItemRegistry.GetDataOrErrorItem(ing.id.StartsWith("(") ? ing.id : "(O)" + ing.id).DisplayName;
            if (ing.preservesId != null)
                name += "(" + Util.ObjectName(ing.preservesId) + ")";
            string quality = ing.quality switch { 1 => " 银星+", 2 => " 金星+", 4 => " 铱星", _ => "" };
            return $"{name} x{ing.stack}{quality}";
        }

        /// <summary>
        /// 鱼在哪、什么时候能钓（读 Data/Fish 的季节、天气、时间，和 Data/Locations 里哪些地图放了这种鱼）。
        /// 不是鱼返回 null。条件很复杂的（比如只在某片水域、要特定条件）以游戏为准，这里只给个大概。
        /// </summary>
        public static string FishWhereWhen(string qualifiedId)
        {
            if (qualifiedId == null || !qualifiedId.StartsWith("(O)"))
                return null;
            string id = qualifiedId.Substring(3);
            Dictionary<string, string> fish;
            try { fish = DataLoader.Fish(Game1.content); } catch { return null; }
            if (!fish.TryGetValue(id, out string raw))
                return null;
            string[] f = raw.Split("/");
            if (f.Length > 1 && f[1] == "trap")
                return "蟹笼：" + (f.Length > 4 && f[4] == "ocean" ? "放海里" : "放淡水（河、湖）里");
            var parts = new List<string>();
            if (f.Length > 6)
            {
                var seasons = ArgUtility.SplitBySpace(f[6]);
                parts.Add(seasons.Length >= 4 ? "四季" : string.Join("", seasons.Select(s => s switch
                    { "spring" => "春", "summer" => "夏", "fall" => "秋", "winter" => "冬", _ => s })) + "季");
            }
            if (f.Length > 7 && f[7] != "both")
                parts.Add(f[7] == "rainy" ? "雨天" : "晴天");
            if (f.Length > 5)
            {
                var hours = ArgUtility.SplitBySpace(f[5]);
                var spans = new List<string>();
                for (int i = 0; i + 1 < hours.Length; i += 2)
                    if (int.TryParse(hours[i], out int a) && int.TryParse(hours[i + 1], out int b) && !(a <= 600 && b >= 2600))
                        spans.Add($"{Util.TimeString(a)}-{Util.TimeString(Math.Min(b, 2600))}");
                parts.Add(spans.Count > 0 ? string.Join("、", spans) : "全天");
            }
            var where = new List<string>();
            foreach (var (name, data) in Game1.locationData)
            {
                // Temp、fishingGame 是节日小游戏用的临时地图
                if (name is "Default" or "Temp" or "fishingGame" || data?.Fish == null)
                    continue;
                if (data.Fish.Any(s => s.ItemId == qualifiedId || s.ItemId == id))
                {
                    string label = name switch
                    {
                        "UndergroundMine" => "矿洞20/60/100层",
                        "Submarine" => "夜市潜水艇",
                        "Caldera" => "火山口",
                        _ when name.StartsWith("Island") => "姜岛",
                        _ => Game1.getLocationFromName(name)?.DisplayName,
                    };
                    label = label != null && label != name ? $"{label}({name})" : name;
                    if (name.StartsWith("Island") && where.Any(w => w.StartsWith("姜岛")))
                        continue;
                    where.Add(name.StartsWith("Island") ? "姜岛" : label);
                }
            }
            if (where.Count > 0)
                parts.Add("在 " + string.Join("/", where.Take(5)) + (where.Count > 5 ? " 等" : ""));
            return string.Join("，", parts);
        }

        /// <summary>和 Bundle.IsValidItemForThisIngredientDescription 相同的判断（不含腌制品的风味细节，提交时以游戏判断为准）。</summary>
        public static bool Matches(Item item, BundleIngredientDescription ing, bool ignoreStack = false)
        {
            if (item == null || ing.completed || ing.quality > item.Quality || (!ignoreStack && item.Stack < ing.stack))
                return false;
            if (ing.preservesId != null)
                return item is SObject o && o.preservedParentSheetIndex.Value == ing.preservesId;
            if (ing.category.HasValue)
                return (item.QualifiedItemId == "(O)107" && ing.category == -5) || item.Category == ing.category;
            return ItemRegistry.HasItemId(item, ing.id);
        }

        /// <summary>背包里能交给这个收集包的物品（每种材料只算一次）。</summary>
        public static List<string> InventoryMatches(BundleInfo b)
        {
            var result = new List<string>();
            if (b.Complete)
                return result;
            foreach (var ing in b.Ingredients.Where(i => !i.completed))
            {
                var item = Game1.player.Items.FirstOrDefault(it => Matches(it, ing));
                if (item != null)
                    result.Add(item.DisplayName);
            }
            return result;
        }

        // ───────────────────────── 博物馆 ─────────────────────────

        public static LibraryMuseum Museum => Game1.getLocationFromName("ArchaeologyHouse") as LibraryMuseum;

        /// <summary>背包里还没捐过、可以捐给博物馆的物品（同一种只算一个）。</summary>
        public static List<Item> MuseumDonatable()
        {
            var museum = Museum;
            var list = new List<Item>();
            if (museum == null)
                return list;
            var seen = new HashSet<string>();
            foreach (var item in Game1.player.Items)
            {
                if (item != null && museum.isItemSuitableForDonation(item) && seen.Add(item.QualifiedItemId))
                    list.Add(item);
            }
            return list;
        }

        internal sealed record MuseumPiece(string Name, bool Mineral, bool Donated);

        /// <summary>按游戏的捐赠规则取完整清单，用展台上的物品 ID 标记已捐。</summary>
        public static List<MuseumPiece> MuseumCollection()
        {
            if (Museum is not { } museum)
                return null;

            var donated = museum.museumPieces.Values
                .Select(id => ItemRegistry.ManuallyQualifyItemId(id, "(O)"))
                .ToHashSet(StringComparer.Ordinal);
            var pieces = new List<MuseumPiece>();
            foreach (string id in ItemRegistry.RequireTypeDefinition("(O)").GetAllIds())
            {
                string qualifiedId = "(O)" + id;
                if (!LibraryMuseum.IsItemSuitableForDonation(qualifiedId, checkDonatedItems: false))
                    continue;
                var data = ItemRegistry.GetDataOrErrorItem(qualifiedId);
                bool mineral = data.ObjectType == "Minerals" || data.Category is SObject.GemCategory or SObject.mineralsCategory;
                string name = data.DisplayName;
                pieces.Add(new MuseumPiece(name, mineral, donated.Contains(qualifiedId)));
            }
            return pieces;
        }

        public static IEnumerable<object> MuseumInfo(string section, string kind)
        {
            section = section?.Trim().ToLowerInvariant() ?? "missing";
            kind = kind?.Trim().ToLowerInvariant();
            if (section is not ("missing" or "donated" or "all"))
                yield return ActionResult.Fail("section 要传 missing（还缺）、donated（已捐）或 all（全部）");
            else if (kind is not (null or "minerals" or "artifacts"))
                yield return ActionResult.Fail("kind 要传 minerals（矿物）或 artifacts（文物），也可以省略");
            else if (MuseumCollection() is not { } pieces)
                yield return ActionResult.Fail("找不到博物馆");
            else
                yield return ActionResult.Success(MuseumCollectionText(pieces, section, kind));
        }

        internal static string MuseumCollectionText(List<MuseumPiece> pieces, string section, string kind)
        {
            var sb = new StringBuilder($"博物馆已捐 {pieces.Count(p => p.Donated)}/{pieces.Count} 件");
            if (kind != "artifacts")
                AppendKind("矿物", mineral: true);
            if (kind != "minerals")
                AppendKind("文物", mineral: false);
            return sb.ToString();

            void AppendKind(string label, bool mineral)
            {
                var items = pieces.Where(p => p.Mineral == mineral).ToList();
                int donated = items.Count(p => p.Donated);
                sb.Append($"\n{label}：已捐 {donated} 件，还缺 {items.Count - donated} 件");
                if (section is "missing" or "all")
                {
                    AppendNames("还缺", donated: false);
                    if (donated < items.Count)
                        sb.Append(mineral ? "\n  部分矿物可以用 crack_geodes 开晶球获得。" : "\n  部分文物可以用锄头挖远古斑点获得。");
                }
                if (section is "donated" or "all")
                    AppendNames("已捐", donated: true);

                void AppendNames(string status, bool donated)
                {
                    var names = items.Where(p => p.Donated == donated).Select(p => p.Name)
                        .OrderBy(name => name, StringComparer.Ordinal).ToArray();
                    if (names.Length == 0)
                        sb.Append($"\n  {status}：无");
                    foreach (var line in names.Chunk(12))
                        sb.Append($"\n  {status}：{string.Join("、", line)}");
                }
            }
        }
    }
}
