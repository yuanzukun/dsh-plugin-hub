using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewValley;
using StardewValley.Buildings;
using StardewValley.GameData.Buildings;
using StardewValley.Objects;
using StardewValley.Quests;
using StardewValley.SpecialOrders.Objectives;
using StardewValley.TerrainFeatures;
using StardewValley.Tools;
using SObject = StardewValley.Object;

namespace BlindWhaleFarmer
{
    internal sealed partial class GameActions
    {
        // ───────────────────────── 任务 / 收集包要交的东西 ─────────────────────────

        /// <summary>
        /// 返回一个判断函数：这件东西是不是任务、特别订单、社区中心收集包要交的（返回原因，不是返回 null）。
        /// 数量比要交的多时不算（多出来的可以吃、可以卖）。先把任务和收集包算好，背包几十格挨个查也不慢。
        /// </summary>
        /// <summary>设置里的 ReservedItems：玩家要留着的东西，逗号分隔。</summary>
        public static string ReservedItems = "";
        /// <summary>reserve_items 记下的一样东西：名字、留到哪天（游戏总天数，0 = 一直留着）、玩家当时说要拿来干什么。</summary>
        public sealed class SavedReserve
        {
            public string Name { get; set; } = "";
            public int UntilDay { get; set; }
            public string Purpose { get; set; } = "";
        }

        /// <summary>
        /// 玩家在游戏里/对话里让 AI 记下要留的东西（reserve_items 写的），按存档保存在模组 data 文件夹，
        /// 和设置里的分开存，免得插件推设置时被覆盖。改它要拿 SaveReservedLock。
        /// </summary>
        public static List<SavedReserve> SaveReserved = new();
        internal static readonly object SaveReservedLock = new();
        /// <summary>SaveReserved 改了以后写盘（ModEntry 填）。</summary>
        internal static Action PersistSaveReserved;
        /// <summary>到期自动放开的东西，下次 get_state / 内置 AI 读状态时提醒一次。</summary>
        private static readonly List<string> expiredReserveNotes = new();
        internal const string PlayerReserved = "玩家要求保留";

        private static readonly char[] NameSeparators = { ',', '，', '、', ';', '；' };

        internal static List<string> SplitReservedNames(string text) =>
            (text ?? "").Split(NameSeparators, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(Util.StripQuality).Where(n => n.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase).ToList();

        internal static string DayText(int totalDays)
        {
            var d = WorldDate.ForDaysPlayed(totalDays);
            return $"第{d.Year}年{Util.SeasonName(d.SeasonKey)}季{d.DayOfMonth}日";
        }

        /// <summary>
        /// 把“第2年春季”“明年春天”“夏季15日”“秋”“10天后”这类说法换成游戏总天数（WorldDate.TotalDays）。
        /// 没写年份就取今天之后最近的那一天；只写季节就是那个季节第 1 天。认不出返回 null 和原因。
        /// </summary>
        internal static (int? day, string error) ParseUntil(string text)
        {
            text = (text ?? "").Trim();
            if (text.Length == 0)
                return (null, null);
            var today = Game1.Date;
            int todayTotal = today.TotalDays;
            var m = System.Text.RegularExpressions.Regex.Match(text, @"(\d+)\s*天后");
            if (m.Success)
                return (todayTotal + Math.Max(1, int.Parse(m.Groups[1].Value)), null);
            string lower = text.ToLowerInvariant();
            Season? season = null;
            foreach (var (key, s) in new[] { ("春", Season.Spring), ("spring", Season.Spring), ("夏", Season.Summer), ("summer", Season.Summer),
                         ("秋", Season.Fall), ("fall", Season.Fall), ("autumn", Season.Fall), ("冬", Season.Winter), ("winter", Season.Winter) })
            {
                if (lower.Contains(key))
                {
                    season = s;
                    break;
                }
            }
            if (season == null)
                return (null, $"认不出“{text}”是哪天，写成“第2年春季”“夏季15日”“明年春天”或“10天后”");
            int day = 1;
            m = System.Text.RegularExpressions.Regex.Match(text, @"(\d+)\s*[日号]");
            if (m.Success)
                day = Math.Clamp(int.Parse(m.Groups[1].Value), 1, 28);
            int? year = null;
            m = System.Text.RegularExpressions.Regex.Match(text, @"(\d+)\s*年");
            if (m.Success)
                year = int.Parse(m.Groups[1].Value);
            else if (text.Contains("后年"))
                year = today.Year + 2;
            else if (text.Contains("明年") || lower.Contains("next year"))
                year = today.Year + 1;
            if (year == null)
            {
                year = today.Year;
                if (new WorldDate(today.Year, season.Value, day).TotalDays <= todayTotal)
                    year++;
            }
            int total = new WorldDate(Math.Max(1, year.Value), season.Value, day).TotalDays;
            if (total <= todayTotal)
                return (null, $"{DayText(total)} 已经过了（今天是 {DayText(todayTotal)}）");
            return (total, null);
        }

        /// <summary>到日子的放开，记下提醒。调用方不用拿锁。</summary>
        internal static void ExpireSaveReserved()
        {
            if (!Context.IsWorldReady)
                return;
            int today = Game1.Date.TotalDays;
            bool changed = false;
            lock (SaveReservedLock)
            {
                foreach (var r in SaveReserved.Where(r => r.UntilDay > 0 && r.UntilDay <= today).ToList())
                {
                    SaveReserved.Remove(r);
                    expiredReserveNotes.Add($"{r.Name}（玩家让你留到 {DayText(r.UntilDay)}{(string.IsNullOrWhiteSpace(r.Purpose) ? "" : "，说要" + r.Purpose.Trim())}）");
                    changed = true;
                }
            }
            if (changed)
                PersistSaveReserved?.Invoke();
        }

        /// <summary>到期放开的提醒，只给一次。没有返回 null。</summary>
        internal static string TakeExpiredReserveNote()
        {
            ExpireSaveReserved();
            lock (SaveReservedLock)
            {
                if (expiredReserveNotes.Count == 0)
                    return null;
                string note = string.Join("；", expiredReserveNotes) + "。到日子了，已经从保留清单里去掉，现在可以用了，按玩家当时说的去做";
                expiredReserveNotes.Clear();
                return note;
            }
        }

        /// <summary>读档时调用：换存档后上一个存档的到期提醒不要带过来。</summary>
        internal static void LoadSaveReserved(List<SavedReserve> list)
        {
            lock (SaveReservedLock)
            {
                SaveReserved = (list ?? new()).Where(r => !string.IsNullOrWhiteSpace(r?.Name)).ToList();
                expiredReserveNotes.Clear();
            }
        }

        /// <summary>写盘用：拿一份快照。</summary>
        internal static List<SavedReserve> SaveReservedSnapshot()
        {
            lock (SaveReservedLock)
                return SaveReserved.Select(r => new SavedReserve { Name = r.Name, UntilDay = r.UntilDay, Purpose = r.Purpose }).ToList();
        }

        private static List<string> SaveReservedNames()
        {
            ExpireSaveReserved();
            lock (SaveReservedLock)
                return SaveReserved.Select(r => r.Name).ToList();
        }

        /// <summary>给 AI 看的保留清单（设置里的 + 这个存档里记下的），都没有就返回 null。</summary>
        internal static string ReservedSummary()
        {
            ExpireSaveReserved();
            var fromSettings = SplitReservedNames(ReservedItems);
            List<string> fromSave;
            lock (SaveReservedLock)
            {
                fromSave = SaveReserved.Where(r => !fromSettings.Contains(r.Name, StringComparer.OrdinalIgnoreCase))
                    .Select(r =>
                    {
                        var extra = new List<string>();
                        if (r.UntilDay > 0)
                            extra.Add("留到" + DayText(r.UntilDay));
                        if (!string.IsNullOrWhiteSpace(r.Purpose))
                            extra.Add("要" + r.Purpose.Trim());
                        return r.Name + (extra.Count > 0 ? "（" + string.Join("，", extra) + "）" : "");
                    })
                    .ToList();
            }
            if (fromSettings.Count == 0 && fromSave.Count == 0)
                return null;
            var parts = new List<string>();
            if (fromSettings.Count > 0)
                parts.Add("设置里的：" + string.Join("、", fromSettings));
            if (fromSave.Count > 0)
                parts.Add("这个存档里记下的：" + string.Join("、", fromSave));
            return string.Join("；", parts) + "。不卖、不出货、不吃、不扔、不种、不送（交任务可以）；写了“留到”的到那天会自动放开并提醒你。玩家说要留别的东西或说不用留了，用 reserve_items 改";
        }

        /// <summary>
        /// reserve_items：玩家说“这个留着”“草莓种子留着明年春天种”时记下来（可带到期日和用途）；说“可以用了”就去掉。
        /// 设置里的那份只能玩家在 DSH 配置页 / config.json 改。
        /// </summary>
        public IEnumerable<object> ReserveItems(string add, string remove, string until, string purpose)
        {
            var addNames = SplitReservedNames(add);
            var removeNames = SplitReservedNames(remove);
            if (addNames.Count == 0 && removeNames.Count == 0)
            {
                yield return ActionResult.Success((ReservedSummary() is string s ? "现在要留着的：" + s : "现在没有要留着的东西") + $"（今天是 {DayText(Game1.Date.TotalDays)}）");
                yield break;
            }
            var (untilDay, untilError) = ParseUntil(until);
            if (untilError != null)
            {
                yield return ActionResult.Fail(untilError + "。清单没改");
                yield break;
            }
            var fromSettings = SplitReservedNames(ReservedItems);
            var notes = new List<string>();
            lock (SaveReservedLock)
            {
                foreach (var n in addNames)
                {
                    var existing = SaveReserved.FirstOrDefault(r => r.Name.Equals(n, StringComparison.OrdinalIgnoreCase));
                    if (fromSettings.Contains(n, StringComparer.OrdinalIgnoreCase))
                        notes.Add($"{n} 是玩家在设置里写的，一直留着，不用再记");
                    else if (existing != null)
                    {
                        // 已经有了就按这次说的更新日子和用途
                        existing.UntilDay = untilDay ?? 0;
                        if (!string.IsNullOrWhiteSpace(purpose))
                            existing.Purpose = purpose.Trim();
                    }
                    else
                        SaveReserved.Add(new SavedReserve { Name = n, UntilDay = untilDay ?? 0, Purpose = (purpose ?? "").Trim() });
                }
                foreach (var n in removeNames)
                {
                    if (SaveReserved.RemoveAll(x => x.Name.Equals(n, StringComparison.OrdinalIgnoreCase)) > 0)
                        continue;
                    notes.Add(fromSettings.Contains(n, StringComparer.OrdinalIgnoreCase)
                        ? $"{n} 是玩家在设置里写的，你去不掉，请玩家在 DSH 配置页的“保留物品”（或 config.json 的 ReservedItems）里删"
                        : $"{n} 本来就不在清单里");
                }
            }
            PersistSaveReserved?.Invoke();
            string now = ReservedSummary() is string summary ? "现在要留着的：" + summary : "现在没有要留着的东西";
            yield return ActionResult.Success((notes.Count > 0 ? string.Join("；", notes) + "。" : "已更新。") + now + $"（今天是 {DayText(Game1.Date.TotalDays)}）");
        }

        internal static Func<Item, string> ReservedChecker()
        {
            var needs = QuestNeeds();
            if (Knowledge.CommunityCenterUnavailable() == null)
            {
                foreach (var b in Knowledge.Bundles().Where(b => !b.Complete))
                {
                    foreach (var ing in b.Ingredients.Where(i => !i.completed))
                    {
                        var ingredient = ing;
                        // 任意一类（比如“任意鸡蛋”）的不算：同类东西太多，留不过来
                        if (ingredient.category.HasValue)
                            continue;
                        needs.Add((i => Knowledge.Matches(i, ingredient, ignoreStack: true), ingredient.stack, $"社区中心“{b.DisplayName}”要交"));
                    }
                }
            }
            var keepNames = SplitReservedNames(ReservedItems).Concat(SaveReservedNames()).ToArray();
            return item =>
            {
                if (item == null)
                    return null;
                if (item is SObject o && o.questItem.Value)
                    return "任务物品";
                // 玩家在设置里点名要留的（名字完全一样才算，免得“草莓”把草莓种子也算进去）
                if (keepNames.Any(n => item.DisplayName.Equals(n, StringComparison.OrdinalIgnoreCase) || item.Name.Equals(n, StringComparison.OrdinalIgnoreCase)))
                    return PlayerReserved;
                foreach (var (match, count, why) in needs)
                {
                    try
                    {
                        if (match(item) && item.Stack <= count)
                            return why;
                    }
                    catch
                    {
                        // 个别物品取不到标签，跳过
                    }
                }
                return null;
            };
        }

        /// <summary>
        /// 任务和特别订单要留几个这件东西（不算收集包；任务专用物品算无穷多）。交收集包时用：任务要的那份留着，只交多出来的。
        /// </summary>
        internal static Func<Item, (int count, string why)> QuestReserve()
        {
            var needs = QuestNeeds();
            return item =>
            {
                if (item is SObject o && o.questItem.Value)
                    return (int.MaxValue, "任务物品");
                (int count, string why) best = (0, null);
                foreach (var (match, count, why) in needs)
                {
                    try
                    {
                        if (match(item) && count > best.count)
                            best = (count, why);
                    }
                    catch
                    {
                        // 个别物品取不到标签，跳过
                    }
                }
                return best;
            };
        }

        /// <summary>任务、特别订单要交的东西：怎么认、要几个、为什么。</summary>
        private static List<(Func<Item, bool> match, int count, string why)> QuestNeeds()
        {
            var needs = new List<(Func<Item, bool> match, int count, string why)>();
            foreach (var q in Game1.player.questLog)
            {
                if (q.completed.Value)
                    continue;
                string name = SafeQuestName(q);
                switch (q)
                {
                    case ItemDeliveryQuest d when d.ItemId.Value != null:
                        string id = ItemRegistry.QualifyItemId(d.ItemId.Value) ?? d.ItemId.Value;
                        needs.Add((i => i.QualifiedItemId == id, Math.Max(1, d.number.Value), $"任务“{name}”要交"));
                        break;
                    case LostItemQuest l when l.ItemId.Value != null:
                        needs.Add((i => i.QualifiedItemId == l.ItemId.Value, 1, $"任务“{name}”要交"));
                        break;
                }
            }
            foreach (var order in Game1.player.team.specialOrders)
            {
                foreach (var obj in order.objectives)
                {
                    if (obj.IsComplete())
                        continue;
                    var tagSets = obj switch
                    {
                        DeliverObjective d => d.acceptableContextTagSets,
                        DonateObjective d => d.acceptableContextTagSets,
                        _ => null
                    };
                    if (tagSets == null || tagSets.Count == 0)
                        continue;
                    var sets = tagSets.ToList();
                    string why = $"特别订单“{SafeOrderName(order)}”要交";
                    needs.Add((i => sets.Any(set => set.Split(',').All(tag => ItemContextTagManager.DoAnyTagsMatch(tag.Trim().Split('/'), i.GetContextTags()))),
                        Math.Max(1, obj.GetMaxCount() - obj.GetCount()), why));
                }
            }
            return needs;
        }

        private static string SafeQuestName(Quest q)
        {
            try
            {
                return q.GetName();
            }
            catch
            {
                return q.id.Value;
            }
        }

        private static string SafeOrderName(StardewValley.SpecialOrders.SpecialOrder order)
        {
            try
            {
                return order.GetName();
            }
            catch
            {
                return order.questKey.Value;
            }
        }

        private const string ForceHint = "真要这么做就再调用一次并传 force=true";

        // ───────────────────────── 出门带什么 ─────────────────────────

        /// <summary>tidy_backpack 的 purpose：出门干什么。不同目的留在身上的东西不一样。</summary>
        private static string NormalizePurpose(string purpose)
        {
            if (string.IsNullOrWhiteSpace(purpose))
                return null;
            string p = purpose.Trim().ToLowerInvariant();
            if (p.Contains("mine") || p.Contains("矿") || p.Contains("skull") || p.Contains("战斗"))
                return "mine";
            if (p.Contains("fish") || p.Contains("钓"))
                return "fish";
            if (p.Contains("farm") || p.Contains("农") || p.Contains("种"))
                return "farm";
            if (p.Contains("town") || p.Contains("镇") || p.Contains("social") || p.Contains("送礼") || p.Contains("社交"))
                return "town";
            return null;
        }

        /// <summary>把今天要做的事逐段识别；有一段不认识就整次报错。</summary>
        private static bool TryParsePurposes(string purposeSpec, out List<string> purposes, out string error)
        {
            purposes = new List<string>();
            error = null;
            if (string.IsNullOrWhiteSpace(purposeSpec))
                return true;

            foreach (string part in Regex.Split(purposeSpec, @"[,，、\s和]+").Where(p => p.Length > 0))
            {
                string purpose = NormalizePurpose(part);
                if (purpose == null)
                {
                    error = UnknownPurpose(part);
                    return false;
                }
                if (!purposes.Contains(purpose))
                    purposes.Add(purpose);
            }

            if (purposes.Count > 0)
                return true;
            error = UnknownPurpose(purposeSpec);
            return false;

            static string UnknownPurpose(string part) =>
                $"不认识出门目的“{part}”，可以用 mine（下矿）、fish（钓鱼）、farm（种地）、town（去镇上送礼办事），多个用逗号分隔，不传就按通用规则整理";
        }

        private static readonly Dictionary<string, string> PurposeName = new()
        {
            ["mine"] = "下矿", ["fish"] = "钓鱼", ["farm"] = "种地", ["town"] = "去镇上"
        };

        /// <summary>回家用的：传送图腾（农场 688、山 689、海滩 690、姜岛 886）、回城权杖。</summary>
        internal static bool IsEscapeItem(Item i) =>
            i is StardewValley.Tools.Wand || i is SObject o && o.QualifiedItemId is "(O)688" or "(O)689" or "(O)690" or "(O)886";

        private static string TripPurposeName(IEnumerable<string> purposes) =>
            string.Join("+", purposes.Select(p => PurposeName[p]));

        /// <summary>某个出门目的用得上的东西。整理背包时可先跳过普通回血食物，稍后按数量补上。</summary>
        private static bool UsefulFor(string purpose, Item i, bool includeHealingFood = true)
        {
            // 戒指、鞋子到哪都带；武器除了去镇上都带（农场晚上、钓鱼的地方也会有怪）
            if (i is Ring or Boots || purpose != "town" && i is MeleeWeapon { } mw && !mw.isScythe())
                return true;
            switch (purpose)
            {
                case "mine":
                    return i is Pickaxe || IsEscapeItem(i) || (i is MeleeWeapon w && !w.isScythe()) || i is Slingshot
                        || i is SObject o && (o.Name.Contains("Bomb") || o.QualifiedItemId is "(O)71" || includeHealingFood && o.Edibility > 0 && o.healthRecoveredOnConsumption() > 0
                                              || o.Category == SObject.CookingCategory)
                        || i is Ring or Boots;
                case "fish":
                    return i is FishingRod || i is SObject f && (f.Category is SObject.baitCategory or SObject.tackleCategory
                        || f.Category == SObject.CookingCategory || f.QualifiedItemId == "(O)710"); // 蟹笼
                case "farm":
                    return i is Hoe or WateringCan or Axe or Pickaxe || (i is MeleeWeapon s && s.isScythe())
                        || i is SObject g && (g.Category is SObject.SeedsCategory or SObject.fertilizerCategory || g.IsSprinkler()
                                              || g.bigCraftable.Value || g.Category == SObject.CookingCategory);
                case "town":
                    return i is SObject t && (t.Category == SObject.CookingCategory || t.QualifiedItemId is "(O)458" or "(O)460");
                default:
                    return true;
            }
        }

        private static IEnumerable<(string name, Func<Item, bool> match)> TripNeeds(string purpose)
        {
            switch (purpose)
            {
                case "mine":
                    yield return ("武器", i => i is MeleeWeapon w && !w.isScythe());
                    yield return ("镐子", i => i is Pickaxe);
                    yield return ("回血的食物", i => i is SObject o && o.Edibility > 0 && o.healthRecoveredOnConsumption() > 0);
                    break;
                case "fish":
                    yield return ("鱼竿", i => i is FishingRod);
                    yield return ("鱼饵", i => i is SObject o && o.Category == SObject.baitCategory);
                    break;
                case "farm":
                    yield return ("锄头", i => i is Hoe);
                    yield return ("水壶", i => i is WateringCan);
                    break;
            }
        }

        private static string MissingForTrip(string purpose) => MissingForTrips(new[] { purpose });

        /// <summary>这次出门该带、背包里却没有的东西；箱子里有的话说在哪个箱子。都带齐了返回 null。</summary>
        private static string MissingForTrips(IReadOnlyList<string> purposes)
        {
            var parts = new List<string>();
            List<(GameLocation loc, Point tile, Chest chest)> chests = null;
            foreach (var (name, match) in purposes.SelectMany(TripNeeds).DistinctBy(n => n.name))
            {
                if (Player.Items.Any(i => i != null && match(i)))
                    continue;
                chests ??= AllChests();
                var where = chests.FirstOrDefault(c => c.chest.GetItemsForPlayer().Any(i => i != null && match(i)));
                parts.Add(where.chest != null
                    ? $"{name}在 {where.loc.NameOrUniqueName} ({where.tile.X},{where.tile.Y}) 的箱子里（take_items 拿出来）"
                    : $"没有{name}");
            }
            return parts.Count == 0 ? null : $"{TripPurposeName(purposes)}还缺：" + string.Join("；", parts);
        }

        /// <summary>出门（下矿、钓鱼）时身上带着、但这次用不上的东西，给动作结果加一句提醒。</summary>
        private static string TripClutterHint(string purpose, Func<Item, bool> alsoUseful = null)
        {
            var reserved = ReservedChecker();
            var clutter = Player.Items.Where(i => i != null && !UsefulFor(purpose, i) && alsoUseful?.Invoke(i) != true && reserved(i) == null
                                                  && !(i is SObject o && o.Edibility > 0)).ToList();
            if (clutter.Count < 4 || Player.freeSpotsInInventory() > 6)
                return null;
            return $"背包空位只剩 {Player.freeSpotsInInventory()} 个，带着{PurposeName[purpose]}用不上的 {string.Join("、", clutter.Take(6).Select(i => i.DisplayName))}{(clutter.Count > 6 ? $" 等 {clutter.Count} 样" : "")}。"
                + $"下次出门前先在农场 tidy_backpack purpose={purpose}，空出位置装战利品";
        }

        // ───────────────────────── 农田 ─────────────────────────

        internal sealed class Field
        {
            public List<Point> Tiles = new();
            public int Crops, Empty;
            /// <summary>季节种子长成的野菜（游戏已经把作物换成了地上的采集物）。</summary>
            public int WildReady;
            public Rectangle Box;
            /// <summary>田里种的作物：名字 → 株数（多的在前）。</summary>
            public Dictionary<string, int> CropNames = new();
            /// <summary>田里作物的种子 id（plant_seeds 把同样的种子种到同一块田）。</summary>
            public HashSet<string> SeedIds = new();
            public string Describe() =>
                $"({Box.Left},{Box.Top})-({Box.Right - 1},{Box.Bottom - 1}) 共 {Tiles.Count} 格耕地：作物 {Crops}"
                + (CropNames.Count > 0 ? $"（{string.Join("、", CropNames.OrderByDescending(kv => kv.Value).Take(4).Select(kv => $"{kv.Key} {kv.Value}"))}）" : "")
                + (WildReady > 0 ? $"，长成的野菜 {WildReady} 个（不算作物，harvest_crops 或 forage 会捡）" : "")
                + $"，空 {Empty}";
        }

        /// <summary>
        /// 把耕地按“挨在一起”分成一块块田（隔一格也算同一块：洒水器、稻草人、小路占的格子不把田切开）。
        /// 大的在前。
        /// </summary>
        internal static List<Field> Fields(GameLocation loc)
        {
            var dirt = new HashSet<Point>(loc.terrainFeatures.Pairs.Where(p => p.Value is HoeDirt).Select(p => new Point((int)p.Key.X, (int)p.Key.Y)));
            var seen = new HashSet<Point>();
            var fields = new List<Field>();
            foreach (var start in dirt)
            {
                if (!seen.Add(start))
                    continue;
                var field = new Field();
                var queue = new Queue<Point>();
                queue.Enqueue(start);
                while (queue.Count > 0)
                {
                    var p = queue.Dequeue();
                    field.Tiles.Add(p);
                    for (int dx = -2; dx <= 2; dx++)
                        for (int dy = -2; dy <= 2; dy++)
                        {
                            var n = new Point(p.X + dx, p.Y + dy);
                            if (Math.Abs(dx) + Math.Abs(dy) <= 2 && dirt.Contains(n) && seen.Add(n))
                                queue.Enqueue(n);
                        }
                }
                int x1 = field.Tiles.Min(p => p.X), y1 = field.Tiles.Min(p => p.Y);
                field.Box = new Rectangle(x1, y1, field.Tiles.Max(p => p.X) - x1 + 1, field.Tiles.Max(p => p.Y) - y1 + 1);
                foreach (var p in field.Tiles)
                {
                    var hd = (HoeDirt)loc.terrainFeatures[new Vector2(p.X, p.Y)];
                    if (hd.crop != null)
                    {
                        field.Crops++;
                        string cropName = hd.crop.dead.Value ? "枯死的作物" : ItemRegistry.GetDataOrErrorItem("(O)" + hd.crop.indexOfHarvest.Value).DisplayName;
                        field.CropNames[cropName] = field.CropNames.GetValueOrDefault(cropName) + 1;
                        if (!string.IsNullOrEmpty(hd.crop.netSeedIndex.Value))
                            field.SeedIds.Add(hd.crop.netSeedIndex.Value);
                    }
                    else if (loc.Objects.TryGetValue(new Vector2(p.X, p.Y), out var onSoil))
                    {
                        if (IsGrabbable(onSoil))
                            field.WildReady++;
                    }
                    else
                        field.Empty++;
                }
                fields.Add(field);
            }
            return fields.OrderByDescending(f => f.Tiles.Count).ToList();
        }

        /// <summary>
        /// 锄地前 till_area 会自己清掉的杂物（和 clear_area 不带 include_trees 时清的一样）：杂草、长草、小石头、树枝、
        /// 树桩、小树苗、远古斑点。只算能开垦的地面上的（枯死作物在已耕地上，单独提示先 clear_area）。
        /// </summary>
        internal static bool FieldClutter(GameLocation loc, Point p) =>
            loc.isTileOnMap(p.X, p.Y) && loc.doesTileHaveProperty(p.X, p.Y, "Diggable", "Back") != null
            && Observer.ClassifyFeature(loc, new Vector2(p.X, p.Y)).ch is 'w' or '"' or 'o' or '/' or '?' or 't' or 'S';

        /// <summary>锄不上的格子是什么挡着（结果里告诉 AI）。</summary>
        internal static string HoleName(GameLocation loc, Point p)
        {
            string name = Observer.ClassifyFeature(loc, new Vector2(p.X, p.Y)).name;
            if (name != null)
                return name;
            var px = new Point(p.X * 64 + 32, p.Y * 64 + 32);
            if (loc.resourceClumps.Any(c => c.getBoundingBox().Contains(px)))
                return "大型障碍（大树桩/大石头/原木）";
            if (loc.largeTerrainFeatures.Any(f => f.getBoundingBox().Contains(px)))
                return "灌木";
            return "走不过去的空地";
        }

        /// <summary>和 till_area 一样的“能直接开垦”判断。</summary>
        private static bool Tillable(GameLocation loc, Point p) =>
            loc.isTileOnMap(p.X, p.Y)
            && loc.doesTileHaveProperty(p.X, p.Y, "Diggable", "Back") != null
            && !loc.Objects.ContainsKey(new Vector2(p.X, p.Y))
            && !loc.terrainFeatures.ContainsKey(new Vector2(p.X, p.Y))
            && Pathfinder.IsPassable(loc, p.X, p.Y);

        /// <summary>
        /// 挨着最大那块田、能直接开垦的扩田位置：在田的上下左右各试一条同宽（或同高）的带子，挑能开垦格最多的。
        /// 没有田时返回 null。
        /// </summary>
        internal static string SuggestFieldExpansion(GameLocation loc, int want = 20)
        {
            // 联机时的农场工人：只建议扩自己小屋门口的田（和 till_area 不给坐标时一样），说法也换成“你门口的田”
            var big = Fields(loc).Where(f => f.Tiles.Count >= 4).ToList();
            string which = "最大的田";
            if (loc is Farm && MyCabinDoor() is Point door)
            {
                big = big.Where(f => FieldDistance(f, door) <= OwnFieldRadius).OrderBy(f => FieldDistance(f, door)).ToList();
                which = "你门口的田";
            }
            var main = big.FirstOrDefault();
            if (main == null)
                return null;
            var best = BestExpansion(loc, main, want);
            if (best.n == 0)
                return $"{which} {main.Describe()}，四周都是树、大树桩大石头或者不能开垦的地面，没法挨着扩，另挑地方开一块";
            return $"挨着{which}往{best.side}扩：till_area {best.r.Left},{best.r.Top},{best.r.Right - 1},{best.r.Bottom - 1}（能开 {best.n} 格"
                + (best.clutter > 0 ? $"，其中 {best.clutter} 格有杂草石头，till_area 会先清掉" : "") + "；也可以只传 count 让它自己挨着扩）";
        }

        /// <summary>
        /// 挨着一块田往上下左右哪边扩最好：扩出的矩形、方向、里面能开的格数（空地加上 till_area 会先清掉的杂物格）、其中杂物格数。
        /// 能开的多的优先；杂物格要花时间体力清，按 0.7 格算，差不多大时挑杂物少的。
        /// </summary>
        internal static (Rectangle r, string side, int n, int clutter) BestExpansion(GameLocation loc, Field main, int want)
        {
            var b = main.Box;
            int mw = Pathfinder.MapWidth(loc), mh = Pathfinder.MapHeight(loc);
            var options = new List<(Rectangle r, string side)>();
            int rows = Math.Clamp((int)Math.Ceiling(want / (double)b.Width), 1, 12);
            int cols = Math.Clamp((int)Math.Ceiling(want / (double)b.Height), 1, 12);
            options.Add((new Rectangle(b.Left, b.Bottom, b.Width, rows), "下"));
            options.Add((new Rectangle(b.Left, b.Top - rows, b.Width, rows), "上"));
            options.Add((new Rectangle(b.Right, b.Top, cols, b.Height), "右"));
            options.Add((new Rectangle(b.Left - cols, b.Top, cols, b.Height), "左"));
            var covered = SprinklerCovered(loc);
            return options.Select(o =>
                {
                    var r = mw > 0 && mh > 0 ? Rectangle.Intersect(o.r, new Rectangle(0, 0, mw, mh)) : o.r;
                    var pts = r.Width > 0 && r.Height > 0
                        ? Enumerable.Range(r.Left, r.Width).SelectMany(x => Enumerable.Range(r.Top, r.Height).Select(y => new Point(x, y))).ToList()
                        : new List<Point>();
                    int free = pts.Count(p => Tillable(loc, p)), clutter = pts.Count(p => FieldClutter(loc, p));
                    int spr = pts.Count(p => covered.Contains(new Vector2(p.X, p.Y)) && (Tillable(loc, p) || FieldClutter(loc, p)));
                    return (r, o.side, n: free + clutter, clutter, score: free + 0.7 * clutter + 0.5 * spr);
                })
                // 分数差不多时挑让田更方正的一边：扩完以后外框的长宽比越接近 1 越好浇（升级水壶一次浇一片）。
                // 以前只看能开几格，同样多时总是往“下”扩，扩几次就成一条长带
                .OrderByDescending(o => Math.Round(o.score))
                .ThenBy(o => Squareness(b, o.r))
                .Select(o => (o.r, o.side, o.n, o.clutter)).First();
        }

        /// <summary>田 main 加上扩出的 add 以后，外框的长边比短边（1 = 正方形，越大越像长条）。</summary>
        internal static double Squareness(Rectangle main, Rectangle add)
        {
            var u = Rectangle.Union(main, add);
            return Math.Max(u.Width, u.Height) / (double)Math.Max(1, Math.Min(u.Width, u.Height));
        }

        /// <summary>矩形离某块田隔着几格（0 = 挨着或重叠）。Rectangle 的 Right/Bottom 是开区间。</summary>
        private static int RectGap(Rectangle a, Rectangle b)
        {
            int dx = Math.Max(0, Math.Max(a.Left - b.Right, b.Left - a.Right));
            int dy = Math.Max(0, Math.Max(a.Top - b.Bottom, b.Top - a.Bottom));
            return Math.Max(dx, dy);
        }

        /// <summary>状态里的农田概况：有几块田、在哪、空多少；零散耕地多少；往哪扩。</summary>
        internal static string FieldOverview(GameLocation loc)
        {
            var fields = Fields(loc);
            if (fields.Count == 0)
                return null;
            var big = fields.Where(f => f.Tiles.Count >= 4).ToList();
            var sb = new StringBuilder();
            sb.Append("农田：");
            sb.Append(big.Count == 0 ? "还没有成片的田" : string.Join("；", big.Take(4).Select((f, i) => $"田{i + 1} {f.Describe()}")));
            var small = fields.Where(f => f.Tiles.Count < 4).ToList();
            int scattered = small.Sum(f => f.Tiles.Count), scatteredCrops = small.Sum(f => f.Crops);
            if (scattered > 0)
                sb.Append($"；零散耕地 {scattered} 格" + (scatteredCrops > 0 ? $"（其中 {scatteredCrops} 株作物，收完别再往这里种）" : "")
                    + "，plant_seeds 不会往零散耕地上种，空着的过几天会自己消失");
            sb.Append("。一块田种一种作物（或者同一季、一起收的几种），不同作物可以分开开几块田；新田挑方便的地方开（离家、出货箱、水边近，留出走的路和放洒水器的位置），不用非挨着老田；每块田开得方方正正，好浇水、好放洒水器");
            if (SprinklerSpareTiles(loc) is string spare)
                sb.Append("；" + spare);
            if (SuggestFieldExpansion(loc) is string ext && big.Sum(f => f.Empty) < 6)
                sb.Append("；" + ext);
            return sb.ToString();
        }

        // ───────────────────────── 建筑 / 机器摆放 ─────────────────────────

        /// <summary>
        /// 规划上的问题（放得下，但放了以后难用）：贴着别的建筑没留路、门口被挡、压着田边。没问题返回 null。
        /// 建筑的门在下面（鸡舍、畜棚、小屋的人门和动物门都朝南），所以下方两格要空出来。
        /// </summary>
        private static string BuildingLayoutProblem(Farm farm, Point tile, Point size, List<Rectangle> fieldBoxes = null)
        {
            var field = fieldBoxes ?? Fields(farm).Where(f => f.Tiles.Count >= 4).Select(f => f.Box).ToList();
            var footprint = new Rectangle(tile.X, tile.Y, size.X, size.Y);
            foreach (var box in field)
                if (RectGap(footprint, box) <= 1)
                    return $"紧挨着田 ({box.Left},{box.Top})-({box.Right - 1},{box.Bottom - 1})，以后没法往这边扩田，也挡洒水器";
            // 别的建筑门口（下方两行）也要空着
            foreach (var b in farm.buildings)
            {
                var door = new Rectangle(b.tileX.Value, b.tileY.Value + b.tilesHigh.Value, b.tilesWide.Value, 2);
                if (door.Intersects(footprint))
                    return $"堵在 {b.buildingType.Value}（左上角 ({b.tileX.Value},{b.tileY.Value})）门口，门口要空着的是 ({door.Left},{door.Top})-({door.Right - 1},{door.Bottom - 1})";
            }
            for (int x = tile.X - 1; x <= tile.X + size.X; x++)
                for (int y = tile.Y - 1; y <= tile.Y + size.Y + 2; y++)
                {
                    bool inside = x >= tile.X && x < tile.X + size.X && y >= tile.Y && y < tile.Y + size.Y;
                    if (inside)
                        continue;
                    var v = new Vector2(x, y);
                    var other = farm.buildings.FirstOrDefault(b => b.occupiesTile(v));
                    if (other != null)
                        return $"和 {other.buildingType.Value}（占 ({other.tileX.Value},{other.tileY.Value})-({other.tileX.Value + other.tilesWide.Value - 1},{other.tileY.Value + other.tilesHigh.Value - 1})）挨得太近（四周要留一格路，门口下方要空两格）";
                    if (y > tile.Y + size.Y - 1 && x >= tile.X && x < tile.X + size.X && farm.isWaterTile(x, y))
                        return "门口下方是水，进不去";
                }
            return null;
        }

        /// <summary>自动选建筑位置：同类建筑排成一排（同一行或同一列、隔两格），没有同类就在农舍附近；不贴田、不堵门。</summary>
        private static Point? PlanBuildingSpot(Farm farm, BuildingData data, string buildingType)
        {
            var house = farm.GetMainFarmHouseEntry();
            // 同类放一起：鸡舍、畜棚、筒仓是一片（筒仓给它们供干草）；其他建筑（棚屋、水井……）跟同名的放一起
            bool AnimalArea(string type) => type.Contains("Coop") || type.Contains("Barn") || type == "Silo";
            var peers = farm.buildings.Where(b => AnimalArea(buildingType) ? AnimalArea(b.buildingType.Value) : b.buildingType.Value == buildingType)
                .Select(b => new Point(b.tileX.Value, b.tileY.Value)).ToList();
            int w = Pathfinder.MapWidth(farm), h = Pathfinder.MapHeight(farm);
            var boxes = Fields(farm).Where(f => f.Tiles.Count >= 4).Select(f => f.Box).ToList();
            var candidates = new List<(Point c, int score)>();
            for (int cx = 1; cx < w - data.Size.X; cx++)
                for (int cy = 1; cy < h - data.Size.Y - 2; cy++)
                {
                    var c = new Point(cx, cy);
                    int dHouse = Util.Manhattan(c, house);
                    if (dHouse < 6)
                        continue; // 别堵在家门口
                    int score = peers.Count > 0
                        ? peers.Min(p => Util.Manhattan(c, p) + (p.Y == c.Y || p.X == c.X ? 0 : 6)) * 2 + dHouse / 4
                        : dHouse;
                    candidates.Add((c, score));
                }
            foreach (var (c, _) in candidates.OrderBy(x => x.score))
                if (CanPlace(farm, data, c) && BuildingLayoutProblem(farm, c, data.Size, boxes) == null)
                    return c;
            return null;
        }

        // ───────────────────────── 洒水器 ─────────────────────────

        /// <summary>已经被现有洒水器浇到的格子。</summary>
        private static HashSet<Vector2> SprinklerCovered(GameLocation loc) =>
            loc.objects.Values.Where(o => o.IsSprinkler()).SelectMany(o => o.GetSprinklerTiles()).Where(v => !NoSprinklers(loc, v)).ToHashSet();

        /// <summary>海滩农场的沙地等格子带 NoSprinklers：洒水器放不上去，也浇不到这格（Object.ApplySprinkler / placementAction）。</summary>
        internal static bool NoSprinklers(GameLocation loc, Vector2 v) =>
            loc.doesTileHavePropertyNoNull((int)v.X, (int)v.Y, "NoSprinklers", "Back") == "T";

        /// <summary>这只洒水器放在 tile 上能新浇到几格耕地（已经被别的洒水器浇到的不算）。范围由游戏自己算，普通 4 格、优质 3x3、铱制 5x5。</summary>
        private static int SprinklerGain(GameLocation loc, SObject sprinkler, Point tile, HashSet<Vector2> covered)
        {
            if (sprinkler.getOne() is not SObject probe)
                return 0;
            probe.TileLocation = new Vector2(tile.X, tile.Y);
            return probe.GetSprinklerTiles().Count(v => !covered.Contains(v) && !NoSprinklers(loc, v) && loc.terrainFeatures.TryGetValue(v, out var f) && f is HoeDirt);
        }

        /// <summary>能放洒水器的格子：没有东西、没有作物（空耕地可以）、走得到。</summary>
        private static bool CanHoldSprinkler(GameLocation loc, Point t)
        {
            var v = new Vector2(t.X, t.Y);
            if (!loc.isTileOnMap(t.X, t.Y) || loc.Objects.ContainsKey(v) || NoSprinklers(loc, v))
                return false;
            if (loc.terrainFeatures.TryGetValue(v, out var f))
                return f is HoeDirt { crop: null };
            return Pathfinder.IsPassable(loc, t.X, t.Y);
        }

        /// <summary>
        /// 现在压着作物、收完以后能放洒水器的格子里，能新浇到最多耕地的那个。比 nowBest 明显多（多 2 格以上、而且 nowBest 不到它的四分之三）时，
        /// 返回“等 (x,y) 的某作物收完放那儿能浇 N 格”的说明；否则 null。
        /// </summary>
        private static string SprinklerAfterHarvest(GameLocation loc, SObject sprinkler, HashSet<Vector2> covered, int nowBest)
        {
            Point? best = null;
            int bestGain = 0;
            Crop bestCrop = null;
            foreach (var f in Fields(loc))
                foreach (var p in f.Tiles)
                {
                    var v = new Vector2(p.X, p.Y);
                    if (loc.Objects.ContainsKey(v) || loc.terrainFeatures[v] is not HoeDirt { crop: { } crop })
                        continue;
                    int g = SprinklerGain(loc, sprinkler, p, covered);
                    if (g > bestGain)
                    {
                        best = p;
                        bestGain = g;
                        bestCrop = crop;
                    }
                }
            if (!best.HasValue || bestGain < nowBest + 2 || nowBest * 4 >= bestGain * 3)
                return null;
            string cropName = bestCrop.dead.Value ? "枯死的作物"
                : ItemRegistry.GetDataOrErrorItem("(O)" + bestCrop.indexOfHarvest.Value).DisplayName;
            return $"这块田的好位置都种着作物：({best.Value.X},{best.Value.Y}) 上的{cropName}{HarvestWhen(bestCrop)}，到时把洒水器放在那里能浇到 {bestGain} 格，比现在能放的位置多 {bestGain - nowBest} 格";
        }

        /// <summary>这株作物什么时候能腾出格子。</summary>
        private static string HarvestWhen(Crop c)
        {
            if (c.dead.Value)
                return "已经枯死了，用镰刀清掉就能放";
            if (c.RegrowsAfterHarvest())
                return "收了还会再长，要等这一季结束才腾得出来（或者趁换季重新规划这块田）";
            if (c.fullyGrown.Value || c.currentPhase.Value >= c.phaseDays.Count - 1)
                return "已经能收了，收了就能放";
            int left = -c.dayOfCurrentPhase.Value;
            for (int i = c.currentPhase.Value; i < c.phaseDays.Count - 1; i++)
                left += c.phaseDays[i];
            return $"大约 {Math.Max(1, left)} 天后成熟，收了就能放";
        }

        /// <summary>
        /// 洒水器浇得到、但还空着的格子：没开垦的（till_area）和空耕地（plant_seeds）。冬天户外种不了东西，不提。没有洒水器或者都种上了返回 null。
        /// </summary>
        internal static string SprinklerSpareTiles(GameLocation loc)
        {
            var covered = SprinklerCovered(loc);
            if (covered.Count == 0 || (loc.IsOutdoors && loc.GetSeason() == Season.Winter))
                return null;
            var untilled = covered.Select(v => new Point((int)v.X, (int)v.Y)).Where(p => Tillable(loc, p)).ToList();
            int emptyDirt = covered.Count(v => !loc.Objects.ContainsKey(v) && loc.terrainFeatures.TryGetValue(v, out var f) && f is HoeDirt { crop: null });
            if (untilled.Count == 0 && emptyDirt == 0)
                return null;
            var parts = new List<string>();
            if (untilled.Count > 0)
            {
                int x1 = untilled.Min(p => p.X), y1 = untilled.Min(p => p.Y), x2 = untilled.Max(p => p.X), y2 = untilled.Max(p => p.Y);
                parts.Add($"{untilled.Count} 格还没开垦（till_area {x1},{y1},{x2},{y2} 会只开能开的格子）");
            }
            if (emptyDirt > 0)
                parts.Add($"{emptyDirt} 格是空耕地（plant_seeds 会补种）");
            return "洒水器浇得到、但还空着的格子：" + string.Join("，", parts) + "。种在这些格子上就不用自己浇水";
        }

        /// <summary>
        /// 洒水器放得对不对：放在 tile 一格耕地都浇不到，或者田里有明显更好的位置（能多浇不少格）时返回原因和建议坐标；没问题返回 null。
        /// gain 是放在 tile 能新浇到的耕地格数。
        /// </summary>
        private static string SprinklerProblem(GameLocation loc, Item item, Point tile, out int gain)
        {
            gain = 0;
            if (item is not SObject o || !o.IsSprinkler())
                return null;
            var covered = SprinklerCovered(loc);
            gain = SprinklerGain(loc, o, tile, covered);

            // 在每块田和它外面一圈里找能新浇到最多耕地的位置
            Point? best = null;
            int bestGain = 0;
            foreach (var f in Fields(loc))
            {
                for (int x = f.Box.Left - 1; x <= f.Box.Right; x++)
                    for (int y = f.Box.Top - 1; y <= f.Box.Bottom; y++)
                    {
                        var p = new Point(x, y);
                        if (!CanHoldSprinkler(loc, p))
                            continue;
                        int g = SprinklerGain(loc, o, p, covered);
                        if (g > bestGain || (g == bestGain && best.HasValue && Util.Manhattan(p, tile) < Util.Manhattan(best.Value, tile)))
                        {
                            best = p;
                            bestGain = g;
                        }
                    }
            }
            string name = o.DisplayName;
            // 田种满了：中间的好位置都压着作物，上面只能找到边上的位置。看看把作物收了以后最好能放哪，明显更好就告诉她等一等
            bool onCrop = loc.terrainFeatures.TryGetValue(new Vector2(tile.X, tile.Y), out var tf) && tf is HoeDirt { crop: not null };
            // 选的格子种着作物时那个位置本身放不了，只和现在真能放的位置比
            string later = SprinklerAfterHarvest(loc, o, covered, onCrop ? bestGain : Math.Max(gain, bestGain));
            string laterNote = later != null ? "。" + later : "";
            if (NoSprinklers(loc, new Vector2(tile.X, tile.Y)))
                return $"({tile.X},{tile.Y}) 是沙地之类放不了洒水器的格子（洒水器也浇不到这种格子，海滩农场只有一块非沙地能用）"
                    + (best.HasValue ? $"。能放的位置里最好的是 ({best.Value.X},{best.Value.Y})，能浇到 {bestGain} 格耕地" : "。这附近没有能放洒水器又浇得到耕地的位置，这块田只能手动浇水");
            if (onCrop)
                return $"({tile.X},{tile.Y}) 上种着作物，放不了{name}" + (best.HasValue ? $"。现在能放的位置里最好的是 ({best.Value.X},{best.Value.Y})，能浇到 {bestGain} 格耕地" : "") + laterNote;
            if (gain == 0)
                return (best.HasValue
                    ? $"{name}放在 ({tile.X},{tile.Y}) 一格耕地都浇不到（周围没有耕地，或者都已经被别的洒水器浇到了）。放在 ({best.Value.X},{best.Value.Y}) 能浇到 {bestGain} 格"
                    : $"{name}放在 ({tile.X},{tile.Y}) 一格耕地都浇不到，而且现在所有耕地都已经有洒水器浇了，这只先留着，等开了新田再放") + laterNote;
            if (best.HasValue && bestGain >= gain + 2 && gain * 4 < bestGain * 3)
                return $"{name}放在 ({tile.X},{tile.Y}) 只能浇到 {gain} 格耕地，放在 ({best.Value.X},{best.Value.Y}) 能浇到 {bestGain} 格" + laterNote;
            // 位置本身是现在能放的里面不错的，但收完作物以后有明显更好的位置：先拦一下，让她选现在放还是等
            if (later != null)
                return $"{name}放在 ({tile.X},{tile.Y}) 能浇到 {gain} 格耕地，这已经是现在能放的位置里比较好的了。{later}。不急的话先留着，收完再放";
            return null;
        }

        /// <summary>农场上摆机器、箱子的规划问题：别压在田里、别堵建筑门口。洒水器、稻草人本来就该放田里。</summary>
        private static string PlacementProblem(GameLocation loc, Item item, Point tile)
        {
            if (item is not SObject o || !o.bigCraftable.Value)
                return null;
            string farmProblem = loc is Farm farm && !o.IsSprinkler() && !o.IsScarecrow() ? FarmPlacementProblem(farm, o, tile) : null;
            if (farmProblem != null)
                return farmProblem;
            // 箱子、机器会挡路：放下后不能把路堵死，也不能把旁边的箱子/机器围得够不着
            if (BlockageProblem(loc, tile) is string block)
            {
                var better = NearbyUnblockingSpot(loc, o, tile);
                return block + (better is Point b ? $"。换到 ({b.X},{b.Y}) 不会挡路" : "");
            }
            return null;
        }

        /// <summary>农场上额外的规矩：别压田里、别堵建筑门口、箱子放一起。</summary>
        private static string FarmPlacementProblem(Farm farm, SObject o, Point tile, bool checkChestDistance = true)
        {
            foreach (var f in Fields(farm).Where(f => f.Tiles.Count >= 4))
                if (f.Box.Contains(tile))
                    return $"({tile.X},{tile.Y}) 在田 ({f.Box.Left},{f.Box.Top})-({f.Box.Right - 1},{f.Box.Bottom - 1}) 里面，机器箱子放田里会占地、挡路";
            foreach (var b in farm.buildings)
            {
                int bx = b.tileX.Value, by = b.tileY.Value;
                if (tile.Y >= by + b.tilesHigh.Value && tile.Y <= by + b.tilesHigh.Value + 1 && tile.X >= bx && tile.X < bx + b.tilesWide.Value)
                    return $"({tile.X},{tile.Y}) 堵在 {b.buildingType.Value}（左上角 ({bx},{by})）门口，门口 ({bx},{by + b.tilesHigh.Value})-({bx + b.tilesWide.Value - 1},{by + b.tilesHigh.Value + 1}) 要空着";
            }
            // 箱子放一起：离已有的箱子太远就拦下，告诉她挨着哪个放
            if (checkChestDistance && (o is Chest || ChestIds.Contains(o.QualifiedItemId)))
            {
                var others = PlayerChests(farm).Select(c => c.tile).ToList();
                if (others.Count > 0)
                {
                    var near = others.OrderBy(c => Math.Max(Math.Abs(c.X - tile.X), Math.Abs(c.Y - tile.Y))).First();
                    if (Math.Max(Math.Abs(near.X - tile.X), Math.Abs(near.Y - tile.Y)) > 3)
                        return $"箱子要和农场上已有的箱子放在一起，({tile.X},{tile.Y}) 离最近的箱子 ({near.X},{near.Y}) 太远了，挨着它放（旁边留一格走路）";
                }
            }
            return null;
        }

        /// <summary>从玩家现在的位置能走到的格子；block 那一格当成已经放了东西。passable 是缓存。</summary>
        private static HashSet<Point> ReachableTiles(GameLocation loc, Point start, Point? block, Dictionary<Point, bool> passable, int maxNodes = 12000)
        {
            bool Can(Point p)
            {
                if (block == p)
                    return false;
                if (!passable.TryGetValue(p, out bool ok))
                    passable[p] = ok = Pathfinder.IsPassable(loc, p.X, p.Y);
                return ok;
            }
            var seen = new HashSet<Point> { start };
            var queue = new Queue<Point>();
            queue.Enqueue(start);
            while (queue.Count > 0 && seen.Count < maxNodes)
            {
                var cur = queue.Dequeue();
                foreach (var d in Pathfinder.Dirs)
                {
                    var next = new Point(cur.X + d.X, cur.Y + d.Y);
                    if (!seen.Contains(next) && Can(next))
                    {
                        seen.Add(next);
                        queue.Enqueue(next);
                    }
                }
            }
            return seen;
        }

        /// <summary>
        /// 在 tile 放一个挡路的东西以后：原来走得到的地方有没有被隔开（堵死一条窄路、把一块空地围起来），
        /// 附近的箱子/机器是不是还有一格能站过去用。有问题返回原因，没问题返回 null。
        /// </summary>
        private static string BlockageProblem(GameLocation loc, Point tile, Dictionary<Point, bool> cache = null, HashSet<Point> before = null, Point? from = null)
        {
            var start = from ?? Game1.player.TilePoint;
            if (start == tile)
                return null;
            cache ??= new Dictionary<Point, bool>();
            before ??= ReachableTiles(loc, start, null, cache);
            if (!before.Contains(tile))
                return null; // 放在走不到的地方，本来就不挡谁
            var after = ReachableTiles(loc, start, tile, cache);
            if (before.Count < 12000 && after.Count < before.Count - 1)
            {
                var lost = before.Where(p => p != tile && !after.Contains(p)).ToList();
                // 墙角一两格的小凹位被挡住无所谓（旁边的箱子/机器下面单独查）
                if (lost.Count > 2)
                {
                    var near = lost.OrderBy(p => Util.Manhattan(p, tile)).First();
                    return $"({tile.X},{tile.Y}) 放下以后会把路堵死：({near.X},{near.Y}) 那边 {lost.Count} 格就走不过去了";
                }
            }
            // 附近的箱子、机器：原来能站到它旁边，放下以后还得能
            foreach (var p in loc.objects.Pairs)
            {
                var ot = new Point((int)p.Key.X, (int)p.Key.Y);
                if (!p.Value.bigCraftable.Value || Math.Max(Math.Abs(ot.X - tile.X), Math.Abs(ot.Y - tile.Y)) > 2)
                    continue;
                var stands = Pathfinder.Dirs.Select(d => new Point(ot.X + d.X, ot.Y + d.Y)).ToList();
                if (stands.Any(before.Contains) && !stands.Any(s => s != tile && after.Contains(s)))
                    return $"({tile.X},{tile.Y}) 放下以后，({ot.X},{ot.Y}) 的{p.Value.DisplayName}四周就没有能站的格子了，打不开/用不了";
            }
            return null;
        }

        /// <summary>tile 附近（3 格内）放下不挡路、也不违反农场规矩的格子，离 tile 最近的一个。</summary>
        private static Point? NearbyUnblockingSpot(GameLocation loc, SObject o, Point tile)
        {
            var cache = new Dictionary<Point, bool>();
            var before = ReachableTiles(loc, Game1.player.TilePoint, null, cache);
            var candidates = new List<Point>();
            for (int dx = -3; dx <= 3; dx++)
                for (int dy = -3; dy <= 3; dy++)
                    if (dx != 0 || dy != 0)
                        candidates.Add(new Point(tile.X + dx, tile.Y + dy));
            foreach (var c in candidates.OrderBy(c => Util.Manhattan(c, tile)))
            {
                // 放不放得下和 place_item 用同一套判断（PlaceableProblem）
                if (!before.Contains(c) || c == Game1.player.TilePoint || PlaceableProblem(loc, o, c) != null)
                    continue;
                if (loc is Farm farm && !o.IsSprinkler() && !o.IsScarecrow() && FarmPlacementProblem(farm, o, c) != null)
                    continue;
                if (BlockageProblem(loc, c, cache, before) == null)
                    return c;
            }
            return null;
        }

        private static readonly HashSet<string> ChestIds = new() { "(BC)130", "(BC)232", "(BC)BigChest", "(BC)BigStoneChest" };

        /// <summary>
        /// 已经摆了机器/箱子的地方（同一片放一起好管理），给放置失败的提示用。坐标都是格子坐标，和 get_state 里“你站在 (x,y)”同一套。
        /// 报最大那一片的范围 (a,b)-(c,d)；给了 item 就再挑一格挨着这片、真能放下也合规矩的空位（以前只报一台机器自己的格子，照着走过去会撞上它）。
        /// </summary>
        private static string MachineAreaHint(GameLocation loc, Item item = null)
        {
            var spots = loc.objects.Pairs.Where(p => p.Value.bigCraftable.Value && !p.Value.IsSprinkler() && !p.Value.IsScarecrow())
                .Select(p => new Point((int)p.Key.X, (int)p.Key.Y)).ToList();
            if (spots.Count == 0)
                return "在出货箱或农舍旁边找块不碍路的空地，以后机器、箱子都放这一片";
            var groups = MachineGroups(spots);
            var main = groups[0];
            var box = BoundingBox(main);
            string range = box.Width == 1 && box.Height == 1 ? $"({box.Left},{box.Top})" : $"({box.Left},{box.Top})-({box.Right - 1},{box.Bottom - 1})";
            string msg = $"已经摆的机器/箱子最多的一片在 {range}（{main.Count} 台）";
            if (groups.Count > 1)
                msg += $"，另外还有 {groups.Count - 1} 片零散的";
            if (item != null && FreeSpotBeside(loc, item, box) is Point free)
                msg += $"，挨着这片能放的空位比如 ({free.X},{free.Y})";
            else
                msg += "，挨着这片的边上放（留一格走路）";
            return msg;
        }

        /// <summary>机器格子按“隔 2 格以内算一片”分组，大的在前。</summary>
        private static List<List<Point>> MachineGroups(List<Point> spots)
        {
            var left = new HashSet<Point>(spots);
            var groups = new List<List<Point>>();
            while (left.Count > 0)
            {
                var seed = left.First();
                left.Remove(seed);
                var group = new List<Point> { seed };
                var queue = new Queue<Point>(group);
                while (queue.Count > 0)
                {
                    var cur = queue.Dequeue();
                    foreach (var n in left.Where(p => Math.Max(Math.Abs(p.X - cur.X), Math.Abs(p.Y - cur.Y)) <= 2).ToList())
                    {
                        left.Remove(n);
                        group.Add(n);
                        queue.Enqueue(n);
                    }
                }
                groups.Add(group);
            }
            return groups.OrderByDescending(g => g.Count).ToList();
        }

        private static Rectangle BoundingBox(List<Point> pts)
        {
            int l = pts.Min(p => p.X), t = pts.Min(p => p.Y);
            return new Rectangle(l, t, pts.Max(p => p.X) - l + 1, pts.Max(p => p.Y) - t + 1);
        }

        /// <summary>机器那片外面一圈（隔 1~2 格）里，放得下、也合规矩的格子，离玩家最近的一个。最多试 40 格（每格要算一遍会不会挡路）。</summary>
        private static Point? FreeSpotBeside(GameLocation loc, Item item, Rectangle box)
        {
            var me = Game1.player.TilePoint;
            var ring = new List<Point>();
            for (int x = box.Left - 2; x <= box.Right + 1; x++)
                for (int y = box.Top - 2; y <= box.Bottom + 1; y++)
                    if (!box.Contains(x, y))
                        ring.Add(new Point(x, y));
            foreach (var c in ring.Where(c => c != me && PlaceableProblem(loc, item, c) == null).OrderBy(c => Util.Manhattan(c, me)).Take(40))
                if (PlacementProblem(loc, item, c) == null)
                    return c;
            return null;
        }

        // ───────────────────────── 箱子总览 ─────────────────────────

        /// <summary>所有地点玩家放的箱子（农场、农舍、小屋、建筑里面……）。</summary>
        internal static List<(GameLocation loc, Point tile, Chest chest)> AllChests()
        {
            var list = new List<(GameLocation, Point, Chest)>();
            Utility.ForEachLocation(l =>
            {
                foreach (var (tile, chest) in PlayerChests(l))
                    list.Add((l, tile, chest));
                // 冰箱也是箱子
                if (l is StardewValley.Locations.FarmHouse fh && fh.fridge.Value is Chest fridge && fridge.Items.Any(i => i != null))
                    list.Add((l, fh.fridgePosition, fridge));
                return true;
            });
            return list;
        }

        /// <summary>状态里的箱子概况：每个箱子在哪、装了多少格、主要装了什么。</summary>
        internal static string ChestOverview(int maxChars = 900)
        {
            var chests = AllChests();
            if (chests.Count == 0)
                return null;
            var sb = new StringBuilder();
            foreach (var (loc, tile, chest) in chests)
            {
                var items = chest.GetItemsForPlayer().Where(i => i != null).ToList();
                bool fridge = loc is StardewValley.Locations.FarmHouse fh && chest == fh.fridge.Value;
                string kind = fridge || items.Count == 0 ? "" : $"【{ChestGroup(items)}】";
                string head = $"- {loc.NameOrUniqueName} ({tile.X},{tile.Y}){(fridge ? " 冰箱" : "")}{kind} {items.Count}/{chest.GetActualCapacity()} 格：";
                string body = items.Count == 0 ? "空" : string.Join("、", items.OrderByDescending(i => i.Stack).Take(10).Select(i => $"{i.DisplayName}x{i.Stack}"))
                                                    + (items.Count > 10 ? $" 等 {items.Count} 种" : "");
                if (sb.Length + head.Length + body.Length > maxChars)
                {
                    sb.AppendLine($"- ……还有 {chests.Count - sb.ToString().Split('\n').Length + 1} 个箱子，用 list_chests 看全部");
                    break;
                }
                sb.AppendLine(head + body);
            }
            return sb.ToString().TrimEnd();
        }

        /// <summary>get_state 里箱子概览被折叠（和上次一样）时留的一行摘要：箱子数 + 全部箱子里数量最多的几样，让 AI 不会觉得“不记得箱子里有什么”。</summary>
        internal static string ChestSummary()
        {
            var chests = AllChests();
            if (chests.Count == 0)
                return "还没有箱子";
            var totals = new Dictionary<string, int>();
            foreach (var (_, _, chest) in chests)
                foreach (var i in chest.GetItemsForPlayer().Where(i => i != null))
                    totals[i.DisplayName] = totals.GetValueOrDefault(i.DisplayName) + i.Stack;
            string top = string.Join("、", totals.OrderByDescending(kv => kv.Value).Take(5).Select(kv => $"{kv.Key}x{kv.Value}"));
            return $"箱子共 {chests.Count} 个，里面一共 {totals.Count} 种东西" + (top.Length > 0 ? $"，数量最多：{top}" : "（全是空的）");
        }

        /// <summary>list_chests：列出所有箱子里的东西；给了 item 就只找这样东西放在哪。不花游戏时间。</summary>
        public IEnumerable<object> ListChests(string item)
        {
            var chests = AllChests();
            if (chests.Count == 0)
            {
                yield return ActionResult.Fail("还没有放过箱子。craft Chest（50 木材）再 place_item 放在农场上");
                yield break;
            }
            var filter = string.IsNullOrWhiteSpace(item) ? null : ItemFilter(item);
            var sb = new StringBuilder();
            int hits = 0;
            foreach (var (loc, tile, chest) in chests)
            {
                var items = chest.GetItemsForPlayer().Where(i => i != null && (filter == null || filter(i))).ToList();
                if (filter != null && items.Count == 0)
                    continue;
                hits += items.Sum(i => i.Stack);
                string kind = ChestGroup(chest.GetItemsForPlayer()) is { } g && !(loc is StardewValley.Locations.FarmHouse fh && chest == fh.fridge.Value) ? $"【{g}】" : "";
                sb.AppendLine($"{loc.NameOrUniqueName} ({tile.X},{tile.Y}){kind} {chest.GetItemsForPlayer().Count(i => i != null)}/{chest.GetActualCapacity()} 格："
                    + (items.Count == 0 ? "空" : string.Join("、", items.Select(Util.ItemLabel))));
            }
            if (filter != null && hits == 0)
            {
                var bag = Player.Items.Where(i => i != null && filter(i)).Sum(i => i.Stack);
                yield return ActionResult.Fail($"哪个箱子里都没有“{item}”" + (bag > 0 ? $"（背包里有 {bag} 个）" : ""));
                yield break;
            }
            // 背包里同名的也列出来（带品质），不然 AI 只看箱子会以为背包里没有金星的
            var inBag = filter == null ? null : Player.Items.Where(i => i != null && filter(i)).ToList();
            yield return ActionResult.Success((filter != null ? $"“{item}”箱子里一共 {hits} 个，在：\n" : "")
                + sb.ToString().TrimEnd()
                + (inBag is { Count: > 0 } ? $"\n背包里还有：{string.Join("、", inBag.Select(Util.ItemLabel))}" : "")
                + "\n（take_items 要先 travel_to 到箱子所在地点；背包里每样东西的品质看 get_state 的背包，没写星就是普通）");
        }
    }
}
