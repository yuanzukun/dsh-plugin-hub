using StardewModdingAPI;

namespace BlindWhaleFarmer
{
    public class ModConfig
    {
        /// <summary>DeepSeek API Key。留空时读取环境变量 DEEPSEEK_API_KEY。</summary>
        public string ApiKey { get; set; } = "";

        /// <summary>OpenAI 兼容接口地址（不含 /chat/completions）。</summary>
        public string BaseUrl { get; set; } = "https://api.deepseek.com";

        /// <summary>模型名。deepseek-v4-flash 支持工具调用，速度快、便宜（旧名 deepseek-chat 已于 2026-07-24 停用）。</summary>
        public string Model { get; set; } = "deepseek-v4-flash";

        public float Temperature { get; set; } = 0.3f;

        public int MaxTokens { get; set; } = 4096;

        public int RequestTimeoutSeconds { get; set; } = 120;

        /// <summary>开关 AI 的快捷键。</summary>
        public SButton ToggleKey { get; set; } = SButton.F8;

        /// <summary>联机时弹出中文输入框的键（游戏聊天框里看不到输入法的候选词）。</summary>
        public SButton ChatInputKey { get; set; } = SButton.F6;

        /// <summary>
        /// 允许 AI 往游戏聊天里发话（say 工具、切换模式的自动播报、节日里“我准备好了”）。默认开；设成 false 就关：AI 不跟别的玩家聊天。
        /// 只管 AI 发出去的话，别人对它说的话它照样收得到；玩家自己按 ChatInputKey 弹出的输入框不受影响。
        /// </summary>
        public bool AllowChat { get; set; } = true;

        /// <summary>联机共用钱包时，允许 AI 在聊天播报后直接花共用金币，无需玩家同意。默认关闭，每次先问玩家。</summary>
        public bool AllowSpendSharedMoney { get; set; } = false;

        /// <summary>
        /// 联机时让 AI 把哪栋房子当家。填地图的 NameOrUniqueName，例如主机的 FarmHouse 或某个 Cabin 的唯一地图名。
        /// 留空按游戏登记的家。只影响 AI 回家和睡觉的目的地，不改游戏登记的房屋归属。
        /// </summary>
        public string AiHomeLocation { get; set; } = "";

        /// <summary>
        /// 联机时 sleep 未指定对象或房子时的默认同睡设置：留空 = 按 AiHomeLocation / 自己的家；
        /// 填玩家名 = 默认去该玩家屋里一起睡；填 random = 随机选一位在线玩家一起睡（无其他在线玩家则回自己的家）。
        /// </summary>
        public string CoSleepDefault { get; set; } = "";

        /// <summary>联机走路途中经过其他真人玩家附近时，停下转身发一个可爱表情。默认开，温和不打断任务。</summary>
        public bool PassbyEmoteEnabled { get; set; } = true;

        /// <summary>路上遇到其他玩家时发表情的触发概率（0~1，默认 0.35）。</summary>
        public float PassbyEmoteChance { get; set; } = 0.35f;

        /// <summary>路上遇到同一位玩家发表情的冷却间隔（现实分钟，默认 5 分钟）。</summary>
        public int PassbyEmoteCooldownMinutes { get; set; } = 5;

        /// <summary>联机空闲（没有任务）时，偶尔随机挑一位在线真人玩家跟一会儿并发表情卖萌（绝不捣乱，有新任务或聊天立刻停下）。默认开。</summary>
        public bool IdleFollowEnabled { get; set; } = true;

        /// <summary>联机空闲多久（现实秒）后触发一次跟着玩家卖萌（默认 180 秒，即 3 分钟；范围 30~3600）。</summary>
        public int IdleFollowIntervalSeconds { get; set; } = 180;

        /// <summary>每次空闲跟着玩家卖萌持续多久（现实秒，默认 30 秒；范围 10~180）。</summary>
        public int IdleFollowDurationSeconds { get; set; } = 30;

        /// <summary>联机时偶尔提醒 AI 挑一件有心意的小礼物（做的菜、捡的花、钓的鱼等）主动送给在线玩家。默认开。</summary>
        public bool ProactiveGiftEnabled { get; set; } = true;

        /// <summary>联机主动送礼提示的触发概率（0~1，默认 0.5）。</summary>
        public float ProactiveGiftChance { get; set; } = 0.5f;

        /// <summary>联机主动送礼的冷却间隔（游戏日，默认 1 表示每天最多触发 1 次；范围 1~28）。</summary>
        public int ProactiveGiftCooldownDays { get; set; } = 1;

        /// <summary>联机时 AI 怎么安排自己：solo 自己玩、command 主要听指令、hybrid 指令做完接着自己玩。</summary>
        public string CompanionMode { get; set; } = GameActions.ModeHybrid;

        /// <summary>接管键：中止 AI 正在执行的动作、拒绝之后的所有游戏动作，由玩家自己操作；再按一次交还给 AI。</summary>
        public SButton TakeOverKey { get; set; } = SButton.F7;

        /// <summary>等待模型回复时冻结游戏时间，避免思考浪费游戏内时间。</summary>
        public bool FreezeTimeWhileThinking { get; set; } = true;

        /// <summary>一次回复里最多执行多少个工具调用。</summary>
        public int MaxActionsPerStep { get; set; } = 6;

        /// <summary>提示词里保留多少条最近的行动记录。</summary>
        public int HistoryLines { get; set; } = 25;

        /// <summary>文字地图以玩家为中心的横向/纵向半径（格）。</summary>
        public int MapRadiusX { get; set; } = 14;
        public int MapRadiusY { get; set; } = 9;

        /// <summary>附近物体列表的搜索半径（格）。</summary>
        public int ScanRadius { get; set; } = 16;

        /// <summary>在屏幕左上角显示 AI 的想法和当前动作。</summary>
        public bool ShowHud { get; set; } = true;

        /// <summary>自动点掉出货结算界面、无需选择的升级界面。</summary>
        public bool AutoConfirmNightMenus { get; set; } = true;

        /// <summary>钓鱼小游戏里出现宝箱时，进度够高就先去拿宝箱再回来钓鱼（传说鱼不拿）。想保“完美”钓鱼就关掉。</summary>
        public bool FishTreasure { get; set; } = true;

        /// <summary>走路时顺手采集野生采集物的范围（格，含斜角）。0 = 不顺手采；1 = 只采紧挨着的；更大会离开路线几步去采再回来。最大 10。</summary>
        public int ForageRadius { get; set; } = 1;

        /// <summary>额外写给 AI 的目标/要求，例如“优先赚钱，第一年春天种满防风草”。</summary>
        public string ExtraInstructions { get; set; } = "";

        /// <summary>玩家要留着的东西，逗号分隔，例如“草莓种子, 远古水果”。AI 不卖、不出货、不吃、不扔、不种、不送、不拿去整理掉。</summary>
        public string ReservedItems { get; set; } = "";

        /// <summary>攻略文件（相对模组目录或绝对路径）。想改打法就复制一份改名后指到这里，更新模组时不会被覆盖；留空用 guide/攻略.md（旧名 guide/zh-CN.md 也会自动换成它）。</summary>
        public string GuideFile { get; set; } = Guide.DefaultFile;

        /// <summary>在 DSH 设置页改过的攻略：篇名（攻略、钓鱼、采矿、节日……）→ 全文。有内容的篇目优先于 guide/ 里的文件。</summary>
        public System.Collections.Generic.Dictionary<string, string> GuideOverrides { get; set; } = new();

        /// <summary>把每次发送给模型的完整提示词写到日志文件，方便调试。</summary>
        public bool LogPrompts { get; set; } = false;

        /// <summary>开启本地 MCP 服务器，让 WorkBuddy / Claude Code / Cursor 等 MCP 客户端来玩（只监听本机 127.0.0.1）。</summary>
        public bool EnableMcp { get; set; } = true;

        /// <summary>
        /// 允许 MCP 客户端用 toggle_ai 启动内置 AI（默认只能停）。内置 AI 是另一个 AI，会接管游戏、花玩家自己的 API 额度，
        /// MCP 那边的模型不该顺手把它打开；只有无人值守、想让外部脚本启动它的人才需要打开。
        /// </summary>
        public bool McpCanStartAi { get; set; } = false;

        /// <summary>MCP 服务器端口，地址为 http://127.0.0.1:端口/mcp。</summary>
        public int McpPort { get; set; } = 18080;

        /// <summary>MCP 客户端在思考（两次调用之间）时冻结游戏时间。超过 McpIdleSeconds 没有调用就恢复走时。</summary>
        public bool McpFreezeTime { get; set; } = true;

        public int McpIdleSeconds { get; set; } = 120;

        /// <summary>MCP 客户端超过 McpIdleSeconds 没有调用（AI 停下或断开）时把整个游戏暂停（怪物、时钟都停），按任意键接手或 AI 再次调用时继续。</summary>
        public bool PauseWhenAiStops { get; set; } = true;

        /// <summary>每次游玩最多玩几个游戏日（睡一觉算一天，默认 3；0 = 不限），到了就让 AI 停下汇报。与 SessionMinutes 先到哪个先停。读档后重新计。</summary>
        public int SessionDays { get; set; } = 3;

        /// <summary>每次游玩最多玩多少现实分钟（从这次第一个动作开始算，默认 60；0 = 不限），到了就让 AI 回家睡觉存档后停下。与 SessionDays 先到哪个先停。</summary>
        public int SessionMinutes { get; set; } = 60;
    }
}
