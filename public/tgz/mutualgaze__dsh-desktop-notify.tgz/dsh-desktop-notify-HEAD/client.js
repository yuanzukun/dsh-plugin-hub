/**
 * dsh-desktop-notify —— 客户端半（浏览器 module table 里的 lazy factory）
 *
 * 只做三件小事：
 *   1. 从宿主半取「提醒」（SSE 优先，轮询兜底；两条通道都按 id 去重）；
 *   2. 用 HTML5 Notification 弹出 Windows 通知（标题 / 正文 / 点击）；
 *   3. 用户点通知或切回窗口时，请宿主半把窗口提到前台、并把任务栏点熄掉。
 *
 * 判定逻辑一点都不放这里：客户端拿不到「上一轮为什么结束」，宿主半的
 * approval/request、api-session/status、agent/error 才覆盖所有会话。
 *
 * 页面里的 fetch 用**文档相对**路径（不带前导斜杠）：桌面端页面是 dsh-app://app/，
 * 非静态路径由 shell 同源转发到宿主；Web 端页面带 base href，相对路径落在部署前缀下。
 *
 * 注意两个 Electron/Chromium 的坑（沿用社区实测结论）：
 *   - Windows toast 会忽略 Notification 的 icon，用应用（AUMID 快捷方式）的图标；
 *   - `tag` 超过约 16 个字符会被静默丢弃，所以这里用 'dsn' + 12 位十六进制。
 */

window.__ModuleLoader__.load({
  id: 'dsh-desktop-notify',
  factory() {
    const PREFIX = 'dsh-desktop-notify'
    const HEADER = 'x-dsh-desktop-notify'
    const POLL_MS = 5000
    const MAX_SEEN = 200

    /** 用 FNV-1a 把事件 id 折成 12 位十六进制，拼出不超过 16 字符的 tag。 */
    function tagOf(id) {
      let hash = 0x811c9dc5
      const raw = String(id)
      for (let i = 0; i < raw.length; i += 1) {
        hash ^= raw.charCodeAt(i)
        hash = (hash * 0x01000193) >>> 0
      }
      return `dsn${hash.toString(16).padStart(8, '0')}${(hash >>> 0).toString(16).slice(0, 4)}`.slice(0, 16)
    }

    /** 只从 id 的哈希里凑长度不够稳定，这里直接补足到 12 位十六进制。 */
    function stableTag(id) {
      let hash = 0x811c9dc5
      const raw = String(id)
      for (let i = 0; i < raw.length; i += 1) {
        hash ^= raw.charCodeAt(i)
        hash = Math.imul(hash, 0x01000193) >>> 0
      }
      let second = 0x9e3779b9
      for (let i = raw.length - 1; i >= 0; i -= 1) {
        second ^= raw.charCodeAt(i)
        second = Math.imul(second, 0x85ebca6b) >>> 0
      }
      const hex = `${hash.toString(16).padStart(8, '0')}${second.toString(16).padStart(8, '0')}`
      return `dsn${hex.slice(0, 12)}`
    }

    return {
      inject: ['uiWorkspace'],
      apply(ctx) {
        /** 客户端半的版本号：改代码时递增，/ping 里能看出页面加载的到底是不是新代码。 */
        const CLIENT_VERSION = 'v20'
        /**
         * 切会话服务（uiWorkspace）是懒注入的：用 ctx.inject 等它出现，
         * 不写进 inject:[]，免得服务缺失时把整个客户端插件卡死。
         */
        let workspace = null
        let injectFired = false
        try {
          ctx.inject(['uiWorkspace'], (scope) => {
            injectFired = true
            workspace = scope.uiWorkspace ?? null
            scope.effect(() => () => {
              workspace = null
            })
          })
        } catch {
          /* 老版本壳没有注入能力：退化成只提窗 */
        }
        /** 已处理过的最大事件 id；-1 表示还没和宿主对过游标。 */
        let cursor = -1
        /** 最近一次收起卡片的时刻；用来挡掉 Windows 收回卡片时的焦点回弹。 */
        let lastDismissAt = 0
        /** 收起卡片后的静默期（毫秒）。 */
        const ACK_QUIET_MS = 1500
        /** 最近一次「窗口失焦」的时刻；用来分辨「用户真的切回来」和焦点回弹。 */
        let lastBlurAt = 0
        /** 离开窗口至少要这么久，focus 才算用户主动回来（毫秒）。 */
        const REAL_RETURN_MS = 2000
        /** 有没有「弹出来了、但用户还没看过」的提醒。 */
        let dirty = false
        /** 已经弹过/见过的 id（SSE 和轮询可能同时送同一条）。 */
        const seen = new Set()
        /** 宿主半自己会用可点击通知弹的类别（/state 的 hostKinds），这里别重复弹。 */
        let hostKinds = new Set()
        /** 最近一次处理的「去回复」时间戳，避免 SSE 与轮询重复切。 */
        let lastFocusAt = 0
        try {
          const probe = { injectFired: injectFired };
          const put = (key, fn) => {
            try {
              probe[key] = fn();
            } catch (err) {
              probe[key] = 'ERR ' + String(err && err.message ? err.message : err).slice(0, 60);
            }
          };
          put('get', () => typeof ctx.get);
          put('inject', () => typeof ctx.inject);
          put('wsProp', () => typeof ctx.uiWorkspace);
          put('wsGet', () => {
            const got = typeof ctx.get === 'function' ? ctx.get('uiWorkspace') : undefined;
            return got === null ? 'null' : typeof got;
          });
          put('wsKind', () => Object.prototype.toString.call(ctx.uiWorkspace));
          put('wsOwn', () => Object.keys(ctx.uiWorkspace || {}).slice(0, 40));
          put('wsProto', () => {
            const proto = Object.getPrototypeOf(ctx.uiWorkspace) || {};
            return Object.getOwnPropertyNames(proto).slice(0, 40);
          });
          put('wsCandidates', () => {
            const ws = ctx.uiWorkspace || {};
            const out = {};
            ['openSession', 'open', 'reveal', 'navigate', 'show', 'focus', 'select', 'activate'].forEach((name) => {
              try {
                out[name] = typeof ws[name];
              } catch (err) {
                out[name] = 'ERR';
              }
            });
            return out;
          });
          put('keys', () => Object.keys(ctx || {}).slice(0, 40));
          put('win', () => Object.keys(window).filter((k) => /dsh|router|nav|workspace/i.test(k)).slice(0, 20));
          report({ stage: 'ctx-probe', probe: probe });
        } catch (err) {
          report({ stage: 'ctx-probe-fail', error: String(err).slice(0, 120) });
        }
        let disposed = false
        let pollTimer = null
        /** 同一时刻只允许一轮 poll：focus / visibilitychange 可能连发两次 kickPoll。 */
        let pollInFlight = false
        /** 轮询进行中又来了 kickPoll：这一轮结束后立刻补跑一次，不叠两圈定时器。 */
        let pollQueued = false
        let source = null
        let streamErrors = 0

        function markSeen(id) {
          seen.add(id)
          if (seen.size > MAX_SEEN) {
            const first = seen.values().next()
            if (!first.done) seen.delete(first.value)
          }
        }

        /** 页面是不是正被用户看着——看着就不弹 toast（应用里的卡片已经足够）。 */
        /** 当前页面地址里带的会话 id（DSH 的会话 id 是 UUID）；拿不到就返回 null。 */
      function urlSessionId() {
        try {
          const hit = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i.exec(String(location.href))
          return hit === null ? null : hit[0].toLowerCase()
        } catch {
          return null
        }
      }

      function isWatching() {
          try {
            return document.visibilityState === 'visible' && document.hasFocus()
          } catch {
            return false
          }
        }

        function post(action, body) {
          try {
            return fetch(`${PREFIX}/${action}`, {
              method: 'POST',
              keepalive: true,
              cache: 'no-store',
              headers: { [HEADER]: '1', 'content-type': 'application/json' },
              body: JSON.stringify(body ?? {}),
            })
          } catch {
            return Promise.reject(new Error('fetch failed'))
          }
        }

        function raiseWindow() {
          post('raise').catch(() => {})
        }

        /** 上报一条诊断（这条通知到底弹出来没有、为什么没弹）。 */
        function report(payload) {
          try {
            post('report', payload).catch(() => {})
          } catch {
            /* 上报失败不影响主流程 */
          }
        }

        function acknowledge(reason = 'unknown') {
          dirty = false
          report({ stage: 'ack', reason })
          post('ack').catch(() => {})
        }

        /** 没人点的话，通知几秒后自己收起（点过的立刻收起）。 */
        const AUTO_CLOSE_MS = 6000

        function show(event) {
          if (typeof Notification !== 'function') {
            report({ stage: 'no-api', id: event.id })
            return
          }
          const permission = Notification.permission
          if (permission === 'denied') {
            report({ stage: 'denied', id: event.id, permission })
            return
          }
          let toast
          try {
            toast = new Notification(event.title || 'DeepSeek Harness', {
              body: event.body || '',
              tag: stableTag(event.id),
              silent: false,
              // 不强制常驻：没人点的话几秒后自己消失（AUTO_CLOSE_MS）。
              requireInteraction: false,
            })
          } catch (error) {
            report({
              stage: 'construct-failed',
              id: event.id,
              kind: event.kind,
              permission,
              error: String(error),
            })
            return
          }
          let closeTimer = null
          function clearCloseTimer() {
            if (closeTimer !== null) {
              clearTimeout(closeTimer)
              closeTimer = null
            }
          }
          function dismiss(reason) {
            clearCloseTimer()
            lastDismissAt = Date.now()
            try {
              toast.close()
            } catch {
              /* 已经关了 */
            }
            if (reason === 'auto') report({ stage: 'auto-closed', id: event.id })
          }
          report({ stage: 'constructed', id: event.id, kind: event.kind, permission })
          toast.onshow = () => {
            report({ stage: 'shown', id: event.id, kind: event.kind, permission })
            if (closeTimer === null) closeTimer = setTimeout(() => dismiss('auto'), AUTO_CLOSE_MS)
          }
          toast.onerror = () => report({ stage: 'failed', id: event.id, kind: event.kind, permission })
          toast.onclose = () => {
            clearCloseTimer()
            report({ stage: 'closed', id: event.id })
          }
          toast.onclick = () => {
            report({ stage: 'clicked', id: event.id })
            dismiss('click')
            // 点过就算看过了：让宿主把这批提醒标成已读，任务栏徽标随之熄灭。
            acknowledge('toast-click')
            raiseWindow()
          }
        }

        /** 处理一批提醒：看见的就弹，正在看的就直接 ack 掉。 */
        function accept(list) {
          let watched = false
          for (const event of list) {
            if (event === null || typeof event !== 'object') continue
            const id = typeof event.id === 'number' ? event.id : null
            if (id === null) continue
            if (id <= cursor && seen.has(id)) continue
            if (seen.has(id)) {
              cursor = Math.max(cursor, id)
              continue
            }
            markSeen(id)
            cursor = Math.max(cursor, id)
            // 自测提醒（event.test）例外：即使用户正看着窗口也弹，方便验证链路。
            // 需要你拍板的提醒（审批/提问）永远弹：你人可能在 DSH 里看着别的会话。
            const blocking = event.kind === 'approval' || event.kind === 'question'
            if (isWatching() && !blocking && event.test !== true) {
              watched = true
              continue
            }
            // 宿主半已经用带按钮的 Windows 通知弹过这一类（/state 的 hostKinds）：别重复弹。
            if (hostKinds.has(event.kind) && event.test !== true) continue
            dirty = true
            show(event)
          }
          if (watched) acknowledge('watching')
        }

        /** 回到窗口时立刻汇报一次 focused，让宿主马上撤气泡，不等下一轮 5 秒轮询。 */
        function kickPoll() {
          try {
            if (disposed) return
            if (pollTimer !== null) {
              window.clearTimeout(pollTimer)
              pollTimer = null
            }
            poll()
          } catch {
            /* 忽略 */
          }
        }

        async function poll() {
          if (disposed) return
          // 并发保护：两轮 poll 各开一个 5 秒定时器，轮询会越滚越多。
          if (pollInFlight) {
            pollQueued = true
            return
          }
          pollInFlight = true
          try {
            const response = await fetch(`${PREFIX}/state`, {
              method: 'POST',
              cache: 'no-store',
              headers: { [HEADER]: '1', 'content-type': 'application/json' },
              body: JSON.stringify({ since: cursor, focused: document.visibilityState === 'visible' && document.hasFocus() }),
            })
            if (response.ok) {
              const data = await response.json()
              // 宿主半声明它自己会弹哪些类别（带按钮的 Windows 通知），用来去重。
              if (Array.isArray(data?.hostKinds)) hostKinds = new Set(data.hostKinds.map(String))
              if (data?.focus) focusSession(data.focus)
              report({ stage: 'poll', since: cursor, ok: true, ids: Array.isArray(data?.events) ? data.events.map((e) => (e && typeof e.id === 'number' ? e.id : null)) : null })
              if (cursor < 0) {
                // 刚加载：只对游标，不回放历史，免得一打开页面刷出一堆旧提醒。
                cursor = Number.isInteger(data?.cursor) ? data.cursor : 0
                if (Array.isArray(data?.events)) accept(data.events)
              } else if (Array.isArray(data?.events)) {
                accept(data.events)
              }
            }
          } catch {
            report({ stage: 'poll-error' })
            /* 宿主半没加载 / 网络抖动：下一轮再试 */
          } finally {
            pollInFlight = false
          }
          if (disposed) return
          pollTimer = window.setTimeout(poll, pollQueued ? 0 : POLL_MS)
          pollQueued = false
        }

        /**
         * 气泡已经替用户做了决定，就把宿主应用里同一张审批卡片按对应按钮点掉。
         * DSH 客户端的卡片是它自己的本地等待，没有远程关闭接口；这里只做一次
         * 「文本唯一命中 + 按钮可用」的保守点击，命中不了就什么都不做。
         */
        /**
         * 宿主半发来「去回复」：把主视图切到对应会话。
         * 用 uiWorkspace.openSession——它既保留会话又显示对话，是壳里唯一的导航动作。
         */
        function focusSession(payload) {
          const sessionId = typeof payload?.sessionId === 'string' ? payload.sessionId : ''
          const at = Number(payload?.at)
          if (sessionId === '' || !Number.isFinite(at) || at <= lastFocusAt) return
          lastFocusAt = at
          try {
            const tries = [
              () => ctx.uiWorkspace,
              () => (typeof ctx.get === 'function' ? ctx.get('uiWorkspace') : null),
              () => workspace,
            ]
            let target = null
            for (const get of tries) {
              try {
                const value = get()
                if (value) {
                  target = value
                  break
                }
              } catch {
                /* 未声明注入的服务会抛错，换下一个来源 */
              }
            }
            if (target && typeof target.openSession === 'function') {
              try {
                target.openSession(sessionId)
                report({ stage: 'focus-open', id: sessionId.slice(0, 40) })
                return
              } catch (err) {
                report({
                  stage: 'focus-call-failed',
                  id: sessionId.slice(0, 40),
                  error: String(err && err.message ? err.message : err).slice(0, 160),
                })
                return
              }
            }
          } catch {
            /* 服务不可用：退化成只提窗 */
          }
          report({ stage: 'focus-unavailable', id: sessionId.slice(0, 40) })
        }

        function dismissQuestionCard(payload) {
          const match = typeof payload?.match === 'string' ? payload.match.trim() : ''
          const label = typeof payload?.label === 'string' ? payload.label.trim() : ''
          if (match === '' || label === '') return
          const norm = (value) => String(value ?? '').replace(/\s+/g, ' ').trim()
          const textOf = (node) => norm(node.textContent)
          let cards = []
          try {
            cards = Array.from(document.querySelectorAll('div,section,article,li')).filter((node) => {
              if (!textOf(node).includes(match)) return false
              return Array.from(node.querySelectorAll('button')).some((b) => textOf(b).includes('提交'))
            })
            cards.sort((a, b) => textOf(a).length - textOf(b).length)
          } catch {
            return
          }
          const card = cards[0]
          if (card === undefined) {
            report({ stage: 'question-ui-dismiss-miss', why: 'no-card', match: match.slice(0, 24) })
            return
          }
          let cands = []
          try {
            cands = Array.from(card.querySelectorAll('button,[role="button"],[role="radio"],li,label,div'))
              .filter((node) => {
                const body = textOf(node)
                return body !== '' && body.includes(label)
              })
              .sort((a, b) => textOf(a).length - textOf(b).length)
          } catch {
            return
          }
          if (cands.length === 0) {
            report({ stage: 'question-ui-dismiss-miss', why: 'no-option', label: label.slice(0, 16) })
            return
          }
          // 最内层点一次，它的父级再点一次：不同版本把点击处理器挂在不同层级
          for (const node of cands.slice(0, 2)) {
            try {
              node.click()
              if (node.parentElement && node.parentElement !== card) node.parentElement.click()
            } catch {
              /* 继续 */
            }
          }
          const trySubmit = (attempt) => {
            let buttons = []
            try {
              buttons = Array.from(card.querySelectorAll('button'))
            } catch {
              return
            }
            const submit = buttons.find((b) => textOf(b).includes('提交') && b.disabled !== true)
            if (submit !== undefined) {
              submit.click()
              report({ stage: 'question-ui-dismiss', label: label.slice(0, 16), attempt })
              return
            }
            if (attempt < 3) {
              setTimeout(() => trySubmit(attempt + 1), 350)
              return
            }
            report({
              stage: 'question-ui-dismiss-miss',
              why: 'no-submit',
              buttons: buttons.slice(0, 6).map((b) => textOf(b).slice(0, 8) + (b.disabled === true ? '(x)' : '')),
            })
          }
          setTimeout(() => trySubmit(1), 350)
        }

        function dismissApprovalCard(payload) {
          const match = typeof payload?.match === 'string' ? payload.match.trim() : ''
          if (match === '') return
          let cards = []
          try {
            cards = Array.from(document.querySelectorAll('[data-approval-key]'))
          } catch {
            return
          }
          const hits = cards.filter((node) => (node.textContent ?? '').includes(match))
          if (hits.length !== 1) return
          const card = hits[0]
          const wanted =
            payload.decision === 'deny' ? /^(拒绝|reject)/i : /^(允许一次|允许|allow once|allow)/i
          let target = null
          for (const node of Array.from(card.querySelectorAll('button'))) {
            const label = (node.textContent ?? '').trim()
            if (node.disabled) continue
            if (wanted.test(label)) {
              target = node
              break
            }
          }
          if (target === null) return
          target.click()
          report({ stage: 'ui-dismiss', decision: String(payload.decision ?? '') })
        }

        function openStream() {
          if (typeof EventSource !== 'function') return
          try {
            source = new EventSource(`${PREFIX}/events?v=${CLIENT_VERSION}`)
          } catch {
            source = null
            return
          }
          source.addEventListener('hello', (message) => {
            streamErrors = 0
            report({ stage: 'hello' })
            try {
              const data = JSON.parse(message.data)
              if (cursor < 0 && Number.isInteger(data?.cursor)) cursor = data.cursor
            } catch {
              /* 忽略坏帧 */
            }
          })
          source.addEventListener('focus', (message) => {
            try {
              focusSession(JSON.parse(message.data))
            } catch {
              /* 忽略坏帧 */
            }
          })
          source.addEventListener('ui-dismiss-question', (message) => {
            try {
              dismissQuestionCard(JSON.parse(message.data))
            } catch {
              /* 忽略坏帧 */
            }
          })
          source.addEventListener('ui-dismiss', (message) => {
            try {
              dismissApprovalCard(JSON.parse(message.data))
            } catch {
              /* 忽略坏帧 */
            }
          })
          source.addEventListener('alert', (message) => {
            try {
              report({ stage: 'sse', raw: String(message.data).slice(0, 60) })
              accept([JSON.parse(message.data)])
            } catch {
              /* 忽略坏帧 */
            }
          })
          source.onerror = () => {
            streamErrors += 1
            // 连续失败就放弃 SSE，只留轮询（自定义协议转发不支持长连接时就是这样）。
            if (streamErrors >= 3 && source !== null) {
              try {
                source.close()
              } catch {
                /* 已经关了 */
              }
              source = null
            }
          }
        }

        // 在窗口里随便点一下也算「人回来了」：熄掉还没看过的提醒。
        const onPointerDown = () => {
          if (!disposed && dirty) acknowledge('pointer')
        }

        // 用户切回窗口（点任务栏图标 / Alt-Tab）：把任务栏徽标熄掉。
        //
        // 但要挡掉一种假信号：Windows 把通知卡片收走时，偶尔会把焦点「还」回来一次，
        // 那不是用户在点。收卡片后 1.5 秒内的 focus / visibility 一律不算。
        const justDismissed = () => Date.now() - lastDismissAt < ACK_QUIET_MS
        const onFocus = () => {
          if (disposed) return
          if (justDismissed()) {
            report({ stage: 'focus-skip', why: 'dismiss', since: Date.now() - lastDismissAt })
            return
          }
          // 必须是真的离开过一段时间才算了「回来了」；否则是 Windows 弹/收卡片时的焦点回弹。
          const away = Date.now() - lastBlurAt
          if (away < REAL_RETURN_MS) {
            report({ stage: 'focus-skip', why: 'bounce', away })
            return
          }
          acknowledge('focus')
          kickPoll()
        }
        const onBlur = () => {
          lastBlurAt = Date.now()
        }
        const onVisible = () => {
          if (disposed) return
          if (document.visibilityState !== 'visible') return
          if (justDismissed()) return
          acknowledge('visible')
          kickPoll()
        }

        try {
          window.addEventListener('focus', onFocus)
          window.addEventListener('blur', onBlur)
          document.addEventListener('visibilitychange', onVisible)
          window.addEventListener('pointerdown', onPointerDown, true)
        } catch {
          /* 忽略 */
        }

        openStream()
        poll()
        report({ stage: 'beacon', version: CLIENT_VERSION, href: String(location.href).slice(0, 260), focus: isWatching() })

        const cleanup = () => {
          disposed = true
          if (pollTimer !== null) {
            window.clearTimeout(pollTimer)
            pollTimer = null
          }
          if (source !== null) {
            try {
              source.close()
            } catch {
              /* 已经关了 */
            }
            source = null
          }
          try {
            window.removeEventListener('focus', onFocus)
            window.removeEventListener('blur', onBlur)
            document.removeEventListener('visibilitychange', onVisible)
          } catch {
            /* 忽略 */
          }
        }
        try {
          ctx?.effect?.(() => cleanup)
        } catch {
          /* 没有 effect 也照常工作，只是卸载时不清理 */
        }
        return cleanup
      },
    }
  },
})
// hmr touch 2026-11-15T16:53:37.1632425+08:00
// hmr touch 2026-11-15T16:55:34.7485173+08:00
// hmr touch 2026-11-15T16:57:04.3969306+08:00
