/**
 * 版本化的插件入口 —— 只为了绕开 DSH 的 ESM 模块缓存。
 *
 * DSH 重载插件（disable/enable、remove+install）都不会重新求值已经进过缓存的
 * 入口模块 URL，所以直接改 index.js 之后必须换一个新 URL 才会生效。
 *
 * 做法：每次改完 index.js / lib 之后
 *   1. 把本文件里的 ?rev=N 加一；
 *   2. 复制成下一个文件名（entry-3.js、entry-4.js …）；
 *   3. 把 package.json 的 exports["."] 指过去。
 */
export * from './index.js?rev=2'