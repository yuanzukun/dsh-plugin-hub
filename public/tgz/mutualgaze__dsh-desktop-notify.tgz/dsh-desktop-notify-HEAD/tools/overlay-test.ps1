# 独立验证：任务栏覆盖图标（与 lib/raise-window.js 里 worker 用的同一套 C#）
# 用法：powershell.exe -NoProfile -ExecutionPolicy Bypass -File .tmp-overlay-test.ps1 -TargetPid 36800 -Seconds 12
param(
  [int]$TargetPid = 36800,
  [int]$Seconds = 12
)
$ErrorActionPreference = 'Stop'

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;

[ComImport, Guid("56FDF344-FD6D-11d0-958A-006097C9A090")]
public class DshTaskbarListCoClass { }

[ComImport, Guid("ea1afb91-9e28-4b86-90e9-9e9f8a5eefaf"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IDshTaskbarList3 {
  [PreserveSig] int HrInit();
  [PreserveSig] int AddTab(IntPtr hwnd);
  [PreserveSig] int DeleteTab(IntPtr hwnd);
  [PreserveSig] int ActivateTab(IntPtr hwnd);
  [PreserveSig] int SetActiveAlt(IntPtr hwnd);
  [PreserveSig] int MarkFullscreenWindow(IntPtr hwnd, [MarshalAs(UnmanagedType.Bool)] bool fFullscreen);
  [PreserveSig] int SetProgressValue(IntPtr hwnd, ulong ullCompleted, ulong ullTotal);
  [PreserveSig] int SetProgressState(IntPtr hwnd, int tbpFlags);
  [PreserveSig] int RegisterTab(IntPtr hwndTab, IntPtr hwndMDI);
  [PreserveSig] int UnregisterTab(IntPtr hwndTab);
  [PreserveSig] int SetTabOrder(IntPtr hwndTab, IntPtr hwndInsertBefore);
  [PreserveSig] int SetTabActive(IntPtr hwndTab, IntPtr hwndMDI, uint dwReserved);
  [PreserveSig] int ThumbBarAddButtons(IntPtr hwnd, uint cButtons, IntPtr pButtons);
  [PreserveSig] int ThumbBarUpdateButtons(IntPtr hwnd, uint cButtons, IntPtr pButtons);
  [PreserveSig] int ThumbBarSetImageList(IntPtr hwnd, IntPtr himl);
  [PreserveSig] int SetOverlayIcon(IntPtr hwnd, IntPtr hIcon, [MarshalAs(UnmanagedType.LPWStr)] string pszDescription);
  [PreserveSig] int SetThumbnailTooltip(IntPtr hwnd, [MarshalAs(UnmanagedType.LPWStr)] string pszTip);
  [PreserveSig] int SetThumbnailClip(IntPtr hwnd, IntPtr prcClip);
}

public class DshWinRaise {
  [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);
  [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll")] private static extern int GetWindowTextLength(IntPtr hWnd);
  [DllImport("user32.dll")] private static extern IntPtr GetWindow(IntPtr hWnd, uint uCmd);
  [DllImport("user32.dll")] private static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);

  private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
  private static IntPtr found;
  private static uint wanted;

  public static IntPtr Find(uint pid) {
    wanted = pid;
    found = IntPtr.Zero;
    EnumWindows(new EnumWindowsProc(Visit), IntPtr.Zero);
    return found;
  }

  private static bool Visit(IntPtr hWnd, IntPtr lParam) {
    uint pid;
    GetWindowThreadProcessId(hWnd, out pid);
    if (pid != wanted) return true;
    if (GetWindow(hWnd, 4) != IntPtr.Zero) return true;
    if (GetWindowTextLength(hWnd) == 0) return true;
    if (IsWindowVisible(hWnd)) { found = hWnd; return false; }
    if (found == IntPtr.Zero) found = hWnd;
    return true;
  }

  public static bool SetOverlay(uint pid, IntPtr hicon, string description) {
    IntPtr target = Find(pid);
    if (target == IntPtr.Zero) return false;
    try {
      IDshTaskbarList3 list = (IDshTaskbarList3)new DshTaskbarListCoClass();
      if (list.HrInit() != 0) return false;
      return list.SetOverlayIcon(target, hicon, description ?? "") == 0;
    } catch {
      return false;
    }
  }
}
'@

Add-Type -AssemblyName System.Drawing
$bmp = New-Object System.Drawing.Bitmap 32, 32
$g = [System.Drawing.Graphics]::FromImage($bmp)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.Clear([System.Drawing.Color]::Transparent)
$ring = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::White)
$g.FillEllipse($ring, 1, 1, 30, 30)
$brush = New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml('#F5A524'))
$g.FillEllipse($brush, 4, 4, 24, 24)
$g.Dispose()
$icon = $bmp.GetHicon()

$hwnd = [DshWinRaise]::Find([uint32]$TargetPid)
"HWND=$hwnd"
$ok = [DshWinRaise]::SetOverlay([uint32]$TargetPid, $icon, 'DeepSeek Harness test')
"SET=$ok"
Start-Sleep -Seconds $Seconds
[void][DshWinRaise]::SetOverlay([uint32]$TargetPid, [IntPtr]::Zero, '')
"CLEARED"
