﻿<#
.SYNOPSIS
  弹出一条 Windows 11 toast：标题 + 正文 + 三个决策按钮 + 一个「去回复」按钮。

  注意（已实测）：activationType="protocol" 的 toast 不会把文本输入框的内容带进
  协议 URI（hint-inputId 在、用户也确实输入了，URI 里依然没有文本），所以这里
  **不放 input**。「去回复」只表示「用户想回复」，由后端把 DSH 窗口提到前台，
  用户在聊天输入框里回。

.DESCRIPTION
  只用纯 PowerShell 加载 WinRT（不依赖 Add-Type 编译，本沙箱里 Add-Type 会报
  "A required privilege is not held by the client"）：

      [Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType=WindowsRuntime]

  交互全部通过 activationType="protocol" 走 dsh-notify 协议：
      允许          -> dsh-notify://action?action=allow&id=<id>
      本次会话允许  -> dsh-notify://action?action=allow-session&id=<id>
      拒绝          -> dsh-notify://action?action=deny&id=<id>
      去回复        -> dsh-notify://action?action=reply&id=<id>
      点正文        -> dsh-notify://show?id=<id>
  由 install.ps1 注册的协议命令把 URI 交给 launch-handler.vbs（隐藏窗口）→ handler.ps1
  → POST http://127.0.0.1:45917/action。

.PARAMETER Wait
  **仅排障用**（别名 -S）：显示后保持进程存活，注册进程内 Activated / Dismissed 事件：
    - Activated 时把 UserInput 里的回复文本写进 logs\toast-<id>.result.json；
    - Dismissed 时写 decision=dismissed；
    - 超时写 decision=timeout。
  注意：协议激活下这里**拿不到回复文本**（已实测），且会挂住控制台最长 180 秒；
  js/backends/windows.js 已**不再**传 -Wait，dismissed/timeout 由 Node 侧超时判定。

.PARAMETER NoReply
  不要「去回复」按钮。任一 -NoAllow/-NoSessionAllow/-NoDeny 可隐藏对应按钮。

.PARAMETER PlainText
  纯文本降级：不要任何按钮（注册项写失败时，后端用它弹一条只能看、不能点的通知）。

.EXAMPLE
  .\show-toast.ps1 -Id demo-allow-1

.EXAMPLE
  .\show-toast.ps1 -Title '[测试] 需要确认' -Body '是否允许执行？' -Id evt-001

.EXAMPLE
  .\show-toast.ps1 -Clear        # 清空本 AUMID 的通知中心历史
#>
[CmdletBinding()]
param(
  [string]$Title = '[测试] DSH 需要你的确认',
  [string]$Body = '是否允许把这次改动写入工作区？',
  [string]$Id = '',
  [string]$AppId = 'DshDesktopNotifyLab',
  [string]$Attribution = '',
  [string]$Logo = '',
  [string]$Hint = '',
  [string]$AllowText = '允许',
  [string]$SessionAllowText = '本次会话允许',
  [string]$DenyText = '拒绝',
  [string]$ReplyText = '去回复',
    [string]$Choices = '',
  [switch]$NoAllow,
  [switch]$NoSessionAllow,
  [switch]$NoDeny,
  [switch]$NoReply,
  [switch]$PlainText,
  [string]$Tag = '',
  [string]$Group = 'lab',
  [Alias('S')]
  [switch]$Wait,
  [int]$WaitSeconds = 30,
  [switch]$Clear,
  [switch]$DryRun
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$logDir = Join-Path $root 'logs'
if (-not (Test-Path -LiteralPath $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$logPath = Join-Path $logDir 'show-toast.log'
$utf8 = New-Object System.Text.UTF8Encoding($false)

if (-not $Id) { $Id = 'evt-' + (Get-Date -Format 'yyyyMMdd-HHmmss') }
if (-not $Tag) { $Tag = $Id }
$safeId = ($Id -replace '[^A-Za-z0-9._-]', '_')
$resultPath = Join-Path $logDir ("toast-{0}.result.json" -f $safeId)

function Write-Log([string]$Message) {
  $line = ('[{0}] {1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $Message)
  [System.IO.File]::AppendAllText($logPath, $line + "`r`n", $utf8)
  Write-Host $line
}

function Write-Result([string]$Decision, [string]$Text, [string]$Argument, [string]$UserInput) {
  $obj = [ordered]@{
    id        = $Id
    decision  = $Decision
    text      = $Text
    argument  = $Argument
    userInput = $UserInput
    at        = (Get-Date).ToString('o')
  }
  [System.IO.File]::WriteAllText($resultPath, ($obj | ConvertTo-Json -Compress -Depth 4), $utf8)
  Write-Host ("RESULT decision={0}" -f $Decision)
}

function Esc([string]$s) {
  if ($null -eq $s) { return '' }
  return $s.Replace('&', '&amp;').Replace('<', '&lt;').Replace('>', '&gt;').Replace('"', '&quot;').Replace("'", '&apos;')
}

# ---------- 1) 拼 toast XML ----------
$idPart = [uri]::EscapeDataString($Id)
$allowUri = "dsh-notify://action?action=allow&id=$idPart"
$sessionUri = "dsh-notify://action?action=allow-session&id=$idPart"
$denyUri = "dsh-notify://action?action=deny&id=$idPart"
$replyUri = "dsh-notify://action?action=reply&id=$idPart"
$launchUri = "dsh-notify://show?id=$idPart"

$actionLines = New-Object System.Collections.Generic.List[string]
if ($PlainText) {
  # 降级：一条只能看、不能点的通知（AUMID / 协议注册写失败时用）。
} else {
  if (-not $NoAllow) {
    $actionLines.Add(('    <action content="{0}" activationType="protocol" arguments="{1}" />' -f (Esc $AllowText), (Esc $allowUri)))
  }
  if (-not $NoSessionAllow) {
    $actionLines.Add(('    <action content="{0}" activationType="protocol" arguments="{1}" />' -f (Esc $SessionAllowText), (Esc $sessionUri)))
  }
  if (-not $NoDeny) {
    $actionLines.Add(('    <action content="{0}" activationType="protocol" arguments="{1}" />' -f (Esc $DenyText), (Esc $denyUri)))
  }
  if (-not $NoReply) {
    $actionLines.Add(('    <action content="{0}" activationType="protocol" arguments="{1}" />' -f (Esc $ReplyText), (Esc $replyUri)))
  }
}

  if ($Choices -ne '') {
    $choiceCount = 0
    foreach ($pair in ($Choices -split '\|')) {
      if ($choiceCount -ge 4) { break }
      $parts = $pair -split '~', 2
      if ($parts[0] -eq '') { continue }
      $choiceId = $parts[0]
      $choiceLabel = if ($parts.Length -gt 1 -and $parts[1] -ne '') { $parts[1] } else { $parts[0] }
      $choiceUri = 'dsh-notify://action/?action=option&id=' + [uri]::EscapeDataString($Id) + '&value=' + [uri]::EscapeDataString($choiceId)
      $actionLines.Add(('    <action content="{0}" activationType="protocol" arguments="{1}" />' -f (Esc $choiceLabel), (Esc $choiceUri)))
      $choiceCount++
    }
  }
$actionsXml = ''
if ($actionLines.Count -gt 0) {
  $actionsXml = "  <actions>`r`n" + ($actionLines -join "`r`n") + "`r`n  </actions>`r`n"
}

$logoXml = ''
if ($Logo -and (Test-Path -LiteralPath $Logo)) {
  $logoPath = (Resolve-Path -LiteralPath $Logo).Path
  $logoSrc = ([System.Uri]::new($logoPath)).AbsoluteUri
  $logoXml = "      <image placement=`"appLogoOverride`" src=`"$(Esc $logoSrc)`" hint-crop=`"none`"/>`r`n"
}

$hintXml = ''
if ($actionLines.Count -gt 0 -and -not $PlainText -and $Hint) {
  $hintXml = "      <text placement=`"subtle`">$(Esc $Hint)</text>`r`n"
}

$xml = @"
<?xml version="1.0" encoding="utf-8"?>
<toast launch="$(Esc $launchUri)" activationType="protocol" duration="long">
  <visual>
    <binding template="ToastGeneric">
$logoXml      <text>$(Esc $Title)</text>
      <text>$(Esc $Body)</text>
$hintXml
      <text placement="attribution">$(Esc $Attribution)</text>
    </binding>
  </visual>
$actionsXml</toast>
"@

$xmlPath = Join-Path $logDir ("toast-{0}.xml" -f $safeId)
[System.IO.File]::WriteAllText($xmlPath, $xml, $utf8)
Write-Log "toast id=$Id tag=$Tag xml=$xmlPath"

if ($DryRun) {
  Write-Host $xml
  return
}

# ---------- 2) 纯 PowerShell 加载 WinRT ----------
[void][Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
[void][Windows.UI.Notifications.ToastNotification, Windows.UI.Notifications, ContentType = WindowsRuntime]
[void][Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime]

$doc = New-Object Windows.Data.Xml.Dom.XmlDocument
try {
  $doc.LoadXml($xml)
} catch {
  Write-Log ('XML 解析失败：' + $_.Exception.Message)
  throw
}

try {
  $notifier = [Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier($AppId)
  Write-Log "CreateToastNotifier($AppId) ok"
} catch {
  $inner = $_.Exception.InnerException
  $hr = if ($inner) { $inner.HResult } else { $_.Exception.HResult }
  $msg = if ($inner) { $inner.Message } else { $_.Exception.Message }
  Write-Log ('CreateToastNotifier 失败：0x{0:X8} {1}' -f $hr, $msg)
  Write-Host ('ERROR CreateToastNotifier 0x{0:X8} {1}' -f $hr, $msg)
  exit 2
}

if ($Clear) {
  try {
    [Windows.UI.Notifications.ToastNotificationManager]::History.Clear($AppId)
    Write-Log "已清空 $AppId 的通知历史"
  } catch {
    Write-Log ('清空通知历史失败：' + $_.Exception.Message)
  }
  return
}

# Windows caps Tag/Group at 16 chars; longer values throw and silently kill the toast.
function ConvertTo-ShortToken([string]$value) {
  if ([string]::IsNullOrEmpty($value)) { return $null }
  if ($value.Length -le 16) { return $value }
  $sha = [System.Security.Cryptography.SHA1]::Create()
  try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($value)
    $hash = $sha.ComputeHash($bytes)
    return ((-join ($hash | ForEach-Object { $_.ToString('x2') })).Substring(0, 16))
  } finally {
    $sha.Dispose()
  }
}
$toast = [Windows.UI.Notifications.ToastNotification]::new($doc)
$safeTag = ConvertTo-ShortToken $Tag
try { if ($safeTag) { $toast.Tag = $safeTag } } catch { Write-Log ('Tag set failed: ' + $_.Exception.Message) }
$safeGroup = ConvertTo-ShortToken $Group
try { if ($safeGroup) { $toast.Group = $safeGroup } } catch { Write-Log ('Group set failed: ' + $_.Exception.Message) }

# ---------- 3) 显示 ----------
try {
  $notifier.Show($toast)
  Write-Log 'Show() ok'
  Write-Host 'SHOWN'
} catch {
  $inner = $_.Exception.InnerException
  $hr = if ($inner) { $inner.HResult } else { $_.Exception.HResult }
  $msg = if ($inner) { $inner.Message } else { $_.Exception.Message }
  Write-Log ('Show() 失败：0x{0:X8} {1}' -f $hr, $msg)
  Write-Host ('ERROR Show 0x{0:X8} {1}' -f $hr, $msg)
  exit 3
}

# ---------- 4) 可选：in-process 事件诊断 + result 文件 ----------
if ($Wait) {
  Write-Log "保持进程存活，最多 $WaitSeconds 秒，等待 in-process Activated / Dismissed…"
  $sigAct = "dsh-toast-act-$safeId"
  $sigDis = "dsh-toast-dis-$safeId"
  $subscribed = $false
  try {
    $null = Register-ObjectEvent -InputObject $toast -EventName Activated -SourceIdentifier $sigAct -ErrorAction Stop
    $null = Register-ObjectEvent -InputObject $toast -EventName Dismissed -SourceIdentifier $sigDis -ErrorAction Stop
    $subscribed = $true
    Write-Log '已注册进程内 Activated / Dismissed 事件'
  } catch {
    Write-Log '注册进程内事件失败（不影响协议回传，只影响 dismissed/timeout 判定）：' + $_.Exception.Message
  }

  $deadline = (Get-Date).AddSeconds($WaitSeconds)
  $ev = $null
  while ((Get-Date) -lt $deadline) {
    if ($subscribed) {
      $ev = Get-Event -ErrorAction SilentlyContinue | Where-Object { $_.SourceIdentifier -eq $sigAct -or $_.SourceIdentifier -eq $sigDis } | Select-Object -First 1
      if ($ev) { break }
    }
    Start-Sleep -Milliseconds 150
  }

  if ($ev) {
    if ($ev.SourceIdentifier -eq $sigAct) {
      $a = $ev.SourceEventArgs
      $argument = [string]$a.Argument
      $uiJson = ''
      $textOut = ''
      try {
        $pairs = @{}
        $enum = $a.UserInput.GetEnumerator()
        while ($enum.MoveNext()) {
          $k = [string]$enum.Current.Key
          $v = [string]$enum.Current.Value
          $pairs[$k] = $v
          if ($k -eq 'replyText' -or $k -eq 'text') { $textOut = $v }
        }
        if ($pairs.Count -gt 0) { $uiJson = ($pairs | ConvertTo-Json -Compress) }
      } catch {
        try { $uiJson = ($a.UserInput | ConvertTo-Json -Compress) } catch { $uiJson = '' }
      }

      $decision = 'allow'
      if ($argument -match 'action=([^&?#]+)') {
        $decision = [uri]::UnescapeDataString($matches[1])
      } elseif ($argument -match '^dsh-notify://([^/?#]+)') {
        $decision = $matches[1]
      }
      if (-not $decision) { $decision = 'allow' }

      Write-Log ('ACTIVATED argument={0} userInput={1}' -f $argument, $uiJson)
      Write-Host ('ACTIVATED argument={0} userInput={1}' -f $argument, $uiJson)
      Write-Result -Decision $decision -Text $textOut -Argument $argument -UserInput $uiJson
    } else {
      $a = $ev.SourceEventArgs
      Write-Log ('DISMISSED reason={0}' -f $a.Reason)
      Write-Host ('DISMISSED reason={0}' -f $a.Reason)
      Write-Result -Decision 'dismissed' -Text '' -Argument '' -UserInput ''
    }
    Get-Event -ErrorAction SilentlyContinue | Where-Object { $_.SourceIdentifier -eq $sigAct -or $_.SourceIdentifier -eq $sigDis } | Remove-Event -ErrorAction SilentlyContinue
  } else {
    Write-Log '等待超时（toast 既没被点也没被关，或事件订阅不可用）'
    Write-Result -Decision 'timeout' -Text '' -Argument '' -UserInput ''
  }

  Unregister-Event -SourceIdentifier $sigAct -ErrorAction SilentlyContinue
  Unregister-Event -SourceIdentifier $sigDis -ErrorAction SilentlyContinue
  Write-Log '等待结束'
}
