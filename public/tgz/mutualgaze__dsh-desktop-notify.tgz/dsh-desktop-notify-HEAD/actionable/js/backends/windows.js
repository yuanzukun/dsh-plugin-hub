/**
 * Windows 后端 —— lab 原型的真实实现。
 *
 * 链路（最小闭环）：
 *
 *   1. notify(req) 确保 AUMID + dsh-notify 协议已注册（首次自动写 HKCU，
 *      失败则降级成纯文本 toast，并在 /state 里记 degraded）；
 *   2. 起本机 HTTP 服务（默认 127.0.0.1:45917）；
 *   3. spawn powershell.exe show-toast.ps1（WinRT ToastNotificationManager），
 *      通知里带「允许 / 本次会话允许 / 拒绝 / 去回复」四个按钮；
 *   4. 用户点按钮 → Windows 协议激活 dsh-notify://… → wscript.exe →
 *      launch-handler.vbs → handler.ps1 → POST /action（带签名头）；
 *   5. 本文件收到事件后把 Promise resolve 成 NotifyResult：
 *        { decision:'allow' } / { decision:'allow-session' } / { decision:'deny' }
 *        { decision:'reply' }   ← 只表示「用户点了去回复」，本后端随后调 raiseWindow()
 *                                 把 DSH 窗口提到前台；拿不到文本（已实测：协议激活不携带
 *                                 input 内容，见 logs/toast-demo-reply-1.xml）
 *        { decision:'dismissed' } / { decision:'timeout' } / { decision:'unsupported' }
 *
 * 注意：
 *   - 不使用 show-toast.ps1 -Wait（那会让进程挂到超时；-Wait/-S 只留给排障）。
 *   - handler.ps1 的端口优先级：-Port > state/install.json.port > 45917。默认 45917，
 *     和 install.ps1 -Port 一致；mock-server.js 与后端不能同时监听同一端口。
 *   - 当前沙箱（受限令牌）里 HKCU 写与 CreateToastNotifier 都会失败，notify() 会返回
 *     unsupported 并保留 lastError；用户正常令牌下可用。
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { DECISIONS, ACTION_TO_DECISION, normalizeRequest, normalizeResult } from './contract.js';

const HERE = path.dirname(fileURLToPath(import.meta.url));
/** actionable/ 目录（js/backends 往上两级）。 */
const DEFAULT_ROOT = path.resolve(HERE, '..', '..');
const DEFAULT_PORT = 45917;
const DEFAULT_APP_ID = 'DshDesktopNotifyLab';
const DEFAULT_PROTOCOL = 'dsh-notify';
const REGISTER_RETRY_MS = 30_000;
const MAX_EVENTS = 200;
const MAX_BODY = 1024 * 1024;
/** 降级通知最多等多久（等它 Show 完就返回，不等点击）。 */
const DEGRADED_SHOW_TIMEOUT_MS = 8000;

/** @returns {string} 系统自带 PowerShell 5.1 的绝对路径。 */
export function defaultPowershellPath() {
  const systemRoot = process.env.SystemRoot || process.env.windir || 'C:\\Windows';
  return path.join(systemRoot, 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
}

function consoleLogger(scope) {
  return {
    info: (...args) => console.log(`[${scope}]`, ...args),
    warn: (...args) => console.warn(`[${scope}]`, ...args),
    error: (...args) => console.error(`[${scope}]`, ...args),
  };
}

function safeId(id) {
  return String(id).replace(/[^A-Za-z0-9._-]/g, '_');
}

/**
 * @param {Object} [options]
 * @param {number} [options.port=45917]        本机回传端口，必须与 install.ps1 的 -Port 一致
 * @param {string} [options.appId]             AUMID（默认 DshDesktopNotifyLab）
 * @param {string} [options.protocol]          协议名（默认 dsh-notify）
 * @param {string} [options.rootDir]           actionable/ 目录，默认由本文件位置推导
 * @param {string} [options.powershellPath]    powershell.exe 路径
 * @param {boolean} [options.autoRegister=true] 首次 notify 时自动写 HKCU（AUMID + 协议）
 * @param {string} [options.installScript]     install.ps1 路径（自动注册用）
 * @param {string} [options.showToastScript]   show-toast.ps1 路径
 * @param {string[]} [options.showToastCommand] 测试用：替换「powershell + show-toast.ps1」的完整命令
 * @param {() => boolean} [options.raise]      把 DSH 窗口提到前台的注入实现（缺省用 WScript.Shell AppActivate）
 * @param {Object} [options.logger]            { info, warn, error }
 * @returns {object} 后端实例
 */
export function createWindowsBackend(options = {}) {
  return new WindowsBackend(options);
}

class WindowsBackend {
  constructor(options = {}) {
    this.rootDir = path.resolve(options.rootDir || DEFAULT_ROOT);
    this.port = Number(options.port || DEFAULT_PORT);
    this.appId = options.appId || DEFAULT_APP_ID;
    this.protocol = options.protocol || DEFAULT_PROTOCOL;
    this.powershellPath = options.powershellPath || defaultPowershellPath();
    this.showToastScript = options.showToastScript || path.join(this.rootDir, 'show-toast.ps1');
    this.removeToastScript = options.removeToastScript || path.join(this.rootDir, 'remove-toast.ps1');
    this.installScript = options.installScript || path.join(this.rootDir, 'install.ps1');
    this.autoRegister = options.autoRegister !== false;
    this.showToastCommand = Array.isArray(options.showToastCommand) ? options.showToastCommand : null;
    this.raiseImpl = typeof options.raise === 'function' ? options.raise : null;
    this.log = options.logger || consoleLogger('windows-backend');

    /** @type {http.Server|null} */
    this.server = null;
    /** @type {Promise<void>|null} */
    this._serverReady = null;
    /** @type {Map<string, Object>} id -> {resolve, timer, child, settled} */
    this._pending = new Map();
    /** @type {Set<import('node:child_process').ChildProcess>} */
    this._children = new Set();
    /** @type {Array<Object>} 最近事件，供 demo / 测试查询 */
    this.events = [];
    /** 最近一次失败信息（toast 显示失败 / 注册失败），便于排查 */
    this.lastError = null;
    /** 自动注册结果：{ status: 'pending'|'ok'|'failed'|'skipped', at, error } */
    this.registration = { status: 'pending', at: null, error: null };
    /** 注册失败后的降级标记（纯文本 toast）。 */
    this.degraded = false;
    this._registrationPromise = null;
    this._seq = 0;
    this._closed = false;
  }

  /**
   * 能力声明。
   *
   * `reply:false` 是刻意的：本后端**能发**「去回复」按钮（actions.reply 仍可用），
   * 但协议激活拿不到用户输入的文本（已实测），所以不宣称支持「输入文本回复」；
   * 客户端不要据此渲染输入框。收到 reply 时后端只做两件事：调 raiseWindow() +
   * 返回 { decision:'reply' }。
   */
  capabilities() {
    return { buttons: true, reply: false, badge: false, raise: true };
  }

  /** 启动回传 HTTP 服务；重复调用幂等。 */
  async ensureServer() {
    if (this.server) return;
    if (this._serverReady) return this._serverReady;
    this._serverReady = new Promise((resolve, reject) => {
      const server = http.createServer((req, res) => this._handleRequest(req, res));
      server.once('error', (err) => {
        this._serverReady = null;
        if (err && err.code === 'EADDRINUSE') {
          reject(new Error(`端口 ${this.port} 已被占用：mock-server.js 和 windows backend 不能同时监听同一端口`));
        } else {
          reject(err);
        }
      });
      server.listen(this.port, '127.0.0.1', () => {
        this.server = server;
        this.log.info(`事件回传服务已监听 http://127.0.0.1:${this.port}（POST /action）`);
        resolve();
      });
    });
    return this._serverReady;
  }

  /**
   * 首次使用自动写 HKCU（AUMID + dsh-notify 协议）。
   * 写失败不抛错：记 failed + degraded，后续通知降级成纯文本。
   */
  async ensureRegistered() {
    // 卸载脚本会删掉 state/install.json：一旦它不在，说明注册可能已被清空（用户手动卸载、或换了机器），
    // 这时不能继续相信内存里的 ok 状态，重新走一次安装把它补回来。
    const stateFile = path.join(this.rootDir, 'state', 'install.json');
    if ((this.registration.status === 'ok' || this.registration.status === 'skipped') && !fs.existsSync(stateFile)) {
      this.log.warn('state/install.json 不见了（可能被卸载过），重新注册 AUMID 与协议');
      this.registration = { status: 'pending', at: null, error: null };
      this.degraded = false;
    }
    if (this.registration.status === 'ok' || this.registration.status === 'skipped') {
      return this.registration;
    }
    if (this.registration.status === 'failed') {
      // 失败不永久缓存：隔 REGISTER_RETRY_MS 再试一次，避免「修好环境后必须重启」。
      const lastAt = Date.parse(this.registration.at ?? '');
      const fresh = Number.isFinite(lastAt) && Date.now() - lastAt < REGISTER_RETRY_MS;
      if (fresh) return this.registration;
      this.registration = { status: 'pending', at: null, error: null };
      this.degraded = false;
    }
    if (this._registrationPromise) return this._registrationPromise;
    if (!this.autoRegister) {
      this.registration = { status: 'skipped', at: new Date().toISOString(), error: null };
      return this.registration;
    }
    this._registrationPromise = this._runInstallScript().then((result) => {
      this.registration = result;
      if (!result.ok) {
        this.degraded = true;
        this.lastError = this.lastError || { phase: 'registration', message: result.error };
        this.log.warn(`自动注册失败，降级为纯文本通知：${result.error}`);
      } else {
        this.log.info(`AUMID/协议已就绪：${this.appId} / ${this.protocol}://`);
      }
      this._registrationPromise = null;
      return this.registration;
    });
    return this._registrationPromise;
  }

  _runInstallScript() {
    return new Promise((resolve) => {
      const at = new Date().toISOString();
      let child;
      try {
        child = spawn(
          this.powershellPath,
          [
            '-NoProfile',
            '-NonInteractive',
            '-ExecutionPolicy', 'Bypass',
            '-File', this.installScript,
            '-Quiet',
            '-AppId', this.appId,
            '-Protocol', this.protocol,
            '-Port', String(this.port),
          ],
          { cwd: this.rootDir, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] },
        );
      } catch (err) {
        return resolve({ status: 'failed', ok: false, at, error: String(err && err.message) });
      }
      let output = '';
      child.stdout?.on('data', (chunk) => { output += chunk.toString('utf8'); });
      child.stderr?.on('data', (chunk) => { output += chunk.toString('utf8'); });
      const timer = setTimeout(() => {
        try { child.kill(); } catch { /* ignore */ }
      }, 20000);
      timer.unref?.();
      child.on('error', (err) => {
        clearTimeout(timer);
        resolve({ status: 'failed', ok: false, at, error: String(err && err.message) });
      });
      child.on('close', (code) => {
        clearTimeout(timer);
        const tail = output.trim().split(/\r?\n/).slice(-3).join(' | ');
        if (code === 0) resolve({ status: 'ok', ok: true, at, error: null });
        else resolve({ status: 'failed', ok: false, at, error: `install.ps1 退出码 ${code}${tail ? `：${tail}` : ''}` });
      });
    });
  }

  /**
   * 弹通知并等用户结果（端到端）。
   * @param {Object} req NotifyRequest
   * @returns {Promise<Object>} NotifyResult
   */
  async notify(req) {
    if (this._closed) throw new Error('backend 已 dispose，不能继续 notify');
    const request = normalizeRequest(req);
    await this.ensureServer();

    const registration = await this.ensureRegistered();
    if (registration.status === 'failed') {
      // 降级：只弹一条纯文本通知（不阻塞等待点击），然后明确告诉调用方 unsupported。
      await this._showPlainText(request);
      return normalizeResult({ decision: DECISIONS.UNSUPPORTED });
    }

    const id = request.eventId || `evt-${Date.now().toString(36)}-${++this._seq}`;
    const labels = request.actions || {};
    const args = [
      '-NoProfile',
      '-NonInteractive',
      '-ExecutionPolicy', 'Bypass',
      '-File', this.showToastScript,
      '-Title', request.title,
      '-Body', request.body,
      '-Id', id,
      '-AppId', this.appId,
    ];
    if (typeof labels.allow === 'string') args.push('-AllowText', labels.allow);
    if (typeof labels.sessionAllow === 'string') args.push('-SessionAllowText', labels.sessionAllow);
    if (typeof labels.deny === 'string') args.push('-DenyText', labels.deny);
    if (typeof labels.reply === 'string') args.push('-ReplyText', labels.reply);
    if (labels.allow === false) args.push('-NoAllow');
    if (labels.sessionAllow === false) args.push('-NoSessionAllow');
    if (labels.deny === false) args.push('-NoDeny');
    if (labels.reply === false) args.push('-NoReply');
    const choices = Array.isArray(request.choices) ? request.choices.slice(0, 4) : [];
    if (choices.length > 0) {
      // 选项按钮：复用四个 -No* 关掉默认按钮，改用 -Choices 逐条生成。
      args.push('-NoAllow', '-NoSessionAllow', '-NoDeny', '-NoReply');
      args.push('-Choices', choices.map((c) => `${c.id}~${c.label}`).join('|'));
    }

    return new Promise((resolve) => {
      const state = { resolve, timer: null, child: null, settled: false };
      this._pending.set(id, state);

      state.timer = setTimeout(() => {
        this._settle(id, { decision: DECISIONS.TIMEOUT });
        this._killChild(state.child);
      }, request.timeoutMs);
      state.timer.unref?.();

      let child;
      try {
        child = this._spawnToast(args);
      } catch (err) {
        this.lastError = { phase: 'spawn', message: String(err && err.message) };
        this._settle(id, { decision: DECISIONS.UNSUPPORTED });
        return;
      }
      state.child = child;
      this._children.add(child);

      const onData = (chunk, isStderr) => {
        const text = chunk.toString('utf8');
        for (const line of text.split(/\r?\n/)) {
          if (!line.trim()) continue;
          this.log.info(`show-toast: ${line.trim()}`);
          if (/ERROR |CreateToastNotifier.*失败|Show\(\) 失败|Exception|HRESULT/i.test(line)) {
            this.lastError = { phase: 'toast', message: line.trim() };
          }
        }
      };
      child.stdout?.on('data', (chunk) => onData(chunk, false));
      child.stderr?.on('data', (chunk) => onData(chunk, true));

      child.on('error', (err) => {
        this.lastError = { phase: 'child', message: String(err && err.message) };
        this._settle(id, { decision: DECISIONS.UNSUPPORTED });
      });

      child.on('exit', (code) => {
        this._children.delete(child);
        if (state.settled) return;
        // 普通模式（不带 -Wait）下 show-toast.ps1 弹完就退出：退出码 0 = 通知已显示，
        // 继续等协议事件或超时；非 0 = 弹窗失败。
        if (code !== 0) {
          this.lastError = this.lastError || {
            phase: 'show-toast',
            message: `show-toast.ps1 退出码 ${code}`,
          };
          this._settle(id, { decision: DECISIONS.UNSUPPORTED });
        }
      });
    });
  }

  /** @returns {{ok: boolean, reason?: string}} */
  badge() {
    // lab 原型不实现任务栏徽标（原仓库的 overlay 测试在 dsh-desktop-notify/tools/ 里）。
    return { ok: false, reason: 'badge-backend-not-implemented-in-lab' };
  }

  /** 把 DSH 宿主窗口拉到前台（优先用注入实现）。 */
  raiseWindow() {
    if (this.raiseImpl) {
      try {
        return this.raiseImpl() === true;
      } catch {
        return false;
      }
    }
    try {
      const script =
        '$ws = New-Object -ComObject WScript.Shell; ' +
        'if ($ws.AppActivate(' + process.pid + ')) { "OK" } else { "NO" }';
      const out = execFileSync(this.powershellPath, ['-NoProfile', '-NonInteractive', '-Command', script], {
        encoding: 'utf8',
        windowsHide: true,
        timeout: 5000,
      });
      return /OK/.test(out);
    } catch {
      return false;
    }
  }

  /** /state 的内容：注册与降级状态对客户端/排障可见。 */
  state() {
    return {
      ok: true,
      backend: 'windows',
      port: this.port,
      appId: this.appId,
      protocol: `${this.protocol}://`,
      registration: this.registration,
      degraded: this.degraded,
      capabilities: this.capabilities(),
      pending: this._pending.size,
      events: this.events.length,
      lastError: this.lastError,
    };
  }

  /** 关服务、杀子进程、把未决 notify 统一 resolve 成 dismissed。 */
  async dispose() {
    this._closed = true;
    for (const [id, state] of [...this._pending.entries()]) {
      this._settle(id, { decision: DECISIONS.DISMISSED });
      this._killChild(state.child);
    }
    for (const child of [...this._children]) this._killChild(child);
    this._children.clear();
    if (this.server) {
      await new Promise((resolve) => this.server.close(() => resolve()));
      this.server = null;
    }
    this._serverReady = null;
  }

  // ───────────────────────────── internals ─────────────────────────────

  /**
   * 撤掉一条还在显示的通知（双通道互通：应用内先点掉时由宿主半调用）。
   * 拿不到返回值也没关系——通知可能已经被 Windows 收进通知中心或已过期。
   */
  async dismiss(eventId) {
    if (this._closed) return false;
    const id = String(eventId || '');
    if (!id) return false;
    try {
      const child = this._spawnToast([
        '-NoProfile',
        '-NonInteractive',
        '-ExecutionPolicy', 'Bypass',
        '-File', this.removeToastScript,
        '-Id', id,
        '-AppId', this.appId,
      ]);
      child.on('error', () => {});
      child.stdout?.resume?.();
      child.stderr?.resume?.();
      return true;
    } catch {
      return false;
    }
  }

  _spawnToast(psArgs) {
    if (this.showToastCommand) {
      const [command, ...prefix] = this.showToastCommand;
      return spawn(command, [...prefix, ...psArgs], {
        cwd: this.rootDir,
        windowsHide: true,
        stdio: ['ignore', 'pipe', 'pipe'],
      });
    }
    return spawn(this.powershellPath, psArgs, {
      cwd: this.rootDir,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
  }

  /** 注册失败时的纯文本降级通知：弹完就返回，不等点击。 */
  _showPlainText(request) {
    return new Promise((resolve) => {
      let child;
      try {
        child = this._spawnToast([
          '-NoProfile',
          '-NonInteractive',
          '-ExecutionPolicy', 'Bypass',
          '-File', this.showToastScript,
          '-Title', request.title,
          '-Body', request.body,
          '-Id', request.eventId || `degraded-${Date.now().toString(36)}`,
          '-AppId', this.appId,
          '-PlainText',
        ]);
      } catch (err) {
        this.log.warn(`降级通知启动失败：${String(err && err.message)}`);
        return resolve(false);
      }
      const done = () => resolve(true);
      const timer = setTimeout(() => {
        try { child.kill(); } catch { /* ignore */ }
      }, DEGRADED_SHOW_TIMEOUT_MS);
      timer.unref?.();
      child.on('error', () => { clearTimeout(timer); resolve(false); });
      child.on('close', () => { clearTimeout(timer); done(); });
    });
  }

  _settle(id, result) {
    const state = this._pending.get(id);
    if (!state || state.settled) return;
    state.settled = true;
    if (state.timer) clearTimeout(state.timer);
    this._pending.delete(id);
    state.resolve(normalizeResult(result));
  }

  _killChild(child) {
    if (!child) return;
    try {
      if (child.exitCode === null) child.kill();
    } catch {
      /* ignore */
    }
  }

  _handleRequest(req, res) {
    const url = new URL(req.url, `http://127.0.0.1:${this.port}`);
    const header = req.headers['x-dsh-desktop-notify'];
    const cors = {
      'access-control-allow-origin': '*',
      'access-control-allow-headers': 'content-type, x-dsh-desktop-notify',
      'access-control-allow-methods': 'GET, POST, OPTIONS',
    };

    if (req.method === 'OPTIONS') {
      res.writeHead(204, cors);
      return res.end();
    }
    if (req.method === 'GET' && url.pathname === '/health') {
      return this._sendJson(res, 200, {
        ok: true,
        backend: 'windows',
        port: this.port,
        pending: this._pending.size,
        degraded: this.degraded,
        registration: this.registration,
        lastError: this.lastError,
      }, cors);
    }
    if (req.method === 'GET' && url.pathname === '/state') {
      return this._sendJson(res, 200, this.state(), cors);
    }
    if (req.method === 'GET' && url.pathname === '/events') {
      return this._sendJson(res, 200, { ok: true, count: this.events.length, events: this.events }, cors);
    }
    if (req.method === 'GET' && url.pathname === '/action') {
      const payload = Object.fromEntries(url.searchParams.entries());
      const event = this._record(payload, header, { via: 'GET' });
      this._onPayload(payload);
      return this._sendJson(res, 200, { ok: true, seq: event.seq, via: 'GET' }, cors);
    }
    if (req.method === 'POST' && url.pathname === '/action') {
      if (!header) {
        return this._sendJson(res, 400, { ok: false, error: 'missing x-dsh-desktop-notify header' }, cors);
      }
      let raw = '';
      req.on('data', (chunk) => {
        raw += chunk;
        if (raw.length > MAX_BODY) req.destroy();
      });
      req.on('end', () => {
        let payload;
        try {
          payload = JSON.parse(raw || '{}');
        } catch (err) {
          return this._sendJson(res, 400, { ok: false, error: `invalid JSON: ${err.message}` }, cors);
        }
        const event = this._record(payload, header, { via: 'POST' });
        this._onPayload(payload);
        this._sendJson(res, 200, { ok: true, seq: event.seq, via: 'POST' }, cors);
      });
      return;
    }
    res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', ...cors });
    res.end(
      [
        'dsh-desktop-notify windows backend',
        '',
        'POST /action   handler.ps1 回传入口',
        'GET  /action   排查用',
        'GET  /state    注册 / 降级 / 能力状态',
        'GET  /events   最近事件 JSON',
        'GET  /health   健康检查',
        '',
      ].join('\n'),
    );
  }

  _record(payload, header, extra) {
    const event = { seq: ++this._seq, at: new Date().toISOString(), header: header ?? null, ...extra, payload };
    this.events.push(event);
    if (this.events.length > MAX_EVENTS) this.events.shift();
    this.log.info(`${event.via} /action id=${payload && payload.id} action=${payload && payload.action}`);
    return event;
  }

  /** 收到协议事件：resolve 正在等这个 id 的 notify。 */
  _onPayload(payload) {
    if (!payload || !payload.id) return;
    const state = this._pending.get(payload.id);
    if (!state || state.settled) return;

    const action = String(payload.action || '');
    let decision = ACTION_TO_DECISION[action];
    if (!decision && payload.kind === 'show') decision = DECISIONS.ALLOW;
    if (!decision) {
      this.log.warn(`未知 action=${action}，忽略（id=${payload.id}）`);
      return;
    }

    if (decision === DECISIONS.CHOICE) {
      return this._settle(payload.id, { decision, choiceId: String(payload.value || '') });
    }
    if (decision === DECISIONS.REPLY) {
      // 协议激活拿不到输入文本（已实测）。reply 的语义 = 用户想回复：
      // 把 DSH 窗口提到前台，让用户直接在聊天输入框里回。
      const raised = this.raiseWindow();
      this.log.info(`reply：唤起 DSH 窗口 raised=${raised}（不携带文本，客户端应在窗口里继续）`);
      return this._settle(payload.id, { decision, raised });
    }
    this._settle(payload.id, { decision });
  }

  _sendJson(res, status, body, extraHeaders = {}) {
    const payload = JSON.stringify(body, null, 2);
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'content-length': Buffer.byteLength(payload),
      'access-control-allow-origin': '*',
      ...extraHeaders,
    });
    res.end(payload);
  }
}

export default createWindowsBackend;
