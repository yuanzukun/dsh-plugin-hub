/**
 * noop 后端：Linux / 未知平台 / 明确关闭桌面通知时的兜底实现。
 *
 * 行为：不弹任何东西，notify() 立刻返回 { decision: 'unsupported' }。
 * 调用方（DSH 插件）拿到 unsupported 后应回退到 HTML5 Notification 或纯文本确认。
 *
 * @typedef {import('./contract.js').NotifyBackend} NotifyBackend
 */
import { DECISIONS, NO_CAPABILITIES } from './contract.js';

/** @returns {NotifyBackend} */
export function createNoopBackend() {
  return {
    capabilities() {
      return { ...NO_CAPABILITIES };
    },
    async notify() {
      return { decision: DECISIONS.UNSUPPORTED };
    },
    badge() {
      return { ok: false, reason: 'noop-backend' };
    },
    raiseWindow() {
      return false;
    },
    async dispose() {},
  };
}

export default createNoopBackend;
