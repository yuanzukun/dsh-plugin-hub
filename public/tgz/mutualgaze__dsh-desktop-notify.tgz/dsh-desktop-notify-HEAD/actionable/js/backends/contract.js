/**
 * dsh-desktop-notify — 平台后端公共契约（纯 JSDoc + 常量，无运行时依赖）
 *
 * 这个文件定义 lab 原型里所有后端（windows / darwin / noop）共同遵守的接口。
 * 真正的产品代码应该把这里换成 .d.ts 或 TypeScript interface；lab 里只用 JSDoc，
 * 保证 Node 直接跑、不引入构建步骤。
 *
 * ── 请求 ────────────────────────────────────────────────────────────────────
 * @typedef {'approval'|'question'|'finish'|'error'} NotifyKind
 *
 * @typedef {Object} NotifyActions
 *   可选：覆盖各按钮文案 / 关闭某个按钮（false）。
 *   @property {string|false} [allow]         默认「允许」
 *   @property {string|false} [sessionAllow]  默认「本次会话允许」
 *   @property {string|false} [deny]          默认「拒绝」
 *   @property {string|false} [reply]         默认「发送回复」，false 表示不要输入框
 *
 * @typedef {Object} NotifyRequest
 *   @property {NotifyKind} kind             通知语义（approval / question / finish / error）
 *   @property {string} title                标题（lab 里测试通知必须以「[测试]」开头）
 *   @property {string} body                 正文
 *   @property {string} [sessionId]          DSH 会话 id，便于 handler 回传时归属
 *   @property {string} [eventId]            事件 id；不传则后端生成，回传时原样返回
 *   @property {NotifyActions} [actions]     按钮文案自定义（见上）
 *   @property {number} [timeoutMs]          超时毫秒数；超时返回 {decision:'timeout'}
 *
 * ── 结果 ────────────────────────────────────────────────────────────────────
 * @typedef {'allow'|'allow-session'|'deny'|'reply'|'choice'|'dismissed'|'timeout'|'unsupported'} NotifyDecision
 *
 * @typedef {Object} NotifyResult
 *   @property {NotifyDecision} decision
 *   @property {string} [text]               decision === 'reply' 时的用户输入文本。
 *     **Windows 上恒为 undefined**：activationType="protocol" 的 toast 不会把输入框
 *     内容带进 URI（已实测，见 logs/toast-demo-reply-1.xml：hint-inputId 在、用户也
 *     输入了，URI 里依然没有文本）。Windows 后端收到 reply 后只把 DSH 窗口提到前台，
 *     让用户直接在聊天输入框里回。
 *
 * ── 后端对象 ────────────────────────────────────────────────────────────────
 * @typedef {Object} BackendCapabilities
 *   @property {boolean} buttons             是否支持按钮
 *   @property {boolean} reply               是否支持文本输入 / 回复
 *   @property {boolean} badge               是否支持任务栏徽标 / 角标
 *   @property {boolean} raise               是否支持把宿主窗口拉到前台
 *
 * @typedef {Object} NotifyBackend
 *   @property {() => BackendCapabilities} capabilities
 *   @property {(req: NotifyRequest) => Promise<NotifyResult>} notify
 *   @property {(opts?: Object) => Object} badge
 *   @property {() => boolean} raiseWindow
 *   @property {() => Promise<void>} dispose
 */

/** 所有后端都会用的 decision 常量（避免魔法字符串拼错）。 */
export const DECISIONS = Object.freeze({
  ALLOW: 'allow',
  ALLOW_SESSION: 'allow-session',
  DENY: 'deny',
  REPLY: 'reply',
  DISMISSED: 'dismissed',
  TIMEOUT: 'timeout',
  UNSUPPORTED: 'unsupported',
  CHOICE: 'choice',
});

/** 后端把 toast action（协议 URI 里的 action= 参数）映射成 NotifyResult.decision。 */
export const ACTION_TO_DECISION = Object.freeze({
  allow: DECISIONS.ALLOW,
  'allow-session': DECISIONS.ALLOW_SESSION,
  deny: DECISIONS.DENY,
  reply: DECISIONS.REPLY,
  option: DECISIONS.CHOICE,
  open: DECISIONS.ALLOW, // 点正文：原型里当作「打开 / 允许」，产品里应该单独处理
});

/** 不支持平台使用的默认能力。 */
export const NO_CAPABILITIES = Object.freeze({ buttons: false, reply: false, badge: false, raise: false });

/**
 * 校验并补全 NotifyRequest。非法 kind 直接抛错（早失败比弹一条错通知好）。
 * @param {NotifyRequest} req
 * @returns {NotifyRequest & {title: string, body: string, timeoutMs: number}}
 */
export function normalizeRequest(req) {
  if (!req || typeof req !== 'object') throw new TypeError('notify(req): req 必须是对象');
  const kinds = ['approval', 'question', 'finish', 'error'];
  if (!kinds.includes(req.kind)) throw new TypeError(`notify(req): kind 必须是 ${kinds.join('|')}，收到 ${String(req.kind)}`);
  const title = String(req.title ?? '').trim();
  if (!title) throw new TypeError('notify(req): title 不能为空');
  const body = String(req.body ?? '');
  const timeoutMs = Number.isFinite(req.timeoutMs) && req.timeoutMs > 0 ? req.timeoutMs : 120_000;
  return { ...req, title, body, timeoutMs };
}

/** 把任意结果收敛成合法 NotifyResult，防止后端实现漏字段。 */
export function normalizeResult(result) {
  const valid = new Set(Object.values(DECISIONS));
  if (!result || typeof result !== 'object') return { decision: DECISIONS.UNSUPPORTED };
  if (!valid.has(result.decision)) return { decision: DECISIONS.UNSUPPORTED };
  const out = { decision: result.decision };
  // 只有后端真的拿到了文本才带 text：Windows 协议激活拿不到（见上），
  // 不能让 normalizeResult 把 undefined 补成空串、让调用方误以为「用户提交了空回复」。
  if (result.decision === DECISIONS.CHOICE && typeof result.choiceId === 'string') out.choiceId = result.choiceId;
  return out;
}
