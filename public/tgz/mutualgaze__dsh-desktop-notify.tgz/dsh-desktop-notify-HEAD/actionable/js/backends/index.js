/**
 * dsh-desktop-notify — 平台后端工厂
 *
 * 用法（DSH 插件里）：
 *
 *   import { createBackend } from './backends/index.js';
 *   const backend = createBackend();               // 按 process.platform 选
 *   const caps = backend.capabilities();
 *   const result = await backend.notify({
 *     kind: 'approval',
 *     title: '允许执行这个命令吗？',
 *     body: 'rm -rf ./dist && pnpm build',
 *     eventId: 'evt-123',
 *     timeoutMs: 120000,
 *   });
 *   // result: { decision: 'allow' } | { decision: 'reply' } | ...
 *   // 注意：Windows 上 reply 不带 text（协议激活不携带输入框内容），
 *   // 后端会先把 DSH 窗口提到前台，让用户直接在聊天里回复。
 *
 * 设计：
 *   - 契约在 ./contract.js（JSDoc），平台差异全部收敛到后端；
 *   - win32  -> windows.js（真实实现：WinRT toast + dsh-notify 协议回传）
 *   - darwin -> darwin.js（本版只留桩：terminal-notifier -action/-reply/-timeout，返回 unsupported）
 *   - 其它   -> noop.js（返回 unsupported，DSH 可回退到 HTML5 Notification）
 */
import { createWindowsBackend } from './windows.js';
import { createDarwinBackend } from './darwin.js';
import { createNoopBackend } from './noop.js';
import { DECISIONS, NO_CAPABILITIES, normalizeRequest, normalizeResult } from './contract.js';

export { DECISIONS, ACTION_TO_DECISION, NO_CAPABILITIES, normalizeRequest, normalizeResult } from './contract.js';

/**
 * @param {Object} [args]
 * @param {NodeJS.Platform|string} [args.platform] 默认 process.platform；测试时可显式传 'darwin'/'linux'。
 * @param {Object} [args.options] 传给具体后端的选项（windows: {port, appId, rootDir, powershellPath, ...}）。
 * @returns {import('./contract.js').NotifyBackend}
 */
export function createBackend({ platform = process.platform, options = {} } = {}) {
  switch (platform) {
    case 'win32':
      return createWindowsBackend(options);
    case 'darwin':
      // 本版只留桩；真正实现时把 createDarwinBackend 换成 createDarwinBackend(options)。
      return createDarwinBackend(options);
    default:
      return createNoopBackend();
  }
}

/**
 * 探针：只拿能力，不创建后端（避免在无 GUI 的 CI 里起 HTTP 服务）。
 * @param {string} [platform]
 * @returns {import('./contract.js').BackendCapabilities}
 */
export function capabilitiesFor(platform = process.platform) {
  switch (platform) {
    case 'win32':
      // reply:false 是刻意的：能发「去回复」按钮，但协议激活拿不到用户输入的文本
      //（已实测：hint-inputId 在、用户也输入了，URI 里仍然没有文本）。
      // actions.reply 仍可用；后端收到 reply 后只做 raiseWindow() + 返回 { decision:'reply' }。
      return { buttons: true, reply: false, badge: false, raise: true };
    case 'darwin':
      return { ...NO_CAPABILITIES };
    default:
      return { ...NO_CAPABILITIES };
  }
}

export default createBackend;
