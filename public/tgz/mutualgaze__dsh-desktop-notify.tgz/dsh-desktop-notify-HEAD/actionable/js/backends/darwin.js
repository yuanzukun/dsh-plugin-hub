/**
 * darwin 后端：**只留桩，本版不实现**（用户已拍板 macOS 这一版不做）。
 *
 * 为什么留桩：lab 原型要把「带按钮 + 输入框 + 同步等结果」这条产品级链路定下来，
 * 平台差异只应该留在后端里。Windows 先跑通，macOS 以后照同一个契约补实现即可。
 *
 * ── 未来 macOS 实现思路（terminal-notifier）────────────────────────────────
 * 1. 依赖：`brew install terminal-notifier`（或把 .app 内置到插件包里）。
 * 2. 弹通知（一次性进程，读 stdout 等结果）：
 *
 *      terminal-notifier \
 *        -title "<title>" -message "<body>" \
 *        -group "dsh-<eventId>" \
 *        -actions "允许","本次会话允许","拒绝","发送回复" \
 *        -reply \
 *        -timeout <秒> \
 *        -json
 *
 *    - `-actions` 会在通知上生成按钮，点按钮后 terminal-notifier 退出并打印
 *      被点按钮的序号（stdout 里 `"activationType":"action"`、`"activationValue":"允许"`）。
 *    - `-reply` 让通知支持直接回文字（macOS 10.14+ 的通知回复），提交后 stdout 里
 *      `"activationType":"replied"`、`"activationValue":"<文本>"`。
 *    - `-timeout` 到期后进程返回 `"activationType":"timeout"`。
 *    - `-json` 输出一行 JSON，后端按 activationType / activationValue 映射成 NotifyResult：
 *        action + 允许            -> { decision: 'allow' }
 *        action + 本次会话允许    -> { decision: 'allow-session' }
 *        action + 拒绝            -> { decision: 'deny' }
 *        replied                 -> { decision: 'reply', text: activationValue }
 *        timeout                 -> { decision: 'timeout' }
 *        closed / 无输出          -> { decision: 'dismissed' }
 * 3. 不支持的能力：
 *    - 任务栏 badge：macOS 没有等价物，capabilities.badge = false；
 *      可考虑 `app.dock.badge` 由 Electron 主进程做。
 *    - raiseWindow：用 `osascript -e 'tell application "System Events" to set frontmost of ...'`
 *      或 Electron 的 `win.show()/focus()`。
 * 4. 注意：terminal-notifier 的 -reply 文本不会出现在 -actions 的结果里，两者互斥；
 *    「按钮 + 回复框同时存在」需要确认目标 macOS 版本的通知 UI（macOS 11+ 支持通知里
 *    直接回复，但与按钮并存的行为要在真机上验证）。
 *
 * 本版所有方法都返回 unsupported / false，不做任何系统调用。
 *
 * 接口规范见 E:\\dsh-plugins\\_notes\\platform-backend.md 第 3 节（macOS 预留）：
 * 本版只留桩，能力全 false；未来能力应为 { buttons:true, reply:true, badge:false, raise:true }
 * ——macOS 能拿回 `replied` 文本（这一点和 Windows 相反，Windows 协议激活拿不到）。
 *
 * @typedef {import('./contract.js').NotifyBackend} NotifyBackend
 */
import { DECISIONS, NO_CAPABILITIES } from './contract.js';

/** @returns {NotifyBackend} */
export function createDarwinBackend() {
  return {
    capabilities() {
      // 未来实现后改成 { buttons: true, reply: true, badge: false, raise: true }
      //（reply=true 因为 macOS 的 replied 能带回文本；Windows 那边恒为 false。）
      return { ...NO_CAPABILITIES };
    },
    async notify() {
      return { decision: DECISIONS.UNSUPPORTED };
    },
    badge() {
      return { ok: false, reason: 'darwin-backend-not-implemented' };
    },
    raiseWindow() {
      return false;
    },
    async dispose() {},
  };
}

export default createDarwinBackend;
