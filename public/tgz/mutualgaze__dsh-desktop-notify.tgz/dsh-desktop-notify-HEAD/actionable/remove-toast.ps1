﻿<#
.SYNOPSIS
  移除一条已经弹出的 Windows toast（按 show-toast.ps1 用的同一套 Tag/Group 规则）。

.DESCRIPTION
  show-toast.ps1 把 Tag/Group 都设成 Id 的「短令牌」（<=16 字符原样，超长取 SHA1 前 16），
  这里必须用完全相同的算法，否则 Remove 找不到那条通知。

  仅用纯 PowerShell 加载 WinRT（不依赖 Add-Type），失败只打日志、返回非零码。

.EXAMPLE
  .\remove-toast.ps1 -Id approval:session-xxx:call_00_yyy
#>
[CmdletBinding()]
param(
  [string]$Id = '',
  [string]$Group = 'lab',
  [string]$AppId = 'DshDesktopNotifyLab'
)

$ErrorActionPreference = 'Stop'

function ConvertTo-ShortToken([string]$value) {
  if ([string]::IsNullOrEmpty($value)) { return $null }
  if ($value.Length -le 16) { return $value }
  $sha = [System.Security.Cryptography.SHA1]::Create()
  try {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($value)
    $hash = $sha.ComputeHash($bytes)
    return ((-join ($hash | ForEach-Object { $_.ToString('x2') })).Substring(0, 16))
  } finally {
    $sha.Dispose()
  }
}

$token = ConvertTo-ShortToken $Id
$safeGroup = ConvertTo-ShortToken $Group
if (-not $token) { Write-Output 'NO_ID'; exit 2 }

try {
  [void][Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
} catch {
  Write-Output ('WINRT_LOAD_FAIL: ' + $_.Exception.Message)
  exit 1
}

try {
  [Windows.UI.Notifications.ToastNotificationManager]::History.Remove($token, $safeGroup, $AppId)
  Write-Output ('REMOVED ' + $token + ' group=' + $safeGroup)
  "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff')] removed token=$token group=$safeGroup app=$AppId" | Add-Content -LiteralPath (Join-Path $PSScriptRoot 'logs\remove-toast.log') -Encoding UTF8
  exit 0
} catch {
  $inner = $_.Exception.InnerException
  $hr = if ($inner) { $inner.HResult } else { $_.Exception.HResult }
  Write-Output ('REMOVE_FAILED 0x{0:X8} {1}' -f $hr, $_.Exception.Message)
  "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff')] failed 0x$('{0:X8}' -f $hr) $($_.Exception.Message) token=$token group=$safeGroup" | Add-Content -LiteralPath (Join-Path $PSScriptRoot 'logs\remove-toast.log') -Encoding UTF8  # REMOVE_FAILED log
  exit 3
}
