﻿<#
.SYNOPSIS
  卸载 dsh-desktop-notify 可交互通知原型：删除 HKCU 注册项、清理通知历史、结束残留进程。

.DESCRIPTION
  幂等：重复执行不报错。删除内容：
    - HKCU:\Software\Classes\AppUserModelId\<AppId>
    - HKCU:\Software\Classes\<Protocol>
    - 本 AUMID 在通知中心的历史（History.Clear）
    - 命令行里带 handler.ps1 / launch-handler.vbs / mock-server.js / show-toast.ps1 的残留进程
    - state\install.json（日志与截图保留，作为证据）

.EXAMPLE
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\uninstall.ps1

.EXAMPLE
  .\uninstall.ps1 -KeepState
#>
[CmdletBinding()]
param(
  [string]$AppId = 'DshDesktopNotifyLab',
  [string]$Protocol = 'dsh-notify',
  [switch]$KeepState
)

$ErrorActionPreference = 'Continue'
$root = $PSScriptRoot
$logDir = Join-Path $root 'logs'
if (-not (Test-Path -LiteralPath $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$logPath = Join-Path $logDir 'uninstall.log'
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Write-Step([string]$Message) {
  $line = ('[{0}] {1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $Message)
  [System.IO.File]::AppendAllText($logPath, $line + "`r`n", $utf8)
  Write-Host $line
}

Write-Step "开始卸载：AppId=$AppId Protocol=$Protocol"

# ---------- 1) 先清通知历史（键删掉后就查不到这个 AUMID 了） ----------
try {
  [void][Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime]
  [Windows.UI.Notifications.ToastNotificationManager]::History.Clear($AppId)
  Write-Step "已清空通知历史：$AppId"
} catch {
  Write-Step ('清空通知历史失败（非致命）：' + $_.Exception.Message)
}

# ---------- 2) 结束残留进程 ----------
$patterns = @('handler\.ps1', 'launch-handler\.vbs', 'mock-server\.js', 'show-toast\.ps1')
$killed = @()
try {
  $procs = Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
    $_.ProcessId -ne $PID -and $_.CommandLine -and ($_.CommandLine -match ($patterns -join '|'))
  }
  foreach ($p in $procs) {
    $desc = '{0} ({1}) pid={2}' -f $p.Name, $p.ProcessId, $p.CommandLine
    try {
      Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop
      $killed += $desc
      Write-Step "已结束进程：$desc"
    } catch {
      Write-Step ('结束进程失败：{0} -> {1}' -f $desc, $_.Exception.Message)
    }
  }
} catch {
  Write-Step ('枚举进程失败（非致命）：' + $_.Exception.Message)
}
if ($killed.Count -eq 0) { Write-Step '没有需要结束的残留进程' }

# ---------- 3) 删除注册表项 ----------
$appKey = "HKCU:\Software\Classes\AppUserModelId\$AppId"
$protoKey = "HKCU:\Software\Classes\$Protocol"
$notifKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Notifications\Settings\$AppId"
foreach ($k in @($appKey, $protoKey, $notifKey)) {
  if (Test-Path -LiteralPath $k) {
    try {
      Remove-Item -LiteralPath $k -Recurse -Force -ErrorAction Stop
      Write-Step "已删除：$k"
    } catch {
      Write-Step ('删除失败：{0} -> {1}' -f $k, $_.Exception.Message)
    }
  } else {
    Write-Step "不存在（跳过）：$k"
  }
}

# ---------- 4) 状态文件 ----------
if (-not $KeepState) {
  foreach ($name in @('install.json', 'node-path.txt')) {
    $statePath = Join-Path $root ("state\" + $name)
    if (Test-Path -LiteralPath $statePath) {
      Remove-Item -LiteralPath $statePath -Force -ErrorAction SilentlyContinue
      Write-Step "已删除状态文件：$statePath"
    }
  }
}

# ---------- 5) 校验 ----------
$appLeft = Test-Path -LiteralPath $appKey
$protoLeft = Test-Path -LiteralPath $protoKey
$notifLeft = Test-Path -LiteralPath $notifKey
Write-Step "校验：AUMID 键存在=$appLeft；协议键存在=$protoLeft；通知设置键存在=$notifLeft"

$leftProcs = @()
try {
  $leftProcs = Get-CimInstance Win32_Process -ErrorAction Stop | Where-Object {
    $_.ProcessId -ne $PID -and $_.CommandLine -and ($_.CommandLine -match ($patterns -join '|'))
  }
} catch {}
Write-Step ('校验：残留进程数={0}' -f @($leftProcs).Count)

if ($appLeft -or $protoLeft -or $notifLeft -or @($leftProcs).Count -gt 0) {
  Write-Step '卸载未完全干净（见上）'
  exit 1
}
Write-Step '卸载完成：注册项已清空，无残留进程'
exit 0
