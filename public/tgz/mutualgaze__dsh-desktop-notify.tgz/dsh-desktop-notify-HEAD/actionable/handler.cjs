#!/usr/bin/env node
/**
 * handler.js —— 协议激活处理器（Node 版，替代 handler.ps1 的快路径）。
 *
 * 为什么要有它：点 toast 按钮时 Windows 会拉起协议命令，PowerShell 冷启动约 450~800ms，
 * 用户感知就是「点了没反应」。Node 冷启动约 90ms，同样的活快 5 倍以上。
 *
 * 输入：Windows 把协议 URI 作为第一个参数传进来（可能带引号）：
 *     dsh-notify://action/?action=allow&id=evt-1
 *     dsh-notify://action/?action=allow-session&id=evt-1
 *     dsh-notify://action/?action=deny&id=evt-1
 *     dsh-notify://action/?action=reply&id=evt-1
 *     dsh-notify://show/?id=evt-1
 *
 * 行为：把事件 POST 到 127.0.0.1:<port>/action（带签名头），并追加一行到 logs\handler.log。
 * 端口优先级：state\install.json 的 port > 45917。
 * POST 失败时把事件存到 logs\pending\*.json，方便排查。
 */

'use strict'

const fs = require('fs')
const path = require('path')
const http = require('http')

const here = __dirname
const logDir = path.join(here, 'logs')
const statePath = path.join(here, 'state', 'install.json')
const HEADER = 'x-dsh-desktop-notify'

function stamp() {
  const d = new Date()
  const p = (n, w = 2) => String(n).padStart(w, '0')
  return (
    `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ` +
    `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)}`
  )
}

function log(line) {
  try {
    fs.mkdirSync(logDir, { recursive: true })
    fs.appendFileSync(path.join(logDir, 'handler.log'), `[${stamp()}] ${line}\r\n`, 'utf8')
  } catch {
    /* 日志写不了也不能影响回传 */
  }
}

function readState() {
  try {
    return JSON.parse(fs.readFileSync(statePath, 'utf8'))
  } catch {
    return {}
  }
}

function post(port, payload) {
  return new Promise((resolve) => {
    const body = JSON.stringify(payload)
    const req = http.request(
      {
        host: '127.0.0.1',
        port,
        path: '/action',
        method: 'POST',
        headers: {
          [HEADER]: '1',
          'content-type': 'application/json',
          'content-length': Buffer.byteLength(body),
        },
        timeout: 4000,
      },
      (res) => {
        let text = ''
        res.setEncoding('utf8')
        res.on('data', (chunk) => {
          text += chunk
        })
        res.on('end', () => resolve({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode, text }))
      },
    )
    req.on('timeout', () => {
      req.destroy(new Error('timeout'))
    })
    req.on('error', (error) => resolve({ ok: false, status: 0, text: String(error && error.message) }))
    req.end(body)
  })
}

function savePending(payload) {
  try {
    const dir = path.join(logDir, 'pending')
    fs.mkdirSync(dir, { recursive: true })
    const name = `pending-${Date.now().toString(36)}.json`
    fs.writeFileSync(path.join(dir, name), JSON.stringify(payload, null, 2), 'utf8')
    return name
  } catch {
    return null
  }
}

async function main() {
  const raw = String(process.argv[2] ?? '').replace(/^"|"$/g, '').trim()
  log(`NODE raw=${raw}`)
  if (raw === '') {
    process.exitCode = 2
    return
  }

  let url
  try {
    url = new URL(raw)
  } catch {
    log('NODE bad-uri')
    process.exitCode = 3
    return
  }

  const host = (url.hostname || url.pathname.replace(/^\/+/, '').split('/')[0] || 'action').toLowerCase()
  const action = (url.searchParams.get('action') || '').toLowerCase() || (host === 'show' ? 'open' : '')
  const id = url.searchParams.get('id') || ''
  const text = url.searchParams.get('replyText') || url.searchParams.get('text') || ''
  const value = url.searchParams.get('value') || ''
  const payload = { kind: host, action, id, text, value, raw }

  log(`NODE parsed kind=${host} action=${action} id=${id} text='${text}' value='${value}'`)

  const state = readState()
  const port = Number.isInteger(state.port) && state.port > 0 ? state.port : 45917
  const result = await post(port, payload)
  if (result.ok) {
    log(`NODE POST http://127.0.0.1:${port}/action ok -> ${String(result.text).replace(/\s+/g, ' ').slice(0, 200)}`)
    return
  }
  const saved = savePending(payload)
  log(`NODE POST failed status=${result.status} err=${String(result.text).replace(/\s+/g, ' ').slice(0, 160)} pending=${saved ?? 'none'}`)
  process.exitCode = 1
}

main().catch((error) => {
  log(`NODE crash ${String(error && (error.stack || error.message))}`.slice(0, 400))
  process.exitCode = 4
})
