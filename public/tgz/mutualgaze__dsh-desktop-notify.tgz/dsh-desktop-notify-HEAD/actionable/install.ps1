﻿<#
.SYNOPSIS
  安装 dsh-desktop-notify「可交互通知」原型所需的注册项（只写 HKCU，可用 uninstall.ps1 完整回滚）。

.DESCRIPTION
  写入两类 HKCU 注册项：
    1. HKCU:\Software\Classes\AppUserModelId\<AppId>
         DisplayName / IconUri —— 未打包 Win32 进程用固定 AUMID 弹 toast 的必要条件。
    2. HKCU:\Software\Classes\<Protocol>
         协议激活链：toast 按钮 / 输入框提交 → Windows → wscript.exe →
         launch-handler.vbs（隐藏窗口）→ handler.ps1（POST 到 mock server 并写日志）。

  同时把安装产出的键名、路径、端口记录到 state\install.json，供 handler.ps1 / uninstall.ps1 使用。

.PARAMETER Port
  handler.ps1 POST 的目标端口（mock-server 监听同一端口）。

.EXAMPLE
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\install.ps1

.EXAMPLE
  .\install.ps1 -Port 45917 -AppId DshDesktopNotifyLab
#>
[CmdletBinding()]
param(
  [string]$AppId = 'DshDesktopNotifyLab',
  [string]$DisplayName = 'DeepSeek Harness',
  [string]$Protocol = 'dsh-notify',
  [string]$IconUri = '',
  [int]$Port = 45917,
  # 协议命令默认走 wscript + launch-handler.vbs（无控制台窗口，不会闪）；
  # 加 -DirectNode 才用 node.exe 直连（更快，但会闪一下控制台）。
  [string]$NodePath = '',
  [switch]$DirectNode,
  # 自动注册（js/backends/windows.js 首次 notify 时调用）用：不往控制台写，只写日志文件。
  [switch]$Quiet
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$stateDir = Join-Path $root 'state'
$logDir = Join-Path $root 'logs'
foreach ($d in @($stateDir, $logDir)) {
  if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}

$logPath = Join-Path $logDir 'install.log'
$utf8 = New-Object System.Text.UTF8Encoding($false)
function Write-Step([string]$Message) {
  $line = ('[{0}] {1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'), $Message)
  [System.IO.File]::AppendAllText($logPath, $line + "`r`n", $utf8)
  if (-not $Quiet) { Write-Host $line }
}

if (-not $IconUri) { $IconUri = Join-Path $root 'icon-v2.png' }
$wscript = Join-Path $env:SystemRoot 'System32\wscript.exe'
$launcher = Join-Path $root 'launch-handler.vbs'
$handler = Join-Path $root 'handler.ps1'
$nodeHandler = Join-Path $root 'handler.cjs'
foreach ($p in @($IconUri, $wscript, $launcher, $handler, $nodeHandler)) {
  if (-not (Test-Path -LiteralPath $p)) { throw "缺少文件：$p" }
}

# node 直连能把一次点击从 ~1.5 秒压到 ~0.2 秒：省掉 wscript 与 PowerShell 启动两层。
if (-not $NodePath) {
  $found = Get-Command node.exe -ErrorAction SilentlyContinue
  if ($found) { $NodePath = $found.Source }
}
if ($NodePath -and -not (Test-Path -LiteralPath $NodePath)) { $NodePath = '' }

Write-Step "开始安装：AppId=$AppId Protocol=$Protocol Port=$Port"

# ---------- 1) AUMID ----------
$appKey = "HKCU:\Software\Classes\AppUserModelId\$AppId"
if (-not (Test-Path -LiteralPath $appKey)) { New-Item -Path $appKey -Force | Out-Null }
New-ItemProperty -Path $appKey -Name 'DisplayName' -Value $DisplayName -PropertyType String -Force | Out-Null
New-ItemProperty -Path $appKey -Name 'IconUri' -Value $IconUri -PropertyType String -Force | Out-Null
Write-Step "AUMID 已注册：$appKey（DisplayName=$DisplayName；IconUri=$IconUri）"

# ---------- 2) 协议 dsh-notify ----------
$protoKey = "HKCU:\Software\Classes\$Protocol"
if (-not (Test-Path -LiteralPath $protoKey)) { New-Item -Path $protoKey -Force | Out-Null }
Set-ItemProperty -Path $protoKey -Name '(default)' -Value 'URL:DSH Desktop Notify lab'
New-ItemProperty -Path $protoKey -Name 'URL Protocol' -Value '' -PropertyType String -Force | Out-Null
$cmdKey = Join-Path $protoKey 'shell\open\command'
if (-not (Test-Path -LiteralPath $cmdKey)) { New-Item -Path $cmdKey -Force | Out-Null }
if ($DirectNode -and $NodePath) {
  $command = '"{0}" "{1}" "%1"' -f $NodePath, $nodeHandler
} else {
  $command = '"{0}" //nologo "{1}" "%1"' -f $wscript, $launcher
}
Set-ItemProperty -Path $cmdKey -Name '(default)' -Value $command
Write-Step "协议已注册：$protoKey -> $command"

# ---------- 3) 状态文件 ----------
$state = [ordered]@{
  installedAt = (Get-Date).ToString('o')
  appId       = $AppId
  displayName = $DisplayName
  protocol    = $Protocol
  port        = $Port
  iconUri     = $IconUri
  appKey      = "HKCU\Software\Classes\AppUserModelId\$AppId"
  protoKey    = "HKCU\Software\Classes\$Protocol"
  command     = $command
  root        = $root
  handler     = $handler
  nodeHandler = $nodeHandler
  nodePath    = $NodePath
  launcher    = $launcher
}
$statePath = Join-Path $stateDir 'install.json'
if ($NodePath) { [System.IO.File]::WriteAllText((Join-Path $stateDir 'node-path.txt'), $NodePath, $utf8) }
$state | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $statePath -Encoding UTF8
Write-Step "状态已写入：$statePath"

# ---------- 4) 回读校验 ----------
$appRead = Get-ItemProperty -Path $appKey
$protoRead = Get-ItemProperty -Path $protoKey
$cmdRead = (Get-ItemProperty -Path $cmdKey).'(default)'
Write-Step "回读 AUMID：DisplayName=$($appRead.DisplayName)；IconUri=$($appRead.IconUri)"
Write-Step "回读协议：URL Protocol='$($protoRead.'URL Protocol')'；command=$cmdRead"
Write-Step '安装完成。下一步：node mock-server.js → show-toast.ps1'
