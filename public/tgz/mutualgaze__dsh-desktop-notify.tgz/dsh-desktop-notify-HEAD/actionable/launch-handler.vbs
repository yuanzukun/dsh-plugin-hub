' launch-handler.vbs - protocol activation launcher for dsh-notify.
' Windows calls: wscript.exe //nologo launch-handler.vbs "dsh-notify://..."
' Fast path: node.exe + handler.cjs (~100ms). Falls back to handler.ps1 (~500-800ms).
' NOTE: keep this file ASCII-only; VBScript reads .vbs as ANSI and UTF-8 text can break parsing.
Option Explicit

Dim fso, shell, here, scriptPath, jsPath, uri, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")

If WScript.Arguments.Count = 0 Then
  WScript.Quit 2
End If

uri = WScript.Arguments(0)
here = fso.GetParentFolderName(WScript.ScriptFullName)
scriptPath = here & "\handler.ps1"
jsPath = here & "\handler.cjs"

If Not fso.FileExists(scriptPath) Then
  WScript.Quit 3
End If

Dim nodePath
nodePath = ""

' 1) nodePath recorded by install.ps1 in state\install.json
Dim jsonPath
jsonPath = here & "\state\install.json"
If fso.FileExists(jsonPath) And fso.FileExists(jsPath) Then
  On Error Resume Next
  Dim text, re
  text = fso.OpenTextFile(jsonPath, 1).ReadAll
  Set re = New RegExp
  re.Global = False
  re.Pattern = """nodePath""\s*:\s*""([^""]*)"""
  If re.Test(text) Then
    nodePath = re.Execute(text)(0).SubMatches(0)
    nodePath = Replace(nodePath, "\\\\", "\")
  End If
  On Error GoTo 0
End If

' 2) cached discovery from the previous run (state\node-path.txt)
Dim cachePath
cachePath = here & "\state\node-path.txt"
If nodePath = "" And fso.FileExists(cachePath) Then
  On Error Resume Next
  nodePath = Trim(fso.OpenTextFile(cachePath, 1).ReadAll)
  On Error GoTo 0
End If

' 3) otherwise ask where.exe for node.exe (~200ms) and cache the answer
If nodePath = "" And fso.FileExists(jsPath) Then
  On Error Resume Next
  Dim exec, line
  Set exec = shell.Exec("cmd.exe /c where node.exe")
  Do While Not exec.StdOut.AtEndOfStream
    line = Trim(exec.StdOut.ReadLine())
    If Len(line) > 0 Then
      nodePath = line
      Exit Do
    End If
  Loop
  On Error GoTo 0
  If Len(nodePath) > 0 Then
    On Error Resume Next
    Dim out
    Set out = fso.CreateTextFile(cachePath, True)
    out.Write nodePath
    out.Close
    On Error GoTo 0
  End If
End If

' 4) fast path when node is available (ELECTRON_RUN_AS_NODE covers Electron binaries)
If Len(nodePath) > 0 Then
  If fso.FileExists(nodePath) And fso.FileExists(jsPath) Then
    On Error Resume Next
    Dim env
    Set env = shell.Environment("Process")
    env("ELECTRON_RUN_AS_NODE") = "1"
    cmd = """" & nodePath & """ """ & jsPath & """ """ & uri & """"
    shell.Run cmd, 0, False
    On Error GoTo 0
    WScript.Quit 0
  End If
End If

' 5) fallback: PowerShell handler
cmd = "powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & scriptPath & """ -Uri """ & uri & """"
shell.Run cmd, 0, False
WScript.Quit 0
