﻿<#
.SYNOPSIS
  协议激活处理器：toast 按钮 / 输入框提交时由 launch-handler.vbs 调起。

.DESCRIPTION
  输入（Windows 会把协议 URI 作为 %1 传进来，可能带引号）：
      dsh-notify://action?action=allow&id=evt-1
      dsh-notify://action?action=allow-session&id=evt-1
      dsh-notify://action?action=deny&id=evt-1
      dsh-notify://action?action=reply&id=evt-1&replyText=...
      dsh-notify://show?id=evt-1                （点正文）

  行为：
    1. 把原始参数 + 解析结果追加到 logs\handler.log（永远先落盘，不丢证据）。
    2. 把事件 POST 到 http://127.0.0.1:<port>/action，带 header x-dsh-desktop-notify: 1。
       端口优先级：-Port 参数 > state\install.json 的 port > 45917。
    3. POST 失败时把事件正文另存为 logs\pending\*.json，方便排查/重放。

  注意：Windows 没有把输入框文本回传时，这里只会拿到按钮 URI 本身；handler.log 里的
  raw= 与 keys= 就是判断依据（见 README「坑」一节）。

.EXAMPLE
  powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\handler.ps1 -Uri "dsh-notify://action?action=allow&id=evt-1"
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true, Position = 0)]
  [string]$Uri,
  [int]$Port = 0,
  [switch]$NoPost
)

$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$logDir = Join-Path $root 'logs'
$pendingDir = Join-Path $logDir 'pending'
foreach ($d in @($logDir, $pendingDir)) {
  if (-not (Test-Path -LiteralPath $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}
$logPath = Join-Path $logDir 'handler.log'
$utf8 = New-Object System.Text.UTF8Encoding($false)

function Write-Log([string]$Message) {
  $line = ('[{0}] {1}' -f (Get-Date).ToString('yyyy-MM-dd HH:mm:ss.fff'), $Message)
  [System.IO.File]::AppendAllText($logPath, $line + "`r`n", $utf8)
}

# ---------- 1) 端口 ----------
if ($Port -le 0) {
  $statePath = Join-Path $root 'state\install.json'
  if (Test-Path -LiteralPath $statePath) {
    try { $Port = [int](Get-Content -LiteralPath $statePath -Encoding UTF8 -Raw | ConvertFrom-Json).port } catch { $Port = 0 }
  }
  if ($Port -le 0) { $Port = 45917 }
}

# ---------- 2) 解析 ----------
$raw = $Uri
$clean = $Uri.Trim().Trim('"').Trim()
Write-Log "RAW=$raw"

$kind = 'unknown'
$query = [ordered]@{}
try {
  if ($clean -match '^[a-zA-Z][a-zA-Z0-9+.\-]*://') {
    $u = [uri]$clean
    $kind = $u.Host.ToLowerInvariant()
    $q = $u.Query.TrimStart('?')
    if ($q) {
      foreach ($pair in ($q -split '&')) {
        if (-not $pair) { continue }
        $kv = $pair -split '=', 2
        $k = [uri]::UnescapeDataString($kv[0])
        $v = ''
        if ($kv.Count -gt 1) { $v = [uri]::UnescapeDataString($kv[1]) }
        $query[$k] = $v
      }
    }
  } else {
    Write-Log "WARN 不是合法 URI：$clean"
  }
} catch {
  Write-Log ('WARN URI 解析失败：' + $_.Exception.Message)
}

$action = ''
if ($query.Contains('action')) { $action = $query['action'] }
elseif ($kind -eq 'show') { $action = 'open' }
elseif ($kind -ne 'unknown') { $action = $kind }

$id = if ($query.Contains('id')) { $query['id'] } else { '' }
$text = ''
if ($query.Contains('replyText')) { $text = $query['replyText'] }
elseif ($query.Contains('text')) { $text = $query['text'] }
if (-not $text -and $action -eq 'reply') {
  # 兜底：如果 Windows 把输入框文本以别的 key 追加到 URI（key = <input id>），取第一个非保留参数。
  foreach ($k in $query.Keys) {
    if ($k -in @('action', 'id', 'kind', 'raw', 'source')) { continue }
    if ($query[$k]) { $text = $query[$k]; break }
  }
}

$keys = ($query.Keys -join ',')
Write-Log "PARSED kind=$kind action=$action id=$id text='$text' keys=$keys"

# ---------- 3) 组 payload ----------
$payload = [ordered]@{
  action     = $action
  id         = $id
  text       = $text
  kind       = $kind
  keys       = $keys
  raw        = $raw
  source     = 'dsh-desktop-notify-lab/handler.ps1'
  receivedAt = (Get-Date).ToString('o')
}

if ($NoPost) {
  Write-Log "NoPost：payload=$(($payload | ConvertTo-Json -Compress))"
  return
}

$json = $payload | ConvertTo-Json -Compress
$url = "http://127.0.0.1:$Port/action"
try {
  $resp = Invoke-RestMethod -Uri $url -Method Post -Headers @{ 'x-dsh-desktop-notify' = '1' } `
    -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 4
  Write-Log ('POST {0} ok -> {1}' -f $url, ($resp | ConvertTo-Json -Compress))
} catch {
  $err = $_.Exception.Message
  Write-Log ('POST {0} 失败：{1}' -f $url, $err)
  $pendingPath = Join-Path $pendingDir ('{0}-{1}.json' -f (Get-Date -Format 'yyyyMMdd-HHmmss-fff'), ($action -replace '[^\w\-]', '_'))
  try {
    [System.IO.File]::WriteAllText($pendingPath, $json, $utf8)
    Write-Log "已保存待重放事件：$pendingPath"
  } catch {
    Write-Log ('保存待重放事件也失败：' + $_.Exception.Message)
  }
}
