# dsh-desktop-notify

在 Windows 通知里直接处理 DSH 的审批与提问：点一下按钮就放行、取消或作答，不用切回窗口。

- **审批气泡四按钮**：允许 / 本次会话允许 / 拒绝 / 去回复
- **提问选项一键作答**：2–4 个选项做成按钮，答案直接回传
- **去回复**：回到 DSH 前台并跳到对应会话
- **自动收起**：切回窗口撤气泡；气泡上作答后，应用内同一张卡片同步收起
- **完成 / 出错提醒**，任务栏图标带数字徽标
- **免管理员**：首次弹气泡自动注册，`uninstall.ps1` 一键清干净

支持 Windows 10/11 + DSH 桌面端；macOS 后端仅预留接口（未实现）。

> 验证状态（2026-11-22）：审批四按钮、提问选项、去回复切会话、回窗撤气泡、气泡作答后卡片自动收起、并发两条互不干扰，均已真机验证。

![审批气泡：四按钮](docs/toast-approval-shot.png)

## 目录

| 文件 | 作用 |
| --- | --- |
| `index.js` | 宿主半。旁听 `approval/request`、`user-questions/request`、`session/event`（`turn/end`，跳过 subagent 会话）与 `agent/error`，记下提醒并提供 HTTP/SSE 接口。 |
| `client.js` | 客户端半。审批/提问由宿主侧后端弹可点击气泡；这里负责 finish/error 的普通通知、任务栏点同步、以及「气泡已处理 → 撤掉应用内卡片」的 DOM 协作。 |
| `lib/raise-window.js` | 常驻 `powershell.exe` worker：`ITaskbarList3.SetOverlayIcon` 画任务栏点、`SetForegroundWindow` 提窗口。 |
| `cordis.patch.yml` | profile 里的插入行（`id: desktop-notify`）。 |
| `entry-10.js` | 版本化入口（`export * from './index.js?rev=10'`），配合 `?rev=N` 做模块缓存失效。 |
| `actionable/` | Windows 可点击通知后端：`show-toast.ps1` / `remove-toast.ps1` / `handler.cjs` / `install.ps1` / `uninstall.ps1` / `js/backends/`。 |

## 安装

本插件以 DSH bundle 的形式分发（`package.json` 的 `dsh.bundle.patch` 指向仓库里的 `cordis.patch.yml`）：

- **插件市场**（收录后）：DSH 侧栏 →「插件市场」→ 搜索 `dsh-desktop-notify` → 安装。
- **手动**：把本仓库放进 DSH profile 的依赖（本地开发用 `"dsh-desktop-notify": "link:E:/dsh-plugins/dsh-desktop-notify"`），并在 profile 的 bundle 列表里启用 `include:desktop-notify`，重启 DSH 桌面版。

## 什么时候提醒

| 触发 | 类别 | 任务栏点 |
| --- | --- | --- |
| 工具要你确认（审批） | approval | 黑底 + 数字 |
| DSH 有选择题等你答 | question | 黑底 + 数字 |
| 顶层会话一轮跑完（`session/event` 的 `turn/end`，subagent 会话跳过） | finish | 黑底数字 +1 |
| agent 报错 | error | 黑底数字 +1 |

- 同类提醒按 `key` 幂等（同一次审批不会重复弹）。
- 子 agent（subagent）会话跑完**不报**，避免一次任务刷屏；只报顶层会话。
- 你正看着 DSH 窗口时：提醒自动 ack，不弹 toast，点也立刻熄掉。

## 可点击通知（Windows）

| 审批气泡 | 提问气泡 | 应用内卡片 |
| --- | --- | --- |
| ![审批气泡：四按钮](docs/toast-approval-shot.png) | ![提问气泡：选项按钮](docs/toast-question-shot.png) | ![应用内卡片](docs/in-app-card-clean.png) |

> 左：审批气泡，四按钮直接放行/拒绝；中：提问气泡，选项点一下即作答；右：同一提问在应用内的卡片形态。两者会同时出现，先处理哪个都行。


右下角的气泡不再只是一条说明，可以直接在上面处理：

| 按钮 | 行为 |
| --- | --- |
| 允许 | 放行这一次，等同应用内卡片的「允许一次」。 |
| 本次会话允许 | 同一会话里**同类工具**不再弹气泡、直接放行（DSH 本身没有这个语义，由插件记着）。 |
| 拒绝 | 取消，命令不会执行。 |
| 去回复 | 把 DSH 提到前台并**跳到对应会话**，由你在窗口里作答（不代答）。 |

- 有 2–4 个选项的提问会把选项做成按钮，点一下直接作答；自由输入类仍然回应用内卡片。
- 点「允许 / 本次会话允许 / 拒绝」不会跳窗口，结果通过本地回传（`127.0.0.1:45917/action`）交回宿主。
- 你切回 DSH 窗口时，还挂着的气泡会被立刻撤掉（不用等它自己消失）。

### 注册（首次自动）

第一次弹气泡时插件会自己写注册表（HKCU，不需要管理员）：

| 键 | 内容 |
| --- | --- |
| `HKCU\Software\Classes\AppUserModelId\DshDesktopNotifyLab` | 气泡抬头显示名（`DeepSeek Harness`）与图标。 |
| `HKCU\Software\Classes\dsh-notify` | 协议激活，命令是 `"<wscript.exe>" //nologo "<...>\launch-handler.vbs" "%1"`（无控制台窗口；`install.ps1 -DirectNode` 可改回 node 直连，快 ~70ms 但会闪一下黑框）。 |

状态写在 `actionable/state/install.json`；清理跑 `actionable/uninstall.ps1`（需普通权限）。

### 已知限制

- **没有输入框**：Windows 协议激活（`dsh-notify://…`）不携带 toast 输入框里的文本（已实测），所以「回复」只能在窗口里打字。
- 通知进「通知中心」后按钮**还能点**（120 秒内有效）；超过 120 秒宿主已放弃等待，这时再点会被静默忽略。
- 改过抬头显示名后，Windows 会缓存旧名，需要重启一次 explorer（或改 AUMID）才刷新。
- 非 Windows 平台没有可点击后端，会退回普通 HTML5 通知（macOS 的 `terminal-notifier` 后端只留了接口，未实现）。
- **系统层面的静音**：开着「请勿打扰」、或「全屏应用/投影/游戏时自动勿扰」被勾选时，Windows 只把通知放进通知中心，不弹横幅。这不是插件能绕过的，验证时先确认这两处。

### 暂缓（下一次功能更新）

- **「去回复」的真输入框**：Windows 协议激活拿不到 toast 输入框里的文本（实测），要做只能自建 COM 激活器并注册新的 AUMID，本轮不做；现在的「去回复」是把窗口提起来并跳到对应会话，由你在窗口里作答。
- **macOS 后端**：`actionable/js/backends/darwin.js` 只有桩（返回 `unsupported`），按约定只留接口。

## HTTP 接口

前缀 `http://127.0.0.1:<port>/dsh-desktop-notify/`，所有请求必须带请求头
`x-dsh-desktop-notify: 1`（缺头 403；自定义头让跨站请求必须预检，服务端不回 CORS 头，所以外部网页打不进来）。

| 动作 | 说明 |
| --- | --- |
| `GET /events` | SSE 推提醒（`event: alert`），客户端首选通道 |
| `POST /state` | `{since: n}` → 游标 + 新提醒（轮询兜底，客户端 5s 一次） |
| `POST /ack` | 用户正在看窗口，熄灯 |
| `POST /raise` | 把 DSH 窗口提到前台 |
| `POST /report` | 客户端诊断上报（toast 到底弹没弹、为什么没弹） |
| `POST /test` | 自测：`{kind,title,body}` 造提醒；`{overlay:"alert"|"green"|"red"|"none", label:"1", pulse:true}` 直接画徽标（`pulse` 先呼吸放大一次） |
| `POST /ping` | 体检：badge / pending / events / subscribers / worker / lastReport |

## 自测

```powershell
$h = @{ 'x-dsh-desktop-notify' = '1'; 'content-type' = 'application/json; charset=utf-8' }
$body = '{"kind":"approval","title":"需要你的确认","body":"这条会停留几秒。"}'
Invoke-WebRequest -Uri 'http://127.0.0.1:60506/dsh-desktop-notify/test' -Method Post -Headers $h `
  -Body ([System.Text.Encoding]::UTF8.GetBytes($body)) -TimeoutSec 10 -UseBasicParsing | Select-Object -Expand Content

# 只画任务栏徽标（会先呼吸放大一次，不弹 toast）
Invoke-WebRequest -Uri 'http://127.0.0.1:60506/dsh-desktop-notify/test' -Method Post -Headers $h `
  -Body ([System.Text.Encoding]::UTF8.GetBytes('{"overlay":"alert","label":"1","pulse":true}')) -TimeoutSec 10 -UseBasicParsing | Select-Object -Expand Content
```

中文 body 必须传**字节**（`UTF8.GetBytes`），直接传字符串 PowerShell 会把它变成 `?`。

## 排障

- `/ping` 的 `subscribers` 应为 1；是 0 说明页面里的客户端半没挂上。
- `raiserRunning/raiserReady` 应为 `true`；`lastReply` 是 worker 最近一句回话（`READY` 表示 C# 类型编译成功）。
- `lastReport` 是客户端最近一次自述：`stage: shown` 就是 toast 真弹出来了，`no-api/denied/construct-failed` 则是没弹的原因。
- **注意**：DSH 文件沙箱内跑 `Add-Type` 会报 `A required privilege is not held by the client`；worker 由 Host 进程拉起，不受该限制，别拿沙箱里的 PowerShell 结果判断 worker 坏了。

## 重载

- 宿主半：`plugin_manager set_plugin target=include:desktop-notify enabled=false` 再 `true`。
- 客户端半：改一下 `client.js` 的 mtime（`(Get-Item client.js).LastWriteTime = Get-Date`）会触发客户端 HMR，
  不用刷新页面；宿主半重载会把客户端半卸载，重载后再 touch 一次即可。
## 开发注意（改完代码怎么让它生效）

DSH 重载插件时不会重新求值已经加载过的模块 URL（disable/enable、remove+install 都不会），所以：

- **改 `index.js`**：新建一个出口文件（`entry-3.js`、`entry-4.js` …，内容只有 `export * from './index.js?rev=N'`），把 `package.json` 的 `exports["."]` 指过去，再 `remove_bundle` + `install_bundle`。
- **改 `lib/raise-window.js`**：把 `index.js` 顶部那条 import 的 `?rev=` 加一。
- **改 `client.js`**：`(Get-Item client.js).LastWriteTime = Get-Date` 触发页面侧 HMR，`/ping` 的 `subscribers` 会回到 1。
- 每次重载后先轮询 `/ping`，等 `raiserReady: true` 再发 `/test` 指令。

## 观感

- 徽标：黑底白字数字（N 件要处理的事——等拍板的、刚跑完的、出错的全都合并计数，不区分颜色）；状态切换时先呼吸放大一次（约 0.4s）。
- 通知：没人点时 6 秒自动消失（`client.js` 的 `AUTO_CLOSE_MS`）；点一下会关掉并把 DSH 窗口提到前台。

## 自测记录

- 2026-11-15：真实审批弹窗链路（这次写入就是触发点）、统一黑底数字徽标、卡片 6 秒自动消失、点窗口/点通知熄灯、DSH 重启后自动恢复。
- 2026-11-15 18:39：跨会话弹窗验证——用户切到别的对话窗口时，这个审批请求应当把右下角卡片弹出来。

## 什么时候弹、什么时候不弹

- **审批 / 提问**（kind 为 pproval / question）：永远弹。你人可能在 DSH 里看着**别的会话**，客户端没法知道你在看哪个，所以这类提醒不套用「前台静默」。
- **运行结束 / 出错**：窗口在前台且有焦点时静默（只点任务栏徽标），切到别的窗口才弹。
- 自测事件（/test 推的  est:true）一律弹，方便验证链路。
