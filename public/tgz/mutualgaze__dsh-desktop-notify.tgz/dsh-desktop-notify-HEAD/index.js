/**
 * dsh-desktop-notify —— 宿主半
 *
 * 三件事：
 *
 * 1. **盯着「需要你确认」**：监听 approval/request 与 user-questions/request 两条
 *    waterfall 事件，把「有个决定在等你」折叠成一条提醒；等决定落地（next() 结算）
 *    再撤回。绝不改变请求本身的走向：只在旁边记录，然后原样交给 next()。
 *
 * 2. **盯着「运行结束 / 出错」**：监听 api-session/status（(sessionId, running)）与
 *    agent/error，在 running 由 true 变 false 时记一条「运行结束」，出错时记「运行出错」。
 *
 * 3. **把状态送到两个地方**：
 *    - 任务栏：ITaskbarList3.SetOverlayIcon，黑底数字 = 有决定等你 / 红 = 报错 / 绿 = 跑完了
 *      （见 lib/raise-window.js；进程号取宿主进程的 ppid = Electron 主进程）。
 *    - 页面：注册一条内部路由，客户端半用 SSE 或轮询取提醒，再用 HTML5 Notification
 *      弹出 Windows 通知（渲染进程才有 Notification，宿主这边没有）。
 *
 * 为什么提醒的判定放在宿主半而不是客户端半：客户端拿不到「上一轮为什么结束」，
 * 而宿主半的 api-session/status、approval/request、agent/error 对**所有**会话都成立，
 * 不依赖某个会话是否被打开。
 *
 * 路由约定：客户端用**文档相对**路径请求（不带前导斜杠），桌面端页面是 dsh-app://app/，
 * 其非静态路径由 shell 同源转发到宿主；Web 端页面带 base href，相对路径落在部署前缀下。
 * 状态变更类动作要求自定义签名头：自定义头会把跨站请求升级成需要预检的请求，
 * 本服务不返回任何 Access-Control-Allow-*，于是其它网页的请求根本到不了 handler。
 *
 * @module dsh-desktop-notify
 */

import { readFileSync } from 'node:fs'
// 注意：DSH 重载插件时不会重新 import 相对模块（ESM 按 URL 缓存）。
// 改过 lib/raise-window.js 之后，必须把下面的 ?rev= 加一，重载才会拿到新代码。
import {
  createWindowRaiser,
  isOverlayState,
  resolveTargetProcessId,
} from './lib/raise-window.js?rev=6'
// 可点击通知的后端（Windows 真实现；macOS 桩；其它平台 noop）。
// 注意：改了 actionable/ 里的文件后，同样要把 ?rev= 加一，重载才会拿到新代码。
import { createBackend, capabilitiesFor, DECISIONS } from './actionable/js/backends/index.js?rev=1'

/** Cordis 插件名（诊断与 patch 行定位用）。 */
export const name = 'desktop-notify'

/** 路由前缀（客户端用相对路径 `dsh-desktop-notify/...` 访问）。 */
export const ROUTE_PATH = '/dsh-desktop-notify'

/** 状态变更类请求必须携带的签名头。 */
export const ROUTE_HEADER = 'x-dsh-desktop-notify'
export const ROUTE_HEADER_VALUE = '1'

/** 单次请求体上限：只接受几十字节的 JSON。 */
const MAX_BODY_BYTES = 4096

/** 内存里最多留多少条提醒（够页面刷新后补看，不会无限涨）。 */
const MAX_EVENTS = 60

/** SSE 心跳间隔。 */
const HEARTBEAT_MS = 20_000

/** 单条文案的截断上限。 */
const TITLE_LIMIT = 120
const BODY_LIMIT = 300

/** 通知等用户点按钮的时长；超时后回到应用内卡片继续等。 */
const NOTIFY_TIMEOUT_MS = 120_000

/** 宿主半版本，直接读同目录 package.json（单一事实来源）。 */
const VERSION = (() => {
  try {
    const pkg = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8'))
    return typeof pkg.version === 'string' && pkg.version !== '' ? pkg.version : 'unknown'
  } catch {
    return 'unknown'
  }
})()

/** 把任意值截成有界字符串。 */
function text(value, limit) {
  if (typeof value !== 'string') return ''
  return value.length > limit ? `${value.slice(0, limit)}…` : value
}

/** 判断请求是否带了签名头（node 会把重复头合并成数组）。 */
function hasRouteHeader(req) {
  const headers = req?.headers
  if (headers === null || typeof headers !== 'object') return false
  const value = headers[ROUTE_HEADER]
  if (typeof value === 'string') return value === ROUTE_HEADER_VALUE
  return Array.isArray(value) && value.includes(ROUTE_HEADER_VALUE)
}

/** 写一个 JSON 响应。 */
function respond(res, status, body) {
  try {
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    })
    res.end(JSON.stringify(body))
  } catch {
    /* 连接已经断了 */
  }
}

/** 读一个小 JSON 请求体。 */
function readJsonBody(req, done) {
  const chunks = []
  let size = 0
  let settled = false
  const finish = (error, body) => {
    if (settled) return
    settled = true
    done(error, body)
  }
  req.on?.('data', (chunk) => {
    if (settled) return
    size += chunk.length
    if (size > MAX_BODY_BYTES) {
      finish('too-large', undefined)
      try {
        req.destroy?.()
      } catch {
        /* 已经断开 */
      }
      return
    }
    chunks.push(chunk)
  })
  req.on?.('error', () => finish('read-error', undefined))
  req.on?.('end', () => {
    if (settled) return
    try {
      const raw = Buffer.concat(chunks).toString('utf8')
      const body = raw === '' ? {} : JSON.parse(raw)
      if (body === null || typeof body !== 'object' || Array.isArray(body)) {
        finish('invalid-json', undefined)
        return
      }
      finish(null, body)
    } catch {
      finish('invalid-json', undefined)
    }
  })
}

/**
 * Cordis 插件入口。
 * @param {object} ctx 根上下文。
 */
export function apply(ctx) {
  const raiser = createWindowRaiser({
    onWarn: (message, error) => {
      ctx.logger?.warn?.(`${message}${error === undefined ? '' : `：${String(error)}`}`)
    },
  })

  /**
   * 可点击通知后端。
   *
   * 宿主半跑在 Electron 主进程里（普通用户令牌），所以能把 WinRT toast 弹出来、
   * 也能在第一次用到时把 AUMID 与 dsh-notify 协议写进 HKCU。
   * 其它平台拿到的是桩/空后端（capabilities().buttons === false），行为与旧版一致。
   */
  const notifyBackend = (() => {
    try {
      return createBackend({ platform: process.platform })
    } catch (error) {
      ctx.logger?.warn?.(`[desktop-notify] 通知后端创建失败，退回 HTML5 通知：${String(error)}`)
      return null
    }
  })()
  // 「去回复」：后端默认用 WScript.Shell.AppActivate(pid) 提窗口，在 Electron 里不可靠；
  // 改成复用插件自己的 raiser（Win32 SetForegroundWindow + AttachThreadInput，已知有效）。
  if (notifyBackend !== null) {
    try {
      notifyBackend.raiseImpl = () => {
        const target = resolveTargetProcessId()
        if (target === undefined) return false
        return raiser.raise(target) === true
      }
    } catch {
      /* 保持后端默认实现 */
    }
  }

  const backendCaps = (() => {
    try {
      return notifyBackend?.capabilities() ?? capabilitiesFor(process.platform)
    } catch {
      return { buttons: false, reply: false, badge: false, raise: false }
    }
  })()
  /** 用户点过「本次会话允许」的 `sessionId:toolName`。 */
  const sessionAllowed = new Set()

  /** 客户端最近一次自报「窗口在前台」的时间：眼前已有卡片就不再弹气泡。 */
  let lastFocusedAt = 0
  /** 最近一次「去回复」要切到的会话；/state 兜底下发，SSE 断线时也能切。 */
  let lastFocus = null
  /** 当前挂着的所有气泡：key -> { at }。并发审批/提问各记各的，回窗时一并撤。 */
  const openToasts = new Map()

  /**
   * 撤掉正在显示的气泡（双通道互通：应用内先处理掉时调用）。
   * explicitKey 用在「气泡已经让出 openToastKey、但还要补撤一次」的场景：
   * 提问气泡应用内先答时，spawn PowerShell 要几百毫秒，气泡可能还没冒出来。
   */
  /** 撤掉一条气泡（按它自己的 key），撤到了返回 true。 */
  function dismissToast(key, reason) {
    if (typeof key !== 'string' || key === '') return false
    if (!openToasts.has(key)) return false
    openToasts.delete(key)
    try {
      notifyBackend?.dismiss?.(key)
      ctx.logger?.info?.(`[desktop-notify] 撤掉气泡（${String(reason)}）`)
    } catch {
      /* 撤气泡失败不影响审批本身 */
    }
    return true
  }

  /**
   * 撤气泡。
   * - 不传 explicitKey：把所有还挂着的气泡都撤掉（窗口回到前台时用）。
   * - 传 explicitKey：只撤那一条（应用内先处理、补撤时用），不会误撤别人的。
   */
  function dismissOpenToast(reason, explicitKey) {
    if (explicitKey !== undefined) return dismissToast(explicitKey, reason) ? 1 : 0
    let count = 0
    for (const key of [...openToasts.keys()]) {
      if (dismissToast(key, reason)) count += 1
    }
    return count
  }

  /** 递增的提醒 id（事件游标）。 */
  let seq = 0
  /** 最近若干条提醒；`ack` 表示用户已经看过。 */
  const events = []
  /** 打开的「等待决定」：key -> { at, kind, sessionId }。 */
  const pending = new Map()
  /** 每个会话上一次的 running 状态。 */
  const runningState = new Map()
  /** 当前托盘点颜色；`none` 表示没点。 */
  let badge = 'none'
  /** 徽标上显示的数字（alert 时生效）。 */
  let badgeCount = 0
  /** SSE 订阅者。 */
  const subscribers = new Set()
  /** 是否已经 dispose。 */
  let disposed = false
  /** 客户端上报的通知结果（诊断用：Windows 通知失败时这里能看到原因）。 */
  let lastReport = null
  /** 最近的客户端上报（环形，最多 12 条；跳过心跳类，只留「为什么灭了」这种线索）。 */
  const recentReports = []
  const NOISY_STAGES = new Set(['poll', 'hello', 'sse', 'boot'])
  /** 最近一个 SSE 订阅者自报的客户端版本。 */
  let subscriberVersion = null

  /**
   * 算出「现在该亮什么状态、圈里写几」。
   *
   * 跑完和「有决定等你」用同一种黑底数字圈：用户要的就是一眼看到「有几件事没看」。
   * 只有出错仍然用红色叹号，因为那件事的性质不同、必须更刺眼。
   */
  function desiredBadge() {
    // 用户的要求：所有提醒都只表达「有几件事等你处理」——
    // 审批/提问/跑完/出错统一合并成一个黑底数字圈，不再区分颜色。
    let count = pending.size
    for (const event of events) {
      if (event.ack) continue
      if (event.kind === 'finish' || event.kind === 'error') count += 1
    }
    if (count === 0) return { state: 'none', count: 0 }
    return { state: 'alert', count }
  }

  /** 徽标上要画的字符：黑底用数字（几件事等你），红色叹号，绿色对勾。 */
  function badgeLabel(state, count) {
    if (state === 'alert') return count > 9 ? '9+' : String(Math.max(count, 1))
    if (state === 'red') return '!'
    if (state === 'green') return 'check'
    return ''
  }

  /** 把算出来的颜色刷到任务栏（只在变化时发指令）。 */
  function applyBadge() {
    if (disposed) return
    const want = desiredBadge()
    if (want.state === badge && want.count === badgeCount) return
    const changed = want.state !== badge
    badge = want.state
    badgeCount = want.count
    const target = resolveTargetProcessId()
    if (target === undefined) return
    raiser.overlay(want.state, target, badgeLabel(want.state, want.count), changed && want.state !== 'none')
  }

  /** 向所有 SSE 订阅者推一条自定义事件。 */
  function broadcastNamed(name, payload) {
    const frame = `event: ${name}\ndata: ${JSON.stringify(payload)}\n\n`
    for (const res of subscribers) {
      try {
        res.write(frame)
      } catch {
        subscribers.delete(res)
      }
    }
  }

  /**
   * 让前端替用户把这条审批对应的应用内卡片点掉。
   * 气泡先给答案时，应用内卡片是 DSH 客户端自己的本地等待，宿主侧没有远程关闭接口；
   * 只能把决定告诉客户端，由它在 DOM 里点一下同一张卡片上的按钮，让宿主 UI 正常收尾。
   */
  function dismissInAppCard(reason, toolName, decision) {
    const text = String(reason ?? '').trim()
    const match = text === '' ? String(toolName ?? '').trim() : text.slice(0, 120)
    if (match === '') return
    broadcastNamed('ui-dismiss', { match, decision })
  }

    /** 气泡里点了「去回复」：让前端把窗口切到这条审批所属的会话。 */
  function focusSession(sessionId) {
    if (sessionId === undefined || sessionId === null) return
    const at = Date.now()
    lastFocus = { sessionId: String(sessionId), at }
    broadcastNamed('focus', lastFocus)
  }

/** 向所有 SSE 订阅者推一条。 */
  function broadcast(event) {
    const frame = `event: alert\ndata: ${JSON.stringify(event)}\n\n`
    for (const res of subscribers) {
      try {
        res.write(frame)
      } catch {
        subscribers.delete(res)
      }
    }
  }

  /**
   * 记一条提醒。
   * @param {'approval'|'question'|'finish'|'error'} kind 类别。
   * @param {string} title 标题。
   * @param {string} body 正文。
   * @param {string|null} sessionId 归属会话。
   * @param {string|null} [key] 决定类提醒的幂等键。
   */
  function push(kind, title, body, sessionId, key = null, extra = null) {
    if (disposed) return null
    const event = {
      id: ++seq,
      kind,
      title: text(title, TITLE_LIMIT),
      body: text(body, BODY_LIMIT),
      sessionId: sessionId === null || sessionId === undefined ? null : String(sessionId),
      key,
      at: Date.now(),
      ack: false,
    }
    if (extra !== null) Object.assign(event, extra)
    events.push(event)
    while (events.length > MAX_EVENTS) events.shift()
    broadcast(event)
    applyBadge()
    return event
  }

  /** 一条「等待决定」开始了。 */
  function openPending(kind, sessionId, key) {
    pending.set(key, { at: Date.now(), kind, sessionId })
    applyBadge()
  }

  /** 一条「等待决定」结束了。 */
  function closePending(key) {
    if (pending.delete(key)) applyBadge()
  }

  /**
   * approval/request 的旁听：先记一笔，再原样 next()。
   *
   * 这条是 waterfall，任何监听者抛错都会把审批流程带崩（用户就再也点不了确认），
   * 所以这里所有自己的动作都包在 try/catch 里，最后一定把 next() 的 Promise 原样返回。
   */
  function onApprovalRequest(req, next) {
    let key = null
    let sessionId = null
    let toolName = '工具'
    let reason = ''
    try {
      sessionId = req?.agent?.id ?? null
      toolName = text(req?.toolName ?? '工具', 60)
      reason = text(
        req?.displayReason?.zh ?? req?.displayReason?.en ?? req?.reason ?? '',
        BODY_LIMIT,
      )
      key = `approval:${String(sessionId)}:${String(req?.callId ?? toolName)}`
      if (!pending.has(key)) {
        openPending('approval', sessionId, key)
        push(
          'approval',
          '需要你的确认',
          reason === '' ? `${toolName} 正在等你确认` : `${toolName}：${reason}`,
          sessionId,
          key,
        )
      }
    } catch {
      /* 旁听失败绝不能影响审批本身 */
    }
    const settle = () => {
      try {
        if (key !== null) closePending(key)
      } catch {
        /* 同上 */
      }
    }

    const allowKey = `${String(sessionId)}:${toolName}`

    // 用户点过「本次会话允许」：同一会话、同一工具的后续审批直接放行，不再弹卡片。
    if (backendCaps.buttons && sessionAllowed.has(allowKey)) {
      settle()
      ctx.logger?.info?.(`[desktop-notify] 本次会话允许命中：${allowKey}`)
      return Promise.resolve('allowed-once')
    }

    // 双通道并行（用户要求：DSH 不在前台时卡片和气泡一起出现）：
    // 应用内卡片立即放行，同时弹气泡；谁先给出答案就用谁的。
    let uiStarted = null
    const startUi = () => {
      if (uiStarted !== null) return uiStarted
      try {
        uiStarted = Promise.resolve(next()).then((value) => ({ source: 'ui', value }))
      } catch (error) {
        uiStarted = Promise.reject(error)
      }
      uiStarted.catch(() => {})
      return uiStarted
    }

    const uiStartedPromise = startUi()

    // 窗口就在眼前 / 没有按钮后端：只用应用内卡片，和旧行为一致。
    if (!backendCaps.buttons || notifyBackend === null || Date.now() - lastFocusedAt < 3_000) {
      return uiStartedPromise.then(
        (hit) => {
          settle()
          return hit.value
        },
        (error) => {
          settle()
          throw error
        },
      )
    }

    if (key !== null) openToasts.set(key, { at: Date.now() })
    const toastResult = notifyBackend
      .notify({
        kind: 'approval',
        title: '需要你的确认',
        body: reason === '' ? `${toolName} 正在等你确认` : `${toolName}：${reason}`,
        sessionId: sessionId === null ? undefined : String(sessionId),
        eventId: key ?? `approval:${String(sessionId)}:${Date.now().toString(36)}`,
        actions: {
          allow: '允许',
          sessionAllow: '本次会话允许',
          deny: '拒绝',
          reply: '去回复',
        },
        timeoutMs: NOTIFY_TIMEOUT_MS,
      })
      .then(
        (result) => ({ source: 'toast', result }),
        () => ({ source: 'toast', result: { decision: 'unsupported' } }),
      )

    // 谁先到：卡片点了 → 撤气泡；气泡点了 → 直接结算。
    // 气泡先给答案时，应用内卡片是客户端自己的本地等待，宿主侧没有远程关闭接口，
    // 所以把决定推给前端，由它点掉卡片上对应的按钮（dismissInAppCard → client.js）。
    return Promise.race([toastResult, uiStartedPromise]).then(
      async (winner) => {
        if (winner.source === 'ui') {
          if (key !== null) {
            dismissOpenToast('应用内先处理', key)
            // 气泡可能还没被 PowerShell 拉起来：1.5 秒后再撤一次（绕过 Map 守卫）。
            try {
              const timer = typeof setTimeout === 'function' ? setTimeout : null
              if (timer !== null) {
                timer(() => {
                  try {
                    notifyBackend?.dismiss?.(key)
                  } catch {
                    /* 尽力而为 */
                  }
                }, 1500).unref?.()
              }
            } catch {
              /* 同上 */
            }
          }
          settle()
          return winner.value
        }
        if (key !== null) dismissOpenToast('气泡已结算', key)
        const decision = winner.result?.decision
        if (decision === DECISIONS.ALLOW || decision === DECISIONS.ALLOW_SESSION) {
          if (decision === DECISIONS.ALLOW_SESSION) sessionAllowed.add(allowKey)
          dismissInAppCard(reason, toolName, 'allow')
          settle()
          return 'allowed-once'
        }
        if (decision === DECISIONS.DENY) {
          dismissInAppCard(reason, toolName, 'deny')
          settle()
          return 'rejected'
        }
        // reply / dismissed / timeout / unsupported：等应用内卡片给答案。
        // 「去回复」额外让前端把窗口切到这条审批的会话（提窗由后端 raiseWindow 负责）。
        if (decision === DECISIONS.REPLY) focusSession(sessionId)
        const hit = await uiStartedPromise
        settle()
        return hit.value
      },
      (error) => {
        if (key !== null) dismissOpenToast('气泡出错', key)
        settle()
        throw error
      },
    )
  }

  /** user-questions/request 的旁听（同样只旁听、不改变走向）。 */
  function onUserQuestionRequest(req, next) {
    const sessionId = req?.agent?.id ?? null
    const first = Array.isArray(req?.questions) ? req.questions[0] : undefined
    const kind = first?.intent?.kind
    const title = kind === 'plan-review' ? '计划等你批准' : 'DSH 在等你回答'
    const question = text(first?.question ?? first?.header ?? '', BODY_LIMIT)
    const options = Array.isArray(first?.options)
      ? first.options
          .map((option, index) => {
            const label = text(option?.label ?? option?.title ?? option?.value ?? '', 40)
            const id = String(option?.value ?? option?.label ?? index)
            return label === '' ? null : { id, label }
          })
          .filter(Boolean)
      : []
    const choices = options.length >= 2 && options.length <= 4 ? options : []
    let key = null
    try {
      key = `question:${String(sessionId)}:${String(req?.wait?.callId ?? question)}`
      if (!pending.has(key)) {
        openPending('question', sessionId, key)
        push(
          'question',
          title,
          question === '' ? '有一个问题需要你回答' : question,
          sessionId,
          key,
        )
      }
    } catch {
      /* 旁听失败绝不能影响问答本身 */
    }
    const settle = () => {
      try {
        if (key !== null) closePending(key)
      } catch {
        /* 同上 */
      }
    }
    const startUi = () => {
      try {
        return Promise.resolve(next()).then((value) => ({ source: 'ui', value }))
      } catch (error) {
        return Promise.reject(error)
      }
    }

    if (notifyBackend === null || backendCaps.buttons !== true || choices.length === 0) {
      let answer
      try {
        answer = next()
      } catch (error) {
        settle()
        throw error
      }
      return Promise.resolve(answer).then(
        (value) => {
          settle()
          return value
        },
        (error) => {
          settle()
          throw error
        },
      )
    }

    // 带上选项按钮的气泡：气泡先答就用气泡；气泡不答再回落到应用内卡片。
    // 先登记成「当前挂着的气泡」：应用内先答、窗口回到前台（/state focused）时
    // 都要能把它撤掉；提问没有「去回复」语义，openToastStartUi 置空。
    if (key !== null) openToasts.set(key, { at: Date.now() })
    const uiResult = startUi()
    uiResult.catch(() => {})
    const toastResult = notifyBackend
      .notify({
        kind: 'question',
        title,
        body: question === '' ? '有一个问题需要你回答' : question,
        sessionId,
        eventId: key,
        choices,
        timeoutMs: NOTIFY_TIMEOUT_MS,
      })
      .catch(() => ({ decision: DECISIONS.UNSUPPORTED }))

    return Promise.race([uiResult, toastResult]).then(
      async (winner) => {
        if (winner && winner.source === 'ui') {
          // 气泡是异步拉起来的（spawn PowerShell 要几百毫秒），应用内先答完时
          // 立刻撤一次、再等一会儿补撤一次，免得气泡在答案之后才冒出来。
          // 出口先清登记，补撤用这条问题自己的 key（dismissOpenToast 的 explicitKey）。
          const dismissedKey = key
          try {
            if (dismissedKey !== null) dismissOpenToast('应用内先处理', dismissedKey)
          } catch {
            /* 同样是尽力而为 */
          }
          try {
            const timer = typeof setTimeout === 'function' ? setTimeout : null
            if (timer !== null) {
              timer(() => {
                try {
                  // 绕过 Map 守卫：这条气泡此时已经被摘掉了，但 PowerShell 可能刚把它拉起来。
                  notifyBackend?.dismiss?.(dismissedKey)
                } catch {
                  /* 同上 */
                }
              }, 1500).unref?.()
            }
          } catch {
            /* 同上 */
          }
          settle()
          return winner.value
        }
        if (winner && winner.decision === DECISIONS.CHOICE) {
          // 气泡已经收回去了，登记跟着清掉（顺手撤一次是幂等的）。
          if (key !== null) dismissOpenToast('气泡已作答', key)
          settle()
          const chosen = choices.find((item) => item.id === winner.choiceId) ?? choices[0]
          try {
            // 气泡答完了，应用内那张卡片还在：让客户端按问题文本找到它，点同一个选项再提交。
            if (question !== '') {
              broadcastNamed('ui-dismiss-question', { match: question, label: chosen.label })
            }
          } catch {
            /* 尽力而为 */
          }
          return {
            answers: [{ id: String(first?.id ?? first?.questionId ?? 'answer'), selected: [chosen.id] }],
          }
        }
        try {
          if (key !== null) dismissOpenToast('回到卡片处理', key)
        } catch {
          /* 尽力而为 */
        }
        const fallback = await uiResult
        settle()
        return fallback.value
      },
      (error) => {
        if (key !== null) dismissOpenToast('气泡出错', key)
        settle()
        throw error
      },
    )
  }
  /** 只给顶层会话发「跑完了」——子 agent 的会话由父会话汇总，避免一次任务刷屏。 */
  function isRootSession(sessionId) {
    try {
      const agents = ctx.get('agents')
      if (!agents || typeof agents.roots !== 'function') return true
      const roots = agents.roots()
      if (!Array.isArray(roots) || roots.length === 0) return true
      return roots.some((agent) => String(agent?.id) === sessionId)
    } catch {
      return true
    }
  }

  /** api-session/status：running 由 true 变 false 就是「这一轮跑完了」。 */
  function onSessionStatus(sessionId, isRunning) {
    try {
      const id = String(sessionId)
      const was = runningState.get(id) ?? false
      runningState.set(id, isRunning === true)
      if (was && isRunning !== true && isRootSession(id)) {
        push('finish', '任务完成', '这一轮已经结束，点开看看结果。', id)
      }
    } catch {
      /* 忽略 */
    }
  }

  /** session/event：turn/end 才是「这一轮跑完了」的权威信号（api-session/status 要先见过 running=true，插件重载后的第一轮会漏）。 */
  function onSessionEvent(a, b) {
    try {
      const session = a && a.header ? a : b
      const event = a && typeof a.type === 'string' ? a : b
      if (!event || event.type !== 'turn/end') return
      const header = session?.header
      if (header?.origin === 'subagent' || header?.parentSession !== undefined) return
      const id = String(session?.id ?? '')
      const reason = event?.data?.reason
      const kind = reason?.kind
      if (kind === 'aborted' || kind === 'interrupted' || kind === 'forked') return
      if (kind === 'error') {
        const message = text(reason?.error?.message ?? '运行出错', BODY_LIMIT)
        push('error', '运行出错', message === '' ? '运行出错了，点开看看。' : message, id)
        return
      }
      push('finish', '任务完成', '这一轮已经结束，点开看看结果。', id)
    } catch {
      /* 忽略 */
    }
  }

  /** agent/error：出错时红点。 */
  function onAgentError(payload) {
    try {
      const sessionId = payload?.agent?.id ?? null
      const raw = payload?.error
      const message = typeof raw === 'string'
        ? raw
        : text(raw?.message ?? raw?.code ?? '运行出错', BODY_LIMIT)
      push('error', '运行出错', message === '' ? '运行出错了，点开看看。' : message, sessionId)
    } catch {
      /* 忽略 */
    }
  }

  /** 挂一个监听，注册失败只记日志（缺服务/缺事件时插件其余功能照常）。 */
  function listen(event, handler) {
    try {
      ctx.effect(() => ctx.on(event, handler), `desktop-notify: ${event}`)
    } catch (error) {
      ctx.logger?.warn?.(`[desktop-notify] 监听 ${event} 失败：${String(error)}`)
    }
  }

  // ---- 旁听：需要你确认 ----
  listen('approval/request', onApprovalRequest)
  listen('user-questions/request', onUserQuestionRequest)
  // ---- 旁听：跑完了 / 出错了 ----
  listen('session/event', onSessionEvent)
  listen('agent/error', onAgentError)

  // ---- SSE：页面用 EventSource('dsh-desktop-notify/events') 订阅 ----
  function openStream(req, res) {
    try {
      const match = /[?&]v=([^&]+)/.exec(String(req.url ?? ''))
      if (match !== null) subscriberVersion = decodeURIComponent(match[1]).slice(0, 40)
    } catch {
      /* 版本号只是诊断信息 */
    }
    res.writeHead(200, {
      'content-type': 'text/event-stream; charset=utf-8',
      'cache-control': 'no-store, no-transform',
      connection: 'keep-alive',
      'x-accel-buffering': 'no',
    })
    res.flushHeaders?.()
    res.write(': connected\n\n')
    res.write(`event: hello\ndata: ${JSON.stringify({ cursor: seq, badge })}\n\n`)
    subscribers.add(res)
    const timer = setInterval(() => {
      try {
        res.write(': ping\n\n')
      } catch {
        /* 断开由 close 处理 */
      }
    }, HEARTBEAT_MS)
    const cleanup = () => {
      clearInterval(timer)
      subscribers.delete(res)
    }
    req.on?.('close', cleanup)
    req.on?.('error', cleanup)
    res.on?.('error', cleanup)
  }

  /** 内部路由：ping / state / ack / raise / test。 */
  function handler(req, res) {
    const raw = typeof req.url === 'string' ? req.url : '/'
    const path = raw.split('?')[0]
    const action = path.startsWith(`${ROUTE_PATH}/`) ? path.slice(ROUTE_PATH.length + 1) : ''

    // SSE 没法带自定义头（EventSource 不支持），它只读、只推提醒本身，不碰状态。
    if (req.method === 'GET' && action === 'events') {
      openStream(req, res)
      return
    }

    if (req.method !== 'POST') {
      respond(res, 405, { error: 'method-not-allowed' })
      return
    }
    if (!hasRouteHeader(req)) {
      req.resume?.()
      respond(res, 403, { error: 'forbidden', reason: 'missing-header' })
      return
    }

    if (action === 'ping') {
      req.resume?.()
      respond(res, 200, {
        host: 'dsh-desktop-notify',
        version: VERSION,
        badge,
        pending: pending.size,
        events: events.length,
        subscribers: subscribers.size,
        subscriberVersion,
        raiserRunning: raiser.isRunning(),
        raiserReady: raiser.isReady(),
        lastReply: raiser.lastReply(),
        lastReport,
        recentReports,
        worker: 'v5',
        platform: process.platform,
        capabilities: backendCaps,
        targetProcessId: resolveTargetProcessId() ?? null,
      })
      return
    }

    if (action === 'state') {
      readJsonBody(req, (error, body) => {
        if (error !== null) {
          respond(res, error === 'too-large' ? 413 : 400, { ok: false, reason: error })
          return
        }
        const since = Number.isInteger(body?.since) ? body.since : -1
        // 客户端每轮轮询都会带 focused：回到窗口前，就把还挂着的气泡收掉。
        if (body?.focused === true) {
          lastFocusedAt = Date.now()
          if (openToasts.size > 0) {
            dismissOpenToast('窗口回到前台')
          }
        }
        respond(res, 200, {
          ok: true,
          cursor: seq,
          badge,
          pending: pending.size,
          platform: process.platform,
          capabilities: backendCaps,
          // 宿主半自己会弹的提醒类别：客户端半别跟着再弹一遍。
          hostKinds: backendCaps.buttons ? ['approval', 'question'] : [],
          // 最近 15 秒内的「去回复」目标：SSE 断线时客户端靠轮询兜底切会话。
          focus: lastFocus !== null && Date.now() - lastFocus.at < 15_000 ? lastFocus : null,
          // since < 0 表示「只给我游标，不要回放历史」——页面刚加载时用。
          events: since < 0 ? [] : events.filter((event) => event.id > since),
        })
      })
      return
    }

    if (action === 'ack') {
      readJsonBody(req, (error) => {
        if (error !== null) {
          respond(res, 400, { ok: false, reason: error })
          return
        }
        for (const event of events) event.ack = true
        applyBadge()
        respond(res, 200, { ok: true, badge })
      })
      return
    }

    if (action === 'raise') {
      req.resume?.()
      const target = resolveTargetProcessId()
      if (target === undefined) {
        respond(res, 503, { raised: false, reason: 'no-parent-process' })
        return
      }
      respond(res, 200, { raised: raiser.raise(target) === true })
      return
    }

    if (action === 'report') {
      // 客户端半上报「这条通知到底弹出来没有」，/ping 里能直接看到。
      readJsonBody(req, (error, body) => {
        if (error !== null) {
          respond(res, 400, { ok: false, reason: error })
          return
        }
        lastReport = { at: Date.now(), ...(body ?? {}) }
        if (!NOISY_STAGES.has(String(lastReport.stage ?? ''))) {
          recentReports.push(lastReport)
          if (recentReports.length > 12) recentReports.shift()
        }
        respond(res, 200, { ok: true })
      })
      return
    }

    if (action === 'test') {
      // 自测入口：`POST dsh-desktop-notify/test`，body 可选
      //   {kind,title,body,sessionId} 造一条提醒；
      //   {overlay:'alert'|'none'}     直接验证任务栏徽标（不经过页面、不受 ack 影响）。
      readJsonBody(req, (error, body) => {
        if (error !== null) {
          respond(res, 400, { ok: false, reason: error })
          return
        }
        if (body?.overlay !== undefined) {
          const target = resolveTargetProcessId()
          if (!isOverlayState(body.overlay) || target === undefined) {
            respond(res, 400, { ok: false, reason: 'invalid-overlay' })
            return
          }
          const label = typeof body.label === 'string' ? body.label : ''
          raiser.overlay(body.overlay, target, label, body.pulse === true)
          raiser.waitFor(/^OVERLAY:/, 2500).then((reply) => {
            respond(res, 200, { ok: reply !== null, overlay: body.overlay, reply })
          })
          return
        }
        // 直接验证「带按钮的通知」后端：点「去回复」会提窗 + 让前端切到 sessionId。
        if (body?.toast === true && notifyBackend !== null) {
          const toastSessionId = body?.sessionId === undefined || body?.sessionId === null ? null : String(body.sessionId)
          const toastKey = `test:${Date.now().toString(36)}`
          // 登记到 openToastKey：窗口一回到前台，/state 的 focused 分支就能把这条气泡撤掉。
          openToasts.set(toastKey, { at: Date.now() })
          notifyBackend
            .notify({
              kind: 'approval',
              title: text(body?.title ?? '测试通知', TITLE_LIMIT),
              body: text(body?.body ?? '点「去回复」验证提窗与切会话。', BODY_LIMIT),
              sessionId: toastSessionId ?? undefined,
              eventId: toastKey,
              actions: { allow: '允许', sessionAllow: '本次会话允许', deny: '拒绝', reply: '去回复' },
              timeoutMs: NOTIFY_TIMEOUT_MS,
            })
            .then(
              (result) => {
                dismissOpenToast('自测结算', toastKey)
                if (result?.decision === DECISIONS.REPLY) focusSession(toastSessionId)
                respond(res, 200, { ok: true, result })
              },
              (error) => {
                dismissOpenToast('自测出错', toastKey)
                respond(res, 500, { ok: false, reason: String(error?.message ?? error) })
              },
            )
          return
        }

        const kind = ['approval', 'question', 'finish', 'error'].includes(body?.kind)
          ? body.kind
          : 'finish'
        const event = push(
          kind,
          text(body?.title ?? '自测提醒', TITLE_LIMIT),
          text(body?.body ?? '这是一条来自 dsh-desktop-notify 的自测提醒。', BODY_LIMIT),
          body?.sessionId ?? null,
          null,
          // 自测提醒即使窗口正被看着也照样弹 toast，方便验证通知链路。
          { test: true },
        )
        respond(res, 200, { ok: true, event })
      })
      return
    }

    req.resume?.()
    respond(res, 404, { error: 'unknown-action' })
  }

  // ---- 挂路由 + 预热 PowerShell worker ----
  ctx.inject(['webServer'], (scoped) => {
    scoped.effect(() => scoped.webServer.register({
      kind: 'prefix',
      path: ROUTE_PATH,
      handler,
    }), 'desktop-notify: routes')
    ctx.logger?.info(`[desktop-notify] 宿主半 v${VERSION}：内部路由 ${ROUTE_PATH} 已挂载`)
  })

  ctx.effect(() => {
    // 提前把 PowerShell 的 C# 编译时间付掉，第一次点通知就不用等 6 秒。
    try {
      raiser.warmup()
    } catch {
      /* 尽力而为 */
    }
    return () => {
      disposed = true
      for (const res of subscribers) {
        try {
          res.end()
        } catch {
          /* 已经断开 */
        }
      }
      subscribers.clear()
      const target = resolveTargetProcessId()
      if (target !== undefined) {
        try {
          raiser.overlay('none', target)
        } catch {
          /* 尽力而为 */
        }
      }
      raiser.dispose()
    }
  }, 'desktop-notify: window raiser')

  ctx.logger?.info(`[desktop-notify] 宿主半 v${VERSION} 已加载`)
}

export default { name, apply }
