/**
 * dsh-desktop-notify —— 宿主半
 *
 * 三件事：
 *
 * 1. **盯着「需要你确认」**：监听 approval/request 与 user-questions/request 两条
 *    waterfall 事件，把「有个决定在等你」折叠成一条提醒；等决定落地（next() 结算）
 *    再撤回。绝不改变请求本身的走向：只在旁边记录，然后原样交给 next()。
 *
 * 2. **盯着「运行结束 / 出错」**：监听 api-session/status（(sessionId, running)）与
 *    agent/error，在 running 由 true 变 false 时记一条「运行结束」，出错时记「运行出错」。
 *
 * 3. **把状态送到两个地方**：
 *    - 任务栏：ITaskbarList3.SetOverlayIcon，黑底数字 = 有决定等你 / 红 = 报错 / 绿 = 跑完了
 *      （见 lib/raise-window.js；进程号取宿主进程的 ppid = Electron 主进程）。
 *    - 页面：注册一条内部路由，客户端半用 SSE 或轮询取提醒，再用 HTML5 Notification
 *      弹出 Windows 通知（渲染进程才有 Notification，宿主这边没有）。
 *
 * 为什么提醒的判定放在宿主半而不是客户端半：客户端拿不到「上一轮为什么结束」，
 * 而宿主半的 api-session/status、approval/request、agent/error 对**所有**会话都成立，
 * 不依赖某个会话是否被打开。
 *
 * 路由约定：客户端用**文档相对**路径请求（不带前导斜杠），桌面端页面是 dsh-app://app/，
 * 其非静态路径由 shell 同源转发到宿主；Web 端页面带 base href，相对路径落在部署前缀下。
 * 状态变更类动作要求自定义签名头：自定义头会把跨站请求升级成需要预检的请求，
 * 本服务不返回任何 Access-Control-Allow-*，于是其它网页的请求根本到不了 handler。
 *
 * @module dsh-desktop-notify
 */

import { readFileSync } from 'node:fs'
// 注意：DSH 重载插件时不会重新 import 相对模块（ESM 按 URL 缓存）。
// 改过 lib/raise-window.js 之后，必须把下面的 ?rev= 加一，重载才会拿到新代码。
import {
  createWindowRaiser,
  isOverlayState,
  resolveTargetProcessId,
} from './lib/raise-window.js?rev=6'

/** Cordis 插件名（诊断与 patch 行定位用）。 */
export const name = 'desktop-notify'

/** 路由前缀（客户端用相对路径 `dsh-desktop-notify/...` 访问）。 */
export const ROUTE_PATH = '/dsh-desktop-notify'

/** 状态变更类请求必须携带的签名头。 */
export const ROUTE_HEADER = 'x-dsh-desktop-notify'
export const ROUTE_HEADER_VALUE = '1'

/** 单次请求体上限：只接受几十字节的 JSON。 */
const MAX_BODY_BYTES = 4096

/** 内存里最多留多少条提醒（够页面刷新后补看，不会无限涨）。 */
const MAX_EVENTS = 60

/** SSE 心跳间隔。 */
const HEARTBEAT_MS = 20_000

/** 单条文案的截断上限。 */
const TITLE_LIMIT = 120
const BODY_LIMIT = 300

/** 宿主半版本，直接读同目录 package.json（单一事实来源）。 */
const VERSION = (() => {
  try {
    const pkg = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8'))
    return typeof pkg.version === 'string' && pkg.version !== '' ? pkg.version : 'unknown'
  } catch {
    return 'unknown'
  }
})()

/** 把任意值截成有界字符串。 */
function text(value, limit) {
  if (typeof value !== 'string') return ''
  return value.length > limit ? `${value.slice(0, limit)}…` : value
}

/** 判断请求是否带了签名头（node 会把重复头合并成数组）。 */
function hasRouteHeader(req) {
  const headers = req?.headers
  if (headers === null || typeof headers !== 'object') return false
  const value = headers[ROUTE_HEADER]
  if (typeof value === 'string') return value === ROUTE_HEADER_VALUE
  return Array.isArray(value) && value.includes(ROUTE_HEADER_VALUE)
}

/** 写一个 JSON 响应。 */
function respond(res, status, body) {
  try {
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    })
    res.end(JSON.stringify(body))
  } catch {
    /* 连接已经断了 */
  }
}

/** 读一个小 JSON 请求体。 */
function readJsonBody(req, done) {
  const chunks = []
  let size = 0
  let settled = false
  const finish = (error, body) => {
    if (settled) return
    settled = true
    done(error, body)
  }
  req.on?.('data', (chunk) => {
    if (settled) return
    size += chunk.length
    if (size > MAX_BODY_BYTES) {
      finish('too-large', undefined)
      try {
        req.destroy?.()
      } catch {
        /* 已经断开 */
      }
      return
    }
    chunks.push(chunk)
  })
  req.on?.('error', () => finish('read-error', undefined))
  req.on?.('end', () => {
    if (settled) return
    try {
      const raw = Buffer.concat(chunks).toString('utf8')
      const body = raw === '' ? {} : JSON.parse(raw)
      if (body === null || typeof body !== 'object' || Array.isArray(body)) {
        finish('invalid-json', undefined)
        return
      }
      finish(null, body)
    } catch {
      finish('invalid-json', undefined)
    }
  })
}

/**
 * Cordis 插件入口。
 * @param {object} ctx 根上下文。
 */
export function apply(ctx) {
  const raiser = createWindowRaiser({
    onWarn: (message, error) => {
      ctx.logger?.warn?.(`${message}${error === undefined ? '' : `：${String(error)}`}`)
    },
  })

  /** 递增的提醒 id（事件游标）。 */
  let seq = 0
  /** 最近若干条提醒；`ack` 表示用户已经看过。 */
  const events = []
  /** 打开的「等待决定」：key -> { at, kind, sessionId }。 */
  const pending = new Map()
  /** 每个会话上一次的 running 状态。 */
  const runningState = new Map()
  /** 当前托盘点颜色；`none` 表示没点。 */
  let badge = 'none'
  /** 徽标上显示的数字（alert 时生效）。 */
  let badgeCount = 0
  /** SSE 订阅者。 */
  const subscribers = new Set()
  /** 是否已经 dispose。 */
  let disposed = false
  /** 客户端上报的通知结果（诊断用：Windows 通知失败时这里能看到原因）。 */
  let lastReport = null
  /** 最近的客户端上报（环形，最多 12 条；跳过心跳类，只留「为什么灭了」这种线索）。 */
  const recentReports = []
  const NOISY_STAGES = new Set(['poll', 'hello', 'sse', 'boot'])
  /** 最近一个 SSE 订阅者自报的客户端版本。 */
  let subscriberVersion = null

  /**
   * 算出「现在该亮什么状态、圈里写几」。
   *
   * 跑完和「有决定等你」用同一种黑底数字圈：用户要的就是一眼看到「有几件事没看」。
   * 只有出错仍然用红色叹号，因为那件事的性质不同、必须更刺眼。
   */
  function desiredBadge() {
    // 用户的要求：所有提醒都只表达「有几件事等你处理」——
    // 审批/提问/跑完/出错统一合并成一个黑底数字圈，不再区分颜色。
    let count = pending.size
    for (const event of events) {
      if (event.ack) continue
      if (event.kind === 'finish' || event.kind === 'error') count += 1
    }
    if (count === 0) return { state: 'none', count: 0 }
    return { state: 'alert', count }
  }

  /** 徽标上要画的字符：黑底用数字（几件事等你），红色叹号，绿色对勾。 */
  function badgeLabel(state, count) {
    if (state === 'alert') return count > 9 ? '9+' : String(Math.max(count, 1))
    if (state === 'red') return '!'
    if (state === 'green') return 'check'
    return ''
  }

  /** 把算出来的颜色刷到任务栏（只在变化时发指令）。 */
  function applyBadge() {
    if (disposed) return
    const want = desiredBadge()
    if (want.state === badge && want.count === badgeCount) return
    const changed = want.state !== badge
    badge = want.state
    badgeCount = want.count
    const target = resolveTargetProcessId()
    if (target === undefined) return
    raiser.overlay(want.state, target, badgeLabel(want.state, want.count), changed && want.state !== 'none')
  }

  /** 向所有 SSE 订阅者推一条。 */
  function broadcast(event) {
    const frame = `event: alert\ndata: ${JSON.stringify(event)}\n\n`
    for (const res of subscribers) {
      try {
        res.write(frame)
      } catch {
        subscribers.delete(res)
      }
    }
  }

  /**
   * 记一条提醒。
   * @param {'approval'|'question'|'finish'|'error'} kind 类别。
   * @param {string} title 标题。
   * @param {string} body 正文。
   * @param {string|null} sessionId 归属会话。
   * @param {string|null} [key] 决定类提醒的幂等键。
   */
  function push(kind, title, body, sessionId, key = null, extra = null) {
    if (disposed) return null
    const event = {
      id: ++seq,
      kind,
      title: text(title, TITLE_LIMIT),
      body: text(body, BODY_LIMIT),
      sessionId: sessionId === null || sessionId === undefined ? null : String(sessionId),
      key,
      at: Date.now(),
      ack: false,
    }
    if (extra !== null) Object.assign(event, extra)
    events.push(event)
    while (events.length > MAX_EVENTS) events.shift()
    broadcast(event)
    applyBadge()
    return event
  }

  /** 一条「等待决定」开始了。 */
  function openPending(kind, sessionId, key) {
    pending.set(key, { at: Date.now(), kind, sessionId })
    applyBadge()
  }

  /** 一条「等待决定」结束了。 */
  function closePending(key) {
    if (pending.delete(key)) applyBadge()
  }

  /**
   * approval/request 的旁听：先记一笔，再原样 next()。
   *
   * 这条是 waterfall，任何监听者抛错都会把审批流程带崩（用户就再也点不了确认），
   * 所以这里所有自己的动作都包在 try/catch 里，最后一定把 next() 的 Promise 原样返回。
   */
  function onApprovalRequest(req, next) {
    let key = null
    try {
      const sessionId = req?.agent?.id ?? null
      const toolName = text(req?.toolName ?? '工具', 60)
      const reason = text(
        req?.displayReason?.zh ?? req?.displayReason?.en ?? req?.reason ?? '',
        BODY_LIMIT,
      )
      key = `approval:${String(sessionId)}:${String(req?.callId ?? toolName)}`
      if (!pending.has(key)) {
        openPending('approval', sessionId, key)
        push(
          'approval',
          '需要你的确认',
          reason === '' ? `${toolName} 正在等你确认` : `${toolName}：${reason}`,
          sessionId,
          key,
        )
      }
    } catch {
      /* 旁听失败绝不能影响审批本身 */
    }
    const settle = () => {
      try {
        if (key !== null) closePending(key)
      } catch {
        /* 同上 */
      }
    }
    let outcome
    try {
      outcome = next()
    } catch (error) {
      settle()
      throw error
    }
    return Promise.resolve(outcome).then(
      (value) => {
        settle()
        return value
      },
      (error) => {
        settle()
        throw error
      },
    )
  }

  /** user-questions/request 的旁听（同样只旁听、不改变走向）。 */
  function onUserQuestionRequest(req, next) {
    let key = null
    try {
      const sessionId = req?.agent?.id ?? null
      const first = Array.isArray(req?.questions) ? req.questions[0] : undefined
      const kind = first?.intent?.kind
      const title = kind === 'plan-review' ? '计划等你批准' : 'DSH 在等你回答'
      const question = text(first?.question ?? first?.header ?? '', BODY_LIMIT)
      key = `question:${String(sessionId)}:${String(req?.wait?.callId ?? question)}`
      if (!pending.has(key)) {
        openPending('question', sessionId, key)
        push(
          'question',
          title,
          question === '' ? '有一个问题需要你回答' : question,
          sessionId,
          key,
        )
      }
    } catch {
      /* 旁听失败绝不能影响问答本身 */
    }
    const settle = () => {
      try {
        if (key !== null) closePending(key)
      } catch {
        /* 同上 */
      }
    }
    let answer
    try {
      answer = next()
    } catch (error) {
      settle()
      throw error
    }
    return Promise.resolve(answer).then(
      (value) => {
        settle()
        return value
      },
      (error) => {
        settle()
        throw error
      },
    )
  }

  /** 只给顶层会话发「跑完了」——子 agent 的会话由父会话汇总，避免一次任务刷屏。 */
  function isRootSession(sessionId) {
    try {
      const agents = ctx.get('agents')
      if (!agents || typeof agents.roots !== 'function') return true
      const roots = agents.roots()
      if (!Array.isArray(roots) || roots.length === 0) return true
      return roots.some((agent) => String(agent?.id) === sessionId)
    } catch {
      return true
    }
  }

  /** api-session/status：running 由 true 变 false 就是「这一轮跑完了」。 */
  function onSessionStatus(sessionId, isRunning) {
    try {
      const id = String(sessionId)
      const was = runningState.get(id) ?? false
      runningState.set(id, isRunning === true)
      if (was && isRunning !== true && isRootSession(id)) {
        push('finish', '运行结束', '这一轮已经跑完，点开看看结果。', id)
      }
    } catch {
      /* 忽略 */
    }
  }

  /** session/event：turn/end 才是「这一轮跑完了」的权威信号（api-session/status 要先见过 running=true，插件重载后的第一轮会漏）。 */
  function onSessionEvent(a, b) {
    try {
      const session = a && a.header ? a : b
      const event = a && typeof a.type === 'string' ? a : b
      if (!event || event.type !== 'turn/end') return
      const header = session?.header
      if (header?.origin === 'subagent' || header?.parentSession !== undefined) return
      const id = String(session?.id ?? '')
      const reason = event?.data?.reason
      const kind = reason?.kind
      if (kind === 'aborted' || kind === 'interrupted' || kind === 'forked') return
      if (kind === 'error') {
        const message = text(reason?.error?.message ?? '运行出错', BODY_LIMIT)
        push('error', '运行出错', message === '' ? '运行出错了，点开看看。' : message, id)
        return
      }
      push('finish', '运行结束', '这一轮已经跑完，点开看看结果。', id)
    } catch {
      /* 忽略 */
    }
  }

  /** agent/error：出错时红点。 */
  function onAgentError(payload) {
    try {
      const sessionId = payload?.agent?.id ?? null
      const raw = payload?.error
      const message = typeof raw === 'string'
        ? raw
        : text(raw?.message ?? raw?.code ?? '运行出错', BODY_LIMIT)
      push('error', '运行出错', message === '' ? '运行出错了，点开看看。' : message, sessionId)
    } catch {
      /* 忽略 */
    }
  }

  /** 挂一个监听，注册失败只记日志（缺服务/缺事件时插件其余功能照常）。 */
  function listen(event, handler) {
    try {
      ctx.effect(() => ctx.on(event, handler), `desktop-notify: ${event}`)
    } catch (error) {
      ctx.logger?.warn?.(`[desktop-notify] 监听 ${event} 失败：${String(error)}`)
    }
  }

  // ---- 旁听：需要你确认 ----
  listen('approval/request', onApprovalRequest)
  listen('user-questions/request', onUserQuestionRequest)
  // ---- 旁听：跑完了 / 出错了 ----
  listen('session/event', onSessionEvent)
  listen('agent/error', onAgentError)

  // ---- SSE：页面用 EventSource('dsh-desktop-notify/events') 订阅 ----
  function openStream(req, res) {
    try {
      const match = /[?&]v=([^&]+)/.exec(String(req.url ?? ''))
      if (match !== null) subscriberVersion = decodeURIComponent(match[1]).slice(0, 40)
    } catch {
      /* 版本号只是诊断信息 */
    }
    res.writeHead(200, {
      'content-type': 'text/event-stream; charset=utf-8',
      'cache-control': 'no-store, no-transform',
      connection: 'keep-alive',
      'x-accel-buffering': 'no',
    })
    res.flushHeaders?.()
    res.write(': connected\n\n')
    res.write(`event: hello\ndata: ${JSON.stringify({ cursor: seq, badge })}\n\n`)
    subscribers.add(res)
    const timer = setInterval(() => {
      try {
        res.write(': ping\n\n')
      } catch {
        /* 断开由 close 处理 */
      }
    }, HEARTBEAT_MS)
    const cleanup = () => {
      clearInterval(timer)
      subscribers.delete(res)
    }
    req.on?.('close', cleanup)
    req.on?.('error', cleanup)
    res.on?.('error', cleanup)
  }

  /** 内部路由：ping / state / ack / raise / test。 */
  function handler(req, res) {
    const raw = typeof req.url === 'string' ? req.url : '/'
    const path = raw.split('?')[0]
    const action = path.startsWith(`${ROUTE_PATH}/`) ? path.slice(ROUTE_PATH.length + 1) : ''

    // SSE 没法带自定义头（EventSource 不支持），它只读、只推提醒本身，不碰状态。
    if (req.method === 'GET' && action === 'events') {
      openStream(req, res)
      return
    }

    if (req.method !== 'POST') {
      respond(res, 405, { error: 'method-not-allowed' })
      return
    }
    if (!hasRouteHeader(req)) {
      req.resume?.()
      respond(res, 403, { error: 'forbidden', reason: 'missing-header' })
      return
    }

    if (action === 'ping') {
      req.resume?.()
      respond(res, 200, {
        host: 'dsh-desktop-notify',
        version: VERSION,
        badge,
        pending: pending.size,
        events: events.length,
        subscribers: subscribers.size,
        subscriberVersion,
        raiserRunning: raiser.isRunning(),
        raiserReady: raiser.isReady(),
        lastReply: raiser.lastReply(),
        lastReport,
        recentReports,
        worker: 'v5',
        targetProcessId: resolveTargetProcessId() ?? null,
      })
      return
    }

    if (action === 'state') {
      readJsonBody(req, (error, body) => {
        if (error !== null) {
          respond(res, error === 'too-large' ? 413 : 400, { ok: false, reason: error })
          return
        }
        const since = Number.isInteger(body?.since) ? body.since : -1
        respond(res, 200, {
          ok: true,
          cursor: seq,
          badge,
          pending: pending.size,
          // since < 0 表示「只给我游标，不要回放历史」——页面刚加载时用。
          events: since < 0 ? [] : events.filter((event) => event.id > since),
        })
      })
      return
    }

    if (action === 'ack') {
      readJsonBody(req, (error) => {
        if (error !== null) {
          respond(res, 400, { ok: false, reason: error })
          return
        }
        for (const event of events) event.ack = true
        applyBadge()
        respond(res, 200, { ok: true, badge })
      })
      return
    }

    if (action === 'raise') {
      req.resume?.()
      const target = resolveTargetProcessId()
      if (target === undefined) {
        respond(res, 503, { raised: false, reason: 'no-parent-process' })
        return
      }
      respond(res, 200, { raised: raiser.raise(target) === true })
      return
    }

    if (action === 'report') {
      // 客户端半上报「这条通知到底弹出来没有」，/ping 里能直接看到。
      readJsonBody(req, (error, body) => {
        if (error !== null) {
          respond(res, 400, { ok: false, reason: error })
          return
        }
        lastReport = { at: Date.now(), ...(body ?? {}) }
        if (!NOISY_STAGES.has(String(lastReport.stage ?? ''))) {
          recentReports.push(lastReport)
          if (recentReports.length > 12) recentReports.shift()
        }
        respond(res, 200, { ok: true })
      })
      return
    }

    if (action === 'test') {
      // 自测入口：`POST dsh-desktop-notify/test`，body 可选
      //   {kind,title,body,sessionId} 造一条提醒；
      //   {overlay:'alert'|'none'}     直接验证任务栏徽标（不经过页面、不受 ack 影响）。
      readJsonBody(req, (error, body) => {
        if (error !== null) {
          respond(res, 400, { ok: false, reason: error })
          return
        }
        if (body?.overlay !== undefined) {
          const target = resolveTargetProcessId()
          if (!isOverlayState(body.overlay) || target === undefined) {
            respond(res, 400, { ok: false, reason: 'invalid-overlay' })
            return
          }
          const label = typeof body.label === 'string' ? body.label : ''
          raiser.overlay(body.overlay, target, label, body.pulse === true)
          raiser.waitFor(/^OVERLAY:/, 2500).then((reply) => {
            respond(res, 200, { ok: reply !== null, overlay: body.overlay, reply })
          })
          return
        }
        const kind = ['approval', 'question', 'finish', 'error'].includes(body?.kind)
          ? body.kind
          : 'finish'
        const event = push(
          kind,
          text(body?.title ?? '自测提醒', TITLE_LIMIT),
          text(body?.body ?? '这是一条来自 dsh-desktop-notify 的自测提醒。', BODY_LIMIT),
          body?.sessionId ?? null,
          null,
          // 自测提醒即使窗口正被看着也照样弹 toast，方便验证通知链路。
          { test: true },
        )
        respond(res, 200, { ok: true, event })
      })
      return
    }

    req.resume?.()
    respond(res, 404, { error: 'unknown-action' })
  }

  // ---- 挂路由 + 预热 PowerShell worker ----
  ctx.inject(['webServer'], (scoped) => {
    scoped.effect(() => scoped.webServer.register({
      kind: 'prefix',
      path: ROUTE_PATH,
      handler,
    }), 'desktop-notify: routes')
    ctx.logger?.info(`[desktop-notify] 宿主半 v${VERSION}：内部路由 ${ROUTE_PATH} 已挂载`)
  })

  ctx.effect(() => {
    // 提前把 PowerShell 的 C# 编译时间付掉，第一次点通知就不用等 6 秒。
    try {
      raiser.warmup()
    } catch {
      /* 尽力而为 */
    }
    return () => {
      disposed = true
      for (const res of subscribers) {
        try {
          res.end()
        } catch {
          /* 已经断开 */
        }
      }
      subscribers.clear()
      const target = resolveTargetProcessId()
      if (target !== undefined) {
        try {
          raiser.overlay('none', target)
        } catch {
          /* 尽力而为 */
        }
      }
      raiser.dispose()
    }
  }, 'desktop-notify: window raiser')

  ctx.logger?.info(`[desktop-notify] 宿主半 v${VERSION} 已加载`)
}

export default { name, apply }
