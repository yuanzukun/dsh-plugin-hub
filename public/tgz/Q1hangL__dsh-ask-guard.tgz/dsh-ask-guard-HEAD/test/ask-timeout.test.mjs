import test from 'node:test'
import assert from 'node:assert/strict'
import { Context } from '@deepseek-ai/cordis'
import ToolRuntime, { defineTool } from '@deepseek-ai/dsh-tools'
import UserQuestionService from '@deepseek-ai/dsh-user-questions'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import * as toolAskUser from '@deepseek-ai/dsh-tool-ask-user'
import { apply, name } from '../index.js'

const questionArgs = {
  questions: [{ id: 'q', question: 'proceed?', options: [{ label: 'yes' }] }],
}

/** Fake provider mirroring the web provider's abort contract. */
function hangingProvider() {
  return {
    ask(request) {
      return new Promise((_resolve, reject) => {
        request.signal.addEventListener(
          'abort',
          () => reject(new Error('ask aborted')),
          { once: true },
        )
      })
    },
  }
}

function answeringProvider(answer) {
  return {
    async ask() {
      return answer
    },
  }
}

async function mount(ctx, provider, config = { timeoutMs: 300 }) {
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(UserQuestionService)
  await ctx.plugin(toolAskUser)
  await ctx.plugin({
    inject: ['userQuestions'],
    apply: (c) => c.userQuestions.registerProvider(provider),
  })
  await ctx.plugin({ apply, name, inject: ['tools'] }, config)
}

function executeAsk(ctx) {
  return ctx.get('tools').execute({
    callId: 'c1',
    name: 'ask_user_question',
    arguments: questionArgs,
    signal: new AbortController().signal,
  })
}

test('hanging question resolves as ASK_TIMEOUT after the deadline', async () => {
  const ctx = new Context()
  await mount(ctx, hangingProvider(), { timeoutMs: 300 })
  const started = Date.now()
  const result = await executeAsk(ctx)
  const elapsed = Date.now() - started
  assert.equal(result.isError, true)
  assert.equal(result.error?.info?.code, 'ASK_TIMEOUT')
  assert.equal(result.error?.info?.name, 'AskTimeoutError')
  assert.ok(result.content[0].text.includes('timed out'))
  assert.ok(elapsed >= 250, `resolved too early (${elapsed}ms)`)
  assert.ok(elapsed < 5000, `resolved too late (${elapsed}ms)`)
  await ctx.fiber.dispose()
})

test('promptly answered question passes through untouched', async () => {
  const ctx = new Context()
  await mount(ctx, answeringProvider({ answers: [{ id: 'q', selected: ['yes'] }] }))
  const result = await executeAsk(ctx)
  assert.equal(result.isError, false)
  assert.deepEqual(result.value, { answers: [{ id: 'q', selected: ['yes'] }] })
  await ctx.fiber.dispose()
})

test('other tools are never touched by the guard', async () => {
  const ctx = new Context()
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin({
    inject: ['tools'],
    apply: (c) =>
      c.tools.register(defineTool({
        name: 'slow_tool',
        description: 'slow test tool',
        parameters: {},
        output: { schema: { type: 'string' }, render: (_a, v) => [{ type: 'text', text: v }] },
        async execute() {
          await new Promise((r) => setTimeout(r, 200))
          return 'done'
        },
      })),
  })
  await ctx.plugin({ apply, name, inject: ['tools'] }, { timeoutMs: 50 })
  const result = await ctx.get('tools').execute({
    callId: 'c2',
    name: 'slow_tool',
    arguments: {},
    signal: new AbortController().signal,
  })
  assert.equal(result.isError, false)
  assert.equal(result.value, 'done')
  await ctx.fiber.dispose()
})

test('invalid timeoutMs rejects at load', () => {
  assert.throws(
    () => apply({ on() {} }, { timeoutMs: 0 }),
    /timeoutMs must be a positive integer/,
  )
})
