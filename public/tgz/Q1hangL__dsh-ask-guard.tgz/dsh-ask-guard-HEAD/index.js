import z from '@deepseek-ai/schemastery'
import { deadline, timeoutOf } from '@deepseek-ai/dsh-timeout'

/**
 * dsh-ask-guard — a cooperative timeout guard for `ask_user_question`.
 *
 * The question card is delivered to the browser over a single mux WebSocket
 * push. When the page is backgrounded, the laptop sleeps, or the connection
 * dies half-open, the frame is lost and the tool waits forever (no built-in
 * budget — see deepseek-ai/deepseek-harness discussion #1554).
 *
 * This plugin arms a deadline on every `ask_user_question` dispatch. When the
 * deadline wins, the waiting provider's abort handler fires (the web provider
 * then broadcasts `question/resolved cancelled`, cleaning up the client), and
 * this wrapper replaces the normalized abort with a structured `ASK_TIMEOUT`
 * result the model can act on — the turn ends instead of hanging forever.
 */

export const name = 'ask-guard'
export const inject = ['tools']

/** Plugin config, validated by schemastery when composed from a patch layer. */
export const Config = z.object({
  timeoutMs: z.number().default(300000),
})

export const DEFAULT_TIMEOUT_MS = 300000
export const ASK_TIMEOUT = 'ASK_TIMEOUT'

export function apply(ctx, config = {}) {
  const timeoutMs = config.timeoutMs ?? DEFAULT_TIMEOUT_MS
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1) {
    throw new Error('dsh-ask-guard: timeoutMs must be a positive integer')
  }
  ctx.on('tools/execute', async (exec, next) => {
    if (exec.name !== 'ask_user_question') return next()
    const d = deadline(exec.signal, timeoutMs, ASK_TIMEOUT)
    const upstream = exec.signal
    exec.signal = d.signal
    try {
      const result = await next()
      if (timeoutOf(d.signal, ASK_TIMEOUT) !== undefined) return askTimeoutResult(timeoutMs)
      return result
    } finally {
      exec.signal = upstream
      d[Symbol.dispose]()
    }
  })
}

/** The structured replacement result when this plugin's deadline wins. */
function askTimeoutResult(timeoutMs) {
  const message = `ask_user_question timed out after ${timeoutMs}ms — the user did not answer (the page may be disconnected; a page refresh re-syncs pending questions)`
  return {
    content: [{ type: 'text', text: `Error: ${message}` }],
    isError: true,
    error: {
      message,
      info: {
        name: 'AskTimeoutError',
        code: ASK_TIMEOUT,
      },
    },
  }
}
