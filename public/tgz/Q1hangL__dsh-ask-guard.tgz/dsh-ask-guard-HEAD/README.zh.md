# dsh-ask-guard

DeepSeek Harness 的 `ask_user_question` 超时守卫：提问卡片丢失或用户未答复时，
以结构化 `ASK_TIMEOUT` 结束工具调用，而不是让回合无限挂起。

## 解决的问题

提问卡片通过 mux WebSocket **一次性推送**到浏览器。当页面后台化、笔记本睡眠、
或连接半开断掉（无心跳、无 FIN）时，帧丢失且客户端无感知，工具将永远等待——
实测挂起 6 小时以上，只能靠按"停止"恢复。上游报告：
[deepseek-ai/deepseek-harness#1554](https://github.com/deepseek-ai/deepseek-harness/discussions/1554)。

## 插件做了什么

注册一个 `tools/execute` 包装器，为每次 `ask_user_question` 派发挂上协作式
deadline（与官方 `dsh-tool-call-timeout-policy` 同款机制；官方那个只对"自己
声明了超时的工具"生效，而 ask 工具没有声明）。

- deadline 获胜时，等待中的 provider 的 abort 处理器触发：web provider 会广播
  `question/resolved cancelled`，残留的提问卡（如果有）被清理；
- 随后包装器把归一化的 abort 替换成结构化错误结果（`code: ASK_TIMEOUT`，
  `name: AskTimeoutError`）并附模型可见的提示，agent 可以体面收尾而不是干等；
- 其他工具完全不受影响。

超时是**协作式**的（`@deepseek-ai/dsh-timeout` 通过 `exec.signal` 通知；web
user-questions provider 监听该信号，会真正终止等待）。

## 安装

```bash
dsh plugin --profile web add dsh-ask-guard
```

重启 `dsh web` 生效。本插件是 `dsh.bundle` 包，reconcile 时会自动把 patch 行
加入 profile 组合。

从 git 安装：

```bash
dsh plugin --profile web add github:Q1hangL/dsh-ask-guard
```

## 配置

| 字段 | 默认值 | 含义 |
|---|---|---|
| `timeoutMs` | `300000` | 单次 `ask_user_question` 的截止时间（毫秒） |

在 profile 的 `cordis.patch.yml` 里调整：

```yaml
- id: ask-guard
  config:
    timeoutMs: 600000
```

## 恢复提示

刷新页面（F5）会触发重连，host 会把未答复的提问回放给客户端。装上本插件后，
即使不刷新，回合也不会再无限挂起。

## 测试

```bash
npm install
node --test
```

## 许可证

MIT
