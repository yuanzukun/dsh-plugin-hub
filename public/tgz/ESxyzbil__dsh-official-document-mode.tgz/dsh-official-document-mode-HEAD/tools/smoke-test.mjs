// dsh-official-document-mode 冒烟测试：不依赖 DSH 运行。
// 1) host 半侧可导入且导出 name/inject/apply；
// 2) client 半侧语法有效（lazy-CJS factory 在浏览器才执行，这里仅做语法校验）；
// 3) 内置文风约束包含关键要求。
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = dirname(dirname(fileURLToPath(import.meta.url)));
let failed = 0;
const ok = (name) => console.log(`  ✓ ${name}`);
const bad = (name, detail) => { console.error(`  ✗ ${name}: ${detail}`); failed++; };

console.log("dsh-official-document-mode smoke test");

// 1) host exports
console.log("[host] import lib/index.js");
try {
  const host = await import("../lib/index.js");
  if (typeof host.name !== "string" || host.name !== "dsh-official-document-mode") bad("name export", "missing/wrong");
  else ok(`name = ${host.name}`);
  if (typeof host.apply !== "function") bad("apply export", "not a function");
  else ok("apply(ctx, config) exported");
  if (!Array.isArray(host.inject)) bad("inject export", "not an array");
  else ok(`inject = [${host.inject.join(", ")}]`);
} catch (error) {
  bad("import", String(error?.message ?? error));
}

// 2) client syntax
console.log("[client] syntax check lib/client.js");
{
  const r = spawnSync(process.execPath, ["--check", join(root, "lib", "client.js")], { encoding: "utf8" });
  if (r.status === 0) ok("client.js parses");
  else bad("client.js parse", (r.stderr || r.stdout || "").trim().split("\n").slice(-3).join(" "));
}

// 3) constraint content sanity（通过 apply 不执行；直接读源文件文本）
console.log("[host] style constraint content (公文模式开启时每回合 pre-step 注入)");
{
  const src = await import("node:fs").then((fs) => fs.readFileSync(join(root, "lib", "index.js"), "utf8"));
  const has = (s) => src.includes(s);
  const checks = [
    ["公文文风约束", "文风约束"],
    ["标题", "标题"],
    ["称谓", "称谓"],
    ["收束语", "收束语"],
    ["用户提供的事实", "用户提供的事实"],
    ["enabled 驱动模式（ensureStyle/releaseStyle）", "ensureStyle"],
    ["pre-step 注入钩子", "agent/pre-step"]
  ];
  for (const [label, needle] of checks) {
    if (has(needle)) ok(`constraint mentions ${label}`);
    else bad(`constraint ${label}`, `missing "${needle}"`);
  }
  // 注入必须由 settings.enabled 门控（关闭模式即零注入）
  if (src.includes("if (!settings.enabled) return decision;")) ok("pre-step injection gated by enabled");
  else bad("pre-step gate", "注入应受 settings.enabled 门控");
}

console.log(failed === 0 ? "\nALL PASS" : `\n${failed} FAILED`);
process.exit(failed === 0 ? 0 : 1);
