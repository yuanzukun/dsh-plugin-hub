# dsh-official-document-mode（DSH 公文模式）

效果对标 [4thfever/codex-document-mode](https://github.com/4thfever/codex-document-mode) 的 DSH 插件：

- **公文模式（总开关驱动）**：开启时 = **回复本身写成公文**——host 以 systemPrompt section 注册一次文风约束（恒定文本、KV 缓存友好，非每条消息注入），引导模型写「标题：关于……的请示/报告/函」、称谓、分层正文与文种收束语；client 对**每个回合的最终汇报**渲染公文版式（题头机关名+文号、红色分隔线、居中标题（提取自 `# 标题` / `标题：…` 行）、称谓、正文（Markdown 原样）、落款「此致 敬礼」+ 署名 + 日期），中间步骤/工具调用/工作流一律不包。关闭时 = 完全普通：零注入、无公文框。
- **圈阅反馈**：输入区左侧工具行加一个 36px 画板——画圈 = 同意，画叉 = 不同意（几何识别：单笔闭合+圆度 → 圈；自相交或多笔交叉 → 叉）。识别成功后写入 `【反馈：同意】` / `【反馈：不同意】` 到草稿；草稿为空且可发送时自动发送，否则追加到草稿末尾。公文模式关闭时画板隐藏。

## 安装

```bat
dsh plugin --profile desktop add link:C:\Users\34983\dsh-plugins\dsh-official-document-mode
```

重启 DSH 生效。

## 配置（可选）

profile 的 `cordis.patch.yml` 或 bundle insert 的 `config:`：

```yaml
- id: dsh-official-document-mode
  name: dsh-official-document-mode
  config:
    enabled: true            # 公文模式总开关（默认开；UI 按钮可运行时切换）
    salutation: '尊敬的领导：'
    signature: 'DeepSeek 人工智能助手'
    orgName: 'DeepSeek Harness'   # 题头机关名
    titlePrefix: ''          # 文号前缀（可填「文件」等）
    fileNo: ''               # 固定文号
    styleConstraint: ''      # 自定义文风约束全文（覆盖内置默认）
```

client 通过 `GET /api/dsh-official-document-mode/settings` 读取展示参数，`POST` 可写（含 `enabled` 开关，持久化到 `$DSH_HOME/dsh-official-document-mode.json`）。

**UI 开关（公文模式总开关）**：输入区下方有「公文模式」按钮，点击切换——开 = 回复成公文（约束+渲染），关 = 普通回复（零注入、无框、画板隐藏）。切换立即生效；host 端约束 section 的注册/注销随 POST 动态进行。

**区分语义（重要）**：以「模式开启时刻」（`enabledAt`，持久化于 `$DSH_HOME/dsh-official-document-mode.json`）为界——开启之前产生的消息（无公文标识）**永远保持普通显示**，只有开启之后产生的新回复才渲染公文；关闭后再开启，以新的开启时刻重新为界。因此历史消息不会被"套上公文框"。

## 结构

```
dsh-official-document-mode/
├── package.json        # dsh.bundle.patch + dsh.client(platform: web)
├── cordis.patch.yml    # 挂载声明（insert id/name）
├── lib/
│   ├── index.js        # host：公文模式开关驱动 systemPrompt section 约束 + /api 设置路由（enabledAt 持久化）
│   └── client.js       # WebUI：公文框架（DOM+snapshot 驱动，开启时刻为界）+ 圈阅画板
└── tools/smoke-test.mjs
```

## 测试

```bat
node tools\smoke-test.mjs
```

## 已知限制

- 一个回合含多次工具调用时会按 assistant 步骤分段出现多份公文（每段各带题头/落款），工具调用行保持原样。
- 公文标题从回复首个标题行/「标题：」行提取，无标题时回退到首句截断。
- 圈阅识别为轻量几何启发式，非机器学习；画太小的圈/叉不触发。

## 热加载结论（实测验证，2026-08-22）

**DSH Desktop 桌面版当前不支持免重启加载新插件（host 半侧）**，实测依据：

- 桌面 host（`main.js`）引导 profile 时**没有调用 `watchUserPatches`**（该函数只由 CLI 启动路径调用），因此 `cordis.patch.yml` 的改动**不会**被热应用；loader 配置树在启动时一次性组合。
- HMR 插件虽随 `dsh-base` 挂载，但其 watcher 默认忽略 `node_modules`，且桌面 host 未把用户 patch 层注册进 HMR。
- 实测：向 profile `cordis.patch.yml` 写入新插件 insert 后，host 未挂载（无路由、无标记文件、日志无 hmr 记录）。

**可以免重启的部分**：

- **client 半侧（`lib/client.js`）代码改动：F5 刷新即生效**——`dsh-client-modules` 按请求从磁盘读取 `/plugins/<id>/client.js`（`cache-control: no-cache`），只要 host 条目已加载。
- **新插件 / host 半侧代码改动：必须重启 DSH Desktop**（安装后一次生效）。

所以本插件的后续迭代：改 `lib/client.js` → 刷新页面即可；改 `lib/index.js`（host）→ 需重启。
