# FAQ

## 为什么第三方插件市场（如 dshmarket）里显示「安装完成但校验失败 / 入口产物缺失」？

> **v18.0.0 起已不适用**：本包现在带 JS 包入口（`main` → `lib/index.js`，注册技能并经 `ctx.effect` 可逆注册），「只认 JS 入口」一类校验器不再误报。若仍看到该校验失败，请确认安装的是 v18.0.0 及以上。
>
> **先分清归属（v18.2.4 补注）**：`dshmarket` 与各类插件市场都是**第三方社区项目**，不是 DSH 官方组件，也不在本包的依赖或支持范围内——本包只依赖 DSH 宿主本身（且 `@deepseek-ai/dsh` 是 optional peer）。故「市场里的显示」与「本包能否装载」是两件事：前者出问题找市场，后者出问题看本文件与 [`troubleshooting.md`](troubleshooting.md)。

## 本包「零可执行内容」吗？

**不是，安装前请知悉信任边界**（完整版见 [`SECURITY.md`](../SECURITY.md)）：

- **包入口** `lib/index.js`：纯 ESM、零第三方依赖，只在 `apply` 期读随包 `SKILL.md` 并经 `ctx.skills.register()` 注册技能；不派生子进程、不联网、不写文件。
- **加载期 `!!js`**（`cordis.patch.yml`）：含 **6 处 `!!js` 表达式** = **3 处 `agentOptions`**（三段分档工具行，各自读本档 `LUNHENG_*_PROVIDER/MODEL`，未设则返回 `undefined`）+ **3 处 `disabled`**（同一批行的行级门控，读 `LUNHENG_TIERING` 与三档 `*_PROVIDER/MODEL`）。它们**都由** DSH 宿主进程在**加载期以完整 Node 权限**求值（`disabled` 由 loader 的 `disabledOf()` 求值，`@deepseek-ai/cordis-plugin-loader/src/config/entry.ts:104-107`），发生在 agent 沙箱与审批关卡之前——**安装本包即等于允许这些表达式在每次启动时执行**。它们只使用 `process.env` 与全局 `Object.assign`（CI 红线规则 ⑭ 禁止 `getBuiltinModule`/`child_process`/`require(`/`eval(` 等标识符）。
  > **计数口径**（v18.2.6 更正）：`Select-String cordis.patch.yml -Pattern '^\s*[A-Za-z]+:\s*!!js'` → **6 行**。旧版本节与旧 patch 注释只写「3 处」（只数了 `agentOptions`），**漏算 3 处 `disabled`**，等于把加载期执行面**少报一半**。
  > v17.0.0 及更早还有第 4 处 `!!js`（技能目录路径求值，用 `baseUrl`/`URL`）；v18.0.0 改由包入口注册技能后，这处求值**已删除**，表达式面更窄。

实测技能可正常加载：`dsh --profile <profile> --dump-config` 可见本包层与 `tool-subagent-*` 的**声明行**，新会话的技能目录能列出 `lunheng-article-pipeline` 与 `lunheng-commands` 两个技能。
> ⚠️ **`--dump-config` 只打印声明行**：三档工具**默认不装载**（v18.2.6 起，见 `docs/installation.md`），所以「dump 里看得到三行」**不等于**「已装载」；要确认装载，看是否设了任一档 `LUNHENG_*_PROVIDER/MODEL` 或 `LUNHENG_TIERING=on`。

## 版本号为什么是纯语义化三段式？

DSH 版独立维护、独立版本线，版本号不与任何外部版本线共享。**v17.0.0 起版本号 = 纯语义化版本，迭代号进 major**：

| 场景 | 版本 |
|---|---|
| 本轮迭代 | 抬 minor（`18.2.0` 形态） |
| 上一轮迭代（未单独发布，内容随本版首发） | 抬 major（`17.0.0` 形态） |
| 同一轮内修补 | 抬 patch（`18.2.4` 形态） |
| 同一轮内小步改进 | 抬 patch（同上） |

> **表中数字只是示例**（v18.2.4 更正）：旧版此处写死成当时的版本 `18.2.1`，此后每次 bump 都不同步、静默滞留了三个版本——**「当前版本」的唯一真源是 `package.json` 的 `version`**（也可 `npm view lunheng-article-pipeline version`）。本文件刻意不再复述具体当前版本号。

**为什么不能写成 `dsh.17.0`**：npm 强制 [semver](https://semver.org)，`major.minor.patch` 三段必须是数字，`dsh` 只能出现在 `-`（prerelease）或 `+`（build metadata）之后——实测 `npm publish` 会直接以 `Invalid version` 拒绝。

**历史版本号** `2.5.2-dsh.N`（截至 `2.5.2-dsh.17`）沿用语义化基线 `2.5.2` + DSH 迭代后缀；换成纯 semver 是为了**去掉那个与 DSH 迭代无关的数字前缀**，同时保证单调递增（`17.0.0 > 2.5.2-dsh.17`、`18.0.0 > 17.0.0`，老用户不会看到「降版」）。

**「dsh 通道」怎么装**：`npm i lunheng-article-pipeline@dsh`（dist-tag `dsh` 始终指向最新 DSH 迭代版）。

## 封面为什么没有文生图？

DSH 无内置图像生成工具，封面降级为 SVG 矢量风（本地，程序化）或主人投喂图片。

## 为什么 T3 案例检索员「任何量级必 spawn」？

为保证三角验证可审计——即使主题「无需案例」，T3 也会显式产出 [C-空] 空卡声明无案例需求，避免留下「到底查没查案例」的模糊地带（教训 #56）。

## 要不要预先准备素材？素材池是什么、在哪里？

**不必预先准备**（v19.6.6 新增）。论衡有一个**跨项目证据素材池**：

- **位置**：`<工作区根>/evidence-pool/`（与 `run/` 平级）。它**不随插件分发**，主控**首次查池时惰性创建**空骨架——所以「装完没看到这个目录」是正常的，跑第一个项目的 Phase 0 就会出现。
- **怎么长**：滚雪球——项目① Phase 5 把被采纳的证据回写进池，项目② Phase 0.5 查池命中即可复用，池随项目数单调增长。**你什么都不预设，这条链照跑**。
- **你要做什么**：只有**长期共享**的一手原件（专著 / 公共数据集 / 长期引用的论文）才需要手工放进 `evidence-pool/raw/{books,datasets,papers,misc}/`（**A 轨**，跨项目）；**本项目一次性**材料走 `run/<项目名>/主人投喂清单.md`（**B 轨**）——两条路**互不替代**。
- **你会看到什么**：Phase 0 的简报里有一行机器可读的 `POOL=` 行（路径 + 现有条数 + 命中数）；Phase 5 的交付说明里有「证据素材池贡献」（本次新沉淀 / 复用 / 池累计）。

机制真源 = [`skills/lunheng-article-pipeline/references/_shared/素材池.md`](../skills/lunheng-article-pipeline/references/_shared/素材池.md)（§十二 可见性与 `POOL=` 行；§11.5 档 B 诚实边界）。

## 刷新后「聊天区消失」/ 输入框和欢迎语都不见了？

**症状**（≤ 19.27.16，已在 **19.27.17** 修复）：会话页只剩「论衡开工」那块「基本设置 / 文风基线 / 项目素材」大表单，欢迎语、模型选择、输入框全被挤到可视区之外；点表单右上角「收起」立刻恢复。

- **原因**：开工台（注册在 `conversation.input.dock`）的展开态曾按 `localStorage['lunheng.workbench.open']` 跨刷新持久化，该值为 `'1'` 时刷新页面即**无声自动整屏展开**；展开区高度又是固定 px（表单 320 + 预览 150 + 标题/操作行 ≈ 540），矮窗口足以把 composer 整块顶出去。**与宿主版本无关**——报告环境的 `0.2.0-rc.2` 本就在受支持区间内（`peerDependencies` = `>=0.1.2-rc.1 <0.3.0`）。
- **处置**：19.27.17 起展开态**不再持久化**（进页面恒为收起），两个滚动面改为 `min(<px>, <N>vh)`（展开总高 ≤ 42vh + 固定件，高屏视觉不变）。
- **暂时无法升级**：点「收起」即可；或在浏览器控制台执行 `localStorage.removeItem('lunheng.workbench.open')` 后刷新。
