# 论衡速查卡（v19.27.17）

> **定位**：新人「第一眼需要知道的硬数字」**单一真源**——所有用户文档**只引本卡**、不在自己文档里复述数字。本卡是 `audit-report-v18.78.0.md` §7.2 立项的落地产物。
>
> **改这里 = 改主文档真源**。任何与本卡不一致的字面 = 漂移（`consistency-check.mjs` 不一定全机检覆盖，**主控人工复核**）。
>
> **维护者规则**：数字变更先改本卡、再 grep 全文核对「是否还在某文档中复述了旧数字」（v18.78.0 文档全量审计 §7.3）。

---

## 版本

| 项 | 值 | 真源 |
|---|---|---|
| 当前版本 | **v19.27.17** | `package.json#version` |
| 引擎锚定（子技能 `lunheng-commands`） | **v19.27.17**（规则 ㉖ 机械对账） | `skills/lunheng-commands/SKILL.md` description + L8 |

## 角色与 Phase

| 项 | 值 | 真源 |
|---|---|---|
| 角色数 | **9 个独立角色 T1-T9 + 主控 T0**（T0 = 调度 + T8 终检执行双重身份） | `references/glossary.md` §一 |
| Phase 主阶段数 | **6**（Phase 0-5，1.5/2.5/3.5/3.6/4.2/4.5/4.6/4.7 是子阶段） | `SKILL.md` §⚡ 启动速查表 |
| 人在环节点 | **4**（Phase 0 定题 / 2.5 大纲 / 3.5 洞察 / 5 终稿；Phase 3.6 T6 批判非人在环） | `references/agents/00-主控-扩展职责.md` §二十一 |

## 闸门 / 修订回环

| 项 | 值 | 真源 |
|---|---|---|
| 阶段闸门 | **2 道**（T2.5 检索→分析；T7.5 审计→终检） | `SKILL.md` §⚡ |
| **M 门总项数** | **机检 25 项 + 人工 1 项 = 总 26 项**（M-Form 11 + M-Exist 12 + M-Integrity-1 + M-Fact-1 = 机检 25；M-Integrity-2 = 人工 1） | `references/_shared/M-Gate-Algorithm.md` L23 |
| M 门脚本实测 `total` | **25**（与机检 25 一致；脚本头注释 v18.61.1 收口、v19.8.0 增 M-Exist-12） | `skills/.../scripts/m-gate-check.mjs` L14 |
| G 清单 | **G0-G14 主项 15 个 + G15 模式相关项**（v18.18.0 口径，v18.34.0 更正） | `references/glossary.md` §二（G 清单） |
| 修订回环 | **三环制（A 轨 / B 轨 / G 环）**：A 轨 ≤2 轮纠错；B 轨至多 +1 深化（主控触发轮 T6/T9/洞察共享）；G 环 1-2 轮（v18.75.0 新立、G14 终闸 Warning/Fail 触发，**不占 B 轨**） | `references/glossary.md` §十二.1 |

## 文类档案（T9 启用决策树）

| 文类 | T9 视角 | T9 启用 | T9 后处置 |
|---|---|---|---|
| `academic-cn` / `academic-hum` / `academic-case` | 三视角 | **必选不可关** | B 轨 |
| `lit-review` | 三视角 | 可选（主人 Phase 0 选 on/off） | B 轨 |
| `course` / `book-review` / `policy` / `report-3rd` / `biz-review` / `industry` / `wechat` | 单视角 | 默认不选（主人 Phase 0 可显式开） | 只出建议件 |

> **真源**：`references/_shared/文类档案.md` §决策树（v18.77.0 P-9 收口）。
>
> **历史漂移（已修）**：v18.77.0 P-3 之前多份文档用通配 `academic-*`，现已全部收口为特指 `academic-cn/-hum/-case`（`AGENTS.md` / `QUICKSTART.md` / `skills/.../README.md` / `references/agents/00-主控-coordinator.md` / `references/glossary.md` §一 / `references/templates/status-template.md` / `status-template-lite.md` 七处，2026-10-06 修订落地）。

## 脚本 / 命令 / 一致性规则

| 项 | 值 | 真源 |
|---|---|---|
| 随包脚本（`skills/.../scripts/*.mjs` 顶层） | **37 个**（`_lib/` 子目录为共享库非入口，不计；v19.13.0 增补 `ref-verify`）＋子技能 `skills/lunheng-commands/scripts/*.mjs` 顶层 **5 个**（route-command / pending-cli / history-cli / stats-cli / owner-cli，v19.27.11 补入声明面） | `SKILL.md` §执行能力边界「随包脚本白名单」行；`tests/scripts/list*.test.mjs` 派生命令（v18.18.0 审计修订：`P-5` 关闭「31 vs 35」误报） |
| `/lunheng` 斜杠命令数 | **13 个**（-draft/-resume/-cite/-audit/-journal/-ppt/-history/-rollback/-status/-stats/-abort/-gate/-help） | `skills/lunheng-commands/scripts/route-command.mjs` COMMANDS 表；规则 ㉕ 机械对账 |
| `cordis.patch.yml` 行数 | **4 行**（1 自注册 + 3 分档）+ **6 处 `!!js`**（3 disabled + 3 agentOptions） | `cordis.patch.yml` 实测 |
| `consistency-check.mjs` 主规则 | **42 类主规则**（近四版 ㊳-㊶ 依次立：G14 类数口径 / 执行面允许面 / 四门事实单一登记表 / M 门项数表述；v19.27.7 ㊷ 四门文件名与默认阻塞语义**反向**对账〔散文 → 真源〕；**子规则计数不再声明**——带字母后缀的标签实测十余个；本卡数字由规则 ㉟ 机械对账，其余文档只许指向登记表） | 真源 = `skills/lunheng-article-pipeline/scripts/_lib/cc-rules/rule-registry.mjs` 的 `RULE_REGISTRY`（§五 各模块按 `// <编号> ` 形态登记规则级标签） |
| DSH 原生工具 | **4 个**（`lunheng_m_gate` / `lunheng_char_count` / `lunheng_handoff_check` / `lunheng_ethics_sanitize`；读取与校验只读，`m_gate` 传 `report` 时写门报告且受路径围栏；v18.60.1 加伦理脱敏） | `SKILL.md` §DSH 原生能力接缝 |
| **常驻上下文面**（每会话固定开销） | `SKILL.md` + `AGENTS.md` **合计上限 59.0 KB**（v19.8.0 反哺 v9 **上调** 57→61 KB：D1/D6-b/D6-c/D3 把 Phase 主干 S1-S6 + 人在环两门+两通知 + 轻量快轨 + M 门计数写进 SKILL.md，均属运行期承重；v19.6.0 **上调** 54→57 KB：架构与机制反哺批 §3.1 把 `--session-log`〔人在环独立核对层〕写进 SKILL.md 两处——抬前实测余量仅 **10 B**，属「等效禁止再写」的失效态，按定案 ① 公式重核；v18.88.0 **下调** 56→54 KB：依主人「多宿主收口」裁定——AGENTS.md §关键规则 7 组同事实条目收为指针 → 常驻集 54,812→53,310 B〔52.1 KB〕，按定案 ① 公式重核；v18.86.0 曾下调 60→56 KB）；逐文件上限 **44.0 / 16.0 KB**（v19.8.0：SKILL.md 42→45 KB，同批）。⚠️ **长期目标 51,200 B 仍未达成**：剩余为唯一宿主承重（子代理失败三段式 / M 门行〔有机械消费者〕/ 各条一句话判据），**再压须删承重**。余量/实测**逐轮以 `repo-hygiene-check` ⑨ 输出为准、本卡不复述**（复述即漂） | `scripts/repo-hygiene-check.mjs` 的 `ALWAYS_LIMIT` + `DOC_BUDGET`（规则 ⑨）；**上限与逐文件值由规则 ㊲ 机械对账** |
| **词预算登记数** | **59 条**（≥12 KB 的 `.md` 逐文件棘轮）；**合计上限 1728.0 KB**（**2026-10-29：SECURITY 41→31 KB（三轮瘦身批），共 −10 KB**；**v19.27.11：SECURITY +3 KB（⑧c 扩到子技能）+ quick-facts +2 KB，共 +5 KB**；**v19.27.10：quickref +3 KB（G16）**；**v19.19.3：抬 A14+07 卡**；**v19.11.0：抬 `docs/installation.md` 13→15 KB**；**v19.10.0：抬 CONTRIBUTING.md 19→21 KB**；**反哺 v9：抬五条**（SKILL.md / pipeline-readme.md / M-Gate-Algorithm.md / QUICKSTART.md / 规范-机械门对照表.md，合计 +14 KB）；2026-10-16 丁案批：**新登记一条**——`_shared/负知识账本.md` 14 KB〔新增 §九.2 同名判同口径：强判据 = claim 归一化逐字相等、**只有它计入复用计数**；登记理由：实测 12,273 B 距 12 KB 线仅 15 B，**实质已到线**〕；前一档 1661.0 KB（同批七：抬 `04-分析-analyst.md` 27→30 KB）；再前 1658.0 KB（同批五：抬 `_shared/素材池.md` 14→16 KB）〔§一 惰性创建段补「池已存在但结构不完整」分支：`pool-query` 须报「补齐缺失的池文件」而非谎称「已创建骨架」，V5b〕；再前 1656.0 KB（同批 C/D：抬 `01-文献检索` 21→23 KB + `09-审稿` 43→45 KB）；再前 1652.0 KB（同批 B/A：抬 `机检硬格式.md` 19→22 KB）；v19.6.6 素材池可见性批：抬三条 + 新登记一条——`templates/任务简报-template.md` 37→41 KB〔§主人侧输入与待办 新增机器可读 `POOL=` 行 + 「两条素材路不许混」条：把「查池」从 Phase 0.5 提前显形到 Phase 0，因为对池的决策在 Phase 0 而池的创建在 Phase 0.5〕＋ `pipeline-readme.md` 134→136 KB〔流水线全景 Phase 0.5 行**行内追加** A/B 轨解歧句；行内追加是为了不动被测试钉死的行号〕＋ `docs/quick-facts.md` 14→16 KB〔本卡自身的登记数 / 合计上限两处随本批同步〕＋ 新登记 `references/_shared/素材池.md` 14 KB〔新增 §11.5 第 4 条「首用空池 = 档 B 不适用」+ §十二 可见性与 `POOL=` 行；该文件此前 10.9 KB 未达登记线〕；四条均按定案 ① 公式重算，长期目标不变；v19.6.4：`外部检索源接入面.md` 再抬 34→37 KB〔新增 §十 `search_papers` 用法规矩〕；v19.6.3：同文件按定案 ① 抬 32→34 KB〔新增 §九「查询范式匹配」〕；v19.6.2：`SECURITY.md` 按定案 ① 抬 36→38 KB〔F-1 写参数围栏 + P2-7 读参数围栏两处**强制披露**〕；v19.6.0 架构与机制反哺批抬两条：`SKILL.md` 40→42 KB〔`--session-log` 独立核对层入常驻面〕＋ `DESIGN.md` 15→16 KB〔撤除过时的「1700 行」自述——该句前提失真 36% 而无门会核；按定案 ① 归位〕；v19.5.4 口径一致性核实批抬一条：`glossary.md` 42→44 KB〔反哺报告 §3.2/§3.6/§3.8/§3.12 四处口径收口——补 `M-Fact-1` 枚举、`G0.5`/`G2.5` 降为 G0/G2 子检查、教训区间改编号真源指针、「45%」补三重限定；按定案 ① 公式重算，长期目标不变〕；v19.5.0（T7 反哺批）抬四条 + 新登记二条：`07-审计-auditor.md` 48→53 KB〔新增「压缩轮专项」四项固定复核——本项目三条新伤全部出自压缩轮〕＋ `agents/08-终检-finalizer.md` 20→24 KB〔交付物最小清单五件、缺一 hard 20——此前 T8 只报 soft A0，五件齐不齐全靠自觉〕＋ `templates/闸门记录-template.md` 14→16 KB〔A/B 轨「同轮无独立复核」豁免形态 + 账本 malformed 逐行降级口径〕＋ `gates/14-中文AI痕迹-gate.md` 20→23 KB〔C 类计数固定三档 + 逐处列 L 号 + 命中前词表对账〕；并新登记 `references/dispatch-cards.md` 14 KB〔交接报告「本轮遗留 P0/P1 净额」字段 + 同路径并行写护栏〕＋ `docs/quick-facts.md` 14 KB〔本卡自身越 12 KB 登记线〕；六条均按定案 ① 公式（实测 + 1.5 KB 向上取整到整 KB）重算，长期目标不变；v19.4.0 抬五条 + 新登记一条：`任务简报-template.md` 35→37 KB〔新增「外部服务授权串」字段块——该字段是机检判据 **A11** 的唯一机械落点〕＋ `规范-机械门对照表.md` 52→55 KB〔登记 A11 行：该表是「代码 ⇒ 表」方向的收款方，加码必加行、加行必增字节〕＋ `M-Gate-Algorithm-appendix.md` 14→16 KB〔新增「文档声称有一条分支、实现里零命中」教训行；抬前余量仅 2 B〕＋ 技能目录 `README.md` 16→20 KB〔补齐 `references/agents/05-写作-writer.md:298` 悬空指向的 `## 定稿引用规范`〕＋ `references/agents/00-主控-扩展职责.md` 64→67 KB〔§十一 新增「交付形态转写」——「引用模式=内联」的唯一可执行落点〕，并新登记 `references/_shared/文类档案.md` 15 KB〔「引用模式」列 = 交付形态的语义澄清块〕；六条均按定案 ① 公式重算，长期目标不变；v19.1.11 上调二条：`docs/introduction.md` 34→36 KB ＋ `maintainers.md` 41→44 KB〔2026-10-13 全量审计核实批：新增 §实战验证 ③ 19.x 复跑实证段 + §6.1 审计三条纪律；两条均为主人直接指令后落地，按定案 ① 公式重算，长期目标不变〕；v19.1.9 上调一条：`SECURITY.md` 35→36 KB〔`token-cost.mjs` 新增落盘 → `script-surface` 门强制要求登记写面，而该文件此前贴死上限、余 0 B〕；v19.0.4 抬升 `references/DESIGN.md` 13→15 KB〔v19.0.2 首登时公式算错、余量仅 711 B，本批加图标口径行即顶穿；按定案 ① 重算〕；v19.0.2 首次登记 `references/DESIGN.md`〔界面设计基准〕；v18.98.0 上调一条：pipeline-readme.md 132→134 KB〔§派发话术新增「跨臂实测前置清单 6 条」，E3 四臂反哺〕；v18.96.0 上调一条：pipeline-readme.md 130→132 KB〔素材池 Phase 0.5 查池行〕；v18.90.0 首次登记 `docs/installation.md` 13 KB ＋ `SECURITY.md` 32→35 KB〔新增可选 HTTP 读面的强制披露〕；v18.88.0 下调一条：`AGENTS.md` 19→16 KB〔多宿主收口，长期目标已达成〕/ 上调一条：`maintainers.md` 34→41 KB 承接迁入；v18.88.0-prep 首次登记 `errors.md` 14 KB）；实测合计同左**不复述**（逐轮以规则 ⑨ 输出为准） | 同规则 ⑨；报告逐轮打印「越线 N 条 / 余量 <1 KB N 条 / 建议下调」三段；**条数与上限由规则 ㊲ 机械对账** |

## 退出码族（按 §真源排序）

| 脚本族 | 码 | 含义 |
|---|---|---|
| **M 门族**（`m-gate-check.mjs`） | 0 / 1 / 2 / 3 / **30** / 70 | 通过 / P1 / P0 / 仅 P2·soft·SKIP（需 LLM 复核）/ `--adjudicate` 裁定被拒（红线/四件套/缺 `true_p0`；v18.12.0 L-05）/ 内部错误（EX_SOFTWARE） |
| **所有脚本**（含 M 门） | **10** | 参数或路径错（含异常路径，`_lib/exit-guard.mjs` 统一映射，**不得与 P1 撞码**） |
| `model-routing.mjs` | **4** | 需人工决定（与 M 门 3 语义**刻意分离**，不可读作「可放行」） |
| `handoff-check.mjs` | **20 / 21 / 22** | 产物缺失或 0 字节（重派）/ 结构·版本·成对·回报段不合（续接补交）/ 仅软提示（人工复核放行）——**与 M 门 1/2/3 刻意分离** |
| `md2html.mjs` | **40** | 导出被拒 / `--strict` 校验失败（v18.12.0 起；**不是** M 门「2 = P0」） |
| **所有脚本**（含 M 门） | **70** | 内部错误（EX_SOFTWARE）——`exit-guard` 对非 fs 类未捕获异常使用；与内容判定无关 |
| **门内解析/读取失败** | **70** | `severity: 'ERROR'`（v18.62.4 §8 全量审计 P1-3 起；`final-check.mjs` 不得读成「P1 残留」） |

> **判据**：只要脚本**不做内容判定**，它的 `1` 就一定是撞码（v18.12.0 已把全部「用法/参数错」收口到 `10`）。
> **真源**：`docs/troubleshooting.md` §8 + `AGENTS.md` §关键规则 + `_lib/exit-guard.mjs`。

## 实战案例

| 时段 | 真源 |
|---|---|
| v2.x 期间（2026-08 前后） | `docs/introduction.md` §实战验证（v2.2.8-dsh.2/3 公众号短评 + v2.3.7-dsh.8 甲醛白菜事件 4200 字深度文） |
| v18.x 期间（2026-08 ~ 2026-09） | `README.md` 顶部 Verification status 表（6 个 case：品牌一致性 7900 字 / 原创性悖论 9500 字 / 教师田野隔离 12000 字 / 生成式 AI 学生写作 2000 字 / 甲醛白菜 4200 字 / Notion vs. idea 哲学论文 6280 字） |
| 历次反哺合并入角色卡 | `references/case-studies.md`（v18.x 阶段案例库；SKILL.md 不重复维护） |

> **历史口径声明**：「修订轮」数 = 该 run 的全部写手轮次（含 Phase 3.5 洞察 → v2、批判/T6 修订、G14 轮、审计打回）；**Phase 4.2 审计打回 ≤2 轮是子集上限**——两者量纲不同，不可混读（README.md L202「How to read this table」段已明示）。
>
> **重跑注意**：v18.18.x 起跑通的产物再用当前脚本重跑，会因 M 门新增项（如 M-Form-9/10/11、M-Exist-7）报历史 P0——**视为历史快照、不为交付参考**。

## 路径速查

| 项 | 路径 |
|---|---|
| 主文档（新人首屏） | `README.md` → `docs/introduction.md` → `skills/lunheng-article-pipeline/SKILL.md` → `references/glossary.md` |
| 概念单一真源 | `skills/lunheng-article-pipeline/references/glossary.md` |
| 流水线协议 | `skills/lunheng-article-pipeline/references/pipeline-readme.md` |
| M 门算法 | `skills/lunheng-article-pipeline/references/_shared/M-Gate-Algorithm.md` |
| 派发话术（开工卡） | `skills/lunheng-article-pipeline/references/dispatch-cards.md` |
| 维护者手册 | `skills/lunheng-article-pipeline/references/maintainers.md` |
| DSH 集成 | `skills/lunheng-article-pipeline/references/_shared/DSH-集成方案.md` |
| 排错 | `docs/troubleshooting.md` |
| 安装 | `docs/installation.md` |
| 使用流程 | `docs/usage.md` |

---

> **速查卡修订记录**：
> - **2026-10-06**（v18.78.0）：本卡初版。依据 `audits/论衡插件文档全量审计-v18.78.0.md` §7.2 立项；起草依据 SKILL.md / glossary.md / 文类档案 / consistency-check.mjs / m-gate-check.mjs / troubleshooting.md / cordis.patch.yml 真源。
> - **改这里之前必读**：`references/glossary.md` §十二「文档约定」（v18.22.1 CTX-1）——本卡对硬数字集中维护的判据与该节「一事实多处 + 多宿主」刻意偏离同源。
