# 架构说明

## 角色

| 角色 | 编号 | 职责 |
|---|---|---|
| 主控 | T0 | 定题、拆解、派发、阶段闸门（T2.5/T7.5）、终检（M 门）、状态机 |
| 文献检索员 | T1 | 文献卡 [Lxx]（可信度 A/B/C + GB/T 7714）+ 先行者清单 |
| 数据检索员 | T2 | 数据卡 [Dxx]（🟢🟡🔴 时效 + 信任级别 + 冲突口径并列） |
| 案例检索员 | T3 | 案例卡 [Cxx]（事件结构 + 多方立场 + ≥2 来源，任何量级必 spawn） |
| 分析员 | T4 | 分析大纲（论点-论据映射 + 反方论证规划 + 三角验证） |
| 写手 | T5 | 初稿（引用/数据/案例全标编号） |
| 批判伙伴 | T6 | 批判报告（C1-C7 反方攻击） |
| 审计员 | T7 | 审计报告（G0-G14，只审不改） |
| 终检 | T8 | 主控亲完成（M 门 + 定稿 + 证据包；有角色卡 `references/agents/08-终检-finalizer.md`，但**执行者 = 主控本人不 spawn**） |
| 同行评审 | T9 | 审稿报告（6 维度评分 + 期刊匹配 Top 3，可选） |

编号 = 阶段顺序（T1-T3 检索 / T4-T5 加工 / T6-T9 防御）。

## 三角验证

任何核心论点必须能映射到三类证据至少两项：

- [Lxx] 学术依据 + [Dxx] 量级数据 + [Cxx] 具体事件

缺角就标缺口，严禁编造。

## 审计 G0-G14 + M 门

G0 覆盖度 / G0.5 视角一致性 / G1 分级核验（C 级 100% web_search 实测）/ G2 数据溯源 / G2.5 案例核验 / G3 逻辑 / G4 格式 / G4-2 文末四节 / G5 规范 / G6 论据自标 / G7 原创性 / G8 成品度 / G9 时序 / G10 一致性 / G11 时效 / G12 信任级别一致性 / G13 AI 使用披露 / G14 中文 AI 痕迹闸（8 类检测维度；Phase 4.6 串行）。

终检前主控跑 **M 门**（`references/_shared/M-Gate-Algorithm.md`）：**总 25 项 = 机检 24 项（M-Form 11 项 + M-Exist 11 项 + M-Integrity-1 + M-Fact-1）+ 人工 1 项（M-Integrity-2）**，LLM 兜底执行，产出 `final/M-Gate-Report.json`，exit 0 才交付。

## 原创性保证

T1 先行者检索 → T4 差异点声明 → T7 G7 原创性审计，防止「重复/改写已公开文章」。

## DSH 适配

技能以「bundle」形态发布，两部分各司其职：**包入口 `lib/index.js`** 经 `ctx.skills.register()` 注册**两个技能**（`lunheng-article-pipeline` 主技能 + `lunheng-commands` 内嵌子技能；`resourceBase` 指向随包的 `skills/lunheng-article-pipeline/`，故角色卡/模板/脚本的相对引用在任意 cwd 下可解析，且注册即 effect、卸载自动清理）；**`cordis.patch.yml`**（由 `package.json` 的 `dsh.bundle.patch` 声明）只叠加 3 档 subagent 工具。工具集由 DSH Agent 预设决定，模型路由由 `settings.yaml` 配置。
