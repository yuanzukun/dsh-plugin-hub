#!/usr/bin/env node
// 打包产物冒烟（v18.0.5 新增，第三方审计 P1-7）：验证**发布物本身**（而不是源码树）能否被装载。
//
// 动机：`.github/workflows/` 里此前**没有任何 job 覆盖「安装→启动→卸载」**（`dsh-plugin-dev verify`
//   在本机被 DSH Desktop 的 dsh shim（硬编码 DSH_HOME）+ pnpm 原生依赖策略挡住，CI 也没跑过它）；
//   而历史上 v18.0.0 的「装了但技能从不注册」缺陷**恰好在这些门都覆盖不到的地方**。
//   本脚本用零依赖方式补上「**pack 出来的那包**能不能注册」这一段：
//     ① `npm pack` → 解包到临时目录（真发布物，含 files 白名单裁剪）
//     ② 关键文件齐备（入口 / patch / SKILL.md / 随包脚本（**数量以 SKILL.md 白名单为准，不硬编码**）/ `_lib`）
//     ③ patch 里本包自注册行**恰好一行**（缺了它 → loader 不会 import 入口 → 技能不注册）
//     ④ patch 行 name 都在 package.json 声明或宿主核心包白名单内（防宿主改名后整树起不来）
//     ⑤ **真跑解包后的 `lib/index.js` 的 apply**（最小 ctx：skills.register + effect），断言
//        注册名 / 正文非空 / frontmatter 已剥离 / resourceBase 指向解包目录 / disposer 可调用
//     ⑥ `tests/` 不得随包（files 白名单裁剪生效）
// 退出码：0 通过｜1 失败（不通过）｜10 参数/环境错（npm/tar 不可用等）
//
// 边界（如实）：本脚本**不等于**官方 `dsh-plugin-dev verify`——它不启动真实 DSH profile，
//   因此不能证明「宿主 loader 会加载本包」；那条由 `tests/bundle-contract.test.mjs`（patch 自注册行）
//   与 `tests/entry.test.mjs`（apply 真跑）在源码树侧覆盖，本脚本则把同一套断言搬到**发布物**侧。
import { spawnSync } from 'node:child_process'
import { existsSync, mkdtempSync, readFileSync, readdirSync, realpathSync, rmSync, statSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join, dirname, resolve, relative } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { installExitGuard } from '../skills/lunheng-article-pipeline/scripts/_lib/exit-guard.mjs'
import { scanShipped, describeViolations } from './_lib/pack-negative.mjs' // D-1②：与 repo-hygiene 共用同形负清单
import { untarGz } from './_lib/untar.mjs' // v19.27.12：系统 tar 失败时的内置解包兜底（见该文件头注释）

installExitGuard()

const HERE = dirname(fileURLToPath(import.meta.url))
const ROOT = resolve(HERE, '..')
const PKG_NAME = 'lunheng-article-pipeline'
import { HOST_CORE_ALLOW } from './_lib/host-contract.mjs' // §8.3 #35：宿主核心包白名单单一真源（原先两处各写一份且内容不同）

// 路径规范化（v18.1.1，CI 实测踩到）：`mkdtempSync(tmpdir())` 拿到的路径**可能不是真实路径**——
// macOS 的 `os.tmpdir()` 返回 `/var/folders/…`，而 `/var` 是指向 `/private/var` 的符号链接；
// Windows 上若 `TEMP` 指向 junction 同理。Node 解析 ESM 时会 `realpath`，于是入口算出的
// `resourceBase.path` 是**规范化后**的路径。**若这里不规范化，字符串比较必然不等** →
// 打包产物冒烟在 macOS 上假红灯（v18.1.0 的 tag CI 就是这么红的：`macos-latest` 的
// 「随包脚本回归测试」job）。同一原因也会让本脚本喂给 guard 的探测路径与 guard 的受保护根
// 前缀不匹配 → 「guard 未否决技能包内写入」假失败。故：**解包目录一律先规范化再使用**。
const canon = (p) => { try { return realpathSync(p) } catch { return resolve(p) } }

const problems = []
const ok = (msg) => console.log(`  ✓ ${msg}`)
const bad = (msg) => { problems.push(msg); console.log(`  ✗ ${msg}`) }

const sh = (cmd, args, opts = {}) => spawnSync(cmd, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], ...opts })

console.log(`\n=== 打包产物冒烟（pack-smoke）· ${ROOT} ===`)
const tmp = mkdtempSync(join(tmpdir(), 'lunheng-pack-smoke-'))
try {
  // ① pack（Windows 下 spawnSync 不能直接跑 `npm.cmd`，需 shell；路径用引号包住防空格）
  const packed = process.platform === 'win32'
    ? sh(`npm pack --pack-destination "${tmp}" --silent`, [], { cwd: ROOT, shell: true })
    : sh('npm', ['pack', '--pack-destination', tmp, '--silent'], { cwd: ROOT })
  if (packed.status !== 0) {
    console.error(`npm pack 失败（exit ${packed.status}）：${(packed.stderr || packed.stdout || '').trim().slice(0, 400)}`)
    console.error('→ 退出码 10（环境问题：npm 不可用或不可写）')
    process.exit(10)
  }
  const tgz = readdirSync(tmp).find((f) => f.endsWith('.tgz'))
  if (!tgz) { console.error('npm pack 未产出 .tgz'); process.exit(10) }
  console.log(`  · 产物：${tgz}`)

  // ② 解包（tar 在 ubuntu/macos/windows10+ 均可用；v18.16.0 起改用 cwd 相对路径，
  //   规避 Windows + Git Bash 下 GNU tar 把绝对路径 C:\... 当成远端主机而报
  //   `Cannot connect to C: resolve failed` 的环境差异 —— 与原行为等价）
  // 强制走内置解包器（仅用于回归：见 tests/scripts/untar.test.mjs 的端到端用例）——
  //   让「系统 tar 坏掉」这条分支在 CI 里被真的跑一遍，而不是等到某个跑者抽风才第一次执行。
  const forceBuiltin = process.env.LUNHENG_PACK_SMOKE_FORCE_BUILTIN_TAR === '1'
  const untar = forceBuiltin
    ? { status: 3, stderr: '强制内置解包（LUNHENG_PACK_SMOKE_FORCE_BUILTIN_TAR=1）' }
    : sh('tar', ['-xzf', tgz], { cwd: tmp })
  if (untar.status !== 0) {
    // v19.27.12（2026-10-25 发版实测）：`pack-smoke (windows-latest)` 自 2026-10-20 起偶发
    //   `tar: Archive entry has empty or unreadable filename ... skipping` → exit 1 → ci.yml 红 →
    //   publish.yml 的「同 SHA CI 绿闸」fail-closed，发版被卡。同一个 tgz 在 ubuntu/macOS/GNU tar 1.35
    //   都能解开（`tar -tzf` 逐条一致、`gzip -t` 通过），即**包是好的、跑者的 tar 有毛病**；
    //   连重跑 2 次（共 3 次）全红，靠 rerun 碰运气不可接受。故改为**内置解包器兜底**：
    //   先把系统 tar 可能写了一半的 `package/` 清掉，再逐块校验着解——门本身一格不松
    //   （后面所有断言仍跑在「从 tgz 解出来的真实文件」上）。
    const reason = (untar.stderr || '').trim().split('\n')[0] || `exit ${untar.status}`
    console.log(`  ! 系统 tar 解包失败（${reason.slice(0, 160)}）`)
    console.log('  · 改用内置解包器（scripts/_lib/untar.mjs）重解同一份 tgz')
    rmSync(join(tmp, 'package'), { recursive: true, force: true })
    try {
      const res = untarGz(readFileSync(join(tmp, tgz)), tmp)
      console.log(`  · 内置解包器：${res.files} 个文件 / ${res.dirs} 个目录（跳过 ${res.skipped} 个非普通文件）`)
    } catch (e) {
      console.error(`内置解包器同样失败：${e.message}`)
      console.error('→ 退出码 10（环境问题：系统 tar 不可用，内置解包器也解不开这份发布物）')
      process.exit(10)
    }
  }
  const pkg = canon(join(tmp, 'package'))

  // 解包后的**真实文件清单 + 解包体积**（直接数盘上内容，比读 `npm pack --json` 更硬：
  //   验的是「用户解包后会看到什么」，而不是 npm 自己报的清单）
  const shipped = []
  ;(function walk(d) {
    for (const e of readdirSync(d, { withFileTypes: true })) {
      const p = join(d, e.name)
      if (e.isDirectory()) walk(p)
      else shipped.push(relative(pkg, p).split('\\').join('/'))
    }
  })(pkg)
  const unpackedSize = shipped.reduce((s, rel) => s + statSync(join(pkg, rel)).size, 0)

  // ② 关键文件齐备（v18.2.6：`lib/*` **从解包产物派生**，不再逐个硬列）
  //   · 为什么派生：`lib/` 是包入口目录、正在演进（新增模块是常态），硬列清单会同时犯两个错——
  //     ①新增的入口模块**不进清单**（没人被要求同步它），②清单里删掉的文件仍被当成必备。
  //     口径与 `repo-hygiene-check` 规则①一致：**入口目录里的每个 `.js` / `.mjs` 都必须随包**，逐个断言存在。
  //   · 与具体文件名解耦（`lib/` 由另一条线改动）：只要求「路径存在」，不要求任何特定文件名。
  //   · v19.27.13（反哺 2026-10-26 F-10）：过滤器从只认 `.js` 扩为 `.js` + `.mjs`——旧实现两侧同滤
  //     `.mjs`（panel / run-path-fence），对账恒绿但 `.mjs` 缺失时用户机 ENOENT 而本门不报
  //     （此前仅靠 `files: ["lib"]` 整目录兜底）。
  const libDir = join(pkg, 'lib')
  const libModules = existsSync(libDir)
    ? readdirSync(libDir, { withFileTypes: true }).filter((e) => e.isFile() && /\.(js|mjs)$/.test(e.name)).map((e) => e.name).sort()
    : []
  if (libModules.length === 0) bad('发布物 lib/ 下没有任何 .js/.mjs（入口目录为空？`main` 会解析失败）')
  // v18.62.4（§8.2 #30）：**期望清单必须来自真源树，不能来自被断言的那个目录**——旧版用
  //   readdirSync(pkg/lib) 派生期望、再断言发布物里有它 = 同义反复，「发布物缺 lib 模块」永不报出。
  const srcLibDir = join(ROOT, 'lib')
  const srcLibModules = existsSync(srcLibDir)
    ? readdirSync(srcLibDir, { withFileTypes: true }).filter((e) => e.isFile() && /\.(js|mjs)$/.test(e.name)).map((e) => e.name).sort()
    : []
  if (srcLibModules.length === 0) bad('真源 lib/ 下没有任何 .js/.mjs（仓库布局异常，本条会退化为空集断言）')
  const libMissingInPkg = srcLibModules.filter((f) => !libModules.includes(f))
  const libExtraInPkg = libModules.filter((f) => !srcLibModules.includes(f))
  if (libMissingInPkg.length) bad(`发布物 lib/ 缺真源已有的模块：${libMissingInPkg.join(', ')}（入口会 ENOENT；检查 package.json files 白名单与打包过程）`)
  if (libExtraInPkg.length) bad(`发布物 lib/ 多出真源没有的模块：${libExtraInPkg.join(', ')}（打包残留？）`)
  const mustExist = [
    'package.json',
    'cordis.patch.yml',
    `skills/${PKG_NAME}/SKILL.md`,
    `skills/${PKG_NAME}/AGENTS.md`,
    `skills/${PKG_NAME}/scripts/_lib/exit-guard.mjs`,
    ...srcLibModules.map((f) => `lib/${f}`),
  ]
  for (const rel of mustExist) {
    if (existsSync(join(pkg, rel))) ok(`随包：${rel}`)
    else bad(`发布物缺 ${rel}`)
  }

  // v19.27.13（反哺 2026-10-26 F-10 + G-3/G-4）：发布物侧**语法冒烟**——`node --check` 只解析不执行，
  //   足以钉住「files 白名单漏文件 / 打包截断」这两类**发布物才暴露**的缺陷：
  //   · lib 全部模块（含 .mjs：panel / run-path-fence——旧过滤器只认 .js）；
  //   · 三个跨层 CLI：owner-cli / history-cli / pending-cli 以 `../../../lib/run-path-fence.mjs`
  //     相对导入**跨出技能目录**，白名单一旦逐文件化即 ERR_MODULE_NOT_FOUND，而所有门照绿；
  //   · client.js：宿主 Web 客户端半边（`exports["./client"]`），此前发布物侧零执行零检查。
  const syntaxTargets = [
    ...libModules.map((f) => join('lib', f)),
    join('skills', 'lunheng-commands', 'scripts', 'owner-cli.mjs'),
    join('skills', 'lunheng-commands', 'scripts', 'history-cli.mjs'),
    join('skills', 'lunheng-commands', 'scripts', 'pending-cli.mjs'),
  ]
  for (const rel of syntaxTargets) {
    const abs = join(pkg, rel)
    if (!existsSync(abs)) { bad(`语法冒烟目标缺失：${rel}（files 白名单漏项？——反哺 F-10）`); continue }
    const r = spawnSync(process.execPath, ['--check', abs], { encoding: 'utf8' })
    if (r.status === 0) ok(`语法冒烟：${rel}`)
    else bad(`语法冒烟失败：${rel}——${String(r.stderr || '').split('\n')[0]}`)
  }
  const scriptsDir = join(pkg, 'skills', PKG_NAME, 'scripts')
  const topScripts = existsSync(scriptsDir) ? readdirSync(scriptsDir).filter((f) => f.endsWith('.mjs')) : []
  // v18.2.5 修（主控实战反哺）：期望数**从发布物的 SKILL.md 白名单动态解析**，不再硬编码 11。
  //   旧写法 `length === 11` 在每次新增随包脚本时都要手工同步——本次加 `apply-diff.mjs`（12 个）
  //   即触发**假失败**「随包脚本数 12 ≠ 11」，而真源（SKILL.md 白名单行）本身是对齐的。
  //   口径与 `consistency-check` 规则⑩ 同源：只取 `=` 与 `+` 之间按 `/` 分隔的**裸脚本名 token**，
  //   这样「脚本数量与清单」这个事实**只有 SKILL.md 一处真源**。
  const pkgSkillPath = join(pkg, 'skills', PKG_NAME, 'SKILL.md')
  const declaredScripts = existsSync(pkgSkillPath)
    ? ((readFileSync(pkgSkillPath, 'utf8').split('\n').find((l) => l.includes('随包脚本白名单')) || '')
      .split('=')[1] || '').split('+')[0].split('/').map((s) => s.trim()).filter((s) => /^[a-z0-9][a-z0-9-]*$/.test(s))
    : []
  if (declaredScripts.length === 0) {
    bad(`无法从发布物 SKILL.md 解析白名单脚本清单（实际随包 ${topScripts.length} 个）`)
  } else if (topScripts.length === declaredScripts.length) {
    ok(`随包脚本 ${topScripts.length} 个（与 SKILL.md 白名单一致）`)
  } else {
    bad(`随包脚本数 ${topScripts.length} ≠ SKILL.md 白名单 ${declaredScripts.length} 个（${declaredScripts.join('/')}）`)
  }

  // ③/④ patch 自注册行 + 行名声明
  const patchPath = join(pkg, 'cordis.patch.yml')
  if (existsSync(patchPath)) {
    const patch = readFileSync(patchPath, 'utf8')
    const selfRows = patch.split('\n').filter((l) => new RegExp(`^\\s*-?\\s*name:\\s*['"]?${PKG_NAME}['"]?\\s*$`).test(l))
    if (selfRows.length === 1) ok('patch 恰有一行本包自注册行（缺它 → loader 不 import 入口 → 技能不注册）')
    else bad(`patch 自注册行数 = ${selfRows.length}（必须恰好 1）`)
    const pkgJson = JSON.parse(readFileSync(join(pkg, 'package.json'), 'utf8'))
    const declared = new Set([pkgJson.name, ...Object.keys(pkgJson.dependencies || {}), ...Object.keys(pkgJson.peerDependencies || {}), ...HOST_CORE_ALLOW])
    const rowNames = [...patch.matchAll(/^\s*-?\s*name:\s*['"]?([^'"\s#]+)['"]?\s*$/gm)].map((m) => m[1])
    const undeclared = [...new Set(rowNames)].filter((n) => !declared.has(n))
    if (undeclared.length === 0) ok(`patch 行 name ${rowNames.length} 处，均已在 package.json 声明或属宿主核心包`)
    else bad(`patch 引用了未声明的包：${undeclared.join(', ')}（宿主改名/移除 → 整棵 profile 起不来）`)
  }

  // ⑤ 真跑解包后的入口 apply
  const entry = join(pkg, 'lib', 'index.js')
  if (existsSync(entry)) {
    const mod = await import(pathToFileURL(entry).href)
    if (mod.name === PKG_NAME) ok(`入口导出 name = ${mod.name}`)
    else bad(`入口 name = ${mod.name}（期望 ${PKG_NAME}）`)
    if (Array.isArray(mod.inject) && mod.inject.includes('skills')) ok(`入口 inject = [${mod.inject.join(', ')}]`)
    else bad(`入口 inject 未声明 skills：${JSON.stringify(mod.inject)}`)

    let registered = null
    const allRegistered = []  // v18.7.1：支持多技能注册（主 + 子如 lunheng-commands）
    let effectUsed = false
    let disposerCalled = false
    // C 组（v18.1.0）：发布物侧同样要覆盖「可选能力」的注册与降级。
    //   · 这里**故意**提供 tools / commands 服务：guard 与命令不依赖宿主包，应当**真注册**；
    //   · 而 `@deepseek-ai/dsh-tools` 在临时解包目录里**不可解析**（真实发布物被 profile 安装时的
    //     常见处境之一），故原生工具必须**安静降级为 0 个**且不拖垮技能注册 —— 正是本脚本要钉住的行为。
    const captured = { guards: 0, guardFn: null, commands: [], tools: [] }
    const services = {
      tools: {
        register(def) { captured.tools.push(def); return () => {} },
        guard(fn) { captured.guards += 1; captured.guardFn = fn; return () => {} },
      },
      commands: { register(def) { captured.commands.push(def); return () => {} } },
    }
    const ctx = {
      get: (n) => services[n],
      effect(fn) {
        effectUsed = true
        const d = fn()
        return () => { disposerCalled = true; if (typeof d === 'function') d() }
      },
      skills: {
        register(def) {
          registered = def  // v18.7.1 前：只保留最后一次（子技能会覆盖）
          allRegistered.push(def)  // v18.7.1：保留所有注册的技能，主技能断言改为 allRegistered.find
          return () => {
            registered = null
            const idx = allRegistered.indexOf(def)
            if (idx >= 0) allRegistered.splice(idx, 1)
          }
        },
      },
    }
    try {
      mod.apply(ctx)
    } catch (e) {
      bad(`apply 抛错：${e.message}`)
    }
    // 入口把 C 组的安装放在 `ctx.effect()` 的异步 IIFE 里，等它落定（解包目录在本地磁盘，几毫秒）
    for (let i = 0; i < 12; i++) await new Promise((r) => setTimeout(r, 20))
    if (effectUsed) ok('注册走 ctx.effect（注册即 effect，卸载可回收）')
    else bad('apply 未使用 ctx.effect —— 卸载无法回收注册')

    // C 组断言（发布物侧）
    if (captured.guards === 1 && typeof captured.guardFn === 'function') {
      ok('机制写保护已注册（tools.guard ×1，全局否决能力就位）')
      const denyInside = captured.guardFn({
        name: 'write',
        arguments: { path: join(pkg, 'skills', PKG_NAME, 'SKILL.md') },
      })
      if (typeof denyInside === 'string' && /机制文件写保护/.test(denyInside)) {
        ok('guard 否决发布物内 SKILL.md 的写入（机制级，而非仅文档纪律）')
      } else {
        bad(`guard 未否决技能包内写入：${JSON.stringify(denyInside)}`)
      }
      if (captured.guardFn({ name: 'write', arguments: { path: join(pkg, 'README.md') } }) === undefined) {
        ok('guard 放行包外/非机制路径（宁松勿误伤）')
      } else {
        bad('guard 误伤非机制路径（会挡住主人正常编辑文档）')
      }
    } else {
      bad(`机制写保护未注册（guards=${captured.guards}）`)
    }
    const cmdNames = captured.commands.map((c) => c.name)
    if (cmdNames.length === 2 && cmdNames.includes('lunheng-status') && cmdNames.includes('lunheng-stats')) {
      ok('人类命令已注册：/lunheng-status ＋ /lunheng-stats（均不产生模型消息）')
      // v19.27.16（R-04）：命令 handler 可返回 Promise（宿主契约），冒烟门必须 await 后再判形态。
      const r = await captured.commands[0].handler({ rawInput: '', signal: new AbortController().signal })
      if (r && r.kind === 'success' && typeof r.text === 'string') ok('命令 handler 返回 CommandResult（可读文本）')
      else bad(`命令 handler 返回形态不符：${JSON.stringify(r)?.slice(0, 160)}`)
    } else {
      bad(`人类命令注册异常：${JSON.stringify(cmdNames)}`)
    }
    if (captured.tools.length === 0) {
      ok('原生工具安静降级为 0 个（解包目录无 @deepseek-ai/dsh-tools）——技能注册不受影响')
    } else {
      bad(`期望降级为 0 个原生工具，实得 ${captured.tools.length}`)
    }
    // v18.7.1：主技能断言改为从 allRegistered 数组中查找 PKG_NAME
    const mainReg = allRegistered.find((r) => r && r.name === PKG_NAME) || registered
    if (mainReg) {
      if (mainReg.name === PKG_NAME) ok(`apply 注册技能 name = ${mainReg.name}`)
      else bad(`apply 注册名 = ${mainReg.name}`)
      const content = String(mainReg.content || '')
      if (content.length > 500) ok(`技能正文非空（${content.length} 字符）`)
      else bad(`技能正文过短（${content.length} 字符）——SKILL.md 可能未随包`)
      if (!content.startsWith('---')) ok('正文已剥离 frontmatter')
      else bad('正文未剥离 frontmatter（首行仍是 ---）')
      const rb = mainReg.resourceBase
      const rbPath = rb && typeof rb === 'object' ? rb.path : null
      // 两侧都走 canon：入口给的 `resourceBase.path` 由 Node realpath 得到（规范化），
      // 解包目录也必须是规范化路径才可比（macOS `/var` ↔ `/private/var`、Windows junction）
      if (rbPath && canon(rbPath) === canon(join(pkg, 'skills', PKG_NAME))) ok('resourceBase 指向解包后的技能目录')
      else bad(`resourceBase 未指向解包技能目录：${JSON.stringify(rb)}`)
      // 角色卡数：**期望值从源码树的 `references/agents/` 派生**（v18.2.6）——旧版写死 `>= 11`，
      //   于是「新增一张角色卡」不需要任何门配合（清单不要求到位），而「某张卡没随包」也可能因
      //   总数仍 ≥11 而被放过。现改为**两边都数**：源码树张数 vs 发布物张数，**必须相等且 > 0**。
      const srcAgentsDir = join(ROOT, 'skills', PKG_NAME, 'references', 'agents')
      const pkgAgentsDir = join(pkg, 'skills', PKG_NAME, 'references', 'agents')
      const expectedCards = existsSync(srcAgentsDir)
        ? readdirSync(srcAgentsDir, { withFileTypes: true }).filter((e) => e.isFile() && e.name.endsWith('.md')).length
        : 0
      const roleCards = existsSync(pkgAgentsDir)
        ? readdirSync(pkgAgentsDir, { withFileTypes: true }).filter((e) => e.isFile() && e.name.endsWith('.md')).length
        : 0
      if (expectedCards === 0) bad('源码树 references/agents/ 下没有任何角色卡——期望值无法派生（目录布局变了？）')
      else if (roleCards === expectedCards) ok(`随包角色卡 ${roleCards} 张 = 源码树 references/agents/ 张数（无缺卡）`)
      else bad(`随包角色卡 ${roleCards} 张 ≠ 源码树 ${expectedCards} 张（发布物缺卡或多卡；期望值由源码树派生，不要写死数字）`)
    } else if (!problems.length) {
      bad('apply 未调用 skills.register')
    }
  }

  // ⑥ tests/ 不随包（v18.0.5）＋ 发布面裁剪断言（v18.2.0：主人指示「最终用户拿到的是功能正常的纯插件」）
  //   ⚠️ 如实边界：npm **强制包含**根目录 `README*` 与 `LICENSE`（实测：从 `files` 白名单删掉、
  //   或加 `.npmignore` 排除，**均无效**；`npm pack --dry-run --json` 实证）。故五语 README 保留在包内，
  //   这是 npm 的规则，不是本仓疏漏——不为它俩造假红灯。
  //
  //   v18.18.3（审计 D-1②）：负清单由「仓库根前缀匹配」改为**路径分量匹配**（共用 `_lib/pack-negative.mjs`，
  //   与 repo-hygiene 同源）。旧口径只看根，导致 `skills/lunheng-commands/tests/`（22 用例）与嵌套
  //   `package.json` 随包时**本门照打印「已裁剪」**——修掉那两个文件只治症，病在匹配口径。
  const negViolations = scanShipped(shipped).filter((v) => v.hits.length > 0)
  for (const v of describeViolations(negViolations)) bad(v)
  for (const v of scanShipped(shipped).filter((v) => v.hits.length === 0)) {
    ok(`发布面已裁剪：不含 ${v.name}（${v.kind === 'dir' ? '目录' : '仓库向文件'}·${v.scope} 作用域）`)
  }
  ok(`发布物解包体积 ${(unpackedSize / 1024).toFixed(0)} KB / ${shipped.length} 个文件`)
} finally {
  rmSync(tmp, { recursive: true, force: true })
}

if (problems.length > 0) {
  console.log(`\n✗ 打包产物冒烟未通过：${problems.length} 项`)
  for (const p of problems) console.log(`  - ${p}`)
  process.exit(1)
}
console.log('\n✓ 打包产物冒烟通过（发布物可装载：入口 + patch 自注册行 + 技能注册 + frontmatter 剥离 + resourceBase）')
