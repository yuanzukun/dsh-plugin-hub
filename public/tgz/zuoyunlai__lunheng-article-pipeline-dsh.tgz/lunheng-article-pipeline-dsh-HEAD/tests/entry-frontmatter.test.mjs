// 入口 frontmatter 解析 + 宿主违约降级 回归测试（v18.2.4，第三方审计 C.1/C.2/C.3/E.2）
//
// 为什么必须有这一条：审计发现入口的 frontmatter 判定是 `text.startsWith('---\n')`，而
//   `readFileSync(p,'utf8')` **不做行尾归一**——SKILL.md 一旦被 CRLF 检出（Windows
//   `core.autocrlf=true`，或任一编辑器另存为 CRLF），首行是 `---\r\n`，判定为假 →
//   **静默**退回内置兜底 description 且 `whenToUse` 不再注册。而 description 是模型侧路由
//   的唯一依据（官方目录只渲染 name + description）。
//   为什么静态门全绿也会漏：既有 `tests/entry.test.mjs` 断言的是「description 非空」「whenToUse 是
//   非空字符串」——**兜底 description 也非空**，故它只在真实仓库的 LF 文件上恰好通过；行尾一变即失效
//   而无任何红灯。教训：断言「字段存在」不等于断言「字段来自真源」。
//
// 本文件的做法：不导出内部函数，而是复制 `lib/` 造一个**最小同构包**，对 SKILL.md 做行尾/编码变体，
//   然后真跑一次 `apply`——测的就是发布物本身的行为（与 pack-smoke 同一思路，粒度更细）。
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { cpSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { isPlatformStderrNoise, settle, withEnv } from './_fixtures.mjs'   // v18.16.0（F-1 反哺 · 共享 settle）；v18.18.0（F-6 · withEnv）；v18.85.0（#3 · isPlatformStderrNoise）

const HERE = dirname(fileURLToPath(import.meta.url))
const PACKAGE_ROOT = join(HERE, '..')
const ENTRY = join(PACKAGE_ROOT, 'lib', 'index.js')
const REAL_SKILL_MD = join(PACKAGE_ROOT, 'skills', 'lunheng-article-pipeline', 'SKILL.md')

/** 内置兜底文案（入口里的 `fields.description ?? ...`）——解析失败时才会出现，故它出现即等于失败。 */
const FALLBACK = '论衡：多 Agent 深度长文流水线（学术论文 / 商业评论 / 行业分析 / 公众号）。'

/** 造最小同构包：`lib/` 全量复制（动态 import 的 tools/guard/commands 也要在）+ 只带 SKILL.md 的技能目录。 */
function makeTempPackage(transform) {
  const root = mkdtempSync(join(tmpdir(), 'lh-fm-'))
  cpSync(join(PACKAGE_ROOT, 'lib'), join(root, 'lib'), { recursive: true })
  const dir = join(root, 'skills', 'lunheng-article-pipeline')
  mkdirSync(dir, { recursive: true })
  const raw = readFileSync(REAL_SKILL_MD, 'utf8')
  writeFileSync(join(dir, 'SKILL.md'), transform ? transform(raw) : raw)
  return root
}

/** 冲刷入口里那次异步安装（C 组动态 import）并回收输出。
 *   v18.16.0（F-1 反哺）：本地实现已上提到 _fixtures.mjs；下方通过 import 引入 80 ms 条件等待版本。 */

/**
 * 真跑一次入口。
 * @returns registrations / logger 记录 / 落到 console.error 的内容（后者只应在无 logger 时出现）。
 */
async function runApply(root, { logger = true } = {}) {
  const logs = { info: [], warn: [] }
  const errs = []
  const originalError = console.error
  console.error = (...args) => { errs.push(args.join(' ')) }
  try {
    const mod = await import(pathToFileURL(join(root, 'lib', 'index.js')).href)
    const regs = []
    const ctx = {
      get: () => undefined,
      effect: (fn) => fn(),
      skills: { register: (d) => { regs.push(d); return () => {} } },
      ...(logger ? { logger: { info: (m) => logs.info.push(m), warn: (m) => logs.warn.push(m) } } : {}),
    }
    mod.apply(ctx)
    await settle()
    return { regs, logs, errs }
  } finally {
    console.error = originalError
  }
}

const withTemp = async (transform, fn) => {
  const root = makeTempPackage(transform)
  try {
    return await fn(root)
  } finally {
    rmSync(root, { recursive: true, force: true })
  }
}

/** 真源 SKILL.md 的正文（与入口应当产出的 body 一致；行尾归一是入口的既定行为）。 */
const realBody = () => {
  const raw = readFileSync(REAL_SKILL_MD, 'utf8').replace(/\r\n?/g, '\n')
  return raw.slice(raw.indexOf('\n---', 4) + 4).replace(/^\n+/, '')
}

test('C.1 CRLF 行尾：SKILL.md 是 CRLF 时 frontmatter 仍必须解析（不得退回兜底描述）', async () => {
  await withTemp((raw) => raw.replace(/\n/g, '\r\n'), async (root) => {
    const { regs, logs, errs } = await runApply(root)
    assert.equal(regs.length, 1, '技能必须照常注册')
    assert.notEqual(regs[0].description, FALLBACK, 'CRLF 行尾下退回了内置兜底 description（审计 C.1 回归）')
    assert.match(regs[0].description, /论衡 v\d+(\.\d+)+：DSH 原生多 Agent 深度长文流水线/, 'description 必须来自 frontmatter 真源（v18.7.1 起加前缀；版本号不写死，防 bump 漂移）')
    assert.equal(typeof regs[0].whenToUse, 'string', 'CRLF 下 whenToUse 也必须注册（丢了 = 模型侧路由字段整块消失）')
    assert.equal(regs[0].content, realBody(), '正文必须与真源一致（行尾归一是既定行为）')
    // v18.57.x（审计修订）改**按内容**断言：旧写 `deepEqual(logs.warn, [])` 把「warn 为空」当成
    //   「解析成功」的同义词——而 warn 通道还有别的合法来源（如「宿主未提供 tools.guard，
    //   机制写保护未安装」这条降级告警）。本用例真正要防的是**解析失败告警**，故只针对它断言。
    assert.ok(!logs.warn.some((m) => /未解析/.test(String(m))), '解析成功时不得报「未解析」：' + JSON.stringify(logs.warn))
    // v18.85.0（/implement #3 修复）：原 `assert.deepEqual(errs, [])` 是**通道全空**断言——把
    //   「stderr 里没有任何东西」当成「入口没退回 console.error」的同义词。而 `--test-isolation=none`
    //   下 Node 自身的弃用警告（`[DEP0190]`）会异步落进本窗口 → **假红**（实测最小复现：
    //   `batch21-…test.mjs` 排本文件之前即 1 红，红的内容逐字是 DEP0190 文案）。
    //   修法与同文件行 93-95（`logs.warn` 改按内容）与行 141-143（`errs` 计数耦合改按内容）**同构**：
    //   只针对**被测对象自己的输出**断言，不把平台噪声算作入口行为。
    assert.deepEqual(errs.filter((e) => !isPlatformStderrNoise(e)), [], '宿主有 logger 时不得退回 console.error（审计 C.3）')
  })
})

test('C.1 UTF-8 BOM：文件带 BOM 时 frontmatter 仍必须解析', async () => {
  // v18.7.0 修订：先剥 raw 自带的 BOM 字符，再注入一个（避免双重 BOM；早期 v18.2.4 修 BOM 剥除仅剥一个）
  await withTemp((raw) => '\uFEFF' + raw.replace(/^\uFEFF/, ''), async (root) => {
    const { regs, logs } = await runApply(root)
    assert.equal(regs.length, 1)
    assert.notEqual(regs[0].description, FALLBACK, 'BOM 下退回了内置兜底 description')
    assert.equal(typeof regs[0].whenToUse, 'string')
    assert.ok(!logs.warn.some((m) => /未解析/.test(String(m))), 'BOM 下不得报「未解析」：' + JSON.stringify(logs.warn))
  })
})

test('C.2 前置空行 + 缺闭合行：必须响亮告警并把兜底形态说清楚（不得静默）', async () => {
  await withTemp(() => '\n---\nname: "x"\ndescription: "不该被采信"\n', async (root) => {
    const { regs, logs } = await runApply(root)
    assert.equal(regs.length, 1, '解析失败也必须照常注册（兜底形态是既定设计）')
    assert.equal(regs[0].description, FALLBACK, '未解析 → 内置兜底')
    assert.equal(regs[0].whenToUse, undefined, '未解析 → whenToUse 不注册')
    const fmWarns = logs.warn.filter((m) => /frontmatter 未解析/.test(String(m)))
    assert.equal(fmWarns.length, 1, '必须恰好告警一次（审计 C.2：此前完全静默）：' + JSON.stringify(logs.warn))
    assert.match(fmWarns[0], /CRLF/, '告警必须点出常见成因，否则收到告警的人无从下手')
  })
})

test('C.3 静音开关：LUNHENG_QUIET=1 静音信息行，但降级告警不静音', async () => {
  // v18.18.0（F-6）：改用共享 withEnv helper（原本地 try/finally；无隔离模式下 env 泄漏会让后续断言假绿）
  await withEnv({ LUNHENG_QUIET: '1' }, async () => {
    await withTemp(() => '\n坏文件（无 frontmatter）\n', async (root) => {
      const { logs } = await runApply(root)
      // 按内容断言（同 C.3 无 logger 那条的理由）：warn 通道另有合法来源，计数耦合会假红。
      assert.ok(logs.warn.some((m) => /frontmatter 未解析/.test(String(m))),
        '降级（warn）必须始终可见——「静默降级」正是 v18.0.0 事故的形态：' + JSON.stringify(logs.warn))
      assert.deepEqual(logs.info, [], 'LUNHENG_QUIET=1 时信息行必须静音')
    })
  })
})

test('C.3 无 logger 宿主：退回 console.error，信息不丢', async () => {
  await withTemp(() => '\n坏文件（无 frontmatter）\n', async (root) => {
    const { logs, errs } = await runApply(root, { logger: false })
    assert.deepEqual(logs.warn, [], '无 logger 时不该走 logger')
    // v18.18.0（F-5 反哺）：原断言 `errs.length === 2` 是**计数耦合**——它靠「临时包里多/少一条
    //   子技能注册 info」凑数，任何与本次被测行为无关的启动文案增删都会让它红/绿（假红/假绿）。
    //   现改按**内容**断言：必须有一条点明 frontmatter 解析失败；且**不得静默**（≥1 条）。
    assert.ok(errs.length >= 1, '宿主无日志面时必须有 console.error 输出（宁可见勿静默）')
    assert.ok(errs.some((e) => /frontmatter 未解析/.test(e)), `必须有一条点明「frontmatter 未解析」，实得：${JSON.stringify(errs)}`)
  })
})

test('E.2 宿主违约：ctx 缺 skills 服务时必须响亮降级、不抛 TypeError，且 C 组能力照常安装', async () => {
  const mod = await import(pathToFileURL(ENTRY).href)
  const guards = []
  const warns = []
  const errs = []
  const originalError = console.error
  console.error = (...args) => { errs.push(args.join(' ')) }
  try {
    const ctx = {
      get: (n) => (n === 'tools'
        ? { register: () => () => {}, guard: (fn) => { guards.push(fn); return () => {} } }
        : undefined),
      effect: (fn) => fn(),
      logger: { info: () => {}, warn: (m) => warns.push(m) },
      // 故意不给 skills：这正是 inject 声明的硬依赖被宿主违约的形态
    }
    assert.doesNotThrow(() => mod.apply(ctx), '缺 skills 不得以 TypeError 形态炸掉入口')
    await settle() // C 组的动态 import 是异步的：不冲刷就断言 = 假绿
    assert.ok(warns.some((m) => /skills/.test(m)), '必须点名缺的是哪个服务（其余 warn 是工具链降级，不计入）')
    assert.equal(guards.length, 1, 'C 组可选能力不得因缺 skills 而一起丢失（机制写保护仍应装上）')
  } finally {
    console.error = originalError
  }
  // v18.85.0（/implement #3 修复）：同 C.1 行 97——`deepEqual(errs, [])` 是**通道全空**断言，
  //   会把平台噪声（`--test-isolation=none` 下 Node 的 `[DEP0190]` 等异步 stderr 行）读成入口行为。
  //   本处与行 97 是同一次修复的两个站点（全库劫持全局 `console.error` 的点只有这两处 + `_fixtures`）。
  assert.deepEqual(errs.filter((e) => !isPlatformStderrNoise(e)), [], '有 logger 时不得产生 console.error 噪声')
})

// ── v18.85.0（/implement #3）：C.3「通道全空」断言的**反事实**回归 ────────────────────────────
// 锁住判据的**双向**：① 平台噪声必须被豁免（否则 no-isolation 假红复发）；② 被测对象自己的输出
//   **不得**被豁免（否则修法把真回归放过——那等于用「让门变绿」换掉了门的牙）。
test('C.3 反事实：平台 stderr 噪声豁免，但入口自身的 console.error 输出必须仍被判出', () => {
  // ① 正向：逐字取自 `--test-isolation=none` 全量跑的真实命中（DEP0190 由
  //    `execFileSync('npm', [...], { shell: true })` 触发，实测弹进本文件 C.1 的采集窗口）
  assert.ok(isPlatformStderrNoise(
    '(node:36704) [DEP0190] DeprecationWarning: Passing args to a child process with shell option true can lead to '
    + 'security vulnerabilities, as the arguments are not escaped, only concatenated.\n'
    + '(Use `node --trace-deprecation ...` to show where the warning was created)'),
  'DEP0190 形态必须被豁免（本缺陷的实测原文）')
  assert.ok(isPlatformStderrNoise('[DEP0190] DeprecationWarning: 无 (node:…) 前缀的形态'))
  assert.ok(isPlatformStderrNoise('(node:123) ExperimentalWarning: something'))
  assert.ok(isPlatformStderrNoise('(node:123) MaxListenersExceededWarning: possible EventEmitter memory leak'))
  // ② 反向：入口自己的诊断**一条都不许**被豁免——否则 `deepEqual(filter(...), [])` 成了恒真断言。
  //    文案逐字取自 `lib/index.js` 的 `say()` 调用点（makeReporter 在无 logger 时走 console.error）。
  assert.ok(!isPlatformStderrNoise('· 论衡原生工具安装失败（不影响技能与流水线）：boom'))
  assert.ok(!isPlatformStderrNoise('· 论衡技能名不一致：SKILL.md frontmatter "x" ≠ 包名 "y"——将以 frontmatter 为准注册。'))
  assert.ok(!isPlatformStderrNoise('frontmatter 未解析（CRLF 行尾或缺少闭合行）'))
  assert.ok(!isPlatformStderrNoise('· H2 伦理脱敏监听器安装失败（不影响技能）：boom'))
  // ③ **断言不空转**（修法的牙）：混合批次（平台噪声 + 真入口报错）过滤后**必须仍有残留**，
  //    即行 97 / 行 178 的 `deepEqual(filter(errs), [])` 对「入口真退回 console.error」仍会红。
  //    没有这一条，把过滤写成 `() => true` 也能让全绿——那正是本修复要避免的「用改绿换掉门的牙」。
  const mixed = ['(node:1) [DEP0190] DeprecationWarning: x', '· 论衡原生工具安装失败（不影响技能与流水线）：boom']
  assert.deepEqual(
    mixed.filter((e) => !isPlatformStderrNoise(e)),
    ['· 论衡原生工具安装失败（不影响技能与流水线）：boom'],
    '混合批次过滤后必须保留真入口报错——否则 C.3 断言退化为恒真',
  )
})
