# examples/preset/ — 论衡分档安装指南

> 版本：v19.27.12

> ✅ **命名状态（v19.0.0 更新；原 v18.99.0 为「命名限定」）**：**本目录自 v19.0.0 起是一份合法 preset 目录。**
> 官方判定一个 preset 的依据是**目录内含组合文件 `agent.cordis.yml`**
> （`dsh-agent-presets/lib/types/discovery.js` 的 `COMPOSITION_FILE`；缺该文件的目录按官方诊断
> 「still occupies the id」——占了 id 却加载不了）。v18.61.0–18.99.0 期间那份组合文件叫
> `agent-tiered/cordis.yml`，**名字不落在契约上** ⇒ 当时的正确说法是「本目录不是 preset，只是一份配置片段」
> （反哺报告 N3 如实登记过）。v19.0.0 **改名到契约名**：`agent.cordis.yml` —— 契约面就此闭合。
> 注意两件事：① 本目录**不会**被自动扫描（DSH 只扫它配置的 preset 根），要**放进/软链到你的 preset 根**才生效（见 §6）；
> ② **预设不携带技能**——论衡技能由包入口 `ctx.skills.register()` 注册（runtime rank 250），刻意不做 `customSkillDirs`
> / `baseUrl` 携带（双注册会**静默**由 250 压过 300；理由见 `agent.cordis.yml` 头注释）。

> **v18.62.4 更正（全量审计-v18.62.3 P1-12）+ v19.0.0 路径更新**：本目录现有 **3 个条目**——`preset.yml`（给主人读的分档说明）
> + 本文件（安装指南）+ **`agent.cordis.yml`**（v18.61.0/H6 落地的组合配置；v19.0.0 由 `agent-tiered/cordis.yml` 改名而来，见 §6）。
> 本行此前写「只有两个文件…**不含任何可加载的 cordis 配置**」——**该断言已被 H6 推翻**，而那份配置
> **随包发布**（`package.json` 的 `files` 含 `examples`）→ 照旧文判断会以为分档只能靠环境变量、
> **永远发现不了这份 preset**。分层行为来自包根 `cordis.patch.yml` 的 **4 段 `- insert:` 行**
> （第 1 段 = 本包自注册行，第 2-4 段 = 三档分档工具），
> 且**三档工具行默认不装载**（v18.2.6 起：不设任何 `LUNHENG_*` 时它们不挂载）。
>
> 历史变更（v2.5.2-dsh.12）：早期版本的 `agent.cordis.yml`（≈16KB standard 全量副本）**已删除**——
> DSH 5.5.0+ 的 `cordis-plugin-include` 真正支持 `- insert:` 局部 patch 增量叠加，不再需要"凑出有效"副本
> （凑副本有版本漂移风险：standard 一更新，副本就过期了）。**故此文件现在只含三条 `- insert:` 行**（`- ` 增量，不是全量副本）。

## 1. 装论衡分档的 3 步（DSH 5.5.0+ 推荐路径）

```sh
# 1. 在 profile 里声明 bundle 依赖（DSH 读 dsh.bundle.patch 找到 cordis.patch.yml 加载）
dsh plugin --profile web add lunheng-article-pipeline@dsh   # 推荐：跟随最新 DSH 迭代版
# 锁定具体版本：dsh plugin --profile web add lunheng-article-pipeline@19.27.12

# 2. （可选，但要让三档工具真的挂上就必做）设三档 subagent 工具的 provider/model 环境变量
#    v18.2.6 起：不设任何变量 = 三档行**根本不装载**（不再是「装载但全继承」）
#    ——三档全继承时它们与内置 subagent 完全同义，无条件装载等于每会话白付 3 份工具 schema。
#    设了任一档的 PROVIDER/MODEL，或 LUNHENG_TIERING=on，才装载三行。
export LUNHENG_RETRIEVAL_PROVIDER=deepseek-official
export LUNHENG_RETRIEVAL_MODEL=deepseek-v4-flash
export LUNHENG_STRONG_PROVIDER=deepseek-official
export LUNHENG_STRONG_MODEL=deepseek-v4-pro
export LUNHENG_AUDIT_PROVIDER=deepseek-official
export LUNHENG_AUDIT_MODEL=deepseek-v4-pro

# 3. 重启 dsh 进程（模型在挂载期求值一次，改完必须重启）
dsh web  # 或 supervisor 自动拉起
```

## 2. 验证

```sh
# ① patch 行进入组合树：4 段 insert 应全部命中（第 1 段是自注册行，必须恰一行）
dsh --profile web --dump-config 2>&1 | grep -E "lunheng-article-pipeline|tool-subagent-(retrieval|strong|audit)"

# ② 技能是否真的挂上（技能由包入口注册，不表现为 patch 行）：
dsh headless --profile web "列出当前可见的技能"
# 预期：lunheng-article-pipeline
```

> ⚠️ **`--dump-config` 只打印声明行**：`disabled: !!js` 的行级门控**不会**在这里体现为「行消失」——所以「dump 里看得到三行」≠「三行已被装载」。要确认是否装载，看第 1 步的变量是否设了（或设 `LUNHENG_TIERING=on` 做一次显式开启对照）。

## 3. preset.yml 仅是分档说明文件

`preset.yml` 不是 DSH 加载的 cordis 配置——它**只是给主人读的分档说明**。
真要装分档行为，看 `../../cordis.patch.yml`（包根）里的 3 档 subagent 工具，**并显式开启**（不设任何 `LUNHENG_*` 时默认不挂；设任一档 `*_PROVIDER`/`*_MODEL` 或 `LUNHENG_TIERING=on` 才装载）。

```sh
# preset.yml 的内容（原文是一行 description，此处按行摘要）：
# name: 论衡分档
# description: 论衡专用预设：三档 subagent 工具按角色能力分模型（检索 T1-T3 便宜快 / 分析写作 T4-T5 推理强 /
#              批判审计 T6+T7+T9+G14 顶配防漏判），模型经 LUNHENG_*_PROVIDER + LUNHENG_*_MODEL 环境变量覆盖。
#              **v18.2.6 起默认不挂载**：设任一档 *_PROVIDER/*_MODEL 或 LUNHENG_TIERING=on 才装载。
# 真源：references/_shared/模型路由.md + scripts/model-routing.mjs + 包根 cordis.patch.yml 的「分档闸门」段
```

## 4. provider/model 分离与「未设即继承」

DSH 的 subagent 工具 `agentOptions` 里 `provider`（注册名）与 `model`（裸 id）是**两个字段**。本包每档用**一个**
`!!js` 表达式整块求值（v2.5.2-dsh.17 起，此前是 provider/model 各一个表达式）：

```yaml
agentOptions: !!js "(e => { const p = e.LUNHENG_RETRIEVAL_PROVIDER, m = e.LUNHENG_RETRIEVAL_MODEL; if (e.LUNHENG_TIERING === 'off' || (!p && !m)) return undefined; return Object.assign({}, p ? { provider: p } : {}, m ? { model: m } : {}); })(process.env)"
```

实际行为（与实现一致）：

| 环境变量组合 | 结果 |
|---|---|
| 都不设 | 三行**不装载**（v18.2.6 起）→ 派发走内置 `subagent`，继承会话模型（不报错，最省心，也是默认） |
| `LUNHENG_TIERING=off` | 强制**不装载**（优先级最高：即便其它 `LUNHENG_*` 已设也关掉） |
| `LUNHENG_TIERING=on` | **装载**三行但不指定模型 → 三档全继承（用于确认工具是否可见） |
| 只设 `MODEL` | 装载且**生效**（字段独立：`provider` 由宿主逐字段继承父级） |
| 只设 `PROVIDER` | 装载且生效（不写 `model` 时用该 provider 的默认模型） |
| 跨 provider | **必须同时给** `PROVIDER` + `MODEL` |

> 本包**不写死任何厂商默认模型**：宿主没有模型级回退，写错模型会让该档工具直接不可用。正确取值请跑
> `node skills/lunheng-article-pipeline/scripts/model-routing.mjs` 按本机实况生成。

「分档是否生效」**不会有报错提示**：派发前请按 `SKILL.md` 的约定确认三档工具存在且取值符合预期，否则回退 `subagent`。

## 5. 技能如何随包生效（v18.0.0 变更；v18.0.1 补自注册行）

**链路完整版**：patch 第一段 `- insert:` 插入**本包自注册行**（`- id: lunheng-article-pipeline` / `name: lunheng-article-pipeline`）→ loader 按包名解析到 `package.json#main` → **import `lib/index.js`** → 其 `apply` 读 `skills/lunheng-article-pipeline/SKILL.md`，经 `ctx.effect(() => ctx.skills.register({ … }))` 注册技能，`resourceBase` 指向该技能目录（因此 `references/**`、`scripts/**` 的相对引用在任意 cwd 下可解析；卸载时注册自动回滚）。

> ⚠️ **自注册行是承重的**：`package.json#main` **不会**因为「包被列进 profile 的 `bundles`」就自动执行——**patch 里的行才是会被 import 的东西**（官方 `publish.zh.md`：插件行按包名引用本包，Node 的模块解析才能找到已安装的代码）。v18.0.0 删掉旧挂载行时漏补这一行 → 组合树里 `name: lunheng-article-pipeline` 行数为 0 → **入口从不被加载、技能不注册**；18.0.1 修复，并由 `tests/bundle-contract.test.mjs` 机械防守（该测试跑已发布的 18.0.0 产物会红）。

- **删掉的东西**：早期版本第一段 `- insert:` 行挂 `@deepseek-ai/dsh-skill-filesystem` 提供者
  （`providerName` / `includeDefaultRoots: false` / `customSkillDirs` + 一处 `!!js` 路径求值）。该行连同那处加载期求值一并删除，
  且不再依赖内部包名 `@deepseek-ai/dsh-skill-filesystem`。
- **本包现在的 6 处 `!!js`**（v18.2.6 更正计数）：**3 处 `agentOptions`**（三段分档工具行，见第 4 节）+ **3 处 `disabled`**（同一批行的行级门控，读 `LUNHENG_TIERING` 与三档 `*_PROVIDER`/`*_MODEL`）。`disabled` **同样由宿主在加载期以完整 Node 权限求值**（`@deepseek-ai/cordis-plugin-loader/src/config/entry.ts:104-107` 的 `disabledOf()`），故**加载期执行面是 6 处而非旧版写的 3 处**。两者都只用 `process.env.*` 与全局 `Object.assign`。
- **入口回归**：`tests/entry.test.mjs` 用最小 ctx 真执行 `apply`，断言注册字段与 `resourceBase` 下的
  `SKILL.md` / `references/` / `scripts/` 齐备；`tests/bundle-contract.test.mjs` 断言「patch 恰有一行 `name == 包名`」。
  两条合起来才是完整防线：前者证明「入口能跑」，后者证明「入口会被加载」。

## 6. 可选：把三档工具行移进 agent preset（v18.1.0 新增配方，**未在真实部署验证**）

上面的 3 步是**默认路径**：三行 `- insert:` 在**包级** `cordis.patch.yml`，因此**该 profile 的每个会话**（装载时）都能看到三个分档工具。

若希望「**只有选定了该预设的会话**才有这三个工具」，官方机制是**把同样的行挂到 preset 组合里**（工具注册落在该 preset 的作用域层：`docs/subsystems/tools.md:484-504`、`docs/subsystems/skills.md:13`；`docs/architecture.md:131` 是入口判据）。完整配方（三步 + 每步验证 + 回滚 + 五条已知限制）见
[`../../skills/lunheng-article-pipeline/references/_shared/DSH-集成方案.md`](../../skills/lunheng-article-pipeline/references/_shared/DSH-集成方案.md) **§八**。

> **本目录里已有一份现成配方：`agent.cordis.yml`**（v18.61.0 反哺 v4 / H6 落地；v19.0.0 由 `agent-tiered/cordis.yml`
> 改名到官方契约名）。它把三档 subagent 工具行写进 preset 作用域，并开 `modelSelectionSettings: true`（该 preset 内可用
> `list_subagent_models` + per-call `provider`/`model`/`reasoning_effort`）。**字段形态与包根 `cordis.patch.yml` 逐条对应**，
> 改动须两处同批——这条**不再是口头纪律**：`tests/scripts/cordis-patch.test.mjs` 逐字比对两处的三条 `disabled`
> 与三条 `agentOptions` 表达式，改一处不改另一处**当场红**。
> 安装方式：把**整个 `examples/preset/` 目录**按你部署里的 preset 目录结构放好（先照抄一个已存在的预设目录，见下方要点①），
> 再在会话空白期切到该预设（要点②）。**回退**：切回原预设即恢复包级行为。

**三个要点先看**：① 官方知识库里**没有任何 preset 组合文件的完整示例**——**照抄你部署里已存在的预设目录**（文件名必须是 `agent.cordis.yml`，这是官方 `COMPOSITION_FILE` 契约；见本文件顶部的命名状态说明）；② **预设只在会话空白期可切**（跑了就别换）；③ 本包**默认不动** patch（「装了不坏」优先），换作用域需要你自己选预设；**预设不携带技能**（技能始终由包入口注册，理由见 `agent.cordis.yml` 头注释）。

---

## 7. 升级/降级/卸载

```sh
dsh plugin --profile web update lunheng-article-pipeline@dsh
# 卸载后 4 段 - insert 行（自注册行 + 三档工具行）与入口注册的技能一并消失；
# 入口安装的可选能力（原生只读工具 / 机制写保护 / /lunheng-status）随 ctx.effect 的 disposer 回收，不留残余
dsh plugin --profile web remove lunheng-article-pipeline
```

> **质量—成本实测（QLT-5）**：分档此前只有**成本定位**、无质量差异实测。观测性读数与**受控 A/B 设计**见 [`../../skills/lunheng-article-pipeline/references/_shared/模型路由.md`](../../skills/lunheng-article-pipeline/references/_shared/模型路由.md) 的质量—成本实测节；复算命令 = `node skills/lunheng-article-pipeline/scripts/token-budget.mjs --roles --by-model`。
