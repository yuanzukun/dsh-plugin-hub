> 版本：v19.1.8（DSH bundle 插件）

# 论衡（lunheng-article-pipeline）— 多 Agent 深度长文流水线

> **DSH 原生插件（v19.1.8）**：本仓库为 DSH bundle 技能包（`package.json` 的 `main` → `lib/index.js` 注册本技能 + `dsh.bundle.patch` → `cordis.patch.yml` 叠加三档 subagent 工具）；结构性差异见 `SKILL.md` 的「🔧 DSH 环境说明」章节。

把一篇深度文章 / 论文的生产拆成 **9 个独立角色 T1-T9 + 6 个阶段**（v2.5.2-dsh.8 语义定案：T1-T9 互不可替代；Phase 1 为 T1 文献 ∥ T2 数据 ∥ T3 案例 三检索员三方真并行互不干涉，T3 任何量级必 spawn 含 0 条空卡协议；T6 批判伙伴 + T7 审计 + **T8 终检独立角色由主控 T0 亲执行** + T9 同行评审T9 启用按 `_shared/文类档案.md`，v2.3.0 角色编号重构 + v2.4.0 加 T9），用 DSH 的 `subagent` 子代理编排，产出有**证据底座、反方论证、独立审计、人工核验节点**的交付物。

> 适用：公众号深度文章、研究报告、学术论文、商业评论、行业分析。经验证：一篇 7650 字/8 节/2 图/52 文献/60 数据点的深度文，全流程约 2 小时完成。

---

## 何时使用 + 🌐 语言与定位声明（v2.1.1 新增）

**何时使用**：
- 主人要一篇「有深度、要站得住脚」的长文（>2000 字），且愿意等数小时（**不给小时区间**，见 `SKILL.md` §边界）
- 主题涉及事实/数据/多方观点，需要证据底座而非纯观点输出
- 需要「人在环」把关：大纲确认后再写，终稿人工审

**🌐 语言与定位（v2.1.1 新增）**：
> 本技能面向**中文研究场景**——人文社科论文/公众号深度文/中文行业评论。角色 prompt/交付物/文件名/操作流程均默认中文。

---

## 🚫 不适用场景（边界明示 — v2.1.5 新增）

**论衡是「论文/深度文章」写作流水线**，擅长**主动检索已发布证据 + 整合主人投喂的证据**。下列场景**不能**主动完成，需主人投喂素材后再用：

- ❌ **一手原始数据采集** —— 实验 / 调查 / 访谈 / 田野调查 → 主人调研后投喂
- ❌ **统计分析**（SPSS / R / Python）—— 论衡可引用结果，**不执行计算**
- ❌ **图表原始数据采集** —— 论衡做**数据可视化**，爬虫 / OCR / 语音转文字需主人用专门工具
- ❌ **原创图片 / 视频生成** —— DSH 无内置文生图（无内置文生图能力）：封面/插图降级为 SVG 矢量风或主人投喂，或另配图像生成 MCP（如 MiniMax `image-01`）
- ❌ **代码执行** —— 本技能默认不主动跑代码；DSH 下可经主人同意后用 `pwsh`/`bash` 执行

**判断口诀**：问「这个证据是**已发布**的数据 / 文献 / 案例吗」—— 是，论衡主动采集；不是，主人投喂后再用。详见 `references/pipeline-readme.md` 的「🚫 不适用场景」段。

---

## ⚠️ 数据流与第三方服务（v2.1.2 新增，v2.3.7-dsh.1 按 DSH 修订）

使用本技能时，以下内容会**发送到第三方服务商**：

| 操作 | 发送内容 | 第三方服务商 | 适用阶段 |
|------|---------|------------|---------|
| `web_search` | 检索关键词 | DSH 的 web_search 提供方（按 DSH 配置，路由可能含 Google/Bing） | T1/T2/T3 检索 |
| `web_fetch`（可选） | 目标 URL | DSH 配置的网页读取引擎 | T1/T2/T3 检索 |
| 封面/插图（DSH 无文生图） | —— | 降级 SVG 矢量风（本地，不外发）或主人投喂；如需文生图另配图像 MCP | Phase 4.5 |
| 大模型推理 | 文献/数据/案例/草稿/大纲全文 | 当前模型 provider（按 DSH `settings.yaml` / LLM 适配器） | T4-T7 + 主控 |

**主控必须在 Phase 0 主人确认时同步告知上述外发项（4 选 1 明示同意）**。涉及未公开主题/客户内部信息/商业机密的研究：
- 改用匿名化措辞（脱敏）
- 封面一律用 SVG 矢量风（本地零外发，DSH 默认即此）
- 主控推理改用本地模型（按 DSH 配置，如本地 Ollama 端点，零成本）

**主人拒绝任一外发项** → 主控调整方案并重做 Phase 0 确认。详见 SKILL.md 「⚠️ 外部服务与数据流声明」章节。

---

## 核心特点

### 三不原则（质量底线）

| 原则 | 机制 | 防什么 |
|------|------|--------|
| **不编造** | 引用带 URL/DOI + 数据带来源年份 + 审计分级抽验 | 幻觉 / 假引用 / 假数据 |
| **不堆砌** | 强相关性铁律（每条材料必答「它支撑哪个论点」+ 反向淘汰自查）| 材料凑数 / 观点堆砌 |
| **不重复** | 先行者检索 + 差异点声明 + 原创性审计 | 重复 / 改写已公开文章 |

### 九角色流水线（v2.3.0 编号重构；v2.5.2-dsh.8 定案：T1-T9 九角色互不可替代）

```
主控 Coordinator（定题、拆解、派发、阶段闸门、终检、状态机）
  │
  ├─ T1 文献检索员 ── 文献卡 [Lxx]（A/B/C 可信度分级）+ 先行者清单
  ├─ T2 数据检索员 ── 数据卡 [Dxx]（🟢🟡🔴 时效 + 信任级别 + 冲突口径并列）
  ├─ T3 案例检索员 ── 案例卡 [Cxx]（事件结构证据，三角验证第三块，**任何量级必 spawn** 含 0 条空卡）
  ├─ T4 分析员     ── 分析大纲（论证主线 + 论点-论据映射 + 反方论证 + 三角验证）
  ├─ T5 写手       ── 初稿（内联/编号引用，AI 去味 10 项）
  ├─ T6 批判伙伴   ── 批判报告（C1-C7 反方攻击，轻量档可跳）
  ├─ T7 审计员     ── 审计报告（G0-G14 全项检查，只审不改）
  ├─ T9 审稿人     ── 审稿报告（6 维度评分 + 期刊匹配 Top 3；启用按文类档案）
  └─ T8 终检（独立角色，主控 T0 亲执行）── M 门（M-Form 11 / M-Exist 11 / M-Integrity 2 / M-Fact 1）+ 定稿 + 证据包
```

### 三角验证（证据底座）

任何论点必须能映射到三类证据，涉企业行为 / 事件必须有案例卡：

| 卡片 | 给的是 | 适用论点 |
|------|--------|---------|
| 文献卡 [Lxx] | 理论 / 学术依据 | 「这事有没有人研究过」 |
| 数据卡 [Dxx] | 量级 / 趋势 | 「这事多大、占比多少」 |
| 案例卡 [Cxx] | 事件结构（who/when/what/各方说法）| 「这事具体怎么发生的」 |

### 人在环四节点

- **Phase 0 定题** —— 人工确认主题
- **Phase 2.5 大纲** —— 人工确认论证方向（改方向成本最低）
- **Phase 3.5 洞察补充** —— 人工补充一线经验/具体场景
- **Phase 5 终稿** —— 人工终审

> v2.3.3 纠偏：Phase 3.6（T6 批判）是流水线内部动作，非人在环节点。

### 独立审计（G0-G14 + M 门）

审计员与写手分离，全项检查：G0 覆盖度 · G0.5 视角一致性 · G1 引用核验 · G2 数据溯源 · G2.5 案例核验 · G3 逻辑 · G4 格式 · G4-2 文末四节 · G5 规范 · G6 论据自标 · G7 原创性 · G8 成品度 · G9 时序 · G10 一致性 · G11 时效 · G12 信任级别 · G13 AI 披露 · **G14 中文 AI 痕迹闸**（v2.4.0 加：8 类检测维度，0-2 类 Pass / 3-4 类 Warning / 5+ 类 Fail；v18.2.8 起三层防御——T5 v1 自检 → 修订轮收尾自查 → **终闸（v18.75.0 起 Phase 4.6，串行，不再与 T9 并行）** spawn）。终检前主控跑 **M 门**（M-Form 11 / M-Exist 11 / M-Integrity 2 / M-Fact 1，LLM 兜底执行，产出 `final/M-Gate-Report.json`，exit 0 才交付）。

---

## 流水线全景

```
Phase 0 定题        确认主题/篇幅/引用格式 → 任务简报 + 状态机 + 外部服务 4 选 1 同意
Phase 1 并行检索    T1 文献 ∥ T2 数据 ∥ T3 案例（任何量级必 spawn，含 0 条空卡），先行者检索
[🔒 T2.5 完整性门]   数据条目 ≥ 简报数据需求 + 信任级别完整
Phase 2 分析        T4 分析员 → 分析大纲（三角验证 + 原创性声明）
Phase 2.5 大纲确认   主人过目（人在环）
Phase 3 写作        T5 写手 → 初稿（AI 去味 10 项 + 反方论证）
Phase 3.5 洞察补充   主人补充一线经验（人在环）→ 写手 v2 融入
Phase 3.6 批判      T6 批判伙伴 → 批判报告 C1-C7（轻量档可跳）
Phase 4 审计        T7 审计员 → 审计报告（G0-G14）
Phase 4 审计打回    写手交修订说明 + 修订稿（A 轨审计打回 ≤2 轮，独立写手执行；B 轨主控触发轮**至多 +1 深化轮**，G14 终闸另走独立的 **G 环**，三环制见 QUICKSTART）
Phase 4.6 G14终闸  G14 中文 AI 痕迹闸终闸（**唯一一次 spawn**；**v18.75.0 起串行，不再与 T9 并行**）→ **Pass → 冻结正文；Warning/Fail → G 环修订后重跑**
Phase 4.7 审稿      T9 同行评审（**v18.75.0 起按文类档案启用**：`academic-cn`/`-hum`/`-case` 必选、`lit-review` 可选、其余默认不选；v18.77.0 P-3 由通配 `academic-*` 收口为特指）→ 审稿报告 + 期刊匹配 Top 3
[🔒 T7.5 完整性门]   审计报告最新版 + P0/P1 清单 + M 门全 exit 0 + 隔离
Phase 4.5 配图      仅当 Phase 2.5 拍板有图位：主控按 `图表-SVG-template.md` 填图落盘 `final/图件/`（**在 G14 终闸之前完成**，使终闸审的是含图的版本）
Phase 5 终检        T8 终检（独立角色，主控 T0 亲执行 M 门）→ 终稿 + 证据包 + 交付说明（含 AI 使用披露）
```

---

## 目录结构

```
lunheng-article-pipeline/                    # npm 包（DSH bundle）
├── package.json                             # 声明 dsh.bundle.patch
├── cordis.patch.yml                         # bundle 补丁（注册技能到技能根）
├── LICENSE
├── README.md                                # 本文件（包说明）
└── skills/lunheng-article-pipeline/         # 技能本体
    ├── SKILL.md                             # 技能入口（含 DSH 环境说明）
    ├── AGENTS.md                            # 操作手册
    ├── QUICKSTART.md                        # 5 分钟快速开始
    └── references/
        ├── agents/                          # **9 个独立角色卡 T1-T9**（01-09；T8 终检由主控 T0 亲执行；00 主控 = T0 + T8 双重身份）
        │   ├── 00-主控-coordinator.md
        │   ├── 01-文献检索-literature-scout.md
        │   ├── 02-数据检索-data-scout.md
        │   ├── 03-案例检索-case-scout.md
        │   ├── 04-分析-analyst.md
        │   ├── 05-写作-writer.md
        │   ├── 06-批判-critical-companion.md
        │   ├── 07-审计-auditor.md
        │   ├── 08-终检-finalizer.md          # T8 终检（独立角色，主控 T0 亲执行，v2.5.2-dsh.7 新增独立卡）
        │   └── 09-审稿-peer-reviewer.md      # T9 同行评审（启用按文类档案）
        ├── templates/                       # 6 对模板 × (full + lite) + 单文件模板（清单以 ls 为准）
        ├── _shared/                         # M 门 / F 模式 / 期刊匹配等共享机制
        │   ├── M-Gate-Algorithm.md          # M 门算法（M-Form 11 / M-Exist 11 / M-Integrity 2 / M-Fact 1）
        │   ├── M-Gate-Algorithm-appendix.md # M 门附录
        │   ├── audit-checklist-quickref.md  # G0-G14 速查
        │   ├── failure-modes.md             # F1-F9 失败模式
        │   ├── 期刊数据库.md + 期刊匹配算法.md # 期刊匹配助手
        │   ├── format-export.md + 中文数据源集成.md + degraded-scenarios.md + 字数判定表.md
        │   └── （历史归档已移出仓库，演进记录见 git log）
        ├── pipeline-readme.md               # 完整运行手册（含 9 角色派发话术 + M 门 + F 模式）
        ├── glossary.md                      # 核心概念词汇表（单一真源）
        ├── errors.md                        # 错误信息友好化（12 类）
        ├── deliverables.md                 # 交付边界 + F 失败模式 + 修订回环
        ├── operations.md                   # 配图 + 写作禁做清单 + 成本模型
        ├── case-studies.md                 # 实战案例库
        ├── memory/                          # 教训库（lessons.md，论衡特定教训，每单实战沉淀）
```

---

## 怎么用

### 方式一：DSH 插件（bundle）安装

```sh
# 1) 装进 profile（新版 dsh 会自动把声明了 dsh.bundle 的依赖加进 dsh.profile.bundles）
dsh plugin --profile web add lunheng-article-pipeline

# 2) 仅当纯 npm/pnpm 安装或旧版 dsh 时，才需手工加 bundle 清单 dsh.profile.bundles
#    "dsh": { "profile": { "bundles": ["@deepseek-ai/dsh-base", "@deepseek-ai/dsh-web-app", "lunheng-article-pipeline"] } }

# 3) 重启 dsh web
```

技能由包入口 `lib/index.js` 注册（读随包 `SKILL.md`，`resourceBase` 指向本技能目录），三档 subagent 工具由 `cordis.patch.yml` 叠加。装好后，新会话的 `skill` 工具目录会出现 `lunheng-article-pipeline`；主控 Agent 按 `references/pipeline-readme.md` 里的派发话术 spawn 各角色。

### 方式二：直接使用技能目录（不发布）

把本仓库的 `skills/lunheng-article-pipeline/` 目录复制到任一 DSH 技能根（`$DSH_HOME/skills/` 或项目 `.dsh/skills/`）即可，无需安装、热加载生效。

### 模型更换 / 按角色分模型（v2.3.7-dsh.6 通用化）

DSH 的模型路由由 `settings.yaml` 配置决定，`subagent` 默认继承会话模型（**单模型配置零配置可用**）。配了多模型想**按角色能力分档**，**装本包即在 profile 里插入三档工具**（`cordis.patch.yml` 的 3 段 `- insert:`；`examples/preset/` 只是说明文档，无需复制任何目录），主控会改用三档工具按角色分派：

| 工具 | 角色 | 能力定位 | 默认 provider/model（可覆盖） |
|---|---|---|---|
| `subagent_retrieval` | T1 文献 / T2 数据 / T3 案例 | 便宜快 | 继承父会话（设 `LUNHENG_RETRIEVAL_*` 才分档） |
| `subagent_strong` | T4 分析 / T5 写作 | 推理强 | 继承父会话（设 `LUNHENG_STRONG_*` 才分档） |
| `subagent_audit` | T6 批判 / T7 审计 / T9 审稿 / G14 检测 | 顶配防漏判 | 继承父会话（设 `LUNHENG_AUDIT_*` 才分档） |

覆盖环境变量：`LUNHENG_{RETRIEVAL,STRONG,AUDIT}_PROVIDER`（provider 名）+ `LUNHENG_{RETRIEVAL,STRONG,AUDIT}_MODEL`（裸模型 id）——**字段独立**（只给 model 也生效；跨 provider 必须同时指定），`LUNHENG_TIERING=off` 一键让三档全部继承。模型在挂载期求值一次，改环境变量后须重启 dsh；未挂载对应工具时自动回退 `subagent`（继承会话模型，任何模型配置都能跑）。

---

## 实战验证

| 文章 | 规模 | 关键产出 |
|------|------|---------|
| 品牌一致性深度文（2026-08） | ~7900 字，15 文献 + 54 数据点 | 证据包三件套，审计复核 8 项全修复 |
| 原创性悖论深度文（2026-08） | ~9500 字，12 文献 + 34 数据 + 6 案例 | 4 轮修订，A- 评级，公众号发布 |
| 教师场域孤岛论文（2026-08） | ~12000 字，18 文献 + 47 数据 + 9 案例 | T7 审计 R2 通过，G10 一致性审计首发实战 |
| 生成式 AI 学生写作短评（2026-08） | ~2000 字，12 文献 + 26 数据 | v2.2.8 实跑：三线并行 + M 门 exit 0 + 3 条 P1 修订关闭 |
| 甲醛白菜事件深度文（2026-08） | ~4200 字，12 文献 + 29 数据 + 4 案例 | v2.5.2-dsh.0 同步前实测：M 门 exit 0（当时为旧口径；现行真源=机械 24 + 人工 1 = 25） + 反哺 6 规则 merge + 教训 #142-#144 |

---

## 许可

MIT License
