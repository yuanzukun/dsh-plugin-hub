# Lunheng (lunheng-article-pipeline) — pipeline multiagente para textos largos

> 版本：v19.27.16（DSH bundle：package.json + cordis.patch.yml + lib/index.js）

> 🌐 [English](README.md) ｜ [中文](README-zh.md) ｜ **Español**（este archivo）｜ [Português](README-pt.md) ｜ [हिन्दी](README-hi.md)

> Un bundle de DeepSeek Harness (DSH) que registra **dos skills de agente bajo demanda**: `lunheng-article-pipeline` (la pipeline principal de 9 roles) y `lunheng-commands` (un envoltorio fino que expone 13 comandos de barra `/lunheng-*`: draft / resume / cite / audit / journal / ppt / history / rollback / status / stats / gate / abort / help; **sin rol nuevo y sin ítem nuevo de la puerta M**; véase `skills/lunheng-commands/SKILL.md`). La skill principal convierte la producción de textos largos —artículos académicos, análisis sectorial, comentario económico y artículos extensos— en una **pipeline de 9 roles con intervención humana**.

## What this is

Lunheng es una pipeline de escritura, no un generador de texto. Divide la producción de un texto largo en 9 roles independientes (T1–T9) a lo largo de 6 fases, orquestados con llamadas `subagent` de DSH, y entrega un resultado con base probatoria, revisión de contraargumentos, auditoría independiente y puntos de control humanos.

Los nueve roles son independientes y no sustituibles: T1 búsqueda bibliográfica, T2 búsqueda de datos, T3 búsqueda de casos, T4 análisis, T5 redacción, T6 compañero crítico, T7 auditoría, T8 verificación final (la ejecuta el propio coordinador), T9 revisión por pares.

## When to use it

- Necesita un texto extenso (más de 2000 caracteres) que resista escrutinio y puede esperar varias horas (sin rango horario; véase `skills/lunheng-article-pipeline/SKILL.md` §边界).
- El tema implica hechos, cifras o múltiples puntos de vista, por lo que requiere una base probatoria y no solo opinión.
- Desea puntos de control humanos: confirmar el esquema antes de redactar y revisar el borrador final.

## When not to use it

Lunheng recopila **evidencia publicada** e integra la evidencia que usted aporte. No puede producir lo siguiente por sí sola; aporte el material primero o use otra herramienta:

- **Recolección de datos de primera mano** — experimentos, encuestas, entrevistas, trabajo de campo.
- **Análisis estadístico** — puede citar resultados, pero no ejecuta SPSS/R/Python.
- **Recolección de datos brutos para gráficos** — renderiza visualizaciones; el scraping, OCR y la transcripción necesitan herramientas dedicadas.
- **Imágenes o vídeo originales** — DSH no incluye generación de imágenes; las portadas usan SVG local o archivos aportados.
- **Ejecución de código** — la pipeline solo ejecuta scripts autorizados; cualquier otra cosa requiere su aprobación explícita.

Regla práctica: pregunte si la evidencia ya está **publicada**. Si lo está, Lunheng la recopila. Si no, apórtela primero.

## What you get

| Elemento | Contenido |
|---|---|
| Fichas bibliográficas `[Lxx]` | Fuentes publicadas con grado de confianza A/B/C y lista de precursores |
| Fichas de datos `[Dxx]` | Cifras con fuente, año, vigencia, nivel de confianza y cifras en conflicto lado a lado |
| Fichas de casos `[Cxx]` | Estructura del evento (quién/cuándo/qué/el relato de cada parte), o marcador explícito `[C-空]` |
| Esquema de análisis | Hilo argumental, mapeo afirmación-evidencia, plan de contraargumentos, evidencia portante |
| Borradores | Versiones sucesivas con limpieza de huellas de IA, cada una de un redactor independiente |
| Informes | Informe crítico (C1–C7), auditoría (G0–G14), revisión por pares (6 dimensiones + revistas) |
| Entregables finales | `final/定稿.md`, figuras, paquete probatorio, notas de entrega, informe de la puerta M |
| Integración con DSH (instalación como bundle) | Cuatro herramientas **de solo lectura**: `lunheng_m_gate` (precomprobación mecánica de la puerta M), `lunheng_char_count` (recuento de caracteres chinos), `lunheng_handoff_check` (verificación de forma / versión / pares / agents-log del informe de traspaso) y `lunheng_ethics_sanitize` (desidentificación ética: enmascara DNI / teléfonos / correos / tarjetas bancarias / nombres de personas / topónimos en transcripciones de entrevistas y notas de campo; devuelve el texto enmascarado para que quien lo invoca decida dónde escribirlo; v18.60.1); si su sesión no las expone, invoque los mismos scripts con `pwsh` como antes (misma fuente de verdad). Comandos humanos `/lunheng-status` (lee `run/<proyecto>/status.md`) y `/lunheng-stats` (panel de telemetría entre proyectos; lanza `scripts/lunheng-stats.mjs` con `--json` como único argumento en lista blanca); ninguno genera mensajes de modelo. **Protección de escritura de los archivos de mecanismo**: un guard global rechaza las llamadas de herramientas tipo `write`/`edit` dirigidas al paquete de la skill, de modo que una sesión no puede reescribir en silencio las reglas de la propia pipeline. Límite declarado sin adornos: el guard solo ve **llamadas de herramientas**; `pwsh` y cualquier subproceso **no pasan por esta puerta**; la excepción del propietario es `LUNHENG_ALLOW_MECH_EDIT=1` (o `config: { allowMechanismEdit: true }`). El **Config** del plugin (interruptor de despliegue, en la fila de este plugin de su perfil) cubre `quiet`, `allowMechanismEdit`, `scriptTimeoutMs`, `scriptMaxOutputBytes`, `handoffLevel`, `hookRewriteContent`, `hookMaxBlockChars` y `hookMaxTotalChars`, `ethicsHook` y `panel` (v18.90.0; **activado por defecto desde v18.93.0** — panel de ejecución, superficie HTTP de **solo lectura** (prefijo propio); para desactivarlo use `LUNHENG_PANEL=0` o `panel: false`, véase `SECURITY.md`) (v18.80.0: interruptor maestro del listener H2 de desidentificación ética, **activado** por defecto; desactívelo en flujos puramente de código/documentación, donde las coincidencias de nombres de persona son medibles como todas de baja confianza y solo añaden ruido) — las dos primeras y `panel` son equivalentes a las variables `LUNHENG_QUIET` / `LUNHENG_ALLOW_MECH_EDIT` / `LUNHENG_PANEL`, mientras que `scriptTimeoutMs` / `scriptMaxOutputBytes` / `handoffLevel` / `hookRewriteContent` / `hookMaxBlockChars` / `hookMaxTotalChars` / `ethicsHook` son **solo Config (sin variable de entorno)**; las diez son revisables con el perfil; una **config inválida falla ruidosamente en la carga** en lugar de volver en silencio a los valores por defecto. |

## Pipeline overview

```text
Fase 0  Tema          Confirmar tema, extensión, formato de citas; consentimiento de servicios externos
Fase 1  Búsqueda      T1 bibliografía ∥ T2 datos ∥ T3 casos (paralelo real e independiente)
Fase 1.5 Relleno   T1 nueva búsqueda dirigida (opcional; reverificación de [Dxx] + argumentos de vacío, etiquetas Permanent Gap)
Puerta T2.5           Entradas de datos ≥ requisito del brief; niveles de confianza completos
Fase 2  Análisis      T4 analista → esquema de análisis
Fase 2.5 Esquema      Revisión humana (en el circuito)
Fase 3  Redacción     T5 redactor → borrador v1
Fase 3.5 Perspectiva  El humano aporta contexto de primera mano (en el circuito) → borrador v2
Fase 3.6 Crítica      T6 compañero crítico → informe C1–C7
Fase 4  Auditoría     T7 auditor → informe G0–G14 y lista de revisión
Fase 4.2 Revisión     Redactor + notas de revisión (≤2 rondas, redactor independiente)
Fase 4.5 Figuras       Generación de figuras (SVG) antes de la puerta
Fase 4.6 Puerta G14    Puerta G14 de huellas de IA (en serie; congela el texto)
Fase 4.7 Revisión      T9 revisión por pares
Puerta T7.5           Auditoría más reciente + lista P0/P1 + puerta M exit 0 + aislamiento
Fase 5  Verificación  T8 (lo ejecuta el coordinador) → texto final, paquete probatorio, notas de entrega
```

**Base probatoria triangular** (`[L]` + `[D]` + `[C]`) — toda afirmación debe mapear a bibliografía, datos y, para afirmaciones sobre eventos, casos. **Auditoría independiente** — quien audita nunca edita. **Cuatro puntos humanos** — fases 0, 2.5, 3.5 y 5.

## Repository layout

```text
lunheng-article-pipeline/                 # el paquete es el repositorio
├── package.json              # declara main (lib/index.js) + dsh.bundle.patch
├── cordis.patch.yml          # capa bundle: fila de autorregistro + 3 herramientas subagent por nivel (solo se montan si define LUNHENG_*)
├── lib/index.js              # entrada del plugin: skill + herramientas de solo lectura + guard de escritura + /lunheng-status
├── skills/lunheng-article-pipeline/       # el cuerpo de la skill (un directorio)
│   ├── SKILL.md              # entrada de la skill (roles, puertas, límites de ejecución)
│   ├── AGENTS.md             # manual del operador
│   ├── QUICKSTART.md         # inicio en cinco minutos
│   ├── README.md             # readme de la skill (chino)
│   ├── references/           # 9 fichas de rol, plantillas, algoritmos de puerta, base de revistas
│   └── scripts/              # scripts .mjs de verificación sin dependencias (recuento: véase la línea de lista blanca de la skill)
├── skills/lunheng-commands/   # skill acompañante: 13 comandos de barra /lunheng-* (draft / resume / cite / audit / journal / ppt / history / rollback / status / stats / gate / abort / help)
│   ├── SKILL.md              # entrada de comandos (lista de comandos, modelo de despacho)
│   ├── README.md             # readme a nivel de comandos
│   ├── scripts/              # manejadores de comandos (p. ej. lunheng-stats.mjs)
│   └── tests/                # pruebas a nivel de comando (no se ejecutan solas; ámbito manual de npm test)
├── scripts/                  # puertas del repositorio: superficie de empaquetado + higiene + humo del paquete
├── tests/                    # suites node --test (scripts + humo de la entrada)
├── docs/                     # instalación, uso, arquitectura, faq, resolución de problemas
├── examples/preset/          # notas de niveles de modelo y guía de instalación
├── README.md                 # fuente en inglés
├── README-zh.md README-es.md README-pt.md README-hi.md
├── SECURITY.md CHANGELOG.md CONTRIBUTING.md LICENSE
```

La entrada del plugin registra `skills/lunheng-article-pipeline/SKILL.md` como skill con `resourceBase` apuntando a ese directorio, de modo que `references/**` y `scripts/**` se resuelven relativos a él desde cualquier directorio de trabajo.

La capa patch hace dos cosas: **inserta una fila para este paquete** (`- id: lunheng-article-pipeline` / `name: lunheng-article-pipeline`) — esa fila es la que hace que el loader importe `lib/index.js`, que es lo que registra la skill — e inserta las tres herramientas subagent por nivel, que **no se montan por defecto** (defina cualquier `LUNHENG_{RETRIEVAL,STRONG,AUDIT}_{PROVIDER,MODEL}` o `LUNHENG_TIERING=on` para montarlas; `off` para forzar que no se monten). **Esa fila es portante**: sin ella la entrada nunca se importa y la skill no aparece (defecto de v18.0.0, corregido en 18.0.1; vigilado por `tests/bundle-contract.test.mjs`).

### Documentation

| Archivo | Contenido |
|---|---|
| `docs/installation.md` | Instalación y verificación |
| `docs/usage.md` | Flujo de uso (fases y estructura de artefactos) |
| `docs/architecture.md` | Arquitectura (9 roles, evidencia triangular, auditoría G0–G14, M-gate) |
| `docs/introduction.md` | Introducción del plugin |
| `docs/faq.md` | Preguntas frecuentes |
| `docs/troubleshooting.md` | Resolución de problemas de instalación/verificación (síntoma → causa → solución) |
| `SECURITY.md` | Política de seguridad y límite de confianza |
| `CHANGELOG.md` | Historial de versiones |
| `CONTRIBUTING.md` | Guía de mantenimiento y publicación |

### Publishing (maintainers)

Las versiones se publican **solo por tag**; `npm publish` local está prohibido (evita las puertas de CI y la procedencia OIDC, y una versión npm nunca se puede sobrescribir).

```sh
git tag v19.27.16 && git push origin v19.27.16   # un tag por push (GitHub: >3 tags en un push no dispara workflow)
# publish.yml ejecuta: puerta 1 consistencia → puerta 2 empaquetado → puerta 3 higiene → puerta 4 humo del paquete → tests
#   → tag/versión iguales → guarda de idempotencia → OIDC publish --provenance --tag dsh → auditoría posterior
```

## Install

**Como bundle** (recomendado; la entrada registra la skill + las capacidades del grupo C, y la capa patch *puede* montar las herramientas por nivel — **desactivadas por defecto**, véase [Model routing](#model-routing)):

```sh
dsh plugin --profile web add lunheng-article-pipeline
dsh --profile web --dump-config   # muestra una capa "# == lunheng-article-pipeline"
```

Un `dsh` moderno añade la dependencia a `dsh.profile.bundles` en cuanto ve la declaración `dsh.bundle`: instale y reinicie `dsh web`. Solo las instalaciones npm/pnpm puras o las versiones antiguas necesitan la entrada manual.

**Como directorio de skill simple** (sin instalación; el host vigila la raíz de skills y la refresca al cambiar — el `SKILL.md` del modo uno es una instantánea leída en el `apply` del entry, así que editar el contenido requiere recargar el plugin o abrir una sesión nueva):

```sh
# Copie el DIRECTORIO DE LA SKILL (no la raíz del repositorio) en cualquier raíz de skills:
#   $DSH_HOME/skills/lunheng-article-pipeline        (usuario, rank 400)
#   <proyecto>/.dsh/skills/lunheng-article-pipeline  (proyecto, rank 100)
```

Un directorio simple no declara `dsh.bundle`, así que `dsh plugin add` solo lo instala como dependencia y no activa ninguna capa. Copiar el directorio de la skill es la vía soportada.

### Requirements

| Elemento | Requisito |
|---|---|
| DSH (versión de producto) | `dsh` CLI disponible; las filas `- insert:` del bundle necesitan **DSH 5.5.0+ versión de producto** — nota: `dsh` se distribuye en dos líneas de versión paralelas, una **línea de producto** (semver, p.ej. `5.5.0`) y la **línea npm** `@deepseek-ai/dsh` (tags prerelease, p.ej. `0.1.7-rc.2`); **no son intercambiables** |
| `@deepseek-ai/dsh` (versión npm) | `peerDependencies` declara `>=0.1.2-rc.1 <0.3.0`; **CI prueba `0.1.7-rc.2` y `0.2.1-rc.2`** (matriz `install-smoke` en `ci.yml`); otras versiones dentro del rango (p. ej. `0.2.0-rc.x`, `0.1.3`–`0.1.6`) están **declaradas, no verificadas** |
| Node | `^22.19.0 \|\| >=24.0.0` (mínimo de DSH; ver `engines` en `package.json`) |
| pnpm | Necesario para instalar/desinstalar (`dsh plugin` delega en pnpm) |
| Plataforma | Windows / macOS / Linux (scripts sin dependencias) |

### Uninstall

```sh
dsh plugin --profile <profile> remove lunheng-article-pipeline
```

Al desinstalar desaparecen las 4 filas `- insert:` (la de autorregistro y las tres de nivel) y la skill registrada por la entrada, sin residuos. Si además copió el directorio de la skill en una raíz de skills, bórrelo aparte.

## Model routing

DSH enruta modelos mediante `settings.yaml`; `subagent` hereda el modelo de la sesión, de modo que una configuración de un solo modelo funciona sin ajustes. Para escalonar por rol, el bundle puede montar tres herramientas por nivel, **desactivadas por defecto** (mientras todos los niveles heredan son idénticas al `subagent` integrado, así que montarlas sin condición costaría tres esquemas de herramienta por sesión a cambio de nada):

| Herramienta | Roles | Capacidad |
|---|---|---|
| `subagent_retrieval` | T1 bibliografía / T2 datos / T3 casos | Rápido y económico |
| `subagent_strong` | T4 análisis / T5 redacción | Razonamiento fuerte |
| `subagent_audit` | T6 crítica / T7 auditoría / T9 revisión / detector G14 | Máximo nivel, sin degradar por coste |

Sobrescriba con `LUNHENG_{RETRIEVAL,STRONG,AUDIT}_PROVIDER` y `LUNHENG_{RETRIEVAL,STRONG,AUDIT}_MODEL`: **definir cualquiera de ellas también monta las tres filas** (una configuración escalonada ya existente sigue funcionando igual). Proveedor y modelo son campos independientes (cruzar proveedores exige ambos); `LUNHENG_TIERING=on` monta las filas sin fijar ningún modelo (útil para comprobar que son visibles) y `LUNHENG_TIERING=off` devuelve los tres niveles a la herencia y las desmonta. Cuando una herramienta de nivel no está montada, el envío recae en el `subagent` integrado. Véase `examples/preset/README.md` y `docs/installation.md`.

## Data and external services

La pipeline envía lo siguiente a terceros:

| Operación | Contenido enviado | Destinatario |
|---|---|---|
| `web_search` / `web_fetch` | Palabras clave y URL de destino | Los proveedores de búsqueda y lectura configurados en DSH |
| Inferencia del modelo | Fichas bibliográficas, de datos y de casos; esquemas; borradores | El proveedor de modelo activo |
| Generación de imágenes (opcional, desactivada) | Tema y prompt de marca | Un MCP de imágenes, solo si usted lo habilita |

El coordinador debe divulgar estos envíos y obtener consentimiento explícito en la fase 0. Para temas confidenciales: anonimice el texto, mantenga las portadas como SVG local (cero llamadas externas) y elija un endpoint de modelo local. Rechazar cualquier elemento devuelve la ejecución a la fase 0.

## Verification status

| Artículo | Escala | Resultado |
|---|---|---|
| Consistencia de marca (2026-08) | ~7900 caracteres, 15 fuentes + 54 datos | Paquete probatorio; 8 hallazgos cerrados |
| Paradoja de originalidad (2026-08) | ~9500 caracteres, 12 fuentes + 34 datos + 6 casos | 4 rondas de revisión en total a lo largo de la ejecución, nota A-, publicado |
| Aislamiento del campo docente (2026-08) | ~12000 caracteres, 18 fuentes + 47 datos + 9 casos | Auditoría ronda 2 aprobada |
| Escritura estudiantil con IA generativa (2026-08) | ~2000 caracteres, 12 fuentes + 26 datos | Búsqueda triple paralela; puerta M exit 0 |
| Caso de la col china con formaldehído (2026-08) | ~4200 caracteres, 12 fuentes + 29 datos + 4 casos | Puerta M exit 0; 6 reglas incorporadas |
| Artículo sobre noción e idea (2026-09) | ~6280 caracteres, 18 fuentes + 15 datos, 0 casos | 2 rondas de auditoría, 23/30 revisión menor, P0 real = 0 |

> **Cómo leer esta tabla (dos criterios que se confunden con facilidad)**: ① «rondas de revisión» cuenta **todas las pasadas del redactor en esa ejecución** (fase 3.5 → v2, correcciones de la crítica T6, rondas G14, bucle de auditoría), mientras que el límite propio de la pipeline (**≤2 rondas**) se aplica **solo al bucle de auditoría de la fase 4.2**: los dos números no miden lo mismo; ② los resultados son **valores históricos registrados en el momento de cada ejecución, con la versión de scripts de entonces** — no son reproducibles con los scripts actuales. Volver a ejecutar los scripts del paquete sobre los proyectos archivados da hoy, por ejemplo, el artículo de la col china con formaldehído en `exit 2` con 5 P0 (M-Form-6/10, M-Exist-7/9, M-Integrity-1): tres de esas puertas se añadieron **después** de aquella ejecución. Lea la tabla como «lo que la pipeline produjo entonces», no como «el conjunto de puertas actual aprueba estos proyectos».

> **Referencias cruzadas (lote de auditoría documental v18.78.0 §7.2)**: análisis detallado de los 6 casos representativos de esta tabla en [`docs/introduction.md` §实战验证](docs/introduction.md) (caso del repollo chino con formaldehído ~4200 caracteres v2.3.7-dsh.8 + 6 casos del período v18.x); campos completos y rutas de productos para casos v2.x en [`references/case-studies.md`](skills/lunheng-article-pipeline/references/case-studies.md) §instantánea histórica. **Tarjeta rápida para recién llegados (lote v18.78.0 §7.2)**: números duros (versión / roles / fases / puertas / scripts / comandos / familia de códigos de salida) fuente única = [`docs/quick-facts.md`](docs/quick-facts.md).

Puertas locales (**solo fuentes del repositorio** — el paquete npm **no incluye** `scripts/` ni `tests/`, por lo que los comandos siguientes no se pueden ejecutar en una instalación desde el paquete; dentro del paquete puede ejecutar el conjunto equivalente sobre el tarball recién descargado con `pack-smoke`): `node skills/lunheng-article-pipeline/scripts/consistency-check.mjs`, `node scripts/plugin-surface-check.mjs`, `node scripts/repo-hygiene-check.mjs`, `node scripts/pack-smoke.mjs`, `node --test "tests/**/*.test.mjs"`.

## Known limitations

- **Prioridad del chino.** Prompts de rol, entregables, nombres de archivo y flujos están en chino por defecto.
- **Sin verificación de red por defecto.** Las comprobaciones numéricas suelen quedar «pendientes de revisión manual» porque las fuentes de pago no se pueden recuperar.
- **La independencia de la auditoría tiene coste.** Una ejecución completa lanza más de 15 subagentes; el gasto se concentra en lecturas de contexto.
- **La puerta M puede dar falsos positivos.** El verificador debe registrar `script_exit_raw` y justificar el veredicto `exit` en lugar de editar el documento para forzar exit 0.
- **No sustituye la revisión real.** El informe T9 es una simulación previa al envío.

## License

MIT License
