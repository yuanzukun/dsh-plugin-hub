// dsh-hybrid-memory: 融合 Hermes 轻量快照 + Noema 可检索知识库的 DSH 记忆插件。
//
// 三层架构：
//   L1 快照层      —— MEMORY.md / USER.md，按需读取：只在模型主动调用 memory_* 工具时
//                    才进入上下文，不做会话级常驻注入。
//   L2 知识库层    —— facts/ 一事实一文件 + node:sqlite FTS5 索引 + 实体抽取。
//   L3 导入层      —— 从 Hermes/Claude/Codex/WorkBuddy 导入既有记忆，账本去重。
//
// 数据根目录默认 D:\Develop\DeepSeek Harness\memory（D 盘，绝不落 C 盘），
// 可用环境变量 DSH_HYBRID_MEMORY_ROOT 覆盖。
//
// ESM 模块格式（cordis bundle rule）：named exports apply/inject/name。
// 所有注册都属于插件 fiber（ctx.effect / disposers）。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { defineTool } from '@deepseek-ai/dsh-tools'
import {
  L1_LIMITS,
  L2_TOKEN_BUDGET,
  ensureDir,
  readTextSafe,
  writeTextAtomic,
  l1Update,
  parseL1,
  openDb,
  closeDb,
  insertFact,
  acceptFact,
  deleteFactRow,
  updateFactBody,
  listFacts,
  searchFacts,
  recallContext,
  extractEntities,
  getFactById,
  readLedger,
  writeLedger,
  contentKey,
  slugify,
  nowStamp,
  upsertImportedFact,
  withFileLockSync,
  firstThreat,
} from './core.js'
import {
  listApprovedMemoryDocuments,
  projectAgentHubDocument,
  resolveAgentHubRoot,
} from './agent-hub-source.js'

const name = 'hybrid-memory'
// tools 是硬依赖。
const inject = ['tools']

// 记忆数据根：绝不放 C 盘。默认 D 盘，环境变量可覆盖。
const DEFAULT_DATA_ROOT = 'D:\\Develop\\DeepSeek Harness\\memory'
function dataRoot() {
  return process.env.DSH_HYBRID_MEMORY_ROOT || DEFAULT_DATA_ROOT
}

// ---------------------------------------------------------------------------
// L3 导入层：从其他工具导入记忆（去重账本）
// ---------------------------------------------------------------------------

// Hermes 的 HERMES_HOME 可能指向 D:\Develop\hermes（本机实测）或 ~/.hermes，
// 两个位置都探测；同时支持环境变量 HERMES_HOME 覆盖。
function hermesHome() {
  if (process.env.HERMES_HOME) return process.env.HERMES_HOME
  const home = os.homedir()
  // 常见安装位置探测（返回第一个存在的）
  const candidates = [
    'D:\\Develop\\hermes',
    path.join(home, '.hermes'),
    path.join(home, 'hermes'),
  ]
  for (const c of candidates) {
    try {
      if (fs.existsSync(path.join(c, 'memories'))) return c
    } catch { /* ignore */ }
  }
  return candidates[0] // 默认 D:\Develop\hermes（Windows 实测路径）
}

function importSources() {
  const hh = hermesHome()
  const home = os.homedir()
  return {
    hermes: {
      label: 'Hermes',
      // 路径以实际存在为准（按顺序取第一个存在的文件）
      files: [
        path.join(hh, 'memories', 'MEMORY.md'),
        path.join(hh, 'memories', 'USER.md'),
        path.join(hh, 'SOUL.md'),
      ],
      // Hermes 记忆用 § 分隔纯文本条目（无 markdown 标题），需专门切分；
      // 文件可能是 CRLF，分隔符要兼容 \r?\n。
      sectionSplit: /\r?\n§\r?\n/,
    },
    claude: {
      label: 'Claude Code',
      files: [
        path.join(home, '.claude', 'CLAUDE.md'),
        path.join(home, '.claude', 'CLAUDE.local.md'),
        path.join(home, '.claude', 'MEMORY.md'),
      ],
    },
    codex: {
      label: 'Codex',
      files: [
        path.join(home, '.codex', 'AGENTS.md'),
        path.join(home, '.codex', 'memories', 'MEMORY.md'),
      ],
    },
    workbuddy: {
      label: 'WorkBuddy',
      files: [
        path.join(home, '.codebuddy', 'CODEBUDDY.md'),
        path.join(home, '.workbuddy', 'memory.md'),
        path.join(home, '.workbuddy', 'AGENTS.md'),
      ],
    },
  }
}

function importAgentHub(root, { dryRun = false, acceptedDecisionsOnly = true, hubRoot } = {}) {
  const hub = resolveAgentHubRoot(hubRoot)
  const documents = listApprovedMemoryDocuments(hub, { acceptedDecisionsOnly })
  const result = { ok: true, dryRun, source: 'agent-hub', scanned: documents.length, imported: 0, updated: 0, unchanged: 0, skipped: 0, skippedByReason: {}, items: [] }
  const cleanDocuments = documents.filter((document) => {
    const threat = firstThreat(document.body)
    if (!threat) return true
    result.skipped++
    result.skippedByReason.threatScan = (result.skippedByReason.threatScan || 0) + 1
    return false
  })
  if (dryRun) return { ...result, scanned: documents.length, eligible: cleanDocuments.length }
  const lock = path.join(root, '.agent-hub-import.lock')
  const journalPath = path.join(root, 'agent-hub-import-journal.json')
  return withFileLockSync(lock, () => {
    const previousJournal = (() => { try { return JSON.parse(readTextSafe(journalPath)) } catch { return null } })()
    const journal = { state: 'prepared', source: 'agent-hub', sourceVersion: 'agent-hub-memory-v1', files: cleanDocuments.map((document) => ({ relativePath: document.relativePath, contentHash: document.contentHash })), startedAt: nowStamp() }
    writeTextAtomic(journalPath, JSON.stringify(journal, null, 2) + '\n')
    const ledger = readLedger(root)
    const db = openDb(root)
    for (const document of cleanDocuments) {
      const projected = projectAgentHubDocument(document)
      const existing = db.prepare('SELECT id FROM facts WHERE id = ?').get(projected.id)
      const upserted = upsertImportedFact(root, projected)
      const ledgerKey = `${document.sourceVersion}|${document.relativePath}`
      ledger[ledgerKey] = { id: projected.id, source: document.source, category: document.category, relativePath: document.relativePath, contentHash: document.contentHash, importedAt: nowStamp() }
      writeLedger(root, ledger)
      if (upserted.action === 'inserted') result.imported++
      else if (upserted.action === 'updated') result.updated++
      else result.unchanged++
      result.items.push({ relativePath: document.relativePath, id: projected.id, action: upserted.action, existed: Boolean(existing) })
    }
    journal.state = 'committed'
    journal.completedAt = nowStamp()
    journal.result = { imported: result.imported, updated: result.updated, unchanged: result.unchanged, skipped: result.skipped }
    writeTextAtomic(journalPath, JSON.stringify(journal, null, 2) + '\n')
    if (previousJournal?.state === 'prepared') result.recoveredPreparedImport = true
    return result
  })
}

function importMemories(root, sourcesFilter) {
  if (sourcesFilter && sourcesFilter.includes('agent-hub')) return importAgentHub(root, { dryRun: false })
  const sources = importSources()
  const ledger = readLedger(root)
  const db = openDb(root)
  const imported = []
  const skipped = []
  let totalSections = 0

  for (const [srcId, src] of Object.entries(sources)) {
    if (sourcesFilter && !sourcesFilter.includes(srcId)) continue
    for (const file of src.files) {
      const content = readTextSafe(file)
      if (!content.trim()) continue
      // 有专门分隔符的源（Hermes §）用它切；否则按 markdown 标题切。
      // 兼容 CRLF（Hermes 文件实测是 \r\n）。
      const splitRe = src.sectionSplit || /\r?\n(?=#{1,3}\s)/
      const sections = content.split(splitRe)
      for (const section of sections) {
        // 剥掉段开头的残留 §（连续 § 分隔时，前一个 § 会粘到本段开头）
        const trimmed = section.replace(/^§[\r\n]*/, '').trim()
        // 跳过空段和单字符垃圾段
        if (!trimmed || trimmed.length <= 1) continue
        totalSections++
        const key = contentKey(file, trimmed)
        if (ledger[key]) {
          skipped.push({ source: srcId, file, key })
          continue
        }
        const titleMatch = trimmed.match(/^#{1,3}\s*(.+)$/m)
        // Hermes § 条目没有标题：取首行前 40 字作为标题
        const title = titleMatch
          ? titleMatch[1].trim().slice(0, 60)
          : trimmed.split(/\r?\n/)[0].slice(0, 40) || `${src.label} import ${nowStamp()}`
        // 6.5: ID 加内容 hash 前 8 位，防同一秒导入相同标题不同内容时碰撞
        const id = `${srcId}-${nowStamp()}-${slugify(title).slice(0, 20)}-${key.slice(0, 8)}`
        const result = insertFact(root, {
          id,
          title,
          body: trimmed,
          entities: extractEntities(trimmed),
          tags: [srcId],
        })
        ledger[key] = { id: result.id, source: srcId, file, importedAt: nowStamp() }
        imported.push({ source: srcId, file: path.basename(file), title, id: result.id })
      }
    }
  }

  writeLedger(root, ledger)
  return {
    ok: true,
    imported,
    skippedCount: skipped.length,
    totalSections,
    stats: { facts: db.prepare('SELECT COUNT(*) AS n FROM facts').get().n },
  }
}

// ---------------------------------------------------------------------------
// 工具定义
// ---------------------------------------------------------------------------

function registerTools(ctx, root) {
  // --- L1 ---
  ctx.tools.register(defineTool({
    name: 'memory_add',
    description: 'Add a durable entry to the L1 snapshot memory (MEMORY.md or USER.md). kind=memory for agent notes (environment facts, project conventions, tool quirks); kind=user for facts about the user (preferences, communication style, habits). Char-limited, not token-limited. L1 is read on demand: it enters the context only when the model actively calls a memory_* tool (e.g. memory_recall) — never auto-injected.',
    parameters: {
      kind: { type: 'string', required: true, description: 'memory or user' },
      title: { type: 'string', required: true, description: 'Entry title (unique within the file).' },
      content: { type: 'string', required: true, description: 'Entry content.' },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      return JSON.stringify(l1Update(root, args.kind === 'user' ? 'user' : 'memory', 'add', args), null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'memory_replace',
    description: 'Replace an existing L1 snapshot entry by title. Same char limits and drift/threat guards as memory_add.',
    parameters: {
      kind: { type: 'string', required: true, description: 'memory or user' },
      title: { type: 'string', required: true, description: 'Existing entry title.' },
      content: { type: 'string', required: true, description: 'New content.' },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      return JSON.stringify(l1Update(root, args.kind === 'user' ? 'user' : 'memory', 'replace', args), null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'memory_remove',
    description: 'Remove an L1 snapshot entry by title.',
    parameters: {
      kind: { type: 'string', required: true, description: 'memory or user' },
      title: { type: 'string', required: true, description: 'Entry title to remove.' },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      return JSON.stringify(l1Update(root, args.kind === 'user' ? 'user' : 'memory', 'remove', args), null, 2)
    },
  }))

  // --- L2 ---
  ctx.tools.register(defineTool({
    name: 'memory_remember',
    description: 'Save a durable fact, decision, constraint, or preference into the knowledge base (L2). One fact per Markdown file under facts/, FTS5-indexed with entity extraction. Default auto-accept: persists immediately. Pass review=true to route through the review queue instead.',
    parameters: {
      title: { type: 'string', required: true, description: 'Short fact title.' },
      content: { type: 'string', required: true, description: 'The fact body.' },
      tags: { type: 'array', items: { type: 'string' }, description: 'Optional tags.' },
      review: { type: 'boolean', description: 'Route through review queue (default false = auto-accept).' },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      const id = `fact-${nowStamp()}-${slugify(args.title).slice(0, 24)}`
      const r = insertFact(root, {
        id,
        title: args.title,
        body: args.content,
        tags: args.tags || [],
        status: args.review ? 'pending' : 'active',
      })
      return JSON.stringify(r, null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'memory_search',
    description: 'Full-text search over both memory layers: L2 knowledge-base facts (FTS5 + entity-weighted ranking) and L1 frozen-snapshot entries (MEMORY.md/USER.md).',
    parameters: {
      query: { type: 'string', required: true, description: 'Search query.' },
      limit: { type: 'number', description: 'Max results (default 8).' },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      const query = args.query
      const hits = searchFacts(root, query, { limit: args.limit || 8 })
      // 合并 L1 快照条目：按标题/内容包含查询词过滤
      const l1Entries = []
      for (const kind of ['memory', 'user']) {
        for (const e of parseL1(readTextSafe(path.join(root, kind === 'user' ? 'USER.md' : 'MEMORY.md')))) {
          if (e.malformed) continue
          if ((e.title + ' ' + e.content).toLowerCase().includes(query.toLowerCase())) {
            l1Entries.push({ id: `l1-${kind}-${e.title}`, kind, title: e.title, body: e.content, layer: 'L1' })
          }
        }
      }
      return JSON.stringify({
        ok: true,
        count: hits.length + l1Entries.length,
        hits,
        l1: l1Entries,
      }, null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'memory_browse',
    description: 'Browse the knowledge base catalog: list recent facts or filter by tag/entity.',
    parameters: {
      tag: { type: 'string', description: 'Filter by tag (e.g. hermes, claude).' },
      limit: { type: 'number', description: 'Max results (default 50).' },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      let facts = listFacts(root, 'active', args.limit || 50)
      if (args.tag) facts = facts.filter((f) => f.tags.includes(args.tag))
      return JSON.stringify({ ok: true, count: facts.length, facts }, null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'memory_recall',
    description: `Fused recall: combine the L1 frozen snapshot with L2 knowledge-base search results for a query, packed under a token budget (default ${L2_TOKEN_BUDGET}). Use when the current task depends on prior context, user preferences, or project conventions. Pass fact_id instead of query to retrieve one fact's full original body by id (CCR 可逆性：被压缩/裁切的条目可依 id 锚点随时取回原文).`,
    parameters: {
      query: { type: 'string', description: `What to recall context for (omit when fact_id is given).` },
      fact_id: { type: 'string', description: "Retrieve one fact's full original body by id (mutually exclusive with query)." },
      budget_tokens: { type: 'number', description: `Token budget (default ${L2_TOKEN_BUDGET}).` },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      if (args.fact_id) {
        const f = getFactById(root, String(args.fact_id))
        if (!f) return JSON.stringify({ ok: false, error: `no fact with id "${args.fact_id}"` })
        return JSON.stringify({ ok: true, fact: f }, null, 2)
      }
      const text = recallContext(root, args.query, { budgetTokens: args.budget_tokens || L2_TOKEN_BUDGET })
      return text || '(no relevant memory found)'
    },
  }))

  // --- L3 ---
  ctx.tools.register(defineTool({
    name: 'memory_import',
    description: 'Import memories from other AI coding tools (Hermes, Claude Code, Codex, WorkBuddy). Use sources=[agent-hub] for the explicit approved Agent Hub projection; omit sources to retain the existing sources.',
    parameters: {
      sources: {
        type: 'array',
        items: { type: 'string' },
        description: 'Sources to import: hermes, claude, codex, workbuddy. Omit = all.',
      },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      return JSON.stringify(importMemories(root, args.sources), null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'memory_import_agent_hub',
    description: 'Import only approved Agent Hub memory/global, memory/projects, and accepted memory/decisions Markdown documents. Pass dry_run=true to scan without writing.',
    parameters: {
      dry_run: { type: 'boolean', description: 'Scan and report without writing facts or the ledger.' },
      accepted_decisions_only: { type: 'boolean', description: 'Only import decisions whose sibling JSON status is accepted; default true.' },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      return JSON.stringify(importAgentHub(root, { dryRun: Boolean(args.dry_run), acceptedDecisionsOnly: args.accepted_decisions_only !== false }), null, 2)
    },
  }))

  // --- 管理 ---
  ctx.tools.register(defineTool({
    name: 'memory_status',
    description: 'Show memory system status: data root, L1 char usage, L2 fact count, pending review count, ledger size.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute() {
      const db = openDb(root)
      const facts = db.prepare('SELECT COUNT(*) AS n FROM facts').get().n
      const pending = db.prepare('SELECT COUNT(*) AS n FROM facts WHERE status = ?').get('pending').n
      const mem = readTextSafe(path.join(root, 'MEMORY.md'))
      const usr = readTextSafe(path.join(root, 'USER.md'))
      return JSON.stringify({
        ok: true,
        dataRoot: root,
        l1: { memoryChars: mem.length, userChars: usr.length, limits: L1_LIMITS },
        l2: { facts, pending },
        ledger: { importedSections: Object.keys(readLedger(root)).length },
      }, null, 2)
    },
  }))

  // --- 审核（P3）---
  ctx.tools.register(defineTool({
    name: 'memory_review_list',
    description: 'List pending memory candidates waiting in the review queue (facts saved with review=true).',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute() {
      const items = listFacts(root, 'pending', 100)
      return JSON.stringify({ ok: true, count: items.length, items }, null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'memory_review_decide',
    description: 'Accept, reject, or edit a pending memory candidate by id. Accept moves the markdown from pending/ to facts/; edit rebuilds the FTS index for the new content.',
    parameters: {
      id: { type: 'string', required: true, description: 'Fact id.' },
      action: { type: 'string', required: true, description: 'accept | reject | edit' },
      content: { type: 'string', description: 'New content when action=edit.' },
    },
    output: {
      schema: { type: 'string' },
      render(_args, value) { return [{ type: 'text', text: String(value) }] },
    },
    execute(args) {
      const db = openDb(root)
      const row = db.prepare('SELECT * FROM facts WHERE id = ?').get(args.id)
      if (!row) return JSON.stringify({ ok: false, error: `fact not found: ${args.id}` })
      if (args.action === 'accept') {
        acceptFact(root, args.id)
        return JSON.stringify({ ok: true, id: args.id, action: 'accepted', movedTo: 'facts/' })
      }
      if (args.action === 'reject') {
        deleteFactRow(root, args.id)
        return JSON.stringify({ ok: true, id: args.id, action: 'rejected' })
      }
      if (args.action === 'edit') {
        // 复用 updateFactBody：统一刷新 SQLite body/entities + FTS 索引 + Markdown 文件
        updateFactBody(root, args.id, args.content)
        return JSON.stringify({ ok: true, id: args.id, action: 'edited' })
      }
      return JSON.stringify({ ok: false, error: `unknown action: ${args.action}` })
    },
  }))
}

// ---------------------------------------------------------------------------
// 插件主入口
// ---------------------------------------------------------------------------

function apply(ctx) {
  const root = dataRoot()
  ensureDir(root)
  ensureDir(path.join(root, 'facts'))
  ensureDir(path.join(root, 'pending'))
  if (!fs.existsSync(path.join(root, 'MEMORY.md'))) {
    writeTextAtomic(path.join(root, 'MEMORY.md'), '# MEMORY.md - agent notes\n')
  }
  if (!fs.existsSync(path.join(root, 'USER.md'))) {
    writeTextAtomic(path.join(root, 'USER.md'), '# USER.md - about the user\n')
  }
  openDb(root)

  // 6.3: 插件销毁时关闭 SQLite 连接（复用单连接，避免句柄/锁累积）
  ctx.effect(() => () => closeDb(root))

  registerTools(ctx, root)

  // 设置页数据端点（webServer 可选；复用 session-delete 已验证的模式）。
  // GET  /__hybrid-memory/status  - 状态 JSON
  // POST /__hybrid-memory/import  - 触发导入 { sources?: string[] }
  const registerHttp = (host, targetCtx) => {
    const sendJson = (res, status, obj) => {
      const body = JSON.stringify(obj)
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'content-length': Buffer.byteLength(body),
      })
      res.end(body)
    }
    targetCtx.effect(() => host.register({
      kind: 'exact',
      path: '/__hybrid-memory/status',
      handler: async (req, res) => {
        if (req.method !== 'GET') return sendJson(res, 405, { error: 'method not allowed' })
        try {
          const db = openDb(root)
          sendJson(res, 200, {
            ok: true,
            dataRoot: root,
            l1: {
              memoryChars: readTextSafe(path.join(root, 'MEMORY.md')).length,
              userChars: readTextSafe(path.join(root, 'USER.md')).length,
              limits: L1_LIMITS,
            },
            l2: {
              facts: db.prepare('SELECT COUNT(*) AS n FROM facts').get().n,
              pending: db.prepare('SELECT COUNT(*) AS n FROM facts WHERE status = ?').get('pending').n,
            },
            ledger: { importedSections: Object.keys(readLedger(root)).length },
          })
        } catch (e) {
          sendJson(res, 500, { ok: false, error: e.message })
        }
      },
    }))
    targetCtx.effect(() => host.register({
      kind: 'exact',
      path: '/__hybrid-memory/import',
      handler: async (req, res) => {
        if (req.method !== 'POST') return sendJson(res, 405, { error: 'method not allowed' })
        let body = ''
        try {
          for await (const chunk of req) body += chunk
        } catch { /* ignore */ }
        let args = {}
        try { if (body) args = JSON.parse(body) } catch { /* bad json */ }
        try {
          const result = importMemories(root, args.sources)
          sendJson(res, 200, result)
        } catch (e) {
          sendJson(res, 500, { ok: false, error: e.message })
        }
      },
    }))
  }
  const ws = ctx.get('webServer')
  if (ws !== undefined) {
    registerHttp(ws, ctx)
  } else {
    ctx.inject(['webServer'], (sub) => registerHttp(sub.webServer, sub))
  }

  // ---------------------------------------------------------------------------
  // 记忆按需读取（不再自动注入）
  //
  // v0.2.0：移除全部自动注入（L1 常驻 system prompt、agent/pre-step 首步/触发词
  // 召回、tools/post-execute 的 skill 附带记忆）。记忆只在模型主动调用 memory_*
  // 工具时才进入上下文；会话内不再出现 [系统注入·记忆] 标签。
  // 保留 agent/session-start 日志 handler 与 status() 查询端点。
  // ---------------------------------------------------------------------------

  ctx.on('agent/session-start', () => {
    try {
      const db = openDb(root)
      const facts = db.prepare('SELECT COUNT(*) AS n FROM facts').get().n
      console.log(`[hybrid-memory] session started; L2 facts=${facts}; root=${root}`)
    } catch { /* ignore */ }
  })

  return {
    status() {
      const db = openDb(root)
      return {
        dataRoot: root,
        l1: {
          memoryChars: readTextSafe(path.join(root, 'MEMORY.md')).length,
          userChars: readTextSafe(path.join(root, 'USER.md')).length,
        },
        l2: { facts: db.prepare('SELECT COUNT(*) AS n FROM facts').get().n },
      }
    },
  }
}

export { apply, inject, name }
