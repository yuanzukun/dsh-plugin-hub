// dsh-hybrid-memory 核心逻辑（零 DSH 依赖，纯 Node）。
// 与 Cordis/DSH 无关，便于单元测试与复用。
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { DatabaseSync } from 'node:sqlite'

// ---------------------------------------------------------------------------
// 配置常量
// ---------------------------------------------------------------------------

export const L1_LIMITS = { memory: 8000, user: 4000 }
export const L2_TOKEN_BUDGET = 1200
// L2 动态注入的字符保障（目标值与下限）：正常预算下知识库检索段给到约 400 字符；
// 预算被 L1 挤占时也绝不低于 64 字符的下限（参考 headroom CCR 的"压缩代替截断"：
// 被裁掉的条目仍带 id 锚点，可经 memory_recall fact_id 按需取回原文，压缩是安全的）。
export const MIN_L2_CHARS = 400
export const ENTRY_DELIM = '\n§\n'

// ---------------------------------------------------------------------------
// 小工具
// ---------------------------------------------------------------------------

export function ensureDir(p) {
  fs.mkdirSync(p, { recursive: true })
}

export function withFileLockSync(lockPath, fn, { timeoutMs = 5000, retryMs = 25 } = {}) {
  ensureDir(path.dirname(lockPath))
  const started = Date.now()
  let fd
  while (fd === undefined) {
    try {
      fd = fs.openSync(lockPath, 'wx')
      fs.writeFileSync(fd, JSON.stringify({ pid: process.pid, acquiredAt: new Date().toISOString() }) + '\n', 'utf8')
      fs.fsyncSync(fd)
    } catch (error) {
      if (fd !== undefined) { try { fs.closeSync(fd) } catch {} }
      fd = undefined
      if (error?.code !== 'EEXIST') throw error
      if (Date.now() - started >= timeoutMs) throw new Error(`memory lock timeout: ${lockPath}`)
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, retryMs)
    }
  }
  try { return fn() } finally {
    try { fs.closeSync(fd) } catch {}
    try { fs.unlinkSync(lockPath) } catch {}
  }
}

export function readTextSafe(p) {
  try {
    return fs.readFileSync(p, 'utf8')
  } catch {
    return ''
  }
}

export function writeTextAtomic(p, content) {
  ensureDir(path.dirname(p))
  const tmp = `${p}.tmp-${process.pid}-${Date.now()}`
  fs.writeFileSync(tmp, content, 'utf8')
  fs.renameSync(tmp, p)
}

export function slugify(s) {
  return String(s)
    .toLowerCase()
    .replace(/[^a-z0-9\u4e00-\u9fa5]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 60)
}

export function nowStamp(d = new Date()) {
  const p = (n) => String(n).padStart(2, '0')
  return `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`
}

// 简单中文/英文分词：CJK 按 2 字滑窗切词 + 英文按词拆分
export function tokenize(text) {
  const tokens = new Set()
  const cjkRuns = String(text).match(/[\u4e00-\u9fa5]{2,}/g) || []
  for (const run of cjkRuns) {
    // 2 字滑窗：『用户偏好』→ 用户、户偏、偏好
    for (let i = 0; i <= run.length - 2; i++) {
      tokens.add(run.slice(i, i + 2))
    }
    // 保留整段（≥4 字时）作为词组候选
    if (run.length >= 4) tokens.add(run)
  }
  const words = String(text).toLowerCase().match(/[a-z0-9_]{2,40}/g) || []
  for (const w of words) tokens.add(w)
  return [...tokens]
}

// ---------------------------------------------------------------------------
// 威胁扫描
// ---------------------------------------------------------------------------

const THREAT_PATTERNS = [
  /\b(system|developer|user)\s*[:：]\s*(ignore|override|disregard|you are now|new instructions)/i,
  /(ignore\s+(all\s+)?(previous|prior|above)\s+instructions|forget\s+(all\s+)?previous)/i,
  /(api[_-]?key|secret|password|token)\s*[:=]\s*\S{8,}/i,
  /\b(rm\s+-rf|format\s+[a-z]:|del\s+[a-z]:\\|shutdown\s+-s|reg\s+delete)/i,
]

export function firstThreat(content) {
  for (const re of THREAT_PATTERNS) {
    const m = String(content).match(re)
    if (m) return m[0]
  }
  return null
}

// ---------------------------------------------------------------------------
// L1 快照层（按需读取，无自动注入）
// ---------------------------------------------------------------------------

export function l1Files(root) {
  return {
    memory: path.join(root, 'MEMORY.md'),
    user: path.join(root, 'USER.md'),
  }
}

export function parseL1(content) {
  const out = []
  const parts = String(content).split(ENTRY_DELIM)
  for (const part of parts) {
    const trimmed = part.trim()
    if (!trimmed) continue
    const lines = trimmed.split('\n').filter((l) => !/^#\s/.test(l))
    const body = lines.join('\n').trim()
    if (!body) continue
    const titleMatch = body.match(/^(?:\*\*|###)\s*([^\n#]+?)\s*(?:\*\*)?(?=\n|$)/)
    if (titleMatch) {
      out.push({ title: titleMatch[1].trim(), content: body.slice(titleMatch[0].length).trim() })
    } else {
      // 无法解析为条目的游离文本（外部编辑产物）→ 标记 malformed，
      // detectDrift 据此判定结构漂移。
      out.push({ title: null, content: body, malformed: true })
    }
  }
  return out
}

export function serializeL1(entries, header) {
  // malformed 条目（游离文本）无法表达为规范结构，序列化时跳过——
  // detectDrift 会在序列化前拦截它们，这里只是防御。
  const body = entries
    .filter((e) => e && e.title)
    .map((e) => `### ${e.title}\n${e.content}`)
    .join(ENTRY_DELIM)
  return `${header}\n\n${body}\n`
}

export function detectDrift(filePath, header) {
  const onDisk = readTextSafe(filePath)
  if (!onDisk) return null
  const parsed = parseL1(onDisk)
  // 游离文本（外部手动编辑）→ 结构漂移
  if (parsed.some((e) => e.malformed)) {
    return makeDrift(filePath, onDisk)
  }
  const roundTripped = serializeL1(parsed, header)
  if (roundTripped.trim() !== onDisk.trim()) {
    return makeDrift(filePath, onDisk)
  }
  return null
}

function makeDrift(filePath, onDisk) {
  const bak = `${filePath}.bak-${Date.now()}`
  try {
    fs.copyFileSync(filePath, bak)
  } catch { /* ignore */ }
  return { bak, onDisk }
}

export function l1Update(root, kind, op, { title, content }) {
  const { memory, user } = l1Files(root)
  const file = kind === 'user' ? user : memory
  const header = kind === 'user' ? '# USER.md - about the user' : '# MEMORY.md - agent notes'
  const limit = kind === 'user' ? L1_LIMITS.user : L1_LIMITS.memory

  const drift = detectDrift(file, header)
  if (drift) {
    return { ok: false, error: `file drift detected; snapshot saved to ${drift.bak}` }
  }

  const entries = parseL1(readTextSafe(file))
  const threat = content ? firstThreat(content) : null
  if (threat) {
    return { ok: false, error: `content blocked by threat scan: ${threat}` }
  }

  let changed = false
  if (op === 'add') {
    if (!entries.some((e) => e.title === title)) {
      entries.push({ title, content: content || '' })
      changed = true
    } else {
      return { ok: false, error: `entry already exists: ${title}` }
    }
  } else if (op === 'replace') {
    const idx = entries.findIndex((e) => e.title === title)
    if (idx >= 0) {
      entries[idx] = { title, content: content || '' }
      changed = true
    } else {
      return { ok: false, error: `entry not found: ${title}` }
    }
  } else if (op === 'remove') {
    const before = entries.length
    const kept = entries.filter((e) => e.title !== title)
    changed = kept.length !== before
    if (!changed) return { ok: false, error: `entry not found: ${title}` }
    entries.splice(0, entries.length, ...kept)
  }

  const serialized = serializeL1(entries, header)
  const totalChars = serialized.replace(header, '').trim().length
  if (totalChars > limit) {
    return { ok: false, error: `L1 ${kind} over char limit: ${totalChars}/${limit}` }
  }

  if (changed) writeTextAtomic(file, serialized)
  return { ok: true, entries: entries.length, chars: totalChars }
}

export function l1Snapshot(root) {
  const { memory, user } = l1Files(root)
  const mem = readTextSafe(memory).trim()
  const usr = readTextSafe(user).trim()
  const parts = []
  if (mem) parts.push(mem)
  if (usr) parts.push(usr)
  return parts.length ? parts.join('\n\n---\n\n') : ''
}

// ---------------------------------------------------------------------------
// L2 知识库层
// ---------------------------------------------------------------------------

export function l2Paths(root) {
  return {
    factsDir: path.join(root, 'facts'),
    pendingDir: path.join(root, 'pending'),
    dbPath: path.join(root, 'index.db'),
    ledger: path.join(root, 'imports.json'),
  }
}

// 按 root 缓存的 SQLite 连接（插件级单连接，避免句柄堆积；closeDb 显式关闭）
const _dbByRoot = new Map()

export function openDb(root) {
  const cached = _dbByRoot.get(root)
  if (cached) return cached
  const { dbPath, factsDir, pendingDir } = l2Paths(root)
  ensureDir(factsDir)
  ensureDir(pendingDir)
  const db = new DatabaseSync(dbPath)
  db.exec(`PRAGMA busy_timeout = 5000; PRAGMA journal_mode = WAL;
    `)
  db.exec(`
    CREATE TABLE IF NOT EXISTS facts (
      id TEXT PRIMARY KEY,
      file TEXT NOT NULL,
      title TEXT NOT NULL,
      body TEXT NOT NULL,
      entities TEXT NOT NULL DEFAULT '[]',
      tags TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'active',
      created TEXT NOT NULL,
      updated TEXT NOT NULL
    );
    CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(
      title, body, entities, tokenize='unicode61'
    );
    -- 注意：不再注册 facts_* 的 FTS trigger。
    -- FTS 行由 insertFact/updateFactBody 在 JS 层显式维护（预分词写入），
    -- trigger 只能插入原始列，会产生重复/不匹配的索引行。
  `)
  _dbByRoot.set(root, db)
  return db
}

// 预分词：把中文按 2 字窗拆成空格分隔的词序列，让 FTS5(unicode61) 能按词匹配中文。
// FTS5 的 unicode61 分词器不切中文（整段连续 CJK 视为一个 token），
// 所以在写入索引列前先用 tokenize() 生成空格分隔的索引文本。
function indexedText(...texts) {
  const parts = []
  for (const t of texts) {
    const toks = tokenize(String(t || ''))
    for (const tok of toks) parts.push(tok)
  }
  // 去重保序，避免索引膨胀
  return [...new Set(parts)].join(' ')
}

export function extractEntities(text) {
  const entities = new Set()
  const tokens = tokenize(text)
  const freq = {}
  for (const t of tokens) freq[t] = (freq[t] || 0) + 1
  for (const [t, c] of Object.entries(freq)) {
    if (c >= 2 && t.length >= 2) entities.add(t)
  }
  const quoted = String(text).match(/[「『""]([^」』""]{2,20})[」』""]/g) || []
  for (const q of quoted) entities.add(q.replace(/[「『""」』""]/g, ''))
  const proper = String(text).match(/\b[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})?\b/g) || []
  for (const p of proper) entities.add(p.toLowerCase())
  return [...entities].slice(0, 20)
}

// 事实对应的 Markdown 文件路径：pending 状态写 pending/，active 写 facts/
function factFilePath(root, id, status) {
  const { factsDir, pendingDir } = l2Paths(root)
  return path.join(status === 'pending' ? pendingDir : factsDir, `${id}.md`)
}

export function upsertImportedFact(root, { id, title, body, entities, tags, status = 'active', provenance }) {
  const db = openDb(root)
  const existing = db.prepare('SELECT * FROM facts WHERE id = ?').get(id)
  if (existing && existing.body === body && existing.title === title && existing.status === status) return { id, title, action: 'unchanged' }
  if (!existing) return { ...insertFact(root, { id, title, body, entities, tags, status }), action: 'inserted', provenance }
  const now = nowStamp()
  const ent = JSON.stringify(entities || extractEntities(`${title} ${body}`))
  const tagArr = JSON.stringify(tags || [])
  db.prepare('UPDATE facts SET title = ?, body = ?, entities = ?, tags = ?, status = ?, updated = ? WHERE id = ?')
    .run(title, body, ent, tagArr, status, now, id)
  const row = db.prepare('SELECT rowid FROM facts WHERE id = ?').get(id)
  if (row) {
    db.prepare('DELETE FROM facts_fts WHERE rowid = ?').run(row.rowid)
    db.prepare('INSERT INTO facts_fts(rowid, title, body, entities) VALUES (?, ?, ?, ?)')
      .run(row.rowid, indexedText(title), indexedText(body), indexedText(ent))
  }
  writeTextAtomic(factFilePath(root, id, status), `# ${title}\n\n${body}\n`)
  return { id, title, action: 'updated', updated: now, provenance }
}

export function insertFact(root, { id, title, body, entities, tags, status = 'active' }) {
  const db = openDb(root)
  const now = nowStamp()
  const ent = JSON.stringify(entities || extractEntities(`${title} ${body}`))
  const tagArr = JSON.stringify(tags || [])
  db.prepare(
    `INSERT OR REPLACE INTO facts (id, file, title, body, entities, tags, status, created, updated)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(id, `${id}.md`, title, body, ent, tagArr, status, now, now)
  // 显式维护 FTS 行（预分词写入，解决 FTS5 不切中文的问题）。
  // 不用 trigger：trigger 只能插入原始列，无法预分词。
  const row = db.prepare('SELECT rowid FROM facts WHERE id = ?').get(id)
  if (row) {
    db.prepare('DELETE FROM facts_fts WHERE rowid = ?').run(row.rowid)
    db.prepare('INSERT INTO facts_fts(rowid, title, body, entities) VALUES (?, ?, ?, ?)')
      .run(row.rowid, indexedText(title), indexedText(body), indexedText(ent))
  }
  // pending 内容写 pending/，active 写 facts/
  writeTextAtomic(factFilePath(root, id, status), `# ${title}\n\n${body}\n`)
  return { id, title, created: now }
}

// 把 pending 事实转正：更新 SQLite status，并把 Markdown 从 pending/ 移到 facts/
export function acceptFact(root, id) {
  const db = openDb(root)
  const row = db.prepare('SELECT * FROM facts WHERE id = ?').get(id)
  if (!row) return false
  db.prepare('UPDATE facts SET status = ?, updated = ? WHERE id = ?').run('active', nowStamp(), id)
  const pendingPath = factFilePath(root, id, 'pending')
  const activePath = factFilePath(root, id, 'active')
  if (fs.existsSync(pendingPath)) {
    ensureDir(path.dirname(activePath))
    writeTextAtomic(activePath, readTextSafe(pendingPath))
    try { fs.unlinkSync(pendingPath) } catch { /* ignore */ }
  }
  return true
}

// fact 存续期修改（正文/状态）走 updateFactBody，完全可逆。
// deleteFactRow 是永久删除：facts 行 + FTS 行 + 两个目录下的磁盘文件一并移除，
// 有意不做软删除/回收站——被压缩裁掉的条目仍可经 memory_recall fact_id 按需取回，
// 删除前如需保留副本可先复制到 archive 目录（参考 headroom CCR 可逆性原则）。
export function deleteFactRow(root, id) {
  const db = openDb(root)
  const row = db.prepare('SELECT rowid FROM facts WHERE id = ?').get(id)
  if (row) db.prepare('DELETE FROM facts_fts WHERE rowid = ?').run(row.rowid)
  db.prepare('DELETE FROM facts WHERE id = ?').run(id)
  const status = row ? row.status : 'active'
  const file = factFilePath(root, id, status)
  if (fs.existsSync(file)) {
    try { fs.unlinkSync(file) } catch { /* ignore */ }
  }
  // 两个目录都尝试清（防止历史遗留）
  try { fs.unlinkSync(factFilePath(root, id, status === 'pending' ? 'active' : 'pending')) } catch { /* ignore */ }
}

export function updateFactBody(root, id, body) {
  const db = openDb(root)
  const row = db.prepare('SELECT * FROM facts WHERE id = ?').get(id)
  if (!row) return false
  db.prepare('UPDATE facts SET body = ?, entities = ?, updated = ? WHERE id = ?')
    .run(body, JSON.stringify(extractEntities(body)), nowStamp(), id)
  const r2 = db.prepare('SELECT rowid FROM facts WHERE id = ?').get(id)
  if (r2) {
    db.prepare('DELETE FROM facts_fts WHERE rowid = ?').run(r2.rowid)
    db.prepare('INSERT INTO facts_fts(rowid, title, body, entities) VALUES (?, ?, ?, ?)')
      .run(r2.rowid, indexedText(row.title), indexedText(body), indexedText(JSON.stringify(extractEntities(body))))
  }
  // 按当前 status 写对目录
  writeTextAtomic(factFilePath(root, id, row.status), `# ${row.title}\n\n${body}\n`)
  return true
}

export function closeDb(root) {
  const db = openDb(root)
  try { db.close() } catch { /* ignore */ }
  _dbByRoot.delete(root)
}

export function listFacts(root, status = 'active', limit = 50) {
  const db = openDb(root)
  const rows = db
    .prepare('SELECT id, title, body, entities, tags, status, created FROM facts WHERE status = ? ORDER BY created DESC LIMIT ?')
    .all(status, limit)
  return rows.map((r) => ({
    id: r.id,
    title: r.title,
    body: r.body,
    entities: JSON.parse(r.entities || '[]'),
    tags: JSON.parse(r.tags || '[]'),
    status: r.status,
    created: r.created,
  }))
}

export function searchFacts(root, query, { limit = 8, status = 'active' } = {}) {
  const db = openDb(root)
  const tokens = tokenize(query)
  if (!tokens.length) return []
  // 查询词同样预分词（空格分隔），与索引侧的 indexedText 对齐
  const q = tokens.map((t) => `"${t}"`).join(' OR ')
  const rows = db
    .prepare(
      `SELECT f.id, f.title, f.body, f.entities, f.status, f.created,
              bm25(facts_fts, 0, 5.0, 2.0, 1.0) AS score
       FROM facts_fts JOIN facts f ON f.rowid = facts_fts.rowid
       WHERE facts_fts MATCH ? AND f.status = ?
       ORDER BY score ASC LIMIT ?`
    )
    .all(q, status, limit * 4)
  const qEntities = new Set(extractEntities(query))
  const scored = rows.map((r) => {
    const ents = JSON.parse(r.entities || '[]')
    const overlap = ents.filter((e) => qEntities.has(e)).length
    return { ...r, rank: r.score - overlap * 0.5 }
  })
  scored.sort((a, b) => a.rank - b.rank)
  return scored.slice(0, limit).map((r) => ({
    id: r.id,
    title: r.title,
    body: r.body,
    entities: JSON.parse(r.entities || '[]'),
    created: r.created,
    score: Math.round((1 - r.rank) * 100) / 100,
  }))
}

// 智能摘要：标题 + 命中句子优先 + 结尾兜底，绝不硬切长正文（压缩代替截断）
export function summarizeBody(body, { maxChars = 300, hint = '' } = {}) {
  const text = String(body ?? '').trim()
  if (!text || maxChars <= 0) return ''
  if (text.length <= maxChars) return text
  const title = text.split('\n', 1)[0].trim()
  const suffix = '\n…'
  const closing = text.slice(-48).trim()
  const sentences = text.split(/(?<=[。！？.!?])\s*/)
  const hintWords = hint ? [...tokenize(hint)] : []
  const seen = new Set()
  const kept = []
  for (const s of sentences) {
    const t = s.trim()
    if (!t || t === title) continue
    if (hintWords.length && !hintWords.some((w) => t.includes(w))) continue
    if (seen.has(t)) continue
    seen.add(t)
    kept.push(t)
  }
  const headBudget = Math.max(0, maxChars - title.length - suffix.length - closing.length - 2)
  let head = kept.join(' ')
  if (!head && text !== title && headBudget > 0) head = text.slice(0, Math.floor(headBudget * 0.5))
  if (head.length > headBudget) head = head.slice(0, headBudget)
  let out = title
  if (head) out += '\n' + head
  if (closing && !out.includes(closing) && out.length + suffix.length + 1 + closing.length <= maxChars) {
    out += suffix + '\n' + closing
  } else if (out.length + suffix.length <= maxChars) {
    out += suffix
  }
  if (out.length > maxChars) {
    out = out.slice(0, Math.max(0, maxChars - suffix.length)) + suffix
  }
  return out
}

// 按条目边界整块裁切（条目原子性：不切半条）；单块超限可溢出，绝不丢首块
export function trimBlocks(block, maxChars) {
  if (!block || maxChars <= 0) return ''
  if (block.length <= maxChars) return block
  const marker = '\n…(条目按边界裁切)'
  const room = Math.max(0, maxChars - marker.length)
  const pieces = String(block).split(ENTRY_DELIM)
  const kept = []
  for (const piece of pieces) {
    const joinLen = (kept.length ? kept.join(ENTRY_DELIM).length + ENTRY_DELIM.length : 0) + piece.length
    if (kept.length && joinLen > room) break
    kept.push(piece)
  }
  if (!kept.length) return block.slice(0, maxChars)
  return kept.join(ENTRY_DELIM) + marker
}

// 构造 L2 注入块：整体预算 + 单条摘要 + 首条必进 + 后续整条原子（压缩代替截断）
export function buildRecallL2(hits, { maxChars = L2_TOKEN_BUDGET * 2.5, hint = '' } = {}) {
  const list = hits || []
  if (!list.length) return ''
  const header = `[知识库检索: ${hint}]`
  const budget = Math.max(64, Math.floor(maxChars) - header.length - 2)
  const blocks = []
  let used = 0
  for (const h of list) {
    const perEntry = Math.max(40, Math.min(240, budget - used - 60))
    const body = summarizeBody(h.body, { maxChars: perEntry, hint })
    const block = `### ${h.title} (id: ${h.id})\n${body}`
    if (used + block.length + 2 > budget && blocks.length) break
    blocks.push(block)
    used += block.length + 2
    if (used >= budget) break
  }
  if (!blocks.length) return ''
  return header + '\n' + blocks.join('\n\n')
}

// 按 id 取回完整事实（CCR 可逆性：被压缩/裁切的条目可依 id 锚点随时取回原文）
export function getFactById(root, id) {
  const db = openDb(root)
  const r = db.prepare('SELECT id, title, body, entities, tags, status, created, updated FROM facts WHERE id = ?').get(String(id))
  if (!r) return null
  return {
    id: r.id,
    title: r.title,
    body: r.body,
    entities: JSON.parse(r.entities || '[]'),
    tags: JSON.parse(r.tags || '[]'),
    status: r.status,
    created: r.created,
    updated: r.updated,
  }
}

// 召回上下文（memory_recall 工具按需输出）：L2 检索压缩打包，至少保留 MIN_L2_CHARS 预算；
// L1 快照与 L2 共享同一字符预算，按剩余空间收窄后一并返回。
export function recallContext(root, query, { budgetTokens = L2_TOKEN_BUDGET } = {}) {
  const budget = Math.floor(budgetTokens * 2.5)
  const l1 = l1Snapshot(root)
  const l1Block = l1 ? `[L1 快照]\n${l1}` : ''
  const l2Budget = Math.max(64, Math.min(MIN_L2_CHARS, budget - l1Block.length - 2))
  const q = String(query || '').trim() || 'recent facts'
  const hits = searchFacts(root, q, { limit: 6 })
  const l2Block = buildRecallL2(hits, { maxChars: l2Budget, hint: q })
  const parts = []
  if (l2Block) parts.push(l2Block)
  if (l1Block) {
    const l1Room = Math.max(0, budget - l2Block.length - 2)
    const trimmed = l1Room >= l1Block.length ? l1Block : trimBlocks(l1Block, l1Room)
    if (trimmed) parts.unshift(trimmed)
  }
  return parts.join('\n\n')
}

// ---------------------------------------------------------------------------
// L3 导入层
// ---------------------------------------------------------------------------

export function contentKey(filePath, section) {
  return crypto.createHash('sha256').update(`${filePath}\n${section}`).digest('hex').slice(0, 16)
}

export function readLedger(root) {
  try {
    return JSON.parse(fs.readFileSync(l2Paths(root).ledger, 'utf8'))
  } catch {
    return {}
  }
}

export function writeLedger(root, ledger) {
  writeTextAtomic(l2Paths(root).ledger, JSON.stringify(ledger, null, 2))
}

// 把指定文件按章节切分并导入（供导入测试用；生产代码在 index.js 里走 importSources）
export function importSections(root, { source, file, sections }) {
  const ledger = readLedger(root)
  const imported = []
  let skipped = 0
  for (const section of sections) {
    const trimmed = String(section).trim()
    if (!trimmed) continue
    const key = contentKey(file, trimmed)
    if (ledger[key]) {
      skipped++
      continue
    }
    const titleMatch = trimmed.match(/^#{1,3}\s*(.+)$/m)
    const title = titleMatch ? titleMatch[1].trim().slice(0, 60) : `${source} import ${nowStamp()}`
    const id = `${source}-${nowStamp()}-${slugify(title).slice(0, 20)}`
    const r = insertFact(root, { id, title, body: trimmed, entities: extractEntities(trimmed), tags: [source] })
    ledger[key] = { id: r.id, source, file, importedAt: nowStamp() }
    imported.push({ source, title, id: r.id })
  }
  writeLedger(root, ledger)
  return { ok: true, imported, skipped }
}
