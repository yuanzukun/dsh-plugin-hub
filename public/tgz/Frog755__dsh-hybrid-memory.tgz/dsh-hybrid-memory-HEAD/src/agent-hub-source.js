import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'

export const AGENT_HUB_SOURCE_VERSION = 'agent-hub-memory-v1'
export const AGENT_HUB_ALLOWED_DIRS = ['memory/global', 'memory/projects', 'memory/decisions']
const MAX_DOCUMENT_BYTES = 1024 * 1024

export function resolveAgentHubRoot(explicitRoot) {
  return path.resolve(String(explicitRoot || process.env.AGENT_HUB_ROOT || 'D:\\Develop\\ai_workspace\\agent_hub'))
}

export function normalizeAgentHubRelativePath(relativePath) {
  const raw = String(relativePath || '').replaceAll('\\', '/')
  if (!raw || raw.startsWith('/') || /^[a-zA-Z]:\//.test(raw)) throw new Error(`absolute Agent Hub path is not allowed: ${relativePath}`)
  const normalized = path.posix.normalize(raw)
  if (normalized === '.' || normalized.startsWith('../') || normalized.includes('/../')) throw new Error(`Agent Hub path traversal is not allowed: ${relativePath}`)
  if (!AGENT_HUB_ALLOWED_DIRS.some((prefix) => normalized === prefix || normalized.startsWith(`${prefix}/`))) {
    throw new Error(`Agent Hub path is outside the approved memory trees: ${relativePath}`)
  }
  return normalized
}

export function classifyAgentHubDocument(relativePath) {
  const normalized = normalizeAgentHubRelativePath(relativePath)
  if (normalized.startsWith('memory/global/')) return 'global'
  if (normalized.startsWith('memory/projects/')) return 'project'
  return 'decision'
}

function isSafeMarkdownName(name) {
  return name.endsWith('.md') && !name.startsWith('.') && !name.includes('.tmp-') && !name.includes('.bak-')
}

function walkApproved(root, relativeDir, out) {
  const absoluteDir = path.join(root, relativeDir)
  if (!fs.existsSync(absoluteDir)) return
  const realAllowed = fs.realpathSync(absoluteDir)
  for (const entry of fs.readdirSync(absoluteDir, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue
    const relative = `${relativeDir}/${entry.name}`.replaceAll('\\', '/')
    const absolute = path.join(root, relative)
    if (entry.isSymbolicLink()) continue
    if (entry.isDirectory()) {
      walkApproved(root, relative, out)
      continue
    }
    if (!entry.isFile() || !isSafeMarkdownName(entry.name)) continue
    let realFile
    try { realFile = fs.realpathSync(absolute) } catch { continue }
    if (realFile !== realAllowed && !realFile.startsWith(`${realAllowed}${path.sep}`)) continue
    let stat
    try { stat = fs.statSync(realFile) } catch { continue }
    if (stat.size > MAX_DOCUMENT_BYTES) continue
    let body
    try { body = fs.readFileSync(realFile, 'utf8').trim() } catch { continue }
    if (!body) continue
    const category = classifyAgentHubDocument(relative)
    if (category === 'decision') {
      const metadataPath = path.join(path.dirname(absolute), `${path.basename(absolute, '.md')}.json`)
      if (fs.existsSync(metadataPath)) {
        try {
          const metadata = JSON.parse(fs.readFileSync(metadataPath, 'utf8'))
          if (metadata.status && metadata.status !== 'accepted') continue
        } catch { continue }
      }
    }
    const title = body.match(/^#{1,3}\s+(.+)$/m)?.[1]?.trim() || path.basename(entry.name, '.md')
    const contentHash = crypto.createHash('sha256').update(`${relative}\n${body}`, 'utf8').digest('hex').slice(0, 16)
    out.push({ source: 'agent-hub', sourceVersion: AGENT_HUB_SOURCE_VERSION, category, relativePath: relative, title, body, contentHash })
  }
}

export function listApprovedMemoryDocuments(explicitRoot, { acceptedDecisionsOnly = true } = {}) {
  const root = resolveAgentHubRoot(explicitRoot)
  const documents = []
  for (const relativeDir of AGENT_HUB_ALLOWED_DIRS) {
    if (relativeDir === 'memory/decisions' && !acceptedDecisionsOnly) {
      // The default adapter still only accepts valid decision metadata when a
      // sibling JSON exists; missing metadata remains valid in directory-only mode.
    }
    walkApproved(root, relativeDir, documents)
  }
  return documents.sort((a, b) => a.relativePath.localeCompare(b.relativePath))
}

export function projectAgentHubDocument(document) {
  const safeId = `${AGENT_HUB_SOURCE_VERSION}-${document.relativePath.replaceAll('/', '-')}`
  return {
    id: safeId.slice(0, 180),
    title: document.title,
    body: document.body,
    tags: ['agent-hub', document.category, `agent-hub-v1:${document.contentHash}`],
    provenance: {
      source: document.source,
      sourceVersion: document.sourceVersion,
      category: document.category,
      relativePath: document.relativePath,
      contentHash: document.contentHash,
    },
  }
}
