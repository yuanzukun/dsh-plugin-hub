// dsh-hybrid-memory client half: 设置页卡片（ModuleLoader bundle 格式）。
// 展示记忆状态 + 一键导入按钮；数据通过 HTTP 端点与 Host 交互。
//
// 注意（static client bundle 规则）：
//  - 必须用 window.__ModuleLoader__.load({ id, factory }) 包装；
//  - 不能用 JSX/import；用 React.createElement；
//  - exports.inject 声明 Cordis 服务注入（slots）。

window.__ModuleLoader__.load({
  id: "@frog755/dsh-hybrid-memory",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;

    var React = require("react");

    var NS = "hybrid-memory";

    // ---- HTTP 辅助（6.6）：检查 r.ok、解析 JSON、非 2xx 给出可读错误 ----

    function requestJson(url, options) {
      return fetch(url, options).then(function (r) {
        if (!r.ok) {
          return r.text().then(function (body) {
            var snippet = body ? body.slice(0, 200) : "";
            throw new Error("HTTP " + r.status + " for " + url + (snippet ? ": " + snippet : ""));
          });
        }
        return r.json().catch(function () {
          throw new Error("non-JSON response for " + url);
        });
      });
    }

    // ---- 状态卡片组件 ----------------------------------------------------

    function MemoryCard() {
      var state = React.useState(null);
      var status = state[0];
      var setStatus = state[1];
      var busy = React.useState(false);
      var setBusy = busy[1];
      var error = React.useState(null);
      var setError = error[1];

      var loadStatus = function () {
        requestJson("/__hybrid-memory/status")
          .then(function (j) {
            if (j && j.ok) setStatus(j);
            else setError((j && j.error) || "failed to load status");
          })
          .catch(function (e) { setError(String(e && e.message ? e.message : e)); });
      };

      React.useEffect(function () {
        loadStatus();
        var t = setInterval(loadStatus, 15000);
        return function () { clearInterval(t); };
      }, []);

      var doImport = function () {
        setBusy(true);
        setError(null);
        requestJson("/__hybrid-memory/import", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({}),
        })
          .then(function (j) {
            if (j && j.ok) {
              setStatus(function (old) {
                return old ? Object.assign({}, old, {
                  l2: { facts: j.stats.facts, pending: 0 },
                  ledger: { importedSections: old.ledger.importedSections + j.imported.length },
                }) : old;
              });
            } else {
              setError((j && j.error) || "import failed");
            }
            setBusy(false);
          })
          .catch(function (e) { setError(String(e && e.message ? e.message : e)); setBusy(false); });
      };

      return React.createElement("div", { style: { padding: "12px 16px", display: "flex", flexDirection: "column", gap: "10px" } },
        React.createElement("div", { style: { fontSize: 13, color: "var(--text-2, #888)", fontWeight: 600 } }, "Memory (dsh-hybrid-memory)"),
        status
          ? React.createElement(React.Fragment, null,
              React.createElement("div", { style: { fontSize: 12, lineHeight: 1.6 } },
                "Data root: " + status.dataRoot,
                React.createElement("br", null),
                "L1 snapshot: " + status.l1.memoryChars + "/" + status.l1.limits.memory + " chars (agent) · " +
                  status.l1.userChars + "/" + status.l1.limits.user + " chars (user)",
                React.createElement("br", null),
                "L2 knowledge base: " + status.l2.facts + " facts" +
                  (status.l2.pending > 0 ? " · " + status.l2.pending + " pending review" : "") +
                  " · ledger " + status.ledger.importedSections + " imported sections"
              ),
              React.createElement("div", { style: { display: "flex", gap: 8, marginTop: 4 } },
                React.createElement("button", {
                  onClick: doImport,
                  disabled: busy[0],
                  style: { padding: "4px 12px", fontSize: 12, borderRadius: 6, cursor: "pointer", border: "1px solid var(--border, #333)", background: "var(--bg-2, #222)", color: "var(--text-1, #ddd)" },
                }, busy[0] ? "Importing…" : "Import from Hermes/Claude/Codex/WorkBuddy"),
                React.createElement("button", {
                  onClick: loadStatus,
                  style: { padding: "4px 12px", fontSize: 12, borderRadius: 6, cursor: "pointer", border: "1px solid var(--border, #333)", background: "transparent", color: "var(--text-1, #ddd)" },
                }, "Refresh")
              )
            )
          : React.createElement("div", { style: { fontSize: 12, color: "var(--text-2, #888)" } },
              error ? "Error: " + error : "Loading…"
            ),
        error && status
          ? React.createElement("div", { style: { fontSize: 12, color: "#e5534b" } }, "Error: " + error)
          : null
      );
    }

    exports.inject = ["slots"];
    exports.apply = function (ctx) {
      var slots = ctx.get("slots");
      if (slots === undefined) return;

      // 插件配置卡片（settings.plugin.item 的 keyed 注册）
      var dispose = slots.inject("settings.plugin.item", function () {
        return slots.register(
          { name: "settings.plugin.item", key: NS },
          function () { return React.createElement(MemoryCard, null); }
        );
      });
      if (dispose && typeof dispose === "function") {
        ctx.effect(function () { return dispose; });
      }
    };

    return module.exports;
  }
});
