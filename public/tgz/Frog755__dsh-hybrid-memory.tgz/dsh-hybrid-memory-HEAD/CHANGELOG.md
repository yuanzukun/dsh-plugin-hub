# Changelog

本项目的版本变更记录。格式遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)。

## [0.2.0] - 2026-08-26

### 变更（破坏性）

- **移除全部自动注入**：删除 `agent/pre-step` 首步/触发词的 L2 自动召回、`tools/post-execute` 的 skill 附带记忆、L1 的 `systemPrompt.section` 常驻注入——记忆只在模型主动调用 `memory_*` 工具时按需进入上下文，不再出现 `[系统注入·记忆]` 标签，上下文零记忆开销。
- **保留**：`agent/session-start` 日志 handler、`status()` service、HTTP 端点（`GET /__hybrid-memory/status`、`POST /__hybrid-memory/import`）。

### 新增

- **`memory_import_agent_hub`（第 12 个模型工具）**：只导入 Agent Hub 已批准的投影文档——`memory/global/`、`memory/projects/` 与状态为 accepted 的 `memory/decisions/`。新增 `src/agent-hub-source.js`：路径白名单（拒绝绝对路径与 `../` 穿越）、按目录归类 global/project/decision、单文件 1 MiB 上限、内容哈希账本去重；导入走「lock + journal 两阶段」（`.agent-hub-import.lock` / `agent-hub-import-journal.json`），中断后可续跑，`sources: ['agent-hub']` 显式触发，`dryRun` 可预演。
- `memory_import` 的说明同步更新：省略 `sources` 仍只导 Hermes / Claude Code / Codex / WorkBuddy，Agent Hub 需显式传入。

### 测试

- 新增 `tests/agent-hub-source.test.js`（路径校验、分类、哈希与限长）；smoke 测试更新：断言不注册任何 system prompt section、不存在 `agent/pre-step` 与 `tools/post-execute` 处理器、`agent/session-start` 仍存在；`tests/core.test.js` 32 个核心测试覆盖 L1/L2/L3。

## [0.1.0] - 2026-08-22

### 新增

- **L1 常驻快照层**：`MEMORY.md` / `USER.md`，会话组装时冻结注入 system prompt（`systemPrompt.section`），中途写入不改已注入内容（保 prefix cache）；字符上限与模型无关。
- **L2 知识库层**：`facts/` 一事实一文件 + `node:sqlite` FTS5 索引 + 实体抽取；2 字滑窗预分词支持中文检索。
- **L3 导入层**：从 Hermes / Claude Code / Codex / WorkBuddy 导入既有记忆，内容哈希账本去重。
- **11 个模型工具**：`memory_add` / `memory_replace` / `memory_remove` / `memory_remember` / `memory_search` / `memory_browse` / `memory_recall` / `memory_import` / `memory_status` / `memory_review_list` / `memory_review_decide`。
- **记忆强制注入层**：`agent/pre-step` 首步或触发词自动召回注入 L2；`tools/post-execute` 在 skill 工具成功加载后把相关记忆拼进工具结果。
- **审核队列**：`memory_remember(review=true)` 进入 `pending/`，`memory_review_decide` 接受/拒绝/编辑。
- **安全**：威胁扫描（提示注入/外泄/危险指令）、原子写 + 漂移检测（`.bak` 快照）。
- **数据位置**：默认 `D:\Develop\DeepSeek Harness\memory`（D 盘，不落 C 盘），`DSH_HYBRID_MEMORY_ROOT` 可覆盖。
- **HTTP 端点**（可选）：`GET /__hybrid-memory/status`、`POST /__hybrid-memory/import`。
- **单元测试**：20 个测试覆盖 L1/L2/L3 核心逻辑（`tests/core.test.js`）。

[0.1.0]: https://github.com/Frog755/dsh-hybrid-memory/releases/tag/v0.1.0
[0.2.0]: https://github.com/Frog755/dsh-hybrid-memory/releases/tag/v0.2.0
