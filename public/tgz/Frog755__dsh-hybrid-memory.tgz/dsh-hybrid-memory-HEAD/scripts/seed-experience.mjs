// 一次性脚本：把本次会话经验写入 dsh-hybrid-memory 真实数据库
// 位置：D:\Develop\DeepSeek Harness\memory\（D 盘，用户明确要求）
// 用法：node scripts/seed-experience.mjs
// 说明：直接调用 core.js 的 insertFact()，同步 facts/ 文件 + FTS 索引；
//       不走 memory_* 工具（运行中的 DSH 还是无 render 的旧版）。
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { pathToFileURL } from 'node:url'

const DATA_ROOT = 'D:\\Develop\\DeepSeek Harness\\memory'
process.env.DSH_HYBRID_MEMORY_ROOT = DATA_ROOT

const core = await import(pathToFileURL(path.join(process.cwd(), 'src', 'core.js')).href)

// 确保目录存在
core.ensureDir(DATA_ROOT)
core.ensureDir(path.join(DATA_ROOT, 'facts'))
core.ensureDir(path.join(DATA_ROOT, 'pending'))

const entries = [
  {
    title: 'dsh-hybrid-memory 插件架构与数据位置',
    body: 'dsh-hybrid-memory 是自研的 DSH 记忆插件（融合 Hermes 轻量快照 + Noema 可检索知识库）。源码 C:\\Users\\frog\\.dsh\\projects\\dsh-hybrid-memory，挂载于 web profile（package.json link 依赖 + dsh.profile.bundles）。记忆数据必须放 D 盘：D:\\Develop\\DeepSeek Harness\\memory\\（MEMORY.md/USER.md + facts/ + pending/ + index.db + imports.json），可用环境变量 DSH_HYBRID_MEMORY_ROOT 覆盖。三层架构：L1 快照（MEMORY.md/USER.md，按需读取——只在模型主动调用 memory_* 工具时进入上下文，字符上限 agent 4000/user 2000、威胁扫描、原子写+漂移检测）；L2 知识库（facts/ 一事实一文件 + node:sqlite FTS5 + 中文 2 字滑窗预分词 + 实体加权，因为 FTS5 unicode61 不切中文）；L3 导入（Hermes/Claude Code/Codex/WorkBuddy + 内容哈希账本去重）。11 个工具：memory_add/replace/remove/remember/search/browse/recall/import/status/review_list/review_decide。审核默认 auto-accept，review=true 写入 pending/ 接受后移 facts/。',
    tags: ['dsh-hybrid-memory', 'dsh', 'architecture', 'memory'],
  },
  {
    title: 'DSH 静态 client 插件 bundle 踩坑（ModuleLoader）',
    body: 'DSH 静态 client bundle 插件（dsh plugin add 安装）的 client.js 必须用 window.__ModuleLoader__.load({id, factory}) 包装，且 id 必须等于包名（如 @frog755/dsh-hybrid-memory）——宿主按包名找注册，id 不匹配会报 "loaded without registering"。factory(require) 里只能用浏览器端 client-modules 模块表的模块（react 等平台 seed）；require("cordis") 会失败（cordis 是 host/Cordis 侧概念，浏览器没有）。必须 exports.inject = ["slots"] 声明服务注入，apply(ctx) 里用 ctx.get("slots")。package.json 的 dsh.client.inject 保持空数组——不要加 @deepseek-ai/dsh-client-runtime，历史上导致 client 加载卡死。挂载方式：编辑 ~/.dsh/profiles/web/package.json 加 "link:C:/..." 依赖 + bundles 列表，pnpm install，重启 DSH（新插件必须进一次启动树；client.js 内容变化硬刷新即可）。',
    tags: ['dsh', 'plugin', 'client-bundle', 'ModuleLoader'],
  },
  {
    title: 'Hermes 记忆系统机制与本机位置',
    body: 'Hermes agent 的记忆在本机 D:\\Develop\\hermes\\memories\\MEMORY.md（agent 笔记）+ USER.md（用户画像），HERMES_HOME 指向 D 盘而非 ~/.hermes。格式：§ 分隔纯文本条目（无 markdown 标题），文件是 CRLF 换行——导入切分必须用 /\\r?\\n§\\r?\\n/ 并清理段开头残留 §。SOUL.md 是人格文件（本机 ~/.hermes/SOUL.md 含用户自定义 4 条规则：确认准确性/不知则不知/任务交作业/验证提示必须带实质内容）。架构：MemoryManager 统一编排 + 可插拔 MemoryProvider（Honcho/Hindsight/Mem0/OpenViking/RetainDB/Supermemory/Byterover/Holographic，一次一个，config.yaml memory.provider 选择），内置 memory 工具（add/replace/remove，字符上限，冻结快照注入保 prefix cache，威胁扫描+原子写+漂移检测）。Hermes 记忆内容含 VBScript/Python/cron 踩坑、抖音评论 bot、模型评测（agnes-2.5-flash ≈ deepseek-v4-flash 最优，glm-4.6v 最差）、用户偏好。',
    tags: ['hermes', 'memory', 'import'],
  },
  {
    title: 'DSH defineTool 的 output 必须带 render 函数',
    body: '用 @deepseek-ai/dsh-tools 的 defineTool 注册模型工具时，output 必须提供 render(args, value) 函数，返回 [{type:"text", text:String(value)}]。如果只写 output:{schema:{type:"string"}} 不写 render，冒烟测试直接调 execute() 不会暴露问题，但真实 DSH 环境调用工具时报 "output.render failed: userRender is not a function"。教训：工具定义验证必须包含真实渲染路径，不能只测 execute。修复：11 个 memory_* 工具全部补上 render。',
    tags: ['dsh', 'defineTool', 'render', '踩坑'],
  },
  {
    title: 'DSH 记忆插件生态调研结论',
    body: 'GitHub 上 DSH 记忆插件生态成熟，awesome-dsh-plugin 的 Memory 分类下有 91 个记忆插件。头部候选：dsh-mnemon(★141, 三层记忆控制面，可插 9 后端)、dsh-noema(★116, Rust noema-mcp 服务端，记忆存 ~/.agent-memory Markdown，可从 10 个工具导入，含 Hermes/WorkBuddy)、engramory(★165, 一事实一文件纯 Markdown 跨 agent 共享)、dsh-memento(★59, 审批门+可审计)、dsh-mneme(★30, 离线语义搜索)。最终决策：自研 dsh-hybrid-memory 融合 Hermes 轻量快照 + Noema 可检索知识库，因为 Hermes 省 token 保 prefix cache 但不可检索，Noema 可检索可导入但需要 Rust 服务端。',
    tags: ['dsh', 'memory', '调研', 'noema', 'mnemon'],
  },
  {
    title: '用户青蛙的偏好（2026-08-21 会话）',
    body: '用户昵称青蛙。科技/工程类学生，参加智能车比赛。中文沟通、直接务实。使用多 agent 生态：Claude/Hermes/Pi/Codex/WorkBuddy/DSH/Gemini/Trae，各 agent 的记忆散落各处（Hermes 在 D:\\Develop\\hermes\\memories\\，Claude 在 ~/.claude，WorkBuddy 在 ~/.codebuddy 等）。偏好：本地优先、免费方案（白嫖优先）、记忆数据绝不放 C 盘（放 D:\\Develop\\DeepSeek Harness\\memory）。agent-diary 只是总结归档工具，不是 agent 记忆库。',
    tags: ['user', 'preference', '青蛙'],
  },
]

let inserted = 0
const existing = core.listFacts(DATA_ROOT, 'active', 500)
// 按标题去重：已存在的标题跳过（前 3 条已通过 memory_remember 实际写入）
const existingTitles = new Set(existing.map((f) => f.title))

for (const e of entries) {
  if (existingTitles.has(e.title)) {
    console.log(`skip (title exists): ${e.title}`)
    continue
  }
  const slug = core.slugify(e.title).slice(0, 24)
  const id = `fact-${core.nowStamp()}-${slug}`
  core.insertFact(DATA_ROOT, {
    id,
    title: e.title,
    body: e.body,
    entities: core.extractEntities(`${e.title} ${e.body}`),
    tags: e.tags,
    status: 'active',
  })
  inserted++
  console.log(`inserted: ${id} | ${e.title}`)
}

// 验证检索
const checks = [
  ['dsh-hybrid-memory', '插件'],
  ['ModuleLoader', 'client bundle'],
  ['Hermes', '记忆'],
  ['render', 'defineTool'],
]
for (const [q] of checks) {
  const hits = core.searchFacts(DATA_ROOT, q, { limit: 3 })
  console.log(`search "${q}" → ${hits.length} hits: ${hits.map((h) => h.title).join(' / ') || '(none)'}`)
}

console.log(`\n=== SEED DONE: ${inserted} inserted, total facts: ${core.listFacts(DATA_ROOT, 'active', 500).length} ===`)
process.exit(0)
