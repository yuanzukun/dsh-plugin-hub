// Hermes 真实记忆导入验证（可选运行）：
//   真实读取 D:\Develop\hermes\memories\MEMORY.md / USER.md（§ 分隔格式），
//   写入【临时】数据根（不碰 D 盘真实数据），验证切分/导入/检索。
// 运行：node tests/import.hermes.mjs
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { pathToFileURL } from 'node:url'

const PROJ = 'C:\\Users\\frog\\.dsh\\projects\\dsh-hybrid-memory'
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-hybrid-memory-import-'))
process.env.DSH_HYBRID_MEMORY_ROOT = TMP

const mod = await import(pathToFileURL(path.join(PROJ, 'src', 'index.js')).href)

const tools = []
const ctx = {
  get: () => undefined,
  inject: () => () => {},
  on: () => () => {},
  effect: () => () => {},
  tools: { register: (d) => { tools.push(d); return () => {} } },
  systemPrompt: { section: () => () => {} },
}
mod.apply(ctx)

const importTool = tools.find((t) => t.name === 'memory_import')
const res = JSON.parse(await importTool.execute({ sources: ['hermes'] }))
console.log('=== Hermes import (temp root: ' + TMP + ') ===')
console.log('imported:', res.imported.length, 'sections · skipped:', res.skippedCount, '· total:', res.totalSections)
for (const i of res.imported) console.log('  -', i.source + ' | ' + i.title.slice(0, 56))

// 检索验证
const searchTool = tools.find((t) => t.name === 'memory_search')
const s1 = JSON.parse(await searchTool.execute({ query: '抖音评论 bot' }))
console.log('--- search 抖音评论 bot →', s1.count, 'hits')
const s2 = JSON.parse(await searchTool.execute({ query: '青蛙' }))
console.log('--- search 青蛙 →', s2.count, 'hits')

// 断言
if (res.imported.length < 5) {
  console.error('✗ expected at least 5 Hermes sections imported')
  process.exit(1)
}
if (s1.count < 1) {
  console.error('✗ search 抖音评论 bot should hit')
  process.exit(1)
}
console.log('\n=== HERMES IMPORT TEST PASSED ===')
process.exit(0)
