// 离线冒烟测试：用 mock ctx 调 apply，验证插件初始化不崩溃、工具/提示注册正确。
// 运行：node tests/smoke.test.js（独立脚本，非 node --test）
import fs from 'node:fs'
import path from 'node:path'
import os from 'node:os'
import { createRequire } from 'node:module'

const require = createRequire(import.meta.url)

// 指向测试数据根
const TMP = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-hybrid-memory-smoke-'))
process.env.DSH_HYBRID_MEMORY_ROOT = TMP

const mod = await import('../src/index.js')

// --- mock ctx ---
const registeredTools = []
const sections = []
const eventHandlers = {}
const effects = []

const ctx = {
  get(name) {
    if (name === 'webServer') return undefined
    return undefined
  },
  inject(deps, fn) {
    // 只模拟 webServer 出现的情况：跳过（optional）
    return () => {}
  },
  on(name, handler) {
    eventHandlers[name] = handler
    return () => {}
  },
  effect(fn) {
    effects.push(fn)
    return () => {}
  },
  tools: {
    register(def) {
      registeredTools.push(def)
      return () => {}
    },
  },
}

// --- run apply ---
let result
try {
  result = mod.apply(ctx)
  console.log('✓ apply() ran without throwing')
} catch (e) {
  console.error('✗ apply() threw:', e)
  process.exit(1)
}

// --- verify tools ---
const toolNames = registeredTools.map((t) => t.name)
const expected = [
  'memory_add', 'memory_replace', 'memory_remove',
  'memory_remember', 'memory_search', 'memory_browse', 'memory_recall',
  'memory_import', 'memory_status', 'memory_review_list', 'memory_review_decide',
]
const missing = expected.filter((n) => !toolNames.includes(n))
if (missing.length) {
  console.error('✗ missing tools:', missing.join(', '))
  process.exit(1)
}
console.log(`✓ registered ${toolNames.length} tools: ${toolNames.join(', ')}`)

// --- verify NO prompt section (v0.2.0 移除 L1 常驻注入) ---
if (sections.length !== 0) {
  console.error('✗ unexpected prompt section registered:', JSON.stringify(sections))
  process.exit(1)
}
console.log('✓ no system prompt section registered (on-demand memory only)')

// --- verify events: 注入 handler 已移除，仅保留 session-start 日志 ---
if (eventHandlers['agent/pre-step']) {
  console.error('✗ agent/pre-step handler should be removed (v0.2.0)')
  process.exit(1)
}
if (eventHandlers['tools/post-execute']) {
  console.error('✗ tools/post-execute handler should be removed (v0.2.0)')
  process.exit(1)
}
if (!eventHandlers['agent/session-start']) {
  console.error('✗ agent/session-start handler missing')
  process.exit(1)
}
console.log('✓ injected handlers removed; session-start log handler kept')

// --- verify data dirs created ---
for (const f of ['MEMORY.md', 'USER.md', 'facts', 'pending']) {
  if (!fs.existsSync(path.join(TMP, f))) {
    console.error(`✗ data dir/file missing: ${f}`)
    process.exit(1)
  }
}
console.log('✓ data dirs created under ' + TMP)

// --- verify status() ---
const st = result.status()
if (typeof st.l2.facts !== 'number') {
  console.error('✗ status() shape wrong')
  process.exit(1)
}
console.log('✓ status() returns', JSON.stringify(st))

// --- exercise a tool execute ---
const addTool = registeredTools.find((t) => t.name === 'memory_add')
const addRes = JSON.parse(await addTool.execute({ kind: 'memory', title: '冒烟测试', content: '插件能正常工作' }))
if (!addRes.ok) {
  console.error('✗ memory_add failed:', JSON.stringify(addRes))
  process.exit(1)
}
console.log('✓ memory_add execute works')

const searchTool = registeredTools.find((t) => t.name === 'memory_search')
const searchRes = JSON.parse(await searchTool.execute({ query: '冒烟测试' }))
if (!searchRes.ok || searchRes.count < 1) {
  console.error('✗ memory_search failed:', JSON.stringify(searchRes))
  process.exit(1)
}
console.log(`✓ memory_search found ${searchRes.count} result(s)`)

const recallTool = registeredTools.find((t) => t.name === 'memory_recall')
const recallText = await recallTool.execute({ query: '冒烟' })
if (!recallText.includes('冒烟测试')) {
  console.error('✗ memory_recall failed to include fact')
  process.exit(1)
}
console.log('✓ memory_recall works')

// --- memory_remember → memory_recall fact_id CCR 往返（压缩锚点可取回原文） ---
const rememberTool = registeredTools.find((t) => t.name === 'memory_remember')
const rememberRes = JSON.parse(await rememberTool.execute({ title: '冒烟测试', content: '冒烟测试知识正文，用于 CCR 按 id 取回验证。' }))
if (!rememberRes.id) {
  console.error('✗ memory_remember failed to return id:', JSON.stringify(rememberRes))
  process.exit(1)
}
console.log(`✓ memory_remember created fact ${rememberRes.id}`)

const recallByFactTool = registeredTools.find((t) => t.name === 'memory_recall')
const byId = JSON.parse(await recallByFactTool.execute({ fact_id: rememberRes.id }))
if (!byId.ok || !byId.fact.body.includes('冒烟测试知识正文')) {
  console.error('✗ memory_recall fact_id failed:', JSON.stringify(byId))
  process.exit(1)
}
console.log('✓ memory_recall fact_id returns full original body (CCR)')

const bothArgs = JSON.parse(await recallByFactTool.execute({ query: '无关词', fact_id: rememberRes.id }))
if (!bothArgs.ok || bothArgs.fact.id !== rememberRes.id) {
  console.error('✗ memory_recall should prefer fact_id over query:', JSON.stringify(bothArgs))
  process.exit(1)
}
console.log('✓ memory_recall mutex prefers fact_id')

const missingId = JSON.parse(await recallByFactTool.execute({ fact_id: 'no-such-fact-id' }))
if (missingId.ok !== false) {
  console.error('✗ memory_recall should report missing id:', JSON.stringify(missingId))
  process.exit(1)
}
console.log('✓ memory_recall missing fact_id reports ok:false')

// --- 查询路径应带 (id: ...) 锚点（压缩注入的 CCR 可逆性由锚点兜底） ---
const recallAnchor = await recallByFactTool.execute({ query: '冒烟' })
if (!recallAnchor.includes('(id: ') || !recallAnchor.includes(rememberRes.id)) {
  console.error('✗ memory_recall query path lacks id anchor:', recallAnchor.slice(0, 200))
  process.exit(1)
}
console.log('✓ memory_recall query path carries (id: ...) anchors')

const statusTool = registeredTools.find((t) => t.name === 'memory_status')
const statusRes = JSON.parse(await statusTool.execute({}))
if (!statusRes.ok) {
  console.error('✗ memory_status failed')
  process.exit(1)
}
console.log('✓ memory_status works: ' + JSON.stringify(statusRes.l2))

// --- import tool presence (不碰真实 ~/.hermes，避免污染用户数据) ---
const importTool = registeredTools.find((t) => t.name === 'memory_import')
if (!importTool) {
  console.error('✗ memory_import not registered')
  process.exit(1)
}
console.log('✓ memory_import tool registered (real import skipped to avoid touching ~/.hermes)')

console.log('\n=== SMOKE TEST PASSED ===')
process.exit(0)
