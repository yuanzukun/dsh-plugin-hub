# dsh-file-shield 设计

日期：2026-09-19
状态：已获用户批准，待用户复核本文档
最后修订：2026-10-10（迁移到 dsh 0.2.0-rc.2 的配置面，见 §11.5）

## 1. 目标

让使用者把某些文件或目录对 agent **完全屏蔽**：

- 模型通过读取类工具（`read`、`read_image`、`grep`、`glob`、`str_replace_editor`）触达这些路径时，调用在派发前被拒绝；
- 同路径的写入与编辑（`write`、`edit`、`str_replace_editor` 的修改命令）一并拒绝；
- 搜索类工具即使整目录搜索，也不能把被屏蔽文件的内容或路径带回对话；
- 使用者可以在 GUI 里**手动点选**文件或目录来增删规则，不必手写配置。

屏蔽规则同时支持部署默认（`cordis.patch.yml` 里的 glob）与用户层（GUI 选择的路径）。

## 2. 为什么是这些接缝

| 能力 | 选用接缝 | 依据 |
|---|---|---|
| 拒绝模型工具调用 | `tools/pre-execute` 瀑布 | registry 自己落实 `deny`，工具体不执行，包装/旁路无法绕过（`packages/core/tools/src/index.ts:137-146`、`:1493-1503`） |
| 过滤搜索结果 | `tools/post-execute` 携带结构化 `value` | registry 用工具自己的 `output.render` 重新渲染，因此不必解析模型可见文本（`packages/core/tools/src/index.ts:1773-1784`） |
| 路径规范化 | `ctx.fs.resolve()` | 得到 canonical realpath，`..` 与符号链接别名无法逃逸（`packages/fs/fs/src/index.ts:107-116`） |
| 规则持久化与实时生效 | 行 config 的 volatile `deny`（host）+ `ctx.configForms.get('file-shield')`（client） | 只有 volatile 字段能由 Plugins 页面编辑，且 loader 用「写引用 + `loader/volatile-update`」提交，不重启插件 |
| 插件页面 | `plugins.bundle.config` 键控槽，键 = 包名 | 渲染在 Plugins 页该插件卡片自己的页面上（`packages/client/ui-plugin-manager/src/client/slot-contract.ts:33-38`） |
| 选目录 | `ctx.uiWorkspace.pickDirectory()` | 直接返回所选绝对路径，官方选择器（`packages/client/ui-workspace/src/client/navigation.ts:64-66`） |
| 选文件 | 系统文件对话框 + preload 真实路径桥 | `pickDirectory()` 只返回目录；`<input type="file">` 只给 `File`，靠桌面壳的 `__DSH_HOST_PATHS__.pathFor` 换回路径 |

被否决的方案：

- **包装 `ctx.fs` 服务**：`ctx.fs` 由 `fs-local`/`fs-sandbox` 提供，二次 provide 不是文档化扩展点，会干扰 `sandboxMode` 与 observation-policy 的装配，且版本脆弱。
- **改 sandbox/permission-presets**：现有 sandbox 只按 workspace 限制写，没有读黑名单；改核心包违背"插件而非改动 loop"。
- **`dsh.client.external` 请求 `api-remotes/client` 直接调 `workspaceFiles.list`**：该字段按仓库约定只允许基础设施/传输/生成装配使用，特征插件请求它是越界。

## 3. 包形态

独立包 `/Users/yazzyk/workspace/dsh-file-shield`，host + client 双面，安装方式为 `link:`（本地目录）或 npm/Git。

```
dsh-file-shield/
  package.json          # dsh.bundle.patch + dsh.client
  cordis.patch.yml      # 插入本插件行（不预设规则）
  README.md             # 使用说明与已知边界
  docs/design.md        # 本文档
  build.mjs             # esbuild 双面构建
  tsconfig.json         # host 源检查
  tsconfig.client.json  # client 源检查（TSX）
  src/host/
    index.js            # apply / inject / name，装配各部件
    config.js           # 配置校验与默认值
    rules.js            # 规则编译与 glob 匹配
    targets.js          # 工具 -> 路径参数表 / 命令参数表
    commands.js         # 从 shell 命令文本提取候选路径
    guard.js            # tools/pre-execute 决策
    results.js          # tools/post-execute 结果过滤
    tiers.js / tier-store.js / tier-routes.js   # 三级规则的状态、持久化、路由
    guidance.js         # 可选系统提示段
  src/client/
    index.tsx           # 槽注册
    Page.tsx            # 规则列表 + 保存/重置
    LevelsPanel.tsx     # 侧边栏面板：三级规则
    SessionShield.tsx   # 会话的「屏蔽」标签页
    pick.ts             # 系统文件对话框 + 真实路径桥探测
    locales.ts          # 本地字典
    page.css            # 样式（构建期内联）
  lib/
    index.js            # host 产物（构建生成，提交）
    client.js           # client 产物（构建生成，提交）
  tests/
    *.test.js           # node --test
```

Host 是纯 ESM JavaScript（JSDoc 类型 + `node --test`），client 是 TSX 经 esbuild 打成单文件 CJS 工厂包。两半都由 esbuild 产出到 `lib/`，仓库里不出现手写的构建产物。

## 4. 配置

`cordis.patch.yml` 插入一行，**不预设规则**（新装即惰性）：

```yaml
- insert:
    - id: file-shield
      name: dsh-file-shield
```

用户在 profile 的 `cordis.patch.yml` 覆盖该行 `config`（整段替换）：

```yaml
- insert:
    - id: file-shield
      name: dsh-file-shield
      config:
        deny:
          - '**/.env'
          - '**/.env.*'
          - '**/*.pem'
          - '~/.dsh/.credentials.yaml'
        matchCase: false
        guidance: true
        extraPathArgs:
          some_reader_tool:
            - target
```

| 字段 | 默认 | 含义 |
|---|---|---|
| `deny` | `[]` | 规则列表：glob 或精确路径；相对规则锚定会话工作区 |
| `matchCase` | `false` | 是否区分大小写；默认失败关闭方向（macOS/Windows 大小写不敏感文件系统） |
| `guidance` | `true` | 是否注入一条系统提示，说明被屏蔽路径是策略而非错误 |
| `extraPathArgs` | `{}` | 其它插件新增的读文件工具：工具名 -> 参数名数组，合并进内置表 |

空 `deny` 是**合法**状态而非误配置：规则的主要所有者是 GUI 写入的设置层，新装插件必须可加载且不自作主张。加载时记一条 info。

## 5. 规则语义

- 规则字符串含 glob 元字符（`*?[]{}`）时按 glob 编译，否则按精确路径比较。
- 相对规则锚定到会话工作区 `exec.agent.session.header.cwd`；无 agent 时退回 provider 默认（即不传 `cwd`，由 `ctx.fs.resolve` 自行决定）。
- 每个目标按**两种拼法**参与匹配：`ctx.fs.resolve(候选路径, { cwd, signal })` 返回的 `FsTarget` 同时给出 `targetKey`（规范化身份，符号链接已解析）与 `displayPath`（调用方写下的绝对路径，链接保持原样），两者都拿来匹配。原因：macOS 的 `/tmp`、`/var` 是指向 `/private/...` 的符号链接，规则可能写成任一种，而系统对话框给出的正是 display 拼法；只比规范化身份会让选出的 `/tmp/...` 静默不生效。别名的防护不受影响——针对真实路径写的规则仍经 `targetKey` 命中。
- 内置 glob 编译支持 `**`（可匹配零层目录）、`*`、`?`、`[...]`；反斜杠转义下一个字符，因此路径中真实存在的 `*` 或 `[` 可以写成 `\*`、`\[`。自实现，不引第三方依赖。
- 空串与纯空白规则被忽略。
- `~` 前缀在规则中展开为宿主 home（仅限规则侧，模型输入不做展开）。

## 6. 拦截

### 6.1 派发前拒绝

`tools/pre-execute` 监听器，两条检查路径。

**路径参数**：按内置表取出该工具的参数路径，逐个规范化并匹配。

| 工具 | 路径参数 |
|---|---|
| `read` / `read_image` / `write` / `edit` | `file_path` |
| `grep` / `glob` | `path` |
| `str_replace_editor` | `path` |
| `bash` / `pwsh` | `workdir` |
| 其它 | `extraPathArgs` 登记项 |

**命令参数**：`bash` / `pwsh` 的 `command`（其它工具可用 `extraCommandArgs` 登记）。shell 不经过 `ctx.fs`，框架也没有暴露 shell/subprocess 事件，`tools/pre-execute` 是唯一能拦住 `cat` 一类读取的位置，因此这里对命令文本做静态提取（`src/host/commands.js`）：按 shell 元字符切词、跟随 `cd`、剥引号与 `NAME=` 前缀、展开 `~`，把除命令名之外的每个词解析成绝对路径，用同一套匹配器比对；不含 glob 元字符的**绝对**规则还直接在命令原文里做字面查找，使带空格的路径无需依赖切词。限定绝对规则是因为相对规则可能只是一个短词（`data`），在命令原文里做子串匹配会误伤 `grep data file.txt`。

静态提取有明确上限：命令文本不等于命令语义，变量拼接、`base64 -d`、`$(...)` 二次求值都能绕开。它拦的是模型自然写出的形态，不是恶意 shell；真正的隔离需要操作系统级的读取限制，那属于宿主能力。

命中即返回：

```
{ kind: 'deny',
  reason: 'Access to "<displayPath>" is blocked by deployment policy (rule "<规则>").',
  info: { name: 'FileAccessBlockedError', code: 'FS_PERMISSION_DENIED', reason: '<规则>' } }
```

registry 会把它物化成 `Error: <reason>` 的失败结果，并保留结构化 `code`。用 `FS_PERMISSION_DENIED` 而非 `FS_SANDBOX_DENIED`，避免触发"用更宽沙箱重试"的语义。

参数中不含路径、或路径无法规范化（例如语法非法）时**不拦截**：这类调用会由工具自身按原有方式失败，策略层不制造新的失败面。

### 6.2 结果过滤

`tools/post-execute` 监听器，处理两类结果。

**结构化搜索结果**，只处理 `grep` 与 `glob`：

- `grep`：`value.matches[].path`（相对会话工作区）逐个规范化并匹配，命中项剔除；
- `glob`：`value.paths[]` 同样处理。

返回 `{ kind: 'accept', value: <过滤后的值> }`，由 registry 调用工具自己的 `output.render` 重新渲染，因此不依赖渲染文本格式，持久化的 `presentationMeta` 也随之一致。

**命令输出**：`bash` / `pwsh` 的 `value.stdout.text` 与 `value.stderr.text` 逐行剔除。递归读取（`grep -rn` / `rg` / `find`）会把被屏蔽文件的**内容**直接打到底流上，而它同样不经过 `ctx.fs`，所以只能在输出侧按行处理：一行里出现某条规则的静态前缀（第一个 glob 元字符之前、截到最后一个 `/` 的部分）即剔除。这一层覆盖 `path:line:content` 与纯路径列表两种形态；不带文件名的输出（`grep -h`、`awk`、`sed -n`）没有可识别的路径，认不出来。

结果被完全过滤时不报错，模型看到"无匹配"或空输出。这与 ripgrep 静默跳过 `.gitignore` 条目的既有行为一致，且不泄露被屏蔽文件的存在。过滤按每次调用缓存规范化结果，避免逐条 realpath 的重复开销。

### 6.3 系统提示

`guidance: true` 时注册一段提示（`order: 50`、`interpolate: false`）：说明部分路径受部署策略保护、被拒绝是策略而非故障、不要改用 shell 或其它工具绕过、也不要猜测被隐藏的内容。提示中不罗列具体路径。

## 7. 选目录与选文件

两条选择路径，都不由本插件自己画对话框：

| 选择 | 走哪条 | 依据 |
|---|---|---|
| 目录 | `ctx.uiWorkspace.pickDirectory()` | dsh 的 directory-picker 接缝；桌面壳开本机对话框，普通 Web 由 Host 端后端应答 |
| 文件 | `<input type="file">` + preload 的 `__DSH_HOST_PATHS__.pathFor(file)` | 浏览器只给 `File` 对象、不给路径；`electron.webUtils.getPathForFile` 才有真实路径，dsh 自己的输入框接文件引用走的同一条桥 |

**没有应用内浏览器**：早先的版本自带一个只读目录对话框（`GET /file-shield/browse` + `Browser.tsx`），现已整体移除。理由是"同一个动作只该有一个界面"——两个选择器并存时用户要先猜"这次会弹哪一个"，而系统对话框在桌面里已经够用。文件路径的桥不在时（纯浏览器），"选择文件…"按钮不出现，而不是换一个降级界面顶上。

移除也缩小了暴露面：插件现在只挂 `/file-shield/state` 与 `/file-shield/session` 两条路由，不再有任何列目录的 HTTP 面。

Host 侧注入 `webServer` **与** `connection` 为**可选**：两者都在时挂这两条路由，缺任一时不挂（宁可让面板不可用，也不开无认证入口），守卫本身不受影响。

## 8. GUI 页面

Rule 有两个来源（见 §13）。本节先记原有的 Plugins 页面，再记三级规则的面板。

### 8.1 Plugins 页面（部署默认那一层）

Client 半注册进 `plugins.bundle.config`，`key = 'dsh-file-shield'`：

- `view: 'summary'`：一行，形如"已屏蔽 N 条规则"。
- `view: 'page'`：
  - 规则列表：每条显示路径与删除按钮，glob 规则额外带一个标签（客户端无法可靠区分「文件」与「目录」，所以不做这个区分）；
  - **添加目录**：`uiWorkspace.pickDirectory()`；
  - **添加文件**：打开系统文件对话框（见 §7）；
  - **手动输入**：一个文本框用于粘贴路径或 glob；
  - **保存**：`form.set('deny', [...])`；
  - **恢复部署默认**：`form.unset('deny')`。
  - 显示当前是否已覆盖部署默认（`user` 层存在即视为覆盖），以及不可写状态（`writable === false` 或 `mode === 'memory'`）下的只读提示。

`inject = ['slots', 'locale']`；`configForms` 与 `uiWorkspace` 都用 `ctx.get(...)` 在渲染时机会性读取，而不是写进 `inject`——宿主没装载 settings 或 workspace UI 时插件仍须激活，页面只是显示「不可用」或隐藏目录选择按钮。`configForms` 的命名空间是 profile 条目 id，也就是本 bundle patch 声明的 `file-shield`（官方插件同样硬编码自己的行 id）。

文案全部来自本包字典；样式为普通 CSS，构建期内联成字符串，插件 fiber 内一次性注入 `<style>`，类名统一前缀 `dfs-`。

### 8.2 三级规则的面板与会话窗口

两处注册，都是官方已占位的槽：

| 位置 | 槽 | 注册形状 |
|---|---|---|
| 侧边栏面板列表 + 主区页面 | `sidebar.panellist` + `main` | 两处的 id 与 key 都是 `file-shield`；面板行图标 `IconShieldOutlineRegular` |
| 会话的标签页 | `conversation.view` | 与「对话」（chat, order 0）、「轨迹」（trajectory, order 10）同级；本节注册 order 20。`inject: (sessionId) => ({ sessionId })` |

会话的「屏蔽」标签页**默认锚在当前会话上**，所以那里只管会话级规则；全局与项目级在侧边栏面板里，两处共用同一份状态与同一个保存路径。分开的理由不是权限，是心流：改会话级规则时人不该还要在面板里再挑一次"哪个会话"。

为什么是标签页而不是会话头部的图标按钮：会话级规则是"这一整段会话怎么被对待"，与对话、轨迹属于同一个层级；用户找它的心智位置就在那排标签里，而不是某个需要先发现的按钮。标签页还顺带解决了空间——规则列表与保存结论都需要高度。

面板的数据面是三条插件路由（§7 同款信任围栏，缺 `connection` 时整组不挂载）：

- `GET /file-shield/state` 读三级状态；
- `POST /file-shield/state` 写某一级（`scope: global | project | session`，空列表等于删条目）；
- `GET /file-shield/session?session=<id>` 把会话 id 换成工作区绝对路径——项目级的键只能这么补，浏览器端只拿得到会话 id。

被否决的方案：

- **把三级规则塞进 settings 命名空间**：命名空间是"一个插件的配置项"，而这里的键是项目路径与会话 id，是随会话增删的**数据**。塞进去会让 Plugins 页面渲染出几十个会话 id，也会让每次会话开合写一次用户配置。
- **把会话级规则做成会话头部的图标按钮**：第一版就是这么做的，但它要用户先发现一个没有文字的图标，而那排标签才是"这一整段会话"的层级。
- **给会话标签页单独一套窄版编辑器**：会话级与会话顶级的编辑动作完全一样，两套 UI 只会多一处要维护的差异；共用 `RuleEditor`。

## 9. 构建

`build.mjs` 用 esbuild 产出两半：

- Host：`src/host/index.js` → `lib/index.js`，`format=esm`、`platform=node`，`external: @deepseek-ai/schemastery` + node 内置模块。host 侧运行时只导入这一个 `@deepseek-ai/*` 包（配置 schema 要用它声明 volatile 字段），其余服务类型都是 type-only。
- Client：`src/client/index.tsx` → `lib/client.js`，`format=cjs`、`platform=browser`，external 为平台模块表：`react`、`react/jsx-runtime`、`react-dom`、`react-dom/client`、`@deepseek-ai/cordis`、`@deepseek-ai/dsh-client-store`、`@deepseek-ai/dsh-client-ui-slots`、`@deepseek-ai/dsh-client-ui-primitives`、`@deepseek-ai/dsh-client-ui-dockkit`；banner/footer 包出 `window.__ModuleLoader__.load({ id, factory: (require) => { … return module.exports; } })`；`.css` 以 `text` loader 内联。
- 运行期依赖只有 `@deepseek-ai/schemastery`（真实 dependency）。client 半在运行时不导入任何 `@deepseek-ai/*`：服务类型都是 `import type {}`，编译后擦除，所以插件不依赖加载器如何解析裸标识符。
- 类型来源（`@deepseek-ai/dsh-*` 与 client 侧各包、react 类型）只进 `devDependencies`，版本钉在目标运行时的 `0.2.0-rc.2`（cordis `~4.0.4`），编译后不再需要。
- 构建器是 **esbuild** 而不是官方 preset：`packages/client/tsdown.client.ts` 不是已发布包，且会按 `packages/*/*/package.json` 查找包名、对仓外包名直接抛错，仓外插件无法复用。

产物提交进包，使 `link:` 安装后即可用；`--watch` 供 client HMR 开发。

## 10. 测试与验证

1. **单元测试**（`node --test`，跑源码）：
   - glob 编译：`**` 匹配零层目录、`*`/`?`/字符类、正则元字符转义、大小写开关；
   - 规则锚定与规范化匹配，含 `..`、符号链接别名、`~` 展开；
   - 工具参数表取值：命中/未命中/参数缺失/非法路径不拦；
   - deny 决策的完整字段；
   - `grep`/`glob` 结果过滤，含全部被过滤与空结果；
   - 配置校验：字段类型错误报错、`deny` 省略合法；
   - 三级规则：状态语义、持久化降级、路由错误码、按调用解析、workspace 归属。
2. **真实组合**：全新临时 `DSH_HOME` 建 scratch profile → `dsh plugin --profile <scratch> add link:/Users/yazzyk/workspace/dsh-file-shield` → `--dump-config` 断言插件行出现且 bundle 层正确 → 有可用 key 时跑真实任务读被屏蔽文件，断言模型收到策略拒绝。
3. **安装与 GUI**：装到 `desktop` 与 `web`；用浏览器自动化打开 `http://127.0.0.1:43120`，进入 Plugins 页打开本插件页面，实际点选目录与文件、保存，再让 agent 读取被屏蔽文件并确认被拒。
4. 若 `plugins.bundle.config` 在已发布构建中对第三方 bundle 不渲染，改用 `plugins.row.config`（键 `dsh-file-shield#file-shield`），并同步修订本文档。

## 11. 实现与本文档的偏差

实现完成后记录的实际差异：

1. 浏览应答去掉了 `size` 字段（UI 用不到，省掉每条的 stat）。
2. 规则条目只对 glob 规则打标签：客户端无法可靠判断一个路径是文件还是目录。
3. 构建器换成 esbuild（原因见 §9）。
4. host 半新增 `services.d.ts`，把 `ctx.tools` / `ctx.fs` / `ctx.systemPrompt` / `ctx.webServer` 的声明以 type-only 方式拉进来，使 `tsc` 能对着真实服务契约检查；loader 发出的 `loader/volatile-update` 目前没有官方类型，也在这份声明里按实际负载补上。
5. **2026-10-10：迁移到 dsh 0.2.0-rc.2 的配置面。** 0.1.6 契约里的 `ctx.settings.installSection()`（host）与 `ctx.settingsScope.bind()`（client）在 0.2.0-rc.2 都已移除：settings 现在把「每个 profile 条目的 Config schema」投影成表单，只有 schema 标成 `.volatile()` 的字段可由页面写入。于是规则列表改住行 config 的 `deny`，并标成 volatile；client 用 `ctx.configForms.get('file-shield')` 拿同一条目的表单。loader 对 volatile-only 变更只写引用并发 `loader/volatile-update`，插件在该事件里重建匹配器，因此保存仍然不需要重启。取证（目标运行时 0.2.0-rc.2）：`@deepseek-ai/dsh-settings/lib/index.js` 的 `SettingsForms`（`describe` / `write` / `volatileForm`）、`@deepseek-ai/dsh-client-ui-settings/lib/types/client/config-form.d.ts` 的 `ConfigForms` / `ConfigForm`、`@deepseek-ai/cordis-plugin-loader/lib/index.js` 的 `Entry.update` → `_commitVolatile` → `loader/volatile-update`。

## 12. 已知边界

- **`bash`/`pwsh` 可绕过**：`cat` 之类的 shell 命令不在本插件的拦截面上。这是明确取舍（未采用可误伤且可绕过的命令文本匹配）。
- **其它插件新增的读文件工具不识别**，除非在 `extraPathArgs` 里登记。
- **host 侧 `ctx.fs` 消费者不在拦截面上**：技能加载、`@文件` 引用、附件等绕过工具层的读取不受影响。
- **grep/glob 结果静默剔除**，不给模型"有内容被隐藏"的提示。
- **规则不校验所指向的文件是否存在**：屏蔽先于存在的路径是合理用法。
- 页面只在 Plugins 页出现；若宿主未装载 plugin manager 或未暴露该槽，页面不存在（守卫不受影响）。
## 13. 三级屏蔽（全局 / 项目 / 会话）

日期：2026-11-08（对应 issue #1）

### 13.1 为什么是三级

部署默认（`config.deny`）只能由部署者改，而"哪些文件不该被这个 agent 读"在不同粒度上的答案不一样：`.env` 通配规则是全局的，某个仓库里的行情快照是项目级的，而一次会话里临时打开又不想被读到的东西只属于那次会话。一层规则只能靠不断手工合并来近似这三件事。

**叠加而不是覆盖**：命中的规则取并集。理由是屏蔽只做加法才安全——若高层能覆盖底层，一次手滑就能把部署策略整段关掉。这与"允许列表"正相反：允许列表的直觉是"越具体越优先"，而屏蔽的直觉必须是"越具体只会更严"。

### 13.2 数据放在哪

`$DSH_HOME/state/dsh-file-shield/tiers.json`（默认 `~/.dsh/state/dsh-file-shield/tiers.json`），权限 0600，写入走"临时文件 + rename"（同文件系统内 rename 原子，进程被杀最多留下一个临时文件，不会让状态文件变成半截 JSON）。

```json
{
  "version": 1,
  "global": ["**/.env"],
  "projects": { "/Users/me/work/app": ["**/snapshots/*.csv"] },
  "sessions": { "session-1dd4b518-…": ["notes/draft.md"] }
}
```

- 空列表**不落键**：状态文件不会堆满空壳条目。
- 读失败（坏 JSON、不认识的 version）退回空状态并记一条 warn——一个坏文件不该关掉屏蔽，那等于用一次解析错误换掉整层防护。
- 文件被外部改过（手工编辑或另一个 dsh 进程写入）会被发现：守卫每次调用比对 `mtime:size`，变了就重读。没有这一条，手改不会生效，而使用者会以为规则已经改了。

### 13.3 按调用现算

`src/host/live.js` 在**每次工具调用**时拼出该调用生效的规则：`global` + 工作区命中的 `projects` 条目 + 该会话的 `sessions` 条目，再与部署默认合并。

保存时合并是行不通的：生效范围本身就是调用的一部分——同一个 agent 在不同会话里、或同一会话换了工作区，命中的项目规则不同，保存时合并只能得到"最后一次保存时的那份"。现算的代价是一次数组拼接，而规则总数有上限（每级 500 条、每级 200 个键），所以不需要缓存。

项目键与工作区用**大小写不敏感**的前缀比较：macOS 与 Windows 的默认文件系统就是大小写不敏感，区分大小写的比较会让 `/Users/Me/proj` 记录的项目规则在 `/Users/me/proj` 的会话里静默失效。

**"项目"指的是 dsh 工作区里的一个项目**，不是随手敲的目录。所以：

- 项目层的键是 dsh Workspace 的 `path`（dsh 自己 realpath 规范化过的那一个），面板直接列出 `workspaceRegistry.list()` 让使用者挑，标题用工作区的 `title` 而不是一长串路径；没登记的目录仍可手动加（脚本目录、临时目录）。
- 判定"这个会话属于哪个项目"以 **dsh 的 Workspace 记录**为准（`record.sessionIds` 里有它就归属该工作区），而不是只看 cwd 前缀：workspace 的 path 是规范化的根，而会话的 cwd 可能只是它下面某个子目录。
- dsh 没有这个会话的记录时（脚本创建的会话、或组合里没装 `dsh-workspace`）才退回 cwd 前缀匹配。
- workspace 与 cwd 分属两个项目时**两者都算**，规则累加——屏蔽只做加法。
- `workspaceRegistry` 是机会性服务：没装时 `listWorkspaces` 返回空，面板显示"这个宿主没有工作区列表"，插件其余部分照常工作。

嵌套的项目根会同时命中（`/w` 与 `/w/app` 都在 `/w/app/src` 里），规则累加。

### 13.4 三条路由

见 §8.2。都不缓存（`Cache-Control: no-store`），都先过 `connection.requestRejection()`；没有该围栏时整组不挂载，而不是开放未认证的读写入口。请求体上限 1 MiB，超了直接 413 而不继续读（否则一个坏请求能占住内存）。

错误码是稳定的：`invalid-body` / `invalid-rules` / `invalid-scope` / `not-absolute` / `rule-too-long` / `too-many-rules` / `too-many-entries` / `body-too-large`（413）/ `write-failed`（500）/ `unsupported`（501，组合里没有 agent 注册表时）。

### 13.5 测试

- `tests/tiers.test.js`：纯状态语义——去重去空、上限、空列表删键、不改入参、`isWithin` 的前缀边界与大小写、嵌套项目根。
- `tests/tiers-io.test.js`：状态文件原子写入与坏文件降级、时间戳变化、GET/POST 形状与全部错误码、围栏拒绝、`live.js` 的按调用解析与外部改动热生效。
- `tests/host.test.js`：接线——三级规则与部署默认叠加、项目级只在命中的工作区生效、会话级只影响那个会话、结果过滤同样吃三级规则、缺服务时一条路由都不挂载。
