/**
 * Host loader entry for the trace-graph plugin — runs in the DSH host process.
 *
 * The host half owns the plugin's settings namespace (`trace-graph`: enabled /
 * announceToAgent / defaultLayout) and a system-prompt section
 * announcing the plugin to every agent. The actual UI lives in the browser
 * half (src/client), which reads the same namespace through the settings
 * scope. The browser half reads the official trajectory view snapshot and
 * projects the same records into TraceSpan nodes.
 */

import type { Context } from '@deepseek-ai/cordis'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import z from 'schemastery'
import type {} from '@deepseek-ai/dsh-system-prompt'

/** Order of the announcement section within the tool-guidance band. */
const SECTION_ORDER = 210

export const inject = ['systemPrompt']

/** Model-facing announcement: plugin presence, capabilities, and limits. */
export const TRACE_GRAPH_GUIDANCE = '本机已安装 dsh-trace-graph 插件（DSH Web GUI 的轨迹图谱）：对话页「轨迹图谱」标签读取官方「轨迹」视图的同一份真实轨迹快照，并以 DAG 可视化展示 system/user/context/LLM/tool/partial/running-call 等记录；支持 Dagre 层级布局与 d3-force 力导向布局切换、悬停高亮上下游、点击节点查看输入/输出 JSON。用户提到「轨迹图谱 / Trace 图 / 轨迹可视化」时即指本插件，请据此协作。'

/** Settings namespace of the plugin's configuration — the section the web settings surface edits. */
export const TRACE_GRAPH_SETTINGS_NAMESPACE = settingsNamespace('trace-graph')

/** Plugin config, validated by the same-named schemastery schema. */
export interface Config {
  /** Master switch for the plugin (browser half + host announcement). */
  enabled?: boolean
  /**
   * When true (default), a system-prompt section announces the plugin to every
   * agent. Set false to keep it silent in prompts.
   */
  announceToAgent?: boolean
  /** Initial graph layout: dagre hierarchical (default) or d3-force. */
  defaultLayout?: 'dagre' | 'force'
}

export const Config: z<Config> = z.object({
  enabled: z.boolean().default(true),
  announceToAgent: z.boolean().default(true),
  defaultLayout: z.union([z.const('dagre' as const), z.const('force' as const)]).default('dagre'),
})

/** Schema default, re-read for hand-built test contexts (the loader applies them normally). */
const DEFAULT_ANNOUNCE = true

/**
 * Register the plugin's announcement section, gated on the composition entry's
 * `enabled` / `announceToAgent` (and the live settings value once the web
 * settings surface is served). The section is re-registered whenever the
 * source changes, so a settings edit takes effect without a restart.
 * @param ctx - the plugin context (systemPrompt injected).
 * @param config - resolved plugin config (schema defaults applied by the loader).
 */
export function apply(ctx: Context, config?: Config): void {
  let current: () => Config = () => config ?? {}
  let disposeSection: (() => void) | undefined

  const sync = (): void => {
    if (disposeSection !== undefined) {
      disposeSection()
      disposeSection = undefined
    }
    if ((current().enabled ?? true) === false) return
    if ((current().announceToAgent ?? DEFAULT_ANNOUNCE) === false) return
    disposeSection = ctx.systemPrompt.section({
      name: 'plugin:trace-graph',
      order: SECTION_ORDER,
      text: TRACE_GRAPH_GUIDANCE,
    })
  }

  installSettingsSection(ctx, TRACE_GRAPH_SETTINGS_NAMESPACE, Config, config ?? {}, {
    setSource: (source) => { current = source },
    onChange: sync,
  })

  // Initial registration from the composition entry (covers deployments with
  // no settings service, whose installSettingsSection never fires its hooks).
  sync()
}
