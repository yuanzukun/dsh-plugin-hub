/**
 * Layout algorithms: dagre hierarchical (default, most readable) and d3-force
 * organic. Both emit a uniform id to {x,y} map; applyLayout assembles the
 * ReactFlow nodes/edges with handle sides and entrance-animation delays.
 */
import dagre from '@dagrejs/dagre'
import { forceSimulation, forceLink, forceManyBody, forceCollide, forceX, forceY } from 'd3-force'
import type { SimulationNodeDatum, SimulationLinkDatum } from 'd3-force'
import type { CSSProperties } from 'react'
import type { LayoutMode, TraceEdge, TraceNode } from './types.ts'

/** Assumed node size (matches the .node width in tracegraph.module.css; height conservative). */
export const NODE_WIDTH = 232
export const NODE_HEIGHT = 92

export const FORCE_NODE_GAP = 72
const FORCE_COLLISION_RADIUS = Math.hypot(NODE_WIDTH, NODE_HEIGHT) / 2 + FORCE_NODE_GAP / 2
const FORCE_RECT_COLLISION_PASSES = 260

/** Edge-count threshold above which each edge renders a single particle. */
const EDGE_PARTICLE_LIMIT = 60

export interface LaidOutGraph {
  nodes: TraceNode[]
  edges: TraceEdge[]
}

interface Point {
  x: number
  y: number
}

/** Dagre hierarchical layout (top-to-bottom). Dagre emits center coords; convert to top-left. */
export function dagreLayout(nodes: TraceNode[], edges: TraceEdge[]): Map<string, Point> {
  const g = new dagre.graphlib.Graph()
  g.setGraph({ rankdir: 'TB', nodesep: 56, ranksep: 110, marginx: 32, marginy: 32 })
  g.setDefaultEdgeLabel(() => ({}))
  for (const n of nodes) g.setNode(n.id, { width: NODE_WIDTH, height: NODE_HEIGHT })
  for (const e of edges) g.setEdge(e.source, e.target)
  dagre.layout(g)
  const out = new Map<string, Point>()
  for (const n of nodes) {
    const p = g.node(n.id) as { x: number; y: number } | undefined
    if (p) out.set(n.id, { x: p.x - NODE_WIDTH / 2, y: p.y - NODE_HEIGHT / 2 })
  }
  return out
}

interface ForceNode extends SimulationNodeDatum {
  id: string
}

interface ForceLink extends SimulationLinkDatum<ForceNode> {
  source: string | ForceNode
  target: string | ForceNode
}

function nodeX(node: ForceNode): number {
  return typeof node.x === 'number' && Number.isFinite(node.x) ? node.x : 0
}

function nodeY(node: ForceNode): number {
  return typeof node.y === 'number' && Number.isFinite(node.y) ? node.y : 0
}

function resolveRectCollisions(nodes: ForceNode[]): void {
  for (let pass = 0; pass < FORCE_RECT_COLLISION_PASSES; pass++) {
    let moved = false
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i]
        const b = nodes[j]
        const ax = nodeX(a)
        const ay = nodeY(a)
        const bx = nodeX(b)
        const by = nodeY(b)
        const dx = bx - ax
        const dy = by - ay
        const overlapX = NODE_WIDTH + FORCE_NODE_GAP - Math.abs(dx)
        const overlapY = NODE_HEIGHT + FORCE_NODE_GAP - Math.abs(dy)
        if (overlapX <= 0 || overlapY <= 0) continue
        moved = true
        if (overlapX < overlapY) {
          const direction = dx === 0 ? 1 : Math.sign(dx)
          const shift = overlapX / 2
          a.x = ax - direction * shift
          b.x = bx + direction * shift
        } else {
          const direction = dy === 0 ? 1 : Math.sign(dy)
          const shift = overlapY / 2
          a.y = ay - direction * shift
          b.y = by + direction * shift
        }
      }
    }
    if (!moved) return
  }
}

/**
 * d3-force organic layout with rectangular collision cleanup, then
 * shift-normalized so all nodes land in the non-negative quadrant.
 */
export function forceLayout(nodes: TraceNode[], edges: TraceEdge[]): Map<string, Point> {
  const fNodes: ForceNode[] = nodes.map((n) => ({ id: n.id }))
  const fLinks: ForceLink[] = edges.map((e) => ({ source: e.source, target: e.target }))
  const sim = forceSimulation<ForceNode>(fNodes)
    .force('link', forceLink<ForceNode, ForceLink>(fLinks).id((d) => d.id).distance(330).strength(0.38))
    .force('charge', forceManyBody<ForceNode>().strength(-780).distanceMax(1800))
    .force('collide', forceCollide<ForceNode>().radius(FORCE_COLLISION_RADIUS).strength(1).iterations(3))
    .force('cx', forceX<ForceNode>(0).strength(0.045))
    .force('cy', forceY<ForceNode>(0).strength(0.045))
  sim.stop()
  sim.tick(420)
  resolveRectCollisions(fNodes)

  let minX = Infinity
  let minY = Infinity
  for (const n of fNodes) {
    const x = nodeX(n)
    const y = nodeY(n)
    if (x - NODE_WIDTH / 2 < minX) minX = x - NODE_WIDTH / 2
    if (y - NODE_HEIGHT / 2 < minY) minY = y - NODE_HEIGHT / 2
  }
  const out = new Map<string, Point>()
  for (const n of fNodes) out.set(n.id, { x: nodeX(n) - minX, y: nodeY(n) - minY })
  return out
}

type Side = 'top' | 'bottom' | 'left' | 'right'

const OPPOSITE: Record<Side, Side> = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' }

/** Dominant direction from the center of a toward the center of b. */
function dominantSide(a: Point, b: Point): Side {
  const dx = b.x - a.x
  const dy = b.y - a.y
  if (Math.abs(dx) > Math.abs(dy)) return dx >= 0 ? 'right' : 'left'
  return dy >= 0 ? 'bottom' : 'top'
}

/**
 * Apply the layout mode: position every node, then derive each edge's
 * connection sides (curve bend + Handle ids) and its entrance stagger delay.
 */
export function applyLayout(nodes: TraceNode[], edges: TraceEdge[], mode: LayoutMode): LaidOutGraph {
  const pos = mode === 'dagre' ? dagreLayout(nodes, edges) : forceLayout(nodes, edges)
  const laidNodes = nodes.map((n) => ({ ...n, position: pos.get(n.id) ?? { x: 0, y: 0 } }))
  const byId = new Map(laidNodes.map((n) => [n.id, n]))
  const particleCount = edges.length > EDGE_PARTICLE_LIMIT ? 1 : 3

  const laidEdges = edges.map((e) => {
    const s = byId.get(e.source)
    const t = byId.get(e.target)
    if (!s || !t) return e
    const sc = { x: s.position.x + NODE_WIDTH / 2, y: s.position.y + NODE_HEIGHT / 2 }
    const tc = { x: t.position.x + NODE_WIDTH / 2, y: t.position.y + NODE_HEIGHT / 2 }
    const sp = dominantSide(sc, tc)
    const tp = OPPOSITE[sp]
    const targetDepth = t.data.depth ?? 0
    return {
      ...e,
      sourceHandle: `out-${sp}`,
      targetHandle: `in-${tp}`,
      data: {
        ...e.data,
        kind: e.data?.kind ?? 'other',
        edgeKind: e.data?.edgeKind ?? 'structure',
        isSequence: e.data?.isSequence ?? false,
        traceLabel: e.data?.traceLabel,
        sourcePosition: sp,
        targetPosition: tp,
        particleCount: e.data?.edgeKind === 'sequence' ? 1 : particleCount,
      },
      style: { '--tg-delay': `${targetDepth * 70 + 40}ms` } as CSSProperties,
    }
  })

  return { nodes: laidNodes, edges: laidEdges }
}
