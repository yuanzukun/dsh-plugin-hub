/**
 * span tree to ReactFlow nodes/edges transformation pipeline.
 *
 * Flow: flattenSpans (flatten the nested tree) -> parent chain resolution
 * (explicit parent_span_id wins, nesting falls back) -> root detection with
 * cycle protection -> BFS depths -> node/edge construction.
 */
import { MarkerType } from '@xyflow/react'
import type { TraceEdgeKind, TraceSpan, GraphBundle, TraceNode, TraceEdge, SpanKind } from './types.ts'
import { inferKind, traceLabelMeta } from './classify.ts'
import { spanLatency } from './format.ts'

/** Fixed id of the synthetic root node. */
export const VIRTUAL_ROOT_ID = '__trace_root__'

/** A flattened span with its nesting metadata, used for parent resolution. */
export interface FlatSpan {
  span: TraceSpan
  /** Depth inside the nested tree (meaningful for the nested form only). */
  depth: number
  /** Parent under the nesting form (null for the flat form). */
  nestedParentId: string | null
}

/**
 * Flatten a nested span tree into a pre-order list, recording the nesting
 * parent. Duplicate span_ids keep their first occurrence (defensive dedup).
 */
export function flattenSpans(spans: TraceSpan[]): FlatSpan[] {
  const out: FlatSpan[] = []
  const seen = new Set<string>()
  const stack: Array<{ span: TraceSpan; depth: number; parentId: string | null }> = []
  for (let i = spans.length - 1; i >= 0; i--) {
    stack.push({ span: spans[i], depth: 0, parentId: null })
  }
  while (stack.length) {
    const { span, depth, parentId } = stack.pop()!
    if (seen.has(span.span_id)) continue
    seen.add(span.span_id)
    out.push({ span, depth, nestedParentId: parentId })
    const kids = span.children
    if (kids && kids.length) {
      for (let i = kids.length - 1; i >= 0; i--) {
        stack.push({ span: kids[i], depth: depth + 1, parentId: span.span_id })
      }
    }
  }
  return out
}

export interface BuildGraphOptions {
  /** Label of the synthetic root node added when multiple roots exist. */
  rootLabel?: string
  /** Whether to add a synthetic root for multiple root spans (default true). */
  virtualRoot?: boolean
}

interface ResolvedGraphEdge {
  source: string
  target: string
  edgeKind: TraceEdgeKind
  isSequence: boolean
}

/**
 * Convert a span tree into a node/edge collection plus interaction indexes.
 * Cycles, dangling parent references, and duplicate ids are handled defensively.
 */
export function buildGraph(spans: TraceSpan[], options: BuildGraphOptions = {}): GraphBundle {
  const flat = flattenSpans(spans)
  const byId = new Map<string, TraceSpan>()
  for (const f of flat) byId.set(f.span.span_id, f.span)

  const resolvedEdges = dropCycleEdges(resolveGraphEdges(flat, byId))

  // Relation indexes.
  const parentOf = new Map<string, string>()
  const childrenOf = new Map<string, string[]>()
  for (const f of flat) childrenOf.set(f.span.span_id, [])
  for (const edge of resolvedEdges) {
    if (!parentOf.has(edge.target)) parentOf.set(edge.target, edge.source)
    const list = childrenOf.get(edge.source)
    if (list && !list.includes(edge.target)) list.push(edge.target)
  }

  // Root detection (parentless nodes are roots), then BFS depths.
  const incoming = new Set(resolvedEdges.map(edge => edge.target))
  const roots: string[] = []
  for (const f of flat) {
    const id = f.span.span_id
    if (!incoming.has(id)) roots.push(id)
  }
  const depthOf = new Map<string, number>()
  const visited = new Set<string>()
  const visitFrom = (start: string): void => {
    const queue: Array<[string, number]> = [[start, 0]]
    while (queue.length) {
      const [id, d] = queue.shift()!
      if (visited.has(id)) continue
      visited.add(id)
      depthOf.set(id, d)
      for (const c of childrenOf.get(id) ?? []) queue.push([c, d + 1])
    }
  }
  const finalRoots: string[] = []
  for (const id of roots) {
    finalRoots.push(id)
    visitFrom(id)
  }
  // Cycle members were never visited: promote them to roots so no span is lost.
  for (const f of flat) {
    if (!visited.has(f.span.span_id)) {
      finalRoots.push(f.span.span_id)
      visitFrom(f.span.span_id)
    }
  }
  relaxDepths(depthOf, resolvedEdges, flat.length)

  // Synthetic root for multi-root traces, keeping the hierarchy a single tree.
  const hasVirtualRoot = finalRoots.length > 1 && options.virtualRoot !== false
  const virtualSpan: TraceSpan = {
    span_id: VIRTUAL_ROOT_ID,
    parent_span_id: null,
    span_name: options.rootLabel ?? 'TRACE',
    kind: 'root',
  }
  if (hasVirtualRoot) {
    byId.set(VIRTUAL_ROOT_ID, virtualSpan)
    childrenOf.set(VIRTUAL_ROOT_ID, finalRoots)
    depthOf.set(VIRTUAL_ROOT_ID, 0)
    for (const r of finalRoots) {
      parentOf.set(r, VIRTUAL_ROOT_ID)
      depthOf.set(r, 1)
    }
    for (const r of finalRoots) {
      resolvedEdges.push({
        source: VIRTUAL_ROOT_ID,
        target: r,
        edgeKind: 'structure',
        isSequence: false,
      })
    }
  }

  // Total duration: real time span when present, else the max span latency.
  let minStart = Infinity
  let maxEnd = -Infinity
  for (const { span } of flat) {
    if (typeof span.start_ms === 'number' && span.start_ms < minStart) minStart = span.start_ms
    if (typeof span.end_ms === 'number' && span.end_ms > maxEnd) maxEnd = span.end_ms
  }
  let totalLatency = Number.isFinite(minStart) && Number.isFinite(maxEnd)
    ? Math.max(1, maxEnd - minStart)
    : 0
  if (totalLatency === 0) {
    for (const { span } of flat) totalLatency = Math.max(totalLatency, spanLatency(span))
  }
  totalLatency = Math.max(1, totalLatency)

  // Nodes (flatten order; synthetic root first).
  const nodes: TraceNode[] = []
  const orderedIds: string[] = hasVirtualRoot ? [VIRTUAL_ROOT_ID] : []
  for (const f of flat) orderedIds.push(f.span.span_id)
  for (const id of orderedIds) {
    const span = byId.get(id)!
    const isVirtualRoot = id === VIRTUAL_ROOT_ID
    const kind: SpanKind = isVirtualRoot ? 'root' : inferKind(span)
    nodes.push({
      id,
      type: 'trace',
      position: { x: 0, y: 0 },
      data: {
        span,
        kind,
        depth: depthOf.get(id) ?? 0,
        durationRatio: isVirtualRoot ? 0 : Math.min(1, spanLatency(span) / totalLatency),
        isVirtualRoot,
      },
    })
  }

  // Edges: source to target; skip cycle edges (target not deeper than source).
  const edges: TraceEdge[] = []
  for (const edge of resolvedEdges) {
    const targetSpan = byId.get(edge.target)
    if (targetSpan === undefined) continue
    const kind = inferKind(targetSpan)
    const color = edge.edgeKind === 'sequence'
      ? '#8b95a7'
      : traceLabelMeta(targetSpan.trace_label, kind).color
    edges.push({
      id: `${edge.edgeKind}:${edge.source}->${edge.target}`,
      source: edge.source,
      target: edge.target,
      type: 'trace',
      data: {
        kind,
        edgeKind: edge.edgeKind,
        isSequence: edge.isSequence,
        traceLabel: targetSpan.trace_label,
        sourcePosition: 'bottom',
        targetPosition: 'top',
      },
      markerEnd: {
        type: MarkerType.ArrowClosed,
        color,
        width: 22,
        height: 22,
      },
    })
  }

  return { nodes, edges, byId, parentOf, childrenOf, totalLatency, hasVirtualRoot }
}

function resolveGraphEdges(
  flat: readonly FlatSpan[],
  byId: ReadonlyMap<string, TraceSpan>,
): ResolvedGraphEdge[] {
  const edges: ResolvedGraphEdge[] = []
  const edgeByPair = new Map<string, ResolvedGraphEdge>()

  const addEdge = (source: string, target: string, edgeKind: TraceEdgeKind): void => {
    if (source === target || !byId.has(source) || !byId.has(target)) return
    const key = `${source}\u0000${target}`
    const existing = edgeByPair.get(key)
    if (existing !== undefined) {
      if (edgeKind === 'structure') existing.edgeKind = 'structure'
      if (edgeKind === 'sequence') existing.isSequence = true
      return
    }
    const edge: ResolvedGraphEdge = {
      source,
      target,
      edgeKind,
      isSequence: edgeKind === 'sequence',
    }
    edgeByPair.set(key, edge)
    edges.push(edge)
  }

  for (const f of flat) {
    const links = f.span.links
    if (links !== undefined) {
      for (const link of links) addEdge(link.source_span_id, f.span.span_id, link.kind)
      continue
    }

    const pid = f.span.parent_span_id
    let parent: string | null = null
    if (typeof pid === 'string' && pid && byId.has(pid)) parent = pid
    else if (f.nestedParentId && byId.has(f.nestedParentId)) parent = f.nestedParentId
    if (parent !== null) addEdge(parent, f.span.span_id, 'structure')
  }

  return edges
}

function dropCycleEdges(edges: readonly ResolvedGraphEdge[]): ResolvedGraphEdge[] {
  const accepted: ResolvedGraphEdge[] = []
  const childrenOf = new Map<string, string[]>()
  for (const edge of edges) {
    if (pathExists(childrenOf, edge.target, edge.source)) continue
    accepted.push(edge)
    const children = childrenOf.get(edge.source)
    if (children === undefined) childrenOf.set(edge.source, [edge.target])
    else children.push(edge.target)
  }
  return accepted
}

function pathExists(childrenOf: ReadonlyMap<string, readonly string[]>, source: string, target: string): boolean {
  const stack = [source]
  const seen = new Set<string>()
  while (stack.length > 0) {
    const next = stack.pop()!
    if (next === target) return true
    if (seen.has(next)) continue
    seen.add(next)
    for (const child of childrenOf.get(next) ?? []) stack.push(child)
  }
  return false
}

function relaxDepths(
  depthOf: Map<string, number>,
  edges: readonly ResolvedGraphEdge[],
  nodeCount: number,
): void {
  for (let pass = 0; pass < Math.max(1, nodeCount); pass++) {
    let moved = false
    for (const edge of edges) {
      const sourceDepth = depthOf.get(edge.source)
      if (sourceDepth === undefined) continue
      const nextDepth = sourceDepth + 1
      if (nextDepth <= (depthOf.get(edge.target) ?? -1)) continue
      depthOf.set(edge.target, nextDepth)
      moved = true
    }
    if (!moved) return
  }
}

/** Hover-highlight relation: the related set plus the direct parent/children. */
export interface HoverRelation {
  /** Hovered node + all ancestors + all descendants. */
  related: Set<string>
  /** Direct parent + direct children (highlighted more strongly). */
  direct: Set<string>
}

/** Compute the upstream/downstream relation of the hovered node (cycle-safe). */
export function buildRelations(
  parentOf: Map<string, string>,
  childrenOf: Map<string, string[]>,
  hoveredId: string,
): HoverRelation {
  const related = new Set<string>([hoveredId])
  const direct = new Set<string>()

  const parent = parentOf.get(hoveredId)
  if (parent) direct.add(parent)
  const seenUp = new Set<string>([hoveredId])
  let cur = parent
  while (cur && !seenUp.has(cur)) {
    seenUp.add(cur)
    related.add(cur)
    cur = parentOf.get(cur)
  }

  const kids = childrenOf.get(hoveredId) ?? []
  for (const k of kids) direct.add(k)
  const queue = [...kids]
  while (queue.length) {
    const id = queue.shift()!
    if (related.has(id)) continue
    related.add(id)
    for (const c of childrenOf.get(id) ?? []) queue.push(c)
  }

  return { related, direct }
}
