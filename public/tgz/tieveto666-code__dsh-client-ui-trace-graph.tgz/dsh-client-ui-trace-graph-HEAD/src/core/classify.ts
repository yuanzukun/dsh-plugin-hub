/**
 * Span classification and per-category visual metadata: colors, gradients,
 * glassmorphism parameters, and icons. Pure functions and static tables only;
 * the UI translates `label` through the client locale dictionaries where a
 * locale-aware label is needed (see client/locales.ts kind.* keys).
 *
 * Icon glyphs are chosen from the Unicode ranges the repo's emoji gate allows
 * (no Emoji_Presentation / Emoji-property characters).
 */
import type { SpanKind, TraceSpan } from './types.ts'

/** Visual metadata for one category. */
export interface KindMeta {
  kind: SpanKind
  /** Neutral (zh) label; localized by the client via locale keys. */
  label: string
  /** Icon glyph. */
  icon: string
  /** Primary color. */
  color: string
  /** Gradient secondary color. */
  color2: string
  /** Glass panel gradient start (rgba). */
  glassFrom: string
  /** Glass panel gradient end (rgba). */
  glassTo: string
  /** Border color (rgba). */
  border: string
  /** Outer glow color (rgba). */
  glow: string
}

/** #rrggbb to rgba() string; falls back to a gray-blue on invalid input. */
export function hexToRgba(hex: string, alpha: number): string {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return `rgba(160,170,200,${alpha})`
  const n = parseInt(m[1], 16)
  return `rgba(${(n >> 16) & 255}, ${(n >> 8) & 255}, ${n & 255}, ${alpha})`
}

/** Category palette (root handled separately: more subdued). */
const PALETTE: Record<Exclude<SpanKind, 'root'>, [color: string, color2: string, label: string, icon: string]> = {
  // LLM/model calls: blue-purple gradient.
  llm: ['#8b9dff', '#b07df5', 'LLM', '✦'],
  // Tool executions: orange-amber gradient.
  tool: ['#ffa75e', '#ff7a45', '工具', '⌘'],
  // Loop/iterations: mint green.
  loop: ['#52e6b8', '#2fd4a0', '循环', '↻'],
  // Agent/thinking: cyan.
  agent: ['#4cd7ff', '#2bb8ff', '代理', '◈'],
  other: ['#9aa3b8', '#7d8aa8', '其他', '·'],
}

const cache = new Map<SpanKind, KindMeta>()

/** Category metadata (cached). */
export function kindMeta(kind: SpanKind): KindMeta {
  const hit = cache.get(kind)
  if (hit) return hit
  const [color, color2, label, icon] = kind === 'root'
    ? (['#c9b8ff', '#9f86ff', '根', '◉'] as const)
    : PALETTE[kind]
  const meta: KindMeta = {
    kind,
    label,
    icon,
    color,
    color2,
    glassFrom: hexToRgba(color, 0.16),
    glassTo: hexToRgba(color, 0.03),
    border: hexToRgba(color, 0.45),
    glow: hexToRgba(color, 0.22),
  }
  cache.set(kind, meta)
  return meta
}

const TRACE_LABEL_PALETTE: Record<string, [color: string, color2: string]> = {
  SYSTEM: ['#f59e0b', '#f97316'],
  USER: ['#22c55e', '#14b8a6'],
  CONTEXT: ['#38bdf8', '#3b82f6'],
  ASSISTANT: ['#a78bfa', '#ec4899'],
  TOOL: ['#fb923c', '#f97316'],
  SUBTOOL: ['#facc15', '#fb923c'],
  COMPACTED: ['#34d399', '#10b981'],
  STEERING: ['#f472b6', '#e879f9'],
}

const traceLabelCache = new Map<string, KindMeta>()

function normalizeTraceLabel(label: string | undefined): string | undefined {
  const normalized = label?.trim().toUpperCase()
  return normalized === '' ? undefined : normalized
}

/** Visual metadata keyed by the source trajectory label when one is present. */
export function traceLabelMeta(label: string | undefined, fallbackKind: SpanKind): KindMeta {
  const base = kindMeta(fallbackKind)
  const normalized = normalizeTraceLabel(label)
  if (normalized === undefined) return base
  const labelColors = TRACE_LABEL_PALETTE[normalized]
  if (labelColors === undefined) return base
  const key = `${normalized}\u0000${fallbackKind}`
  const hit = traceLabelCache.get(key)
  if (hit) return hit
  const [color, color2] = labelColors
  const meta: KindMeta = {
    ...base,
    label: normalized,
    color,
    color2,
    glassFrom: hexToRgba(color, 0.18),
    glassTo: hexToRgba(color, 0.04),
    border: hexToRgba(color, 0.52),
    glow: hexToRgba(color, 0.24),
  }
  traceLabelCache.set(key, meta)
  return meta
}

/** Keyword rules for category inference (first match wins, order is priority). */
const KIND_RULES: Array<[RegExp, SpanKind]> = [
  [/agent|代理|subagent|think|思考|规划|plan/i, 'agent'],
  [/llm|model|大模型|gpt|deepseek|chat|completion|生成|总结|分析|评估|审查|建议|方案/i, 'llm'],
  [/loop|循环|迭代|iteration|repeat|while\b|for\b/i, 'loop'],
  [/tool|工具|python|bash|shell|sql|http|api|fetch|git\b|file|执行|运行|查询|保存|渲染|清洗|填充|剔除|测试/i, 'tool'],
]

/**
 * Infer a span's category: an explicit kind wins, then keyword matching on the
 * name, then other. 'root' is never inferred (synthetic roots only).
 */
export function inferKind(span: TraceSpan): SpanKind {
  if (span.kind && span.kind !== 'root') return span.kind
  const name = span.span_name ?? ''
  for (const [re, kind] of KIND_RULES) {
    if (re.test(name)) return kind
  }
  return 'other'
}
