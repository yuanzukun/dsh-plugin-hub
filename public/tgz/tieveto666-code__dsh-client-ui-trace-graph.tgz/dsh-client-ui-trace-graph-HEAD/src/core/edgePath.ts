/**
 * Edge path geometry: a cubic bezier (smooth S curve).
 *
 * The control points are constructed here instead of delegating to ReactFlow's
 * getBezierPath so the particle animation and the drawn path share one
 * geometry (zero parsing, zero drift). The bend direction follows the
 * dominant axis between the source and target nodes.
 */
export interface Point {
  x: number
  y: number
}

export interface EdgeGeometry {
  /** SVG path string (M + C structure). */
  path: string
  p0: Point
  p1: Point
  p2: Point
  p3: Point
}

function clamp(v: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, v))
}

/**
 * Build a smooth cubic bezier from the source point to the target point.
 * @param curvature - control-point reach as a fraction of the axis delta.
 */
export function buildFlowPath(
  sx: number,
  sy: number,
  tx: number,
  ty: number,
  curvature = 0.62,
): EdgeGeometry {
  const dx = tx - sx
  const dy = ty - sy
  const horizontal = Math.abs(dx) > Math.abs(dy)
  let p1: Point
  let p2: Point
  if (horizontal) {
    const c = clamp(Math.abs(dx) * curvature, 40, 260)
    const dir = dx >= 0 ? 1 : -1
    p1 = { x: sx + dir * c, y: sy }
    p2 = { x: tx - dir * c, y: ty }
  } else {
    const c = clamp(Math.abs(dy) * curvature, 40, 260)
    const dir = dy >= 0 ? 1 : -1
    p1 = { x: sx, y: sy + dir * c }
    p2 = { x: tx, y: ty - dir * c }
  }
  const p0 = { x: sx, y: sy }
  const p3 = { x: tx, y: ty }
  return {
    p0,
    p1,
    p2,
    p3,
    path: `M ${sx},${sy} C ${p1.x},${p1.y} ${p2.x},${p2.y} ${tx},${ty}`,
  }
}

/** Point on a cubic bezier (t in [0,1]). */
export function cubicPoint(p0: Point, p1: Point, p2: Point, p3: Point, t: number): Point {
  const u = 1 - t
  const x = u * u * u * p0.x + 3 * u * u * t * p1.x + 3 * u * t * t * p2.x + t * t * t * p3.x
  const y = u * u * u * p0.y + 3 * u * u * t * p1.y + 3 * u * t * t * p2.y + t * t * t * p3.y
  return { x, y }
}
