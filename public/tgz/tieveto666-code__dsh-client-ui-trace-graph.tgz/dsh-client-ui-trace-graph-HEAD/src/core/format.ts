/** Display formatting for numbers and times (presentation only, never logic). */

/** Latency in ms to human-readable text. */
export function fmtLatency(ms: number): string {
  if (!Number.isFinite(ms) || ms < 0) return '—'
  if (ms < 1) return `${(ms * 1000).toFixed(0)} µs`
  if (ms < 1000) return `${ms.toFixed(ms < 10 ? 1 : 0)} ms`
  if (ms < 60_000) return `${(ms / 1000).toFixed(1)} s`
  return `${(ms / 60_000).toFixed(1)} min`
}

/** Token count to short text (>=1000 becomes k). */
export function fmtTokens(n: number): string {
  if (!Number.isFinite(n)) return '—'
  if (n >= 1000) return `${(n / 1000).toFixed(1)}k`
  return String(n)
}

/** Epoch ms to "HH:MM:SS.mmm" (local timezone). */
export function fmtClock(ms: number): string {
  const d = new Date(ms)
  const p = (v: number, len = 2) => String(v).padStart(len, '0')
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}.${p(d.getMilliseconds(), 3)}`
}

/** A span's effective latency: latency_ms first, then end_ms - start_ms, else 0. */
export function spanLatency(span: { latency_ms?: number; start_ms?: number; end_ms?: number }): number {
  if (typeof span.latency_ms === 'number' && span.latency_ms >= 0) return span.latency_ms
  if (typeof span.start_ms === 'number' && typeof span.end_ms === 'number') {
    return Math.max(0, span.end_ms - span.start_ms)
  }
  return 0
}
