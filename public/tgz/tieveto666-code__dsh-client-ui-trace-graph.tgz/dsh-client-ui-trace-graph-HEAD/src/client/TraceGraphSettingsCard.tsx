/**
 * The trace-graph settings card: enablement, agent announcement, default
 * layout. Registers into the `settings.plugin.item` slot the plugin-
 * configuration section renders, bound to the `trace-graph` settings
 * namespace.
 */

import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { SettingsScope, SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client'
import { PluginSettingsCard, BooleanField, ChoiceField } from './PluginSettingsCard.tsx'
import { CardForm, booleanField, choiceField, type CardActions, type CardShell, type FieldState as CardFieldState } from './settings-form.ts'

/** The trace-graph fields this card edits (the namespace's full schema). */
export interface TraceGraphSettings {
  /** Master switch for the plugin. */
  enabled?: boolean
  /** Whether the plugin announces itself in every agent's system prompt. */
  announceToAgent?: boolean
  /** Initial graph layout. */
  defaultLayout?: 'dagre' | 'force'
}

/** What the trace-graph card renders. */
export interface TraceGraphSettingsCardState extends CardShell {
  /** Master switch. */
  enabled: CardFieldState
  /** System-prompt announcement flag. */
  announceToAgent: CardFieldState
  /** Initial graph layout. */
  defaultLayout: CardFieldState
}

/** The registration-side face the card's slot entry injects. */
export interface TraceGraphSettingsCardFace extends CardActions {
  hooks: {
    /** Card snapshot bound by the renderer as useTraceGraphSettingsCard. */
    traceGraphSettingsCard: SnapshotStore<TraceGraphSettingsCardState>
  }
}

/** Bridges the `trace-graph` scope onto the card's staged form. */
export class TraceGraphSettingsCardController {
  private readonly form: CardForm<TraceGraphSettings>
  private readonly store: SnapshotStore<TraceGraphSettingsCardState>

  /** @param scope - the bound settings scope for the `trace-graph` namespace. */
  constructor(scope: SettingsScope<TraceGraphSettings>) {
    this.form = new CardForm(scope, [
      booleanField('enabled'),
      booleanField('announceToAgent'),
      choiceField('defaultLayout', ['dagre', 'force']),
    ])
    this.store = this.form.bind(() => this.projection())
  }

  private projection(): TraceGraphSettingsCardState {
    return {
      ...this.form.shell(),
      enabled: this.form.field('enabled'),
      announceToAgent: this.form.field('announceToAgent'),
      defaultLayout: this.form.field('defaultLayout'),
    }
  }

  /**
   * Build the face the card's slot registration injects.
   * @returns the card's snapshot and its form actions.
   */
  inject(): TraceGraphSettingsCardFace {
    return { hooks: { traceGraphSettingsCard: this.store }, ...this.form.actions() }
  }
}

/** Props the renderer binds for the trace-graph card. */
export type TraceGraphSettingsCardProps =
  PropsRuntime<'settings.plugin.item'>
  & PropsLocale<'trace-graph'>
  & InjectFace<TraceGraphSettingsCardFace>

/**
 * Render the trace-graph card.
 * @param props - locale copy, the card snapshot, and its form actions.
 * @returns the card.
 */
export function TraceGraphSettingsCard(props: TraceGraphSettingsCardProps) {
  const { t } = props
  const state = props.useTraceGraphSettingsCard(snapshot => snapshot)
  const disabled = !state.writable
  const fieldProps = {
    overriddenLabel: t('settings.overridden'),
    resetLabel: t('settings.reset'),
    invalidLabel: t('settings.invalidNumber'),
    disabled,
  }
  return (
    <PluginSettingsCard
      t={t}
      titleKey="settings.title"
      descriptionKey="settings.description"
      state={state}
      onSave={props.save}
      onDiscard={props.discard}
    >
      <BooleanField
        id="settings-trace-graph-enabled"
        label={t('settings.enabled')}
        hint={t('settings.enabledHint')}
        inheritLabel={t('settings.inherit')}
        onLabel={t('settings.on')}
        offLabel={t('settings.off')}
        {...fieldProps}
        {...state.enabled}
        onEdit={(text) => { props.edit('enabled', text) }}
        onReset={() => { props.resetField('enabled') }}
      />
      <BooleanField
        id="settings-trace-graph-announce"
        label={t('settings.announceToAgent')}
        hint={t('settings.announceToAgentHint')}
        inheritLabel={t('settings.inherit')}
        onLabel={t('settings.on')}
        offLabel={t('settings.off')}
        {...fieldProps}
        {...state.announceToAgent}
        onEdit={(text) => { props.edit('announceToAgent', text) }}
        onReset={() => { props.resetField('announceToAgent') }}
      />
      <ChoiceField
        id="settings-trace-graph-default-layout"
        label={t('settings.defaultLayout')}
        hint={t('settings.defaultLayoutHint')}
        inheritLabel={t('settings.inherit')}
        options={[
          { value: 'dagre', label: t('settings.choice.layoutDagre') },
          { value: 'force', label: t('settings.choice.layoutForce') },
        ]}
        {...fieldProps}
        {...state.defaultLayout}
        onEdit={(text) => { props.edit('defaultLayout', text) }}
        onReset={() => { props.resetField('defaultLayout') }}
      />
    </PluginSettingsCard>
  )
}
