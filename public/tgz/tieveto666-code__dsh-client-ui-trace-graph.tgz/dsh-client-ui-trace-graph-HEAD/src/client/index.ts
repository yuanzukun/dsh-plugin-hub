/**
 * Trace-graph client plugin: wires the framework-free controller to the real
 * client runtime and mounts the conversation-view tab plus the official
 * settings card.
 *
 * Failure policy: DOM mounting problems are logged, never thrown — the web
 * shell fails the whole boot when a plugin apply throws, and an external
 * plugin must not take the GUI down.
 */
import type { ClientContext, SettingsScope, SettingsScopeSpec } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
// Type-only: pulls the locale plugin's Context merge (ctx.locale) and its
// LocaleNamespaceMap merge table.
import type {} from '@deepseek-ai/dsh-client-locale/client'
// Type-only: pulls the settings-surface Context merge (ctx.settingsScope).
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import { TraceGraphController } from './controller.ts'
import { claimTraceGraphApply, releaseTraceGraphApply } from './apply-guard.ts'
import { mountView } from './mount-view.tsx'
import { TraceGraphSettingsCard, TraceGraphSettingsCardController, type TraceGraphSettings } from './TraceGraphSettingsCard.tsx'
import { en, zh, type TraceGraphKey } from './locales.ts'
// Side-effect import: injects the plugin-scoped ReactFlow base stylesheet.
import './reactflow-base.module.css'

/** Locale namespace this plugin owns. */
const NS = 'trace-graph'

/** Settings namespace the settings card edits (the Host plugin registers it). */
const TRACE_GRAPH_NS = 'trace-graph'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Trace-graph surface copy. */
    'trace-graph': TraceGraphKey
  }

  interface SlotMap {
    /** One view tab inside the official conversation view strip. */
    'conversation.view': { kind: 'list'; scope: 'session'; owner: TraceGraphConversationViewOwnerProps }
    /** One plugin card inside the official plugin configuration section. */
    'settings.plugin.item': { kind: 'list'; scope: 'root'; owner: TraceGraphSettingsPluginItemOwnerProps }
  }
}

/** Owner share of a conversation view; the runtime supplies session hooks at render time. */
export interface TraceGraphConversationViewOwnerProps {
  /** Marker field: no registration-time owner props are required. */
  children?: never
}

/** Owner share of a plugin card (the section supplies nothing). */
export interface TraceGraphSettingsPluginItemOwnerProps {
  /** Marker field: card owner props are intentionally empty. */
  children?: never
}

declare module '@deepseek-ai/cordis' {
  interface Context {
    /**
     * Optional rc.6 compatibility binder provided by dsh-web-ui-settings;
     * absent when that group plugin is not installed, so callers fall back to
     * the official settings scope.
     */
    webUiSettings?: { bind<S>(spec: SettingsScopeSpec<S>): SettingsScope<S> }
  }
}

/** Required services (fiber inject waiting — the runtime must be up first). */
export const inject = ['slots', 'connection', 'settingsScope', 'locale', 'remote']

/**
 * Mount the trace graph.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  // A duplicated client injection (module factory executed twice in one page
  // lifetime) would otherwise mount a second panel view. First application
  // wins; later calls become no-ops (see apply-guard.ts).
  if (!claimTraceGraphApply()) return

  // Release the claim when this fiber unloads (the loader supports plugin
  // unloads / hot-reloads), so a rebuilt bundle can claim again in the same
  // page instead of being silently dropped.
  ctx.effect(() => releaseTraceGraphApply, 'trace-graph: apply claim')

  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'trace-graph: dictionaries')

  // Plugin configuration card: one staged form over the `trace-graph`
  // settings namespace, contributed to the official plugin configuration page.
  const binder = ctx.get('webUiSettings') ?? ctx.settingsScope
  const settingsScope = binder.bind<TraceGraphSettings>({ namespace: TRACE_GRAPH_NS })
  const settingsCard = new TraceGraphSettingsCardController(settingsScope)
  ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
    name: 'settings.plugin.item',
    id: 'trace-graph',
    order: 30,
    locale: NS,
    inject: () => settingsCard.inject(),
  }, TraceGraphSettingsCard))

  const viewLabel = ctx.locale.bind(NS)

  // The conversation view mounts once the settings scope settles; while the
  // scope is still loading, the composition default is unknown, so nothing
  // mounts yet. Only an unavailable scope (no settings surface served) falls
  // back to the composition default (enabled).
  let uiDisposer: (() => void) | undefined
  const mountUi = (): void => {
    if (uiDisposer !== undefined) return
    const snapshot = settingsScope.getSnapshot()
    const value = snapshot.status === 'ready' ? snapshot.value ?? {} : {}
    const controller = new TraceGraphController({
      defaultLayout: value.defaultLayout,
    })

    const disposers: Array<() => void> = []
    try {
      disposers.push(mountView(ctx, controller, () => viewLabel('view.title')))
    } catch (error) {
      // Surface failures degrade the panel, never the GUI.
      console.error('[dsh-trace-graph] mount failed:', error)
    }

    uiDisposer = () => {
      for (const dispose of disposers.splice(0)) dispose()
      controller.dispose()
      uiDisposer = undefined
    }
  }
  const syncEnabled = (): void => {
    const snapshot = settingsScope.getSnapshot()
    const enabled = snapshot.status === 'ready'
      ? snapshot.value?.enabled ?? true
      : snapshot.status === 'unavailable'
    if (enabled) mountUi()
    else uiDisposer?.()
  }
  settingsScope.subscribe(syncEnabled)
  syncEnabled()
}
