/**
 * Custom node: modern rounded glassmorphism.
 * - Gradient glass surface + colored border + outer glow (category colors via
 *   inline styles from the core palette);
 * - Content: icon/category badge, span name, latency, token usage, and a
 *   duration-share time bar;
 * - Four sides x in/out invisible Handles support edges from any direction;
 * - Entrance animation (fade + springy overshoot scale) lives in CSS and is
 *   staggered by tree depth.
 */
import { memo } from 'react'
import type { CSSProperties } from 'react'
import { Handle, Position } from '@xyflow/react'
import type { NodeProps } from '@xyflow/react'
import type { TraceNode as TraceNodeType } from '../../core/types.ts'
import { kindMeta, traceLabelMeta } from '../../core/classify.ts'
import { fmtLatency, fmtTokens, spanLatency } from '../../core/format.ts'
import { t, kindLabelKey } from '../locales.ts'
import css from '../tracegraph.module.css'

const HANDLES: Array<{ id: string; type: 'source' | 'target'; position: Position }> = [
  { id: 'out-top', type: 'source', position: Position.Top },
  { id: 'out-bottom', type: 'source', position: Position.Bottom },
  { id: 'out-left', type: 'source', position: Position.Left },
  { id: 'out-right', type: 'source', position: Position.Right },
  { id: 'in-top', type: 'target', position: Position.Top },
  { id: 'in-bottom', type: 'target', position: Position.Bottom },
  { id: 'in-left', type: 'target', position: Position.Left },
  { id: 'in-right', type: 'target', position: Position.Right },
]

function TraceNodeComponent({ data, selected }: NodeProps<TraceNodeType>) {
  const { span, kind, depth, durationRatio, isVirtualRoot } = data
  const meta = isVirtualRoot ? kindMeta(kind) : traceLabelMeta(span.trace_label, kind)
  const latency = isVirtualRoot ? 0 : spanLatency(span)
  const status = span.status ?? 'ok'
  const pct = Math.round(durationRatio * 100)
  const label = span.trace_label ?? t(kindLabelKey(kind))

  const style = {
    '--tg-kind': meta.color,
    '--tg-delay': `${depth * 70}ms`,
    background: `linear-gradient(155deg, ${meta.glassFrom}, ${meta.glassTo})`,
    borderColor: meta.border,
    boxShadow: `0 0 14px ${meta.glow}, inset 0 1px 0 rgba(255,255,255,0.06)`,
  } as CSSProperties

  // Synthetic root: dashed capsule, title only.
  if (isVirtualRoot) {
    return (
      <div className={`${css.node} ${css.nodeRoot}`} data-kind={kind} style={style}>
        {HANDLES.filter((h) => h.type === 'source').map((h) => (
          <Handle key={h.id} id={h.id} type={h.type} position={h.position} className={css.handle} isConnectable={false} />
        ))}
        <div className={css.nodeRootLabel}>
          <span className={css.nodeIcon} style={{ color: meta.color, borderColor: meta.border }}>{meta.icon}</span>
          {span.span_name}
        </div>
      </div>
    )
  }

  return (
    <div className={`${css.node}${selected ? ` ${css.nodeSelected}` : ''}`} data-kind={kind} data-status={status} style={style}>
      {HANDLES.map((h) => (
        <Handle key={h.id} id={h.id} type={h.type} position={h.position} className={css.handle} isConnectable={false} />
      ))}
      <div className={css.nodeHead}>
        {span.sequence !== undefined ? <span className={css.nodeSequence}>#{span.sequence}</span> : null}
        <span className={css.nodeIcon} style={{ color: meta.color, borderColor: meta.border }}>{meta.icon}</span>
        <span className={css.nodeKind} style={{ color: meta.color }}>{label}</span>
        <span
          className={`${css.nodeStatus} ${status === 'ok' ? css.statusOk : status === 'error' ? css.statusError : css.statusRunning}`}
          title={status === 'error' ? span.error : status}
        />
      </div>
      <div className={css.nodeTitle} title={span.span_name}>{span.span_name}</div>
      <div className={css.nodeMetrics}>
        <span className={css.metric} title={t('node.latency')}>◷ {latency > 0 ? fmtLatency(latency) : '—'}</span>
        {span.token_usage ? (
          <span className={css.metric} title={t('node.tokens')}>
            Σ ↑{fmtTokens(span.token_usage.input)} ↓{fmtTokens(span.token_usage.output)}
          </span>
        ) : null}
      </div>
      <div className={css.nodeBar}>
        <i style={{ width: `${Math.max(2, pct)}%`, background: `linear-gradient(90deg, ${meta.color}, ${meta.color2})` }} />
      </div>
      {status === 'error' && span.error ? <div className={css.nodeError}>! {span.error}</div> : null}
    </div>
  )
}

export const TraceNode = memo(TraceNodeComponent)
