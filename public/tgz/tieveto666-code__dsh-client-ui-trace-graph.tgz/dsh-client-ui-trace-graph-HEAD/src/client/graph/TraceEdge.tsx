/**
 * Custom edge: smooth bezier curve with three render layers.
 * - BaseEdge underneath: translucent stroke + arrow marker;
 * - dashed flow overlay: stroke-dasharray offset animation, the data/time flow;
 * - particles: glowing dots drifting along the curve (shared rAF engine,
 *   direct DOM writes, zero React re-renders).
 */
import { memo, useMemo } from 'react'
import { BaseEdge } from '@xyflow/react'
import type { EdgeProps } from '@xyflow/react'
import type { TraceEdge as TraceEdgeType } from '../../core/types.ts'
import { hexToRgba, traceLabelMeta } from '../../core/classify.ts'
import { buildFlowPath } from '../../core/edgePath.ts'
import { useFlowParticles } from './useFlowParticles.tsx'
import css from '../tracegraph.module.css'

function TraceEdgeComponent(props: EdgeProps<TraceEdgeType>) {
  const { id, sourceX, sourceY, targetX, targetY, data, selected, markerEnd } = props
  const kind = data?.kind ?? 'other'
  const isSequenceOnly = data?.edgeKind === 'sequence'
  const meta = traceLabelMeta(data?.traceLabel, kind)
  const color = isSequenceOnly ? '#8b95a7' : meta.color
  const geom = useMemo(
    () => buildFlowPath(sourceX, sourceY, targetX, targetY),
    [sourceX, sourceY, targetX, targetY],
  )
  const particles = useFlowParticles(id, geom, {
    color,
    count: isSequenceOnly ? 1 : data?.particleCount ?? (selected ? 5 : 3),
  })

  return (
    <g>
      <BaseEdge
        id={id}
        path={geom.path}
        markerEnd={markerEnd}
        className={`${css.edgeBase} ${isSequenceOnly ? css.edgeSequenceBase : css.edgeStructureBase}`}
        style={{ stroke: hexToRgba(color, isSequenceOnly ? 0.38 : 0.56), strokeWidth: selected ? 2.7 : isSequenceOnly ? 1.4 : 2 }}
      />
      <path
        d={geom.path}
        markerEnd={markerEnd}
        className={`${css.edgeFlow} ${isSequenceOnly ? css.edgeSequenceFlow : css.edgeStructureFlow}`}
        style={{ color, stroke: color }}
      />
      {particles}
    </g>
  )
}

export const TraceEdge = memo(TraceEdgeComponent)
