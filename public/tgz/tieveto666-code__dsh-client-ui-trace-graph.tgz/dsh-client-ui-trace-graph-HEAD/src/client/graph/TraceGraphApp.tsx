/** Panel shell: binds the controller state onto the real trajectory graph. */
import { useSyncExternalStore } from 'react'
import type { TraceGraphController } from '../controller.ts'
import { TraceViewer } from './TraceViewer.tsx'
import { useTrajectoryTrace, type TraceGraphUseSession } from '../trajectory-adapter.ts'

interface TraceGraphAppProps {
  controller: TraceGraphController
  useSession: TraceGraphUseSession
}

/** The panel's React tree, driven entirely by the controller snapshot. */
export function TraceGraphApp({ controller, useSession }: TraceGraphAppProps) {
  const snapshot = useSyncExternalStore(
    controller.subscribe.bind(controller),
    controller.getSnapshot.bind(controller),
  )
  const trace = useTrajectoryTrace(useSession)

  return (
    <TraceViewer
      spans={[...trace.spans]}
      traceName={trace.traceName}
      layoutMode={snapshot.layoutMode}
      onLayoutModeChange={(mode) => { controller.setLayoutMode(mode) }}
      showHeader={false}
    />
  )
}
