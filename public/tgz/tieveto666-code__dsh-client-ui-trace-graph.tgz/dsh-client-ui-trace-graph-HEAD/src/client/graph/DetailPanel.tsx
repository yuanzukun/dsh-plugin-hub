/**
 * Non-intrusive slide-out detail panel: clicking a node slides it in from the
 * right with the span's full Input/Output JSON (collapsible tree viewer),
 * without covering the whole graph and without fixed/modal positioning.
 */
import { useMemo, useState } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import type { TraceSpan } from '../../core/types.ts'
import { inferKind, traceLabelMeta } from '../../core/classify.ts'
import { fmtClock, fmtLatency, fmtTokens, spanLatency } from '../../core/format.ts'
import { t, kindLabelKey } from '../locales.ts'
import css from '../tracegraph.module.css'

interface DetailPanelProps {
  span: TraceSpan
  onClose: () => void
}

/** Entries shown per page inside the JSON tree viewer. */
const JSON_PAGE = 200

export function DetailPanel({ span, onClose }: DetailPanelProps) {
  const kind = inferKind(span)
  const meta = traceLabelMeta(span.trace_label, kind)
  const status = span.status ?? 'ok'
  const latency = spanLatency(span)
  const statusKey = status === 'ok' ? 'detail.status.ok' : status === 'error' ? 'detail.status.error' : 'detail.status.running'
  const label = span.trace_label ?? t(kindLabelKey(kind))

  return (
    <aside className={css.detail} style={{ '--tg-kind': meta.color } as CSSProperties}>
      <header className={css.detailHead}>
        <span className={css.nodeIcon} style={{ color: meta.color, borderColor: meta.border }}>{meta.icon}</span>
        <div className={css.detailTitle}>
          <div className={css.detailName} title={span.span_name}>{span.span_name}</div>
          <div className={css.detailSub}>{label} · {span.span_id}</div>
        </div>
        <button type="button" className={css.detailClose} onClick={onClose} aria-label={t('detail.close')}>✕</button>
      </header>
      <div className={css.detailBody}>
        {status === 'error' && span.error ? <div className={css.detailError}>! {span.error}</div> : null}
        <div className={css.detailGrid}>
          <DetailCell label={t('detail.sequence')} value={span.sequence === undefined ? '—' : `#${span.sequence}`} />
          <DetailCell label={t('detail.sourceSeq')} value={span.source_seq === undefined ? '—' : String(span.source_seq)} />
          <DetailCell label={t('detail.turnStep')} value={turnStepLabel(span)} />
          <DetailCell label={t('detail.group')} value={span.group ?? '—'} />
          <DetailCell label={t('detail.latency')} value={latency > 0 ? fmtLatency(latency) : '—'} />
          <DetailCell
            label={t('detail.status')}
            value={<span className={`${css.statusChip} ${status === 'ok' ? css.statusOk : status === 'error' ? css.statusError : css.statusRunning}`}>{t(statusKey)}</span>}
          />
          <DetailCell label={t('detail.tokenIn')} value={span.token_usage ? fmtTokens(span.token_usage.input) : '—'} />
          <DetailCell label={t('detail.tokenOut')} value={span.token_usage ? fmtTokens(span.token_usage.output) : '—'} />
          <DetailCell label={t('detail.start')} value={span.start_ms != null ? fmtClock(span.start_ms) : '—'} />
          <DetailCell label={t('detail.end')} value={span.end_ms != null ? fmtClock(span.end_ms) : '—'} />
        </div>
        <JsonSection title={t('detail.input')} value={span.input} />
        <JsonSection title={t('detail.output')} value={span.output} />
      </div>
    </aside>
  )
}

function turnStepLabel(span: TraceSpan): string {
  if (span.turn === undefined && span.step === undefined) return '—'
  if (span.step === undefined) return `Turn ${span.turn ?? '—'}`
  return `Turn ${span.turn ?? '—'} · Step ${span.step}`
}

function DetailCell({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className={css.detailCell}>
      <div className={css.detailCellLabel}>{label}</div>
      <div className={css.detailCellValue}>{value}</div>
    </div>
  )
}

function JsonSection({ title, value }: { title: string; value: unknown }) {
  return (
    <section className={css.jsonSection}>
      <h4 className={css.jsonTitle}>{title}</h4>
      {value === undefined ? <div className={css.jsonEmpty}>{t('detail.none')}</div> : <JsonView value={value} />}
    </section>
  )
}

function isPlainObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v)
}

/** Recursive collapsible JSON viewer (pure React, no innerHTML). */
function JsonView({ value, name, depth = 0 }: { value: unknown; name?: string; depth?: number }) {
  const [open, setOpen] = useState(depth < 2)
  const entries = useMemo(() => {
    if (Array.isArray(value)) return value.slice(0, JSON_PAGE).map((v, i) => [String(i), v] as const)
    if (isPlainObject(value)) return Object.entries(value).slice(0, JSON_PAGE) as Array<[string, unknown]>
    return null
  }, [value])
  const isArray = Array.isArray(value)
  const total = isArray ? value.length : isPlainObject(value) ? Object.keys(value).length : 0
  const truncated = entries !== null && entries.length < total

  if (entries === null) return <PrimitiveValue value={value} name={name} />

  return (
    <div className={css.jv}>
      <button type="button" className={css.jvToggle} onClick={() => setOpen((o) => !o)}>
        <span className={`${css.jvCaret}${open ? ` ${css.jvCaretOpen}` : ''}`}>▸</span>
        {name !== undefined && <span className={css.jvKey}>{name}:</span>}
        <span className={css.jvSummary}>{isArray ? `[${total}]` : `{${total}}`}</span>
      </button>
      {open && (
        <div className={css.jvChildren}>
          {entries.map(([k, v]) => (
            <JsonView key={k} name={isArray ? `[${k}]` : k} value={v} depth={depth + 1} />
          ))}
          {truncated && <div className={css.jvMore}>{t('detail.more', { total: String(total), shown: String(entries.length) })}</div>}
        </div>
      )}
    </div>
  )
}

function PrimitiveValue({ value, name }: { value: unknown; name?: string }) {
  const cls =
    value === null ? css.jvNull
      : typeof value === 'string' ? css.jvString
        : typeof value === 'number' ? css.jvNumber
          : typeof value === 'boolean' ? css.jvBool
            : css.jvPlain
  const text = value === null ? 'null' : typeof value === 'string' ? JSON.stringify(value) : String(value)
  return (
    <div className={css.jvLine}>
      {name !== undefined && <span className={css.jvKey}>{name}:</span>}
      <span className={cls}>{text}</span>
    </div>
  )
}
