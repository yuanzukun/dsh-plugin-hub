/**
 * TraceViewer: the panel's total container.
 *
 * - Optional header: title and stats for standalone embedding;
 * - Body: the graph with the slide-out detail panel;
 * - Strict container constraints: position:relative + height:100% only,
 *   never fixed/Modal/Overlay.
 *
 * Controlled layout mode: when `layoutMode` and its change callback are
 * provided, the parent owns the layout state; otherwise the component keeps
 * an internal default.
 */
import { useMemo, useState } from 'react'
import type { CSSProperties, ReactNode } from 'react'
import type { LayoutMode, TraceSpan } from '../../core/types.ts'
import { buildGraph } from '../../core/transform.ts'
import { fmtLatency } from '../../core/format.ts'
import { TraceGraph } from './TraceGraph.tsx'
import { DetailPanel } from './DetailPanel.tsx'
import { t } from '../locales.ts'
import css from '../tracegraph.module.css'

export interface TraceViewerProps {
  /** Nested span tree (or a flat parent_span_id array). */
  spans: TraceSpan[]
  /** Trace name; used as the synthetic root title for multi-root traces. */
  traceName?: string
  /** Controlled layout mode; falls back to internal state when omitted. */
  layoutMode?: LayoutMode
  /** Controlled layout change; called with the next mode. */
  onLayoutModeChange?: (mode: LayoutMode) => void
  /** Default layout (uncontrolled mode only). */
  defaultLayout?: LayoutMode
  /** Extra nodes rendered after the title. */
  headerExtra?: ReactNode
  /** Whether to render the standalone header. */
  showHeader?: boolean
  className?: string
  style?: CSSProperties
}

export function TraceViewer({
  spans,
  traceName,
  layoutMode,
  onLayoutModeChange,
  defaultLayout = 'dagre',
  headerExtra,
  showHeader = true,
  className,
  style,
}: TraceViewerProps) {
  const [layoutState, setLayoutState] = useState<LayoutMode>(defaultLayout)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const bundle = useMemo(() => buildGraph(spans, { rootLabel: traceName }), [spans, traceName])

  const currentLayout = layoutMode ?? layoutState
  const setLayout = (next: LayoutMode): void => {
    if (onLayoutModeChange !== undefined) onLayoutModeChange(next)
    else setLayoutState(next)
  }

  const selected = selectedId ? bundle.byId.get(selectedId) ?? null : null
  const realNodeCount = bundle.nodes.length - (bundle.hasVirtualRoot ? 1 : 0)

  return (
    <div className={`${css.root}${className ? ` ${className}` : ''}`} style={style}>
      {showHeader ? (
        <header className={css.viewerHead}>
          <div className={css.viewerTitle}>
            <span className={css.titleDot} />
            <span className={css.titleText}>{traceName ?? t('view.title')}</span>
            <span className={css.viewerStats}>
              {t('view.stats', { count: String(realNodeCount), latency: fmtLatency(bundle.totalLatency) })}
            </span>
          </div>
          {headerExtra}
        </header>
      ) : null}
      <div className={css.viewerBody}>
        <TraceGraph
          spans={spans}
          traceName={traceName}
          layoutMode={currentLayout}
          onLayoutModeChange={setLayout}
          selectedId={selectedId}
          onSelect={setSelectedId}
        />
        {selected ? (
          <DetailPanel key={selected.span_id} span={selected} onClose={() => { setSelectedId(null) }} />
        ) : null}
      </div>
    </div>
  )
}
