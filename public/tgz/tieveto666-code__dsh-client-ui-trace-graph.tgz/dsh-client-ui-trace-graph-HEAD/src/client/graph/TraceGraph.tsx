/**
 * Main graph component: ReactFlow rendering plus the interaction wiring.
 *
 * - hovering a node highlights its direct parent/children and keeps the whole
 *   upstream/downstream relation visible; unrelated nodes/edges dim;
 * - a ResizeObserver watches the container (sidebar collapse / panel resize)
 *   and re-fits the viewport (debounced);
 * - switching layouts re-lays the graph and re-fits; nodes stay draggable
 *   (drag positions reset on layout switch), no wiring interactions;
 * - the graph renders strictly inside its container: position:relative +
 *   100% size, no fixed/modal anywhere.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  Background,
  BackgroundVariant,
  Controls,
  MiniMap,
  Panel,
  ReactFlow,
  ReactFlowProvider,
  useEdgesState,
  useNodesState,
  useReactFlow,
} from '@xyflow/react'
import type { EdgeTypes, NodeTypes } from '@xyflow/react'
import type { LayoutMode, TraceEdge as TraceEdgeType, TraceNode as TraceNodeType, TraceNodeData, TraceSpan } from '../../core/types.ts'
import { buildGraph, buildRelations } from '../../core/transform.ts'
import { applyLayout } from '../../core/layout.ts'
import { traceLabelMeta } from '../../core/classify.ts'
import { fmtLatency } from '../../core/format.ts'
import { t } from '../locales.ts'
import { TraceNode } from './TraceNode.tsx'
import { TraceEdge } from './TraceEdge.tsx'
import css from '../tracegraph.module.css'

// Module-level constant references: rebuilding nodeTypes/edgeTypes per render
// would make ReactFlow remount every custom node/edge.
const nodeTypes: NodeTypes = { trace: TraceNode }
const edgeTypes: EdgeTypes = { trace: TraceEdge }

export interface TraceGraphProps {
  /** Span tree (nested or flat form). */
  spans: TraceSpan[]
  /** Trace name; the synthetic root title for multi-root traces. */
  traceName?: string
  layoutMode: LayoutMode
  onLayoutModeChange: (mode: LayoutMode) => void
  selectedId: string | null
  onSelect: (id: string | null) => void
}

function TraceGraphInner({
  spans,
  traceName,
  layoutMode,
  onLayoutModeChange,
  onSelect,
}: TraceGraphProps) {
  const bundle = useMemo(() => buildGraph(spans, { rootLabel: traceName }), [spans, traceName])
  const laidOut = useMemo(() => applyLayout(bundle.nodes, bundle.edges, layoutMode), [bundle, layoutMode])
  const traceLabels = useMemo(() => {
    const labels = new Map<string, TraceNodeData['kind']>()
    for (const node of bundle.nodes) {
      if (node.data.isVirtualRoot) continue
      const label = node.data.span.trace_label
      if (label !== undefined && label !== '' && !labels.has(label)) labels.set(label, node.data.kind)
    }
    return [...labels.entries()]
  }, [bundle.nodes])
  const [nodes, setNodes, onNodesChange] = useNodesState<TraceNodeType>(laidOut.nodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState<TraceEdgeType>(laidOut.edges)
  const [hoveredId, setHoveredId] = useState<string | null>(null)
  const wrapRef = useRef<HTMLDivElement | null>(null)
  const { fitView } = useReactFlow()

  // Replace nodes/edges wholesale on layout/data change (drag positions reset).
  useEffect(() => {
    setNodes(laidOut.nodes)
    setEdges(laidOut.edges)
  }, [laidOut, setNodes, setEdges])

  const fit = useCallback(() => {
    fitView({ padding: 0.22, duration: 240, maxZoom: 1.4 })
  }, [fitView])

  // Fit after the nodes are measured (double rAF waits for the commit).
  useEffect(() => {
    const timer = requestAnimationFrame(() => requestAnimationFrame(fit))
    return () => cancelAnimationFrame(timer)
  }, [laidOut, fit])

  // Container size changes (panel width changes / sidebar collapse) re-fit,
  // debounced so continuous resizes settle first.
  useEffect(() => {
    const el = wrapRef.current
    if (!el) return
    let timer: number | undefined
    const ro = new ResizeObserver(() => {
      window.clearTimeout(timer)
      timer = window.setTimeout(fit, 160)
    })
    ro.observe(el)
    return () => {
      ro.disconnect()
      window.clearTimeout(timer)
    }
  }, [fit])

  // Hover relation: all ancestors + all descendants + direct parent/children.
  const relation = useMemo(
    () => (hoveredId ? buildRelations(bundle.parentOf, bundle.childrenOf, hoveredId) : null),
    [hoveredId, bundle],
  )

  // Attach highlight/dim classes by relation (className only, data untouched).
  const displayNodes = useMemo(() => {
    if (!relation) return nodes
    return nodes.map((n) => {
      let cls = css.nodeDim
      if (n.id === hoveredId) cls = css.nodeHovered
      else if (relation.direct.has(n.id)) cls = css.nodeFocus
      else if (relation.related.has(n.id)) cls = css.nodeRelated
      return { ...n, className: cls }
    })
  }, [nodes, relation, hoveredId])

  const displayEdges = useMemo(() => {
    if (!relation) return edges
    return edges.map((e) => {
      let cls = css.edgeDim
      const both = relation.related.has(e.source) && relation.related.has(e.target)
      if (both) cls = e.source === hoveredId || e.target === hoveredId ? css.edgeFocus : css.edgeRelated
      return { ...e, className: cls }
    })
  }, [edges, relation, hoveredId])

  const realNodeCount = bundle.nodes.length - (bundle.hasVirtualRoot ? 1 : 0)

  return (
    <div className={css.graphWrap} ref={wrapRef}>
      <ReactFlow
        nodes={displayNodes}
        edges={displayEdges}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        minZoom={0.12}
        maxZoom={2.4}
        fitView
        fitViewOptions={{ padding: 0.22, maxZoom: 1.4 }}
        nodesConnectable={false}
        deleteKeyCode={null}
        onNodeMouseEnter={(_, node) => setHoveredId(node.id)}
        onNodeMouseLeave={() => setHoveredId(null)}
        onNodeClick={(_, node) => onSelect(node.id)}
        onPaneClick={() => {
          setHoveredId(null)
          onSelect(null)
        }}
      >
        <Background variant={BackgroundVariant.Lines} gap={30} size={1} color="rgba(130,150,230,0.08)" />
        <Controls position="bottom-left" showInteractive={false} className={css.controls} />
        <MiniMap
          position="bottom-right"
          pannable
          zoomable
          style={{ width: 168, height: 108 }}
          nodeColor={(n) => {
            const data = n.data as TraceNodeData | undefined
            return traceLabelMeta(data?.span.trace_label, data?.kind ?? 'other').color
          }}
          nodeStrokeWidth={2}
          maskColor="rgba(8,11,22,0.66)"
          className={css.minimap}
        />
        <Panel position="top-left" className={css.toolbar}>
          <div className={css.seg} role="group" aria-label="layout toggle">
            <button
              type="button"
              className={layoutMode === 'dagre' ? css.segActive : ''}
              onClick={() => onLayoutModeChange('dagre')}
            >
              {t('view.layoutDagre')}
            </button>
            <button
              type="button"
              className={layoutMode === 'force' ? css.segActive : ''}
              onClick={() => onLayoutModeChange('force')}
            >
              {t('view.layoutForce')}
            </button>
          </div>
          <div className={css.edgeLegend}>
            <span className={css.edgeLegendItem}>
              <i className={css.edgeLegendSequence} />
              {t('view.edgeSequence')}
            </span>
            <span className={css.edgeLegendItem}>
              <i className={css.edgeLegendStructure} />
              {t('view.edgeStructure')}
            </span>
          </div>
          <div className={css.legend}>
            {traceLabels.map(([label, kind]) => (
              <span key={label} className={css.legendItem}>
                <i style={{ background: traceLabelMeta(label, kind).color, color: traceLabelMeta(label, kind).color }} />
                {label}
              </span>
            ))}
          </div>
          <div className={css.stats}>
            {t('view.stats', { count: String(realNodeCount), latency: fmtLatency(bundle.totalLatency) })}
          </div>
        </Panel>
        {realNodeCount === 0 && <Panel position="top-center" className={css.empty}>{t('view.empty')}</Panel>}
      </ReactFlow>
    </div>
  )
}

/** Outer Provider wrapper: useReactFlow/fitView need it. */
export function TraceGraph(props: TraceGraphProps) {
  return (
    <ReactFlowProvider>
      <TraceGraphInner {...props} />
    </ReactFlowProvider>
  )
}
