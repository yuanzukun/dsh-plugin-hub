/**
 * Flow-particle engine: glowing dots drifting along edge paths from parent to
 * child, suggesting token flow / execution propagation.
 *
 * Implementation notes:
 * - all edges share one requestAnimationFrame loop (no per-edge rAF);
 * - particle positions are written straight to the DOM (setAttribute), so
 *   React never re-renders for animation frames;
 * - edges deregister on unmount and the engine idles when empty.
 */
import { useEffect, useMemo, useRef } from 'react'
import type { ReactElement } from 'react'
import { cubicPoint } from '../../core/edgePath.ts'
import type { EdgeGeometry } from '../../core/edgePath.ts'
import css from '../tracegraph.module.css'

/** Cycles per second for one particle (one cycle = one source-to-target trip). */
const PARTICLE_CYCLE = 0.5

interface ParticleEntry {
  geom: EdgeGeometry
  color: string
  count: number
  els: Array<SVGCircleElement | null>
}

class ParticleEngine {
  private entries = new Map<string, ParticleEntry>()
  private raf = 0

  add(id: string, entry: ParticleEntry): void {
    this.entries.set(id, entry)
    this.start()
  }

  remove(id: string): void {
    this.entries.delete(id)
    if (this.entries.size === 0) this.stop()
  }

  private start(): void {
    if (this.raf === 0) this.raf = requestAnimationFrame(this.tick)
  }

  private stop(): void {
    if (this.raf !== 0) cancelAnimationFrame(this.raf)
    this.raf = 0
  }

  private readonly tick = (now: number): void => {
    this.raf = 0
    const time = now / 1000
    for (const entry of this.entries.values()) {
      const { geom, color, count, els } = entry
      for (let i = 0; i < count; i++) {
        const el = els[i]
        if (!el) continue
        const t = (time * PARTICLE_CYCLE + i / count) % 1
        const p = cubicPoint(geom.p0, geom.p1, geom.p2, geom.p3, t)
        el.setAttribute('cx', p.x.toFixed(1))
        el.setAttribute('cy', p.y.toFixed(1))
        // Fade in/out at both ends, brightest mid-flow.
        el.style.opacity = String(0.2 + 0.8 * Math.sin(Math.PI * t))
        el.style.fill = color
        el.style.color = color
      }
    }
    if (this.entries.size > 0) this.raf = requestAnimationFrame(this.tick)
  }
}

/** Module-level singleton: every graph on the page shares one rAF loop. */
const engine = new ParticleEngine()

export interface FlowParticleOptions {
  count?: number
  color: string
}

/**
 * Return the particles drifting along one edge and register them with the
 * shared engine.
 * @param edgeId - edge id (the engine's registration key).
 * @param geom - edge geometry; null renders and registers nothing.
 */
export function useFlowParticles(
  edgeId: string,
  geom: EdgeGeometry | null,
  options: FlowParticleOptions,
): ReactElement[] | null {
  const count = Math.max(1, options.count ?? 3)
  const refs = useRef<Array<SVGCircleElement | null>>([])

  useEffect(() => {
    if (!geom) return
    engine.add(edgeId, { geom, color: options.color, count, els: refs.current })
    return () => engine.remove(edgeId)
  }, [edgeId, geom, options.color, count])

  return useMemo(() => {
    if (!geom) return null
    const els: ReactElement[] = []
    for (let i = 0; i < count; i++) {
      const t = i / count
      const p = cubicPoint(geom.p0, geom.p1, geom.p2, geom.p3, t)
      els.push(
        <circle
          key={i}
          cx={p.x}
          cy={p.y}
          r={2.4}
          className={css.particle}
          style={{ pointerEvents: 'none', color: options.color, opacity: 0.2 }}
          fill={options.color}
          ref={(el: SVGCircleElement | null) => {
            refs.current[i] = el
          }}
        />,
      )
    }
    return els
  }, [geom, count, options.color])
}
