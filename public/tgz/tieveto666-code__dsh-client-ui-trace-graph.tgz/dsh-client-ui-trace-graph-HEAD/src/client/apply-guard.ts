/**
 * Apply guard: the trace-graph client bundle must mount exactly once per page
 * lifetime, even when the module factory runs more than once (duplicated
 * client injection, stale module still alive). First application wins; later
 * calls become no-ops until the claim is released by the owning fiber.
 */

/** Global claim flag shared by every factory run of this bundle. */
declare global {
  // eslint-disable-next-line no-var
  var __dshTraceGraphApplied: boolean | undefined
}

/** Try to claim the single apply slot for this page lifetime. */
export function claimTraceGraphApply(): boolean {
  if (globalThis.__dshTraceGraphApplied === true) return false
  globalThis.__dshTraceGraphApplied = true
  return true
}

/** Release the claim (fiber unload / hot-reload), letting a rebuilt bundle re-claim. */
export function releaseTraceGraphApply(): void {
  globalThis.__dshTraceGraphApplied = undefined
}
