/** Conversation view registration for the trace graph tab. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type { TraceGraphController } from './controller.ts'
import { TraceGraphApp } from './graph/TraceGraphApp.tsx'
import type { TraceGraphUseSession } from './trajectory-adapter.ts'
import css from './tracegraph.module.css'

/** Stable id of the trace graph conversation view entry. */
export const TRACE_GRAPH_VIEW_ID = 'trace-graph'

interface TraceGraphViewProps {
  readonly useSession: TraceGraphUseSession
}

/**
 * Register the graph as a regular conversation view tab.
 * @param ctx - client root context.
 * @param controller - the panel controller driving the view.
 * @param label - localized tab label.
 * @returns disposer unregistering the tab.
 */
export function mountView(ctx: ClientContext, controller: TraceGraphController, label: () => string): () => void {
  return ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    id: TRACE_GRAPH_VIEW_ID,
    order: 20,
    locale: 'trace-graph',
    label,
  }, (props: TraceGraphViewProps) => (
    <div className={css.panel} data-dsh-tracegraph-panel="">
      <TraceGraphApp controller={controller} useSession={props.useSession} />
    </div>
  )))
}
