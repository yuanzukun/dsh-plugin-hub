import { useMemo } from 'react'
import type { SpanKind, SpanStatus, TokenUsage, TraceSpan } from '../core/types.ts'
import { t } from './locales.ts'

/** Minimal session snapshot surface supplied by the official conversation view slot. */
export interface TraceGraphSessionSnapshot {
  readonly views: { get(name: string): unknown }
  readonly nodes?: readonly unknown[]
  readonly partial?: unknown
  readonly runningCalls?: readonly unknown[]
}

/** React selector hook supplied by the conversation view slot. */
export type TraceGraphUseSession = <T>(selector: (snapshot: TraceGraphSessionSnapshot) => T) => T

export interface TrajectoryTraceProjection {
  readonly traceName: string
  readonly spans: readonly TraceSpan[]
}

export interface ProjectionInput {
  readonly trajectory: unknown
  readonly fallbackNodes: readonly unknown[]
  readonly fallbackPartial: unknown
  readonly fallbackRunningCalls: readonly unknown[]
}

interface TraceSource {
  readonly nodes: readonly unknown[]
  readonly requests: readonly unknown[]
  readonly partial: unknown
  readonly runningCalls: readonly unknown[]
}

export type TrajectoryKind =
  | 'system'
  | 'user'
  | 'context'
  | 'compacted'
  | 'message'
  | 'tool'
  | 'subtool'

export interface TraceGraphRecord {
  readonly id: string
  readonly label: string
  readonly kind: TrajectoryKind
  readonly summary: string
  readonly startMs?: number
  readonly endMs?: number
  readonly latencyMs?: number
  readonly status: SpanStatus
  readonly tokenUsage?: TokenUsage
  readonly input?: unknown
  readonly output?: unknown
  readonly error?: string
  readonly sourceSeq?: number
  readonly turn?: number
  readonly step?: number
  readonly group?: string
  readonly callId?: string
  readonly structureParentIds?: readonly string[]
}

type OrderedEntry =
  | {
    readonly kind: 'node'
    readonly order: number
    readonly node: Record<string, unknown>
  }
  | {
    readonly kind: 'system'
    readonly order: number
    readonly request: Record<string, unknown>
    readonly change: Record<string, unknown>
  }
  | {
    readonly kind: 'assistant-request'
    readonly order: number
    readonly request: Record<string, unknown>
  }
  | {
    readonly kind: 'compaction-request'
    readonly order: number
    readonly request: Record<string, unknown>
  }

const EMPTY_LIST: readonly never[] = []

const KIND_LABEL: Record<TrajectoryKind, string> = {
  system: 'SYSTEM',
  user: 'USER',
  context: 'CONTEXT',
  compacted: 'COMPACTED',
  message: 'ASSISTANT',
  tool: 'TOOL',
  subtool: 'SUBTOOL',
}

/** Project the same live trajectory snapshot as the official "轨迹" tab into ordered TraceSpan nodes. */
export function useTrajectoryTrace(useSession: TraceGraphUseSession): TrajectoryTraceProjection {
  const trajectory = useSession(snapshot => snapshot.views.get('trajectory'))
  const fallbackNodes = useSession(snapshot => snapshot.nodes ?? EMPTY_LIST)
  const fallbackPartial = useSession(snapshot => snapshot.partial ?? null)
  const fallbackRunningCalls = useSession(snapshot => snapshot.runningCalls ?? EMPTY_LIST)
  return useMemo(
    () => projectTrajectory({ trajectory, fallbackNodes, fallbackPartial, fallbackRunningCalls }),
    [trajectory, fallbackNodes, fallbackPartial, fallbackRunningCalls],
  )
}

export function projectTrajectory(input: ProjectionInput): TrajectoryTraceProjection {
  const source = readTraceSource(input)
  const toolResults = indexToolResults(source.nodes)
  const emittedCallIds = new Set<string>()
  const rows: TraceGraphRecord[] = []
  let previousAbsTime: number | undefined

  for (const entry of orderedEntries(source)) {
    switch (entry.kind) {
      case 'system': {
        const row = systemRow(entry.request, entry.change, source.nodes, source.partial)
        rows.push(row)
        previousAbsTime = row.startMs ?? previousAbsTime
        break
      }
      case 'assistant-request': {
        const row = assistantRequestRow(entry.request)
        rows.push(row)
        previousAbsTime = row.endMs ?? row.startMs ?? previousAbsTime
        break
      }
      case 'compaction-request': {
        const row = compactionRequestRow(entry.request)
        rows.push(row)
        previousAbsTime = row.endMs ?? row.startMs ?? previousAbsTime
        break
      }
      case 'node': {
        const nodeKind = stringValue(entry.node.kind)
        if (nodeKind === 'user' || nodeKind === 'steering' || nodeKind === 'context') {
          const row = inputNodeRow(entry.node, source.nodes, source.partial)
          rows.push(row)
          previousAbsTime = row.startMs ?? previousAbsTime
          break
        }
        if (nodeKind === 'assistant') {
          const assistant = assistantRows(entry.node, toolResults, previousAbsTime)
          rows.push(...assistant)
          for (const row of assistant) {
            const callId = stringValue(recordValue(row.input)?.callId)
            if (row.kind === 'tool' && callId !== undefined) emittedCallIds.add(callId)
          }
          const last = assistant.at(-1)
          previousAbsTime = last?.endMs ?? numberValue(entry.node.time) ?? previousAbsTime
          break
        }
        if (nodeKind === 'tool-result') {
          const callId = stringValue(entry.node.callId)
          if (callId === undefined || !emittedCallIds.has(callId)) {
            const row = orphanToolResultRow(entry.node)
            rows.push(row)
            previousAbsTime = row.endMs ?? row.startMs ?? previousAbsTime
          }
        }
        break
      }
    }
  }

  rows.push(...partialRows(source.partial, toolResults))
  rows.push(...runningCallRows(source.runningCalls, emittedCallIds))

  return {
    traceName: t('view.realTrace'),
    spans: rowsToSpans(rows),
  }
}

function readTraceSource(input: ProjectionInput): TraceSource {
  if (isRecord(input.trajectory)) {
    return {
      nodes: arrayValue(input.trajectory.eventNodes) ?? input.fallbackNodes,
      requests: arrayValue(input.trajectory.requests) ?? EMPTY_LIST,
      partial: 'partial' in input.trajectory ? input.trajectory.partial : input.fallbackPartial,
      runningCalls: arrayValue(input.trajectory.runningCalls) ?? input.fallbackRunningCalls,
    }
  }
  return {
    nodes: input.fallbackNodes,
    requests: EMPTY_LIST,
    partial: input.fallbackPartial,
    runningCalls: input.fallbackRunningCalls,
  }
}

function orderedEntries(source: TraceSource): OrderedEntry[] {
  const represented = representedAssistantSteps(source.nodes, source.partial, source.runningCalls)
  return [
    ...objects(source.nodes).map(node => ({
      kind: 'node' as const,
      order: numberValue(node.seq) ?? 0,
      node,
    })),
    ...objects(source.requests)
      .filter(request => stringValue(request.purpose) === 'compaction')
      .map(request => ({
        kind: 'compaction-request' as const,
        order: numberValue(request.startSeq) ?? 0,
        request,
      })),
    ...objects(source.requests).flatMap((request): OrderedEntry[] => {
      const change = recordValue(request.promptChange)
      if (change === undefined) return []
      return [{
        kind: 'system',
        order: stringValue(change.kind) === 'initial'
          ? Number.NEGATIVE_INFINITY
          : numberValue(change.seq) ?? numberValue(request.startSeq) ?? 0,
        request,
        change,
      }]
    }),
    ...objects(source.requests)
      .filter(request => stringValue(request.purpose) === 'assistant')
      .filter((request) => {
        const turn = numberValue(request.turn)
        const step = numberValue(request.step)
        return turn === undefined || step === undefined || !represented.has(stepKey(turn, step))
      })
      .map(request => ({
        kind: 'assistant-request' as const,
        order: numberValue(request.startSeq) ?? 0,
        request,
      })),
  ].sort((left, right) => left.order - right.order)
}

function systemRow(
  request: Record<string, unknown>,
  change: Record<string, unknown>,
  nodes: readonly unknown[],
  partial: unknown,
): TraceGraphRecord {
  const summary = promptChangeLabel(change)
  const seq = numberValue(change.seq) ?? numberValue(request.startSeq) ?? 0
  return {
    id: `system:${seq}`,
    label: KIND_LABEL.system,
    kind: 'system',
    summary,
    startMs: numberValue(change.time),
    latencyMs: 0,
    status: 'ok',
    input: change.previous,
    output: request.prompt,
    sourceSeq: seq,
    turn: promptTurn(change, nodes, partial),
    group: 'Message',
  }
}

function assistantRequestRow(request: Record<string, unknown>): TraceGraphRecord {
  const turn = numberValue(request.turn)
  const step = numberValue(request.step)
  const start = numberValue(request.startedAt)
  const end = numberValue(request.completedAt)
  const status = requestStatus(request)
  const error = stringValue(request.error)
  return {
    id: `assistant-request:${numberValue(request.startSeq) ?? start ?? 0}`,
    label: KIND_LABEL.message,
    kind: 'message',
    summary: error ?? statusLabel(status),
    startMs: start,
    endMs: end,
    latencyMs: durationMs(start, end),
    status,
    tokenUsage: usageValue(request.usage),
    input: request.prompt,
    output: error,
    error,
    sourceSeq: numberValue(request.startSeq),
    ...(turn === undefined ? {} : { turn }),
    ...(step === undefined ? {} : { step, group: `Step ${step}` }),
  }
}

function compactionRequestRow(request: Record<string, unknown>): TraceGraphRecord {
  const start = numberValue(request.startedAt)
  const end = numberValue(request.completedAt)
  const status = requestStatus(request)
  const rawOutput = request.summary ?? request.rawOutput
  const summary = status === 'running'
    ? 'Compacting context...'
    : status === 'error'
      ? stringValue(request.error) ?? 'Compaction failed'
      : markdownSummary(contentPreview(arrayValue(request.summary)) ?? primitiveDetail(rawOutput) ?? 'Context compacted')
  return {
    id: `compaction:${numberValue(request.startSeq) ?? start ?? 0}`,
    label: KIND_LABEL.compacted,
    kind: 'compacted',
    summary,
    startMs: start,
    endMs: end,
    latencyMs: durationMs(start, end),
    status,
    tokenUsage: usageValue(request.usage),
    input: request.prompt,
    output: rawOutput,
    error: stringValue(request.error),
    sourceSeq: numberValue(request.startSeq),
    turn: numberValue(request.turn),
    group: `Compaction ${numberValue(request.startSeq) ?? ''}`.trim(),
  }
}

function inputNodeRow(
  node: Record<string, unknown>,
  nodes: readonly unknown[],
  partial: unknown,
): TraceGraphRecord {
  const nodeKind = stringValue(node.kind)
  const trajectoryKind: TrajectoryKind = nodeKind === 'context' ? 'context' : 'user'
  const content = arrayValue(node.content)
  const inputDetail = detailContent(content)
  const preview = contentPreview(content)
  const summary = recordDisplayText({
    kind: trajectoryKind,
    text: '',
    previewMarkdown: preview,
    inputDetail,
  })
  const seq = numberValue(node.seq) ?? 0
  return {
    id: `${nodeKind ?? trajectoryKind}:${seq}`,
    label: KIND_LABEL[trajectoryKind],
    kind: trajectoryKind,
    summary,
    startMs: numberValue(node.time),
    latencyMs: 0,
    status: 'ok',
    input: blocksDetail(content),
    output: node.source,
    sourceSeq: seq,
    turn: enclosingTurn(seq, nodes, partial),
    group: 'Message',
  }
}

function assistantRows(
  node: Record<string, unknown>,
  toolResults: ReadonlyMap<string, Record<string, unknown>>,
  previousAbsTime: number | undefined,
): TraceGraphRecord[] {
  const turn = numberValue(node.turn)
  const step = numberValue(node.step)
  const blocks = objects(arrayValue(node.blocks) ?? EMPTY_LIST)
  const timing = recordValue(node.timing)
  const start = numberValue(timing?.stepStartTime) ?? previousAbsTime
  const end = numberValue(node.time)
  const messageText = blocks
    .filter(block => stringValue(block.kind) === 'text')
    .map(block => stringValue(block.text) ?? '')
    .filter(text => text !== '')
    .join('\n\n')
  const thinkingText = blocks
    .filter(block => stringValue(block.kind) === 'reasoning')
    .map(block => stringValue(block.text) ?? '')
    .filter(text => text !== '')
    .join('\n\n')
  const activity = summarizeAssistantActivity(blocks)
  const summary = recordDisplayText({
    kind: 'message',
    text: messageText !== '' || thinkingText !== '' ? '' : activity,
    previewMarkdown: messageText !== '' ? messageText : thinkingText !== '' ? thinkingText : undefined,
    outputDetail: messageText === '' ? undefined : messageText,
    thinkingDetail: thinkingText === '' ? undefined : thinkingText,
  }) || (activity === 'Tool call only' ? '(tool call only)' : '')
  const assistantId = `assistant:${numberValue(node.seq) ?? `${turn ?? 0}:${step ?? 0}`}`
  const rows: TraceGraphRecord[] = [{
    id: assistantId,
    label: KIND_LABEL.message,
    kind: 'message',
    summary,
    startMs: start,
    endMs: end,
    latencyMs: durationMs(start, end),
    status: 'ok',
    tokenUsage: usageValue(node.usage),
    input: undefined,
    output: { text: messageText, thinking: thinkingText, blocks },
    sourceSeq: numberValue(node.seq),
    ...(turn === undefined ? {} : { turn }),
    ...(step === undefined ? {} : { step, group: step > 0 ? `Step ${step}` : 'Message' }),
  }]

  for (const block of blocks) {
    if (stringValue(block.kind) !== 'tool-call') continue
    rows.push(...toolRowsFromCall(block, toolResults.get(stringValue(block.callId) ?? ''), turn, step, assistantId))
  }
  return rows
}

function toolRowsFromCall(
  block: Record<string, unknown>,
  result: Record<string, unknown> | undefined,
  turn: number | undefined,
  step: number | undefined,
  parentId: string,
): TraceGraphRecord[] {
  const callId = stringValue(block.callId) ?? `anonymous:${stringValue(block.name) ?? 'tool'}`
  const name = stringValue(block.name) ?? callId
  const argsRaw = stringValue(block.argsRaw) ?? ''
  const call = recordValue(result?.call)
  const start = numberValue(result?.callTime)
  const end = numberValue(result?.time)
  const status: SpanStatus = result === undefined ? 'running' : booleanValue(result.isError) ? 'error' : 'ok'
  const row: TraceGraphRecord = {
    id: `tool:${callId}`,
    label: KIND_LABEL.tool,
    kind: 'tool',
    summary: toolSummary(name, argsRaw),
    startMs: start,
    endMs: end,
    latencyMs: durationMs(start, end),
    status,
    input: { callId, name, argsRaw },
    output: result === undefined ? undefined : blocksDetail(arrayValue(result.content)),
    error: result === undefined || !booleanValue(result.isError) ? undefined : resultErrorText(result),
    sourceSeq: numberValue(result?.seq),
    callId,
    structureParentIds: [parentId],
    ...(turn === undefined ? {} : { turn }),
    ...(step === undefined ? {} : { step, group: `Step ${step}` }),
  }
  return [row, ...subtoolRows(arrayValue(result?.subCalls), row)]
}

function orphanToolResultRow(node: Record<string, unknown>): TraceGraphRecord {
  const call = recordValue(node.call)
  const callId = stringValue(node.callId) ?? `orphan:${numberValue(node.seq) ?? 0}`
  const start = numberValue(node.callTime)
  const end = numberValue(node.time)
  const name = stringValue(call?.name)
  const argsRaw = stringValue(call?.argsRaw)
  const resultSummary = summarizeResult(node)
  return {
    id: `tool:${callId}`,
    label: KIND_LABEL.tool,
    kind: 'tool',
    summary: call === undefined
      ? resultSummary
      : toolSummary(name ?? callId, argsRaw ?? ''),
    startMs: start,
    endMs: end,
    latencyMs: durationMs(start, end),
    status: booleanValue(node.isError) ? 'error' : 'ok',
    input: call ?? { callId },
    output: blocksDetail(arrayValue(node.content)),
    error: booleanValue(node.isError) ? resultErrorText(node) : undefined,
    sourceSeq: numberValue(node.seq),
    callId,
  }
}

function subtoolRows(
  subCalls: readonly unknown[] | undefined,
  parent: TraceGraphRecord,
): TraceGraphRecord[] {
  if (subCalls === undefined) return []
  const rows: TraceGraphRecord[] = []
  let index = 0
  for (const sub of objects(subCalls)) {
    const callId = stringValue(sub.callId) ?? `${parent.id}:sub:${index++}`
    const settled = stringValue(sub.kind) === 'tool-result'
    const call = recordValue(sub.call)
    const name = settled
      ? stringValue(call?.name) ?? callId
      : stringValue(sub.name) ?? callId
    const argsRaw = settled
      ? stringValue(call?.argsRaw) ?? ''
      : stringValue(sub.argsRaw) ?? ''
    const start = settled ? numberValue(sub.callTime) : numberValue(sub.time)
    const end = settled ? numberValue(sub.time) : undefined
    const isError = booleanValue(sub.isError)
    const row: TraceGraphRecord = {
      id: `subtool:${callId}`,
      label: KIND_LABEL.subtool,
      kind: 'subtool',
      summary: toolSummary(name, argsRaw),
      startMs: start,
      endMs: end,
      latencyMs: durationMs(start, end),
      status: settled ? isError ? 'error' : 'ok' : 'running',
      input: { callId, name, argsRaw },
      output: settled ? blocksDetail(arrayValue(sub.content)) : undefined,
      error: settled && isError ? resultErrorText(sub) : undefined,
      sourceSeq: numberValue(sub.seq),
      callId,
      structureParentIds: [parent.id],
      turn: parent.turn,
      step: parent.step,
      group: parent.group,
    }
    rows.push(row, ...subtoolRows(arrayValue(sub.subCalls), row))
  }
  return rows
}

function partialRows(
  partial: unknown,
  toolResults: ReadonlyMap<string, Record<string, unknown>>,
): TraceGraphRecord[] {
  const value = recordValue(partial)
  if (value === undefined) return []
  return assistantRows({
    kind: 'assistant',
    seq: Number.MAX_SAFE_INTEGER,
    time: undefined,
    turn: value.turn,
    step: value.step,
    blocks: value.blocks,
  }, toolResults, undefined).map(row => ({ ...row, status: 'running' as const }))
}

function runningCallRows(
  runningCalls: readonly unknown[],
  emittedCallIds: ReadonlySet<string>,
): TraceGraphRecord[] {
  return objects(runningCalls).flatMap((call) => {
    const callId = stringValue(call.callId)
    if (callId !== undefined && emittedCallIds.has(callId)) return []
    const name = stringValue(call.name) ?? callId ?? 'tool'
    const argsRaw = stringValue(call.argsRaw) ?? ''
    const turn = numberValue(call.turn)
    const step = numberValue(call.step)
    const row: TraceGraphRecord = {
      id: `running-tool:${callId ?? `${name}:${numberValue(call.time) ?? 0}`}`,
      label: KIND_LABEL.tool,
      kind: 'tool',
      summary: toolSummary(name, argsRaw),
      startMs: numberValue(call.time),
      status: 'running',
      input: { callId, name, argsRaw },
      ...(callId === undefined ? {} : { callId }),
      ...(turn === undefined ? {} : { turn }),
      ...(step === undefined ? {} : { step, group: `Step ${step}` }),
    }
    return [row, ...subtoolRows(arrayValue(call.subCalls), row)]
  })
}

function rowsToSpans(rows: readonly TraceGraphRecord[]): TraceSpan[] {
  const seen = new Set<string>()
  const spanIds = rows.map(row => uniqueId(seen, row.id))
  const idByRowId = new Map<string, string>()
  for (let index = 0; index < rows.length; index++) idByRowId.set(rows[index].id, spanIds[index])
  const inferredParents = inferStructureParents(rows)

  return rows.map((row, index): TraceSpan => {
    const id = spanIds[index]
    const links = [
      ...(index === 0 ? [] : [{ source_span_id: spanIds[index - 1]!, kind: 'sequence' as const }]),
      ...structureLinks(id, row, inferredParents, idByRowId),
    ]
    return {
      span_id: id,
      parent_span_id: null,
      span_name: row.summary || row.label,
      sequence: index + 1,
      trace_label: row.label,
      source_seq: row.sourceSeq,
      turn: row.turn,
      step: row.step,
      group: row.group,
      links,
      kind: visualKind(row.kind),
      start_ms: row.startMs,
      end_ms: row.endMs,
      latency_ms: row.latencyMs,
      status: row.status,
      token_usage: row.tokenUsage,
      input: {
        sequence: index + 1,
        label: row.label,
        summary: row.summary,
        sourceSeq: row.sourceSeq,
        turn: row.turn,
        step: row.step,
        group: row.group,
        callId: row.callId,
        payload: row.input,
      },
      output: row.output,
      error: row.error,
    }
  })
}

function inferStructureParents(rows: readonly TraceGraphRecord[]): Map<string, string[]> {
  const byRow = new Map<string, string[]>()
  const pendingInputsByTurn = new Map<string, string[]>()
  const pendingToolsByTurn = new Map<string, string[]>()

  for (const row of rows) {
    const key = turnKey(row)
    if (row.kind === 'message') {
      appendAll(byRow, row.id, pendingInputsByTurn.get(key) ?? EMPTY_LIST)
      appendAll(byRow, row.id, pendingToolsByTurn.get(key) ?? EMPTY_LIST)
      pendingInputsByTurn.set(key, [])
      pendingToolsByTurn.set(key, [])
    }
    if (isInputRecord(row)) appendAll(pendingInputsByTurn, key, [row.id])
    if (isToolRecord(row)) appendAll(pendingToolsByTurn, key, [row.id])
  }

  return byRow
}

function structureLinks(
  targetId: string,
  row: TraceGraphRecord,
  inferredParents: ReadonlyMap<string, readonly string[]>,
  idByRowId: ReadonlyMap<string, string>,
): Array<{ source_span_id: string; kind: 'structure' }> {
  const links: Array<{ source_span_id: string; kind: 'structure' }> = []
  const seen = new Set<string>()
  for (const rowId of [...row.structureParentIds ?? [], ...inferredParents.get(row.id) ?? []]) {
    const sourceId = idByRowId.get(rowId)
    if (sourceId === undefined || sourceId === targetId || seen.has(sourceId)) continue
    seen.add(sourceId)
    links.push({ source_span_id: sourceId, kind: 'structure' })
  }
  return links
}

function isInputRecord(row: TraceGraphRecord): boolean {
  return row.kind === 'system' || row.kind === 'user' || row.kind === 'context' || row.kind === 'compacted'
}

function isToolRecord(row: TraceGraphRecord): boolean {
  return row.kind === 'tool' || row.kind === 'subtool'
}

function turnKey(row: TraceGraphRecord): string {
  return `${row.turn ?? 0}`
}

function appendAll(map: Map<string, string[]>, key: string, values: readonly string[]): void {
  if (values.length === 0) return
  const existing = map.get(key)
  if (existing === undefined) {
    map.set(key, [...values])
    return
  }
  for (const value of values) {
    if (!existing.includes(value)) existing.push(value)
  }
}

function visualKind(kind: TrajectoryKind): SpanKind {
  switch (kind) {
    case 'message': return 'llm'
    case 'tool':
    case 'subtool': return 'tool'
    case 'compacted': return 'loop'
    case 'system':
    case 'user':
    case 'context': return 'other'
  }
}

function indexToolResults(nodes: readonly unknown[]): Map<string, Record<string, unknown>> {
  const results = new Map<string, Record<string, unknown>>()
  for (const node of objects(nodes)) {
    if (stringValue(node.kind) !== 'tool-result') continue
    const callId = stringValue(node.callId)
    if (callId !== undefined) results.set(callId, node)
  }
  return results
}

function representedAssistantSteps(
  nodes: readonly unknown[],
  partial: unknown,
  runningCalls: readonly unknown[],
): Set<string> {
  const represented = new Set<string>()
  for (const node of objects(nodes)) {
    if (stringValue(node.kind) !== 'assistant') continue
    const turn = numberValue(node.turn)
    const step = numberValue(node.step)
    if (turn !== undefined && step !== undefined && step > 0) represented.add(stepKey(turn, step))
  }
  const partialValue = recordValue(partial)
  const partialTurn = numberValue(partialValue?.turn)
  const partialStep = numberValue(partialValue?.step)
  if (partialTurn !== undefined && partialStep !== undefined && partialStep > 0) {
    represented.add(stepKey(partialTurn, partialStep))
  }
  for (const call of objects(runningCalls)) {
    const turn = numberValue(call.turn)
    const step = numberValue(call.step)
    if (turn !== undefined && step !== undefined && step > 0) represented.add(stepKey(turn, step))
  }
  return represented
}

function enclosingTurn(seq: number, nodes: readonly unknown[], partial: unknown): number {
  for (const node of objects(nodes)) {
    if (stringValue(node.kind) !== 'assistant') continue
    const nodeSeq = numberValue(node.seq)
    const turn = numberValue(node.turn)
    if (nodeSeq !== undefined && turn !== undefined && nodeSeq >= seq) return turn
  }
  return numberValue(recordValue(partial)?.turn) ?? 1
}

function promptTurn(change: Record<string, unknown>, nodes: readonly unknown[], partial: unknown): number {
  if (stringValue(change.kind) === 'initial') return firstVisibleTurn(nodes, partial)
  return enclosingTurn(numberValue(change.seq) ?? 0, nodes, partial)
}

function firstVisibleTurn(nodes: readonly unknown[], partial: unknown): number {
  for (const node of objects(nodes)) {
    const turn = numberValue(node.turn)
    if (turn !== undefined) return Math.max(1, turn)
  }
  return numberValue(recordValue(partial)?.turn) ?? 1
}

function promptChangeLabel(change: Record<string, unknown>): string {
  const kind = stringValue(change.kind)
  if (kind === 'initial') return 'Initial System Prompt'
  if (kind === 'system') return 'System Prompt Updated'
  if (kind === 'tools') return 'Tools Updated'
  return 'System Prompt and Tools Updated'
}

function recordDisplayText(cell: {
  readonly kind: TrajectoryKind
  readonly text: string
  readonly previewMarkdown?: string
  readonly inputDetail?: string
  readonly outputDetail?: string
  readonly thinkingDetail?: string
}): string {
  if (isToolCallOnly(cell)) return ''
  if (cell.previewMarkdown !== undefined) {
    const preview = markdownSummary(cell.previewMarkdown)
    if (cell.text === '') return preview
    return preview === '' ? cell.text : `${cell.text} · ${preview}`
  }
  if (cell.text !== '') return cell.text
  const markdown = cell.kind === 'user' || cell.kind === 'context'
    ? cell.inputDetail
    : cell.kind === 'message'
      ? cell.outputDetail ?? cell.thinkingDetail
      : undefined
  return markdown === undefined ? '' : markdownSummary(markdown)
}

function isToolCallOnly(cell: { readonly kind: TrajectoryKind; readonly text: string; readonly outputDetail?: string; readonly thinkingDetail?: string }): boolean {
  return cell.kind === 'message'
    && cell.outputDetail === undefined
    && cell.thinkingDetail === undefined
    && cell.text === 'Tool call only'
}

function toolSummary(name: string, argsRaw: string): string {
  if (argsRaw === '') return name
  const preview = markdownSummary(argsRaw)
  return preview === '' ? name : `${name} · ${preview}`
}

function summarizeResult(node: Record<string, unknown>): string {
  if (booleanValue(node.isError)) return recordValue(node.error) === undefined ? 'error' : stringValue(recordValue(node.error)?.code) ?? 'error'
  const preview = contentPreview(arrayValue(node.content))
  return preview === undefined ? 'No output' : markdownSummary(preview)
}

function resultErrorText(node: Record<string, unknown>): string | undefined {
  const error = recordValue(node.error)
  if (error === undefined) return blocksText(arrayValue(node.content))
  const name = stringValue(error.name)
  const code = stringValue(error.code)
  return [name, code].filter(Boolean).join(': ') || undefined
}

function summarizeAssistantActivity(blocks: readonly Record<string, unknown>[]): string {
  return blocks.some(block => stringValue(block.kind) === 'tool-call') ? 'Tool call only' : ''
}

function requestStatus(request: Record<string, unknown> | undefined): SpanStatus {
  const status = stringValue(request?.status)
  if (status === 'running') return 'running'
  if (status === 'error') return 'error'
  return 'ok'
}

function statusLabel(status: SpanStatus): string {
  if (status === 'running') return 'Running'
  if (status === 'error') return 'Error'
  return 'Complete'
}

function usageValue(value: unknown): TokenUsage | undefined {
  const usage = recordValue(value)
  if (usage === undefined) return undefined
  const input = sumNumbers(usage.inputTokens, usage.cacheReadTokens, usage.cacheWriteTokens)
  const output = sumNumbers(usage.outputTokens)
  if (input === 0 && output === 0) return undefined
  return { input, output, total: input + output + sumNumbers(usage.reasoningTokens) }
}

function blocksDetail(blocks: readonly unknown[] | undefined): unknown {
  if (blocks === undefined) return undefined
  return {
    text: blocksText(blocks),
    blocks,
  }
}

function blocksText(blocks: readonly unknown[] | undefined): string | undefined {
  if (blocks === undefined) return undefined
  const text = blocks
    .map(block => blockText(block))
    .filter((part): part is string => part !== undefined && part.length > 0)
    .join('\n\n')
  return text.length === 0 ? undefined : text
}

function blockText(block: unknown): string | undefined {
  const value = recordValue(block)
  if (value === undefined) return primitiveDetail(block)
  const type = stringValue(value.type)
  if (type === 'text' || type === 'reasoning') return stringValue(value.text)
  const kind = stringValue(value.kind)
  if (kind === 'text' || kind === 'reasoning') return stringValue(value.text)
  if (kind === 'tool-call') {
    const name = stringValue(value.name) ?? stringValue(value.callId) ?? 'tool'
    const args = stringValue(value.argsRaw)
    return args === undefined || args === '' ? name : `${name}\n${args}`
  }
  return primitiveDetail(value.content ?? value.block)
}

function detailContent(blocks: readonly unknown[] | undefined): string | undefined {
  return blocksText(blocks)
}

function contentPreview(blocks: readonly unknown[] | undefined): string | undefined {
  if (blocks === undefined) return undefined
  for (const block of objects(blocks)) {
    if (stringValue(block.type) === 'text' && typeof block.text === 'string') return block.text
  }
  return undefined
}

function markdownSummary(text: string): string {
  const source = text.slice(0, 2_048)
  const compact = source
    .replace(/```[\s\S]*?```/g, block => block.replace(/```[a-zA-Z0-9_-]*\n?|\n?```/g, ' '))
    .replace(/`([^`]+)`/g, '$1')
    .replace(/!\[([^\]]*)\]\([^)]+\)/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[*_~#>|\-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
  const preview = compact.slice(0, 512).trimEnd()
  return source.length < text.length || preview.length < compact.length ? `${preview}...` : preview
}

function stepKey(turn: number, step: number): string {
  return `${turn}\u0000${step}`
}

function uniqueId(seen: Set<string>, id: string): string {
  if (!seen.has(id)) {
    seen.add(id)
    return id
  }
  let index = 2
  while (seen.has(`${id}:${index}`)) index++
  const next = `${id}:${index}`
  seen.add(next)
  return next
}

function durationMs(start: number | undefined, end: number | undefined): number | undefined {
  return start === undefined || end === undefined ? undefined : Math.max(0, end - start)
}

function sumNumbers(...values: readonly unknown[]): number {
  let sum = 0
  for (const value of values) {
    const n = numberValue(value)
    if (n !== undefined) sum += n
  }
  return sum
}

function primitiveDetail(value: unknown): string | undefined {
  if (value === undefined || value === null) return undefined
  if (typeof value === 'string') return value
  if (typeof value === 'number' || typeof value === 'boolean') return String(value)
  try {
    return JSON.stringify(value)
  } catch {
    return String(value)
  }
}

function objects(values: readonly unknown[]): Array<Record<string, unknown>> {
  return values.filter(isRecord)
}

function recordValue(value: unknown): Record<string, unknown> | undefined {
  return isRecord(value) ? value : undefined
}

function arrayValue(value: unknown): readonly unknown[] | undefined {
  return Array.isArray(value) ? value : undefined
}

function stringValue(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

function numberValue(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

function booleanValue(value: unknown): boolean {
  return value === true
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}
