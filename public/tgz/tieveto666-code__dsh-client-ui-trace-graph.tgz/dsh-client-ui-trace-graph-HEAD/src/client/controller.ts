/**
 * Framework-free graph controller: the UI state the React tree renders.
 * Subscribable snapshot store; no React imports, so mount code and the graph
 * tree can share defaults without a framework dependency.
 */
import type { LayoutMode } from '../core/types.ts'

/** The controller snapshot React subscribes to. */
export interface TraceGraphControllerSnapshot {
  /** Current graph layout mode. */
  layoutMode: LayoutMode
}

export interface TraceGraphControllerDefaults {
  defaultLayout?: LayoutMode
}

const FALLBACK_LAYOUT: LayoutMode = 'dagre'

/**
 * The trace-graph view controller.
 */
export class TraceGraphController {
  private readonly listeners = new Set<() => void>()
  private snapshot: TraceGraphControllerSnapshot

  constructor(defaults: TraceGraphControllerDefaults = {}) {
    this.snapshot = {
      layoutMode: defaults.defaultLayout ?? FALLBACK_LAYOUT,
    }
  }

  /** Subscribe to snapshot changes. @returns unsubscribe. */
  subscribe(listener: () => void): () => void {
    this.listeners.add(listener)
    return () => { this.listeners.delete(listener) }
  }

  /** The current snapshot (stable identity between mutations). */
  getSnapshot(): TraceGraphControllerSnapshot {
    return this.snapshot
  }

  /** Switch the graph layout mode. */
  setLayoutMode(mode: LayoutMode): void {
    this.mutate((next) => { next.layoutMode = mode })
  }

  /** Drop every listener (fiber unload). */
  dispose(): void {
    this.listeners.clear()
  }

  private mutate(fn: (next: TraceGraphControllerSnapshot) => void): void {
    this.snapshot = { ...this.snapshot }
    fn(this.snapshot)
    for (const listener of this.listeners) listener()
  }
}
