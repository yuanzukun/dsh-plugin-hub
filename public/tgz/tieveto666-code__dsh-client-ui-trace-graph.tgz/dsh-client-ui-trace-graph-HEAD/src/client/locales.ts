/**
 * Trace-graph copy: zh-first dictionaries with an English fallback, selected
 * by the document language. Dependency-free so the graph tree and settings
 * card share one tiny lookup.
 */

/** zh dictionary (key-set source of truth). */
export const zh = {
  'view.title': '轨迹图谱',
  'view.realTrace': '真实轨迹',
  'view.layoutDagre': '层级布局',
  'view.layoutForce': '力导向布局',
  'view.edgeSequence': '执行顺序',
  'view.edgeStructure': '结构关系',
  'view.stats': '{count} 个节点 · 总耗时 {latency}',
  'view.empty': '暂无真实轨迹数据',
  'adapter.systemInitial': 'SYSTEM · Initial System Prompt',
  'adapter.systemUpdate': 'SYSTEM · Prompt Update',
  'adapter.user': 'USER',
  'adapter.steering': 'USER',
  'adapter.context': 'CONTEXT',
  'adapter.assistant': 'ASSISTANT',
  'adapter.tool': 'TOOL',
  'adapter.subtool': 'TOOL',
  'adapter.compaction': 'COMPACTION',
  'adapter.compactionRunning': 'COMPACTION · Running',
  'kind.llm': 'LLM',
  'kind.tool': '工具',
  'kind.loop': '循环',
  'kind.agent': '代理',
  'kind.root': '根',
  'kind.other': '其他',
  'node.latency': '延迟',
  'node.tokens': 'Token 输入/输出',
  'detail.close': '关闭详情',
  'detail.sequence': '轨迹序号',
  'detail.sourceSeq': '事件 Seq',
  'detail.turnStep': 'Turn / Step',
  'detail.group': '轨迹分组',
  'detail.latency': '延迟',
  'detail.status': '状态',
  'detail.status.ok': '成功',
  'detail.status.error': '失败',
  'detail.status.running': '运行中',
  'detail.tokenIn': 'Token 输入',
  'detail.tokenOut': 'Token 输出',
  'detail.start': '开始时间',
  'detail.end': '结束时间',
  'detail.input': '输入 Input',
  'detail.output': '输出 Output',
  'detail.none': '（无数据）',
  'detail.more': '… 共 {total} 项，仅展示前 {shown} 项',
  'settings.title': '轨迹图谱',
  'settings.description': '图谱视图的启用状态与默认布局。',
  'settings.enabled': '启用轨迹图谱',
  'settings.enabledHint': '关闭后会隐藏对话页里的轨迹图谱标签页。',
  'settings.announceToAgent': '向 agent 公告本插件',
  'settings.announceToAgentHint': '开启：每个 agent 的系统提示词包含本插件的说明。关闭：不公告，只有你提到时 agent 才知道。',
  'settings.defaultLayout': '默认布局',
  'settings.defaultLayoutHint': '图形视图的初始布局；工具栏仍可随时切换。',
  'settings.choice.layoutDagre': '层级布局（Dagre）',
  'settings.choice.layoutForce': '力导向布局（d3-force）',
  'settings.inherit': '继承',
  'settings.on': '开',
  'settings.off': '关',
  'settings.overridden': '已覆盖',
  'settings.reset': '恢复默认',
  'settings.notExposed': '当前 DSH 版本未向配置页开放本插件的设置命名空间，表单不可用。可直接编辑 ~/.dsh/settings.yaml，或将命名空间加入 dsh-host-apiproxy 的 WEB_SETTINGS_NAMESPACES 白名单后重启。',
  'settings.readOnly': '此部署的设置存储为只读。',
  'settings.expand': '展开设置',
  'settings.collapse': '收起设置',
  'settings.save': '保存',
  'settings.saving': '保存中…',
  'settings.discard': '放弃',
  'settings.unsaved': '未保存',
  'settings.saveFailed': '部署未接受这些值，已保留待你修正。',
  'settings.invalidNumber': '请输入数字，或留空使用默认值。',
}

/** en dictionary (complete mirror of the zh key set). */
export const en: Record<TraceGraphKey, string> = {
  'view.title': 'Trace Graph',
  'view.realTrace': 'Real Trajectory',
  'view.layoutDagre': 'Hierarchical',
  'view.layoutForce': 'Force Layout',
  'view.edgeSequence': 'Sequence',
  'view.edgeStructure': 'Structure',
  'view.stats': '{count} nodes · {latency} total',
  'view.empty': 'No real trajectory data',
  'adapter.systemInitial': 'SYSTEM · Initial System Prompt',
  'adapter.systemUpdate': 'SYSTEM · Prompt Update',
  'adapter.user': 'USER',
  'adapter.steering': 'USER',
  'adapter.context': 'CONTEXT',
  'adapter.assistant': 'ASSISTANT',
  'adapter.tool': 'TOOL',
  'adapter.subtool': 'TOOL',
  'adapter.compaction': 'COMPACTION',
  'adapter.compactionRunning': 'COMPACTION · Running',
  'kind.llm': 'LLM',
  'kind.tool': 'Tool',
  'kind.loop': 'Loop',
  'kind.agent': 'Agent',
  'kind.root': 'Root',
  'kind.other': 'Other',
  'node.latency': 'Latency',
  'node.tokens': 'Token in/out',
  'detail.close': 'Close detail',
  'detail.sequence': 'Record #',
  'detail.sourceSeq': 'Event seq',
  'detail.turnStep': 'Turn / Step',
  'detail.group': 'Group',
  'detail.latency': 'Latency',
  'detail.status': 'Status',
  'detail.status.ok': 'Succeeded',
  'detail.status.error': 'Failed',
  'detail.status.running': 'Running',
  'detail.tokenIn': 'Token in',
  'detail.tokenOut': 'Token out',
  'detail.start': 'Start time',
  'detail.end': 'End time',
  'detail.input': 'Input',
  'detail.output': 'Output',
  'detail.none': '(no data)',
  'detail.more': '... {total} items total, showing first {shown}',
  'settings.title': 'Trace Graph',
  'settings.description': 'Trace graph enablement and default layout.',
  'settings.enabled': 'Enable the trace graph',
  'settings.enabledHint': 'When off, the trace graph conversation tab is hidden.',
  'settings.announceToAgent': 'Announce the trace graph to agents',
  'settings.announceToAgentHint': 'On: every agent system prompt includes a note about this plugin. Off: no announcement; agents learn about it only when you mention it.',
  'settings.defaultLayout': 'Default layout',
  'settings.defaultLayoutHint': 'The initial graph layout; switchable at any time from the toolbar.',
  'settings.choice.layoutDagre': 'Hierarchical (Dagre)',
  'settings.choice.layoutForce': 'Force-directed (d3-force)',
  'settings.inherit': 'Inherit',
  'settings.on': 'On',
  'settings.off': 'Off',
  'settings.overridden': 'Overridden',
  'settings.reset': 'Reset to default',
  'settings.notExposed': 'This DSH version does not expose this plugin\'s settings namespace to the configuration page, so the form is unavailable. Edit ~/.dsh/settings.yaml directly, or add the namespace to dsh-host-apiproxy\'s WEB_SETTINGS_NAMESPACES allowlist and restart.',
  'settings.readOnly': 'This deployment stores settings read-only.',
  'settings.expand': 'Show settings',
  'settings.collapse': 'Hide settings',
  'settings.save': 'Save',
  'settings.saving': 'Saving…',
  'settings.discard': 'Discard',
  'settings.unsaved': 'Unsaved',
  'settings.saveFailed': 'The deployment did not accept these values; they were left for you to correct.',
  'settings.invalidNumber': 'Enter a number, or leave blank to use the default.',
}

/** The dictionary key union. */
export type TraceGraphKey = keyof typeof zh

/** The settings-card slice of the trace-graph dictionary. */
export type SettingsCardKey = TraceGraphKey

/** Active dictionary, picked by the document language at call time. */
export function dictionary(): Record<TraceGraphKey, string> {
  const lang = typeof document !== 'undefined' ? document.documentElement.lang : 'zh'
  return lang.toLowerCase().startsWith('en') ? en : zh
}

/** Translate a key with optional {name} template params. */
export function t(key: TraceGraphKey, params?: Record<string, string>): string {
  let text: string = dictionary()[key]
  if (params !== undefined) {
    for (const [name, value] of Object.entries(params)) {
      text = text.replaceAll(`{${name}}`, value)
    }
  }
  return text
}

/** Locale key of a category label (kindMeta.label is the neutral fallback). */
export function kindLabelKey(kind: 'llm' | 'tool' | 'loop' | 'agent' | 'root' | 'other'): TraceGraphKey {
  return `kind.${kind}` as TraceGraphKey
}
