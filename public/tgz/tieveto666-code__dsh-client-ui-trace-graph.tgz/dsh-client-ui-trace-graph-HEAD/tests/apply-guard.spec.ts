/**
 * Apply guard tests: the trace-graph client bundle must mount exactly once per
 * page lifetime, even when the module factory runs more than once (duplicated
 * client injection). The full apply() is not exercised here because it wires
 * DOM mounting, React portals, and the runtime context; the guard itself is
 * the unit under test, and apply() early-returns on a losing claim.
 */
import { beforeEach, describe, expect, it } from 'vitest'
import { claimTraceGraphApply, releaseTraceGraphApply } from '../src/client/apply-guard.ts'

describe('claimTraceGraphApply', () => {
  beforeEach(() => {
    globalThis.__dshTraceGraphApplied = undefined
  })

  it('grants the first claim', () => {
    expect(claimTraceGraphApply()).toBe(true)
  })

  it('rejects later claims in the same page lifetime', () => {
    expect(claimTraceGraphApply()).toBe(true)
    expect(claimTraceGraphApply()).toBe(false)
    expect(claimTraceGraphApply()).toBe(false)
  })

  it('keeps rejecting across independent module instances', () => {
    // Simulates two factory runs: each run is a separate module instance,
    // but they share one globalThis flag.
    expect(claimTraceGraphApply()).toBe(true)
    expect(claimTraceGraphApply()).toBe(false)
    expect(globalThis.__dshTraceGraphApplied).toBe(true)
  })

  it('grants again after the claim is released (fiber unload / hot-reload)', () => {
    expect(claimTraceGraphApply()).toBe(true)
    releaseTraceGraphApply()
    expect(claimTraceGraphApply()).toBe(true)
  })

  it('grants again after a full page reload (flag cleared)', () => {
    expect(claimTraceGraphApply()).toBe(true)
    globalThis.__dshTraceGraphApplied = undefined
    expect(claimTraceGraphApply()).toBe(true)
  })
})
