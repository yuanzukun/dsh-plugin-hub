/**
 * Settings slot guard: the trace graph registers as a first-party plugin
 * configuration card without the optional dsh-web-ui group plugin.
 */
/// <reference types="node" />
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

const client = readFileSync(new URL('../src/client/index.ts', import.meta.url), 'utf8')
const card = readFileSync(new URL('../src/client/TraceGraphSettingsCard.tsx', import.meta.url), 'utf8')
const viewMount = readFileSync(new URL('../src/client/mount-view.tsx', import.meta.url), 'utf8')

describe('settings slot registration', () => {
  it('registers the graph in the official conversation view slot', () => {
    expect(client).toContain("'conversation.view': { kind: 'list'; scope: 'session'")
    expect(viewMount).toContain("ctx.slots.inject('conversation.view'")
    expect(viewMount).toContain("name: 'conversation.view'")
    expect(viewMount).not.toContain("data-conversation-composer-overlay")
    expect(viewMount).not.toContain('createRoot')
  })

  it('registers the card in the official plugin configuration slot', () => {
    expect(client).toContain("ctx.slots.inject('settings.plugin.item'")
    expect(client).toContain("name: 'settings.plugin.item'")
    expect(card).toContain("PropsRuntime<'settings.plugin.item'>")
  })

  it('does not depend on the optional Web UI plugin group slot', () => {
    expect(client).not.toContain('web-ui.plugin.item')
    expect(card).not.toContain('web-ui.plugin.item')
  })
})
