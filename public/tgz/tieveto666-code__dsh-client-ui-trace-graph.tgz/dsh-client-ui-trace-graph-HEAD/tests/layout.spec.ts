/**
 * Layout tests: both layout modes emit finite positions for every node, and
 * applyLayout derives handle sides plus particle counts without dropping
 * nodes or edges.
 */
import { describe, expect, it } from 'vitest'
import { buildGraph } from '../src/core/transform.ts'
import { applyLayout, dagreLayout, forceLayout } from '../src/core/layout.ts'
import { TRACE_A } from '../src/core/mock.ts'

describe('dagreLayout', () => {
  it('positions every node with finite top-left coordinates', () => {
    const bundle = buildGraph(TRACE_A.spans)
    const pos = dagreLayout(bundle.nodes, bundle.edges)
    expect(pos.size).toBe(bundle.nodes.length)
    for (const [id, p] of pos) {
      expect(Number.isFinite(p.x)).toBe(true)
      expect(Number.isFinite(p.y)).toBe(true)
      expect(id).toBeTruthy()
    }
  })

  it('lays children below their parents (rank order)', () => {
    const bundle = buildGraph(TRACE_A.spans)
    const pos = dagreLayout(bundle.nodes, bundle.edges)
    for (const e of bundle.edges) {
      const p = pos.get(e.source)
      const c = pos.get(e.target)
      expect(p).toBeDefined()
      expect(c).toBeDefined()
      expect(c!.y).toBeGreaterThan(p!.y)
    }
  })
})

describe('forceLayout', () => {
  it('positions every node with finite non-negative coordinates', () => {
    const bundle = buildGraph(TRACE_A.spans)
    const pos = forceLayout(bundle.nodes, bundle.edges)
    expect(pos.size).toBe(bundle.nodes.length)
    for (const p of pos.values()) {
      expect(Number.isFinite(p.x)).toBe(true)
      expect(Number.isFinite(p.y)).toBe(true)
      expect(p.x).toBeGreaterThanOrEqual(0)
      expect(p.y).toBeGreaterThanOrEqual(0)
    }
  })
})

describe('applyLayout', () => {
  it('keeps node and edge counts and assigns handle sides', () => {
    const bundle = buildGraph(TRACE_A.spans)
    const laid = applyLayout(bundle.nodes, bundle.edges, 'dagre')
    expect(laid.nodes).toHaveLength(bundle.nodes.length)
    expect(laid.edges).toHaveLength(bundle.edges.length)
    for (const e of laid.edges) {
      expect(e.sourceHandle).toMatch(/^out-(top|bottom|left|right)$/)
      expect(e.targetHandle).toMatch(/^in-(top|bottom|left|right)$/)
      expect(['top', 'bottom', 'left', 'right']).toContain(e.data?.sourcePosition)
      expect(['top', 'bottom', 'left', 'right']).toContain(e.data?.targetPosition)
    }
  })

  it('reduces the particle count for large graphs', () => {
    const bundle = buildGraph(TRACE_A.spans)
    const many = { ...bundle, edges: Array.from({ length: 61 }, (_, i) => bundle.edges[0]) }
    const laid = applyLayout(bundle.nodes, many.edges, 'force')
    expect(laid.edges[0]?.data?.particleCount).toBe(1)
  })
})
