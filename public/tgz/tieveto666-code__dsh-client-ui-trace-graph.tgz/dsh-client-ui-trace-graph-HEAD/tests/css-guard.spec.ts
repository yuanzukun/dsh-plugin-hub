/**
 * Trace graph CSS guards: the graph must stay in its conversation-view
 * container and the sidebar entry must ride the shell's nav-item tokens for
 * theme parity.
 */
/// <reference types="node" />
import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'

const css = readFileSync(new URL('../src/client/tracegraph.module.css', import.meta.url), 'utf8')
const reactFlowBase = readFileSync(
  new URL('../src/client/reactflow-base.module.css', import.meta.url),
  'utf8',
)

describe('tracegraph.module.css conversation-view containment', () => {
  it('does not take over the host conversation column', () => {
    expect(css).not.toContain('data-dsh-tracegraph-active')
    expect(css).not.toContain('data-dsh-tracegraph-view')
    expect(css).not.toContain("[data-pane='conversation']")
    expect(css).not.toContain("[class*='centerCol']")
    expect(css).not.toContain('[data-dsh-frame]')
    expect(css).not.toContain('data-conversation-composer-overlay')
    expect(css).not.toContain('--dsh-composer-height')
    expect(css).not.toContain('--tg-composer-clearance')
    expect(css).not.toContain('display: none !important')
  })

  it('scopes ReactFlow global selectors under the plugin panel', () => {
    expect(css).not.toMatch(/(?:^|\n):global\(\.react-flow/)
    expect(css).toMatch(/\.panel\s+:global\(\.react-flow\)/)
    expect(css).toMatch(/\.panel\s+:global\(\.react-flow__node\)/)
    expect(css).toMatch(/\.panel\s+:global\(\.react-flow__edge\)/)
    expect(reactFlowBase).not.toMatch(/(?:^|\n):global\(\.react-flow/)
    expect(reactFlowBase).not.toMatch(/,\s*:global\(\.react-flow/)
    expect(reactFlowBase).not.toMatch(/(?:^|\n)\.react-flow/)
    expect(reactFlowBase).not.toMatch(/(?:^|\n)\s+\.react-flow/)
    expect(reactFlowBase).toContain('[data-dsh-tracegraph-panel] :global(.react-flow)')
    expect(reactFlowBase).toContain('[data-dsh-tracegraph-panel] :global(.react-flow__node)')
    expect(reactFlowBase).toContain('[data-dsh-tracegraph-panel] :global(.react-flow__edge)')
  })

  it('keeps the graph constrained to its view container', () => {
    expect(css).toMatch(/\.panel\s*\{[^}]*position: relative/s)
    expect(css).toMatch(/\.panel\s*\{[^}]*overflow: hidden/s)
    expect(css).toMatch(/\.graphWrap\s*\{[^}]*height: 100%/s)
    expect(css).toMatch(/\.list\s*\{[^}]*inset: 0/s)
  })

  it('rides the shell nav-item tokens for the sidebar entry', () => {
    expect(css).toMatch(/\.entry\s*\{[^}]*color: var\(--dsw-alias-label-secondary/s)
    expect(css).toMatch(/\.entry:hover\s*\{[^}]*var\(--dsw-specific-sidebar-nav-item-hover/s)
    expect(css).toMatch(/\.entry\[data-active\]\s*\{[^}]*var\(--dsw-specific-sidebar-nav-item-active/s)
  })

  it('collapses the entry to icon-only on the 56px rail', () => {
    expect(css).toMatch(/\.entry\[data-collapsed\]\s*\.entryLabel\s*\{\s*display: none/s)
  })

  it('contains no emoji presentation characters (repo-wide ban)', () => {
    // U+23F1/U+26A1/U+26A0/U+2699 and friends are forbidden; the graph uses
    // ◷ / Σ / ! / ⌘ / ✕ style glyphs only. Spelled as escapes so this file
    // itself stays clean of the banned characters.
    expect(css).not.toMatch(/[\u23F1\u26A1\u26A0\u2699\u{1F680}\u{1F389}\u{1F527}\u2705\u274C]/u)
  })
})
