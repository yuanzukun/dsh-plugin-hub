/**
 * Transform pipeline tests: flattening nested and flat span inputs, parent
 * chain resolution, synthetic roots, cycle protection, and hover relations.
 */
import { describe, expect, it } from 'vitest'
import type { TraceSpan } from '../src/core/types.ts'
import { buildGraph, buildRelations, flattenSpans, VIRTUAL_ROOT_ID } from '../src/core/transform.ts'

function span(id: string, name: string, extra: Partial<TraceSpan> = {}): TraceSpan {
  return { span_id: id, parent_span_id: null, span_name: name, ...extra }
}

describe('flattenSpans', () => {
  it('flattens a nested tree in pre-order with nesting parents', () => {
    const tree = span('a', 'root', {
      children: [
        span('b', 'child', { children: [span('c', 'grandchild')] }),
        span('d', 'sibling'),
      ],
    })
    const flat = flattenSpans([tree])
    expect(flat.map(f => f.span.span_id)).toEqual(['a', 'b', 'c', 'd'])
    expect(flat[1].nestedParentId).toBe('a')
    expect(flat[2].nestedParentId).toBe('b')
    expect(flat[3].nestedParentId).toBe('a')
  })

  it('keeps the first occurrence of a duplicated span id', () => {
    const dup = span('x', 'twice')
    const flat = flattenSpans([dup, dup])
    expect(flat).toHaveLength(1)
  })
})

describe('buildGraph', () => {
  it('builds nodes and parent-to-child edges from a nested tree', () => {
    const tree = span('a', 'root', { children: [span('b', 'child'), span('c', 'sibling')] })
    const bundle = buildGraph([tree])
    expect(bundle.nodes.map(n => n.id).sort()).toEqual(['a', 'b', 'c'])
    expect(bundle.edges).toHaveLength(2)
    expect(bundle.hasVirtualRoot).toBe(false)
    expect(bundle.parentOf.get('b')).toBe('a')
    expect(bundle.childrenOf.get('a')?.sort()).toEqual(['b', 'c'])
  })

  it('supports the flat parent_span_id form', () => {
    const bundle = buildGraph([
      span('r', 'root'),
      { ...span('k', 'kid'), parent_span_id: 'r' },
    ])
    expect(bundle.edges.map(e => [e.source, e.target])).toEqual([['r', 'k']])
  })

  it('prefers a valid explicit parent_span_id over the nesting parent', () => {
    const bundle = buildGraph([
      span('p', 'parent'),
      { ...span('n', 'node', { parent_span_id: null }), parent_span_id: 'p' },
    ])
    expect(bundle.parentOf.get('n')).toBe('p')
  })

  it('adds a synthetic root for multiple root spans and links every root to it', () => {
    const bundle = buildGraph([span('r1', 'one'), span('r2', 'two')])
    expect(bundle.hasVirtualRoot).toBe(true)
    const virtual = bundle.nodes.find(n => n.id === VIRTUAL_ROOT_ID)
    expect(virtual?.data.isVirtualRoot).toBe(true)
    expect(bundle.parentOf.get('r1')).toBe(VIRTUAL_ROOT_ID)
    expect(bundle.parentOf.get('r2')).toBe(VIRTUAL_ROOT_ID)
  })

  it('drops cycle edges instead of losing spans', () => {
    const a = { ...span('a', 'node-a'), parent_span_id: 'b' }
    const b = { ...span('b', 'node-b'), parent_span_id: 'a' }
    const bundle = buildGraph([a, b])
    expect(bundle.nodes.map(n => n.id).sort()).toEqual(['a', 'b'])
    // The cycle edge (child not deeper than parent) is skipped.
    expect(bundle.edges.length).toBeLessThanOrEqual(1)
  })

  it('computes duration ratios against the whole trace', () => {
    const bundle = buildGraph([
      { ...span('p', 'parent'), start_ms: 0, end_ms: 1000 },
      { ...span('c', 'child', { parent_span_id: 'p' }), start_ms: 100, end_ms: 600 },
    ])
    const child = bundle.nodes.find(n => n.id === 'c')!
    expect(child.data.durationRatio).toBeCloseTo(0.5, 5)
  })
})

describe('buildRelations', () => {
  const tree = span('r', 'root', {
    children: [
      span('m', 'mid', {
        children: [span('x', 'leaf-x'), span('y', 'leaf-y')],
      }),
      span('s', 'side'),
    ],
  })
  const bundle = buildGraph([tree])

  it('collects all ancestors and descendants', () => {
    const rel = buildRelations(bundle.parentOf, bundle.childrenOf, 'm')
    expect([...rel.related].sort()).toEqual(['m', 'r', 'x', 'y'])
  })

  it('marks the direct parent and children separately', () => {
    const rel = buildRelations(bundle.parentOf, bundle.childrenOf, 'm')
    expect([...rel.direct].sort()).toEqual(['r', 'x', 'y'])
  })

  it('keeps unrelated branches out of the relation', () => {
    const rel = buildRelations(bundle.parentOf, bundle.childrenOf, 'x')
    expect(rel.related.has('s')).toBe(false)
    expect(rel.direct.has('m')).toBe(true)
  })
})
