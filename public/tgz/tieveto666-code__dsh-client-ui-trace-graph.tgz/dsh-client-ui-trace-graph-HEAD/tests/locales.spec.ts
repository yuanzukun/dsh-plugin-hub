/**
 * Locale parity tests: the en dictionary must mirror the zh key set exactly
 * (zh is the key-set source of truth), and the settings-card chrome keys the
 * shared PluginSettingsCard renders must exist in both dictionaries.
 */
import { describe, expect, it } from 'vitest'
import { en, zh } from '../src/client/locales.ts'

describe('locale dictionaries', () => {
  it('mirrors every zh key in en (and vice versa)', () => {
    const zhKeys = Object.keys(zh).sort()
    const enKeys = Object.keys(en).sort()
    expect(enKeys).toEqual(zhKeys)
  })

  it('ships the settings-card chrome keys the shared card renders', () => {
    const required = [
      'settings.title',
      'settings.description',
      'settings.inherit',
      'settings.on',
      'settings.off',
      'settings.overridden',
      'settings.reset',
      'settings.notExposed',
      'settings.readOnly',
      'settings.expand',
      'settings.collapse',
      'settings.save',
      'settings.saving',
      'settings.discard',
      'settings.unsaved',
      'settings.saveFailed',
      'settings.invalidNumber',
    ] as const
    for (const key of required) {
      expect(zh[key], `zh missing ${key}`).toBeTruthy()
      expect(en[key], `en missing ${key}`).toBeTruthy()
    }
  })

  it('ships a localized label for every category', () => {
    for (const kind of ['llm', 'tool', 'loop', 'agent', 'root', 'other'] as const) {
      expect(zh[`kind.${kind}`]).toBeTruthy()
      expect(en[`kind.${kind}`]).toBeTruthy()
    }
  })
})
