import type { ReactElement } from 'react';
import type { EdgeGeometry } from '../../core/edgePath.ts';
export interface FlowParticleOptions {
    count?: number;
    color: string;
}
/**
 * Return the particles drifting along one edge and register them with the
 * shared engine.
 * @param edgeId - edge id (the engine's registration key).
 * @param geom - edge geometry; null renders and registers nothing.
 */
export declare function useFlowParticles(edgeId: string, geom: EdgeGeometry | null, options: FlowParticleOptions): ReactElement[] | null;
