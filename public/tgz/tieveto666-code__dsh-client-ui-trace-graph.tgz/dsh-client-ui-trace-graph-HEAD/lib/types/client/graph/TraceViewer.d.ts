import type { CSSProperties, ReactNode } from 'react';
import type { LayoutMode, TraceSpan } from '../../core/types.ts';
export interface TraceViewerProps {
    /** Nested span tree (or a flat parent_span_id array). */
    spans: TraceSpan[];
    /** Trace name; used as the synthetic root title for multi-root traces. */
    traceName?: string;
    /** Controlled layout mode; falls back to internal state when omitted. */
    layoutMode?: LayoutMode;
    /** Controlled layout change; called with the next mode. */
    onLayoutModeChange?: (mode: LayoutMode) => void;
    /** Default layout (uncontrolled mode only). */
    defaultLayout?: LayoutMode;
    /** Extra nodes rendered after the title. */
    headerExtra?: ReactNode;
    /** Whether to render the standalone header. */
    showHeader?: boolean;
    className?: string;
    style?: CSSProperties;
}
export declare function TraceViewer({ spans, traceName, layoutMode, onLayoutModeChange, defaultLayout, headerExtra, showHeader, className, style, }: TraceViewerProps): import("react").JSX.Element;
