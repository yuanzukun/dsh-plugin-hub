import type { TraceSpan } from '../../core/types.ts';
interface DetailPanelProps {
    span: TraceSpan;
    onClose: () => void;
}
export declare function DetailPanel({ span, onClose }: DetailPanelProps): import("react").JSX.Element;
export {};
