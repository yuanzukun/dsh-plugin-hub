import type { EdgeProps } from '@xyflow/react';
import type { TraceEdge as TraceEdgeType } from '../../core/types.ts';
declare function TraceEdgeComponent(props: EdgeProps<TraceEdgeType>): import("react").JSX.Element;
export declare const TraceEdge: import("react").MemoExoticComponent<typeof TraceEdgeComponent>;
export {};
