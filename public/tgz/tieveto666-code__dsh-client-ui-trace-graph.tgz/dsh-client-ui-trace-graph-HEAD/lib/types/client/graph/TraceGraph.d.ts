import type { LayoutMode, TraceSpan } from '../../core/types.ts';
export interface TraceGraphProps {
    /** Span tree (nested or flat form). */
    spans: TraceSpan[];
    /** Trace name; the synthetic root title for multi-root traces. */
    traceName?: string;
    layoutMode: LayoutMode;
    onLayoutModeChange: (mode: LayoutMode) => void;
    selectedId: string | null;
    onSelect: (id: string | null) => void;
}
/** Outer Provider wrapper: useReactFlow/fitView need it. */
export declare function TraceGraph(props: TraceGraphProps): import("react").JSX.Element;
