import type { TraceGraphController } from '../controller.ts';
import { type TraceGraphUseSession } from '../trajectory-adapter.ts';
interface TraceGraphAppProps {
    controller: TraceGraphController;
    useSession: TraceGraphUseSession;
}
/** The panel's React tree, driven entirely by the controller snapshot. */
export declare function TraceGraphApp({ controller, useSession }: TraceGraphAppProps): import("react").JSX.Element;
export {};
