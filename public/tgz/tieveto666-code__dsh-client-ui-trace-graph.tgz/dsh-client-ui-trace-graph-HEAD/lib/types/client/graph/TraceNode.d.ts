import type { NodeProps } from '@xyflow/react';
import type { TraceNode as TraceNodeType } from '../../core/types.ts';
declare function TraceNodeComponent({ data, selected }: NodeProps<TraceNodeType>): import("react").JSX.Element;
export declare const TraceNode: import("react").MemoExoticComponent<typeof TraceNodeComponent>;
export {};
