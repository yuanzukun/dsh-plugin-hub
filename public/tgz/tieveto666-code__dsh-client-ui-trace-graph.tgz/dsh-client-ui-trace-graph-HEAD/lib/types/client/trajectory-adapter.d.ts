import type { SpanStatus, TokenUsage, TraceSpan } from '../core/types.ts';
/** Minimal session snapshot surface supplied by the official conversation view slot. */
export interface TraceGraphSessionSnapshot {
    readonly views: {
        get(name: string): unknown;
    };
    readonly nodes?: readonly unknown[];
    readonly partial?: unknown;
    readonly runningCalls?: readonly unknown[];
}
/** React selector hook supplied by the conversation view slot. */
export type TraceGraphUseSession = <T>(selector: (snapshot: TraceGraphSessionSnapshot) => T) => T;
export interface TrajectoryTraceProjection {
    readonly traceName: string;
    readonly spans: readonly TraceSpan[];
}
export interface ProjectionInput {
    readonly trajectory: unknown;
    readonly fallbackNodes: readonly unknown[];
    readonly fallbackPartial: unknown;
    readonly fallbackRunningCalls: readonly unknown[];
}
export type TrajectoryKind = 'system' | 'user' | 'context' | 'compacted' | 'message' | 'tool' | 'subtool';
export interface TraceGraphRecord {
    readonly id: string;
    readonly label: string;
    readonly kind: TrajectoryKind;
    readonly summary: string;
    readonly startMs?: number;
    readonly endMs?: number;
    readonly latencyMs?: number;
    readonly status: SpanStatus;
    readonly tokenUsage?: TokenUsage;
    readonly input?: unknown;
    readonly output?: unknown;
    readonly error?: string;
    readonly sourceSeq?: number;
    readonly turn?: number;
    readonly step?: number;
    readonly group?: string;
    readonly callId?: string;
    readonly structureParentIds?: readonly string[];
}
/** Project the same live trajectory snapshot as the official "轨迹" tab into ordered TraceSpan nodes. */
export declare function useTrajectoryTrace(useSession: TraceGraphUseSession): TrajectoryTraceProjection;
export declare function projectTrajectory(input: ProjectionInput): TrajectoryTraceProjection;
