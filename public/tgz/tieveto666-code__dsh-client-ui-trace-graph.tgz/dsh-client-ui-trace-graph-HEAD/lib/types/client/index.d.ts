/**
 * Trace-graph client plugin: wires the framework-free controller to the real
 * client runtime and mounts the conversation-view tab plus the official
 * settings card.
 *
 * Failure policy: DOM mounting problems are logged, never thrown — the web
 * shell fails the whole boot when a plugin apply throws, and an external
 * plugin must not take the GUI down.
 */
import type { ClientContext, SettingsScope, SettingsScopeSpec } from '@deepseek-ai/dsh-client-runtime/client';
import { type TraceGraphKey } from './locales.ts';
import './reactflow-base.module.css';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Trace-graph surface copy. */
        'trace-graph': TraceGraphKey;
    }
    interface SlotMap {
        /** One view tab inside the official conversation view strip. */
        'conversation.view': {
            kind: 'list';
            scope: 'session';
            owner: TraceGraphConversationViewOwnerProps;
        };
        /** One plugin card inside the official plugin configuration section. */
        'settings.plugin.item': {
            kind: 'list';
            scope: 'root';
            owner: TraceGraphSettingsPluginItemOwnerProps;
        };
    }
}
/** Owner share of a conversation view; the runtime supplies session hooks at render time. */
export interface TraceGraphConversationViewOwnerProps {
    /** Marker field: no registration-time owner props are required. */
    children?: never;
}
/** Owner share of a plugin card (the section supplies nothing). */
export interface TraceGraphSettingsPluginItemOwnerProps {
    /** Marker field: card owner props are intentionally empty. */
    children?: never;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        /**
         * Optional rc.6 compatibility binder provided by dsh-web-ui-settings;
         * absent when that group plugin is not installed, so callers fall back to
         * the official settings scope.
         */
        webUiSettings?: {
            bind<S>(spec: SettingsScopeSpec<S>): SettingsScope<S>;
        };
    }
}
/** Required services (fiber inject waiting — the runtime must be up first). */
export declare const inject: string[];
/**
 * Mount the trace graph.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
