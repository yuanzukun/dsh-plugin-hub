/** Conversation view registration for the trace graph tab. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import type { TraceGraphController } from './controller.ts';
/** Stable id of the trace graph conversation view entry. */
export declare const TRACE_GRAPH_VIEW_ID = "trace-graph";
/**
 * Register the graph as a regular conversation view tab.
 * @param ctx - client root context.
 * @param controller - the panel controller driving the view.
 * @param label - localized tab label.
 * @returns disposer unregistering the tab.
 */
export declare function mountView(ctx: ClientContext, controller: TraceGraphController, label: () => string): () => void;
