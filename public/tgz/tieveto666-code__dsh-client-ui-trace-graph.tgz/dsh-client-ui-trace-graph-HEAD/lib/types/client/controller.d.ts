/**
 * Framework-free graph controller: the UI state the React tree renders.
 * Subscribable snapshot store; no React imports, so mount code and the graph
 * tree can share defaults without a framework dependency.
 */
import type { LayoutMode } from '../core/types.ts';
/** The controller snapshot React subscribes to. */
export interface TraceGraphControllerSnapshot {
    /** Current graph layout mode. */
    layoutMode: LayoutMode;
}
export interface TraceGraphControllerDefaults {
    defaultLayout?: LayoutMode;
}
/**
 * The trace-graph view controller.
 */
export declare class TraceGraphController {
    private readonly listeners;
    private snapshot;
    constructor(defaults?: TraceGraphControllerDefaults);
    /** Subscribe to snapshot changes. @returns unsubscribe. */
    subscribe(listener: () => void): () => void;
    /** The current snapshot (stable identity between mutations). */
    getSnapshot(): TraceGraphControllerSnapshot;
    /** Switch the graph layout mode. */
    setLayoutMode(mode: LayoutMode): void;
    /** Drop every listener (fiber unload). */
    dispose(): void;
    private mutate;
}
