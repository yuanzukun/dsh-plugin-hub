/**
 * The trace-graph settings card: enablement, agent announcement, default
 * layout. Registers into the `settings.plugin.item` slot the plugin-
 * configuration section renders, bound to the `trace-graph` settings
 * namespace.
 */
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SettingsScope, SnapshotStore } from '@deepseek-ai/dsh-client-runtime/client';
import { type CardActions, type CardShell, type FieldState as CardFieldState } from './settings-form.ts';
/** The trace-graph fields this card edits (the namespace's full schema). */
export interface TraceGraphSettings {
    /** Master switch for the plugin. */
    enabled?: boolean;
    /** Whether the plugin announces itself in every agent's system prompt. */
    announceToAgent?: boolean;
    /** Initial graph layout. */
    defaultLayout?: 'dagre' | 'force';
}
/** What the trace-graph card renders. */
export interface TraceGraphSettingsCardState extends CardShell {
    /** Master switch. */
    enabled: CardFieldState;
    /** System-prompt announcement flag. */
    announceToAgent: CardFieldState;
    /** Initial graph layout. */
    defaultLayout: CardFieldState;
}
/** The registration-side face the card's slot entry injects. */
export interface TraceGraphSettingsCardFace extends CardActions {
    hooks: {
        /** Card snapshot bound by the renderer as useTraceGraphSettingsCard. */
        traceGraphSettingsCard: SnapshotStore<TraceGraphSettingsCardState>;
    };
}
/** Bridges the `trace-graph` scope onto the card's staged form. */
export declare class TraceGraphSettingsCardController {
    private readonly form;
    private readonly store;
    /** @param scope - the bound settings scope for the `trace-graph` namespace. */
    constructor(scope: SettingsScope<TraceGraphSettings>);
    private projection;
    /**
     * Build the face the card's slot registration injects.
     * @returns the card's snapshot and its form actions.
     */
    inject(): TraceGraphSettingsCardFace;
}
/** Props the renderer binds for the trace-graph card. */
export type TraceGraphSettingsCardProps = PropsRuntime<'settings.plugin.item'> & PropsLocale<'trace-graph'> & InjectFace<TraceGraphSettingsCardFace>;
/**
 * Render the trace-graph card.
 * @param props - locale copy, the card snapshot, and its form actions.
 * @returns the card.
 */
export declare function TraceGraphSettingsCard(props: TraceGraphSettingsCardProps): import("react").JSX.Element;
