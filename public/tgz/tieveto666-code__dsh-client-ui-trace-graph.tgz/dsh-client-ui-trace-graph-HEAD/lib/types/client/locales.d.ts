/**
 * Trace-graph copy: zh-first dictionaries with an English fallback, selected
 * by the document language. Dependency-free so the graph tree and settings
 * card share one tiny lookup.
 */
/** zh dictionary (key-set source of truth). */
export declare const zh: {
    'view.title': string;
    'view.realTrace': string;
    'view.layoutDagre': string;
    'view.layoutForce': string;
    'view.edgeSequence': string;
    'view.edgeStructure': string;
    'view.stats': string;
    'view.empty': string;
    'adapter.systemInitial': string;
    'adapter.systemUpdate': string;
    'adapter.user': string;
    'adapter.steering': string;
    'adapter.context': string;
    'adapter.assistant': string;
    'adapter.tool': string;
    'adapter.subtool': string;
    'adapter.compaction': string;
    'adapter.compactionRunning': string;
    'kind.llm': string;
    'kind.tool': string;
    'kind.loop': string;
    'kind.agent': string;
    'kind.root': string;
    'kind.other': string;
    'node.latency': string;
    'node.tokens': string;
    'detail.close': string;
    'detail.sequence': string;
    'detail.sourceSeq': string;
    'detail.turnStep': string;
    'detail.group': string;
    'detail.latency': string;
    'detail.status': string;
    'detail.status.ok': string;
    'detail.status.error': string;
    'detail.status.running': string;
    'detail.tokenIn': string;
    'detail.tokenOut': string;
    'detail.start': string;
    'detail.end': string;
    'detail.input': string;
    'detail.output': string;
    'detail.none': string;
    'detail.more': string;
    'settings.title': string;
    'settings.description': string;
    'settings.enabled': string;
    'settings.enabledHint': string;
    'settings.announceToAgent': string;
    'settings.announceToAgentHint': string;
    'settings.defaultLayout': string;
    'settings.defaultLayoutHint': string;
    'settings.choice.layoutDagre': string;
    'settings.choice.layoutForce': string;
    'settings.inherit': string;
    'settings.on': string;
    'settings.off': string;
    'settings.overridden': string;
    'settings.reset': string;
    'settings.notExposed': string;
    'settings.readOnly': string;
    'settings.expand': string;
    'settings.collapse': string;
    'settings.save': string;
    'settings.saving': string;
    'settings.discard': string;
    'settings.unsaved': string;
    'settings.saveFailed': string;
    'settings.invalidNumber': string;
};
/** en dictionary (complete mirror of the zh key set). */
export declare const en: Record<TraceGraphKey, string>;
/** The dictionary key union. */
export type TraceGraphKey = keyof typeof zh;
/** The settings-card slice of the trace-graph dictionary. */
export type SettingsCardKey = TraceGraphKey;
/** Active dictionary, picked by the document language at call time. */
export declare function dictionary(): Record<TraceGraphKey, string>;
/** Translate a key with optional {name} template params. */
export declare function t(key: TraceGraphKey, params?: Record<string, string>): string;
/** Locale key of a category label (kindMeta.label is the neutral fallback). */
export declare function kindLabelKey(kind: 'llm' | 'tool' | 'loop' | 'agent' | 'root' | 'other'): TraceGraphKey;
