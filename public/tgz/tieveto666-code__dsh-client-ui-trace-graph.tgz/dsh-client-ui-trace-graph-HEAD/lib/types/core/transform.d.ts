import type { TraceSpan, GraphBundle } from './types.ts';
/** Fixed id of the synthetic root node. */
export declare const VIRTUAL_ROOT_ID = "__trace_root__";
/** A flattened span with its nesting metadata, used for parent resolution. */
export interface FlatSpan {
    span: TraceSpan;
    /** Depth inside the nested tree (meaningful for the nested form only). */
    depth: number;
    /** Parent under the nesting form (null for the flat form). */
    nestedParentId: string | null;
}
/**
 * Flatten a nested span tree into a pre-order list, recording the nesting
 * parent. Duplicate span_ids keep their first occurrence (defensive dedup).
 */
export declare function flattenSpans(spans: TraceSpan[]): FlatSpan[];
export interface BuildGraphOptions {
    /** Label of the synthetic root node added when multiple roots exist. */
    rootLabel?: string;
    /** Whether to add a synthetic root for multiple root spans (default true). */
    virtualRoot?: boolean;
}
/**
 * Convert a span tree into a node/edge collection plus interaction indexes.
 * Cycles, dangling parent references, and duplicate ids are handled defensively.
 */
export declare function buildGraph(spans: TraceSpan[], options?: BuildGraphOptions): GraphBundle;
/** Hover-highlight relation: the related set plus the direct parent/children. */
export interface HoverRelation {
    /** Hovered node + all ancestors + all descendants. */
    related: Set<string>;
    /** Direct parent + direct children (highlighted more strongly). */
    direct: Set<string>;
}
/** Compute the upstream/downstream relation of the hovered node (cycle-safe). */
export declare function buildRelations(parentOf: Map<string, string>, childrenOf: Map<string, string[]>, hoveredId: string): HoverRelation;
