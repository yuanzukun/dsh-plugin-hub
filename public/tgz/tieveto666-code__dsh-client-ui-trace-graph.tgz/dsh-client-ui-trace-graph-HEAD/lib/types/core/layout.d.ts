import type { LayoutMode, TraceEdge, TraceNode } from './types.ts';
/** Assumed node size (matches the .node width in tracegraph.module.css; height conservative). */
export declare const NODE_WIDTH = 232;
export declare const NODE_HEIGHT = 92;
export declare const FORCE_NODE_GAP = 72;
export interface LaidOutGraph {
    nodes: TraceNode[];
    edges: TraceEdge[];
}
interface Point {
    x: number;
    y: number;
}
/** Dagre hierarchical layout (top-to-bottom). Dagre emits center coords; convert to top-left. */
export declare function dagreLayout(nodes: TraceNode[], edges: TraceEdge[]): Map<string, Point>;
/**
 * d3-force organic layout with rectangular collision cleanup, then
 * shift-normalized so all nodes land in the non-negative quadrant.
 */
export declare function forceLayout(nodes: TraceNode[], edges: TraceEdge[]): Map<string, Point>;
/**
 * Apply the layout mode: position every node, then derive each edge's
 * connection sides (curve bend + Handle ids) and its entrance stagger delay.
 */
export declare function applyLayout(nodes: TraceNode[], edges: TraceEdge[], mode: LayoutMode): LaidOutGraph;
export {};
