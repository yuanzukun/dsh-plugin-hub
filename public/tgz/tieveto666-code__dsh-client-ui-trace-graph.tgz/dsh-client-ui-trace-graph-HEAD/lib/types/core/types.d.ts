/**
 * Shared types for the trace-graph visualization.
 *
 * The data model is decoupled from any trace backend: an upstream adapter only
 * has to produce a TraceSpan tree (nested children or flat parent_span_id),
 * and the whole visualization reuses it unchanged.
 */
import type { Edge, Node } from '@xyflow/react';
/** Node business category, deciding the color, icon, and label. */
export type SpanKind = 'llm' | 'tool' | 'loop' | 'agent' | 'root' | 'other';
/** Token usage (shown on LLM nodes). */
export interface TokenUsage {
    input: number;
    output: number;
    total?: number;
}
export type SpanStatus = 'ok' | 'error' | 'running';
/** Relationship represented by a rendered graph edge. */
export type TraceEdgeKind = 'structure' | 'sequence';
/** One incoming relation from another span. */
export interface TraceSpanLink {
    /** Source span id. */
    source_span_id: string;
    /** Whether the relation is a causal structure edge or chronological edge. */
    kind: TraceEdgeKind;
}
/**
 * One trace span.
 *
 * Both input forms are accepted:
 * - nested: organize the tree through `children`;
 * - flat: provide only `parent_span_id` and let buildGraph derive the edges.
 * When both are present, a valid `parent_span_id` wins.
 */
export interface TraceSpan {
    /** Globally unique span id. */
    span_id: string;
    /** Parent span id; null for roots. Optional under the nested form. */
    parent_span_id?: string | null;
    /** Span name, e.g. "LLM Call", "Tool: Python". */
    span_name: string;
    /** 1-based trajectory record index. */
    sequence?: number;
    /** Source trajectory ledger label, e.g. SYSTEM, USER, CONTEXT. */
    trace_label?: string;
    /** Source session-event seq when one event owns this span. */
    source_seq?: number;
    /** Conversation turn inferred by the trajectory projection. */
    turn?: number;
    /** Agent step inferred by the trajectory projection. */
    step?: number;
    /** Official trajectory group label, e.g. Message or Step 1. */
    group?: string;
    /** Incoming graph links. When present, buildGraph uses these instead of parent fallback. */
    links?: readonly TraceSpanLink[];
    /** Business category; inferred from span_name keywords when absent. */
    kind?: SpanKind;
    /** Start time (epoch ms). */
    start_ms?: number;
    /** End time (epoch ms). */
    end_ms?: number;
    /** Latency (ms); falls back to end_ms - start_ms. */
    latency_ms?: number;
    /** Token usage for LLM spans. */
    token_usage?: TokenUsage;
    status?: SpanStatus;
    /** Arbitrary JSON: the step's input. */
    input?: unknown;
    /** Arbitrary JSON: the step's output. */
    output?: unknown;
    /** Error message when status is error. */
    error?: string;
    /** Nested child spans. */
    children?: TraceSpan[];
}
/** Custom node data payload. */
export type TraceNodeData = {
    span: TraceSpan;
    kind: SpanKind;
    /** Tree depth (root is 0), driving the staggered entrance animation. */
    depth: number;
    /** This span's latency share of the whole trace (0~1) for the node time bar. */
    durationRatio: number;
    /** Whether this is the synthetic root added when multiple roots exist. */
    isVirtualRoot: boolean;
};
/** Custom edge data payload. */
export type TraceEdgeData = {
    kind: SpanKind;
    /** Edge kind: execution structure, or chronological sequence. */
    edgeKind: TraceEdgeKind;
    /** True when this edge also connects adjacent trajectory records. */
    isSequence: boolean;
    /** Source trajectory ledger label of the target node. */
    traceLabel?: string;
    /** Connection sides computed during layout (curve direction + Handle ids). */
    sourcePosition: 'top' | 'bottom' | 'left' | 'right';
    targetPosition: 'top' | 'bottom' | 'left' | 'right';
    /** Particle count rendered on this edge; auto-reduced for large graphs. */
    particleCount?: number;
};
export type TraceNode = Node<TraceNodeData, 'trace'>;
export type TraceEdge = Edge<TraceEdgeData, 'trace'>;
/** Layout mode: dagre hierarchical / d3-force organic. */
export type LayoutMode = 'dagre' | 'force';
/** One-shot product of buildGraph: nodes/edges plus interaction indexes. */
export interface GraphBundle {
    nodes: TraceNode[];
    edges: TraceEdge[];
    /** span_id to span index (detail panel lookups). */
    byId: Map<string, TraceSpan>;
    /** child id to parent id. */
    parentOf: Map<string, string>;
    /** parent id to child ids. */
    childrenOf: Map<string, string[]>;
    /** Whole-trace duration (ms), for the time-ratio bars. */
    totalLatency: number;
    /** Whether a synthetic root was added (multiple root spans). */
    hasVirtualRoot: boolean;
}
