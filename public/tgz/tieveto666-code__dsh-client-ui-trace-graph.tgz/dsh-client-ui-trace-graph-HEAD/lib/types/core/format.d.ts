/** Display formatting for numbers and times (presentation only, never logic). */
/** Latency in ms to human-readable text. */
export declare function fmtLatency(ms: number): string;
/** Token count to short text (>=1000 becomes k). */
export declare function fmtTokens(n: number): string;
/** Epoch ms to "HH:MM:SS.mmm" (local timezone). */
export declare function fmtClock(ms: number): string;
/** A span's effective latency: latency_ms first, then end_ms - start_ms, else 0. */
export declare function spanLatency(span: {
    latency_ms?: number;
    start_ms?: number;
    end_ms?: number;
}): number;
