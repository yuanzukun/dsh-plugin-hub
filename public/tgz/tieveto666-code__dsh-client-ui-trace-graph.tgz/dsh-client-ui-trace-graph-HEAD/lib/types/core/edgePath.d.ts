/**
 * Edge path geometry: a cubic bezier (smooth S curve).
 *
 * The control points are constructed here instead of delegating to ReactFlow's
 * getBezierPath so the particle animation and the drawn path share one
 * geometry (zero parsing, zero drift). The bend direction follows the
 * dominant axis between the source and target nodes.
 */
export interface Point {
    x: number;
    y: number;
}
export interface EdgeGeometry {
    /** SVG path string (M + C structure). */
    path: string;
    p0: Point;
    p1: Point;
    p2: Point;
    p3: Point;
}
/**
 * Build a smooth cubic bezier from the source point to the target point.
 * @param curvature - control-point reach as a fraction of the axis delta.
 */
export declare function buildFlowPath(sx: number, sy: number, tx: number, ty: number, curvature?: number): EdgeGeometry;
/** Point on a cubic bezier (t in [0,1]). */
export declare function cubicPoint(p0: Point, p1: Point, p2: Point, p3: Point, t: number): Point;
