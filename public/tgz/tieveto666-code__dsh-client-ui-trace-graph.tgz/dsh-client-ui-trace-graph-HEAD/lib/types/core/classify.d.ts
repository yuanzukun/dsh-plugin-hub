/**
 * Span classification and per-category visual metadata: colors, gradients,
 * glassmorphism parameters, and icons. Pure functions and static tables only;
 * the UI translates `label` through the client locale dictionaries where a
 * locale-aware label is needed (see client/locales.ts kind.* keys).
 *
 * Icon glyphs are chosen from the Unicode ranges the repo's emoji gate allows
 * (no Emoji_Presentation / Emoji-property characters).
 */
import type { SpanKind, TraceSpan } from './types.ts';
/** Visual metadata for one category. */
export interface KindMeta {
    kind: SpanKind;
    /** Neutral (zh) label; localized by the client via locale keys. */
    label: string;
    /** Icon glyph. */
    icon: string;
    /** Primary color. */
    color: string;
    /** Gradient secondary color. */
    color2: string;
    /** Glass panel gradient start (rgba). */
    glassFrom: string;
    /** Glass panel gradient end (rgba). */
    glassTo: string;
    /** Border color (rgba). */
    border: string;
    /** Outer glow color (rgba). */
    glow: string;
}
/** #rrggbb to rgba() string; falls back to a gray-blue on invalid input. */
export declare function hexToRgba(hex: string, alpha: number): string;
/** Category metadata (cached). */
export declare function kindMeta(kind: SpanKind): KindMeta;
/** Visual metadata keyed by the source trajectory label when one is present. */
export declare function traceLabelMeta(label: string | undefined, fallbackKind: SpanKind): KindMeta;
/**
 * Infer a span's category: an explicit kind wins, then keyword matching on the
 * name, then other. 'root' is never inferred (synthetic roots only).
 */
export declare function inferKind(span: TraceSpan): SpanKind;
