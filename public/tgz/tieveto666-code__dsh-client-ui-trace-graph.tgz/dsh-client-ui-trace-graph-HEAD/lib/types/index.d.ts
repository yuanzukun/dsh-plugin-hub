/**
 * Host loader entry for the trace-graph plugin — runs in the DSH host process.
 *
 * The host half owns the plugin's settings namespace (`trace-graph`: enabled /
 * announceToAgent / defaultLayout) and a system-prompt section
 * announcing the plugin to every agent. The actual UI lives in the browser
 * half (src/client), which reads the same namespace through the settings
 * scope. The browser half reads the official trajectory view snapshot and
 * projects the same records into TraceSpan nodes.
 */
import type { Context } from '@deepseek-ai/cordis';
import z from 'schemastery';
export declare const inject: string[];
/** Model-facing announcement: plugin presence, capabilities, and limits. */
export declare const TRACE_GRAPH_GUIDANCE = "\u672C\u673A\u5DF2\u5B89\u88C5 dsh-trace-graph \u63D2\u4EF6\uFF08DSH Web GUI \u7684\u8F68\u8FF9\u56FE\u8C31\uFF09\uFF1A\u5BF9\u8BDD\u9875\u300C\u8F68\u8FF9\u56FE\u8C31\u300D\u6807\u7B7E\u8BFB\u53D6\u5B98\u65B9\u300C\u8F68\u8FF9\u300D\u89C6\u56FE\u7684\u540C\u4E00\u4EFD\u771F\u5B9E\u8F68\u8FF9\u5FEB\u7167\uFF0C\u5E76\u4EE5 DAG \u53EF\u89C6\u5316\u5C55\u793A system/user/context/LLM/tool/partial/running-call \u7B49\u8BB0\u5F55\uFF1B\u652F\u6301 Dagre \u5C42\u7EA7\u5E03\u5C40\u4E0E d3-force \u529B\u5BFC\u5411\u5E03\u5C40\u5207\u6362\u3001\u60AC\u505C\u9AD8\u4EAE\u4E0A\u4E0B\u6E38\u3001\u70B9\u51FB\u8282\u70B9\u67E5\u770B\u8F93\u5165/\u8F93\u51FA JSON\u3002\u7528\u6237\u63D0\u5230\u300C\u8F68\u8FF9\u56FE\u8C31 / Trace \u56FE / \u8F68\u8FF9\u53EF\u89C6\u5316\u300D\u65F6\u5373\u6307\u672C\u63D2\u4EF6\uFF0C\u8BF7\u636E\u6B64\u534F\u4F5C\u3002";
/** Settings namespace of the plugin's configuration — the section the web settings surface edits. */
export declare const TRACE_GRAPH_SETTINGS_NAMESPACE: import("@deepseek-ai/dsh-settings").SettingsNamespace;
/** Plugin config, validated by the same-named schemastery schema. */
export interface Config {
    /** Master switch for the plugin (browser half + host announcement). */
    enabled?: boolean;
    /**
     * When true (default), a system-prompt section announces the plugin to every
     * agent. Set false to keep it silent in prompts.
     */
    announceToAgent?: boolean;
    /** Initial graph layout: dagre hierarchical (default) or d3-force. */
    defaultLayout?: 'dagre' | 'force';
}
export declare const Config: z<Config>;
/**
 * Register the plugin's announcement section, gated on the composition entry's
 * `enabled` / `announceToAgent` (and the live settings value once the web
 * settings surface is served). The section is re-registered whenever the
 * source changes, so a settings edit takes effect without a restart.
 * @param ctx - the plugin context (systemPrompt injected).
 * @param config - resolved plugin config (schema defaults applied by the loader).
 */
export declare function apply(ctx: Context, config?: Config): void;
