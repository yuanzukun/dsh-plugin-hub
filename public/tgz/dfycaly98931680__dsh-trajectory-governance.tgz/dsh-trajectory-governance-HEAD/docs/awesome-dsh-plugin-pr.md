# Submit to awesome-dsh-plugin

Repo: https://github.com/awesome-dsh-plugin/awesome-dsh-plugin

## PR 描述文本（提交用）

```markdown
### dsh-trajectory-governance

Agent trajectory governance & anomaly diagnosis plugin for DeepSeek Harness.

- Rebuilds the flat session/event log into a structured multi-branch trajectory
  tree (fork/subagent lineage derived implicitly from parentSessionId,
  seedLength, and session/end-seed).
- Observation-layer snapshots (nodeId + context hash + branchId; context
  rebuilt from the event store — no control-plane rollback).
- Three temporal anomaly strategies (loop deadlock / invalid retry / goal
  drift) with configurable thresholds, incremental async analysis, and results
  mounted on tree nodes.
- Independent GUI tab (conversation.view slot, id trajectory-governance); never
  overwrites the official Trajectory view.
- Zero kernel modification, consume-only event subscription, plugin-private
  SQLite storage, official bundle packaging (dsh.bundle → cordis.patch.yml),
  46 tests, MIT.
```

## 收录自检清单

- [x] 官方 bundle 打包（`dsh.bundle.patch` + `cordis.patch.yml`）
- [x] 零内核修改 / 无 monkey-patch / 只消费事件（emit 模式）
- [x] 观测层快照（不做控制层回滚）
- [x] 独立 Tab（不覆盖官方 Trajectory）
- [x] 独立 SQLite 存储（不触碰宿主数据库）
- [x] README（定位 / 边界 / 架构 / 安装 / 使用 / Demo / 兼容性）
- [x] LICENSE（MIT）
- [x] 68 项自动化测试（`npm test`）
- [x] 已发布到 GitHub：https://github.com/dfycaly98931680/dsh-trajectory-governance
- [ ] README 截图（首跑后补充）
- [ ] 仓库添加 topic：`dsh-plugin`

## 发布方式建议

1. **Git 直装**：仓库根含 `prepare` 构建脚本（`npm run build`），用户在 profile 的
   `pnpm-workspace.yaml` 加 `allowBuilds` 后 `dsh plugin --profile web add github:dfycaly98931680/dsh-trajectory-governance#<sha>`。
2. **npm 发布**（免构建授权）：`npm publish`（`prepack` 自动 build），用户
   `dsh plugin --profile web add dsh-trajectory-governance`。
