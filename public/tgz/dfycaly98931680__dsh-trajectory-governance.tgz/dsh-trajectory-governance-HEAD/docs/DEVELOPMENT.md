# 开发踩坑记录（Development Notes）

> 面向给本项目提 PR / 维护的贡献者。DSH 处于预览期（`SESSION_FORMAT_VERSION = 0`），
> 接口随时可能变动；本文按"现象 → 根因 → 对策"记录踩过的坑，全部已被本项目代码吸收。

## 1. `plugin.manifest.yaml` 在官方仓库中不存在

- **现象**：需求文档要求"严格遵循 plugin.manifest.yaml 规范"，但按此文件无法加载。
- **根因**：deepseek-ai/deepseek-harness（master，全 git 历史核对）从未有过该文件。
  官方插件 = 导出 `apply(ctx)`（+可选 `name`）的 Cordis 模块；打包 = npm 包 +
  package.json 声明 `dsh.bundle.patch` 指向 `cordis.patch.yml`（`- insert:` 行
  `{id, name, config}`）；安装 = `dsh plugin --profile <name> add <spec>`。
- **对策**：本项目采用双轨制 —— 加载走官方 bundle 机制；`plugin.manifest.yaml`
  仅作自描述元数据（声明订阅事件/能力/边界），供人类与工具链阅读。
- **对应文档**：`docs/user/develop/basic/index.md`、`publish.md`（官方仓库）。

## 2. Cordis v4 没有 `ctx.on('dispose')`

- **现象**：卸载钩子 `ctx.on('dispose', ...)` 类型报错（`'dispose' is not assignable
  to keyof Events`）。
- **根因**：`@deepseek-ai/cordis` 4.x 的 Events 不含 dispose；卸载清理统一走
  `ctx.effect(() => { ...; return () => cleanup() })`（disposer 随 fiber 逆序执行）。
- **对策**：所有清理（关库、清定时器、卸样式）都用 `ctx.effect` 的返回 disposer。

## 3. 包名 module augmentation 会遮蔽 re-export 的 `Context`

- **现象**：`declare module '@deepseek-ai/cordis' { interface Context { webServer } }`
  一加，`ctx.on` / `ctx.logger` 全部"不存在"。
- **根因**：cordis 入口 `lib/types/index.d.ts` 用 `export * from './context.ts'` 再导出；
  `Context` 是 interface + class 合并类型，且 `on/effect` 来自 cordis 内部
  `declare module './context.ts'` 的增强。从包名增强 `interface Context` 会新建一个
  遮蔽原始接口的空壳（内部增强不合并进包名模块）。
- **对策**：不增强 Context；改用**结构化局部类型**（`ApiHostContext`：只声明
  `effect` + `webServer.register`），调用处一次受控断言
  （`ctx as unknown as ApiHostContext`），并注释说明预览类型缺口。
  注意：`interface Events` 的包名增强是安全的（Events 是纯 interface），照常使用。

## 4. 沙箱环境下 npm 安装与测试的子进程限制

- **现象**：`npm install` 失败（esbuild postinstall `spawn EPERM`）；`node --test tests/`
  失败（测试运行器为每个文件 spawn 子进程）。
- **根因**：受限环境禁止 spawn 子进程（含 piped stdio）。
- **对策**：测试改用 `node tests/x.test.mjs` 直跑（node:test 主模块模式，进程内执行）；
  依赖树避免需要原生 postinstall 的包（用 `node:sqlite` 替代 better-sqlite3）。

## 5. node:sqlite 的选择

- **现象**：better-sqlite3 需要 node-gyp 原生编译，在受限环境与交付机器上都是负担。
- **根因**：Node ≥ 24 内置 `node:sqlite`（`DatabaseSync`），零原生依赖。
- **对策**：直接用内置模块；WAL 模式 + `synchronous=NORMAL`；`(session_id, seq)`
  主键做幂等插入（回放/fork 种子可安全重放）。

## 6. 事件乱序与"时序"的取舍

- **现象**：异步到达的 `session/event` 时间戳可能轻微回退。
- **根因**：官方会话日志是**追加式、seq 单调**的（`session/event` 是 post-commit
  fire-and-forget）；time 仅作展示。
- **对策**：建树以 **seq 为主序**，time 仅做乱序容错统计（`jitterCount`），
  绝不因时间倒挂切断链式父子。

## 7. 错误信号不是独立事件

- **现象**：需求假设存在 `error` / `taskFinish` 事件类型。
- **根因**：官方 44 类事件里没有独立 error 事件；错误以 `turn/end.reason.kind ∈
  {error, aborted, blocked, max-tokens, interrupted}`、`tool/result.error`、
  `llm/retry*` 等形式编码。
- **对策**：`event-catalog.ts` 集中映射；策略 B 从这些信号推导"无效重试"。

## 8. "embedding"没有现成服务

- **现象**：策略 C 需求写"复用 DSH 内置 embedding"。
- **根因**：rc.6 无公开 embedding 服务。
- **对策**：可插拔 `Embedder` 接口 + 内置词法 embedding（n-gram 特征哈希 + 余弦，
  零依赖）；`embedder: 'llm'` 作为扩展缝（当前降级词法），不引入重型模型依赖。

## 9. 测试里的三个真 bug（过程复盘）

1. `??` 与三元混用：`a ?? b ? c : d` 解析为 `(a ?? (b===…)) ? …` —— 一律加括号。
2. `setStatus` 无条件覆盖把终态 `disposed` 复活成 `settled` —— SQL 加粘性条件
   （`? = 'disposed' OR sessions.status <> 'disposed'`）。
3. catch 块里访问失败载荷字段（`event.seq`）导致**二次抛错** —— catch 日志一律
   安全访问（`event?.seq ?? '?'`）。

## 10. 客户端构建管线（参考 turn-rewind）

- `tsconfig.client.json`：CJS + `jsx: react-jsx` + DOM lib，输出 `.client-build`；
- `scripts/wrap-client.mjs`：把构建产物包成
  `window.__ModuleLoader__.load({ id, factory: (require) => ... })` 写入 `lib/client.js`；
- package.json 声明 `dsh.client: { platform: 'web', inject: [...] }`；
- 客户端 `Context` 同样用结构化局部类型（`slots.inject/register`），避免增强问题。

## 11. 实机三连坑：webServer 服务可见性与 exact 路由去重

- **现象一**：实机加载插件即失败，报
  `failed to apply loader entry trajectory-governance (dsh-trajectory-governance):
  cannot get property "webServer" without inject`。
  - 根因：Cordis 上下文是代理 + 运行时 Guard，**service 属性必须在声明依赖后
    读取**；"类型断言绕过"只骗过编译器，运行时照样被拦。
  - 对策：不要直接读 service 属性。
- **现象二**：`ctx.inject(['webServer'], cb)` 不再报错、插件正常记录事件，但 API
  路由始终未注册（请求落到 SPA 兜底页返回 `<!doctype html>`）；`ctx.get` 在插件
  apply 早期也拿不到服务。
  - 根因：服务可见性走 fiber store 链且**插件激活顺序由"服务可用性"驱动**——
    apply 执行时 webServer 可能尚未激活，任何一次性读取都拿不到；动态 `ctx.inject`
    的子 fiber 回调在此场景未触发（时序/fiber 归属问题）。
  - 对策（官方模式）：**拆两个插件行** —— 核心行零服务依赖（任何 profile 都激活），
    API 行在 `cordis.patch.yml` 里声明 `inject: [webServer]`，loader 等 webServer
    就绪后才激活该行，此时 `ctx.get('webServer')` 必返回服务。headless 下 API 行
    不激活、核心行照常录事件。
- **现象三**：API 行激活后报
  `webserver: duplicate exact route "/trajectory-governance/api/snapshots"`。
  - 根因：`webServer.register` 的 exact 路由**按 path 为键**（不看 method），
    同一 path 的 GET/POST/DELETE 各注册一次即冲突。
  - 对策：**每个 path 只注册一次**，method 分发在 handler 内部完成
    （`api.handle` 本就按 method+path 路由）；回归测试断言"注册路径集合无重复且
    等于预期 12 条"。
- **通用规则**：业务 service 用 `ctx.get(name)` 读，但**必须在服务已激活的时机**
  （行级 inject 保证）；`on/effect/logger` 等内置 mixin 直接可用；exact 路由
  path 唯一、method 在 handler 内分发。

## 12. v0.2 告警与止损的实现要点

- **成本数据源**：官方 `assistant/message` 事件自带 `usage`（`input_tokens`/
  `output_tokens`，兼容 `inputTokens`/`outputTokens` 风格）—— 折算只读官方
  token 账，缺失时按会话内平均值估算（可关）。
- **金额精度**：成本以元两位小数显示；小额（<0.01 元）在 UI 降级为千 token 数，
  避免无意义的 `¥0.00`。
- **告警触发**：只对新落库的 anomalyId 触发一次（引擎 `newAnomalyIds`）+ 置信度
  门槛 + 每会话冷却；通道三条：`trajectory/anomaly` 总线事件（生态可订阅）、
  webhook POST、浏览器 Notification（客户端轮询 `/api/alerts` 增量拉取 + 本地去重）。
- **一键中断**：`POST /api/actions/interrupt` → API 行 `ctx.get('agents')` →
  官方 `agent.cancel({ kind: 'hook', reason })`。这是**官方公开能力**，不是
  monkey-patch；默认动作层级 `notify`，`auto-stop` 需显式配置（仅 loop_deadlock
  且置信度 ≥ 0.9）。

## 13. v0.3 断点出口与浪费报告

- **断点出口 = 轻量版回滚**：刻意不做 turn-rewind 式工作区回滚（红海 + 与
  "观测层"定位冲突）。`POST /api/actions/fork` 把目标节点 seq **向下归一到最近
  的 `turn/end`**（官方 `sessions.fork` 要求前缀结尾在 open turn 之外），再调
  官方 `ctx.sessions.fork(source, boundary)` 生成种子子会话。目标前无轮次边界时
  返回 409（防止 fork 进未闭合轮次）。
- **浪费报告**：`/api/report/waste`（全量 Markdown+JSON）与
  `?sessionId=`（会话明细）。刻意不做"总用量统计"（生态 15+ 竞品），只做
  **异常归因**——基于我们自己的异常区间 + 官方 token 账。
- **服务获取**：API 行通过 `ctx.get('sessions')` 拿官方 SessionStore（防御
  undefined → fork 返回 501）；`agents`/`sessions`/`webServer` 三个可选服务
  都在 API 行激活后读取，测试桩需逐一覆盖。

## 14. v0.4 会话命名（官方 rename + 本地镜像）

- **官方能力（源码确认）**：`SessionTitleService.rename(session, title)`
  （服务名 `sessionTitle`）——`source.kind === 'user'`，**用户重命名会钉住标题、
  停止自动生成**；`session/title` 事件是 log-only，官方 UI 同步显示。
- **我们的双写**：`POST /api/actions/rename` ① 写本地 `sessions.display_name`
  （观测层镜像，headless 也能查）② 若 `sessionTitle`/`sessions.get` 可用则调官方
  `rename(liveSession, title)`（`official: true`；live 会话不存在时仅本地成功）。
- **自动标题镜像**：订阅器监听 `session/title` 事件写入 `auto_title`，Tab 显示
  `display_name ?? auto_title ?? sessionId`——会话列表从 `session-xxx` 变成可读标题。
- **schema 迁移**：旧库通过 `MIGRATIONS`（`PRAGMA table_info` 检查 + `ALTER TABLE
  ADD COLUMN`）幂等补齐 `display_name`/`auto_title` 列。
- **历史标题回填（实机踩坑）**：官方标题是 `session/title` **历史事件**，插件只录
  安装之后的事件 → 老会话 `auto_title` 恒空。`/sessions` 端点对无标题会话从官方
  日志回填：先读 live `sessions.get(id).events`，再回退官方 `sessionQuery.readSession`
  （能读历史/归档）；回填结果写回本地镜像（一次成功，后续零开销），失败静默降级。
