/**
 * EventStore — SQLite-backed persistence + query interface for raw session
 * events and session lineage. Idempotent upserts (INSERT OR IGNORE on
 * (session_id, seq)) make replay/fork seeds safe to fold repeatedly.
 */
import type { DatabaseSync } from 'node:sqlite'
import type { NormalizedEvent } from '../core/types.js'
import { openDatabase } from './sqlite.js'

export interface SessionRecord {
  sessionId: string
  parentSessionId?: string
  origin?: 'subagent'
  seedLength?: number
  cwd?: string
  agentPreset?: string
  subagentMode?: string
  subagentLabel?: string
  subagentProvider?: string
  /** User rename (ours; display priority). */
  displayName?: string
  /** Official session/title (auto-generated or user rename, mirrored here). */
  autoTitle?: string
  createdAt: number
  lastEventSeq: number
  lastEventAt?: number
  status: 'active' | 'disposed' | 'settled'
}

export interface StoredEvent {
  sessionId: string
  branchId: string
  seq: number
  time: number
  type: string
  kind: string
  category: string
  surface: boolean
  ignorable: boolean
  parentSessionId?: string
  origin?: 'subagent'
  data: Record<string, unknown>
  raw: unknown
}

export interface EventQuery {
  fromSeq?: number
  limit?: number
  offset?: number
}

export interface SnapshotRow {
  snapshotId: string
  sessionId: string
  branchId: string
  nodeId: string
  seq: number
  contextHash: string
  label?: string
  note?: string
  createdAt: number
  lastAccessedAt: number
  accessCount: number
}

export interface SnapshotQuery {
  sessionId?: string
  branchId?: string
  limit?: number
  offset?: number
}

export interface DeleteBranchResult {
  removedEvents: number
  removedSnapshots: number
  removedSessions: number
}

export interface AnomalyRow {
  anomalyId: string
  sessionId: string
  type: string
  startNodeId: string
  endNodeId: string
  confidence: number
  description: string
  suggestion?: string
  severity?: string
  createdAt: number
  updatedAt: number
}

export interface AnomalyQuery {
  sessionId?: string
  type?: string
  limit?: number
  offset?: number
}

export interface DiagnosisStateRow {
  sessionId: string
  analyzedSeq: number
  updatedAt: number
}

export class EventStore {
  private readonly upsertSessionStmt
  private readonly touchSessionStmt
  private readonly insertEventStmt
  private readonly setStatusStmt
  private readonly setSubagentMetaStmt
  private readonly listSessionsStmt
  private readonly listSessionsCountStmt
  private readonly listEventsStmt
  private readonly countEventsStmt
  private readonly countEventsBySessionStmt
  private readonly findSessionStmt
  private readonly insertSnapshotStmt
  private readonly findSnapshotStmt
  private readonly listSnapshotsStmt
  private readonly touchSnapshotStmt
  private readonly deleteSnapshotStmt
  private readonly countSnapshotsStmt
  private readonly deleteEventsBySessionStmt
  private readonly deleteSnapshotsBySessionStmt
  private readonly deleteSessionStmt
  private readonly upsertAnomalyStmt
  private readonly findAnomalyStmt
  private readonly listAnomaliesStmt
  private readonly countAnomaliesStmt
  private readonly countAnomaliesBySessionStmt
  private readonly deleteAnomaliesBySessionStmt
  private readonly getDiagnosisStateStmt
  private readonly setDiagnosisStateStmt

  private constructor(private readonly db: DatabaseSync) {
    this.upsertSessionStmt = db.prepare(`
      INSERT INTO sessions (
        session_id, parent_session_id, origin, seed_length, cwd, agent_preset,
        subagent_mode, subagent_label, subagent_provider, display_name, auto_title,
        created_at, last_event_seq, last_event_at, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(session_id) DO UPDATE SET
        parent_session_id = COALESCE(excluded.parent_session_id, sessions.parent_session_id),
        origin            = COALESCE(excluded.origin, sessions.origin),
        seed_length       = COALESCE(excluded.seed_length, sessions.seed_length),
        cwd               = COALESCE(excluded.cwd, sessions.cwd),
        agent_preset      = COALESCE(excluded.agent_preset, sessions.agent_preset),
        display_name      = COALESCE(excluded.display_name, sessions.display_name),
        auto_title        = COALESCE(excluded.auto_title, sessions.auto_title),
        status            = CASE
                              WHEN sessions.status = 'disposed' THEN 'disposed'
                              WHEN excluded.status = 'settled' AND sessions.status = 'active' THEN 'settled'
                              ELSE excluded.status
                            END
    `)
    this.touchSessionStmt = db.prepare(`
      UPDATE sessions
      SET last_event_seq = MAX(last_event_seq, ?), last_event_at = MAX(COALESCE(last_event_at, 0), ?)
      WHERE session_id = ?
    `)
    this.insertEventStmt = db.prepare(`
      INSERT OR IGNORE INTO events (
        session_id, branch_id, seq, time, type, kind, category, surface,
        ignorable, parent_session_id, origin, data, raw
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    // 'disposed' is terminal: a settled transition must never resurrect a disposed session.
    this.setStatusStmt = db.prepare(`
      UPDATE sessions SET status = ?
      WHERE session_id = ? AND (? = 'disposed' OR sessions.status <> 'disposed')
    `)
    this.setSubagentMetaStmt = db.prepare(`
      UPDATE sessions
      SET subagent_mode = COALESCE(?, subagent_mode),
          subagent_label = COALESCE(?, subagent_label),
          subagent_provider = COALESCE(?, subagent_provider)
      WHERE session_id = ?
    `)
    this.listSessionsStmt = db.prepare(`
      SELECT * FROM sessions ORDER BY created_at DESC, session_id ASC LIMIT ? OFFSET ?
    `)
    this.listSessionsCountStmt = db.prepare(`SELECT COUNT(*) AS n FROM sessions`)
    this.listEventsStmt = db.prepare(`
      SELECT * FROM events
      WHERE session_id = ? AND seq >= ?
      ORDER BY seq ASC
      LIMIT ? OFFSET ?
    `)
    this.countEventsStmt = db.prepare(`SELECT COUNT(*) AS n FROM events`)
    this.countEventsBySessionStmt = db.prepare(`SELECT COUNT(*) AS n FROM events WHERE session_id = ?`)
    this.findSessionStmt = db.prepare(`SELECT * FROM sessions WHERE session_id = ?`)
    this.insertSnapshotStmt = db.prepare(`
      INSERT OR IGNORE INTO snapshots (
        snapshot_id, session_id, branch_id, node_id, seq, context_hash,
        label, note, created_at, last_accessed_at, access_count
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `)
    this.findSnapshotStmt = db.prepare(`SELECT * FROM snapshots WHERE snapshot_id = ?`)
    this.listSnapshotsStmt = db.prepare(`
      SELECT * FROM snapshots
      WHERE (? IS NULL OR session_id = ?)
        AND (? IS NULL OR branch_id = ?)
      ORDER BY created_at DESC, snapshot_id ASC
      LIMIT ? OFFSET ?
    `)
    this.touchSnapshotStmt = db.prepare(`
      UPDATE snapshots SET last_accessed_at = ?, access_count = access_count + 1
      WHERE snapshot_id = ?
    `)
    this.deleteSnapshotStmt = db.prepare(`DELETE FROM snapshots WHERE snapshot_id = ?`)
    this.countSnapshotsStmt = db.prepare(`SELECT COUNT(*) AS n FROM snapshots`)
    this.deleteEventsBySessionStmt = db.prepare(`DELETE FROM events WHERE session_id = ?`)
    this.deleteSnapshotsBySessionStmt = db.prepare(`DELETE FROM snapshots WHERE session_id = ?`)
    this.deleteSessionStmt = db.prepare(`DELETE FROM sessions WHERE session_id = ?`)
    this.upsertAnomalyStmt = db.prepare(`
      INSERT INTO anomalies (
        anomaly_id, session_id, type, start_node_id, end_node_id, confidence,
        description, suggestion, severity, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(anomaly_id) DO UPDATE SET
        confidence = excluded.confidence,
        description = excluded.description,
        suggestion = excluded.suggestion,
        severity = excluded.severity,
        updated_at = excluded.updated_at
    `)
    this.findAnomalyStmt = db.prepare(`SELECT * FROM anomalies WHERE anomaly_id = ?`)
    this.listAnomaliesStmt = db.prepare(`
      SELECT * FROM anomalies
      WHERE (? IS NULL OR session_id = ?)
        AND (? IS NULL OR type = ?)
      ORDER BY created_at DESC, anomaly_id ASC
      LIMIT ? OFFSET ?
    `)
    this.countAnomaliesStmt = db.prepare(`SELECT COUNT(*) AS n FROM anomalies`)
    this.countAnomaliesBySessionStmt = db.prepare(`SELECT COUNT(*) AS n FROM anomalies WHERE session_id = ?`)
    this.deleteAnomaliesBySessionStmt = db.prepare(`DELETE FROM anomalies WHERE session_id = ?`)
    this.getDiagnosisStateStmt = db.prepare(`SELECT * FROM diagnosis_state WHERE session_id = ?`)
    this.setDiagnosisStateStmt = db.prepare(`
      INSERT INTO diagnosis_state (session_id, analyzed_seq, updated_at) VALUES (?, ?, ?)
      ON CONFLICT(session_id) DO UPDATE SET
        analyzed_seq = excluded.analyzed_seq,
        updated_at = excluded.updated_at
    `)
  }

  static open(path: string): EventStore {
    return new EventStore(openDatabase(path))
  }

  // ---- writes ----

  upsertSession(record: SessionRecord): void {
    this.upsertSessionStmt.run(
      record.sessionId,
      record.parentSessionId ?? null,
      record.origin ?? null,
      record.seedLength ?? null,
      record.cwd ?? null,
      record.agentPreset ?? null,
      record.subagentMode ?? null,
      record.subagentLabel ?? null,
      record.subagentProvider ?? null,
      record.displayName ?? null,
      record.autoTitle ?? null,
      record.createdAt,
      record.lastEventSeq,
      record.lastEventAt ?? null,
      record.status,
    )
  }

  /** Set display/auto titles; empty strings clear the field. */
  setTitle(sessionId: string, titles: { displayName?: string; autoTitle?: string }): void {
    const parts: string[] = []
    const args: unknown[] = []
    if (titles.displayName !== undefined) {
      parts.push('display_name = ?')
      args.push(titles.displayName === '' ? null : titles.displayName)
    }
    if (titles.autoTitle !== undefined) {
      parts.push('auto_title = ?')
      args.push(titles.autoTitle === '' ? null : titles.autoTitle)
    }
    if (parts.length === 0) return
    args.push(sessionId)
    this.db.prepare(`UPDATE sessions SET ${parts.join(', ')} WHERE session_id = ?`).run(...args as never[])
  }

  /** Advance a session's watermark without touching other fields. */
  touchSession(sessionId: string, seq: number, time: number): void {
    this.touchSessionStmt.run(seq, time, sessionId)
  }

  /** Insert one normalized event (idempotent) and advance the session watermark. */
  insertEvent(event: NormalizedEvent, rawJson: string): void {
    this.insertEventStmt.run(
      event.sessionId,
      event.branchId,
      event.seq,
      event.time,
      event.type,
      event.kind,
      event.category,
      event.surface ? 1 : 0,
      event.ignorable ? 1 : 0,
      event.parentSessionId ?? null,
      event.origin ?? null,
      JSON.stringify(event.data),
      rawJson,
    )
    this.touchSession(event.sessionId, event.seq, event.time)
  }

  setStatus(sessionId: string, status: SessionRecord['status']): void {
    this.setStatusStmt.run(status, sessionId, status)
  }

  setSubagentMeta(sessionId: string, meta: { mode?: string; label?: string; provider?: string }): void {
    this.setSubagentMetaStmt.run(meta.mode ?? null, meta.label ?? null, meta.provider ?? null, sessionId)
  }

  // ---- reads ----

  findSession(sessionId: string): SessionRecord | undefined {
    const row = this.findSessionStmt.get(sessionId)
    return row === undefined ? undefined : mapSessionRow(row)
  }

  listSessions(limit = 100, offset = 0): SessionRecord[] {
    const rows = this.listSessionsStmt.all(limit, offset) as unknown[]
    return rows.map(mapSessionRow)
  }

  countSessions(): number {
    const row = this.listSessionsCountStmt.get() as { n: number }
    return Number(row.n)
  }

  listEventsBySession(sessionId: string, query: EventQuery = {}): StoredEvent[] {
    const fromSeq = query.fromSeq ?? 0
    const limit = query.limit ?? 1000
    const offset = query.offset ?? 0
    const rows = this.listEventsStmt.all(sessionId, fromSeq, limit, offset) as unknown[]
    return rows.map(mapEventRow)
  }

  countEvents(): number {
    const row = this.countEventsStmt.get() as { n: number }
    return Number(row.n)
  }

  countEventsBySession(sessionId: string): number {
    const row = this.countEventsBySessionStmt.get(sessionId) as { n: number }
    return Number(row.n)
  }

  // ---- snapshots ----

  insertSnapshot(row: SnapshotRow): void {
    this.insertSnapshotStmt.run(
      row.snapshotId,
      row.sessionId,
      row.branchId,
      row.nodeId,
      row.seq,
      row.contextHash,
      row.label ?? null,
      row.note ?? null,
      row.createdAt,
      row.lastAccessedAt,
      row.accessCount,
    )
  }

  findSnapshot(snapshotId: string): SnapshotRow | undefined {
    const row = this.findSnapshotStmt.get(snapshotId)
    return row === undefined ? undefined : mapSnapshotRow(row)
  }

  listSnapshots(query: SnapshotQuery = {}): SnapshotRow[] {
    const limit = query.limit ?? 100
    const offset = query.offset ?? 0
    const rows = this.listSnapshotsStmt.all(query.sessionId ?? null, query.sessionId ?? null, query.branchId ?? null, query.branchId ?? null, limit, offset) as unknown[]
    return rows.map(mapSnapshotRow)
  }

  touchSnapshot(snapshotId: string, at = Date.now()): boolean {
    const result = this.touchSnapshotStmt.run(at, snapshotId)
    return Number(result.changes) > 0
  }

  deleteSnapshot(snapshotId: string): boolean {
    const result = this.deleteSnapshotStmt.run(snapshotId)
    return Number(result.changes) > 0
  }

  countSnapshots(): number {
    const row = this.countSnapshotsStmt.get() as { n: number }
    return Number(row.n)
  }

  /** All snapshots, oldest-access first (LRU order for pruning). */
  listSnapshotsLru(): SnapshotRow[] {
    const rows = this.db.prepare(`SELECT * FROM snapshots ORDER BY last_accessed_at ASC, snapshot_id ASC`).all() as unknown[]
    return rows.map(mapSnapshotRow)
  }

  // ---- branch deletion (observation-store cleanup; never touches DSH host data) ----

  deleteBranchData(sessionId: string): DeleteBranchResult {
    const removedEvents = Number(this.deleteEventsBySessionStmt.run(sessionId).changes)
    const removedSnapshots = Number(this.deleteSnapshotsBySessionStmt.run(sessionId).changes)
    const removedSessions = Number(this.deleteSessionStmt.run(sessionId).changes)
    return { removedEvents, removedSnapshots, removedSessions }
  }

  // ---- anomalies ----

  upsertAnomaly(row: AnomalyRow): void {
    this.upsertAnomalyStmt.run(
      row.anomalyId,
      row.sessionId,
      row.type,
      row.startNodeId,
      row.endNodeId,
      row.confidence,
      row.description,
      row.suggestion ?? null,
      row.severity ?? null,
      row.createdAt,
      row.updatedAt,
    )
  }

  findAnomaly(anomalyId: string): AnomalyRow | undefined {
    const row = this.findAnomalyStmt.get(anomalyId)
    return row === undefined ? undefined : mapAnomalyRow(row)
  }

  listAnomalies(query: AnomalyQuery = {}): AnomalyRow[] {
    const limit = query.limit ?? 100
    const offset = query.offset ?? 0
    const rows = this.listAnomaliesStmt.all(
      query.sessionId ?? null, query.sessionId ?? null,
      query.type ?? null, query.type ?? null,
      limit, offset,
    ) as unknown[]
    return rows.map(mapAnomalyRow)
  }

  countAnomalies(): number {
    const row = this.countAnomaliesStmt.get() as { n: number }
    return Number(row.n)
  }

  countAnomaliesBySession(sessionId: string): number {
    const row = this.countAnomaliesBySessionStmt.get(sessionId) as { n: number }
    return Number(row.n)
  }

  deleteAnomaliesBySession(sessionId: string): number {
    return Number(this.deleteAnomaliesBySessionStmt.run(sessionId).changes)
  }

  // ---- diagnosis state (incremental watermark) ----

  getDiagnosisState(sessionId: string): DiagnosisStateRow | undefined {
    const row = this.getDiagnosisStateStmt.get(sessionId)
    return row === undefined ? undefined : mapDiagnosisStateRow(row)
  }

  setDiagnosisState(sessionId: string, analyzedSeq: number, at = Date.now()): void {
    this.setDiagnosisStateStmt.run(sessionId, analyzedSeq, at)
  }

  close(): void {
    this.db.close()
  }
}

function mapSessionRow(row: unknown): SessionRecord {
  const r = row as Record<string, unknown>
  return {
    sessionId: String(r.session_id),
    parentSessionId: nullableString(r.parent_session_id),
    origin: r.origin === 'subagent' ? 'subagent' : undefined,
    seedLength: nullableNumber(r.seed_length),
    cwd: nullableString(r.cwd),
    agentPreset: nullableString(r.agent_preset),
    subagentMode: nullableString(r.subagent_mode),
    subagentLabel: nullableString(r.subagent_label),
    subagentProvider: nullableString(r.subagent_provider),
    displayName: nullableString(r.display_name),
    autoTitle: nullableString(r.auto_title),
    createdAt: Number(r.created_at),
    lastEventSeq: Number(r.last_event_seq),
    lastEventAt: nullableNumber(r.last_event_at),
    status: String(r.status) as SessionRecord['status'],
  }
}

function mapEventRow(row: unknown): StoredEvent {
  const r = row as Record<string, unknown>
  return {
    sessionId: String(r.session_id),
    branchId: String(r.branch_id),
    seq: Number(r.seq),
    time: Number(r.time),
    type: String(r.type),
    kind: String(r.kind),
    category: String(r.category),
    surface: Number(r.surface) === 1,
    ignorable: Number(r.ignorable) === 1,
    parentSessionId: nullableString(r.parent_session_id),
    origin: r.origin === 'subagent' ? 'subagent' : undefined,
    data: JSON.parse(String(r.data)) as Record<string, unknown>,
    raw: JSON.parse(String(r.raw)),
  }
}

function mapSnapshotRow(row: unknown): SnapshotRow {
  const r = row as Record<string, unknown>
  return {
    snapshotId: String(r.snapshot_id),
    sessionId: String(r.session_id),
    branchId: String(r.branch_id),
    nodeId: String(r.node_id),
    seq: Number(r.seq),
    contextHash: String(r.context_hash),
    label: nullableString(r.label),
    note: nullableString(r.note),
    createdAt: Number(r.created_at),
    lastAccessedAt: Number(r.last_accessed_at),
    accessCount: Number(r.access_count),
  }
}

function mapDiagnosisStateRow(row: unknown): DiagnosisStateRow {
  const r = row as Record<string, unknown>
  return {
    sessionId: String(r.session_id),
    analyzedSeq: Number(r.analyzed_seq),
    updatedAt: Number(r.updated_at),
  }
}

function mapAnomalyRow(row: unknown): AnomalyRow {
  const r = row as Record<string, unknown>
  return {
    anomalyId: String(r.anomaly_id),
    sessionId: String(r.session_id),
    type: String(r.type),
    startNodeId: String(r.start_node_id),
    endNodeId: String(r.end_node_id),
    confidence: Number(r.confidence),
    description: String(r.description),
    suggestion: nullableString(r.suggestion),
    severity: nullableString(r.severity),
    createdAt: Number(r.created_at),
    updatedAt: Number(r.updated_at),
  }
}

function nullableString(value: unknown): string | undefined {
  return value === null || value === undefined ? undefined : String(value)
}

function nullableNumber(value: unknown): number | undefined {
  return value === null || value === undefined ? undefined : Number(value)
}
