/**
 * SQLite schema (plugin-private storage; never touches DSH host storage).
 *
 * events   — one row per committed session event (idempotent on (session_id, seq)).
 * sessions — one row per session with lineage + lifecycle status.
 *            display_name = user rename (ours), auto_title = official session/title.
 *            Schema evolution for existing DBs lives in `MIGRATIONS` below.
 */
export const SCHEMA = `
CREATE TABLE IF NOT EXISTS sessions (
  session_id        TEXT PRIMARY KEY,
  parent_session_id TEXT,
  origin            TEXT,
  seed_length       INTEGER,
  cwd               TEXT,
  agent_preset      TEXT,
  subagent_mode     TEXT,
  subagent_label    TEXT,
  subagent_provider TEXT,
  display_name      TEXT,
  auto_title        TEXT,
  created_at        INTEGER NOT NULL,
  last_event_seq    INTEGER NOT NULL DEFAULT 0,
  last_event_at     INTEGER,
  status            TEXT NOT NULL DEFAULT 'active'
);

CREATE TABLE IF NOT EXISTS events (
  session_id         TEXT NOT NULL,
  branch_id          TEXT NOT NULL,
  seq                INTEGER NOT NULL,
  time               INTEGER NOT NULL,
  type               TEXT NOT NULL,
  kind               TEXT NOT NULL,
  category           TEXT NOT NULL,
  surface            INTEGER NOT NULL DEFAULT 0,
  ignorable          INTEGER NOT NULL DEFAULT 0,
  parent_session_id  TEXT,
  origin             TEXT,
  data               TEXT NOT NULL,
  raw                TEXT NOT NULL,
  PRIMARY KEY (session_id, seq)
);

CREATE INDEX IF NOT EXISTS idx_events_session_time ON events (session_id, time);
CREATE INDEX IF NOT EXISTS idx_events_branch      ON events (branch_id);
CREATE INDEX IF NOT EXISTS idx_events_kind        ON events (kind);

CREATE TABLE IF NOT EXISTS snapshots (
  snapshot_id      TEXT PRIMARY KEY,
  session_id       TEXT NOT NULL,
  branch_id        TEXT NOT NULL,
  node_id          TEXT NOT NULL,
  seq              INTEGER NOT NULL,
  context_hash     TEXT NOT NULL,
  label            TEXT,
  note             TEXT,
  created_at       INTEGER NOT NULL,
  last_accessed_at INTEGER NOT NULL,
  access_count     INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_snapshots_session ON snapshots (session_id);
CREATE INDEX IF NOT EXISTS idx_snapshots_branch  ON snapshots (branch_id);
CREATE INDEX IF NOT EXISTS idx_snapshots_access  ON snapshots (last_accessed_at);

CREATE TABLE IF NOT EXISTS anomalies (
  anomaly_id    TEXT PRIMARY KEY,
  session_id    TEXT NOT NULL,
  type          TEXT NOT NULL,
  start_node_id TEXT NOT NULL,
  end_node_id   TEXT NOT NULL,
  confidence    REAL NOT NULL,
  description   TEXT NOT NULL,
  suggestion    TEXT,
  severity      TEXT,
  created_at    INTEGER NOT NULL,
  updated_at    INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_anomalies_session ON anomalies (session_id);
CREATE INDEX IF NOT EXISTS idx_anomalies_type     ON anomalies (type);

CREATE TABLE IF NOT EXISTS diagnosis_state (
  session_id   TEXT PRIMARY KEY,
  analyzed_seq INTEGER NOT NULL DEFAULT 0,
  updated_at   INTEGER NOT NULL
);
`

/**
 * Idempotent column migrations for databases created before a column existed
 * (CREATE TABLE IF NOT EXISTS never alters existing tables).
 */
export const MIGRATIONS: ReadonlyArray<{ column: string; ddl: string }> = [
  {
    column: 'display_name',
    ddl: `ALTER TABLE sessions ADD COLUMN display_name TEXT`,
  },
  {
    column: 'auto_title',
    ddl: `ALTER TABLE sessions ADD COLUMN auto_title TEXT`,
  },
]

/** True when `table` has a column named `column` (used by migrations). */
export const COLUMN_CHECK_SQL = `
SELECT 1 FROM pragma_table_info('sessions') WHERE name = ?
`
