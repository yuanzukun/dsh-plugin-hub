/**
 * node:sqlite wrapper (built-in DatabaseSync, zero native dependencies).
 * WAL journaling keeps writes off the hot read path.
 */
import { mkdirSync } from 'node:fs'
import { dirname } from 'node:path'
import { DatabaseSync } from 'node:sqlite'
import { COLUMN_CHECK_SQL, MIGRATIONS, SCHEMA } from './schema.js'

export type { DatabaseSync } from 'node:sqlite'

/** Open (creating if needed) a SQLite database at `path`, apply schema + migrations. */
export function openDatabase(path: string): DatabaseSync {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true })
  const db = new DatabaseSync(path)
  db.exec('PRAGMA journal_mode = WAL;')
  db.exec('PRAGMA synchronous = NORMAL;')
  db.exec(SCHEMA)
  // idempotent column migrations for pre-existing databases
  const hasColumn = db.prepare(COLUMN_CHECK_SQL)
  for (const migration of MIGRATIONS) {
    const row = hasColumn.get(migration.column) as { 1?: number } | undefined
    if (row === undefined) db.exec(migration.ddl)
  }
  return db
}
