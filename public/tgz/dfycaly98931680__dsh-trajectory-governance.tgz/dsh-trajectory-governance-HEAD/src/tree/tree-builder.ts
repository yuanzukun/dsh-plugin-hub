/**
 * Trajectory tree builder.
 *
 * Input: the event store (flat per-session logs + session lineage).
 * Output: a cross-session trajectory tree with fork/subagent children attached
 * as subtrees. Attachment is derived from IMPLICIT information only (the raw
 * events carry no parent ids):
 *   - subagent child  → nearest subagent `tool/call` node in the parent chain
 *     at or before the child's first event time;
 *   - fork child      → parent node at seq `seedLength - 1` (the seeded
 *     boundary), else nearest earlier node;
 *   - fallback        → last parent node at or before the child's creation.
 */
import type { EventStore, SessionRecord, StoredEvent } from '../persistence/event-store.js'
import type { BuildStats, BranchInfo, TrajectoryNode } from './types.js'

export interface TreeBuildOptions {
  /** Tool names whose `tool/call` nodes are subagent anchors. */
  subagentToolNames?: readonly string[]
}

const DEFAULT_SUBAGENT_TOOLS: readonly string[] = ['subagent', 'subagent_fork']

/** Globally unique node id. */
export function nodeIdFor(sessionId: string, seq: number): string {
  return `${sessionId}:${seq}`
}

/** Parse a node id back into { sessionId, seq }; undefined when malformed. */
export function parseNodeId(nodeId: string): { sessionId: string; seq: number } | undefined {
  const idx = nodeId.lastIndexOf(':')
  if (idx <= 0 || idx === nodeId.length - 1) return undefined
  const sessionId = nodeId.slice(0, idx)
  const seq = Number(nodeId.slice(idx + 1))
  if (!Number.isSafeInteger(seq) || seq < 0) return undefined
  return { sessionId, seq }
}

export class TrajectoryTreeBuilder {
  readonly opts: Required<TreeBuildOptions>
  stats: BuildStats = freshStats()

  constructor(
    private readonly store: EventStore,
    opts: TreeBuildOptions = {},
  ) {
    this.opts = {
      subagentToolNames: opts.subagentToolNames ?? DEFAULT_SUBAGENT_TOOLS,
    }
  }

  /** Build the full tree rooted at `sessionId`, including descendant subtrees. */
  build(sessionId: string): TrajectoryNode | undefined {
    this.stats = freshStats()
    const session = this.store.findSession(sessionId)
    if (session === undefined) return undefined
    const visited = new Set<string>()
    const branch: BranchInfo = {
      branchId: sessionId,
      branchType: 'main',
      parentBranchId: null,
      parentSessionId: session.parentSessionId ?? null,
      label: session.subagentLabel,
    }
    return this.buildSessionTree(sessionId, branch, visited)
  }

  /** Linear chain of one branch (sessionId === branchId). */
  buildBranch(sessionId: string, branchId = sessionId): TrajectoryNode[] {
    const session = this.store.findSession(sessionId)
    const branch: BranchInfo = {
      branchId,
      branchType: branchTypeOf(session),
      parentBranchId: null,
      parentSessionId: session?.parentSessionId ?? null,
      label: session?.subagentLabel,
    }
    return this.buildChain(sessionId, branch)
  }

  /** Resolve one node by id without building the whole tree. */
  findNode(nodeId: string): TrajectoryNode | undefined {
    const parsed = parseNodeId(nodeId)
    if (parsed === undefined) return undefined
    const event = this.store.listEventsBySession(parsed.sessionId, { fromSeq: parsed.seq, limit: 1 })[0]
    if (event === undefined || event.seq !== parsed.seq) return undefined
    const session = this.store.findSession(parsed.sessionId)
    const branch: BranchInfo = {
      branchId: parsed.sessionId,
      branchType: branchTypeOf(session),
      parentBranchId: null,
      parentSessionId: session?.parentSessionId ?? null,
      label: session?.subagentLabel,
    }
    return this.nodeFromEvent(event, branch, null)
  }

  // ---- internals ----

  private buildSessionTree(sessionId: string, branch: BranchInfo, visited: Set<string>): TrajectoryNode | undefined {
    if (visited.has(sessionId)) {
      this.stats.skippedCycles += 1
      return undefined
    }
    visited.add(sessionId)
    this.stats.sessionsScanned += 1

    const chain = this.buildChain(sessionId, branch)
    const root = chain[0]
    if (root === undefined) return root

    // Attach descendant sessions (fork / subagent children) as subtrees.
    const children = this.store
      .listSessions(1_000_000)
      .filter(child => child.parentSessionId === sessionId)

    for (const child of children) {
      const attach = this.resolveAttachPoint(chain, child)
      if (attach === undefined) continue
      const childBranch: BranchInfo = {
        branchId: child.sessionId,
        branchType: child.origin === 'subagent' ? 'subagent' : 'fork',
        parentBranchId: branch.branchId,
        parentSessionId: sessionId,
        label: child.subagentLabel,
      }
      const subtree = this.buildSessionTree(child.sessionId, childBranch, visited)
      if (subtree === undefined) continue
      subtree.parentNodeId = attach.nodeId
      attach.children.push(subtree)
      this.stats.attachedChildren += 1
    }

    return root
  }

  /** Chain one session's events in seq order (time jitter tolerated). */
  private buildChain(sessionId: string, branch: BranchInfo): TrajectoryNode[] {
    const events = this.store.listEventsBySession(sessionId, { limit: 1_000_000 })
    const chain: TrajectoryNode[] = []
    let prev: TrajectoryNode | null = null
    let prevTime = -Infinity
    for (const event of events) {
      if (event.time < prevTime) this.stats.jitterCount += 1
      prevTime = event.time
      const node = this.nodeFromEvent(event, branch, prev?.nodeId ?? null)
      if (prev !== null) prev.children.push(node)
      chain.push(node)
      prev = node
      this.stats.nodesBuilt += 1
    }
    return chain
  }

  private nodeFromEvent(event: StoredEvent, branch: BranchInfo, parentNodeId: string | null): TrajectoryNode {
    return {
      nodeId: nodeIdFor(event.sessionId, event.seq),
      sessionId: event.sessionId,
      branchId: branch.branchId,
      parentNodeId,
      eventType: event.type,
      kind: event.kind,
      category: event.category,
      timestamp: event.time,
      seq: event.seq,
      data: event.data,
      raw: event.raw,
      isSnapshot: false,
      anomalyInfo: null,
      children: [],
      branch,
    }
  }

  private resolveAttachPoint(parentChain: TrajectoryNode[], child: SessionRecord): TrajectoryNode | undefined {
    if (parentChain.length === 0) return undefined
    const anchorTime = this.firstEventTime(child.sessionId) ?? child.createdAt

    // 1) subagent: nearest subagent tool/call at or before the child's first event
    if (child.origin === 'subagent') {
      let best: TrajectoryNode | undefined
      for (const node of parentChain) {
        if (node.eventType !== 'tool/call') continue
        const name = node.data.name
        if (typeof name !== 'string' || !this.opts.subagentToolNames.includes(name)) continue
        if (node.timestamp > anchorTime) continue
        if (best === undefined || anchorTime - node.timestamp < anchorTime - best.timestamp) best = node
      }
      if (best !== undefined) return best
    }

    // 2) fork: parent node at seq = seedLength - 1 (the seeded boundary)
    if (child.seedLength !== undefined && child.seedLength > 0) {
      const boundarySeq = child.seedLength - 1
      const exact = parentChain.find(node => node.seq === boundarySeq)
      if (exact !== undefined) return exact
      let best: TrajectoryNode | undefined
      for (const node of parentChain) {
        if (node.seq <= boundarySeq && (best === undefined || node.seq > best.seq)) best = node
      }
      if (best !== undefined) return best
    }

    // 3) fallback: last parent node at or before the child's creation
    let best: TrajectoryNode | undefined
    for (const node of parentChain) {
      if (node.timestamp <= anchorTime && (best === undefined || node.timestamp > best.timestamp)) best = node
    }
    return best ?? parentChain[parentChain.length - 1]
  }

  private firstEventTime(sessionId: string): number | undefined {
    return this.store.listEventsBySession(sessionId, { limit: 1 })[0]?.time
  }
}

function branchTypeOf(session: SessionRecord | undefined): BranchInfo['branchType'] {
  if (session === undefined) return 'main'
  if (session.origin === 'subagent') return 'subagent'
  if (session.parentSessionId !== undefined) return 'fork'
  return 'main'
}

function freshStats(): BuildStats {
  return { sessionsScanned: 0, nodesBuilt: 0, attachedChildren: 0, jitterCount: 0, skippedCycles: 0 }
}
