/**
 * Trajectory tree vocabulary.
 *
 * A trajectory tree is a cross-session forest folded into one root:
 *   - within a session the durable log is a linear chain keyed by `seq`
 *     (time is display-only; small inversions are tolerated, never split);
 *   - fork / subagent children are their OWN sessions (parentSessionId +
 *     seedLength / origin), attached as subtrees at a parent-chain node;
 *   - branchId === sessionId (a branch IS a session).
 */

/** Forward declaration (full shape finalized in phase 4). */
export type AnomalyType = 'loop_deadlock' | 'invalid_retry' | 'goal_drift'

export interface AnomalyResult {
  anomalyId: string
  type: AnomalyType
  startNodeId: string
  endNodeId: string
  /** 0..1 */
  confidence: number
  description: string
  suggestion?: string
}

export type BranchType = 'main' | 'subagent' | 'fork'

export interface BranchInfo {
  branchId: string
  branchType: BranchType
  /** branchId of the branch this one attaches into. */
  parentBranchId: string | null
  parentSessionId: string | null
  /** subagent descriptor label, when known. */
  label?: string
}

export interface TrajectoryNode {
  /** `${sessionId}:${seq}` — globally unique. */
  nodeId: string
  sessionId: string
  branchId: string
  parentNodeId: string | null
  eventType: string
  kind: string
  category: string
  /** Unix epoch ms. */
  timestamp: number
  seq: number
  /** Normalized scalar summary. */
  data: Record<string, unknown>
  /** Full raw envelope (JSON by contract). */
  raw: unknown
  /** Set by the snapshot layer (phase 3). */
  isSnapshot: boolean
  /** Set by the diagnosis engine (phase 4). */
  anomalyInfo: AnomalyResult | null
  children: TrajectoryNode[]
  branch: BranchInfo
}

export interface BuildStats {
  sessionsScanned: number
  nodesBuilt: number
  attachedChildren: number
  /** events whose time regressed vs the previous seq (async jitter, tolerated). */
  jitterCount: number
  /** session cycles skipped (malformed lineage). */
  skippedCycles: number
}
