/**
 * Public query facade over the tree builder — the API the UI/CLI will call:
 *   buildTrajectoryTree(sessionId)  — full cross-session tree
 *   getBranchTrajectory(sessionId, branchId?) — one branch's linear chain
 *   getNodeById(nodeId)             — single node without building the tree
 *   toJSON(node, opts?)             — JSON export (raw included by default)
 */
import type { EventStore } from '../persistence/event-store.js'
import { TrajectoryTreeBuilder, type TreeBuildOptions } from './tree-builder.js'
import type { TrajectoryNode } from './types.js'

export function buildTrajectoryTree(
  store: EventStore,
  sessionId: string,
  opts?: TreeBuildOptions,
): TrajectoryNode | undefined {
  return new TrajectoryTreeBuilder(store, opts).build(sessionId)
}

export function getBranchTrajectory(
  store: EventStore,
  sessionId: string,
  branchId?: string,
  opts?: TreeBuildOptions,
): TrajectoryNode[] {
  return new TrajectoryTreeBuilder(store, opts).buildBranch(sessionId, branchId)
}

export function getNodeById(store: EventStore, nodeId: string): TrajectoryNode | undefined {
  return new TrajectoryTreeBuilder(store).findNode(nodeId)
}

export interface TreeJsonOptions {
  /** Omit the raw envelope (UI payloads). Default: keep raw. */
  stripRaw?: boolean
}

export function toJSON(node: TrajectoryNode, opts: TreeJsonOptions = {}): unknown {
  const { stripRaw = false } = opts
  const plain: Record<string, unknown> = {
    nodeId: node.nodeId,
    sessionId: node.sessionId,
    branchId: node.branchId,
    parentNodeId: node.parentNodeId,
    eventType: node.eventType,
    kind: node.kind,
    category: node.category,
    timestamp: node.timestamp,
    seq: node.seq,
    data: node.data,
    isSnapshot: node.isSnapshot,
    anomalyInfo: node.anomalyInfo,
    branch: node.branch,
    children: node.children.map(child => toJSON(child, opts)),
  }
  if (!stripRaw) plain.raw = node.raw
  return plain
}
