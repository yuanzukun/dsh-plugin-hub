/**
 * Core host plugin entry (Cordis function form) — the "core row".
 *
 * Responsibilities: SQLite persistence (plugin-private) + session event
 * subscription + async diagnosis runtime. Deliberately has NO dependency on
 * webServer so it activates in ANY profile (web, headless, …).
 *
 * The JSON API + UI tab live in the separate "API row" (src/api/plugin.ts,
 * cordis.patch.yml row `trajectory-governance-api` with `inject: [webServer]`),
 * which the loader activates only when webServer is available — that is the
 * service-availability-driven activation the harness relies on.
 *
 * Boundaries: this plugin only consumes emit-mode events (post-commit,
 * read-only). It never mutates a payload, never registers a waterfall that
 * could steer execution, and never touches the harness kernel or host storage.
 */
import { homedir } from 'node:os'
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import { installSessionEventSubscription } from './ingest/session-event-subscriber.js'
import { EventStore } from './persistence/event-store.js'
import { mergeDiagnosisConfig, type DiagnosisConfig } from './diagnose/config.js'
import { installDiagnosisRuntime } from './diagnose/runtime.js'

export const name = 'trajectory-governance'

export interface TrajectoryGovernanceConfig {
  /**
   * Plugin-private SQLite storage. Defaults to
   * ~/.dsh-trajectory-governance/trajectory.db — independent of DSH host
   * storage; overridable per row via the patch `config`.
   */
  storage?: { path?: string }
  /** Diagnosis strategy thresholds; deep-merged over defaults. */
  diagnosis?: Partial<DiagnosisConfig>
}

export function apply(ctx: Context, config: TrajectoryGovernanceConfig = {}): void {
  const dbPath = config.storage?.path ?? join(homedir(), '.dsh-trajectory-governance', 'trajectory.db')

  const store = EventStore.open(dbPath)
  ctx.effect(() => () => {
    store.close()
    ctx.logger.info('[trajectory-governance] storage closed')
  })

  installSessionEventSubscription(ctx, store)

  const diagnosis = mergeDiagnosisConfig(config.diagnosis)
  installDiagnosisRuntime(ctx, store, diagnosis)

  ctx.logger.info(
    `[trajectory-governance] loaded; storage=${dbPath} sessions=${store.countSessions()} events=${store.countEvents()} anomalies=${store.countAnomalies()}`,
  )
}
