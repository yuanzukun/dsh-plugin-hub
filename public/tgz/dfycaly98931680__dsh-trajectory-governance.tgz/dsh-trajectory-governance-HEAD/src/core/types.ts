/**
 * Core type vocabulary.
 *
 * The raw session-event envelope mirrors the official persistence catalog
 * (docs/persistence-catalog.md @ deepseek-ai/deepseek-harness, master).
 * The normalized vocabulary is what the tree builder, snapshot layer, and
 * diagnosis engine reason over. Session payloads are JSON-serializable by
 * contract (enforced at `Session.append`), so scalar extraction and raw JSON
 * persistence are safe.
 */

/** One immutable entry in the session log (official envelope subset). */
export interface RawSessionEvent<TData = unknown> {
  type: string
  /** Monotonic sequence number within the session. */
  seq: number
  /** Unix epoch milliseconds. */
  time: number
  data: TData
  /**
   * Unknown-type skip marker. Absent means required: an unrecognized type
   * without this marker must be refused, not silently dropped.
   */
  ignorable?: true
  /** Surface events only: how the event entered the ordered surface. */
  surfaceOp?: 'append' | { op: 'replace'; start: number; end: number }
  /** Surface events only: seqs of earlier events this event cites as sources. */
  sourceEventSeqs?: number[]
}

/** Durable cancellation cause of an aborted turn (official subset). */
export type TurnEndCancelCause =
  | { kind: 'user' }
  | { kind: 'parent' }
  | { kind: 'hook'; reason: string }
  | { kind: 'disposed' }
  | { kind: 'legacy' }

/** Structured LLM failure carried by an error turn end (official subset). */
export interface LlmFailure {
  message: string
  code?: string
}

/** Merge-extensible turn-end reason (official TurnEndReasonMap subset). */
export type TurnEndReason =
  | { kind: 'completed' }
  | { kind: 'aborted'; reason: TurnEndCancelCause }
  | { kind: 'blocked' }
  | { kind: 'error'; error: LlmFailure }
  | { kind: 'max-tokens' }
  | { kind: 'interrupted' }

/**
 * Durable session lineage fields (official SessionHeader subset).
 * A fork or subagent child carries parentSessionId + origin, and seedLength
 * marks where constructor-seeded history ends (`session/end-seed` is the
 * durable projection of the same boundary).
 */
export interface SessionLineage {
  sessionId: string
  parentSessionId?: string
  origin?: 'subagent'
  seedLength?: number
  cwd?: string
  agentPreset?: string
  createdAt: number
}

/** Normalized event kind the plugin reasons over. */
export type NormalizedEventKind =
  | 'turn-start'
  | 'turn-end'
  | 'step-start'
  | 'step-end'
  | 'user-message'
  | 'assistant-message'
  | 'assistant-chunk'
  | 'tool-call'
  | 'tool-result'
  | 'plan-mode'
  | 'goal-change'
  | 'subagent-descriptor'
  | 'end-seed'
  | 'retry'
  | 'retry-start'
  | 'other'

/** Broad category for filtering / analytics. */
export type EventCategory =
  | 'core-loop'
  | 'lifecycle'
  | 'goal-plan'
  | 'meta'
  | 'retry'
  | 'unknown'

/**
 * Normalized event after extraction — scalars only, JSON-safe.
 * For in-session events branchId === sessionId; fork/subagent children get
 * their own branch (their sessionId).
 */
export interface NormalizedEvent {
  sessionId: string
  branchId: string
  parentSessionId?: string
  origin?: 'subagent'
  seq: number
  time: number
  type: string
  kind: NormalizedEventKind
  category: EventCategory
  surface: boolean
  /** True when the writer marked this event ignorable (unknown types may be skipped). */
  ignorable: boolean
  /** Scalar payload summary extracted per event type. */
  data: Record<string, unknown>
}
