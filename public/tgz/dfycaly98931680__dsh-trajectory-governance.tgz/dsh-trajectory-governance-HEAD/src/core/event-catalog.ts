/**
 * Session event catalog — the single mapping table between raw session event
 * types and the plugin's normalized vocabulary.
 *
 * The 44 official types are generated from the harness source
 * (packages/core/session/src/known-event-types.ts ==
 * docs/persistence-catalog.md). Keep this table the ONLY place a vocabulary
 * change lands (preview API: `SESSION_FORMAT_VERSION = 0`, no compatibility
 * implied).
 *
 * ignorableHint stays conservative (false) for every type: the authoritative
 * signal is the runtime envelope's own `event.ignorable` marker, honored in
 * the normalizer.
 */
import type { EventCategory, NormalizedEventKind } from './types.js'

export interface EventCatalogEntry {
  type: string
  kind: NormalizedEventKind
  category: EventCategory
  surface: boolean
  description: string
}

/** The 44 official session event types (mirror of KNOWN_SESSION_EVENT_TYPES). */
export const KNOWN_EVENT_TYPES: readonly string[] = [
  'agent-preset/selected',
  'agent/inbox/spliced',
  'approval/asked',
  'approval/decided',
  'approval/policy',
  'assistant/chunk',
  'assistant/message',
  'command/done',
  'command/run',
  'compaction/end',
  'compaction/prune',
  'compaction/start',
  'compaction/summary',
  'feedback/record',
  'goal/change',
  'hook/invoked',
  'hook/result',
  'llm/retry',
  'llm/retry-started',
  'permission/preset',
  'plan/mode',
  'request/context',
  'request/header',
  'sandbox/mode',
  'schedule/change',
  'session/end-seed',
  'session/title',
  'session/title-llm-request',
  'step/end',
  'step/start',
  'subagent/descriptor',
  'todo/write',
  'tool-workflow/agent-end',
  'tool-workflow/agent-start',
  'tool-workflow/run-end',
  'tool-workflow/run-start',
  'tool/call',
  'tool/code-dispatch',
  'tool/code-dispatch-start',
  'tool/result',
  'turn/end',
  'turn/start',
  'user/message',
  'web/deepseek-search-llm-request',
]

const e = (
  type: string,
  kind: NormalizedEventKind,
  category: EventCategory,
  surface: boolean,
  description: string,
): EventCatalogEntry => ({ type, kind, category, surface, description })

export const EVENT_CATALOG: Readonly<Record<string, EventCatalogEntry>> = {
  // ---- core loop ----
  'turn/start': e('turn/start', 'turn-start', 'core-loop', false, 'Opens turn N before the loop claims queued input or runs pre-step.'),
  'turn/end': e('turn/end', 'turn-end', 'core-loop', false, 'Closes turn N with the TurnEndReason that ended it (completed/aborted/blocked/error/max-tokens/interrupted).'),
  'step/start': e('step/start', 'step-start', 'core-loop', false, 'Opens step N of turn M — one model call plus the tool executions it requested.'),
  'step/end': e('step/end', 'step-end', 'core-loop', false, 'Closes step N of turn M.'),
  'user/message': e('user/message', 'user-message', 'core-loop', true, 'User-role message on the model-visible surface: direct prompt, injected context, or goal continuation round.'),
  'assistant/message': e('assistant/message', 'assistant-message', 'core-loop', true, 'Assembled assistant message on the surface.'),
  'assistant/chunk': e('assistant/chunk', 'assistant-chunk', 'core-loop', false, 'Raw assistant token chunk; feeds the message assembler and UI streaming.'),
  'request/header': e('request/header', 'other', 'meta', false, 'LLM request header snapshot (records when the header differs from baseline).'),
  'request/context': e('request/context', 'other', 'meta', false, 'LLM request context snapshot (provider/model/context-window changes).'),
  'tool/call': e('tool/call', 'tool-call', 'core-loop', false, 'Model requested one tool invocation: name + raw arguments JSON string; callId pairs with tool/result.'),
  'tool/result': e('tool/result', 'tool-result', 'core-loop', true, 'Tool execution result on the surface; pairs with its tool/call via callId.'),
  'tool/code-dispatch': e('tool/code-dispatch', 'other', 'meta', false, 'Durable log copy of one run_code sub-dispatch outcome.'),
  'tool/code-dispatch-start': e('tool/code-dispatch-start', 'other', 'meta', false, 'run_code sub-dispatch started.'),
  // ---- lifecycle ----
  'session/end-seed': e('session/end-seed', 'end-seed', 'lifecycle', false, 'First live write of a seeded session (resume/fork/replay); events before it came from the seed.'),
  'subagent/descriptor': e('subagent/descriptor', 'subagent-descriptor', 'lifecycle', false, 'Durable identity/mode of a session-backed subagent child (one-shot|continuable).'),
  'agent-preset/selected': e('agent-preset/selected', 'other', 'lifecycle', false, 'Agent preset selected for a session.'),
  'command/run': e('command/run', 'other', 'lifecycle', false, 'A CLI command ran.'),
  'command/done': e('command/done', 'other', 'lifecycle', false, 'A CLI command finished.'),
  // ---- goal / plan ----
  'plan/mode': e('plan/mode', 'plan-mode', 'goal-plan', false, 'Plan mode toggled (log-only, whole-value replace { active }).'),
  'goal/change': e('goal/change', 'goal-change', 'goal-plan', false, 'Goal state changed (continuation rounds).'),
  // ---- retry / error signals ----
  'llm/retry': e('llm/retry', 'retry', 'retry', false, 'An LLM request was retried after a failure.'),
  'llm/retry-started': e('llm/retry-started', 'retry-start', 'retry', false, 'A retry attempt started.'),
  // ---- meta ----
  'agent/inbox/spliced': e('agent/inbox/spliced', 'other', 'meta', false, 'One normalized mutation of an agent\'s durable pending-message lists.'),
  'approval/asked': e('approval/asked', 'other', 'meta', false, 'An approval was requested.'),
  'approval/decided': e('approval/decided', 'other', 'meta', false, 'An approval was decided.'),
  'approval/policy': e('approval/policy', 'other', 'meta', false, 'Approval policy changed.'),
  'compaction/start': e('compaction/start', 'other', 'meta', false, 'Compaction opened.'),
  'compaction/end': e('compaction/end', 'other', 'meta', false, 'Compaction closed.'),
  'compaction/prune': e('compaction/prune', 'other', 'meta', false, 'Compaction pruned tool results.'),
  'compaction/summary': e('compaction/summary', 'other', 'meta', false, 'Compaction summary.'),
  'feedback/record': e('feedback/record', 'other', 'meta', false, 'User feedback recorded.'),
  'hook/invoked': e('hook/invoked', 'other', 'meta', false, 'A hook was invoked.'),
  'hook/result': e('hook/result', 'other', 'meta', false, 'A hook returned a result.'),
  'permission/preset': e('permission/preset', 'other', 'meta', false, 'Permission preset changed.'),
  'sandbox/mode': e('sandbox/mode', 'other', 'meta', false, 'Sandbox mode changed.'),
  'schedule/change': e('schedule/change', 'other', 'meta', false, 'Schedule changed.'),
  'session/title': e('session/title', 'other', 'meta', false, 'Session title changed.'),
  'session/title-llm-request': e('session/title-llm-request', 'other', 'meta', false, 'Auxiliary LLM title request recorded.'),
  'todo/write': e('todo/write', 'other', 'meta', false, 'Whole-list todo snapshot; latest write wins on replay.'),
  'tool-workflow/run-start': e('tool-workflow/run-start', 'other', 'meta', false, 'Workflow run started.'),
  'tool-workflow/run-end': e('tool-workflow/run-end', 'other', 'meta', false, 'Workflow run ended.'),
  'tool-workflow/agent-start': e('tool-workflow/agent-start', 'other', 'meta', false, 'Workflow subagent started.'),
  'tool-workflow/agent-end': e('tool-workflow/agent-end', 'other', 'meta', false, 'Workflow subagent ended.'),
  'web/deepseek-search-llm-request': e('web/deepseek-search-llm-request', 'other', 'meta', false, 'Auxiliary DeepSeek search LLM request recorded before dispatch.'),
}

/** Fallback entry for unknown event types. */
export const UNKNOWN_EVENT: EventCatalogEntry = {
  type: '__unknown__',
  kind: 'other',
  category: 'unknown',
  surface: false,
  description: 'Unknown event type. Honor the runtime ignorable marker: skip only when ignorable === true, otherwise record/refuse.',
}

/** Classify one raw event type; unknown types fall back to UNKNOWN_EVENT. */
export function classifyEvent(type: string): EventCatalogEntry {
  return EVENT_CATALOG[type] ?? UNKNOWN_EVENT
}

/** True when the event type is part of the official known vocabulary. */
export function isKnownEventType(type: string): boolean {
  return type in EVENT_CATALOG
}
