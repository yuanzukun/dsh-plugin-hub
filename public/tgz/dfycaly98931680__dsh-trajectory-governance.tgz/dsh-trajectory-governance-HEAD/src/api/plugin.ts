/**
 * API row plugin entry (Cordis function form).
 *
 * Loaded as a SEPARATE cordis.patch.yml row with `inject: [webServer]`, so the
 * harness activates it only once webServer is available (service-availability
 * driven). In profiles without webServer (e.g. headless) this row simply never
 * activates, while the core row keeps recording events.
 *
 * Both rows share the same plugin-private SQLite file (default path below, or
 * the per-row `config.storage.path` — keep both rows consistent if you
 * override it).
 */
import { homedir } from 'node:os'
import { join } from 'node:path'
import type { Context } from '@deepseek-ai/cordis'
import { DiagnosisEngine } from '../diagnose/engine.js'
import { mergeDiagnosisConfig, type DiagnosisConfig } from '../diagnose/config.js'
import { EventStore } from '../persistence/event-store.js'
import { installTrajectoryApi, type ApiHostContext } from './http.js'

export const name = 'trajectory-governance-api'

export interface TrajectoryApiConfig {
  storage?: { path?: string }
  diagnosis?: Partial<DiagnosisConfig>
}

export function apply(ctx: Context, config: TrajectoryApiConfig = {}): void {
  const dbPath = config.storage?.path ?? join(homedir(), '.dsh-trajectory-governance', 'trajectory.db')

  const store = EventStore.open(dbPath)
  ctx.effect(() => () => {
    store.close()
  })

  const engine = new DiagnosisEngine(store, mergeDiagnosisConfig(config.diagnosis))
  // `webServer` is declared by this row's inject, so the loader guarantees it
  // is ready here. The preview Context types don't expose it; the runtime ctx
  // satisfies ApiHostContext structurally (see api/http.ts).
  installTrajectoryApi(ctx as unknown as ApiHostContext, store, engine)

  ctx.logger.info(
    `[trajectory-governance-api] loaded; serving /trajectory-governance/api/* sessions=${store.countSessions()} anomalies=${store.countAnomalies()}`,
  )
}
