/**
 * Host JSON API for the UI tab — same-origin, exact routes under
 * /trajectory-governance/api/*, registered through ctx.webServer.
 *
 * The handler core (createTrajectoryApi) is a pure function over (store,
 * engine) and is unit-tested directly; installTrajectoryApi only adapts it to
 * the webServer request/response objects.
 */
import type { DiagnosisEngine } from '../diagnose/engine.js'
import { mountAnomalies } from '../diagnose/mount.js'
import { CostEstimator } from '../diagnose/cost.js'
import {
  buildSessionWasteReport,
  buildWasteReport,
  sessionWasteToMarkdown,
  wasteReportToMarkdown,
} from '../report/waste-report.js'
import type { EventStore, AnomalyRow } from '../persistence/event-store.js'
import { SnapshotService } from '../snapshot/snapshot-service.js'
import { deleteBranch, listBranches } from '../snapshot/branch-manager.js'
import { buildTrajectoryTree, getNodeById, toJSON } from '../tree/queries.js'

export const API_BASE = '/trajectory-governance/api'

/**
 * Structural host-context face used by the API installer. The harness ctx
 * satisfies this at runtime; the preview type declarations do not yet expose
 * `webServer` on Context, so a contained cast at the call site bridges the gap
 * (no module augmentation that would shadow Context's other members).
 *
 * IMPORTANT (runtime findings):
 *  - direct property access (`ctx.webServer`) is rejected by the Guard
 *    ("cannot get property X without inject");
 *  - `ctx.inject(['webServer'], cb)` did NOT fire its callback in the live
 *    web profile (routes never registered; API fell back to the SPA page);
 *  - the sanctioned optional-capability read is `ctx.get(name)` (core method,
 *    Guard-free, non-blocking): if the service is absent (e.g. headless), the
 *    plugin still records events and simply exposes no API.
 */
export interface ApiWebServer {
  register(route: {
    kind: 'exact'
    path: string
    handler: (
      request: HttpRequestLike,
      response: HttpResponseLike,
    ) => void | Promise<void>
  }): () => void
}

export interface ApiHostContext {
  effect(setup: () => (() => void) | void, label?: string): unknown
  get(name: string): unknown
  logger?: {
    warn(message: unknown, ...args: unknown[]): void
  }
}

interface HttpRequestLike {
  method?: string
  url?: string
  on(event: 'data', listener: (chunk: Uint8Array | string) => void): unknown
  on(event: 'end', listener: () => void): unknown
  on(event: 'error', listener: (error: unknown) => void): unknown
}

interface HttpResponseLike {
  writeHead(status: number, headers?: Record<string, string>): unknown
  end(body?: string): void
}

export interface ApiRequest {
  method: string
  url: string
  body?: unknown
}

export interface ApiResponse {
  status: number
  json: unknown
}

export interface TrajectoryApi {
  handle(request: ApiRequest): Promise<ApiResponse>
}

export interface InterruptResult {
  ok: boolean
  error?: string
}

export interface ForkResult {
  ok: boolean
  childSessionId?: string
  boundarySeq?: number
  error?: string
}

export interface TrajectoryApiDeps {
  /** Stop one agent session via the official `agent.cancel` capability. */
  interrupt?: (sessionId: string) => Promise<InterruptResult> | InterruptResult
  /** Branch a new session from a stable point via the official `sessions.fork`. */
  fork?: (sessionId: string, boundarySeq: number) => Promise<ForkResult> | ForkResult
  /** Rename via the official `sessionTitle.rename` (pins; stops auto-generation). */
  rename?: (sessionId: string, title: string) => Promise<{ ok: boolean; error?: string }> | { ok: boolean; error?: string }
  /**
   * Backfill the official title for sessions whose `session/title` event
   * predates this plugin (live session events, else persisted sessionQuery).
   */
  readTitle?: (sessionId: string) => Promise<string | undefined> | string | undefined
}

export function createTrajectoryApi(
  store: EventStore,
  engine: DiagnosisEngine,
  deps: TrajectoryApiDeps = {},
): TrajectoryApi {
  const snapshots = new SnapshotService(store)
  const config = engine.getConfig()
  const cost = new CostEstimator(store, {
    tokenPricePerM: config.cost.tokenPricePerM,
    estimateWhenUsageMissing: config.cost.estimateWhenUsageMissing,
  })

  const anomalyWithCost = (a: AnomalyRow): Record<string, unknown> => {
    const start = seqOf(a.startNodeId)
    const end = seqOf(a.endNodeId)
    return {
      anomalyId: a.anomalyId,
      sessionId: a.sessionId,
      type: a.type,
      startNodeId: a.startNodeId,
      endNodeId: a.endNodeId,
      confidence: a.confidence,
      severity: a.severity ?? null,
      description: a.description,
      suggestion: a.suggestion ?? null,
      createdAt: a.createdAt,
      updatedAt: a.updatedAt,
      cost: cost.estimate(a.sessionId, start, end),
    }
  }

  return {
    async handle(request) {
      const url = new URL(request.url, 'http://dsh.local')
      const path = url.pathname
      const q = url.searchParams
      const method = request.method.toUpperCase()

      try {
        // ---- sessions (with wasted-token attribution + title backfill) ----
        if (method === 'GET' && path === `${API_BASE}/sessions`) {
          const rows = store.listSessions(500)
          const sessions = await Promise.all(rows.map(async session => {
            let wastedTokens = 0
            if (config.cost.enabled) {
              for (const a of store.listAnomalies({ sessionId: session.sessionId, limit: 1000 })) {
                wastedTokens += cost.estimate(a.sessionId, seqOf(a.startNodeId), seqOf(a.endNodeId)).tokens
              }
            }
            // title backfill: official titles predating this plugin are not in
            // our event store — read them from the official log on demand.
            let title = session.displayName ?? session.autoTitle ?? null
            if (title === null && deps.readTitle !== undefined) {
              try {
                const official = await deps.readTitle(session.sessionId)
                if (official !== undefined && official !== '') {
                  store.setTitle(session.sessionId, { autoTitle: official })
                  title = official
                }
              } catch { /* backfill is best-effort */ }
            }
            return {
              sessionId: session.sessionId,
              parentSessionId: session.parentSessionId ?? null,
              origin: session.origin ?? null,
              status: session.status,
              createdAt: session.createdAt,
              lastEventSeq: session.lastEventSeq,
              lastEventAt: session.lastEventAt ?? null,
              eventCount: store.countEventsBySession(session.sessionId),
              anomalyCount: store.countAnomaliesBySession(session.sessionId),
              wastedTokens,
              title,
            }
          }))
          return { status: 200, json: { sessions } }
        }

        // ---- alerts (incremental, with cost + action tier + stop-loss message) ----
        if (method === 'GET' && path === `${API_BASE}/alerts`) {
          const sessionId = q.get('sessionId') ?? undefined
          const since = Number(q.get('since') ?? 0)
          const anomalies = store.listAnomalies({ sessionId, limit: 1000 })
            .filter(a => a.updatedAt > since)
            .map(a => anomalyWithCost(a))
          return { status: 200, json: { alerts: anomalies } }
        }

        // ---- rename a session (official sessionTitle.rename, local mirror) ----
        if (method === 'POST' && path === `${API_BASE}/actions/rename`) {
          const body = asRecord(request.body)
          const sessionId = stringOf(body.sessionId)
          const title = stringOf(body.title)
          if (sessionId === undefined) return badRequest('sessionId required')
          if (title === undefined || title.trim() === '') return badRequest('title required')
          store.setTitle(sessionId, { displayName: title.trim() })
          let official = false
          if (deps.rename !== undefined) {
            const result = await deps.rename(sessionId, title.trim())
            official = result.ok
            if (!result.ok) {
              // local mirror succeeded even if the live session is gone
              return { status: 200, json: { ok: true, official: false, error: result.error } }
            }
          }
          return { status: 200, json: { ok: true, official } }
        }

        // ---- stop one agent (official agent.cancel capability) ----
        if (method === 'POST' && path === `${API_BASE}/actions/interrupt`) {
          const body = asRecord(request.body)
          const sessionId = stringOf(body.sessionId)
          if (sessionId === undefined) return badRequest('sessionId required')
          if (deps.interrupt === undefined) {
            return { status: 501, json: { error: 'interrupt capability unavailable (no agents service)' } }
          }
          const result = await deps.interrupt(sessionId)
          return { status: result.ok ? 200 : 409, json: result }
        }

        // ---- branch a new session from a stable point (official sessions.fork) ----
        if (method === 'POST' && path === `${API_BASE}/actions/fork`) {
          const body = asRecord(request.body)
          const sessionId = stringOf(body.sessionId)
          if (sessionId === undefined) return badRequest('sessionId required')
          if (deps.fork === undefined) {
            return { status: 501, json: { error: 'fork capability unavailable (no sessions service)' } }
          }
          const nodeId = stringOf(body.nodeId)
          const atSeq = numberOrUndefined(body.atSeq)
          const targetSeq = nodeId !== undefined ? seqOf(nodeId) : atSeq
          if (targetSeq === undefined || targetSeq < 0) return badRequest('nodeId or atSeq required')
          const boundarySeq = resolveBoundarySeq(store, sessionId, targetSeq)
          if (boundarySeq === undefined) {
            return { status: 409, json: { ok: false, error: `no stable turn boundary at/before seq ${targetSeq} — cannot fork inside an open turn` } }
          }
          const result = await deps.fork(sessionId, boundarySeq)
          return { status: result.ok ? 200 : 409, json: result }
        }

        // ---- waste attribution report ----
        if (method === 'GET' && path === `${API_BASE}/report/waste`) {
          const sessionId = q.get('sessionId') ?? undefined
          if (sessionId !== undefined) {
            const report = buildSessionWasteReport(store, cost, sessionId)
            if (report === undefined) return notFound(`waste report for ${sessionId} (no anomalies)`)
            report.markdown = sessionWasteToMarkdown(report)
            return { status: 200, json: report }
          }
          const report = buildWasteReport(store, cost)
          return { status: 200, json: { ...report, markdown: wasteReportToMarkdown(report) } }
        }

        // ---- tree ----
        if (method === 'GET' && path === `${API_BASE}/tree`) {
          const sessionId = q.get('sessionId')
          if (sessionId === null) return badRequest('sessionId required')
          const tree = buildTrajectoryTree(store, sessionId)
          if (tree === undefined) return notFound(`session ${sessionId}`)
          mountAnomalies(store, tree)
          return { status: 200, json: { tree: toJSON(tree, { stripRaw: true }) } }
        }

        // ---- branches ----
        if (method === 'GET' && path === `${API_BASE}/branches`) {
          const sessionId = q.get('sessionId')
          if (sessionId === null) return badRequest('sessionId required')
          return { status: 200, json: { branches: listBranches(store, sessionId) } }
        }

        // ---- anomalies ----
        if (method === 'GET' && path === `${API_BASE}/anomalies`) {
          const sessionId = q.get('sessionId') ?? undefined
          const type = q.get('type') ?? undefined
          const anomalies = store.listAnomalies({ sessionId, type, limit: 1000 }).map(a => ({
            anomalyId: a.anomalyId,
            type: a.type,
            startNodeId: a.startNodeId,
            endNodeId: a.endNodeId,
            confidence: a.confidence,
            severity: a.severity ?? null,
            description: a.description,
            suggestion: a.suggestion ?? null,
          }))
          return { status: 200, json: { anomalies } }
        }

        // ---- single node ----
        if (method === 'GET' && path === `${API_BASE}/node`) {
          const nodeId = q.get('nodeId')
          if (nodeId === null) return badRequest('nodeId required')
          const node = getNodeById(store, nodeId)
          if (node === undefined) return notFound(`node ${nodeId}`)
          return { status: 200, json: { node: toJSON(node, { stripRaw: false }) } }
        }

        // ---- snapshots ----
        if (method === 'GET' && path === `${API_BASE}/snapshots`) {
          const sessionId = q.get('sessionId') ?? undefined
          return { status: 200, json: { snapshots: snapshots.list({ sessionId, limit: 500 }) } }
        }
        if (method === 'POST' && path === `${API_BASE}/snapshots`) {
          const body = asRecord(request.body)
          const sessionId = stringOf(body.sessionId)
          if (sessionId === undefined) return badRequest('sessionId required')
          const snapshot = snapshots.create(sessionId, {
            nodeId: stringOf(body.nodeId),
            label: stringOf(body.label),
            note: stringOf(body.note),
          })
          if (snapshot === undefined) return badRequest('cannot create snapshot (node missing?)')
          return { status: 201, json: { snapshot } }
        }
        if (method === 'DELETE' && path === `${API_BASE}/snapshots`) {
          const snapshotId = q.get('snapshotId')
          if (snapshotId === null) return badRequest('snapshotId required')
          return { status: 200, json: { ok: snapshots.remove(snapshotId) } }
        }
        if (method === 'GET' && path === `${API_BASE}/snapshot-context`) {
          const snapshotId = q.get('snapshotId')
          if (snapshotId === null) return badRequest('snapshotId required')
          const ctx = snapshots.context(snapshotId)
          if (ctx === undefined) return notFound(`snapshot ${snapshotId}`)
          return {
            status: 200,
            json: {
              snapshot: ctx.snapshot,
              hashMatch: ctx.hashMatch,
              events: ctx.events.map(e => ({
                seq: e.seq, time: e.time, type: e.type, kind: e.kind,
                data: e.data, raw: e.raw,
              })),
            },
          }
        }

        // ---- prune ----
        if (method === 'POST' && path === `${API_BASE}/prune`) {
          const body = asRecord(request.body)
          const result = snapshots.prune({
            maxSnapshots: numberOrUndefined(body.maxSnapshots),
            ttlMs: numberOrUndefined(body.ttlMs),
            keepNewest: numberOrUndefined(body.keepNewest),
          })
          return { status: 200, json: { result } }
        }

        // ---- on-demand analysis ----
        if (method === 'POST' && path === `${API_BASE}/analyze`) {
          const body = asRecord(request.body)
          const sessionId = stringOf(body.sessionId)
          if (sessionId === undefined) return badRequest('sessionId required')
          const result = await engine.analyzeSession(sessionId, { full: body.full === true })
          return { status: 200, json: { result } }
        }

        // ---- delete observation branch ----
        if (method === 'DELETE' && path === `${API_BASE}/branch`) {
          const sessionId = q.get('sessionId')
          if (sessionId === null) return badRequest('sessionId required')
          return { status: 200, json: { result: deleteBranch(store, sessionId) } }
        }

        return { status: 404, json: { error: `no route ${method} ${path}` } }
      } catch (error) {
        return { status: 500, json: { error: errorMessage(error) } }
      }
    },
  }
}

/** Register every exact route on the harness web server (same-origin). */
export function installTrajectoryApi(ctx: ApiHostContext, store: EventStore, engine: DiagnosisEngine): void {
  // Stop capability: the official `agents` service (optional). We only trigger
  // the official `agent.cancel` — never monkey-patch or take over scheduling.
  const agents = ctx.get('agents') as AgentsLike | undefined
  const sessions = ctx.get('sessions') as SessionsLike | undefined
  const sessionQuery = ctx.get('sessionQuery') as SessionQueryLike | undefined
  const deps: TrajectoryApiDeps = {
    ...(agents === undefined ? {} : {
      interrupt: (sessionId): InterruptResult => {
        const agent = agents.list().find(a => a.id === sessionId)
        if (agent === undefined) return { ok: false, error: `no live agent ${sessionId}` }
        if (typeof agent.cancel !== 'function') return { ok: false, error: 'agent has no cancel capability' }
        agent.cancel({ kind: 'hook', reason: 'trajectory-governance: user-requested stop' })
        return { ok: true }
      },
    }),
    ...(sessions === undefined || typeof sessions.fork !== 'function' ? {} : {
      fork: (sessionId, boundarySeq): ForkResult => {
        const child = sessions.fork(sessionId, boundarySeq)
        if (child === undefined) return { ok: false, error: `sessions.fork returned no child for ${sessionId}` }
        return { ok: true, childSessionId: typeof child === 'string' ? child : child.id, boundarySeq }
      },
    }),
    // readTitle: the last official `session/title` from the live log, else the
    // persisted log via sessionQuery (covers sessions whose title predates us).
    ...((sessions === undefined || typeof sessions.get !== 'function') && sessionQuery === undefined ? {} : {
      readTitle: async (sessionId): Promise<string | undefined> => {
        const live = sessions?.get?.(sessionId) as SessionLikeEvents | undefined
        const events = live?.events
        if (events !== undefined) {
          const found = lastSessionTitle(events)
          if (found !== undefined) return found
        }
        if (sessionQuery === undefined || typeof sessionQuery.readSession !== 'function') return undefined
        try {
          const persisted = await sessionQuery.readSession(sessionId)
          return lastSessionTitle(persisted?.events ?? [])
        } catch { return undefined }
      },
    }),
    ...(sessions === undefined || typeof sessions.get !== 'function' ? {} : (() => {
      const sessionTitle = ctx.get('sessionTitle') as { rename?: (session: { id: string }, title: string) => unknown } | undefined
      return {
        rename: (sessionId, title): { ok: boolean; error?: string } => {
          if (sessionTitle === undefined || typeof sessionTitle.rename !== 'function') {
            return { ok: false, error: 'sessionTitle service unavailable' }
          }
          const liveSession = sessions.get?.(sessionId)
          if (liveSession === undefined) return { ok: false, error: `no live session ${sessionId}` }
          try {
            sessionTitle.rename(liveSession, title)
            return { ok: true }
          } catch (error) {
            return { ok: false, error: errorMessage(error) }
          }
        },
      }
    })()),
  }
  const api = createTrajectoryApi(store, engine, deps)
  const server = ctx.get('webServer') as ApiWebServer | undefined
  if (server === undefined) {
    ctx.logger?.warn?.('[trajectory-governance] webServer unavailable — API routes not registered (recording continues)')
    return
  }
  // Exact routes are keyed by PATH ONLY (method dispatch happens inside the
  // handler via api.handle), so each path is registered exactly once —
  // otherwise the webserver rejects duplicates (e.g. /snapshots GET/POST/DELETE).
  const paths = [
    '/sessions',
    '/alerts',
    '/tree',
    '/branches',
    '/anomalies',
    '/node',
    '/snapshots',
    '/snapshot-context',
    '/prune',
    '/analyze',
    '/branch',
    '/actions/interrupt',
    '/actions/fork',
    '/actions/rename',
    '/report/waste',
  ]
  for (const path of paths) {
    const fullPath = `${API_BASE}${path}`
    ctx.effect(() => server.register({
      kind: 'exact',
      path: fullPath,
      handler: (request, response) => {
        void handleHttp(api, request, response)
      },
    }), `trajectory-governance:api ${fullPath}`)
  }
}

async function handleHttp(api: TrajectoryApi, request: HttpRequestLike, response: HttpResponseLike): Promise<void> {
  try {
    const body = await readBody(request)
    const result = await api.handle({ method: request.method ?? 'GET', url: request.url ?? '', body })
    writeJson(response, result.status, result.json)
  } catch (error) {
    writeJson(response, 500, { error: errorMessage(error) })
  }
}

function readBody(request: HttpRequestLike): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = []
    request.on('data', chunk => {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(String(chunk)))
    })
    request.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8').trim()
      resolve(raw === '' ? undefined : JSON.parse(raw) as unknown)
    })
    request.on('error', reject)
  })
}

function writeJson(response: HttpResponseLike, status: number, json: unknown): void {
  response.writeHead(status, { 'content-type': 'application/json; charset=utf-8' })
  response.end(JSON.stringify(json))
}

// ---- helpers ----

function asRecord(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {}
}

function stringOf(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

function numberOrUndefined(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

/** Loose read face of the official `agents` service (cancel capability only). */
interface AgentsLike {
  list(): Array<{
    id: string
    cancel?(cause: { kind: 'hook'; reason: string }, options?: { keepInbox?: boolean }): void
  }>
}

/** Loose read face of the official `sessions` service (fork + get capabilities). */
interface SessionsLike {
  fork(source: string, boundary?: number, childSessionId?: string): { id: string } | undefined
  get?(sessionId: string): { id: string; events?: readonly unknown[] } | undefined
}

/** Loose read face of the official persisted session query service. */
interface SessionQueryLike {
  readSession?(sessionId: string): Promise<{ events?: readonly unknown[] }> | { events?: readonly unknown[] }
}

/** Loose shape of a live session's event log (title lookup). */
interface SessionLikeEvents {
  events?: readonly unknown[]
}

/** Last `session/title` event's title from a raw event list (defensive). */
function lastSessionTitle(events: readonly unknown[]): string | undefined {
  let title: string | undefined
  for (const event of events) {
    const record = event as { type?: unknown; data?: { title?: unknown } }
    if (record?.type === 'session/title') {
      const candidate = record.data?.title
      if (typeof candidate === 'string' && candidate !== '') title = candidate
    }
  }
  return title
}

function seqOf(nodeId: string): number {
  const idx = nodeId.lastIndexOf(':')
  const seq = Number(nodeId.slice(idx + 1))
  return Number.isSafeInteger(seq) ? seq : -1
}

/**
 * Official `sessions.fork` requires the chosen prefix to end OUTSIDE an open
 * turn. Resolve a target seq down to the nearest `turn/end` at or before it —
 * the stable boundary we can safely fork at. Returns undefined when the
 * session has no turn boundary yet (nothing safe to fork from).
 */
function resolveBoundarySeq(store: EventStore, sessionId: string, targetSeq: number): number | undefined {
  const events = store.listEventsBySession(sessionId, { fromSeq: 0, limit: targetSeq + 1 })
  let boundary: number | undefined
  for (const event of events) {
    if (event.seq > targetSeq) break
    if (event.type === 'turn/end') boundary = event.seq
  }
  return boundary
}

function badRequest(message: string): ApiResponse {
  return { status: 400, json: { error: message } }
}

function notFound(what: string): ApiResponse {
  return { status: 404, json: { error: `${what} not found` } }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
