/**
 * Session event subscription layer.
 *
 * Subscribes the plugin to the harness's Cordis event bus (emit-mode events
 * only: post-commit, fire-and-forget, strictly read-only). Nothing here
 * mutates a payload, registers a waterfall, or touches the harness kernel.
 */
import type { Context } from '@deepseek-ai/cordis'
import type { EventStore } from '../persistence/event-store.js'
import { lineageFromSession, normalizeEvent } from './normalize.js'

interface SubagentRunInfoLike {
  id?: unknown
  provider?: unknown
  parentSessionId?: unknown
}

const STATUS_ACTIVE = 'active' as const
const STATUS_SETTLED = 'settled' as const
const STATUS_DISPOSED = 'disposed' as const

/** Install all event subscriptions; listeners are auto-removed on plugin unload. */
export function installSessionEventSubscription(ctx: Context, store: EventStore): void {
  // Durable log feed: every committed session event, exactly as recorded.
  ctx.on('session/event', (session, event) => {
    try {
      const lineage = lineageFromSession(session)
      const normalized = normalizeEvent(session.id, lineage, event)
      store.insertEvent(normalized, JSON.stringify(event))
      // Mirror the official session/title (auto-generated or user rename) so
      // our session list can show readable titles without a live session.
      if (event.type === 'session/title') {
        const title = (event.data as { title?: unknown })?.title
        if (typeof title === 'string' && title !== '') {
          store.setTitle(session.id, { autoTitle: title })
        }
      }
    } catch (error) {
      ctx.logger.warn(
        `[trajectory-governance] failed to record session/event (session=${session?.id ?? '?'} seq=${event?.seq ?? '?'} type=${event?.type ?? '?'}): ${errorMessage(error)}`,
      )
    }
  })

  // Session lifecycle: record lineage (fork/subagent) and start-of-life facts.
  ctx.on('session/created', (session) => {
    try {
      const header = (session.header ?? {}) as Record<string, unknown>
      store.upsertSession({
        sessionId: session.id,
        parentSessionId: stringOr(header.parentSessionId),
        origin: header.origin === 'subagent' ? 'subagent' : undefined,
        seedLength: numberOr(header.seedLength),
        cwd: stringOr(header.cwd),
        agentPreset: stringOr(header.agentPreset),
        createdAt: numberOr(header.createdAt) ?? (session.seq === 0 ? 0 : Date.now()),
        lastEventSeq: 0,
        lastEventAt: undefined,
        status: STATUS_ACTIVE,
      })
    } catch (error) {
      ctx.logger.warn(`[trajectory-governance] failed to record session/created (session=${session?.id ?? '?'}): ${errorMessage(error)}`)
    }
  })

  ctx.on('session/disposed', (session) => {
    store.setStatus(session.id, STATUS_DISPOSED)
  })

  // Subagent runs: provider pairing + settlement (defensive payload access).
  ctx.on('subagent/start', (info: SubagentRunInfoLike) => {
    const childId = typeof info?.id === 'string' ? info.id : undefined
    if (childId === undefined) return
    store.setSubagentMeta(childId, {
      provider: typeof info.provider === 'string' ? info.provider : undefined,
    })
  })

  ctx.on('subagent/end', (info: SubagentRunInfoLike) => {
    const childId = typeof info?.id === 'string' ? info.id : undefined
    if (childId === undefined) return
    store.setStatus(childId, STATUS_SETTLED)
  })
}

function stringOr(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

function numberOr(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
