/**
 * Event normalization: RawSessionEvent → NormalizedEvent.
 *
 * Extraction is DEFENSIVE by design (preview API, `SESSION_FORMAT_VERSION = 0`):
 * a field is copied only when present with the expected type; everything else
 * falls back to scalar-only pass-through, so a vocabulary change degrades to a
 * less rich summary instead of a crash. Only scalars are extracted (the DSH
 * rule: never stringify/recursively copy internal objects; session payloads
 * are JSON-serializable by contract, so scalar summary + raw JSON persistence
 * are both safe).
 */
import { classifyEvent } from '../core/event-catalog.js'
import type { NormalizedEvent, RawSessionEvent, SessionLineage } from '../core/types.js'

/** Lineage fields the subscriber extracts from a live Session (header subset). */
export interface LineageInput {
  parentSessionId?: string
  origin?: 'subagent'
}

export function normalizeEvent(
  sessionId: string,
  lineage: LineageInput | undefined,
  event: RawSessionEvent,
): NormalizedEvent {
  const entry = classifyEvent(event.type)
  return {
    sessionId,
    branchId: sessionId,
    parentSessionId: lineage?.parentSessionId,
    origin: lineage?.origin,
    seq: event.seq,
    time: event.time,
    type: event.type,
    kind: entry.kind,
    category: entry.category,
    surface: entry.surface,
    ignorable: event.ignorable === true,
    data: extractSummary(event.type, event.data),
  }
}

function extractSummary(type: string, data: unknown): Record<string, unknown> {
  if (data === null || typeof data !== 'object' || Array.isArray(data)) return {}
  const d = data as Record<string, unknown>
  switch (type) {
    case 'turn/start':
    case 'step/start':
    case 'step/end':
      return pick(d, 'turn', 'step')
    case 'turn/end': {
      const reason = d.reason as { kind?: unknown } | undefined
      return {
        ...pick(d, 'turn'),
        reasonKind: scalarString(reason?.kind),
      }
    }
    case 'tool/call':
      return {
        name: scalarString(d.name),
        callId: scalarString(d.callId),
        argumentsLength: typeof d.arguments === 'string' ? d.arguments.length : undefined,
        ...pick(d, 'turn', 'step'),
      }
    case 'tool/result': {
      const error = d.error as { name?: unknown; code?: unknown } | undefined
      return {
        callId: scalarString(d.callId),
        isError: d.error !== undefined,
        errorName: scalarString(error?.name),
        errorCode: scalarString(error?.code),
        ...pick(d, 'turn', 'step'),
      }
    }
    case 'user/message': {
      const source = d.source as { kind?: unknown } | undefined
      return {
        sourceKind: scalarString(source?.kind),
        contentLength: Array.isArray(d.content) ? d.content.length : undefined,
      }
    }
    case 'assistant/message': {
      return {
        contentLength: safeLength(d.message),
        ...pick(d, 'turn', 'step'),
      }
    }
    case 'assistant/chunk':
      return pick(d, 'turn', 'step')
    case 'plan/mode':
      return { active: typeof d.active === 'boolean' ? d.active : undefined }
    case 'request/context':
      return pick(d, 'provider', 'model', 'contextWindow')
    case 'request/header':
      return { reason: scalarString(d.reason) }
    case 'subagent/descriptor':
      return {
        mode: scalarString(d.mode),
        label: scalarString(d.label),
        provider: scalarString(d.provider),
      }
    case 'llm/retry':
    case 'llm/retry-started':
      return pickScalars(d)
    default:
      return pickScalars(d)
  }
}

function pick(d: Record<string, unknown>, ...keys: string[]): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const key of keys) {
    if (key in d) out[key] = d[key]
  }
  return out
}

/** Copy only scalar values (string/number/boolean) — JSON-safe, bounded size. */
function pickScalars(d: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [key, value] of Object.entries(d)) {
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      out[key] = value
    }
  }
  return out
}

function scalarString(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

function safeLength(value: unknown): number | undefined {
  if (value === null || typeof value !== 'object') return undefined
  const arr = (value as { content?: unknown }).content
  return Array.isArray(arr) ? arr.length : undefined
}

/** Extract lineage scalars from a live Session object (defensive). */
export function lineageFromSession(session: { header?: Record<string, unknown> | SessionLineage }): LineageInput {
  const header = session.header
  if (header === undefined || header === null) return {}
  return {
    parentSessionId: scalarString(header.parentSessionId),
    origin: header.origin === 'subagent' ? 'subagent' : undefined,
  }
}
