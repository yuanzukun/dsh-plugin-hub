/**
 * Waste attribution report — what the anomalies actually cost.
 *
 * This is NOT a usage-stats dashboard (that's a saturated niche). It answers
 * the attribution question nobody else does: "which sessions wasted how many
 * tokens/money, on which anomaly types" — derived from our anomaly ranges and
 * the official token accounting.
 */
import type { EventStore } from '../persistence/event-store.js'
import type { CostEstimator } from '../diagnose/cost.js'

export interface WasteByType {
  count: number
  tokens: number
  costCny: number
  durationMs: number
}

export interface WasteRow {
  sessionId: string
  anomalyCount: number
  byType: Record<string, WasteByType>
  totalTokens: number
  totalCostCny: number
  totalDurationMs: number
}

export interface WasteTotals {
  sessions: number
  anomalies: number
  tokens: number
  costCny: number
  durationMs: number
}

export interface WasteReport {
  generatedAt: number
  tokenPricePerM: number
  estimated: boolean
  sessions: WasteRow[]
  totals: WasteTotals
}

export interface WasteItem {
  anomalyId: string
  type: string
  startNodeId: string
  endNodeId: string
  confidence: number
  severity?: string
  description: string
  tokens: number
  costCny: number
  durationMs: number
}

export interface SessionWasteReport {
  sessionId: string
  tokenPricePerM: number
  items: WasteItem[]
  totals: WasteTotals
  markdown: string
}

function emptyType(): WasteByType {
  return { count: 0, tokens: 0, costCny: 0, durationMs: 0 }
}

function seqOf(nodeId: string): number {
  const idx = nodeId.lastIndexOf(':')
  const seq = Number(nodeId.slice(idx + 1))
  return Number.isSafeInteger(seq) ? seq : -1
}

function round2(value: number): number {
  return Math.round(value * 100) / 100
}

export function buildWasteReport(store: EventStore, cost: CostEstimator): WasteReport {
  const sessions = store.listSessions(1_000_000)
  const rows: WasteRow[] = []
  let estimated = false
  for (const session of sessions) {
    const anomalies = store.listAnomalies({ sessionId: session.sessionId, limit: 1000 })
    if (anomalies.length === 0) continue
    const byType: Record<string, WasteByType> = {}
    let totalTokens = 0
    let totalCostCny = 0
    let totalDurationMs = 0
    for (const a of anomalies) {
      const estimate = cost.estimate(a.sessionId, seqOf(a.startNodeId), seqOf(a.endNodeId))
      if (estimate.estimated) estimated = true
      const bucket = byType[a.type] ?? emptyType()
      bucket.count += 1
      bucket.tokens += estimate.tokens
      bucket.costCny = round2(bucket.costCny + estimate.costCny)
      bucket.durationMs += estimate.durationMs
      byType[a.type] = bucket
      totalTokens += estimate.tokens
      totalCostCny = round2(totalCostCny + estimate.costCny)
      totalDurationMs += estimate.durationMs
    }
    rows.push({
      sessionId: session.sessionId,
      anomalyCount: anomalies.length,
      byType,
      totalTokens,
      totalCostCny,
      totalDurationMs,
    })
  }
  rows.sort((a, b) => b.totalTokens - a.totalTokens)
  const totals: WasteTotals = rows.reduce(
    (acc, row) => ({
      sessions: acc.sessions + 1,
      anomalies: acc.anomalies + row.anomalyCount,
      tokens: acc.tokens + row.totalTokens,
      costCny: round2(acc.costCny + row.totalCostCny),
      durationMs: acc.durationMs + row.totalDurationMs,
    }),
    { sessions: 0, anomalies: 0, tokens: 0, costCny: 0, durationMs: 0 },
  )
  return { generatedAt: Date.now(), tokenPricePerM: cost.pricePerM(), estimated, sessions: rows, totals }
}

export function buildSessionWasteReport(store: EventStore, cost: CostEstimator, sessionId: string): SessionWasteReport | undefined {
  const anomalies = store.listAnomalies({ sessionId, limit: 1000 })
  if (anomalies.length === 0) return undefined
  const items: WasteItem[] = anomalies.map(a => {
    const estimate = cost.estimate(a.sessionId, seqOf(a.startNodeId), seqOf(a.endNodeId))
    return {
      anomalyId: a.anomalyId,
      type: a.type,
      startNodeId: a.startNodeId,
      endNodeId: a.endNodeId,
      confidence: a.confidence,
      severity: a.severity,
      description: a.description,
      tokens: estimate.tokens,
      costCny: estimate.costCny,
      durationMs: estimate.durationMs,
    }
  })
  const totals: WasteTotals = items.reduce(
    (acc, item) => ({
      sessions: 1,
      anomalies: acc.anomalies + 1,
      tokens: acc.tokens + item.tokens,
      costCny: round2(acc.costCny + item.costCny),
      durationMs: acc.durationMs + item.durationMs,
    }),
    { sessions: 1, anomalies: 0, tokens: 0, costCny: 0, durationMs: 0 },
  )
  return { sessionId, tokenPricePerM: cost.pricePerM(), items, totals, markdown: '' }
}

export function wasteReportToMarkdown(report: WasteReport): string {
  const lines: string[] = []
  lines.push('# Agent 异常浪费报告')
  lines.push('')
  lines.push(`- 生成时间：${new Date(report.generatedAt).toISOString()}`)
  lines.push(`- 折算单价：¥${report.tokenPricePerM}/1M tokens${report.estimated ? '（部分为估算）' : ''}`)
  lines.push(`- 异常会话：${report.totals.sessions} 个 ｜ 异常：${report.totals.anomalies} 条 ｜ 浪费 token：${report.totals.tokens.toLocaleString()} ｜ 约 ¥${report.totals.costCny} ｜ ${Math.round(report.totals.durationMs / 60000)} 分钟`)
  lines.push('')
  if (report.sessions.length === 0) {
    lines.push('暂无异常浪费。')
    return lines.join('\n')
  }
  lines.push('| 会话 | 异常数 | 浪费 token | 约金额 | 时长(分) | 类型分布 |')
  lines.push('| --- | --- | --- | --- | --- | --- |')
  for (const row of report.sessions) {
    const types = Object.entries(row.byType)
      .map(([type, w]) => `${type}×${w.count}(${(w.tokens / 1000).toFixed(0)}k tok)`)
      .join('、')
    lines.push(`| ${row.sessionId} | ${row.anomalyCount} | ${row.totalTokens.toLocaleString()} | ¥${row.totalCostCny} | ${Math.round(row.totalDurationMs / 60000)} | ${types} |`)
  }
  return lines.join('\n')
}

export function sessionWasteToMarkdown(report: SessionWasteReport): string {
  const lines: string[] = []
  lines.push(`# 会话 ${report.sessionId} 异常浪费明细`)
  lines.push('')
  lines.push(`- 折算单价：¥${report.tokenPricePerM}/1M tokens`)
  lines.push(`- 异常 ${report.totals.anomalies} 条 ｜ 浪费 token ${report.totals.tokens.toLocaleString()} ｜ 约 ¥${report.totals.costCny} ｜ ${Math.round(report.totals.durationMs / 60000)} 分钟`)
  lines.push('')
  for (const item of report.items) {
    lines.push(`## ${item.type} · 置信度 ${Math.round(item.confidence * 100)}%${item.severity !== undefined ? ` · ${item.severity}` : ''}`)
    lines.push('')
    lines.push(`- 区间：${item.startNodeId} → ${item.endNodeId}`)
    lines.push(`- 消耗：${item.tokens.toLocaleString()} token ｜ 约 ¥${item.costCny} ｜ ${Math.round(item.durationMs / 60000)} 分钟`)
    lines.push(`- 描述：${item.description}`)
    lines.push('')
  }
  return lines.join('\n')
}
