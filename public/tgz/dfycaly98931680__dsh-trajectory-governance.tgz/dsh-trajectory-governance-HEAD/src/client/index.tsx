/**
 * Trajectory Governance — independent client tab.
 *
 * Registered in the `conversation.view` slot with its OWN id
 * ('trajectory-governance', order 20) — the official Trajectory tab
 * (id 'trajectory', order 10) is never overwritten. Data comes from the host
 * JSON API (/trajectory-governance/api/*, same-origin).
 *
 * Deliberately lightweight: no external UI kit, inline styles only.
 */
import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react'

// ---------------------------------------------------------------------------
// structural client context types (the web profile injects these)
// ---------------------------------------------------------------------------

interface SlotsLike {
  inject(name: string, install: () => unknown): void
  register(
    entry: {
      name: string
      id: string
      order: number
      label: () => string
      inject: (sessionId: string) => { sessionId: string }
    },
    component: (props: { sessionId: string }) => ReactNode,
  ): () => void
}

interface ClientContextLike {
  slots: SlotsLike
  effect(setup: () => (() => void), label?: string): unknown
}

// ---------------------------------------------------------------------------
// data shapes (defensive — preview API)
// ---------------------------------------------------------------------------

interface SessionSummary {
  sessionId: string
  parentSessionId?: string
  origin?: string
  status: string
  createdAt: number
  lastEventSeq: number
  eventCount: number
  anomalyCount: number
  /** Estimated tokens wasted inside anomaly ranges. */
  wastedTokens?: number
  /** Readable title (user rename ?? official auto title). */
  title?: string | null
}

interface AlertLike {
  anomalyId: string
  sessionId: string
  type: string
  startNodeId: string
  endNodeId: string
  confidence: number
  severity?: string
  description: string
  suggestion?: string
  createdAt: number
  updatedAt: number
  cost: { tokens: number; costCny: number; durationMs: number; estimated: boolean }
}

interface TreeNode {
  nodeId: string
  sessionId: string
  branchId: string
  parentNodeId: string | null
  eventType: string
  kind: string
  category: string
  timestamp: number
  seq: number
  data: Record<string, unknown>
  isSnapshot: boolean
  anomalyInfo: unknown
  branch: { branchId: string; branchType: string; label?: string }
  children: TreeNode[]
}

interface AnomalyRow {
  anomalyId: string
  type: string
  startNodeId: string
  endNodeId: string
  confidence: number
  severity?: string
  description: string
  suggestion?: string
}

interface SnapshotMeta {
  snapshotId: string
  sessionId: string
  branchId: string
  nodeId: string
  label?: string
  createdAt: number
  accessCount: number
}

const API = '/trajectory-governance/api'
const STYLE_ID = 'dsh-trajectory-governance'
const ANOMALY_TYPES = ['all', 'loop_deadlock', 'invalid_retry', 'goal_drift'] as const

const styles = `
.tgd-root{box-sizing:border-box;display:flex;flex-direction:column;gap:10px;height:100%;min-height:0;padding:14px;font:13px/1.5 var(--dsw-font-family,system-ui);color:var(--dsw-alias-label-primary,#333)}
.tgd-bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.tgd-bar select,.tgd-bar button{height:28px;border-radius:6px;border:1px solid var(--dsw-alias-border-l2,#ccc);background:var(--dsw-alias-bg-layer-1,#fff);font:inherit;color:inherit}
.tgd-body{display:flex;gap:10px;min-height:0;flex:1}
.tgd-tree{flex:1.2;min-width:0;overflow:auto;border:1px solid var(--dsw-alias-border-l2,#ccc);border-radius:8px;padding:8px}
.tgd-side{flex:1;min-width:0;display:flex;flex-direction:column;gap:10px;overflow:auto}
.tgd-card{border:1px solid var(--dsw-alias-border-l2,#ccc);border-radius:8px;padding:10px}
.tgd-card h4{margin:0 0 6px;font-size:12px;color:var(--dsw-alias-label-tertiary,#888)}
.tgd-node{display:flex;gap:6px;align-items:baseline;padding:2px 4px;border-radius:4px;cursor:pointer;white-space:nowrap}
.tgd-node:hover{background:var(--dsw-alias-interactive-bg-hover,#eee)}
.tgd-node.sel{background:var(--dsw-alias-state-business-tertiary,#dbeafe)}
.tgd-node.err{background:color-mix(in srgb,var(--dsw-alias-state-error-primary,#dc2626) 12%,transparent)}
.tgd-dot{display:inline-block;width:8px;height:8px;border-radius:50%;flex:none;align-self:center}
.tgd-seq{color:var(--dsw-alias-label-tertiary,#888);font-size:11px}
.tgd-badge{font-size:10px;border:1px solid currentColor;border-radius:4px;padding:0 3px}
.tgd-mono{font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:11px;word-break:break-all}
.tgd-pre{max-height:220px;overflow:auto;background:var(--dsw-alias-bg-layer-2,#f6f6f6);border-radius:6px;padding:8px;margin:0}
.tgd-empty{color:var(--dsw-alias-label-tertiary,#888);padding:8px}
.tgd-anomaly{border:1px solid color-mix(in srgb,var(--dsw-alias-state-error-primary,#dc2626) 40%,transparent);background:color-mix(in srgb,var(--dsw-alias-state-error-primary,#dc2626) 6%,transparent);border-radius:8px;padding:10px}
.tgd-alertbar{display:flex;flex-direction:column;gap:6px}
.tgd-alert{display:flex;gap:10px;align-items:flex-start;justify-content:space-between;border:1px solid color-mix(in srgb,var(--dsw-alias-state-error-primary,#dc2626) 45%,transparent);background:color-mix(in srgb,var(--dsw-alias-state-error-primary,#dc2626) 8%,transparent);border-radius:8px;padding:8px 10px}
.tgd-alert-main{min-width:0;display:flex;flex-direction:column;gap:2px}
.tgd-alert-actions{display:flex;gap:6px;flex:none}
`

const KIND_DOT: Record<string, string> = {
  'user-message': '#3b82f6',
  'assistant-message': '#10b981',
  'assistant-chunk': '#a3e635',
  'tool-call': '#f59e0b',
  'tool-result': '#f59e0b',
  'turn-start': '#8b5cf6',
  'turn-end': '#8b5cf6',
  'step-start': '#64748b',
  'step-end': '#64748b',
  'retry': '#ef4444',
  'retry-start': '#f97316',
  'end-seed': '#94a3b8',
  'plan-mode': '#06b6d4',
  'goal-change': '#06b6d4',
  'subagent-descriptor': '#ec4899',
}

// ---------------------------------------------------------------------------
// client plugin entry
// ---------------------------------------------------------------------------

export const inject = ['slots']

export function apply(ctx: ClientContextLike): void {
  ctx.effect(() => {
    if (document.querySelector(`style[data-tgd="${STYLE_ID}"]`) !== null) return () => {}
    const tag = document.createElement('style')
    tag.dataset.tgd = STYLE_ID
    tag.textContent = styles
    document.head.appendChild(tag)
    return () => tag.remove()
  }, 'trajectory-governance: styles')

  ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    id: 'trajectory-governance',
    order: 20,
    label: () => '轨迹治理',
    inject: (sessionId: string) => ({ sessionId }),
  }, TrajectoryGovernancePanel))
}

// ---------------------------------------------------------------------------
// panel
// ---------------------------------------------------------------------------

function TrajectoryGovernancePanel({ sessionId: initialSessionId }: { sessionId: string }): ReactNode {
  const [sessions, setSessions] = useState<SessionSummary[]>([])
  const [sessionId, setSessionId] = useState(initialSessionId)
  const [tree, setTree] = useState<TreeNode | null>(null)
  const [anomalies, setAnomalies] = useState<AnomalyRow[]>([])
  const [snapshots, setSnapshots] = useState<SnapshotMeta[]>([])
  const [alerts, setAlerts] = useState<AlertLike[]>([])
  const [filter, setFilter] = useState<string>('all')
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null)
  const [nodeDetail, setNodeDetail] = useState<unknown>(null)
  const [notifyPerm, setNotifyPerm] = useState<string>(typeof Notification === 'undefined' ? 'unsupported' : Notification.permission)
  const [interrupting, setInterrupting] = useState<string | null>(null)
  const [forking, setForking] = useState<string | null>(null)
  const [reportOpen, setReportOpen] = useState(false)
  const [report, setReport] = useState<{ markdown: string } | null>(null)
  const [error, setError] = useState<string | null>(null)

  const loadSessions = useCallback(async () => {
    setError(null)
    try {
      const json = await getJson(`${API}/sessions`)
      const list = (json?.sessions as SessionSummary[] | undefined) ?? []
      setSessions(list)
      if (list.length > 0 && (sessionId === '' || !list.some(s => s.sessionId === sessionId))) {
        setSessionId(list[0]!.sessionId)
      }
    } catch (caught) {
      setError(`会话列表加载失败：${messageOf(caught)}`)
    }
  }, [sessionId])

  const loadSessionData = useCallback(async (id: string) => {
    if (id === '') return
    setError(null)
    try {
      const [treeJson, anomJson, snapJson] = await Promise.all([
        getJson(`${API}/tree?sessionId=${encodeURIComponent(id)}`),
        getJson(`${API}/anomalies?sessionId=${encodeURIComponent(id)}`),
        getJson(`${API}/snapshots?sessionId=${encodeURIComponent(id)}`),
      ])
      setTree((treeJson?.tree as TreeNode | undefined) ?? null)
      setAnomalies((anomJson?.anomalies as AnomalyRow[] | undefined) ?? [])
      setSnapshots((snapJson?.snapshots as SnapshotMeta[] | undefined) ?? [])
      setSelectedNodeId(null)
    } catch (caught) {
      setError(messageOf(caught))
    }
  }, [])

  useEffect(() => { void loadSessions() }, [loadSessions])
  useEffect(() => { void loadSessionData(sessionId) }, [sessionId, loadSessionData])

  // ---- alert polling: desktop notification + alert bar (local dedupe) ----
  const notifySeenKey = 'tgd-notify-seen'
  useEffect(() => {
    const seen = new Set<string>(JSON.parse(sessionStorage.getItem(notifySeenKey) ?? '[]'))
    const tick = async (): Promise<void> => {
      try {
        const json = await getJson(`${API}/alerts?since=0`)
        const list = (json?.alerts as AlertLike[] | undefined) ?? []
        const fresh: AlertLike[] = []
        for (const alert of list) {
          if (!seen.has(alert.anomalyId)) {
            seen.add(alert.anomalyId)
            fresh.push(alert)
            // desktop notification (browser Notification API — same approach
            // as the ecosystem's dsh-notification)
            if (typeof Notification !== 'undefined' && Notification.permission === 'granted') {
              try {
                new Notification(`⚠ ${alert.type} · ${alert.sessionId}`, {
                  body: `${alert.description}\n已消耗约 ${fmtCost(alert.cost)}`,
                  tag: alert.anomalyId,
                })
              } catch { /* notification already shown / unsupported */ }
            }
          }
        }
        if (fresh.length > 0) {
          sessionStorage.setItem(notifySeenKey, JSON.stringify([...seen]))
          setAlerts(prev => {
            const merged = new Map<string, AlertLike>()
            for (const a of [...prev, ...fresh]) merged.set(a.anomalyId, a)
            return [...merged.values()].sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 20)
          })
        }
      } catch { /* polling is best-effort */ }
    }
    void tick()
    const id = setInterval(() => { void tick() }, 10_000)
    return () => clearInterval(id)
  }, [])

  const requestNotify = useCallback(async () => {
    if (typeof Notification === 'undefined') return
    const permission = await Notification.requestPermission()
    setNotifyPerm(permission)
  }, [])

  const interruptSession = useCallback(async (target: string) => {
    setInterrupting(target)
    try {
      const json = await postJson(`${API}/actions/interrupt`, { sessionId: target })
      if (json?.ok !== true) {
        setError(`中断失败：${String((json as { error?: unknown })?.error ?? 'unknown')}`)
      }
    } catch (caught) {
      setError(`中断请求失败：${messageOf(caught)}`)
    } finally {
      setInterrupting(null)
    }
  }, [])

  /** 断点出口：从稳定轮次边界 fork 新会话（官方 sessions.fork，非控制层回滚）。 */
  const forkSession = useCallback(async (target: string, nodeId?: string) => {
    setForking(target)
    try {
      const json = await postJson(`${API}/actions/fork`, { sessionId: target, nodeId })
      if (json?.ok !== true) {
        setError(`分支失败：${String((json as { error?: unknown })?.error ?? 'unknown')}`)
      } else {
        setError(null)
        await loadSessions() // 分支生成新会话，刷新列表
      }
    } catch (caught) {
      setError(`分支请求失败：${messageOf(caught)}`)
    } finally {
      setForking(null)
    }
  }, [loadSessions])

  const openReport = useCallback(async (target: string | undefined) => {
    setReportOpen(true)
    setReport(null)
    try {
      const url = target === undefined ? `${API}/report/waste` : `${API}/report/waste?sessionId=${encodeURIComponent(target)}`
      const json = await getJson(url)
      setReport({ markdown: String((json as { markdown?: unknown })?.markdown ?? '（无报告）') })
    } catch (caught) {
      setError(`报告加载失败：${messageOf(caught)}`)
    }
  }, [])

  /** 重命名会话：官方 sessionTitle.rename（钉住标题）+ 本地镜像。 */
  const renameSession = useCallback(async () => {
    const current = sessions.find(s => s.sessionId === sessionId)
    const title = window.prompt('会话名称：', current?.title ?? '')
    if (title === null) return
    const trimmed = title.trim()
    if (trimmed === '') { setError('名称不能为空'); return }
    try {
      const json = await postJson(`${API}/actions/rename`, { sessionId, title: trimmed })
      if (json?.ok !== true) {
        setError(`重命名失败：${String((json as { error?: unknown })?.error ?? 'unknown')}`)
        return
      }
      await loadSessions()
    } catch (caught) {
      setError(`重命名请求失败：${messageOf(caught)}`)
    }
  }, [sessionId, sessions, loadSessions])

  const visibleAnomalies = useMemo(() => {
    if (filter === 'all') return anomalies
    return anomalies.filter(a => a.type === filter)
  }, [anomalies, filter])

  const snapshotNodeIds = useMemo(() => new Set(snapshots.map(s => s.nodeId)), [snapshots])
  const coveredSeqByAnomaly = useMemo(() => {
    const map = new Map<string, AnomalyRow[]>() // nodeId -> covering anomalies
    for (const anomaly of visibleAnomalies) {
      const start = seqOf(anomaly.startNodeId)
      const end = seqOf(anomaly.endNodeId)
      for (let seq = start; seq <= end; seq += 1) {
        const nodeId = `${sessionId}:${seq}`
        const list = map.get(nodeId) ?? []
        list.push(anomaly)
        map.set(nodeId, list)
      }
    }
    return map
  }, [visibleAnomalies, sessionId])

  const selectNode = useCallback(async (nodeId: string) => {
    setSelectedNodeId(nodeId)
    try {
      const json = await getJson(`${API}/node?nodeId=${encodeURIComponent(nodeId)}`)
      setNodeDetail(json?.node ?? null)
    } catch (caught) {
      setNodeDetail({ error: messageOf(caught) })
    }
  }, [])

  const createSnapshot = useCallback(async () => {
    if (selectedNodeId === null) return
    await postJson(`${API}/snapshots`, { sessionId, nodeId: selectedNodeId, label: 'UI checkpoint' })
    await loadSessionData(sessionId)
  }, [sessionId, selectedNodeId, loadSessionData])

  const deleteSnapshot = useCallback(async (snapshotId: string) => {
    await fetchJson(`${API}/snapshots?snapshotId=${encodeURIComponent(snapshotId)}`, { method: 'DELETE' })
    await loadSessionData(sessionId)
  }, [sessionId, loadSessionData])

  const selectedAnomalies = selectedNodeId === null ? [] : (coveredSeqByAnomaly.get(selectedNodeId) ?? [])

  // 事故模式：异常会话置顶（按浪费 token 降序）
  const orderedSessions = useMemo(() => {
    const abnormal = sessions.filter(s => s.anomalyCount > 0)
      .sort((a, b) => (b.wastedTokens ?? 0) - (a.wastedTokens ?? 0))
    const normal = sessions.filter(s => s.anomalyCount === 0)
    return [...abnormal, ...normal]
  }, [sessions])

  const dismissAlert = useCallback((anomalyId: string) => {
    setAlerts(prev => prev.filter(a => a.anomalyId !== anomalyId))
  }, [])

  return (
    <div className="tgd-root">
      <div className="tgd-bar">
        <select value={sessionId} onChange={e => setSessionId(e.target.value)}>
          {orderedSessions.map(s => (
            <option key={s.sessionId} value={s.sessionId}>
              {s.title ?? s.sessionId}
              {s.title !== undefined && s.title !== null ? ` (${s.sessionId.slice(0, 8)}…)` : ''}
              {s.anomalyCount > 0 ? ` · ⚠${s.anomalyCount}` : ''}
              {(s.wastedTokens ?? 0) > 0 ? ` · ~${(s.wastedTokens! / 1000).toFixed(0)}k tok` : ''}
            </option>
          ))}
        </select>
        <select value={filter} onChange={e => setFilter(e.target.value)}>
          {ANOMALY_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <button type="button" onClick={() => { void loadSessions(); void loadSessionData(sessionId) }}>刷新</button>
        <button type="button" onClick={() => { void renameSession() }}>重命名会话</button>
        <button type="button" disabled={selectedNodeId === null} onClick={() => { void createSnapshot() }}>
          在选中节点打快照
        </button>
        <button type="button" disabled={selectedNodeId === null} onClick={() => { void forkSession(sessionId, selectedNodeId ?? undefined) }}>
          {forking === sessionId ? '正在分支…' : '在选中节点分支新会话'}
        </button>
        <button type="button" onClick={() => { void openReport(undefined) }}>浪费报告</button>
        <button type="button" onClick={() => { void openReport(sessionId) }}>本会话报告</button>
        {typeof Notification !== 'undefined' && notifyPerm !== 'granted' && (
          <button type="button" onClick={() => { void requestNotify() }}>
            {notifyPerm === 'denied' ? '通知被拒（浏览器设置）' : '开启异常桌面通知'}
          </button>
        )}
        <span className="tgd-seq">trajectory-governance v0.4</span>
      </div>

      {error !== null && <div className="tgd-empty">⚠ {error}</div>}

      {reportOpen && (
        <div className="tgd-card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h4>异常浪费报告</h4>
            <button type="button" onClick={() => setReportOpen(false)}>关闭</button>
          </div>
          <pre className="tgd-pre" style={{ maxHeight: 260 }}>{report?.markdown ?? '加载中…'}</pre>
        </div>
      )}

      {alerts.length > 0 && (
        <div className="tgd-alertbar">
          {alerts.map(a => (
            <div className="tgd-alert" key={a.anomalyId}>
              <div className="tgd-alert-main">
                <strong>⚠ {a.type}{a.severity !== undefined ? ` · ${a.severity}` : ''} · 置信度 {Math.round(a.confidence * 100)}%</strong>
                <span>{a.sessionId}</span>
                <span className="tgd-seq">已消耗约 {fmtCost(a.cost)}</span>
                <p style={{ margin: '2px 0' }}>{a.description}</p>
              </div>
              <div className="tgd-alert-actions">
                <button type="button" onClick={() => { setSessionId(a.sessionId); void loadSessionData(a.sessionId) }}>查看</button>
                <button type="button" disabled={forking !== null} onClick={() => { void forkSession(a.sessionId, a.startNodeId) }}>
                  {forking === a.sessionId ? '正在分支…' : '在异常起点分支'}
                </button>
                <button type="button" disabled={interrupting !== null} onClick={() => { void interruptSession(a.sessionId) }}>
                  {interrupting === a.sessionId ? '正在中断…' : '中断该会话'}
                </button>
                <button type="button" onClick={() => dismissAlert(a.anomalyId)}>忽略</button>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="tgd-body">
        <div className="tgd-tree">
          {tree === null
            ? <div className="tgd-empty">（无轨迹数据）</div>
            : <TreeNodeRow
                node={tree}
                depth={0}
                selectedNodeId={selectedNodeId}
                snapshotNodeIds={snapshotNodeIds}
                covered={coveredSeqByAnomaly}
                onSelect={nodeId => { void selectNode(nodeId) }}
              />}
        </div>

        <div className="tgd-side">
          {selectedAnomalies.length > 0 && selectedAnomalies.map(a => (
            <div className="tgd-anomaly" key={a.anomalyId}>
              <strong>⚠ {a.type} · 置信度 {Math.round(a.confidence * 100)}%{a.severity !== undefined ? ` · ${a.severity}` : ''}</strong>
              <p style={{ margin: '4px 0' }}>{a.description}</p>
              {a.suggestion !== undefined && <p style={{ margin: 0, opacity: 0.85 }}>建议：{a.suggestion}</p>}
            </div>
          ))}

          <div className="tgd-card">
            <h4>节点详情</h4>
            {nodeDetail === null
              ? <div className="tgd-empty">点击左侧节点查看原始事件与诊断</div>
              : <NodeDetail detail={nodeDetail} />}
          </div>

          <div className="tgd-card">
            <h4>快照（{snapshots.length}）</h4>
            {snapshots.length === 0 && <div className="tgd-empty">暂无快照</div>}
            {snapshots.map(s => (
              <div className="tgd-node" key={s.snapshotId} onClick={() => { void selectNode(s.nodeId) }}>
                <span className="tgd-seq">★</span>
                <span>{s.label ?? s.snapshotId}</span>
                <span className="tgd-seq">{s.nodeId}</span>
                <button type="button" onClick={e => { e.stopPropagation(); void deleteSnapshot(s.snapshotId) }}>删除</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

function TreeNodeRow({ node, depth, selectedNodeId, snapshotNodeIds, covered, onSelect }: {
  node: TreeNode
  depth: number
  selectedNodeId: string | null
  snapshotNodeIds: Set<string>
  covered: Map<string, unknown[]>
  onSelect: (nodeId: string) => void
}): ReactNode {
  const isErr = (covered.get(node.nodeId)?.length ?? 0) > 0
  const isSnap = snapshotNodeIds.has(node.nodeId)
  const color = KIND_DOT[node.kind] ?? '#94a3b8'
  return (
    <>
      <div
        className={`tgd-node${node.nodeId === selectedNodeId ? ' sel' : ''}${isErr ? ' err' : ''}`}
        style={{ paddingLeft: `${8 + depth * 14}px` }}
        onClick={() => onSelect(node.nodeId)}
      >
        <span className="tgd-dot" style={{ background: color }} />
        <span>{node.eventType}</span>
        <span className="tgd-seq">#{node.seq}</span>
        {node.branch.branchType !== 'main' && <span className="tgd-badge" style={{ color: '#ec4899' }}>{node.branch.branchType}</span>}
        {isSnap && <span className="tgd-badge" style={{ color: '#f59e0b' }}>★</span>}
        {isErr && <span className="tgd-badge" style={{ color: '#dc2626' }}>⚠</span>}
      </div>
      {node.children.map(child => (
        <TreeNodeRow
          key={child.nodeId}
          node={child}
          depth={depth + (child.branch.branchId === node.branch.branchId ? 1 : 1)}
          selectedNodeId={selectedNodeId}
          snapshotNodeIds={snapshotNodeIds}
          covered={covered}
          onSelect={onSelect}
        />
      ))}
    </>
  )
}

function NodeDetail({ detail }: { detail: unknown }): ReactNode {
  const d = asRecord(detail)
  return (
    <div>
      <div className="tgd-mono">{String(d.nodeId ?? '')} · {String(d.eventType ?? '')}</div>
      <div className="tgd-seq">seq={String(d.seq ?? '')} time={String(d.timestamp ?? '')} kind={String(d.kind ?? '')}</div>
      {d.anomalyInfo !== null && d.anomalyInfo !== undefined && (
        <div className="tgd-anomaly" style={{ marginTop: 6 }}>
          <strong>⚠ {String(asRecord(d.anomalyInfo).type ?? '')} · {(asRecord(d.anomalyInfo).confidence ?? 0) as number}</strong>
        </div>
      )}
      <pre className="tgd-pre">{JSON.stringify(d.data ?? {}, null, 2)}</pre>
      <h4 style={{ margin: '8px 0 4px' }}>原始事件</h4>
      <pre className="tgd-pre">{JSON.stringify(d.raw ?? {}, null, 2)}</pre>
    </div>
  )
}

// ---------------------------------------------------------------------------
// fetch helpers
// ---------------------------------------------------------------------------

async function getJson(path: string): Promise<Record<string, unknown> | undefined> {
  const response = await fetchJson(path, { method: 'GET' })
  return response.ok ? (await response.json()) as Record<string, unknown> : undefined
}

async function postJson(path: string, body: unknown): Promise<Record<string, unknown> | undefined> {
  const response = await fetchJson(path, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  })
  return response.ok ? (await response.json()) as Record<string, unknown> : undefined
}

async function fetchJson(path: string, init: RequestInit): Promise<Response> {
  const response = await fetch(path, { ...init, cache: 'no-store' })
  if (!response.ok) {
    throw new Error(`API ${init.method ?? 'GET'} ${path} → ${String(response.status)}`)
  }
  return response
}

function asRecord(value: unknown): Record<string, unknown> {
  return value !== null && typeof value === 'object' && !Array.isArray(value)
    ? value as Record<string, unknown>
    : {}
}

function seqOf(nodeId: string): number {
  const idx = nodeId.lastIndexOf(':')
  const seq = Number(nodeId.slice(idx + 1))
  return Number.isSafeInteger(seq) ? seq : -1
}

/** 金额显示：够 1 分钱显示 ¥，否则显示千 token 数（避免 "¥0.00" 无意义）。 */
function fmtCost(cost: { costCny: number; tokens: number; durationMs: number }): string {
  const money = cost.costCny >= 0.01 ? `¥${cost.costCny}` : `${Math.round(cost.tokens / 1000)}k tok`
  const durMin = Math.round(cost.durationMs / 60000)
  return durMin > 0 ? `${money} / ${durMin} 分钟` : money
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
