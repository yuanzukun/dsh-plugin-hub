/**
 * Cordis module augmentation: declare the dsh session/subagent events this
 * plugin subscribes to. Session-scoped dispatch is handled by the harness;
 * the plugin is a plain listener (emit mode, post-commit, read-only).
 */
import type { RawSessionEvent } from './core/types.js'

/** Minimal read face of a live Session the plugin touches. */
export interface SessionLike {
  id: string
  seq: number
  events: readonly RawSessionEvent[]
  header?: {
    parentSessionId?: string
    origin?: 'subagent'
    seedLength?: number
    cwd?: string
    agentPreset?: string
    createdAt?: number
  }
}

/** Loose read face of subagent run notifications (payload may drift in preview). */
export interface SubagentRunInfoLike {
  id?: unknown
  provider?: unknown
  parentSessionId?: unknown
}

/** Minimal http server route contract (webServer service). */
export interface HttpServerRouteLike {
  kind: 'exact'
  path: string
  handler: (
    request: {
      method?: string
      url?: string
      on(event: 'data' | 'end' | 'error', listener: (...args: never[]) => void): unknown
    },
    response: {
      writeHead(status: number, headers?: Record<string, string>): unknown
      end(body?: string): void
    },
  ) => void | Promise<void>
}

declare module '@deepseek-ai/cordis' {
  interface Events {
    /** Post-commit append feed: one durable session event, fire-and-forget. */
    'session/event'(session: SessionLike, event: RawSessionEvent): void
    /** Creation announcement during session publication (fork/subagent lineage visible here). */
    'session/created'(session: SessionLike): void
    /** Emitted once when an announced session leaves the store. */
    'session/disposed'(session: SessionLike): void
    /** A provider established a published subagent child. */
    'subagent/start'(info: SubagentRunInfoLike): void
    /** A published subagent child settled. */
    'subagent/end'(info: SubagentRunInfoLike): void
    /** Our anomaly alert — ecosystem notification plugins can subscribe. */
    'trajectory/anomaly'(alert: import('./diagnose/alerts.js').AnomalyAlert): void
  }
}

export {}
