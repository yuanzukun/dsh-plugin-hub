/**
 * Snapshot service — index-only snapshots over the trajectory store.
 *
 * API: create / list / context / touch / remove / prune.
 * `create` is idempotent per node: the snapshot id derives from
 * (sessionId, seq, hash-prefix), so re-creating at the same node updates
 * nothing and returns the existing row (meta only).
 */
import type { EventStore, SnapshotRow } from '../persistence/event-store.js'
import { hashContextUpTo } from './context-hash.js'
import type { PruneOptions, PruneResult, SnapshotContext, SnapshotMeta } from './types.js'

export interface CreateSnapshotOptions {
  /** Anchored node; defaults to the branch's current last event. */
  nodeId?: string
  /** Branch id (defaults to the node's session id). */
  branchId?: string
  label?: string
  note?: string
  /** Test hooks: backdate timestamps. */
  createdAt?: number
  lastAccessedAt?: number
}

const DEFAULTS = {
  maxSnapshots: 200,
  ttlMs: 30 * 24 * 60 * 60 * 1000, // 30 days
  keepNewest: 5,
}

export class SnapshotService {
  constructor(private readonly store: EventStore) {}

  /** Create an observation snapshot at a trajectory node. */
  create(sessionId: string, opts: CreateSnapshotOptions = {}): SnapshotMeta | undefined {
    const target = this.resolveNode(sessionId, opts)
    if (target === undefined) return undefined

    const seq = target.seq
    const contextHash = hashContextUpTo(this.store, target.sessionId, seq)
    const now = Date.now()
    const createdAt = opts.createdAt ?? now
    const lastAccessedAt = opts.lastAccessedAt ?? createdAt
    const snapshotId = `snap_${target.sessionId}:${seq}:${contextHash.slice(0, 8)}`

    const row: SnapshotRow = {
      snapshotId,
      sessionId: target.sessionId,
      branchId: opts.branchId ?? target.sessionId,
      nodeId: target.nodeId,
      seq,
      contextHash,
      label: opts.label,
      note: opts.note,
      createdAt,
      lastAccessedAt,
      accessCount: 0,
    }
    this.store.insertSnapshot(row)
    const existing = this.store.findSnapshot(snapshotId)
    return existing === undefined ? undefined : toMeta(existing)
  }

  /** List snapshots, optionally filtered by session / branch. */
  list(opts: { sessionId?: string; branchId?: string; limit?: number; offset?: number } = {}): SnapshotMeta[] {
    return this.store.listSnapshots(opts).map(toMeta)
  }

  /** Rebuild the captured context from the raw event store (+ staleness check). */
  context(snapshotId: string): SnapshotContext | undefined {
    const row = this.store.findSnapshot(snapshotId)
    if (row === undefined) return undefined
    const events = this.store.listEventsBySession(row.sessionId, { fromSeq: 0, limit: row.seq + 1 })
      .filter(event => event.seq <= row.seq)
    const fresh = hashContextUpTo(this.store, row.sessionId, row.seq)
    return {
      snapshot: toMeta(row),
      events,
      hashMatch: fresh === row.contextHash,
    }
  }

  /** Record a view (LRU bookkeeping). */
  touch(snapshotId: string): boolean {
    return this.store.touchSnapshot(snapshotId)
  }

  remove(snapshotId: string): boolean {
    return this.store.deleteSnapshot(snapshotId)
  }

  /** LRU + TTL pruning; protects the newest `keepNewest` snapshots from TTL. */
  prune(opts: PruneOptions = {}): PruneResult {
    const maxSnapshots = opts.maxSnapshots ?? DEFAULTS.maxSnapshots
    const ttlMs = opts.ttlMs ?? DEFAULTS.ttlMs
    const keepNewest = opts.keepNewest ?? DEFAULTS.keepNewest

    const all = this.store.listSnapshotsLru() // oldest-access first
    let removed = 0
    const now = Date.now()

    // TTL pass (skip the newest `keepNewest`).
    if (ttlMs > 0) {
      const cutoff = now - ttlMs
      const protectedIds = new Set(all.slice(-keepNewest).map(row => row.snapshotId))
      for (const row of all) {
        if (protectedIds.has(row.snapshotId)) continue
        if (row.lastAccessedAt < cutoff) {
          if (this.store.deleteSnapshot(row.snapshotId)) removed += 1
        }
      }
    }

    // LRU cap pass.
    const remaining = this.store.listSnapshotsLru()
    let overflow = remaining.length - maxSnapshots
    for (const row of remaining) {
      if (overflow <= 0) break
      if (this.store.deleteSnapshot(row.snapshotId)) {
        overflow -= 1
        removed += 1
      }
    }

    return { removed, kept: this.store.countSnapshots() }
  }

  // ---- internals ----

  private resolveNode(
    sessionId: string,
    opts: CreateSnapshotOptions,
  ): { sessionId: string; seq: number; nodeId: string } | undefined {
    if (opts.nodeId !== undefined) {
      const parsed = parseNodeId(opts.nodeId)
      if (parsed === undefined) return undefined
      const event = this.store.listEventsBySession(parsed.sessionId, { fromSeq: parsed.seq, limit: 1 })[0]
      if (event === undefined || event.seq !== parsed.seq) return undefined
      return { sessionId: parsed.sessionId, seq: parsed.seq, nodeId: opts.nodeId }
    }
    const session = this.store.findSession(sessionId)
    if (session === undefined) return undefined
    const seq = session.lastEventSeq
    return { sessionId, seq, nodeId: `${sessionId}:${seq}` }
  }
}

function parseNodeId(nodeId: string): { sessionId: string; seq: number } | undefined {
  const idx = nodeId.lastIndexOf(':')
  if (idx <= 0 || idx === nodeId.length - 1) return undefined
  const seq = Number(nodeId.slice(idx + 1))
  if (!Number.isSafeInteger(seq) || seq < 0) return undefined
  return { sessionId: nodeId.slice(0, idx), seq }
}

function toMeta(row: SnapshotRow): SnapshotMeta {
  return {
    snapshotId: row.snapshotId,
    sessionId: row.sessionId,
    branchId: row.branchId,
    nodeId: row.nodeId,
    seq: row.seq,
    contextHash: row.contextHash,
    label: row.label,
    note: row.note,
    createdAt: row.createdAt,
    lastAccessedAt: row.lastAccessedAt,
    accessCount: row.accessCount,
  }
}
