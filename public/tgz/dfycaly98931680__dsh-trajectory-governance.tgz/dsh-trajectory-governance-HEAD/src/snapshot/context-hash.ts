/**
 * Context hash: a stable sha256 over the event prefix (seq 0..seq) of a
 * session, built from normalized scalar summaries. Deterministic across
 * store reads of the same log; any change in the captured prefix changes the
 * hash, which is how snapshot staleness is detected.
 */
import { createHash } from 'node:crypto'
import type { EventStore } from '../persistence/event-store.js'

export function hashContextUpTo(store: EventStore, sessionId: string, seq: number): string {
  const events = store.listEventsBySession(sessionId, { fromSeq: 0, limit: seq + 1 })
  const hash = createHash('sha256')
  for (const event of events) {
    if (event.seq > seq) break
    // [seq, type, time, data] — data is the normalizer's deterministic
    // scalar summary; raw is derivable and excluded.
    hash.update(JSON.stringify([event.seq, event.type, event.time, event.data]))
  }
  return hash.digest('hex')
}
