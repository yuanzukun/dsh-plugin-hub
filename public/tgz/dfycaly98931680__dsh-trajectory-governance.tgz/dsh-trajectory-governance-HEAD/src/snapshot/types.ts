/**
 * Observation-layer snapshot vocabulary.
 *
 * A snapshot is an INDEX, not a copy: it stores the node id, the branch id,
 * and a content hash of the event prefix up to that node. The context is
 * rebuilt on demand from the raw event store, and the hash detects staleness
 * (the store no longer reproduces the captured context).
 *
 * Boundary: observation only. This layer never intercepts, forks, or rewinds
 * the agent's real execution — the harness owns real control-plane actions.
 */
import type { StoredEvent } from '../persistence/event-store.js'

export interface SnapshotMeta {
  snapshotId: string
  sessionId: string
  branchId: string
  /** `${sessionId}:${seq}` — the anchored node. */
  nodeId: string
  seq: number
  /** sha256 of the event prefix (seq 0..seq) — reproducible from the store. */
  contextHash: string
  label?: string
  note?: string
  createdAt: number
  lastAccessedAt: number
  accessCount: number
}

export interface SnapshotContext {
  snapshot: SnapshotMeta
  /** Rebuilt event prefix up to and including the anchored node. */
  events: StoredEvent[]
  /** false when the store no longer reproduces the captured context. */
  hashMatch: boolean
}

export interface PruneOptions {
  /** Hard LRU cap: evict oldest-accessed snapshots above this count. */
  maxSnapshots?: number
  /** TTL: evict snapshots untouched for longer than this (ms). */
  ttlMs?: number
  /** Never evict the newest N snapshots during a TTL pass. */
  keepNewest?: number
}

export interface PruneResult {
  removed: number
  kept: number
}
