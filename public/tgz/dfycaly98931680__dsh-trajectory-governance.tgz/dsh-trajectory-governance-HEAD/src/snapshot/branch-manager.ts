/**
 * Branch management (observation side).
 *
 * A branch IS a session: fork/subagent children get their own branchId
 * (their sessionId) — recorded automatically by the ingest layer from
 * session/created lineage. This module adds the read face (listBranches)
 * and observation-store cleanup (deleteBranch). Deleting a branch removes
 * only THIS plugin's copy (events/snapshots/session rows); the real DSH
 * session is never touched.
 */
import type { EventStore, DeleteBranchResult, SessionRecord } from '../persistence/event-store.js'
import type { BranchType } from '../tree/types.js'

export interface BranchSummary {
  sessionId: string
  branchId: string
  branchType: BranchType
  parentSessionId: string | null
  label?: string
  status: SessionRecord['status']
  createdAt: number
  lastEventSeq: number
  eventCount: number
}

export function listBranches(store: EventStore, rootSessionId: string): BranchSummary[] {
  const all = store.listSessions(1_000_000)
  const byParent = new Map<string | undefined, SessionRecord[]>()
  for (const session of all) {
    const key = session.parentSessionId ?? undefined
    const list = byParent.get(key) ?? []
    list.push(session)
    byParent.set(key, list)
  }
  const out: BranchSummary[] = []
  const root = store.findSession(rootSessionId)
  if (root === undefined) return out
  out.push(toSummary(store, root))
  const walk = (sessionId: string): void => {
    const children = byParent.get(sessionId) ?? []
    for (const child of children) {
      out.push(toSummary(store, child))
      walk(child.sessionId)
    }
  }
  walk(rootSessionId)
  return out
}

export function deleteBranch(store: EventStore, sessionId: string): DeleteBranchResult {
  const all = store.listSessions(1_000_000)
  const byParent = new Map<string, SessionRecord[]>()
  for (const session of all) {
    if (session.parentSessionId === undefined) continue
    const list = byParent.get(session.parentSessionId) ?? []
    list.push(session)
    byParent.set(session.parentSessionId, list)
  }
  const total: DeleteBranchResult = { removedEvents: 0, removedSnapshots: 0, removedSessions: 0 }
  const walk = (id: string): void => {
    for (const child of byParent.get(id) ?? []) walk(child.sessionId)
    const part = store.deleteBranchData(id)
    total.removedEvents += part.removedEvents
    total.removedSnapshots += part.removedSnapshots
    total.removedSessions += part.removedSessions
  }
  walk(sessionId)
  return total
}

function toSummary(store: EventStore, session: SessionRecord | undefined): BranchSummary {
  const eventCount = session === undefined ? 0 : store.countEventsBySession(session.sessionId)
  return {
    sessionId: session?.sessionId ?? '',
    branchId: session?.sessionId ?? '',
    branchType: session === undefined
      ? 'main'
      : session.origin === 'subagent'
        ? 'subagent'
        : session.parentSessionId === undefined ? 'main' : 'fork',
    parentSessionId: session?.parentSessionId ?? null,
    label: session?.subagentLabel,
    status: session?.status ?? 'active',
    createdAt: session?.createdAt ?? 0,
    lastEventSeq: session?.lastEventSeq ?? 0,
    eventCount,
  }
}
