/**
 * Diagnosis strategy configuration — every threshold is adjustable per
 * deployment through the plugin row `config.diagnosis` (deep-merged over
 * defaults). See DIAGNOSIS_CONFIG_SCHEMA for the JSON schema.
 */
export interface StrategyAConfig {
  enabled: boolean
  /** Sliding window over consecutive tool calls. */
  windowSize: number
  /** Min consecutive tool-call similarity to suspect a loop. */
  similarityThreshold: number
  /** Min similarity of the window's tool results (no substantive progress). */
  resultSimilarityThreshold: number
}

export interface StrategyBConfig {
  enabled: boolean
  /** Sliding window over consecutive error signals. */
  windowSize: number
  /** Min similarity of consecutive errors to count as "same class". */
  errorSimilarityThreshold: number
  /** Min similarity of the retry actions to count as "no real adjustment". */
  actionSimilarityThreshold: number
  /** Consecutive same-class errors required to flag invalid retry. */
  minRounds: number
}

export interface StrategyCConfig {
  enabled: boolean
  /** Sample the agent's current intent every N turns (turn/end boundaries). */
  sampleEveryNRounds: number
  /** Cosine below this vs the baseline counts as a drift sample. */
  similarityThreshold: number
  /** Consecutive low-similarity samples required to flag drift. */
  consecutiveSamples: number
  /** Cosine below this → severe drift. */
  severeBelow: number
  /** Cosine below this (but above severeBelow) → moderate drift. */
  moderateBelow: number
  /** 'lexical' (built-in) — 'llm' is the extension seam (degrades to lexical). */
  embedder: 'lexical' | 'llm'
}

export interface AnalyzerConfig {
  enabled: boolean
  /** Async incremental tick. */
  intervalMs: number
  /** Overlap window re-scanned on each incremental run (dedupe keeps it cheap). */
  incrementalWindow: number
}

/** Anomaly action tier: how far the plugin may act on a finding. */
export type AnomalyAction = 'notify' | 'suggest-stop' | 'auto-stop'

export interface AlertsConfig {
  enabled: boolean
  /** Only alert on anomalies with confidence >= this. */
  minConfidence: number
  /** Per-session cooldown between alerts (ms). */
  cooldownMs: number
  channels: {
    /** Browser Notification (client side, polled). */
    desktop: boolean
    /** Emit `trajectory/anomaly` on the Cordis bus for the ecosystem. */
    cordisEvent: boolean
    /** POST JSON to a webhook URL (Feishu/DingTalk/Slack/Discord …). */
    webhook: { url: string }
  }
}

export interface ActionsConfig {
  onLoopDeadlock: AnomalyAction
  onInvalidRetry: AnomalyAction
  onGoalDrift: AnomalyAction
  /** auto-stop additionally requires confidence >= this. */
  autoStopMinConfidence: number
}

export interface CostConfig {
  enabled: boolean
  /** Price per 1M tokens (CNY). Adjust to your provider pricing. */
  tokenPricePerM: number
  /** When a message lacks `usage`, estimate from average tokens per message. */
  estimateWhenUsageMissing: boolean
}

export interface DiagnosisConfig {
  strategyA: StrategyAConfig
  strategyB: StrategyBConfig
  strategyC: StrategyCConfig
  analyzer: AnalyzerConfig
  alerts: AlertsConfig
  actions: ActionsConfig
  cost: CostConfig
}

export const DEFAULT_DIAGNOSIS_CONFIG: DiagnosisConfig = {
  strategyA: {
    enabled: true,
    windowSize: 5,
    similarityThreshold: 0.85,
    resultSimilarityThreshold: 0.8,
  },
  strategyB: {
    enabled: true,
    windowSize: 4,
    errorSimilarityThreshold: 0.8,
    actionSimilarityThreshold: 0.85,
    minRounds: 3,
  },
  strategyC: {
    enabled: true,
    sampleEveryNRounds: 5,
    similarityThreshold: 0.5,
    consecutiveSamples: 2,
    severeBelow: 0.3,
    moderateBelow: 0.45,
    embedder: 'lexical',
  },
  analyzer: {
    enabled: true,
    intervalMs: 10_000,
    incrementalWindow: 50,
  },
  alerts: {
    enabled: true,
    minConfidence: 0.8,
    cooldownMs: 10 * 60 * 1000,
    channels: {
      desktop: true,
      cordisEvent: true,
      webhook: { url: '' },
    },
  },
  actions: {
    onLoopDeadlock: 'notify',
    onInvalidRetry: 'notify',
    onGoalDrift: 'notify',
    autoStopMinConfidence: 0.9,
  },
  cost: {
    enabled: true,
    tokenPricePerM: 0.28,
    estimateWhenUsageMissing: true,
  },
}

/** JSON schema for the `config.diagnosis` section (tools/validators). */
export const DIAGNOSIS_CONFIG_SCHEMA: Record<string, unknown> = {
  $schema: 'https://json-schema.org/draft/2020-12/schema',
  title: 'dsh-trajectory-governance diagnosis config',
  type: 'object',
  additionalProperties: false,
  properties: {
    strategyA: {
      type: 'object',
      additionalProperties: false,
      properties: {
        enabled: { type: 'boolean' },
        windowSize: { type: 'integer', minimum: 2, maximum: 50 },
        similarityThreshold: { type: 'number', minimum: 0, maximum: 1 },
        resultSimilarityThreshold: { type: 'number', minimum: 0, maximum: 1 },
      },
    },
    strategyB: {
      type: 'object',
      additionalProperties: false,
      properties: {
        enabled: { type: 'boolean' },
        windowSize: { type: 'integer', minimum: 2, maximum: 50 },
        errorSimilarityThreshold: { type: 'number', minimum: 0, maximum: 1 },
        actionSimilarityThreshold: { type: 'number', minimum: 0, maximum: 1 },
        minRounds: { type: 'integer', minimum: 2, maximum: 50 },
      },
    },
    strategyC: {
      type: 'object',
      additionalProperties: false,
      properties: {
        enabled: { type: 'boolean' },
        sampleEveryNRounds: { type: 'integer', minimum: 1, maximum: 100 },
        similarityThreshold: { type: 'number', minimum: 0, maximum: 1 },
        consecutiveSamples: { type: 'integer', minimum: 1, maximum: 20 },
        severeBelow: { type: 'number', minimum: 0, maximum: 1 },
        moderateBelow: { type: 'number', minimum: 0, maximum: 1 },
        embedder: { enum: ['lexical', 'llm'] },
      },
    },
    analyzer: {
      type: 'object',
      additionalProperties: false,
      properties: {
        enabled: { type: 'boolean' },
        intervalMs: { type: 'integer', minimum: 1000 },
        incrementalWindow: { type: 'integer', minimum: 1, maximum: 10000 },
      },
    },
    alerts: {
      type: 'object',
      additionalProperties: false,
      properties: {
        enabled: { type: 'boolean' },
        minConfidence: { type: 'number', minimum: 0, maximum: 1 },
        cooldownMs: { type: 'integer', minimum: 0 },
        channels: {
          type: 'object',
          additionalProperties: false,
          properties: {
            desktop: { type: 'boolean' },
            cordisEvent: { type: 'boolean' },
            webhook: {
              type: 'object',
              additionalProperties: false,
              properties: { url: { type: 'string' } },
            },
          },
        },
      },
    },
    actions: {
      type: 'object',
      additionalProperties: false,
      properties: {
        onLoopDeadlock: { enum: ['notify', 'suggest-stop', 'auto-stop'] },
        onInvalidRetry: { enum: ['notify', 'suggest-stop', 'auto-stop'] },
        onGoalDrift: { enum: ['notify', 'suggest-stop', 'auto-stop'] },
        autoStopMinConfidence: { type: 'number', minimum: 0, maximum: 1 },
      },
    },
    cost: {
      type: 'object',
      additionalProperties: false,
      properties: {
        enabled: { type: 'boolean' },
        tokenPricePerM: { type: 'number', minimum: 0 },
        estimateWhenUsageMissing: { type: 'boolean' },
      },
    },
  },
}

/** Deep-merge a partial config over the defaults (missing keys keep defaults). */
export function mergeDiagnosisConfig(partial: Partial<DiagnosisConfig> | undefined): DiagnosisConfig {
  if (partial === undefined) return structuredClone(DEFAULT_DIAGNOSIS_CONFIG)
  return {
    strategyA: { ...DEFAULT_DIAGNOSIS_CONFIG.strategyA, ...partial.strategyA },
    strategyB: { ...DEFAULT_DIAGNOSIS_CONFIG.strategyB, ...partial.strategyB },
    strategyC: { ...DEFAULT_DIAGNOSIS_CONFIG.strategyC, ...partial.strategyC },
    analyzer: { ...DEFAULT_DIAGNOSIS_CONFIG.analyzer, ...partial.analyzer },
    alerts: {
      ...DEFAULT_DIAGNOSIS_CONFIG.alerts,
      ...partial.alerts,
      channels: {
        ...DEFAULT_DIAGNOSIS_CONFIG.alerts.channels,
        ...partial.alerts?.channels,
        webhook: {
          ...DEFAULT_DIAGNOSIS_CONFIG.alerts.channels.webhook,
          ...partial.alerts?.channels?.webhook,
        },
      },
    },
    actions: { ...DEFAULT_DIAGNOSIS_CONFIG.actions, ...partial.actions },
    cost: { ...DEFAULT_DIAGNOSIS_CONFIG.cost, ...partial.cost },
  }
}
