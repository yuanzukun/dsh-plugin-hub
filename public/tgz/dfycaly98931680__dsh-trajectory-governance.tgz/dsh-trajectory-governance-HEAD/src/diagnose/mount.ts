/**
 * Mount persisted anomalies onto a built trajectory tree.
 *
 * The AnomalyResult is attached to its trigger node (startNodeId); the full
 * range is available through the anomaly list API for UI highlighting. A node
 * inside a flagged range reports the covering anomaly via coveredBy().
 */
import type { EventStore, AnomalyRow } from '../persistence/event-store.js'
import type { AnomalyType, TrajectoryNode } from '../tree/types.js'

export function mountAnomalies(store: EventStore, root: TrajectoryNode | undefined): number {
  if (root === undefined) return 0
  const anomalies = store.listAnomalies({ limit: 10_000 })
  const byStart = new Map<string, AnomalyRow[]>()
  for (const anomaly of anomalies) {
    const list = byStart.get(anomaly.startNodeId) ?? []
    list.push(anomaly)
    byStart.set(anomaly.startNodeId, list)
  }
  let mounted = 0
  const walk = (node: TrajectoryNode): void => {
    const hits = byStart.get(node.nodeId)
    if (hits !== undefined && hits.length > 0) {
      const best = hits.reduce((a, b) => (b.confidence > a.confidence ? b : a))
      node.anomalyInfo = {
        anomalyId: best.anomalyId,
        type: best.type as AnomalyType,
        startNodeId: best.startNodeId,
        endNodeId: best.endNodeId,
        confidence: best.confidence,
        description: best.description,
        suggestion: best.suggestion,
      }
      mounted += 1
    }
    for (const child of node.children) walk(child)
  }
  walk(root)
  return mounted
}

/** True when `nodeId` falls inside the anomaly's inclusive range (same session). */
export function coveredBy(anomaly: AnomalyRow, nodeId: string): boolean {
  if (!nodeId.startsWith(`${sessionOf(anomaly.startNodeId)}:`)) return false
  const seq = seqOf(nodeId)
  return seq >= seqOf(anomaly.startNodeId) && seq <= seqOf(anomaly.endNodeId)
}

function sessionOf(nodeId: string): string {
  const idx = nodeId.lastIndexOf(':')
  return idx > 0 ? nodeId.slice(0, idx) : ''
}

function seqOf(nodeId: string): number {
  const idx = nodeId.lastIndexOf(':')
  const seq = Number(nodeId.slice(idx + 1))
  return Number.isSafeInteger(seq) ? seq : -1
}
