/**
 * Anomaly alerts — turn a diagnosis into a human-actionable signal.
 *
 * The alert payload is written in "stop-loss language": type, confidence,
 * how much tokens/money/time the range already consumed, and the configured
 * action tier. Channels: webhook POST (host) and the `trajectory/anomaly`
 * Cordis event (ecosystem); desktop notifications are handled client-side.
 */
import type { AnomalyRow } from '../persistence/event-store.js'
import type { AnomalyAction, DiagnosisConfig } from './config.js'
import type { CostEstimate } from './cost.js'

export interface AnomalyAlert {
  anomalyId: string
  sessionId: string
  type: 'loop_deadlock' | 'invalid_retry' | 'goal_drift'
  startNodeId: string
  endNodeId: string
  confidence: number
  severity?: string
  description: string
  suggestion?: string
  cost: CostEstimate
  /** Configured action tier for this anomaly type. */
  action: AnomalyAction
  /** Stop-loss message for humans. */
  message: string
  createdAt: number
}

/** Trigger gate: enabled? confidence floor? per-anomaly cooldown? */
export class AlertGate {
  private readonly fired = new Map<string, number>()

  constructor(private readonly config: DiagnosisConfig) {}

  shouldAlert(anomaly: AnomalyRow, now = Date.now()): boolean {
    if (!this.config.alerts.enabled) return false
    if (anomaly.confidence < this.config.alerts.minConfidence) return false
    const last = this.fired.get(anomaly.anomalyId)
    if (last !== undefined && now - last < this.config.alerts.cooldownMs) return false
    this.fired.set(anomaly.anomalyId, now)
    return true
  }
}

/** Which action tier applies to this anomaly type. */
export function actionFor(type: AnomalyAlert['type'], config: DiagnosisConfig): AnomalyAction {
  switch (type) {
    case 'loop_deadlock': return config.actions.onLoopDeadlock
    case 'invalid_retry': return config.actions.onInvalidRetry
    case 'goal_drift': return config.actions.onGoalDrift
  }
}

/** Build the human message in stop-loss language. */
export function alertMessage(alert: Omit<AnomalyAlert, 'message'>): string {
  const money = `¥${alert.cost.costCny}`
  const durMin = Math.round(alert.cost.durationMs / 60000)
  const consumed = durMin > 0 ? `${money} / ${durMin} 分钟` : money
  switch (alert.type) {
    case 'loop_deadlock':
      return `⚠ 会话 ${alert.sessionId} 疑似循环死锁（置信度 ${Math.round(alert.confidence * 100)}%）：工具调用高度相似且无实质进展，已消耗约 ${consumed}。建议：中断当前循环并更换策略。`
    case 'invalid_retry':
      return `⚠ 会话 ${alert.sessionId} 疑似无效重试（置信度 ${Math.round(alert.confidence * 100)}%）：同类错误反复出现且重试动作未调整，已消耗约 ${consumed}。建议：先分析根因（权限/参数/环境）再重试。`
    case 'goal_drift':
      return `⚠ 会话 ${alert.sessionId} 任务目标疑似漂移（${alert.severity ?? 'mild'}，置信度 ${Math.round(alert.confidence * 100)}%）：当前执行意图与初始目标已偏离。已消耗约 ${consumed}。建议：暂停并回看原始目标。`
  }
}

export function buildAlert(
  anomaly: AnomalyRow,
  cost: CostEstimate,
  config: DiagnosisConfig,
  createdAt = Date.now(),
): AnomalyAlert {
  const base = {
    anomalyId: anomaly.anomalyId,
    sessionId: anomaly.sessionId,
    type: anomaly.type as AnomalyAlert['type'],
    startNodeId: anomaly.startNodeId,
    endNodeId: anomaly.endNodeId,
    confidence: anomaly.confidence,
    severity: anomaly.severity,
    description: anomaly.description,
    suggestion: anomaly.suggestion,
    cost,
    action: actionFor(anomaly.type as AnomalyAlert['type'], config),
    createdAt,
  }
  return { ...base, message: alertMessage(base) }
}

export interface WebhookPayload {
  text: string
  anomalyId: string
  sessionId: string
  type: string
  confidence: number
  severity?: string
  costCny: number
  durationMs: number
  createdAt: number
}

/** POST the alert to a generic text webhook (Feishu/DingTalk/Slack-compatible `text`). */
export async function sendWebhook(url: string, alert: AnomalyAlert, timeoutMs = 8000): Promise<void> {
  const payload: WebhookPayload = {
    text: alert.message,
    anomalyId: alert.anomalyId,
    sessionId: alert.sessionId,
    type: alert.type,
    confidence: alert.confidence,
    severity: alert.severity,
    costCny: alert.cost.costCny,
    durationMs: alert.cost.durationMs,
    createdAt: alert.createdAt,
  }
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
      signal: controller.signal,
    })
    if (!response.ok) {
      throw new Error(`webhook ${url} → ${String(response.status)}`)
    }
  } finally {
    clearTimeout(timer)
  }
}
