/**
 * Diagnosis engine — async, non-blocking, incremental/full analysis.
 *
 * Reads the session chain from the store, runs the three strategies, and
 * persists deduped AnomalyResults (stable ids → idempotent upserts). The
 * incremental watermark (diagnosis_state) plus a tail-overlap window keeps
 * repeated runs cheap; the agent loop is never awaited or blocked.
 */
import type { EventStore } from '../persistence/event-store.js'
import type { TrajectoryNode } from '../tree/types.js'
import { getBranchTrajectory } from '../tree/queries.js'
import { mergeDiagnosisConfig, type DiagnosisConfig } from './config.js'
import {
  detectGoalDrift,
  detectInvalidRetry,
  detectLoopDeadlock,
  type DraftAnomaly,
} from './strategies.js'
import { LexicalEmbedder } from './similarity.js'

export interface AnalyzeOptions {
  /** Re-scan from seq 0 instead of the incremental watermark. */
  full?: boolean
}

export interface SessionRunResult {
  sessionId: string
  newAnomalies: number
  /** Ids of anomalies that did not exist before this run (alert candidates). */
  newAnomalyIds: string[]
  totalAnomalies: number
  ranStrategies: string[]
}

export interface AllSessionsResult {
  sessions: number
  newAnomalies: number
}

export class DiagnosisEngine {
  private readonly config: DiagnosisConfig
  private readonly embedder: LexicalEmbedder

  constructor(
    private readonly store: EventStore,
    config?: Partial<DiagnosisConfig>,
  ) {
    this.config = mergeDiagnosisConfig(config)
    this.embedder = new LexicalEmbedder()
  }

  getConfig(): DiagnosisConfig {
    return this.config
  }

  /** Analyze one session; returns how many NEW anomalies were found. */
  async analyzeSession(sessionId: string, opts: AnalyzeOptions = {}): Promise<SessionRunResult> {
    const session = this.store.findSession(sessionId)
    if (session === undefined) {
      return { sessionId, newAnomalies: 0, newAnomalyIds: [], totalAnomalies: 0, ranStrategies: [] }
    }

    const chain = getBranchTrajectory(this.store, sessionId)
    if (chain.length === 0) return { sessionId, newAnomalies: 0, newAnomalyIds: [], totalAnomalies: 0, ranStrategies: [] }

    const state = this.store.getDiagnosisState(sessionId)
    const fromSeq = opts.full ? 0 : Math.max(0, (state?.analyzedSeq ?? 0) - this.config.analyzer.incrementalWindow)
    // strategies see the whole chain (context lookups) but only report from the window
    const windowNodes = chain.filter(node => node.seq >= fromSeq)

    const drafts: DraftAnomaly[] = [
      ...detectLoopDeadlock(windowNodes, this.config),
      ...detectInvalidRetry(windowNodes, this.config),
      ...(await detectGoalDrift(windowNodes, this.config, this.embedder)),
    ]

    const ranStrategies = [
      ...(this.config.strategyA.enabled ? ['loop_deadlock'] : []),
      ...(this.config.strategyB.enabled ? ['invalid_retry'] : []),
      ...(this.config.strategyC.enabled ? ['goal_drift'] : []),
    ]

    const now = Date.now()
    let newAnomalies = 0
    const newAnomalyIds: string[] = []
    for (const draft of drafts) {
      const anomalyId = anomalyIdFor(sessionId, draft)
      const existed = this.store.findAnomaly(anomalyId) !== undefined
      this.store.upsertAnomaly({
        anomalyId,
        sessionId,
        type: draft.type,
        startNodeId: draft.startNodeId,
        endNodeId: draft.endNodeId,
        confidence: draft.confidence,
        description: draft.description,
        suggestion: draft.suggestion,
        severity: draft.severity,
        createdAt: existed ? (this.store.findAnomaly(anomalyId)?.createdAt ?? now) : now,
        updatedAt: now,
      })
      if (!existed) {
        newAnomalies += 1
        newAnomalyIds.push(anomalyId)
      }
    }

    const tailSeq = chain[chain.length - 1]!.seq
    this.store.setDiagnosisState(sessionId, tailSeq, now)

    return {
      sessionId,
      newAnomalies,
      newAnomalyIds,
      totalAnomalies: this.store.countAnomaliesBySession(sessionId),
      ranStrategies,
    }
  }

  /** Analyze every session whose log grew past its watermark. */
  async analyzeDirtySessions(): Promise<AllSessionsResult> {
    let sessions = 0
    let newAnomalies = 0
    for (const session of this.store.listSessions(1_000_000)) {
      const state = this.store.getDiagnosisState(session.sessionId)
      if (session.lastEventSeq > (state?.analyzedSeq ?? 0)) {
        const result = await this.analyzeSession(session.sessionId)
        sessions += 1
        newAnomalies += result.newAnomalies
      }
    }
    return { sessions, newAnomalies }
  }

  /** Full re-analysis of every session with events. */
  async analyzeAllSessions(): Promise<AllSessionsResult> {
    let sessions = 0
    let newAnomalies = 0
    for (const session of this.store.listSessions(1_000_000)) {
      if (this.store.countEventsBySession(session.sessionId) === 0) continue
      const result = await this.analyzeSession(session.sessionId, { full: true })
      sessions += 1
      newAnomalies += result.newAnomalies
    }
    return { sessions, newAnomalies }
  }
}

/** Deterministic anomaly id — same finding always maps to the same row. */
export function anomalyIdFor(sessionId: string, draft: DraftAnomaly): string {
  const start = seqOf(draft.startNodeId)
  const end = seqOf(draft.endNodeId)
  return `anom_${sessionId}_${draft.type}_${start}_${end}`
}

function seqOf(nodeId: string): number {
  const idx = nodeId.lastIndexOf(':')
  const seq = Number(nodeId.slice(idx + 1))
  return Number.isSafeInteger(seq) ? seq : 0
}

export type { TrajectoryNode }
