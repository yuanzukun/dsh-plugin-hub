/**
 * Async diagnosis runtime — a background tick that analyzes sessions whose
 * logs grew, without ever blocking the agent loop, and dispatches alerts for
 * newly found anomalies (webhook POST + `trajectory/anomaly` bus event).
 */
import type { Context } from '@deepseek-ai/cordis'
import type { EventStore } from '../persistence/event-store.js'
import { DiagnosisEngine } from './engine.js'
import type { DiagnosisConfig } from './config.js'
import { AlertGate, buildAlert, sendWebhook, type AnomalyAlert } from './alerts.js'
import { CostEstimator } from './cost.js'

export interface AlertEmitter {
  /** Emit the alert on the Cordis bus (ecosystem notifications can subscribe). */
  emit(event: 'trajectory/anomaly', alert: AnomalyAlert): void
}

export function installDiagnosisRuntime(
  ctx: Context & AlertEmitter,
  store: EventStore,
  config: DiagnosisConfig,
): DiagnosisEngine {
  const engine = new DiagnosisEngine(store, config)
  const gate = new AlertGate(config)
  const cost = new CostEstimator(store, {
    tokenPricePerM: config.cost.tokenPricePerM,
    estimateWhenUsageMissing: config.cost.estimateWhenUsageMissing,
  })

  if (!config.analyzer.enabled) {
    ctx.logger.info('[trajectory-governance] diagnosis auto-analyzer disabled')
    return engine
  }

  const dispatchAlert = (anomalyId: string): void => {
    try {
      const anomaly = store.findAnomaly(anomalyId)
      if (anomaly === undefined) return
      if (!gate.shouldAlert(anomaly)) return
      const costEstimate = cost.estimate(anomaly.sessionId, seqOf(anomaly.startNodeId), seqOf(anomaly.endNodeId))
      const alert = buildAlert(anomaly, costEstimate, config)
      if (config.alerts.channels.cordisEvent) {
        try {
          ctx.emit('trajectory/anomaly', alert)
        } catch (emitError) {
          ctx.logger.warn(`[trajectory-governance] alert emit failed: ${errorMessage(emitError)}`)
        }
      }
      const webhookUrl = config.alerts.channels.webhook.url
      if (webhookUrl !== '') {
        void sendWebhook(webhookUrl, alert)
          .catch(error => ctx.logger.warn(`[trajectory-governance] webhook failed: ${errorMessage(error)}`))
      }
      ctx.logger.warn(`[trajectory-governance] ${alert.message}`)
    } catch (error) {
      ctx.logger.warn(`[trajectory-governance] alert dispatch failed: ${errorMessage(error)}`)
    }
  }

  ctx.effect(() => {
    const id = setInterval(() => {
      void engine.analyzeDirtySessions()
        .then(result => {
          if (result.newAnomalies > 0) {
            ctx.logger.info(
              `[trajectory-governance] diagnosis: ${result.sessions} session(s), ${result.newAnomalies} new anomaly(ies)`,
            )
          }
        })
        .catch(error => {
          ctx.logger.warn(`[trajectory-governance] diagnosis tick failed: ${errorMessage(error)}`)
        })
    }, config.analyzer.intervalMs)
    return () => clearInterval(id)
  }, 'trajectory-governance: diagnosis analyzer')

  // Hook INTO the engine so alerts fire the moment a NEW anomaly is persisted,
  // not one tick later.
  const original = engine.analyzeSession.bind(engine)
  engine.analyzeSession = async (sessionId, opts) => {
    const result = await original(sessionId, opts)
    for (const id of result.newAnomalyIds) dispatchAlert(id)
    return result
  }

  return engine
}

function seqOf(nodeId: string): number {
  const idx = nodeId.lastIndexOf(':')
  const seq = Number(nodeId.slice(idx + 1))
  return Number.isSafeInteger(seq) ? seq : -1
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
