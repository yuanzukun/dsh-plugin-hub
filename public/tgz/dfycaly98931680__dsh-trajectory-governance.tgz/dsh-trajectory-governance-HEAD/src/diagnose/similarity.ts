/**
 * Similarity primitives — lexical (n-gram cosine), dependency-free.
 *
 * Strategy C's "embedding" is pluggable through the Embedder interface; the
 * built-in LexicalEmbedder is the default (the harness exposes no public
 * embedding service; an LLM-based embedder can be supplied later without
 * changing the strategies).
 */

/** Character n-grams of alphanumeric/CJK tokens. */
export function ngramTokens(text: string, n = 2): string[] {
  const cleaned = text
    .toLowerCase()
    .replace(/[^a-z0-9\u4e00-\u9fff]+/g, ' ')
    .trim()
  if (cleaned === '') return []
  const grams: string[] = []
  for (const token of cleaned.split(' ')) {
    if (token.length <= n) {
      grams.push(token)
    } else {
      for (let i = 0; i <= token.length - n; i += 1) grams.push(token.slice(i, i + n))
    }
  }
  return grams
}

export function cosineOf(tokensA: string[], tokensB: string[]): number {
  const countsA = new Map<string, number>()
  const countsB = new Map<string, number>()
  for (const token of tokensA) countsA.set(token, (countsA.get(token) ?? 0) + 1)
  for (const token of tokensB) countsB.set(token, (countsB.get(token) ?? 0) + 1)
  let dot = 0
  let normA = 0
  let normB = 0
  for (const [token, count] of countsA) {
    dot += count * (countsB.get(token) ?? 0)
    normA += count * count
  }
  for (const count of countsB.values()) normB += count * count
  if (normA === 0 && normB === 0) return 1
  if (normA === 0 || normB === 0) return 0
  return dot / (Math.sqrt(normA) * Math.sqrt(normB))
}

export function textSimilarity(a: string, b: string): number {
  if (a === b) return 1
  if (a.trim() === '' || b.trim() === '') return 0
  return cosineOf(ngramTokens(a), ngramTokens(b))
}

/** Stable fingerprint of a tool-arguments JSON string (key order independent). */
export function argumentFingerprint(argsJson: string | undefined): string {
  if (argsJson === undefined) return ''
  try {
    return JSON.stringify(sortKeys(JSON.parse(argsJson) as unknown))
  } catch {
    return argsJson
  }
}

function sortKeys(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sortKeys)
  if (value !== null && typeof value === 'object') {
    const record = value as Record<string, unknown>
    const out: Record<string, unknown> = {}
    for (const key of Object.keys(record).sort()) out[key] = sortKeys(record[key])
    return out
  }
  return value
}

export function argumentsSimilarity(a: string | undefined, b: string | undefined): number {
  if (a === undefined && b === undefined) return 1
  return textSimilarity(argumentFingerprint(a), argumentFingerprint(b))
}

/** Tool call similarity: name equality (0.6) + argument similarity (0.4). */
export function toolCallSimilarity(
  nameA: string,
  argsA: string | undefined,
  nameB: string,
  argsB: string | undefined,
): number {
  const nameSim = nameA === nameB ? 1 : 0
  return nameSim * 0.6 + argumentsSimilarity(argsA, argsB) * 0.4
}

export function errorSimilarity(a: string, b: string): number {
  if (a === b) return 1
  return textSimilarity(a, b)
}

// ---- Embedder (Strategy C) ----

export interface Embedder {
  embed(text: string): Promise<number[]>
}

/** Feature-hashed n-gram bag → fixed-dim normalized vector; zero dependencies. */
export class LexicalEmbedder implements Embedder {
  constructor(
    private readonly dim = 256,
    private readonly n = 2,
  ) {}

  async embed(text: string): Promise<number[]> {
    const vector = new Array<number>(this.dim).fill(0)
    for (const token of ngramTokens(text, this.n)) {
      let hash = 0
      for (let i = 0; i < token.length; i += 1) hash = (hash * 31 + token.charCodeAt(i)) >>> 0
      const idx = hash % this.dim
      vector[idx] = (vector[idx] ?? 0) + 1
    }
    let norm = 0
    for (const value of vector) norm += value * value
    norm = Math.sqrt(norm)
    if (norm > 0) {
      for (let i = 0; i < vector.length; i += 1) vector[i] = (vector[i] ?? 0) / norm
    }
    return vector
  }
}

export function vectorCosine(a: number[], b: number[]): number {
  if (a.length !== b.length) return 0
  let dot = 0
  let normA = 0
  let normB = 0
  for (let i = 0; i < a.length; i += 1) {
    const av = a[i] ?? 0
    const bv = b[i] ?? 0
    dot += av * bv
    normA += av * av
    normB += bv * bv
  }
  if (normA === 0 && normB === 0) return 1
  if (normA === 0 || normB === 0) return 0
  return dot / (Math.sqrt(normA) * Math.sqrt(normB))
}
