/**
 * The three temporal anomaly strategies — pure functions over a session's
 * linear node chain. Each returns draft anomalies; the engine dedupes,
 * persists, and mounts them.
 *
 * False-positive controls:
 *  - Strategy A requires BOTH similar calls AND similar results (no
 *    substantive progress); iterative refinement where results change does
 *    not alarm.
 *  - Strategy B requires same-class errors AND similar retry actions
 *    (no real adjustment); evolving remediation does not alarm.
 *  - Strategy C samples intent periodically and requires CONSECUTIVE
 *    low-similarity samples; a single low sample (a detour that re-converges)
 *    does not alarm.
 */
import type { TrajectoryNode } from '../tree/types.js'
import type { DiagnosisConfig } from './config.js'
import {
  argumentsSimilarity,
  errorSimilarity,
  type Embedder,
  LexicalEmbedder,
  textSimilarity,
  toolCallSimilarity,
  vectorCosine,
} from './similarity.js'

export interface DraftAnomaly {
  type: 'loop_deadlock' | 'invalid_retry' | 'goal_drift'
  startNodeId: string
  endNodeId: string
  confidence: number
  description: string
  suggestion?: string
  severity?: 'mild' | 'moderate' | 'severe'
}

const FAILURE_REASON_KINDS = new Set(['error', 'aborted', 'blocked', 'max-tokens', 'interrupted'])

// ---------------------------------------------------------------------------
// Strategy A — loop deadlock
// ---------------------------------------------------------------------------

export function detectLoopDeadlock(chain: TrajectoryNode[], config: DiagnosisConfig): DraftAnomaly[] {
  const cfg = config.strategyA
  if (!cfg.enabled) return []
  const calls = chain.filter(node => node.kind === 'tool-call')
  const out: DraftAnomaly[] = []
  for (let i = 0; i + cfg.windowSize <= calls.length; i += 1) {
    const window = calls.slice(i, i + cfg.windowSize)
    let minCallSim = 1
    for (let j = 0; j + 1 < window.length; j += 1) {
      const sim = toolCallSimilarity(
        toolName(window[j]!),
        toolArgs(window[j]!),
        toolName(window[j + 1]!),
        toolArgs(window[j + 1]!),
      )
      minCallSim = Math.min(minCallSim, sim)
    }
    const results = window.map(call => toolResultText(chain, call)).filter(text => text !== undefined)
    let minResultSim = 1
    if (results.length >= 2) {
      for (let j = 0; j + 1 < results.length; j += 1) {
        minResultSim = Math.min(minResultSim, textSimilarity(results[j]!, results[j + 1]!))
      }
    }
    if (minCallSim >= cfg.similarityThreshold && minResultSim >= cfg.resultSimilarityThreshold) {
      const confidence = Math.min(1, minCallSim * 0.7 + minResultSim * 0.3)
      out.push({
        type: 'loop_deadlock',
        startNodeId: window[0]!.nodeId,
        endNodeId: window[window.length - 1]!.nodeId,
        confidence: round(confidence),
        description: `连续 ${cfg.windowSize} 轮工具调用高度相似（相似度 ${round(minCallSim)}）且结果无实质变化（${round(minResultSim)}），疑似循环死锁，任务没有推进。`,
        suggestion: '中断当前循环并更换策略：检查是否缺少终止条件、改用一次性批量操作，或人工干预。',
      })
      // slide past the flagged window to avoid overlapping duplicates
      i += cfg.windowSize - 1
    }
  }
  return out
}

// ---------------------------------------------------------------------------
// Strategy B — invalid retry
// ---------------------------------------------------------------------------

interface Attempt {
  errorNode: TrajectoryNode
  errorKey: string
  action: TrajectoryNode | undefined
}

export function detectInvalidRetry(chain: TrajectoryNode[], config: DiagnosisConfig): DraftAnomaly[] {
  const cfg = config.strategyB
  if (!cfg.enabled) return []
  const attempts: Attempt[] = []
  for (const node of chain) {
    if (isErrorNode(node)) {
      attempts.push({
        errorNode: node,
        errorKey: errorKeyOf(node),
        action: nextToolCall(chain, node),
      })
    }
  }

  const out: DraftAnomaly[] = []
  let run: Attempt[] = []
  const flush = (): void => {
    if (run.length < cfg.minRounds) {
      run = []
      return
    }
    // compare consecutive retry actions; at least one pair must be observable
    const pairs: Array<[TrajectoryNode, TrajectoryNode]> = []
    for (let j = 0; j + 1 < run.length; j += 1) {
      const a = run[j]!.action
      const b = run[j + 1]!.action
      if (a !== undefined && b !== undefined) pairs.push([a, b])
    }
    if (pairs.length === 0) {
      run = []
      return
    }
    let minActionSim = 1
    for (const [a, b] of pairs) {
      minActionSim = Math.min(
        minActionSim,
        toolCallSimilarity(toolName(a), toolArgs(a), toolName(b), toolArgs(b)),
      )
    }
    if (minActionSim >= cfg.actionSimilarityThreshold) {
      const first = run[0]!
      const last = run[run.length - 1]!
      out.push({
        type: 'invalid_retry',
        startNodeId: first.errorNode.nodeId,
        endNodeId: last.errorNode.nodeId,
        confidence: round(Math.min(1, minActionSim * 0.7 + 0.2)),
        description: `连续 ${run.length} 次同类错误（${first.errorKey}）后重试动作仍高度相似（${round(minActionSim)}），未做实质调整，疑似无效重试。`,
        suggestion: '停止机械重试：分析根因（权限/参数/环境），先修正方案再重试。',
      })
    }
    run = []
  }

  for (const attempt of attempts) {
    if (run.length === 0) {
      run = [attempt]
      continue
    }
    const prev = run[run.length - 1]!
    if (errorSimilarity(prev.errorKey, attempt.errorKey) >= cfg.errorSimilarityThreshold) {
      run.push(attempt)
      if (run.length >= cfg.windowSize) flush()
    } else {
      flush()
      run = [attempt]
    }
  }
  flush()
  return out
}

// ---------------------------------------------------------------------------
// Strategy C — goal drift
// ---------------------------------------------------------------------------

export async function detectGoalDrift(
  chain: TrajectoryNode[],
  config: DiagnosisConfig,
  embedder: Embedder = new LexicalEmbedder(),
): Promise<DraftAnomaly[]> {
  const cfg = config.strategyC
  if (!cfg.enabled) return []
  const baseline = baselineText(chain)
  if (baseline === undefined) return []
  const baseVec = await embedder.embed(baseline)

  const samples = sampleIntents(chain, cfg.sampleEveryNRounds)
  const out: DraftAnomaly[] = []
  let consecutiveLow = 0
  let driftRun: { start: TrajectoryNode; sims: number[] } | undefined

  for (const sample of samples) {
    const vec = await embedder.embed(sample.text)
    const sim = vectorCosine(baseVec, vec)
    if (sim < cfg.similarityThreshold) {
      consecutiveLow += 1
      if (driftRun === undefined) driftRun = { start: sample.node, sims: [sim] }
      else driftRun.sims.push(sim)
      if (consecutiveLow >= cfg.consecutiveSamples && driftRun !== undefined) {
        const minSim = Math.min(...driftRun.sims)
        const severity = minSim < cfg.severeBelow ? 'severe' : minSim < cfg.moderateBelow ? 'moderate' : 'mild'
        out.push({
          type: 'goal_drift',
          startNodeId: driftRun.start.nodeId,
          endNodeId: sample.node.nodeId,
          confidence: round(1 - minSim),
          severity,
          description: `当前执行意图与初始目标相似度降至 ${round(minSim)}（连续 ${consecutiveLow} 次采样低于阈值 ${cfg.similarityThreshold}），任务目标疑似漂移（${severity}）。`,
          suggestion: '暂停执行并回看原始目标：是否需要重新对齐意图、拆分任务或终止偏离方向的分支。',
        })
        consecutiveLow = 0
        driftRun = undefined
      }
    } else {
      // re-converged — the detour was transient, do not alarm
      consecutiveLow = 0
      driftRun = undefined
    }
  }
  return out
}

// ---------------------------------------------------------------------------
// shared extraction helpers
// ---------------------------------------------------------------------------

export function toolName(node: TrajectoryNode): string {
  return typeof node.data.name === 'string' ? node.data.name : ''
}

export function toolArgs(node: TrajectoryNode): string | undefined {
  // the raw envelope carries the unparsed arguments string
  const raw = node.raw as { data?: { arguments?: unknown } } | undefined
  return typeof raw?.data?.arguments === 'string' ? raw.data.arguments : undefined
}

function toolResultText(chain: TrajectoryNode[], call: TrajectoryNode): string | undefined {
  const callId = typeof call.data.callId === 'string' ? call.data.callId : undefined
  if (callId === undefined) return undefined
  const result = chain.find(node => node.kind === 'tool-result' && node.data.callId === callId)
  if (result === undefined) return undefined
  return String(JSON.stringify((result.raw as { data?: unknown })?.data ?? '')).slice(0, 2000)
}

export function isErrorNode(node: TrajectoryNode): boolean {
  if (node.kind === 'turn-end') {
    const reason = node.data.reasonKind
    return typeof reason === 'string' && FAILURE_REASON_KINDS.has(reason)
  }
  if (node.kind === 'retry' || node.kind === 'retry-start') return true
  if (node.kind === 'tool-result') return node.data.isError === true
  return false
}

function errorKeyOf(node: TrajectoryNode): string {
  const raw = node.raw as { data?: Record<string, unknown> } | undefined
  const data = raw?.data
  if (node.kind === 'turn-end') {
    const reason = data?.reason as { kind?: unknown; error?: { code?: unknown; message?: unknown } } | undefined
    const code = typeof reason?.error?.code === 'string' ? reason.error.code : ''
    const message = typeof reason?.error?.message === 'string' ? reason.error.message : ''
    return `turn:${String(reason?.kind ?? '')}:${code}:${message.slice(0, 200)}`
  }
  if (node.kind === 'tool-result') {
    return `tool:${String(data?.errorCode ?? '')}:${String(data?.errorName ?? '')}`
  }
  if (node.kind === 'retry' || node.kind === 'retry-start') {
    return `retry:${String(JSON.stringify(data ?? {})).slice(0, 200)}`
  }
  return String(node.eventType)
}

function nextToolCall(chain: TrajectoryNode[], node: TrajectoryNode): TrajectoryNode | undefined {
  const idx = chain.indexOf(node)
  for (let i = idx + 1; i < chain.length; i += 1) {
    if (chain[i]!.kind === 'tool-call') return chain[i]
  }
  return undefined
}

/** First direct user prompt text (source.kind === 'user' preferred). */
export function baselineText(chain: TrajectoryNode[]): string | undefined {
  const messages = chain.filter(node => node.kind === 'user-message')
  const direct = messages.find(node => node.data.sourceKind === 'user')
  const chosen = direct ?? messages[0]
  if (chosen === undefined) return undefined
  const raw = chosen.raw as { data?: { content?: unknown } } | undefined
  const content = raw?.data?.content
  if (!Array.isArray(content)) return undefined
  const text = content
    .map(block => (block as { text?: unknown }).text)
    .filter((value): value is string => typeof value === 'string')
    .join('\n')
  return text.trim() === '' ? undefined : text
}

interface IntentSample {
  node: TrajectoryNode
  text: string
}

/** Sample the latest assistant message before every N-th turn/end boundary. */
export function sampleIntents(chain: TrajectoryNode[], everyNRounds: number): IntentSample[] {
  const turnEnds = chain
    .map((node, index) => ({ node, index }))
    .filter(({ node }) => node.kind === 'turn-end')
  const out: IntentSample[] = []
  for (let i = everyNRounds - 1; i < turnEnds.length; i += everyNRounds) {
    const boundary = turnEnds[i]!
    let text: string | undefined
    for (let j = boundary.index - 1; j >= 0; j -= 1) {
      const node = chain[j]!
      if (node.kind === 'assistant-message') {
        text = assistantText(node)
        if (text !== undefined) break
      }
    }
    if (text !== undefined) out.push({ node: boundary.node, text })
  }
  return out
}

function assistantText(node: TrajectoryNode): string | undefined {
  const raw = node.raw as { data?: { message?: { content?: unknown } } } | undefined
  const content = raw?.data?.message?.content
  if (!Array.isArray(content)) return undefined
  const text = content
    .map(block => (block as { text?: unknown }).text)
    .filter((value): value is string => typeof value === 'string')
    .join('\n')
  return text.trim() === '' ? undefined : text
}

function round(value: number): number {
  return Math.round(value * 100) / 100
}

/** Export for tests: arguments-level similarity used by Strategy A. */
export { argumentsSimilarity }
