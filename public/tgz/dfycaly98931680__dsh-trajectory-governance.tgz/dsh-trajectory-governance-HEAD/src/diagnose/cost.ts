/**
 * Cost attribution: estimate tokens / money / time wasted inside an anomaly
 * range, from the official `assistant/message.usage` events in that seq span.
 *
 * Data source is the harness's own token accounting (TokenUsage on
 * `assistant/message`), never a guess from text length. When usage is missing
 * and `estimateWhenUsageMissing` is on, we fall back to an average derived
 * from the messages that DO carry usage in the same session.
 */
import type { EventStore } from '../persistence/event-store.js'

export interface CostEstimate {
  /** Total tokens from recorded usage (input + output). */
  tokens: number
  /** Tokens counted as "unknown" (messages without usage, estimate on). */
  unknownTokens: number
  /** Estimated money at the configured price. */
  costCny: number
  /** Wall time between the range's first and last event (ms). */
  durationMs: number
  /** True when part of the total was estimated, not recorded. */
  estimated: boolean
}

export interface CostEstimatorOptions {
  tokenPricePerM: number
  estimateWhenUsageMissing: boolean
}

export class CostEstimator {
  constructor(
    private readonly store: EventStore,
    private readonly opts: CostEstimatorOptions,
  ) {}

  /** Configured price per 1M tokens. */
  pricePerM(): number {
    return this.opts.tokenPricePerM
  }

  /**
   * Estimate the cost of one anomaly range (inclusive seq span of one session).
   * `endSeq` may be -1 when unknown — the range then spans to the session tail.
   */
  estimate(sessionId: string, startSeq: number, endSeq: number): CostEstimate {
    const events = this.store.listEventsBySession(sessionId, {
      fromSeq: startSeq,
      limit: (endSeq >= startSeq ? endSeq - startSeq + 1 : 1_000_000),
    })
    let tokens = 0
    let usageMessages = 0
    let noUsageMessages = 0
    let firstTime: number | undefined
    let lastTime: number | undefined
    for (const event of events) {
      if (endSeq >= startSeq && event.seq > endSeq) break
      if (event.seq < startSeq) continue
      if (firstTime === undefined) firstTime = event.time
      lastTime = event.time
      if (event.type === 'assistant/message') {
        const usage = (event.raw as { data?: { usage?: unknown } })?.data?.usage
        const counted = usageTokens(usage)
        if (counted !== undefined) {
          tokens += counted
          usageMessages += 1
        } else {
          noUsageMessages += 1
        }
      }
    }

    let unknownTokens = 0
    let estimated = false
    if (noUsageMessages > 0 && this.opts.estimateWhenUsageMissing) {
      const sessionAverage = this.sessionAverageTokens(sessionId)
      if (sessionAverage > 0) {
        unknownTokens = sessionAverage * noUsageMessages
        estimated = true
      }
    } else if (noUsageMessages > 0) {
      estimated = true
    }

    const totalTokens = tokens + unknownTokens
    const durationMs = firstTime !== undefined && lastTime !== undefined
      ? Math.max(0, lastTime - firstTime)
      : 0
    return {
      tokens: totalTokens,
      unknownTokens,
      costCny: round2((totalTokens / 1_000_000) * this.opts.tokenPricePerM),
      durationMs,
      estimated,
    }
  }

  /** Per-message average over the whole session (usage-carrying messages only). */
  private sessionAverageTokens(sessionId: string): number {
    const events = this.store.listEventsBySession(sessionId, { limit: 1_000_000 })
    let sum = 0
    let count = 0
    for (const event of events) {
      if (event.type !== 'assistant/message') continue
      const usage = (event.raw as { data?: { usage?: unknown } })?.data?.usage
      const counted = usageTokens(usage)
      if (counted !== undefined) {
        sum += counted
        count += 1
      }
    }
    return count === 0 ? 0 : Math.round(sum / count)
  }
}

function usageTokens(usage: unknown): number | undefined {
  if (usage === null || typeof usage !== 'object') return undefined
  const u = usage as Record<string, unknown>
  const input = typeof u.input_tokens === 'number' ? u.input_tokens
    : typeof u.inputTokens === 'number' ? u.inputTokens : 0
  const output = typeof u.output_tokens === 'number' ? u.output_tokens
    : typeof u.outputTokens === 'number' ? u.outputTokens : 0
  if (input === 0 && output === 0) return undefined
  return input + output
}

function round2(value: number): number {
  return Math.round(value * 100) / 100
}
