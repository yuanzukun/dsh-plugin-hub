import assert from 'node:assert/strict'
import test from 'node:test'
import { AlertGate, actionFor, buildAlert, alertMessage, sendWebhook } from '../lib/diagnose/alerts.js'
import { DEFAULT_DIAGNOSIS_CONFIG, mergeDiagnosisConfig } from '../lib/diagnose/config.js'

const anomaly = {
  anomalyId: 'anom_s1_loop_deadlock_1_9',
  sessionId: 's1',
  type: 'loop_deadlock',
  startNodeId: 's1:1',
  endNodeId: 's1:9',
  confidence: 0.92,
  description: 'desc',
  suggestion: 'sugg',
  severity: undefined,
  createdAt: 1,
  updatedAt: 1,
}

const cost = { tokens: 12000, unknownTokens: 0, costCny: 3.36, durationMs: 120000, estimated: false }

test('AlertGate: confidence floor, cooldown, disable', () => {
  const config = mergeDiagnosisConfig({ alerts: { enabled: true, minConfidence: 0.8, cooldownMs: 1000 } })
  const gate = new AlertGate(config)
  assert.equal(gate.shouldAlert(anomaly, 100), true)
  assert.equal(gate.shouldAlert(anomaly, 500), false) // cooldown
  assert.equal(gate.shouldAlert(anomaly, 2000), true) // cooldown elapsed

  const low = { ...anomaly, confidence: 0.5 }
  assert.equal(gate.shouldAlert(low, 3000), false) // below floor

  const disabled = new AlertGate(mergeDiagnosisConfig({ alerts: { enabled: false } }))
  assert.equal(disabled.shouldAlert(anomaly, 0), false)
})

test('actionFor maps types to configured tiers', () => {
  const config = mergeDiagnosisConfig({
    actions: { onLoopDeadlock: 'auto-stop', onInvalidRetry: 'suggest-stop', onGoalDrift: 'notify' },
  })
  assert.equal(actionFor('loop_deadlock', config), 'auto-stop')
  assert.equal(actionFor('invalid_retry', config), 'suggest-stop')
  assert.equal(actionFor('goal_drift', config), 'notify')
  // defaults
  assert.equal(actionFor('loop_deadlock', DEFAULT_DIAGNOSIS_CONFIG), 'notify')
})

test('buildAlert produces stop-loss message with cost', () => {
  const alert = buildAlert(anomaly, cost, DEFAULT_DIAGNOSIS_CONFIG, 42)
  assert.equal(alert.anomalyId, anomaly.anomalyId)
  assert.equal(alert.action, 'notify')
  assert.equal(alert.createdAt, 42)
  assert.match(alert.message, /¥3\.36/)
  assert.match(alert.message, /2 分钟/)
  assert.match(alert.message, /循环死锁/)
})

test('alertMessage covers all three types', () => {
  const base = { ...anomaly, cost }
  const drift = alertMessage({ ...base, type: 'goal_drift', severity: 'severe' })
  assert.match(drift, /漂移/)
  const retry = alertMessage({ ...base, type: 'invalid_retry' })
  assert.match(retry, /无效重试/)
})

test('sendWebhook POSTs JSON to the URL', async () => {
  const calls = []
  const originalFetch = globalThis.fetch
  globalThis.fetch = async (url, init) => {
    calls.push({ url, init })
    return { ok: true } // eslint-disable-line no-undef
  }
  try {
    const alert = buildAlert(anomaly, cost, DEFAULT_DIAGNOSIS_CONFIG)
    await sendWebhook('https://example.invalid/hook', alert)
    assert.equal(calls.length, 1)
    assert.equal(calls[0].url, 'https://example.invalid/hook')
    const body = JSON.parse(calls[0].init.body)
    assert.equal(body.anomalyId, anomaly.anomalyId)
    assert.equal(body.costCny, 3.36)
    assert.equal(typeof body.text, 'string')
  } finally {
    globalThis.fetch = originalFetch
  }
})

test('sendWebhook surfaces non-ok responses', async () => {
  const originalFetch = globalThis.fetch
  globalThis.fetch = async () => ({ ok: false, status: 500 })
  try {
    const alert = buildAlert(anomaly, cost, DEFAULT_DIAGNOSIS_CONFIG)
    await assert.rejects(() => sendWebhook('https://example.invalid/hook', alert), /500/)
  } finally {
    globalThis.fetch = originalFetch
  }
})
