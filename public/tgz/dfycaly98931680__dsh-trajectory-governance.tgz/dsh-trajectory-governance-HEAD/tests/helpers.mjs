// Shared test helpers: fake Cordis context, event/session fixtures, temp DB.
import { mkdtempSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

export function fakeContext() {
  const listeners = new Map()
  return {
    listeners,
    logger: { info() {}, warn() {}, error() {} },
    on(name, fn) {
      listeners.set(name, fn)
      return () => listeners.delete(name)
    },
    effect(fn) {
      const disposer = fn()
      return () => (typeof disposer === 'function' ? disposer() : undefined)
    },
  }
}

/** Build one raw session event envelope. */
export function makeEvent(type, seq, time, data = {}, extra = {}) {
  return { type, seq, time, data, ...extra }
}

/** Build a fake live Session object (read face only). */
export function makeSession(id, header = {}) {
  return { id, seq: 0, events: [], header }
}

/** Temp dir + db path + cleanup. */
export function tempDb() {
  const dir = mkdtempSync(join(tmpdir(), 'tgd-test-'))
  return {
    dir,
    path: join(dir, 'test.db'),
    cleanup() {
      rmSync(dir, { recursive: true, force: true, maxRetries: 5, retryDelay: 60 })
    },
  }
}
