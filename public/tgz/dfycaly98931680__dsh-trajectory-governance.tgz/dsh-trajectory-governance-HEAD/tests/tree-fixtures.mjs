// Fixture helpers for tree tests: seed sessions + events straight into a store.
import { normalizeEvent } from '../lib/ingest/normalize.js'
import { makeEvent } from './helpers.mjs'

export function seedSession(store, meta, events) {
  store.upsertSession({
    sessionId: meta.sessionId,
    parentSessionId: meta.parentSessionId,
    origin: meta.origin,
    seedLength: meta.seedLength,
    createdAt: meta.createdAt ?? 0,
    subagentLabel: meta.subagentLabel,
    lastEventSeq: 0,
    status: 'active',
  })
  for (const event of events) {
    const normalized = normalizeEvent(meta.sessionId, {
      parentSessionId: meta.parentSessionId,
      origin: meta.origin,
    }, event)
    store.insertEvent(normalized, JSON.stringify(event))
  }
}

/** Walk the first-child spine of a node. */
export function chainIds(node) {
  const ids = []
  for (let n = node; n !== undefined; n = n.children[0]) ids.push(n.nodeId)
  return ids
}

export function makeToolCall(seq, time, callId, name) {
  return makeEvent('tool/call', seq, time, { turn: 1, step: 1, callId, name, arguments: '{}' })
}
