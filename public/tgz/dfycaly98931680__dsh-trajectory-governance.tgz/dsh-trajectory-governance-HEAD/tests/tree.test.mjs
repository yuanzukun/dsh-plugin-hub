import assert from 'node:assert/strict'
import test from 'node:test'
import { EventStore } from '../lib/persistence/event-store.js'
import { TrajectoryTreeBuilder } from '../lib/tree/tree-builder.js'
import {
  buildTrajectoryTree,
  getBranchTrajectory,
  getNodeById,
  toJSON,
} from '../lib/tree/queries.js'
import { makeEvent, tempDb } from './helpers.mjs'
import { chainIds, makeToolCall, seedSession } from './tree-fixtures.mjs'

test('linear chain: same-session events chain by seq with correct parents', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('user/message', 0, 100, { content: [], source: { kind: 'user' } }),
      makeEvent('turn/start', 1, 101, { turn: 1 }),
      makeToolCall(2, 102, 'c1', 'read'),
      makeEvent('tool/result', 3, 103, { turn: 1, step: 1, message: {} }),
      makeEvent('turn/end', 4, 104, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const tree = buildTrajectoryTree(store, 's1')
    assert.equal(tree.nodeId, 's1:0')
    assert.deepEqual(chainIds(tree), ['s1:0', 's1:1', 's1:2', 's1:3', 's1:4'])
    assert.equal(tree.children[0].parentNodeId, 's1:0')
    assert.equal(tree.children[0].branch.branchType, 'main')
    store.close()
  } finally {
    t.cleanup()
  }
})

test('subagent child attaches under the parent subagent tool/call node', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('user/message', 0, 100, { content: [], source: { kind: 'user' } }),
      makeEvent('turn/start', 1, 101, { turn: 1 }),
      makeToolCall(2, 102, 'sub-1', 'subagent'),
      makeEvent('tool/result', 3, 103, { turn: 1, step: 1, message: {} }),
      makeEvent('turn/end', 4, 104, { turn: 1, reason: { kind: 'completed' } }),
    ])
    seedSession(store, {
      sessionId: 'child', parentSessionId: 's1', origin: 'subagent', seedLength: 2, createdAt: 102, subagentLabel: 'helper',
    }, [
      makeEvent('session/end-seed', 0, 105),
      makeEvent('turn/start', 1, 106, { turn: 1 }),
      makeToolCall(2, 107, 'c2', 'read'),
      makeEvent('turn/end', 3, 108, { turn: 1, reason: { kind: 'completed' } }),
    ])

    const tree = buildTrajectoryTree(store, 's1')
    const anchor = tree.children[0].children[0] // s1:2 tool/call 'subagent'
    assert.equal(anchor.eventType, 'tool/call')
    assert.equal(anchor.children.length, 2) // next-in-chain + child subtree
    const subtree = anchor.children[1]
    assert.equal(subtree.nodeId, 'child:0')
    assert.equal(subtree.parentNodeId, 's1:2')
    assert.equal(subtree.branch.branchType, 'subagent')
    assert.equal(subtree.branch.parentBranchId, 's1')
    assert.equal(subtree.branch.label, 'helper')
    assert.deepEqual(chainIds(subtree), ['child:0', 'child:1', 'child:2', 'child:3'])
    store.close()
  } finally {
    t.cleanup()
  }
})

test('fork child attaches at the seedLength boundary node', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('user/message', 0, 100, { content: [], source: { kind: 'user' } }),
      makeEvent('turn/start', 1, 101, { turn: 1 }),
      makeToolCall(2, 102, 'c1', 'read'),
      makeEvent('turn/end', 3, 103, { turn: 1, reason: { kind: 'completed' } }),
      makeEvent('turn/start', 4, 104, { turn: 2 }),
    ])
    // fork after parent seq 2 → seedLength = 3
    seedSession(store, { sessionId: 'fork1', parentSessionId: 's1', seedLength: 3, createdAt: 103 }, [
      makeEvent('session/end-seed', 0, 110),
      makeEvent('turn/start', 1, 111, { turn: 1 }),
      makeEvent('turn/end', 2, 112, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const tree = buildTrajectoryTree(store, 's1')
    const boundary = tree.children[0].children[0] // s1:2
    assert.equal(boundary.children.length, 2) // s1:3 + fork subtree
    const subtree = boundary.children[1]
    assert.equal(subtree.nodeId, 'fork1:0')
    assert.equal(subtree.parentNodeId, 's1:2')
    assert.equal(subtree.branch.branchType, 'fork')
    store.close()
  } finally {
    t.cleanup()
  }
})

test('nested subagents attach recursively (child of child)', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('turn/start', 0, 100, { turn: 1 }),
      makeToolCall(1, 101, 'sub-1', 'subagent'),
      makeEvent('turn/end', 2, 102, { turn: 1, reason: { kind: 'completed' } }),
    ])
    seedSession(store, { sessionId: 'child', parentSessionId: 's1', origin: 'subagent', seedLength: 1, createdAt: 101 }, [
      makeEvent('session/end-seed', 0, 103),
      makeToolCall(1, 104, 'sub-2', 'subagent'),
      makeEvent('turn/end', 2, 105, { turn: 1, reason: { kind: 'completed' } }),
    ])
    seedSession(store, { sessionId: 'gc', parentSessionId: 'child', origin: 'subagent', seedLength: 1, createdAt: 104 }, [
      makeEvent('session/end-seed', 0, 106),
      makeEvent('turn/start', 1, 107, { turn: 1 }),
      makeEvent('turn/end', 2, 108, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const tree = buildTrajectoryTree(store, 's1')
    const level1 = tree.children[0].children[1] // child subtree root under s1:1
    assert.equal(level1.nodeId, 'child:0')
    const level1Anchor = level1.children[0] // child:1 tool/call subagent
    assert.equal(level1Anchor.eventType, 'tool/call')
    assert.equal(level1Anchor.children[1].nodeId, 'gc:0')
    assert.equal(level1Anchor.children[1].branch.branchType, 'subagent')
    store.close()
  } finally {
    t.cleanup()
  }
})

test('time jitter is tolerated: chain stays by seq, jitter counted', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('turn/start', 0, 100, { turn: 1 }),
      makeEvent('tool/call', 1, 150, { turn: 1, step: 1, callId: 'c1', name: 'a', arguments: '{}' }),
      makeEvent('tool/result', 2, 120, { turn: 1, step: 1, message: {} }), // time regresses
      makeEvent('turn/end', 3, 200, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const builder = new TrajectoryTreeBuilder(store)
    const tree = builder.build('s1')
    assert.deepEqual(chainIds(tree), ['s1:0', 's1:1', 's1:2', 's1:3'])
    assert.equal(builder.stats.jitterCount, 1)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('cycle guard: malformed lineage never loops forever', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 'a', parentSessionId: 'b', createdAt: 0 }, [
      makeEvent('turn/start', 0, 100, { turn: 1 }),
      makeEvent('turn/end', 1, 101, { turn: 1, reason: { kind: 'completed' } }),
    ])
    seedSession(store, { sessionId: 'b', parentSessionId: 'a', createdAt: 1 }, [
      makeEvent('turn/start', 0, 200, { turn: 1 }),
      makeEvent('turn/end', 1, 201, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const builder = new TrajectoryTreeBuilder(store)
    const tree = builder.build('a')
    assert.equal(tree.nodeId, 'a:0')
    assert.equal(builder.stats.skippedCycles, 1)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('query facade: getNodeById and getBranchTrajectory', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('turn/start', 0, 100, { turn: 1 }),
      makeToolCall(1, 101, 'c1', 'read'),
      makeEvent('turn/end', 2, 102, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const node = getNodeById(store, 's1:1')
    assert.equal(node.eventType, 'tool/call')
    assert.equal(node.data.name, 'read')
    assert.equal(getNodeById(store, 's1:99'), undefined)
    assert.equal(getNodeById(store, 'not-a-node'), undefined)
    assert.equal(getNodeById(store, ':5'), undefined)

    const branch = getBranchTrajectory(store, 's1')
    assert.equal(branch.length, 3)
    assert.deepEqual(branch.map(n => n.seq), [0, 1, 2])
    store.close()
  } finally {
    t.cleanup()
  }
})

test('toJSON export includes structure, raw, and nested children', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('turn/start', 0, 100, { turn: 1 }),
      makeToolCall(1, 101, 'c1', 'read'),
      makeEvent('turn/end', 2, 102, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const tree = buildTrajectoryTree(store, 's1')
    const json = toJSON(tree)
    assert.equal(json.nodeId, 's1:0')
    assert.equal(json.children.length, 1)
    assert.equal(json.children[0].raw.type, 'tool/call')
    const stripped = toJSON(tree, { stripRaw: true })
    assert.equal('raw' in stripped, false)
    store.close()
  } finally {
    t.cleanup()
  }
})
