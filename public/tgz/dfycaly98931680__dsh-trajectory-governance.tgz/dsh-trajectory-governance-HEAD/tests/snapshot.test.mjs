import assert from 'node:assert/strict'
import test from 'node:test'
import { EventStore } from '../lib/persistence/event-store.js'
import { SnapshotService } from '../lib/snapshot/snapshot-service.js'
import { deleteBranch, listBranches } from '../lib/snapshot/branch-manager.js'
import { makeEvent, tempDb } from './helpers.mjs'
import { seedSession } from './tree-fixtures.mjs'

const NOW = 1_000_000_000_000

function seededStore(t) {
  const store = EventStore.open(t.path)
  seedSession(store, { sessionId: 's1', createdAt: 0 }, [
    makeEvent('user/message', 0, 100, { content: [], source: { kind: 'user' } }),
    makeEvent('turn/start', 1, 101, { turn: 1 }),
    makeEvent('tool/call', 2, 102, { turn: 1, step: 1, callId: 'c1', name: 'read', arguments: '{}' }),
    makeEvent('tool/result', 3, 103, { turn: 1, step: 1, message: {} }),
    makeEvent('turn/end', 4, 104, { turn: 1, reason: { kind: 'completed' } }),
  ])
  return store
}

test('createSnapshot stores only the index (nodeId + hash + branchId)', () => {
  const t = tempDb()
  try {
    const store = seededStore(t)
    const svc = new SnapshotService(store)
    const snap = svc.create('s1', { nodeId: 's1:2', label: 'before-read', createdAt: NOW })
    assert.equal(snap.nodeId, 's1:2')
    assert.equal(snap.seq, 2)
    assert.equal(snap.branchId, 's1')
    assert.equal(snap.sessionId, 's1')
    assert.match(snap.contextHash, /^[0-9a-f]{64}$/)
    assert.equal(snap.label, 'before-read')

    // idempotent: same node → same snapshot id, still one row
    const again = svc.create('s1', { nodeId: 's1:2' })
    assert.equal(again.snapshotId, snap.snapshotId)
    assert.equal(store.countSnapshots(), 1)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('createSnapshot without nodeId anchors at the branch tail', () => {
  const t = tempDb()
  try {
    const store = seededStore(t)
    const svc = new SnapshotService(store)
    const snap = svc.create('s1')
    assert.equal(snap.nodeId, 's1:4')
    assert.equal(snap.seq, 4)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('getSnapshotContext rebuilds the prefix and detects staleness', () => {
  const t = tempDb()
  try {
    const store = seededStore(t)
    const svc = new SnapshotService(store)
    const snap = svc.create('s1', { nodeId: 's1:2' })
    const ctx = svc.context(snap.snapshotId)
    assert.equal(ctx.snapshot.snapshotId, snap.snapshotId)
    assert.deepEqual(ctx.events.map(e => e.seq), [0, 1, 2])
    assert.equal(ctx.hashMatch, true)

    // events appended AFTER the anchor do not change the captured prefix
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('turn/start', 5, 200, { turn: 2 }),
      makeEvent('turn/end', 6, 201, { turn: 2, reason: { kind: 'completed' } }),
    ])
    const ctx2 = svc.context(snap.snapshotId)
    assert.equal(ctx2.hashMatch, true)
    assert.deepEqual(ctx2.events.map(e => e.seq), [0, 1, 2])
    store.close()
  } finally {
    t.cleanup()
  }
})

test('touch updates LRU bookkeeping', () => {
  const t = tempDb()
  try {
    const store = seededStore(t)
    const svc = new SnapshotService(store)
    const snap = svc.create('s1', { nodeId: 's1:2', lastAccessedAt: NOW })
    assert.equal(snap.accessCount, 0)
    assert.equal(svc.touch(snap.snapshotId), true)
    assert.equal(svc.touch(snap.snapshotId), true)
    const meta = svc.list()[0]
    assert.equal(meta.accessCount, 2)
    assert.equal(svc.touch('missing'), false)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('prune: TTL evicts stale snapshots but protects the newest keepNewest', () => {
  const t = tempDb()
  try {
    const store = seededStore(t)
    const svc = new SnapshotService(store)
    // A,B,C old; D new
    svc.create('s1', { nodeId: 's1:0', createdAt: NOW, lastAccessedAt: NOW - 100_000 })
    svc.create('s1', { nodeId: 's1:1', createdAt: NOW, lastAccessedAt: NOW - 100_000 })
    svc.create('s1', { nodeId: 's1:2', createdAt: NOW, lastAccessedAt: NOW - 100_000 })
    svc.create('s1', { nodeId: 's1:3', createdAt: NOW, lastAccessedAt: NOW })
    assert.equal(store.countSnapshots(), 4)

    const result = svc.prune({ ttlMs: 50_000, keepNewest: 2, maxSnapshots: 100 })
    // C is protected by keepNewest=2; A and B are evicted
    assert.equal(result.removed, 2)
    assert.equal(result.kept, 2)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('prune: LRU cap evicts oldest-accessed above maxSnapshots', () => {
  const t = tempDb()
  try {
    const store = seededStore(t)
    const svc = new SnapshotService(store)
    svc.create('s1', { nodeId: 's1:0', lastAccessedAt: NOW - 300 })
    svc.create('s1', { nodeId: 's1:1', lastAccessedAt: NOW - 200 })
    svc.create('s1', { nodeId: 's1:2', lastAccessedAt: NOW - 100 })
    svc.create('s1', { nodeId: 's1:3', lastAccessedAt: NOW })
    const result = svc.prune({ maxSnapshots: 2, ttlMs: 0 })
    assert.equal(result.removed, 2)
    assert.equal(store.countSnapshots(), 2)
    // the two evicted are the oldest-accessed (seq 0 and 1); 2 and 3 remain
    assert.deepEqual(new Set(store.listSnapshots().map(s => s.seq)), new Set([2, 3]))
    store.close()
  } finally {
    t.cleanup()
  }
})

test('deleteSnapshot removes one snapshot', () => {
  const t = tempDb()
  try {
    const store = seededStore(t)
    const svc = new SnapshotService(store)
    const snap = svc.create('s1', { nodeId: 's1:2' })
    assert.equal(svc.remove(snap.snapshotId), true)
    assert.equal(store.countSnapshots(), 0)
    assert.equal(svc.remove('missing'), false)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('listBranches walks descendants; deleteBranch cleans observation store only', () => {
  const t = tempDb()
  try {
    const store = seededStore(t)
    seedSession(store, {
      sessionId: 'child', parentSessionId: 's1', origin: 'subagent', seedLength: 2, createdAt: 1, subagentLabel: 'helper',
    }, [
      makeEvent('session/end-seed', 0, 110),
      makeEvent('turn/start', 1, 111, { turn: 1 }),
      makeEvent('turn/end', 2, 112, { turn: 1, reason: { kind: 'completed' } }),
    ])
    seedSession(store, { sessionId: 'gc', parentSessionId: 'child', seedLength: 1, createdAt: 2 }, [
      makeEvent('session/end-seed', 0, 120),
      makeEvent('turn/end', 1, 121, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const svc = new SnapshotService(store)
    svc.create('child', { nodeId: 'child:1', label: 'checkpoint' })

    const branches = listBranches(store, 's1')
    assert.deepEqual(branches.map(b => b.sessionId), ['s1', 'child', 'gc'])
    assert.equal(branches[1].branchType, 'subagent')
    assert.equal(branches[1].label, 'helper')
    assert.equal(branches[2].branchType, 'fork')
    assert.equal(branches[2].eventCount, 2)

    // delete the 'child' branch → removes child + grandchild + its snapshot; root stays
    const result = deleteBranch(store, 'child')
    assert.equal(result.removedSessions, 2)
    assert.equal(result.removedEvents, 5) // 3 child + 2 gc
    assert.equal(result.removedSnapshots, 1)
    assert.equal(store.findSession('s1').sessionId, 's1')
    assert.equal(store.countEvents(), 5) // root's 5 events remain
    store.close()
  } finally {
    t.cleanup()
  }
})
