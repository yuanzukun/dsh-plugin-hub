import assert from 'node:assert/strict'
import test from 'node:test'
import { EventStore } from '../lib/persistence/event-store.js'
import { getBranchTrajectory, buildTrajectoryTree } from '../lib/tree/queries.js'
import {
  detectGoalDrift,
  detectInvalidRetry,
  detectLoopDeadlock,
  baselineText,
} from '../lib/diagnose/strategies.js'
import { DiagnosisEngine, anomalyIdFor } from '../lib/diagnose/engine.js'
import { mergeDiagnosisConfig, DEFAULT_DIAGNOSIS_CONFIG } from '../lib/diagnose/config.js'
import { mountAnomalies, coveredBy } from '../lib/diagnose/mount.js'
import {
  LexicalEmbedder,
  argumentsSimilarity,
  textSimilarity,
  toolCallSimilarity,
  vectorCosine,
} from '../lib/diagnose/similarity.js'
import { makeEvent, tempDb } from './helpers.mjs'
import { seedSession } from './tree-fixtures.mjs'
import { assistantMsg, retryCycle, toolCall, toolResult, turnEnd, turnStart, userMsg } from './diagnose-fixtures.mjs'

function chainOf(t, sessionId, events) {
  const store = EventStore.open(t.path)
  seedSession(store, { sessionId, createdAt: 0 }, events)
  const chain = getBranchTrajectory(store, sessionId)
  store.close()
  return { chain }
}

// ---- similarity primitives ----

test('similarity: text, arguments (key-order invariant), tool calls, vectors', async () => {
  assert.equal(textSimilarity('refactor to typescript', 'refactor to typescript'), 1)
  assert.ok(textSimilarity('refactor project to typescript', 'cooking pasta recipes') < 0.5)
  assert.equal(argumentsSimilarity('{"file":"a.ts","content":"x"}', '{"content":"x","file":"a.ts"}'), 1)
  assert.equal(toolCallSimilarity('edit', '{"file":"a.ts"}', 'edit', '{"file":"a.ts"}'), 1)
  assert.ok(toolCallSimilarity('edit', '{"file":"a.ts"}', 'read', '{"file":"a.ts"}') < 0.6)
  const embedder = new LexicalEmbedder()
  const v1 = await embedder.embed('refactor the whole project to typescript')
  const v2 = await embedder.embed('refactor the whole project to typescript')
  const v3 = await embedder.embed('cooking pasta with fresh basil')
  assert.equal(vectorCosine(v1, v2), 1)
  assert.ok(vectorCosine(v1, v3) < 0.5)
})

// ---- Strategy A ----

test('strategy A: identical calls with identical results flag loop deadlock', () => {
  const t = tempDb()
  try {
    const events = [turnStart(0, 0, 1)]
    for (let i = 0; i < 5; i += 1) {
      events.push(toolCall(1 + i * 2, 10 + i * 2, `c${i}`, 'edit', '{"file":"a.ts","content":"add const x = 1"}'))
      events.push(toolResult(2 + i * 2, 11 + i * 2, `c${i}`, { role: 'tool', content: [{ type: 'text', text: 'File updated.' }] }))
    }
    events.push(turnEnd(12, 30, 1, { kind: 'completed' }))
    const { chain } = chainOf(t, 's1', events)
    const anomalies = detectLoopDeadlock(chain, DEFAULT_DIAGNOSIS_CONFIG)
    assert.equal(anomalies.length, 1)
    assert.equal(anomalies[0].type, 'loop_deadlock')
    assert.equal(anomalies[0].startNodeId, 's1:1')
    assert.equal(anomalies[0].endNodeId, 's1:9')
    assert.ok(anomalies[0].confidence >= 0.8)
  } finally {
    t.cleanup()
  }
})

test('strategy A: iterative refinement (changing args/results) does not alarm', () => {
  const t = tempDb()
  try {
    const contents = ['add auth flow', 'fix db connection', 'refactor ui grid', 'add cache layer', 'migrate to v2']
    const outcomes = ['auth flow done', 'db connection fixed', 'ui grid refactored', 'cache layer added', 'migrated to v2']
    const events = [turnStart(0, 0, 1)]
    for (let i = 0; i < 5; i += 1) {
      events.push(toolCall(1 + i * 2, 10 + i * 2, `c${i}`, 'edit', `{"file":"a.ts","content":"${contents[i]}"}`))
      events.push(toolResult(2 + i * 2, 11 + i * 2, `c${i}`, { role: 'tool', content: [{ type: 'text', text: outcomes[i] }] }))
    }
    events.push(turnEnd(12, 30, 1, { kind: 'completed' }))
    const { chain } = chainOf(t, 's1', events)
    assert.deepEqual(detectLoopDeadlock(chain, DEFAULT_DIAGNOSIS_CONFIG), [])
  } finally {
    t.cleanup()
  }
})

// ---- Strategy B ----

test('strategy B: same-class errors with unchanged retry action flag invalid retry', () => {
  const t = tempDb()
  try {
    const { chain } = chainOf(t, 's1', retryCycle(3, 1))
    const anomalies = detectInvalidRetry(chain, DEFAULT_DIAGNOSIS_CONFIG)
    assert.equal(anomalies.length, 1)
    assert.equal(anomalies[0].type, 'invalid_retry')
    assert.ok(anomalies[0].confidence >= 0.8)
  } finally {
    t.cleanup()
  }
})

test('strategy B: same errors but adjusted action does not alarm', () => {
  const t = tempDb()
  try {
    const events = []
    let seq = 1
    for (let i = 0; i < 3; i += 1) {
      events.push(toolCall(seq, seq * 10, `c${i}`, 'invoke', `{"param":"value${i}"}`)); seq += 1
      events.push(toolResult(seq, seq * 10, `c${i}`, { role: 'tool', content: [] }, { name: 'API', code: 'RATE_LIMIT' })); seq += 1
      events.push(turnEnd(seq, seq * 10, i + 1, { kind: 'error', error: { code: 'RATE_LIMIT', message: 'rate limited' } })); seq += 1
    }
    const { chain } = chainOf(t, 's1', events)
    assert.deepEqual(detectInvalidRetry(chain, DEFAULT_DIAGNOSIS_CONFIG), [])
  } finally {
    t.cleanup()
  }
})

test('strategy B: different error classes do not alarm', () => {
  const t = tempDb()
  try {
    // rotating error codes → runs of length 1, never reaching minRounds
    const events = []
    let seq = 1
    for (let i = 0; i < 3; i += 1) {
      events.push(toolCall(seq, seq * 10, `c${i}`, 'invoke', '{"p":"x"}')); seq += 1
      events.push(toolResult(seq, seq * 10, `c${i}`, { role: 'tool', content: [] })); seq += 1
      events.push(turnEnd(seq, seq * 10, i + 1, { kind: 'error', error: { code: `E${i}`, message: `m${i}` } })); seq += 1
    }
    const { chain } = chainOf(t, 's1', events)
    assert.deepEqual(detectInvalidRetry(chain, DEFAULT_DIAGNOSIS_CONFIG), [])
  } finally {
    t.cleanup()
  }
})

// ---- Strategy C ----

const DRIFT_CONFIG = mergeDiagnosisConfig({
  strategyC: {
    enabled: true,
    sampleEveryNRounds: 1,
    consecutiveSamples: 2,
    similarityThreshold: 0.5,
    severeBelow: 0.3,
    moderateBelow: 0.45,
  },
})

test('strategy C: intent drifting away from the baseline flags goal drift', async () => {
  const t = tempDb()
  try {
    const events = [
      userMsg(0, 0, '重构整个项目为 TypeScript 并补充单元测试'),
      turnStart(1, 1, 1),
      assistantMsg(2, 2, '我正在重构项目为 TypeScript', 1),
      turnEnd(3, 3, 1, { kind: 'completed' }),
      turnStart(4, 4, 2),
      assistantMsg(5, 5, '我在讨论如何做番茄意面', 2),
      turnEnd(6, 6, 2, { kind: 'completed' }),
      turnStart(7, 7, 3),
      assistantMsg(8, 8, '番茄意面需要新鲜罗勒和帕玛森', 3),
      turnEnd(9, 9, 3, { kind: 'completed' }),
    ]
    const { chain } = chainOf(t, 's1', events)
    const anomalies = await detectGoalDrift(chain, DRIFT_CONFIG)
    assert.equal(anomalies.length, 1)
    assert.equal(anomalies[0].type, 'goal_drift')
    assert.equal(anomalies[0].startNodeId, 's1:6') // first low-similarity sample
    assert.equal(anomalies[0].endNodeId, 's1:9')   // second consecutive low sample
    assert.ok(['mild', 'moderate', 'severe'].includes(anomalies[0].severity))
  } finally {
    t.cleanup()
  }
})

test('strategy C: on-goal conversation does not alarm', async () => {
  const t = tempDb()
  try {
    const events = [
      userMsg(0, 0, '重构整个项目为 TypeScript 并补充单元测试'),
      turnStart(1, 1, 1),
      assistantMsg(2, 2, '正在迁移模块到 TypeScript', 1),
      turnEnd(3, 3, 1, { kind: 'completed' }),
      turnStart(4, 4, 2),
      assistantMsg(5, 5, '为重构后的模块补充单元测试', 2),
      turnEnd(6, 6, 2, { kind: 'completed' }),
      turnStart(7, 7, 3),
      assistantMsg(8, 8, '继续 TypeScript 迁移并运行测试', 3),
      turnEnd(9, 9, 3, { kind: 'completed' }),
    ]
    const { chain } = chainOf(t, 's1', events)
    assert.deepEqual(await detectGoalDrift(chain, DRIFT_CONFIG), [])
    assert.equal(baselineText(chain), '重构整个项目为 TypeScript 并补充单元测试')
  } finally {
    t.cleanup()
  }
})

// ---- engine + mount ----

test('engine: incremental analysis, dedupe, watermark', async () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const events = [turnStart(0, 0, 1)]
    for (let i = 0; i < 5; i += 1) {
      events.push(toolCall(1 + i * 2, 10 + i * 2, `c${i}`, 'edit', '{"file":"a.ts","content":"same"}'))
      events.push(toolResult(2 + i * 2, 11 + i * 2, `c${i}`, { role: 'tool', content: [{ type: 'text', text: 'same result' }] }))
    }
    events.push(turnEnd(12, 30, 1, { kind: 'completed' }))
    seedSession(store, { sessionId: 's1', createdAt: 0 }, events)

    const engine = new DiagnosisEngine(store)
    const first = await engine.analyzeSession('s1')
    assert.equal(first.newAnomalies, 1)
    assert.equal(first.totalAnomalies, 1)

    // no new events → no new anomalies
    const second = await engine.analyzeSession('s1')
    assert.equal(second.newAnomalies, 0)

    // append 5 more identical calls → a new full window flags a new anomaly
    const more = []
    for (let i = 5; i < 10; i += 1) {
      more.push(toolCall(13 + (i - 5) * 2, 40 + (i - 5) * 2, `c${i}`, 'edit', '{"file":"a.ts","content":"same"}'))
      more.push(toolResult(14 + (i - 5) * 2, 41 + (i - 5) * 2, `c${i}`, { role: 'tool', content: [{ type: 'text', text: 'same result' }] }))
    }
    more.push(turnEnd(23, 60, 2, { kind: 'completed' }))
    seedSession(store, { sessionId: 's1', createdAt: 0 }, more)
    const third = await engine.analyzeSession('s1')
    assert.equal(third.newAnomalies, 1)
    assert.equal(third.totalAnomalies, 2)

    // dirty-session scan
    const dirty = await engine.analyzeDirtySessions()
    assert.equal(dirty.sessions, 0)
    assert.equal(dirty.newAnomalies, 0)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('engine: disabled strategies are skipped; anomaly ids are deterministic', async () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      turnStart(0, 0, 1),
      toolCall(1, 10, 'c0', 'edit', '{"file":"a.ts","content":"same"}'),
      toolResult(2, 11, 'c0', { role: 'tool', content: [{ type: 'text', text: 'same' }] }),
      turnEnd(3, 20, 1, { kind: 'completed' }),
    ])
    const engine = new DiagnosisEngine(store, mergeDiagnosisConfig({ strategyA: { enabled: false } }))
    const result = await engine.analyzeSession('s1')
    assert.deepEqual(result.ranStrategies, ['invalid_retry', 'goal_drift'])
    assert.equal(result.newAnomalies, 0)
    const id1 = anomalyIdFor('s1', { type: 'loop_deadlock', startNodeId: 's1:1', endNodeId: 's1:9', confidence: 1, description: 'x' })
    const id2 = anomalyIdFor('s1', { type: 'loop_deadlock', startNodeId: 's1:1', endNodeId: 's1:9', confidence: 1, description: 'y' })
    assert.equal(id1, id2)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('mount: anomalies attach to the trigger node; coveredBy checks ranges', async () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const events = [turnStart(0, 0, 1)]
    for (let i = 0; i < 5; i += 1) {
      events.push(toolCall(1 + i * 2, 10 + i * 2, `c${i}`, 'edit', '{"file":"a.ts","content":"same"}'))
      events.push(toolResult(2 + i * 2, 11 + i * 2, `c${i}`, { role: 'tool', content: [{ type: 'text', text: 'same result' }] }))
    }
    events.push(turnEnd(12, 30, 1, { kind: 'completed' }))
    seedSession(store, { sessionId: 's1', createdAt: 0 }, events)
    await new DiagnosisEngine(store).analyzeSession('s1')

    const tree = buildTrajectoryTree(store, 's1')
    const mounted = mountAnomalies(store, tree)
    assert.equal(mounted, 1)
    // trigger node is the first tool call of the flagged window (s1:1)
    assert.equal(tree.children[0].anomalyInfo.type, 'loop_deadlock')
    const anomaly = store.listAnomalies({ sessionId: 's1' })[0]
    assert.equal(coveredBy(anomaly, 's1:5'), true)
    assert.equal(coveredBy(anomaly, 's1:12'), false)
    store.close()
  } finally {
    t.cleanup()
  }
})
