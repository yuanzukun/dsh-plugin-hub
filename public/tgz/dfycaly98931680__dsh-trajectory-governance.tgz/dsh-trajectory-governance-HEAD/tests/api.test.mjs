import assert from 'node:assert/strict'
import test from 'node:test'
import { EventStore } from '../lib/persistence/event-store.js'
import { DiagnosisEngine } from '../lib/diagnose/engine.js'
import { createTrajectoryApi, installTrajectoryApi, API_BASE } from '../lib/api/http.js'
import { seedSession } from './tree-fixtures.mjs'
import { makeEvent, tempDb } from './helpers.mjs'
import { toolCall, toolResult, turnEnd, turnStart, userMsg } from './diagnose-fixtures.mjs'

function deadlockStore(t) {
  const store = EventStore.open(t.path)
  const events = [userMsg(0, 0, '重构项目为 TypeScript', 'user'), turnStart(1, 1, 1)]
  for (let i = 0; i < 5; i += 1) {
    events.push(toolCall(2 + i * 2, 10 + i * 2, `c${i}`, 'edit', '{"file":"a.ts","content":"same"}'))
    events.push(toolResult(3 + i * 2, 11 + i * 2, `c${i}`, { role: 'tool', content: [{ type: 'text', text: 'same result' }] }))
  }
  events.push(turnEnd(13, 30, 1, { kind: 'completed' }))
  seedSession(store, { sessionId: 's1', createdAt: 0 }, events)
  return store
}

function makeApi(store) {
  return createTrajectoryApi(store, new DiagnosisEngine(store))
}

test('API: sessions list carries counts; analyze finds the deadlock', async () => {
  const t = tempDb()
  try {
    const store = deadlockStore(t)
    const api = makeApi(store)

    let res = await api.handle({ method: 'GET', url: `${API_BASE}/sessions` })
    assert.equal(res.status, 200)
    const { sessions } = res.json
    assert.equal(sessions.length, 1)
    assert.equal(sessions[0].sessionId, 's1')
    assert.equal(sessions[0].eventCount, 13)
    assert.equal(sessions[0].anomalyCount, 0)

    res = await api.handle({ method: 'POST', url: `${API_BASE}/analyze`, body: { sessionId: 's1' } })
    assert.equal(res.status, 200)
    assert.equal(res.json.result.newAnomalies, 1)

    res = await api.handle({ method: 'GET', url: `${API_BASE}/anomalies?sessionId=s1` })
    assert.equal(res.json.anomalies.length, 1)
    assert.equal(res.json.anomalies[0].type, 'loop_deadlock')
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: sessions carry wastedTokens; /alerts returns alerts with cost', async () => {
  const t = tempDb()
  try {
    const store = deadlockStore(t)
    const api = makeApi(store)
    await api.handle({ method: 'POST', url: `${API_BASE}/analyze`, body: { sessionId: 's1' } })

    const res = await api.handle({ method: 'GET', url: `${API_BASE}/sessions` })
    assert.equal(res.status, 200)
    assert.equal(typeof res.json.sessions[0].wastedTokens, 'number')

    const alertsRes = await api.handle({ method: 'GET', url: `${API_BASE}/alerts?sessionId=s1&since=0` })
    assert.equal(alertsRes.status, 200)
    assert.equal(alertsRes.json.alerts.length, 1)
    const alert = alertsRes.json.alerts[0]
    assert.equal(alert.anomalyId, 'anom_s1_loop_deadlock_2_10')
    assert.equal(typeof alert.cost.costCny, 'number')
    assert.equal(typeof alert.updatedAt, 'number')

    // incremental: since=now → nothing new
    const later = await api.handle({ method: 'GET', url: `${API_BASE}/alerts?since=${alert.updatedAt}` })
    assert.equal(later.json.alerts.length, 0)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: /actions/interrupt calls the official cancel capability', async () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const interrupted = []
    const engine = new DiagnosisEngine(store)
    const api = createTrajectoryApi(store, engine, {
      interrupt: (sessionId) => {
        interrupted.push(sessionId)
        return { ok: true }
      },
    })

    let res = await api.handle({ method: 'POST', url: `${API_BASE}/actions/interrupt`, body: { sessionId: 's1' } })
    assert.equal(res.status, 200)
    assert.equal(res.json.ok, true)
    assert.deepEqual(interrupted, ['s1'])

    // missing sessionId
    res = await api.handle({ method: 'POST', url: `${API_BASE}/actions/interrupt`, body: {} })
    assert.equal(res.status, 400)

    // no capability → 501
    const bare = createTrajectoryApi(store, engine)
    res = await bare.handle({ method: 'POST', url: `${API_BASE}/actions/interrupt`, body: { sessionId: 's1' } })
    assert.equal(res.status, 501)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: /actions/rename mirrors locally and calls official rename', async () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const engine = new DiagnosisEngine(store)
    const renamed = []
    const api = createTrajectoryApi(store, engine, {
      rename: (sessionId, title) => {
        renamed.push({ sessionId, title })
        return { ok: true }
      },
    })

    // session row must exist for the mirror to be visible in listSessions
    store.upsertSession({ sessionId: 's1', createdAt: 0, lastEventSeq: 0, status: 'active' })

    let res = await api.handle({ method: 'POST', url: `${API_BASE}/actions/rename`, body: { sessionId: 's1', title: '我的重构任务' } })
    assert.equal(res.status, 200)
    assert.equal(res.json.ok, true)
    assert.equal(res.json.official, true)
    assert.deepEqual(renamed, [{ sessionId: 's1', title: '我的重构任务' }])

    // mirrored title is in the sessions list
    res = await api.handle({ method: 'GET', url: `${API_BASE}/sessions` })
    assert.equal(res.json.sessions[0].title, '我的重构任务')

    // empty title → 400
    res = await api.handle({ method: 'POST', url: `${API_BASE}/actions/rename`, body: { sessionId: 's1', title: '   ' } })
    assert.equal(res.status, 400)

    // no official capability → local mirror only, official:false
    const bare = createTrajectoryApi(store, engine)
    res = await bare.handle({ method: 'POST', url: `${API_BASE}/actions/rename`, body: { sessionId: 's1', title: '本地命名' } })
    assert.equal(res.status, 200)
    assert.equal(res.json.ok, true)
    assert.equal(res.json.official, false)
    res = await api.handle({ method: 'GET', url: `${API_BASE}/sessions` })
    assert.equal(res.json.sessions[0].title, '本地命名')
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: tree is mounted with anomalies; node lookup works', async () => {
  const t = tempDb()
  try {
    const store = deadlockStore(t)
    const api = makeApi(store)
    await api.handle({ method: 'POST', url: `${API_BASE}/analyze`, body: { sessionId: 's1' } })

    const res = await api.handle({ method: 'GET', url: `${API_BASE}/tree?sessionId=s1` })
    assert.equal(res.status, 200)
    const tree = res.json.tree
    assert.equal(tree.nodeId, 's1:0')
    // the first tool call (s1:2) carries the mounted anomaly
    assert.equal(tree.children[0].children[0].anomalyInfo.type, 'loop_deadlock')

    const nodeRes = await api.handle({ method: 'GET', url: `${API_BASE}/node?nodeId=s1:2` })
    assert.equal(nodeRes.status, 200)
    assert.equal(nodeRes.json.node.eventType, 'tool/call')
    assert.equal(nodeRes.json.node.raw.data.name, 'edit')

    const missing = await api.handle({ method: 'GET', url: `${API_BASE}/node?nodeId=s1:999` })
    assert.equal(missing.status, 404)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: sessions backfill official titles that predate the plugin', async () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const engine = new DiagnosisEngine(store)
    // no title in OUR store — the official log has one (predates us)
    store.upsertSession({ sessionId: 's1', createdAt: 0, lastEventSeq: 0, status: 'active' })
    const api = createTrajectoryApi(store, engine, {
      readTitle: async (sessionId) => {
        assert.equal(sessionId, 's1')
        return 'DeepSeek-Harness Agent轨迹治理'
      },
    })

    let res = await api.handle({ method: 'GET', url: `${API_BASE}/sessions` })
    assert.equal(res.status, 200)
    assert.equal(res.json.sessions[0].title, 'DeepSeek-Harness Agent轨迹治理')
    // backfilled into the store, so a second read hits the mirror (deps not called again)
    assert.equal(store.findSession('s1').autoTitle, 'DeepSeek-Harness Agent轨迹治理')

    // readTitle failure → no crash, title stays from the earlier backfill
    const failing = createTrajectoryApi(store, engine, {
      readTitle: async () => { throw new Error('query down') },
    })
    res = await failing.handle({ method: 'GET', url: `${API_BASE}/sessions` })
    assert.equal(res.status, 200)
    assert.equal(res.json.sessions[0].title, 'DeepSeek-Harness Agent轨迹治理') // from the earlier backfill
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: snapshot create/list/context/delete round-trip', async () => {
  const t = tempDb()
  try {
    const store = deadlockStore(t)
    const api = makeApi(store)

    let res = await api.handle({ method: 'POST', url: `${API_BASE}/snapshots`, body: { sessionId: 's1', nodeId: 's1:4', label: 'check' } })
    assert.equal(res.status, 201)
    const snapshotId = res.json.snapshot.snapshotId

    res = await api.handle({ method: 'GET', url: `${API_BASE}/snapshots?sessionId=s1` })
    assert.equal(res.json.snapshots.length, 1)
    assert.equal(res.json.snapshots[0].label, 'check')

    res = await api.handle({ method: 'GET', url: `${API_BASE}/snapshot-context?snapshotId=${snapshotId}` })
    assert.equal(res.status, 200)
    assert.equal(res.json.hashMatch, true)
    assert.deepEqual(res.json.events.map(e => e.seq), [0, 1, 2, 3, 4])

    res = await api.handle({ method: 'DELETE', url: `${API_BASE}/snapshots?snapshotId=${snapshotId}` })
    assert.equal(res.json.ok, true)

    res = await api.handle({ method: 'POST', url: `${API_BASE}/prune`, body: { maxSnapshots: 10 } })
    assert.equal(res.status, 200)
    assert.equal(typeof res.json.result.kept, 'number')
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: branches + delete observation branch; 404 on unknown route', async () => {
  const t = tempDb()
  try {
    const store = deadlockStore(t)
    seedSession(store, { sessionId: 'child', parentSessionId: 's1', origin: 'subagent', seedLength: 2, createdAt: 1 }, [
      makeEvent('session/end-seed', 0, 100),
      makeEvent('turn/start', 1, 101, { turn: 1 }),
      makeEvent('turn/end', 2, 102, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const api = makeApi(store)

    let res = await api.handle({ method: 'GET', url: `${API_BASE}/branches?sessionId=s1` })
    assert.equal(res.status, 200)
    assert.deepEqual(res.json.branches.map(b => b.sessionId), ['s1', 'child'])
    assert.equal(res.json.branches[1].branchType, 'subagent')

    res = await api.handle({ method: 'DELETE', url: `${API_BASE}/branch?sessionId=child` })
    assert.equal(res.status, 200)
    assert.equal(res.json.result.removedSessions, 1)
    assert.equal(store.findSession('s1').sessionId, 's1')

    res = await api.handle({ method: 'GET', url: `${API_BASE}/nope` })
    assert.equal(res.status, 404)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: error paths are shaped', async () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const api = makeApi(store)
    const missing = await api.handle({ method: 'GET', url: `${API_BASE}/tree` })
    assert.equal(missing.status, 400)
    const none = await api.handle({ method: 'GET', url: `${API_BASE}/tree?sessionId=nope` })
    assert.equal(none.status, 404)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('installTrajectoryApi registers each path exactly once (no duplicate collisions)', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const engine = new DiagnosisEngine(store)
    const registered = []
    const fakeServer = {
      register(route) {
        registered.push(route.path)
        return () => {}
      },
    }
    const fakeCtx = {
      effect(setup) {
        setup()
        return () => {}
      },
      get(name) {
        if (name === 'agents' || name === 'sessions' || name === 'sessionQuery') return undefined
        assert.equal(name, 'webServer')
        return fakeServer
      },
      logger: { warn() {} },
    }

    installTrajectoryApi(fakeCtx, store, engine)
    // exact routes are keyed by path only; duplicates would make the real
    // webserver reject the loader — assert uniqueness + the expected set
    assert.equal(registered.length, new Set(registered).size, 'no duplicate paths')
    assert.ok(registered.every(p => p.startsWith(`${API_BASE}/`)))
    const expected = [
      '/sessions', '/alerts', '/tree', '/branches', '/anomalies', '/node',
      '/snapshots', '/snapshot-context', '/prune', '/analyze', '/branch',
      '/actions/interrupt', '/actions/fork', '/actions/rename', '/report/waste',
    ].map(p => `${API_BASE}${p}`)
    assert.deepEqual(new Set(registered), new Set(expected))
    store.close()
  } finally {
    t.cleanup()
  }
})

test('installTrajectoryApi degrades gracefully when webServer is absent', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const engine = new DiagnosisEngine(store)
    let warned = false
    const fakeCtx = {
      effect() {
        throw new Error('effect must not run without webServer')
      },
      get() {
        return undefined
      },
      logger: { warn() { warned = true } },
    }
    installTrajectoryApi(fakeCtx, store, engine)
    assert.equal(warned, true)
    store.close()
  } finally {
    t.cleanup()
  }
})
