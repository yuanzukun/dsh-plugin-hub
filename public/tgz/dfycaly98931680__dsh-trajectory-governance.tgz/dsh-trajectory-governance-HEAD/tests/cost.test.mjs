import assert from 'node:assert/strict'
import test from 'node:test'
import { EventStore } from '../lib/persistence/event-store.js'
import { CostEstimator } from '../lib/diagnose/cost.js'
import { makeEvent, tempDb } from './helpers.mjs'
import { seedSession } from './tree-fixtures.mjs'

function usageEvent(seq, time, input, output) {
  return makeEvent('assistant/message', seq, time, {
    turn: 1, step: 1,
    message: { role: 'assistant', content: [{ type: 'text', text: 'x' }] },
    usage: { input_tokens: input, output_tokens: output },
  })
}

test('cost: sums usage tokens inside the range and converts to money', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('turn/start', 0, 100, { turn: 1 }),
      usageEvent(1, 200, 1000, 200),
      usageEvent(2, 300, 2000, 300),
      usageEvent(3, 400, 4000, 500), // outside range (seq > 2)
      makeEvent('turn/end', 4, 500, { turn: 1, reason: { kind: 'completed' } }),
    ])
    const cost = new CostEstimator(store, { tokenPricePerM: 100, estimateWhenUsageMissing: false })
    const estimate = cost.estimate('s1', 1, 2)
    assert.equal(estimate.tokens, 3500) // (1000+200) + (2000+300)
    assert.equal(estimate.costCny, 0.35) // 3500 / 1M * 100
    assert.equal(estimate.durationMs, 100) // last(300) - first(200)
    assert.equal(estimate.estimated, false)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('cost: missing usage falls back to session average when enabled', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      usageEvent(0, 0, 1000, 1000), // average = 2000
      usageEvent(1, 1, 1000, 1000),
      makeEvent('assistant/message', 2, 2, { turn: 1, step: 1, message: { role: 'assistant', content: [] } }), // no usage
    ])
    const cost = new CostEstimator(store, { tokenPricePerM: 1, estimateWhenUsageMissing: true })
    const estimate = cost.estimate('s1', 0, 2)
    assert.equal(estimate.tokens, 4000 + 2000) // recorded 4000 + estimated 2000
    assert.equal(estimate.unknownTokens, 2000)
    assert.equal(estimate.estimated, true)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('cost: usage-style tokens (inputTokens/outputTokens) also counted', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      makeEvent('assistant/message', 0, 0, {
        turn: 1, step: 1, message: { role: 'assistant', content: [] },
        usage: { inputTokens: 500, outputTokens: 100 },
      }),
    ])
    const cost = new CostEstimator(store, { tokenPricePerM: 1, estimateWhenUsageMissing: false })
    assert.equal(cost.estimate('s1', 0, 0).tokens, 600)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('cost: endSeq -1 spans to the session tail', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    seedSession(store, { sessionId: 's1', createdAt: 0 }, [
      usageEvent(0, 0, 100, 100),
      usageEvent(5, 5, 300, 300),
      usageEvent(9, 9, 200, 200),
    ])
    const cost = new CostEstimator(store, { tokenPricePerM: 1, estimateWhenUsageMissing: false })
    assert.equal(cost.estimate('s1', 5, -1).tokens, 1000) // 600 + 400
    store.close()
  } finally {
    t.cleanup()
  }
})
