import assert from 'node:assert/strict'
import test from 'node:test'
import { normalizeEvent } from '../lib/ingest/normalize.js'
import { makeEvent } from './helpers.mjs'

test('tool/call normalization extracts name, callId, argumentsLength', () => {
  const event = makeEvent('tool/call', 10, 1000, {
    turn: 2, step: 1, callId: 'call-1', name: 'edit', arguments: '{"file":"a.ts"}',
  })
  const n = normalizeEvent('s1', {}, event)
  assert.equal(n.kind, 'tool-call')
  assert.equal(n.category, 'core-loop')
  assert.equal(n.data.name, 'edit')
  assert.equal(n.data.callId, 'call-1')
  assert.equal(n.data.argumentsLength, 15)
})

test('tool/result normalization extracts isError + error code', () => {
  const ok = normalizeEvent('s1', {}, makeEvent('tool/result', 11, 1001, { turn: 2, step: 1, message: { role: 'tool', content: [] } }))
  assert.equal(ok.kind, 'tool-result')
  assert.equal(ok.surface, true)
  assert.equal(ok.data.isError, false)

  const err = normalizeEvent('s1', {}, makeEvent('tool/result', 12, 1002, {
    turn: 2, step: 1, message: { role: 'tool', content: [] },
    error: { name: 'SandboxDenied', code: 'DENIED' },
  }))
  assert.equal(err.data.isError, true)
  assert.equal(err.data.errorCode, 'DENIED')
  assert.equal(err.data.errorName, 'SandboxDenied')
})

test('turn/end normalization extracts reasonKind', () => {
  const n = normalizeEvent('s1', {}, makeEvent('turn/end', 20, 2000, {
    turn: 2, reason: { kind: 'error', error: { message: 'boom', code: 'RATE_LIMIT' } },
  }))
  assert.equal(n.kind, 'turn-end')
  assert.equal(n.data.reasonKind, 'error')
})

test('unknown event type falls back to unknown category and keeps ignorable', () => {
  const required = normalizeEvent('s1', {}, makeEvent('future/thing', 99, 3000, { x: 1 }))
  assert.equal(required.kind, 'other')
  assert.equal(required.category, 'unknown')
  assert.equal(required.ignorable, false)

  const skippable = normalizeEvent('s1', {}, { type: 'future/thing', seq: 100, time: 3001, data: {}, ignorable: true })
  assert.equal(skippable.ignorable, true)
})

test('user/message normalization extracts sourceKind + contentLength', () => {
  const n = normalizeEvent('s1', {}, makeEvent('user/message', 1, 0, {
    content: [{ type: 'text', text: 'hi' }], source: { kind: 'user' },
  }))
  assert.equal(n.data.sourceKind, 'user')
  assert.equal(n.data.contentLength, 1)
})

test('plan/mode normalization extracts active flag', () => {
  const n = normalizeEvent('s1', {}, makeEvent('plan/mode', 5, 500, { active: true }))
  assert.equal(n.kind, 'plan-mode')
  assert.equal(n.data.active, true)
})

test('session/end-seed maps to end-seed lifecycle kind', () => {
  const n = normalizeEvent('s1', {}, makeEvent('session/end-seed', 3, 300))
  assert.equal(n.kind, 'end-seed')
  assert.equal(n.category, 'lifecycle')
})

test('lineage flows through to the normalized event', () => {
  const n = normalizeEvent('child', { parentSessionId: 'parent', origin: 'subagent' }, makeEvent('turn/start', 0, 0, { turn: 1 }))
  assert.equal(n.branchId, 'child')
  assert.equal(n.parentSessionId, 'parent')
  assert.equal(n.origin, 'subagent')
})
