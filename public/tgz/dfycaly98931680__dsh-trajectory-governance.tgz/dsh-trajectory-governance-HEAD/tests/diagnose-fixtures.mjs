// Fixture builders for diagnosis tests (realistic raw envelope shapes).
import { makeEvent } from './helpers.mjs'

export function toolCall(seq, time, callId, name, args) {
  return makeEvent('tool/call', seq, time, { turn: 1, step: 1, callId, name, arguments: args })
}

export function toolResult(seq, time, callId, message, error) {
  const data = { turn: 1, step: 1, message }
  if (error !== undefined) data.error = error
  return makeEvent('tool/result', seq, time, data)
}

export function turnEnd(seq, time, turn, reason) {
  return makeEvent('turn/end', seq, time, { turn, reason })
}

export function turnStart(seq, time, turn) {
  return makeEvent('turn/start', seq, time, { turn })
}

export function userMsg(seq, time, text, kind = 'user') {
  return makeEvent('user/message', seq, time, { content: [{ type: 'text', text }], source: { kind } })
}

export function assistantMsg(seq, time, text, turn, step = 1) {
  return makeEvent('assistant/message', seq, time, {
    turn, step, message: { role: 'assistant', content: [{ type: 'text', text }] },
  })
}

/** N identical tool attempts, each: call → failed result → error turn/end. */
export function retryCycle(count, baseSeq, { args = '{"retry":true,"param":"x"}', code = 'RATE_LIMIT' } = {}) {
  const events = []
  let seq = baseSeq
  let time = baseSeq * 10
  for (let i = 0; i < count; i += 1) {
    events.push(toolCall(seq, time, `c${i}`, 'invoke', args)); seq += 1; time += 1
    events.push(toolResult(seq, time, `c${i}`, { role: 'tool', content: [{ type: 'text', text: 'failed' }] })); seq += 1; time += 1
    events.push(turnEnd(seq, time, i + 1, { kind: 'error', error: { code, message: `${code}: rate limited` } })); seq += 1; time += 1
  }
  return events
}
