import assert from 'node:assert/strict'
import test from 'node:test'
import { EventStore } from '../lib/persistence/event-store.js'
import { installSessionEventSubscription } from '../lib/ingest/session-event-subscriber.js'
import { fakeContext, makeEvent, makeSession, tempDb } from './helpers.mjs'

test('session/event feed persists normalized events and advances the watermark', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const ctx = fakeContext()
    installSessionEventSubscription(ctx, store)

    const session = makeSession('s1', { parentSessionId: undefined, createdAt: 42 })
    ctx.listeners.get('session/event')(session, makeEvent('turn/start', 1, 100, { turn: 1 }))
    ctx.listeners.get('session/event')(session, makeEvent('tool/call', 2, 101, { turn: 1, step: 1, callId: 'c1', name: 'read' }))
    ctx.listeners.get('session/event')(session, makeEvent('turn/end', 3, 102, { turn: 1, reason: { kind: 'completed' } }))

    assert.equal(store.countEvents(), 3)
    const events = store.listEventsBySession('s1')
    assert.deepEqual(events.map(e => [e.seq, e.type]), [[1, 'turn/start'], [2, 'tool/call'], [3, 'turn/end']])
    assert.equal(events[2].data.reasonKind, 'completed')
    // raw envelope round-trips
    assert.equal(events[1].raw.type, 'tool/call')
    assert.equal(events[1].raw.data.name, 'read')

    // a throwing listener must not break the emitter: feed a malformed event
    assert.doesNotThrow(() => {
      ctx.listeners.get('session/event')(session, null)
    })
    store.close()
  } finally {
    t.cleanup()
  }
})

test('session/created records fork/subagent lineage; disposed + subagent/end settle status', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const ctx = fakeContext()
    installSessionEventSubscription(ctx, store)

    // parent
    ctx.listeners.get('session/created')(makeSession('parent', { createdAt: 1 }))
    // fork/subagent child
    ctx.listeners.get('session/created')(makeSession('child', {
      parentSessionId: 'parent', origin: 'subagent', seedLength: 4, createdAt: 2,
    }))

    const child = store.findSession('child')
    assert.equal(child.parentSessionId, 'parent')
    assert.equal(child.origin, 'subagent')
    assert.equal(child.seedLength, 4)

    // subagent provider pairing from subagent/start
    ctx.listeners.get('subagent/start')({ id: 'child', provider: 'fork' })
    assert.equal(store.findSession('child').subagentProvider, 'fork')

    // settlement from subagent/end
    ctx.listeners.get('subagent/end')({ id: 'child' })
    assert.equal(store.findSession('child').status, 'settled')

    // hard disposal is sticky
    ctx.listeners.get('session/disposed')(makeSession('parent'))
    assert.equal(store.findSession('parent').status, 'disposed')
    store.close()
  } finally {
    t.cleanup()
  }
})
