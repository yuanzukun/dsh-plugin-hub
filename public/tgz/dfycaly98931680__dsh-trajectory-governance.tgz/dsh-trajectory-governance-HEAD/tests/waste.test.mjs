import assert from 'node:assert/strict'
import test from 'node:test'
import { EventStore } from '../lib/persistence/event-store.js'
import { CostEstimator } from '../lib/diagnose/cost.js'
import { DiagnosisEngine } from '../lib/diagnose/engine.js'
import {
  buildWasteReport,
  buildSessionWasteReport,
  wasteReportToMarkdown,
  sessionWasteToMarkdown,
} from '../lib/report/waste-report.js'
import { createTrajectoryApi, API_BASE } from '../lib/api/http.js'
import { makeEvent, tempDb } from './helpers.mjs'
import { seedSession } from './tree-fixtures.mjs'
import { toolCall, toolResult, turnEnd, turnStart, userMsg } from './diagnose-fixtures.mjs'

function usageMsg(seq, time, text, input, output) {
  return makeEvent('assistant/message', seq, time, {
    turn: 1, step: 1,
    message: { role: 'assistant', content: [{ type: 'text', text }] },
    usage: { input_tokens: input, output_tokens: output },
  })
}

/** user(0) turnStart(1) [call/result/usage]×5 (2..16) turnEnd(17). */
function deadlockWithUsage(t) {
  const store = EventStore.open(t.path)
  const events = [userMsg(0, 0, '重构项目为 TypeScript', 'user'), turnStart(1, 1, 1)]
  let seq = 2
  let time = 10
  for (let i = 0; i < 5; i += 1) {
    events.push(toolCall(seq++, time++, `c${i}`, 'edit', '{"file":"a.ts","content":"same"}'))
    events.push(toolResult(seq++, time++, `c${i}`, { role: 'tool', content: [{ type: 'text', text: 'same result' }] }))
    events.push(usageMsg(seq++, time++, `loop ${i}`, 100_000, 20_000))
  }
  events.push(turnEnd(seq, time, 1, { kind: 'completed' }))
  seedSession(store, { sessionId: 's1', createdAt: 0 }, events)
  return store
}

async function analyze(store, sessionId = 's1') {
  await new DiagnosisEngine(store).analyzeSession(sessionId, { full: true })
}

test('waste report: aggregates per session and by type', async () => {
  const t = tempDb()
  try {
    const store = deadlockWithUsage(t)
    const cost = new CostEstimator(store, { tokenPricePerM: 1, estimateWhenUsageMissing: false })
    // no anomalies yet
    assert.equal(buildWasteReport(store, cost).sessions.length, 0)

    await analyze(store)

    const after = buildWasteReport(store, cost)
    assert.equal(after.sessions.length, 1)
    assert.equal(after.sessions[0].sessionId, 's1')
    assert.equal(after.sessions[0].byType.loop_deadlock.count, 1)
    assert.equal(after.totals.anomalies, 1)
    assert.ok(after.sessions[0].totalTokens > 0)

    const markdown = wasteReportToMarkdown(after)
    assert.match(markdown, /s1/)
    assert.match(markdown, /loop_deadlock/)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('session waste report lists items with cost', async () => {
  const t = tempDb()
  try {
    const store = deadlockWithUsage(t)
    await analyze(store)
    const cost = new CostEstimator(store, { tokenPricePerM: 1, estimateWhenUsageMissing: false })
    const report = buildSessionWasteReport(store, cost, 's1')
    assert.equal(report.items.length, 1)
    assert.equal(report.items[0].type, 'loop_deadlock')
    assert.ok(report.items[0].tokens > 0)
    const markdown = sessionWasteToMarkdown(report)
    assert.match(markdown, /s1/)
    assert.match(markdown, /消耗/)
    assert.equal(buildSessionWasteReport(store, cost, 'nope'), undefined)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: /actions/fork resolves the turn boundary and calls sessions.fork', async () => {
  const t = tempDb()
  try {
    const store = deadlockWithUsage(t)
    const forks = []
    const api = createTrajectoryApi(store, new DiagnosisEngine(store), {
      fork: (sessionId, boundarySeq) => {
        forks.push({ sessionId, boundarySeq })
        return { ok: true, childSessionId: 'child-1', boundarySeq }
      },
    })

    // node inside an open turn (before the only turn/end at 17) → no stable boundary
    let res = await api.handle({ method: 'POST', url: `${API_BASE}/actions/fork`, body: { sessionId: 's1', nodeId: 's1:8' } })
    assert.equal(res.status, 409)
    assert.match(res.json.error, /no stable turn boundary/)

    // at the turn/end itself → fork at 17
    res = await api.handle({ method: 'POST', url: `${API_BASE}/actions/fork`, body: { sessionId: 's1', atSeq: 17 } })
    assert.equal(res.status, 200)
    assert.equal(res.json.childSessionId, 'child-1')
    assert.deepEqual(forks, [{ sessionId: 's1', boundarySeq: 17 }])

    // missing sessionId
    res = await api.handle({ method: 'POST', url: `${API_BASE}/actions/fork`, body: {} })
    assert.equal(res.status, 400)

    // no capability → 501
    const bare = createTrajectoryApi(store, new DiagnosisEngine(store))
    res = await bare.handle({ method: 'POST', url: `${API_BASE}/actions/fork`, body: { sessionId: 's1', atSeq: 17 } })
    assert.equal(res.status, 501)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('API: /report/waste returns markdown (global + per-session)', async () => {
  const t = tempDb()
  try {
    const store = deadlockWithUsage(t)
    const api = createTrajectoryApi(store, new DiagnosisEngine(store))
    await api.handle({ method: 'POST', url: `${API_BASE}/analyze`, body: { sessionId: 's1' } })

    const global = await api.handle({ method: 'GET', url: `${API_BASE}/report/waste` })
    assert.equal(global.status, 200)
    assert.match(global.json.markdown, /异常浪费报告/)
    assert.equal(global.json.sessions.length, 1)

    const session = await api.handle({ method: 'GET', url: `${API_BASE}/report/waste?sessionId=s1` })
    assert.equal(session.status, 200)
    assert.match(session.json.markdown, /s1/)
    assert.equal(session.json.items.length, 1)

    const none = await api.handle({ method: 'GET', url: `${API_BASE}/report/waste?sessionId=nope` })
    assert.equal(none.status, 404)
    store.close()
  } finally {
    t.cleanup()
  }
})
