import assert from 'node:assert/strict'
import test from 'node:test'
import { DatabaseSync } from 'node:sqlite'
import { EventStore } from '../lib/persistence/event-store.js'
import { makeEvent, tempDb } from './helpers.mjs'

test('insert events idempotently and read them back in seq order', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    const ev1 = makeEvent('turn/start', 1, 100, { turn: 1 })
    const ev2 = makeEvent('tool/call', 2, 101, { turn: 1, step: 1, callId: 'c1', name: 'read' })
    const ev3 = makeEvent('tool/result', 3, 102, { turn: 1, step: 1, message: {} })

    store.insertEvent({ ...ev1, sessionId: 's1', branchId: 's1', kind: 'turn-start', category: 'core-loop', surface: false, ignorable: false, data: { turn: 1 } }, JSON.stringify(ev1))
    store.insertEvent({ ...ev2, sessionId: 's1', branchId: 's1', kind: 'tool-call', category: 'core-loop', surface: false, ignorable: false, data: { name: 'read' } }, JSON.stringify(ev2))
    store.insertEvent({ ...ev3, sessionId: 's1', branchId: 's1', kind: 'tool-result', category: 'core-loop', surface: true, ignorable: false, data: {} }, JSON.stringify(ev3))
    // duplicate of ev2 must be ignored
    store.insertEvent({ ...ev2, sessionId: 's1', branchId: 's1', kind: 'tool-call', category: 'core-loop', surface: false, ignorable: false, data: { name: 'read' } }, JSON.stringify(ev2))

    assert.equal(store.countEvents(), 3)
    const events = store.listEventsBySession('s1')
    assert.deepEqual(events.map(e => e.seq), [1, 2, 3])
    assert.equal(events[1].raw.type, 'tool/call')
    assert.equal(events[1].data.name, 'read')

    const from2 = store.listEventsBySession('s1', { fromSeq: 2 })
    assert.deepEqual(from2.map(e => e.seq), [2, 3])

    store.close()
  } finally {
    t.cleanup()
  }
})

test('session lifecycle: upsert, status transitions, subagent meta', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    store.upsertSession({ sessionId: 's1', parentSessionId: 'parent', origin: 'subagent', createdAt: 0, lastEventSeq: 0, status: 'active' })
    store.upsertSession({ sessionId: 's2', createdAt: 1, lastEventSeq: 0, status: 'active' })

    assert.equal(store.countSessions(), 2)
    const found = store.findSession('s1')
    assert.equal(found.parentSessionId, 'parent')
    assert.equal(found.origin, 'subagent')

    store.setStatus('s1', 'disposed')
    assert.equal(store.findSession('s1').status, 'disposed')
    // disposed is sticky: a later 'settled' must not resurrect it
    store.setStatus('s1', 'settled')
    assert.equal(store.findSession('s1').status, 'disposed')

    store.setSubagentMeta('s2', { mode: 'continuable', label: 'helper', provider: 'spawn' })
    const meta = store.findSession('s2')
    assert.equal(meta.subagentMode, 'continuable')
    assert.equal(meta.subagentProvider, 'spawn')

    store.close()
  } finally {
    t.cleanup()
  }
})

test('touchSession advances the watermark only forward', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    store.upsertSession({ sessionId: 's1', createdAt: 0, lastEventSeq: 0, status: 'active' })
    store.touchSession('s1', 5, 500)
    store.touchSession('s1', 3, 300)
    assert.equal(store.findSession('s1').lastEventSeq, 5)
    assert.equal(store.findSession('s1').lastEventAt, 500)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('listSessions orders by createdAt desc', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    store.upsertSession({ sessionId: 'old', createdAt: 1, lastEventSeq: 0, status: 'active' })
    store.upsertSession({ sessionId: 'new', createdAt: 9, lastEventSeq: 0, status: 'active' })
    const sessions = store.listSessions()
    assert.deepEqual(sessions.map(s => s.sessionId), ['new', 'old'])
    store.close()
  } finally {
    t.cleanup()
  }
})

test('setTitle persists display name and auto title; upsert keeps them', () => {
  const t = tempDb()
  try {
    const store = EventStore.open(t.path)
    store.upsertSession({ sessionId: 's1', createdAt: 0, lastEventSeq: 0, status: 'active' })
    store.setTitle('s1', { autoTitle: '重构项目为 TS' })
    store.setTitle('s1', { displayName: '我的命名' })
    const found = store.findSession('s1')
    assert.equal(found.autoTitle, '重构项目为 TS')
    assert.equal(found.displayName, '我的命名')

    // re-upsert must not wipe titles
    store.upsertSession({ sessionId: 's1', createdAt: 0, lastEventSeq: 5, status: 'active' })
    assert.equal(store.findSession('s1').displayName, '我的命名')

    // clearing via empty string
    store.setTitle('s1', { displayName: '' })
    assert.equal(store.findSession('s1').displayName, undefined)
    store.close()
  } finally {
    t.cleanup()
  }
})

test('migration: pre-v0.4 database gains display_name / auto_title columns', () => {
  const t = tempDb()
  try {
    // build an OLD-schema database by hand (no title columns)
    const db = new DatabaseSync(t.path)
    db.exec(`CREATE TABLE sessions (
      session_id TEXT PRIMARY KEY, parent_session_id TEXT, origin TEXT,
      seed_length INTEGER, cwd TEXT, agent_preset TEXT, subagent_mode TEXT,
      subagent_label TEXT, subagent_provider TEXT, created_at INTEGER NOT NULL,
      last_event_seq INTEGER NOT NULL DEFAULT 0, last_event_at INTEGER,
      status TEXT NOT NULL DEFAULT 'active'
    )`)
    db.exec(`INSERT INTO sessions (session_id, created_at, last_event_seq, status) VALUES ('old', 0, 0, 'active')`)
    db.close()

    // open through EventStore → migrations must add the columns
    const store = EventStore.open(t.path)
    const found = store.findSession('old')
    assert.equal(found.sessionId, 'old')
    assert.equal(found.displayName, undefined)
    store.setTitle('old', { displayName: '迁移后命名' })
    assert.equal(store.findSession('old').displayName, '迁移后命名')
    store.close()
  } finally {
    t.cleanup()
  }
})
