// Dev utility: dump one session's trajectory tree as JSON.
// Usage: node scripts/tree.mjs <sessionId> [dbPath] [--strip-raw]
import { homedir } from 'node:os'
import { join } from 'node:path'
import { EventStore } from '../lib/persistence/event-store.js'
import { buildTrajectoryTree, toJSON } from '../lib/tree/queries.js'

const sessionId = process.argv[2]
if (sessionId === undefined) {
  console.error('usage: node scripts/tree.mjs <sessionId> [dbPath] [--strip-raw]')
  process.exit(1)
}
const stripRaw = process.argv.includes('--strip-raw')
const dbPath = process.argv[3] ?? join(homedir(), '.dsh-trajectory-governance', 'trajectory.db')

const store = EventStore.open(dbPath)
try {
  const builder = buildTrajectoryTree(store, sessionId)
  if (builder === undefined) {
    console.error(`no session ${sessionId} in ${dbPath}`)
    process.exit(1)
  }
  console.log(JSON.stringify(toJSON(builder, { stripRaw }), null, 2))
} finally {
  store.close()
}
