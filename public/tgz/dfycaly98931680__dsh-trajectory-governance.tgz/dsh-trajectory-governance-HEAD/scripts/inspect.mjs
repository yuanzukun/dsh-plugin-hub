// Dev utility: inspect the plugin's SQLite store from the command line.
// Usage: node scripts/inspect.mjs [dbPath]   (default: ~/.dsh-trajectory-governance/trajectory.db)
import { homedir } from 'node:os'
import { join } from 'node:path'
import { EventStore } from '../lib/persistence/event-store.js'

const dbPath = process.argv[2] ?? join(homedir(), '.dsh-trajectory-governance', 'trajectory.db')
const store = EventStore.open(dbPath)
try {
  const sessions = store.listSessions(50)
  console.log(`db: ${dbPath}`)
  console.log(`sessions: ${store.countSessions()}  events: ${store.countEvents()}`)
  for (const s of sessions) {
    const events = store.listEventsBySession(s.sessionId, { limit: 10 })
    console.log(`- ${s.sessionId} [${s.status}] parent=${s.parentSessionId ?? '-'} origin=${s.origin ?? '-'} seq<=${s.lastEventSeq} events=${events.length >= 10 ? '10+' : events.length} first=${events[0]?.type ?? '-'} last=${events.at(-1)?.type ?? '-'}`)
  }
} finally {
  store.close()
}
