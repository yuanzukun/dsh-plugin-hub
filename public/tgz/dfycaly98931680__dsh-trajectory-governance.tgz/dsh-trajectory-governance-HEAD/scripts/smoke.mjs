// Verify the built host entry exports a Cordis plugin surface.
// Run: npm run build && npm run smoke  (or: node scripts/smoke.mjs)
const m = await import('../lib/index.js')

if (m.name !== 'trajectory-governance') {
  throw new Error(`unexpected plugin name: ${m.name}`)
}
if (typeof m.apply !== 'function') {
  throw new Error('plugin entry missing apply()')
}

console.log(`smoke OK: ${m.name} (apply=${typeof m.apply})`)
