// Dev utility: snapshot operations from the command line (observation layer).
// Usage:
//   node scripts/snapshot.mjs <dbPath> list [sessionId]
//   node scripts/snapshot.mjs <dbPath> create <sessionId> [nodeId] [label]
//   node scripts/snapshot.mjs <dbPath> context <snapshotId>
//   node scripts/snapshot.mjs <dbPath> delete <snapshotId>
//   node scripts/snapshot.mjs <dbPath> prune [maxSnapshots] [ttlMs] [keepNewest]
import { EventStore } from '../lib/persistence/event-store.js'
import { SnapshotService } from '../lib/snapshot/snapshot-service.js'

const [, , dbPath, cmd, ...args] = process.argv
if (dbPath === undefined || cmd === undefined) {
  console.error('usage: node scripts/snapshot.mjs <dbPath> <list|create|context|delete|prune> [...]')
  process.exit(1)
}

const store = EventStore.open(dbPath)
const svc = new SnapshotService(store)
try {
  switch (cmd) {
    case 'list': {
      const filter = args[0]
      const snaps = svc.list(filter === undefined ? {} : { sessionId: filter })
      console.log(`snapshots: ${snaps.length}`)
      for (const s of snaps) {
        console.log(`- ${s.snapshotId} node=${s.nodeId} branch=${s.branchId} hash=${s.contextHash.slice(0, 12)} acc=${s.accessCount}`)
      }
      break
    }
    case 'create': {
      const sessionId = args[0]
      const nodeId = args[1]
      const label = args[2]
      const snap = svc.create(sessionId, { nodeId, label })
      if (snap === undefined) {
        console.error(`cannot create snapshot (session=${sessionId} node=${nodeId ?? 'tail'})`)
        process.exit(1)
      }
      console.log(`created ${snap.snapshotId} node=${snap.nodeId} hash=${snap.contextHash.slice(0, 12)}`)
      break
    }
    case 'context': {
      const ctx = svc.context(args[0])
      if (ctx === undefined) {
        console.error(`snapshot not found: ${args[0]}`)
        process.exit(1)
      }
      console.log(`snapshot=${ctx.snapshot.snapshotId} hashMatch=${ctx.hashMatch} events=${ctx.events.length}`)
      for (const e of ctx.events) console.log(`  ${e.seq}\t${e.type}\tt=${e.time}`)
      break
    }
    case 'delete': {
      console.log(svc.remove(args[0]) ? `deleted ${args[0]}` : `not found ${args[0]}`)
      break
    }
    case 'prune': {
      const result = svc.prune({
        maxSnapshots: args[0] === undefined ? undefined : Number(args[0]),
        ttlMs: args[1] === undefined ? undefined : Number(args[1]),
        keepNewest: args[2] === undefined ? undefined : Number(args[2]),
      })
      console.log(`pruned: removed=${result.removed} kept=${result.kept}`)
      break
    }
    default:
      console.error(`unknown command: ${cmd}`)
      process.exit(1)
  }
} finally {
  store.close()
}
