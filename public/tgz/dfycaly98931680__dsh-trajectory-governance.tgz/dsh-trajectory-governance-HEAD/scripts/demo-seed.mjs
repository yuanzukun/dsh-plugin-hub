// Demo seed: inject a synthetic session into a trajectory-governance DB so the
// UI tab shows the full picture instantly (loop deadlock + goal drift + snapshot).
// Usage: node scripts/demo-seed.mjs [dbPath]
//   default dbPath: ~/.dsh-trajectory-governance/trajectory.db
// After seeding, refresh the "轨迹治理" tab and pick session "demo-session".
import { homedir } from 'node:os'
import { join } from 'node:path'
import { EventStore } from '../lib/persistence/event-store.js'
import { SnapshotService } from '../lib/snapshot/snapshot-service.js'
import { DiagnosisEngine } from '../lib/diagnose/engine.js'
import { mergeDiagnosisConfig } from '../lib/diagnose/config.js'
import { normalizeEvent } from '../lib/ingest/normalize.js'

const dbPath = process.argv[2] ?? join(homedir(), '.dsh-trajectory-governance', 'trajectory.db')
const SESSION = 'demo-session'

const store = EventStore.open(dbPath)
try {
  // idempotent: wipe a previous demo-session first
  const existing = store.findSession(SESSION)
  if (existing !== undefined) {
    store.deleteBranchData(SESSION)
    store.deleteAnomaliesBySession(SESSION)
  }

  const events = []
  let seq = 0
  let time = 0
  const ev = (type, data) => {
    const event = { type, seq, time, data }
    seq += 1
    time += 10
    return event
  }

  // goal + a couple of turns
  events.push(ev('user/message', { content: [{ type: 'text', text: '重构整个项目为 TypeScript 并补充单元测试' }], source: { kind: 'user' } }))
  const USAGE = { input_tokens: 200_000, output_tokens: 50_000 } // ~¥0.07 per message @0.28/M
  events.push(ev('turn/start', { turn: 1 }))
  events.push(ev('assistant/message', { turn: 1, step: 1, message: { role: 'assistant', content: [{ type: 'text', text: '开始迁移项目到 TypeScript' }] }, usage: USAGE }))
  // loop deadlock: 5 identical edit calls with identical results (5 more usage messages)
  for (let i = 0; i < 5; i += 1) {
    events.push(ev('tool/call', { turn: 1, step: 1, callId: `c${i}`, name: 'edit', arguments: '{"file":"src/main.ts","content":"export const VERSION = 1"}' }))
    events.push(ev('tool/result', { turn: 1, step: 1, message: { role: 'tool', content: [{ type: 'text', text: 'File updated.' }] } }))
    events.push(ev('assistant/message', { turn: 1, step: 1, message: { role: 'assistant', content: [{ type: 'text', text: '继续调整相同文件…' }] }, usage: USAGE }))
  }
  events.push(ev('turn/end', { turn: 1, reason: { kind: 'completed' } }))
  // goal drift: two off-topic turns
  for (let t = 2; t <= 3; t += 1) {
    events.push(ev('turn/start', { turn: t }))
    events.push(ev('assistant/message', { turn: t, step: 1, message: { role: 'assistant', content: [{ type: 'text', text: t === 2 ? '我在研究怎么做番茄意面' : '番茄意面要配新鲜罗勒和帕玛森' }] }, usage: USAGE }))
    events.push(ev('turn/end', { turn: t, reason: { kind: 'completed' } }))
  }

  store.upsertSession({ sessionId: SESSION, createdAt: Date.now() - 60_000, lastEventSeq: 0, status: 'active' })
  for (const event of events) {
    const normalized = normalizeEvent(SESSION, {}, event)
    store.insertEvent(normalized, JSON.stringify(event))
  }

  // snapshot at the first tool call
  const svc = new SnapshotService(store)
  svc.create(SESSION, { nodeId: `${SESSION}:3`, label: 'Demo 检查点' })

  // run the diagnosis engine once (full) — sample every turn so the 3-turn
  // demo session still shows goal drift
  const engine = new DiagnosisEngine(store, mergeDiagnosisConfig({
    strategyC: { enabled: true, sampleEveryNRounds: 1, consecutiveSamples: 2 },
  }))
  const result = await engine.analyzeSession(SESSION, { full: true })

  console.log(`seeded ${events.length} events into ${dbPath}`)
  console.log(`anomalies: ${result.newAnomalies} new / ${result.totalAnomalies} total (${result.ranStrategies.join(', ')})`)
  console.log('refresh the 轨迹治理 tab and pick session "demo-session"')
} finally {
  store.close()
}
