import { fileURLToPath } from 'node:url'
import tsconfigPaths from 'vite-tsconfig-paths'
import { defineConfig } from 'vitest/config'

export default defineConfig({
  // Anchor the project at the plugin folder so `include` resolves here even
  // when vitest is launched from the repository root.
  root: fileURLToPath(new URL('.', import.meta.url)),
  plugins: [
    tsconfigPaths({ projects: [fileURLToPath(new URL('../tsconfig.base.json', import.meta.url))] }),
  ],
  test: {
    include: ['tests/**/*.spec.ts'],
    // Forked workers match the repo-wide pool; Node 24 can abort in its CJS
    // lexer from worker threads.
    pool: 'forks',
  },
})
