/**
 * Unit and real-spawn tests for the mmv-dspic plugin: registration shape,
 * HMR disposal, the process runner's timeout/abort/truncation contract, arg
 * validation through the real registry, and the tool bodies driven against
 * fake (but really executed) toolchain executables.
 */

import { existsSync } from 'node:fs'
import { chmod, mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { afterAll, describe, expect, it } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import { CallId } from '@deepseek-ai/dsh-llm'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import type { ToolExecutionResult } from '@deepseek-ai/dsh-tools'
import { runProcess } from '../src/run.ts'
import type { Config } from '../src/index.ts'
import * as plugin from '../src/index.ts'

const testSignal = new AbortController().signal

const TOOL_NAMES = [
  'mmv_check_env',
  'mmv_project_init',
  'mmv_matlab_run',
  'mmv_modelsim_compile',
  'mmv_modelsim_simulate',
  'mmv_vivado_run',
  'mmv_vivado_flow',
]

const DEFAULT_CONFIG: Config = {
  matlabPath: 'matlab',
  modelsimPath: 'vsim',
  vivadoPath: 'vivado',
  workdir: '',
  timeoutMs: 30_000,
  maxOutputChars: 20_000,
}

/** Mount the real plugin body on a real ToolRuntime. */
async function setup(config: Config = DEFAULT_CONFIG): Promise<Context> {
  const ctx = new Context()
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(plugin, config)
  return ctx
}

let callCounter = 0
function call(ctx: Context, name: string, args: unknown): Promise<ToolExecutionResult> {
  return ctx.tools.execute({
    signal: testSignal,
    callId: CallId(`mmv-${++callCounter}`),
    name,
    arguments: args,
  })
}

function text(result: ToolExecutionResult): string {
  return result.content.filter(block => block.type === 'text').map(block => block.text).join('')
}

const tempDirs: string[] = []
async function tempDir(prefix: string): Promise<string> {
  const dir = await mkdtemp(path.join(os.tmpdir(), prefix))
  tempDirs.push(dir)
  return dir
}

/** Write a really executable fake toolchain binary (a .cmd on Windows, a sh script elsewhere). */
async function fakeTool(binDir: string, name: string, echoLines: string[]): Promise<string> {
  if (process.platform === 'win32') {
    const file = path.join(binDir, `${name}.cmd`)
    await writeFile(file, `@echo off\r\n${echoLines.map(line => `echo ${line}`).join('\r\n')}\r\n`, 'utf8')
    return file
  }
  const file = path.join(binDir, name)
  await writeFile(file, `#!/bin/sh\n${echoLines.map(line => `echo ${line}`).join('\n')}\nexit 0\n`, 'utf8')
  await chmod(file, 0o755)
  return file
}

afterAll(async () => {
  await Promise.all(tempDirs.map(dir => rm(dir, { recursive: true, force: true })))
})

describe('plugin export shape', () => {
  it('has the namespace-plugin export shape (no stray default) so the Loader keeps name/inject/apply', () => {
    expect('default' in plugin).toBe(false)
    expect(plugin.name).toBe('mmv-dspic')
    expect(plugin.inject).toEqual(['tools'])

    const loader = Object.create(Loader.prototype) as Loader
    const unwrapped = loader.unwrapExports(plugin) as Record<string, unknown>
    expect(unwrapped).toBe(plugin)
    expect(unwrapped.name).toBe('mmv-dspic')
    expect(unwrapped.inject).toEqual(['tools'])
    expect(typeof unwrapped.apply).toBe('function')
  })

  it('registers all seven mmv_* tools with non-empty descriptions', async () => {
    const ctx = await setup()
    const schemas = ctx.tools.schemas()
    for (const name of TOOL_NAMES) {
      const schema = schemas.find(s => s.name === name)
      expect(schema, `tool ${name}`).toBeDefined()
      expect(schema!.description.length).toBeGreaterThan(20)
    }
  })

  it('unregisters every tool when its contributing fiber is disposed (HMR-safety)', async () => {
    const ctx = new Context()
    await ctx.plugin(SystemPrompt)
    await ctx.plugin(ToolRuntime)
    const fiber = await ctx.plugin(plugin, DEFAULT_CONFIG)
    expect(ctx.tools.schemas().some(s => s.name === 'mmv_matlab_run')).toBe(true)
    await fiber.dispose()
    expect(ctx.tools.schemas().some(s => s.name === 'mmv_matlab_run')).toBe(false)
    expect(ctx.tools.schemas().some(s => s.name === 'mmv_vivado_flow')).toBe(false)
  })
})

describe('runProcess', () => {
  it('captures stdout and a zero exit code', async () => {
    const result = await runProcess({
      command: process.execPath,
      args: ['-e', "console.log('hello mmv')"],
      timeoutMs: 5000,
      signal: testSignal,
      maxOutputChars: 1000,
    })
    expect(result.exitCode).toBe(0)
    expect(result.timedOut).toBe(false)
    expect(result.stdout).toContain('hello mmv')
  })

  it('carries a non-zero exit code as a domain outcome', async () => {
    const result = await runProcess({
      command: process.execPath,
      args: ['-e', 'process.exit(3)'],
      timeoutMs: 5000,
      signal: testSignal,
      maxOutputChars: 1000,
    })
    expect(result.exitCode).toBe(3)
    expect(result.timedOut).toBe(false)
  })

  it('kills the process tree on timeout and reports timedOut', async () => {
    const result = await runProcess({
      command: process.execPath,
      args: ['-e', 'setTimeout(() => {}, 60000)'],
      timeoutMs: 400,
      signal: testSignal,
      maxOutputChars: 1000,
    })
    expect(result.timedOut).toBe(true)
    expect(result.exitCode).toBeNull()
  })

  it('rejects when the caller aborts mid-run', async () => {
    const controller = new AbortController()
    const pending = runProcess({
      command: process.execPath,
      args: ['-e', 'setTimeout(() => {}, 60000)'],
      timeoutMs: 30_000,
      signal: controller.signal,
      maxOutputChars: 1000,
    })
    setTimeout(() => controller.abort(), 100)
    await expect(pending).rejects.toThrow(/cancelled/)
  })

  it('rejects an unresolvable executable', async () => {
    await expect(runProcess({
      command: 'mmv-definitely-missing-xyz',
      args: [],
      timeoutMs: 1000,
      signal: testSignal,
      maxOutputChars: 1000,
    })).rejects.toThrow(/cannot resolve executable/)
  })

  it('caps oversized output and reports truncation', async () => {
    const result = await runProcess({
      command: process.execPath,
      args: ['-e', "process.stdout.write('x'.repeat(5000))"],
      timeoutMs: 5000,
      signal: testSignal,
      maxOutputChars: 200,
    })
    expect(result.exitCode).toBe(0)
    expect(result.truncated).toBe(true)
    expect(result.stdout.length).toBeLessThan(400)
    expect(result.stdout).toContain('output truncated')
  })
})

describe('mmv_check_env', () => {
  it('reports every toolchain as missing without failing the call', async () => {
    const config: Config = {
      ...DEFAULT_CONFIG,
      matlabPath: 'C:/mmv-nonexistent/matlab.exe',
      modelsimPath: 'C:/mmv-nonexistent/vsim.exe',
      vivadoPath: 'C:/mmv-nonexistent/vivado.exe',
    }
    const ctx = await setup(config)
    const result = await call(ctx, 'mmv_check_env', {})
    expect(result.isError).toBe(false)
    const value = result.value as { checks: { tool: string; found: boolean }[] }
    expect(value.checks).toHaveLength(3)
    for (const check of value.checks) expect(check.found).toBe(false)
  })

  it('honors the tools subset parameter', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_check_env', { tools: ['vivado'] })
    expect(result.isError).toBe(false)
    const value = result.value as { checks: { tool: string }[] }
    expect(value.checks.map(check => check.tool)).toEqual(['vivado'])
  })

  it('rejects an unknown toolchain name at the schema boundary', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_check_env', { tools: ['cadence'] })
    expect(result.isError).toBe(true)
    expect(text(result)).toContain('invalid arguments')
    expect(text(result)).toContain('must be one of')
  })
})

describe('mmv_project_init', () => {
  it('scaffolds the workspace, README, and templates', async () => {
    const dir = await tempDir('mmv-proj-')
    const ctx = await setup()
    const result = await call(ctx, 'mmv_project_init', { dir })
    expect(result.isError).toBe(false)
    const value = result.value as { dir: string; created: string[] }
    expect(value.dir).toBe(path.resolve(dir))
    expect(value.created).toContain(path.join(dir, 'rtl'))
    expect(existsSync(path.join(dir, 'README.md'))).toBe(true)
    expect(existsSync(path.join(dir, 'sim', 'run.do'))).toBe(true)
    expect(existsSync(path.join(dir, 'scripts', 'flow.tcl'))).toBe(true)
  })

  it('skips templates when requested', async () => {
    const dir = await tempDir('mmv-proj-notpl-')
    const ctx = await setup()
    const result = await call(ctx, 'mmv_project_init', { dir, templates: false })
    expect(result.isError).toBe(false)
    expect(existsSync(path.join(dir, 'README.md'))).toBe(true)
    expect(existsSync(path.join(dir, 'sim', 'run.do'))).toBe(false)
  })

  it('rejects an empty dir', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_project_init', { dir: '   ' })
    expect(result.isError).toBe(true)
  })

  it('presents the call as a diff card naming the created files', async () => {
    const ctx = await setup()
    const def = ctx.tools.get('mmv_project_init')!
    const view = def.presentCall?.({ dir: 'proj' })
    expect(view).toMatchObject({ card: 'diff', title: 'Scaffold project proj' })
    const diffs = (view as { diffs: { path: string }[] }).diffs
    expect(diffs.map(diff => diff.path)).toEqual([
      path.join('proj', 'README.md'),
      path.join('proj', 'sim', 'run.do'),
      path.join('proj', 'scripts', 'flow.tcl'),
    ])
  })
})

describe('mmv_matlab_run', () => {
  it('rejects zero or two of mFile/expression', async () => {
    const ctx = await setup()
    const none = await call(ctx, 'mmv_matlab_run', {})
    expect(none.isError).toBe(true)
    expect(text(none)).toContain('exactly one of mFile/expression')

    const both = await call(ctx, 'mmv_matlab_run', { mFile: 'a.m', expression: 'x' })
    expect(both.isError).toBe(true)
    expect(text(both)).toContain('exactly one of mFile/expression')
  })

  it('rejects a missing mFile', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_matlab_run', { mFile: 'C:/mmv-nonexistent/a.m' })
    expect(result.isError).toBe(true)
    expect(text(result)).toContain('mFile not found')
  })

  it('runs the configured executable with -batch and captures the outcome', async () => {
    const ctx = await setup({ ...DEFAULT_CONFIG, matlabPath: process.execPath })
    const result = await call(ctx, 'mmv_matlab_run', { expression: 'console.log("from matlab run")' })
    expect(result.isError).toBe(false)
    const value = result.value as { exitCode: number | null; timedOut: boolean; stderr: string }
    // node rejects the -batch flag, proving the plumbing ran with the right argv.
    expect(value.exitCode).not.toBeNull()
    expect(value.exitCode).not.toBe(0)
    expect(value.timedOut).toBe(false)
    expect(value.stderr).toContain('-batch')
  })
})

describe('mmv_modelsim_compile', () => {
  it('rejects an empty sources array', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_modelsim_compile', { sources: [] })
    expect(result.isError).toBe(true)
    expect(text(result)).toContain('non-empty')
  })

  it('rejects a missing source file', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_modelsim_compile', { sources: ['C:/mmv-nonexistent/top.sv'] })
    expect(result.isError).toBe(true)
    expect(text(result)).toContain('source not found')
  })

  it('rejects an unknown extension when language is auto', async () => {
    const dir = await tempDir('mmv-msim-ext-')
    await writeFile(path.join(dir, 'top.xyz'), 'x', 'utf8')
    const ctx = await setup()
    const result = await call(ctx, 'mmv_modelsim_compile', { sources: ['top.xyz'], cwd: dir })
    expect(result.isError).toBe(true)
    expect(text(result)).toContain('cannot determine language')
  })

  it('creates the library and compiles through fake vlib/vlog executables', async () => {
    const bin = await tempDir('mmv-msim-bin-')
    const vsimPath = await fakeTool(bin, 'vsim', ['vsim ran'])
    await fakeTool(bin, 'vlib', ['vlib ran'])
    await fakeTool(bin, 'vlog', ['vlog ran'])
    await fakeTool(bin, 'vcom', ['vcom ran'])
    const workDir = await tempDir('mmv-msim-work-')
    await writeFile(path.join(workDir, 'top.sv'), 'module top; endmodule\n', 'utf8')
    const ctx = await setup({ ...DEFAULT_CONFIG, modelsimPath: vsimPath })
    const result = await call(ctx, 'mmv_modelsim_compile', { sources: ['top.sv'], cwd: workDir })
    expect(result.isError).toBe(false)
    const value = result.value as { exitCode: number; stdout: string; compiledFiles: string[] }
    expect(value.exitCode).toBe(0)
    expect(value.stdout).toContain('vlib ran')
    expect(value.stdout).toContain('vlog ran')
    expect(value.compiledFiles).toEqual([path.join(workDir, 'top.sv')])
  })
})

describe('mmv_modelsim_simulate', () => {
  it('rejects zero or two of doFile/commands', async () => {
    const ctx = await setup()
    const none = await call(ctx, 'mmv_modelsim_simulate', { top: 'tb' })
    expect(none.isError).toBe(true)
    expect(text(none)).toContain('exactly one of doFile/commands')

    const both = await call(ctx, 'mmv_modelsim_simulate', { top: 'tb', doFile: 'a.do', commands: ['run -all'] })
    expect(both.isError).toBe(true)
  })

  it('rejects a missing doFile', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_modelsim_simulate', { top: 'tb', doFile: 'C:/mmv-nonexistent/x.do' })
    expect(result.isError).toBe(true)
    expect(text(result)).toContain('doFile not found')
  })

  it('writes a generated do-file with wave recording and drives fake vsim', async () => {
    const bin = await tempDir('mmv-msim-bin2-')
    const vsimPath = await fakeTool(bin, 'vsim', ['vsim ran'])
    const workDir = await tempDir('mmv-msim-work2-')
    const ctx = await setup({ ...DEFAULT_CONFIG, modelsimPath: vsimPath })
    const result = await call(ctx, 'mmv_modelsim_simulate', {
      top: 'tb_top',
      commands: ['run -all'],
      recordWaves: true,
      cwd: workDir,
    })
    expect(result.isError).toBe(false)
    const value = result.value as { exitCode: number; stdout: string; doFile: string }
    expect(value.exitCode).toBe(0)
    expect(value.stdout).toContain('vsim ran')
    expect(path.dirname(value.doFile)).toBe(workDir)
    const content = await readFile(value.doFile, 'utf8')
    expect(content).toContain('log -r /*')
    expect(content).toContain('run -all')
    expect(content).toContain('quit -f')
  })

  it('qualifies a bare top with the work library', async () => {
    const bin = await tempDir('mmv-msim-bin3-')
    // The fake vsim echoes its argument line so the qualified unit is observable.
    const vsimPath = await fakeTool(bin, 'vsim', [process.platform === 'win32' ? '%*' : '"$@"'])
    const workDir = await tempDir('mmv-msim-work3-')
    const ctx = await setup({ ...DEFAULT_CONFIG, modelsimPath: vsimPath })
    const result = await call(ctx, 'mmv_modelsim_simulate', {
      top: 'tb',
      commands: ['run -all'],
      cwd: workDir,
    })
    expect(result.isError).toBe(false)
    // The fake vsim echoes its argument line; the qualified unit must appear.
    const value = result.value as { stdout: string }
    expect(value.stdout).toContain('work.tb')
  })
})

describe('mmv_vivado_run', () => {
  it('rejects a missing script', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_vivado_run', { script: 'C:/mmv-nonexistent/flow.tcl' })
    expect(result.isError).toBe(true)
    expect(text(result)).toContain('script not found')
  })

  it('runs a Tcl script through fake vivado', async () => {
    const bin = await tempDir('mmv-viv-bin-')
    const vivadoPath = await fakeTool(bin, 'vivado', ['vivado ran'])
    const workDir = await tempDir('mmv-viv-work-')
    await writeFile(path.join(workDir, 'script.tcl'), 'puts "hi"\n', 'utf8')
    const ctx = await setup({ ...DEFAULT_CONFIG, vivadoPath })
    const result = await call(ctx, 'mmv_vivado_run', { script: 'script.tcl', cwd: workDir })
    expect(result.isError).toBe(false)
    const value = result.value as { exitCode: number; stdout: string }
    expect(value.exitCode).toBe(0)
    expect(value.stdout).toContain('vivado ran')
  })
})

describe('mmv_vivado_flow', () => {
  it('generates and runs a synthesis-only flow', async () => {
    const bin = await tempDir('mmv-vivf-bin-')
    const vivadoPath = await fakeTool(bin, 'vivado', ['vivado ran'])
    const workDir = await tempDir('mmv-vivf-work-')
    await writeFile(path.join(workDir, 'top.sv'), 'module top; endmodule\n', 'utf8')
    const ctx = await setup({ ...DEFAULT_CONFIG, vivadoPath })
    const result = await call(ctx, 'mmv_vivado_flow', {
      top: 'top',
      sources: ['top.sv'],
      part: 'xc7a35tcsg324-1',
      steps: ['synthesis'],
      cwd: workDir,
    })
    expect(result.isError).toBe(false)
    const value = result.value as {
      exitCode: number
      tclPath: string
      outputs: { synthesisCheckpoint?: string; reports: string[] }
    }
    expect(value.exitCode).toBe(0)
    const tcl = await readFile(value.tclPath, 'utf8')
    expect(tcl).toContain('synth_design -top {top} -part {xc7a35tcsg324-1}')
    expect(tcl).not.toContain('route_design')
    expect(value.outputs.synthesisCheckpoint).toBeUndefined()
    expect(value.outputs.reports).toEqual([])
  })

  it('bitstream implies implementation in the generated Tcl', async () => {
    const bin = await tempDir('mmv-vivf-bin2-')
    const vivadoPath = await fakeTool(bin, 'vivado', ['vivado ran'])
    const workDir = await tempDir('mmv-vivf-work2-')
    await writeFile(path.join(workDir, 'top.v'), 'module top; endmodule\n', 'utf8')
    const ctx = await setup({ ...DEFAULT_CONFIG, vivadoPath })
    const result = await call(ctx, 'mmv_vivado_flow', {
      top: 'top',
      sources: ['top.v'],
      part: 'xc7a35tcsg324-1',
      steps: ['bitstream'],
      cwd: workDir,
    })
    expect(result.isError).toBe(false)
    const value = result.value as { tclPath: string }
    const tcl = await readFile(value.tclPath, 'utf8')
    expect(tcl).toContain('route_design')
    expect(tcl).toContain('write_bitstream')
  })

  it('rejects a missing source file', async () => {
    const ctx = await setup()
    const result = await call(ctx, 'mmv_vivado_flow', {
      top: 'top',
      sources: ['C:/mmv-nonexistent/top.sv'],
      part: 'xc7a35tcsg324-1',
    })
    expect(result.isError).toBe(true)
    expect(text(result)).toContain('source not found')
  })
})
