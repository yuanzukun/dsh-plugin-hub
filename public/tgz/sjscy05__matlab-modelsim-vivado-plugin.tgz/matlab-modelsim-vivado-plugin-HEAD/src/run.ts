/**
 * Process execution for the mmv-dspic tools: PATH-aware executable resolution,
 * bounded-output capture, cooperative timeout and caller-cancellation with
 * process-tree kills, and a shared canonical run-result shape.
 * @module mmv-dspic/run
 */

import { spawn } from 'node:child_process'
import type { ChildProcess } from 'node:child_process'
import { accessSync, existsSync, constants as fsConstants } from 'node:fs'
import path from 'node:path'

/** Canonical outcome of one tool-driven process run. */
export interface RunResult {
  /** Process exit code; null when the run was killed by timeout or signal. */
  exitCode: number | null
  /** Whether the run was killed by the timeout budget. */
  timedOut: boolean
  /** Wall-clock duration of the run in milliseconds. */
  durationMs: number
  /** Captured stdout, capped at the configured character budget. */
  stdout: string
  /** Captured stderr, capped at the configured character budget. */
  stderr: string
  /** Whether either captured stream was truncated to its budget. */
  truncated: boolean
}

/** Options for {@link runProcess}. */
export interface RunOptions {
  /** Executable: a bare PATH name, an absolute path, or a relative path. */
  command: string
  /** Arguments passed verbatim (no shell quoting is applied). */
  args: string[]
  /** Working directory for the child process; undefined inherits the parent. */
  cwd?: string | undefined
  /** Positive wall-clock budget; the process tree is killed on expiry. */
  timeoutMs: number
  /** Caller-owned cancellation; firing kills the tree and rejects the run. */
  signal: AbortSignal
  /** Per-stream cap on captured characters; the run result reports truncation. */
  maxOutputChars: number
}

/** Cap a captured stream while preserving both its head and its tail. */
export function truncateOutput(text: string, maxChars: number): { text: string; truncated: boolean } {
  if (text.length <= maxChars) return { text, truncated: false }
  const head = Math.floor(maxChars * 0.6)
  const tail = maxChars - head
  const marker = `\n... [output truncated: ${text.length - maxChars} characters removed] ...\n`
  return {
    text: text.slice(0, head) + marker + text.slice(-tail),
    truncated: true,
  }
}

const WINDOWS_EXECUTABLE_EXTENSIONS = ['', '.exe', '.cmd', '.bat', '.com']

/** Whether a path exists and is runnable in this environment. */
function isExecutableFile(file: string): boolean {
  if (!existsSync(file)) return false
  if (process.platform !== 'win32') {
    try {
      accessSync(file, fsConstants.X_OK)
    } catch {
      return false
    }
  }
  return true
}

/**
 * Resolve a command to an executable path: absolute/relative paths are checked
 * directly (with PATHEXT-style extension probing on Windows); bare names are
 * searched on PATH the way the platform shells would find them.
 * @param candidate - the configured or derived executable reference.
 * @returns the resolved path, or null when nothing matches.
 */
export function resolveExecutable(candidate: string): string | null {
  if (candidate.includes('/') || candidate.includes('\\')) {
    if (isExecutableFile(candidate)) return candidate
    if (process.platform === 'win32' && path.extname(candidate) === '') {
      for (const ext of WINDOWS_EXECUTABLE_EXTENSIONS.slice(1)) {
        const withExt = candidate + ext
        if (isExecutableFile(withExt)) return withExt
      }
    }
    return null
  }
  const dirs = (process.env.PATH ?? '').split(path.delimiter).filter(Boolean)
  const extensions = process.platform === 'win32' ? WINDOWS_EXECUTABLE_EXTENSIONS : ['']
  for (const dir of dirs) {
    for (const ext of extensions) {
      const full = path.join(dir, candidate + ext)
      if (isExecutableFile(full)) return full
    }
  }
  return null
}

/** Kill a child process and its whole tree. */
function killTree(child: ChildProcess): void {
  if (child.pid === undefined) return
  if (process.platform === 'win32') {
    // taskkill /T walks the tree; /F forces termination of GUI tools like
    // MATLAB or Vivado that ignore plain child.kill().
    spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true })
  } else {
    try {
      // detached: true makes the child a process-group leader, so a negative
      // pid kills the whole group.
      process.kill(-child.pid, 'SIGKILL')
    } catch {
      // The group is already gone.
    }
  }
}

/**
 * Run one executable with bounded capture, a cooperative timeout, and caller
 * cancellation. A missing executable, an already-aborted signal, or an abort
 * firing mid-run REJECTS; timeouts and non-zero exits are ordinary domain
 * outcomes carried in the result value.
 * @param options - run configuration.
 * @returns the canonical {@link RunResult}.
 */
export function runProcess(options: RunOptions): Promise<RunResult> {
  const { command, args, cwd, timeoutMs, signal, maxOutputChars } = options
  const resolved = resolveExecutable(command)
  if (resolved === null) {
    return Promise.reject(new Error(`cannot resolve executable: ${JSON.stringify(command)}`))
  }
  if (signal.aborted) {
    return Promise.reject(new Error('tool call cancelled before the process started'))
  }
  const needsCmdWrapper = process.platform === 'win32' && /\.(bat|cmd)$/i.test(resolved)
  let cmd: string
  let cmdArgs: string[]
  if (needsCmdWrapper) {
    // cmd /c parses its remaining argv as one command line, so the resolved
    // executable is passed as a BARE element and Node quotes it (and every
    // space-containing argument) with its own Win32 joiner. Manually embedded
    // quotes must never be used: Node escapes them to \" which cmd rejects.
    cmd = 'cmd'
    cmdArgs = ['/d', '/s', '/c', resolved, ...args]
  } else {
    cmd = resolved
    cmdArgs = args
  }

  return new Promise<RunResult>((resolve, reject) => {
    const start = Date.now()
    let stdout = ''
    let stderr = ''
    let settled = false
    let timedOut = false
    let timer: NodeJS.Timeout | undefined
    const child = spawn(cmd, cmdArgs, {
      cwd,
      windowsHide: true,
      ...(process.platform !== 'win32' ? { detached: true } : {}),
    })

    const budget = (stream: string, chunk: string): string => {
      const next = stream + chunk
      // Bound memory while the process is alive; the final cap is applied at
      // settle time. 2x the budget keeps the head/tail window representative.
      return next.length > maxOutputChars * 2 ? next.slice(-maxOutputChars * 2) : next
    }
    child.stdout?.on('data', (chunk: Buffer) => { stdout = budget(stdout, chunk.toString()) })
    child.stderr?.on('data', (chunk: Buffer) => { stderr = budget(stderr, chunk.toString()) })

    const onAbort = (): void => {
      if (settled) return
      killTree(child)
      settle(new Error('tool call cancelled'))
    }
    signal.addEventListener('abort', onAbort, { once: true })

    const settle = (outcome: RunResult | Error): void => {
      if (settled) return
      settled = true
      if (timer !== undefined) clearTimeout(timer)
      signal.removeEventListener('abort', onAbort)
      if (outcome instanceof Error) reject(outcome)
      else resolve(outcome)
    }

    child.on('error', (error: NodeJS.ErrnoException) => {
      // Spawn-level failures (permissions, invalid cwd, ...). A missing
      // executable is normally caught by resolveExecutable before spawning.
      settle(new Error(`failed to start ${JSON.stringify(command)}: ${error.message}`))
    })

    child.on('close', (code, _closeSignal) => {
      const head = truncateOutput(stdout, maxOutputChars)
      const tail = truncateOutput(stderr, maxOutputChars)
      if (timedOut) {
        settle({
          exitCode: null,
          timedOut: true,
          durationMs: Date.now() - start,
          stdout: head.text,
          stderr: tail.text,
          truncated: head.truncated || tail.truncated,
        })
        return
      }
      settle({
        exitCode: code,
        timedOut: false,
        durationMs: Date.now() - start,
        stdout: head.text,
        stderr: tail.text,
        truncated: head.truncated || tail.truncated,
        // closeSignal is deliberately unused: a timed-out/aborted kill is
        // reported through timedOut or the rejection, and a spontaneous
        // signal death still surfaces as exitCode null.
      })
    })

    timer = setTimeout(() => {
      timedOut = true
      killTree(child)
    }, timeoutMs)
  })
}

/**
 * Resolve one ModelSim-family executable (vsim/vlog/vcom/vlib) from the
 * configured `modelsimPath`, which may be a bare name, a full path to vsim,
 * or a bin directory.
 * @param modelsimPath - the configured ModelSim reference.
 * @param tool - the sibling executable to derive.
 * @returns the derived reference (bare names stay bare; resolution happens at run time).
 */
export function deriveModelSimTool(modelsimPath: string, tool: 'vsim' | 'vlog' | 'vcom' | 'vlib'): string {
  if (modelsimPath.includes('/') || modelsimPath.includes('\\')) {
    if (existsSync(modelsimPath) && !/\.(exe|cmd|bat)$/i.test(modelsimPath)) {
      // A bin directory: join the tool name directly.
      return path.join(modelsimPath, tool + (process.platform === 'win32' ? '.exe' : ''))
    }
    const base = path.basename(modelsimPath)
    const stem = base.replace(/\.[^.]+$/, '')
    if (stem.startsWith('vsim')) {
      return path.join(path.dirname(modelsimPath), stem.replace(/^vsim/, tool) + path.extname(base))
    }
    // A full path to some other executable: fall back to the same dir + tool.
    return path.join(path.dirname(modelsimPath), tool + (process.platform === 'win32' ? '.exe' : ''))
  }
  return modelsimPath.replace(/^vsim/, tool)
}
