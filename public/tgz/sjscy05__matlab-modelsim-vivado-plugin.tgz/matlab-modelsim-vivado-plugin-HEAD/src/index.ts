/**
 * mmv-dspic: MATLAB + ModelSim + Vivado full-flow tools for digital
 * communication IC design tasks. The seven `mmv_*` tools let an agent run a
 * complete design cycle — algorithm modeling in MATLAB, RTL compile and
 * simulation in ModelSim, and synthesis/implementation/bitstream in Vivado —
 * entirely through configured local toolchains.
 * @module mmv-dspic
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { defineCheckEnvTool } from './tools/check-env.ts'
import { defineProjectInitTool } from './tools/project-init.ts'
import { defineMatlabRunTool } from './tools/matlab.ts'
import { defineModelsimCompileTool } from './tools/modelsim-compile.ts'
import { defineModelsimSimulateTool } from './tools/modelsim-simulate.ts'
import { defineVivadoRunTool } from './tools/vivado-run.ts'
import { defineVivadoFlowTool } from './tools/vivado-flow.ts'

export const name = 'mmv-dspic'
export const inject = ['tools']

/** Deployment-varying executable paths and run budgets for the toolchain tools. */
export interface Config {
  /**
   * MATLAB executable: a bare PATH name or an absolute path. `matlab -batch`
   * (R2019a or newer) drives every run.
   */
  matlabPath: string
  /**
   * ModelSim reference: a bare PATH name (default), an absolute path to vsim,
   * or a bin directory; the sibling vlog/vcom/vlib executables are derived
   * from it.
   */
  modelsimPath: string
  /**
   * Vivado executable: a bare PATH name or an absolute path; on Windows a
   * resolved .bat/.cmd is invoked through cmd.
   */
  vivadoPath: string
  /**
   * Working directory for tool runs; empty uses the harness process directory.
   * Relative values resolve against it.
   */
  workdir: string
  /** Default per-run budget in milliseconds unless a call passes timeoutMs. */
  timeoutMs: number
  /** Per-stream cap on captured stdout/stderr characters. */
  maxOutputChars: number
}

/** Schemastery configuration for the mmv-dspic plugin. */
export const Config: z<Config> = z.object({
  matlabPath: z.string().default('matlab'),
  modelsimPath: z.string().default('vsim'),
  vivadoPath: z.string().default('vivado'),
  workdir: z.string().default(''),
  timeoutMs: z.natural().min(1000).default(600000),
  maxOutputChars: z.natural().min(1000).default(40000),
})

/**
 * Register the seven `mmv_*` tools on the tool registry.
 * @param ctx - registrant context carrying the tool registry.
 * @param config - deployment toolchain configuration.
 */
export function apply(ctx: Context, config: Config): void {
  console.log('[mmv-dspic] plugin loaded (matlab=%s modelsim=%s vivado=%s)', config.matlabPath, config.modelsimPath, config.vivadoPath)
  const definitions = [
    defineCheckEnvTool(config),
    defineProjectInitTool(config),
    defineMatlabRunTool(config),
    defineModelsimCompileTool(config),
    defineModelsimSimulateTool(config),
    defineVivadoRunTool(config),
    defineVivadoFlowTool(config),
  ]
  for (const definition of definitions) {
    ctx.tools.register(definition)
  }
}
