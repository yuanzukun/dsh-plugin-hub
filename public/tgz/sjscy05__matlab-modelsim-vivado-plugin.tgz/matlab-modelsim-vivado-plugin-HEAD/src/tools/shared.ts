/**
 * Shared pieces for the mmv-dspic run tools: the canonical run-output schema,
 * argument/cwd/timeout resolution, and terminal-card presentation helpers.
 * @module mmv-dspic/tools/shared
 */

import path from 'node:path'
import type { TerminalCallView, TerminalResultView, ToolResult } from '@deepseek-ai/dsh-tools'
import type { RunResult } from '../run.ts'
import type { Config } from '../index.ts'

/** Optional `cwd` parameter shared by every run tool. */
export const CWD_PARAM = {
  type: 'string',
  description: 'Working directory for the run. Relative values resolve against the harness process directory; omitted uses the plugin `workdir` config, then the harness directory.',
} as const

/** Optional `timeoutMs` parameter shared by every run tool. */
export const TIMEOUT_PARAM = {
  type: 'integer',
  description: 'Wall-clock budget in milliseconds for this run; the process tree is killed on expiry. Omitted uses the plugin `timeoutMs` config.',
} as const

/** The canonical value schema for one process run. */
export const RUN_OUTPUT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    exitCode: {
      required: true,
      oneOf: [
        { type: 'integer', description: 'Process exit code when the run ended by exiting.' },
        { type: 'null', description: 'The run was killed by timeout or signal.' },
      ],
    },
    timedOut: { type: 'boolean', required: true, description: 'Whether the timeout budget killed the run.' },
    durationMs: { type: 'integer', required: true, description: 'Wall-clock duration of the run in milliseconds.' },
    stdout: { type: 'string', required: true, description: 'Captured standard output, capped at the plugin `maxOutputChars` budget.' },
    stderr: { type: 'string', required: true, description: 'Captured standard error, capped at the plugin `maxOutputChars` budget.' },
    truncated: { type: 'boolean', required: true, description: 'Whether either captured stream was truncated to its budget.' },
  },
} as const

/** The inferred canonical value of {@link RUN_OUTPUT_SCHEMA}. */
export interface RunOutputValue extends RunResult {}

/** Common run-tool arguments. */
export interface RunToolArgs {
  cwd?: string
  timeoutMs?: number
}

/**
 * Resolve the effective working directory for a run: the per-call `cwd` wins,
 * then the plugin `workdir` config, then the harness process directory
 * (undefined keeps the child on the parent cwd).
 * @param cwd - per-call working directory, if any.
 * @param workdir - configured plugin working directory.
 * @returns the absolute working directory, or undefined to inherit.
 */
export function resolveCwd(cwd: string | undefined, workdir: string): string | undefined {
  const base = cwd ?? workdir
  if (base === undefined || base.trim() === '') return undefined
  return path.resolve(process.cwd(), base)
}

/**
 * Resolve the effective per-run timeout, validating the per-call override.
 * @param timeoutMs - per-call override, if any.
 * @param configTimeoutMs - configured plugin budget.
 * @returns the positive budget to use.
 */
export function resolveTimeoutMs(timeoutMs: number | undefined, configTimeoutMs: number): number {
  if (timeoutMs !== undefined) {
    if (!Number.isInteger(timeoutMs) || timeoutMs <= 0) {
      throw new Error('timeoutMs must be a positive integer')
    }
    return timeoutMs
  }
  return configTimeoutMs
}

/** Resolve a possibly-relative file path against the run working directory. */
export function resolvePath(file: string, cwd: string | undefined): string {
  return path.resolve(cwd ?? process.cwd(), file)
}

/** One-line model-facing summary of a run result. */
export function describeRun(value: RunOutputValue): string {
  const status = value.timedOut
    ? 'timed out'
    : value.exitCode === null
      ? 'killed'
      : `exit code ${value.exitCode}`
  const parts = [`status: ${status}`, `duration: ${value.durationMs} ms`]
  if (value.truncated) parts.push('output truncated to the configured budget')
  return parts.join(' · ')
}

/** Model-facing text renderer for a run result (header + both streams). */
export function renderRun(value: RunOutputValue): string {
  const body = [describeRun(value)]
  if (value.stdout.length > 0) body.push('--- stdout ---', value.stdout)
  if (value.stderr.length > 0) body.push('--- stderr ---', value.stderr)
  return body.join('\n')
}

/** Small replayable metadata projected onto `tool/result` for run tools. */
export function runPresentationMeta(value: RunOutputValue): {
  exitCode: number | null
  timedOut: boolean
  durationMs: number
  truncated: boolean
} {
  return {
    exitCode: value.exitCode,
    timedOut: value.timedOut,
    durationMs: value.durationMs,
    truncated: value.truncated,
  }
}

/**
 * Completed-state terminal view for a run result. The output text is the
 * model-facing render (status header plus both streams) so a replay without
 * the canonical value still shows everything; the exit-code pill comes from
 * the persisted meta.
 * @param args - ignored; presentation is a pure function of the result.
 * @param result - the durable result projection.
 * @returns the terminal view, or undefined for failed calls.
 */
export function runPresentResult(_args: unknown, result: ToolResult): TerminalResultView | undefined {
  if (result.isError) return undefined
  const meta = result.meta as { exitCode?: number | null } | undefined
  const output = result.content
    .filter(block => block.type === 'text')
    .map(block => block.text)
    .join('\n')
  const exitCode = meta?.exitCode
  return {
    card: 'terminal',
    output,
    ...(typeof exitCode === 'number' ? { exitCode } : {}),
  }
}

/** Pending-state terminal view for one run command. */
export function runPresentCall(title: string, cwd: string | undefined): TerminalCallView {
  return {
    card: 'terminal',
    title,
    ...(cwd !== undefined ? { cwd } : {}),
  }
}

/** Resolve the per-tool working directory from tool arguments. */
export function toolCwd(args: RunToolArgs, config: Config): string | undefined {
  return resolveCwd(args.cwd, config.workdir)
}
