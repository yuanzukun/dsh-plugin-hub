/**
 * `mmv_project_init`: scaffold a standard digital-communication IC design
 * workspace (matlab/rtl/sim/scripts/reports) with optional starter templates.
 * @module mmv-dspic/tools/project-init
 */

import { mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { DiffCallView, DiffResultView, ToolDefinition } from '@deepseek-ai/dsh-tools'
import { buildDoFile, buildFlowTcl, buildProjectReadme } from '../templates.ts'
import type { Config } from '../index.ts'
import { resolvePath, toolCwd } from './shared.ts'

/** Subdirectories every scaffolded workspace gets. */
const SUBDIRS = ['matlab', 'rtl', 'sim', 'scripts', 'reports'] as const

/** Starter template files written when `templates` is requested. */
const TEMPLATE_FILES: ReadonlyArray<{ path: string; content: () => string }> = [
  {
    path: path.join('sim', 'run.do'),
    content: () => buildDoFile([
      'vlib work',
      'vlog -work work ../rtl/*.sv',
      'vsim -c work.tb_top',
      'run -all',
    ], true),
  },
  {
    path: path.join('scripts', 'flow.tcl'),
    content: () => buildFlowTcl({
      top: 'top',
      part: 'xc7a35tcsg324-1',
      outDir: 'vivado_out',
      verilog: ['../rtl/*.v', '../rtl/*.sv'],
      vhdl: [],
      constraints: [],
      steps: ['synthesis', 'implementation', 'bitstream'],
    }),
  },
]

/** The diff presentation for the files a scaffold call creates. */
function scaffoldDiffs(dir: string, withTemplates: boolean): { path: string; oldText: null; newText: string }[] {
  const diffs: { path: string; oldText: null; newText: string }[] = [{
    path: path.join(dir, 'README.md'),
    oldText: null,
    newText: buildProjectReadme(path.basename(dir)),
  }]
  if (withTemplates) {
    for (const file of TEMPLATE_FILES) {
      diffs.push({ path: path.join(dir, file.path), oldText: null, newText: file.content() })
    }
  }
  return diffs
}

/**
 * Define the `mmv_project_init` tool for one plugin configuration.
 * @param config - the plugin configuration whose `workdir` anchors relative `dir` values.
 * @returns the registry-ready tool definition.
 */
export function defineProjectInitTool(config: Config): ToolDefinition {
  return defineTool({
    name: 'mmv_project_init',
    description: 'Scaffold a digital-communication IC design workspace: create matlab/, rtl/, sim/, scripts/, and reports/ directories plus a README describing the MATLAB → ModelSim → Vivado flow. With `templates`, also write a starter ModelSim do-file and a Vivado batch Tcl flow. Use once at the beginning of a design task to give every later file a stable home.',
    parameters: {
      dir: {
        type: 'string',
        required: true,
        description: 'Directory to scaffold. Relative values resolve against the harness process directory; an existing non-empty directory is left intact (missing pieces are created).',
      },
      templates: {
        type: 'boolean',
        description: 'Whether to write starter sim/run.do and scripts/flow.tcl templates (default true).',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          dir: { type: 'string', required: true, description: 'Absolute scaffolded directory.' },
          created: {
            type: 'array',
            required: true,
            description: 'Absolute paths of every created directory and file, in creation order.',
            items: { type: 'string' },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: `Scaffolded ${value.dir}\n${value.created.map(p => `  created ${p}`).join('\n')}`,
      }],
      presentationMeta: (_args, value) => ({ dir: value.dir, created: value.created }),
    },
    async execute(args, _exec) {
      const dir = args.dir.trim()
      if (dir.length === 0) throw new Error('dir must be a non-empty path')
      const withTemplates = args.templates ?? true
      const abs = resolvePath(dir, toolCwd({}, config))
      const created: string[] = []
      const dirs = [...SUBDIRS, 'sim', 'scripts']
      for (const sub of dirs) {
        const target = path.join(abs, sub)
        await mkdir(target, { recursive: true })
        created.push(target)
      }
      const files: { path: string; content: string }[] = [{
        path: path.join(abs, 'README.md'),
        content: buildProjectReadme(path.basename(abs)),
      }]
      if (withTemplates) {
        for (const file of TEMPLATE_FILES) {
          files.push({ path: path.join(abs, file.path), content: file.content() })
        }
      }
      for (const file of files) {
        await writeFile(file.path, file.content, 'utf8')
        created.push(file.path)
      }
      return { dir: abs, created }
    },
    presentCall: args => ({
      card: 'diff',
      title: `Scaffold project ${args.dir}`,
      diffs: scaffoldDiffs(args.dir, args.templates ?? true),
    }) satisfies DiffCallView,
    presentResult: (args, result): DiffResultView | undefined => {
      if (result.isError) return undefined
      return {
        card: 'diff',
        diffs: scaffoldDiffs(args.dir, args.templates ?? true),
      }
    },
  })
}
