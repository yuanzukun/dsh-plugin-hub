/**
 * `mmv_matlab_run`: execute a MATLAB script or inline expression in batch
 * mode (`matlab -batch`), capturing stdout/stderr with a cooperative timeout.
 * @module mmv-dspic/tools/matlab
 */

import { existsSync } from 'node:fs'
import path from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import { runProcess } from '../run.ts'
import type { Config } from '../index.ts'
import {
  CWD_PARAM,
  RUN_OUTPUT_SCHEMA,
  TIMEOUT_PARAM,
  renderRun,
  resolvePath,
  resolveTimeoutMs,
  runPresentCall,
  runPresentResult,
  runPresentationMeta,
  toolCwd,
} from './shared.ts'

/** Escape a path for embedding in a MATLAB single-quoted string. */
function matlabString(value: string): string {
  return value.replace(/'/g, "''")
}

/**
 * Define the `mmv_matlab_run` tool for one plugin configuration.
 * @param config - the plugin configuration carrying `matlabPath`.
 * @returns the registry-ready tool definition.
 */
export function defineMatlabRunTool(config: Config): ToolDefinition {
  return defineTool({
    name: 'mmv_matlab_run',
    description: 'Run MATLAB in batch mode (`matlab -batch`): execute an .m script file with `mFile`, or inline MATLAB code with `expression` (exactly one is required). Capture stdout/stderr and report the exit code. Use it for algorithm modeling and reference simulation in a digital-communication IC flow: derive filter coefficients, simulate BER/EVN curves, or produce fixed-point references that RTL testbenches cross-check against.',
    parameters: {
      mFile: {
        type: 'string',
        description: 'Path to a .m script to execute via run(); exactly one of mFile/expression is required.',
      },
      expression: {
        type: 'string',
        description: 'Inline MATLAB code to execute; exactly one of mFile/expression is required.',
      },
      cwd: CWD_PARAM,
      timeoutMs: TIMEOUT_PARAM,
    },
    output: {
      schema: RUN_OUTPUT_SCHEMA,
      render: (_args, value) => [{ type: 'text', text: renderRun(value) }],
      presentationMeta: (_args, value) => runPresentationMeta(value),
    },
    async execute(args, exec) {
      const mFile = args.mFile?.trim() ?? ''
      const expression = args.expression?.trim() ?? ''
      const provided = (mFile.length > 0 ? 1 : 0) + (expression.length > 0 ? 1 : 0)
      if (provided !== 1) {
        throw new Error('exactly one of mFile/expression must be provided')
      }
      const cwd = toolCwd(args, config)
      const timeoutMs = resolveTimeoutMs(args.timeoutMs, config.timeoutMs)
      let statement: string
      if (expression.length > 0) {
        statement = expression
      } else {
        const abs = resolvePath(mFile, cwd)
        if (!existsSync(abs)) throw new Error(`mFile not found: ${abs}`)
        statement = `run('${matlabString(abs.replaceAll(path.sep, '/'))}')`
      }
      const result = await runProcess({
        command: config.matlabPath,
        args: ['-batch', statement],
        cwd,
        timeoutMs,
        signal: exec.signal,
        maxOutputChars: config.maxOutputChars,
      })
      return result
    },
    presentCall: args => {
      const statement = args.mFile !== undefined ? `run('${args.mFile}')` : (args.expression ?? '')
      return runPresentCall(`matlab -batch ${statement}`, toolCwd(args, config))
    },
    presentResult: runPresentResult,
  })
}
