/**
 * `mmv_check_env`: resolve each configured EDA executable and probe its
 * version, reporting availability without failing the call — a missing tool
 * is a domain outcome, not an error.
 * @module mmv-dspic/tools/check-env
 */

import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import { deriveModelSimTool, resolveExecutable, runProcess } from '../run.ts'
import type { Config } from '../index.ts'
import { resolveTimeoutMs } from './shared.ts'

/** The three toolchains the plugin drives. */
export const TOOLCHAINS = ['matlab', 'modelsim', 'vivado'] as const

/** One toolchain's availability report. */
export interface EnvCheck {
  /** Toolchain name. */
  tool: (typeof TOOLCHAINS)[number]
  /** Whether the executable resolved and its version probe ran. */
  found: boolean
  /** The resolved executable path (or the configured reference when unresolvable). */
  command: string
  /** First non-empty probe output line, when the probe succeeded. */
  version?: string
  /** Human-readable failure detail, when the tool is unavailable. */
  error?: string
}

/** Probe invocation for one toolchain; returns its version text or null. */
async function probeVersion(
  command: string,
  args: string[],
  timeoutMs: number,
  signal: AbortSignal,
  maxOutputChars: number,
): Promise<string | null> {
  const result = await runProcess({ command, args, timeoutMs, signal, maxOutputChars })
  if (result.exitCode !== 0 || result.timedOut) return null
  const line = result.stdout.split(/\r?\n/).find(line => line.trim().length > 0)
  return line === undefined ? null : line.trim()
}

/**
 * Define the `mmv_check_env` tool for one plugin configuration.
 * @param config - the plugin configuration carrying the executable paths.
 * @returns the registry-ready tool definition.
 */
export function defineCheckEnvTool(config: Config): ToolDefinition {
  return defineTool({
    name: 'mmv_check_env',
    description: 'Probe the configured MATLAB, ModelSim, and Vivado installations: resolve each executable and capture its version banner. Call this once at the start of a design flow so the model knows which toolchains are available before planning MATLAB/ModelSim/Vivado steps.',
    parameters: {
      tools: {
        type: 'array',
        description: 'Toolchains to probe; omitted probes all three.',
        items: { type: 'string', enum: TOOLCHAINS },
      },
      timeoutMs: {
        type: 'integer',
        description: 'Per-probe budget in milliseconds; omitted uses the plugin `timeoutMs` config.',
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          checks: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                tool: { type: 'string', required: true, enum: TOOLCHAINS },
                found: { type: 'boolean', required: true },
                command: { type: 'string', required: true },
                version: { type: 'string' },
                error: { type: 'string' },
              },
            },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: value.checks
          .map(check => {
            const status = check.found
              ? `OK${check.version === undefined ? '' : ` (${check.version})`}`
              : `MISSING${check.error === undefined ? '' : ` — ${check.error}`}`
            return `${check.tool}: ${status} — ${check.command}`
          })
          .join('\n'),
      }],
    },
    async execute(args, exec) {
      const timeoutMs = resolveTimeoutMs(args.timeoutMs, config.timeoutMs)
      const requested = args.tools ?? TOOLCHAINS
      const checks: EnvCheck[] = []
      for (const tool of requested) {
        const reference = tool === 'matlab'
          ? config.matlabPath
          : tool === 'modelsim'
            ? deriveModelSimTool(config.modelsimPath, 'vsim')
            : config.vivadoPath
        const resolved = resolveExecutable(reference)
        if (resolved === null) {
          checks.push({
            tool,
            found: false,
            command: reference,
            error: `executable not found (checked PATH and the configured path ${JSON.stringify(reference)})`,
          })
          continue
        }
        const probe = tool === 'matlab'
          ? { command: resolved, args: ['-batch', 'disp(version("-release"))'] }
          : { command: resolved, args: ['-version'] }
        try {
          const version = await probeVersion(
            probe.command, probe.args, timeoutMs, exec.signal, config.maxOutputChars,
          )
          checks.push({
            tool,
            found: version !== null,
            command: resolved,
            ...(version !== null ? { version } : { error: 'version probe failed or timed out' }),
          })
        } catch (error) {
          checks.push({
            tool,
            found: false,
            command: resolved,
            error: error instanceof Error ? error.message : String(error),
          })
        }
      }
      return { checks }
    },
    presentCall: args => ({
      card: 'generic',
      title: 'Probe EDA toolchains',
      kind: 'search',
      rawInput: args.tools ?? TOOLCHAINS,
    }),
    presentResult: (_args, result) => {
      if (result.isError) return undefined
      const text = result.content.filter(b => b.type === 'text').map(b => b.text).join('\n')
      return { card: 'generic', title: 'EDA toolchains probed', content: [{ type: 'text', text }] }
    },
  })
}
