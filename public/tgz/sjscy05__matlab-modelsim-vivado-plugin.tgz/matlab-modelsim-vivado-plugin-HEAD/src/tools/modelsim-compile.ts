/**
 * `mmv_modelsim_compile`: compile Verilog/SystemVerilog (vlog) and/or VHDL
 * (vcom) sources into a ModelSim work library.
 * @module mmv-dspic/tools/modelsim-compile
 */

import { existsSync } from 'node:fs'
import { rm } from 'node:fs/promises'
import path from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import { deriveModelSimTool, runProcess } from '../run.ts'
import type { RunResult } from '../run.ts'
import type { Config } from '../index.ts'
import {
  CWD_PARAM,
  RUN_OUTPUT_SCHEMA,
  TIMEOUT_PARAM,
  renderRun,
  resolvePath,
  resolveTimeoutMs,
  runPresentCall,
  runPresentResult,
  runPresentationMeta,
  toolCwd,
} from './shared.ts'

const LANGUAGES = ['auto', 'verilog', 'vhdl'] as const

/** Per-file language classification. */
function classify(file: string): 'verilog' | 'vhdl' | null {
  const ext = path.extname(file).toLowerCase()
  if (ext === '.v' || ext === '.sv' || ext === '.svh') return 'verilog'
  if (ext === '.vhd' || ext === '.vhdl') return 'vhdl'
  return null
}

/** One executed compiler step and its display label. */
interface LabeledRun {
  label: 'vlib' | 'vlog' | 'vcom'
  result: RunResult
}

/** Merge sequential runs into one canonical run result. */
function mergeRuns(runs: LabeledRun[]): RunResult {
  if (runs.length === 1) return runs[0]!.result
  const timedOut = runs.some(run => run.result.timedOut)
  const truncated = runs.some(run => run.result.truncated)
  const exitCode = timedOut
    ? null
    : runs.some(run => run.result.exitCode !== 0)
      ? 1
      : 0
  const stream = (pick: (run: RunResult) => string): string =>
    runs.map((run, index) => {
      const body = pick(run.result)
      return body.length === 0 ? '' : `--- step ${index + 1} (${run.label}) ---\n${body}`
    }).filter(Boolean).join('\n')
  return {
    exitCode,
    timedOut,
    durationMs: runs.reduce((sum, run) => sum + run.result.durationMs, 0),
    stdout: stream(run => run.stdout),
    stderr: stream(run => run.stderr),
    truncated,
  }
}

/**
 * Define the `mmv_modelsim_compile` tool for one plugin configuration.
 * @param config - the plugin configuration carrying `modelsimPath`.
 * @returns the registry-ready tool definition.
 */
export function defineModelsimCompileTool(config: Config): ToolDefinition {
  return defineTool({
    name: 'mmv_modelsim_compile',
    description: 'Compile HDL sources into a ModelSim library: Verilog/SystemVerilog sources go through vlog, VHDL through vcom, and the library is created with vlib when missing. Run this before mmv_modelsim_simulate so the testbench and design units exist in the work library. Use the same working directory as the later simulate call so the library resolves.',
    parameters: {
      sources: {
        type: 'array',
        required: true,
        description: 'HDL source files to compile (relative to cwd), e.g. rtl/*.sv or sim/tb_top.sv. Extensions: .v/.sv/.svh → vlog, .vhd/.vhdl → vcom.',
        items: { type: 'string' },
      },
      work: {
        type: 'string',
        description: 'Library name to compile into (default "work").',
      },
      language: {
        type: 'string',
        enum: LANGUAGES,
        description: 'Force one compiler for every source; auto (default) picks vlog/vcom per file extension.',
      },
      defines: {
        type: 'array',
        description: 'Verilog `+define+NAME[=VALUE]` tokens (vlog only), e.g. ["WIDTH=16"].',
        items: { type: 'string' },
      },
      includeDirs: {
        type: 'array',
        description: 'Verilog `+incdir+` search directories (vlog only).',
        items: { type: 'string' },
      },
      fresh: {
        type: 'boolean',
        description: 'Delete the library directory and recreate it before compiling (default false).',
      },
      cwd: CWD_PARAM,
      timeoutMs: TIMEOUT_PARAM,
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ...RUN_OUTPUT_SCHEMA.properties,
          compiledFiles: {
            type: 'array',
            required: true,
            description: 'Absolute paths of the successfully submitted source files.',
            items: { type: 'string' },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: `${renderRun(value)}\ncompiled ${value.compiledFiles.length} file(s)`,
      }],
      presentationMeta: (_args, value) => ({ ...runPresentationMeta(value), compiledFiles: value.compiledFiles }),
    },
    async execute(args, exec) {
      if (args.sources.length === 0) throw new Error('sources must be a non-empty array')
      const language = args.language ?? 'auto'
      const work = (args.work ?? 'work').trim()
      if (work.length === 0) throw new Error('work must be a non-empty library name')
      const cwd = toolCwd(args, config)
      const timeoutMs = resolveTimeoutMs(args.timeoutMs, config.timeoutMs)
      const absSources = args.sources.map(source => {
        if (source.trim().length === 0) throw new Error('source paths must be non-empty')
        const abs = resolvePath(source, cwd)
        if (!existsSync(abs)) throw new Error(`source not found: ${abs}`)
        return abs
      })
      const classified = absSources.map((source, index) => {
        const kind = language === 'auto' ? classify(source) : language
        if (kind === null) {
          throw new Error(`cannot determine language of ${JSON.stringify(args.sources[index])}; pass language "verilog" or "vhdl"`)
        }
        return { source, kind }
      })
      const verilog = classified.filter(entry => entry.kind === 'verilog').map(entry => entry.source)
      const vhdl = classified.filter(entry => entry.kind === 'vhdl').map(entry => entry.source)
      const libDir = path.join(cwd ?? process.cwd(), work)
      if (args.fresh) {
        await rm(libDir, { recursive: true, force: true })
      }
      const runs: LabeledRun[] = []
      if (!existsSync(libDir)) {
        const vlib = deriveModelSimTool(config.modelsimPath, 'vlib')
        const created = await runProcess({
          command: vlib,
          args: [work],
          cwd,
          timeoutMs,
          signal: exec.signal,
          maxOutputChars: config.maxOutputChars,
        })
        if (created.exitCode !== 0 || created.timedOut) {
          return { ...created, compiledFiles: [] }
        }
        runs.push({ label: 'vlib', result: created })
      }
      if (verilog.length > 0) {
        const vlog = deriveModelSimTool(config.modelsimPath, 'vlog')
        const defines = (args.defines ?? []).map(def => def.startsWith('+define+') ? def : `+define+${def}`)
        const incdirs = (args.includeDirs ?? []).map(dir => `+incdir+${dir}`)
        runs.push({
          label: 'vlog',
          result: await runProcess({
            command: vlog,
            args: ['-work', work, ...defines, ...incdirs, ...verilog],
            cwd,
            timeoutMs,
            signal: exec.signal,
            maxOutputChars: config.maxOutputChars,
          }),
        })
      }
      if (vhdl.length > 0) {
        const vcom = deriveModelSimTool(config.modelsimPath, 'vcom')
        runs.push({
          label: 'vcom',
          result: await runProcess({
            command: vcom,
            args: ['-work', work, ...vhdl],
            cwd,
            timeoutMs,
            signal: exec.signal,
            maxOutputChars: config.maxOutputChars,
          }),
        })
      }
      return { ...mergeRuns(runs), compiledFiles: absSources }
    },
    presentCall: args => {
      const work = args.work ?? 'work'
      const command = args.language === 'vhdl'
        ? `vcom -work ${work} ${args.sources.join(' ')}`
        : `vlog -work ${work} ${args.sources.join(' ')}`
      return runPresentCall(command, toolCwd(args, config))
    },
    presentResult: runPresentResult,
  })
}
