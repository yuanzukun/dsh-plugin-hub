/**
 * `mmv_vivado_run`: execute a Vivado Tcl script in batch mode and capture the
 * run log.
 * @module mmv-dspic/tools/vivado-run
 */

import { existsSync } from 'node:fs'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import { runProcess } from '../run.ts'
import type { Config } from '../index.ts'
import {
  CWD_PARAM,
  RUN_OUTPUT_SCHEMA,
  TIMEOUT_PARAM,
  renderRun,
  resolvePath,
  resolveTimeoutMs,
  runPresentCall,
  runPresentResult,
  runPresentationMeta,
  toolCwd,
} from './shared.ts'

/**
 * Define the `mmv_vivado_run` tool for one plugin configuration.
 * @param config - the plugin configuration carrying `vivadoPath`.
 * @returns the registry-ready tool definition.
 */
export function defineVivadoRunTool(config: Config): ToolDefinition {
  return defineTool({
    name: 'mmv_vivado_run',
    description: 'Run a Vivado Tcl script in batch mode (`vivado -mode batch -notrace -source <script>`) and capture the run log. Use it for ad-hoc Tcl steps (reading reports, running analysis commands) or for a hand-written flow; for the standard synthesis → implementation → bitstream pipeline prefer mmv_vivado_flow, which generates the Tcl for you.',
    parameters: {
      script: {
        type: 'string',
        required: true,
        description: 'Path to the Tcl script to run (relative to cwd).',
      },
      args: {
        type: 'array',
        description: 'Extra arguments forwarded after the script via `-tclargs`; read inside Tcl through $argv/$argc.',
        items: { type: 'string' },
      },
      cwd: CWD_PARAM,
      timeoutMs: TIMEOUT_PARAM,
    },
    output: {
      schema: RUN_OUTPUT_SCHEMA,
      render: (_args, value) => [{ type: 'text', text: renderRun(value) }],
      presentationMeta: (_args, value) => runPresentationMeta(value),
    },
    async execute(args, exec) {
      const script = args.script.trim()
      if (script.length === 0) throw new Error('script must be a non-empty path')
      const cwd = toolCwd(args, config)
      const timeoutMs = resolveTimeoutMs(args.timeoutMs, config.timeoutMs)
      const abs = resolvePath(script, cwd)
      if (!existsSync(abs)) throw new Error(`script not found: ${abs}`)
      const extra = args.args ?? []
      return await runProcess({
        command: config.vivadoPath,
        args: ['-mode', 'batch', '-notrace', '-source', abs, ...(extra.length > 0 ? ['-tclargs', ...extra] : [])],
        cwd,
        timeoutMs,
        signal: exec.signal,
        maxOutputChars: config.maxOutputChars,
      })
    },
    presentCall: args => runPresentCall(`vivado -mode batch -notrace -source ${args.script}`, toolCwd(args, config)),
    presentResult: runPresentResult,
  })
}
