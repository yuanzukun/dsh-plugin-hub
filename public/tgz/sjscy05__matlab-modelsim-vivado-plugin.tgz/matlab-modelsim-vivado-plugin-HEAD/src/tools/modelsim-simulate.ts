/**
 * `mmv_modelsim_simulate`: run a ModelSim batch simulation (vsim -c) driven
 * by an existing do-file or inline commands written to a generated do-file.
 * @module mmv-dspic/tools/modelsim-simulate
 */

import { existsSync } from 'node:fs'
import { writeFile } from 'node:fs/promises'
import path from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import { deriveModelSimTool, runProcess } from '../run.ts'
import type { Config } from '../index.ts'
import { buildDoFile } from '../templates.ts'
import {
  CWD_PARAM,
  RUN_OUTPUT_SCHEMA,
  TIMEOUT_PARAM,
  renderRun,
  resolvePath,
  resolveTimeoutMs,
  runPresentCall,
  runPresentResult,
  runPresentationMeta,
  toolCwd,
} from './shared.ts'

let doFileCounter = 0

/**
 * Define the `mmv_modelsim_simulate` tool for one plugin configuration.
 * @param config - the plugin configuration carrying `modelsimPath`.
 * @returns the registry-ready tool definition.
 */
export function defineModelsimSimulateTool(config: Config): ToolDefinition {
  return defineTool({
    name: 'mmv_modelsim_simulate',
    description: 'Run a ModelSim batch simulation (`vsim -c`) of a top-level unit: drive it with an existing do-file (`doFile`) or inline `commands` (exactly one is required; a `quit -f` is appended unless the commands already quit). `recordWaves` prepends `log -r /*` so a WLF waveform database is written for later viewing. Compile first with mmv_modelsim_compile in the same working directory. The transcript reports errors like assertion failures — inspect it to decide whether the RTL matches the MATLAB reference.',
    parameters: {
      top: {
        type: 'string',
        required: true,
        description: 'Top-level module/entity to simulate; a bare name is qualified with the `work` library.',
      },
      doFile: {
        type: 'string',
        description: 'Path to an existing do-file to execute; exactly one of doFile/commands is required.',
      },
      commands: {
        type: 'array',
        description: 'Inline do-file commands in order; exactly one of doFile/commands is required.',
        items: { type: 'string' },
      },
      work: {
        type: 'string',
        description: 'Library containing the top (default "work").',
      },
      recordWaves: {
        type: 'boolean',
        description: 'Record all signals (`log -r /*`) into a WLF database (default false). Applies to generated do-files only.',
      },
      cwd: CWD_PARAM,
      timeoutMs: TIMEOUT_PARAM,
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ...RUN_OUTPUT_SCHEMA.properties,
          doFile: {
            type: 'string',
            required: true,
            description: 'Absolute path of the do-file that drove this run (generated or supplied).',
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: `${renderRun(value)}\ndo-file: ${value.doFile}`,
      }],
      presentationMeta: (_args, value) => ({ ...runPresentationMeta(value), doFile: value.doFile }),
    },
    async execute(args, exec) {
      const top = args.top.trim()
      if (top.length === 0) throw new Error('top must be a non-empty unit name')
      const work = (args.work ?? 'work').trim()
      if (work.length === 0) throw new Error('work must be a non-empty library name')
      const doFile = args.doFile?.trim() ?? ''
      const commands = args.commands ?? []
      const provided = (doFile.length > 0 ? 1 : 0) + (commands.length > 0 ? 1 : 0)
      if (provided !== 1) {
        throw new Error('exactly one of doFile/commands must be provided')
      }
      const cwd = toolCwd(args, config)
      const timeoutMs = resolveTimeoutMs(args.timeoutMs, config.timeoutMs)
      let doFilePath: string
      if (doFile.length > 0) {
        doFilePath = resolvePath(doFile, cwd)
        if (!existsSync(doFilePath)) throw new Error(`doFile not found: ${doFilePath}`)
      } else {
        doFilePath = path.join(cwd ?? process.cwd(), `mmv_sim_${process.pid}_${++doFileCounter}.do`)
        await writeFile(doFilePath, buildDoFile(commands, args.recordWaves ?? false), 'utf8')
      }
      const qualifiedTop = top.includes('.') ? top : `${work}.${top}`
      const result = await runProcess({
        command: deriveModelSimTool(config.modelsimPath, 'vsim'),
        args: ['-c', '-do', doFilePath, '-L', work, qualifiedTop],
        cwd,
        timeoutMs,
        signal: exec.signal,
        maxOutputChars: config.maxOutputChars,
      })
      return { ...result, doFile: doFilePath }
    },
    presentCall: args => {
      const top = args.top.includes('.') ? args.top : `${args.work ?? 'work'}.${args.top}`
      return runPresentCall(`vsim -c -do <do-file> ${top}`, toolCwd(args, config))
    },
    presentResult: runPresentResult,
  })
}
