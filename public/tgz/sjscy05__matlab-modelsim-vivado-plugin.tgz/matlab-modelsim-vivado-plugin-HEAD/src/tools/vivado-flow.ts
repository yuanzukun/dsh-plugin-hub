/**
 * `mmv_vivado_flow`: generate the standard Vivado batch Tcl (read sources →
 * synth_design → opt/place/route → write_bitstream) into the output directory
 * and execute it, reporting which artifacts were produced.
 * @module mmv-dspic/tools/vivado-flow
 */

import { existsSync } from 'node:fs'
import { mkdir, writeFile } from 'node:fs/promises'
import path from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ToolDefinition } from '@deepseek-ai/dsh-tools'
import { runProcess } from '../run.ts'
import type { Config } from '../index.ts'
import { FLOW_STEPS, buildFlowTcl } from '../templates.ts'
import {
  CWD_PARAM,
  RUN_OUTPUT_SCHEMA,
  TIMEOUT_PARAM,
  renderRun,
  resolvePath,
  resolveTimeoutMs,
  runPresentCall,
  runPresentResult,
  runPresentationMeta,
  toolCwd,
} from './shared.ts'

/** Classify a source path for the generated Tcl read command. */
function sourceKind(file: string): 'verilog' | 'vhdl' | null {
  const ext = path.extname(file).toLowerCase()
  if (ext === '.v' || ext === '.sv' || ext === '.svh') return 'verilog'
  if (ext === '.vhd' || ext === '.vhdl') return 'vhdl'
  return null
}

/**
 * Define the `mmv_vivado_flow` tool for one plugin configuration.
 * @param config - the plugin configuration carrying `vivadoPath`.
 * @returns the registry-ready tool definition.
 */
export function defineVivadoFlowTool(config: Config): ToolDefinition {
  return defineTool({
    name: 'mmv_vivado_flow',
    description: 'Run the complete Vivado FPGA implementation flow for one design: read the RTL sources and constraints, synthesize (`synth_design`), implement (opt/place/route), and generate the bitstream — driven by a generated Tcl script in the output directory. `steps` selects the pipeline length (default all three; requesting `bitstream` automatically includes `implementation`). Checkpoints, utilization/timing reports, and the .bit file land in `outDir`. Use it after ModelSim simulation passes, when the RTL is ready for the FPGA.',
    parameters: {
      top: {
        type: 'string',
        required: true,
        description: 'Top-level module/entity name.',
      },
      sources: {
        type: 'array',
        required: true,
        description: 'RTL source files (relative to cwd); .v/.sv/.svh are read with read_verilog, .vhd/.vhdl with read_vhdl.',
        items: { type: 'string' },
      },
      part: {
        type: 'string',
        required: true,
        description: 'Target FPGA part, e.g. "xc7a35tcsg324-1".',
      },
      constraints: {
        type: 'array',
        description: 'XDC constraint files (relative to cwd), read with read_xdc.',
        items: { type: 'string' },
      },
      outDir: {
        type: 'string',
        description: 'Output directory for the generated Tcl, checkpoints, reports, and bitstream (default "vivado_out").',
      },
      steps: {
        type: 'array',
        description: 'Pipeline steps to run (default all three): "synthesis", "implementation", "bitstream".',
        items: { type: 'string', enum: FLOW_STEPS },
      },
      cwd: CWD_PARAM,
      timeoutMs: TIMEOUT_PARAM,
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          ...RUN_OUTPUT_SCHEMA.properties,
          tclPath: { type: 'string', required: true, description: 'Absolute path of the generated Tcl script.' },
          outputs: {
            type: 'object',
            required: true,
            additionalProperties: false,
            properties: {
              synthesisCheckpoint: { type: 'string', description: 'Absolute path of synth.dcp, when produced.' },
              implementationCheckpoint: { type: 'string', description: 'Absolute path of impl.dcp, when produced.' },
              bitstream: { type: 'string', description: 'Absolute path of the generated .bit file, when produced.' },
              reports: {
                type: 'array',
                required: true,
                description: 'Absolute paths of the utilization/timing reports produced by the run.',
                items: { type: 'string' },
              },
            },
          },
        },
      },
      render: (_args, value) => [{
        type: 'text',
        text: [
          renderRun(value),
          `Tcl: ${value.tclPath}`,
          ...Object.entries(value.outputs).flatMap(([key, item]) => {
            if (key === 'reports') {
              return value.outputs.reports.map(report => `report: ${report}`)
            }
            return typeof item === 'string' ? [`${key}: ${item}`] : []
          }),
        ].join('\n'),
      }],
      presentationMeta: (_args, value) => ({ ...runPresentationMeta(value), tclPath: value.tclPath, outputs: value.outputs }),
    },
    async execute(args, exec) {
      const top = args.top.trim()
      if (top.length === 0) throw new Error('top must be a non-empty unit name')
      const part = args.part.trim()
      if (part.length === 0) throw new Error('part must be a non-empty part name')
      if (args.sources.length === 0) throw new Error('sources must be a non-empty array')
      const cwd = toolCwd(args, config)
      const timeoutMs = resolveTimeoutMs(args.timeoutMs, config.timeoutMs)
      const outDirAbs = resolvePath(args.outDir ?? 'vivado_out', cwd)
      await mkdir(outDirAbs, { recursive: true })
      const verilog: string[] = []
      const vhdl: string[] = []
      for (const source of args.sources) {
        if (source.trim().length === 0) throw new Error('source paths must be non-empty')
        const abs = resolvePath(source, cwd)
        if (!existsSync(abs)) throw new Error(`source not found: ${abs}`)
        const kind = sourceKind(abs)
        if (kind === null) {
          throw new Error(`unsupported source extension: ${abs} (use .v/.sv/.svh or .vhd/.vhdl)`)
        }
        if (kind === 'verilog') verilog.push(abs)
        else vhdl.push(abs)
      }
      const constraints = (args.constraints ?? []).map(file => {
        const abs = resolvePath(file, cwd)
        if (!existsSync(abs)) throw new Error(`constraint not found: ${abs}`)
        return abs
      })
      let steps = args.steps ?? [...FLOW_STEPS]
      if (steps.length === 0) steps = [...FLOW_STEPS]
      // A bitstream cannot be written without a routed design; implement is
      // implied by the request rather than rejected.
      if (steps.includes('bitstream') && !steps.includes('implementation')) {
        steps = [...steps, 'implementation']
      }
      const tcl = buildFlowTcl({
        top,
        part,
        outDir: outDirAbs.replaceAll(path.sep, '/'),
        verilog,
        vhdl,
        constraints,
        steps,
      })
      const tclPath = path.join(outDirAbs, 'flow.tcl')
      await writeFile(tclPath, tcl, 'utf8')
      const run = await runProcess({
        command: config.vivadoPath,
        args: ['-mode', 'batch', '-notrace', '-source', tclPath],
        cwd,
        timeoutMs,
        signal: exec.signal,
        maxOutputChars: config.maxOutputChars,
      })
      const reports: string[] = []
      if (steps.includes('synthesis')) {
        reports.push(path.join(outDirAbs, 'utilization_synth.rpt'))
      }
      if (steps.includes('implementation')) {
        reports.push(path.join(outDirAbs, 'utilization_placed.rpt'), path.join(outDirAbs, 'timing.rpt'))
      }
      const existing = (file: string): string | undefined => existsSync(file) ? file : undefined
      const outputs: {
        synthesisCheckpoint?: string
        implementationCheckpoint?: string
        bitstream?: string
        reports: string[]
      } = { reports: [] }
      const synthDcp = existing(path.join(outDirAbs, 'synth.dcp'))
      if (synthDcp !== undefined) outputs.synthesisCheckpoint = synthDcp
      const implDcp = existing(path.join(outDirAbs, 'impl.dcp'))
      if (implDcp !== undefined) outputs.implementationCheckpoint = implDcp
      const bit = existing(path.join(outDirAbs, `${top}.bit`))
      if (bit !== undefined) outputs.bitstream = bit
      outputs.reports = reports.filter(report => existsSync(report))
      return { ...run, tclPath, outputs }
    },
    presentCall: args => {
      const outDir = args.outDir ?? 'vivado_out'
      return runPresentCall(`vivado -mode batch -notrace -source ${path.join(outDir, 'flow.tcl')}`, toolCwd(args, config))
    },
    presentResult: runPresentResult,
  })
}
