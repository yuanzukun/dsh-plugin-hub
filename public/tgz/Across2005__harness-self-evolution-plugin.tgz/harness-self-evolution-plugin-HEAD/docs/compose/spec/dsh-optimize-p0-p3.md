---
feature: dsh-optimize-p0-p3
status: delivered
updated: 2026-09-29
branch: main
commits: 11e9243..884d65e
---

# DSH 插件 P0–P3 全量优化

> **2026-09-25 安全修订**：M7 的 `process_task` 真实进程路径在事务性 sandbox
> adapter 落地前改为 fail closed；`real_validation` 仍保留。该修订优先保证
> 不把无法追踪新文件/删除/并发写入的执行误报为可回滚，后续 adapter 完成后再
> 重新开放进程派发。

## Report

**What was built** — v3.2.0：① 安装器回归网/复验报告入库 + DESIGN「启动时扫描」失实纠偏；② 新增 `record_tool_call`/`record_user_feedback` 注入面（工具 14→16），data_gaps/面板文案改为「注入面已暴露」；③ `real_validation` 保留经 `@process.collect_output` 的显式验证路径，但 `process_task` 在事务性 sandbox adapter 落地前 fail closed；生产装配不再把不可追踪的裸进程写入伪装成可回滚执行；④ 面板 npm test **20/20**、删除 `miniapps/` 残留、版本五处一致。两轴 code-review 硬伤已修（CONTEXT 注入面词条、AGENTS 日期、G1 引用、假 cwd、写穿测试、历史 14/16 区分）。

**Verification** — `moon check --deny-warn` 零错零警；`moon test` **459/459**；`scripts/test-install-dsh.ps1` 7/7；`dsh-evolution-panel` npm test **20/20**；`dsh-watcher` pnpm test **88 passed / 0 failed / 2 skipped**；`build.ps1 -Task all` EXIT=0 并刷新 `bin/harness-evolution.exe`（当前构建产物大小以实测为准）。

**Journey log** — ① PowerShell 批量字符串替换破坏 UTF-8，已用 `git show` 按字节恢复后改用 Edit 工具重做；② MoonBit 本版本 async **无 `await` 关键字**、`replace` 需 `old~/new~` 标签、`cwd?` 不接受 `String?`、`Ok(expr) catch` 必须与返回类型对齐；③ G5b 锚点 454→**457**（审查补网：写穿 +1、fake-cwd +1），随后 T2 lazy-fallback 回归再 +2 → **459**。

## [S1] Problem

仓库存在四层待处理问题：

1. **P0 卫生**：安装器回归网与复验报告未入库；DESIGN 等文档仍有「启动时扫描」失实；全门禁未在当前工作树复跑。
2. **P1 缺陷 9**：监控链只有本插件自测量，宿主/Agent **没有** 向 `metrics`/`signals` 注入其他插件事件的 MCP 面；`data_gaps` 只能点名「未上报」。
3. **P2 M7**：`real_validation` 已有显式开关；`process_task` 的裸进程路径因无法提供完整 mutation manifest/回滚，在 2026-09-25 修订为 fail closed，三级验证与子 Agent 默认仍走模拟。
4. **P3 面板**：`dsh-evolution-panel` 有测试但「可视化验收」未在本轮闭环；`miniapps/` 为已取消的 MiniMax 打包残留。

## [S2] Design

### P0 卫生与文档

- 提交：`scripts/test-install-dsh.ps1`、`scripts/test-patch-layer.mjs`、`scripts/_archive/README.md`、`COMPATIBILITY_RECHECK_2026-09-22.md`。
- 纠正 `DESIGN.md` 中「启动时扫描 / 启动时」等与 README/SKILL 不一致的表述（能力以「工具调用触发扫描」为准）。
- 跑 `pwsh -File scripts/test-install-dsh.ps1`（7/7）与 `.\build.ps1 -Task all`（T0/T1/T2）。

### P1 生态注入面（缺陷 9 第二步）

新增 **2 个 MCP 工具**（工具面 14 → **16**），把已就绪的 monitor API 暴露为宿主可调注入点：

| 工具 | 作用 |
|------|------|
| `record_tool_call` | 按 `plugin_id` 写入延迟/成败/可选 error_message（参数体刻意不落盘，与自测量同策略） |
| `record_user_feedback` | 写入 positive/negative + 可选 context |

- Schema：`plugin_id`、`tool`、`latency_ms`、`success`、`error_message?` / `feedback`（wire 表已有 UserFeedback）。
- Handler：只调 `state.monitor.record_*`；错误仍走 `call_tool`（不变量④）。
- `data_gaps` / 面板文案更新：从「宿主未上报」改为「**注入面已暴露**；未调用则仍无该插件数据；自测量仅本插件」。
- 同步：`.dsh-plugin/plugin.json` mcp.tools、`DSH_INTEGRATION` 工具表、SKILL、README 十四→十六、schema_wbtest 顺序锚点、G5b 测试数。

**不**在本切片挂载 `dsh-watcher` 进程内桥（另立项）；注入面是 out-of-process 下唯一可机读的生态数据入口。

### P2 M7 真实派发

依赖：`executor/moon.pkg` 增加 `"moonbitlang/async/process"`（同一 `moonbitlang/async@0.20.1`，不新增外部包）。

**`process_task`**（安全修订后的当前契约）：

1. `HARNESS_EVOLUTION_AGENT_CMD` 已设置 → 在创建任何子进程前 `raise Failure`，错误明确指出需要 transactional sandbox adapter；不得派发不可追踪写入，也不得声称可回滚。
2. 未设置 env → 仍回退 `simulated_task`（保持既有语义）。
3. 模板占位符、命令拆词、退出码/stdout 尾处理等旧派发实现已删除，不属于当前接口；transactional adapter 落地时再作为新能力单独设计与验收。

**`real_validation`**（`HARNESS_EVOLUTION_REAL_VALIDATION=true` 时）：

| 级 | 命令（cwd = `HARNESS_EVOLUTION_WORKDIR` 或当前目录） |
|----|-----------------------------------------------------|
| T0 | `moon check --deny-warn` |
| T1 | `moon test` |
| T2 | `pwsh -File build.ps1 -Task all`（**任意非 0** 再回落 `powershell -NoProfile -File …`，不只在「命令不存在」时） |

- 非 0 退出 → `(false, "Tn failed (exit N): …")`；0 → `(true, "Tn passed")`。
- 开关关闭 → 仍 `simulated_validation`。
- 超时：沿用 executor 的 `with_timeout_opt`（不另设）。

**装配**：`ServerState::with_scan_config` / `with_harness_config` 改为注入 `run_task=process_task, validate_level=real_validation`（二者内部按 env 自选真实/模拟），测试构造器可继续用默认模拟注入缝。

更新 X9/X10 回归：配置真实 Agent 命令时必须在 spawn 前 fail closed；未配置时仍走模拟任务。`real_validation` 的真命令成功/假命令失败另行覆盖。

### P3 面板验收与残留

- 跑 `dsh-evolution-panel` 的 `npm test`（typecheck + node --test）作为机器验收；记录结果。
- 面板 `dataGaps` fixture/文案与 P1 新语义对齐。
- `miniapps/harness-evolution-panel`：确认无引用后删除（已取消 MiniMax 打包）；若 panel package 仍引用则只改文档标注「已取消」。
- 更新 ROADMAP：P0–P3 状态。

### 版本

功能面 +2 工具 + 安全闸门首发于 **3.2.0**；当前维护版本为 **3.2.3**，`moon.mod` 发布号 0.3.8。`package.json`、`.dsh-plugin/plugin.json`、`jsonrpc.server_version`、`SKILL` frontmatter、`DESIGN` 镜像保持一致。

## [S3] Out of Scope

- 不挂载 `dsh-watcher` 进程内桥、不改宿主源码。
- 不接通 `auto_approve`。
- 不改提案状态机 / patch 安装器行为（P0 只入库已有修复）。
- 不 push / 不开 PR（除非用户后续要求）。
- 不做跨平台预编译。

## Tasks

- [x] T1: P0 提交未跟踪回归网与复验报告并纠 DESIGN 文档 — acceptance: `git status` 无上述 untracked；DESIGN 无「启动时扫描」能力声明；安装器 7/7（covers: S2-P0）
- [x] T2: P1 新增 `record_tool_call`/`record_user_feedback` 工具与 schema/handler — acceptance: `tools/list` 16 个；两工具可写入 metrics/signals（covers: S2-P1; depends: T1）
- [x] T3: P1 同步清单/文档/data_gaps/面板文案/G5b — acceptance: 三方清单均 16；data_gaps 提到注入面（covers: S2-P1; depends: T2）
- [~] T4: P2 实现 `process_task` 真实执行 — **blocked by safety gate**：当前配置 env 时 fail closed，直到 transactional adapter 提供完整 mutation manifest 与回滚；未配置仍回退模拟（covers: S2-P2; depends: T1）
- [x] T5: P2 实现 `real_validation` 三级真实验证 — acceptance: 开关开时 T0 跑 moon check；假 cwd 失败（covers: S2-P2; depends: T4）
- [~] T6: P2 生产装配注入 process/real + 更新 X9/X10 测试 — **safety-gated**：ServerState 仍注入 `process_task`/`real_validation` 缝，但前者默认 fail closed；测试改绿（covers: S2-P2; depends: T4 T5）
- [x] T7: P3 面板 npm test + 残留处理 + ROADMAP/CONTEXT 更新 — acceptance: panel 测试通过；残留有明确处置；ROADMAP 反映本切片（covers: S2-P3; depends: T3）
- [x] T8: 全门禁 + 当前版本 3.2.3 五处一致 — acceptance: build.ps1 -Task all 绿；版本号一致（covers: S2; depends: T1 T2 T3 T4 T5 T6 T7）
