'use strict';

const { manifestEditDependencyIntent, manifestDependencyIntent, patchDependencyIntent } = require('../manifest-dependencies.cjs');
const { analyzeShell, classifyShell, combineAffectedPaths } = require('../shell-analysis.cjs');

const path = require('node:path');
const { classifyCodexTool } = require('./codex-tool-classifier.cjs');
const { fileHashIntent, patchHashIntent } = require('../hash-intent.cjs');

const WRITE_TOOLS = new Set(['apply_patch', 'edit', 'write']);
const READ_TOOLS = new Set(['glob', 'grep', 'lsp', 'read', 'webfetch', 'websearch']);
const CONTROL_TOOLS = new Set(['plan_enter', 'plan_exit', 'question', 'skill', 'todowrite']);

function normalizePath(value, cwd) {
  const original = String(value || '').trim().replace(/^['"]|['"]$/g, '');
  if (!original) return '';

  const windowsPath = /^[A-Za-z]:[\\/]|^\\\\/.test(original);
  const windowsCwd = /^[A-Za-z]:[\\/]|^\\\\/.test(String(cwd || ''));
  let normalized = original;
  if (cwd && windowsPath && windowsCwd) {
    normalized = path.win32.relative(String(cwd), original);
  } else if (cwd && path.posix.isAbsolute(original) && path.posix.isAbsolute(String(cwd))) {
    normalized = path.posix.relative(String(cwd), original);
  }
  return normalized.replace(/\\/g, '/').replace(/^\.\//, '');
}

function patchText(args) {
  return String(args && args.patchText || '');
}

function classifyOpenCodeTool(toolName, args) {
  const name = String(toolName || '').toLowerCase();
  if (WRITE_TOOLS.has(name)) return 'write';
  if (name === 'bash') return classifyShell(args && args.command);
  if (name === 'task') return args && args.task_id ? 'control' : 'delegate';
  if (READ_TOOLS.has(name)) return 'read';
  if (CONTROL_TOOLS.has(name)) return 'control';
  return classifyCodexTool(toolName, args);
}

function extractAffectedPaths(toolName, args, cwd, mutability) {
  const name = String(toolName || '').toLowerCase();
  if (name === 'edit' || name === 'write') {
    const file = normalizePath(args && args.filePath, cwd);
    return file ? [file] : [];
  }

  if (name === 'apply_patch') {
    const files = [];
    for (const line of patchText(args).split(/\r?\n/)) {
      const match = /^\*\*\* (?:Add|Update|Delete) File:\s*(.+?)\s*$/.exec(line)
        || /^\*\*\* Move to:\s*(.+?)\s*$/.exec(line);
      if (match) files.push(normalizePath(match[1], cwd));
    }
    return [...new Set(files.filter(Boolean))];
  }

  if ((mutability ?? classifyOpenCodeTool(toolName, args)) === 'write') {
    const file = normalizePath(args && (args.filePath || args.file_path || args.path), cwd);
    return file ? [file] : [];
  }
  return [];
}

function detectDependencyIntent(toolName, args) {
  const name = String(toolName || '').toLowerCase();
  if (name === 'bash') {
    return analyzeShell(args && args.command).dependencyIntent;
  }
  if (name === 'apply_patch') {
    return patchDependencyIntent(patchText(args));
  }
  if (name === 'edit' || name === 'write') {
    const file = normalizePath(args && args.filePath);
    const added = String(args && (name === 'edit' ? args.newString : args.content) || '');
    return name === 'write' ? manifestDependencyIntent(file, added)
      : manifestEditDependencyIntent(file, args && args.oldString, added);
  }
  return false;
}

function detectHashIntent(toolName, args) {
  const name = String(toolName || '').toLowerCase();
  if (name === 'bash') {
    return analyzeShell(args && args.command).hashIntent;
  }
  if (name === 'apply_patch') {
    return patchHashIntent(patchText(args));
  }
  if (name === 'edit') {
    return fileHashIntent(args && args.filePath, args && args.newString);
  }
  if (name === 'write') {
    return fileHashIntent(args && args.filePath, args && args.content);
  }
  return false;
}

function analyzeOpenCodeTool(toolName, args, cwd) {
  const analysis = String(toolName || '').toLowerCase() === 'bash'
    ? analyzeShell(args && args.command)
    : {
      mutability: classifyOpenCodeTool(toolName, args),
      hashIntent: detectHashIntent(toolName, args),
      dependencyIntent: detectDependencyIntent(toolName, args)
    };
  return {
    ...analysis,
    affectedPaths: combineAffectedPaths(
      extractAffectedPaths(toolName, args, cwd, analysis.mutability), analysis, value => normalizePath(value, cwd)
    )
  };
}

module.exports = {
  analyzeOpenCodeTool,
  classifyOpenCodeTool,
  detectDependencyIntent,
  detectHashIntent,
  extractAffectedPaths,
  normalizePath
};
