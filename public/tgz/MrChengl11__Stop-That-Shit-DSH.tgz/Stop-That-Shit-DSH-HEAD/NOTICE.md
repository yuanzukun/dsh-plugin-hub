# NOTICE — 二次开发声明 / Derivative work notice

本仓库 **Stop-That-Shit-DSH** 是 [lennney/stop-that-shit](https://github.com/lennney/stop-that-shit) 的二次开发（derivative work），
不是上游官方项目，也未获得上游官方背书。

This repository is a **derivative work** of [lennney/stop-that-shit](https://github.com/lennney/stop-that-shit).
It is not an official upstream project and carries no upstream endorsement.

## 本仓库版本

| 项 | 值 |
| --- | --- |
| 版本 | `dsh-stop-that-shit` **0.2.1** |
| 已验证运行时 | DeepSeek Harness **0.2.1-rc.5**（Electron 桌面版 win32-x64；验收走同一安装产物的 headless CLI，依据见 `e2e/REPORT-rc5.md`） |
| 声明支持范围 | `engines.dsh: "^0.2.1-rc.3"` —— 0.2.1-rc.3 起、含 0.2.x，不含 0.3.x |

## 上游 / Upstream

| 项 | 值 |
| --- | --- |
| 仓库 | https://github.com/lennney/stop-that-shit |
| 版本 | commit `e2660f4`（tag 0.2.5 + 18 个提交，含上游 DSH host adapter 合并）+ 0.2.5.1 的两项修复 |
| 许可证 | MIT |
| 版权 | Copyright (c) 2026 Stop That Shit contributors |
| 收录位置 | `vendor-sts/`（`src/adapters/` 已剔除，DSH 粘合层改由 `lib/` 承担） |

## 本仓库新增（二次开发部分）

| 路径 | 说明 |
| --- | --- |
| `lib/index.js` | DeepSeek Harness 插件入口，注册宿主扩展点 |
| `lib/adapter.js` | DSH 工具调用 → 上游 ControlEvent v2 的适配层 |
| `cordis.patch.yml` | DSH profile 的 cordis 补丁（insert `sts-native`） |
| `install.mjs` | 幂等安装/卸载脚本 |
| `test/conformance.mjs` | 121 条一致性断言 |
| `test/rc5-tool-inventory.mjs` | rc.5 桌面 / headless 实挂工具名与分类清单（签入证据） |
| `e2e/` | 端到端探针与报告 |
| `research/claude-code-bridge/` | 早期桥接路线探针与结论 |
| `docs/01–03` | 上游与 DSH 扩展面取证记录 |
| `docs/04–05` | 兼容性判定与原生插件设计（中文） |
| `docs/06` | rc.5 宿主契约复核（中文，本轮 rc.5 适配的证据基础） |

## 为什么是二次开发而不是 fork 上游

上游提供的宿主适配器覆盖 Codex、Claude Code、OpenCode、Hermes Agent CLI、Pi、Oh My Pi，
**不包含 DeepSeek Harness**。上游的决策引擎与宿主解耦（ControlEvent v2 协议），
本仓库利用这一设计，只补一个宿主适配层，因此：

* 上游的判定规则、指令语法、状态机 **未改**，只有 `src/shell-analysis.cjs`（证明 shell 写目标）与 `src/decision.cjs`（依赖授权先于文件边界）两处打了上游 0.2.5.1 的修复；
* 上游升级时，只需替换 `vendor-sts/` 即可跟进；
* 本仓库的所有缺陷都应算在适配层，而非上游。

## 许可证

上游与本仓库均为 MIT。上游版权声明保留于 `vendor-sts/LICENSE` 与本仓库 `LICENSE`。
分发本仓库时请同时保留两份声明。
