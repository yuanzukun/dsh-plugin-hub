let demo = {
  en: {
    tagline: 'Paste a product story, article, course, event, or personal idea. Extract the thesis and evidence, then get a platform-native publicity matrix without invented claims.',
    coreIdea: 'One long-form source can become many distinct publishing entrances when the evidence stays fixed and the structure changes.',
    titles: ['One Source, 17 Native Drafts: A Publicity Toolkit for Products, Projects, and Ideas', 'Why platform-native promotion beats copy-paste distribution', 'A long-form source, rewritten for every publishing surface'],
    hook: "You wrote a great README, but nobody reads it. The problem isn't the content — it's the lack of a content kit.",
    quote: 'One source should not be copied and pasted into every platform.',
    x: 'Plugin idea: turn any article/README into a content kit — 3 title angles, a hook, source-grounded evidence, platform drafts, image prompt, hashtags, and claim-safety flags. Local-first, deterministic v0.1, no extra API calls, no invented facts. Open source. Try it tonight.',
    xiaohongshu: '🔥 内容创作者的效率神器！\n\n今天发现一个开源插件 DSH Promotion Toolkit，它能把你的文章、聊天记录甚至 README 变成一个完整的内容发布包！\n\n✨ 它能做什么？\n- 3 个标题角度，告别标题荒\n- 一个吸引人的钩子\n- 基于原文的证据，不编造事实\n- 针对 X、小红书、LinkedIn 的草稿\n- 图片提示 + 标签\n- 声明安全标记，避免翻车\n\n💡 亮点：本地优先，确定性 v0.1，不调用额外 API，所有内容都基于你提供的源材料。\n\n🚀 适合谁？\n- 独立开发者\n- 技术博主\n- 内容运营\n\n#开源 #内容创作 #效率工具 #开发者工具',
    linkedin: "As developers, we write READMEs and technical articles, but rarely have time to repurpose them for social media. DSH Promotion Toolkit turns one source into platform-specific drafts while keeping claims traceable to the source.",
    zhihu: '# How do you turn one long-form source into several native openings?\n\n## Short answer\n\nKeep the thesis and evidence fixed, then adapt the reading path for each platform.\n\n## Method\n\nUse context for explainers, a checklist for saves, a human share for friend feeds, and a shot list for video.\n\n## Limits\n\nVerify every number, date, attribution, and outcome before publishing.',
    wechat: 'Title: One source, many native openings\n\nLead: Your long-form source is not a single post waiting to be shortened.\n\nStart with the thesis, map the evidence, and rewrite the information architecture for each audience. A product story, article, course, event, or personal idea can become an explainer, checklist, friend-feed share, discussion prompt, and video storyboard without changing what it actually says.',
    wechat_moments: 'I am trying a calmer way to publish: keep one long-form source, pull out the evidence, and give each platform its own opening. Less copy-paste, more room for the idea to sound like itself.',
    bilibili: 'Video title: One source, different openings\n\n[0-3s] Show one long article copied into four identical posts.\n[3-25s] Show the Markdown explainer, saveable checklist, Moments share, and video storyboard.\n[25-45s] Keep the evidence fixed while the reading path changes.\n[CTA] Which source would you repurpose first?',
    douyin: '[30-second script]\nYou wrote a great README, but nobody reads it. The fix is not another prompt: it is a repeatable content workflow. One source, platform-specific drafts, and a claim check before you post. What would you automate first?',
    weibo: 'Microblog: one long-form source should not become the same post everywhere. Keep the evidence, change the opening, and give each audience a native way in.',
    kuaishou: '[Short video script] You wrote a great README, but nobody reads it. Turn it into a repeatable workflow your agent can run. What would you automate first?',
    threads: 'One source can carry more than one conversation.\n\nKeep the evidence fixed. Change the opening for the explainer, checklist, friend feed, and video.\n\nThat is the publicity matrix.',
    reddit: 'Title: From README to platform-specific launch copy\n\nI am exploring a local-first plugin that turns one source into drafts for social, community, article, and video surfaces. The source supports the workflow idea; I am not claiming outcomes yet. How would you test it?',
    tiktok: '[TikTok script] One README. Ten platform drafts. The useful shift is not more prompts; it is a repeatable workflow you can inspect before publishing. What would you automate first?',
    youtube: '[YouTube Short]\n0-3s: Show four identical posts from one article.\n3-20s: Turn it into an explainer, checklist, friend-feed share, and video script.\n20-40s: Same evidence, different reading path.\n40-50s: Which source would you repurpose first?',
    medium: 'Title: From README to a platform-specific launch kit\n\nLead: You wrote a great README. Now give it a distribution workflow.\n\nOne source becomes drafts for social, community, article, and video surfaces. Verify any broader claim before publishing.',
    facebook: 'A good long-form source deserves more than one doorway. Keep the evidence, change the opening, and let each platform sound like itself. What would you repurpose first?',
    instagram: 'One source. Platform-specific drafts. A claim check before publishing.\n\n#OpenSource #DevTools #ContentCreation',
    hashtags: ['#OpenSource', '#ContentCreation', '#DevTools', '#Productivity', '#AI'],
    signals: ['tension', 'clear topic', 'quotable length'],
    evidence: ['A long-form source contains several publishable ideas, not one universal post.', 'Platform-native writing changes the reading path while keeping the source evidence attached.', 'Numbers, attribution, dates, and outcomes still need a final check before publishing.'],
    risk: 'One absolute claim detected. Soften it unless you can prove it.',
  },
  zh: {
    tagline: '把产品故事、文章、课程、活动或个人观点贴进来，先抽取观点与证据，再按平台生成真正不同的宣发成稿。',
    coreIdea: '一份长文不是一条被压扁的帖子，而是一组可以从不同入口进入读者视线的观点与证据。',
    titles: ['一篇长文，如何变成 17 个平台原生入口？', '别再把同一段话复制到所有平台', '从原文证据到可复制的宣发矩阵'],
    hook: '你写了一个很棒的 README，但没人看。不是内容不行，而是你缺少一个内容套件。',
    quote: '一份原文，不应该被复制粘贴到所有平台。',
    x: '一个插件，把文章/README 变成完整的内容套件：3 个标题角度、一个钩子、基于原文的证据、平台草稿、图片提示、标签，还有声明安全标记。本地优先，确定性 v0.1，不调用额外 API，不编造事实。开源，今晚就能试。',
    xiaohongshu: '🔥 内容创作者的效率神器！\n\n今天发现一个开源插件 DSH Promotion Toolkit，它能把你的文章、聊天记录甚至 README 变成一个完整的内容发布包！\n\n✨ 它能做什么？\n- 3 个标题角度，告别标题荒\n- 一个吸引人的钩子\n- 基于原文的证据，不编造事实\n- 针对 X、小红书、LinkedIn 的草稿\n- 图片提示 + 标签\n- 声明安全标记，避免翻车\n\n💡 亮点：本地优先，确定性 v0.1，不调用额外 API，所有内容都基于你提供的源材料。\n\n🚀 适合谁？\n- 独立开发者\n- 技术博主\n- 内容运营\n\n#开源 #内容创作 #效率工具 #开发者工具',
    linkedin: '作为开发者，我们经常写 README，却很少有时间把它改成适合不同平台的内容。DSH Promotion Toolkit 把一份原文变成小红书、知乎、公众号、视频和全球社交平台的差异化草稿，并保留事实边界。',
    zhihu: '# 一份长文，为什么需要不同的宣发入口？\n\n## 先说结论\n\n保留观点和证据，改变平台的阅读路径。\n\n## 方法\n\n知乎讲因果，小红书做清单，朋友圈写真实分享，视频先安排画面。\n\n## 边界\n\n数字、引用、日期和效果仍需发布前回到原文核验。',
    wechat: '标题：一份长文，为什么需要不同的宣发入口？\n\n摘要：长文不是一条等待被缩短的帖子，而是一组观点、证据、案例和问题。\n\n先抽取核心观点，再把证据绑定到对应说法，最后根据不同平台改写顺序。这样产品故事、文章、课程、活动和个人经验都可以变成科普文、可保存清单、朋友圈分享、社区讨论和视频分镜。发布前，数字、引用、日期和效果仍要回到原文核查。',
    wechat_moments: '我最近在试一种更省力的发布方式：一份长文先提炼观点和证据，再按平台改写。不是为了多发，而是让真正想说的东西别卡在草稿箱里。',
    bilibili: '视频标题：一份长文，四种原生入口\n\n【0-3 秒】同一段原文被复制到四个平台。\n【3-25 秒】展示知乎 Markdown、小红书清单、朋友圈分享和视频分镜。\n【25-45 秒】证据不变，阅读路径改变。\n【结尾】你最想先改写哪篇长文？',
    douyin: '【30 秒口播】你写了一个很棒的 README，但没人看。解决办法不一定是再写一个提示词，而是把它变成一套可重复的内容工作流。一份原文，按平台改写，发布前还能检查事实边界。你会先自动化哪一步？',
    weibo: '微博：一份长文不要硬复制到所有平台。保留观点和证据，按受众改写入口，内容才有机会被真正读完。',
    kuaishou: '【快手口播】你写了一个很棒的 README，但没人看。把它变成一套可重复的工作流，才是重点。你会先自动化哪一步？',
    threads: '一份长文可以进入很多种对话。\n\n知乎需要因果，小红书需要清单，朋友圈需要人味，视频需要画面。\n\n保留证据，换一个入口。',
    reddit: '标题：如何把一份 README 改成全平台发布内容？\n\n我在做一个本地优先的插件，把一份原文分别改写成社交、社区、文章和视频平台的版本。原文只能支持“工作流”这个方向，不先承诺传播结果。你会如何测试？',
    tiktok: '【TikTok 口播】一份 README，十个平台成稿。重点不是多几个 prompt，而是让 agent 多一个可重复、可复核的工作流。你会先自动化什么？',
    youtube: '【YouTube Shorts】\n0-3 秒：展示一份长文被复制成四条相同帖子。\n3-20 秒：改成科普、清单、朋友圈分享和视频脚本。\n20-40 秒：证据不变，阅读路径改变。\n40-50 秒：你会先改写哪篇长文？',
    medium: '标题：从 README 到全平台发布矩阵\n\n开头：你写了一个很棒的 README，现在只差一套分发工作流。\n\n一份原文可以被改写成社交、社区、文章和视频平台版本，发布前再检查事实边界。',
    facebook: '你写了一个很棒的 README。真正有用的改变，是让 agent 多一个可重复的工作习惯，而不是再增加一个提示词。你会先试哪一步？',
    instagram: '一份原文。按平台改写。发布前检查事实边界。\n\n#开源 #开发者工具 #内容创作',
    hashtags: ['#开源', '#内容创作', '#开发者工具', '#效率', '#AI'],
    signals: ['张力', '主题清晰', '适合引用'],
    evidence: ['一份原文里通常有多个可以进入不同平台的观点。', '平台适配改变的是阅读路径，不是事实本身。', '数字、引用、日期和效果需要在发布前回到原文核验。'],
    risk: '检测到绝对化表述。发布前请确认是否有证据支撑。',
  },
};

const labels = {
  en: { status: 'source-grounded / platform-native', eyebrow: 'PLATFORM-NATIVE PUBLICITY', headline: 'One source.<br /><em>Every platform,<br />native.</em>', lede: 'Paste a product story, article, course, event, or personal idea. Extract the thesis and evidence, then rewrite the entry point for each platform.', pill: 'Chinese platform defaults', pill2: 'Claims stay traceable', pill3: '4 long-form cases / 17 platforms', caseLabel: 'LONG-FORM LIVE CASES / DEEPSEEK-V4-PRO', sourceLabel: 'LONG-FORM SOURCE', sourceFoot: 'Long-form source → publicity matrix', resultEyebrow: 'PLATFORM-NATIVE MATRIX', resultHeading: 'Same idea. Different entry points.', copyAll: 'Copy all', ideaLabel: 'SOURCE THESIS', ideaFine: 'Extracted first, then adapted by audience.', scoreLabel: 'SHAREABILITY', evidenceLabel: 'EVIDENCE TO KEEP', draftLabel: 'PLATFORM DRAFTS', draftHeading: 'Pick a surface. Copy the voice.', copyDraft: 'Copy draft', useCasesEyebrow: 'WHAT IT IS FOR', useCasesHeading: 'Not just launch day.', useCaseOne: 'Product / project launch', useCaseTwo: 'Article / explainer', useCaseThree: 'Course / event', useCaseFour: 'Personal point of view', stepOne: 'Paste the source', stepOneFine: 'Product, article, course, event', stepTwo: 'Extract thesis + evidence', stepTwoFine: 'Keep the claim boundary', stepThree: 'Generate native drafts', stepThreeFine: 'Change the entry point', closingEyebrow: 'FROM SOURCE TO DISTRIBUTION', closingHeading: 'Give good ideas more ways in.', closingText: 'Keep the facts. Change the opening. Turn any idea into a reviewable, copy-ready publicity matrix.', installLink: 'Install from README ↗' },
  zh: { status: '事实可追溯 / 平台原生', eyebrow: '平台原生宣发', headline: '一个产品，<br /><em>整套宣发。</em>', lede: '把产品、项目、文章、课程、活动或个人观点贴进来。先抽取观点与证据，再按平台重写，让每个平台都像原生内容。', pill: '中文平台默认', pill2: '事实可追溯', pill3: '4 个长文案例 / 17 个平台', caseLabel: '真实长文案例 / DEEPSEEK-V4-PRO', sourceLabel: '原文输入', sourceFoot: 'Long-form source → publicity matrix', resultEyebrow: '平台原生宣发矩阵', resultHeading: '同一件事，不同平台，换一种入口。', copyAll: '复制全部', ideaLabel: '核心观点', ideaFine: '先抽取，再按受众和平台改写。', scoreLabel: '传播评分', evidenceLabel: '需要保留的证据', draftLabel: '平台成稿', draftHeading: '选择平台，直接复制。', copyDraft: '复制成稿', useCasesEyebrow: '适合什么内容', useCasesHeading: '不是只给发布会用。', useCaseOne: '产品 / 项目发布', useCaseTwo: '文章 / 科普', useCaseThree: '课程 / 活动', useCaseFour: '个人观点 / 经验', stepOne: '贴入原文', stepOneFine: '产品、文章、课程、活动或想法', stepTwo: '抽取观点与证据', stepTwoFine: '保留事实边界', stepThree: '生成平台成稿', stepThreeFine: '每个平台换一种入口', closingEyebrow: '从原文到分发', closingHeading: '让好内容真正被看见。', closingText: '先保留事实，再改变入口。把任何想法变成一套可以复核、可以复制、也愿意被读完的宣发矩阵。', installLink: '查看安装方式 ↗' },
};

let language = 'zh';
let platform = 'x';
let caseIndex = 0;
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function mapLiveCase(item) {
  const mapLanguage = (code) => {
    const content = item.polished[code];
    return { ...content, ...content.platforms, source: code === 'zh' ? item.source : (content.quote || content.coreIdea || item.source), signals: item.baseline.signals, evidence: item.baseline.evidence, risk: code === 'zh' ? '模型输出已基于原文生成；数字、来源和绝对化表述仍需发布前复核。' : 'Model-polished from the source; verify numbers, sources, and absolutes before publishing.' };
  };
  return { zh: mapLanguage('zh'), en: mapLanguage('en') };
}

function applyLiveCase(index) {
  const cases = window.DSH_LIVE_DEMOS?.cases || [];
  if (!cases[index]) return;
  caseIndex = index;
  demo = mapLiveCase(cases[index]);
  $$('[data-case]').forEach((button) => button.classList.toggle('active', Number(button.dataset.case) === caseIndex));
  renderLanguage();
}

function renderCaseLabels() {
  const cases = window.DSH_LIVE_DEMOS?.cases || [];
  $$('[data-case]').forEach((button) => {
    const item = cases[Number(button.dataset.case)];
    if (item) button.textContent = language === 'zh' ? item.labelZh : item.label;
  });
}

function renderLanguage() {
  const copy = labels[language];
  $$('[data-copy]').forEach((node) => { const value = copy[node.dataset.copy]; if (value != null) node.innerHTML = value; });
  $$('[data-language]').forEach((node) => node.classList.toggle('active', node.dataset.language === language));
  renderCaseLabels();
  renderData();
}

function renderData() {
  const data = demo[language];
  $('[data-field="coreIdea"]').textContent = data.coreIdea;
  $('[data-field="score"]').textContent = language === 'zh' ? '70' : '70';
  $('[data-field="scoreMeter"]').style.width = '70%';
  $('[data-field="signals"]').innerHTML = data.signals.map((signal) => `<span>${signal}</span>`).join('');
  $('[data-field="evidence"]').innerHTML = data.evidence.map((item) => `<li>${item}</li>`).join('');
  $('[data-field="draft"]').textContent = data[platform];
  $('[data-field="draftTag"]').textContent = platform === 'xiaohongshu' ? '小红书 / NOTE' : platform === 'zhihu' ? '知乎 / MARKDOWN' : platform === 'wechat' ? '公众号 / ARTICLE' : platform === 'wechat_moments' ? '朋友圈 / SHARE' : platform === 'bilibili' || platform === 'youtube' ? `${platform.toUpperCase()} / VIDEO` : platform === 'douyin' || platform === 'kuaishou' || platform === 'tiktok' ? `${platform.toUpperCase()} / VIDEO` : platform === 'weibo' ? '微博 / MICROBLOG' : platform === 'medium' ? 'MEDIUM / ARTICLE' : `${platform.toUpperCase()} / POST`;
  $('[data-field="hashtags"]').innerHTML = data.hashtags.map((tag) => `<span>${tag}</span>`).join('');
  $('[data-field="risk"]').textContent = data.risk;
  $('[data-copy="sourceQuote"]').textContent = data.source ? (data.source.length > 210 ? data.source.slice(0, 210) + '…' : data.source) : data.quote;
}

function textToCopy(kind) {
  const data = demo[language];
  if (kind === 'draft') return data[platform];
  return [data.tagline, data.coreIdea, ...data.titles, data.hook, data.quote, data.x, data.xiaohongshu, data.zhihu, data.wechat, data.wechat_moments, data.weibo, data.bilibili, data.douyin, data.kuaishou, data.threads, data.linkedin, data.reddit, data.tiktok, data.youtube, data.medium, data.facebook, data.instagram, data.hashtags.join(' ')].join('\n\n');
}

async function copy(kind, button) {
  await navigator.clipboard.writeText(textToCopy(kind));
  const label = button.querySelector('[data-copy]');
  if (label) { const original = label.textContent; label.textContent = language === 'zh' ? '已复制' : 'Copied'; setTimeout(() => { label.textContent = original; }, 1400); }
}

$$('[data-language]').forEach((button) => button.addEventListener('click', () => { language = button.dataset.language; renderLanguage(); }));
$$('[data-case]').forEach((button) => button.addEventListener('click', () => applyLiveCase(Number(button.dataset.case))));
$$('[data-platform]').forEach((button) => button.addEventListener('click', () => { platform = button.dataset.platform; $$('[data-platform]').forEach((item) => item.classList.toggle('active', item === button)); renderData(); }));
$$('[data-copy-action]').forEach((button) => button.addEventListener('click', () => copy(button.dataset.copyAction, button)));
if (window.DSH_LIVE_DEMOS?.cases?.length) applyLiveCase(0);
else renderLanguage();
