/**
 * Runtime Skill registration for DSH.
 *
 * The Markdown copy in skills/viral-kit/SKILL.md is kept as a readable source
 * mirror, but DSH loads this registration through ctx.skills.register().
 */
export const VIRAL_KIT_SKILL_NAME = 'viral-kit'

export const VIRAL_KIT_SKILL_CONTENT = `# viral-kit (DSH edition)

Use the viral_kit tool when a user wants to publish, launch, announce, or
repurpose any source: a repository, product, article, course, event, video,
newsletter, or personal idea.

## Workflow

1. Preserve the source boundary. Extract the thesis, evidence, audience, and
   canonical URL before writing.
2. Choose a platform when the user names one. Otherwise return the complete
   platform matrix.
3. Keep Chinese-platform defaults in Chinese and global-platform defaults in
   English. An explicit language always wins.
4. Make each draft native to its surface: Xiaohongshu is conversational and
   saveable, Zhihu is Markdown-first and explanatory, WeChat is a substantial
   article, Moments is a short personal share, and video platforms include
   shots, voiceover, captions, and a CTA.
5. Use emoji sparingly and intentionally: more visual on Xiaohongshu and
   Instagram, at most two in Moments, and restrained elsewhere.
6. If sourceUrl is supplied, keep it in every platform-native CTA. Never
   invent links, metrics, users, pricing, or social proof.

Do not paste one platform draft into another when a tailored draft exists.
Do not use generic growth slogans unrelated to the source.`

export const VIRAL_KIT_SKILL = {
  name: VIRAL_KIT_SKILL_NAME,
  description: 'Source-grounded publicity workflow for platform-native promotion copy.',
  whenToUse: 'Use when a user asks to publish, launch, announce, promote, or repurpose content for one or more platforms.',
  source: 'runtime',
  content: VIRAL_KIT_SKILL_CONTENT,
}
