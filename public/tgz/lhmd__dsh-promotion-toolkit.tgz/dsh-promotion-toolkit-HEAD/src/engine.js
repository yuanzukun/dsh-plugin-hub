const ZH_STOPWORDS = new Set(['我们', '这个', '那个', '可以', '就是', '然后', '因为', '所以', '以及', '如果', '但是', '一个', '没有', '已经', '他们', '你们', '什么', '如何', '其中', '通过', '进行'])
const EN_STOPWORDS = new Set(['this', 'that', 'with', 'from', 'there', 'their', 'about', 'would', 'could', 'should', 'which', 'because', 'where', 'while', 'after', 'before', 'these', 'those', 'have', 'been', 'were', 'will', 'the', 'and', 'for', 'are', 'not', 'you', 'your', 'into', 'can', 'now', 'only', 'ever'])
const ZH_NOISE_CHARS = new Set('的了和与在是也能把将都不必等待进装做有为对从到被让一个这那其更很')
const CONTRAST_WORDS = ['但是', '然而', '反而', '却', '不是', '真正', '竟然', '原来', 'but', 'however', 'instead', 'not', 'actually', 'surprisingly']
const POWER_WORDS = ['最', '唯一', '关键', '秘密', '意外', '真相', '突破', '免费', '一夜', 'first', 'only', 'secret', 'truth', 'surprise', 'free', 'overnight']

function clean(value) {
  return String(value == null ? '' : value).replace(/\r/g, '').replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim()
}

function clamp(value, max) {
  const text = clean(value)
  return text.length <= max ? text : text.slice(0, Math.max(0, max - 1)).trim() + '…'
}

function splitSentences(text) {
  return clean(text).split(/(?<=[。！？!?；;]|\.(?:\s|$)|\?(?:\s|$)|!(?:\s|$))\s*|\n+/u).map(s => s.trim()).filter(s => s.length >= 8)
}

function languageOf(text, requested) {
  if (requested === 'zh' || requested === 'en') return requested
  if (requested == null) return 'zh'
  return /[\u3400-\u9fff]/u.test(text) ? 'zh' : 'en'
}

function scoreSentence(sentence, index, all) {
  const lower = sentence.toLowerCase()
  let score = Math.min(sentence.length / 70, 2)
  if (/\d/.test(sentence)) score += 1.25
  if (/[?！？!]/.test(sentence)) score += 1
  if (CONTRAST_WORDS.some(word => lower.includes(word))) score += 1.5
  if (POWER_WORDS.some(word => lower.includes(word))) score += 1.2
  if (/[:："“”‘’]/.test(sentence)) score += 0.6
  if (index === 0) score += 0.25
  if (all.length > 1 && index === all.length - 1) score += 0.2
  return score
}

function keywords(text, language) {
  const counts = new Map()
  const asciiTokens = text.match(/[A-Za-z][A-Za-z0-9-]{2,}/g) || []
  for (const token of asciiTokens) {
    const normalized = token.toLowerCase()
    if (!EN_STOPWORDS.has(normalized)) counts.set(token, (counts.get(token) || 0) + 2)
  }
  const tokens = language === 'zh' ? (text.match(/[\u3400-\u9fff]{2,4}/gu) || []) : (text.toLowerCase().match(/[a-z][a-z0-9-]{2,}/g) || [])
  const stopwords = language === 'zh' ? ZH_STOPWORDS : EN_STOPWORDS
  for (const token of tokens) {
    if (language === 'zh' && (token.length < 2 || Array.from(token).some(char => ZH_NOISE_CHARS.has(char)))) continue
    if (!stopwords.has(token)) counts.set(token, (counts.get(token) || 0) + 1)
  }
  return Array.from(counts.entries()).sort((a, b) => b[1] - a[1] || b[0].length - a[0].length || a[0].localeCompare(b[0])).slice(0, 8).map(pair => pair[0])
}

function stripPunctuation(value) {
  return clean(value).replace(/^[\s\-—:：,，。.!！?？]+|[\s\-—:：,，。.!！?？]+$/g, '')
}

function activePlatform(platform) {
  return ['x', 'xiaohongshu', 'zhihu', 'wechat', 'wechat_moments', 'weibo', 'bilibili', 'douyin', 'kuaishou', 'linkedin', 'threads', 'reddit', 'tiktok', 'youtube', 'medium', 'facebook', 'instagram'].includes(platform) ? platform : 'x'
}

function appendSourceUrl(platform, text, sourceUrl) {
  const url = clean(sourceUrl)
  if (!url || !/^https?:\/\//i.test(url)) return text
  const labels = {
    x: 'Read the source:', threads: 'Source:', linkedin: 'Read the source:', reddit: 'Source and discussion:',
    tiktok: 'Link in bio:', youtube: 'Full source:', medium: 'Read the full source:', facebook: 'Full source:', instagram: 'Link in bio:',
    xiaohongshu: '🔗 原文链接：', zhihu: '原文链接：', wechat: '原文与完整案例：', wechat_moments: '想看完整内容：', weibo: '🔗 原文：',
    bilibili: '完整内容：', douyin: '完整内容见：', kuaishou: '完整内容：',
  }
  return text + '\n\n' + (labels[platform] || 'Source:') + ' ' + url
}

function makeChineseKit(top, terms, platform, sourceUrl) {
  const idea = stripPunctuation(top)
  const keywordText = terms.slice(0, 3).join('、') || '这个想法'
  const title = clamp(idea, 28)
  const titles = [
    '我把「' + title + '」看懂了：真正关键的不是表面',
    '为什么' + keywordText + '，可能比你想的更重要',
    '一个反直觉结论：' + title,
  ]
  const quote = clamp(top.replace(/^["“]|["”]$/g, ''), 72)
  const hook = '先别急着划走：' + quote
  const evidence = [top, '可复用的关键动作：' + keywordText, '发布前要保留原文边界，不把推测写成事实。']
  const xPost = '一句话讲清：' + idea + '。\n\n我会把它拆成三步：先抓住可引用观点，再按平台改写，最后检查来源和绝对化表述。\n\n这不是把一篇长文压扁成一句口号，而是让同一个观点在不同场景里有不同说法。你会先发在哪个平台？'
  const xiaohongshu = titles[0] + '\n\n' + hook + '\n\n我把这件事拆成一份可以照着做的清单：\n\n1️⃣ 先找出读者真正关心的一个问题\n2️⃣ 用原文证据回答它，不把猜测写成结论\n3️⃣ 按平台重新组织，而不是复制粘贴\n\n适合：产品发布、开源项目、课程、活动和个人经验。\n\n最后检查：数字有没有来源？案例是不是自己的？“一定、最好、全网”这种词能不能证明？\n\n' + terms.slice(0, 6).map(term => '#' + term).join(' ')
  const zhihu = '# ' + titles[2] + '\n\n## 先说结论\n\n' + idea + '。真正值得讨论的不是一句漂亮的判断，而是它能否被拆成一套可复核的方法。\n\n## 背景：问题从哪里来\n\n很多内容在发布前只有一份长文，发布后却要面对完全不同的阅读场景：有人只看标题，有人需要完整论证，有人只给你 15 秒。\n\n## 方法：如何从一份原文做宣发\n\n1. **提取观点**：' + clamp(top, 120) + '\n2. **保留证据**：' + evidence[1] + '\n3. **重写结构**：短帖强调冲突，科普文展开因果，视频稿写清画面和口播。\n\n## 边界\n\n以上内容只基于给定原文。数字、引用、效果和外部案例，发布前需要单独核验。\n\n如果你也在做发布，最容易卡住的是哪一步？'
  const wechat = '标题：' + titles[0] + '\n\n摘要：' + hook + '\n\n## 一、为什么一篇好内容，发出去却没有反应？\n\n长文适合完整表达，但不同平台的读者并不会用同一种方式阅读。朋友圈需要一句让熟人愿意停下来的话，知乎需要解释来龙去脉，小红书需要清晰的步骤和可保存的清单，视频平台则需要先让人看懂画面。\n\n## 二、同一份素材，应该怎样改写？\n\n原文的核心不是“多发”，而是把一个观点拆成多个入口：先保留可引用的证据，再根据平台调整顺序、语气和行动号召。\n\n## 三、发布前的事实检查\n\n' + evidence.map((line, index) => (index + 1) + '. ' + line).join('\n') + '\n\n如果一条内容需要靠夸大的数字才能成立，先回到原文，确认它究竟能支持什么。'
  const wechatMoments = hook + '\n\n我最近在试一种更省力的发布方式：一份长文，先提炼观点，再按平台改写，最后核查来源。不是为了每天发更多，而是让真正想说的东西别卡在草稿箱里。'
  const bilibili = '视频标题：' + titles[1] + '\n\n【0-3 秒｜画面】长文、收藏夹和草稿箱快速闪过\n【3-15 秒｜口播】' + hook + '\n【15-35 秒｜演示】同一个观点分别变成知乎 Markdown、小红书清单和朋友圈短文\n【35-55 秒｜解释】短帖讲冲突，长文讲因果，视频讲画面；平台不同，读者的注意力就不同\n【55-65 秒｜结尾】发布前再查一次数字、来源和绝对化表述。'
  const douyin = '【45 秒口播】\n开场：你是不是也有一篇写得很好的长文，最后只发了一句“欢迎大家看看”？\n转折：问题不是内容不够，而是没有按平台改写。\n方法：知乎用 Markdown 讲清因果，小红书做成可保存清单，朋友圈写成像朋友分享，视频先给画面再给结论。\n结尾：一份原文，多种入口；但每一条都要守住事实边界。'
  const weibo = '一份长文不要硬复制到所有平台。提炼观点 → 保留证据 → 按平台改写 → 查数字和来源。省下来的不是打字时间，是从想法到发布的摩擦。\n\n' + terms.slice(0, 5).map(term => '#' + term + '#').join(' ')
  const kuaishou = '【快手口播】老铁们，一篇长文想发到十几个平台，别直接复制！先找一个最重要的观点，再按平台改：知乎讲明白，小红书列清单，朋友圈像聊天，视频先上画面。最后别忘了查来源，内容才能发得稳。'
  const linkedin = titles[2] + '\n\n我把一份长文拆成跨平台发布矩阵：\n\n- 短帖：压缩成一个可讨论的判断\n- 知乎：用 Markdown 展开背景、证据和边界\n- 小红书：把方法变成可保存的清单\n- 视频：把论点转成画面、口播和 CTA\n- 朋友圈：保留个人语气，让内容像真实分享\n\n关键不是追求每个平台都说同一句话，而是在不改变事实的前提下，改变信息的入口。'
  const threads = '一篇长文，不该被复制粘贴到所有平台。\n\n知乎需要因果，小红书需要清单，朋友圈需要人味，视频需要画面。\n\n同一个观点，换一个入口，才有机会被真正读完。'
  const reddit = '# ' + titles[2] + '\n\nI am testing a simple repurposing workflow for long-form content. The source stays fixed, but each channel gets a different structure: an evidence-led explainer, a saveable checklist, a conversational share, or a short-video script.\n\nThe hard part is not rewriting. It is keeping the claim boundary intact while changing the entry point. How do you repurpose long-form content without making every platform sound identical?'
  const tiktok = '[TikTok script]\nHook: You wrote a long article. Why does every platform post still sound the same?\nPayoff: Explainers need context, saveable posts need a checklist, friend feeds need a human voice, and video needs a visual beat.\nCTA: Keep the source fixed. Change the entry point. Verify the claim before you publish.'
  const youtube = '[YouTube Short storyboard]\n0-3s: Show one long article copied into four identical posts.\n3-15s: Cut to four formats: Markdown explainer, saveable checklist, friend-feed note, video script.\n15-35s: Explain why each format earns attention differently.\n35-50s: Keep evidence fixed, change structure, check claims before publishing.\n50-60s: One source. A real launch matrix.'
  const medium = '# ' + titles[2] + '\n\n' + hook + '\n\nA long-form source is not a single post waiting to be shortened. It is a set of ideas, evidence, examples, and questions that can enter different conversations.\n\nThe practical workflow is simple: extract one defensible idea, map the evidence behind it, then adapt the information architecture for each channel. A good adaptation changes the reading path, not the truth.\n\nBefore publishing, verify every number, attribution, result, and absolute claim that the source cannot support on its own.'
  const facebook = hook + '\n\n我最近越来越相信，长文的价值不应该只停留在一条链接里。把它改成朋友看得懂的分享、知乎的解释、小红书的清单和视频的脚本，内容才真正开始流动。'
  const instagram = titles[0] + '\n\n一篇长文，四种入口：\n📌 科普：讲清因果\n📝 清单：方便保存\n💬 朋友圈：像真实分享\n🎬 视频：先让人看懂画面\n\n事实不变，表达换轨。\n\n' + terms.slice(0, 6).map(term => '#' + term.replace(/\s+/g, '')).join(' ')
  const imagePrompt = 'Editorial content repurposing board showing one long-form article branching into a Markdown explainer, saveable checklist, friend-feed note, and video storyboard; warm white paper, black ink, coral and electric blue accents, Chinese typography placeholders, clean studio light, 4:5 portrait'
  const rawPlatformDrafts = { x: xPost, xiaohongshu, zhihu, wechat, wechat_moments: wechatMoments, weibo, bilibili, douyin, kuaishou, linkedin, threads, reddit, tiktok, youtube, medium, facebook, instagram }
  const platformDrafts = Object.fromEntries(Object.entries(rawPlatformDrafts).map(([name, draft]) => [name, appendSourceUrl(name, draft, sourceUrl)]))
  const redNote = xiaohongshu
  const selected = activePlatform(platform)
  return { titles, hook, quote, xPost, redNote, platformDrafts, publishText: platformDrafts[selected], imagePrompt, hashtags: terms.slice(0, 6).map(term => '#' + term), platform }
}

function makeEnglishKit(top, terms, platform, sourceUrl) {
  const idea = stripPunctuation(top)
  const keywordText = terms.slice(0, 3).join(', ') || 'this idea'
  const titles = [
    'The part of "' + clamp(idea, 44) + '" people will miss',
    'Why ' + keywordText + ' matters more than it looks',
    'A counterintuitive take: ' + clamp(idea, 48),
  ]
  const quote = clamp(top.replace(/^[\"“]|[\"”]$/g, ''), 120)
  const hook = 'The useful part is easy to miss: ' + quote
  const xPost = 'A long-form source should not become the same post everywhere.\n\nStart with one defensible idea: ' + idea + '. Keep the evidence fixed, then change the entry point for each channel.\n\nThat is how a product story, essay, course, event, or personal point of view becomes a real publicity matrix. Where would you publish first?'
  const xiaohongshu = titles[1] + '\n\n' + hook + '\n\nSave this repurposing checklist:\n\n1) Pick one reader question\n2) Answer it with source evidence\n3) Turn the method into steps people can keep\n4) Rewrite the opening for the platform\n5) Check numbers, attribution, and absolute claims\n\nThis works for product launches, essays, courses, events, and creator notes.\n\n' + terms.slice(0, 5).map(term => '#' + term.replace(/\s+/g, '')).join(' ')
  const zhihu = '# ' + titles[2] + '\n\n## Short answer\n\n' + idea + '. The important move is to keep the claim boundary stable while changing the reading path.\n\n## Background\n\nA long article, product story, course page, or event brief contains more than one publishable entry point. A short post needs tension; an explainer needs context; a video needs a visual beat.\n\n## Method\n\n1. **Extract the thesis**: ' + clamp(top, 130) + '\n2. **Map the evidence**: keep the examples, numbers, and attribution attached to the claim they support.\n3. **Adapt the structure**: use a checklist for saves, Markdown sections for explanation, and a shot list for video.\n\n## Limits\n\nThis answer stays inside the supplied source. Verify metrics, customer stories, dates, and outcomes before publishing.\n\nWhat format do you find hardest to write from one source?'
  const wechat = 'Title: ' + titles[0] + '\n\nSummary: ' + hook + '\n\n## Why one source needs several openings\n\nLong-form writing is usually rich with context, but publishing surfaces ask different questions. A friend feed wants a human reason to share. A professional network wants a clear lesson. A video needs the first visual before the explanation.\n\n## A practical publicity matrix\n\nStart with the source thesis: ' + clamp(top, 150) + '\n\nThen map the evidence behind it, choose the audience for each channel, and rewrite the order rather than merely shortening the sentences. The result can include a full article, a concise post, a saveable checklist, a community discussion, and a shot-by-shot script.\n\n## Before publishing\n\nKeep every number, quote, date, and outcome traceable to the source. If a claim cannot be supported, soften it or remove it. A wider distribution plan is only useful when the original idea remains recognisable.'
  const wechatMoments = hook + '\n\nI am trying a calmer way to publish: keep one long-form source, pull out the evidence, and give each platform its own opening. Less copy-paste, more room for the idea to sound like itself.'
  const imagePrompt = 'Editorial publicity matrix showing one long-form source branching into a Markdown explainer, saveable checklist, newsletter article, friend-feed note, community discussion, and short-video storyboard; warm white paper, black ink, coral and electric blue accents, clean studio light, 4:5 portrait'
  const bilibili = 'Video title: ' + titles[1] + '\n\n[0-3s | Visual] Show one long article copied into four identical posts.\n[3-12s | Voiceover] ' + hook + '\n[12-28s | Demo] Turn the thesis into a Markdown explainer, a saveable checklist, and a friend-feed share.\n[28-48s | Explanation] The source stays fixed; the hook, pacing, visuals, and CTA change with the audience.\n[48-60s | CTA] Pick one source and build its first publicity matrix this week.'
  const douyin = '[45-second script]\nHook: You wrote a strong article, so why does every launch post sound identical?\nTurn: The problem is not a lack of content. It is a lack of platform-specific openings.\nMethod: explainer for context, checklist for saves, friend-feed note for trust, shot list for video.\nClose: Keep the evidence. Change the entry point. Check the claim before you publish.'
  const threads = 'One source can carry more than one conversation.\n\nA product story needs a different opening on a professional network, a friend feed, a video, and a Markdown explainer.\n\nKeep the evidence fixed. Change the entry point. That is the publicity matrix.'
  const reddit = '## ' + titles[2] + '\n\nI am testing a general repurposing workflow for product stories, essays, courses, events, and personal notes. The source stays fixed, while each channel gets its own information architecture: context for explainers, a checklist for saves, a human share for friend feeds, and a shot list for video.\n\nThe hard part is not making more drafts. It is keeping every claim traceable while changing how people enter the idea. What is your rule for avoiding copy-paste content?'
  const tiktok = '[TikTok script]\nHook: Your article is not boring. Your launch post is just using the wrong opening.\nBeat 1: Show the same paragraph on four platforms.\nBeat 2: Turn it into a checklist, explainer, friend-feed note, and shot list.\nPayoff: Same evidence, different reading path.\nCTA: What source would you repurpose first?\n\n' + terms.slice(0, 5).map(term => '#' + term.replace(/\s+/g, '')).join(' ')
  const youtube = '[YouTube Short storyboard]\n0-3s: Four identical posts appear on screen.\n3-12s: Ask why a strong article gets ignored after launch.\n12-28s: Show a Markdown explainer, saveable checklist, friend-feed share, and video shot list.\n28-46s: Explain that the evidence stays fixed while the reading path changes.\n46-60s: Invite viewers to choose one source and one first channel.'
  const medium = '# ' + titles[2] + '\n\n' + hook + '\n\nA long-form source is a small library of claims, evidence, examples, and unanswered questions. Treating it as one shortened post leaves most of its useful surface area unused.\n\nA publicity matrix starts with the thesis, maps each supporting detail, and then chooses a different entry point for each audience. The article can become an explainer, a checklist, a community prompt, a friend-feed note, and a video storyboard without changing what the source actually says.\n\nThe discipline is simple: preserve attribution, verify numbers and dates, and remove any outcome the source cannot support.'
  const facebook = hook + '\n\nI have been thinking about how much good work gets trapped inside one long post. A product story, essay, course, event, or personal note can travel further when each platform gets a human opening of its own. The facts stay the same; the invitation changes.'
  const instagram = titles[0] + '\n\nOne source. Six openings.\n\n• Explainer: add context\n• Checklist: make it saveable\n• Friend feed: make it personal\n• Video: show the first beat\n• Community: ask a real question\n\nKeep the evidence. Change the entry point.\n\n' + terms.slice(0, 5).map(term => '#' + term.replace(/\s+/g, '')).join(' ')
  const weibo = 'A long-form source should not become the same post everywhere. Keep one defensible idea, keep the evidence attached, and change the opening for each audience. That is how a product story becomes a publicity matrix.'
  const kuaishou = '[Short-video script] A good article does not need more copy-paste. Find its strongest idea, show the evidence, and give each platform a native opening: checklist, explainer, friend-feed share, or shot list. Same source, more ways in.'
  const linkedin = titles[0] + '\n\nA practical way to launch any product, project, article, course, event, or point of view:\n\n- Extract one defensible thesis\n- Keep evidence attached to the claim\n- Map the audience and reading context\n- Rewrite the information architecture for each channel\n- Verify numbers, dates, attribution, and outcomes\n\nThe goal is not to publish the same message everywhere. It is to make one source legible in several professional conversations.'
  const rawPlatformDrafts = { x: xPost, xiaohongshu, zhihu, wechat, wechat_moments: wechatMoments, weibo, bilibili, douyin, kuaishou, linkedin, threads, reddit, tiktok, youtube, medium, facebook, instagram }
  const platformDrafts = Object.fromEntries(Object.entries(rawPlatformDrafts).map(([name, draft]) => [name, appendSourceUrl(name, draft, sourceUrl)]))
  return { titles, hook, quote, xPost, redNote: linkedin, platformDrafts, publishText: platformDrafts[activePlatform(platform)], imagePrompt, hashtags: terms.slice(0, 5).map(term => '#' + term.replace(/\s+/g, '')), platform }
}

function shareability(text, ranked, terms) {
  const lower = text.toLowerCase()
  let score = 36
  const signals = []
  if (/\d/.test(text)) {
    score += 14
    signals.push('specificity')
  }
  if (CONTRAST_WORDS.some(word => lower.includes(word))) {
    score += 18
    signals.push('tension')
  }
  if (/[?！？!]/.test(text)) {
    score += 10
    signals.push('conversation')
  }
  if (terms.length >= 3) {
    score += 8
    signals.push('clear topic')
  }
  if (ranked[0].sentence.length >= 24 && ranked[0].sentence.length <= 150) {
    score += 8
    signals.push('quotable length')
  }
  if (signals.length === 0) signals.push('needs a sharper contrast or concrete detail')
  return { score: Math.min(100, score), signals }
}

export function buildKit(input, options = {}) {
  const text = clean(input)
  if (!text) throw new Error('text is required')
  const maxInputChars = Number(options.maxInputChars == null ? 24000 : options.maxInputChars)
  if (text.length > maxInputChars) throw new Error('text is too long; limit is ' + maxInputChars + ' characters')
  const language = languageOf(text, options.language)
  const sentences = splitSentences(text)
  const ranked = (sentences.length ? sentences : [text]).map((sentence, index, all) => ({ sentence, score: scoreSentence(sentence, index, all) })).sort((a, b) => b.score - a.score)
  const top = ranked[0].sentence
  const terms = keywords(text, language)
  const platform = options.platform || 'x'
  const kit = language === 'zh' ? makeChineseKit(top, terms, platform, options.sourceUrl) : makeEnglishKit(top, terms, platform, options.sourceUrl)
  const riskFlags = []
  if (/\d+%|\$\d+|€\d+|¥\d+/.test(text)) riskFlags.push('Contains numbers or prices: verify before publishing.')
  if (/[“”"].+[“”"]/.test(text)) riskFlags.push('Contains quoted language: preserve attribution.')
  if (/(guarantee|稳赚|保证|必然|always|never|only|ever|everyone|must)/i.test(text)) riskFlags.push('Contains absolute claims: soften unless you can prove them.')
  return {
    schemaVersion: '0.1',
    language,
    platform,
    source: { characters: text.length, sentences: sentences.length, keywords: terms, ...(options.sourceUrl ? { url: options.sourceUrl } : {}) },
    coreIdea: clamp(top, 180),
    evidence: ranked.slice(0, 3).map(item => item.sentence),
    shareability: shareability(text, ranked, terms),
    confidence: Math.min(0.98, Math.max(0.42, 0.46 + ranked[0].score / 10)),
    ...kit,
    riskFlags,
    generatedBy: 'dsh-promotion-toolkit/local-heuristics',
  }
}
