import { buildKit } from './engine.js'
import { defineTool } from '@deepseek-ai/dsh-tools'
import { VIRAL_KIT_SKILL } from './skill.js'

export const name = '@lhmd/dsh-promotion-toolkit'
export const inject = ['tools', 'skills']

const CHINESE_PLATFORMS = ['xiaohongshu', 'zhihu', 'wechat', 'wechat_moments', 'weibo', 'bilibili', 'douyin', 'kuaishou']
const ENGLISH_PLATFORMS = ['x', 'threads', 'linkedin', 'reddit', 'tiktok', 'youtube', 'medium', 'facebook', 'instagram']

function defaultLanguageFor(platform, config) {
  const chinese = Array.isArray(config.chinesePlatforms) ? config.chinesePlatforms : CHINESE_PLATFORMS
  const english = Array.isArray(config.englishPlatforms) ? config.englishPlatforms : ENGLISH_PLATFORMS
  if (english.includes(platform)) return 'en'
  if (chinese.includes(platform)) return 'zh'
  return config.defaultLanguage === 'en' ? 'en' : 'zh'
}

function createTool(config = {}) {
  return defineTool({
    name: 'viral_kit',
    description: 'Turn any long-form source into a source-grounded publicity matrix for products, projects, articles, courses, events, and personal ideas. Generate platform-native Chinese and global copy for Xiaohongshu, Zhihu, WeChat, Moments, Weibo, Bilibili, Douyin, Kuaishou, X, Threads, LinkedIn, Reddit, TikTok, YouTube, Medium, Facebook, and Instagram.',
    parameters: {
      text: { type: 'string', required: true, description: 'Source text. Paste the content you want to package.' },
      language: { type: 'string', enum: ['auto', 'zh', 'en'], description: 'Explicit language wins. When omitted, Chinese platforms default to Chinese and global platforms default to English.' },
      platform: { type: 'string', enum: ['x', 'xiaohongshu', 'zhihu', 'wechat', 'wechat_moments', 'weibo', 'bilibili', 'douyin', 'kuaishou', 'linkedin', 'threads', 'reddit', 'tiktok', 'youtube', 'medium', 'facebook', 'instagram', 'general'], description: 'Primary publishing surface. Output includes a tailored draft for every supported platform.' },
      sourceUrl: { type: 'string', description: 'Optional canonical URL for the source, repository, product, article, or signup page. The link is added to platform CTAs without inventing a URL.' },
      maxInputChars: { type: 'integer', description: 'Input limit; defaults to 24000.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          schemaVersion: { type: 'string', required: true },
          language: { type: 'string', required: true },
          source: {
            type: 'object',
            required: true,
            additionalProperties: false,
            properties: {
              characters: { type: 'integer', required: true },
              sentences: { type: 'integer', required: true },
              keywords: { type: 'array', items: { type: 'string' }, required: true },
              url: { type: 'string' },
            },
          },
          coreIdea: { type: 'string', required: true },
          evidence: { type: 'array', items: { type: 'string' }, required: true },
          shareability: {
            type: 'object',
            required: true,
            additionalProperties: false,
            properties: {
              score: { type: 'integer', required: true },
              signals: { type: 'array', items: { type: 'string' }, required: true },
            },
          },
          titles: { type: 'array', items: { type: 'string' }, required: true },
          hook: { type: 'string', required: true },
          quote: { type: 'string', required: true },
          xPost: { type: 'string', required: true },
          redNote: { type: 'string', required: true },
          publishText: { type: 'string', required: true },
          platformDrafts: {
            type: 'object',
            required: true,
            additionalProperties: false,
            properties: {
              x: { type: 'string', required: true },
          xiaohongshu: { type: 'string', required: true },
              zhihu: { type: 'string', required: true },
              wechat: { type: 'string', required: true },
              wechat_moments: { type: 'string', required: true },
              weibo: { type: 'string', required: true },
              bilibili: { type: 'string', required: true },
              douyin: { type: 'string', required: true },
              kuaishou: { type: 'string', required: true },
              linkedin: { type: 'string', required: true },
              threads: { type: 'string', required: true },
              reddit: { type: 'string', required: true },
              tiktok: { type: 'string', required: true },
              youtube: { type: 'string', required: true },
              medium: { type: 'string', required: true },
              facebook: { type: 'string', required: true },
              instagram: { type: 'string', required: true },
            },
          },
          imagePrompt: { type: 'string', required: true },
          hashtags: { type: 'array', items: { type: 'string' }, required: true },
          riskFlags: { type: 'array', items: { type: 'string' }, required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args) {
      const platform = args.platform || config.defaultPlatform
      const language = args.language === 'auto' ? undefined : (args.language || defaultLanguageFor(platform, config))
      return buildKit(args.text, {
        language,
        platform,
        sourceUrl: args.sourceUrl,
        maxInputChars: args.maxInputChars || config.maxInputChars,
      })
    },
  })
}

export async function apply(ctx, config = {}) {
  const register = ctx && ctx.tools && ctx.tools.register
  const registerSkill = ctx && ctx.skills && ctx.skills.register
  if (typeof register !== 'function' || typeof registerSkill !== 'function') {
    throw new Error('dsh-promotion-toolkit requires the DSH tools and skills services')
  }
  const toolDisposer = register(createTool(config))
  const skillDisposer = registerSkill(VIRAL_KIT_SKILL)
  if (ctx.logger && ctx.logger.info) ctx.logger.info('%s ready: viral_kit and viral-kit skill are available', name)
  return () => {
    if (typeof skillDisposer === 'function') skillDisposer()
    if (typeof toolDisposer === 'function') toolDisposer()
  }
}

export { buildKit }
