import test from 'node:test'
import assert from 'node:assert/strict'
import { buildKit } from '../src/engine.js'

test('builds a Chinese publish-ready kit without inventing a new source fact', () => {
  const source = 'DeepSeek Harness 把能力都做成插件。真正意外的是，小团队不必等待核心版本，也能把自己的工作流装进 agent。'
  const result = buildKit(source, { language: 'zh', platform: 'x' })
  assert.equal(result.language, 'zh')
  assert.equal(result.titles.length, 3)
  assert.ok(result.shareability.score >= 50)
  assert.ok(result.evidence.length >= 1)
  assert.match(result.xPost, /小团队|工作流|agent/)
  assert.equal(result.platformDrafts.x, result.xPost)
  assert.match(result.platformDrafts.xiaohongshu, /清单|1️⃣/)
  assert.equal(result.publishText, result.xPost)
  assert.deepEqual(Object.keys(result.platformDrafts).sort(), ['bilibili', 'douyin', 'facebook', 'instagram', 'kuaishou', 'linkedin', 'medium', 'reddit', 'threads', 'tiktok', 'wechat', 'wechat_moments', 'weibo', 'x', 'xiaohongshu', 'youtube', 'zhihu'])
  assert.match(result.platformDrafts.zhihu, /# |## 先说结论/)
  assert.match(result.platformDrafts.wechat, /标题/)
  assert.ok(result.platformDrafts.wechat_moments.length < 240)
  assert.match(result.platformDrafts.bilibili, /视频标题/)
  assert.match(result.platformDrafts.douyin, /口播/)
  assert.match(result.platformDrafts.weibo, /长文|平台/)
  assert.match(result.platformDrafts.kuaishou, /快手/)
  assert.equal(result.generatedBy, 'dsh-promotion-toolkit/local-heuristics')
})

test('auto-detects English and flags absolute claims', () => {
  const result = buildKit('This is the only tool you will ever need. It saves 50% of the work.', { language: 'auto', platform: 'linkedin' })
  assert.equal(result.language, 'en')
  assert.equal(result.platform, 'linkedin')
  assert.equal(result.publishText, result.platformDrafts.linkedin)
  assert.match(result.platformDrafts.xiaohongshu, /Save this repurposing checklist/)
  assert.match(result.platformDrafts.wechat_moments, /source|publish/i)
  assert.match(result.platformDrafts.reddit, /## |Title:/)
  assert.match(result.platformDrafts.youtube, /YouTube/)
  assert.match(result.platformDrafts.medium, /# |Title:/)
  assert.ok(result.riskFlags.some(flag => flag.includes('absolute claims')))
  assert.ok(result.riskFlags.some(flag => flag.includes('numbers')))
})

test('adds a canonical source URL to platform-native drafts', () => {
  const result = buildKit('A public repository contains a reusable workflow for creators.', { language: 'en', platform: 'linkedin', sourceUrl: 'https://github.com/example/repo' })
  assert.equal(result.source.url, 'https://github.com/example/repo')
  assert.match(result.platformDrafts.linkedin, /https:\/\/github\.com\/example\/repo/)
  assert.match(result.publishText, /https:\/\/github\.com\/example\/repo/)
})

test('rejects empty and oversized input', () => {
  assert.throws(() => buildKit('   '), /text is required/)
  assert.throws(() => buildKit('abcdef', { maxInputChars: 3 }), /too long/)
})
