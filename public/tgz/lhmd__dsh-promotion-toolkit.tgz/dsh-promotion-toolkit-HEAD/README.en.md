# DSH Promotion Toolkit

[中文 README](README.md) · [Live showcase](https://lhmd.top/dsh-promotion-toolkit/) · [Live demo set](examples/live-demos.md)

> Turn any idea into platform-native publicity.

[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek%20Harness-plugin-111827)](https://github.com/deepseek-ai/deepseek-harness)
[![Model](https://img.shields.io/badge/demo-deepseek--v4--pro-0f766e)](examples/live-demos.json)
[![License](https://img.shields.io/badge/license-MIT-111827)](LICENSE)

![DSH Promotion Toolkit preview](docs/preview.svg)

## What it does

DSH Promotion Toolkit is a DeepSeek Harness-native plugin for turning a product, open-source project, article, course, event, personal point of view, or rough idea into platform-native publicity.

It extracts the thesis, quotable evidence, risk flags, and canonical URL first. Then it changes the reading path for every platform instead of shrinking one paragraph seventeen times.

```text
Any idea / source / README
            |
            v
Thesis + evidence + claim boundaries + canonical URL
            |
            v
17 native long-form drafts, posts, video scripts, and CTAs
```

## Platform-native by design

| Surface | Draft format |
| --- | --- |
| Xiaohongshu | Pain-point opening, saveable checklist, restrained emoji, hashtags, CTA |
| Zhihu | Markdown explainer with conclusion, background, method, limits, and source link |
| WeChat | Long-form article with title, lead, sections, examples, and ending |
| WeChat Moments | Short personal share with human tone and controlled information density |
| Bilibili / Douyin / Kuaishou | Shots, timestamps, voiceover, captions, cover title, and CTA |
| Weibo / X / Threads | Concise, opinionated openings with platform-specific interaction prompts |
| LinkedIn | Professional context, product background, lessons, and discussion-led CTA |
| Reddit | Community context, question-led title, evidence, and restrained self-promotion |
| TikTok / YouTube | Short-video script with visuals, voiceover, captions, and closing prompt |
| Medium | English long-form structure, section headings, context, and source link |
| Facebook / Instagram | Community share or visual short copy with emoji, tags, and canonical URL |

Supported surfaces: `xiaohongshu`, `zhihu`, `wechat`, `wechat_moments`, `weibo`, `bilibili`, `douyin`, `kuaishou`, `x`, `threads`, `linkedin`, `reddit`, `tiktok`, `youtube`, `medium`, `facebook`, and `instagram`.

## Real DeepSeek demo

The checked-in fixture was generated end to end with `deepseek-v4-pro`: four long-form sources, Chinese and English output, and 17 platform drafts per language. One source is this repository, so the examples are ready to publish.

**English LinkedIn**

```text
One source should not become the same paragraph everywhere.

DSH Promotion Toolkit turns a product story, open-source project, article, course, event, or personal idea into platform-native publicity. It extracts the thesis, evidence, risk flags, and canonical URL first, then changes the reading path for each surface.

Source and live examples: https://github.com/lhmd/dsh-promotion-toolkit
```

**English X**

```text
Tired of rewriting one idea for every platform?

DSH Promotion Toolkit extracts the claims and evidence first, then generates native drafts for X, LinkedIn, Reddit, Zhihu, Xiaohongshu, video platforms, and more. Same source. Different entry points. Canonical links stay attached.

Repo: https://github.com/lhmd/dsh-promotion-toolkit
```

See the [full JSON fixture](examples/live-demos.json), [readable code-block excerpts](examples/live-demos.md), or the [bilingual showcase](https://lhmd.top/dsh-promotion-toolkit/).

## Install into DeepSeek Harness

This repository follows the DSH profile-bundle shape. `cordis.patch.yml` mounts the package; `src/index.js` exports `apply(ctx)` and registers the `viral_kit` tool; `src/skill.js` provides the runtime Skill; and `skills/viral-kit/SKILL.md` is the readable mirror.

```bash
npm install -g @deepseek-ai/dsh
dsh plugin --profile web add /absolute/path/to/dsh-promotion-toolkit
dsh web
```

For local development:

```bash
npm test
npm run check:release
npm run demo
```

## CLI

```bash
node scripts/viral-kit.mjs \
  --text "Paste your product brief, article, course, event, or idea" \
  --language auto \
  --platform linkedin \
  --source-url https://github.com/lhmd/dsh-promotion-toolkit \
  --json
```

Language routing is platform-aware: Chinese surfaces default to Chinese; global surfaces default to English. An explicit `--language zh|en|auto` always wins. Pass `--source-url` when the source has a repository, product page, article, signup page, or other canonical link. The plugin places that URL in the platform-native CTA and never invents one.

## Output contract

Every call returns structured JSON with the thesis, evidence, shareability signals, title angles, platform drafts, image prompt, hashtags, and risk flags:

```json
{
  "coreIdea": "A source-grounded thesis",
  "evidence": ["Evidence to preserve"],
  "shareability": {"score": 0, "signals": []},
  "titles": ["Angle one", "Angle two", "Angle three"],
  "platformDrafts": {
    "xiaohongshu": "Saveable note",
    "zhihu": "Markdown explainer",
    "wechat_moments": "Short personal share"
  },
  "riskFlags": ["Verify before publishing"]
}
```

The model can polish language but must not add unsupported users, customers, metrics, dates, prices, outcomes, or links. Verify attribution, numbers, dates, and absolute claims before publishing.

## Live showcase

Open the [bilingual showcase](https://lhmd.top/dsh-promotion-toolkit/) to switch between four DeepSeek examples, Chinese / English, and 17 platform tabs. The source is [`docs/`](docs/).

## License

MIT
