# 中文 README

默认中文文档已经移至仓库根目录的 [`README.md`](README.md)，英文版见 [`README.en.md`](README.en.md)。

- [在线双语展示页](https://lhmd.top/dsh-promotion-toolkit/)
- [完整长文案例](examples/live-demos.md)
