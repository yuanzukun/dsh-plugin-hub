#!/usr/bin/env node
import { buildKit } from '../src/engine.js'

const args = process.argv.slice(2)
const valueAfter = flag => {
  const index = args.indexOf(flag)
  return index >= 0 ? args[index + 1] : undefined
}

if (args.includes('--help') || args.includes('-h')) {
  console.log('Usage: node scripts/viral-kit.mjs --text "..." [--language zh|en|auto] [--platform x|xiaohongshu|zhihu|wechat|wechat_moments|weibo|bilibili|douyin|kuaishou|linkedin|threads|reddit|tiktok|youtube|medium|facebook|instagram] [--source-url https://...] [--json]')
  console.log('       cat article.md | node scripts/viral-kit.mjs --stdin --json')
  process.exit(0)
}

let text = valueAfter('--text')
if (args.includes('--demo')) text = '我们做了一款面向独立创作者的长文宣发工具。它先抽取可验证的观点、证据和用户场景，再按平台重写：知乎展开方法论，小红书整理成可保存清单，公众号保留完整叙事，朋友圈写成像朋友分享，视频平台转成分镜和口播。'
if (args.includes('--stdin')) text = await new Promise(resolve => { let data = ''; process.stdin.setEncoding('utf8'); process.stdin.on('data', chunk => { data += chunk }); process.stdin.on('end', () => resolve(data)) })
if (!text) {
  console.error('Missing input. Pass --text, --stdin, or --demo.')
  process.exit(2)
}

try {
  const result = buildKit(text, { language: valueAfter('--language'), platform: valueAfter('--platform'), sourceUrl: valueAfter('--source-url'), maxInputChars: valueAfter('--max-input-chars') })
  if (args.includes('--json')) console.log(JSON.stringify(result, null, 2))
  else {
    console.log('\nDSH PROMOTION TOOLKIT · ' + result.language.toUpperCase() + ' · ' + result.platform)
    console.log('\nCORE IDEA\n' + result.coreIdea)
    console.log('\nSHAREABILITY SIGNAL\n' + result.shareability.score + '/100 · ' + result.shareability.signals.join(', '))
    console.log('\nSOURCE EVIDENCE\n' + result.evidence.map((line, index) => (index + 1) + '. ' + line).join('\n'))
    console.log('\nTITLES\n' + result.titles.map((title, index) => (index + 1) + '. ' + title).join('\n'))
    console.log('\nHOOK\n' + result.hook)
    console.log('\nX / THREAD DRAFT\n' + result.xPost)
    console.log('\nSELECTED PLATFORM DRAFT (' + result.platform + ')\n' + result.publishText)
    console.log('\nZHIHU / LONG-FORM DRAFT\n' + result.platformDrafts.zhihu)
    console.log('\nWECHAT / ARTICLE DRAFT\n' + result.platformDrafts.wechat)
    console.log('\nWECHAT MOMENTS / SHORT SHARE\n' + result.platformDrafts.wechat_moments)
    console.log('\nBILIBILI / VIDEO OUTLINE\n' + result.platformDrafts.bilibili)
    console.log('\nDOUYIN / SHORT VIDEO SCRIPT\n' + result.platformDrafts.douyin)
    console.log('\nWEIBO / MICROBLOG\n' + result.platformDrafts.weibo)
    console.log('\nKUAISHOU / SHORT VIDEO SCRIPT\n' + result.platformDrafts.kuaishou)
    console.log('\nTHREADS / SHORT POST\n' + result.platformDrafts.threads)
    console.log('\nREDDIT / DISCUSSION POST\n' + result.platformDrafts.reddit)
    console.log('\nTIKTOK / SHORT VIDEO SCRIPT\n' + result.platformDrafts.tiktok)
    console.log('\nYOUTUBE / SHORT SCRIPT\n' + result.platformDrafts.youtube)
    console.log('\nMEDIUM / ARTICLE DRAFT\n' + result.platformDrafts.medium)
    console.log('\nFACEBOOK / POST\n' + result.platformDrafts.facebook)
    console.log('\nINSTAGRAM / CAPTION\n' + result.platformDrafts.instagram)
    console.log('\nIMAGE PROMPT\n' + result.imagePrompt)
    console.log('\nHASHTAGS\n' + result.hashtags.join(' '))
    if (result.riskFlags.length) console.log('\nCHECK BEFORE POSTING\n' + result.riskFlags.map(flag => '- ' + flag).join('\n'))
  }
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
}
