#!/usr/bin/env node
import { writeFile } from 'node:fs/promises'
import { buildKit } from '../src/engine.js'

const apiKey = process.env.DEEPSEEK_API_KEY
if (!apiKey) throw new Error('DEEPSEEK_API_KEY is required; pass it as a temporary environment variable')

const platforms = ['x', 'xiaohongshu', 'zhihu', 'wechat', 'wechat_moments', 'weibo', 'bilibili', 'douyin', 'kuaishou', 'linkedin', 'threads', 'reddit', 'tiktok', 'youtube', 'medium', 'facebook', 'instagram']
const cases = [
  {
    id: 'product-launch',
    label: 'Product launch story',
    labelZh: '产品发布长文',
    sourceUrl: 'https://github.com/lhmd/dsh-promotion-toolkit',
    source: '我们做了一款面向独立创作者的长文宣发工具。最初的产品说明有十几个段落，里面混着用户场景、功能边界、为什么不做自动编造，以及使用中的记录。我们没有把它压缩成一条万能文案，而是先抽取可验证的观点、证据和反例，再按平台重写：知乎展开方法论和取舍，小红书整理成可保存清单，公众号保留完整叙事，朋友圈写成像朋友分享，视频平台转成分镜和口播。实际使用时最明显的变化不是发布数量，而是每次打开草稿箱都知道下一步该写什么。这个工具的目标不是让每个平台说同一句话，而是让同一个真实故事拥有更多进入读者视线的入口。',
  },
  {
    id: 'indie-builder',
    label: 'Indie builder log',
    labelZh: '独立开发者日志',
    source: 'I stopped adding features for a week and rebuilt my tiny SaaS onboarding flow around one question: what should a new user accomplish in the first five minutes? The result was not a bigger dashboard. It was a shorter path from the first click to a useful result, with fewer choices and a clear next action. I documented the trade-offs, the screens I removed, the questions that remained, and the signs I will watch before deciding whether the change worked.',
  },
  {
    id: 'creator-workflow',
    label: 'Creator workflow',
    labelZh: '创作者工作流',
    source: '我把每天收藏的文章、会议纪要和灵感碎片，整理成一个可复用的内容工作流。过去我通常会把同一段文字复制到多个平台，再补几个标签，结果每个平台都像半成品。后来我先提取一个能被引用的观点，给它标出原文证据和不能越过的边界，再为不同平台改写：知乎写背景与因果，小红书写步骤和清单，公众号保留完整叙事，朋友圈只留下一个真实的分享理由，短视频则先设计画面和口播。为了验证它是否真的有用，我记录了几类反馈：哪些内容被保存，哪些内容引发回复，哪些内容虽然写得很长却没人看。这样做的价值不是每天发更多，而是减少从想法到发布之间的摩擦。',
  },
  {
    id: 'repo-promotion',
    label: 'This repository promotion',
    labelZh: '本仓库宣发实战',
    sourceUrl: 'https://github.com/lhmd/dsh-promotion-toolkit',
    source: '我们把一个 DeepSeek Harness 插件做成了通用内容宣发工具。它不只服务于某个框架的首发，也适合产品故事、开源项目、文章、课程、活动和个人经验。输入一篇长文后，工具先抽取核心观点、可引用证据和需要核验的风险，再为小红书、知乎、公众号、朋友圈、微博、B 站、抖音、快手、X、Threads、LinkedIn、Reddit、TikTok、YouTube、Medium、Facebook 和 Instagram 分别生成内容。知乎是 Markdown 科普，小红书是带适量 emoji 的可保存清单，公众号保留长文叙事，朋友圈像朋友分享，视频平台包含分镜、口播、字幕和 CTA。我们用 deepseek-v4-pro 跑了双语长文案例，展示页和 README 直接提供可复制的结果。',
  },
]

const cleanJson = (value) => {
  const text = String(value || '').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/i, '')
  const start = text.indexOf('{')
  const end = text.lastIndexOf('}')
  if (start < 0 || end <= start) throw new Error('DeepSeek returned no JSON object')
  return JSON.parse(text.slice(start, end + 1))
}

const emptyPlatformMap = () => Object.fromEntries(platforms.map((name) => [name, '']))
const sourceLinkLabel = {
  zh: {
    xiaohongshu: '🔗 原文链接：', zhihu: '原文链接：', wechat: '原文链接：',
    wechat_moments: '🔗 ', weibo: '🔗 原文：', bilibili: '原文链接：',
    douyin: '🔗 原文：', kuaishou: '🔗 原文：',
  },
  en: {
    x: 'Source:', threads: 'Source:', linkedin: 'Source:', reddit: 'Source:',
    tiktok: 'Source:', youtube: 'Source:', medium: 'Source:', facebook: 'Source:',
    instagram: 'Source:',
  },
}

function removeUnsupportedTrialDurations(value) {
  if (typeof value !== 'string') return value
  return value
    .replace(/一个月的试用记录/g, '使用记录')
    .replace(/一个月的试用中/g, '使用过程中')
    .replace(/一个月试用里/g, '使用过程中')
    .replace(/一个月试用/g, '实际使用')
    .replace(/试用一个月/g, '实际使用')
    .replace(/连续记录了一个月/g, '持续记录了一段时间')
    .replace(/连续记录一个月/g, '持续记录一段时间')
    .replace(/一个月时间/g, '一段时间')
    .replace(/一个月后/g, '使用后')
    .replace(/一个月下来/g, '使用下来')
    .replace(/一个月发现/g, '使用后发现')
    .replace(/一个月的最大变化/g, '最明显的变化')
    .replace(/一个月的内容工作流/g, '可复用的内容工作流')
    .replace(/一个月的个人记录/g, '个人记录')
    .replace(/一个月记录/g, '记录结果')
    .replace(/一个月看看变化/g, '看看变化')
    .replace(/一个月把/g, '把')
    .replace(/一个月/g, '一段时间')
    .replace(/上个月/g, '此前')
    .replace(/one-month trial record/gi, 'trial record')
    .replace(/one-month trial/gi, 'trial')
    .replace(/one-month test/gi, 'test')
    .replace(/one-month tracking/gi, 'tracking')
    .replace(/one-month experiment/gi, 'experiment')
    .replace(/month-long/gi, 'short')
    .replace(/after one month/gi, 'after using it')
    .replace(/over one month/gi, 'over time')
    .replace(/tracked for a month/gi, 'tracked the results')
    .replace(/tracking for a month/gi, 'tracking the results')
    .replace(/track for a month/gi, 'track the results')
    .replace(/for a month/gi, 'over time')
    .replace(/last month/gi, 'previously')
    .replace(/a month/gi, 'a while')
    .replace(/one month/gi, 'a period of time')
}

function sanitizeGenerated(value) {
  if (Array.isArray(value)) return value.map(sanitizeGenerated)
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, sanitizeGenerated(item)]))
  return removeUnsupportedTrialDurations(value)
}

function ensureSourceUrl(platform, text, language, sourceUrl) {
  if (!sourceUrl || String(text || '').includes(sourceUrl)) return text
  const label = sourceLinkLabel[language][platform] || (language === 'zh' ? '原文链接：' : 'Source:')
  return `${String(text || '').trim()}\n\n${label}${sourceUrl}`
}

async function polishCase(item, index) {
  const baseline = buildKit(item.source, { language: 'auto', platform: 'x', sourceUrl: item.sourceUrl })
  const request = {
    model: 'deepseek-v4-pro',
    temperature: 0.75,
    response_format: { type: 'json_object' },
    messages: [
      {
        role: 'system',
        content: 'You are a bilingual publicity editor for a general content repurposing plugin. Return valid JSON only. The source may describe a product, project, article, course, event, or personal point of view; it is not automatically a DeepSeek Harness launch. Make copy vivid and specific, but do not invent facts, metrics, customers, dates, trial periods, usage durations, integrations, or outcomes. Keep every claim inside the source. Adapt structure to each platform instead of copying one draft. Chinese is native and energetic; English is concise and natural for global audiences. Use emojis as platform-native punctuation, not decoration: Xiaohongshu and Instagram may use 3-6 relevant emojis for visual sections, WeChat Moments may use 1-2 natural emojis, video captions may use a few beat markers, while Zhihu, WeChat articles, X, Threads, LinkedIn, and Reddit should stay restrained. If a canonical source URL is provided, include it in the final CTA in every platform-native format; never invent or omit a provided URL. Never use the slogan "a useful plugin should give the agent a new habit" unless the exact source explicitly says it.',
      },
      {
        role: 'user',
        content: `Create a complete cross-platform demo for this general publicity source. It may be a product launch, project update, article, course, event, or personal idea. Do not frame it as a DeepSeek Harness launch unless the source itself does. The local engine already extracted evidence and signals; preserve their meaning. Return exactly {"zh":{"tagline":"","coreIdea":"","titles":["","",""],"hook":"","quote":"","platforms":{"x":"","xiaohongshu":"","zhihu":"","wechat":"","wechat_moments":"","weibo":"","bilibili":"","douyin":"","kuaishou":"","linkedin":"","threads":"","reddit":"","tiktok":"","youtube":"","medium":"","facebook":"","instagram":""},"hashtags":["","","","",""],"imagePrompt":""},"en":{"tagline":"","coreIdea":"","titles":["","",""],"hook":"","quote":"","platforms":{"x":"","xiaohongshu":"","zhihu":"","wechat":"","wechat_moments":"","weibo":"","bilibili":"","douyin":"","kuaishou":"","linkedin":"","threads":"","reddit":"","tiktok":"","youtube":"","medium":"","facebook":"","instagram":""},"hashtags":["","","","",""],"imagePrompt":""}}. Make every draft materially different and long enough to be useful. Requirements: Xiaohongshu/Instagram use a strong title, pain point, conversational saveable checklist, 3-6 relevant emojis, and hashtags; Zhihu must be a Markdown answer with # title, ## conclusion, ## background, ## method, and ## limits and no decorative emoji; WeChat/Medium must be substantial article drafts with title, lead, sections, and ending; WeChat Moments must be a short personal share under 120 Chinese characters with no more than 2 natural emojis (or 2-3 natural English sentences); Bilibili/YouTube/Douyin/Kuaishou/TikTok must include shots, timestamps, voiceover, captions, CTA, and only a few emoji beat markers; X/Threads/Weibo must be concise but distinct with restrained emoji; LinkedIn should be professional and practical; Reddit should invite discussion without marketing hype. For repository or open-source sources, mention the actual repo/tool only when the source supports it and make the copy ready to paste as a launch post. Do not state a fixed trial period or usage duration unless the source explicitly provides it. Add the provided canonical URL to each platform's native CTA: ${item.sourceUrl || '(none provided; do not invent one)'}. Never say the content went viral. Never use the unrelated slogan "a useful plugin should give the agent a new habit".\n\nSOURCE:\n${item.source}\n\nLOCAL EVIDENCE:\n${baseline.evidence.join('\n')}\n\nLOCAL SIGNALS:\n${baseline.shareability.signals.join(', ')}\n\nLOCAL SCORE:\n${baseline.shareability.score}/100`,
      },
    ],
  }
  const response = await fetch('https://api.deepseek.com/chat/completions', {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${apiKey}` },
    body: JSON.stringify(request),
  })
  if (!response.ok) throw new Error(`DeepSeek request ${index + 1} failed: ${response.status} ${await response.text()}`)
  const payload = await response.json()
  const polished = cleanJson(payload.choices?.[0]?.message?.content)
  for (const language of ['zh', 'en']) {
    if (!polished[language] || !Array.isArray(polished[language].titles) || !polished[language].platforms) throw new Error(`DeepSeek response ${index + 1} is missing ${language} fields`)
    polished[language] = sanitizeGenerated(polished[language])
    polished[language].platforms = { ...emptyPlatformMap(), ...polished[language].platforms }
    for (const platform of platforms) {
      polished[language].platforms[platform] = ensureSourceUrl(platform, polished[language].platforms[platform], language, item.sourceUrl)
    }
  }
  return {
    ...item,
    baseline: {
      language: baseline.language,
      score: baseline.shareability.score,
      signals: baseline.shareability.signals,
      evidence: baseline.evidence,
      platformCount: Object.keys(baseline.platformDrafts).length,
    },
    polished,
  }
}

const results = []
for (let index = 0; index < cases.length; index += 1) {
  process.stderr.write(`Generating live demo ${index + 1}/${cases.length}: ${cases[index].id}\n`)
  results.push(await polishCase(cases[index], index))
}

const output = {
  schemaVersion: '0.2',
  generatedAt: new Date().toISOString(),
  provider: 'DeepSeek API / deepseek-v4-pro',
  note: 'Generated from the local DSH Promotion Toolkit baseline, then source-checked for demo use.',
  platforms,
  cases: results,
}
const json = JSON.stringify(output, null, 2) + '\n'
await writeFile('examples/live-demos.json', json)
await writeFile('docs/live-demos.js', `window.DSH_LIVE_DEMOS = ${json};\n`)

const first = results[0]
function codeBlock(value) {
  const text = String(value || '').trim()
  const longestBacktickRun = Math.max(0, ...[...text.matchAll(/`+/g)].map((match) => match[0].length))
  const fence = '`'.repeat(Math.max(3, longestBacktickRun + 1))
  return `${fence}text\n${text}\n${fence}`
}

const excerpt = [
  '# Live DeepSeek demo set',
  '',
  `Generated at: ${output.generatedAt}`,
  '',
  ...results.map((item) => `## ${item.labelZh} / ${item.label}\n\n### 中文 X\n\n${codeBlock(item.polished.zh.platforms.x)}\n\n### 中文小红书\n\n${codeBlock(item.polished.zh.platforms.xiaohongshu)}\n\n### 中文朋友圈\n\n${codeBlock(item.polished.zh.platforms.wechat_moments)}\n\n### English X\n\n${codeBlock(item.polished.en.platforms.x)}\n\n### English LinkedIn\n\n${codeBlock(item.polished.en.platforms.linkedin)}\n`),
].join('\n')
await writeFile('examples/live-demos.md', excerpt)
process.stdout.write(JSON.stringify({ cases: results.length, platforms: platforms.length, firstZhX: first.polished.zh.platforms.x }, null, 2) + '\n')
