import { access } from 'node:fs/promises'
import { readFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(fileURLToPath(new URL('..', import.meta.url)))
const packageJson = JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8'))
const requiredFiles = [
  'README.md',
  'README.en.md',
  'README.zh.md',
  'cordis.patch.yml',
  'src/index.js',
  'src/engine.js',
  'src/skill.js',
  'skills/viral-kit/SKILL.md',
  'README.i18n.yaml',
  'examples/demo-input.md',
]

for (const file of requiredFiles) await access(resolve(root, file))
if (packageJson.name !== '@lhmd/dsh-promotion-toolkit') throw new Error('package name mismatch')
if (packageJson.dsh?.bundle?.patch !== './cordis.patch.yml') throw new Error('missing dsh bundle patch')
if (!packageJson.dsh?.skill || !packageJson.dsh?.tool) throw new Error('missing dsh runtime entry points')
if (!packageJson.bin?.['dsh-promotion-toolkit']) throw new Error('missing CLI bin')
if (!packageJson.peerDependencies?.['@deepseek-ai/dsh-tools']) throw new Error('missing dsh-tools peer dependency')
console.log('release check passed')
console.log('required files:', requiredFiles.length)
console.log('package:', packageJson.name + '@' + packageJson.version)
