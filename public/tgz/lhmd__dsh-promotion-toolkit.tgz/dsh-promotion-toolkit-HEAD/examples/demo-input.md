# 产品宣发工作流

我们做了一款面向独立创作者的长文宣发工具。它不替你编造卖点，而是先从产品故事里抽取可验证的观点、证据和用户场景，再按不同平台重写。

知乎适合展开方法论，小红书适合整理成可保存清单，公众号适合保留完整叙事，朋友圈适合写成像朋友分享，视频平台则需要分镜和口播。它的目标不是让每个平台说同一句话，而是让同一个真实故事拥有更多进入读者视线的入口。

This demo asks DSH Promotion Toolkit to turn that idea into platform-ready publicity while keeping every claim grounded in the source.
