/**
 * DSH 插件的 **LLM 适配器**（Provider 侧）。
 *
 * 这是「模型分组 + 倍率标签必须作用在 DSH 对话框原生模型下拉选择器」这条
 * 硬要求的落点。实现依据是 DSH 的真实契约（`@deepseek-ai/dsh-llm` +
 * `dsh-api-session-controller/lib/types/catalog.js` 的 `buildModelCatalog()`）：
 *
 * ```ts
 * // 宿主把每个已注册 provider 变成一个分组：
 * { id: provider.id, name: provider.name, models: [{ id, name, description, reasoning }] }
 * // 客户端 ui-model-selection 用 MenuGroup(label = group.name) 渲染分组标题，
 * // 用 model.name 渲染每一行。
 * ```
 *
 * 所以：
 *
 *   - **分组** = 一个 Agent 注册一个 provider 路由（`multiagent-opencode` …），
 *     `providerInfo().name` 就是分组标题（`OpenCode` / `Qoder` / …）。
 *   - **倍率标签** = 行标签走 `LlmModelInfo.name`，格式 `<Agent> · <模型> (×N)`，
 *     与任务书给的示例 `OpenCode · DeepSeek-R1 (×2)` 完全一致。
 *
 * 三个必须小心的点（踩了就是「模型列表空着」）：
 *   1. `listModels()` **必须**实现 —— 基类默认返回空数组，GUI 就不给选；
 *   2. `resolveModel()` 里 `provider`/`id` 必须与请求的**完全一致**，否则
 *      `normalizeModelInfo` 会抛 `INVALID_MODEL_INFO`；
 *   3. 一个 provider 路由只能有一个 adapter（重复注册抛 `DUPLICATE_ADAPTER`），
 *      所以「未启用的 Agent」干脆不注册那条路由，而不是注册一个空 adapter。
 */

import { formatMultiplier } from '../core/types.js'
import {
  CANONICAL_REASONING_EFFORTS,
  defaultReasoningEffortFor,
  reasoningEffortName,
  reasoningEffortsForDeclared,
  translateReasoningEffort,
} from '../core/reasoning.js'
import type { AccountRecord, AdapterContext, AgentAdapter, ErrorKind, ModelMeta, TokenUsage } from '../core/types.js'
import { computeTps } from '../core/request-log.js'
import type { RequestLogEntry } from '../core/request-log.js'
import type { AccountManager } from '../core/accounts.js'
import type { AccountRouter } from '../core/router.js'

// ───────────────────────── DSH 侧类型（结构化声明，不 import 宿主包） ─────────────────────────
//
// 为什么不 `import type { LlmAdapter } from '@deepseek-ai/dsh-llm'`：
// 插件的 `peerDependencies` 里没有也不该有它 —— `dsh-llm` 是宿主自带包，
// 插件运行时拿到的是**宿主那一份实例**。用结构化声明，接口形状对得上即可，
// 版本漂移也不会在装载期变成 `ERR_MODULE_NOT_FOUND`。

/** `LlmProviderInfo`。 */
export interface DshProviderInfo {
  id: string
  name: string
}

/** `LlmModelInfo`（`name` 就是选择器里那行字）。 */
export interface DshModelInfo {
  provider: string
  id: string
  name: string
  description?: string
  inputModalities?: string[]
}

/**
 * `ImageRequestTarget`：适配器发给上游的请求版图片尺寸与字节上限。
 *
 * DSH 0.2.1 起 `LlmAdapter` 多了 `imageRequestTarget()`，token meter 与
 * 截图类调用方会同步问一次。宿主用的是鸭子类型，缺这个方法不会在装载期报错，
 * 只会在**真正调用时**抛 `is not a function`（压缩对话就是这么崩的）。
 */
export interface DshImageRequestTarget {
  width: number
  height: number
  maxBytes: number
}

/** `ImageAttachmentRef`（只声明这里读的四个字段）。 */
export interface DshImageRef {
  attachmentId?: string
  width: number
  height: number
  bytes: number
  [key: string]: unknown
}

/**
 * DSH 内容流里的一次图片出现（`ImageBlock`，只声明定价要读的字段）。
 *
 * `offloaded: true` 表示 DSH 已经把它换成占位文本了，不会真的发出去。
 */
export interface DshImageBlock {
  type: 'image'
  offloaded?: boolean
  attachment: DshImageRef
  [key: string]: unknown
}

/** 一次图片出现的计价结果（`LlmImageRequestPricing` 的元素）。 */
export interface DshImagePrice {
  /** 上游按视觉规则要收的 token；本网关恒为 0。 */
  visualTokens: number
  /** 这次出现在模型请求里实际占的文本。 */
  text: string
}

/** `LlmImageRequestPricing`：同步给出每一次图片出现的计价。 */
export interface DshImageRequestPricing {
  priceImages(images: readonly DshImageBlock[]): DshImagePrice[]
}

/**
 * 宿主附件服务里「一次请求版图片」的返回（`readImageRequest()`）。
 *
 * 只声明用得到的字段：`data` 是**已经按 target 压过**的编码字节，
 * `mediaType` 是压缩后的真实 MIME（可能从 png 变成 jpeg）。
 */
export interface DshImageVersion {
  data: Uint8Array
  mediaType: string
  width?: number
  height?: number
}

/**
 * 宿主的附件服务（`ctx.get('attachments')`）。
 *
 * **只声明一个方法**：本插件不存附件、不列附件，只在发请求前把 `ImageBlock`
 * 里的 `attachmentId` 换成真正的字节。少声明就不会因为宿主加方法而被动崩掉。
 */
export interface DshAttachmentStore {
  readImageRequest(
    ref: DshImageRef,
    target: DshImageRequestTarget,
    signal?: AbortSignal,
  ): Promise<DshImageVersion | undefined>
}

/** `LlmResolvedModelInfo`。 */
export interface DshResolvedModelInfo extends DshModelInfo {
  context?: { contextWindow: number }
  defaultMaxTokens?: number
  reasoning?: {
    efforts: Array<{ id: string; name: string; description?: string }>
    defaultEffort?: string
  }
}

/** `LlmFailure`。 */
export interface DshFailure {
  message: string
  code: string
  status?: number
  providerRetryAfterMs?: number
  requestId?: string
}

/** `StreamChunk`（联合类型，这里用宽形状即可）。 */
export type DshStreamChunk = Record<string, unknown> & { type: string }

/** 宿主传进来的 `GenerateOptions`（只声明我们读的字段）。 */
export interface DshGenerateOptions {
  provider: string
  model: string
  messages: Array<{ role: string; content?: unknown; [key: string]: unknown }>
  system?: string
  tools?: Array<{ name: string; description: string; parameters: Record<string, unknown> }>
  temperature?: number
  maxTokens?: number
  stop?: string[]
  signal?: AbortSignal
  reasoningEffort?: string
}

/** 创建 LLM 适配器需要的依赖。 */
export interface LlmAdapterDeps {
  /** 该路由对应的 agentId（`multiagent-opencode` → `opencode`）。 */
  agentId: string
  /** 分组标题。也接受**取值函数** —— 配置热更新后分组名可能变了。 */
  displayName: string | (() => string)
  /**
   * 是否在模型名里带 `<Agent> · ` 前缀。
   *
   * 同样接受取值函数：适配器实例是**注册时**建好的，捕获一个布尔值就再也读不到
   * 新配置（实测踩到过 —— 在设置页关掉「带前缀」，下拉里名字纹丝不动）。
   */
  labelWithAgent: boolean | (() => boolean)
  accounts: AccountManager
  router: AccountRouter
  /** 取适配器 + 它的运行上下文。 */
  adapterOf(agentId: string): AgentAdapter | undefined
  contextOf(agentId: string): AdapterContext | undefined
  /** 取（可能有缓存的）模型元数据。 */
  modelsOf(agentId: string, force?: boolean): Promise<ModelMeta[]>
  /**
   * **要暴露给 DSH 的**模型（已按「勾选/免费/全部」策略过滤）。
   *
   * 选择器读的是这个，不是 `modelsOf` —— 否则上游几十个模型会全塞进下拉里。
   * 可选：只给了 `modelsOf` 的调用方退化成「不过滤」（保持老行为，不炸）。
   */
  exposedModelsOf?(agentId: string, force?: boolean): Promise<ModelMeta[]>
  /**
   * 一次对话结束时的采样回调（成功与失败都会调，**只调一次**）。
   *
   * 宿主把它接到 `RequestLog` 上，就是「日志」页与总览 KPI 的数据来源。
   * 刻意做成可选：没有这个回调时适配器行为一个字节都不变。
   */
  onRequest?(sample: Omit<RequestLogEntry, 'ts'>): void
  /**
   * 取宿主的**附件服务**（`ctx.get('attachments')`）。
   *
   * 可选：拿不到时图片块按老行为丢弃（只发文本），插件其余功能一个字节都不变。
   * 做成**取值函数**而不是直接传服务实例 —— 注册路由时附件服务可能还没挂好，
   * 而且宿主重启/热重载后实例会换。
   */
  resolveAttachments?(): DshAttachmentStore | undefined
  log: AdapterContext['log']
}

/**
 * 把 `ModelMeta` 渲染成 DSH 选择器里的行标签。
 *
 * 任务书给的格式：`OpenCode · DeepSeek-R1 (×2)`。
 * 倍率取不到时显示什么，是**要不要骗用户**的分界线 —— 这里显示「未知倍率」，
 * 既不省略（省略看不出差别）也不编造。
 */
export function renderModelLabel(meta: ModelMeta, withAgentPrefix: boolean): string {
  const tag = formatMultiplier(meta.multiplier, meta.free)
  const head = withAgentPrefix ? `${meta.agentName} · ${meta.name}` : meta.name
  return `${head} (${tag})`
}

/**
 * 模型元数据 → DSH 模型列表项。
 *
 * `id` 里带 `agentId` 前缀是**刻意的**：同一分组下不同 Agent 不会重名，
 * 而将来若把多个 Agent 合到一个 provider 路由里，id 仍然唯一。
 * `stream()` 里按同样规则反解回 (agentId, upstreamModelId)。
 */
export function encodeModelId(agentId: string, upstreamId: string): string {
  return `${agentId}/${upstreamId}`
}

/** 拆回 `(agentId, upstreamModelId)`。 */
export function decodeModelId(encoded: string): { agentId: string; upstreamId: string } {
  const index = encoded.indexOf('/')
  if (index < 0) return { agentId: '', upstreamId: encoded }
  return { agentId: encoded.slice(0, index), upstreamId: encoded.slice(index + 1) }
}

/**
 * 造一个 DSH `LlmAdapter`。
 *
 * 不继承宿主的 `LlmAdapter` 抽象类：宿主用的是**鸭子类型**（它只读
 * `providerInfo` / `listModels` / `resolveModel` / `prepareCall` / `stream`），
 * 继承反而要 import 宿主包。结构化实现更不容易被版本漂移打断。
 */
export function createLlmAdapter(deps: LlmAdapterDeps): {
  providerInfo(provider: string): DshProviderInfo
  listModels(provider: string): Promise<DshModelInfo[]>
  resolveModel(provider: string, model: string, signal?: AbortSignal): Promise<DshResolvedModelInfo>
  prepareCall(provider: string, model: string, signal?: AbortSignal): Promise<{
    model: DshResolvedModelInfo
    stream(options: DshGenerateOptions): AsyncIterable<DshStreamChunk>
  }>
  stream(options: DshGenerateOptions): AsyncIterable<DshStreamChunk>
  imageRequestPricing(provider: string, model: string): DshImageRequestPricing
  imageRequestTarget(provider: string, model: string, image: DshImageRef): DshImageRequestTarget
  providerRetryPolicy(): { mode: 'normal'; maxRetries: number; retryableCodes: string[]; initialDelayMs: number; maxDelayMs: number; jitterRatio: number }
} {
  const { agentId, accounts, router, log } = deps
  /**
   * 每次读取都解析一遍，而不是解构一次就定死。
   *
   * `displayName` / `labelWithAgent` 可能传的是取值函数（配置热更新后要读新值）；
   * 常量形式在这里退化成「每次都得到同一个值」，行为不变。
   */
  const displayNameOf = (): string => (typeof deps.displayName === 'function' ? deps.displayName() : deps.displayName)
  const labelWithAgentOf = (): boolean =>
    typeof deps.labelWithAgent === 'function' ? deps.labelWithAgent() : deps.labelWithAgent

  /** 当前分组**暴露给选择器**的模型列表（已按策略过滤 + 带缓存）。 */
  const models = async (): Promise<ModelMeta[]> => {
    // `exposedModelsOf` 是可选的；没接就退化成「不过滤」（老行为）。
    const list =
      deps.exposedModelsOf === undefined ? await deps.modelsOf(agentId) : await deps.exposedModelsOf(agentId)
    return list
  }

  const info = (provider: string): DshProviderInfo => ({ id: provider, name: displayNameOf() })

  /** 从模型元数据里挑出与 DSH 路由 id 对应的那一条。 */
  const find = async (encoded: string): Promise<{ meta: ModelMeta; upstreamId: string } | undefined> => {
    const decoded = decodeModelId(encoded)
    const list = await models()
    const meta = list.find(
      (item) => item.id === decoded.upstreamId || encodeModelId(item.agentId, item.id) === encoded,
    )
    if (meta === undefined) return undefined
    return { meta, upstreamId: meta.id }
  }

  const resolve = async (provider: string, model: string, _signal?: AbortSignal): Promise<DshResolvedModelInfo> => {
    const hit = await find(model)
    const meta: ModelMeta = hit?.meta ?? {
      id: model,
      name: model,
      agentId,
      agentName: displayNameOf(),
    }
    const out: DshResolvedModelInfo = {
      provider,
      id: model,
      name: renderModelLabel(meta, labelWithAgentOf()),
    }
    if (meta.description !== undefined) out.description = meta.description
    if (meta.contextWindow !== undefined) out.context = { contextWindow: meta.contextWindow }
    if (meta.maxTokens !== undefined) out.defaultMaxTokens = meta.maxTokens
    if (Array.isArray(meta.inputModalities) && meta.inputModalities.length > 0) {
      out.inputModalities = [...meta.inputModalities]
    }
    /**
     * 思考档位行。
     *
     * ⚠️ **判据是「模型声明了哪些档位」，不是 `meta.reasoning`。**
     *
     * 原先这里外层套了 `if (meta.reasoning === true)`，于是**声明了档位但
     * `reasoning` 为假**的模型一个档位行都拿不到 —— 实测 Qoder CN 的
     * `performance` 就是这种：目录 `is_reasoning: false`（所以请求体的
     * `isReasoning` 为假），但 `thinking_config.enabled` 为真、上游**确实**提供
     * 档位选择。参考实现（`qoder-adapter.ts` 的 `resolveModel`）也只看
     * `qoderEffortsFor(entry).length > 0`，从不看 `is_reasoning`。
     *
     * 语义上两者本就独立：
     *   - `reasoning`     —— 「这个模型会不会吐思维链」（`is_reasoning`）；
     *   - `reasoningEfforts` —— 「用户能不能调它的思考强度」（`thinking_config`）。
     * 一个模型可以「不吐思维链但你仍能要求它多想想」，也可以反过来。
     *
     * ⚠️ 两者都没有时**不出档位行**：我们不知道它接受什么，编一组出来就是谎报能力。
     */
    const declared = Array.isArray(meta.reasoningEfforts) ? meta.reasoningEfforts : []
    const efforts = reasoningEffortsForDeclared(declared)
    if (efforts.length > 0) {
      const rows = efforts.map((id) => ({ id, name: reasoningEffortName(id) }))
      // 默认档：上游声明过就用它（见 `defaultReasoningEffortFor` 的优先级说明）。
      const fallback = defaultReasoningEffortFor(declared, meta.defaultReasoningEffort)
      out.reasoning = {
        efforts: rows,
        ...(fallback === undefined ? {} : { defaultEffort: fallback }),
      }
    }
    return out
  }

  /** 把上游的归一化事件翻成 DSH 的 `StreamChunk`。 */
  async function* pump(options: DshGenerateOptions, signal: AbortSignal): AsyncIterable<DshStreamChunk> {
    const decoded = decodeModelId(options.model)
    const targetAgent = decoded.agentId === '' ? agentId : decoded.agentId
    const upstreamModel = decoded.upstreamId
    const adapter = deps.adapterOf(targetAgent)
    const ctx = deps.contextOf(targetAgent)
    if (adapter === undefined || ctx === undefined) {
      yield {
        type: 'finish',
        reason: {
          kind: 'error',
          failure: { message: `「${displayNameOf()}」适配器未装载`, code: 'NO_ADAPTER' } satisfies DshFailure,
        },
      }
      return
    }

    /**
     * 本轮的**采样起点**。
     *
     * ⚠️ 必须在 `router.execute` **之前**取。原先它在 `router.execute` 之后
     * （也就是「第一个事件已经拿到」之后）才取，于是两个字段一起失真：
     *
     *   - `ttftMs` 恒为 **0** —— 「等首字」的那一整段被排除在计时之外，
     *     日志里「首字」那一列永远是 0；
     *   - `durationMs` 只剩「首字之后」的耗时，比用户真实等待短一大截
     *     （实测 Qoder `auto`：日志 679ms，真实 2044ms）。
     *
     * `computeTps` 用的是 `durationMs - ttftMs`（解码窗口），两者同步平移，
     * 所以速度大致还对；但「耗时」与「首字」两列一直在骗人。
     * 起点提前之后两者都回到真实口径，且 `computeTps` 的语义不变。
     */
    const startedAt = Date.now()

    /**
     * 当前模型的元数据 —— **倍率的唯一来源**（`ModelMeta.multiplier` / `free`）。
     *
     * ⚠️ 查不到**不是错误**，更**不能退化成 `multiplier: 0`**：
     * 我们的口径里 `0` = **免费**（见 `formatMultiplier`）。模型不在上报列表里
     * （用户没勾选）、目录还没拉到，都只是「**不知道**倍率」——
     * 给「不知道」写一个 0，等于在日志里告诉用户「这一轮不要钱」。
     * 所以查不到时采样里**不放这两个键**，让界面显示「未知倍率」。
     *
     * 查元数据本身包了 try/catch：它要读模型目录（可能打上游/读缓存），
     * 读不到不该让整轮对话失败 —— 之前这条路径只在用户传了 `reasoningEffort`
     * 时才会走到，现在无条件走，所以必须自己兜住。
     */
    let modelMeta: ModelMeta | undefined
    try {
      modelMeta = (await find(options.model))?.meta
    } catch (error) {
      deps.log.debug(
        '读取模型元数据失败，本轮不记倍率',
        error instanceof Error ? error.message : String(error),
      )
    }

    /**
     * 思考档位：把客户端选的**规范名**翻译成模型**真正声明过的** id。
     *
     * ## 为什么必须翻译而不是原样下发
     *
     * 上游会**校验** `reasoning_effort`：值不在模型接受的集合里就是 400，
     * 整轮对话直接失败（参考实现 2026-10-02 实测：非法值让错误信息变成
     * `[400] reasoning_…`）。而档位表来自 models.dev、**会被远端刷新** ——
     * 用户在选择器里选了「高」，刷新后该模型的档位集合变了（或会话恢复出一份
     * 旧选择），线上就会发出一个现在非法的值。
     *
     * ## 三态分流（对应 `translateReasoningEffort` 的四态）
     *
     * - `exact` / `mapped` → **下发**（`mapped` 记一条 debug，将来排查 400 靠它）；
     * - `unexpressible` → **不下发**并记日志：模型没有这一族档位，硬发就是 400。
     *   模型用自己的默认思考行为接管；
     * - `unknown` → **报错**：连名字都不认识（客户端 bug / 拼写错），静默吞掉
     *   等于用户以为设了其实没设。
     *
     * ⚠️ **能力未知时原样放行**（`declared === undefined`）：那是「我们不知道该模型
     * 接受什么」，此时拦下来等于把调用方的显式选择静默丢掉。这与「能力表拿到了、
     * 且明确声明了档位集合」是两种不同的处境 —— 后者的空集合表示**确实没有档位**。
     */
    const requestedEffort = options.reasoningEffort
    let reasoningEffort: string | undefined
    if (typeof requestedEffort === 'string' && requestedEffort !== '') {
      const hit = await find(options.model)
      /**
       * ⚠️ 判据是「**这个字段在不在**」，不是「它的长度」——
       * 两种 `undefined` 的处境必须分开：
       *   - `Array.isArray(...) === false`（字段缺失，例如 models.dev 整个拉失败）
       *     ⇒ 我们**不知道**该模型接受什么 ⇒ **原样放行**。此时拦下来等于把
       *       用户的显式选择静默丢掉。
       *   - `[]`（字段在、但是空的）⇒ 适配器**明确告诉我们**这模型没有档位可选
       *     ⇒ 拦下 `reasoning_effort`（上游会校验，发它没声明过的值 = 400）。
       */
      const declared = hit !== undefined && Array.isArray(hit.meta.reasoningEfforts)
        ? hit.meta.reasoningEfforts
        : undefined
      if (declared === undefined) {
        reasoningEffort = requestedEffort
      } else if (declared.length === 0) {
        deps.log.warn(
          `模型 ${upstreamModel} 没有声明任何思考档位，已忽略请求的档位`,
          `requested=${requestedEffort}（上游对该字段会校验，发它没声明过的值会 400）`,
        )
      } else {
        const translated = translateReasoningEffort(requestedEffort, declared)
        if (translated.kind === 'exact') {
          reasoningEffort = translated.effort
        } else if (translated.kind === 'mapped') {
          reasoningEffort = translated.effort
          deps.log.debug(
            `思考档位 ${requestedEffort} → ${translated.effort}（模型 ${upstreamModel} 的写法不同）`,
            `declared=[${declared.join(', ')}]`,
          )
        } else if (translated.kind === 'unexpressible') {
          deps.log.warn(
            `模型 ${upstreamModel} 表达不了档位「${requestedEffort}」，已忽略`,
            `declared=[${declared.join(', ')}]（关闭族与思考族不互译，故不会就近顶替）`,
          )
        } else {
          yield {
            type: 'finish',
            reason: {
              kind: 'error',
              failure: {
                message:
                  `无法识别的思考档位「${requestedEffort}」。` +
                  `本网关认识：${CANONICAL_REASONING_EFFORTS.join(' / ')}。`,
                code: 'UNKNOWN_REASONING_EFFORT',
              } satisfies DshFailure,
            },
          }
          return
        }
      }
    }

    // ── 图片：把 `ImageBlock` 换成真正的 data URI ──────────────────────────
    //
    // 只对**声明了视觉能力**的模型解析：没声明的模型即使收到图片块也发不出去
    // （上游会 400），继续按纯文本发，行为与 0.3.4 一致。
    //
    // 附件服务可能还没挂（headless / 精简 profile），拿不到就退化成只发文本 ——
    // 图片发不出去是降级，不该让整轮对话失败。
    const supportsVision =
      Array.isArray(modelMeta?.inputModalities) && modelMeta.inputModalities.includes('image')
    const attachments = deps.resolveAttachments?.()
    // 丢图时留一条能查的日志：用户报「模型看不见图」时，先看这里说没说为什么。
    const imageCount = countImageBlocks(options)
    if (imageCount > 0) {
      if (!supportsVision) {
        deps.log.debug(`模型 ${upstreamModel} 没声明视觉能力，${imageCount} 张图片按纯文本发送`)
      } else if (attachments === undefined) {
        deps.log.warn(`宿主没有提供附件服务（attachments），${imageCount} 张图片按纯文本发送`)
      }
    }
    const imageResolver: DshImageResolver | undefined =
      supportsVision && attachments !== undefined
        ? async (ref) => {
            try {
              const version = await attachments.readImageRequest(ref, requestImageTarget(ref), signal)
              if (version === undefined || version.data === undefined) return undefined
              const base64 = Buffer.from(version.data).toString('base64')
              return `data:${version.mediaType ?? 'image/png'};base64,${base64}`
            } catch (error) {
              deps.log.warn(
                '读取图片失败，本轮这张图按纯文本发送',
                error instanceof Error ? error.message : String(error),
              )
              return undefined
            }
          }
        : undefined

    // DSH 的 messages → OpenAI 兼容 messages（图片在这里被换成 data URI）。
    const payload = {
      model: upstreamModel,
      messages: await toOpenAiMessages(options, imageResolver),
      stream: true,
      ...(options.temperature === undefined ? {} : { temperature: options.temperature }),
      ...(options.maxTokens === undefined ? {} : { max_tokens: options.maxTokens }),
      ...(options.stop === undefined ? {} : { stop: options.stop }),
      // ⚠️ 字段名 `reasoning_effort` 由**实测**确定（参考实现 2026-10-02）：
      // 给上游传非法值时错误信息变成 `[400] reasoning_…`，说明它确实解析并校验
      // 这个字段。**不是** `reasoning`（那是我们内部的布尔开关语义）。
      ...(reasoningEffort === undefined ? {} : { reasoning_effort: reasoningEffort }),
      ...(options.tools === undefined
        ? {}
        : {
            tools: options.tools.map((tool) => ({
              type: 'function',
              function: { name: tool.name, description: tool.description, parameters: tool.parameters },
            })),
          }),
    }

    // ★ 多账号智能路由：一次调用内部自动换号、重试。
    const outcome = await router.execute<{
      events: AsyncIterable<import('../core/types.js').StreamEvent>
    }>(
      targetAgent,
      async (account: AccountRecord) => {
        const stream = adapter.requestChatStream(
          payload,
          account,
          { ...ctx, log: ctx.log.child(account.id) },
          signal,
        )
        // 先取第一个事件：这一步就能知道是不是 401/429/额度耗尽，
        // 从而在「还没往 DSH 吐任何字」的时候换号，用户看不到闪烁。
        const iterator = stream[Symbol.asyncIterator]()
        const first = await iterator.next()
        if (first.done === true) {
          return { ok: false as const, kind: 'unknown' as const, message: '上游没有返回任何事件' }
        }
        const value = first.value
        if (value.type === 'error') {
          return {
            ok: false as const,
            kind: value.failure.kind,
            message: value.failure.message,
            ...(value.failure.status === undefined ? {} : { status: value.failure.status }),
            ...(value.failure.retryAfterMs === undefined ? {} : { retryAfterMs: value.failure.retryAfterMs }),
            ...(value.failure.requestId === undefined ? {} : { requestId: value.failure.requestId }),
          }
        }
        return {
          ok: true as const,
          value: {
            events: (async function* replay(): AsyncIterable<import('../core/types.js').StreamEvent> {
              yield value
              for (;;) {
                const next = await iterator.next()
                if (next.done === true) return
                yield next.value
              }
            })(),
          },
        }
      },
      // 取消信号透传进路由：用户点「停止」后不再换号、不再退避等待。
      { signal },
    )

    // ── 采样：把这一轮的耗时 / 首字 / token / 倍率记下来（成功失败都记） ──
    // ⚠️ `startedAt` 在 `router.execute` **之前**就取好了（见上面的说明），
    //    这里绝不能再取一次 —— 那样「首字」会变回 0、耗时也短一截。
    let ttftMs: number | undefined
    let usage: TokenUsage | undefined
    let failureMessage: string | undefined
    /**
     * 失败分类（`ErrorKind`）—— 与 {@link failureMessage} 同时设置，只在失败时有值。
     *
     * 为什么要单独记：界面上「鉴权失效 / 触发限流 / 触发风控 / 额度耗尽」的
     * 处置办法**完全不同**（重新登录 / 等一会儿 / 换号 / 换号或充值）。
     * 只有上游原话 `error` 的话，界面只能靠正则去猜；而分类在宿主侧是现成的。
     */
    let failureKind: ErrorKind | undefined
    let accountId: string | null = null
    let settled = false
    /** 只会真正写一次（生成器可能在多个分支 return）。 */
    const settle = (ok: boolean): void => {
      if (settled) return
      settled = true
      if (deps.onRequest === undefined) return
      const durationMs = Date.now() - startedAt
      /**
       * 倍率与「是否免费」。
       *
       * ⚠️ 约定是「**不知道就不写，不拿 0 冒充未知**」（见 `core/request-log.ts`）。
       * 客户端 `multiplierTag()` 把 `undefined` 画成「未知倍率」、把 `0` 画成「免费」——
       * 两者对用户是完全不同的结论，而「未知」与「免费」我们分得清，就必须分开写。
       *
       * 三条分支，覆盖全部情形：
       *   - 拿到倍率 → 免不免费**是确定的**（`0` 就是免费），两个键一起写；
       *   - 没倍率但上游明确标了免费 → 只写 `free: true`（「免费」说得出口）；
       *   - 都没有 → **两个键都不写**，界面显示「未知倍率」。
       *
       * 最后一种就是用户报的那个「倍率为未知」：宁可显示未知，
       * 也不能编一个 0 出来让用户以为这一轮不要钱。
       */
      const multiplier = modelMeta?.multiplier
      const hasMultiplier = typeof multiplier === 'number' && Number.isFinite(multiplier)
      // 与 `formatMultiplier` 同一口径：上游标了 `free`，或倍率恰好是 0，都算免费。
      const free = modelMeta?.free === true || multiplier === 0
      const sample: Omit<RequestLogEntry, 'ts'> = {
        agentId: targetAgent,
        agentName: displayNameOf(),
        model: upstreamModel,
        /**
         * 展示名 —— 与 DSH 选择器里显示的那个名字一致（如 `Qwen3.8-Flash`）。
         *
         * ⚠️ **用户报障**：「请求日志的模型名全部都是 `qfmodel`，并不是真实选中的
         * 模型名称」。查下来记录**是对的** —— `qfmodel` 就是上游目录 key、
         * 也就是我们真正发出去的那个值；问题是它在界面上**根本不可见**
         * （选择器里写的是 `Qwen3.8-Flash`）。两套词汇对不上，用户自然认为记错了。
         *
         * 所以两个都存：`model` 供排查（它才是发上游的那个值），
         * `modelName` 供阅读。取不到展示名就**不写**这个键，界面退回显示 id ——
         * 绝不拿 id 冒充名字（那正是这条报障的成因）。
         */
        ...(modelMeta?.name === undefined || modelMeta.name === '' ? {} : { modelName: modelMeta.name }),
        accountId,
        ok,
        durationMs,
        ...(ttftMs === undefined ? {} : { ttftMs }),
        ...(usage?.inputTokens === undefined ? {} : { inputTokens: usage.inputTokens }),
        ...(usage?.outputTokens === undefined ? {} : { outputTokens: usage.outputTokens }),
        ...(usage?.reasoningTokens === undefined ? {} : { reasoningTokens: usage.reasoningTokens }),
        ...(usage?.cacheReadTokens === undefined ? {} : { cacheReadTokens: usage.cacheReadTokens }),
        ...(usage?.cacheWriteTokens === undefined ? {} : { cacheWriteTokens: usage.cacheWriteTokens }),
        // 0.3.8 起 `inputTokens` 是**未缓存**那一桶（issue #8）；老记录没有这个字段，
        // 界面据此区分分母（新记录 input + cacheRead，老记录 input）。
        ...(usage === undefined ? {} : { inputSemantics: 'uncached' as const }),
        ...(hasMultiplier ? { multiplier } : {}),
        ...(hasMultiplier || free ? { free } : {}),
        ...(failureKind === undefined ? {} : { errorKind: failureKind }),
        ...(failureMessage === undefined ? {} : { error: failureMessage }),
      }
      const tps = computeTps({
        durationMs,
        ...(ttftMs === undefined ? {} : { ttftMs }),
        ...(usage?.outputTokens === undefined ? {} : { outputTokens: usage.outputTokens }),
      })
      deps.onRequest(tps === undefined ? sample : { ...sample, tps })
    }

    if (!outcome.ok) {
      failureMessage = outcome.failure.message
      failureKind = outcome.failure.kind
      /**
       * ★ **失败时也要记下是哪个账号**（2026-10-27 修）。
       *
       * 原先这里只写 `failureMessage` 就 `settle(false)`，而 `accountId` 要到
       * 下面的成功分支才赋值 —— 于是**每一条失败记录都记成 `null`**，
       * 界面把 `null` 画成「免账号」。用户看到的正是那句最没用的结论：
       * 「触发限流」但不知道限的是哪个号。本机 654 条日志实测：23 条失败里
       * 22 条 `accountId === null`，唯一有值的那条是「路由成功后才断流」。
       *
       * 取 `attempts` 的**最后一次**：`execute()` 每次失败都会 push 一条，
       * 而 `attempts` 为空表示**一个候选都没轮到**（没有可用账号 / 全被排除）。
       * 两种情况的 `null` 含义不同，界面靠 `errorKind` 与文案区分。
       */
      accountId = outcome.attempts.at(-1)?.accountId ?? null
      settle(false)
      yield {
        type: 'finish',
        reason: {
          kind: 'error',
          failure: {
            message: outcome.failure.message,
            code: outcome.failure.kind.toUpperCase(),
            ...(outcome.failure.status === undefined ? {} : { status: outcome.failure.status }),
            ...(outcome.failure.retryAfterMs === undefined ? {} : { providerRetryAfterMs: outcome.failure.retryAfterMs }),
            ...(outcome.failure.requestId === undefined ? {} : { requestId: outcome.failure.requestId }),
          } satisfies DshFailure,
        },
      }
      return
    }

    accountId = outcome.accountId ?? null
    log.debug(
      `路由完成：account=${outcome.accountId} attempts=${outcome.attempts.length}`,
      outcome.attempts.map((item) => `${item.accountId}:${item.kind}`).join(','),
    )

    // ── 事件 → chunk ─────────────────────────────────────────────
    //
    // DSH 的 `BlockAssembler` 按 **index** 收块，四条硬约束（读源码确认，不是猜的）：
    //   · 同一 index 的 blockType 必须一致（text / reasoning / tool-call 各占一块）；
    //   · `tool-call-delta` 的 id 是**覆盖**式赋值（`partial.toolCallId = chunk.id`），
    //     而上游只在首帧给 id ⇒ 我们必须**每帧发同一个 id**，否则真 id 会被冲掉；
    //   · `argumentsDelta` 是**累加**的，必须原样转发；
    //   · 上游可以有**多个并行工具调用**（`tool_calls[i].index` 不同）⇒ 每个占独立块。
    let cursor = 0
    let textBlock = -1
    let reasoningBlock = -1
    /**
     * 已流出的正文与思维链原文。
     *
     * ⚠️ **必须自己攒着** —— `block-end` 不是「关闭」而是**覆盖**：
     * 宿主 `BlockAssembler.push()` 收到 `block-end` 时直接
     * `partial.block = chunk.block`，`assemble()` 又优先返回 `partial.block`，
     * 所以之前发的那一串 `text-delta` **会被整个丢掉**。
     *
     * 症状就是用户看到的那条：「有输出，但一调工具就被覆盖掉」——
     * 流式期间 delta 显示得好好的，回合收尾把文本块冲成一个空串。
     * 宿主自带的适配器（`dsh-llm-deepseek` / `dsh-llm-pi-ai`）在 `block-end`
     * 里带的都是**完整正文**（`text: event.content`），这里与它们对齐。
     */
    let textBuf = ''
    let reasoningBuf = ''
    /**
     * 是否已经收到上游的 `finish`，以及它给的终止原因。
     *
     * ⚠️ 收到 finish **不等于**这一轮结束：usage 末帧排在它后面（见 `case 'finish'`）。
     */
    let finishSeen = false
    let finishReason: string | undefined
    /** finish 之后最多等到什么时候（毫秒时间戳）。 */
    let drainUntil = 0
    /**
     * 本轮的 usage 等待窗口。
     *
     * ⚠️ **取值来自适配器，不是全局常量**：各平台发 usage 的时机差三个数量级
     * （Qoder +17ms vs 小浣熊 +472…3744ms）。全局恒定时必然有一边不对 ——
     * 见 `AgentCapabilities.usageDrainMs` 的注释。
     *
     * ⚠️ 用可选链读：`capabilities` 是 `AgentAdapter` 的**必填**字段，但这个
     * 函数是给**任何**鸭子类型适配器用的（第三方可以运行期注册）。少读一层
     * 就是一个 `TypeError` 把整轮对话打断 —— 一个「等待窗口」不值得这个风险。
     */
    const usageDrainMs = adapter.capabilities?.usageDrainMs ?? USAGE_DRAIN_MS
    /** usage 是否已经透给 DSH（finish 前透的记 `true`，之后补发时也记）。 */
    let usageYielded = false
    const toolBlocks = new Map<number, { block: number; id: string; name: string; args: string }>()
    /** 拿一个全新的块下标。 */
    const allocate = (): number => {
      const block = cursor
      cursor += 1
      return block
    }
    /**
     * 收尾该报哪种 finish。
     *
     * ⚠️ **有工具调用时必须报 `tool-calls`** —— 这一条曾让我掉进死循环：
     * 一律报 `stop` 时，DSH 认为本轮已正常结束、**不去执行工具**，
     * 模型下一轮又发同样的工具调用，表现就是「工具调用失败 + 无限循环」。
     * `max-tokens` 同理：上游说 `length` 时不能谎报 `stop`，否则截断被当成正常结束。
     */
    const finishChunk = (upstreamReason?: string): DshStreamChunk => ({
      type: 'finish',
      reason: {
        kind: toolBlocks.size > 0 ? 'tool-calls' : upstreamReason === 'length' ? 'max-tokens' : 'stop',
      },
    })
    /**
     * 关掉所有还开着的块，**幂等**（调用第二次什么也不发）。
     *
     * 抽出来是因为收尾路径变多了：`finish`、`error`、以及「流断了没给 finish」。
     * 三处各写一遍的话，`finish` 之后再收到 `error`（drain 窗口内是可能的）
     * 就会把同一个块关两次 —— DSH 侧收到两个 `block-end`，
     * 而后一个是空正文，正好又踩「覆盖式赋值把正文冲掉」那条坑。
     *
     * 工具块照旧带上累积的 `name` / `arguments`，否则拼不回完整调用。
     */
    let blocksClosed = false
    function* closeBlocks(): Generator<DshStreamChunk> {
      if (blocksClosed) return
      blocksClosed = true
      for (const state of toolBlocks.values()) {
        yield {
          type: 'block-end',
          index: state.block,
          block: { type: 'tool-call', id: state.id, name: state.name, arguments: state.args },
        }
      }
      if (textBlock >= 0) {
        yield { type: 'block-end', index: textBlock, block: { type: 'text', text: textBuf } }
      }
      if (reasoningBlock >= 0) {
        yield { type: 'block-end', index: reasoningBlock, block: { type: 'reasoning', text: reasoningBuf } }
      }
    }
    const iterator = outcome.value.events[Symbol.asyncIterator]()
    /** 超时哨兵（事件一定是对象，用唯一 symbol 不会撞）。 */
    const TIMEOUT = Symbol('usage-drain-timeout')
    /**
     * 取下一个事件；`finish` 之后受 {@link USAGE_DRAIN_MS} 约束。
     *
     * ⚠️ 超时必须**在这里**判，不能写成循环体里的一句 `if (Date.now() > drainUntil)`：
     * `for await` 卡在 `next()` 上时循环体根本不执行，那种写法对着
     * 「发完 finish 就挂住连接」的上游会**永远等下去**（用户感知就是对话不结束）。
     * 这里的 `Promise.race` 才是真正的上限。
     *
     * 返回 `undefined` 表示流已结束或等待超时 —— 两种情况后面走同一套收尾。
     */
    const nextEvent = async (): Promise<import('../core/types.js').StreamEvent | undefined> => {
      if (!finishSeen) {
        const next = await iterator.next()
        return next.done === true ? undefined : next.value
      }
      const remaining = drainUntil - Date.now()
      if (remaining <= 0) return undefined
      let timer: ReturnType<typeof setTimeout> | undefined
      const pending = iterator.next()
      // ⚠️ 超时先赢时，这个 promise 之后若失败就**没有人接**了 ——
      // Node 默认把未处理的 rejection 当致命错误（崩进程）。这里先挂一个空的
      // 处理函数兜住它；真正失败且**先赢**的情况仍会由下面的 `race` 正常抛出。
      pending.catch(() => {})
      try {
        const result = await Promise.race([
          pending,
          new Promise<typeof TIMEOUT>((resolve) => {
            timer = setTimeout(() => resolve(TIMEOUT), remaining)
          }),
        ])
        if (result === TIMEOUT) {
          // 尽力关掉上游流（`iterateSse` 的 `finally` 会释放 reader）。
          // 只发不等：它要是不肯结束，我们也不能再搭进去一次等待。
          try {
            void iterator.return?.()?.catch?.(() => {})
          } catch { /* 释放失败无所谓 */ }
          return undefined
        }
        return result.done === true ? undefined : result.value
      } finally {
        if (timer !== undefined) clearTimeout(timer)
      }
    }
    try {
      for (;;) {
        const event = await nextEvent()
        if (event === undefined) {
          // 只在「确实没等到 usage」时记一条 —— 正常收到 usage 的情况不该刷日志。
          if (finishSeen && usage === undefined) {
            log.debug(
              `finish 后没有收到 usage 帧（最多等了 ${usageDrainMs}ms）`,
              `model=${upstreamModel}（该上游可能不支持 stream_options.include_usage，token 只能留空）`,
            )
          }
          break
        }
        // 首字延迟：第一段「用户能看见的内容」到达的时刻。
        // 思维链也算 —— 它同样是用户可见的等待结束点。
        if (ttftMs === undefined && (event.type === 'text' || event.type === 'reasoning' || event.type === 'tool_call')) {
          ttftMs = Date.now() - startedAt
        }
        switch (event.type) {
          case 'text': {
            if (textBlock < 0) {
              textBlock = allocate()
              yield { type: 'block-start', index: textBlock, blockType: 'text' }
            }
            textBuf += event.text
            yield { type: 'text-delta', index: textBlock, text: event.text }
            break
          }
          case 'reasoning': {
            // 思维链单独一块，DSH 会话里显示成思考过程。
            if (reasoningBlock < 0) {
              reasoningBlock = allocate()
              yield { type: 'block-start', index: reasoningBlock, blockType: 'reasoning' }
            }
            reasoningBuf += event.text
            yield { type: 'reasoning-delta', index: reasoningBlock, text: event.text }
            break
          }
          case 'tool_call': {
            const upstreamIndex = event.index ?? 0
            let state = toolBlocks.get(upstreamIndex)
            if (state === undefined) {
              state = { block: allocate(), id: '', name: '', args: '' }
              toolBlocks.set(upstreamIndex, state)
              yield { type: 'block-start', index: state.block, blockType: 'tool-call' }
            }
            // 首帧拿真 id；之后每帧都发同一个，别让 DSH 的覆盖式赋值把它抹掉。
            if (state.id === '') state.id = event.id ?? `call_${state.block}`
            if (event.name !== undefined && event.name !== '') state.name = event.name
            state.args += event.argumentsDelta ?? ''
            yield {
              type: 'tool-call-delta',
              index: state.block,
              id: state.id,
              ...(event.name === undefined || event.name === '' ? {} : { name: event.name }),
              argumentsDelta: event.argumentsDelta ?? '',
            }
            break
          }
          case 'usage': {
            usage = event.usage
            // finish **之前**到的 usage 照旧立刻透给 DSH；
            // 之后的（Qoder 就是这种）留到循环结束后统一补发，见 `usageYielded`。
            if (!finishSeen) {
              usageYielded = true
              yield { type: 'usage', usage: event.usage }
            }
            break
          }
          case 'finish': {
            // 可能重复到达（`iterateSse` 在 `[DONE]` 与流结束时会各补一次），
            // 所以收尾动作只做一次。
            if (finishSeen) break
            finishSeen = true
            finishReason = event.reason
            /**
             * ⚠️ **收到 finish 不能马上 return**（真实缺陷，用户报「输入/输出为 —」）。
             *
             * `stream_options.include_usage` 的 usage 末帧**排在 finish 之后**：
             * 本机实测 Qoder CN `auto`（2026-10-20）的事件序列是
             * `… #16 text → #17 finish → #18 usage`，usage 比 finish **晚 17ms**。
             * 原先这里直接 `return`，于是 usage 永远读不到 ⇒ 采样里
             * `inputTokens` / `outputTokens` / `tps` 三个字段永远缺席。
             *
             * 所以这里改成「**收尾但不结束**」：先把块关掉（用户看到的内容不受影响），
             * 然后继续拉一小段，只为了等那一帧 usage。
             *
             * 等的代价通常是 **0ms** —— 上游发完 usage 紧接着就是 `[DONE]`
             * 并关闭连接，循环自然结束。`USAGE_DRAIN_MS` 只是兜底上限，
             * 防止某个上游发完 finish 却挂着连接不放，把用户的一轮对话拖住。
             */
            drainUntil = Date.now() + usageDrainMs
            // 关掉所有开着的块（工具块带上累积的 name/arguments，DSH 侧才拼得回完整调用）。
            // 用户看到的内容到这里就完整了；下面再等只是为采样收 usage。
            yield* closeBlocks()
            break
          }
          case 'error': {
            // 这里同样要带上已流出的正文 —— 报错也不能把用户已经看到的话吞掉。
            yield* closeBlocks()
            failureMessage = event.failure.message
            // 分类要一起记：只留原话的话，界面无从分辨「鉴权失效」与「触发限流」。
            // ⚠️ 这条路径的 `accountId` 已经在路由成功时赋好了 —— 流中途才报错
            // 恰恰说明**账号是选到了的**，正是用户最需要看到的那个号。
            failureKind = event.failure.kind
            settle(false)
            yield {
              type: 'finish',
              reason: {
                kind: 'error',
                failure: {
                  message: event.failure.message,
                  code: event.failure.kind.toUpperCase(),
                  ...(event.failure.status === undefined ? {} : { status: event.failure.status }),
                } satisfies DshFailure,
              },
            }
            return
          }
        }
      }
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error)
      failureMessage = message
      settle(false)
      yield {
        type: 'finish',
        reason: { kind: 'aborted', failure: { message, code: 'ABORTED' } satisfies DshFailure },
      }
      return
    }
    /**
     * 收尾并结算采样。
     *
     * ⚠️ **顺序不能反**：先走完上面的循环（把 finish 之后那帧 usage 收进来），
     * 再 `settle()`。原先是在 `case 'finish'` 里立刻 `settle()` 后 `return`，
     * 于是 usage 永远来不及进采样 —— 这正是用户看到的「输入/输出为 —」。
     *
     * `settle()` 自己在内部去重（`settled`），这里调用是安全的：
     * 无论走的是「正常收到 finish」「上游没给终止」还是「drain 超时」，
     * 都只会写一条日志。
     */
    // 上游**没给 finish** 就断了（真适配器走 `iterateSse` 时不会出现 —— 它总会补一个
    // finish；这里防的是自定义/未来适配器）：块还开着，必须补 `block-end`。
    // 漏掉它的后果与「block-end 传空串」是同一类：DSH 侧拼不回完整正文 ——
    // 用户已经看到的字会被丢掉一截。已收到 finish 的情况由 `closeBlocks` 的幂等挡掉。
    yield* closeBlocks()
    settle(true)
    // finish 之后才到的 usage：补发给 DSH（DSH 侧靠它显示 token 用量）。
    if (usage !== undefined && !usageYielded) {
      usageYielded = true
      yield { type: 'usage', usage }
    }
    // 收到过 finish 就照它报（`tool-calls` / `max-tokens` 的判定在 finishChunk 里）；
    // 没收到过（上游流直接断）则兜一个，DSH 侧才能收尾。
    yield finishChunk(finishReason)
  }

  return {
    providerInfo: info,
    async listModels(_provider: string): Promise<DshModelInfo[]> {
      const list = await models()
      return list.map((meta) => {
        const info: DshModelInfo = {
          provider: _provider,
          id: encodeModelId(meta.agentId, meta.id),
          name: renderModelLabel(meta, labelWithAgentOf()),
        }
        if (meta.description !== undefined) info.description = meta.description
        if (Array.isArray(meta.inputModalities) && meta.inputModalities.length > 0) {
          info.inputModalities = [...meta.inputModalities]
        }
        return info
      })
    },
    resolveModel: resolve,
    async prepareCall(provider, model, signal) {
      const resolved = await resolve(provider, model, signal)
      return {
        model: resolved,
        stream: (options: DshGenerateOptions) => {
          const controller = new AbortController()
          const signalOut =
            options.signal === undefined
              ? controller.signal
              : typeof AbortSignal.any === 'function'
                ? AbortSignal.any([options.signal, controller.signal])
                : options.signal
          return pump(options, signalOut)
        },
      }
    },
    stream(options: DshGenerateOptions) {
      const controller = new AbortController()
      const signal =
        options.signal === undefined
          ? controller.signal
          : typeof AbortSignal.any === 'function'
            ? AbortSignal.any([options.signal, controller.signal])
            : options.signal
      return pump(options, signal)
    },
    /**
     * 本路由的图片计价。
     *
     * ⚠️ **视觉 token 恒报 0 —— 这是产品决定，不是「没发图」**。
     * 0.3.5 起 `toOpenAiMessages()` 已经会把图片块转成 `image_url` 真的发给上游
     * （历史原因：0.3.4 及以前只拼 `text` 块，图片整块丢掉，所以当时报 0 是实情）。
     * 现在仍报 0，是「成本显示不把视觉 token 计进倍率」的口径：网关的倍率表按
     * 文本 token 计，混进视觉单价会让同一模型在不同图上的价格跳动。
     * 真要改口径，改这里一处即可 —— 但必须与倍率表一起改，否则显示与账单对不上。
     *
     * 返回 `undefined` 是允许的（宿主会退回自己的固定估算），但**不能不给
     * 这个方法**：`ctx.llm.imageRequestPricing()` 直接
     * `adapters.get(provider)?.adapter.imageRequestPricing(...)`，
     * 缺方法就是 `is not a function` —— 压缩对话崩在这里。
     */
    imageRequestPricing(_provider, _model) {
      return {
        priceImages: (images) => images.map((block) => ({ visualTokens: 0, text: imagePlaceholderText(block) })),
      }
    },
    /**
     * 这张图在**发给上游的请求里**的尺寸与字节上限。
     *
     * 宿主拿这个值去 `readImageRequest(ref, target)`：**它决定实际发出去的字节**，
     * 所以这里是全链路唯一该做压缩的地方。取上线常见的一套：
     * 长边 1568 px（视觉模型的原生输入量级，再大只是白烧 token）、单张 1 MiB
     * （base64 后约 1.33 MiB，低于主流网关的请求体上限）。
     *
     * 小图**不放大**：`scale` 只在超过长边时小于 1。
     */
    imageRequestTarget(_provider, _model, image) {
      return requestImageTarget(image)
    },
    providerRetryPolicy() {
      // 交给 DSH 自己的重试执行器：限流/上游故障值得重试；鉴权与额度错误
      // 已经在插件内部换过号了，再重试同一路由没意义。
      //
      // ⚠️ **`RISK_CONTROL` 刻意不在这个列表里**。
      //
      // 风控是按账号行为特征判定的：同一个号立刻重试只会加深「这是个异常客户端」
      // 的印象，把临时风控升级成长期封禁。而且我们在插件内部**已经换过号**了
      // （`shouldSwitchAccount('risk_control') === true`），能走到这里说明候选号
      // 都试完了 —— 再让 DSH 重试同一路由就是纯重复撞墙。
      //
      // 代价是用户看到的是一次干脆的失败，而不是「转圈重试 5 次再失败」。
      // 这正是想要的：失败信息里带着上游原话，比转圈有用。
      return {
        mode: 'normal',
        maxRetries: 2,
        retryableCodes: ['RATE_LIMIT', 'SERVER', 'NETWORK', 'UNKNOWN', 'EMPTY_RESPONSE'],
        initialDelayMs: 1000,
        maxDelayMs: 30_000,
        jitterRatio: 0.2,
      }
    },
  }
}

/**
 * 一次图片出现在**本网关发给上游的请求里**实际占的文本。
 *
 * 计价口径：视觉 token 恒报 0（产品决定，见 `imageRequestPricing()`），这里返回
 * 空串，代表「这次出现在模型请求里不额外占文本 token」。图片本身走
 * `image_url` 的 base64，不占文本位置。
 *
 * 为什么不复刻宿主的 `textOnlyImageText()`（那段 `[image omitted because…]`）：
 * 宿主只在**它自己序列化**时写那句占位；本网关的序列化器不写，写了就是给
 * token 计量凭空加几十个 token。计量要贴实际请求，不贴宿主的默认假设。
 *
 * 保留 `block` 参数是为了签名与宿主一致。
 */
function imagePlaceholderText(_block: DshImageBlock): string {
  return ''
}

/**
 * 图片长边上限（像素）。
 *
 * 取 1568：主流视觉模型的原生输入量级（长边再大只是被上游缩回去，白烧 token
 * 和上传带宽）。小图不放大 —— `scale` 只在超过长边时小于 1。
 */
const MAX_REQUEST_IMAGE_EDGE = 1568

/**
 * 单张图片字节上限：1 MiB。
 *
 * base64 编码后约 1.33 MiB，加上提示词与工具表仍在主流网关的请求体上限内；
 * 再大就容易在反代层被直接截断（而且视觉模型本来也不会用到那部分细节）。
 */
const MAX_REQUEST_IMAGE_BYTES = 1024 * 1024

/** `GenerateOptions.messages` 里有多少个图片块（只给日志用，不算字节）。 */
function countImageBlocks(options: DshGenerateOptions): number {
  let count = 0
  for (const message of options.messages) {
    if (!Array.isArray(message.content)) continue
    for (const block of message.content) {
      if ((block as { type?: unknown })?.type === 'image') count += 1
    }
  }
  return count
}

/**
 * 一张图在**发给上游的请求里**应有的尺寸与字节上限。
 *
 * 宿主拿这个值去 `readImageRequest(ref, target)` 真的会按它压缩，所以这里是
 * 全链路唯一该做尺寸决策的地方（`imageRequestTarget()` 与解析图片时共用）。
 */
export function requestImageTarget(image: DshImageRef): DshImageRequestTarget {
  const width = Number.isFinite(image.width) && image.width > 0 ? image.width : 1
  const height = Number.isFinite(image.height) && image.height > 0 ? image.height : 1
  const longEdge = Math.max(width, height)
  const scale = longEdge > MAX_REQUEST_IMAGE_EDGE ? MAX_REQUEST_IMAGE_EDGE / longEdge : 1
  const bytes = Number.isFinite(image.bytes) && image.bytes > 0 ? image.bytes : MAX_REQUEST_IMAGE_BYTES
  return {
    width: Math.max(1, Math.round(width * scale)),
    height: Math.max(1, Math.round(height * scale)),
    maxBytes: Math.min(Math.round(bytes), MAX_REQUEST_IMAGE_BYTES),
  }
}

/** 把一张图片块换成 data URI 的回调；返回 `undefined` 表示这张图发不出去（降级成文本）。 */
export type DshImageResolver = (ref: DshImageRef) => Promise<string | undefined>

/**
 * DSH 的 `GenerateOptions.messages` → OpenAI 兼容 messages。
 *
 * 图片块（`{type:'image', attachment}`）在给了 `resolveImage` 时转成
 * `{type:'image_url', image_url:{url:'data:<mime>;base64,…'}}`。
 * 以下三种情况**跳过该图**（等价于 0.3.4 及以前的行为，只发文本）：
 *
 *   1. 没给 `resolveImage`（宿主没有附件服务，或模型没声明视觉能力）；
 *   2. `offloaded: true`（DSH 已经把它换成占位文本，不该再发）；
 *   3. 解析失败（附件读不到 / 已过期）。
 *
 * 纯文本消息仍然产出**字符串** `content`：上游对字符串的兼容性最好，改成数组
 * 只会让那些不认多模态的老接口 400。
 */
export async function toOpenAiMessages(
  options: DshGenerateOptions,
  resolveImage?: DshImageResolver,
): Promise<Array<Record<string, unknown>>> {
  const out: Array<Record<string, unknown>> = []
  if (typeof options.system === 'string' && options.system !== '') {
    out.push({ role: 'system', content: options.system })
  }
  for (const message of options.messages) {
    // 已经是 OpenAI 形状的（DSH 的请求消息本来就是 provider 中立的块数组，
    // 这里做一次扁平化；能直接用的就原样透传）。
    if (typeof message.content === 'string') {
      out.push({ role: normalizeRole(message.role), content: message.content, ...carryExtra(message) })
      continue
    }
    const blocks = Array.isArray(message.content) ? (message.content as Array<Record<string, unknown>>) : []
    const parts: Array<Record<string, unknown>> = []
    let hasImage = false
    for (const block of blocks) {
      if (block?.type === 'text' && typeof block.text === 'string') {
        parts.push({ type: 'text', text: String(block.text) })
        continue
      }
      if (block?.type !== 'image' || resolveImage === undefined || block.offloaded === true) continue
      const ref = block.attachment as DshImageRef | undefined
      if (ref === undefined || typeof ref !== 'object') continue
      const url = await resolveImage(ref)
      if (url === undefined) continue
      parts.push({ type: 'image_url', image_url: { url } })
      hasImage = true
    }
    // 没有图 ⇒ 保持字符串形态（老行为）；有图 ⇒ 保序的块数组。
    const content = hasImage
      ? parts
      : parts.filter((part) => part.type === 'text').map((part) => String(part.text)).join('')
    const entry: Record<string, unknown> = { role: normalizeRole(message.role), content }
    const toolCalls = blocks.filter((block) => block?.type === 'tool-call')
    if (toolCalls.length > 0) {
      entry.tool_calls = toolCalls.map((block) => ({
        id: block.id,
        type: 'function',
        function: { name: block.name, arguments: block.arguments },
      }))
    }
    if (typeof message.toolCallId === 'string') {
      entry.tool_call_id = message.toolCallId
    }
    out.push(entry)
  }
  return out
}

/**
 * 收到上游 `finish` 之后，最多再等多久来收那一帧 usage（毫秒）。
 *
 * ## 为什么需要「等」
 *
 * `stream_options.include_usage` 的 usage 末帧**排在 finish 之后**。
 * 本机实测 Qoder CN `auto`（2026-10-20）的事件序列：
 *
 * ```
 * … #16 text「你好」 → #17 finish(stop) → #18 usage{input:15, output:54}
 * ```
 *
 * usage 比 finish 晚 **17ms**。若收到 finish 就 `return`，这一帧永远读不到，
 * 采样里 `inputTokens` / `outputTokens` / `tps` 就全空 —— 用户看到的
 * 「输入、输出、速度为 —」正是这么来的。
 *
 * ## 为什么默认上限是 250ms，而它现在可以被适配器覆盖
 *
 * 正常上游发完 usage 紧接着就 `[DONE]` 并关闭连接，循环自然结束，**一秒都不等**。
 * 这个上限只兜「发完 finish 却挂着连接不放」的上游；250ms 相对实测的 17ms
 * 有十几倍余量，又短到用户完全感觉不到。
 *
 * ## ⚠️ 但 250ms 对小浣熊**不够**（2026-10-27 实测）
 *
 * 商汤小浣熊的 usage 帧比 finish 晚 **472 … 3744ms**（8 次采样，均值 ≈ 2.4s）——
 * 因为它在网关侧要等上游把计费算完才补这一帧。用 250ms 的窗口去等，
 * 结果就是这一帧**永远收不到**，日志里输入/输出/速度三列恒为 `—`。
 *
 * 可全局调到 4s 吗？不行 —— 那会让 Qoder 这类只晚 17ms 的平台，
 * **每一轮**收尾都多挂最多 4 秒（字都出完了还在转圈）。
 *
 * 所以窗口改成**由适配器声明**（`AgentCapabilities.usageDrainMs`）：
 * 知道自己上游慢的适配器自己说，其余继续用这个 250ms 的默认值。
 */
const USAGE_DRAIN_MS = 250

/** DSH 的 role → OpenAI role（`developer` 归一到 `system`）。 */
function normalizeRole(role: string): string {
  if (role === 'developer') return 'system'
  return role
}

/**
 * 把消息上已有的额外字段带过去。
 *
 * ⚠️ DSH 的形状是 camelCase（`ToolResultMessage.toolCallId`），OpenAI 是
 * snake_case（`tool_call_id`）—— 少做这一步映射，工具结果就会丢关联 id，
 * 上游会直接 400「tool_call_id is required」（这是最容易漏的一处）。
 */
function carryExtra(message: { [key: string]: unknown }): Record<string, unknown> {
  const extra: Record<string, unknown> = {}
  for (const key of ['name', 'tool_calls', 'reasoning_content']) {
    if (message[key] !== undefined) extra[key] = message[key]
  }
  const callId = message.tool_call_id ?? message.toolCallId
  if (typeof callId === 'string' && callId !== '') extra.tool_call_id = callId
  const reasoning = message.reasoning_content ?? message.reasoningContent
  if (typeof reasoning === 'string' && reasoning !== '') extra.reasoning_content = reasoning
  return extra
}
