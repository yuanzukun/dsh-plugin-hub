/**
 * dsh-pilot host smoke test: real headless Edge end-to-end, v0.2.
 * Run: node tests/smoke.mjs
 */
import { Pilot, PilotPool, gcStaleProfiles } from '../lib/index.js'
import { existsSync } from 'node:fs'
import { mkdtemp, rm, utimes, writeFile } from 'node:fs/promises'
import { spawn } from 'node:child_process'
import { createServer } from 'node:http'
import { createServer as createNetServer } from 'node:net'
import { once } from 'node:events'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

let failed = 0
const check = (label, condition, extra = '') => {
  const ok = Boolean(condition)
  if (!ok) failed++
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}${extra ? ` — ${extra}` : ''}`)
}

const pilot = new Pilot()
let fixtureServer = null
let fixtureBase = ''
let formServer = null
let formBase = ''
let uploadFixture = null
try {
  // Text and element assertions run against a local fixture. A public page's
  // wording, language and availability are not ours to depend on: example.com
  // replaced its copy in October 2026 and every text assertion broke at once.
  fixtureServer = createServer((_req, res) => {
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    res.end('<!doctype html><title>Pilot fixture</title><h1>Pilot fixture</h1><p id="body-text">pilot fixture body text</p><a href="/second">second page</a>')
  })
  fixtureServer.listen(0, '127.0.0.1')
  await once(fixtureServer, 'listening')
  fixtureBase = `http://127.0.0.1:${fixtureServer.address().port}`

  const fixtureSnap = await pilot.navigate(`${fixtureBase}/`)
  check('navigate: status ready', pilot.status === 'ready')
  check('navigate: url', fixtureSnap.url === `${fixtureBase}/`, fixtureSnap.url)
  check('navigate: title', fixtureSnap.title === 'Pilot fixture', fixtureSnap.title)
  check('navigate: has body text', fixtureSnap.text.includes('pilot fixture body text'))
  check('navigate: numbered elements', Array.isArray(fixtureSnap.elements) && fixtureSnap.elements.length > 0, `${fixtureSnap.elements.length} elements`)
  check('navigate: first element ref is 1', fixtureSnap.elements[0].ref === 1)
  check('snapshot: no baseline on first snapshot', fixtureSnap.changed === null)

  const waitForText = await pilot.waitFor({ text: 'pilot fixture body text', timeoutMs: 2000 })
  check('waitFor: matches visible text', waitForText.ok === true && waitForText.textMatched === true, JSON.stringify(waitForText))

  const timedOut = await pilot.waitFor({ text: 'this text is not on the fixture page', timeoutMs: 100 })
  check('waitFor: reports a timeout', timedOut.ok === false && /timed out/.test(timedOut.error), JSON.stringify(timedOut))

  // Real-site navigation semantics (click, back, reload, selector matching) still
  // run against a public page; only its wording is off limits.
  const snapshot = await pilot.navigate('https://example.com')
  check('navigate: external page loads', pilot.status === 'ready' && /example\.com/.test(snapshot.url), snapshot.url)

  const learnMore = snapshot.elements.find(el => el.href.includes('iana.org'))
  check('elements: href captured', learnMore !== undefined)

  const clicked = await pilot.click(learnMore.ref)
  check('click by ref: ok', clicked.ok === true && clicked.ref === learnMore.ref, JSON.stringify(clicked).slice(0, 120))
  check('click: waits for navigation', /iana\.org/.test(clicked.url), clicked.url)
  check('click: title settled after load', typeof clicked.title === 'string' && clicked.title.length > 0, clicked.title)

  const snapAfter = await pilot.snapshot()
  check('snapshot: urlChanged after click', snapAfter.changed !== null && snapAfter.changed.urlChanged === true, JSON.stringify(snapAfter.changed).slice(0, 160))

  const wentBack = await pilot.back()
  check('back: returns to previous page', /example\.com/.test(wentBack.url), wentBack.url)

  const reloaded = await pilot.reload()
  check('reload: keeps url', reloaded.url === wentBack.url, reloaded.url)

  const waited = await pilot.wait(150)
  check('wait: ok', waited.ok === true && waited.waited === 150, JSON.stringify(waited))

  const asserted = await pilot.assert({ selector: 'a[href*="iana.org"]', urlIncludes: 'example.com' })
  check('assert: matches selector and url', asserted.ok === true && asserted.selectorMatched && asserted.urlMatched, JSON.stringify(asserted))


  // A real local form exercises label-driven fill and CDP file upload end-to-end.
  formServer = createServer((_req, res) => {
    if (_req.url === '/download') {
      res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8' })
      res.end('pilot download fixture\n'.repeat(40))
      return
    }
    res.writeHead(200, { 'content-type': 'text/html; charset=utf-8' })
    res.end(`<!doctype html><title>Pilot form</title>
      <label for="email">Email address</label><input id="email" type="email">
      <label>Display name <input name="display-name"></label>
      <label for="role">Role</label><select id="role"><option value="member">Member</option><option value="admin">Admin</option></select>
      <label for="resume">Resume</label><input id="resume" name="resume" type="file">
      <script>window.__uploadEvents = 0; document.querySelector('#resume').addEventListener('change', () => window.__uploadEvents++)</script>`)
  })
  formServer.listen(0, '127.0.0.1')
  await once(formServer, 'listening')
  const formPort = formServer.address().port
  formBase = `http://127.0.0.1:${formPort}`
  const form = await pilot.navigate(`${formBase}/form`)
  check('form: local page loaded', form.title === 'Pilot form' && form.url.includes(String(formPort)), form.url)

  const filled = await pilot.fill([
    { label: 'Email address', value: 'agent@example.com' },
    { label: 'Display name', value: 'Harness Agent' },
    { label: 'Role', value: 'Admin' },
  ])
  check('fill: labels and select values', filled.ok === true && filled.filled.length === 3, JSON.stringify(filled))
  const formValues = await pilot.evalJs(`({ email: document.querySelector('#email').value, name: document.querySelector('[name="display-name"]').value, role: document.querySelector('#role').value })`)
  check('fill: values reached DOM', formValues.ok && formValues.value.email === 'agent@example.com' && formValues.value.name === 'Harness Agent' && formValues.value.role === 'admin', JSON.stringify(formValues))
  const unmatched = await pilot.fill([{ label: 'No such field', value: 'x' }])
  check('fill: unmatched label is explicit', unmatched.ok === false && unmatched.failed.length === 1, JSON.stringify(unmatched))

  uploadFixture = join(tmpdir(), `dsh-pilot-upload-${process.pid}.txt`)
  await writeFile(uploadFixture, 'pilot upload fixture')
  const formSnapshot = await pilot.snapshot()
  const fileInput = formSnapshot.elements.find(element => element.type === 'file')
  check('upload: file input has a snapshot ref', fileInput?.ref > 0, JSON.stringify(fileInput))
  const uploaded = await pilot.upload(fileInput.ref, [uploadFixture])
  check('upload: assigns the selected file', uploaded.ok === true && uploaded.count === 1 && uploaded.files[0] === `dsh-pilot-upload-${process.pid}.txt`, JSON.stringify(uploaded))
  const uploadEvents = await pilot.evalJs('window.__uploadEvents')
  check('upload: dispatches change event', uploadEvents.ok && uploadEvents.value >= 1, JSON.stringify(uploadEvents))

  // stale ref after navigation
  const stale = await pilot.click(999)
  check('click: stale ref fails gracefully', stale.ok === false && /stale|unknown/.test(stale.error), stale.error)

  const evaluated = await pilot.evalJs('1 + 1')
  check('eval: value', evaluated.ok && evaluated.value === 2, JSON.stringify(evaluated))

  const pressed = await pilot.press('Escape')
  check('press: ok', pressed.ok === true)

  const state1 = pilot.state()
  check('state: log populated', state1.log.length >= 4, `${state1.log.length} entries`)

  // screenshot into a nested, non-existent directory — mkdir -p regression
  const { saveScreenshot } = await import('../lib/index.js')
  const nested = await saveScreenshot(pilot, `${tmpdir()}/dsh-pilot-nested/a/b/shot.png`)
  check('screenshot: creates parent dirs', nested.ok === true && nested.bytes > 1000, nested.path)

  // download through the page's own fetch (session cookies apply)
  const dl = await pilot.download(`${formBase}/download`, `${tmpdir()}/dsh-pilot-dl-test.txt`)
  check('download: saves file with bytes', dl.ok === true && dl.bytes > 500, JSON.stringify(dl))
} catch (error) {
  failed++
  console.error('FATAL', error)
} finally {
  await pilot.dispose()
  if (fixtureServer !== null) await new Promise(resolve => fixtureServer.close(resolve))
  if (formServer !== null) await new Promise(resolve => formServer.close(resolve))
  if (uploadFixture !== null) await rm(uploadFixture, { force: true })
}

// ---- pool: per-session isolation ----
const pool = new PilotPool()
try {
  const a = pool.for('session-a')
  const b = pool.for('session-b')
  check('pool: distinct pilots per session', a !== b)
  await a.navigate('https://example.com')
  await b.navigate('https://en.wikipedia.org/wiki/DeepSeek')
  check('pool: a independent', a.url.includes('example.com'), a.url)
  check('pool: b independent', b.url.includes('DeepSeek'), b.url)
  check('pool: distinct ports', a.port !== b.port, `${a.port} vs ${b.port}`)
  check('pool: primary tracks last use', pool.panelPilot() === b)
  check('pool: can pin cockpit to a session', pool.selectPanelSession('session-a') === true && pool.panelPilot() === a)
  pool.for('session-b')
  check('pool: pin survives newer activity', pool.panelPilot() === a)
  check('pool: latest restores automatic following', pool.selectPanelSession('latest') === true && pool.panelPilot() === b)
  check('pool: rejects unknown cockpit session', pool.selectPanelSession('missing-session') === false && pool.panelPilot() === b)
  await a.stop()
  check('pool: stopping a leaves b ready', b.status === 'ready')
} catch (error) {
  failed++
  console.error('FATAL pool', error)
} finally {
  await pool.disposeAll()
}

// ---- profile lifecycle: stop, unexpected exit, start-up sweep ----
const waitForGone = async (dir, timeoutMs) => {
  const deadline = Date.now() + timeoutMs
  while (Date.now() < deadline && existsSync(dir)) await new Promise(resolve => setTimeout(resolve, 200))
  return !existsSync(dir)
}

const killTree = async pilot => {
  const pid = pilot.child.pid
  if (process.platform === 'win32') {
    const killer = spawn('taskkill', ['/pid', String(pid), '/T', '/F'], { stdio: 'ignore', windowsHide: true })
    await once(killer, 'exit')
    return
  }
  process.kill(pid, 'SIGKILL')
}

{
  const solo = new Pilot()
  try {
    await solo.navigate('https://example.com')
    const dir = solo.profileDir
    check('profile: created under the temp dir', typeof dir === 'string' && dir.includes('dsh-pilot-'), String(dir))
    await solo.dispose()
    check('profile: removed on stop', dir !== null && !existsSync(dir), String(dir))
    check('profile: path dropped only after confirmed removal', solo.profileDir === null)
  } catch (error) {
    failed++
    console.error('FATAL profile stop', error)
  } finally {
    await solo.dispose()
  }
}

{
  const crashed = new Pilot()
  try {
    await crashed.navigate('https://example.com')
    const dir = crashed.profileDir
    await killTree(crashed)
    check('profile: reclaimed after an unexpected browser exit', await waitForGone(dir, 10000), String(dir))
  } catch (error) {
    failed++
    console.error('FATAL profile crash', error)
  } finally {
    await crashed.dispose()
  }
}

{
  const blockers = [createNetServer(), createNetServer()]
  try {
    let port = 9340
    for (const blocker of blockers) {
      blocker.listen(port++, '127.0.0.1')
      await once(blocker, 'listening')
    }
    const picked = await new Pilot().pickPort(9340)
    check('port: occupied debug ports are skipped', picked >= 9342, `${picked} with 9340-9341 blocked`)
  } catch (error) {
    failed++
    console.error('FATAL port pick', error)
  } finally {
    for (const blocker of blockers) blocker.close()
  }
}

{
  try {
    const stale = await mkdtemp(join(tmpdir(), 'dsh-pilot-'))
    await writeFile(join(stale, 'Default'), 'chromium profile leftover')
    const old = new Date(Date.now() - 2 * 60 * 60 * 1000)
    await utimes(stale, old, old)
    await gcStaleProfiles()
    check('sweep: reclaims a stale profile', !existsSync(stale), String(stale))

    const fresh = await mkdtemp(join(tmpdir(), 'dsh-pilot-'))
    await gcStaleProfiles()
    check('sweep: leaves a fresh profile alone', existsSync(fresh), String(fresh))
    const fixture = await mkdtemp(join(tmpdir(), 'dsh-pilot-nested-'))
    await utimes(fixture, old, old)
    await gcStaleProfiles()
    check('sweep: ignores non-profile fixtures', existsSync(fixture), String(fixture))
    await rm(fresh, { recursive: true, force: true })
    await rm(fixture, { recursive: true, force: true })
  } catch (error) {
    failed++
    console.error('FATAL sweep', error)
  }
}

// ---- window mode: headless by default, headed on request ----
{
  const restore = process.env.DSH_PILOT_HEADED
  try {
    const cases = [
      [undefined, undefined, false, 'default is headless'],
      [{ headed: true }, undefined, true, 'explicit headed'],
      [{ headed: false }, '1', false, 'explicit headless beats the env var'],
      [{}, '1', true, 'env var turns headed on'],
      [{}, 'true', true, 'env var accepts true'],
      [{}, '  TRUE  ', true, 'env var is trimmed and case-insensitive'],
      [{}, '0', false, 'env var accepts 0'],
      [{}, 'false', false, 'env var accepts false'],
      [{}, '', false, 'empty env var stays headless'],
    ]
    for (const [options, env, expected, label] of cases) {
      if (env === undefined) delete process.env.DSH_PILOT_HEADED
      else process.env.DSH_PILOT_HEADED = env
      const pilot = new Pilot(options)
      check(`window mode: ${label}`, pilot.headed === expected, `headed=${pilot.headed}`)
    }
    const sized = new Pilot({ headed: true, windowWidth: 1280, windowHeight: 720 })
    check('window mode: explicit size is kept', sized.windowWidth === 1280 && sized.windowHeight === 720)
    const pooled = new PilotPool({ headed: true })
    check('window mode: pool forwards pilot options', pooled.for('headed-session').headed === true)
  } catch (error) {
    failed++
    console.error('FATAL window mode', error)
  } finally {
    if (restore === undefined) delete process.env.DSH_PILOT_HEADED
    else process.env.DSH_PILOT_HEADED = restore
  }
}

console.log(`\n${failed === 0 ? 'ALL PASS' : `${failed} FAILURES`}`)
process.exit(failed === 0 ? 0 : 1)
