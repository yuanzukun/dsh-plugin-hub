/**
 * `doctor --json` 的档位分岔字段。
 *
 * `effd45c` 承诺 `deviceIdentity.tierSent` / `deviceIdentity.fallbackToVirtual`
 * 「只在分岔时出现」，但首版只把它们接进了人类可读行——`--json` 的组装处漏了
 * 这两个字段的展开，消费者永远读不到。本文件就是在那条承诺上钉的钉子：跑真实的
 * `run(['doctor','--json'])`，解析 stdout，两种设置各验一次。
 *
 * 环境由 vitest 的 isolated env 保证：`DSH_HOME` 指向临时目录（设置文件写在那里）、
 * `WORKBUDDY_TURING_SDK_DIR` 指向不存在的目录（probe 立刻答 `missing`，不起子进程、
 * 不发网络请求），所以「真实值档 + 断 token」在本测试里是确定性的。
 */
import { mkdtemp, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it } from 'vitest'
import { run } from '../src/bin.ts'
import { DEVICE_PROFILE_VERSION } from '../src/device-profile.ts'

const homes: string[] = []

afterEach(() => {
  homes.length = 0
})

/**
 * 在一份**全新的** `$DSH_HOME` 下写设备设置。
 *
 * 每个用例换一个目录不是洁癖：`readDeviceSettings` 有 5 秒读缓存（按路径键），
 * 同一个 home 里连写三次会读到上一用例的 `mode`——这正是本文件第一版失败的原因。
 */
async function writeDeviceSettings(mode: 'virtual' | 'real', sdkFallbackToVirtual: boolean): Promise<void> {
  const home = await mkdtemp(join(tmpdir(), 'doctor-device-'))
  homes.push(home)
  process.env['DSH_HOME'] = home
  await writeFile(
    join(home, '.workbuddy-device-profiles.json'),
    `${JSON.stringify({ version: DEVICE_PROFILE_VERSION, mode, accounts: {}, sdkFallbackToVirtual }, null, 2)}\n`,
    'utf8',
  )
}

/** 跑一次真实的 `doctor --json` 并解析它的 stdout。 */
async function doctorJson(): Promise<Record<string, unknown>> {
  const chunks: string[] = []
  const original = process.stdout.write.bind(process.stdout)
  process.stdout.write = ((chunk: unknown) => {
    if (typeof chunk === 'string') chunks.push(chunk)
    return true
  }) as typeof process.stdout.write
  try {
    const exit = await run(['doctor', '--json'])
    // doctor 的退出码是 `anySignedIn && desktopPresent`：隔离环境没有账号，1 是
    // 正常答案（报告在返回前就已打印完毕），所以这里只要求它是这两者之一。
    expect([0, 1]).toContain(exit)
  } finally {
    process.stdout.write = original
  }
  const lines = chunks.join('').split('\n').filter(line => line.trim().startsWith('{'))
  expect(lines.length).toBeGreaterThan(0)
  return JSON.parse(lines[0] as string) as Record<string, unknown>
}

describe('doctor --json 的档位分岔（schemaVersion 10 的承诺）', () => {
  it('real 档 + 断 token + 开关开：tier 保留 real，tierSent 降成 virtual', async () => {
    await writeDeviceSettings('real', true)
    const report = await doctorJson()
    const device = report['deviceIdentity'] as Record<string, unknown>
    expect(device['tier']).toBe('real')
    // 这三条就是"报告与出站字节一致"的形状：请求的是 real、线上发的是 virtual、
    // 且报告明说这是退回而不是用户的选择。
    expect(device['tierSent']).toBe('virtual')
    expect(device['fallbackToVirtual']).toBe(true)
  })

  it('开关关：不退回，也就没有分岔字段', async () => {
    await writeDeviceSettings('real', false)
    const report = await doctorJson()
    const device = report['deviceIdentity'] as Record<string, unknown>
    expect(device['tier']).toBe('real')
    expect(device['tierSent']).toBeUndefined()
    expect(device['fallbackToVirtual']).toBeUndefined()
    // 关掉退回的真实值档取不到 token：一个设备头都不发（P3 原始语义）。
    expect(device['onWire']).toEqual([])
  })

  it('virtual 档：常态无分岔，两个字段都不出现', async () => {
    await writeDeviceSettings('virtual', true)
    const report = await doctorJson()
    const device = report['deviceIdentity'] as Record<string, unknown>
    expect(device['tier']).toBe('virtual')
    expect(device['tierSent']).toBeUndefined()
    expect(device['fallbackToVirtual']).toBeUndefined()
  })
})
