// DeepSeek Harness 启动器外壳（主窗口）：
// 1. 启动流程：检测安装 → 自动安装（动画+日志）→ 成功提示 → 启动并跳转到本地 Web 界面；
// 2. 标题栏：三键、前进/后退、文件/窗口/关于/帮助菜单（DSH 就绪后显示，iframe 承载 DSH）；
// 3. 主题跟随：DSH 主题中继（--tb-* 变量）与 Windows 系统主题兜底。
// 通过 withGlobalTauri 注入的 window.__TAURI__ 调用后端命令。
//
// 模块级结构（2026-09 阶段一拆分，见优化报告 v2）：
// - setupWindowButtons / setupNavButtons / setupMenus / setupMaxGlyph（原 setupTitlebar 拆分）
// - setupAbout / openAbout：页内「关于」overlay（三版本号 + 检查更新，不新增 webview）
// - postToFrame：向 iframe 发送 postMessage 的唯一出口（origin 缓存于 showFrame）
// - setupThemeFollow：主题中继 + 导航状态 + 系统主题转发 + matchMedia 兜底
/* global window, document */
(function () {
  "use strict";

  const { invoke } = window.__TAURI__.core;
  const { listen } = window.__TAURI__.event;

  const phases = [
    "checking",
    "installing",
    "success",
    "launching",
    "linking",
    "error",
  ];

  function show(phase) {
    for (const p of phases) {
      const el = document.getElementById(`phase-${p}`);
      if (el) el.classList.toggle("hidden", p !== phase);
    }
  }

  function setText(id, text) {
    const el = document.getElementById(id);
    if (el) el.textContent = text;
  }

  function formatError(e) {
    if (typeof e === "string") return e;
    if (e instanceof Error) return e.message;
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  }

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  let unlisten = null;

  /* ---------- 标题栏与 iframe 外壳 ---------- */

  let frameUrl = "";
  /** iframe 页面的 origin（showFrame 时解析并缓存，供 postToFrame 定向投递）。 */
  let frameOrigin = "";

  /** DSH 就绪：隐藏启动卡片，显示标题栏并用 iframe 承载（不再整页跳转）。 */
  function showFrame(url) {
    frameUrl = url;
    try {
      frameOrigin = new URL(url).origin;
    } catch {
      frameOrigin = "";
    }
    document.getElementById("app")?.classList.add("hidden");
    document.getElementById("titlebar")?.classList.remove("hidden");
    const frame = document.getElementById("dsh-frame");
    if (frame) {
      frame.src = url;
      frame.classList.remove("hidden");
    }
  }

  /**
   * 接管外部启动的新版实例时的鉴权提示：
   * Rust 侧探测到 401 但拿不到对方进程的 token，页面能否渲染取决于 WebView
   * 是否已持有签名 cookie。提示条在插件握手成功（页面正常加载）后自动隐藏。
   */
  let authHintDismissed = false;

  function showAuthHint() {
    if (authHintDismissed) return;
    document.getElementById("auth-hint")?.classList.remove("hidden");
  }

  function hideAuthHint() {
    document.getElementById("auth-hint")?.classList.add("hidden");
  }

  function dismissAuthHint() {
    authHintDismissed = true;
    hideAuthHint();
  }

  /** 「关闭并重启」是否处于武装状态（首击后 4 秒内再击才执行，防误触）。 */
  let restartArmed = false;

  /**
   * 提示条上的「关闭并重启」：两步点击确认后，终止外部实例并由启动器
   * 重新拉起托管实例（restart_dsh_external）。重启成功后重新导航 iframe，
   * 新实例的 token URL 会完成握手；失败则回到出错页（可点重试）。
   */
  async function restartExternalInstance() {
    const btn = document.getElementById("auth-hint-restart");
    if (!btn || btn.disabled) return;
    if (!restartArmed) {
      restartArmed = true;
      btn.textContent = "再次点击确认重启";
      setTimeout(() => {
        restartArmed = false;
        btn.textContent = "关闭并重启";
      }, 4000);
      return;
    }
    restartArmed = false;
    btn.disabled = true;
    btn.textContent = "正在重启…";
    try {
      const info = await invoke("restart_dsh_external");
      hideAuthHint();
      // 新实例由本启动器托管（owned=true），直接承载带 token 的握手 URL
      showFrame(info.url);
      btn.disabled = false;
      btn.textContent = "关闭并重启";
    } catch (e) {
      btn.disabled = false;
      btn.textContent = "关闭并重启";
      // 出错页在启动卡片内：接管态下 #app 已被隐藏，需恢复
      document.getElementById("app")?.classList.remove("hidden");
      document.getElementById("titlebar")?.classList.add("hidden");
      showError(`操作失败：${formatError(e)}`);
    }
  }

  /* ---------- 外壳 ↔ 插件 postMessage 协议 ---------- */
  // 消息统一信封 { v, type, payload }。为兼容旧版对端（旧插件配新 exe，或
  // 反之），发送时同时保留旧字段、解析时信封优先并回退旧字段；下个大版本再
  // 移除旧字段。字段与超时清单见项目 docs/architecture.md。
  const MSG_VERSION = 1;
  const MSG = {
    NAV_COMMAND: "navCommand", // 外壳 → 插件：dir = back | forward | ping
    SYSTEM_THEME: "systemTheme", // 外壳 → 插件：scheme = light | dark
    NAV_STATUS: "navStatus", // 插件 → 外壳：back / forward 可用性
    THEME_SYNC: "themeSync", // 插件 → 外壳：scheme + 六色 token
  };

  /** 读取信封载荷；版本或类型不匹配时返回 null（调用方回退旧字段）。 */
  function readEnvelope(data, type) {
    if (!data || data.v !== MSG_VERSION || data.type !== type) return null;
    return data.payload && typeof data.payload === "object" ? data.payload : null;
  }

  /** 发送导航命令（back / forward / ping）：旧字段 + 信封双发。 */
  function sendNavCommand(dir) {
    postToFrame({ __tbNav: dir, v: MSG_VERSION, type: MSG.NAV_COMMAND, payload: { dir } });
  }

  /**
   * 向 iframe 发送 postMessage（外壳 → 插件 的唯一出口）。
   * 载荷字段与 lib/client.js 的 MSG 常量一一对应（协议见 docs/architecture.md）。
   */
  function postToFrame(payload) {
    const frame = document.getElementById("dsh-frame");
    if (!frame || !frameUrl || !frameOrigin || !frame.contentWindow) return;
    try {
      frame.contentWindow.postMessage(payload, frameOrigin);
    } catch {
      /* iframe 未就绪或 origin 解析失败时忽略 */
    }
  }

  /** 标题栏三键：最小化 / 最大化还原 / 关闭（关闭被 Rust 拦截为隐藏到托盘）。 */
  function setupWindowButtons(appWindow) {
    document.getElementById("btn-min")?.addEventListener("click", () => {
      void appWindow.minimize();
    });
    document.getElementById("btn-max")?.addEventListener("click", () => {
      void appWindow.toggleMaximize();
    });
    document.getElementById("btn-close")?.addEventListener("click", () => {
      void appWindow.close();
    });
  }

  /**
   * 前进 / 后退（插件协作通道）：
   * DSH 在跨源 iframe 里，外壳无法直接操作它的历史；postMessage 是唯一合法
   * 的跨源操作，由插件在 DSH 页面内同源执行（应用层会话导航栈，见 client.js）。
   */
  function setupNavButtons() {
    document.getElementById("tb-back")?.addEventListener("click", () => sendNavCommand("back"));
    document.getElementById("tb-forward")?.addEventListener("click", () => sendNavCommand("forward"));
  }

  /** 标题栏菜单（文件 / 窗口 / 帮助）：面板与条目都由数组驱动，新增菜单 = 加一条数据。 */
  function setupMenus() {
    // 面板锚点：数组驱动互斥——任一时刻至多一个面板展开
    const MENUS = [
      { btn: "menu-btn", panel: "menu-panel" },
      { btn: "window-btn", panel: "window-panel" },
      { btn: "about-btn", panel: "about-panel" },
      { btn: "help-btn", panel: "help-panel" },
    ].map(({ btn, panel }) => ({
      btn: document.getElementById(btn),
      panel: document.getElementById(panel),
    }));

    /** 外链统一入口：URL 表唯一维护在 Rust 侧（windows.rs::EXTERNAL_LINKS），前端只传 key。 */
    const openInBrowser = (key) =>
      invoke("open_in_browser", { key }).catch((e) =>
        console.error("浏览器打开失败", e),
      );

    // 条目表：id → 动作。keepOpen（退出）保持「不收起菜单」的原行为。
    // 新增外链须在此加一条（id 形如 help-<key>）并在 Rust 表里加同名条目。
    const MENU_ITEMS = [
      {
        id: "menu-settings",
        run: () =>
          invoke("open_settings_window").catch((e) =>
            console.error("打开设置失败", e),
          ),
      },
      {
        id: "menu-reload",
        run: () => {
          // iframe 跨源无法直接 contentWindow.location.reload()，重设 src 重载
          const frame = document.getElementById("dsh-frame");
          if (frame && frameUrl) frame.src = frameUrl;
        },
      },
      // 「在浏览器中打开」本地 DSH：URL 由后端按 key 解析（新版地址含进程 token）
      { id: "menu-browser", run: () => openInBrowser("dsl") },
      {
        id: "menu-quit",
        keepOpen: true,
        run: () =>
          invoke("quit_app").catch((e) => console.error("退出失败", e)),
      },
      // 关闭窗口：隐藏主窗与设置窗（Rust hide_all_windows），托盘与 Harness 子进程不受影响
      {
        id: "window-close",
        run: () =>
          invoke("hide_all_windows").catch((e) =>
            console.error("关闭窗口失败", e),
          ),
      },
      // 「关于」菜单：关于 Launcher（三版本号）/ 检查更新（npm 两查 + 出路三件套）
      { id: "about-info", run: () => openAbout(false) },
      { id: "about-update", run: () => openAbout(true) },
      { id: "help-website", run: () => openInBrowser("website") },
      { id: "help-docs", run: () => openInBrowser("docs") },
    ];

    function closeMenus() {
      for (const { btn, panel } of MENUS) {
        panel?.classList.add("hidden");
        btn?.classList.remove("open");
      }
    }

    function togglePanel(btn, panel) {
      const isOpen = !panel?.classList.contains("hidden");
      closeMenus();
      if (!isOpen) {
        panel?.classList.remove("hidden");
        btn?.classList.add("open");
      }
    }

    for (const { btn, panel } of MENUS) {
      btn?.addEventListener("click", () => togglePanel(btn, panel));
    }

    // 点击标题栏其他区域收起；切到 iframe（父窗口失焦）时也收起。
    // 命中某个菜单按钮时，只有「其它面板正展开」才先全部收起——否则会把
    // 点击自身按钮的收起动作变成重新展开（togglePanel 内部已含 closeMenus）。
    document.addEventListener("mousedown", (e) => {
      const inMenu = MENUS.some(
        ({ btn, panel }) =>
          (panel && panel.contains(e.target)) || e.target === btn,
      );
      if (!inMenu) {
        closeMenus();
        return;
      }
      const hit = MENUS.find(({ btn }) => e.target === btn);
      const othersOpen = MENUS.some(
        (m) => m !== hit && !m.panel?.classList.contains("hidden"),
      );
      if (hit && othersOpen) closeMenus();
    });
    window.addEventListener("blur", closeMenus);
    // Esc 收起（焦点在外壳页时生效；焦点进入 iframe 由上面的 blur 兜底）
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeMenus();
    });

    for (const { id, run, keepOpen } of MENU_ITEMS) {
      document.getElementById(id)?.addEventListener("click", () => {
        if (!keepOpen) closeMenus();
        run();
      });
    }
  }

  /** 最大化图标随窗口状态切换。 */
  function setupMaxGlyph(appWindow) {
    async function refreshMaxGlyph() {
      try {
        const maximized = await appWindow.isMaximized();
        document
          .querySelector(".ic-max")
          ?.classList.toggle("hidden", maximized);
        document
          .querySelector(".ic-restore")
          ?.classList.toggle("hidden", !maximized);
      } catch {
        /* 权限或时序问题不影响主流程 */
      }
    }
    if (window.__TAURI__.event?.listen) {
      void window.__TAURI__.event
        .listen("tauri://resize", () => void refreshMaxGlyph())
        .catch(() => {});
    }
    void refreshMaxGlyph();
  }

  /* ---------- 「关于」弹窗（三版本号 + 检查更新） ---------- */
  // 页内 overlay，不新增 webview（新窗口须遵守启动早期预建约束，见 windows.rs）。
  // 「检查更新」只在用户点击时发起，不做后台轮询（v1.2 再谈）。

  /** 最近一次检查更新的结果（「复制升级命令」取文本用）。 */
  let aboutReport = null;

  /** DSH 一键升级的两步确认开关（点一次进入「确认」态，再点才执行）。 */
  let confirmArmed = false;

  /** 升级进度日志（只保留最后几行，避免刷屏）。 */
  let upgradeLogLines = [];

  /** 重置更新区到初始态：每次打开弹窗都重新检查，不展示上一次的陈旧结果。 */
  function resetUpdateArea() {
    aboutReport = null;
    confirmArmed = false;
    upgradeLogLines = [];
    const upgradeBtn = document.getElementById("about-upgrade-dsh");
    if (upgradeBtn) upgradeBtn.textContent = "升级 DSH";
    const log = document.getElementById("about-upgrade-log");
    if (log) {
      log.textContent = "";
      log.classList.add("hidden");
    }
    setText("about-check-status", "");
    setText("about-upgrade-status", "");
    document.getElementById("about-update-result")?.classList.add("hidden");
    document.getElementById("about-dsh-upgrade")?.classList.add("hidden");
    document.getElementById("about-update-drift")?.classList.add("hidden");
    document.getElementById("about-update-actions")?.classList.add("hidden");
  }

  /** 打开「关于」弹窗；autoCheck（菜单「检查更新」）为真时立即开始检查。 */
  function openAbout(autoCheck) {
    const overlay = document.getElementById("about-overlay");
    if (!overlay) return;
    resetUpdateArea();
    overlay.classList.remove("hidden");
    void loadVersions();
    if (autoCheck) void runUpdateCheck();
  }

  function closeAbout() {
    document.getElementById("about-overlay")?.classList.add("hidden");
  }

  /** 三版本号：三项各自探测、各自容错（未安装 / 未知只影响自己那一行）。 */
  async function loadVersions() {
    try {
      const v = await invoke("get_versions");
      setText("about-launcher", v.launcher ? `v${v.launcher}` : "未知");
      setText("about-dsh", v.dsh ? `v${v.dsh}` : "未安装");
      setText("about-node", v.node || "未知");
    } catch (e) {
      console.error("读取版本失败", e);
      setText("about-launcher", "未知");
      setText("about-dsh", "未知");
      setText("about-node", "未知");
    }
  }

  /**
   * 单项是否「有更新」：Rust 侧已做语义化比较（预发布低于同号正式版，见 info.rs 的
   * has_update），拿到结论就用它；结论缺失时退回按字符串判断，与旧版行为一致。
   * current / latest 缺一即 false——「本地版本未知」不当成有更新。
   */
  function isOutdated(item) {
    if (!item?.latest || !item.current) return false;
    if (item.has_update === true) return true;
    if (item.has_update === false) return false;
    return item.latest !== item.current;
  }

  /** 单项对比文案：本地版本一定有，远端可能是「未能获取」（离线 / 超时 / npm 缺失）。 */
  function describeUpdate(label, item) {
    const current = item?.current ? `v${item.current}` : "未知";
    if (!item?.latest) return `${label}：${current}（未能获取最新版本）`;
    // current 缺失（如 DSH 未安装）时判不出新旧，沿用旧版的「新版本」文案
    if (!item.current) return `${label}：新版本 v${item.latest}（当前 ${current}）`;
    if (!isOutdated(item)) return `${label}：已是最新（${current}）`;
    return `${label}：新版本 v${item.latest}（当前 ${current}）`;
  }

  function renderUpdateReport(report) {
    setText("about-update-launcher", describeUpdate("启动器 + 插件", report.launcher));
    setText("about-update-dsh", describeUpdate("DSH", report.dsh));

    const drift = document.getElementById("about-update-drift");
    if (drift) {
      if (report.drift) {
        drift.textContent = report.drift;
        drift.classList.remove("hidden");
      } else {
        drift.classList.add("hidden");
      }
    }

    // DSH 一键升级入口只在 DSH 自己有新版时出现（升的是 DSH 本体，与启动器那条线独立）
    const dshUpgrade = document.getElementById("about-dsh-upgrade");
    if (dshUpgrade) {
      if (isOutdated(report.dsh)) dshUpgrade.classList.remove("hidden");
      else dshUpgrade.classList.add("hidden");
    }

    // 出路三件套只在真有新版本时出现：当前 exe 完整路径 + 打开下载页 + 复制升级命令
    const hasUpdate = [report.launcher, report.dsh].some((item) => isOutdated(item));
    const actions = document.getElementById("about-update-actions");
    if (actions) {
      if (hasUpdate) {
        setText("about-exe-path", `当前运行的 exe：${report.exe_path || "未知"}`);
        actions.classList.remove("hidden");
      } else {
        actions.classList.add("hidden");
      }
    }

    const status = document.getElementById("about-check-status");
    if (status) {
      status.textContent = report.error
        ? `检查失败：${report.error}`
        : hasUpdate
          ? ""
          : "已是最新";
    }
    document.getElementById("about-update-result")?.classList.remove("hidden");
  }

  /** 「检查更新」：按钮禁用 + 状态文案；超时由 Rust 侧兜底（8 秒），不阻塞标题栏。 */
  async function runUpdateCheck() {
    const btn = document.getElementById("about-check");
    const status = document.getElementById("about-check-status");
    if (btn) btn.disabled = true;
    if (status) status.textContent = "检查中…";
    document.getElementById("about-update-result")?.classList.add("hidden");
    try {
      const report = await invoke("check_updates");
      aboutReport = report;
      renderUpdateReport(report);
    } catch (e) {
      if (status) status.textContent = `检查失败：${formatError(e)}`;
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  /** 复制升级命令：优先 Clipboard API，失败回退到临时 textarea + execCommand。 */
  async function copyUpgradeCommand() {
    const text = aboutReport?.upgrade_command || "";
    if (!text) return;
    const btn = document.getElementById("about-copy");
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.className = "about-clip";
      ta.value = text;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
      } catch {
        /* 自动复制不可用：命令原文已在弹窗内，用户可手动选取 */
      }
      ta.remove();
    }
    if (btn) {
      const original = btn.textContent;
      btn.textContent = "已复制";
      setTimeout(() => {
        btn.textContent = original;
      }, 1500);
    }
  }

  /* ---------- DSH 一键升级（W15） ---------- */

  /**
   * 订阅 npm 安装输出（Rust 侧 install_dsh 逐行 emit），返回退订函数。
   * 事件 API 缺失或订阅失败时退化为「没有进度日志」——升级本身照常进行。
   */
  async function listenInstallOutput(onLine) {
    const event = window.__TAURI__?.event;
    if (!event?.listen) return () => {};
    try {
      const unlisten = await event.listen("install-output", (e) => {
        const payload = e?.payload || {};
        const line = payload.line || "";
        if (line) onLine(`[${payload.stream || "stdout"}] ${line}`);
      });
      return () => {
        try {
          unlisten();
        } catch {
          /* 退订失败无副作用 */
        }
      };
    } catch (e) {
      console.error("订阅安装输出失败", e);
      return () => {};
    }
  }

  /** 进度日志只留最后 8 行：npm 输出很长，弹窗不该被它撑爆。 */
  function appendUpgradeLog(line) {
    upgradeLogLines.push(line);
    if (upgradeLogLines.length > 8) upgradeLogLines.shift();
    const log = document.getElementById("about-upgrade-log");
    if (log) {
      log.textContent = upgradeLogLines.join("\n");
      log.classList.remove("hidden");
    }
  }

  /**
   * 升级 DSH 本体：停 → 装 → 起，三步全部复用既有命令（不新增后端命令、不动 ACL）。
   * 顺序不能反——npm 覆盖包文件时若 DSH 仍在运行，可能因文件占用而失败。
   * 完成后用新实例的地址重新导航 iframe（与启动流程同一条 showFrame 路径）。
   */
  async function runDshUpgrade() {
    const btn = document.getElementById("about-upgrade-dsh");
    const status = document.getElementById("about-upgrade-status");
    const before = aboutReport?.dsh?.current || "";

    upgradeLogLines = [];
    const log = document.getElementById("about-upgrade-log");
    if (log) {
      log.textContent = "";
      log.classList.add("hidden");
    }
    if (btn) btn.disabled = true;
    const unsubscribe = await listenInstallOutput(appendUpgradeLog);

    try {
      if (status) status.textContent = "正在停止 DeepSeek Harness…";
      await invoke("stop_dsh");

      if (status) status.textContent = "正在下载并安装…";
      const installed = await invoke("install_dsh");

      if (status) status.textContent = "正在重新启动…";
      const info = await invoke("launch_dsh");
      showFrame(info.url);

      const from = before ? `（原 v${before}）` : "";
      if (status) {
        status.textContent = info.auth_uncertain
          ? `已升级到 v${installed}${from}，但新实例无法自动鉴权——若页面提示未授权，请在提示条上点「关闭并重启」。`
          : `已升级到 v${installed}${from}，已重新启动。`;
      }
      await loadVersions();
      await runUpdateCheck();
    } catch (e) {
      if (status) status.textContent = `升级失败：${formatError(e)}`;
      // 失败时把日志留在屏幕上——npm 的报错原因就在里面
      document.getElementById("about-upgrade-log")?.classList.remove("hidden");
    } finally {
      unsubscribe();
      if (btn) btn.disabled = false;
    }
  }

  /** 两步确认：第一次点击把按钮切成「确认升级」，再点才执行（避免误触重启）。 */
  function onUpgradeDshClick() {
    const btn = document.getElementById("about-upgrade-dsh");
    if (!btn) return;
    if (!confirmArmed) {
      confirmArmed = true;
      btn.textContent = "确认升级？会重启 DSH";
      setTimeout(() => {
        if (confirmArmed) {
          confirmArmed = false;
          btn.textContent = "升级 DSH";
        }
      }, 4000);
      return;
    }
    confirmArmed = false;
    btn.textContent = "升级 DSH";
    void runDshUpgrade();
  }

  function setupAbout() {
    document.getElementById("about-close")?.addEventListener("click", closeAbout);
    // 点遮罩关闭；点卡片内部不关
    document.getElementById("about-overlay")?.addEventListener("mousedown", (e) => {
      if (e.target?.id === "about-overlay") closeAbout();
    });
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeAbout();
    });
    document
      .getElementById("about-check")
      ?.addEventListener("click", () => void runUpdateCheck());
    document.getElementById("about-download")?.addEventListener("click", () => {
      void invoke("open_in_browser", { key: "releases" }).catch((e) =>
        console.error("浏览器打开失败", e),
      );
    });
    document
      .getElementById("about-copy")
      ?.addEventListener("click", () => void copyUpgradeCommand());
    document
      .getElementById("about-upgrade-dsh")
      ?.addEventListener("click", onUpgradeDshClick);
  }

  function setupTitlebar() {
    if (!window.__TAURI__) return;
    const appWindow = window.__TAURI__.window.getCurrentWindow();
    setupWindowButtons(appWindow);
    setupNavButtons();
    setupMenus();
    setupAbout();
    setupMaxGlyph(appWindow);
  }

  /* ---------- 标题栏主题跟随（DSH 浅/深） ---------- */
  // 色板为 DSH 官方设计 token 的真实值（浅/深两套），仅作兜底：
  // 插件在线时以它发来的计算样式逐项覆盖（--tb-* 全部取 DSH 实际生效色）。

  const TB_PALETTES = {
    light: {
      bg: "#f9fafb", // --dsw-specific-sidebar-fill: bluish-50
      fg: "#0f1115", // --dsw-alias-label-primary: bluish-1000
      titleFg: "#0f1115",
      hover: "rgba(17, 24, 39, 0.08)",
      menuBorder: "rgba(0, 0, 0, 0.10)", // --dsw-alias-border-l2: #0000001a
      menuShadow: "0 10px 34px rgba(15, 23, 42, 0.14)",
      sep: "rgba(0, 0, 0, 0.04)", // --dsw-alias-border-l1: #0000000a
      danger: "#ec1313", // --dsw-alias-state-error-primary: red-600
      closeHoverBg: "#e81123",
      closeHoverFg: "#ffffff",
    },
    dark: {
      bg: "#1b1b1c", // --dsw-specific-sidebar-fill: bluish-900
      fg: "#f9fafb", // --dsw-alias-label-primary: bluish-50
      titleFg: "#f9fafb",
      hover: "rgba(255, 255, 255, 0.08)",
      menuBorder: "rgba(255, 255, 255, 0.12)", // --dsw-alias-border-l2: #ffffff1f
      menuShadow: "0 10px 34px rgba(0, 0, 0, 0.5)",
      sep: "rgba(255, 255, 255, 0.06)", // --dsw-alias-border-l1: #ffffff0f
      danger: "#f25a5a", // --dsw-alias-state-error-primary: red-400
      closeHoverBg: "#e81123",
      closeHoverFg: "#ffffff",
    },
  };

  // 插件主题到达后即以 DSH 为准，系统主题兜底不再介入
  let pluginThemeApplied = false;

  // 颜色值来自插件消息（可信来源），只做基本形状校验；非法值回退色板
  const pickColor = (value, fallback) =>
    typeof value === "string" &&
    value.length >= 3 &&
    value.length <= 64 &&
    !value.includes("var(") &&
    /^[#a-zA-Z0-9(),.\s%-]+$/.test(value)
      ? value
      : fallback;

  function applyTitlebarTheme(mode, overrides) {
    const p = TB_PALETTES[mode === "dark" ? "dark" : "light"];
    const ov = overrides || {};
    const s = document.documentElement.style;
    s.setProperty("--tb-bg", pickColor(ov.bg, p.bg));
    s.setProperty("--tb-fg", pickColor(ov.fg, p.fg));
    s.setProperty("--tb-hover", p.hover);
    // 菜单与弹窗的背景取「窗口同色」（标题栏背景）：DSH 的 overlay token 在深色主题下
    // 是 bluish-700 中灰，压在近黑的标题栏上突兀得很；同色后靠边框与阴影分层次。
    s.setProperty("--tb-menu-bg", pickColor(ov.bg, p.bg));
    s.setProperty("--tb-menu-border", pickColor(ov.menuBorder, p.menuBorder));
    s.setProperty("--tb-menu-shadow", p.menuShadow);
    s.setProperty("--tb-sep", pickColor(ov.sep, p.sep));
    s.setProperty("--tb-danger", pickColor(ov.danger, p.danger));
    s.setProperty("--tb-close-hover-bg", p.closeHoverBg);
    s.setProperty("--tb-close-hover-fg", p.closeHoverFg);
  }

  function setupThemeFollow() {
    // 主通道：Web 插件（运行在 DSH iframe 里）双向 postMessage：
    // 主题中继 + 会话导航状态（后退/前进键的可用性）。
    // 外壳每 3 秒 ping 一次，插件回以最新状态——单发丢失也能自愈。
    window.addEventListener("message", (event) => {
      const data = event.data;
      if (!data || !frameUrl) return;
      if (event.origin !== frameOrigin) return;
      // 插件消息 = DSH 页面已正常加载，接管场景的鉴权提示随之失效
      hideAuthHint();
      const navStatus = readEnvelope(data, MSG.NAV_STATUS) || data.__tbNavStatus;
      if (navStatus) {
        const back = document.getElementById("tb-back");
        const fwd = document.getElementById("tb-forward");
        if (back) back.disabled = !navStatus.back;
        if (fwd) fwd.disabled = !navStatus.forward;
        return;
      }
      const envelopeTheme = readEnvelope(data, MSG.THEME_SYNC);
      if (!envelopeTheme && data.__dshLauncherTheme !== 1) return;
      const theme = envelopeTheme || data;
      pluginThemeApplied = true;
      // 注：插件仍在上报 menuBg（DSH 的 overlay token），但外壳已改用「窗口同色」，
      // 故不再透传；协议字段保留，等大版本再清理。
      applyTitlebarTheme(theme.scheme, {
        bg: theme.bg,
        fg: theme.fg,
        menuBorder: theme.menuBorder,
        sep: theme.sep,
        danger: theme.danger,
      });
    });

    // 心跳探针：每 3 秒 ping 一次，插件回以最新导航状态。
    // 主窗口常驻应用全生命周期，窗口销毁即应用退出，无需显式清理句柄。
    setInterval(() => {
      sendNavCommand("ping");
    }, 3000);

    // 桌面端系统主题跟随：WebView2 的 prefers-color-scheme 不随 Windows 变化
    // （tauri/wry 未暴露 PreferredColorScheme），启动器轮询到系统主题变化后
    // 经事件广播到这里，再转发给 iframe 内的插件，由 DSH 主题服务恢复跟随。
    if (window.__TAURI__.event?.listen) {
      void window.__TAURI__.event
        .listen("launcher-system-theme", (e) => {
          if (e.payload === "light" || e.payload === "dark") {
            // 双发：信封（新）+ 旧字段（兼容旧版插件）；下个大版本移除旧字段。
            postToFrame({
              __tbSystemTheme: e.payload,
              v: MSG_VERSION,
              type: MSG.SYSTEM_THEME,
              payload: { scheme: e.payload },
            });
          }
        })
        .catch(() => {});
    }

    // 兜底：插件未运行（未安装 / DSH 在普通浏览器打开）→ 跟随 Windows 系统主题
    if (window.matchMedia) {
      const mq = window.matchMedia("(prefers-color-scheme: dark)");
      const onScheme = () => {
        if (!pluginThemeApplied) applyTitlebarTheme(mq.matches ? "dark" : "light");
      };
      if (mq.addEventListener) mq.addEventListener("change", onScheme);
      onScheme();
    } else {
      applyTitlebarTheme("light");
    }
  }

  function clearUnlisten() {
    if (unlisten) {
      unlisten();
      unlisten = null;
    }
  }

  function appendLog(stream, line) {
    const log = document.getElementById("install-log");
    if (!log) return;
    const div = document.createElement("div");
    div.className = stream === "stderr" ? "log-line log-err" : "log-line";
    div.textContent = line;
    log.appendChild(div);
    while (log.childElementCount > 400) {
      log.firstElementChild?.remove();
    }
    log.scrollTop = log.scrollHeight;
  }

  function showError(message) {
    clearUnlisten();
    setText("error-message", message);
    show("error");
  }

  async function run() {
    clearUnlisten();
    show("checking");
    setText("checking-status", "正在检查 DeepSeek Harness 安装状态…");

    try {
      const check = await invoke("check_dsh");

      if (!check.installed) {
        if (check.error) {
          showError(`检查失败：${check.error}`);
          return;
        }
        // 未安装 → 自动安装（显示加载动画与实时日志）
        show("installing");
        unlisten = await listen("install-output", (e) =>
          appendLog(e.payload.stream, e.payload.line),
        );
        const version = await invoke("install_dsh");
        clearUnlisten();
        // 安装成功提示
        setText("success-hint", `DeepSeek Harness v${version} 安装成功，正在启动…`);
        show("success");
        await sleep(2600);
      } else {
        setText(
          "checking-status",
          `已检测到 DeepSeek Harness v${check.version ?? "?"}，正在启动…`,
        );
        await sleep(900);
      }

      show("launching");
      const info = await invoke("launch_dsh");
      setText("linking-hint", `本地服务：${info.url}`);
      show("linking");
      await sleep(900);
      // 不再整页跳转：交给 iframe 承载，标题栏得以常驻
      showFrame(info.url);
      // 接管的是外部新版实例且无法确定 WebView 是否已持有鉴权 cookie：
      // 页面若加载失败会停在 401，提示条引导用户处理
      if (info.auth_uncertain) showAuthHint();
    } catch (e) {
      showError(`操作失败：${formatError(e)}`);
    }
  }

  window.addEventListener("DOMContentLoaded", () => {
    setupTitlebar();
    setupThemeFollow();
    document.getElementById("auth-hint-close")?.addEventListener("click", dismissAuthHint);
    document
      .getElementById("auth-hint-restart")
      ?.addEventListener("click", () => void restartExternalInstance());
    document.getElementById("retry-btn")?.addEventListener("click", () => {
      const log = document.getElementById("install-log");
      if (log) log.innerHTML = "";
      void run();
    });
    void run();
  });
})();
