# 余额悬浮窗（dsh-opencode-go-monitor）

DSH（DeepSeek Harness）Web UI 悬浮面板插件：**四标签页** 实时显示 **DeepSeek / Command Code GOAT / OpenCode Go / Charm Hyper** 的余额（标签切换带滑动+淡入动画）。

## 功能

- **四标签页**：DeepSeek 余额 / Command Code GOAT 余额 / OpenCode Go 额度 / Charm Hyper 余额，点击切换，带方向滑动 + 淡入动画
- **OpenCode Go 页**：官方订阅额度三窗口（**滚动 / 每周 / 每月**）：剩余 %（绿≥50% / 橙≥25% / 红<25%）+ 进度条 + 已用 % + 重置倒计时，外加最近一次窗口重置倒计时
- **Command Code GOAT 页**：5 小时 / 每周 两档滚动窗口：剩余 %（绿≥50% / 橙≥25% / 红<25%）+ 进度条 + 已用 % + 重置倒计时，外加 **月度余额**（美元：月度+已购+免费三池合计）
- **DeepSeek 页**：余额、预计剩余 tokens（按官方现行价 + 本账户用量结构折算的有效单价估算，尾注当前空闲/高峰时段与单价）、当前模型
- **Charm Hyper 页**：余额（hypercredits）+ 约合美元（官方 balance_usd，或按 20 hc ≈ $1 折算）
- 可**拖动**（位置记忆）、右下角**调整大小**（尺寸记忆）
- 轮询：DeepSeek 每 30s、Command Code GOAT 每 60s、OpenCode Go 每 60s、Charm Hyper 每 30s

> 已移除原「省钱」功能：限额、超限断点截断、低耗压缩、官网用量分析、语音提醒、时段建议等。

## 预计剩余估算口径（2026-09 官方调价后）

官方现行价（¥/百万 tokens，**空闲时段价**；高峰时段 = 空闲 × 2）：

| 模型 | 输入·缓存命中 | 输入·缓存未命中 | 输出 |
| --- | --- | --- | --- |
| deepseek-flash（旧名 `deepseek-v4-flash` / `deepseek-v4-flash-vision-exp` 现由 V4.1-Flash 提供服务，按 Flash 计费） | 0.02 | 1 | 4 |
| deepseek-v4-pro | 0.15 | 4.5 | 13.5 |

- **高峰时段**：北京时间周一至周五 09:00-12:00、14:00-18:00；其余时间（含周末全天）为空闲时段
- **有效单价**＝输入侧（缓存命中率加权）× 输入占比 ＋ 输出价 × 输出占比；命中率与占比取本账户 2026-08 官网平台实测（命中 721.98M / 未命中 6.84M / 输出 4.69M → 命中率 99.1%、输出占比 0.6%）
- 推算结果：Flash 空闲 ≈ **¥0.0546/百万**、高峰 ≈ **¥0.1092/百万**；Pro 空闲 ≈ ¥0.2759/百万、高峰 ≈ ¥0.5518/百万
- 面板「预计剩余」＝ 余额 ÷ 当前时段有效单价，行尾标注「空闲/高峰 + 单价」；鼠标悬浮可看完整口径（官方三档价、命中率、另一时段估算）
- 对照 2026-09 调价前（Flash 命中 0.05 / 未命中 1.5 / 输出 4.5）：同余额下预计剩余约为调价前的 **2.2 倍**
- 价格来源：[DeepSeek 官方「模型 & 价格」页](https://api-docs.deepseek.com/zh-cn/quick_start/pricing/)

> 估算仅为参考：实际花费取决于缓存命中率、输出占比与所用模型；切换模型（Flash ↔ Pro）后按对应价目重算。命中率与占比是**本账户实测常数**（其他部署请按自己账号的平台月报改 `DS_USAGE_SAMPLE`），改价只改 `DS_PRICE_OFFPEAK` 一处即可。
>
> 未建模：法定节假日（官方公告里也按空闲计价，影响 <1%）；若 V4 Pro 后续改由 Flash 提供服务，按模型名仍走 Pro 价目（估算偏保守）。

## 前置条件

| 依赖 | 说明 |
| --- | --- |
| DeepSeek Harness（web 或桌面端） | 插件运行在 DSH 内 |
| DeepSeek API key | DSH **设置 → 凭据** 添加 `DEEPSEEK_API_KEY`（DeepSeek 余额标签页用） |
| Command Code GOAT 订阅 + API key | DSH **设置 → 凭据** 添加 `COMMANDCODE_API_KEY`（在 [commandcode.ai/settings](https://commandcode.ai/settings) 创建，`user_` 开头；也兼容 `COMMAND_CODE_API_KEY` 命名或环境变量 `COMMAND_CODE_API_KEY`，未配置时尽力而为读取 Command Code CLI 登录凭据 `~/.commandcode/auth.json`） |
| Charm Hyper 订阅 + API key | DSH **设置 → 凭据** 添加 `HYPER_API_KEY`（兼容 `HYPERCHARM_API_KEY` 命名或环境变量） |
| OpenCode Go 订阅 | DSH **设置 → 凭据** 添加 `OPENCODE_GO_API_KEY`（兼容 `OPENCODE_API_KEY` / 同名环境变量）；未配置时自动读 opencode 登录凭据 `~/.local/share/opencode/auth.json` 的 `opencode-go` 条目，WSL 下还会探测 Windows 用户目录 `/mnt/c/Users/<用户>/.local/share/opencode/auth.json` |

## 隐私说明

- API key 只在进程内存中使用，用于调用官方余额接口，**不落盘、不写日志、不发给任何第三方**
- 仓库内不含任何密钥 —— 每个部署者在自己的机器上配置自己的凭据，看到的是自己的余额

## 安装

### 方式一：标准流程（热加载）

1. 把插件文件夹（含 `package.json` 和 `lib/`）整个复制到 `$DSH_HOME/profiles/node_modules/dsh-opencode-go-monitor/`
2. 编辑 `$DSH_HOME/profiles/web/cordis.patch.yml`（没有则新建，内容为 `[]`），追加：

   ```yaml
   # 余额悬浮窗
   - insert:
       - id: opencode-go-monitor
         name: 'dsh-opencode-go-monitor'
   ```

3. `cordis.patch.yml` 修改会**热加载**，无需重启；刷新浏览器页面（Ctrl+Shift+R）即可看到面板
4. 配置凭据：DSH **设置 → 凭据** → 添加 `DEEPSEEK_API_KEY`、`COMMANDCODE_API_KEY`、`HYPER_API_KEY`

### 方式二：super-injector（如果装有）

```text
dev_install_package dir=<本文件夹绝对路径>
```

## 排错

| 现象 | 处理 |
| --- | --- |
| 状态行「余额失败：未配置 COMMAND_CODE_API_KEY 凭据」 | DSH 设置 → 凭据 添加 `COMMANDCODE_API_KEY`，或设置环境变量 `COMMAND_CODE_API_KEY`，或确认已 `cmd login`（自动读取 `~/.commandcode/auth.json`） |
| 状态行「余额失败：HTTP 401」 | key 无效/过期，到对应服务商控制台重新生成 |
| DeepSeek 余额显示为负 | 账户余额已用超，注意在 [platform.deepseek.com](https://platform.deepseek.com) 充值 |
| 面板完全不显示 | 确认 `cordis.patch.yml` 注册行格式、`profiles/node_modules/dsh-opencode-go-monitor` 路径；浏览器硬刷新（Ctrl+Shift+R）；F12 控制台看红色报错 |

## 卸载

1. 从 `cordis.patch.yml` 删除注册行（热加载立即移除）
2. 删除 `profiles/node_modules/dsh-opencode-go-monitor/` 文件夹

## 结构

```
├── package.json      # 插件清单（dsh.client 双半声明）
└── lib/
    ├── index.js      # host 半：/api/commandcode-goat/balance（GOAT 官方接口，60s 缓存）
    │                 #       /api/deepseek/balance（DeepSeek 官方接口，5s 缓存）
    │                 #       /api/opencode-go/balance（OpenCode Go 官方 /usage 接口，60s 缓存）
    │                 #       /api/hypercharm/balance（Charm Hyper 官方接口，30s 缓存）
    └── client.js     # client 半：shell.overlay 悬浮面板（拖动/缩放/位置记忆）
└── test/
    └── client-smoke.mjs  # 无浏览器冒烟测试（最小 React/DOM shim 跑渲染路径并断言四标签页）
```

## 自测

```bash
node test/client-smoke.mjs   # 不依赖 DSH / 浏览器，全 PASS 则四标签页（含 OpenCode Go 面板）渲染正常
```