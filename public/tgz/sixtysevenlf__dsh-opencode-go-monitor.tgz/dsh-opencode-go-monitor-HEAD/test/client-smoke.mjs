// client-smoke.mjs — 无浏览器冒烟测试（不依赖 DSH / 浏览器）
//   用最小 React/DOM shim 跑一遍 lib/client.js 的渲染路径：注入 apply → 点击各标签 →
//   断言四个标签与 OpenCode Go 面板（滚动/每周/每月 + 剩余%/已用%）渲染正确。
// 用法：node test/client-smoke.mjs
const routes = {
  '/api/deepseek/balance': { ok: true, balance: 2.77, currency: 'CNY', estTokens: 25366300, pricePerMillion: 0.1092, pricePeriod: 'peak', model: 'deepseek-v4.1-flash', fetchedAt: Date.now() },
  '/api/commandcode-goat/balance': { ok: true, fetchedAt: Date.now(), fiveHour: { percent: 10, resetsAt: Date.now() + 3600000 }, weekly: { percent: 20, resetsAt: Date.now() + 86400000 }, monthly: { present: true, remaining: 12.5 } },
  '/api/opencode-go/balance': { ok: true, fetchedAt: Date.now(), rolling: { status: 'ok', percent: 6, resetsAt: '2026-09-14T13:08:46.329Z' }, weekly: { status: 'ok', percent: 2, resetsAt: '2026-09-21T00:00:00.329Z' }, monthly: { status: 'ok', percent: 1, resetsAt: '2026-10-14T08:02:19.329Z' }, source: 'DSH 凭据 OPENCODE_GO_API_KEY' },
  '/api/hypercharm/balance': { ok: true, balance: 247, unit: 'hc', priceUsd: null, fetchedAt: Date.now() },
};
globalThis.window = { innerWidth: 1280, innerHeight: 800, addEventListener: () => {}, removeEventListener: () => {}, requestAnimationFrame: () => 0, cancelAnimationFrame: () => {}, __ModuleLoader__: { load(cfg) { globalThis.__CFG = cfg; } } };
globalThis.document = { querySelector: () => null, createElement: () => ({ setAttribute() {}, style: {}, appendChild() {} }), head: { appendChild() {} } };
globalThis.localStorage = { getItem: () => null, setItem: () => {} };
globalThis.fetch = async (url) => ({ json: async () => routes[url] || { ok: false, error: 'no route ' + url } });

const st = [], refs = [], ranEffects = new Set();
let hookIndex = 0, rerender = null, renders = 0;
const React = {
  useState: (v) => { const i = hookIndex++; if (!(i in st)) st[i] = typeof v === 'function' ? v() : v;
    return [st[i], (nv) => { st[i] = typeof nv === 'function' ? nv(st[i]) : nv; if (rerender) rerender(); }]; },
  useEffect: (f) => { const i = hookIndex++; if (ranEffects.has(i)) return; ranEffects.add(i); const c = f(); if (typeof c === 'function') ranEffects.add('cleanup' + i); },
  useCallback: (f) => { hookIndex++; return f; },
  useRef: (v) => { const i = hookIndex++; if (!(i in refs)) refs[i] = { current: v }; return refs[i]; },
  createElement: (type, props, ...children) => ({ type, props: props || {}, children }),
};
const requireShim = (m) => { if (m === 'react') return React; throw new Error('unexpected require: ' + m) };

await import(new URL('../lib/client.js', import.meta.url).href);
const mod = globalThis.__CFG.factory(requireShim);
let renderFn = null;
mod.apply({
  effect: (f) => f(),
  interval: () => () => {},
  slots: { inject: (n, cb) => cb(), register: (meta, render) => { if (meta.name === 'shell.overlay') renderFn = render; return () => {}; } },
  get: () => undefined,
});
let tree = null;
const render = () => { hookIndex = 0; renders++; tree = renderFn({}); return tree; };
rerender = render;
tree = render();
await new Promise((r) => setTimeout(r, 400)); // 等四个接口的异步 setState

const find = (n, pred, out = []) => {
  if (n == null || typeof n === 'string' || typeof n === 'number') return out;
  if (Array.isArray(n)) { n.forEach((x) => find(x, pred, out)); return out; }
  if (pred(n)) out.push(n);
  find(n.children, pred, out);
  return out;
};
const collectText = (n, out = []) => {
  if (n == null) return out;
  if (typeof n === 'string' || typeof n === 'number') { out.push(String(n)); return out; }
  if (Array.isArray(n)) { n.forEach((x) => collectText(x, out)); return out; }
  collectText(n.children, out);
  return out;
};

let failed = 0;
const ok = (cond, msg) => { if (!cond) failed++; console.log((cond ? 'PASS ' : 'FAIL ') + msg); };

const tabBtns = find(tree, (n) => n.type === 'button' && n.props.className && String(n.props.className).includes('opencg-tab'));
ok(tabBtns.map((b) => collectText(b).join('')).join('/') === 'DeepSeek/GOAT/OpenCode Go/Charm Hyper', '四个标签按钮顺序：' + tabBtns.map((b) => collectText(b).join('')).join(' / '));

const ocBtn = tabBtns.find((b) => collectText(b).join('') === 'OpenCode Go');
ok(!!ocBtn, '存在 OpenCode Go 标签按钮');
if (ocBtn) {
  ocBtn.props.onClick();
  const txt = collectText(tree).join(' | ');
  ok(txt.includes('滚动') && txt.includes('每周') && txt.includes('每月'), 'OC 面板三窗口行（滚动/每周/每月）');
  ok(txt.includes('94%') && txt.includes('98%') && txt.includes('99%'), '剩余 %（100-已用）：94% / 98% / 99%');
  ok(txt.includes('已用 6%') && txt.includes('已用 2%') && txt.includes('已用 1%'), '已用 % 文案');
  ok(txt.includes('额度刷新'), '额度刷新倒计时行');
  const active = find(tree, (n) => String((n.props || {}).className || '').includes('opencg-tab active'));
  ok(collectText(active[0] || []).join('') === 'OpenCode Go', 'OpenCode Go 为激活标签');
  const root = find(tree, (n) => String((n.props || {}).className || '').startsWith('opencg'))[0];
  ok(String(root.props.title).startsWith('OpenCode Go 额度'), '面板 tip：' + root.props.title);
}
console.log(failed === 0 ? 'SMOKE_OK (' + renders + ' renders)' : 'SMOKE_FAILED: ' + failed);
process.exit(failed === 0 ? 0 : 1);
