/**
 * Desktop shortcut management across platforms, with headless-host safety:
 * detection returns null when no interactive desktop exists (Windows Server
 * without a Desktop, Linux without DISPLAY/WAYLAND_DISPLAY, headless CI), and
 * every creation/update failure is caught and reported — never thrown into
 * the plugin boot.
 *
 * The shortcut points at a small generated launcher script (poll-until-ready,
 * then open the browser), mirroring the classic launcher UX:
 *  - Windows: a `.cmd` in the managed dir + a `.lnk` on the Desktop
 *    (WScript.Shell COM via PowerShell), icon = `.ico`;
 *  - Linux: a `.sh` in the managed dir + a `.desktop` on the Desktop,
 *    icon = `.png`;
 *  - macOS: a double-clickable `.command` on the Desktop; custom icons are
 *    not supported there (reported as a soft failure).
 */

import { execFile } from 'node:child_process'
import { chmodSync, existsSync, mkdirSync, readFileSync, unlinkSync, writeFileSync } from 'node:fs'
import { homedir, tmpdir } from 'node:os'
import { join } from 'node:path'
import process from 'node:process'

/** Everything needed to build the shortcut and its launcher script. */
export interface LauncherSpec {
  /** Display name of the shortcut. */
  name: string
  /** Executable that starts the server (the node executable). */
  command: string
  /** Full argument list: CLI entry + --profile web --host <h> --port <p>. */
  cliArgs: string[]
  /** Working directory for the server process. */
  cwd: string
  /** URL the launcher script opens once ready. */
  url: string
  /** Shortcut description. */
  description: string
  /** Icon file path ('' = platform default). */
  iconPath: string
}

/** A created shortcut: the file on the desktop. */
export interface ShortcutHandle {
  path: string
}

/**
 * Detect an interactive desktop directory, or null when none exists. The
 * headless check is the crash guard: plugins on servers/CI must never attempt
 * desktop work.
 */
export function detectDesktopDir(): string | null {
  const platform = process.platform
  if (platform === 'win32') {
    const home = process.env.USERPROFILE ?? homedir()
    for (const candidate of [join(home, 'Desktop'), join(home, 'OneDrive', 'Desktop')]) {
      if (existsSync(candidate)) return candidate
    }
    return null
  }
  if (platform === 'darwin') {
    const dir = join(homedir(), 'Desktop')
    return existsSync(dir) ? dir : null
  }
  // Linux: a desktop session needs a display; headless hosts skip entirely.
  if (!process.env.DISPLAY && !process.env.WAYLAND_DISPLAY) return null
  const xdg = process.env.XDG_DESKTOP_DIR
  if (xdg !== undefined && xdg !== '' && existsSync(xdg)) return xdg
  const dir = join(homedir(), 'Desktop')
  return existsSync(dir) ? dir : null
}

/** Escape a path/argument for embedding in a double-quoted shell string. */
function shQuote(value: string): string {
  return value.replaceAll('"', '\\"')
}

/** Generate the poll-until-ready launcher script into the managed dir. The
 * spawned CLI runs with `spec.cwd` as its working directory via an explicit
 * `cd` — the .lnk's WorkingDirectory can be lost or overridden, and a checkout
 * layout needs a cwd from which `--import tsx/esm` can resolve tsx. On Windows
 * the server is started through a generated VBScript with a hidden console, so
 * no Node.js terminal sits on the desktop (or the taskbar) while it runs. */
export function writeLauncherScript(managedDir: string, spec: LauncherSpec): string {
  mkdirSync(managedDir, { recursive: true })
  const args = spec.cliArgs.map(shQuote).join(' ')
  const commandLine = `"${shQuote(spec.command)}" ${args}`
  // One poll line shared by the pre-check and the loop; exits 1 while the
  // surface is NOT ready. Ready means the shell answers 200 AND the client
  // API transport is up (426 on /api/events.mux) — opening the browser on the
  // shell alone boots it to "Failed to load plugins" (all entries pending on
  // `connection`). The polarity must be `-ne 200/-ne 426` — an inverted check
  // would exit 1 when ready and loop forever. `%%` is cmd's literal-percent
  // escape so curl's `%{http_code}` survives the batch file.
  const poll = `>nul 2>&1 powershell -NoProfile -Command "$r = 0; $w = 0; try { $r = curl.exe -s -o NUL -w '%%{http_code}' --max-time 2 '${spec.url}/' } catch { }; try { $w = curl.exe -s -o NUL -w '%%{http_code}' --max-time 2 '${spec.url}/api/events.mux' } catch { }; exit (($r -ne '200') -or ($w -ne '426'))"`
  // Port the launcher's server listens on — used to record its PID so the
  // plugin can stop it later. Only recorded on the SPAWN path: the
  // already-serving path must never claim a foreign server's PID.
  const port = new URL(spec.url).port
  const pidFile = join(managedDir, 'server.pid')
  if (process.platform === 'win32') {
    const path = join(managedDir, 'launch.cmd')
    const vbsPath = join(managedDir, 'launch-server.vbs')
    // Hidden-console server launch: window style 0 hides the console, so the
    // long-running server never shows a terminal. Quotes are doubled for the
    // VBScript string literal.
    writeFileSync(vbsPath, [
      "' Generated by dsh-webui-launcher: starts the Web UI server hidden.",
      'Set sh = WScript.CreateObject("WScript.Shell")',
      `sh.CurrentDirectory = "${vbsQuote(spec.cwd)}"`,
      `sh.Run "${vbsQuote(commandLine)}", 0, False`,
      '',
    ].join('\r\n'), 'utf8')
    writeFileSync(path, [
      '@echo off',
      'setlocal',
      `cd /d "${shQuote(spec.cwd)}"`,
      // Already serving? Just open the browser — no spawn, no console flash.
      poll,
      'if not errorlevel 1 goto open',
      `wscript.exe "${shQuote(vbsPath)}"`,
      ':loop',
      poll,
      'if errorlevel 1 ( timeout /t 1 /nobreak >nul & goto loop )',
      // We spawned and the server is ready: record its PID (netstat's last
      // LISTENING column) so the plugin's stop() can close it later.
      `for /f "tokens=5" %%p in ('netstat -ano ^| findstr /c:":${port} " ^| findstr "LISTENING"') do set DSH_SRVPID=%%p`,
      `if defined DSH_SRVPID echo %DSH_SRVPID%>"${shQuote(pidFile)}"`,
      ':open',
      `start "" "${spec.url}"`,
      'endlocal',
      '',
    ].join('\r\n'), 'utf8')
    return path
  }
  const path = join(managedDir, 'launch.sh')
  const opener = process.platform === 'darwin' ? 'open' : 'xdg-open'
  writeFileSync(path, [
    '#!/bin/sh',
    `# ${spec.name} launcher (generated by dsh-webui-launcher)`,
    `cd "${shQuote(spec.cwd)}" || exit 1`,
    // Ready = shell 200 AND the client API transport up (426); opening on the
    // shell alone boots the page to "Failed to load plugins".
    'is_ready() {',
    `  [ "$(curl -s -o /dev/null -w '%{http_code}' --max-time 2 "${spec.url}/api/events.mux" 2>/dev/null)" = "426" ] && curl -sf "${spec.url}/" -o /dev/null`,
    '}',
    // Already serving? Just open the browser.
    `if is_ready; then ${opener} "${spec.url}" >/dev/null 2>&1 & exit 0; fi`,
    `${commandLine} &`,
    'i=0',
    'while [ $i -lt 120 ]; do',
    '  if is_ready; then break; fi',
    '  sleep 1',
    '  i=$((i+1))',
    'done',
    // Record the spawned server's PID (spawn path only) so the plugin can
    // stop it later; an empty file (no lsof) simply disables that.
    `lsof -nP -tiTCP:${port} -sTCP:LISTEN 2>/dev/null | head -n 1 > "${shQuote(pidFile)}"`,
    `${opener} "${spec.url}" >/dev/null 2>&1 &`,
    '',
  ].join('\n'), 'utf8')
  chmodSync(path, 0o755)
  return path
}

/** Double any double quote for embedding inside a VBScript string literal. */
function vbsQuote(value: string): string {
  return value.replaceAll('"', '""')
}

/** Run a generated PowerShell script with a JSON config file as its argument. */
function runPowerShell(psPath: string, cfgPath: string): Promise<boolean> {
  return new Promise((resolve) => {
    execFile('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', psPath, cfgPath], { windowsHide: true }, (error) => {
      resolve(error === null)
    })
  })
}

/** Create the desktop shortcut; returns null when skipped or failed. */
export async function createShortcut(desktopDir: string, managedDir: string, spec: LauncherSpec): Promise<ShortcutHandle | null> {
  const launcher = writeLauncherScript(managedDir, spec)
  try {
    if (process.platform === 'win32') {
      const path = join(desktopDir, `${spec.name}.lnk`)
      const cfgPath = join(managedDir, 'shortcut-cfg.json')
      const psPath = join(managedDir, 'create-shortcut.ps1')
      writeFileSync(cfgPath, JSON.stringify({
        path,
        target: launcher,
        arguments: '',
        // The .lnk's WorkingDirectory must be where the spawned CLI can run
        // (a checkout layout needs a cwd that resolves `--import tsx/esm`),
        // not the managed dir.
        cwd: spec.cwd,
        description: spec.description,
        icon: spec.iconPath,
      }), 'utf8')
      writeFileSync(psPath, [
        '$cfg = Get-Content -Raw -Encoding UTF8 $args[0] | ConvertFrom-Json',
        '$ws = New-Object -ComObject WScript.Shell',
        '$s = $ws.CreateShortcut($cfg.path)',
        '$s.TargetPath = $cfg.target',
        '$s.Arguments = $cfg.arguments',
        '$s.WorkingDirectory = $cfg.cwd',
        '$s.Description = $cfg.description',
        // Run the launcher console minimized so the polling window does not
        // sit on the desktop while the server boots.
        '$s.WindowStyle = 7',
        'if ($cfg.icon -ne "") { $s.IconLocation = $cfg.icon }',
        '$s.Save()',
        '',
      ].join('\n'), 'utf8')
      const ok = await runPowerShell(psPath, cfgPath)
      return ok ? { path } : null
    }
    if (process.platform === 'darwin') {
      // The .command on the desktop IS the launcher script.
      const path = join(desktopDir, `${spec.name}.command`)
      const script = readFileSync(launcher, 'utf8')
      writeFileSync(path, script, 'utf8')
      chmodSync(path, 0o755)
      return { path }
    }
    // Linux
    const path = join(desktopDir, `${spec.name}.desktop`)
    const iconLine = spec.iconPath === '' ? '' : `Icon=${spec.iconPath}`
    writeFileSync(path, [
      '[Desktop Entry]',
      'Type=Application',
      'Version=1.0',
      `Name=${spec.name}`,
      `Comment=${spec.description}`,
      // Quote the launcher path: a DSH_HOME with spaces would otherwise split
      // the Exec field and the desktop environment would fail to launch it.
      `Exec="${launcher}"`,
      iconLine,
      'Terminal=false',
      'Categories=Network;',
      '',
    ].filter((line) => line !== '').join('\n'), 'utf8')
    chmodSync(path, 0o755)
    return { path }
  } catch {
    return null
  }
}

/** Update an existing shortcut's icon; false when unsupported or failed. */
export async function updateShortcutIcon(handle: ShortcutHandle, iconFile: string): Promise<boolean> {
  try {
    if (process.platform === 'win32') {
      // The cfg/ps1 are transient — write them to the system temp, never next
      // to the .lnk (the Desktop), so an icon update leaves no litter behind.
      const stamp = `${process.pid}-${Date.now()}`
      const cfgPath = join(tmpdir(), `dsh-icon-cfg-${stamp}.json`)
      const psPath = join(tmpdir(), `dsh-update-icon-${stamp}.ps1`)
      writeFileSync(cfgPath, JSON.stringify({ path: handle.path, icon: iconFile }), 'utf8')
      writeFileSync(psPath, [
        '$cfg = Get-Content -Raw -Encoding UTF8 $args[0] | ConvertFrom-Json',
        '$ws = New-Object -ComObject WScript.Shell',
        '$s = $ws.CreateShortcut($cfg.path)',
        '$s.IconLocation = $cfg.icon',
        '$s.Save()',
        '',
      ].join('\n'), 'utf8')
      const ok = await runPowerShell(psPath, cfgPath)
      try {
        unlinkSync(cfgPath)
        unlinkSync(psPath)
      } catch {
        /* best-effort cleanup */
      }
      return ok
    }
    if (process.platform === 'linux' && handle.path.endsWith('.desktop')) {
      const content = readFileSync(handle.path, 'utf8')
      const lines = content.split('\n').map((line) => (/^Icon=/.test(line) ? `Icon=${iconFile}` : line))
      writeFileSync(handle.path, lines.join('\n'), 'utf8')
      return true
    }
    return false
  } catch {
    return false
  }
}
