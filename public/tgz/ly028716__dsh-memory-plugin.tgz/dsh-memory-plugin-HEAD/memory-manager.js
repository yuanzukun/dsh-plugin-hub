/**
 * Memory Manager
 * Core logic for tracking, analyzing, and managing user memory data.
 */

const { MemoryStorage, DEFAULT_MEMORY, cloneData, parseDotPath } = require('./storage');
const { DataLifecycleManager } = require('./data-lifecycle');
const fs = require('fs').promises;
const path = require('path');
const { redactSensitiveData, redactProjectPath } = require('./privacy');
const {
  INPUT_LIMITS,
  assertTextLength,
  assertDataWithinLimits,
  trimArrayToLimits
} = require('./limits');

const IMPORTED_HISTORY_FIELDS = [
  ['inputHabits', 'commonCommands'],
  ['inputHabits', 'frequentPatterns'],
  ['inputHabits', 'preferredTools'],
  ['sessionHistory', 'recentTopics'],
  ['sessionHistory', 'frequentTasks']
];

const RECOMMENDATION_FEEDBACK_TYPES = new Set(['agent', 'model', 'commands', 'projects']);
const RECOMMENDATION_FEEDBACK_OUTCOMES = new Set(['helpful', 'not_helpful']);

function tokenizeContext(value) {
  if (typeof value !== 'string') return [];
  return [...new Set((value.toLocaleLowerCase().match(/[\p{L}\p{N}]+/gu) || []))];
}

function contextMatchCount(value, tokens) {
  const text = String(value || '').toLocaleLowerCase();
  const candidateTokens = new Set(tokenizeContext(text));
  return tokens.filter((token) => /^[a-z0-9]+$/i.test(token)
    ? candidateTokens.has(token)
    : text.includes(token)).length;
}

function rankByContext(items, hasContext, tokens, textFor, secondaryScore, feedbackScore = () => 0) {
  return items
    .map((item) => ({
      item,
      matches: contextMatchCount(textFor(item), tokens),
      score: secondaryScore(item),
      feedbackScore: feedbackScore(item)
    }))
    .filter((entry) => !hasContext || entry.matches > 0)
    .sort((left, right) => right.matches - left.matches || right.score - left.score || right.feedbackScore - left.feedbackScore);
}

function feedbackFor(entries, type, item) {
  const entry = Array.isArray(entries)
    ? entries.find((candidate) => candidate && candidate.type === type && candidate.item === item)
    : null;
  const helpful = Number.isSafeInteger(entry?.helpful) && entry.helpful >= 0 ? entry.helpful : 0;
  const notHelpful = Number.isSafeInteger(entry?.notHelpful) && entry.notHelpful >= 0 ? entry.notHelpful : 0;
  return { helpful, notHelpful, score: helpful - notHelpful };
}

function explanation(source, hasContext, ranked = []) {
  const matches = ranked.reduce((maximum, entry) => Math.max(maximum, entry.matches || 0), 0);
  const feedbackScore = ranked.reduce((total, entry) => total + (entry.feedbackScore || 0), 0);
  return {
    source,
    contextMatched: matches > 0,
    matchedTokenCount: matches,
    feedbackScore,
    confidence: hasContext ? (matches > 0 ? 'high' : 'low') : 'medium'
  };
}

function boundImportedHistory(data, maxHistoryItems) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) return data;

  for (const [sectionName, fieldName] of IMPORTED_HISTORY_FIELDS) {
    const section = data[sectionName];
    if (!section || typeof section !== 'object' || Array.isArray(section)) continue;
    if (Array.isArray(section[fieldName])) {
      section[fieldName] = trimArrayToLimits(
        section[fieldName],
        maxHistoryItems,
        INPUT_LIMITS.maxStoredValueBytes
      );
    }
  }

  return data;
}

function isRecoverableMemoryFileError(error) {
  return error instanceof SyntaxError || error?.message === 'Invalid memory data format';
}

function isNonEmptyString(value) {
  return typeof value === 'string' && value.trim() !== '';
}

function isRecommendationCommand(value) {
  return value && typeof value === 'object' && !Array.isArray(value) &&
    isNonEmptyString(value.command) && Number.isFinite(value.count);
}

function isRecommendationProject(value) {
  return value && typeof value === 'object' && !Array.isArray(value) &&
    isNonEmptyString(value.path);
}

class MemoryManager {
  constructor(config, storage) {
    this.config = config;
    this.storage = storage;
    this.lifecycle = new DataLifecycleManager(storage, config);
    this.autoSaveTimer = null;
    this._autoSaveGeneration = 0;
    this.sessionStartTime = null;
    this._initializePromise = null;
    this.recommendationMetrics = {
      requests: 0,
      availableRequests: 0,
      contextualRequests: 0,
      contextMatches: 0,
      fallbackRequests: 0,
      suggestions: 0
    };
  }

  /**
   * Initialize the memory manager
   */
  async initialize() {
    if (this.sessionStartTime) return;
    if (this._initializePromise) return this._initializePromise;

    this._initializePromise = (async () => {
      const automaticCollectionEnabled = this.isAutomaticCollectionEnabled();
      if (this.config.backupOnInitialize) {
        try {
          await fs.access(this.storage.storagePath);
          await this.lifecycle.backupFile('startup');
        } catch (error) {
          if (error.code !== 'ENOENT') throw error;
        }
      }
      try {
        await this.storage.initialize({
          persistIfMissing: automaticCollectionEnabled,
          persistSanitized: automaticCollectionEnabled
        });
      } catch (error) {
        if (!isRecoverableMemoryFileError(error)) throw error;
        try {
          const recovery = await this.lifecycle.recoverFromLatestBackup();
          console.warn(`Memory plugin: Recovered corrupt memory from backup ${recovery.restored}`);
        } catch (recoveryError) {
          error.recoveryError = recoveryError;
          throw error;
        }
      }
      if (automaticCollectionEnabled) this.startAutoSave();
      this.sessionStartTime = Date.now();

      // Update session metadata
      if (automaticCollectionEnabled) {
        await this.storage.recordSessionStart();
      }
      await this.lifecycle.applyRetention();
    })();

    try {
      await this._initializePromise;
    } catch (error) {
      this.stopAutoSave();
      this.sessionStartTime = null;
      throw error;
    } finally {
      this._initializePromise = null;
    }
  }

  async ensureInitialized() {
    await this.initialize();
  }

  isAutomaticCollectionEnabled() {
    return this.config.trackToolCalls ||
      this.config.trackPreferences ||
      this.config.trackProjectContext ||
      this.config.trackSessionHistory;
  }

  /**
   * Start automatic saving at configured intervals
   */
  startAutoSave() {
    this.stopAutoSave();
    const generation = this._autoSaveGeneration;
    const schedule = () => {
      if (generation !== this._autoSaveGeneration) return;
      this.autoSaveTimer = setTimeout(async () => {
        if (generation !== this._autoSaveGeneration) return;
        try {
          await this.storage.save();
        } catch (error) {
          console.error('Memory plugin: Auto-save failed:', error.message);
        } finally {
          schedule();
        }
      }, this.config.autoSaveInterval);
    };

    schedule();
  }

  /**
   * Stop automatic saving.
   */
  stopAutoSave() {
    this._autoSaveGeneration += 1;
    if (this.autoSaveTimer) {
      clearTimeout(this.autoSaveTimer);
      this.autoSaveTimer = null;
    }
  }

  /**
   * Record a tool call
   * @param {Object} toolCall - Tool call information
   */
  async recordToolCall(toolCall) {
    if (!this.config.trackToolCalls) return;

    if (!toolCall || typeof toolCall !== 'object' || typeof toolCall.name !== 'string' || toolCall.name.trim() === '') {
      throw new Error('toolCall.name must be a non-empty string');
    }
    assertTextLength(toolCall.name, 'toolCall.name', INPUT_LIMITS.maxProjectNameLength);

    await this.ensureInitialized();

    const { name, args } = toolCall;
    const mutations = [
      {
        dotPath: 'sessionHistory.toolUsageStats',
        mutate: (stats) => {
          const nextStats = stats && typeof stats === 'object' && !Array.isArray(stats) ? stats : {};
          const currentCount = Number.isSafeInteger(nextStats[name]) && nextStats[name] >= 0
            ? nextStats[name]
            : 0;
          nextStats[name] = currentCount + 1;
          return nextStats;
        }
      }
    ];

    if (this.config.trackPreferences) {
      mutations.push({
        dotPath: 'inputHabits.preferredTools',
        maxArrayBytes: INPUT_LIMITS.maxStoredValueBytes,
        mutate: (tools) => {
          const nextTools = Array.isArray(tools) ? tools : [];
          if (!nextTools.includes(name)) nextTools.push(name);
          return nextTools;
        }
      });
    }

    if (args && args.command) {
      if (typeof args.command !== 'string') throw new Error('command must be a string');
      assertTextLength(args.command, 'command');
      const safeCommand = redactSensitiveData(args.command);
      mutations.push({
        dotPath: 'inputHabits.commonCommands',
        maxArrayLength: this.config.maxHistoryItems,
        mutate: (commands) => {
          const nextCommands = Array.isArray(commands) ? commands : [];
          const existingIndex = nextCommands.findIndex((entry) => entry && entry.command === safeCommand);
          const now = new Date().toISOString();

          if (existingIndex >= 0) {
            const existing = nextCommands[existingIndex];
            existing.count = Number.isSafeInteger(existing.count) && existing.count >= 0 ? existing.count + 1 : 1;
            existing.lastUsed = now;
          } else {
            nextCommands.unshift({ command: safeCommand, count: 1, firstUsed: now, lastUsed: now });
          }

          nextCommands.sort((left, right) => right.count - left.count);
          return nextCommands.slice(0, this.config.maxHistoryItems);
        }
      });
    }

    await this.storage.mutatePersistedBatch(mutations);
  }

  /**
   * Analyze and record command patterns
   * @param {string} command - The command that was executed
   */
  async analyzeCommand(command) {
    if (typeof command !== 'string') {
      throw new Error('command must be a string');
    }
    assertTextLength(command, 'command');

    await this.ensureInitialized();
    const safeCommand = redactSensitiveData(command);
    await this.storage.recordCommandUsage(safeCommand, this.config.maxHistoryItems);
  }

  /**
   * Record user preference update
   * @param {string} preferenceKey - The preference key
   * @param {*} value - The preference value
   */
  async recordPreference(preferenceKey, value) {
    if (typeof preferenceKey !== 'string' || preferenceKey.trim() === '') {
      throw new Error('preferenceKey must be a non-empty string');
    }
    assertTextLength(preferenceKey, 'preferenceKey', INPUT_LIMITS.maxProjectNameLength);
    assertDataWithinLimits(value, 'stored value', INPUT_LIMITS.maxStoredValueBytes);

    parseDotPath(`userPreferences.${preferenceKey}`);
    await this.ensureInitialized();
    
    this.storage.set(`userPreferences.${preferenceKey}`, redactSensitiveData(value));
    await this.storage.save();
  }

  async recordCollectedPreference(preferenceKey, value) {
    if (!this.config.trackPreferences || value === undefined || value === null || value === '') return;
    await this.recordPreference(preferenceKey, value);
  }

  async recordCollectedAgentPreset(agentPreset) {
    if (!this.config.trackPreferences || typeof agentPreset !== 'string' || agentPreset.trim() === '') return;
    await this.ensureInitialized();
    const agents = this.storage.get('userPreferences.preferredAgents') || [];
    if (agents.includes(agentPreset)) return;
    await this.recordPreference('preferredAgents', [...agents, agentPreset].slice(-this.config.maxHistoryItems));
  }

  /**
   * Record active project context
   * @param {Object} projectInfo - Project information
   */
  async recordProjectContext(projectInfo) {
    if (!projectInfo || typeof projectInfo !== 'object' || Array.isArray(projectInfo)) {
      throw new Error('projectInfo must be an object');
    }

    if (typeof projectInfo.path !== 'string' || projectInfo.path.trim() === '') {
      throw new Error('projectInfo.path must be a non-empty string');
    }
    assertTextLength(projectInfo.path, 'projectInfo.path', INPUT_LIMITS.maxProjectPathLength);

    if (projectInfo.name !== undefined && typeof projectInfo.name !== 'string') {
      throw new Error('projectInfo.name must be a string');
    }
    if (projectInfo.name !== undefined) {
      assertTextLength(projectInfo.name, 'projectInfo.name', INPUT_LIMITS.maxProjectNameLength);
    }

    if (projectInfo.tags !== undefined && (!Array.isArray(projectInfo.tags) || projectInfo.tags.some((tag) => typeof tag !== 'string'))) {
      throw new Error('projectInfo.tags must be an array of strings');
    }
    if (projectInfo.tags !== undefined) {
      if (projectInfo.tags.length > INPUT_LIMITS.maxTags) {
        throw new Error(`projectInfo.tags must not contain more than ${INPUT_LIMITS.maxTags} items`);
      }
      projectInfo.tags.forEach((tag) => assertTextLength(tag, 'projectInfo.tag', INPUT_LIMITS.maxTagLength));
    }

    await this.ensureInitialized();
    
    const safeProjectInfo = redactSensitiveData(projectInfo);
    safeProjectInfo.path = redactProjectPath(safeProjectInfo.path);

    await this.storage.addProject({
      path: safeProjectInfo.path,
      name: safeProjectInfo.name || path.basename(safeProjectInfo.path),
      tags: safeProjectInfo.tags || []
    });
  }

  /**
   * Record session topic or task
   * @param {string} type - 'topic' or 'task'
   * @param {string} content - The topic or task content
   */
  async recordSessionItem(type, content) {
    if (type !== 'topic' && type !== 'task') {
      throw new Error('session item type must be topic or task');
    }

    if (typeof content !== 'string') {
      throw new Error('session item content must be a string');
    }
    assertTextLength(content, 'session item content');

    await this.ensureInitialized();
    
    const path = type === 'topic' 
      ? 'sessionHistory.recentTopics'
      : 'sessionHistory.frequentTasks';
    
    await this.storage.appendToArray(path, {
      content: redactSensitiveData(content),
      timestamp: new Date().toISOString()
    }, this.config.maxHistoryItems, 'content');
  }

  /**
   * Remove one exact entry from locally stored memory.
   * @param {'preference'|'topic'|'task'|'project'} category - Memory category
   * @param {{key?: string, value?: string, path?: string}} selector - Exact entry selector
   * @returns {Promise<{category: string, removed: boolean}>}
   */
  async forgetMemoryItem(category, selector) {
    if (!this.config.allowClearMemory) {
      throw new Error('Memory clearing is disabled in configuration');
    }
    if (!['preference', 'topic', 'task', 'project'].includes(category)) {
      throw new Error('memory category must be preference, topic, task, or project');
    }
    if (!selector || typeof selector !== 'object' || Array.isArray(selector)) {
      throw new Error('memory selector must be an object');
    }

    const selectorKeys = Object.keys(selector);
    const expectedKey = category === 'preference' ? 'key' : category === 'project' ? 'path' : 'value';
    if (selectorKeys.length !== 1 || selectorKeys[0] !== expectedKey
      || typeof selector[expectedKey] !== 'string' || selector[expectedKey].trim() === '') {
      throw new Error(`memory ${category} selector must contain one non-empty ${expectedKey}`);
    }

    const rawValue = selector[expectedKey];
    const limit = category === 'project' ? INPUT_LIMITS.maxProjectPathLength
      : category === 'preference' ? INPUT_LIMITS.maxProjectNameLength
        : undefined;
    assertTextLength(rawValue, `memory ${category} selector`, limit);
    await this.ensureInitialized();

    let dotPath;
    let matches;
    let mutate;
    let removed = false;
    if (category === 'preference') {
      const preferencePath = parseDotPath(`userPreferences.${rawValue}`);
      const preferenceKeys = preferencePath.slice(1);
      dotPath = 'userPreferences';
      matches = (preferences) => {
        let current = preferences;
        for (const key of preferenceKeys) {
          if (!current || typeof current !== 'object' || !Object.prototype.hasOwnProperty.call(current, key)) return false;
          current = current[key];
        }
        return true;
      };
      mutate = (preferences) => {
        let current = preferences;
        for (const key of preferenceKeys.slice(0, -1)) {
          if (!current || typeof current !== 'object' || !Object.prototype.hasOwnProperty.call(current, key)) return preferences;
          current = current[key];
        }
        if (current && typeof current === 'object' && Object.prototype.hasOwnProperty.call(current, preferenceKeys.at(-1))) {
          delete current[preferenceKeys.at(-1)];
          removed = true;
        }
        return preferences;
      };
    } else {
      dotPath = category === 'project'
        ? 'projectContext.activeProjects'
        : category === 'topic'
          ? 'sessionHistory.recentTopics'
          : 'sessionHistory.frequentTasks';
      const safeValue = category === 'project'
        ? redactProjectPath(redactSensitiveData(rawValue))
        : redactSensitiveData(rawValue);
      const field = category === 'project' ? 'path' : 'content';
      matches = (items) => Array.isArray(items) && items.some((item) => item?.[field] === safeValue);
      mutate = (items) => {
        if (!Array.isArray(items)) return [];
        const matchIndex = items.findIndex((item) => item?.[field] === safeValue);
        if (matchIndex < 0) return items;
        removed = true;
        return [...items.slice(0, matchIndex), ...items.slice(matchIndex + 1)];
      };
    }

    let backupCreated = false;
    await this.storage.mutatePersisted(dotPath, mutate, {
      maxArrayLength: category === 'preference' ? undefined : this.config.maxHistoryItems,
      beforeMutate: async (current, snapshot) => {
        if (!matches(current)) return;
        await this.lifecycle.writeSnapshot(snapshot, 'forget-item-safety');
        backupCreated = true;
      }
    });
    if (backupCreated) await this.lifecycle.applyRetention();
    return { category, removed };
  }

  /**
   * Get recommendations based on memory data
   * @param {string} context - Current context for recommendations
   * @returns {Object} Recommendations object
   */
  getRecommendations(context) {
    this.recommendationMetrics.requests += 1;

    if (!this.config.enableRecommendations) {
      return { available: false };
    }

    this.recommendationMetrics.availableRequests += 1;

    const recommendations = {
      available: true,
      suggestions: []
    };

    if (!this.storage.memory) return recommendations;

    const feedbackEntries = this.storage.get('metadata.recommendationFeedback') || [];

    // Recommend preferred agents
    const preferredAgents = (this.storage.get('userPreferences.preferredAgents') || [])
      .filter(isNonEmptyString);
    const rankedAgents = rankByContext(preferredAgents, false, [], (agent) => agent, () => 0,
      (agent) => feedbackFor(feedbackEntries, 'agent', agent).score);
    if (rankedAgents.length > 0) {
      recommendations.suggestions.push({
        type: 'agent',
        items: rankedAgents.slice(0, 3).map(({ item }) => item),
        reason: 'Based on your usage history',
        explanation: explanation('userPreferences.preferredAgents', false, rankedAgents)
      });
    }

    // Recommend default model
    const defaultModel = this.storage.get('userPreferences.defaultModel');
    if (isNonEmptyString(defaultModel)) {
      recommendations.suggestions.push({
        type: 'model',
        items: [defaultModel],
        reason: 'Your preferred model',
        explanation: {
          ...explanation('userPreferences.defaultModel'),
          feedbackScore: feedbackFor(feedbackEntries, 'model', defaultModel).score,
          confidence: 'high'
        }
      });
    }

    const hasContext = typeof context === 'string' && context.trim().length > 0;
    const contextTokens = tokenizeContext(context);
    if (hasContext) this.recommendationMetrics.contextualRequests += 1;

    // Recommend common commands that have reached the recognition threshold
    const commonCommands = this.storage.get('inputHabits.commonCommands') || [];
    const frequentCommands = commonCommands.filter((command) => (
      isRecommendationCommand(command) && command.count >= this.config.patternRecognitionThreshold
    ));
    const rankedCommands = rankByContext(frequentCommands, hasContext, contextTokens,
      (command) => command.command, (command) => command.count,
      (command) => feedbackFor(feedbackEntries, 'commands', command.command).score);
    if (rankedCommands.length > 0) {
      recommendations.suggestions.push({
        type: 'commands',
        items: rankedCommands.slice(0, 5).map(({ item }) => item.command),
        reason: hasContext ? 'Matches the requested context and usage history' : 'Frequently used commands',
        explanation: explanation('inputHabits.commonCommands', hasContext, rankedCommands)
      });
    }

    // Recommend projects
    const activeProjects = (this.storage.get('projectContext.activeProjects') || [])
      .filter(isRecommendationProject);
    const rankedProjects = rankByContext(activeProjects, hasContext, contextTokens,
      (project) => [project.name, project.path, ...(Array.isArray(project.tags) ? project.tags : [])].join(' '),
      (project) => Date.parse(project.lastAccessed) || 0,
      (project) => feedbackFor(feedbackEntries, 'projects', project.name || project.path).score);
    if (rankedProjects.length > 0) {
      recommendations.suggestions.push({
        type: 'projects',
        items: rankedProjects.slice(0, 3).map(({ item }) => item.name || item.path),
        reason: hasContext ? 'Matches the requested context and recent activity' : 'Recently accessed projects',
        explanation: explanation('projectContext.activeProjects', hasContext, rankedProjects)
      });
    }

    if (hasContext) {
      const hasContextMatch = rankedCommands.length > 0 || rankedProjects.length > 0;
      const hasFallbackCandidate = !hasContextMatch && (
        frequentCommands.length > 0 || activeProjects.length > 0
      );
      if (hasContextMatch) this.recommendationMetrics.contextMatches += 1;
      else if (hasFallbackCandidate) this.recommendationMetrics.fallbackRequests += 1;
    }

    this.recommendationMetrics.suggestions += recommendations.suggestions.length;

    return recommendations;
  }

  /** Record local feedback for a returned recommendation item. */
  async recordRecommendationFeedback(type, item, outcome) {
    if (!RECOMMENDATION_FEEDBACK_TYPES.has(type)) {
      throw new Error('type must be a supported recommendation type');
    }
    if (!isNonEmptyString(item)) throw new Error('item must be a non-empty string');
    assertTextLength(item, 'recommendation item');
    if (!RECOMMENDATION_FEEDBACK_OUTCOMES.has(outcome)) {
      throw new Error('outcome must be helpful or not_helpful');
    }

    await this.ensureInitialized();
    let recorded;
    await this.storage.mutatePersisted('metadata.recommendationFeedback', (current) => {
      const entries = Array.isArray(current) ? current.filter((entry) => entry && typeof entry === 'object') : [];
      const previous = feedbackFor(entries, type, item);
      recorded = {
        type,
        item,
        helpful: previous.helpful + (outcome === 'helpful' ? 1 : 0),
        notHelpful: previous.notHelpful + (outcome === 'not_helpful' ? 1 : 0),
        updatedAt: new Date().toISOString()
      };
      return trimArrayToLimits(
        [recorded, ...entries.filter((entry) => entry.type !== type || entry.item !== item)],
        this.config.maxHistoryItems,
        INPUT_LIMITS.maxStoredValueBytes
      );
    }, { maxArrayLength: this.config.maxHistoryItems, maxArrayBytes: INPUT_LIMITS.maxStoredValueBytes });
    return { ...recorded, score: recorded.helpful - recorded.notHelpful };
  }

  /**
   * Get privacy-safe recommendation quality metrics for the current process.
   * @returns {Object} Recommendation request, coverage, and fallback metrics
   */
  getRecommendationMetrics() {
    const { contextualRequests } = this.recommendationMetrics;
    return {
      ...this.recommendationMetrics,
      contextMatchRate: contextualRequests > 0
        ? this.recommendationMetrics.contextMatches / contextualRequests
        : null,
      fallbackRate: contextualRequests > 0
        ? this.recommendationMetrics.fallbackRequests / contextualRequests
        : null,
      patternRecognitionThreshold: this.config.patternRecognitionThreshold
    };
  }

  /**
   * Get memory statistics
   * @returns {Object} Statistics
   */
  getStats() {
    if (!this.storage.memory) {
      return {
        totalSessions: 0,
        lastUpdated: null,
        trackedTools: 0,
        activeProjects: 0,
        preferredAgents: 0
      };
    }

    return this.storage.getStats();
  }

  /**
   * Export memory data
   * @returns {Object} Complete memory data
   */
  exportData() {
    if (!this.storage.memory) return cloneData(DEFAULT_MEMORY);

    return this.storage.exportData();
  }

  /**
   * Import memory data
   * @param {Object} data - Memory data to import
   */
  async importData(data) {
    await this.ensureInitialized();
    const safeData = boundImportedHistory(
      redactSensitiveData(data),
      this.config.maxHistoryItems
    );
    await this.lifecycle.backup('import-safety');
    await this.storage.importData(safeData);
  }

  async backup(reason = 'manual') {
    await this.ensureInitialized();
    return this.lifecycle.backup(reason);
  }

  async listBackups() {
    await this.ensureInitialized();
    return this.lifecycle.listBackups();
  }

  async restoreBackup(name) {
    await this.ensureInitialized();
    return this.lifecycle.restoreBackup(name);
  }

  async applyRetention() {
    await this.ensureInitialized();
    return this.lifecycle.applyRetention();
  }

  /**
   * Clear all memory data
   */
  async clearMemory() {
    if (!this.config.allowClearMemory) {
      throw new Error('Memory clearing is disabled in configuration');
    }

    await this.ensureInitialized();
    await this.lifecycle.backup('clear-safety');
    await this.storage.clear();
  }

  /**
   * Cleanup resources
   */
  async dispose() {
    if (this._initializePromise) {
      await this._initializePromise.catch(() => {});
    }
    this.stopAutoSave();
    if (this.storage.memory) {
      await this.storage.save();
      await this.storage.flush();
    }
  }
}

module.exports = { MemoryManager };
