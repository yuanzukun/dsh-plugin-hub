/**
 * Tests for storage.js
 */

const fs = require('fs').promises;
const path = require('path');
const { MemoryStorage, DEFAULT_MEMORY } = require('../storage');

describe('MemoryStorage', () => {
  let storage;
  let testDir;
  let testFile;

  beforeEach(async () => {
    // Create temporary directory for tests
    testDir = await fs.mkdtemp(path.join(require('os').tmpdir(), 'memory-test-'));
    testFile = path.join(testDir, 'test-memory.json');
    storage = new MemoryStorage(testFile);
  });

  afterEach(async () => {
    // Cleanup
    try {
      await fs.rm(testDir, { recursive: true, force: true });
    } catch (error) {
      // Ignore cleanup errors
    }
  });

  describe('Initialization', () => {
    test('should create new file with defaults when file does not exist', async () => {
      await storage.initialize();
      
      const content = await fs.readFile(testFile, 'utf-8');
      const data = JSON.parse(content);
      
      expect(data.version).toBe('1.1.0');
      expect(data.metadata.createdAt).toBeDefined();
      expect(data.userPreferences).toBeDefined();
    });

    test('should keep defaults in memory without persisting when requested', async () => {
      await storage.initialize({ persistIfMissing: false });

      expect(storage.get('version')).toBe('1.1.0');
      await expect(fs.access(testFile)).rejects.toThrow();
    });

    test('should load existing file', async () => {
      // Create a test file
      const testData = { ...DEFAULT_MEMORY, customField: 'test' };
      await fs.writeFile(testFile, JSON.stringify(testData));
      
      await storage.initialize();
      
      const value = storage.get('customField');
      expect(value).toBe('test');
    });

    test('should load legacy data and persist the migrated version', async () => {
      await fs.writeFile(testFile, JSON.stringify({
        version: '1.0.0',
        metadata: { createdAt: '2026-01-01T00:00:00.000Z' },
        userPreferences: { defaultModel: 'legacy-model' }
      }));

      await storage.initialize();

      expect(storage.get('version')).toBe('1.1.0');
      expect(storage.get('metadata.schemaVersion')).toBe(2);
      expect(JSON.parse(await fs.readFile(testFile, 'utf8')).version).toBe('1.1.0');
    });

    test('should not replace the source when migration rejects the document', async () => {
      const original = JSON.stringify({ version: '9.0.0', metadata: {} });
      await fs.writeFile(testFile, original);

      await expect(storage.initialize()).rejects.toThrow('Unsupported memory data version');
      expect(await fs.readFile(testFile, 'utf8')).toBe(original);
    });

    test('should initialize concurrent callers only once', async () => {
      await Promise.all([storage.initialize(), storage.initialize()]);

      expect(storage.get('metadata.totalSessions')).toBe(0);
      expect(await fs.readFile(testFile, 'utf-8')).toContain('"version"');
    });

    test('should create parent directories for nested storage paths', async () => {
      const nestedFile = path.join(testDir, 'nested', 'memory', 'test.json');
      const nestedStorage = new MemoryStorage(nestedFile);

      await nestedStorage.initialize();

      expect(await fs.readFile(nestedFile, 'utf-8')).toContain('"version"');
    });

    test('should fill missing fields when loading partial data', async () => {
      await fs.writeFile(testFile, JSON.stringify({
        version: '1.0.0',
        metadata: { createdAt: new Date().toISOString() },
        userPreferences: { imported: true }
      }));

      await storage.initialize();

      expect(storage.get('sessionHistory.toolUsageStats')).toEqual({});
      expect(storage.get('projectContext.activeProjects')).toEqual([]);
    });
  });

  describe('Get and Set', () => {
    beforeEach(async () => {
      await storage.initialize();
    });

    test('should get value by dot path', () => {
      storage.set('userPreferences.defaultModel', 'qwen3.7-plus');
      const value = storage.get('userPreferences.defaultModel');
      expect(value).toBe('qwen3.7-plus');
    });

    test('should return undefined for non-existent path', () => {
      const value = storage.get('nonexistent.path');
      expect(value).toBeUndefined();
    });

    test('should set nested values', () => {
      storage.set('userPreferences.customSettings.theme', 'dark');
      const theme = storage.get('userPreferences.customSettings.theme');
      expect(theme).toBe('dark');
    });

    test('should reject prototype pollution paths', () => {
      expect(() => storage.set('__proto__.polluted', 'yes')).toThrow('Unsafe storage path');
      expect(() => storage.get('constructor.prototype')).toThrow('Unsafe storage path');
      expect({}).not.toHaveProperty('polluted');
    });

    test('should reject nested writes through null intermediate values', () => {
      storage.set('userPreferences.defaultModel', null);

      expect(() => storage.set('userPreferences.defaultModel.detail', 'value'))
        .toThrow('Cannot set nested storage path: userPreferences.defaultModel.detail');
    });

    test('should mark as dirty when setting values', () => {
      expect(storage.isDirty).toBe(false);
      storage.set('userPreferences.language', 'zh-CN');
      expect(storage.isDirty).toBe(true);
    });
  });

  describe('Save and Load', () => {
    beforeEach(async () => {
      await storage.initialize();
    });

    test('should save data to file', async () => {
      storage.set('userPreferences.defaultModel', 'test-model');
      await storage.save();
      
      const content = await fs.readFile(testFile, 'utf-8');
      const data = JSON.parse(content);
      
      expect(data.userPreferences.defaultModel).toBe('test-model');
    });

    test('should not save if not dirty', async () => {
      await storage.save();
      const isDirty = storage.isDirty;
      expect(isDirty).toBe(false);
    });

    test('should update lastUpdated timestamp on save', async () => {
      const before = storage.get('lastUpdated');
      storage.set('userPreferences.test', 'value');
      await storage.save();
      const after = storage.get('lastUpdated');
      
      expect(after).toBeDefined();
      if (before) {
        expect(new Date(after).getTime()).toBeGreaterThan(new Date(before).getTime());
      }
    });

    test('should serialize concurrent saves without losing the file', async () => {
      storage.set('userPreferences.defaultModel', 'concurrent-model');

      await Promise.all([storage.save(), storage.save(), storage.save()]);

      const reloaded = new MemoryStorage(testFile);
      await reloaded.initialize();
      expect(reloaded.get('userPreferences.defaultModel')).toBe('concurrent-model');
    });

    test('should retry a transient Windows lock while replacing a snapshot', async () => {
      storage.set('userPreferences.defaultModel', 'retry-model');
      const originalPlatform = Object.getOwnPropertyDescriptor(process, 'platform');
      const privateModeSpy = jest.spyOn(storage, 'setPrivateFileMode').mockResolvedValue();
      const renameSpy = jest.spyOn(fs, 'rename');
      const transientError = Object.assign(new Error('file is temporarily locked'), { code: 'EPERM' });
      renameSpy.mockRejectedValueOnce(transientError);
      Object.defineProperty(process, 'platform', { value: 'win32' });

      try {
        await expect(storage.save()).resolves.toBeUndefined();
        expect(renameSpy).toHaveBeenCalledTimes(2);
      } finally {
        Object.defineProperty(process, 'platform', originalPlatform);
        renameSpy.mockRestore();
        privateModeSpy.mockRestore();
      }

      expect(await fs.readFile(testFile, 'utf8')).toContain('retry-model');
    });

    test('should recover from a stale lock and leave no lock file', async () => {
      const lockPath = `${testFile}.lock`;
      await fs.writeFile(lockPath, 'stale');
      const staleDate = new Date(Date.now() - 60000);
      await fs.utimes(lockPath, staleDate, staleDate);

      storage.set('userPreferences.defaultModel', 'stale-lock-recovered');
      await storage.save();

      expect(await fs.readFile(testFile, 'utf8')).toContain('stale-lock-recovered');
      await expect(fs.access(lockPath)).rejects.toThrow();
    });

    test('should start a heartbeat while a storage lock is held', async () => {
      const setIntervalSpy = jest.spyOn(global, 'setInterval');

      try {
        const ownerToken = await storage.acquireLock();
        expect(setIntervalSpy).toHaveBeenCalled();
        expect((await fs.stat(`${testFile}.lock`)).isDirectory()).toBe(true);
        await storage.releaseLock(ownerToken);
      } finally {
        setIntervalSpy.mockRestore();
      }
    });

    test('should remove a newly created lock directory when writing its metadata fails', async () => {
      const originalWriteFile = fs.writeFile.bind(fs);
      const writeFileSpy = jest.spyOn(fs, 'writeFile').mockImplementationOnce(async (...args) => {
        if (args[0] === storage.lockMetadataPath) {
          throw Object.assign(new Error('metadata write failed'), { code: 'EACCES' });
        }
        return originalWriteFile(...args);
      });

      try {
        await expect(storage.acquireLock()).rejects.toMatchObject({ code: 'EACCES' });
      } finally {
        writeFileSpy.mockRestore();
      }

      await expect(fs.access(`${testFile}.lock`)).rejects.toThrow();
    });

    test('should not remove a lock that changed owners during release', async () => {
      const lockPath = `${testFile}.lock`;
      const ownerToken = await storage.acquireLock();
      const originalReadFile = fs.readFile.bind(fs);
      const readFileSpy = jest.spyOn(fs, 'readFile').mockImplementationOnce(async (...args) => {
        const content = await originalReadFile(...args);
        await fs.rm(lockPath, { recursive: true, force: true });
        await fs.mkdir(lockPath);
        await fs.writeFile(path.join(lockPath, 'owner.json'), JSON.stringify({ ownerToken: 'new-owner' }), 'utf8');
        return content;
      });

      try {
        await storage.releaseLock(ownerToken);
      } finally {
        readFileSpy.mockRestore();
      }

      expect(JSON.parse(await fs.readFile(path.join(lockPath, 'owner.json'), 'utf8')).ownerToken).toBe('new-owner');
      await fs.rm(lockPath, { recursive: true, force: true });
    });

    test('should only release a lock when the owner token matches', async () => {
      const lockPath = `${testFile}.lock`;
      const ownerToken = await storage.acquireLock();

      await storage.releaseLock('different-owner');
      await expect(fs.access(lockPath)).resolves.toBeUndefined();

      await storage.releaseLock(ownerToken);
      await expect(fs.access(lockPath)).rejects.toThrow();
    });

    test('should expose a flush operation for queued saves', async () => {
      storage.set('userPreferences.defaultModel', 'flushed-model');
      await storage.save();
      await storage.flush();

      const reloaded = new MemoryStorage(testFile);
      await reloaded.initialize();
      expect(reloaded.get('userPreferences.defaultModel')).toBe('flushed-model');
    });

    test('should serialize saves from separate storage instances into valid JSON', async () => {
      const first = new MemoryStorage(testFile);
      const second = new MemoryStorage(testFile);
      await Promise.all([first.initialize(), second.initialize()]);

      first.set('userPreferences.first', 'one');
      second.set('userPreferences.second', 'two');
      await Promise.all([first.save(), second.save()]);

      const content = await fs.readFile(testFile, 'utf8');
      expect(() => JSON.parse(content)).not.toThrow();
      const data = JSON.parse(content);
      expect(data.userPreferences.first).toBe('one');
      expect(data.userPreferences.second).toBe('two');
      await expect(fs.access(`${testFile}.lock`)).rejects.toThrow();
    });

    test('should accumulate concurrent counter increments from separate storage instances', async () => {
      const first = new MemoryStorage(testFile);
      const second = new MemoryStorage(testFile);
      await Promise.all([first.initialize(), second.initialize()]);

      await Promise.all([
        first.recordToolUsage('read'),
        second.recordToolUsage('read')
      ]);

      const reloaded = new MemoryStorage(testFile);
      await reloaded.initialize();
      expect(reloaded.get('sessionHistory.toolUsageStats')).toEqual({ read: 2 });
    });

    test('should preserve concurrent array appends from separate storage instances', async () => {
      const first = new MemoryStorage(testFile);
      const second = new MemoryStorage(testFile);
      await Promise.all([first.initialize(), second.initialize()]);

      await Promise.all([
        first.appendToArray('sessionHistory.recentTopics', { content: 'first' }, 10),
        second.appendToArray('sessionHistory.recentTopics', { content: 'second' }, 10)
      ]);

      const reloaded = new MemoryStorage(testFile);
      await reloaded.initialize();
      expect(reloaded.get('sessionHistory.recentTopics').map((entry) => entry.content).sort())
        .toEqual(['first', 'second']);
    });

    test('should preserve concurrent project additions from separate storage instances', async () => {
      const first = new MemoryStorage(testFile);
      const second = new MemoryStorage(testFile);
      await Promise.all([first.initialize(), second.initialize()]);

      await Promise.all([
        first.addProject({ path: '/first', name: 'First' }),
        second.addProject({ path: '/second', name: 'Second' })
      ]);

      const reloaded = new MemoryStorage(testFile);
      await reloaded.initialize();
      expect(reloaded.get('projectContext.activeProjects').map((project) => project.path).sort())
        .toEqual(['/first', '/second']);
    });

    test('should restrict persisted file permissions on supported platforms', async () => {
      if (process.platform === 'win32') return;

      const mode = (await fs.stat(testFile)).mode & 0o777;
      expect(mode).toBe(0o600);
    });
  });

  describe('Array Operations', () => {
    beforeEach(async () => {
      await storage.initialize();
    });

    test('should append to array', async () => {
      await storage.appendToArray('inputHabits.preferredTools', 'read');
      await storage.appendToArray('inputHabits.preferredTools', 'write');
      
      const tools = storage.get('inputHabits.preferredTools');
      expect(tools).toEqual(['write', 'read']);
    });

    test('should respect max length', async () => {
      for (let i = 1; i <= 5; i++) {
        await storage.appendToArray('sessionHistory.recentTopics', `topic-${i}`, 3);
      }
      
      const topics = storage.get('sessionHistory.recentTopics');
      expect(topics.length).toBe(3);
      expect(topics[0]).toBe('topic-5');
    });

    test('should trim long history arrays to the stored value byte limit', async () => {
      const longContent = 'x'.repeat(10000);

      for (let index = 0; index < 30; index += 1) {
        await storage.appendToArray(
          'sessionHistory.recentTopics',
          { content: `${index}-${longContent}` },
          10000,
          'content'
        );
      }

      const topics = storage.get('sessionHistory.recentTopics');
      expect(topics.length).toBeLessThan(30);
      expect(Buffer.byteLength(JSON.stringify(topics), 'utf8')).toBeLessThanOrEqual(256 * 1024);
      expect(topics[0].content).toContain('29-');
    });
  });

  describe('Tool Usage Tracking', () => {
    beforeEach(async () => {
      await storage.initialize();
    });

    test('should record tool usage', async () => {
      await storage.recordToolUsage('read');
      await storage.recordToolUsage('read');
      await storage.recordToolUsage('write');
      
      const stats = storage.get('sessionHistory.toolUsageStats');
      expect(stats.read).toBe(2);
      expect(stats.write).toBe(1);
    });
  });

  describe('Project Management', () => {
    beforeEach(async () => {
      await storage.initialize();
    });

    test('should add new project', async () => {
      await storage.addProject({
        path: '/test/project',
        name: 'Test Project',
        tags: ['test']
      });
      
      const projects = storage.get('projectContext.activeProjects');
      expect(projects.length).toBe(1);
      expect(projects[0].name).toBe('Test Project');
    });

    test('should update existing project', async () => {
      await storage.addProject({
        path: '/test/project',
        name: 'Test Project'
      });
      
      await storage.addProject({
        path: '/test/project',
        name: 'Updated Project',
        tags: ['updated']
      });
      
      const projects = storage.get('projectContext.activeProjects');
      expect(projects.length).toBe(1);
      expect(projects[0].name).toBe('Updated Project');
      expect(projects[0].tags).toEqual(['updated']);
    });
  });

  describe('Clear and Export', () => {
    beforeEach(async () => {
      await storage.initialize();
    });

    test('should clear all data', async () => {
      storage.set('userPreferences.test', 'value');
      await storage.clear();
      
      const prefs = storage.get('userPreferences.test');
      expect(prefs).toBeUndefined();
    });

    test('should persist cleared data and isolate default nested objects', async () => {
      storage.set('userPreferences.preferredAgents', ['agent']);
      await storage.clear();

      const reloaded = new MemoryStorage(testFile);
      await reloaded.initialize();
      expect(reloaded.get('userPreferences.preferredAgents')).toEqual([]);

      reloaded.get('userPreferences.preferredAgents').push('mutated');
      expect(reloaded.get('userPreferences.preferredAgents')).toEqual([]);
    });

    test('should export data', async () => {
      storage.set('userPreferences.test', 'value');
      const data = storage.exportData();
      
      expect(data.userPreferences.test).toBe('value');
      expect(data.version).toBe('1.1.0');
    });

    test('should deep clone exported and imported data', async () => {
      storage.set('userPreferences.customSettings', { nested: { enabled: true } });
      const exported = storage.exportData();
      exported.userPreferences.customSettings.nested.enabled = false;
      expect(storage.get('userPreferences.customSettings.nested.enabled')).toBe(true);

      const imported = {
        version: '1.0.0',
        metadata: { createdAt: new Date().toISOString() },
        userPreferences: { customSettings: { nested: { enabled: true } } }
      };
      await storage.importData(imported);
      imported.userPreferences.customSettings.nested.enabled = false;
      expect(storage.get('userPreferences.customSettings.nested.enabled')).toBe(true);
    });

    test('should import data', async () => {
      const importData = {
        version: '1.0.0',
        metadata: { createdAt: new Date().toISOString() },
        userPreferences: { imported: true }
      };
      
      await storage.importData(importData);
      const value = storage.get('userPreferences.imported');
      expect(value).toBe(true);
    });

    test('should reject invalid import data', async () => {
      const invalidData = { noVersion: true };
      
      await expect(storage.importData(invalidData)).rejects.toThrow('Invalid memory data format');
    });

    test('should reject oversized stored values', () => {
      expect(() => storage.set('userPreferences.largeValue', 'x'.repeat(256 * 1024 + 1)))
        .toThrow('stored value must not exceed');
    });

    test('should reject excessively deep stored values', () => {
      let value = 'leaf';
      for (let index = 0; index < 9; index += 1) value = { nested: value };

      expect(() => storage.set('userPreferences.deepValue', value))
        .toThrow('stored value must not exceed 8 levels');
    });

    test('runs beforeMutate against the persisted pre-mutation snapshot', async () => {
      storage.set('userPreferences.defaultModel', 'before-mutation');
      await storage.save();
      const snapshots = [];

      await storage.mutatePersisted('userPreferences.defaultModel', () => 'after-mutation', {
        beforeMutate: async (current, snapshot) => {
          snapshots.push({ current, model: snapshot.userPreferences.defaultModel });
        }
      });

      expect(snapshots).toEqual([{ current: 'before-mutation', model: 'before-mutation' }]);
      expect(storage.get('userPreferences.defaultModel')).toBe('after-mutation');
    });
  });

  describe('Statistics', () => {
    beforeEach(async () => {
      await storage.initialize();
    });

    test('should get stats', () => {
      const stats = storage.getStats();
      
      expect(stats.totalSessions).toBe(0);
      expect(stats.trackedTools).toBe(0);
      expect(stats.activeProjects).toBe(0);
    });

    test('should reflect data in stats', async () => {
      await storage.recordToolUsage('read');
      await storage.addProject({ path: '/test', name: 'Test' });
      
      const stats = storage.getStats();
      expect(stats.trackedTools).toBe(1);
      expect(stats.activeProjects).toBe(1);
    });
  });
});
