/**
 * Interactive DeepSeek Harness front door, visually aligned with the local
 * OMP 17.2.15 Catppuccin layout while retaining dsh-native agent, session,
 * command, and persistence contracts.
 * @module dsh-omp-tui
 */

import { readFile } from 'node:fs/promises'
import { basename, isAbsolute, join, resolve } from 'node:path'
import { Service, type Context } from './dsh-host/index.ts'
import {
  Container,
  Editor,
  ProcessTerminal,
  Spacer,
  TUI,
  Text,
  matchesKey,
  truncateToWidth,
  visibleWidth,
  type Component,
  type EditorTheme,
  type SelectItem,
  type TerminalColorScheme,
} from '@earendil-works/pi-tui'
import type { Agent, AgentHandle, AgentStatus, ModelSelection, ModelSelectionRef } from './dsh-host/index.ts'
import { installModelSelection } from './dsh-host/index.ts'
import { CombinedAutocompleteProvider, type AutocompleteItem, type SlashCommand } from '@earendil-works/pi-tui'
import { createUserMessage, errorChain, type ToolCallId, type LlmConfigurableProvider, type LlmReasoningEffortInfo } from './dsh-host/index.ts'
import { SessionId, type Session, type SessionEvent } from './dsh-host/index.ts'
import { foldSessionTitle } from './dsh-host/index.ts'
import { parseSessionReferenceText } from './dsh-host/index.ts'
import { renderSkillContent } from './dsh-host/index.ts'
// Type-only imports pull in the declaration merges that expose `ctx.commands`,
// `ctx.tokenMeter`, `ctx.llm`, `ctx.userQuestions`, `ctx.sessionQuery`,
// `ctx.agentDefaultModel`, `ctx.skills`, `ctx.sessionReferenceResolver`, and
// `ctx.permissionPresets` on the cordis Context, plus the goal/compaction/skill
// session-event extensions.
import { settingsNamespace, type SettingsNamespace } from './dsh-host/index.ts'
import { PERMISSION_SETTINGS_NAMESPACE } from './dsh-host/index.ts'
// Declaration merges: `ctx.agentPresets` and the `agent-preset/selected`
// session event, plus the runtime preset resolver for resumed sessions.
import { resolveSessionPreset } from './dsh-host/index.ts'
import {
  DEFAULT_LEFT_PROMPT,
  DEFAULT_RIGHT_PROMPT,
  TuiConfigSchema,
  resolveTuiConfig,
  type Config,
  type ResolvedTuiConfig,
  type UiMode,
} from './config.ts'
import type { TuiStartup } from './startup.ts'
import { parseTuiPromptTemplate } from './prompt.ts'
import { createTranslator, type MessageKey, type Translator } from './i18n.ts'
import {
  FULL_ACCESS_REGISTRY_NAME,
  FULL_ACCESS_UI_NAME,
  displayPermissionName,
  permissionCommandMetadata,
  registryPermissionName,
} from './permission.ts'
import { SkillAwareAutocompleteProvider } from './autocomplete.ts'
import {
  BUILTIN_THEMES,
  COLOR_ROLES,
  createPalette,
  detectTruecolor,
  findTheme,
  markdownTheme,
  renderPalette,
  selectTheme,
  type Palette,
  type ThemeCustom,
  type ThemeMode,
  type ThemeOverride,
} from './theme.ts'
import {
  SESSION_TITLE_SETTINGS_NAMESPACE,
  TUI_SETTINGS_NAMESPACE,
  TuiSettingsSchema,
} from './settings.ts'
import {
  ContextCardComponent,
  HeaderComponent,
  StaticCardComponent,
  SubagentPanelComponent,
  TranscriptFoldNoticeComponent,
  TranscriptViewport,
  AssistantStreamController,
  TodoPanelComponent,
  ToolCardComponent,
  UserMessageComponent,
  type ToolCardVisibility,
} from './components/transcript.ts'
import {
  CommandHintComponent,
  ComposerDirectoryComponent,
  ComposerFooterComponent,
  InputBorderComponent,
  formatContextTokens,
  chooseReasoningEffort,
  resolveSessionModelSelection,
} from './components/status.ts'
import {
  InputDialog,
  SelectDialog,
  runInlineQuestionFlow,
  runModelFlow,
  showOverlay,
  pushOverlay,
} from './components/dialogs.ts'
import { ModelListDialog } from './components/model-list-dialog.ts'
import {
  parseReasoningEffortSetting,
  type ReasoningEffortSetting,
} from './reasoning-maps.ts'
import { SettingsScreen, cycleValue, type SettingsTab } from './components/settings-screen.ts'
import {
  ProviderForm,
  type DiscoveredModel,
  type ProviderDraft,
  type ProviderModelDraft,
} from './components/provider-form.ts'
import { contentText } from './components/content.ts'
import { displayInlineText, displayText } from './components/text.ts'
import { filterProjectSessions, sameProject } from './session-filter.ts'
import { hasConversationData, recordConversationPreset } from './session-lifecycle.ts'
import type { BridgeConfig, WechatBridge } from './wechat/index.ts'
import { setActiveAgent } from './wechat/dsh/session.ts'
import { setTuiForegroundControl } from './wechat/dsh/tui-control.ts'
import { createExtensionServices, type ExtensionServices, type SettingsField, type SettingsSection } from './extensions/index.ts'
import type { TuiPluginHost } from './host/index.ts'
import { enqueueBootNotice, drainBootNotices } from './boot-notices.ts'
import { upstreamDriftWarnings } from './std-contract.ts'
import { negotiate, parseManifest } from './plugin-spec/index.ts'

export const name = 'tui'

const SPINNER_FRAMES = ['⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏']
const SPINNER_INTERVAL_MS = 80
/** How long to wait for the configured agent to publish before giving up. */
const AGENT_READY_TIMEOUT_MS = 30000
/** Safety cap for a session resume's persistence load and setup phase. */
const RESUME_TIMEOUT_MS = 30_000
/** How many recent sessions to show in the `/resume` picker before title reads. */
const RESUME_PICKER_LIMIT = 50
/** Safety cap for loading title snapshots before showing the `/resume` picker. */
const RESUME_TITLES_TIMEOUT_MS = 5_000
/** Context fallback while exact model metadata is unavailable. */
const DEFAULT_CONTEXT_WINDOW = 1_000_000

/** UI modes map 1:1 to the shipped dsh agent presets (backend compositions). */
const MODE_PRESETS = { standard: 'standard', minimal: 'minimal', code: 'code', cordis: 'cordis' } as const
type UiModeKey = keyof typeof MODE_PRESETS

/** Bare `/mode` cycles through the shipped presets in this order. */
const MODE_ORDER: readonly UiModeKey[] = ['standard', 'minimal', 'code', 'cordis']

/** i18n key for each mode's localized label. */
const MODE_LABEL_KEYS: Record<UiModeKey, MessageKey> = {
  standard: 'modeStandard',
  minimal: 'modeMinimal',
  code: 'modeCode',
  cordis: 'modeCordis',
}



/** Restore a session's recorded backend preset, falling back for blank sessions. */
function modeForSession(session: Session, fallback: string): string {
  return resolveSessionPreset(session) ?? fallback
}

/** The localized label of a preset id, preferring the roster's own name. */
function modeLabel(
  t: Translator,
  mode: string,
  names: ReadonlyMap<string, string>,
): string {
  const rosterName = names.get(mode)
  if (rosterName !== undefined) return rosterName
  return mode in MODE_LABEL_KEYS ? t(MODE_LABEL_KEYS[mode as UiModeKey]) : mode
}

/** Filter preset argument choices while preserving their descriptions. */
function filterCommandOptions(options: readonly AutocompleteItem[], prefix: string): AutocompleteItem[] | null {
  const query = prefix.trim().toLocaleLowerCase()
  const filtered = query === ''
    ? options
    : options.filter(item => `${item.value} ${item.label}`.toLocaleLowerCase().startsWith(query))
  return filtered.length === 0 ? null : [...filtered]
}

/** Show the command's expected argument while the user edits its prefix. */
function commandInputHint(text: string, commands: readonly SlashCommand[]): string | undefined {
  const match = /^\/([^\s]*)/.exec(text)
  if (match?.[1] === undefined) return undefined
  const command = commands.find(entry => entry.name === match[1])
  return command?.argumentHint === undefined ? undefined : `/${command.name} ${command.argumentHint}`
}

/** Format a token count compactly: 1234 → "1.2k", 1234567 → "1.2M". */
function formatTokens(count: number): string {
  if (count >= 1_000_000) return `${(count / 1_000_000).toFixed(1)}M`
  if (count >= 1_000) return `${(count / 1_000).toFixed(1)}k`
  return String(count)
}



/** Resolve a regular repository or linked worktree branch without spawning Git. */
async function readGitBranch(cwd: string): Promise<string | undefined> {
  const dotGit = join(cwd, '.git')
  let gitDir = dotGit
  try {
    const pointer = (await readFile(dotGit, 'utf8')).trim()
    const match = /^gitdir:\s*(.+)$/i.exec(pointer)
    if (match?.[1] !== undefined) {
      gitDir = isAbsolute(match[1]) ? match[1] : resolve(cwd, match[1])
    }
  } catch {
    // A normal checkout exposes `.git` as a directory, not a pointer file.
  }
  try {
    const head = (await readFile(join(gitDir, 'HEAD'), 'utf8')).trim()
    if (head.startsWith('ref:')) return head.slice(head.lastIndexOf('/') + 1)
    return head === '' ? undefined : head.slice(0, 7)
  } catch {
    return undefined
  }
}

/** The terminal mode's plugin entry: mounts the whole UI in its constructor. */
export class Tui extends Service {
  static inject = ['tuiStartup', 'agents', 'tuiPrompt', 'commands', 'tokenMeter', 'llm', 'userQuestions', 'sessionQuery', 'agentDefaultModel', 'skills', 'sessionReferenceResolver', 'agentPresets', 'permissionPresets', 'settings', 'sessionTitle']
  static Config = TuiConfigSchema

  /** Mount 后由 TUI 赋值：读取当前前台 agent。 */
  private foregroundAgentImpl: (() => Agent | undefined) | undefined

  /** Mount 后由 TUI 赋值：按 TUI `/new` 逻辑创建会话并切到前台。 */
  private createForegroundSessionImpl: (() => Promise<SessionId | undefined>) | undefined

  /** 当前前台会话；未挂载时返回 undefined。 */
  foregroundAgent(): Agent | undefined {
    return this.foregroundAgentImpl?.()
  }

  /** WeChat `@dsh new` 使用：按 TUI 的 `/new` 逻辑创建会话并切到前台。 */
  async createForegroundSession(): Promise<SessionId | undefined> {
    if (this.createForegroundSessionImpl === undefined) return undefined
    return this.createForegroundSessionImpl()
  }

  constructor(ctx: Context, config: Config) {
    super(ctx, 'tui')

    const startup: TuiStartup = ctx.tuiStartup
    const sessionId = startup.sessionId ?? startup.resumeSessionId
    if (sessionId === undefined) {
      throw new Error('tui: no session identity available')
    }

    const resolved: ResolvedTuiConfig = resolveTuiConfig(config)
    const t: Translator = createTranslator(resolved.locale)
    const truecolor = resolved.theme.truecolor || detectTruecolor()
    // Runtime theme state; `/theme` and `/settings` re-paint in place.
    const settings = ctx.settings
    const tuiSettings = settings?.register(TUI_SETTINGS_NAMESPACE, TuiSettingsSchema, {
      base: {
        themeMode: resolved.theme.mode,
        themeDark: resolved.theme.dark,
        themeLight: resolved.theme.light,
        themeSelected: resolved.theme.selected,
      },
    })
    interface ProviderModelProfile {
      id: string
      name?: string
      contextWindow?: number
      maxTokens?: number
      reasoningEfforts?: ReasoningEffortSetting
    }
    interface ConfiguredProviderProfile {
      apiKeyEnv?: string
      displayName?: string
      api?: string
      baseURL?: string
      models?: ProviderModelProfile[]
    }
    const asRecord = (value: unknown): Record<string, unknown> | undefined => (
      value !== null && typeof value === 'object' && !Array.isArray(value)
        ? value as Record<string, unknown>
        : undefined
    )
    const readPath = (value: unknown, path: readonly string[]): unknown => {
      let current = value
      for (const key of path) {
        const record = asRecord(current)
        if (record === undefined) return undefined
        current = record[key]
      }
      return current
    }
    const configurableProviderList = (): LlmConfigurableProvider[] => (
      typeof ctx.llm.listConfigurableProviders === 'function'
        ? ctx.llm.listConfigurableProviders()
        : []
    )
    const readConfiguredProvider = (entry: LlmConfigurableProvider): ConfiguredProviderProfile | undefined => {
      const value = readPath(settings?.get(settingsNamespace(entry.settingsNs)), entry.settingsPath)
      const record = asRecord(value)
      if (record === undefined) return undefined
      const profile: ConfiguredProviderProfile = {}
      if (typeof record.apiKeyEnv === 'string') profile.apiKeyEnv = record.apiKeyEnv
      if (typeof record.displayName === 'string') profile.displayName = record.displayName
      if (typeof record.api === 'string') profile.api = record.api
      if (typeof record.baseURL === 'string') profile.baseURL = record.baseURL
      if (Array.isArray(record.models) && record.models.length > 0) {
        const models = record.models.flatMap(model => {
          if (typeof model === 'string') return [{ id: model }]
          const modelRecord = asRecord(model)
          return typeof modelRecord?.id === 'string'
            ? [{
              id: modelRecord.id,
              ...(typeof modelRecord.name === 'string' ? { name: modelRecord.name } : {}),
              ...(typeof modelRecord.contextWindow === 'number' ? { contextWindow: modelRecord.contextWindow } : {}),
              ...(typeof modelRecord.maxTokens === 'number' ? { maxTokens: modelRecord.maxTokens } : {}),
              ...(() => {
                const reasoningEfforts = parseReasoningEffortSetting(
                  modelRecord.reasoningEfforts as string | readonly string[] | ReasoningEffortSetting | Record<string, unknown> | boolean | undefined,
                )
                return reasoningEfforts === undefined ? {} : { reasoningEfforts }
              })(),
            }]
            : []
        })
        if (models.length > 0) profile.models = models
      }
      return profile
    }
    const configuredProviderProfiles = (): Readonly<Record<string, ConfiguredProviderProfile>> => {
      const profiles: Record<string, ConfiguredProviderProfile> = {}
      for (const entry of configurableProviderList()) {
        const profile = readConfiguredProvider(entry)
        if (profile !== undefined) profiles[entry.provider] = profile
      }
      return profiles
    }
    let reasoningEffortCache: { route: string; efforts: readonly LlmReasoningEffortInfo[] } | undefined
    // Provider configuration belongs to the adapter that declares it through
    // dsh-llm's configurable-provider directory. The TUI only follows the
    // declared namespace/path and never invents a provider-owned namespace.
    // Runtime theme state; `/theme` and `/settings` repaint in place.

    const migrateLegacyThemeName = (name: string | undefined): Partial<{ themeMode: ThemeMode; themeDark: string; themeLight: string; themeSelected: string }> | undefined => {
      if (name === undefined) return undefined
      const concrete = findTheme(name)
      if (concrete !== undefined) {
        return { themeMode: 'selected', themeDark: resolved.theme.dark, themeLight: resolved.theme.light, themeSelected: name }
      }
      const dark = findTheme(`dark-${name}`)
      const light = findTheme(`light-${name}`)
      if (dark !== undefined && light !== undefined) {
        return { themeMode: 'dynamic', themeDark: dark.id, themeLight: light.id, themeSelected: resolved.theme.selected }
      }

      return undefined
    }
    const persistedTheme = tuiSettings?.get()
    let themeCustom: ThemeCustom | undefined = persistedTheme?.themeCustom ?? resolved.theme.custom
    const legacyThemeMigration = migrateLegacyThemeName(persistedTheme?.themeName)
    let themeMode: ThemeMode = persistedTheme?.themeMode ?? legacyThemeMigration?.themeMode ?? resolved.theme.mode
    let themeDark = persistedTheme?.themeDark ?? legacyThemeMigration?.themeDark ?? resolved.theme.dark
    let themeLight = persistedTheme?.themeLight ?? legacyThemeMigration?.themeLight ?? resolved.theme.light
    let themeSelected = persistedTheme?.themeSelected ?? legacyThemeMigration?.themeSelected ?? resolved.theme.selected
    // Runtime presentation state; `/settings` can persist these through the
    // same TUI settings namespace.
    let showReasoning = persistedTheme?.showReasoning ?? resolved.showReasoning
    let maxToolOutputLines = persistedTheme?.maxToolOutputLines ?? resolved.maxToolOutputLines
    let leftPrompt = persistedTheme?.leftPrompt ?? resolved.theme.leftPrompt
    let rightPrompt = persistedTheme?.rightPrompt ?? resolved.theme.rightPrompt
    let keyTools = persistedTheme?.keyTools ?? 'ctrl+o'
    let keyReasoning = persistedTheme?.keyReasoning ?? 'ctrl+t'
    const resolveDefaultMode = (): string => ctx.agentPresets?.defaultId ?? resolved.mode
    let uiMode: string = resolveDefaultMode()
    // Roster display names (id → name); refreshed from ctx.agentPresets.list().
    const presetNames = new Map<string, string>()
    const permissionCommand = permissionCommandMetadata(ctx.permissionPresets, t)
    const themeOverride = (): ThemeOverride => ({ mode: themeMode, darkId: themeDark, lightId: themeLight, selectedId: themeSelected, custom: themeCustom })
    const palette: Palette = createPalette(resolved.theme.color, 'dark', truecolor, themeOverride())
    const mdTheme = markdownTheme(palette)
    const terminal = new ProcessTerminal()
    // Keep the hardware cursor visible at the editor's real cursor position;
    // IMEs that preview pinyin/composition inline depend on it being shown there.
    const ui = new TUI(terminal, true)
    ui.setClearOnShrink(true)

    // Community extension seams (dsh-ecosystem-spec v0.15): the TUI row
    // provides the renderer-coupled services and installs pi-tui backends
    // below once `appendNotice`/`palette` are available.
    const extensions: ExtensionServices = createExtensionServices()
    ctx.provide('tuiDialogs', extensions.dialogs)
    ctx.provide('tuiStatus', extensions.status)
    ctx.provide('tuiShortcuts', extensions.shortcuts)
    ctx.provide('tuiRenderers', extensions.renderers)
    ctx.provide('tuiSettingsSections', extensions.settingsSections)
    ctx.provide('tuiScenes', extensions.scenes)
    const pluginHost = ctx.get('tuiPluginHost', false) as TuiPluginHost | undefined

    // Warn once when the profile's harness tree drifts from the validated
    // upstream line. The check is best-effort and never blocks startup.
    void upstreamDriftWarnings(join(import.meta.dirname, '..', '..', '..')).then(warnings => {
      for (const warning of warnings) enqueueBootNotice(warning, 'warning')
    })

    // The agent is published asynchronously on the resume path (persistence
    // load), so agent-dependent setup runs in mount() once it is live.
    let agent: Agent | undefined
    let gitBranch: string | undefined
    /** Running token usage for the active session; kept incrementally to avoid rescanning the whole log on every status update. */
    let tokenTotals = { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }
    // Agent-scoped helpers handed to the command surface by mount().
    const handles: {
      newAgent: (() => Promise<SessionId | undefined>) | undefined
      switchAgent: ((id: SessionId) => Promise<void>) | undefined
      saveSelection: ((selection: ModelSelection) => Promise<void>) | undefined
      setReasoningEffort: ((effort: NonNullable<ModelSelection['reasoningEffort']>) => Promise<void>) | undefined
      selectionRef: ModelSelectionRef | undefined
    } = {
      newAgent: undefined,
      switchAgent: undefined,
      saveSelection: undefined,
      setReasoningEffort: undefined,
      selectionRef: undefined,
    }
    const reasoningEffortsFor = async (selection: ModelSelection): Promise<readonly LlmReasoningEffortInfo[]> => {
      const route = `${selection.provider}\u0000${selection.model}`
      if (reasoningEffortCache?.route === route) return reasoningEffortCache.efforts
      const info = await ctx.llm.resolveModelInfo(selection.provider, selection.model)
      const efforts = info.reasoning?.efforts ?? []
      reasoningEffortCache = { route, efforts }
      return efforts
    }

    // --- components -------------------------------------------------------
    const editor = new Editor(ui, {
      borderColor: (text: string) => palette.borderMuted(text),
      selectList: selectTheme(palette),
    } satisfies EditorTheme, {
      paddingX: 1,
      frame: 'none',
      prompt: { first: '', continuation: '' },
    })
    let leftTemplate = parseTuiPromptTemplate(displayInlineText(persistedTheme?.leftPrompt ?? resolved.theme.leftPrompt))
    let rightTemplate = parseTuiPromptTemplate(displayInlineText(persistedTheme?.rightPrompt ?? resolved.theme.rightPrompt))
    const promptValue = (valueName: string): string | undefined => ctx.tuiPrompt.get(valueName)
    let directoryStatus = new ComposerDirectoryComponent(leftTemplate, promptValue, palette)
    const todoPanel = new TodoPanelComponent(palette)
    const subagentPanel = new SubagentPanelComponent(palette)
    // 固定占位一行：通知只在行内刷新文字，不改变 chrome 高度，
    // 避免每次临时通知出现/消失时 transcript 视口上下抽动。
    // 无临时通知时回落到微信桥持久状态（连接情况 + 接收锁归属）。
    let noticeText = ''
    let wechatStatusText = ''
    let uiStarted = false
    const pendingNotices: Array<{ text: string; kind: 'info' | 'warning' | 'error' }> = []
    const noticeSlot: Component = {
      invalidate() {},
      render(width: number): string[] {
        const pluginLines = extensions.status.snapshot()
        const lines: string[] = []
        if (pluginLines.length > 0) {
          lines.push(truncateToWidth(pluginLines.join(' · '), Math.max(1, width), ''))
        }
        if (noticeText !== '') {
          lines.push(truncateToWidth(noticeText, Math.max(1, width), ''))
        } else if (wechatStatusText !== '') {
          lines.push(truncateToWidth(palette.dim(`\uf1d7 ${wechatStatusText}`), Math.max(1, width), ''))
        }
        if (lines.length === 0) return ['']
        return lines
      },
    }
    const askSlot = new Container()
    let commandHintText: string | undefined
    const commandHint = new CommandHintComponent(() => commandHintText, palette)
    const inputTopBorder = new InputBorderComponent(palette)
    const inputBorder = new InputBorderComponent(palette)
    let footer = new ComposerFooterComponent(rightTemplate, promptValue, palette)
    let noticeTimer: NodeJS.Timeout | undefined

    /** Lines consumed by every root child below the transcript viewport. */
    const computeTranscriptHeight = (width: number): number => {
      let used = 0
      for (const child of [todoPanel, subagentPanel, noticeSlot, askSlot, inputTopBorder, editor, commandHint, inputBorder, directoryStatus, footer]) {
        used += child.render(width).length
      }
      return Math.max(1, ui.terminal.rows - used)
    }
    const chat = new TranscriptViewport(computeTranscriptHeight)

    const rebuildChrome = (): void => {
      ui.clear()
      ui.addChild(chat)
      ui.addChild(todoPanel)
      ui.addChild(subagentPanel)
      ui.addChild(noticeSlot)
      ui.addChild(askSlot)
      ui.addChild(inputTopBorder)
      ui.addChild(editor)
      ui.addChild(commandHint)
      ui.addChild(inputBorder)
      ui.addChild(directoryStatus)
      ui.addChild(footer)
      ui.setFocus(editor)
    }
    rebuildChrome()
    terminal.setTitle(resolved.title)

    // --- prompt values ----------------------------------------------------
    const cwdValue = ctx.tuiPrompt.register('cwd')
    const cwdCompactValue = ctx.tuiPrompt.register('cwd/compact')
    const gitValue = ctx.tuiPrompt.register('git/worktree')
    const gitCompactValue = ctx.tuiPrompt.register('git/worktree/compact')
    const modeValue = ctx.tuiPrompt.register('mode')
    const modeCompactValue = ctx.tuiPrompt.register('mode/compact')
    const modelValue = ctx.tuiPrompt.register('model')
    const modelCompactValue = ctx.tuiPrompt.register('model/compact')
    const effortValue = ctx.tuiPrompt.register('effort')
    const effortCompactValue = ctx.tuiPrompt.register('effort/compact')
    const tokensValue = ctx.tuiPrompt.register('tokens')
    const contextValue = ctx.tuiPrompt.register('context')
    const contextCompactValue = ctx.tuiPrompt.register('context/compact')
    const cacheValue = ctx.tuiPrompt.register('cache')
    const cacheCompactValue = ctx.tuiPrompt.register('cache/compact')
    const permissionCompactValue = ctx.tuiPrompt.register('permission/compact')
    const queuedValue = ctx.tuiPrompt.register('queued')
    const symbolValue = ctx.tuiPrompt.register('symbol')
    const indicatorValue = ctx.tuiPrompt.register('indicator')

    const updateInputPrompt = (): void => {
      const indicator = ctx.tuiPrompt.get('indicator') ?? ''
      const first = indicator === '' ? '' : `${indicator} `
      editor.setPrompt({ first, continuation: ' '.repeat(visibleWidth(first)) })
    }

    const showNotice = (text: string, kind: 'info' | 'warning' | 'error'): void => {
      const color = kind === 'error'
        ? palette.error
        : kind === 'warning' ? palette.warning : palette.dim
      noticeText = color(displayInlineText(text))
      clearTimeout(noticeTimer)
      noticeTimer = setTimeout(() => {
        noticeText = ''
        ui.requestRender()
      }, kind === 'error' ? 20000 : kind === 'warning' ? 10000 : 5000)
      ui.requestRender()
    }

    const appendNotice = (text: string, kind: 'info' | 'warning' | 'error'): void => {
      if (!uiStarted) {
        pendingNotices.push({ text, kind })
        return
      }
      showNotice(text, kind)
    }

    const flushDeferredNotices = (): void => {
      uiStarted = true
      for (const notice of drainBootNotices()) pendingNotices.push(notice)
      const deferred = pendingNotices.splice(0)
      const last = deferred.at(-1)
      if (last !== undefined) showNotice(last.text, last.kind)
    }

    // Managed dialog backend: FIFO queue lives in DialogsService; pi-tui
    // renders one modal at a time through the existing overlay helpers.
    extensions.dialogs.installBackend({
      select: request => showOverlay<string>(ui, done => new SelectDialog(
        request.title,
        request.options.map(option => ({
          value: option.id,
          label: option.label,
          ...option.description === undefined ? {} : { description: option.description },
        })),
        palette,
        done,
      )),
      confirm: request => showOverlay<boolean>(ui, done => new SelectDialog(
        request.title,
        [
          { value: 'yes', label: request.confirmLabel ?? t('confirmYes') },
          { value: 'no', label: request.cancelLabel ?? t('confirmNo') },
        ],
        palette,
        value => done(value === 'yes'),
      )).then(value => value ?? false),
      input: request => showOverlay<string>(ui, done => new InputDialog(
        request.title,
        palette,
        done,
        t,
        request.initial ?? '',
      )),
    })

    // Scene backend: pi-tui scene components (deviation from the React scene
    // contract documented in docs/contracts.md).
    extensions.scenes.installBackend({
      open: registration => {
        if (typeof registration.component !== 'object' && typeof registration.component !== 'function') return false
        void showOverlay<unknown>(ui, done => {
          if (typeof registration.component === 'function') {
            return (registration.component as (props: { close: () => void; palette: Palette; t: Translator }) => Component)({
              close: () => done(undefined),
              palette,
              t,
            })
          }
          return registration.component as Component
        })
        return true
      },
      close: () => undefined,
    })

    const warnIfFullAccess = (target: Agent): void => {
      if (ctx.permissionPresets.current(target.session) === FULL_ACCESS_REGISTRY_NAME) {
        appendNotice(t('noticeFullAccessWarning'), 'warning')
      }
    }

    // 微信桥输出不直接写 stderr：日志/二维码作为持久化文本进入 transcript，
    // 与 `/help` 的静态卡片一样保留在终端中，且不会越过差分渲染器覆盖输入框。
    // 普通运行日志不展示；error 类走临时通知，status 更新到固定占位行。
    const wechatErrorLog = /(?:error|failed|crash|refused|timed?\s*out|失败|错误|异常|❌)/i
    const subscribeWechatOutput = (): void => {
      if (offWechatOutput !== undefined) return
      let bridge: WechatBridge | undefined
      try {
        bridge = ctx.get('wechat') as WechatBridge | undefined
      } catch {
        bridge = undefined
      }
      if (bridge?.subscribeOutput === undefined) return
      offWechatOutput = bridge.subscribeOutput((message) => {
        if (message.kind === 'status') {
          wechatStatusText = displayInlineText(message.text)
          ui.requestRender()
          return
        }
        if (message.kind === 'error' || (message.kind === 'log' && wechatErrorLog.test(message.text))) {
          appendNotice(message.text, 'error')
          return
        }
        if (message.kind === 'qr') {
          // 二维码保持无边框等宽文本，避免卡片边框影响扫码。
          chat.addChild(new Spacer(1))
          chat.addChild(new Text(displayText(message.text), 1, 0))
        }
        // 普通日志不进入 transcript，也不发通知。
        ui.requestRender()
      })
    }

    // --- status -----------------------------------------------------------
    let currentScheme: TerminalColorScheme = 'dark'
    let spinnerTimer: NodeJS.Timeout | undefined
    let spinnerIndex = 0
    let isCompacting = false
    const refreshCompacting = (): void => {
      if (isCompacting) {
        indicatorValue.set(palette.warning(` ${t('noticeCompacting')} `))
      } else if (spinnerTimer === undefined) {
        indicatorValue.set(undefined)
      }
      updateInputPrompt()
      ui.requestRender()
    }
    let estimatedContextWindow = DEFAULT_CONTEXT_WINDOW
    let contextEstimateRevision = 0

    const startSpinner = (): void => {
      spinnerIndex = 0
      spinnerTimer = setInterval(() => {
        spinnerIndex = (spinnerIndex + 1) % SPINNER_FRAMES.length
        if (isCompacting) {
          indicatorValue.set(palette.warning(` ${t('noticeCompacting')} `))
        } else {
          indicatorValue.set(palette.bold(palette.accent(SPINNER_FRAMES[spinnerIndex] ?? '')))
        }
        updateInputPrompt()
        ui.requestRender()
      }, SPINNER_INTERVAL_MS)
      if (isCompacting) {
        indicatorValue.set(palette.warning(` ${t('noticeCompacting')} `))
      } else {
        indicatorValue.set(palette.bold(palette.accent(SPINNER_FRAMES[spinnerIndex] ?? '')))
      }
      updateInputPrompt()
    }

    const stopSpinner = (): void => {
      if (spinnerTimer === undefined) return
      clearInterval(spinnerTimer)
      spinnerTimer = undefined
      if (isCompacting) {
        indicatorValue.set(palette.warning(` ${t('noticeCompacting')} `))
      } else {
        indicatorValue.set(undefined)
      }
      updateInputPrompt()
    }

    // --- interjection queue -------------------------------------------------
    // While the agent is running, Enter queues the composed text as an
    // interjection (`agent.steer`) instead of a normal follow-up. The loop
    // claims it at the next step boundary, so it reaches the model right after
    // the in-flight tool call settles (or immediately after the current model
    // message when there are no tool calls). Entries are removed from this list
    // once their matching `user/message` event is rendered.
    const pendingInterjections: Array<{ message: ReturnType<typeof createUserMessage>; text: string }> = []

    const refreshInterjectionIndicator = (): void => {
      queuedValue.set(pendingInterjections.length === 0
        ? undefined
        : ` ${palette.muted('·')} ${palette.warning(`⏳${pendingInterjections.length}`)}`)
    }

    const enqueueInterjection = (text: string): void => {
      const current = agent
      if (current === undefined) return
      const message = createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'user' },
      })
      pendingInterjections.push({ message, text })
      try {
        current.steer(message)
      } catch (error: unknown) {
        pendingInterjections.pop()
        appendNotice(t('noticeInterjectionFailed', { error: errorChain(error) }), 'error')
        refreshInterjectionIndicator()
        ui.requestRender()
        return
      }
      appendNotice(t('noticeInterjectionQueued'), 'info')
      refreshInterjectionIndicator()
      updateStatusValues()
      ui.requestRender()
    }

    /** Expensive status inputs (token meter + permission) are refreshed at most once per second. */
    const CONTEXT_USAGE_REFRESH_MS = 1_000
    let contextUsageCache: { measuredAt: number; totalTokens: number; permission: string } = {
      measuredAt: 0,
      totalTokens: 0,
      permission: '',
    }

    const updateStatusValues = (): void => {
      const current = agent
      if (current === undefined) return
      const cwd = displayText(current.session.header.cwd ?? process.cwd())
      cwdValue.set(palette.path(` ${cwd}`))
      cwdCompactValue.set(palette.path(` ${displayText(basename(cwd))}`))
      gitValue.set(gitBranch === undefined
        ? undefined
        : ` ${palette.statusSep('')} ${palette.git(` ${displayText(gitBranch)}`)}`)
      gitCompactValue.set(gitBranch === undefined
        ? undefined
        : palette.git(` ${displayText(gitBranch)}`))
      const mode = modeLabel(t, uiMode, presetNames)
      const compactMode = visibleWidth(mode) <= visibleWidth(uiMode) ? mode : uiMode
      modeValue.set(`${palette.accent(mode)} ${palette.statusSep('')} `)
      modeCompactValue.set(palette.accent(displayText(compactMode)))
      const selection = handles.selectionRef?.current
      const model = selection?.model ?? current.options.model
      modelValue.set(model === undefined ? undefined : palette.model(displayText(model)))
      modelCompactValue.set(model === undefined ? undefined : palette.model(displayText(model)))
      const effort = selection?.reasoningEffort
      effortValue.set(effort === undefined
        ? undefined
        : ` ${palette.muted('·')} ${palette.accent(displayText(effort))}`)
      effortCompactValue.set(effort === undefined ? undefined : palette.accent(displayText(effort)))
      tokensValue.set(` ${palette.muted('·')} ${palette.spend(`↑${formatTokens(tokenTotals.inputTokens)} ↓${formatTokens(tokenTotals.outputTokens)}`)}`)
      const recordedContext = current.session.requestContext()
      const recordedWindow = recordedContext !== undefined
        && selection !== undefined
        && recordedContext.provider === selection.provider
        && recordedContext.model === selection.model
        ? recordedContext.contextWindow
        : undefined
      const contextWindow = recordedWindow ?? estimatedContextWindow
      const now = Date.now()
      if (now - contextUsageCache.measuredAt >= CONTEXT_USAGE_REFRESH_MS) {
        let totalTokens = 0
        try {
          totalTokens = ctx.tokenMeter.measure(current.session).totalTokens
        } catch {
          // Before assembly, some providers cannot estimate the input. Show the
          // required zero fallback rather than hiding the context segment.
        }
        contextUsageCache = {
          measuredAt: now,
          totalTokens,
          permission: ctx.permissionPresets.current(current.session),
        }
      }
      const contextText = `ctx ${formatContextTokens(contextUsageCache.totalTokens)}/${formatContextTokens(contextWindow)}`
      contextValue.set(` ${palette.muted('·')} ${palette.context(contextText)}`)
      contextCompactValue.set(palette.context(contextText))
      const cacheDenominator = tokenTotals.cacheReadTokens + tokenTotals.inputTokens
      const cacheText = cacheDenominator > 0
        ? `cache ${Math.round(tokenTotals.cacheReadTokens / cacheDenominator * 100)}%`
        : undefined
      cacheValue.set(cacheText === undefined ? undefined : ` ${palette.muted('·')} ${palette.context(cacheText)}`)
      cacheCompactValue.set(cacheText === undefined ? undefined : palette.context(cacheText))
      const permission = contextUsageCache.permission
      const permissionRole = permission === FULL_ACCESS_REGISTRY_NAME
        ? (text: string) => palette.bold(palette.accent(text))
        : permission === 'read-only' ? palette.muted : palette.accent
      const permissionText = permissionRole(displayText(displayPermissionName(permission)))
      permissionCompactValue.set(permissionText)
      refreshInterjectionIndicator()
      symbolValue.set(undefined)
      updateInputPrompt()
    }

    const refreshGitBranch = (workspace: string): void => {
      const target = agent
      gitBranch = undefined
      void readGitBranch(workspace).then(branch => {
        if (agent !== target) return
        gitBranch = branch
        updateStatusValues()
        ui.requestRender()
      })
    }

    const refreshContextEstimate = (target: Agent, selection: ModelSelection): void => {
      const revision = ++contextEstimateRevision
      const recorded = target.session.requestContext()
      const recordedWindow = recorded !== undefined
        && recorded.provider === selection.provider
        && recorded.model === selection.model
        ? recorded.contextWindow
        : undefined
      estimatedContextWindow = recordedWindow ?? DEFAULT_CONTEXT_WINDOW
      if (target.id === agent?.id) {
        updateStatusValues()
        ui.requestRender()
      }
      if (recordedWindow !== undefined) return
      void ctx.llm.resolveModelInfo(selection.provider, selection.model).then((info) => {
        if (revision !== contextEstimateRevision || target.id !== agent?.id) return
        estimatedContextWindow = info.context?.contextWindow ?? DEFAULT_CONTEXT_WINDOW
        updateStatusValues()
        ui.requestRender()
      }).catch(() => {
        // The 1m fallback remains visible when exact model metadata is unavailable.
      })
    }

    const setStatus = (status: AgentStatus): void => {
      editor.borderColor = status === 'running'
        ? (text: string) => palette.accent(text)
        : (text: string) => palette.borderMuted(text)
      if (status === 'running') startSpinner()
      else stopSpinner()
      terminal.setProgress(status === 'running')
      updateStatusValues()
      ui.requestRender()
    }

    // --- transcript ---------------------------------------------------------
    const assistantStream = new AssistantStreamController(chat, palette, mdTheme)
    const toolCards = new Map<ToolCallId, ToolCardComponent>()
    const allToolCards = new Set<ToolCardComponent>()
    const contextCards = new Set<ContextCardComponent>()
    let toolsVisibility: ToolCardVisibility = 'collapsed'
    let live = false
    /** 启动时先置顶展示历史内容；首个实时事件到达后恢复跟随最新。 */
    let followLatestAfterStartup = false
    const TRANSCRIPT_EVENT_TYPES = new Set<string>([
      'user/message',
      'assistant/chunk',
      'assistant/message',
      'tool/call',
      'tool/result',
      'subagent/descriptor',
    ])
    let header: HeaderComponent | undefined
    const TRANSCRIPT_RECENT_LIMIT = 200
    const TRANSCRIPT_LOAD_STEP = 200
    let transcriptStart = 0
    /** Invalidates chunked rebuilds that are superseded by a newer window. */
    let transcriptBuildGeneration = 0
    const renderEvent = (event: SessionEvent, syncStatus = true, notify = true): void => {
      switch (event.type) {
        case 'user/message': {
          const source = event.data.source
          const text = displayText(contentText(event.data.content).trim())
          if (text === '') break
          chat.addChild(new Spacer(1))
          if (source.kind !== 'user') {
            const label = source.kind === 'plugin' ? source.plugin : source.kind
            const card = new ContextCardComponent(label, text, maxToolOutputLines, palette)
            card.setVisibility(toolsVisibility)
            contextCards.add(card)
            chat.addChild(card)
          } else {
            chat.addChild(new UserMessageComponent(text, palette, mdTheme))
          }
          // Interjections are durable user messages; once the loop appends one
          // it has taken effect and is no longer editable with Alt+Up.
          const pendingIndex = pendingInterjections.findIndex(entry => entry.message.id === event.data.id)
          if (pendingIndex >= 0) pendingInterjections.splice(pendingIndex, 1)
          break
        }
        case 'step/start':
          assistantStream.start(showReasoning)
          break
        case 'assistant/chunk':
          assistantStream.update(event.data.chunk)
          break
        case 'assistant/message':
          assistantStream.settle(event.data.message.content)
          if (event.data.usage !== undefined) {
            tokenTotals.inputTokens += event.data.usage.inputTokens
            tokenTotals.outputTokens += event.data.usage.outputTokens
            tokenTotals.cacheReadTokens += event.data.usage.cacheReadTokens ?? 0
            tokenTotals.cacheWriteTokens += event.data.usage.cacheWriteTokens ?? 0
          }
          break
        case 'step/end':
          assistantStream.end()
          break
        case 'tool/call': {
          const card = new ToolCardComponent(
            event.data.name,
            event.data.arguments,
            maxToolOutputLines,
            palette,
          )
          card.setVisibility(toolsVisibility)
          toolCards.set(event.data.callId, card)
          allToolCards.add(card)
          chat.addChild(card)
          break
        }
        case 'tool/result': {
          const callId = event.data.message.content[0]?.toolCallId
          if (callId !== undefined) toolCards.get(callId)?.updateResult(event.data)
          break
        }
        case 'todo/write':
          todoPanel.setTodos(event.data.todos)
          break
        case 'goal/change':
          if (event.data.operation === 'clear') {
            todoPanel.setGoal(undefined)
          } else {
            todoPanel.setGoal({ objective: event.data.goal.objective, phase: event.data.goal.phase })
          }
          break
        case 'compaction/start':
          isCompacting = true
          refreshCompacting()
          if (live && notify) appendNotice(t('noticeCompacting'), 'info')
          break
        case 'compaction/end':
          isCompacting = false
          refreshCompacting()
          // Force token counts to re-measure: the compressed history is
          // dramatically smaller than the shadowed range.
          contextUsageCache.measuredAt = 0
          if (live && notify) {
            appendNotice(
              event.data.error === undefined ? t('noticeCompactionDone') : t('noticeCompactionFailed', { error: event.data.error }),
              event.data.error === undefined ? 'info' : 'error',
            )
          }
          break
        case 'turn/end': {
          // Detach the live streaming slot so straggler chunks that arrive
          // after an abort cannot keep appending to the interrupted step;
          // its rendered partial content stays in the transcript.
          assistantStream.end()
          if (live && notify && event.data.reason.kind !== 'completed') {
            appendNotice(t('noticeTurnEnded', { reason: event.data.reason.kind }), 'warning')
          }
          break
        }
        default: {
          const rendered = extensions.renderers.render(event.type, event.data)
          if (rendered !== undefined) {
            const rows = rendered.title === undefined ? rendered.lines : [rendered.title, ...rendered.lines]
            chat.addChild(new StaticCardComponent(rows, palette))
          }
          break
        }
      }
      if ((event as { type: string }).type === 'subagent/descriptor') {
        const data = (event as { data: { label?: string; provider?: string; mode?: 'one-shot' | 'continuable' } }).data
        subagentPanel.add({ label: data.label, provider: data.provider ?? 'subagent', mode: data.mode ?? 'one-shot' })
      }
      if (syncStatus) updateStatusValues()
    }

    /**
     * Rebuild the transcript from `start` to the end. `anchor` controls the
     * viewport after the rebuild: `'bottom'` follows the latest event, while
     * `'top'` keeps the newly prepended page in view (for paging backwards).
     */
    const renderTranscriptWindow = (start: number, anchor: 'bottom' | 'top' = 'bottom'): void => {
      assistantStream.end()
      toolCards.clear()
      allToolCards.clear()
      contextCards.clear()
      chat.followLatest = anchor === 'bottom'
      chat.lineOffset = 0
      chat.clear()
      if (header !== undefined) chat.addChild(header)
      chat.addChild(new TranscriptFoldNoticeComponent(() => transcriptStart, palette))
      const events = agent!.session.events
      const generation = ++transcriptBuildGeneration
      let index = Math.max(0, start)
      const chunkSize = 200
      const renderChunk = (): void => {
        // Drop stale work if a newer window build started or the active
        // session changed while this chunked rebuild was still running.
        if (generation !== transcriptBuildGeneration) return
        if (agent === undefined || agent.session.events !== events) return
        const end = Math.min(index + chunkSize, events.length)
        for (; index < end; index++) {
          renderEvent(events[index]!, false, false)
        }
        if (index < events.length) {
          setImmediate(renderChunk)
          ui.requestRender()
        } else {
          updateStatusValues()
          ui.requestRender()
        }
      }
      renderChunk()
    }

    const rebuildTranscript = (anchor: 'bottom' | 'top' = 'bottom', followLive = false): void => {
      followLatestAfterStartup = followLive
      subagentPanel.clear()
      tokenTotals = { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }
      contextUsageCache.measuredAt = 0
      const events = agent!.session.events
      // Re-derive persistent compacting flag when rebuilding a truncated window.
      isCompacting = false
      for (const ev of events) {
        if (ev.type === 'compaction/start') isCompacting = true
        else if (ev.type === 'compaction/end') isCompacting = false
      }
      refreshCompacting()
      transcriptStart = Math.max(0, events.length - TRANSCRIPT_RECENT_LIMIT)
      renderTranscriptWindow(transcriptStart, anchor)
    }

    const loadOlderTranscript = (): void => {
      if (transcriptStart <= 0) return
      transcriptStart = Math.max(0, transcriptStart - TRANSCRIPT_LOAD_STEP)
      renderTranscriptWindow(transcriptStart, 'top')
    }

    /** Scroll the transcript by a signed number of lines; loading older pages at the top. */
    const scrollTranscriptLines = (delta: number): void => {
      if (delta < 0) {
        if (chat.followLatest) {
          chat.lineOffset = Math.max(0, chat.lastTotalLines - chat.lastViewportLines)
          chat.followLatest = false
        }
        chat.lineOffset = Math.max(0, chat.lineOffset + delta)
        if (chat.lineOffset === 0 && transcriptStart > 0) {
          loadOlderTranscript()
          return
        }
      } else if (delta > 0 && !chat.followLatest) {
        const maxOffset = Math.max(0, chat.lastTotalLines - chat.lastViewportLines)
        chat.lineOffset = Math.min(maxOffset, chat.lineOffset + delta)
        if (chat.lineOffset >= maxOffset) chat.followLatest = true
      }
      ui.requestRender()
    }

    /** Scroll the transcript by one viewport page; loading older pages at the top. */
    const scrollTranscriptPage = (direction: -1 | 1): void => {
      scrollTranscriptLines(direction * Math.max(1, chat.lastViewportLines))
    }

    const latestCompactionError = (): string | undefined => {
      const events = agent?.session.events
      if (events === undefined) return undefined
      for (let index = events.length - 1; index >= 0; index--) {
        const event = events[index]!
        if (event.type === 'compaction/end') {
          const error = (event.data as { error?: string } | undefined)?.error
          return typeof error === 'string' && error !== '' ? error : undefined
        }
      }
      return undefined
    }

    // --- input ---------------------------------------------------------------
    const applyToolsVisibility = (): void => {
      for (const card of allToolCards) card.setVisibility(toolsVisibility)
      for (const card of contextCards) card.setVisibility(toolsVisibility)
    }

    /** Ctrl+O (OMP-style): expand or collapse truncated tool cards. */
    const expandTools = (): void => {
      toolsVisibility = toolsVisibility === 'expanded' ? 'collapsed' : 'expanded'
      applyToolsVisibility()
      appendNotice(t('noticeToolCards', { visibility: toolsVisibility }), 'info')
    }

    /** Ctrl+Shift+O (OMP-style): show or hide tool activity cards. */
    const toggleToolActivity = (): void => {
      toolsVisibility = toolsVisibility === 'hidden' ? 'collapsed' : 'hidden'
      applyToolsVisibility()
      appendNotice(t('noticeToolCards', { visibility: toolsVisibility }), 'info')
    }

    const recordActivePreset = (target: Agent): void => {
      const mounted = ctx.agentPresets?.composedPreset(target.ctx)
      const preset = mounted ?? resolveSessionPreset(target.session)
        ?? (target.id === agent?.id ? uiMode : undefined)
      if (preset !== undefined) recordConversationPreset(target.session, preset)
    }

    const toggleReasoning = (): void => {
      showReasoning = !showReasoning
      appendNotice(showReasoning ? t('noticeReasoningShown') : t('noticeReasoningHidden'), 'info')
    }

    const resetDisplay = (): void => {
      rebuildTranscript()
      appendNotice(t('noticeDisplayReset'), 'info')
    }

    const cycleModel = async (direction: 1 | -1): Promise<void> => {
      const save = handles.saveSelection
      const selection = handles.selectionRef?.current
      if (save === undefined || selection === undefined) return
      try {
        const entries: ModelSelection[] = []
        for (const provider of ctx.llm.listProviders()) {
          try {
            const models = await ctx.llm.listModels(provider.id)
            for (const model of models) {
              entries.push({ provider: provider.id, model: model.id })
            }
          } catch {
            // Providers may expose no model catalog; the current selection
            // still participates below.
          }
        }
        const currentIndex = entries.findIndex(entry =>
          entry.provider === selection.provider && entry.model === selection.model)
        if (currentIndex !== -1 && entries.length > 1) {
          const target = entries[(currentIndex + direction + entries.length) % entries.length]!
          const next: ModelSelection = {
            provider: target.provider,
            model: target.model,
            ...selection.reasoningEffort === undefined ? {} : { reasoningEffort: selection.reasoningEffort },
          }
          await save(next)
          appendNotice(t('noticeModelSet', { provider: next.provider, model: next.model }), 'info')
        } else {
          appendNotice(t('noticeNoModels'), 'warning')
        }
      } catch (error: unknown) {
        appendNotice(t('noticeModelFailed', { error: errorChain(error) }), 'error')
      }
    }

    const runCommand = async (line: string): Promise<void> => {
      const current = agent
      if (current === undefined) return

      const runSessionSwitchDecision = async (kind: 'new' | 'resume', targetSessionId?: string): Promise<boolean> => {
        if (pluginHost === undefined) return true
        const payload: Record<string, unknown> = {
          kind,
          sessionId: String(current.id),
          cwd: current.session.header.cwd ?? process.cwd(),
        }
        if (targetSessionId !== undefined) payload.targetSessionId = targetSessionId
        const decision = await pluginHost.runDecision('tui/session-switch', payload)
        if (decision !== null && typeof decision === 'object' && (decision as { cancel?: unknown }).cancel === true) {
          const reason = (decision as { reason?: unknown }).reason
          appendNotice(typeof reason === 'string' && reason !== '' ? reason : 'Session switch cancelled by a plugin', 'warning')
          return false
        }
        return true
      }
      const notifySessionSwitched = (kind: 'new' | 'resume', sessionId: string): void => {
        if (pluginHost === undefined) return
        void pluginHost.runDecision('tui/session-switched', {
          kind,
          sessionId,
          previousSessionId: String(current.id),
        })
      }
      if (line === '/palette' || line.startsWith('/palette ')) {
        const rows = renderPalette(palette, currentScheme, resolved.theme.color, truecolor, themeOverride())
        chat.addChild(new StaticCardComponent(rows, palette))
        ui.requestRender()
        return
      }
      if (line === '/plugins' || line.startsWith('/plugins ')) {
        const rows: string[] = []
        rows.push('trust: plugins run trusted-in-process; grants are behaviour, not a security boundary')
        const hostDescriptor = pluginHost?.buildHostDescriptor({ commandsMounted: true })
        rows.push(`host: ${hostDescriptor?.hostId ?? 'dsh-omp-tui'} ${hostDescriptor?.hostVersion ?? ''} · generation ${pluginHost?.generationId ?? 'unavailable'}`)
        const checkTarget = line.slice('/plugins'.length).trim()
        if (checkTarget.startsWith('check ')) {
          const target = checkTarget.slice('check '.length).trim()
          if (target === '') {
            rows.push('usage: /plugins check <path>')
          } else {
            try {
              const raw = await readFile(target, 'utf8')
              const manifest = parseManifest(JSON.parse(raw))
              const granted = pluginHost?.grants.grantedPermissions(manifest.id) ?? new Set<string>()
              const result = negotiate(manifest, { grantedPermissions: granted })
              rows.push(`check ${target}: ${result.status}`)
              for (const decision of result.contractDecisions) {
                rows.push(`- ${decision.coordinate}: ${decision.status}${decision.reason === undefined ? '' : ` (${decision.reason})`}`)
              }
            } catch (error: unknown) {
              rows.push(`check failed: ${error instanceof Error ? error.message : String(error)}`)
            }
          }
        } else if (checkTarget !== '') {
          rows.push('usage: /plugins [check <path>]')
        }
        if (pluginHost === undefined) {
          rows.push('plugin host unavailable')
        } else {
          const selfCheck = pluginHost.selfCheck()
          if (selfCheck.length > 0) {
            rows.push(`self-check: ${selfCheck.join('; ')}`)
          } else {
            rows.push('self-check: ok')
          }
          const admissions = pluginHost.activeAdmissions()
          rows.push(`admissions: ${admissions.length}`)
          for (const admission of admissions) {
            rows.push(`- ${admission.componentId} ${admission.activationInstance} ${admission.negotiation.status}`)
          }
          const ledger = await pluginHost.ledger.tail(5)
          rows.push('ledger (last 5):')
          for (const entry of ledger) {
            rows.push(`- ${entry.operation} ${entry.scope} ${entry.resource} ${entry.pluginId}`)
          }
          const snapshot = pluginHost.grants.snapshot()
          const grantRules = Object.keys(snapshot.grants).length
          const denyRules = Object.keys(snapshot.denies).length
          rows.push(`grants: ${grantRules} grant rules, ${denyRules} deny rules${snapshot.failedClosed ? ', FAILED CLOSED' : ''}`)
        }
        chat.addChild(new StaticCardComponent(rows, palette))
        ui.requestRender()
        return
      }
      if (line === '/doctor') {
        const rows: string[] = ['doctor:']
        if (pluginHost === undefined) {
          rows.push('plugin host unavailable')
        } else {
          const selfCheck = pluginHost.selfCheck()
          rows.push(selfCheck.length > 0 ? `self-check: ${selfCheck.join('; ')}` : 'self-check: ok')
          const descriptor = pluginHost.buildHostDescriptor({ commandsMounted: true })
          rows.push(`contracts advertised: ${descriptor.contracts.length}`)
          rows.push(`generation: ${pluginHost.generationId}`)
        }
        rows.push('verified dsh line: 0.1.2-alpha.3 (see verify:contract)')
        chat.addChild(new StaticCardComponent(rows, palette))
        ui.requestRender()
        return
      }
      // The TUI presents the unrestricted preset as `full-access`; the host
      // registry still knows it as `danger-full-access`, so translate before
      // handing the slash command to the backend.
      const permissionMatch = /^\/permission(?:\s+(.*))?$/.exec(line)
      if (permissionMatch !== null) {
        const arg = permissionMatch[1]?.trim() ?? ''
        line = arg === '' ? '/permission' : `/permission ${registryPermissionName(arg)}`
      }
      if (line === '/model' || line.startsWith('/model ')) {
        const save = handles.saveSelection
        if (save === undefined) return
        try {
          await runModelFlow(ui, palette, t, ctx.llm, save)
        } catch (error: unknown) {
          appendNotice(t('noticeModelFailed', { error: errorChain(error) }), 'error')
        }
        ui.requestRender()
        return
      }
      if (line === '/think' || line.startsWith('/think ')) {
        const selection = handles.selectionRef?.current
        const setEffort = handles.setReasoningEffort
        if (selection === undefined || setEffort === undefined) return
        try {
          const efforts = await reasoningEffortsFor(selection)
          const choice = chooseReasoningEffort(
            efforts,
            selection.reasoningEffort,
            line.slice('/think'.length).trim(),
          )
          if (choice.kind === 'unsupported') {
            appendNotice(t('noticeThinkUnsupported'), 'warning')
            return
          }
          if (choice.kind === 'unknown') {
            appendNotice(t('noticeThinkUnknown', { name: choice.requested }), 'warning')
            return
          }
          const params = { name: displayText(choice.effort.name), id: displayText(choice.effort.id) }
          if (choice.kind === 'already') {
            appendNotice(t('noticeThinkAlready', params), 'info')
            return
          }
          await setEffort(choice.effort.id)
          appendNotice(t('noticeThinkSet', params), 'info')
        } catch (error: unknown) {
          appendNotice(t('noticeThinkFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/new' || line.startsWith('/new ')) {
        const creator = handles.newAgent
        if (creator === undefined) return
        if (!(await runSessionSwitchDecision('new'))) return
        appendNotice(t('noticeCreatingSession'), 'info')
        try {
          const id = await creator()
          if (id !== undefined) notifySessionSwitched('new', String(id))
        } catch (error: unknown) {
          appendNotice(t('noticeSessionCreateFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/resume' || line.startsWith('/resume ')) {
        const switcher = handles.switchAgent
        if (switcher === undefined) return
        const explicit = line.slice('/resume'.length).trim()
        if (explicit !== '') {
          if (!(await runSessionSwitchDecision('resume', explicit))) return
          await switcher(SessionId(explicit))
          notifySessionSwitched('resume', explicit)
          return
        }
        if (!(await runSessionSwitchDecision('resume'))) return
        try {
          const records = await ctx.sessionQuery.listSessions()
          const workspace = current.session.header.cwd ?? process.cwd()
          const persisted = filterProjectSessions(records, workspace)
            .sort((left, right) => (right.header.createdAt ?? 0) - (left.header.createdAt ?? 0))
            .slice(0, RESUME_PICKER_LIMIT)
          if (persisted.length === 0) {
            appendNotice(t('noticeNoSessions'), 'warning')
            return
          }
          const titlesPromise = ctx.sessionQuery.readTitleSnapshots(
            persisted.map(record => record.header.id),
          ).catch(() => [] as Awaited<ReturnType<typeof ctx.sessionQuery.readTitleSnapshots>>)
          let titleTimer: NodeJS.Timeout | undefined
          const timeoutPromise = new Promise<Awaited<ReturnType<typeof ctx.sessionQuery.readTitleSnapshots>>>(
            resolve => { titleTimer = setTimeout(() => resolve([]), RESUME_TITLES_TIMEOUT_MS) },
          )
          // Titles are decorative; if a slow/corrupt session blocks the batch,
          // show the picker after the timeout with untitled labels instead of freezing.
          const titles = await Promise.race([titlesPromise, timeoutPromise])
          clearTimeout(titleTimer)
          const titleById = new Map<string, string | undefined>()
          for (const observation of titles) {
            if (observation.status === 'fulfilled') {
              titleById.set(String(observation.sessionId), observation.value.title?.title)
            }
          }
          const picked = await showOverlay<string>(ui, (done) => new SelectDialog(
            t('resumeTitle'),
            persisted.map(record => ({
              value: String(record.header.id),
              label: titleById.get(String(record.header.id)) ?? t('untitled'),
              description: `${record.header.id} · ${new Date(record.header.createdAt ?? 0).toLocaleString()}`,
            })),
            palette,
            done,
          ))
          if (picked !== undefined) {
            await switcher(SessionId(picked))
            notifySessionSwitched('resume', picked)
          }
        } catch (error: unknown) {
          appendNotice(t('noticeSessionListFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/skills' || line.startsWith('/skills ')) {
        try {
          const snapshot = await ctx.skills.snapshot({ cwd: current.session.header.cwd ?? process.cwd() })
          if (snapshot.skills.length === 0) {
            appendNotice(t('noticeNoSkills'), 'info')
            return
          }
          const rows = snapshot.skills.map(skill =>
            `/${skill.name} — ${skill.description}${skill.source === undefined ? '' : ` (${skill.source})`}`)
          chat.addChild(new StaticCardComponent(rows, palette))
          ui.requestRender()
        } catch (error: unknown) {
          appendNotice(t('noticeSkillListFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line.startsWith('/skill:')) {
        const name = line.slice('/skill:'.length).trim()
        if (name === '') {
          appendNotice(t('noticeSkillUsage'), 'warning')
          return
        }
        try {
          const definition = await ctx.skills.get(name, { cwd: current.session.header.cwd ?? process.cwd() })
          if (definition === undefined) {
            appendNotice(t('noticeUnknownSkill', { name }), 'warning')
            return
          }
          recordActivePreset(current)
          current.followup(createUserMessage({
            content: [{ type: 'text', text: renderSkillContent(definition) }],
            source: { kind: 'skill-invocation', name, form: 'instructions' },
          }))
        } catch (error: unknown) {
          appendNotice(t('noticeSkillFailed', { name, error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/details' || line.startsWith('/details ')) {
        const folded = foldSessionTitle(current.session.events)
        const model = handles.selectionRef?.current?.model ?? current.options.model
        let inputTokens = 0
        let outputTokens = 0
        for (const event of current.session.events) {
          if (event.type === 'assistant/message' && event.data.usage !== undefined) {
            inputTokens += event.data.usage.inputTokens
            outputTokens += event.data.usage.outputTokens
          }
        }
        const contextWindow = current.session.requestContext()?.contextWindow
        const usedTokens = ctx.tokenMeter.measure(current.session).totalTokens
        const rows: Array<[string, string]> = [
          ['Title', folded?.title ?? 'untitled'],
          ['Session', String(current.session.id)],
          ['Directory', current.session.header.cwd ?? process.cwd()],
          ['Model', `${current.options.provider ?? '?'}/${model ?? '?'}`],
          ['Agent', `${current.id} · ${current.status}`],
          ['Tokens', `↑${formatTokens(inputTokens)} ↓${formatTokens(outputTokens)}`],
          ['Context', contextWindow === undefined
            ? `${formatTokens(usedTokens)} used · capacity unknown`
            : `${Math.round(usedTokens / contextWindow * 100)}% · ${formatTokens(usedTokens)} / ${formatTokens(contextWindow)}`],
        ]
        const labelWidth = Math.max(...rows.map(([label]) => label.length))
        const body = rows.map(([label, value]) =>
          ` ${palette.dim(String(label).padEnd(labelWidth))}  ${displayText(String(value))}`)
        chat.addChild(new StaticCardComponent(body, palette))
        ui.requestRender()
        return
      }
      if (line === '/mode' || line.startsWith('/mode ')) {
        const presets = ctx.agentPresets
        if (presets === undefined) {
          appendNotice(t('noticeModeUnavailable'), 'warning')
          return
        }
        const roster = (await presets.list()).filter(preset => preset.broken === undefined)
        // Cycle order: the roster's own order (shipped first, then any number
        // of locally installed presets), deduplicated against the shipped set.
        const known = roster.length > 0
          ? [...new Set([...MODE_ORDER, ...roster.map(preset => preset.id)])]
          : [...MODE_ORDER]
        const arg = line.slice('/mode'.length).trim()
        if (arg !== '' && !known.includes(arg)) {
          appendNotice(t('noticeModeUnknown', { name: arg }), 'warning')
          return
        }
        const live = presets.composedPreset(current.ctx)
        const currentMode = live ?? uiMode
        const liveIndex = known.indexOf(currentMode)
        const target = arg === ''
          ? known[(liveIndex + 1) % known.length] ?? currentMode
          : arg
        if (currentMode === target) {
          appendNotice(t('noticeModeAlready', { mode: modeLabel(t, target, presetNames) }), 'info')
          return
        }
        // Swapping the composition mid-conversation would leave logged tool
        // calls the new preset cannot make; the official roster only allows
        // switching while the session is blank.
        const produced = hasConversationData(current.session.events)
        if (produced) {
          appendNotice(t('noticeModeNotBlank'), 'warning')
          return
        }
        try {
          if (live === undefined) await presets.mount(current.ctx, target)
          else await presets.recompose(current.ctx, target)
          uiMode = target
          updateStatusValues()
          ui.requestRender()
          appendNotice(t('noticeModeSet', { mode: modeLabel(t, target, presetNames) }), 'info')
        } catch (error: unknown) {
          appendNotice(t('noticeModeSwitchFailed', { error: errorChain(error) }), 'error')
        }
        return
      }
      if (line === '/settings' || line.startsWith('/settings ')) {
        if (settings === undefined || tuiSettings === undefined) {
          appendNotice(t('noticeSettingsUnavailable'), 'warning')
          return
        }
        try {
          type SettingsView =
            | 'main'
            | 'theme'
            | 'theme-mode'
            | 'theme-dark'
            | 'theme-light'
            | 'theme-selected'
            | 'theme-custom'
            | 'title-provider'
            | 'title-model'
            | 'default-permission'
            | 'default-provider'
            | 'default-model'
            | 'default-mode'

          interface ProviderCatalogEntry {
            id: string
            name: string
            source: 'registered' | 'configurable'
            configurable?: LlmConfigurableProvider
            profile?: ConfiguredProviderProfile
          }

          const toolOutputLineOptions = [3, 6, 10, 20, 50]
          const parallelToolCallOptions = [1, 2, 4, 8, 10, 16, 32]
          const CUSTOM_PROVIDER = '\u0000custom-provider'
          const CUSTOM_MODEL = '\u0000custom-model'
          const EDIT_CUSTOM_PROVIDER = '\u0000edit-custom-provider'
          const EDIT_CUSTOM_MODEL = '\u0000edit-custom-model'

          const wechatBridge = (): WechatBridge | undefined => {
            try {
              return ctx.get('wechat') as WechatBridge | undefined
            } catch {

      return undefined
            }
          }
          const getWechatConfig = (): BridgeConfig | undefined => wechatBridge()?.getBridgeConfig()
          const setWechatConfig = (next: BridgeConfig): void => {
            const bridge = wechatBridge()
            if (bridge !== undefined) bridge.setBridgeConfig(next)
          }

          let providerCatalog: ProviderCatalogEntry[] = []
          let modelCatalog: Array<{ provider: string; model: string }> = []
          const refreshProviderModelCatalog = async (): Promise<void> => {
            const providers = new Map<string, ProviderCatalogEntry>()
            const configurableProviders = configurableProviderList()
            const configurableIds = new Set(configurableProviders.map(entry => entry.provider))
            const registeredProviders = typeof ctx.llm.listProviders === 'function'
              ? ctx.llm.listProviders()
              : []
            for (const entry of registeredProviders) {
              if (configurableIds.has(entry.id)) {
                providers.set(entry.id, { id: entry.id, name: entry.name, source: 'registered' })
              }
            }
            const profiles = configuredProviderProfiles()
            for (const entry of configurableProviders) {
              const existing = providers.get(entry.provider)
              const profile = profiles[entry.provider]
              if (existing !== undefined) {
                existing.configurable = entry
                existing.profile = profile
                if (profile?.displayName !== undefined && profile.displayName !== '') existing.name = profile.displayName
                else if (existing.name === existing.id) existing.name = entry.displayName
              } else {
                providers.set(entry.provider, {
                  id: entry.provider,
                  name: profile?.displayName || entry.displayName,
                  source: 'configurable',
                  configurable: entry,
                  ...(profile === undefined ? {} : { profile }),
                })
              }
            }
            providerCatalog = [...providers.values()]

            const models = new Map<string, { provider: string; model: string }>()
            const addModel = (provider: string, model: string): void => {
              const key = `${provider}\u0000${model}`
              if (!models.has(key)) models.set(key, { provider, model })
            }
            const modelLoaders: Promise<void>[] = []
            for (const entry of providerCatalog) {
              if (entry.profile?.models !== undefined) {
                for (const model of entry.profile.models) addModel(entry.id, model.id)
                continue
              }
              modelLoaders.push((async () => {
                try {
                  const found = await ctx.llm.listModels(entry.id)
                  for (const model of found) addModel(entry.id, model.id)
                } catch {
                  // Dormant providers may have no live model catalog yet.
                }
              })())
            }
            await Promise.all(modelLoaders)
            const defaultSelection = ctx.agentDefaultModel.currentSelection()
            addModel(defaultSelection.provider, defaultSelection.model)
            const titleSettings = settings.get(SESSION_TITLE_SETTINGS_NAMESPACE) as {
              provider?: string
              model?: string
            } | undefined
            if (titleSettings?.provider !== undefined && titleSettings.model !== undefined) {
              addModel(titleSettings.provider, titleSettings.model)
            }
            modelCatalog = [...models.values()]
          }

          const listModelsForProvider = async (provider: string): Promise<Awaited<ReturnType<typeof ctx.llm.listModels>>> => {
            try {
              return await ctx.llm.listModels(provider)
            } catch {
              return []
            }
          }

          const providerModelCount = (provider: string): number => {
            const entry = providerCatalog.find(candidate => candidate.id === provider)
            if (entry?.profile?.models !== undefined) return entry.profile.models.length
            return modelCatalog.filter(model => model.provider === provider).length
          }

          const providerCurrentValue = (provider: string): string => {
            const entry = providerCatalog.find(candidate => candidate.id === provider)
            const count = providerModelCount(provider)
            const parts = [
              entry?.profile?.api,
              count > 0 ? t('settingsProviderModelCount', { count }) : undefined,
            ].filter((part): part is string => part !== undefined && part !== '')
            return parts.length > 0 ? parts.join(' · ') : '—'
          }

          const themeSummary = (): string => themeMode === 'dynamic'
            ? `${t('settingsThemeModeDynamic')} · ${themeDark} / ${themeLight}`
            : `${t('settingsThemeModeSelected')} · ${themeSelected}`
          const themeCustomSummary = (): string => {
            const roles = themeCustom === undefined ? [] : Object.keys(themeCustom)
            return roles.length === 0 ? t('settingsThemeCustomNone') : roles.join(', ')
          }
          const buildSettingsTabs = (): SettingsTab[] => {
            const agentLoopSettings = settings.get(settingsNamespace('agent-loop')) as {
              maxParallelToolCalls?: number
            } | undefined
            const maxParallelToolCalls = agentLoopSettings?.maxParallelToolCalls ?? 10
            const defaultSelection = ctx.agentDefaultModel.currentSelection()
            const titleSettings = settings.get(SESSION_TITLE_SETTINGS_NAMESPACE) as {
              provider?: string
              model?: string
            } | undefined
            const titleProvider = titleSettings?.provider ?? current.options.provider ?? 'auto'
            const titleModel = titleSettings?.model ?? current.options.model ?? 'auto'
            const defaultPermission = displayPermissionName(ctx.permissionPresets.defaultPreset)
            const defaultPreset = (settings.get(settingsNamespace('agent-presets')) as {
              default?: string
            } | undefined)?.default
            const defaultMode = defaultPreset ?? ctx.agentPresets?.defaultId ?? resolved.mode
            const wechatConfig = getWechatConfig()
            const pluginFieldValue = (section: SettingsSection, field: SettingsField): string => {
              const value = settings?.get(settingsNamespace(section.ns))
              const current = readPath(value, field.path)
              if (current === undefined) return '—'
              if (typeof current === 'boolean') return current ? t('settingsOn') : t('settingsOff')
              return String(current)
            }
            return [
              {
                id: 'general',
                label: t('settingsTabGeneral'),
                items: [
                  { value: 'theme', label: t('settingsTheme'), currentValue: themeSummary() },
                  { value: 'theme-custom', label: t('settingsThemeCustom'), currentValue: themeCustomSummary() },
                  { value: 'show-reasoning', label: t('settingsShowReasoning'), currentValue: showReasoning ? t('settingsOn') : t('settingsOff') },
                  { value: 'tool-output-lines', label: t('settingsToolOutputLines'), currentValue: String(maxToolOutputLines) },
                  { value: 'permission', label: t('settingsDefaultPermission'), currentValue: defaultPermission },
                  { value: 'default-mode', label: t('settingsDefaultMode'), currentValue: modeLabel(t, defaultMode, presetNames) },
                ],
              },
              {
                id: 'models-providers',
                label: t('settingsTabModelsProviders'),
                items: [
                  { value: 'provider', label: t('settingsDefaultModel'), currentValue: `${defaultSelection.provider}/${defaultSelection.model}` },
                  {
                    value: 'effort',
                    label: t('settingsDefaultEffort'),
                    currentValue: defaultSelection.reasoningEffort ?? '—',
                    description: t('settingsEffortHint'),
                  },
                  { value: 'title-model', label: t('settingsTitleModel'), currentValue: `${titleProvider}/${titleModel}` },
                  { value: '__providers-header', label: t('settingsConfiguredProviders'), currentValue: '', kind: 'header' },
                  ...providerCatalog.map(entry => ({
                    value: `provider:${entry.id}`,
                    label: entry.name,
                    currentValue: providerCurrentValue(entry.id),
                  })),
                  { value: 'add-provider', label: t('settingsAddProvider'), currentValue: '', kind: 'action' as const },
                ],
              },
              {
                id: 'advanced',
                label: t('settingsTabAdvanced'),
                items: [
                  { value: 'max-parallel-tool-calls', label: t('settingsMaxParallelToolCalls'), currentValue: String(maxParallelToolCalls) },
                  { value: 'left-prompt', label: t('settingsLeftPrompt'), currentValue: leftPrompt },
                  { value: 'right-prompt', label: t('settingsRightPrompt'), currentValue: rightPrompt },
                  { value: 'key-tools', label: t('settingsKeyTools'), currentValue: keyTools },
                  { value: 'key-reasoning', label: t('settingsKeyReasoning'), currentValue: keyReasoning },
                ],
              },
              {
                id: 'wechat',
                label: t('settingsTabWechat'),
                items: wechatConfig === undefined
                  ? [{ value: 'wechat-unavailable', label: t('settingsWechatUnavailable'), currentValue: '' }]
                  : [
                    { value: 'wechat-progress-enabled', label: t('settingsWechatProgressEnabled'), currentValue: wechatConfig.progress.enabled ? t('settingsOn') : t('settingsOff') },
                    { value: 'wechat-progress-interval', label: t('settingsWechatProgressInterval'), currentValue: String(wechatConfig.progress.interval) },
                    { value: 'wechat-notify', label: t('settingsWechatNotify'), currentValue: wechatConfig.notify ? t('settingsOn') : t('settingsOff') },
                  ],
              },
              ...extensions.settingsSections.snapshot().map(section => ({
                id: `plugin:${section.ns}`,
                label: section.title,
                items: section.fields.map(field => ({
                  value: `plugin-field:${section.ns}:${field.path.join('.')}`,
                  label: field.label,
                  currentValue: pluginFieldValue(section, field),
                })),
              })),
            ]
          }
          const themeItems: SelectItem[] = BUILTIN_THEMES.map(theme => ({
            value: theme.id,
            label: `${theme.id} — ${theme.label}`,
            description: `${theme.scheme} · ${theme.description}`,
          }))
          const themeMenuItems = (): SelectItem[] => {
            const modeText = themeMode === 'dynamic' ? t('settingsThemeModeDynamic') : t('settingsThemeModeSelected')
            const rows: SelectItem[] = [
              {
                value: 'mode',
                label: `${t('settingsThemeMode')} — ${modeText}`,
              },
            ]
            if (themeMode === 'dynamic') {
              rows.push(
                { value: 'dark', label: `${t('settingsThemeDark')} — ${themeDark}` },
                { value: 'light', label: `${t('settingsThemeLight')} — ${themeLight}` },
              )
            } else {
              rows.push({ value: 'selected', label: `${t('settingsThemeSelectedItem')} — ${themeSelected}` })
            }
            return rows
          }
          const booleanThemeModeItems: SelectItem[] = [
            { value: 'dynamic', label: t('settingsThemeModeDynamic') },
            { value: 'selected', label: t('settingsThemeModeSelected') },
          ]
          const themeCustomItems = (): SelectItem[] => COLOR_ROLES.map(role => {
            const rgb = themeCustom?.[role]
            return {
              value: role,
              label: `${role} — ${rgb === undefined ? t('settingsThemeCustomNone') : `[${rgb.join(', ')}]`}`,
            }
          })
          const providerItems = (): SelectItem[] => {
            const registeredProviders = typeof ctx.llm.listProviders === 'function' ? ctx.llm.listProviders() : []
            const registeredProviderIds = new Set(registeredProviders.map(entry => entry.id))
            return [
              ...registeredProviders.map(entry => ({
                value: entry.id,
                label: entry.name,
              })),
              ...Object.entries(configuredProviderProfiles())
                .filter(([id]) => !registeredProviderIds.has(id))
                .map(([id, profile]) => ({
                  value: id,
                  label: profile.displayName || id,
                })),
              { value: CUSTOM_PROVIDER, label: t('settingsCustomProvider') },
            ]
          }

          const screen = new SettingsScreen(
            buildSettingsTabs()[0]?.items ?? [],
            t('settingsTitle'),
            palette,
            t,
            Math.max(5, terminal.rows - 4),
            terminal.rows,
          )
          await refreshProviderModelCatalog()
          screen.setTabs(buildSettingsTabs(), t('settingsTitle'))
          let view: SettingsView = 'main'
          let viewVersion = 0
          let pendingProvider: string | undefined
          let pendingModelItems: SelectItem[] = []
          let busy = false

          const showItems = (
            nextView: Exclude<SettingsView, 'main'>,
            items: SelectItem[],
            title: string,
            selectedValue?: string,
          ): void => {
            view = nextView
            viewVersion++
            screen.setItems(items, title, selectedValue)
            ui.requestRender()
          }
          const showMain = (): void => {
            view = 'main'
            viewVersion++
            pendingProvider = undefined
            pendingModelItems = []
            screen.setTabs(buildSettingsTabs(), t('settingsTitle'))
            ui.requestRender()
          }
          const promptCustom = async (title: string, initialValue?: string): Promise<string | undefined> => {
            const value = await showOverlay<string>(
              ui,
              done => new InputDialog(title, palette, done, t, initialValue),
            )
            const trimmed = value?.trim()
            return trimmed === '' ? undefined : trimmed
          }
          const providerPickerItems = (selected: string | undefined): SelectItem[] => {
            const known = new Set([
              ...(typeof ctx.llm.listProviders === 'function' ? ctx.llm.listProviders() : []).map(entry => entry.id),
              ...Object.keys(configuredProviderProfiles()),
            ])
            const items = providerItems()
            if (selected !== undefined && selected !== CUSTOM_PROVIDER && !known.has(selected)) {
              items.unshift({ value: selected, label: `${selected} — ${t('settingsCustomProvider')}` })
              items.splice(1, 0, { value: EDIT_CUSTOM_PROVIDER, label: t('settingsEditCustomProvider') })
            }
            return items
          }
          const modelPickerItems = (
            models: readonly { id: string; name?: string }[],
            selected: string | undefined,
          ): SelectItem[] => {
            const items: SelectItem[] = [
              ...models.map(entry => ({
                value: entry.id,
                label: entry.id,
                description: entry.name === undefined ? undefined : displayText(entry.name),
              })),
              { value: CUSTOM_MODEL, label: t('settingsCustomModel') },
            ]
            if (selected !== undefined && selected !== CUSTOM_MODEL && !models.some(entry => entry.id === selected)) {
              items.unshift({ value: selected, label: `${selected} — ${t('settingsCustomModel')}` })
              items.splice(1, 0, { value: EDIT_CUSTOM_MODEL, label: t('settingsEditCustomModel') })
            }
            return items
          }


          interface ProviderSettingsTarget {
            ns: SettingsNamespace
            path: string[]
            entry: LlmConfigurableProvider
          }
          const providerSettingsTarget = (
            providerId: string,
            editingId?: string,
          ): ProviderSettingsTarget | undefined => {
            const entries = configurableProviderList()
            const entry = entries.find(candidate => candidate.provider === (editingId ?? providerId))
              ?? (editingId === undefined ? entries.find(candidate => candidate.settingsPath.length > 0) : undefined)
            if (entry === undefined || (editingId === undefined && entry.settingsPath.length === 0)) return undefined
            const path = editingId === undefined
              ? [...entry.settingsPath.slice(0, -1), providerId]
              : [...entry.settingsPath]
            return { ns: settingsNamespace(entry.settingsNs), path, entry }
          }

          const providerDiscoveryNamespace = (providerId: string | undefined): string | undefined => {
            const entries = configurableProviderList()
            const entry = entries.find(candidate => candidate.provider === providerId)
              ?? entries.find(candidate => candidate.settingsPath.length > 0)
              ?? entries[0]
            if (entry === undefined || typeof ctx.llm.discoverModels !== 'function') return undefined
            const runtime = ctx.llm as typeof ctx.llm & {
              listModelDiscoveryNamespaces?: () => readonly string[]
            }
            const namespaces = runtime.listModelDiscoveryNamespaces?.()
            if (namespaces !== undefined && !namespaces.includes(entry.settingsNs)) return undefined
            return entry.settingsNs
          }

          const credentialReference = (providerId: string): string => {
            const normalized = providerId.toUpperCase().replace(/[^A-Z0-9]+/g, '_').replace(/^_+|_+$/g, '')
            return `${normalized || 'DSH_PROVIDER'}_API_KEY`
          }

          const saveProvider = async (providerId: string | undefined, draft: ProviderDraft): Promise<void> => {
            if (settings === undefined) throw new Error('settings unavailable')
            const id = draft.id.trim()
            if (id === '') throw new Error(t('providerIdRequired'))
            if (providerId !== undefined && providerId !== id) throw new Error(t('providerIdInvalid'))
            const target = providerSettingsTarget(id, providerId)
            if (target === undefined) throw new Error(t('settingsDiscoveryUnavailable'))
            const nestedProfile = target.entry.settingsPath.length > 0
            const catalogEntry = configurableProviderList().find(entry => entry.provider === id)
            const isCatalogProvider = catalogEntry?.declared === false || !nestedProfile
            if (nestedProfile && !isCatalogProvider && draft.models.length === 0) throw new Error(t('providerModelsRequired'))

            const apiKeyEnv = draft.apiKeyEnv ?? (draft.apiKey.trim() === '' ? undefined : credentialReference(id))
            if (draft.apiKey.trim() !== '') {
              const credentials = ctx.get('credentials') as { set?: (ref: string, value: string) => Promise<void> } | undefined
              if (credentials?.set === undefined || apiKeyEnv === undefined) {
                throw new Error('credentials service unavailable')
              }
              await credentials.set(apiKeyEnv, draft.apiKey.trim())
            }

            type SettingsMutation =
              | { op: 'set'; path: readonly string[]; value: unknown }
              | { op: 'unset'; path: readonly string[] }
            const ops: SettingsMutation[] = []
            const set = (field: string, value: unknown): void => { ops.push({ op: 'set', path: [...target.path, field], value }) }
            const unset = (field: string): void => { ops.push({ op: 'unset', path: [...target.path, field] }) }
            if (nestedProfile) {
              const displayName = draft.name.trim()
              if (displayName === '' || displayName === id) unset('displayName')
              else set('displayName', displayName)
              if (draft.api.trim() === '') unset('api')
              else set('api', draft.api.trim())
              if (draft.models.length === 0) unset('models')
              else set('models', draft.models.map(model => {
                const reasoningEfforts = parseReasoningEffortSetting(model.reasoningEfforts)
                return {
                  id: model.id,
                  ...(model.name === undefined || model.name === '' ? {} : { name: model.name }),
                  ...(typeof model.contextWindow === 'number' ? { contextWindow: model.contextWindow } : {}),
                  ...(typeof model.maxTokens === 'number' ? { maxTokens: model.maxTokens } : {}),
                  ...(reasoningEfforts === undefined ? {} : { reasoningEfforts }),
                }
              }))
            }
            if (draft.baseURL.trim() === '') unset('baseURL')
            else set('baseURL', draft.baseURL.trim())
            if (apiKeyEnv !== undefined) set('apiKeyEnv', apiKeyEnv)
            await settings.mutate(target.ns, ops)
            reasoningEffortCache = undefined
            appendNotice(t('noticeProviderSaved'), 'info')
          }
          const openProviderForm = async (providerId?: string): Promise<void> => {
            if (settings === undefined) {
              appendNotice(t('noticeSettingsUnavailable'), 'warning')
              return
            }
            const existing = providerId === undefined ? undefined : providerCatalog.find(candidate => candidate.id === providerId)
            const profile = providerId === undefined ? undefined : configuredProviderProfiles()[providerId]

            let templateId = ''
            let templateName = ''
            if (providerId === undefined) {
              const addableProviders = configurableProviderList().filter(entry => entry.settingsPath.length > 0)
              const templateItems: SelectItem[] = [
                { value: '', label: t('settingsBlankProvider') },
                ...addableProviders.map(entry => ({
                  value: `preset:${entry.provider}`,
                  label: entry.displayName,
                })),
              ]
              const template = await showOverlay<string>(
                ui,
                done => new SelectDialog(t('settingsProviderTemplate'), templateItems, palette, done),
              )
              if (template === undefined) return
              if (template.startsWith('preset:')) {
                const presetId = template.slice('preset:'.length)
                const preset = addableProviders.find(entry => entry.provider === presetId)
                templateId = presetId
                templateName = preset?.displayName ?? ''
              }
            }

            const id = providerId ?? templateId
            const catalogEntry = configurableProviderList().find(entry => entry.provider === id)
            const isCatalogProvider = catalogEntry?.declared === false || catalogEntry?.settingsPath.length === 0
            const apiKeyEnv = profile?.apiKeyEnv
            const apiKeyConfigured = apiKeyEnv === undefined
              ? false
              : await (async () => {
                const credentials = ctx.get('credentials') as { describe?: (ref: string) => Promise<{ configured: boolean }> } | undefined
                if (credentials?.describe === undefined) return true
                try {
                  return (await credentials.describe(apiKeyEnv)).configured
                } catch {
                  return false
                }
              })()
            const draft: ProviderDraft = {
              id,
              name: profile?.displayName ?? existing?.name ?? templateName,
              api: profile?.api ?? '',
              baseURL: profile?.baseURL ?? '',
              apiKey: '',
              apiKeyEnv: profile?.apiKeyEnv,
              apiKeyConfigured,
              models: profile?.models?.map(model => ({
                id: model.id,
                ...(model.name === undefined ? {} : { name: model.name }),
                ...(model.reasoningEfforts === undefined ? {} : { reasoningEfforts: model.reasoningEfforts }),
                ...(typeof model.contextWindow === 'number' ? { contextWindow: model.contextWindow } : {}),
                ...(typeof model.maxTokens === 'number' ? { maxTokens: model.maxTokens } : {}),
              }))
                ?? modelCatalog.filter(model => model.provider === id).map(model => ({
                  id: model.model,
                })),
            }
            const submitted = await showOverlay<ProviderDraft>(
              ui,
              done => new ProviderForm(
                providerId === undefined ? t('settingsAddProvider') : t('settingsEditProvider'),
                palette,
                t,
                draft,
                done,
                {
                  discover: async (currentDraft) => {
                    if (typeof ctx.llm.discoverModels !== 'function') return undefined
                    const ns = providerDiscoveryNamespace(providerId)
                    if (ns === undefined) return undefined
                    try {
                      const found = await ctx.llm.discoverModels(ns, {
                        ...(providerId !== undefined ? { provider: providerId } : {}),
                        baseURL: currentDraft.baseURL || undefined,
                        apiKey: currentDraft.apiKey || undefined,
                        api: currentDraft.api || undefined,
                      })
                      return found as DiscoveredModel[]
                    } catch (error: unknown) {
                      appendNotice(t('noticeProviderFailed', { error: errorChain(error) }), 'error')

      return undefined
                    }
                  },
                  manageModels: async (currentDraft, discovered) => {
                    const merged = [
                      ...currentDraft.models,
                      ...discovered
                        .filter(model => !currentDraft.models.some(entry => entry.id === model.id))
                        .map(model => ({ id: model.id })),
                    ]
                    return showOverlay<ProviderModelDraft[]>(
                      ui,
                      done => new ModelListDialog(
                        t('settingsModels'),
                        merged,
                        palette,
                        t,
                        done,
                      ),
                    )
                  }
                },
                {
                  idEditable: providerId === undefined,
                  requireModels: !isCatalogProvider,
                  requireApi: !isCatalogProvider,
                  requireBaseURL: !isCatalogProvider,
                }
              ),
            )
            if (submitted === undefined) return
            try {
              await saveProvider(providerId, submitted)
              await refreshProviderModelCatalog()
              if (view === 'main') showMain()
            } catch (error: unknown) {
              const message = t('noticeProviderFailed', { error: errorChain(error) })
              appendNotice(message, 'error')
              chat.addChild(new StaticCardComponent([palette.error(displayText(message))], palette))
              ui.requestRender()
            }
          }

          const handleBack = (): void => {
            if (view === 'title-model') {
              showItems('title-provider', providerItems(), t('modelProvider'), pendingProvider)
              return
            }
            if (view === 'default-model') {
              showItems('default-provider', providerItems(), t('modelProvider'), pendingProvider)
              return
            }
            showMain()
          }

          const handleSelect = async (item: SelectItem): Promise<void> => {
            if (busy) return
            busy = true
            const selectedView = view
            const selectedVersion = viewVersion
            try {
              if (selectedView === 'main') {
                if (item.value === 'theme') {
                  showItems('theme', themeMenuItems(), t('settingsTheme'), 'mode')
                } else if (item.value === 'theme-custom') {
                  showItems('theme-custom', themeCustomItems(), t('settingsThemeCustom'), 'accent')
                } else if (item.value === 'show-reasoning') {
                  const next = !showReasoning
                  await tuiSettings.update({ showReasoning: next })
                  showReasoning = next
                  appendNotice(t('noticeSettingsSaved'), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                } else if (item.value === 'tool-output-lines') {
                  const next = cycleValue(toolOutputLineOptions, maxToolOutputLines)
                  await tuiSettings.update({ maxToolOutputLines: next })
                  maxToolOutputLines = next
                  rebuildTranscript()
                  appendNotice(t('noticeSettingsSaved'), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                } else if (item.value === 'title-model') {
                  const titleSettings = settings.get(SESSION_TITLE_SETTINGS_NAMESPACE) as {
                    provider?: string
                  } | undefined
                  showItems(
                    'title-provider',
                    providerPickerItems(titleSettings?.provider ?? current.options.provider),
                    t('modelProvider'),
                    titleSettings?.provider ?? current.options.provider,
                  )
                } else if (item.value === 'default-mode') {
                  const presets = ctx.agentPresets
                  if (presets === undefined) {
                    appendNotice(t('noticeModeUnavailable'), 'warning')
                    return
                  }
                  const presetsList = (await presets.list()).filter(preset => preset.broken === undefined)
                  const defaultMode = (settings.get(settingsNamespace('agent-presets')) as {
                    default?: string
                  } | undefined)?.default ?? presets.defaultId
                  showItems(
                    'default-mode',
                    presetsList.map(preset => ({
                      value: preset.id,
                      label: preset.name === undefined ? preset.id : `${preset.id} — ${preset.name}`,
                      description: preset.description,
                    })),
                    t('settingsDefaultMode'),
                    defaultMode,
                  )
                } else if (item.value === 'max-parallel-tool-calls') {
                  const currentParallel = (settings.get(settingsNamespace('agent-loop')) as {
                    maxParallelToolCalls?: number
                  } | undefined)?.maxParallelToolCalls ?? 10
                  const next = cycleValue(parallelToolCallOptions, currentParallel)
                  await settings.update(settingsNamespace('agent-loop'), { maxParallelToolCalls: next })
                  appendNotice(t('noticeSettingsSaved'), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                } else if (item.value === 'left-prompt' || item.value === 'right-prompt') {
                  const editLeft = item.value === 'left-prompt'
                  const initial = editLeft ? leftPrompt : rightPrompt
                  const answer = await showOverlay<string>(
                    ui,
                    done => new InputDialog(t('settingsPromptHint'), palette, done, t, initial),
                  )
                  const trimmed = answer?.trim() ?? ''
                  const next = trimmed === ''
                    ? editLeft ? DEFAULT_LEFT_PROMPT : DEFAULT_RIGHT_PROMPT
                    : trimmed
                  if (editLeft) {
                    leftPrompt = next
                    leftTemplate = parseTuiPromptTemplate(displayInlineText(next))
                    directoryStatus = new ComposerDirectoryComponent(leftTemplate, promptValue, palette)
                  } else {
                    rightPrompt = next
                    rightTemplate = parseTuiPromptTemplate(displayInlineText(next))
                    footer = new ComposerFooterComponent(rightTemplate, promptValue, palette)
                  }
                  await tuiSettings.update({ leftPrompt, rightPrompt })
                  rebuildChrome()
                  appendNotice(t('noticePromptSet', { name: editLeft ? t('settingsLeftPrompt') : t('settingsRightPrompt') }), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                  else ui.requestRender()
                  return
                } else if (item.value === 'key-tools' || item.value === 'key-reasoning') {
                  const editTools = item.value === 'key-tools'
                  const initial = editTools ? keyTools : keyReasoning
                  const answer = await showOverlay<string>(
                    ui,
                    done => new InputDialog(t('settingsPromptHint'), palette, done, t, initial),
                  )
                  const trimmed = answer?.trim() ?? ''
                  if (trimmed !== '') {
                    if (editTools) keyTools = trimmed
                    else keyReasoning = trimmed
                    await tuiSettings.update({ keyTools, keyReasoning })
                  }
                  appendNotice(t('noticeKeybindingSet', { name: editTools ? t('settingsKeyTools') : t('settingsKeyReasoning') }), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                  else ui.requestRender()
                  return
                } else if (item.value === 'wechat-progress-enabled') {
                  const wechatConfig = getWechatConfig()
                  if (wechatConfig === undefined) {
                    appendNotice(t('settingsWechatUnavailable'), 'warning')
                    return
                  }
                  setWechatConfig({
                    ...wechatConfig,
                    progress: { ...wechatConfig.progress, enabled: !wechatConfig.progress.enabled },
                  })
                  appendNotice(t('noticeSettingsSaved'), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                } else if (item.value === 'wechat-progress-interval') {
                  const wechatConfig = getWechatConfig()
                  if (wechatConfig === undefined) {
                    appendNotice(t('settingsWechatUnavailable'), 'warning')
                    return
                  }
                  const value = await promptCustom(t('settingsWechatProgressInterval'), String(wechatConfig.progress.interval))
                  if (value === undefined) return
                  const next = Number(value)
                  if (!Number.isInteger(next) || next <= 0) {
                    appendNotice(t('noticeWechatInvalidInterval'), 'warning')
                    return
                  }
                  setWechatConfig({ ...wechatConfig, progress: { ...wechatConfig.progress, interval: next } })
                  appendNotice(t('noticeSettingsSaved'), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                } else if (item.value === 'wechat-notify') {
                  const wechatConfig = getWechatConfig()
                  if (wechatConfig === undefined) {
                    appendNotice(t('settingsWechatUnavailable'), 'warning')
                    return
                  }
                  setWechatConfig({ ...wechatConfig, notify: !wechatConfig.notify })
                  appendNotice(t('noticeSettingsSaved'), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                } else if (item.value === 'wechat-unavailable') {
                  appendNotice(t('settingsWechatUnavailable'), 'warning')
                } else if (item.value.startsWith('plugin-field:')) {
                  appendNotice('Plugin settings editing is read-only in this host preview', 'info')
                } else if (item.value === 'permission') {
                  showItems(
                    'default-permission',
                    permissionCommand.options,
                    t('settingsDefaultPermission'),
                    displayPermissionName(ctx.permissionPresets.defaultPreset),
                  )
                } else if (item.value === 'provider') {
                  showItems(
                    'default-provider',
                    providerPickerItems(ctx.agentDefaultModel.currentSelection().provider),
                    t('modelProvider'),
                    ctx.agentDefaultModel.currentSelection().provider,
                  )
                } else if (item.value === 'effort') {
                  const defaultSelection = ctx.agentDefaultModel.currentSelection()
                  const efforts = await reasoningEffortsFor(defaultSelection)
                  if (selectedVersion !== viewVersion || view !== selectedView) return
                  const choice = chooseReasoningEffort(efforts, defaultSelection.reasoningEffort, '')
                  if (choice.kind === 'unsupported') {
                    appendNotice(t('noticeThinkUnsupported'), 'warning')
                    return
                  }
                  if (choice.kind === 'unknown') {
                    appendNotice(t('noticeThinkUnknown', { name: choice.requested }), 'warning')
                    return
                  }
                  if (choice.kind === 'already') {
                    appendNotice(t('noticeThinkAlready', { name: displayText(choice.effort.name), id: displayText(choice.effort.id) }), 'info')
                    return
                  }
                  const effortId = choice.effort.id as NonNullable<ModelSelection['reasoningEffort']>
                  await ctx.agentDefaultModel.saveSelection({
                    ...defaultSelection,
                    reasoningEffort: effortId,
                  })
                  const live = handles.selectionRef?.current
                  if (
                    live !== undefined
                    && live.provider === defaultSelection.provider
                    && live.model === defaultSelection.model
                    && handles.setReasoningEffort !== undefined
                  ) {
                    await handles.setReasoningEffort(effortId)
                  }
                  appendNotice(t('noticeDefaultEffortSet', { effort: `${choice.effort.id} — ${choice.effort.name}` }), 'info')
                  if (selectedVersion === viewVersion && view === selectedView) showMain()
                } else if (item.value === 'add-provider') {
                  await openProviderForm()
                } else if (item.value.startsWith('provider:')) {
                  await openProviderForm(item.value.slice('provider:'.length))
                }
                return
              }

              if (selectedView === 'theme') {
                if (item.value === 'mode') {
                  showItems('theme-mode', booleanThemeModeItems, t('settingsThemeMode'), themeMode)
                } else if (item.value === 'dark') {
                  showItems('theme-dark', themeItems, t('settingsThemeDark'), themeDark)
                } else if (item.value === 'light') {
                  showItems('theme-light', themeItems, t('settingsThemeLight'), themeLight)
                } else if (item.value === 'selected') {
                  showItems('theme-selected', themeItems, t('settingsThemeSelectedItem'), themeSelected)
                }
                return
              }

              if (selectedView === 'theme-mode') {
                themeMode = item.value === 'dynamic' ? 'dynamic' : 'selected'
                await tuiSettings.update({ themeMode, themeDark, themeLight, themeSelected })
                Object.assign(palette, createPalette(resolved.theme.color, currentScheme, truecolor, themeOverride()))
                Object.assign(mdTheme, markdownTheme(palette))
                rebuildTranscript()
                setStatus(current.status)
                appendNotice(t('noticeSettingsSaved'), 'info')
                if (selectedVersion === viewVersion && view === selectedView) showMain()
                else ui.requestRender()
                return
              }

              if (selectedView === 'theme-dark' || selectedView === 'theme-light' || selectedView === 'theme-selected') {
                if (selectedView === 'theme-dark') themeDark = item.value
                if (selectedView === 'theme-light') themeLight = item.value
                if (selectedView === 'theme-selected') themeSelected = item.value
                await tuiSettings.update({ themeMode, themeDark, themeLight, themeSelected })
                Object.assign(palette, createPalette(resolved.theme.color, currentScheme, truecolor, themeOverride()))
                Object.assign(mdTheme, markdownTheme(palette))
                rebuildTranscript()
                setStatus(current.status)
                appendNotice(t('noticeSettingsSaved'), 'info')
                if (selectedVersion === viewVersion && view === selectedView) showMain()
                else ui.requestRender()
                return
              }

              if (selectedView === 'theme-custom') {
                const role = item.value
                const currentRgb = themeCustom?.[role]
                const initial = currentRgb === undefined ? '' : currentRgb.join(', ')
                const answer = await showOverlay<string>(
                  ui,
                  done => new InputDialog(t('settingsThemeCustomEditHint'), palette, done, t, initial),
                )
                const trimmed = answer?.trim() ?? ''
                const next = { ...(themeCustom ?? {}) } as Record<string, number[]>
                if (trimmed === '') {
                  delete next[role]
                } else {
                  const parts = trimmed.split(',').map(part => Number(part.trim()))
                  if (parts.length !== 3 || parts.some(part => !Number.isFinite(part) || part < 0 || part > 255)) {
                    appendNotice(t('noticeThemeCustomInvalid'), 'warning')
                    if (selectedVersion === viewVersion && view === selectedView) showMain()
                    else ui.requestRender()
                    return
                  }
                  next[role] = [parts[0]!, parts[1]!, parts[2]!]
                }
                themeCustom = Object.keys(next).length === 0 ? undefined : next
                await tuiSettings.update({ themeMode, themeDark, themeLight, themeSelected, themeCustom })
                Object.assign(palette, createPalette(resolved.theme.color, currentScheme, truecolor, themeOverride()))
                Object.assign(mdTheme, markdownTheme(palette))
                rebuildTranscript()
                setStatus(current.status)
                appendNotice(t('noticeThemeCustomSet', { name: role }), 'info')
                if (selectedVersion === viewVersion && view === selectedView) showMain()
                else ui.requestRender()
                return
              }

              if (selectedView === 'default-mode') {
                await settings.update(settingsNamespace('agent-presets'), { default: item.value })
                appendNotice(t('noticeDefaultModeSet', { mode: modeLabel(t, item.value, presetNames) }), 'info')
                if (selectedVersion === viewVersion && view === selectedView) showMain()
                return
              }


              if (selectedView === 'title-provider') {
                const titleSettings = settings.get(SESSION_TITLE_SETTINGS_NAMESPACE) as {
                  provider?: string
                  model?: string
                } | undefined
                const savedProvider = titleSettings?.provider ?? current.options.provider
                const provider = item.value === CUSTOM_PROVIDER
                  ? await promptCustom(t('modelProvider'))
                  : item.value === EDIT_CUSTOM_PROVIDER
                    ? await promptCustom(t('settingsEditCustomProvider'), savedProvider)
                    : item.value
                if (provider === undefined) return
                const models = await listModelsForProvider(provider)
                if (selectedVersion !== viewVersion || view !== selectedView) return
                pendingProvider = provider
                const savedModel = titleSettings?.provider === provider ? titleSettings.model : undefined
                pendingModelItems = modelPickerItems(models, savedModel)
                showItems(
                  'title-model',
                  pendingModelItems,
                  t('modelTitle', { provider: pendingProvider }),
                  savedModel,
                )
                return
              }

              if (selectedView === 'title-model') {
                if (pendingProvider === undefined) return
                const titleSettings = settings.get(SESSION_TITLE_SETTINGS_NAMESPACE) as {
                  provider?: string
                  model?: string
                } | undefined
                const savedModel = titleSettings?.provider === pendingProvider ? titleSettings.model : undefined
                const model = item.value === CUSTOM_MODEL
                  ? await promptCustom(t('modelTitle', { provider: pendingProvider }))
                  : item.value === EDIT_CUSTOM_MODEL
                    ? await promptCustom(t('settingsEditCustomModel'), savedModel)
                    : item.value
                if (model === undefined) return
                await settings.update(SESSION_TITLE_SETTINGS_NAMESPACE, { provider: pendingProvider, model })
                const sessionTitle = ctx.get('sessionTitle')
                if (sessionTitle !== undefined) void sessionTitle.refresh(current.session).catch(() => undefined)
                appendNotice(t('noticeTitleModelSet', { provider: pendingProvider, model }), 'info')
                if (selectedVersion === viewVersion && view === selectedView) showMain()
                return
              }

              if (selectedView === 'default-permission') {
                const registryName = registryPermissionName(item.value)
                await settings.update(PERMISSION_SETTINGS_NAMESPACE, { defaultPreset: registryName })
                appendNotice(t('noticeDefaultPermissionSet', { permission: displayPermissionName(registryName) }), 'info')
                if (selectedVersion === viewVersion && view === selectedView) showMain()
                return
              }

              if (selectedView === 'default-provider') {
                const defaultSelection = ctx.agentDefaultModel.currentSelection()
                const savedProvider = defaultSelection.provider
                const provider = item.value === CUSTOM_PROVIDER
                  ? await promptCustom(t('modelProvider'))
                  : item.value === EDIT_CUSTOM_PROVIDER
                    ? await promptCustom(t('settingsEditCustomProvider'), savedProvider)
                    : item.value
                if (provider === undefined) return
                const models = await listModelsForProvider(provider)
                if (selectedVersion !== viewVersion || view !== selectedView) return
                pendingProvider = provider
                const savedModel = defaultSelection.provider === provider ? defaultSelection.model : undefined
                pendingModelItems = modelPickerItems(models, savedModel)
                showItems(
                  'default-model',
                  pendingModelItems,
                  t('modelTitle', { provider: pendingProvider }),
                  savedModel,
                )
                return
              }

              if (selectedView === 'default-model') {
                if (pendingProvider === undefined) return
                const defaultSelection = ctx.agentDefaultModel.currentSelection()
                const savedModel = defaultSelection.provider === pendingProvider ? defaultSelection.model : undefined
                const model = item.value === CUSTOM_MODEL
                  ? await promptCustom(t('modelTitle', { provider: pendingProvider }))
                  : item.value === EDIT_CUSTOM_MODEL
                    ? await promptCustom(t('settingsEditCustomModel'), savedModel)
                    : item.value
                if (model === undefined) return
                if (selectedVersion !== viewVersion || view !== selectedView) return
                let reasoningEffort: ModelSelection['reasoningEffort']
                try {
                  const info = await ctx.llm.resolveModelInfo(pendingProvider, model)
                  const efforts = info.reasoning?.efforts ?? []
                  const advertised = info.reasoning?.defaultEffort
                  const reuse = defaultSelection.reasoningEffort !== undefined
                    && efforts.some(effort => effort.id === defaultSelection.reasoningEffort)
                  reasoningEffort = (reuse
                    ? defaultSelection.reasoningEffort
                    : advertised !== undefined && efforts.some(effort => effort.id === advertised)
                      ? advertised as NonNullable<ModelSelection['reasoningEffort']>
                      : efforts[0]?.id as ModelSelection['reasoningEffort'])
                } catch {
                  reasoningEffort = undefined
                }
                const selectedModel: ModelSelection = {
                  provider: pendingProvider,
                  model,
                  ...(reasoningEffort === undefined ? {} : { reasoningEffort }),
                }
                await ctx.agentDefaultModel.saveSelection(selectedModel)
                appendNotice(t('noticeDefaultModelSet', { provider: selectedModel.provider, model: selectedModel.model }), 'info')
                if (selectedVersion === viewVersion && view === selectedView) showMain()
                return
              }
            } catch (error: unknown) {
              appendNotice(t('noticeSettingsFailed', { error: errorChain(error) }), 'error')
            } finally {
              busy = false
            }
          }

          screen.onSelect = (item) => {
            void handleSelect(item)
          }
          screen.onBack = handleBack

          const handle = pushOverlay(ui, screen)
          const { promise, resolve } = Promise.withResolvers<void>()
          screen.onClose = () => {
            handle.hide()
            resolve()
          }
          await promise
          ui.requestRender()
        } catch (error: unknown) {
          appendNotice(t('noticeSettingsFailed', { error: errorChain(error) }), 'error')
        }
        return
      }

      if (line === '/theme' || line.startsWith('/theme ')) {
        const arg = line.slice('/theme'.length).trim()
        const parts = arg.split(/\s+/).filter(Boolean)
        const applyTheme = async (): Promise<void> => {
          if (tuiSettings !== undefined) {
            try {
              await tuiSettings.update({ themeMode, themeDark, themeLight, themeSelected })
            } catch (error: unknown) {
              appendNotice(t('noticeSettingsFailed', { error: errorChain(error) }), 'error')
              return
            }
          }
          Object.assign(palette, createPalette(resolved.theme.color, currentScheme, truecolor, themeOverride()))
          Object.assign(mdTheme, markdownTheme(palette))
          rebuildTranscript()
          setStatus(current.status)
          ui.requestRender()
        }
        if (parts.length === 0) {
          const modeText = themeMode === 'dynamic' ? t('settingsThemeModeDynamic') : t('settingsThemeModeSelected')
          const rows = [
            palette.bold(palette.accent(`${t('themeCurrent')}: ${modeText}`)),
            '',
            ...(themeMode === 'dynamic'
              ? [
                  `${palette.dim(t('settingsThemeDark'))}  ${themeDark}`,
                  `${palette.dim(t('settingsThemeLight'))}  ${themeLight}`,
                ]
              : [`${palette.dim(t('settingsThemeSelectedItem'))}  ${themeSelected}`]),
            '',
            ...BUILTIN_THEMES.map(theme =>
              ` ${theme.id} — ${theme.label}: ${theme.scheme}`),
            ...themeCustom === undefined
              ? [palette.dim(` ${t('themeCustomNote')}`)]
              : [palette.dim(` ${t('themeCurrent')}: + custom overrides`), ''],
          ]
          chat.addChild(new StaticCardComponent(rows, palette))
          ui.requestRender()
          return
        }
        const command = parts[0]!
        if (command === 'mode') {
          const next = parts[1]
          if (next !== 'dynamic' && next !== 'selected') {
            appendNotice(t('noticeThemeModeUnknown', { name: next ?? '' }), 'warning')
            return
          }
          themeMode = next
          await applyTheme()
          appendNotice(t('noticeThemeModeSet', { mode: t(next === 'dynamic' ? 'settingsThemeModeDynamic' : 'settingsThemeModeSelected') }), 'info')
          return
        }
        if (command === 'dark' || command === 'light') {
          const id = parts[1]
          if (id === undefined || findTheme(id) === undefined) {
            appendNotice(t('noticeThemeUnknown', { name: id ?? '' }), 'warning')
            return
          }
          themeMode = 'dynamic'
          if (command === 'dark') themeDark = id
          if (command === 'light') themeLight = id
          await applyTheme()
          appendNotice(command === 'dark' ? t('noticeThemeDarkSet', { name: id }) : t('noticeThemeLightSet', { name: id }), 'info')
          return
        }
        const known = findTheme(arg)
        if (known === undefined) {
          appendNotice(t('noticeThemeUnknown', { name: arg }), 'warning')
          return
        }
        themeMode = 'selected'
        themeSelected = known.id
        await applyTheme()
        appendNotice(t('noticeThemeSet', { name: themeSelected }), 'info')
        return
      }
      if (line === '/help' || line.startsWith('/help ')) {
        const commandRows = ctx.commands.list(current).map(command => {
          const permission = command.name === 'permission'
          const hint = permission ? permissionCommand.argumentHint : command.input?.hint
          const description = permission ? t('helpPermission') : command.description
          return `/${command.name}${hint === undefined ? '' : ` ${hint}`} — ${description}`
        })
        const rows = [
          palette.bold(palette.accent(t('helpShortcuts'))),
          '',
          `${palette.dim('Esc')}  ${t('helpEsc')}`,
          `${palette.dim('Enter')}  ${t('helpEnter')}`,
          `${palette.dim('Ctrl+C')}  ${t('helpCtrlC')}`,
          `${palette.dim('Ctrl+D')}  ${t('helpCtrlD')}`,
          `${palette.dim('Ctrl+T')}  ${t('helpCtrlT')}`,
          `${palette.dim('Ctrl+O')}  ${t('helpCtrlO')}`,
          `${palette.dim('Ctrl+Shift+O')}  ${t('helpCtrlShiftO')}`,
          `${palette.dim('Alt+L')}  ${t('helpAltL')}`,
          `${palette.dim('Alt+Up')}  ${t('helpAltUp')}`,
          `${palette.dim('Ctrl+P / Shift+Ctrl+P')}  ${t('helpCtrlP')}`,
          `${palette.dim('Alt+M')}  ${t('helpAltM')}`,
          `${palette.dim('Ctrl+Q / Ctrl+Enter')}  ${t('helpCtrlQ')}`,
          '',
          palette.bold(palette.accent(t('helpCommands'))),
          `/palette — ${t('helpPalette')}`,
          `/help — ${t('helpHelp')}`,
          `/model — ${t('helpModel')}`,
          `/think [level] — ${t('helpThink')}`,
          `/new — ${t('helpNew')}`,
          `/resume — ${t('helpResume')}`,
          `/details — ${t('helpDetails')}`,
          `/skills — ${t('helpSkills')}`,
          `/skill:<name> — ${t('helpSkillInvoke')}`,
          `/mode — ${t('helpMode')}`,
          `/theme — ${t('helpTheme')}`,
          `/settings — ${t('helpSettings')}`,
          ...commandRows,
        ]
        chat.addChild(new StaticCardComponent(rows, palette))
        ui.requestRender()
        return
      }
      if (line.trim() === '/compact' || line.startsWith('/compact ')) {
        if (pluginHost !== undefined) {
          const decision = await pluginHost.runDecision('tui/compact', {
            sessionId: String(current.id),
            cwd: current.session.header.cwd ?? process.cwd(),
          })
          if (decision !== null && typeof decision === 'object' && (decision as { cancel?: unknown }).cancel === true) {
            const reason = (decision as { reason?: unknown }).reason
            appendNotice(typeof reason === 'string' && reason !== '' ? reason : 'Compaction cancelled by a plugin', 'warning')
            return
          }
        }
      }
      // dsh rc8 added an `images` parameter to commands.execute. Pass an empty
      // image batch so the same source compiles and runs against rc6 and rc8.
      // Keep the method bound: CommandRuntime.execute reads `this.view(agent)`.
      const executeCommand = ctx.commands.execute.bind(ctx.commands) as unknown as (
        agent: Agent,
        line: string,
        images: readonly unknown[],
        signal: AbortSignal,
      ) => ReturnType<typeof ctx.commands.execute>
      const execution = await executeCommand(current, line, [], new AbortController().signal)
      if (execution === undefined) {
        appendNotice(t('noticeUnknownCommand', {
          name: line.slice(1, line.indexOf(' ') === -1 ? undefined : line.indexOf(' ')),
        }), 'warning')
        return
      }
      const result = execution.result
      const resultText = result.text?.replaceAll(FULL_ACCESS_REGISTRY_NAME, FULL_ACCESS_UI_NAME)
      const isWechatCommand = line.startsWith('/wechat-')
      if (isWechatCommand && resultText !== undefined && resultText !== '') {
        // 微信桥命令结果与二维码/日志一样持久化到 transcript，避免自动消失。
        const color = result.kind === 'error' ? palette.error : palette.text
        chat.addChild(new StaticCardComponent(
          displayText(resultText).split('\n').map(row => color(row)),
          palette,
        ))
        ui.requestRender()
        return
      }
      if (result.kind === 'error') {
        appendNotice(resultText ?? '', 'error')
        if (line.trim() === '/compact') {
          const cause = latestCompactionError()
          if (cause !== undefined && cause !== '' && !String(resultText ?? '').includes(cause)) {
            appendNotice(t('noticeCompactionCause', { cause }), 'error')
          }
          if (cause !== undefined && cause.includes('400 status code')) {
            appendNotice(t('noticeCompaction400Hint'), 'warning')
          } else {
            appendNotice(t('noticeCompactionHint'), 'warning')
          }
        }
      } else if (resultText !== undefined && resultText !== '') {
        appendNotice(resultText, 'info')
      }
    }

    const submitText = (text: string): void => {
      const current = agent
      if (current === undefined) return
      const trimmed = text.trim()
      if (trimmed === '') return
      editor.addToHistory(text)
      if (trimmed.startsWith('/')) {
        // A command handler (e.g. /compact) may reject after logging a partial
        // attempt; surface it as a notice instead of an unhandled rejection.
        void runCommand(trimmed).catch((error: unknown) => {
          try {
            const message = errorChain(error)
            if (trimmed === '/compact') {
              const cause = latestCompactionError()
              if (cause !== undefined && cause !== '' && !message.includes(cause)) {
                appendNotice(t('noticeCompactionCause', { cause }), 'error')
              }
              if (cause !== undefined && cause.includes('400 status code')) {
                appendNotice(t('noticeCompaction400Hint'), 'warning')
              } else {
                appendNotice(t('noticeCompactionHint'), 'warning')
              }
            }
            appendNotice(t('noticeCommandFailed', { error: message }), 'error')
          } catch {
            appendNotice(t('noticeCommandFailed', { error: error instanceof Error ? error.message : String(error) }), 'error')
          }
        })
        return
      }
      // While the agent is generating, Enter defaults to the interjection
      // queue: the message is steered into the next step boundary instead of
      // opening a brand-new follow-up turn.
      if (current.status === 'running') {
        enqueueInterjection(text)
        return
      }
      const refreshTitle = (): void => {
        const sessionTitle = ctx.get('sessionTitle')
        if (sessionTitle !== undefined && foldSessionTitle(current.session.events) === undefined) {
          void sessionTitle.refresh(current.session).catch(() => undefined)
        }
      }
      // `@[label](dsh-session:…)` mentions lift another session's surface
      // into this one: prepare attaches the snapshot and injects the
      // additional context without a model turn.
      const parsed = parseSessionReferenceText(text)
      if (parsed.references.length > 0) {
        void (async () => {
          try {
            const prepared = await ctx.sessionReferenceResolver.prepare(
              current,
              [{ type: 'text', text: parsed.text }],
              parsed.references,
            )
            // Inject first (queues context without waking), then follow up:
            // the waking driver claims both at the next pre-step, so the
            // model sees the referenced snapshot from the first step.
            if (prepared.additionalContext !== undefined) {
              current.inject(prepared.additionalContext)
            }
            recordActivePreset(current)
            current.followup(createUserMessage({ content: prepared.content, source: { kind: 'user' } }))
            refreshTitle()
          } catch (error: unknown) {
            appendNotice(t('noticeReferenceFailed', { error: errorChain(error) }), 'error')
          }
        })()
        return
      }
      recordActivePreset(current)
      current.followup(createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'user' },
      }))
      refreshTitle()
    }

    editor.onSubmit = (text: string): void => {
      const current = agent
      if (current === undefined) return
      if (text.trim() === '') return
      const hasInputInterceptors = pluginHost?.activeDecisionSubscriptions().some(subscription => subscription.event === 'tui/input') ?? false
      if (!hasInputInterceptors) {
        submitText(text)
        return
      }
      void (async () => {
        const decision = await pluginHost!.runDecision('tui/input', {
          text,
          delivery: current.status === 'running' ? 'steer' : 'followup',
          sessionId: String(current.id),
          cwd: current.session.header.cwd ?? process.cwd(),
        })
        if (decision !== null && typeof decision === 'object') {
          const record = decision as { cancel?: unknown; handled?: unknown; text?: unknown; reason?: unknown; notice?: unknown }
          if (record.cancel === true) {
            appendNotice(typeof record.reason === 'string' && record.reason !== '' ? record.reason : 'Input cancelled by a plugin', 'warning')
            return
          }
          if (record.handled === true) {
            appendNotice(typeof record.notice === 'string' && record.notice !== '' ? record.notice : 'Input handled by a plugin', 'info')
            return
          }
          if (typeof record.text === 'string' && record.text.trim() !== '') {
            submitText(record.text.trim())
            return
          }
        }
        submitText(text)
      })()
    }

    // First Ctrl+C clears the display (or interrupts a running turn); a second
    // press within the window exits through the launcher's bounded appExit hook.
    let exitArmed = false
    let exitArmTimer: NodeJS.Timeout | undefined
    const EXIT_ARM_WINDOW_MS = 2000

    const offKeys = ui.addInputListener((data) => {
      const mouseMatch = /^\x1b\[<(\d+);(\d+);(\d+)([Mm])/.exec(data)
      if (mouseMatch !== null) {
        if (!ui.hasOverlay()) {
          const button = Number(mouseMatch[1])
          if (button === 64) scrollTranscriptLines(-3) // wheel up
          else if (button === 65) scrollTranscriptLines(3) // wheel down
          return { consume: true }
        }
        return undefined
      }

      // OMP-style Esc: interrupt the running turn. Overlays keep Esc for cancel.
      if (matchesKey(data, 'escape')) {
        if (!ui.hasOverlay() && agent?.status === 'running') {
          agent.cancel({ kind: 'user' })
          return { consume: true }
        }
        return undefined
      }

      // OMP-style Ctrl+C with the legacy double-press exit retained: overlays
      // keep Ctrl+C for cancel/selection, a running turn is interrupted, an
      // idle screen is cleared, and a second press within the window exits.
      if (matchesKey(data, 'ctrl+c')) {
        if (ui.hasOverlay()) return undefined
        if (exitArmed) {
          clearTimeout(exitArmTimer)
          exitArmed = false
          ctx.appExit?.(0)
          return { consume: true }
        }
        exitArmed = true
        clearTimeout(exitArmTimer)
        exitArmTimer = setTimeout(() => {
          exitArmed = false
        }, EXIT_ARM_WINDOW_MS)
        if (agent?.status === 'running') {
          agent.cancel({ kind: 'user' })
        } else {
          resetDisplay()
          appendNotice(t('noticeExitHint'), 'info')
        }
        return { consume: true }
      }

      // OMP-style Ctrl+D: exit when the editor is empty; otherwise keep the
      // editor's delete-forward behavior.
      if (matchesKey(data, 'ctrl+d')) {
        if (!ui.hasOverlay() && editor.getText().trim() === '') {
          ctx.appExit?.(0)
          return { consume: true }
        }
        return undefined
      }

      // OMP-style Ctrl+Q / Ctrl+Enter: submit the current draft even while
      // the agent is running.
      if (matchesKey(data, 'ctrl+q') || matchesKey(data, 'ctrl+enter')) {
        if (!ui.hasOverlay() && editor.getText().trim() !== '') {
          return { data: '\r' }
        }
        return undefined
      }

      // Global app shortcuts only when no overlay owns keyboard focus.
      if (!ui.hasOverlay()) {
        // Alt+Up: edit the oldest still-pending interjection. Entering edit
        // cancels its queued state in the agent inbox before it takes effect.
        if (matchesKey(data, 'alt+up' as Parameters<typeof matchesKey>[1])) {
          const current = agent
          const item = pendingInterjections.shift()
          if (current !== undefined && item !== undefined) {
            try {
              const stillPending = current.inbox.remove(item.message.id)
              if (!stillPending) {
                refreshInterjectionIndicator()
                updateStatusValues()
                appendNotice(t('noticeInterjectionAlreadyEffective'), 'warning')
                ui.requestRender()
                return { consume: true }
              }
              editor.setText(item.text)
              ui.setFocus(editor)
              refreshInterjectionIndicator()
              updateStatusValues()
              appendNotice(t('noticeInterjectionEdit'), 'info')
              ui.requestRender()
              return { consume: true }
            } catch (error: unknown) {
              pendingInterjections.unshift(item)
              refreshInterjectionIndicator()
              appendNotice(t('noticeInterjectionFailed', { error: errorChain(error) }), 'error')
              ui.requestRender()
              return { consume: true }
            }
          }
          return undefined
        }
        if (matchesKey(data, keyTools as Parameters<typeof matchesKey>[1])) {
          expandTools()
          return { consume: true }
        }
        if (matchesKey(data, 'ctrl+shift+o' as Parameters<typeof matchesKey>[1])) {
          toggleToolActivity()
          return { consume: true }
        }
        if (matchesKey(data, keyReasoning as Parameters<typeof matchesKey>[1])) {
          toggleReasoning()
          return { consume: true }
        }
        if (matchesKey(data, 'alt+l' as Parameters<typeof matchesKey>[1])) {
          resetDisplay()
          return { consume: true }
        }
        if (matchesKey(data, 'alt+m' as Parameters<typeof matchesKey>[1])) {
          void runCommand('/model')
          return { consume: true }
        }
        if (matchesKey(data, 'ctrl+p' as Parameters<typeof matchesKey>[1])) {
          void cycleModel(1)
          return { consume: true }
        }
        if (matchesKey(data, 'shift+ctrl+p' as Parameters<typeof matchesKey>[1])) {
          void cycleModel(-1)
          return { consume: true }
        }
        if (matchesKey(data, 'pageup' as Parameters<typeof matchesKey>[1])) {
          scrollTranscriptPage(-1)
          return { consume: true }
        }
        if (matchesKey(data, 'pagedown' as Parameters<typeof matchesKey>[1])) {
          scrollTranscriptPage(1)
          return { consume: true }
        }
        // While reading history, Down arrow jumps straight back to the live
        // latest message; otherwise it keeps its normal editor behavior.
        if (matchesKey(data, 'down' as Parameters<typeof matchesKey>[1]) && !chat.followLatest) {
          chat.followLatest = true
          chat.lineOffset = Math.max(0, chat.lastTotalLines - chat.lastViewportLines)
          ui.requestRender()
          return { consume: true }
        }
        // Community plugin shortcuts (tuiShortcuts): built-ins above always win.
        for (const registration of extensions.shortcuts.snapshot()) {
          if (matchesKey(data, registration.combo as Parameters<typeof matchesKey>[1])) {
            extensions.shortcuts.dispatch(registration.combo)
            return { consume: true }
          }
        }
      }

      return undefined
    })

    // --- mount: run once the configured agent is live -------------------------
    let offEvent: (() => void) | undefined
    let offStatus: (() => void) | undefined
    let offScheme: (() => void) | undefined
    let offModelSelection: (() => void) | undefined
    let offInbox: (() => void) | undefined
    let offWechatOutput: (() => void) | undefined
    let activeHandle: AgentHandle | undefined
    let mounted = false

    const mount = (liveAgent: Agent): void => {
      if (mounted) return
      uiMode = modeForSession(liveAgent.session, resolveDefaultMode())
      mounted = true
      agent = liveAgent
      // 让微信桥跟随 TUI 当前会话；/resume、/new 等切换也走 activateAgent。
      setActiveAgent(liveAgent)
      this.foregroundAgentImpl = () => agent

      const selectionFor = (target: Agent): ModelSelection => {
        const configured = ctx.agentDefaultModel.currentSelection()
        const fallback: ModelSelection = {
          provider: target.options.provider ?? configured.provider,
          model: target.options.model ?? configured.model,
          ...configured.reasoningEffort === undefined ? {} : { reasoningEffort: configured.reasoningEffort },
        }
        return resolveSessionModelSelection(
          target.session.requestHeader(),
          fallback,
          resolved.defaultReasoningEffort,
        )
      }

      // A historical session continues its last actual request route. A new
      // session starts from the configured Agent route and dsh default model.
      const initialSelection = selectionFor(liveAgent)
      const selectionRef: ModelSelectionRef = { current: initialSelection, assembled: undefined }
      offModelSelection = installModelSelection(liveAgent.ctx, selectionRef)
      const commitSelection = async (selection: ModelSelection): Promise<void> => {
        selectionRef.current = selection
        refreshContextEstimate(agent ?? liveAgent, selection)
        await ctx.agentDefaultModel.saveSelection(selection)
      }
      const saveSelection = async (selection: ModelSelection): Promise<void> => {
        await commitSelection(selection)
        appendNotice(t('noticeModelSet', { provider: selection.provider, model: selection.model }), 'info')
      }
      const setReasoningEffort = async (effort: NonNullable<ModelSelection['reasoningEffort']>): Promise<void> => {
        const selection = selectionRef.current
        if (selection === undefined) throw new Error('model selection unavailable')
        await commitSelection({ ...selection, reasoningEffort: effort })
      }

      const updateTitle = (): void => {
        const current = agent
        const folded = current === undefined ? undefined : foldSessionTitle(current.session.events)
        terminal.setTitle(folded === undefined ? resolved.title : `${folded.title} — ${resolved.title}`)
      }

      header = new HeaderComponent(
        liveAgent,
        () => undefined,
        palette,
        resolved.theme.color && truecolor,
        t,
        () => selectionRef.current,
      )

      // Slash commands + @ / path completions (pi-tui's combined provider
      // scans the workspace rooted at the session cwd).
      const workspace = liveAgent.session.header.cwd ?? process.cwd()
      refreshGitBranch(workspace)
      const modeOptions: AutocompleteItem[] = [
        { value: 'standard', label: `standard — ${t('modeStandard')}`, description: t('modeStandardHint') },
        { value: 'minimal', label: `minimal — ${t('modeMinimal')}`, description: t('modeMinimalHint') },
        { value: 'code', label: `code — ${t('modeCode')}`, description: t('modeCodeHint') },
        { value: 'cordis', label: `cordis — ${t('modeCordis')}`, description: t('modeCordisHint') },
      ]
      const themeOptions: AutocompleteItem[] = BUILTIN_THEMES.map(theme => ({
        value: theme.id,
        label: `${theme.id} — ${theme.label}`,
        description: `${theme.scheme} · ${theme.description}`,
      }))
      const commandEntries: SlashCommand[] = [
        { name: 'palette', description: t('cmdPalette') },
        { name: 'help', description: t('cmdHelp') },
        { name: 'model', description: t('cmdModel') },
        {
          name: 'think',
          description: t('cmdThink'),
          argumentHint: '<level>',
          getArgumentCompletions: async (prefix) => {
            const selection = selectionRef.current
            if (selection === undefined) return null
            try {
              const options: AutocompleteItem[] = (await reasoningEffortsFor(selection)).map(effort => ({
                value: effort.id,
                label: `${effort.id} — ${effort.name}`,
                description: effort.description,
              }))
              return filterCommandOptions(options, prefix)
            } catch {
              return null
            }
          },
        },
        { name: 'new', description: t('cmdNew') },
        {
          name: 'resume',
          description: t('cmdResume'),
          argumentHint: '<sessionId>',
          getArgumentCompletions: async (prefix) => {
            try {
              const records = await ctx.sessionQuery.listSessions()
              const options: AutocompleteItem[] = filterProjectSessions(records, workspace)
                .map(record => {
                  const id = String(record.header.id)
                  const created = new Date(record.header.createdAt ?? 0).toLocaleString()
                  return { value: id, label: id, description: created }
                })
              return filterCommandOptions(options, prefix)
            } catch {
              return null
            }
          },
        },
        { name: 'details', description: t('cmdDetails') },
        { name: 'skills', description: t('cmdSkills') },
        {
          name: 'mode',
          description: t('cmdMode'),
          argumentHint: '<standard|minimal|code|cordis|user preset>',
          getArgumentCompletions: async (prefix) => {
            const roster = ctx.agentPresets
            let extra: AutocompleteItem[] = []
            if (roster !== undefined) {
              try {
                const shipped = new Set(modeOptions.map(option => option.value))
                extra = (await roster.list())
                  .filter(preset => preset.broken === undefined && !shipped.has(preset.id))
                  .map(preset => ({
                    value: preset.id,
                    label: `${preset.id} — ${preset.name ?? preset.id}`,
                    description: preset.description,
                  }))
              } catch {
                // Roster unreadable: shipped set only.
              }
            }
            return filterCommandOptions([...modeOptions, ...extra], prefix)
          },
        },
        {
          name: 'theme',
          description: t('cmdTheme'),
          argumentHint: '<mode|dark|light|theme id>',
          getArgumentCompletions: (prefix) => {
            const tokens = prefix.trim().split(/\s+/).filter(Boolean)
            const themeModeOptions: AutocompleteItem[] = [
              { value: 'mode dynamic', label: `mode dynamic — ${t('settingsThemeModeDynamic')}` },
              { value: 'mode selected', label: `mode selected — ${t('settingsThemeModeSelected')}` },
              { value: 'dark', label: `dark — ${t('settingsThemeDark')}` },
              { value: 'light', label: `light — ${t('settingsThemeLight')}` },
            ]
            if (tokens.length === 0) return themeModeOptions
            if (tokens.length === 1) return filterCommandOptions([...themeModeOptions, ...themeOptions], prefix)
            if (tokens[0] === 'mode' && tokens.length === 2) {
              return filterCommandOptions([
                { value: 'dynamic', label: t('settingsThemeModeDynamic') },
                { value: 'selected', label: t('settingsThemeModeSelected') },
              ], tokens[1] ?? '')
            }
            if ((tokens[0] === 'dark' || tokens[0] === 'light') && tokens.length === 2) {
              return filterCommandOptions(themeOptions, tokens[1] ?? '')
            }
            return null
          },
        },
        { name: 'settings', description: t('cmdSettings') },
        ...ctx.commands.list(liveAgent).map((command): SlashCommand => {
          if (command.name === 'permission') {
            return {
              name: command.name,
              description: t('cmdPermission'),
              argumentHint: permissionCommand.argumentHint,
              getArgumentCompletions: prefix => filterCommandOptions(permissionCommand.options, prefix),
            }
          }
          return {
            name: command.name,
            description: command.description,
            ...command.input === undefined ? {} : { argumentHint: command.input.hint },
          }
        }),
      ]
      const skillCommandNames = new Set<string>()
      const refreshSkillCommands = async (): Promise<void> => {
        try {
          const snapshot = await ctx.skills.snapshot({ cwd: workspace })
          const seen = new Set<string>()
          for (const skill of snapshot.skills) {
            const name = `skill:${skill.name}`
            seen.add(name)
            if (!skillCommandNames.has(name)) {
              skillCommandNames.add(name)
              commandEntries.push({ name, description: t('helpSkillInvoke') })
            }
          }
          for (let index = commandEntries.length - 1; index >= 0; index--) {
            const entry = commandEntries[index]
            if (entry !== undefined && entry.name.startsWith('skill:') && !seen.has(entry.name)) {
              commandEntries.splice(index, 1)
              skillCommandNames.delete(entry.name)
            }
          }
        } catch {
          // Keep the current skill command list if the snapshot fails.
        }
      }
      const baseAutocomplete = new CombinedAutocompleteProvider(commandEntries, workspace)
      editor.setAutocompleteProvider(new SkillAwareAutocompleteProvider(baseAutocomplete))
      void refreshSkillCommands()
      commandHintText = commandInputHint(editor.getText(), commandEntries)
      editor.onChange = (text: string): void => {
        commandHintText = commandInputHint(text, commandEntries)
        ui.requestRender()
      }

      const offQuestions = ctx.on('user-questions/request', async (request) => {
        const bridge = ctx.get('wechat') as WechatBridge | undefined
        if (bridge?.askWithFallback !== undefined) {
          return bridge.askWithFallback(request, async (r) => ({
            answers: await runInlineQuestionFlow(
              ui,
              askSlot,
              palette,
              t,
              r.questions,
              r.signal,
              () => ui.setFocus(editor),
            ),
          }))
        }
        return {
          answers: await runInlineQuestionFlow(
            ui,
            askSlot,
            palette,
            t,
            request.questions,
            request.signal,
            () => ui.setFocus(editor),
          ),
        }
      })

      const handleSessionEvent = (targetId: SessionId, session: Session, event: SessionEvent): void => {
        if (session.id !== targetId) return
        try {
          // 启动置顶视图只在无实时 transcript 事件时保持；首个会向
          // transcript 追加/更新内容的实时事件到达后回到跟随最新。
          if (followLatestAfterStartup && TRANSCRIPT_EVENT_TYPES.has(event.type)) {
            followLatestAfterStartup = false
            chat.followLatest = true
            chat.lineOffset = 0
          }
          if (event.type === 'session/title') updateTitle()
          renderEvent(event)
          updateStatusValues()
          ui.requestRender()
        } catch (error: unknown) {
          appendNotice(t('noticeEventRenderFailed', { error: errorChain(error) }), 'error')
        }
      }
      const handleAgentStatus = (targetId: SessionId, candidate: Agent, status: AgentStatus): void => {
        if (candidate.id !== targetId) return
        try {
          setStatus(status)
        } catch (error: unknown) {
          appendNotice(t('noticeEventRenderFailed', { error: errorChain(error) }), 'error')
        }
      }
      offEvent = ctx.on('session/event', (session, event) => handleSessionEvent(liveAgent.session.id, session, event))

      offStatus = ctx.on('agent/status', ({ agent: candidate, status }) => handleAgentStatus(liveAgent.id, candidate, status))

      // If an interjection is discarded (cancellation, inbox clear, or an
      // Alt+Up edit racing the loop), drop it from the TUI queue too.
      offInbox = ctx.on('agent/inbox/discarded', (payload) => {
        if (payload.agent.id !== liveAgent.id) return
        const index = pendingInterjections.findIndex(entry => entry.message.id === payload.message.id)
        if (index < 0) return
        pendingInterjections.splice(index, 1)
        refreshInterjectionIndicator()
        updateStatusValues()
        ui.requestRender()
      })

      offScheme = ui.onTerminalColorSchemeChange((scheme) => {
        try {
        currentScheme = scheme
        Object.assign(palette, createPalette(resolved.theme.color, scheme, truecolor, themeOverride()))
        Object.assign(mdTheme, markdownTheme(palette))
        rebuildTranscript()
        setStatus(agent?.status ?? 'idle')
        ui.requestRender()
        } catch (error: unknown) {
          appendNotice(t('noticeEventRenderFailed', { error: errorChain(error) }), 'error')
        }
      })

      // Compose fresh sessions from the selected mode without recording an
      // event yet. The persistence gate buffers setup metadata, and the actual
      // preset selection is logged immediately before the first user message.
      async function composeAgentPreset(target: Agent): Promise<void> {
        const presets = ctx.agentPresets
        if (presets === undefined || presets.composedPreset(target.ctx) !== undefined) return
        const recorded = resolveSessionPreset(target.session)
        if (recorded === undefined && hasConversationData(target.session.events)) return
        const wanted = recorded ?? uiMode
        try {
          await presets.mount(target.ctx, wanted)
        } catch (error: unknown) {
          appendNotice(t('noticeModeMountFailed', { error: errorChain(error) }), 'error')
        }
      }

      const activateAgent = (next: Agent, handle: AgentHandle): void => {
        const previousHandle = activeHandle
        offEvent?.()
        offStatus?.()
        offModelSelection?.()
        offInbox?.()
        const nextSelection = selectionFor(next)
        selectionRef.current = nextSelection
        selectionRef.assembled = undefined
        uiMode = modeForSession(next.session, resolveDefaultMode())
        offModelSelection = installModelSelection(next.ctx, selectionRef)
        agent = next
        activeHandle = handle
        setActiveAgent(next)
        tokenTotals = { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }
      contextUsageCache.measuredAt = 0
        // Pending interjections belong to the previous foreground session;
        // switching sessions drops them from the TUI queue.
        pendingInterjections.length = 0
        refreshInterjectionIndicator()
        refreshContextEstimate(next, nextSelection)
        refreshGitBranch(next.session.header.cwd ?? process.cwd())
        header = new HeaderComponent(
          next,
          () => undefined,
          palette,
          resolved.theme.color && truecolor,
          t,
          () => selectionRef.current,
        )
        offEvent = ctx.on('session/event', (session, event) => handleSessionEvent(next.session.id, session, event))
        offStatus = ctx.on('agent/status', ({ agent: candidate, status }) => handleAgentStatus(next.id, candidate, status))
        offInbox = ctx.on('agent/inbox/discarded', (payload) => {
          if (payload.agent.id !== next.id) return
          const index = pendingInterjections.findIndex(entry => entry.message.id === payload.message.id)
          if (index < 0) return
          pendingInterjections.splice(index, 1)
          refreshInterjectionIndicator()
          updateStatusValues()
          ui.requestRender()
        })
        rebuildTranscript()
        live = true
        setStatus(next.status)
        updateTitle()
        warnIfFullAccess(next)
        void composeAgentPreset(next)
        if (previousHandle !== undefined && previousHandle !== handle) {
          // 延迟到当前命令/事件生命周期写完再释放旧句柄；微信侧
          // `@dsh new` 会从旧 agent 的命令执行中直接切换前台会话。
          // 用 setImmediate 而不是 queueMicrotask：命令执行器在 handler
          // 返回后还需要往旧 session 追加 command/done，不能在微任务里先 dispose。
          setImmediate(() => {
            void previousHandle.dispose().catch(() => undefined)
          })
        }
      }

      const createAgent = async (): Promise<SessionId | undefined> => {
        const current = agent ?? liveAgent
        const selection = selectionRef.current ?? selectionFor(current)
        const preset = uiMode
        const id = SessionId(`tui-${crypto.randomUUID()}`)
        const handle = await ctx.agents.create({
          sessionId: id,
          meta: {
            cwd: current.session.header.cwd ?? process.cwd(),
            agentPreset: preset,
          },
          agentOptions: {
            ...current.options,
            provider: selection.provider,
            model: selection.model,
          },
          setup: async (agentCtx) => { await ctx.agentPresets.mount(agentCtx, preset) },
        })
        // `/new` should continue the current session's permission instead of
        // falling back to the global startup default.
        const currentPermission = ctx.permissionPresets.current(current.session)
        if (currentPermission !== 'custom') {
          try {
            ctx.permissionPresets.set(handle.agent.session, currentPermission)
          } catch {
            // If the preset cannot be applied, the new session keeps the default.
          }
        }
        activateAgent(handle.agent, handle)
        appendNotice(t('noticeSessionCreated', { id: String(id) }), 'info')
        return id
      }
      this.createForegroundSessionImpl = createAgent
      setTuiForegroundControl({
        foregroundAgent: () => this.foregroundAgent(),
        createForegroundSession: () => this.createForegroundSession(),
        currentModelSelection: () => selectionRef.current,
        saveModelSelection: async (selection: ModelSelection) => {
          await commitSelection(selection)
        },
      })

      const switchAgent = async (targetId: SessionId): Promise<void> => {
        const current = agent ?? liveAgent
        if (current.id === targetId) {
          appendNotice(t('noticeAlreadySession'), 'info')
          return
        }
        try {
          const workspace = current.session.header.cwd ?? process.cwd()
          const records = await ctx.sessionQuery.listSessions()
          const allowed = records.some(record =>
            record.persisted && String(record.header.id) === String(targetId) && sameProject(record.header.cwd, workspace))
          if (!allowed) {
            appendNotice(t('noticeNoSessions'), 'warning')
            return
          }
        } catch (error: unknown) {
          appendNotice(t('noticeSessionListFailed', { error: errorChain(error) }), 'error')
          return
        }
        appendNotice(t('noticeResuming'), 'info')
        const presets = ctx.agentPresets
        const controller = new AbortController()
        const resumePromise = ctx.agents.resume({
          resumeSessionId: targetId,
          agentOptions: current.options,
          signal: controller.signal,
          setup: presets === undefined ? undefined : async (agentCtx) => {
            const resumed = agentCtx.agent
            const recorded = resumed === undefined ? undefined : resolveSessionPreset(resumed.session)
            if (recorded !== undefined) await presets.mount(agentCtx, recorded)
          },
        })
        // Keep the original promise's late rejection from becoming unhandled if
        // the timeout wins the race, and dispose a handle that only arrives late.
        let timedOut = false
        let settled = false
        void resumePromise.then((handle) => {
          if (timedOut) void handle.dispose().catch(() => undefined)
        }).catch(() => undefined)
        let resumeTimer: NodeJS.Timeout | undefined
        const timeoutPromise = new Promise<AgentHandle>((_, reject) => {
          resumeTimer = setTimeout(() => {
            controller.abort()
            if (!settled) {
              timedOut = true
              reject(new DOMException('Session resume timed out', 'AbortError'))
            }
          }, RESUME_TIMEOUT_MS)
        })
        try {
          const handle = await Promise.race([resumePromise, timeoutPromise])
          settled = true
          clearTimeout(resumeTimer)
          activateAgent(handle.agent, handle)
          appendNotice(t('noticeSessionResumed', { id: String(targetId) }), 'info')
        } catch (error: unknown) {
          settled = true
          clearTimeout(resumeTimer)
          const aborted = error instanceof Error && error.name === 'AbortError'
          appendNotice(
            aborted ? t('noticeResumeTimeout') : t('noticeResumeFailed', { error: errorChain(error) }),
            'error',
          )
        }
      }

      // Publish model helpers before the first status render; otherwise the
      // initial frame briefly shows Agent creation defaults instead of the
      // selection that will actually route the next request.
      handles.newAgent = createAgent
      handles.switchAgent = switchAgent
      handles.saveSelection = saveSelection
      handles.setReasoningEffort = setReasoningEffort
      handles.selectionRef = selectionRef
      refreshContextEstimate(liveAgent, initialSelection)

      // Replay the durable log first (constructor seeds never publish), then
      // go live so turn-end notices only surface for fresh work. 启动重放先
      // 置顶展示；首个实时事件到达后恢复跟随最新，避免打开即跳底。
      rebuildTranscript('top', true)
      // Attach after the transcript rebuild so buffered startup output is not
      // cleared by the replay and stays visible as persistent cards.
      subscribeWechatOutput()
      live = true
      updateTitle()
      setStatus(liveAgent.status)
      void composeAgentPreset(liveAgent)
      void (async () => {
        const presets = ctx.agentPresets
        if (presets === undefined) return
        try {
          for (const preset of await presets.list()) {
            presetNames.set(preset.id, preset.name ?? preset.id)
          }
        } catch {
          // Roster unreadable: keep the shipped labels.
        }
        updateStatusValues()
        ui.requestRender()
      })()
      ui.start()
      // Report mouse wheel events (normal tracking + SGR encoding) so the
      // transcript can page on scroll without sending legacy X10 sequences.
      terminal.write('\x1b[?1000h\x1b[?1006h')
      flushDeferredNotices()
      warnIfFullAccess(liveAgent)

    }

    const readyAgent = ctx.agents.get(sessionId)
    if (readyAgent !== undefined) {
      mount(readyAgent)
    } else {
      const offCreated = ctx.on('agent/created', ({ agent: candidate }) => {
        if (candidate.id === sessionId) {
          offCreated()
          mount(candidate)
        }
      })
      const timeout = setTimeout(() => {
        if (mounted) return
        offCreated()
        terminal.write(`\r\ntui: session "${sessionId}" never became live (timed out).\r\n`)
        ctx.appExit?.(1)
      }, AGENT_READY_TIMEOUT_MS)
      ctx.effect(() => () => {
        clearTimeout(timeout)
      })
    }

    ctx.effect(() => () => {
      setTuiForegroundControl(undefined)
      offKeys()
      offEvent?.()
      offStatus?.()
      offScheme?.()
      offModelSelection?.()
      offInbox?.()
      offWechatOutput?.()
      stopSpinner()
      clearTimeout(noticeTimer)
      clearTimeout(exitArmTimer)
      terminal.write('\x1b[?1006l\x1b[?1000l')
      ui.stop()
      terminal.stop()
    })
  }
}

export { SessionId }
export default Tui
