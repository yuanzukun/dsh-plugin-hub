/**
 * @by oh-my-zerone
 * @date 2026-09-30
 *
 * Cross-check this bundle against its target DSH runtime line, so a runtime
 * upgrade cannot silently break the install gate again.
 *
 * Checks:
 *   1. Every `@deepseek-ai/dsh*` peer is an EXACT version equal to the expected
 *      runtime version. DSH compares each declared range against the single
 *      version from `getDshRuntimeVersion()`; a caret range such as
 *      `^0.1.0-rc.8` never matches a `0.2.x` runtime, and the install is refused.
 *   2. Every package the preset references exists — in an installed runtime tree
 *      (`--runtime <dir>` whose `@deepseek-ai/*` packages are reachable) or in a
 *      published plugin catalog (`--catalog <packages.md>`).
 *   3. Every preset `config` key is declared by the target package's published
 *      `Config` type (catches `text` -> `prefix` style drift). Needs `--runtime`.
 *   4. Every `dsh.bundle.patch` file exists and parses to a loader entry list.
 *
 * Run:
 *   node scripts/verify-dsh-contract.mjs --catalog <packages.md>
 *   node scripts/verify-dsh-contract.mjs --runtime <dir containing node_modules|@deepseek-ai>
 *   node scripts/verify-dsh-contract.mjs --catalog <packages.md> --runtime <dir>
 *
 * `--expect <version>` overrides the expected runtime version (default: the
 * exact version declared by every DSH peer).
 */
import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import yaml from 'js-yaml';

const pkgRoot = dirname(dirname(fileURLToPath(import.meta.url)));

// DSH composition files use the `!!js` loader dialect (JS expressions in YAML).
const jsType = new yaml.Type('tag:yaml.org,2002:js', {
  kind: 'scalar',
  resolve: () => true,
  construct: (v) => v
});
const loadYaml = (text) => yaml.load(text, { schema: yaml.JSON_SCHEMA.extend([jsType]) });

const argv = process.argv.slice(2);
const argValue = (flag, fallback) => {
  const i = argv.indexOf(flag);
  return i >= 0 && argv[i + 1] ? argv[i + 1] : fallback;
};

const pkgJson = JSON.parse(readFileSync(join(pkgRoot, 'package.json'), 'utf8').replace(/^\uFEFF/, ''));
const dshPeers = Object.entries(pkgJson.peerDependencies ?? {})
  .filter(([n]) => n === '@deepseek-ai/dsh' || n.startsWith('@deepseek-ai/dsh-'));
const expected = argValue('--expect', dshPeers[0]?.[1]);
const catalogPath = argValue('--catalog', undefined);
const runtimeArg = argValue('--runtime', undefined);

let ok = 0;
let fail = 0;
let skip = 0;
const check = (label, cond, detail = '') => {
  if (cond) { ok += 1; console.log(`  OK   ${label}`); }
  else { fail += 1; console.log(`  FAIL ${label}${detail ? ` — ${detail}` : ''}`); }
};
const note = (label) => { skip += 1; console.log(`  SKIP ${label}`); };

/**
 * Locate a package's manifest inside a runtime tree. Accepts a directory that
 * contains `@deepseek-ai/*` directly, or an installed profile/package root whose
 * `node_modules/@deepseek-ai/*` holds them (pnpm layouts link them there).
 */
const runtimeRoots = (() => {
  if (!runtimeArg) return [];
  const base = resolve(runtimeArg);
  const candidates = [base, join(base, 'node_modules')];
  return candidates.filter((dir) => existsSync(join(dir, '@deepseek-ai')));
})();
const packageDir = (name) => {
  const parts = name.split('/');
  for (const root of runtimeRoots) {
    const dir = join(root, ...parts);
    if (existsSync(join(dir, 'package.json'))) return dir;
  }
  return undefined;
};
const declareTextOf = (name) => {
  const dir = packageDir(name);
  if (!dir) return '';
  const base = join(dir, 'lib');
  if (!existsSync(base)) return '';
  let text = '';
  const walk = (d) => {
    for (const entry of readdirSync(d, { withFileTypes: true })) {
      const path = join(d, entry.name);
      if (entry.isDirectory()) walk(path);
      else if (entry.name.endsWith('.d.ts')) text += readFileSync(path, 'utf8');
    }
  };
  walk(base);
  return text;
};

console.log(`== target runtime version: ${expected ?? '(none declared)'}`);
if (runtimeArg) {
  console.log(`== runtime tree: ${resolve(runtimeArg)} -> ${runtimeRoots.length} root(s) with @deepseek-ai/`);
  check('the --runtime tree exposes @deepseek-ai packages', runtimeRoots.length > 0, resolve(runtimeArg));
} else {
  note('runtime tree checks (pass --runtime <dir> to enable)');
}
if (catalogPath) console.log(`== catalog: ${catalogPath}`);

console.log('== 1. peer declarations pass the DSH compatibility gate ==');
check('declares at least one @deepseek-ai/dsh-* peer', dshPeers.length > 0);
check('every DSH peer declares the same version', new Set(dshPeers.map(([, r]) => r)).size <= 1);
for (const [name, range] of dshPeers) {
  check(`${name} is pinned to an exact version`, !/[~^*x]|\s-\s|\|\|/.test(range), `range "${range}" is ranged; DSH matches ranges literally`);
  check(`${name} pins ${expected}`, range === expected, `declared "${range}"`);
}

console.log('== 2. every referenced package exists on this runtime line ==');
const patchPaths = (Array.isArray(pkgJson.dsh?.bundle?.patch) ? pkgJson.dsh.bundle.patch : [pkgJson.dsh?.bundle?.patch]).filter(Boolean);
const parsedPatches = patchPaths
  .map((p) => ({ path: p, full: join(pkgRoot, p) }))
  .filter(({ full }) => existsSync(full))
  .map(({ path, full }) => ({ path, doc: loadYaml(readFileSync(full, 'utf8')) }));
const flattenRows = (list) => (list || []).flatMap((row) => [row, ...(Array.isArray(row?.config) ? flattenRows(row.config) : [])]);
const presetRows = parsedPatches.flatMap(({ doc }) => (doc || []).flatMap((e) => e.insert || [])).filter((r) => r.name === '@deepseek-ai/dsh-agent-preset');
const presetPlugins = presetRows.flatMap((r) => flattenRows(r.config?.plugins));
const referenced = [...new Set([...dshPeers.map(([n]) => n), ...presetPlugins.map((r) => r.name)])].filter((n) => n.startsWith('@deepseek-ai/'));

if (catalogPath) {
  const catalog = readFileSync(catalogPath, 'utf8');
  const known = new Set([...catalog.matchAll(/^\| `(@deepseek-ai\/[^`]+)`/gm)].map((m) => m[1]));
  const absent = referenced.filter((n) => {
    const parent = n.split('/').slice(0, 2).join('/');
    return !known.has(n) && !known.has(parent);
  });
  check(`all ${referenced.length} referenced packages are in the catalog`, absent.length === 0, absent.join(', '));
} else {
  note('catalog name checks (pass --catalog <packages.md> to enable)');
}
if (runtimeRoots.length > 0) {
  const absent = referenced.filter((n) => !packageDir(n.split('/').slice(0, 2).join('/')));
  check(`all ${referenced.length} referenced packages are installed`, absent.length === 0, absent.join(', '));
} else {
  note('installed package checks (pass --runtime <dir> to enable)');
}

console.log('== 3. preset config keys are declared by the target packages ==');
if (runtimeRoots.length > 0) {
  let keysChecked = 0;
  const unknown = [];
  for (const row of presetPlugins) {
    const config = row.config && !Array.isArray(row.config) ? row.config : undefined;
    if (!config) continue;
    const keys = Object.keys(config).filter((k) => k !== 'isolate');
    const declares = declareTextOf(row.name);
    if (keys.length === 0 || !declares) continue;
    for (const key of keys) {
      keysChecked += 1;
      if (!new RegExp(`\\b${key}\\s*[?:]`).test(declares)) unknown.push(`${row.id}.${key}`);
    }
  }
  check(`all ${keysChecked} preset config keys are declared`, unknown.length === 0, unknown.join(', '));
} else {
  note('config key checks (pass --runtime <dir> to enable)');
}

console.log('== 4. bundle patches exist and parse ==');
check('dsh.bundle.patch is declared', patchPaths.length > 0);
check('every declared patch exists', patchPaths.every((p) => existsSync(join(pkgRoot, p))), patchPaths.join(', '));
check('every declared patch parses to a loader entry list', parsedPatches.length === patchPaths.length && parsedPatches.every(({ doc }) => Array.isArray(doc)));
check('exactly one agent-preset declaration row', presetRows.length === 1, `${presetRows.length} row(s)`);

console.log(`\n${ok} passed, ${fail} failed, ${skip} skipped`);
process.exit(fail === 0 ? 0 : 1);
