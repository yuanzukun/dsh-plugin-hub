/**
 * @by oh-my-zerone
 * @date 2026-07-18
 *
 * Local acceptance test (workspace-only; does not touch the running DSH).
 * Verifies this bundle against the DSH 0.2.1-rc.2 contract observed in the
 * published `@deepseek-ai/*` packages:
 *   A. presets/zerone.patch.yml — declares the ZERONE agent preset through one
 *      `@deepseek-ai/dsh-agent-preset` insert row (`id`/`name`/`description`/
 *      `order`/`plugins`), with the standard capability rows, the OMZ persona in
 *      a supported `dsh-persona` field, and every service row inside an
 *      `isolate` realm group.
 *   B. cordis.patch.yml — inserts the host plugin row (global skill registry).
 *   C. package.json — dsh.bundle.patch lists both patches, DSH peers target the
 *      supported runtime line, repository and files stay correct.
 *   D. every embedded SKILL.md parses into a valid SkillRegistration input
 *      (name/description/content/invocation/resourceBase).
 *   E. the retired 0.1.x preset layout (`config/agent-presets/<id>/` with
 *      `preset.yml` + `agent.cordis.yml`, discovered through
 *      `agent-presets.roots`) is gone.
 *
 * Run: node scripts/acceptance-test.mjs
 */
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import yaml from 'js-yaml';
import { parseFrontmatter } from '../lib/frontmatter.js';

// DSH composition files use the `!!js` loader dialect (JS expressions in YAML).
// Register a passthrough scalar type so structure validation can parse them.
const jsType = new yaml.Type('tag:yaml.org,2002:js', {
  kind: 'scalar',
  resolve: () => true,
  construct: (v) => v
});
const schema = yaml.JSON_SCHEMA.extend([jsType]);
const loadYaml = (text) => yaml.load(text, { schema });

/** DSH runtime line this bundle is built against. */
const DSH_RUNTIME = '0.2.1-rc.2';

const pkg = dirname(dirname(fileURLToPath(import.meta.url)));
let ok = 0;
let fail = 0;
const check = (label, cond) => {
  if (cond) { ok += 1; console.log(`  OK   ${label}`); }
  else { fail += 1; console.log(`  FAIL ${label}`); }
};

/** Flatten a Cordis entry list, including nested group `config` lists. */
const flattenRows = (list) => (list || []).flatMap((row) => [row, ...(Array.isArray(row?.config) ? flattenRows(row.config) : [])]);

/** Parse `x.y.z[-pre]` into comparable parts (prerelease-aware). */
const parseVer = (v) => {
  const m = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?$/.exec(String(v ?? ''));
  return m ? { core: [Number(m[1]), Number(m[2]), Number(m[3])], pre: m[4] ? m[4].split('.') : [] } : null;
};
const cmpVer = (a, b) => {
  for (let i = 0; i < 3; i += 1) if (a.core[i] !== b.core[i]) return a.core[i] < b.core[i] ? -1 : 1;
  if (a.pre.length === 0 || b.pre.length === 0) return a.pre.length === b.pre.length ? 0 : (a.pre.length === 0 ? 1 : -1);
  for (let i = 0; i < Math.max(a.pre.length, b.pre.length); i += 1) {
    const x = a.pre[i], y = b.pre[i];
    if (x === undefined) return -1;
    if (y === undefined) return 1;
    const nx = /^\d+$/.test(x), ny = /^\d+$/.test(y);
    if (nx && ny) { if (Number(x) !== Number(y)) return Number(x) < Number(y) ? -1 : 1; continue; }
    if (nx !== ny) return nx ? -1 : 1;
    if (x !== y) return x < y ? -1 : 1;
  }
  return 0;
};
/** Evaluate a simple `a b` conjunction of comparators (>=, >, <=, <, =). */
const satisfiesRange = (range, version) => {
  const v = parseVer(version);
  if (!v) return false;
  const parts = String(range).trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return false;
  return parts.every((part) => {
    const m = /^(>=|<=|>|<|=)?(.+)$/.exec(part);
    if (!m) return false;
    const bound = parseVer(m[2]);
    if (!bound) return false;
    const c = cmpVer(v, bound);
    switch (m[1] ?? '=') {
      case '>=': return c >= 0;
      case '>': return c > 0;
      case '<=': return c <= 0;
      case '<': return c < 0;
      default: return c === 0;
    }
  });
};

console.log('== A. presets/zerone.patch.yml ==');
const patch = loadYaml(readFileSync(join(pkg, 'presets/zerone.patch.yml'), 'utf8'));
check('patch is an array of loader entries', Array.isArray(patch) && patch.length > 0);
const presetRow = (patch || []).flatMap((e) => e.insert || []).find((r) => r.name === '@deepseek-ai/dsh-agent-preset');
check('declares a dsh-agent-preset row', !!presetRow);
check('row id follows preset-<id>', presetRow?.id === 'preset-zerone');
const preset = presetRow?.config ?? {};
check('config.id = zerone', preset.id === 'zerone');
check('config.name = ZERONE', preset.name === 'ZERONE');
check('config.description present', typeof preset.description === 'string' && preset.description.length > 0);
check('config.order = 5', preset.order === 5);
check('config.plugins is a non-empty list', Array.isArray(preset.plugins) && preset.plugins.length > 0);

const idRequired = ['persona', 'agent-instructions', 'tool-bash', 'tool-pwsh', 'tool-fs', 'tool-fs-search', 'tool-jobs', 'skill-filesystem', 'tool-skill', 'tool-goal', 'planning', 'compaction', 'delegation', 'tool-ask-user', 'tool-todo', 'tool-web'];
const topIds = (preset.plugins || []).map((r) => r.id);
const missingTop = idRequired.filter((r) => !topIds.includes(r));
check('has all standard capability rows', missingTop.length === 0);

const rows = flattenRows(preset.plugins);
const persona = rows.find((r) => r.id === 'persona');
check('persona row uses dsh-persona', persona?.name === '@deepseek-ai/dsh-persona');
check('persona.config.prefix is non-empty (OMZ persona)', typeof persona?.config?.prefix === 'string' && persona.config.prefix.length > 200);
check('persona.config has no retired `text` field', persona?.config?.text === undefined);
check('persona.config.suffix carries the runtime template', /\{\{model\}\}/.test(persona?.config?.suffix ?? '') && /\{\{cwd\}\}/.test(persona?.config?.suffix ?? ''));
check('persona mentions ZERONE / SDD', /ZERONE|SDD|Specification/i.test(persona?.config?.prefix ?? ''));
check('persona has user-confirmation ([用户确认])', /用户确认/.test(persona?.config?.prefix ?? ''));
check('persona has evolution three-tier (可自主/需用户确认/禁止)', /可自主/.test(persona?.config?.prefix ?? '') && /需用户确认/.test(persona?.config?.prefix ?? '') && /禁止/.test(persona?.config?.prefix ?? ''));

// isolate realm: each service-bearing row inside a cordis:group with isolate
const groupIds = (preset.plugins || []).filter((r) => r.group === true).map((r) => r.id);
check('service groups (planning/compaction/delegation) have isolate realm', ['planning', 'compaction', 'delegation'].every((g) => groupIds.includes(g)));
check('service groups declare isolate keys', (preset.plugins || []).filter((r) => r.group === true).every((r) => r.isolate && Object.keys(r.isolate).length > 0));
check('workflow row uses dsh-workflow-ptc (0.2.0 engine)', rows.some((r) => r.name === '@deepseek-ai/dsh-workflow-ptc' && r.disabled !== true));
check('retired dsh-workflow-worker-thread is not referenced', !rows.some((r) => r.name === '@deepseek-ai/dsh-workflow-worker-thread'));
check('every row carries an id and a name', rows.every((r) => typeof r.id === 'string' && r.id.length > 0 && typeof r.name === 'string' && r.name.length > 0));
check('every package row is scoped or a cordis native', rows.every((r) => r.name.startsWith('@deepseek-ai/') || r.name.startsWith('cordis:')));

console.log('== B. cordis.patch.yml ==');
const hostPatch = loadYaml(readFileSync(join(pkg, 'cordis.patch.yml'), 'utf8'));
const inserts = (hostPatch || []).flatMap((e) => e.insert || []);
check('patch inserts plugin row', inserts.some((r) => r.id === 'dsh-plugin-zerone' && r.name === '@vigalai/dsh-plugin-zerone'));

console.log('== C. package.json ==');
const pj = JSON.parse(readFileSync(join(pkg, 'package.json'), 'utf8'));
check('name = @vigalai/dsh-plugin-zerone', pj.name === '@vigalai/dsh-plugin-zerone');
check('version is a 0.1.x release', /^0\.1\.\d+$/.test(pj.version ?? ''));
const patches = Array.isArray(pj.dsh?.bundle?.patch) ? pj.dsh.bundle.patch : [pj.dsh?.bundle?.patch];
check('dsh.bundle.patch lists cordis.patch.yml', patches.includes('./cordis.patch.yml'));
check('dsh.bundle.patch lists presets/zerone.patch.yml', patches.includes('./presets/zerone.patch.yml'));
check('every declared patch file exists', patches.every((p) => existsSync(join(pkg, p))));
const dshPeers = Object.entries(pj.peerDependencies ?? {}).filter(([n]) => n === '@deepseek-ai/dsh' || n.startsWith('@deepseek-ai/dsh-'));
const enginesDsh = typeof pj.engines?.dsh === 'string' ? pj.engines.dsh : undefined;
// DSH gate semantics: `engines.dsh` alone decides (real semver range) and peer
// ranges are ignored; without it every `@deepseek-ai/dsh*` peer must match the
// runtime version literally.
if (enginesDsh !== undefined) {
  check('declares engines.dsh (range-matched by the gate)', enginesDsh.trim().length > 0);
  check(`engines.dsh includes the ${DSH_RUNTIME} runtime`, satisfiesRange(enginesDsh, DSH_RUNTIME), `"${enginesDsh}"`);
  check('engines.dsh is not a workspace: placeholder', !/^\s*workspace:/.test(enginesDsh));
} else {
  check('declares at least one @deepseek-ai/dsh-* peer (compatibility gate)', dshPeers.length > 0);
  check(`every dsh peer matches the ${DSH_RUNTIME} runtime`, dshPeers.every(([, range]) => range === DSH_RUNTIME));
}
check('files includes presets', (pj.files || []).includes('presets'));
check('files includes cordis.patch.yml', (pj.files || []).includes('cordis.patch.yml'));
check('files no longer ships config/', !(pj.files || []).includes('config'));
check('repository points to yahoolcj repo', /yahoolcj\/dsh-plugin-zerone/.test(pj.repository?.url ?? ''));

console.log('== D. SKILL.md registration inputs ==');
const skillsDir = join(pkg, 'skills');
const skills = [];
for (const entry of readdirSync(skillsDir, { withFileTypes: true })) {
  if (!entry.isDirectory()) continue;
  const f = join(skillsDir, entry.name, 'SKILL.md');
  if (!statSync(f, { throwIfNoEntry: false })) continue;
  const parsed = parseFrontmatter(readFileSync(f, 'utf8'));
  skills.push({ dir: entry.name, ...parsed?.fields, body: parsed?.body, dirPath: join(skillsDir, entry.name) });
}
check('16 skills found (15 SDD + omz-governance)', skills.length === 16);
check('omz-governance present', skills.some((s) => s.name === 'omz-governance'));
check('all have name+description+content', skills.every((s) => s.name && s.description && s.body?.length > 0));
check('all have user+model invocable default', true); // register() applies defaults; registration shape below
check('each has a resourceBase directory (resource dir exists)', skills.every((s) => existsSync(s.dirPath)));

console.log('== E. retired 0.1.x preset layout ==');
check('config/agent-presets directory is gone', !existsSync(join(pkg, 'config')));
check('no agent.cordis.yml ships', !existsSync(join(pkg, 'config/agent-presets/zerone/agent.cordis.yml')));

console.log(`\n${ok} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
