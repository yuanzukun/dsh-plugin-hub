# 安装 dsh-plugin-zerone

`dsh-plugin-zerone` 是 oh-my-zerone（OMZ）给 DeepSeek Harness 做的插件：装上去之后，你会多一个 **ZERONE 模式**，还带一整套 16 个技能。

> **适用 DSH 0.2.0-rc.2 运行时线**（本包 `0.1.4+`）。DSH 会校验插件声明的 `@deepseek-ai/dsh*` peer 版本区间，0.1.x 上装不了，也不需要装 —— 那是另一套 preset 机制。

## 怎么装

### 方式一：让 DSH 自己装（最省事）

把下面这句发给任意一个 DSH 会话：

```text
请你仔细阅读 https://github.com/yahoolcj/dsh-plugin-zerone/blob/main/install.md，并且安装这个插件。
```

### 方式二：Plugin Market 安装

打开 DSH 的 **Plugin Market**，搜索 **yahoolcj/dsh-plugin-zerone**，点一键安装。

### 方式三：手动命令

也可以自己在终端跑：

```sh
dsh plugin --profile web add @vigalai/dsh-plugin-zerone
```

### 不需要额外配置

ZERONE 模式由插件包自带的 bundle patch 声明（`presets/zerone.patch.yml` 里的 `@deepseek-ai/dsh-agent-preset` 行），技能由 host 插件行全局注册 —— 装完即生效，**不用改 profile 的 `cordis.patch.yml`，也不用注册任何 preset 根目录**。

### dsh-desktop

0.2.0 起桌面端不再内置第三方插件，请在桌面端的**插件 / Plugin Market** 里安装本插件，效果与 `dsh plugin add` 一致。

## 装完做什么

重启 DSH，新建一个会话、切到 **ZERONE** 模式。

你会得到一个带着 OMZ 人格的 Agent：它自主进化、严格走 SDD 工作流、会主动找你确认、也会做 review。同时 `/to-prd`、`/to-coding`、`/to-review` 这些命令就都能用了。

## 你拿到了什么

- **16 个技能**：15 个 SDD 工作流技能 + `omz-governance` 机制技能
- **ZERONE 模式**：DSH 标准能力 + OMZ 人格（可选模式，不动你的默认设置）
- **项目级能力**：进新仓库自动建记忆、知识库、进化日志，越用越懂你的项目

## 备注

- npm：<https://www.npmjs.com/package/@vigalai/dsh-plugin-zerone>
- 仓库：<https://github.com/yahoolcj/dsh-plugin-zerone>
- 市场收录：<https://github.com/awesome-dsh-plugin/awesome-dsh-plugin/pull/4037>
