/**
 * ── 就地类型声明 ────────────────────────────────────────────────────────────
 * 本文件**必须保持零 import**：客户端 bundle 由宿主在浏览器里 eval
 * （`window.__ModuleLoader__`），import 解析不了（AGENTS.md §2.15）。所以宿主
 * 注入的全局对象、payload 形状与 player API 全部就地声明在这里。
 */

/** 宿主注入的浏览器全局（shell 启动时写入；测试注入其中两项）。 */
interface Window {
  /**
   * 宿主模块加载器：插件 bundle 由它 eval 注册。`factory` 的形参（`require`）
   * 故意不给上下文类型：它是宿主的动态模块表，形状不可静态表达，只能保持
   * 原来的隐式 any（`noImplicitAny` 关闭）。
   */
  __ModuleLoader__: { load(registration: { id: string; factory: unknown }): void };
  /** Desktop 的 app 文档由 preload-app 注入（只有 { protocolVersion } 标记，无 IPC 能力）。 */
  dshDesktop?: { protocolVersion?: string } | null;
  /** jsdom 测试注入的假媒体元素工厂（jsdom 没有媒体实现）。 */
  __dshMusicMedia?: () => HTMLVideoElement;
  /** 页面级共享的 player 单例（见 createPlayer 上方注释）。 */
  __dshMusicPlayer?: MusicPlayerApi;
}

/**
 * React 组件在宿主 module loader 下只是运行时值（`require("react")` 的返回是
 * 动态模块，形状不可静态表达）；这里只声明「可调用」这一必要形状。
 */
type RuntimeComponent = (props: unknown) => unknown;

/** /api/library 的曲目（宿主 payloadTracksFor 产出的字段，见 src/host.ts）。 */
type LibrarySection = "library" | "favorites" | "recent";
type MediaFilter = "all" | "audio" | "video";
/** setView 兼容入口：把旧的 4 个视图映射到两轴状态。 */
type LibraryView = "all" | "audio" | "video" | "favorites" | "recent";

interface MusicTrack {
  id: string;
  name: string;
  title: string;
  artist?: string | null;
  duration?: number | null;
  /** 文件 mtime（毫秒）；仅用于「最近添加」排序。 */
  addedAt?: number | null;
  /** 是否已同时具备标题与歌手标签（“一键补全”据此挑选待补全曲目）。 */
  tagged?: boolean;
  /** 'audio' | 'video'：MV 只有在视频轨上才显示画面。 */
  kind?: string | null;
  /** 视频编码（用于判断能否直出，见 host 的 mvPlan）。 */
  videoCodec?: string | null;
  /** 音轨编码（用于判断 WASM 画面旁路会不会「有画面没声音」，见 host 的 mvPlan）。 */
  audioCodec?: string | null;
  /** ReplayGain 标准标签（宿主从 music-metadata 归一化后下发）；null/缺省 = 未测量。 */
  rgTrackGainDb?: number | null;
  rgTrackPeak?: number | null;
  rgAlbumGainDb?: number | null;
  rgAlbumPeak?: number | null;
  /** 宿主**测量**出来的（不是文件标签）。标签优先，这两个是兜底。 */
  rgMeasuredGainDb?: number | null;
  rgMeasuredPeak?: number | null;
}

/** 在线补全结果（localStorage `dsh-music:meta`）：只覆盖显示，不写回文件。 */
interface MetaEntry {
  title?: string;
  artist?: string;
  album?: string;
  cover?: string;
}

/** /api/match 的候选（宿主 rankCandidates 的产物）。 */
interface MatchCandidate {
  id?: string;
  title?: string;
  artist?: string;
  album?: string;
  cover?: string;
  /** 首个来源（`sources` 缺失时回退用）。 */
  source?: string;
  /** 命中的全部来源。 */
  sources?: string[];
  score?: number;
  /** 高置信度：宿主认为可以直接写回。 */
  auto?: boolean;
}

/** MV 准备状态：null（非视频）| { id, state, progress, mode, error }。 */
interface MvState {
  id: string;
  /** 'checking' | 'preparing' | 'ready' | 'failed'。 */
  state: string;
  progress: number;
  /** 'direct' | 'remux' | 'transcode' | 'wasm' | null。 */
  mode: string | null;
  error: string | null;
}

/** 补全弹层：null = 关闭，否则 { id, loading, applying?, error, candidates, term }。 */
interface MatchState {
  id: string;
  loading: boolean;
  /** 正在写入文件（写标签 + 重命名）的进行中标志。 */
  applying?: boolean;
  error: string | null;
  candidates: MatchCandidate[];
  /** 服务端实际使用的搜索词（搜过之后回填）。 */
  term: string;
}

/** 播放器 store 的状态快照；`set()` 的 patch 是它的部分字段。 */
/**
 * 均衡器参数（**模块级**：player 与视图是两个作用域，放 createPlayer 内视图读不到）。
 * 10 段 ISO 中心频率的 peaking 滤波器串成一条链，串在 RG 与音量之间；0dB 是**直通**，
 * 所以「关闭」不需要旁路开关。频点与曲线都是本仓库自定（fooyin 是 GPL-3.0：只借鉴做法）。
 */
const EQ_BANDS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];
/** 带宽：1.1 是十段均衡器常用的互不严重重叠值。 */
const EQ_Q = 1.1;
/** 单段增益范围（dB）。超出只可能是脏数据。 */
const EQ_GAIN_MIN_DB = -12;
const EQ_GAIN_MAX_DB = 12;
/** 预设：id → 每段增益（dB）。`flat` 永远是第一条（默认不动音色）。 */
const EQ_PRESETS: Record<string, number[]> = {
  flat: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  // 曲线按「**入耳式真能重放**的频段」分布：小动圈对 31/62Hz 几乎无输出，把能量堆在那里
  // 只会白白让自动前级压低整体音量（实测听不出差别的原因之一）。所以低音落在 62–250Hz。
  pop: [-1, 0, 1, 3, 4, 3, 2, 1, 0, -1],
  rock: [3, 3, 2, 0.5, -1, -1, 1, 3, 4, 4],
  classical: [3.5, 3, 2, 0, 0, 0, -1, -2, -3, -3.5],
  jazz: [3, 2, 1, 1.5, -0.5, -0.5, 0, 1.5, 2, 2.5],
  bass: [2, 4, 5, 4, 2, 0, 0, 0, 0, 0],
  vocal: [-2, -1, 0.5, 3, 4.5, 4, 3, 1.5, 0, -1],
  electronic: [4, 4, 3, 0, -1, -0.5, 1.5, 3, 4, 4.5],
};
const EQ_PRESET_ORDER = Object.keys(EQ_PRESETS);
/** 波形柱子数：全屏播放器多给一点细节，常驻底栏减半（DOM 节点 = 2×柱子数）。 */
const WAVE_BARS_FULL = 120;
const WAVE_BARS_INLINE = 60;

/**
 * 波形柱子的抽样：宿主下发 400 桶，渲染只要 ~120 根（全屏）/ ~60 根（常驻底栏）。
 * 两层行 = 2×柱子数个节点，所以底栏刻意减半 —— 它在浏览列表时一直可见，省一半节点。
 * 取每段**最大值**（不是平均：平均会把瞬态抹平，鼓点看起来就没了）。
 */
function sampleWaveBars(peaks: number[], target: number): number[] {
  if (peaks.length <= target) return peaks.slice();
  const out: number[] = [];
  for (let i = 0; i < target; i += 1) {
    const from = Math.floor((i * peaks.length) / target);
    const to = Math.max(from + 1, Math.floor(((i + 1) * peaks.length) / target));
    let max = 0;
    for (let j = from; j < to && j < peaks.length; j += 1) if (peaks[j] > max) max = peaks[j];
    out.push(max);
  }
  return out;
}

interface PlayerState {
  dir: string | null;
  tracks: MusicTrack[];
  scannedAt: number | null;
  loading: boolean;
  picking: boolean;
  /** 目的地：资料库 / 收藏 / 最近添加。过滤在 store 内完成，next/prev 也遵守。 */
  section: LibrarySection;
  /** 目的地的类型过滤：全部 / 音频 / MV。 */
  mediaFilter: MediaFilter;
  /** 侧边栏展开状态；持久化，切走视图再回来保持。 */
  sidebarOpen: boolean;
  /** 收藏 id 集合（相对路径 id）；只存本机 localStorage。 */
  favorites: Set<string>;
  scanning: boolean;
  /**
   * 宿主入口：`api`（经连接层 /api 栅栏 + 浏览器会话）或 `legacy`（降级到插件
   * 自建的 /dsh-music 前缀）。降级是信任模型降级，必须让用户看得见。
   */
  hostEntry: "api" | "legacy";
  mv: MvState | null;
  /** 补全时顺带转格式：成功后是否把原件丢进废纸篓（默认否，只并存）。 */
  convertDeleteOriginal: boolean;
  scanParsed: number;
  scanTotal: number;
  truncated: boolean;
  /** 扫描时跳过的 DRM 加密包（.movpkg）数量。 */
  skippedPackages: number;
  error: string | null;
  current: number;
  playing: boolean;
  /** 用户按了静音：`volume` 保留设定值，实际输出按 0 处理。 */
  muted: boolean;
  /** 正在等数据（网络/宿主慢）：UI 显示「缓冲中」。 */
  buffering: boolean;
  mode: "loop" | "one";
  time: number;
  duration: number;
  volume: number;
  /** ReplayGain：模式与前级增益（dB）。`off` 表示完全不干预响度。 */
  rgMode: "off" | "track" | "album";
  rgPreampDb: number;
  /** 当前曲目**实际生效**的增益（dB）；null = 未启用或该曲目未测量。 */
  rgTrackDb: number | null;
  /** 测量进度（宿主侧后台任务）；UI 用它显示「测量中 x/y」。 */
  rgMeasuring: boolean;
  rgMeasureDone: number;
  rgMeasureTotal: number;
  /** 均衡器：当前预设 id 与**实际生效**的每段增益（dB）。自定义曲线时 preset 为 'custom'。 */
  eqPreset: string;
  eqBands: number[];
  /**
   * 当前曲目的波形包络（0..1，宿主下发的 400 桶；`null` = 还没拿到或拿不到）。
   * 它是**纯展示数据**：拿不到就退回原来的细轨，绝不因此报错或拦住播放。
   */
  wavePeaks: number[] | null;
  /** 已为哪一首发起过波形请求：换歌要重新取，同一首不重复取。 */
  waveTrackId: string | null;
  query: string;
  /** 在线补全结果：id → { title?, artist?, album?, cover? }。 */
  meta: Record<string, MetaEntry>;
  match: MatchState | null;
  /** 一键补全：确认条 + 批处理进度。 */
  pendingComplete: boolean;
  /** 一键补全是否替换已有内嵌封面（默认 false：只补缺失）。逐首手动应用不走这里。 */
  completeOverwriteCover: boolean;
  completing: boolean;
  completeTotal: number;
  completeDone: number;
  completeFailed: number;
  completeSkipped: number;
  /** 'title' | 'artist' | 'duration' | 'none'（localStorage 里是未校验的字符串）。 */
  sortKey: string;
  sortDir: "asc" | "desc";
  /** 待确认删除的曲目下标（-1 = 无）。替代 window.confirm 的应用内确认。 */
  pendingDelete: number;
  /**
   * 全屏播放器弹层三态（closed → open → closing）。**必须放在 player store 里**，
   * 不能是视图局部 useState：`conversation.view` 在切到对话时会卸载本视图，
   * 局部状态随之丢失，回来就只剩列表页（用户报的「切出去再切回来全屏播放器没了」）。
   */
  playerPhase: "closed" | "open" | "closing";
  /** MV 就地放大：同 playerPhase，跨视图卸载保留。 */
  mvBig: boolean;
  /** 封面放大预览：同 playerPhase，跨视图卸载保留。 */
  zoomOpen: boolean;
}

/** localStorage `dsh-music:prefs`：原始 JSON，字段都可能缺失/类型不对。 */
interface PlaybackPrefs {
  mode?: string;
  volume?: number;
  sortKey?: string;
  sortDir?: string;
  /** 上次播放位置（换目录/刷新后回补）。 */
  last?: { id: string; time: number } | undefined;
  rgMode?: string;
  rgPreampDb?: number;
  eqPreset?: string;
  eqBands?: number[];
}

/** 可见列表（筛选 + 排序后的行序）里的一行。 */
interface TrackRow {
  track: MusicTrack;
  index: number;
}

/** visibleRows() 的缓存，按 (tracks, query, sort, meta) 的 identity 失效。 */
interface RowsCache {
  tracks: MusicTrack[];
  query: string;
  sortKey: string;
  sortDir: string;
  section: LibrarySection;
  mediaFilter: MediaFilter;
  favorites: Set<string>;
  meta: Record<string, MetaEntry>;
  rows: TrackRow[];
}

/** 叠加在线补全后的展示信息（effective 的返回；不改动 state.tracks 本身）。 */
interface TrackView {
  id: string;
  name: string;
  title: string;
  artist?: string | null;
  album?: string | null;
  duration?: number | null;
  kind?: string | null;
}

/**
 * 宿主 locale 翻译器（`ctx.locale.bind(NS)`）。字典里**参数化**的键返回构造函数
 * 而不是文案，所以按实际用法逐键声明 —— 新增参数化键时 tsc 会直接报出来。
 */
interface DshTranslator {
  (key: "confirm.delete"): (title: string) => string;
  (key: "confirm.complete" | "stats" | "stats.drm"): (count: number) => string;
  (key: "complete.progress"): (done: number, total: number, failed: number, skipped: number) => string;
  (key: "scan.progress"): (parsed: number, total: number) => string;
  (key: "rg.measuring"): (done: number, total: number) => string;
  (key: string, ...args: unknown[]): string;
}

/**
 * createPlayer() 返回的 player 单例 API。每一个成员在 api0 里都有对应实现；
 * 这里显式声明是为了让 `window.__dshMusicPlayer` 可静态检查（原来整个 API 是
 * 隐式 any，任何拼写错误都要等运行时才发现）。`t` 由 apply() 注入，故可选。
 */
interface MusicPlayerApi {
  setView(view: LibraryView): void;
  setMediaFilter(media: MediaFilter): void;
  toggleSidebar(): void;
  toggleFavorite(id: string): void;
  t?: DshTranslator;
  getState(): PlayerState;
  subscribe(listener: () => void): () => void;
  load(): Promise<void>;
  refresh(): Promise<void>;
  pick(): Promise<void>;
  setDir(dir: string): Promise<void>;
  play(index: number): void;
  remove(index: number): void;
  cancelRemove(): void;
  confirmRemove(): Promise<void>;
  toggle(): void;
  /** 插件停用/卸载时停止播放并断开流（lifecycle 清理语义）。 */
  halt(): void;
  /** 领取本代 activation 租约号（见 api0.acquire）。 */
  acquire(): number;
  /** 当前租约号。 */
  lease(): number;
  /**
   * 打开全屏播放器弹层。状态存在 player 单例里 —— 切到对话会让视图卸载，
   * 回来时仍是全屏播放器（而不是列表页）。
   */
  openPlayer(): void;
  /**
   * 收起全屏播放器：先切 closing 播 200ms 退出动画再卸载。
   * 定时器由 player 持有，视图卸载不会把它清掉（否则回来卡在 closing 态）。
   */
  closePlayer(): void;
  /** MV 就地放大开关（跨视图卸载保留）。 */
  toggleMvBig(): void;
  /** 封面放大预览开关（跨视图卸载保留）。 */
  setZoomOpen(open: boolean): void;
  next(): void;
  prev(): void;
  seek(value: number): void;
  /** ReplayGain：模式（'off' | 'track' | 'album'）与可选前级增益（dB）。 */
  setReplayGain(mode: string, preampDb?: number): void;
  /** 均衡器：传预设 id（'flat' | 'pop' | …）或自定义每段增益（dB，长度 10，自动夹范围）。 */
  setEqualizer(presetOrBands: string | number[]): void;
  /** 预热 /session（媒体直连基址）。 */
  warmSession(): void;
  /** MV 画面：React 侧把这个媒体元素搬进全屏播放器的舞台。 */
  media(): HTMLVideoElement;
  /** body 上的停靠位：视图卸载时把媒体元素搬回这里，避免被移出文档而暂停。 */
  mediaPark(): HTMLDivElement | null;
  retryVideo(track: MusicTrack): void;
  setVolume(value: number): void;
  toggleMode(): void;
  setQuery(query: string): void;
  toggleSort(key: string): void;
  match(id: string, query?: string): Promise<void>;
  closeMatch(): void;
  clearError(): void;
  toggleMute(): void;
  applyMatch(candidate: MatchCandidate, writeFile: boolean, replaceCover: boolean): Promise<void>;
  setCompleteOverwriteCover(on: boolean): void;
  completeRequest(): void;
  cancelComplete(): void;
  stopComplete(): void;
  completeAll(): Promise<void>;
  clearMeta(id: string): void;
  effective(track: MusicTrack | undefined): TrackView | undefined;
  coverFor(track: MusicTrack | undefined): string;
  /** 实时播放时钟（给平滑进度条用）。 */
  now(): number;
  /** 可见列表：渲染与播放推进共用的同一顺序（所见即所播）。 */
  visibleRows(): TrackRow[];
}

/** module.exports 的形状（宿主只读这两个字段）。 */
interface MusicPlayerExports {
  apply?: (ctx: unknown) => void;
  inject?: string[];
}

window.__ModuleLoader__.load({
  id: "@heshuren/dsh-music-player",
  factory: (require) => {
    var module: { exports: MusicPlayerExports } = { exports: {} };
    var exports = module.exports;
    const React = require("react");
    const h = React.createElement;
    const { useEffect, useRef, useState, useSyncExternalStore } = React;

    /**
     * DSH 内置图标与 Tooltip，来自平台种子模块
     * `@deepseek-ai/dsh-client-ui-primitives`（client/web/src/platform.ts 的
     * PLATFORM_MODULES 之一）：它在 shell 启动时就注入了冻结模块表，所以这里的
     * require 必定命中 shell 的那一份实例——图标 SVG 与 Tooltip 的 CSS Module
     * 都已经随 shell 加载，插件不必再自带一份样式，悬停气泡因此和 DSH 官方
     * 完全同源。
     * 用 try/catch 兜底：万一宿主没有该种子模块，退回自绘图标 + 原生 title，
     * 绝不因为一个装饰性依赖白屏。
     */
    let Tooltip: RuntimeComponent | null = null;
    let DshInput: RuntimeComponent | null = null;
    let dsIcons: Record<string, unknown> = {};
    try {
      const primitives = require("@deepseek-ai/dsh-client-ui-primitives");
      Tooltip = typeof primitives.Tooltip === "function" ? primitives.Tooltip : null;
      DshInput = typeof primitives.Input === "function" ? primitives.Input : null;
      dsIcons = primitives;
    } catch {
      // 老宿主/受限模块表：保持原有图标与 title 提示。
    }
    /**
     * 官方图标在 DSH 0.1.6 与 0.1.7 之间换过整套命名：
     *   0.1.6（ic_ds_* 时代）IconPlayOutline16 / IconFolderOpen16 / IconSparkle16
     *   0.1.7+（权重体系）   IconPlayOutlineRegular|Medium / IconFolderOpenRegular / IconSparkleRegular
     * 名字对不上时必须显式回退，不能静默——之前只写了 0.1.6 的名字，在 0.1.7 上
     * 全部解析失败、悄悄退回自绘 SVG，表现就是「界面什么都没变」。
     * 这里按候选名依次探测，命中即用，全都没有才用自绘 SVG。
     */
    const officialIcon = (candidates, size, fallback) => {
      for (const exportName of candidates) {
        const Component = dsIcons[exportName];
        if (typeof Component === "function") return h(Component, { size });
      }
      return fallback;
    };

    const NS = "dsh-music-player";
    /**
     * 宿主端点基址。必须是 /api 之下：DSH Desktop 的 Electron 自定义协议只把
     * /api/* 转给宿主进程，其余路径按静态资源回落到 index.html；Web 侧
     * @deepseek-ai/dsh-client-connection 也只把 /api 前缀接到连接层。
     * 因此同一个基址在 dsh web 与 dsh desktop 上都是同源的。
     */
    const API_BASE = "/api/dsh-music";
    /** 旧版宿主入口的前缀（`/dsh-music/api/library`），仅用于一次性回落探测。 */
    const LEGACY_API_BASE = "/dsh-music/api";
    /**
     * 当前有效的宿主基址。首选 API_BASE；如果宿主进程还是旧版入口（只注册了
     * /dsh-music 前缀），首次请求会 404 —— 此时自动切到 LEGACY_API_BASE 并只探一次，
     * 避免「客户端 bundle 已随刷新更新、宿主入口却要重启进程」这一窗口期直接报错。
     */
    let endpointBase = API_BASE;
    /**
     * 是否已确认当前入口可用。**只在采纳成功时置位**：探测失败不置位，下一次仍可
     * 重试（原实现在探测**之前**置一次性标志，失败一次就永久失去回落机会）。
     */
    let entryResolved = false;
    /**
     * 是否降级到了旧前缀。这是**信任模型降级**：从 `/api` 的连接层 Host/Origin
     * 栅栏 + 浏览器会话，退到插件自建的栅栏 —— `composition.zh.md:143` 要求偏离
     * 计划必须被报告，不能顺带发生，所以这里留一个可观察的状态位（A1-02）。
     */
    // 注：原有一个 `downgradedToLegacy` 只写不读（降级状态由 hostEntry 表达、
    // 由 onDowngrade() 上报），属重构残留，已删 —— 见 tsconfig 的 noUnusedLocals。
    /** 降级发生时的通知槽：状态对象在 api() 之后才创建，所以用晚绑定。 */
    let onDowngrade: (() => void) | null = null;
    /**
     * 这些端点的 404 **只可能**意味着一件事：路由不存在（宿主入口是旧版）—— 它们
     * 在任何健康宿主上都答 200 或业务错误码（409/400/403/500），**不会答 404**。
     *
     * 反过来，`cover`（无内嵌封面）/ `art`（代理失败）/ `mv`·`mvfile`（缓存未命中）/
     * `stream`（文件不在了）/ `match` 的 404 是**正常业务语义**，绝不能拿它们当
     * 「宿主是旧入口」的信号 —— 否则一次「这首歌没封面」就会被误判成入口降级
     * （AGENTS.md §2.8）。所以判据是**端点语义 + 正向识别**，不是裸状态码。
     */
    const ROUTE_MISSING_404_ENDPOINTS = new Set(['library', 'session', 'refresh', 'dir', 'apply', 'pick', 'delete', 'caps', 'mvconvert']);
    /**
     * 旧入口的**正向指纹**：旧前缀必须真答出一个宿主数据对象（非错误信封）才算
     * 认出来了。「不是 404」不算证据。
     */
    const looksLikeHostPayload = (value) => value !== null && typeof value === "object"
      && !Array.isArray(value) && typeof value.error !== "string";
    /**
     * 系统「正在播放」（macOS 状态栏 / 控制中心 / 锁屏）取封面用的**绝对**地址前缀。
     *
     * 两个硬约束叠在一起，Desktop 才需要这套东西：
     *  1. Chromium 的 MediaImage 只收 http/https/data/blob（二进制原话
     *     "MediaImage src can only be of http/https/data/blob scheme"）——
     *     Desktop 页面是 dsh-app://app，相对路径直接被丢掉；
     *  2. 换成回环 http 之后，系统取图又是**浏览器内部发起**的，带着发起页的痕迹
     *     （实测 `Origin: dsh-app://app` / `Sec-Fetch-Site: cross-site`），
     *     会被插件自己的 Host/Origin 栅栏判 403 —— 页面也补不了这个头。
     *
     * 所以宿主专门开了 token 端点（/dsh-music/api/system-art?t=…）：随机 token 即
     * 能力凭证，只认 token 不看 Host/Origin，token 只随鉴权过的 /session 发给本页。
     * 这里拿到的就是带 token 的绝对基址；Web 端继续用同源地址（本来就正常）。
     */
    let systemArtBase: string | null = null;
    /**
     * 媒体直连基址（token 版）。Desktop 页面是 dsh-app://，媒体 src 走 Desktop 转发，
     * 而转发会让流丢掉 Range/206 → 浏览器判定"不可 seek"，拖动/快进就回到 0 秒。
     * 用 token 版的绝对回环地址直连，Range 才是真的（和封面取图同一套机制）。
     */
    let systemStreamBase: string | null = null;
    let systemArtBasePromise: Promise<string | null> | null = null;
    /** 上次成功取到 /session 的时间；超过 TTL 就重取（宿主热重载会轮换 token）。 */
    let sessionBaseFetchedAt = 0;
    const SESSION_BASE_TTL_MS = 60 * 1000;
    /** token 基址自愈只做一次，避免「失败→重取→再失败」的死循环。 */
    let sessionBaseHealed = false;
    /** 丢掉缓存的会话基址，下一次 ensureStreamBase/loadSystemArtBase 会重新取。 */
    const invalidateSessionBase = () => {
      systemArtBasePromise = null;
      systemArtBase = null;
      systemStreamBase = null;
      sessionBaseFetchedAt = 0;
    };
    const loadSystemArtBase = (force: boolean = false): Promise<string | null> => {
      // 缓存带 TTL：宿主每次热重载 createHost() 都会（曾经）轮换 token，而客户端把
      // 基址缓存了整个页面生命周期 —— 过期快照会让音频 403 到刷新页面为止。
      if (force) sessionBaseFetchedAt = 0;
      if (systemArtBasePromise !== null && Date.now() - sessionBaseFetchedAt < SESSION_BASE_TTL_MS) return systemArtBasePromise;
      systemArtBasePromise = (async () => {
        /** 采纳一份 /session 载荷；只有真的拿到基址才算成功（正向识别）。 */
        const adoptSession = (payload: unknown): boolean => {
          if (payload === null || typeof payload !== "object") return false;
          const p = payload as { systemArtBase?: unknown; systemStreamBase?: unknown };
          let got = false;
          if (typeof p.systemArtBase === "string" && p.systemArtBase.length > 0) { systemArtBase = p.systemArtBase; got = true; }
          if (typeof p.systemStreamBase === "string" && p.systemStreamBase.length > 0) { systemStreamBase = p.systemStreamBase; got = true; }
          return got;
        };
        try {
          if (adoptSession(await api("/api/session"))) {
            sessionBaseFetchedAt = Date.now();
            return systemArtBase;
          }
        } catch {
          // 落到下面用插件自建的回环路由再试一次。
        }
        // ⚠️ 这条回落**只给 /session**，因为它是唯一「以下发回环 token 基址为目的」的
        // 端点 —— 那个基址存在的意义就是绕开平台 /api 的栅栏，让 Chromium 内部发起的
        // 取图/取媒体能走通。所以它有资格自己走插件自建的回环路由。
        //
        // 为什么需要它：平台 /api 的 admit() 在**路由之前**判 Host/Origin 栅栏与浏览器
        // 会话，Desktop 渲染进程拿 /session 会得到 **401/403，而不是 404**。A1-02 的通用
        // 回落只在 404 触发，于是这里永远回落不了 ⇒ 基址恒为空 ⇒ 媒体只能用相对地址
        // ⇒ Desktop 转发丢 Range ⇒ seekable=[0,0] ⇒ **一拖进度条就回 0 秒**（真机读数）。
        // 其余端点不享受这条：把一次普通的 403 洗成降级会破坏信任边界（§2.8）。
        if (endpointBase !== LEGACY_API_BASE) {
          try {
            const legacy = await fetch(LEGACY_API_BASE + "/session");
            const payload = await legacy.json().catch(() => null);
            if (legacy.ok && adoptSession(payload)) {
              if (typeof onDowngrade === "function") onDowngrade();
              sessionBaseFetchedAt = Date.now();
              return systemArtBase;
            }
          } catch {
            // 两条路都不通：保持无基址，由 healUnseekableSource 继续尝试。
          }
        }
        return systemArtBase;
      })();
      return systemArtBasePromise;
    };
    /**
     * 平台探测：Desktop 的 app 文档由 preload-app 注入 window.dshDesktop
     * （只有 { protocolVersion } 标记，不带任何 IPC 能力）；Web 上不存在。
     * 官方判据见 apps/desktop/src/preload-app.ts。
     */
    const DESKTOP = typeof window !== "undefined"
      && typeof window.dshDesktop === "object"
      && window.dshDesktop !== null;
    const zh = {
      "view.music": "音乐",
      "view.all": "全部",
      "view.audio": "音频",
      "view.mv": "MV",
      "view.favorites": "收藏",
      "view.filter": "列表视图",
      "view.showAll": "查看全部",
      "view.allSongs": "全部歌曲",
      "view.recent": "最近添加",
      "nav.library": "资料库",
      "nav.mine": "我的",
      "action.more": "更多操作",
      "sidebar.collapse": "收起侧边栏",
      "sidebar.expand": "展开侧边栏",
      "col.added": "添加",
      "empty.view": "这个视图还没有内容",
      "empty.viewHint": "切换视图，或在行内点星标收藏",
      "action.chooseDir": "选择目录",
      "action.inputDir": "手动输入路径",
      "action.inputDir.placeholder": "粘贴本地目录路径，如 D:\\Music 或 ~/Music",
      "action.confirm": "确定",
      "action.refresh": "刷新",
      "action.delete": "删除",
      "action.cancel": "取消",
      "confirm.delete": (title) => `确定删除「${title}」吗？将同时删除本地文件，此操作不可恢复。`,
      "action.search.placeholder": "搜索歌曲或歌手",
      "action.match.tip": "在线补全原名 / 歌手 / 封面",
      "action.matching": "正在匹配…",
      "action.search": "搜索",
      "action.closeSearch": "收起搜索",
      "search.active": "筛选中",
      "match.title": "在线补全元数据",
      "action.import": "从链接导入",
      "import.title": "从链接导入",
      "import.urlLabel": "视频链接（每行一个）",
      "import.urlPlaceholder": "粘贴 B 站 / YouTube / Vimeo / SoundCloud 链接，每行一个",
      "import.urlHint": "可一次粘贴多个链接；同时下载 3 个，其余自动排队",
      "import.batchHint": "批量导入使用自动最佳清晰度；单链接可先探测",
      "import.kind": "下载内容",
      "import.audio": "音频",
      "import.video": "视频",
      "import.audioHint": "音频保存为 MP3，并写入作者、标题与封面",
      "import.videoHint": "视频保存为 MP4，作为 MV 曲目进入列表",
      "import.target": "保存到当前音乐目录：",
      "import.notice": "请只下载你拥有版权或已获授权的内容；不支持登录、付费墙或 DRM 绕过。",
      "import.start": "开始导入",
      "import.starting": "正在启动…",
      "import.close": "关闭",
      "import.cancel": "取消下载",
      "import.cancelling": "正在取消…",
      "import.cancelAll": "取消全部",
      "import.emptyUrls": "请先粘贴至少一个链接",
      "import.backgroundHint": "关闭后继续后台下载",
      "import.done": "已加入播放列表",
      "import.cancelled": "已取消",
      "import.errorPrefix": "导入失败：",
      "import.phase.queued": "排队中",
      "import.phase.starting": "准备中",
      "import.phase.error": "失败",
      "import.phase.metadata": "读取链接信息",
      "import.phase.download": "下载中",
      "import.phase.finalize": "写入标签与封面",
      "import.missing": "缺少下载工具",
      "import.missingHint": "需要 yt-dlp 与 ffmpeg。macOS 可运行：brew install yt-dlp ffmpeg",
      "import.unsupported": "只支持公开的 B 站 / YouTube / Vimeo / SoundCloud 链接",
      "import.speed": "速度",
      "import.eta": "剩余",
      "import.savedAs": "保存为",
      "import.warning": "提示：",
      "import.quality": "清晰度",
      "import.qualityBest": "自动（最佳可用）",
      "import.qualityHint": "选择清晰度上限；B 站 1080P 通常需要登录",
      "import.probing": "正在解析清晰度…",
      "import.probeError": "清晰度解析失败，将按自动最佳下载",
      "import.recommended": "推荐",
      "import.approx": "约",
      "import.login": "B 站登录",
      "import.loginHint": "登录后可获取账号有权的 1080P 及以上清晰度",
      "import.loginButton": "扫码登录",
      "import.loginLogged": "已登录：",
      "import.logout": "退出登录",
      "import.qrHint": "请用 B 站 App 扫码",
      "import.qrWaiting": "等待扫码…",
      "import.qrScanned": "已扫码，请在手机上确认",
      "import.qrExpired": "二维码已过期，请刷新",
      "import.qrRefresh": "刷新二维码",
      "import.qrError": "登录失败：",
      "import.loginSaved": "cookie 仅保存在本机（0600），不写入日志",
      "import.vip": "大会员",
      "match.none": "没有找到匹配结果，换个关键词或手动填写标签",
      "match.clear": "清除已补全信息",
      "match.source": "结果来自 QQ 音乐 / iTunes / 网易云 / MusicBrainz；勾选后写回标签并重命名文件",
      "action.completeAll": "一键补全",
      "action.stop": "停止",
      "complete.progress": (done, total, failed, skipped) => `补全中… ${done}/${total}`
        + (failed > 0 ? `（失败 ${failed}）` : "")
        + (skipped > 0 ? `（${skipped} 首已正确或置信不足，跳过）` : ""),
      "confirm.complete": (count) => `将逐首检查 ${count} 首歌曲（多源搜索：QQ 音乐 / iTunes / 网易云 / MusicBrainz）：标签与文件名都已正确的自动跳过，只写入高置信度的结果，置信不足的一律不动。封面默认只补缺失；勾选「覆盖已有封面」才会替换已有封面。是否继续？`,
      "complete.none": "没有需要补全的歌曲",
      "match.writeFile": "写入标签并重命名文件",
      "match.replaceCover": "替换已有封面",
      "complete.replaceCover": "覆盖已有封面",
      "match.applying": "正在写入文件…",
      "action.picking": "正在选择…",
      "action.loading": "正在扫描…",
      "col.title": "歌曲名",
      "col.artist": "歌手",
      "col.duration": "时长",
      "empty.title": "尚未选择音乐目录",
      "empty.hint": "选择一个本地目录，支持 flac / mp3 / m4a / ogg / wav 等常见格式",
      "empty.tracks": "该目录下没有找到音频文件",
      "empty.search": "没有匹配的歌曲",
      "empty.searchHint": "换个关键词，或清除搜索",
      "action.clearSearch": "清除搜索",
      "action.dismiss": "关闭提示",
      "status.buffering": "缓冲中…",
      "mode.loop": "列表循环",
      "mode.one": "单曲循环",
      "stats": (count) => `${count} 首歌曲`,
      "stats.truncated": "已达扫描上限",
      "stats.drm": (count) => `${count} 个 DRM 加密包已跳过`,
      "stats.drmTip": "Apple .movpkg 是 FairPlay 加密的 HLS 离线包，任何第三方播放器都无法解密；请在 Apple Music / Apple TV 应用内播放",
      "scan.progress": (parsed, total) => total > 0 ? `正在扫描… ${parsed}/${total}` : `正在扫描… ${parsed}`,
      "error.prefix": "出错了：",
      "error.legacyEntry": "已回落到旧版宿主入口（/dsh-music 前缀）：请求不再经连接层的 Host/Origin 栅栏与浏览器会话鉴权。请重启 dsh 以恢复。",
      "error.unsupported": "无法播放该文件（格式不受支持或文件已移动）",
      "error.staleHost": "宿主插件仍是旧版（没有重载）：请在终端重启 dsh web，然后刷新本页",
      "a11y.progress": "播放进度",
      "action.prev": "上一首",
      "action.next": "下一首",
      "action.play": "播放",
      "action.pause": "暂停",
      "action.volume": "音量",
      "action.mute": "静音",
      "action.unmute": "取消静音",
      "rg.label": "响度归一化（ReplayGain）",
      "rg.off": "关闭",
      "rg.track": "单曲",
      "rg.album": "专辑",
      "eq.label": "均衡器",
      "eq.flat": "原声",
      "eq.pop": "流行",
      "eq.rock": "摇滚",
      "eq.classical": "古典",
      "eq.jazz": "爵士",
      "eq.bass": "低音增强",
      "eq.vocal": "人声",
      "eq.electronic": "电子",
      "rg.measuring": (done, total) => total > 0 ? `正在测量响度… ${done}/${total}` : "正在测量响度…",
      "player.open": "打开播放器",
      "player.close": "收起播放器",
      "player.webFullscreen": "网页全屏",
      "player.exitWebFullscreen": "退出网页全屏",
      "player.fullscreen": "全屏",
      "player.exitFullscreen": "退出全屏",
      "player.queue": "接下来播放",
      "player.favorite": "收藏",
      "player.unfavorite": "取消收藏",
      "player.more": "更多操作",
      "player.match": "在线补全元数据",
      "player.delete": "删除本地文件",
      "player.noTrack": "在列表里点一首歌开始播放",
      "mv.remuxing": "正在准备 MV（换封装）…",
      "mv.transcoding": "正在准备 MV（转码）…",
      "mv.failed": "这个 MV 播不了",
      "mv.fastHint": "极速转码：ultrafast，最长边最高 1080P，优先速度",
      "mv.noFfmpeg": "需要转封装才能播放：装一个 ffmpeg（brew install ffmpeg）再试",
      "mv.retry": "重试",
      "confirm.convert": "（其中 {0} 个 MV 会顺带转成 MP4，重编码那档会掉一点画质）",
      "confirm.deleteOriginal": "转换成功后删除原件（丢进废纸篓）",
    };
    const en = {
      "view.music": "Music",
      "view.all": "All",
      "view.audio": "Audio",
      "view.mv": "MV",
      "view.favorites": "Favorites",
      "view.filter": "Library view",
      "view.showAll": "Show all",
      "view.allSongs": "All songs",
      "view.recent": "Recently added",
      "nav.library": "Library",
      "nav.mine": "Mine",
      "action.more": "More actions",
      "sidebar.collapse": "Collapse sidebar",
      "sidebar.expand": "Expand sidebar",
      "col.added": "Added",
      "empty.view": "Nothing in this view yet",
      "empty.viewHint": "Switch views, or star tracks from the list",
      "action.chooseDir": "Choose Folder",
      "action.inputDir": "Enter path manually",
      "action.inputDir.placeholder": "Paste a local folder path, e.g. D:\\Music or ~/Music",
      "action.confirm": "OK",
      "action.refresh": "Refresh",
      "action.delete": "Delete",
      "action.cancel": "Cancel",
      "confirm.delete": (title) => `Delete "${title}"? The local file will be permanently removed. This cannot be undone.`,
      "action.search.placeholder": "Search title or artist",
      "action.match.tip": "Fetch title / artist / cover online",
      "action.matching": "Matching…",
      "action.search": "Search",
      "action.closeSearch": "Close search",
      "search.active": "Filtering",
      "match.title": "Online metadata",
      "action.import": "Import from link",
      "import.title": "Import from link",
      "import.urlLabel": "Video links (one per line)",
      "import.urlPlaceholder": "Paste Bilibili / YouTube / Vimeo / SoundCloud links, one per line",
      "import.urlHint": "Paste several links at once; three download in parallel, the rest queue",
      "import.kind": "Download",
      "import.audio": "Audio",
      "import.video": "Video",
      "import.audioHint": "Audio is saved as MP3 with author, title and cover tags",
      "import.videoHint": "Video is saved as MP4 and appears as an MV track",
      "import.target": "Save to the current music folder: ",
      "import.notice": "Download only content you own or have permission to download. Sign-in, paywall and DRM bypasses are not supported.",
      "import.start": "Start import",
      "import.starting": "Starting…",
      "import.close": "Close",
      "import.cancel": "Cancel download",
      "import.cancelling": "Cancelling…",
      "import.cancelAll": "Cancel all",
      "import.emptyUrls": "Paste at least one link first",
      "import.backgroundHint": "Downloads continue in the background after closing",
      "import.done": "Added to the playlist",
      "import.cancelled": "Cancelled",
      "import.errorPrefix": "Import failed: ",
      "import.phase.queued": "Queued",
      "import.phase.starting": "Preparing",
      "import.phase.error": "Failed",
      "import.phase.metadata": "Reading link metadata",
      "import.phase.download": "Downloading",
      "import.phase.finalize": "Writing tags and cover",
      "import.missing": "Missing download tools",
      "import.missingHint": "yt-dlp and ffmpeg are required. On macOS run: brew install yt-dlp ffmpeg",
      "import.unsupported": "Only public Bilibili / YouTube / Vimeo / SoundCloud links are supported",
      "import.speed": "Speed",
      "import.eta": "ETA",
      "import.savedAs": "Saved as",
      "import.warning": "Note: ",
      "import.quality": "Quality",
      "import.qualityBest": "Auto (best available)",
      "import.qualityHint": "Choose a height cap; Bilibili 1080P usually requires sign-in",
      "import.batchHint": "Batch imports use the best automatic quality; probe a single link first if needed",
      "import.probing": "Checking available formats…",
      "import.probeError": "Could not read formats; auto best will be used",
      "import.recommended": "Recommended",
      "import.approx": "~",
      "import.login": "Bilibili sign-in",
      "import.loginHint": "Sign in to get 1080P and higher when your account allows it",
      "import.loginButton": "Scan QR to sign in",
      "import.loginLogged": "Signed in: ",
      "import.logout": "Sign out",
      "import.qrHint": "Scan with the Bilibili app",
      "import.qrWaiting": "Waiting for scan…",
      "import.qrScanned": "Scanned — confirm on your phone",
      "import.qrExpired": "QR expired — refresh it",
      "import.qrRefresh": "Refresh QR",
      "import.qrError": "Sign-in failed: ",
      "import.loginSaved": "The cookie is stored locally (mode 0600) and never logged",
      "import.vip": "Premium",
      "match.none": "No matches found — try another keyword",
      "match.clear": "Clear fetched info",
      "match.source": "From QQ / iTunes / NetEase / MusicBrainz; when checked, tags are written and the file renamed",
      "action.completeAll": "Complete All",
      "action.stop": "Stop",
      "complete.progress": (done, total, failed, skipped) => `Completing… ${done}/${total}`
        + (failed > 0 ? ` (${failed} failed)` : "")
        + (skipped > 0 ? ` (${skipped} already correct or low confidence)` : ""),
      "confirm.complete": (count) => `Check all ${count} song(s) against multiple sources (QQ / iTunes / NetEase / MusicBrainz): songs whose tags and filename are already correct are skipped, only high-confidence results are written, low-confidence ones stay untouched. Covers fill missing art only; check "Replace existing covers" to overwrite. Continue?`,
      "complete.none": "Nothing to complete",
      "match.writeFile": "Write tags & rename file",
      "match.replaceCover": "Replace existing cover",
      "complete.replaceCover": "Replace existing covers",
      "match.applying": "Writing file…",
      "action.picking": "Picking…",
      "action.loading": "Scanning…",
      "col.title": "Title",
      "col.artist": "Artist",
      "col.duration": "Time",
      "empty.title": "No music folder selected",
      "empty.hint": "Pick a local folder — flac / mp3 / m4a / ogg / wav and more are supported",
      "empty.tracks": "No audio files found in this folder",
      "empty.search": "No matching songs",
      "empty.searchHint": "Try another keyword, or clear the search",
      "action.clearSearch": "Clear search",
      "action.dismiss": "Dismiss",
      "status.buffering": "Buffering…",
      "mode.loop": "Repeat All",
      "mode.one": "Repeat One",
      "stats": (count) => `${count} songs`,
      "stats.truncated": "scan limit reached",
      "stats.drm": (count) => `${count} DRM-protected package(s) skipped`,
      "stats.drmTip": "Apple .movpkg is a FairPlay-encrypted HLS bundle; no third-party player can decrypt it — play it in Apple Music / Apple TV",
      "scan.progress": (parsed, total) => total > 0 ? `Scanning… ${parsed}/${total}` : `Scanning… ${parsed}`,
      "error.prefix": "Error: ",
      "error.legacyEntry": "Fell back to the legacy host entry (/dsh-music prefix): requests no longer go through the connection layer Host/Origin fence and browser-session auth. Restart dsh to recover.",
      "error.unsupported": "Cannot play this file (unsupported format or file moved)",
      "error.staleHost": "Host plugin is still the old build (not reloaded): restart dsh web, then refresh this page",
      "a11y.progress": "Playback position",
      "action.prev": "Previous",
      "action.next": "Next",
      "action.play": "Play",
      "action.pause": "Pause",
      "action.volume": "Volume",
      "action.mute": "Mute",
      "action.unmute": "Unmute",
      "rg.label": "ReplayGain loudness normalisation",
      "rg.off": "Off",
      "rg.track": "Track",
      "rg.album": "Album",
      "eq.label": "Equaliser",
      "eq.flat": "Flat",
      "eq.pop": "Pop",
      "eq.rock": "Rock",
      "eq.classical": "Classical",
      "eq.jazz": "Jazz",
      "eq.bass": "Bass boost",
      "eq.vocal": "Vocal",
      "eq.electronic": "Electronic",
      "rg.measuring": (done, total) => total > 0 ? `Measuring loudness… ${done}/${total}` : "Measuring loudness…",
      "player.open": "Open player",
      "player.close": "Collapse player",
      "player.webFullscreen": "Web fullscreen",
      "player.exitWebFullscreen": "Exit web fullscreen",
      "player.fullscreen": "Fullscreen",
      "player.exitFullscreen": "Exit fullscreen",
      "player.queue": "Continue Playing",
      "player.favorite": "Favorite",
      "player.unfavorite": "Remove favorite",
      "player.more": "More",
      "player.match": "Fetch metadata online",
      "player.delete": "Delete local file",
      "player.noTrack": "Pick a song from the list to start",
      "mv.remuxing": "Preparing the music video (remux)…",
      "mv.transcoding": "Preparing the music video (transcoding)…",
      "mv.failed": "This music video cannot be played",
      "mv.fastHint": "Fast transcode: ultrafast, capped at 1080P on the long edge",
      "mv.noFfmpeg": "Remuxing is required: install ffmpeg (brew install ffmpeg) and retry",
      "mv.retry": "Retry",
      "confirm.convert": " ({0} MV(s) will also be converted to MP4; re-encoding loses a little quality)",
      "confirm.deleteOriginal": "Delete the original after a successful conversion (moved to Trash)",
    };

    const CSS = `
/* 透明毛玻璃：与 DSH 自己（ui-dockkit .dockScrim / --dsw-mask-blur）同款配方 ——
   color-mix 半透明底色 + backdrop-filter。根容器留一点透明度，桌面端窗口/外壳的
   背景才能透上来，否则模糊的是自己的纯色底，等于没做。 */
.dshm-root{box-sizing:border-box;position:relative;width:100%;height:100%;min-height:0;color:var(--dsw-alias-label-primary);background:color-mix(in srgb, var(--dsw-alias-bg-layer-1) 88%, transparent);font:var(--dsw-font-xs-13);flex-direction:column;display:flex;overflow:hidden}
/* 层级阶梯：菜单(5) < 全屏播放器(40) < 弹层(60) < 灯箱(80)。插件内的层级用 token，不写裸数字。 */
.dshm-root{--dshm-z-menu:5;--dshm-z-player:40;--dshm-z-modal:60;--dshm-z-lightbox:80}
/* 悬停提示包装层：官方 Tooltip 会 clone 唯一子元素，disabled 的按钮不派发鼠标
   事件，所以由这层 inline-flex 容器收 hover；自身不占额外空间。 */
.dshm-tip{display:inline-flex;min-width:0;align-items:center;flex:none}
.dshm-glyph{line-height:1}
.dshm-volIcon{flex:none;color:var(--dsw-alias-label-tertiary);align-items:center;display:inline-flex;background:none;border:0;padding:0;cursor:pointer;border-radius:4px}
.dshm-volIcon:hover{color:var(--dsw-alias-label-primary)}
.dshm-volIcon--muted{color:var(--dsw-alias-state-error-primary)}
/* 不启用 composer 悬浮（避免底部留白空隙）：恢复原布局，仅用 :has() 在音乐页隐藏两侧宽度条 */
body:has(.dshm-root) [data-width-handle]{display:none}
.dshm-root *{box-sizing:border-box}
.dshm-header{border-bottom:1px solid var(--dsw-alias-border-l2);background:color-mix(in srgb, var(--dsw-alias-bg-base) 72%, transparent);-webkit-backdrop-filter:saturate(180%) blur(6px);backdrop-filter:saturate(180%) blur(6px);flex:none;align-items:center;gap:10px;min-height:44px;padding:0 14px;display:flex}
.dshm-title{font-size:14px;font-weight:600;flex:none}
.dshm-dir{min-width:0;color:var(--dsw-alias-label-tertiary);font-family:var(--ds-font-family-code);font-size:11px;text-overflow:ellipsis;white-space:nowrap;flex:1;overflow:hidden}
.dshm-stats{color:var(--dsw-alias-label-tertiary);flex:none;font-size:11px}
/* 官方 Input 组件自带 wrap/icon/input 三层样式（高 32、bg-layer-1、border-l4、
   radius-md、focus-within 变主题色），插件只补宽度约束；下面 .dshm-search 是
   拿不到官方组件时的降级输入框。 */
.dshm-searchWrap{flex:0 1 220px;min-width:120px}
.dshm-search{border:1px solid var(--dsw-alias-border-l2);height:24px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2);border-radius:6px;flex:0 1 180px;min-width:80px;padding:0 8px;font:inherit;font-size:12px;outline:none}
.dshm-search:focus{border-color:var(--dsw-alias-state-business-primary);background:var(--dsw-alias-bg-layer-1)}
.dshm-search::placeholder{color:var(--dsw-alias-label-caption)}
.dshm-searchBox{flex:0 0 auto;align-items:center;gap:6px;display:flex;position:relative}
.dshm-searchToggle{border-radius:6px;justify-content:center;align-items:center;width:26px;height:26px;color:var(--dsw-alias-label-tertiary);background:transparent;border:0;padding:0;cursor:pointer;display:inline-flex;position:relative}
.dshm-searchToggle:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-searchToggle--active{color:var(--dsw-alias-state-business-primary)}
.dshm-searchToggle:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:1px}
.dshm-searchBox--open .dshm-searchToggle{color:var(--dsw-alias-label-primary)}
.dshm-searchBadge{background:var(--dsw-alias-state-business-primary);border-radius:50%;width:6px;height:6px;position:absolute;top:3px;right:2px;pointer-events:none}
.dshm-searchField{align-items:center;gap:4px;display:flex;animation:dshm-searchIn .16s var(--ds-ease-in-out)}
.dshm-searchField .dshm-search{flex:0 1 190px;min-width:120px}
.dshm-searchField .dshm-searchWrap{flex:0 1 200px;min-width:120px}
.dshm-searchClear{color:var(--dsw-alias-label-caption);background:transparent;border:0;border-radius:4px;cursor:pointer;width:18px;height:18px;padding:0;font-size:12px;line-height:1}
.dshm-searchClear:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
@keyframes dshm-searchIn{from{opacity:0;transform:translateX(4px)}to{opacity:1;transform:none}}
@media (prefers-reduced-motion:reduce){.dshm-searchField{animation:none}}
.dshm-btn{cursor:pointer;height:26px;color:var(--dsw-alias-label-primary);border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-fill-l1);border-radius:7px;flex:none;align-items:center;gap:5px;padding:0 10px;font:inherit;font-size:12px;display:inline-flex}
.dshm-btn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
.dshm-btn{transition:background-color .12s var(--ds-ease-in-out),border-color .12s var(--ds-ease-in-out)}
.dshm-btn:disabled{cursor:not-allowed;opacity:.45}
.dshm-error{border-bottom:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-state-error-primary);background:var(--dsw-alias-state-error-tertiary);flex:none;align-items:center;gap:8px;padding:6px 14px;font-size:12px;display:flex}
.dshm-errorClose{margin-left:auto;color:inherit;background:none;border:0;border-radius:4px;cursor:pointer;font-size:14px;line-height:1;padding:2px 6px}
.dshm-notice{border-bottom:1px solid var(--dsw-alias-border-l2);color:var(--dsw-alias-text-secondary);background:var(--dsw-alias-bg-secondary);flex:none;padding:6px 14px;font-size:12px}
.dshm-confirmBar{border-bottom:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-state-error-tertiary);flex:none;align-items:center;gap:10px;padding:8px 14px;display:flex}
.dshm-coverToggle{display:flex;align-items:center;gap:6px;margin-left:auto;cursor:pointer;white-space:nowrap}
.dshm-confirmText{min-width:0;flex:1;color:var(--dsw-alias-label-primary);font-size:12px;line-height:1.5}
.dshm-btn--danger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-state-error-primary)}
.dshm-dirEditor{border-bottom:1px solid var(--dsw-alias-border-l2);background:color-mix(in srgb, var(--dsw-alias-bg-base) 72%, transparent);-webkit-backdrop-filter:saturate(180%) blur(6px);backdrop-filter:saturate(180%) blur(6px);flex:none;align-items:center;gap:8px;padding:8px 14px;display:flex}
.dshm-dirInput{border:1px solid var(--dsw-alias-border-l2);height:28px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2);border-radius:7px;flex:1;min-width:0;padding:0 10px;font:inherit;font-size:12px;font-family:var(--ds-font-family-code);outline:none}
.dshm-dirInput:focus{border-color:var(--dsw-alias-state-business-primary);background:var(--dsw-alias-bg-layer-1)}
.dshm-dirInput::placeholder{color:var(--dsw-alias-label-caption)}
.dshm-tableWrap{min-height:0;flex:1;overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable}
.dshm-table{border-spacing:0;table-layout:fixed;width:100%;font-size:12px}
/* 列头是真正的毛玻璃：它在滚动容器内 position:sticky，列表从它下面滑过——
   这里能实打实看到模糊，而不是对着纯色底做无用功。 */
.dshm-table th{z-index:2;border-bottom:1px solid var(--dsw-alias-border-l2);height:30px;color:var(--dsw-alias-label-tertiary);background:color-mix(in srgb, var(--dsw-specific-sidebar-fill) 78%, transparent);-webkit-backdrop-filter:saturate(180%) blur(6px);backdrop-filter:blur(6px);text-align:left;font-weight:500;padding:0 10px;position:sticky;top:0;user-select:none;white-space:nowrap}
.dshm-table th.dshm-sortable{cursor:pointer}
.dshm-table th.dshm-sortable:hover{color:var(--dsw-alias-label-primary)}
.dshm-table th.dshm-sorted{color:var(--dsw-alias-state-business-primary)}
.dshm-table td{border-bottom:1px solid var(--dsw-alias-border-l1);height:32px;text-overflow:ellipsis;white-space:nowrap;padding:0 10px;overflow:hidden}
/* No cell padding here: the shared td padding (10px) left only 20px of content
   box for the 22px delete button, so the td clipped it and painted a "…". */
.dshm-table td.dshm-colDuration,.dshm-table th.dshm-colDuration{width:64px;text-align:right;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}
.dshm-table td.dshm-colAdded,.dshm-table th.dshm-colAdded{width:84px;color:var(--dsw-alias-label-tertiary);font-variant-numeric:tabular-nums}
.dshm-viewChip{border:1px solid transparent;height:24px;color:var(--dsw-alias-label-tertiary);background:transparent;border-radius:999px;align-items:center;gap:5px;padding:0 9px;font:inherit;font-size:11px;display:inline-flex;cursor:pointer;white-space:nowrap}
.dshm-viewChip:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-viewChip--active{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2);border-color:var(--dsw-alias-state-business-primary)}
.dshm-viewCount{opacity:.65;font-size:10px;font-variant-numeric:tabular-nums}
.dshm-shell{min-height:0;flex:1;display:flex;overflow:hidden}
.dshm-main{min-width:0;min-height:0;flex:1;flex-direction:column;display:flex;overflow:hidden}
.dshm-headerToggle{border:0;width:26px;height:26px;color:var(--dsw-alias-label-tertiary);background:transparent;border-radius:7px;flex:none;align-items:center;justify-content:center;padding:0;display:inline-flex;cursor:pointer}
.dshm-headerToggle:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-headerToggle--open{color:var(--dsw-alias-state-business-primary)}
.dshm-sidebar{width:196px;flex:none;border-right:1px solid var(--dsw-alias-border-l1);background:color-mix(in srgb, var(--dsw-alias-bg-layer-2) 72%, transparent);flex-direction:column;gap:2px;padding:10px 8px;display:flex;overflow:auto}
.dshm-sideBrand{color:var(--dsw-alias-label-primary);align-items:center;gap:8px;padding:2px 8px 12px;font-size:13px;font-weight:600;display:flex}
.dshm-sideBrandName{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dshm-sideLogo{color:var(--dsw-alias-state-business-primary);align-items:center;display:inline-flex}
.dshm-sideHeading{color:var(--dsw-alias-label-caption);padding:10px 8px 4px;font-size:10px;font-weight:600}
.dshm-navItem{border:0;width:100%;height:28px;color:var(--dsw-alias-label-secondary);background:transparent;border-radius:7px;align-items:center;gap:8px;padding:0 8px;font:inherit;font-size:12px;display:flex;cursor:pointer;text-align:left}
.dshm-navItem:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-navItem--active{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-1)}
.dshm-navGlyph{width:16px;color:var(--dsw-alias-label-tertiary);align-items:center;justify-content:center;display:inline-flex}
.dshm-navItem--active .dshm-navGlyph{color:var(--dsw-alias-state-business-primary)}
.dshm-navCount{margin-left:auto;color:var(--dsw-alias-label-caption);font-size:10px;font-variant-numeric:tabular-nums}
.dshm-navLabel{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dshm-typeBar{align-items:center;gap:4px;padding:5px 14px;border-bottom:1px solid var(--dsw-alias-border-l1);flex:none;display:flex;overflow-x:auto}
.dshm-mvGrid{min-height:0;flex:1;overflow:auto;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));align-content:start;gap:14px;padding:14px;display:grid}
.dshm-mvCard{border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-2);border-radius:10px;padding:0;text-align:left;color:inherit;font:inherit;display:flex;flex-direction:column;overflow:hidden;cursor:pointer;position:relative}
.dshm-mvCard:hover{border-color:var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1)}
.dshm-mvCard--active{border-color:var(--dsw-alias-state-business-primary)}
.dshm-mvThumb{aspect-ratio:16/9;background:var(--dsw-alias-fill-l1);width:100%;position:relative;overflow:hidden}
.dshm-mvThumb img{width:100%;height:100%;object-fit:cover;display:block}
.dshm-mvPlay{position:absolute;inset:0;color:#fff;background:linear-gradient(transparent 45%,rgba(0,0,0,.35));align-items:center;justify-content:center;display:flex;opacity:0;transition:opacity .12s}
.dshm-mvCard:hover .dshm-mvPlay,.dshm-mvCard--active .dshm-mvPlay{opacity:1}
.dshm-mvCardTitle{padding:8px 10px 0;font-size:12px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dshm-mvCardMeta{padding:3px 10px 9px;color:var(--dsw-alias-label-tertiary);font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dshm-mvCardMenu{position:absolute;top:6px;right:6px;z-index:2}
.dshm-rowMenuBtn{cursor:pointer;width:24px;height:24px;color:var(--dsw-alias-label-tertiary);border:0;background:transparent;border-radius:6px;align-items:center;justify-content:center;display:inline-flex;font:inherit;font-size:16px;line-height:1;padding:0}
.dshm-rowMenuBtn:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-rowMenu{position:fixed;z-index:calc(var(--dshm-z-player) - 1);min-width:146px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l2);border-radius:8px;box-shadow:0 8px 28px rgba(0,0,0,.22);padding:4px;display:flex;flex-direction:column;gap:1px}
.dshm-rowMenuItem{border:0;background:transparent;color:var(--dsw-alias-label-primary);border-radius:5px;padding:6px 9px;font:inherit;font-size:12px;text-align:left;cursor:pointer}
.dshm-rowMenuItem:hover{background:var(--dsw-alias-interactive-bg-hover)}
.dshm-rowMenuItem--danger{color:var(--dsw-alias-state-error-primary)}
.dshm-menuFav,.dshm-menuMatch,.dshm-menuDelete{width:100%}
@media (max-width: 760px){.dshm-shell{flex-direction:column}.dshm-sidebar{width:auto;border-right:0;border-bottom:1px solid var(--dsw-alias-border-l1);flex-direction:row;align-items:center;padding:6px 8px;overflow-x:auto}.dshm-sideHeading{display:none}.dshm-navItem{width:auto;flex:none}}

.dshm-colArtist{width:26%}
.dshm-row{cursor:default;transition:background-color .12s var(--ds-ease-in-out)}
.dshm-row:hover{background:var(--dsw-alias-interactive-bg-hover)}
.dshm-row:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:-2px}
.dshm-buffering{flex:none;padding:4px 14px;font-size:12px;color:var(--dsw-alias-label-tertiary);border-bottom:1px solid var(--dsw-alias-border-l2)}
.dshm-clearSearch{margin-top:2px}
.dshm-row--active{background:var(--dsw-alias-interactive-bg-active)}
.dshm-row--active .dshm-cellTitle{color:var(--dsw-alias-state-business-primary);font-weight:500}
.dshm-cellTitle{color:var(--dsw-alias-label-primary)}
.dshm-cellArtist{color:var(--dsw-alias-label-secondary)}
.dshm-empty{min-height:0;flex:1;color:var(--dsw-alias-label-tertiary);text-align:center;flex-direction:column;justify-content:center;align-items:center;gap:10px;padding:32px;display:flex}
.dshm-emptyIcon{font-size:44px;line-height:1;opacity:.5}
.dshm-emptyHint{max-width:420px;font-size:12px;line-height:1.7}
.dshm-bar{border-top:1px solid var(--dsw-alias-border-l2);background:color-mix(in srgb, var(--dsw-specific-sidebar-fill) 82%, transparent);-webkit-backdrop-filter:saturate(180%) blur(6px);backdrop-filter:saturate(180%) blur(6px);flex:none;align-items:center;gap:14px;min-height:64px;padding:8px 16px;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,2fr) minmax(0,1fr)}
.dshm-nowPlaying{min-width:0;align-items:center;gap:10px;display:flex}
/* 底部条的封面变成「打开全屏播放器」的入口（Apple Music 同款交互） */
.dshm-nowCoverBtn{cursor:pointer;border:0;background:transparent;border-radius:8px;flex:none;align-items:center;padding:0;display:inline-flex}
.dshm-nowCoverBtn:hover{opacity:.85}

/* ── 动效（取自 Apple Music 前端 music.apple.com 的 CSS）─────────────────────
   他们的缓动曲线只有三条在反复用：
     cubic-bezier(.215,.61,.355,1)  easeOutCubic  —— 用得最多（16 处）
     cubic-bezier(.23,1,.32,1)      easeOutQuint  —— 弹层/播放器出场（2 处）
     cubic-bezier(.76,.665,.37,1.35) 带过冲       —— 按压回弹（1 处）
   按下反馈是 scale(.88~.92)；材质是 backdrop-filter: saturate(180%) blur(60px)。 */
.dshm-root{
  --dshm-ease:cubic-bezier(.215,.61,.355,1);
  --dshm-ease-snap:cubic-bezier(.23,1,.32,1);
  --dshm-ease-spring:cubic-bezier(.76,.665,.37,1.35);
}
@keyframes dshm-playerIn{from{opacity:0;transform:scale(.965)}to{opacity:1;transform:scale(1)}}
@keyframes dshm-playerOut{from{opacity:1;transform:scale(1)}to{opacity:0;transform:scale(.975)}}
@keyframes dshm-artIn{from{opacity:0;transform:scale(1.035)}to{opacity:1;transform:scale(1)}}
.dshm-player{animation:dshm-playerIn .44s var(--dshm-ease-snap) backwards}
.dshm-player--closing{animation:dshm-playerOut .2s var(--dshm-ease) backwards;pointer-events:none}
.dshm-playerArt,.dshm-playerArtFallback{animation:dshm-artIn .5s var(--dshm-ease) backwards}
/* 按压 / 悬停的微交互（Apple 的按下是 scale(.88~.92)） */
.dshm-playerTransportBtn,.dshm-tbtn,.dshm-playerRound,.dshm-pill,.dshm-queueMore,.dshm-btn{
  transition:transform .16s var(--dshm-ease-spring),background-color .16s var(--dshm-ease),color .16s var(--dshm-ease),opacity .16s var(--dshm-ease);
}
.dshm-playerTransportBtn:active:not(:disabled),.dshm-tbtn:active:not(:disabled),.dshm-playerRound:active:not(:disabled),.dshm-pill:active:not(:disabled),.dshm-queueMore:active,.dshm-btn:active{transform:scale(.92)}
.dshm-queueRow{transition:background-color .18s var(--dshm-ease)}
/* 尊重"减少动态效果"：以上动效全部关掉（跑马灯另有同样处理） */
@media (prefers-reduced-motion:reduce){
  .dshm-player,.dshm-player--closing,.dshm-playerArt,.dshm-playerArtFallback,.dshm-coverBars i{animation:none}
  .dshm-playerTransportBtn,.dshm-tbtn,.dshm-playerRound,.dshm-pill,.dshm-queueMore,.dshm-btn,.dshm-queueRow{transition:none}
  .dshm-playerTransportBtn:active:not(:disabled),.dshm-tbtn:active:not(:disabled),.dshm-playerRound:active:not(:disabled),.dshm-pill:active:not(:disabled),.dshm-queueMore:active,.dshm-btn:active{transform:none}
}

/* ── MV（音乐视频）───────────────────────────────────────────────────────
   媒体元素是 <video>（音频文件也用它播），MV 时被搬进 .dshm-mvStage；
   弹层收起则停到 .dshm-mvPark（移动父节点不会中断播放，实测 t 连续推进）。 */
.dshm-mv{width:100%;height:100%;display:block;object-fit:contain;background:#000;border-radius:10px}
.dshm-mvPark{display:none}
/* WASM 解出来的画面：铺满画面槽，和 <video> 同一套 object-fit 规则 */
.dshm-mvCanvas{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:block}
.dshm-zoomable{cursor:zoom-in}
.dshm-lightbox{position:fixed;inset:0;z-index:var(--dshm-z-lightbox);justify-content:center;align-items:center;background:rgba(0,0,0,.72);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);display:flex}
.dshm-lightboxImg{max-width:min(88vw,900px);max-height:86vh;object-fit:contain;border-radius:14px;box-shadow:0 30px 80px rgba(0,0,0,.55)}
/* MV 放大模式：点画面后视频铺大（右栏队列让位），整套控制条仍在下方 ——
   尺寸夹在播放器区域内，永远不会超出 desktop。 */
.dshm-player--mvbig .dshm-playerBody{grid-template-columns:minmax(0,1fr);padding:0 26px 22px}
.dshm-player--mvbig .dshm-playerRight{display:none}
.dshm-player--mvbig .dshm-playerStage{--dshm-art:min(98%,1240px)}
.dshm-player--mvbig .dshm-playerMeta,.dshm-player--mvbig .dshm-progress,.dshm-player--mvbig .dshm-playerTransport{width:min(92%,1040px)}
.dshm-player--mvbig .dshm-mvStage{aspect-ratio:16/9;max-height:82vh;background:#000}

.dshm-playerControls{width:100%;min-width:0;flex-direction:column;align-items:center;gap:16px;display:flex}
/* 网页全屏：铺满浏览器视口，不进入系统全屏 */
.dshm-player.dshm-player--theater{position:fixed;inset:0;width:100vw;height:100vh;z-index:var(--dshm-z-lightbox);background:#000}
/* 原生全屏：fullscreen 元素自己填满屏幕 */
.dshm-player.dshm-player--nativefull:fullscreen,.dshm-player.dshm-player--nativefull:-webkit-full-screen{position:fixed;inset:0;width:100%;height:100%;z-index:var(--dshm-z-lightbox);background:#000}
.dshm-player--immersive{background:#000}
.dshm-player--immersive .dshm-playerArt-bg,.dshm-player--immersive .dshm-playerScrim{display:none}
.dshm-player--immersive .dshm-playerBody{position:absolute;inset:0;display:block;padding:0}
.dshm-player--immersive .dshm-playerStage{position:absolute;inset:0;width:100%;height:100%;justify-content:center;gap:0}
.dshm-player--immersive .dshm-mvStage{width:100%;height:100%;max-height:none;aspect-ratio:auto;border-radius:0;box-shadow:none;cursor:default}
.dshm-player--immersive .dshm-playerRight{display:none}
.dshm-player--immersive .dshm-playerTop{position:absolute;inset:0 0 auto;z-index:3;padding:12px 20px;color:#fff;background:linear-gradient(rgba(0,0,0,.68),transparent);transition:opacity .2s var(--dshm-ease)}
.dshm-player--immersive .dshm-playerControls{position:absolute;left:0;right:0;bottom:0;z-index:3;width:100%;padding:52px 40px 18px;gap:12px;background:linear-gradient(transparent,rgba(0,0,0,.88));transition:opacity .2s var(--dshm-ease)}
.dshm-player--immersive .dshm-playerMeta,.dshm-player--immersive .dshm-progress,.dshm-player--immersive .dshm-playerTransport{width:min(94%,1100px)}
.dshm-player--immersive .dshm-playerTitle{color:#fff}
.dshm-player--immersive .dshm-playerArtist{color:rgba(255,255,255,.72)}
.dshm-player--immersive .dshm-playerRound{color:#fff;border-color:rgba(255,255,255,.3);background:rgba(0,0,0,.35)}
.dshm-player--immersive .dshm-playerRound:hover:not(:disabled){color:#fff;background:rgba(255,255,255,.18)}
.dshm-player--immersive .dshm-playerTransportBtn{color:#fff}
.dshm-player--immersive .dshm-playerTransportBtn:hover:not(:disabled){background:rgba(255,255,255,.16)}
.dshm-player--immersive .dshm-playerTransportBtn--play{color:#111;background:#fff}
.dshm-player--immersive .dshm-playerTransportBtn--on{color:#fff;background:rgba(255,255,255,.18)}
.dshm-player--immersive .dshm-playerVolume{color:#fff}
.dshm-player--idle{cursor:none}
.dshm-player--idle .dshm-playerTop,.dshm-player--idle .dshm-playerControls{opacity:0;pointer-events:none}
@media (max-width:760px){.dshm-player--immersive .dshm-playerControls{padding:46px 16px 12px}.dshm-player--immersive .dshm-playerTop{padding:8px 12px}}
.dshm-mvStage{position:relative;width:100%;aspect-ratio:1;background:#000;border-radius:10px;overflow:hidden;box-shadow:0 26px 60px rgba(0,0,0,.45)}
.dshm-mvPrep{position:absolute;inset:0;z-index:2;flex-direction:column;justify-content:center;align-items:center;gap:10px;padding:0 18px;color:#fff;text-align:center;background:rgba(0,0,0,.62);display:flex}
.dshm-mvPrepText{font-size:13px;font-weight:500}
.dshm-mvPrepBar{width:min(70%,220px);height:4px;background:rgba(255,255,255,.25);border-radius:2px;overflow:hidden}
.dshm-mvPrepBar i{display:block;height:100%;background:#fff;border-radius:2px;transition:width .3s var(--dshm-ease)}
.dshm-mvPrepPct{font-size:11px;opacity:.75;font-variant-numeric:tabular-nums}
.dshm-mvPrepHint{color:var(--dsw-alias-label-caption);font-size:11px;line-height:1.5;max-width:300px;word-break:break-word}
.dshm-check{cursor:pointer;color:var(--dsw-alias-label-secondary);font-size:12px;align-items:center;gap:6px;flex:none;display:inline-flex}
.dshm-check input{accent-color:var(--dsw-alias-state-business-primary);cursor:pointer;width:13px;height:13px;margin:0}
.dshm-mvPrepRetry{cursor:pointer;color:#fff;border:1px solid rgba(255,255,255,.4);background:rgba(255,255,255,.14);border-radius:8px;padding:5px 14px;font:inherit;font-size:12px}
.dshm-mvPrepRetry:hover{background:rgba(255,255,255,.24)}
.dshm-mvTag{margin-right:6px;padding:0 5px;color:var(--dsw-alias-state-business-primary);background:color-mix(in srgb, var(--dsw-alias-state-business-primary) 14%, transparent);border-radius:4px;font-size:10px;font-weight:600;line-height:15px;vertical-align:1px;display:inline-block}
.dshm-nowText .dshm-mvTag{margin-right:5px;vertical-align:1px}

/* ── 全屏播放器（Apple Music 风格）：点底部封面弹出 ───────────────────── */
.dshm-player{position:absolute;inset:0;z-index:var(--dshm-z-player);color:var(--dsw-alias-label-primary);flex-direction:column;display:flex;overflow:hidden}
/* 背景＝封面放大 + 高斯模糊 + 一层主题色薄纱，和 Apple Music 的"取色背景"一致 */
.dshm-playerArt-bg{position:absolute;inset:-12%;background-position:center;background-size:cover;filter:blur(64px) saturate(1.7);opacity:.55;pointer-events:none}
.dshm-playerScrim{position:absolute;inset:0;background:color-mix(in srgb, var(--dsw-alias-bg-base) 78%, transparent);-webkit-backdrop-filter:saturate(180%) blur(48px);backdrop-filter:saturate(180%) blur(48px);pointer-events:none}
.dshm-playerTop{position:relative;flex:none;align-items:center;justify-content:space-between;gap:12px;padding:10px 18px;display:flex}
.dshm-playerBody{position:relative;flex:1;min-height:0;grid-template-columns:minmax(0,1fr) minmax(300px,400px);gap:36px;padding:0 40px 26px;display:grid}
.dshm-playerStage{--dshm-art:min(42vh,380px,100%);width:var(--dshm-art);min-width:0;min-height:0;flex-direction:column;justify-content:center;align-items:center;gap:16px;display:flex}
.dshm-playerArt{width:100%;aspect-ratio:1;object-fit:cover;background:var(--dsw-alias-bg-layer-2);border-radius:10px;box-shadow:0 26px 60px rgba(0,0,0,.45)}
.dshm-playerArtFallback{width:100%;aspect-ratio:1;background:var(--dsw-alias-bg-layer-2);border-radius:10px;box-shadow:0 26px 60px rgba(0,0,0,.45);color:var(--dsw-alias-label-caption);justify-content:center;align-items:center;display:flex}
.dshm-playerMeta{width:100%;min-width:0;align-items:center;gap:10px;display:flex}
.dshm-playerMetaText{min-width:0;flex:1}
.dshm-playerTitle{font-size:16px;font-weight:600;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-playerArtist{color:var(--dsw-alias-label-tertiary);font-size:12.5px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-playerRound{cursor:pointer;width:30px;height:30px;color:var(--dsw-alias-label-secondary);border:1px solid var(--dsw-alias-border-l2);background:color-mix(in srgb, var(--dsw-alias-fill-l1) 60%, transparent);border-radius:50%;flex:none;justify-content:center;align-items:center;padding:0;display:inline-flex}
.dshm-playerRound:hover:not(:disabled){color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-playerRound:disabled{cursor:not-allowed;opacity:.4}
.dshm-playerRound--on{color:var(--dsw-alias-state-business-primary);border-color:var(--dsw-alias-state-business-primary)}
/* 双类选择器：必须压过下面 .dshm-progress{align-items:center}（同特异性时靠后规则赢），
   否则时间行会被压成"内容宽"、space-between 失效，两个时间就挤到中间去了。 */
.dshm-progress.dshm-progress--stacked{flex-direction:column;gap:6px;align-items:stretch}
.dshm-progress--stacked .dshm-timeRow{width:100%}
.dshm-progress--stacked .dshm-progressTrack{width:100%;flex:none;height:18px}
.dshm-timeRow{justify-content:space-between;align-items:center;gap:8px;display:flex}
.dshm-progress--stacked .dshm-time{width:auto;text-align:left}
.dshm-progress--stacked .dshm-time--end{text-align:right}
.dshm-playerTransport{width:100%;grid-template-columns:1fr auto 1fr;align-items:center;display:grid}
.dshm-playerTransportCenter{gap:26px;justify-content:center;align-items:center;display:flex}
.dshm-playerTransportSide{min-width:0;display:flex}
.dshm-playerTransportSide--end{justify-content:flex-end}
.dshm-playerTransportBtn{cursor:pointer;width:34px;height:34px;color:var(--dsw-alias-label-primary);border:0;background:transparent;border-radius:50%;justify-content:center;align-items:center;padding:0;display:inline-flex}
.dshm-playerTransportBtn:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
.dshm-playerTransportBtn:disabled{cursor:not-allowed;opacity:.35}
.dshm-playerTransportBtn--play{width:44px;height:44px}
.dshm-playerTransportBtn--on{color:var(--dsw-alias-state-business-primary)}
.dshm-playerRight{min-width:0;min-height:0;flex-direction:column;gap:10px;display:flex}
.dshm-playerPills{gap:10px;flex:none;display:flex}
.dshm-pill{cursor:pointer;height:38px;color:var(--dsw-alias-label-secondary);border:1px solid var(--dsw-alias-border-l2);background:color-mix(in srgb, var(--dsw-alias-fill-l1) 55%, transparent);border-radius:10px;flex:1;justify-content:center;align-items:center;gap:6px;padding:0 10px;font:inherit;font-size:12px;display:inline-flex}
.dshm-pill:hover:not(:disabled){color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-pill:disabled{cursor:not-allowed;opacity:.45}
.dshm-playerQueueHead{flex:none;align-items:baseline;gap:8px;padding:2px 2px 4px;display:flex}
.dshm-playerQueueTitle{font-size:15px;font-weight:600}
.dshm-playerQueueCount{color:var(--dsw-alias-label-caption);font-size:11px}
.dshm-playerQueue{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable}
.dshm-queueRow{position:relative;cursor:default;width:100%;color:var(--dsw-alias-label-primary);text-align:left;border:0;background:transparent;border-radius:12px;align-items:center;gap:10px;padding:6px 8px;font:inherit;display:flex}
.dshm-queueRow:hover{background:var(--dsw-alias-interactive-bg-hover)}
.dshm-queueRow--current{background:var(--dsw-alias-interactive-bg-active)}
.dshm-queueRow--current .dshm-queueTitle{color:var(--dsw-alias-state-business-primary);font-weight:500}
.dshm-queueRow .dshm-rowCover,.dshm-queueRow .dshm-rowNote{width:40px;height:40px;border-radius:6px}
.dshm-queueText{min-width:0;flex:1;flex-direction:column;display:flex}
.dshm-queueTitle{font-size:13px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-queueArtist{color:var(--dsw-alias-label-tertiary);font-size:11.5px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-queueFav{flex:none;color:var(--dsw-alias-state-business-primary);display:inline-flex}
.dshm-queueMore{cursor:pointer;width:24px;height:24px;color:var(--dsw-alias-label-tertiary);border:0;background:transparent;border-radius:6px;flex:none;justify-content:center;align-items:center;padding:0;display:inline-flex}
.dshm-queueMore:hover{color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-queueMenu{position:absolute;z-index:var(--dshm-z-menu);top:calc(100% - 4px);right:8px;min-width:168px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l2);border-radius:10px;box-shadow:0 14px 34px rgba(0,0,0,.35);padding:4px;display:flex;flex-direction:column}
.dshm-queueMenuItem{cursor:pointer;color:var(--dsw-alias-label-primary);text-align:left;border:0;background:transparent;border-radius:7px;align-items:center;gap:8px;padding:7px 9px;font:inherit;font-size:12px;display:flex}
.dshm-queueMenuItem:hover{background:var(--dsw-alias-interactive-bg-hover)}
.dshm-queueMenuItem--danger{color:var(--dsw-alias-state-error-primary)}
.dshm-noteIcon{width:34px;height:34px;color:var(--dsw-alias-label-tertiary);background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l2);border-radius:6px;flex:none;justify-content:center;align-items:center;display:flex}
.dshm-cover{width:34px;height:34px;border:1px solid var(--dsw-alias-border-l2);border-radius:6px;flex:none;object-fit:cover;background:var(--dsw-alias-bg-layer-2)}
/* 跑马灯：只在真的放不下时滚动（JS 量宽度后加 --on），悬停暂停，尊重
   prefers-reduced-motion。位移一份文本 + 一个 gap，正好无缝衔接。 */
.dshm-marquee{min-width:0;overflow:hidden;white-space:nowrap}
.dshm-marqueeInner{display:inline-flex;align-items:center;gap:var(--dshm-marquee-gap,36px);white-space:nowrap}
.dshm-marqueeText{white-space:nowrap}
.dshm-marquee--on .dshm-marqueeInner{animation:dshm-marquee-scroll var(--dshm-marquee-duration,12s) linear infinite}
.dshm-marquee:hover .dshm-marqueeInner{animation-play-state:paused}
@keyframes dshm-marquee-scroll{from{transform:translateX(0)}to{transform:translateX(calc(-50% - var(--dshm-marquee-gap,36px) / 2))}}
@media (prefers-reduced-motion:reduce){.dshm-marquee--on .dshm-marqueeInner{animation:none}}
.dshm-nowText{min-width:0}
.dshm-nowTitle{color:var(--dsw-alias-label-primary);font-size:12px;font-weight:500;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-nowArtist{color:var(--dsw-alias-label-tertiary);font-size:11px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-center{min-width:0;flex-direction:column;align-items:center;gap:2px;display:flex}
.dshm-transport{align-items:center;gap:6px;display:flex}
.dshm-tbtn{cursor:pointer;width:30px;height:30px;color:var(--dsw-alias-label-secondary);border:0;background:transparent;border-radius:8px;justify-content:center;align-items:center;padding:0;display:inline-flex}
.dshm-tbtn:hover:not(:disabled){color:var(--dsw-alias-label-primary);background:var(--dsw-alias-interactive-bg-hover)}
.dshm-tbtn:disabled{cursor:not-allowed;opacity:.35}
.dshm-tbtn--play{width:36px;height:36px}
.dshm-progress{width:100%;align-items:center;gap:8px;display:flex}
/* 进度条命中区：指针事件在这里处理（滑杆本体 pointer-events:none），
   这样"点哪儿跳哪儿 / 拖多快都跟手"不依赖原生 range 的拇指命中。 */
.dshm-progressTrack{cursor:pointer;flex:1;min-width:0;align-items:center;display:flex;position:relative}
/* 波形：垫在滑杆下面（滑杆轨道透明），播放过的部分用 clip-path 亮起来。进度靠 CSS 变量
   --dshm-played 传入，所以拖动的 rAF 循环不必触发 React 重渲染。 */
.dshm-wave{position:absolute;inset:-6px 0;pointer-events:none;display:flex}
.dshm-wave__row{position:absolute;inset:0;display:flex;align-items:center;gap:1px}
.dshm-wave__bar{flex:1;min-width:0;border-radius:1px;background:var(--dsw-alias-border-l2)}
.dshm-wave__row--on{clip-path:inset(0 calc(100% - var(--dshm-played,0%)) 0 0)}
.dshm-wave__row--on .dshm-wave__bar{background:var(--dsw-alias-text-accent,currentColor);opacity:.85}
/* 波形垫底、滑杆在上：波形自己 pointer-events:none，这里把层序写成显式的（别依赖 DOM 顺序）。 */
.dshm-progressTrack--wave .dshm-slider{position:relative;z-index:1}
.dshm-progress .dshm-slider{width:100%}
.dshm-progressTrack:hover .dshm-slider::-webkit-slider-thumb,.dshm-progress--dragging .dshm-slider::-webkit-slider-thumb{transform:scale(1)}
.dshm-progressTrack:hover .dshm-slider::-moz-range-thumb,.dshm-progress--dragging .dshm-slider::-moz-range-thumb{transform:scale(1)}
.dshm-time{color:var(--dsw-alias-label-tertiary);flex:none;width:38px;font-size:10px;font-variant-numeric:tabular-nums;text-align:center;user-select:none}
.dshm-progress--stacked .dshm-time{font-size:11.5px;font-variant-numeric:tabular-nums}
/* macOS Music style slider: filled elapsed portion, thin track that thickens on hover, knob scales up */
.dshm-slider{-webkit-appearance:none;appearance:none;cursor:pointer;height:16px;background:linear-gradient(to right, var(--dsw-alias-label-primary) 0 var(--p, 0%), color-mix(in srgb, var(--dsw-alias-label-primary) 22%, transparent) var(--p, 0%) 100%) center/100% 4px no-repeat;border-radius:2px;flex:1;min-width:0;margin:0;outline:none;transition:background-size .12s var(--ds-ease-in-out)}
.dshm-slider:hover:not(:disabled){background-size:100% 5px}
/* 圆钮：macOS 原生样式 —— 始终是白色实心圆 + 极细描边 + 柔和投影，
   不跟随主题色；进度条上的钮悬停/拖拽才出现，音量条上的钮常显。 */
.dshm-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:20px;height:14px;border-radius:999px;background:#ffffff;box-shadow:0 .5px 2px rgba(0,0,0,.28),0 0 0 .5px rgba(0,0,0,.08);transform:scale(0);transition:transform .12s var(--ds-ease-in-out)}
.dshm-slider:hover:not(:disabled)::-webkit-slider-thumb,.dshm-slider:active::-webkit-slider-thumb{transform:scale(1)}
.dshm-volume::-webkit-slider-thumb,.dshm-volume:hover:not(:disabled)::-webkit-slider-thumb{transform:scale(1)}
.dshm-slider::-moz-range-thumb{width:20px;height:14px;background:#ffffff;border:0;border-radius:999px;box-shadow:0 .5px 2px rgba(0,0,0,.28),0 0 0 .5px rgba(0,0,0,.08);transform:scale(0);transition:transform .12s var(--ds-ease-in-out)}
.dshm-slider:hover:not(:disabled)::-moz-range-thumb,.dshm-slider:active::-moz-range-thumb{transform:scale(1)}
.dshm-volume::-moz-range-thumb{transform:scale(1)}
.dshm-slider:disabled{cursor:not-allowed;opacity:.45}
.dshm-right{min-width:0;justify-content:flex-end;align-items:center;gap:10px;display:flex}
.dshm-mode{cursor:pointer;height:26px;color:var(--dsw-alias-label-secondary);border:1px solid var(--dsw-alias-border-l2);background:transparent;border-radius:7px;flex:none;align-items:center;gap:5px;padding:0 9px;font:inherit;font-size:11px;display:inline-flex}
.dshm-mode:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
/* ReplayGain 按钮：与模式按钮同款，只在开启时高亮，未开启时保持安静 */
.dshm-rg{font-weight:600;letter-spacing:.02em;min-width:34px;justify-content:center}
.dshm-rg--on{color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-label-primary)}
.dshm-volume{width:88px;flex:none}
/* 全屏播放器顶部那条音量按 macOS 的长条比例（底部条不变，仍是 88px） */
.dshm-volume--wide{width:180px}
.dshm-playerVolume{align-items:center;gap:8px;display:flex}
/* 音量条的圆钮与进度条同款（macOS 原生白色圆钮），只是常显 */
/* 在线补全：行内封面列 / 匹配按钮 / 候选弹层 */
.dshm-table td.dshm-colCover,.dshm-table th.dshm-colCover{width:44px;text-align:center;padding:0 4px;text-overflow:clip}
/* ── 列表封面上的「正在播放」指示（Apple Music 的 .playing-bars）─────────────
   正在播放的行：封面上叠三根跳动条；悬停时跳动条淡出、换成播放/暂停图标
   （他们用 --playButtonOpacity + .playing-bars-hover 做同一件事）。 */
.dshm-coverWrap{position:relative;flex:none;align-items:center;justify-content:center;display:inline-flex}
.dshm-coverWrap::after{content:"";position:absolute;inset:0;z-index:1;background:rgba(0,0,0,.42);border-radius:5px;opacity:0;transition:opacity .18s var(--dshm-ease)}
.dshm-row:hover .dshm-coverWrap::after,.dshm-queueRow:hover .dshm-coverWrap::after{opacity:1}
.dshm-queueRow .dshm-coverWrap::after{border-radius:6px}
.dshm-coverBars{position:absolute;z-index:2;height:12px;align-items:flex-end;gap:2px;display:flex;opacity:1;transition:opacity .18s var(--dshm-ease)}
.dshm-coverBars i{width:2.5px;height:100%;background:#fff;border-radius:1px;transform-origin:bottom;animation:dshm-eq .9s ease-in-out infinite alternate}
.dshm-coverBars i:nth-child(1){height:60%;animation-delay:-.5s}
.dshm-coverBars i:nth-child(2){height:100%;animation-delay:-.25s}
.dshm-coverBars i:nth-child(3){height:75%;animation-delay:-.75s}
@keyframes dshm-eq{from{transform:scaleY(.28)}to{transform:scaleY(1)}}
.dshm-coverHover{position:absolute;z-index:2;color:#fff;opacity:0;transition:opacity .18s var(--dshm-ease);display:inline-flex}
.dshm-row:hover .dshm-coverBars,.dshm-queueRow:hover .dshm-coverBars{opacity:0}
.dshm-row:hover .dshm-coverHover,.dshm-queueRow:hover .dshm-coverHover{opacity:1}
/* macOS 的悬浮滚动条：平时隐形，滚动/悬停才浮出来（Apple 干脆 display:none） */
.dshm-tableWrap::-webkit-scrollbar,.dshm-playerQueue::-webkit-scrollbar{width:11px;height:11px}
.dshm-tableWrap::-webkit-scrollbar-track,.dshm-playerQueue::-webkit-scrollbar-track{background:transparent}
.dshm-tableWrap::-webkit-scrollbar-thumb,.dshm-playerQueue::-webkit-scrollbar-thumb{background:transparent;background-clip:padding-box;border:3px solid transparent;border-radius:6px}
.dshm-tableWrap:hover::-webkit-scrollbar-thumb,.dshm-playerQueue:hover::-webkit-scrollbar-thumb{background:color-mix(in srgb, var(--dsw-alias-label-primary) 30%, transparent);background-clip:padding-box;border:3px solid transparent}
/* 键盘焦点环：Apple 是 4px 主题色光晕（:focus-visible{box-shadow:0 0 0 4px rgba(keyColor,.6)}） */
.dshm-root button:focus-visible,.dshm-root input:focus-visible,.dshm-root [role="button"]:focus-visible{outline:none;box-shadow:0 0 0 3px color-mix(in srgb, var(--dsw-alias-state-business-primary) 55%, transparent)}
.dshm-rowCover{width:28px;height:28px;border:1px solid var(--dsw-alias-border-l2);border-radius:5px;object-fit:cover;background:var(--dsw-alias-bg-layer-2);vertical-align:middle}
.dshm-rowNote{width:28px;height:28px;color:var(--dsw-alias-label-caption);background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l2);border-radius:5px;justify-content:center;align-items:center;vertical-align:middle;display:inline-flex}
.dshm-table td.dshm-colActions,.dshm-table th.dshm-colActions{width:44px;text-align:center;padding:0;text-overflow:clip}
.dshm-complete{font-size:13px;line-height:1;padding:0 9px}
/* 与官方 Modal/ImageLightbox 同款遮罩模糊（--dsw-mask-blur）。 */
.dshm-modal{position:fixed;inset:0;z-index:var(--dshm-z-modal);background:rgba(0,0,0,.35);-webkit-backdrop-filter:var(--dsw-mask-blur,blur(2px));backdrop-filter:var(--dsw-mask-blur,blur(2px));justify-content:center;align-items:center;display:flex;padding:24px}
.dshm-importDialog{width:min(560px,100%)}
.dshm-importBody{display:flex;flex-direction:column;gap:9px;padding:12px 14px;overflow:auto}
.dshm-importLabel{color:var(--dsw-alias-label-secondary);font-size:11px;font-weight:600}
.dshm-importInput{border:1px solid var(--dsw-alias-border-l2);height:30px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2);border-radius:7px;padding:0 10px;font:inherit;font-size:12px;outline:none}
.dshm-importInput:focus{border-color:var(--dsw-alias-state-business-primary);background:var(--dsw-alias-bg-layer-1)}
.dshm-importInput:disabled{cursor:not-allowed;opacity:.55}
textarea.dshm-importInput{height:auto;min-height:60px;padding:8px 10px;resize:vertical;line-height:1.45;font-family:inherit}
.dshm-importJobs{max-height:260px;display:flex;flex-direction:column;overflow:auto}
.dshm-importJobHead{align-items:center;gap:8px;display:flex}
.dshm-importJobHead .dshm-importStatus{min-width:0;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dshm-importCancel{border:0;color:var(--dsw-alias-label-tertiary);background:transparent;border-radius:5px;flex:none;padding:2px 5px;font:inherit;font-size:11px;cursor:pointer}
.dshm-importCancel:hover:not(:disabled){color:var(--dsw-alias-state-error-primary);background:var(--dsw-alias-state-error-tertiary)}
.dshm-importCancel:disabled{cursor:not-allowed;opacity:.55}
.dshm-importHint{color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:1.45}
.dshm-importKinds{display:flex;gap:6px}
.dshm-importKind{border:1px solid var(--dsw-alias-border-l2);height:26px;color:var(--dsw-alias-label-secondary);background:var(--dsw-alias-fill-l1);border-radius:7px;padding:0 12px;font:inherit;font-size:12px;cursor:pointer}
.dshm-importKind--active{color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-state-business-primary);background:var(--dsw-alias-bg-layer-1)}
.dshm-importKind:disabled{cursor:not-allowed;opacity:.55}
.dshm-importNotice{border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-2);border-radius:7px;padding:8px 10px;color:var(--dsw-alias-label-tertiary);font-size:11px;line-height:1.5}
.dshm-importJob{border-top:1px solid var(--dsw-alias-border-l1);margin-top:2px;padding-top:9px;display:flex;flex-direction:column;gap:6px}
.dshm-importStatus{color:var(--dsw-alias-label-primary);font-size:12px;font-weight:600}
.dshm-importProgress{height:6px;background:var(--dsw-alias-fill-l2);border-radius:999px;overflow:hidden}
.dshm-importBar{height:100%;background:var(--dsw-alias-state-business-primary);border-radius:999px;transition:width .2s var(--ds-ease-in-out)}
.dshm-importMeta{color:var(--dsw-alias-label-secondary);font-size:12px}
.dshm-importDone{color:var(--dsw-alias-state-success-primary);font-size:12px}
.dshm-importError{color:var(--dsw-alias-state-error-primary);font-size:12px;line-height:1.45}
.dshm-importWarn{color:var(--dsw-alias-state-warning-primary);font-size:11px;line-height:1.45}
.dshm-importFootHint{color:var(--dsw-alias-label-caption);font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:45%}
.dshm-importBadge{background:var(--dsw-alias-state-business-primary);color:var(--dsw-alias-label-on-color,#fff);border-radius:999px;min-width:14px;height:14px;align-items:center;justify-content:center;padding:0 4px;font-size:9px;font-weight:600;display:inline-flex;line-height:1}
.dshm-importProbeMeta{color:var(--dsw-alias-label-secondary);font-size:12px}
.dshm-importQualityRow{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.dshm-importSelect{border:1px solid var(--dsw-alias-border-l2);height:28px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2);border-radius:7px;padding:0 8px;font:inherit;font-size:12px;outline:none;max-width:100%}
.dshm-importSelect:focus{border-color:var(--dsw-alias-state-business-primary)}
.dshm-importLogin{border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-layer-2);border-radius:7px;padding:8px 10px;display:flex;flex-direction:column;gap:6px}
.dshm-importLoginRow{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.dshm-importQrBox{display:flex;flex-direction:column;align-items:center;gap:4px;padding:8px 0}
.dshm-importQr{width:220px;height:220px;background:#fff;border-radius:8px;padding:6px}
.dshm-importQrStatus{color:var(--dsw-alias-label-primary);font-size:12px}
.dshm-importLinkBtn{border:0;background:transparent;color:var(--dsw-alias-state-business-primary);font:inherit;font-size:11px;cursor:pointer;padding:0}
.dshm-dialog{width:min(520px,100%);max-height:min(70vh,560px);background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l2);border-radius:12px;box-shadow:0 18px 48px rgba(0,0,0,.35);flex-direction:column;display:flex;overflow:hidden}
.dshm-dialogHead{border-bottom:1px solid var(--dsw-alias-border-l1);padding:12px 14px;font-size:13px;font-weight:600}
.dshm-matchRow{justify-content:stretch;align-items:center;gap:8px;margin-top:10px;display:flex}
.dshm-matchInput{border:1px solid var(--dsw-alias-border-l2);height:28px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-2);border-radius:7px;flex:1;min-width:0;padding:0 10px;font:inherit;font-size:12px;outline:none}
.dshm-matchInput:focus{border-color:var(--dsw-alias-state-business-primary);background:var(--dsw-alias-bg-layer-1)}
.dshm-matchInput::placeholder{color:var(--dsw-alias-label-caption)}
.dshm-dialogMsg{color:var(--dsw-alias-label-tertiary);padding:20px 14px;font-size:12px}
.dshm-cands{min-height:0;flex:1;overflow:auto;padding:6px}
.dshm-cand{cursor:pointer;width:100%;color:var(--dsw-alias-label-primary);text-align:left;border:0;background:transparent;border-radius:8px;align-items:center;gap:10px;padding:6px 8px;font:inherit;display:flex}
.dshm-cand:hover{background:var(--dsw-alias-interactive-bg-hover)}
.dshm-candCover{width:40px;height:40px;border:1px solid var(--dsw-alias-border-l2);border-radius:6px;background:var(--dsw-alias-bg-layer-2);object-fit:cover;flex:none}
.dshm-candText{min-width:0;flex-direction:column;display:flex;gap:2px}
.dshm-candTitle{font-size:12px;font-weight:500;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-candArtist{color:var(--dsw-alias-label-tertiary);font-size:11px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-candMeta{color:var(--dsw-alias-label-caption);font-size:10px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden}
.dshm-candBest{color:var(--dsw-alias-state-business-primary);margin-right:4px}
.dshm-dialogFoot{border-top:1px solid var(--dsw-alias-border-l1);justify-content:space-between;align-items:center;gap:8px;padding:8px 12px;display:flex}
.dshm-check{color:var(--dsw-alias-label-secondary);cursor:pointer;user-select:none;align-items:center;gap:6px;font-size:11px;display:inline-flex}
.dshm-check input{cursor:pointer;accent-color:var(--dsw-alias-state-business-primary);margin:0}
`;

    /**
     * 播放 / 暂停用 macOS 原生形状（实心三角 / 双圆角竖条）—— 这是用户点名要换的
     * 两枚；DSH 的 IconPlayOutline 是"圆圈里套三角"，和 Apple Music 的传输键观感
     * 不同。其余按钮继续遵守"有官方图标就用官方"。
     */
    const appleTransport = (kind, size) => {
      const paths = kind === "play"
        ? [h("path", { d: "M5.6 3.05c0-.95 1.05-1.52 1.83-.98l7.3 4.62c.72.46.72 1.5 0 1.96l-7.3 4.62c-.78.54-1.83-.03-1.83-.98z" })]
        : [h("rect", { x: 4.3, y: 2.8, width: 2.9, height: 10.4, rx: 1.15 }), h("rect", { x: 8.8, y: 2.8, width: 2.9, height: 10.4, rx: 1.15 })];
      return h("svg", { width: size, height: size, viewBox: "0 0 16 16", fill: "currentColor" }, paths);
    };
    const ICONS = {
      play: appleTransport("play", 19),
      pause: appleTransport("pause", 19),
      playBig: appleTransport("play", 27),
      pauseBig: appleTransport("pause", 27),
      prev: h("svg", { width: 15, height: 15, viewBox: "0 0 16 16", fill: "currentColor" }, h("path", { d: "M3 3.2v9.6c0 .4.3.7.7.7s.7-.3.7-.7V3.2c0-.4-.3-.7-.7-.7s-.7.3-.7.7z" }), h("path", { d: "M13.4 3.1v9.8c0 .8-.9 1.2-1.5.8l-6.9-4.9c-.6-.4-.6-1.2 0-1.6l6.9-4.9c.6-.4 1.5 0 1.5.8z" })),
      next: h("svg", { width: 15, height: 15, viewBox: "0 0 16 16", fill: "currentColor" }, h("path", { d: "M12.3 3.2v9.6c0 .4.3.7.7.7s.7-.3.7-.7V3.2c0-.4-.3-.7-.7-.7s-.7.3-.7.7z" }), h("path", { d: "M2.6 3.1v9.8c0 .8.9 1.2 1.5.8l6.9-4.9c.6-.4.6-1.2 0-1.6l-6.9-4.9c-.6-.4-1.5 0-1.5.8z" })),
      repeat: h("svg", { width: 14, height: 14, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round", strokeLinejoin: "round" }, h("path", { d: "M11 1.8 13 3.8l-2 2" }), h("path", { d: "M3.5 7.2V6.4a2.6 2.6 0 0 1 2.6-2.6H13" }), h("path", { d: "m5 14.2-2-2 2-2" }), h("path", { d: "M12.5 8.8v.8a2.6 2.6 0 0 1-2.6 2.6H3" })),
      repeatOne: h("svg", { width: 14, height: 14, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round", strokeLinejoin: "round" }, h("path", { d: "M11 1.8 13 3.8l-2 2" }), h("path", { d: "M3.5 7.2V6.4a2.6 2.6 0 0 1 2.6-2.6H13" }), h("path", { d: "m5 14.2-2-2 2-2" }), h("path", { d: "M12.5 8.8v.8a2.6 2.6 0 0 1-2.6 2.6H3" }), h("text", { x: 8, y: 10.6, fontSize: 6.5, fill: "currentColor", stroke: "none", textAnchor: "middle", fontWeight: 700 }, "1")),
      note: h("svg", { width: 16, height: 16, viewBox: "0 0 16 16", fill: "currentColor" }, h("path", { d: "M12.9 1.3 5.9 2.9c-.5.1-.9.6-.9 1.1v6.9c-.3-.1-.7-.2-1-.2-1.2 0-2.2.8-2.2 1.9s1 1.9 2.2 1.9 2.2-.8 2.2-1.9V5.4c0-.3.2-.6.5-.6l5.7-1.3c.3-.1.6.2.6.5v5.3c-.3-.1-.7-.2-1-.2-1.2 0-2.2.8-2.2 1.9s1 1.9 2.2 1.9 2.2-.8 2.2-1.9V2.2c0-.5-.4-1-1.3-.9z" })),
      // 喇叭：macOS 原生样式（SF Symbols 的 speaker.wave.2 形状——实心喇叭 + 两道弧）
      volume: h("svg", { width: 15, height: 15, viewBox: "0 0 16 16", fill: "none" }, h("path", { d: "M8.35 2.72c0-.66-.8-1-1.27-.53L4.6 4.68H2.9c-.61 0-1.1.49-1.1 1.1v4.44c0 .61.49 1.1 1.1 1.1h1.7l2.48 2.49c.47.47 1.27.14 1.27-.53z", fill: "currentColor" }), h("path", { d: "M10.5 5.75c.75.75.75 1.97 0 2.72", stroke: "currentColor", strokeWidth: 1.35, strokeLinecap: "round" }), h("path", { d: "M12.55 3.9c1.72 1.72 1.72 4.5 0 6.22", stroke: "currentColor", strokeWidth: 1.35, strokeLinecap: "round" })),
      volumeOff: h("svg", { width: 15, height: 15, viewBox: "0 0 16 16", fill: "none" }, h("path", { d: "M8.35 2.72c0-.66-.8-1-1.27-.53L4.6 4.68H2.9c-.61 0-1.1.49-1.1 1.1v4.44c0 .61.49 1.1 1.1 1.1h1.7l2.48 2.49c.47.47 1.27.14 1.27-.53z", fill: "currentColor" }), h("path", { d: "M10.5 6.1l3 3m0-3l-3 3", stroke: "currentColor", strokeWidth: 1.35, strokeLinecap: "round" })),
      folder: officialIcon(["IconFolderOpenRegular", "IconFolderOpenOutlineRegular", "IconFolderOpen16"], 14, h("svg", { width: 13, height: 13, viewBox: "0 0 16 16", fill: "currentColor" }, h("path", { d: "M1.8 3.4c0-.7.5-1.2 1.2-1.2h3c.4 0 .8.2 1 .5l.8 1.1c.1.2.3.3.5.3H13c.7 0 1.2.5 1.2 1.2v7.3c0 .7-.5 1.2-1.2 1.2H3c-.7 0-1.2-.5-1.2-1.2V3.4z" }))),
      refresh: officialIcon(["IconRefreshOutlineRegular", "IconRefreshOutlineMedium", "IconRefreshOutline16"], 14, h("svg", { width: 13, height: 13, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2.2, strokeLinecap: "round", strokeLinejoin: "round" }, h("path", { d: "M21 12a9 9 0 1 1-2.6-6.4" }), h("path", { d: "M21 3.5V10h-6.5" }))),
      edit: officialIcon(["IconEditOutlineRegular", "IconEditOutlineMedium", "IconEditOutline16"], 13, h("svg", { width: 13, height: 13, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round" }, h("path", { d: "M17 3.5a2.6 2.6 0 0 1 3.7 3.7L8.4 19.5 3 21l1.5-5.4L17 3.5z" }))),
      search: officialIcon(["IconSearchOutlineRegular", "IconSearchOutlineMedium", "IconSearchOutline16"], 14,
        h("svg", { width: 14, height: 14, viewBox: "0 0 16 16", fill: "currentColor" }, h("path", { d: "M11.9 6.65a5.27 5.27 0 1 1-10.54 0 5.27 5.27 0 0 1 10.54 0zm1.35 0a6.62 6.62 0 1 1-13.24 0 6.62 6.62 0 0 1 13.24 0z" }), h("path", { d: "M16 15.04l-.96.96-3.51-3.53.95-.96z" }))),
      // 链接导入：下载托盘 + 向下箭头（插件自绘，不依赖某个宿主版本的官方图标名）。
      importLink: h("svg", { width: 14, height: 14, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round", strokeLinejoin: "round" },
        h("path", { d: "M8 2.2v7.2" }), h("path", { d: "m4.9 6.5 3.1 3.1 3.1-3.1" }),
        h("path", { d: "M2.8 11.2v1.4c0 .7.6 1.2 1.2 1.2h8c.7 0 1.2-.5 1.2-1.2v-1.4" })),
      // 原先用「✦ / − / ×」文字充当的按钮，改用官方 ic_ds_* 图标。
      sparkle: officialIcon(["IconSparkleRegular", "IconSparkleMedium", "IconSparkle16"], 12, h("span", { className: "dshm-glyph" }, "✦")),
      trash: officialIcon(["IconTrashOutlineRegular", "IconTrashOutlineMedium", "IconTrashOutline16"], 13, h("span", { className: "dshm-glyph" }, "−")),
      close: officialIcon(["IconCloseOutlineRegular", "IconCloseOutlineMedium", "IconCloseOutline16"], 12, h("span", { className: "dshm-glyph" }, "×")),
      // 全屏播放器用到的官方图标（有官方的一律用官方）
      chevronDown: officialIcon(["IconChevronDownOutlineRegular", "IconChevronDownOutlineMedium"],
        18, h("svg", { width: 18, height: 18, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round", strokeLinejoin: "round" }, h("path", { d: "M3.6 6.2 8 10.4l4.4-4.2" }))),
      ellipsis: officialIcon(["IconEllipsisOutlineRegular", "IconEllipsisOutlineMedium"],
        16, h("span", { className: "dshm-glyph" }, "⋯")),
      star: h("svg", { width: 18, height: 18, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.3, strokeLinejoin: "round" }, h("path", { d: "M8 1.9l1.85 3.9 4.3.55-3.15 2.95.8 4.25L8 11.5l-3.8 2.05.8-4.25L1.85 6.35l4.3-.55z" })),
      starFill: h("svg", { width: 18, height: 18, viewBox: "0 0 16 16", fill: "currentColor" }, h("path", { d: "M8 1.9l1.85 3.9 4.3.55-3.15 2.95.8 4.25L8 11.5l-3.8 2.05.8-4.25L1.85 6.35l4.3-.55z" })),
      // 网页全屏 / 原生全屏（插件自绘；DSH 图标集没有这一组）
      theater: h("svg", { width: 17, height: 17, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.3 },
        h("rect", { x: 1.5, y: 3, width: 13, height: 10, rx: 1.6 }),
        h("path", { d: "M5 6.2h6v3.6H5z", fill: "currentColor", stroke: "none" })),
      theaterExit: h("svg", { width: 17, height: 17, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.3 },
        h("rect", { x: 1.5, y: 3, width: 13, height: 10, rx: 1.6 }),
        h("path", { d: "M3.8 5.8h8.4v4.4H3.8z" })),
      fullscreen: h("svg", { width: 17, height: 17, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round", strokeLinejoin: "round" },
        h("path", { d: "M6 2H2v4M10 2h4v4M14 10v4h-4M6 14H2v-4" })),
      fullscreenExit: h("svg", { width: 17, height: 17, viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round", strokeLinejoin: "round" },
        h("path", { d: "M2 6h4V2M14 6h-4V2M10 14v-4h4M6 14v-4H2" })),
    };

    /**
     * 官方悬停提示（与 DSH 官方完全同源，见 @deepseek-ai/dsh-client-ui-primitives
     * 的 Tooltip）：气泡样式、翻转/贴边算法、动画都由 shell 提供，插件不再自带。
     *  - withTip：把 Tooltip 直接套在目标元素上，元素的布局身份（flex:1 等）不变。
     *  - withTipWrapped：先包一层 inline-flex 的 span——disabled 的 <button> 在浏览器
     *    里根本不派发鼠标事件，只有外层容器能收到 hover。
     * 取不到官方 Tooltip 时降级成原生 title，功能不丢。
     */
    /**
     * portal: true 是必须的，不是可选优化 —— 官方 Tooltip 的气泡默认渲染在锚点同一个
     * 父节点里（同一个 React 子树），而气泡是 position:fixed。只要祖先里有
     * backdrop-filter / filter / transform，就会成为 fixed 后代的包含块，气泡于是被
     * .dshm-root 的 overflow:hidden 裁掉 —— 表现就是「鼠标悬停什么都不出来」。
     * 插件为了毛玻璃恰好给 header / 播放条 / 列头都加了 backdrop-filter，正好踩中。
     * portal 把气泡挂到 document.body（z-index 也升到 1100），彻底绕开裁剪。
     */
    const TIP_PORTAL = true;

    const withTip = (element, label, side = "top") => {
      if (typeof label !== "string" || label.length === 0) return element;
      if (Tooltip === null) return React.cloneElement(element, { title: label });
      return h(Tooltip, { label, side, portal: TIP_PORTAL }, element);
    };
    const withTipWrapped = (element, label, side = "top") => {
      if (typeof label !== "string" || label.length === 0) return element;
      if (Tooltip === null) {
        return h("span", { className: "dshm-tip" }, React.cloneElement(element, { title: label }));
      }
      return h(Tooltip, { label, side, portal: TIP_PORTAL }, h("span", { className: "dshm-tip" }, element));
    };

    /**
     * 搜索框：优先用官方 @deepseek-ai/dsh-client-ui-primitives 的 Input 组件
     * （wrap + 前置图标 + input 三件套，样式与 DSH 自己的搜索框完全一致），
     * 拿不到就退回原来的裸 input，保证老宿主不白屏。
     */
    function searchField(props) {
      if (DshInput !== null) {
        return h(DshInput, {
          className: "dshm-searchWrap",
          icon: ICONS.search,
          type: "search",
          "aria-label": props.placeholder,
          spellCheck: false,
          ...props,
        });
      }
      return h("input", { className: "dshm-search", type: "search", spellCheck: false, ...props });
    }

    /** 搜索防抖窗口：大库逐键全量过滤+排序会卡，输入框本身仍然即时回显。 */
    const SEARCH_DEBOUNCE_MS = 140;

    /** 收藏：DSH 没有这个能力，插件用 localStorage 记一份（dsh-music:fav）。 */
    const FAV_KEY = "dsh-music:fav";
    const SECTION_KEY = "dsh-music:section";
    const MEDIA_KEY = "dsh-music:media";
    const SECTIONS = ["library", "favorites", "recent"];
    const MEDIA_FILTERS = ["all", "audio", "video"];
    function loadSection(): LibrarySection {
      try {
        const value = localStorage.getItem(SECTION_KEY) ?? "";
        return SECTIONS.includes(value) ? value as LibrarySection : "library";
      } catch {
        return "library";
      }
    }
    function saveSection(section: LibrarySection) {
      try { localStorage.setItem(SECTION_KEY, section); } catch { /* 隐私模式 */ }
    }
    function loadMediaFilter(): MediaFilter {
      try {
        const value = localStorage.getItem(MEDIA_KEY) ?? "";
        return MEDIA_FILTERS.includes(value) ? value as MediaFilter : "all";
      } catch {
        return "all";
      }
    }
    function saveMediaFilter(media: MediaFilter) {
      try { localStorage.setItem(MEDIA_KEY, media); } catch { /* 隐私模式 */ }
    }
    const SIDEBAR_KEY = "dsh-music:sidebar";
    function loadSidebarOpen() {
      try { return localStorage.getItem(SIDEBAR_KEY) !== "0"; } catch { return true; }
    }
    function saveSidebarOpen(open) {
      try { localStorage.setItem(SIDEBAR_KEY, open ? "1" : "0"); } catch { /* 隐私模式 */ }
    }
    function loadFavorites(): Set<string> {
      try {
        const raw = JSON.parse(localStorage.getItem(FAV_KEY) ?? "[]");
        return new Set(Array.isArray(raw) ? raw.filter((value) => typeof value === "string") : []);
      } catch {
        return new Set();
      }
    }
    function saveFavorites(set) {
      try {
        localStorage.setItem(FAV_KEY, JSON.stringify([...set]));
      } catch {
        // 隐私模式等：收藏是尽力而为。
      }
    }

    /** Locale translator for module-scope code; bound in apply() after locale registers. */
    let translate = (key) => key;

    function formatAddedAt(value) {
      if (typeof value !== "number" || !Number.isFinite(value)) return "";
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return "";
      return date.getFullYear() + "-" + String(date.getMonth() + 1).padStart(2, "0") + "-" + String(date.getDate()).padStart(2, "0");
    }

    function formatTime(value) {
      if (typeof value !== "number" || !Number.isFinite(value) || value < 0) return "--:--";
      const total = Math.floor(value);
      const minutes = Math.floor(total / 60);
      const seconds = total % 60;
      return minutes + ":" + String(seconds).padStart(2, "0");
    }

    /**
     * 浏览器实际解码能力。宿主默认 hevc=false，不上报就会把本可直出的 HEVC 转码；
     * 这里只问 `<video>` 的 canPlayType（MSE 支持不等于直出支持），加载时 POST /caps。
     * 探测失败按 false，宁转勿黑屏。
     */
    function detectVideoCaps() {
      const video = document.createElement("video");
      const can = (type) => {
        try {
          return video.canPlayType(type) !== "";
        } catch {
          return false;
        }
      };
      return {
        hevc: can('video/mp4; codecs="hvc1.1.6.L93.B0"') || can('video/mp4; codecs="hev1.1.6.L93.B0"'),
        av1: can('video/mp4; codecs="av01.0.05M.08"') || can('video/webm; codecs="av01.0.05M.08"'),
      };
    }

    async function api(path: string, options?: RequestInit) {
      // 调用点写的是宿主端点名（/api/library…），基址本身已经带了 /api，
      // 这里把重复的 /api 段折叠掉，避免出现 /api/dsh-music/api/library。
      const suffix = path.replace(/^\/api/, "");
      let response = await fetch(endpointBase + suffix, options);
      // 回落（A1-02）。判据是**端点语义 + 正向识别**，不是裸状态码：
      //   ① 失败的那个端点必须是「不该 404」的那一类（否则一首没封面的歌就能
      //      把入口判成旧版）；
      //   ② 旧前缀必须真答出宿主数据对象才算认出来；
      //   ③ 只在**采纳成功**时置 entryResolved —— 探测失败下次仍可重试。
      const endpoint = suffix.replace(/^\/|\?.*$/g, '').split('/')[0];
      if (response.status === 404 && !entryResolved && endpointBase === API_BASE
        && ROUTE_MISSING_404_ENDPOINTS.has(endpoint)) {
        const legacy = await fetch(LEGACY_API_BASE + suffix, options);
        const legacyData = await legacy.clone().json().catch(() => null);
        if (legacy.ok && looksLikeHostPayload(legacyData)) {
          endpointBase = LEGACY_API_BASE;
          entryResolved = true;
          // 显式报告降级，不能静默发生（composition.zh.md:143）。
          if (typeof onDowngrade === "function") onDowngrade();
          response = legacy;
        }
      }
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(typeof data.error === "string" ? data.error : "HTTP " + response.status);
      return data;
    }

    /** Client playback prefs persisted across page reloads. */
    const PREFS_KEY = "dsh-music:prefs";
    /** Parsed-once cache: playback position is saved while audio plays, and a
     *  JSON.parse + stringify per save would land on the audio thread's path. */
    let prefsCache: PlaybackPrefs | null = null;
    function loadPrefs(): PlaybackPrefs {
      if (prefsCache !== null) return prefsCache;
      let next: PlaybackPrefs = {};
      try {
        const parsed = JSON.parse(localStorage.getItem(PREFS_KEY) ?? "{}");
        next = parsed && typeof parsed === "object" ? parsed : {};
      } catch {
        // Private mode / 损坏的 JSON：prefs 是尽力而为。
      }
      prefsCache = next;
      return next;
    }
    function savePrefs(patch: PlaybackPrefs) {
      const next = { ...loadPrefs(), ...patch };
      prefsCache = next;
      try {
        localStorage.setItem(PREFS_KEY, JSON.stringify(next));
      } catch {
        // Private mode etc.: prefs are best-effort.
      }
    }

    /**
     * 在线补全结果（iTunes 匹配的原名/歌手/专辑/封面）按曲目稳定 id 存
     * localStorage：不写回音频文件、不改标签，只覆盖列表与播放条的显示。
     */
    const META_KEY = "dsh-music:meta";
    function loadMeta(): Record<string, MetaEntry> {
      try {
        const parsed = JSON.parse(localStorage.getItem(META_KEY) ?? "{}");
        return parsed && typeof parsed === "object" && !Array.isArray(parsed) ? parsed : {};
      } catch {
        return {};
      }
    }
    function persistMeta(meta: Record<string, MetaEntry>) {
      try {
        localStorage.setItem(META_KEY, JSON.stringify(meta));
      } catch {
        // Private mode etc.: overrides are best-effort.
      }
    }

    /** 远端封面走宿主代理（限制白名单主机 + 缓存），避免页面 CSP 拦截第三方图片。 */
    const artUrl = (cover) => endpointBase + "/art?u=" + encodeURIComponent(cover);
    /** “匹配结果 == 现有标签”的归一化键：只比较字母/数字/汉字，忽略标点与空白。 */
    const sameKey = (value) => String(value ?? "").normalize("NFKC").toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "");
    /**
     * 与宿主 buildFileName 一致的“期望文件名”。批量判断“已正确”时必须连
     * 文件名一起比较：标签对但文件名不规范（01.xxx / 裸歌名）也要重命名。
     */
    const FILENAME_ILLEGAL = /[\\/:*?"<>|\u0000-\u001f]/g;
    const expectedFileName = (title, artist, name) => {
      const dot = name.lastIndexOf(".");
      const ext = dot > 0 ? name.slice(dot) : "";
      const stem = name.slice(0, dot > 0 ? dot : name.length);
      const wanted = [artist, title]
        .filter((value) => typeof value === "string" && value.trim().length > 0)
        .join(" - ") || stem;
      const cleaned = wanted
        .replace(FILENAME_ILLEGAL, "_")
        .replace(/\s+/g, " ")
        .replace(/^[.\s]+/, "")
        .trim()
        .slice(0, 120)
        .trim();
      return (cleaned.length > 0 ? cleaned : "track") + ext;
    };

    /**
     * 页级音频设备：常驻 `AudioContext` 与它那条固定采样率的输出流。
     *
     * 归属是**页面**，不是某一次 activation（`Symbol.for` 挂在 window 上）：插件热重载会
     * 重新求值整个 bundle，设备若跟着 activation 重建，每保存一次文件就得重协商一次输出
     * 设备格式（I-16 要消除的正是这个）。而设备若跟着上一代 player 一起复用，`disposed`
     * 闸门就永远关着 —— 那是「有时没声音、刷新才好」的成因。
     *
     * 设备只留**跨代不变**的那部分（ctx / 增益链 / 探测结果）；媒体元素与每元素电平节点
     * 仍然每代各建一份，见 createPlayer。
     */
    interface MusicAudioDevice {
      ctx: AudioContext | null;
      /** 用户音量增益：渐变的唯一目标（元素音量始终中性）。 */
      volume: GainNode | null;
      /** ReplayGain 增益，同时是每元素电平节点的汇入点。 */
      rg: GainNode | null;
      eqPreamp: GainNode | null;
      eqNodes: BiquadFilterNode[];
      /** 建图失败 / 环境没有 AudioContext → 本页面永久退回元素音量。 */
      disabled: boolean;
      /** 跨源媒体是否回显 ACAO（null = 还没探过）；探测结果页级有效。 */
      corsOk: boolean | null;
      /** ctx 状态变化时代为转发的**当前代**回调；null = 没有代在监听（已释放）。 */
      watcher: (() => void) | null;
      /** 已经 halt 过的实例。跨 bundle 重求值仍有效 —— 否则新一代会去接管一份终态实例。 */
      released: WeakSet<object>;
    }

    const AUDIO_DEVICE = Symbol.for("dsh-music-player.audio-device");

    function audioDevice(): MusicAudioDevice {
      const holder = window as unknown as { [key: symbol]: MusicAudioDevice | undefined };
      const existing = holder[AUDIO_DEVICE];
      if (existing !== undefined) return existing;
      const created: MusicAudioDevice = {
        ctx: null, volume: null, rg: null, eqPreamp: null, eqNodes: [],
        disabled: false, corsOk: null, watcher: null, released: new WeakSet(),
      };
      holder[AUDIO_DEVICE] = created;
      return created;
    }

    /**
     * Player singleton. The <audio> element lives at module scope (not inside the
     * view tree), so playback keeps running when the user switches to another tab
     * and the Music view unmounts.
     */
    /**
     * 系统「正在播放」集成：封面回退、位置状态、MediaSession 元数据。
     * 依赖用 getter 注入（`audio` 会在交叉淡化时交换，`state` 会被 set 替换）。
     */
    function createMediaSession(core) {
      /** 封面回退图（canvas 生成一次）跟工厂实例走。 */
      let fallbackArtwork;
    const mediaArtworkFallback = () => {
      if (fallbackArtwork !== undefined) return fallbackArtwork;
      try {
        const size = 256;
        const canvas = document.createElement("canvas");
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext("2d");
        if (ctx === null) return (fallbackArtwork = null);
        const radius = size * 0.225;
        const gradient = ctx.createLinearGradient(0, 0, size, size);
        gradient.addColorStop(0, "#fb5c74");
        gradient.addColorStop(0.55, "#f7415f");
        gradient.addColorStop(1, "#e0304a");
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(radius, 0);
        ctx.lineTo(size - radius, 0);
        ctx.arcTo(size, 0, size, radius, radius);
        ctx.lineTo(size, size - radius);
        ctx.arcTo(size, size, size - radius, size, radius);
        ctx.lineTo(radius, size);
        ctx.arcTo(0, size, 0, size - radius, radius);
        ctx.lineTo(0, radius);
        ctx.arcTo(0, 0, radius, 0, radius);
        ctx.closePath();
        ctx.fill();
        // Reuse the sidebar note glyph (16x16 viewBox) as the white note.
        const note = new Path2D("M12.9 1.3 5.9 2.9c-.5.1-.9.6-.9 1.1v6.9c-.3-.1-.7-.2-1-.2-1.2 0-2.2.8-2.2 1.9s1 1.9 2.2 1.9 2.2-.8 2.2-1.9V5.4c0-.3.2-.6.5-.6l5.7-1.3c.3-.1.6.2.6.5v5.3c-.3-.1-.7-.2-1-.2-1.2 0-2.2.8-2.2 1.9s1 1.9 2.2 1.9 2.2-.8 2.2-1.9V2.2c0-.5-.4-1-1.3-.9z");
        const scale = (size / 16) * 0.62;
        ctx.save();
        ctx.translate(size / 2 - 8 * scale, size / 2 - 8 * scale);
        ctx.scale(scale, scale);
        ctx.fillStyle = "#ffffff";
        ctx.fill(note);
        ctx.restore();
        fallbackArtwork = canvas.toDataURL("image/png");
      } catch {
        // No canvas (or Path2D): fall back to the cover URL as before.
        fallbackArtwork = null;
      }
      return fallbackArtwork;
    };

    /** id → true | false (has embedded cover); absent = not probed yet. */
    const coverKnown = new Map();
    const probeCover = (track) => {
      if (coverKnown.has(track.id)) return;
      coverKnown.set(track.id, null); // in-flight
      const image = new Image();
      image.onload = () => {
        coverKnown.set(track.id, true);
        if (core.state.current >= 0 && core.state.tracks[core.state.current]?.id === track.id) updateMediaSession();
      };
      image.onerror = () => {
        coverKnown.set(track.id, false);
        if (core.state.current >= 0 && core.state.tracks[core.state.current]?.id === track.id) updateMediaSession();
      };
      image.src = core.coverUrl(track.id);
    };

    /**
     * macOS 的「正在播放」（控制中心 / 锁屏 / 触控栏）由系统 MediaRemote 抓封面，
     * 它只接受能真正解析到的绝对 URL；在 dsh-app:// 自定义协议下相对路径容易
     * 被判成无效资源，于是封面一直是空白。统一转绝对地址。
     */
    const absoluteUrl = (value) => {
      try {
        return new URL(value, window.location.href).href;
      } catch {
        return value;
      }
    };

    /**
     * 系统媒体卡片（MediaSession artwork）用的封面地址。
     *
     * 必须是绝对 http(s) / data / blob —— Chromium 会直接拒收其它 scheme
     * （"MediaImage src can only be of http/https/data/blob scheme"），
     * Desktop 的 dsh-app:// 就是被拒的那一类，表现是「有歌名没封面」。
     * Desktop 用外壳回环 origin + 免会话 cookie 的旧前缀；Web 用页面同源绝对地址。
     */
    const systemMediaUrl = (path, query) => {
      // Web（DESKTOP=false）保持同源地址不变——那条路本来就正常。
      if (DESKTOP && typeof core.systemArtBase === "string" && core.systemArtBase.length > 0) {
        return core.systemArtBase + "&" + query;
      }
      return absoluteUrl(core.endpointBase + path + "?" + query);
    };

    /**
     * 把播放进度同步给系统 Now Playing 的进度条（macOS 控制中心可以直接拖动）。
     * setPositionState 的参数校验很严：duration 必须是有限的正值、position 不得
     * 超过 duration，否则整段调用抛异常；所以先夹紧再调。
     */
    const updatePositionState = () => {
      if (!("mediaSession" in navigator)) return;
      if (typeof navigator.mediaSession.setPositionState !== "function") return;
      if (core.state.current < 0) return;
      try {
        const live = Number.isFinite(core.audio.duration) && core.audio.duration > 0 ? core.audio.duration : core.state.duration;
        if (!Number.isFinite(live) || live <= 0) return;
        const position = Math.min(Math.max(core.audio.currentTime, 0), live);
        navigator.mediaSession.setPositionState({
          duration: live,
          playbackRate: Number.isFinite(core.audio.playbackRate) && core.audio.playbackRate > 0 ? core.audio.playbackRate : 1,
          position,
        });
      } catch {
        // 旧引擎 / 越界参数：进度只是装饰，绝不因此打断播放。
      }
    };

    /**
     * Desktop 通知栏：换曲时给一条原生通知（Electron 把它转成 macOS/Windows
     * 系统通知）。策略上只在窗口失焦时发，否则会抢焦点、刷屏。
     * 官方 desktop app 文档只注入 window.dshDesktop 标记（不带 IPC 能力），
     * 所以这里用标准 Web Notification；icon 在支持的平台上直接显示专辑封面。
     */
    /**
     * 只在实际开始播放时提示：页面加载时把上次曲目 cue 成暂停态、或用户手动暂停，
     * 都不该弹通知。'play' 事件里 state.playing 已经为 true，换曲/自动下一首也会
     * 走到同一处，所以一个判据覆盖全部路径。
     */
    const NOTIFY_ALWAYS = true;
    let lastNoticeId = null;
    const notifyTrack = (track, view, artwork, playing) => {
      if (!DESKTOP || track === undefined) return;
      if (lastNoticeId === track.id) return;
      if (playing !== true) return;
      // 焦点策略：默认每次换曲都提示（静音横幅），窗口失焦时当然也提示。
      // 想安静一点就把 NOTIFY_ALWAYS 改成 false，只在窗口失焦时提示。
      if (!NOTIFY_ALWAYS && document.visibilityState === "visible" && document.hasFocus()) return;
      lastNoticeId = track.id;
      if (typeof Notification !== "function") return;
      try {
        if (Notification.permission === "denied") return;
        // Electron 里默认就是 granted；'default' 时补一次授权请求（首次会走系统弹窗）。
        if (Notification.permission === "default" && typeof Notification.requestPermission === "function") {
          Notification.requestPermission().catch(() => undefined);
        }
        const body = [view?.artist, view?.album].filter((value) => typeof value === "string" && value.length > 0).join(" · ");
        const notification = new Notification(view?.title ?? track.title, {
          body,
          icon: typeof artwork === "string" ? artwork : undefined,
          silent: true, // 音乐本身在响，不该再叠一层提示音
          tag: "dsh-music-now-playing",
        });
        notification.onclick = () => {
          try {
            window.focus();
          } catch {
            // 无窗口句柄：忽略。
          }
          notification.close();
        };
      } catch {
        // 通知是增强项：任何平台差异都不影响播放。
      }
    };

    /** System media keys / OS now-playing integration (macOS Control Center…). */
    const updateMediaSession = () => {
      if (!("mediaSession" in navigator)) return;
      try {
        const raw = core.state.current >= 0 ? core.state.tracks[core.state.current] : undefined;
        if (raw !== undefined) probeCover(raw);
        const track = core.effective(raw);
        // 补全的远端封面优先；没有补全才回退内嵌封面 / Apple Music 图标。
        const meta = raw === undefined ? undefined : core.state.meta[raw.id];
        /**
         * `track === undefined` 与 `raw === undefined` 等价（effective 对
         * undefined 原样返回 undefined），但类型系统看不见这层等价。下面用
         * 一个收窄过的 id 供 artwork 分支使用 —— 那两个分支里 track 必然存在，
         * 所以 raw 也必然存在，运行结果与 `raw.id` 完全一致。
         */
        const rawId = raw === undefined ? "" : raw.id;
        const metaCover = meta !== undefined && typeof meta.cover === "string" && meta.cover.length > 0
          ? systemMediaUrl("/art", "u=" + encodeURIComponent(meta.cover))
          : null;
        // While a cover is still being probed, keep the cover URL (tracks
        // usually have one); swap in the Apple Music icon once a 404 proves
        // there is none, so the widget never shows a blank square.
        const fallback = track === undefined ? null : mediaArtworkFallback();
        // 真实封面不写 sizes：MediaRemote 会按需缩放，写错尺寸反而会被跳过；
        // canvas 兜底图尺寸是我们自己定的，才标注。
        const artwork = track === undefined
          ? []
          : metaCover !== null
            ? [{ src: absoluteUrl(metaCover) }]
            : coverKnown.get(rawId) === false && fallback !== null
              // canvas 兜底图本身就是 data: URL，Chromium 明确允许。
              ? [{ src: fallback, sizes: "256x256", type: "image/png" }]
              : [{ src: systemMediaUrl("/cover", "p=" + encodeURIComponent(rawId) + "&v=" + (core.state.scannedAt ?? 0)) }];
        navigator.mediaSession.metadata = track === undefined ? null : new MediaMetadata({
          title: track.title,
          artist: track.artist ?? "",
          album: typeof track.album === "string" && track.album.length > 0
            ? track.album
            : (typeof core.state.dir === "string" ? core.state.dir.split(/[\\/]/).pop() : ""),
          artwork,
        });
        navigator.mediaSession.playbackState = core.state.current < 0 ? "none" : core.state.playing ? "playing" : "paused";
        if (track === undefined && typeof navigator.mediaSession.setPositionState === "function") {
          // 没有当前曲目时必须清掉上一首的进度，否则系统控件停在旧位置。
          try {
            navigator.mediaSession.setPositionState();
          } catch {
            // 部分引擎不接受空参数：忽略。
          }
        } else {
          updatePositionState();
        }
        notifyTrack(raw, track, artwork.length > 0 ? artwork[0].src : undefined, core.state.playing);
      } catch {
        // Older engines: metadata is cosmetic, never break playback over it.
      }
    };
      return { mediaArtworkFallback, coverKnown, probeCover, updatePositionState, updateMediaSession };
    }

    function createPlayerApi(core) {
      const api0 = {
        getState: () => core.state,
        setView: (view) => {
          if (view === "favorites") {
            core.set({ section: "favorites", mediaFilter: "all" });
            saveSection("favorites"); saveMediaFilter("all");
          } else if (view === "recent") {
            // 最近添加默认按文件时间倒序；用户之后仍可点表头改排序。
            core.set({ section: "recent", mediaFilter: "all", sortKey: "added", sortDir: "desc" });
            saveSection("recent"); saveMediaFilter("all");
            savePrefs({ sortKey: "added", sortDir: "desc" });
          } else {
            const media = view === "audio" ? "audio" : view === "video" ? "video" : "all";
            core.set({ section: "library", mediaFilter: media });
            saveSection("library"); saveMediaFilter(media);
          }
        },
        setMediaFilter: (media) => {
          if (media !== "all" && media !== "audio" && media !== "video") return;
          if (core.state.mediaFilter === media) return;
          core.set({ mediaFilter: media });
          saveMediaFilter(media);
        },
        toggleSidebar: () => {
          const open = !core.state.sidebarOpen;
          core.set({ sidebarOpen: open });
          saveSidebarOpen(open);
        },
        toggleFavorite: (id) => {
          if (typeof id !== "string" || id.length === 0) return;
          const next = new Set(core.state.favorites);
          if (next.has(id)) next.delete(id); else next.add(id);
          core.set({ favorites: next });
          saveFavorites(next);
        },
        subscribe: (listener) => {
          core.listeners.add(listener);
          return () => core.listeners.delete(listener);
        },
        load: core.load,
        refresh: async () => {
          core.set({ loading: true, error: null });
          try {
            core.applyLibrary(await api("/api/refresh", { method: "POST" }));
          } catch (error) {
            core.set({ error: error instanceof Error ? error.message : String(error) });
          } finally {
            core.set({ loading: false });
          }
        },
        pick: async () => {
          core.set({ picking: true, error: null });
          try {
            const payload = await api("/api/pick", { method: "POST" });
            if (payload.cancelled !== true) {
              core.stopAudio();
              core.applyLibrary(payload);
              core.set({ current: -1, playing: false, time: 0, duration: 0, query: "" });
            }
          } catch (error) {
            core.set({ error: error instanceof Error ? error.message : String(error) });
          } finally {
            core.set({ picking: false });
          }
        },
        setDir: async (dir) => {
          if (typeof dir !== "string" || dir.trim().length === 0) return;
          core.set({ loading: true, error: null });
          try {
            const payload = await api("/api/dir", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ dir: dir.trim() }),
            });
            core.stopAudio();
            core.applyLibrary(payload);
            core.set({ current: -1, playing: false, time: 0, duration: 0, query: "" });
          } catch (error) {
            core.set({ error: error instanceof Error ? error.message : String(error) });
            throw error;
          } finally {
            core.set({ loading: false });
          }
        },
        play: core.playIndex,
        /** 删除曲目（含本地文件）：先在应用内弹确认条，用户同意才删。 */
        remove: (index) => {
          if (core.state.tracks[index] === undefined) return;
          core.set({ pendingDelete: index });
        },
        cancelRemove: () => core.set({ pendingDelete: -1 }),
        confirmRemove: async () => {
          const index = core.state.pendingDelete;
          const track = core.state.tracks[index];
          if (track === undefined) {
            core.set({ pendingDelete: -1 });
            return;
          }
          core.set({ error: null, pendingDelete: -1 });
          try {
            const payload = await api("/api/delete", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ id: track.id }),
            });
            // 记住的「最后播放」若指向被删曲目，一并清掉
            const last = loadPrefs().last;
            if (last !== undefined && last.id === track.id) savePrefs({ last: undefined });
            if (core.state.favorites.has(track.id)) {
              const nextFavorites = new Set(core.state.favorites);
              nextFavorites.delete(track.id);
              core.set({ favorites: nextFavorites });
              saveFavorites(nextFavorites);
            }
            core.applyLibrary(payload);
          } catch (error) {
            core.set({ error: error instanceof Error ? error.message : String(error) });
          }
        },
        toggle: () => {
          if (core.state.current < 0) {
            const rows = core.visibleRows();
            if (rows.length > 0) core.playIndex(rows[0].index);
            return;
          }
          if (core.audio.paused) {
            // cued / 暂停中的元素：设备可能已被 suspend（上一代 halt、系统挂起发生在暂停期间）。
            // 这条路径**不经过** attachSource，所以必须自己把输出流叫醒 —— 不叫醒就是
            // 「界面在放、耳机没声」，而且 onstatechange 不会触发（状态没变）。
            core.resumeGraph();
            // 从当前瞬时音量（cue 之后是 0）淡入到用户音量。
            const promise = core.audio.play();
            if (promise === undefined) {
              core.applyVolume(core.targetVolume());
              return;
            }
            promise.then(() => {
              if (!core.disposed) void core.rampVolume(core.targetVolume(), core.FADE_PAUSE_MS);
            }).catch((error) => {
              // 同 attachSource：AbortError 是被打断，不是格式不支持。
              if (error?.name === "NotAllowedError" || error?.name === "AbortError") return;
              core.set({ playing: false, error: translate("error.unsupported") });
            });
          } else {
            // 暂停也要淡出：直接 pause() 是满幅瞬间归零，同样是一声「啪」。
            // 被后续动作取消时（rapid toggle）`ok` 为 false，就不要再暂停了。
            // 过渡窗口内先结算交接：否则 pause 打在淡出中的旧元素上，新元素继续出声。
            core.pauseEpoch += 1;
            core.commitPendingCrossfade();
            void (async () => {
              const ok = await core.rampVolume(0, core.FADE_PAUSE_MS);
              if (ok && !core.disposed) core.audio.pause();
            })();
          }
        },
        /**
         * 打开全屏播放器。若正处在 closing（用户刚点了收起就再点封面），
         * 先撤销那个还在飞的关闭定时器，否则 200ms 后会被它强制关掉。
         *
         * ⚠️ 这里**不能**加 `disposed` 守卫：player 是 window 级单例，插件热重载后的
         * 下一次 activation 复用它，而 `disposed` 置位后永不复位 —— 加了守卫会让
         * 重载之后的全屏播放器**再也打不开**（比死锁更坏）。teardown 的清理语义
         * 由 halt() 自己完成（停播、清句柄、复位状态），不靠拦 UI 操作。
         */
        openPlayer: () => {
          if (core.playerCloseTimer !== null) {
            clearTimeout(core.playerCloseTimer);
            core.playerCloseTimer = null;
          }
          core.set({ playerPhase: "open" });
        },
        /** 收起全屏播放器：closing 播完退出动画再置 closed（定时器归 player）。 */
        closePlayer: () => {
          if (core.state.playerPhase !== "open" || core.playerCloseTimer !== null) return;
          core.set({ playerPhase: "closing" });
          core.playerCloseTimer = setTimeout(() => {
            core.playerCloseTimer = null;
            // ⚠️ 这里**禁止**用 `disposed` 早退（第 16 轮回归）：halt() 已经把句柄
            // 清掉了，所以回调能跑到这里，唯一原因就是「teardown 之后又被显式打开过」
            // —— 而 player 是 window 级单例、下一次 activation 继续用它（A3-03），
            // `disposed` 一旦置位**永不复位**；早退会把 phase 永久钉死在 `closing`
            // （覆盖层关不掉、`closePlayer` 又拒绝从 closing 出发 ⇒ 死锁）。
            // 只认「还在 closing」这一步：openPlayer 撤销定时器后这里自然不触发。
            if (core.state.playerPhase !== "closing") return;
            core.set({ playerPhase: "closed" });
          }, 200);
        },
        toggleMvBig: () => core.set({ mvBig: !core.state.mvBig }),
        setZoomOpen: (open) => core.set({ zoomOpen: open === true }),
        /**
         * activation 租约：**取号**。设备与 player 实例都是页级的，而「哪一代还有权操作
         * 它」必须显式记账 —— 热重载的旧 disposer 可能在新 bundle 求值之后才跑到（顺序
         * 不定），只按实例调 halt() 会把新一代正在用的实例一起停掉。
         */
        acquire: () => (core.activationGen += 1),
        /** 当前租约号：activation 的 disposer 据此判断自己是否还是当前一代。 */
        lease: () => core.activationGen,
        /** 插件停用/卸载时停止播放并断开流（lifecycle 清理语义）。 */
        halt: () => {
          // 先立闸门：清句柄只能清掉「当前」那个定时器，清不掉在飞回调的再武装
          // （见 schedulePoll 的注释）。disposed 置位后 schedulePoll 永不排期。
          core.disposed = true;
          window.removeEventListener("pagehide", core.onPageHide);
          if (core.pollTimer !== null) {
            clearTimeout(core.pollTimer);
            core.pollTimer = null;
          }
          // 测量轮询同理：清句柄 + 复位状态位（否则守卫 `!state.rgMeasuring` 永不成立）。
          if (core.rgPollTimer !== null) {
            clearTimeout(core.rgPollTimer);
            core.rgPollTimer = null;
          }
          // 同一个道理：清句柄 + 阻止再武装。scheduleUnseekableHeal 在 disposed 后
          // 直接返回，不会重新排期（见 §2.10「清 timer 与阻止再武装是两件事」）。
          if (core.unseekableTimer !== null) {
            clearTimeout(core.unseekableTimer);
            core.unseekableTimer = null;
          }
          // 音量渐变也是定时器：不清掉它会在 teardown 之后继续写音量。
          // cancelFade 会同时把在飞的那个 promise 结算掉（不会挂住 await 它的调用方）。
          core.cancelFade();
          // 画面旁路（WASM 解码循环 / canvas）也是本代资源：停掉它，别在卸载后继续解码。
          core.stopWasmVideo();
          // 常驻音频图刻意不销毁（它的存在意义就是让设备流别重建），但 teardown 必须释放
          // 设备流：suspend 而不是 close —— 设备是**页级**的，下一代 activation 还要接管它，
          // close 之后就再也接不回来（ctx.close() 不可逆）。
          if (core.audioCtx !== null && core.audioCtx.state === "running") void core.audioCtx.suspend();
          // 本代的监听回调必须撤销：设备跨代存活，留着它等于把上一代的 handler 交给下一代
          // （客户端 activation 归属：上一代不得把 handler 交给下一代）。
          if (core.device.watcher === core.watchSuspended) core.device.watcher = null;
          // 交叉淡化模式下有两个元素：只用 `stopAudio()` 停当前那个会留下一个还在出声的。
          if (core.idleEl !== null) {
            try { core.idleEl.pause(); } catch { /* 假元素 */ }
          }
          // 释放本代接进设备的节点与自建 DOM：停用后 body 上不该留插件自建的 `<video>`/
          // 停靠位。设备本身的节点与 ctx 不动（它们归属页面）。
          core.releaseElement(core.activeSource);
          core.releaseElement(core.idleSource);
          core.releaseElement(core.activeLevelNode);
          core.releaseElement(core.idleLevelNode);
          core.activeSource = null;
          core.idleSource = null;
          core.activeLevelNode = null;
          core.idleLevelNode = null;
          core.mediaPark?.remove();
          core.mediaPark = null;
          // 收起动画的定时器同理：清句柄 + 复位 phase，下一代会话/下一次挂载
          // 不会继承「全屏播放器还开着」的旧状态。
          if (core.playerCloseTimer !== null) {
            clearTimeout(core.playerCloseTimer);
            core.playerCloseTimer = null;
          }
          // 作废在途的 match/apply，并停掉批量循环：否则卸载后它还会继续
          // 逐首打接口、写文件（实测每 600ms 一次，停不下来的后台任务）。
          core.matchSeq += 1;
          core.stopAudio();
          // 把 window 上的引用摘掉（只摘自己那一份）：下一次 activation 于是**新建**一份
          // player/媒体元素，而不是接管这一份已经立了闸门的旧状态。
          const holder = window as unknown as { __dshMusicPlayer?: MusicPlayerApi };
          if (holder.__dshMusicPlayer === api0) delete holder.__dshMusicPlayer;
          core.device.released.add(api0);
          // Reset current/error too: the deferred auto-skip and resume timers
          // test those fields, and must not restart audio after teardown.
          // `scanning` 也必须显式复位：它是轮询守卫读的字段，留着 true 会让
          // 「阻止再武装」失守（A3-01）。
          core.set({
            playing: false,
            scanning: false,
            pendingDelete: -1,
            current: -1,
            error: null,
            completing: false,
            buffering: false,
            pendingComplete: false,
            match: null,
            playerPhase: "closed",
            mvBig: false,
            zoomOpen: false,
          });
          if ("mediaSession" in navigator) {
            try {
              navigator.mediaSession.metadata = null;
              navigator.mediaSession.playbackState = "none";
            } catch {
              // MediaSession is cosmetic; teardown must not fail on it.
            }
          }
        },
        next: core.next,
        prev: core.prev,
        seek: (value) => {
          if (core.state.current < 0 || !Number.isFinite(value)) return;
          // 过渡窗口内 `audio` 还是淡出中的旧元素：先结算交接，seek 才会落在真正在响的那个上。
          core.commitPendingCrossfade();
          core.resumeAttempts = 0;
          core.skipAttempts = 0;
          core.lastFailureAt = 0;
          core.logSeek(value);
          // 拖动进度同样是波形上的硬跳变 —— fooyin 对 seek 也做 120ms 淡入淡出
          // （fadingdefs.h::CrossfadingValues::seek）。
          // **只在常驻音频图接管增益时**才这么做：图未启用时保持「立即 seek」，因为用元素
          // 音量做延迟会让拖动明显发粘，而且没有采样级保证（也会改掉既有测试依赖的同步语义）。
          if (core.gainNode === null) {
            core.set({ time: core.seekAudio(value) });
            return;
          }
          void (async () => {
            const ok = await core.rampVolume(0, core.FADE_SEEK_MS);
            if (!ok || core.disposed) return;   // 被更新的拖动接管：这一次不 seek（最后一次赢）
            core.set({ time: core.seekAudio(value) });
            if (!core.disposed) void core.rampVolume(core.targetVolume(), core.FADE_SEEK_MS);
          })();
        },
        /** 预热 /session（媒体直连基址）；页面挂载时调一次即可。 */
        warmSession: () => { void loadSystemArtBase(); },
        /** MV 画面：React 侧把这个媒体元素搬进全屏播放器的舞台（移动父节点不会中断播放）。 */
        media: () => core.audio,
        /** body 上的停靠位：视图卸载时把媒体元素搬回这里，避免被移出文档而暂停。 */
        mediaPark: () => core.mediaPark,
        /**
         * MV 失败后手动重试（重置升级标记 → 进入 preparing → 重走转码并挂源）。
         *
         * ⚠️ 这三步**必须**留在这里，不能写在 MusicView 的 onClick 里：
         * `mvEscalated` 与 `set` 都是 createPlayer() 的局部量，而 MusicView 在它外面，
         * 从视图里引用会在**运行时抛 ReferenceError**，而且抛在 prepareVideo 之前 ——
         * 表现就是「转码失败后点『重试』什么都没发生，只有控制台报错」。
         * 这个缺陷在 TS 迁移前就存在（032e333 及更早），是第 12 轮类型检查顺手抓出来的。
         */
        retryVideo: (track) => {
          core.mvEscalated.delete(track.id);
          core.set({ mv: { id: track.id, state: "preparing", progress: 0, mode: "transcode", error: null } });
          // retry=true：宿主把失败的转码任务缓存 10 分钟，不带这个标记这一下只会立刻
          // 拿回同一条失败记录（按钮形同空操作，只能刷新页面）。
          void core.prepareVideo(track, "transcode", true).then((url) => {
            if (url === null || core.playingId !== track.id) return;
            core.attachSource(url);
          });
        },
        setVolume: (value) => {
          // 用户拖动优先：取消在飞的渐变，否则下一帧就把现值覆盖回去。
          core.cancelFade();
          core.applyVolume(value);
          // 拖音量条 = 明确要声音：静音状态一并解除。
          core.set({ volume: value, muted: false });
          savePrefs({ volume: value });
        },
        /**
         * 均衡器：预设 id 或自定义曲线。预设来自内置表；自定义曲线长度必须等于段数，
         * 超出 ±12dB 会被夹住（脏数据不该变成刺耳的声音）。两种都会持久化。
         */
        setEqualizer: (presetOrBands) => {
          let nextPreset = "custom";
          let nextBands: number[];
          if (typeof presetOrBands === "string") {
            const preset = EQ_PRESETS[presetOrBands];
            if (preset === undefined) return;                       // 未知预设：不动（不猜）
            nextPreset = presetOrBands;
            nextBands = preset.slice();
          } else if (Array.isArray(presetOrBands) && presetOrBands.length === EQ_BANDS.length) {
            nextBands = presetOrBands.map((v) => (typeof v === "number" && Number.isFinite(v)
              ? Math.max(EQ_GAIN_MIN_DB, Math.min(EQ_GAIN_MAX_DB, v)) : 0));
          } else {
            return;                                                  // 长度不对：不动（不猜）
          }
          core.set({ eqPreset: nextPreset, eqBands: nextBands });
          savePrefs({ eqPreset: nextPreset, eqBands: nextBands });
          core.applyEqualizer();
        },
        /**
         * ReplayGain：模式（'off' | 'track' | 'album'）与可选前级增益（dB，省略则不变）。
         * 未测量的曲目**不做增益** —— 想统一推高请用前级，而不是把它当 0dB。
         */
        setReplayGain: (mode, preampDb) => {
          const nextMode = mode === "track" || mode === "album" ? mode : "off";
          const nextPreamp = typeof preampDb === "number" && Number.isFinite(preampDb)
            ? Math.max(core.RG_PREAMP_MIN_DB, Math.min(core.RG_PREAMP_MAX_DB, preampDb))
            : core.state.rgPreampDb;
          core.set({ rgMode: nextMode, rgPreampDb: nextPreamp });
          savePrefs({ rgMode: nextMode, rgPreampDb: nextPreamp });
          core.applyReplayGain();
          // 开了归一化但当前曲目既没标签也没测量值 → 直接开始测量。
          // 否则（实测用户曲库 0/40 首带标签）用户打开开关会发现「什么都没发生」。
          if (nextMode !== "off" && !core.hasRgData(core.state.tracks[core.state.current])) core.startRgMeasure();
        },
        toggleMode: () => {
          const mode = core.state.mode === "loop" ? "one" : "loop";
          core.set({ mode });
          savePrefs({ mode });
        },
        setQuery: (query) => core.set({ query }),
        toggleSort: (key) => {
          const sortDir = core.state.sortKey === key ? (core.state.sortDir === "asc" ? "desc" : "asc") : "asc";
          core.set({ sortKey: key, sortDir });
          savePrefs({ sortKey: key, sortDir });
        },
        /** 打开在线补全弹层：按曲目原名/歌手查 iTunes；query 为手动搜索词。 */
        match: async (id, query) => {
          const track = core.state.tracks.find((item) => item.id === id);
          if (track === undefined) return;
          const override = typeof query === "string" && query.trim().length > 0 ? query.trim() : "";
          const seq = ++core.matchSeq;
          core.set({ match: { id, loading: true, error: null, candidates: [], term: override } });
          try {
            const suffix = override.length > 0 ? "&q=" + encodeURIComponent(override) : "";
            const payload = await api("/api/match?p=" + encodeURIComponent(id) + suffix);
            if (seq !== core.matchSeq) return;
            // 旧宿主只有 iTunes 单源，响应里没有 terms/best：与其显示
            // “没有匹配结果”，不如直接说明宿主需要重载。
            if (payload.terms === undefined && payload.best === undefined) {
              const message = translate("error.staleHost");
              core.set({ match: { id, loading: false, error: message, candidates: [], term: override }, error: message });
              return;
            }
            const candidates = Array.isArray(payload.candidates) ? payload.candidates : [];
            const sourceErrors = Array.isArray(payload.errors) && payload.errors.length > 0
              ? payload.errors.join("；")
              : null;
            core.set({
              match: {
                id,
                loading: false,
                // 真的没候选时，把各源的具体报错带出来（而不是只给一句“没找到”）。
                error: candidates.length === 0 && sourceErrors !== null ? sourceErrors : null,
                candidates,
                term: typeof payload.term === "string" ? payload.term : override,
              },
            });
          } catch (error) {
            if (seq !== core.matchSeq) return;
            core.set({
              match: {
                id,
                loading: false,
                error: error instanceof Error ? error.message : String(error),
                candidates: [],
                term: override,
              },
            });
          }
        },
        closeMatch: () => {
          core.matchSeq += 1;
          core.set({ match: null });
        },
        /**
         * 应用一条候选。writeFile=true 时调宿主写入标签并重命名本地文件；
         * 写文件失败或未勾选时退化为本地显示覆盖，功能不会因此不可用。
         */
        applyMatch: async (candidate, writeFile, replaceCover) => {
          const picker = core.state.match;
          if (picker === null || candidate === null || typeof candidate !== "object") return;
          const seq = ++core.matchSeq;
          const id = picker.id;
          const entry: MetaEntry = {};
          if (typeof candidate.title === "string" && candidate.title.length > 0) entry.title = candidate.title;
          if (typeof candidate.artist === "string" && candidate.artist.length > 0) entry.artist = candidate.artist;
          if (typeof candidate.album === "string" && candidate.album.length > 0) entry.album = candidate.album;
          if (typeof candidate.cover === "string" && candidate.cover.length > 0) entry.cover = candidate.cover;

          // 仅改显示：不碰音频文件。
          if (writeFile !== true) {
            const meta = { ...core.state.meta, [id]: entry };
            persistMeta(meta);
            core.set({ meta, match: null });
            core.updateMediaSession();
            return;
          }

          const position = core.audio.currentTime;
          const wasLoaded = (core.playingId !== null && core.playingId === id)
            || (core.state.current >= 0 && core.state.tracks[core.state.current]?.id === id);
          const wasPlaying = wasLoaded && !core.audio.paused;
          core.set({ match: { id, loading: true, applying: true, error: null, candidates: [], term: picker.term } });
          try {
            // 宿主只在调用方**显式**要求时才替换已有内嵌封面（缺省只补缺失，见 /api/apply）。
            // 手动应用是用户逐首选定的动作：候选带封面且「替换已有封面」勾选时才要求替换。
            // 缺了这一项，已有封面的歌怎么应用都不会变。
            const replaceExisting = replaceCover === true
              && typeof candidate.cover === "string" && candidate.cover.length > 0;
            const payload = await api("/api/apply", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ id, ...entry, rename: true, replaceCover: replaceExisting }),
            });
            // 弹层已被关闭 / 插件已停用：这次结果作废，不得再改状态。
            if (seq !== core.matchSeq) return;
            const oldId = typeof payload.oldId === "string" ? payload.oldId : id;
            const newId = typeof payload.newId === "string" ? payload.newId : oldId;
            if (oldId !== newId) {
              const last = loadPrefs().last;
              if (last !== undefined && last.id === oldId) savePrefs({ last: { ...last, id: newId } });
              if (core.playingId === oldId) core.playingId = newId;
              // 收藏按路径 id 存；重命名必须迁移，否则“收藏”视图会凭空少一首。
              if (core.state.favorites.has(oldId)) {
                const nextFavorites = new Set(core.state.favorites);
                nextFavorites.delete(oldId);
                nextFavorites.add(newId);
                core.set({ favorites: nextFavorites });
                saveFavorites(nextFavorites);
              }
            }
            if (payload.library !== undefined) core.applyLibrary(payload.library);
            // 被重命名的文件旧流地址已失效：重新指向新 id 并恢复播放位置。
            if (wasLoaded) {
              const index = core.state.tracks.findIndex((track) => track.id === newId);
              if (index >= 0) {
                const track = core.state.tracks[index];
                core.set({ current: index, time: position, duration: typeof track.duration === "number" ? track.duration : 0 });
                // 先等基址再挂源（同 recoverAt：相对地址在 Desktop 上不可 seek）。
                void (async () => {
                  await core.ensureStreamBase();
                  if (core.disposed || core.playingId !== newId) return;
                  core.audio.src = core.streamUrl(track);
                  core.audio.addEventListener("loadedmetadata", () => {
                    if (core.playingId !== newId) return;
                    if (Number.isFinite(core.audio.duration)) core.audio.currentTime = Math.min(position, Math.max(0, core.audio.duration - 1));
                  }, { once: true });
                  if (wasPlaying) {
                    const promise = core.audio.play();
                    if (promise !== undefined) promise.catch(() => {});
                  }
                })();
                core.updateMediaSession();
              }
            }
            const nextMeta = { ...core.state.meta };
            delete nextMeta[oldId];
            delete nextMeta[newId];
            // 标签写入失败时保留显示覆盖，至少列表里的原名是对的。
            if (payload.tagged !== true) nextMeta[newId] = entry;
            persistMeta(nextMeta);
            core.set({
              meta: nextMeta,
              match: null,
              error: payload.tagged === true
                ? null
                : (typeof payload.warning === "string" ? payload.warning : null),
            });
          } catch (error) {
            // 写文件失败不能让“显示修正”一起失败：退回本地覆盖。
            const meta = { ...core.state.meta, [id]: entry };
            persistMeta(meta);
            core.set({ meta, match: null, error: error instanceof Error ? error.message : String(error) });
          }
        },
        /** 一键补全：弹出确认条（会改本地文件，必须先确认）。 */
        completeRequest: () => {
          const count = core.state.tracks.filter((track) => core.state.meta[track.id] === undefined).length;
          if (count === 0) {
            core.set({ error: translate("complete.none") });
            return;
          }
          core.set({ pendingComplete: true, error: null });
        },
        cancelComplete: () => core.set({ pendingComplete: false }),
        clearError: () => core.set({ error: null }),
        toggleMute: () => {
          const next = !core.state.muted;
          core.set({ muted: next });
          // 走短渐变：直接归零/跳回都会有一声「啪」。
          void core.rampVolume(next ? 0 : core.state.volume, core.FADE_PAUSE_MS);
        },
        setCompleteOverwriteCover: (on) => core.set({ completeOverwriteCover: on === true }),

        stopComplete: () => core.set({ completing: false }),
        /**
         * 逐首检查全部曲目：多源搜索 → 标签已正确的直接跳过，有差异且高置信度
         * 才写标签 + 重命名（置信不足的一律不动）。逐首留间隔，用户可随时停止。
         */
        completeAll: async () => {
          if (core.state.completing) return;
          const targets = core.state.tracks.filter((track) => core.state.meta[track.id] === undefined);
          core.set({
            pendingComplete: false,
            error: null,
            completing: true,
            completeTotal: targets.length,
            completeDone: 0,
            completeFailed: 0,
            completeSkipped: 0,
          });
          if (targets.length === 0) {
            core.set({ completing: false, error: translate("complete.none") });
            return;
          }
          // 正在播放的文件即将被重命名，旧流地址会失效：先停下再改。
          if (core.playingId !== null && targets.some((track) => track.id === core.playingId)) {
            core.stopAudio();
            core.set({ current: -1, playing: false, time: 0, duration: 0 });
          }
          let done = 0;
          let failed = 0;
          let skipped = 0;
          for (const track of targets) {
            if (!core.state.completing) break;
            try {
              const payload = await api("/api/match?p=" + encodeURIComponent(track.id));
              // 旧宿主：不要假装“跳过”，直接停下并说明原因。
              if (payload.terms === undefined && payload.best === undefined) {
                core.set({ error: translate("error.staleHost") });
                break;
              }
              const candidate = payload.best !== undefined && payload.best !== null
                ? payload.best
                : (Array.isArray(payload.candidates) ? payload.candidates[0] : undefined);
              if (candidate === undefined) {
                failed += 1;
              } else if (payload.auto !== true) {
                // 置信不足：只统计、跳过，绝不把错误信息写进文件
                skipped += 1;
              } else if (track.tagged === true
                && sameKey(candidate.title) === sameKey(track.title)
                && sameKey(candidate.artist ?? "") === sameKey(track.artist ?? "")
                && track.name === expectedFileName(candidate.title, candidate.artist, track.name)
                && !(core.state.completeOverwriteCover && typeof candidate.cover === "string" && candidate.cover.length > 0)) {
                // 标签与文件名都已规范 ⇒ 通常无事可做，算「已正确」直接跳过。例外：用户勾选了
                // 「覆盖已有封面」而候选带封面时，封面正是要写的东西，不能算已完成 —— 否则
                // 已有封面的歌在批量里永远轮不到。
                skipped += 1;
              } else {
                const entry: MetaEntry = {};
                if (typeof candidate.title === "string" && candidate.title.length > 0) entry.title = candidate.title;
                if (typeof candidate.artist === "string" && candidate.artist.length > 0) entry.artist = candidate.artist;
                if (typeof candidate.album === "string" && candidate.album.length > 0) entry.album = candidate.album;
                if (typeof candidate.cover === "string" && candidate.cover.length > 0) entry.cover = candidate.cover;
                await api("/api/apply", {
                  method: "POST",
                  headers: { "content-type": "application/json" },
                  body: JSON.stringify({
                    id: track.id,
                    ...entry,
                    rename: true,
                    replaceCover: core.state.completeOverwriteCover === true,
                  }),
                });
                // 注意：这里**不再**顺手转格式。一键补全只做它本来的事（写标签 + 重命名）。
                // 之前把「转码 + 丢原件」挂在补全里是设计错误：批量、不可逆、还看不出发生了什么。
              }
            } catch {
              failed += 1;
            }
            done += 1;
            core.set({ completeDone: done, completeFailed: failed, completeSkipped: skipped });
            await new Promise((resolve) => setTimeout(resolve, 600));
          }
          try {
            core.applyLibrary(await api("/api/library"));
          } catch {
            // 列表刷新失败不影响已完成的补全。
          }
          core.set({ completing: false, completeTotal: targets.length, completeDone: done, completeFailed: failed, completeSkipped: skipped });
        },
        /** 清除某曲目的在线补全，恢复文件内嵌标签/文件名回退。 */
        clearMeta: (id) => {
          if (core.state.meta[id] === undefined) return;
          core.matchSeq += 1;
          const meta = { ...core.state.meta };
          delete meta[id];
          persistMeta(meta);
          core.set({ meta, match: null });
          core.updateMediaSession();
        },
        effective: core.effective,
        coverFor: core.coverFor,
        /** Live playback clock for the smooth progress fill (rAF consumers). */
        now: () => core.audio.currentTime,
        /** 可见列表：渲染与播放推进共用的同一顺序（所见即所播）。 */
        visibleRows: core.visibleRows,
      };
      return api0;
    }

    function createTransport(core) {
      /**
       * 媒体元素池与交叉淡化：元素/电平节点/预取/交接/挂源。
       * 依赖用 core getter/setter 注入（audio 会交换、settlePending 在本工厂闭包里）。
       */
      let settlePending: (() => void) | null = null;
    const commitPendingCrossfade = () => {
      const pending = settlePending;
      settlePending = null;
      if (pending !== null) pending();
    };
    const ensureIdleElement = (): HTMLVideoElement | null => {
      if (!core.crossfadeOn) return null;
      if (core.idleEl !== null) return core.idleEl;
      const injected = (window as unknown as { __dshMusicMedia2?: () => HTMLVideoElement }).__dshMusicMedia2;
      const el = typeof injected === "function" ? injected() : document.createElement("video");
      el.preload = "auto";
      el.className = "dshm-mv";
      el.setAttribute?.("playsinline", "");
      el.volume = 1;
      if (core.mediaPark !== null) core.mediaPark.appendChild(el);
      core.idleEl = el;
      // 预取用的这一半是"下一个活动元素"：交换过去后它要接管全部媒体事件。
      core.bindMedia(el);
      return el;
    };
    const ensureIdleGraph = (): boolean => {
      const el = core.idleEl;
      const ctx = core.device.ctx;
      const rg = core.device.rg;
      if (ctx === null || rg === null || el === null) return false;
      if (core.idleLevelNode !== null) return true;
      try {
        const level = ctx.createGain();
        level.gain.value = 0;
        level.connect(rg);
        core.idleSource = ctx.createMediaElementSource(el);
        core.idleSource.connect(level);
        core.idleLevelNode = level;
        return true;
      } catch {
        return false;
      }
    };
    const schedulePrefetch = () => {
      if (core.disposed) return;
      const next = core.nextTrackForPrefetch();
      if (next === null) { core.prefetchedUrl = null; return; }
      // 波形预取与交叉淡化**解耦**：关掉淡化也该预取（少一次往返，切歌时柱子立刻出现）。
      void core.prefetchWaveform(next);
      if (!core.crossfadeOn) return;
      const el = ensureIdleElement();
      if (el === null || !ensureIdleGraph()) return;
      const url = core.streamUrl(next);
      core.prefetchedUrl = url;
      el.src = url;
      el.load?.();
    };
    const attachSource = (url) => {
      // 任何新的切歌先把**上一段在飞的交叉淡化**结算掉：角色/电平/`audio` 绑定必须是一致状态，
      // 否则迟到的交接会把刚起播的那一首 pause 掉（本轮实测：快速连切时能听见「切过去又停」）。
      commitPendingCrossfade();
      const epoch = core.pauseEpoch;
      core.logAttach(url);
      /** 挂源 + 起播 + 淡入。**必须同步执行**，调用方的时序依赖它。 */
      const startNow = () => {
        // 音频图必须在挂源**之前**建好：一条常驻输出流 = 设备格式不再随文件变。
        // 跨源且尚未确认 ACAO 时**不建图**（先走直连，零风险），只探一次。
        const sameOrigin = core.sameOriginAsPage(url);
        if (!sameOrigin && core.device.corsOk !== true) core.probeCrossOriginCors(url);
        const graph = (sameOrigin || core.device.corsOk === true) && core.ensureAudioGraph();
        if (graph && core.audioCtx !== null) {
          // 瞬时音量**在元素音量里还是已在图上**取决于这一代是否已建过图：readVolume()
          // 两条路都归一成「用户音量刻度」。直接读 `audio.volume` 是错的 —— 建图之后
          // 元素音量恒为中性 1，那会把每一首的起播都跳到满幅再淡下来（实测过的爆音）。
          const carried = core.readVolume();
          core.audio.volume = 1;
          const gain = core.gainNode;
          if (gain !== null) gain.gain.value = carried;   // 把瞬时值搬到图上，渐变从这里继续
          // 设备可能被上一代 halt() suspend 过：出声之前必须让它回到 running。
          core.resumeGraph();
          // 跨源媒体接进音频图**必须**带 crossOrigin，否则 Web Audio 输出静音；
          // 同源则**必须不带**（带了反而会因为同源响应没有 ACAO 而加载失败）。
          if (sameOrigin) core.audio.removeAttribute("crossorigin");
          else core.audio.crossOrigin = "anonymous";
        }
        // 切曲前把该曲目的 ReplayGain 落到图上：晚一步就会先按上一首的增益出声。
        core.applyReplayGain();
        core.audio.src = url;
        const promise = core.audio.play();
        if (promise === undefined) {
          core.applyVolume(core.targetVolume());
          return;
        }
        // 起播后淡入到用户音量，避免第一帧就是满幅。
        void promise.then(() => {
          if (!core.disposed) void core.rampVolume(core.targetVolume(), core.changeFadeInMs);
          // 起播后把**下一首**挂到空闲元素上，切换时就能直接交叉进入。
          if (!core.disposed) schedulePrefetch();
        }).catch((error) => {
          // AbortError = 这次 play 被随后的 pause()/换源打断，不是失败（快速切歌、
          // 立刻暂停都会走到这里）。把它当成「播不了」会误报红字。
          if (error?.name === "NotAllowedError") {
            core.set({ playing: false });
            return;
          }
          if (error?.name === "AbortError") {
            core.set({ playing: false });
            return;
          }
          core.set({ playing: false, error: translate("error.unsupported") });
        });
      };
      // 「确定正在出声」才需要淡出。判据写成 `paused === false && volume > 0` 而不是
      // `paused || volume <= 0.001`：后者在属性缺失（`paused === undefined`）时两个分支
      // 都是 false，会误判成「正在播」而走异步路径（第 18 轮实测踩到）。
      /**
       * 交叉进入：空闲元素**已经预取好**这一首，于是新旧两首**重叠**淡入淡出 ——
       * 300ms 的遮蔽力保持不变，而「淡出→加载→淡入」的缝隙消失（这就是 fooyin
       * `nexttrackpreparer` + crossfade 在浏览器里的等价物）。两个元素接进**同一个
       * 常驻 AudioContext**，所以设备流仍然只有一条。
       */
      const crossfadeInto = (): boolean => {
        const inEl = core.idleEl;
        const inLevel = core.idleLevelNode;
        if (!core.crossfadeOn || core.audioCtx === null || inEl === null || inLevel === null) return false;
        if (core.prefetchedUrl !== url || !(inEl.readyState >= 2)) return false;
        // 两个元素都在设备上：设备被 suspend 过（上一代 halt / 系统挂起）时先让它回到 running，
        // 否则「交叉淡化成功」但整体无声。
        core.resumeGraph();
        const outEl = core.audio;
        const outLevel = core.activeLevelNode;
        // 共享 RG 节点按**新**曲目设值 —— 用**斜坡**（两首同时在响，见 applyReplayGain 注释）。
        core.applyReplayGain(core.changeFadeInMs);
        try { inEl.currentTime = 0; } catch { /* 假元素可能没有 setter 语义 */ }
        const now = core.audioCtx.currentTime;
        const down = outLevel;
        if (down !== null) {
          down.gain.cancelScheduledValues(now);
          down.gain.setValueAtTime(Number.isFinite(down.gain.value) ? down.gain.value : 1, now);
          down.gain.linearRampToValueAtTime(0, now + core.changeFadeOutMs / 1000);
        }
        inLevel.gain.cancelScheduledValues(now);
        inLevel.gain.setValueAtTime(0, now);
        inLevel.gain.linearRampToValueAtTime(1, now + core.changeFadeInMs / 1000);
        const promise = inEl.play();
        core.set({ playing: true, error: null, buffering: false });
        const settle = () => {
          if (core.disposed) return;
          // ⚠️ **不要**清掉旧元素的 `src` / 调 `load()`：那会再触发一次媒体管线拆除 ——
          // 设备侧看到的是**两次**事件而不是一次。让它保持原样，等下一次预取直接覆盖即可
          // （交换后它就是空闲元素，紧接着就会被 `schedulePrefetch` 换上下一首）。
          try {
            outEl.pause();
          } catch { /* 假元素 */ }
          if (outLevel !== null) outLevel.gain.value = 0;
          // 交换角色：`audio` 是 let，其余 90+ 处引用自动跟随；电平节点跟着换。
          core.audio = inEl;
          core.idleEl = outEl;
          const levelSwap = core.activeLevelNode;
          core.activeLevelNode = inLevel;
          core.idleLevelNode = levelSwap;
          core.prefetchedUrl = null;
          schedulePrefetch();
        };
        settlePending = settle;
        setTimeout(() => {
          // 被更新的过渡取代了就**什么都不做**（新过渡已经接手元素角色）。
          if (settlePending !== settle) return;
          settlePending = null;
          settle();
        }, core.changeFadeOutMs + 20);
        if (promise !== undefined) promise.catch(() => { /* AbortError 等：不是失败 */ });
        return true;
      };

      const audible = core.audio.paused === false && Number.isFinite(core.audio.volume) && core.audio.volume > 0.001;
      // 预取已经就绪 → 直接重叠进入（无声可淡、或没预取到，才走下面既有的两条路径）。
      if (audible && crossfadeInto()) return;
      if (!audible) {
        // ⚠️ 没有声音要淡出时**必须同步起播**：这里 await 一下就会把 src/play 推迟到
        // 一个微任务之后，起播时序整体后移（第 18 轮实测：6 套回归当场抓到）。
        // 首播、暂停中切歌都走这条，行为与引入渐变之前完全一致。
        core.cancelFade();
        core.applyVolume(0);
        startNow();
        return;
      }
      // 正在播：先淡出**再**换 src。不淡出就换源，Chromium 会在当前采样的位置直接掐断
      // 旧流，耳机里就是一声「啪」—— 这正是要修的症状。代价是这一路 ~70ms。
      // 用户点击带来的 sticky activation 仍然有效（本文件其它路径也早就 await 后才 play）。
      void (async () => {
        await core.rampVolume(0, core.changeFadeOutMs);
        if (core.disposed || epoch !== core.pauseEpoch) return;
        startNow();
      })();
    };
      return { commitPendingCrossfade, attachSource };
    }

    function createAudioEngine(core) {
      /**
       * 常驻音频图、淡入淡出、ReplayGain 与均衡器的应用层。
       * 依赖用 core getter/setter 注入；fade 状态归本工厂闭包。
       */
    let fadeSeq = 0;
    let fadeCancelTimer: (() => void) | null = null;
    let fadeSettle: ((done: boolean) => void) | null = null;
    const releaseElement = (node: { disconnect?: () => void } | null) => {
      if (node === null || typeof node.disconnect !== "function") return;
      try {
        node.disconnect();
      } catch { /* 已经断开 */ }
    };
    const resumeGraph = () => {
      const ctx = core.audioCtx;
      if (ctx === null || ctx.state === "running") return;
      console.info("[dsh-music-player] AudioContext state=" + String(ctx.state) + " → 恢复输出（未记任何 URL/凭据）");
      void ctx.resume();
    };
    const watchSuspended = () => {
      if (core.disposed || core.audio.paused !== false || core.audioCtx === null) return;
      resumeGraph();
    };
    const ensureDevice = (): boolean => {
      if (core.device.volume !== null) return true;
      if (core.device.disabled || core.graphOffByFlag) return false;
      const Ctor = window.AudioContext
        ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (Ctor === undefined) {
        core.device.disabled = true;
        console.info("[dsh-music-player] 本环境没有 AudioContext —— 退回元素音量（功能不受影响）");
        return false;
      }
      const ctx = new Ctor();
      // 设备级只装一次处理器：具体「该不该恢复」由当前代（watcher）决定。
      ctx.onstatechange = () => {
        const watcher = core.device.watcher;
        if (watcher !== null) watcher();
      };
      // 「在行为发生的那一刻」记一行无凭据诊断（§2.16）。**只记数字与状态**，
      // 绝不记 URL / token（§2.9）。sampleRate 是关键：ctx 的采样率**创建时固定**，
      // 所以要能看到它到底钉在多少（howler.js 也为此专门 unload 重建 ctx）。
      console.info(
        "[dsh-music-player] 常驻音频图已启用：sampleRate=" + String(ctx.sampleRate) +
        "Hz state=" + String(ctx.state) +
        "（所有媒体重采样到这条流，输出设备格式不再变）"
      );
      const gain = ctx.createGain();
      gain.gain.value = 0;
      gain.connect(ctx.destination);
      // 均衡器链：rg → f1 → … → f10 → eqPreamp → 音量 → destination。
      // 0dB 的 peaking 滤波器是直通，所以关闭不需要旁路；**自动前级**按最大提升量衰减，
      // 保证「只提升某几段」不会把峰值推过满刻度（与 RG 的防削波同一思路）。
      const eqPreamp = ctx.createGain();
      eqPreamp.gain.value = 1;
      eqPreamp.connect(gain);
      // 没有 createBiquadFilter 的环境只**跳过 EQ**，绝不能因此把整条音频图判为失败 ——
      // 那会连「常驻输出流」（§2.19 的根本修法）一起丢掉。
      let eqChainHead: AudioNode = eqPreamp;
      if (typeof ctx.createBiquadFilter === "function") {
        const filters: BiquadFilterNode[] = [];
        for (const frequency of EQ_BANDS) {
          const filter = ctx.createBiquadFilter();
          filter.type = "peaking";
          filter.frequency.value = frequency;
          filter.Q.value = EQ_Q;
          filter.gain.value = 0;
          filters.push(filter);
        }
        // 倒着接：f10→前级、f9→f10 … f1→f2，于是信号方向是 rg → f1 → … → f10 → 前级 → 音量。
        let node: AudioNode = eqPreamp;
        for (let i = filters.length - 1; i >= 0; i -= 1) {
          filters[i].connect(node);
          node = filters[i];
        }
        core.device.eqNodes = filters;
        core.device.eqPreamp = eqPreamp;
        eqChainHead = node;
      } else {
        console.info("[dsh-music-player] 本环境没有 createBiquadFilter —— 跳过均衡器（其余功能不受影响）");
      }
      // RG 节点串在媒体源与均衡器之间：各段增益互不覆盖（淡入淡出只写音量节点）。
      const rg = ctx.createGain();
      rg.gain.value = 1;
      rg.connect(eqChainHead);
      core.device.ctx = ctx;
      core.device.volume = gain;
      core.device.rg = rg;
      return true;
    };
    const ensureAudioGraph = (): boolean => {
      if (core.graphReady) return true;
      if (core.bindFailed || core.device.disabled || core.graphOffByFlag) return false;
      try {
        if (!ensureDevice()) return false;
        if (!core.bindElement()) return false;
        core.audioCtx = core.device.ctx;
        core.gainNode = core.device.volume;
        core.rgGainNode = core.device.rg;
        core.graphReady = true;
        core.device.watcher = watchSuspended;
        // 曲线可能在建图之前就设过了（prefs）—— 建完立刻应用一次，避免首播用了默认值。
        applyEqualizer();
        return true;
      } catch (error) {
        core.bindFailed = true;
        // `useUnknownInCatchVariables` 下 catch 变量是 unknown/{}，必须先收窄（§2.15）。
        const reason = error instanceof Error ? error.name : "unknown";
        console.info("[dsh-music-player] 音频图创建失败 —— 退回元素音量：" + reason);
        return false;
      }
    };
    const probeCrossOriginCors = (url: string) => {
      if (core.device.corsOk !== null) return;
      core.device.corsOk = false;                           // 探测期间先按「不行」处理
      void fetch(url, { method: "HEAD", mode: "cors", credentials: "omit" })
        .then(() => {
          core.device.corsOk = true;
          console.info("[dsh-music-player] 跨源媒体 CORS 探测通过 —— 下一首起接入常驻音频图");
        })
        .catch(() => {
          core.device.corsOk = false;  // 缺 ACAO 时 fetch 会 reject
          console.info("[dsh-music-player] 跨源媒体 CORS 探测未通过 —— 继续直连（宿主没回 ACAO）");
        });
    };
    const applyVolume = (value: number) => {
      const v = Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0;
      if (core.gainNode !== null) {
        core.audio.volume = 1;                              // 元素音量中性，真正的增益在图里
        core.gainNode.gain.value = v;
      } else {
        // 回退路径只有**一个**旋钮：响度归一化必须折进来，否则 RG 静默失效。
        core.audio.volume = Math.max(0, Math.min(1, v * core.rgLinear));
      }
    };
    const readVolume = (): number => {
      if (core.gainNode !== null) return Number.isFinite(core.gainNode.gain.value) ? core.gainNode.gain.value : 0;
      const raw = Number.isFinite(core.audio.volume) ? core.audio.volume : 0;
      // 元素音量里含着 RG，读回来要**除回去**，否则渐变会从被 RG 缩过的值起步。
      return core.rgLinear > 0 ? Math.max(0, Math.min(1, raw / core.rgLinear)) : raw;
    };
    const hasRgData = (track: MusicTrack | undefined): boolean => track !== undefined
      && [track.rgTrackGainDb, track.rgAlbumGainDb, track.rgMeasuredGainDb]
        .some((v) => typeof v === "number" && Number.isFinite(v));
    const startRgMeasure = () => {
      if (core.disposed || core.state.rgMeasuring) return;
      core.set({ rgMeasuring: true, rgMeasureDone: 0, rgMeasureTotal: 0 });
      void (async () => {
        try {
          const status = await api("/api/measure", { method: "POST" });
          if (core.disposed) return;
          core.set({
            rgMeasureDone: Number(status?.done) || 0,
            rgMeasureTotal: Number(status?.total) || 0,
            rgMeasuring: status?.running === true,
          });
          if (core.state.rgMeasuring) core.scheduleRgPoll();
        } catch {
          if (!core.disposed) core.set({ rgMeasuring: false });
        }
      })();
    };
    const applyEqualizer = () => {
      const filters = core.device.eqNodes;
      if (filters.length === 0) return;
      let maxBoost = 0;
      for (let i = 0; i < filters.length; i += 1) {
        const raw = core.state.eqBands[i];
        const db = typeof raw === "number" && Number.isFinite(raw)
          ? Math.max(EQ_GAIN_MIN_DB, Math.min(EQ_GAIN_MAX_DB, raw)) : 0;
        filters[i].gain.value = db;
        if (db > maxBoost) maxBoost = db;
      }
      if (core.device.eqPreamp !== null) {
        core.device.eqPreamp.gain.value = maxBoost > 0 ? Math.pow(10, -maxBoost / 20) : 1;
      }
    };
    const applyReplayGain = (rampMs = 0) => {
      const next = core.rgForTrack(core.state.tracks[core.state.current]);
      const node = core.rgGainNode;
      if (node !== null) {
        // 交叉淡化期间新旧两首**同时出声**，而 RG 节点是**共享**的：瞬时写值等于在重叠中间
        // 给两首一起做了个阶跃 —— 听感就是那「一丝丝杂音」。所以按过渡时长**斜坡**推过去。
        // 顺序播放路径（旧曲已静音）保持瞬时写值：那里没有可听的不连续。
        if (rampMs > 0 && core.audioCtx !== null) {
          const now = core.audioCtx.currentTime;
          node.gain.cancelScheduledValues(now);
          node.gain.setValueAtTime(Number.isFinite(node.gain.value) ? node.gain.value : next.linear, now);
          node.gain.linearRampToValueAtTime(next.linear, now + rampMs / 1000);
        } else {
          node.gain.value = next.linear;
        }
      }
      // 回退路径的 RG 折在**元素音量**里，所以 RG 没变就不必再写一次 ——
      // 冗余写入会让「起播前不得有渐变写入」这类断言失去分辨力（test-audio-fade A2）。
      if (next.linear === core.rgLinear) {
        core.set({ rgTrackDb: next.db });
        return;
      }
      const user = readVolume();     // 必须**先**读：readVolume 依赖旧的 rgLinear
      core.rgLinear = next.linear;
      applyVolume(user);
      core.set({ rgTrackDb: next.db });
    };
    const cancelFade = () => {
      fadeSeq += 1;
      if (fadeCancelTimer !== null) {
        fadeCancelTimer();
        fadeCancelTimer = null;
      }
      if (fadeSettle !== null) {
        const settle = fadeSettle;
        fadeSettle = null;
        settle(false);
      }
    };
    const rampVolume = (to: number, ms: number): Promise<boolean> => {
      cancelFade();
      const seq = fadeSeq;
      // 非有限值兜底：光秃秃的假元素可能压根没有 volume 属性，直接算会得到 NaN。
      const from = readVolume();
      const target = Number.isFinite(to) ? Math.max(0, Math.min(1, to)) : 0;
      if (core.disposed || ms <= 0 || Math.abs(from - target) < 0.001) {
        // 已卸载：不再渐变，直接落到目标（halt 之后不该再有渐变在写音量）。
        applyVolume(target);
        return Promise.resolve(true);
      }
      if (core.audioCtx !== null && core.gainNode !== null) {
        // 音频图：用 context 时钟做**采样级**线性渐变 —— 比 16ms 定时器平滑，
        // 也不会在渐变过程中产生阶梯噪声。
        const gain = core.gainNode.gain;
        const now = core.audioCtx.currentTime;
        gain.cancelScheduledValues(now);
        gain.setValueAtTime(from, now);
        gain.linearRampToValueAtTime(target, now + ms / 1000);
        return new Promise((resolve) => {
          fadeSettle = resolve;
          const timer = setTimeout(() => {
            fadeCancelTimer = null;
            if (seq !== fadeSeq) return;               // 已被 cancelFade 结算
            const settle = fadeSettle;
            fadeSettle = null;
            if (settle !== null) settle(true);
          }, ms + 20);
          fadeCancelTimer = () => clearTimeout(timer);
        });
      }
      return new Promise((resolve) => {
        const started = Date.now();
        fadeSettle = resolve;
        const timer = setInterval(() => {
          if (seq !== fadeSeq) return;                 // 已被 cancelFade 结算，什么都不做
          const t = Math.min(1, (Date.now() - started) / ms);
          applyVolume(from + (target - from) * t);
          if (t >= 1) {
            if (fadeCancelTimer !== null) {
              fadeCancelTimer();
              fadeCancelTimer = null;
            }
            const settle = fadeSettle;
            fadeSettle = null;
            if (settle !== null) settle(true);
          }
        }, 16);
        fadeCancelTimer = () => clearInterval(timer);
      });
    };
      return { ensureDevice, ensureAudioGraph, resumeGraph, applyVolume, rampVolume, cancelFade, readVolume, applyReplayGain, startRgMeasure, hasRgData, applyEqualizer, probeCrossOriginCors, watchSuspended, releaseElement };
    }

    function createRuntime(core) {
      /**
       * 播放运行时的其余职责：列表与恢复、音量/进度、预取、MV、媒体事件、错误恢复。
       * 依赖用 core getter/setter 注入；可变绑定留在 createPlayer。
       */
    const stopAudio = () => {
      core.playingId = null;
      core.pauseEpoch += 1;   // 在飞的 startNow 不得把已停掉的播放重新起来
      core.cancelFade();
      core.applyVolume(0);
      core.audio.pause();
      if (core.idleEl !== null) {
        // 交叉淡化模式下另一个元素也可能在出声：只停 `audio` 会留下它继续播。
        try { core.idleEl.pause(); } catch { /* 假元素 */ }
      }
      core.audio.removeAttribute("src");
      core.audio.load();
    };
    const mvCacheUrl = (key) => {
      const encoded = encodeURIComponent(key);
      if (hasStreamBase()) {
        return systemStreamBase + "&k=" + encoded;
      }
      return endpointBase + "/mvfile?k=" + encoded;
    };
    const hasStreamBase = () => typeof systemStreamBase === "string" && systemStreamBase.length > 0;
    const ensureStreamBase = async () => {
      if (hasStreamBase()) return true;
      await Promise.race([loadSystemArtBase(), new Promise((resolve) => setTimeout(resolve, 2000))]);
      if (hasStreamBase()) return true;
      invalidateSessionBase();
      await Promise.race([loadSystemArtBase(true), new Promise((resolve) => setTimeout(resolve, 4000))]);
      return hasStreamBase();
    };
    const streamUrl = (track) => {
      const rev = "&v=" + (core.state.scannedAt ?? 0);
      // Desktop：走 token 直连（保住 Range，拖动/快进才不会回到 0 秒）。
      if (hasStreamBase()) {
        return systemStreamBase + "&p=" + encodeURIComponent(track.id) + rev;
      }
      return endpointBase + "/stream?p=" + encodeURIComponent(track.id) + rev;
    };
    const mediaSrcKind = (url: string): string => {
      if (url === "") return "empty";
      if (url.startsWith("http")) return url.includes("system-stream") ? "token" : "abs";
      if (url.includes("/mvfile")) return "mvfile-rel";
      if (url.startsWith("blob:")) return "blob";
      return "rel";
    };
    const redactSrc = (url: string): string => url.replace(/t=[^&]*/g, "t=***");
    const logSeek = (asked) => {
      setTimeout(() => {
        try {
          const seekable = core.audio.seekable ?? null;
          const bounds = seekable !== null && seekable.length > 0
            ? seekable.start(0).toFixed(1) + ".." + seekable.end(0).toFixed(1) : "-";
          const src = typeof core.audio.currentSrc === "string" ? core.audio.currentSrc : "";
          console.info("[dsh-music] seek asked=" + asked.toFixed(1) + " now=" + (Number.isFinite(core.audio.currentTime) ? core.audio.currentTime.toFixed(1) : "?")
            + " dur=" + (Number.isFinite(core.audio.duration) ? core.audio.duration.toFixed(1) : String(core.audio.duration))
            + " seekable=" + (seekable === null ? "-" : seekable.length) + "(" + bounds + ")"
            + " src=" + mediaSrcKind(src) + " err=" + (core.audio.error !== null && core.audio.error !== undefined ? core.audio.error.code : 0)
            + " base=" + (hasStreamBase() ? "token" : "none") + " ep=" + endpointBase
            + " url=" + redactSrc(src));
        } catch { /* 日志失败无所谓 */ }
      }, 400);
    };
    const healUnseekableSource = () => {
      if (core.disposed) return;
      const src = typeof core.audio.currentSrc === "string" ? core.audio.currentSrc : "";
      if (src.includes("system-stream")) return;                       // 已是 token 直连，基址没问题
      if (!(Number.isFinite(core.audio.duration) && core.audio.duration > 0)) return;
      const range = core.audio.seekable ?? null;
      if (range === null) return;                                      // 拿不到可寻址信息就不猜（假元素可能没有这个属性）
      if (range.length > 0 && range.end(0) > 0) return;                // 能 seek，正常
      const index = core.state.current;
      const track = index >= 0 ? core.state.tracks[index] : undefined;
      if (track === undefined) return;
      // 换了源就重新开一个窗口（每首歌各有自己的预算）。
      // ⚠️ 条件必须带 `deadline === 0`：首次调用时 `src` 可能与 `unseekableSrc`
      // 的初值同为 ""（假元素没有 currentSrc 时就是如此），只判「变了」会导致
      // deadline 永远停在 0 → 第一行就 `Date.now() > 0` 直接 return，自愈从不执行。
      if (src !== core.unseekableSrc || core.unseekableHealDeadline === 0) {
        core.unseekableSrc = src;
        core.unseekableHealDeadline = Date.now() + core.UNSEEKABLE_HEAL_WINDOW_MS;
      }
      if (Date.now() > core.unseekableHealDeadline) return;                 // 窗口内一直没成功：放弃，不再打扰
      const wasAt = Number.isFinite(core.audio.currentTime) ? core.audio.currentTime : 0;
      const wasPlaying = core.state.playing;
      invalidateSessionBase();
      void (async () => {
        const usable = await ensureStreamBase();
        if (core.disposed || core.playingId !== track.id) return;
        if (!usable) {
          // ⚠️ 基址还没就绪时**不能一次就放弃**。第一版就是一次性的：第一次尝试压在
          // 宿主还没准备好的时刻上，失败后永久锁死 —— 真机上等于自愈从未生效。
          // 退回窗口内再试，由 deadline 收口，不会变成无限重试。
          scheduleUnseekableHeal(1200);
          return;
        }
        // ⚠️ 按**当前这条源是什么类型**决定怎么修，不能按 track.kind 猜：
        //   含 `/mvfile` 或 `&k=` → MV 转码缓存文件，要重新问一次 /api/mv 拿缓存键；
        //   否则                  → 音轨 / 音频流，重建 streamUrl 即可。
        // 真机教训：`.mov` 走 **WASM 旁路**时元素播的是 `/stream?p=<视频文件>`
        // （画面由 WASM 解，元素只播音轨），而这时 track.kind 仍是 "video" —— 按 kind
        // 去 prepareVideo 会去等一次可能长达几分钟的转码，自愈于是永远卡住、源从未被换掉
        // （用户日志里 url 从第一次 seek 到最后一次完全没变，就是这个原因）。
        const wasMvCache = src.includes("/mvfile") || src.includes("&k=");
        const next = wasMvCache ? await prepareVideo(track) : streamUrl(track);
        if (core.disposed || core.playingId !== track.id) return;
        if (next === null) { scheduleUnseekableHeal(1200); return; }   // 还没就绪：窗口内再试
        core.audio.src = next;
        core.audio.addEventListener("loadedmetadata", () => {
          if (core.playingId !== track.id) return;
          if (wasAt > 0 && Number.isFinite(core.audio.duration) && wasAt < core.audio.duration - 0.5) core.audio.currentTime = wasAt;
          if (wasPlaying) {
            const promise = core.audio.play();
            if (promise !== undefined) promise.catch(() => {});
          }
        }, { once: true });
        core.audio.load();
      })();
    };
    const scheduleUnseekableHeal = (delayMs = 700) => {
      if (core.disposed) return;                                            // 已立闸门：不再排期（§2.10）
      if (core.unseekableTimer !== null) clearTimeout(core.unseekableTimer);
      core.unseekableTimer = setTimeout(() => {
        core.unseekableTimer = null;
        healUnseekableSource();
      }, delayMs);
    };
    const logAttach = (url: string) => {
      const kind = mediaSrcKind(url);
      if (kind === "token") return;
      console.info("[dsh-music] attach kind=" + kind + " base=" + (hasStreamBase() ? "token" : "none")
        + " ep=" + endpointBase + " url=" + redactSrc(url));
    };
    const seekAudio = (value) => {
      if (!Number.isFinite(value)) return 0;
      const known = Number.isFinite(core.audio.duration) && core.audio.duration > 0 ? core.audio.duration : core.state.duration;
      const at = known > 0 ? Math.max(0, Math.min(known, value)) : Math.max(0, value);
      // Re-assigning the position we are already at would abort and re-issue
      // the range request (the native change event lands after pointerup).
      if (!Number.isFinite(core.audio.currentTime) || Math.abs(core.audio.currentTime - at) > 0.01) core.audio.currentTime = at;
      return at;
    };
    const savePosition = (force) => {
      if (core.state.current < 0) return;
      const track = core.state.tracks[core.state.current];
      if (track === undefined) return;
      const at = Math.max(0, Math.floor(core.audio.currentTime));
      if (!force && Math.abs(at - core.lastSavedAt) < 5) return;
      core.lastSavedAt = at;
      savePrefs({ last: { id: track.id, time: at } });
    };
    const schedulePoll = () => {
      if (core.disposed || core.pollTimer !== null) return;
      core.pollTimer = setTimeout(async () => {
        core.pollTimer = null;
        if (core.disposed || !core.state.scanning) return;
        try {
          applyLibrary(await api("/api/library"));
        } catch {
          if (!core.disposed) schedulePoll();
        }
      }, 1500);
    };
    const applyLibrary = (payload) => {
      const scanning = payload.scanning === true;
      const incoming = payload.tracks ?? [];
      // A host scan reports no rows (library = null while it runs). For a
      // refresh of the SAME directory, keep the current table and the
      // scannedAt cache-busters so the list does not blank out mid-scan.
      const keepRows = scanning && incoming.length === 0 && core.state.dir !== null && payload.dir === core.state.dir;
      const nextTracks = keepRows ? core.state.tracks : incoming;
      // 补全结果按稳定 id 保存：库变化时剔除已不在库内的条目，防止旧目录的
      // 补全串到新目录里的同名文件（id 是相对路径，可能重名）。
      let nextMeta = core.state.meta;
      if (!scanning) {
        const liveIds = new Set(nextTracks.map((track) => track.id));
        let stale = false;
        for (const id of Object.keys(core.state.meta)) {
          if (!liveIds.has(id)) { stale = true; break; }
        }
        if (stale) {
          const pruned = {};
          for (const track of nextTracks) {
            if (core.state.meta[track.id] !== undefined) pruned[track.id] = core.state.meta[track.id];
          }
          nextMeta = pruned;
          persistMeta(pruned);
        }
      }
      core.set({
        dir: payload.dir,
        tracks: nextTracks,
        meta: nextMeta,
        scannedAt: scanning && payload.scannedAt == null ? core.state.scannedAt : (payload.scannedAt ?? null),
        scanning,
        scanParsed: payload.scanParsed ?? 0,
        scanTotal: payload.scanTotal ?? 0,
        truncated: keepRows ? core.state.truncated : payload.truncated === true,
        skippedPackages: keepRows ? core.state.skippedPackages : (payload.skippedPackages ?? 0),
        error: null,
        pendingDelete: scanning ? core.state.pendingDelete : -1,
      });
      if (scanning) {
        // Keep the current playback untouched while the new scan runs.
        schedulePoll();
        return;
      }
      // Cover probes are keyed by id: drop ids that left the library so the
      // map cannot grow across directory switches.
      const liveIds = new Set(core.state.tracks.map((track) => track.id));
      for (const id of core.coverKnown.keys()) {
        if (!liveIds.has(id)) core.coverKnown.delete(id);
      }
      remapCurrent();
      restoreLastPlayed();
    };
    const remapCurrent = () => {
      if (core.playingId === null) return;
      const nextIndex = core.state.tracks.findIndex((track) => track.id === core.playingId);
      if (nextIndex >= 0) {
        if (nextIndex !== core.state.current) core.set({ current: nextIndex });
        return;
      }
      // The playing track vanished from the library: stop for real, not just UI.
      stopAudio();
      core.set({ current: -1, playing: false, time: 0, duration: 0 });
    };
    const load = async () => {
      core.set({ loading: true, error: null });
      try {
        await api("/api/caps", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify(detectVideoCaps()),
        }).catch(() => { /* 旧宿主没有 /caps：按宿主默认能力走 */ });
        applyLibrary(await api("/api/library"));
      } catch (error) {
        core.set({ error: error instanceof Error ? error.message : String(error) });
      } finally {
        core.set({ loading: false });
      }
    };
    const restoreLastPlayed = () => {
      if (core.lastPlayedRestored || core.state.current >= 0) return;
      const last = loadPrefs().last;
      if (last === undefined || typeof last.id !== "string") {
        // 从未保存过曲目：这次库无论大小都无回补对象，标记完成。
        core.lastPlayedRestored = true;
        return;
      }
      const index = core.state.tracks.findIndex((track) => track.id === last.id);
      // 保存过的曲目不在当前库：先不标记完成，等下一次（换目录/刷新）
      // 载入包含该曲目的库时再回补。
      if (index < 0) return;
      core.lastPlayedRestored = true;
      const track = core.state.tracks[index];
      core.playingId = track.id;
      core.set({
        current: index,
        duration: typeof track.duration === "number" ? track.duration : 0,
        mv: track.kind === "video" ? { id: track.id, state: "checking", progress: 0, mode: null, error: null } : null,
      });
      core.updateMediaSession();
      if (track.kind === "video") {
        // 视频轨：先拿 MV 地址（可能要先转封装），拿到再挂源。
        void prepareVideo(track).then((url) => {
          if (url === null || core.playingId !== track.id) return;
          cueSource(url);          // cue 成暂停态：不调 play，也就不会有 AbortError
        });
        return;
      }
      // 音频：同样要先等媒体直连基址。用一个 IIFE 包住是因为 streamUrl() 是同步的，
      // 而基址可能是这次才去取的——不等就会拼出相对地址，Desktop 上丢了 Range，
      // cue 出来的这首之后一拖进度就回 0 秒（与 MV 同一个根因）。
      void (async () => {
        await ensureStreamBase();
        if (core.playingId !== track.id) return;
        core.audio.src = streamUrl(track);
        if (typeof last.time === "number" && last.time > 0) {
          core.audio.addEventListener("loadedmetadata", () => {
            // The user may have picked another track before metadata landed:
            // the stale resume position must not hijack that track.
            if (core.state.current !== index || core.playingId !== track.id) return;
            if (Number.isFinite(core.audio.duration) && last.time < core.audio.duration - 1) {
              core.audio.currentTime = last.time;
              core.set({ time: last.time });
            }
          }, { once: true });
        }
      })();
    };
    const bindElement = (): boolean => {
      const ctx = core.device.ctx;
      const rg = core.device.rg;
      if (ctx === null || rg === null) return false;
      let head: AudioNode = rg;
      if (core.crossfadeOn) {
        const level = ctx.createGain();
        level.gain.value = 1;
        level.connect(rg);
        core.activeLevelNode = level;
        head = level;
      }
      // 一个媒体元素只能建一次 source；建不上就永久退回元素音量。
      core.activeSource = ctx.createMediaElementSource(core.audio);
      core.activeSource.connect(head);
      return true;
    };
    const targetVolume = () => (core.state.muted ? 0 : core.state.volume);
    const rgForTrack = (track: MusicTrack | undefined): { linear: number; db: number | null } => {
      if (track === undefined || core.state.rgMode === "off") return { linear: 1, db: null };
      const album = core.state.rgMode === "album";
      // 优先级：**标签 > 测量**。同一优先级里 album 优先、缺则回退 track。
      // 测量值只到 track 级（v1 不按专辑合并测量），所以 album 模式的测量兜底就是它。
      const firstFinite = (list: (number | null | undefined)[]): number | undefined =>
        list.find((v): v is number => typeof v === "number" && Number.isFinite(v));
      const rawDb = firstFinite(album
        ? [track.rgAlbumGainDb, track.rgTrackGainDb, track.rgMeasuredGainDb]
        : [track.rgTrackGainDb, track.rgMeasuredGainDb]);
      if (rawDb === undefined) return { linear: 1, db: null };
      const gainDb = Math.max(core.RG_GAIN_MIN_DB, Math.min(core.RG_GAIN_MAX_DB, rawDb));
      const preampDb = Math.max(core.RG_PREAMP_MIN_DB, Math.min(core.RG_PREAMP_MAX_DB, core.state.rgPreampDb));
      const db = gainDb + preampDb;
      let linear = Math.pow(10, db / 20);
      const rawPeak = firstFinite(album
        ? [track.rgAlbumPeak, track.rgTrackPeak, track.rgMeasuredPeak]
        : [track.rgTrackPeak, track.rgMeasuredPeak]);
      if (core.RG_PREVENT_CLIPPING && typeof rawPeak === "number" && Number.isFinite(rawPeak)
        && rawPeak > 0 && rawPeak <= core.RG_PEAK_MAX) {
        linear = Math.min(linear, 1 / rawPeak);
      }
      return { linear, db };
    };
    const nextTrackForPrefetch = (): MusicTrack | null => {
      const rows = visibleRows();
      if (rows.length === 0) return null;
      const pos = rows.findIndex((row) => row.index === core.state.current);
      if (pos < 0) return null;
      const track = core.state.tracks[rows[(pos + 1) % rows.length].index];
      // 只预取音频：MV 走单元素路径（画面要搬进舞台，换元素的代价与风险都不值得）。
      if (track === undefined || track.kind === "video") return null;
      if (core.state.tracks[core.state.current]?.kind === "video") return null;
      return track;
    };
    const scheduleRgPoll = () => {
      if (core.disposed || core.rgPollTimer !== null) return;
      core.rgPollTimer = setTimeout(async () => {
        core.rgPollTimer = null;
        if (core.disposed || !core.state.rgMeasuring) return;
        try {
          const status = await api("/api/measure");
          const running = status?.running === true;
          core.set({
            rgMeasuring: running,
            rgMeasureDone: Number(status?.done) || 0,
            rgMeasureTotal: Number(status?.total) || 0,
          });
          if (running) {
            scheduleRgPoll();
          } else {
            // 测完刷新一次库：测量值随 payload 下发，客户端据此生效。
            applyLibrary(await api("/api/library"));
          }
        } catch {
          if (!core.disposed) core.set({ rgMeasuring: false });
        }
      }, 1200);
    };
    const cueSource = (url) => {
      logAttach(url);
      // cue 是暂停态：直接把瞬时音量归零，等用户按播放时由 toggle 淡入。
      core.cancelFade();
      core.applyVolume(0);
      core.audio.src = url;
    };
    const prepareVideo = async (track, forcedMode?: string, retry = false) => {
      // ⚠️ 必须先拿到媒体直连基址再拼 URL。mvCacheUrl() 在基址为空时会退回**相对**
      // 地址 `/api/dsh-music/mvfile?k=…`，而 Desktop 上相对地址要经 Electron
      // forwardWebRequest —— **那条路会丢 Range/206**，于是 <video> 认为流不可 seek，
      // 症状就是「MV 进度条一拖就从头开始播」。
      // 放在这里而不是每个调用点：5 个调用点里有 4 个不会自己 await
      // （restoreLastPlayed、两处 error→转码升级、手动转换）。
      await ensureStreamBase();
      for (let round = 0; round < 900; round += 1) {
        if (core.playingId !== track.id) return null;
        let payload;
        try {
          payload = await api("/api/mv?id=" + encodeURIComponent(track.id)
            + (typeof forcedMode === "string" ? "&mode=" + forcedMode : "")
            + (retry && round === 0 ? "&retry=1" : ""));
        } catch (error) {
          // 与原来 `String(error?.message ?? error)` 逐字等价：catch 变量在
          // useUnknownInCatchVariables 下是 unknown，用 typeof / in 收窄后取同一个值。
          const detail = error !== null && (typeof error === "object" || typeof error === "function") && "message" in error
            ? (error.message ?? error) : error;
          core.set({ mv: { id: track.id, state: "failed", progress: 0, mode: null, error: String(detail) } });
          return null;
        }
        if (core.playingId !== track.id) return null;
        if (payload.state === "ready") {
          core.set({ mv: { id: track.id, state: "ready", progress: 1, mode: payload.mode ?? null, error: null } });
          // 有 key 就自己拼（Desktop 下用 token 直连，保住 Range）。
          if (typeof payload.key === "string") return mvCacheUrl(payload.key);
          // direct：宿主给的 url 是**相对**地址（`/api/dsh-music/stream?p=…`）。相对地址在
          // Desktop 上经转发会丢 Range（I-02），所以这里自己拼 streamUrl（有 token 基址时
          // 就是绝对地址，没有才退回相对）。
          if (payload.mode === "direct") return streamUrl(track);
          if (typeof payload.url === "string") return payload.url;
        }
        if (payload.state === "failed") {
          core.set({ mv: { id: track.id, state: "failed", progress: 0, mode: payload.mode ?? null, error: payload.error ?? null } });
          return null;
        }
        core.set({ mv: { id: track.id, state: "preparing", progress: typeof payload.progress === "number" ? payload.progress : 0, mode: payload.mode ?? null, error: null } });
        await new Promise((resolve) => setTimeout(resolve, 700));
      }
      return null;
    };
    const stopWasmVideo = () => {
      if (core.wasmAbort !== null) core.wasmAbort.aborted = true;
      core.wasmAbort = null;
    };
    const wasmAudioPlayable = (track: MusicTrack): boolean =>
      track.audioCodec === null || track.audioCodec === undefined || core.MV_DIRECT_AUDIO.has(track.audioCodec);
    const startWasmVideo = async (track, stage) => {
      if (typeof document === "undefined" || stage === null || stage === undefined) return false;
      try {
        const libavUrl = endpointBase + "/mvlib?f=" + encodeURIComponent("@libav.js/variant-webcodecs/dist/libav-6.10.9.0-webcodecs.mjs");
        const polyUrl = endpointBase + "/mvlib?f=" + encodeURIComponent("libavjs-webcodecs-polyfill/dist/libavjs-webcodecs-polyfill.min.mjs");
        const mbUrl = endpointBase + "/mvlib?f=" + encodeURIComponent("mediabunny/dist/bundles/mediabunny.min.mjs");
        const [libav, polyfill, mediabunny] = await Promise.all([import(libavUrl), import(polyUrl), import(mbUrl)]);
        // 这个包的 ESM 导出是具名 load（不是 README 里那个 LibAVWebCodecs.load）
        const loadPolyfill = polyfill.load ?? polyfill.LibAVWebCodecs?.load;
        if (typeof loadPolyfill !== "function") return false;
        await loadPolyfill.call(polyfill, { polyfill: true, libavOptions: { LibAV: libav.LibAV ?? libav.default ?? libav } });
        const buffer = await (await fetch(streamUrl(track))).arrayBuffer();
        const input = new mediabunny.Input({ source: new mediabunny.BlobSource(new Blob([buffer])), formats: mediabunny.ALL_FORMATS });
        const videoTrack = await input.getPrimaryVideoTrack();
        if (videoTrack === null || videoTrack === undefined) return false;
        const sink = new mediabunny.CanvasSink(videoTrack, { width: 1280 });
        const canvas = document.createElement("canvas");
        canvas.className = "dshm-mvCanvas";
        stage.querySelector(".dshm-mvCanvas")?.remove();
        stage.appendChild(canvas);
        // 这块 canvas 是上面刚 createElement 出来的、且从未请求过别的上下文，
        // 所以 "2d" 上下文必然拿得到（getContext 只在类型不支持或已请求过其它
        // 类型时返回 null）；非空断言因此可证，也没有改变任何失败路径的行为
        // （原来的实现同样不做判空，只在拿不到时于绘制处抛错并静默停住画面）。
        const ctx = canvas.getContext("2d")!;
        const token = { aborted: false };
        core.wasmAbort = token;
        void (async () => {
          for await (const frame of sink.canvases()) {
            if (token.aborted || core.playingId !== track.id) return;
            // 跟音频时钟对齐：画面快了就等，慢了就丢帧（丢帧比卡顿好看）
            const at = typeof frame.timestamp === "number" ? frame.timestamp / 1e6 : 0;
            const drift = at - (Number.isFinite(core.audio.currentTime) ? core.audio.currentTime : 0);
            if (drift > 0.15) await new Promise((r) => setTimeout(r, Math.min(200, drift * 500)));
            if (drift < -0.4) continue;
            canvas.width = frame.canvas.width;
            canvas.height = frame.canvas.height;
            ctx.drawImage(frame.canvas, 0, 0);
          }
        })().catch(() => { /* 解到一半失败：画面停住，不影响音频 */ });
        return true;
      } catch {
        stopWasmVideo();
        return false;
      }
    };
    const cacheWavePeaks = (id: string, peaks: number[]) => {
      core.wavePeaksCache.delete(id);
      core.wavePeaksCache.set(id, peaks);
      while (core.wavePeaksCache.size > core.WAVE_PEAKS_CACHE_MAX) {
        core.wavePeaksCache.delete(core.wavePeaksCache.keys().next().value as string);
      }
    };
    const prefetchWaveform = async (track: MusicTrack) => {
      if (core.disposed || core.wavePeaksCache.has(track.id)) return;
      try {
        const result = await api("/api/waveform?p=" + encodeURIComponent(track.id));
        if (core.disposed) return;
        const peaks = (Array.isArray(result?.peaks) ? result.peaks : [])
          .filter((v) => typeof v === "number" && Number.isFinite(v));
        if (peaks.length > 0) cacheWavePeaks(track.id, peaks);
      } catch {
        // 预取失败无所谓：真正切到那首时会再请求一次（不报错、不重试风暴）。
      }
    };
    const loadWaveform = async (track: MusicTrack) => {
      if (core.state.waveTrackId === track.id && core.state.wavePeaks !== null) return;
      const cached = core.wavePeaksCache.get(track.id);
      if (cached !== undefined) {
        // 命中缓存（多是预取来的）：**同步**出图，切歌时看不到空白期。
        core.set({ wavePeaks: cached, waveTrackId: track.id });
        return;
      }
      core.set({ wavePeaks: null, waveTrackId: track.id });
      try {
        const result = await api("/api/waveform?p=" + encodeURIComponent(track.id));
        // 快速连切时回来的是**上一首**的结果，必须丢弃 —— 否则波形与正在播的歌对不上。
        if (core.state.waveTrackId !== track.id) return;
        const raw = Array.isArray(result?.peaks) ? result.peaks : [];
        const peaks = raw.filter((v) => typeof v === "number" && Number.isFinite(v));
        if (peaks.length > 0) cacheWavePeaks(track.id, peaks);
        core.set({ wavePeaks: peaks.length > 0 ? peaks : null });
      } catch {
        core.set({ wavePeaks: null });
      }
    };
    const playIndex = (index) => {
      const track = core.state.tracks[index];
      if (track === undefined) return;
      // 手动切歌 vs 曲末自动接下一首：fooyin 给后者更长的过渡（700ms vs 300ms）。
      const auto = core.advanceIsAuto;
      core.advanceIsAuto = false;
      core.changeFadeOutMs = auto ? core.FADE_AUTO_OUT_MS : core.FADE_CHANGE_OUT_MS;
      core.changeFadeInMs = auto ? core.FADE_AUTO_IN_MS : core.FADE_CHANGE_IN_MS;
      core.resumeAttempts = 0;
      core.skipAttempts = 0;
      core.lastFailureAt = 0;
      core.playingId = track.id;
      stopWasmVideo();   // 换曲：停掉上一条的 WASM 解码循环
      // 手动重新播这一首时给升级一次新机会：升级标记只防「一次播放里失败→升级→再失败」
      // 的死循环，不是「这一首永久只能直出」。不清它，失败过一次的歌就再也升不了级
      // （症状：回去再播还是没声音，只有刷新页面才好）。
      if (track.kind === "video") core.mvEscalated.delete(track.id);
      core.set({
        current: index,
        time: 0,
        duration: typeof track.duration === "number" ? track.duration : 0,
        mv: track.kind === "video" ? { id: track.id, state: "checking", progress: 0, mode: null, error: null } : null,
      });
      savePrefs({ last: { id: track.id, time: 0 } });
      void loadWaveform(track);
      core.updateMediaSession();
      if (track.kind === "video") {
        void (async () => {
          await ensureStreamBase();   // 先拿到媒体直连基址（拖不动进度就是它没拿到）
          // 1) 浏览器没有这个解码器 → 先试 WASM 旁路（不碰文件、不用等转码）。
          // 前提是**音轨元素自己能解**：WASM 只补画面，音轨解不了就是有画面没声音。
          if (core.WASM_CODECS.has(track.videoCodec ?? "") && wasmAudioPlayable(track)) {
            await new Promise((resolve) => setTimeout(resolve, 30));   // 等 React 把画面槽渲染出来
            const stage = typeof document === "undefined" ? null : document.querySelector(".dshm-mvStage");
            const ok = await startWasmVideo(track, stage);
            if (ok && core.playingId === track.id) {
              core.attachSource(streamUrl(track));     // 音频照旧走 /stream
              core.set({ mv: { id: track.id, state: "ready", progress: 1, mode: "wasm", error: null } });
              guardAudioTrack(track);             // 画面由 WASM 出，音轨仍归元素：它没解出来就是没声
              return;
            }
          }
          // 2) 退回只读缓存转码（同样不改用户文件）
          const url = await prepareVideo(track);
          if (url === null || core.playingId !== track.id) return;
          core.attachSource(url);
          guardVideoPicture(track);
          guardAudioTrack(track);
        })();
        return;
      }
      // 音频：先等媒体直连基址再挂源（拿不到就退回相对地址，播放不受影响）。
      void (async () => {
        await ensureStreamBase();
        if (core.playingId !== track.id) return;
        core.attachSource(streamUrl(track));
      })();
      return;
    };
    const effective = (track) => {
      if (track === undefined) return undefined;
      const meta = core.state.meta[track.id];
      if (meta === undefined) return track;
      return {
        ...track,
        title: typeof meta.title === "string" && meta.title.length > 0 ? meta.title : track.title,
        artist: typeof meta.artist === "string" && meta.artist.length > 0 ? meta.artist : track.artist,
        album: typeof meta.album === "string" && meta.album.length > 0 ? meta.album : undefined,
      };
    };
    const coverFor = (track) => {
      const meta = track === undefined ? undefined : core.state.meta[track.id];
      if (meta !== undefined && typeof meta.cover === "string" && meta.cover.length > 0) return artUrl(meta.cover);
      return coverUrl(track === undefined ? "" : track.id);
    };
    const visibleRows = () => {
      const cache = core.rowsCache;
      if (cache !== null && cache.tracks === core.state.tracks && cache.query === core.state.query
        && cache.sortKey === core.state.sortKey && cache.sortDir === core.state.sortDir
        && cache.section === core.state.section && cache.mediaFilter === core.state.mediaFilter && cache.favorites === core.state.favorites
        && cache.meta === core.state.meta) {
        return cache.rows;
      }
      const query = core.state.query.trim().toLowerCase();
      const section = core.state.section;
      const media = core.state.mediaFilter;
      const favorites = core.state.favorites;
      const inView = (track) => (section !== "favorites" || favorites.has(track.id))
        && (media === "all"
          || (media === "audio" && track.kind !== "video")
          || (media === "video" && track.kind === "video"));
      let rows: TrackRow[] = [];
      for (let index = 0; index < core.state.tracks.length; index += 1) {
        const track = core.state.tracks[index];
        if (!inView(track)) continue;
        const item = effective(track);
        if (query.length > 0) {
          const haystack = (item.title + " " + (item.artist ?? "") + " " + track.name).toLowerCase();
          if (!haystack.includes(query)) continue;
        }
        rows.push({ track, index });
      }
      if (core.state.sortKey !== "none") {
        rows = [...rows].sort((a, b) => {
          const dir = core.state.sortDir === "asc" ? 1 : -1;
          const valueOf = (track) => core.state.sortKey === "added" ? track.addedAt : effective(track)[core.state.sortKey];
          const va = valueOf(a.track);
          const vb = valueOf(b.track);
          if (va == null && vb == null) return a.index - b.index;
          if (va == null) return 1;
          if (vb == null) return -1;
          const order = typeof va === "number" && typeof vb === "number"
            ? va - vb
            : String(va).localeCompare(String(vb), "zh-Hans-CN", { numeric: true, sensitivity: "base" });
          return dir * (order || (a.index - b.index));
        });
      }
      core.rowsCache = { tracks: core.state.tracks, query: core.state.query, sortKey: core.state.sortKey, sortDir: core.state.sortDir, section: core.state.section, mediaFilter: core.state.mediaFilter, favorites: core.state.favorites, meta: core.state.meta, rows };
      return rows;
    };
    const next = () => {
      const rows = visibleRows();
      if (rows.length === 0) return;
      // 当前曲目不在可见列表里（被筛选掉）时，从第一行开始。
      const pos = rows.findIndex((row) => row.index === core.state.current);
      playIndex(rows[(pos + 1) % rows.length].index);
    };
    const prev = () => {
      const rows = visibleRows();
      if (rows.length === 0) return;
      // macOS Music behavior: beyond 3s into the song, "previous" restarts it.
      if (core.audio.currentTime > 3 && core.state.current >= 0) {
        core.audio.currentTime = 0;
        return;
      }
      const pos = rows.findIndex((row) => row.index === core.state.current);
      playIndex(rows[pos <= 0 ? rows.length - 1 : pos - 1].index);
    };
    const onTimeupdate = (el: HTMLVideoElement) => {
      if (el !== core.audio || core.state.current < 0) return;
      const live = core.audio.currentTime;
      // Playback moved 5s past the last failure: that failure is behind us,
      // so a later, independent bad spot gets its own retry budget again.
      if (core.lastFailureAt > 0 && live > core.lastFailureAt + 5) {
        core.resumeAttempts = 0;
        core.skipAttempts = 0;
        core.lastFailureAt = 0;
      }
      const liveDuration = Number.isFinite(core.audio.duration) && core.audio.duration > 0 ? core.audio.duration : core.state.duration;
      // The progress bar follows the audio clock itself (rAF), so publishing
      // every ~4Hz timeupdate would only re-render the track list: publish on
      // the whole second, or immediately when the duration finally arrives.
      if (liveDuration !== core.state.duration || Math.floor(live) !== Math.floor(core.state.time)) {
        core.set({ time: live, duration: liveDuration });
        // 同一处节流（≈1Hz）顺手把进度推给系统 Now Playing 的进度条。
        core.updatePositionState();
      }
      savePosition(false);
    };
    const coverUrl = (id) => endpointBase + "/cover?p=" + encodeURIComponent(id) + "&v=" + (core.state.scannedAt ?? 0);
    const onPlay = (el: HTMLVideoElement) => {
      if (el !== core.audio) return;
      core.errorStreak = 0;
      core.set({ playing: true, error: null });
      core.updateMediaSession();
    };
    const onPause = (el: HTMLVideoElement) => {
      if (el !== core.audio) return;
      core.set({ playing: false });
      savePosition(true);
      core.updateMediaSession();
    };
    const onPageHide = () => { savePosition(true); };
    window.addEventListener("pagehide", onPageHide);
    const onEnded = (el: HTMLVideoElement) => {
      if (el !== core.audio) return;
      if (core.state.mode === "one") {
        core.audio.currentTime = 0;
        const promise = core.audio.play();
        if (promise !== undefined) promise.catch(() => {});
      } else {
        core.advanceIsAuto = true;   // 曲末自动接下一首：用更长的过渡（fooyin autoChange）
        next();
      }
    };
    const onLoadedMetadata = (el: HTMLVideoElement) => {
      if (el !== core.audio) return;
      scheduleUnseekableHeal();
    };
    const onWaiting = (el: HTMLVideoElement) => {
      if (el !== core.audio || !core.state.playing) return;
      core.set({ buffering: true });
    };
    const onResumed = (el: HTMLVideoElement) => {
      if (el !== core.audio) return;
      core.set({ buffering: false });
    };
    const recoverAt = (failedTrack, failedIndex, target, delay) => {
      setTimeout(() => {
        if (core.state.current !== failedIndex || core.playingId !== failedTrack.id) return;
        // 必须**先等基址**：不等就会拼出相对地址，Desktop 上丢了 Range ⇒ 之后一拖就回 0
        // （§2.16「降级成不可 seek 的源比等待更糟」）。
        void (async () => {
          await ensureStreamBase();
          if (core.disposed || core.state.current !== failedIndex || core.playingId !== failedTrack.id) return;
          core.audio.src = streamUrl(failedTrack);
          core.audio.addEventListener("loadedmetadata", () => {
            if (core.state.current !== failedIndex || core.playingId !== failedTrack.id) return;
            if (Number.isFinite(core.audio.duration)) {
              core.audio.currentTime = Math.min(target, Math.max(0, core.audio.duration - 1));
            }
          }, { once: true });
          const promise = core.audio.play();
          if (promise !== undefined) promise.catch(() => {});
        })();
      }, delay);
    };
    const escalateToTranscode = (track) => {
      if (core.mvEscalated.has(track.id)) return;
      core.mvEscalated.add(track.id);
      core.set({ mv: { id: track.id, state: "preparing", progress: 0, mode: "transcode", error: null } });
      void prepareVideo(track, "transcode").then((url) => {
        if (url === null || core.playingId !== track.id) return;
        core.attachSource(url);
      });
    };
    const guardVideoPicture = (track) => {
      setTimeout(() => {
        if (core.playingId !== track.id) return;
        const current = core.state.tracks[core.state.current];
        if (current === undefined || current.kind !== "video") return;
        if (Number(core.audio.videoWidth ?? 1) > 0 || core.audio.readyState < 2) return;
        escalateToTranscode(track);
      }, 2000);
    };
    const guardAudioTrack = (track) => {
      if (track.audioCodec === null || track.audioCodec === undefined) return;
      setTimeout(() => {
        if (core.playingId !== track.id) return;
        const decoded = (core.audio as unknown as { webkitAudioDecodedByteCount?: number }).webkitAudioDecodedByteCount;
        if (typeof decoded !== "number" || decoded > 0) return;
        if (core.audio.paused !== false || core.audio.readyState < 2) return;
        escalateToTranscode(track);
      }, 3500);
    };
    const onError = (el: HTMLVideoElement) => {
      if (el !== core.audio || core.state.current < 0) return;
      core.set({ buffering: false });
      // ① 优先自愈「token 基址失效」：宿主热重载会换 token（已改为进程级，但历史
      //    快照仍可能过期），而**音频永远走 system-stream token 直连** —— 一旦失效
      //    就是「音乐全不能播、MV 照播（/api/mv 返相对地址）」。丢掉缓存，让下面
      //    的重试路径重新取一次 /session，用新基址重挂。
      const failedSrc = typeof core.audio.currentSrc === "string" ? core.audio.currentSrc : "";
      if (failedSrc.includes("system-stream") && !sessionBaseHealed) {
        sessionBaseHealed = true;
        invalidateSessionBase();
        // 立刻用新基址重放本曲（而不是让它退化成「跳过一首」）：
        // ensureStreamBase 会重新取 /session，streamUrl 于是拿到新 token。
        const retryTrack = core.state.tracks[core.state.current];
        if (retryTrack !== undefined) {
          void (async () => {
            await ensureStreamBase();
            if (core.playingId !== retryTrack.id) return;
            core.attachSource(streamUrl(retryTrack));
          })();
          return;
        }
      }
      // 错误分类（借鉴 Feishin 的 MediaError 分派）：`MEDIA_ERR_SRC_NOT_SUPPORTED (4)` 意味着
      // **格式/源根本不可用** —— 原位置重试与「跳过坏区」都救不了它，直接走「放弃 + 自动下一首」，
      // 省掉 1 次重试 + 2 次跳区（每次 400ms，还会放出一段垃圾声）。
      // `MEDIA_ERR_DECODE (3)` 保持现有策略（跳坏区对**局部**坏帧是对的）；`NETWORK (2)` 走重试。
      const mediaErrorCode = typeof core.audio.error?.code === "number" ? core.audio.error.code : 0;
      const hopelessSource = mediaErrorCode === 4;
      const failedIndex = core.state.current;
      const failedTrack = core.state.tracks[failedIndex];
      // MV 直出失败（容器解不了 / 该构建没有这个解码器）：升级成 ffmpeg 转码再试一次。
      if (failedTrack !== undefined && failedTrack.kind === "video" && !core.mvEscalated.has(failedTrack.id)) {
        core.mvEscalated.add(failedTrack.id);
        core.set({ mv: { id: failedTrack.id, state: "preparing", progress: 0, mode: "transcode", error: null } });
        void prepareVideo(failedTrack, "transcode").then((url) => {
          if (url === null || core.playingId !== failedTrack.id) return;
          core.attachSource(url);
        });
        return;
      }
      const resumeAt = Number.isFinite(core.audio.currentTime) ? core.audio.currentTime : 0;
      core.errorStreak += 1;
      const knownDuration = Number.isFinite(core.audio.duration) && core.audio.duration > 0 ? core.audio.duration : core.state.duration;
      // 1) 流中途被切断（宿主 requestTimeout 截断长连接、瞬时网络错误等）：
      //    原位置重试一次，恢复后 timeupdate 会把预算清零。
      const mayRetrySame = !hopelessSource && failedTrack !== undefined && resumeAt > 0 && core.resumeAttempts < 1
        && (!Number.isFinite(core.audio.duration) || resumeAt < core.audio.duration - 2);
      if (mayRetrySame) {
        core.resumeAttempts += 1;
        core.lastFailureAt = resumeAt;
        recoverAt(failedTrack, failedIndex, resumeAt, 400);
        return;
      }
      // 2) 同一位置再次失败 = 文件局部坏帧（坏源/下载损坏）：
      //    向前跳过坏区继续播放，而不是让几 KB 垃圾废掉整首歌。
      const jump = hopelessSource ? undefined : core.FAILURE_JUMPS[core.skipAttempts];
      if (failedTrack !== undefined && resumeAt > 0 && jump !== undefined
        && (knownDuration === 0 || resumeAt + jump < knownDuration - 1)) {
        const target = resumeAt + jump;
        core.skipAttempts += 1;
        core.lastFailureAt = target;
        core.set({ time: target });
        recoverAt(failedTrack, failedIndex, target, 400);
        return;
      }
      // 3) 放弃本曲：提示 + 列表循环下自动跳下一首（每一行都失败后停手）。
      core.set({ playing: false, error: translate("error.unsupported") });
      const rowCount = visibleRows().length;
      if (core.state.mode === "loop" && rowCount > 1 && core.errorStreak < rowCount) {
        setTimeout(() => {
          if (core.state.error !== null && core.state.current === failedIndex && !core.state.playing) next();
        }, 600);
      }
    };
      return { stopAudio, mvCacheUrl, hasStreamBase, ensureStreamBase, streamUrl, mediaSrcKind, redactSrc, logSeek, healUnseekableSource, scheduleUnseekableHeal, logAttach, seekAudio, savePosition, schedulePoll, applyLibrary, remapCurrent, load, restoreLastPlayed, bindElement, targetVolume, rgForTrack, nextTrackForPrefetch, scheduleRgPoll, cueSource, prepareVideo, stopWasmVideo, wasmAudioPlayable, startWasmVideo, cacheWavePeaks, prefetchWaveform, loadWaveform, playIndex, effective, coverFor, visibleRows, next, prev, onTimeupdate, coverUrl, onPlay, onPause, onPageHide, onEnded, onLoadedMetadata, onWaiting, onResumed, recoverAt, escalateToTranscode, guardVideoPicture, guardAudioTrack, onError };
    }

    function createPlayer() {
      /**
       * 媒体元素用 <video>：音频文件本来就能播，MV 才有画面可显示（一个元素搞定两种媒体，
       * 进度/seek/MediaSession 全部共用一条路径）。
       * jsdom 没有媒体实现 —— 测试套件通过 window.__dshMusicMedia 注入假元素。
       */
      // ⚠️ 必须是 `let`：交叉淡化要**交换两个元素的角色**，而下面 90+ 处引用都读这个名字。
      let audio = typeof window.__dshMusicMedia === "function"
        ? window.__dshMusicMedia()
        : document.createElement("video");

      /**
       * 给媒体元素装契约监听器。交叉淡化会**交换**活动元素（`audio = inEl`），两个元素都要装；
       * 只装初始元素时，交换后新元素没有任何事件（曲末不续播、流错误不恢复、进度不落盘）。
       * 真实实现定义在后段（它引用的闭包都在那边），这里先占位，供空闲元素创建时调用。
       */
      let bindMedia: (el: HTMLVideoElement) => void = () => {};
      /** 暂停代际：淡出/换源途中按下的暂停，必须让在飞的 `startNow()` 作废。 */
      let pauseEpoch = 0;
      audio.preload = "auto";
      audio.className = "dshm-mv";
      // 假元素（测试）没有 setAttribute，这里全部可选调用。
      audio.setAttribute?.("playsinline", "");
      audio.setAttribute?.("webkit-playsinline", "");
      /**
       * 媒体元素的停靠位挂在 document.body 上，**不挂在 React 树里**：
       * 切回对话会让插件视图卸载，元素若在 React 树里就会被移出文档，而 HTML 规范
       * 对「媒体元素离开文档」的处理就是暂停 —— 这正是 MV 切走就停的原因。
       */
      let mediaPark: HTMLDivElement | null = null;
      if (typeof audio.nodeType === "number" && typeof document !== "undefined" && document.body !== null) {
        mediaPark = document.createElement("div");
        mediaPark.className = "dshm-mvPark";
        mediaPark.setAttribute("aria-hidden", "true");
        document.body.appendChild(mediaPark);
        mediaPark.appendChild(audio);
      }
      /**
       * ReplayGain（响度归一化）。做法与 fooyin 一致：**只读标准标签、不改文件**；
       * 未测量过的曲目**不做任何增益**（不是当 0dB 用）。
       * 增益走**独立节点**，与用户音量串成 `source → rgGain → volumeGain → destination` ——
       * 这样淡入淡出（写音量节点）与响度归一化（写 RG 节点）互不覆盖。
       */
      const RG_PREAMP_MIN_DB = -15;
      const RG_PREAMP_MAX_DB = 15;
      /** 标签来自文件，可能荒谬：夹住范围（不可信输入）。 */
      const RG_GAIN_MIN_DB = -40;
      const RG_GAIN_MAX_DB = 40;
      /** 峰值只用于**收窄**增益；超过这个数当标签损坏，不用它。 */
      const RG_PEAK_MAX = 4;
      /** 防削波（fooyin 的 PreventClipping）：默认**恒开**。增益可能把峰值推过满刻度。 */
      const RG_PREVENT_CLIPPING = true;

      const prefs = loadPrefs();
      let state: PlayerState = {
        dir: null,
        tracks: [],
        scannedAt: null,
        loading: false,
        picking: false,
        scanning: false,
        /**
         * 宿主入口：`api`（经连接层 /api 栅栏 + 会话）或 `legacy`（降级到插件
         * 自建的 /dsh-music 前缀）。降级是信任模型降级，必须让用户看得见。
         */
        hostEntry: "api",
        /** MV 准备状态：null（非视频）| { id, state, progress, mode, error }。 */
        mv: null,
        /** 补全时顺带转格式：成功后是否把原件丢进废纸篓（默认否，只并存）。 */
        convertDeleteOriginal: false,
        scanParsed: 0,
        scanTotal: 0,
        truncated: false,
        /** 扫描时跳过的 DRM 加密包（.movpkg）数量。 */
        skippedPackages: 0,
        error: null,
        current: -1,
        playing: false,
        muted: false,
        buffering: false,
        mode: prefs.mode === "one" ? "one" : "loop",
        time: 0,
        duration: 0,
        volume: typeof prefs.volume === "number" && prefs.volume >= 0 && prefs.volume <= 1 ? prefs.volume : 1,
        // 默认 off：归一化会改变用户听到的响度，必须由用户显式打开。
        rgMode: prefs.rgMode === "track" || prefs.rgMode === "album" ? prefs.rgMode : "off",
        rgPreampDb: typeof prefs.rgPreampDb === "number" && Number.isFinite(prefs.rgPreampDb)
          ? Math.max(RG_PREAMP_MIN_DB, Math.min(RG_PREAMP_MAX_DB, prefs.rgPreampDb))
          : 0,
        rgTrackDb: null,
        rgMeasuring: false,
        rgMeasureDone: 0,
        rgMeasureTotal: 0,
        // 均衡器默认 flat（不动音色）—— 用户没要求就不要偷偷改声音。
        wavePeaks: null,
        waveTrackId: null,
        eqPreset: typeof prefs.eqPreset === "string" && EQ_PRESETS[prefs.eqPreset] !== undefined ? prefs.eqPreset : "flat",
        eqBands:
          Array.isArray(prefs.eqBands) && prefs.eqBands.length === EQ_BANDS.length
            ? prefs.eqBands.map((v) => (typeof v === "number" && Number.isFinite(v)
              ? Math.max(EQ_GAIN_MIN_DB, Math.min(EQ_GAIN_MAX_DB, v)) : 0))
            : EQ_PRESETS.flat.slice(),
        query: "",
        /** 在线补全结果：id → { title?, artist?, album?, cover? }。 */
        meta: loadMeta(),
        /** 补全弹层：null = 关闭，否则 { id, loading, error, candidates }。 */
        match: null,
        /** 一键补全：确认条 + 批处理进度。 */
        pendingComplete: false,
        completeOverwriteCover: false,
        completing: false,
        completeTotal: 0,
        completeDone: 0,
        completeFailed: 0,
        completeSkipped: 0,
        sortKey: typeof prefs.sortKey === "string" && ["title", "artist", "duration", "added"].includes(prefs.sortKey)
          ? prefs.sortKey : "none",
        sortDir: prefs.sortDir === "desc" ? "desc" : "asc",
        section: loadSection(),
        mediaFilter: loadMediaFilter(),
        sidebarOpen: loadSidebarOpen(),
        favorites: loadFavorites(),
        /** 待确认删除的曲目下标（-1 = 无）。替代 window.confirm 的应用内确认。 */
        pendingDelete: -1,
        /**
         * 全屏播放器弹层 + 两个子态（MV 放大 / 封面预览）都放在 player store 里：
         * 视图会在切到对话时卸载，局部 useState 会一起丢（见 PlayerState 注释）。
         */
        playerPhase: "closed",
        mvBig: false,
        zoomOpen: false,
      };
      audio.volume = state.volume;
      const listeners = new Set<() => void>();
      const emit = () => {
        for (const listener of listeners) listener();
      };
      // 入口降级 → 落到状态里，由视图渲染成一条可见提示（不静默）。
    onDowngrade = () => set({ hostEntry: "legacy" });
    const set = (patch: Partial<PlayerState>) => {
        state = { ...state, ...patch };
        emit();
      };
      /** Consecutive decode failures; auto-skip stops once every track failed. */
      let errorStreak = 0;
      /** 单调递增的补全请求序号：同一曲目手动重查时，旧响应不得覆盖新结果。 */
      let matchSeq = 0;
      /** Same-position retries after a mid-playback stream cut (one per failure site). */
      let resumeAttempts = 0;
      /** Forward jumps spent stepping over a locally damaged region (per failure site). */
      let skipAttempts = 0;
      /** Playback position of the last handled failure; cleared once we pass it. */
      let lastFailureAt = 0;
      /**
       * Forward-jump sizes tried in order when a failure repeats at the same
       * spot. A file with a few corrupt frames (bad rip / interrupted download)
       * must not cost the whole track: step over the damage and keep playing.
       */
      const FAILURE_JUMPS = [1.5, 6];
      /**
       * Stable id of the track currently loaded into <audio>, independent of
       * its array index. A rescan can reorder/insert rows; re-mapping by id is
       * the only way the highlighted row keeps matching what is playing.
       */
      let playingId: string | null = null;

      /** Stop playback and detach the stream (used before library replacement). */
      /**
       * 停止播放并断开流。**刻意不等渐变**：调用方含 halt()/卸载路径，必须立刻断开
       * （§2.10）。先把瞬时音量落到 0 再 pause，至少不是「满幅被掐断」。
       * 有停止按钮的交互式停止会走 toggle 的暂停路径（那条有淡出）。
       */
      const runtimeCore = {
        get FADE_AUTO_IN_MS() { return FADE_AUTO_IN_MS; },
        get FADE_AUTO_OUT_MS() { return FADE_AUTO_OUT_MS; },
        get FADE_CHANGE_IN_MS() { return FADE_CHANGE_IN_MS; },
        get FADE_CHANGE_OUT_MS() { return FADE_CHANGE_OUT_MS; },
        get FAILURE_JUMPS() { return FAILURE_JUMPS; },
        get MV_DIRECT_AUDIO() { return MV_DIRECT_AUDIO; },
        get RG_GAIN_MAX_DB() { return RG_GAIN_MAX_DB; },
        get RG_GAIN_MIN_DB() { return RG_GAIN_MIN_DB; },
        get RG_PEAK_MAX() { return RG_PEAK_MAX; },
        get RG_PREAMP_MAX_DB() { return RG_PREAMP_MAX_DB; },
        get RG_PREAMP_MIN_DB() { return RG_PREAMP_MIN_DB; },
        get RG_PREVENT_CLIPPING() { return RG_PREVENT_CLIPPING; },
        get UNSEEKABLE_HEAL_WINDOW_MS() { return UNSEEKABLE_HEAL_WINDOW_MS; },
        get WASM_CODECS() { return WASM_CODECS; },
        get WAVE_PEAKS_CACHE_MAX() { return WAVE_PEAKS_CACHE_MAX; },
        get activeLevelNode() { return activeLevelNode; },
        set activeLevelNode(value) { activeLevelNode = value; },
        get activeSource() { return activeSource; },
        set activeSource(value) { activeSource = value; },
        get advanceIsAuto() { return advanceIsAuto; },
        set advanceIsAuto(value) { advanceIsAuto = value; },
        get applyVolume() { return applyVolume; },
        get attachSource() { return attachSource; },
        get audio() { return audio; },
        set audio(value) { audio = value; },
        get cancelFade() { return cancelFade; },
        get changeFadeInMs() { return changeFadeInMs; },
        set changeFadeInMs(value) { changeFadeInMs = value; },
        get changeFadeOutMs() { return changeFadeOutMs; },
        set changeFadeOutMs(value) { changeFadeOutMs = value; },
        get coverKnown() { return coverKnown; },
        get crossfadeOn() { return crossfadeOn; },
        get device() { return device; },
        get disposed() { return disposed; },
        set disposed(value) { disposed = value; },
        get errorStreak() { return errorStreak; },
        set errorStreak(value) { errorStreak = value; },
        get idleEl() { return idleEl; },
        set idleEl(value) { idleEl = value; },
        get lastFailureAt() { return lastFailureAt; },
        set lastFailureAt(value) { lastFailureAt = value; },
        get lastPlayedRestored() { return lastPlayedRestored; },
        set lastPlayedRestored(value) { lastPlayedRestored = value; },
        get lastSavedAt() { return lastSavedAt; },
        set lastSavedAt(value) { lastSavedAt = value; },
        get mvEscalated() { return mvEscalated; },
        get pauseEpoch() { return pauseEpoch; },
        set pauseEpoch(value) { pauseEpoch = value; },
        get playingId() { return playingId; },
        set playingId(value) { playingId = value; },
        get pollTimer() { return pollTimer; },
        set pollTimer(value) { pollTimer = value; },
        get resumeAttempts() { return resumeAttempts; },
        set resumeAttempts(value) { resumeAttempts = value; },
        get rgPollTimer() { return rgPollTimer; },
        set rgPollTimer(value) { rgPollTimer = value; },
        get rowsCache() { return rowsCache; },
        set rowsCache(value) { rowsCache = value; },
        get set() { return set; },
        get skipAttempts() { return skipAttempts; },
        set skipAttempts(value) { skipAttempts = value; },
        get state() { return state; },
        set state(value) { state = value; },
        get unseekableHealDeadline() { return unseekableHealDeadline; },
        set unseekableHealDeadline(value) { unseekableHealDeadline = value; },
        get unseekableSrc() { return unseekableSrc; },
        set unseekableSrc(value) { unseekableSrc = value; },
        get unseekableTimer() { return unseekableTimer; },
        set unseekableTimer(value) { unseekableTimer = value; },
        get updateMediaSession() { return updateMediaSession; },
        get updatePositionState() { return updatePositionState; },
        get wasmAbort() { return wasmAbort; },
        set wasmAbort(value) { wasmAbort = value; },
        get wavePeaksCache() { return wavePeaksCache; },
      };
      const runtime = createRuntime(runtimeCore);
      const { stopAudio, ensureStreamBase, streamUrl, logSeek, logAttach, seekAudio, applyLibrary, load, bindElement, targetVolume, rgForTrack, nextTrackForPrefetch, scheduleRgPoll, prepareVideo, stopWasmVideo, prefetchWaveform, playIndex, effective, coverFor, visibleRows, next, prev, onTimeupdate, coverUrl, onPlay, onPause, onPageHide, onEnded, onLoadedMetadata, onWaiting, onResumed, onError } = runtime;

      /**
       * 断开一个本代接进设备的节点（音源 / 电平）。释放路径要容忍三件事：空值、
       * 已经断开、以及测试夹具里没有 `disconnect` 的假节点。
       */

      /** Range-stream URL for one track, revisioned by the current scan. */
      /** MV 转码缓存文件的地址：Desktop 下同样走 token 直连（否则拖不动进度）。 */
      /**
       * 是否运行在 DSH Desktop。**每次调用现算**，不看模块加载时抓的 window.dshDesktop
       * —— 插件先于产品 API 注入执行时那个值是 undefined，于是媒体一直用相对地址，
       * 经 Desktop 转发后 Range 丢失 → seekable=[0,0] → 一拖就回 0 秒（实测读数如此）。
       */
      /**
       * 等一次 /session（媒体直连基址）。返回是否**真的**拿到了。
       *
       * ⚠️ 不能「超时就算了」：拿不到基址就意味着媒体只能用**相对地址**，而相对地址
       * 在 Desktop 上经 Electron 转发会丢 Range（`seekable=[0,0]`）⇒ 一拖进度条就回 0
       * 秒。所以先给一次预算，还没有就**作废缓存强制重取**再来一次 —— 第二次会走
       * `/session` 的回环回落路径（见 loadSystemArtBase），这正是 Desktop 上唯一能走通的路。
       */

      /** Move the audio clock (clamped to the track) without touching store state. */
      /** 后台日志（不占界面）：排查"拖不动进度"用，DevTools 控制台可见。 */
      /**
       * 媒体源分类 + 是否已有 token 基址。「一拖就回 0」的排查全靠这行，
       * 所以分类必须**无歧义**：空串 / blob: / dsh-app:// / 相对路径原来会被
       * 一起算成 `rel`，等于看不出到底是哪一路。
       */
      /** 日志里不得出现能力 token（§2.9 凭据不进日志）。 */

      /**
       * 「一拖就回 0 秒」的可观测判据自愈（第 13 轮）。
       *
       * 判据是**症状**，不是原因：源不是 token 直连、时长已知、而 `seekable` 是 [0,0]
       * —— 这时媒体元素根本不能 seek，`currentTime = X` 只会让它从 0 重来。真机上
       * 读到的正是 `seekable=1(0.0..0.0) src=rel`。
       *
       * 成因（相对地址在 Desktop 上经 Electron 转发丢 Range）已在 §2.14 记过，
       * 但**只修成因不够**：基址可能因为平台 /api 的 401/403 而一直拿不到。所以这里
       * 按症状兜底 —— 作废基址、重取（含 /session 的回环回落）、用 token 地址重挂同一
       * 媒体并回到原位。只做一次，避免「失败→重取→再失败」的死循环。
       */
      let unseekableSrc = "";
      let unseekableHealDeadline = 0;
      let unseekableTimer: ReturnType<typeof setTimeout> | null = null;
      /** 自愈窗口：只有源真的不可 seek 才会进来，所以在这里等基址是值得的（有界，非无限）。 */
      const UNSEEKABLE_HEAL_WINDOW_MS = 20000;
      /** 换源后延迟一点再判：`seekable` 在 loadedmetadata 当场可能还没填好。 */
      /** 挂非 token 源时记一行 —— Desktop 上这就是「之后拖不动」的前兆，正常路径不刷屏。 */

      /** Remember the resume position. localStorage writes are synchronous, so
       *  timeupdate only persists every ~5s; pause/pagehide flush exactly. */
      let lastSavedAt = -1;

      /** One outstanding library poll while a host-side scan is running. */
      let pollTimer: ReturnType<typeof setTimeout> | null = null;
      /**
       * Teardown 之后的「不得再武装」闸门（A3-01）。
       *
       * 只清 `pollTimer` 不够：若 teardown 撞上某次轮询**在飞**，回调开头已把
       * `pollTimer` 置 null，`clearTimeout` 落空；该请求又因宿主路由已摘除而 404，
       * 回调的 `catch` 会再武装定时器 —— 之后 `state.scanning` 若没被复位，守卫
       * `if (!state.scanning) return` 永不成立，卸载后就是 1.5s 一次的永久请求风暴。
       * 所以「清句柄」与「阻止再武装」必须分开做：这里加状态位，`halt()` 里复位
       * `scanning`。
       */
      let disposed = false;
      /**
       * activation 租约号（见 api0.acquire/lease）：这个实例可能被**两代** activation
       * 先后引用（新 bundle 先求值、旧 disposer 后跑），谁有权释放必须按号判断。
       */
      let activationGen = 0;


      /** After a fresh library arrives, re-map the playing track by stable id. */


      /** Cue the last played track (paused, at the remembered position). */
      let lastPlayedRestored = false;

      /**
       * 只换源、**不开播**（刷新后 cue 上一首用的就是这条）。
       *
       * ⚠️ 不能用 `attachSource(url); audio.pause();` 来模拟「cue」：`attachSource` 内部
       * 调了 `audio.play()`，紧接着的同步 `pause()` 会让那个 promise 以 **AbortError**
       * 拒绝，而 catch 只放行 NotAllowedError ⇒ 每次打开页面都弹一条
       * 「无法播放该文件」的红字（真机就是这个症状）。
       * 意图是 cue 就别调 play —— 而不是「播了再赶紧停」。
       */
      /**
       * 音量的短渐变 —— 消除切歌 / 起播 / 暂停时的**电流声**。
       *
       * 直接换 `src`、直接 `play()`、直接 `pause()` 都是**波形上的瞬间跳变**：输出从满幅
       * 一步跨到 0（或反过来），耳机（尤其入耳式）会把它放大成「啪 / 嘶」的一声。
       * 系统播放器（Apple Music 等）都做淡入淡出 —— 差距在这里，不在解码质量。
       *
       * 三条规则：
       * - `state.volume` 永远是**用户设定值**；渐变只改 `audio.volume` 的**瞬时值**。
       * - 任何会让声音突然消失的动作（换源 / 暂停）**先淡出**；起播之后**淡入**。
       * - 渐变**可被取消**：快速连点切歌时旧渐变必须停下并让位，否则它会把音量写回旧目标
       *   （与 §2.10「挂起后必须检查状态位」同族）。取消时 promise 以 `false` 结算 ——
       *   **不能只清定时器不结算**，那会让 `await` 它的调用方永久挂住。
       */
      /**
       * 过渡淡入淡出的时长取自 **fooyin**（开源本地音乐播放器）的引擎默认值：
       * `include/core/engine/fadingdefs.h` —— manualChange{in=300,out=300} ·
       * autoChange{in=700,out=700} · seek{in=120,out=120} · pause{in=120,out=120} ·
       * stop{in=120,out=300}。
       *
       * 关键情报：fooyin **同时**做了两件事 —— ① 输出会话常驻 + 「terminal resampling
       * for output compatibility」（`audiopipeline.h:228`，默认开，master output format +
       * SoX 重采样器）；② **每一次过渡都淡入淡出**（含 seek）。
       * 也就是：常驻输出流与过渡淡入淡出**不是二选一**，两个都要。
       * 我们第 18 轮做了②但太短（70/90ms）且漏了 seek，第 19 轮做了① —— 现在补齐。
       */
      const FADE_CHANGE_OUT_MS = 300;
      const FADE_CHANGE_IN_MS = 300;
      const FADE_AUTO_OUT_MS = 700;      // 曲末自动接下一首，给更长
      const FADE_AUTO_IN_MS = 700;
      const FADE_PAUSE_MS = 120;
      const FADE_SEEK_MS = 120;
      /** 本次换曲要用的时长（由 playIndex 按「手动 / 自动」写入）。 */
      let changeFadeOutMs = FADE_CHANGE_OUT_MS;
      let changeFadeInMs = FADE_CHANGE_IN_MS;
      /** 曲末自动续播标记：只由 ended 处理器置位，playIndex 消费后立刻复位。 */
      let advanceIsAuto = false;
      const engineCore = {
        get audio() { return audio; },
        set audio(value) { audio = value; },
        get audioCtx() { return audioCtx; },
        set audioCtx(value) { audioCtx = value; },
        get bindElement() { return bindElement; },
        get bindFailed() { return bindFailed; },
        set bindFailed(value) { bindFailed = value; },
        get device() { return device; },
        get disposed() { return disposed; },
        set disposed(value) { disposed = value; },
        get gainNode() { return gainNode; },
        set gainNode(value) { gainNode = value; },
        get graphOffByFlag() { return graphOffByFlag; },
        get graphReady() { return graphReady; },
        set graphReady(value) { graphReady = value; },
        get rgForTrack() { return rgForTrack; },
        get rgGainNode() { return rgGainNode; },
        set rgGainNode(value) { rgGainNode = value; },
        get rgLinear() { return rgLinear; },
        set rgLinear(value) { rgLinear = value; },
        get scheduleRgPoll() { return scheduleRgPoll; },
        get set() { return set; },
        get state() { return state; },
        set state(value) { state = value; },
      };
      const engine = createAudioEngine(engineCore);
      const { ensureAudioGraph, resumeGraph, applyVolume, rampVolume, cancelFade, readVolume, applyReplayGain, startRgMeasure, hasRgData, applyEqualizer, probeCrossOriginCors, watchSuspended, releaseElement } = engine;


      /**
       * 常驻音频图 —— 消除切歌 / 起播的「电流声」（第 19 轮）。
       *
       * **实测证据**：本机曲库 44.1kHz / 48kHz / 96kHz 与 16bit / 24bit 混排。
       * Chromium 为**每一条媒体源**单独建一条音频输出流；换 `src` 就是「销毁旧流 + 按新文件
       * 的采样率与位深建新流」，macOS 于是必须重协商输出设备格式 —— **设备重建就是那一声
       * 电流声**。它发生在**增益级之外**，所以第 18 轮的淡入淡出原理上消不掉（用户实测证实）。
       *
       * 一个常驻 `AudioContext` 只有**一条**输出流、一个固定采样率，所有媒体都被重采样进去，
       * 设备格式于是不再变 —— 系统播放器（Apple Music）就是这个做法。
       *
       * 三层保护：① 拿不到 AudioContext / 建图失败 → 永久退回元素音量（功能不受影响）；
       * ② 跨源媒体（桌面版页面 origin 是 `dsh-app://app`）必须带 `crossOrigin`，否则 Web Audio
       * 输出**静音**；宿主只对窄名单回显 ACAO（见 host.ts 的 mediaCorsHeaders）；
       * ③ 跨源时先**探测**一次 CORS，确认前仍走直连 —— 不出声风险为 0；
       * ④ 兜底开关：`?musicGraph=0` 或 `window.__dshMusicNoGraph = true` 直接关掉音频图。
       */
      /**
       * 本代对页级设备的引用。`device` 跨代存活，这三个别名让下面 30+ 处引用不必每处
       * 都写 `device.`；halt() 之后写这三个别名的只有释放路径本身（实例是终态的，
       * 跨代不复用）。
       */
      const device = audioDevice();
      let audioCtx: AudioContext | null = device.ctx;
      let gainNode: GainNode | null = device.volume;
      /** RG 增益节点，**独立于**音量节点（见 RG 常量处的说明）。 */
      let rgGainNode: GainNode | null = device.rg;
      /** 本代元素是否已接进设备（与「设备是否存在」是两件事）。 */
      let graphReady = false;
      /** 媒体元素只能建一次 source：这一代建不上就永久走元素音量。 */
      let bindFailed = false;
      /** 接进设备的 source 节点，释放时要 disconnect（否则设备一直被元素钉住）。 */
      let activeSource: MediaElementAudioSourceNode | null = null;
      let idleSource: MediaElementAudioSourceNode | null = null;
      /** 交叉淡化：空闲元素与它的电平节点（**惰性创建**，未开启时不存在）。 */
      let idleEl: HTMLVideoElement | null = null;
      let idleLevelNode: GainNode | null = null;
      /** 交叉淡化模式下当前元素的电平节点；非交叉模式为 null（图形态与以前完全一致）。 */
      let activeLevelNode: GainNode | null = null;
      /** 已经预取到空闲元素上的 URL（切换时用它判断「能否直接交叉进入」）。 */
      let prefetchedUrl: string | null = null;
      /**
       * **在飞的交叉淡化交接**。定时器到点时若发现它已被取代（`settlePending !== settle`）就放弃，
       * 而任何**新的切歌**都会先把上一段交接**结算掉**（`commitPendingCrossfade`）。
       * 否则一段迟到的交接会在新过渡开始后交换角色、pause 掉用户正在听的那一首
       * （与 §2.10「清 timer ≠ 阻止再武装」同一类：只 guard `disposed` 不够）。
       */
      const transportCore = {
        get activeLevelNode() { return activeLevelNode; },
        set activeLevelNode(value) { activeLevelNode = value; },
        get applyReplayGain() { return applyReplayGain; },
        get applyVolume() { return applyVolume; },
        get audio() { return audio; },
        set audio(value) { audio = value; },
        get audioCtx() { return audioCtx; },
        set audioCtx(value) { audioCtx = value; },
        get bindMedia() { return bindMedia; },
        set bindMedia(value) { bindMedia = value; },
        get cancelFade() { return cancelFade; },
        get changeFadeInMs() { return changeFadeInMs; },
        set changeFadeInMs(value) { changeFadeInMs = value; },
        get changeFadeOutMs() { return changeFadeOutMs; },
        set changeFadeOutMs(value) { changeFadeOutMs = value; },
        get crossfadeOn() { return crossfadeOn; },
        get device() { return device; },
        get disposed() { return disposed; },
        set disposed(value) { disposed = value; },
        get ensureAudioGraph() { return ensureAudioGraph; },
        get gainNode() { return gainNode; },
        set gainNode(value) { gainNode = value; },
        get idleEl() { return idleEl; },
        set idleEl(value) { idleEl = value; },
        get idleLevelNode() { return idleLevelNode; },
        set idleLevelNode(value) { idleLevelNode = value; },
        get idleSource() { return idleSource; },
        set idleSource(value) { idleSource = value; },
        get logAttach() { return logAttach; },
        get mediaPark() { return mediaPark; },
        set mediaPark(value) { mediaPark = value; },
        get nextTrackForPrefetch() { return nextTrackForPrefetch; },
        get pauseEpoch() { return pauseEpoch; },
        set pauseEpoch(value) { pauseEpoch = value; },
        get prefetchWaveform() { return prefetchWaveform; },
        get prefetchedUrl() { return prefetchedUrl; },
        set prefetchedUrl(value) { prefetchedUrl = value; },
        get probeCrossOriginCors() { return probeCrossOriginCors; },
        get rampVolume() { return rampVolume; },
        get readVolume() { return readVolume; },
        get resumeGraph() { return resumeGraph; },
        get sameOriginAsPage() { return sameOriginAsPage; },
        get set() { return set; },
        get streamUrl() { return streamUrl; },
        get targetVolume() { return targetVolume; },
      };
      const transport = createTransport(transportCore);
      const { commitPendingCrossfade, attachSource } = transport;

      /** 结算在飞的交叉淡化（幂等）；没有在飞的就是空操作。 */
      /** 当前生效的 RG 线性增益（1 = 不动）。回退路径要把它折进元素音量。 */
      let rgLinear = 1;
      /**
       * 预取 + 交叉淡化（消除切歌过渡缝）。**默认开启**：噪声与平台/其它来源有关，
       * 不属于本插件的设备重协商（§2.18 / §2.21）。
       * 显式关闭：`?crossfade=0` 或 `window.__dshMusicCrossfade = false`。
       */
      const crossfadeOn = (() => {
        try {
          const q = new URLSearchParams(window.location.search).get("crossfade");
          if (q === "1") return true;
          if (q === "0") return false;
        } catch { /* location 不可用就当作没设标记 */ }
        // 默认**开启**（第 25 轮用户实测确认：噪声在**换页面**时也出现 ⇒ 与平台/其它来源有关，
        // 不再是本插件的设备重协商）。显式关闭：`window.__dshMusicCrossfade = false`。
        const flag = (window as unknown as { __dshMusicCrossfade?: boolean }).__dshMusicCrossfade;
        return flag === undefined ? true : flag === true;
      })();

      const graphOffByFlag = (() => {
        try {
          // 查询参数刻意**不叫** `dshm-*`：静态审计按约定把 `dshm-` 前缀当 CSS 类
          // (test-audit「每个 JS 里用到的类都要有 CSS 规则」)，改门禁就是放宽断言。
          if (new URLSearchParams(window.location.search).get("musicGraph") === "0") return true;
        } catch { /* location 不可用就当作没设标记 */ }
        return (window as unknown as { __dshMusicNoGraph?: boolean }).__dshMusicNoGraph === true;
      })();

      /** url 与页面是否同源（blob:/data: 视为同源，它们不需要 CORS）。 */
      const sameOriginAsPage = (url: string): boolean => {
        if (/^(blob:|data:)/.test(url)) return true;
        try {
          // 一律走 `window.location`：client bundle 由宿主 eval 进浏览器，而「被 eval 的
          // 代码里裸 `location` 能不能解析」取决于宿主作用域 —— 用 window 上的属性最稳。
          return new URL(url, window.location.href).origin === window.location.origin;
        } catch {
          return false;
        }
      };

      /**
       * 让设备的输出流回到 running。**只由「即将出声」的路径调用**：设备跨代共存，上一代的
       * halt() 会把它 suspend，缺这一步就是「界面在放、耳机没声」，从外部完全看不出原因。
       * 诊断只记状态（§2.9：绝不记 URL / token）。
       */

      /**
       * 系统单方面挂起 ctx（切换音频设备、休眠唤醒、iOS 的 interrupted）时的自愈判据：
       * 元素**仍在放**才算「该出声却没在跑」。挂起发生在暂停期间的情况由**播放起点**的
       * resumeGraph() 兜住 —— 那条路不依赖 onstatechange（它只在状态**变化**时触发）。
       */

      /** 建（或复用）设备上的固定采样率输出流与增益链。返回设备是否可用。 */

      /** 把本代媒体元素接进设备：交叉淡化时经每元素电平节点，否则直连 RG（形态与以前逐字一致）。 */


      /** 跨源媒体是否已确认宿主回显 ACAO（页级只探一次；失败就永久走直连）。 */

      /** 瞬时音量：有音频图就走 GainNode，否则写元素音量（两条路都不写 state）。 */
      /** 实际输出音量：静音时按 0，`state.volume` 始终保留用户设定值。 */


      /**
       * 当前曲目该用的 ReplayGain。与 fooyin 一致：
       * ① 只读标准标签、不改文件；② 未测量过 → 1（**不做增益**，不是当 0dB 用）；
       * ③ Track / Album 两种模式，Album 缺标签回退 Track；
       * ④ 防削波：增益后峰值可能越过满刻度，按 peak **收窄**增益。
       */

      /** 空闲元素（预取用的另一半）。惰性创建：只在开启交叉淡化时存在。 */

      /** 空闲元素接进**同一条常驻输出流**：设备格式仍然只开一次（§2.19 的前提不变）。 */

      /** 可见列表里的下一首（与 next() 同一套顺序：播放顺序 = 你看到的顺序）。 */

      /** 把下一首挂到空闲元素上（只加载，不出声）。 */

      /** 当前曲目有没有任何可用的 RG 数据（文件标签或插件测量）。 */

      /**
       * 测量进度轮询。与 `schedulePoll` 同一套纪律：`disposed` 立闸门 + 清句柄两者都要做，
       * 否则 teardown 撞上在飞回调会再武装（§2.10 / A3-01）。
       */
      let rgPollTimer: ReturnType<typeof setTimeout> | null = null;

      /** 让宿主开始测量（幂等：宿主侧正在跑就只返回状态）。 */

      /**
       * 把均衡器曲线落到滤波器链上，并按**最大提升量**设置自动前级：
       * 只提升某几段时，前级按 `-max(0, 最大增益)` 衰减，保证不会因此把峰值推过满刻度
       * （与 RG 的防削波同一思路；fooyin 里这件事由用户调 preamp，这里自动做掉）。
       * 图不可用时静默跳过 —— 均衡器是锦上添花，绝不能让整条播放路径失败。
       */

      /** 把 RG 落到图上（或折进回退路径的元素音量）。切曲与改设置都要调。 */

      /** 取消在飞的渐变；被取消的那个 promise 以 `false` 结算（不会挂住调用方）。 */

      /** 把瞬时音量在 ms 内推到 to。返回是否**正常走完**（false = 被更新的动作取消）。 */
      /** 只换源、**不开播**（刷新后 cue 上一首用的就是这条）。 */

      /** 换源并开播（音频与 MV 共用；MV 的 URL 由 /mv 决定）。 */

      /**
       * 视频轨要出画面，先问宿主怎么办：direct 直出 / remux 换壳 / transcode 重编码。
       * 后两种要等 ffmpeg 干活，轮询到 ready 再拿到缓存文件 URL（缓存命中就秒回）。
       *
       * `retry` 只由「用户点了重试」传：宿主那边失败任务会缓存 10 分钟，不带这个标记
       * 重试只会拿回同一条失败记录（按钮看起来像个空操作）。
       */
      /** 已经升级过转码的视频轨（避免失败→升级→再失败的死循环）。 */
      const mvEscalated = new Set<string>();

      /**
       * WASM 画面旁路：浏览器没有的解码器（mpeg4/DivX、老 mpeg2 等）用
       * libav.js 的 WebCodecs polyfill 补上，帧直接画到 canvas。
       * 音频继续由现有 <video> 播 /stream（本来就能播），所以不用碰 A/V 同步最难的那半。
       * 任何一步失败都返回 false，让调用方退回只读缓存转码 —— 绝不改用户的文件。
       */
      let wasmAbort: { aborted: boolean } | null = null;
      const WASM_CODECS = new Set(["mpeg4", "mpeg2", "vc1", "theora", "msmpeg4"]);
      /**
       * Chromium 能自己解的音轨编码（与宿主 `mvPlan` 的 `MV_DIRECT_AUDIO` 同一张表）。
       * WASM 旁路只接管**画面**，元素仍要自己解音轨 —— 表里没有的编码（DTS、WMA…）
       * 走 WASM 就是「有画面、没声音」，而且跳过了本来会把音轨转成 AAC 的那次转码。
       * 探测不到编码（null）时按宿主同样的口径保守放行。
       */
      const MV_DIRECT_AUDIO = new Set(["aac", "mp3", "opus", "vorbis", "flac", "ac3", "eac3", "pcm", "alac"]);

      /**
       * 波形客户端缓存（**有界**，§2.2）。宿主那边要跑一次 ffmpeg，客户端这边一次往返也不便宜：
       * 返回上一首时直接用缓存，柱子**立刻**出现。
       */
      const wavePeaksCache = new Map<string, number[]>();
      const WAVE_PEAKS_CACHE_MAX = 30;

      /**
       * 预取**下一首**的包络进客户端缓存。与交叉淡化**无关**（关掉淡化也值得预取）。
       * 注意它只填缓存、**不动当前显示** —— 预取绝不能改 UI。
       */

      /**
       * 波形：按需取当前曲目的包络。宿主侧是**只读** ffmpeg 解码 + 缓存（与 §2.20 同族纪律）。
       * 取不到（没有 ffmpeg / 解码失败 / 未知曲目）就保持 `null` 静默降级 —— 不报红字、不影响播放。
       */

      /**
       * 可见列表（筛选 + 排序后的行序）。它就是播放队列：
       * next/prev/播完自动下一首/出错自动跳过，全部按这个顺序走——
       * 用户在表格里看到的上下关系就是实际的播放先后。
       * Cached by (tracks, query, sort) so render + next/prev + error paths
       * share one sorted array instead of re-sorting per call.
       */
      /** 叠加在线补全后的展示信息（不改动 state.tracks 本身）。 */
      /** 优先用补全的远端封面，否则回退文件内嵌封面。 */

      let rowsCache: RowsCache | null = null;

      /** 播放进度：只有**活动元素**的事件算数（另一个在淡出或预取）。 */

      /**
       * Apple Music–style placeholder artwork for the OS now-playing widget.
       * MediaSession needs a raster URL, so the icon (pink gradient rounded
       * square + white beamed note) is drawn once on a canvas and cached.
       */
      const mediaSession = createMediaSession({
        get state() { return state; },
        get audio() { return audio; },
        get endpointBase() { return endpointBase; },
        get systemArtBase() { return systemArtBase; },
        effective,
        coverUrl,
      });
      const { coverKnown, updatePositionState, updateMediaSession } = mediaSession;
      if ("mediaSession" in navigator) {
        try {
          navigator.mediaSession.setActionHandler("play", () => api0.toggle());
          navigator.mediaSession.setActionHandler("pause", () => api0.toggle());
          navigator.mediaSession.setActionHandler("previoustrack", () => api0.prev());
          navigator.mediaSession.setActionHandler("nexttrack", () => api0.next());
          navigator.mediaSession.setActionHandler("seekto", (details) => {
            if (typeof details.seekTime === "number") api0.seek(details.seekTime);
          });
        } catch {
          // Some handlers may be unsupported; register what we can.
        }
        // 拿到带 token 的系统取图基址后重发一次 metadata，保证第一首就有封面。
        loadSystemArtBase().then((base) => {
          if (typeof base === "string" && base.length > 0) updateMediaSession();
        });
      }

      /** 关页面前把位置落盘：节流写入会丢最后 5 秒。注册的监听必须在 halt() 里摘掉。 */
      /** 每次换源都会重新触发 loadedmetadata：统一检查这个源能不能 seek。 */
      /** 缓冲反馈：等数据时给明确信号，恢复后立刻撤掉（状态由 bindMedia 装在两个元素上）。 */
      /**
       * Re-pull the stream and land at `target` (used by both recovery paths).
       * Re-checks the playing track inside the timer: the user may have picked
       * another song during the grace period, and that choice must win.
       */

      /** 升级成转码（画面看门狗与音轨看门狗共用；每首各自只有一次预算）。 */

      /**
       * 画面看门狗：有些编码 Chromium 既不报 error 也不出画面（只有声音，实测 MPEG-4 Part 2
       * 与部分 HEVC 就是这样）。播了 2 秒 videoWidth 仍是 0 就当成失败，升级成转码。
       */

      /**
       * 音轨看门狗：图面对得上、音轨解不了时 Chromium **不报 error**，只是把那条流丢掉 ——
       * 直出/换壳路径的症状于是是「有画面、没声音」，刷新也好不了。
       *
       * 判据用 Chromium 的 `webkitAudioDecodedByteCount`（其他引擎没有这个属性，取不到就不判）：
       * 播了 3.5 秒仍是 0 个音频字节 ⇒ 这条音轨实际没解出来 ⇒ 升级成转码（音轨转 AAC）。
       * 只在**已知有音轨**（`audioCodec` 非 null）时才判：否则会把本来就无声的 MV 也送去转码。
       */


      // 两个元素都装：这是交叉淡化交换活动元素后仍能收到媒体事件的唯一保证。
      bindMedia = (el) => {
        el.addEventListener("timeupdate", () => onTimeupdate(el));
        el.addEventListener("waiting", () => onWaiting(el));
        el.addEventListener("stalled", () => onWaiting(el));
        el.addEventListener("playing", () => onResumed(el));
        el.addEventListener("canplay", () => onResumed(el));
        el.addEventListener("play", () => onPlay(el));
        el.addEventListener("pause", () => onPause(el));
        el.addEventListener("ended", () => onEnded(el));
        el.addEventListener("error", () => onError(el));
        el.addEventListener("loadedmetadata", () => onLoadedMetadata(el));
      };
      bindMedia(audio);
      if (idleEl !== null) bindMedia(idleEl);

      /**
       * 全屏播放器收起动画（200ms）的定时器。
       *
       * 归 player 所有、而不是归视图的 useEffect 所有：视图在切到对话时**会被卸载**，
       * 挂在视图里的 timer 会被 cleanup 清掉，回来时 phase 永远停在 `closing`
       * ——既收不拢也打不开。halt() 里清句柄 + disposed 闸门（同 §2.10）。
       */
      let playerCloseTimer: ReturnType<typeof setTimeout> | null = null;

      const core = {
        get FADE_PAUSE_MS() { return FADE_PAUSE_MS; },
        get FADE_SEEK_MS() { return FADE_SEEK_MS; },
        get RG_PREAMP_MAX_DB() { return RG_PREAMP_MAX_DB; },
        get RG_PREAMP_MIN_DB() { return RG_PREAMP_MIN_DB; },
        get activationGen() { return activationGen; },
        set activationGen(value) { activationGen = value; },
        get activeLevelNode() { return activeLevelNode; },
        set activeLevelNode(value) { activeLevelNode = value; },
        get activeSource() { return activeSource; },
        set activeSource(value) { activeSource = value; },
        get applyEqualizer() { return applyEqualizer; },
        get applyLibrary() { return applyLibrary; },
        get applyReplayGain() { return applyReplayGain; },
        get applyVolume() { return applyVolume; },
        get attachSource() { return attachSource; },
        get audio() { return audio; },
        set audio(value) { audio = value; },
        get audioCtx() { return audioCtx; },
        set audioCtx(value) { audioCtx = value; },
        get cancelFade() { return cancelFade; },
        get commitPendingCrossfade() { return commitPendingCrossfade; },
        get coverFor() { return coverFor; },
        get device() { return device; },
        get disposed() { return disposed; },
        set disposed(value) { disposed = value; },
        get effective() { return effective; },
        get ensureStreamBase() { return ensureStreamBase; },
        get gainNode() { return gainNode; },
        set gainNode(value) { gainNode = value; },
        get hasRgData() { return hasRgData; },
        get idleEl() { return idleEl; },
        set idleEl(value) { idleEl = value; },
        get idleLevelNode() { return idleLevelNode; },
        set idleLevelNode(value) { idleLevelNode = value; },
        get idleSource() { return idleSource; },
        set idleSource(value) { idleSource = value; },
        get lastFailureAt() { return lastFailureAt; },
        set lastFailureAt(value) { lastFailureAt = value; },
        get listeners() { return listeners; },
        get load() { return load; },
        get logSeek() { return logSeek; },
        get matchSeq() { return matchSeq; },
        set matchSeq(value) { matchSeq = value; },
        get mediaPark() { return mediaPark; },
        set mediaPark(value) { mediaPark = value; },
        get mvEscalated() { return mvEscalated; },
        get next() { return next; },
        get onPageHide() { return onPageHide; },
        get pauseEpoch() { return pauseEpoch; },
        set pauseEpoch(value) { pauseEpoch = value; },
        get playIndex() { return playIndex; },
        get playerCloseTimer() { return playerCloseTimer; },
        set playerCloseTimer(value) { playerCloseTimer = value; },
        get playingId() { return playingId; },
        set playingId(value) { playingId = value; },
        get pollTimer() { return pollTimer; },
        set pollTimer(value) { pollTimer = value; },
        get prepareVideo() { return prepareVideo; },
        get prev() { return prev; },
        get rampVolume() { return rampVolume; },
        get releaseElement() { return releaseElement; },
        get resumeAttempts() { return resumeAttempts; },
        set resumeAttempts(value) { resumeAttempts = value; },
        get resumeGraph() { return resumeGraph; },
        get rgPollTimer() { return rgPollTimer; },
        set rgPollTimer(value) { rgPollTimer = value; },
        get seekAudio() { return seekAudio; },
        get set() { return set; },
        get skipAttempts() { return skipAttempts; },
        set skipAttempts(value) { skipAttempts = value; },
        get startRgMeasure() { return startRgMeasure; },
        get state() { return state; },
        set state(value) { state = value; },
        get stopAudio() { return stopAudio; },
        get stopWasmVideo() { return stopWasmVideo; },
        get streamUrl() { return streamUrl; },
        get targetVolume() { return targetVolume; },
        get unseekableTimer() { return unseekableTimer; },
        set unseekableTimer(value) { unseekableTimer = value; },
        get updateMediaSession() { return updateMediaSession; },
        get visibleRows() { return visibleRows; },
        get watchSuspended() { return watchSuspended; },
      };
      const api0 = createPlayerApi(core);
      return api0;
    }

    /**
     * 取一代还活着的 player：`window` 上的那份若已被 halt() 释放（`spent()`），
     * 就**新建**一份而不是接管旧状态 —— 旧状态的核心是 `disposed` 终态闸门与已释放的
     * 媒体元素/停靠位，接管它等于下一代替上一代保持沉默。
     *
     * 页级的东西（AudioContext、增益链、CORS 探测结果）不在这里重建，它们在
     * `audioDevice()` 里跨代存活。
     */
    function takePlayer(): MusicPlayerApi {
      const holder = window as unknown as { __dshMusicPlayer?: MusicPlayerApi };
      const existing = holder.__dshMusicPlayer;
      // 释放记账在**页级设备**里（halt 往它里面登记），所以新 bundle 求值后也认识上一代
      // 已经释放的实例；接管一份终态实例就是「换首歌以后界面在放、耳机没声」。
      if (existing !== undefined && !audioDevice().released.has(existing)) return existing;
      const created = createPlayer();
      holder.__dshMusicPlayer = created;
      return created;
    }

    /** 当前代的 player。视图与 player 内的回调都从这里取（apply 会刷新它）。 */
    let player: MusicPlayerApi = takePlayer();

    /**
     * Attach a non-passive wheel listener to an element (React's synthetic
     * onWheel is passive and cannot preventDefault the page scroll).
     * The handler ref always sees the latest render's state.
     */
    function useWheelHandler(getHandler) {
      const ref = useRef(null);
      const latest = useRef(getHandler);
      latest.current = getHandler;
      useEffect(() => {
        const el = ref.current;
        if (el === null) return undefined;
        const onWheel = (event) => {
          // A disabled slider must not swallow the gesture — let the list scroll.
          if (el.disabled) return;
          event.preventDefault();
          latest.current(event);
        };
        el.addEventListener("wheel", onWheel, { passive: false });
        return () => el.removeEventListener("wheel", onWheel);
      }, []);
      return ref;
    }

    /**
     * 覆盖层契约：打开时锁背景滚动、Tab 焦点锁在层内、Escape 关闭、关闭后焦点归还触发者。
     * `.dshm-modal` 是唯一的真覆盖层；内联确认条的 Escape 在下面统一处理。
     */
    function useModalA11y(isOpen, onClose) {
      const layerRef: { current: HTMLDivElement | null } = React.useRef(null);
      const closeRef = React.useRef(onClose);
      closeRef.current = onClose;
      const restoreRef: { current: { focus?: () => void } | null } = React.useRef(null);
      React.useEffect(() => {
        if (!isOpen) return undefined;
        // 注意：客户端 bundle 也在 jsdom 里跑，那里没有 `HTMLElement` 全局 —— 用鸭子类型判断。
        const focused = document.activeElement as unknown as { focus?: () => void } | null;
        restoreRef.current = focused !== null && typeof focused.focus === "function" ? focused : null;
        const body = document.body;
        const priorOverflow = body.style.overflow;
        body.style.overflow = "hidden";
        const focusables = (): HTMLElement[] => {
          const root = layerRef.current;
          if (root === null) return [];
          return Array.from(root.querySelectorAll<HTMLElement>(
            'button:not([disabled]), input:not([disabled]), [href], [tabindex]:not([tabindex="-1"])',
          ));
        };
        const onKeyDown = (event) => {
          if (event.key === "Escape") {
            event.preventDefault();
            closeRef.current();
            return;
          }
          if (event.key !== "Tab") return;
          const items = focusables();
          if (items.length === 0) return;
          const first = items[0];
          const last = items[items.length - 1];
          const focused = document.activeElement as unknown as { focus?: () => void } | null;
          const active = focused !== null && typeof focused.focus === "function"
            ? (focused as unknown as HTMLElement) : null;
          if (!event.shiftKey && (active === last || active === null || !items.includes(active))) {
            event.preventDefault();
            first.focus();
          } else if (event.shiftKey && (active === first || active === null || !items.includes(active))) {
            event.preventDefault();
            last.focus();
          }
        };
        document.addEventListener("keydown", onKeyDown);
        const initial = focusables()[0];
        if (initial !== undefined) initial.focus();
        return () => {
          document.removeEventListener("keydown", onKeyDown);
          body.style.overflow = priorOverflow;
          const restore = restoreRef.current;
          if (restore !== null && typeof restore.focus === "function") restore.focus();
        };
      }, [isOpen]);
      return layerRef;
    }

    /**
     * Elapsed-time slider. Deliberately uncontrolled: the fill, the knob and the
     * clock are painted straight from the audio clock in a rAF loop, so playback
     * and scrubbing never re-render React. A controlled slider re-rendered the
     * whole view (track list included) on every animation frame, which is what
     * made dragging and seeking feel sluggish.
     */
    const ProgressBar = React.memo(function ProgressBar({ player, trackId, duration, time, playing, peaks, t, variant }) {
      // 指针交互挂在命中区（.dshm-progressTrack）上，滚轮快进也挂这里。
      const trackRef = useWheelHandler((event) => {
        if (trackId < 0 || !(duration > 0)) return;
        const step = event.shiftKey ? 1 : 5;
        const delta = event.deltaY < 0 ? step : -step;
        player.seek(Math.max(0, Math.min(duration, player.now() + delta)));
      });
      const [dragging, setDragging] = React.useState(false);
      const sliderRef = useRef(null);
      const clockRef = useRef(null);
      const remainingRef = useRef(null);
      const draggingRef = useRef(false);
      const movedRef = useRef(false);
      const pendingRef = useRef(0);
      const paintRef = useRef(null);

      paintRef.current = (value) => {
        const slider = sliderRef.current;
        const clock = clockRef.current;
        const total = duration > 0 ? duration : 0;
        const at = Number.isFinite(value) ? Math.max(0, total > 0 ? Math.min(total, value) : value) : 0;
        if (slider !== null) {
          // Never fight the user's drag: the browser owns value while dragging.
          if (!draggingRef.current) slider.value = String(at);
          // --p is a gradient stop (not a background-size), so the fill follows
          // the pointer instantly and the .12s track-thickness transition on
          // hover stays independent of it.
          slider.style.setProperty("--p", String(total > 0 ? (at / total) * 100 : 0) + "%");
        }
        if (clock !== null) {
          const label = formatTime(at);
          if (clock.textContent !== label) clock.textContent = label;
        }
        // 右侧显示「剩余」（macOS Music 是 -4:26 这种带负号的剩余时间）
        const remaining = remainingRef.current;
        if (remaining !== null) {
          const label = total > 0 ? "-" + formatTime(Math.max(0, total - at)) : "--:--";
          if (remaining.textContent !== label) remaining.textContent = label;
        }
      };

      // Repaint on external changes (track switch, pause, keyboard seek). While
      // playing the loop below owns the paint, so the 1Hz state.time update must
      // not snap the fill back to a stale whole-second value.
      React.useLayoutEffect(() => {
        if (playing) return;
        paintRef.current(player.now());
      }, [playing, trackId, duration, time]);

      useEffect(() => {
        if (!playing) return undefined;
        let raf = 0;
        const tick = () => {
          if (!draggingRef.current) paintRef.current(player.now());
          raf = requestAnimationFrame(tick);
        };
        raf = requestAnimationFrame(tick);
        return () => cancelAnimationFrame(raf);
      }, [playing, trackId]);

      /**
       * 拖动：完全交给滑杆自己的原生事件（Chromium 里按轨道即跳、按住即拖）。
       * 这里只管两件事 —— 拖动期间不动音频（只画界面），松手 seek 一次。
       * 之前自绘过一层 pointerdown/move/up + pointer-events:none，实测在真实环境里
       * 点击和拖动都没反应（jsdom 测不出来），所以退回原生交互。
       */
      const endDrag = () => {
        if (!draggingRef.current) return;
        draggingRef.current = false;
        setDragging(false);
        // 松手才真正 seek（单击 = 快进到该点）。
        player.seek(pendingRef.current);
        paintRef.current(pendingRef.current);
      };
      const onInput = (event) => {
        const value = Number(event.target.value);
        if (!Number.isFinite(value)) return;
        if (!draggingRef.current) {
          // Keyboard arrows / wheel: commit straight away.
          player.seek(value);
          paintRef.current(value);
          return;
        }
        // 拖动中：只记位置 + 画界面，不动音频（流式文件被反复 seek 会不断中断 Range 请求）。
        pendingRef.current = value;
        paintRef.current(value);
      };

      const elapsedLabel = h("span", { className: "dshm-time", ref: clockRef });
      const remainingLabel = h("span", { className: "dshm-time dshm-time--end", ref: remainingRef }, "--:--");
      const slider = h("input", {
        type: "range",
        className: "dshm-slider",
        ref: sliderRef,
        min: 0,
        max: duration > 0 ? duration : 1,
        step: 0.1,
        defaultValue: 0,
        disabled: trackId < 0,
        "aria-label": t("a11y.progress"),
        onPointerDown: () => { draggingRef.current = true; movedRef.current = false; },
        onPointerMove: () => { if (draggingRef.current) movedRef.current = true; },
        onPointerUp: endDrag,
        onPointerCancel: endDrag,
        onLostPointerCapture: endDrag,
        onChange: onInput,
      });
      // 波形：两层同样的柱子，上层用 clip-path 按播放进度裁开。进度通过 CSS 变量
      // `--dshm-played` 传进去，所以拖动的 rAF 循环**不必**触发 React 重渲染。
      const bars = Array.isArray(peaks) && peaks.length > 0
        ? sampleWaveBars(peaks, variant === "stacked" ? WAVE_BARS_FULL : WAVE_BARS_INLINE)
        : null;
      const playedPct = duration > 0 && Number.isFinite(time) ? Math.max(0, Math.min(100, (time / duration) * 100)) : 0;
      const waveRow = (modifier?) => h("div", { className: "dshm-wave__row" + (modifier === undefined ? "" : " " + modifier) },
        bars === null ? null : bars.map((value, i) => h("span", {
          key: i,
          className: "dshm-wave__bar",
          // 高度按包络；最低留 6%，静音段也看得见一条底线。
          style: { height: Math.max(6, Math.round(value * 100)) + "%" },
        })));
      // 命中区自己接管指针：点哪儿跳哪儿、拖多快都只画界面，松手才 seek。
      const track = h("div", {
        className: "dshm-progressTrack" + (bars === null ? "" : " dshm-progressTrack--wave"),
        style: bars === null ? undefined : { "--dshm-played": playedPct.toFixed(2) + "%" },
      },
        bars === null ? null : h("div", { className: "dshm-wave", "aria-hidden": "true" }, waveRow(), waveRow("dshm-wave__row--on")),
        slider);
      const stacked = variant === "stacked";
      return h("div", {
        className: "dshm-progress"
          + (stacked ? " dshm-progress--stacked" : "")
          + (dragging ? " dshm-progress--dragging" : ""),
        // 指针事件在滑杆本体上（原生交互）；容器这个 ref 只用来挂滚轮快进。
        ref: trackRef,
      },
        // macOS Music 的全屏播放器：细轨在上，时间在下左右分列；底部条一行内联
        stacked
          ? [track, h("div", { key: "times", className: "dshm-timeRow" }, elapsedLabel, remainingLabel)]
          : [elapsedLabel, track, remainingLabel],
      );
    });

    /**
     * 溢出时「从右往左」循环滚动的歌名/歌手（Apple Music 那种跑马灯）。
     *
     * 只在真的放不下时才滚：ResizeObserver 同时盯着容器和内容宽度，窄窗口 / 长标题
     * 都会重新判定；复制一份文本做无缝衔接（[文本][gap][文本]，位移正好一份 + gap），
     * 速度按内容宽度换算成固定 px/s，所以长标题不会滚得离谱；悬停暂停。
     */
    const MARQUEE_GAP_PX = 36;
    const MARQUEE_SPEED_PX_PER_S = 38;
    const Marquee = React.memo(function Marquee({ text, className, title }) {
      const hostRef = useRef(null);
      const sampleRef = useRef(null);
      const [state, setState] = useState({ on: false, duration: 12 });
      useEffect(() => {
        const host = hostRef.current;
        const sample = sampleRef.current;
        if (host === null || sample === null) return undefined;
        const sync = () => {
          // 单份文本宽度直接量第一份 span。早先是从 inner.scrollWidth 折半推的，
          // 但"未滚动"时 inner 里只有一份，折半等于把阈值抬成"文本得超过 2 倍
          // 容器宽才滚"——于是 1~2 倍之间的长歌名既不滚也不显示省略号，直接被切掉。
          const copy = sample.scrollWidth;
          const box = host.clientWidth;
          const overflows = copy > box + 4;
          const duration = Math.max(6, Math.round((copy + MARQUEE_GAP_PX) / MARQUEE_SPEED_PX_PER_S));
          setState((previous) => (
            previous.on === overflows && previous.duration === duration
              ? previous
              : { on: overflows, duration }
          ));
        };
        sync();
        const observer = new ResizeObserver(sync);
        observer.observe(host);
        observer.observe(sample);
        window.addEventListener("resize", sync);
        return () => {
          observer.disconnect();
          window.removeEventListener("resize", sync);
        };
      }, [text]);
      return h("div", {
        ref: hostRef,
        className: "dshm-marquee" + (state.on ? " dshm-marquee--on" : "") + (className === undefined ? "" : " " + className),
        title: state.on ? undefined : title,
        style: { "--dshm-marquee-gap": MARQUEE_GAP_PX + "px", "--dshm-marquee-duration": state.duration + "s" },
      },
        h("div", { className: "dshm-marqueeInner" },
          h("span", { className: "dshm-marqueeText", ref: sampleRef }, text),
          // 只有需要滚动时才插第二份，避免常态下多一份重复文本被读屏念两遍。
          state.on ? h("span", { className: "dshm-marqueeText", "aria-hidden": "true" }, text) : null,
        ),
      );
    });

    /** 行内封面：加载失败（无内嵌封面且未补全）时回退音符图标。 */
    /**
     * 列表封面。正在播放的那一行像 Apple Music 一样在封面上叠「跳动条」
     * （他们的 .playing-bars）；鼠标悬停时跳动条淡出、换成播放/暂停图标
     * （他们的 --playButtonOpacity + .playing-bars-hover 那套交互）。
     */
    const RowCover = React.memo(function RowCover({ src, playing, paused }) {
      const [failed, setFailed] = useState(false);
      useEffect(() => { setFailed(false); }, [src]);
      const art = src === null || failed
        ? h("span", { className: "dshm-rowNote" }, ICONS.note)
        : h("img", { className: "dshm-rowCover", src, alt: "", loading: "lazy", onError: () => setFailed(true) });
      if (!playing) return art;
      return h("span", { className: "dshm-coverWrap" },
        art,
        h("span", { className: "dshm-coverBars", "aria-hidden": "true" }, h("i"), h("i"), h("i")),
        h("span", { className: "dshm-coverHover", "aria-hidden": "true" }, paused ? ICONS.play : ICONS.pause),
      );
    });

    /** Track list. Memoised so the playback clock never re-renders the rows. */
    const TrackTable = React.memo(function TrackTable({ rows, current, sortKey, sortDir, player, t, effective, coverFor, activeRowRef, playing, onMenu }) {
      const sortHeader = (key, labelKey, className?: string) => h("th", {
        className: (className ?? "") + " dshm-sortable" + (sortKey === key ? " dshm-sorted" : ""),
        onClick: () => player.toggleSort(key),
      }, t(labelKey), sortKey === key ? (sortDir === "asc" ? " ▲" : " ▼") : "");
      return h("div", { className: "dshm-tableWrap" },
        h("table", { className: "dshm-table" },
          h("thead", null, h("tr", null,
            h("th", { className: "dshm-colCover" }, ""),
            sortHeader("title", "col.title"),
            sortHeader("artist", "col.artist", "dshm-colArtist"),
            sortHeader("added", "col.added", "dshm-colAdded"),
            sortHeader("duration", "col.duration", "dshm-colDuration"),
            h("th", { className: "dshm-colActions" }, ""),
          )),
          h("tbody", null, rows.map(({ track, index }) => {
            const item = effective(track);
            // 行悬停也用官方气泡（原来是原生 title，和 DSH 观感不一致）；
            // Tooltip 会合并 ref，所以 activeRowRef 的滚动定位不受影响。
            // key 必须落在 map 返回的最外层元素上，所以这里先组装再用 cloneElement 挂 key。
            const rowElement = h("tr", {
              className: "dshm-row" + (index === current ? " dshm-row--active" : ""),
              ref: index === current ? activeRowRef : undefined,
              // 行可用键盘直接播放（Enter/空格）。行内按钮自己处理按键，不冒泡到行。
              tabIndex: 0,
              "aria-current": index === current ? "true" : undefined,
              onClick: () => player.play(index),
              onKeyDown: (event) => {
                if (event.target !== event.currentTarget) return;
                if (event.key !== "Enter" && event.key !== " ") return;
                event.preventDefault();
                player.play(index);
              },
            },
              h("td", { className: "dshm-colCover" }, h(RowCover, {
                src: coverFor(track),
                playing: index === current,
                paused: !playing,
              })),
              h("td", { className: "dshm-cellTitle" }, item.title, track.kind === "video" ? h("span", { className: "dshm-mvTag" }, "MV") : null),
              h("td", { className: "dshm-cellArtist" }, item.artist ?? ""),
              h("td", { className: "dshm-colAdded" }, formatAddedAt(track.addedAt)),
              h("td", { className: "dshm-colDuration" }, formatTime(track.duration)),
              h("td", { className: "dshm-colActions" },
                withTipWrapped(h("button", {
                  type: "button",
                  className: "dshm-rowMenuBtn",
                  "aria-label": t("action.more") + ": " + item.title,
                  "aria-haspopup": "menu",
                  onClick: (event) => {
                    event.stopPropagation();
                    onMenu(track, event);
                  },
                }, "⋯"), t("action.more")),
              ),
            );
            return React.cloneElement(withTip(rowElement, track.name), { key: index + ":" + track.name });
          })),
        ),
      );
    });


    const IMPORT_ACTIVE_PHASES = new Set(["queued", "starting", "metadata", "download", "finalize"]);
    const importUrlList = (text) => [...new Set(String(text).split(/\r?\n/).map((line) => line.trim()).filter((line) => line.length > 0))];

    /**
     * 链接导入弹层。任务归宿主：关掉弹层后继续下载，重新打开能看到任务列表；
     * 支持一次提交多行链接（宿主 3 并发、其余排队）。
     */
    function useImportDialogA11y(isOpen, onClose) {
      const layerRef = React.useRef(null);
      const closeRef = React.useRef(onClose);
      closeRef.current = onClose;
      const restoreRef = React.useRef(null);
      React.useEffect(() => {
        if (!isOpen) return undefined;
        const focused = document.activeElement as unknown as { focus?: () => void } | null;
        restoreRef.current = focused !== null && typeof focused.focus === "function" ? focused : null;
        const body = document.body;
        const priorOverflow = body.style.overflow;
        body.style.overflow = "hidden";
        const focusables = (): HTMLElement[] => {
          const root = layerRef.current as unknown as HTMLElement | null;
          if (root === null) return [];
          return Array.from(root.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]), textarea:not([disabled]), [href], [tabindex]:not([tabindex="-1"])'));
        };
        const onKeyDown = (event) => {
          if (event.key === "Escape") {
            event.preventDefault();
            closeRef.current();
            return;
          }
          if (event.key !== "Tab") return;
          const items = focusables();
          if (items.length === 0) return;
          const first = items[0];
          const last = items[items.length - 1];
          const active = document.activeElement as unknown as HTMLElement | null;
          if (!event.shiftKey && (active === last || active === null || !items.includes(active))) {
            event.preventDefault();
            first.focus();
          } else if (event.shiftKey && (active === first || active === null || !items.includes(active))) {
            event.preventDefault();
            last.focus();
          }
        };
        document.addEventListener("keydown", onKeyDown);
        const initial = focusables()[0];
        if (initial !== undefined) initial.focus();
        return () => {
          document.removeEventListener("keydown", onKeyDown);
          body.style.overflow = priorOverflow;
          if (restoreRef.current !== null && typeof restoreRef.current.focus === "function") restoreRef.current.focus();
        };
      }, [isOpen]);
      return layerRef;
    }

    function ImportDialog({ open, onClose, dir, t, onDone, onActiveChange }) {
      const [url, setUrl] = React.useState("");
      const [kind, setKind] = React.useState("audio");
      const [caps, setCaps] = React.useState(null);
      const [jobs, setJobs] = React.useState([]);
      const [cancelling, setCancelling] = React.useState({});
      const [error, setError] = React.useState(null);
      const [starting, setStarting] = React.useState(false);
      const [auth, setAuth] = React.useState(null);
      const [authError, setAuthError] = React.useState(null);
      const [qr, setQr] = React.useState(null);
      const [probe, setProbe] = React.useState(null);
      const [probing, setProbing] = React.useState(false);
      const [probeError, setProbeError] = React.useState(null);
      const [height, setHeight] = React.useState("best");
      const [probeNonce, setProbeNonce] = React.useState(0);
      const doneNotified = React.useRef(new Set());
      const activeJobs = jobs.filter((job) => IMPORT_ACTIVE_PHASES.has(job.phase));
      const anyActive = activeJobs.length > 0;
      const urlList = importUrlList(url);

      React.useEffect(() => {
        // 弹层关着时任务归宿主，由主视图轮询接管；这里只上报可见时的变化。
        if (!open) return;
        onActiveChange?.(activeJobs.length);
      }, [open, activeJobs.length]);

      const requestClose = () => {
        setQr(null);
        setAuthError(null);
        // 关闭弹层不取消下载：任务归宿主，重开弹层会重新拉取 jobs。
        onClose();
      };
      const layerRef = useImportDialogA11y(open, requestClose);

      React.useEffect(() => {
        if (!open) return undefined;
        let disposed = false;
        setError(null);
        void (async () => {
          try {
            const status = await api("/api/import");
            if (disposed) return;
            setCaps(status);
            const loaded = Array.isArray(status.jobs) ? status.jobs : (status.job ? [status.job] : []);
            setJobs(loaded);
            doneNotified.current = new Set(loaded.filter((job) => job.phase === "done").map((job) => job.id));
            const authStatus = await api("/api/import-auth").catch(() => null);
            if (!disposed && authStatus !== null) setAuth(authStatus.bilibili ?? null);
          } catch (failure) {
            if (!disposed) setError(failure instanceof Error ? failure.message : String(failure));
          }
        })();
        return () => { disposed = true; };
      }, [open]);

      React.useEffect(() => {
        if (!open || kind !== "video") {
          setProbe(null);
          setProbeError(null);
          setProbing(false);
          return undefined;
        }
        const value = urlList.length === 1 ? urlList[0] : "";
        if (value.length === 0) {
          setProbe(null);
          setProbeError(null);
          setProbing(false);
          return undefined;
        }
        let disposed = false;
        const timer = setTimeout(async () => {
          setProbing(true);
          setProbeError(null);
          try {
            const result = await api("/api/import-probe", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ url: value }),
            });
            if (disposed) return;
            setProbe(result);
            setHeight((previous) => {
              const numeric = result.heights?.some((item) => String(item.height) === previous);
              if (previous !== "best" && numeric) return previous;
              return result.recommended !== null ? String(result.recommended) : "best";
            });
          } catch (failure) {
            if (!disposed) {
              setProbe(null);
              setProbeError(failure instanceof Error ? failure.message : String(failure));
            }
          } finally {
            if (!disposed) setProbing(false);
          }
        }, 700);
        return () => { disposed = true; clearTimeout(timer); };
      }, [open, urlList.length === 1 ? urlList[0] : "", kind, probeNonce]);

      React.useEffect(() => {
        if (!open || !anyActive) return undefined;
        let disposed = false;
        let inFlight = false;
        const timer = setInterval(async () => {
          if (inFlight) return;
          inFlight = true;
          try {
            const status = await api("/api/import");
            if (!disposed) {
              setCaps(status);
              if (Array.isArray(status.jobs)) setJobs(status.jobs);
            }
          } catch (failure) {
            if (!disposed) setError(failure instanceof Error ? failure.message : String(failure));
          } finally {
            inFlight = false;
          }
        }, 800);
        return () => { disposed = true; clearInterval(timer); };
      }, [open, anyActive]);

      React.useEffect(() => {
        if (!open || qr === null || qr.status === "ok" || qr.status === "expired") return undefined;
        let disposed = false;
        let inFlight = false;
        const timer = setInterval(async () => {
          if (inFlight) return;
          inFlight = true;
          try {
            const response = await api("/api/import-auth", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ action: "poll", key: qr.key }),
            });
            if (disposed) return;
            if (response.status === "ok") {
              setAuth(response.auth ?? { loggedIn: true });
              setQr(null);
              setAuthError(null);
              setProbeNonce((value) => value + 1);
            } else if (response.status === "expired") {
              setQr((previous) => previous === null ? null : { ...previous, status: "expired" });
            } else {
              setQr((previous) => previous === null ? null : { ...previous, status: response.status });
            }
          } catch (failure) {
            if (!disposed) {
              setAuthError(failure instanceof Error ? failure.message : String(failure));
              setQr(null);
            }
          } finally {
            inFlight = false;
          }
        }, 1500);
        return () => { disposed = true; clearInterval(timer); };
      }, [open, qr?.key, qr?.status]);

      React.useEffect(() => {
        if (!open) return;
        const fresh = jobs.filter((job) => job.phase === "done" && !doneNotified.current.has(job.id));
        if (fresh.length === 0) return;
        for (const job of fresh) doneNotified.current.add(job.id);
        onDone();
      }, [open, jobs]);

      const start = async () => {
        const urls = importUrlList(url);
        if (urls.length === 0) {
          setError(t("import.emptyUrls"));
          return;
        }
        setStarting(true);
        setError(null);
        try {
          const status = await api("/api/import", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ urls, kind, height: kind === "video" && height !== "best" ? Number(height) : null }),
          });
          setCaps(status);
          const created = Array.isArray(status.jobs) ? status.jobs : (status.job ? [status.job] : []);
          setJobs((previous) => {
            const map = new Map<string, any>();
            for (const job of previous) map.set(job.id, job);
            for (const job of created) map.set(job.id, job);
            return [...map.values()].sort((a: any, b: any) => a.startedAt - b.startedAt);
          });
          setUrl("");
        } catch (failure) {
          setError(failure instanceof Error ? failure.message : String(failure));
        } finally {
          setStarting(false);
        }
      };
      const cancel = async (id) => {
        setCancelling((previous) => ({ ...previous, [id]: true }));
        try {
          const status = await api("/api/import-cancel", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ id }),
          });
          setCaps(status);
          if (Array.isArray(status.jobs)) setJobs(status.jobs);
        } catch (failure) {
          setError(failure instanceof Error ? failure.message : String(failure));
        } finally {
          setCancelling((previous) => {
            const next = { ...previous };
            delete next[id];
            return next;
          });
        }
      };
      const cancelAll = async () => {
        setStarting(true);
        try {
          const status = await api("/api/import-cancel", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ all: true }),
          });
          setCaps(status);
          if (Array.isArray(status.jobs)) setJobs(status.jobs);
        } catch (failure) {
          setError(failure instanceof Error ? failure.message : String(failure));
        } finally {
          setStarting(false);
        }
      };

      const loginQr = async () => {
        setAuthError(null);
        try {
          const response = await api("/api/import-auth", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ action: "qr" }),
          });
          setQr({ key: response.key, qr: response.qr, status: "waiting" });
        } catch (failure) {
          setAuthError(failure instanceof Error ? failure.message : String(failure));
        }
      };
      const logout = async () => {
        setAuthError(null);
        try {
          await api("/api/import-auth", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ action: "logout" }),
          });
          setAuth({ loggedIn: false });
          setQr(null);
          setProbeNonce((value) => value + 1);
        } catch (failure) {
          setAuthError(failure instanceof Error ? failure.message : String(failure));
        }
      };
      const biliUrl = urlList.some((raw) => {
        try {
          const host = new URL(raw).hostname.toLowerCase();
          return host === "b23.tv" || host === "bilibili.com" || host.endsWith(".bilibili.com");
        } catch {
          return false;
        }
      });
      const formatOption = (item) => {
        const size = item.filesize !== null ? " · " + t("import.approx") + " " + Math.round(item.filesize / 1048576) + " MB" : "";
        const fps = item.fps !== null ? " · " + item.fps + "fps" : "";
        const recommended = probe !== null && item.height === probe.recommended ? " · " + t("import.recommended") : "";
        return item.height + "P" + fps + size + recommended;
      };

      if (!open) return null;
      const available = caps?.available === true;
      const canStart = available && urlList.length > 0 && !starting;
      const phaseLabel = (job) =>
        job.phase === "queued" ? t("import.phase.queued")
        : job.phase === "metadata" ? t("import.phase.metadata")
        : job.phase === "download" ? t("import.phase.download")
        : job.phase === "finalize" ? t("import.phase.finalize")
        : job.phase === "done" ? t("import.done")
        : job.phase === "cancelled" ? t("import.cancelled")
        : job.phase === "starting" ? t("import.phase.starting")
        : job.phase === "error" ? t("import.phase.error")
        : "";
      const renderJob = (job) => {
        const running = IMPORT_ACTIVE_PHASES.has(job.phase);
        const progressText = job.phase === "queued" || job.phase === "done" || job.phase === "cancelled" || job.phase === "error"
          ? ""
          : " · " + job.progress + "%";
        return h("div", { className: "dshm-importJob", key: job.id },
          h("div", { className: "dshm-importJobHead" },
            h("span", { className: "dshm-importStatus" }, phaseLabel(job) + progressText),
            running && h("button", {
              type: "button",
              className: "dshm-importCancel",
              disabled: cancelling[job.id] === true,
              onClick: () => void cancel(job.id),
            }, cancelling[job.id] === true ? t("import.cancelling") : t("import.cancel"))),
          h("div", {
            className: "dshm-importProgress",
            role: "progressbar",
            "aria-valuemin": 0,
            "aria-valuemax": 100,
            "aria-valuenow": job.progress,
          }, h("div", { className: "dshm-importBar", style: { width: job.progress + "%" } })),
          h("div", { className: "dshm-importMeta" }, job.title !== null ? [job.title, job.artist].filter(Boolean).join(" · ") : job.url),
          (job.speed !== null || job.eta !== null) && h("div", { className: "dshm-importHint" },
            [job.speed !== null ? t("import.speed") + " " + job.speed : "", job.eta !== null ? t("import.eta") + " " + job.eta : ""].filter(Boolean).join(" · ")),
          job.phase === "done" && h("div", { className: "dshm-importDone" },
            t("import.done") + (job.file !== null ? " · " + t("import.savedAs") + " " + job.file : "")),
          job.warning !== null && h("div", { className: "dshm-importWarn" }, t("import.warning") + job.warning),
          job.error !== null && h("div", { className: "dshm-importError" }, t("import.errorPrefix") + job.error),
        );
      };

      return h("div", {
        ref: layerRef,
        className: "dshm-modal",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": t("import.title"),
        onClick: requestClose,
      },
        h("div", { className: "dshm-dialog dshm-importDialog", onClick: (event) => event.stopPropagation() },
          h("div", { className: "dshm-dialogHead" }, t("import.title")),
          h("div", { className: "dshm-importBody" },
            caps !== null && caps.available === false && h("div", { className: "dshm-importError" },
              h("div", null, t("import.missing")),
              h("div", null, t("import.missingHint"))),
            h("label", { className: "dshm-importLabel", htmlFor: "music-import-url" }, t("import.urlLabel")),
            h("textarea", {
              id: "music-import-url",
              className: "dshm-importInput",
              rows: 3,
              value: url,
              autoFocus: true,
              disabled: starting,
              spellCheck: false,
              placeholder: t("import.urlPlaceholder"),
              onChange: (event) => setUrl(event.target.value),
              onKeyDown: (event) => {
                if (event.key === "Enter" && (event.metaKey || event.ctrlKey) && canStart) {
                  event.preventDefault();
                  void start();
                }
              },
            }),
            h("div", { className: "dshm-importHint" }, t("import.urlHint")),
            h("div", { className: "dshm-importHint" }, t("import.unsupported")),
            h("div", { className: "dshm-importLabel" }, t("import.kind")),
            h("div", { className: "dshm-importKinds", role: "group", "aria-label": t("import.kind") },
              h("button", {
                type: "button",
                className: "dshm-importKind" + (kind === "audio" ? " dshm-importKind--active" : ""),
                "aria-pressed": kind === "audio",
                disabled: starting,
                onClick: () => setKind("audio"),
              }, t("import.audio")),
              h("button", {
                type: "button",
                className: "dshm-importKind" + (kind === "video" ? " dshm-importKind--active" : ""),
                "aria-pressed": kind === "video",
                disabled: starting,
                onClick: () => setKind("video"),
              }, t("import.video"))),
            h("div", { className: "dshm-importHint" }, kind === "audio" ? t("import.audioHint") : t("import.videoHint")),
            h("div", { className: "dshm-importHint" }, t("import.target") + (dir ?? "")),
            h("div", { className: "dshm-importNotice" }, t("import.notice")),
            kind === "video" && h("div", { className: "dshm-importQualityRow" },
              h("label", { className: "dshm-importLabel", htmlFor: "music-import-quality" }, t("import.quality")),
              h("select", {
                id: "music-import-quality",
                className: "dshm-importSelect",
                value: height,
                disabled: starting,
                onChange: (event) => setHeight(event.target.value),
              },
                h("option", { value: "best" }, t("import.qualityBest")),
                (probe?.heights ?? []).map((item) => h("option", { key: String(item.height), value: String(item.height) }, formatOption(item)))),
              h("div", { className: "dshm-importHint" },
                urlList.length > 1 ? t("import.batchHint")
                  : probing ? t("import.probing")
                    : probeError !== null ? t("import.probeError")
                      : t("import.qualityHint"))),
            urlList.length > 1 && h("div", { className: "dshm-importHint" }, t("import.batchHint")),
            probeError !== null && h("div", { className: "dshm-importHint" }, probeError),
            probe !== null && h("div", { className: "dshm-importProbeMeta" }, [probe.title, probe.artist].filter(Boolean).join(" · ")),
            biliUrl && h("div", { className: "dshm-importLogin" },
              h("div", { className: "dshm-importLoginRow" },
                h("span", { className: "dshm-importLabel" }, t("import.login")),
                h("span", { className: "dshm-importHint" },
                  auth?.loggedIn === true
                    ? t("import.loginLogged") + (auth.uname ?? "") + (auth.vip === true ? " · " + t("import.vip") : "")
                    : t("import.loginHint")),
                auth?.loggedIn === true
                  ? h("button", { type: "button", className: "dshm-importLinkBtn", onClick: () => void logout() }, t("import.logout"))
                  : h("button", { type: "button", className: "dshm-importLinkBtn", onClick: () => void loginQr() }, t("import.loginButton"))),
              authError !== null && h("div", { className: "dshm-importError" }, t("import.qrError") + authError),
              qr !== null && h("div", { className: "dshm-importQrBox" },
                h("img", { className: "dshm-importQr", src: qr.qr, alt: "" }),
                h("div", { className: "dshm-importQrStatus" },
                  qr.status === "scanned" ? t("import.qrScanned") : qr.status === "expired" ? t("import.qrExpired") : t("import.qrWaiting")),
                h("div", { className: "dshm-importHint" }, t("import.qrHint")),
                qr.status === "expired" && h("button", { type: "button", className: "dshm-importLinkBtn", onClick: () => void loginQr() }, t("import.qrRefresh"))),
              h("div", { className: "dshm-importHint" }, t("import.loginSaved"))),
            jobs.length > 0 && h("div", { className: "dshm-importJobs" }, jobs.map(renderJob)),
            error !== null && h("div", { className: "dshm-importError", role: "alert" }, error),
          ),
          h("div", { className: "dshm-dialogFoot" },
            h("span", { className: "dshm-importFootHint" }, anyActive ? t("import.backgroundHint") : caps?.ytdlp ? "yt-dlp " + caps.ytdlp : ""),
            h("span", { style: { display: "flex", gap: "8px" } },
              anyActive && activeJobs.length > 1 && h("button", {
                type: "button", className: "dshm-btn", disabled: starting, onClick: () => void cancelAll(),
              }, t("import.cancelAll")),
              h("button", { type: "button", className: "dshm-btn", onClick: requestClose }, t("import.close")),
              h("button", {
                type: "button",
                className: "dshm-btn",
                disabled: !canStart,
                onClick: () => void start(),
              }, starting ? t("import.starting") : t("import.start")))),
        ));
    }

    /** MV 海报墙：视频用封面卡片，音频继续用表格。 */
    const MvGrid = React.memo(function MvGrid({ rows, current, player, t, effective, coverFor, onMenu }) {
      return h("div", { className: "dshm-mvGrid" },
        rows.map(({ track, index }) => {
          const item = effective(track);
          return h("div", {
            key: index + ":" + track.name,
            className: "dshm-mvCard" + (index === current ? " dshm-mvCard--active" : ""),
            role: "button",
            tabIndex: 0,
            "aria-label": item.title,
            "aria-current": index === current ? "true" : undefined,
            onClick: () => player.play(index),
            onKeyDown: (event) => {
              if (event.target !== event.currentTarget) return;
              if (event.key !== "Enter" && event.key !== " ") return;
              event.preventDefault();
              player.play(index);
            },
          },
            h("div", { className: "dshm-mvThumb" },
              h("img", {
                src: coverFor(track),
                alt: "",
                loading: "lazy",
                decoding: "async",
                onError: (event) => { event.currentTarget.style.visibility = "hidden"; },
              }),
              h("span", { className: "dshm-mvPlay" }, ICONS.play)),
            h("div", { className: "dshm-mvCardTitle" }, item.title),
            h("div", { className: "dshm-mvCardMeta" }, [item.artist, formatTime(track.duration)].filter((value) => typeof value === "string" && value.length > 0).join(" · ")),
            h("div", { className: "dshm-mvCardMenu" },
              withTipWrapped(h("button", {
                type: "button",
                className: "dshm-rowMenuBtn",
                "aria-label": t("action.more") + ": " + item.title,
                "aria-haspopup": "menu",
                onClick: (event) => {
                  event.stopPropagation();
                  onMenu(track, event);
                },
              }, "⋯"), t("action.more"))),
          );
        }));
    });

    function MusicView() {
      const state = useSyncExternalStore(player.subscribe, player.getState);
      const activeRowRef = useRef(null);
      // player.t 由 apply() 在注册字典之后注入，而本视图只可能在 apply() 里
      // ctx.slots.register 之后被渲染 —— 所以这里必然已经赋值（非空断言可证）。
      const t = player.t!;

      useEffect(() => {
        if (state.dir === null && state.tracks.length === 0 && !state.loading && state.scannedAt === null) player.load();
        // eslint-disable-next-line react-hooks/exhaustive-deps
      }, []);
      useEffect(() => {
        activeRowRef.current?.scrollIntoView({ block: "nearest" });
      }, [state.current]);

      const currentTrack = state.current >= 0 ? state.tracks[state.current] : undefined;
      /** 播放条展示的是叠加在线补全后的信息。 */
      const currentView = player.effective(currentTrack);
      const busy = state.loading || state.picking;

      // The conversation shell lets the view area grow with content
      // (flex:1 0 auto) and scrolls it in its own scrollport — which leaves
      // the player bar below the fold and eats wheel gestures over the list.
      // Pin the root to the scrollport's height instead: fixed header/bar,
      // internally scrolling track list (macOS Music layout).
      const rootRef = useRef(null);
      useEffect(() => {
        const root = rootRef.current;
        if (root === null) return undefined;
        const scrollport = root.closest("[data-conversation-scroll]") ?? root.parentElement;
        if (scrollport === null) return undefined;
        const sync = () => {
          // The composer floats over the scrollport's lower edge; keep the
          // player bar above it (shell publishes --dsh-composer-height).
          const raw = getComputedStyle(scrollport).getPropertyValue("--dsh-composer-height");
          const composer = Number.parseFloat(raw);
          const height = scrollport.clientHeight - (Number.isFinite(composer) ? composer : 0);
          if (height > 0) root.style.height = height + "px";
        };
        sync();
        const observer = new ResizeObserver(sync);
        observer.observe(scrollport);
        // The composer height var changes without resizing the scrollport.
        const mutations = new MutationObserver(sync);
        mutations.observe(scrollport, { attributes: true, attributeFilter: ["style"] });
        return () => {
          observer.disconnect();
          mutations.disconnect();
          root.style.height = "";
        };
      }, []);

      // 手动输入目录路径（原生选择器之外的兜底；Windows 可用 D:\Music 之类路径）
      const [dirInputOpen, setDirInputOpen] = useState(false);
      const [importOpen, setImportOpen] = useState(false);
      const [importJobsActive, setImportJobsActive] = useState(0);
      const [rowMenu, setRowMenu] = useState(null);

      // 后台导入：视图挂载时找回宿主里仍在跑的任务；有任务时轮询，归零后刷新列表。
      React.useEffect(() => {
        let disposed = false;
        void api("/api/import").then((status) => {
          if (disposed) return;
          const active = (Array.isArray(status.jobs) ? status.jobs : []).filter((job) => IMPORT_ACTIVE_PHASES.has(job.phase)).length;
          if (active > 0) setImportJobsActive(active);
        }).catch(() => {});
        return () => { disposed = true; };
      }, []);
      React.useEffect(() => {
        if (importJobsActive <= 0) return undefined;
        let disposed = false;
        let inFlight = false;
        const timer = setInterval(async () => {
          if (inFlight) return;
          inFlight = true;
          try {
            const status = await api("/api/import");
            if (disposed) return;
            const active = (Array.isArray(status.jobs) ? status.jobs : []).filter((job) => IMPORT_ACTIVE_PHASES.has(job.phase)).length;
            if (active === 0) {
              setImportJobsActive(0);
              void player.refresh();
            } else {
              setImportJobsActive(active);
            }
          } catch {
            // 后台轮询失败不打断播放；下一拍再试。
          } finally {
            inFlight = false;
          }
        }, 2000);
        return () => { disposed = true; clearInterval(timer); };
      }, [importJobsActive]);
      const [dirInputValue, setDirInputValue] = useState("");

      // 底部条专辑封面：无内嵌封面时回退音符图标（补全封面变化也要重试）
      const [coverFailed, setCoverFailed] = useState(false);
      // 全屏播放器（Apple Music 风格）：点底部封面打开，Esc / 收起按钮关闭
      // 弹层三态：closed → open → closing（留 200ms 播完退出动画再卸载，对应
      // Apple Music 弹层的 modalZoomIn / modalZoomOut）。
      // **状态必须在 player store 里，不能是这里的 useState**：切到对话时
      // conversation.view 会卸载本视图，局部状态一起丢，回来就只剩列表页
      // （用户报的「切出去再切回来，全屏播放器不留存」）。退出动画的定时器
      // 同理归 player（见 closePlayer），否则视图卸载会清掉它、卡在 closing。
      const playerPhase = state.playerPhase;
      const playerOpen = playerPhase !== "closed";
      // 收藏与列表视图都在 player store：视图卸载/重挂后仍保留，且 next/prev 与行过滤同源。
      const favorites = state.favorites;
      // 队列行的「⋯」菜单当前展开在哪首歌上

      const [queueMenu, setQueueMenu] = useState(null);
      /** 封面放大预览（只给音频封面）与 MV 就地放大：同样放进 player store 跨卸载保留。 */
      const zoomOpen = state.zoomOpen;
      const mvBig = state.mvBig;
      const [webFullscreen, setWebFullscreen] = React.useState(false);
      /** MV 画面槽（媒体元素会被搬进来）与隐藏停靠位（弹层关着时停在这儿）。 */
      const mvStageRef = useRef(null);
      const mvParkRef = useRef(null);
      const playerRef = useRef(null);
      const [nativeFullscreen, setNativeFullscreen] = React.useState(false);
      const [controlsIdle, setControlsIdle] = React.useState(false);
      const immersive = webFullscreen || nativeFullscreen;
      const isVideo = currentTrack !== undefined && currentTrack.kind === "video";
      const mvState = state.mv;

      /** Safari/旧 Electron 用 webkit 前缀；标准 API 优先。 */
      const fullscreenElement = () => {
        const doc = document as unknown as { fullscreenElement?: Element | null; webkitFullscreenElement?: Element | null };
        return doc.fullscreenElement ?? doc.webkitFullscreenElement ?? null;
      };
      const exitNativeFullscreen = () => {
        const doc = document as unknown as { exitFullscreen?: () => Promise<void>; webkitExitFullscreen?: () => void };
        const exit = typeof doc.exitFullscreen === "function" ? doc.exitFullscreen : doc.webkitExitFullscreen;
        if (typeof exit !== "function") return;
        try {
          const result = exit.call(document) as Promise<void> | void;
          if (result !== undefined && typeof result.catch === "function") result.catch(() => {});
        } catch { /* 不是全屏态 / 权限已撤销：没有可退的 */ }
      };
      const toggleWebFullscreen = () => {
        if (nativeFullscreen) exitNativeFullscreen();
        setWebFullscreen((previous) => !previous);
      };
      const toggleNativeFullscreen = () => {
        if (nativeFullscreen) {
          exitNativeFullscreen();
          return;
        }
        if (webFullscreen) setWebFullscreen(false);
        const element = playerRef.current as HTMLElement | null;
        if (element === null) return;
        const request = element.requestFullscreen
          ?? (element as unknown as { webkitRequestFullscreen?: () => Promise<void> | void }).webkitRequestFullscreen;
        if (typeof request !== "function") return;
        try {
          const result = request.call(element) as Promise<void> | void;
          if (result !== undefined && typeof result.catch === "function") result.catch(() => {});
        } catch { /* 用户手势/策略拒绝：保持窗口态 */ }
      };
      const closeFullPlayer = () => {
        if (fullscreenElement() != null) exitNativeFullscreen();
        player.closePlayer();
      };

      // 原生全屏由浏览器驱动：按钮、F、浏览器自己的 Esc 都走同一个 fullscreenchange。
      React.useEffect(() => {
        const onChange = () => setNativeFullscreen(fullscreenElement() === playerRef.current);
        document.addEventListener("fullscreenchange", onChange);
        document.addEventListener("webkitfullscreenchange", onChange);
        return () => {
          document.removeEventListener("fullscreenchange", onChange);
          document.removeEventListener("webkitfullscreenchange", onChange);
          if (fullscreenElement() === playerRef.current) exitNativeFullscreen();
        };
      }, []);
      // 收起播放器时不要把人留在系统全屏里。
      React.useEffect(() => {
        if (!playerOpen && fullscreenElement() === playerRef.current) exitNativeFullscreen();
      }, [playerOpen]);
      // 播放器里从 MV 切到纯音频：退出两种全屏，别让音频铺满屏幕。
      React.useEffect(() => {
        if (playerOpen && isVideo) return;
        setWebFullscreen(false);
        if (nativeFullscreen) exitNativeFullscreen();
      }, [playerOpen, isVideo, nativeFullscreen]);
      // 沉浸模式播放时 2.6s 无操作淡出控制层；暂停/移动/按键立即唤醒。
      React.useEffect(() => {
        if (!immersive || !state.playing) {
          setControlsIdle(false);
          return undefined;
        }
        let timer: ReturnType<typeof setTimeout> | null = null;
        const wake = () => {
          setControlsIdle(false);
          if (timer !== null) clearTimeout(timer);
          timer = setTimeout(() => setControlsIdle(true), 2600);
        };
        wake();
        const element = playerRef.current as HTMLElement | null;
        const wakeKey = (event) => { if (event.key !== "Escape") wake(); };
        element?.addEventListener("pointermove", wake);
        element?.addEventListener("pointerdown", wake);
        window.addEventListener("keydown", wakeKey);
        return () => {
          if (timer !== null) clearTimeout(timer);
          element?.removeEventListener("pointermove", wake);
          element?.removeEventListener("pointerdown", wake);
          window.removeEventListener("keydown", wakeKey);
        };
      }, [immersive, state.playing]);
      useEffect(() => () => {
        // 视图卸载（切回对话/关标签）：把媒体元素搬回 body 停靠位，别让它离开文档。
        const media = player.media();
        const park = player.mediaPark();
        if (media === null || media === undefined || typeof media.nodeType !== "number") return;
        if (park !== null && park !== undefined && media.parentElement !== park) park.appendChild(media);
      }, []);
      useEffect(() => {
        // 移动父节点不会中断 <video> 播放（实测 t 连续推进），所以可以直接搬。
        const media = player.media();
        // 测试里的假元素不是 DOM 节点（没有 nodeType），此时不做搬运。
        if (media === null || media === undefined || typeof media.nodeType !== "number") return;
        const target = isVideo && playerOpen ? mvStageRef.current : mvParkRef.current;
        if (target === null || target === undefined || media.parentElement === target) return;
        target.appendChild(media);
        // zoomOpen 必须在依赖里：放大预览打开时要把画面搬进预览层（漏了它就搬不过去）。
      }, [isVideo, playerOpen, zoomOpen, currentTrack?.id, mvState?.state]);
      useEffect(() => {
        // 封面当 MV 的海报（首帧出来前不闪黑屏）。这里自己取封面，别依赖
        // render 后段才定义的 playerCoverSrc（那会在依赖数组里踩 TDZ）。
        const media = player.media();
        if (media === null || media === undefined) return;
        const poster = isVideo && currentTrack !== undefined && !coverFailed ? player.coverFor(currentTrack) : "";
        if (media.poster !== poster) media.poster = poster;
      }, [isVideo, currentTrack?.id, coverFailed]);
      useEffect(() => {
        if (!playerOpen) return undefined;
        const onKeyDown = (event) => {
          if (event.key === "Escape") {
            // 现场读 store 而不是闭包捕获：这个 effect 只在 playerOpen 变化时重挂，
            // 捕获 mvBig / zoomOpen 会读到旧值，Esc 的手感就取决于上一次渲染。
            const live = player.getState();
            if (fullscreenElement() != null) { exitNativeFullscreen(); return; }
            if (webFullscreen) { setWebFullscreen(false); return; }
            if (live.mvBig) { player.toggleMvBig(); return; }    // Esc：先还原 MV 大小
            if (live.zoomOpen) { player.setZoomOpen(false); return; } // 再关封面预览，最后才关播放器
            closeFullPlayer();
            return;
          }
          // 输入框里的按键归输入框（搜索框等），不是全局播放快捷键。
          // 客户端 bundle 在 jsdom 里没有 HTMLElement 全局：用 tagName 鸭子类型判断。
          const target = event.target;
          const tag = target !== null && typeof target === "object" && typeof target.tagName === "string"
            ? target.tagName : "";
          const editable = target !== null && typeof target === "object" && target.isContentEditable === true;
          if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || editable) return;
          if (player.getState().playerPhase === "closed") return;
          if (isVideo && (event.key === "f" || event.key === "F")) {
            event.preventDefault();
            toggleNativeFullscreen();
            return;
          }
          if (isVideo && (event.key === "t" || event.key === "T")) {
            event.preventDefault();
            toggleWebFullscreen();
            return;
          }
          if (event.key === " " || event.code === "Space") {
            // 焦点在按钮/链接上时空格是"点击它"，不能抢。
            if (tag === "BUTTON" || tag === "A") return;
            event.preventDefault();
            player.toggle();
            return;
          }
          const step = event.shiftKey ? 1 : 5;
          if (event.key === "ArrowRight") {
            event.preventDefault();
            player.seek(Math.min(player.now() + step, player.getState().duration || Infinity));
            return;
          }
          if (event.key === "ArrowLeft") {
            event.preventDefault();
            player.seek(Math.max(0, player.now() - step));
            return;
          }
          if (event.key === "ArrowUp") {
            event.preventDefault();
            player.setVolume(Math.min(1, player.getState().volume + 0.05));
            return;
          }
          if (event.key === "ArrowDown") {
            event.preventDefault();
            player.setVolume(Math.max(0, player.getState().volume - 0.05));
          }
        };
        window.addEventListener("keydown", onKeyDown);
        return () => window.removeEventListener("keydown", onKeyDown);
      }, [playerOpen, isVideo, nativeFullscreen, webFullscreen]);
      // 删除确认条在主视图里；弹层开着会把它盖住，所以进入确认态就自动收起弹层
      useEffect(() => {
        if (state.pendingDelete >= 0) player.closePlayer();
      }, [state.pendingDelete]);
      // Escape 的优先级：全屏播放器（上一个 effect）> 补全弹层（层内自己处理）> 内联确认条。
      // 确认条不是覆盖层，没有自己的键盘处理，这里兜住。
      useEffect(() => {
        const onKeyDown = (event) => {
          if (event.key !== "Escape") return;
          const live = player.getState();
          if (live.match !== null) return;
          if (live.pendingDelete >= 0) {
            event.preventDefault();
            player.cancelRemove();
            return;
          }
          if (live.pendingComplete) {
            event.preventDefault();
            player.cancelComplete();
          }
        };
        window.addEventListener("keydown", onKeyDown);
        return () => window.removeEventListener("keydown", onKeyDown);
      }, [player]);
      useEffect(() => setCoverFailed(false), [currentTrack?.id, state.meta]);

      // 补全弹层的搜索框：打开弹层或服务端返回实际搜索词后同步显示
      const [matchTerm, setMatchTerm] = useState("");
      useEffect(() => {
        const current = state.match;
        setMatchTerm(current !== null && typeof current.term === "string" ? current.term : "");
      }, [state.match?.id, state.match?.term]);

      // 搜索：输入框即时回显，过滤按 SEARCH_DEBOUNCE_MS 防抖（每次按键就重算全量筛选+排序会卡）。
      const [queryDraft, setQueryDraft] = useState(state.query);
      const queryDraftRef = useRef(state.query);
      const queryTimerRef = useRef(null);
      // 搜索框收在放大镜按钮里：点击展开、Esc/失焦收起；关闭时保留筛选结果并点亮小圆点。
      const [searchOpen, setSearchOpen] = useState(false);
      const searchBoxRef = useRef(null);
      const searchToggleRef = useRef(null);
      const searchWasOpen = useRef(false);
      useEffect(() => {
        setQueryDraft(state.query);
        queryDraftRef.current = state.query;
      }, [state.query]);
      useEffect(() => () => {
        if (queryTimerRef.current !== null) clearTimeout(queryTimerRef.current);
      }, []);
      const clearQuery = () => {
        setQueryDraft("");
        queryDraftRef.current = "";
        if (queryTimerRef.current !== null) {
          clearTimeout(queryTimerRef.current);
          queryTimerRef.current = null;
        }
        player.setQuery("");
      };
      const applyQuerySoon = (value) => {
        setQueryDraft(value);
        queryDraftRef.current = value;
        if (queryTimerRef.current !== null) clearTimeout(queryTimerRef.current);
        queryTimerRef.current = setTimeout(() => {
          queryTimerRef.current = null;
          player.setQuery(queryDraftRef.current);
        }, SEARCH_DEBOUNCE_MS);
      };

      // 展开后聚焦输入框；关闭时把焦点还给放大镜按钮。
      // 通过 DOM 查询而不是组件 ref：官方 Input 与原生 input 两条渲染路径共用同一套行为。
      useEffect(() => {
        if (searchOpen) {
          searchWasOpen.current = true;
          const input = searchBoxRef.current?.querySelector?.("input");
          if (input !== null && input !== undefined && typeof input.focus === "function") input.focus();
          return undefined;
        }
        if (searchWasOpen.current) {
          searchWasOpen.current = false;
          const toggle = searchToggleRef.current;
          if (toggle !== null && typeof toggle.focus === "function") toggle.focus();
        }
        return undefined;
      }, [searchOpen]);

      // 是否把补全结果写回文件（写标签 + 重命名），默认开启
      const [writeFile, setWriteFile] = useState(true);
      // 手动应用默认替换封面：用户已经看到了候选的封面并主动点选它。
      const [replaceCover, setReplaceCover] = useState(true);

      // 可见列表 = 播放队列：筛选 + 排序统一在 player.visibleRows() 里计算，
      // 这里渲染的顺序就是 next/prev/自动下一首将走的顺序。
      const visibleTracks = player.visibleRows();
      const volumePct = Math.round(state.volume * 100);

      /**
       * ReplayGain 按钮：点一下循环 `off → track → album`（与 fooyin 的三种模式一致）。
       * 前级增益属进阶设置，不进 UI —— 用 `player.setReplayGain(mode, preampDb)` 设。
       * 标签用缩写「RG」，完整含义在 tooltip 与 aria-label 里（两处都走字典）。
       */
      const rgModeLabel = state.rgMode === "album"
        ? t("rg.album")
        : (state.rgMode === "track" ? t("rg.track") : t("rg.off"));
      const rgTip = state.rgMeasuring
        ? t("rg.measuring")(state.rgMeasureDone, state.rgMeasureTotal)
        : t("rg.label") + " · " + rgModeLabel;
      const rgButton = (placement) => withTipWrapped(h("button", {
        type: "button",
        className: "dshm-mode dshm-rg" + (state.rgMode === "off" ? "" : " dshm-rg--on"),
        onClick: (event) => {
          event.stopPropagation();
          player.setReplayGain(state.rgMode === "off" ? "track" : (state.rgMode === "track" ? "album" : "off"));
        },
        "aria-label": t("rg.label") + ": " + rgModeLabel,
      }, "RG"), rgTip, placement);

      /** 均衡器按钮：点一下在预设之间循环（flat → 流行 → 摇滚 → … → flat）。 */
      const eqPresetLabel = t("eq." + (EQ_PRESETS[state.eqPreset] !== undefined ? state.eqPreset : "flat"));
      const eqButton = (placement) => withTipWrapped(h("button", {
        type: "button",
        className: "dshm-mode dshm-rg" + (state.eqBands.some((v) => Math.abs(v) > 0.01) ? " dshm-rg--on" : ""),
        onClick: (event) => {
          event.stopPropagation();
          const at = EQ_PRESET_ORDER.indexOf(state.eqPreset);
          player.setEqualizer(EQ_PRESET_ORDER[(at + 1) % EQ_PRESET_ORDER.length]);
        },
        "aria-label": t("eq.label") + ": " + eqPresetLabel,
      }, "EQ"), t("eq.label") + " · " + eqPresetLabel, placement);

      // 滚轮：音量条 ±5%（进度条的滚轮在 ProgressBar 内处理）。
      const volumeWheelRef = useWheelHandler((event) => {
        const delta = (event.deltaY < 0 ? 0.05 : -0.05);
        player.setVolume(Math.max(0, Math.min(1, Math.round((state.volume + delta) * 100) / 100)));
      });

      const header = h("div", { className: "dshm-header" },
        withTipWrapped(h("button", {
          type: "button",
          className: "dshm-headerToggle" + (state.sidebarOpen ? " dshm-headerToggle--open" : ""),
          "aria-label": state.sidebarOpen ? t("sidebar.collapse") : t("sidebar.expand"),
          "aria-expanded": state.sidebarOpen,
          "aria-controls": "dshm-sidebar",
          onClick: () => player.toggleSidebar(),
        }, ICONS.note),
          state.sidebarOpen ? t("sidebar.collapse") : t("sidebar.expand")),
        h("span", { className: "dshm-title" }, state.section === "favorites"
          ? t("view.favorites")
          : state.section === "recent"
            ? t("view.recent")
            : state.mediaFilter === "video" ? t("view.mv")
              : state.mediaFilter === "audio" ? t("view.audio")
                : t("view.allSongs")),
        // 目录名经常长到溢出：悬停给出完整路径（官方 Tooltip，贴着 header 下沿弹出）
        withTip(h("span", { className: "dshm-dir" }, state.dir ?? t("empty.title")), state.dir ?? "", "bottom"),
        // 搜索框用官方 Input 组件（与 DSH 自己的搜索框同源）：组件自带 32px wrap、
        // 前置图标位、focus-within 主题色描边。取不到官方组件时退回原输入框。
        state.tracks.length > 0 && h("div", {
          className: "dshm-searchBox" + (searchOpen ? " dshm-searchBox--open" : ""),
          ref: searchBoxRef,
          // 焦点移出整个搜索区才收起；点“清除”或再次点放大镜都不会先被 blur 打断。
          onBlur: (event) => {
            if (!event.currentTarget.contains(event.relatedTarget)) setSearchOpen(false);
          },
          onKeyDown: (event) => {
            if (event.key !== "Escape" || !searchOpen) return;
            event.preventDefault();
            event.stopPropagation();
            setSearchOpen(false);
          },
        },
          withTipWrapped(h("button", {
            type: "button",
            className: "dshm-searchToggle" + (queryDraft.length > 0 ? " dshm-searchToggle--active" : ""),
            ref: searchToggleRef,
            "aria-label": searchOpen ? t("action.closeSearch") : t("action.search"),
            "aria-expanded": searchOpen,
            "aria-controls": searchOpen ? "music-search-input" : undefined,
            onClick: () => setSearchOpen((open) => !open),
          },
            h("svg", { width: 16, height: 16, viewBox: "0 0 16 16", fill: "none", "aria-hidden": "true" },
              h("circle", { cx: "7.1", cy: "7.1", r: "4.7", stroke: "currentColor", strokeWidth: 1.4 }),
              h("path", { d: "M10.6 10.6 14 14", stroke: "currentColor", strokeWidth: 1.4, strokeLinecap: "round" })),
            !searchOpen && queryDraft.length > 0 && h("span", { className: "dshm-searchBadge", "aria-hidden": "true" })),
            searchOpen ? t("action.closeSearch") : (queryDraft.length > 0 ? t("action.search") + " · " + t("search.active") : t("action.search")), "bottom"),
          searchOpen && h("div", { className: "dshm-searchField" },
            searchField({
              id: "music-search-input",
              autoFocus: true,
              placeholder: t("action.search.placeholder"),
              value: queryDraft,
              // onInput 直接映射原生 input 事件；受控输入上只挂 onChange 时，React 的 value
              // tracker 会吞掉「原生 setter + input 事件」这条测试与 IME 路径。
              onChange: (event) => applyQuerySoon(event.target.value),
              onInput: (event) => applyQuerySoon(event.target.value),
            }),
            queryDraft.length > 0 && h("button", {
              type: "button",
              className: "dshm-searchClear",
              "aria-label": t("action.clearSearch"),
              onClick: () => clearQuery(),
            }, "✕"))),
        state.completing
          ? h("span", { className: "dshm-stats" }, t("complete.progress")(state.completeDone, state.completeTotal, state.completeFailed, state.completeSkipped))
          : state.scanning
            ? h("span", { className: "dshm-stats" }, t("scan.progress")(state.scanParsed, state.scanTotal))
            : state.tracks.length > 0 && withTip(h("span", { className: "dshm-stats" },
                t("stats")(visibleTracks.length === state.tracks.length ? state.tracks.length : visibleTracks.length + "/" + state.tracks.length),
                state.truncated ? " · " + t("stats.truncated") : "",
                state.skippedPackages > 0 ? " · " + t("stats.drm")(state.skippedPackages) : ""),
              state.skippedPackages > 0 ? t("stats.drmTip") : "", "bottom"),
        state.completing
          ? withTipWrapped(h("button", {
              type: "button",
              className: "dshm-btn dshm-completeStop",
              "aria-label": t("action.stop"),
              onClick: () => player.stopComplete(),
            }, t("action.stop")), t("action.stop"), "bottom")
          : state.tracks.length > 0 && withTipWrapped(h("button", {
              type: "button",
              className: "dshm-btn dshm-complete",
              "aria-label": t("action.completeAll"),
              disabled: busy,
              onClick: () => player.completeRequest(),
            }, ICONS.sparkle), t("action.completeAll"), "bottom"),
        withTipWrapped(h("button", {
          type: "button",
          className: "dshm-btn",
          "aria-label": t("action.refresh"),
          disabled: state.tracks.length === 0 || busy,
          onClick: () => player.refresh(),
        }, ICONS.refresh), t("action.refresh"), "bottom"),
        state.dir !== null && withTipWrapped(h("button", {
          type: "button",
          className: "dshm-btn",
          "aria-label": t("action.import"),
          disabled: busy,
          onClick: () => setImportOpen(true),
        }, ICONS.importLink, importJobsActive > 0 && h("span", { className: "dshm-importBadge", "aria-hidden": "true" }, String(importJobsActive))), t("action.import"), "bottom"),
        withTipWrapped(h("button", {
          type: "button",
          className: "dshm-btn",
          // 只保留图标：文案移到官方悬停提示 / aria-label，忙碌时提示跟着变
          "aria-label": t("action.chooseDir"),
          disabled: busy,
          onClick: () => player.pick(),
        }, ICONS.folder), busy ? (state.picking ? t("action.picking") : t("action.loading")) : t("action.chooseDir"), "bottom"),
        withTipWrapped(h("button", {
          type: "button",
          className: "dshm-btn",
          "aria-label": t("action.inputDir"),
          disabled: busy,
          onClick: () => {
            setDirInputValue(state.dir ?? "");
            setDirInputOpen(!dirInputOpen);
          },
        }, ICONS.edit, dirInputOpen ? ICONS.close : ""), t("action.inputDir"), "bottom"),
      );

      const dirEditor = dirInputOpen && h("div", { className: "dshm-dirEditor" },
        h("input", {
          type: "text",
          className: "dshm-dirInput",
          value: dirInputValue,
          placeholder: t("action.inputDir.placeholder"),
          autoFocus: true,
          spellCheck: false,
          onChange: (event) => setDirInputValue(event.target.value),
          onKeyDown: (event) => {
            if (event.key === "Escape") setDirInputOpen(false);
            if (event.key === "Enter") {
              const value = dirInputValue.trim();
              if (value.length === 0) return;
              player.setDir(value).then(() => setDirInputOpen(false)).catch(() => {});
            }
          },
        }),
        h("button", {
          type: "button",
          className: "dshm-btn",
          disabled: busy || dirInputValue.trim().length === 0,
          onClick: () => {
            player.setDir(dirInputValue).then(() => setDirInputOpen(false)).catch(() => {});
          },
        }, t("action.confirm")),
      );

      const counts = {
        all: state.tracks.length,
        audio: state.tracks.filter((track) => track.kind !== "video").length,
        video: state.tracks.filter((track) => track.kind === "video").length,
        favorites: state.tracks.filter((track) => favorites.has(track.id)).length,
      };
      const favoriteRows = state.tracks.filter((track) => favorites.has(track.id));
      const typeBase = state.section === "favorites" ? favoriteRows : state.tracks;
      const typeCounts = {
        all: typeBase.length,
        audio: typeBase.filter((track) => track.kind !== "video").length,
        video: typeBase.filter((track) => track.kind === "video").length,
      };
      const sideActive = (view) => state.section === "library" && state.mediaFilter === view;
      const navItem = (view, label, count, glyph) => h("button", {
        type: "button",
        className: "dshm-navItem" + ((view === "favorites" || view === "recent"
          ? state.section === view
          : sideActive(view)) ? " dshm-navItem--active" : ""),
        "aria-current": (view === "favorites" || view === "recent" ? state.section === view : sideActive(view)) ? "page" : undefined,
        "aria-label": label,
        onClick: () => player.setView(view),
      },
        h("span", { className: "dshm-navGlyph" }, glyph),
        h("span", { className: "dshm-navLabel" }, label),
        h("span", { className: "dshm-navCount" }, String(count)));
      const sidebar = h("aside", {
        id: "dshm-sidebar",
        className: "dshm-sidebar",
        "aria-label": t("nav.library"),
      },
        h("div", { className: "dshm-sideBrand" },
          h("span", { className: "dshm-sideLogo" }, ICONS.note),
          h("span", { className: "dshm-sideBrandName" }, t("view.music"))),
        h("div", { className: "dshm-sideHeading" }, t("nav.library")),
        navItem("all", t("view.allSongs"), counts.all, ICONS.note),
        navItem("audio", t("view.audio"), counts.audio, ICONS.note),
        navItem("video", t("view.mv"), counts.video, ICONS.play),
        h("div", { className: "dshm-sideHeading" }, t("nav.mine")),
        navItem("favorites", t("view.favorites"), counts.favorites, ICONS.star),
        navItem("recent", t("view.recent"), counts.all, ICONS.refresh));
      const typeBar = (state.section === "favorites" || state.section === "recent") && h("div", {
        className: "dshm-typeBar", role: "group", "aria-label": t("view.filter"),
      },
        ([["all", "view.all"], ["audio", "view.audio"], ["video", "view.mv"]] as [MediaFilter, string][]).map(([id, label]) =>
          h("button", {
            key: id,
            type: "button",
            className: "dshm-viewChip" + (state.mediaFilter === id ? " dshm-viewChip--active" : ""),
            "aria-pressed": state.mediaFilter === id,
            onClick: () => player.setMediaFilter(id),
          }, t(label), h("span", { className: "dshm-viewCount" }, String(typeCounts[id])))));
      const openRowMenu = React.useCallback((track, event) => {
        const rect = event.currentTarget.getBoundingClientRect();
        const width = 170;
        const height = 154;
        const x = Math.max(8, Math.min(rect.right - width, window.innerWidth - width - 8));
        const y = Math.max(8, Math.min(rect.bottom + 4, window.innerHeight - height - 8));
        setRowMenu({ id: track.id, x, y });
      }, []);
      useEffect(() => {
        if (rowMenu === null) return undefined;
        const close = () => setRowMenu(null);
        const onPointer = (event) => {
          const target = event.target as { closest?: (selector: string) => unknown } | null;
          if (target !== null && typeof target.closest === "function"
            && (target.closest(".dshm-rowMenu") !== null || target.closest(".dshm-rowMenuBtn") !== null)) return;
          close();
        };
        const onKey = (event) => { if (event.key === "Escape") close(); };
        document.addEventListener("pointerdown", onPointer, true);
        document.addEventListener("keydown", onKey);
        window.addEventListener("resize", close);
        return () => {
          document.removeEventListener("pointerdown", onPointer, true);
          document.removeEventListener("keydown", onKey);
          window.removeEventListener("resize", close);
        };
      }, [rowMenu]);

      let body;
      if (state.dir === null) {
        body = h("div", { className: "dshm-empty" },
          h("div", { className: "dshm-emptyIcon" }, "♪"),
          h("div", null, t("empty.title")),
          h("div", { className: "dshm-emptyHint" }, t("empty.hint")),
          h("button", { type: "button", className: "dshm-btn", disabled: busy, onClick: () => player.pick() }, ICONS.folder, t("action.chooseDir")),
        );
      } else if (state.tracks.length === 0 && state.scanning) {
        body = h("div", { className: "dshm-empty" },
          h("div", { className: "dshm-emptyIcon" }, "♪"),
          h("div", null, t("scan.progress")(state.scanParsed, state.scanTotal)),
        );
      } else if (state.tracks.length === 0 && !state.loading) {
        body = h("div", { className: "dshm-empty" },
          h("div", { className: "dshm-emptyIcon" }, "♪"),
          h("div", null, t("empty.tracks")),
        );
      } else if (visibleTracks.length === 0) {
        // 查询与视图是两种空态：查询空给“清除搜索”，视图空给“查看全部”。
        const viewEmpty = state.query.trim().length === 0
          && !(state.section === "library" && state.mediaFilter === "all");
        body = h("div", { className: "dshm-empty" },
          h("div", { className: "dshm-emptyIcon" }, viewEmpty ? (state.section === "favorites" ? "★" : state.mediaFilter === "video" ? "🎬" : "♪") : "🔍"),
          h("div", null, viewEmpty ? t("empty.view") : t("empty.search")),
          h("div", { className: "dshm-emptyHint" }, viewEmpty ? t("empty.viewHint") : t("empty.searchHint")),
          viewEmpty
            ? h("button", { type: "button", className: "dshm-btn", onClick: () => player.setView("all") }, t("view.showAll"))
            : h("button", { type: "button", className: "dshm-btn dshm-clearSearch", onClick: () => clearQuery() }, t("action.clearSearch")),
        );
      } else if (state.mediaFilter === "video") {
        body = h(MvGrid, {
          rows: visibleTracks,
          current: state.current,
          player,
          t,
          effective: player.effective,
          coverFor: player.coverFor,
          onMenu: openRowMenu,
        });
      } else {
        body = h(TrackTable, {
          rows: visibleTracks,
          current: state.current,
          sortKey: state.sortKey,
          sortDir: state.sortDir,
          player,
          t,
          effective: player.effective,
          coverFor: player.coverFor,
          activeRowRef,
          playing: state.playing,
          onMenu: openRowMenu,
        });
      }

      // ── 全屏播放器（Apple Music 风格）：左侧大封面 + 进度 + 传输，右侧播放队列 ──
      // 队列 = 可见列表以当前曲目为首旋转后的前 20 首（和"下一首"的实际顺序一致）
      const queueEntries = (() => {
        const rows = player.visibleRows();
        if (rows.length === 0) return rows;
        const at = rows.findIndex((entry) => entry.index === state.current);
        if (at <= 0) return rows.slice(0, 20);
        return rows.slice(at).concat(rows.slice(0, at)).slice(0, 20);
      })();
      const playerCoverSrc = currentTrack !== undefined && !coverFailed ? player.coverFor(currentTrack) : null;
      const favoriteOn = currentTrack !== undefined && favorites.has(currentTrack.id);
      const transportButton = (icon, label, onClick, extraClass?: string) => withTipWrapped(h("button", {
        type: "button",
        className: "dshm-playerTransportBtn" + (extraClass ?? ""),
        disabled: state.tracks.length === 0,
        "aria-label": label,
        onClick: (event) => {
          event.stopPropagation();
          onClick();
        },
      }, icon), label);

      const fullPlayer = playerOpen && h("div", {
        ref: playerRef,
        // closing 阶段保留挂载 200ms 播退出动画，期间不接受交互
        className: "dshm-player"
          + (playerPhase === "closing" ? " dshm-player--closing" : "")
          + (mvBig && isVideo && !immersive ? " dshm-player--mvbig" : "")
          + (webFullscreen ? " dshm-player--theater" : "")
          + (nativeFullscreen ? " dshm-player--nativefull" : "")
          + (immersive ? " dshm-player--immersive" : "")
          + (controlsIdle ? " dshm-player--idle" : ""),
        // 点空白处收起「⋯」菜单（菜单与 ⋯ 按钮自己 stopPropagation）
        onClick: () => setQueueMenu(null),
      },
        playerCoverSrc !== null && h("div", {
          className: "dshm-playerArt-bg",
          style: { backgroundImage: "url(" + JSON.stringify(playerCoverSrc) + ")" },
        }),
        h("div", { className: "dshm-playerScrim" }),
        h("div", { className: "dshm-playerTop" },
          withTipWrapped(h("button", {
            type: "button",
            className: "dshm-playerRound",
            "aria-label": immersive
              ? (nativeFullscreen ? t("player.exitFullscreen") : t("player.exitWebFullscreen"))
              : t("player.close"),
            onClick: (event) => {
              event.stopPropagation();
              if (immersive) {
                if (nativeFullscreen) exitNativeFullscreen();
                if (webFullscreen) setWebFullscreen(false);
                return;
              }
              closeFullPlayer();
            },
          }, immersive ? ICONS.fullscreenExit : ICONS.chevronDown),
            immersive ? (nativeFullscreen ? t("player.exitFullscreen") : t("player.exitWebFullscreen")) : t("player.close"), "bottom"),
          // 参考 macOS Music：右上角是「喇叭图标 + 长条滑杆」
          h("div", { className: "dshm-playerVolume" },
            withTipWrapped(h("button", {
              type: "button",
              className: "dshm-volIcon" + (state.muted ? " dshm-volIcon--muted" : ""),
              "aria-label": t(state.muted ? "action.unmute" : "action.mute"),
              "aria-pressed": state.muted,
              onClick: () => player.toggleMute(),
            }, ICONS[state.muted ? "volumeOff" : "volume"]), t(state.muted ? "action.unmute" : "action.mute"), "bottom"),
            withTipWrapped(h("input", {
              type: "range",
              className: "dshm-slider dshm-volume dshm-volume--wide",
              ref: volumeWheelRef,
              style: { "--p": volumePct + "%" },
              min: 0,
              max: 1,
              step: 0.01,
              value: state.volume,
              "aria-label": t("action.volume"),
              onChange: (event) => player.setVolume(Number(event.target.value)),
            }), t("action.volume") + " " + volumePct + "%", "bottom"),
            rgButton("bottom"),
            eqButton("bottom"),
            isVideo && withTipWrapped(h("button", {
              type: "button",
              className: "dshm-playerRound" + (webFullscreen ? " dshm-playerRound--on" : ""),
              "aria-label": webFullscreen ? t("player.exitWebFullscreen") : t("player.webFullscreen"),
              "aria-pressed": webFullscreen,
              onClick: (event) => {
                event.stopPropagation();
                toggleWebFullscreen();
              },
            }, webFullscreen ? ICONS.theaterExit : ICONS.theater), webFullscreen ? t("player.exitWebFullscreen") : t("player.webFullscreen"), "bottom"),
            isVideo && withTipWrapped(h("button", {
              type: "button",
              className: "dshm-playerRound" + (nativeFullscreen ? " dshm-playerRound--on" : ""),
              "aria-label": nativeFullscreen ? t("player.exitFullscreen") : t("player.fullscreen"),
              "aria-pressed": nativeFullscreen,
              onClick: (event) => {
                event.stopPropagation();
                toggleNativeFullscreen();
              },
            }, nativeFullscreen ? ICONS.fullscreenExit : ICONS.fullscreen), nativeFullscreen ? t("player.exitFullscreen") : t("player.fullscreen"), "bottom"),
          ),
        ),
        h("div", { className: "dshm-playerBody" },
          h("div", { className: "dshm-playerStage" },
            // MV：媒体元素会被搬进这个槽位；准备期间盖一层进度（转封装/转码要等 ffmpeg）。
            // 关键：只要是视频轨就必须渲染这个槽位。之前写成「有封面才渲染」，
            // 封面取不到（例如带 MJPEG 封面轨的 mp4）时 <video> 只能留在隐藏停靠位 —— 声音响、画面没有。
            isVideo
              // 点画面 = 就地放大/还原（不另开预览层：视频留在原位，只是铺得更大）
              ? h("div", {
                  className: "dshm-mvStage" + (immersive ? "" : " dshm-zoomable"),
                  ref: mvStageRef,
                  // 普通态点画面铺大；全屏态点画面是播放/暂停（和 YouTube 一致）。
                  onClick: (event) => {
                    event.stopPropagation();
                    if (immersive) player.toggle(); else player.toggleMvBig();
                  },
                  onDoubleClick: (event) => {
                    event.stopPropagation();
                    if (!immersive) toggleNativeFullscreen();
                  },
                },
                  mvState !== null && mvState !== undefined && mvState.state !== "ready"
                    ? h("div", { className: "dshm-mvPrep" },
                        h("span", { className: "dshm-mvPrepText" }, mvState.state === "failed"
                          ? t("mv.failed")
                          : mvState.mode === "transcode" ? t("mv.transcoding") : t("mv.remuxing")),
                        mvState.state !== "failed" && h("span", { className: "dshm-mvPrepBar" },
                          h("i", { style: { width: Math.round((mvState.progress ?? 0) * 100) + "%" } })),
                        mvState.state !== "failed" && h("span", { className: "dshm-mvPrepPct" }, Math.round((mvState.progress ?? 0) * 100) + "%"),
                        mvState.state !== "failed" && mvState.mode === "transcode" && h("span", { className: "dshm-mvPrepHint" }, t("mv.fastHint")),
                        mvState.state === "failed" && mvState.error === "ffmpeg-not-found"
                          ? h("span", { className: "dshm-mvPrepHint" }, t("mv.noFfmpeg"))
                          : mvState.state === "failed"
                            // 失败原因直接摊开（ffmpeg 的最后一行），否则只能看到黑屏没法查
                            ? h("span", { className: "dshm-mvPrepHint" }, String(mvState.error ?? t("mv.failed")))
                            : null,
                        mvState.state === "failed" && h("button", {
                          type: "button",
                          className: "dshm-mvPrepRetry",
                          onClick: (event) => {
                            event.stopPropagation();
                            if (currentTrack === undefined) return;
                            // 重置 mvEscalated / 置 preparing 都在 player.retryVideo 里做 ——
                            // 那两个是 createPlayer() 的局部量，写在这里会 ReferenceError。
                            void player.retryVideo(currentTrack);
                          },
                        }, t("mv.retry")),
                      )
                    : null,
                )
              : playerCoverSrc !== null
              // key 跟着曲目走：换歌时整块重挂载，封面淡入 + 轻微缩放的入场动画重播
              ? h("img", {
                  key: "art:" + (currentTrack?.id ?? "none"),
                  className: "dshm-playerArt dshm-zoomable",
                  src: playerCoverSrc,
                  alt: "",
                  onClick: (event) => { event.stopPropagation(); player.setZoomOpen(true); },
                  onError: () => setCoverFailed(true),
                })
              : h("div", { className: "dshm-playerArtFallback" }, ICONS.note),
            h("div", { className: "dshm-playerControls" },
            h("div", { className: "dshm-playerMeta" },
              h("div", { className: "dshm-playerMetaText" },
                // 歌名/歌手同样走右→左跑马灯（放得下就不动）
                h(Marquee, {
                  className: "dshm-playerTitle",
                  text: currentView?.title ?? t("player.noTrack"),
                  title: currentView?.title ?? t("player.noTrack"),
                }),
                h(Marquee, {
                  className: "dshm-playerArtist",
                  text: [currentView?.artist, currentView?.album].filter((value) => typeof value === "string" && value.length > 0).join(" — "),
                  title: [currentView?.artist, currentView?.album].filter((value) => typeof value === "string" && value.length > 0).join(" — "),
                }),
              ),
              // 收藏：DSH 图标集没有星标 → 补 macOS 原生风格星形（其余按钮一律用官方图标）
              withTipWrapped(h("button", {
                type: "button",
                className: "dshm-playerRound" + (favoriteOn ? " dshm-playerRound--on" : ""),
                disabled: currentTrack === undefined,
                "aria-label": favoriteOn ? t("player.unfavorite") : t("player.favorite"),
                onClick: (event) => {
                  event.stopPropagation();
                  if (currentTrack !== undefined) player.toggleFavorite(currentTrack.id);
                },
              }, favoriteOn ? ICONS.starFill : ICONS.star), favoriteOn ? t("player.unfavorite") : t("player.favorite")),
              // ⋯：对齐 macOS Music 的「⭐ + ⋯」两枚圆形按钮（这里是当前曲目的在线补全）
              withTipWrapped(h("button", {
                type: "button",
                className: "dshm-playerRound",
                disabled: currentTrack === undefined,
                "aria-label": t("player.match"),
                onClick: (event) => {
                  event.stopPropagation();
                  if (currentTrack === undefined) return;
                  player.closePlayer();
                  player.match(currentTrack.id);
                },
              }, ICONS.ellipsis), t("player.match")),
            ),
            h(ProgressBar, {
              player,
              trackId: state.current,
              duration: state.duration,
              time: state.time,
              playing: state.playing,
              peaks: state.wavePeaks,
              t,
              variant: "stacked",
            }),
            // 三栏网格：上一首/播放/下一首 永远居中；循环键放到右栏，
            // 正好落在上面「-剩余」时间的正下方（同一右边界对齐）。
            h("div", { className: "dshm-playerTransport" },
              h("span", { className: "dshm-playerTransportSide" }),
              h("div", { className: "dshm-playerTransportCenter" },
                transportButton(ICONS.prev, t("action.prev"), () => player.prev()),
                transportButton(state.playing ? ICONS.pauseBig : ICONS.playBig, state.playing ? t("action.pause") : t("action.play"), () => player.toggle(), " dshm-playerTransportBtn--play"),
                transportButton(ICONS.next, t("action.next"), () => player.next()),
              ),
              h("div", { className: "dshm-playerTransportSide dshm-playerTransportSide--end" },
                transportButton(
                  state.mode === "loop" ? ICONS.repeat : ICONS.repeatOne,
                  state.mode === "loop" ? t("mode.loop") : t("mode.one"),
                  () => player.toggleMode(),
                  state.mode === "one" ? " dshm-playerTransportBtn--on" : "",
                ),
              ),
            ),
            ),
          ),
          h("div", { className: "dshm-playerRight" },
            h("div", { className: "dshm-playerPills" },
              withTipWrapped(h("button", {
                type: "button",
                className: "dshm-pill",
                disabled: busy || state.tracks.length === 0,
                onClick: (event) => {
                  event.stopPropagation();
                  player.closePlayer();
                  player.completeRequest();
                },
              }, ICONS.sparkle, t("action.completeAll")), t("action.completeAll")),
              withTipWrapped(h("button", {
                type: "button",
                className: "dshm-pill",
                disabled: busy || state.tracks.length === 0,
                onClick: (event) => {
                  event.stopPropagation();
                  player.refresh();
                },
              }, ICONS.refresh, t("action.refresh")), t("action.refresh")),
            ),
            h("div", { className: "dshm-playerQueueHead" },
              h("span", { className: "dshm-playerQueueTitle" }, t("player.queue")),
              h("span", { className: "dshm-playerQueueCount" }, t("stats")(queueEntries.length)),
            ),
            h("div", { className: "dshm-playerQueue" }, queueEntries.length === 0
              ? h("div", { className: "dshm-dialogMsg" }, t("player.noTrack"))
              : queueEntries.map((entry) => {
                  const view = player.effective(entry.track);
                  const isCurrent = entry.index === state.current;
                  const favorited = favorites.has(entry.track.id);
                  const subtitle = [view?.artist, view?.album]
                    .filter((value) => typeof value === "string" && value.length > 0).join(" — ");
                  return h("div", {
                    key: "queue:" + entry.index + ":" + entry.track.name,
                    className: "dshm-queueRow" + (isCurrent ? " dshm-queueRow--current" : ""),
                    onClick: () => player.play(entry.index),
                  },
                    h(RowCover, {
                      src: player.coverFor(entry.track),
                      playing: isCurrent,
                      paused: !state.playing,
                    }),
                    h("span", { className: "dshm-queueText" },
                      h("span", { className: "dshm-queueTitle" },
                        entry.track.kind === "video" ? h("span", { className: "dshm-mvTag" }, "MV") : null,
                        view?.title ?? entry.track.title),
                      h("span", { className: "dshm-queueArtist" }, subtitle.length > 0 ? subtitle : entry.track.name),
                    ),
                    favorited && h("span", { className: "dshm-queueFav" }, ICONS.starFill),
                    withTipWrapped(h("button", {
                      type: "button",
                      className: "dshm-queueMore",
                      "aria-label": t("player.more"),
                      onClick: (event) => {
                        event.stopPropagation();
                        setQueueMenu(queueMenu === entry.track.id ? null : entry.track.id);
                      },
                    }, ICONS.ellipsis), t("player.more")),
                    queueMenu === entry.track.id && h("div", {
                      className: "dshm-queueMenu",
                      onClick: (event) => event.stopPropagation(),
                    },
                      h("button", {
                        type: "button",
                        className: "dshm-queueMenuItem",
                        onClick: () => {
                          setQueueMenu(null);
                          player.closePlayer();
                          player.match(entry.track.id);
                        },
                      }, ICONS.sparkle, t("player.match")),
                      h("button", {
                        type: "button",
                        className: "dshm-queueMenuItem dshm-queueMenuItem--danger",
                        onClick: () => {
                          setQueueMenu(null);
                          player.remove(entry.index);
                        },
                      }, ICONS.trash, t("player.delete")),
                    ),
                  );
                })),
          ),
        ),
      );

      const bar = h("div", { className: "dshm-bar" },
        h("div", { className: "dshm-nowPlaying" },
          // 封面即入口：点开全屏播放器（Apple Music 同款）
          withTipWrapped(h("button", {
            type: "button",
            className: "dshm-nowCoverBtn",
            "aria-label": t("player.open"),
            onClick: () => player.openPlayer(),
          },
            currentTrack !== undefined && !coverFailed
              ? h("img", {
                  className: "dshm-cover",
                  src: player.coverFor(currentTrack),
                  alt: "",
                  onError: () => setCoverFailed(true),
                })
              : h("span", { className: "dshm-noteIcon" }, ICONS.note),
          ), t("player.open")),
          h("div", { className: "dshm-nowText" },
            // 歌名/歌手溢出时右→左跑马灯（放得下就完全不动）
            currentTrack?.kind === "video" ? h("span", { className: "dshm-mvTag" }, "MV") : null,
            h(Marquee, {
              className: "dshm-nowTitle",
              text: currentView?.title ?? "—",
              title: currentView?.title ?? "—",
            }),
            h(Marquee, {
              className: "dshm-nowArtist",
              text: currentView?.artist ?? "",
              title: currentView?.artist ?? "",
            }),
          ),
        ),
        h("div", { className: "dshm-center" },
          h("div", { className: "dshm-transport" },
            withTipWrapped(h("button", { type: "button", className: "dshm-tbtn", disabled: state.tracks.length === 0, onClick: () => player.prev(), "aria-label": t("action.prev") }, ICONS.prev), t("action.prev")),
            withTipWrapped(h("button", { type: "button", className: "dshm-tbtn dshm-tbtn--play", disabled: state.tracks.length === 0, onClick: () => player.toggle(), "aria-label": t("action.play") + "/" + t("action.pause") }, state.playing ? ICONS.pause : ICONS.play), state.playing ? t("action.pause") : t("action.play")),
            withTipWrapped(h("button", { type: "button", className: "dshm-tbtn", disabled: state.tracks.length === 0, onClick: () => player.next(), "aria-label": t("action.next") }, ICONS.next), t("action.next")),
          ),
          h(ProgressBar, {
            player,
            trackId: state.current,
            duration: state.duration,
            time: state.time,
            playing: state.playing,
            peaks: state.wavePeaks,
            t,
          }),
        ),
        h("div", { className: "dshm-right" },
          withTipWrapped(h("button", {
            type: "button",
            className: "dshm-mode",
            onClick: () => player.toggleMode(),
            "aria-label": state.mode === "loop" ? t("mode.loop") : t("mode.one"),
          }, state.mode === "loop" ? ICONS.repeat : ICONS.repeatOne), state.mode === "loop" ? t("mode.loop") : t("mode.one")),
          withTipWrapped(h("button", {
            type: "button",
            className: "dshm-volIcon" + (state.muted ? " dshm-volIcon--muted" : ""),
            "aria-label": t(state.muted ? "action.unmute" : "action.mute"),
            "aria-pressed": state.muted,
            onClick: () => player.toggleMute(),
          }, ICONS[state.muted ? "volumeOff" : "volume"]), t(state.muted ? "action.unmute" : "action.mute"), "bottom"),
          withTipWrapped(h("input", {
            type: "range",
            className: "dshm-slider dshm-volume",
            ref: volumeWheelRef,
            style: { "--p": volumePct + "%" },
            min: 0,
            max: 1,
            step: 0.01,
            value: state.volume,
            "aria-label": t("action.volume"),
            onChange: (event) => player.setVolume(Number(event.target.value)),
          }), t("action.volume") + " " + volumePct + "%"),
          rgButton("top"),
          eqButton("top"),
        ),
      );

      // 在线补全弹层：点选候选即写入本地覆盖，音频文件与标签不动
      const picker = state.match;
      const modalRef = useModalA11y(picker !== null, () => player.closeMatch());
      const matchOverlay = picker !== null && h("div", {
        ref: modalRef,
        className: "dshm-modal",
        role: "dialog",
        "aria-modal": "true",
        "aria-label": t("match.title"),
        onClick: () => player.closeMatch(),
      },
        h("div", { className: "dshm-dialog", onClick: (event) => event.stopPropagation() },
          h("div", { className: "dshm-dialogHead" },
            t("match.title"),
            h("div", { className: "dshm-matchRow" },
              h("input", {
                type: "text",
                autoFocus: true,
                className: "dshm-matchInput",
                value: matchTerm,
                placeholder: t("action.search.placeholder"),
                spellCheck: false,
                onChange: (event) => setMatchTerm(event.target.value),
                onKeyDown: (event) => {
                  if (event.key === "Enter" && matchTerm.trim().length > 0) player.match(picker.id, matchTerm);
                },
              }),
              h("button", {
                type: "button",
                className: "dshm-btn",
                disabled: picker.loading || matchTerm.trim().length === 0,
                onClick: () => player.match(picker.id, matchTerm),
              }, t("action.search")),
            ),
          ),
          picker.applying || picker.loading
            ? h("div", { className: "dshm-dialogMsg" }, picker.applying ? t("match.applying") : t("action.matching"))
            : picker.error !== null
              ? h("div", { className: "dshm-dialogMsg" }, t("error.prefix"), picker.error)
              : picker.candidates.length === 0
                ? h("div", { className: "dshm-dialogMsg" }, t("match.none"))
                : h("div", { className: "dshm-cands" }, picker.candidates.map((candidate, index) => h("button", {
                    key: (candidate.id ?? "c") + ":" + index,
                    type: "button",
                    className: "dshm-cand",
                    onClick: () => player.applyMatch(candidate, writeFile, replaceCover),
                  },
                    candidate.cover
                      ? h("img", {
                          className: "dshm-candCover",
                          src: artUrl(candidate.cover),
                          alt: "",
                          onError: (event) => { event.currentTarget.style.visibility = "hidden"; },
                        })
                      : h("span", { className: "dshm-candCover dshm-noteIcon" }, ICONS.note),
                    h("span", { className: "dshm-candText" },
                      h("span", { className: "dshm-candTitle" },
                        index === 0 && h("span", { className: "dshm-candBest" }, "✦"),
                        candidate.title || "—"),
                      h("span", { className: "dshm-candArtist" }, [candidate.artist, candidate.album]
                        .filter((value) => typeof value === "string" && value.length > 0).join(" · ")),
                      h("span", { className: "dshm-candMeta" }, [
                        (Array.isArray(candidate.sources) ? candidate.sources : [candidate.source])
                          .filter((value) => typeof value === "string" && value.length > 0).join(" + "),
                        typeof candidate.score === "number" ? Math.round(candidate.score * 100) + "%" : "",
                        candidate.auto === true ? "✓" : "",
                      ].filter(Boolean).join(" · ")),
                    ),
                  ))),
          h("div", { className: "dshm-dialogFoot" },
            withTip(h("label", { className: "dshm-check" },
              h("input", {
                type: "checkbox",
                checked: writeFile,
                disabled: picker.applying,
                onChange: (event) => setWriteFile(event.target.checked),
              }),
              t("match.writeFile"),
            ), t("match.source")),
            withTip(h("label", { className: "dshm-check" },
              h("input", {
                type: "checkbox",
                checked: replaceCover,
                disabled: picker.applying || writeFile !== true,
                onChange: (event) => setReplaceCover(event.target.checked),
              }),
              t("match.replaceCover"),
            ), t("match.replaceCover")),
            h("span", { style: { display: "flex", gap: "8px" } },
              state.meta[picker.id] !== undefined && h("button", {
                type: "button",
                className: "dshm-btn",
                disabled: picker.applying,
                onClick: () => player.clearMeta(picker.id),
              }, t("match.clear")),
              h("button", {
                type: "button",
                className: "dshm-btn",
                disabled: picker.applying,
                onClick: () => player.closeMatch(),
              }, t("action.cancel")),
            ),
          ),
        ),
      );

      // 一键补全确认条（会改本地文件：写标签 + 重命名）
      const completeCount = state.tracks.filter((track) => state.meta[track.id] === undefined).length;

      const completeBar = state.pendingComplete && h("div", { className: "dshm-confirmBar" },
        h("span", { className: "dshm-confirmText" }, t("confirm.complete")(completeCount)),
        h("label", { className: "dshm-coverToggle" },
          h("input", {
            type: "checkbox",
            checked: state.completeOverwriteCover,
            onChange: (event) => player.setCompleteOverwriteCover(event.target.checked),
          }),
          t("complete.replaceCover"),
        ),
        h("button", { type: "button", className: "dshm-btn dshm-completeGo", onClick: () => player.completeAll() }, t("action.confirm")),
        h("button", { type: "button", className: "dshm-btn dshm-completeCancel", onClick: () => player.cancelComplete() }, t("action.cancel")),
      );

      // 删除确认条（替代 window.confirm 的应用内结构化确认）
      const pendingTrack = state.pendingDelete >= 0 ? state.tracks[state.pendingDelete] : undefined;
      const confirmBar = pendingTrack !== undefined && h("div", { className: "dshm-confirmBar" },
        h("span", { className: "dshm-confirmText" }, t("confirm.delete")(pendingTrack.title)),
        h("button", { type: "button", className: "dshm-btn dshm-btn--danger", onClick: () => player.confirmRemove() }, t("action.delete")),
        h("button", { type: "button", className: "dshm-btn", onClick: () => player.cancelRemove() }, t("action.cancel")),
      );

      const menuTrack = rowMenu === null ? undefined : state.tracks.find((track) => track.id === rowMenu.id);
      const menuIndex = rowMenu === null ? -1 : state.tracks.findIndex((track) => track.id === rowMenu.id);
      const rowMenuElement = rowMenu !== null && menuTrack !== undefined && h("div", {
        className: "dshm-rowMenu",
        style: { left: rowMenu.x + "px", top: rowMenu.y + "px" },
        role: "menu",
        "aria-label": t("action.more"),
      },
        h("button", {
          type: "button", role: "menuitem", className: "dshm-rowMenuItem dshm-menuFav",
          onClick: () => { setRowMenu(null); player.toggleFavorite(menuTrack.id); },
        }, favorites.has(menuTrack.id) ? t("player.unfavorite") : t("player.favorite")),
        h("button", {
          type: "button", role: "menuitem", className: "dshm-rowMenuItem dshm-menuMatch",
          onClick: () => { setRowMenu(null); player.match(menuTrack.id); },
        }, t("action.match.tip")),
        h("button", {
          type: "button", role: "menuitem", className: "dshm-rowMenuItem dshm-rowMenuItem--danger dshm-menuDelete",
          onClick: () => { setRowMenu(null); player.remove(menuIndex); },
        }, t("action.delete")),
      );

      return h("div", { className: "dshm-root", ref: rootRef },
        // MV 媒体元素的隐藏停靠位：弹层收起时把 <video> 停在这里继续放声音
        h("div", { className: "dshm-mvPark", ref: mvParkRef, "aria-hidden": "true" }),
        h("div", { className: "dshm-shell" },
          state.sidebarOpen && sidebar,
          h("div", { className: "dshm-main" },
            header,
            dirEditor,
            typeBar,
            completeBar,
            confirmBar,
            state.hostEntry === "legacy" && h("div", { className: "dshm-notice" }, t("error.legacyEntry")),
            state.buffering && h("div", { className: "dshm-buffering", role: "status", "aria-live": "polite" }, t("status.buffering")),
            state.error !== null && h("div", { className: "dshm-error", role: "alert", "aria-live": "assertive" },
              t("error.prefix"), state.error,
              h("button", {
                type: "button",
                className: "dshm-errorClose",
                "aria-label": t("action.dismiss"),
                onClick: () => player.clearError(),
              }, "✕")),
            body,
            bar)),
        rowMenuElement,
        // 全屏播放器盖在内容之上；matchOverlay 的 z-index 更高，弹层仍在它之上
        fullPlayer,
        // 放大预览：封面看大图，MV 直接把画面搬进这一层（尺寸夹在窗口内，不超出 desktop）
        zoomOpen && !isVideo && playerCoverSrc !== null
          && h("div", { className: "dshm-lightbox", onClick: () => player.setZoomOpen(false) },
            h("img", { className: "dshm-lightboxImg", src: playerCoverSrc, alt: "" }),
          ),
        matchOverlay,
        h(ImportDialog, { open: importOpen, dir: state.dir, t, onClose: () => setImportOpen(false), onDone: () => player.refresh(), onActiveChange: setImportJobsActive }),
      );
    }

    /** 渲染错误必须可见，绝不白屏（与 dsh-text-reader 同一模式）。 */
    class ErrorBoundary extends React.Component {
      constructor(props) {
        super(props);
        this.state = { error: null };
      }
      static getDerivedStateFromError(error) {
        return { error };
      }
      componentDidCatch(error) {
        console.error("[dsh-music-player] view render error:", error);
      }
      render() {
        if (this.state.error !== null) {
          return h("div", { className: "dshm-root" },
            h("div", { className: "dshm-error" }, "界面渲染出错了：", this.state.error instanceof Error ? this.state.error.message : String(this.state.error)),
          );
        }
        return h(MusicView);
      }
    }

    const inject = ["slots", "locale"];
    function apply(ctx) {
      // 本代先用（必要时新建）一份 player：上一代的 halt() 已经把 window 键摘掉，
      // 于是这里拿到的一定是能干活的实例，而不是继承上一代的终态闸门。
      player = takePlayer();
      const generation = player.acquire();
      ctx.effect(() => ctx.locale.register(NS, { zh, en }), "music-player: dictionaries");
      const t = ctx.locale.bind(NS);
      translate = t;
      player.t = t;
      // lifecycle：插件停用/卸载时停止播放并断开音频流，不留后台声音。
      // 租约号是**比较并释放**的前置条件：热重载的旧 disposer 可能晚于新 bundle 求值跑到，
      // 那时新的一代已经取过号，这次释放必须放弃（见 api0.acquire）。实例也当场捕获，
      // 不读模块级 `player` —— 它可能已经被下一代改写。
      ctx.effect(() => () => {
        // 比较并释放：新 bundle 先求值、旧 disposer 后跑是常态，旧一代不得停掉新一代。
        // 这里读模块级 `player` 是对的 —— `takePlayer()` 只在旧实例已释放时才换新的，
        // 而租约号保证只有取到当前号的那一代才真的释放。
        if (player.lease() !== generation) return;
        player.halt();
      }, "music-player: audio teardown");
      // 立刻问一次 /session：拿到 token 版的系统取图/媒体直连基址（Desktop 拖动/快进要靠它）。
      void player.warmSession();
      ctx.effect(() => {
        const tag = document.createElement("style");
        tag.dataset.plugin = "@heshuren/dsh-music-player";
        tag.dataset.pluginCss = NS;
        tag.textContent = CSS;
        document.head.appendChild(tag);
        return () => tag.remove();
      }, "music-player: styles");
      ctx.slots.inject("conversation.view", () => ctx.slots.register({
        name: "conversation.view",
        id: "music",
        order: 20,
        locale: NS,
        label: () => t("view.music"),
        inject: () => ({}),
      }, ErrorBoundary));
    }

    exports.apply = apply;
    exports.inject = inject;
    return module.exports;
  }
});
