import { spawn } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve, sep } from 'node:path';
import { tmpdir } from 'node:os';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

// 每个版本使用独立依赖树和构建产物副本，不修改开发依赖或用户 profile。
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const pkg = JSON.parse(readFileSync(join(root, 'package.json'), 'utf8'));
const lock = JSON.parse(readFileSync(join(root, 'package-lock.json'), 'utf8'));
const HOST_PINS = {
  '0.2.0-rc.1': { cordis: '4.0.4', schemastery: '3.18.4' },
  '0.2.0-rc.2': { cordis: '4.0.4', schemastery: '3.18.4' },
  '0.2.1-rc.1': { cordis: '4.0.5', schemastery: '3.18.5' },
  '0.2.1-rc.2': { cordis: '4.0.5', schemastery: '3.18.5' },
  '0.2.1-rc.3': { cordis: '4.0.5', schemastery: '3.18.5' },
  '0.2.2-rc.1': { cordis: '4.1.0', schemastery: '3.19.0' },
  '0.2.2-rc.2': { cordis: '4.1.0', schemastery: '3.19.0' },
};
const defaultTestedHosts = Object.keys(HOST_PINS);
const versions = process.argv.slice(2).length ? process.argv.slice(2) : defaultTestedHosts;
const npmCli = process.env.npm_execpath;
if (!npmCli || !existsSync(npmCli)) throw new Error('请通过 npm run test:compat 执行。');
if (!existsSync(join(root, 'lib/index.js'))) throw new Error('请先 npm run build。');
const tmpBase = join(tmpdir(), 'dsh-pua-compat');
mkdirSync(tmpBase, { recursive: true });
const run = (cwd, args) => new Promise((resolveResult, reject) => {
  const env = { ...process.env };
  delete env.PUA_TEST_PROFILE;
  delete env.NODE_PATH;
  const child = spawn(process.execPath, args, { cwd, env, windowsHide: true });
  let output = '';
  child.stdout.on('data', data => { output += data.toString('utf8'); });
  child.stderr.on('data', data => { output += data.toString('utf8'); });
  child.on('error', reject);
  child.on('close', code => resolveResult({ code, output }));
});

const results = await Promise.allSettled(versions.map(async version => {
  const dir = mkdtempSync(join(tmpBase, `compat-${version}-`));
  console.log(`${version}：创建隔离依赖树`);
  try {
    const manifest = structuredClone(pkg);
    delete manifest.scripts;
    const pin = HOST_PINS[version];
    if (!pin) throw new Error(`缺少 ${version} 的 Cordis 钉版本。`);
    manifest.overrides = {
      ...Object.fromEntries(Object.keys(manifest.devDependencies)
        .filter(name => name.startsWith('@deepseek-ai/dsh-'))
        .map(name => [name, version])),
      '@deepseek-ai/cordis': pin.cordis,
      '@deepseek-ai/schemastery': pin.schemastery,
    };
    manifest.devDependencies['@deepseek-ai/schemastery'] = pin.schemastery;
    manifest.devDependencies['@deepseek-ai/cordis'] = pin.cordis;
    for (const key of Object.keys(manifest.devDependencies)) {
      if (!key.startsWith('@deepseek-ai/dsh-')) continue;
      manifest.devDependencies[key] = version;
    }
    if (['0.2.0-rc.1', '0.2.0-rc.2', '0.2.1-rc.1', '0.2.1-rc.2', '0.2.1-rc.3', '0.2.2-rc.1'].includes(version)) {
      delete manifest.devDependencies['@deepseek-ai/dsh-error'];
    }
    writeFileSync(join(dir, 'package.json'), JSON.stringify(manifest, null, 2) + '\n', 'utf8');
    for (const name of ['lib', 'assets', 'tests', 'locale', 'src']) cpSync(join(root, name), join(dir, name), { recursive: true });
    for (const file of readdirSync(root).filter(n => n.startsWith('README') && n.endsWith('.md'))) cpSync(join(root, file), join(dir, file));
    const install = await run(dir, [npmCli, 'install', '--ignore-scripts', '--registry=https://registry.npmjs.org/', '--no-audit', '--no-fund']);
    if (install.code !== 0) throw new Error(`依赖安装失败\n${install.output.slice(-4000)}`);
    for (const name of ['dsh-agent', 'dsh-session', 'dsh-tools']) {
      const installed = JSON.parse(readFileSync(join(dir, 'node_modules', '@deepseek-ai', name, 'package.json'), 'utf8'));
      if (installed.version !== version) throw new Error(`${name} 意外解析为 ${installed.version}`);
    }
    const isolatedRequire = createRequire(join(dir, 'package.json'));
    for (const name of Object.keys(manifest.devDependencies).filter(name => name.startsWith('@deepseek-ai/') || ['react', 'react-dom', 'zod'].includes(name))) {
      const resolved = isolatedRequire.resolve(name);
      if (!resolve(resolved).startsWith(resolve(dir) + sep)) throw new Error(name + ' 解析到隔离目录之外：' + resolved);
    }
    const files = readdirSync(join(dir, 'tests')).filter(name => name.endsWith('.test.mjs')).map(name => join('tests', name));
    if (!files.length) throw new Error('兼容测试目录为空，拒绝报告成功。');
    // 文件包含多次真实 PowerShell 启动；云端并行版本回归需要预留启动开销。
    const tested = await run(dir, ['--test', '--test-timeout=60000', ...files]);
    if (tested.code !== 0) {
      writeFileSync(join(tmpBase, 'last-failure.txt'), tested.output);
      throw new Error(`回归失败\n${tested.output.slice(-6000)}`);
    }
    if (!/(?:tests|pass) [1-9]\d*/u.test(tested.output)) throw new Error('未发现实际执行的测试计数。');
    console.log(`${version}：${tested.output.split(/\r?\n/u).filter(line => /(?:tests|pass|fail|skipped) \d+/u.test(line)).join('；')}`);
    return version;
  } finally {
    if (!resolve(dir).startsWith(resolve(tmpBase) + sep)) throw new Error('拒绝清理越界目录。');
    rmSync(dir, { recursive: true, force: true });
  }
}));
results.forEach((result, index) => {
  if (result.status === 'rejected') { console.error(`${versions[index]}：${result.reason.message}`); process.exitCode = 1; }
});
