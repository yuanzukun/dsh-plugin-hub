import { Service } from "@deepseek-ai/cordis";
import { Config } from "../lib/settings.js";

const WRITE = Symbol.for("cosmokit.volatile.write");

function commit(state, patch) {
  const config = state.config;
  if (!config || typeof config !== "object") {
    state.config = { ...state.config, ...patch };
    return;
  }
  if (typeof config.get === "function" && WRITE in config) {
    config[WRITE]({ ...config.get(), ...patch });
    return;
  }
  for (const [key, value] of Object.entries(patch)) {
    const current = config[key];
    if (current && typeof current === "object" && WRITE in current) current[WRITE](value);
    else config[key] = value;
  }
}

function snapshot(config) {
  if (config && typeof config.get === "function") return config.get();
  return config;
}

export async function installSettings(ctx) {
  const state = {
    fail: false,
    config: { alwaysOn: true, flavor: "auto", offline: false, mode: "pua", subagents: false },
    revision: 0,
    listed: false
  };
  class VolatileMemorySettings extends Service {
    constructor(context) { super(context, "settings"); }
    configure() {
      state.listed = true;
      return () => { state.listed = false; };
    }
    get(ns) { return ns === "michengai-pua" ? snapshot(state.config) : undefined; }
    describe() {
      return state.listed ? [{ ns: "michengai-pua", revision: state.revision, value: snapshot(state.config) }] : [];
    }
    async update(_ns, patch, expected) {
      if (state.fail) throw new Error("模拟磁盘写入失败");
      if (expected !== undefined && expected !== state.revision) {
        throw new Error("settings namespace changed");
      }
      commit(state, patch);
      state.revision += 1;
    }
  }
  new VolatileMemorySettings(ctx);
  return {
    fail(value) { state.fail = value; },
    attach(config) {
      if (config) {
        state.config = config;
      }
    }
  };
}
