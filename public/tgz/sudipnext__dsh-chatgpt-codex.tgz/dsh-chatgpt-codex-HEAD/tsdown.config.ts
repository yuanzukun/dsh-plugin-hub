import { defineConfig } from 'tsdown'

export default defineConfig({
  entry: ['src/index.ts', 'src/cli.ts'],
  format: 'esm',
  outDir: 'lib',
  unbundle: true,
  root: 'src',
  fixedExtension: false,
  hash: false,
  dts: true,
  sourcemap: true,
  clean: true,
  deps: {
    neverBundle: [
      '@deepseek-ai/cordis',
      '@deepseek-ai/dsh-attachment',
      '@deepseek-ai/dsh-llm',
    ],
  },
})
