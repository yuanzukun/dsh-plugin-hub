#!/usr/bin/env node
import { createRequire } from 'node:module'
import { Command, Option } from 'commander'
import { AuthManager } from './auth/manager.ts'
import { AuthStore, defaultAuthFile } from './auth/store.ts'
import { DEFAULT_CLIENT_ID, DEFAULT_ISSUER } from './constants.ts'

interface GlobalOptions {
  authFile: string
  issuer: string
  clientId: string
}

const manifest = createRequire(import.meta.url)('../package.json') as { version: string }

function integer(value: string): number {
  const parsed = Number(value)
  if (!Number.isInteger(parsed) || parsed <= 0) throw new Error(`expected a positive integer, received ${value}`)
  return parsed
}

function manager(command: Command): { auth: AuthManager; globals: GlobalOptions } {
  const globals = command.optsWithGlobals() as GlobalOptions
  return {
    auth: new AuthManager({ store: new AuthStore(globals.authFile), issuer: globals.issuer }),
    globals,
  }
}

function accountLine(credentials: { email?: string; accountId: string; plan?: string }): string {
  return [credentials.email ?? credentials.accountId, credentials.plan].filter(Boolean).join(' · ')
}

const program = new Command()
  .name('dsh-chatgpt-codex')
  .description('Connect DeepSeek Harness to Codex models with your ChatGPT account')
  .version(manifest.version)
  .option('--auth-file <path>', 'credential file path', defaultAuthFile())
  .option('--issuer <url>', 'OpenAI OAuth issuer', DEFAULT_ISSUER)
  .addOption(new Option('--client-id <id>', 'OAuth public client id').default(
    process.env['DSH_CHATGPT_CODEX_CLIENT_ID']?.trim() || DEFAULT_CLIENT_ID,
  ))

program.command('login')
  .description('sign in with a browser callback or device code')
  .option('--device', 'use device-code login instead of a localhost callback')
  .option('--no-open', 'print the browser URL without opening it')
  .option('--port <port>', 'localhost callback port', integer, 1455)
  .option('--timeout <seconds>', 'login timeout in seconds', integer)
  .action(async (options: { device?: boolean; open: boolean; port: number; timeout?: number }, command: Command) => {
    const { auth, globals } = manager(command)
    const credentials = options.device
      ? await auth.loginDevice({
          clientId: globals.clientId,
          ...(options.timeout === undefined ? {} : { timeoutMs: options.timeout * 1000 }),
          onCode: (verificationUrl, userCode) => {
            console.log(`Open: ${verificationUrl}`)
            console.log(`Code: ${userCode}`)
            console.log('Continue only because you started this login in dsh-chatgpt-codex.')
          },
        })
      : await auth.loginBrowser({
          clientId: globals.clientId,
          port: options.port,
          ...(options.timeout === undefined ? {} : { timeoutMs: options.timeout * 1000 }),
          open: options.open,
          onUrl: url => console.log(`Authorize ChatGPT: ${url}`),
        })
    console.log(`Connected: ${accountLine(credentials)}`)
    console.log(`Credentials: ${auth.store.path}`)
  })

program.command('status')
  .description('show safe authentication status')
  .option('--json', 'emit JSON')
  .action(async (options: { json?: boolean }, command: Command) => {
    const { auth } = manager(command)
    const status = await auth.status()
    if (options.json) {
      console.log(JSON.stringify(status, null, 2))
      return
    }
    if (!status.authenticated) {
      console.log('Not connected')
      console.log(`Credentials: ${status.authFile}`)
      return
    }
    console.log(`Connected: ${[status.email ?? status.accountId, status.plan].filter(Boolean).join(' · ')}`)
    console.log(`Method: ${status.authMethod}`)
    console.log(`Expires: ${new Date(status.expiresAt!).toISOString()}${status.expired ? ' (expired)' : ''}`)
    console.log(`Credentials: ${status.authFile}`)
  })

program.command('refresh')
  .description('refresh the access token now')
  .action(async (_options: object, command: Command) => {
    const { auth } = manager(command)
    const credentials = await auth.refresh(true)
    console.log(`Refreshed: ${accountLine(credentials)}`)
    console.log(`Expires: ${new Date(credentials.expiresAt).toISOString()}`)
  })

program.command('logout')
  .description('remove locally stored ChatGPT credentials')
  .action(async (_options: object, command: Command) => {
    const { auth } = manager(command)
    const removed = await auth.logout()
    console.log(removed ? `Removed ${auth.store.path}` : `No credentials at ${auth.store.path}`)
  })

program.command('path')
  .description('print the credential file path')
  .action((_options: object, command: Command) => {
    console.log(manager(command).auth.store.path)
  })

program.parseAsync().catch((error: unknown) => {
  console.error(error instanceof Error ? `Error: ${error.message}` : `Error: ${String(error)}`)
  process.exitCode = 1
})
