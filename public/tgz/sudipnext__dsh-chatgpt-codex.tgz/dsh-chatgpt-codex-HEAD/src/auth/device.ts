import {
  DEFAULT_CLIENT_ID,
  DEFAULT_ISSUER,
  DEVICE_LOGIN_TIMEOUT_MS,
  ORIGINATOR,
} from '../constants.ts'
import { exchangeAuthorizationCode } from './oauth.ts'
import type { OAuthTokenResponse } from './types.ts'

interface UserCodeResponse {
  deviceAuthId: string
  userCode: string
  intervalSeconds: number
}

interface DeviceTokenResponse {
  authorizationCode: string
  codeVerifier: string
}

/** Device-code login configuration. */
export interface DeviceLoginOptions {
  clientId?: string
  issuer?: string
  timeoutMs?: number
  onCode?: (verificationUrl: string, userCode: string) => void
}

function apiEndpoint(issuer: string, path: string): string {
  return `${issuer.replace(/\/+$/, '')}/api/accounts/deviceauth/${path}`
}

async function requestUserCode(clientId: string, issuer: string): Promise<UserCodeResponse> {
  const response = await fetch(apiEndpoint(issuer, 'usercode'), {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'user-agent': ORIGINATOR, originator: ORIGINATOR },
    body: JSON.stringify({ client_id: clientId }),
  })
  if (!response.ok) {
    throw new Error(response.status === 404
      ? 'Device-code login is unavailable; use browser login instead'
      : `Device-code request returned HTTP ${response.status}`)
  }
  const value = await response.json() as Record<string, unknown>
  const deviceAuthId = value['device_auth_id']
  const userCode = value['user_code'] ?? value['usercode']
  const interval = typeof value['interval'] === 'string' ? Number(value['interval']) : value['interval']
  if (typeof deviceAuthId !== 'string' || typeof userCode !== 'string') {
    throw new Error('Device-code endpoint returned an invalid response')
  }
  return {
    deviceAuthId,
    userCode,
    intervalSeconds: typeof interval === 'number' && Number.isFinite(interval) && interval > 0 ? interval : 5,
  }
}

async function delay(ms: number, signal: AbortSignal): Promise<void> {
  await new Promise<void>((resolveDelay, rejectDelay) => {
    if (signal.aborted) {
      rejectDelay(signal.reason)
      return
    }
    const onAbort = (): void => {
      clearTimeout(timer)
      rejectDelay(signal.reason)
    }
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort)
      resolveDelay()
    }, ms)
    signal.addEventListener('abort', onAbort, { once: true })
  })
}

async function pollForToken(
  code: UserCodeResponse,
  issuer: string,
  signal: AbortSignal,
): Promise<DeviceTokenResponse> {
  while (!signal.aborted) {
    const response = await fetch(apiEndpoint(issuer, 'token'), {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'user-agent': ORIGINATOR, originator: ORIGINATOR },
      body: JSON.stringify({ device_auth_id: code.deviceAuthId, user_code: code.userCode }),
      signal,
    })
    if (response.ok) {
      const value = await response.json() as Record<string, unknown>
      if (typeof value['authorization_code'] !== 'string' || typeof value['code_verifier'] !== 'string') {
        throw new Error('Device token endpoint returned an invalid response')
      }
      return { authorizationCode: value['authorization_code'], codeVerifier: value['code_verifier'] }
    }
    if (response.status !== 403 && response.status !== 404 && response.status !== 429) {
      throw new Error(`Device authorization returned HTTP ${response.status}`)
    }
    const retryAfter = Number(response.headers.get('retry-after'))
    const waitMs = Number.isFinite(retryAfter) && retryAfter > 0
      ? retryAfter * 1000
      : code.intervalSeconds * 1000
    await delay(waitMs, signal)
  }
  throw signal.reason
}

/** Sign in on another browser-capable device and exchange the resulting code. */
export async function loginWithDeviceCode(options: DeviceLoginOptions = {}): Promise<OAuthTokenResponse> {
  const clientId = options.clientId ?? DEFAULT_CLIENT_ID
  const issuer = options.issuer ?? DEFAULT_ISSUER
  const code = await requestUserCode(clientId, issuer)
  const verificationUrl = `${issuer.replace(/\/+$/, '')}/codex/device`
  options.onCode?.(verificationUrl, code.userCode)
  const timeoutMs = options.timeoutMs ?? DEVICE_LOGIN_TIMEOUT_MS
  const timeout = AbortSignal.timeout(timeoutMs)
  let deviceToken: DeviceTokenResponse
  try {
    deviceToken = await pollForToken(code, issuer, timeout)
  } catch (cause) {
    if (timeout.aborted) {
      throw new Error(`Device authorization timed out after ${Math.ceil(timeoutMs / 60_000)} minutes`, { cause })
    }
    throw cause
  }
  return exchangeAuthorizationCode({
    code: deviceToken.authorizationCode,
    clientId,
    redirectUri: `${issuer.replace(/\/+$/, '')}/deviceauth/callback`,
    verifier: deviceToken.codeVerifier,
    issuer,
  })
}
