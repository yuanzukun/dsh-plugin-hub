interface OpenAIAuthClaims {
  chatgpt_account_id?: unknown
  chatgpt_plan_type?: unknown
}

/** Claims used to route ChatGPT Codex requests and show safe account status. */
export interface TokenClaims {
  accountId?: string
  email?: string
  plan?: string
  expiresAt?: number
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

/** Decode a JWT payload without treating it as signature verification. */
export function decodeTokenClaims(token: string): TokenClaims {
  const parts = token.split('.')
  if (parts.length !== 3 || parts[1] === undefined) throw new Error('OAuth token is not a JWT')
  let payload: Record<string, unknown>
  try {
    payload = record(JSON.parse(Buffer.from(parts[1], 'base64url').toString('utf8'))) ?? {}
  } catch (cause) {
    throw new Error('OAuth token has an invalid JWT payload', { cause })
  }
  const auth = record(payload['https://api.openai.com/auth']) as OpenAIAuthClaims | undefined
  const accountId = typeof auth?.chatgpt_account_id === 'string' ? auth.chatgpt_account_id : undefined
  const plan = typeof auth?.chatgpt_plan_type === 'string' ? auth.chatgpt_plan_type : undefined
  const email = typeof payload['email'] === 'string' ? payload['email'] : undefined
  const expiresAt = typeof payload['exp'] === 'number' && Number.isFinite(payload['exp'])
    ? payload['exp'] * 1000
    : undefined
  return {
    ...(accountId === undefined ? {} : { accountId }),
    ...(email === undefined ? {} : { email }),
    ...(plan === undefined ? {} : { plan }),
    ...(expiresAt === undefined ? {} : { expiresAt }),
  }
}

/** Read the ChatGPT account id required by the Codex backend. */
export function requireAccountId(accessToken: string, idToken?: string): TokenClaims & { accountId: string } {
  const access = decodeTokenClaims(accessToken)
  let identity: TokenClaims = {}
  if (idToken !== undefined) {
    try {
      identity = decodeTokenClaims(idToken)
    } catch {
      // The access token remains authoritative for request routing.
    }
  }
  const accountId = access.accountId ?? identity.accountId
  if (accountId === undefined || accountId.length === 0) {
    throw new Error('OAuth token does not contain a ChatGPT account id')
  }
  const email = identity.email ?? access.email
  const plan = access.plan ?? identity.plan
  const expiresAt = access.expiresAt ?? identity.expiresAt
  return {
    accountId,
    ...(email === undefined ? {} : { email }),
    ...(plan === undefined ? {} : { plan }),
    ...(expiresAt === undefined ? {} : { expiresAt }),
  }
}
