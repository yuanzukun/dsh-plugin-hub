import { timingSafeEqual } from 'node:crypto'
import { createServer, type Server, type ServerResponse } from 'node:http'
import openBrowser from 'open'
import { DEFAULT_CALLBACK_PORT, DEFAULT_CLIENT_ID, DEFAULT_ISSUER } from '../constants.ts'
import { authorizeUrl, createPkce, createState, exchangeAuthorizationCode } from './oauth.ts'
import type { OAuthTokenResponse } from './types.ts'

/** Browser callback login configuration. */
export interface BrowserLoginOptions {
  clientId?: string
  issuer?: string
  port?: number
  timeoutMs?: number
  open?: boolean
  onUrl?: (url: string) => void
}

function sameState(actual: string, expected: string): boolean {
  const left = Buffer.from(actual)
  const right = Buffer.from(expected)
  return left.length === right.length && timingSafeEqual(left, right)
}

function html(response: ServerResponse, status: number, title: string, detail: string): void {
  response.writeHead(status, {
    'content-type': 'text/html; charset=utf-8',
    'cache-control': 'no-store',
    connection: 'close',
  })
  response.end(`<!doctype html><meta charset="utf-8"><title>${title}</title><style>body{font:16px system-ui;max-width:42rem;margin:12vh auto;padding:2rem;line-height:1.5}h1{font-size:1.6rem}</style><h1>${title}</h1><p>${detail}</p>`)
}

async function closeServer(server: Server): Promise<void> {
  server.closeAllConnections()
  await new Promise<void>(resolveClose => server.close(() => resolveClose()))
}

/** Sign in through a strict-state localhost OAuth callback. */
export async function loginWithBrowser(options: BrowserLoginOptions = {}): Promise<OAuthTokenResponse> {
  const clientId = options.clientId ?? DEFAULT_CLIENT_ID
  const issuer = options.issuer ?? DEFAULT_ISSUER
  const port = options.port ?? DEFAULT_CALLBACK_PORT
  const redirectUri = `http://localhost:${port}/auth/callback`
  const pkce = createPkce()
  const state = createState()
  const url = authorizeUrl({ clientId, redirectUri, state, pkce, issuer })
  let settled = false
  let resolveCode!: (code: string) => void
  let rejectCode!: (error: Error) => void
  const code = new Promise<string>((resolvePromise, rejectPromise) => {
    resolveCode = resolvePromise
    rejectCode = rejectPromise
  })
  const server = createServer((request, response) => {
    if (settled) {
      html(response, 409, 'Login already completed', 'You can close this window.')
      return
    }
    const requestUrl = new URL(request.url ?? '/', redirectUri)
    if (request.method !== 'GET' || requestUrl.pathname !== '/auth/callback') {
      response.writeHead(404, { connection: 'close' }).end('Not found')
      return
    }
    const returnedState = requestUrl.searchParams.get('state') ?? ''
    if (!sameState(returnedState, state)) {
      settled = true
      html(response, 400, 'Login rejected', 'The OAuth state did not match. Start a new login and do not reuse this URL.')
      rejectCode(new Error('OAuth callback state did not match'))
      return
    }
    const oauthError = requestUrl.searchParams.get('error')
    if (oauthError !== null) {
      settled = true
      const description = requestUrl.searchParams.get('error_description') ?? oauthError
      html(response, 400, 'Login failed', 'OpenAI did not authorize this login. Return to the terminal for details.')
      rejectCode(new Error(`OAuth authorization failed: ${description}`))
      return
    }
    const authorizationCode = requestUrl.searchParams.get('code')
    if (!authorizationCode) {
      settled = true
      html(response, 400, 'Login failed', 'The callback did not contain an authorization code.')
      rejectCode(new Error('OAuth callback did not contain an authorization code'))
      return
    }
    settled = true
    html(response, 200, 'ChatGPT connected', 'Authentication succeeded. You can close this window and return to DeepSeek Harness.')
    resolveCode(authorizationCode)
  })
  server.on('clientError', (_error, socket) => socket.destroy())
  await new Promise<void>((resolveListen, rejectListen) => {
    server.once('error', rejectListen)
    server.listen(port, '127.0.0.1', () => {
      server.off('error', rejectListen)
      resolveListen()
    })
  })
  const timer = setTimeout(() => {
    if (!settled) {
      settled = true
      rejectCode(new Error('Browser login timed out'))
    }
  }, options.timeoutMs ?? 5 * 60_000)
  timer.unref()
  try {
    options.onUrl?.(url)
    if (options.open !== false) await openBrowser(url, { wait: false })
    const authorizationCode = await code
    return await exchangeAuthorizationCode({
      code: authorizationCode,
      clientId,
      redirectUri,
      verifier: pkce.verifier,
      issuer,
    })
  } finally {
    clearTimeout(timer)
    await closeServer(server)
  }
}
