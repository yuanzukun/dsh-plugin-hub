/** Login mechanism that produced the stored credentials. */
export type AuthMethod = 'browser' | 'device'

/** Versioned credential document persisted on the local machine. */
export interface StoredCredentials {
  version: 1
  provider: 'openai-codex'
  authMethod: AuthMethod
  clientId: string
  accessToken: string
  refreshToken: string
  idToken?: string
  accountId: string
  email?: string
  plan?: string
  expiresAt: number
  updatedAt: string
}

/** OAuth token endpoint response. Refresh responses may rotate only some tokens. */
export interface OAuthTokenResponse {
  access_token?: string
  refresh_token?: string
  id_token?: string
  expires_in?: number
  token_type?: string
}

/** Public, non-secret status suitable for CLI display. */
export interface AuthStatus {
  authenticated: boolean
  authFile: string
  authMethod?: AuthMethod
  accountId?: string
  email?: string
  plan?: string
  expiresAt?: number
  expired?: boolean
}
