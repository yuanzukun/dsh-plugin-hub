import { chmod, mkdir, open, readFile, rename, stat, unlink } from 'node:fs/promises'
import { homedir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import { randomUUID } from 'node:crypto'
import type { StoredCredentials } from './types.ts'

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function optionalString(value: unknown): value is string | undefined {
  return value === undefined || typeof value === 'string'
}

function parseCredentials(value: unknown): StoredCredentials {
  if (!isRecord(value)
    || value['version'] !== 1
    || value['provider'] !== 'openai-codex'
    || (value['authMethod'] !== 'browser' && value['authMethod'] !== 'device')
    || typeof value['clientId'] !== 'string'
    || typeof value['accessToken'] !== 'string'
    || typeof value['refreshToken'] !== 'string'
    || !optionalString(value['idToken'])
    || typeof value['accountId'] !== 'string'
    || !optionalString(value['email'])
    || !optionalString(value['plan'])
    || typeof value['expiresAt'] !== 'number'
    || !Number.isFinite(value['expiresAt'])
    || typeof value['updatedAt'] !== 'string') {
    throw new Error('ChatGPT Codex credential file has an invalid format')
  }
  return value as unknown as StoredCredentials
}

/** Resolve the credential file without reading or creating it. */
export function defaultAuthFile(env: NodeJS.ProcessEnv = process.env): string {
  const explicit = env['DSH_CHATGPT_CODEX_AUTH_FILE']?.trim()
  if (explicit) return resolve(explicit)
  const dshHome = env['DSH_HOME']?.trim() || join(homedir(), '.dsh')
  return resolve(dshHome, 'chatgpt-codex', 'auth.json')
}

/** Owner-only, atomic JSON credential storage. */
export class AuthStore {
  readonly path: string

  constructor(path = defaultAuthFile()) {
    this.path = resolve(path)
  }

  /** Load credentials, returning undefined only when the file does not exist. */
  async read(): Promise<StoredCredentials | undefined> {
    let raw: string
    try {
      raw = await readFile(this.path, 'utf8')
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return undefined
      throw error
    }
    try {
      return parseCredentials(JSON.parse(raw))
    } catch (cause) {
      throw new Error(`Cannot read ChatGPT Codex credentials at ${this.path}`, { cause })
    }
  }

  /** Atomically replace credentials with an owner-readable document. */
  async write(credentials: StoredCredentials): Promise<void> {
    const parent = dirname(this.path)
    await mkdir(parent, { recursive: true, mode: 0o700 })
    await chmod(parent, 0o700)
    const temporary = join(parent, `.auth-${randomUUID()}.tmp`)
    const handle = await open(temporary, 'wx', 0o600)
    try {
      await handle.writeFile(`${JSON.stringify(credentials, null, 2)}\n`, 'utf8')
      await handle.sync()
      await handle.close()
      await rename(temporary, this.path)
      await chmod(this.path, 0o600)
    } catch (error) {
      await handle.close().catch(() => undefined)
      await unlink(temporary).catch(() => undefined)
      throw error
    }
  }

  /** Serialize refresh-token rotation across processes sharing this store. */
  async withLock<T>(task: () => Promise<T>): Promise<T> {
    const lockPath = `${this.path}.lock`
    const deadline = Date.now() + 10_000
    let handle
    while (handle === undefined) {
      try {
        await mkdir(dirname(this.path), { recursive: true, mode: 0o700 })
        handle = await open(lockPath, 'wx', 0o600)
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code !== 'EEXIST') throw error
        const info = await stat(lockPath).catch(() => undefined)
        if (info !== undefined && Date.now() - info.mtimeMs > 120_000) {
          await unlink(lockPath).catch(() => undefined)
          continue
        }
        if (Date.now() >= deadline) throw new Error(`Timed out waiting for credential lock ${lockPath}`)
        await new Promise(resolveDelay => setTimeout(resolveDelay, 50))
      }
    }
    try {
      await handle.writeFile(`${process.pid}\n`, 'utf8')
      return await task()
    } finally {
      await handle.close().catch(() => undefined)
      await unlink(lockPath).catch(() => undefined)
    }
  }

  /** Remove this exact credential document. */
  async clear(): Promise<boolean> {
    try {
      await unlink(this.path)
      return true
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return false
      throw error
    }
  }
}
