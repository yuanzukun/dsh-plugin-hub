import { createHash, randomBytes } from 'node:crypto'
import { DEFAULT_ISSUER, ORIGINATOR } from '../constants.ts'
import type { OAuthTokenResponse } from './types.ts'

/** PKCE verifier and S256 challenge for one authorization attempt. */
export interface PkceCodes {
  verifier: string
  challenge: string
}

/** Values accepted by the browser authorization URL. */
export interface AuthorizeOptions {
  clientId: string
  redirectUri: string
  state: string
  pkce: PkceCodes
  issuer?: string
}

function endpoint(issuer: string, path: string): string {
  return `${issuer.replace(/\/+$/, '')}${path}`
}

async function tokenError(response: Response): Promise<Error> {
  const body = (await response.text()).slice(0, 2_000)
  let detail = body
  try {
    const parsed = JSON.parse(body) as { error?: unknown; error_description?: unknown }
    detail = typeof parsed.error_description === 'string'
      ? parsed.error_description
      : typeof parsed.error === 'string' ? parsed.error : body
  } catch {
    // Plain-text error bodies are already suitable after truncation.
  }
  return new Error(`OAuth token endpoint returned HTTP ${response.status}${detail ? `: ${detail}` : ''}`)
}

function parseTokenResponse(value: unknown): OAuthTokenResponse {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('OAuth token endpoint returned a non-object response')
  }
  const item = value as Record<string, unknown>
  const response: OAuthTokenResponse = {}
  for (const [wire, local] of [
    ['access_token', 'access_token'],
    ['refresh_token', 'refresh_token'],
    ['id_token', 'id_token'],
    ['token_type', 'token_type'],
  ] as const) {
    if (item[wire] !== undefined && typeof item[wire] !== 'string') {
      throw new Error(`OAuth token response field ${wire} must be a string`)
    }
    if (typeof item[wire] === 'string') response[local] = item[wire]
  }
  if (item['expires_in'] !== undefined) {
    const expires = typeof item['expires_in'] === 'string' ? Number(item['expires_in']) : item['expires_in']
    if (typeof expires !== 'number' || !Number.isFinite(expires) || expires <= 0) {
      throw new Error('OAuth token response field expires_in must be positive')
    }
    response.expires_in = expires
  }
  return response
}

async function postToken(body: URLSearchParams | Record<string, string>, issuer: string): Promise<OAuthTokenResponse> {
  const form = body instanceof URLSearchParams
  const response = await fetch(endpoint(issuer, '/oauth/token'), {
    method: 'POST',
    headers: {
      'content-type': form ? 'application/x-www-form-urlencoded' : 'application/json',
      'user-agent': ORIGINATOR,
      originator: ORIGINATOR,
    },
    body: form ? body.toString() : JSON.stringify(body),
    signal: AbortSignal.timeout(30_000),
  })
  if (!response.ok) throw await tokenError(response)
  return parseTokenResponse(await response.json())
}

/** Create a cryptographically random OAuth state value. */
export function createState(): string {
  return randomBytes(32).toString('base64url')
}

/** Create a fresh S256 PKCE pair. */
export function createPkce(): PkceCodes {
  const verifier = randomBytes(64).toString('base64url')
  const challenge = createHash('sha256').update(verifier).digest('base64url')
  return { verifier, challenge }
}

/** Build the ChatGPT browser authorization URL. */
export function authorizeUrl(options: AuthorizeOptions): string {
  const issuer = options.issuer ?? DEFAULT_ISSUER
  const url = new URL(endpoint(issuer, '/oauth/authorize'))
  url.search = new URLSearchParams({
    response_type: 'code',
    client_id: options.clientId,
    redirect_uri: options.redirectUri,
    scope: 'openid profile email offline_access api.connectors.read api.connectors.invoke',
    code_challenge: options.pkce.challenge,
    code_challenge_method: 'S256',
    id_token_add_organizations: 'true',
    codex_cli_simplified_flow: 'true',
    state: options.state,
    originator: ORIGINATOR,
  }).toString()
  return url.toString()
}

/** Exchange an authorization code for the initial token set. */
export async function exchangeAuthorizationCode(options: {
  code: string
  clientId: string
  redirectUri: string
  verifier: string
  issuer?: string
}): Promise<OAuthTokenResponse> {
  const tokens = await postToken(new URLSearchParams({
    grant_type: 'authorization_code',
    code: options.code,
    redirect_uri: options.redirectUri,
    client_id: options.clientId,
    code_verifier: options.verifier,
  }), options.issuer ?? DEFAULT_ISSUER)
  if (!tokens.access_token || !tokens.refresh_token) {
    throw new Error('OAuth token exchange did not return access and refresh tokens')
  }
  return tokens
}

/** Refresh a ChatGPT OAuth token set. */
export async function refreshOAuthTokens(options: {
  refreshToken: string
  clientId: string
  issuer?: string
}): Promise<OAuthTokenResponse> {
  const tokens = await postToken({
    grant_type: 'refresh_token',
    client_id: options.clientId,
    refresh_token: options.refreshToken,
  }, options.issuer ?? DEFAULT_ISSUER)
  if (!tokens.access_token) throw new Error('OAuth refresh did not return an access token')
  return tokens
}
