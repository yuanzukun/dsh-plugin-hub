import { DEFAULT_CLIENT_ID, DEFAULT_ISSUER, REFRESH_SKEW_MS } from '../constants.ts'
import { loginWithBrowser, type BrowserLoginOptions } from './browser.ts'
import { loginWithDeviceCode, type DeviceLoginOptions } from './device.ts'
import { requireAccountId } from './jwt.ts'
import { refreshOAuthTokens } from './oauth.ts'
import { AuthStore } from './store.ts'
import type { AuthMethod, AuthStatus, OAuthTokenResponse, StoredCredentials } from './types.ts'

function materializeCredentials(
  method: AuthMethod,
  clientId: string,
  tokens: OAuthTokenResponse,
  previous?: StoredCredentials,
): StoredCredentials {
  const accessToken = tokens.access_token ?? previous?.accessToken
  const refreshToken = tokens.refresh_token ?? previous?.refreshToken
  const idToken = tokens.id_token ?? previous?.idToken
  if (!accessToken || !refreshToken) throw new Error('OAuth response did not provide usable credentials')
  const claims = requireAccountId(accessToken, idToken)
  const expiresAt = tokens.expires_in === undefined
    ? claims.expiresAt
    : Date.now() + tokens.expires_in * 1000
  if (expiresAt === undefined || !Number.isFinite(expiresAt)) {
    throw new Error('OAuth access token does not contain an expiry')
  }
  return {
    version: 1,
    provider: 'openai-codex',
    authMethod: method,
    clientId,
    accessToken,
    refreshToken,
    ...(idToken === undefined ? {} : { idToken }),
    accountId: claims.accountId,
    ...(claims.email === undefined ? {} : { email: claims.email }),
    ...(claims.plan === undefined ? {} : { plan: claims.plan }),
    expiresAt,
    updatedAt: new Date().toISOString(),
  }
}

/** OAuth lifecycle facade shared by the CLI and DSH adapter. */
export class AuthManager {
  readonly store: AuthStore
  private readonly issuer: string
  private refreshInFlight: Promise<StoredCredentials> | undefined

  constructor(options: { store?: AuthStore; issuer?: string } = {}) {
    this.store = options.store ?? new AuthStore()
    this.issuer = options.issuer ?? DEFAULT_ISSUER
  }

  /** Complete browser callback login and persist the resulting credentials. */
  async loginBrowser(options: BrowserLoginOptions = {}): Promise<StoredCredentials> {
    const clientId = options.clientId ?? DEFAULT_CLIENT_ID
    const tokens = await loginWithBrowser({ ...options, clientId, issuer: options.issuer ?? this.issuer })
    const credentials = materializeCredentials('browser', clientId, tokens)
    await this.store.write(credentials)
    return credentials
  }

  /** Complete device-code login and persist the resulting credentials. */
  async loginDevice(options: DeviceLoginOptions = {}): Promise<StoredCredentials> {
    const clientId = options.clientId ?? DEFAULT_CLIENT_ID
    const tokens = await loginWithDeviceCode({ ...options, clientId, issuer: options.issuer ?? this.issuer })
    const credentials = materializeCredentials('device', clientId, tokens)
    await this.store.write(credentials)
    return credentials
  }

  /** Return public account status without exposing token material. */
  async status(): Promise<AuthStatus> {
    const credentials = await this.store.read()
    if (credentials === undefined) return { authenticated: false, authFile: this.store.path }
    return {
      authenticated: true,
      authFile: this.store.path,
      authMethod: credentials.authMethod,
      accountId: credentials.accountId,
      ...(credentials.email === undefined ? {} : { email: credentials.email }),
      ...(credentials.plan === undefined ? {} : { plan: credentials.plan }),
      expiresAt: credentials.expiresAt,
      expired: credentials.expiresAt <= Date.now(),
    }
  }

  /** Return a fresh access token, refreshing once when its safety window begins. */
  async accessToken(): Promise<StoredCredentials> {
    const current = await this.store.read()
    if (current === undefined) {
      throw new Error(`ChatGPT is not connected. Run dsh-chatgpt-codex login (credentials: ${this.store.path})`)
    }
    return current.expiresAt - Date.now() > REFRESH_SKEW_MS ? current : this.refresh(false, current)
  }

  /** Refresh credentials; forced refresh is used after an authenticated HTTP 401. */
  async refresh(force = true, observed?: StoredCredentials): Promise<StoredCredentials> {
    if (this.refreshInFlight !== undefined) return this.refreshInFlight
    const promise = this.store.withLock(async () => {
      const current = await this.store.read()
      if (current === undefined) throw new Error('ChatGPT is not connected')
      if (observed !== undefined && current.updatedAt !== observed.updatedAt) return current
      if (!force && current.expiresAt - Date.now() > REFRESH_SKEW_MS) return current
      const tokens = await refreshOAuthTokens({
        refreshToken: current.refreshToken,
        clientId: current.clientId,
        issuer: this.issuer,
      })
      const refreshed = materializeCredentials(current.authMethod, current.clientId, tokens, current)
      await this.store.write(refreshed)
      return refreshed
    })
    this.refreshInFlight = promise
    try {
      return await promise
    } finally {
      if (this.refreshInFlight === promise) this.refreshInFlight = undefined
    }
  }

  /** Remove local credentials. */
  logout(): Promise<boolean> {
    return this.store.clear()
  }
}

export type { AuthStatus, StoredCredentials } from './types.ts'
export { AuthStore, defaultAuthFile } from './store.ts'
