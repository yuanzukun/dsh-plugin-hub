/** ChatGPT OAuth and native Codex Responses integration for DeepSeek Harness. */
import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { AuthManager } from './auth/manager.ts'
import { AuthStore, defaultAuthFile } from './auth/store.ts'
import { CodexAdapter } from './adapter/adapter.ts'
import { DEFAULT_MODELS, type CodexModel } from './adapter/catalog.ts'
import { DEFAULT_CODEX_BASE_URL, DEFAULT_ISSUER, ORIGINATOR, PROVIDER } from './constants.ts'

export const name = 'dsh-chatgpt-codex'
export const inject = ['llm']

/** Plugin configuration. OAuth login itself is performed by the bundled CLI. */
export interface Config {
  authFile?: string
  issuer?: string
  baseURL?: string
  originator?: string
  models?: CodexModel[]
  defaultReasoningEffort?: 'low' | 'medium' | 'high' | 'xhigh' | 'max'
  textVerbosity?: 'low' | 'medium' | 'high'
  requestTimeoutMs?: number
}

const modelSchema: z<CodexModel> = z.object({
  id: z.string().required(),
  name: z.string().required(),
  description: z.string(),
  contextWindow: z.number().step(1).min(1).required(),
  inputModalities: z.array(z.union(['text', 'image'])).required(),
  reasoningEfforts: z.array(z.union(['low', 'medium', 'high', 'xhigh', 'max'])).required(),
})

export const Config: z<Config> = z.object({
  authFile: z.string().default(defaultAuthFile()),
  issuer: z.string().default(DEFAULT_ISSUER),
  baseURL: z.string().default(DEFAULT_CODEX_BASE_URL),
  originator: z.string().default(ORIGINATOR),
  models: z.array(modelSchema).default(DEFAULT_MODELS),
  defaultReasoningEffort: z.union(['low', 'medium', 'high', 'xhigh', 'max']).default('high'),
  textVerbosity: z.union(['low', 'medium', 'high']).default('low'),
  requestTimeoutMs: z.number().step(1).min(1).max(2_147_483_647).default(300_000),
})

function validatedModels(models: readonly CodexModel[]): CodexModel[] {
  const seen = new Set<string>()
  return models.map(model => {
    if (model.id.length === 0 || model.name.length === 0) throw new Error('Codex model id and name must be non-empty')
    if (seen.has(model.id)) throw new Error(`duplicate Codex model id ${model.id}`)
    if (model.inputModalities.length === 0) throw new Error(`Codex model ${model.id} needs an input modality`)
    if (model.reasoningEfforts.length === 0) throw new Error(`Codex model ${model.id} needs a reasoning effort`)
    seen.add(model.id)
    return {
      ...model,
      inputModalities: [...model.inputModalities],
      reasoningEfforts: [...model.reasoningEfforts],
    }
  })
}

/** Register the `openai-codex` route on the DSH LLM service. */
export function apply(ctx: Context, config: Config = {}): void {
  const models = validatedModels(config.models ?? DEFAULT_MODELS)
  const auth = new AuthManager({
    store: new AuthStore(config.authFile ?? defaultAuthFile()),
    issuer: config.issuer ?? DEFAULT_ISSUER,
  })
  const attachments = ctx.get('attachments')
  const adapter = new CodexAdapter({
    auth,
    models,
    ...(attachments === undefined ? {} : { attachments }),
    baseURL: config.baseURL ?? DEFAULT_CODEX_BASE_URL,
    originator: config.originator ?? ORIGINATOR,
    defaultReasoningEffort: config.defaultReasoningEffort ?? 'high',
    textVerbosity: config.textVerbosity ?? 'low',
    requestTimeoutMs: config.requestTimeoutMs ?? 300_000,
  })
  ctx.llm.registerAdapter([PROVIDER], adapter)
}

export { CodexAdapter, PROVIDER } from './adapter/adapter.ts'
export { DEFAULT_MODELS } from './adapter/catalog.ts'
export type { CodexAdapterOptions } from './adapter/adapter.ts'
export type { CodexModel } from './adapter/catalog.ts'
export { AuthManager, AuthStore, defaultAuthFile } from './auth/manager.ts'
export type { AuthStatus, StoredCredentials } from './auth/manager.ts'
