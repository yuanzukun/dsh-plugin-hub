import { LlmError } from '@deepseek-ai/dsh-llm'
import type { ContentBlock, GenerateOptions, Message } from '@deepseek-ai/dsh-llm'
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment'
import type {
  ResponseFunctionCallOutputItemList,
  ResponseInputContent,
  ResponseInputItem,
  Tool,
} from 'openai/resources/responses/responses'
import { replayItems } from './replay.ts'

function textOf(blocks: readonly ContentBlock[]): string {
  return blocks.map(block => block.type === 'text'
    ? block.text
    : block.type === 'tool-result' ? textOf(block.content) : '').join('')
}

async function contentOf(
  blocks: readonly ContentBlock[],
  attachments: AttachmentStore | undefined,
  signal?: AbortSignal,
): Promise<ResponseInputContent[]> {
  const content: ResponseInputContent[] = []
  for (const block of blocks) {
    switch (block.type) {
      case 'text':
        if (block.text.length > 0) content.push({ type: 'input_text', text: block.text })
        break
      case 'image': {
        if (attachments === undefined) {
          throw new LlmError('ChatGPT Codex image input requires the DSH attachment service', 'UNSUPPORTED_CONTENT')
        }
        const stored = await attachments.readImage(block.attachment, signal)
        content.push({
          type: 'input_image',
          detail: 'auto',
          image_url: `data:${stored.ref.mediaType};base64,${Buffer.from(stored.data).toString('base64')}`,
        })
        break
      }
      case 'tool-result':
        content.push(...await contentOf(block.content, attachments, signal))
        break
      default:
        break
    }
  }
  return content
}

function foreignAssistant(message: Message): ResponseInputItem[] {
  const items: ResponseInputItem[] = []
  for (const block of message.content) {
    switch (block.type) {
      case 'text':
        if (block.text.length > 0) items.push({ role: 'assistant', content: block.text })
        break
      case 'tool-call':
        items.push({
          type: 'function_call',
          call_id: block.id,
          name: block.name,
          arguments: block.arguments,
        })
        break
      case 'image':
        throw new LlmError('ChatGPT Codex cannot replay structured assistant image output', 'UNSUPPORTED_CONTENT')
      default:
        // Reasoning is replayed only with its encrypted provider item.
        break
    }
  }
  return items
}

async function toolOutput(
  block: Extract<ContentBlock, { type: 'tool-result' }>,
  attachments: AttachmentStore | undefined,
  signal?: AbortSignal,
): Promise<string | ResponseFunctionCallOutputItemList> {
  const content = await contentOf(block.content, attachments, signal)
  if (content.some(part => part.type === 'input_image')) {
    return content.filter((part): part is Extract<typeof part, { type: 'input_text' | 'input_image' }> =>
      part.type === 'input_text' || part.type === 'input_image')
  }
  return textOf(block.content) || '(no tool output)'
}

async function convertMessage(
  message: Message,
  attachments: AttachmentStore | undefined,
  signal?: AbortSignal,
): Promise<ResponseInputItem[]> {
  if (message.role === 'assistant') return replayItems(message) ?? foreignAssistant(message)
  if (message.role === 'system') {
    const content = textOf(message.content)
    return content.length === 0 ? [] : [{ role: 'developer', content }]
  }
  const items: ResponseInputItem[] = []
  const regular = message.content.filter(block => block.type !== 'tool-result')
  const content = await contentOf(regular, attachments, signal)
  const results = message.content.filter(block => block.type === 'tool-result')
  if (content.length > 0 || results.length === 0) items.push({ role: 'user', content })
  for (const result of results) {
    items.push({
      type: 'function_call_output',
      call_id: result.toolCallId,
      output: await toolOutput(result, attachments, signal),
    })
  }
  return items
}

/** Convert DSH history into stateless OpenAI Responses input items. */
export async function convertInput(
  options: GenerateOptions,
  attachments?: AttachmentStore,
): Promise<ResponseInputItem[]> {
  const items: ResponseInputItem[] = []
  for (const message of options.messages) {
    items.push(...await convertMessage(message, attachments, options.signal))
  }
  return items
}

/** Convert DSH JSON-schema tools into Responses function tools. */
export function convertTools(options: GenerateOptions): Tool[] | undefined {
  if (options.tools === undefined || options.tools.length === 0) return undefined
  return options.tools.map(tool => ({
    type: 'function',
    name: tool.name,
    description: tool.description,
    parameters: tool.parameters,
    strict: null,
  }))
}
