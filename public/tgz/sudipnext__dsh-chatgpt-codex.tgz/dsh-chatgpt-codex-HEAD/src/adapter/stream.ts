import { CallId, EMPTY_RESPONSE_CODE, LlmError } from '@deepseek-ai/dsh-llm'
import type { FinishReason, StreamChunk, TokenUsage } from '@deepseek-ai/dsh-llm'
import type { ResponseOutputItem } from 'openai/resources/responses/responses'
import { createReplayState } from './replay.ts'

interface OpenBlock {
  index: number
  outputIndex: number
  kind: 'text' | 'reasoning' | 'tool-call'
  started: boolean
  text: string
  callId?: string
  name?: string
  closed: boolean
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function integer(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 ? value : undefined
}

function itemKind(item: Record<string, unknown>): OpenBlock['kind'] | undefined {
  switch (item['type']) {
    case 'message': return 'text'
    case 'reasoning': return 'reasoning'
    case 'function_call': return 'tool-call'
    default: return undefined
  }
}

function finalText(item: Record<string, unknown>, kind: OpenBlock['kind']): string {
  if (kind === 'tool-call') return typeof item['arguments'] === 'string' ? item['arguments'] : ''
  const list = kind === 'reasoning' ? item['summary'] : item['content']
  if (!Array.isArray(list)) return ''
  return list.map(part => {
    const value = record(part)
    return typeof value?.['text'] === 'string' ? value['text'] : ''
  }).join('')
}

function startChunk(block: OpenBlock): StreamChunk {
  block.started = true
  return { type: 'block-start', index: block.index, blockType: block.kind }
}

function deltaChunk(block: OpenBlock, delta: string): StreamChunk {
  block.text += delta
  switch (block.kind) {
    case 'text': return { type: 'text-delta', index: block.index, text: delta }
    case 'reasoning': return { type: 'reasoning-delta', index: block.index, text: delta }
    case 'tool-call': return {
      type: 'tool-call-delta',
      index: block.index,
      id: CallId(block.callId ?? ''),
      ...(block.name === undefined ? {} : { name: block.name }),
      argumentsDelta: delta,
    }
  }
}

function closeChunks(block: OpenBlock, item: Record<string, unknown>): StreamChunk[] {
  if (block.closed) return []
  const chunks: StreamChunk[] = []
  const complete = finalText(item, block.kind)
  if (!block.started && (complete.length > 0 || block.kind === 'tool-call')) chunks.push(startChunk(block))
  if (!complete.startsWith(block.text)) {
    throw new LlmError(`Codex ${block.kind} final content did not match streamed deltas`, 'MALFORMED_RESPONSE')
  }
  const missing = complete.slice(block.text.length)
  if (missing.length > 0) chunks.push(deltaChunk(block, missing))
  block.closed = true
  if (!block.started) return chunks
  switch (block.kind) {
    case 'text': chunks.push({ type: 'block-end', index: block.index, block: { type: 'text', text: complete } }); break
    case 'reasoning': chunks.push({ type: 'block-end', index: block.index, block: { type: 'reasoning', text: complete } }); break
    case 'tool-call': {
      const callId = typeof item['call_id'] === 'string' ? item['call_id'] : block.callId ?? ''
      const name = typeof item['name'] === 'string' ? item['name'] : block.name ?? ''
      chunks.push({
        type: 'block-end',
        index: block.index,
        block: { type: 'tool-call', id: CallId(callId), name, arguments: complete },
      })
      break
    }
  }
  return chunks
}

function mapUsage(value: unknown): TokenUsage | undefined {
  const usage = record(value)
  if (usage === undefined) return undefined
  const input = typeof usage['input_tokens'] === 'number' ? usage['input_tokens'] : 0
  const output = typeof usage['output_tokens'] === 'number' ? usage['output_tokens'] : 0
  const inputDetails = record(usage['input_tokens_details'])
  const outputDetails = record(usage['output_tokens_details'])
  const cached = typeof inputDetails?.['cached_tokens'] === 'number' ? inputDetails['cached_tokens'] : undefined
  const reasoning = typeof outputDetails?.['reasoning_tokens'] === 'number'
    ? outputDetails['reasoning_tokens']
    : undefined
  return {
    inputTokens: Math.max(0, input - (cached ?? 0)),
    outputTokens: output,
    ...(cached === undefined ? {} : { cacheReadTokens: cached }),
    ...(reasoning === undefined ? {} : { reasoningTokens: reasoning }),
  }
}

function finishReason(response: Record<string, unknown>, hasTools: boolean, hasBlocks: boolean): FinishReason {
  const status = response['status']
  if (status === 'failed' || status === 'cancelled') {
    const error = record(response['error'])
    const message = typeof error?.['message'] === 'string' ? error['message'] : `Codex response ${String(status)}`
    const code = typeof error?.['code'] === 'string' ? error['code'] : String(status).toUpperCase()
    return { kind: 'error', failure: { message, code } }
  }
  if (status === 'incomplete') {
    const details = record(response['incomplete_details'])
    const reason = typeof details?.['reason'] === 'string' ? details['reason'] : 'incomplete'
    return reason === 'max_output_tokens'
      ? { kind: 'max-tokens' }
      : { kind: 'error', failure: { message: `Codex response incomplete: ${reason}`, code: reason.toUpperCase() } }
  }
  if (!hasBlocks) {
    return {
      kind: 'error',
      failure: { message: 'Codex returned a completed response with no content', code: EMPTY_RESPONSE_CODE },
    }
  }
  return hasTools ? { kind: 'tool-calls' } : { kind: 'stop' }
}

/** Translate the OpenAI SDK event stream into DSH chunks. */
export async function* translateCodexStream(
  events: AsyncIterable<unknown>,
  model: string,
): AsyncGenerator<StreamChunk> {
  const blocks = new Map<number, OpenBlock>()
  let nextIndex = 0
  let terminal = false

  const ensure = (outputIndex: number, item?: Record<string, unknown>): OpenBlock | undefined => {
    const existing = blocks.get(outputIndex)
    if (existing !== undefined) return existing
    if (item === undefined) return undefined
    const kind = itemKind(item)
    if (kind === undefined) return undefined
    const block: OpenBlock = {
      index: nextIndex++,
      outputIndex,
      kind,
      started: false,
      text: '',
      ...(typeof item['call_id'] === 'string' ? { callId: item['call_id'] } : {}),
      ...(typeof item['name'] === 'string' ? { name: item['name'] } : {}),
      closed: false,
    }
    blocks.set(outputIndex, block)
    return block
  }

  for await (const raw of events) {
    const event = record(raw)
    if (event === undefined || typeof event['type'] !== 'string') {
      throw new LlmError('Codex stream returned a malformed event', 'MALFORMED_RESPONSE')
    }
    const type = event['type']
    if (type === 'error' || type === 'response.failed') {
      const response = record(event['response'])
      const error = record(event['error']) ?? record(response?.['error'])
      const message = typeof error?.['message'] === 'string' ? error['message'] : 'Codex response failed'
      const code = typeof error?.['code'] === 'string' ? error['code'] : 'SERVER'
      throw new LlmError(message, code)
    }
    if (type === 'response.output_item.added') {
      const outputIndex = integer(event['output_index'])
      const item = record(event['item'])
      if (outputIndex !== undefined && item !== undefined) {
        const block = ensure(outputIndex, item)
        if (block?.kind === 'tool-call' && !block.started) yield startChunk(block)
      }
      continue
    }
    if (type === 'response.output_text.delta'
      || type === 'response.reasoning_summary_text.delta'
      || type === 'response.function_call_arguments.delta') {
      const outputIndex = integer(event['output_index'])
      const delta = event['delta']
      if (outputIndex === undefined || typeof delta !== 'string') {
        throw new LlmError(`Codex ${type} event is malformed`, 'MALFORMED_RESPONSE')
      }
      const expected = type === 'response.output_text.delta'
        ? 'text'
        : type === 'response.reasoning_summary_text.delta' ? 'reasoning' : 'tool-call'
      const block = ensure(outputIndex)
      if (block === undefined || block.kind !== expected) {
        throw new LlmError(`Codex ${type} event has no matching output item`, 'MALFORMED_RESPONSE')
      }
      if (!block.started) yield startChunk(block)
      if (delta.length > 0) yield deltaChunk(block, delta)
      continue
    }
    if (type === 'response.output_item.done') {
      const outputIndex = integer(event['output_index'])
      const item = record(event['item'])
      if (outputIndex === undefined || item === undefined) {
        throw new LlmError('Codex output-item completion is malformed', 'MALFORMED_RESPONSE')
      }
      const block = ensure(outputIndex, item)
      if (block !== undefined) for (const chunk of closeChunks(block, item)) yield chunk
      continue
    }
    if (type === 'response.completed' || type === 'response.done' || type === 'response.incomplete') {
      const response = record(event['response'])
      if (response === undefined || !Array.isArray(response['output'])) {
        throw new LlmError('Codex terminal event has no response output', 'MALFORMED_RESPONSE')
      }
      const output = response['output']
      for (const [outputIndex, rawItem] of output.entries()) {
        const item = record(rawItem)
        if (item === undefined) throw new LlmError('Codex response output item is malformed', 'MALFORMED_RESPONSE')
        const block = ensure(outputIndex, item)
        if (block !== undefined) for (const chunk of closeChunks(block, item)) yield chunk
      }
      const usage = mapUsage(response['usage'])
      if (usage !== undefined) yield { type: 'usage', usage }
      const openBlocks = [...blocks.values()].filter(block => block.started)
      yield {
        type: 'finish',
        reason: finishReason(response, openBlocks.some(block => block.kind === 'tool-call'), openBlocks.length > 0),
        replayState: createReplayState(model, output as ResponseOutputItem[]),
      }
      terminal = true
      return
    }
  }
  if (!terminal) throw new LlmError('Codex stream ended without a terminal event', 'STREAM_CLOSED')
}
