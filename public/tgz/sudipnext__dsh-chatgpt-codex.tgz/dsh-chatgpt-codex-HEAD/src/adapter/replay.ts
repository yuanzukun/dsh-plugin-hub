import { LlmError } from '@deepseek-ai/dsh-llm'
import type { ContentBlock, Message, ModelMessageSource } from '@deepseek-ai/dsh-llm'
import type {
  ResponseFunctionToolCall,
  ResponseInputItem,
  ResponseOutputItem,
  ResponseOutputMessage,
  ResponseReasoningItem,
} from 'openai/resources/responses/responses'
import { PROVIDER } from '../constants.ts'

type ReplayItem = ResponseOutputMessage | ResponseReasoningItem | ResponseFunctionToolCall

/** Versioned provider items required for stateless Responses replay. */
export interface CodexReplayState {
  kind: 'dsh-chatgpt-codex'
  version: 1
  provider: 'openai-codex'
  model: string
  items: ReplayItem[]
}

function invalid(message: string): never {
  throw new LlmError(`invalid ChatGPT Codex replay state: ${message}`, 'INVALID_REPLAY_STATE')
}

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

function sanitizeItem(value: unknown, index: number): ReplayItem {
  const item = record(value)
  if (item === undefined || typeof item['type'] !== 'string') return invalid(`item ${index} is not an object`)
  switch (item['type']) {
    case 'reasoning': {
      if (typeof item['id'] !== 'string' || !Array.isArray(item['summary'])) {
        return invalid(`reasoning item ${index} is malformed`)
      }
      const summary = item['summary'].map((part, partIndex) => {
        const candidate = record(part)
        if (candidate?.['type'] !== 'summary_text' || typeof candidate['text'] !== 'string') {
          return invalid(`reasoning item ${index} summary ${partIndex} is malformed`)
        }
        return { type: 'summary_text' as const, text: candidate['text'] }
      })
      if (item['encrypted_content'] !== undefined
        && item['encrypted_content'] !== null
        && typeof item['encrypted_content'] !== 'string') {
        return invalid(`reasoning item ${index} encrypted content is malformed`)
      }
      return {
        type: 'reasoning',
        id: item['id'],
        summary,
        ...(typeof item['encrypted_content'] === 'string' ? { encrypted_content: item['encrypted_content'] } : {}),
        ...(item['status'] === 'completed' || item['status'] === 'incomplete' || item['status'] === 'in_progress'
          ? { status: item['status'] }
          : {}),
      }
    }
    case 'message': {
      if (typeof item['id'] !== 'string' || item['role'] !== 'assistant' || !Array.isArray(item['content'])) {
        return invalid(`message item ${index} is malformed`)
      }
      const content = item['content'].map((part, partIndex) => {
        const candidate = record(part)
        if (candidate?.['type'] !== 'output_text' || typeof candidate['text'] !== 'string') {
          return invalid(`message item ${index} content ${partIndex} is unsupported`)
        }
        return { type: 'output_text' as const, text: candidate['text'], annotations: [] }
      })
      const rawPhase = item['phase']
      const phase: 'commentary' | 'final_answer' | undefined = rawPhase === 'commentary' || rawPhase === 'final_answer'
        ? rawPhase
        : undefined
      return {
        type: 'message',
        id: item['id'],
        role: 'assistant',
        status: item['status'] === 'incomplete' ? 'incomplete' : 'completed',
        content,
        ...(phase === undefined ? {} : { phase }),
      }
    }
    case 'function_call':
      if (typeof item['call_id'] !== 'string'
        || typeof item['name'] !== 'string'
        || typeof item['arguments'] !== 'string') {
        return invalid(`function call item ${index} is malformed`)
      }
      return {
        type: 'function_call',
        call_id: item['call_id'],
        name: item['name'],
        arguments: item['arguments'],
        ...(typeof item['id'] === 'string' ? { id: item['id'] } : {}),
        status: item['status'] === 'incomplete' ? 'incomplete' : 'completed',
      }
    default: return invalid(`item ${index} has unsupported type ${item['type']}`)
  }
}

function projectedBlocks(items: readonly ReplayItem[]): ContentBlock[] {
  const blocks: ContentBlock[] = []
  for (const item of items) {
    switch (item.type) {
      case 'reasoning': {
        const text = item.summary.map(part => part.text).join('')
        if (text.length > 0) blocks.push({ type: 'reasoning', text })
        break
      }
      case 'message': {
        const text = item.content
          .filter(part => part.type === 'output_text')
          .map(part => part.text)
          .join('')
        if (text.length > 0) blocks.push({ type: 'text', text })
        break
      }
      case 'function_call':
        blocks.push({ type: 'tool-call', id: item.call_id as never, name: item.name, arguments: item.arguments })
        break
    }
  }
  return blocks
}

function sameBlock(left: ContentBlock, right: ContentBlock): boolean {
  if (left.type !== right.type) return false
  switch (left.type) {
    case 'text': return right.type === 'text' && left.text === right.text
    case 'reasoning': return right.type === 'reasoning' && left.text === right.text
    case 'tool-call': return right.type === 'tool-call'
      && left.id === right.id
      && left.name === right.name
      && left.arguments === right.arguments
    default: return false
  }
}

function parseState(raw: unknown, source: ModelMessageSource, message: Message): CodexReplayState {
  const state = record(raw)
  if (state?.['kind'] !== 'dsh-chatgpt-codex' || state['version'] !== 1) return invalid('unknown kind or version')
  if (state['provider'] !== PROVIDER || state['provider'] !== source.provider) return invalid('provider does not match')
  if (typeof state['model'] !== 'string' || state['model'] !== source.model) return invalid('model does not match')
  if (!Array.isArray(state['items'])) return invalid('items must be an array')
  const items = state['items'].map(sanitizeItem)
  const projected = projectedBlocks(items)
  if (projected.length !== message.content.length
    || projected.some((block, index) => !sameBlock(block, message.content[index]!))) {
    return invalid('provider items do not match durable assistant content')
  }
  return { kind: 'dsh-chatgpt-codex', version: 1, provider: PROVIDER, model: state['model'], items }
}

/** Rehydrate same-adapter assistant state, or return undefined for foreign history. */
export function replayItems(message: Message): ResponseInputItem[] | undefined {
  const source = message.source
  if (source.kind !== 'model' || source.provider !== PROVIDER) return undefined
  if (source.replayState === undefined) return undefined
  return parseState(source.replayState, source, message).items
}

/** Capture completed provider items in a JSON-safe replay envelope. */
export function createReplayState(model: string, output: readonly ResponseOutputItem[]): CodexReplayState {
  return {
    kind: 'dsh-chatgpt-codex',
    version: 1,
    provider: PROVIDER,
    model,
    items: output.map(sanitizeItem),
  }
}
