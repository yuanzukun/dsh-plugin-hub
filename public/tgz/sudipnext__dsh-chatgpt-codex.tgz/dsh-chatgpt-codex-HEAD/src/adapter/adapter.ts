import { createHash } from 'node:crypto'
import OpenAI, { APIError } from 'openai'
import type { ResponseCreateParamsStreaming } from 'openai/resources/responses/responses'
import {
  attributionHeaders,
  isQuotaExceededError,
  LlmAdapter,
  LlmError,
  ProviderRequestId,
} from '@deepseek-ai/dsh-llm'
import type {
  GenerateOptions,
  LlmModelInfo,
  LlmProviderInfo,
  LlmResolvedModelInfo,
  StreamChunk,
} from '@deepseek-ai/dsh-llm'
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment'
import { DEFAULT_CODEX_BASE_URL, ORIGINATOR, PROVIDER } from '../constants.ts'
import { AuthManager } from '../auth/manager.ts'
import type { StoredCredentials } from '../auth/types.ts'
import { catalogEntries, type CodexModel, resolveCatalogModel } from './catalog.ts'
import { convertInput, convertTools } from './convert.ts'
import { translateCodexStream } from './stream.ts'

const EFFORTS = new Set(['low', 'medium', 'high', 'xhigh', 'max'])

/** Runtime options for the native DSH Codex adapter. */
export interface CodexAdapterOptions {
  auth: AuthManager
  attachments?: AttachmentStore
  baseURL?: string
  originator?: string
  models: readonly CodexModel[]
  defaultReasoningEffort?: CodexModel['reasoningEfforts'][number]
  textVerbosity?: 'low' | 'medium' | 'high'
  requestTimeoutMs?: number
}

function normalizeBaseURL(value: string): string {
  const trimmed = value.replace(/\/+$/, '')
  return trimmed.endsWith('/responses') ? trimmed.slice(0, -'/responses'.length) : trimmed
}

function sessionKey(value: string | undefined): string | undefined {
  if (value === undefined) return undefined
  return value.length <= 64 ? value : createHash('sha256').update(value).digest('hex')
}

function retryAfter(headers: Headers | undefined): number | undefined {
  if (headers === undefined) return undefined
  const milliseconds = Number(headers.get('retry-after-ms'))
  if (Number.isFinite(milliseconds) && milliseconds > 0) return milliseconds
  const raw = headers.get('retry-after')
  if (raw === null) return undefined
  const seconds = Number(raw)
  if (Number.isFinite(seconds) && seconds > 0) return seconds * 1000
  const date = Date.parse(raw)
  return Number.isNaN(date) || date <= Date.now() ? undefined : date - Date.now()
}

function providerError(error: unknown, aborted: boolean): LlmError {
  if (error instanceof LlmError) return error
  if (aborted) return new LlmError('ChatGPT Codex request was aborted', 'ABORTED', { cause: error })
  if (error instanceof APIError) {
    const detail = [error.code, error.type, error.message].filter(Boolean).join(' ')
    const status = error.status
    const code = status === 401 || status === 403
      ? 'AUTH'
      : isQuotaExceededError(detail) ? 'QUOTA'
        : status === 429 ? 'RATE_LIMIT'
          : status >= 500 ? 'SERVER' : 'PROVIDER_ERROR'
    const requestId = error.requestID ? ProviderRequestId(error.requestID) : undefined
    const delay = retryAfter(error.headers)
    return new LlmError(`ChatGPT Codex request failed: ${error.message}`, code, {
      cause: error,
      status,
      ...(requestId === undefined ? {} : { requestId }),
      ...(delay === undefined ? {} : { providerRetryAfterMs: delay }),
    })
  }
  const message = error instanceof Error ? error.message : String(error)
  return new LlmError(`ChatGPT Codex transport failed: ${message}`, 'TRANSPORT', { cause: error })
}

function isUnauthorized(error: unknown): boolean {
  return error instanceof APIError && error.status === 401
}

/** Native ChatGPT Codex Responses adapter with OAuth token refresh. */
export class CodexAdapter extends LlmAdapter {
  private readonly options: CodexAdapterOptions

  constructor(options: CodexAdapterOptions) {
    super()
    this.options = options
  }

  override providerInfo(provider: string): LlmProviderInfo {
    return { id: provider, name: 'OpenAI Codex (ChatGPT)' }
  }

  override listModels(): Promise<readonly LlmModelInfo[]> {
    return Promise.resolve(catalogEntries(this.options.models))
  }

  override resolveModel(_provider: string, model: string): Promise<LlmResolvedModelInfo> {
    return Promise.resolve(resolveCatalogModel(this.options.models, model, this.options.defaultReasoningEffort))
  }

  private client(credentials: StoredCredentials, sessionId?: string): OpenAI {
    const key = sessionKey(sessionId)
    return new OpenAI({
      apiKey: credentials.accessToken,
      baseURL: normalizeBaseURL(this.options.baseURL ?? DEFAULT_CODEX_BASE_URL),
      defaultHeaders: {
        ...attributionHeaders(),
        'chatgpt-account-id': credentials.accountId,
        originator: this.options.originator ?? ORIGINATOR,
        'OpenAI-Beta': 'responses=experimental',
        ...(key === undefined ? {} : { 'session-id': key, 'x-client-request-id': key }),
      },
      maxRetries: 0,
      timeout: this.options.requestTimeoutMs ?? 300_000,
    })
  }

  private async params(options: GenerateOptions): Promise<ResponseCreateParamsStreaming> {
    if (options.temperature !== undefined) {
      throw new LlmError('ChatGPT Codex does not support the DSH temperature option', 'UNSUPPORTED_OPTION')
    }
    if (options.maxTokens !== undefined) {
      throw new LlmError('ChatGPT Codex controls its own output limit and does not support maxTokens', 'UNSUPPORTED_OPTION')
    }
    if (options.stop !== undefined && options.stop.length > 0) {
      throw new LlmError('ChatGPT Codex does not support stop sequences', 'UNSUPPORTED_OPTION')
    }
    const effort = options.reasoningEffort?.toString()
    if (effort !== undefined && !EFFORTS.has(effort)) {
      throw new LlmError(`ChatGPT Codex does not support reasoning effort ${effort}`, 'UNSUPPORTED_OPTION')
    }
    const tools = convertTools(options)
    const cacheKey = sessionKey(options.sessionId)
    return {
      model: options.model,
      instructions: options.system ?? 'You are a helpful coding assistant.',
      input: await convertInput(options, this.options.attachments),
      ...(tools === undefined ? {} : { tools }),
      tool_choice: 'auto',
      parallel_tool_calls: true,
      reasoning: {
        effort: (effort ?? this.options.defaultReasoningEffort ?? 'high') as 'low' | 'medium' | 'high' | 'xhigh',
        summary: 'auto',
      },
      include: ['reasoning.encrypted_content'],
      text: { verbosity: this.options.textVerbosity ?? 'low' },
      ...(cacheKey === undefined ? {} : { prompt_cache_key: cacheKey }),
      store: false,
      stream: true,
    }
  }

  override async *stream(options: GenerateOptions): AsyncGenerator<StreamChunk> {
    const params = await this.params(options)
    let credentials = await this.options.auth.accessToken()
    let emitted = false
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const events = await this.client(credentials, options.sessionId).responses.create(params, {
          ...(options.signal === undefined ? {} : { signal: options.signal }),
        })
        for await (const chunk of translateCodexStream(events, options.model)) {
          emitted = true
          yield chunk
        }
        return
      } catch (error) {
        if (attempt === 0 && !emitted && isUnauthorized(error)) {
          credentials = await this.options.auth.refresh(true, credentials)
          continue
        }
        throw providerError(error, options.signal?.aborted ?? false)
      }
    }
  }
}

export { PROVIDER }
