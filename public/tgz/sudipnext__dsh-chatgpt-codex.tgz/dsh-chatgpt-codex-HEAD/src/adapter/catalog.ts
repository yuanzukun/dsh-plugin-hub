import { ReasoningEffortId } from '@deepseek-ai/dsh-llm'
import type { LlmModelInfo, LlmResolvedModelInfo } from '@deepseek-ai/dsh-llm'
import { PROVIDER } from '../constants.ts'

/** Configurable model metadata advertised to DeepSeek Harness. */
export interface CodexModel {
  id: string
  name: string
  description?: string
  contextWindow: number
  inputModalities: Array<'text' | 'image'>
  reasoningEfforts: Array<'low' | 'medium' | 'high' | 'xhigh' | 'max'>
}

/** Current ChatGPT Codex model catalog; availability still depends on the signed-in plan. */
export const DEFAULT_MODELS: CodexModel[] = [
  {
    id: 'gpt-5.6-luna',
    name: 'GPT-5.6 Luna',
    description: 'Fast Codex model for everyday agent work',
    contextWindow: 272_000,
    inputModalities: ['text', 'image'],
    reasoningEfforts: ['low', 'medium', 'high', 'xhigh', 'max'],
  },
  {
    id: 'gpt-5.6-terra',
    name: 'GPT-5.6 Terra',
    description: 'Balanced Codex model for complex coding work',
    contextWindow: 272_000,
    inputModalities: ['text', 'image'],
    reasoningEfforts: ['low', 'medium', 'high', 'xhigh', 'max'],
  },
  {
    id: 'gpt-5.6-sol',
    name: 'GPT-5.6 Sol',
    description: 'Frontier Codex model for the hardest agent tasks',
    contextWindow: 272_000,
    inputModalities: ['text', 'image'],
    reasoningEfforts: ['low', 'medium', 'high', 'xhigh', 'max'],
  },
  {
    id: 'gpt-5.5',
    name: 'GPT-5.5',
    contextWindow: 272_000,
    inputModalities: ['text', 'image'],
    reasoningEfforts: ['low', 'medium', 'high', 'xhigh'],
  },
  {
    id: 'gpt-5.4-mini',
    name: 'GPT-5.4 mini',
    contextWindow: 272_000,
    inputModalities: ['text', 'image'],
    reasoningEfforts: ['low', 'medium', 'high', 'xhigh'],
  },
  {
    id: 'gpt-5.4',
    name: 'GPT-5.4',
    contextWindow: 272_000,
    inputModalities: ['text', 'image'],
    reasoningEfforts: ['low', 'medium', 'high', 'xhigh'],
  },
  {
    id: 'gpt-5.3-codex-spark',
    name: 'GPT-5.3 Codex Spark',
    contextWindow: 128_000,
    inputModalities: ['text'],
    reasoningEfforts: ['low', 'medium', 'high', 'xhigh'],
  },
]

/** Convert configurable metadata into advisory catalog entries. */
export function catalogEntries(models: readonly CodexModel[]): LlmModelInfo[] {
  return models.map(model => ({
    provider: PROVIDER,
    id: model.id,
    name: model.name,
    ...(model.description === undefined ? {} : { description: model.description }),
    inputModalities: model.inputModalities,
  }))
}

/** Resolve exact model metadata without rejecting unlisted model ids. */
export function resolveCatalogModel(
  models: readonly CodexModel[],
  modelId: string,
  defaultEffort: CodexModel['reasoningEfforts'][number] | undefined,
): LlmResolvedModelInfo {
  const model = models.find(candidate => candidate.id === modelId)
  if (model === undefined) return { provider: PROVIDER, id: modelId, name: modelId }
  const effort = defaultEffort !== undefined && model.reasoningEfforts.includes(defaultEffort)
    ? defaultEffort
    : undefined
  return {
    ...catalogEntries([model])[0]!,
    context: { contextWindow: model.contextWindow },
    reasoning: {
      efforts: model.reasoningEfforts.map(id => ({
        id: ReasoningEffortId(id),
        name: id === 'xhigh' ? 'Extra high' : id[0]!.toUpperCase() + id.slice(1),
      })),
      ...(effort === undefined ? {} : { defaultEffort: ReasoningEffortId(effort) }),
    },
  }
}
