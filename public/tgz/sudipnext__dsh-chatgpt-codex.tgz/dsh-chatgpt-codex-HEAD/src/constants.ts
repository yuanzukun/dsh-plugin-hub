/** Public OAuth client used by the official Codex CLI. */
export const DEFAULT_CLIENT_ID = 'app_EMoamEEZ73f0CkXaXp7hrann'

/** Production OpenAI identity issuer. */
export const DEFAULT_ISSUER = 'https://auth.openai.com'

/** ChatGPT Codex Responses base URL. */
export const DEFAULT_CODEX_BASE_URL = 'https://chatgpt.com/backend-api/codex'

/** Provider route registered in DeepSeek Harness. */
export const PROVIDER = 'openai-codex'

/** Product identity sent to the OAuth and Codex services. */
export const ORIGINATOR = 'dsh-chatgpt-codex'

/** Default localhost callback port used by Codex OAuth clients. */
export const DEFAULT_CALLBACK_PORT = 1455

/** Refresh before expiry so a request never starts with an almost-expired token. */
export const REFRESH_SKEW_MS = 120_000

/** Device authorization expires after fifteen minutes. */
export const DEVICE_LOGIN_TIMEOUT_MS = 15 * 60_000
