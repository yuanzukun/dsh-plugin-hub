# Contributing

Issues and pull requests are welcome. Keep changes focused and include tests for authentication state, token rotation, provider wire behavior, or stream translation when those surfaces change.

```sh
pnpm install
pnpm run check
```

Tests must use synthetic tokens and local servers. Never commit credentials, captured authorization URLs, real account ids, or provider response bodies containing user content.

For behavior changes, explain the user-visible result and any DSH or Codex compatibility requirement in the pull request.
