# Architecture

`dsh-chatgpt-codex` is one DSH bundle with two independently usable surfaces: an authentication CLI and a Cordis LLM plugin.

## Authentication

The browser path creates a fresh PKCE pair and state, opens OpenAI's authorize endpoint, and accepts one callback on `127.0.0.1:1455`. The device path requests a user code, polls only the documented pending statuses, then exchanges the returned authorization code with its server-issued verifier. Both paths write the same versioned credential document.

`AuthManager.accessToken()` reads the document for each model request. It refreshes two minutes before expiry. A process-local shared promise coalesces concurrent callers, while an owner-only adjacent lock file serializes refresh-token rotation across DSH processes. The manager re-reads credentials after acquiring the lock so it can use another process's successful rotation without reusing the old refresh token.

## Model request

`CodexAdapter` registers the `openai-codex` provider on `ctx.llm`. It converts DSH messages, durable image attachments, JSON-schema tools, and tool results to Responses input items. The request uses `store: false` and asks for `reasoning.encrypted_content`, so no server-side response history is required.

The official OpenAI JavaScript SDK sends the HTTPS request and parses SSE framing. The project-owned translator maps provider events into DSH block start/delta/end chunks, disjoint cached-token usage, and one terminal finish chunk.

## Replay

Reasoning models require completed reasoning items on subsequent stateless requests. The finish chunk therefore stores a versioned replay projection containing only supported response output items. Before replay, the plugin validates its version, provider, model, fields, and exact projection against the durable DSH assistant blocks. Foreign assistant history keeps visible text and function calls but omits reasoning that has no encrypted provider item.

## Dependencies

- `openai`: official Responses HTTP/SSE client
- `open`: cross-platform browser launch; login also supports `--no-open`
- `commander`: CLI parsing
- `@deepseek-ai/dsh-llm`: provider-neutral adapter protocol
- `@deepseek-ai/dsh-attachment`: durable image lookup type/service

There is no `pi-ai` dependency.
