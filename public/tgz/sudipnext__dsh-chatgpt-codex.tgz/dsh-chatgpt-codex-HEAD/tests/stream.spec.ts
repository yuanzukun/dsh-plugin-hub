import { CallId } from '@deepseek-ai/dsh-llm'
import { describe, expect, it } from 'vitest'
import { translateCodexStream } from '../src/adapter/stream.ts'

async function* events(values: unknown[]): AsyncGenerator<unknown> {
  yield* values
}

describe('Codex stream translation', () => {
  it('streams reasoning, text, tools, disjoint usage, and replay state', async () => {
    const reasoning = {
      type: 'reasoning', id: 'rs_1', summary: [{ type: 'summary_text', text: 'Think' }],
      encrypted_content: 'encrypted', status: 'completed',
    }
    const message = {
      type: 'message', id: 'msg_1', role: 'assistant', status: 'completed',
      content: [{ type: 'output_text', text: 'Hello', annotations: [] }], phase: 'final_answer',
    }
    const tool = {
      type: 'function_call', id: 'fc_1', call_id: 'call_1', name: 'read_file',
      arguments: '{"path":"a"}', status: 'completed',
    }
    const chunks = []
    for await (const chunk of translateCodexStream(events([
      { type: 'response.output_item.added', output_index: 0, item: { ...reasoning, summary: [] } },
      { type: 'response.reasoning_summary_text.delta', output_index: 0, delta: 'Think' },
      { type: 'response.output_item.done', output_index: 0, item: reasoning },
      { type: 'response.output_item.added', output_index: 1, item: { ...message, content: [] } },
      { type: 'response.output_text.delta', output_index: 1, delta: 'Hello' },
      { type: 'response.output_item.done', output_index: 1, item: message },
      { type: 'response.output_item.added', output_index: 2, item: { ...tool, arguments: '' } },
      { type: 'response.function_call_arguments.delta', output_index: 2, delta: '{"path":"a"}' },
      { type: 'response.output_item.done', output_index: 2, item: tool },
      {
        type: 'response.completed',
        response: {
          status: 'completed',
          output: [reasoning, message, tool],
          usage: {
            input_tokens: 100,
            output_tokens: 20,
            input_tokens_details: { cached_tokens: 40 },
            output_tokens_details: { reasoning_tokens: 5 },
          },
        },
      },
    ]), 'gpt-test')) chunks.push(chunk)

    expect(chunks).toContainEqual({ type: 'reasoning-delta', index: 0, text: 'Think' })
    expect(chunks).toContainEqual({ type: 'text-delta', index: 1, text: 'Hello' })
    expect(chunks).toContainEqual({
      type: 'block-end', index: 2,
      block: { type: 'tool-call', id: CallId('call_1'), name: 'read_file', arguments: '{"path":"a"}' },
    })
    expect(chunks).toContainEqual({
      type: 'usage',
      usage: { inputTokens: 60, outputTokens: 20, cacheReadTokens: 40, reasoningTokens: 5 },
    })
    expect(chunks.at(-1)).toMatchObject({
      type: 'finish',
      reason: { kind: 'tool-calls' },
      replayState: { kind: 'dsh-chatgpt-codex', version: 1, model: 'gpt-test' },
    })
  })

  it('maps an incomplete max-token response', async () => {
    const message = {
      type: 'message', id: 'msg_1', role: 'assistant', status: 'incomplete',
      content: [{ type: 'output_text', text: 'partial', annotations: [] }],
    }
    const chunks = []
    for await (const chunk of translateCodexStream(events([{
      type: 'response.incomplete',
      response: {
        status: 'incomplete',
        incomplete_details: { reason: 'max_output_tokens' },
        output: [message],
      },
    }]), 'gpt-test')) chunks.push(chunk)
    expect(chunks.at(-1)).toMatchObject({ type: 'finish', reason: { kind: 'max-tokens' } })
  })
})
