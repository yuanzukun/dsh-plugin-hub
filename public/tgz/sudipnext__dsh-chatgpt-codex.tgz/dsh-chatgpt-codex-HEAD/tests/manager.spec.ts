import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { AuthManager } from '../src/auth/manager.ts'
import { AuthStore } from '../src/auth/store.ts'
import type { StoredCredentials } from '../src/auth/types.ts'
import { accessToken } from './helpers.ts'

afterEach(() => vi.unstubAllGlobals())

describe('AuthManager refresh', () => {
  it('coalesces concurrent refreshes and preserves an unrotated refresh token', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-chatgpt-codex-manager-'))
    const store = new AuthStore(join(root, 'auth.json'))
    const old: StoredCredentials = {
      version: 1,
      provider: 'openai-codex',
      authMethod: 'device',
      clientId: 'client',
      accessToken: accessToken('acct-test', Date.now() + 1_000),
      refreshToken: 'refresh-original',
      accountId: 'acct-test',
      expiresAt: Date.now() + 1_000,
      updatedAt: new Date(0).toISOString(),
    }
    await store.write(old)
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({
      access_token: accessToken('acct-test', Date.now() + 3_600_000),
      expires_in: 3600,
    }), { status: 200, headers: { 'content-type': 'application/json' } }))
    vi.stubGlobal('fetch', fetchMock)
    const auth = new AuthManager({ store })
    const [first, second] = await Promise.all([auth.accessToken(), auth.accessToken()])
    expect(first.accessToken).toBe(second.accessToken)
    expect(first.refreshToken).toBe('refresh-original')
    expect(fetchMock).toHaveBeenCalledOnce()
    expect((await store.read())?.accessToken).toBe(first.accessToken)
  })
})
