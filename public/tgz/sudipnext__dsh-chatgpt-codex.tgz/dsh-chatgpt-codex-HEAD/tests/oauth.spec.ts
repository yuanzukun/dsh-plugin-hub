import { get } from 'node:http'
import { createServer } from 'node:net'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { loginWithBrowser } from '../src/auth/browser.ts'
import { loginWithDeviceCode } from '../src/auth/device.ts'
import { authorizeUrl, createPkce } from '../src/auth/oauth.ts'
import { accessToken } from './helpers.ts'

async function freePort(): Promise<number> {
  const server = createServer()
  await new Promise<void>(resolveListen => server.listen(0, '127.0.0.1', resolveListen))
  const address = server.address()
  if (address === null || typeof address === 'string') throw new Error('test server did not bind TCP')
  await new Promise<void>(resolveClose => server.close(() => resolveClose()))
  return address.port
}

function callback(url: string, state: string): Promise<void> {
  const target = new URL(url)
  const redirect = new URL(target.searchParams.get('redirect_uri')!)
  return new Promise((resolveRequest, rejectRequest) => {
    get(`http://127.0.0.1:${redirect.port}/auth/callback?code=code-1&state=${encodeURIComponent(state)}`, response => {
      response.resume()
      response.once('end', resolveRequest)
    }).once('error', rejectRequest)
  })
}

afterEach(() => vi.unstubAllGlobals())

describe('OAuth flows', () => {
  it('builds the simplified-flow authorize URL with PKCE', () => {
    const pkce = createPkce()
    const value = new URL(authorizeUrl({
      clientId: 'client',
      redirectUri: 'http://localhost:1455/auth/callback',
      state: 'state',
      pkce,
    }))
    expect(value.origin).toBe('https://auth.openai.com')
    expect(value.searchParams.get('code_challenge_method')).toBe('S256')
    expect(value.searchParams.get('codex_cli_simplified_flow')).toBe('true')
    expect(value.searchParams.get('state')).toBe('state')
    expect(pkce.verifier).not.toBe(pkce.challenge)
  })

  it('completes browser callback login and exchanges the code', async () => {
    const port = await freePort()
    const fetchMock = vi.fn(async (_input: string | URL | Request, init?: RequestInit) => {
      expect(init?.body?.toString()).toContain('code=code-1')
      return new Response(JSON.stringify({
        access_token: accessToken(),
        refresh_token: 'refresh-1',
        id_token: accessToken(),
      }), { status: 200, headers: { 'content-type': 'application/json' } })
    })
    vi.stubGlobal('fetch', fetchMock)
    let callbackRequest: Promise<void> | undefined
    const tokens = await loginWithBrowser({
      port,
      open: false,
      onUrl: url => {
        const state = new URL(url).searchParams.get('state')!
        callbackRequest = callback(url, state)
      },
    })
    await callbackRequest
    expect(tokens.refresh_token).toBe('refresh-1')
    expect(fetchMock).toHaveBeenCalledOnce()
  })

  it('rejects a browser callback whose state does not match', async () => {
    const port = await freePort()
    const fetchMock = vi.fn()
    vi.stubGlobal('fetch', fetchMock)
    await expect(loginWithBrowser({
      port,
      open: false,
      onUrl: url => void callback(url, 'wrong-state'),
    })).rejects.toThrow('state did not match')
    expect(fetchMock).not.toHaveBeenCalled()
  })

  it('polls device authorization and exchanges its PKCE code', async () => {
    const responses = [
      new Response(JSON.stringify({ device_auth_id: 'device-1', user_code: 'ABCD-1234', interval: '0.001' }), { status: 200 }),
      new Response('', { status: 403 }),
      new Response(JSON.stringify({ authorization_code: 'code-device', code_verifier: 'verifier-device' }), { status: 200 }),
      new Response(JSON.stringify({ access_token: accessToken(), refresh_token: 'refresh-device' }), { status: 200 }),
    ]
    const fetchMock = vi.fn(async () => responses.shift()!)
    vi.stubGlobal('fetch', fetchMock)
    const onCode = vi.fn()
    const tokens = await loginWithDeviceCode({ timeoutMs: 2_000, onCode })
    expect(onCode).toHaveBeenCalledWith('https://auth.openai.com/codex/device', 'ABCD-1234')
    expect(tokens.refresh_token).toBe('refresh-device')
    expect(fetchMock).toHaveBeenCalledTimes(4)
  })
})
