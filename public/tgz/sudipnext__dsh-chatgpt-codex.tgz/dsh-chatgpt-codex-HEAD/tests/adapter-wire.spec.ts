import { createServer } from 'node:http'
import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createMessage } from '@deepseek-ai/dsh-llm'
import { afterEach, describe, expect, it } from 'vitest'
import { CodexAdapter } from '../src/adapter/adapter.ts'
import { DEFAULT_MODELS } from '../src/adapter/catalog.ts'
import { AuthManager } from '../src/auth/manager.ts'
import { AuthStore } from '../src/auth/store.ts'
import type { StoredCredentials } from '../src/auth/types.ts'
import { accessToken } from './helpers.ts'

const servers: Array<ReturnType<typeof createServer>> = []

afterEach(async () => {
  await Promise.all(servers.splice(0).map(server => new Promise<void>(resolveClose => server.close(() => resolveClose()))))
})

describe('CodexAdapter wire request', () => {
  it('sends DSH attribution, ChatGPT routing, Codex payload, and consumes SDK SSE', async () => {
    let requestHeaders: Record<string, string | string[] | undefined> = {}
    let requestBody: Record<string, unknown> = {}
    const server = createServer((request, response) => {
      requestHeaders = request.headers
      const parts: Buffer[] = []
      request.on('data', part => parts.push(part as Buffer))
      request.on('end', () => {
        requestBody = JSON.parse(Buffer.concat(parts).toString('utf8')) as Record<string, unknown>
        const message = {
          type: 'message', id: 'msg_1', role: 'assistant', status: 'completed',
          content: [{ type: 'output_text', text: 'ready', annotations: [] }],
        }
        response.writeHead(200, { 'content-type': 'text/event-stream' })
        for (const event of [
          { type: 'response.output_item.added', output_index: 0, item: { ...message, content: [] } },
          { type: 'response.output_text.delta', output_index: 0, delta: 'ready' },
          { type: 'response.output_item.done', output_index: 0, item: message },
          { type: 'response.completed', response: { status: 'completed', output: [message], usage: { input_tokens: 2, output_tokens: 1 } } },
        ]) response.write(`data: ${JSON.stringify(event)}\n\n`)
        response.end('data: [DONE]\n\n')
      })
    })
    servers.push(server)
    await new Promise<void>(resolveListen => server.listen(0, '127.0.0.1', resolveListen))
    const address = server.address()
    if (address === null || typeof address === 'string') throw new Error('test server did not bind TCP')

    const root = await mkdtemp(join(tmpdir(), 'dsh-chatgpt-codex-wire-'))
    const store = new AuthStore(join(root, 'auth.json'))
    const credentials: StoredCredentials = {
      version: 1,
      provider: 'openai-codex',
      authMethod: 'browser',
      clientId: 'client',
      accessToken: accessToken('acct-wire'),
      refreshToken: 'refresh',
      accountId: 'acct-wire',
      expiresAt: Date.now() + 3_600_000,
      updatedAt: new Date().toISOString(),
    }
    await store.write(credentials)
    const adapter = new CodexAdapter({
      auth: new AuthManager({ store }),
      models: DEFAULT_MODELS,
      baseURL: `http://127.0.0.1:${address.port}/codex`,
    })
    const chunks = []
    for await (const chunk of adapter.stream({
      provider: 'openai-codex',
      model: 'gpt-5.6-luna',
      system: 'Be concise.',
      messages: [createMessage({
        role: 'user',
        content: [{ type: 'text', text: 'Hello' }],
        source: { kind: 'plugin', plugin: 'test' },
      })],
      tools: [{ name: 'read_file', description: 'Read a file', parameters: { type: 'object' } }],
    })) chunks.push(chunk)

    expect(requestHeaders['authorization']).toBe(`Bearer ${credentials.accessToken}`)
    expect(requestHeaders['chatgpt-account-id']).toBe('acct-wire')
    expect(requestHeaders['originator']).toBe('dsh-chatgpt-codex')
    expect(requestHeaders['user-agent']).toMatch(/^deepseek-harness\//)
    expect(requestBody).toMatchObject({
      model: 'gpt-5.6-luna',
      instructions: 'Be concise.',
      store: false,
      stream: true,
      tool_choice: 'auto',
      parallel_tool_calls: true,
    })
    expect(chunks).toContainEqual({ type: 'text-delta', index: 0, text: 'ready' })
    expect(chunks.at(-1)).toMatchObject({ type: 'finish', reason: { kind: 'stop' } })
  })
})
