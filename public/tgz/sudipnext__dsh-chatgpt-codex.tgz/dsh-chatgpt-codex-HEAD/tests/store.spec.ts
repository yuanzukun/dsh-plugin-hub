import { mkdtemp, readFile, stat } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it } from 'vitest'
import { AuthStore } from '../src/auth/store.ts'
import type { StoredCredentials } from '../src/auth/types.ts'
import { accessToken } from './helpers.ts'

function credentials(): StoredCredentials {
  return {
    version: 1,
    provider: 'openai-codex',
    authMethod: 'browser',
    clientId: 'client',
    accessToken: accessToken(),
    refreshToken: 'refresh',
    accountId: 'acct-test',
    email: 'test@example.com',
    plan: 'plus',
    expiresAt: Date.now() + 3_600_000,
    updatedAt: new Date().toISOString(),
  }
}

describe('AuthStore', () => {
  it('atomically writes owner-only credentials and removes the exact file', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-chatgpt-codex-store-'))
    const path = join(root, 'nested', 'auth.json')
    const store = new AuthStore(path)
    const value = credentials()
    await store.write(value)

    expect(await store.read()).toEqual(value)
    expect(JSON.parse(await readFile(path, 'utf8'))).toEqual(value)
    if (process.platform !== 'win32') expect((await stat(path)).mode & 0o777).toBe(0o600)
    expect(await store.clear()).toBe(true)
    expect(await store.clear()).toBe(false)
    expect(await store.read()).toBeUndefined()
  })

  it('rejects malformed stored data without returning token fragments', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-chatgpt-codex-store-'))
    const store = new AuthStore(join(root, 'auth.json'))
    await store.write(credentials())
    const raw = JSON.parse(await readFile(store.path, 'utf8')) as Record<string, unknown>
    raw['version'] = 99
    await import('node:fs/promises').then(fs => fs.writeFile(store.path, JSON.stringify(raw)))
    await expect(store.read()).rejects.toThrow(`Cannot read ChatGPT Codex credentials at ${store.path}`)
  })
})
