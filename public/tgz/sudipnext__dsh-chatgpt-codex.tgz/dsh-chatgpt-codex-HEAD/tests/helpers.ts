/** Build an unsigned JWT-shaped value for protocol tests. */
export function jwt(claims: Record<string, unknown>): string {
  const encode = (value: unknown): string => Buffer.from(JSON.stringify(value)).toString('base64url')
  return `${encode({ alg: 'none' })}.${encode(claims)}.`
}

/** Token carrying the account and expiry fields consumed by the plugin. */
export function accessToken(accountId = 'acct-test', expiresAt = Date.now() + 3_600_000): string {
  return jwt({
    exp: Math.floor(expiresAt / 1000),
    email: 'test@example.com',
    'https://api.openai.com/auth': {
      chatgpt_account_id: accountId,
      chatgpt_plan_type: 'plus',
    },
  })
}
