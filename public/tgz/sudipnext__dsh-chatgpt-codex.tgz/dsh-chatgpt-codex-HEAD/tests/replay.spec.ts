import { CallId, createMessage } from '@deepseek-ai/dsh-llm'
import { describe, expect, it } from 'vitest'
import { convertInput } from '../src/adapter/convert.ts'
import { createReplayState } from '../src/adapter/replay.ts'

const output = [
  {
    type: 'reasoning' as const,
    id: 'rs_1',
    summary: [{ type: 'summary_text' as const, text: 'Checked' }],
    encrypted_content: 'ciphertext',
    status: 'completed' as const,
  },
  {
    type: 'message' as const,
    id: 'msg_1',
    role: 'assistant' as const,
    status: 'completed' as const,
    content: [{ type: 'output_text' as const, text: 'Done', annotations: [] }],
    phase: 'final_answer' as const,
  },
  {
    type: 'function_call' as const,
    id: 'fc_1',
    call_id: 'call_1',
    name: 'read_file',
    arguments: '{"path":"a"}',
    status: 'completed' as const,
  },
]

describe('Codex replay', () => {
  it('rehydrates encrypted provider items after validating durable content', async () => {
    const state = createReplayState('gpt-test', output)
    const message = createMessage({
      role: 'assistant',
      content: [
        { type: 'reasoning', text: 'Checked' },
        { type: 'text', text: 'Done' },
        { type: 'tool-call', id: CallId('call_1'), name: 'read_file', arguments: '{"path":"a"}' },
      ],
      source: { kind: 'model', provider: 'openai-codex', model: 'gpt-test', replayState: state },
    })
    const input = await convertInput({ provider: 'openai-codex', model: 'gpt-test', messages: [message] })
    expect(input).toEqual(state.items)
    expect(input[0]).toMatchObject({ type: 'reasoning', encrypted_content: 'ciphertext' })
  })

  it('rejects replay metadata that no longer matches durable assistant content', async () => {
    const state = createReplayState('gpt-test', output)
    const message = createMessage({
      role: 'assistant',
      content: [{ type: 'text', text: 'Changed' }],
      source: { kind: 'model', provider: 'openai-codex', model: 'gpt-test', replayState: state },
    })
    await expect(convertInput({ provider: 'openai-codex', model: 'gpt-test', messages: [message] }))
      .rejects.toMatchObject({ code: 'INVALID_REPLAY_STATE' })
  })
})
