# Security policy

## Reporting

Do not open a public issue for a vulnerability, OAuth token exposure, or authentication bypass. Use GitHub's **Report a vulnerability** form in the Security tab of this repository and include affected versions, reproduction steps, and impact.

Never attach real access, refresh, or ID tokens. Synthetic JWT-shaped test values are sufficient for reports and reproductions.

## Supported versions

Security fixes are made on the latest tagged release. This project depends on pre-release DeepSeek Harness interfaces and does not promise fixes for older plugin versions.

## Credential scope

The plugin stores ChatGPT OAuth credentials locally. On POSIX the credential file is mode `0600` and its directory is mode `0700`; operating-system ACLs remain authoritative on Windows. `logout` deletes the local file but does not revoke the upstream OpenAI session.
