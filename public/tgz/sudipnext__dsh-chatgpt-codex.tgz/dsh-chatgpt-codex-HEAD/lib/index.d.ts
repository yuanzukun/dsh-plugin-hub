import { CodexModel, DEFAULT_MODELS } from "./adapter/catalog.js";
import { PROVIDER } from "./constants.js";
import { AuthStatus, StoredCredentials } from "./auth/types.js";
import { AuthStore, defaultAuthFile } from "./auth/store.js";
import { AuthManager } from "./auth/manager.js";
import { CodexAdapter, CodexAdapterOptions } from "./adapter/adapter.js";
import z from "@deepseek-ai/schemastery";
import { Context } from "@deepseek-ai/cordis";
//#region src/index.d.ts
declare const name = "dsh-chatgpt-codex";
declare const inject: string[];
/** Plugin configuration. OAuth login itself is performed by the bundled CLI. */
interface Config {
  authFile?: string;
  issuer?: string;
  baseURL?: string;
  originator?: string;
  models?: CodexModel[];
  defaultReasoningEffort?: 'low' | 'medium' | 'high' | 'xhigh' | 'max';
  textVerbosity?: 'low' | 'medium' | 'high';
  requestTimeoutMs?: number;
}
declare const Config: z<Config>;
/** Register the `openai-codex` route on the DSH LLM service. */
declare function apply(ctx: Context, config?: Config): void;
//#endregion
export { AuthManager, type AuthStatus, AuthStore, CodexAdapter, type CodexAdapterOptions, type CodexModel, Config, DEFAULT_MODELS, PROVIDER, type StoredCredentials, apply, defaultAuthFile, inject, name };
//# sourceMappingURL=index.d.ts.map