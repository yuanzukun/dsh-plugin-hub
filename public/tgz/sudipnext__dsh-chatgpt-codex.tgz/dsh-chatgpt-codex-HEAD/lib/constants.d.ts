//#region src/constants.d.ts
/** Provider route registered in DeepSeek Harness. */
declare const PROVIDER = "openai-codex";
//#endregion
export { PROVIDER };
//# sourceMappingURL=constants.d.ts.map