import { CodexModel } from "./catalog.js";
import { PROVIDER } from "../constants.js";
import { AuthManager } from "../auth/manager.js";
import { GenerateOptions, LlmAdapter, LlmModelInfo, LlmProviderInfo, LlmResolvedModelInfo, StreamChunk } from "@deepseek-ai/dsh-llm";
import { AttachmentStore } from "@deepseek-ai/dsh-attachment";
//#region src/adapter/adapter.d.ts
/** Runtime options for the native DSH Codex adapter. */
interface CodexAdapterOptions {
  auth: AuthManager;
  attachments?: AttachmentStore;
  baseURL?: string;
  originator?: string;
  models: readonly CodexModel[];
  defaultReasoningEffort?: CodexModel['reasoningEfforts'][number];
  textVerbosity?: 'low' | 'medium' | 'high';
  requestTimeoutMs?: number;
}
/** Native ChatGPT Codex Responses adapter with OAuth token refresh. */
declare class CodexAdapter extends LlmAdapter {
  private readonly options;
  constructor(options: CodexAdapterOptions);
  providerInfo(provider: string): LlmProviderInfo;
  listModels(): Promise<readonly LlmModelInfo[]>;
  resolveModel(_provider: string, model: string): Promise<LlmResolvedModelInfo>;
  private client;
  private params;
  stream(options: GenerateOptions): AsyncGenerator<StreamChunk>;
}
//#endregion
export { CodexAdapter, CodexAdapterOptions, PROVIDER };
//# sourceMappingURL=adapter.d.ts.map