import { LlmModelInfo, LlmResolvedModelInfo } from "@deepseek-ai/dsh-llm";
//#region src/adapter/catalog.d.ts
/** Configurable model metadata advertised to DeepSeek Harness. */
interface CodexModel {
  id: string;
  name: string;
  description?: string;
  contextWindow: number;
  inputModalities: Array<'text' | 'image'>;
  reasoningEfforts: Array<'low' | 'medium' | 'high' | 'xhigh' | 'max'>;
}
/** Current ChatGPT Codex model catalog; availability still depends on the signed-in plan. */
declare const DEFAULT_MODELS: CodexModel[];
//#endregion
export { CodexModel, DEFAULT_MODELS };
//# sourceMappingURL=catalog.d.ts.map