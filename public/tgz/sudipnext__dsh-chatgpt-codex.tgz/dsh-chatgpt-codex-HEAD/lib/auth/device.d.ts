//#region src/auth/device.d.ts
/** Device-code login configuration. */
interface DeviceLoginOptions {
  clientId?: string;
  issuer?: string;
  timeoutMs?: number;
  onCode?: (verificationUrl: string, userCode: string) => void;
}
//#endregion
export { DeviceLoginOptions };
//# sourceMappingURL=device.d.ts.map