import { StoredCredentials } from "./types.js";
//#region src/auth/store.d.ts
/** Resolve the credential file without reading or creating it. */
declare function defaultAuthFile(env?: NodeJS.ProcessEnv): string;
/** Owner-only, atomic JSON credential storage. */
declare class AuthStore {
  readonly path: string;
  constructor(path?: string);
  /** Load credentials, returning undefined only when the file does not exist. */
  read(): Promise<StoredCredentials | undefined>;
  /** Atomically replace credentials with an owner-readable document. */
  write(credentials: StoredCredentials): Promise<void>;
  /** Serialize refresh-token rotation across processes sharing this store. */
  withLock<T>(task: () => Promise<T>): Promise<T>;
  /** Remove this exact credential document. */
  clear(): Promise<boolean>;
}
//#endregion
export { AuthStore, defaultAuthFile };
//# sourceMappingURL=store.d.ts.map