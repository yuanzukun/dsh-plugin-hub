import { AuthStatus, StoredCredentials } from "./types.js";
import { BrowserLoginOptions } from "./browser.js";
import { DeviceLoginOptions } from "./device.js";
import { AuthStore, defaultAuthFile } from "./store.js";
//#region src/auth/manager.d.ts
/** OAuth lifecycle facade shared by the CLI and DSH adapter. */
declare class AuthManager {
  readonly store: AuthStore;
  private readonly issuer;
  private refreshInFlight;
  constructor(options?: {
    store?: AuthStore;
    issuer?: string;
  });
  /** Complete browser callback login and persist the resulting credentials. */
  loginBrowser(options?: BrowserLoginOptions): Promise<StoredCredentials>;
  /** Complete device-code login and persist the resulting credentials. */
  loginDevice(options?: DeviceLoginOptions): Promise<StoredCredentials>;
  /** Return public account status without exposing token material. */
  status(): Promise<AuthStatus>;
  /** Return a fresh access token, refreshing once when its safety window begins. */
  accessToken(): Promise<StoredCredentials>;
  /** Refresh credentials; forced refresh is used after an authenticated HTTP 401. */
  refresh(force?: boolean, observed?: StoredCredentials): Promise<StoredCredentials>;
  /** Remove local credentials. */
  logout(): Promise<boolean>;
}
//#endregion
export { AuthManager, type AuthStatus, AuthStore, type StoredCredentials, defaultAuthFile };
//# sourceMappingURL=manager.d.ts.map