//#region src/auth/types.d.ts
/** Login mechanism that produced the stored credentials. */
type AuthMethod = 'browser' | 'device';
/** Versioned credential document persisted on the local machine. */
interface StoredCredentials {
  version: 1;
  provider: 'openai-codex';
  authMethod: AuthMethod;
  clientId: string;
  accessToken: string;
  refreshToken: string;
  idToken?: string;
  accountId: string;
  email?: string;
  plan?: string;
  expiresAt: number;
  updatedAt: string;
}
/** Public, non-secret status suitable for CLI display. */
interface AuthStatus {
  authenticated: boolean;
  authFile: string;
  authMethod?: AuthMethod;
  accountId?: string;
  email?: string;
  plan?: string;
  expiresAt?: number;
  expired?: boolean;
}
//#endregion
export { AuthMethod, AuthStatus, StoredCredentials };
//# sourceMappingURL=types.d.ts.map