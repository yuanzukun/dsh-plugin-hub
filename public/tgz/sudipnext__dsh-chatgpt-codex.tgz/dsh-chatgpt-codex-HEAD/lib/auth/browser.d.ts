//#region src/auth/browser.d.ts
/** Browser callback login configuration. */
interface BrowserLoginOptions {
  clientId?: string;
  issuer?: string;
  port?: number;
  timeoutMs?: number;
  open?: boolean;
  onUrl?: (url: string) => void;
}
//#endregion
export { BrowserLoginOptions };
//# sourceMappingURL=browser.d.ts.map