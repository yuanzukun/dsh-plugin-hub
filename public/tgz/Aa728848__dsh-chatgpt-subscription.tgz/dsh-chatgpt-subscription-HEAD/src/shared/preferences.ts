import { DEFAULT_VISIBLE_CODEX_MODEL_IDS } from './model-catalog.ts'
import type { CodexOutputVerbosity, CodexReasoningSummary, ProxyMode, SearchProviderPreference, SubscriptionPreferencesDto } from './contracts.ts'

export const PREFERENCES_NAMESPACE = 'dsh-chatgpt-subscription'

export const DEFAULT_PREFERENCES: Omit<SubscriptionPreferencesDto, 'writable'> = {
  enabled: true,
  quickQuotaVisible: false,
  fastMode: false,
  outputVerbosity: null,
  reasoningSummary: null,
  visibleModelIds: [...DEFAULT_VISIBLE_CODEX_MODEL_IDS],
  searchProvider: 'dsh',
  // Empty until the user overrides one: an absent key means "use the catalog
  // default", so a restored default stores nothing at all.
  contextWindowOverrides: {},
  proxyMode: 'auto',
  customProxyUrl: null,
  // Off by default: every deployment summarizes on the model that built the
  // conversation until an operator picks another route.
  compactionRoute: null,
}

export const SEARCH_PROVIDER_DSH: SearchProviderPreference = 'dsh'
export const SEARCH_PROVIDER_CODEX: SearchProviderPreference = 'codex'

export function isSearchProviderPreference(value: unknown): value is SearchProviderPreference {
  return value === SEARCH_PROVIDER_DSH || value === SEARCH_PROVIDER_CODEX
}

export function isCodexOutputVerbosity(value: unknown): value is CodexOutputVerbosity {
  return value === 'low' || value === 'medium' || value === 'high'
}

export function isCodexReasoningSummary(value: unknown): value is CodexReasoningSummary {
  return value === 'auto' || value === 'concise' || value === 'detailed' || value === 'none'
}

export function isProxyMode(value: unknown): value is ProxyMode {
  return value === 'auto' || value === 'custom' || value === 'direct'
}

/** Re-exported so the host parsers share one definition with the DTO. */
export { isCompactionRouteTarget } from './compaction-route.ts'
