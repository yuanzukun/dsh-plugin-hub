import { useCallback, useEffect, useRef, useState } from 'react'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { CodexReasoningSummary, DeviceLoginDto, PluginStatusDto, PoolStorageDto, PoolStorageMode, QuotaBucketDto, QuotaWindowDto, SearchProviderPreference, SubscriptionPreferencesUpdateDto } from '../shared/contracts.ts'
import { CODEX_MODEL_CATALOG, DEFAULT_VISIBLE_CODEX_MODEL_IDS, GPT_56_MAX_CONTEXT_WINDOW, contextWindowLimitForModel, resolveCodexCatalogEntry } from '../shared/model-catalog.ts'
import type { CodexModelId } from '../shared/model-catalog.ts'
import { SubscriptionApi, parseLoginEvent } from './api.ts'
import { AccountPoolSection, type AccountPoolLabels } from './common/AccountPoolSection.tsx'
import { formatPoolLabel } from './common/account-pool-labels.ts'
import { ModelChecklist } from './common/ModelChecklist.tsx'
import { createQuotaFollowUp, type QuotaFollowUp } from './common/quota-follow-up.ts'
import type { AccountRotationStrategy } from '../shared/account-pool-contracts.ts'
import { NS } from './locales.ts'
import { quotaWindows } from './quota.ts'

type Props = PropsRuntime<'settings.section'> & PropsLocale<typeof NS>
type BusyAction = 'login' | 'device-login' | 'token' | 'quota' | 'reset-credit' | 'test' | 'logout' | 'preferences'
  | 'set-primary' | 'delete' | 'clear-cooldown' | 'strategy' | 'adopt' | 'adopt-disable' | 'storage' | null
type Translate = Props['t']

/**
 * The device panel: the host's answer, plus the grant's deadline on this
 * browser's clock.
 *
 * The host states the deadline together with its own `now`, so the remaining
 * time is `expiresAt - now` — measured from the moment the answer arrived, with
 * this browser's elapsed time. Comparing the host's `expiresAt` against the
 * browser's wall clock instead rendered a wrong countdown whenever the two
 * clocks disagreed, which is the normal case for a remote/headless host.
 */
interface DevicePanel {
  login: DeviceLoginDto
  deadlineMs: number
}

/** The grant's deadline, moved onto this browser's clock. */
function panelDeadlineMs(login: DeviceLoginDto): number {
  return Date.now() + (login.expiresAt - login.now) * 1000
}

/**
 * The sentence the card shows about where the pool actually lives.
 *
 * One key per BACKEND, not per configured value: `keyring` resolves to the Secret
 * Service on Linux, DPAPI on Windows and the Keychain on macOS, so a user looking
 * at "saving failed" needs to know which store answered, not which one was asked
 * for. Every branch is spelled out, so a new backend cannot reach the card as an
 * untranslated fallback.
 */
function poolStorageBackendLabel(storage: PoolStorageDto, t: Translate): string {
  switch (storage.backend) {
    case 'keyring': return t('poolStorageBackendKeyring')
    case 'credentials': return t('poolStorageBackendCredentials')
    case 'dpapi': return t('poolStorageBackendDpapi')
    case 'keychain': return t('poolStorageBackendKeychain')
  }
}

/** Why the configured store is not usable here, in the reader's language. */
function poolStorageUnavailableLabel(storage: PoolStorageDto, t: Translate): string | null {
  switch (storage.unavailable) {
    case undefined: return null
    case 'keyring-unreachable': return t('poolStorageUnavailableKeyring')
    case 'no-credentials-service': return t('poolStorageUnavailableCredentials')
    case 'store-unreadable': return t('poolStorageUnavailableStore')
  }
  return null
}

export function CodexSubscriptionSection({ t }: Props): React.JSX.Element {
  const apiRef = useRef(new SubscriptionApi())
  const eventSourceRef = useRef<EventSource | null>(null)
  /**
   * The flow the card knows it started.
   *
   * Cancel used to read the id from the last status answer, which is a race the
   * user could lose: the panel is on screen the instant the host answers, and a
   * Cancel pressed before the status reload finished went nowhere. The id the
   * start route just returned is the truth about what is running.
   */
  const loginIdRef = useRef<string | null>(null)
  /** Follow-up poll owed while the host refreshes the quota behind an answer. */
  const quotaFollowUp = useRef<QuotaFollowUp | null>(null)
  const [status, setStatus] = useState<PluginStatusDto | null>(null)
  const [busy, setBusy] = useState<BusyAction>(null)
  const [error, setError] = useState<string | null>(null)
  const [authUrl, setAuthUrl] = useState<string | null>(null)
  const [popupBlocked, setPopupBlocked] = useState(false)
  /** The device code on screen. Non-null means the device panel is what is open. */
  const [deviceLogin, setDeviceLogin] = useState<DevicePanel | null>(null)
  const [deviceError, setDeviceError] = useState<string | null>(null)
  /** Which of the two panel values was copied a moment ago: the code or the link. */
  const [copiedField, setCopiedField] = useState<'code' | 'link' | null>(null)
  /** Cleared on unmount, so a panel closed inside 1.5 s leaves no timer behind. */
  const copiedTimerRef = useRef<number | null>(null)
  /** Ticked once a second, so the panel's countdown is a clock and not a snapshot. */
  const [now, setNow] = useState(() => Date.now())
  const [resetCreditNotice, setResetCreditNotice] = useState<string | null>(null)
  const [connection, setConnection] = useState<{ latencyMs: number; checkedAt: number } | null>(null)
  const [contextDrafts, setContextDrafts] = useState<Record<string, string>>({})
  const [customProxyDraft, setCustomProxyDraft] = useState<string | null>(null)

  const load = useCallback(async (quiet = false) => {
    if (!quiet) setError(null)
    try {
      const next = await apiRef.current.status()
      setStatus(next)
      if (next.error !== undefined) setError(next.error.message)
      // An answer that refreshed the quota behind itself is followed up shortly,
      // so the fresh numbers land without waiting for the next poll.
      quotaFollowUp.current ??= createQuotaFollowUp()
      quotaFollowUp.current.observe(next.quotaRefreshing === true, () => { void load(true) })
    } catch (cause) {
      if (!quiet) setError(messageOf(cause))
    }
  }, [])

  useEffect(() => {
    void load()
    const refreshWhenVisible = (): void => {
      if (document.visibilityState === 'visible') void load(true)
    }
    document.addEventListener('visibilitychange', refreshWhenVisible)
    const timer = window.setInterval(refreshWhenVisible, 60_000)
    return () => {
      window.clearInterval(timer)
      document.removeEventListener('visibilitychange', refreshWhenVisible)
      quotaFollowUp.current?.cancel()
      eventSourceRef.current?.close()
      if (copiedTimerRef.current !== null) window.clearTimeout(copiedTimerRef.current)
    }
  }, [load])

  const watchLogin = useCallback((loginId: string, mode: 'browser' | 'device' = 'browser') => {
    loginIdRef.current = loginId
    eventSourceRef.current?.close()
    const source = apiRef.current.events(loginId)
    eventSourceRef.current = source
    const finish = async (message?: string): Promise<void> => {
      source.close()
      eventSourceRef.current = null
      loginIdRef.current = null
      setBusy(null)
      setAuthUrl(null)
      if (mode === 'device') {
        // A terminal failure leaves the panel open with the reason on it: the
        // code itself is still on screen, and closing would take away the only
        // thing that explains what the user was doing.
        if (message === undefined) setDeviceLogin(null)
        else setDeviceError(message)
      } else if (message !== undefined) {
        setError(message)
      }
      // Preserve the terminal OAuth error while refreshing the account DTO.
      await load(true)
    }
    source.addEventListener('completed', (event) => {
      const parsed = parseLoginEvent(event as MessageEvent<string>)
      if (parsed?.type === 'completed') void finish()
    })
    source.addEventListener('cancelled', () => void finish())
    source.addEventListener('failed', (event) => {
      const parsed = parseLoginEvent(event as MessageEvent<string>)
      void finish(parsed?.type === 'failed' ? parsed.error.message : 'ChatGPT sign-in failed.')
    })
  }, [load])

  useEffect(() => {
    const loginId = status?.login.active ? status.login.loginId : null
    if (loginId === null || loginId === undefined) return
    const device = status?.login.device
    loginIdRef.current = loginId
    if (eventSourceRef.current === null) watchLogin(loginId, device === undefined || device === null ? 'browser' : 'device')
    // A card opened (or reloaded) mid-flow takes the code from the host: the
    // grant is still waiting upstream, and the code is the only way to finish it.
    if (device !== undefined && device !== null) {
      setDeviceLogin((current) => current ?? { login: device, deadlineMs: panelDeadlineMs(device) })
    }
  }, [status?.login.active, status?.login.loginId, status?.login.device, watchLogin])

  // The countdown runs only while a device panel is open.
  useEffect(() => {
    if (deviceLogin === null) return
    setNow(Date.now())
    const timer = window.setInterval(() => setNow(Date.now()), 1_000)
    return () => window.clearInterval(timer)
  }, [deviceLogin])

  const startLogin = async (): Promise<void> => {
    setBusy('login')
    setError(null)
    setPopupBlocked(false)
    const popup = window.open('about:blank', 'dsh-chatgpt-oauth', 'popup,width=560,height=760')
    try {
      const login = await apiRef.current.startLogin()
      setAuthUrl(login.authUrl)
      if (popup === null) setPopupBlocked(true)
      else popup.location.replace(login.authUrl)
      watchLogin(login.loginId)
      await load(true)
    } catch (cause) {
      popup?.close()
      setBusy(null)
      setError(messageOf(cause))
    }
  }

  /**
   * The third way in: a code the user types on their own machine.
   *
   * Nothing is opened and nothing is listened on locally — that is the whole
   * point of this path on a server — so the answer is immediately shown instead
   * of being handed to a popup.
   */
  const startDeviceLogin = async (): Promise<void> => {
    setBusy('device-login')
    setError(null)
    setDeviceError(null)
    setCopiedField(null)
    try {
      const login = await apiRef.current.startDeviceLogin()
      setDeviceLogin({ login, deadlineMs: panelDeadlineMs(login) })
      watchLogin(login.loginId, 'device')
      // The wait is the host's now, not this button's: the panel holds the code
      // and its own Cancel, which must be pressable while the flow is pending.
      setBusy(null)
      await load(true)
    } catch (cause) {
      // No panel exists to hold the reason when the grant itself could not be
      // requested, so it goes to the card's strip. A retry from an OPEN panel
      // keeps its answer on the panel, beside the code it is about.
      if (deviceLogin === null) setError(messageOf(cause))
      else setDeviceError(messageOf(cause))
      setBusy(null)
    }
  }

  /**
   * Copy one of the panel's two values.
   *
   * One handler for both buttons, because they are the same action and must look
   * and behave identically. The code is stripped of whitespace on the way out:
   * what the panel renders is a code in a box, and a copied value with a stray
   * space or line break is refused by the page the user pastes it into.
   */
  const copyDeviceValue = async (field: 'code' | 'link'): Promise<void> => {
    if (deviceLogin === null) return
    const value = field === 'code' ? deviceLogin.login.userCode.replace(/\s+/g, '') : deviceLogin.login.verificationUrl
    if (value === '') return
    // No clipboard at all (insecure origin, an old browser): silent no-op rather
    // than a crash. Both values stay on screen and can be copied by hand.
    if (typeof navigator === 'undefined' || navigator.clipboard === undefined) return
    try {
      await navigator.clipboard.writeText(value)
    } catch {
      // Denied permission is the same situation as no clipboard: nothing is lost,
      // so nothing is reported.
      return
    }
    if (copiedTimerRef.current !== null) window.clearTimeout(copiedTimerRef.current)
    setCopiedField(field)
    copiedTimerRef.current = window.setTimeout(() => {
      copiedTimerRef.current = null
      setCopiedField(null)
    }, 1_500)
  }

  /**
   * Stop the running sign-in, or close a panel that has nothing left to stop.
   *
   * A terminal failure ends the flow on the host (`activeLogin` is empty) and the
   * card forgets the id with it — but the panel stays open on purpose, because
   * the code is still the only thing that explains what happened. Cancel is the
   * only control on it, so with nothing to cancel it has to mean "close", or an
   * expired code could only be got rid of by starting a new sign-in.
   */
  const cancelLogin = async (): Promise<void> => {
    const loginId = loginIdRef.current ?? status?.login.loginId
    if (loginId === null || loginId === undefined) {
      setDeviceLogin(null)
      setDeviceError(null)
      return
    }
    setBusy('login')
    try {
      await apiRef.current.cancelLogin(loginId)
      eventSourceRef.current?.close()
      eventSourceRef.current = null
      loginIdRef.current = null
      setAuthUrl(null)
      setDeviceLogin(null)
      setDeviceError(null)
      await load()
    } catch (cause) {
      setError(messageOf(cause))
    } finally {
      setBusy(null)
    }
  }

  const refreshToken = async (): Promise<void> => run('token', async () => {
    setStatus(await apiRef.current.refresh())
  })

  const refreshQuota = async (): Promise<void> => run('quota', async () => {
    const quota = await apiRef.current.refreshQuota()
    setStatus((current) => current === null ? current : { ...current, quota })
  })

  const useResetCredit = async (): Promise<void> => {
    if (!window.confirm(t('useResetCreditConfirm'))) return
    await run('reset-credit', async () => {
      const quota = await apiRef.current.useResetCredit()
      setStatus((current) => current === null ? current : { ...current, quota })
      setResetCreditNotice(t('resetCreditUsed'))
    })
  }

  const testConnection = async (): Promise<void> => run('test', async () => {
    const result = await apiRef.current.testConnection()
    setConnection({ latencyMs: result.latencyMs, checkedAt: result.checkedAt })
  })

  const updatePreferences = async (patch: SubscriptionPreferencesUpdateDto): Promise<void> => run('preferences', async () => {
    const preferences = await apiRef.current.updatePreferences(patch)
    setStatus((current) => current === null ? current : { ...current, preferences })
  })

  const selectSearchProvider = (provider: SearchProviderPreference): void => {
    setStatus(current => current ? { ...current, preferences: { ...current.preferences, searchProvider: provider } } : current)
    void updatePreferences({ searchProvider: provider })
  }

  const toggleVisibleModel = async (modelId: string, checked: boolean): Promise<void> => {
    const current = status?.preferences.visibleModelIds ?? [...DEFAULT_VISIBLE_CODEX_MODEL_IDS]
    const visibleModelIds = checked ? [...current, modelId] : current.filter(id => id !== modelId)
    await updatePreferences({ visibleModelIds })
  }

  const setAllVisibleModels = async (selectAll: boolean): Promise<void> => {
    const visibleModelIds = selectAll ? CODEX_MODEL_CATALOG.map(m => m.id) : []
    await updatePreferences({ visibleModelIds })
  }

  const updateContextWindow = async (model: CodexModelId): Promise<void> => {
    const current = status?.preferences.contextWindowOverrides[model] ?? resolveCodexCatalogEntry(model).contextWindow
    const parsed = parseCapacity(contextDrafts[model] ?? String(current), contextWindowLimitForModel(model))
    if (parsed === null) {
      setError(t('contextWindowInvalid'))
      return
    }
    await updatePreferences({ contextWindowOverrides: { [model]: parsed } })
    setContextDrafts((drafts) => ({ ...drafts, [model]: String(parsed) }))
  }

  /** Drop one model's override; the row falls back to the catalog value. */
  const resetContextWindow = async (model: CodexModelId): Promise<void> => {
    await updatePreferences({ contextWindowOverrides: { [model]: null } })
    setContextDrafts((drafts) => ({ ...drafts, [model]: formatCapacity(resolveCodexCatalogEntry(model).contextWindow) }))
  }

  /** Clear every stored override, including models the picker no longer shows. */
  const resetAllContextWindows = async (): Promise<void> => {
    const models = Object.keys(status?.preferences.contextWindowOverrides ?? {})
    if (models.length === 0) return
    if (!window.confirm(t('contextWindowResetAllConfirm'))) return
    await updatePreferences({ contextWindowOverrides: Object.fromEntries(models.map((model) => [model, null])) })
    setContextDrafts({})
  }

  const updateCustomProxyUrl = async (): Promise<void> => {
    const draft = customProxyDraft?.trim()
    await updatePreferences({ customProxyUrl: draft ? draft : null })
    setCustomProxyDraft(null)
  }

  /**
   * The shared card takes a label object while this tab translates by key, so
   * every pool label is resolved through the tab's own translator and follows
   * whichever locale is active.
   */
  const poolLabels: AccountPoolLabels = {
    accountPool: t('accountPool'),
    addAccount: t('addAccount'),
    accountCount: t('accountCount'),
    primaryAccount: t('primaryAccount'),
    activeAccount: t('activeAccount'),
    setPrimary: t('setPrimary'),
    deleteAccount: t('deleteAccount'),
    cooling: t('cooling'),
    cooldownLeft: t('cooldownLeft'),
    cooldownRemaining: t('cooldownRemaining'),
    cooldownRemainingSeconds: t('cooldownRemainingSeconds'),
    clearCooldown: t('clearCooldown'),
    needsRelogin: t('needsRelogin'),
    relogin: t('relogin'),
    rotationStrategy: t('rotationStrategy'),
    strategySequential: t('strategySequential'),
    strategyRoundRobin: t('strategyRoundRobin'),
    strategySticky: t('strategySticky'),
    noAccounts: t('noAccounts'),
    email: t('email'),
    expires: t('expires'),
    lastUsed: t('lastUsed'),
    accountId: t('accountId'),
    accountQuota: t('accountQuota'),
    quotaNone: t('quotaNone'),
    quotaSnapshot: t('quotaSnapshot'),
    quotaResets: t('quotaResets'),
    quotaExhausted: t('quotaExhausted'),
    quotaWindow: t('quotaWindow'),
    quotaUsed: t('quotaUsed'),
    quotaFactsScope: t('quotaFactsScope'),
    composerLabel: t('composerLabel'),
  }

  const accountAction = async (
    action: 'set-primary' | 'delete' | 'clear-cooldown',
    accountId: string,
  ): Promise<void> => {
    await run(action, async () => {
      const next = await apiRef.current.accountAction(action, { accountId })
      setStatus(next)
    })
  }

  /**
   * Forget every imported snapshot: the undo for the local sign-in import below.
   *
   * ONE control for the whole pool rather than one per row, because the host's
   * route deliberately ignores an accountId and clears every imported row at once.
   * That is not an oversight to route around: the pool refuses to delete an
   * adopted credential, so a per-row control here could only ever be a button that
   * silently clears its neighbours — a worse bug than offering no button at all.
   * The Codex CLI's own file is not deleted, rewritten or moved by this; it only
   * makes this plugin forget the copy it took.
   */
  const stopImporting = async (): Promise<void> => {
    await run('adopt-disable', async () => {
      setStatus(await apiRef.current.disableAdoptedLocalLogins())
    })
  }

  /**
   * Copy this machine's Codex CLI sign-in into the pool as a snapshot.
   *
   * The status is re-read rather than taken from the route's answer: the route
   * answers with the pool's refreshed status, which knows nothing about the
   * CLI file, so adopting from its value would flip the block to "not detected"
   * one click after the import succeeded. The file is still there — the import
   * copies it — so /status is the answer that tells the truth, and the row the
   * account just created comes back with it.
   */
  const importLocalSignIn = async (): Promise<void> => {
    await run('adopt', async () => {
      await apiRef.current.adoptLocalLogin('codex')
      await load(true)
    })
  }

  const setRotationStrategy = async (strategy: AccountRotationStrategy): Promise<void> => {
    await run('strategy', async () => {
      const next = await apiRef.current.accountAction('strategy', { strategy })
      setStatus(next)
    })
  }

  /**
   * Move the pool to the other store.
   *
   * Nothing is copied: the accounts saved in the store being left stay there and
   * reappear if the choice is switched back, which is what the warning under the
   * select says. The route answers with the refreshed status, so the card renames
   * the store in use in the same render.
   */
  const changePoolStorage = async (mode: PoolStorageMode): Promise<void> => {
    await run('storage', async () => {
      const next = await apiRef.current.setPoolStorage(mode)
      setStatus(next)
    })
  }

  /**
   * Re-authorize one account.
   *
   * The failure marker is cleared first and nothing is deleted: the account
   * keeps its alias and place in the rotation.
   */
  const relogin = (accountId: string): void => {
    void (async () => {
      try {
        const next = await apiRef.current.accountAction('relogin', { accountId })
        setStatus(next)
      } catch (cause) {
        setError(messageOf(cause))
        return
      }
      await startLogin()
    })()
  }

  const logout = async (): Promise<void> => run('logout', async () => {
    await apiRef.current.logout()
    eventSourceRef.current?.close()
    eventSourceRef.current = null
    setAuthUrl(null)
    setConnection(null)
    setDeviceLogin(null)
    setDeviceError(null)
    await load()
  })

  const run = async (action: Exclude<BusyAction, null>, task: () => Promise<void>): Promise<void> => {
    setBusy(action)
    setError(null)
    setResetCreditNotice(null)
    try {
      await task()
    } catch (cause) {
      setError(messageOf(cause))
    } finally {
      setBusy(null)
    }
  }

  // `removable: false` is the shared summary DTO's own signal for a borrowed
  // credential (it is what suppresses Delete on the shared card). The Codex pool
  // also puts an `adopted` flag on the wire, but that field is not in the shared
  // contract this tab is typed against, so the declared one is what is read.
  const importedAccounts = (status?.accounts ?? []).filter((account) => account.removable === false)
  const account = status?.account
  const preferences = status?.preferences
  const quota = status?.quota
  const login = status?.login
  // Resolved once per render: the same sentence is rendered in one place and
  // compared against null to decide whether it is rendered at all.
  const poolStorageUnavailable = status?.poolStorage === undefined
    ? null
    : poolStorageUnavailableLabel(status.poolStorage, t)
  const visibleModelIds = preferences?.visibleModelIds ?? DEFAULT_VISIBLE_CODEX_MODEL_IDS
  // Only checked models get a context row, in catalog order.
  const contextModels = CODEX_MODEL_CATALOG.filter((entry) => visibleModelIds.some((id) => id === entry.id))
  const overrideCount = Object.keys(preferences?.contextWindowOverrides ?? {}).length
  return <section className="dsha-page" aria-labelledby="dsh-codex-title">
    <header>
      <h2 id="dsh-codex-title" className="dsh-codex-title">{t('title')}</h2>
      <p className="dsh-codex-intro">{t('intro')}</p>
    </header>

    {error !== null ? <div className="dsh-codex-errorbar" role="alert">
      <span>{error}</span>
      {status === null ? <Button disabled={busy !== null} onClick={() => load()}>{t('retry')}</Button> : null}
    </div> : null}

    {status === null && error === null ? <Skeleton label={t('loading')} /> : <>
      <AccountPoolSection
        accounts={status?.accounts ?? []}
        activeAccountId={status?.activeAccountId}
        rotationStrategy={status?.rotationStrategy ?? 'sequential'}
        busy={busy}
        labels={poolLabels}
        loginBusyLabel={login?.active ? t('pending') : undefined}
        onLogin={() => void startLogin()}
        onSetPrimary={(accountId) => void accountAction('set-primary', accountId)}
        onDelete={(accountId) => void accountAction('delete', accountId)}
        onClearCooldown={(accountId) => void accountAction('clear-cooldown', accountId)}
        onRelogin={(accountId) => relogin(accountId)}
        onSetStrategy={(strategy) => void setRotationStrategy(strategy)}
        showQuota
        renderLoginActions={() => (
          // The pool card's own login row, in the shape the Claude section uses:
          // the sign-in keeps the primary treatment, and a sign-in that already
          // exists on this machine sits beside it as the alternative way in.
          //
          // The first button REPRODUCES the shared card's default login button
          // (same classes, same label, same disable rule), because taking the row
          // over means reproducing it — nothing about signing in changes here.
          <div className="dsha-account-add-actions">
            <button
              className="dsha-btn dsha-btn-primary"
              disabled={busy !== null}
              onClick={() => void startLogin()}
            >
              {login?.active ? t('pending') : t('addAccount')}
            </button>
            {/* The second entry: a local Codex CLI sign-in can be imported instead
                of running a fresh ChatGPT OAuth flow.

                ALWAYS RENDERED, exactly as the Claude section renders its own —
                including when the host found no sign-in, which is the decision
                stated here rather than left to drift: a button that DISAPPEARS
                when there is nothing to import cannot answer whether one exists,
                and "is my CLI signed in here?" is the question this row is here to
                answer. Clicking it with nothing there is not a dead end and needs
                no substitute prose: the host refuses in a sentence, and that
                sentence lands in the card's existing error strip. */}
            {/* The device-code path, kept between the two existing entries: it is
                the same sign-in as the primary button, obtained without a
                loopback listener, so a host with no browser on it (or a page
                served over HTTPS, which cannot reach localhost:1455 at all) can
                still add an account.

                Disabled for EVERY busy action, including its own: the two
                starts are mutually exclusive on the host, and a button that
                stays clickable while its request is in flight is a second
                request nobody meant to send. */}
            {/* Three entries share one row, so each one's visible text is the
                short form and its aria-label keeps the full sentence: the row
                has to fit without wrapping on a normal settings pane, and a row
                that wraps stops reading as a set of alternatives. */}
            <button
              className="dsha-btn"
              disabled={busy !== null}
              aria-label={t('deviceCodeLoginDetail')}
              title={t('deviceCodeLoginDetail')}
              onClick={() => void startDeviceLogin()}
            >
              {busy === 'device-login' ? t('deviceCodeLoginStarting') : t('deviceCodeLogin')}
            </button>
            <button
              className="dsha-btn"
              disabled={busy !== null}
              aria-label={t('localCodexLoginImport')}
              title={t('localCodexLoginImport')}
              onClick={() => void importLocalSignIn()}
            >
              {busy === 'adopt' ? t('localCodexLoginImporting') : t('localCodexLoginImport')}
            </button>
          </div>
        )}
        renderDetails={(entry) => (
          <>
            {entry.planLabel && <span>{t('plan')}: {entry.planLabel}</span>}
          </>
        )}
      >
        {login?.active && deviceLogin === null ? <p className="dsha-muted" role="status">{t('pending')}</p> : null}
        {deviceLogin !== null ? (
          <div className="dsh-codex-device" role="group" aria-label={t('deviceCodeLogin')}>
            <p className="dsha-muted">{t('deviceCodeHint')}</p>
            <div className="dsh-codex-device-row">
              <span className="dsh-codex-device-value">
                <code className="dsh-codex-device-code" aria-label={t('deviceCodeLabel')}>{deviceLogin.login.userCode}</code>
                <CopyButton
                  copied={copiedField === 'code'}
                  label={t('deviceCodeCopy')}
                  onClick={() => void copyDeviceValue('code')}
                />
              </span>
              <span className="dsh-codex-device-value">
                <a className="dsh-codex-link" href={deviceLogin.login.verificationUrl} target="_blank" rel="noreferrer">{t('deviceCodeOpen')}</a>
                <CopyButton
                  copied={copiedField === 'link'}
                  label={t('deviceCodeCopy')}
                  onClick={() => void copyDeviceValue('link')}
                />
              </span>
            </div>
            <p className="dsha-muted" role="status">
              {t('deviceCodeWaiting').replace('{time}', formatRemaining(deviceLogin.deadlineMs, now))}
            </p>
            {deviceError !== null ? <p className="dsh-codex-error" role="alert">{deviceError}</p> : null}
            <div className="dsha-actions">
              <Button disabled={busy !== null} onClick={cancelLogin}>{t('cancel')}</Button>
            </div>
          </div>
        ) : null}
        {popupBlocked ? <p className="dsh-codex-error">{t('popupBlocked')}</p> : null}
        {authUrl !== null ? <a className="dsh-codex-link" href={authUrl} target="_blank" rel="noreferrer">{t('continueLogin')}</a> : null}
        <div className="dsha-actions">
          {login?.active ? <Button disabled={busy !== null} onClick={cancelLogin}>{t('cancel')}</Button> : null}
          {status?.authenticated ? <Button disabled={busy !== null} onClick={refreshToken}>{t('refreshToken')}</Button> : null}
        </div>
        {/* The imported rows have no Delete (the shared card hides it for a
            borrowed credential), so without the import button above this would be
            a one-way door. Rendered once, below the list, and its label says "all":
            the route it calls forgets every snapshot at once. */}
        {importedAccounts.length > 0 ? (
          <>
            <p className="dsha-muted">{formatPoolLabel(t('stopImportingHint'), { count: importedAccounts.length })}</p>
            <div className="dsha-actions">
              <button
                className="dsha-btn"
                type="button"
                disabled={busy !== null}
                aria-label={formatPoolLabel(t('stopImportingLabel'), { count: importedAccounts.length })}
                onClick={() => void stopImporting()}
              >{busy === 'adopt-disable' ? t('stopImportingBusy') : t('stopImporting')}</button>
            </div>
          </>
        ) : null}
        {/* Where the pool is kept — and the one control in this card that can fix
            the failure a user cannot diagnose from it: the token exchange succeeds,
            the write does not, and the store the pool tried is the answer.

            The select states the CONFIGURED choice; the line under it states the
            store this host actually resolved, because `keyring` is three different
            stores depending on the platform, and because a configured store that is
            not there (a server with no secret service) has to say so where the
            switch is, not in a log. */}
        {status?.poolStorage !== undefined ? (
          <div data-dsh-pool-storage={status.poolStorage.backend}>
            <div className="dsha-pref-row">
              <div>
                <strong>{t('poolStorageTitle')}</strong>
                <p className="dsha-muted">
                  {status.poolStorage.mode === 'keyring' ? t('poolStorageKeyringHint') : t('poolStorageCredentialsHint')}
                </p>
              </div>
              <select
                className="dsha-select"
                aria-label={t('poolStorageTitle')}
                value={status.poolStorage.mode}
                disabled={busy !== null}
                onChange={(event) => void changePoolStorage(event.currentTarget.value as PoolStorageMode)}
              >
                <option value="keyring">{t('poolStorageKeyring')}</option>
                <option value="credentials">{t('poolStorageCredentials')}</option>
              </select>
            </div>
            <p className="dsha-muted">
              {formatPoolLabel(t('poolStorageEffective'), { storage: poolStorageBackendLabel(status.poolStorage, t) })}
            </p>
            {poolStorageUnavailable === null ? null : (
              <p className="dsh-codex-error" role="status">{poolStorageUnavailable}</p>
            )}
            <p className="dsha-muted">{t('poolStorageSwitchWarning')}</p>
          </div>
        ) : null}
      </AccountPoolSection>

      <Section title={t('connection')}>
        {connection !== null ? <InfoRow label={t('latency')} value={`${connection.latencyMs} ms · ${formatDate(connection.checkedAt)}`} /> : null}
        <p className="dsha-muted dsha-models-hint">{t('modelsHint')}</p>
        <ModelChecklist
          items={CODEX_MODEL_CATALOG.map((model) => ({
            id: model.id,
            name: model.name,
            hint: `${formatCapacity(model.contextWindow)} ${t('tokens')}`,
            enabled: visibleModelIds.some(id => id === model.id),
          }))}
          busy={busy !== null}
          onToggle={(id, enabled) => void toggleVisibleModel(id, enabled)}
          onToggleAll={(enabled) => void setAllVisibleModels(enabled)}
          labels={{ selectAll: t('selectAll'), clearAll: t('unselectAll'), countTemplate: t('modelChecklistCount'), list: t('models') }}
        />
        <div className="dsha-actions">
          <Button disabled={!status?.authenticated || busy !== null} onClick={testConnection}>{busy === 'test' ? t('testing') : t('testConnection')}</Button>
        </div>
      </Section>

      <Section title={t('proxySettings')}>
        <div className="dsha-pref-row">
          <div>
            <strong>{t('proxyMode')}</strong>
            <p className="dsha-muted">{t('proxyModeHint')}</p>
          </div>
          <select
            className="dsha-select"
            aria-label={t('proxyMode')}
            value={preferences?.proxyMode ?? 'auto'}
            disabled={busy !== null}
            onChange={(event) => {
              const mode = event.currentTarget.value as 'auto' | 'custom' | 'direct'
              setStatus(current => current ? { ...current, preferences: { ...current.preferences, proxyMode: mode } } : current)
              void updatePreferences({ proxyMode: mode })
            }}
          >
            <option value="auto">{t('proxyModeAuto')}</option>
            <option value="custom">{t('proxyModeCustom')}</option>
            <option value="direct">{t('proxyModeDirect')}</option>
          </select>
        </div>

        {(preferences?.proxyMode ?? 'auto') === 'auto' ? <div className="dsh-codex-proxy-status">
          {status?.detectedProxy ? <>
            <span>{t('proxyDetected')}:</span>
            <code className="dsh-codex-proxy-tag">{status.detectedProxy}</code>
            <span className="dsh-codex-success">{t('proxyDetectedEffective')}</span>
          </> : <span className="dsha-muted">{t('proxyNoneDetected')}</span>}
        </div> : null}

        {preferences?.proxyMode === 'direct' ? <p className="dsha-muted" style={{ margin: '8px 0 0' }}>{t('proxyDirectHint')}</p> : null}

        {preferences?.proxyMode === 'custom' ? <div className="dsha-context-settings">
          <div>
            <strong>{t('customProxyUrl')}</strong>
            <p className="dsha-muted">{t('customProxyUrlHint')}</p>
          </div>
          <div className="dsha-context-row">
            <span className="dsh-codex-proxy-control">
              <input
                id="dsh-codex-custom-proxy"
                type="text"
                placeholder={t('customProxyUrlPlaceholder')}
                value={customProxyDraft ?? (preferences?.customProxyUrl ?? '')}
                disabled={busy !== null}
                aria-label={t('customProxyUrl')}
                onChange={(event) => {
                  setCustomProxyDraft(event.currentTarget.value)
                }}
                onKeyDown={(event) => {
                  if (event.key !== 'Enter') return
                  event.preventDefault()
                  void updateCustomProxyUrl()
                }}
              />
              <button
                className="dsha-context-save"
                type="button"
                aria-label={t('saveProxyUrl')}
                disabled={busy !== null || customProxyDraft === null}
                onClick={() => void updateCustomProxyUrl()}
              >
                {t('save')}
              </button>
            </span>
          </div>
        </div> : null}
      </Section>

      <Section title={t('enhancements')}>
        <div className="dsha-pref-row">
          <div>
            <strong>{t('searchProvider')}</strong>
            <p className="dsha-muted">{t('searchProviderHint')}</p>
          </div>
          <div className="dsh-codex-segments" role="group" aria-label={t('searchProvider')}>
            <button
              type="button"
              className={preferences?.searchProvider === 'dsh' ? 'active' : ''}
              aria-pressed={preferences?.searchProvider === 'dsh'}
              disabled={busy !== null}
              onClick={() => selectSearchProvider('dsh')}
            >
              {t('searchProviderDsh')}
            </button>
            <button
              type="button"
              className={preferences?.searchProvider === 'codex' ? 'active' : ''}
              aria-pressed={preferences?.searchProvider === 'codex'}
              disabled={busy !== null}
              onClick={() => selectSearchProvider('codex')}
            >
              {t('searchProviderCodex')}
            </button>
          </div>
        </div>
        <FetchProviderStatusCard status={status} t={t} />
        <div className="dsha-pref-row">
          <div>
            <strong>{t('outputVerbosity')}</strong>
            <p className="dsha-muted">{t('outputVerbosityHint')}</p>
          </div>
          <select className="dsha-select" aria-label={t('outputVerbosity')} value={preferences?.outputVerbosity ?? ''} disabled={busy !== null} onChange={(event) => {
            const value = event.currentTarget.value
            void updatePreferences({ outputVerbosity: value === '' ? null : value as 'low' | 'medium' | 'high' })
          }}>
            <option value="">{t('providerDefault')}</option>
            <option value="low">{t('verbosityLow')}</option>
            <option value="medium">{t('verbosityMedium')}</option>
            <option value="high">{t('verbosityHigh')}</option>
          </select>
        </div>
        <div className="dsha-pref-row">
          <div>
            <strong>{t('reasoningSummary')}</strong>
            <p className="dsha-muted">{t('reasoningSummaryHint')}</p>
          </div>
          <select className="dsha-select" aria-label={t('reasoningSummary')} value={preferences?.reasoningSummary ?? ''} disabled={busy !== null} onChange={(event) => {
            const value = event.currentTarget.value
            void updatePreferences({ reasoningSummary: value === '' ? null : value as CodexReasoningSummary })
          }}>
            <option value="">{t('providerDefault')}</option>
            <option value="auto">{t('summaryAuto')}</option>
            <option value="concise">{t('summaryConcise')}</option>
            <option value="detailed">{t('summaryDetailed')}</option>
            <option value="none">{t('summaryNone')}</option>
          </select>
        </div>
        <div className="dsha-context-settings">
          <div>
            <strong>{t('contextWindows')}</strong>
            <p className="dsha-muted">{t('contextWindowsHint')}</p>
          </div>
          {contextModels.length === 0 ? <p className="dsha-muted">{t('contextWindowsNoneEnabled')}</p> : null}
          {contextModels.map((entry) => {
            const model = entry.id
            const fallback = preferences?.contextWindowOverrides?.[model] ?? entry.contextWindow
            const draft = contextDrafts[model]
            const parsedDraft = draft === undefined ? fallback : parseCapacity(draft, contextWindowLimitForModel(model))
            const dirty = draft !== undefined && parsedDraft !== fallback
            const overridden = preferences?.contextWindowOverrides?.[model] !== undefined
            const inputId = `dsh-codex-context-${model}`
            return <div className="dsha-context-row" key={model}>
              <label htmlFor={inputId}>{entry.name}</label>
              <span className="dsha-capacity-control">
                <input id={inputId} type="text" inputMode="numeric" value={draft ?? formatCapacity(fallback)} disabled={busy !== null} aria-label={entry.name + ' ' + t('contextWindow')} onChange={(event) => {
                  const value = event.currentTarget.value
                  setContextDrafts((drafts) => ({ ...drafts, [model]: value }))
                }} onKeyDown={(event) => {
                  if (event.key !== 'Enter' || !dirty) return
                  event.preventDefault()
                  void updateContextWindow(model)
                }} />
                <small>{t('tokens')}</small>
                <button className="dsha-context-save" type="button" data-model={model} aria-label={entry.name + ' ' + t('saveContextWindow')} disabled={busy !== null || !dirty} onClick={() => void updateContextWindow(model)}>{t('save')}</button>
                <button className="dsha-context-save dsha-context-reset" type="button" data-reset-model={model} aria-label={entry.name + ' ' + t('contextWindowReset')} disabled={busy !== null || !overridden} onClick={() => void resetContextWindow(model)}>{t('contextWindowReset')}</button>
              </span>
            </div>
          })}
          <div className="dsha-actions">
            <Button disabled={busy !== null || overrideCount === 0} onClick={resetAllContextWindows}>{t('contextWindowResetAll')}</Button>
          </div>
        </div>
        <label className="dsh-codex-check">
          <input type="checkbox" checked={preferences?.fastMode === true} disabled={busy !== null} onChange={(event) => updatePreferences({ fastMode: event.currentTarget.checked })} />
          <span>
            <strong>{t('fastMode')}</strong>
            <small>{t('fastModeHint')}</small>
          </span>
        </label>
        <label className="dsh-codex-check">
          <input type="checkbox" checked={preferences?.quickQuotaVisible === true} disabled={busy !== null} onChange={(event) => updatePreferences({ quickQuotaVisible: event.currentTarget.checked })} />
          <span>
            <strong>{t('quickQuota')}</strong>
            <small>{t('quickQuotaHint')}</small>
          </span>
        </label>
      </Section>

      <Section title={t('quota')} aside={<Button disabled={!status?.authenticated || busy !== null} onClick={refreshQuota}>{busy === 'quota' ? t('refreshing') : t('refreshQuota')}</Button>}>
        <p className="dsha-muted">{t('quotaIntro')}</p>
        {/* The progress bars moved into each account card: quota follows the
            account, so a bar here could only ever describe whichever account
            happened to be active when the snapshot was read. What stays is what
            has no per-account bar to live in — the plan, the credits, the
            monthly spend, the reset cards and the freshness of this reading. */}
        <p className="dsha-muted">{poolLabels.quotaFactsScope}</p>
        {quota?.state === 'signed-out' || !status?.authenticated ? <p className="dsh-codex-empty">{t('quotaSignedOut')}</p> : null}
        {quota?.buckets?.map((bucket) => <QuotaFact key={bucket.id} label={bucket.name} value={bucket.planType ?? '—'} />)}
        {quota?.credits !== null && quota?.credits !== undefined ? <QuotaFact label={t('credits')} value={quota.credits.unlimited ? t('unlimited') : quota.credits.balance ?? (quota.credits.hasCredits ? t('available') : t('unavailable'))} /> : null}
        {quota?.individualLimit !== null && quota?.individualLimit !== undefined ? <QuotaFact label={t('monthlySpend')} value={individualLimitLabel(quota.individualLimit, t)} /> : null}
        {quota?.resetCredits !== null && quota?.resetCredits !== undefined ? <ResetCreditsFact resetCredits={quota.resetCredits} busy={busy} onUse={useResetCredit} t={t} /> : null}
        {resetCreditNotice !== null ? <p className="dsh-codex-success" role="status">{resetCreditNotice}</p> : null}
        {quota?.spendControlReached === true ? <p className="dsh-codex-warning" role="status">{t('spendControlReached')}</p> : null}
        {quota?.state === 'empty' ? <p className="dsh-codex-empty">{t('noQuota')}</p> : null}
        {quota?.stale ? <p className="dsh-codex-warning" role="status">{t('stale')}</p> : null}
        {quota?.error ? <p className="dsh-codex-error" role="alert">{quota.error.message}</p> : null}
        {quota?.fetchedAt ? <p className="dsh-codex-timestamp">{t('updated')}: {formatDate(quota.fetchedAt)}</p> : null}
      </Section>
    </>}

    <span className="dsh-codex-sr" aria-live="polite">{busy === null ? '' : busy}</span>
  </section>
}

function Section({ title, aside, children }: { title: string; aside?: React.ReactNode; children: React.ReactNode }): React.JSX.Element {
  return <section className="dsha-group">
    <div className="dsha-grouphead"><h3>{title}</h3>{aside}</div>
    {children}
  </section>
}

function Button({ primary = false, disabled, onClick, children }: { primary?: boolean; disabled?: boolean; onClick: () => void | Promise<void>; children: React.ReactNode }): React.JSX.Element {
  return <button className={`dsha-btn${primary ? ' dsha-btn-primary' : ''}`} type="button" disabled={disabled} onClick={() => void onClick()}>{children}</button>
}

function InfoRow({ label, value }: { label: string; value: string }): React.JSX.Element {
  return <div className="dsha-row"><span className="dsha-label">{label}</span><span className="dsha-value">{value}</span></div>
}

const SWITCHER_STATE_LABELS = {
  idle: 'switcherStateIdle',
  applying: 'switcherStateApplying',
  applied: 'switcherStateApplied',
  missing: 'switcherStateMissing',
  failed: 'switcherStateFailed',
} as const

const FETCH_MODE_LABELS = {
  auto: 'fetchModeAuto',
  plugin: 'fetchModePlugin',
  dsh: 'fetchModeDsh',
} as const

/**
 * Read-only view of the fetch selection, shown under the search source.
 *
 * Both blocks are optional on the status DTO, so every row is rendered only from
 * a value the host actually reported. That distinction is load-bearing: a
 * missing `switcher` means the host tells us nothing and the row stays hidden,
 * while a reported `configuredFetchProvider: null` is a real answer — the host
 * pinned no provider, which is the DSH default. Guessing an id there would claim
 * a provider the settings page never observed.
 *
 * Nothing here is editable: the mode and the limits live in the plugin Config,
 * not in the preferences this card sits in, so the numbers cannot be mistaken for
 * a setting that this page can change.
 */
export function FetchProviderStatusCard({ status, t }: { status: PluginStatusDto | null | undefined; t: Translate }): React.JSX.Element | null {
  const switcher = status?.switcher
  const configuration = status?.fetchConfiguration
  if (switcher === undefined && configuration === undefined) return null
  const state = switcher !== null && switcher !== undefined && switcher.state in SWITCHER_STATE_LABELS
    ? switcher.state
    : null
  const mode = configuration !== undefined && configuration.fetchProvider in FETCH_MODE_LABELS
    ? configuration.fetchProvider
    : undefined
  const maxBodyChars = fetchLimit(configuration?.fetchMaxBodyChars)
  const maxResponseBytes = fetchLimit(configuration?.fetchMaxResponseBytes)
  return <div className="dsha-context-settings" data-fetch-status={state ?? 'none'}>
    <div>
      <strong>{t('fetchStatus')}</strong>
      <p className="dsha-muted">{t('fetchStatusHint')}</p>
    </div>
    {switcher !== null && switcher !== undefined ? <InfoRow
      label={t('fetchConfiguredProvider')}
      value={switcher.configuredFetchProvider || t('fetchProviderDshDefault')}
    /> : null}
    {state !== null ? <InfoRow label={t('switcherState')} value={t(SWITCHER_STATE_LABELS[state])} /> : null}
    {mode !== undefined ? <InfoRow label={t('fetchMode')} value={t(FETCH_MODE_LABELS[mode])} /> : null}
    {maxBodyChars !== null ? <InfoRow label={t('fetchMaxBodyChars')} value={`${maxBodyChars} ${t('characters')}`} /> : null}
    {maxResponseBytes !== null ? <InfoRow label={t('fetchMaxResponseBytes')} value={`${maxResponseBytes} ${t('bytes')}`} /> : null}
    {mode !== undefined && mode !== 'plugin' ? <p className="dsha-muted">{t('fetchLimitsInactive')}</p> : null}
    <p className="dsha-muted">{t('fetchConfigSource')}</p>
  </div>
}

/** A limit is shown only once it is the positive safe integer the Config promises. */
function fetchLimit(value: number | undefined): number | null {
  return value !== undefined && Number.isSafeInteger(value) && value >= 1 ? value : null
}

function QuotaFact({ label, value }: { label: string; value: string }): React.JSX.Element {
  return <div className="dsh-codex-quota-fact"><span>{label}</span><strong>{value}</strong></div>
}

export function ResetCreditsFact({ resetCredits, busy, onUse, t }: { resetCredits: NonNullable<PluginStatusDto['quota']['resetCredits']>; busy: BusyAction; onUse: () => Promise<void>; t: Translate }): React.JSX.Element {
  const available = resetCredits.availableCount > 0
  return <div className="dsh-codex-reset-credits">
    <div className="dsh-codex-reset-credits-info">
      <span>{t('resetCredits')}</span>
      <strong>{resetCredits.availableCount}</strong>
      <small>{t('resetCreditExpires')}: {resetCredits.expiresAt == null ? t('unknown') : formatReset(resetCredits.expiresAt)}</small>
    </div>
    <Button primary disabled={!available || busy !== null} onClick={onUse}>{busy === 'reset-credit' ? t('usingResetCredit') : t('useResetCredit')}</Button>
  </div>
}

export function QuotaBar({ label, window, t }: { label: string; window: QuotaWindowDto; t: Translate }): React.JSX.Element {
  const percent = typeof window?.usedPercent === 'number' && Number.isFinite(window.usedPercent) ? window.usedPercent : 0
  const level = percent >= 95 ? 'danger' : percent >= 80 ? 'warning' : 'normal'
  const remaining = Math.max(0, 100 - percent)
  return <div className="dsh-codex-meter-wrap">
    <div className="dsh-codex-meter-label"><span>{label}</span><strong>{formatPercent(percent)}</strong></div>
    <div className={`dsh-codex-meter dsh-codex-meter-${level}`} role="progressbar" aria-label={`${label}: ${formatPercent(percent)} ${t('used')}`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={percent}>
      <span style={{ width: `${Math.min(100, Math.max(0, percent))}%` }} />
    </div>
    <div className="dsh-codex-meter-meta">
      <span>{percent >= 100 ? `${t('exhausted')} · ${formatPercent(remaining)} ${t('remaining')}` : `${formatPercent(percent)} ${t('used')} · ${formatPercent(remaining)} ${t('remaining')}`}</span>
      <span>{window?.resetsAt == null ? '—' : `${t('resets')}: ${formatReset(window.resetsAt)}`}</span>
    </div>
  </div>
}

function Skeleton({ label }: { label: string }): React.JSX.Element {
  return <div className="dsh-codex-skeleton" role="status" aria-label={label}><span /><span /></div>
}

export function windowLabel(minutes: number | null | undefined, t: Translate): string {
  if (minutes === null || minutes === undefined || typeof minutes !== 'number' || !Number.isFinite(minutes) || minutes <= 0) return t('limitWindow')
  const [value, unit]: [number, Intl.NumberFormatOptions['unit']] = minutes >= 1440 && minutes % 1440 === 0
    ? [minutes / 1440, 'day']
    : minutes >= 60 && minutes % 60 === 0
      ? [minutes / 60, 'hour']
      : [Math.round(minutes), 'minute']
  try {
    return `${new Intl.NumberFormat(undefined, { style: 'unit', unit, unitDisplay: 'long' }).format(value)} ${t('limitWindow')}`
  } catch {
    return `${value} ${t('limitWindow')}`
  }
}

export function parsePositiveCapacity(value: string): number | null {
  const normalized = value.trim().toLowerCase().replace(/[,_\s]/g, '')
  const matched = normalized.match(/^(\d+(?:\.\d+)?)(k|m)?$/)
  if (matched === null) return null
  const multiplier = matched[2] === 'm' ? 1_000_000 : matched[2] === 'k' ? 1_000 : 1
  const parsed = Number(matched[1]) * multiplier
  return Number.isSafeInteger(parsed) && parsed >= 1 ? parsed : null
}

export function parseCapacity(value: string, maxContextWindow = GPT_56_MAX_CONTEXT_WINDOW): number | null {
  const parsed = parsePositiveCapacity(value)
  return parsed !== null && parsed <= maxContextWindow ? parsed : null
}

function formatCapacity(value: number): string {
  if (value % 1_000 === 0) return `${value / 1_000}K`
  return String(value)
}

function formatPercent(value: number | undefined | null): string {
  if (value === undefined || value === null || typeof value !== 'number' || !Number.isFinite(value)) return '0%'
  try {
    return `${new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 }).format(value)}%`
  } catch {
    return `${value}%`
  }
}

function individualLimitLabel(limit: NonNullable<PluginStatusDto['quota']['individualLimit']>, t: Translate): string {
  const parts = [
    limit.remainingPercent !== null && limit.remainingPercent !== undefined ? `${formatPercent(limit.remainingPercent)} ${t('remaining')}` : null,
    limit.limit !== null && limit.limit !== undefined ? `${t('limit')}: ${limit.limit}` : null,
    limit.used !== null && limit.used !== undefined ? `${t('used')}: ${limit.used}` : null,
    limit.resetsAt !== null && limit.resetsAt !== undefined ? `${t('resets')}: ${formatReset(limit.resetsAt)}` : null,
  ].filter((part): part is string => part !== null)
  return parts.length > 0 ? parts.join(' · ') : t('unknown')
}

/**
 * `m:ss` left on the grant, floored at zero — the panel's countdown.
 *
 * Both arguments are on the same clock: `deadlineMs` was derived from the host's
 * `expiresAt - now` pair when the answer arrived (see {@link panelDeadlineMs}),
 * so this subtraction never mixes a host timestamp with a browser one.
 */
function formatRemaining(deadlineMs: number, nowMs: number): string {
  const total = Math.max(0, Math.floor(deadlineMs - nowMs) / 1000)
  const minutes = Math.floor(total / 60)
  const seconds = Math.floor(total % 60)
  return `${minutes}:${String(seconds).padStart(2, '0')}`
}

/**
 * The panel's copy control, used twice.
 *
 * One component rather than two buttons with the same classes: the two icons sat
 * at different sizes in the first version, and the only durable fix is that there
 * is exactly one of them. The tooltip never changes — the tick is the feedback,
 * so the affordance keeps saying what it does.
 */
function CopyButton({ copied, label, onClick }: { copied: boolean; label: string; onClick: () => void }): React.JSX.Element {
  return (
    <button
      type="button"
      className={copied ? 'dsh-codex-copy dsh-codex-copy-done' : 'dsh-codex-copy'}
      title={label}
      aria-label={label}
      data-copied={copied ? 'true' : 'false'}
      onClick={onClick}
    >
      {copied ? <CheckIcon /> : <CopyIcon />}
    </button>
  )
}

function CopyIcon(): React.JSX.Element {
  return (
    <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false">
      <rect x="5.6" y="5.6" width="8" height="8" rx="1.6" fill="none" stroke="currentColor" strokeWidth="1.3" />
      <path d="M10.4 5.6V4.2A1.6 1.6 0 0 0 8.8 2.6H4.2A1.6 1.6 0 0 0 2.6 4.2v4.6A1.6 1.6 0 0 0 4.2 10.4h1.4" fill="none" stroke="currentColor" strokeWidth="1.3" />
    </svg>
  )
}

function CheckIcon(): React.JSX.Element {
  return (
    <svg viewBox="0 0 16 16" width="14" height="14" aria-hidden="true" focusable="false">
      <path d="M3 8.4l3.3 3.3L13 4.8" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function formatDate(seconds: number | undefined | null): string {
  if (seconds === undefined || seconds === null || typeof seconds !== 'number' || !Number.isFinite(seconds) || seconds <= 0) return '—'
  const ms = seconds > 10_000_000_000 ? seconds : seconds * 1000
  try {
    return new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' }).format(ms)
  } catch {
    return '—'
  }
}

export function formatReset(seconds: number | undefined | null): string {
  if (seconds === undefined || seconds === null || typeof seconds !== 'number' || !Number.isFinite(seconds) || seconds <= 0) return '—'
  const ms = seconds > 10_000_000_000 ? seconds : seconds * 1000
  const absolute = formatDate(seconds)
  const diff = ms - Date.now()
  const abs = Math.abs(diff)
  const [amount, unit]: [number, Intl.RelativeTimeFormatUnit] = abs >= 86_400_000
    ? [Math.round(diff / 86_400_000), 'day']
    : abs >= 3_600_000
      ? [Math.round(diff / 3_600_000), 'hour']
      : [Math.round(diff / 60_000), 'minute']
  try {
    return `${absolute} (${new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' }).format(amount, unit)})`
  } catch {
    return absolute
  }
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
