import React, { useCallback, useEffect, useState } from 'react'
import { AccountPoolSection } from '../common/AccountPoolSection.tsx'
import { ModelChecklist } from '../common/ModelChecklist.tsx'
import type { AccountRotationStrategy } from '../../shared/account-pool-contracts.ts'
import {
  OLLAMA_REASONING_EFFORTS,
  type OllamaReasoningEffort,
  type OllamaWebStatus,
} from '../../shared/ollama-contracts.ts'
import { OllamaApi } from './api.ts'
import { zh, NS_OLLAMA } from './locales.ts'
import { useLineDict } from '../common/line-locale.ts'

const API = new OllamaApi()

/**
 * What each thinking level says in this card.
 *
 * 'none' is the only one that needs words, because it is not a weaker rung on
 * the same ladder: it means "send no thinking control", which for the boolean
 * families (deepseek-r1 and friends) is an explicit off, and for gpt-oss means
 * nothing at all. The other three are spelled the way the models spell them.
 */
const EFFORT_LABELS: Record<OllamaReasoningEffort, string> = {
  none: 'none（关闭思考）',
  low: 'low（低）',
  medium: 'medium（中）',
  high: 'high（高）',
}

/**
 * A token count short enough to sit in an account card.
 *
 * Exact below a thousand, then thousands, then millions. A six-figure number with
 * no grouping is unreadable at card width, and these are running totals that only
 * ever grow, so rounding is fine but commas are not optional.
 */
export function formatTokens(value: number): string {
  if (!Number.isFinite(value) || value < 0) return '—'
  if (value < 1_000) return String(Math.floor(value))
  if (value < 1_000_000) return `${(value / 1_000).toFixed(value < 10_000 ? 1 : 0)}K`
  return `${(value / 1_000_000).toFixed(1)}M`
}

interface Props {
  onModelChange?: () => void
  loadModelDirectory?: () => void
}

/**
 * The Ollama tab.
 *
 * Deliberately thin. The account card, its badges and the rotation picker are
 * the shared {@link AccountPoolSection}, so this line looks
 * like every other provider tab by construction rather than by imitation; only
 * what is genuinely Ollama's - pasting a key, syncing the catalog, and the
 * documented service limits - is written here.
 */
export function OllamaSection(props: Props): React.ReactElement {
  const [status, setStatus] = useState<OllamaWebStatus | null>(null)
  const [busy, setBusy] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [key, setKey] = useState('')
  const [alias, setAlias] = useState('')
  const [showKeyForm, setShowKeyForm] = useState(false)
  /** Ids the user has switched on. Null means 'no filter', i.e. all of them. */
  const [enabled, setEnabled] = useState<Set<string> | null>(null)

  const reload = useCallback(async () => {
    try {
      const next = await API.status()
      setStatus(next)
      setEnabled(next.enabledModelIds == null ? null : new Set(next.enabledModelIds))
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause))
    }
  }, [])

  useEffect(() => {
    void reload()
  }, [reload])

  const run = useCallback(async (label: string, action: () => Promise<OllamaWebStatus>) => {
    setBusy(label)
    setError(null)
    try {
      setStatus(await action())
      props.onModelChange?.()
      props.loadModelDirectory?.()
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : String(cause))
    } finally {
      setBusy(null)
    }
  }, [props])

  const addKey = useCallback(() => {
    const trimmed = key.trim()
    if (trimmed === '') return
    void run('add', async () => {
      const next = await API.accountAction('add', {
        apiKey: trimmed,
        ...(alias.trim() === '' ? {} : { alias: alias.trim() }),
      })
      // Cleared only after the host accepted it, so a failed add never loses the
      // key the user just pasted and would have to find again.
      setKey('')
      setAlias('')
      setShowKeyForm(false)
      return next
    })
  }, [key, alias, run])

  const syncCatalog = useCallback(() => {
    void run('catalog', async () => {
      await API.refreshCatalog()
      return API.status()
    })
  }, [run])

  // A null selection means 'everything the catalog returned', which is what the
  // adapter reads as no filter. Modelling 'all' as null rather than an explicit
  // all-ids list means a model the service adds later is not silently hidden by
  // a selection made before it existed. An array is an explicit selection, and
  // an empty one switches every model off.
  const isModelEnabled = useCallback((id: string): boolean => {
    return enabled === null || enabled.has(id)
  }, [enabled])

  const applyEnabled = useCallback((next: string[] | null) => {
    void run('models', async () => {
      const result = await API.setEnabledModels(next)
      setEnabled(result.enabledModelIds == null ? null : new Set(result.enabledModelIds))
      return API.status()
    })
  }, [run])

  const toggleModel = useCallback((id: string, checked: boolean) => {
    if (status === null) return
    const all = status.models ?? []
    const current = all.filter(model => isModelEnabled(model.id)).map(model => model.id)
    const next = checked
      ? [...new Set([...current, id])]
      : current.filter(entry => entry !== id)
    // Covering the whole list is stored as null, so 'all' keeps tracking the
    // catalog instead of freezing at the list that happened to be complete.
    applyEnabled(next.length === all.length ? null : next)
  }, [status, isModelEnabled, applyEnabled])

  const setAllModels = useCallback((selectAll: boolean) => {
    applyEnabled(selectAll ? null : [])
  }, [applyEnabled])

  const setEffort = useCallback((value: string) => {
    // The dropdown's empty option is the card's 'not specified', which is null on
    // the wire and a real stored value rather than an absent patch: sending
    // nothing would leave the previous level in place and make it un-undoable.
    void run('effort', () => API.setDefaultReasoningEffort(value === '' ? null : value))
  }, [run])

  const t = useLineDict(NS_OLLAMA, zh)
  const pool = status?.pool
  // A partial status payload (a host build whose action answer is not the full
  // status) must degrade to empty blocks, never crash the settings page.
  const models = status?.models ?? []

  return (
    <div>
      <div className="dsha-group">
        <div className="dsha-grouphead">
          <h3>{t.title}</h3>
        </div>
        <p className="dsha-notice">{t.pageDesc}</p>
        {error !== null && (
          <p className="dsha-notice" style={{ color: 'var(--dsha-danger, #c0392b)' }}>
            {t.error.replace('{detail}', error)}
          </p>
        )}
      </div>

      {pool !== undefined && (
        <AccountPoolSection
          accounts={pool.accounts}
          activeAccountId={pool.activeAccountId}
          rotationStrategy={pool.rotationStrategy}
          labels={t}
          busy={busy}
          onLogin={() => setShowKeyForm(value => !value)}
          onSetPrimary={(id) => void run('set-primary', () => API.accountAction('set-primary', { accountId: id }))}
          onDelete={(id) => void run('delete', () => API.accountAction('delete', { accountId: id }))}
          onClearCooldown={(id) => void run('clear-cooldown', () => API.accountAction('clear-cooldown', { accountId: id }))}
          onSetStrategy={(strategy: AccountRotationStrategy) =>
            void run('strategy', () => API.accountAction('strategy', { strategy }))}
          renderDetails={(account) => {
            const usage = account.usage
            return <>
              {account.lastModelId !== undefined && <span>{t.lastModel}: {account.lastModelId}</span>}
              {usage === undefined
                ? <span>{t.usageNone}</span>
                : <span>
                  {t.usageInput.replace('{tokens}', formatTokens(usage.inputTokens))}
                  {t.usageOutput.replace('{tokens}', formatTokens(usage.outputTokens))}
                  {t.usageRequests.replace('{count}', String(usage.requestCount))}
                </span>}
            </>
          }}
          renderLoginActions={() => (
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                className="dsha-btn dsha-btn-primary"
                disabled={busy !== null}
                onClick={() => setShowKeyForm(value => !value)}
              >
                {t.addAccount}
              </button>
            </div>
          )}
        >
          {showKeyForm && (
            <div className="dsha-pref-row" style={{ flexDirection: 'column', alignItems: 'stretch', gap: 8 }}>
              <label className="dsha-label" htmlFor="ollama-key">{t.keySection}</label>
              <input
                id="ollama-key"
                className="dsha-input"
                type="password"
                value={key}
                placeholder={t.keyPlaceholder}
                autoComplete="off"
                onChange={(event) => setKey(event.target.value)}
              />
              <label className="dsha-label" htmlFor="ollama-alias">{t.keyAliasLabel}</label>
              <input
                id="ollama-alias"
                className="dsha-input"
                value={alias}
                placeholder={t.keyAliasPlaceholder}
                onChange={(event) => setAlias(event.target.value)}
              />
              <p className="dsha-muted" style={{ fontSize: 12 }}>{t.keyHint}</p>
              <p className="dsha-muted" style={{ fontSize: 12 }}>{t.keyAliasHint}</p>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  className="dsha-btn dsha-btn-primary"
                  disabled={busy !== null || key.trim() === ''}
                  onClick={addKey}
                >
                  {busy === 'add' ? t.keySaving : t.keySave}
                </button>
                <button className="dsha-btn" disabled={busy !== null} onClick={() => setShowKeyForm(false)}>
                  {zh.deleteAccount}
                </button>
              </div>
            </div>
          )}
        </AccountPoolSection>
      )}

      <div className="dsha-group">
        <div className="dsha-grouphead">
          <h3>{t.modelsSection}</h3>
          <button className="dsha-btn" disabled={busy !== null} onClick={syncCatalog}>
            {busy === 'catalog' ? t.catalogSyncing : t.catalogSync}
          </button>
        </div>
        <p className="dsha-muted" style={{ fontSize: 12 }}>{t.modelsHint}</p>
        <p className="dsha-muted" style={{ fontSize: 12 }}>{t.wireNote}</p>
        {status !== null && models.length === 0 && (
          <div className="dsha-empty">
            {status.catalogSynced ? t.catalogEmpty : t.catalogNeverSynced}
          </div>
        )}
        {status !== null && models.length === 0 && !status.usable && (
          <p className="dsha-muted" style={{ fontSize: 12 }}>{t.catalogNeedKey}</p>
        )}
        {status !== null && models.length > 0 && (
          <>
            <p className="dsha-muted" style={{ fontSize: 12 }}>
              {t.modelCount.replace('{count}', String(models.length))}
            </p>
            <ModelChecklist
              items={models.map((model) => ({
                id: model.id,
                name: model.name ?? model.id,
                enabled: isModelEnabled(model.id),
              }))}
              busy={busy !== null}
              onToggle={(id, enabled) => void toggleModel(id, enabled)}
              onToggleAll={(enabled) => void setAllModels(enabled)}
              labels={{ selectAll: t.selectAll, clearAll: t.unselectAll, list: t.modelsSection }}
            />
          </>
        )}
      </div>

      <div className="dsha-group">
        <div className="dsha-grouphead">
          <h3>{t.enhanced}</h3>
        </div>
        <div className="dsha-pref-row">
          <div>
            <strong>{t.defaultReasoningEffort}</strong>
            <p className="dsha-muted">{t.defaultReasoningEffortHint}</p>
          </div>
          {/* Read through the nullish coalesce on purpose. A host that
              predates this field answers without it, and an undefined value on
              a controlled select is one of the ways a settings page goes blank.
              The empty option is exactly the state the field's null means, so
              such a host degrades to "not specified" rather than to an error. */}
          <select
            className="dsha-select"
            aria-label={t.defaultReasoningEffort}
            value={status?.defaultReasoningEffort ?? ''}
            disabled={busy !== null}
            onChange={(event) => setEffort(event.currentTarget.value)}
          >
            <option value="">{t.defaultEffortAuto}</option>
            {OLLAMA_REASONING_EFFORTS.map((effort) => (
              <option key={effort} value={effort}>{EFFORT_LABELS[effort]}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="dsha-group">
        <div className="dsha-grouphead">
          <h3>{t.limitsSection}</h3>
        </div>
        <p className="dsha-muted" style={{ fontSize: 12 }}>{t.limitsHint}</p>
        <ul className="dsha-notice" style={{ paddingLeft: 18 }}>
          <li>{t.limitNoStateful}</li>
          <li>{t.limitNoWebSearch}</li>
          <li>{t.limitNoToolReplay}</li>
          <li>{t.limitUsage}</li>
        </ul>
      </div>
    </div>
  )
}