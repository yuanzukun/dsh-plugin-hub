import { randomUUID } from 'node:crypto'
import {
  CODEX_RESET_CREDITS_CONSUME_URL,
  CODEX_RESET_CREDITS_URL,
  CODEX_USAGE_URL,
  QUOTA_CACHE_MS,
  QUOTA_MIN_UPSTREAM_INTERVAL_MS,
} from '../compat.ts'
import type {
  ConnectionTestDto,
  PublicErrorDto,
  QuotaBucketDto,
  QuotaUsageDto,
  QuotaStatusDto,
  QuotaWindowDto,
} from '../shared/contracts.ts'
import { OAuthService } from './oauth-service.ts'
import { codexHeaders, retryAfterMs } from './wire-auth.ts'
import type { StoredOAuthCredentials } from './token-store.ts'

type FetchLike = typeof fetch

/**
 * The quota card reads the same account the conversation uses, but it must keep
 * reading it while that account is cooling down — otherwise the card that exists
 * to explain a spent window is the first thing the spent window breaks.
 *
 * Every credential this service asks for is therefore a `'tool'` read: not a
 * metered model request, so rotation cooldowns do not apply.
 */
const USAGE_CREDENTIAL_ACCESS = { purpose: 'tool' } as const

interface CacheEntry {
  usage: QuotaUsageDto
  fetchedAt: number
  accountKey: string
}

const EMPTY_USAGE: QuotaUsageDto = {
  buckets: [],
  credits: null,
  individualLimit: null,
  spendControlReached: null,
  resetCredits: null,
}

export interface UsageServiceOptions {
  fetchFn?: FetchLike
  now?: () => number
}

/** How one status read may treat a snapshot that has aged past its TTL. */
export interface UsageStatusOptions {
  /**
   * Answer from an existing snapshot and refresh behind it, instead of waiting
   * for the upstream request. A caller that must not show aged numbers — or has
   * no snapshot to show — leaves this off.
   */
  backgroundRefresh?: boolean
}

export class UsageService {
  private readonly fetchFn: FetchLike
  private readonly now: () => number
  private cache: CacheEntry | null = null
  // One snapshot per account identity, kept so the pool can skip an account
  // whose window is already spent without spending a request to rediscover it.
  private readonly snapshots = new Map<string, { usage: QuotaUsageDto; fetchedAt: number }>()
  private lastUpstreamAt = 0
  private blockedUntil = 0
  private invalidated = false
  /**
   * Serving identity observed when {@link cache} was written.
   *
   * A warm snapshot may only be served while this still matches, which is what
   * keeps the cheap early return below from reporting one account's quota under
   * another account's name.
   */
  private cacheIdentityRevision: number | null = null
  private inFlight: Promise<QuotaStatusDto> | null = null
  private resetConsumeInFlight: Promise<QuotaStatusDto> | null = null

  constructor(private readonly oauth: OAuthService, options: UsageServiceOptions = {}) {
    this.fetchFn = options.fetchFn ?? fetch
    this.now = options.now ?? Date.now
  }

  async status(authenticated: boolean, force = false, options: UsageStatusOptions = {}): Promise<QuotaStatusDto> {
    if (!authenticated) return { state: 'signed-out', ...EMPTY_USAGE, fetchedAt: null, stale: false }
    const now = this.now()

    // A warm, un-invalidated snapshot is answerable without reading the
    // credential store. Reading it costs a DPAPI unprotect through a spawned
    // `powershell.exe` on Windows (~200 ms), and the settings card polls this
    // route on a 60 s timer, so acquiring credentials first made every poll pay
    // that launch even when nothing had changed.
    //
    // The guard that makes this safe is the identity revision: it is compared
    // against the revision observed when the snapshot was written, so any write
    // that can move which account serves a request (a sign-in, a delete, a pin,
    // a rotation, a refresh) falls through to the credential read below. That
    // check has to happen BEFORE the early return, because the account key that
    // used to guard this cache is only known from the credential we are trying
    // to avoid reading — without it, switching accounts inside the 60 s window
    // served the previous account's quota.
    if (!force && !this.invalidated && this.cache !== null
      && now - this.cache.fetchedAt < QUOTA_CACHE_MS
      && this.cacheIdentityRevision === this.oauth.currentIdentityRevision()) {
      return this.fromCache(false)
    }

    let selection: { accountId?: string; credentials: StoredOAuthCredentials }
    try {
      selection = await this.oauth.credentialSelection(false, USAGE_CREDENTIAL_ACCESS)
    } catch (error) {
      // "Could not be refreshed" alone sent people looking at their token; the
      // provider's own reason (a rejected refresh, an unwritable store, a
      // missing sign-in) is what makes the card actionable.
      const reason = error instanceof Error && error.message !== '' ? ` (${error.message})` : ''
      return this.failure({
        code: 'quota-failed',
        message: `ChatGPT credentials could not be refreshed.${reason}`,
      })
    }
    const credentials = selection.credentials
    // ONE key for the page-level cache and the per-account map: the POOL ROW when
    // there is one — the identity that survives a token refresh, and the only one
    // that tells two pooled accounts apart when neither states an id or an email
    // — and the credential identity otherwise.
    const accountKey = this.snapshotKeyFor(selection.accountId, credentials)
    if (this.cache !== null && this.cache.accountKey !== accountKey) this.clear()
    if (!force && !this.invalidated && this.cache !== null && now - this.cache.fetchedAt < QUOTA_CACHE_MS) {
      return this.fromCache(false)
    }
    if (this.cache !== null && now - this.lastUpstreamAt < QUOTA_MIN_UPSTREAM_INTERVAL_MS) {
      return this.fromCache(this.invalidated || now - this.cache.fetchedAt >= QUOTA_CACHE_MS)
    }
    if (now < this.blockedUntil) {
      return this.failure({ code: 'rate-limited', message: 'Quota refresh is temporarily rate limited.' })
    }
    // A stale snapshot that exists answers now, with the refresh running behind
    // it. Waiting on the upstream request here is what made every tab open after
    // the TTL take 1-3 s, while the card only ever needed a value it already
    // had; the client asks again shortly so the refreshed snapshot still lands
    // in the UI.
    if (options.backgroundRefresh === true && this.cache !== null) {
      this.startBackgroundRefresh(credentials, accountKey)
      return this.fromCache(true)
    }
    if (this.inFlight !== null) return this.inFlight
    this.inFlight = this.refreshUpstream(credentials, accountKey).finally(() => {
      this.inFlight = null
    })
    return this.inFlight
  }

  /** Whether a quota refresh is running, so a caller can ask again when it lands. */
  get refreshing(): boolean {
    return this.inFlight !== null
  }

  /**
   * Refresh behind an answer that has already been given.
   *
   * The rejection is absorbed here: this refresh has no caller to receive it,
   * and {@link fromCache} keeps serving the snapshot it failed to replace.
   */
  private startBackgroundRefresh(credentials: StoredOAuthCredentials, snapshotKey: string): void {
    if (this.inFlight !== null) return
    const task = this.refreshUpstream(credentials, snapshotKey).finally(() => {
      if (this.inFlight === task) this.inFlight = null
    })
    this.inFlight = task
    void task.catch(() => undefined)
  }

  invalidate(): void {
    this.invalidated = true
  }

  /**
   * When one credential's Codex window reopens, from the last snapshot.
   *
   * Undefined means nothing is known or nothing is spent (the account stays
   * routable). A spent window with no stated reset blocks for the default
   * cooldown rather than forever, so a missing upstream field cannot strand an
   * account permanently.
   */
  blockedUntilFor(
    accountId: string | undefined,
    credentials: StoredOAuthCredentials,
    now: number,
  ): number | undefined {
    const snapshot = this.snapshots.get(this.snapshotKeyFor(accountId, credentials))
    if (snapshot === undefined) return undefined
    let reopen: number | undefined
    for (const bucket of snapshot.usage.buckets) {
      if (bucket.id !== 'codex') continue
      for (const window of bucket.windows) {
        if (window.usedPercent < 100) continue
        const reopenAt = window.resetsAt === null ? now + QUOTA_MIN_UPSTREAM_INTERVAL_MS : window.resetsAt * 1000
        reopen = reopen === undefined ? reopenAt : Math.max(reopen, reopenAt)
      }
    }
    return reopen !== undefined && reopen > now ? reopen : undefined
  }

  /**
   * The newest quota snapshot held for one account, if any.
   *
   * Quota follows the account, so the settings card shows each account its own
   * progress. The pool asks here with the row id it addresses the account by —
   * the identity that survives a token refresh — while its credentials answer
   * for a composition without a pool. This reads the remembered map only, never
   * the network, because opening the settings page must not cost one upstream
   * request per pooled account.
   */
  snapshotFor(
    accountId: string | undefined,
    credentials: StoredOAuthCredentials,
  ): { usage: QuotaUsageDto; fetchedAt: number } | undefined {
    return this.snapshots.get(this.snapshotKeyFor(accountId, credentials))
  }

  /**
   * Key one account's remembered snapshot is filed under.
   *
   * A pool row id when the caller names one, prefixed so it can never be
   * confused with the credential-derived key, and otherwise the credential
   * identity — which is all a composition without a pool has. Two pooled accounts
   * that state neither an account id nor an email would otherwise collapse onto
   * one key and show each other's numbers, so the row id is the answer wherever
   * a pool is in charge.
   */
  private snapshotKeyFor(accountId: string | undefined, credentials: StoredOAuthCredentials): string {
    return accountId === undefined || accountId === '' ? identityKey(credentials) : `row:${accountId}`
  }

  /** Remember the newest snapshot for one account, bounded to the accounts in use. */
  private rememberSnapshot(accountKey: string, usage: QuotaUsageDto, fetchedAt: number): void {
    this.snapshots.set(accountKey, { usage, fetchedAt })
    while (this.snapshots.size > 20) {
      const oldest = [...this.snapshots.entries()].sort((left, right) => left[1].fetchedAt - right[1].fetchedAt)[0]
      if (oldest === undefined) break
      this.snapshots.delete(oldest[0])
    }
  }

  clear(): void {
    this.cache = null
    this.cacheIdentityRevision = null
    this.blockedUntil = 0
    this.invalidated = false
  }

  /** Drop the remembered snapshot of one account, after its window is known to have reset. */
  forgetSnapshot(accountId: string | undefined, credentials: StoredOAuthCredentials): void {
    this.snapshots.delete(this.snapshotKeyFor(accountId, credentials))
  }

  async consumeResetCredit(): Promise<QuotaStatusDto> {
    if (this.resetConsumeInFlight !== null) return this.resetConsumeInFlight
    this.resetConsumeInFlight = this.consumeResetCreditUpstream().finally(() => {
      this.resetConsumeInFlight = null
    })
    return this.resetConsumeInFlight
  }

  private async consumeResetCreditUpstream(): Promise<QuotaStatusDto> {
    let credentials: StoredOAuthCredentials
    let accountId: string | undefined
    try {
      const selection = await this.oauth.credentialSelection(false, USAGE_CREDENTIAL_ACCESS)
      credentials = selection.credentials
      accountId = selection.accountId
      let creditsResponse = await this.fetchResetCredits(credentials)
      if (creditsResponse.status === 401) {
        await creditsResponse.body?.cancel().catch(() => undefined)
        const renewed = await this.oauth.credentialSelection(true, USAGE_CREDENTIAL_ACCESS)
        credentials = renewed.credentials
        accountId = renewed.accountId
        creditsResponse = await this.fetchResetCredits(credentials)
      }
      if (!creditsResponse.ok) {
        const status = creditsResponse.status
        await creditsResponse.body?.cancel().catch(() => undefined)
        throw new UsageServiceError({
          code: status === 429 ? 'rate-limited' : 'quota-failed',
          message: status === 429 ? 'Reset credit request was rate limited.' : `Reset credit request failed (${status}).`,
        })
      }
      const resetCredits = parseResetCredits(await creditsResponse.json() as unknown)
      const creditId = resetCredits.availableCreditIds[0]
      if (creditId === undefined) {
        throw new UsageServiceError({ code: 'bad-request', message: 'No reset credits are currently available.' })
      }
      const redeemRequestId = randomUUID()
      let consumeResponse = await this.fetchFn(CODEX_RESET_CREDITS_CONSUME_URL, {
        method: 'POST',
        headers: { ...codexHeaders(credentials), accept: 'application/json', 'content-type': 'application/json' },
        body: JSON.stringify({ credit_id: creditId, redeem_request_id: redeemRequestId }),
      })
      if (consumeResponse.status === 401) {
        await consumeResponse.body?.cancel().catch(() => undefined)
        const renewed = await this.oauth.credentialSelection(true, USAGE_CREDENTIAL_ACCESS)
        credentials = renewed.credentials
        accountId = renewed.accountId
        consumeResponse = await this.fetchFn(CODEX_RESET_CREDITS_CONSUME_URL, {
          method: 'POST',
          headers: { ...codexHeaders(credentials), accept: 'application/json', 'content-type': 'application/json' },
          body: JSON.stringify({ credit_id: creditId, redeem_request_id: redeemRequestId }),
        })
      }
      if (!consumeResponse.ok) {
        const status = consumeResponse.status
        await consumeResponse.body?.cancel().catch(() => undefined)
        throw new UsageServiceError({
          code: status === 429 ? 'rate-limited' : 'quota-failed',
          message: status === 429 ? 'Using the reset credit was rate limited.' : `Using the reset credit failed (${status}).`,
        })
      }
      await consumeResponse.body?.cancel().catch(() => undefined)
      this.clear()
      const refreshed = await this.refreshUpstream(credentials, this.snapshotKeyFor(accountId, credentials))
      if (refreshed.error !== undefined) {
        throw new UsageServiceError({ code: 'quota-failed', message: 'The reset credit was used, but usage could not be refreshed.' })
      }
      return refreshed
    } catch (error) {
      if (error instanceof UsageServiceError) throw error
      throw new UsageServiceError({ code: 'quota-failed', message: 'The reset credit could not be used.' })
    }
  }

  async testConnection(): Promise<ConnectionTestDto> {
    const started = this.now()
    const result = await this.status(true, true)
    if (result.state === 'error' || result.error !== undefined) {
      throw new UsageServiceError(result.error ?? { code: 'connection-failed', message: 'Codex connection test failed.' })
    }
    return { connected: true, latencyMs: Math.max(0, this.now() - started), checkedAt: Math.floor(this.now() / 1000) }
  }

  private async refreshUpstream(initialCredentials: StoredOAuthCredentials, initialSnapshotKey: string): Promise<QuotaStatusDto> {
    this.lastUpstreamAt = this.now()
    try {
      let credentials = initialCredentials
      let snapshotKey = initialSnapshotKey
      let response = await this.fetch(credentials)
      if (response.status === 401) {
        await response.body?.cancel().catch(() => undefined)
        const renewed = await this.oauth.credentialSelection(true, USAGE_CREDENTIAL_ACCESS)
        credentials = renewed.credentials
        // A renewal can land on another account. The reading belongs to whoever
        // answered, so the key follows the credential actually used rather than
        // the one that was refused.
        snapshotKey = this.snapshotKeyFor(renewed.accountId, credentials)
        response = await this.fetch(credentials)
      }
      if (response.status === 429) {
        const delay = retryAfterMs(response.headers) ?? QUOTA_MIN_UPSTREAM_INTERVAL_MS
        this.blockedUntil = this.now() + Math.max(QUOTA_MIN_UPSTREAM_INTERVAL_MS, delay)
        await response.body?.cancel().catch(() => undefined)
        return this.failure({ code: 'rate-limited', message: 'Quota refresh was rate limited. Existing data was kept.' })
      }
      if (!response.ok) {
        await response.body?.cancel().catch(() => undefined)
        return this.failure({ code: 'quota-failed', message: `Quota request failed (${response.status}).` })
      }
      const data = await response.json() as unknown
      const usage = parseCodexUsage(data)
      if ((usage.resetCredits?.availableCount ?? 0) > 0) {
        const resetResponse = await this.fetchResetCredits(credentials).catch(() => null)
        if (resetResponse?.ok === true) {
          const reset = parseResetCredits(await resetResponse.json() as unknown)
          usage.resetCredits = { availableCount: reset.availableCount, expiresAt: reset.expiresAt }
        } else {
          await resetResponse?.body?.cancel().catch(() => undefined)
        }
      }
      this.cache = { usage, fetchedAt: this.now(), accountKey: snapshotKey }
      // Recorded as late as possible so a credential rotation that happened
      // while this request was in flight is still captured.
      this.cacheIdentityRevision = this.oauth.currentIdentityRevision()
      this.rememberSnapshot(snapshotKey, usage, this.cache.fetchedAt)
      this.invalidated = false
      return this.fromCache(false)
    } catch (error) {
      const publicError = error instanceof UsageServiceError
        ? error.publicError
        : { code: 'quota-failed' as const, message: 'Quota information could not be refreshed.' }
      return this.failure(publicError)
    }
  }

  private fetch(credentials: Awaited<ReturnType<OAuthService['credentials']>>): Promise<Response> {
    return this.fetchFn(CODEX_USAGE_URL, {
      headers: { ...codexHeaders(credentials), accept: 'application/json' },
    })
  }

  private fetchResetCredits(credentials: StoredOAuthCredentials): Promise<Response> {
    return this.fetchFn(CODEX_RESET_CREDITS_URL, {
      headers: { ...codexHeaders(credentials), accept: 'application/json' },
    })
  }

  private fromCache(stale: boolean, error?: PublicErrorDto): QuotaStatusDto {
    if (this.cache === null) return {
      state: error ? 'error' : 'empty',
      ...EMPTY_USAGE,
      fetchedAt: null,
      stale,
      ...(error ? { error } : {}),
    }
    return {
      state: error ? 'stale' : this.cache.usage.buckets.length > 0 ? 'ready' : 'empty',
      ...structuredClone(this.cache.usage),
      fetchedAt: Math.floor(this.cache.fetchedAt / 1000),
      stale,
      ...(error ? { error } : {}),
    }
  }

  private failure(error: PublicErrorDto): QuotaStatusDto {
    return this.fromCache(this.cache !== null, error)
  }
}

export class UsageServiceError extends Error {
  constructor(readonly publicError: PublicErrorDto) {
    super(publicError.message)
  }
}

export function mapCodexUsage(value: unknown): QuotaBucketDto[] {
  return parseCodexUsage(value).buckets
}

export function parseCodexUsage(value: unknown): QuotaUsageDto {
  const data = record(value)
  if (data === null) return structuredClone(EMPTY_USAGE)
  const planType = typeof data.plan_type === 'string' ? data.plan_type : null
  const buckets: QuotaBucketDto[] = []
  const usedIds = new Set<string>()
  addBucket(buckets, usedIds, 'codex', 'Codex', planType, data.rate_limit)
  addBucket(buckets, usedIds, 'code-review', 'Code review', planType, data.code_review_rate_limit)
  const additional = Array.isArray(data.additional_rate_limits) ? data.additional_rate_limits : []
  for (const [index, value] of additional.entries()) {
    const limit = record(value)
    if (limit === null) continue
    const idSource = text(limit.limit_name) ?? text(limit.metered_feature) ?? `additional-${index + 1}`
    const id = uniqueId(slug(idSource), usedIds)
    const name = readableLimitName(text(limit.limit_name) ?? text(limit.metered_feature) ?? idSource)
    addBucket(buckets, usedIds, id, name, planType, limit.rate_limit)
  }
  return {
    buckets,
    credits: mapCredits(data.credits),
    individualLimit: mapIndividualLimit(record(data.spend_control)?.individual_limit),
    spendControlReached: boolean(record(data.spend_control)?.reached),
    resetCredits: mapResetCredits(data.rate_limit_reset_credits),
  }
}

function addBucket(
  result: QuotaBucketDto[],
  usedIds: Set<string>,
  id: string,
  name: string,
  planType: string | null,
  value: unknown,
): void {
  const source = record(value)
  if (source === null) return
  const primary = mapWindow(source.primary_window)
  const secondary = mapWindow(source.secondary_window)
  if (primary === null && secondary === null) return
  result.push({ id, name, planType, primary, secondary, windows: [primary, secondary].filter(isWindow) })
  usedIds.add(id)
}

function mapWindow(value: unknown): QuotaWindowDto | null {
  const data = record(value)
  if (data === null) return null
  const used = numeric(data.used_percent)
  if (used === undefined) return null
  const seconds = numeric(data.limit_window_seconds)
  const reset = numeric(data.reset_at)
  return {
    usedPercent: Math.min(100, Math.max(0, used)),
    windowDurationMins: seconds !== undefined && seconds > 0 ? seconds / 60 : null,
    resetsAt: reset !== undefined && reset > 0 ? reset : null,
  }
}

function mapCredits(value: unknown): QuotaUsageDto['credits'] {
  const data = record(value)
  if (data === null) return null
  const hasCredits = boolean(data.has_credits)
  const unlimited = boolean(data.unlimited)
  const balance = decimalText(data.balance)
  if (hasCredits === null && unlimited === null && balance === null) return null
  return {
    hasCredits: hasCredits ?? (balance !== null || unlimited === true),
    unlimited: unlimited ?? false,
    balance,
  }
}

function mapIndividualLimit(value: unknown): QuotaUsageDto['individualLimit'] {
  const data = record(value)
  if (data === null) return null
  const remaining = numeric(data.remaining_percent)
  const reset = numeric(data.reset_at)
  const limit = decimalText(data.limit)
  const used = decimalText(data.used)
  if (remaining === undefined && reset === undefined && limit === null && used === null) return null
  return {
    limit,
    used,
    remainingPercent: remaining !== undefined ? Math.min(100, Math.max(0, remaining)) : null,
    resetsAt: reset !== undefined && reset > 0 ? reset : null,
  }
}

function mapResetCredits(value: unknown): QuotaUsageDto['resetCredits'] {
  const data = record(value)
  if (data === null) return null
  const available = numeric(data.available_count)
  if (available === undefined) return null
  return { availableCount: Math.max(0, Math.floor(available)), expiresAt: null }
}

export function parseResetCredits(value: unknown): { availableCount: number; expiresAt: number | null; availableCreditIds: string[] } {
  const data = record(value)
  if (data === null) return { availableCount: 0, expiresAt: null, availableCreditIds: [] }
  const credits = Array.isArray(data.credits) ? data.credits : []
  const available = credits
    .map(record)
    .filter((credit): credit is Record<string, unknown> => credit !== null && credit.status === 'available')
    .map((credit) => ({
      id: text(credit.id),
      expiresAt: timestamp(credit.expires_at),
    }))
    .filter((credit): credit is { id: string; expiresAt: number | null } => credit.id !== null)
    .sort((left, right) => (left.expiresAt ?? Number.MAX_SAFE_INTEGER) - (right.expiresAt ?? Number.MAX_SAFE_INTEGER))
  const reported = numeric(data.available_count)
  return {
    availableCount: reported === undefined ? available.length : Math.max(0, Math.floor(reported)),
    expiresAt: available.map(credit => credit.expiresAt).find((expiresAt): expiresAt is number => expiresAt !== null) ?? null,
    availableCreditIds: available.map(credit => credit.id),
  }
}

function timestamp(value: unknown): number | null {
  const numericValue = numeric(value)
  if (numericValue !== undefined && numericValue > 0) return numericValue > 10_000_000_000 ? Math.floor(numericValue / 1000) : Math.floor(numericValue)
  if (typeof value !== 'string') return null
  const parsed = Date.parse(value)
  return Number.isFinite(parsed) ? Math.floor(parsed / 1000) : null
}

function record(value: unknown): Record<string, unknown> | null {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null
}

function boolean(value: unknown): boolean | null {
  return typeof value === 'boolean' ? value : null
}

function numeric(value: unknown): number | undefined {
  if (typeof value !== 'number' && (typeof value !== 'string' || value.trim() === '')) return undefined
  const number = Number(value)
  return Number.isFinite(number) ? number : undefined
}

function decimalText(value: unknown): string | null {
  if (typeof value === 'number' && Number.isFinite(value)) return String(value)
  if (typeof value !== 'string') return null
  const trimmed = value.trim()
  return trimmed !== '' ? trimmed : null
}

function text(value: unknown): string | null {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : null
}

function slug(value: string): string {
  const normalized = value
    .trim()
    .toLowerCase()
    .replace(/[_\s]+/g, '-')
    .replace(/[^a-z0-9-]+/g, '-')
    .replace(/-{2,}/g, '-')
    .replace(/^-|-$/g, '')
  return normalized || 'additional'
}

function uniqueId(base: string, usedIds: Set<string>): string {
  let candidate = base
  let suffix = 2
  while (usedIds.has(candidate)) {
    candidate = `${base}-${suffix}`
    suffix += 1
  }
  return candidate
}

function readableLimitName(value: string): string {
  return value
    .replace(/^codex[_-]/i, '')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, match => match.toUpperCase()) || 'Additional limit'
}

function isWindow(value: QuotaWindowDto | null): value is QuotaWindowDto {
  return value !== null
}

function identityKey(credentials: StoredOAuthCredentials): string {
  return credentials.accountId ?? credentials.email ?? credentials.planType ?? 'signed-in'
}
