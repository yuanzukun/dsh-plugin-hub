import {
  CATALOG_CACHE_TTL_MS,
  DEFAULT_CONTEXT_WINDOW,
  DISCOVERY_TIMEOUT_MS,
  PROVIDER_NAME,
  QUOTA_CACHE_TTL_MS,
  anthropicUrl,
  inputModalitiesFor,
  maxOutputTokensFor,
  openAIUrl,
  reasoningEffortsFor,
  thinkingTypeFor,
  wireForModel,
} from './types.ts'
import {
  FileCredentialStore,
  resolveRegion,
  type KimiCodeCatalogModel,
  type KimiCodeCredentials,
} from './token-store.ts'
import { KimiCodeUnauthorizedError, ensureAccessToken, identityFromTokens, kimiIdentityHeaders } from './oauth.ts'
import { kimiCodeModelDef } from './model-catalog.ts'
import type {
  KimiCodeAccount,
  KimiCodeAccountQuota,
  KimiCodeExtraUsage,
  KimiCodeModelOption,
  KimiCodeRegion,
  KimiCodeThinkingType,
  KimiCodeUsageWindow,
  KimiCodeWire,
} from '../../shared/kimi-code-contracts.ts'
import { catalogSnapshotName, rehydrateCatalogCache, writeCatalogSnapshot } from '../common/catalog-snapshot.ts'

/** Endpoint suffixes on the coding API base. */
export const MODELS_PATH = '/models'
export const USAGES_PATH = '/usages'
export const ME_PATH = '/me'

/** The service reports money in fixed-point units of 1e-6 cents. */
const FIXED_POINT_CENTS = 1_000_000

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function asRecord(value: unknown): Record<string, unknown> | undefined {
  return isRecord(value) ? value : undefined
}

function asString(value: unknown): string | undefined {
  if (typeof value === 'string' && value.trim() !== '') return value
  if (typeof value === 'number' && Number.isFinite(value)) return String(value)
  return undefined
}

/** Accept a number, or a numeric string as the service sometimes sends. */
function asNumber(value: unknown): number | undefined {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim() !== '') {
    const parsed = Number(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return undefined
}

function firstString(record: Record<string, unknown>, keys: readonly string[]): string | undefined {
  for (const key of keys) {
    const value = asString(record[key])
    if (value !== undefined) return value
  }
  return undefined
}

function firstNumber(record: Record<string, unknown>, keys: readonly string[]): number | undefined {
  for (const key of keys) {
    const value = asNumber(record[key])
    if (value !== undefined) return value
  }
  return undefined
}

function clamp01(value: number): number {
  return Math.min(1, Math.max(0, value))
}

/** Parse an ISO string, Unix seconds, or Unix milliseconds into Unix milliseconds. */
export function parseTimestamp(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) {
    return value > 0 && value < 1e11 ? Math.round(value * 1000) : Math.round(value)
  }
  if (typeof value === 'string' && value.trim() !== '') {
    const numeric = Number(value)
    if (Number.isFinite(numeric)) return parseTimestamp(numeric)
    const parsed = Date.parse(value)
    if (Number.isFinite(parsed)) return parsed
  }
  return null
}

function formatAmount(value: number | undefined): string | null {
  if (value === undefined || !Number.isFinite(value)) return null
  return Number.isInteger(value) ? String(value) : value.toFixed(2)
}

function timeoutSignal(signal: AbortSignal | undefined, ms: number): AbortSignal {
  return signal ? AbortSignal.any([signal, timeoutSignalOnly(ms)]) : timeoutSignalOnly(ms)
}

function timeoutSignalOnly(ms: number): AbortSignal {
  return AbortSignal.timeout(ms)
}

/**
 * Headers for a managed coding API request.
 *
 * The OpenAI-compatible surface authenticates with a bearer token. On the
 * Anthropic-compatible surface the Anthropic SDK sends the token as
 * `x-api-key` instead and deliberately omits `authorization`, so both are
 * emitted — the service documents each surface and only reads its own field.
 */
export async function kimiCodeHeaders(
  accessToken: string,
  wire: KimiCodeWire = 'openai',
  extra: Record<string, string> = {},
): Promise<Record<string, string>> {
  // The two surfaces authenticate differently: the Anthropic-compatible one
  // reads `x-api-key`, the OpenAI-compatible one a bearer token.
  const auth: Record<string, string> = wire === 'anthropic'
    ? { 'x-api-key': accessToken, 'anthropic-version': '2023-06-01' }
    : { authorization: `Bearer ${accessToken}` }
  return kimiIdentityHeaders({
    accept: 'application/json',
    ...auth,
    ...extra,
  })
}

/**
 * Headers for one model call.
 *
 * The managed service attributes usage to the installation, so the same
 * \`X-Msh-*\` device identity the account endpoints require is sent here too.
 * The product token stays this plugin's own: the service documents third-party
 * clients against this endpoint, and claiming to be the official CLI is both
 * dishonest and, per its own terms, grounds for suspending the subscription.
 * The cost of that honesty is that a non-whitelisted user agent can be routed to
 * a deprioritized pool, which answers with a transient 429 — the retry policy in
 * the adapter is what absorbs it.
 */
export async function modelRequestHeaders(accessToken: string, wire: KimiCodeWire): Promise<Record<string, string>> {
  const auth: Record<string, string> = wire === 'anthropic'
    ? { 'x-api-key': accessToken, 'anthropic-version': '2023-06-01' }
    : { authorization: `Bearer ${accessToken}` }
  return kimiIdentityHeaders({
    'content-type': 'application/json',
    accept: 'text/event-stream',
    ...auth,
  })
}

/** Test seam: resolve the URL one request goes to. */
export function requestUrl(wire: KimiCodeWire, region: KimiCodeRegion): string {
  return wire === 'anthropic'
    ? anthropicUrl('/v1/messages?beta=true', region)
    : openAIUrl('/chat/completions', region)
}

// ---------------------------------------------------------------------------
// Model catalog
// ---------------------------------------------------------------------------

interface CatalogCache {
  fetchedAt: number
  models: KimiCodeCatalogModel[]
  key: string
  /**
   * Region the listing was fetched for.
   *
   * Kept separately from {@link key} so a token-free caller can match the cache
   * without acquiring a token first.
   */
  region: KimiCodeRegion
}

let catalogCache: CatalogCache | null = null
/**
 * Bumped by every cache clear so a fetch already in flight cannot publish.
 *
 * A stale-while-revalidate refresh answers its caller from cache and keeps
 * fetching. Clearing the cache — a sign-out, a forced refresh, a test starting
 * over — must therefore also silence that refresh: without this it landed
 * afterwards and republished both the in-memory cache and the persisted
 * snapshot it was written to invalidate.
 */
let catalogCacheEpoch = 0
/**
 * Snapshot scopes already consulted in this process.
 *
 * One entry per region rather than a single flag: the persisted file is scoped
 * to the region it was fetched for (see `catalogSnapshotName`), so each region
 * consults its own file once, and a scope that has no snapshot is not re-read on
 * every cache miss.
 */
const catalogSnapshotScopesLoaded = new Set<KimiCodeRegion>()

export function clearCachedCatalog(): void {
  catalogCacheEpoch += 1
  catalogCache = null
  catalogSnapshotScopesLoaded.clear()
  // The remembered credential belongs to the listing being dropped: a forced
  // refresh or a test must not answer from a token the cache no longer holds.
  catalogActiveRegions.clear()
}

export function getCachedCatalog(): KimiCodeCatalogModel[] {
  return catalogCache?.models ?? []
}

/**
 * Read one model entry from the live catalog.
 *
 * The service reports far more than this plugin uses, so only the fields that
 * change a request or the picker are read; an entry with no positive context
 * length is dropped rather than shown as a zero-capacity model.
 */
/** Lifecycle markers the service sets on a model it no longer offers. */
const RETIRED_MODEL_STATUSES = new Set(['deprecated', 'alpha', 'retired'])

/**
 * Read the three-state thinking declaration.
 *
 * Kept separate from the effort list because it can contradict it: a model may
 * ship `valid_efforts` that still contain `none` while `supports_thinking_type`
 * says it can only reason. When both are present the declaration wins, because
 * it is the field the service introduced to replace the older boolean.
 */
function parseThinkingType(record: Record<string, unknown>): KimiCodeThinkingType | undefined {
  const raw = asString(record.supports_thinking_type) ?? asString(record.supportsThinkingType)
  return raw === 'only' || raw === 'no' || raw === 'both' ? raw : undefined
}

function parseCatalogModel(value: unknown): KimiCodeCatalogModel | undefined {
  const record = asRecord(value)
  if (record === undefined) return undefined
  const id = asString(record.id)
  if (id === undefined) return undefined
  // A retired alias is dropped rather than offered: selecting it would fail
  // at request time, and leaving it in the picker hides the model that
  // replaced it.
  const status = asString(record.status)?.toLowerCase()
  if (status !== undefined && RETIRED_MODEL_STATUSES.has(status)) return undefined
  const contextWindow = firstNumber(record, ['context_length', 'contextLength'])
  if (contextWindow === undefined || contextWindow <= 0) return undefined
  const limits = asRecord(record.limit) ?? asRecord(record.limits)
  // The input cap is tracked apart from the window: a model can accept a 1M
  // window while refusing prompts past a lower bound, and budgeting the prompt
  // against the window overshoots into a rejected request rather than a compaction.
  const declaredInput = firstNumber(limits ?? {}, ['input'])
    ?? firstNumber(record, ['max_input_tokens', 'maxInputTokens'])
  const maxInputTokens = declaredInput !== undefined && declaredInput > 0 && declaredInput < contextWindow
    ? declaredInput
    : undefined
  const thinkingType = parseThinkingType(record)

  const efforts = asRecord(record.think_efforts) ?? asRecord(record.thinkEfforts)
  const validEfforts = Array.isArray(efforts?.valid_efforts)
    ? efforts.valid_efforts.filter((entry): entry is string => typeof entry === 'string')
    : Array.isArray(efforts?.validEfforts)
      ? efforts.validEfforts.filter((entry): entry is string => typeof entry === 'string')
      : undefined

  const modalities: Array<'text' | 'image' | 'video'> = ['text']
  if (record.supports_image_in === true || record.supportsImageIn === true) modalities.push('image')
  // The live listing uses the same capability tag the official CLI's model
  // table declares, so a model that gains video acceptance server-side starts
  // working here without a plugin release.
  if (record.supports_video_in === true || record.supportsVideoIn === true) modalities.push('video')

  const protocol = asString(record.protocol)
  return {
    id,
    name: asString(record.display_name) ?? asString(record.displayName) ?? undefined,
    contextWindow,
    ...(validEfforts === undefined || validEfforts.length === 0 ? {} : { reasoningEfforts: validEfforts }),
    ...(asString(efforts?.default_effort ?? efforts?.defaultEffort) === undefined
      ? {}
      : { defaultReasoningEffort: asString(efforts?.default_effort ?? efforts?.defaultEffort) }),
    inputModalities: modalities,
    protocol: protocol === 'anthropic' ? 'anthropic' : 'openai',
    ...(record.supports_video_in === true || record.supportsVideoIn === true ? { supportsVideo: true } : {}),
    ...(maxInputTokens === undefined ? {} : { maxInputTokens }),
    ...(thinkingType === undefined ? {} : { thinkingType }),
    // Three-state like the dynamic-tool flag below: silence is not a denial,
    // and treating it as one would disable tools on a model that still takes
    // them simply because the listing omitted the field.
    ...(typeof (record.supports_tool_use ?? record.supportsToolUse) === 'boolean'
      ? { supportsToolUse: (record.supports_tool_use ?? record.supportsToolUse) as boolean }
      : {}),
    // Three-state on purpose: the listing may assert true, assert false, or say
    // nothing at all. Collapsing false into "absent" would make an explicit
    // denial indistinguishable from silence, and the static fallback would then
    // re-enable a capability the service just turned off.
    ...(typeof (record.supports_dynamic_tools ?? record.supportsDynamicTools) === 'boolean'
      ? { supportsDynamicTools: (record.supports_dynamic_tools ?? record.supportsDynamicTools) as boolean }
      : {}),
  }
}

/**
 * Fetch the models the signed-in subscription can use.
 *
 * The live listing is authoritative — it is what tells the plugin which models
 * the account's tier actually unlocks — so it is cached for half an hour and
 * re-read on demand from the settings card.
 *
 * The cache is consulted BEFORE a token is acquired whenever the caller does not
 * already hold one. That order is load-bearing: acquiring a token reads the
 * credential store, and on Windows that is a DPAPI unprotect through a spawned
 * `powershell.exe` (~200 ms). The harness resolves every model of every
 * provider when it builds the picker's catalog, and each resolution calls in
 * here, so acquiring first turned one catalog into one process launch per
 * model. A caller that passes `accessToken` still keys the cache on the token,
 * because a different account can see a different listing.
 */
export function loadProviderModels(options: {
  fetchFn?: typeof fetch
  store?: FileCredentialStore
  accessToken?: string
  region?: KimiCodeRegion
  signal?: AbortSignal
  force?: boolean
  /**
   * Read the active credential from the account pool.
   *
   * Every refresh rotates the refresh token and invalidates the previous one.
   * The single-credential file is a *copy* of the pool's primary account, so
   * refreshing that copy spends the token the pool will present on the next
   * model request — the account then reads as rejected until a new sign-in.
   * Supplying this keeps the loader on the one credential authority.
   */
  credentialProvider?: (region: KimiCodeRegion) => Promise<string | undefined>
} = {}): Promise<KimiCodeCatalogModel[]> {
  return options.force === true ? refreshProviderModels(options) : cachedOrRevalidate(options)
}

async function cachedOrRevalidate(options: {
  fetchFn?: typeof fetch
  store?: FileCredentialStore
  accessToken?: string
  region?: KimiCodeRegion
  signal?: AbortSignal
  credentialProvider?: (region: KimiCodeRegion) => Promise<string | undefined>
}): Promise<KimiCodeCatalogModel[]> {
  const region = options.region ?? await resolveRegion()
  let accessToken = options.accessToken

  // Serve a warm cache without touching the credential store. Only a caller
  // that already named a token can be keyed precisely; a token-free caller is
  // keyed on the region, which still cannot serve another region's listing.
  if (catalogCache !== null
    && (accessToken === undefined
      ? catalogCache.region === region
      : catalogCache.key === `${region}:${accessToken.slice(-8)}`)
    && Date.now() - catalogCache.fetchedAt < CATALOG_CACHE_TTL_MS) {
    return catalogCache.models
  }

  // Stale-while-revalidate: an expired snapshot answers now and the refresh
  // runs behind it. A rehydrated snapshot is stale by definition, so the same
  // applies on the first call after a restart — the persisted listing is
  // served immediately instead of waiting on the network (and on the
  // credential store a live fetch would need first).
  const warm = catalogCache !== null
    && (accessToken === undefined
      ? catalogCache.region === region
      : catalogCache.key === `${region}:${accessToken.slice(-8)}`)
  if (warm) {
    void refreshProviderModels(options).catch(() => undefined)
    return catalogCache!.models
  }
  if (!catalogSnapshotScopesLoaded.has(region)) {
    catalogSnapshotScopesLoaded.add(region)
    // The snapshot is scoped to the region it was fetched for, and the cache
    // entry it produces is keyed on this caller's own region rather than on a
    // token that was never read. Reading the shared file here is what put one
    // region's models and context windows behind another region's credential:
    // a mainland-cn listing answered a global caller because the snapshot was
    // written and read under one name.
    const rehydratedAt = await rehydrateCatalogCache(
      catalogSnapshotName('kimi-code', region),
      parsePersistedCatalogModels,
      (fetchedAt, models) => {
        catalogCache = { fetchedAt, models, key: `${region}:persisted`, region }
      },
      catalogCache?.fetchedAt ?? 0,
    )
    if (rehydratedAt > 0) {
      void refreshProviderModels({ ...options, region }).catch(() => undefined)
      return catalogCache!.models
    }
  }

  if (accessToken === undefined) {
    if (options.store === undefined) return []
    // A token already held for this region — the pool's active account, read by
    // the caller — is preferred over decrypting the single-credential mirror.
    // Every refresh rotates the refresh token and invalidates the old one, so
    // the mirror must not be refreshed on its own while a pool serves the line:
    // it holds a copy of the same token, and rotating that copy would kill the
    // one the pool will present on the next model request.
    accessToken = catalogAccessToken(region)
    // A pool credential beats the mirror: the mirror is a copy of one pool
    // account, and refreshing it would invalidate the token the pool is about
    // to use.
    if (accessToken === undefined && options.credentialProvider !== undefined) {
      accessToken = await options.credentialProvider(region).catch(() => undefined)
    }
    if (accessToken === undefined && options.credentialProvider === undefined) {
      try {
        accessToken = (await ensureAccessToken(options.store, { fetchFn: options.fetchFn, signal: options.signal })).accessToken
      } catch {
        return []
      }
    }
    if (accessToken === undefined) return []
  }

  const cacheKey = `${region}:${accessToken.slice(-8)}`
  if (catalogCache !== null
    && catalogCache.key === cacheKey
    && Date.now() - catalogCache.fetchedAt < CATALOG_CACHE_TTL_MS) {
    return catalogCache.models
  }
  return refreshProviderModels({ ...options, accessToken, region })
}

/** One in-flight, single-flighted fetch of the live listing. */
function refreshProviderModels(options: {
  fetchFn?: typeof fetch
  store?: FileCredentialStore
  accessToken?: string
  region?: KimiCodeRegion
  signal?: AbortSignal
  credentialProvider?: (region: KimiCodeRegion) => Promise<string | undefined>
}): Promise<KimiCodeCatalogModel[]> {
  return performListing(options)
}

async function performListing(options: {
  fetchFn?: typeof fetch
  store?: FileCredentialStore
  accessToken?: string
  region?: KimiCodeRegion
  signal?: AbortSignal
  credentialProvider?: (region: KimiCodeRegion) => Promise<string | undefined>
}): Promise<KimiCodeCatalogModel[]> {
  const region = options.region ?? await resolveRegion()
  // Sampled before the first await: a clear during this fetch must silence the
  // publish below, exactly like the antigravity quota epoch does.
  const epoch = catalogCacheEpoch
  let accessToken = options.accessToken

  if (accessToken === undefined) {
    if (options.store === undefined) return []
    // Same rule as the cache path: a region token the caller already holds is
    // the credential that will serve the next request, so the mirror is only
    // read when there is none.
    accessToken = catalogAccessToken(region)
    if (accessToken === undefined && options.credentialProvider !== undefined) {
      accessToken = await options.credentialProvider(region).catch(() => undefined)
    }
    if (accessToken === undefined && options.credentialProvider === undefined) {
      try {
        accessToken = (await ensureAccessToken(options.store, { fetchFn: options.fetchFn, signal: options.signal })).accessToken
      } catch {
        return []
      }
    }
    if (accessToken === undefined) return []
  }

  const response = await (options.fetchFn ?? fetch)(openAIUrl(MODELS_PATH, region), {
    headers: await kimiCodeHeaders(accessToken, 'openai'),
    signal: timeoutSignal(options.signal, DISCOVERY_TIMEOUT_MS),
  })
  if (!response.ok) throw new Error(`Kimi Code model listing failed (${response.status}).`)

  const payload: unknown = await response.json().catch(() => undefined)
  const data = Array.isArray(payload) ? payload : asRecord(payload)?.data
  if (!Array.isArray(data)) throw new Error('Kimi Code model listing was not in the documented shape.')

  const models = data.map(parseCatalogModel).filter((model): model is KimiCodeCatalogModel => model !== undefined)
  if (epoch !== catalogCacheEpoch) {
    // A clear landed while this fetch was in flight: answer the caller with the
    // listing it asked for, but publish nothing. Republishing would restore the
    // cache that was just dropped and rewrite the snapshot that clear exists to
    // invalidate.
    return models
  }
  // The listing is cached, not just its models: a later token-free caller for
  // this region can present the same credential instead of decrypting the
  // mirror, which is a second copy of the same rotating refresh token.
  rememberCatalogCredential(region, accessToken)
  catalogCache = { fetchedAt: Date.now(), models, key: cacheKeyOf(region, accessToken), region }
  void writeCatalogSnapshot(catalogSnapshotName('kimi-code', region), models, catalogCache.fetchedAt)
  return models
}

function cacheKeyOf(region: KimiCodeRegion, accessToken: string): string {
  return `${region}:${accessToken.slice(-8)}`
}

/**
 * Region whose active account is already carried by the catalog cache.
 *
 * The settings card reads the card and the catalog with the pool's active
 * credential but calls the loader without one, so without this the loader would
 * fall back to the single-credential mirror — a second copy of the same
 * rotating refresh token. Refreshing that copy invalidates the token the pool
 * will present on the next model request, and the account then reads as
 * rejected until a new sign-in.
 */
const catalogActiveRegions = new Map<KimiCodeRegion, string>()

/**
 * Record which credential the last listing used, so a token-free caller for the
 * same region can reuse it instead of decrypting the mirror.
 */
export function rememberCatalogCredential(region: KimiCodeRegion, accessToken: string): void {
  catalogActiveRegions.set(region, accessToken)
}

/** The token the cache already holds for this region, if any. */
function catalogAccessToken(region: KimiCodeRegion): string | undefined {
  return catalogActiveRegions.get(region)
}

/** Test seam: forget which credential the cached listings were fetched with. */
export function clearCatalogCredentials(): void {
  catalogActiveRegions.clear()
}

/** Shape check for a persisted snapshot.
 *
 * Entries are already in the parsed catalog shape, so they are accepted as
 * they are: routing them through `parseCatalogModel` again would drop every
 * one (that parser reads the raw listing's `context_length`, not the parsed
 * entry's `contextWindow`). Only the identity field is checked.
 */
function parsePersistedCatalogModels(value: unknown): KimiCodeCatalogModel[] | undefined {
  if (!Array.isArray(value)) return undefined
  const models = value.filter((entry): entry is KimiCodeCatalogModel =>
    typeof entry === 'object' && entry !== null
    && typeof (entry as Record<string, unknown>).id === 'string'
    && ((entry as Record<string, unknown>).id as string) !== ''
    && typeof (entry as Record<string, unknown>).contextWindow === 'number'
    && ((entry as Record<string, unknown>).contextWindow as number) > 0)
  return models.length > 0 ? models : undefined
}

/** Choose the wire dialect for one model, from the live catalog when it says. */
export function wireForCatalogEntry(modelId: string, catalog: readonly KimiCodeCatalogModel[]): KimiCodeWire {
  const entry = catalog.find((model) => model.id === modelId)
  if (entry?.protocol === 'anthropic') return 'anthropic'
  return wireForModel(modelId)
}

/**
 * Thinking levels for one model, from the catalog when it declares them.
 *
 * `supports_thinking_type` is applied last because it is the field that can
 * invalidate the effort list itself. A model that declares `only` reasons at
 * every level, so offering `none` asks for a turn the service will reject; a
 * model that declares `no` does not reason at all, so exposing its levels would
 * advertise behaviour it does not have.
 */
export function reasoningEffortsForEntry(modelId: string, catalog: readonly KimiCodeCatalogModel[]): string[] {
  const entry = catalog.find((model) => model.id === modelId)
  const declared = entry?.reasoningEfforts ?? reasoningEffortsFor(modelId)
  // Precedence is the live listing, then the shipped registry: a server that
  // says nothing about thinking must not turn a thinking-only model into a
  // switchable one. Without the static half a cold start — or an offline
  // settings card — offered `none` for an id whose 400 the registry already
  // documents.
  switch (entry?.thinkingType ?? thinkingTypeFor(modelId)) {
    case 'no':
      return []
    case 'only':
      return declared.filter((effort) => effort !== 'none')
    default:
      return [...declared]
  }
}

/**
 * Default thinking level for one model, when the server states one.
 *
 * A declared default that the resolved effort list no longer contains is
 * dropped rather than carried through: with `only` in force the list can lose
 * `none`, and a default naming a level the model can no longer be asked for
 * would fail on the first turn that relied on it.
 */
export function defaultReasoningEffortForEntry(
  modelId: string,
  catalog: readonly KimiCodeCatalogModel[],
): string | undefined {
  const entry = catalog.find((model) => model.id === modelId)
  const declared = entry?.defaultReasoningEffort ?? kimiCodeModelDef(modelId)?.defaultReasoningEffort ?? undefined
  if (declared === undefined) return undefined
  return reasoningEffortsForEntry(modelId, catalog).includes(declared) ? declared : undefined
}

/**
 * Whether one model accepts tool declarations at all.
 *
 * Distinct from {@link dynamicToolsForEntry}, which asks the narrower question
 * of message-level declarations: a model can take tools at the top level and
 * not accept them per message, and collapsing the two would disable tools on a
 * model that still works. Precedence is the live listing, including an
 * explicit false, then the shipped registry.
 */
export function toolUseForEntry(modelId: string, catalog: readonly KimiCodeCatalogModel[]): boolean {
  const entry = catalog.find((model) => model.id === modelId)
  if (entry?.supportsToolUse !== undefined) return entry.supportsToolUse
  return true
}

/**
 * Prompt ceiling for one model, or undefined when it equals the window.
 *
 * The completion budget still uses the full window — the cap bounds what may be
 * sent, not how much may be generated — but a caller sizing a prompt needs the
 * smaller of the two whenever the service states a lower input bound.
 */
export function maxInputTokensForEntry(
  modelId: string,
  catalog: readonly KimiCodeCatalogModel[],
): number | undefined {
  return catalog.find((model) => model.id === modelId)?.maxInputTokens
}

/**
 * Whether one model accepts message-level tool declarations.
 *
 * THE single resolution point for `dynamically_loaded_tools`: the settings card
 * and the request builder must never disagree, because the failure mode is a UI
 * that promises a capability the sent request silently drops. Precedence is the
 * live listing (including an explicit false), then the shipped registry.
 *
 * @param modelId - exact model id.
 * @param catalog - live catalog, possibly empty when offline.
 */
export function dynamicToolsForEntry(
  modelId: string,
  catalog: readonly KimiCodeCatalogModel[],
): boolean {
  const entry = catalog.find((model) => model.id === modelId)
  if (entry?.supportsDynamicTools !== undefined) return entry.supportsDynamicTools
  return kimiCodeModelDef(modelId)?.supportsDynamicTools === true
}

/** Input modalities for one model, from the catalog when it declares them. */
export function inputModalitiesForEntry(modelId: string, catalog: readonly KimiCodeCatalogModel[]): Array<'text' | 'image' | 'video'> {
  const entry = catalog.find((model) => model.id === modelId)
  if (entry?.inputModalities !== undefined) return [...entry.inputModalities]
  return inputModalitiesFor(modelId)
}

/** Build the picker entries the settings card renders. */
export function buildModelOptions(
  catalog: readonly KimiCodeCatalogModel[],
  enabledModelIds: readonly string[],
  contextWindowOverrides: Record<string, number>,
): KimiCodeModelOption[] {
  const enabled = new Set(enabledModelIds)
  return catalog.map((model) => {
    const override = contextWindowOverrides[model.id]
    const contextWindow = typeof override === 'number' && Number.isFinite(override) && override > 0
      ? override
      : model.contextWindow ?? DEFAULT_CONTEXT_WINDOW
    const efforts = reasoningEffortsForEntry(model.id, catalog)
    const defaultEffort = defaultReasoningEffortForEntry(model.id, catalog)
    const thinkingType = model.thinkingType ?? thinkingTypeFor(model.id)
    // The window bounds the completion budget; the input cap, when the service
    // states one, bounds the prompt. A model declaring a lower input limit is
    // reported at that limit so a caller sizes the turn against the number the
    // endpoint will actually accept.
    const declaredInputCap = maxInputTokensForEntry(model.id, catalog)
    const promptBudget = declaredInputCap === undefined ? contextWindow : Math.min(contextWindow, declaredInputCap)
    return {
      id: model.id,
      name: model.name ?? model.id,
      enabled: enabled.has(model.id),
      defaultContextWindow: model.contextWindow ?? DEFAULT_CONTEXT_WINDOW,
      contextWindow,
      ...(declaredInputCap === undefined ? {} : { maxInputTokens: declaredInputCap }),
      // With no separate input cap, the prompt budget IS the window; reporting
      // it keeps the card from showing a blank where a caller needs a number.
      promptBudget,
      defaultMaxTokens: maxOutputTokensFor(model.id, contextWindow),
      ...(efforts.length === 0 ? {} : { reasoningEfforts: [...efforts] }),
      ...(defaultEffort === undefined ? {} : { defaultReasoningEffort: defaultEffort }),
      ...(thinkingType === undefined ? {} : { thinkingType }),
      wire: model.protocol ?? wireForModel(model.id),
      // The live catalog carries capabilities but not the marketing copy, so
      // the static registry fills the gaps rather than the card showing blanks.
      description: model.description ?? kimiCodeModelDef(model.id)?.description ?? null,
      supportsVideo: model.supportsVideo ?? (kimiCodeModelDef(model.id)?.inputModalities.includes('video') ?? false),
      minimumPlan: model.minimumPlan ?? kimiCodeModelDef(model.id)?.minimumPlan ?? null,
      // The live catalog publishes no quota multiplier, so this comes only from
      // the shipped registry and is null for an id the registry has no row for.
      // Guessing 1x for an unknown id would understate a 2x or 3x model on the
      // one page whose purpose is telling the user what actually costs more.
      quotaMultiplier: kimiCodeModelDef(model.id)?.quotaMultiplier ?? null,
      // Resolved through the shared helper so the card cannot drift from what
      // the request builder will actually do with the same catalog.
      supportsDynamicTools: dynamicToolsForEntry(model.id, catalog) && toolUseForEntry(model.id, catalog),
      supportsToolUse: toolUseForEntry(model.id, catalog),
    }
  })
}

// ---------------------------------------------------------------------------
// Quota
// ---------------------------------------------------------------------------

/**
 * How many accounts' snapshots are remembered.
 *
 * Mirrors the bound the ChatGPT line's usage service applies to its own
 * per-account map: room for every account a user is likely to pool, and no way
 * for a long-lived process to accumulate one snapshot per account it has seen.
 */
const QUOTA_ACCOUNT_LIMIT = 20

/** Key of a snapshot whose caller named no account: the single-credential read. */
const UNNAMED_ACCOUNT_KEY = ''

/**
 * One newest snapshot PER ACCOUNT, keyed by the account id the caller stated.
 *
 * Quota follows the account: rotation decides which account spends the next
 * request, so a single slot could only ever describe whichever account was read
 * last. The pool's card draws every account its own reading, so each account
 * keeps its own entry; past the cap the oldest read is evicted.
 *
 * This map is a memory read only. Nothing here fetches — the settings card
 * builds its account list from it, and that must never cost one upstream
 * request per pooled account.
 */
const quotaCache = new Map<string, KimiCodeAccountQuota>()

/**
 * Key of the entry written most recently.
 *
 * The pre-pool card asks "whatever was fetched last"; the last WRITE answers
 * that exactly, where a scan by `fetchedAt` would break a tie between two
 * accounts read inside the same millisecond by map order.
 */
let quotaLastKey = UNNAMED_ACCOUNT_KEY

function quotaCacheKeyFor(accountId?: string | null): string {
  return accountId ?? UNNAMED_ACCOUNT_KEY
}

/** The entry read most recently, whichever account it belongs to. */
function newestQuotaEntry(): KimiCodeAccountQuota | undefined {
  return quotaCache.get(quotaLastKey)
}

/** Remember one account's newest snapshot, bounded to the accounts in use. */
function rememberQuota(accountId: string | undefined, snapshot: KimiCodeAccountQuota): void {
  const key = quotaCacheKeyFor(accountId)
  quotaCache.set(key, snapshot)
  quotaLastKey = key
  while (quotaCache.size > QUOTA_ACCOUNT_LIMIT) {
    const oldest = [...quotaCache.entries()].sort((left, right) => left[1].fetchedAt - right[1].fetchedAt)[0]
    if (oldest === undefined) break
    quotaCache.delete(oldest[0])
    if (quotaLastKey === oldest[0]) quotaLastKey = UNNAMED_ACCOUNT_KEY
  }
}

/**
 * The snapshot read most recently, whichever account it belongs to.
 *
 * Kept for the pre-pool single-credential card, which has no account id to ask
 * with. A pooled caller asks {@link getCachedQuotaFor} instead.
 */
export function getCachedQuota(): KimiCodeAccountQuota | null {
  return newestQuotaEntry() ?? null
}

/**
 * The cached snapshot only when it belongs to this account.
 *
 * Passing no account keeps the pre-pool behavior of returning whatever was
 * fetched last. Passing one answers that account's own newest snapshot, or null
 * when this line has never read it — null is "never read", which is a different
 * statement from a snapshot whose windows are all at zero.
 */
export function getCachedQuotaFor(accountId?: string | null): KimiCodeAccountQuota | null {
  if (accountId === undefined || accountId === null) return newestQuotaEntry() ?? null
  return cachedQuotaFor(accountId)
}

/**
 * The newest snapshot held for one account, for display only.
 *
 * The pool asks here while it builds the account list for the settings card, so
 * this is a pure memory read: it never fetches.
 */
export function cachedQuotaFor(accountId: string): KimiCodeAccountQuota | null {
  return quotaCache.get(accountId) ?? null
}

export function clearCachedQuota(): void {
  quotaCache.clear()
  quotaLastKey = UNNAMED_ACCOUNT_KEY
}

/**
 * Display name and nominal length for each window key the service reports.
 *
 * The keys are the service's own names, and two of them describe different
 * monthly pools: the membership-wide one and the Kimi Code one. They are
 * labelled distinctly because a user who has spent their shared membership
 * quota is blocked even while the Code pool still has room.
 */
const WINDOW_DESCRIPTORS: Record<string, { label: string; minutes: number | null }> = {
  limit_5h: { label: '5-hour', minutes: 300 },
  limit5h: { label: '5-hour', minutes: 300 },
  limit_7d: { label: 'Weekly (7-day)', minutes: 10_080 },
  limit7d: { label: 'Weekly (7-day)', minutes: 10_080 },
  limit_month_total: { label: 'Monthly (membership)', minutes: 43_200 },
  monthTotal: { label: 'Monthly (membership)', minutes: 43_200 },
  limit_month_code: { label: 'Monthly (Kimi Code)', minutes: 43_200 },
  monthCode: { label: 'Monthly (Kimi Code)', minutes: 43_200 },
}

/** Window order for the card: shortest window first. */
const WINDOW_ORDER = [
  'limit_5h', 'limit5h',
  'limit_7d', 'limit7d',
  'limit_month_total', 'monthTotal',
  'limit_month_code', 'monthCode',
] as const

function humanizeWindowKey(key: string): string {
  const spaced = key.replace(/^limit[_-]?/i, '').replace(/([a-z0-9])([A-Z])/g, '$1 $2').replace(/[_-]+/g, ' ').trim()
  return spaced === '' ? key : spaced.charAt(0).toUpperCase() + spaced.slice(1)
}

/** One `{usedRatio, resetAt}` entry into a renderable window. */
function usageWindow(
  id: string,
  record: Record<string, unknown>,
  descriptor: { label: string; minutes: number | null } | undefined,
): KimiCodeUsageWindow | undefined {
  const limit = firstNumber(record, ['limit'])
  const used = firstNumber(record, ['used'])
  const remaining = firstNumber(record, ['remaining'])
  // The service normally reports a ready ratio; the alternative shape reports a
  // used/limit pair instead, so the ratio is derived from it rather than the
  // window being dropped.
  const reported = firstNumber(record, ['used_ratio', 'usedRatio'])
  const usedRatio = reported ?? (limit !== undefined && limit > 0 && used !== undefined ? used / limit : undefined)
  if (usedRatio === undefined || !Number.isFinite(usedRatio)) return undefined
  const usedFraction = clamp01(usedRatio)
  return {
    id,
    label: descriptor?.label ?? humanizeWindowKey(id),
    usedFraction,
    // Kept to two decimals rather than rounded to a whole percent: the card
    // shows what the service stated (88.55%), and rounding here would make a
    // 0.4% change invisible while the website beside it still moved.
    usedPercent: Math.round(usedFraction * 10_000) / 100,
    windowDurationMins: descriptor?.minutes ?? null,
    resetsAt: parseTimestamp(record.reset_time ?? record.resetTime ?? record.resetsAt),
    limit: formatAmount(limit),
    used: formatAmount(used ?? (limit === undefined ? undefined : usedFraction * limit)),
    remaining: formatAmount(remaining ?? (limit === undefined ? undefined : Math.max(0, limit - usedFraction * limit))),
  }
}

/**
 * Read the windowed quota block.
 *
 * The service's own shape nests one entry per window under `usages`; a
 * community-documented alternative reports a top-level `usage` plus a
 * `limits[]` array. Both are read so a service-side change of shape does not
 * silently blank the card, and an unrecognized payload yields no windows rather
 * than a fabricated 0%.
 */
export function parseUsageWindows(payload: unknown): KimiCodeUsageWindow[] {
  const root = asRecord(payload) ?? {}
  const windows: KimiCodeUsageWindow[] = []
  const seen = new Set<string>()

  const push = (id: string, record: Record<string, unknown>, descriptor?: { label: string; minutes: number | null }): void => {
    if (seen.has(id)) return
    const parsed = usageWindow(id, record, descriptor)
    if (parsed === undefined) return
    seen.add(id)
    windows.push(parsed)
  }

  // Official shape: usages.{limit_5h,limit_7d,limit_month_total,limit_month_code}
  const usages = asRecord(root.usages) ?? asRecord(root.usageWindows)
  if (usages !== undefined) {
    const keys = [
      ...WINDOW_ORDER.filter((key) => usages[key] !== undefined),
      ...Object.keys(usages).filter((key) => !(WINDOW_ORDER as readonly string[]).includes(key)),
    ]
    for (const key of keys) {
      const record = asRecord(usages[key])
      if (record === undefined) continue
      push(key, record, WINDOW_DESCRIPTORS[key])
    }
  }

  // Alternative shape: top-level usage (the 7-day pool) plus limits[].
  const topLevel = asRecord(root.usage)
  if (topLevel !== undefined && seen.size === 0) {
    push('limit_7d', topLevel, WINDOW_DESCRIPTORS.limit_7d)
  }
  const limits = Array.isArray(root.limits) ? root.limits : []
  for (const entry of limits) {
    const record = asRecord(entry)
    if (record === undefined) continue
    const detail = asRecord(record.detail) ?? record
    const window = asRecord(record.window)
    const duration = firstNumber(window ?? {}, ['duration'])
    const unit = asString(window?.timeUnit ?? window?.time_unit)
    const minutes = duration === undefined ? null : unit === 'TIME_UNIT_HOUR' ? duration * 60 : duration
    const id = minutes === 300 ? 'limit_5h' : minutes === 10_080 ? 'limit_7d' : firstString(record, ['id', 'name']) ?? `limit-${windows.length + 1}`
    push(id, detail, minutes === null ? undefined : { label: minutes === 300 ? '5-hour' : `${minutes}-minute`, minutes })
  }

  return windows
}

/**
 * Convert the fixed-point money field the service uses into cents.
 *
 * Amounts arrive as 1e-6 cents; a positive amount that would round to zero is
 * reported as one cent, because "you have something left" is closer to the
 * truth than "you have nothing".
 */
export function fixedPointToCents(value: unknown): number | null {
  const raw = asNumber(value)
  if (raw === undefined) return null
  const cents = Math.round(raw / FIXED_POINT_CENTS)
  if (cents === 0 && raw > 0) return 1
  return cents
}

/**
 * Read a money object's `priceInCents` field.
 *
 * Unlike the wallet balance — which is fixed-point 1e-6 cents — this field is
 * already a plain cent amount, so applying the fixed-point divisor here would
 * under-report a charge limit by six orders of magnitude.
 */
function moneyCents(value: unknown): number | null {
  const record = asRecord(value)
  if (record === undefined) return null
  const cents = asNumber(record.priceInCents ?? record.price_in_cents)
  return cents === undefined || !Number.isFinite(cents) ? null : Math.round(cents)
}

function moneyCurrency(value: unknown): string | undefined {
  const record = asRecord(value)
  return record === undefined ? undefined : asString(record.currency)
}

/**
 * Read the booster wallet (the pay-as-you-go top-up pool).
 *
 * The wallet only counts when its balance is a real booster balance; anything
 * else is reported as absent so the card does not advertise credit the account
 * cannot spend.
 */
export function parseExtraUsage(payload: unknown): KimiCodeExtraUsage | null {
  const root = asRecord(payload) ?? {}
  const wallet = asRecord(root.boosterWallet) ?? asRecord(root.booster_wallet) ?? asRecord(root.extraUsage)
  if (wallet === undefined) return null

  const balance = asRecord(wallet.balance)
  const balanceType = asString(balance?.type)
  const amount = asNumber(balance?.amount)
  if (balance === undefined || balanceType !== 'BOOSTER' || amount === undefined || amount <= 0) return null

  const limit = wallet.monthlyChargeLimit ?? wallet.monthly_charge_limit
  const used = wallet.monthlyUsed ?? wallet.monthly_used
  return {
    balanceCents: fixedPointToCents(balance.amountLeft ?? balance.amount_left ?? balance.amount),
    totalCents: fixedPointToCents(balance.amount),
    monthlyChargeLimitEnabled: wallet.monthlyChargeLimitEnabled === true || wallet.monthly_charge_limit_enabled === true,
    monthlyChargeLimitCents: moneyCents(limit),
    monthlyUsedCents: moneyCents(used),
    currency: moneyCurrency(limit) ?? moneyCurrency(used) ?? asString(wallet.currency) ?? 'USD',
  }
}

/**
 * Display name for each machine membership level the service reports.
 *
 * `/usages` used to carry `user_level_name` directly and stopped doing so, so
 * the code is now often the only tier signal available; without this table the
 * card would show a raw enum. Names are the ones Kimi's own pricing page uses.
 */
const MEMBERSHIP_LEVEL_NAMES: Record<string, string> = {
  LEVEL_FREE: 'Adagio',
  LEVEL_BASIC: 'Adagio',
  LEVEL_ANDANTE: 'Andante',
  LEVEL_STANDARD: 'Moderato',
  LEVEL_MODERATO: 'Moderato',
  LEVEL_INTERMEDIATE: 'Allegretto',
  LEVEL_ALLEGRETTO: 'Allegretto',
  LEVEL_ADVANCED: 'Allegro',
  LEVEL_ALLEGRO: 'Allegro',
  LEVEL_PREMIUM: 'Vivace',
  LEVEL_VIVACE: 'Vivace',
}

/** Human name for one machine level code, or the code itself when unknown. */
export function membershipLevelName(level: string | null | undefined): string | null {
  if (level === null || level === undefined || level.trim() === '') return null
  const key = level.trim().toUpperCase()
  return MEMBERSHIP_LEVEL_NAMES[key] ?? level
}

/**
 * Subscription tier the payload names, from any documented shape.
 *
 * Prefers the display name when the service still sends one, then the machine
 * level (mapped to its marketing name), so a payload that dropped
 * `user_level_name` still yields a readable tier instead of a raw enum.
 */
export function parsePlanName(payload: unknown): string | null {
  const root = asRecord(payload) ?? {}
  const direct = firstString(root, ['user_level_name', 'userLevelName', 'planName', 'plan_name'])
  if (direct !== undefined) return direct
  const user = asRecord(root.user)
  const membership = asRecord(user?.membership)
  const named = asString(membership?.level_name ?? membership?.levelName)
  if (named !== undefined) return named
  return membershipLevelName(asString(membership?.level) ?? null)
}

/** Machine tier level when the service reports one. */
export function parsePlanLevel(payload: unknown): string | null {
  const root = asRecord(payload) ?? {}
  const direct = firstNumber(root, ['user_level', 'userLevel'])
  if (direct !== undefined) return String(direct)
  const user = asRecord(root.user)
  const membership = asRecord(user?.membership)
  return asString(membership?.level ?? membership?.levelId ?? membership?.level_id) ?? null
}

/**
 * Field names the service uses for the account's own name.
 *
 * `/me` documents a nickname; the platform also echoes a display name, and a
 * gateway envelope adds nothing but depth. All of them are the same fact: what
 * to title the account's card with, and what a `账号 N` placeholder should
 * become.
 */
const PROFILE_NAME_KEYS = [
  'nickname',
  'name',
  'username',
  'display_name',
  'displayName',
  'preferred_username',
] as const

/**
 * Every record a profile payload may keep the identity in, outermost first.
 *
 * The endpoint has answered flat (`{ nickname, email, ... }`) and nested
 * (`{ data: { userInfo: { ... } } }`) on different gateway versions, and a
 * nested envelope may hold credentials-adjacent siblings at the top level too,
 * so the search never commits to one shape: each container is tried in turn and
 * the first one that names a field wins.
 */
function profileRecords(payload: unknown): Array<Record<string, unknown>> {
  const root = asRecord(payload)
  if (root === undefined) return []
  const data = asRecord(root.data)
  const containers = [
    root,
    data,
    asRecord(root.userInfo) ?? asRecord(data?.userInfo),
    asRecord(root.user) ?? asRecord(data?.user),
  ]
  return containers.filter((record): record is Record<string, unknown> => record !== undefined)
}

/** First value among `keys` found in any profile container, outermost first. */
function profileString(payload: unknown, keys: readonly string[]): string | undefined {
  for (const record of profileRecords(payload)) {
    const found = firstString(record, keys)
    if (found !== undefined) return found
  }
  return undefined
}

/**
 * Turn a `/me` payload into the public account DTO.
 *
 * The endpoint answers with snake_case fields while the card consumes
 * camelCase, and either profile source may be the one that answered, so both
 * spellings are accepted.
 */
export function parseUserInfo(payload: unknown, fallback: Partial<KimiCodeAccount> = {}): KimiCodeAccount {
  return {
    userId: profileString(payload, ['user_id', 'userId', 'global_id', 'globalId']) ?? fallback.userId ?? null,
    nickname: profileString(payload, PROFILE_NAME_KEYS) ?? fallback.nickname ?? null,
    email: profileString(payload, ['email']) ?? fallback.email ?? null,
    planName: parsePlanName(payload) ?? fallback.planName ?? null,
    planLevel: parsePlanLevel(payload) ?? fallback.planLevel ?? null,
    region: (profileString(payload, ['region']) as KimiCodeRegion | undefined) ?? fallback.region ?? null,
    authenticatedAt: fallback.authenticatedAt ?? null,
  }
}

/**
 * Fold the facts a `/me` read established into a credential.
 *
 * Sign-in only names the account through its token, which carries an id and —
 * for an account with a mailbox — an address. The nickname lives on `/me` and
 * nowhere else, so the caller reads it once and stores it here; without this,
 * a phone-signed-in account could never be called anything but `账号 N`.
 *
 * Only fields the profile actually names are written: a gateway that drops the
 * nickname must not blank one learned earlier, and the token pair is copied
 * through untouched. Returns the same object when nothing new was learned, so a
 * caller can tell "nothing to store" from "store this".
 */
export function credentialsWithProfile(
  credentials: KimiCodeCredentials,
  profile: unknown,
): KimiCodeCredentials {
  const nickname = profileString(profile, PROFILE_NAME_KEYS)
  const email = profileString(profile, ['email'])?.toLowerCase()
  const userId = profileString(profile, ['user_id', 'userId', 'global_id', 'globalId'])
  const planName = parsePlanName(profile) ?? undefined
  const next: KimiCodeCredentials = { ...credentials }
  let changed = false
  if (nickname !== undefined && next.nickname !== nickname) {
    next.nickname = nickname
    changed = true
  }
  if (email !== undefined && next.email !== email) {
    next.email = email
    changed = true
  }
  if (userId !== undefined && next.userId !== userId) {
    next.userId = userId
    changed = true
  }
  if (planName !== undefined && next.planName !== planName) {
    next.planName = planName
    changed = true
  }
  return changed ? next : credentials
}

export interface QuotaFetchOptions {
  fetchFn?: typeof fetch
  signal?: AbortSignal
  /** Bypass the local cache and read the service again. */
  force?: boolean
  /**
   * Credentials to read usage for.
   *
   * A pool supplies the active account's credential here; without it the single
   * stored account is refreshed and used.
   */
  credentials?: KimiCodeCredentials
  /**
   * Account the snapshot belongs to.
   *
   * With a pool the card must never render one account's quota under another
   * account's name, so each account keeps its own cache entry, keyed by this id.
   * Omitted, the reading is filed under the single-credential slot.
   */
  accountId?: string
  /**
   * Refresh this credential and hand back the replacement, or undefined when
   * the caller has no way to renew it.
   *
   * A usage call that answers 401 is the only signal that an access token
   * stopped being accepted; rotation bookkeeping cannot see it, because the
   * token still looks unexpired locally. The caller that owns the credential —
   * the pool — supplies the write-back here, so the one retry happens where the
   * rotated refresh token can actually be persisted.
   */
  renewFn?: (credentials: KimiCodeCredentials) => Promise<KimiCodeCredentials | undefined>
  /**
   * Called with the account this reading describes, once it has been assembled.
   *
   * A pool owns the account rows, so it is the pool that persists what `/me`
   * taught: the nickname, the address, the tier — and, for a row still titled
   * with the placeholder minted at sign-in, the name the card should carry.
   * This runs on the pooled path too, where the credential write-back below is
   * deliberately skipped because the pool, not this function, owns that file.
   */
  onAccount?: (account: KimiCodeAccount, credentials: KimiCodeCredentials) => void | Promise<void>
}

/**
 * Fetch and cache the account's quota snapshot.
 *
 * A 401 is surfaced as a rejection so the caller can invalidate the stored
 * credential; every other failure leaves the previous snapshot in place rather
 * than blanking the card, because a transient outage says nothing about the
 * account's real usage.
 */
export async function fetchAccountQuota(
  store: FileCredentialStore,
  options: QuotaFetchOptions = {},
): Promise<KimiCodeAccountQuota | null> {
  // The TTL belongs to ONE account: this account's snapshot is served only
  // while warm, and a fresh reading of a different account never answers here.
  const cached = quotaCache.get(quotaCacheKeyFor(options.accountId))
  if (options.force !== true && cached !== undefined && Date.now() - cached.fetchedAt < QUOTA_CACHE_TTL_MS) {
    return cached
  }

  const fetchFn = options.fetchFn ?? fetch
  // Pooled callers pass the active account's credential: the pool owns refresh
  // and write-back, so this path must not touch the single-credential file.
  const pooled = options.credentials !== undefined
  let credentials: KimiCodeCredentials
  try {
    credentials = options.credentials ?? await ensureAccessToken(store, { fetchFn, signal: options.signal })
  } catch (error) {
    throw error
  }

  const requestUsage = async (credentials: KimiCodeCredentials): Promise<Response> =>
    fetchFn(openAIUrl(USAGES_PATH, credentials.region), {
      headers: await kimiCodeHeaders(credentials.accessToken, 'openai'),
      signal: timeoutSignal(options.signal, DISCOVERY_TIMEOUT_MS),
    })

  let response = await requestUsage(credentials)

  if (response.status === 401) {
    // A 401 is not automatically a dead account: an access token can be
    // revoked upstream, or read back stale by a process that refreshed it.
    // One forced renewal decides between the two, and only a second 401 means
    // the credential itself is gone.
    const renewed = await forceRenew(store, credentials, options, fetchFn)
    if (renewed !== undefined) {
      credentials = renewed
      response = await requestUsage(credentials)
    }
  }

  if (response.status === 401) {
    // A rejected credential must be distinguishable from a transient outage:
    // callers surface the first and retry the second, so it carries the same
    // typed error the token layer uses.
    throw new KimiCodeUnauthorizedError(
      'Kimi Code rejected the stored credential (401). Sign in again from Settings > Kimi Code.',
    )
  }
  if (response.status === 404) {
    throw new Error('The Kimi Code usage endpoint is unavailable for this account. Confirm the subscription is active.')
  }
  if (!response.ok) {
    throw new Error(`Kimi Code usage request failed (${response.status}).`)
  }

  const payload: unknown = await response.json().catch(() => undefined)

  // `/usages` no longer names the plan, so `/me` supplies it; both are folded
  // in and whatever is learned is written back for the status fallback to read.
  const profile = await fetchProfile(store, {
    fetchFn,
    signal: options.signal,
    // The credential the usage call finally succeeded with, so a renewal made
    // above is not immediately undone by asking with the refused token.
    ...(options.credentials === undefined ? {} : { credentials }),
  })
  const account = accountFromCredentials(credentials, payload, profile ?? undefined)
  const learned: Partial<KimiCodeCredentials> = {}
  if (account.planName !== null && account.planName !== credentials.planName) learned.planName = account.planName
  if (account.nickname !== null && account.nickname !== credentials.nickname) learned.nickname = account.nickname
  // Only the single-account path writes back: with a pool the account record is
  // the pool's to update, and the mirror belongs to whichever account is primary.
  if (!pooled && Object.keys(learned).length > 0) {
    void store.write({ ...credentials, ...learned }).catch(() => undefined)
  }
  // The same facts, handed to whoever owns the credential: for a pool that is
  // the row's owner, which is where a name learned here becomes the card title.
  if (options.onAccount !== undefined) {
    try {
      await options.onAccount(account, credentials)
    } catch {
      // Learning who the account is must never cost the quota reading it came
      // with; the row keeps its previous name until the next read.
    }
  }

  const snapshot: KimiCodeAccountQuota = {
    account,
    planName: account.planName,
    windows: parseUsageWindows(payload),
    extraUsage: parseExtraUsage(payload),
    fetchedAt: Date.now(),
    sources: [openAIUrl(USAGES_PATH, credentials.region)],
  }
  rememberQuota(options.accountId, snapshot)
  return snapshot
}

/**
 * Renew an access token once after the usage endpoint refused it.
 *
 * A pool supplies {@link QuotaFetchOptions.renewFn}, because only the pool can
 * persist the rotated refresh token. Without one the single-credential store
 * renews itself — but only when it still holds the very token that was refused:
 * a store already carrying a different pair was rotated by someone else, and
 * refreshing it again would spend a token the upstream has not rejected.
 */
async function forceRenew(
  store: FileCredentialStore,
  refused: KimiCodeCredentials,
  options: QuotaFetchOptions,
  fetchFn: typeof fetch,
): Promise<KimiCodeCredentials | undefined> {
  if (options.renewFn !== undefined) {
    try {
      return await options.renewFn(refused)
    } catch {
      return undefined
    }
  }
  if (options.credentials !== undefined) return undefined
  const stored = await store.read().catch(() => null)
  if (stored === null || stored.refreshToken !== refused.refreshToken) return undefined
  try {
    return await ensureAccessToken(store, { fetchFn, signal: options.signal, force: true })
  } catch {
    return undefined
  }
}

/**
 * Build the account view for one credential.
 *
 * There is no account-profile endpoint on the coding API: the signed-in
 * identity lives in the token's own claims, so the account is assembled from
 * the stored credential (which the login and every refresh keep populated) and
 * enriched by whatever the usage payload reports about the tier.
 */
export function accountFromCredentials(
  credentials: KimiCodeCredentials,
  payload?: unknown,
  profile?: unknown,
): KimiCodeAccount {
  const identity = identityFromTokens(credentials.accessToken, credentials.refreshToken)
  // The tier is read from whichever source has it: `/me` is authoritative for
  // the plan (and is now the only place that names it), while `/usages` may
  // still carry the code.
  const planName = (profile === undefined ? null : parsePlanName(profile))
    ?? (payload === undefined ? null : parsePlanName(payload))
    ?? credentials.planName
    ?? null
  const planLevel = (profile === undefined ? null : parsePlanLevel(profile))
    ?? (payload === undefined ? null : parsePlanLevel(payload))
  return {
    userId: credentials.userId ?? identity.userId ?? null,
    // The profile is the only place the nickname exists at all (the token
    // carries an id, not a name), and it may wrap the record in an envelope.
    nickname: (profile === undefined ? undefined : profileString(profile, PROFILE_NAME_KEYS))
      ?? credentials.nickname
      ?? null,
    // A claim decoded from the live token outranks the stored copy, so a
    // credential written before the claims were read still shows the account.
    // The profile is the last resort: a phone-signed-in account has no address
    // in its token at all, and `/me` is the only place that names one.
    email: credentials.email
      ?? identity.email
      ?? (profile === undefined ? undefined : profileString(profile, ['email'])?.toLowerCase())
      ?? null,
    planName,
    planLevel,
    region: credentials.region,
    authenticatedAt: credentials.authenticatedAt ?? null,
  }
}

/**
 * Read the plan profile from `/me`.
 *
 * The endpoint exists and is the only remaining source of the plan's display
 * name: `/usages` used to carry `user_level_name` and stopped. It is called
 * with the OAuth access token only (never a pasted plan key) and is treated as
 * enrichment — a failure returns null so the card still renders the identity it
 * already has from the token.
 */
export async function fetchProfile(
  store: FileCredentialStore,
  options: QuotaFetchOptions = {},
): Promise<unknown | null> {
  const fetchFn = options.fetchFn ?? fetch
  let credentials: KimiCodeCredentials
  try {
    credentials = options.credentials ?? await ensureAccessToken(store, { fetchFn, signal: options.signal })
  } catch {
    return null
  }
  try {
    const response = await fetchFn(openAIUrl(ME_PATH, credentials.region), {
      headers: await kimiCodeHeaders(credentials.accessToken, 'openai'),
      signal: timeoutSignal(options.signal, DISCOVERY_TIMEOUT_MS),
    })
    if (!response.ok) return null
    return await response.json().catch(() => null)
  } catch {
    // A profile is enrichment; a network failure must not fail the card.
    return null
  }
}

/**
 * Read the account identity for a stored credential.
 *
 * Combines the token's own claims (the identity) with `/me` (the plan name) and
 * persists what it learns, so a later call needs no network work. It never
 * throws for a missing profile: the identity is derived locally.
 */
export async function fetchUserInfo(
  store: FileCredentialStore,
  options: QuotaFetchOptions = {},
): Promise<KimiCodeAccount | null> {
  const credentials = await store.read()
  if (credentials === null) return null
  const profile = await fetchProfile(store, options)
  const account = accountFromCredentials(credentials, undefined, profile)
  // Persist anything new (identity claims, the plan name) so the next status
  // call can render without asking the service again.
  const learned: Partial<KimiCodeCredentials> = {}
  if (credentials.userId === undefined && account.userId !== null) learned.userId = account.userId
  if (credentials.email === undefined && account.email !== null) learned.email = account.email
  if (credentials.nickname === undefined && account.nickname !== null) learned.nickname = account.nickname
  if (account.planName !== null && account.planName !== credentials.planName) learned.planName = account.planName
  if (Object.keys(learned).length > 0) {
    try {
      await store.write({ ...credentials, ...learned })
    } catch {
      // A read-only store must not break the card; the value is still returned.
    }
  }
  return account
}

/**
 * Prove the stored credential still authenticates, and report how long that took.
 *
 * The probe is the real usage call rather than a profile lookup, because there
 * is no profile endpoint: a 200 from `/usages` is what shows the token is
 * accepted, and it doubles as a quota refresh for the card.
 */
export async function testConnection(
  store: FileCredentialStore,
  options: QuotaFetchOptions = {},
): Promise<{ account: KimiCodeAccount | null; latencyMs: number }> {
  const startedAt = Date.now()
  try {
    const quota = await fetchAccountQuota(store, { ...options, force: true })
    return { account: quota?.account ?? null, latencyMs: Date.now() - startedAt }
  } catch (error) {
    // A rejected credential is the failure worth surfacing; a transient outage
    // is reported as "not connected" without failing the whole request.
    if (error instanceof KimiCodeUnauthorizedError) throw error
    const credentials = await store.read()
    return {
      account: credentials === null ? null : accountFromCredentials(credentials),
      latencyMs: Date.now() - startedAt,
    }
  }
}

export { PROVIDER_NAME }
