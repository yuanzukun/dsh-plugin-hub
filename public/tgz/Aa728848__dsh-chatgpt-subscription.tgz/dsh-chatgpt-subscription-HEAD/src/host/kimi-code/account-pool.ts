import path from 'node:path'
import { dshHomeDir } from '../common/home.ts'
import {
  AccountPoolCore,
  normalizeRotationStrategy,
  type AccountPoolHooks,
  type PoolAccountShape,
  type PoolData,
} from '../common/account-pool.ts'
import type { CredentialStore } from '../token-store.ts'
import {
  FileCredentialStore,
  parseKimiCodeCredentials,
  type KimiCodeCredentials,
} from './token-store.ts'
import { KimiCodeUnauthorizedError, isRefreshTokenRejected, refreshAccessToken, refreshThresholdMs } from './oauth.ts'
import { PROVIDER_ID } from './types.ts'
import { cachedQuotaFor } from './client.ts'
import { poolQuota, quotaWindow } from '../common/account-quota.ts'
import type { PoolAccountQuotaDto } from '../../shared/account-pool-contracts.ts'
import type {
  KimiCodeAccount,
  KimiCodeAccountQuota,
  KimiCodeAccountSummaryDto,
  KimiCodeRegion,
} from '../../shared/kimi-code-contracts.ts'

/** One pooled Kimi Code account: the token pair plus the facts the card renders. */
export interface KimiCodePoolAccount extends PoolAccountShape<KimiCodeCredentials> {
  email?: string
  nickname?: string
  userId?: string
  planName?: string
  region?: KimiCodeRegion
}

/** Encrypted pool file this line owns; the pre-pool credential file stays the mirror. */
export function kimiCodePoolPath(): string {
  return path.join(dshHomeDir(), 'storages', 'kimi-code-pool.json')
}

/**
 * Aliases that name nobody: the placeholder this pool mints at sign-in.
 *
 * `defaultAlias` writes `账号 N` when the credential carried neither an address
 * nor a name (a phone-signed-in account carries neither), and the legacy
 * single-credential mirror wrote `主账号`. Both mean "no name learned yet", so
 * both may be upgraded once the profile reports one — while anything else is a
 * name someone chose or an address already on the card, and stays put.
 */
const PLACEHOLDER_ALIAS = /^(?:账号|帐号|account)\s*\d*$|^主账号$|^primary$/i

/**
 * Whether an alias is still the placeholder a sign-in mints, rather than a name
 * somebody recognises.
 *
 * Exported because the routes decide whether one more profile read is worth it:
 * a row still titled `账号 N` is exactly the row whose name nobody has learned.
 */
export function isPlaceholderAlias(alias: string): boolean {
  return PLACEHOLDER_ALIAS.test(alias.trim())
}

/** A field worth storing, or undefined when the service left it blank. */
function learnedField(value: string | null | undefined): string | undefined {
  const text = (value ?? '').trim()
  return text === '' ? undefined : text
}

/**
 * The alias one sign-in should leave the row with.
 *
 * A fresh sign-in computes one from the credential it just produced, and that is
 * the truth when it names something (an address, or a nickname in the token). It
 * names nothing for a phone account, though, while the row may already carry the
 * nickname a profile read learned or a title the user typed — dropping those
 * back to `账号 N` on a re-sign-in would undo both. So a minted placeholder only
 * beats another placeholder; anything that names somebody is kept.
 */
function aliasForSignIn(minted: string, previous: string | undefined): string {
  if (!isPlaceholderAlias(minted)) return minted
  if (previous !== undefined && !isPlaceholderAlias(previous)) return previous
  return minted
}

function optionalString(record: Record<string, unknown>, key: string): string | undefined {
  const value = record[key]
  if (value === undefined || value === null) return undefined
  if (typeof value !== 'string') throw new Error('Kimi Code pool account field is invalid')
  return value
}

/** Validate and normalize one whole pool document. */
export function parseKimiCodePoolData(value: unknown): PoolData<KimiCodePoolAccount> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('Kimi Code pool payload is invalid')
  }
  const record = value as Record<string, unknown>
  const accounts: KimiCodePoolAccount[] = []
  for (const item of Array.isArray(record.accounts) ? record.accounts : []) {
    if (typeof item !== 'object' || item === null) continue
    const raw = item as Record<string, unknown>
    if (typeof raw.id !== 'string') continue
    const credentials = parseKimiCodeCredentials(raw.credentials)
    const account: KimiCodePoolAccount = {
      id: raw.id,
      alias: typeof raw.alias === 'string' ? raw.alias : (credentials.email || credentials.nickname || '账号'),
      credentials,
      addedAt: typeof raw.addedAt === 'number' ? raw.addedAt : Date.now(),
      isPrimary: raw.isPrimary === true,
    }
    for (const key of ['email', 'nickname', 'userId', 'planName'] as const) {
      const parsed = optionalString(raw, key)
      if (parsed !== undefined) account[key] = parsed
    }
    if (raw.region === 'mainland-cn' || raw.region === 'global') account.region = raw.region
    if (account.email === undefined && credentials.email !== undefined) account.email = credentials.email
    if (account.userId === undefined && credentials.userId !== undefined) account.userId = credentials.userId
    if (account.region === undefined) account.region = credentials.region
    if (typeof raw.lastUsedAt === 'number') account.lastUsedAt = raw.lastUsedAt
    if (typeof raw.cooldownUntil === 'number') account.cooldownUntil = raw.cooldownUntil
    if (typeof raw.cooldownReason === 'string') account.cooldownReason = raw.cooldownReason
    if (raw.authStatus === 'expired' || raw.authStatus === 'invalid') account.authStatus = raw.authStatus
    if (typeof raw.authFailedReason === 'string') account.authFailedReason = raw.authFailedReason
    accounts.push(account)
  }
  const result: PoolData<KimiCodePoolAccount> = {
    version: 1,
    rotationStrategy: normalizeRotationStrategy(record.rotationStrategy),
    accounts,
  }
  if (typeof record.activeAccountId === 'string') result.activeAccountId = record.activeAccountId
  return result
}

export interface KimiCodeAccountPoolOptions {
  /** Pre-pool credential file the pool mirrors its primary account into. */
  store?: FileCredentialStore
  /** Test seam; production builds the platform backend from the pool path. */
  backend?: CredentialStore<PoolData<KimiCodePoolAccount>>
  /** Accounts this pool accepts; defaults to the core's limit. */
  maxAccounts?: number
}

/**
 * One account's own newest quota snapshot, in the shape the account card draws.
 *
 * The snapshot comes from 'client.ts''s per-account cache keyed by the pool
 * account id, and this is where this line's own numbers are translated into the
 * shared shape. Every judgement below trades a possibly-nice-looking bar for an
 * honest one:
 *
 * - a window whose consumed share nobody measured is DROPPED (`quotaWindow`
 *   returns null), because "0% used" and "not stated" are different claims. This
 *   parser only mints a window once it has a ratio, so a window that states none
 *   never reaches here at all — the drop is the second line of defence;
 * - `resetsAt` is already Unix MILLISECONDS on this line, so it is passed
 *   through and normalized rather than multiplied;
 * - the read time is the snapshot's own `fetchedAt`, which this line always
 *   sets. A snapshot with no read time is not a snapshot, and `poolQuota`
 *   reports that as undefined.
 *
 * A null snapshot means "this account was never read", which the card renders as
 * exactly that instead of drawing a zero.
 */
export function kimiCodePoolQuota(snapshot: KimiCodeAccountQuota | null): PoolAccountQuotaDto | undefined {
  if (snapshot === null) return undefined
  return poolQuota(snapshot.fetchedAt, snapshot.windows.map((window) => quotaWindow(
    window.label,
    window.usedPercent,
    { windowDurationMins: window.windowDurationMins, resetsAt: window.resetsAt },
  )))
}

/**
 * Kimi Code's account pool.
 *
 * The credential is an OAuth pair whose refresh token rotates, so the pool owns
 * both the refresh and the write-back: two accounts must never be refreshed
 * through the same single-credential file.
 */
export class KimiCodeAccountPool extends AccountPoolCore<
  KimiCodeCredentials,
  KimiCodePoolAccount,
  KimiCodeAccountSummaryDto
> {
  private readonly store: FileCredentialStore

  constructor(options: KimiCodeAccountPoolOptions = {}) {
    const store = options.store ?? new FileCredentialStore()
    const hooks: AccountPoolHooks<KimiCodeCredentials, KimiCodePoolAccount, KimiCodeAccountSummaryDto> = {
      providerId: PROVIDER_ID,
      displayName: 'Kimi Code',
      poolFile: kimiCodePoolPath(),
      keychainService: 'dsh-kimi-code-pool',
      parsePoolData: parseKimiCodePoolData,
      // Identity, never a token: the refresh token rotates, so keying on it
      // would make the same account look new after every refresh.
      dedupeKey: (credentials) => credentials.userId ?? credentials.email,
      defaultAlias: (credentials, position) => credentials.email
        ?? credentials.nickname
        ?? `账号 ${position}`,
      createAccount: ({ id, alias, credentials, addedAt, isPrimary, existing }) => ({
        id,
        // A re-sign-in mints the alias from the credential handed in, and that
        // credential is as nameless as the first one for a phone account — so
        // without this, signing in again would throw the learned name away and
        // put `账号 N` back. The row's existing title wins over a placeholder.
        alias: aliasForSignIn(alias, existing?.alias),
        credentials,
        addedAt,
        isPrimary,
        ...(credentials.email === undefined ? {} : { email: credentials.email }),
        ...(credentials.nickname === undefined ? {} : { nickname: credentials.nickname }),
        ...(credentials.userId === undefined ? {} : { userId: credentials.userId }),
        ...(credentials.planName === undefined ? {} : { planName: credentials.planName }),
        ...(credentials.region === undefined ? {} : { region: credentials.region }),
      }),
      expiresAt: (credentials) => credentials.expiresAt,
      needsRefresh: (credentials, now) => credentials.expiresAt - now <= refreshThresholdMs(credentials.expiresIn),
      refresh: async (credentials, fetchFn) => {
        // The refresh targets this account's own OAuth host and region, and the
        // rotated pair replaces only the token fields: an account from one region
        // must not silently become an account of another.
        const token = await refreshAccessToken(credentials.refreshToken, {
          fetchFn,
          host: credentials.oauthHost,
          region: credentials.region,
        })
        return {
          ...credentials,
          accessToken: token.accessToken,
          refreshToken: token.refreshToken,
          expiresAt: token.expiresAt,
          expiresIn: token.expiresIn,
          scope: token.scope,
          tokenType: token.tokenType,
        }
      },
      // A refresh the service calls final takes that account out of rotation;
      // a transient refresh failure leaves it in place.
      refreshFailureStatus: (error) => (error instanceof KimiCodeUnauthorizedError ? 'expired' : undefined),
      // Pure check: the rejection is recorded by the token layer, and the pool
      // only stops routing to the account it belongs to.
      authRejectedReason: (credentials) => (isRefreshTokenRejected(credentials.refreshToken)
        ? 'Kimi Code 已拒绝该账号的刷新令牌，需要重新登录。'
        : undefined),
      legacyAccount: async () => {
        const stored = await store.read()
        if (stored === null) return null
        return {
          id: 'acc_primary',
          alias: stored.email || stored.nickname || '主账号',
          credentials: stored,
          addedAt: Date.now(),
          isPrimary: true,
          ...(stored.email === undefined ? {} : { email: stored.email }),
          ...(stored.nickname === undefined ? {} : { nickname: stored.nickname }),
          ...(stored.userId === undefined ? {} : { userId: stored.userId }),
          ...(stored.planName === undefined ? {} : { planName: stored.planName }),
          ...(stored.region === undefined ? {} : { region: stored.region }),
        }
      },
      mirrorPrimary: async (credentials) => {
        if (credentials === null) {
          await store.delete()
          return
        }
        await store.write(credentials)
      },
      extendSummary: (account, base) => {
        const email = account.email ?? account.credentials.email
        const nickname = account.nickname ?? account.credentials.nickname
        const planName = account.planName ?? account.credentials.planName
        const region = account.region ?? account.credentials.region
        // The account's own newest snapshot, taken from the identity THIS row
        // carries. Quota follows the account, so the row draws its own reading;
        // absent means that account was never read, which is not "nothing used".
        const quota = kimiCodePoolQuota(cachedQuotaFor(account.id))
        return {
          ...base,
          ...(email === undefined ? {} : { email }),
          ...(nickname === undefined ? {} : { nickname }),
          ...(planName === undefined ? {} : { planName, planLabel: planName }),
          ...(region === undefined ? {} : { region }),
          ...(account.userId === undefined ? {} : { userId: account.userId }),
          ...(quota === undefined ? {} : { quota }),
        }
      },
      // Keeps the wording the adapter's missing-credential error used before the
      // pool existed, so existing diagnostics still match.
      emptyMessage: 'Not signed in to Kimi Code. Sign in from Settings > Kimi Code.',
      ...(options.backend === undefined ? {} : { backend: options.backend }),
      ...(options.maxAccounts === undefined ? {} : { maxAccounts: options.maxAccounts }),
    }
    super(hooks)
    this.store = store
  }

  /**
   * Pick the account for the next request.
   *
   * The returned credential carries its own region, OAuth host and base URL, so
   * the caller must use those rather than the process-wide defaults.
   */
  async getEffectiveCredential(
    excludeIds?: ReadonlySet<string>,
    fetchFn: typeof fetch = fetch,
  ): Promise<{ account: KimiCodePoolAccount; credentials: KimiCodeCredentials }> {
    return this.getEffectiveAccount(excludeIds, fetchFn)
  }

  /** The pre-pool credential file this pool mirrors its primary account into. */
  mirrorStore(): FileCredentialStore {
    return this.store
  }

  /**
   * Remember who the service says one pooled account is.
   *
   * Sign-in can only name an account through its token, which carries an id and
   * — for an account with a mailbox — an address. That is why a phone-signed-in
   * row is titled `账号 N` and never changes on its own: the nickname lives on
   * `/me`, which only the quota read asks, and nothing used to carry the answer
   * back to the row. Every reading now calls this with what the profile said, so
   * the card can name its own account without a re-sign-in.
   *
   * Only the placeholder yields: a name someone chose stays, because silently
   * renaming a row a user named is worse than leaving a default in place. The
   * learned facts also go into the mirrored credential, so a later re-sign-in
   * (which mints the alias from the credential) keeps the name, and so do the
   * single-account fallbacks that read that copy.
   */
  async learnAccount(accountId: string, account: KimiCodeAccount): Promise<void> {
    const nickname = learnedField(account.nickname)
    const email = learnedField(account.email)?.toLowerCase()
    const userId = learnedField(account.userId)
    const planName = learnedField(account.planName)
    if (nickname === undefined && email === undefined && userId === undefined && planName === undefined) {
      return
    }
    await this.updatePool((data) => {
      const target = data.accounts.find((entry) => entry.id === accountId)
      if (target === undefined) return
      if (nickname !== undefined) target.nickname = nickname
      if (email !== undefined) target.email = email
      if (userId !== undefined) target.userId = userId
      if (planName !== undefined) target.planName = planName
      // The credential is the pool's own copy of the identity, and the next
      // sign-in mints the alias from it: keep the two in step rather than
      // storing the name only on the row. Token fields are copied through.
      const next = { ...target.credentials }
      if (nickname !== undefined) next.nickname = nickname
      if (email !== undefined) next.email = email
      if (userId !== undefined) next.userId = userId
      if (planName !== undefined) next.planName = planName
      target.credentials = next
      if (isPlaceholderAlias(target.alias)) {
        const name = nickname ?? email
        if (name !== undefined) target.alias = name
      }
    })
  }
}
