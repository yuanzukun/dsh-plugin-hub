import { spawn } from 'node:child_process'
import { CredentialReadCache, keyringCredentialIdentity } from './common/credential-read-cache.ts'
import type { CredentialStore, TokenStore, StoredOAuthCredentials } from './token-store.ts'
import { CorruptStoredDocumentError, parseStoredCredentials } from './token-store.ts'

const DEFAULT_SERVICE = 'dsh-chatgpt-subscription'
const DEFAULT_ACCOUNT = 'oauth'

/**
 * How long one keychain read may stand in for the stored value.
 *
 * A keychain has no mtime to compare, so this is the price of not spawning
 * `security` on every read; it is far below the 60 s polling interval of the
 * surfaces that read these credentials.
 */
const KEYRING_READ_CACHE_TTL_MS = 15_000

/**
 * macOS credential storage backed by the login Keychain through the built-in
 * `security` command-line tool. The payload is encrypted at rest by the
 * Keychain, so this store reports itself as encrypted like Windows DPAPI.
 */
export class MacKeychainCredentialStore<T> implements CredentialStore<T> {
  readonly storage = { kind: 'macos-keychain', encrypted: true } as const
  /**
   * Snapshot of the last keychain read.
   *
   * A keychain lookup spawns `security`, and one settings request performs
   * several of them. There is no file to compare against, so the snapshot is
   * keyed on a short time bucket instead — see
   * {@link keyringCredentialIdentity}.
   */
  private readonly cache = new CredentialReadCache<T>(
    () => keyringCredentialIdentity(KEYRING_READ_CACHE_TTL_MS),
  )

  constructor(
    private readonly service: string,
    private readonly account: string,
    private readonly parse: (value: unknown) => T,
  ) {
    if (process.platform !== 'darwin') throw new Error('macOS Keychain storage requires macOS')
  }

  async load(): Promise<T | null> {
    return this.cache.load(async () => {
      const result = await runSecurity(['find-generic-password', '-a', this.account, '-s', this.service, '-w'])
      if (result.code === 44) return null
      if (result.code !== 0) throw new Error('Keychain credential read failed')
      try {
        return this.parse(parseSecurityPayload(result.stdout))
      } catch {
        throw new CorruptStoredDocumentError('Keychain credential payload is invalid')
      }
    })
  }

  async save(value: T): Promise<void> {
    const result = await runSecurity(['add-generic-password', '-a', this.account, '-s', this.service, '-w', JSON.stringify(value), '-U'])
    if (result.code !== 0) throw new Error('Keychain credential write failed')
    this.cache.invalidate()
  }

  async clear(): Promise<void> {
    const result = await runSecurity(['delete-generic-password', '-a', this.account, '-s', this.service])
    if (result.code !== 0 && result.code !== 44) throw new Error('Keychain credential deletion failed')
    this.cache.invalidate()
  }
}

/**
 * `security find-generic-password -w` normally prints the stored password as
 * text, but macOS prints the underlying bytes as hexadecimal when the payload
 * contains characters it does not consider safely printable. Credential pools
 * can contain localized account names, so accept both representations.
 */
export function parseSecurityPayload(stdout: string): unknown {
  let payload = stdout.replace(/\r?\n$/, '')
  if (/^[0-9a-fA-F]+$/.test(payload) && payload.length % 2 === 0) {
    payload = Buffer.from(payload, 'hex').toString('utf8')
  }
  return JSON.parse(payload) as unknown
}

export class MacKeychainTokenStore extends MacKeychainCredentialStore<StoredOAuthCredentials> implements TokenStore {
  constructor(service = DEFAULT_SERVICE, account = DEFAULT_ACCOUNT) {
    super(service, account, parseStoredCredentials)
  }
}

interface ProcessResult {
  code: number
  stdout: string
}

function runSecurity(args: string[]): Promise<ProcessResult> {
  return new Promise((resolve, reject) => {
    const child = spawn('security', args, {
      env: { ...process.env },
      stdio: ['ignore', 'pipe', 'pipe'],
    })
    let stdout = ''
    let stderrLength = 0
    const timer = setTimeout(() => {
      child.kill()
      reject(new Error('Keychain helper timed out'))
    }, 10_000)
    child.stdout.setEncoding('utf8')
    child.stdout.on('data', (chunk: string) => {
      stdout += chunk
      if (stdout.length > 1 << 20) child.kill()
    })
    child.stderr.on('data', (chunk: Buffer) => {
      stderrLength += chunk.length
      if (stderrLength > 1 << 20) child.kill()
    })
    child.once('error', (error) => {
      clearTimeout(timer)
      reject(error)
    })
    child.once('close', (code) => {
      clearTimeout(timer)
      resolve({ code: code ?? 1, stdout })
    })
  })
}
