import type { Context } from '@deepseek-ai/cordis'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { FileCredentialStore, FileModelSettingsStore, type AntigravityPreferenceStore } from './token-store.ts'
import { AccountPoolStore, poolRotationStrategy } from './account-pool.ts'
import { beginWebLogin, getWebLoginStatus } from './oauth.ts'
import { ANTIGRAVITY_QUOTA_CACHE_TTL_MS, clearCachedQuota, fetchAccountQuota, getCachedQuota } from './client.ts'
import { MODELS } from './types.ts'
import { effectiveModelLimits } from './catalog-limits.ts'
import { QuotaRefresh } from '../common/quota-refresh.ts'
import { getCacheStats } from './cache-stats.ts'
import type {
  AntigravityCacheStatsDto,
  AntigravityModelOption,
  AntigravityWebStatus,
} from '../../shared/antigravity-contracts.ts'

function sendJson(response: ServerResponse, status: number, body: unknown): void {
  response.writeHead(status, { 'Content-Type': 'application/json' })
  response.end(JSON.stringify(body))
}

function sendMethodNotAllowed(response: ServerResponse): void {
  sendJson(response, 405, { ok: false, error: 'Method Not Allowed' })
}

async function readRequestJson(request: IncomingMessage): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    let raw = ''
    request.on('data', (chunk) => {
      raw += String(chunk)
      if (raw.length > 64 * 1024) {
        reject(new Error('Request body too large'))
      }
    })
    request.on('end', () => {
      try {
        resolve(raw ? JSON.parse(raw) : {})
      } catch (err) {
        reject(err)
      }
    })
    request.on('error', reject)
  })
}

export async function getAntigravityWebStatus(
  store: FileCredentialStore,
  modelSettings: FileModelSettingsStore,
  preferences?: AntigravityPreferenceStore,
  accountPool = new AccountPoolStore(undefined, undefined, store),
  sessionId?: string,
): Promise<AntigravityWebStatus> {
  const credentials = await store.read()
  const settings = preferences ? preferences.status() : await modelSettings.read()
  const quota = getCachedQuota()
  const enabledSet = new Set(settings.enabledModelIds)
  const overrides = settings.contextWindowOverrides || {}

  const models: AntigravityModelOption[] = MODELS.map((m) => {
    // The same limit the adapter advertises, so the card's "default" is the
    // window a conversation actually gets without an override.
    const { contextWindow } = effectiveModelLimits(m, settings.catalogModels)
    return {
      id: m.id,
      name: m.name,
      enabled: enabledSet.has(m.id),
      defaultContextWindow: contextWindow,
      contextWindow: overrides[m.id] || contextWindow,
      reasoningEfforts: m.reasoningEfforts,
    }
  })

  const accounts = await accountPool.listAccounts().catch(() => [])
  const poolData = await accountPool.read().catch(() => null)
  const activeAccount = accounts.find((a) => a.id === poolData?.activeAccountId) || accounts[0]

  return {
    enabled: settings.enabled !== false,
    authenticated: accounts.length > 0 || !!(credentials?.access || credentials?.access_token),
    email: activeAccount?.email || credentials?.email,
    projectId: activeAccount?.projectId || credentials?.projectId,
    hasCredentials: accounts.length > 0 || !!credentials,
    storagePath: store.path(),
    lastFetchedAt: quota?.fetchedAt,
    quota,
    models,
    contextWindowOverrides: overrides,
    defaultReasoningEffort: settings.defaultReasoningEffort || null,
    accounts,
    activeAccountId: poolData?.activeAccountId || activeAccount?.id,
    // Both lines fall back to the same default: the strategy the pool itself
    // would use for an unstated one. A stored choice — including a
    // 'sequential' written before this default moved — wins, so what the card
    // shows is what the adapter will actually do.
    rotationStrategy: poolData?.rotationStrategy || poolRotationStrategy(undefined),
    cache: cacheStatsOrNull(sessionId),
  }
}

/**
 * Rolling cache totals for one session, or null while nothing has reported usage.
 *
 * The session is a query parameter because the numbers are per session: a host
 * running several conversations at once cannot present one merged hit ratio as
 * if it described any of them. With no session named the route still answers
 * with the process aggregate, which is the right answer for a settings card
 * that is not showing a specific conversation.
 */
function cacheStatsOrNull(sessionId?: string): AntigravityCacheStatsDto | null {
  const stats = getCacheStats(sessionId)
  if (stats.requests === 0) return null
  return stats
}

export function registerAntigravityRoutes(
  ctx: Context,
  store: FileCredentialStore,
  modelSettings: FileModelSettingsStore,
  preferences?: AntigravityPreferenceStore,
  fetchFn: typeof fetch = fetch,
  accountPool = new AccountPoolStore(undefined, undefined, store),
): () => void {
  // One per registration: a background refresh belongs to the line this route
  // serves, and the flag it reports must not leak between instances.
  const quotaRefresh = new QuotaRefresh()
  return ctx.webServer.register({
    kind: 'prefix',
    path: '/antigravity/api',
    handler: async (request: IncomingMessage, response: ServerResponse) => {
      const url = new URL(request.url || '/', 'http://dsh.local')
      const path = url.pathname.replace(/^\/antigravity\/api\/?/, '')

      try {
        if (path === 'status' || path === '') {
          if (request.method !== 'GET') return sendMethodNotAllowed(response)
          const credentials = await store.read()
          const authenticated = !!(credentials?.access || credentials?.access_token)
          const cached = getCachedQuota()
          // A snapshot that exists answers now and refreshes behind it; only a
          // missing one is worth waiting for, because the card has nothing to
          // render without it.
          if (authenticated && (!cached || Date.now() - (cached.fetchedAt || 0) > ANTIGRAVITY_QUOTA_CACHE_TTL_MS)) {
            const refresh = (): Promise<unknown> => fetchAccountQuota(store, modelSettings, fetchFn)
            if (cached === undefined) await quotaRefresh.run(refresh)
            else quotaRefresh.start(refresh)
          }
          // The cache totals are per session when the caller names one, so a card
          // showing a specific conversation can read that conversation's ratio
          // instead of the process-wide one.
          const value = await getAntigravityWebStatus(
            store,
            modelSettings,
            preferences,
            accountPool,
            url.searchParams.get('sessionId') ?? undefined,
          )
          return sendJson(response, 200, { ok: true, value: { ...value, quotaRefreshing: quotaRefresh.refreshing } })
        }

        if (path === 'login' || path === 'accounts/login') {
          if (request.method !== 'POST') return sendMethodNotAllowed(response)
          const value = await beginWebLogin(store, fetchFn, undefined, async (creds) => {
            await accountPool.addAccount(creds)
          })
          return sendJson(response, 200, { ok: true, value })
        }

        if (path === 'login/status') {
          if (request.method !== 'GET') return sendMethodNotAllowed(response)
          const value = getWebLoginStatus()
          return sendJson(response, 200, { ok: true, value })
        }

        if (path === 'accounts') {
          if (request.method === 'GET') {
            const list = await accountPool.listAccounts()
            return sendJson(response, 200, { ok: true, value: list })
          }
          if (request.method === 'POST') {
            const body = await readRequestJson(request)
            const action = String(body.action || '')

            if (action === 'set-primary' && typeof body.accountId === 'string') {
              await accountPool.setPrimary(body.accountId)
            } else if (action === 'set-alias' && typeof body.accountId === 'string' && typeof body.alias === 'string') {
              await accountPool.setAlias(body.accountId, body.alias)
            } else if (action === 'delete' && typeof body.accountId === 'string') {
              await accountPool.deleteAccount(body.accountId)
            } else if (action === 'strategy'
              && (body.strategy === 'sequential' || body.strategy === 'round-robin' || body.strategy === 'sticky')) {
              await accountPool.setStrategy(body.strategy)
            } else if (action === 'clear-cooldown' && typeof body.accountId === 'string') {
              await accountPool.clearCooldown(body.accountId)
            }

            // The quota shown belongs to the account that was active a moment
            // ago; an account change must not display it for the new one.
            clearCachedQuota()
            const value = await getAntigravityWebStatus(store, modelSettings, preferences, accountPool)
            return sendJson(response, 200, { ok: true, value })
          }
          return sendMethodNotAllowed(response)
        }

        if (path === 'quota') {
          if (request.method !== 'GET' && request.method !== 'POST') return sendMethodNotAllowed(response)
          const quota = await fetchAccountQuota(store, modelSettings, fetchFn, true)
          const status = await getAntigravityWebStatus(store, modelSettings, preferences, accountPool)
          return sendJson(response, 200, { ok: true, value: { ...status, quota } })
        }

        if (path === 'settings') {
          if (request.method !== 'POST') return sendMethodNotAllowed(response)
          const body = await readRequestJson(request)
          if (preferences) {
            await preferences.update(body)
          } else {
            await modelSettings.updateSettings(body)
          }
          if (body.enabledModelIds !== undefined || body.enabled !== undefined) ctx.emit?.('llm/adapters-updated')
          const value = await getAntigravityWebStatus(store, modelSettings, preferences, accountPool)
          return sendJson(response, 200, { ok: true, value })
        }

        if (path === 'models') {
          if (request.method === 'GET') {
            const status = await getAntigravityWebStatus(store, modelSettings, preferences, accountPool)
            return sendJson(response, 200, { ok: true, value: status.models })
          }
          if (request.method === 'POST') {
            const body = await readRequestJson(request)
            if (Array.isArray(body.enabledModelIds) || body.enabled !== undefined || body.contextWindowOverrides || body.defaultReasoningEffort !== undefined) {
              if (preferences) {
                await preferences.update(body)
              } else {
                await modelSettings.updateSettings(body)
              }
              if (body.enabledModelIds !== undefined || body.enabled !== undefined) ctx.emit?.('llm/adapters-updated')
            }
            const status = await getAntigravityWebStatus(store, modelSettings, preferences, accountPool)
            return sendJson(response, 200, { ok: true, value: status })
          }
          return sendMethodNotAllowed(response)
        }

        if (path === 'logout') {
          if (request.method !== 'POST') return sendMethodNotAllowed(response)
          const body = (await readRequestJson(request).catch(() => ({}))) as Record<string, unknown>
          const targetId = typeof body.accountId === 'string' ? body.accountId : undefined
          if (targetId) {
            await accountPool.deleteAccount(targetId)
          } else {
            const poolData = await accountPool.read().catch(() => null)
            if (poolData?.activeAccountId) {
              await accountPool.deleteAccount(poolData.activeAccountId)
            } else {
              await store.delete()
            }
          }
          clearCachedQuota()
          const value = await getAntigravityWebStatus(store, modelSettings, preferences, accountPool)
          return sendJson(response, 200, { ok: true, value })
        }

        return sendJson(response, 404, { ok: false, error: 'not-found' })
      } catch (err) {
        const error = err instanceof Error ? err.message : String(err)
        return sendJson(response, 500, { ok: false, error })
      }
    },
  })
}
