import fs from 'node:fs'
import fsPromises from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { isDeepStrictEqual } from 'node:util'
import z from '@deepseek-ai/schemastery'
import { MODELS } from './types.ts'
import { hasRegister, resolveSettingsNamespace, type SettingsScope } from '../common/settings-compat.ts'
import { mergeContextWindowOverrides, type ContextWindowOverridePatch } from '../common/context-window-overrides.ts'
import type { CredentialStore } from '../token-store.ts'
import { WindowsDpapiCredentialStore } from '../token-store-windows.ts'
import { MacKeychainCredentialStore } from '../token-store-macos.ts'
import { SecretServiceCredentialStore } from '../credential-store-secret-service.ts'

export const ANTIGRAVITY_PREFERENCES_NAMESPACE = 'dsh-antigravity'

export interface AntigravityCredentials {
  access?: string
  access_token?: string
  refresh?: string
  refresh_token?: string
  expires?: number
  expires_at?: number
  email?: string
  projectId?: string
}

export interface AntigravityCatalogModel {
  id: string
  name?: string
  description?: string
  /** Context window `fetchAvailableModels` reported for this runtime id, when it did. */
  contextWindow?: number
  /** Output ceiling `fetchAvailableModels` reported for this runtime id, when it did. */
  maxOutputTokens?: number
}

export interface AntigravityModelSettings {
  enabled?: boolean
  enabledModelIds: string[]
  catalogModels: AntigravityCatalogModel[]
  contextWindowOverrides?: Record<string, number>
  defaultReasoningEffort?: 'low' | 'medium' | 'high' | null
}

export interface AntigravityPreferenceStore {
  status(): AntigravityModelSettings
  update(patch: {
    enabled?: boolean
    enabledModelIds?: string[]
    /** `null` deletes one override and falls back to the catalog default. */
    contextWindowOverrides?: ContextWindowOverridePatch
    defaultReasoningEffort?: 'low' | 'medium' | 'high' | null
  }): Promise<AntigravityModelSettings>
}

export function registerAntigravityPreferenceStore(
  settings?: unknown,
  fallbackStore = new FileModelSettingsStore(),
): AntigravityPreferenceStore {
  if (!hasRegister(settings)) {
    // With no settings namespace to persist in, the JSON file beside the
    // credentials is the store. It is read once here, so a selection saved by an
    // earlier run is still the selection on the next boot.
    let snapshot: AntigravityModelSettings = {
      enabled: true,
      enabledModelIds: MODELS.map((m) => m.id),
      catalogModels: [],
      contextWindowOverrides: {},
      defaultReasoningEffort: null,
    }
    void fallbackStore.read().then((stored) => { snapshot = stored }).catch(() => undefined)
    return {
      status: () => snapshot,
      update: async (patch) => {
        snapshot = await fallbackStore.updateSettings(patch)
        return snapshot
      },
    }
  }

  const scope = settings.register(resolveSettingsNamespace(ANTIGRAVITY_PREFERENCES_NAMESPACE), z.object({
    enabled: z.boolean().default(true),
    enabledModelIds: z.array(z.string()).default(MODELS.map((m) => m.id)),
    contextWindowOverrides: z.dict(z.number()).default({}),
    defaultReasoningEffort: z.union([z.const('low'), z.const('medium'), z.const('high'), z.const(null)]).default(null),
  })) as SettingsScope<{
    enabled: boolean
    enabledModelIds: string[]
    contextWindowOverrides: Record<string, number>
    defaultReasoningEffort: 'low' | 'medium' | 'high' | null
  }>

  return {
    status: () => {
      const val = scope.get()
      return {
        enabled: val.enabled !== false,
        enabledModelIds: val.enabledModelIds,
        catalogModels: [],
        contextWindowOverrides: val.contextWindowOverrides,
        defaultReasoningEffort: val.defaultReasoningEffort,
      }
    },
    update: async (patch) => {
      const current = scope.get()
      const normalized = {
        enabled: patch.enabled !== undefined ? patch.enabled : (current.enabled !== false),
        enabledModelIds: patch.enabledModelIds ?? current.enabledModelIds,
        contextWindowOverrides: patch.contextWindowOverrides
          ? mergeContextWindowOverrides(current.contextWindowOverrides, patch.contextWindowOverrides)
          : current.contextWindowOverrides,
        defaultReasoningEffort:
          patch.defaultReasoningEffort !== undefined
            ? patch.defaultReasoningEffort
            : current.defaultReasoningEffort,
      }
      await scope.update(normalized)
      void fallbackStore.updateSettings(patch).catch(() => undefined)
      return {
        ...normalized,
        catalogModels: [],
      }
    },
  }
}

export function dshHomeDir(): string {
  return process.env.DSH_HOME?.trim() || path.join(os.homedir(), '.dsh')
}

export function credentialPath(): string {
  return path.join(dshHomeDir(), 'storages', 'antigravity-oauth.json')
}

export function modelSettingsPath(): string {
  return path.join(dshHomeDir(), 'storages', 'antigravity-models.json')
}

export function parseAntigravityCredentials(value: unknown): AntigravityCredentials {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) {
    throw new Error('Antigravity credential payload is invalid')
  }
  const record = value as Record<string, unknown>
  const credentials: AntigravityCredentials = {}
  for (const key of ['access', 'access_token', 'refresh', 'refresh_token', 'email', 'projectId'] as const) {
    if (record[key] === undefined) continue
    if (typeof record[key] !== 'string') throw new Error('Antigravity credential payload is invalid')
    credentials[key] = record[key]
  }
  for (const key of ['expires', 'expires_at'] as const) {
    if (record[key] === undefined) continue
    if (typeof record[key] !== 'number' || !Number.isFinite(record[key])) {
      throw new Error('Antigravity credential expiry is invalid')
    }
    credentials[key] = record[key]
  }
  if (!(credentials.access || credentials.access_token || credentials.refresh || credentials.refresh_token)) {
    throw new Error('Antigravity credential tokens are missing')
  }
  return credentials
}

function credentialAccount(filePath: string): string {
  return createHash('sha256').update(path.resolve(filePath)).digest('hex')
}

function createCredentialBackend(filePath: string): CredentialStore<AntigravityCredentials> {
  if (process.platform === 'win32') {
    return new WindowsDpapiCredentialStore(`${filePath}.dpapi`, parseAntigravityCredentials)
  }
  if (process.platform === 'darwin') {
    return new MacKeychainCredentialStore('dsh-antigravity', credentialAccount(filePath), parseAntigravityCredentials)
  }
  if (process.platform === 'linux') {
    return new SecretServiceCredentialStore('dsh-antigravity', credentialAccount(filePath), parseAntigravityCredentials)
  }
  throw new Error('Antigravity encrypted credential storage requires Windows, macOS, or Linux.')
}

// Web login, quota requests and CLI-compatible store instances share migration ordering.
const credentialOperations = new Map<string, Promise<void>>()

/** Keeps the public API; filePath identifies the legacy JSON that is migrated on first use. */
export class FileCredentialStore {
  constructor(
    private readonly filePath = credentialPath(),
    private readonly backend: CredentialStore<AntigravityCredentials> = createCredentialBackend(filePath),
  ) {}

  path(): string {
    if (process.platform === 'win32') return `${this.filePath}.dpapi`
    const kind = process.platform === 'darwin' ? 'Keychain' : 'Secret Service'
    return `${kind}: dsh-antigravity/${credentialAccount(this.filePath)}`
  }

  private serialize<T>(operation: () => Promise<T>): Promise<T> {
    const key = path.resolve(this.filePath)
    const result = (credentialOperations.get(key) || Promise.resolve()).then(operation)
    const settled = result.then(() => undefined, () => undefined)
    credentialOperations.set(key, settled)
    void settled.then(() => {
      if (credentialOperations.get(key) === settled) credentialOperations.delete(key)
    })
    return result
  }

  private async removeLegacy(): Promise<void> {
    try {
      await fsPromises.unlink(this.filePath)
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== 'ENOENT') {
        throw new Error('Antigravity legacy credential removal failed')
      }
    }
  }

  private async saveVerified(credentials: AntigravityCredentials): Promise<void> {
    await this.backend.save(credentials)
    const restored = await this.backend.load()
    if (!isDeepStrictEqual(restored, credentials)) throw new Error('Antigravity encrypted credential verification failed')
    await this.removeLegacy()
  }

  read(): Promise<AntigravityCredentials | null> {
    return this.serialize(async () => {
      // A damaged/locked secure store must never fall back to stale plaintext tokens.
      const current = await this.backend.load()
      if (current !== null) {
        await this.removeLegacy()
        return current
      }
      let legacy: string
      try {
        const stats = await fsPromises.lstat(this.filePath)
        if (!stats.isFile() || stats.isSymbolicLink()) throw new Error('Invalid credential file')
        if (process.getuid && stats.uid !== process.getuid()) throw new Error('Invalid credential owner')
        if (process.platform !== 'win32') await fsPromises.chmod(this.filePath, 0o600)
        legacy = await fsPromises.readFile(this.filePath, 'utf8')
      } catch (error) {
        if ((error as NodeJS.ErrnoException).code === 'ENOENT') return null
        throw new Error('Antigravity legacy credential read failed')
      }
      let credentials: AntigravityCredentials
      try {
        credentials = parseAntigravityCredentials(JSON.parse(legacy) as unknown)
      } catch {
        throw new Error('Antigravity legacy credential payload is invalid')
      }
      await this.saveVerified(credentials)
      return credentials
    })
  }

  write(credentials: AntigravityCredentials): Promise<void> {
    return this.serialize(() => this.saveVerified(parseAntigravityCredentials(credentials)))
  }

  delete(): Promise<void> {
    return this.serialize(async () => {
      // Remove the migration source first so a failed logout cannot resurrect it.
      await this.removeLegacy()
      await this.backend.clear()
    })
  }
}

export class FileModelSettingsStore {
  constructor(private readonly filePath = modelSettingsPath()) {}

  path(): string {
    return this.filePath
  }

  async read(): Promise<AntigravityModelSettings> {
    try {
      const content = await fsPromises.readFile(this.filePath, 'utf8')
      const parsed = JSON.parse(content) as unknown
      if (typeof parsed === 'object' && parsed !== null) {
        const record = parsed as Record<string, unknown>
        const enabledModelIds = Array.isArray(record.enabledModelIds)
          ? record.enabledModelIds.filter((id): id is string => typeof id === 'string')
          : MODELS.map((m) => m.id)
        const catalogModels = Array.isArray(record.catalogModels)
          ? (record.catalogModels as AntigravityCatalogModel[])
          : []
        const contextWindowOverrides =
          typeof record.contextWindowOverrides === 'object' && record.contextWindowOverrides !== null
            ? (record.contextWindowOverrides as Record<string, number>)
            : {}
        const defaultReasoningEffort =
          record.defaultReasoningEffort === 'low' ||
          record.defaultReasoningEffort === 'medium' ||
          record.defaultReasoningEffort === 'high'
            ? record.defaultReasoningEffort
            : null
        const enabled = record.enabled !== false

        return {
          enabled,
          enabledModelIds,
          catalogModels,
          contextWindowOverrides,
          defaultReasoningEffort,
        }
      }
    } catch {
      // ignore
    }
    return {
      enabled: true,
      enabledModelIds: MODELS.map((m) => m.id),
      catalogModels: [],
      contextWindowOverrides: {},
      defaultReasoningEffort: null,
    }
  }

  async write(settings: AntigravityModelSettings): Promise<void> {
    await fsPromises.mkdir(path.dirname(this.filePath), { recursive: true })
    const tmp = `${this.filePath}.tmp.${Date.now()}`
    await fsPromises.writeFile(tmp, JSON.stringify(settings, null, 2), 'utf8')
    await fsPromises.rename(tmp, this.filePath)
  }

  async updateSettings(patch: {
    enabled?: boolean
    enabledModelIds?: string[]
    /** `null` deletes one override and falls back to the catalog default. */
    contextWindowOverrides?: ContextWindowOverridePatch
    defaultReasoningEffort?: 'low' | 'medium' | 'high' | null
  }): Promise<AntigravityModelSettings> {
    const current = await this.read()
    const next: AntigravityModelSettings = {
      ...current,
      ...(patch.enabled !== undefined ? { enabled: patch.enabled } : {}),
      ...(patch.enabledModelIds !== undefined ? { enabledModelIds: patch.enabledModelIds } : {}),
      ...(patch.contextWindowOverrides !== undefined
        ? {
            contextWindowOverrides: mergeContextWindowOverrides(
              current.contextWindowOverrides || {},
              patch.contextWindowOverrides,
            ),
          }
        : {}),
      ...(patch.defaultReasoningEffort !== undefined
        ? { defaultReasoningEffort: patch.defaultReasoningEffort }
        : {}),
    }
    await this.write(next)
    return next
  }

  async setEnabledModelIds(enabledModelIds: string[]): Promise<AntigravityModelSettings> {
    return this.updateSettings({ enabledModelIds })
  }

  async setCatalogModels(
    catalogModels: AntigravityCatalogModel[],
    options?: { enabledModelIds?: string[] },
  ): Promise<AntigravityModelSettings> {
    const current = await this.read()
    const next: AntigravityModelSettings = {
      ...current,
      enabledModelIds: options?.enabledModelIds ?? current.enabledModelIds,
      catalogModels,
    }
    await this.write(next)
    return next
  }
}
