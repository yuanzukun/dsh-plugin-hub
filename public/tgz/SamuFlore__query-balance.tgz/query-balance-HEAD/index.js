import { defineTool } from '@deepseek-ai/dsh-tools'
import { credentialRef } from '@deepseek-ai/dsh-credentials'



export const name = 'query-balance'
export const inject = ['tools', 'credentials']


// 余额查询端点
const BALANCE_URL = 'https://api.deepseek.com/user/balance'

export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'query_api_balance',
    description: 'Query the DeepSeek API account balance via GET /user/balance.',
    parameters: {},
    output: {
      schema: { type: 'json' },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    timeoutMs: 15_000,
    isConcurrencySafe: () => true,
    async execute() {
      const key = await ctx.credentials.resolve(credentialRef('DEEPSEEK_API_KEY'))
      if (key === undefined) {
        throw new Error('credential DEEPSEEK_API_KEY is not configured (set it in the environment or $DSH_HOME/.env)')
      }
      const response = await fetch(BALANCE_URL, {
        headers: {
          Accept: 'application/json',
          Authorization: `Bearer ${key.value}`,
        },
        // 禁止重定向
        redirect: 'error',
      })
      if (!response.ok) {
        throw new Error(`balance request failed: HTTP ${response.status} ${response.statusText}`)
      }
      return await response.json()
    },
  }))
}
