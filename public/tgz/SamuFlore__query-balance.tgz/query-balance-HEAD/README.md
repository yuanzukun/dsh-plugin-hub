# @samuflore/dsh-query-balance

DSH 查询 API 余额工具：注册 `query_api_balance` 工具，通过 `GET /user/balance` 查询 DeepSeek API 账户余额。

## 安装

```sh
dsh plugin --profile web add @samuflore/dsh-query-balance@latest
```

然后启动：

```sh
dsh web
```

## 使用

直接对 agent 说：

> 查询余额

## 前置条件

工具通过 dsh 的 credentials 服务读取 `DEEPSEEK_API_KEY`（解析顺序：进程环境变量 → 凭据存储 → `~/.dsh/.env` → 项目 `.env`）。使用前请配置自己的 API Key：

```sh
export DEEPSEEK_API_KEY=sk-...
```

**一般来说，在能够正常使用 DSH 的情况下，这一项已经正常配置了。**

## 返回值

返回 `/user/balance` 接口原始 JSON（`is_available`、`balance_infos`）。

## API 参考

<https://api-docs.deepseek.com/api/get-user-balance/>
