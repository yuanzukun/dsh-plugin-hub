#!/usr/bin/env node
/**
 * Client bundle build: emits the closure-factory artifact the DSH web loader
 * consumes. Externals resolve through the loader module table; everything else
 * inlines. The web shell serves this artifact at /plugins/<id>/client.js and
 * executes it as a CLASSIC script, so the emitted text must contain NO
 * import.meta and no top-level ESM statements.
 */
import { build } from 'esbuild';
import { readFileSync, writeFileSync } from 'node:fs';

const ID = 'dsh-ssh-remote';
const ENTRY = 'client/index.tsx';
const OUT_FILE = 'lib/client.js';
const REMOTE_ENTRY = 'client/typert.remote-client.ts';
const REMOTE_OUT_FILE = 'lib/typert.remote-client.js';

/** Loader module table (platform seed entries + runtime/client exemption). */
const CLIENT_EXTERNALS = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-schema-form',
  '@deepseek-ai/dsh-client-runtime/client',
];

/** Wire/type layers with no shared runtime identity that may inline. */
const INLINE_SAFE = /^@deepseek-ai\/dsh-(host-apiproxy|session|llm|tools|brand|util-workspace-path)(\/|$)/;
/**
 * Generated descriptor/codec contribution with no shared runtime identity.
 * NOTE: this plugin is UNscoped (dsh-ssh-remote), so its own /remote export
 * (dsh-ssh-remote/remote) does NOT match this regex (nor the @deepseek-ai/
 * onResolve filter) - the client half inlines its own descriptors via the
 * ordinary bundle path. This regex only matters for BUILT-IN
 * @deepseek-ai/dsh-<pkg>/remote imports, which this plugin does not make.
 */
const GENERATED_REMOTE = /^@deepseek-ai\/dsh-[a-z0-9]+(?:-[a-z0-9]+)*\/remote$/;

const bannerJs = `window.__ModuleLoader__.load({ id: ${JSON.stringify(ID)}, factory: (require) => {\nvar module = { exports: {} }; var exports = module.exports;`;
const footerJs = 'return module.exports; } });';

const result = await build({
  entryPoints: [ENTRY],
  outfile: OUT_FILE,
  bundle: true,
  format: 'cjs',
  platform: 'browser',
  target: 'es2020',
  jsx: 'automatic',
  external: [...CLIENT_EXTERNALS],
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    'import.meta.env.MODE': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    'import.meta.env': JSON.stringify({ MODE: process.env.NODE_ENV ?? 'production' }),
  },
  banner: { js: bannerJs },
  footer: { js: footerJs },
  plugins: [{
    // Bundle purity gate: platform seed entries stay external, inline-safe wire
    // layers inline, and every other @deepseek-ai value import is a build error.
    name: 'dsh-client-bundle-purity',
    setup(build) {
      build.onResolve({ filter: /^@deepseek-ai\// }, (args) => {
        if (CLIENT_EXTERNALS.includes(args.path)) return undefined;
        if (INLINE_SAFE.test(args.path) || GENERATED_REMOTE.test(args.path)) return undefined;
        throw new Error(
          `client bundle purity: "${args.path}" is not a platform module (CLIENT_EXTERNALS), an inline-safe wire layer, or a generated /remote contribution - cross-plugin value imports are forbidden (type-only imports are erased and never reach this gate)`,
        );
      });
    },
  }],
});

if (result.errors.length > 0) {
  throw new Error(`client bundle build failed:\n${result.errors.map((e) => e.text).join('\n')}`);
}

const text = readFileSync(OUT_FILE, 'utf8');
if (!text.includes('window.__ModuleLoader__.load(') || !text.includes(JSON.stringify(ID))) {
  throw new Error('client bundle contract: closure-factory load handoff with the plugin id is missing');
}
if (text.includes('import.meta') || /(^|\n)\s*(import|export)\s/.test(text)) {
  throw new Error('client bundle contract: emitted bundle contains import.meta / ESM statements');
}
for (const match of text.matchAll(/require\(\s*["'](@deepseek-ai\/[^"']+)["']\s*\)/g)) {
  const specifier = match[1];
  if (!CLIENT_EXTERNALS.includes(specifier)) {
    throw new Error(`client bundle contract: "${specifier}" VALUE import survived the purity gate`);
  }
}

// Flat type re-export the loader-facing exports["./client"].types points at.
writeFileSync('lib/client.d.ts', `export * from './client/index.js';\n`);

// The client imports this descriptor from source. Emit the package ./remote
// face from the same source so a clean build cannot retain stale hand-written
// descriptors in lib/.
await build({
  entryPoints: [REMOTE_ENTRY],
  outfile: REMOTE_OUT_FILE,
  bundle: true,
  format: 'esm',
  platform: 'browser',
  target: 'es2020',
});
writeFileSync(
  'lib/typert.remote-client.d.ts',
  `export { default, TYPERT_REMOTE } from './client/typert.remote-client.js';\n`,
);

console.log(
  `built ${OUT_FILE} (closure-factory, id=${ID}, ${text.length} bytes), ${REMOTE_OUT_FILE}, and loader declarations`,
);
