import { useEffect, useRef, useState, type CSSProperties } from 'react';
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { WorkspaceId, WorkspaceView } from '@deepseek-ai/dsh-api-remotes/client';
import type {} from '@deepseek-ai/dsh-api-workspace-controller/client';
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client';
import type {} from '@deepseek-ai/dsh-client-ui-settings/client';
import type { DirectoryFlowOwnerProps } from '@deepseek-ai/dsh-client-ui-workspace/client';
import {
  Button,
  IconFolderCloseRegular,
  IconPlusOutlineRegular,
  Input,
  Modal,
  Pill,
} from '@deepseek-ai/dsh-client-ui-primitives';
import {
  isDirectoryPickerUnavailable,
  probeLocalBrowse,
  windowsDriveAnchors,
  type LocalAnchor,
} from './local-browse.js';
import TYPERT_REMOTE from './typert.remote-client.js';
import { mountNativePanels } from './native-panels.js';
import { mountSessionMarkdownImages } from './markdown-preview.js';
import { mountRemoteEditor } from './editor.js';
import { mountQuickOpen } from './quick-open.js';
import type { EditorBridge } from './file-search-types.js';

export const name = 'dsh-ssh-remote-client';
export const inject = ['remote'];

interface DiscoveredHost {
  alias: string;
  host: string;
  port: number;
  user: string;
  identityFile: string;
  proxyJump: string;
  proxyCommand: string;
  helper: HelperHostStatus;
}

interface HelperHostStatus {
  status: 'disconnected' | 'installing' | 'connecting' | 'connected' | 'degraded' | 'reconnecting' | 'error';
  version: string;
  sessionId: string;
  capabilities: Record<string, unknown>;
  error: string;
  errorCode?: string;
  retryable?: boolean;
  hint?: string;
  environment?: { search: { available: boolean; path?: string; version?: string; error?: string } };
}

interface HelperHostDiagnostics extends HelperHostStatus {
  alias: string;
  helperSha256: string;
  lastConnectedAt: number;
  lastHealthAt: number;
  nextRetryAt: number;
  stderr: string;
  assetPath: string;
}

interface SshConfig {
  configPath: string;
  configExists: boolean;
  hosts: DiscoveredHost[];
  legacyHostCount: number;
}

interface RemoteDirectoryEntry {
  name: string;
  path: string;
  hidden: boolean;
}

interface RemoteDirectoryListing {
  path: string;
  home: string;
  crumbs: RemoteDirectoryEntry[];
  entries: RemoteDirectoryEntry[];
  truncated: boolean;
}

interface SshWorkspaceAnchor {
  anchorPath: string;
  uri: string;
  alias: string;
  remotePath: string;
  title: string;
  createdAt: number;
}

type RemoteResult<T> =
  | { ok: true; value: T }
  | { ok: false; error: { message: string } };

const MUTATION_DEADLINE_MS = 30_000;
const READ_DEADLINE_MS = 30_000;

interface SshRemote {
  config(): Promise<RemoteResult<SshConfig>>;
  statuses(): Promise<RemoteResult<Record<string, HelperHostStatus>>>;
  browse(alias: string, path: string): Promise<RemoteResult<RemoteDirectoryListing>>;
  createDirectory(alias: string, parent: string, name: string): Promise<RemoteResult<string>>;
  materializeWorkspace(alias: string, path: string): Promise<RemoteResult<SshWorkspaceAnchor>>;
  connectHost(alias: string): Promise<RemoteResult<HelperHostStatus>>;
  disconnectHost(alias: string): Promise<RemoteResult<HelperHostStatus>>;
  retryHost(alias: string): Promise<RemoteResult<HelperHostStatus>>;
  diagnostics(alias: string): Promise<RemoteResult<HelperHostDiagnostics>>;
}

interface DirectoryService {
  pickDirectory(): Promise<string | null>;
  listDirectory(path?: string): Promise<RemoteDirectoryListing>;
  createDirectory(path: string, name: string): Promise<string>;
}

export async function apply(ctx: ClientContext) {
  const disposeMount = await ctx.remote.$mount(TYPERT_REMOTE);
  const ui = ctx.inject(['remote.sshRemote', 'slots', 'workspaces'], (scope) => {
    // The official Remote supports cancellation; UiWorkspace's convenience
    // method currently drops that signal. Keep its fallback for compositions
    // without this optional namespace, without blocking the rest of the UI.
    let pickNative: ((signal?: AbortSignal) => Promise<string | null>) | undefined;
    const nativePicker = scope.inject(['remote.directoryPicker'], next => {
      const picker = next.remote.directoryPicker;
      const adapter = async (signal?: AbortSignal) => {
        const result = await picker.pick(signal);
        if (!result.ok) throw new Error(`directory picker failed: ${result.error.message}`);
        return result.value;
      };
      pickNative = adapter;
      return () => { if (pickNative === adapter) pickNative = undefined; };
    });
    const mountUi = (scope: ClientContext, directories: DirectoryService) => {
      const ssh = scope.remote.sshRemote;
      const flowInject = () => ({
        ssh,
        pickLocal: (signal?: AbortSignal) => {
          // Match the stock native slot: Desktop owns a window-parented
          // dialog bridge; bypassing it incorrectly sends Desktop to the
          // Web host's external OS chooser instead.
          const desktop = (globalThis as typeof globalThis & {
            __DSH_DIRECTORY_PICKER__?: { pick(): Promise<string | null> };
          }).__DSH_DIRECTORY_PICKER__;
          return desktop === undefined
            ? pickNative?.(signal) ?? directories.pickDirectory()
            : desktop.pick();
        },
        // The composed picker's browse capability (in-app listing/creation).
        // Served only when the host composes the `-browse` backend; chooseLocal
        // probes for it and falls back to the native chooser only on the
        // explicit capability-unavailable signal (`directory-picker-unavailable`).
        listLocal: (path?: string) => directories.listDirectory(path),
        createLocalDirectory: (path: string, name: string) =>
          directories.createDirectory(path, name),
        createWorkspace: (input: { path: string }) => scope.workspaces.create(input),
        renameWorkspace: (workspaceId: WorkspaceId, title: string) =>
          scope.workspaces.rename(workspaceId, title),
      });

      return scope.slots.inject('settings.plugins.tab', () =>
        scope.slots.inject('conversation.hero.workspace.directoryFlow', () =>
          scope.slots.inject('sidebar.workspaces.directoryFlow', function* () {
            yield scope.slots.register(
              {
                name: 'settings.plugins.tab',
                id: 'ssh-remote',
                order: 20,
                label: () => 'SSH Remote',
                inject: () => ({ ssh }),
              },
              SshRemotePanel,
            );
            // The slot is `single`; a lower priority shadows the stock local-only
            // occupant while this combined local/SSH flow is mounted.
            yield scope.slots.register(
              {
                name: 'conversation.hero.workspace.directoryFlow',
                priority: -100,
                inject: flowInject,
              },
              SshDirectoryFlow,
            );
            yield scope.slots.register(
              {
                name: 'sidebar.workspaces.directoryFlow',
                priority: -100,
                inject: flowInject,
              },
              SshDirectoryFlow,
            );
          }),
        ),
      );
    };
    // DSH 0.2.0 split directory UI operations into `ctx.uiWorkspace`
    // (UiWorkspace), separate from `ctx.workspaces` (IWorkspaces).
    const directories = scope.inject(['uiWorkspace'], next => mountUi(
      next,
      (next as ClientContext & { uiWorkspace: DirectoryService }).uiWorkspace,
    ));
    return async () => {
      await directories.dispose();
      await nativePicker.dispose();
    };
  });

  const disposePanels = mountNativePanels(ctx);
  const disposeMarkdown = mountSessionMarkdownImages(ctx);
  const editorBridge: EditorBridge = {};
  const disposeEditor = mountRemoteEditor(ctx, editorBridge);
  const disposeQuickOpen = mountQuickOpen(ctx, editorBridge);
  try {
    await ui;
  } catch (error) {
    await disposeQuickOpen();
    await disposeEditor();
    await disposeMarkdown();
    await disposePanels();
    await ui.dispose();
    await disposeMount();
    throw error;
  }

  return async () => {
    await disposeQuickOpen();
    await disposeEditor();
    await disposeMarkdown();
    await disposePanels();
    await ui.dispose();
    await disposeMount();
  };
}

/** Which filesystem the combined dialog is currently browsing. */
type BrowseTarget = { kind: 'local' } | { kind: 'ssh'; alias: string };

type SshDirectoryFlowProps = DirectoryFlowOwnerProps & {
  ssh: SshRemote;
  pickLocal: (signal?: AbortSignal) => Promise<string | null>;
  /** One local directory level via the composed picker's browse capability. */
  listLocal: (path?: string) => Promise<RemoteDirectoryListing>;
  /** Create one child directory under an existing local parent. */
  createLocalDirectory: (path: string, name: string) => Promise<string>;
  createWorkspace: (input: { path: string }) => Promise<WorkspaceView>;
  renameWorkspace: (workspaceId: WorkspaceId, title: string) => Promise<WorkspaceView>;
};

/** Wrap a throwing service call into the dialog's result envelope. */
async function asResult<T>(run: () => Promise<T>): Promise<RemoteResult<T>> {
  try {
    return { ok: true, value: await run() };
  } catch (reason) {
    return { ok: false, error: { message: messageOf(reason) } };
  }
}

/** Bound non-cancellable host RPCs so a wedged transport cannot lock the dialog forever. */
function withMutationDeadline<T>(operation: Promise<T>, label: string): Promise<T> {
  return withDeadline(operation, `${label} 超过 ${MUTATION_DEADLINE_MS / 1000} 秒；结果未知，请刷新后核对。`, MUTATION_DEADLINE_MS);
}

function withReadDeadline<T>(operation: Promise<T>, label: string): Promise<T> {
  return withDeadline(operation, `${label} 超过 ${READ_DEADLINE_MS / 1000} 秒，请重试。`, READ_DEADLINE_MS);
}

function withDeadline<T>(operation: Promise<T>, message: string, milliseconds: number, onTimeout?: () => void): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let settled = false;
    const finish = (run: () => void): void => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      run();
    };
    const timer = setTimeout(() => {
      finish(() => {
        onTimeout?.();
        reject(new Error(message));
      });
    }, milliseconds);
    operation.then(
      value => finish(() => resolve(value)),
      reason => finish(() => reject(reason)),
    );
  });
}

function messageOf(reason: unknown): string {
  return reason instanceof Error ? reason.message : String(reason);
}

export function SshDirectoryFlow({
  open,
  busy,
  onPicked,
  onCancel,
  onError,
  ssh,
  pickLocal,
  listLocal,
  createLocalDirectory,
  createWorkspace,
  renameWorkspace,
}: SshDirectoryFlowProps) {
  const [config, setConfig] = useState<SshConfig | null>(null);
  const [target, setTarget] = useState<BrowseTarget | null>(null);
  const [listing, setListing] = useState<RemoteDirectoryListing | null>(null);
  const [loading, setLoading] = useState(false);
  /** Irreversible host-side operation in flight; user cancellation is gated. */
  const [mutating, setMutating] = useState(false);
  const [error, setError] = useState('');
  const [newFolder, setNewFolder] = useState('');
  const [pathInput, setPathInput] = useState('');
  // Tri-state browse-capability probe result: null while unknown.
  const [localCanBrowse, setLocalCanBrowse] = useState<boolean | null>(null);
  // Windows drive anchors derived from one /mnt listing; null until probed.
  const [driveAnchors, setDriveAnchors] = useState<LocalAnchor[] | null>(null);
  /** Latest navigation request; stale remote replies may not overwrite it. */
  const navigationEpoch = useRef(0);
  /** Owns the mutation busy flag even if navigation/open state changes. */
  const mutationEpoch = useRef(0);
  const mounted = useRef(false);
  const nativePicker = useRef<AbortController | null>(null);

  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
      navigationEpoch.current += 1;
      mutationEpoch.current += 1;
      nativePicker.current?.abort();
    };
  }, []);

  useEffect(() => {
    if (!open) return;
    const epoch = ++navigationEpoch.current;
    setConfig(null);
    setTarget(null);
    setListing(null);
    setError('');
    setNewFolder('');
    setPathInput('');
    setDriveAnchors(null);
    setLocalCanBrowse(null);
    setLoading(true);
    void Promise.all([
      withReadDeadline(ssh.config(), 'SSH 配置读取').catch(error => ({
        ok: false as const,
        error: { message: messageOf(error) },
      })),
      probeLocalBrowse(() => withReadDeadline(listLocal(), '本机浏览')).then(
        value => ({ ok: true as const, value }),
        error => ({ ok: false as const, error }),
      ),
    ]).then(([configResult, browseProbe]) => {
      if (navigationEpoch.current !== epoch) return;
      if (browseProbe.ok) setLocalCanBrowse(browseProbe.value);
      else {
        // Non-capability probe failures (permission, timeout, transport,
        // internal…) surface only after the request epoch is still current.
        setError(`本机浏览探测失败：${messageOf(browseProbe.error)}`);
      }
      if (configResult.ok) setConfig(configResult.value);
      else if (browseProbe.ok) setError(configResult.error.message);
    }).finally(() => {
      if (navigationEpoch.current === epoch) setLoading(false);
    });
    return () => {
      navigationEpoch.current += 1;
      nativePicker.current?.abort();
    };
  }, [open, ssh, listLocal]);

  useEffect(() => {
    if (!open || target?.kind !== 'local' || driveAnchors !== null) return;
    const epoch = navigationEpoch.current;
    let cancelled = false;
    void asResult(() => withReadDeadline(listLocal('/mnt'), '本机磁盘探测')).then((result) => {
      if (!cancelled && navigationEpoch.current === epoch) {
        setDriveAnchors(result.ok ? windowsDriveAnchors(result.value.entries) : []);
      }
    });
    return () => { cancelled = true; };
  }, [open, target, driveAnchors, listLocal]);

  /**
   * One raw local browse call that preserves any thrown error so callers can
   * still distinguish the explicit capability-unavailable signal from real
   * browse failures.
   */
  async function browseLocalRaw(path?: string): Promise<
    { ok: true; value: RemoteDirectoryListing } | { ok: false; error: unknown }
  > {
    try {
      return { ok: true, value: await withReadDeadline(listLocal(path), '本机浏览') };
    } catch (error) {
      return { ok: false, error };
    }
  }

  async function enter(targetNext: BrowseTarget, path?: string): Promise<boolean> {
    const epoch = ++navigationEpoch.current;
    setLoading(true);
    setError('');
    if (targetNext.kind === 'ssh') {
      let result: RemoteResult<RemoteDirectoryListing>;
      try {
        result = await withReadDeadline(ssh.browse(targetNext.alias, path ?? ''), '远程目录浏览');
      } catch (reason) {
        if (navigationEpoch.current === epoch) {
          setError(messageOf(reason));
          setLoading(false);
        }
        return false;
      }
      if (navigationEpoch.current !== epoch) return false;
      if (result.ok) {
        setTarget(targetNext);
        setListing(result.value);
        setPathInput(result.value.path);
      } else {
        setError(result.error.message);
      }
      setLoading(false);
      return result.ok;
    }
    const outcome = await browseLocalRaw(path);
    if (navigationEpoch.current !== epoch) return false;
    if (outcome.ok) {
      setTarget(targetNext);
      setListing(outcome.value);
      setPathInput(outcome.value.path);
    } else {
      setError(messageOf(outcome.error));
    }
    setLoading(false);
    return outcome.ok;
  }

  function navigate(path?: string): void {
    if (target) void enter(target, path);
  }

  async function chooseLocal() {
    // Prefer the composed browse capability — it works headless and covers
    // the WSL host filesystem together with its /mnt Windows drives. Only
    // the explicit capability-unavailable signal may switch to the OS
    // chooser: the probe reported `false`, or a raced browse call now
    // reports `directory-picker-unavailable`. Permission, timeout, transport,
    // internal, and every other failure stays in the dialog for retry, with
    // no native fallback.
    if (localCanBrowse !== false) {
      const epoch = ++navigationEpoch.current;
      setLoading(true);
      setError('');
      const outcome = await browseLocalRaw();
      if (navigationEpoch.current !== epoch) return;
      if (outcome.ok) {
        setLoading(false);
        setTarget({ kind: 'local' });
        setListing(outcome.value);
        setPathInput(outcome.value.path);
        return;
      }
      if (!isDirectoryPickerUnavailable(outcome.error)) {
        setError(messageOf(outcome.error));
        setLoading(false);
        return;
      }
      // Capability raced: the composition now serves native (or no picker) —
      // the one condition that may reach the OS chooser.
      setLocalCanBrowse(false);
      setLoading(false);
    }
    await pickLocalFallback();
  }

  /** The only native-chooser path, entered solely on the explicit unavailable signal. */
  async function pickLocalFallback() {
    const epoch = ++navigationEpoch.current;
    nativePicker.current?.abort();
    const controller = new AbortController();
    nativePicker.current = controller;
    setLoading(true);
    setError('');
    try {
      const path = await withDeadline(
        pickLocal(controller.signal),
        '系统文件夹选择器超过 30 秒未返回，已停止等待。若系统对话框仍在或置于后台，请先关闭后重试；若仍无对话框，请重启 DSH 后再试。',
        READ_DEADLINE_MS,
        () => controller.abort(),
      );
      if (navigationEpoch.current === epoch && path) onPicked(path);
    } catch (reason) {
      if (navigationEpoch.current === epoch) setError(messageOf(reason));
    } finally {
      if (nativePicker.current === controller) nativePicker.current = null;
      if (navigationEpoch.current === epoch) setLoading(false);
    }
  }

  async function commit() {
    if (!target || !listing) return;
    const epoch = ++navigationEpoch.current;
    const mutation = ++mutationEpoch.current;
    setMutating(true);
    if (target.kind === 'local') {
      setMutating(false);
      onPicked(listing.path);
      return;
    }
    setLoading(true);
    setError('');
    try {
      const result = await withMutationDeadline(
        ssh.materializeWorkspace(target.alias, listing.path),
        '远程工作区验证',
      );
      if (navigationEpoch.current !== epoch) return;
      if (result.ok) {
        // The stock owner accepts only a path and initially derives the title
        // from its basename. Pre-create idempotently, apply the clean remote
        // title, then hand the same path back so the owner keeps its normal
        // close/select/error lifecycle without exposing the anchor hash.
        const workspace = await withMutationDeadline(
          createWorkspace({ path: result.value.anchorPath }),
          '工作区创建',
        );
        if (navigationEpoch.current !== epoch) return;
        if (workspace.title !== result.value.title) {
          await withMutationDeadline(
            renameWorkspace(workspace.workspaceId, result.value.title),
            '工作区命名',
          );
          if (navigationEpoch.current !== epoch) return;
        }
        onPicked(result.value.anchorPath);
      } else {
        onError(result.error.message);
      }
    } catch (reason) {
      if (navigationEpoch.current === epoch) onError(messageOf(reason));
    } finally {
      if (navigationEpoch.current === epoch) setLoading(false);
      if (mounted.current && mutationEpoch.current === mutation) setMutating(false);
    }
  }

  async function createFolder() {
    if (!target || !listing || !newFolder.trim()) return;
    const epoch = ++navigationEpoch.current;
    const mutation = ++mutationEpoch.current;
    const targetSnapshot = target;
    const listingPath = listing.path;
    const folderName = newFolder.trim();
    setLoading(true);
    setMutating(true);
    setError('');
    try {
      const created = targetSnapshot.kind === 'ssh'
        ? await withMutationDeadline(
          ssh.createDirectory(targetSnapshot.alias, listingPath, folderName),
          '远程文件夹创建',
        )
        : await asResult(() => withMutationDeadline(
          createLocalDirectory(listingPath, folderName),
          '本机文件夹创建',
        ));
      if (navigationEpoch.current !== epoch) return;
      if (created.ok) {
        setNewFolder('');
        await enter(targetSnapshot, created.value);
      } else {
        setError(created.error.message);
        setLoading(false);
      }
    } catch (reason) {
      if (navigationEpoch.current === epoch) {
        setError(messageOf(reason));
        setLoading(false);
      }
    } finally {
      if (mounted.current && mutationEpoch.current === mutation) setMutating(false);
    }
  }

  function cancel(): void {
    navigationEpoch.current += 1;
    nativePicker.current?.abort();
    onCancel();
  }

  // Modal renders null while closed; `disabled` only gates the open dialog.
  const disabled = loading || busy || mutating;

  return (
    <Modal
      open={open}
      onClose={() => { if (!busy && !mutating) cancel(); }}
      // The Modal card defaults to min(380px, 100%) (confirm-dialog size);
      // plugins ship no stylesheet, so one scoped rule widens the card for
      // the browse layout.
      className="dsh-ssh-remote-flow"
      title={!target ? '添加工作区' : target.kind === 'local' ? '本机文件' : `SSH · ${target.alias}`}
      closeLabel="关闭"
      description={listing ? listing.path : '选择本机文件夹或 SSH 主机'}
      footer={
        <>
          <Button variant="ghost" disabled={busy || mutating} onClick={cancel}>取消</Button>
          {target && listing && (
            <Button variant="primary" disabled={disabled} onClick={() => void commit()}>
              {busy ? '正在添加…' : '打开此文件夹'}
            </Button>
          )}
        </>
      }
    >
      <style>{'.dsh-ssh-remote-flow{width:min(880px,94vw)}.dsh-ssh-remote-flow .dsh-ssh-remote-field{width:100%;box-sizing:border-box}'}</style>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {!target || !listing ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <Button
              variant="outline"
              disabled={disabled}
              onClick={() => void chooseLocal()}
              style={sourceRowStyle}
            >
              <strong>本机</strong>
              <span style={subtleText}>
                {localCanBrowse === false
                  ? '使用系统文件夹选择器'
                  : '在应用内浏览 Host 文件系统（含 /mnt 下的 Windows 盘）'}
              </span>
            </Button>
            <div style={hostListStyle}>
              {config?.hosts.map((host) => (
                <Button
                  key={host.alias}
                  variant="outline"
                  disabled={disabled}
                  onClick={() => void enter({ kind: 'ssh', alias: host.alias })}
                  style={sourceRowStyle}
                >
                  <strong>{host.alias}</strong>
                  <span style={subtleText}>
                    {host.user ? `${host.user}@` : ''}{host.host}:{host.port}
                  </span>
                  <span style={dimmedText}>
                    Helper · {helperStateLabel(host.helper.status)}
                    {host.helper.version ? ` · ${host.helper.version}` : ''}
                  </span>
                  {host.helper.error && <span style={{ ...dimmedText, color: 'var(--dsw-alias-label-error)' }}>{host.helper.error}</span>}
                  <span style={dimmedText}>{searchSummary(host.helper)}</span>
                </Button>
              ))}
              {!loading && config?.hosts.length === 0 && (
                <div style={subtleText}>~/.ssh/config 中没有可用的具体 Host。</div>
              )}
            </div>
          </div>
        ) : (
          <>
            <div style={{ display: 'flex', gap: 8 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <Input
                  aria-label="文件夹路径"
                  className="dsh-ssh-remote-field"
                  value={pathInput}
                  disabled={busy || mutating}
                  onChange={event => setPathInput(event.target.value)}
                  onKeyDown={event => {
                    if (event.key === 'Enter' && pathInput.trim()) navigate(pathInput.trim());
                  }}
                  placeholder="输入完整文件夹路径"
                />
              </div>
              <Button disabled={busy || mutating || !pathInput.trim()} onClick={() => navigate(pathInput.trim())}>前往</Button>
              <Button disabled={busy || mutating} onClick={() => navigate(listing.path)}>刷新目录</Button>
              <Button disabled={busy || mutating} onClick={() => navigate(listing.home)}>主目录</Button>
            </div>
            <div style={chipRowStyle}>
              <Pill disabled={disabled} onClick={() => { setTarget(null); setListing(null); }}>
                {target.kind === 'local' ? '本机' : '主机'}
              </Pill>
              {listing.crumbs.map((crumb) => (
                <Pill key={crumb.path} disabled={disabled} onClick={() => navigate(crumb.path)}>
                  {crumb.name}
                </Pill>
              ))}
            </div>
            {target.kind === 'local' && (
              <div style={chipRowStyle}>
                {(driveAnchors ?? []).map((anchor) => (
                  <Pill key={anchor.path} disabled={disabled} onClick={() => navigate(anchor.path)}>
                    {anchor.label}
                  </Pill>
                ))}
                {driveAnchors === null && <span style={subtleText}>检测 Windows 盘…</span>}
              </div>
            )}
            <div style={entryListStyle}>
              {listing.entries.map((entry) => (
                <Button
                  key={entry.path}
                  variant="ghost"
                  size="sm"
                  icon={<IconFolderCloseRegular />}
                  disabled={disabled}
                  onClick={() => navigate(entry.path)}
                  style={entryRowStyle}
                >
                  <span>{entry.name}</span>
                  {entry.hidden && <span style={{ marginLeft: 'auto', ...dimmedText }}>隐藏</span>}
                </Button>
              ))}
              {!loading && listing.entries.length === 0 && (
                <div style={{ padding: 16, ...dimmedText }}>此目录没有子文件夹。</div>
              )}
            </div>
            {listing.truncated && <div style={{ fontSize: 12, ...dimmedText }}>目录列表已截断（最多 1000 项）；未显示的文件夹可输入完整路径前往。</div>}
            <div style={{ display: 'flex', gap: 8 }}>
              <div style={{ flex: 1, minWidth: 0 }}>
                <Input
                  value={newFolder}
                  className="dsh-ssh-remote-field"
                  disabled={disabled}
                  onChange={(event) => setNewFolder(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === 'Enter') void createFolder();
                  }}
                  placeholder="新建文件夹名称"
                />
              </div>
              <Button
                variant="ghost"
                icon={<IconPlusOutlineRegular />}
                disabled={disabled || !newFolder.trim()}
                onClick={() => void createFolder()}
              >
                新建
              </Button>
            </div>
          </>
        )}

        {loading && <div role="status" style={subtleText}>正在读取…</div>}
        {error && <div role="alert" style={{ color: 'var(--dsw-alias-label-error)', fontSize: 12 }}>{error}</div>}
      </div>
    </Modal>
  );
}

const sourceRowStyle: CSSProperties = {
  flexDirection: 'column',
  alignItems: 'flex-start',
  gap: 2,
  width: '100%',
  height: 'auto',
  padding: '10px 14px',
};

const chipRowStyle: CSSProperties = { display: 'flex', flexWrap: 'wrap', gap: 6 };

const entryListStyle: CSSProperties = {
  maxHeight: 320,
  overflowY: 'auto',
  border: '1px solid var(--dsw-alias-border-l2)',
  borderRadius: 10,
  background: 'var(--dsw-alias-bg-layer-1)',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'stretch',
  gap: 2,
  padding: 6,
};

// The host/source picker list mirrors the directory list: bounded height so a
// large ~/.ssh/config cannot push the footer actions off-screen. "本机" stays
// pinned above it; only the SSH hosts scroll.
const hostListStyle: CSSProperties = {
  maxHeight: 'min(50vh, 420px)',
  overflowY: 'auto',
  display: 'flex',
  flexDirection: 'column',
  gap: 8,
  // Keep clickable buttons clear of the scrollbar gutter.
  paddingRight: 4,
};

const entryRowStyle: CSSProperties = { justifyContent: 'flex-start', flexShrink: 0 };

const subtleText: CSSProperties = { color: 'var(--dsw-alias-label-secondary)', fontSize: 12 };
const dimmedText: CSSProperties = { color: 'var(--dsw-alias-label-dimmed)', fontSize: 11 };

function helperStateLabel(state: HelperHostStatus['status']): string {
  return ({
    disconnected: '未连接',
    installing: '正在安装',
    connecting: '正在连接',
    connected: '已连接',
    degraded: '已连接（能力受限）',
    reconnecting: '正在重连',
    error: '错误',
  } as const)[state];
}

function helperCapabilitySummary(capabilities: Record<string, unknown>): string {
  const names = Object.entries(capabilities)
    .filter(([, value]) => value !== false && value !== null)
    .map(([name]) => name);
  return names.length === 0 ? '等待握手' : names.join(' · ');
}

function searchSummary(helper: HelperHostStatus): string {
  const search = helper.environment?.search;
  if (search === undefined) return '远程搜索：未检查（连接或重试后检查 rg）';
  return search.available
    ? `远程搜索：可用${search.version ? ` · ${search.version}` : ''}`
    : `远程搜索：不可用；请在远端安装 ripgrep，确保 rg 在登录环境 PATH 中，然后重试连接。${search.error ? ` ${search.error}` : ''}`;
}

type HostAction = 'connect' | 'disconnect' | 'retry' | 'diagnostics';

export function SshRemotePanel({ ssh }: { ssh: SshRemote }) {
  const [config, setConfig] = useState<SshConfig | null>(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [actions, setActions] = useState<Record<string, HostAction | undefined>>({});
  const [hostErrors, setHostErrors] = useState<Record<string, string | undefined>>({});
  const [details, setDetails] = useState<HelperHostDiagnostics | null>(null);
  const epoch = useRef(0);
  const mounted = useRef(false);
  const actionEpochs = useRef(new Map<string, number>());
  // Any host action invalidates status/config snapshots already in flight.
  const statusRevision = useRef(0);
  const polling = useRef<Promise<RemoteResult<Record<string, HelperHostStatus>>> | null>(null);

  async function load(showLoading = true) {
    const request = ++epoch.current;
    const revision = statusRevision.current;
    if (showLoading) setLoading(true);
    try {
      const result = await withReadDeadline(ssh.config(), 'SSH 配置读取');
      if (!mounted.current || epoch.current !== request) return;
      if (result.ok) {
        setConfig(current => revision === statusRevision.current || current === null ? result.value : {
          ...result.value,
          hosts: result.value.hosts.map(host => ({
            ...host,
            helper: current.hosts.find(previous => previous.alias === host.alias)?.helper ?? host.helper,
          })),
        });
        setError('');
      } else setError(result.error.message);
    } catch (reason) {
      if (mounted.current && epoch.current === request) setError(messageOf(reason));
    } finally {
      if (mounted.current && showLoading && epoch.current === request) setLoading(false);
    }
  }

  async function loadStatuses() {
    if (!mounted.current || polling.current !== null) return;
    const lifecycle = epoch.current;
    const revision = statusRevision.current;
    const operation = Promise.resolve().then(() => ssh.statuses());
    polling.current = operation;
    // Do not accumulate unresolved RPCs when the UI-side timeout fires.
    void operation.finally(() => {
      if (polling.current === operation) polling.current = null;
    }).catch(() => {});
    try {
      const result = await withReadDeadline(operation, '连接状态读取');
      if (!mounted.current || epoch.current !== lifecycle || statusRevision.current !== revision || !result.ok) return;
      setConfig(current => current === null ? current : {
        ...current,
        hosts: current.hosts.map(host => ({
          ...host,
          helper: actionEpochs.current.has(host.alias) ? host.helper : result.value[host.alias] ?? host.helper,
        })),
      });
    } catch {
      // The full refresh button remains the explicit diagnostic surface.
    }
  }

  useEffect(() => {
    mounted.current = true;
    void load();
    const timer = setInterval(() => { void loadStatuses(); }, 5_000);
    return () => {
      mounted.current = false;
      clearInterval(timer);
      epoch.current += 1;
      statusRevision.current += 1;
      actionEpochs.current.clear();
      polling.current = null;
    };
  }, [ssh]);

  async function runHostAction(
    alias: string,
    action: HostAction,
  ): Promise<void> {
    const request = ++statusRevision.current;
    actionEpochs.current.set(alias, request);
    const isCurrent = () => mounted.current && actionEpochs.current.get(alias) === request;
    setActions(current => ({ ...current, [alias]: action }));
    setHostErrors(current => ({ ...current, [alias]: undefined }));
    if (action === 'connect' || action === 'retry') {
      setConfig(current => current === null ? current : {
        ...current,
        hosts: current.hosts.map(host => host.alias === alias ? {
          ...host,
          helper: { ...host.helper, status: action === 'retry' ? 'reconnecting' : 'connecting', error: '' },
        } : host),
      });
    }
    try {
      const operation = action === 'connect'
        ? ssh.connectHost(alias)
        : action === 'disconnect'
          ? ssh.disconnectHost(alias)
          : action === 'retry'
            ? ssh.retryHost(alias)
            : ssh.diagnostics(alias);
      const result = await (action === 'diagnostics'
        ? withReadDeadline(operation, '连接诊断')
        : withMutationDeadline(operation, '主机操作'));
      if (!isCurrent()) return;
      if (!result.ok) setHostErrors(current => ({ ...current, [alias]: result.error.message }));
      else {
        if (action === 'diagnostics') setDetails(result.value as HelperHostDiagnostics);
        setConfig(current => current === null ? current : {
          ...current,
          hosts: current.hosts.map(host => host.alias === alias ? { ...host, helper: result.value } : host),
        });
      }
    } catch (reason) {
      if (isCurrent()) setHostErrors(current => ({ ...current, [alias]: messageOf(reason) }));
    } finally {
      if (isCurrent()) {
        actionEpochs.current.delete(alias);
        statusRevision.current += 1;
        setActions(current => ({ ...current, [alias]: undefined }));
      }
    }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14, padding: 12, maxWidth: 760 }}>
      <div style={{ display: 'flex', gap: 12, alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <h3 style={{ margin: 0 }}>SSH Connections</h3>
          <div style={{ marginTop: 4, color: 'var(--dsw-alias-label-secondary)', fontSize: 12 }}>
            连接由本机 OpenSSH 建立；版本化 helper 统一远端文件、进程和 PTY。显式断开会停止该 helper session 管理的远端进程。
          </div>
        </div>
        <Button variant="outline" size="sm" disabled={loading} onClick={() => void load()}>
          {loading ? '刷新中…' : '刷新'}
        </Button>
      </div>

      {config && (
        <div style={{ padding: 10, border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 8 }}>
          <div style={subtleText}>SSH config</div>
          <code style={{ fontSize: 12 }}>{config.configPath}</code>
          {!config.configExists && <div style={{ marginTop: 6, ...subtleText }}>请创建该文件并添加具体 Host 后刷新。</div>}
        </div>
      )}

      {config?.hosts.length === 0 && config.configExists && <div style={subtleText}>没有发现具体 SSH Host alias。</div>}

      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {config?.hosts.map((host) => {
          const action = actions[host.alias];
          const busy = action !== undefined;
          const canStop = action === 'connect' || action === 'retry'
            || ['connected', 'degraded', 'installing', 'connecting', 'reconnecting'].includes(host.helper.status);
          return (
            <div key={host.alias} role="group" aria-label={`SSH 主机 ${host.alias}`} style={{ padding: 12, border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 8 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}>
                <div style={{ fontWeight: 600 }}>{host.alias}</div>
                <span style={{ ...dimmedText, color: host.helper.status === 'error' ? 'var(--dsw-alias-label-error)' : undefined }}>
                  {helperStateLabel(host.helper.status)}
                </span>
              </div>
              <div style={{ ...subtleText, overflowWrap: 'anywhere' }}>
                {host.user ? `${host.user}@` : ''}{host.host}:{host.port}
              </div>
              <div style={{ marginTop: 6, ...dimmedText }}>
                Helper {host.helper.version || '尚未握手'} · {helperCapabilitySummary(host.helper.capabilities)}
              </div>
              <div style={{ marginTop: 6, ...subtleText }}>{searchSummary(host.helper)}</div>
              {(hostErrors[host.alias] || host.helper.error) && <div role="alert" style={{ marginTop: 6, color: 'var(--dsw-alias-label-error)', fontSize: 12 }}>{hostErrors[host.alias] || host.helper.error}</div>}
              {host.helper.hint && <div style={{ marginTop: 6, ...subtleText }}>{host.helper.hint}</div>}
              {(host.proxyJump || host.proxyCommand || host.identityFile) && (
                <div style={{ marginTop: 6, display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {host.proxyJump && <Pill>ProxyJump: {host.proxyJump}</Pill>}
                  {host.proxyCommand && <Pill>ProxyCommand</Pill>}
                  {host.identityFile && <Pill>Identity configured</Pill>}
                </div>
              )}
              <div style={{ marginTop: 10, display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {canStop ? (
                  <Button size="sm" variant="outline" disabled={action === 'disconnect'} onClick={() => void runHostAction(host.alias, 'disconnect')}>
                    {action === 'disconnect' ? '正在停止…' : '停止 / 断开'}
                  </Button>
                ) : (
                  <Button size="sm" variant="primary" disabled={busy} onClick={() => void runHostAction(host.alias, 'connect')}>
                    {busy ? '处理中…' : '连接'}
                  </Button>
                )}
                <Button size="sm" variant="outline" disabled={busy} onClick={() => void runHostAction(host.alias, 'retry')}>重试</Button>
                <Button size="sm" variant="ghost" disabled={busy} onClick={() => void runHostAction(host.alias, 'diagnostics')}>诊断</Button>
              </div>
            </div>
          );
        })}
      </div>

      {details && (
        <div style={{ padding: 12, border: '1px solid var(--dsw-alias-border-l2)', borderRadius: 8 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8 }}>
            <strong>{details.alias} · 诊断</strong>
            <Button size="sm" variant="ghost" onClick={() => setDetails(null)}>关闭</Button>
          </div>
          <pre style={{ margin: '8px 0 0', maxHeight: 260, overflow: 'auto', whiteSpace: 'pre-wrap', fontSize: 11 }}>
            {JSON.stringify(details, null, 2)}
          </pre>
        </div>
      )}

      {config && config.legacyHostCount > 0 && (
        <div style={subtleText}>
          仍有 {config.legacyHostCount} 个旧 DSH host 仅作为 SFTP 兼容兜底；请迁移到 <code>{config.configPath}</code>。
        </div>
      )}
      {error && <div role="alert" style={{ color: 'var(--dsw-alias-label-error)' }}>{error}</div>}
    </div>
  );
}
