import { execFile, spawn, type ChildProcess } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

export const HELPER_REMOTE_ROOT = '.local/share/dsh-remote-helper';
export const HELPER_STDERR_MAX_BYTES = 16 * 1024;
const UPLOAD_TERM_GRACE_MS = 500;
const UPLOAD_KILL_WAIT_MS = 1_000;

export interface HelperAsset {
  path: string;
  content: Buffer;
  sha256: string;
  remotePath: string;
}

export interface RemoteHelperInstallerOptions {
  assetPath?: string;
  sshBinary?: string;
  spawnProcess?: typeof spawn;
  timeoutMs?: number;
  /**
   * Pre-resolved local OpenSSH capabilities. When omitted, the installer probes
   * `ssh -G` once (cached) without loading user config. Inject in tests for
   * hermetic runs.
   */
  capabilities?: SshCapabilities;
}

export interface RemoteHelperInstallResult {
  alias: string;
  sha256: string;
  remotePath: string;
}

export class RemoteHelperInstallError extends Error {
  readonly stderr: string;
  readonly exitCode: number | null;
  readonly signal: NodeJS.Signals | null;

  constructor(
    message: string,
    details: { stderr?: string; exitCode?: number | null; signal?: NodeJS.Signals | null } = {},
    options?: ErrorOptions,
  ) {
    super(message, options);
    this.name = 'RemoteHelperInstallError';
    this.stderr = details.stderr ?? '';
    this.exitCode = details.exitCode ?? null;
    this.signal = details.signal ?? null;
  }
}

/** Locate the source asset both before and after TypeScript compilation. */
export function resolveHelperAssetPath(assetPath?: string): string {
  const candidates = assetPath === undefined
    ? [fileURLToPath(new URL('../../helper/dsh_remote_helper.py', import.meta.url))]
    : [assetPath];
  const found = candidates.find(existsSync);
  if (found === undefined) {
    throw new RemoteHelperInstallError(
      `dsh_remote_helper.py is missing (checked ${candidates.join(', ')})`,
    );
  }
  return found;
}

export function loadHelperAsset(assetPath?: string): HelperAsset {
  const path = resolveHelperAssetPath(assetPath);
  let content = readFileSync(path);
  // Keep deployment a single authenticated, content-addressed Python file.
  // Extension sources are packaged verbatim, and therefore covered by its SHA.
  if (content.includes('# DSH_BUNDLED_EXTENSIONS')) {
    const modules = ['dsh_transfer'];
    const embedded = modules.map(name => {
      const source = readFileSync(join(dirname(path), `${name}.py`), 'utf8');
      return `import types as _dsh_types\n_dsh_module = _dsh_types.ModuleType(${JSON.stringify(name)})\nexec(compile(${JSON.stringify(source)}, ${JSON.stringify(`<bundled:${name}>`)}, 'exec'), _dsh_module.__dict__)\nsys.modules[${JSON.stringify(name)}] = _dsh_module\n`;
    }).join('\n');
    content = Buffer.from(content.toString('utf8').replace('# DSH_BUNDLED_EXTENSIONS', embedded));
  }
  const sha256 = createHash('sha256').update(content).digest('hex');
  return {
    path,
    content,
    sha256,
    remotePath: helperRemotePath(sha256),
  };
}

export function helperRemotePath(sha256: string): string {
  assertSha256(sha256);
  return `$HOME/${HELPER_REMOTE_ROOT}/releases/${sha256}/helper.py`;
}

export function buildHelperConnectCommand(sha256: string): string {
  return `exec python3 \"${helperRemotePath(sha256)}\" connect --stdio`;
}

/**
 * Local OpenSSH transport options. RemoteCommand is present in 8.2;
 * SessionType and StdinNull appear in 8.7. Probe the actual binary since
 * vendors may backport features independently of the version banner.
 */
export interface SshCapabilities {
  readonly sessionTypeSupported: boolean;
}

/** Conservative default: assume a modern client (the original hard-coded behaviour). */
export const MODERN_SSH_CAPABILITIES: SshCapabilities = { sessionTypeSupported: true };

const capabilityCache = new Map<string, Promise<SshCapabilities>>();

/** Probe supported transport options without connecting to a host. */
export async function detectSshCapabilities(
  sshBinary = 'ssh',
  probeOptions: (binary: string) => Promise<boolean> = probeSystemSshOptions,
): Promise<SshCapabilities> {
  let probe = capabilityCache.get(sshBinary);
  if (!probe) {
    probe = (async () => {
      try {
        return { sessionTypeSupported: await probeOptions(sshBinary) };
      } catch {
        return { sessionTypeSupported: false };
      }
    })();
    capabilityCache.set(sshBinary, probe);
  }
  return probe;
}

/** Test-only: clear the cached capability probe between isolated runs. */
export function resetSshCapabilityCache(): void {
  capabilityCache.clear();
}

/** `-G` expands isolated options and never opens a network connection. */
function probeSystemSshOptions(sshBinary: string): Promise<boolean> {
  return new Promise((resolve) => {
    execFile(sshBinary, [
      '-F', '/dev/null', '-G',
      '-o', 'SessionType=default', '-o', 'StdinNull=no',
      'probe.invalid',
    ], { encoding: 'utf8', timeout: 5_000, maxBuffer: 64 * 1024 }, (error) => {
      resolve(error === null);
    });
  });
}

export function buildSystemSshArgs(
  alias: string,
  remoteCommand: string,
  capabilities: SshCapabilities = MODERN_SSH_CAPABILITIES,
): string[] {
  assertSshAlias(alias);
  const args = ['-T', '-o', 'BatchMode=yes'];
  // RemoteCommand is supported by OpenSSH 8.2 and must always override a
  // Host-level remote command when the helper sends its own command.
  args.push('-o', 'RemoteCommand=none');
  if (capabilities.sessionTypeSupported) {
    args.push('-o', 'SessionType=default', '-o', 'StdinNull=no');
  }
  args.push(
    '-o', 'ConnectTimeout=15',
    '-o', 'ServerAliveInterval=15',
    '-o', 'ServerAliveCountMax=3',
    '--', alias,
    remoteCommand,
  );
  return args;
}

/**
 * Redact credential-shaped diagnostics before retaining or publishing them.
 * This is deliberately conservative: diagnostics are for classification, not
 * a byte-perfect copy of a user's SSH environment.
 */
export function redactHelperDiagnostic(value: string): string {
  return value
    .replace(/-----BEGIN [^-]*(?:PRIVATE|SECRET)[^-]*-----[\s\S]*?-----END [^-]*-----/giu, '[REDACTED PRIVATE MATERIAL]')
    .replace(/\b(password|passphrase|token|secret|authorization)\s*[:=]\s*([^\s,;]+)/giu, '$1=[REDACTED]')
    .replace(/\bSSH_AUTH_SOCK\s*=\s*[^\s]+/gu, 'SSH_AUTH_SOCK=[REDACTED]')
    .replace(/\/(?:Users|home)\/[^/\s]+/gu, '~');
}

export class RemoteHelperInstaller {
  readonly asset: HelperAsset;
  private readonly sshBinary: string;
  private readonly spawnProcess: typeof spawn;
  private readonly timeoutMs: number;
  private readonly capabilities?: SshCapabilities;

  constructor(options: RemoteHelperInstallerOptions = {}) {
    this.asset = loadHelperAsset(options.assetPath);
    this.sshBinary = options.sshBinary ?? 'ssh';
    this.spawnProcess = options.spawnProcess ?? spawn;
    this.timeoutMs = options.timeoutMs ?? 30_000;
    this.capabilities = options.capabilities;
  }

  async install(alias: string, signal?: AbortSignal): Promise<RemoteHelperInstallResult> {
    assertSshAlias(alias);
    signal?.throwIfAborted();
    const capabilities = this.capabilities ?? await detectSshCapabilities(this.sshBinary);
    signal?.throwIfAborted();
    const script = installScript(this.asset.sha256);
    const args = buildSystemSshArgs(alias, `sh -c ${shellQuote(script)}`, capabilities);
    const child = this.spawnProcess(this.sshBinary, args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
    });
    const result = await runUploadProcess(
      child,
      this.asset.content,
      signal,
      this.timeoutMs,
    );
    if (result.code !== 0) {
      throw new RemoteHelperInstallError(
        `remote helper installation failed for ${alias}${result.stderr ? `: ${result.stderr}` : ''}`,
        { stderr: result.stderr, exitCode: result.code, signal: result.signal },
      );
    }
    return { alias, sha256: this.asset.sha256, remotePath: this.asset.remotePath };
  }
}

function installScript(sha256: string): string {
  assertSha256(sha256);
  const relativeRoot = HELPER_REMOTE_ROOT;
  return [
    'set -eu',
    'umask 077',
    `base="$HOME/${relativeRoot}"`,
    `release="$base/releases/${sha256}"`,
    'target="$release/helper.py"',
    'mkdir -p "$base/releases" "$release"',
    'chmod 700 "$base" "$base/releases" "$release"',
    'tmp="$release/.helper.py.tmp.$$"',
    'trap \'rm -f "$tmp"\' EXIT HUP INT TERM',
    'cat > "$tmp"',
    `python3 -c ${shellQuote("import hashlib,sys; p,e=sys.argv[1:]; a=hashlib.sha256(open(p,'rb').read()).hexdigest(); raise SystemExit(0 if a == e else 'helper sha256 mismatch')")} "$tmp" ${sha256}`,
    'chmod 600 "$tmp"',
    'mv -f "$tmp" "$target"',
    'trap - EXIT HUP INT TERM',
  ].join('\n');
}

function runUploadProcess(
  child: ChildProcess,
  content: Buffer,
  signal: AbortSignal | undefined,
  timeoutMs: number,
): Promise<{ code: number | null; signal: NodeJS.Signals | null; stderr: string }> {
  return new Promise((resolve, reject) => {
    let settled = false;
    let stopping = false;
    let failure: unknown;
    let stderr = '';
    let termTimer: ReturnType<typeof setTimeout> | undefined;
    let cleanupTimer: ReturnType<typeof setTimeout> | undefined;
    const cleanupErrors: string[] = [];
    const finish = (run: () => void): void => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      clearTimeout(termTimer);
      clearTimeout(cleanupTimer);
      signal?.removeEventListener('abort', onAbort);
      run();
    };
    const sendSignal = (name: NodeJS.Signals): void => {
      // killed only means a signal was sent, not that the child exited. Never
      // signal an already-exited child while waiting for inherited stdio to close.
      if (settled || child.exitCode !== null || child.signalCode !== null || child.pid === undefined) return;
      try {
        if (!child.kill(name)) cleanupErrors.push(`${name} was not delivered`);
      } catch (error) {
        cleanupErrors.push(`${name}: ${String(error)}`);
      }
    };
    const terminate = (error: unknown): void => {
      if (settled || stopping) return;
      stopping = true;
      failure = error;
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
      // Wait for close even after KILL: receiving a signal is not evidence that
      // the owned SSH child has been reaped or its pipes have been closed.
      termTimer = setTimeout(() => sendSignal('SIGKILL'), UPLOAD_TERM_GRACE_MS);
      cleanupTimer = setTimeout(() => {
        const reason = error instanceof Error ? error.message : String(error);
        const diagnostics = cleanupErrors.length ? ` (${cleanupErrors.join('; ')})` : '';
        finish(() => reject(new RemoteHelperInstallError(
          `${reason}; SSH installer cleanup failed: child close was not observed after ${UPLOAD_TERM_GRACE_MS + UPLOAD_KILL_WAIT_MS}ms${diagnostics}`,
          { stderr: boundedDiagnostic(stderr), exitCode: child.exitCode, signal: child.signalCode },
          { cause: error },
        )));
      }, UPLOAD_TERM_GRACE_MS + UPLOAD_KILL_WAIT_MS);
      sendSignal('SIGTERM');
    };
    // SSH may exit while the helper body is still being uploaded. The resulting
    // asynchronous EPIPE is emitted by stdin, not thrown by end(). Consume it at
    // the process boundary so a failed remote connection cannot terminate DSH.
    child.stdin?.on('error', (error) => {
      terminate(new RemoteHelperInstallError('failed to upload remote helper', {
        stderr: boundedDiagnostic(stderr),
      }, { cause: error }));
    });
    const onAbort = (): void => {
      terminate(signal?.reason ?? new Error('remote helper installation aborted'));
    };
    const timer = setTimeout(() => {
      terminate(new RemoteHelperInstallError(`remote helper installation timed out after ${timeoutMs}ms`, {
        stderr: boundedDiagnostic(stderr),
      }));
    }, timeoutMs);
    child.stderr?.on('data', (chunk: Buffer | string) => {
      stderr = boundedDiagnostic(`${stderr}${String(chunk)}`);
    });
    // The install script intentionally emits nothing, but a remote sshrc may.
    // Drain it so an untrusted banner cannot backpressure the upload process.
    child.stdout?.on('data', () => {});
    child.on('error', (error) => {
      if (stopping) {
        cleanupErrors.push(error.message);
      } else {
        terminate(new RemoteHelperInstallError(
          `failed to start system SSH: ${error.message}`,
          { stderr: boundedDiagnostic(stderr) },
          { cause: error },
        ));
      }
    });
    child.once('close', (code, childSignal) => finish(() => {
      if (stopping) reject(failure);
      else resolve({ code, signal: childSignal, stderr: boundedDiagnostic(stderr) });
    }));
    if (child.stdin === null || child.stdout === null || child.stderr === null) {
      terminate(new RemoteHelperInstallError('SSH installer did not expose piped stdio'));
      return;
    }
    if (signal?.aborted) {
      onAbort();
      return;
    }
    signal?.addEventListener('abort', onAbort, { once: true });
    try {
      child.stdin.end(content);
    } catch (error) {
      terminate(new RemoteHelperInstallError('failed to upload remote helper', {
        stderr: boundedDiagnostic(stderr),
      }, { cause: error as Error }));
    }
  });
}

function boundedDiagnostic(value: string): string {
  const sanitized = redactHelperDiagnostic(value);
  const bytes = Buffer.from(sanitized, 'utf8');
  if (bytes.length <= HELPER_STDERR_MAX_BYTES) return sanitized.trim();
  let start = bytes.length - HELPER_STDERR_MAX_BYTES;
  while (start < bytes.length && (bytes[start] & 0xc0) === 0x80) start += 1;
  return bytes.subarray(start).toString('utf8').trim();
}

function shellQuote(value: string): string {
  return `'${value.replaceAll("'", `'\\''`)}'`;
}

function assertSha256(value: string): void {
  if (!/^[a-f0-9]{64}$/u.test(value)) throw new Error('invalid helper sha256');
}

export function assertSshAlias(alias: string): void {
  if (!alias || alias.startsWith('-') || /[\s\0\r\n]/u.test(alias)) {
    throw new Error(`invalid SSH alias: ${JSON.stringify(alias)}`);
  }
}
