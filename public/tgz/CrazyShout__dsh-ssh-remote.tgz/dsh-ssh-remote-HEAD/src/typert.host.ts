import { z } from 'zod';
import { editorInvocations } from './editor-schema.js';
import { fileSearchInvocations } from './file-search-schema.js';

const string = z.string();
const helperStatus = z.object({
  status: z.enum(['disconnected', 'installing', 'connecting', 'connected', 'degraded', 'reconnecting', 'error']),
  version: string,
  sessionId: string,
  capabilities: z.record(z.string(), z.unknown()),
  error: string,
  errorCode: string.optional(),
  retryable: z.boolean().optional(),
  hint: string.optional(),
  environment: z.object({ search: z.object({
    available: z.boolean(), path: string.optional(), version: string.optional(), error: string.optional(),
  }) }).optional(),
});
const host = z.object({
  alias: string,
  host: string,
  port: z.number(),
  user: string,
  identityFile: string,
  proxyJump: string,
  proxyCommand: string,
  helper: helperStatus,
});
const config = z.object({
  configPath: string,
  configExists: z.boolean(),
  hosts: z.array(host),
  legacyHostCount: z.number(),
});
const directoryEntry = z.object({ name: string, path: string, hidden: z.boolean() });
const directoryListing = z.object({
  path: string,
  home: string,
  crumbs: z.array(directoryEntry),
  entries: z.array(directoryEntry),
  truncated: z.boolean(),
});
const workspaceAnchor = z.object({
  anchorPath: string,
  uri: string,
  alias: string,
  remotePath: string,
  title: string,
  createdAt: z.number(),
});
const workspaceInfo = z.object({ alias: string, remotePath: string, uri: string }).nullable();
const diagnostics = helperStatus.extend({
  alias: string,
  helperSha256: string,
  lastConnectedAt: z.number(),
  lastHealthAt: z.number(),
  nextRetryAt: z.number(),
  stderr: string,
  assetPath: string,
});

function parameter(name: string) {
  return {
    name,
    wire: name,
    source: 'json',
    codec: { mode: 'strict', typeSymbol: `dsh-ssh-remote#${name}`, create: () => string },
  };
}

function invocation(method: string, parameters: unknown[], schema: z.ZodType, typeSymbol: string) {
  return {
    id: `dsh-ssh-remote#sshRemote/${method}`,
    service: 'sshRemote',
    namespace: 'sshRemote',
    method,
    invocation: { kind: 'direct' },
    parameters,
    result: { mode: 'strict', typeSymbol, create: () => schema },
    sourceLocation: { file: 'src/registry.ts', line: 1, column: 1 },
  };
}

/** Deterministic host-face descriptor discovered through package export ./typert. */
export const TYPERT = {
  package: 'dsh-ssh-remote',
  face: 'host',
  schemas: [],
  invocations: [
    invocation('config', [], config, 'dsh-ssh-remote#SshConfig'),
    invocation('statuses', [], z.record(z.string(), helperStatus), 'dsh-ssh-remote#HelperHostStatuses'),
    invocation('workspaceInfo', [parameter('path')], workspaceInfo, 'dsh-ssh-remote#RemoteWorkspaceInfo'),
    invocation('browse', [parameter('alias'), parameter('path')], directoryListing, 'dsh-ssh-remote#RemoteDirectoryListing'),
    invocation('createDirectory', [parameter('alias'), parameter('parent'), parameter('name')], string, 'string'),
    invocation('materializeWorkspace', [parameter('alias'), parameter('remotePath')], workspaceAnchor, 'dsh-ssh-remote#SshWorkspaceAnchor'),
    invocation('connectHost', [parameter('alias')], helperStatus, 'dsh-ssh-remote#HelperHostStatus'),
    invocation('disconnectHost', [parameter('alias')], helperStatus, 'dsh-ssh-remote#HelperHostStatus'),
    invocation('retryHost', [parameter('alias')], helperStatus, 'dsh-ssh-remote#HelperHostStatus'),
    invocation('diagnostics', [parameter('alias')], diagnostics, 'dsh-ssh-remote#HelperHostDiagnostics'),
    ...editorInvocations,
    ...fileSearchInvocations,
  ],
  model: { services: [], events: [], objects: [] },
};
