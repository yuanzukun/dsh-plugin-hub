import FileSystem, { FsError, type FsTarget } from '@deepseek-ai/dsh-fs';
import type { SandboxExecutionPolicy } from '@deepseek-ai/dsh-sandbox';
import type {
  SubprocessRuntime,
  SubprocessSpawnSpec,
  SubprocessTerminalSpawnSpec,
} from '@deepseek-ai/dsh-subprocess';
import type { TerminalSessionService, TerminalSpawnRequest } from '@deepseek-ai/dsh-terminal';
import { HelperRemoteFileSystem, type RemoteHelperProvider } from './helper-fs.js';
import { parseSshUri, type SshUri } from './types.js';

type AnyFunction = (...args: any[]) => any;

/** Resolve a registered local anchor or descendant to an SSH URI. */
export type RemotePathResolver = (path: string) => string | undefined;

function isSshPath(value: unknown): value is string {
  return typeof value === 'string' && value.startsWith('ssh://');
}

function isSshTarget(value: unknown): boolean {
  if (!value || typeof value !== 'object') return false;
  return isSshPath(String((value as { targetKey?: unknown }).targetKey ?? ''));
}

/**
 * Add exact SSH URI routing to DSH's filesystem service. Local paths always
 * call the original provider; only direct SSH URIs and paths beneath a
 * persisted remote Workspace anchor use the helper.
 */
export function installRemoteFileSystemRouter(
  fs: FileSystem,
  resolveRemotePath: RemotePathResolver,
  helpers: RemoteHelperProvider,
): () => void {
  const remote = new HelperRemoteFileSystem(helpers, resolveRemotePath);
  const originals = new Map<string, AnyFunction>();
  const remember = (name: string) => {
    const original = (fs as unknown as Record<string, AnyFunction>)[name];
    if (typeof original !== 'function') throw new Error(`ctx.fs.${name} is unavailable`);
    originals.set(name, original);
    return original;
  };
  const asRemotePath = (path: string | undefined) => {
    if (path === undefined) return undefined;
    return isSshPath(path) ? path : resolveRemotePath(path);
  };

  const checkedRemoteWriteTarget = async (
    target: FsTarget,
    policy?: SandboxExecutionPolicy,
  ): Promise<FsTarget> => {
    const fallbackMode = (fs as unknown as { sandboxMode?: string }).sandboxMode;
    const mode = policy?.mode ?? fallbackMode;
    if (mode === 'read-only') {
      throw new FsError(`cannot write "${target.displayPath}": remote file access denied under read-only mode`, 'FS_SANDBOX_DENIED');
    }
    if (mode === 'danger-full-access' || mode === undefined) return target;
    if (mode !== 'workspace-write' || policy === undefined) {
      throw new FsError(`cannot write "${target.displayPath}": missing remote workspace policy`, 'FS_SANDBOX_DENIED');
    }
    const remoteRoot = asRemotePath(policy.workspaceRoot);
    if (remoteRoot === undefined) {
      throw new FsError(`cannot write "${target.displayPath}": workspace root is not mapped to this SSH host`, 'FS_SANDBOX_DENIED');
    }
    // Re-canonicalize both identities immediately before mutation. This is the
    // remote equivalent of dsh-fs-sandbox's checkedTarget critical edge.
    const [fresh, root] = await Promise.all([
      remote.resolve(String(target.targetKey)),
      remote.resolve(remoteRoot),
    ]);
    if (!remote.contains(root, fresh)) {
      throw new FsError(`cannot write "${target.displayPath}": remote file access denied outside workspace`, 'FS_SANDBOX_DENIED');
    }
    return fresh;
  };

  const originalResolve = remember('resolve');
  (fs as any).resolve = (path: string, opts?: { cwd?: string; signal?: AbortSignal }) => {
    const remoteCwd = asRemotePath(opts?.cwd);
    const remotePath = asRemotePath(path);
    if (remoteCwd !== undefined) {
      return remote.resolve(remotePath ?? path, { ...opts, cwd: remoteCwd });
    }
    if (remotePath !== undefined) return remote.resolve(remotePath, opts);
    return originalResolve.call(fs, path, opts);
  };

  const originalLstat = remember('lstat');
  (fs as any).lstat = (path: string, opts?: { cwd?: string }, signal?: AbortSignal) => {
    const remoteCwd = asRemotePath(opts?.cwd);
    const remotePath = asRemotePath(path);
    if (remoteCwd !== undefined) {
      return remote.lstat(remotePath ?? path, { ...opts, cwd: remoteCwd }, signal);
    }
    if (remotePath !== undefined) return remote.lstat(remotePath, opts, signal);
    return originalLstat.call(fs, path, opts, signal);
  };

  // DSH 0.1.2 adds this optional host→execution-world visibility seam. Keep
  // rc.2 compatibility while mapping persisted anchors when the newer method
  // exists, so an upgrade does not reinterpret an anchor as a local path.
  const processPathFromHostPath = (fs as unknown as Record<string, AnyFunction>).processPathFromHostPath;
  if (typeof processPathFromHostPath === 'function') {
    originals.set('processPathFromHostPath', processPathFromHostPath);
    (fs as unknown as Record<string, AnyFunction>).processPathFromHostPath = (hostPath: string) => {
      const remotePath = resolveRemotePath(hostPath);
      return remotePath === undefined
        ? processPathFromHostPath.call(fs, hostPath)
        : parseSshUri(remotePath).path;
    };
  }

  for (const name of [
    'processPath',
    'fileUrl',
    'stat',
    'readText',
    'streamText',
    'readBytes',
    'listDir',
  ]) {
    const original = remember(name);
    (fs as unknown as Record<string, AnyFunction>)[name] = (...args: any[]) =>
      isSshTarget(args[0])
        ? (remote as unknown as Record<string, AnyFunction>)[name](...args)
        : original.call(fs, ...args);
  }

  // DSH 0.2.0 adds readByteRange for ranged file reads (e.g. workspace file
  // previews). Intercept it the same way when the host provides it; older DSH
  // versions and test mocks without it are unaffected.
  const originalReadByteRange = (fs as unknown as Record<string, AnyFunction>).readByteRange;
  if (typeof originalReadByteRange === 'function') {
    originals.set('readByteRange', originalReadByteRange);
    (fs as unknown as Record<string, AnyFunction>).readByteRange = (...args: any[]) =>
      isSshTarget(args[0])
        ? (remote as unknown as Record<string, AnyFunction>).readByteRange(...args)
        : originalReadByteRange.call(fs, ...args);
  }

  // The native Files/Preview UI subscribes through ctx.fs.watch. Never hand
  // an execution-world SSH target to the local watcher. The official feed
  // translates this unsupported-provider error into its manual-refresh mode.
  const originalWatch = (fs as unknown as Record<string, AnyFunction>).watch;
  if (typeof originalWatch === 'function') {
    originals.set('watch', originalWatch);
    (fs as unknown as Record<string, AnyFunction>).watch = (...args: any[]) => isSshTarget(args[0])
      ? Promise.reject(new FsError('Remote file watching is unavailable; use the file panel refresh control.', 'FS_IO_ERROR'))
      : originalWatch.call(fs, ...args);
  }

  const originalWriteText = remember('writeText');
  (fs as any).writeText = async (
    target: FsTarget,
    content: string,
    expected?: unknown,
    signal?: AbortSignal,
    sandboxPolicy?: SandboxExecutionPolicy,
  ) => isSshTarget(target)
    ? remote.writeText(await checkedRemoteWriteTarget(target, sandboxPolicy), content, expected as never, signal, sandboxPolicy)
    : originalWriteText.call(fs, target, content, expected, signal, sandboxPolicy);

  const originalEditText = remember('editText');
  (fs as any).editText = async (
    target: FsTarget,
    edit: unknown,
    expected?: unknown,
    signal?: AbortSignal,
    sandboxPolicy?: SandboxExecutionPolicy,
  ) => isSshTarget(target)
    ? remote.editText(await checkedRemoteWriteTarget(target, sandboxPolicy), edit as never, expected as never, signal, sandboxPolicy)
    : originalEditText.call(fs, target, edit, expected, signal, sandboxPolicy);

  const originalContains = remember('contains');
  (fs as any).contains = (parent: unknown, child: unknown) => {
    const parentRemote = isSshTarget(parent);
    const childRemote = isSshTarget(child);
    if (parentRemote !== childRemote) return false;
    return parentRemote
      ? remote.contains(parent as any, child as any)
      : originalContains.call(fs, parent, child);
  };

  return () => {
    for (const [name, original] of originals) {
      (fs as unknown as Record<string, AnyFunction>)[name] = original;
    }
  };
}

function shellQuote(value: string): string {
  return `'${value.replaceAll("'", `'\\''`)}'`;
}

function sameRemote(left: SshUri, right: SshUri): boolean {
  return left.host === right.host && left.port === right.port && left.user === right.user;
}

function remoteArgv(cwd: SshUri, argv: readonly string[], resolveRemotePath?: RemotePathResolver): readonly string[] {
  const executable = argv[0];
  if (executable === undefined) return argv;
  const normalized = executable.replaceAll('\\', '/');
  if (!/(?:^|\/)@vscode\/ripgrep(?:-[a-z0-9-]+)?\/bin\/rg(?:\.exe)?$/u.test(normalized)) {
    return argv;
  }
  const rewritten = ['rg', ...argv.slice(1)];
  const separator = rewritten.indexOf('--');
  // DSH's glob/grep templates use long flags (values in --flag=value form)
  // followed by optional roots behind `--`. Limit path rewriting to those
  // templates: arbitrary rg invocations may put a PATTERN behind `--`, and
  // explicit roots without a separator must not be widened by appending `.`.
  const options = rewritten.slice(1, separator === -1 ? undefined : separator);
  const dshSearch = options.every(value => value.startsWith('--')) && (
    options.includes('--files')
    || (options.includes('--json') && options.some(value => value.startsWith('--regexp=')))
  );
  if (!dshSearch) return rewritten;
  // In particular, pathless grep must search cwd, not the SSH stdin pipe.
  if (separator === -1) return [...rewritten, '--', '.'];
  if (separator === rewritten.length - 1) return [...rewritten, '.'];
  return rewritten.map((value, index) => {
    if (index <= separator) return value;
    const mapped = isSshPath(value) ? value : resolveRemotePath?.(value);
    if (mapped === undefined) return value;
    const mappedUri = parseSshUri(mapped);
    if (!sameRemote(cwd, mappedUri)) throw new Error('remote ripgrep search root belongs to a different SSH host');
    return mappedUri.path;
  });
}

/** Build the local OpenSSH argv used for a remote process or terminal. */
export function buildRemoteSshInvocation(
  cwd: string,
  argv: readonly string[],
  env: NodeJS.ProcessEnv | undefined,
  terminal: boolean,
  resolveRemotePath?: RemotePathResolver,
): readonly string[] {
  if (argv.length === 0) throw new Error('remote subprocess argv is empty');
  const uri = parseSshUri(cwd);
  const destination = `${uri.user ? `${uri.user}@` : ''}${uri.host}`;
  const environment = Object.entries(env ?? {})
    .filter((entry): entry is [string, string] => entry[1] !== undefined)
    .filter(([key]) => /^[A-Za-z_][A-Za-z0-9_]*$/.test(key))
    .map(([key, value]) => shellQuote(`${key}=${value}`));
  const command = remoteArgv(uri, argv, resolveRemotePath).map(shellQuote);
  const exec = environment.length > 0
    ? `exec env ${environment.join(' ')} ${command.join(' ')}`
    : `exec ${command.join(' ')}`;
  const script = `cd ${shellQuote(uri.path)} && ${exec}`;
  const args = ['ssh', terminal ? '-tt' : '-T'];
  // Port 22 stays absent so an alias-specific Port from ~/.ssh/config wins.
  if (uri.port !== 22) args.push('-p', String(uri.port));
  // End local OpenSSH option parsing before the destination. URI validation
  // also rejects option-like users/hosts; this is defense in depth.
  args.push('--', destination, `sh -lc ${shellQuote(script)}`);
  return args;
}

/**
 * Route process execution by Workspace cwd. The stock local provider still
 * owns stream collection, PTY behavior, cancellation and teardown; for a
 * mapped cwd its managed child is the system OpenSSH client.
 */
export function installRemoteSubprocessRouter(
  subprocess: SubprocessRuntime,
  resolveRemotePath: RemotePathResolver,
): () => void {
  const originalSpawn = subprocess.spawn;
  const originalSpawnTerminal = subprocess.spawnTerminal;

  subprocess.spawn = function (spec: SubprocessSpawnSpec) {
    const remoteCwd = isSshPath(spec.cwd) ? spec.cwd : resolveRemotePath(spec.cwd);
    if (remoteCwd === undefined) return originalSpawn.call(subprocess, spec);
    return originalSpawn.call(subprocess, {
      ...spec,
      argv: buildRemoteSshInvocation(remoteCwd, spec.argv, spec.env, false, resolveRemotePath),
      cwd: process.cwd(),
      env: undefined,
    });
  };

  subprocess.spawnTerminal = function (spec: SubprocessTerminalSpawnSpec) {
    const remoteCwd = isSshPath(spec.cwd) ? spec.cwd : resolveRemotePath(spec.cwd);
    if (remoteCwd === undefined) return originalSpawnTerminal.call(subprocess, spec);
    return originalSpawnTerminal.call(subprocess, {
      ...spec,
      argv: buildRemoteSshInvocation(remoteCwd, spec.argv, spec.env, true, resolveRemotePath),
      cwd: process.cwd(),
      env: undefined,
    });
  };

  return () => {
    subprocess.spawn = originalSpawn;
    subprocess.spawnTerminal = originalSpawnTerminal;
  };
}

/**
 * Route persistent PTY sessions by workspace cwd. A remote cwd selects the
 * `ssh` backend (see `RemoteTerminalBackend`); local sessions keep the stock
 * `bash` backend untouched.
 */
export function installRemoteTerminalRouter(
  terminals: TerminalSessionService,
  resolveRemotePath: RemotePathResolver,
): () => void {
  const originalSpawn = terminals.spawn;
  terminals.spawn = function (owner, request: TerminalSpawnRequest, signal?: AbortSignal) {
    const cwd = request.cwd;
    const remote = cwd !== undefined && (cwd.startsWith('ssh://') || resolveRemotePath(cwd) !== undefined);
    if (!remote) return originalSpawn.call(terminals, owner, request, signal);
    return originalSpawn.call(terminals, owner, { ...request, type: 'ssh' }, signal);
  };
  return () => {
    terminals.spawn = originalSpawn;
  };
}
