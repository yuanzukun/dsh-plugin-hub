import { Context } from '@deepseek-ai/cordis';
import FileSystem, {
  FsError,
  FsTargetKey,
  FsVersion,
  type FsDirEntry,
  type FsEditOutcome,
  type FsEditRequest,
  type FsInfo,
  type FsPathInfo,
  type FsTarget,
  type FsWriteIntent,
  type FsWriteOutcome,
} from '@deepseek-ai/dsh-fs';
import type { SFTPWrapper, Stats } from 'ssh2';
import { randomBytes } from 'node:crypto';
import { posix } from 'node:path';
import { finished } from 'node:stream/promises';
import { SshConnectionManager } from './connection.js';
import { formatSshUri, parseSshUri, type SshUri } from './types.js';

/** Remote `ssh://` filesystem provider: implements the FileSystem seam over SFTP. */
export class RemoteFileSystem extends FileSystem {
  /** Default base for relative-path resolution: the workspace's ssh:// root. */
  private readonly baseUri: SshUri;
  /** Serialize mutation critical sections per canonical remote target. */
  private readonly mutations = new Map<string, Promise<unknown>>();

  constructor(
    ctx: Context,
    private readonly connections: SshConnectionManager,
    baseUri: string,
  ) {
    super(ctx);
    this.baseUri = normalizeSshUri(parseSshUri(baseUri));
  }

  get sandboxMode(): undefined {
    return undefined;
  }

  async resolve(
    path: string,
    opts?: { cwd?: string; signal?: AbortSignal },
  ): Promise<FsTarget> {
    const parsed = this.parseTargetPath(path, opts?.cwd);
    let uri: SshUri;
    try {
      uri = { ...parsed, path: await this.canonicalizePath(parsed, opts?.signal) };
    } catch (error) {
      if (error instanceof FsError) throw error;
      throw this.mapError(error);
    }
    const key = formatSshUri(uri);
    return { targetKey: FsTargetKey(key), displayPath: `${uri.user ? uri.user + '@' : ''}${uri.host}:${uri.path}` };
  }

  processPath(target: FsTarget): string {
    // Remote absolute path in the backend's execution world.
    return normalizeRemote(parseSshUri(String(target.targetKey)).path);
  }

  fileUrl(target: FsTarget): string {
    const remotePath = normalizeRemote(parseSshUri(String(target.targetKey)).path);
    const url = new URL('file:///');
    url.pathname = remotePath;
    return url.href;
  }

  contains(parent: FsTarget, child: FsTarget): boolean {
    const p = normalizeSshUri(parseSshUri(String(parent.targetKey)));
    const c = normalizeSshUri(parseSshUri(String(child.targetKey)));
    if (p.host !== c.host || p.port !== c.port || p.user !== c.user) return false;
    const pp = ensureTrailingSlash(p.path);
    return c.path === p.path || c.path.startsWith(pp);
  }

  async stat(target: FsTarget, signal?: AbortSignal): Promise<FsInfo | undefined> {
    const { uri, path } = this.split(target);
    try {
      const st = await this.sftp(uri, (s) => promisify<Stats>((cb) => s.stat(path, cb), signal));
      return statToFsInfo(st);
    } catch (e) {
      if (isCode(e, 'ENOENT')) return undefined;
      throw this.mapError(e);
    }
  }

  async lstat(path: string, opts?: { cwd?: string }, signal?: AbortSignal): Promise<FsPathInfo | undefined> {
    const uri = this.parseTargetPath(path, opts?.cwd);
    try {
      const st = await this.sftp(uri, (s) => promisify<Stats>((cb) => s.lstat(uri.path, cb), signal));
      return statToPathInfo(st);
    } catch (e) {
      if (isCode(e, 'ENOENT')) return undefined;
      throw this.mapError(e);
    }
  }

  async readText(target: FsTarget, signal?: AbortSignal): Promise<string> {
    const { uri, path } = this.split(target);
    const buf = await this.readFile(uri, path, signal);
    return decodeText(buf);
  }

  async streamText(target: FsTarget, signal?: AbortSignal): Promise<AsyncIterable<string>> {
    const { uri, path } = this.split(target);
    signal?.throwIfAborted();
    const stream = await this.sftp(uri, async (sftp) => sftp.createReadStream(path));
    const mapError = (error: unknown): FsError => this.mapError(error);
    return {
      async *[Symbol.asyncIterator]() {
        const decoder = new TextDecoder('utf-8', { fatal: true });
        const aborted = new FsError('aborted', 'FS_ABORTED');
        const completion = finished(stream);
        // Attach a rejection observer immediately; the generator may be paused
        // at a yielded chunk when the underlying SFTP handle reports an error.
        void completion.catch(() => {});
        const onAbort = (): void => {
          stream.destroy(aborted);
        };
        if (signal?.aborted) {
          stream.destroy();
          throw aborted;
        }
        signal?.addEventListener('abort', onAbort, { once: true });
        try {
          for await (const chunk of stream) {
            const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
            if (bytes.includes(0)) throw new FsError('binary file', 'FS_NOT_TEXT');
            let text: string;
            try {
              text = decoder.decode(bytes, { stream: true });
            } catch {
              throw new FsError('not valid UTF-8', 'FS_NOT_TEXT');
            }
            if (text.length > 0) yield text;
          }
          let tail: string;
          try {
            tail = decoder.decode();
          } catch {
            throw new FsError('not valid UTF-8', 'FS_NOT_TEXT');
          }
          if (tail.length > 0) yield tail;
          // Async iteration reaches readable `end` before ssh2 necessarily
          // receives the remote CLOSE response. Do not publish completion until
          // that file handle has fully quiesced.
          await completion;
        } catch (error) {
          if (error instanceof FsError) throw error;
          if (signal?.aborted) throw aborted;
          throw mapError(error);
        } finally {
          signal?.removeEventListener('abort', onAbort);
          if (!stream.destroyed) stream.destroy();
          try {
            await completion;
          } catch {
            // The primary mapped stream/abort error is raised above.
          }
        }
      },
    };
  }

  async readBytes(target: FsTarget, signal: AbortSignal | undefined, maxBytes: number): Promise<Uint8Array> {
    const { uri, path } = this.split(target);
    const info = await this.stat(target, signal);
    if (info?.size !== undefined && info.size > maxBytes) {
      throw new FsError(`file exceeds ${maxBytes} bytes`, 'FS_TOO_LARGE');
    }
    const buf = await this.readFile(uri, path, signal);
    if (buf.length > maxBytes) throw new FsError(`file exceeds ${maxBytes} bytes`, 'FS_TOO_LARGE');
    return new Uint8Array(buf);
  }

  async readByteRange(
    target: FsTarget,
    range: { offset: number; length: number },
    signal?: AbortSignal,
  ): Promise<Uint8Array> {
    const { offset, length } = range;
    if (!Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(length) || length < 0
      || (length > 0 && offset > Number.MAX_SAFE_INTEGER - (length - 1))) {
      throw new FsError('byte range must have non-negative safe integer bounds', 'FS_IO_ERROR');
    }
    if (signal?.aborted) throw new FsError('aborted', 'FS_ABORTED');
    if (length === 0) return new Uint8Array(0);
    const { uri, path } = this.split(target);
    try {
      return await this.sftp(uri, async (sftp) => {
        if (signal?.aborted) throw new FsError('aborted', 'FS_ABORTED');
        const stream = sftp.createReadStream(path, { start: offset, end: offset + (length - 1) });
        const completion = finished(stream);
        void completion.catch(() => {});
        const onAbort = (): void => { stream.destroy(new FsError('aborted', 'FS_ABORTED')); };
        signal?.addEventListener('abort', onAbort, { once: true });
        try {
          const chunks: Buffer[] = [];
          let total = 0;
          for await (const chunk of stream) {
            const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
            const window = bytes.subarray(0, length - total);
            chunks.push(window);
            total += window.length;
            if (total === length) break;
          }
          return new Uint8Array(Buffer.concat(chunks, total));
        } finally {
          signal?.removeEventListener('abort', onAbort);
          if (!stream.destroyed) stream.destroy();
          await completion.catch(() => {});
        }
      });
    } catch (error) {
      if (signal?.aborted) throw new FsError('aborted', 'FS_ABORTED', { cause: error });
      if (error instanceof FsError) throw error;
      throw this.mapError(error);
    }
  }

  async listDir(target: FsTarget, signal?: AbortSignal): Promise<FsDirEntry[]> {
    const { uri, path } = this.split(target);
    return this.sftp(uri, async (sftp) => {
      const entries = await promisify<Array<{ filename: string; attrs: Stats }>>(
        (cb) => sftp.readdir(path, cb),
        signal,
      );
      const result: FsDirEntry[] = [];
      for (const entry of entries) {
        const lexicalPath = joinRemote(path, entry.filename);
        // A normal child under an already-canonical parent cannot escape. A
        // symlink can, so give it the same canonical identity as resolve()
        // before exposing the target to consumers or containment checks.
        const childPath = entry.attrs.isSymbolicLink()
          ? await canonicalizeRemotePath(sftp, lexicalPath, signal)
          : lexicalPath;
        const childUri = { ...uri, path: childPath };
        const key = formatSshUri(childUri);
        result.push({
          name: entry.filename,
          type: statsType(entry.attrs),
          target: { targetKey: FsTargetKey(key), displayPath: `${childUri.user ? childUri.user + '@' : ''}${childUri.host}:${childPath}` },
          version: statsVersion(entry.attrs),
          size: entry.attrs.size,
        });
      }
      return result.sort((left, right) => left.name.localeCompare(right.name));
    });
  }

  async writeText(
    target: FsTarget,
    content: string,
    expected?: FsWriteIntent,
    signal?: AbortSignal,
    _sandboxPolicy?: unknown,
  ): Promise<FsWriteOutcome> {
    return this.withMutation(String(target.targetKey), () => this.writeTextUnlocked(target, content, expected, signal));
  }

  private async writeTextUnlocked(
    target: FsTarget,
    content: string,
    expected?: FsWriteIntent,
    signal?: AbortSignal,
    expectedBasis?: string,
  ): Promise<FsWriteOutcome> {
    const { uri, path } = this.split(target);
    const beforeStat = await this.statOrAbsent(target, signal);
    if (expected?.kind === 'createIfAbsent' && beforeStat) {
      throw beforeStat.type === 'file'
        ? new FsError('file already exists', 'FS_NOT_OBSERVED')
        : new FsError('existing target is not a regular file', 'FS_NOT_REGULAR_FILE');
    }
    if (expected?.kind === 'replaceIfVersion') {
      if (!beforeStat) throw new FsError('file does not exist', 'FS_STALE_VERSION');
      if (String(beforeStat.version) !== String(expected.version)) throw new FsError('stale version', 'FS_STALE_VERSION');
    }
    const before = beforeStat ? await this.readText(target, signal) : null;
    if (expectedBasis !== undefined && before !== expectedBasis) {
      throw new FsError('stale content', 'FS_STALE_VERSION');
    }
    await this.writeFile(
      uri,
      path,
      Buffer.from(content, 'utf8'),
      signal,
      expected?.kind === 'createIfAbsent',
      expected?.kind === 'replaceIfVersion' ? expected.version : undefined,
      expected?.kind === 'replaceIfVersion' && before !== null
        ? Buffer.from(expectedBasis ?? before, 'utf8')
        : undefined,
    );
    const afterStat = await this.stat(target, signal);
    return {
      operation: beforeStat ? 'update' : 'create',
      version: afterStat?.version ?? FsVersion(`${Date.now()}-${Buffer.byteLength(content)}`),
      before,
      after: content.replace(/\r\n/g, '\n'),
    };
  }

  async editText(
    target: FsTarget,
    edit: FsEditRequest,
    expected?: { version: FsVersion },
    signal?: AbortSignal,
    _sandboxPolicy?: unknown,
  ): Promise<FsEditOutcome> {
    return this.withMutation(String(target.targetKey), () => this.editTextUnlocked(target, edit, expected, signal));
  }

  private async editTextUnlocked(
    target: FsTarget,
    edit: FsEditRequest,
    expected?: { version: FsVersion },
    signal?: AbortSignal,
  ): Promise<FsEditOutcome> {
    const before = await this.readText(target, signal);
    const norm = before.replace(/\r\n/g, '\n');
    const old = edit.oldString.replace(/\r\n/g, '\n');
    const newStr = edit.newString.replace(/\r\n/g, '\n');
    if (!old) throw new FsError('empty oldString', 'FS_AMBIGUOUS_EDIT');
    const stat = await this.stat(target, signal);
    if (stat?.version === undefined) {
      throw new FsError('file changed or disappeared while editing', 'FS_STALE_VERSION');
    }
    if (expected && String(stat.version) !== String(expected.version)) {
      throw new FsError('stale version', 'FS_STALE_VERSION');
    }
    const indices = allMatches(norm, old);
    let after: string;
    if (edit.replaceAll) {
      after = norm.split(old).join(newStr);
    } else if (indices.length === 0) {
      throw new FsError('oldString not found', 'FS_EDIT_NOT_FOUND');
    } else if (indices.length > 1) {
      throw new FsError('oldString matches more than once', 'FS_AMBIGUOUS_EDIT');
    } else {
      after = norm.slice(0, indices[0]) + newStr + norm.slice(indices[0] + old.length);
    }
    const guarded = { kind: 'replaceIfVersion' as const, version: stat.version };
    await this.writeTextUnlocked(target, after, guarded, signal, before);
    return {
      version: (await this.stat(target, signal))?.version ?? FsVersion(`${Date.now()}-${Buffer.byteLength(after)}`),
      before: norm,
      after,
    };
  }

  // ── internals ──────────────────────────────────────────────────────────

  private parseTargetPath(path: string, cwd?: string): SshUri {
    if (path.startsWith('ssh://')) return normalizeSshUri(parseSshUri(path));
    const base = cwd && cwd.startsWith('ssh://')
      ? normalizeSshUri(parseSshUri(cwd))
      : this.baseUri;
    const abs = path.startsWith('/') ? path : joinRemote(base.path, path);
    return { ...base, path: normalizeRemote(abs) };
  }

  private split(target: FsTarget): { uri: SshUri; path: string } {
    const uri = normalizeSshUri(parseSshUri(String(target.targetKey)));
    return { uri, path: uri.path };
  }

  /**
   * Resolve symlinks for an existing target. For a path that does not exist yet,
   * resolve the nearest existing ancestor and append only normalized path
   * segments. This gives callers a stable target identity and ensures
   * `contains()` never approves a lexical `..` or an existing symlink escape.
   */
  private async canonicalizePath(uri: SshUri, signal?: AbortSignal): Promise<string> {
    return this.sftp(uri, (sftp) => canonicalizeRemotePath(sftp, uri.path, signal));
  }

  private async sftp<T>(uri: SshUri, op: (sftp: SFTPWrapper) => Promise<T>): Promise<T> {
    const transport = await this.connections.transport(formatSshUri(uri));
    return transport.sftp(op);
  }

  private async readFile(uri: SshUri, path: string, signal?: AbortSignal): Promise<Buffer> {
    return this.sftp(uri, (s) => promisify<Buffer>((cb) => s.readFile(path, cb), signal));
  }

  private async writeFile(
    uri: SshUri,
    path: string,
    data: Buffer,
    signal?: AbortSignal,
    createIfAbsent = false,
    expectedVersion?: FsVersion,
    expectedContent?: Buffer,
  ): Promise<void> {
    await this.sftp(uri, async (sftp) => {
      signal?.throwIfAborted();
      const temporary = posix.join(
        posix.dirname(path),
        `.${posix.basename(path)}.dsh-${randomBytes(8).toString('hex')}.tmp`,
      );
      try {
        let existing: Stats | undefined;
        if (!createIfAbsent) {
          try {
            existing = await promisify<Stats>((cb) => sftp.stat(path, cb));
          } catch (error) {
            if (!isCode(error, 'ENOENT')) throw error;
          }
        }
        await promisify<void>((cb) => sftp.writeFile(temporary, data, {
          flag: 'wx',
          mode: 0o600,
        }, cb));
        signal?.throwIfAborted();
        if (createIfAbsent) {
          try {
            // hardlink@openssh.com publishes an already-complete inode and
            // refuses to replace an existing destination.
            await promisify<void>((cb) => sftp.ext_openssh_hardlink(temporary, path, cb));
          } catch (error) {
            if (isUnsupportedRename(error)) {
              throw new FsError(
                'remote SFTP server does not support atomic hardlink create',
                'FS_IO_ERROR',
                { cause: error as Error },
              );
            }
            let destination: Stats | undefined;
            try {
              destination = await promisify<Stats>((cb) => sftp.lstat(path, cb));
            } catch (statError) {
              if (!isCode(statError, 'ENOENT')) throw this.mapError(statError);
            }
            if (destination !== undefined) {
              throw destination.isFile()
                ? new FsError('file already exists', 'FS_NOT_OBSERVED', {
                  cause: error as Error,
                })
                : new FsError('existing target is not a regular file', 'FS_NOT_REGULAR_FILE', {
                  cause: error as Error,
                });
            }
            // SFTP v3 collapses EEXIST, policy failures, quota errors and
            // several other errno values into SSH_FX_FAILURE. With no target
            // left to classify, preserve the ambiguity as a typed IO failure.
            throw this.mapError(error);
          }
          return;
        }
        if (existing?.mode !== undefined) {
          await promisify<void>((cb) => sftp.chmod(temporary, existing.mode & 0o7777, cb));
        }
        signal?.throwIfAborted();
        if (expectedVersion !== undefined) {
          let current: Stats;
          try {
            current = await promisify<Stats>((cb) => sftp.stat(path, cb));
          } catch (error) {
            if (isCode(error, 'ENOENT')) {
              throw new FsError('file disappeared before publish', 'FS_STALE_VERSION', {
                cause: error as Error,
              });
            }
            throw error;
          }
          if (String(statsVersion(current)) !== String(expectedVersion)) {
            throw new FsError('stale version', 'FS_STALE_VERSION');
          }
        }
        if (expectedContent !== undefined) {
          let current: Buffer;
          try {
            current = await promisify<Buffer>((cb) => sftp.readFile(path, cb));
          } catch (error) {
            if (isCode(error, 'ENOENT')) {
              throw new FsError('file disappeared before publish', 'FS_STALE_VERSION', {
                cause: error as Error,
              });
            }
            throw error;
          }
          if (!current.equals(expectedContent)) {
            throw new FsError('stale content', 'FS_STALE_VERSION');
          }
        }
        signal?.throwIfAborted();
        try {
          await promisify<void>((cb) => sftp.ext_openssh_rename(temporary, path, cb));
        } catch (error) {
          if (!isUnsupportedRename(error)) throw error;
          throw new FsError(
            'remote SFTP server does not support atomic posix-rename',
            'FS_IO_ERROR',
            { cause: error as Error },
          );
        }
      } finally {
        try {
          await promisify<void>((cb) => sftp.unlink(temporary, cb));
        } catch {
          /* renamed or best-effort cleanup */
        }
      }
    });
  }

  private async tryUnlink(uri: SshUri, path: string): Promise<void> {
    try {
      await this.sftp(uri, (s) => promisify<void>((cb) => s.unlink(path, cb)));
    } catch {
      /* best effort */
    }
  }

  private async statOrAbsent(target: FsTarget, signal?: AbortSignal): Promise<FsInfo | undefined> {
    return this.stat(target, signal);
  }

  private async withMutation<T>(key: string, run: () => Promise<T>): Promise<T> {
    const previous = this.mutations.get(key) ?? Promise.resolve();
    const current = previous.catch(() => undefined).then(run);
    this.mutations.set(key, current);
    try {
      return await current;
    } finally {
      if (this.mutations.get(key) === current) this.mutations.delete(key);
    }
  }

  private mapError(e: unknown): FsError {
    const code = codeOf(e);
    const mapped =
      code === 'ENOENT' ? 'FS_NOT_FOUND' :
      code === 'EACCES' || code === 'EPERM' ? 'FS_PERMISSION_DENIED' :
      code === 'EISDIR' ? 'FS_NOT_REGULAR_FILE' :
      code === 'ENOTDIR' ? 'FS_NOT_DIRECTORY' :
      'FS_IO_ERROR';
    return new FsError(`remote fs: ${messageOf(e)}`, mapped, { cause: e as Error });
  }
}

/**
 * Build the remote half of the URI router without registering a second
 * `ctx.fs` service. DSH exposes one filesystem service per host; the router
 * delegates only mapped SSH targets to this adapter.
 */
export function createRemoteFileSystemAdapter(
  connections: SshConnectionManager,
): RemoteFileSystem {
  const adapter = Object.create(RemoteFileSystem.prototype) as RemoteFileSystem;
  Object.defineProperties(adapter, {
    connections: { value: connections },
    baseUri: { value: parseSshUri('ssh://unresolved/') },
    mutations: { value: new Map<string, Promise<unknown>>() },
  });
  return adapter;
}


// ── helpers ──────────────────────────────────────────────────────────────

function promisify<T>(fn: (cb: (err: Error | null | undefined, result: T) => void) => void, signal?: AbortSignal): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    let settled = false;
    const onAbort = () => {
      if (!settled) {
        settled = true;
        reject(new FsError('aborted', 'FS_ABORTED'));
      }
    };
    if (signal) {
      if (signal.aborted) return onAbort();
      signal.addEventListener('abort', onAbort, { once: true });
    }
    fn((err, result) => {
      if (settled) return;
      settled = true;
      if (signal) signal.removeEventListener('abort', onAbort);
      if (err) reject(err);
      else resolve(result);
    });
  });
}

function statToFsInfo(st: { mtime: number; size: number; isFile(): boolean; isDirectory(): boolean }): FsInfo {
  return {
    version: statsVersion(st),
    type: st.isDirectory() ? 'directory' : st.isFile() ? 'file' : 'other',
    size: st.size,
  };
}

function statsVersion(st: { mtime: number; size: number; mode?: number; uid?: number; gid?: number }): FsVersion {
  return FsVersion([
    Math.floor(st.mtime),
    st.size,
    st.mode ?? '',
    st.uid ?? '',
    st.gid ?? '',
  ].join('-'));
}

function statToPathInfo(st: { mtime: number; size: number; isFile(): boolean; isDirectory(): boolean; isSymbolicLink(): boolean }): FsPathInfo {
  return {
    version: statsVersion(st),
    type: st.isSymbolicLink() ? 'symlink' : st.isDirectory() ? 'directory' : st.isFile() ? 'file' : 'other',
    size: st.size,
  };
}

function statsType(st: { isFile(): boolean; isDirectory(): boolean }): 'file' | 'directory' | 'other' {
  return st.isDirectory() ? 'directory' : st.isFile() ? 'file' : 'other';
}

function decodeText(buf: Buffer): string {
  if (buf.includes(0)) throw new FsError('binary file', 'FS_NOT_TEXT');
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buf);
  } catch {
    throw new FsError('not valid UTF-8', 'FS_NOT_TEXT');
  }
}

function normalizeSshUri(uri: SshUri): SshUri {
  return { ...uri, path: normalizeRemote(uri.path) };
}

/**
 * Canonicalize one absolute remote path using the SFTP server's realpath
 * implementation. A missing leaf is still safe to address: walk upward until
 * an existing ancestor is found, resolve that ancestor (including symlinks),
 * then append the missing normalized segments.
 */
async function canonicalizeRemotePath(
  sftp: SFTPWrapper,
  path: string,
  signal?: AbortSignal,
): Promise<string> {
  let candidate = normalizeRemote(path);
  const missing: string[] = [];

  while (true) {
    try {
      const resolved = await promisify<string>((cb) => sftp.realpath(candidate, cb), signal);
      return normalizeRemote(posix.join(resolved, ...missing));
    } catch (error) {
      if (!isCode(error, 'ENOENT') || candidate === '/') throw error;
      let existing: Stats | undefined;
      try {
        existing = await promisify<Stats>((cb) => sftp.lstat(candidate, cb), signal);
      } catch (lstatError) {
        if (!isCode(lstatError, 'ENOENT')) throw lstatError;
      }
      if (existing?.isSymbolicLink()) {
        throw new FsError(
          `refusing unresolved remote symlink: ${candidate}`,
          'FS_SANDBOX_DENIED',
        );
      }
      // If lstat found a non-symlink object, realpath failed for a reason other
      // than absence despite the server's coarse status code. Preserve that
      // failure instead of manufacturing a new child identity.
      if (existing !== undefined) throw error;
      missing.unshift(posix.basename(candidate));
      candidate = posix.dirname(candidate);
    }
  }
}

function joinRemote(base: string, ...parts: string[]): string {
  let p = base;
  for (const part of parts) p = p.replace(/\/+$/, '') + '/' + part.replace(/^\/+/, '');
  return normalizeRemote(p);
}

function normalizeRemote(p: string): string {
  const segs: string[] = [];
  for (const seg of p.split('/')) {
    if (!seg || seg === '.') continue;
    if (seg === '..') segs.pop();
    else segs.push(seg);
  }
  return '/' + segs.join('/');
}

function ensureTrailingSlash(p: string): string {
  return p.endsWith('/') ? p : p + '/';
}

function allMatches(haystack: string, needle: string): number[] {
  const out: number[] = [];
  let idx = haystack.indexOf(needle);
  while (idx !== -1) {
    out.push(idx);
    idx = haystack.indexOf(needle, idx + needle.length);
  }
  return out;
}

function isCode(e: unknown, code: string): boolean {
  return codeOf(e) === code;
}

function codeOf(e: unknown): string | undefined {
  const code = (e as { code?: unknown })?.code;
  if (typeof code === 'number') return sftpStatusToNode(code);
  return typeof code === 'string' ? code : undefined;
}

/** Map a numeric SFTP status code to a Node-style error code string. */
function sftpStatusToNode(code: number): string | undefined {
  switch (code) {
    case 2: // SSH_FX_NO_SUCH_FILE
    case 10: // SSH_FX_NO_SUCH_PATH
      return 'ENOENT';
    case 3: // SSH_FX_PERMISSION_DENIED
      return 'EACCES';
    case 19: // SSH_FX_NOT_A_DIRECTORY
      return 'ENOTDIR';
    case 11: // SSH_FX_FILE_ALREADY_EXISTS (SFTP v6 / some servers)
      return 'EEXIST';
    case 4: // SSH_FX_FAILURE
      return 'EIO';
    default:
      return undefined;
  }
}

function messageOf(e: unknown): string {
  return (e as Error)?.message ?? String(e);
}

function isUnsupportedRename(error: unknown): boolean {
  const raw = (error as { code?: unknown })?.code;
  return raw === 8
    || raw === 'ENOSYS'
    || raw === 'EOPNOTSUPP'
    || /unsupported|not supported/u.test(messageOf(error).toLowerCase());
}
