import { createInterface } from 'node:readline';
import { spawn, spawnSync, type ChildProcessWithoutNullStreams } from 'node:child_process';
import { chmod, mkdtemp, mkdir, readFile, realpath, rm, stat, symlink, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import nodeProcess from 'node:process';
import { fileURLToPath } from 'node:url';
import { afterEach, describe, expect, it } from 'vitest';

const helper = fileURLToPath(new URL('../helper/dsh_remote_helper.py', import.meta.url));
// These end-to-end cases create 1,200 files and transfer PTY data. macOS
// filesystem/process tracing can exceed 15 s without a protocol failure.
const integrationTimeout = process.platform === 'darwin' ? 60_000 : 15_000;

class RpcClient {
  readonly child: ChildProcessWithoutNullStreams;
  readonly hello: Promise<Record<string, unknown>>;
  private nextId = 1;
  private readonly pending = new Map<number, { resolve(value: any): void; reject(error: Error): void }>();
  private resolveHello!: (value: Record<string, unknown>) => void;
  private rejectHello!: (error: Error) => void;
  private helloSettled = false;
  private stderr = '';

  constructor(options: { direct?: boolean; runtimeDir?: string; extraEnv?: Record<string, string> } = {}) {
    this.hello = new Promise((resolve, reject) => { this.resolveHello = resolve; this.rejectHello = reject; });
    const args = [helper, 'connect', '--stdio'];
    if (options.direct !== false) args.push('--direct');
    this.child = spawn('python3', args, {
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...process.env, ...options.extraEnv, DSH_REMOTE_HELPER_RUNTIME_DIR: options.runtimeDir,
        DSH_REMOTE_HELPER_ALLOW_SHUTDOWN: options.runtimeDir ? '1' : undefined },
    });
    this.child.stderr.on('data', (chunk) => { this.stderr += String(chunk); });
    createInterface({ input: this.child.stdout }).on('line', (line) => {
      const message = JSON.parse(line) as any;
      if (message.method === 'server/hello') {
        this.helloSettled = true;
        this.resolveHello(message.params);
        return;
      }
      const waiter = this.pending.get(message.id);
      if (!waiter) return;
      this.pending.delete(message.id);
      if (message.error) {
        const error = Object.assign(new Error(message.error.message), { code: message.error.code });
        waiter.reject(error);
      } else {
        waiter.resolve(message.result);
      }
    });
    this.child.on('exit', (code) => {
      if (!this.helloSettled) this.rejectHello(new Error(`helper exited ${code}: ${this.stderr}`));
      for (const waiter of this.pending.values()) {
        waiter.reject(new Error(`helper exited ${code}: ${this.stderr}`));
      }
      this.pending.clear();
    });
  }

  async request(method: string, params: Record<string, unknown> = {}): Promise<any> {
    const id = this.nextId++;
    const response = new Promise((resolve, reject) => this.pending.set(id, { resolve, reject }));
    this.child.stdin.write(`${JSON.stringify({ dshRpc: '1', id, method, params })}\n`);
    return response;
  }

  async close(): Promise<void> {
    if (this.child.exitCode !== null) return;
    const exited = new Promise<void>((resolve) => this.child.once('exit', () => resolve()));
    this.child.stdin.end();
    await exited;
  }
}

const clients: RpcClient[] = [];
const temporary: string[] = [];

afterEach(async () => {
  await Promise.all(clients.splice(0).map((client) => client.close()));
  await Promise.all(temporary.splice(0).map((path) => rm(path, { recursive: true, force: true })));
});

describe('Python remote helper v1', () => {
  it('ignores a directory-valued SHELL preference and reports an executable file', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-shell-directory-')); temporary.push(root);
    const rpc = new RpcClient({ extraEnv: { SHELL: root } }); clients.push(rpc);
    const hello = await rpc.hello as { platform: { shell: string } };
    expect(hello.platform.shell).not.toBe(root);
    expect((await stat(hello.platform.shell)).isFile()).toBe(true);
  });

  it('resolves executables in the helper execution environment without local PATH guesses', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-helper-executable-')); temporary.push(root);
    const executable = join(root, 'fixture-shell');
    await writeFile(executable, '#!/bin/sh\nexit 0\n'); await chmod(executable, 0o755);
    await symlink(executable, join(root, 'shell-alias'));
    const rpc = new RpcClient(); clients.push(rpc); await rpc.hello;
    const initialized = await rpc.request('initialize', { clientId: 'executable-lookup' });
    expect(initialized.capabilities.environment.resolveExecutable).toBe(true);
    await expect(rpc.request('environment/resolveExecutable', { command: 'fixture-shell', env: { PATH: root } }))
      .resolves.toEqual({ path: await realpath(executable) });
    await expect(rpc.request('environment/resolveExecutable', { command: join(root, 'shell-alias') }))
      .resolves.toEqual({ path: await realpath(executable) });
    await expect(rpc.request('environment/resolveExecutable', { command: 'definitely-not-a-shell', env: { PATH: root } }))
      .rejects.toMatchObject({ code: 'E_EXECUTABLE_NOT_FOUND' });
    await expect(rpc.request('environment/resolveExecutable', { command: './fixture-shell', env: { PATH: root } }))
      .rejects.toMatchObject({ code: 'E_INVALID_PARAMS' });
    await chmod(executable, 0o644);
    await expect(rpc.request('environment/resolveExecutable', { command: executable }))
      .rejects.toMatchObject({ code: 'E_EXECUTABLE_NOT_FOUND' });
    await expect(rpc.request('environment/resolveExecutable', { command: '/bin/sh', env: { PATH: 1 } }))
      .rejects.toMatchObject({ code: 'E_INVALID_PARAMS' });
  }, integrationTimeout);

  it('resolves login-only search executables without confusing direct-process PATH', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-login-executable-')); temporary.push(root);
    const loginBin = join(root, 'login-bin'); const wrapperBin = join(root, 'wrapper-bin');
    await mkdir(loginBin); await mkdir(wrapperBin);
    const command = 'login-only-fixture-executable';
    await writeFile(join(loginBin, command), '#!/bin/sh\nexit 0\n'); await chmod(join(loginBin, command), 0o755);
    await writeFile(join(wrapperBin, 'sh'), '#!/bin/sh\n[ "$1" = "-lc" ] || exit 99\nPATH="$LOGIN_FIXTURE_BIN:/bin:/usr/bin"; export PATH\nexec /bin/sh -c "$2" "$3" "$4"\n');
    await chmod(join(wrapperBin, 'sh'), 0o755);
    const rpc = new RpcClient(); clients.push(rpc); await rpc.hello;
    await rpc.request('initialize', { clientId: 'login-path-lookup' });
    const env = { PATH: `${wrapperBin}:/bin:/usr/bin`, LOGIN_FIXTURE_BIN: loginBin };
    await expect(rpc.request('environment/resolveExecutable', { command, env }))
      .rejects.toMatchObject({ code: 'E_EXECUTABLE_NOT_FOUND' });
    await expect(rpc.request('environment/resolveExecutable', { command, env, login: true }))
      .resolves.toEqual({ path: await realpath(join(loginBin, command)) });
  }, integrationTimeout);

  it('cancels RESERVED process allocations before they can publish a late live terminal', () => {
    const program = String.raw`
import importlib.util,json,threading,tempfile,sys
spec=importlib.util.spec_from_file_location('helper',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
server=m.Server();server.dispatch('initialize',{'clientId':'reserved-test'})
entered=threading.Event();proceed=threading.Event();real=m.ProcessRecord;outcomes=[];created=[]
def delayed(*args,**kwargs):
 entered.set();assert proceed.wait(3)
 record=real(*args,**kwargs);created.append(record);return record
m.ProcessRecord=delayed
with tempfile.TemporaryDirectory() as root:
 server.dispatch('workspace/open',{'path':root,'access':'danger-full-access','workspaceId':'w','operationId':'w'})
 for method in ('process/terminate','process/release'):
  early='before-reserve-'+method.split('/')[1]
  try:server.dispatch(method,{'processId':early,'operationId':'cancel-'+early,'force':True})
  except m.RpcError as e:assert e.code=='E_UNKNOWN_PROCESS'
  try:server.dispatch('process/start',{'workspaceId':'w','processId':early,'operationId':'start-'+early,'argv':['/bin/sleep','20'],'stdin':'closed'});raise AssertionError('late pre-reservation start published')
  except m.RpcError as e:assert e.code=='E_PROCESS_CANCELLED'
 assert not created
 request={'workspaceId':'w','processId':'late','operationId':'start','argv':['/bin/sleep','20'],'stdin':'closed'}
 def start():
  try:server.dispatch('process/start',request);outcomes.append('published')
  except m.RpcError as e:outcomes.append(e.code)
 worker=threading.Thread(target=start);worker.start();assert entered.wait(3)
 result=server.dispatch('process/terminate',{'processId':'late','operationId':'cancel','force':True})
 assert result['cancellationScheduled']
 try:server.dispatch('process/release',{'processId':'late','operationId':'release'})
 except m.RpcError as e:assert e.code=='E_PROCESS_STARTING'
 proceed.set();worker.join(5);assert not worker.is_alive()
 assert outcomes==['E_PROCESS_CANCELLED'],outcomes
 assert created[0].released and server.dispatch('health/status',{})['processes']==0
 try:server.dispatch('process/start',dict(request,operationId='retry-start'));raise AssertionError('restarted cancelled identity')
 except m.RpcError as e:assert e.code=='E_PROCESS_CANCELLED'
 server.close()
print(json.dumps({'cancelled':True,'lateProcessReleased':created[0].released}))
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', timeout: 12_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toEqual({ cancelled: true, lateProcessReleased: true });
  }, integrationTimeout);

  it('drains every retained output page before reporting process EOF', async () => {
    const rpc = new RpcClient(); clients.push(rpc); await rpc.hello;
    await rpc.request('initialize', { clientId: 'output-drain' });
    await rpc.request('workspace/open', { path: tmpdir(), access: 'danger-full-access',
      workspaceId: 'drain-ws', operationId: 'drain-ws' });
    for (const overflow of [false, true]) {
      const id = overflow ? 'overflow' : 'multi-page';
      const size = overflow ? 3 * 1024 * 1024 : 512 * 1024;
      await rpc.request('process/start', { workspaceId: 'drain-ws', processId: id, operationId: id,
        stdin: 'closed', argv: ['python3', '-c',
          `import sys; sys.stdout.write('A'*${size}+'END_STDOUT'); sys.stdout.flush(); sys.stderr.write('END_STDERR')`],
      });
      for (let attempt = 0; attempt < 100; attempt += 1) {
        if (!(await rpc.request('process/status', { processId: id })).running) break;
        await new Promise(resolve => setTimeout(resolve, 20));
      }
      await new Promise(resolve => setTimeout(resolve, 50));
      let cursor = '0'; let stdout = ''; let stderr = ''; let truncated = false; let pages = 0;
      for (;;) {
        const read = await rpc.request('process/read', { processId: id, afterSeq: cursor, maxBytes: 64 * 1024, waitMs: 100 });
        pages += 1; cursor = read.nextSeq; truncated ||= read.truncated;
        for (const chunk of read.chunks) {
          if (chunk.stream === 'stderr') stderr += Buffer.from(chunk.data, 'base64').toString();
          else stdout += Buffer.from(chunk.data, 'base64').toString();
        }
        if (pages === 1) expect(read.exited).toBe(false);
        if (read.exited) break;
        expect(pages).toBeLessThan(100);
      }
      expect(stdout.endsWith('END_STDOUT')).toBe(true);
      expect(stderr).toBe('END_STDERR');
      expect(truncated).toBe(overflow);
      if (!overflow) expect(stdout).toBe('A'.repeat(size) + 'END_STDOUT');
      else expect(Buffer.byteLength(stdout + stderr)).toBeLessThanOrEqual(2 * 1024 * 1024);
      await rpc.request('process/release', { processId: id, operationId: `release-${id}` });
    }
  }, integrationTimeout);

  it('pins the task group after leader exit and escalates TERM for surviving descendants', () => {
    const program = String.raw`
import importlib.util,json,time,sys,base64,subprocess,os,signal
spec=importlib.util.spec_from_file_location('helper',__import__('sys').argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
for tty in (None,{'rows':24,'cols':80}):
 r=m.ProcessRecord('descendant',['/bin/sh','-c',"trap '' TERM HUP; sleep 20 & printf 'child-started:%s\\n' \"$!\"; exit 7"],'/tmp',{},tty,'pipe')
 try:
  deadline=time.monotonic()+3
  while r.returncode is None and time.monotonic()<deadline:time.sleep(.01)
  assert r.returncode==7,r.status()
  deadline=time.monotonic()+3
  while time.monotonic()<deadline:
   first=r.read({'afterSeq':'0','waitMs':100})
   output=b''.join(base64.b64decode(c['data']) for c in first['chunks'])
   if b'\n' in output:break
  # Darwin revokes a controlling PTY when its real task/session leader exits.
  # That is kernel EOF, not a proxy for process exit. Pipes and Linux retain
  # their existing descendant-held-output behavior.
  if tty is None or sys.platform!='darwin':assert not first['exited']
  descendant=int(output.split(b'child-started:')[1].strip())
  os.kill(descendant,0)
  if tty is not None and sys.platform=='darwin':
   state=subprocess.check_output(['/bin/ps','-o','stat=','-p',str(r.pid)],text=True).strip()
   assert state.startswith('Z'),state # kqueue has reported exit without reaping our PID pin.
  r.terminate(False,100)
  deadline=time.monotonic()+3
  while time.monotonic()<deadline:
   data=r.read({'afterSeq':'0','waitMs':100})
   if data['exited']:break
  assert data['exited'],data
  assert data['exitCode']==7,data
  deadline=time.monotonic()+2
  while time.monotonic()<deadline:
   check=subprocess.run(['ps','-o','stat=','-p',str(descendant)],stdout=subprocess.PIPE,text=True)
   if not check.stdout.strip() or check.stdout.strip().startswith('Z'):break
   time.sleep(.01)
  assert not check.stdout.strip() or check.stdout.strip().startswith('Z'),check.stdout
  started=time.monotonic();r.release();elapsed=time.monotonic()-started
  assert elapsed<3,elapsed
  assert r.release()=={'released':False}
  results.append({'tty':tty is not None,'exitCode':data['exitCode'],'readers':r.readers})
 finally:
  if not r.released:r.release()
print(json.dumps(results))
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', timeout: 15_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toEqual([
      { tty: false, exitCode: 7, readers: 0 }, { tty: true, exitCode: 7, readers: 0 },
    ]);
  }, integrationTimeout);

  it.runIf(process.platform === 'darwin')('pins Darwin PTY task exits even with an inherited ignored SIGCHLD', () => {
    const program = String.raw`
import importlib.util,json,time,sys,signal,subprocess
spec=importlib.util.spec_from_file_location('helper',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
signal.signal(signal.SIGCHLD,signal.SIG_IGN)
r=m.ProcessRecord('ignored-chld',['/bin/sh','-c','printf PINNED; exit 7'],'/tmp',{}, {'rows':24,'cols':80},'pipe')
signal.signal(signal.SIGCHLD,signal.SIG_DFL)
try:
 deadline=time.monotonic()+3
 while r.returncode is None and time.monotonic()<deadline:time.sleep(.01)
 assert r.returncode==7,r.status()
 state=subprocess.check_output(['/bin/ps','-o','stat=','-p',str(r.pid)],text=True).strip()
 assert state.startswith('Z'),state
 r.release()
 check=subprocess.run(['/bin/ps','-o','stat=','-p',str(r.pid)],stdout=subprocess.PIPE,text=True)
 assert not check.stdout.strip(),check.stdout
 print(json.dumps({'pinned':True,'reaped':True}))
finally:
 if not r.released:r.release()
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', timeout: 10_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toEqual({ pinned: true, reaped: true });
  }, integrationTimeout);

  it('cleans the owned task group when its supervisor is abruptly killed', () => {
    const program = String.raw`
import importlib.util,json,time,sys,base64,subprocess
spec=importlib.util.spec_from_file_location('helper',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
results=[]
for tty in (None,{'rows':24,'cols':80}):
 r=m.ProcessRecord('guardian-crash',['/bin/sh','-c',"trap '' HUP TERM; sleep 20 & printf 'CHILD:%s\\n' \"$!\"; wait"],'/tmp',{},tty,'pipe')
 try:
  deadline=time.monotonic()+3;output=b''
  while time.monotonic()<deadline:
   read=r.read({'afterSeq':'0','waitMs':100})
   output=b''.join(base64.b64decode(c['data']) for c in read['chunks'])
   if b'\n' in output:break
  descendant=int(output.split(b'CHILD:')[1].strip())
  r.child.kill();r.child.wait(timeout=2)
  deadline=time.monotonic()+3
  while time.monotonic()<deadline:
   states=[subprocess.run(['ps','-o','stat=','-p',str(pid)],stdout=subprocess.PIPE,text=True).stdout.strip() for pid in (r.pid,descendant)]
   if all(not state or state.startswith('Z') for state in states):break
   time.sleep(.02)
  assert all(not state or state.startswith('Z') for state in states),states
  while not r.supervisor_closed and time.monotonic()<deadline:time.sleep(.01)
  r.release();results.append({'tty':tty is not None,'cleaned':True})
 finally:
  if not r.released:r.release()
print(json.dumps(results))
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', timeout: 12_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toEqual([{ tty: false, cleaned: true }, { tty: true, cleaned: true }]);
  }, integrationTimeout);

  it.runIf(process.platform === 'darwin')('fails a Darwin guardian fork promptly without a launch-gate deadlock', () => {
    const program = String.raw`
import importlib.util,json,time,sys,socket,os,errno,signal
spec=importlib.util.spec_from_file_location('helper',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
local,remote=socket.socketpair();master,slave=os.openpty()
launcher=os.fork()
if launcher==0:
 local.close()
 for target in (0,1,2):os.dup2(slave,target)
 os.close(slave)
 original_fork=os.fork;calls=[0]
 def fail_guardian_fork():
  calls[0]+=1
  if calls[0]==3:raise OSError(errno.EAGAIN,'injected guardian fork failure')
  return original_fork()
 os.fork=fail_guardian_fork
 os._exit(m.run_supervised(remote.fileno(),master,None,['/bin/true']))
remote.close();os.close(slave);started=time.monotonic();local.settimeout(3)
try:
 buffered=b''
 while b'\n' not in buffered:
  chunk=local.recv(8192)
  assert chunk,'closed without startup error'
  buffered+=chunk
 event=json.loads(buffered.split(b'\n',1)[0])
 assert event['event']=='error',event
 assert event['code']!='E_SUPERVISOR_TIMEOUT',event
 assert time.monotonic()-started<3,event
 print(json.dumps({'failedPromptly':True,'error':event['code']}))
finally:
 local.close();os.close(master)
 # The launcher is our unreaped child, so this exact PID remains owned.
 try:os.kill(launcher,signal.SIGKILL)
 except ProcessLookupError:pass
 os.waitpid(launcher,0)
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', timeout: 6_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toMatchObject({ failedPromptly: true });
  }, integrationTimeout);

  it('keeps sandbox reaper stdio separate from task EOF with the inherited-FD bridge', () => {
    const program = String.raw`
import importlib.util,json,time,tempfile,os,sys
spec=importlib.util.spec_from_file_location('helper',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
# Simulate bwrap's relevant lifecycle: pass extra FDs to the child, close our
# copies, but retain standard descriptors until the supervised child exits.
# This is a pipe-lifetime regression, not a substitute for Linux confinement.
wrapper='''import os,sys,subprocess
assert '--preserve-fds' not in sys.argv
fds=[]
for value in os.listdir('/dev/fd'):
 try:
  fd=int(value);os.fstat(fd)
  if fd>2:fds.append(fd)
 except (OSError,ValueError):pass
child=subprocess.Popen(sys.argv[sys.argv.index('--')+1:],pass_fds=tuple(fds),close_fds=True)
for fd in fds:
 try:os.close(fd)
 except OSError:pass
raise SystemExit(child.wait())
'''
results=[]
with tempfile.TemporaryDirectory(prefix='dsh-reaper-fixture-') as root:
 fixture=os.path.join(root,'reaper.py')
 with open(fixture,'w') as target:target.write(wrapper)
 for tty in (None,{'rows':24,'cols':80}):
  r=m.ProcessRecord('sandbox-fds',[sys.executable,fixture,'--','/bin/sh','-c','printf bridge-ok'],root,{},tty,'pipe',inside_sandbox=True)
  try:
   deadline=time.monotonic()+3
   while time.monotonic()<deadline:
    read=r.read({'afterSeq':'0','waitMs':100})
    if read['exited']:break
   assert read['exited'] and read['exitCode']==0,read
   r.release();results.append({'tty':tty is not None,'eof':True})
  finally:
   if not r.released:r.release()
print(json.dumps(results))
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', timeout: 12_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toEqual([{ tty: false, eof: true }, { tty: true, eof: true }]);
  }, integrationTimeout);

  it('bounds cleanup when an escaped child retains pipes and a stdin writer is blocked', () => {
    const program = String.raw`
import importlib.util,json,time,threading,base64,os,signal,sys
spec=importlib.util.spec_from_file_location('helper',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
command="import os,time; p=os.fork(); print(p,flush=True) if p else None; os._exit(0) if p else None; os.setsid(); time.sleep(20)"
r=m.ProcessRecord('escaped',[sys.executable,'-c',command],'/tmp',{},None,'pipe')
escaped=None;writer=None;outcomes=[]
try:
 deadline=time.monotonic()+3;output=b''
 while not output and time.monotonic()<deadline:
  read=r.read({'afterSeq':'0','waitMs':100})
  output=b''.join(base64.b64decode(c['data']) for c in read['chunks'])
 escaped=int(output.strip())
 # This child deliberately left the owned process group. It is not a cgroup
 # kill target, but its pipe ownership must not hang helper cleanup.
 def write():
  try:r.write({'data':base64.b64encode(b'x'*(2*1024*1024)).decode()})
  except m.RpcError as e:outcomes.append(e.code)
 writer=threading.Thread(target=write);writer.start();time.sleep(.05)
 started=time.monotonic();r.release();elapsed=time.monotonic()-started
 writer.join(1)
 assert not writer.is_alive()
 assert elapsed<4,elapsed
 assert r.readers==0,r.readers
 print(json.dumps({'bounded':True,'readers':r.readers,'writerStopped':True}))
finally:
 if escaped:
  try:os.kill(escaped,signal.SIGKILL)
  except ProcessLookupError:pass
 if not r.released:r.release()
 if writer:writer.join(1)
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', timeout: 12_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toEqual({ bounded: true, readers: 0, writerStopped: true });
  }, integrationTimeout);

  it('invalidates delayed group signals and cleans every server resource after one cleanup fails', () => {
    const program = String.raw`
import importlib.util,json,socket,sys,time
spec=importlib.util.spec_from_file_location('helper',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
left,right=socket.socketpair();s=m.ProcessSupervisor(left.detach(),None)
s.pid=12345;s.group_owned=True;s.command_reaped=True
signals=[];original=m.os.killpg;m.os.killpg=lambda pid,sig:signals.append((pid,sig))
try:
 s.dispatch('terminate',{'graceMs':1000});generation=s.generation
 s.finish();s.finish();s.dispatch('terminate',{'graceMs':0})
 assert s.deadline is None and s.generation>generation
 assert len(signals)==2,signals
finally:m.os.killpg=original;s.control.close();right.close()
seen=[]
class Resource:
 def __init__(self,name,fail=False):self.name=name;self.fail=fail
 def release(self):
  seen.append(self.name)
  if self.fail:raise RuntimeError('fixture cleanup failure')
 def close(self):self.release()
server=m.Server();server.processes={'bad':Resource('bad',True),'good':Resource('good')};server.workspaces={'w':Resource('workspace')}
try:server.close();raise AssertionError('expected aggregate cleanup failure')
except m.RpcError as e:assert e.code=='E_CLEANUP_FAILED'
assert seen==['bad','good','workspace'],seen
left,right=socket.socketpair();channel=m.SupervisorChannel(left,lambda e:None)
channel.write_lock.acquire();started=time.monotonic()
try:
 try:channel.call('signal',{},timeout=.05);raise AssertionError('expected bounded lock timeout')
 except m.RpcError as e:assert e.code=='E_SUPERVISOR_TIMEOUT'
 assert time.monotonic()-started<.5
finally:channel.write_lock.release();channel.close();right.close()
print(json.dumps({'signals':len(signals),'resources':seen,'boundedControl':True}))
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', timeout: 5_000, env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toEqual({ signals: 2, resources: ['bad', 'good', 'workspace'], boundedControl: true });
  });

  it('returns connector capacity even when disconnected socket streams fail during cleanup', () => {
    const program = String.raw`
import importlib.util,io,json,os,socket,sys,tempfile
spec=importlib.util.spec_from_file_location('dsh_helper',sys.argv[1])
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
BaseState=m.DaemonState
observed=[]
for failure in ('input-close','output-close','makefile'):
 states=[]
 class State(BaseState):
  def __init__(self,*args):
   super().__init__(*args);states.append(self)
 class Stream(io.BytesIO):
  def __init__(self,mode):
   super().__init__();self.mode=mode
  def close(self):
   if self.closed:return
   super().close()
   if failure==self.mode+'-close':raise BrokenPipeError('cancelled probe')
 class Client:
  def __enter__(self):return self
  def __exit__(self,*args):pass
  def makefile(self,mode):
   if failure=='makefile':raise OSError('closed socket')
   return Stream('input' if mode=='rb' else 'output')
 class Listener:
  accepted=False
  def bind(self,path):
   with open(path,'wb'):pass
  def listen(self,*args):pass
  def settimeout(self,*args):pass
  def close(self):pass
  def accept(self):
   if not self.accepted:
    self.accepted=True;return Client(),None
   states[0].shutdown.set();raise socket.timeout()
 class Thread:
  def __init__(self,target,args,**kwargs):self.target=target;self.args=args
  def start(self):
   try:self.target(*self.args)
   except OSError:pass
 m.socket.socket=lambda *args:Listener()
 m.threading.Thread=Thread
 m.DaemonState=State
 m.serve_protocol=lambda *args:None
 with tempfile.TemporaryDirectory() as root:
  m.run_daemon(os.path.join(root,'daemon.sock'),600)
 observed.append(states[0].connections)
print(json.dumps(observed))
`;
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    expect(JSON.parse(result.stdout)).toEqual([0, 0, 0]);
  }, integrationTimeout);

  it('enforces daemon session and connector ceilings without allocating resources past the limit', () => {
    const program = [
      'import importlib.util,json,sys',
      'spec=importlib.util.spec_from_file_location("dsh_helper",sys.argv[1])',
      'm=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)',
      'state=m.DaemonState(600)',
      'opened=[state.open_connection() for _ in range(m.MAX_CONNECTIONS+1)]',
      'error=None',
      'for_i=range(m.MAX_SESSIONS)',
      'servers=[state.acquire({"clientId":f"client-{i}"}) for i in for_i]',
      'try:\n state.acquire({"clientId":"client-overflow"})\nexcept m.RpcError as exc:\n error=exc.code',
      'print(json.dumps({"connections":opened,"sessions":len(state.sessions),"error":error}))',
      '[server.close() for server in servers]',
    ].join('\n');
    const result = spawnSync('python3', ['-c', program, helper], {
      encoding: 'utf8', env: { ...process.env, PYTHONDONTWRITEBYTECODE: '1' },
    });
    expect(result.status, result.stderr).toBe(0);
    const observed = JSON.parse(result.stdout);
    expect(observed.connections.slice(0, -1).every((value: boolean) => value)).toBe(true);
    expect(observed.connections.at(-1)).toBe(false);
    expect(observed).toMatchObject({ sessions: 16, error: 'E_RESOURCE_LIMIT' });
  }, integrationTimeout);

  it('serves bounded JSONL and performs confined, version-guarded file operations', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-helper-root-'));
    const outside = await mkdtemp(join(tmpdir(), 'dsh-helper-outside-'));
    temporary.push(root, outside);
    const rpc = new RpcClient();
    clients.push(rpc);

    const hello = await rpc.hello;
    expect(hello).toMatchObject({ protocol: { min: 1, max: 1 }, limits: {
      maxFrameBytes: 1_048_576, maxSessions: 16, maxConnections: 64,
      maxProcesses: 32, maxProcessOutputBytes: 2 * 1024 * 1024,
    } });
    const initialized = await rpc.request('initialize', {
      clientId: 'vitest', protocol: { min: 1, max: 1 },
    });
    expect(initialized.capabilities.filesystem).toMatchObject({
      confinement: 'dirfd-no-follow',
      guardedWrite: { helperLinearizable: true, externalWriterRaceFree: false },
    });
    await expect(rpc.request('health/ping', { nonce: 'n1' })).resolves.toEqual({ nonce: 'n1', ok: true });

    const openWorkspace = { path: root, access: 'workspace-write',
      workspaceId: 'fs-workspace', operationId: 'open-fs-workspace' };
    const workspace = await rpc.request('workspace/open', openWorkspace);
    await expect(rpc.request('workspace/open', openWorkspace)).resolves.toEqual(workspace);
    const workspaceId = workspace.workspaceId as string;
    await rpc.request('fs/mkdir', {
      workspaceId, path: 'src/nested', recursive: true, operationId: 'mkdir-1',
    });
    const created = await rpc.request('fs/write', {
      workspaceId, path: 'src/nested/value.txt', data: Buffer.from('first').toString('base64'),
      encoding: 'base64', intent: { kind: 'create-if-absent' }, operationId: 'write-1',
    });
    const read = await rpc.request('fs/read', { workspaceId, path: 'src/nested/value.txt' });
    expect(Buffer.from(read.data, 'base64').toString()).toBe('first');
    expect(read.version).toBe(created.version);
    expect(read.statVersion).toMatch(/^s1:/u);
    const opened = await rpc.request('fs/readOpen', {
      workspaceId, path: 'src/nested/value.txt', handleId: 'read-value', operationId: 'open-read-value',
    });
    let streamed = '';
    let streamVersion: string | undefined;
    let afterSeq = '0';
    for (let attempt = 0; attempt < 10 && streamVersion === undefined; attempt += 1) {
      const next = await rpc.request('fs/readNext', { handleId: opened.handleId, afterSeq, maxBytes: 2 });
      if (attempt === 0) {
        await expect(rpc.request('fs/readNext', { handleId: opened.handleId, afterSeq, maxBytes: 2 }))
          .resolves.toEqual(next);
      }
      streamed += Buffer.from(next.data, 'base64').toString();
      afterSeq = next.seq;
      streamVersion = next.version;
    }
    expect(streamed).toBe('first');
    expect(streamVersion).toBe(read.version);
    await rpc.request('fs/close', { handleId: opened.handleId, operationId: 'close-read-value' });

    const replaced = await rpc.request('fs/write', {
      workspaceId, path: 'src/nested/value.txt', data: Buffer.from('second').toString('base64'),
      encoding: 'base64', intent: { kind: 'replace-if-version', version: read.version }, operationId: 'write-2',
    });
    expect(replaced.version).not.toBe(read.version);
    const observed = await rpc.request('fs/stat', { workspaceId, path: 'src/nested/value.txt' });
    expect(observed.version).toMatch(/^s1:/u);
    await expect(rpc.request('fs/write', {
      workspaceId, path: 'src/nested/value.txt', data: Buffer.from('second-via-stat').toString('base64'),
      encoding: 'base64', intent: { kind: 'replace-if-version', version: observed.version }, operationId: 'write-stat-version',
    })).resolves.toMatchObject({ operation: 'update' });
    await expect(rpc.request('fs/write', {
      workspaceId, path: 'src/nested/value.txt', data: Buffer.from('stale').toString('base64'),
      encoding: 'base64', intent: { kind: 'replace-if-version', version: read.version }, operationId: 'write-3',
    })).rejects.toMatchObject({ code: 'E_STALE_VERSION' });

    await rpc.request('fs/write', {
      workspaceId, path: 'src/nested/race.txt', data: Buffer.from('base').toString('base64'), encoding: 'base64',
      intent: { kind: 'create-if-absent' }, operationId: 'create-race-base',
    });
    const raceRead = await rpc.request('fs/read', { workspaceId, path: 'src/nested/race.txt' });
    for (const suffix of ['a', 'b']) {
      await rpc.request('fs/writeOpen', {
        workspaceId, path: 'src/nested/race.txt', handleId: `race-${suffix}`, operationId: `open-race-${suffix}`,
        intent: { kind: 'replace-if-version', version: raceRead.version },
      });
      await rpc.request('fs/writeChunk', {
        handleId: `race-${suffix}`, afterSeq: '0', operationId: `chunk-race-${suffix}`,
        encoding: 'base64', data: Buffer.from(`winner-${suffix}`).toString('base64'),
      });
    }
    const commits = await Promise.allSettled(['a', 'b'].map((suffix) => rpc.request('fs/writeCommit', {
      handleId: `race-${suffix}`, operationId: `commit-race-${suffix}`,
    })));
    expect(commits.filter((result) => result.status === 'fulfilled')).toHaveLength(1);
    const rejectedCommit = commits.find((result) => result.status === 'rejected') as PromiseRejectedResult;
    expect(rejectedCommit.reason).toMatchObject({ code: 'E_STALE_VERSION' });
    for (const suffix of ['a', 'b']) {
      await rpc.request('fs/writeAbort', {
        handleId: `race-${suffix}`, operationId: `abort-race-${suffix}`,
      }).catch(() => {});
    }

    await symlink(outside, join(root, 'escape'));
    await expect(rpc.request('fs/stat', { workspaceId, path: 'escape' }))
      .rejects.toMatchObject({ code: 'E_SYMLINK' });
    await expect(rpc.request('fs/stat', { workspaceId, path: 'escape', follow: false }))
      .resolves.toMatchObject({ exists: true, metadata: { type: 'symlink' } });
    const listed = await rpc.request('fs/list', { workspaceId, path: 'src/nested' });
    expect(listed.entries.map((entry: any) => entry.name).sort()).toEqual(['race.txt', 'value.txt']);

    const large = Buffer.alloc(2 * 1024 * 1024 + 123);
    for (let index = 0; index < large.length; index += 1) large[index] = index % 251;
    const writeOpen = await rpc.request('fs/writeOpen', {
      workspaceId, path: 'src/nested/large.bin', handleId: 'write-large', operationId: 'open-write-large',
      intent: { kind: 'create-if-absent' },
    });
    expect(writeOpen).toMatchObject({ handleId: 'write-large', seq: '0', maxChunkBytes: 256 * 1024 });
    let writeSeq = '0';
    for (let offset = 0, index = 0; offset < large.length; offset += 192 * 1024, index += 1) {
      const chunk = large.subarray(offset, Math.min(large.length, offset + 192 * 1024));
      const params = { handleId: 'write-large', afterSeq: writeSeq, data: chunk.toString('base64'),
        encoding: 'base64', operationId: `large-chunk-${index}` };
      const written = await rpc.request('fs/writeChunk', params);
      if (index === 0) {
        await expect(rpc.request('fs/writeChunk', { ...params, operationId: 'large-chunk-0-retry' }))
          .resolves.toEqual(written);
      }
      writeSeq = written.seq;
    }
    await expect(rpc.request('fs/writeCommit', {
      handleId: 'write-large', operationId: 'commit-write-large',
    })).resolves.toMatchObject({ operation: 'create', written: large.length });
    await expect(rpc.request('fs/read', {
      workspaceId, path: 'src/nested/large.bin', maxBytes: large.length,
    })).rejects.toMatchObject({ code: 'E_TOO_LARGE' });
    await expect(rpc.request('fs/list', {
      workspaceId, path: 'src/nested', limit: 1,
    })).rejects.toMatchObject({ code: 'E_TOO_LARGE' });
    await expect(rpc.request('fs/list', {
      workspaceId, path: 'src/nested', limit: 1, allowTruncated: true,
    })).resolves.toMatchObject({ truncated: true, limit: 1 });

    await rpc.request('fs/readOpen', {
      workspaceId, path: 'src/nested/large.bin', handleId: 'read-large', operationId: 'open-read-large',
    });
    const received: Buffer[] = [];
    let largeReadSeq = '0';
    for (let attempt = 0; attempt < 100; attempt += 1) {
      const next = await rpc.request('fs/readNext', {
        handleId: 'read-large', afterSeq: largeReadSeq, maxBytes: 256 * 1024,
      });
      received.push(Buffer.from(next.data, 'base64'));
      largeReadSeq = next.seq;
      if (next.eof) break;
    }
    expect(Buffer.concat(received)).toEqual(large);
    await rpc.request('fs/close', { handleId: 'read-large', operationId: 'close-read-large' });

    const picker = join(root, 'picker-many-files');
    await mkdir(picker);
    for (let offset = 0; offset < 1_200; offset += 100) {
      await Promise.all(Array.from({ length: 100 }, (_, index) => writeFile(
        join(picker, `file-${String(offset + index).padStart(4, '0')}.txt`),
        '',
      )));
    }
    await mkdir(join(picker, 'directory-after-files'));
    await expect(rpc.request('fs/list', {
      workspaceId, path: 'picker-many-files', limit: 1_000, allowTruncated: true, types: ['directory'],
    })).resolves.toMatchObject({
      truncated: false,
      entries: [{ name: 'directory-after-files', metadata: { type: 'directory' } }],
    });
    await expect(rpc.request('health/status')).resolves.toMatchObject({ pathLocks: 0, writeHandles: 0 });
  }, integrationTimeout);

  it('runs bounded non-PTY and PTY processes and fails restricted execution closed without bwrap', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-helper-process-'));
    temporary.push(root);
    const rpc = new RpcClient({ extraEnv: { DEMO_TOKEN: 'ambient-secret' } });
    clients.push(rpc);
    await rpc.hello;
    const initialized = await rpc.request('initialize', { clientId: 'process-vitest' });

    const danger = await rpc.request('workspace/open', { path: root, access: 'danger-full-access',
      workspaceId: 'process-workspace', operationId: 'open-process-workspace' });
    const quick = await rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: 'quick-true', operationId: 'start-quick-true',
      argv: ['/usr/bin/true'], stdin: 'closed',
    });
    expect(quick).toMatchObject({ processId: 'quick-true', stdin: 'closed' });
    let quickRead: any;
    for (let attempt = 0; attempt < 10; attempt += 1) {
      quickRead = await rpc.request('process/read', { processId: 'quick-true', afterSeq: '0', waitMs: 100 });
      if (quickRead.exited) break;
    }
    expect(quickRead).toMatchObject({ exited: true, exitCode: 0 });

    await rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: 'quick-printf', operationId: 'start-quick-printf',
      argv: ['/bin/sh', '-c', "printf 'fast-output'"], stdin: 'closed',
    });
    let fastOutput = '';
    let fastCursor = '0';
    for (let attempt = 0; attempt < 10 && !fastOutput.includes('fast-output'); attempt += 1) {
      const read = await rpc.request('process/read', { processId: 'quick-printf', afterSeq: fastCursor, waitMs: 100 });
      for (const chunk of read.chunks) fastOutput += Buffer.from(chunk.data, 'base64').toString();
      fastCursor = read.nextSeq;
    }
    expect(fastOutput).toContain('fast-output');
    await rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: 'ambient-env', operationId: 'start-ambient-env',
      argv: ['/bin/sh', '-c', 'printf %s "${DEMO_TOKEN-unset}"'], stdin: 'closed',
    });
    let ambientOutput = '';
    for (let attempt = 0; attempt < 10 && ambientOutput.length === 0; attempt += 1) {
      const read = await rpc.request('process/read', { processId: 'ambient-env', afterSeq: '0', waitMs: 100 });
      ambientOutput = read.chunks.map((chunk: any) => Buffer.from(chunk.data, 'base64').toString()).join('');
    }
    expect(ambientOutput).toBe('unset');
    await rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: 'explicit-env', operationId: 'start-explicit-env',
      argv: ['/bin/sh', '-c', 'printf %s "${DEMO_TOKEN-unset}"'], stdin: 'closed', env: { DEMO_TOKEN: 'explicit-ok' },
    });
    let explicitOutput = '';
    for (let attempt = 0; attempt < 10 && explicitOutput.length === 0; attempt += 1) {
      const read = await rpc.request('process/read', { processId: 'explicit-env', afterSeq: '0', waitMs: 100 });
      explicitOutput = read.chunks.map((chunk: any) => Buffer.from(chunk.data, 'base64').toString()).join('');
    }
    expect(explicitOutput).toBe('explicit-ok');
    const process = await rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: 'plain',
      operationId: 'process-plain', argv: ['/bin/sh', '-c', "printf 'out'; printf 'err' >&2"],
    });
    expect(process).toMatchObject({ processId: 'plain', tty: false });
    let cursor = '0';
    let output = '';
    for (let attempt = 0; attempt < 10 && (!output.includes('out') || !output.includes('err')); attempt += 1) {
      const read = await rpc.request('process/read', { processId: 'plain', afterSeq: cursor, waitMs: 200 });
      for (const chunk of read.chunks) output += Buffer.from(chunk.data, 'base64').toString();
      cursor = read.nextSeq;
    }
    expect(output).toContain('out');
    expect(output).toContain('err');

    const pty = await rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: 'pty', argv: ['/bin/sh'],
      operationId: 'process-pty', tty: { rows: 24, cols: 80, term: 'xterm-256color' },
    });
    expect(pty).toMatchObject({ processId: 'pty', tty: true });
    await expect(rpc.request('process/resize', { processId: 'pty', rows: 40, cols: 100, operationId: 'resize-pty' }))
      .resolves.toEqual({ resized: true });
    await expect(rpc.request('process/inspectForeground', { processId: 'pty' }))
      .resolves.toMatchObject({ verified: true });
    await rpc.request('process/write', {
      processId: 'pty', encoding: 'base64', data: Buffer.from("printf 'pty-ok\\n'; exit\\n").toString('base64'),
      operationId: 'write-pty',
    });
    let ptyOutput = '';
    cursor = '0';
    for (let attempt = 0; attempt < 10 && !ptyOutput.includes('pty-ok'); attempt += 1) {
      const read = await rpc.request('process/read', { processId: 'pty', afterSeq: cursor, waitMs: 200 });
      for (const chunk of read.chunks) ptyOutput += Buffer.from(chunk.data, 'base64').toString();
      cursor = read.nextSeq;
    }
    expect(ptyOutput).toContain('pty-ok');
    const concurrentPtys = await Promise.all(['a', 'b'].map((suffix) => rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: `pty-${suffix}`, operationId: `start-pty-${suffix}`,
      argv: suffix === 'a' ? ['/bin/cat'] : ['/bin/sh'], tty: { rows: 24, cols: 80, term: 'xterm-256color' },
    })));
    expect(concurrentPtys).toHaveLength(2);
    const largePtyInput = Buffer.from('x\n'.repeat(96 * 1024));
    const ptyWrites = await Promise.all(['a', 'b'].map((suffix) => rpc.request('process/write', {
      processId: `pty-${suffix}`, operationId: `exit-pty-${suffix}`, encoding: 'base64',
      data: (suffix === 'a' ? largePtyInput : Buffer.from('exit\n')).toString('base64'),
    })));
    expect(ptyWrites[0]).toMatchObject({ written: largePtyInput.length });

    await rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: 'concurrent-cat', operationId: 'start-concurrent-cat',
      argv: ['/bin/cat'],
    });
    const waitingRead = rpc.request('process/read', {
      processId: 'concurrent-cat', afterSeq: '0', waitMs: 1_000,
    });
    await new Promise((resolve) => setTimeout(resolve, 20));
    const writeStarted = Date.now();
    const largePipeInput = Buffer.alloc(384 * 1024, 0x61);
    const pipeWrite = await rpc.request('process/write', {
      processId: 'concurrent-cat', operationId: 'write-concurrent-cat', encoding: 'base64',
      data: largePipeInput.toString('base64'),
    });
    expect(pipeWrite).toMatchObject({ written: largePipeInput.length });
    expect(Date.now() - writeStarted).toBeLessThan(500);
    const concurrentRead = await waitingRead;
    expect(Buffer.concat(concurrentRead.chunks.map((chunk: any) => Buffer.from(chunk.data, 'base64'))).length)
      .toBeGreaterThan(0);
    await rpc.request('process/write', {
      processId: 'concurrent-cat', operationId: 'eof-concurrent-cat', encoding: 'base64', data: '', eof: true,
    });
    await rpc.request('process/release', { processId: 'plain', operationId: 'release-plain' });
    await rpc.request('process/release', { processId: 'pty', operationId: 'release-pty' });
    await rpc.request('process/release', { processId: 'concurrent-cat', operationId: 'release-concurrent-cat' });
    await rpc.request('process/release', { processId: 'quick-true', operationId: 'release-quick-true' });
    await rpc.request('process/release', { processId: 'quick-printf', operationId: 'release-quick-printf' });
    await rpc.request('process/release', { processId: 'ambient-env', operationId: 'release-ambient-env' });
    await rpc.request('process/release', { processId: 'explicit-env', operationId: 'release-explicit-env' });
    await rpc.request('process/release', { processId: 'pty-a', operationId: 'release-pty-a' });
    await rpc.request('process/release', { processId: 'pty-b', operationId: 'release-pty-b' });

    for (let index = 0; index < 8; index += 1) {
      const immediate = await rpc.request('process/start', {
        workspaceId: danger.workspaceId, cwd: '', processId: `immediate-pty-${index}`,
        operationId: `start-immediate-pty-${index}`, argv: ['/bin/sh'],
        tty: { rows: 24, cols: 80, term: 'xterm-256color' },
      });
      await rpc.request('process/release', {
        processId: `immediate-pty-${index}`, operationId: `release-immediate-pty-${index}`,
      });
      expect(() => nodeProcess.kill(immediate.pid, 0)).toThrow(expect.objectContaining({ code: 'ESRCH' }));
    }

    const cappedStarts = await Promise.allSettled(Array.from({ length: 40 }, (_, index) => rpc.request('process/start', {
      workspaceId: danger.workspaceId, cwd: '', processId: `capped-${index}`, operationId: `start-capped-${index}`,
      argv: ['/bin/sleep', '30'], stdin: 'closed',
    })));
    const startedAtLimit = cappedStarts
      .map((result, index) => ({ result, index }))
      .filter((item): item is { result: PromiseFulfilledResult<any>; index: number } => item.result.status === 'fulfilled');
    expect(startedAtLimit).toHaveLength(32);
    const rejectedAtLimit = cappedStarts.filter((result): result is PromiseRejectedResult => result.status === 'rejected');
    expect(rejectedAtLimit).toHaveLength(8);
    expect(rejectedAtLimit.map(result => ({ code: result.reason.code, message: result.reason.message })))
      .toEqual(Array.from({ length: 8 }, () => ({ code: 'E_RESOURCE_LIMIT', message: expect.any(String) })));
    await Promise.all(startedAtLimit.map(({ index }) => rpc.request('process/release', {
      processId: `capped-${index}`, operationId: `release-capped-${index}`,
    })));

    const restricted = await rpc.request('workspace/open', { path: root, access: 'workspace-write',
      workspaceId: 'restricted-workspace', operationId: 'open-restricted-workspace' });
    if (initialized.capabilities.process.sandbox === 'none') {
      await expect(rpc.request('process/start', {
        workspaceId: restricted.workspaceId, cwd: '', argv: ['/usr/bin/true'], operationId: 'restricted-process',
      })).rejects.toMatchObject({ code: 'E_SANDBOX_UNAVAILABLE' });
    } else {
      const hostMarkerName = `dsh-helper-host-marker-${Date.now()}`;
      const hostMarker = join(tmpdir(), hostMarkerName);
      await writeFile(hostMarker, 'host-only');
      temporary.push(hostMarker);
      await rpc.request('process/start', {
        workspaceId: restricted.workspaceId, cwd: '', processId: 'restricted-policy', operationId: 'start-restricted-policy',
        argv: ['/bin/sh', '-c', `tmp=$(mktemp) && printf ok >"$tmp" && rm -f "$tmp" && test ! -e /tmp/${hostMarkerName} && printf workspace >.dsh-policy-proof && rm -f .dsh-policy-proof && pids=$(find /proc -maxdepth 1 -type d -name "[0-9]*" | wc -l) && test "$pids" -lt 10 && if printf no >/etc/dsh-helper-policy-test; then exit 99; else printf policy-ok; fi`],
        stdin: 'closed',
      });
      let restrictedOutput = '';
      let restrictedCursor = '0';
      for (let attempt = 0; attempt < 20 && !restrictedOutput.includes('policy-ok'); attempt += 1) {
        const read = await rpc.request('process/read', {
          processId: 'restricted-policy', afterSeq: restrictedCursor, waitMs: 100,
        });
        restrictedCursor = read.nextSeq;
        for (const chunk of read.chunks) restrictedOutput += Buffer.from(chunk.data, 'base64').toString();
      }
      expect(restrictedOutput).toContain('policy-ok');
      expect(await readFile(hostMarker, 'utf8')).toBe('host-only');
      await rm(hostMarker, { force: true });
      await rpc.request('process/release', {
        processId: 'restricted-policy', operationId: 'release-restricted-policy',
      });
    }
  }, integrationTimeout);

  it.skipIf(process.env.CODEX_SANDBOX_NETWORK_DISABLED === '1')('coordinates guarded commits from two real daemon clients', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-helper-writers-'));
    const runtimeDir = await mkdtemp(join(tmpdir(), 'dsh-helper-writer-runtime-'));
    temporary.push(root, runtimeDir);
    await mkdir(join(root, 'project'));
    await writeFile(join(root, 'project', 'shared.txt'), 'seed');
    const first = new RpcClient({ direct: false, runtimeDir });
    const second = new RpcClient({ direct: false, runtimeDir });
    clients.push(first, second);
    await Promise.all([first.hello, second.hello]);
    const [a, b] = await Promise.all([
      first.request('initialize', { clientId: 'writer-a' }),
      second.request('initialize', { clientId: 'writer-b' }),
    ]);
    try {
      expect(a.session.serverEpoch).toBe(b.session.serverEpoch);
      expect(a.session.sessionId).not.toBe(b.session.sessionId);
      expect(a.capabilities.filesystem.guardedWrite).toMatchObject({ coordinationScope: 'daemon', externalWriterRaceFree: false });
      await Promise.all([
        first.request('workspace/open', { path: join(root, 'project'), workspaceId: 'w', operationId: 'w', access: 'workspace-write' }),
        second.request('workspace/open', { path: root, workspaceId: 'w', operationId: 'w', access: 'workspace-write' }),
      ]);
      for (let index = 0; index < 8; index += 1) {
        const { version } = await first.request('fs/read', { workspaceId: 'w', path: 'shared.txt' });
        const results = await Promise.allSettled([
          first.request('fs/write', { workspaceId: 'w', path: 'shared.txt', operationId: `write-${index}`,
            intent: { kind: 'replace-if-version', version }, data: Buffer.from(`a-${index}`).toString('base64') }),
          second.request('fs/write', { workspaceId: 'w', path: 'project/shared.txt', operationId: `write-${index}`,
            intent: { kind: 'replace-if-version', version }, data: Buffer.from(`b-${index}`).toString('base64') }),
        ]);
        expect(results.filter(result => result.status === 'fulfilled')).toHaveLength(1);
        expect(results.filter(result => result.status === 'rejected').map(result => result.reason.code)).toEqual(['E_STALE_VERSION']);
      }
      expect(await first.request('health/status')).toMatchObject({ pathLocks: 0 });
    } finally {
      await first.request('admin/shutdown');
    }
  }, integrationTimeout);

  it.skipIf(process.env.CODEX_SANDBOX_NETWORK_DISABLED === '1')('keeps a process in the per-user daemon and resumes it by clientId and token', async () => {
    const root = await mkdtemp(join(tmpdir(), 'dsh-helper-resume-root-'));
    const runtimeDir = await mkdtemp(join(tmpdir(), 'dsh-helper-runtime-'));
    temporary.push(root, runtimeDir);
    const first = new RpcClient({ direct: false, runtimeDir });
    clients.push(first);
    await first.hello;
    const initialized = await first.request('initialize', { clientId: 'resume-vitest', retentionMs: 60_000 });
    const workspace = await first.request('workspace/open', { path: root, access: 'danger-full-access',
      workspaceId: 'resume-workspace', operationId: 'open-resume-workspace' });
    await first.request('process/start', {
      workspaceId: workspace.workspaceId, cwd: '', processId: 'retained', operationId: 'retained-start',
      argv: ['/bin/sh', '-c', "sleep 0.1; printf 'resumed-output'; sleep 0.2"],
    });
    await first.close();
    clients.splice(clients.indexOf(first), 1);

    const rejected = new RpcClient({ direct: false, runtimeDir });
    clients.push(rejected);
    await rejected.hello;
    await expect(rejected.request('initialize', {
      clientId: 'resume-vitest', resumeToken: 'wrong-resume-token',
    })).rejects.toMatchObject({ code: 'E_RESUME_DENIED' });
    await rejected.close();
    clients.splice(clients.indexOf(rejected), 1);

    const second = new RpcClient({ direct: false, runtimeDir });
    clients.push(second);
    await second.hello;
    const resumed = await second.request('initialize', {
      clientId: 'resume-vitest', resumeToken: initialized.session.resumeToken,
    });
    expect(resumed.session).toMatchObject({ resumed: true, sessionId: initialized.session.sessionId });
    let output = '';
    let cursor = '0';
    for (let attempt = 0; attempt < 10 && !output.includes('resumed-output'); attempt += 1) {
      const read = await second.request('process/read', { processId: 'retained', afterSeq: cursor, waitMs: 200 });
      for (const chunk of read.chunks) output += Buffer.from(chunk.data, 'base64').toString();
      cursor = read.nextSeq;
    }
    expect(output).toContain('resumed-output');
    await second.request('admin/shutdown');
  }, integrationTimeout);
});
