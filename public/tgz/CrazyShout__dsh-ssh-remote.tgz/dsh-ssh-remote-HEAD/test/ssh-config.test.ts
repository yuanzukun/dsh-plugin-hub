import { describe, expect, it } from 'vitest';
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { formatSshUri, parseSshUri } from '../src/types.js';
import {
  collectSshAliases,
  discoverSshHosts,
  parseOpenSshResolvedConfig,
  parseSshConfig,
  resolveSshAlias,
} from '../src/ssh-config.js';

describe('parseSshUri', () => {
  it('parses a full uri', () => {
    expect(parseSshUri('ssh://bob@host:2222/a/b')).toEqual({
      host: 'host',
      port: 2222,
      user: 'bob',
      path: '/a/b',
    });
  });

  it('defaults port 22 and empty user', () => {
    expect(parseSshUri('ssh://host/')).toEqual({
      host: 'host',
      port: 22,
      user: '',
      path: '/',
    });
  });

  it('round-trips through formatSshUri', () => {
    const uri = 'ssh://bob@host:2222/a/b';
    expect(formatSshUri(parseSshUri(uri))).toBe(uri);
  });

  it('parses bracketed IPv6 and round-trips it safely', () => {
    const parsed = parseSshUri('ssh://atlas@[2001:db8::1]:2202/home/atlas');
    expect(parsed).toEqual({ host: '2001:db8::1', port: 2202, user: 'atlas', path: '/home/atlas' });
    expect(formatSshUri(parsed)).toBe('ssh://atlas@[2001:db8::1]:2202/home/atlas');
  });

  it('rejects malformed ports, unbracketed IPv6, and option-like authorities', () => {
    expect(() => parseSshUri('ssh://host:not-a-port/path')).toThrow(/port/u);
    expect(() => parseSshUri('ssh://host:70000/path')).toThrow(/port/u);
    expect(() => parseSshUri('ssh://2001:db8::1/path')).toThrow(/brackets/u);
    expect(() => parseSshUri('ssh://-oProxyCommand=bad/path')).toThrow(/host/u);
    expect(() => parseSshUri('ssh://-Fbad@host/path')).toThrow(/user/u);
  });
});

describe('parseSshConfig', () => {
  it('resolves concrete aliases and ignores wildcards', () => {
    const hosts = parseSshConfig(`
Host devbox
  HostName dev.example.com
  User you
  Port 2222
  IdentityFile ~/.ssh/id_ed25519

Host *
  User nobody
`);
    expect(hosts).toHaveLength(1);
    expect(resolveSshAlias('devbox', hosts)).toEqual({
      host: 'devbox',
      hostName: 'dev.example.com',
      user: 'you',
      port: 2222,
      identityFile: expect.stringContaining('id_ed25519'),
      identityFiles: [expect.stringContaining('id_ed25519')],
    });
  });

  it('returns undefined for an unknown alias', () => {
    expect(resolveSshAlias('nope', [])).toBeUndefined();
  });

  it('collects concrete aliases recursively through Include files', () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-ssh-config-'));
    try {
      mkdirSync(join(root, 'conf.d'));
      writeFileSync(join(root, 'config'), `
Include conf.d/*.conf
Host primary secondary
  HostName primary.example.com
Host *.internal
  User ignored
`);
      writeFileSync(join(root, 'conf.d', 'gpu.conf'), `
Host gpu
  HostName gpu.example.com
Include ../config
`);

      expect(collectSshAliases(join(root, 'config'))).toEqual(['gpu', 'primary', 'secondary']);
    } finally {
      rmSync(root, { recursive: true, force: true });
    }
  });

  it('parses effective OpenSSH output including proxy settings', () => {
    expect(parseOpenSshResolvedConfig('devbox', `
host devbox
hostname dev.example.com
user atlas
port 2202
identityfile ~/.ssh/missing
identityfile ~/.ssh/id_ed25519
proxyjump jump-a,jump-b
stricthostkeychecking ask
userknownhostsfile ~/.ssh/known_hosts ~/.ssh/known_hosts_work
globalknownhostsfile /etc/ssh/ssh_known_hosts
`)).toEqual({
      host: 'devbox',
      hostName: 'dev.example.com',
      user: 'atlas',
      port: 2202,
      identityFile: expect.stringContaining('/.ssh/missing'),
      identityFiles: [
        expect.stringContaining('/.ssh/missing'),
        expect.stringContaining('/.ssh/id_ed25519'),
      ],
      proxyJump: 'jump-a,jump-b',
      proxyCommand: undefined,
      hostKeyAlias: undefined,
      strictHostKeyChecking: 'ask',
      userKnownHostsFiles: [
        expect.stringContaining('/.ssh/known_hosts'),
        expect.stringContaining('/.ssh/known_hosts_work'),
      ],
      globalKnownHostsFiles: ['/etc/ssh/ssh_known_hosts'],
    });
  });

  it('discovers aliases and delegates effective resolution to ssh -G', async () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-ssh-discovery-'));
    try {
      const configPath = join(root, 'config');
      writeFileSync(configPath, 'Host beta\nHost alpha\n');
      const hosts = await discoverSshHosts(configPath, async (receivedPath, alias) => ({
        code: 0,
        stdout: `hostname ${alias}.example.com\nuser you\nport 22\n`,
        stderr: '',
      }));
      expect(hosts.map((host) => host.host)).toEqual(['alpha', 'beta']);
      expect(hosts.map((host) => host.hostName)).toEqual(['alpha.example.com', 'beta.example.com']);
    } finally {
      rmSync(root, { recursive: true, force: true });
    }
  });

  it('bounds concurrent ssh -G discovery for large configs', async () => {
    const root = mkdtempSync(join(tmpdir(), 'dsh-ssh-discovery-limit-'));
    try {
      const configPath = join(root, 'config');
      writeFileSync(configPath, Array.from({ length: 24 }, (_, index) => `Host host-${index}`).join('\n'));
      let active = 0;
      let maximum = 0;
      const hosts = await discoverSshHosts(configPath, async (_receivedPath, alias) => {
        active += 1;
        maximum = Math.max(maximum, active);
        await new Promise((resolveDelay) => setTimeout(resolveDelay, 2));
        active -= 1;
        return { code: 0, stdout: `hostname ${alias}.example.com\nuser you\nport 22\n`, stderr: '' };
      });
      expect(hosts).toHaveLength(24);
      expect(maximum).toBeLessThanOrEqual(8);
    } finally {
      rmSync(root, { recursive: true, force: true });
    }
  });
});
