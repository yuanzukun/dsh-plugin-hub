/**
 * Token Combo — Host half.
 *
 * Tracks the live "combo" of an agent's token stream for every session and
 * exposes the derived state to the Client half through one Host RPC channel
 * (`/token-combo`). The Client polls that channel with a revision cursor.
 *
 * Everything in this file is plain ESM with no imports: the Host loads it as a
 * profile-installed Cordis plugin (`inject = ['timer', 'webServer']`). Every
 * listener body is try/catch defended and the RPC handler always resolves an envelope,
 * because a throwing plugin listener would poison unrelated Host work.
 *
 * The authoritative contract lives in `INTERFACE.md`; the emitted snapshot is
 * deliberately small (plain arrays/objects/numbers/strings — no Map, no class
 * instances) so it can cross the RPC wire as JSON and be polled cheaply.
 */

import { readFile } from 'node:fs/promises'
import { existsSync, readdirSync } from 'node:fs'
import { spawn } from 'node:child_process'
import { fileURLToPath } from 'node:url'
import { randomBytes } from 'node:crypto'

export const inject = ['timer', 'webServer']

/** RPC channel shared with the Client half. */
const CHANNEL = '/token-combo'
const ART_IDS = new Set(['deepseek', 'chatgpt', 'claude', 'gemini', 'glm', 'grok', 'qwen'])
const artCache = new Map()

/** Static files for the standalone WebView2 HUD page. */
const HUD_STATIC = {
  '/hud/page': ['../hud/standalone.html', 'text/html; charset=utf-8'],
  '/hud/standalone.js': ['../hud/standalone.js', 'text/javascript; charset=utf-8'],
  '/hud/client.js': ['../client.js', 'text/javascript; charset=utf-8'],
  '/hud/vendor/react.js': ['../hud/vendor/react.js', 'text/javascript; charset=utf-8'],
  '/hud/vendor/react-dom.js': ['../hud/vendor/react-dom.js', 'text/javascript; charset=utf-8'],
}


/** Combo level table: `at` is the cumulative hit count, so each stage needs 30/60/120/240/500/1000 hits. */
const LEVELS = [
  { level: 1, at: 0, multiplier: 1, tier: 'READY' },
  { level: 2, at: 30, multiplier: 1.5, tier: 'NICE' },
  { level: 3, at: 90, multiplier: 2, tier: 'GREAT' },
  { level: 4, at: 210, multiplier: 3, tier: 'FRENZY' },
  { level: 5, at: 450, multiplier: 4, tier: 'FEVER' },
  { level: 6, at: 950, multiplier: 5, tier: 'GODLIKE' },
  { level: 7, at: 1950, multiplier: 8, tier: 'LEGEND' },
]

/** Milestones up to 1000; afterwards one every 500. */
const MILESTONE_BASE = [10, 25, 50, 100, 150, 200, 300, 500, 750, 1000]
const MILESTONE_STEP = 500

/** Hard safety caps (never reached by a sane Host, but never unbounded). */
const MAX_WAITERS = 64
const MAX_SESSIONS_HARD_CAP = 64

/** Bound the official-token reconcile map per member (old turns are pruned anyway). */
const MAX_OFFICIAL_KEYS = 2_000

/* ------------------------------------------------------------------ helpers */

/** Coerce to a finite integer, else the fallback. */
function toInteger(value, fallback) {
  const number = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(number) ? Math.trunc(number) : fallback
}

/** Coerce to a finite number, else the fallback. */
function toNumber(value, fallback) {
  const number = typeof value === 'number' ? value : Number(value)
  return Number.isFinite(number) ? number : fallback
}

/** Level spec for an explicit stage number (clamped to the table). */
function levelSpec(level) {
  const index = Math.min(LEVELS.length, Math.max(1, toInteger(level, 1))) - 1
  const current = LEVELS[index]
  const next = LEVELS[index + 1]
  return {
    level: current.level,
    multiplier: current.multiplier,
    tier: current.tier,
    nextLevelAt: next === undefined ? 0 : next.at,
    hitsToNext: next === undefined ? 0 : Math.max(1, next.at - current.at),
  }
}

/** First milestone strictly greater than `combo`. */
function nextMilestoneAt(combo) {
  for (let index = 0; index < MILESTONE_BASE.length; index += 1) {
    if (combo < MILESTONE_BASE[index]) return MILESTONE_BASE[index]
  }
  const base = MILESTONE_BASE[MILESTONE_BASE.length - 1]
  return base + Math.ceil((combo - base + 1) / MILESTONE_STEP) * MILESTONE_STEP
}

/** Highest milestone crossed when combo moves from `previous` to `next`. */
function crossedMilestone(previous, next) {
  if (next <= previous) return 0
  let highest = 0
  let candidate = nextMilestoneAt(previous)
  for (let guard = 0; guard < 64 && candidate <= next; guard += 1) {
    highest = candidate
    candidate = nextMilestoneAt(candidate)
  }
  return highest
}

/** CJK / full-width code points (Han, Kana, Hangul, CJK punctuation). */
function isCjkCodePoint(code) {
  return (
    (code >= 0x2e80 && code <= 0x2eff) ||
    (code >= 0x3000 && code <= 0x30ff) ||
    (code >= 0x3100 && code <= 0x31bf) ||
    (code >= 0x3400 && code <= 0x4dbf) ||
    (code >= 0x4e00 && code <= 0x9fff) ||
    (code >= 0xac00 && code <= 0xd7af) ||
    (code >= 0xf900 && code <= 0xfaff) ||
    (code >= 0xfe30 && code <= 0xfe4f) ||
    (code >= 0xff00 && code <= 0xffef)
  )
}

/**
 * Token estimate for one streamed delta: CJK chars * 0.8 + other chars / 4,
 * at least 1 when the delta is non-empty (INTERFACE.md "Combo model").
 */
function estimateDelta(text) {
  if (typeof text !== 'string' || text.length === 0) return 0
  let cjk = 0
  let other = 0
  for (const character of text) {
    if (isCjkCodePoint(character.codePointAt(0))) cjk += 1
    else other += 1
  }
  const raw = cjk * 0.8 + other / 4
  return raw > 1 ? raw : 1
}

/**
 * Session id plus the durable header from an Agent-shaped object. The header
 * carries `parentSession` / `origin: 'subagent'`, which is how this plugin maps
 * a teammate/subagent session back to the conversation root it belongs to.
 */
function sessionInfoFromAgent(agent) {
  if (agent === null || agent === undefined || typeof agent !== 'object') return null
  const session = agent.session
  if (session !== null && session !== undefined && typeof session === 'object') {
    const header = session.header !== null && session.header !== undefined && typeof session.header === 'object' ? session.header : null
    if (typeof session.id === 'string' && session.id.length > 0) return { id: session.id, header }
  }
  if (typeof agent.id === 'string' && agent.id.length > 0) return { id: agent.id, header: null }
  if (typeof agent.sessionId === 'string' && agent.sessionId.length > 0) return { id: agent.sessionId, header: null }
  return null
}

/** Session id plus durable header from a Session-shaped object (`session/event` first argument). */
function sessionInfoFromSession(session) {
  if (session === null || session === undefined || typeof session !== 'object') return null
  if (typeof session.id !== 'string' || session.id.length === 0) return null
  const header = session.header !== null && session.header !== undefined && typeof session.header === 'object' ? session.header : null
  return { id: session.id, header }
}

/* ------------------------------------------------------------ config / state */

/** Defensively read the plugin config; every field is optional. */
function readConfig(config) {
  const source = config !== null && config !== undefined && typeof config === 'object' ? config : {}
  const pick = (value, fallback, minimum, maximum) => {
    const number = toNumber(value, fallback)
    return Math.min(maximum, Math.max(minimum, number))
  }
  return {
    publishIntervalMs: pick(source.publishIntervalMs, 80, 0, 60_000),
    breakMs: pick(source.breakMs, 5_000, 100, 3_600_000),
    idleMemoryMs: pick(source.idleMemoryMs, 10 * 60_000, 1_000, 24 * 3_600_000),
    settleHoldMs: pick(source.settleHoldMs, 2_200, 100, 60_000),
    breakHoldMs: pick(source.breakHoldMs, 1_800, 100, 60_000),
    tickMs: pick(source.tickMs, 250, 50, 5_000),
    pollDefaultMs: pick(source.pollDefaultMs, 15_000, 0, 25_000),
    pollMaxMs: pick(source.pollMaxMs, 25_000, 1_000, 25_000),
    maxSessions: pick(source.maxSessions, 16, 1, MAX_SESSIONS_HARD_CAP),
    now: typeof source.now === 'function' ? source.now : null,
  }
}

/**
 * One conversation-root "game session": the root session plus every subagent
 * session below it share this state, so all of their deltas feed one combo.
 */
function createSessionState(id, time) {
  return {
    id,
    /** Member session ids (the root itself first, then every seen descendant). */
    members: new Set([id]),
    running: false,
    phase: 'idle',
    combo: 0,
    level: 1,
    maxCombo: 0,
    bestCombo: 0,
    hits: 0,
    scoreExact: 0,
    /** Official usage accumulated during the current root turn / the whole root lifetime. */
    officialTurn: 0,
    officialSession: 0,
    turn: 0,
    step: 0,
    lastHitAt: 0,
    /** Stage charge 0..1: hits fill it, reaching 1 advances the multiplier stage. */
    energy: 0,
    energyAt: 0,
    /** False right after a stage advance, until the next hit starts the new stage. */
    chargeActive: false,
    /** The root session's own turn is open. */
    openTurn: false,
    /** Number of attempts currently streaming across all members. */
    busy: 0,
    /** Root turn ended while an attempt was still running; settle once it drains. */
    pendingTurnEnd: false,
    activeAt: time,
    startedAt: 0,
    milestone: 0,
    milestoneSeq: 0,
    hitSeq: 0,
    breakSeq: 0,
    settleSeq: 0,
    startSeq: 0,
    completedTurns: 0,
    holdAt: 0,
  }
}

/** Per-member tracking folded into one root game session. */
function createMember(id) {
  return {
    id,
    rootId: null,
    running: false,
    building: false,
    activeAttempt: false,
    /** In-flight attempt: `{ id, turn, step, official }` (official is max-seen usage). */
    attempt: null,
    /** Live estimate for the in-flight attempt; the root sums these. */
    live: 0,
    /** Usage seen without an attempt start frame; settled at the end frame. */
    pendingOfficial: 0,
    /** `turn:step` -> already-applied official tokens (max reconcile, not first-wins). */
    officialKeys: new Map(),
    turn: 0,
    step: 0,
  }
}

/* ------------------------------------------------------------------- plugin */

/**
 * Install the Host half: event folding, phase tick, and the RPC channel.
 *
 * @param ctx - owning Cordis Context (the bundle injects `connection`).
 * @param config - optional overrides; see `readConfig`.
 */
export function apply(ctx, config = {}) {
  const cfg = readConfig(config)
  /** Root game sessions (one per conversation tree). */
  const roots = new Map()
  /** Every tracked session id -> member record. */
  const members = new Map()
  /** Child session id -> parent session id, learned from durable session headers. */
  const parentOf = new Map()
  /** Session ids whose header says `origin: 'subagent'`. */
  const subagentOf = new Map()

  let revision = 1
  let lastPublishAt = -Infinity
  let publishTimer = null
  let disposed = false
  const waiters = new Set()

  const log = (level, message) => {
    try {
      const logger = ctx.logger
      if (logger !== null && logger !== undefined && typeof logger[level] === 'function') logger[level](`[token-combo] ${String(message)}`)
    } catch {
      /* logging is advisory */
    }
  }

  /* --------------------------------------------------------- desktop HUD */
  const hudToken = randomBytes(16).toString('hex')
  const hudScriptPath = fileURLToPath(new URL('../hud/TokenComboWebView2.ps1', import.meta.url))
  let hudProcess = null
  /** The WebView2 page reported `ready` through `/hud/sync?ready=1`. */
  let hudReady = false
  let hudReadyTimer = null
  let hudReadyWaiters = []
  let hudInteractive = true
  let webview2Available = null
  let hudPrefs = { style: 'deepseek', scale: 1, align: 'left', locale: 'zh', hotkeysEnabled: true, hotkeyToggle: 'Ctrl+Alt+T', hotkeyClose: 'Ctrl+Alt+X' }

  /** The desktop HUD is actually on screen (process alive and page ready). */
  const hudOpen = () => hudProcess !== null && hudReady === true

  /** Resolve every open-waiter with the current readiness, clearing the safety timer. */
  const settleHudReady = (ready) => {
    if (hudReadyTimer !== null) {
      clearTimeout(hudReadyTimer)
      hudReadyTimer = null
    }
    hudReady = ready === true && hudProcess !== null
    const pending = hudReadyWaiters
    hudReadyWaiters = []
    for (const resolve of pending) {
      try {
        resolve(hudReady)
      } catch {
        /* waiter already settled */
      }
    }
  }

  /** Wait until the HUD page reports ready (or the process dies / the timeout hits). */
  const waitHudReady = (timeoutMs) =>
    new Promise((resolve) => {
      if (hudReady === true && hudProcess !== null) {
        resolve(true)
        return
      }
      if (hudProcess === null) {
        resolve(false)
        return
      }
      hudReadyWaiters.push(resolve)
      const timer = setTimeout(() => {
        hudReadyWaiters = hudReadyWaiters.filter((entry) => entry !== resolve)
        resolve(hudReady === true && hudProcess !== null)
      }, timeoutMs)
      if (typeof timer.unref === 'function') timer.unref()
    })

  const sanitizeHudPrefs = (raw) => {
    const value = raw !== null && raw !== undefined && typeof raw === 'object' ? raw : {}
    return {
      style: typeof value.style === 'string' && ART_IDS.has(value.style) ? value.style : hudPrefs.style,
      scale: Math.min(2.4, Math.max(0.8, toNumber(value.scale, hudPrefs.scale))),
      align: value.align === 'right' ? 'right' : 'left',
      locale: value.locale === 'en' ? 'en' : 'zh',
      hotkeysEnabled: value.hotkeysEnabled !== false,
      hotkeyToggle: typeof value.hotkeyToggle === 'string' && value.hotkeyToggle.trim() !== '' ? value.hotkeyToggle.slice(0, 32) : hudPrefs.hotkeyToggle,
      hotkeyClose: typeof value.hotkeyClose === 'string' && value.hotkeyClose.trim() !== '' ? value.hotkeyClose.slice(0, 32) : hudPrefs.hotkeyClose,
    }
  }

  const hudStateUrl = () => {
    const origin = ctx.webServer.getOrigin()
    return String(origin).replace(/\/$/, '') + CHANNEL + '/hud/state'
  }

  const hudPageUrl = () => {
    const origin = String(ctx.webServer.getOrigin()).replace(/\/$/, '')
    const query = [
      `style=${encodeURIComponent(hudPrefs.style)}`,
      `scale=${encodeURIComponent(String(hudPrefs.scale))}`,
      `align=${encodeURIComponent(hudPrefs.align)}`,
      `locale=${encodeURIComponent(hudPrefs.locale)}`,
      `token=${encodeURIComponent(hudToken)}`,
    ].join('&')
    return `${origin}${CHANNEL}/hud/page?${query}`
  }

  const isWebView2Available = () => {
    if (typeof process === 'undefined' || process.platform !== 'win32') return false
    if (webview2Available === true) return true
    const roots = [process.env['ProgramFiles(x86)'], process.env.ProgramFiles, process.env.LOCALAPPDATA].filter(Boolean)
    for (const root of roots) {
      const base = `${root}\\Microsoft\\EdgeWebView\\Application`
      try {
        if (existsSync(base) && readdirSync(base).length > 0) {
          webview2Available = true
          return true
        }
      } catch {
        /* ignore probe failures */
      }
    }
    return false
  }

  /** Terminate the HUD process tree so msedgewebview2 children do not linger. */
  const terminateHudProcess = () => {
    const child = hudProcess
    if (child === null) {
      settleHudReady(false)
      return
    }
    hudProcess = null
    settleHudReady(false)
    try {
      if (typeof process !== 'undefined' && process.platform === 'win32' && child.pid !== undefined) {
        const killer = spawn('taskkill', ['/pid', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' })
        if (killer !== null && killer !== undefined) {
          killer.on('error', () => {
            try {
              child.kill()
            } catch {
              /* already gone */
            }
          })
        }
      } else {
        child.kill()
      }
    } catch {
      try {
        child.kill()
      } catch {
        /* already gone */
      }
    }
    requestPublish()
  }

  const closeHud = () => {
    if (hudProcess === null) return
    terminateHudProcess()
  }

  /** Spawn the PowerShell HUD host, then wait for its page to report ready. */
  const openHud = async () => {
    if (hudProcess !== null) {
      if (hudReady !== true) await waitHudReady(8_000)
      return { ok: true, value: { open: hudOpen(), interactive: hudInteractive, prefs: hudPrefs, webview2: isWebView2Available() } }
    }
    if (!isWebView2Available()) {
      return { ok: true, value: { open: false, interactive: hudInteractive, prefs: hudPrefs, webview2: false } }
    }
    try {
      const child = spawn(
        'powershell.exe',
        ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-WindowStyle', 'Hidden', '-File', hudScriptPath, '-Url', hudStateUrl(), '-Token', hudToken, '-PageUrl', hudPageUrl(), '-Scale', String(hudPrefs.scale)],
        { windowsHide: true, stdio: 'ignore' },
      )
      hudProcess = child
      hudReady = false
      hudReadyTimer = setTimeout(() => {
        log('warn', 'desktop HUD did not become ready; terminating it')
        terminateHudProcess()
      }, 10_000)
      if (typeof hudReadyTimer.unref === 'function') hudReadyTimer.unref()
      child.on('exit', () => {
        if (hudProcess === child) {
          hudProcess = null
          settleHudReady(false)
        }
        requestPublish()
      })
      child.on('error', (error) => {
        log('warn', `desktop HUD failed to start: ${String(error)}`)
        if (hudProcess === child) terminateHudProcess()
      })
    } catch (error) {
      log('warn', `desktop HUD spawn failed: ${String(error)}`)
      hudProcess = null
      settleHudReady(false)
    }
    const ready = await waitHudReady(8_000)
    if (ready !== true) terminateHudProcess()
    return { ok: true, value: { open: hudOpen(), interactive: hudInteractive, prefs: hudPrefs, webview2: isWebView2Available() } }
  }

  /** Epoch milliseconds; `config.now` keeps the harness deterministic. */
  const clock = () => {
    if (cfg.now !== null) {
      try {
        const value = cfg.now()
        if (Number.isFinite(value)) return Math.trunc(value)
      } catch {
        /* fall through to the wall clock */
      }
    }
    return Date.now()
  }

  /* --------------------------------------------------- session lineage */

  /** Whether a session is a subagent (teammate) session rather than a conversation root. */
  function isSubagentSession(id) {
    return subagentOf.get(id) === true
  }

  /** Walk `parentSession` links up to the conversation root (cycle-safe). */
  function rootOf(id) {
    let current = id
    for (let guard = 0; guard < 64; guard += 1) {
      if (!isSubagentSession(current)) return current
      const parent = parentOf.get(current)
      if (typeof parent !== 'string' || parent.length === 0) return current
      current = parent
    }
    return id
  }

  /** Drop one root game session and all of its member records. */
  function dropRoot(rootId) {
    const state = roots.get(rootId)
    if (state === undefined) return false
    for (const memberId of state.members) {
      members.delete(memberId)
      parentOf.delete(memberId)
      subagentOf.delete(memberId)
    }
    roots.delete(rootId)
    return true
  }

  /** Root game state, created on first sight (bounded by the hard session cap). */
  function getRoot(id) {
    let state = roots.get(id)
    if (state !== undefined) return state
    // The tick prunes idle roots down to `maxSessions`, but long-running sessions
    // must still be bounded: at the hard cap evict the least recently active root,
    // even when it is running, so the snapshot/console cannot grow without limit.
    if (roots.size >= MAX_SESSIONS_HARD_CAP) {
      let oldest = null
      for (const candidate of roots.values()) {
        if (candidate.id === id) continue
        if (oldest === null || candidate.activeAt < oldest.activeAt) oldest = candidate
      }
      if (oldest !== null) dropRoot(oldest.id)
    }
    state = createSessionState(id, clock())
    roots.set(id, state)
    return state
  }

  /** Member record, created on first sight. */
  function getMember(id) {
    let member = members.get(id)
    if (member !== undefined) return member
    member = createMember(id)
    members.set(id, member)
    return member
  }

  /** True when any member of the root is running. */
  function anyMemberRunning(state) {
    for (const memberId of state.members) {
      const member = members.get(memberId)
      if (member !== undefined && member.running === true) return true
    }
    return false
  }

  /**
   * Fold one root game session into another. This only happens when a session's
   * parent link becomes known after its state was already created (plugin load
   * mid-stream, or a nested subagent whose parent is bound later).
   */
  function mergeRoots(fromId, toId) {
    if (fromId === toId) return
    const from = roots.get(fromId)
    if (from === undefined) return
    const to = getRoot(toId)
    for (const memberId of from.members) {
      to.members.add(memberId)
      const member = members.get(memberId)
      if (member !== undefined) member.rootId = toId
    }
    to.running = to.running === true || from.running === true
    to.openTurn = to.openTurn === true || from.openTurn === true
    to.pendingTurnEnd = to.pendingTurnEnd === true || from.pendingTurnEnd === true
    to.busy += from.busy
    to.combo += from.combo
    to.hits += from.hits
    to.scoreExact += from.scoreExact
    to.officialTurn += from.officialTurn
    to.officialSession += from.officialSession
    if (from.maxCombo > to.maxCombo) to.maxCombo = from.maxCombo
    if (from.bestCombo > to.bestCombo) to.bestCombo = from.bestCombo
    if (from.milestone > to.milestone) to.milestone = from.milestone
    if (from.level > to.level) to.level = from.level
    if (from.energy > to.energy) to.energy = from.energy
    to.chargeActive = to.chargeActive === true || from.chargeActive === true
    to.milestoneSeq += from.milestoneSeq
    to.hitSeq += from.hitSeq
    to.breakSeq += from.breakSeq
    to.settleSeq += from.settleSeq
    to.startSeq += from.startSeq
    to.completedTurns += from.completedTurns
    to.activeAt = Math.max(to.activeAt, from.activeAt)
    to.lastHitAt = Math.max(to.lastHitAt, from.lastHitAt)
    to.energyAt = Math.max(to.energyAt, from.energyAt)
    to.holdAt = Math.max(to.holdAt, from.holdAt)
    if (to.startedAt === 0 || (from.startedAt > 0 && from.startedAt < to.startedAt)) to.startedAt = from.startedAt
    if (to.phase === 'idle' && from.phase !== 'idle') to.phase = from.phase
    if (from.turn > to.turn) to.turn = from.turn
    if (to.step === 0) to.step = from.step
    roots.delete(fromId)
  }

  /**
   * Learn a session's durable lineage, then return its member record folded into
   * the conversation root. Every event calls this first, so a teammate session
   * contributes to the same combo as its parent conversation.
   */
  function bindSession(id, header) {
    if (header !== null && header !== undefined && typeof header === 'object') {
      const parentId = typeof header.parentSession === 'string' && header.parentSession.length > 0 ? header.parentSession : null
      if (parentId !== null && parentId !== id) parentOf.set(id, parentId)
      else parentOf.delete(id)
      if (header.origin === 'subagent') subagentOf.set(id, true)
      else subagentOf.delete(id)
    }
    const rootId = rootOf(id)
    const member = getMember(id)
    if (member.rootId !== null && member.rootId !== rootId) mergeRoots(member.rootId, rootId)
    member.rootId = rootId
    const state = getRoot(rootId)
    state.members.add(id)
    return { member, state }
  }

  /** Root id for a reset target (a member id is accepted too). */
  function resolveRootId(id) {
    const member = members.get(id)
    if (member !== undefined && member.rootId !== null) return member.rootId
    return rootOf(id)
  }

  /* ------------------------------------------------------------ snapshot */

  /** One root-conversation entry — the INTERFACE.md field list plus `members`. */
  const sessionView = (state) => {
    const level = levelSpec(state.level)
    let liveExact = 0
    const memberIds = []
    for (const memberId of state.members) {
      memberIds.push(memberId)
      const member = members.get(memberId)
      if (member !== undefined && member.live > 0) liveExact += member.live
    }
    const live = Math.max(0, Math.round(liveExact))
    return {
      id: state.id,
      running: state.running === true || anyMemberRunning(state),
      phase: state.phase,
      combo: state.combo,
      maxCombo: state.maxCombo,
      bestCombo: state.bestCombo,
      level: level.level,
      multiplier: level.multiplier,
      nextLevelAt: level.nextLevelAt,
      tier: level.tier,
      hits: state.hits,
      score: Math.round(state.scoreExact),
      tokens: {
        turn: Math.max(0, Math.round(state.officialTurn + liveExact)),
        live,
        output: Math.max(0, Math.round(state.officialTurn)),
        total: Math.max(0, Math.round(state.officialSession + liveExact)),
      },
      turn: state.turn,
      step: state.step,
      lastHitAt: state.lastHitAt,
      energy: Math.round(state.energy * 100) / 100,
      activeAt: state.activeAt,
      startedAt: state.startedAt,
      milestone: state.milestone,
      milestoneSeq: state.milestoneSeq,
      hitSeq: state.hitSeq,
      breakSeq: state.breakSeq,
      settleSeq: state.settleSeq,
      startSeq: state.startSeq,
      completedTurns: state.completedTurns,
      members: memberIds,
    }
  }

  /** Full snapshot handed to the Client: `{revision, engine, serverTime, sessions, totals}`. */
  const buildSnapshot = () => {
    const entries = []
    let outputTokens = 0
    let hits = 0
    let bestCombo = 0
    for (const state of roots.values()) {
      entries.push(sessionView(state))
      outputTokens += Math.max(0, Math.round(state.officialSession))
      hits += state.hits
      if (state.bestCombo > bestCombo) bestCombo = state.bestCombo
    }
    entries.sort((left, right) => {
      if (right.activeAt !== left.activeAt) return right.activeAt - left.activeAt
      return left.id < right.id ? -1 : left.id > right.id ? 1 : 0
    })
    return {
      revision,
      engine: 11,
      serverTime: clock(),
      sessions: entries,
      totals: { outputTokens, hits, bestCombo, sessions: entries.length },
      // Desktop HUD state for the in-window client (reconcile close / click-through).
      hud: { open: hudOpen(), interactive: hudInteractive },
    }
  }

  /** Current snapshot plus the revision the client must poll from. */
  const current = () => ({ revision, snapshot: buildSnapshot() })

  /* ------------------------------------------------------------- publish */

  /** Resolve every parked long-poll with the freshly published snapshot. */
  const publishNow = () => {
    if (publishTimer !== null) {
      clearTimeout(publishTimer)
      publishTimer = null
    }
    lastPublishAt = clock()
    revision += 1
    if (waiters.size === 0) return
    let snapshot = null
    let value = null
    try {
      snapshot = buildSnapshot()
      value = { revision, snapshot }
    } catch (error) {
      log('warn', `snapshot build failed: ${String(error)}`)
    }
    for (const waiter of [...waiters]) {
      waiters.delete(waiter)
      try {
        waiter.resolve(value)
      } catch {
        /* waiter already settled */
      }
    }
  }

  /**
   * Mark the state dirty. Publishing is coalesced to at most one revision per
   * `publishIntervalMs` so a token storm cannot become an RPC request storm.
   */
  const requestPublish = () => {
    if (disposed) return
    const time = clock()
    // Clamp against a wall-clock rollback: a negative elapsed value would turn
    // the coalescing delay into "rollback amount" and stall publishing.
    const elapsed = Number.isFinite(lastPublishAt) ? Math.max(0, time - lastPublishAt) : Infinity
    if (publishTimer !== null) {
      // A coalescing window is open. Publish now only when the injected clock
      // has already moved past the window (tests / suspended hosts), otherwise
      // let the scheduled flush do it.
      if (!Number.isFinite(lastPublishAt) || elapsed >= cfg.publishIntervalMs) publishNow()
      return
    }
    if (!Number.isFinite(lastPublishAt) || elapsed >= cfg.publishIntervalMs) {
      publishNow()
      return
    }
    const wait = Math.min(cfg.publishIntervalMs, Math.max(1, cfg.publishIntervalMs - elapsed))
    try {
      publishTimer = setTimeout(() => {
        publishTimer = null
        try {
          publishNow()
        } catch (error) {
          log('warn', `coalesced publish failed: ${String(error)}`)
        }
      }, wait)
      if (publishTimer !== null && typeof publishTimer.unref === 'function') publishTimer.unref()
    } catch {
      publishTimer = null
    }
  }

  /* -------------------------------------------------------- long polling */

  /** Park one `poll` call until the next revision, the timeout, or client abort. */
  const waitForNextRevision = (timeoutMs, signal) =>
    new Promise((resolve) => {
      let settled = false
      let timer = null
      const waiter = {
        resolve: (value) => finish(value),
      }
      const finish = (value) => {
        if (settled) return
        settled = true
        waiters.delete(waiter)
        if (timer !== null) {
          clearTimeout(timer)
          timer = null
        }
        if (signal !== null && signal !== undefined && typeof signal.removeEventListener === 'function') {
          try {
            signal.removeEventListener('abort', onAbort)
          } catch {
            /* signal already gone */
          }
        }
        resolve(value !== null && value !== undefined ? value : current())
      }
      const onAbort = () => finish(current())

      if (waiters.size >= MAX_WAITERS) {
        resolve(current())
        return
      }
      waiters.add(waiter)
      try {
        // Deliberately never unref'd: a parked poll is pending work whose answer
        // must be delivered even when the Host is otherwise idle.
        timer = setTimeout(() => finish(current()), timeoutMs)
      } catch {
        timer = null
      }
      if (signal !== null && signal !== undefined) {
        try {
          if (signal.aborted === true) {
            finish(current())
            return
          }
          if (typeof signal.addEventListener === 'function') signal.addEventListener('abort', onAbort, { once: true })
        } catch {
          /* an unusable signal just means no abort wakeup */
        }
      }
    })

  /* ------------------------------------------------------- state folding */

  /** Count official (provider-reported) output tokens with a max reconcile per member step. */
  const commitOfficial = (state, member, turn, step, tokens) => {
    const amount = toNumber(tokens, 0)
    if (!(amount > 0)) return
    const key = `${toInteger(turn, 0)}:${toInteger(step, 0)}`
    const previous = member.officialKeys.get(key)
    const applied = typeof previous === 'number' ? previous : 0
    if (amount <= applied) return
    member.officialKeys.set(key, amount)
    if (member.officialKeys.size > MAX_OFFICIAL_KEYS) {
      const oldest = member.officialKeys.keys().next()
      if (oldest.done !== true) member.officialKeys.delete(oldest.value)
    }
    state.officialTurn += amount - applied
    state.officialSession += amount - applied
  }

  /** Drop reconcile keys from earlier turns; they can never be applied again. */
  const pruneOfficialKeys = (member, turn) => {
    const prefix = `${toInteger(turn, 0)}:`
    for (const key of member.officialKeys.keys()) {
      if (!key.startsWith(prefix)) member.officialKeys.delete(key)
    }
  }

  /** Bank the current combo and open its display window. */
  const settleState = (state, time) => {
    state.phase = 'settled'
    state.settleSeq += 1
    state.pendingTurnEnd = false
    if (state.combo > state.maxCombo) state.maxCombo = state.combo
    if (state.combo > state.bestCombo) state.bestCombo = state.combo
    state.holdAt = time
  }

  /** Clear the meter display without touching the monotonic counters. */
  const resetToIdle = (state) => {
    state.phase = 'idle'
    state.holdAt = 0
    state.energy = 0
    state.level = 1
    state.chargeActive = false
    state.combo = 0
    state.pendingTurnEnd = false
  }

  /** Start a fresh combo for a new root turn (child turns never call this). */
  const beginRootTurn = (state, turn, time) => {
    state.combo = 0
    state.hits = 0
    state.scoreExact = 0
    state.level = 1
    state.energy = 0
    state.chargeActive = false
    state.officialTurn = 0
    state.openTurn = true
    state.pendingTurnEnd = false
    state.turn = toInteger(turn, state.turn)
    state.step = 0
    state.energyAt = time
    state.activeAt = time
    for (const memberId of state.members) {
      const member = members.get(memberId)
      if (member !== undefined) member.live = 0
    }
    if (state.startedAt === 0) state.startedAt = time
  }

  /** Close the root turn: settle once nothing is streaming any more. */
  const finishRootTurn = (state, time) => {
    state.openTurn = false
    if (state.busy > 0) {
      state.pendingTurnEnd = true
      return
    }
    state.pendingTurnEnd = false
    if (state.phase === 'broken') return
    if (state.phase === 'settled' || state.phase === 'holding') {
      state.phase = 'settled'
      state.holdAt = time
      return
    }
    if (state.combo > 0) settleState(state, time)
    else resetToIdle(state)
  }

  /** One visible delta = one combo hit for the whole conversation tree. */
  const countHit = (state, member, text, time) => {
    const estimate = estimateDelta(text)
    if (estimate <= 0) return
    state.combo += 1
    state.hits += 1
    state.hitSeq += 1
    const spec = levelSpec(state.level)
    state.scoreExact += estimate * spec.multiplier
    member.live += estimate
    member.building = true
    if (state.combo > state.maxCombo) state.maxCombo = state.combo
    const crossed = crossedMilestone(state.combo - 1, state.combo)
    if (crossed > 0) {
      state.milestone = crossed
      state.milestoneSeq += 1
    }
    state.lastHitAt = time
    // Charge the current multiplier stage; a full bar advances to the next stage.
    if (state.level < LEVELS.length) {
      state.energy = Math.min(1, state.energy + 1 / spec.hitsToNext)
      state.energyAt = time
      state.chargeActive = true
      if (state.energy >= 1 - 1e-6) {
        state.level += 1
        state.energy = 0
        state.chargeActive = false
      }
    } else {
      state.energy = 1
      state.energyAt = time
      state.chargeActive = true
    }
    state.activeAt = time
    if (state.startedAt === 0) state.startedAt = time
    state.running = true
    state.openTurn = true
    state.phase = 'building'
    state.holdAt = 0
    requestPublish()
  }

  /** `start` frame: one member opens a new model attempt inside the shared turn. */
  const onStreamStart = (member, state, frame, time) => {
    // Defensive: a repeated start without an end settles the previous attempt's
    // usage instead of double-counting the busy counter.
    if (member.activeAttempt === true && member.attempt !== null) {
      commitOfficial(state, member, member.attempt.turn, member.attempt.step, member.attempt.official)
    } else {
      state.busy += 1
    }
    member.attempt = {
      id: typeof frame.attemptId === 'string' ? frame.attemptId : '',
      turn: toInteger(frame.turn, member.turn),
      step: toInteger(frame.step, 0),
      official: 0,
    }
    member.activeAttempt = true
    member.building = true
    member.live = 0
    member.pendingOfficial = 0
    member.running = true
    if (member.id === state.id) {
      const nextTurn = toInteger(frame.turn, state.turn)
      if (nextTurn !== state.turn) beginRootTurn(state, nextTurn, time)
      else {
        state.turn = nextTurn
        state.step = toInteger(frame.step, state.step)
      }
    } else if (state.turn === 0) {
      state.turn = toInteger(frame.turn, state.turn)
    }
    state.openTurn = true
    state.running = true
    state.lastHitAt = time
    state.energyAt = time
    state.activeAt = time
    if (state.startedAt === 0) state.startedAt = time
    state.startSeq += 1
    state.phase = 'building'
    state.holdAt = 0
    requestPublish()
  }

  /** `chunk` frame: deltas count hits, `usage` reports official output tokens. */
  const onStreamChunk = (member, state, chunk, time) => {
    switch (chunk.type) {
      case 'text-delta':
      case 'reasoning-delta':
        countHit(state, member, chunk.text, time)
        return
      case 'tool-call-delta':
        countHit(state, member, chunk.argumentsDelta, time)
        return
      case 'usage': {
        const usage = chunk.usage
        if (usage === null || usage === undefined || typeof usage !== 'object') return
        const output = toNumber(usage.outputTokens, 0)
        if (!(output > 0)) return
        if (member.attempt !== null) {
          if (output > member.attempt.official) member.attempt.official = output
        } else if (output > member.pendingOfficial) {
          // Plugin loaded mid-stream: hold the value until a turn/step is known.
          member.pendingOfficial = output
        }
        state.activeAt = time
        requestPublish()
        return
      }
      default:
        return
    }
  }

  /** `end` frame: bank the attempt (committed) or drop its live estimate. */
  const onStreamEnd = (member, state, frame, time) => {
    const outcome = frame.outcome !== null && frame.outcome !== undefined && typeof frame.outcome === 'object' ? frame.outcome : {}
    const kind = typeof outcome.kind === 'string' ? outcome.kind : 'abandoned'
    const attempt = member.attempt
    member.attempt = null
    member.building = false
    member.live = 0
    if (member.activeAttempt === true) {
      member.activeAttempt = false
      state.busy = Math.max(0, state.busy - 1)
    }
    if (attempt !== null) commitOfficial(state, member, attempt.turn, attempt.step, attempt.official)
    if (member.pendingOfficial > 0) {
      const pendingKey = `pending:${typeof frame.attemptId === 'string' ? frame.attemptId : member.id}`
      if (!member.officialKeys.has(pendingKey)) {
        member.officialKeys.set(pendingKey, member.pendingOfficial)
        state.officialTurn += member.pendingOfficial
        state.officialSession += member.pendingOfficial
      }
      member.pendingOfficial = 0
    }
    state.activeAt = time
    if (kind === 'committed') {
      if (state.busy > 0) {
        if (state.phase !== 'broken') state.phase = 'holding'
      } else if (state.openTurn) {
        settleState(state, time)
      } else if (state.phase === 'broken') {
        /* Keep the break display until its own window expires. */
      } else if (state.combo > 0) {
        settleState(state, time)
      } else {
        resetToIdle(state)
      }
    } else if (state.busy === 0) {
      // Retry/abandon inside an open turn: keep the combo meter running.
      if (state.openTurn) {
        state.phase = 'holding'
        state.holdAt = 0
      } else if (state.phase !== 'broken') {
        resetToIdle(state)
      }
    }
    requestPublish()
  }

  const onAssistantStream = (payload) => {
    try {
      if (payload === null || payload === undefined || typeof payload !== 'object') return
      const info = sessionInfoFromAgent(payload.agent)
      const frame = payload.frame
      if (info === null || frame === null || frame === undefined || typeof frame !== 'object') return
      const time = clock()
      const { member, state } = bindSession(info.id, info.header)
      if (frame.type === 'start') onStreamStart(member, state, frame, time)
      else if (frame.type === 'chunk') {
        const chunk = frame.chunk
        if (chunk !== null && chunk !== undefined && typeof chunk === 'object') onStreamChunk(member, state, chunk, time)
      } else if (frame.type === 'end') onStreamEnd(member, state, frame, time)
    } catch (error) {
      log('warn', `assistant stream fold failed: ${String(error)}`)
    }
  }

  const onSessionEvent = (session, event) => {
    try {
      const info = sessionInfoFromSession(session)
      if (info === null || event === null || event === undefined || typeof event !== 'object') return
      const data = event.data !== null && event.data !== undefined && typeof event.data === 'object' ? event.data : null
      const time = clock()
      const { member, state } = bindSession(info.id, info.header)
      state.activeAt = time
      switch (event.type) {
        case 'turn/start': {
          const turn = toInteger(data === null ? undefined : data.turn, state.turn + 1)
          member.running = true
          member.turn = turn
          member.step = 0
          member.live = 0
          member.pendingOfficial = 0
          pruneOfficialKeys(member, turn)
          state.running = true
          if (state.startedAt === 0) state.startedAt = time
          if (member.id === state.id) {
            // Only the conversation root starts a fresh combo; teammate/subagent
            // turns are steps inside the same run and keep the shared combo.
            beginRootTurn(state, turn, time)
          } else {
            state.openTurn = true
            if (state.phase === 'idle') state.phase = 'building'
            else if (state.phase === 'settled') state.phase = 'holding'
          }
          requestPublish()
          return
        }
        case 'turn/end': {
          member.running = false
          state.activeAt = time
          state.running = anyMemberRunning(state)
          if (member.id === state.id) {
            state.completedTurns += 1
            finishRootTurn(state, time)
          } else if (state.openTurn !== true && state.busy === 0 && state.phase === 'building') {
            // The last child turn closed after the root turn already ended.
            if (state.combo > 0) settleState(state, time)
            else resetToIdle(state)
          }
          requestPublish()
          return
        }
        case 'assistant/message': {
          const usage = data !== null && data.usage !== null && data.usage !== undefined && typeof data.usage === 'object' ? data.usage : null
          const output = usage === null ? 0 : toNumber(usage.outputTokens, 0)
          if (data !== null && data.turn !== undefined) {
            member.turn = toInteger(data.turn, member.turn)
            if (member.id === state.id) state.turn = member.turn
          }
          if (data !== null && data.step !== undefined) {
            member.step = toInteger(data.step, member.step)
            if (member.id === state.id) state.step = member.step
          }
          if (output > 0) {
            commitOfficial(state, member, member.turn, member.step, output)
            // The durable message is authoritative for this step: a usage chunk
            // seen without an attempt frame must not be banked twice.
            member.pendingOfficial = 0
          }
          state.activeAt = time
          requestPublish()
          return
        }
        default:
          return
      }
    } catch (error) {
      log('warn', `session event fold failed: ${String(error)}`)
    }
  }

  const onAgentStatus = (payload) => {
    try {
      if (payload === null || payload === undefined || typeof payload !== 'object') return
      const info = sessionInfoFromAgent(payload.agent)
      if (info === null) return
      const time = clock()
      const { member, state } = bindSession(info.id, info.header)
      const running = payload.status === 'running'
      member.running = running
      state.running = running || anyMemberRunning(state)
      state.activeAt = time
      if (running) {
        if (state.startedAt === 0) state.startedAt = time
      } else if (state.openTurn !== true && state.busy === 0 && state.phase === 'building') {
        resetToIdle(state)
      }
      requestPublish()
    } catch (error) {
      log('warn', `agent status fold failed: ${String(error)}`)
    }
  }

  const onAgentDisposed = (payload) => {
    try {
      if (payload === null || payload === undefined || typeof payload !== 'object') return
      const info = sessionInfoFromAgent(payload.agent)
      if (info === null) return
      const member = members.get(info.id)
      if (member === undefined) return
      const time = clock()
      if (member.activeAttempt === true && member.rootId !== null) {
        const rootState = roots.get(member.rootId)
        if (rootState !== undefined) rootState.busy = Math.max(0, rootState.busy - 1)
      }
      const rootId = member.rootId
      members.delete(info.id)
      parentOf.delete(info.id)
      subagentOf.delete(info.id)
      if (rootId === null) return
      const state = roots.get(rootId)
      if (state === undefined) return
      state.members.delete(info.id)
      state.running = anyMemberRunning(state)
      state.activeAt = time
      if (state.members.size === 0) roots.delete(rootId)
      requestPublish()
    } catch (error) {
      log('warn', `agent disposal fold failed: ${String(error)}`)
    }
  }

  /* ---------------------------------------------------------------- tick */

  /** Phase windows, break detection, and idle-memory pruning (one pass per root). */
  const tick = () => {
    try {
      if (disposed) return
      const time = clock()
      let changed = false
      const forgotten = []
      for (const state of roots.values()) {
        if ((state.phase === 'settled' || state.phase === 'broken') && state.holdAt > 0) {
          const hold = state.phase === 'settled' ? cfg.settleHoldMs : cfg.breakHoldMs
          if (time - state.holdAt >= hold) {
            if (state.phase === 'settled' && (state.openTurn === true || state.busy > 0)) {
              // The turn is still running (for example a Tool call between steps):
              // keep the banked combo alive until the turn really ends.
              state.phase = 'holding'
              state.holdAt = 0
            } else {
              resetToIdle(state)
            }
            changed = true
          }
        }
        // The stage meter drains while no token arrives; reaching zero breaks the combo.
        if (
          (state.openTurn === true || state.busy > 0) &&
          state.combo > 0 &&
          state.chargeActive === true &&
          (state.phase === 'building' || state.phase === 'holding' || state.phase === 'settled') &&
          state.energy > 0
        ) {
          const last = state.energyAt > 0 ? state.energyAt : state.lastHitAt
          if (last > 0) {
            const elapsed = Math.max(0, time - last)
            if (elapsed > 0) {
              state.energy = Math.max(0, state.energy - elapsed / cfg.breakMs)
              state.energyAt = time
            }
          }
          if (state.energy <= 0) {
            if (state.level > 1) {
              // Empty mid-stage: drop one multiplier step and restart that
              // stage's meter full, so it drains again on the way down.
              state.level -= 1
              state.energy = 1
              state.chargeActive = true
              state.activeAt = time
              changed = true
            } else {
              state.phase = 'broken'
              state.combo = 0
              state.level = 1
              state.energy = 0
              state.chargeActive = false
              state.breakSeq += 1
              state.holdAt = time
              state.activeAt = time
              changed = true
            }
          } else {
            changed = true
          }
        }
        if (state.running !== true && state.busy === 0 && state.phase === 'idle' && state.activeAt > 0 && time - state.activeAt >= cfg.idleMemoryMs) {
          forgotten.push(state.id)
        }
      }
      for (const id of forgotten) {
        if (dropRoot(id)) changed = true
      }
      if (roots.size > cfg.maxSessions) {
        const ordered = [...roots.values()].sort((left, right) => left.activeAt - right.activeAt)
        for (const state of ordered) {
          if (roots.size <= cfg.maxSessions) break
          if (state.running === true) continue
          if (dropRoot(state.id)) changed = true
        }
      }
      if (changed) requestPublish()
    } catch (error) {
      log('warn', `tick failed: ${String(error)}`)
    }
  }

  /* --------------------------------------------------------------- reset */

  /** Zero the game counters of one conversation tree (or every root when omitted). */
  const resetCounters = (sessionId) => {
    const time = clock()
    const targets = sessionId === null ? [...roots.keys()] : [resolveRootId(sessionId)]
    for (const id of targets) {
      const state = roots.get(id)
      if (state === undefined) continue
      state.combo = 0
      state.level = 1
      state.maxCombo = 0
      state.bestCombo = 0
      state.hits = 0
      state.scoreExact = 0
      state.officialTurn = 0
      state.officialSession = 0
      state.milestone = 0
      state.completedTurns = 0
      state.phase = 'idle'
      state.holdAt = 0
      state.lastHitAt = 0
      state.energy = 0
      state.energyAt = 0
      state.chargeActive = false
      state.openTurn = false
      state.pendingTurnEnd = false
      state.busy = 0
      state.activeAt = time
      for (const memberId of state.members) {
        const member = members.get(memberId)
        if (member === undefined) continue
        member.attempt = null
        member.activeAttempt = false
        member.building = false
        member.live = 0
        member.pendingOfficial = 0
        member.officialKeys.clear()
      }
    }
    // A reset is an explicit user action: publish immediately so the Client
    // sees the zeroed state without waiting for the coalescing window.
    publishNow()
  }

  /* --------------------------------------------------------- RPC carrier */

  /**
   * The Client half calls this plugin through the generic connection RPC
   * carrier (`ctx.connection.rpc.call('/token-combo', endpoint, payload)`).
   * That carrier POSTs the standard client-request envelope and parses a
   * server-response envelope, so the plugin owns the exact same wire format on
   * its own web route. Registering the route directly keeps this bundle
   * independent of the connection service's inject scope.
   */
  const jsonResponse = (res, status, body) => {
    try {
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store',
      })
      res.end(JSON.stringify(body))
    } catch {
      /* the client went away */
    }
  }

  /** Read one bounded JSON request body. */
  const readJsonBody = (req) =>
    new Promise((resolve) => {
      const chunks = []
      let size = 0
      let settled = false
      const finish = (value) => {
        if (settled) return
        settled = true
        resolve(value)
      }
      try {
        req.on('data', (chunk) => {
          size += chunk.length
          if (size <= 1_000_000) chunks.push(chunk)
        })
        req.on('end', () => {
          try {
            finish(chunks.length === 0 ? null : JSON.parse(Buffer.concat(chunks).toString('utf8')))
          } catch {
            finish(null)
          }
        })
        req.on('error', () => finish(null))
        req.on('aborted', () => finish(null))
        req.on('close', () => finish(null))
      } catch {
        finish(null)
      }
    })

  const clampPollTimeout = (value) => {
    const fallback = Math.min(cfg.pollMaxMs, cfg.pollDefaultMs)
    if (value === undefined || value === null) return fallback
    const timeout = toNumber(value, fallback)
    if (timeout < 0) return 0
    return Math.min(cfg.pollMaxMs, timeout)
  }

  /** Route one decoded RPC call to its endpoint and always resolve an envelope. */
  const invoke = async (endpoint, payload, signal) => {
    try {
      const request = payload !== null && payload !== undefined && typeof payload === 'object' && !Array.isArray(payload) ? payload : {}
      if (endpoint === 'hello') return { ok: true, value: current() }
      if (endpoint === 'poll') {
        const since = toInteger(request.since, 0)
        const timeoutMs = clampPollTimeout(request.timeoutMs)
        // A stale cursor larger than the current revision (Host restart) must
        // answer immediately instead of parking for the full timeout.
        if (disposed || revision > since || since > revision || timeoutMs <= 0) return { ok: true, value: current() }
        return { ok: true, value: await waitForNextRevision(timeoutMs, signal) }
      }
      if (endpoint === 'reset') {
        if (typeof request.sessionId === 'string' && request.sessionId.length === 0) {
          return { ok: true, value: current() }
        }
        const target = typeof request.sessionId === 'string' ? request.sessionId : null
        resetCounters(target)
        return { ok: true, value: current() }
      }
      if (endpoint === 'hud') {
        const action = typeof request.action === 'string' ? request.action : 'status'
        if (request.prefs !== undefined) hudPrefs = sanitizeHudPrefs(request.prefs)
        let interactiveChanged = false
        if (typeof request.interactive === 'boolean' && request.interactive !== hudInteractive) {
          hudInteractive = request.interactive
          interactiveChanged = true
        }
        if (action === 'open') {
          const opened = await openHud()
          requestPublish()
          return opened
        }
        if (action === 'close') {
          closeHud()
          return { ok: true, value: { open: false, interactive: hudInteractive, prefs: hudPrefs, webview2: isWebView2Available() } }
        }
        if (action === 'interactive') {
          hudInteractive = request.interactive !== false
          requestPublish()
          return { ok: true, value: { open: hudOpen(), interactive: hudInteractive, prefs: hudPrefs, webview2: isWebView2Available() } }
        }
        if (interactiveChanged) requestPublish()
        return { ok: true, value: { open: hudOpen(), interactive: hudInteractive, prefs: hudPrefs, webview2: isWebView2Available() } }
      }
      return { ok: false, error: { code: 'token-combo/unknown-endpoint', message: `unknown endpoint ${JSON.stringify(endpoint)}`, details: {} } }
    } catch (error) {
      log('warn', `token combo handler failed: ${String(error)}`)
      return { ok: false, error: { code: 'token-combo/handler-failure', message: 'token combo handler failed', details: {} } }
    }
  }

  /** Prefix route serving the connection RPC envelope over plain HTTP. */
  const rpcRoute = async (req, res) => {
    try {
      const url = new URL(typeof req.url === 'string' ? req.url : '/', 'http://token-combo.local')
      if (req.method === 'GET' && url.pathname.startsWith(`${CHANNEL}/`)) {
        const staticKey = url.pathname.slice(CHANNEL.length)
        const staticEntry = HUD_STATIC[staticKey]
        if (staticEntry !== undefined) {
          const data = await readFile(new URL(staticEntry[0], import.meta.url))
          res.writeHead(200, {
            'content-type': staticEntry[1],
            'cache-control': 'no-store',
            'content-length': String(data.length),
          })
          res.end(data)
          return
        }
      }
      if (req.method === 'GET' && url.pathname.startsWith(`${CHANNEL}/art/`)) {
        const name = url.pathname.slice(`${CHANNEL}/art/`.length)
        const match = /^([a-z]+)\.(webp|png)$/.exec(name)
        if (match === null || !ART_IDS.has(match[1])) {
          jsonResponse(res, 404, { error: 'unknown character art' })
          return
        }
        const id = match[1]
        const ext = match[2]
        const key = `${id}.${ext}`
        let data = artCache.get(key)
        if (data === undefined) {
          data = await readFile(new URL(`../art/${key}`, import.meta.url))
          artCache.set(key, data)
        }
        res.writeHead(200, {
          'content-type': ext === 'png' ? 'image/png' : 'image/webp',
          'cache-control': 'public, max-age=86400',
          'content-length': String(data.length),
        })
        res.end(data)
        return
      }
      if (req.method === 'GET' && url.pathname === `${CHANNEL}/hud/state`) {
        const token = String(req.headers['x-token-combo-token'] ?? '')
        if (token !== hudToken) {
          jsonResponse(res, 403, { error: 'forbidden' })
          return
        }
        jsonResponse(res, 200, {
          ...current(),
          hud: {
            interactive: hudInteractive,
            prefs: hudPrefs,
            open: hudOpen(),
            ready: hudReady === true,
          },
        })
        return
      }
      if (req.method === 'GET' && url.pathname === `${CHANNEL}/hud/sync`) {
        const token = String(req.headers['x-token-combo-token'] ?? '')
        if (token !== hudToken) {
          jsonResponse(res, 403, { error: 'forbidden' })
          return
        }
        let changed = false
        const rawInteractive = url.searchParams.get('interactive')
        if (rawInteractive !== null) {
          const nextInteractive = rawInteractive === '1' || rawInteractive === 'true'
          if (nextInteractive !== hudInteractive) {
            hudInteractive = nextInteractive
            changed = true
          }
        }
        if (url.searchParams.get('ready') === '1' && hudProcess !== null && hudReady !== true) {
          settleHudReady(true)
          changed = true
        }
        if (changed) requestPublish()
        jsonResponse(res, 200, { ok: true, interactive: hudInteractive, open: hudOpen() })
        return
      }
      if (req.method !== 'POST') {
        jsonResponse(res, 405, { error: 'POST only' })
        return
      }
      if (!url.pathname.startsWith(`${CHANNEL}/`)) {
        jsonResponse(res, 404, { error: 'not found' })
        return
      }
      const endpoint = url.pathname.slice(CHANNEL.length + 1)
      const contentType = String(req.headers['content-type'] ?? '')
        .split(';', 1)[0]
        .trim()
        .toLowerCase()
      if (contentType !== 'application/json') {
        jsonResponse(res, 415, { error: 'content type must be application/json' })
        return
      }
      const envelope = await readJsonBody(req)
      const rpcId = envelope !== null && typeof envelope === 'object' && typeof envelope.rpcId === 'string' ? envelope.rpcId : 'invalid'
      const method = envelope !== null && typeof envelope === 'object' ? envelope.method : undefined
      if (method !== endpoint) {
        jsonResponse(res, 200, {
          type: 'server-response',
          rpcId,
          result: { ok: false, error: { code: 'gateway/bad-request', message: 'method does not match endpoint', details: {} } },
        })
        return
      }
      const controller = new AbortController()
      const abort = () => {
        try {
          controller.abort()
        } catch {
          /* ignore */
        }
      }
      // Abort the parked long-poll when the client disconnects.
      try {
        res.on('close', abort)
      } catch {
        /* ignore */
      }
      const result = await invoke(endpoint, envelope.payload, controller.signal)
      jsonResponse(res, 200, { type: 'server-response', rpcId, result })
    } catch (error) {
      log('warn', `rpc bridge failed: ${String(error)}`)
      jsonResponse(res, 500, { error: 'bridge failure' })
    }
  }

  /* ----------------------------------------------------------- lifecycle */

  /** Register one global event listener, contained against plugin-level throws. */
  const listen = (name, fold, label) => {
    ctx.effect(() => {
      if (typeof ctx.on !== 'function') return () => {}
      const dispose = ctx.on(
        name,
        (...args) => {
          try {
            fold(...args)
          } catch (error) {
            log('warn', `${name} listener failed: ${String(error)}`)
          }
        },
        { global: true },
      )
      return typeof dispose === 'function' ? dispose : () => {}
    }, `token-combo: ${label}`)
  }

  listen('agent/assistant-stream', onAssistantStream, 'assistant stream')
  listen('session/event', onSessionEvent, 'session events')
  listen('agent/status', onAgentStatus, 'agent status')
  listen('agent/disposed', onAgentDisposed, 'agent disposal')

  /**
   * Drive phase windows. `ctx.interval` comes from the timer plugin; a Host
   * profile without it still gets the tick through a plain interval, because a
   * silent tick would disable break/hold/idle-memory behavior entirely.
   */
  ctx.effect(() => {
    if (typeof ctx.interval === 'function') {
      try {
        const dispose = ctx.interval(() => {
          tick()
        }, cfg.tickMs)
        return typeof dispose === 'function' ? dispose : () => {}
      } catch (error) {
        log('warn', `ctx.interval failed, falling back: ${String(error)}`)
      }
    }
    let timer = null
    try {
      timer = setInterval(() => {
        tick()
      }, cfg.tickMs)
    } catch {
      timer = null
    }
    return () => {
      if (timer !== null) {
        clearInterval(timer)
        timer = null
      }
    }
  }, 'token-combo: phase tick')

  ctx.effect(
    () =>
      ctx.webServer.register(
        { kind: 'prefix', path: CHANNEL, handler: rpcRoute },
        'token-combo: rpc route',
      ),
    'token-combo: rpc route',
  )

  ctx.effect(
    () => () => {
      disposed = true
      closeHud()
      if (publishTimer !== null) {
        clearTimeout(publishTimer)
        publishTimer = null
      }
      for (const waiter of [...waiters]) {
        waiters.delete(waiter)
        try {
          waiter.resolve(null)
        } catch {
          /* waiter already settled */
        }
      }
      roots.clear()
      members.clear()
      parentOf.clear()
      subagentOf.clear()
    },
    'token-combo: dispose',
  )

  log('info', `ready (channel ${CHANNEL})`)
}


