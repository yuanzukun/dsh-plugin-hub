/**
 * Structural + behavioural test for token-combo/src/fx.js
 * Character-preset edition: every AI mascot must render safely and expose
 * its palette, judge lines and portrait card.
 *
 * Run: node src/fx-test.mjs
 */
import fs from 'node:fs';
import vm from 'node:vm';

let passed = 0;
const failures = [];
function check(name, cond, detail) {
  if (cond) { passed++; return true; }
  failures.push(name + (detail ? ' — ' + detail : ''));
  return false;
}
function section(title) { console.log('\n== ' + title + ' =='); }

function createElement(type, props) {
  const p = {};
  if (props) for (const key of Object.keys(props)) p[key] = props[key];
  const children = [];
  for (let i = 2; i < arguments.length; i++) children.push(arguments[i]);
  if (children.length === 1) p.children = children[0];
  else if (children.length > 1) p.children = children;
  return { type, props: p, key: p.key };
}
const React = {
  createElement,
  Fragment: Symbol.for('dsftc.fragment'),
  useState: (init) => [typeof init === 'function' ? init() : init, () => {}],
  useEffect: () => {}, useLayoutEffect: () => {},
  useRef: (init) => ({ current: init }),
  useMemo: (fn) => fn(), useCallback: (fn) => fn,
  createRef: () => ({ current: null })
};

function walk(node, visit) {
  if (node === null || node === undefined) return;
  if (Array.isArray(node)) { for (const child of node) walk(child, visit); return; }
  if (typeof node !== 'object') return;
  visit(node);
  if (node.props) walk(node.props.children, visit);
}
function findAll(tree, pred) {
  const out = [];
  walk(tree, (node) => { if (typeof node.type === 'string' && pred(node)) out.push(node); });
  return out;
}
function collectText(tree) {
  const out = [];
  (function visit(node) {
    if (node === null || node === undefined) return;
    if (typeof node === 'string' || typeof node === 'number') { out.push(String(node)); return; }
    if (Array.isArray(node)) { for (const child of node) visit(child); return; }
    if (typeof node === 'object' && node.props) visit(node.props.children);
  })(tree);
  return out.join(' ');
}
function classHits(tree, token) {
  return findAll(tree, (node) => String(node.props.className || '').split(/\s+/).includes(token));
}
function cssProblems(css, id) {
  const clean = String(css).replace(/\/\*[\s\S]*?\*\//g, '');
  const problems = [];
  if (!clean.includes('.dsftc-arena-' + id)) problems.push('missing arena scope');
  if (/@import/.test(clean)) problems.push('@import');
  if (/url\s*\(/.test(clean)) problems.push('url()');
  if (/https?:/.test(clean)) problems.push('network url');
  if (/\$\{/.test(clean)) problems.push('template leftover');
  return problems;
}

const fileUrl = new URL('./fx.js', import.meta.url);
const src = fs.readFileSync(fileUrl, 'utf8');
const sandbox = { console };
vm.createContext(sandbox);
let loadError = '';
try { vm.runInContext(src, sandbox, { filename: 'fx.js' }); }
catch (error) { loadError = error && error.message ? error.message : String(error); }
check('vm loads fx.js', !loadError, loadError);
check('global.createComboFx exists', typeof sandbox.createComboFx === 'function');
const fx = typeof sandbox.createComboFx === 'function' ? sandbox.createComboFx(React) : null;
check('PRESETS array present', !!fx && Array.isArray(fx.PRESETS));
if (!fx || !Array.isArray(fx.PRESETS)) {
  console.log('passed: ' + passed + ', failed: ' + failures.length);
  for (const failure of failures) console.log('  - ' + failure);
  process.exit(1);
}

section('source shape');
check('no ESM import/export', !/(^|\n)\s*(import|export)[\s({]/.test(src));
check('assigns global.createComboFx', /global\.createComboFx\s*=\s*createComboFx/.test(src));
check('no document access', !/\bdocument\b/.test(src));
check('no network APIs', !/\b(fetch|XMLHttpRequest|WebSocket|importScripts)\b/.test(src));
check('no localStorage', !/localStorage|sessionStorage/.test(src));
check('no eval', !/\beval\s*\(/.test(src));

section('legacy cleanup');
check('no legacy preset CSS constants', !/RHYTHM_CSS|FIGHTING_CSS|ARCADE_CSS|CYBER_CSS/.test(src));
check('no legacy preset ids in fx.js', !/\b(rhythm|fighting|arcade|cyber)\b/i.test(src));
check('no unused readFx.pct field', !/\bpct\b/.test(src));
check('no dead SPECS.title', !/title:\s*character\.motto/.test(src));

const CHARACTER_IDS = ['deepseek', 'chatgpt', 'claude', 'gemini', 'glm', 'grok', 'qwen'];
section('character presets');
check('exactly 7 presets', fx.PRESETS.length === 7, 'got ' + fx.PRESETS.length);
check('character ids/order', JSON.stringify(fx.PRESETS.map((p) => p.id)) === JSON.stringify(CHARACTER_IDS), JSON.stringify(fx.PRESETS.map((p) => p.id)));
check('legacy ids removed', ['rhythm', 'fighting', 'arcade', 'cyber'].every((id) => fx.PRESETS.every((p) => p.id !== id)));

const byId = {};
for (const preset of fx.PRESETS) {
  byId[preset.id] = preset;
  const id = preset.id;
  check(id + ': bilingual label', !!preset.label && preset.label.zh && preset.label.en);
  check(id + ': bilingual hint', !!preset.hint && preset.hint.zh && preset.hint.en);
  check(id + ': six-digit palette', ['accent', 'accent2', 'accent3', 'ink'].every((key) => /^#[0-9A-Fa-f]{6}$/.test(String(preset[key]))));
  check(id + ': css scoped', typeof preset.css === 'string' && preset.css.length > 800);
  check(id + ': css audit', cssProblems(preset.css, id).length === 0, cssProblems(preset.css, id).join(','));
  check(id + ': styleById matches', fx.styleById(id) === preset.css);
  check(id + ': styleById unknown empty', fx.styleById('nope-' + id) === '');
  check(id + ': factories', ['Arena', 'Badge', 'Preview', 'Icon'].every((key) => typeof preset[key] === 'function'));
  check(id + ': has avatar + art css', preset.css.includes('.dsftc-avatar') && preset.css.includes('.dsftc-art'));
  check(id + ': has character arena rule', preset.css.includes('.dsftc-arena-' + id + ' .dsftc-num'));
}

function fxWith(overrides) {
  return Object.assign({
    id: 'session-live', running: true, phase: 'building',
    combo: 42, maxCombo: 47, bestCombo: 128, level: 3, multiplier: 2, nextLevelAt: 90,
    tier: 'GREAT', hits: 42, score: 1234, energy: 0.55,
    tokens: { turn: 321, live: 12, output: 309, total: 9876 },
    turn: 3, step: 1, milestone: 25, milestoneSeq: 1, hitSeq: 42,
    breakSeq: 0, settleSeq: 0, startSeq: 1, completedTurns: 2, now: 1730000001000
  }, overrides || {});
}
const saturated = fxWith({ phase: 'settled', combo: 1950, level: 7, multiplier: 8, tier: 'LEGEND' });
const idle = fxWith({ phase: 'idle', combo: 0, level: 1, multiplier: 1, hitSeq: 0, milestone: 0, milestoneSeq: 0 });

section('Arena / Preview / Badge / Icon');
for (const preset of fx.PRESETS) {
  const id = preset.id;
  let arena = null;
  let preview = null;
  try { arena = preset.Arena({ fx: saturated, compact: false, scale: 1, reduced: false, locale: 'zh' }); }
  catch (error) { check(id + ': Arena renders', false, String(error)); }
  if (arena) {
    check(id + ': Arena has combo number', classHits(arena, 'dsftc-num').length === 1);
    check(id + ': Arena has judge line', classHits(arena, 'dsftc-judge').length === 1);
    check(id + ': Arena has meter', classHits(arena, 'dsftc-bar-fill').length === 1);
    check(id + ': Arena has stats', classHits(arena, 'dsftc-stat').length >= 3);
    check(id + ': Arena avatar image', findAll(arena, (node) => node.type === 'img' && String(node.props.className).includes('dsftc-avatar')).length === 1);
    check(id + ': Arena portrait image', findAll(arena, (node) => node.type === 'img' && String(node.props.className).includes('dsftc-art')).length === 1);
    check(id + ': Arena art src', findAll(arena, (node) => node.type === 'img' && node.props.src === '/token-combo/art/' + id + '.webp').length >= 1);
    check(id + ': ArtUrl unique', findAll(arena, (node) => node.type === 'img').every((node) => node.props.src.includes('/token-combo/art/' + id + '.webp')));
  }
  try { preview = preset.Preview({ locale: 'zh' }); }
  catch (error) { check(id + ': Preview renders', false, String(error)); }
  if (preview) {
    check(id + ': Preview portrait', findAll(preview, (node) => node.type === 'img' && String(node.props.className).includes('dsftc-pv-art')).length === 1);
    check(id + ': Preview has no overlay text', collectText(preview).trim() === '');
  }
  try {
    const badge = preset.Badge({ fx: saturated, compact: true, scale: 1, locale: 'zh' });
    check(id + ': Badge renders', !!badge && typeof badge === 'object');
    const icon = preset.Icon({ size: 20, active: true });
    check(id + ': Icon portrait', icon && icon.type === 'img' && String(icon.props.src).includes('/token-combo/art/' + id + '.webp'));
  } catch (error) {
    check(id + ': Badge/Icon render', false, String(error));
  }
  try { preset.Arena({ fx: idle, compact: true, scale: 1, reduced: true, locale: 'en' }); }
  catch (error) { check(id + ': Arena idle safe', false, String(error)); }
}

section('judge / KO');
const JUDGES = { deepseek: '白饭', chatgpt: '生成', claude: '蒸馏', gemini: '检索', glm: '开源', grok: '叛逆', qwen: '微调' };
for (const id of CHARACTER_IDS) {
  for (const level of [1, 3, 6]) {
    const arena = byId[id].Arena({ fx: fxWith({ level, hitSeq: 7 }), compact: true, scale: 1, locale: 'zh' });
    check(id + ': level ' + level + ' judge ' + JUDGES[id], collectText(arena).includes(JUDGES[id]));
  }
}
const grokSettled = byId.grok.Arena({ fx: saturated, compact: true, scale: 1, locale: 'en' });
for (const id of CHARACTER_IDS) {
  const arena = byId[id].Arena({ fx: saturated, compact: true, scale: 1, locale: 'en' });
  check(id + ': no K.O.', classHits(arena, 'dsftc-ko').length === 0);
}

section('compactNum boundaries (rendered)');
/* tokens.turn is read as a float, so it exercises compactNum directly through statsRow. */
function tokenDisplay(turn) {
  const arena = byId.deepseek.Arena({
    fx: fxWith({ tokens: { turn: turn, live: 0, output: 0, total: 0 } }),
    locale: 'zh'
  });
  const cells = findAll(arena, (node) => node.type === 'b' && String(node.props.className || '').split(/\s+/).includes('dsftc-sv'));
  return cells.length ? collectText(cells[0]).trim() : '';
}
const COMPACT_CASES = [
  [0, '0'], [1, '1'], [42, '42'], [999, '999'], [1234, '1234'], [9999, '9999'],
  [9999.4, '9999'], [9999.5, '10K'], [9999.99, '10K'], [10000, '10K'],
  [12345, '12.3K'], [99999, '100K'], [123456, '123K'],
  [999499, '999K'], [999500, '1M'], [999999, '1M'], [1000000, '1M'],
  [1234567, '1.2M'], [9999999, '10M'], [999999999, '1B']
];
for (const [value, want] of COMPACT_CASES) {
  const got = tokenDisplay(value);
  check('compactNum ' + value + ' -> ' + want, got === want, 'got ' + got);
  check('compactNum ' + value + ' width <= 5', got.length <= 5, got + ' (' + got.length + ' chars)');
}
check('compactNum: 9999.5..9999.99 never shows 10000', tokenDisplay(9999.5) !== '10000' && tokenDisplay(9999.99) !== '10000');
check('compactNum: 999999 never shows 1000K', tokenDisplay(999999) !== '1000K');

section('SfxEngine');
const Sfx = fx.SfxEngine;
const engine = new Sfx();
check('sfx lazy context', engine._ctx === null || engine._ctx === undefined);
check('sfx muted hit is no-op', (() => { try { engine.sync({ muted: true }); engine.hit({ presetId: 'deepseek', level: 3 }); return true; } catch { return false; } })());
try { engine.dispose(); check('sfx dispose', true); } catch { check('sfx dispose', false); }

section('SfxEngine node bookkeeping');

/* Minimal AudioContext stub: nodes are recorded so tests can inspect
   connect/disconnect/start/stop and fire onended handlers manually. */
function makeAudioStub() {
  const nodes = [];
  const sources = [];
  function param(value) {
    return {
      value: value,
      setValueAtTime: function () {},
      exponentialRampToValueAtTime: function () {},
      linearRampToValueAtTime: function () {},
      setTargetAtTime: function () {},
      cancelScheduledValues: function () {}
    };
  }
  function node(kind) {
    const n = {
      kind: kind, connects: 0, disconnects: 0, starts: 0, stops: 0,
      startAt: null, stopAt: null, onended: null
    };
    n.connect = function (target) { n.connects++; return target || undefined; };
    n.disconnect = function () { n.disconnects++; };
    nodes.push(n);
    return n;
  }
  function sourceNode(kind) {
    const n = node(kind);
    n.start = function (t) { n.starts++; n.startAt = t; };
    n.stop = function (t) { n.stops++; n.stopAt = t; };
    sources.push(n);
    return n;
  }
  const ctx = {
    currentTime: 0,
    sampleRate: 44100,
    state: 'running',
    destination: node('destination'),
    nodes: nodes,
    sources: sources,
    closeCalls: 0,
    createGain: function () { const g = node('gain'); g.gain = param(1); return g; },
    createOscillator: function () {
      const o = sourceNode('oscillator');
      o.type = 'sine';
      o.frequency = param(440);
      o.detune = param(0);
      return o;
    },
    createBufferSource: function () { const b = sourceNode('bufferSource'); b.buffer = null; return b; },
    createBuffer: function (channels, length, rate) {
      const data = new Float32Array(Math.max(1, length | 0));
      return {
        numberOfChannels: channels,
        length: data.length,
        sampleRate: rate,
        getChannelData: function () { return data; }
      };
    },
    createBiquadFilter: function () {
      const f = node('biquad');
      f.type = 'lowpass';
      f.frequency = param(1000);
      f.Q = param(1);
      return f;
    },
    close: function () { ctx.closeCalls++; ctx.state = 'closed'; return Promise.resolve(); }
  };
  ctx.fireEnded = function () {
    for (const s of sources.slice()) {
      if (typeof s.onended !== 'function') continue;
      const fn = s.onended;
      s.onended = null;
      try { fn(); } catch (e) { /* ignore */ }
    }
  };
  return ctx;
}
function engineWithStub(stub) {
  return new Sfx({ createContext: function () { return stub; } });
}

/* nodes are released (and emptied) when onended fires */
{
  const stub = makeAudioStub();
  const e = engineWithStub(stub);
  e.hit({ presetId: 'deepseek', level: 3 });
  e.milestone({ presetId: 'grok', level: 4 });
  e.breakCombo({ presetId: 'gemini' });
  e.settle({ presetId: 'deepseek', combo: 120 });
  const tracked = e._nodes.slice();
  check('sfx stub: nodes tracked', tracked.length > 0, 'got ' + tracked.length);
  const fmEntries = tracked.filter(function (entry) { return entry.extra.length === 3; });
  check('sfx stub: fm graph tracked', fmEntries.length > 0, 'got ' + fmEntries.length);
  stub.fireEnded();
  check('sfx stub: onended drains _nodes', e._nodes.length === 0, 'left ' + e._nodes.length);
  check('sfx stub: onended disconnects src', tracked.every(function (entry) { return entry.src.disconnects > 0; }));
  check('sfx stub: onended disconnects extras', tracked.every(function (entry) {
    return entry.extra.every(function (n) { return n.disconnects > 0; });
  }));
  check('sfx stub: fm mod/mGain/amp disconnected', fmEntries.every(function (entry) {
    return entry.extra[0].disconnects > 0 && entry.extra[1].disconnects > 0 && entry.extra[2].disconnects > 0;
  }));
  e.dispose();
}

/* hard cap of 256 tracked entries */
{
  const stub = makeAudioStub();
  const e = engineWithStub(stub);
  for (let i = 0; i < 200; i++) e.milestone({ presetId: 'grok', level: 3 }); // 3 entries each
  check('sfx stub: _nodes hard cap', e._nodes.length === 256, 'got ' + e._nodes.length);
  check('sfx stub: cap evicts and disconnects old nodes', stub.sources.filter(function (s) { return s.disconnects > 0; }).length === stub.sources.length - e._nodes.length, 'disconnected ' + stub.sources.filter(function (s) { return s.disconnects > 0; }).length + ' of ' + stub.sources.length);
  e.dispose();
  check('sfx stub: dispose clears capped array', e._nodes.length === 0);
}

/* dispose is idempotent, stops live nodes, and leaves public API safe */
{
  const stub = makeAudioStub();
  const e = engineWithStub(stub);
  e.milestone({ presetId: 'grok', level: 2 });
  e.settle({ presetId: 'qwen', combo: 10 });
  const live = e._nodes.slice();
  check('sfx stub: live nodes before dispose', live.length > 0, 'got ' + live.length);
  e.dispose();
  check('sfx stub: dispose clears _nodes', e._nodes.length === 0);
  check('sfx stub: dispose stops live src', live.every(function (entry) { return entry.src.stops >= 2; }));
  check('sfx stub: dispose closes context once', stub.closeCalls === 1, 'close calls ' + stub.closeCalls);
  const createdBefore = stub.nodes.length;
  e.hit({ presetId: 'deepseek', level: 3 });
  e.milestone({ presetId: 'gemini', level: 2 });
  e.breakCombo({ presetId: 'grok' });
  e.settle({ presetId: 'claude', combo: 3 });
  check('sfx stub: post-dispose calls add no nodes', e._nodes.length === 0 && stub.nodes.length === createdBefore);
  try { e.dispose(); check('sfx stub: dispose idempotent', e._nodes.length === 0 && stub.closeCalls === 1); }
  catch (error) { check('sfx stub: dispose idempotent', false, String(error)); }
}

/* no AudioContext available => every voice is a no-op */
{
  const e = new Sfx({ createContext: function () { return null; } });
  try {
    e.hit({ presetId: 'deepseek', level: 3 });
    e.milestone({ presetId: 'grok', level: 2 });
    e.breakCombo({ presetId: 'gemini' });
    e.settle({ presetId: 'claude', combo: 5 });
    check('sfx stub: missing AudioContext no-op', e._ctx === null && e._nodes.length === 0 && e._dead === false);
  } catch (error) {
    check('sfx stub: missing AudioContext no-op', false, String(error));
  }
  e.dispose();
}

section('report');
console.log('passed: ' + passed + ', failed: ' + failures.length);
for (const failure of failures) console.log('  FAIL ' + failure);
if (failures.length) process.exit(1);
console.log('PASS');
