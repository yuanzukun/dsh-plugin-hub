// Token Combo — Client core (plain script, concatenated into the __ModuleLoader__ factory).
// React and createComboFx(React) are in scope from the bundle wrapper.
const h = React.createElement;
const fx = createComboFx(React);

/** Resolve one preset object by id (guarding unknown stored prefs). */
function presetOf(id) {
  return fx.PRESETS.find((preset) => preset.id === id) || fx.PRESETS[0];
}

const CHANNEL = '/token-combo';
const PANEL_ID = 'combo';
// Bump when the stored default geometry changes; older drag positions are dropped.
const PREFS_VERSION = 8;
const PREFS_KEY = 'dsh-token-combo:prefs:v1';
const STATS_KEY = 'dsh-token-combo:stats:v1';

/** Fire-and-forget Host RPC for desktop HUD commands. */
function callHost(ctx, endpoint, payload) {
  try {
    if (!ctx || !ctx.connection || !ctx.connection.rpc || typeof ctx.connection.rpc.call !== 'function') return Promise.resolve(null);
    const pending = ctx.connection.rpc.call(CHANNEL, endpoint, payload);
    if (!pending || typeof pending.then !== 'function') return Promise.resolve(null);
    return pending.then((response) => (response && response.value ? response.value : null)).catch(() => null);
  } catch {
    /* desktop HUD is optional */
    return Promise.resolve(null);
  }
}

const LEVELS = [
  { at: 0, multiplier: 1, tier: 'READY' },
  { at: 30, multiplier: 1.5, tier: 'NICE' },
  { at: 90, multiplier: 2, tier: 'GREAT' },
  { at: 210, multiplier: 3, tier: 'FRENZY' },
  { at: 450, multiplier: 4, tier: 'FEVER' },
  { at: 950, multiplier: 5, tier: 'GODLIKE' },
  { at: 1950, multiplier: 8, tier: 'LEGEND' },
];
const MILESTONES = [10, 25, 50, 100, 150, 200, 300, 500, 750, 1000];

const DEFAULT_PREFS = {
  version: PREFS_VERSION,
  style: 'deepseek',
  display: 'overlay', // overlay | dock | both | none (legacy; derived from the two toggles)
  overlayEnabled: true,
  dockEnabled: false,
  anchor: 'left', // content alignment: left | right
  scale: 1,
  sound: true,
  sfxStyle: 'rhythm', // auto | rhythm | fighting | arcade | cyber
  volume: 0.25,
  reduced: false,
  overlayPos: null,
  overlayCollapsed: false,
  desktopHud: false,
  // Click-through state: true = clicks pass through (cannot drag), false = draggable.
  desktopHudInteractive: false,
  hudHotkeysEnabled: true,
  hudHotkeyToggle: 'Ctrl+Alt+T',
  hudHotkeyClose: 'Ctrl+Alt+X',
};

const TEXT = {
  zh: {
    brand: 'Token Combo',
    panel: '词元连击',
    subtitle: '实时读取当前会话的流式输出：连击、倍率、Token 数与总分。',
    live: 'LIVE',
    offline: '未连接',
    waiting: '待命',
    building: '连击中',
    settled: '结算',
    broken: '连击中断',
    burstSettle: '词元入账',
    burstMilestone: '里程碑',
    burstBreak: '断连',
    combo: '连击',
    maxCombo: '最高连击',
    multiplier: '倍率',
    nextTier: '下一等级',
    tokens: '本轮 Tokens',
    score: '总分',
    hits: '命中',
    best: '历史最佳',
    trial: '试炼模式',
    trialOn: '试炼中',
    trialHint: '用模拟 Token 流预览风格，不影响真实数据。',
    reset: '重置数据',
    resetConfirm: '再按一次确认',
    styles: '风格预设',
    stylesHint: '控制台、悬浮窗与聊天栏共用同一套风格，点击立即切换。',
    display: '显示位置',
    displayHint: '窗口悬浮窗、聊天栏、桌面悬浮窗各自独立开关，设置立即生效。',
    overlayToggle: '窗口悬浮窗',
    dockToggle: '聊天栏',
    displayIndependentHint: '三个显示位置各自独立开关；桌面悬浮窗不可用时，窗口悬浮窗仍可作为兜底。',
    anchor: '内容对齐',
    anchorLeft: '靠左',
    anchorRight: '靠右',
    anchorHint: '控制 HUD 内容对齐：靠右时数字变长、弹跳动画都向左扩展；靠左时向右扩展。',
    desktopHud: '桌面悬浮窗',
    desktopHudHint: '独立置顶透明窗口，叠在其他应用上方；需要 WebView2，不可用时请用窗口悬浮窗兜底。',
    desktopHudInteractive: '鼠标穿透',
    desktopHudInteractiveHint: '开启后点击穿过悬浮窗；Ctrl+Alt+T 可快速切换。',
    desktopHudHotkey: 'Ctrl+Alt+T 切换穿透 · Ctrl+Alt+X 关闭悬浮窗',
    hudHotkeys: '快捷键',
    hudHotkeysHint: '可修改组合键（需含 Ctrl/Alt/Shift/Win，或用 F1–F12），失焦或回车生效；也可关闭快捷键注册。',
    hudHotkeyToggle: '切换穿透',
    hudHotkeyClose: '关闭悬浮窗',
    hudHotkeyPlaceholder: 'Ctrl+Alt+T',
    scale: '界面缩放',
    sound: '音效',
    soundHint: 'WebAudio 合成音，无外部音频文件。',
    sfxStyle: '音效风格',
    sfxAuto: '角色专属',
    sfxRhythm: '经典音游',
    sfxFighting: '格斗',
    sfxArcade: '街机',
    sfxCyber: '赛博',
    sfxHint: '默认使用旧版预设的合成音；也可选择角色专属音色。',
    volume: '音量',
    reduced: '低动态',
    reducedHint: '减少闪烁与位移（不改变布局），也自动跟随系统“减少动态效果”。',
    rules: '连击规则',
    ruleHit: '模型每流式输出一段可见 Token，连击 +1 并累计 Token 估算值；倍率随连击等级提升。',
    ruleBreak: '连击槽会持续回退；槽空时掉级，最低阶段的槽也空时连击中断（槽越满越耐断）。',
    ruleBank: '一轮输出结束会结算当前连击，并写入历史最佳。',
    ruleAudio: '关闭显示后音效仍在播放；想完全安静请关闭音效。',
    levels: '等级',
    atCombo: '连击',
    openConsole: '打开控制台',
    backToChat: '返回对话',
    hide: '隐藏',
    collapse: '收起',
    expand: '展开',
    dragHint: '按住任意位置拖动',
    resetPosition: '恢复默认位置',
    collapsed: '连击',
    statTotal: '本次运行累计',
    session: '会话',
    currentStyle: '当前风格',
    syncNote: '数据由 Host 实时推送，约每 80ms 合并一次。',
    demoBanner: '试炼模式：模拟连击流',
    settingsTitle: 'Token Combo 连击',
    settingsDesc: '把 Token 流变成街机连击，可切换显示位置与风格。',
    settingsDisplay: '位置',
    settingsSound: '音效',
    off: '关',
    on: '开',
    footer: 'Token Combo · 娱乐插件 · 数据仅本地与当前进程',
    liveBadge: '实时',
    idleBadge: '待命',
  },
  en: {
    brand: 'Token Combo',
    panel: 'Combo Arena',
    subtitle: 'Live stream from the active session: combo, multiplier, tokens and score.',
    live: 'LIVE',
    offline: 'Offline',
    waiting: 'Standby',
    building: 'Combo',
    settled: 'Banked',
    broken: 'Miss',
    burstSettle: 'TOKENS BANKED',
    burstMilestone: 'MILESTONE',
    burstBreak: 'COMBO BREAK',
    combo: 'Combo',
    maxCombo: 'Max combo',
    multiplier: 'Multiplier',
    nextTier: 'Next tier',
    tokens: 'Turn tokens',
    score: 'Score',
    hits: 'Hits',
    best: 'Best ever',
    trial: 'Practice',
    trialOn: 'Practising',
    trialHint: 'Preview the style with a simulated token stream; real stats are untouched.',
    reset: 'Reset data',
    resetConfirm: 'Press again to confirm',
    styles: 'Style presets',
    stylesHint: 'The console, overlay and chat bar share one style. Click to switch instantly.',
    display: 'Placement',
    displayHint: 'Window overlay, chat dock and desktop HUD each have their own switch; changes apply immediately.',
    overlayToggle: 'Window overlay',
    dockToggle: 'Chat dock',
    displayIndependentHint: 'Each position has its own switch; if the desktop HUD is unavailable, the window overlay remains the fallback.',
    anchor: 'HUD alignment',
    anchorLeft: 'Left',
    anchorRight: 'Right',
    anchorHint: 'Controls content alignment: Right grows and pops leftward, Left grows rightward.',
    desktopHud: 'Desktop HUD',
    desktopHudHint: 'Always-on-top transparent window outside the DSH window; requires WebView2, use the window overlay as fallback.',
    desktopHudInteractive: 'Click-through',
    desktopHudInteractiveHint: 'Clicks pass through the HUD when enabled; Ctrl+Alt+T toggles it.',
    desktopHudHotkey: 'Ctrl+Alt+T toggles click-through · Ctrl+Alt+X closes the HUD',
    hudHotkeys: 'Hotkeys',
    hudHotkeysHint: 'Customize the combos (a modifier or F1–F12 is required; commit on blur/Enter), or disable hotkey registration.',
    hudHotkeyToggle: 'Toggle click-through',
    hudHotkeyClose: 'Close HUD',
    hudHotkeyPlaceholder: 'Ctrl+Alt+T',
    scale: 'UI scale',
    sound: 'Sound',
    soundHint: 'Synthesized WebAudio SFX, no external audio files.',
    sfxStyle: 'SFX style',
    sfxAuto: 'Character',
    sfxRhythm: 'Classic rhythm',
    sfxFighting: 'Fighter',
    sfxArcade: 'Arcade',
    sfxCyber: 'Cyber',
    sfxHint: 'Defaults to the old preset SFX; you can switch to each character voice instead.',
    volume: 'Volume',
    reduced: 'Low motion',
    reducedHint: 'Less flashing and movement; also follows the OS reduced-motion preference.',
    rules: 'Combo rules',
    ruleHit: 'Every visible streamed token chunk adds a hit and estimated tokens; the multiplier rises with the combo tier.',
    ruleBreak: 'The combo meter keeps draining; an empty meter drops a tier, and the lowest tier breaks the combo (a fuller meter survives longer).',
    ruleBank: 'When a stream settles, the combo is banked into the all-time best.',
    ruleAudio: 'Sound keeps playing when placement is Off; turn Sound off to go fully silent.',
    levels: 'Tiers',
    atCombo: 'Combo',
    openConsole: 'Open console',
    backToChat: 'Back to chat',
    hide: 'Hide',
    collapse: 'Collapse',
    expand: 'Expand',
    dragHint: 'Drag anywhere to move',
    resetPosition: 'Reset position',
    collapsed: 'Combo',
    statTotal: 'Process total',
    session: 'Session',
    currentStyle: 'Current style',
    syncNote: 'Pushed from the Host, coalesced to about one update per 80ms.',
    demoBanner: 'Practice mode: simulated combo stream',
    settingsTitle: 'Token Combo',
    settingsDesc: 'Turn the token stream into an arcade combo; switch placement and style here.',
    settingsDisplay: 'Placement',
    settingsSound: 'Sound',
    off: 'Off',
    on: 'On',
    footer: 'Token Combo · just for fun · data stays local to this run',
    liveBadge: 'LIVE',
    idleBadge: 'STANDBY',
  },
};

function dictFor(locale) {
  return locale === 'en' ? TEXT.en : TEXT.zh;
}

function readLocale(ctx) {
  // While the locale service is still initializing, fall back to the browser
  // language so Chinese users do not see an English flash on first paint.
  const browserLocale = () => {
    try {
      const language = typeof window !== 'undefined' && window.navigator ? window.navigator.language : '';
      return typeof language === 'string' && language.toLowerCase().startsWith('zh') ? 'zh' : 'en';
    } catch {
      return 'zh';
    }
  };
  try {
    const service = ctx && ctx.locale;
    const snapshot = service && typeof service.getSnapshot === 'function' ? service.getSnapshot() : null;
    const active = snapshot && typeof snapshot === 'object' ? (snapshot.active ?? snapshot.id) : null;
    if (typeof active === 'string' && active.length > 0) return active.toLowerCase().startsWith('zh') ? 'zh' : 'en';
    return browserLocale();
  } catch {
    return browserLocale();
  }
}

function useLocale(ctx) {
  const [locale, setLocale] = React.useState(() => readLocale(ctx));
  React.useEffect(() => {
    let dispose = null;
    try {
      if (ctx && ctx.locale && typeof ctx.locale.subscribe === 'function') {
        dispose = ctx.locale.subscribe(() => setLocale(readLocale(ctx)));
      }
    } catch {
      dispose = null;
    }
    return () => {
      try {
        if (typeof dispose === 'function') dispose();
      } catch {
        /* ignore */
      }
    };
  }, [ctx]);
  return locale;
}

function useSystemReduced() {
  const [reduced, setReduced] = React.useState(() => {
    try {
      return window.matchMedia('(prefers-reduced-motion: reduce)').matches === true;
    } catch {
      return false;
    }
  });
  React.useEffect(() => {
    let mq = null;
    const onChange = () => setReduced(mq !== null && mq.matches === true);
    try {
      mq = window.matchMedia('(prefers-reduced-motion: reduce)');
      if (typeof mq.addEventListener === 'function') mq.addEventListener('change', onChange);
    } catch {
      mq = null;
    }
    return () => {
      try {
        if (mq !== null && typeof mq.removeEventListener === 'function') mq.removeEventListener('change', onChange);
      } catch {
        /* ignore */
      }
    };
  }, []);
  return reduced;
}

// ---------------------------------------------------------------- utils

/** Clamp a finite number; a missing/invalid value falls back to `fallback` (or `min`). */
function clamp(value, min, max, fallback) {
  const number = typeof value === 'number' && Number.isFinite(value) ? value : fallback === undefined ? min : fallback;
  return Math.min(max, Math.max(min, number));
}

function groupInt(value) {
  const number = typeof value === 'number' && Number.isFinite(value) ? Math.max(0, Math.round(value)) : 0;
  const text = String(number);
  let out = '';
  for (let index = 0; index < text.length; index += 1) {
    const back = text.length - index;
    out += text[index];
    if (back > 1 && back % 3 === 1) out += ',';
  }
  return out;
}

function trim1(value) {
  return String(Math.round(value * 10) / 10).replace(/\.0$/, '');
}

/** Display number: exact through 9999, then K/M/B (max 5 chars). */
function formatTokens(value) {
  const number = typeof value === 'number' && Number.isFinite(value) ? Math.max(0, value) : 0;
  // Round first so 9999.5 becomes 10K instead of "10000"; promote a rounded
  // 1000-unit tail to the next bracket instead of showing "1000K" / "1000M".
  const rounded = Math.round(number);
  if (rounded < 10000) return String(rounded);
  if (rounded < 100000) return trim1(rounded / 1000) + 'K';
  if (rounded < 1000000) {
    const thousands = Math.round(rounded / 1000);
    return thousands >= 1000 ? '1M' : String(thousands) + 'K';
  }
  if (rounded < 10000000) return trim1(rounded / 1000000) + 'M';
  if (rounded < 1000000000) {
    const millions = Math.round(rounded / 1000000);
    return millions >= 1000 ? '1B' : String(millions) + 'M';
  }
  return trim1(rounded / 1000000000) + 'B';
}

function delay(ms, signal) {
  return new Promise((resolve) => {
    if (!signal || signal.aborted) {
      resolve();
      return;
    }
    const timer = window.setTimeout(done, ms);
    function done() {
      window.clearTimeout(timer);
      try {
        signal.removeEventListener('abort', done);
      } catch {
        /* ignore */
      }
      resolve();
    }
    try {
      signal.addEventListener('abort', done, { once: true });
    } catch {
      /* ignore */
    }
  });
}

function levelFor(combo) {
  let current = LEVELS[0];
  for (const step of LEVELS) {
    if (combo >= step.at) current = step;
  }
  return current;
}

function nextLevelAt(combo) {
  for (const step of LEVELS) {
    if (step.at > combo) return step.at;
  }
  return null;
}

function highestMilestone(previous, combo) {
  let hit = null;
  for (const at of MILESTONES) {
    if (previous < at && combo >= at) hit = at;
  }
  if (combo >= 1000) {
    const step = 500 * Math.floor(combo / 500);
    if (step > 1000 && previous < step && combo >= step) hit = step;
  }
  return hit;
}

function idleFx(now) {
  return {
    id: null,
    running: false,
    phase: 'idle',
    combo: 0,
    maxCombo: 0,
    bestCombo: 0,
    level: 1,
    multiplier: 1,
    nextLevelAt: 30,
    tier: 'READY',
    hits: 0,
    score: 0,
    tokens: { turn: 0, live: 0, output: 0, total: 0 },
    turn: 0,
    step: 0,
    lastHitAt: 0,
    energy: 0,
    activeAt: 0,
    startedAt: 0,
    milestone: 0,
    milestoneSeq: 0,
    hitSeq: 0,
    breakSeq: 0,
    settleSeq: 0,
    startSeq: 0,
    completedTurns: 0,
    now: typeof now === 'number' ? now : Date.now(),
  };
}

function normalizeFx(session) {
  if (session === null || session === undefined || typeof session !== 'object') return idleFx();
  const tokens = session.tokens !== null && typeof session.tokens === 'object' ? session.tokens : {};
  const next = Number(session.nextLevelAt);
  return {
    ...idleFx(),
    ...session,
    nextLevelAt: next > 0 ? next : null,
    tokens: {
      turn: Number(tokens.turn) || 0,
      live: Number(tokens.live) || 0,
      output: Number(tokens.output) || 0,
      total: Number(tokens.total) || 0,
    },
    now: Date.now(),
  };
}

// ---------------------------------------------------------------- preference + stats store

const prefsListeners = new Set();
let prefsCache = null;

function sanitizePrefs(raw) {
  const value = raw !== null && typeof raw === 'object' ? raw : {};
  const styleId = typeof value.style === 'string' && fx.PRESETS.some((preset) => preset.id === value.style) ? value.style : DEFAULT_PREFS.style;
  const display = value.display === 'dock' || value.display === 'both' || value.display === 'none' ? value.display : 'overlay';
  const hasIndependent = typeof value.overlayEnabled === 'boolean' || typeof value.dockEnabled === 'boolean';
  const overlayEnabled = hasIndependent ? value.overlayEnabled !== false : display !== 'dock' && display !== 'none';
  const dockEnabled = hasIndependent ? value.dockEnabled === true : display === 'dock' || display === 'both';
  const derivedDisplay = dockEnabled && overlayEnabled ? 'both' : dockEnabled ? 'dock' : overlayEnabled ? 'overlay' : 'none';
  const anchor = value.anchor === 'right' ? 'right' : 'left';
  const positionVersionOk = Number(value.version) === PREFS_VERSION;
  const overlayPos =
    positionVersionOk &&
    value.overlayPos !== null &&
    typeof value.overlayPos === 'object' &&
    Number.isFinite(value.overlayPos.x) &&
    Number.isFinite(value.overlayPos.y)
      ? { x: value.overlayPos.x, y: value.overlayPos.y }
      : null;
  return {
    version: PREFS_VERSION,
    style: styleId,
    display: derivedDisplay,
    overlayEnabled,
    dockEnabled,
    anchor,
    scale: clamp(value.scale, 0.8, 2.4, DEFAULT_PREFS.scale),
    sound: value.sound !== false,
    sfxStyle: ['auto', 'rhythm', 'fighting', 'arcade', 'cyber'].includes(value.sfxStyle) ? value.sfxStyle : 'rhythm',
    volume: clamp(value.volume, 0, 1, DEFAULT_PREFS.volume),
    reduced: value.reduced === true,
    overlayPos,
    overlayCollapsed: value.overlayCollapsed === true,
    desktopHud: value.desktopHud === true,
    desktopHudInteractive: value.desktopHudInteractive === true,
    hudHotkeysEnabled: value.hudHotkeysEnabled !== false,
    hudHotkeyToggle: typeof value.hudHotkeyToggle === 'string' && value.hudHotkeyToggle.trim() !== '' ? value.hudHotkeyToggle.slice(0, 32) : 'Ctrl+Alt+T',
    hudHotkeyClose: typeof value.hudHotkeyClose === 'string' && value.hudHotkeyClose.trim() !== '' ? value.hudHotkeyClose.slice(0, 32) : 'Ctrl+Alt+X',
  };
}

function getPrefs() {
  if (prefsCache !== null) return prefsCache;
  let raw = null;
  try {
    const stored = window.localStorage.getItem(PREFS_KEY);
    if (stored) raw = JSON.parse(stored);
  } catch {
    raw = null;
  }
  prefsCache = sanitizePrefs(raw);
  return prefsCache;
}

function savePrefs(patch) {
  prefsCache = sanitizePrefs({ ...getPrefs(), ...patch });
  try {
    window.localStorage.setItem(PREFS_KEY, JSON.stringify(prefsCache));
  } catch {
    /* storage may be unavailable */
  }
  for (const listener of [...prefsListeners]) {
    try {
      listener();
    } catch {
      /* ignore */
    }
  }
  return prefsCache;
}

function subscribePrefs(listener) {
  prefsListeners.add(listener);
  return () => prefsListeners.delete(listener);
}

/** Used by the standalone WebView2 page to apply Host-owned HUD prefs live. */
function applyHostPrefs(patch) {
  if (patch === null || typeof patch !== 'object') return;
  const next = {};
  if (typeof patch.style === 'string') next.style = patch.style;
  const hostAnchor = patch.anchor === 'left' || patch.anchor === 'right' ? patch.anchor : patch.align === 'left' || patch.align === 'right' ? patch.align : null;
  if (hostAnchor !== null) next.anchor = hostAnchor;
  if (Number.isFinite(Number(patch.scale))) next.scale = Number(patch.scale);
  if (Object.keys(next).length > 0) savePrefs(next);
  // The HUD page re-initializes itself from the URL query when the Host locale
  // changes, so no separate locale storage key is needed here.
}
if (typeof window !== 'undefined') {
  window.__tokenComboApplyHostPrefs = applyHostPrefs;
}

function usePrefs() {
  const [value, setValue] = React.useState(getPrefs);
  React.useEffect(() => subscribePrefs(() => setValue(getPrefs())), []);
  return value;
}

const STATS_DEFAULT = { bestCombo: 0, bestMultiplier: 1, bestScore: 0, hits: 0, runs: 0 };
// Per-hit updates are frequent (every streaming chunk); coalesce the localStorage write.
const STATS_WRITE_DELAY = 800;
let statsCache = null;
let statsWriteTimer = null;
let statsDirty = false;
const statsListeners = new Set();

function clearStatsWriteTimer() {
  if (statsWriteTimer === null) return;
  try {
    window.clearTimeout(statsWriteTimer);
  } catch {
    /* ignore */
  }
  statsWriteTimer = null;
}

/** Persist the pending stats write once (called by the debounce timer and page-hide flush). */
function flushStats() {
  clearStatsWriteTimer();
  if (statsDirty !== true) return;
  statsDirty = false;
  if (statsCache === null) return;
  try {
    window.localStorage.setItem(STATS_KEY, JSON.stringify(statsCache));
  } catch {
    /* ignore */
  }
}

function scheduleStatsWrite() {
  statsDirty = true;
  if (statsWriteTimer !== null) return;
  try {
    statsWriteTimer = window.setTimeout(flushStats, STATS_WRITE_DELAY);
  } catch {
    statsWriteTimer = null;
    flushStats();
  }
}

function getStats() {
  if (statsCache !== null) return statsCache;
  let raw = null;
  try {
    const stored = window.localStorage.getItem(STATS_KEY);
    if (stored) raw = JSON.parse(stored);
  } catch {
    raw = null;
  }
  const value = raw !== null && typeof raw === 'object' ? raw : {};
  statsCache = {
    bestCombo: Number(value.bestCombo) || 0,
    bestMultiplier: Number(value.bestMultiplier) || 1,
    bestScore: Number(value.bestScore) || 0,
    hits: Number(value.hits) || 0,
    runs: Number(value.runs) || 0,
  };
  return statsCache;
}

function bumpStats(patch) {
  const current = getStats();
  const next = {
    bestCombo: Math.max(current.bestCombo, patch.bestCombo || 0),
    bestMultiplier: Math.max(current.bestMultiplier, patch.bestMultiplier || 1),
    bestScore: Math.max(current.bestScore, patch.bestScore || 0),
    hits: Math.max(current.hits, patch.hits || 0),
    runs: current.runs,
  };
  if (
    next.bestCombo === current.bestCombo &&
    next.bestMultiplier === current.bestMultiplier &&
    next.bestScore === current.bestScore &&
    next.hits === current.hits
  ) {
    return;
  }
  statsCache = next;
  scheduleStatsWrite();
  for (const listener of [...statsListeners]) {
    try {
      listener();
    } catch {
      /* ignore */
    }
  }
}

function resetStats() {
  statsCache = { ...STATS_DEFAULT };
  statsDirty = false;
  clearStatsWriteTimer();
  try {
    window.localStorage.removeItem(STATS_KEY);
  } catch {
    /* ignore */
  }
  for (const listener of [...statsListeners]) {
    try {
      listener();
    } catch {
      /* ignore */
    }
  }
}

function useStats() {
  const [value, setValue] = React.useState(getStats);
  React.useEffect(() => {
    const listener = () => setValue(getStats());
    statsListeners.add(listener);
    return () => statsListeners.delete(listener);
  }, []);
  return value;
}

// ---------------------------------------------------------------- host bridge

function createBridge(ctx) {
  const listeners = new Set();
  const abort = new AbortController();
  let state = { revision: 0, snapshot: null, connected: false, error: null, lastAt: 0 };
  let disposed = false;

  const emit = () => {
    for (const listener of [...listeners]) {
      try {
        listener();
      } catch {
        /* ignore */
      }
    }
  };

  const call = (endpoint, payload, signal) => {
    if (!ctx || !ctx.connection || !ctx.connection.rpc || typeof ctx.connection.rpc.call !== 'function') {
      return Promise.resolve({ ok: false, error: { code: 'combo/no-connection', message: 'connection service unavailable', details: {} } });
    }
    return ctx.connection.rpc.call(CHANNEL, endpoint, payload, signal);
  };

  const run = async () => {
    let backoff = 600;
    while (!disposed && !abort.signal.aborted) {
      try {
        const out = await call('poll', { since: state.revision, timeoutMs: 12000 }, abort.signal);
        if (disposed || abort.signal.aborted) return;
        if (out === null || typeof out !== 'object' || out.ok !== true) {
          throw new Error(out && out.error && typeof out.error.message === 'string' ? out.error.message : 'poll failed');
        }
        const value = out.value !== null && typeof out.value === 'object' ? out.value : {};
        const revision = Number(value.revision);
        if (!Number.isFinite(revision)) throw new Error('poll envelope missing revision');
        if (revision !== state.revision || state.snapshot === null) {
          state = {
            revision,
            snapshot: value.snapshot !== null && typeof value.snapshot === 'object' ? value.snapshot : state.snapshot,
            connected: true,
            error: null,
            lastAt: Date.now(),
          };
          emit();
        } else if (!state.connected) {
          state = { ...state, connected: true, error: null };
          emit();
        }
        backoff = 600;
      } catch (error) {
        if (disposed || abort.signal.aborted) return;
        const message = error instanceof Error ? error.message : String(error);
        state = { ...state, connected: false, error: message };
        emit();
        await delay(backoff, abort.signal);
        backoff = Math.min(backoff * 2, 5000);
      }
    }
  };

  void run();

  return {
    getState() {
      return state;
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    reset(sessionId) {
      return call('reset', sessionId ? { sessionId } : {}, abort.signal);
    },
    dispose() {
      disposed = true;
      try {
        abort.abort();
      } catch {
        /* ignore */
      }
      listeners.clear();
    },
  };
}

function useBridgeSnapshot(bridge) {
  const [state, setState] = React.useState(() => bridge.getState());
  React.useEffect(() => bridge.subscribe(() => setState(bridge.getState())), [bridge]);
  return state;
}

function useFocusedSessionId(props) {
  const useSessions = props && typeof props.useSessions === 'function' ? props.useSessions : null;
  const store = useSessions === null ? null : useSessions((snapshot) => snapshot);
  if (store === null || store === undefined || store.byId === null || typeof store.byId !== 'object') return null;
  const rows = Object.values(store.byId);
  let focused = rows.find((row) => row && row.retainedBy && (row.retainedBy.mainView || 0) > 0);
  if (focused === undefined) focused = rows.find((row) => row && row.running === true);
  if (focused === undefined) focused = rows.find((row) => row && row.open === true);
  return focused && typeof focused.id === 'string' ? focused.id : null;
}

function selectSession(snapshot, focusedId) {
  const sessions = snapshot && Array.isArray(snapshot.sessions) ? snapshot.sessions : [];
  if (sessions.length === 0) return null;
  if (focusedId !== null && focusedId !== undefined) {
    // A Host snapshot may merge a root conversation and all of its subagent sessions
    // into one entry; `members` lists those session ids (root included).
    const match = sessions.find(
      (session) =>
        session && (session.id === focusedId || (Array.isArray(session.members) && session.members.includes(focusedId))),
    );
    if (match) return match;
  }
  let best = null;
  for (const session of sessions) {
    if (!session || typeof session !== 'object') continue;
    if (best === null) {
      best = session;
      continue;
    }
    const bestActive = Number(best.activeAt) || 0;
    const nextActive = Number(session.activeAt) || 0;
    if (nextActive > bestActive || (nextActive === bestActive && session.running === true && best.running !== true)) best = session;
  }
  return best;
}

function useCombo(props, bridge, sessionIdOverride) {
  const locale = useLocale(props && props.ctx);
  const bridgeState = useBridgeSnapshot(bridge);
  const focusedId = useFocusedSessionId(props || {});
  const session = React.useMemo(
    () => selectSession(bridgeState.snapshot, sessionIdOverride ?? focusedId),
    [bridgeState.snapshot, sessionIdOverride, focusedId],
  );
  const value = React.useMemo(() => normalizeFx(session), [session, bridgeState.revision]);
  return {
    fx: value,
    snapshot: bridgeState.snapshot,
    session,
    focusedId,
    locale,
    connected: bridgeState.connected === true,
    revision: bridgeState.revision,
  };
}

function sfxPresetId(prefs) {
  const style = prefs && typeof prefs.sfxStyle === 'string' ? prefs.sfxStyle : 'rhythm';
  return style === 'auto' ? prefs.style : style;
}

function useAudioDriver(combo, prefs, sfx) {
  const previous = React.useRef({ ready: false, hitSeq: 0, milestoneSeq: 0, breakSeq: 0, settleSeq: 0 });
  React.useEffect(() => {
    try {
      sfx.sync({ muted: prefs.sound !== true, volume: prefs.volume });
    } catch {
      /* ignore */
    }
  }, [sfx, prefs.sound, prefs.volume]);
  React.useEffect(() => {
    const state = previous.current;
    const current = combo.fx;
    const seqs = {
      hitSeq: Number(current.hitSeq) || 0,
      milestoneSeq: Number(current.milestoneSeq) || 0,
      breakSeq: Number(current.breakSeq) || 0,
      settleSeq: Number(current.settleSeq) || 0,
    };
    if (!state.ready) {
      state.ready = true;
      state.hitSeq = seqs.hitSeq;
      state.milestoneSeq = seqs.milestoneSeq;
      state.breakSeq = seqs.breakSeq;
      state.settleSeq = seqs.settleSeq;
      return;
    }
    const style = sfxPresetId(prefs);
    try {
      if (seqs.settleSeq > state.settleSeq) {
        sfx.settle({ presetId: style, combo: current.combo });
      } else if (seqs.breakSeq > state.breakSeq) {
        sfx.breakCombo({ presetId: style });
      }
      if (seqs.milestoneSeq > state.milestoneSeq) {
        sfx.milestone({ presetId: style, level: current.level });
      } else if (seqs.hitSeq > state.hitSeq) {
        sfx.hit({ presetId: style, level: current.level });
      }
    } catch {
      /* audio is best-effort */
    }
    state.hitSeq = seqs.hitSeq;
    state.milestoneSeq = seqs.milestoneSeq;
    state.breakSeq = seqs.breakSeq;
    state.settleSeq = seqs.settleSeq;
  }, [combo.fx, prefs.style, prefs.sfxStyle, sfx]);
}

function useAchievements(combo) {
  const value = combo.fx;
  const bestCombo = Number(value.bestCombo) || 0;
  const comboNow = Number(value.combo) || 0;
  const multiplier = Number(value.multiplier) || 1;
  const score = Number(value.score) || 0;
  const hits = Number(value.hits) || 0;
  React.useEffect(() => {
    bumpStats({
      bestCombo: Math.max(bestCombo, comboNow),
      bestMultiplier: multiplier,
      bestScore: score,
      hits,
    });
  }, [bestCombo, comboNow, multiplier, score, hits]);
}

// ---------------------------------------------------------------- dialogs helper

function getLayout(ctx) {
  try {
    const layout = ctx && typeof ctx.get === 'function' ? ctx.get('layout') : ctx && ctx.layout;
    return layout !== null && layout !== undefined ? layout : null;
  } catch {
    return null;
  }
}

function openConsole(ctx) {
  const layout = getLayout(ctx);
  if (layout !== null && typeof layout.selectPanel === 'function') {
    try {
      layout.selectPanel(PANEL_ID);
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

function backToChat(ctx) {
  const layout = getLayout(ctx);
  if (layout !== null && typeof layout.selectPanel === 'function') {
    try {
      layout.selectPanel('conversation');
    } catch {
      /* ignore */
    }
  }
}

// ---------------------------------------------------------------- styles

const CORE_CSS = `
.dsftcu-console {
  box-sizing: border-box;
  height: 100%;
  overflow: auto;
  padding: 26px 30px 56px;
  color: var(--dsw-alias-label-primary, #e9eefb);
  font: 14px/1.55 system-ui, -apple-system, "Segoe UI", "Microsoft YaHei", sans-serif;
  background:
    radial-gradient(1100px 420px at 12% -8%, rgba(124, 77, 255, 0.16), transparent 62%),
    radial-gradient(900px 420px at 92% 0%, rgba(34, 230, 255, 0.10), transparent 60%);
}
.dsftcu-inner { max-width: 1120px; margin: 0 auto; display: flex; flex-direction: column; gap: 20px; }
.dsftcu-head { display: flex; flex-wrap: wrap; align-items: flex-end; gap: 14px 22px; justify-content: space-between; }
.dsftcu-brandline { display: flex; align-items: center; gap: 12px; }
.dsftcu-logo {
  width: 44px; height: 44px; border-radius: 13px; flex: 0 0 auto;
  display: grid; place-items: center;
  background: linear-gradient(140deg, #7c4dff 0%, #22e6ff 55%, #ff4d9d 100%);
  box-shadow: 0 0 24px rgba(124, 77, 255, 0.55), inset 0 0 14px rgba(255, 255, 255, 0.24);
  font-family: Impact, "Arial Black", sans-serif; font-size: 19px; color: #0b0618; letter-spacing: 0.5px;
}
.dsftcu-title { font-size: 26px; line-height: 1.15; font-weight: 800; letter-spacing: 0.4px; margin: 0; }
.dsftcu-sub { margin: 3px 0 0; font-size: 12.5px; color: var(--dsw-alias-label-secondary, #b8c2d8); max-width: 640px; }
.dsftcu-chip {
  display: inline-flex; align-items: center; gap: 6px;
  border-radius: 999px; padding: 3px 10px; font-size: 11.5px; font-weight: 600; letter-spacing: 0.4px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.28));
  background: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.05));
  color: var(--dsw-alias-label-secondary, #b8c2d8);
}
.dsftcu-chip[data-live="true"] { color: var(--dsw-alias-state-success-primary, #3ecf8e); border-color: rgba(62, 207, 142, 0.5); box-shadow: 0 0 12px rgba(62, 207, 142, 0.25); }
.dsftcu-dot { width: 7px; height: 7px; border-radius: 999px; background: currentColor; box-shadow: 0 0 8px currentColor; }
.dsftcu-card {
  border-radius: 18px; overflow: hidden;
  border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.22));
  background: var(--dsw-alias-bg-layer-1, rgba(20, 24, 38, 0.72));
  box-shadow: 0 18px 46px rgba(4, 8, 20, 0.22);
}
.dsftcu-arena-card { position: relative; }
.dsftcu-arena-toolbar {
  display: flex; flex-wrap: wrap; align-items: center; gap: 10px; justify-content: space-between;
  padding: 12px 16px; border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.16));
}
.dsftcu-arena-body { padding: 12px; display: flex; align-items: center; }
.dsftcu-stats { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 12px; }
.dsftcu-stat {
  border-radius: 16px; padding: 14px 16px 12px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.2));
  background: linear-gradient(160deg, rgba(124, 77, 255, 0.10), var(--dsw-alias-bg-layer-1, rgba(20, 24, 38, 0.6)));
  min-width: 0;
}
.dsftcu-stat-label { font-size: 11px; letter-spacing: 0.6px; text-transform: uppercase; color: var(--dsw-alias-label-secondary, #aab6cf); }
.dsftcu-stat-value { margin-top: 4px; font: 800 24px/1.05 Impact, "Arial Black", "Segoe UI Black", system-ui, sans-serif; letter-spacing: 0.5px; }
.dsftcu-stat-sub { margin-top: 3px; font-size: 11.5px; color: var(--dsw-alias-label-secondary, #aab6cf); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.dsftcu-section { display: flex; flex-direction: column; gap: 10px; }
.dsftcu-section-head { display: flex; align-items: baseline; gap: 10px; flex-wrap: wrap; }
.dsftcu-section-title { font-size: 15.5px; font-weight: 750; letter-spacing: 0.3px; }
.dsftcu-section-hint { font-size: 12px; color: var(--dsw-alias-label-secondary, #aab6cf); }
.dsftcu-presets { display: grid; grid-template-columns: repeat(auto-fit, minmax(170px, 1fr)); gap: 12px; }
.dsftcu-preset {
  position: relative; cursor: pointer; text-align: left; padding: 12px;
  border-radius: 16px; border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.22));
  background: var(--dsw-alias-bg-layer-1, rgba(20, 24, 38, 0.62));
  color: inherit; transition: transform 160ms ease, border-color 160ms ease, box-shadow 160ms ease;
  display: flex; flex-direction: column; gap: 10px; overflow: hidden;
}
.dsftcu-preset:hover { transform: translateY(-2px); border-color: var(--dsw-alias-border-l2, rgba(150, 175, 235, 0.4)); }
.dsftcu-preset[data-active="true"] {
  border-color: var(--dsw-alias-brand-primary, #7c6cff);
  box-shadow: 0 0 0 1px var(--dsw-alias-brand-primary, #7c6cff), 0 10px 34px rgba(124, 108, 255, 0.28);
}
.dsftcu-preset-preview { border-radius: 12px; overflow: hidden; position: relative; height: 82px; background: #06060f; }
.dsftcu-preset-preview .dsftc-pv { width: 100%; height: 100%; border: 0; border-radius: 0; }
.dsftcu-preset-meta { display: flex; align-items: center; gap: 8px; justify-content: space-between; }
.dsftcu-preset-name { font-weight: 700; font-size: 13.5px; }
.dsftcu-preset-hint { font-size: 11.5px; color: var(--dsw-alias-label-secondary, #aab6cf); }
.dsftcu-preset-check { font-size: 11px; font-weight: 700; letter-spacing: 0.5px; color: var(--dsw-alias-brand-primary, #9c8cff); }
.dsftcu-row { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; }
.dsftcu-row-between { display: flex; flex-wrap: wrap; align-items: center; gap: 10px; justify-content: space-between; }
.dsftcu-label { font-size: 12.5px; font-weight: 600; color: var(--dsw-alias-label-primary, #e9eefb); }
.dsftcu-muted { font-size: 12px; color: var(--dsw-alias-label-secondary, #aab6cf); }
.dsftcu-input {
  width: 128px;
  padding: 5px 8px;
  border-radius: 8px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(150, 170, 220, 0.25));
  background: var(--dsw-alias-bg-l2, rgba(255, 255, 255, 0.05));
  color: inherit;
  font: inherit;
  font-size: 12px;
}
.dsftcu-btn {
  appearance: none; display: inline-flex; align-items: center; justify-content: center; gap: 7px;
  height: 32px; padding: 0 12px; border-radius: 9px; cursor: pointer;
  border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.28));
  background: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.06));
  color: var(--dsw-alias-label-primary, #e9eefb); font: 600 12.5px/1 system-ui, -apple-system, "Segoe UI", sans-serif;
  transition: background 140ms ease, border-color 140ms ease, transform 120ms ease;
}
.dsftcu-btn:hover { background: rgba(140, 160, 240, 0.16); border-color: var(--dsw-alias-border-l2, rgba(150, 175, 235, 0.42)); }
.dsftcu-btn:active { transform: translateY(1px); }
.dsftcu-btn[data-variant="primary"] {
  border-color: transparent; color: #0b0618;
  background: linear-gradient(120deg, #9a7bff, #46e6ff 60%, #ff7ac2);
  box-shadow: 0 6px 20px rgba(124, 108, 255, 0.35);
}
.dsftcu-btn[data-variant="danger"] { color: var(--dsw-alias-state-error-primary, #ff6b6b); border-color: rgba(255, 107, 107, 0.42); background: rgba(255, 107, 107, 0.08); }
.dsftcu-btn[data-active="true"] { border-color: var(--dsw-alias-brand-primary, #8b7bff); background: rgba(124, 108, 255, 0.18); }
.dsftcu-btn:focus-visible, .dsftcu-preset:focus-visible, .dsftcu-seg button:focus-visible { outline: 2px solid var(--dsw-alias-brand-primary, #8b7bff); outline-offset: 2px; }
.dsftcu-seg { display: inline-flex; padding: 3px; gap: 2px; border-radius: 11px; background: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.06)); border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.24)); }
.dsftcu-seg button {
  appearance: none; border: 0; cursor: pointer; border-radius: 8px; padding: 0 11px; height: 27px;
  background: transparent; color: var(--dsw-alias-label-secondary, #b8c2d8); font: 600 12px/1 system-ui, sans-serif;
}
.dsftcu-seg button[data-active="true"] { background: var(--dsw-alias-bg-layer-1, rgba(255, 255, 255, 0.14)); color: var(--dsw-alias-label-primary, #ffffff); box-shadow: 0 1px 6px rgba(0, 0, 0, 0.24); }
.dsftcu-toggle {
  position: relative; width: 40px; height: 22px; flex: 0 0 auto; border-radius: 999px; cursor: pointer;
  border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.35));
  background: rgba(120, 140, 200, 0.18); padding: 0; transition: background 150ms ease;
}
.dsftcu-toggle[data-on="true"] { background: var(--dsw-alias-brand-primary, #6f5bff); border-color: transparent; }
.dsftcu-toggle span {
  position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border-radius: 999px; background: #ffffff;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.35); transition: left 150ms ease;
}
.dsftcu-toggle[data-on="true"] span { left: 20px; }
.dsftcu-slider { width: 150px; accent-color: #8b7bff; }
.dsftcu-value { font-size: 11.5px; color: var(--dsw-alias-label-secondary, #aab6cf); min-width: 42px; text-align: right; }
.dsftcu-settings-card { padding: 16px 18px; display: flex; flex-direction: column; gap: 12px; }
.dsftcu-settings-line { display: flex; flex-wrap: wrap; align-items: center; gap: 8px 14px; }
.dsftcu-settings-line > .dsftcu-label { min-width: 78px; }
.dsftcu-display-switches { display: flex; flex-wrap: wrap; align-items: center; gap: 10px 14px; }
.dsftcu-switch {
  display: inline-flex; align-items: center; gap: 10px;
  padding: 7px 12px; border-radius: 10px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.2));
  background: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.04));
}
.dsftcu-switch .dsftcu-label { min-width: 0; }
.dsftcu-display-hint { margin-top: -2px; }
.dsftcu-rulelist { margin: 0; padding-left: 18px; display: flex; flex-direction: column; gap: 6px; font-size: 12.5px; color: var(--dsw-alias-label-secondary, #b8c2d8); }
.dsftcu-levels { display: flex; flex-wrap: wrap; gap: 8px; }
.dsftcu-level {
  display: inline-flex; align-items: baseline; gap: 7px; padding: 5px 10px; border-radius: 999px;
  border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.24));
  background: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.05)); font-size: 12px;
}
.dsftcu-level b { font: 800 12.5px/1 Impact, "Arial Black", sans-serif; letter-spacing: 0.4px; }
.dsftcu-footer { display: flex; flex-wrap: wrap; gap: 8px 16px; justify-content: space-between; font-size: 11.5px; color: var(--dsw-alias-label-secondary, #93a0ba); padding-top: 4px; }
.dsftcu-overlay {
  position: absolute; z-index: 60; pointer-events: auto; cursor: grab;
  touch-action: none; user-select: none; -webkit-user-select: none;
  box-sizing: border-box;
}
.dsftcu-overlay:hover {
  outline: 1px dashed rgba(255, 255, 255, 0.22);
  outline-offset: 5px;
  border-radius: 8px;
}
.dsftcu-overlay[data-dragging="true"] {
  cursor: grabbing;
  outline: 1px dashed rgba(255, 255, 255, 0.28);
  outline-offset: 5px;
  border-radius: 8px;
}
/* Content alignment inside the fixed-width HUD (like left/right text alignment). */
.dsftcu-overlay .dsftcu-overlay-body { display: flex; flex-direction: column; }
.dsftcu-overlay[data-align="left"] .dsftcu-overlay-body { align-items: flex-start; }
.dsftcu-overlay[data-align="right"] .dsftcu-overlay-body { align-items: flex-end; }
.dsftcu-overlay[data-align="left"] .dsftc-num { transform-origin: left center; }
.dsftcu-overlay[data-align="right"] .dsftc-panel { justify-content: end; text-align: right; }
.dsftcu-overlay[data-align="right"] .dsftc-head { justify-content: flex-end; }
.dsftcu-overlay[data-align="right"] .dsftc-num { transform-origin: right center; }
.dsftcu-overlay[data-align="right"] .dsftc-main > .dsftc-side { justify-self: end; }
.dsftcu-overlay[data-align="right"] .dsftc-main > .dsftc-block:nth-child(2) { justify-self: end; text-align: right; }
.dsftcu-overlay[data-align="right"] .dsftc-bar { justify-self: end; }
.dsftcu-overlay[data-align="right"] .dsftc-stats { justify-self: end; }
.dsftcu-overlay[data-align="right"] .dsftcu-overlay-burst { text-align: right; }
.dsftcu-overlay[data-align="right"] .dsftc-sidekick { animation-name: dsftcu-hudside-right; }
@keyframes dsftcu-hudside-right {
  0% { transform: translateX(-0.55em) scale(1.09); }
  60% { transform: translateX(-0.1em) scale(1.01); }
  100% { transform: translateX(0) scale(1); }
}
.dsftcu-overlay-body { position: relative; padding: 0; }
/* Smooth combo-meter drain: the bar slides back instead of jumping. */
.dsftc-bar-fill { transition: width 180ms linear; }
/* Bare overlay: strip the preset panel chrome so only values, words and motion remain. */
.dsftcu-overlay-bare .dsftc-panel {
  background: transparent !important;
  border: 0 !important;
  box-shadow: none !important;
  padding: 0 !important;
  overflow: visible !important;
  border-radius: 0 !important;
  display: grid !important;
  grid-template-columns: auto auto;
  grid-template-areas:
    "head head"
    "combo mult"
    ". judge"
    "bar bar"
    "stats stats";
  align-items: start;
  align-content: start;
  justify-content: start;
  column-gap: 0.7em;
  row-gap: 0.05em;
}
.dsftcu-overlay-bare .dsftc-panel::before,
.dsftcu-overlay-bare .dsftc-panel::after { content: none !important; }
.dsftcu-overlay-bare .dsftc-arena { isolation: auto; overflow: visible; width: max-content; max-width: 100%; }
/* Never clip HUD text: the fixed boundary is a drag/hit box, not a crop box. */
.dsftcu-overlay, .dsftcu-overlay-body { overflow: visible !important; }
.dsftcu-overlay-bare .dsftc-arena, .dsftcu-overlay-bare .dsftc-panel { max-width: none !important; overflow: visible !important; }
.dsftcu-overlay-bare .dsftc-head, .dsftcu-overlay-bare .dsftc-stats { flex-wrap: nowrap; overflow: visible; }
.dsftcu-overlay-bare .dsftc-bword,
.dsftcu-overlay-bare .dsftc-status,
.dsftcu-overlay-bare .dsftc-judge,
.dsftcu-overlay-bare .dsftc-mult,
.dsftcu-overlay-bare .dsftc-sv,
.dsftcu-overlay-bare .dsftc-sk { white-space: nowrap; overflow: visible; }
.dsftcu-overlay-bare .dsftc-chip {
  background: transparent !important;
  border: 0 !important;
  backdrop-filter: none !important;
  padding: 0.1em 0.15em !important;
}
.dsftcu-overlay-bare .dsftc-deco { opacity: 0.42; }
.dsftcu-overlay-bare .dsftc-burst { text-shadow: 0 0 18px currentColor, 0 2px 0 rgba(0, 0, 0, 0.7); }
/* Compact HUD proportions: big combo digit, short left-aligned meter, multiplier under it. */
.dsftcu-overlay-bare .dsftc-head { grid-area: head; margin: 0 0 0.1em; gap: 0.3em; transform: translateY(-0.3em); }
.dsftcu-overlay-bare .dsftc-brand { font-size: 0.5em; letter-spacing: 0.12em; opacity: 0.82; }
.dsftcu-overlay-bare .dsftc-bword { font-size: 1.15em; }
.dsftcu-overlay-bare .dsftc-tier { display: none !important; }
.dsftcu-overlay-bare .dsftc-status { font-size: 0.5em; opacity: 0.85; }
.dsftcu-overlay-bare .dsftc-main { display: contents; }
.dsftcu-overlay-bare .dsftc-main > .dsftc-block:nth-child(1) { grid-area: combo; align-self: start; }
.dsftcu-overlay-bare .dsftc-main > .dsftc-block:nth-child(2) {
  grid-area: judge;
  justify-self: start;
  align-self: start;
  margin-top: 0.08em;
  text-align: left;
}
.dsftcu-overlay-bare .dsftc-main > .dsftc-side {
  grid-area: mult;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-self: start;
  align-self: start;
  text-align: left;
  margin-top: 0.12em;
  margin-left: 0.2em;
  gap: 0.22em;
}
.dsftcu-overlay[data-align="right"] .dsftc-main > .dsftc-side { align-items: flex-end; text-align: right; }
.dsftcu-overlay-bare .dsftc-ko {
  display: block;
  font-size: 0.85em;
  line-height: 1;
  margin: 0 0 0.12em;
  opacity: 0.95;
  text-shadow: 0 0 12px currentColor;
}
/* KO floats in the natural gap above the judgement: no reserved slot, no reflow. */
.dsftcu-overlay-bare .dsftc-arena-grok .dsftc-main > .dsftc-block:nth-child(2) {
  position: relative;
}
.dsftcu-overlay-bare .dsftc-arena-grok .dsftc-ko {
  position: absolute;
  top: -1.15em;
  left: 0;
  right: 0;
  margin: 0;
}
.dsftcu-overlay-bare .dsftc-art { display: none !important; }
.dsftcu-overlay-bare .dsftc-avatar { width: 1.35em; height: 1.35em; }
.dsftcu-overlay-bare .dsftc-num {
  padding: 0.22em 0.2em;
  margin: -0.22em -0.2em;
  font-size: 5.6em !important;
  line-height: 0.76 !important;
}
.dsftcu-overlay-bare .dsftc-num.dsftc-pop { animation-name: dsftc-hudpop; }
.dsftcu-overlay-bare .dsftc-cap { display: none !important; }
.dsftcu-overlay-bare .dsftc-judge { font-size: 0.9em; min-height: 0.7em; }
.dsftcu-overlay-bare .dsftc-mult { font-size: 1.75em !important; }
/* The duplicated damage line under the multiplier is already shown in the stats row. */
.dsftcu-overlay-bare .dsftc-fg-dmg { display: none !important; }
/* Fighting's K.O. flash sits inline to the right of the multiplier. */
.dsftcu-overlay-bare .dsftc-fg-ko {
  grid-area: ko;
  position: static !important;
  justify-self: start;
  align-self: start;
  margin-top: 0.1em;
  font-size: 1.2em;
}
@keyframes dsftc-hudpop {
  0% { transform: scale(1.12); }
  60% { transform: scale(0.99); }
  100% { transform: scale(1); }
}
@keyframes dsftc-hudside {
  0% { transform: translateX(0.55em) scale(1.09); }
  60% { transform: translateX(0.1em) scale(1.01); }
  100% { transform: translateX(0) scale(1); }
}
.dsftc-sidekick { animation: dsftc-hudside 0.2s cubic-bezier(0.2, 1.6, 0.4, 1) both; transform-origin: left top; }
.dsftcu-overlay-bare .dsftc-bar {
  grid-area: bar; justify-self: start; width: 9em !important;
  height: 0.18em; margin: 0.2em 0 0; opacity: 0.9;
  background: rgba(255, 255, 255, 0.07) !important;
  border: 0 !important;
  border-radius: 99px !important;
  overflow: hidden;
}
.dsftcu-overlay-bare .dsftc-bar-fill { border-radius: 99px !important; }
.dsftcu-overlay-bare .dsftc-stats { grid-area: stats; display: flex; gap: 0.55em; margin-top: 0.04em; justify-self: start; }
.dsftcu-overlay-bare .dsftc-stat:nth-child(n + 3) { display: none !important; }
.dsftcu-overlay-bare .dsftc-sv { font-size: 0.92em; }
.dsftcu-overlay-bare .dsftc-sk { font-size: 0.44em; opacity: 0.5; }
/* Preset bursts stay out of the HUD; the overlay owns one queued ticker under the stats. */
.dsftcu-overlay-bare .dsftc-burst { display: none !important; }
.dsftcu-overlay-burst {
  position: absolute;
  top: 100%;
  left: 0;
  right: 0;
  margin-top: 0.14em;
  font: 800 1em/1.15 Impact, "Arial Black", "Segoe UI Black", sans-serif;
  letter-spacing: 0.08em;
  white-space: nowrap;
  text-shadow: 0 0 12px currentColor, 0 2px 0 rgba(0, 0, 0, 0.6);
  animation: dsftcu-hudburst 0.95s ease-out both;
}
.dsftcu-overlay-burst-settle { color: #7ff0ff; }
.dsftcu-overlay-burst-break { color: #ff6a5a; }
.dsftcu-overlay-burst-milestone { color: #ffe45c; }
@keyframes dsftcu-hudburst {
  0% { opacity: 0; transform: translateY(0.4em) scale(0.82); }
  18% { opacity: 1; transform: translateY(0) scale(1.06); }
  70% { opacity: 1; transform: translateY(0) scale(1); }
  100% { opacity: 0; transform: translateY(0.3em) scale(0.98); }
}
.dsftcu-pill {
  position: absolute; z-index: 60; pointer-events: auto; cursor: pointer;
  display: inline-flex; align-items: baseline; gap: 7px; padding: 2px 4px; border: 0; background: transparent;
  color: #ffffff; font: 800 15px/1 Impact, "Arial Black", sans-serif; letter-spacing: 0.6px;
  text-shadow: 0 0 10px var(--dsw-alias-brand-primary, #7c6cff), 0 2px 0 rgba(0, 0, 0, 0.7);
  filter: drop-shadow(0 3px 8px rgba(0, 0, 0, 0.5));
}
.dsftcu-pill span { font: 600 10px/1 system-ui, sans-serif; letter-spacing: 0.8px; opacity: 0.8; }
/* Chat bar: one compact statistics control aligned with the shipped DSH pills. */
.dsftcu-dock { display: inline-flex; align-items: center; min-width: 0; pointer-events: auto; transition: opacity 220ms ease; }
.dsftcu-dock[data-live="false"] { opacity: 0.65; }
.dsftcu-dock[data-reduced="true"] { transition: none; }
.dsftcu-dock-pill {
  box-sizing: border-box;
  display: inline-flex; align-items: center; gap: 6px;
  padding: 1px 8px; border-radius: var(--dsw-radius-sm, 6px);
  background: transparent; border: 0; cursor: pointer;
  color: var(--dsw-alias-label-tertiary, #93a0ba);
  font: inherit;
  font-size: calc(var(--dsh-content-font-size-secondary, 13px) - 1px);
  line-height: calc(20px + var(--dsh-content-font-delta-secondary, 0px));
  font-variant-numeric: tabular-nums; white-space: nowrap;
  transition: background 140ms ease, color 140ms ease;
}
.dsftcu-dock-pill:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(255, 255, 255, 0.08)); color: var(--dsw-alias-label-secondary, #b8c2d8); }
.dsftcu-dock-pill:focus-visible { outline: 2px solid var(--dsw-alias-brand-primary, #8b7bff); outline-offset: 2px; }
.dsftcu-dock[data-live="true"] .dsftcu-dock-pill { color: var(--dsw-alias-label-secondary, #b8c2d8); }
.dsftcu-dock-dot { width: 6px; height: 6px; border-radius: 999px; flex: 0 0 auto; background: currentColor; }
.dsftcu-dock-combo { font-weight: 700; }
.dsftcu-dock-mult { font-weight: 600; }
.dsftcu-dock-tokens { opacity: 0.78; }
.dsftcu-dock-note { font-weight: 600; opacity: 0.78; }
.dsftcu-settings-block { display: flex; flex-direction: column; gap: 10px; pointer-events: auto; }
.dsftcu-settings-row { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 12px; padding: 11px 0; border-bottom: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.14)); }
.dsftcu-settings-row:last-child { border-bottom: 0; }
.dsftcu-settings-text { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.dsftcu-settings-name { font-weight: 650; font-size: 13px; }
.dsftcu-settings-desc { font-size: 11.5px; color: var(--dsw-alias-label-secondary, #aab6cf); }
.dsftcu-style-chips { display: inline-flex; gap: 6px; flex-wrap: wrap; }
.dsftcu-style-chip {
  appearance: none; cursor: pointer; border-radius: 999px; padding: 4px 10px; font: 600 11.5px/1.2 system-ui, sans-serif;
  border: 1px solid var(--dsw-alias-border-l1, rgba(130, 150, 210, 0.28));
  background: var(--dsw-alias-bg-layer-2, rgba(255, 255, 255, 0.05)); color: var(--dsw-alias-label-secondary, #b8c2d8);
}
.dsftcu-style-chip[data-active="true"] { color: #fff; border-color: transparent; background: linear-gradient(120deg, #7c4dff, #22b6ff); }
@keyframes dsftcu-bob { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-3px); } }
@keyframes dsftcu-glowpulse { 0%, 100% { filter: drop-shadow(0 0 2px currentColor); } 50% { filter: drop-shadow(0 0 7px currentColor); } }
@keyframes dsftcu-flash { 0% { opacity: 0; } 12% { opacity: 0.85; } 100% { opacity: 0; } }
.dsftcu-live-icon { animation: dsftcu-glowpulse 1.4s ease-in-out infinite; }
.dsftcu-live-icon[data-reduced="true"] { animation: none; }
/* Low-motion mode: core HUD animations and transitions must respect it too. */
.dsftcu-overlay[data-reduced="true"] .dsftcu-overlay-burst { animation: none; }
.dsftcu-overlay[data-reduced="true"] .dsftc-bar-fill { transition: none; }
.dsftcu-overlay[data-reduced="true"] .dsftc-sidekick,
.dsftcu-overlay[data-reduced="true"] .dsftc-num { animation: none !important; }
@media (prefers-reduced-motion: reduce) {
  .dsftcu-live-icon { animation: none !important; }
  .dsftcu-overlay-burst { animation: none !important; }
  .dsftc-bar-fill { transition: none !important; }
}
@media (max-width: 1200px) {
  .dsftcu-presets { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 900px) {
  .dsftcu-console { padding: 18px 16px 44px; }
  .dsftcu-stats { grid-template-columns: repeat(2, minmax(0, 1fr)); }
  .dsftcu-presets { grid-template-columns: 1fr; }
}
`;

// ---------------------------------------------------------------- small UI pieces

function Btn(props) {
  return h(
    'button',
    {
      type: 'button',
      className: 'dsftcu-btn',
      'data-variant': props.variant,
      'data-active': props.active === true ? 'true' : undefined,
      title: props.title,
      'aria-label': props.label || (typeof props.children === 'string' ? props.children : undefined),
      onClick: props.onClick,
      disabled: props.disabled === true,
      style: props.style,
    },
    props.children,
  );
}

function Toggle(props) {
  return h(
    'button',
    {
      type: 'button',
      role: 'switch',
      'aria-checked': props.on === true,
      'aria-label': props.label,
      title: props.label,
      className: 'dsftcu-toggle',
      'data-on': props.on === true ? 'true' : 'false',
      onClick: props.onToggle,
    },
    h('span', null),
  );
}

/**
 * Hotkey input: typing only updates local state; the value is committed on blur/Enter.
 * Committing per keystroke would register partially typed combos as global hotkeys.
 */
function HotkeyField(props) {
  const current = typeof props.value === 'string' ? props.value : '';
  const [draft, setDraft] = React.useState(current);
  const [editing, setEditing] = React.useState(false);
  React.useEffect(() => {
    if (editing) return;
    setDraft(current);
  }, [current, editing]);
  const commit = () => {
    setEditing(false);
    const next = String(draft).trim();
    if (next === '') {
      // Empty never commits: keep the existing binding.
      setDraft(current);
      return;
    }
    if (next !== current && typeof props.onCommit === 'function') props.onCommit(next);
  };
  return h('input', {
    className: 'dsftcu-input',
    type: 'text',
    value: draft,
    placeholder: props.placeholder || '',
    'aria-label': props.label,
    onFocus: () => setEditing(true),
    onChange: (event) => setDraft(event.target.value),
    onBlur: commit,
    onKeyDown: (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        commit();
      } else if (event.key === 'Escape') {
        event.preventDefault();
        setEditing(false);
        setDraft(current);
      }
    },
  });
}

function Segmented(props) {
  return h(
    'div',
    { className: 'dsftcu-seg', role: 'group', 'aria-label': props.label },
    props.options.map((option) =>
      h(
        'button',
        {
          key: option.id,
          type: 'button',
          'data-active': props.value === option.id ? 'true' : 'false',
          'aria-pressed': props.value === option.id,
          onClick: () => props.onChange(option.id),
        },
        option.label,
      ),
    ),
  );
}

function Slider(props) {
  return h('input', {
    className: 'dsftcu-slider',
    type: 'range',
    min: props.min,
    max: props.max,
    step: props.step,
    value: props.value,
    'aria-label': props.label,
    onChange: (event) => props.onChange(Number(event.target.value)),
  });
}

function ToneIcon(props) {
  const size = props.size || 16;
  if (props.on) {
    return h(
      'svg',
      { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', 'aria-hidden': true },
      h('path', { d: 'M4 9v6h4l5 4V5L8 9H4z', fill: 'currentColor' }),
      h('path', { d: 'M16.5 8.5a5 5 0 010 7M19 6a8.5 8.5 0 010 12', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' }),
    );
  }
  return h(
    'svg',
    { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', 'aria-hidden': true },
    h('path', { d: 'M4 9v6h4l5 4V5L8 9H4z', fill: 'currentColor' }),
    h('path', { d: 'M16 10l5 5M21 10l-5 5', stroke: 'currentColor', strokeWidth: 1.8, strokeLinecap: 'round' }),
  );
}

// ---------------------------------------------------------------- sidebar panel icon

function PanelIcon(props) {
  const ctx = props.ctx;
  const bridge = props.bridge;
  const locale = useLocale(ctx);
  const dict = dictFor(locale);
  const state = useBridgeSnapshot(bridge);
  const session = React.useMemo(() => selectSession(state.snapshot, null), [state.snapshot]);
  const live = session !== null && session !== undefined && (session.phase === 'building' || session.phase === 'holding');
  const prefs = usePrefs();
  const preset = presetOf(prefs.style);
  const size = typeof props.size === 'number' ? props.size : 18;
  const strong = props.active === true || live;
  return h(
    'span',
    {
      className: live ? 'dsftcu-live-icon' : undefined,
      'data-reduced': prefs.reduced === true ? 'true' : undefined,
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: size,
        height: size,
        color: strong ? preset.accent2 : 'currentColor',
        opacity: props.active === true ? 1 : 0.92,
        filter: strong ? `drop-shadow(0 0 5px ${preset.accent})` : 'none',
      },
      title: dict.panel,
    },
    h(
      'svg',
      { width: size, height: size, viewBox: '0 0 24 24', fill: 'none', 'aria-hidden': true },
      h('path', {
        d: 'M13.2 2.6 5.2 13.4h5l-1.4 7.6 8.4-11.2h-5.2l1.2-7.2z',
        fill: props.active === true || live ? 'currentColor' : 'none',
        stroke: 'currentColor',
        strokeWidth: 1.5,
        strokeLinejoin: 'round',
      }),
      h('circle', { cx: 19.4, cy: 4.6, r: 1.6, fill: live ? '#ffd84d' : 'currentColor', opacity: live ? 1 : 0.55 }),
    ),
  );
}

// ---------------------------------------------------------------- floating overlay

function Overlay(props) {
  const ctx = props.ctx;
  const bridge = props.bridge;
  const sfx = props.sfx;
  const prefs = usePrefs();
  const locale = useLocale(ctx);
  const dict = dictFor(locale);
  const combo = useCombo(props, bridge);
  const systemReduced = useSystemReduced();
  const reduced = prefs.reduced || systemReduced;
  useAudioDriver(combo, prefs, sfx);
  useAchievements(combo);
  const burstState = React.useRef({ ready: false, id: 0, milestoneSeq: 0, breakSeq: 0, settleSeq: 0 });
  const [burstQueue, setBurstQueue] = React.useState([]);
  const [burstCurrent, setBurstCurrent] = React.useState(null);
  React.useEffect(() => {
    const state = burstState.current;
    const seqs = {
      milestoneSeq: Number(combo.fx.milestoneSeq) || 0,
      breakSeq: Number(combo.fx.breakSeq) || 0,
      settleSeq: Number(combo.fx.settleSeq) || 0,
    };
    if (!state.ready) {
      state.ready = true;
      Object.assign(state, seqs);
      return;
    }
    const items = [];
    if (seqs.settleSeq > state.settleSeq) items.push({ kind: 'settle', text: '+ ' + formatTokens(combo.fx.tokens.turn) + ' ' + dict.burstSettle });
    if (seqs.breakSeq > state.breakSeq) items.push({ kind: 'break', text: dict.burstBreak });
    if (seqs.milestoneSeq > state.milestoneSeq) items.push({ kind: 'milestone', text: '\u2605 ' + formatTokens(combo.fx.milestone) + ' ' + dict.burstMilestone });
    Object.assign(state, seqs);
    if (items.length > 0) {
      for (const item of items) {
        state.id += 1;
        item.id = state.id;
      }
      const kinds = new Set(items.map((item) => item.kind));
      setBurstQueue((queue) => [...queue.filter((queued) => !kinds.has(queued.kind)), ...items]);
      setBurstCurrent((current) => {
        if (current === null) return current;
        const fresh = items.find((item) => item.kind === current.kind);
        return fresh || current;
      });
    }
  }, [combo.fx.milestoneSeq, combo.fx.breakSeq, combo.fx.settleSeq]);
  React.useEffect(() => {
    if (burstCurrent !== null || burstQueue.length === 0) return;
    setBurstCurrent(burstQueue[0]);
    setBurstQueue((queue) => queue.slice(1));
  }, [burstQueue, burstCurrent]);
  React.useEffect(() => {
    if (burstCurrent === null) return undefined;
    const timer = window.setTimeout(() => setBurstCurrent(null), 1100);
    return () => window.clearTimeout(timer);
  }, [burstCurrent]);
  const preset = presetOf(prefs.style);
  const scale = prefs.scale;
  const cardRef = React.useRef(null);
  const [pos, setPos] = React.useState(() => prefs.overlayPos);
  const [dragging, setDragging] = React.useState(false);
  const drag = React.useRef(null);
  const lastPos = React.useRef(null);

  React.useEffect(() => {
    setPos(prefs.overlayPos);
  }, [prefs.overlayPos]);

  React.useEffect(() => {
    if (pos === null) return undefined;
    const onResize = () => {
      const el = cardRef.current;
      if (el === null) return;
      const layer = el.offsetParent !== null ? el.offsetParent.getBoundingClientRect() : null;
      const card = el.getBoundingClientRect();
      const maxX = Math.max(8, (layer !== null ? layer.width : window.innerWidth) - card.width - 8);
      const maxY = Math.max(8, (layer !== null ? layer.height : window.innerHeight) - card.height - 8);
      setPos((current) => (current === null ? current : { x: clamp(current.x, 8, maxX), y: clamp(current.y, 8, maxY) }));
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [pos === null, scale]);

  // When the HUD grows (combo digits / stage tier changes), pull it back inside
  // the layer so a HUD parked at the right edge never overflows the screen.
  React.useEffect(() => {
    if (pos === null || dragging) return undefined;
    const element = cardRef.current;
    if (element === null || typeof ResizeObserver !== 'function') return undefined;
    const observer = new ResizeObserver(() => {
      const layerElement = element.offsetParent;
      if (layerElement === null) return;
      const layer = layerElement.getBoundingClientRect();
      const card = element.getBoundingClientRect();
      const maxX = Math.max(8, layer.width - card.width - 8);
      const maxY = Math.max(8, layer.height - card.height - 8);
      setPos((current) => (current === null ? current : { x: clamp(current.x, 8, maxX), y: clamp(current.y, 8, maxY) }));
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, [pos === null, dragging]);

  if (!prefs.overlayEnabled) return null;

  const live = combo.fx.running === true || combo.fx.phase === 'building' || combo.fx.phase === 'holding';
  const anchored = pos !== null ? { left: pos.x + 'px', top: pos.y + 'px' } : { right: '18px', bottom: '48px' };

  const startDrag = (event) => {
    const el = cardRef.current;
    if (el === null) return;
    event.preventDefault();
    const layerEl = el.offsetParent;
    const layer = layerEl !== null ? layerEl.getBoundingClientRect() : { left: 0, top: 0, width: window.innerWidth, height: window.innerHeight };
    const card = el.getBoundingClientRect();
    drag.current = {
      grabX: event.clientX - card.left,
      grabY: event.clientY - card.top,
      layer,
      width: card.width,
      height: card.height,
    };
    const next = { x: card.left - layer.left, y: card.top - layer.top };
    lastPos.current = next;
    setPos(next);
    setDragging(true);
    try {
      event.currentTarget.setPointerCapture(event.pointerId);
    } catch {
      /* ignore */
    }
  };
  const moveDrag = (event) => {
    const state = drag.current;
    if (state === null) return;
    const next = {
      x: clamp(event.clientX - state.grabX - state.layer.left, 8, Math.max(8, state.layer.width - state.width - 8)),
      y: clamp(event.clientY - state.grabY - state.layer.top, 8, Math.max(8, state.layer.height - state.height - 8)),
    };
    lastPos.current = next;
    setPos(next);
  };
  const endDrag = () => {
    if (drag.current === null) return;
    drag.current = null;
    setDragging(false);
    if (lastPos.current !== null) savePrefs({ overlayPos: lastPos.current });
  };

  const statusText = live ? dict.liveBadge : dict.idleBadge;

  if (prefs.overlayCollapsed) {
    return h(
      'button',
      {
        type: 'button',
        className: 'dsftcu-pill',
        ref: cardRef,
        style: anchored,
        title: dict.expand,
        'aria-label': dict.collapsed + ' ' + formatTokens(combo.fx.combo) + ' x' + String(combo.fx.multiplier),
        onClick: () => savePrefs({ overlayCollapsed: false }),
      },
      h('b', { style: { color: preset.accent2 } }, formatTokens(combo.fx.combo)),
      h('span', null, 'x' + String(combo.fx.multiplier)),
      h('span', { style: { color: preset.accent } }, statusText),
    );
  }

  return h(
    'div',
    {
      className: 'dsftcu-overlay dsftcu-overlay-bare',
      ref: cardRef,
      style: { ...anchored, width: Math.round(250 * scale) + 'px', maxWidth: 'calc(100vw - 16px)' },
      'data-dragging': dragging ? 'true' : 'false',
      'data-align': prefs.anchor,
      'data-reduced': reduced ? 'true' : 'false',
      'aria-label': dict.dragHint,
      title: dict.collapse,
      onDoubleClick: (event) => {
        // Double-click collapses the HUD to the small pill; the pill expands it.
        event.preventDefault();
        savePrefs({ overlayCollapsed: true });
      },
      onPointerDown: startDrag,
      onPointerMove: moveDrag,
      onPointerUp: endDrag,
      onPointerCancel: endDrag,
    },
    h(
      'div',
      { className: 'dsftcu-overlay-body' },
      h(preset.Arena, {
        fx: { ...combo.fx, now: Date.now() },
        compact: true,
        scale,
        reduced,
        locale,
        styleId: prefs.style,
      }),
      burstCurrent !== null
        ? h('div', { key: burstCurrent.id, className: 'dsftcu-overlay-burst dsftcu-overlay-burst-' + burstCurrent.kind }, burstCurrent.text)
        : null,
    ),
  );
}

// ---------------------------------------------------------------- composer dock bar

function DockBar(props) {
  const ctx = props.ctx;
  const bridge = props.bridge;
  const prefs = usePrefs();
  const locale = useLocale(ctx);
  const dict = dictFor(locale);
  // The dock is mounted inside one conversation composer, so select by the slot's own
  // session id instead of the globally focused session (multiple composers can coexist).
  const combo = useCombo(props, bridge, props.sessionId || null);
  const preset = presetOf(prefs.style);
  // Kept so this entry's hook order stays identical to earlier builds; the compact pill
  // only uses `reduced` to drop its opacity fade.
  const systemReduced = useSystemReduced();
  const reduced = prefs.reduced || systemReduced;
  if (!prefs.dockEnabled) return null;
  const fxState = combo.fx;
  const live = fxState.phase === 'building' || fxState.phase === 'holding' || fxState.running === true;
  // Match the shipped statistics pills: no line when there is nothing to report.
  if (fxState.phase === 'idle' && fxState.combo === 0 && fxState.running !== true) return null;
  const broken = fxState.phase === 'broken';
  const multiplier = trim1(Number(fxState.multiplier) || 1);
  const label =
    dict.panel +
    ' · ' +
    dict.combo +
    ' ' +
    formatTokens(fxState.combo) +
    ' · x' +
    multiplier +
    (live ? ' · ' + dict.tokens + ' ' + formatTokens(fxState.tokens.turn) : '') +
    (broken ? ' · ' + dict.burstBreak : '');
  return h(
    'div',
    {
      className: 'dsftcu-dock',
      'data-live': live ? 'true' : 'false',
      'data-reduced': reduced ? 'true' : undefined,
      'data-composer-stat': 'combo',
    },
    h(
      'button',
      {
        type: 'button',
        className: 'dsftcu-dock-pill',
        title: label,
        'aria-label': label,
        onClick: () => openConsole(ctx),
      },
      h('span', { className: 'dsftcu-dock-dot', style: { background: preset.accent2 }, 'aria-hidden': true }),
      h('b', { className: 'dsftcu-dock-combo' }, formatTokens(fxState.combo)),
      h('span', { className: 'dsftcu-dock-mult', style: { color: preset.accent2 } }, 'x' + multiplier),
      live ? h('span', { className: 'dsftcu-dock-tokens' }, formatTokens(fxState.tokens.turn)) : null,
      broken ? h('span', { className: 'dsftcu-dock-note' }, dict.burstBreak) : null,
    ),
  );
}

// ---------------------------------------------------------------- settings row

function SettingsRow(props) {
  const ctx = props.ctx;
  const prefs = usePrefs();
  const locale = useLocale(ctx);
  const dict = dictFor(locale);
  const styles = fx.PRESETS;
  const anchorOptions = [
    { id: 'left', label: dict.anchorLeft },
    { id: 'right', label: dict.anchorRight },
  ];
  const sfxOptions = [
    { id: 'rhythm', label: dict.sfxRhythm },
    { id: 'fighting', label: dict.sfxFighting },
    { id: 'arcade', label: dict.sfxArcade },
    { id: 'cyber', label: dict.sfxCyber },
    { id: 'auto', label: dict.sfxAuto },
  ];
  return h(
    'div',
    { className: 'dsftcu-settings-block' },
    h(
      'div',
      { className: 'dsftcu-settings-row' },
      h(
        'div',
        { className: 'dsftcu-settings-text' },
        h('span', { className: 'dsftcu-settings-name' }, dict.settingsTitle),
        h('span', { className: 'dsftcu-settings-desc' }, dict.settingsDesc),
      ),
      h(
        'div',
        { className: 'dsftcu-row' },
        h(
          'div',
          { className: 'dsftcu-style-chips' },
          styles.map((preset) =>
            h(
              'button',
              {
                key: preset.id,
                type: 'button',
                className: 'dsftcu-style-chip',
                'data-active': prefs.style === preset.id ? 'true' : 'false',
                onClick: () => savePrefs({ style: preset.id }),
              },
              preset.label[locale] || preset.label.zh,
            ),
          ),
        ),
        h(Btn, { onClick: () => openConsole(ctx) }, dict.openConsole),
      ),
    ),
    h(
      'div',
      { className: 'dsftcu-settings-row' },
      h(
        'div',
        { className: 'dsftcu-settings-text' },
        h('span', { className: 'dsftcu-settings-name' }, dict.settingsDisplay),
        h('span', { className: 'dsftcu-settings-desc' }, dict.displayHint),
      ),
      h(
        'div',
        { className: 'dsftcu-row' },
        h(
          'div',
          { className: 'dsftcu-display-switches' },
          h(
            'div',
            { className: 'dsftcu-switch' },
            h('span', { className: 'dsftcu-label' }, dict.overlayToggle),
            h(Toggle, {
              on: prefs.overlayEnabled,
              label: dict.overlayToggle,
              onToggle: () => savePrefs({ overlayEnabled: !prefs.overlayEnabled }),
            }),
          ),
          h(
            'div',
            { className: 'dsftcu-switch' },
            h('span', { className: 'dsftcu-label' }, dict.dockToggle),
            h(Toggle, {
              on: prefs.dockEnabled,
              label: dict.dockToggle,
              onToggle: () => savePrefs({ dockEnabled: !prefs.dockEnabled }),
            }),
          ),
          h(
            'div',
            { className: 'dsftcu-switch' },
            h('span', { className: 'dsftcu-label' }, dict.settingsSound),
            h(Toggle, {
              on: prefs.sound,
              label: dict.sound,
              onToggle: () => savePrefs({ sound: !prefs.sound }),
            }),
          ),
        ),
      ),
    ),
    h(
      'div',
      { className: 'dsftcu-settings-row' },
      h(
        'div',
        { className: 'dsftcu-settings-text' },
        h('span', { className: 'dsftcu-settings-name' }, dict.anchor),
        h('span', { className: 'dsftcu-settings-desc' }, dict.anchorHint),
      ),
      h(
        'div',
        { className: 'dsftcu-row' },
        h(Segmented, {
          options: anchorOptions,
          value: prefs.anchor,
          label: dict.anchor,
          onChange: (value) => savePrefs({ anchor: value }),
        }),
      ),
    ),
    h(
      'div',
      { className: 'dsftcu-settings-row' },
      h(
        'div',
        { className: 'dsftcu-settings-text' },
        h('span', { className: 'dsftcu-settings-name' }, dict.sfxStyle),
        h('span', { className: 'dsftcu-settings-desc' }, dict.sfxHint),
      ),
      h(
        'div',
        { className: 'dsftcu-row' },
        h(Segmented, {
          options: sfxOptions,
          value: prefs.sfxStyle,
          label: dict.sfxStyle,
          onChange: (value) => savePrefs({ sfxStyle: value }),
        }),
      ),
    ),
    h(
      'div',
      { className: 'dsftcu-settings-row' },
      h(
        'div',
        { className: 'dsftcu-settings-text' },
        h('span', { className: 'dsftcu-settings-name' }, dict.desktopHud),
        h('span', { className: 'dsftcu-settings-desc' }, dict.desktopHudHint),
      ),
      h(
        'div',
        { className: 'dsftcu-row' },
        h(Toggle, {
          on: prefs.desktopHud,
          label: dict.desktopHud,
          onToggle: () => savePrefs({ desktopHud: !prefs.desktopHud }),
        }),
        prefs.desktopHud
          ? h(Toggle, {
              on: prefs.desktopHudInteractive,
              label: dict.desktopHudInteractive,
              onToggle: () => savePrefs({ desktopHudInteractive: !prefs.desktopHudInteractive }),
            })
          : null,
      ),
    ),
  );
}

function useDemoStream(active, sfx, styleId, muted) {
  const config = React.useRef({ sfx, styleId, muted });
  config.current = { sfx, styleId, muted };
  const [state, setState] = React.useState(() => idleFx());
  React.useEffect(() => {
    if (active !== true) {
      setState(idleFx());
      return undefined;
    }
    let live = {
      ...idleFx(),
      running: true,
      phase: 'building',
      turn: 1,
      step: 1,
      startedAt: Date.now(),
      lastHitAt: Date.now(),
      tokens: { turn: 0, live: 0, output: 0, total: 0 },
    };
    let phaseAt = Date.now();
    const timer = window.setInterval(() => {
      const now = Date.now();
      if (live.phase === 'settled' || live.phase === 'broken') {
        if (now - phaseAt > 2200) {
          live = { ...live, phase: 'building', combo: 0, hits: 0, level: 1, energy: 0, lastHitAt: now, tokens: { ...live.tokens, live: 0 } };
        } else {
          setState({ ...live, now });
          return;
        }
      }
      // Drain the stage meter while nothing new arrives. Emptying it drops one
      // multiplier step (meter refills for that step); the lowest step breaks.
      // Only a non-empty meter drains: after a level-up energy is 0, and draining
      // then would instantly drop the just-earned step (mirrors the Host guard).
      if (live.energy > 0) {
        live.energy = Math.max(0, live.energy - 95 / 5000);
        if (live.combo > 0 && live.energy <= 0) {
          if (live.level > 1) {
            live.level -= 1;
            live.energy = 1;
            const level = LEVELS[live.level - 1];
            live.multiplier = level.multiplier;
            live.tier = level.tier;
            live.nextLevelAt = nextLevelAt(live.combo);
            setState({ ...live, now });
            return;
          }
          live.phase = 'broken';
          live.combo = 0;
          live.level = 1;
          live.energy = 0;
          live.breakSeq += 1;
          live.milestone = 0;
          phaseAt = now;
          try {
            if (config.current.muted !== true && config.current.sfx) {
              config.current.sfx.breakCombo({ presetId: config.current.styleId });
            }
          } catch {
            /* ignore */
          }
          setState({ ...live, now });
          return;
        }
      }
      const bursts = 1 + Math.floor(Math.random() * 3);
      let milestone = null;
      for (let index = 0; index < bursts; index += 1) {
        const chars = 1 + Math.floor(Math.random() * 16);
        const estimated = Math.max(1, Math.round(chars / 3));
        const previousCombo = live.combo;
        live.combo += 1;
        live.hits += 1;
        live.hitSeq += 1;
        live.tokens.live += estimated;
        live.lastHitAt = now;
        const spec = LEVELS[Math.min(LEVELS.length, Math.max(1, live.level)) - 1];
        live.score += estimated * spec.multiplier;
        if (live.level < LEVELS.length) {
          const next = LEVELS[live.level];
          const need = Math.max(1, next.at - spec.at);
          live.energy = Math.min(1, live.energy + 1 / need);
          if (live.energy >= 1 - 1e-6) {
            live.level += 1;
            live.energy = 0;
          }
        } else {
          live.energy = 1;
        }
        const level = LEVELS[Math.min(LEVELS.length, live.level) - 1];
        live.multiplier = level.multiplier;
        live.tier = level.tier;
        live.nextLevelAt = nextLevelAt(live.combo);
        const crossed = highestMilestone(previousCombo, live.combo);
        if (crossed !== null) {
          milestone = crossed;
          live.milestone = crossed;
          live.milestoneSeq += 1;
        }
      }
      live.tokens.turn = live.tokens.output + live.tokens.live;
      live.tokens.total = live.tokens.turn;
      live.maxCombo = Math.max(live.maxCombo, live.combo);
      live.bestCombo = Math.max(live.bestCombo, live.combo);
      const audio = config.current;
      try {
        if (audio.muted !== true && audio.sfx) {
          if (milestone !== null) audio.sfx.milestone({ presetId: audio.styleId, level: live.level });
          else audio.sfx.hit({ presetId: audio.styleId, level: live.level });
        }
      } catch {
        /* ignore */
      }
      if (Math.random() < 0.012) {
        live.phase = 'settled';
        live.settleSeq += 1;
        live.energy = 0;
        phaseAt = now;
        try {
          if (config.current.muted !== true && config.current.sfx) {
            config.current.sfx.settle({ presetId: config.current.styleId, combo: live.combo });
          }
        } catch {
          /* ignore */
        }
      }
      setState({ ...live, now });
    }, 95);
    return () => window.clearInterval(timer);
  }, [active]);
  return active === true ? state : null;
}

// ---------------------------------------------------------------- combo console page

function StatCell(props) {
  return h(
    'div',
    { className: 'dsftcu-stat' },
    h('div', { className: 'dsftcu-stat-label' }, props.label),
    h('div', { className: 'dsftcu-stat-value', style: props.color ? { color: props.color } : undefined }, props.value),
    props.sub ? h('div', { className: 'dsftcu-stat-sub', title: props.sub }, props.sub) : null,
  );
}

function ConsolePage(props) {
  const ctx = props.ctx;
  const bridge = props.bridge;
  const sfx = props.sfx;
  const prefs = usePrefs();
  const stats = useStats();
  const locale = useLocale(ctx);
  const dict = dictFor(locale);
  const combo = useCombo(props, bridge);
  const systemReduced = useSystemReduced();
  const reduced = prefs.reduced || systemReduced;
  const [trial, setTrial] = React.useState(false);
  const [resetArm, setResetArm] = React.useState(0);
  const resetTimer = React.useRef(null);
  React.useEffect(
    () => () => {
      if (resetTimer.current !== null) {
        window.clearTimeout(resetTimer.current);
        resetTimer.current = null;
      }
    },
    [],
  );
  const demo = useDemoStream(trial, sfx, sfxPresetId(prefs), prefs.sound !== true);
  const preset = presetOf(prefs.style);
  const active = trial ? demo || idleFx() : combo.fx;
  const live = active.phase === 'building' || active.phase === 'holding' || (combo.connected && combo.session && combo.session.running === true);
  const layout = getLayout(ctx);
  const canBack = layout !== null;

  const anchorOptions = [
    { id: 'left', label: dict.anchorLeft },
    { id: 'right', label: dict.anchorRight },
  ];
  const sfxOptions = [
    { id: 'rhythm', label: dict.sfxRhythm },
    { id: 'fighting', label: dict.sfxFighting },
    { id: 'arcade', label: dict.sfxArcade },
    { id: 'cyber', label: dict.sfxCyber },
    { id: 'auto', label: dict.sfxAuto },
  ];

  const statusText = !combo.connected
    ? dict.offline
    : active.phase === 'building' || active.phase === 'holding'
      ? dict.building
      : active.phase === 'settled'
        ? dict.settled
        : active.phase === 'broken'
          ? dict.broken
          : dict.waiting;

  const doReset = () => {
    if (resetArm === 0) {
      setResetArm(Date.now());
      if (resetTimer.current !== null) window.clearTimeout(resetTimer.current);
      resetTimer.current = window.setTimeout(() => {
        resetTimer.current = null;
        setResetArm(0);
      }, 3200);
      return;
    }
    setResetArm(0);
    if (resetTimer.current !== null) {
      window.clearTimeout(resetTimer.current);
      resetTimer.current = null;
    }
    try {
      resetStats();
    } catch {
      /* ignore */
    }
    bridge.reset().catch(() => {
      /* reset is best-effort */
    });
  };

  return h(
    'div',
    { className: 'dsftcu-console', 'data-reduced': reduced ? 'true' : 'false' },
    h(
      'div',
      { className: 'dsftcu-inner' },
      h(
        'div',
        { className: 'dsftcu-head' },
        h(
          'div',
          null,
          h(
            'div',
            { className: 'dsftcu-brandline' },
            h('div', { className: 'dsftcu-logo', 'aria-hidden': 'true' }, 'TC'),
            h(
              'div',
              null,
              h('h1', { className: 'dsftcu-title' }, dict.brand + ' · ' + dict.panel),
              h('p', { className: 'dsftcu-sub' }, dict.subtitle),
            ),
          ),
        ),
        h(
          'div',
          { className: 'dsftcu-row' },
          h(
            'span',
            { className: 'dsftcu-chip', 'data-live': combo.connected ? 'true' : 'false' },
            h('span', { className: 'dsftcu-dot' }),
            (combo.connected ? dict.live : dict.offline) + ' · ' + statusText,
          ),
          h(
            'span',
            { className: 'dsftcu-chip' },
            dict.currentStyle + ': ' + (preset.label[locale] || preset.label.zh),
          ),
          canBack ? h(Btn, { onClick: () => backToChat(ctx) }, dict.backToChat) : null,
        ),
      ),
      h(
        'div',
        { className: 'dsftcu-card dsftcu-arena-card' },
        h(
          'div',
          { className: 'dsftcu-arena-toolbar' },
          h(
            'div',
            { className: 'dsftcu-row' },
            h('span', { className: 'dsftcu-label' }, preset.label[locale] || preset.label.zh),
            h('span', { className: 'dsftcu-muted' }, preset.hint[locale] || preset.hint.zh),
            trial ? h('span', { className: 'dsftcu-chip', 'data-live': 'true' }, dict.demoBanner) : null,
          ),
          h(
            'div',
            { className: 'dsftcu-row' },
            h(
              Btn,
              {
                variant: trial ? 'primary' : undefined,
                active: trial,
                onClick: () => setTrial((value) => !value),
                title: dict.trialHint,
              },
              trial ? dict.trialOn : dict.trial,
            ),
            h(
              Btn,
              { onClick: () => savePrefs({ sound: !prefs.sound }), title: dict.soundHint },
              h(ToneIcon, { size: 14, on: prefs.sound }),
              prefs.sound ? dict.on : dict.off,
            ),
            h(
              Btn,
              {
                variant: resetArm !== 0 ? 'danger' : undefined,
                onClick: doReset,
                title: dict.reset,
              },
              resetArm !== 0 ? dict.resetConfirm : dict.reset,
            ),
          ),
        ),
        h(
          'div',
          { className: 'dsftcu-arena-body' },
          h(preset.Arena, {
            fx: { ...active, now: Date.now() },
            compact: false,
            scale: 1,
            reduced,
            locale,
            styleId: prefs.style,
          }),
        ),
      ),
      h(
        'div',
        { className: 'dsftcu-stats' },
        h(StatCell, {
          label: dict.combo,
          value: groupInt(active.combo),
          sub: dict.maxCombo + ' ' + groupInt(Math.max(active.maxCombo, active.bestCombo)),
          color: preset.accent2,
        }),
        h(StatCell, {
          label: dict.multiplier,
          value: 'x' + String(active.multiplier),
          sub: (active.nextLevelAt === null ? dict.levels : dict.nextTier + ' ' + active.nextLevelAt) + ' · ' + active.tier,
          color: preset.accent3,
        }),
        h(StatCell, {
          label: dict.tokens,
          value: formatTokens(active.tokens.turn),
          sub: dict.statTotal + ' ' + formatTokens(active.tokens.total),
          color: preset.accent,
        }),
        h(StatCell, {
          label: dict.score,
          value: groupInt(active.score),
          sub: dict.best + ' ' + groupInt(Math.max(stats.bestCombo, active.bestCombo)),
        }),
      ),
      h(
        'div',
        { className: 'dsftcu-section' },
        h(
          'div',
          { className: 'dsftcu-section-head' },
          h('span', { className: 'dsftcu-section-title' }, dict.styles),
          h('span', { className: 'dsftcu-section-hint' }, dict.stylesHint),
        ),
        h(
          'div',
          { className: 'dsftcu-presets' },
          fx.PRESETS.map((item) =>
            h(
              'button',
              {
                key: item.id,
                type: 'button',
                className: 'dsftcu-preset',
                'data-active': prefs.style === item.id ? 'true' : 'false',
                onClick: () => {
                  savePrefs({ style: item.id });
                  try {
                    sfx.unlock();
                    if (prefs.sound) sfx.hit({ presetId: item.id, level: 3 });
                  } catch {
                    /* ignore */
                  }
                },
                'aria-pressed': prefs.style === item.id,
              },
              h('div', { className: 'dsftcu-preset-preview' }, h(item.Preview, { locale })),
              h(
                'div',
                { className: 'dsftcu-preset-meta' },
                h('span', { className: 'dsftcu-preset-name' }, item.label[locale] || item.label.zh),
                prefs.style === item.id ? h('span', { className: 'dsftcu-preset-check' }, 'ACTIVE') : null,
              ),
              h('span', { className: 'dsftcu-preset-hint' }, item.hint[locale] || item.hint.zh),
            ),
          ),
        ),
      ),
      h(
        'div',
        { className: 'dsftcu-section' },
        h(
          'div',
          { className: 'dsftcu-section-head' },
          h('span', { className: 'dsftcu-section-title' }, dict.display),
          h('span', { className: 'dsftcu-section-hint' }, dict.displayHint),
        ),
        h(
          'div',
          { className: 'dsftcu-card dsftcu-settings-card' },
          h(
            'div',
            { className: 'dsftcu-display-switches' },
            h(
              'div',
              { className: 'dsftcu-switch' },
              h('span', { className: 'dsftcu-label' }, dict.overlayToggle),
              h(Toggle, {
                on: prefs.overlayEnabled,
                label: dict.overlayToggle,
                onToggle: () => savePrefs({ overlayEnabled: !prefs.overlayEnabled }),
              }),
            ),
            h(
              'div',
              { className: 'dsftcu-switch' },
              h('span', { className: 'dsftcu-label' }, dict.dockToggle),
              h(Toggle, {
                on: prefs.dockEnabled,
                label: dict.dockToggle,
                onToggle: () => savePrefs({ dockEnabled: !prefs.dockEnabled }),
              }),
            ),
            h(
              'div',
              { className: 'dsftcu-switch' },
              h('span', { className: 'dsftcu-label' }, dict.desktopHud),
              h(Toggle, {
                on: prefs.desktopHud,
                label: dict.desktopHud,
                onToggle: () => savePrefs({ desktopHud: !prefs.desktopHud }),
              }),
            ),
          ),
          h('div', { className: 'dsftcu-muted dsftcu-display-hint' }, dict.displayIndependentHint),
          h(
            'div',
            { className: 'dsftcu-settings-line' },
            h('span', { className: 'dsftcu-label' }, dict.anchor),
            h(Segmented, {
              options: anchorOptions,
              value: prefs.anchor,
              label: dict.anchor,
              onChange: (value) => savePrefs({ anchor: value }),
            }),
            h('span', { className: 'dsftcu-muted' }, dict.anchorHint),
            prefs.overlayEnabled
              ? h(
                  Btn,
                  {
                    onClick: () => savePrefs({ overlayPos: null, overlayCollapsed: false }),
                    title: dict.resetPosition,
                  },
                  dict.resetPosition,
                )
              : null,
          ),
          prefs.desktopHud
            ? h('div', { className: 'dsftcu-settings-line' }, h('span', { className: 'dsftcu-muted' }, dict.desktopHudHint))
            : null,
          prefs.desktopHud
            ? h(
                'div',
                { className: 'dsftcu-settings-line' },
                h('span', { className: 'dsftcu-label' }, dict.desktopHudInteractive),
                h(Toggle, {
                  on: prefs.desktopHudInteractive,
                  label: dict.desktopHudInteractive,
                  onToggle: () => savePrefs({ desktopHudInteractive: !prefs.desktopHudInteractive }),
                }),
                h('span', { className: 'dsftcu-muted' }, dict.desktopHudInteractiveHint),
              )
            : null,
          prefs.desktopHud
            ? h(
                'div',
                { className: 'dsftcu-settings-line' },
                h('span', { className: 'dsftcu-label' }, dict.hudHotkeys),
                h(Toggle, {
                  on: prefs.hudHotkeysEnabled,
                  label: dict.hudHotkeys,
                  onToggle: () => savePrefs({ hudHotkeysEnabled: !prefs.hudHotkeysEnabled }),
                }),
                h('span', { className: 'dsftcu-muted' }, dict.hudHotkeysHint),
              )
            : null,
          prefs.desktopHud && prefs.hudHotkeysEnabled
            ? h(
                'div',
                { className: 'dsftcu-settings-line' },
                h('span', { className: 'dsftcu-label' }, dict.hudHotkeyToggle),
                h(HotkeyField, {
                  value: prefs.hudHotkeyToggle,
                  label: dict.hudHotkeyToggle,
                  placeholder: dict.hudHotkeyPlaceholder,
                  onCommit: (value) => savePrefs({ hudHotkeyToggle: value }),
                }),
                h('span', { className: 'dsftcu-label' }, dict.hudHotkeyClose),
                h(HotkeyField, {
                  value: prefs.hudHotkeyClose,
                  label: dict.hudHotkeyClose,
                  placeholder: dict.hudHotkeyPlaceholder,
                  onCommit: (value) => savePrefs({ hudHotkeyClose: value }),
                }),
              )
            : null,
          prefs.desktopHud
            ? h('div', { className: 'dsftcu-settings-line' }, h('span', { className: 'dsftcu-muted' }, dict.desktopHudHotkey))
            : null,
          h(
            'div',
            { className: 'dsftcu-settings-line' },
            h('span', { className: 'dsftcu-label' }, dict.scale),
            h(Slider, {
              min: 0.8,
              max: 2.4,
              step: 0.05,
              value: prefs.scale,
              label: dict.scale,
              onChange: (value) => savePrefs({ scale: value }),
            }),
            h('span', { className: 'dsftcu-value' }, Math.round(prefs.scale * 100) + '%'),
          ),
          h(
            'div',
            { className: 'dsftcu-settings-line' },
            h('span', { className: 'dsftcu-label' }, dict.sound),
            h(Toggle, {
              on: prefs.sound,
              label: dict.sound,
              onToggle: () => savePrefs({ sound: !prefs.sound }),
            }),
            h('span', { className: 'dsftcu-muted' }, dict.soundHint),
          ),
          h(
            'div',
            { className: 'dsftcu-settings-line' },
            h('span', { className: 'dsftcu-label' }, dict.sfxStyle),
            h(Segmented, {
              options: sfxOptions,
              value: prefs.sfxStyle,
              label: dict.sfxStyle,
              onChange: (value) => {
                savePrefs({ sfxStyle: value });
                try {
                  if (prefs.sound) {
                    sfx.unlock();
                    sfx.hit({ presetId: value === 'auto' ? prefs.style : value, level: 3 });
                  }
                } catch {
                  /* preview is best-effort */
                }
              },
            }),
            h('span', { className: 'dsftcu-muted' }, dict.sfxHint),
          ),
          h(
            'div',
            { className: 'dsftcu-settings-line' },
            h('span', { className: 'dsftcu-label' }, dict.volume),
            h(Slider, {
              min: 0,
              max: 1,
              step: 0.05,
              value: prefs.volume,
              label: dict.volume,
              onChange: (value) => savePrefs({ volume: value }),
            }),
            h('span', { className: 'dsftcu-value' }, Math.round(prefs.volume * 100) + '%'),
          ),
          h(
            'div',
            { className: 'dsftcu-settings-line' },
            h('span', { className: 'dsftcu-label' }, dict.reduced),
            h(Toggle, {
              on: prefs.reduced,
              label: dict.reduced,
              onToggle: () => savePrefs({ reduced: !prefs.reduced }),
            }),
            h('span', { className: 'dsftcu-muted' }, dict.reducedHint),
          ),
        ),
      ),
      h(
        'div',
        { className: 'dsftcu-section' },
        h(
          'div',
          { className: 'dsftcu-section-head' },
          h('span', { className: 'dsftcu-section-title' }, dict.rules),
          h('span', { className: 'dsftcu-section-hint' }, dict.levels + ': ' + dict.atCombo + ' / ' + dict.multiplier),
        ),
        h(
          'div',
          { className: 'dsftcu-card dsftcu-settings-card' },
          h(
            'div',
            { className: 'dsftcu-levels' },
            LEVELS.map((level) =>
              h(
                'span',
                { key: level.at, className: 'dsftcu-level' },
                h('b', null, level.tier),
                h('span', null, level.at + '+ → x' + String(level.multiplier)),
              ),
            ),
          ),
          h(
            'ul',
            { className: 'dsftcu-rulelist' },
            h('li', null, dict.ruleHit),
            h('li', null, dict.ruleBreak),
            h('li', null, dict.ruleBank),
            h('li', null, dict.ruleAudio),
          ),
          h(
            'div',
            { className: 'dsftcu-row-between' },
            h(
              'span',
              { className: 'dsftcu-muted' },
              dict.best + ': ' + groupInt(stats.bestCombo) + ' · ' + dict.multiplier + ' x' + String(stats.bestMultiplier),
            ),
            h('span', { className: 'dsftcu-muted' }, dict.syncNote),
          ),
        ),
      ),
      h(
        'div',
        { className: 'dsftcu-footer' },
        h('span', null, dict.footer),
        h('span', null, (trial ? dict.trialOn : combo.connected ? dict.live : dict.offline) + ' · rev ' + String(combo.revision)),
      ),
    ),
  );
}

// ---------------------------------------------------------------- plugin body

function createSoundEngine() {
  try {
    const engine = new fx.SfxEngine();
    return engine;
  } catch {
    return {
      sync() {},
      unlock() {},
      hit() {},
      milestone() {},
      breakCombo() {},
      settle() {},
      dispose() {},
    };
  }
}

function apply(ctx) {
  const bridge = createBridge(ctx);
  ctx.effect(() => () => bridge.dispose(), 'token-combo: host bridge');

  // True once a snapshot reported the desktop HUD as open. An observed open→closed
  // transition means the user (Ctrl+Alt+X) or a crash closed it, so settings changes
  // must not silently reopen it afterwards.
  let hudSawOpen = false;

  ctx.effect(() => {
    // Last HUD request sent from this client: null | 'close' | 'open'.
    let last = null;
    // The Host owns the HUD page; it needs the live locale (no hardcoded 'zh') plus
    // the hotkey bindings and scale/alignment on every open/prefs ping.
    const hudPrefsPayload = (prefs) => ({
      style: prefs.style,
      scale: prefs.scale,
      align: prefs.anchor,
      locale: readLocale(ctx),
      hotkeysEnabled: prefs.hudHotkeysEnabled,
      hotkeyToggle: prefs.hudHotkeyToggle,
      hotkeyClose: prefs.hudHotkeyClose,
    });
    const push = () => {
      const prefs = getPrefs();
      const payload = {
        interactive: prefs.desktopHudInteractive !== true,
        prefs: hudPrefsPayload(prefs),
      };
      if (!prefs.desktopHud) {
        // Only ask the Host to close when the previous request opened it.
        if (last === 'open') {
          last = 'close';
          void callHost(ctx, 'hud', { action: 'close', ...payload });
        } else {
          last = null;
        }
        return;
      }
      if (last === 'open') {
        // Already open: prefs changes are live updates, never a second open.
        void callHost(ctx, 'hud', { action: 'prefs', ...payload });
        return;
      }
      last = 'open';
      hudSawOpen = false;
      const result = callHost(ctx, 'hud', { action: 'open', ...payload });
      if (result) {
        void result.then((value) => {
          if (value && (value.open !== true || value.webview2 === false)) {
            // WebView2 missing or the spawn failed: fall back to the in-window overlay.
            if (getPrefs().desktopHud) savePrefs({ desktopHud: false, overlayEnabled: true });
            last = null;
          }
        });
      }
    };
    push();
    const disposePrefs = subscribePrefs(push);
    let disposeLocale = null;
    try {
      if (ctx.locale && typeof ctx.locale.subscribe === 'function') disposeLocale = ctx.locale.subscribe(push);
    } catch {
      disposeLocale = null;
    }
    return () => {
      try {
        disposePrefs();
      } catch {
        /* ignore */
      }
      try {
        if (typeof disposeLocale === 'function') disposeLocale();
      } catch {
        /* ignore */
      }
    };
  }, 'token-combo: desktop hud');

  // Reconcile client prefs with the Host's real HUD state (`snapshot.hud`), tolerating
  // snapshots without it so older Hosts keep working. `hud.open === true` also syncs the
  // click-through flag (Host says interactive; client stores its inverse).
  ctx.effect(
    () =>
      bridge.subscribe(() => {
        const state = bridge.getState();
        const snapshot = state !== null && typeof state === 'object' ? state.snapshot : null;
        const hud = snapshot !== null && typeof snapshot === 'object' ? snapshot.hud : null;
        if (hud === null || typeof hud !== 'object') return;
        const prefs = getPrefs();
        if (hud.open === true) {
          hudSawOpen = true;
          if (prefs.desktopHud && typeof hud.interactive === 'boolean') {
            const interactive = prefs.desktopHudInteractive !== true;
            if (hud.interactive !== interactive) savePrefs({ desktopHudInteractive: !hud.interactive });
          }
          return;
        }
        if (hud.open === false && hudSawOpen && prefs.desktopHud) {
          // The HUD closed outside the settings UI; drop the pref instead of reopening it.
          hudSawOpen = false;
          savePrefs({ desktopHud: false });
        }
      }),
    'token-combo: desktop hud reconcile',
  );

  // Cross-window sync: every DSH window shares localStorage. Drop the caches on a
  // foreign write and notify the subscribers so all windows agree.
  ctx.effect(() => {
    const onStorage = (event) => {
      const key = event !== null && typeof event === 'object' ? event.key : null;
      if (key === PREFS_KEY) {
        prefsCache = null;
        for (const listener of [...prefsListeners]) {
          try {
            listener();
          } catch {
            /* ignore */
          }
        }
        return;
      }
      if (key === STATS_KEY) {
        statsCache = null;
        statsDirty = false;
        clearStatsWriteTimer();
        for (const listener of [...statsListeners]) {
          try {
            listener();
          } catch {
            /* ignore */
          }
        }
      }
    };
    window.addEventListener('storage', onStorage);
    return () => window.removeEventListener('storage', onStorage);
  }, 'token-combo: storage sync');

  // The stats write is debounced; flush it before the page is hidden or unloaded.
  ctx.effect(() => {
    const flush = () => {
      try {
        flushStats();
      } catch {
        /* ignore */
      }
    };
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') flush();
    };
    window.addEventListener('pagehide', flush);
    document.addEventListener('visibilitychange', onVisibility);
    return () => {
      window.removeEventListener('pagehide', flush);
      document.removeEventListener('visibilitychange', onVisibility);
      flush();
      clearStatsWriteTimer();
    };
  }, 'token-combo: stats flush');

  const sfx = createSoundEngine();

  ctx.effect(() => {
    const unlock = () => {
      try {
        sfx.unlock();
      } catch {
        /* ignore */
      }
    };
    window.addEventListener('pointerdown', unlock, { passive: true });
    window.addEventListener('keydown', unlock);
    return () => {
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
    };
  }, 'token-combo: audio unlock');

  ctx.effect(() => {
    const element = document.createElement('style');
    element.setAttribute('data-dsh-token-combo', '');
    const presetCss = fx.PRESETS.map((preset) => (typeof preset.css === 'string' ? preset.css : '')).join('\n');
    element.textContent = presetCss + '\n' + CORE_CSS;
    document.head.appendChild(element);
    return () => {
      try {
        element.remove();
      } catch {
        /* ignore */
      }
    };
  }, 'token-combo: styles');

  ctx.effect(() => () => {
    try {
      sfx.dispose();
    } catch {
      /* ignore */
    }
  }, 'token-combo: audio dispose');

  ctx.slots.inject('sidebar.panellist', () =>
    ctx.slots.register(
      {
        name: 'sidebar.panellist',
        id: PANEL_ID,
        order: 20,
        label: () => dictFor(readLocale(ctx)).panel,
      },
      (props) => h(PanelIcon, { ...props, ctx, bridge }),
    ),
  );

  ctx.slots.inject('main', () =>
    ctx.slots.register(
      { name: 'main', key: PANEL_ID },
      (props) => h(ConsolePage, { ...props, ctx, bridge, sfx }),
    ),
  );

  ctx.slots.inject('shell.overlay', () =>
    ctx.slots.register(
      {
        name: 'shell.overlay',
        id: 'combo.overlay',
        order: 80,
        label: () => 'Token Combo',
      },
      (props) => h(Overlay, { ...props, ctx, bridge, sfx }),
    ),
  );

  ctx.slots.inject('conversation.composer.dock', () =>
    ctx.slots.register(
      {
        name: 'conversation.composer.dock',
        id: 'combo.dock',
        order: 4,
      },
      (props) => h(DockBar, { ...props, ctx, bridge }),
    ),
  );

  ctx.slots.inject('settings.general.item', () =>
    ctx.slots.register(
      {
        name: 'settings.general.item',
        id: 'combo.settings',
        order: 88,
        label: () => dictFor(readLocale(ctx)).settingsTitle,
      },
      (props) => h(SettingsRow, { ...props, ctx, bridge }),
    ),
  );

  // First-run showcase: open the arena once so the plugin introduces itself.
  ctx.effect(() => {
    const key = 'dsh-token-combo:welcomed:v4';
    const timers = [];
    const attempt = (remaining) => {
      timers.push(
        window.setTimeout(() => {
          try {
            if (window.localStorage.getItem(key) === '1') return;
            if (openConsole(ctx)) {
              window.localStorage.setItem(key, '1');
              return;
            }
          } catch {
            /* ignore */
          }
          if (remaining > 0) attempt(remaining - 1);
        }, 1600),
      );
    };
    attempt(2);
    return () => {
      for (const timer of timers) window.clearTimeout(timer);
    };
  }, 'token-combo: first run');
}

exports.inject = ['connection', 'slots', 'locale'];
exports.apply = apply;



