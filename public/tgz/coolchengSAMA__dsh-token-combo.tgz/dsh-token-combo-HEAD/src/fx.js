/* =====================================================================
 * Token Combo - character preset visuals (7 AI mascots) and
 * WebAudio SFX. Plain browser script: defines global.createComboFx(React)
 * returning { PRESETS, styleById, SfxEngine }. No imports/exports.
 * All CSS selectors/keyframes are dsftc-prefixed; motion uses transform/
 * opacity; Arena render is a pure function of the snapshot.
 * ===================================================================== */
(function (global) {
  'use strict';
  function createComboFx(React) {
    const h = React.createElement;

    /* --- 1. small helpers + snapshot normalisation --- */
    const PHASES = { idle: 1, building: 1, holding: 1, settled: 1, broken: 1 };
    const TIERS = { 1: 'READY', 2: 'NICE', 3: 'GREAT', 4: 'FRENZY', 5: 'FEVER', 6: 'GODLIKE', 7: 'LEGEND' };
    /** AI character presets: each model mascot has its own palette, portrait and judgement lines. */
    const CHARACTERS = [
      {
        id: 'deepseek', label: { zh: 'DeepSeek', en: 'DeepSeek' },
        hint: { zh: '深度求索', en: 'DeepSeek' },
        word: 'DEEPSEEK', judges: { zh: ['白饭', '白饭', '白饭'], en: ['RICE', 'RICE', 'RICE'] },
        cap: { zh: '鲸语', en: 'WHALE' }, motto: { zh: '深潮同频', en: 'DEEP CURRENT' },
        accent: '#4D7CFF', accent2: '#7FE7FF', accent3: '#FFD166', ink: '#EAF4FF',
        num: ['#FFFFFF', '#7FE7FF', '#4D7CFF'],
        panel: 'radial-gradient(circle at 82% 6%,rgba(127,231,255,.22),transparent 46%),linear-gradient(155deg,#0A1A3A,#050A18 58%,#0B1430)',
        sound: { kind: 'fm', wave: 'sine', base: 300, ratio: 2.2, index: 1.5, sweep: 1.6, short: 0.16 }
      },
      {
        id: 'chatgpt', label: { zh: 'ChatGPT', en: 'ChatGPT' },
        hint: { zh: 'OpenAI', en: 'OpenAI' },
        word: 'CHATGPT', judges: { zh: ['生成', '生成', '生成'], en: ['GEN', 'GEN', 'GEN'] },
        cap: { zh: '龙息', en: 'DRAGON' }, motto: { zh: '为你而来', en: 'AT YOUR SERVICE' },
        accent: '#C4B5FD', accent2: '#F5F3FF', accent3: '#93C5FD', ink: '#F7F5FF',
        num: ['#FFFFFF', '#E9E4FF', '#B8A6FF'],
        panel: 'radial-gradient(circle at 78% 4%,rgba(196,181,253,.26),transparent 48%),linear-gradient(160deg,#17142A,#0A0814 62%,#14102A)',
        sound: { kind: 'fm', wave: 'sine', base: 320, ratio: 2.8, index: 1.4, sweep: 1.9, short: 0.16 }
      },
      {
        id: 'claude', label: { zh: 'Claude', en: 'Claude' },
        hint: { zh: 'Anthropic', en: 'Anthropic' },
        word: 'CLAUDE', judges: { zh: ['蒸馏', '蒸馏', '蒸馏'], en: ['DISTILL', 'DISTILL', 'DISTILL'] },
        cap: { zh: '书页', en: 'PAGE' }, motto: { zh: '逐字推敲', en: 'WORD BY WORD' },
        accent: '#FF8A4C', accent2: '#FFD9B0', accent3: '#FF5A36', ink: '#FFF3E6',
        num: ['#FFF6EA', '#FFD9B0', '#FF8A4C'],
        panel: 'radial-gradient(circle at 82% 4%,rgba(255,138,76,.26),transparent 46%),linear-gradient(160deg,#1A0D08,#0C0604 62%,#1A0B05)',
        sound: { kind: 'triangle', wave: 'triangle', base: 420, lift: 5, octave: 2, short: 0.12 }
      },
      {
        id: 'gemini', label: { zh: 'Gemini', en: 'Gemini' },
        hint: { zh: 'Google', en: 'Google' },
        word: 'GEMINI', judges: { zh: ['检索', '检索', '检索'], en: ['SEARCH', 'SEARCH', 'SEARCH'] },
        cap: { zh: '星光', en: 'STARLIGHT' }, motto: { zh: '双子同辉', en: 'TWIN LIGHT' },
        accent: '#8B5CF6', accent2: '#FF9BE6', accent3: '#FFE066', ink: '#FFF7FF',
        num: ['#FFFFFF', '#FFD1F5', '#8B5CF6'],
        panel: 'radial-gradient(circle at 24% 0%,rgba(255,155,230,.24),transparent 48%),radial-gradient(circle at 82% 18%,rgba(120,216,255,.22),transparent 52%),linear-gradient(160deg,#100A24,#070512 62%,#150A2A)',
        sound: { kind: 'chip', wave: 'square', base: 660, arp: [0, 4, 7], gap: 0.034, short: 0.06 }
      },
      {
        id: 'glm', label: { zh: 'GLM', en: 'GLM' },
        hint: { zh: '智谱 AI', en: 'Zhipu AI' },
        word: 'GLM', judges: { zh: ['开源', '开源', '开源'], en: ['OPEN', 'OPEN', 'OPEN'] },
        cap: { zh: '狐火', en: 'FOXFIRE' }, motto: { zh: '夜班已就位', en: 'NIGHT SHIFT' },
        accent: '#7AA7FF', accent2: '#E8F0FF', accent3: '#4C6FFF', ink: '#EEF2FF',
        num: ['#FFFFFF', '#C8D8FF', '#6F8FFF'],
        panel: 'radial-gradient(circle at 80% 8%,rgba(122,167,255,.22),transparent 48%),linear-gradient(160deg,#070B16,#03040A 62%,#0A1022)',
        sound: { kind: 'fm', wave: 'sine', base: 280, ratio: 3.2, index: 1.7, sweep: 1.5, short: 0.16 }
      },
      {
        id: 'grok', label: { zh: 'Grok', en: 'Grok' },
        hint: { zh: 'xAI', en: 'xAI' },
        word: 'GROK', judges: { zh: ['叛逆', '叛逆', '叛逆'], en: ['REBEL', 'REBEL', 'REBEL'] },
        cap: { zh: '混沌', en: 'CHAOS' }, motto: { zh: '规则就是用来打破', en: 'BREAK THE RULES' },
        accent: '#FFCF5C', accent2: '#FF5A5A', accent3: '#7C2D12', ink: '#FFF8E6',
        num: ['#FFF8E6', '#FFCF5C', '#FF5A5A'],
        panel: 'radial-gradient(circle at 82% 4%,rgba(255,90,90,.24),transparent 46%),linear-gradient(160deg,#150609,#080203 62%,#1C0A08)',
        sound: { kind: 'impact', wave: 'sine', base: 150, kickTo: 44, noiseFrom: 2400, noiseTo: 900, short: 0.16 }
      },
      {
        id: 'qwen', label: { zh: 'Qwen', en: 'Qwen' },
        hint: { zh: '阿里巴巴', en: 'Alibaba' },
        word: 'QWEN', judges: { zh: ['微调', '微调', '微调'], en: ['FINETUNE', 'FINETUNE', 'FINETUNE'] },
        cap: { zh: '扇影', en: 'FAN' }, motto: { zh: '有问必答', en: 'ANSWER ALL' },
        accent: '#7AA2FF', accent2: '#DCE6FF', accent3: '#FFD700', ink: '#F4F7FF',
        num: ['#FFFFFF', '#DCE6FF', '#7AA2FF'],
        panel: 'radial-gradient(circle at 80% 4%,rgba(122,162,255,.24),transparent 48%),linear-gradient(160deg,#0A1030,#04060F 62%,#0C1236)',
        sound: { kind: 'fm', wave: 'sine', base: 340, ratio: 2.0, index: 1.2, sweep: 1.7, short: 0.16 }
      }
    ];
    const CHARACTER_MAP = {};
    for (let i = 0; i < CHARACTERS.length; i++) CHARACTER_MAP[CHARACTERS[i].id] = CHARACTERS[i];
    /** Per-character typography. Fonts fall back to fonts shipped with Windows/Office. */
    const FONTS = {
      deepseek: { num: '"Comic Sans MS","Segoe UI","Microsoft YaHei",sans-serif', numStyle: 'normal', numTrack: '0.01em', judge: '"KaiTi","SimSun","Microsoft YaHei",serif', judgeTrack: '0.04em', brand: '"Comic Sans MS","Segoe UI Black",sans-serif' },
      chatgpt: { num: '"Georgia","Cambria","Times New Roman",serif', numStyle: 'normal', numTrack: '0.01em', judge: '"STKaiti","KaiTi","SimSun",serif', judgeStyle: 'italic', judgeTrack: '0.1em', brand: '"Georgia","Cambria",serif' },
      claude: { num: '"Cambria","Book Antiqua","Georgia",serif', numStyle: 'normal', numTrack: '0.02em', judge: '"FangSong","STFangsong","SimSun",serif', judgeTrack: '0.08em', brand: '"Cambria","Georgia",serif' },
      gemini: { num: '"Trebuchet MS","Verdana",sans-serif', numStyle: 'normal', numTrack: '0.01em', judge: '"Microsoft YaHei","Microsoft JhengHei",sans-serif', judgeTrack: '0.06em', brand: '"Trebuchet MS","Verdana",sans-serif' },
      glm: { num: '"Palatino Linotype","Book Antiqua","Georgia",serif', numStyle: 'italic', numTrack: '0.02em', judge: '"STKaiti","KaiTi","SimSun",serif', judgeStyle: 'italic', judgeTrack: '0.12em', brand: '"Palatino Linotype","Georgia",serif' },
      grok: { num: '"Impact","Arial Black","Segoe UI Black",sans-serif', numStyle: 'italic', numTrack: '0.01em', judge: '"SimHei","Microsoft YaHei",sans-serif', judgeStyle: 'italic', judgeTrack: '0.08em', brand: '"Impact","Arial Black",sans-serif' },
      qwen: { num: '"STKaiti","KaiTi","SimSun",serif', numStyle: 'normal', numTrack: '0.03em', judge: '"STXingkai","STKaiti","KaiTi",serif', judgeTrack: '0.1em', brand: '"Georgia","KaiTi",serif' }
    };
    const FALLBACK_FONT = { num: '"Segoe UI Black",Impact,sans-serif', judge: '"Microsoft YaHei",sans-serif', brand: '"Segoe UI Black",sans-serif' };
    const SOUND_BY_ID = {
      deepseek: 'fm', chatgpt: 'fm', claude: 'triangle', gemini: 'chip', glm: 'fm', grok: 'impact', qwen: 'fm'
    };
    function soundKind(id) { return SOUND_BY_ID[id] || id; }
    const ART_URL_BASE = '/token-combo/art/';
    function artUrl(id) { return ART_URL_BASE + id + '.webp'; }
    function num(v, d) {
      if (typeof v === 'number' && isFinite(v)) return v;
      if (typeof v === 'string' && v !== '' && isFinite(+v)) return +v;
      return d;
    }
    function int(v, d) { return Math.floor(num(v, d)); }
    function clamp(v, lo, hi) { v = num(v, lo); return v < lo ? lo : v > hi ? hi : v; }
    function tr(locale, zh, en) { return locale === 'zh' ? zh : en; }
    function trim1(v) { return String(Math.round(v * 10) / 10).replace(/\.0$/, ''); }
    /**
     * Compact display number: exact through 9999, then K/M/B (max 5 chars,
     * e.g. 12.3K / 123K / 1.2M) so the HUD width stays bounded. The value is
     * rounded before picking a tier, and the tier is promoted when the
     * rounded mantissa would overflow its unit (999999 -> 1M, not 1000K).
     */
    function compactNum(v) {
      const n = Math.round(num(v, 0));
      const a = Math.abs(n);
      if (a < 10000) return String(n);
      if (a < 1e6) {
        const k = Math.round(n / 1000);
        if (Math.abs(k) >= 1000) return trim1(n / 1e6) + 'M';
        return a < 1e5 ? trim1(n / 1000) + 'K' : String(k) + 'K';
      }
      if (a < 1e9) {
        const m = Math.round(n / 1e6);
        if (Math.abs(m) >= 1000) return trim1(n / 1e9) + 'B';
        return a < 1e7 ? trim1(n / 1e6) + 'M' : String(m) + 'M';
      }
      return trim1(n / 1e9) + 'B';
    }
    /** Preset colours as inline CSS custom properties. */
    function presetVars(spec) {
      return {
        '--dsftc-a': spec.accent,
        '--dsftc-a2': spec.accent2,
        '--dsftc-a3': spec.accent3,
        '--dsftc-ink': spec.ink
      };
    }
    /** Defensive read of one snapshot session entry. Never throws. */
    function readFx(raw) {
      const fx = raw && typeof raw === 'object' ? raw : {};
      const tk = fx.tokens && typeof fx.tokens === 'object' ? fx.tokens : {};
      const phase = PHASES[fx.phase] ? fx.phase : 'idle';
      const level = clamp(int(fx.level, 1), 1, 7);
      const combo = Math.max(0, int(fx.combo, 0));
      const next = Math.max(0, int(fx.nextLevelAt, 0));
      const mult = num(fx.multiplier, 1);
      const energy = clamp(num(fx.energy, 0), 0, 1);
      return {
        phase: phase,
        level: level,
        tier: typeof fx.tier === 'string' && fx.tier ? fx.tier.slice(0, 12) : TIERS[level],
        multiplier: mult > 0 ? mult : 1,
        combo: combo,
        maxCombo: Math.max(combo, Math.max(0, int(fx.maxCombo, 0))),
        bestCombo: Math.max(0, int(fx.bestCombo, 0)),
        hits: Math.max(0, int(fx.hits, 0)),
        score: Math.max(0, int(fx.score, 0)),
        tokens: {
          turn: Math.max(0, num(tk.turn, 0)),
          live: Math.max(0, num(tk.live, 0)),
          output: Math.max(0, num(tk.output, 0)),
          total: Math.max(0, num(tk.total, 0))
        },
        turn: Math.max(0, int(fx.turn, 0)),
        completedTurns: Math.max(0, int(fx.completedTurns, 0)),
        running: !!fx.running,
        milestone: Math.max(0, int(fx.milestone, 0)),
        milestoneSeq: Math.max(0, int(fx.milestoneSeq, 0)),
        hitSeq: Math.max(0, int(fx.hitSeq, 0)),
        breakSeq: Math.max(0, int(fx.breakSeq, 0)),
        settleSeq: Math.max(0, int(fx.settleSeq, 0)),
        energy: energy,
        energyPct: Math.round(energy * 100),
        next: next
      };
    }
    function statusOf(m, locale) {
      if (m.phase === 'building') return tr(locale, '连击', 'LIVE');
      if (m.phase === 'holding') return tr(locale, '保持', 'HOLD');
      if (m.phase === 'settled') return tr(locale, '已入账', 'BANKED');
      if (m.phase === 'broken') return tr(locale, '断连', 'BREAK');
      return tr(locale, '待机', 'READY');
    }
    /** Per-character judgement word; unknown kinds get a safe fallback. */
    function judgeOf(kind, m, locale) {
      const character = CHARACTER_MAP[kind];
      if (!character) return 'LOCK';
      const pair = character.judges[locale === 'zh' ? 'zh' : 'en'];
      const index = m.level >= 5 ? 2 : m.level >= 3 ? 1 : 0;
      return pair[index];
    }
    function judgeCap(kind, locale) {
      const character = CHARACTER_MAP[kind];
      if (!character) return tr(locale, '锁定', 'LOCK-ON');
      return character.cap[locale === 'zh' ? 'zh' : 'en'];
    }
    function previewWord(kind) {
      const character = CHARACTER_MAP[kind];
      if (!character) return 'LOCK';
      return character.cap.zh;
    }
    /* =================================================================
     * 2. shared CSS shell (embedded into every preset stylesheet so a
     *    single injected preset style is enough to skin picker previews)
     * =============================================================== */
    const BASE_CSS = `
/* ===== dsftc shared shell: embedded in every preset stylesheet ===== */
.dsftc-arena{position:relative;width:100%;isolation:isolate;color:var(--dsftc-ink,#eaf2ff);font-family:"Segoe UI",system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;line-height:1;user-select:none;-webkit-user-select:none}.dsftc-panel{position:relative;overflow:hidden;border-radius:14px;padding:.85em 1em .8em;background:#0a0e1c;border:1px solid rgba(255,255,255,.16);box-shadow:0 12px 32px rgba(0,0,0,.38),inset 0 1px 0 rgba(255,255,255,.09)}
.dsftc-head{position:relative;z-index:3;display:flex;align-items:center;gap:.45em;margin-bottom:.45em;flex-wrap:wrap}.dsftc-brand{display:flex;align-items:baseline;gap:.4em;font-size:.7em;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:var(--dsftc-a2,#22e6ff)}
.dsftc-bword{font-family:Impact,"Arial Black","Segoe UI Black","Haettenschweiler",sans-serif;font-size:1.35em;font-weight:900;letter-spacing:.03em;text-shadow:0 0 14px var(--dsftc-a,#7c4dff)}.dsftc-brand-sub{font-size:.82em;letter-spacing:.08em;opacity:.72;color:var(--dsftc-ink,#eaf2ff)}
.dsftc-chip{display:inline-flex;align-items:center;gap:.25em;padding:.28em .5em;border-radius:99px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.07);font-size:.6em;font-weight:800;letter-spacing:.1em;text-transform:uppercase;white-space:nowrap;color:#fff}.dsftc-cv{font-size:1.05em;color:var(--dsftc-a2,#22e6ff)}
.dsftc-tier{margin-left:auto}.dsftc-chip-broken{background:rgba(255,64,64,.24);border-color:rgba(255,100,100,.6)}
.dsftc-chip-settled{background:rgba(255,214,63,.2);border-color:rgba(255,214,63,.6)}.dsftc-main{position:relative;z-index:3;display:flex;align-items:flex-end;gap:.8em;min-height:3.4em}
.dsftc-block{display:flex;flex-direction:column;gap:.18em;min-width:0}.dsftc-num{display:inline-block;font-family:Impact,"Arial Black","Segoe UI Black","Haettenschweiler","Franklin Gothic Heavy",sans-serif;font-size:3.2em;font-weight:900;line-height:.86;letter-spacing:-.02em;font-variant-numeric:tabular-nums;color:#fff;text-shadow:0 0 14px var(--dsftc-a,#7c4dff),0 .06em 0 rgba(0,0,0,.6);transform-origin:8% 70%}
.dsftc-pop{animation:dsftc-pop .2s cubic-bezier(.2,1.6,.4,1) both}.dsftc-cap{font-size:.56em;font-weight:800;letter-spacing:.24em;text-transform:uppercase;opacity:.68}
.dsftc-judge{display:block;min-height:1.1em;font-family:Impact,"Arial Black","Segoe UI Black",sans-serif;font-size:1.15em;font-weight:900;letter-spacing:.09em;text-transform:uppercase;color:var(--dsftc-a3,#ff4d9d);text-shadow:0 0 12px currentColor;animation:dsftc-judge .48s cubic-bezier(.15,1.5,.4,1) both}.dsftc-side{margin-left:auto;display:flex;flex-direction:column;align-items:flex-end;gap:.3em;min-width:0;text-align:right}
.dsftc-mult{font-family:Impact,"Arial Black","Segoe UI Black",sans-serif;font-size:1.5em;font-weight:900;line-height:1;color:var(--dsftc-a2,#22e6ff);text-shadow:0 0 10px currentColor;font-variant-numeric:tabular-nums}.dsftc-bar{position:relative;z-index:3;height:.42em;margin-top:.55em;border-radius:99px;background:rgba(255,255,255,.12);overflow:hidden}
.dsftc-bar-fill{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--dsftc-a),var(--dsftc-a2));box-shadow:0 0 12px var(--dsftc-a2)}.dsftc-stats{position:relative;z-index:3;display:flex;align-items:flex-end;gap:1em;margin-top:.5em;flex-wrap:wrap}
.dsftc-stat{display:flex;flex-direction:column;gap:.16em;min-width:0}.dsftc-sv{font-family:"Segoe UI Black","Arial Black",Impact,sans-serif;font-size:1em;font-weight:900;color:#fff;font-variant-numeric:tabular-nums;letter-spacing:.01em}
.dsftc-sk{font-style:normal;font-size:.54em;font-weight:800;letter-spacing:.18em;text-transform:uppercase;opacity:.58;white-space:nowrap}.dsftc-burst{position:absolute;left:50%;top:44%;z-index:6;transform:translate(-50%,-50%);pointer-events:none;font-family:Impact,"Arial Black","Segoe UI Black",sans-serif;font-size:1.7em;font-weight:900;letter-spacing:.06em;text-transform:uppercase;text-align:center;white-space:nowrap;color:#fff;text-shadow:0 0 18px var(--dsftc-a2),0 2px 0 rgba(0,0,0,.6);animation:dsftc-burst 1s ease-out both}
.dsftc-burst-top{top:16%;font-size:1.2em;letter-spacing:.12em}.dsftc-burst-b{top:64%}
.dsftc-burst-c{top:80%;font-size:1.1em}.dsftc-burst-red{color:#ff5a4d;text-shadow:0 0 18px #ff2f2f,0 2px 0 #000}
.dsftc-burst-gold{color:#ffe45c;text-shadow:0 0 18px #ffb300,0 2px 0 #000}.dsftc-ico{display:block;overflow:visible}
@keyframes dsftc-pop{0%{transform:scale(1.42) skewX(-6deg)}60%{transform:scale(.96) skewX(1deg)}100%{transform:scale(1) skewX(0)}}@keyframes dsftc-judge{0%{opacity:0;transform:translateY(.25em) scale(.72)}20%{opacity:1;transform:translateY(0) scale(1.06)}55%{opacity:1;transform:translateY(0) scale(1)}100%{opacity:0;transform:translateY(-.45em) scale(1.02)}}
@keyframes dsftc-burst{0%{opacity:0;transform:translate(-50%,-50%) scale(.55)}14%{opacity:1;transform:translate(-50%,-50%) scale(1.14)}30%{transform:translate(-50%,-50%) scale(1)}72%{opacity:1}100%{opacity:0;transform:translate(-50%,-62%) scale(1.03)}}@keyframes dsftc-fade{0%{opacity:0}25%{opacity:1}100%{opacity:0}}
@keyframes dsftc-fadein{0%{opacity:.35}100%{opacity:1}}@keyframes dsftc-blink{0%,100%{opacity:1}50%{opacity:.25}}
/* --- compact: overlay / dock mode --- */ .dsftc-cmp .dsftc-panel{padding:.6em .7em .55em;border-radius:11px}.dsftc-cmp .dsftc-head{margin-bottom:.3em;gap:.35em}
.dsftc-cmp .dsftc-brand{font-size:.62em}.dsftc-cmp .dsftc-brand-sub{display:none}
.dsftc-cmp .dsftc-num{font-size:2.35em}.dsftc-cmp .dsftc-main{min-height:2.5em;gap:.5em}
.dsftc-cmp .dsftc-judge{font-size:.98em}.dsftc-cmp .dsftc-mult{font-size:1.15em}
.dsftc-cmp .dsftc-bar{height:.34em;margin-top:.4em}.dsftc-cmp .dsftc-stats{gap:.7em;margin-top:.35em}
.dsftc-cmp .dsftc-sv{font-size:.86em}.dsftc-cmp .dsftc-burst{font-size:1.15em}
.dsftc-cmp .dsftc-burst-top{font-size:.92em}.dsftc-cmp .dsftc-hidecmp{display:none!important}
/* --- reduced motion: keep feedback, drop looping decoration --- */ .dsftc-red .dsftc-deco{animation:none!important}.dsftc-red .dsftc-judge{animation:dsftc-fade .32s linear both}
.dsftc-red .dsftc-burst{animation:dsftc-fade .5s linear both;transform:translate(-50%,-50%)}.dsftc-red .dsftc-pop{animation:dsftc-fadein .2s linear both}
/* --- badge: single-row composer pill (34-44px tall) --- */ .dsftc-badge{position:relative;display:inline-flex;align-items:center;gap:.42em;height:36px;padding:0 .72em;border-radius:999px;overflow:hidden;white-space:nowrap;color:var(--dsftc-ink,#eaf2ff);font-family:"Segoe UI",system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;line-height:1;background:linear-gradient(135deg,#101830,#22143a);border:1px solid rgba(255,255,255,.18);box-shadow:0 2px 10px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.14);font-variant-numeric:tabular-nums}.dsftc-bdot{flex:none;width:.44em;height:.44em;border-radius:50%;background:var(--dsftc-a);box-shadow:0 0 8px var(--dsftc-a)}
.dsftc-bcombo{font-family:Impact,"Arial Black","Segoe UI Black",sans-serif;font-weight:900;font-size:1.5em;line-height:1;color:#fff;text-shadow:0 0 10px var(--dsftc-a)}.dsftc-bcap{font-size:.62em;font-weight:800;letter-spacing:.14em;text-transform:uppercase;opacity:.66}
.dsftc-bx{font-weight:900;font-size:.9em;letter-spacing:.02em;color:var(--dsftc-a2)}.dsftc-bt{font-weight:700;font-size:.8em;letter-spacing:.04em;opacity:.85}
.dsftc-badge-live .dsftc-bdot{animation:dsftc-blink .9s steps(2) infinite}.dsftc-red .dsftc-badge-live .dsftc-bdot{animation:none}
/* --- preview: 120x90 portrait picker card --- */ .dsftc-pv{position:relative;width:120px;height:90px;border-radius:10px;overflow:hidden;isolation:isolate;color:#eaf2ff;background:radial-gradient(circle at 50% 30%,#18224a,#080c18 72%);border:1px solid rgba(255,255,255,.16);font-family:"Segoe UI",system-ui,-apple-system,"PingFang SC","Microsoft YaHei",sans-serif}.dsftc-pvw{position:absolute;left:0;right:0;bottom:8px;z-index:5;text-align:center;font-family:Impact,"Arial Black","Segoe UI Black",sans-serif;font-size:14px;font-weight:900;letter-spacing:.08em;color:#fff;text-shadow:0 0 10px var(--dsftc-a2),0 1px 0 rgba(0,0,0,.6);animation:dsftc-pvword 1.6s ease-in-out infinite}
@keyframes dsftc-pvword{0%,100%{transform:scale(1);opacity:.92}50%{transform:scale(1.09);opacity:1}}
`;

    /* --- 3. character chrome: portrait / avatar / picker card / fever glow --- */
    const CHAR_CSS = `
.dsftc-art{position:absolute;right:-1em;bottom:-1.4em;z-index:0;height:118%;width:auto;max-width:72%;object-fit:contain;object-position:bottom right;opacity:.2;pointer-events:none;-webkit-mask-image:linear-gradient(180deg,transparent 0%,#000 18%,#000 72%,transparent 100%);mask-image:linear-gradient(180deg,transparent 0%,#000 18%,#000 72%,transparent 100%)}
.dsftc-char-aura{position:absolute;right:10%;top:16%;z-index:1;width:5em;height:5em;border-radius:50%;background:radial-gradient(circle,var(--dsftc-a2),transparent 66%);opacity:.16;filter:blur(10px);pointer-events:none}
.dsftc-avatar{width:1.25em;height:1.25em;border-radius:4px;object-fit:cover;object-position:top center;border:1px solid var(--dsftc-a2);background:#fff;flex:none;box-shadow:0 0 8px var(--dsftc-a2)}
.dsftc-pv-art{position:absolute;inset:0;z-index:1;width:100%;height:100%;object-fit:cover;object-position:top center;display:block}
.dsftc-pv-shade{position:absolute;inset:0;z-index:2;background:linear-gradient(180deg,rgba(0,0,0,0) 42%,rgba(0,0,0,.74))}
.dsftc-pv-name{position:absolute;left:6px;right:6px;bottom:17px;z-index:4;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-size:11px;font-weight:700;letter-spacing:.04em;color:#fff;text-shadow:0 1px 4px rgba(0,0,0,.85)}
.dsftc-pv .dsftc-pvw{bottom:3px;font-size:11px}
.dsftc-arena.dsftc-fever .dsftc-panel{border-color:var(--dsftc-a2)}
.dsftc-ico{border-radius:50%;object-fit:cover;object-position:top center;background:#fff}
`;
    function charCss(c) {
      const f = FONTS[c.id] || FALLBACK_FONT;
      return `
.dsftc-arena-${c.id} .dsftc-panel{background:${c.panel};border:1px solid ${c.accent}55;box-shadow:0 14px 40px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.08)}
.dsftc-arena-${c.id} .dsftc-num{font-family:${f.num};font-style:${f.numStyle || 'normal'};letter-spacing:${f.numTrack || '0.01em'};background:linear-gradient(180deg,${c.num[0]},${c.num[1]} 45%,${c.num[2]});-webkit-background-clip:text;background-clip:text;color:transparent;text-shadow:none;filter:drop-shadow(0 0 14px ${c.accent}cc)}
.dsftc-arena-${c.id} .dsftc-judge{font-family:${f.judge};font-style:${f.judgeStyle || 'normal'};letter-spacing:${f.judgeTrack || '0.05em'};color:${c.accent2};text-shadow:0 0 14px ${c.accent2},0 0 28px ${c.accent}88}
.dsftc-arena-${c.id} .dsftc-bword{font-family:${f.brand};letter-spacing:0.14em}
.dsftc-arena-${c.id} .dsftc-mult{color:${c.accent2};text-shadow:0 0 10px ${c.accent2}}
.dsftc-arena-${c.id} .dsftc-bar-fill{background:linear-gradient(90deg,${c.accent},${c.accent2});box-shadow:0 0 12px ${c.accent2}}
.dsftc-arena-${c.id} .dsftc-chip{background:${c.accent}22;border-color:${c.accent}66}
.dsftc-arena-${c.id}.dsftc-fever .dsftc-panel{box-shadow:0 0 0 1px ${c.accent2}88,0 0 30px ${c.accent}66,0 14px 40px rgba(0,0,0,.45)}
`;
    }

    /* --- 4. shared arena fragments --- */
    function stat(locale, zh, en, value, extraCls) {
      return h('div', { className: 'dsftc-stat' + (extraCls ? ' ' + extraCls : '') },
        h('b', { className: 'dsftc-sv' }, value),
        h('i', { className: 'dsftc-sk' }, tr(locale, zh, en)));
    }
    function headRow(spec, m, locale) {
      return h('div', { className: 'dsftc-head' },
        h('img', { key: 'avatar', className: 'dsftc-avatar', src: artUrl(spec.id), alt: '' }),
        h('span', { className: 'dsftc-brand' },
          h('b', { className: 'dsftc-bword' }, spec.word),
          h('span', { className: 'dsftc-brand-sub' }, spec.label[locale] || spec.label.en)),
        h('span', { key: 'lv' + m.level, className: 'dsftc-chip dsftc-tier dsftc-pop' },
          'LV ', h('b', { className: 'dsftc-cv' }, String(m.level)), ' ', m.tier),
        h('span', { className: 'dsftc-chip dsftc-status dsftc-chip-' + m.phase }, statusOf(m, locale)));
    }
    function mainRow(spec, m, locale) {
      const character = CHARACTER_MAP[spec.id];
      const side2 = h('span', { className: 'dsftc-chip dsftc-hidecmp' }, character ? character.cap[locale === 'zh' ? 'zh' : 'en'] : tr(locale, '下一级 ', 'NEXT ') + compactNum(m.next));
      return h('div', { className: 'dsftc-main' },
        h('div', { className: 'dsftc-block' },
          h('span', { key: 'combo' + m.hitSeq, className: 'dsftc-num dsftc-pop' }, compactNum(m.combo)),
          h('span', { className: 'dsftc-cap' }, tr(locale, '连击', 'COMBO'))),
        h('div', { className: 'dsftc-block' },
          h('span', { key: 'judge' + m.hitSeq, className: 'dsftc-judge' }, m.hitSeq > 0 ? judgeOf(spec.id, m, locale) : ''),
          h('span', { className: 'dsftc-cap' }, judgeCap(spec.id, locale))),
        h('div', { key: 'side' + m.hitSeq, className: 'dsftc-side dsftc-sidekick' },
          h('span', { className: 'dsftc-mult' }, 'x' + trim1(m.multiplier)),
          side2));
    }
    function statsRow(spec, m, locale) {
      return h('div', { className: 'dsftc-stats' },
        stat(locale, '词元', 'TOKENS', compactNum(m.tokens.turn)),
        stat(locale, '命中', 'HITS', compactNum(m.hits)),
        stat(locale, '得分', 'SCORE', compactNum(m.score)),
        stat(locale, '最高连击', 'BEST', compactNum(m.bestCombo), 'dsftc-hidecmp'),
        stat(locale, '等级', 'TIER', m.tier, 'dsftc-hidecmp'));
    }
    /** Decorative character props, keyed so React can stream updates cheaply. */
    function decorations(spec) {
      const character = CHARACTER_MAP[spec.id];
      if (!character) return [];
      return [
        h('img', { key: 'art', className: 'dsftc-art dsftc-deco', src: artUrl(spec.id), alt: '' }),
        h('i', { key: 'aura', className: 'dsftc-char-aura dsftc-deco' })
      ];
    }

    /* --- 5. Arena factory (pure render from snapshot; safe for many mounts) --- */
    function makeArena(spec) {
      return function Arena(props) {
        props = props && typeof props === 'object' ? props : {};
        const m = readFx(props.fx);
        const locale = props.locale === 'zh' ? 'zh' : 'en';
        const scale = clamp(num(props.scale, 1), 0.8, 2.4);
        const compact = !!props.compact;
        const reduced = !!props.reduced;
        const style = presetVars(spec);
        style.fontSize = (compact ? 10.6 : 14.4) * scale + 'px';
        let cls = 'dsftc-arena dsftc-arena-' + spec.id;
        if (compact) cls += ' dsftc-cmp';
        if (reduced) cls += ' dsftc-red';
        cls += ' dsftc-ph-' + m.phase;
        if (CHARACTER_MAP[spec.id] && m.level >= 5) cls += ' dsftc-fever';
        /* Transient flourishes: keyed by sequence, play once, self-hide. */
        const bursts = [];
        if (m.milestoneSeq > 0 && m.milestone > 0) {
          bursts.push(h('span', { key: 'ms' + m.milestoneSeq, className: 'dsftc-burst dsftc-burst-top' },
            '\u2605 ' + compactNum(m.milestone) + ' ' + tr(locale, '里程碑', 'MILESTONE') + ' \u2605'));
        }
        if (m.breakSeq > 0) {
          bursts.push(h('span', { key: 'bk' + m.breakSeq, className: 'dsftc-burst dsftc-burst-b dsftc-burst-red' },
            tr(locale, '断连', 'COMBO BREAK')));
        }
        if (m.settleSeq > 0) {
          bursts.push(h('span', { key: 'se' + m.settleSeq, className: 'dsftc-burst dsftc-burst-c dsftc-burst-gold' },
            '+ ' + compactNum(m.tokens.turn) + ' ' + tr(locale, '词元入账', 'TOKENS BANKED')));
        }
        return h('div', {
          className: cls,
          style: style,
          'data-preset': spec.id,
          'data-phase': m.phase,
          role: 'group',
          'aria-label': (spec.label[locale] || spec.label.en) + ' \u00b7 ' + tr(locale, '连击', 'combo') + ' ' + m.combo +
            ' \u00b7 ' + tr(locale, '倍率', 'multiplier') + ' x' + trim1(m.multiplier)
        },
          h('div', { className: 'dsftc-panel' },
            decorations(spec),
            headRow(spec, m, locale),
            mainRow(spec, m, locale),
            h('div', { className: 'dsftc-bar' },
              h('i', { className: 'dsftc-bar-fill', style: { width: m.energyPct + '%' } })),
            statsRow(spec, m, locale),
            bursts));
      };
    }

    /* --- 6. Badge factory: one-row composer pill, 34..44px tall --- */
    function makeBadge(spec) {
      return function Badge(props) {
        props = props && typeof props === 'object' ? props : {};
        const m = readFx(props.fx);
        const locale = props.locale === 'zh' ? 'zh' : 'en';
        const scale = clamp(num(props.scale, 1), 0.8, 2.4);
        const reduced = !!props.reduced;
        const height = clamp(Math.round(38 * scale), 34, 44);
        const style = presetVars(spec);
        style.height = height + 'px';
        style.fontSize = Math.round(height * 0.34 * 10) / 10 + 'px';
        let cls = 'dsftc-badge dsftc-bad-' + spec.id;
        if (reduced) cls += ' dsftc-red';
        if (m.phase === 'building') cls += ' dsftc-badge-live';
        const label = (spec.label[locale] || spec.label.en) + ' \u00b7 ' + tr(locale, '连击', 'COMBO') + ' ' + m.combo +
          ' \u00b7 x' + trim1(m.multiplier) + ' \u00b7 ' + compactNum(m.tokens.turn) + ' ' + tr(locale, '词元', 'tokens');
        return h('div', { className: cls, style: style, title: label, 'aria-label': label },
          h('span', { className: 'dsftc-bdot' }),
          h('b', { key: 'b' + m.hitSeq, className: 'dsftc-bcombo' }, compactNum(m.combo)),
          h('span', { className: 'dsftc-bcap' }, tr(locale, '连击', 'COMBO')),
          h('span', { className: 'dsftc-bx' }, 'x' + trim1(m.multiplier)),
          h('span', { className: 'dsftc-bt' }, compactNum(m.tokens.turn) + ' ' + tr(locale, '词元', 'tok')));
      };
    }

    /* --- 7. Preview factory: character portrait picker card --- */
    function makePreview(spec) {
      return function Preview() {
        const style = presetVars(spec);
        const character = CHARACTER_MAP[spec.id];
        const cls = 'dsftc-pv dsftc-pv-' + spec.id;
        if (!character) {
          /* Defensive fallback for an unknown preset id: word card, never throw. */
          return h('div', { className: cls, style: style, 'aria-hidden': 'true' },
            h('span', { key: 'w', className: 'dsftc-pvw' }, previewWord(spec.id)));
        }
        return h('div', { className: cls, style: style, 'aria-hidden': 'true' },
          h('img', { key: 'art', className: 'dsftc-pv-art', src: artUrl(spec.id), alt: '' }));
      };
    }

    /* --- 8. Icon factory: 24x24 svg glyph, currentColor + preset accent --- */
    function makeIcon(spec) {
      return function Icon(props) {
        props = props && typeof props === 'object' ? props : {};
        const size = clamp(int(props.size, 24), 12, 64);
        const active = !!props.active;
        const style = presetVars(spec);
        if (active) style.filter = 'drop-shadow(0 0 5px ' + spec.accent2 + ')';
        const character = CHARACTER_MAP[spec.id];
        if (character) {
          return h('img', {
            key: 'art', className: 'dsftc-ico dsftc-ico-' + spec.id, src: artUrl(spec.id), alt: '',
            width: size, height: size, style: style, 'aria-hidden': 'true'
          });
        }
        const base = {
          width: size, height: size, viewBox: '0 0 24 24',
          className: 'dsftc-ico dsftc-ico-' + spec.id,
          style: style, 'aria-hidden': 'true', focusable: 'false'
        };
        /* Defensive fallback for an unknown preset id (character icons return above). */
        return h('svg', base,
          h('path', { key: 'hex', d: 'M12 2.4l7.6 4.4v9.2L12 20.4 4.4 16V6.8z', fill: 'none', stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' }),
          h('circle', { key: 'r', cx: 12, cy: 12, r: 3.6, fill: 'none', stroke: active ? spec.accent : 'currentColor', strokeWidth: 1.8 }),
          h('path', { key: 't1', d: 'M12 6.4v1.9M12 15.7v1.9M6.4 12h1.9M15.7 12h1.9', fill: 'none', stroke: 'currentColor', strokeWidth: 1.4, strokeLinecap: 'round' }),
          h('circle', { key: 'dot', cx: 12, cy: 12, r: 1.3, fill: active ? spec.accent2 : 'currentColor' }));
      };
    }
    /* =================================================================
     * 9. WebAudio SFX engine
     *    - voices per preset, generated (no assets)
     *    - lazy AudioContext, muted = zero work, hit rate limit 14/s
     *    - every public method is wrapped: never throws
     * =============================================================== */
    function nowMs() {
      try {
        if (typeof performance !== 'undefined' && performance && typeof performance.now === 'function') return performance.now();
      } catch (e) { /* ignore */ }
      return Date.now();
    }
    function defaultContextFactory() {
      try {
        const g = typeof globalThis !== 'undefined' ? globalThis : null;
        if (!g) return null;
        const Ctor = g.AudioContext || g.webkitAudioContext;
        return Ctor ? new Ctor() : null;
      } catch (e) {
        return null;
      }
    }
    /** Hard cap on live node entries; keeps long-running HUD pages bounded. */
    const SFX_MAX_NODES = 256;
    function SfxEngine(options) {
      if (!(this instanceof SfxEngine)) return new SfxEngine(options);
      options = options && typeof options === 'object' ? options : {};
      this._factory = typeof options.createContext === 'function' ? options.createContext : defaultContextFactory;
      this._ctx = null;
      this._master = null;
      this._nodes = [];
      this._muted = false;
      this._volume = 0.25;
      this._lastHit = -1e9;
      this._queued = 0;
      this._dead = false;
    }
    /** Create/resume the context lazily. Returns null when unavailable. */
    SfxEngine.prototype._ensure = function () {
      if (this._dead) return null;
      if (this._ctx) return this._ctx;
      let ctx = null;
      try {
        const made = typeof this._factory === 'function' ? this._factory() : null;
        if (!made) return null;
        ctx = typeof made === 'function' ? new made() : made;
      } catch (e) {
        return null;
      }
      if (!ctx || typeof ctx.createOscillator !== 'function' || typeof ctx.createGain !== 'function') return null;
      try {
        const master = ctx.createGain();
        if (!master || !master.gain) return null;
        master.gain.value = this._muted ? 0 : this._volume;
        master.connect(ctx.destination);
        this._ctx = ctx;
        this._master = master;
        return ctx;
      } catch (e) {
        return null;
      }
    };
    SfxEngine.prototype._env = function (param, peak, t0, attack, dur) {
      const p = Math.max(0.0002, peak);
      try {
        if (typeof param.setValueAtTime === 'function') param.setValueAtTime(0.0001, t0);
        if (typeof param.exponentialRampToValueAtTime === 'function') {
          param.exponentialRampToValueAtTime(p, t0 + Math.max(0.004, attack));
          param.exponentialRampToValueAtTime(0.0001, t0 + dur);
        } else if (typeof param.setValueAtTime === 'function') {
          param.setValueAtTime(p, t0 + Math.max(0.004, attack));
          param.setValueAtTime(0.0001, t0 + dur);
        } else {
          param.value = p;
        }
      } catch (e) {
        try { param.value = p; } catch (e2) { /* ignore */ }
      }
    };
    /**
     * Register one finished node graph: push an entry, evict the oldest entry
     * first when the hard cap is reached, and wire onended to release it again.
     * `extra` holds every downstream node so the whole graph is disconnected.
     */
    SfxEngine.prototype._trackNode = function (src, extra) {
      if (!src) return null;
      if (!this._nodes) this._nodes = [];
      const entry = { src: src, extra: extra && extra.length ? extra : [] };
      while (this._nodes.length >= SFX_MAX_NODES) {
        const oldest = this._nodes.shift();
        if (oldest) this._releaseNode(oldest, true);
      }
      this._nodes.push(entry);
      try {
        const self = this;
        src.onended = function () { self._releaseNode(entry, false); };
      } catch (e) { /* ignore */ }
      return entry;
    };
    /** Remove one tracked entry and disconnect its source plus every extra. */
    SfxEngine.prototype._releaseNode = function (entry, alsoStop) {
      if (!entry) return;
      const nodes = this._nodes;
      if (nodes) {
        const idx = nodes.indexOf(entry);
        if (idx >= 0) nodes.splice(idx, 1);
      }
      const src = entry.src;
      if (src) {
        if (alsoStop) { try { if (typeof src.stop === 'function') src.stop(); } catch (e) { /* ignore */ } }
        try { if (typeof src.disconnect === 'function') src.disconnect(); } catch (e) { /* ignore */ }
      }
      const extra = entry.extra || [];
      for (let i = 0; i < extra.length; i++) {
        const n = extra[i];
        if (!n) continue;
        if (alsoStop) { try { if (typeof n.stop === 'function') n.stop(); } catch (e) { /* ignore */ } }
        try { if (typeof n.disconnect === 'function') n.disconnect(); } catch (e) { /* ignore */ }
      }
    };
    /** One enveloped oscillator blip. */
    SfxEngine.prototype._tone = function (o) {
      const ctx = this._ensure();
      if (!ctx) return;
      o = o || {};
      let osc = null;
      let gain = null;
      try {
        osc = ctx.createOscillator();
        gain = ctx.createGain();
      } catch (e) {
        return;
      }
      if (!osc || !gain) return;
      const t0 = ctx.currentTime + num(o.delay, 0);
      const dur = clamp(num(o.dur, 0.12), 0.02, 1.2);
      const f0 = clamp(num(o.freq, 440), 20, 14000);
      try { if (o.type) osc.type = o.type; } catch (e) { /* ignore */ }
      try {
        osc.frequency.setValueAtTime(f0, t0);
        if (o.to && typeof osc.frequency.exponentialRampToValueAtTime === 'function') {
          osc.frequency.exponentialRampToValueAtTime(clamp(num(o.to, f0), 20, 14000), t0 + dur);
        }
      } catch (e) { try { osc.frequency.value = f0; } catch (e2) { /* ignore */ } }
      try { if (o.detune) osc.detune.value = num(o.detune, 0); } catch (e) { /* ignore */ }
      this._env(gain.gain, num(o.gain, 0.18), t0, num(o.attack, 0.008), dur);
      try { osc.connect(gain); } catch (e) { /* ignore */ }
      try { if (this._master) gain.connect(this._master); } catch (e) { /* ignore */ }
      try {
        osc.start(t0);
        osc.stop(t0 + dur + 0.03);
      } catch (e) { try { osc.start(); osc.stop(); } catch (e2) { /* ignore */ } }
      this._trackNode(osc, [gain]);
    };
    /** Filtered noise burst (punch / whoosh / glitch). */
    SfxEngine.prototype._noise = function (o) {
      const ctx = this._ensure();
      if (!ctx) return;
      if (typeof ctx.createBufferSource !== 'function') return;
      o = o || {};
      const dur = clamp(num(o.dur, 0.1), 0.02, 1);
      const rate = Math.max(8000, num(ctx.sampleRate, 44100));
      let buf = null;
      try { buf = ctx.createBuffer(1, Math.max(8, Math.floor(rate * dur)), rate); } catch (e) { buf = null; }
      if (buf && typeof buf.getChannelData === 'function') {
        try {
          const data = buf.getChannelData(0);
          for (let i = 0; i < data.length; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / data.length);
        } catch (e) { /* ignore */ }
      }
      let src = null;
      let gain = null;
      try {
        src = ctx.createBufferSource();
        gain = ctx.createGain();
      } catch (e) {
        return;
      }
      if (!src || !gain) return;
      try { src.buffer = buf; } catch (e) { /* ignore */ }
      const t0 = ctx.currentTime + num(o.delay, 0);
      this._env(gain.gain, num(o.gain, 0.2), t0, 0.004, dur);
      const extra = [gain];
      try {
        if (typeof ctx.createBiquadFilter === 'function' && (o.from || o.to)) {
          const flt = ctx.createBiquadFilter();
          try {
            flt.type = o.type === 'lowpass' ? 'lowpass' : o.type === 'highpass' ? 'highpass' : 'bandpass';
            flt.frequency.setValueAtTime(clamp(num(o.from, 1200), 40, 16000), t0);
            if (o.to && typeof flt.frequency.exponentialRampToValueAtTime === 'function') {
              flt.frequency.exponentialRampToValueAtTime(clamp(num(o.to, 600), 40, 16000), t0 + dur);
            }
            try { flt.Q.value = num(o.q, 1.1); } catch (e) { /* ignore */ }
            src.connect(flt);
            flt.connect(gain);
          } catch (e) {
            try { src.connect(gain); } catch (e2) { /* ignore */ }
          }
          extra.push(flt);
        } else {
          try { src.connect(gain); } catch (e) { /* ignore */ }
        }
      } catch (e) { /* ignore */ }
      try { if (this._master) gain.connect(this._master); } catch (e) { /* ignore */ }
      try {
        src.start(t0);
        src.stop(t0 + dur + 0.03);
      } catch (e) { try { src.start(); src.stop(); } catch (e2) { /* ignore */ } }
      this._trackNode(src, extra);
    };
    /** Two-operator FM sweep (fm-family character voices). */
    SfxEngine.prototype._fm = function (o) {
      const ctx = this._ensure();
      if (!ctx) return;
      o = o || {};
      let carrier = null;
      let mod = null;
      let mGain = null;
      let amp = null;
      try {
        carrier = ctx.createOscillator();
        mod = ctx.createOscillator();
        mGain = ctx.createGain();
        amp = ctx.createGain();
      } catch (e) {
        return;
      }
      if (!carrier || !mod || !mGain || !amp) return;
      const t0 = ctx.currentTime + num(o.delay, 0);
      const dur = clamp(num(o.dur, 0.2), 0.03, 1.2);
      const f0 = clamp(num(o.freq, 400), 30, 12000);
      const f1 = clamp(num(o.to, f0 * 1.5), 30, 12000);
      try { carrier.type = o.type || 'sine'; mod.type = 'sine'; } catch (e) { /* ignore */ }
      try {
        carrier.frequency.setValueAtTime(f0, t0);
        if (typeof carrier.frequency.exponentialRampToValueAtTime === 'function') {
          carrier.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
        }
      } catch (e) { try { carrier.frequency.value = f0; } catch (e2) { /* ignore */ } }
      try { mod.frequency.setValueAtTime(f0 * num(o.ratio, 2.5), t0); } catch (e) { try { mod.frequency.value = f0 * num(o.ratio, 2.5); } catch (e2) { /* ignore */ } }
      try {
        mGain.gain.setValueAtTime(f0 * num(o.index, 1.5), t0);
        if (typeof mGain.gain.exponentialRampToValueAtTime === 'function') {
          mGain.gain.exponentialRampToValueAtTime(Math.max(1, f0 * 0.18), t0 + dur);
        }
      } catch (e) { /* ignore */ }
      this._env(amp.gain, num(o.gain, 0.14), t0, 0.012, dur);
      try { mod.connect(mGain); mGain.connect(carrier.frequency); } catch (e) { /* ignore */ }
      try { carrier.connect(amp); if (this._master) amp.connect(this._master); } catch (e) { /* ignore */ }
      try {
        mod.start(t0);
        carrier.start(t0);
        mod.stop(t0 + dur + 0.03);
        carrier.stop(t0 + dur + 0.03);
      } catch (e) {
        try { carrier.start(); carrier.stop(); } catch (e2) { /* ignore */ }
      }
      this._trackNode(carrier, [mod, mGain, amp]);
    };

    /* --- voices --- */
    SfxEngine.prototype._hitVoice = function (kind, level, boost) {
      if (kind === 'impact') {
        this._noise({ dur: 0.09, gain: 0.2 + boost * 0.3, from: 2400, to: 900 });
        this._tone({ type: 'sine', freq: 150 + level * 6, to: 44, dur: 0.16, gain: 0.28 });
        this._tone({ type: 'square', freq: 90, to: 34, dur: 0.05, gain: 0.08 });
        return;
      }
      if (kind === 'chip') {
        const root = 620 * Math.pow(2, (level - 1) / 12);
        const arp = [0, 4, 7];
        for (let i = 0; i < arp.length; i++) {
          this._tone({ type: 'square', freq: root * Math.pow(2, arp[i] / 12), dur: 0.06, gain: 0.1, delay: i * 0.034 });
        }
        return;
      }
      if (kind === 'fm') {
        const f = 300 + level * 28;
        this._fm({ freq: f, to: f * 1.7, ratio: 2.4, index: 1.6 + boost, dur: 0.17, gain: 0.14 });
        return;
      }
      const f = 523.25 * Math.pow(2, (level - 1) / 6);
      this._tone({ type: 'triangle', freq: f, to: f * 1.42, dur: 0.08 + level * 0.012, gain: 0.15 + boost * 0.2 });
      this._tone({ type: 'sine', freq: f * 2, dur: 0.055, gain: 0.05, delay: 0.012 });
    };
    SfxEngine.prototype._milestoneVoice = function (kind, level) {
      const lift = Math.pow(2, (level - 1) / 24);
      if (kind === 'impact') {
        this._noise({ dur: 0.18, gain: 0.24, from: 3200, to: 600 });
        this._tone({ type: 'sine', freq: 120, to: 40, dur: 0.3, gain: 0.3 });
        this._tone({ type: 'sawtooth', freq: 220, to: 660 * lift, dur: 0.34, gain: 0.09, delay: 0.08 });
        return;
      }
      if (kind === 'chip') {
        const notes = [0, 4, 7, 12, 16];
        for (let i = 0; i < notes.length; i++) {
          this._tone({ type: 'square', freq: 523.25 * lift * Math.pow(2, notes[i] / 12), dur: 0.07, gain: 0.1, delay: i * 0.065 });
        }
        return;
      }
      if (kind === 'fm') {
        this._fm({ freq: 180, to: 1500, ratio: 3.1, index: 2.2, dur: 0.5, gain: 0.16 });
        this._fm({ freq: 240, to: 1100, ratio: 1.7, index: 1.2, dur: 0.42, gain: 0.1, delay: 0.06 });
        return;
      }
      const notes = [0, 4, 7, 12];
      for (let i = 0; i < notes.length; i++) {
        this._tone({ type: 'triangle', freq: 523.25 * lift * Math.pow(2, notes[i] / 12), dur: 0.11, gain: 0.13, delay: i * 0.07 });
      }
      this._tone({ type: 'sine', freq: 1568, dur: 0.22, gain: 0.05, delay: 0.2 });
    };
    SfxEngine.prototype._breakVoice = function (kind) {
      if (kind === 'impact') {
        this._noise({ dur: 0.22, gain: 0.2, from: 900, to: 180, type: 'lowpass' });
        this._tone({ type: 'sine', freq: 110, to: 38, dur: 0.26, gain: 0.24 });
        return;
      }
      if (kind === 'chip') {
        const seq = [0, -4, -7, -12];
        for (let i = 0; i < seq.length; i++) {
          this._tone({ type: 'square', freq: 440 * Math.pow(2, seq[i] / 12), dur: 0.08, gain: 0.1, delay: i * 0.09 });
        }
        return;
      }
      if (kind === 'fm') {
        this._fm({ freq: 640, to: 120, ratio: 2.8, index: 1.4, dur: 0.32, gain: 0.13 });
        return;
      }
      const seq = [0, -3, -7];
      for (let i = 0; i < seq.length; i++) {
        this._tone({ type: 'triangle', freq: 523.25 * Math.pow(2, seq[i] / 12), dur: 0.12, gain: 0.12, delay: i * 0.09 });
      }
    };
    SfxEngine.prototype._settleVoice = function (kind, combo) {
      const lift = Math.pow(2, clamp(combo, 0, 400) / 400);
      if (kind === 'impact') {
        this._noise({ dur: 0.16, gain: 0.24, from: 2800, to: 700 });
        this._tone({ type: 'sine', freq: 130, to: 40, dur: 0.24, gain: 0.3 });
        this._tone({ type: 'sawtooth', freq: 330 * lift, to: 880 * lift, dur: 0.4, gain: 0.1, delay: 0.06 });
        return;
      }
      if (kind === 'chip') {
        const notes = [0, 7, 12, 16, 19];
        for (let i = 0; i < notes.length; i++) {
          this._tone({ type: 'square', freq: 440 * lift * Math.pow(2, notes[i] / 12), dur: 0.09, gain: 0.09, delay: i * 0.07 });
        }
        return;
      }
      if (kind === 'fm') {
        this._fm({ freq: 260 * lift, to: 1600, ratio: 2.2, index: 1.9, dur: 0.46, gain: 0.15 });
        this._fm({ freq: 390 * lift, to: 1300, ratio: 3.4, index: 1.1, dur: 0.4, gain: 0.09, delay: 0.08 });
        return;
      }
      const notes = [0, 4, 7, 11];
      for (let i = 0; i < notes.length; i++) {
        this._tone({ type: 'triangle', freq: 523.25 * lift * Math.pow(2, notes[i] / 12), dur: 0.14, gain: 0.12, delay: i * 0.08 });
      }
      this._tone({ type: 'sine', freq: 2093, dur: 0.24, gain: 0.045, delay: 0.26 });
    };

    /* --- public API --- */
    SfxEngine.prototype.sync = function (settings) {
      try {
        settings = settings && typeof settings === 'object' ? settings : {};
        if (typeof settings.muted === 'boolean') this._muted = settings.muted;
        if (typeof settings.volume === 'number' && isFinite(settings.volume)) this._volume = clamp(settings.volume, 0, 1);
        if (this._master && this._ctx) {
          const target = this._muted ? 0 : this._volume;
          const t = num(this._ctx.currentTime, 0);
          try {
            if (this._master.gain.setTargetAtTime) this._master.gain.setTargetAtTime(target, t, 0.01);
            else this._master.gain.value = target;
          } catch (e) {
            try { this._master.gain.value = target; } catch (e2) { /* ignore */ }
          }
        }
      } catch (e) { /* never throw */ }
      return this;
    };
    SfxEngine.prototype.unlock = function () {
      try {
        if (this._dead) return this;
        const ctx = this._ensure();
        if (ctx && ctx.state === 'suspended' && typeof ctx.resume === 'function') {
          const p = ctx.resume();
          if (p && typeof p.catch === 'function') p.catch(function () { /* ignore */ });
        }
      } catch (e) { /* never throw */ }
      return this;
    };
    SfxEngine.prototype.hit = function (opts) {
      try {
        if (this._dead || this._muted) return this;
        opts = opts && typeof opts === 'object' ? opts : {};
        const t = nowMs();
        const gap = 1000 / 14;
        if (t - this._lastHit < gap) {
          this._queued = Math.min(6, this._queued + 1);
          return this;
        }
        this._lastHit = t;
        const boost = this._queued > 0 ? Math.min(0.35, this._queued * 0.08) : 0;
        this._queued = 0;
        const level = clamp(int(opts.level, 1), 1, 7);
        this._hitVoice(soundKind(String(opts.presetId || '')), level, boost);
      } catch (e) { /* never throw */ }
      return this;
    };
    SfxEngine.prototype.milestone = function (opts) {
      try {
        if (this._dead || this._muted) return this;
        opts = opts && typeof opts === 'object' ? opts : {};
        this._milestoneVoice(soundKind(String(opts.presetId || '')), clamp(int(opts.level, 1), 1, 7));
      } catch (e) { /* never throw */ }
      return this;
    };
    SfxEngine.prototype.breakCombo = function (opts) {
      try {
        if (this._dead || this._muted) return this;
        opts = opts && typeof opts === 'object' ? opts : {};
        this._breakVoice(soundKind(String(opts.presetId || '')));
      } catch (e) { /* never throw */ }
      return this;
    };
    SfxEngine.prototype.settle = function (opts) {
      try {
        if (this._dead || this._muted) return this;
        opts = opts && typeof opts === 'object' ? opts : {};
        this._settleVoice(soundKind(String(opts.presetId || '')), clamp(int(opts.combo, 0), 0, 400));
      } catch (e) { /* never throw */ }
      return this;
    };
    SfxEngine.prototype.dispose = function () {
      try {
        this._dead = true;
        const nodes = (this._nodes || []).slice();
        for (let i = 0; i < nodes.length; i++) {
          try { this._releaseNode(nodes[i], true); } catch (e) { /* ignore */ }
        }
        this._nodes = [];
      } catch (e) { /* never throw */ }
      try {
        const ctx = this._ctx;
        const master = this._master;
        this._ctx = null;
        this._master = null;
        try { if (master && typeof master.disconnect === 'function') master.disconnect(); } catch (e) { /* ignore */ }
        if (ctx && typeof ctx.close === 'function') {
          const p = ctx.close();
          if (p && typeof p.catch === 'function') p.catch(function () { /* ignore */ });
        }
      } catch (e) { /* never throw */ }
      return this;
    };

    /* --- 10. character specs + public table --- */
    const SPECS = CHARACTERS.map(function (character) {
      return {
        id: character.id,
        label: character.label,
        hint: character.hint,
        accent: character.accent,
        accent2: character.accent2,
        accent3: character.accent3,
        ink: character.ink,
        word: character.word,
        css: BASE_CSS + CHAR_CSS + charCss(character),
        sound: character.sound
      };
    });
    const PRESETS = SPECS.map(function (spec) {
      return {
        id: spec.id,
        label: spec.label,
        hint: spec.hint,
        accent: spec.accent,
        accent2: spec.accent2,
        accent3: spec.accent3,
        ink: spec.ink,
        css: spec.css,
        sound: spec.sound,
        Arena: makeArena(spec),
        Badge: makeBadge(spec),
        Preview: makePreview(spec),
        Icon: makeIcon(spec)
      };
    });
    const STYLE_BY_ID = {};
    for (let i = 0; i < PRESETS.length; i++) STYLE_BY_ID[PRESETS[i].id] = PRESETS[i].css;
    /** CSS text for one preset id ('' when unknown), for style injection. */
    function styleById(id) {
      return STYLE_BY_ID[id] || '';
    }
    return { PRESETS: PRESETS, styleById: styleById, SfxEngine: SfxEngine };
  }
  global.createComboFx = createComboFx;
})(typeof window !== 'undefined' ? window : globalThis);