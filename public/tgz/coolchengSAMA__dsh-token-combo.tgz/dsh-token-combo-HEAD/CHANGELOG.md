# Changelog

All notable changes to Token Combo are documented here. The plugin is installed from a
local bundle (`@local/dsh-token-combo`), so versions are bumped in `package.json`.

## 2.7.5 — 2026-11-05

### Changed

- Renamed the user-facing plugin title: English **Token Combo** (was “Token Combo Arena”),
  Chinese **词元连击** (was “Token Combo AI 娘连击”). The sidebar/console label follows the Chinese
  name (was “连击竞技场”). Package id, Cordis row id, RPC channel and slot ids are unchanged, so
  existing installs keep upgrading normally. Character/AI-girl descriptions remain in the body copy.

## 2.7.4 — 2026-11-05

### Fixed

- The click-through switch felt delayed because the desktop HUD applied its state on a 500 ms
  asynchronous poll (worst case ≈1 s). The poll interval is now 150 ms, so toggling capture/click-
  through is reflected in roughly ≤0.3 s; the stale-HUD self-close threshold was widened to keep the
  same ~12 s grace period.

## 2.7.3 — 2026-11-05

### Fixed

- Interactive desktop HUD (click-through off) now captures mouse input over its content instead of
  merely swallowing buttons: an almost invisible alpha=1 topmost window is shown over the dashed
  bounds, so background applications no longer receive hover/click/wheel events in that area. It is
  hidden in click-through mode, follows the HUD while dragging/scaling, does not activate or appear
  in the taskbar, and the native hook still owns dragging and hover-outline state.

## 2.7.2 — 2026-11-05

### Fixed

- Desktop HUD hover outline works again: CSS `:hover` never fires reliably in the layered
  transparent WebView2 host window, so the native mouse hook now reports `IsHovering` and PS1
  forwards it to the page through `window.__TC_HOVER_STATE__` (setting `data-hover`), the same
  bridge already used for dragging. Hovering shows the dashed outline, dragging keeps it, and
  click-through does not show it. No DSH restart is needed for this change: close and reopen the
  desktop HUD so the new PS1/DLL/page are loaded.

## 2.7.1 — 2026-11-05

### Added

- `node scripts/build-client.mjs --check` (and README/dev-check documentation) verifies that
  the committed `client.js` matches the current `src/` without writing.
- Package manifest now includes this changelog; README documents the full Host config table.

### Fixed

- Removed the unreachable legacy preset code from `src/fx.js` (rhythm/fighting/arcade/cyber CSS
  and render branches, unused sound mappings, dead `pct`/`title` fields), shrinking the client
  bundle by roughly 20 KiB; `compactNum` now rounds before choosing its K/M/B bracket so
  `9999.5 → 10K`, `999999 → 1M`, `999999999 → 1B` (never `10000` / `1000K` / `1000M`).
- Host desktop-HUD hard cap is now enforced for running conversation roots too (oldest root is
  evicted at 64), so snapshots cannot grow without bound from concurrent agents.
- Desktop HUD hotkeys reject modifier-less letter/digit bindings (only F1–F12 may be bare) and
  keep retrying on system conflicts; the hint text documents the commit-on-blur/Enter behavior.
- Native helper DLL was rebuilt from a slimmed source: unused global system-cursor replacement
  code (the riskiest part of the helper) is gone; the exported surface used by the PowerShell
  host is unchanged, and click-through leaves the underlying app's cursor alone.
- Removed the dead `token-combo:host-locale` storage write and aligned the HUD page's fallback
  padding with the runtime value (30 px per side, so 310 = 250 HUD + 60 padding).
- The HUD host now fetches `/hud/state` through an asynchronous `HttpClient` task instead of a
  blocking `Invoke-RestMethod` on the WPF dispatcher thread; state application still happens on the
  UI thread, but drag/hotkeys/render are never stalled by a slow Host. Poll failures keep the
  rate-limited log and self-close after repeated failures.
- Client counters now round before choosing their K/M/B bracket as well (`formatTokens`), so the
  console/HUD never shows `10000` or `1000K`; the reset-confirm timer is cleared on unmount (the
  console no longer runs an unused 1 s ticker), segmented controls expose `aria-pressed`, and the
  sidebar live icon also respects the `低动态` preference.
- Double-clicking the in-window HUD now collapses it to the small pill (the previously dead
  `overlayCollapsed` branch); clicking the pill expands it again. Unused i18n strings and the
  duplicated character/string metadata in `/hud/state` were removed, and the HUD window size is now
  derived from named constants (`250 + 2 * 30 = 310`).

## 2.7.0 — 2026-11-05

### Added

- **Multi-agent combo aggregation**: the Host folds a conversation root and every
  subagent/teammate session below it (`SessionHeader.parentSession` / `origin: 'subagent'`)
  into one game session. All agents share one combo, stage ladder, score and token counters;
  child turns no longer reset the combo, and only the root turn end settles the group.
- Snapshot entries expose `members: string[]`; snapshot gains `hud: { open, interactive }`.
- Desktop HUD ready handshake (`/hud/sync?ready=1`): `hud open` waits for the page and falls
  back to the window overlay when it never becomes ready.
- Chat dock entry restyled as a compact statistics pill aligned with the shipped DSH dock
  pills (idle hidden, session-scoped `sessionId`).
- HUD page hover/drag dashed outline; desktop HUD restores its saved position (clamped to the
  visible screen), resizes from the requested scale, recomputes drag bounds on DPI changes,
  and does not force a hand cursor in click-through mode.
- `node scripts/build-client.mjs --check` verifies the committed bundle without writing.
- CHANGELOG and package test/build documentation.

### Fixed

- In-window client: fresh installs now start at 100% scale / 25% volume (`DEFAULT_PREFS`
  fallbacks instead of `clamp` minimum); trial mode no longer demotes a tier immediately
  after a level-up; HUD locale follows the DSH locale instead of a hardcoded Chinese value;
  hotkeys commit on blur/Enter instead of every keystroke; stats persistence is debounced
  with page-hide flush; cross-window `storage` synchronization; reduced-motion covers core
  HUD animations; `bridge.reset()` rejection is handled.
- Host: official token accounting reconciles max usage per `(member, turn, step)` so a
  mid-stream plugin reload cannot double count and retries cannot hide final usage; clock
  rollback no longer stalls the 80 ms publish coalescer; `probe` endpoint removed; `breakMs`
  default matches the documented 5000 ms; poll with a stale future cursor answers
  immediately; empty `reset.sessionId` no longer resets every conversation; hard cap
  (64) bounds conversation roots even when they are running.
- Desktop HUD: tree-kill on close (no lingering `msedgewebview2`), process exit publishes
  state so the console flips `desktopHud` off, `Ctrl+Alt+T` click-through state is written
  back to the console, and a stale HUD closes itself after repeated failed polls (Host
  restart); position memory is now actually read back; hotkey registration retries on
  conflict and ignores modifier-less bindings (only F1–F12 allowed bare).
- SfxEngine: tracked audio nodes are removed on `onended` (with a 256-node hard cap and a
  complete FM graph disconnect), fixing unbounded memory growth on long-running HUD pages.
- Build: `client.js` is generated atomically (temp file → syntax check → rename).
- Docs/contracts updated for all of the above (README, INTERFACE, test counts).

## 2.6.0 and earlier

Character presets, window/desktop HUDs, composer dock, settings, SFX engine, WebView2
desktop window, drag hook, and click-through hotkeys. See the git log for details.
