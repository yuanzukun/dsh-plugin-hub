# 贡献说明

这是一个 Windows 上的 DeepSeek Harness 插件，目前处于公开测试阶段。欢迎提 Issue 和 PR。

## 环境

- Windows 10 / 11（x64）
- Node.js（只用于构建和测试）
- DeepSeek Harness Desktop；桌面悬浮窗需要 WebView2

## 本地开发

```text
node --check host/engine11.js
node host-test.mjs
node --check src/fx.js
node src/fx-test.mjs
node scripts/build-client.mjs        # 生成 client.js
node scripts/build-client.mjs --check
```

`client.js` 是生成文件，不要直接编辑。修改 `src/fx.js` 或 `src/client-core.js` 后重新运行构建脚本。

## 提交 Issue

- 使用仓库里的 Issue 模板；
- 附上 DSH 版本、Windows 版本、缩放比例和复现步骤；
- 桌面悬浮窗问题可附 `%APPDATA%\token-combo-webview2.log`；
- **不要上传对话内容、API Key 或其他隐私信息**，截图请先打码。

## 提交 PR

- 一个 PR 只做一件事，避免混入无关格式化；
- 按 PR 模板填写验证结果；
- UI/HUD 改动请附打码截图；
- 涉及桌面悬浮窗（WPF/WebView2/原生 DLL）的改动，请说明 Windows 实机验证情况；
- 不要提交本机路径、日志、缓存和临时文件。
