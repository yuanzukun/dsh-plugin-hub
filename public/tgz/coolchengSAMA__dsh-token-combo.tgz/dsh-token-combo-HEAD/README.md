<p align="center">
  <a href="https://github.com/coolchengSAMA/dsh-token-combo"><img src="icon.svg" width="88" alt="Token Combo"></a>
</p>

<h1 align="center">Token Combo · 词元连击</h1>

<p align="center">把 DeepSeek Harness 的流式 Token 输出变成街机连击 HUD。</p>

<p align="center">
  <a href="https://github.com/coolchengSAMA/dsh-token-combo/releases/tag/v2.7.5-beta.1"><img alt="release" src="https://img.shields.io/badge/release-v2.7.5--beta.1-blue"></a>
  <a href="https://github.com/coolchengSAMA/dsh-token-combo/blob/main/LICENSE"><img alt="license" src="https://img.shields.io/badge/license-MIT-green"></a>
  <a href="https://github.com/coolchengSAMA/dsh-token-combo#环境"><img alt="platform" src="https://img.shields.io/badge/platform-Windows%2010%2F11-0078D4"></a>
  <a href="https://github.com/coolchengSAMA/dsh-token-combo"><img alt="harness" src="https://img.shields.io/badge/DeepSeek%20Harness-plugin-4D7CFF"></a>
  <a href="https://github.com/coolchengSAMA/dsh-token-combo/releases"><img alt="status" src="https://img.shields.io/badge/status-public%20beta-orange"></a>
</p>

<p align="center">
  <a href="https://github.com/coolchengSAMA/dsh-token-combo/stargazers"><img alt="stars" src="https://img.shields.io/github/stars/coolchengSAMA/dsh-token-combo"></a>
  <a href="https://github.com/coolchengSAMA/dsh-token-combo/issues"><img alt="issues" src="https://img.shields.io/github/issues/coolchengSAMA/dsh-token-combo"></a>
  <a href="https://github.com/coolchengSAMA/dsh-token-combo/commits/main"><img alt="last commit" src="https://img.shields.io/github/last-commit/coolchengSAMA/dsh-token-combo"></a>
  <a href="https://github.com/coolchengSAMA/dsh-token-combo/releases"><img alt="downloads" src="https://img.shields.io/github/downloads/coolchengSAMA/dsh-token-combo/total"></a>
</p>

> **公开测试版**，仅支持 Windows。功能与兼容性可能变化，欢迎反馈问题。

<p align="center">
  <img src="screenshots/characters.png" alt="七位大模型角色" width="100%">
</p>

<p align="center">
  <img src="screenshots/hud.png" alt="桌面悬浮窗" width="388">
</p>

## 功能

- **实时连击**：每段可见 Token 命中 +1，按字符估算词元数，累计分数
- **等级与倍率**：连击槽攒满升阶，空闲会回退/掉级，最低级才会断连
- **七位角色**：DeepSeek / ChatGPT / Claude / Gemini / GLM / Grok / Qwen
- **三个显示位置**，各自独立开关：
  - 窗口悬浮窗
  - 聊天栏紧凑徽章
  - 桌面透明悬浮窗
- **桌面悬浮窗**：置顶、透明、可拖动、悬停/拖动虚线、位置记忆、鼠标穿透
- **多智能体汇总**：同一对话里的 subagent / teammate 共享一条连击
- 音效、低动态、试炼预览、内容对齐、80%–240% 缩放

## 环境

- Windows 10 / 11（x64）
- DeepSeek Harness Desktop
- 桌面悬浮窗需要 WebView2 Runtime（Windows 11 通常自带）

## 安装

1. 下载或克隆本仓库到本地目录
2. 在 DeepSeek Harness 中安装本地插件包，target 指向本仓库目录：

   ```text
   plugin_manager install_bundle
     target: <本仓库路径>
   ```

3. 重启 DSH，从侧边栏打开「词元连击」

## 使用

- 在控制台里分别开关窗口悬浮窗、聊天栏和桌面悬浮窗
- 桌面悬浮窗默认 `Ctrl+Alt+T` 切换鼠标穿透，`Ctrl+Alt+X` 关闭
- 双击窗口悬浮窗可收起为小徽章，点击徽章展开
- 偏好和悬浮窗位置保存在浏览器本地

## 从源码构建

```text
node scripts/build-client.mjs        # 生成 client.js 并做语法检查
node scripts/build-client.mjs --check
node host-test.mjs
node src/fx-test.mjs
```

## 说明

- 只在本机运行，不发送网络请求，不保存对话内容
- 桌面悬浮窗是独立 WebView2 窗口，常驻内存约 120MB
- 仅支持 Windows；桌面悬浮窗需要 WebView2
- 当前为测试版，暂无自动更新，升级需替换本地目录并重启 DSH

## 贡献

- 遇到问题请使用仓库的 Issue 模板，附上复现步骤和版本信息
- 提交 PR 前请阅读 [CONTRIBUTING.md](CONTRIBUTING.md)，并按 PR 模板填写验证结果
- **请不要上传对话内容、API Key 或其他隐私信息**，截图请先打码

## 许可证

代码使用 **MIT** 许可证；`art/` 中的角色图片不包含在 MIT 许可范围内，详见 `NOTICE`。

## 反馈

请通过 GitHub Issues 反馈，并附上：

- DSH 版本、Windows 版本、缩放比例
- 复现步骤和截图
- 桌面悬浮窗问题可附 `%APPDATA%\token-combo-webview2.log`

请勿在 Issue 里贴对话内容或 API Key。
