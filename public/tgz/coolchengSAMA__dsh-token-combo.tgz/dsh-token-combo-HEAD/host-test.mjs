#!/usr/bin/env node
/**
 * Token Combo — Host harness.
 *
 * Exercises `host/engine11.js` with a fake Cordis Context and a fake clock:
 * listener registration, per-delta combo math, level/milestone crosses, official
 * token accounting, settle banking, break detection, reset, long-poll wakeup and
 * every RPC envelope. Runs with plain `node host-test.mjs`; prints one PASS line
 * per check and exits non-zero on any failure.
 */

import { apply, inject } from './host/engine11.js'

let passCount = 0
let failCount = 0

function pass(name) {
  passCount += 1
  console.log(`PASS ${name}`)
}

function fail(name, error) {
  failCount += 1
  console.log(`FAIL ${name}: ${error !== null && error !== undefined && error.message !== undefined ? error.message : String(error)}`)
}

/** Throwing assertion helper. */
function expect(condition, message) {
  if (!condition) throw new Error(message)
}

/** Strict scalar equality with a readable message. */
function eq(actual, expected, label) {
  if (actual !== expected) throw new Error(`${label}: expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`)
}

/** Structural equality via canonical JSON (object key order is part of the contract). */
function deepEqual(actual, expected, label) {
  const left = JSON.stringify(actual)
  const right = JSON.stringify(expected)
  if (left !== right) throw new Error(`${label}: expected ${right}, got ${left}`)
}

/** Walk a value and prove it is plain JSON data (no class instances / non-finite numbers). */
function assertPlainJson(value, label, depth = 0) {
  if (depth > 10) throw new Error(`${label}: nesting too deep`)
  if (value === null) return
  const type = typeof value
  if (type === 'number') {
    expect(Number.isFinite(value), `${label}: non-finite number`)
    return
  }
  if (type === 'string' || type === 'boolean') return
  expect(type === 'object', `${label}: unexpected ${type}`)
  const isArray = Array.isArray(value)
  if (!isArray) {
    const prototype = Object.getPrototypeOf(value)
    expect(prototype === Object.prototype || prototype === null, `${label}: not a plain object`)
  }
  for (const key of Object.keys(value)) {
    expect(value[key] !== undefined, `${label}.${key}: undefined value is not JSON-safe`)
    assertPlainJson(value[key], `${label}.${key}`, depth + 1)
  }
}

/* --------------------------------------------------------------- fake Host */

const clock = { value: 1_730_000_000_000 }
const advance = (ms) => {
  clock.value += ms
  return clock.value
}

const SESSION_KEYS = [
  'id',
  'running',
  'phase',
  'combo',
  'maxCombo',
  'bestCombo',
  'level',
  'multiplier',
  'nextLevelAt',
  'tier',
  'hits',
  'score',
  'tokens',
  'turn',
  'step',
  'lastHitAt',
  'energy',
  'activeAt',
  'startedAt',
  'milestone',
  'milestoneSeq',
  'hitSeq',
  'breakSeq',
  'settleSeq',
  'startSeq',
  'completedTurns',
  'members',
]

function createFakeCtx() {
  const listeners = new Map()
  const effects = new Map()
  const intervals = []
  const ctx = {
    logger: { info() {}, warn() {}, error() {}, debug() {} },
    webServer: {
      register(route) {
        ctx.route = route
        return () => {
          if (ctx.route === route) ctx.route = null
        }
      },
    },
    on(name, listener, options) {
      const list = listeners.get(name) ?? []
      list.push({ listener, options })
      listeners.set(name, list)
      return () => {
        const index = list.findIndex((entry) => entry.listener === listener)
        if (index >= 0) list.splice(index, 1)
      }
    },
    effect(fn, label) {
      const disposer = fn()
      const dispose = typeof disposer === 'function' ? disposer : () => {}
      effects.set(label ?? `effect-${effects.size}`, dispose)
      return dispose
    },
    interval(callback, ms) {
      intervals.push({ callback, ms })
      return () => {
        const index = intervals.findIndex((entry) => entry.callback === callback)
        if (index >= 0) intervals.splice(index, 1)
      }
    },
  }
  ctx.listeners = listeners
  ctx.effects = effects
  ctx.intervals = intervals
  ctx.handler = null
  ctx.channel = null
  ctx.route = null
  ctx.emit = (name, ...args) => {
    const list = listeners.get(name)
    if (list === undefined || list.length === 0) throw new Error(`no listener registered for ${name}`)
    for (const entry of list) entry.listener(...args)
  }
  ctx.tick = () => {
    for (const entry of [...intervals]) entry.callback()
  }
  /** Drive one connection-RPC call through the plugin's own prefix route. */
  ctx.call = (endpoint, payload, signal) =>
    new Promise((resolve, reject) => {
      const route = ctx.route
      if (route === null || route === undefined) {
        reject(new Error('no rpc route installed'))
        return
      }
      const body = Buffer.from(JSON.stringify({ type: 'client-request', rpcId: 'test-rpc', method: endpoint, payload }))
      const reqListeners = new Map()
      const req = {
        method: 'POST',
        url: `${route.path}/${endpoint}`,
        headers: { 'content-type': 'application/json' },
        on(event, callback) {
          reqListeners.set(event, callback)
          return req
        },
      }
      let settled = false
      const finish = (value, error) => {
        if (settled) return
        settled = true
        if (error !== undefined) reject(error)
        else resolve(value)
      }
      const res = {
        on(event, callback) {
          if (event === 'close') res.onClose = callback
          return res
        },
        writeHead(status, headers) {
          res.status = status
          res.headers = headers
        },
        end(text) {
          try {
            const parsed = JSON.parse(String(text))
            if (parsed !== null && typeof parsed === 'object' && parsed.type === 'server-response') finish(parsed.result)
            else finish(parsed)
          } catch (error) {
            finish(undefined, error)
          }
        },
      }
      if (signal !== undefined && signal !== null) {
        if (signal.aborted === true) {
          finish(undefined, new Error('aborted'))
          return
        }
        if (typeof signal.addEventListener === 'function') {
          signal.addEventListener(
            'abort',
            () => {
              if (typeof res.onClose === 'function') res.onClose()
              finish(undefined, new Error('aborted'))
            },
            { once: true },
          )
        }
      }
      Promise.resolve().then(() => {
        const onData = reqListeners.get('data')
        if (onData !== undefined) onData(body)
        const onEnd = reqListeners.get('end')
        if (onEnd !== undefined) onEnd()
      })
      try {
        const pending = route.handler(req, res)
        if (pending !== undefined && pending !== null && typeof pending.catch === 'function') pending.catch((error) => finish(undefined, error))
      } catch (error) {
        finish(undefined, error)
      }
    })
  ctx.disposeAll = () => {
    for (const dispose of [...effects.values()].reverse()) {
      try {
        dispose()
      } catch {
        /* disposal must not throw */
      }
    }
  }
  return ctx
}

const ctx = createFakeCtx()
apply(ctx, {
  publishIntervalMs: 80,
  breakMs: 6_000,
  idleMemoryMs: 3_600_000,
  now: () => clock.value,
})

const AGENT = { id: 'S1', session: { id: 'S1' } }

/**
 * Every harness emission advances the fake clock past `publishIntervalMs` first
 * so the coalesced publisher flushes synchronously and revision assertions are
 * deterministic (a real Host would simply publish on its own timer).
 */
const step = () => advance(100)

const streamFrame = (frame) => {
  step()
  ctx.emit('agent/assistant-stream', { agent: AGENT, frame })
}
const textDelta = (text, attemptId = 'a1', index = 0) =>
  streamFrame({
    type: 'chunk',
    attemptId,
    revision: index + 1,
    index,
    time: clock.value,
    chunk: { type: 'text-delta', index: 0, text },
  })
const sessionEvent = (type, data) => {
  step()
  ctx.emit('session/event', { id: 'S1' }, { type, seq: 1, time: clock.value, data })
}
const agentStatus = (status) => {
  step()
  ctx.emit('agent/status', { agent: AGENT, status })
}

const hello = async () => {
  const envelope = await ctx.call('hello')
  expect(envelope.ok === true, 'hello envelope must be ok:true')
  expect(envelope.value !== undefined && envelope.value !== null, 'hello envelope must carry a value')
  return envelope.value
}
const firstSession = (value) => {
  expect(Array.isArray(value.snapshot.sessions), 'snapshot.sessions must be an array')
  expect(value.snapshot.sessions.length > 0, 'snapshot.sessions must not be empty')
  return value.snapshot.sessions[0]
}

/* ------------------------------------------------------------------ checks */

await (async () => {
  try {
    deepEqual(inject, ['timer', 'webServer'], 'inject must be ["timer", "webServer"]')
    eq(ctx.route.path, '/token-combo', 'rpc route path')
    eq(ctx.route.kind, 'prefix', 'rpc route kind')
    expect(typeof ctx.route.handler === 'function', 'rpc route handler must be installed')
    eq(ctx.intervals.length, 1, 'exactly one tick interval')
    expect(ctx.intervals[0].ms > 0, 'tick interval must be positive')
    for (const name of ['agent/assistant-stream', 'session/event', 'agent/status', 'agent/disposed']) {
      const list = ctx.listeners.get(name)
      expect(list !== undefined && list.length === 1, `${name} listener must be registered once`)
      eq(list[0].options.global, true, `${name} listener must be global`)
    }
    pass('plugin registration: inject, channel, listeners, tick')
  } catch (error) {
    fail('plugin registration: inject, channel, listeners, tick', error)
  }
})()

await (async () => {
  try {
    advance(100)
    sessionEvent('turn/start', { turn: 1 })
    agentStatus('running')
    streamFrame({ type: 'start', attemptId: 'a1', revision: 1, turn: 1, step: 1 })
    const started = await hello()
    eq(started.snapshot.serverTime, clock.value, 'serverTime uses the injected clock')
    const startedSession = firstSession(started)
    eq(startedSession.phase, 'building', 'phase after start frame')
    eq(startedSession.startSeq, 1, 'startSeq after start frame')
    eq(startedSession.running, true, 'running after start frame')
    const revisionBeforeDeltas = started.revision

    for (let index = 0; index < 9; index += 1) {
      advance(100)
      textDelta('hello world', 'a1', index)
    }
    const afterNine = await hello()
    const nine = firstSession(afterNine)
    eq(nine.combo, 9, 'combo after 9 deltas')
    eq(nine.hits, 9, 'hits after 9 deltas')
    eq(nine.level, 1, 'level after 9 deltas')
    eq(nine.tier, 'READY', 'tier after 9 deltas')
    eq(nine.milestone, 0, 'no milestone after 9 deltas')
    expect(nine.tokens.live > 0, 'live estimate after 9 deltas must be > 0')

    advance(100)
    textDelta('hello world', 'a1', 9)
    const afterTen = await hello()
    const ten = firstSession(afterTen)
    eq(ten.combo, 10, 'combo after 10th delta')
    eq(ten.hits, 10, 'hits after 10th delta')
    eq(ten.hitSeq, 10, 'hitSeq after 10th delta')
    eq(ten.maxCombo, 10, 'maxCombo after 10th delta')
    eq(ten.level, 1, 'level after 10th delta (LV2 needs 30 hits)')
    eq(ten.tier, 'READY', 'tier after 10th delta')
    eq(ten.multiplier, 1, 'multiplier after 10th delta')
    eq(ten.nextLevelAt, 30, 'nextLevelAt at level 1')
    eq(ten.milestone, 10, 'milestone crossed at 10')
    eq(ten.milestoneSeq, 1, 'milestoneSeq after first milestone')
    eq(ten.phase, 'building', 'phase while streaming')
    eq(ten.tokens.live, 28, 'live estimate (10 * 2.75, rounded)')
    eq(ten.tokens.turn, 28, 'turn tokens while building = live')
    eq(ten.tokens.output, 0, 'no official output before usage')
    eq(ten.tokens.total, 28, 'total tokens while building = live')
    eq(ten.score, 28, 'score = sum(estimate * multiplier) rounded')
    expect(ten.energy > 0.3 && ten.energy < 0.36, `stage meter 10/30 filled, got ${ten.energy}`)
    expect(ten.lastHitAt > 0, 'lastHitAt recorded')
    expect(ten.startedAt > 0, 'startedAt recorded')
    expect(afterTen.revision > revisionBeforeDeltas, 'revision grows as the combo grows')

    const polled = await ctx.call('poll', { since: 0, timeoutMs: 1_000 })
    expect(polled.ok === true, 'poll envelope must be ok:true')
    expect(polled.value.revision > 0, 'poll must return a revision')
    eq(polled.value.snapshot.revision, polled.value.revision, 'poll revision matches snapshot.revision')
    eq(firstSession(polled.value).combo, 10, 'poll snapshot is current')
    pass('stream deltas: combo, level stays 1 at 10, milestone 10, token estimate, poll')
  } catch (error) {
    fail('stream deltas: combo, level 2 at 10, milestone 10, token estimate, poll', error)
  }
})()

await (async () => {
  try {
    advance(100)
    streamFrame({
      type: 'chunk',
      attemptId: 'a1',
      revision: 11,
      index: 10,
      time: clock.value,
      chunk: { type: 'usage', usage: { inputTokens: 500, outputTokens: 321, totalTokens: 821 } },
    })
    const afterUsage = await hello()
    const usage = firstSession(afterUsage)
    eq(usage.phase, 'building', 'usage chunk keeps the attempt building')
    expect(usage.tokens.live > 0, 'live estimate survives the usage chunk')

    advance(100)
    streamFrame({
      type: 'end',
      attemptId: 'a1',
      revision: 12,
      index: 11,
      outcome: { kind: 'committed', eventType: 'assistant/message', seq: 7 },
    })
    const afterEnd = await hello()
    const settled = firstSession(afterEnd)
    eq(settled.phase, 'settled', 'phase after committed end')
    eq(settled.settleSeq, 1, 'settleSeq after committed end')
    eq(settled.bestCombo, 10, 'bestCombo banked on settle')
    eq(settled.maxCombo, 10, 'maxCombo preserved')
    eq(settled.tokens.output, 321, 'official turn output from usage chunk')
    eq(settled.tokens.live, 0, 'live estimate cleared at end')
    eq(settled.tokens.turn, 321, 'tokens.turn = official + live')
    eq(settled.tokens.total, 321, 'tokens.total = session official + live')
    eq(afterEnd.snapshot.totals.outputTokens, 321, 'totals.outputTokens aggregates official output')
    eq(afterEnd.snapshot.totals.sessions, 1, 'totals.sessions')
    eq(afterEnd.snapshot.totals.bestCombo, 10, 'totals.bestCombo')
    eq(afterEnd.snapshot.totals.hits, 10, 'totals.hits')
    pass('usage + committed end: official tokens, settled phase, banking, settleSeq')
  } catch (error) {
    fail('usage + committed end: official tokens, settled phase, banking, settleSeq', error)
  }
})()

await (async () => {
  try {
    sessionEvent('turn/end', {})
    advance(10_000) // beyond breakMs (6000) and the settle hold window
    ctx.tick()
    const afterIdle = await hello()
    const idle = firstSession(afterIdle)
    eq(idle.phase, 'idle', 'phase after settle hold')
    eq(idle.combo, 0, 'combo cleared after settle hold')
    eq(idle.energy, 0, 'meter empty after settle hold')
    eq(idle.breakSeq, 0, 'no break after a settled turn')
    eq(idle.maxCombo, 10, 'maxCombo preserved')
    eq(idle.bestCombo, 10, 'bestCombo banked')
    eq(idle.hits, 10, 'hits preserved (monotonic)')
    eq(idle.tokens.output, 321, 'official output preserved')
    pass('settle idle: combo cleared after settle hold, no phantom break')
  } catch (error) {
    fail('settle idle: combo cleared after settle hold, no phantom break', error)
  }
})()

await (async () => {
  try {
    advance(200)
    sessionEvent('turn/start', { turn: 2 })
    streamFrame({ type: 'start', attemptId: 'meter', turn: 2, step: 1 })
    for (let index = 0; index < 5; index += 1) textDelta('abcd', 'meter', index + 1)
    const full = firstSession(await hello())
    expect(full.energy > 0.1 && full.energy < 0.25, `stage meter fills 5/30, got ${full.energy}`)
    const before = full.energy
    advance(500)
    ctx.tick()
    const mid = firstSession(await hello())
    expect(mid.phase === 'building', 'still building mid-drain')
    expect(mid.energy > 0 && mid.energy < before, `meter drains over time, ${before} -> ${mid.energy}`)
    advance(1_000)
    ctx.tick()
    const broken = firstSession(await hello())
    eq(broken.phase, 'broken', 'meter empty breaks the combo')
    eq(broken.combo, 0, 'combo cleared at break')
    eq(broken.energy, 0, 'meter empty at break')
    eq(broken.breakSeq, 1, 'breakSeq after metered break')
    pass('combo meter: refills on hits, drains during idle, breaks at zero')
  } catch (error) {
    fail('combo meter: refills on hits, drains during idle, breaks at zero', error)
  }
})()

await (async () => {
  try {
    advance(200)
    sessionEvent('turn/start', { turn: 3 })
    streamFrame({ type: 'start', attemptId: 'demote', turn: 3, step: 1 })
    for (let index = 0; index < 30; index += 1) textDelta('abcd', 'demote', index + 1)
    let entry = firstSession(await hello())
    eq(entry.level, 2, '30 hits fill stage 1 and advance to LV2')
    eq(entry.energy, 0, 'new stage starts empty')
    for (let index = 0; index < 5; index += 1) textDelta('abcd', 'demote', 100 + index)
    entry = firstSession(await hello())
    eq(entry.level, 2, 'mid-stage hits keep LV2')
    expect(entry.energy > 0.02 && entry.energy < 0.2, `mid-stage meter 5/60, got ${entry.energy}`)
    advance(250)
    ctx.tick()
    entry = firstSession(await hello())
    expect(entry.level === 2 && entry.energy > 0, 'meter still draining at LV2')
    advance(250)
    ctx.tick()
    entry = firstSession(await hello())
    eq(entry.level, 1, 'empty mid-stage drops one multiplier step')
    eq(entry.energy, 1, 'the previous stage meter restarts full')
    expect(entry.combo > 0 && entry.phase !== 'broken', 'combo survives the demotion')
    advance(6_000)
    ctx.tick()
    entry = firstSession(await hello())
    eq(entry.level, 1, 'lowest stage reached')
    eq(entry.phase, 'broken', 'lowest stage meter empty breaks the combo')
    eq(entry.combo, 0, 'combo cleared after final break')
    eq(entry.breakSeq, 2, 'second break recorded')
    pass('stage ladder: fill advances, mid-stage drain demotes one step at a time, lowest step breaks')
  } catch (error) {
    fail('stage ladder: fill advances, mid-stage drain demotes one step at a time, lowest step breaks', error)
  }
})()

await (async () => {
  try {
    const beforeReset = await hello()
    const reset = await ctx.call('reset', { sessionId: 'S1' })
    expect(reset.ok === true, 'reset envelope must be ok:true')
    expect(reset.value.revision > beforeReset.revision, 'reset must publish a fresh revision')
    eq(reset.value.snapshot.revision, reset.value.revision, 'reset revision matches snapshot.revision')
    const entry = firstSession(reset.value)
    eq(entry.combo, 0, 'reset combo')
    eq(entry.maxCombo, 0, 'reset maxCombo')
    eq(entry.bestCombo, 0, 'reset bestCombo')
    eq(entry.hits, 0, 'reset hits')
    eq(entry.score, 0, 'reset score')
    eq(entry.milestone, 0, 'reset milestone')
    eq(entry.tokens.output, 0, 'reset official output')
    eq(entry.tokens.live, 0, 'reset live estimate')
    eq(entry.tokens.turn, 0, 'reset turn tokens')
    eq(entry.tokens.total, 0, 'reset total tokens')
    eq(entry.phase, 'idle', 'reset phase')
    eq(entry.energy, 0, 'reset combo meter')
    eq(entry.hitSeq, 50, 'hitSeq stays monotonic across reset')
    eq(entry.breakSeq, 2, 'breakSeq stays monotonic across reset')
    const polled = await ctx.call('poll', { since: beforeReset.revision, timeoutMs: 1_000 })
    expect(polled.ok === true, 'poll after reset must be ok:true')
    eq(polled.value.revision, reset.value.revision, 'poll sees the reset revision')
    pass('reset endpoint: zeroed counters, fresh revision, publish')
  } catch (error) {
    fail('reset endpoint: zeroed counters, fresh revision, publish', error)
  }
})()

await (async () => {
  try {
    const unknown = await ctx.call('nope', {})
    eq(unknown.ok, false, 'unknown endpoint ok:false')
    eq(unknown.error.code, 'token-combo/unknown-endpoint', 'unknown endpoint error code')
    expect(typeof unknown.error.message === 'string' && unknown.error.message.length > 0, 'unknown endpoint message')
    deepEqual(unknown.error.details, {}, 'unknown endpoint details is a plain record')

    const undefinedEndpoint = await ctx.call(undefined, null)
    eq(undefinedEndpoint.ok, false, 'undefined endpoint ok:false')

    const garbage = await ctx.call('poll', { since: 'not-a-number', timeoutMs: 'also-not' })
    expect(garbage.ok === true, 'poll tolerates a malformed payload')

    // Malformed listener payloads must be swallowed by the plugin, never thrown.
    ctx.emit('agent/assistant-stream', null)
    ctx.emit('agent/assistant-stream', {})
    ctx.emit('agent/assistant-stream', { agent: null, frame: null })
    ctx.emit('agent/assistant-stream', { agent: AGENT, frame: { type: 'chunk', chunk: null } })
    ctx.emit('agent/assistant-stream', { agent: AGENT, frame: { type: 'end', outcome: null } })
    ctx.emit('session/event', null, null)
    ctx.emit('session/event', { id: 'S1' }, { type: 'turn/end' })
    ctx.emit('session/event', {}, {})
    ctx.emit('agent/status', { agent: null, status: 'idle' })
    ctx.emit('agent/status', null)
    ctx.emit('agent/disposed', null)
    ctx.emit('agent/disposed', {})

    const afterGarbage = await hello()
    expect(afterGarbage.revision >= 1, 'hello still answers after malformed traffic')
    pass('robustness: unknown endpoint, malformed payloads, listener containment')
  } catch (error) {
    fail('robustness: unknown endpoint, malformed payloads, listener containment', error)
  }
})()

await (async () => {
  try {
    advance(100)
    streamFrame({ type: 'start', attemptId: 'a2', revision: 1, turn: 2, step: 1 })
    advance(100)
    sessionEvent('turn/start', { turn: 2 })
    const beforeMilestones = firstSession(await hello()).milestoneSeq
    let seen = 0
    for (let index = 0; index < 25; index += 1) {
      advance(100)
      textDelta('hello world', 'a2', index)
      seen += 1
    }
    eq(seen, 25, 'emitted 25 deltas')
    const afterTwentyFive = await hello()
    const entry = firstSession(afterTwentyFive)
    eq(entry.combo, 25, 'combo after 25 deltas')
    eq(entry.hits, 25, 'hits after 25 deltas')
    eq(entry.milestone, 25, 'milestone crossed at 25')
    eq(entry.milestoneSeq, beforeMilestones + 2, 'milestoneSeq grows by 10 and 25 in this climb')
    eq(entry.level, 1, 'level stays 1 at combo 25 (LV2 needs 30 hits)')
    eq(entry.tier, 'READY', 'tier at combo 25')
    eq(entry.tokens.live, 69, 'live estimate after 25 deltas (25 * 2.75)')
    eq(entry.phase, 'building', 'phase building at combo 25')
    pass('milestone progression: 25 crosses once, level stays 1')
  } catch (error) {
    fail('milestone progression: 25 crosses once, level stays 2', error)
  }
})()

await (async () => {
  try {
    const before = await hello()
    advance(100)
    const parked = ctx.call('poll', { since: before.revision, timeoutMs: 5_000 })
    // The waiter must resolve on the next publish, without waiting for the timeout.
    advance(100)
    textDelta('wake up', 'a2', 99)
    const woke = await parked
    expect(woke.ok === true, 'parked poll envelope must be ok:true')
    expect(woke.value.revision > before.revision, 'parked poll resolved with a newer revision')
    eq(woke.value.snapshot.revision, woke.value.revision, 'parked poll snapshot revision')
    eq(firstSession(woke.value).combo, 26, 'parked poll snapshot is current')

    const immediate = await ctx.call('poll', { since: 0, timeoutMs: 25_000 })
    expect(immediate.ok === true, 'poll with stale cursor returns immediately')

    const currentRevision = (await hello()).revision
    const startedAt = Date.now()
    const timedOut = await ctx.call('poll', { since: currentRevision, timeoutMs: 25 })
    expect(timedOut.ok === true, 'timed-out poll envelope must be ok:true')
    expect(timedOut.value.revision === currentRevision, 'timed-out poll returns the current revision')
    expect(Date.now() - startedAt >= 15, 'poll honored the timeout window')
    expect(Date.now() - startedAt < 4_000, 'poll timeout is not wildly late')

    // A cursor from a previous Host incarnation (larger than the current
    // revision) must answer immediately instead of parking for the timeout.
    const futureStartedAt = Date.now()
    const future = await ctx.call('poll', { since: 1_000_000_000, timeoutMs: 25 })
    expect(future.ok === true, 'future-cursor poll envelope must be ok:true')
    expect(Date.now() - futureStartedAt < 15, 'future-cursor poll answers immediately')
    pass('long poll: wakes on publish, immediate for stale cursors, honors timeout')
  } catch (error) {
    fail('long poll: wakes on publish, immediate for stale cursors, honors timeout', error)
  }
})()

await (async () => {
  try {
    const multiClock = { value: clock.value + 1_000 }
    const multi = createFakeCtx()
    apply(multi, { publishIntervalMs: 0, breakMs: 60_000, idleMemoryMs: 3_600_000, now: () => multiClock.value })
    const mstep = () => {
      multiClock.value += 10
    }
    const frameFor = (id, frame) => multi.emit('agent/assistant-stream', { agent: { id, session: { id } }, frame })
    const deltaFor = (id, text) => {
      mstep()
      frameFor(id, { type: 'chunk', attemptId: `${id}-a1`, revision: 1, index: 0, chunk: { type: 'text-delta', text } })
    }
    const eventFor = (id, type, data) => {
      mstep()
      multi.emit('session/event', { id }, { type, seq: 1, time: multiClock.value, data })
    }

    // A1: official usage arrives only on the durable message event.
    eventFor('A1', 'turn/start', { turn: 1 })
    mstep()
    frameFor('A1', { type: 'start', attemptId: 'A1-a1', turn: 1, step: 1 })
    for (let index = 0; index < 3; index += 1) deltaFor('A1', 'hello world')
    eventFor('A1', 'assistant/message', { turn: 1, step: 1, usage: { outputTokens: 100 } })
    mstep()
    frameFor('A1', { type: 'end', attemptId: 'A1-a1', index: 3, outcome: { kind: 'committed' } })

    // A2: the same official usage is reported by chunk AND message — counted once.
    eventFor('A2', 'turn/start', { turn: 1 })
    mstep()
    frameFor('A2', { type: 'start', attemptId: 'A2-a1', turn: 1, step: 1 })
    for (let index = 0; index < 2; index += 1) deltaFor('A2', 'hello world')
    mstep()
    frameFor('A2', { type: 'chunk', attemptId: 'A2-a1', revision: 9, index: 2, chunk: { type: 'usage', usage: { outputTokens: 40 } } })
    eventFor('A2', 'assistant/message', { turn: 1, step: 1, usage: { outputTokens: 40 } })
    mstep()
    frameFor('A2', { type: 'end', attemptId: 'A2-a1', index: 3, outcome: { kind: 'committed' } })

    const value = (await multi.call('hello')).value
    eq(value.snapshot.sessions.length, 2, 'two tracked sessions')
    eq(value.snapshot.sessions[0].id, 'A2', 'sessions sorted by most recent activity')
    const a2 = value.snapshot.sessions[0]
    const a1 = value.snapshot.sessions[1]
    eq(a1.tokens.output, 100, 'A1 official output from the durable message event')
    eq(a2.tokens.output, 40, 'A2 official output counted once (chunk + message dedupe)')
    eq(a1.phase, 'settled', 'A1 settled')
    eq(a2.phase, 'settled', 'A2 settled')
    eq(value.snapshot.totals.outputTokens, 140, 'totals aggregate official output')
    eq(value.snapshot.totals.hits, 5, 'totals aggregate hits')
    eq(value.snapshot.totals.bestCombo, 3, 'totals bestCombo is the max banked session combo')
    eq(value.snapshot.totals.sessions, 2, 'totals session count')

    const single = await multi.call('reset', { sessionId: 'A1' })
    const a1Reset = single.value.snapshot.sessions.find((entry) => entry.id === 'A1')
    const a2Kept = single.value.snapshot.sessions.find((entry) => entry.id === 'A2')
    eq(a1Reset.hits, 0, 'reset with sessionId zeroes that session')
    eq(a2Kept.hits, 2, 'reset with sessionId leaves other sessions alone')

    const all = await multi.call('reset', undefined)
    for (const entry of all.value.snapshot.sessions) {
      eq(entry.hits, 0, `reset without payload zeroes hits for ${entry.id}`)
      eq(entry.tokens.output, 0, `reset without payload zeroes output for ${entry.id}`)
      eq(entry.combo, 0, `reset without payload zeroes combo for ${entry.id}`)
    }
    multi.disposeAll()
    eq(multi.route, null, 'multi-session context disposal removes its route')
    pass('multi-session: aggregation, sorting, dedupe, per-session and global reset')
  } catch (error) {
    fail('multi-session: aggregation, sorting, dedupe, per-session and global reset', error)
  }
})()

await (async () => {
  try {
    const kindsClock = { value: clock.value + 2_000 }
    const kinds = createFakeCtx()
    apply(kinds, { publishIntervalMs: 0, breakMs: 60_000, now: () => kindsClock.value })
    const kindsAgent = { id: 'K1', session: { id: 'K1' } }
    const emitFrame = (frame) => {
      kindsClock.value += 10
      kinds.emit('agent/assistant-stream', { agent: kindsAgent, frame })
    }
    emitFrame({ type: 'start', attemptId: 'K1-a1', turn: 1, step: 1 })
    // Empty deltas must not become hits or spend estimates.
    emitFrame({ type: 'chunk', chunk: { type: 'text-delta', text: '' } })
    emitFrame({ type: 'chunk', chunk: { type: 'tool-call-delta', id: 't1', name: 'read', argumentsDelta: '' } })
    emitFrame({ type: 'chunk', chunk: { type: 'reasoning-delta', text: 'thinking!' } })
    emitFrame({ type: 'chunk', chunk: { type: 'tool-call-delta', id: 't1', argumentsDelta: '{"a":1}' } })
    emitFrame({ type: 'chunk', chunk: { type: 'text-delta', text: '你好' } })
    // Non-counting chunk kinds must be ignored without throwing.
    emitFrame({ type: 'chunk', chunk: { type: 'block-start', index: 0, block: { type: 'text' } } })
    emitFrame({ type: 'chunk', chunk: { type: 'block-end', index: 0, block: { type: 'text', text: '你好' } } })
    emitFrame({ type: 'chunk', chunk: { type: 'finish', reason: 'stop' } })

    const kindsValue = (await kinds.call('hello')).value
    const entry = kindsValue.snapshot.sessions[0]
    eq(entry.hits, 3, 'only non-empty deltas count as hits')
    eq(entry.combo, 3, 'combo from reasoning/tool-arg/text deltas')
    eq(entry.level, 1, 'level stays 1 at combo 3')
    // 9 other chars / 4 + 7 other chars / 4 + 2 CJK chars * 0.8 = 2.25 + 1.75 + 1.6 = 5.6
    eq(entry.tokens.live, 6, 'token estimate mixes ASCII and CJK deltas')
    eq(entry.score, 6, 'score uses the level multiplier at each hit')
    eq(entry.phase, 'building', 'still building after non-counting chunks')
    kinds.disposeAll()
    eq(kinds.route, null, 'delta-kind context disposal removes its route')
    pass('delta kinds: reasoning/tool-arg hits, empty deltas ignored, CJK estimate')
  } catch (error) {
    fail('delta kinds: reasoning/tool-arg hits, empty deltas ignored, CJK estimate', error)
  }
})()

await (async () => {
  try {
    const aggClock = { value: clock.value + 5_000 }
    const agg = createFakeCtx()
    apply(agg, { publishIntervalMs: 0, breakMs: 60_000, idleMemoryMs: 3_600_000, now: () => aggClock.value })
    const ROOT_HEADER = { version: 4, id: 'R1', isSeeded: false, delegationDepth: 0 }
    const CHILD_HEADER = { version: 4, id: 'C1', parentSession: 'R1', isSeeded: false, origin: 'subagent', delegationDepth: 1 }
    const rootSession = { id: 'R1', header: ROOT_HEADER }
    const childSession = { id: 'C1', header: CHILD_HEADER }
    const rootAgent = { id: 'R1', session: { id: 'R1', header: ROOT_HEADER } }
    const childAgent = { id: 'C1', session: { id: 'C1', header: CHILD_HEADER } }
    const frameFor = (type, extra = {}) => ({ type, attemptId: 'agg', revision: 1, turn: 1, step: 1, ...extra })
    const emitFrame = (agent, frame) => {
      aggClock.value += 10
      agg.emit('agent/assistant-stream', { agent, frame })
    }
    const emitEvent = (session, type, data) => {
      aggClock.value += 10
      agg.emit('session/event', session, { type, seq: 1, time: aggClock.value, data })
    }
    const delta = (agent, text) => emitFrame(agent, frameFor('chunk', { chunk: { type: 'text-delta', text } }))
    const start = (agent, extra = {}) => emitFrame(agent, frameFor('start', extra))
    const end = (agent, outcome) => emitFrame(agent, frameFor('end', { index: 2, outcome }))
    const chat = async (label) => {
      const value = (await agg.call('hello')).value
      return { snapshot: value.snapshot, sessions: value.snapshot.sessions, label }
    }

    // Root turn with one root agent and one subagent/teammate session.
    emitEvent(rootSession, 'turn/start', { turn: 1 })
    start(rootAgent, { turn: 1, step: 1 })
    start(childAgent, { turn: 1, step: 1 })
    for (let index = 0; index < 3; index += 1) delta(rootAgent, 'root')
    for (let index = 0; index < 2; index += 1) delta(childAgent, 'child')
    let value = await chat('root + child')
    eq(value.sessions.length, 1, 'root and subagent fold into one game session')
    let entry = value.sessions[0]
    eq(entry.id, 'R1', 'the conversation root is the game session id')
    deepEqual(entry.members, ['R1', 'C1'], 'members lists the root and its subagent')
    eq(entry.combo, 5, 'hits from both agents share one combo')
    eq(entry.hits, 5, 'hits from both agents share one counter')

    // A subagent turn boundary must not reset the conversation's shared combo.
    emitEvent(childSession, 'turn/start', { turn: 2 })
    start(childAgent, { turn: 2, step: 1 })
    delta(childAgent, 'x')
    entry = (await chat('child turn/start')).sessions[0]
    eq(entry.combo, 6, 'a child turn/start keeps the shared combo')
    eq(entry.turn, 1, 'the shared turn number stays the root turn')

    // Child finishes while the root is still streaming: no settle burst yet.
    end(childAgent, { kind: 'committed', eventType: 'assistant/message', seq: 5 })
    emitEvent(childSession, 'turn/end', { turn: 2 })
    entry = (await chat('child end')).sessions[0]
    expect(entry.phase === 'building' || entry.phase === 'holding', 'a child end does not settle while the root attempt runs')
    eq(entry.settleSeq, 0, 'no settle burst for an intermediate child attempt')

    // Official usage from both members is summed; the root end settles once.
    emitEvent(childSession, 'assistant/message', { turn: 2, step: 1, usage: { outputTokens: 100 } })
    emitFrame(rootAgent, frameFor('chunk', { chunk: { type: 'usage', usage: { outputTokens: 50 } } }))
    end(rootAgent, { kind: 'committed', eventType: 'assistant/message', seq: 6 })
    entry = (await chat('usage')).sessions[0]
    eq(entry.tokens.output, 150, 'official usage from both members is summed')
    eq(entry.phase, 'settled', 'the last attempt of the group settles the combo')
    eq(entry.settleSeq, 1, 'the group settles exactly once')

    emitEvent(rootSession, 'turn/end', { turn: 1 })
    entry = (await chat('root turn/end')).sessions[0]
    eq(entry.settleSeq, 1, 'root turn/end extends the settle window without a second burst')
    eq(entry.bestCombo, 6, 'bestCombo banked on settle')

    // Next root turn resets the combo but keeps lifetime official usage.
    emitEvent(rootSession, 'turn/start', { turn: 2 })
    entry = (await chat('new root turn')).sessions[0]
    eq(entry.combo, 0, 'a new root turn resets the shared combo')
    eq(entry.level, 1, 'a new root turn resets the stage ladder')
    eq(entry.tokens.output, 0, 'a new root turn resets the turn token counter')
    eq(entry.tokens.total, 150, 'lifetime official usage survives the new turn')

    // One retried attempt must reconcile to its final usage, not the abandoned one.
    start(rootAgent, { turn: 2, step: 1 })
    emitFrame(rootAgent, frameFor('chunk', { chunk: { type: 'usage', usage: { outputTokens: 40 } } }))
    end(rootAgent, { kind: 'abandoned' })
    start(rootAgent, { turn: 2, step: 1 })
    emitFrame(rootAgent, frameFor('chunk', { chunk: { type: 'usage', usage: { outputTokens: 120 } } }))
    end(rootAgent, { kind: 'committed', eventType: 'assistant/message', seq: 9 })
    entry = (await chat('retry reconcile')).sessions[0]
    eq(entry.tokens.output, 120, 'retried attempt reconciles to the final usage (120), not 40')
    eq(entry.tokens.total, 270, 'retry delta is added to the lifetime total')

    // Reset with any member id resolves to the conversation root.
    await agg.call('reset', { sessionId: 'C1' })
    entry = (await chat('reset by child')).sessions[0]
    eq(entry.id, 'R1', 'reset keeps the root entry')
    eq(entry.hits, 0, 'reset by a subagent id zeroes the conversation root')
    eq(entry.tokens.total, 0, 'reset clears lifetime official usage of the tree')

    // Disposing the subagent keeps the root session alive.
    agg.emit('agent/disposed', { agent: childAgent })
    value = await chat('child disposed')
    eq(value.sessions.length, 1, 'root stays after its subagent is disposed')
    deepEqual(value.sessions[0].members, ['R1'], 'disposed subagent leaves the member list')
    agg.disposeAll()
    eq(agg.route, null, 'aggregate context disposal removes its route')

    // Plugin loaded mid-stream: an unattributed usage chunk must not double count.
    const midClock = { value: clock.value + 8_000 }
    const mid = createFakeCtx()
    apply(mid, { publishIntervalMs: 0, breakMs: 60_000, now: () => midClock.value })
    mid.emit('agent/assistant-stream', { agent: rootAgent, frame: frameFor('chunk', { chunk: { type: 'usage', usage: { outputTokens: 100 } } }) })
    mid.emit('session/event', rootSession, { type: 'assistant/message', seq: 1, time: midClock.value, data: { turn: 3, step: 2, usage: { outputTokens: 100 } } })
    let midEntry = (await mid.call('hello')).value.snapshot.sessions[0]
    eq(midEntry.tokens.output, 100, 'mid-stream load: usage without an attempt frame is counted once')
    mid.emit('agent/assistant-stream', { agent: childAgent, frame: frameFor('chunk', { chunk: { type: 'usage', usage: { outputTokens: 70 } } }) })
    mid.emit('agent/assistant-stream', { agent: childAgent, frame: frameFor('end', { index: 2, outcome: { kind: 'abandoned' } }) })
    midEntry = (await mid.call('hello')).value.snapshot.sessions[0]
    eq(midEntry.tokens.output, 170, 'an abandoned unattributed usage chunk is banked once at its end frame')
    mid.disposeAll()
    pass('subagent aggregation: shared combo, shared usage, retry reconcile, reset/dispose')
  } catch (error) {
    fail('subagent aggregation: shared combo, shared usage, retry reconcile, reset/dispose', error)
  }
})()

await (async () => {
  try {
    const capClock = { value: clock.value + 9_000 }
    const cap = createFakeCtx()
    apply(cap, { publishIntervalMs: 0, breakMs: 60_000, now: () => capClock.value })
    // 65 distinct live roots: the 64-session hard cap must evict the oldest root
    // (even though every one is "running") instead of growing the snapshot.
    for (let index = 0; index < 65; index += 1) {
      capClock.value += 10
      const id = `CAP${index}`
      cap.emit('agent/assistant-stream', {
        agent: { id, session: { id } },
        frame: { type: 'chunk', attemptId: 'cap', revision: 1, index: 0, chunk: { type: 'text-delta', text: 'a' } },
      })
    }
    const capped = (await cap.call('hello')).value.snapshot
    eq(capped.sessions.length, 64, 'hard cap bounds the number of tracked roots')
    expect(!capped.sessions.some((entry) => entry.id === 'CAP0'), 'the least recently active root is evicted at the cap')
    cap.disposeAll()
    pass('hard cap: running conversation roots stay bounded')
  } catch (error) {
    fail('hard cap: running conversation roots stay bounded', error)
  }
})()

await (async () => {
  try {
    const live = await hello()
    assertPlainJson(live, 'hello envelope')
    const entry = firstSession(live)
    deepEqual(Object.keys(entry), SESSION_KEYS, 'session entry keys follow INTERFACE.md order')
    deepEqual(Object.keys(live.snapshot), ['revision', 'engine', 'serverTime', 'sessions', 'totals', 'hud'], 'snapshot keys')
    deepEqual(live.snapshot.hud, { open: false, interactive: true }, 'hud state defaults before a desktop HUD exists')
    deepEqual(Object.keys(entry.tokens), ['turn', 'live', 'output', 'total'], 'tokens keys')
    deepEqual(Object.keys(live.snapshot.totals), ['outputTokens', 'hits', 'bestCombo', 'sessions'], 'totals keys')
    expect(JSON.stringify(live).length < 20_000, 'snapshot stays small')

    advance(100)
    ctx.emit('agent/disposed', { agent: AGENT })
    const afterDispose = await hello()
    eq(afterDispose.snapshot.sessions.length, 0, 'agent/disposed removes the session')
    deepEqual(afterDispose.snapshot.totals, { outputTokens: 0, hits: 0, bestCombo: 0, sessions: 0 }, 'totals empty after dispose')
    pass('snapshot shape: JSON-safe, exact keys, bounded size, disposal cleanup')
  } catch (error) {
    fail('snapshot shape: JSON-safe, exact keys, bounded size, disposal cleanup', error)
  }
})()

await (async () => {
  try {
    ctx.disposeAll()
    eq(ctx.route, null, 'dispose removes the RPC route')
    eq(ctx.intervals.length, 0, 'dispose removes the tick interval')
    pass('dispose removes channel and interval')
  } catch (error) {
    fail('dispose removes channel and interval', error)
  }
})()

await (async () => {
  try {
    const bare = createFakeCtx()
    apply(bare) // no config at all: defaults must parse defensively
    const envelope = await bare.call('hello')
    expect(envelope.ok === true, 'default-config hello must be ok:true')
    eq(envelope.value.revision, 1, 'default-config initial revision')
    deepEqual(envelope.value.snapshot.sessions, [], 'default-config starts with no sessions')
    eq(envelope.value.snapshot.totals.outputTokens, 0, 'default-config totals')
    const polled = await bare.call('poll', { since: 0, timeoutMs: 10 })
    expect(polled.ok === true, 'default-config poll must be ok:true')
    const unknown = await bare.call('definitely-not-an-endpoint')
    eq(unknown.ok, false, 'default-config unknown endpoint ok:false')
    const probe = await bare.call('probe')
    eq(probe.ok, false, 'the removed probe endpoint answers ok:false')
    const hud = await bare.call('hud', { action: 'status' })
    expect(hud.ok === true, 'hud status envelope must be ok:true')
    expect(hud.value.open === false, 'hud status starts closed')
    expect(typeof hud.value.prefs === 'object' && hud.value.prefs !== null, 'hud status carries prefs')
    const hudBefore = (await bare.call('hello')).value
    const interactive = await bare.call('hud', { action: 'interactive', interactive: false })
    expect(interactive.ok === true, 'hud interactive envelope must be ok:true')
    const hudAfter = (await bare.call('hello')).value
    eq(hudAfter.snapshot.hud.interactive, false, 'hud interactive change is published in the snapshot')
    expect(hudAfter.revision > hudBefore.revision, 'hud interactive change bumps the revision')
    const hudPoll = await bare.call('poll', { since: hudBefore.revision, timeoutMs: 10 })
    expect(hudPoll.ok === true && hudPoll.value.snapshot.hud.interactive === false, 'in-window clients see the HUD state change')
    bare.disposeAll()
    pass('default config: apply without options and still answer envelopes')
  } catch (error) {
    fail('default config: apply without options and still answer envelopes', error)
  }
})()

console.log('')
console.log(`token-combo host-test: ${passCount} passed, ${failCount} failed`)
process.exitCode = failCount === 0 ? 0 : 1
