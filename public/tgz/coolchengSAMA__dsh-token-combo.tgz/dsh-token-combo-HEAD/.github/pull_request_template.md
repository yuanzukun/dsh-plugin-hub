## 改动内容

<!-- 简要说明这个 PR 做了什么、为什么需要它 -->

## 关联 Issue

<!-- 例如：Closes #12 -->

## 验证

- [ ] `node --check` 相关文件通过
- [ ] `node host-test.mjs` 通过
- [ ] `node src/fx-test.mjs` 通过
- [ ] `node scripts/build-client.mjs --check` 通过
- [ ] 涉及 UI/HUD 的改动附带截图（截图已打码）
- [ ] 已更新 README / CHANGELOG（如需要）

## 说明

- [ ] 没有提交本机路径、日志、聊天内容、API Key 等敏感信息
- [ ] 没有手动修改生成的 `client.js`（改 `src/` 后重新构建）
- [ ] 桌面悬浮窗相关改动说明已在 Windows 实机验证
