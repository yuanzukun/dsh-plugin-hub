param(
  [Parameter(Mandatory = $true)][string]$Url,
  [Parameter(Mandatory = $true)][string]$Token,
  [Parameter(Mandatory = $true)][string]$PageUrl,
  [Parameter(Mandatory = $false)][double]$Scale = 1
)

$ErrorActionPreference = 'Stop'
$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$logPath = Join-Path $env:APPDATA 'token-combo-webview2.log'
function Write-HudLog([string]$message) {
  try { Add-Content -Path $logPath -Value ((Get-Date).ToString('s') + ' ' + $message) } catch { }
}
try { Remove-Item $logPath -Force -ErrorAction SilentlyContinue } catch { }
Write-HudLog 'start'
$webviewDir = Join-Path $dir 'webview2'
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Xaml
try { Add-Type -AssemblyName System.Net.Http } catch { }

$env:PATH = $webviewDir + ';' + $env:PATH
[System.Reflection.Assembly]::Load([System.IO.File]::ReadAllBytes((Join-Path $webviewDir 'TokenComboNative.dll'))) | Out-Null
[System.Reflection.Assembly]::Load([System.IO.File]::ReadAllBytes((Join-Path $webviewDir 'Microsoft.Web.WebView2.Core.dll'))) | Out-Null
[System.Reflection.Assembly]::Load([System.IO.File]::ReadAllBytes((Join-Path $webviewDir 'Microsoft.Web.WebView2.Wpf.dll'))) | Out-Null

$GWL_EXSTYLE = -20
$WS_EX_TRANSPARENT = 0x20
$WS_EX_LAYERED = 0x80000
$WS_EX_NOACTIVATE = 0x08000000
$WS_EX_TOOLWINDOW = 0x00000080
# Keep in sync with hud/standalone.js: the HUD content is 250*scale wide and the
# page pads it by 30*scale per side, so the window is 310*scale wide. The height
# additionally leaves room for the bottom burst ticker.
$HUD_BASE_WIDTH = 250
$HUD_PAD = 30
$HUD_WINDOW_WIDTH = $HUD_BASE_WIDTH + 2 * $HUD_PAD
$HUD_WINDOW_HEIGHT = 220

$script:clickThrough = $false
$script:hwnd = [IntPtr]::Zero
$script:hotkeyActions = @{}
$script:hotkeySig = ''
$script:hotkeyLogSig = ''
$script:dragUiActive = $false
$script:hoverUiActive = $false
$script:lastSyncErrorAt = 0
$script:syncFailures = 0
$script:overlayCssRect = $null
$script:inputWindow = $null
$script:inputWindowSig = ''
$script:inputWindowShown = $false
$script:posFile = Join-Path $env:APPDATA 'token-combo-hud-webview2.json'
$script:httpClient = $null
$script:stateTask = $null

function Parse-Hotkey([string]$text) {
  if ([string]::IsNullOrWhiteSpace($text)) { return $null }
  $value = $text.Trim()
  if ($value -eq 'off' -or $value -eq 'none' -or $value -eq '-') { return $null }
  $mods = 0
  $vk = 0
  foreach ($raw in ($value -split '\+')) {
    $part = $raw.Trim()
    if ($part -eq '') { continue }
    $lower = $part.ToLower()
    if ($lower -eq 'ctrl' -or $lower -eq 'control') { $mods = $mods -bor 0x0002 }
    elseif ($lower -eq 'alt') { $mods = $mods -bor 0x0001 }
    elseif ($lower -eq 'shift') { $mods = $mods -bor 0x0004 }
    elseif ($lower -eq 'win' -or $lower -eq 'windows') { $mods = $mods -bor 0x0008 }
    elseif ($lower -eq 'space') { $vk = 0x20 }
    elseif ($lower -eq 'tab') { $vk = 0x09 }
    elseif ($lower -eq 'enter') { $vk = 0x0D }
    elseif ($lower -eq 'esc' -or $lower -eq 'escape') { $vk = 0x1B }
    elseif ($part.ToUpper() -match '^F([1-9]|1[0-2])$') { $vk = 0x70 + ([int]$Matches[1] - 1) }
    elseif ($part.Length -eq 1) {
      $upper = $part.ToUpper()
      if ($upper -match '^[A-Z0-9]$') { $vk = [int][char]$upper }
    }
  }
  if ($vk -eq 0) { return $null }
  return @{ mods = $mods; vk = $vk }
}

# A modifier-less letter/digit would be registered system-wide and swallow normal
# typing; only F1-F12 are accepted without a modifier.
function Test-HotkeySafe($hotkey) {
  if ($null -eq $hotkey) { return $false }
  if ($hotkey.mods -ne 0) { return $true }
  return ($hotkey.vk -ge 0x70 -and $hotkey.vk -le 0x7B)
}

function Apply-Hotkeys($prefs) {
  if ($null -eq $prefs -or $script:hwnd -eq [IntPtr]::Zero) { return }
  $enabled = $prefs.hotkeysEnabled -ne $false
  $sig = 'off'
  if ($enabled) { $sig = [string]$prefs.hotkeyToggle + '|' + [string]$prefs.hotkeyClose }
  if ($sig -eq $script:hotkeySig) { return }
  foreach ($id in 1, 2) {
    try { [void][TokenComboNative]::UnregisterHotKey($script:hwnd, $id) } catch { }
    $script:hotkeyActions.Remove($id)
  }
  if (-not $enabled) {
    $script:hotkeySig = $sig
    return
  }
  $toggle = Parse-Hotkey ([string]$prefs.hotkeyToggle)
  $close = Parse-Hotkey ([string]$prefs.hotkeyClose)
  if ($null -ne $toggle -and -not (Test-HotkeySafe $toggle)) {
    Write-HudLog ('hotkey needs a modifier or F1-F12: ' + [string]$prefs.hotkeyToggle)
    $toggle = $null
  }
  if ($null -ne $close -and -not (Test-HotkeySafe $close)) {
    Write-HudLog ('hotkey needs a modifier or F1-F12: ' + [string]$prefs.hotkeyClose)
    $close = $null
  }
  if ($null -ne $toggle -and $null -ne $close -and $toggle.mods -eq $close.mods -and $toggle.vk -eq $close.vk) {
    $close = $null
    Write-HudLog ('hotkeys conflict: ' + $sig)
  }
  $toggleOk = $true
  $closeOk = $true
  if ($null -ne $toggle) {
    $toggleOk = [TokenComboNative]::RegisterHotKey($script:hwnd, 1, $toggle.mods, $toggle.vk)
    if ($toggleOk) { $script:hotkeyActions[1] = 'toggle' }
  }
  if ($null -ne $close) {
    $closeOk = [TokenComboNative]::RegisterHotKey($script:hwnd, 2, $close.mods, $close.vk)
    if ($closeOk) { $script:hotkeyActions[2] = 'close' }
  }
  if ($toggleOk -and $closeOk) {
    $script:hotkeySig = $sig
    $script:hotkeyLogSig = ''
  } else {
    # Keep the signature uncached so a conflicting system-wide hotkey is retried
    # on later state polls, but log the failure only once per preference value.
    $script:hotkeySig = ''
    if ($script:hotkeyLogSig -ne $sig) {
      $script:hotkeyLogSig = $sig
      Write-HudLog ('hotkey registration failed: ' + $sig)
    }
  }
}

function Sync-HudState([string]$query) {
  try {
    $syncUrl = ($Url -replace '/hud/state$', '/hud/sync') + $query
    Invoke-RestMethod -Uri $syncUrl -Headers @{ 'x-token-combo-token' = $Token } -TimeoutSec 1 | Out-Null
  } catch { }
}
function Sync-Interactive {
  $flag = if ($script:clickThrough) { '0' } else { '1' }
  Sync-HudState ('?interactive=' + $flag)
}
function Sync-HudReady { Sync-HudState '?ready=1' }

function Save-Position {
  try {
    @{ left = [Math]::Round($window.Left, 1); top = [Math]::Round($window.Top, 1) } | ConvertTo-Json -Compress | Set-Content -Path $script:posFile -Encoding UTF8
  } catch { }
}

function Read-Position {
  try {
    if (-not (Test-Path -LiteralPath $script:posFile)) { return $null }
    $saved = Get-Content -LiteralPath $script:posFile -Raw | ConvertFrom-Json
    $left = [double]$saved.left
    $top = [double]$saved.top
    if ([double]::IsNaN($left) -or [double]::IsNaN($top) -or [double]::IsInfinity($left) -or [double]::IsInfinity($top)) { return $null }
    $vsLeft = [System.Windows.SystemParameters]::VirtualScreenLeft
    $vsTop = [System.Windows.SystemParameters]::VirtualScreenTop
    $vsWidth = [System.Windows.SystemParameters]::VirtualScreenWidth
    $vsHeight = [System.Windows.SystemParameters]::VirtualScreenHeight
    if ($left -lt $vsLeft -or $top -lt $vsTop) { return $null }
    if ($left -gt ($vsLeft + $vsWidth - 80) -or $top -gt ($vsTop + $vsHeight - 80)) { return $null }
    return @{ left = $left; top = $top }
  } catch {
    return $null
  }
}

function Clamp-WindowPosition {
  try {
    $vsLeft = [System.Windows.SystemParameters]::VirtualScreenLeft
    $vsTop = [System.Windows.SystemParameters]::VirtualScreenTop
    $vsWidth = [System.Windows.SystemParameters]::VirtualScreenWidth
    $vsHeight = [System.Windows.SystemParameters]::VirtualScreenHeight
    $maxLeft = $vsLeft + $vsWidth - [Math]::Max(80, $window.Width * 0.4)
    $maxTop = $vsTop + $vsHeight - [Math]::Max(60, $window.Height * 0.4)
    $window.Left = [Math]::Max($vsLeft, [Math]::Min($window.Left, $maxLeft))
    $window.Top = [Math]::Max($vsTop, [Math]::Min($window.Top, $maxTop))
  } catch { }
}

# Recompute the physical drag bounds from the last CSS rect with the CURRENT DPI
# (moving the window to a monitor with a different scale changes the factor).
function Update-DragBounds {
  try {
    if ($null -eq $script:overlayCssRect -or $script:hwnd -eq [IntPtr]::Zero) { return }
    $dpi = 1.0
    $source = [System.Windows.PresentationSource]::FromVisual($window)
    if ($null -ne $source) { $dpi = $source.CompositionTarget.TransformToDevice.M11 }
    $pad = 2
    $rect = $script:overlayCssRect
    $left = [int][Math]::Round(([double]$rect.left + $pad) * $dpi)
    $top = [int][Math]::Round(([double]$rect.top + $pad) * $dpi)
    $width = [int][Math]::Round(([double]$rect.width + $pad * 2) * $dpi)
    $height = [int][Math]::Round(([double]$rect.height + $pad * 2) * $dpi)
    [TokenComboNative]::SetDragBounds($left, $top, $width, $height)
    Write-HudLog ('drag bounds ' + $left + ',' + $top + ' ' + $width + 'x' + $height + ' dpi=' + $dpi)
  } catch { }
}

function Apply-Interactive([bool]$interactive) {
  $script:clickThrough = -not $interactive
  try { [TokenComboNative]::SetClickThrough($script:clickThrough) } catch { }
  if ($script:clickThrough) {
    # Click-through means no hover affordance while the pointer is over the HUD.
    $script:hoverUiActive = $false
    try {
      if ($null -ne $view -and $null -ne $view.CoreWebView2) {
        $null = $view.CoreWebView2.ExecuteScriptAsync('window.__TC_HOVER_STATE__ && window.__TC_HOVER_STATE__(false)')
      }
    } catch { }
  }
  if ($script:hwnd -eq [IntPtr]::Zero) { return }
  try {
    $ex = [TokenComboNative]::GetWindowLong($script:hwnd, $GWL_EXSTYLE)
    if ($script:clickThrough) { $ex = $ex -bor $WS_EX_TRANSPARENT -bor $WS_EX_LAYERED }
    else { $ex = $ex -band (-bnot $WS_EX_TRANSPARENT) }
    [void][TokenComboNative]::SetWindowLong($script:hwnd, $GWL_EXSTYLE, $ex)
  } catch { }
  Update-InputWindow
}

# While interactive, an almost-invisible (alpha = 1) topmost window covers the
# dashed content bounds and swallows mouse input. Without it the layered HUD
# window lets mouse moves reach the app underneath, so background apps keep
# reacting to hover even though clicks inside the bounds are already hooked.
function Update-InputWindow {
  try {
    if ($null -eq $script:inputWindow) { return }
    if ($script:clickThrough -or $null -eq $script:overlayCssRect -or $script:hwnd -eq [IntPtr]::Zero -or -not $window.IsVisible) {
      if ($script:inputWindowShown) {
        $script:inputWindow.Hide()
        $script:inputWindowShown = $false
        Write-HudLog 'input window hidden'
      }
      return
    }
    $rect = $script:overlayCssRect
    $pad = 6
    $left = $window.Left + [double]$rect.left - $pad
    $top = $window.Top + [double]$rect.top - $pad
    $width = [Math]::Max(1.0, [double]$rect.width + $pad * 2)
    $height = [Math]::Max(1.0, [double]$rect.height + $pad * 2)
    $sig = '' + $left + ',' + $top + ',' + $width + ',' + $height
    if ($sig -ne $script:inputWindowSig) {
      $script:inputWindowSig = $sig
      $script:inputWindow.Left = $left
      $script:inputWindow.Top = $top
      $script:inputWindow.Width = $width
      $script:inputWindow.Height = $height
    }
    $script:inputWindow.Cursor = if ([TokenComboNative]::IsDragging) { [System.Windows.Input.Cursors]::SizeAll } else { [System.Windows.Input.Cursors]::Hand }
    if (-not $script:inputWindowShown) {
      if ($null -eq $script:inputWindow.Owner) { $script:inputWindow.Owner = $window }
      $script:inputWindow.Show()
      $script:inputWindowShown = $true
      Write-HudLog 'input window shown'
    }
  } catch {
    try {
      if ($null -ne $script:inputWindow -and $script:inputWindow.IsVisible) { $script:inputWindow.Hide() }
    } catch { }
    $script:inputWindowShown = $false
  }
}

$startupScale = 1
if ($Scale -ge 0.8 -and $Scale -le 2.4) { $startupScale = $Scale }
$initialWidth = [Math]::Round($HUD_WINDOW_WIDTH * $startupScale)
$initialHeight = [Math]::Round($HUD_WINDOW_HEIGHT * $startupScale)
$workArea = [System.Windows.SystemParameters]::WorkArea
$savedPosition = Read-Position

$window = New-Object System.Windows.Window
$window.Title = 'Token Combo HUD'
$window.WindowStyle = 'None'
$window.AllowsTransparency = $true
$window.Background = [System.Windows.Media.Brushes]::Transparent
$window.Topmost = $true
$window.ShowInTaskbar = $false
$window.ResizeMode = 'NoResize'
$window.Width = $initialWidth
$window.Height = $initialHeight
$window.WindowStartupLocation = 'Manual'
if ($null -ne $savedPosition) {
  $window.Left = $savedPosition.left
  $window.Top = $savedPosition.top
  Clamp-WindowPosition
} else {
  $window.Left = $workArea.Right - $initialWidth - 18
  $window.Top = $workArea.Bottom - $initialHeight - 18
}

$view = New-Object Microsoft.Web.WebView2.Wpf.WebView2
$view.DefaultBackgroundColor = [System.Drawing.Color]::Transparent
$props = New-Object Microsoft.Web.WebView2.Wpf.CoreWebView2CreationProperties
$props.UserDataFolder = (Join-Path $env:LOCALAPPDATA 'token-combo-wv2-hud')
$view.CreationProperties = $props
$window.Content = $view

# Input-capture window: alpha = 1 keeps it visually invisible while Windows
# still delivers mouse messages to it (layered windows with alpha = 0 are
# click-through). It is shown only while the HUD is interactive.
$script:inputWindow = New-Object System.Windows.Window
$script:inputWindow.Title = 'Token Combo input'
$script:inputWindow.WindowStyle = 'None'
$script:inputWindow.AllowsTransparency = $true
$script:inputWindow.Background = New-Object System.Windows.Media.SolidColorBrush([System.Windows.Media.Color]::FromArgb(1, 0, 0, 0))
$script:inputWindow.Topmost = $true
$script:inputWindow.ShowInTaskbar = $false
$script:inputWindow.ShowActivated = $false
$script:inputWindow.Focusable = $false
$script:inputWindow.ResizeMode = 'NoResize'
$script:inputWindow.Cursor = [System.Windows.Input.Cursors]::Hand
$script:inputWindow.Add_SourceInitialized({
  try {
    $helper = New-Object System.Windows.Interop.WindowInteropHelper($script:inputWindow)
    $handle = $helper.Handle
    if ($handle -ne [IntPtr]::Zero) {
      $ex = [TokenComboNative]::GetWindowLong($handle, $GWL_EXSTYLE)
      $ex = $ex -bor $WS_EX_NOACTIVATE -bor $WS_EX_TOOLWINDOW
      [void][TokenComboNative]::SetWindowLong($handle, $GWL_EXSTYLE, $ex)
    }
  } catch { }
})

# Non-blocking HUD state source: the UI timer starts/collects an asynchronous GET
# instead of running Invoke-RestMethod on the WPF dispatcher thread.
try {
  $script:httpClient = New-Object System.Net.Http.HttpClient
  $script:httpClient.Timeout = [TimeSpan]::FromSeconds(3)
  $script:httpClient.DefaultRequestHeaders.Add('x-token-combo-token', $Token)
} catch {
  Write-HudLog ('http client failed: ' + $_.Exception.Message)
  $script:httpClient = $null
}

$view.add_CoreWebView2InitializationCompleted({
  param($sender, $e)
  Write-HudLog ('webview2 init success=' + $e.IsSuccess + ' err=' + $e.InitializationException)
  if (-not $e.IsSuccess) { $window.Close(); return }
  $view.CoreWebView2.Settings.AreDefaultContextMenusEnabled = $false
  $view.CoreWebView2.Settings.AreDevToolsEnabled = $false
  $view.CoreWebView2.Settings.IsZoomControlEnabled = $false
  $view.CoreWebView2.Settings.IsWebMessageEnabled = $true
  $view.CoreWebView2.add_WebMessageReceived({
    param($s2, $e)
    try {
      $message = $e.WebMessageAsJson | ConvertFrom-Json
      if ($message.type -eq 'ready') {
        Write-HudLog 'page ready'
        Sync-HudReady
      } elseif ($message.type -eq 'overlay-rect') {
        try {
          $script:overlayCssRect = @{
            left = [double]$message.left
            top = [double]$message.top
            width = [double]$message.width
            height = [double]$message.height
          }
          Update-DragBounds
          Update-InputWindow
        } catch { }
      }
    } catch {
      Write-HudLog ('web message failed: ' + $_.Exception.Message)
    }
  })
  $view.CoreWebView2.Navigate($PageUrl)
})

$window.Add_SourceInitialized({
  try {
    $helper = New-Object System.Windows.Interop.WindowInteropHelper($window)
    $script:hwnd = $helper.Handle
    $hookOk = [TokenComboNative]::StartDragHook($script:hwnd)
    Write-HudLog ('drag hook=' + $hookOk)
    $source = [System.Windows.Interop.HwndSource]::FromHwnd($script:hwnd)
    $source.AddHook([System.Windows.Interop.HwndSourceHook]{
      param($hwnd, $msg, $wParam, $lParam, [ref]$handled)
      if ($msg -eq 0x02E0) {
        # WM_DPICHANGED: the window moved to a monitor with a different scale.
        Update-DragBounds
      } elseif ($msg -eq 0x0312) {
        $action = $script:hotkeyActions[[int]$wParam]
        if ($action -eq 'toggle') { Apply-Interactive (-not $script:clickThrough); Sync-Interactive }
        elseif ($action -eq 'close') { $window.Close() }
      }
      return [IntPtr]::Zero
    })
  } catch { }
})

$window.Add_Closed({
  Save-Position
  try {
    if ($null -ne $script:httpClient) {
      $script:httpClient.Dispose()
      $script:httpClient = $null
    }
  } catch { }
  $script:stateTask = $null
  try { [TokenComboNative]::RestoreSystemCursors() } catch { }
  try { [TokenComboNative]::StopDragHook() } catch { }
  try { [void][TokenComboNative]::UnregisterHotKey($script:hwnd, 1) } catch { }
  try { [void][TokenComboNative]::UnregisterHotKey($script:hwnd, 2) } catch { }
})

$timer = New-Object System.Windows.Threading.DispatcherTimer
# Keep this fast enough that a click-through toggle from the console lands in
# well under a second; the HTTP call itself is asynchronous, so the dispatcher
# only parses the small JSON payload.
$timer.Interval = [TimeSpan]::FromMilliseconds(150)
$timer.Add_Tick({
  try {
    # A state update must never run while a native drag is in progress.
    if ([TokenComboNative]::IsDragging) { return }
    $state = $null
    if ($null -eq $script:httpClient) {
      # HttpClient unavailable (very old .NET): fall back to the blocking call.
      $state = Invoke-RestMethod -Uri $Url -Headers @{ 'x-token-combo-token' = $Token } -TimeoutSec 1
      $script:syncFailures = 0
    } elseif ($null -ne $script:stateTask) {
      if (-not $script:stateTask.IsCompleted) { return }
      $task = $script:stateTask
      $script:stateTask = $null
      if ($task.IsFaulted) {
        $message = 'state fetch failed'
        try { $message = $task.Exception.GetBaseException().Message } catch { }
        throw (New-Object System.Exception $message)
      }
      $state = $task.Result | ConvertFrom-Json
      $script:syncFailures = 0
    }
    if ($null -ne $state) {
      try {
        $draggingNow = [TokenComboNative]::IsDragging
        if ($script:wasDragging -and -not $draggingNow) { Save-Position }
        $script:wasDragging = $draggingNow
      } catch { }
      if ($null -ne $state.hud) {
        Apply-Interactive ([bool]$state.hud.interactive)
        Apply-Hotkeys $state.hud.prefs
        $stateScale = [double]$state.hud.prefs.scale
        if ($stateScale -ge 0.8 -and $stateScale -le 2.4) {
          # Window = 250*scale HUD width + 2 * 30*scale padding; the extra height
          # leaves room for the bottom burst ticker below the HUD.
          $nextWidth = [Math]::Round($HUD_WINDOW_WIDTH * $stateScale)
          $nextHeight = [Math]::Round($HUD_WINDOW_HEIGHT * $stateScale)
          if ([Math]::Abs($window.Width - $nextWidth) -gt 1 -or [Math]::Abs($window.Height - $nextHeight) -gt 1) {
            $window.Width = $nextWidth
            $window.Height = $nextHeight
            Clamp-WindowPosition
          }
        }
      }
    }
    if ($null -ne $script:httpClient -and $null -eq $script:stateTask) {
      # Fire the next request without blocking the dispatcher thread.
      $script:stateTask = $script:httpClient.GetStringAsync($Url)
    }
  } catch {
    $script:stateTask = $null
    $script:syncFailures = [int]$script:syncFailures + 1
    $now = (Get-Date).Ticks
    if ($script:lastSyncErrorAt -eq 0 -or ($now - $script:lastSyncErrorAt) -gt [TimeSpan]::FromSeconds(30).Ticks) {
      $script:lastSyncErrorAt = $now
      Write-HudLog ('state poll failed (' + $script:syncFailures + '): ' + $_.Exception.Message)
    }
    # A Host restart issues a new HUD token; a stale window would keep failing
    # forever. Close ourselves after ~80 failed polls (about 12 s).
    if ($script:syncFailures -gt 80) { $window.Close() }
  }
})
$timer.Start()

$dragTimer = New-Object System.Windows.Threading.DispatcherTimer
$dragTimer.Interval = [TimeSpan]::FromMilliseconds(40)
$dragTimer.Add_Tick({
  try {
    if ($null -eq $view.CoreWebView2 -or $script:hwnd -eq [IntPtr]::Zero) { return }
    $dragging = [TokenComboNative]::IsDragging
    if ($dragging -ne $script:dragUiActive) {
      $script:dragUiActive = $dragging
      Write-HudLog ('drag ui ' + $dragging)
      $flag = if ($dragging) { 'true' } else { 'false' }
      $null = $view.CoreWebView2.ExecuteScriptAsync('window.__TC_DRAG_STATE__ && window.__TC_DRAG_STATE__(' + $flag + ')')
    }
    # Hover is driven by the native hook because CSS :hover is unreliable in the
    # layered transparent host window.
    $hovering = [TokenComboNative]::IsHovering
    if ($hovering -ne $script:hoverUiActive) {
      $script:hoverUiActive = $hovering
      Write-HudLog ('hover ui ' + $hovering)
      $flag = if ($hovering) { 'true' } else { 'false' }
      $null = $view.CoreWebView2.ExecuteScriptAsync('window.__TC_HOVER_STATE__ && window.__TC_HOVER_STATE__(' + $flag + ')')
    }
    Update-InputWindow
  } catch { }
})
$dragTimer.Start()

$window.Add_ContentRendered({
  Write-HudLog 'content rendered; ensure webview2'
  $null = $view.EnsureCoreWebView2Async()
  Update-InputWindow
})
$window.Add_LocationChanged({
  Update-DragBounds
  Update-InputWindow
})
$window.Add_Closed({
  Write-HudLog 'closed'
  try {
    if ($null -ne $script:inputWindow) {
      $script:inputWindow.Hide()
      $script:inputWindow.Close()
    }
  } catch { }
  $script:inputWindow = $null
})
$window.ShowDialog() | Out-Null
$timer.Stop()
$dragTimer.Stop()
