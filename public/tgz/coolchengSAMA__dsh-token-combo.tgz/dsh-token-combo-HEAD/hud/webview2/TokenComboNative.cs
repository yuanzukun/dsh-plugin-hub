using System;
using System.Runtime.InteropServices;

public static class TokenComboNative
{
    [StructLayout(LayoutKind.Sequential)]
    public struct POINT { public int X; public int Y; }

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

    [StructLayout(LayoutKind.Sequential)]
    private struct MSLLHOOKSTRUCT
    {
        public POINT pt;
        public uint mouseData;
        public uint flags;
        public uint time;
        public IntPtr dwExtraInfo;
    }

    private delegate IntPtr LowLevelMouseProc(int nCode, IntPtr wParam, IntPtr lParam);

    private const int WH_MOUSE_LL = 14;
    private const int WM_MOUSEMOVE = 0x0200;
    private const int WM_LBUTTONDOWN = 0x0201;
    private const int WM_LBUTTONUP = 0x0202;
    private const int WM_RBUTTONDOWN = 0x0204;
    private const int WM_RBUTTONUP = 0x0205;
    private const int WM_MBUTTONDOWN = 0x0207;
    private const int WM_MBUTTONUP = 0x0208;
    private const int WM_MOUSEWHEEL = 0x020A;
    private const uint SWP_NOSIZE = 0x0001;
    private const uint SWP_NOZORDER = 0x0004;
    private const uint SWP_NOACTIVATE = 0x0010;

    [DllImport("user32.dll")]
    public static extern bool GetCursorPos(out POINT p);

    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);

    [DllImport("user32.dll")]
    public static extern bool SetWindowPos(IntPtr hWnd, IntPtr after, int x, int y, int cx, int cy, uint flags);

    [DllImport("user32.dll")]
    public static extern int GetWindowLong(IntPtr hWnd, int nIndex);

    [DllImport("user32.dll")]
    public static extern int SetWindowLong(IntPtr hWnd, int nIndex, int dwNewLong);

    [DllImport("user32.dll")]
    public static extern bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

    [DllImport("user32.dll")]
    public static extern bool UnregisterHotKey(IntPtr hWnd, int id);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, LowLevelMouseProc lpfn, IntPtr hMod, uint dwThreadId);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern bool UnhookWindowsHookEx(IntPtr hhk);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hhk, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll")]
    private static extern IntPtr GetModuleHandle(string lpModuleName);

    [DllImport("user32.dll")]
    private static extern IntPtr LoadCursor(IntPtr hInstance, IntPtr cursorName);

    [DllImport("user32.dll")]
    private static extern IntPtr SetCursor(IntPtr cursor);

    private static LowLevelMouseProc _proc;
    private static IntPtr _hook = IntPtr.Zero;
    private static IntPtr _target = IntPtr.Zero;
    private static bool _clickThrough;
    private static bool _dragging;
    private static bool _hovering;
    private static POINT _startCursor;
    private static RECT _startRect;
    private static RECT _dragBounds;
    private static bool _hasDragBounds;
    private static IntPtr _cursorHand = IntPtr.Zero;
    private static IntPtr _cursorSizeAll = IntPtr.Zero;

    /** Kept for the PowerShell host teardown path; the helper no longer mutates system cursors. */
    public static void RestoreSystemCursors()
    {
    }
    public static int DragStarts = 0;
    public static int DragMoves = 0;
    public static bool IsDragging { get { return _dragging; } }
    /** Cursor is inside the draggable overlay bounds (only meaningful while interactive). */
    public static bool IsHovering { get { return _hovering; } }

    public static void SetDragBounds(int left, int top, int width, int height)
    {
        _dragBounds.Left = left;
        _dragBounds.Top = top;
        _dragBounds.Right = left + width;
        _dragBounds.Bottom = top + height;
        _hasDragBounds = width > 0 && height > 0;
    }

    public static bool StartDragHook(IntPtr target)
    {
        _target = target;
        if (_cursorHand == IntPtr.Zero) _cursorHand = LoadCursor(IntPtr.Zero, (IntPtr)32649);
        if (_cursorSizeAll == IntPtr.Zero) _cursorSizeAll = LoadCursor(IntPtr.Zero, (IntPtr)32646);
        if (_hook != IntPtr.Zero) return true;
        _proc = HookCallback;
        _hook = SetWindowsHookEx(WH_MOUSE_LL, _proc, GetModuleHandle(null), 0);
        return _hook != IntPtr.Zero;
    }

    public static void StopDragHook()
    {
        if (_hook != IntPtr.Zero)
        {
            UnhookWindowsHookEx(_hook);
            _hook = IntPtr.Zero;
        }
        _dragging = false;
        _hovering = false;
    }

    public static void SetClickThrough(bool value)
    {
        _clickThrough = value;
        if (value)
        {
            _dragging = false;
            _hovering = false;
        }
    }

    private static bool Inside(POINT p, RECT r)
    {
        return p.X >= r.Left && p.X < r.Right && p.Y >= r.Top && p.Y < r.Bottom;
    }

    private static IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0 && _target != IntPtr.Zero)
        {
            MSLLHOOKSTRUCT data = (MSLLHOOKSTRUCT)Marshal.PtrToStructure(lParam, typeof(MSLLHOOKSTRUCT));
            RECT rect;
            bool insideWindow = GetWindowRect(_target, out rect) && Inside(data.pt, rect);
            bool insideBounds = false;
            if (insideWindow && !_clickThrough && _hasDragBounds)
            {
                int cx = data.pt.X - rect.Left;
                int cy = data.pt.Y - rect.Top;
                insideBounds = cx >= _dragBounds.Left && cx < _dragBounds.Right && cy >= _dragBounds.Top && cy < _dragBounds.Bottom;
            }
            // The WebView2 page cannot rely on CSS :hover in a layered transparent
            // host window, so the hook is the authoritative hover source.
            _hovering = insideBounds;
            if (_dragging)
            {
                SetCursor(_cursorSizeAll);
            }
            else if (insideWindow && !_clickThrough)
            {
                // Click-through mode must leave the underlying app's cursor alone.
                SetCursor(_cursorHand);
            }

            if (wParam == (IntPtr)WM_LBUTTONDOWN)
            {
                if (insideBounds)
                {
                    _startCursor = data.pt;
                    _startRect = rect;
                    _dragging = true;
                    DragStarts++;
                    return (IntPtr)1;
                }
            }
            else if (wParam == (IntPtr)WM_MOUSEMOVE && _dragging)
            {
                int x = _startRect.Left + (data.pt.X - _startCursor.X);
                int y = _startRect.Top + (data.pt.Y - _startCursor.Y);
                SetWindowPos(_target, IntPtr.Zero, x, y, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE);
                DragMoves++;
            }
            else if (wParam == (IntPtr)WM_LBUTTONUP)
            {
                if (_dragging)
                {
                    _dragging = false;
                    return (IntPtr)1;
                }
                if (insideBounds && !_clickThrough) return (IntPtr)1;
            }
            else if (wParam == (IntPtr)WM_RBUTTONDOWN || wParam == (IntPtr)WM_RBUTTONUP ||
                     wParam == (IntPtr)WM_MBUTTONDOWN || wParam == (IntPtr)WM_MBUTTONUP ||
                     wParam == (IntPtr)WM_MOUSEWHEEL)
            {
                if (insideBounds && !_clickThrough) return (IntPtr)1;
            }
        }
        return CallNextHookEx(_hook, nCode, wParam, lParam);
    }
}
