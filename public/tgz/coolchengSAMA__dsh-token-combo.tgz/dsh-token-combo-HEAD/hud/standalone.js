(function () {
  'use strict';
  var params = new URLSearchParams(window.location.search);
  var token = params.get('token') || '';
  var style = params.get('style') || 'deepseek';
  var scale = Number(params.get('scale') || '1');
  var align = params.get('align') === 'right' ? 'right' : 'left';
  var locale = params.get('locale') === 'en' ? 'en' : 'zh';
  if (!Number.isFinite(scale) || scale < 0.8 || scale > 2.4) scale = 1;
  function applyHudPadding(value) {
    // Keep in sync with TokenComboWebView2.ps1: 310 = 250 HUD width + 2 * 30 padding.
    var pad = Math.round(30 * value);
    document.documentElement.style.setProperty('--tc-hud-pad', pad + 'px');
  }
  applyHudPadding(scale);
  try {
    localStorage.setItem('dsh-token-combo:prefs:v1', JSON.stringify({
      version: 8, style: style, display: 'overlay', overlayEnabled: true, dockEnabled: false,
      anchor: align, scale: scale, sound: false, sfxStyle: 'rhythm', volume: 0, reduced: false,
      overlayPos: null, overlayCollapsed: false, desktopHud: false,
      desktopHudInteractive: false, hudHotkeysEnabled: false,
      hudHotkeyToggle: 'Ctrl+Alt+T', hudHotkeyClose: 'Ctrl+Alt+X'
    }));
    localStorage.setItem('dsh-token-combo:welcomed:v4', '1');
  } catch (error) { /* ignore storage failures */ }

  function rpc(endpoint, payload) {
    return fetch('/token-combo/' + endpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ rpcId: String(Date.now()), method: endpoint, payload: payload || {} })
    }).then(function (response) {
      return response.json();
    }).then(function (body) {
      return body && body.result ? body.result : { ok: false, error: { code: 'hud/page-rpc', message: 'bad envelope', details: {} } };
    });
  }

  var overlayFactory = null;
  var cleanups = [];
  var ctx = {
    effect: function (fn) {
      try {
        var dispose = fn();
        if (typeof dispose === 'function') cleanups.push(dispose);
      } catch (error) {
        console.error('[token-combo hud] effect failed', error);
      }
      return function () {};
    },
    slots: {
      inject: function (name, factory) {
        try { factory(); } catch (error) { console.error('[token-combo hud] slot inject failed', name, error); }
      },
      register: function (meta, component) {
        if (meta && meta.name === 'shell.overlay') overlayFactory = component;
        return function () {};
      }
    },
    locale: {
      getSnapshot: function () { return { active: locale }; },
      subscribe: function () { return function () {}; }
    },
    connection: {
      rpc: {
        call: function (channel, endpoint, payload) {
          if (endpoint === 'hud') return Promise.resolve({ ok: true, value: {} });
          return rpc(endpoint, payload);
        }
      }
    }
  };

  var entry = window.__TC_ENTRY__;
  if (!entry || typeof entry.factory !== 'function') {
    console.error('[token-combo hud] client bundle did not load');
    return;
  }
  var module = entry.factory(function (name) {
    if (name === 'react') return window.React;
    return undefined;
  });
  if (!module || typeof module.apply !== 'function') {
    console.error('[token-combo hud] client bundle has no apply()');
    return;
  }
  try {
    module.apply(ctx);
  } catch (error) {
    console.error('[token-combo hud] apply failed', error);
  }
  if (!overlayFactory) {
    console.error('[token-combo hud] shell.overlay was not registered');
    return;
  }
  var root = ReactDOM.createRoot(document.getElementById('hud-root'));
  root.render(React.createElement(overlayFactory, {}));

  var lastPrefsSignature = '';
  var reloadingForLocale = false;
  // The HUD page is initialized from the URL query string, so a Host-side locale change
  // can only reach the bundled client by reloading the page with the new locale.
  function reloadWithHostPrefs(hostPrefs) {
    if (reloadingForLocale) return;
    reloadingForLocale = true;
    try {
      var next = new URLSearchParams(window.location.search);
      if (token) next.set('token', token);
      if (typeof hostPrefs.style === 'string' && hostPrefs.style !== '') next.set('style', hostPrefs.style);
      var hostScale = Number(hostPrefs.scale);
      if (Number.isFinite(hostScale)) next.set('scale', String(hostScale));
      if (hostPrefs.align === 'left' || hostPrefs.align === 'right') next.set('align', hostPrefs.align);
      next.set('locale', hostPrefs.locale === 'en' ? 'en' : 'zh');
      window.location.replace(window.location.pathname + '?' + next.toString());
    } catch (error) {
      reloadingForLocale = false;
    }
  }
  function syncHostPrefs() {
    if (!token) return;
    fetch('/token-combo/hud/state', { headers: { 'x-token-combo-token': token } })
      .then(function (response) { return response.json(); })
      .then(function (state) {
        var hostPrefs = state && state.hud && state.hud.prefs;
        if (!hostPrefs) return;
        var hostLocale = hostPrefs.locale === 'en' ? 'en' : 'zh';
        if (hostLocale !== locale) {
          reloadWithHostPrefs(hostPrefs);
          return;
        }
        var signature = [hostPrefs.style, hostPrefs.scale, hostPrefs.align, hostPrefs.locale].join('|');
        if (signature === lastPrefsSignature) return;
        lastPrefsSignature = signature;
        if (typeof window.__tokenComboApplyHostPrefs === 'function') {
          window.__tokenComboApplyHostPrefs(hostPrefs);
        }
        applyHudPadding(Number(hostPrefs.scale) || 1);
      })
      .catch(function () { /* host may not be ready yet */ });
  }
  syncHostPrefs();
  setInterval(syncHostPrefs, 700);

  function post(message) {
    try { window.chrome.webview.postMessage(message); } catch (error) { /* ignore */ }
  }
  document.addEventListener('pointerdown', function (event) {
    var target = event.target;
    if (!target || typeof target.closest !== 'function' || !target.closest('.dsftcu-overlay')) return;
    event.preventDefault();
    event.stopPropagation();
  }, true);

  window.__TC_DRAG_STATE__ = function (active) {
    var overlay = document.querySelector('.dsftcu-overlay');
    if (overlay) overlay.setAttribute('data-dragging', active ? 'true' : 'false');
    document.documentElement.style.cursor = active ? 'grabbing' : '';
  };

  // The native mouse hook owns hover in the layered transparent window (CSS
  // :hover is unreliable there); PS1 forwards the hook state to the page.
  window.__TC_HOVER_STATE__ = function (active) {
    var overlay = document.querySelector('.dsftcu-overlay');
    if (overlay) overlay.setAttribute('data-hover', active ? 'true' : 'false');
  };

  var lastOverlayRect = '';
  function reportOverlayRect() {
    var overlay = document.querySelector('.dsftcu-overlay');
    if (!overlay) return;
    var rect = overlay.getBoundingClientRect();
    var signature = [rect.left, rect.top, rect.width, rect.height].join(',');
    if (signature === lastOverlayRect) return;
    lastOverlayRect = signature;
    post({ type: 'overlay-rect', left: rect.left, top: rect.top, width: rect.width, height: rect.height });
  }
  reportOverlayRect();
  setInterval(reportOverlayRect, 500);
  window.addEventListener('resize', reportOverlayRect);
  post({ type: 'ready' });
})();
