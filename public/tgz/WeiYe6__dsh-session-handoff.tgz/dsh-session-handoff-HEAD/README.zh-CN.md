# dsh-session-handoff

[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%5E22.19%20%7C%7C%20%3E%3D24-green.svg)](package.json)
[![dsh](https://img.shields.io/badge/dsh-rc.5%E2%80%93rc.8%20%7C%200.1.1--rc.2-8a2be2.svg)](https://github.com/deepseek-ai/deepseek-harness)

[English](README.md) | 中文

**把长会话"交接"到一个干净的新会话**。`/handoff` 用 LLM 总结当前会话最近几轮对话，
在同一工作区创建一个**全新会话 + agent**（不复制历史），把结构化交接文档作为新会话
第一条消息注入，并**自动打开**——模型从摘要继续，不用重放整段旧历史。原会话保持不变。

## 特性

- **一条命令**——`/handoff [<N>|all]`（默认最近 8 轮用户消息；`all` 覆盖全部）
- **干净的交接**——新会话继承原会话的工作区、模型路由与 agent preset（系统提示 / 工具 / 技能），无上下文臃肿
- **结构化摘要**——任务目标 / 当前进度 / 关键决策 / 涉及文件 / 下一步 / 遗留问题
- **自动打开**——客户端半区等待新会话就绪后自动跳转（每个子会话只自动打开一次，历史回放不反复跳转）
- **默认就健壮**——摘要调用关闭思考（快且省）、超长输入自动保留最新而非报错、finish reason（max-tokens / error / aborted）翻译成可操作的错误
- **零核心改动**——只插入一行 `dsh.bundle.patch`，全部走公开服务

## 安装

```sh
# 1. 从源码构建（或直接下载 release tarball）
npm install && npm run build && npm pack     # → dsh-session-handoff-0.2.1.tgz

# 2. 装进 web profile
dsh plugin --profile web add ./dsh-session-handoff-0.2.1.tgz

# 3. 重启并验证挂载
dsh web
dsh --profile web --dump-config | grep handoff
# 期望：# == dsh-session-handoff / - id: handoff / - name: dsh-session-handoff
```

> 开发期源码 link 安装（`dsh plugin --profile web add D:/path/to/dsh-session-handoff`）要求源码
> 目录的 `node_modules` 能解析 `@deepseek-ai/*` peers；正式安装推荐直接用 tarball。

## 使用

在任意会话输入框敲：

```text
/handoff          # 总结最近 8 轮用户消息（默认）
/handoff 20       # 总结最近 20 轮（等价 turns=20）
/handoff all      # 总结全部用户消息（等价 turns=all）
```

执行后：

1. 命令卡片显示"正在总结…"；
2. LLM 生成交接文档（目标 / 进度 / 决策 / 文件 / 下一步 / 遗留问题），成为新会话首条消息；
3. 新会话**自动打开**；原会话原样保留并回链。

> ⚠️ **隐私提示**：所选窗口内的对话文本（用户 + 助手消息）会发送给配置的模型用于生成摘要。

## 配置

```yaml
- id: handoff
  name: dsh-session-handoff
  config:
    turns: 8            # 提取的用户消息轮数（1–50）
    maxInputChars: 24000  # 摘要输入字节上限（超限自动丢弃最旧）
    maxTokens: 2000     # 摘要输出 token 上限
    reasoningEffort: off  # 摘要调用思考强度：off（默认，快省）| high | max | inherit
    timeoutMs: 120000   # 摘要调用超时
    # provider: deepseek-official   # 可选：固定模型路由
    # model: deepseek-v4-flash      # 必须与 provider 成对
```

不配 `provider`/`model` 时，自动使用当前会话最近一次请求的模型路由
（`session.requestHeader()`）。

## 原理

- **宿主侧**（`index.mjs`，纯 ESM）：只消费公开服务——`commands`（/handoff 命令）、
  `llm`（`ctx.llm.stream`，参考官方 session-title-llm）、`agents`
  （`ctx.agents.create`：会话与 agent 一起建，经 `agentPresets.mount` 继承原会话的
  cwd / 模型路由 / agent preset），以及 `workspaceRegistry.attachSession`（同工作区分组）
  与 `sessionTitle.rename`（`handoff: <源标题>` 可辨识标题）。
- **客户端侧**（`src/client/`，tsdown → `lib/client.js`）：`handoff` conversation node
  命中 `/handoff` 成功事件后自动打开子会话（轮询等待可寻址，localStorage 去重）。

## 开发

```sh
npm install        # devDeps：tsdown / typescript / @types/react / vitest / jsdom …
npm test           # 22 用例：17 宿主+客户端纯函数 + 5 客户端组件
npm run typecheck
npm run build      # tsdown → lib/client.js（CJS factory，官方客户端模块系统形态）
npm pack           # prepack 自动 typecheck + build
```

发布清单：仓库加 `dsh-plugin` GitHub topic → 给
[awesome-deepseek-harness](https://github.com/0xsline/awesome-deepseek-harness) 提 PR
收录 → 可选 `npm publish`。

## 已知限制

- 交接文档目前只注入会话内，不落盘（`HANDOFF.md` 留作后续）；
- 支持 DSH `0.1.0-rc.5` 至 `rc.8` 版本线以及 `0.1.1-rc.2`；暂不支持
  `0.1.2-alpha.1`，该版本拆分了会话 UI/服务，需要单独迁移客户端半区；
- 自动跳转已有 jsdom 组件测试，但真实浏览器时序仍需端到端验证。

## License

[MIT](./LICENSE)
