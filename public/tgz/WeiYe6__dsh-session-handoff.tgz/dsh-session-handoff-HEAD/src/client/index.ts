// dsh-session-handoff 客户端半区（browser half）：
// 监听 /handoff 命令完成事件（command/done），自动打开新建的交接会话。
//
// 实现要点：
// - 走官方 conversation node 机制（与 /goal、/compact 同款）：match 命中
//   command/done（kind=success 且文本含 handoff 成功标记），start 提取
//   子会话 id，渲染一个自动跳转卡片（副作用只在渲染组件里发生，状态机保持纯）。
// - 每个子会话用 localStorage 标记"已打开过"，避免历史回放时反复跳转。
// - 零 @deepseek-ai 运行时/类型依赖（类型用本地最小接口），仅外部依赖 react。

import type { ComponentType } from 'react'
import { HandoffOpenCard } from './HandoffOpenCard.tsx'
import { extractChildId, isHandoffDone } from './parse.ts'

/** 本插件客户端最小上下文接口（避免 @deepseek-ai 类型依赖链）。 */
interface HandoffClientCtx {
  conversationEvents: { register(definition: unknown): void }
  slots: {
    inject(name: string, register: () => unknown): void
    register(options: Record<string, unknown>, component: ComponentType<Record<string, unknown>>): unknown
  }
  sessions: {
    open(sessionId: string): void
    binding(sessionId: string): unknown
  }
}

/** 本插件客户端节点渲染的负载。 */
interface HandoffChatData {
  kind: 'handoff'
  commandId: string
  childId: string
}

export const name = 'dsh-session-handoff-client'

/** 必需服务：slots（注册 UI）、sessions（打开会话）、conversationEvents（节点状态机）。 */
export const inject = ['slots', 'sessions', 'conversationEvents']

/**
 * 客户端插件挂载：注册 handoff 会话节点的状态机与自动跳转卡片。
 * @param ctx - 客户端根上下文。
 */
export function apply(ctx: HandoffClientCtx): void {
  ctx.conversationEvents.register({
    kind: 'handoff',
    target: 'chat',
    match(event: unknown) {
      if (!isHandoffDone(event)) return null
      const text = (event as { data: { text: string } }).data.text
      const childId = extractChildId(text)
      if (childId === undefined) return null
      return { id: `handoff:${String((event as { data: { commandId: unknown } }).data.commandId)}`, role: 'start' }
    },
    start(_context: unknown, match: { event: { data: { text: string; commandId: unknown }; seq: number } }) {
      return {
        commandId: String(match.event.data.commandId),
        childId: extractChildId(match.event.data.text),
      }
    },
    update(context: { state?: { commandId?: string; childId?: string } }) {
      // 单事件节点（command/done 即 start），无后续更新。
      return context.state
    },
    buildViewNode(context: {
      key: string
      id: string
      start?: { event: { seq: number } }
      state?: { commandId?: string; childId?: string }
    }) {
      const state = context.state
      if (state === undefined || typeof state.childId !== 'string') return null
      const data: HandoffChatData = { kind: 'handoff', commandId: state.commandId ?? '', childId: state.childId }
      return {
        key: context.key,
        kind: 'handoff',
        id: context.id,
        target: 'chat',
        anchorSeq: context.start?.event.seq ?? 0,
        location: { kind: 'unresolved' },
        visibility: 'visible',
        data,
      }
    },
  })

  ctx.slots.inject('conversation.chat.node', () => ctx.slots.register(
    {
      name: 'conversation.chat.node',
      key: 'handoff',
      locale: 'handoff',
      inject: (): { waitAndOpen: (sessionId: string) => Promise<void> } => ({
        // 宿主直接创建的新会话要等投影刷新才会出现在客户端列表里：
        // 轮询 binding 直到可寻址（最多 6s），再打开。
        waitAndOpen: async (sessionId: string) => {
          for (let attempt = 0; attempt < 12; attempt += 1) {
            if (ctx.sessions.binding(sessionId) !== undefined) {
              ctx.sessions.open(sessionId)
              return
            }
            await new Promise((resolve) => window.setTimeout(resolve, 500))
          }
          // 兜底：仍尝试一次（侧边栏此时应已可见，可手动打开）。
          ctx.sessions.open(sessionId)
        },
      }),
    },
    HandoffOpenCard as ComponentType<Record<string, unknown>>,
  ))
}
