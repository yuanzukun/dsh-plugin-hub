// dsh-session-handoff 纯函数单测（node --test，零依赖，不 import @deepseek-ai 包）。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import {
  composeHandoffDoc,
  extractRecentMessages,
  frameItemsForSummary,
  parseHandoffArgs,
  textOfBlocks,
} from '../lib/summary.mjs'
import { withAbortTimeout } from '../lib/timeout.mjs'

function userEvent(text, seq) {
  return { type: 'user/message', data: { content: [{ type: 'text', text }] }, seq }
}

function assistantEvent(text, seq) {
  return { type: 'assistant/message', data: { message: { content: [{ type: 'text', text }] } }, seq }
}

test('textOfBlocks joins text blocks and ignores others', () => {
  assert.equal(textOfBlocks(undefined), '')
  assert.equal(textOfBlocks([]), '')
  assert.equal(
    textOfBlocks([
      { type: 'text', text: 'a' },
      { type: 'tool-call', name: 'x' },
      { type: 'text', text: 'b' },
    ]),
    'a\nb',
  )
})

test('extractRecentMessages collects user and assistant text in order', () => {
  const events = [
    userEvent('q1', 1),
    assistantEvent('a1', 2),
    userEvent('q2', 3),
    assistantEvent('a2', 4),
  ]
  const out = extractRecentMessages(events, { turns: 8 })
  assert.equal(out.userCount, 2)
  assert.deepEqual(out.items.map((i) => i.role), ['user', 'assistant', 'user', 'assistant'])
  assert.deepEqual(out.items.map((i) => i.text), ['q1', 'a1', 'q2', 'a2'])
})

test('extractRecentMessages skips non-message and empty-text events', () => {
  const events = [
    { type: 'turn/start', data: {} },
    userEvent('only', 1),
    { type: 'tool-call', data: {} },
    userEvent('', 2), // 空文本跳过
  ]
  const out = extractRecentMessages(events, { turns: 8 })
  assert.equal(out.userCount, 1)
  assert.deepEqual(out.items.map((i) => i.text), ['only'])
})

test('extractRecentMessages trims to the last N user messages', () => {
  const events = []
  for (let i = 1; i <= 5; i += 1) {
    events.push(userEvent(`q${i}`, i * 2 - 1))
    events.push(assistantEvent(`a${i}`, i * 2))
  }
  const out = extractRecentMessages(events, { turns: 2 })
  assert.equal(out.userCount, 2)
  assert.deepEqual(out.items.map((i) => i.text), ['q4', 'a4', 'q5', 'a5'])
})

test('extractRecentMessages reports zero when there are no user messages', () => {
  const out = extractRecentMessages([assistantEvent('a1', 1)], { turns: 8 })
  assert.equal(out.userCount, 0)
  assert.deepEqual(out.items, [])
})

test('extractRecentMessages keeps everything when turns is "all"', () => {
  const events = []
  for (let i = 1; i <= 5; i += 1) {
    events.push(userEvent(`q${i}`, i * 2 - 1))
    events.push(assistantEvent(`a${i}`, i * 2))
  }
  const out = extractRecentMessages(events, { turns: 'all' })
  assert.equal(out.userCount, 5)
  assert.deepEqual(out.items.map((i) => i.text), ['q1', 'a1', 'q2', 'a2', 'q3', 'a3', 'q4', 'a4', 'q5', 'a5'])
})

test('parseHandoffArgs handles empty, valid, all, shorthand, and invalid input', () => {
  assert.deepEqual(parseHandoffArgs('', 8), { turns: 8 })
  assert.deepEqual(parseHandoffArgs('turns=5', 8), { turns: 5 })
  assert.equal(parseHandoffArgs('turns=5', 8).turns, 5)
  assert.deepEqual(parseHandoffArgs('turns=all', 8), { turns: 'all' })
  assert.deepEqual(parseHandoffArgs('turns=ALL', 8), { turns: 'all' })
  // 简写：直接数字 / all
  assert.deepEqual(parseHandoffArgs('20', 8), { turns: 20 })
  assert.deepEqual(parseHandoffArgs('all', 8), { turns: 'all' })
  assert.deepEqual(parseHandoffArgs('ALL', 8), { turns: 'all' })
  const bad = parseHandoffArgs('foo', 8)
  assert.equal(bad.turns, 8)
  assert.ok(bad.invalid !== undefined)
  const outOfRange = parseHandoffArgs('turns=999', 8)
  assert.equal(outOfRange.turns, 8)
  assert.ok(outOfRange.invalid !== undefined)
})

test('frameItemsForSummary keeps everything when under the byte cap', () => {
  const items = [
    { role: 'user', text: 'a' },
    { role: 'assistant', text: 'b' },
  ]
  const { framed, dropped } = frameItemsForSummary(items, 100000)
  assert.equal(dropped, 0)
  assert.deepEqual(JSON.parse(framed).map((i) => i.text), ['a', 'b'])
})

test('frameItemsForSummary drops oldest items to fit the byte cap', () => {
  const items = []
  for (let i = 1; i <= 5; i += 1) {
    items.push({ role: 'user', text: `第${i}条消息` + 'x'.repeat(2000) })
  }
  const { framed, dropped } = frameItemsForSummary(items, 5000)
  assert.ok(dropped >= 1, 'expected at least one dropped')
  const parsed = JSON.parse(framed)
  assert.ok(parsed.length >= 1)
  // 保留的是最旧的被丢、最新的留下（以第一条为基准）。
  assert.ok(Buffer.byteLength(framed, 'utf8') <= 5000)
  assert.equal(parsed[0].text.startsWith('第'), true)
})

test('frameItemsForSummary throws when a single message exceeds the cap', () => {
  const items = [{ role: 'user', text: 'x'.repeat(100000) }]
  assert.throws(() => frameItemsForSummary(items, 5000), /exceeds maxInputChars/)
})

test('composeHandoffDoc embeds source id and summary', () => {
  const doc = composeHandoffDoc({ sourceId: 's-1', sourceTitle: '重构', summary: '## 下一步\n1. x' })
  assert.ok(doc.includes('s-1'))
  assert.ok(doc.includes('重构'))
  assert.ok(doc.includes('## 下一步'))
  assert.ok(doc.includes('未改动'))
})

test('withAbortTimeout aborts a cooperative operation with an actionable error', async () => {
  await assert.rejects(
    withAbortTimeout(signal => new Promise((resolve, reject) => {
      signal.addEventListener('abort', () => reject(signal.reason), { once: true })
    }), { timeoutMs: 10, label: 'summary model call' }),
    /summary model call timed out after 10ms/,
  )
})

test('withAbortTimeout preserves caller cancellation instead of reporting a timeout', async () => {
  const controller = new AbortController()
  const pending = withAbortTimeout(signal => new Promise((resolve, reject) => {
    signal.addEventListener('abort', () => reject(signal.reason), { once: true })
  }), { signal: controller.signal, timeoutMs: 1000, label: 'summary model call' })
  controller.abort(new Error('caller cancelled'))
  await assert.rejects(pending, /caller cancelled/)
})
