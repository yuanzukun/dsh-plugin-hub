// 客户端纯函数单测（node --experimental-strip-types --test，零依赖）。

import { test } from 'node:test'
import assert from 'node:assert/strict'
import { extractChildId, isHandoffDone, SUCCESS_PREFIX } from '../src/client/parse.ts'

test('extractChildId pulls the first backticked session id', () => {
  const text = 'handoff: created a fresh session `session-3` in this workspace; origin `session-f60d` unchanged.'
  assert.equal(extractChildId(text), 'session-3')
})

test('extractChildId returns undefined when no session id is present', () => {
  assert.equal(extractChildId('handoff: something else'), undefined)
  assert.equal(extractChildId(''), undefined)
  assert.equal(extractChildId('no backticks session-3'), undefined)
})

test('isHandoffDone matches command/done success with the handoff prefix', () => {
  assert.equal(isHandoffDone({
    type: 'command/done',
    data: { commandId: 'cmd-1', kind: 'success', text: `handoff: created a fresh session \`session-3\` ...` },
  }), true)
})

test('isHandoffDone rejects other commands, errors, and malformed events', () => {
  assert.equal(isHandoffDone({
    type: 'command/done',
    data: { commandId: 'cmd-2', kind: 'success', text: 'rewind: ok' },
  }), false)
  assert.equal(isHandoffDone({
    type: 'command/done',
    data: { commandId: 'cmd-3', kind: 'error', text: `handoff: ${SUCCESS_PREFIX} ...` },
  }), false)
  assert.equal(isHandoffDone({ type: 'turn/end', data: {} }), false)
  assert.equal(isHandoffDone({
    type: 'turn/end',
    data: { kind: 'success', text: `handoff: created a fresh session \`session-3\` ...` },
  }), false)
  assert.equal(isHandoffDone(null), false)
  assert.equal(isHandoffDone(undefined), false)
  assert.equal(isHandoffDone('handoff'), false)
  assert.equal(isHandoffDone({ type: 'command/done', data: { kind: 'success' } }), false)
})
