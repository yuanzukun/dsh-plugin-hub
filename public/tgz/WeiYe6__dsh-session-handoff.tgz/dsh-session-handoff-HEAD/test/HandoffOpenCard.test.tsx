// HandoffOpenCard 组件测试（vitest + jsdom + @testing-library/react）。
// 验证自动跳转的三条核心契约：有 childId 时触发一次、去重标记、无 childId 不触发。

import { describe, expect, it, vi, beforeEach } from 'vitest'
import { render } from '@testing-library/react'
import { HandoffOpenCard } from '../src/client/HandoffOpenCard.tsx'

const OPENED_KEY = 'dsh.handoff.opened.v1:session-1'

describe('HandoffOpenCard', () => {
  beforeEach(() => {
    window.localStorage.clear()
    vi.restoreAllMocks()
  })

  it('auto-opens once and records the dedup marker', async () => {
    const waitAndOpen = vi.fn<(_id: string) => Promise<void>>().mockResolvedValue(undefined)
    render(<HandoffOpenCard node={{ data: { kind: 'handoff', childId: 'session-1' } }} waitAndOpen={waitAndOpen} />)
    await vi.waitFor(() => expect(waitAndOpen).toHaveBeenCalledTimes(1))
    expect(waitAndOpen).toHaveBeenCalledWith('session-1')
    expect(window.localStorage.getItem(OPENED_KEY)).toBe('1')
  })

  it('does not re-open an already-opened child', async () => {
    window.localStorage.setItem(OPENED_KEY, '1')
    const waitAndOpen = vi.fn<(_id: string) => Promise<void>>()
    render(<HandoffOpenCard node={{ data: { kind: 'handoff', childId: 'session-1' } }} waitAndOpen={waitAndOpen} />)
    await new Promise((resolve) => setTimeout(resolve, 60))
    expect(waitAndOpen).not.toHaveBeenCalled()
  })

  it('skips when no childId is present', async () => {
    const waitAndOpen = vi.fn<(_id: string) => Promise<void>>()
    render(<HandoffOpenCard node={{ data: { kind: 'handoff' } }} waitAndOpen={waitAndOpen} />)
    await new Promise((resolve) => setTimeout(resolve, 60))
    expect(waitAndOpen).not.toHaveBeenCalled()
  })

  it('skips when waitAndOpen is not injected', async () => {
    const error = vi.spyOn(console, 'info').mockImplementation(() => {})
    render(<HandoffOpenCard node={{ data: { kind: 'handoff', childId: 'session-1' } }} />)
    await new Promise((resolve) => setTimeout(resolve, 60))
    expect(error).toHaveBeenCalled()
    error.mockRestore()
  })

  it('clears the dedup marker when auto-open fails so a later render can retry', async () => {
    const warning = vi.spyOn(console, 'warn').mockImplementation(() => {})
    const waitAndOpen = vi.fn<(_id: string) => Promise<void>>().mockRejectedValue(new Error('not ready'))
    render(<HandoffOpenCard node={{ data: { kind: 'handoff', childId: 'session-1' } }} waitAndOpen={waitAndOpen} />)
    await vi.waitFor(() => expect(waitAndOpen).toHaveBeenCalledTimes(1))
    await vi.waitFor(() => expect(window.localStorage.getItem(OPENED_KEY)).toBeNull())
    expect(warning).toHaveBeenCalled()
  })
})
