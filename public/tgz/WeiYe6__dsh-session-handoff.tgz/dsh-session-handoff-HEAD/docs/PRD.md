# dsh-session-handoff — PRD（产品需求文档，as-built 归档）

> 本文件沉淀从 0 到 v0.1.0 的完整决策链。语言：中文。对应实现见
> [README.md](../README.md) 与源码。

## 1. 背景与痛点

DeepSeek Harness（DSH）会话在长时间编码/研究任务中会"上下文过长"：

- 官方社区 Discussions 存在明确的"长会话"问题家族（`#211` 浏览器卡死、
  `#317/#370/#501/#534` 20 万 token 历史加载失败、`#624` 内存爆炸）；
- 官方自带 `/compact`（压缩）与 fork（分叉复制全量历史），但**没有**
  "总结当前会话 → 迁移到干净的新会话并继续"的一键能力；
- 生态现状：`dsh-session-manager`「在新聊天中继续」只是封装 fork；记忆类插件
  覆盖单点；**"总结式交接"是空白点**。

## 2. 目标

提供一条命令，把"太长/太乱"的当前会话**交接**到一个干净的新会话：

- 用 LLM 总结最近对话 → 生成结构化交接文档；
- 在同一工作区创建**全新会话 + agent**（不复制历史）；
- 交接文档作为新会话首条消息注入（模型从摘要继续）；
- **自动打开**新会话；原会话保持不变、可回链。

## 3. 核心流程（/handoff）

```
1. 提取 session.events 中最近 N 轮 user/message + assistant/message 文本
2. 调 ctx.llm.stream 生成交接摘要（默认 reasoningEffort=off，快且省）
   - 输入超 maxInputChars 时自动丢弃最旧、保留最近（单条超限才报错）
3. ctx.agents.create 创建全新会话 + agent：
   - 继承原会话 cwd / 模型路由 / agent preset（agentPresets.mount）
4. workspaceRegistry.attachSession 挂载到原工作区
5. sessionTitle.rename pin "handoff: <源标题>"
6. 注入交接文档为首条 user/message（plugin source，落日志）
7. 客户端 conversation node 命中 command/done → 轮询等待会话就绪 → sessions.open
   （localStorage 去重，历史回放不反复跳转）
```

## 4. 参数与配置

- `/handoff [<N>|all]`（空=默认 8 轮，`N`=N 轮，`all`=全部；兼容 `turns=` 写法）
- 配置（cordis.patch.yml）：`turns / maxInputChars / maxTokens / reasoningEffort /
  timeoutMs / provider / model`，Schemastery 校验、非法值启动即报错。

## 5. 架构决策

| 决策 | 理由 |
| :-- | :-- |
| 宿主半区纯 ESM `.mjs`、零构建 | 参考 checkpoint-rewind，规避 rc 期 tsc 构建链与版本线匹配坑 |
| 客户端半区 tsdown → CJS factory | 官方客户端模块系统要求 `window.__ModuleLoader__.load({id,factory})` 形态 |
| 客户端零 `@deepseek-ai` 类型依赖 | `@deepseek-ai` scope 走门控 registry（需只读 token），本地最小接口绕开 |
| 会话经 `ctx.agents.create`（非 sessions.create） | 裸会话无 agent → 客户端打开走 resume → "cannot prepare while it is live" |
| 显式 `attachSession` | workspace registry 只在启动时索引 live 会话，不显式挂载会落"未分组" |
| 摘要关闭思考（off） | high 思考吃光输出预算导致 "produced no text"，总结是压缩任务无需深度思考 |

## 6. 验收标准（v0.1.0 已达成）

- [x] `/handoff all` 生成摘要并创建新会话，无 resume 报错
- [x] 新会话自动打开（客户端半区）
- [x] 新会话与源会话同工作区分组
- [x] 新会话标题带 `handoff:` 前缀
- [x] 19 测试全绿（15 纯函数 + 4 组件）+ typecheck 0 错误 + CI green
- [x] 双语 README + 可复现构建（npm pack 端到端验证）

## 7. 路线图

**已做**：MVP 全流程、工程债（测试/CI/tag/双语文档）、分发（topic + awesome PR）。

**待定（等真实用户反馈）**：交接文档落盘 HANDOFF.md、交接前预览确认、
输入框快捷按钮 / 右键菜单 / 设置页 UI（当前判断为锦上添花，不做）。

**已关闭**：npm 发布——`dsh-session-handoff` 包名已被另一项目占用，且本机未登录 npm；
GitHub + `dsh-plugin` topic + awesome 列表已覆盖分发需求。

## 8. 风险与已知限制

- 已复核 DSH `0.1.0-rc.5` 至 `rc.8` 及 `0.1.1-rc.2` 的公开契约；
  `0.1.2-alpha.1` 的会话 UI/服务拆分需要单独迁移客户端半区；
- 摘要调用会把所选窗口的对话文本发送给模型（隐私，README 已提示）；
- 客户端自动跳转组件的 jsdom 测试已覆盖核心契约，但真实浏览器时序仍以实测为准。
