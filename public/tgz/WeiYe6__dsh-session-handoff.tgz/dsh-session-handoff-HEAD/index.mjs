// index.mjs — dsh-session-handoff 插件入口（唯一 host 面文件；纯 ESM，零构建）。
//
// /handoff：把当前长会话"交接"到一个干净的新会话——
// 1) 从 session.events 提取最近 N 轮用户/助手消息文本；
// 2) 调 LLM 生成结构化交接摘要（经 ctx.llm.stream，参考官方 session-title-llm）；
// 3) ctx.agents.create() 在相同工作区创建全新会话 + agent（会话与 agent 一起
//    建，客户端打开才不触发 resume 冲突；setup 挂载原会话的 agent preset）；
// 4) 把交接文档作为新会话首条 user/message 注入（模型可见 ⟺ 已记录）；
// 5) 返回新会话 id；原会话保持不变，可从侧边栏随时回去。
//
// 只消费公开服务：sessions / commands / llm / agents（inject 声明），
// agentPresets 按需可选查找（ctx.get）。

import { randomUUID } from 'node:crypto'
import Schema from '@deepseek-ai/schemastery'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import { COMMAND_NAME, DEFAULTS, LIMITS, PLUGIN_NAME, REASONING_EFFORTS, SESSION_EVENT_INJECT } from './lib/constants.mjs'
import { composeHandoffDoc, extractRecentMessages, parseHandoffArgs } from './lib/summary.mjs'
import { generateSummary } from './lib/llm.mjs'
import { withAbortTimeout } from './lib/timeout.mjs'

export const name = PLUGIN_NAME

/** 必需服务：缺失即加载失败（响亮）。 */
export const inject = ['sessions', 'commands', 'llm', 'agents']

/**
 * 插件配置（Schemastery，全部可 cordis.yml 覆盖；无硬编码 tunable）。
 */
export const Config = Schema.object({
  enabled: Schema.boolean().default(DEFAULTS.ENABLED),
  turns: Schema.number().default(DEFAULTS.TURNS),
  maxInputChars: Schema.number().default(DEFAULTS.MAX_INPUT_CHARS),
  maxTokens: Schema.number().default(DEFAULTS.MAX_TOKENS),
  timeoutMs: Schema.number().default(DEFAULTS.TIMEOUT_MS),
  reasoningEffort: Schema.union(REASONING_EFFORTS).default(DEFAULTS.REASONING_EFFORT),
  provider: Schema.string(),
  model: Schema.string(),
})

/** 显式补齐默认 + 加载期校验（非法配置响亮失败）。 */
export function resolveConfig(config = {}) {
  const resolved = {
    enabled: config.enabled ?? DEFAULTS.ENABLED,
    turns: config.turns ?? DEFAULTS.TURNS,
    maxInputChars: config.maxInputChars ?? DEFAULTS.MAX_INPUT_CHARS,
    maxTokens: config.maxTokens ?? DEFAULTS.MAX_TOKENS,
    timeoutMs: config.timeoutMs ?? DEFAULTS.TIMEOUT_MS,
    reasoningEffort: config.reasoningEffort ?? DEFAULTS.REASONING_EFFORT,
    provider: config.provider ?? undefined,
    model: config.model ?? undefined,
  }
  if (resolved.enabled === false) return resolved
  if (!REASONING_EFFORTS.includes(resolved.reasoningEffort)) {
    throw new Error(`dsh-session-handoff: reasoningEffort must be one of ${REASONING_EFFORTS.join('|')}`)
  }
  if (!Number.isInteger(resolved.turns) || resolved.turns < LIMITS.MIN_TURNS || resolved.turns > LIMITS.MAX_TURNS) {
    throw new Error(`dsh-session-handoff: turns must be an integer in [${LIMITS.MIN_TURNS}, ${LIMITS.MAX_TURNS}]`)
  }
  if (!Number.isInteger(resolved.maxInputChars) || resolved.maxInputChars < LIMITS.MIN_MAX_INPUT_CHARS || resolved.maxInputChars > LIMITS.MAX_MAX_INPUT_CHARS) {
    throw new Error(`dsh-session-handoff: maxInputChars must be an integer in [${LIMITS.MIN_MAX_INPUT_CHARS}, ${LIMITS.MAX_MAX_INPUT_CHARS}]`)
  }
  if (!Number.isInteger(resolved.maxTokens) || resolved.maxTokens < LIMITS.MIN_MAX_TOKENS || resolved.maxTokens > LIMITS.MAX_MAX_TOKENS) {
    throw new Error(`dsh-session-handoff: maxTokens must be an integer in [${LIMITS.MIN_MAX_TOKENS}, ${LIMITS.MAX_MAX_TOKENS}]`)
  }
  if (!Number.isInteger(resolved.timeoutMs) || resolved.timeoutMs < LIMITS.MIN_TIMEOUT_MS || resolved.timeoutMs > LIMITS.MAX_TIMEOUT_MS) {
    throw new Error(`dsh-session-handoff: timeoutMs must be an integer in [${LIMITS.MIN_TIMEOUT_MS}, ${LIMITS.MAX_TIMEOUT_MS}]`)
  }
  const hasProvider = resolved.provider !== undefined
  const hasModel = resolved.model !== undefined
  if (hasProvider !== hasModel) {
    throw new Error('dsh-session-handoff: provider and model must be configured together')
  }
  if (hasProvider && (typeof resolved.provider !== 'string' || resolved.provider.length === 0 || typeof resolved.model !== 'string' || resolved.model.length === 0)) {
    throw new Error('dsh-session-handoff: provider and model must be non-empty strings')
  }
  return resolved
}

/**
 * 解析模型路由：优先配置覆盖，其次当前会话最近一次 request/header 记录的
 * 路由（与官方 session-title 同源）。
 * @param {object} session - 会话。
 * @param {{provider?: string, model?: string}} resolved - 已校验配置。
 * @returns {{provider: string, model: string}|undefined} 路由或 undefined。
 */
function resolveRoute(session, resolved) {
  if (resolved.provider !== undefined && resolved.model !== undefined) {
    return { provider: resolved.provider, model: resolved.model }
  }
  const header = session.requestHeader?.()
  const route = header?.config
  if (route !== null && typeof route === 'object' && typeof route.provider === 'string' && typeof route.model === 'string') {
    return { provider: route.provider, model: route.model }
  }
  return undefined
}

/** 取会话标题（无则为 undefined；MVP 不做额外查询）。 */
function sessionTitleOf(session) {
  const title = session.header?.title
  return typeof title === 'string' && title.length > 0 ? title : undefined
}

/**
 * 组装子会话的 agent preset 组合（照抄 api-proxy composeAgent 的公开服务
 * 调用：agentPresets.resolve → mount）。无 preset 服务时退化为空 setup。
 * @param {object} ctx - Cordis 上下文。
 * @param {string|undefined} presetId - 原会话记录的 agent preset id（无则默认）。
 * @returns {Promise<{agentPreset?: string, setup: Function}>} 组合结果。
 */
async function composeForPreset(ctx, presetId) {
  const presets = ctx.get('agentPresets')
  if (presets === undefined) {
    return { setup: () => Promise.resolve() }
  }
  const resolvedId = (await presets.resolve(presetId)).id
  return {
    agentPreset: resolvedId,
    setup: async (agentCtx) => {
      await presets.mount(agentCtx, resolvedId)
    },
  }
}

/**
 * 插件挂载。enabled:false 时不注册任何东西；非法配置在加载期响亮抛错。
 * @param {import('@deepseek-ai/cordis').Context} ctx - Cordis 上下文。
 * @param {Partial<ReturnType<typeof resolveConfig>>} [config] - 插件配置。
 */
export function apply(ctx, config = {}) {
  const resolved = resolveConfig(config)
  if (resolved.enabled === false) return
  const logger = ctx.logger(PLUGIN_NAME)

  ctx.commands.register({
    name: COMMAND_NAME,
    description: 'Summarize this session and continue in a fresh one: creates a new session in the same workspace with the LLM-generated handoff summary as its first message; the origin session is unchanged.',
    input: { hint: '[<N>|all] (default 8)' },
    async handler(invocation) {
      return handleHandoff(invocation, { ctx, logger, resolved })
    },
  })
}

/**
 * /handoff 命令处理器。
 * @param {import('@deepseek-ai/dsh-commands').CommandInvocation} invocation - 命令调用。
 * @param {{ctx: object, logger: object, resolved: object}} env - 执行环境。
 * @returns {Promise<import('@deepseek-ai/dsh-commands').CommandResult>} 命令结果。
 */
async function handleHandoff(invocation, { ctx, logger, resolved }) {
  const { agent, rawInput, signal } = invocation
  const session = agent?.session
  if (session === null || session === undefined) {
    return { kind: 'error', text: 'handoff: no active session' }
  }
  const args = parseHandoffArgs(rawInput, resolved.turns, { min: LIMITS.MIN_TURNS, max: LIMITS.MAX_TURNS })
  if (args.invalid !== undefined) return { kind: 'error', text: args.invalid }

  const recent = extractRecentMessages(session.events, { turns: args.turns })
  if (recent.userCount === 0) {
    return { kind: 'error', text: 'handoff: no user messages to summarize yet (send a message first)' }
  }

  const route = resolveRoute(session, resolved)
  if (route === undefined) {
    return {
      kind: 'error',
      text: 'handoff: no model route available. Send a message in this session first, or configure provider and model for dsh-session-handoff in the plugin settings.',
    }
  }

  // 1) 总结：失败即报错，不创建会话（无副作用）。
  let summary
  try {
    summary = await withAbortTimeout((summarySignal) => generateSummary({
      llm: ctx.llm,
      session,
      route,
      items: recent.items,
      config: {
        maxInputChars: resolved.maxInputChars,
        maxTokens: resolved.maxTokens,
        reasoningEffort: resolved.reasoningEffort,
      },
      signal: summarySignal,
    }), {
      signal,
      timeoutMs: resolved.timeoutMs,
      label: 'summary model call',
    })
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    logger.warn(`handoff summary failed: ${message}`)
    return { kind: 'error', text: message.startsWith('handoff: ') ? message : `handoff: ${message}` }
  }

  // 2) 新会话 + agent：同工作区全新会话（不复制历史；fork 才会复制）。
  //    必须经 ctx.agents.create 把会话与 agent 一起建（照抄 api-proxy 的
  //    sessions.create 路径）：只建裸会话会导致客户端打开时走 agent resume、
  //    撞上"cannot prepare while it is live"。setup 挂载原会话的 agent preset，
  //    让子会话拥有相同的系统提示/工具/技能组成。
  let child
  let childSessionId
  try {
    childSessionId = `session-${randomUUID()}`
    const composition = await composeForPreset(ctx, session.header?.agentPreset)
    const handle = await ctx.agents.create({
      sessionId: childSessionId,
      agentOptions: { provider: route.provider, model: route.model },
      meta: {
        ...(session.header?.cwd !== undefined ? { cwd: session.header.cwd } : {}),
        parentSession: session.id,
        ...(composition.agentPreset === undefined ? {} : { agentPreset: composition.agentPreset }),
      },
      setup: composition.setup,
    })
    child = handle.agent.session
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    logger.error(`handoff session create failed: ${message}`)
    return { kind: 'error', text: `handoff: failed to create the new session (${message})` }
  }

  // 2.5) 工作区挂载：workspace registry 只在启动时索引 live 会话，新建会话
  //     必须显式 attach（照抄 api-proxy create 的 workspace.attachSession），
  //     否则落到"未分组"直到下次重启。失败仅告警——会话仍可用。
  try {
    const registry = ctx.get('workspaceRegistry')
    const cwd = session.header?.cwd
    if (registry !== undefined && typeof cwd === 'string' && cwd.length > 0) {
      const workspace = await registry.create(cwd)
      await workspace.attachSession(childSessionId)
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    logger.warn(`handoff workspace attach failed (session ${childSessionId} stays ungrouped until restart): ${message}`)
  }

  // 2.6) 子会话标题：pin 一个可辨识的标题（sessionTitle 服务可选，失败仅告警；
  //     标题规范化后为空会抛 SessionTitleInvalidError，同样吞掉）。
  try {
    const titles = ctx.get('sessionTitle')
    if (titles !== undefined) {
      const sourceTitle = sessionTitleOf(session)
      titles.rename(child, sourceTitle === undefined ? 'handoff: 会话交接' : `handoff: ${sourceTitle}`)
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    logger.warn(`handoff child title rename failed (session ${childSessionId}): ${message}`)
  }

  // 3) 注入交接文档为新会话首条消息（user/message，plugin source，落日志）。
  const doc = composeHandoffDoc({ sourceId: session.id, sourceTitle: sessionTitleOf(session), summary: summary.text })
  try {
    child.append(SESSION_EVENT_INJECT, createUserMessage({
      content: [{ type: 'text', text: doc }],
      source: { kind: 'plugin', plugin: PLUGIN_NAME, form: 'handoff', summary: 'handoff' },
    }), { surfaceOp: 'append' })
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error)
    logger.error(`handoff notice injection failed: ${message}`)
    return {
      kind: 'error',
      text: `handoff: created session ${child.id} but failed to inject the summary (${message}); the new session is empty.`,
    }
  }

  logger.info(`handoff ok: session ${session.id} → new session ${child.id} (${recent.userCount} user message(s) summarized)`)
  const scope = args.turns === 'all'
    ? `all ${recent.userCount} user message(s)`
    : `the last ${recent.userCount} user message(s)`
  const dropNote = summary.dropped > 0
    ? ` (${summary.dropped} earlier message(s) omitted to fit maxInputChars ${resolved.maxInputChars})`
    : ''
  return {
    kind: 'success',
    text: [
      `handoff: created a fresh session \`${child.id}\` in this workspace with a summary of ${scope}${dropNote}.`,
      `Open \`${child.id}\` from the sidebar to continue the task (the origin session \`${session.id}\` is unchanged).`,
    ].join('\n'),
  }
}
