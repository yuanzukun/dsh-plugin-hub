// tsdown 客户端 bundle 配置：输出 DSH 客户端模块系统要求的 CJS factory 形态
// （window.__ModuleLoader__.load({ id, factory })），react 走外部（由宿主
// 平台模块表提供），其余全部内联。与官方 clientBundle 预设的产物契约一致。
import { defineConfig } from 'tsdown'

export default defineConfig({
  name: 'dsh-session-handoff/client',
  entry: { client: 'src/client/index.ts' },
  outDir: 'lib',
  format: 'cjs',
  platform: 'browser',
  dts: false,
  sourcemap: true,
  clean: false,
  external: ['react'],
  outputOptions: {
    entryFileNames: 'client.js',
    banner: `window.__ModuleLoader__.load({ id: 'dsh-session-handoff', factory: (require) => {`,
    footer: 'return module.exports; } });',
    intro: 'var module = { exports: {} }; var exports = module.exports;',
  },
})
