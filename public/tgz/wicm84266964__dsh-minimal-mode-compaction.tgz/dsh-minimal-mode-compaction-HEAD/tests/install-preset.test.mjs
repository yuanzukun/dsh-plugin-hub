import { access, mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { parseDocument } from "yaml";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import test from "node:test";
import assert from "node:assert/strict";

const run = promisify(execFile);
const root = fileURLToPath(new URL("..", import.meta.url));
const installer = join(root, "scripts", "install-preset.mjs");
const { updateDefaultPreset, parseArgs } = await import(pathToFileURL(join(root, "scripts", "install.mjs")).href);

test("installer creates an isolated user preset without touching the source", async () => {
  const home = await mkdtemp(join(tmpdir(), "dsh-minimal-mode-compaction-"));
  try {
    const { stdout } = await run(process.execPath, [installer, "--dsh-home", home, "--id", "test-minimal"]);
    assert.match(stdout, /installed preset/);
    const composition = await readFile(join(home, ".agent-presets", "test-minimal", "agent.cordis.yml"), "utf8");
    assert.match(composition, /@deepseek-ai\/dsh-compaction-basic/);
    assert.match(composition, /@deepseek-ai\/dsh-command-compact/);
    assert.match(composition, /thresholdRatio: 0\.75/);
  } finally {
    await rm(home, { recursive: true, force: true });
  }
});

test("installer refuses an existing preset unless force is explicit", async () => {
  const home = await mkdtemp(join(tmpdir(), "dsh-minimal-mode-compaction-"));
  try {
    await run(process.execPath, [installer, "--dsh-home", home]);
    await assert.rejects(
      run(process.execPath, [installer, "--dsh-home", home]),
      /preset already exists/,
    );
  } finally {
    await rm(home, { recursive: true, force: true });
  }
});

test("force replacement preserves a timestamped backup", async () => {
  const home = await mkdtemp(join(tmpdir(), "dsh-minimal-mode-compaction-"));
  try {
    const id = "backup-test";
    await run(process.execPath, [installer, "--dsh-home", home, "--id", id]);
    const { stdout } = await run(process.execPath, [installer, "--dsh-home", home, "--id", id, "--force"]);
    assert.match(stdout, /backup:/);
    const entries = (await import("node:fs/promises")).readdir(join(home, ".agent-presets"));
    assert.equal((await entries).filter(entry => entry.startsWith(`${id}.backup-`)).length, 1);
    await access(join(home, ".agent-presets", id, "agent.cordis.yml"));
  } finally {
    await rm(home, { recursive: true, force: true });
  }
});

test("one-click settings update preserves unrelated settings", async () => {
  const home = await mkdtemp(join(tmpdir(), "dsh-minimal-mode-compaction-"));
  try {
    const settingsPath = join(home, "settings.yaml");
    await (await import("node:fs/promises")).writeFile(settingsPath, [
      "ui-onboarding:",
      "  welcomeNoticeVersion: 2026-08-13.1",
      "agent-presets:",
      "  pinned: true",
      "agent-default-model:",
      "  model: deepseek-v4-pro",
      "",
    ].join("\n"));

    await updateDefaultPreset(home);
    const document = parseDocument(await readFile(settingsPath, "utf8"));
    assert.equal(document.getIn(["agent-presets", "default"]), "minimal-compaction");
    assert.equal(document.getIn(["agent-presets", "pinned"]), true);
    assert.equal(document.getIn(["agent-default-model", "model"]), "deepseek-v4-pro");
  } finally {
    await rm(home, { recursive: true, force: true });
  }
});

test("one-click settings update creates agent-presets when absent", async () => {
  const home = await mkdtemp(join(tmpdir(), "dsh-minimal-mode-compaction-"));
  try {
    await updateDefaultPreset(home, "test-preset");
    const document = parseDocument(await readFile(join(home, "settings.yaml"), "utf8"));
    assert.equal(document.getIn(["agent-presets", "default"]), "test-preset");
  } finally {
    await rm(home, { recursive: true, force: true });
  }
});

test("installer argument parser supports preserving the user's default", () => {
  const options = parseArgs(["--profile", "headless", "--no-default", "--keep-preset"]);
  assert.equal(options.profile, "headless");
  assert.equal(options.noDefault, true);
  assert.equal(options.keepPreset, true);
});
