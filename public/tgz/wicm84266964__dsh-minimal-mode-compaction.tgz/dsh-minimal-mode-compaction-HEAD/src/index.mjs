/**
 * Model-facing compaction scheduler for a minimal-style DSH preset.
 *
 * The official compaction service only accepts compactNow() while an agent is
 * idle. A model tool runs during a turn, so this plugin records the request
 * and performs the operation after the turn settles.
 */

import { defineTool } from "@deepseek-ai/dsh-tools";
import { ManualCompactionError } from "@deepseek-ai/dsh-compaction";

export const name = "dsh-minimal-mode-compaction";
export const inject = ["tools", "agents", "timer", "commands", "settings"];

const RETRY_LIMIT = 3;
const RETRY_DELAY_MS = 2000;
const DEEPSEEK_SETTINGS = "llm-deepseek";
const DEFAULT_CONTEXT_WINDOW = 1_000_000;

function parseContextWindow(input) {
  const value = input.trim();
  if (value === "" || value === "show" || value === "status") return null;
  const match = /^(\d+(?:\.\d+)?)\s*(k|m)?$/iu.exec(value);
  if (match === null) return undefined;
  const amount = Number(match[1]);
  const unit = match[2]?.toLowerCase();
  const multiplier = unit === "m" ? 1024 * 1024 : unit === "k" ? 1024 : 1;
  const tokens = amount * multiplier;
  if (!Number.isSafeInteger(tokens) || tokens < 1) return undefined;
  return tokens;
}

function modelFor(agent) {
  return agent?.options?.model ?? agent?.session?.requestContext?.()?.model;
}

function formatTokens(tokens) {
  if (!Number.isFinite(tokens)) return "未知";
  if (tokens % (1024 * 1024) === 0) return `${tokens / (1024 * 1024)}M`;
  if (tokens % 1024 === 0) return `${tokens / 1024}K`;
  return String(tokens);
}

function currentCapacity(config, model) {
  const models = Array.isArray(config?.models) ? config.models : [];
  const selected = models.find((entry) => entry?.id === model);
  return selected?.contextWindow ?? config?.defaultContextWindow ?? DEFAULT_CONTEXT_WINDOW;
}

function contextStatus(config, agent) {
  const model = modelFor(agent);
  const capacity = currentCapacity(config, model);
  const modelLabel = model ?? "当前默认模型";
  return `模型 ${modelLabel} 的上下文窗口为 ${formatTokens(capacity)} tokens；自动压缩阈值为 ${formatTokens(Math.floor(capacity * 0.75))} tokens。`;
}

async function executeContextCommand(ctx, invocation) {
  const config = ctx.settings.get(DEEPSEEK_SETTINGS);
  if (config === undefined) {
    return { kind: "error", text: "DeepSeek 模型设置当前不可用。" };
  }

  const value = parseContextWindow(invocation.rawInput);
  if (value === null) return { kind: "success", text: contextStatus(config, invocation.agent) };
  if (value === undefined) {
    return { kind: "error", text: "用法：/context、/context 256k 或 /context 1m" };
  }

  const model = modelFor(invocation.agent);
  const models = Array.isArray(config.models) ? config.models : [];
  const selected = model === undefined ? undefined : models.find((entry) => entry?.id === model);
  const patch = { defaultContextWindow: value };
  if (selected !== undefined) {
    patch.models = models.map((entry) => entry?.id === model
      ? { ...entry, contextWindow: value }
      : entry);
  } else if (models.length > 0) {
    patch.models = models.map((entry) => ({ ...entry, contextWindow: value }));
  }

  try {
    await ctx.settings.update(DEEPSEEK_SETTINGS, patch);
  } catch (error) {
    ctx.logger.warn(`context setting update failed: ${String(error)}`);
    return { kind: "error", text: `上下文设置未能保存：${String(error)}` };
  }

  const target = selected === undefined ? "已配置的 DeepSeek 模型" : `模型 ${model}`;
  return {
    kind: "success",
    text: `${target}的上下文窗口已设置为 ${formatTokens(value)} tokens；自动压缩将在约 ${formatTokens(Math.floor(value * 0.75))} tokens 时触发。`,
  };
}

function renderResult(_args, value) {
  if (value?.ok === false) return [{ type: "text", text: `上下文压缩不可用：${value.reason ?? "未知原因"}` }];
  if (value?.status === "scheduled") {
    return [{ type: "text", text: "已调度上下文压缩，将在当前回合结束后执行。" }];
  }
  if (value?.status === "already-scheduled") {
    return [{ type: "text", text: "本回合已经排队过上下文压缩。" }];
  }
  return [{ type: "text", text: "上下文压缩请求已处理。" }];
}

export function apply(ctx) {
  const pending = new Set();

  ctx.effect(() => ctx.commands.register({
    name: "context",
    description: "用法：/context 查看；/context 256k 或 /context 1m 设置窗口",
    input: { hint: "<size>，例如 256k 或 1m" },
    handler: (invocation) => executeContextCommand(ctx, invocation),
  }), "dsh-minimal-mode-compaction /context command");

  ctx.tools.register(defineTool({
    name: "compact_now",
    description: "Schedule compaction of older conversation history after the current turn ends.",
    parameters: {},
    output: {
      schema: {
        type: "object",
        additionalProperties: false,
        properties: {
          ok: { type: "boolean", required: true },
          status: { type: "string" },
          reason: { type: "string" },
          shadowed: { type: "number" },
          tokens: { type: "number" },
        },
      },
      render: renderResult,
    },
    timeoutMs: 15000,
    isConcurrencySafe: () => true,
    async execute(_args, execution) {
      const agents = ctx.get("agents");
      const agent = agents?.requireInitiator();
      if (agent === undefined) return { ok: false, reason: "no active agent" };

      const compaction = agent.ctx.get("compaction");
      if (compaction === undefined) {
        return { ok: false, reason: "compaction service is unavailable for this preset" };
      }
      if (pending.has(agent.id)) return { ok: true, status: "already-scheduled" };

      pending.add(agent.id);
      const signal = execution.signal ?? new AbortController().signal;
      const runWhenIdle = async () => {
        try {
          await agent.whenIdle();
          for (let attempt = 0; ; attempt += 1) {
            try {
              const result = await compaction.compactNow(agent, signal);
              if (result === null) return { status: "no-compactable-history" };
              return {
                status: "done",
                shadowed: result.shadowedSeqs.length,
                tokens: result.shadowedTokenCount,
              };
            } catch (error) {
              const busy = error instanceof ManualCompactionError && error.code === "busy";
              if (!busy || attempt >= RETRY_LIMIT) {
                ctx.logger.warn(`model-requested compaction failed: ${String(error)}`);
                return { status: "failed", reason: String(error) };
              }
              await ctx.timer.timeout(RETRY_DELAY_MS);
            }
          }
        } catch (error) {
          ctx.logger.warn(`model-requested compaction could not start: ${String(error)}`);
          return { status: "failed", reason: String(error) };
        } finally {
          pending.delete(agent.id);
        }
      };

      // The tool must return during the current turn. The durable compaction
      // result is visible in the following turn's session history.
      void runWhenIdle();
      return { ok: true, status: "scheduled" };
    },
    presentCall: () => ({ card: "generic", title: "调度上下文压缩", kind: "compact", rawInput: "" }),
  }));

  ctx.effect(() => () => pending.clear(), "dsh-minimal-mode-compaction pending cleanup");
}

export default { name, inject, apply };
