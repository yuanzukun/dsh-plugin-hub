#!/usr/bin/env node

import { access, mkdir, readFile, writeFile } from "node:fs/promises";
import { constants } from "node:fs";
import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";
import { parseDocument } from "yaml";

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const packageManifest = JSON.parse(await readFile(join(packageRoot, "package.json"), "utf8"));
const packageName = packageManifest.name;
const presetId = "minimal-compaction";
const repositorySpec = "github:wicm84266964/dsh-minimal-mode-compaction";
const profileTemplates = {
  web: ["@deepseek-ai/dsh-base", "@deepseek-ai/dsh-web-app"],
  headless: ["@deepseek-ai/dsh-base", "@deepseek-ai/dsh-headless"],
};

export function parseArgs(argv) {
  const options = {
    dshHome: process.env.DSH_HOME ?? join(homedir(), ".dsh"),
    profile: "web",
    source: process.env.DSH_MINIMAL_MODE_COMPACTION_SPEC,
    noDefault: false,
    keepPreset: false,
    dryRun: false,
  };

  for (let index = 0; index < argv.length; index += 1) {
    const arg = argv[index];
    if (arg === "--dsh-home") options.dshHome = requiredValue(argv, ++index, arg);
    else if (arg === "--profile") options.profile = requiredValue(argv, ++index, arg);
    else if (arg === "--source") options.source = requiredValue(argv, ++index, arg);
    else if (arg === "--no-default") options.noDefault = true;
    else if (arg === "--keep-preset") options.keepPreset = true;
    else if (arg === "--dry-run") options.dryRun = true;
    else if (arg === "--help" || arg === "-h") {
      console.log(`Usage: npx --yes ${repositorySpec}

Options:
  --profile NAME       DSH profile to install into (default: web)
  --dsh-home PATH      DSH home directory (default: $DSH_HOME or ~/.dsh)
  --source SPEC        package spec to add to the profile
  --no-default         install the preset without changing the default preset
  --keep-preset        keep an existing preset instead of replacing it
  --dry-run            print paths and commands without changing anything`);
      process.exit(0);
    } else {
      throw new Error(`unknown argument: ${arg}`);
    }
  }

  if (!/^[a-z0-9][a-z0-9-]*$/.test(options.profile)) {
    throw new Error(`invalid profile name: ${options.profile}`);
  }
  options.dshHome = resolve(options.dshHome);
  return options;
}

function requiredValue(argv, index, flag) {
  const value = argv[index];
  if (value === undefined || value.startsWith("--")) throw new Error(`${flag} requires a value`);
  return value;
}

async function exists(path) {
  try {
    await access(path, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

function commandCandidates(name) {
  if (process.platform !== "win32") return [name];
  return [`${name}.cmd`, `${name}.exe`, name];
}

function canRun(command) {
  const result = spawnSync(command, ["--version"], {
    stdio: "ignore",
    shell: process.platform === "win32",
  });
  return result.error === undefined && result.status === 0;
}

function findCommand(name) {
  return commandCandidates(name).find(canRun);
}

function runCommand(command, args, options = {}) {
  const result = spawnSync(command, args, {
    cwd: options.cwd,
    env: options.env ?? process.env,
    stdio: "inherit",
    shell: process.platform === "win32",
  });
  if (result.error !== undefined) throw result.error;
  if (result.status !== 0) {
    throw new Error(`${command} ${args.join(" ")} exited with code ${result.status ?? 1}`);
  }
}

function resolvePackageManager() {
  const direct = findCommand("pnpm");
  if (direct !== undefined) return { command: direct, prefix: [], direct: true };

  const npx = findCommand("npx");
  if (npx !== undefined) return { command: npx, prefix: ["--yes", "pnpm"], direct: false };

  throw new Error("找不到 pnpm 或 npx；请先安装 Node.js，或把 pnpm 加入 PATH 后重试。");
}

function resolveDshCommand() {
  const requested = process.env.DSH_BIN;
  if (requested !== undefined && requested !== "") return requested;
  return findCommand("dsh");
}

async function isLocalCheckout() {
  return exists(join(packageRoot, ".git"));
}

async function resolvePluginSpec(options) {
  if (options.source !== undefined) return options.source;
  if (await isLocalCheckout()) return `file:${packageRoot}`;
  return repositorySpec;
}

async function ensureProfileSkeleton(profileDir, profile) {
  await mkdir(profileDir, { recursive: true });
  const manifestPath = join(profileDir, "package.json");
  if (!await exists(manifestPath)) {
    const bundles = profileTemplates[profile] ?? ["@deepseek-ai/dsh-base"];
    await writeFile(manifestPath, `${JSON.stringify({
      name: `dsh-profile-${profile}`,
      private: true,
      dependencies: {},
      dsh: { profile: { bundles } },
    }, null, 2)}\n`);
  }

  const patchPath = join(profileDir, "cordis.patch.yml");
  if (!await exists(patchPath)) await writeFile(patchPath, "[]\n");

  const workspacePath = join(profileDir, "pnpm-workspace.yaml");
  if (!await exists(workspacePath)) {
    await writeFile(workspacePath, "packages:\n  - .\n\nnodeLinker: hoisted\nautoInstallPeers: false\n");
  }
}

async function reconcileLocalInstall(profileDir, spec) {
  const manifestPath = join(profileDir, "package.json");
  const manifest = JSON.parse(await readFile(manifestPath, "utf8"));
  manifest.dependencies ??= {};
  if (manifest.dependencies[packageName] === undefined) manifest.dependencies[packageName] = spec;
  manifest.dsh ??= {};
  manifest.dsh.profile ??= {};
  manifest.dsh.profile.bundles ??= [];
  if (!manifest.dsh.profile.bundles.includes(packageName)) manifest.dsh.profile.bundles.push(packageName);
  await writeFile(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`);
}

function runPnpm(packageManager, profileDir, args) {
  runCommand(packageManager.command, [...packageManager.prefix, ...args], { cwd: profileDir });
}

async function installProfilePlugin(options, profileDir, spec, packageManager) {
  const dsh = resolveDshCommand();
  if (dsh !== undefined && packageManager.direct) {
    console.log(`Adding ${packageName} to the ${options.profile} profile...`);
    runCommand(dsh, ["plugin", "--profile", options.profile, "add", spec], {
      env: { ...process.env, DSH_HOME: options.dshHome },
    });
    return;
  }

  const npx = findCommand("npx");
  if (npx !== undefined && packageManager.direct) {
    console.log(`Adding ${packageName} to the ${options.profile} profile...`);
    runCommand(npx, ["--yes", "@deepseek-ai/dsh", "plugin", "--profile", options.profile, "add", spec], {
      env: { ...process.env, DSH_HOME: options.dshHome },
    });
    return;
  }

  await ensureProfileSkeleton(profileDir, options.profile);
  console.log(`Adding ${packageName} to the ${options.profile} profile...`);
  runPnpm(packageManager, profileDir, ["add", spec, "--config.auto-install-peers=true"]);
  await reconcileLocalInstall(profileDir, spec);
}

async function installPreset(options) {
  const installer = join(packageRoot, "scripts", "install-preset.mjs");
  const args = [installer, "--dsh-home", options.dshHome, "--id", presetId];
  if (!options.keepPreset) args.push("--force");
  runCommand(process.execPath, args, { cwd: packageRoot });
}

export async function updateDefaultPreset(dshHome, id = presetId) {
  const settingsPath = join(resolve(dshHome), "settings.yaml");
  const source = await exists(settingsPath) ? await readFile(settingsPath, "utf8") : "{}\n";
  const document = parseDocument(source);
  if (document.errors.length > 0) {
    throw new Error(`无法解析 ${settingsPath}：${document.errors[0].message}`);
  }

  const current = document.get("agent-presets");
  if (current === undefined || current === null) {
    document.set("agent-presets", { default: id });
  } else if (typeof current !== "object" || Array.isArray(current)) {
    throw new Error(`${settingsPath} 中的 agent-presets 必须是 YAML 对象。`);
  } else {
    document.setIn(["agent-presets", "default"], id);
  }

  await mkdir(dirname(settingsPath), { recursive: true });
  await writeFile(settingsPath, document.toString());
  return settingsPath;
}

export async function install(options) {
  const profileDir = join(options.dshHome, "profiles", options.profile);
  const spec = await resolvePluginSpec(options);

  if (options.dryRun) {
    console.log(`profile: ${profileDir}`);
    console.log(`plugin: ${spec}`);
    console.log(`preset: ${join(options.dshHome, ".agent-presets", presetId)}`);
    console.log(`default: ${options.noDefault ? "unchanged" : join(options.dshHome, "settings.yaml")}`);
    return;
  }

  const packageManager = resolvePackageManager();
  await installProfilePlugin(options, profileDir, spec, packageManager);
  console.log("Installing peer dependencies for the profile...");
  runPnpm(packageManager, profileDir, ["install", "--config.auto-install-peers=true"]);
  await installPreset(options);

  if (options.noDefault) {
    console.log(`default preset unchanged; select ${presetId} in the Harness UI`);
  } else {
    const settingsPath = await updateDefaultPreset(options.dshHome);
    console.log(`default preset: ${settingsPath} -> ${presetId}`);
  }

  console.log("Installation complete. Restart DeepSeek Harness to load the plugin in new sessions.");
}

if (process.argv[1] !== undefined && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  try {
    await install(parseArgs(process.argv.slice(2)));
  } catch (error) {
    console.error(`dsh-minimal-mode-compaction: ${error instanceof Error ? error.message : String(error)}`);
    process.exitCode = 1;
  }
}
