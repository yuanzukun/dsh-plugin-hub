#!/usr/bin/env node

import { access, cp, mkdir, rename } from "node:fs/promises";
import { constants } from "node:fs";
import { homedir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const packageRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const source = join(packageRoot, "preset");

function parseArgs(argv) {
  const options = { dshHome: process.env.DSH_HOME ?? join(homedir(), ".dsh"), id: "minimal-compaction", force: false, dryRun: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--dsh-home") options.dshHome = requiredValue(argv, ++i, arg);
    else if (arg === "--id") options.id = requiredValue(argv, ++i, arg);
    else if (arg === "--force") options.force = true;
    else if (arg === "--dry-run") options.dryRun = true;
    else if (arg === "--help" || arg === "-h") {
      console.log("Usage: node scripts/install-preset.mjs [--dsh-home PATH] [--id ID] [--force] [--dry-run]");
      process.exit(0);
    } else {
      throw new Error(`unknown argument: ${arg}`);
    }
  }
  if (!/^[a-z0-9][a-z0-9-]*$/.test(options.id)) {
    throw new Error(`invalid preset id: ${options.id}`);
  }
  return options;
}

function requiredValue(argv, index, flag) {
  const value = argv[index];
  if (value === undefined || value.startsWith("--")) throw new Error(`${flag} requires a value`);
  return value;
}

async function exists(path) {
  try {
    await access(path, constants.F_OK);
    return true;
  } catch {
    return false;
  }
}

const options = parseArgs(process.argv.slice(2));
const target = join(resolve(options.dshHome), ".agent-presets", options.id);

if (await exists(target) && !options.force) {
  throw new Error(`preset already exists: ${target}; use --force only to replace it`);
}

if (options.dryRun) {
  console.log(`${options.force ? "replace" : "create"}: ${target}`);
  process.exit(0);
}

await mkdir(join(resolve(options.dshHome), ".agent-presets"), { recursive: true });
if (options.force && await exists(target)) {
  const backup = `${target}.backup-${new Date().toISOString().replace(/[:.]/g, "-")}`;
  await rename(target, backup);
  try {
    await cp(source, target, { recursive: true, errorOnExist: true });
  } catch (error) {
    await rename(backup, target);
    throw error;
  }
  console.log(`backup: ${backup}`);
} else {
  await cp(source, target, { recursive: true, errorOnExist: true });
}
console.log(`installed preset: ${target}`);
console.log(`select preset: ${options.id}`);
