/**
 * DSH Vision Toolkit browser plugin: dedicated Tool cards plus the Settings,
 * health, connection-test, and safe Artifact preview experience.
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
/**
 * `ToolCallBlock` is the one DSH type this bundle consumes by name. DSH 0.1.5
 * publishes it from `@deepseek-ai/dsh-client-ui-conversation/client`; its
 * earlier home, `@deepseek-ai/dsh-client-runtime/client`, stopped publishing
 * after 0.1.1-rc.2 and has no member of the 0.1.5 family at all, so importing
 * the old specifier would leave an unresolvable peer on a real host. The
 * `paths` row in tsconfig.client.json and the peerDependency in package.json
 * name the same package, and both must move together. A type-only import costs
 * nothing at runtime and emits no `require()` in lib/client.js.
 */
import type { ToolCallBlock } from '@deepseek-ai/dsh-client-ui-conversation/client';
declare const en: {
    readonly nav: "Vision";
    readonly settingsTitle: "Vision Toolkit";
    readonly settingsIntro: "Configure the pinned visual engineering runtime, its external vision endpoint, and local safety limits.";
    readonly externalNotice: "Remote tools send the selected image bytes to the configured external vision API. Local crop, trace, pixel diff, palette, foreground extraction, and HTML rendering do not upload images.";
    readonly provider: "Vision service";
    readonly providerHint: "Choose the API protocol, then provide the service address, model, and API key used by online vision features.";
    readonly aihubmixTutorial: "Need an AIHubMix key for free Gemini 3.7 Flash vision? Follow the signup guide →";
    readonly baseUrl: "Base URL";
    readonly apiKey: "API key";
    readonly apiKeyPlaceholderMissing: "Paste the API key";
    readonly apiKeyPlaceholderConfigured: "Saved; leave blank to keep it";
    readonly apiKeyHint: "The key is stored in DSH Credentials and is never shown again after saving.";
    readonly apiKeyLocked: "The current key comes from a read-only source and cannot be replaced here.";
    readonly apiKeyBlank: "The API key cannot contain only spaces.";
    readonly apiKeyInvalid: "Paste only the key, without a variable name, quotes, spaces, or line breaks.";
    readonly credential: "Credential name";
    readonly credentialHint: "The built-in free provider needs no user key. For a custom provider, this is the DSH credential reference used to store its key.";
    readonly model: "Model";
    readonly protocol: "API protocol";
    readonly reasoningEffort: "Vision service reasoning effort";
    readonly reasoningEffortHint: "Optional. Common values: none, minimal, low, medium, high, xhigh. Supported values and billing depend on the model or proxy; higher effort may increase tokens, latency, and cost. Requests send store:false, but you should still verify the provider's data-retention policy.";
    readonly reasoningEffortInvalid: "Vision service reasoning effort must be at most 64 ASCII letters, digits, dots, underscores, or hyphens.";
    readonly anthropicThinking: "Anthropic thinking";
    readonly anthropicThinkingHint: "omit has the broadest compatibility. Use disabled or adaptive only when the selected model documents that mode; restore omit first after HTTP 400.";
    readonly userAgent: "User-Agent";
    readonly language: "Output language";
    readonly limits: "Limits";
    readonly timeout: "Request timeout (ms)";
    readonly maxBytes: "Maximum image bytes";
    readonly maxPixels: "Maximum image pixels";
    readonly concurrency: "Concurrent calls per session";
    readonly runtime: "Runtime";
    readonly runtimeMode: "Runtime mode";
    readonly toolkitPath: "Pinned checkout path";
    readonly python: "Python override";
    readonly storage: "Local files";
    readonly storageDir: "Default save directory";
    readonly storageDirHint: "Leave blank to keep .dsh-vision-toolkit in each workspace. On POSIX systems, set an absolute shared root such as /tmp/dsh-vision-toolkit to store artifacts, pasted images, and caches in an automatically generated per-user, workspace-specific child directory. Windows shared roots remain disabled until their ACLs can be verified safely.";
    readonly allowedDirs: "Additional allowed directories";
    readonly allowedDirsHint: "One path per line. The session workspace is always allowed.";
    readonly save: "Save and apply";
    readonly saving: "Validating runtime…";
    readonly reload: "Reload";
    readonly saved: "Settings validated and applied.";
    readonly readOnly: "Service settings are read-only. A writable API key can still be saved.";
    readonly configured: "Configured";
    readonly missing: "Missing";
    readonly source: "Source";
    readonly sourceHint: "{source}: {value}";
    readonly sourceEnv: "Environment variable";
    readonly sourceFile: "Credential file";
    readonly health: "Health";
    readonly runHealth: "Run health check";
    readonly testConnection: "Test API connection";
    readonly testModel: "Test vision model";
    readonly testing: "Checking…";
    readonly testingModel: "Testing model…";
    readonly connectionHint: "The API connection test only queries GET /models. The vision model test sends the bundled diagnostic image and verifies one real multimodal request.";
    readonly saveBeforeTesting: "Save service changes before testing the connection.";
    readonly advanced: "Advanced settings";
    readonly advancedHint: "Credential name, provider compatibility, output language, resource limits, default save directory, runtime source, Python, and additional readable directories.";
    readonly imageInput: "Image input";
    readonly hiddenVariants: "Transparent variant routing";
    readonly hiddenVariantsLabel: "Keep the original model names and enable images automatically";
    readonly hiddenVariantsHint: "Text-only models keep one model-selector entry with the original name while the session runs on the image-capable variant. Pasted images, image history, and the built-in read_image tool keep working; disable to restore the explicit (Vision Toolkit) entries.";
    readonly pluginVersion: "Plugin";
    readonly upstreamVersion: "Upstream";
    readonly activeGeneration: "Runtime generation";
    readonly activeGenerationValue: "Generation {generation}";
    readonly updates: "Plugin updates";
    readonly updatesHint: "Check npm for a newer release, install it into this DSH profile, and restart DSH Web automatically.";
    readonly manualUpdate: "Manual update";
    readonly manualUpdateHint: "Run this command in your terminal to install the latest release into this DSH profile.";
    readonly copy: "Copy";
    readonly copied: "Copied";
    readonly checkUpdate: "Check for updates";
    readonly checkingUpdate: "Checking for updates…";
    readonly updateAvailable: "Update available";
    readonly updateAvailableDetail: "Version {version} is available. It will restart DSH Web automatically when safe; otherwise you will be asked to restart it manually.";
    readonly upToDate: "Up to date";
    readonly upToDateDetail: "Version {version} is the latest release.";
    readonly updateNow: "Install update";
    readonly updatingPlugin: "Installing update…";
    readonly updateConfirm: "Install Vision Toolkit {version} now? DSH Web will restart automatically when supported; otherwise a manual restart will be required.";
    readonly restarting: "Version {version} was installed. Waiting for DSH Web to restart…";
    readonly manualRestartRequired: "Version {version} was installed. Restart DSH Web through your usual command or process manager to activate it.";
    readonly updateProfile: "Profile";
    readonly updateInstalled: "Installed";
    readonly updateLatest: "Latest";
    readonly updateUnsupported: "In-app updates are unavailable for this installation.";
    readonly updateReasonProfileNotFound: "The running plugin could not be matched to a DSH profile installation.";
    readonly updateReasonNotDependency: "The plugin is not a direct dependency of this DSH profile.";
    readonly updateReasonLocalSource: "This profile uses a local, workspace, URL, or git installation; update that source manually so local work is not overwritten.";
    readonly updateReasonReadOnly: "The profile package manifest is read-only.";
    readonly updateReasonPnpm: "pnpm is unavailable in the DSH execution environment.";
    readonly updateReasonPlatform: "Automatic restart is unavailable on this operating system.";
    readonly updateReasonRestartUnmanaged: "Detached self-restart is disabled. Use a supported process manager, or explicitly opt in with DSH_VISION_TOOLKIT_ALLOW_DETACHED_RESTART=1 for an unsupervised Web process.";
    readonly updateReasonRestartAddress: "Automatic restart is unavailable when DSH Web uses an unknown or dynamically allocated port. Start it with a fixed --port value.";
    readonly updateSaveFirst: "Save or discard the current Settings and API key changes before updating the plugin.";
    readonly restartTimedOut: "DSH Web did not return with the target plugin version. Check the restart log and restart the Web profile through its original process manager.";
    readonly restartRolledBack: "The new plugin did not become ready, so the previous version was restored. Check the restart log before trying again.";
    readonly pluginKind: "DSH native plugin";
    readonly runtimeUnavailable: "Runtime unavailable";
    readonly runtimeCandidateRejected: "Last runtime candidate was rejected; the active generation remains available.";
    readonly runtimeReady: "Ready";
    readonly runtimeManaged: "Managed";
    readonly runtimeExternal: "External checkout";
    readonly retry: "Retry";
    readonly open: "Open file";
    readonly download: "Download";
    readonly previewUnavailable: "HTTP preview is unavailable in this host; use Open file.";
    readonly running: "Running…";
    readonly failed: "Failed";
    readonly matches: "matches";
    readonly elements: "elements";
    readonly dimensions: "Dimensions";
    readonly coordinates: "Coordinates";
    readonly artifact: "Artifact";
    readonly artifacts: "Artifacts";
    readonly difference: "Overall difference";
    readonly worstRegions: "Worst regions";
    readonly colors: "Dominant colors";
    readonly noResult: "Structured result unavailable; inspect the raw Tool result.";
    readonly healthy: "Healthy";
    readonly degraded: "Needs attention";
    readonly notTested: "Not tested";
    readonly groundTitle: "Ground";
    readonly detectTitle: "Detect";
    readonly traceTitle: "Trace SVG";
    readonly pixelDiffTitle: "Pixel Diff";
    readonly cropTitle: "Crop";
    readonly longOcrTitle: "Long OCR";
    readonly extractForegroundTitle: "Extract Foreground";
    readonly htmlScreenshotTitle: "HTML Screenshot";
    readonly artifactTitle: "Vision Artifact";
    readonly dominantColorsTitle: "Dominant Colors";
    readonly artifactGroundPreview: "Grounding bounding-box preview";
    readonly artifactDetectPreview: "Detected-element bounding-box preview";
    readonly artifactCrop: "Cropped image region";
    readonly artifactTrace: "Traced vector geometry";
    readonly artifactDiffHeatmap: "Pixel-difference heatmap";
    readonly artifactDiffReport: "Structured pixel-difference report";
    readonly artifactLongManifest: "Long-screenshot split and merge manifest";
    readonly artifactLongTranscript: "Merged long-screenshot OCR transcript";
    readonly artifactLongAudit: "Long-screenshot OCR boundary audit";
    readonly artifactLongChunk: "Long-screenshot OCR chunk {index}";
    readonly artifactOcrSidecar: "OCR sidecar for chunk {index}";
    readonly artifactForeground: "Extracted transparent foreground";
    readonly artifactHtmlScreenshot: "Headless browser screenshot of local HTML";
    readonly label: "Label";
    readonly paths: "paths";
    readonly healthPython: "Python";
    readonly healthDependencies: "Dependencies";
    readonly healthChrome: "Browser";
    readonly healthCredential: "Credential";
    readonly healthArtifactDirectory: "Artifact directory";
    readonly healthTempDirectory: "Temporary directory";
    readonly healthService: "Vision service";
    readonly healthModel: "Vision model";
    readonly statusOk: "OK";
    readonly statusWarning: "Warning";
    readonly statusError: "Error";
    readonly statusNotTested: "Not tested";
    readonly positiveInteger: "{field} must be a positive integer.";
    readonly healthPythonDetail: "{version} via {path}";
    readonly healthChromeMissing: "Chrome, Chromium, or Edge was not found; HTML Screenshot is unavailable.";
    readonly healthChromeProbeFailed: "Could not check whether a supported browser is available.";
    readonly healthCredentialMissing: "Credential {credential} is not configured.";
    readonly healthCredentialReady: "Credential {credential} is available.";
    readonly healthCredentialFailed: "Could not read credential {credential}.";
    readonly healthDirectoryWritable: "{directory} is writable: {path}";
    readonly healthDirectoryNotWritable: "{directory} is not writable: {path}";
    readonly healthArtifactDirectoryFailed: "Could not prepare the artifact directory.";
    readonly healthConnectionNotTested: "API connection not tested. Use Test API connection to query /models.";
    readonly healthConnectionCredentialMissing: "Connection test skipped because the credential is unavailable.";
    readonly healthServiceResponded: "Service responded at {endpoint} (HTTP {status}).";
    readonly healthServiceRejectedCredential: "Service rejected the configured credential (HTTP {status}).";
    readonly healthServiceForbidden: "Service is reachable, but GET /models is restricted (HTTP {status}). This is often an account or model-list permission limit, not an invalid key; you can ignore this warning when the vision-model test reports success.";
    readonly healthServiceNoModels: "Service is reachable but does not support GET /models (HTTP {status}).";
    readonly healthServiceRateLimited: "Service is reachable, but the connection test was rate-limited (HTTP 429). Wait for the Retry-After interval or configure your own vision endpoint in Settings.";
    readonly healthServiceHttpFailed: "Connection test failed with HTTP {status}.";
    readonly healthServiceUnreachable: "Could not reach {endpoint}.";
    readonly healthModelNotTested: "Vision model not tested. Run Test vision model to make one real multimodal request.";
    readonly healthModelCredentialMissing: "Vision model test skipped because the credential is unavailable.";
    readonly healthModelReady: "Model {model} completed a real multimodal request.";
    readonly healthModelFailed: "Real multimodal request failed: {detail}";
    readonly modelTestVerifiedTag: "Verified";
    readonly modelTestNotRunTag: "Not tested";
    readonly modelTestFailedTag: "Test failed";
};
type LocaleKey = keyof typeof en;
interface ToolCallOwnerProps {
    callId: string;
    toolName: string;
    block: ToolCallBlock;
    cwd?: string | undefined;
    openFile: (path: string) => void;
    inspect?: (() => void) | undefined;
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /** Keyed atomic Tool call view, dispatched by wire Tool name. */
        'tool.call.toolview': {
            kind: 'keyed';
            scope: 'session';
            owner: ToolCallOwnerProps;
        };
    }
    interface LocaleNamespaceMap {
        /** DSH Vision Toolkit Tool cards and Settings copy. */
        'vision-toolkit': LocaleKey;
    }
}
interface HealthCheck {
    status: 'ok' | 'warning' | 'error' | 'not_tested';
    detail: string;
}
interface HealthResult {
    pluginVersion: string;
    checks: Record<string, HealthCheck>;
    healthy: boolean;
    connectionTested: boolean;
    modelTested: boolean;
}
interface SettingsValue {
    provider?: {
        baseUrl?: string;
        credential?: string;
        model?: string;
        protocol?: 'openai' | 'responses' | 'anthropic';
        reasoningEffort?: string;
        anthropicThinking?: 'omit' | 'disabled' | 'adaptive';
        userAgent?: string;
        headers?: Record<string, string>;
        sessionHeaders?: string[];
    };
    language?: 'zh' | 'en';
    timeoutMs?: number;
    maxImageBytes?: number;
    maxImagePixels?: number;
    concurrency?: number;
    runtime?: {
        mode?: 'managed' | 'external';
        agentVisionToolkitPath?: string;
        python?: string;
    };
    storageDir?: string;
    storageHistory?: string[];
    allowedDirs?: string[];
    imageInputVariants?: {
        enabled?: boolean;
        providers?: string[];
        autoSwitch?: boolean;
        hidden?: boolean;
    };
}
type PluginUpdateUnavailableReason = 'profile-not-found' | 'not-direct-dependency' | 'unsupported-install-source' | 'profile-read-only' | 'pnpm-unavailable' | 'unsupported-platform' | 'restart-unmanaged' | 'restart-address-unavailable';
interface PluginUpdateCapability {
    supported: boolean;
    checkSupported?: boolean;
    profile?: string;
    dependencySpec?: string;
    reason?: PluginUpdateUnavailableReason;
}
interface PluginUpdateCheck extends PluginUpdateCapability {
    currentVersion: string;
    latestVersion?: string;
    updateAvailable: boolean;
    checkedAt: string;
}
type PluginUpdateResult = {
    fromVersion: string;
    toVersion: string;
    profile: string;
    restarting: true;
    retryAfterMs: number;
    manualRestartRequired?: false;
} | {
    fromVersion: string;
    toVersion: string;
    profile: string;
    restarting: false;
    manualRestartRequired: true;
    retryAfterMs?: undefined;
};
interface SettingsSnapshot {
    schemaVersion: 1;
    writable: boolean;
    settings: {
        value: SettingsValue;
        revision: number;
        applies: 'live';
    };
    credential: {
        ref: string;
        configured: boolean;
        source?: string;
        writable: boolean;
    };
    runtime: {
        ready: boolean;
        generation: number;
        activeConfig?: SettingsValue;
        upstream?: {
            source: 'managed' | 'external';
            path: string;
            runtimeHome: string;
            python: string;
            pythonVersion: string;
        };
        lastError?: string;
    };
    release: {
        pluginVersion: string;
        upstreamRepository: string;
        upstreamVersion: string;
        upstreamCommit: string;
        update: PluginUpdateCapability;
    };
    artifactRouteAvailable: boolean;
}
/** Decode canonical presentation metadata with a JSON-text fallback. */
export declare function decodeVisionResult(block: ToolCallBlock): Record<string, unknown> | undefined;
interface SettingsState {
    status: 'idle' | 'loading' | 'ready' | 'error';
    snapshot?: SettingsSnapshot | undefined;
    health?: HealthResult | undefined;
    update?: PluginUpdateCheck | undefined;
    restart?: PluginUpdateResult | undefined;
    action?: 'save' | 'health' | 'connection' | 'model' | 'check-update' | 'apply-update' | undefined;
    message?: string | undefined;
    error?: string | undefined;
}
/** Small external store shared by the Settings route and pushed invalidations. */
export declare class VisionSettingsController {
    private state;
    private listeners;
    private generation;
    subscribe: (listener: () => void) => (() => void);
    snapshot: () => SettingsState;
    private set;
    load(): Promise<void>;
    refreshIfLoaded(): void;
    save(value: SettingsValue, expectedRevision: number, credentialValue: string | undefined, writeSettings: boolean): Promise<boolean>;
    runHealth(mode: 'health' | 'connection' | 'model'): Promise<void>;
    checkUpdate(): Promise<void>;
    applyUpdate(expectedVersion: string): Promise<void>;
    reportRestartTimeout(message: string): void;
}
/** Required client services. The pasted-image codec attaches to either trigger-service generation after load. */
export declare const inject: string[];
/** Register dedicated Tool views and the Vision Settings section. */
export declare function apply(ctx: ClientContext): void;
export {};
//# sourceMappingURL=index.d.ts.map