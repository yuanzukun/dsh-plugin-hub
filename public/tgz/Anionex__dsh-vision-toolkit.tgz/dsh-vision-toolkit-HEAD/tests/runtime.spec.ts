import { copyFile, lstat, mkdir, mkdtemp, readFile, readdir, realpath, rm, symlink, writeFile } from 'node:fs/promises'
import { createHmac } from 'node:crypto'
import { createServer } from 'node:http'
import { homedir, tmpdir } from 'node:os'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import LocalSubprocessService from '@deepseek-ai/dsh-subprocess-local'
import type { Credentials } from '@deepseek-ai/dsh-credentials'
import { resolveConfig, type VisionToolkitConfig } from '../src/config.ts'
import { VisionToolkitError } from '../src/errors.ts'
import { createPathPolicy, workspaceStorageId } from '../src/paths.ts'
import {
  createDeadline,
  createVisionProviderHeaderResolver,
  Semaphore,
  VisionToolkitRuntime,
} from '../src/runtime.ts'
import {
  UpstreamAdapter,
  type UpstreamEnvironment,
  type UpstreamRunResult,
  type UpstreamTool,
} from '../src/upstream.ts'
import type { PreparedUpstreamRuntime } from '../src/runtime-install.ts'
import { UPSTREAM_VERSION } from '../src/version.ts'

const FIXTURE_UPSTREAM = fileURLToPath(new URL('./fixtures/upstream', import.meta.url))
const VENDORED_UPSTREAM = fileURLToPath(new URL('../vendor/agent-vision-toolkit', import.meta.url))
const SAMPLE_IMAGE = fileURLToPath(new URL('./fixtures/sample.png', import.meta.url))

const tempDirs: string[] = []
const contexts: Context[] = []

async function tempWorkspace(): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'dsh-vision-toolkit-runtime-'))
  tempDirs.push(dir)
  await copyFile(SAMPLE_IMAGE, join(dir, 'sample.png'))
  return dir
}

async function outsideTempDir(prefix: string): Promise<string> {
  const dir = await mkdtemp(join(homedir(), `.dsh-vision-toolkit-runtime-${prefix}-`))
  tempDirs.push(dir)
  return dir
}

afterEach(async () => {
  vi.unstubAllEnvs()
  await Promise.all(contexts.splice(0).map(ctx => ctx.fiber.dispose()))
  await Promise.all(tempDirs.splice(0).map(dir => rm(dir, { recursive: true, force: true })))
})

function preparedFixture(cleanHome = FIXTURE_UPSTREAM): PreparedUpstreamRuntime {
  return {
    source: 'external',
    root: FIXTURE_UPSTREAM,
    python: { program: 'python3', prefix: [], display: 'python3' },
    cleanHome,
    pythonVersion: '3.11+',
    dependencies: { pillow: 'fixture', numpy: 'fixture', vtracer: 'fixture' },
  }
}

function preparedVendored(cleanHome: string): PreparedUpstreamRuntime {
  return {
    source: 'managed',
    root: VENDORED_UPSTREAM,
    python: { program: 'python3', prefix: [], display: 'python3' },
    cleanHome,
    pythonVersion: '3.11+',
    dependencies: {},
  }
}

async function setup(
  overrides: VisionToolkitConfig = {},
  credential: string | null = 'test-vision-key',
  prepared = preparedFixture(),
  readableStorageDirs: readonly string[] = [],
) {
  const ctx = new Context()
  contexts.push(ctx)
  await ctx.plugin(LocalSubprocessService)
  ctx.provide('credentials', {
    async resolve() {
      return credential === null ? undefined : { value: credential, source: 'env' }
    },
  } as unknown as Credentials)
  const config = resolveConfig({
    provider: {
      baseUrl: 'https://vision.example/v1',
      credential: 'VISION_API_KEY',
      model: 'fixture-model',
    },
    runtime: { mode: 'external', agentVisionToolkitPath: FIXTURE_UPSTREAM, python: 'python3' },
    ...overrides,
  })
  const adapter = new UpstreamAdapter(ctx, config, prepared)
  const runtime = new VisionToolkitRuntime(ctx, config, adapter, readableStorageDirs)
  return { ctx, config, adapter, runtime }
}

function mockTraceDocument(
  adapter: UpstreamAdapter,
  svg: string,
  reportedPathCount = 1,
  reportedBytes = Buffer.byteLength(svg),
): void {
  vi.spyOn(adapter, 'run').mockImplementationOnce(async (_tool, args) => {
    const outputIndex = args.indexOf('-o')
    const outputPath = outputIndex === -1 ? undefined : args[outputIndex + 1]
    if (outputPath === undefined) throw new Error('trace output path was not provided')
    await writeFile(outputPath, svg)
    return {
      stdout: `wrote ${outputPath} (${reportedBytes} bytes, ${reportedPathCount} paths, traced at 1x)\n`,
      stderr: '',
      stdoutTruncated: false,
      stderrTruncated: false,
      outcome: { exitCode: 0, signal: null },
    }
  })
}

const signal = new AbortController().signal

describe('VisionToolkitRuntime', () => {
  it('uses the bundled free proxy without resolving a user credential', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const resolve = vi.fn(async () => undefined)
    ctx.provide('credentials', { resolve } as unknown as Credentials)
    const config = resolveConfig({
      runtime: { mode: 'external', agentVisionToolkitPath: FIXTURE_UPSTREAM, python: 'python3' },
    })
    const adapter = new UpstreamAdapter(ctx, config, preparedFixture())
    const runtime = new VisionToolkitRuntime(ctx, config, adapter)

    await expect(runtime.resolveVisionEnv()).resolves.toMatchObject({
      VISION_API_KEY: 'https://agent-vision.anionex.me',
      VISION_BASE_URL: 'https://vision.anionex.me/v1',
      VISION_MODEL: 'gemini-3.7-flash',
      VISION_API_PROTOCOL: 'chat_completions',
    })
    expect(resolve).not.toHaveBeenCalled()
  })

  it('keeps the v0.1.10 Moondream default on the bundled free credential path', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const resolve = vi.fn(async () => undefined)
    ctx.provide('credentials', { resolve } as unknown as Credentials)
    const config = resolveConfig({
      provider: {
        baseUrl: 'https://vision.anionex.me/v1',
        credential: 'ANIONEX_FREE_VISION',
        model: 'moondream-3.1',
        protocol: 'openai',
      },
      runtime: { mode: 'external', agentVisionToolkitPath: FIXTURE_UPSTREAM, python: 'python3' },
    })
    const adapter = new UpstreamAdapter(ctx, config, preparedFixture())
    const runtime = new VisionToolkitRuntime(ctx, config, adapter)

    await expect(runtime.resolveVisionEnv()).resolves.toMatchObject({
      VISION_API_KEY: 'https://agent-vision.anionex.me',
      VISION_BASE_URL: 'https://vision.anionex.me/v1',
      VISION_MODEL: 'moondream-3.1',
      VISION_API_PROTOCOL: 'chat_completions',
    })
    expect(resolve).not.toHaveBeenCalled()
  })

  it('glance describes an image', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    const result = await runtime.glance({ images: ['sample.png'] }, { signal, workspace })
    expect(result).toMatchObject({ mode: 'describe', answer: 'Fixture detailed description', truncated: false })
    expect(result.images[0]).toMatchObject({ width: 256, height: 256, format: 'png' })
    expect(result.images[0]?.bytes).toBeGreaterThan(0)
  })

  it('pins one resolved credential to the evidence fingerprint and vision call', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    await ctx.plugin(LocalSubprocessService)
    let credential = 'first-vision-key'
    const resolve = vi.fn(async () => ({ value: credential, source: 'file' }))
    ctx.provide('credentials', { resolve } as unknown as Credentials)
    const config = resolveConfig({
      provider: {
        baseUrl: 'https://vision.example/v1',
        credential: 'VISION_API_KEY',
        model: 'fixture-model',
      },
      runtime: { mode: 'external', agentVisionToolkitPath: FIXTURE_UPSTREAM, python: 'python3' },
    })
    const adapter = new UpstreamAdapter(ctx, config, preparedFixture())
    const runtime = new VisionToolkitRuntime(ctx, config, adapter)
    const run = vi.spyOn(adapter, 'run')
    const workspace = await tempWorkspace()

    const captured = await runtime.captureEvidenceRuntime()
    credential = 'second-vision-key'
    await captured.glance({ images: ['sample.png'] }, { signal, workspace })

    expect(resolve).toHaveBeenCalledTimes(1)
    expect(run).toHaveBeenCalledWith(
      'glance',
      expect.any(Array),
      expect.objectContaining({
        env: expect.objectContaining({ VISION_API_KEY: 'first-vision-key' }),
      }),
    )
    const next = await runtime.captureEvidenceRuntime()
    expect(resolve).toHaveBeenCalledTimes(2)
    expect(next.evidenceFingerprint).not.toBe(captured.evidenceFingerprint)
  })

  it('sends bounded static headers and process-keyed session routing headers', async () => {
    const { adapter, runtime } = await setup({
      provider: {
        headers: { 'x-tenant': 'acme' },
        sessionHeaders: ['x-opencode-session'],
      },
    })
    const workspace = await tempWorkspace()
    const run = vi.spyOn(adapter, 'run')

    await runtime.glance({ images: ['sample.png'] }, { signal, workspace, sessionId: 'session-a' })
    await runtime.glance({ images: ['sample.png'] }, { signal, workspace, sessionId: 'session-a' })
    await runtime.glance({ images: ['sample.png'] }, { signal, workspace, sessionId: 'session-b' })
    await runtime.glance({ images: ['sample.png'] }, { signal, workspace })

    const headersAt = (index: number): Record<string, string> => JSON.parse(
      (run.mock.calls[index]?.[2].env?.DSH_VISION_EXTRA_HEADERS) ?? '{}',
    ) as Record<string, string>
    expect(headersAt(0)['x-tenant']).toBe('acme')
    expect(headersAt(0)['x-opencode-session']).toMatch(/^[0-9a-f]{32}$/u)
    expect(headersAt(1)['x-opencode-session']).toBe(headersAt(0)['x-opencode-session'])
    expect(headersAt(2)['x-opencode-session']).not.toBe(headersAt(0)['x-opencode-session'])
    expect(headersAt(3)['x-opencode-session']).toMatch(/^[0-9a-f]{32}$/u)
    expect(JSON.stringify(headersAt(3))).not.toContain(workspace)
  })

  it('rotates session routing identities when the process HMAC key changes', () => {
    const provider = resolveConfig({ provider: { sessionHeaders: ['x-route'] } }).provider
    const firstKey = Uint8Array.from({ length: 32 }, () => 1)
    const firstProcess = createVisionProviderHeaderResolver(firstKey)
    const secondProcess = createVisionProviderHeaderResolver(Uint8Array.from({ length: 32 }, () => 2))
    const expected = createHmac('sha256', firstKey).update('session-a').digest('hex').slice(0, 32)

    expect(firstProcess(provider, 'session-a')['x-route']).toBe(expected)
    expect(firstProcess(provider, 'session-a')['x-route']).toBe(firstProcess(provider, 'session-a')['x-route'])
    expect(secondProcess(provider, 'session-a')['x-route']).not.toBe(firstProcess(provider, 'session-a')['x-route'])
  })

  it('omits the provider-header environment payload when no headers are configured', async () => {
    const { adapter, runtime } = await setup()
    const workspace = await tempWorkspace()
    const run = vi.spyOn(adapter, 'run')

    await runtime.glance({ images: ['sample.png'] }, { signal, workspace })

    expect(run.mock.calls[0]?.[2].env?.DSH_VISION_EXTRA_HEADERS).toBeUndefined()
  })

  it('redacts every outbound provider header value from upstream failures', async () => {
    const headerValue = 'deployment-metadata-that-must-not-surface'
    const { adapter, runtime } = await setup({ provider: {
      headers: { 'x-tenant': headerValue },
      sessionHeaders: ['x-route'],
    } })
    vi.spyOn(adapter, 'run').mockImplementationOnce(async (_tool, _args, options) => {
      const routeValue = JSON.parse(options.env?.DSH_VISION_EXTRA_HEADERS ?? '{}')['x-route'] as string
      return {
        stdout: '',
        stderr: `provider rejected ${headerValue} for route ${routeValue}`,
        stdoutTruncated: false,
        stderrTruncated: false,
        outcome: { exitCode: 1, signal: null },
      }
    })
    const workspace = await tempWorkspace()

    const error = await runtime.glance({ images: ['sample.png'] }, { signal, workspace })
      .then(() => undefined, failure => failure as Error)
    expect(error).toBeInstanceOf(Error)
    expect(error?.message).not.toContain(headerValue)
    expect(error?.message).not.toMatch(/[0-9a-f]{32}/u)
  })

  it('glance answers a question, OCRs, and zooms into a region', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    const qa = await runtime.glance({ images: ['sample.png'], query: 'what color?' }, { signal, workspace })
    expect(qa).toMatchObject({ mode: 'qa', answer: 'Fixture answer to the question' })
    const ocr = await runtime.glance({ images: ['sample.png'], ocr: true }, { signal, workspace })
    expect(ocr).toMatchObject({ mode: 'ocr', answer: 'Fixture OCR text' })
    const region = await runtime.glance({ images: ['sample.png'], region: '10,10,30,30', query: 'x' }, { signal, workspace })
    expect(region.answer).toBe('Fixture answer to the question')
  })

  it('deduplicates the same resolved image inside one glance request', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    const result = await runtime.glance({ images: ['sample.png', './sample.png'] }, { signal, workspace })
    expect(result.images).toHaveLength(1)
    expect(result.answer).toBe('Fixture detailed description')
  })

  it('reuses the last identical glance result only inside the same live session', async () => {
    const { adapter, runtime } = await setup()
    const workspace = await tempWorkspace()
    const run = vi.spyOn(adapter, 'run')
    const firstSession = {}
    const options = { signal, workspace, sessionId: 'first', sessionScope: firstSession }

    const first = await runtime.glance({ images: ['sample.png'], query: 'what color?' }, options)
    const second = await runtime.glance({ images: ['./sample.png'], query: 'what color?' }, options)
    expect(second).toEqual(first)
    expect(run).toHaveBeenCalledTimes(1)

    await runtime.glance({ images: ['sample.png'], query: 'what shape?' }, options)
    expect(run).toHaveBeenCalledTimes(2)

    await runtime.glance(
      { images: ['sample.png'], query: 'what shape?' },
      { signal, workspace, sessionId: 'second', sessionScope: {} },
    )
    expect(run).toHaveBeenCalledTimes(3)
  })

  it('separates the live-Session glance cache by effective Responses reasoning effort', async () => {
    const { adapter, config, runtime } = await setup({
      provider: {
        baseUrl: 'https://vision.example/v1',
        credential: 'VISION_API_KEY',
        model: 'fixture-model',
        protocol: 'responses',
        reasoningEffort: 'low',
      },
    })
    const workspace = await tempWorkspace()
    const run = vi.spyOn(adapter, 'run')
    const options = { signal, workspace, sessionId: 'effort', sessionScope: {} }

    await runtime.glance({ images: ['sample.png'] }, options)
    config.provider.reasoningEffort = 'high'
    await runtime.glance({ images: ['sample.png'] }, options)

    expect(run).toHaveBeenCalledTimes(2)
    expect(run.mock.calls[0]?.[2]?.env).toMatchObject({ VISION_REASONING_EFFORT: 'low' })
    expect(run.mock.calls[1]?.[2]?.env).toMatchObject({ VISION_REASONING_EFFORT: 'high' })
  })

  it('does not cache a failed glance request', async () => {
    const { adapter, runtime } = await setup()
    const workspace = await tempWorkspace()
    const originalRun = adapter.run.bind(adapter)
    const run = vi.spyOn(adapter, 'run')
      .mockResolvedValueOnce({
        stdout: '',
        stderr: 'HTTP 429 fixture limit',
        stdoutTruncated: false,
        stderrTruncated: false,
        outcome: { exitCode: 1, signal: null },
      })
      .mockImplementation(originalRun)
    const options = { signal, workspace, sessionId: 'retry', sessionScope: {} }

    await expect(runtime.glance({ images: ['sample.png'] }, options)).rejects.toMatchObject({ code: 'service' })
    await expect(runtime.glance({ images: ['sample.png'] }, options)).resolves.toMatchObject({ answer: 'Fixture detailed description' })
    expect(run).toHaveBeenCalledTimes(2)
  })

  it('rejects truncated upstream output instead of exposing a partial model result', async () => {
    const { adapter, runtime } = await setup()
    const workspace = await tempWorkspace()
    vi.spyOn(adapter, 'run').mockResolvedValueOnce({
      stdout: 'partial response',
      stderr: '',
      stdoutTruncated: true,
      stderrTruncated: false,
      outcome: { exitCode: 0, signal: null },
    })

    await expect(runtime.glance({ images: ['sample.png'] }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'output' })
  })

  it('glance rejects region with multiple images and mutually exclusive modes', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    await expect(runtime.glance({ images: ['sample.png', 'sample.png'], region: '0,0,1,1' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'input' })
    await expect(runtime.glance({ images: ['sample.png'], query: 'x', ocr: true }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'input' })
  })

  it('ground returns normalized in-range pixel boxes with image size', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    const result = await runtime.ground({ image: 'sample.png', target: 'send button' }, { signal, workspace })
    expect(result).toEqual({
      target: 'send button',
      image: {
        path: expect.stringMatching(/sample\.png$/),
        originalPath: expect.stringMatching(/sample\.png$/),
        bytes: expect.any(Number),
        width: 256,
        height: 256,
        format: 'png',
      },
      imageWidth: 256,
      imageHeight: 256,
      matches: [{ label: 'send button', box: { x1: 100, y1: 50, x2: 200, y2: 90 } }],
    })
  })

  it('detect returns a numbered element inventory', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    const result = await runtime.detect({ image: 'sample.png', target: 'buttons' }, { signal, workspace })
    expect(result.category).toBe('buttons')
    expect(result.elements).toEqual([
      { index: 1, label: 'button', box: { x1: 10, y1: 20, x2: 60, y2: 40 } },
      { index: 2, label: 'input', box: { x1: 130, y1: 100, x2: 220, y2: 140 } },
    ])
  })

  it('rejects unknown and out-of-range location output', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    await expect(runtime.ground({ image: 'sample.png', target: 'unknown-output' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'output' })
    await expect(runtime.ground({ image: 'sample.png', target: 'out-of-range' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'output' })
  })

  it('crop writes an image file and reports dimensions without a credential', async () => {
    const { runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    const result = await runtime.crop({ image: 'sample.png', region: '10,20,50,40' }, { signal, workspace })
    expect(result.outputPath).toContain(join('.dsh-vision-toolkit', 'artifacts'))
    expect(result).toMatchObject({ mimeType: 'image/png', width: 40, height: 20, clamped: false })
  })

  it.skipIf(typeof process.geteuid !== 'function')('writes artifacts and compression cache below the configured shared storage root', async () => {
    const shared = await mkdtemp(join(tmpdir(), 'dsh-vision-toolkit-shared-'))
    tempDirs.push(shared)
    const { runtime } = await setup({ storageDir: shared, maxImageBytes: 1024 }, null)
    const workspace = await tempWorkspace()
    const canonicalWorkspace = await realpath(workspace)
    const storageRoot = join(await realpath(shared), workspaceStorageId(canonicalWorkspace))

    const result = await runtime.crop({ image: 'sample.png', region: '10,20,50,40' }, { signal, workspace })

    expect(result.outputPath).toContain(join(storageRoot, 'artifacts'))
    expect(await readdir(workspace)).toEqual(['sample.png'])
    expect((await readdir(join(storageRoot, 'tmp', 'compressed-images'))).length).toBeGreaterThan(0)
  })

  it.skipIf(typeof process.geteuid !== 'function')('reads a persisted image from a previously configured shared storage root', async () => {
    const previousShared = await outsideTempDir('previous-storage')
    const currentShared = await outsideTempDir('current-storage')
    const workspace = await tempWorkspace()
    const previousPolicy = await createPathPolicy(workspace, [], previousShared)
    const persisted = join(previousPolicy.storageRoot, 'persisted.png')
    await copyFile(SAMPLE_IMAGE, persisted)
    const { runtime } = await setup({ storageDir: currentShared }, 'test-vision-key', preparedFixture(), [previousShared])

    await expect(runtime.glance({ images: [persisted], query: 'what color?' }, { signal, workspace }))
      .resolves.toMatchObject({ answer: 'Fixture answer to the question' })
  })

  it('trace writes an SVG and returns pinned vtracer facts without a credential', async () => {
    const { runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    const result = await runtime.trace({ image: 'sample.png', scale: 2 }, { signal, workspace })
    expect(result.outputPath).toContain(join('.dsh-vision-toolkit', 'artifacts'))
    expect(result).toMatchObject({
      mimeType: 'image/svg+xml',
      imageWidth: 256,
      imageHeight: 256,
      geometry: { status: 'generated', pathCount: 1, tracedScale: 2 },
    })
    expect(result.geometry.bytes).toBeGreaterThan(0)
  })

  it('accepts declarations, comments, and namespace-prefixed SVG elements', async () => {
    const { adapter, runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    const svg = [
      '<?xml version="1.0" encoding="UTF-8"?>',
      '<!-- literal text such as <!DOCTYPE svg> is not a document type -->',
      '<s:svg xmlns:s="http://www.w3.org/2000/svg"><s:g><s:path d="M0 0"/></s:g></s:svg>',
      '',
    ].join('\n')
    mockTraceDocument(adapter, svg)

    const result = await runtime.trace({ image: 'sample.png' }, { signal, workspace })

    expect(result.geometry).toMatchObject({ status: 'generated', pathCount: 1 })
    await expect(readFile(result.outputPath, 'utf8')).resolves.toBe(svg)
  })

  it('rejects a trace character count when the generated SVG contains expanded CRLF bytes', async () => {
    const { adapter, runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    const svg = '<svg xmlns="http://www.w3.org/2000/svg">\r\n<path/>\r\n</svg>\r\n'
    mockTraceDocument(adapter, svg, 1, Buffer.byteLength(svg) - 3)

    await expect(runtime.trace({ image: 'sample.png' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'output', message: 'trace: reported byte count does not match the generated SVG' })
  })

  it.each([
    ['a doctype', '<!DOCTYPE svg><svg xmlns="http://www.w3.org/2000/svg"><path/></svg>\n'],
    ['malformed nesting', '<svg xmlns="http://www.w3.org/2000/svg"><path></svg>\n'],
    ['multiple roots', '<svg xmlns="http://www.w3.org/2000/svg"/><svg xmlns="http://www.w3.org/2000/svg"/>\n'],
    ['a non-SVG root', '<html xmlns="http://www.w3.org/2000/svg"><path/></html>\n'],
    ['the wrong namespace', '<svg xmlns="urn:not-svg"><path/></svg>\n'],
    ['trailing document text', '<svg xmlns="http://www.w3.org/2000/svg"><path/></svg>not-xml\n'],
  ] as const)('rejects trace SVG documents with %s before artifact commit', async (_label, svg) => {
    const { adapter, runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    mockTraceDocument(adapter, svg)

    await expect(runtime.trace({ image: 'sample.png' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'output', message: 'trace: output SVG is not a parseable document' })
    await expect(readFile(join(workspace, '.dsh-vision-toolkit', 'artifacts', 'sample.svg'), 'utf8'))
      .rejects.toMatchObject({ code: 'ENOENT' })
  })

  it.each([
    ['path count', 2, undefined, 'trace: reported path count does not match the generated SVG'],
    ['byte count', 1, 1, 'trace: reported byte count does not match the generated SVG'],
  ] as const)('rejects a mismatched trace %s before artifact commit', async (_label, pathCount, bytes, message) => {
    const { adapter, runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    const svg = '<svg xmlns="http://www.w3.org/2000/svg"><path/></svg>\n'
    mockTraceDocument(adapter, svg, pathCount, bytes)

    await expect(runtime.trace({ image: 'sample.png' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'output', message })
    await expect(readFile(join(workspace, '.dsh-vision-toolkit', 'artifacts', 'sample.svg'), 'utf8'))
      .rejects.toMatchObject({ code: 'ENOENT' })
  })

  it('auto-compresses oversized images and resizes pixel-over-limit images', async () => {
    const workspace = await tempWorkspace()
    const byteLimited = await setup({ maxImageBytes: 1024 })
    const byteResult = await byteLimited.runtime.glance({ images: ['sample.png'] }, { signal, workspace })
    const byteImage = byteResult.images[0]
    expect(byteImage?.bytes ?? 0).toBeLessThanOrEqual(1024)
    expect(byteImage?.path).toMatch(/compressed-images/u)
    expect(byteImage?.originalPath).toBe(await realpath(join(workspace, 'sample.png')))
    await expect(readFile(join(workspace, 'sample.png'))).resolves.toEqual(await readFile(SAMPLE_IMAGE))

    const pixelLimited = await setup({ maxImagePixels: 65_535 })
    const pixelResult = await pixelLimited.runtime.glance({ images: ['sample.png'] }, { signal, workspace })
    const pixelImage = pixelResult.images[0]
    expect((pixelImage?.width ?? 0) * (pixelImage?.height ?? 0)).toBeLessThanOrEqual(65_535)
    expect(pixelImage?.path).toMatch(/compressed-images/u)
    expect(pixelImage?.originalPath).toBe(await realpath(join(workspace, 'sample.png')))
  })

  it('reuses the durable compressed-image cache for identical inputs', async () => {
    const { adapter, runtime } = await setup({ maxImageBytes: 1024 })
    const workspace = await tempWorkspace()
    const compress = vi.spyOn(adapter, 'compressImage')
    const options = { signal, workspace }

    const first = await runtime.glance({ images: ['sample.png'] }, options)
    const second = await runtime.glance({ images: ['sample.png'] }, options)
    expect(second).toEqual(first)
    expect(compress).toHaveBeenCalledTimes(1)
    const entries = await readdir(join(workspace, '.dsh-vision-toolkit', 'tmp', 'compressed-images'))
    const cacheEntry = entries.find(entry => !entry.startsWith('.'))
    expect(cacheEntry).toBeDefined()
    expect(cacheEntry).toMatch(/^v2-[0-9a-f]{16}-b\d+-p\d+-[0-9a-f]{16}-\d+x\d+\.(?:jpg|png|webp)$/u)
    expect(cacheEntry?.length).toBeLessThan(120)
  })

  it('ignores and replaces tampered compressed-cache entries', async () => {
    const { runtime } = await setup({ maxImageBytes: 1024 })
    const workspace = await tempWorkspace()
    const options = { signal, workspace }
    await runtime.glance({ images: ['sample.png'] }, options)
    const cacheDir = join(workspace, '.dsh-vision-toolkit', 'tmp', 'compressed-images')
    const entries = (await readdir(cacheDir)).filter(name => !name.startsWith('.'))
    expect(entries).toHaveLength(1)
    const entry = entries[0]!
    await rm(join(cacheDir, entry))
    const decoy = join(workspace, 'decoy.png')
    await copyFile(SAMPLE_IMAGE, decoy)
    await symlink(decoy, join(cacheDir, entry))

    const result = await runtime.glance({ images: ['sample.png'] }, options)
    expect(result.images[0]?.path).toMatch(/compressed-images/u)
    const info = await lstat(join(cacheDir, entry))
    expect(info.isSymbolicLink()).toBe(false)
    expect(info.isFile()).toBe(true)
    expect(info.size).toBeLessThanOrEqual(1024)
  })

  it('prunes cache entries from older compression schemas', async () => {
    const { runtime } = await setup({ maxImageBytes: 1024 })
    const workspace = await tempWorkspace()
    const options = { signal, workspace }
    await runtime.glance({ images: ['sample.png'] }, options)
    const cacheDir = join(workspace, '.dsh-vision-toolkit', 'tmp', 'compressed-images')
    const v1Entry = `v1-${'a'.repeat(64)}-b1024-p1000000-${'b'.repeat(64)}-256x256.png`
    await writeFile(join(cacheDir, 'legacy-entry'), 'stale')
    await writeFile(join(cacheDir, v1Entry), 'stale')

    await runtime.glance({ images: ['sample.png'] }, options)
    const entries = (await readdir(cacheDir)).filter(name => !name.startsWith('.'))
    expect(entries).not.toContain('legacy-entry')
    expect(entries).not.toContain(v1Entry)
    expect(entries.length).toBeGreaterThan(0)
  })

  it('forwards the compressed copy to upstream and leaves the original file untouched', async () => {
    const { adapter, runtime } = await setup({ maxImageBytes: 1024 })
    const workspace = await tempWorkspace()
    const run = vi.spyOn(adapter, 'run')

    await runtime.glance({ images: ['sample.png'] }, { signal, workspace })
    const upstreamPath = run.mock.calls[0]?.[1]?.[0]
    expect(upstreamPath).toMatch(/compressed-images/u)
    await expect(readFile(join(workspace, 'sample.png'))).resolves.toEqual(await readFile(SAMPLE_IMAGE))
  })

  it('keeps a capacity error when auto-compression cannot reach the configured limit', async () => {
    const { adapter, runtime } = await setup({ maxImageBytes: 1024 })
    const workspace = await tempWorkspace()
    vi.spyOn(adapter, 'compressImage').mockRejectedValue(
      new VisionToolkitError('capacity', 'cannot compress image under 1024 bytes: test failure'),
    )

    await expect(runtime.glance({ images: ['sample.png'] }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'capacity', message: 'cannot compress image under 1024 bytes: test failure' })
  })

  it('rejects missing images, malformed regions, and extension/content mismatches', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    await copyFile(SAMPLE_IMAGE, join(workspace, 'disguised.jpg'))
    await expect(runtime.ground({ image: 'missing.png', target: 'x' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'input' })
    await expect(runtime.crop({ image: 'sample.png', region: '1,2,3' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'input' })
    await expect(runtime.glance({ images: ['disguised.jpg'] }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'input' })
  })

  it('refuses to overwrite the original image with a crop output after compression', async () => {
    const { runtime } = await setup({ maxImageBytes: 1024 })
    const workspace = await tempWorkspace()
    const artifactDir = join(workspace, '.dsh-vision-toolkit', 'artifacts')
    await mkdir(artifactDir, { recursive: true })
    await copyFile(SAMPLE_IMAGE, join(artifactDir, 'sample.png'))
    await expect(runtime.crop(
      { image: '.dsh-vision-toolkit/artifacts/sample.png', region: '0,0,10,10', output: 'sample.png' },
      { signal, workspace },
    )).rejects.toMatchObject({ code: 'input' })
    await expect(readFile(join(artifactDir, 'sample.png'))).resolves.toEqual(await readFile(SAMPLE_IMAGE))
  })

  it('distinguishes caller cancellation from a hard operation timeout', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    const aborted = new AbortController()
    aborted.abort()
    await expect(runtime.glance({ images: ['sample.png'] }, { signal: aborted.signal, workspace }))
      .rejects.toMatchObject({ code: 'cancelled' })
    await expect(runtime.glance(
      { images: ['sample.png'], query: '__sleep__' },
      { signal, workspace, timeoutMs: 1000 },
    )).rejects.toMatchObject({ code: 'timeout' })
  })

  it('records elapsed upstream time when the adapter rejects on abort', async () => {
    const { ctx, adapter, runtime } = await setup()
    const workspace = await tempWorkspace()
    const warn = vi.spyOn(ctx.logger, 'warn')
    vi.spyOn(adapter, 'probeImageSize').mockResolvedValue({ width: 256, height: 256, format: 'png', mode: 'RGBA' })
    vi.spyOn(adapter, 'run').mockImplementation(async (_tool, _args, options) => {
      await new Promise<void>((_resolve, reject) => {
        options.signal.addEventListener('abort', () => reject(new Error('aborted')), { once: true })
      })
      throw new Error('unreachable')
    })

    await expect(runtime.glance(
      { images: ['sample.png'] },
      { signal, workspace, timeoutMs: 1000 },
    )).rejects.toMatchObject({ code: 'timeout' })

    const diagnostic = warn.mock.calls.find(call => String(call[0]).startsWith('dsh-vision-toolkit tool='))
    expect(diagnostic?.[2]).toBe('timeout')
    expect(diagnostic?.[5]).toBeGreaterThan(0)
    expect(diagnostic?.[5]).toBeLessThanOrEqual(diagnostic?.[3])
  })

  it('requires a credential only for remote vision operations', async () => {
    const { runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    await expect(runtime.glance({ images: ['sample.png'] }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'config' })
    await expect(runtime.crop({ image: 'sample.png', region: '0,0,10,10' }, { signal, workspace }))
      .resolves.toMatchObject({ width: 40, height: 20 })
  })

  it('delivers labeled ground previews as managed image artifacts', async () => {
    const { runtime } = await setup()
    const workspace = await tempWorkspace()
    const result = await runtime.ground(
      { image: 'sample.png', target: 'send button', preview: true },
      { signal, workspace },
    )
    expect(result.preview).toMatchObject({
      mimeType: 'image/png',
      kind: 'image',
      sourceTool: 'vision_ground',
      previewIntent: 'image',
    })
    expect(result.preview?.path).toContain(join('.dsh-vision-toolkit', 'artifacts'))
    expect(result.preview?.bytes).toBeGreaterThan(0)
  })

  it('pixel-diffs two images and atomically delivers heatmap and report artifacts', async () => {
    const { runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    await copyFile(SAMPLE_IMAGE, join(workspace, 'rebuilt.png'))
    const result = await runtime.pixelDiff(
      { original: 'sample.png', rebuilt: 'rebuilt.png', grid: 4, top: 1 },
      { signal, workspace },
    )
    expect(result).toMatchObject({
      scaled: false,
      overallDifferencePct: 12.34,
      worstRegions: [{ index: 1, differencePct: 23.45 }],
      heatmap: { kind: 'image', mimeType: 'image/png', sourceTool: 'vision_pixel_diff' },
      report: { kind: 'json', mimeType: 'application/json', sourceTool: 'vision_pixel_diff' },
    })
    const report = JSON.parse(await readFile(result.report.path, 'utf8')) as { schemaVersion: number; grid: number }
    expect(report).toMatchObject({ schemaVersion: 1, grid: 4 })
  })

  it('splits long screenshots without credentials and OCRs/resumes with credentials', async () => {
    const noCredential = await setup({}, null)
    const workspace = await tempWorkspace()
    const split = await noCredential.runtime.longScreenshotOcr(
      { image: 'sample.png', splitOnly: true, runName: 'sample-split' },
      { signal, workspace },
    )
    expect(split).toMatchObject({ splitOnly: true, complete: false, chunkCount: 1 })
    expect(split.output).toBeUndefined()
    expect(split.audit).toBeUndefined()
    expect(split.manifest.kind).toBe('json')
    expect(split.chunks[0]?.image.kind).toBe('image')

    const withCredential = await setup()
    const first = await withCredential.runtime.longScreenshotOcr(
      { image: 'sample.png', runName: 'sample-ocr', jobs: 1 },
      { signal, workspace },
    )
    expect(first).toMatchObject({ splitOnly: false, complete: true, chunkCount: 1 })
    expect(first.output?.kind).toBe('markdown')
    expect(first.audit?.kind).toBe('markdown')
    expect(first.chunks[0]?.ocr?.kind).toBe('markdown')
    const resumed = await withCredential.runtime.longScreenshotOcr(
      { image: 'sample.png', runName: 'sample-ocr', jobs: 1, resume: true },
      { signal, workspace },
    )
    expect(resumed.runDirectory).toBe(first.runDirectory)
    expect(await readFile(resumed.output?.path ?? '', 'utf8')).toContain('Fixture merged OCR')
  })

  it('extracts transparent foregrounds from UTF-8 Chinese subprocess output', async () => {
    vi.stubEnv('PYTHONIOENCODING', 'cp936')
    vi.stubEnv('PYTHONUTF8', '0')
    const { ctx, runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    const spawn = vi.spyOn(ctx.subprocess, 'spawn')
    const result = await runtime.extractForeground(
      { image: 'sample.png', region: '0,0,128,128' },
      { signal, workspace },
    )
    expect(result).toMatchObject({
      box: { x1: 10, y1: 20, x2: 42, y2: 44 },
      foregroundPixels: 512,
      keptComponents: 1,
      totalComponents: 2,
      largestComponentPct: 88,
      artifact: { mimeType: 'image/png', kind: 'image', sourceTool: 'vision_extract_foreground' },
    })
    const extractSpawn = spawn.mock.calls.find(([spec]) => spec.argv.some(arg => arg.endsWith('extract_fg.py')))
    expect(extractSpawn?.[0].env).toMatchObject({ PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' })
  })

  it('parses palette extraction and candidate scoring into structure', async () => {
    const { runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    const palette = await runtime.dominantColors({ image: 'sample.png' }, { signal, workspace })
    expect(palette.analysis.mode).toBe('palette')
    if (palette.analysis.mode !== 'palette') throw new Error('expected palette mode')
    expect(palette.analysis.colors).toEqual(expect.arrayContaining([{ color: '#336699', sharePct: 42.1 }]))
    const candidates = await runtime.dominantColors(
      { image: 'sample.png', candidates: ['#336699', '#FFFFFF'] },
      { signal, workspace },
    )
    expect(candidates.analysis).toMatchObject({
      mode: 'candidates',
      winner: '#336699',
      matchedWithinTolerance: true,
    })
  })

  it('renders only authorized local HTML and delivers a PNG artifact', async () => {
    const { runtime } = await setup({}, null)
    const workspace = await tempWorkspace()
    await writeFile(join(workspace, 'page.html'), '<!doctype html><title>fixture</title>\n')
    const result = await runtime.htmlScreenshot(
      { source: 'page.html', width: 320, height: 180, scale: 2 },
      { signal, workspace },
    )
    expect(result).toMatchObject({
      viewport: { width: 320, height: 180, scale: 2 },
      width: 640,
      height: 360,
      artifact: { mimeType: 'image/png', kind: 'image', sourceTool: 'vision_html_screenshot' },
    })
    expect(result).not.toHaveProperty('pageHeight')
    await expect(runtime.htmlScreenshot({ source: 'https://example.com' }, { signal, workspace }))
      .rejects.toMatchObject({ code: 'input' })
  })

  it('captures a full HTML document and reports its CSS page height', async () => {
    const { adapter, runtime } = await setup()
    const workspace = await tempWorkspace()
    await writeFile(join(workspace, 'page.html'), '<!doctype html><title>fixture</title>\n')
    vi.spyOn(adapter, 'run').mockImplementationOnce(async (_tool, args) => {
      const outputIndex = args.indexOf('-o')
      const outputPath = outputIndex === -1 ? undefined : args[outputIndex + 1]
      if (outputPath === undefined) throw new Error('screenshot output path was not provided')
      expect(args).toContain('--full-page')
      expect(args).toContain('--max-pixels')
      await copyFile(SAMPLE_IMAGE, outputPath)
      return {
        stdout: `wrote ${outputPath} (256x256; pageHeight=256)\n`,
        stderr: '',
        stdoutTruncated: false,
        stderrTruncated: false,
        outcome: { exitCode: 0, signal: null },
      }
    })
    const result = await runtime.htmlScreenshot(
      { source: 'page.html', width: 256, height: 180, fullPage: true },
      { signal, workspace },
    )
    expect(result).toMatchObject({
      viewport: { width: 256, height: 180, scale: 1 },
      width: 256,
      height: 256,
      pageHeight: 256,
    })
  })

  it('reports health without network access and tests /models only when explicit', async () => {
    const server = createServer((request, response) => {
      expect(request.url).toBe('/v1/models')
      expect(request.headers.authorization).toBe('Bearer test-vision-key')
      expect(request.headers['user-agent']).toContain('Mozilla/5.0')
      response.writeHead(200, { 'content-type': 'application/json' })
      response.end('{"data":[]}')
    })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    try {
      const address = server.address()
      if (address === null || typeof address === 'string') throw new Error('missing fixture server address')
      const { runtime } = await setup({
        provider: {
          baseUrl: `http://127.0.0.1:${address.port}/v1`,
          credential: 'VISION_API_KEY',
          model: 'fixture-model',
        },
      })
      const workspace = await tempWorkspace()
      const passive = await runtime.health(false, { signal, workspace })
      expect(passive).toMatchObject({
        connectionTested: false,
        modelTested: false,
        checks: {
          chrome: { status: 'ok' },
          credential: { status: 'ok' },
          service: { status: 'not_tested' },
          model: { status: 'not_tested' },
        },
      })
      const active = await runtime.health(true, { signal, workspace })
      expect(active).toMatchObject({
        connectionTested: true,
        modelTested: false,
        checks: { service: { status: 'ok' }, model: { status: 'not_tested' } },
      })
      const model = await runtime.health(true, { signal, workspace }, true)
      expect(model).toMatchObject({
        connectionTested: true,
        modelTested: true,
        checks: { service: { status: 'ok' }, model: { status: 'ok' } },
      })
    } finally {
      await new Promise<void>((resolve, reject) => server.close(error => error === undefined ? resolve() : reject(error)))
    }
  })

  it('treats a 403 from GET /models as a warning instead of claiming the key was rejected', async () => {
    const server = createServer((_request, response) => {
      response.writeHead(403, { 'content-type': 'application/json' })
      response.end('{"error":{"message":"Forbidden","type":"permission_error","code":"restricted"}}')
    })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    try {
      const address = server.address()
      if (address === null || typeof address === 'string') throw new Error('missing fixture server address')
      const { runtime } = await setup({
        provider: {
          baseUrl: `http://127.0.0.1:${address.port}/v1`,
          credential: 'VISION_API_KEY',
          model: 'fixture-model',
        },
      })
      const workspace = await tempWorkspace()
      const result = await runtime.health(true, { signal, workspace })
      expect(result).toMatchObject({
        healthy: true,
        connectionTested: true,
        checks: {
          service: {
            status: 'warning',
            detail: expect.stringContaining('restricted GET /models (HTTP 403)'),
          },
        },
      })
    } finally {
      await new Promise<void>((resolve, reject) => server.close(error => error === undefined ? resolve() : reject(error)))
    }
  })

  it('checks output readiness without resolving session-relative allowed directories', async () => {
    const runtimeHome = await tempWorkspace()
    const { runtime } = await setup(
      { allowedDirs: ['session-relative-inputs'] },
      'test-vision-key',
      preparedFixture(runtimeHome),
    )

    const result = await runtime.health(false, { signal, workspace: runtimeHome })

    expect(result.checks.artifactDirectory).toEqual({
      status: 'ok',
      detail: `Artifact directory is writable: ${join(await realpath(runtimeHome), '.dsh-vision-toolkit', 'artifacts')}`,
    })
  })

  it('reports a real multimodal model-test failure without treating /models as success', async () => {
    const server = createServer((_request, response) => {
      response.writeHead(200, { 'content-type': 'application/json' })
      response.end('{"data":[]}')
    })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    try {
      const address = server.address()
      if (address === null || typeof address === 'string') throw new Error('missing fixture server address')
      const { adapter, runtime } = await setup({
        provider: {
          baseUrl: `http://127.0.0.1:${address.port}/v1`,
          credential: 'VISION_API_KEY',
          model: 'fixture-model',
        },
      })
      vi.spyOn(adapter, 'run').mockResolvedValueOnce({
        stdout: '',
        stderr: 'Vision API HTTP 503: no available accounts',
        stdoutTruncated: false,
        stderrTruncated: false,
        outcome: { exitCode: 1, signal: null },
      })
      const workspace = await tempWorkspace()
      const result = await runtime.health(true, { signal, workspace }, true)
      expect(result).toMatchObject({
        healthy: false,
        connectionTested: true,
        modelTested: true,
        checks: {
          service: { status: 'ok' },
          model: { status: 'error', detail: expect.stringContaining('no available accounts') },
        },
      })
    } finally {
      await new Promise<void>((resolve, reject) => server.close(error => error === undefined ? resolve() : reject(error)))
    }
  })

  it('uses Anthropic authentication for an explicit connection test', async () => {
    const server = createServer((request, response) => {
      expect(request.url).toBe('/v1/models')
      expect(request.headers.authorization).toBeUndefined()
      expect(request.headers['x-api-key']).toBe('test-vision-key')
      expect(request.headers['anthropic-version']).toBe('2023-06-01')
      expect(request.headers['user-agent']).toBe('fixture-agent/1.0')
      response.writeHead(200, { 'content-type': 'application/json' })
      response.end('{"data":[]}')
    })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    try {
      const address = server.address()
      if (address === null || typeof address === 'string') throw new Error('fixture server did not bind')
      const { runtime } = await setup({
        provider: {
          baseUrl: `http://127.0.0.1:${address.port}/v1`,
          credential: 'VISION_API_KEY',
          model: 'fixture-model',
          protocol: 'anthropic',
          userAgent: 'fixture-agent/1.0',
        },
      })
      const workspace = await tempWorkspace()
      await expect(runtime.health(true, { signal, workspace }))
        .resolves.toMatchObject({ connectionTested: true, checks: { service: { status: 'ok' } } })
    } finally {
      await new Promise<void>((resolve, reject) => server.close(error => error === undefined ? resolve() : reject(error)))
    }
  })

  it('uses one session route for both requests in a connection and model health operation', async () => {
    let connectionRoute: string | undefined
    const server = createServer((request, response) => {
      connectionRoute = request.headers['x-opencode-session']
      expect(request.headers['x-tenant']).toBe('acme')
      response.writeHead(200, { 'content-type': 'application/json' })
      response.end('{"data":[]}')
    })
    await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve))
    try {
      const address = server.address()
      if (address === null || typeof address === 'string') throw new Error('fixture server did not bind')
      const { adapter, runtime } = await setup({ provider: {
        baseUrl: `http://127.0.0.1:${address.port}/v1`,
        credential: 'VISION_API_KEY',
        model: 'fixture-model',
        headers: { 'x-tenant': 'acme' },
        sessionHeaders: ['x-opencode-session'],
      } })
      const run = vi.spyOn(adapter, 'run').mockResolvedValueOnce({
        stdout: 'fixture model ready',
        stderr: '',
        stdoutTruncated: false,
        stderrTruncated: false,
        outcome: { exitCode: 0, signal: null },
      })
      const workspace = await tempWorkspace()

      await expect(runtime.health(true, { signal, workspace, sessionId: 'health-session' }, true))
        .resolves.toMatchObject({ checks: { service: { status: 'ok' }, model: { status: 'ok' } } })
      const modelHeaders = JSON.parse(
        run.mock.calls[0]?.[2].env?.DSH_VISION_EXTRA_HEADERS ?? '{}',
      ) as Record<string, string>
      expect(connectionRoute).toMatch(/^[0-9a-f]{32}$/u)
      expect(modelHeaders['x-opencode-session']).toBe(connectionRoute)
      expect(modelHeaders['x-tenant']).toBe('acme')
    } finally {
      await new Promise<void>((resolve, reject) => server.close(error => error === undefined ? resolve() : reject(error)))
    }
  })
})

describe('createDeadline', () => {
  it('reports only timeout when the timer fires first', async () => {
    const controller = new AbortController()
    const deadline = createDeadline(controller.signal, 20)
    await new Promise(resolve => setTimeout(resolve, 40))
    controller.abort()
    expect(deadline.signal.aborted).toBe(true)
    expect(deadline.timedOut).toBe(true)
    expect(deadline.cancelled).toBe(false)
    deadline.cleanup()
  })

  it('reports only cancellation when the caller signal fires first', async () => {
    const controller = new AbortController()
    const deadline = createDeadline(controller.signal, 20)
    controller.abort()
    await new Promise(resolve => setTimeout(resolve, 40))
    expect(deadline.signal.aborted).toBe(true)
    expect(deadline.timedOut).toBe(false)
    expect(deadline.cancelled).toBe(true)
    deadline.cleanup()
  })
})

describe('Semaphore', () => {
  it('bounds concurrent acquisitions and transfers a slot without losing capacity', async () => {
    const semaphore = new Semaphore(1)
    await semaphore.acquire(new AbortController().signal)
    const second = semaphore.acquire(new AbortController().signal)
    let secondDone = false
    void second.then(() => { secondDone = true })
    await Promise.resolve()
    expect(secondDone).toBe(false)
    semaphore.release()
    await second
    expect(secondDone).toBe(true)
    expect(semaphore.idle).toBe(false)
    semaphore.release()
    expect(semaphore.idle).toBe(true)
  })

  it('rejects a queued waiter when its signal aborts', async () => {
    const semaphore = new Semaphore(1)
    await semaphore.acquire(new AbortController().signal)
    const controller = new AbortController()
    const waiting = semaphore.acquire(controller.signal)
    controller.abort()
    await expect(waiting).rejects.toMatchObject({ code: 'cancelled' })
    semaphore.release()
  })

  it('accounts for weighted callers without exceeding total capacity', async () => {
    const semaphore = new Semaphore(3)
    await semaphore.acquire(new AbortController().signal, 2)
    const second = semaphore.acquire(new AbortController().signal, 2)
    let settled = false
    void second.then(() => { settled = true })
    await Promise.resolve()
    expect(settled).toBe(false)
    semaphore.release(2)
    await second
    expect(settled).toBe(true)
    semaphore.release(2)
    expect(semaphore.idle).toBe(true)
  })
})

class TrackingAdapter extends UpstreamAdapter {
  active = 0
  delayMs = 40
  maxActive = 0

  override probeImageSize(): Promise<{ width: number; height: number; format: string }> {
    return Promise.resolve({ width: 256, height: 256, format: 'png' })
  }

  override async run(
    _tool: UpstreamTool,
    _args: readonly string[],
    _options: { signal: AbortSignal; env?: UpstreamEnvironment },
  ): Promise<UpstreamRunResult> {
    this.active += 1
    this.maxActive = Math.max(this.maxActive, this.active)
    try {
      await new Promise(resolve => setTimeout(resolve, this.delayMs))
      return {
        stdout: 'tracked\n',
        stderr: '',
        stdoutTruncated: false,
        stderrTruncated: false,
        outcome: { exitCode: 0, signal: null },
      }
    } finally {
      this.active -= 1
    }
  }
}

describe('session-scoped concurrency', () => {
  it('serializes one session while allowing independent sessions to overlap', async () => {
    const { ctx, config } = await setup({ concurrency: 1 })
    const adapter = new TrackingAdapter(ctx, config, preparedFixture())
    const runtime = new VisionToolkitRuntime(ctx, config, adapter)
    const workspace = await tempWorkspace()

    await Promise.all([
      runtime.glance({ images: ['sample.png'] }, { signal, workspace, sessionId: 'same' }),
      runtime.glance({ images: ['sample.png'] }, { signal, workspace, sessionId: 'same' }),
    ])
    expect(adapter.maxActive).toBe(1)

    adapter.maxActive = 0
    await Promise.all([
      runtime.glance({ images: ['sample.png'] }, { signal, workspace, sessionId: 'one' }),
      runtime.glance({ images: ['sample.png'] }, { signal, workspace, sessionId: 'two' }),
    ])
    expect(adapter.maxActive).toBe(2)
  })

  it('starts a fresh execution timeout after a queued operation acquires its slot', async () => {
    const { ctx, config } = await setup({ concurrency: 1 })
    const adapter = new TrackingAdapter(ctx, config, preparedFixture())
    adapter.delayMs = 650
    const runtime = new VisionToolkitRuntime(ctx, config, adapter)
    const workspace = await tempWorkspace()

    await expect(Promise.all([
      runtime.glance(
        { images: ['sample.png'] },
        { signal, workspace, sessionId: 'same', timeoutMs: 1000 },
      ),
      runtime.glance(
        { images: ['sample.png'] },
        { signal, workspace, sessionId: 'same', timeoutMs: 1000 },
      ),
    ])).resolves.toHaveLength(2)
  })

  it('reports queue timeout separately from the execution deadline', async () => {
    const { ctx, config } = await setup({ concurrency: 1 })
    const adapter = new TrackingAdapter(ctx, config, preparedFixture())
    adapter.delayMs = 1_200
    const runtime = new VisionToolkitRuntime(ctx, config, adapter)
    const workspace = await tempWorkspace()

    const first = runtime.glance(
      { images: ['sample.png'] },
      { signal, workspace, sessionId: 'same', timeoutMs: 2000 },
    )
    await vi.waitFor(() => expect(adapter.active).toBe(1))
    await expect(runtime.glance(
      { images: ['sample.png'] },
      { signal, workspace, sessionId: 'same', timeoutMs: 1000 },
    )).rejects.toMatchObject({
      code: 'timeout',
      message: 'vision_glance: timed out while waiting for a concurrency slot',
    })
    await expect(first).resolves.toMatchObject({ answer: 'tracked' })
  })
})

describe('upstream adapter version facts', () => {
  it('reports the prepared pinned snapshot identity', async () => {
    const { adapter } = await setup()
    expect(adapter.versionInfo).toMatchObject({
      path: FIXTURE_UPSTREAM,
      source: 'external',
      python: 'python3',
      dependencies: { pillow: 'fixture' },
    })
    expect(await adapter.readCheckoutVersion()).toBe(UPSTREAM_VERSION)
  })

  it('forces UTF-8 for direct tools, image probes, and Python helpers', async () => {
    const { ctx, adapter } = await setup({}, null)
    const workspace = await tempWorkspace()
    const spawn = vi.spyOn(ctx.subprocess, 'spawn')

    await adapter.run('crop', [SAMPLE_IMAGE, '--region', '0,0,2,2', '-o', join(workspace, 'crop.png')], { signal })
    await adapter.probeImageSize(SAMPLE_IMAGE, { signal })
    await adapter.renderAnnotatedPreview(SAMPLE_IMAGE, join(workspace, 'preview.png'), [], { signal })

    expect(spawn).toHaveBeenCalledTimes(3)
    for (const [spec] of spawn.mock.calls) {
      expect(spec.env).toMatchObject({ PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' })
    }
  })

  it('forwards the resolved Anthropic protocol to remote upstream tools', async () => {
    const { ctx, adapter, runtime } = await setup({
      provider: {
        baseUrl: 'https://vision.example/v1',
        credential: 'VISION_API_KEY',
        model: 'fixture-model',
        protocol: 'anthropic',
      },
    })
    const spawn = vi.spyOn(ctx.subprocess, 'spawn')

    await adapter.run('glance', [SAMPLE_IMAGE], { signal, env: await runtime.resolveVisionEnv() })

    expect(spawn).toHaveBeenCalledOnce()
    expect(spawn.mock.calls[0]?.[0].env).toMatchObject({
      VISION_API_PROTOCOL: 'anthropic',
      VISION_ANTHROPIC_THINKING: 'omit',
      VISION_API_KEY: 'test-vision-key',
      VISION_USER_AGENT: expect.stringContaining('Mozilla/5.0'),
    })
  })

  it('runs the vendored Responses transport through the TS subprocess boundary with optional effort', async () => {
    const requests: Array<{ url: string; body: Record<string, unknown> }> = []
    const server = createServer((request, response) => {
      const chunks: Buffer[] = []
      request.on('data', chunk => { chunks.push(Buffer.from(chunk)) })
      request.on('end', () => {
        requests.push({
          url: request.url ?? '',
          body: JSON.parse(Buffer.concat(chunks).toString('utf8')) as Record<string, unknown>,
        })
        response.writeHead(200, { 'Content-Type': 'application/json' })
        response.end(JSON.stringify({
          output: [{ type: 'message', content: [{ type: 'output_text', text: 'responses fixture answer' }] }],
        }))
      })
    })
    await new Promise<void>((resolve, reject) => {
      server.once('error', reject)
      server.listen(0, '127.0.0.1', resolve)
    })
    try {
      const address = server.address()
      if (address === null || typeof address === 'string') throw new Error('fixture server has no TCP address')
      const { ctx, config, runtime } = await setup({
        provider: {
          baseUrl: `http://127.0.0.1:${address.port}/v1`,
          credential: 'VISION_API_KEY',
          model: 'responses-model',
          protocol: 'responses',
          reasoningEffort: 'medium',
        },
      })
      const cleanHome = await tempWorkspace()
      const adapter = new UpstreamAdapter(ctx, config, preparedVendored(cleanHome))

      const withEffort = await adapter.run('glance', [SAMPLE_IMAGE, '-q', 'describe fixture'], {
        signal,
        env: await runtime.resolveVisionEnv(),
      })
      delete config.provider.reasoningEffort
      const withoutEffort = await adapter.run('glance', [SAMPLE_IMAGE, '-q', 'describe fixture'], {
        signal,
        env: await runtime.resolveVisionEnv(),
      })

      expect(withEffort.stdout.trim()).toBe('responses fixture answer')
      expect(withoutEffort.stdout.trim()).toBe('responses fixture answer')
      expect(requests).toHaveLength(2)
      expect(requests[0]?.url).toBe('/v1/responses')
      expect(requests[0]?.body).toMatchObject({
        model: 'responses-model',
        store: false,
        reasoning: { effort: 'medium' },
        input: [{ role: 'user', content: expect.arrayContaining([
          expect.objectContaining({ type: 'input_image' }),
          expect.objectContaining({ type: 'input_text' }),
        ]) }],
      })
      expect(requests[1]?.body).not.toHaveProperty('reasoning')
    } finally {
      await new Promise<void>((resolve, reject) => {
        server.close(error => { if (error === undefined) resolve(); else reject(error) })
      })
    }
  })

  it('forwards VISION_SSL_VERIFY to the isolated upstream process', async () => {
    vi.stubEnv('VISION_SSL_VERIFY', 'off')
    const { ctx, adapter, runtime } = await setup()
    const spawn = vi.spyOn(ctx.subprocess, 'spawn')

    const env = await runtime.resolveVisionEnv()
    expect(env.VISION_SSL_VERIFY).toBe('off')
    await adapter.run('glance', [SAMPLE_IMAGE], { signal, env })

    expect(spawn).toHaveBeenCalledOnce()
    expect(spawn.mock.calls[0]?.[0].env).toMatchObject({ VISION_SSL_VERIFY: 'off' })
  })

  it('fails prepare with a clear runtime error when the external path is missing', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    await ctx.plugin(LocalSubprocessService)
    const config = resolveConfig({
      provider: { baseUrl: 'https://vision.example/v1', credential: 'K', model: 'm' },
      runtime: { mode: 'external', agentVisionToolkitPath: '/nonexistent/toolkit' },
    })
    const adapter = new UpstreamAdapter(ctx, config)
    await expect(adapter.prepare()).rejects.toBeInstanceOf(VisionToolkitError)
  })
})
