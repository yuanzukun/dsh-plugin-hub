import { readFile, stat } from 'node:fs/promises'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'

const ROOT = dirname(fileURLToPath(new URL('../package.json', import.meta.url)))
const PACKAGE = JSON.parse(await readFile(join(ROOT, 'package.json'), 'utf8')) as {
  name: string
  main: string
  types: string
  exports: Record<string, unknown>
  files: string[]
  scripts: Record<string, string>
  engines?: { node?: string }
  dsh?: {
    bundle?: { patch?: string }
    client?: { platform?: string; inject?: string[] }
    visionToolkit?: { upstreamSkillCommit?: string }
    compatibility?: {
      dsh?: string
      dshReleases?: Record<string, 'compatible' | 'incompatible' | 'unknown'>
      profiles?: string[]
    }
  }
  dependencies?: Record<string, string>
  peerDependencies?: Record<string, string>
  peerDependenciesMeta?: Record<string, { optional?: boolean }>
  devDependencies?: Record<string, string>
}

describe('package layout contract', () => {
  it('is a bundle with a declared patch', async () => {
    expect(PACKAGE.dsh?.bundle?.patch).toBe('./cordis.patch.yml')
    await expect(stat(join(ROOT, 'cordis.patch.yml'))).resolves.toBeDefined()
  })

  it('points main/types/exports at built artifacts', async () => {
    expect(PACKAGE.main).toBe('lib/index.js')
    expect(PACKAGE.types).toBe('lib/types/index.d.ts')
    const entry = PACKAGE.exports['.'] as { types?: string; default?: string }
    expect(entry.types).toBe('./lib/types/index.d.ts')
    expect(entry.default).toBe('./lib/index.js')
    await expect(stat(join(ROOT, 'lib', 'index.js'))).resolves.toBeDefined()
    await expect(stat(join(ROOT, 'lib', 'types', 'index.d.ts'))).resolves.toBeDefined()
    await expect(stat(join(ROOT, 'lib', 'exposure.js'))).resolves.toBeDefined()
    await expect(stat(join(ROOT, 'lib', 'types', 'exposure.d.ts'))).resolves.toBeDefined()
    const client = PACKAGE.exports['./client'] as { types?: string; default?: string }
    expect(client.types).toBe('./lib/types/client/index.d.ts')
    expect(client.default).toBe('./lib/client.js')
    await expect(stat(join(ROOT, 'lib', 'client.js'))).resolves.toBeDefined()
    await expect(stat(join(ROOT, 'lib', 'types', 'client', 'index.d.ts'))).resolves.toBeDefined()
  })

  it('declares a loader-compatible Web client and its slot dependencies', () => {
    expect(PACKAGE.dsh?.client?.platform).toBe('web')
    // One row per real client dependency of this bundle: the services the
    // client's `inject` array requires, the package that declares each slot it
    // registers into, and the remaining type-contract packages.
    expect(PACKAGE.dsh?.client?.inject).toEqual(expect.arrayContaining([
      '@deepseek-ai/dsh-client-ui-renderer',
      '@deepseek-ai/dsh-client-locale',
      '@deepseek-ai/dsh-api-gateway',
      '@deepseek-ai/dsh-client-ui-conversation',
      '@deepseek-ai/dsh-api-session-controller',
      '@deepseek-ai/dsh-client-ui-settings-general',
      '@deepseek-ai/dsh-client-ui-tool',
      '@deepseek-ai/dsh-api-remotes',
      '@deepseek-ai/dsh-client-ui-input-trigger',
    ]))
    // Every runtime `require()` in lib/client.js is a platform seed word, so the
    // bundle declares no non-baseline module request.
    expect(PACKAGE.dsh?.client?.external).toBeUndefined()
    // `@deepseek-ai/dsh-client-runtime` stopped publishing at 0.1.1-rc.2. It must
    // not come back into either the install-time or the client metadata.
    expect(PACKAGE.peerDependencies).not.toHaveProperty('@deepseek-ai/dsh-client-runtime')
    expect(PACKAGE.dsh?.client?.inject).not.toContain('@deepseek-ai/dsh-client-runtime')
  })

  it('declares the exact DSH release window and runtime compatibility contract', () => {
    expect(PACKAGE.engines?.node).toBe('^22.19.0 || >=24.0.0')
    expect(PACKAGE.dsh?.compatibility?.dsh).toBe('>=0.1.0-rc.8 <0.2.0 || 0.2.0-rc.2 || 0.2.1-rc.2 || 0.2.1-rc.3 || 0.2.1-rc.5')
    expect(PACKAGE.dsh?.compatibility?.dshReleases?.['0.2.1-rc.2']).toBe('compatible')
    expect(PACKAGE.dsh?.compatibility?.dshReleases?.['0.2.1-rc.5']).toBe('compatible')
    expect(PACKAGE.dsh?.compatibility?.dshReleases).not.toHaveProperty('0.2.1-rc.4')
    expect(PACKAGE.dsh?.compatibility?.profiles).toEqual(['web', 'headless'])
    // DSH STORE reads the official latest-three window per release and needs at
    // least one exact `compatible` verdict; a range alone is not installable evidence.
    expect(PACKAGE.dsh?.compatibility?.dshReleases?.['0.1.3-alpha.1']).toBe('unknown')
    expect(PACKAGE.dsh?.compatibility?.dshReleases?.['0.1.3-alpha.2']).toBe('compatible')
    expect(PACKAGE.dsh?.compatibility?.dshReleases?.['0.1.5-rc.1']).toBe('compatible')
    // Historical verdicts stay recorded even after they leave the window.
    expect(PACKAGE.dsh?.compatibility?.dshReleases?.['0.1.2-rc.1']).toBe('compatible')
    const window = ['0.1.5-alpha.1', '0.1.5-alpha.2', '0.1.5-rc.1']
    expect(window.filter(release => PACKAGE.dsh?.compatibility?.dshReleases?.[release] === 'compatible')).not.toHaveLength(0)
  })

  it('ships runtime, pinned upstream, adapted Skill resources, lib, src, patch, and docs in files', async () => {
    for (const required of ['lib', 'src', 'runtime', 'vendor', 'assets', 'patches', 'cordis.patch.yml', 'README.md', 'README.zh.md', 'LICENSE']) {
      expect(PACKAGE.files).toContain(required)
    }
    expect(PACKAGE.dsh?.visionToolkit?.upstreamSkillCommit).toMatch(/^[0-9a-f]{40}$/u)
    await expect(stat(join(ROOT, 'assets', 'skill', 'SKILL.md'))).resolves.toBeDefined()
    await expect(stat(join(ROOT, 'assets', 'skill', 'UPSTREAM.json'))).resolves.toBeDefined()
    await expect(stat(join(ROOT, 'assets', 'skill', 'references', 'restore-ui.md'))).resolves.toBeDefined()
  })

  it('has reproducible build and prepack scripts', () => {
    expect(PACKAGE.scripts.build).toContain('node scripts/python-bootstrap.mjs')
    expect(PACKAGE.scripts.build).toContain('node scripts/upstream-manifest.mjs')
    expect(PACKAGE.scripts.build).toContain('node scripts/verify-skill.mjs')
    expect(PACKAGE.scripts.build).toContain('node scripts/clean-build.mjs')
    expect(PACKAGE.scripts.build).toContain('tsc -p tsconfig.json')
    expect(PACKAGE.scripts.build).toContain('tsc -p tsconfig.client.json')
    expect(PACKAGE.scripts.build).toContain('tsc -p tsconfig.client.public.json')
    expect(PACKAGE.scripts.build).toContain('node scripts/build-client.mjs')
    expect(PACKAGE.scripts['verify:portable']).toContain('node scripts/python-bootstrap.mjs')
    expect(PACKAGE.scripts['upstream:sync']).toBe('node scripts/sync-upstream.mjs')
    expect(PACKAGE.scripts['upstream:skill:sync']).toBe('node scripts/sync-skill.mjs')
    expect(PACKAGE.scripts['upstream:skill:verify']).toBe('node scripts/verify-skill.mjs')
    expect(PACKAGE.scripts['upstream:manifest']).toContain('--write')
    expect(PACKAGE.scripts.prepack).toBe('npm run build')
    expect(PACKAGE.scripts.test).toContain('vitest')
  })

  it('pins the dependency install scripts allowed in standalone CI', async () => {
    const workspace = await readFile(join(ROOT, 'pnpm-workspace.yaml'), 'utf8')
    expect(workspace).toContain("'@deepseek-ai/dsh-subprocess-local@0.1.5-rc.1': true")
    expect(workspace).toContain("'koffi@3.2.1': true")
    expect(workspace).toContain("'node-pty@1.2.0-beta.15': true")
    expect(workspace).not.toMatch(/^\s{2}(?:'@deepseek-ai\/dsh-subprocess-local'|node-pty):/mu)
  })

  it('keeps every dependency specifier portable', () => {
    expect(PACKAGE.peerDependencies).toHaveProperty('@deepseek-ai/dsh-agent')
    expect(PACKAGE.peerDependencies).toHaveProperty('@deepseek-ai/cordis')
    expect(PACKAGE.peerDependencies).toHaveProperty('@deepseek-ai/schemastery')
    expect(PACKAGE.peerDependencies).toHaveProperty('@deepseek-ai/dsh-storage-domain')
    expect(PACKAGE.dependencies).toHaveProperty('zod')
    expect(PACKAGE.peerDependencies).not.toHaveProperty('cordis')
    expect(PACKAGE.peerDependencies).not.toHaveProperty('schemastery')
    for (const section of [PACKAGE.dependencies ?? {}, PACKAGE.peerDependencies ?? {}, PACKAGE.devDependencies ?? {}]) {
      for (const [name, spec] of Object.entries(section)) {
        expect(spec, `${name}`).not.toMatch(/^\/|^[A-Za-z]:\\|^file:|^link:|^workspace:/)
      }
    }
  })

  it('targets the published DSH prerelease line without retired package names', () => {
    const peers = PACKAGE.peerDependencies ?? {}
    // One union line per declared DSH release line. A prerelease comparator
    // matches only its own major.minor.patch tuple, so a single range cannot
    // cover 0.1.0-rc.*, 0.1.1-rc.*, 0.1.2-*, and 0.1.5-rc.* at once; without the
    // union a user on 0.1.5-rc.1 has an unsatisfied peer and `pnpm` (which
    // auto-installs peers by default) silently materializes a stale older copy
    // next to the real host.
    for (const [name, spec] of Object.entries(peers)) {
      if (name.startsWith('@deepseek-ai/dsh-')) {
        expect(spec, name).toBe('>=0.1.0-rc.8 <0.2.0 || ^0.1.1-rc.1 || ^0.1.2-alpha.1 || ^0.1.5-rc.1 || 0.2.0-rc.2 || 0.2.1-rc.2 || 0.2.1-rc.3 || 0.2.1-rc.5')
      }
    }
    expect(peers).toHaveProperty('@deepseek-ai/dsh-client-ui-input-trigger')
    expect(peers).not.toHaveProperty('@deepseek-ai/dsh-client-ui-slash')
    expect(peers).not.toHaveProperty('@deepseek-ai/dsh-host-apiproxy')
    expect(PACKAGE.peerDependenciesMeta?.['@deepseek-ai/dsh-host-webserver']?.optional).toBe(true)
    expect(PACKAGE.dsh?.client?.inject).not.toContain('@deepseek-ai/dsh-client-ui-slash')
    // Retired package: last published at 0.1.1-rc.2 and absent from the whole
    // 0.1.5 family. The client's `ToolCallBlock` import now names
    // `@deepseek-ai/dsh-client-ui-conversation/client` instead.
    expect(peers).not.toHaveProperty('@deepseek-ai/dsh-client-runtime')
    expect(PACKAGE.dsh?.client?.inject).not.toContain('@deepseek-ai/dsh-client-runtime')
  })

  it('emits no raw .ts relative imports in built JavaScript', async () => {
    const text = await readFile(join(ROOT, 'lib', 'index.js'), 'utf8')
    expect(text).not.toMatch(/from '\.\/[^']+\.ts'/)
    const config = await readFile(join(ROOT, 'lib', 'config.js'), 'utf8')
    expect(config).toContain("from '@deepseek-ai/schemastery'")
    expect(config).not.toContain("from 'schemastery'")
    expect(config).toContain('anthropicThinking')
    expect(config).toContain('reasoningEffort')
    expect(config).toContain('userAgent')
    const client = await readFile(join(ROOT, 'lib', 'client.js'), 'utf8')
    expect(client).toContain('window.__ModuleLoader__.load({ id: "@anionex/dsh-vision-toolkit"')
    expect(client).toContain('anthropicThinking')
    expect(client).toContain('reasoningEffort')
    expect(client).toContain('userAgent')
    expect(client).not.toMatch(/require\("\.\//)
    const runtime = await readFile(join(ROOT, 'lib', 'runtime.js'), 'utf8')
    expect(runtime).toContain('anthropic-version')
    expect(runtime).toContain('x-api-key')
    const upstream = await readFile(join(ROOT, 'lib', 'upstream.js'), 'utf8')
    expect(upstream).toContain('VISION_API_PROTOCOL')
    expect(upstream).toContain('VISION_ANTHROPIC_THINKING')
    expect(upstream).toContain('VISION_REASONING_EFFORT')
    expect(upstream).toContain('VISION_USER_AGENT')
  })

  it('indexes each client source map section at the generated module source line', async () => {
    const client = await readFile(join(ROOT, 'lib', 'client.js'), 'utf8')
    const indexedMap = JSON.parse(await readFile(join(ROOT, 'lib', 'client.js.map'), 'utf8')) as {
      sections: Array<{
        offset: { line: number; column: number }
        map: { sources: string[] }
      }>
    }
    const outputLines = client.split(/\r?\n/u)
    expect(indexedMap.sections.length).toBeGreaterThan(1)
    for (const section of indexedMap.sections) {
      const source = section.map.sources[0]
      if (source === undefined) throw new Error('client source map section has no source')
      await expect(stat(resolve(ROOT, 'lib', source)), source).resolves.toBeDefined()
      const leaf = source.slice(source.lastIndexOf('/') + 1).replace(/\.[^.]+$/u, '.js')
      const wrapper = `__modules["./${leaf}"] = function(module, exports, require, __load_) {`
      const wrapperLine = outputLines.indexOf(wrapper)
      expect(wrapperLine, source).toBeGreaterThanOrEqual(0)
      expect(section.offset).toEqual({ line: wrapperLine + 1, column: 0 })
    }
  })
})
