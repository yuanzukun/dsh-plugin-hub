import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { Context } from '@deepseek-ai/cordis'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { ResolvedVisionToolkitConfig } from '../src/config.ts'
import type { VisionToolkitRuntime } from '../src/runtime.ts'
import { VisionToolkitRuntimeManager, type RuntimeGenerationFactory } from '../src/runtime-manager.ts'

const contexts: Context[] = []
const tempDirs: string[] = []

async function tempDir(prefix: string): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), `dsh-vision-toolkit-${prefix}-`))
  tempDirs.push(dir)
  return dir
}

afterEach(async () => {
  await Promise.all(contexts.splice(0).map(ctx => ctx.fiber.dispose()))
  await Promise.all(tempDirs.splice(0).map(dir => rm(dir, { recursive: true, force: true })))
})

function fakeRuntime(config: ResolvedVisionToolkitConfig): VisionToolkitRuntime {
  return {
    upstreamVersion: {
      repository: 'https://github.com/Anionex/agent-vision-toolkit',
      version: 'fixture',
      commit: 'c27d1a300962b553c0884993c575cd3e819465ce',
      path: `/fixture/${config.provider.model}`,
      source: config.runtime.mode,
      runtimeHome: '/fixture/runtime',
      python: 'python3',
      pythonVersion: '3.12.0',
      dependencies: {},
    },
  } as unknown as VisionToolkitRuntime
}

function config(model: string) {
  return {
    provider: { baseUrl: 'https://vision.example/v1', credential: 'VISION_API_KEY', model },
    runtime: { mode: 'managed' as const },
  }
}

describe('VisionToolkitRuntimeManager', () => {
  it('waits for background preparation, isolates caller cancellation, and follows replacement Settings', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const signals: AbortSignal[] = []
    let finish!: () => void
    const manager = new VisionToolkitRuntimeManager(ctx, async (_ctx, resolved, _dirs, signal) => {
      signals.push(signal!)
      if (resolved.provider.model === 'slow') {
        await new Promise<void>((resolve, reject) => {
          finish = resolve
          signal!.addEventListener('abort', () => reject(signal!.reason), { once: true })
        })
      }
      return fakeRuntime(resolved)
    })
    const startup = manager.start(config('slow'))
    expect(manager.ready).toBe(false)
    const caller = new AbortController()
    const cancelled = manager.whenReady(caller.signal)
    caller.abort(new Error('caller stopped'))
    await expect(cancelled).rejects.toThrow('caller stopped')
    expect(signals[0]!.aborted).toBe(false)
    const waiting = manager.whenReady()
    await manager.reconfigure(config('replacement'))
    await expect(startup).rejects.toThrow()
    expect(signals[0]!.aborted).toBe(true)
    expect(await waiting).toBe(manager.current())
    expect(manager.currentConfig().provider.model).toBe('replacement')
    finish()
    manager.dispose()
    await expect(manager.whenReady()).rejects.toThrow()
  })

  it('cancels background work on unload and prevents late publication', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    let finish!: () => void
    let preparationSignal!: AbortSignal
    const manager = new VisionToolkitRuntimeManager(ctx, async (_ctx, resolved, _dirs, signal) => {
      preparationSignal = signal!
      await new Promise<void>(resolve => { finish = resolve })
      return fakeRuntime(resolved)
    })
    const startup = manager.start(config('slow'))
    const waiting = manager.whenReady()
    manager.dispose()
    await expect(waiting).rejects.toThrow()
    expect(preparationSignal.aborted).toBe(true)
    finish()
    await expect(startup).rejects.toThrow()
    expect(manager.ready).toBe(false)
  })

  it('reports startup failure and permits Settings to repair the first generation', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const manager = new VisionToolkitRuntimeManager(ctx, async (_ctx, resolved) => {
      if (resolved.provider.model === 'broken') throw new Error('preparation failed')
      return fakeRuntime(resolved)
    })
    await expect(manager.start(config('broken'))).rejects.toThrow('preparation failed')
    await expect(manager.whenReady()).rejects.toThrow('preparation failed')
    await manager.reconfigure(config('repaired'))
    expect(await manager.whenReady()).toBe(manager.current())
    expect(manager.status().lastError).toBeUndefined()
  })

  it('prepares before publishing and retains the serving generation after failure', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const prepared: string[] = []
    const factory: RuntimeGenerationFactory = async (_ctx, resolved) => {
      prepared.push(resolved.provider.model)
      if (resolved.provider.model === 'broken') throw new Error('fixture runtime unavailable')
      return fakeRuntime(resolved)
    }
    const manager = new VisionToolkitRuntimeManager(ctx, factory)
    await manager.initialize(config('first'))
    const first = manager.current()

    await expect(manager.reconfigure(config('broken'))).rejects.toThrow('fixture runtime unavailable')
    expect(manager.current()).toBe(first)
    expect(manager.status()).toMatchObject({ ready: true, generation: 1, lastError: 'fixture runtime unavailable' })
    expect(prepared).toEqual(['first', 'broken'])
  })

  it('runs durable commit prerequisites after preparation and before publication', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const sequence: string[] = []
    const factory: RuntimeGenerationFactory = async (_ctx, resolved) => {
      sequence.push(`prepare:${resolved.provider.model}`)
      return fakeRuntime(resolved)
    }
    const manager = new VisionToolkitRuntimeManager(ctx, factory)
    await manager.initialize(config('first'))

    await expect(manager.reconfigure(config('second'), async (candidate) => {
      sequence.push(`persist:${candidate.config.provider.model}`)
      throw new Error('storage history unavailable')
    })).rejects.toThrow('storage history unavailable')

    expect(sequence).toEqual(['prepare:first', 'prepare:second', 'persist:second'])
    expect(manager.currentConfig().provider.model).toBe('first')
    expect(manager.status()).toMatchObject({
      ready: true,
      generation: 1,
      lastError: 'storage history unavailable',
    })
  })

  it.skipIf(typeof process.geteuid !== 'function')('keeps consumers on the active configuration while a candidate fails', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const activeStorage = await tempDir('active-storage')
    const rejectedStorage = await tempDir('rejected-storage')
    const factory: RuntimeGenerationFactory = async (_ctx, resolved) => {
      if (resolved.storageDir === rejectedStorage) throw new Error('fixture runtime unavailable')
      return fakeRuntime(resolved)
    }
    const manager = new VisionToolkitRuntimeManager(ctx, factory)
    await manager.initialize({ ...config('first'), storageDir: activeStorage })

    await expect(manager.reconfigure({ ...config('first'), storageDir: rejectedStorage }))
      .rejects.toThrow('fixture runtime unavailable')

    expect(manager.currentConfig().storageDir).toBe(activeStorage)
  })

  it('rejects an unusable shared storage root before preparing or replacing the runtime', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const factory = vi.fn(async (_ctx: Context, resolved: ResolvedVisionToolkitConfig) => fakeRuntime(resolved))
    const manager = new VisionToolkitRuntimeManager(ctx, factory)
    await manager.initialize(config('first'))
    const first = manager.current()
    const parent = await tempDir('invalid-storage')
    const file = join(parent, 'not-a-directory')
    await writeFile(file, 'fixture')

    await expect(manager.reconfigure({ ...config('second'), storageDir: file }))
      .rejects.toThrow(/configured storage directory/u)

    expect(factory).toHaveBeenCalledTimes(1)
    expect(manager.current()).toBe(first)
    expect(manager.status()).toMatchObject({ ready: true, generation: 1 })
  })

  it.skipIf(typeof process.geteuid !== 'function')('keeps validated startup storage available when initial runtime preparation fails', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const shared = await tempDir('startup-storage')
    const manager = new VisionToolkitRuntimeManager(ctx, async () => {
      throw new Error('fixture runtime unavailable')
    })

    await expect(manager.initialize({ ...config('broken'), storageDir: shared }))
      .rejects.toThrow('fixture runtime unavailable')

    expect(manager.ready).toBe(false)
    expect(manager.storageGeneration()).toEqual({ generation: 0, storageDir: shared, windowsWorkspaceFallback: false })
    expect(manager.validatedStorageGeneration()?.storageDir).toBe(shared)
  })

  it('keeps the startup opt-in after preparation fails and honors later active settings', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const manager = new VisionToolkitRuntimeManager(ctx, async (_ctx, resolved) => {
      if (resolved.provider.model === 'broken') throw new Error('fixture runtime unavailable')
      return fakeRuntime(resolved)
    })

    await expect(manager.initialize({ ...config('broken'), windowsWorkspaceFallback: true }))
      .rejects.toThrow('fixture runtime unavailable')
    expect(manager.storageGeneration()).toEqual({ generation: 0, windowsWorkspaceFallback: true })

    await manager.reconfigure({ ...config('working'), windowsWorkspaceFallback: true })
    expect(manager.storageGeneration()).toEqual({ generation: 1, windowsWorkspaceFallback: true })
    await manager.reconfigure(config('working'))
    expect(manager.storageGeneration()).toEqual({ generation: 2, windowsWorkspaceFallback: false })
  })

  it('keeps best-effort consumers usable when startup storage preflight fails', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const parent = await tempDir('invalid-startup-storage')
    const file = join(parent, 'not-a-directory')
    await writeFile(file, 'fixture')
    const factory = vi.fn(async (_ctx: Context, resolved: ResolvedVisionToolkitConfig) => fakeRuntime(resolved))
    const manager = new VisionToolkitRuntimeManager(ctx, factory)

    await expect(manager.initialize({ ...config('broken'), storageDir: file }))
      .rejects.toThrow(/configured storage directory/u)

    expect(manager.ready).toBe(false)
    expect(manager.validatedStorageGeneration()).toBeUndefined()
    expect(() => manager.storageGeneration()).toThrow('storage configuration is not ready')
    expect(factory).not.toHaveBeenCalled()
  })

  it.skipIf(typeof process.geteuid !== 'function')('passes previously validated storage roots to later runtime generations', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const firstStorage = await tempDir('history-first')
    const secondStorage = await tempDir('history-second')
    const seen: string[][] = []
    const factory: RuntimeGenerationFactory = async (_ctx, resolved, readableStorageDirs) => {
      seen.push([...readableStorageDirs])
      return fakeRuntime(resolved)
    }
    const manager = new VisionToolkitRuntimeManager(ctx, factory)

    await manager.initialize({ ...config('first'), storageDir: firstStorage })
    await manager.reconfigure({ ...config('second'), storageDir: secondStorage })

    expect(seen).toEqual([[], [firstStorage]])
  })

  it.skipIf(typeof process.geteuid !== 'function')('retains startup storage after initial runtime preparation fails', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const firstStorage = await tempDir('failed-history-first')
    const secondStorage = await tempDir('failed-history-second')
    const seen: string[][] = []
    const factory: RuntimeGenerationFactory = async (_ctx, resolved, readableStorageDirs) => {
      seen.push([...readableStorageDirs])
      if (resolved.provider.model === 'broken') throw new Error('fixture runtime unavailable')
      return fakeRuntime(resolved)
    }
    const manager = new VisionToolkitRuntimeManager(ctx, factory)

    await expect(manager.initialize({ ...config('broken'), storageDir: firstStorage }))
      .rejects.toThrow('fixture runtime unavailable')
    await manager.reconfigure({ ...config('repaired'), storageDir: secondStorage })

    expect(seen).toEqual([[], [firstStorage]])
  })

  it.skipIf(typeof process.geteuid !== 'function')('restores readable storage history from persisted configuration', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const previousStorage = await tempDir('persisted-history-previous')
    const currentStorage = await tempDir('persisted-history-current')
    const seen: string[][] = []
    const factory: RuntimeGenerationFactory = async (_ctx, resolved, readableStorageDirs) => {
      seen.push([...readableStorageDirs])
      return fakeRuntime(resolved)
    }
    const manager = new VisionToolkitRuntimeManager(ctx, factory)

    await manager.initialize({
      ...config('current'),
      storageDir: currentStorage,
      storageHistory: [previousStorage],
    })

    expect(seen).toEqual([[previousStorage]])
  })

  it('treats transparent-routing visibility as display-only so toggling it does not rebuild the runtime', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const factory = vi.fn(async (_ctx: Context, resolved: ResolvedVisionToolkitConfig) => fakeRuntime(resolved))
    const manager = new VisionToolkitRuntimeManager(ctx, factory)
    await manager.initialize(config('first'))
    expect(factory).toHaveBeenCalledTimes(1)

    const changed = await manager.reconfigure({ ...config('first'), imageInputVariants: { hidden: true } })

    expect(changed).toBe(false)
    expect(factory).toHaveBeenCalledTimes(1)
    expect(manager.status()).toMatchObject({ ready: true, generation: 1 })
    expect(manager.status().activeConfig?.imageInputVariants.hidden).toBe(true)
  })

  it('drops dormant reasoning effort so non-Responses edits do not rebuild the runtime', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    const factory = vi.fn(async (_ctx: Context, resolved: ResolvedVisionToolkitConfig) => fakeRuntime(resolved))
    const manager = new VisionToolkitRuntimeManager(ctx, factory)
    await manager.initialize({
      ...config('first'),
      provider: { ...config('first').provider, protocol: 'openai', reasoningEffort: 'low' },
    })

    const changed = await manager.reconfigure({
      ...config('first'),
      provider: { ...config('first').provider, protocol: 'openai', reasoningEffort: 'high' },
    })

    expect(changed).toBe(false)
    expect(factory).toHaveBeenCalledTimes(1)
    expect(manager.currentConfig().provider.reasoningEffort).toBeUndefined()
    expect(manager.status()).toMatchObject({ ready: true, generation: 1 })
  })

  it('prevents a slower obsolete Settings prepare from overwriting a newer one', async () => {
    const ctx = new Context()
    contexts.push(ctx)
    let releaseSlow: (() => void) | undefined
    const slow = new Promise<void>((resolve) => { releaseSlow = resolve })
    const factory: RuntimeGenerationFactory = async (_ctx, resolved) => {
      if (resolved.provider.model === 'slow') await slow
      return fakeRuntime(resolved)
    }
    const manager = new VisionToolkitRuntimeManager(ctx, factory)
    await manager.initialize(config('first'))

    const older = manager.reconfigure(config('slow'))
    await manager.reconfigure(config('newest'))
    releaseSlow?.()
    await older

    expect(manager.status().activeConfig?.provider.model).toBe('newest')
    expect(manager.current().upstreamVersion.path).toBe('/fixture/newest')
  })
})
