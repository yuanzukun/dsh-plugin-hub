import { test } from 'node:test'
import assert from 'node:assert/strict'
import { joinPayload, maskKey, normalizeClaimUrl, searchPayload, statusPayload } from '../dist/format.js'

test('maskKey hides the middle of an API key', () => {
  assert.equal(maskKey('acn_abcdefghijklmnop'), 'acn_…mnop')
  assert.equal(maskKey(undefined), undefined)
})

test('statusPayload reports not joined without credentials', () => {
  const payload = statusPayload({
    region: 'cn',
    baseUrl: 'https://acn.acnlabs.cn',
    configPath: '/tmp/.acn/config.json',
  })
  assert.equal(payload.joined, false)
  assert.equal(payload.region, 'cn')
})

test('joinPayload never returns the raw key', () => {
  const payload = joinPayload(
    {
      region: 'cn',
      baseUrl: 'https://acn.acnlabs.cn',
      apiKey: 'acn_secret_key_value',
      agentId: 'agent-9',
      configPath: '/tmp/.acn/config.json',
    },
    { agent_id: 'agent-9', api_key: 'acn_secret_key_value' },
  )
  assert.equal(payload.joined, true)
  assert.equal(payload.agent_id, 'agent-9')
  assert.notEqual(payload.api_key, 'acn_secret_key_value')
  assert.match(String(payload.api_key), /…/)
})

test('searchPayload keeps a short public card', () => {
  const payload = searchPayload({
    total: 1,
    agents: [{ id: 'a1', name: 'Demo', description: 'hi', tags: ['coding'], status: 'online' }],
  })
  assert.equal(payload.total, 1)
  assert.equal(payload.agents[0]?.id, 'a1')
})

test('searchPayload reads ACN agent_id when id is absent', () => {
  const payload = searchPayload({
    total: 1,
    agents: [{ agent_id: 'f5f1616f-5583-4f56-b22f-9b8b6efd2fef', name: 'DSH ACN E2E', status: 'online' }],
  })
  assert.equal(payload.agents[0]?.id, 'f5f1616f-5583-4f56-b22f-9b8b6efd2fef')
})

test('searchPayload prefers id over agent_id', () => {
  const payload = searchPayload({
    agents: [{ id: 'keep-me', agent_id: 'ignore-me', name: 'X' }],
  })
  assert.equal(payload.agents[0]?.id, 'keep-me')
})

test('normalizeClaimUrl rewrites CN API host to the CN claim page', () => {
  const url = normalizeClaimUrl(
    'https://acn.acnlabs.cn/claim/abc?token=tok',
    'cn',
  )
  assert.equal(url, 'https://agentplanet.acnlabs.cn/claim/abc?token=tok')
})

test('normalizeClaimUrl does not jump CN claim links to the global site', () => {
  const url = normalizeClaimUrl(
    'https://acn.acnlabs.cn/claim/abc?token=tok',
    'global',
  )
  assert.equal(url, 'https://acn.acnlabs.cn/claim/abc?token=tok')
})

test('normalizeClaimUrl leaves a correct CN claim page alone', () => {
  const url = normalizeClaimUrl(
    'https://agentplanet.acnlabs.cn/claim/abc?token=tok',
    'cn',
  )
  assert.equal(url, 'https://agentplanet.acnlabs.cn/claim/abc?token=tok')
})

test('joinPayload rewrites a CN API claim_url', () => {
  const payload = joinPayload(
    {
      region: 'cn',
      baseUrl: 'https://acn.acnlabs.cn',
      apiKey: 'acn_secret_key_value',
      agentId: 'agent-9',
      configPath: '/tmp/.acn/config.json',
    },
    {
      agent_id: 'agent-9',
      api_key: 'acn_secret_key_value',
      claim_url: 'https://acn.acnlabs.cn/claim/agent-9?token=tok',
    },
  )
  assert.equal(payload.claim_url, 'https://agentplanet.acnlabs.cn/claim/agent-9?token=tok')
  assert.match(String(payload.next_step_hint), /claim_url/)
  assert.match(String(payload.next_step_hint), /\?token=/)
})
