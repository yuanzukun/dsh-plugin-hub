import { mkdtempSync, readFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { inferRegion, normalizeBaseUrl, REGION_CLAIM_ORIGINS, resolveSession, saveConfig } from '../dist/config.js'

test('normalizeBaseUrl strips /api/v1 and trailing slash', () => {
  assert.equal(normalizeBaseUrl('https://acn.acnlabs.cn/api/v1/'), 'https://acn.acnlabs.cn')
})

test('inferRegion maps hosted origins', () => {
  assert.equal(inferRegion('https://acn.acnlabs.cn'), 'cn')
  assert.equal(inferRegion('https://api.acnlabs.dev'), 'global')
  assert.equal(inferRegion('https://self.host.example'), undefined)
})

test('CN claim origin stays on the China site', () => {
  assert.equal(REGION_CLAIM_ORIGINS.cn, 'https://agentplanet.acnlabs.cn')
  assert.equal(REGION_CLAIM_ORIGINS.global, 'https://agentplanet.org')
})

test('resolveSession defaults to cn and reads file credentials', () => {
  const home = mkdtempSync(join(tmpdir(), 'dsh-acn-'))
  saveConfig({ api_key: 'acn_testkey_xxxxx', agent_id: 'agent-1', region: 'cn' }, home)
  const session = resolveSession({ region: 'cn' }, {}, home)
  assert.equal(session.region, 'cn')
  assert.equal(session.baseUrl, 'https://acn.acnlabs.cn')
  assert.equal(session.apiKey, 'acn_testkey_xxxxx')
  assert.equal(session.agentId, 'agent-1')
})

test('plugin config and env beat the file', () => {
  const home = mkdtempSync(join(tmpdir(), 'dsh-acn-'))
  saveConfig({ api_key: 'file', agent_id: 'file-id', region: 'cn' }, home)
  const session = resolveSession(
    { region: 'global', apiKey: 'plugin-key' },
    { ACN_AGENT_ID: 'env-id' },
    home,
  )
  assert.equal(session.region, 'global')
  assert.equal(session.baseUrl, 'https://api.acnlabs.dev')
  assert.equal(session.apiKey, 'plugin-key')
  assert.equal(session.agentId, 'env-id')
})

test('saveConfig writes ~/.acn/config.json compatible with the CLI', () => {
  const home = mkdtempSync(join(tmpdir(), 'dsh-acn-'))
  saveConfig({ api_key: 'acn_abc', agent_id: 'agt', region: 'cn' }, home)
  const raw = JSON.parse(readFileSync(join(home, '.acn', 'config.json'), 'utf8'))
  assert.deepEqual(raw, {
    base_url: 'https://acn.acnlabs.cn',
    api_key: 'acn_abc',
    agent_id: 'agt',
    region: 'cn',
  })
})
