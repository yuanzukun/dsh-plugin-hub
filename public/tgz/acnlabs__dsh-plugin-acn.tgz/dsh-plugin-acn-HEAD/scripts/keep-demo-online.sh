#!/usr/bin/env bash
# Keep a CN-region demo agent visible on ACN (heartbeat every 15 minutes).
# First run joins and writes ~/.acn/dsh-plugin-demo.json; later runs only heartbeat.
# Does not touch ~/.acn/config.json. ACN_ONCE=1 heartbeats once and exits.
set -euo pipefail

REGION="${ACN_REGION:-cn}"
BASE="${ACN_BASE_URL:-https://acn.acnlabs.cn}"
NAME="${ACN_DEMO_NAME:-DeepSeek ACN Demo}"
# Dedicated file so this never overwrites a human agent's ~/.acn/config.json
CONFIG="${ACN_CONFIG:-${HOME}/.acn/dsh-plugin-demo.json}"

mkdir -p "${HOME}/.acn"

if [[ ! -f "$CONFIG" ]] || ! python3 -c 'import json,sys; json.load(open(sys.argv[1]))["api_key"]' "$CONFIG" >/dev/null 2>&1; then
  echo "joining ${BASE} as ${NAME}"
  payload="$(python3 -c 'import json,sys; print(json.dumps({
    "name": sys.argv[1],
    "description": "Public demo agent for the DeepSeek Harness ACN plugin. Send a hello.",
    "tags": ["deepseek", "dsh", "demo"],
    "communication_policy": {"mode": "manifest"},
  }))' "$NAME")"
  resp="$(curl --noproxy '*' -fsS -X POST "${BASE}/api/v1/agents/join" \
    -H 'content-type: application/json' \
    -d "$payload")"
  python3 -c '
import json, sys
body = json.loads(sys.argv[1])
out = {
  "api_key": body["api_key"],
  "agent_id": body["agent_id"],
  "base_url": sys.argv[3].rstrip("/"),
  "region": sys.argv[2],
}
open(sys.argv[4], "w").write(json.dumps(out, indent=2) + "\n")
print("joined agent_id=%s (key saved to %s)" % (out["agent_id"], sys.argv[4]))
' "$resp" "$REGION" "$BASE" "$CONFIG"
fi

agent_id="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["agent_id"])' "$CONFIG")"
api_key="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["api_key"])' "$CONFIG")"

heartbeat_once() {
  curl --noproxy '*' -fsS -X POST "${BASE}/api/v1/agents/${agent_id}/heartbeat" \
    -H "authorization: Bearer ${api_key}" \
    -H 'content-type: application/json' \
    -d '{}' >/dev/null
  echo "$(date -u +%FT%TZ) heartbeat ok"
}

if [[ "${ACN_ONCE:-}" == "1" ]]; then
  echo "heartbeat ${agent_id} once"
  heartbeat_once
  exit 0
fi

echo "heartbeat ${agent_id} every 15m (ctrl-c to stop)"
while true; do
  heartbeat_once
  sleep 900
done
