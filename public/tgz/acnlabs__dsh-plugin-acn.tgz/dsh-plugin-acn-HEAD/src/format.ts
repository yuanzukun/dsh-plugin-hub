import type { AgentRow, JoinResult } from './acn.js'
import { REGION_BASE_URLS, REGION_CLAIM_ORIGINS, type AcnRegion, type ResolvedSession } from './config.js'

/**
 * Join returns claim_url from ACN's frontend_base_url. CN currently falls
 * back to the API host (404). Rewrite only that region's own API host to
 * its claim origin — never jump across regions.
 */
export function normalizeClaimUrl(claimUrl: string | undefined, region?: AcnRegion): string | null {
  if (!claimUrl) return null
  const claimOrigin = region ? REGION_CLAIM_ORIGINS[region] : undefined
  try {
    const parsed = new URL(claimUrl, claimOrigin ?? 'https://invalid.local')
    if (region && claimOrigin && parsed.hostname === new URL(REGION_BASE_URLS[region]).hostname) {
      return new URL(`${parsed.pathname}${parsed.search}`, claimOrigin).toString()
    }
    return parsed.toString()
  } catch {
    return claimUrl
  }
}

export function maskKey(key: string | undefined): string | undefined {
  if (!key) return undefined
  if (key.length <= 8) return 'acn_***'
  return `${key.slice(0, 4)}…${key.slice(-4)}`
}

export function statusPayload(session: ResolvedSession, me?: Record<string, unknown>) {
  return {
    joined: Boolean(session.apiKey && session.agentId),
    region: session.region ?? null,
    base_url: session.baseUrl,
    agent_id: session.agentId ?? (typeof me?.agent_id === 'string' ? me.agent_id : null),
    name: typeof me?.name === 'string' ? me.name : null,
    api_key: maskKey(session.apiKey) ?? null,
    config_path: session.configPath,
    me: me ?? null,
  }
}

export function joinPayload(session: ResolvedSession, result: JoinResult) {
  return {
    joined: true,
    region: session.region ?? null,
    base_url: session.baseUrl,
    agent_id: result.agent_id,
    api_key_saved: true,
    api_key: maskKey(result.api_key),
    config_path: session.configPath,
    status: result.status ?? null,
    communication_mode: result.communication_mode ?? 'manifest',
    claim_url: normalizeClaimUrl(result.claim_url, session.region),
    next_step_hint: result.next_step_hint
      ?? 'Give the human the complete claim_url including ?token= (do not strip the query). Credentials are saved. Then use acn_agents_search.',
  }
}

export function searchPayload(rows: { agents?: AgentRow[]; total?: number }) {
  const agents = (rows.agents ?? []).slice(0, 20).map((agent) => ({
    id: agent.id ?? agent.agent_id ?? null,
    name: agent.name ?? null,
    description: agent.description ?? null,
    tags: agent.tags ?? agent.skills ?? [],
    status: agent.status ?? null,
  }))
  return {
    total: rows.total ?? agents.length,
    agents,
  }
}
