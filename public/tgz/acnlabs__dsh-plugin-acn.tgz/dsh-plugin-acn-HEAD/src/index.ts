import type { Context } from '@deepseek-ai/cordis'
import { defineTool } from '@deepseek-ai/dsh-tools'
import Schema from '@deepseek-ai/schemastery'
import {
  getMe,
  heartbeat,
  joinAgent,
  listInbox,
  searchAgents,
  sendMessage,
} from './acn.js'
import { resolveSession, saveConfig, type AcnRegion, type PluginConfig } from './config.js'
import { joinPayload, searchPayload, statusPayload } from './format.js'
import { loadSkillContent, skillDescription } from './skill.js'

export const name = 'acn'
export const inject = ['tools', 'skills']

export interface Config extends PluginConfig {}

export const Config = Schema.object({
  region: Schema.union(['cn', 'global']).default('cn'),
  apiKey: Schema.string(),
  agentId: Schema.string(),
  baseUrl: Schema.string(),
})

function jsonTool(name: string, description: string, parameters: Record<string, unknown>, execute: (args: Record<string, unknown>, signal?: AbortSignal) => Promise<unknown>) {
  return defineTool({
    name,
    description,
    parameters,
    output: {
      schema: { type: 'object', additionalProperties: true },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value, null, 2) }],
    },
    async execute(args, exec) {
      return execute(args, exec?.signal)
    },
  })
}

function requireSession(config: Config) {
  const session = resolveSession({
    region: (config.region ?? 'cn') as AcnRegion,
    apiKey: config.apiKey,
    agentId: config.agentId,
    baseUrl: config.baseUrl,
  })
  return session
}

function requireJoined(config: Config) {
  const session = requireSession(config)
  if (!session.apiKey || !session.agentId) {
    throw new Error('Not joined. Call acn_join first (or set ACN_API_KEY + ACN_AGENT_ID).')
  }
  return session
}

export function apply(ctx: Context, config: Config) {
  ctx.skills.register({
    name: 'acn',
    description: skillDescription(),
    content: loadSkillContent(),
    source: 'runtime',
    whenToUse: 'User wants this DeepSeek agent on ACN: join, discover agents, send a message, or check inbox.',
  })

  ctx.tools.register(jsonTool(
    'acn_status',
    'Show whether this DeepSeek agent is joined to ACN, and which region. Sends a heartbeat when already joined.',
    {},
    async (_args, signal) => {
      const session = requireSession(config)
      if (!session.apiKey || !session.agentId) {
        return {
          ...statusPayload(session),
          hint: 'Not joined. Ask the user for a display name and tags, then call acn_join. Default region is cn.',
        }
      }
      const [me] = await Promise.all([
        getMe({ ...session, signal }),
        heartbeat({ ...session, signal }, session.agentId).catch(() => null),
      ])
      return statusPayload(session, me)
    },
  ))

  ctx.tools.register(jsonTool(
    'acn_join',
    'Register this DeepSeek agent on ACN (default China region). Saves credentials to ~/.acn/config.json. Give the human the complete claim_url including ?token=. Do not print the full API key.',
    {
      name: { type: 'string', required: true, description: 'Human-readable agent name' },
      description: { type: 'string', description: 'What this agent does (min 10 characters)' },
      tags: { type: 'string', description: 'Comma-separated capability tags, e.g. coding,review' },
      region: { type: 'string', description: 'cn (default) or global. Pick by where the agent is hosted.' },
    },
    async (args, signal) => {
      const region = (String(args.region ?? config.region ?? 'cn').trim().toLowerCase() === 'global'
        ? 'global'
        : 'cn') as AcnRegion
      const name = String(args.name ?? '').trim()
      if (!name) throw new Error('name is required')
      const description = String(args.description ?? '').trim()
        || `${name} — DeepSeek Harness agent on ACN`
      const tags = String(args.tags ?? 'deepseek,dsh')
        .split(',')
        .map((part) => part.trim())
        .filter(Boolean)
      const session = resolveSession({ ...config, region })
      const result = await joinAgent({ ...session, signal }, { name, description, tags })
      const saved = saveConfig({
        api_key: result.api_key,
        agent_id: result.agent_id,
        region,
        base_url: session.baseUrl,
      })
      return joinPayload({
        ...session,
        region: saved.region ?? region,
        apiKey: result.api_key,
        agentId: result.agent_id,
      }, result)
    },
  ))

  ctx.tools.register(jsonTool(
    'acn_agents_search',
    'Discover other ACN agents by name or tag. Defaults to online agents.',
    {
      name: { type: 'string', description: 'Name substring' },
      tag: { type: 'string', description: 'Capability tag, e.g. coding' },
      status: { type: 'string', description: 'online (default) | offline | all' },
    },
    async (args, signal) => {
      const session = requireSession(config)
      const rows = await searchAgents({ ...session, signal }, {
        name: args.name ? String(args.name) : undefined,
        tag: args.tag ? String(args.tag) : undefined,
        status: args.status ? String(args.status) : 'online',
      })
      return searchPayload(rows)
    },
  ))

  ctx.tools.register(jsonTool(
    'acn_message_send',
    'Send a text message to another ACN agent. Requires this agent to be joined.',
    {
      target_agent: { type: 'string', required: true, description: 'Recipient agent_id' },
      text: { type: 'string', required: true, description: 'Message body' },
    },
    async (args, signal) => {
      const session = requireJoined(config)
      const target = String(args.target_agent ?? '').trim()
      const text = String(args.text ?? '').trim()
      if (!target) throw new Error('target_agent is required')
      if (!text) throw new Error('text is required')
      const result = await sendMessage({ ...session, signal }, {
        fromAgent: session.agentId!,
        targetAgent: target,
        text,
      })
      return { sent: true, target_agent: target, result }
    },
  ))

  ctx.tools.register(jsonTool(
    'acn_inbox_list',
    'List inbound ACN messages received while this agent was unreachable (manifest/inbox).',
    {
      limit: { type: 'number', description: 'Max messages (default 20)' },
    },
    async (args, signal) => {
      const session = requireJoined(config)
      const limit = typeof args.limit === 'number' && args.limit > 0 ? Math.min(args.limit, 50) : 20
      const inbox = await listInbox({ ...session, signal }, session.agentId!, limit)
      return { agent_id: session.agentId, messages: inbox.entries ?? inbox.messages ?? [] }
    },
  ))
}
