declare module '@deepseek-ai/cordis' {
  export interface Context {
    tools: { register(tool: unknown): unknown }
    skills: { register(skill: unknown): unknown }
  }
}

declare module '@deepseek-ai/dsh-tools' {
  export function defineTool(definition: {
    name: string
    description: string
    parameters: Record<string, unknown>
    output: {
      schema: Record<string, unknown>
      render: (args: unknown, value: unknown) => Array<{ type: string; text: string }>
    }
    execute: (args: Record<string, unknown>, exec?: { signal?: AbortSignal }) => unknown
  }): unknown
}

declare module '@deepseek-ai/schemastery' {
  interface SchemaNode<T> {
    default(value: T): SchemaNode<T>
  }
  interface SchemaFactory {
    object<T extends Record<string, unknown>>(fields: {
      [K in keyof T]: SchemaNode<T[K]>
    }): SchemaNode<T>
    string(): SchemaNode<string>
    union<T extends string>(values: readonly T[]): SchemaNode<T>
  }
  const Schema: SchemaFactory
  export default Schema
}
