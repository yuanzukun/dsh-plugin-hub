import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

export const REGION_BASE_URLS = {
  global: 'https://api.acnlabs.dev',
  cn: 'https://acn.acnlabs.cn',
} as const

/** Human-facing claim pages. Do not point these at the API host. */
export const REGION_CLAIM_ORIGINS = {
  global: 'https://agentplanet.org',
  cn: 'https://agentplanet.acnlabs.cn',
} as const

export type AcnRegion = keyof typeof REGION_BASE_URLS

export interface AcnFileConfig {
  api_key?: string
  agent_id?: string
  base_url: string
  region?: AcnRegion
}

export interface PluginConfig {
  region: AcnRegion
  apiKey?: string
  agentId?: string
  baseUrl?: string
}

export interface ResolvedSession {
  region?: AcnRegion
  baseUrl: string
  apiKey?: string
  agentId?: string
  configPath: string
}

export function configPath(home = homedir()): string {
  return join(home, '.acn', 'config.json')
}

export function normalizeBaseUrl(url: string): string {
  let u = url.trim().replace(/\/+$/, '')
  u = u.replace(/\/api\/v1$/i, '')
  return u.replace(/\/+$/, '')
}

export function inferRegion(baseUrl: string): AcnRegion | undefined {
  const u = normalizeBaseUrl(baseUrl)
  if (u === REGION_BASE_URLS.global) return 'global'
  if (u === REGION_BASE_URLS.cn) return 'cn'
  return undefined
}

export function readConfigFile(home = homedir()): Partial<AcnFileConfig> {
  const path = configPath(home)
  if (!existsSync(path)) return {}
  try {
    return JSON.parse(readFileSync(path, 'utf8')) as Partial<AcnFileConfig>
  } catch {
    return {}
  }
}

export function saveConfig(updates: Partial<AcnFileConfig>, home = homedir()): AcnFileConfig {
  const dir = join(home, '.acn')
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true, mode: 0o700 })
  const file = readConfigFile(home)
  const next: AcnFileConfig = {
    base_url: file.base_url ? normalizeBaseUrl(file.base_url) : REGION_BASE_URLS.cn,
    api_key: file.api_key,
    agent_id: file.agent_id,
    region: file.region === 'global' || file.region === 'cn' ? file.region : undefined,
    ...updates,
  }
  if (updates.region && !updates.base_url) {
    next.base_url = REGION_BASE_URLS[updates.region]
  }
  if (updates.base_url && updates.region === undefined) {
    next.region = inferRegion(updates.base_url)
  }
  const clean: AcnFileConfig = { base_url: normalizeBaseUrl(next.base_url) }
  if (next.api_key !== undefined) clean.api_key = next.api_key
  if (next.agent_id !== undefined) clean.agent_id = next.agent_id
  const region = next.region ?? inferRegion(clean.base_url)
  if (region !== undefined) clean.region = region
  writeFileSync(configPath(home), JSON.stringify(clean, null, 2), { encoding: 'utf8', mode: 0o600 })
  return clean
}

/**
 * Precedence: plugin config → env → ~/.acn/config.json → region default (cn).
 */
export function resolveSession(
  plugin: PluginConfig,
  env: NodeJS.ProcessEnv = process.env,
  home = homedir(),
): ResolvedSession {
  const file = readConfigFile(home)
  const regionHint = plugin.region
    || env.ACN_REGION?.trim()
    || file.region
    || 'cn'
  const region: AcnRegion = regionHint === 'global' ? 'global' : 'cn'
  const baseUrl = plugin.baseUrl
    ? normalizeBaseUrl(plugin.baseUrl)
    : env.ACN_BASE_URL?.trim()
      ? normalizeBaseUrl(env.ACN_BASE_URL)
      : plugin.region || env.ACN_REGION?.trim()
        ? REGION_BASE_URLS[region]
        : file.base_url
          ? normalizeBaseUrl(file.base_url)
          : REGION_BASE_URLS[region]
  return {
    region: inferRegion(baseUrl) ?? region,
    baseUrl,
    apiKey: plugin.apiKey || env.ACN_API_KEY?.trim() || file.api_key,
    agentId: plugin.agentId || env.ACN_AGENT_ID?.trim() || file.agent_id,
    configPath: configPath(home),
  }
}
