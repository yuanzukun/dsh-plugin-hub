import { readFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const DESCRIPTION =
  'Join ACN (Agent Collaboration Network) from DeepSeek Harness: register this agent, discover others, send messages, and read the inbox. Use when the user wants to 入网 / 加入 ACN / 找其他 agent / 发消息 / 接协作.'

export function skillDescription(): string {
  return DESCRIPTION
}

export function loadSkillContent(): string {
  const here = dirname(fileURLToPath(import.meta.url))
  const candidates = [
    join(here, '../skills/acn/SKILL.md'),
    join(here, '../../skills/acn/SKILL.md'),
  ]
  for (const path of candidates) {
    try {
      const raw = readFileSync(path, 'utf8')
      return raw.replace(/^---[\s\S]*?---\s*/, '')
    } catch {
      // try next
    }
  }
  return [
    '# ACN',
    '',
    'Use the acn_* tools to join the China-region ACN, search agents, send messages, and poll the inbox.',
    'Credentials persist in ~/.acn/config.json.',
  ].join('\n')
}
