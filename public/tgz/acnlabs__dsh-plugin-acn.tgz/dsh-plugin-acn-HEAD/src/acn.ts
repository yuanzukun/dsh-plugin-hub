export class AcnHttpError extends Error {
  readonly status: number
  readonly body: unknown

  constructor(status: number, message: string, body?: unknown) {
    super(message)
    this.name = 'AcnHttpError'
    this.status = status
    this.body = body
  }
}

export interface AcnRequestOptions {
  baseUrl: string
  apiKey?: string
  signal?: AbortSignal
}

async function request<T>(
  opts: AcnRequestOptions,
  method: string,
  path: string,
  init?: { body?: unknown; params?: Record<string, string | undefined> },
): Promise<T> {
  const url = new URL(`${opts.baseUrl.replace(/\/+$/, '')}${path}`)
  if (init?.params) {
    for (const [key, value] of Object.entries(init.params)) {
      if (value !== undefined && value !== '') url.searchParams.set(key, value)
    }
  }
  const headers: Record<string, string> = { Accept: 'application/json' }
  if (init?.body !== undefined) headers['Content-Type'] = 'application/json'
  if (opts.apiKey) headers.Authorization = `Bearer ${opts.apiKey}`

  const response = await fetch(url, {
    method,
    headers,
    body: init?.body === undefined ? undefined : JSON.stringify(init.body),
    signal: opts.signal,
  })

  if (response.status === 204) return undefined as T

  let parsed: unknown = undefined
  const text = await response.text()
  if (text) {
    try {
      parsed = JSON.parse(text)
    } catch {
      parsed = text
    }
  }

  if (!response.ok) {
    const detail = parsed && typeof parsed === 'object'
      ? (parsed as { detail?: unknown; message?: unknown }).detail
        ?? (parsed as { message?: unknown }).message
      : undefined
    throw new AcnHttpError(
      response.status,
      typeof detail === 'string' ? detail : `${method} ${path} failed (${response.status})`,
      parsed,
    )
  }
  return parsed as T
}

export interface JoinResult {
  agent_id: string
  api_key: string
  status?: string
  claim_url?: string
  communication_mode?: string
  next_step_hint?: string
}

export interface AgentRow {
  id?: string
  agent_id?: string
  name?: string
  description?: string
  tags?: string[]
  skills?: string[]
  status?: string
}

export function joinAgent(
  opts: AcnRequestOptions,
  body: { name: string; description: string; tags: string[] },
): Promise<JoinResult> {
  return request(opts, 'POST', '/api/v1/agents/join', {
    body: {
      name: body.name,
      description: body.description,
      tags: body.tags,
      communication_policy: { mode: 'manifest' },
    },
  })
}

export function getMe(opts: AcnRequestOptions): Promise<Record<string, unknown>> {
  return request(opts, 'GET', '/api/v1/agents/me')
}

export function heartbeat(opts: AcnRequestOptions, agentId: string): Promise<Record<string, unknown>> {
  return request(opts, 'POST', `/api/v1/agents/${encodeURIComponent(agentId)}/heartbeat`)
}

export function searchAgents(
  opts: AcnRequestOptions,
  query: { name?: string; tag?: string; status?: string },
): Promise<{ agents?: AgentRow[]; total?: number }> {
  return request(opts, 'GET', '/api/v1/agents', {
    params: {
      name: query.name,
      tag: query.tag,
      status: query.status ?? 'online',
    },
  })
}

export function sendMessage(
  opts: AcnRequestOptions,
  body: { fromAgent: string; targetAgent: string; text: string },
): Promise<Record<string, unknown>> {
  return request(opts, 'POST', '/api/v1/communication/send', {
    body: {
      from_agent: body.fromAgent,
      target_agent: body.targetAgent,
      message: {
        role: 'user',
        parts: [{ type: 'text', text: body.text }],
      },
    },
  })
}

export function listInbox(
  opts: AcnRequestOptions,
  agentId: string,
  limit = 20,
): Promise<{ messages?: unknown[]; entries?: unknown[] }> {
  // v0 join uses communication_policy.mode=manifest. Those messages
  // land on the manifest queue, not the offline history inbox.
  return request(opts, 'GET', `/api/v1/communication/manifest/${encodeURIComponent(agentId)}`, {
    params: { limit: String(limit) },
  })
}
