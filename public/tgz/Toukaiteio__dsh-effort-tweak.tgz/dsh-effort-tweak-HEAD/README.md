# DSH Effort Tweak

English | [中文](README.zh-CN.md)

DSH Effort Tweak adds a small settings page for the per-model capabilities of each model in a DeepSeek Harness custom provider: input types, context window, maximum output, and the reasoning levels the endpoint accepts. It is designed for the case where the model capability must be edited in `llm-pi-ai` configuration but the official Web UI does not yet expose that control.

## What it does

- Adds **Settings → Model capabilities** to the DSH Web UI.
- Lists models explicitly configured in `llm-pi-ai.providers.<provider>.models`.
- Edits four model fields together: `input` (text and/or image), `contextWindow`, `maxTokens`, and `reasoningEfforts`.
- Lets you choose `off`, `minimal`, `low`, `medium`, `high`, `xhigh`, or `max` for the reasoning levels.
- Accepts typed capacities such as `131072`, `256K`, or `1M`, and leaves a blank field inherited instead of copying the fallback into the model.
- Shows what a blank field would inherit from the provider's `defaultContextWindow`, `defaultMaxTokens`, and `defaultInput`.
- Preserves the model's other fields and existing provider-specific wire values.
- Saves through DSH's settings service, so no manual configuration-file editing is needed.

The page intentionally does not show catalog-only providers. Add a model list to a custom provider first, then open this page to tune that model.

## Install from a release

### Windows PowerShell

Run PowerShell as your normal user and execute:

```powershell
irm https://raw.githubusercontent.com/Toukaiteio/dsh-effort-tweak/main/scripts/Install-DshEffortTweak.ps1 | iex
```

To install into another Profile without starting Web UI:

```powershell
$script = "$env:TEMP\Install-DshEffortTweak.ps1"
Invoke-WebRequest https://raw.githubusercontent.com/Toukaiteio/dsh-effort-tweak/main/scripts/Install-DshEffortTweak.ps1 -OutFile $script
& $script -Profile work -NoStart
```

### macOS and Linux

```bash
curl -fsSL https://raw.githubusercontent.com/Toukaiteio/dsh-effort-tweak/main/scripts/install-dsh-effort-tweak.sh | bash
```

For another Profile:

```bash
curl -fsSL https://raw.githubusercontent.com/Toukaiteio/dsh-effort-tweak/main/scripts/install-dsh-effort-tweak.sh -o install-dsh-effort-tweak.sh
bash install-dsh-effort-tweak.sh --profile work --no-start
```

The scripts download the latest GitHub Release archive, verify the GitHub-provided SHA-256 digest when available, keep it under `DSH_HOME/plugin-archives/dsh-effort-tweak/` for future dependency resolution, install it with `dsh plugin`, and start the default `web` Profile unless `--no-start` or `-NoStart` is supplied.

## Install a local package

```bash
pnpm install
pnpm build
dsh plugin --profile web add ./dsh-effort-tweak-0.2.0.tgz
```

Restart DSH Web after installing or updating the plugin so the new client bundle is loaded.

## Development

Requirements: Node.js 22.19 or newer and pnpm 10.

```bash
pnpm install
pnpm check
pnpm pack --pack-destination artifacts
```

The CI workflow checks types, runs unit and bundle integration tests, builds the host and browser bundles, and uploads the package archive. Pushing a matching tag such as `v0.1.0` runs the release workflow and publishes the archive to GitHub Releases.

## Configuration shape

The plugin edits this part of the `llm-pi-ai` namespace:

```yaml
providers:
  my-gateway:
    defaultContextWindow: 128000   # fallback for a model that sizes nothing
    defaultMaxTokens: 8192
    defaultInput: [text]
    models:
      - id: my-reasoning-model
        contextWindow: 200000
        maxTokens: 16384
        input: [text, image]
        reasoningEfforts:
          off: null
          low: low
          high: high
```

- `input` declares the request modalities the endpoint accepts. Blank leaves the field out, so the installed catalog entry, then the provider's `defaultInput`, decide; `llm-pi-ai` treats an empty list the same way, so this page never writes one.
- `contextWindow` and `maxTokens` must be positive integers. Blank removes the field, so the provider's `defaultContextWindow` and `defaultMaxTokens` apply, and the page shows those values as the inherited hint.
- `reasoningEfforts` decides which effort levels the DSH model picker can offer. The plugin uses the existing value for a level when one is already present; a newly enabled level is initialized with its canonical name.

## License

MIT. See [LICENSE](LICENSE).
