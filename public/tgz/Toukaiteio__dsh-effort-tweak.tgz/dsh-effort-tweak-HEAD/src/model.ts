/** The canonical pi-ai escalation order accepted by `llm-pi-ai`. */
export const THINKING_LEVELS = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const

export type ThinkingLevel = (typeof THINKING_LEVELS)[number]
export type ReasoningEfforts = Partial<Record<ThinkingLevel, string | null>>

export interface ModelProfile {
  readonly id: string
  readonly name?: string
  readonly reasoningEfforts?: false | ReasoningEfforts
  readonly [key: string]: unknown
}

export interface ProviderProfile {
  readonly displayName?: string
  readonly models?: readonly ModelProfile[]
  readonly [key: string]: unknown
}

export type ProviderProfiles = Readonly<Record<string, ProviderProfile>>

export interface EditableModel {
  readonly provider: string
  readonly providerLabel: string
  readonly model: ModelProfile
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function isModelProfile(value: unknown): value is ModelProfile {
  return isRecord(value) && typeof value.id === 'string' && value.id.length > 0
}

function isProviderProfile(value: unknown): value is ProviderProfile {
  return isRecord(value)
}

/** Read only explicitly configured model lists; catalog-only routes remain untouched. */
export function editableModels(providers: unknown): readonly EditableModel[] {
  if (!isRecord(providers)) return []
  return Object.entries(providers).flatMap(([provider, rawProfile]) => {
    if (!isProviderProfile(rawProfile) || !Array.isArray(rawProfile.models)) return []
    const providerLabel = typeof rawProfile.displayName === 'string' && rawProfile.displayName.length > 0
      ? `${rawProfile.displayName} (${provider})`
      : provider
    return rawProfile.models
      .filter(isModelProfile)
      .map(model => ({ provider, providerLabel, model }))
  })
}

/** A model explicitly set to `false` cannot have selectable reasoning levels. */
export function supportedLevels(model: ModelProfile): readonly ThinkingLevel[] {
  if (model.reasoningEfforts === false) return []
  const efforts = model.reasoningEfforts
  if (efforts !== undefined && isRecord(efforts)) {
    return THINKING_LEVELS.filter(level => Object.hasOwn(efforts, level))
  }
  return []
}

/** Create a complete, valid effort map from the user's selected levels. */
export function reasoningEffortsFor(levels: ReadonlySet<ThinkingLevel>, existing: unknown): ReasoningEfforts | false {
  const ordered = THINKING_LEVELS.filter(level => levels.has(level))
  if (!ordered.some(level => level !== 'off')) return false
  const known = isRecord(existing) ? existing : {}
  const result: ReasoningEfforts = {}
  for (const level of ordered) {
    const current = known[level]
    if (typeof current === 'string' && current.length > 0) {
      result[level] = current
    } else if (level === 'off') {
      result.off = null
    } else {
      // DeepSeek/OpenAI-compatible endpoints conventionally accept the level
      // spelling directly. Advanced gateways can preserve an existing custom
      // wire value, while this fallback keeps a newly enabled level usable.
      result[level] = level
    }
  }
  return result
}

/** Immutably update one configured model without dropping its unrelated fields. */
export function updateModelEfforts(
  providers: unknown,
  providerId: string,
  modelId: string,
  levels: ReadonlySet<ThinkingLevel>,
): ProviderProfiles {
  if (!isRecord(providers)) return {}
  const profile = providers[providerId]
  if (!isProviderProfile(profile) || !Array.isArray(profile.models)) return providers as ProviderProfiles
  const models = profile.models.map((rawModel) => {
    if (!isModelProfile(rawModel) || rawModel.id !== modelId) return rawModel
    return { ...rawModel, reasoningEfforts: reasoningEffortsFor(levels, rawModel.reasoningEfforts) }
  })
  return { ...providers, [providerId]: { ...profile, models } } as ProviderProfiles
}
