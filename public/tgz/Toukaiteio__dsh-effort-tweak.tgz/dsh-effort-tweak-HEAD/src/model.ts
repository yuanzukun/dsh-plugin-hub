/** The canonical pi-ai escalation order accepted by `llm-pi-ai`. */
export const THINKING_LEVELS = ['off', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const

export type ThinkingLevel = (typeof THINKING_LEVELS)[number]
export type ReasoningEfforts = Partial<Record<ThinkingLevel, string | null>>

/** Request modalities `llm-pi-ai` accepts, in its canonical order. */
export const INPUT_MODALITIES = ['text', 'image'] as const

export type InputModality = (typeof INPUT_MODALITIES)[number]

/** Context capacity `llm-pi-ai` assumes for a model neither the entry nor the catalog sizes. */
export const DEFAULT_CONTEXT_WINDOW = 262_144

/** Output capability `llm-pi-ai` assumes for a model neither the entry nor the catalog sizes. */
export const DEFAULT_MAX_TOKENS = 32_768

export interface ModelProfile {
  readonly id: string
  readonly name?: string
  readonly contextWindow?: number
  readonly maxTokens?: number
  readonly input?: readonly InputModality[]
  readonly reasoningEfforts?: false | ReasoningEfforts
  readonly [key: string]: unknown
}

/** Route-level fallbacks a model entry inherits when it declares nothing itself. */
export interface RouteDefaults {
  readonly contextWindow?: number
  readonly maxTokens?: number
  readonly input?: readonly InputModality[]
}

export interface ProviderProfile {
  readonly displayName?: string
  readonly defaultContextWindow?: number
  readonly defaultMaxTokens?: number
  readonly defaultInput?: readonly InputModality[]
  readonly models?: readonly ModelProfile[]
  readonly [key: string]: unknown
}

export type ProviderProfiles = Readonly<Record<string, ProviderProfile>>

export interface EditableModel {
  readonly provider: string
  readonly providerLabel: string
  readonly model: ModelProfile
  /** Values this model inherits from its route when its own entry omits a field. */
  readonly defaults: RouteDefaults
}

/** Everything this page edits on one model, normalized for comparison and saving. */
export interface ModelDraft {
  readonly levels: ReadonlySet<ThinkingLevel>
  /** Explicit context capacity; undefined inherits the route or catalog value. */
  readonly contextWindow?: number
  /** Explicit output cap; undefined inherits the route or catalog value. */
  readonly maxTokens?: number
  /** Explicit request modalities; undefined inherits them. */
  readonly input?: readonly InputModality[]
}

/** Outcome of reading a typed capacity such as `262144`, `256K`, or `1M`. */
export type CapacityParse =
  | { readonly kind: 'inherit' }
  | { readonly kind: 'invalid' }
  | { readonly kind: 'value'; readonly value: number }

/** Decimal capacity suffixes, matching how model capacities are quoted. */
const CAPACITY_PATTERN = /^(\d+(?:\.\d+)?)([km])?$/i
const CAPACITY_SCALE = { k: 1_000, m: 1_000_000 } as const

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

function isModelProfile(value: unknown): value is ModelProfile {
  return isRecord(value) && typeof value.id === 'string' && value.id.length > 0
}

function isProviderProfile(value: unknown): value is ProviderProfile {
  return isRecord(value)
}

/** Read a positive capacity, treating anything else as inherited. */
function positiveInteger(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isInteger(value) && value > 0 ? value : undefined
}

/** Read a configured modality list, keeping only values pi-ai accepts. */
export function normalizeInput(value: unknown): readonly InputModality[] | undefined {
  if (!Array.isArray(value)) return undefined
  if (!value.every(modality => (INPUT_MODALITIES as readonly unknown[]).includes(modality))) return undefined
  const declared = INPUT_MODALITIES.filter(modality => (value as readonly InputModality[]).includes(modality))
  // pi-ai reads an absent list and an empty one the same way — the entry states
  // no answer, so the installed catalog then the route default decide — which is
  // what `undefined` means here.
  return declared.length === 0 ? undefined : declared
}

/** Read only explicitly configured model lists; catalog-only routes remain untouched. */
export function editableModels(providers: unknown): readonly EditableModel[] {
  if (!isRecord(providers)) return []
  return Object.entries(providers).flatMap(([provider, rawProfile]) => {
    if (!isProviderProfile(rawProfile) || !Array.isArray(rawProfile.models)) return []
    const providerLabel = typeof rawProfile.displayName === 'string' && rawProfile.displayName.length > 0
      ? `${rawProfile.displayName} (${provider})`
      : provider
    const defaults: RouteDefaults = {
      contextWindow: positiveInteger(rawProfile.defaultContextWindow),
      maxTokens: positiveInteger(rawProfile.defaultMaxTokens),
      input: normalizeInput(rawProfile.defaultInput),
    }
    return rawProfile.models
      .filter(isModelProfile)
      .map(model => ({ provider, providerLabel, model, defaults }))
  })
}

/** A model explicitly set to `false` cannot have selectable reasoning levels. */
export function supportedLevels(model: ModelProfile): readonly ThinkingLevel[] {
  if (model.reasoningEfforts === false) return []
  const efforts = model.reasoningEfforts
  if (efforts !== undefined && isRecord(efforts)) {
    return THINKING_LEVELS.filter(level => Object.hasOwn(efforts, level))
  }
  return []
}

/** Read a model's own modality declaration; undefined means it inherits. */
export function declaredInput(model: ModelProfile): readonly InputModality[] | undefined {
  return normalizeInput(model.input)
}

/** A capacity a model inherits, and whether the route itself declared it. */
export interface InheritedCapacity {
  readonly value: number
  /** True when the provider declared the fallback; false when the built-in default applies. */
  readonly route: boolean
}

/**
 * What a blank capacity field would resolve to for one model.
 * @param item - the editable model, including its route defaults.
 * @param field - which capacity to describe.
 * @returns the inherited count and which layer supplied it.
 */
export function inheritedCapacity(item: EditableModel, field: 'contextWindow' | 'maxTokens'): InheritedCapacity {
  const route = item.defaults[field]
  return {
    value: route ?? (field === 'contextWindow' ? DEFAULT_CONTEXT_WINDOW : DEFAULT_MAX_TOKENS),
    route: route !== undefined,
  }
}

/**
 * What an empty input declaration would resolve to for one model. The route's
 * `defaultInput` is the only layer this page can read; the installed catalog is
 * not part of the settings document.
 * @param item - the editable model, including its route defaults.
 * @returns the inherited modalities, or undefined when the route declares none.
 */
export function inheritedInput(item: EditableModel): readonly InputModality[] | undefined {
  return item.defaults.input
}

/**
 * Read a typed capacity, so a user can write `256K` or `1M` instead of counting
 * zeroes. The stored value stays a plain token count.
 * @param text - raw field text.
 * @returns `inherit` when blank, `invalid` when unreadable, otherwise the count.
 */
export function parseCapacity(text: string): CapacityParse {
  const trimmed = text.trim()
  if (trimmed.length === 0) return { kind: 'inherit' }
  const match = CAPACITY_PATTERN.exec(trimmed)
  if (match === null) return { kind: 'invalid' }
  const suffix = match[2]?.toLowerCase()
  const scale = suffix === 'k' ? CAPACITY_SCALE.k : suffix === 'm' ? CAPACITY_SCALE.m : 1
  const value = Math.round(Number(match[1]) * scale)
  if (!Number.isSafeInteger(value) || value < 1) return { kind: 'invalid' }
  return { kind: 'value', value }
}

/**
 * Spell a stored count back in the shortest form that survives a round trip
 * through {@link parseCapacity}; a count that is not a whole number of
 * thousands stays written out.
 * @param value - stored capacity.
 * @returns the field text.
 */
export function formatCapacity(value: number): string {
  if (!Number.isInteger(value) || value <= 0) return String(value)
  if (value % CAPACITY_SCALE.m === 0) return `${String(value / CAPACITY_SCALE.m)}M`
  if (value % CAPACITY_SCALE.k === 0) return `${String(value / CAPACITY_SCALE.k)}K`
  return String(value)
}

/** The normalized draft one model currently declares. */
export function modelDraft(model: ModelProfile): ModelDraft {
  return {
    levels: new Set(supportedLevels(model)),
    contextWindow: positiveInteger(model.contextWindow),
    maxTokens: positiveInteger(model.maxTokens),
    input: declaredInput(model),
  }
}

/** The draft a model would have while editing, where text fields keep their raw spelling. */
export interface DraftFields {
  readonly levels: ReadonlySet<ThinkingLevel>
  readonly contextWindow: string
  readonly maxTokens: string
  readonly input: ReadonlySet<InputModality>
}

/** Turn the editing fields into a draft, or report the first unreadable capacity. */
export type DraftParse =
  | { readonly kind: 'ok'; readonly draft: ModelDraft }
  | { readonly kind: 'invalid'; readonly field: 'contextWindow' | 'maxTokens' }

/**
 * Read the editor's fields into a draft.
 * @param fields - checked levels, raw capacity text, and checked modalities.
 * @returns the draft, or which capacity field is unreadable.
 */
export function parseDraft(fields: DraftFields): DraftParse {
  const contextWindow = parseCapacity(fields.contextWindow)
  if (contextWindow.kind === 'invalid') return { kind: 'invalid', field: 'contextWindow' }
  const maxTokens = parseCapacity(fields.maxTokens)
  if (maxTokens.kind === 'invalid') return { kind: 'invalid', field: 'maxTokens' }
  const input = INPUT_MODALITIES.filter(modality => fields.input.has(modality))
  return {
    kind: 'ok',
    draft: {
      levels: new Set(THINKING_LEVELS.filter(level => fields.levels.has(level))),
      ...contextWindow.kind === 'value' ? { contextWindow: contextWindow.value } : {},
      ...maxTokens.kind === 'value' ? { maxTokens: maxTokens.value } : {},
      ...input.length === 0 ? {} : { input },
    },
  }
}

/** Compare two drafts by value, including the ordered modality list. */
export function sameDraft(left: ModelDraft, right: ModelDraft): boolean {
  return JSON.stringify(draftKey(left)) === JSON.stringify(draftKey(right))
}

function draftKey(draft: ModelDraft): readonly unknown[] {
  return [
    THINKING_LEVELS.filter(level => draft.levels.has(level)),
    draft.contextWindow ?? null,
    draft.maxTokens ?? null,
    draft.input === undefined ? null : [...draft.input],
  ]
}

/** Create a complete, valid effort map from the user's selected levels. */
export function reasoningEffortsFor(levels: ReadonlySet<ThinkingLevel>, existing: unknown): ReasoningEfforts | false {
  const ordered = THINKING_LEVELS.filter(level => levels.has(level))
  if (!ordered.some(level => level !== 'off')) return false
  const known = isRecord(existing) ? existing : {}
  const result: ReasoningEfforts = {}
  for (const level of ordered) {
    const current = known[level]
    if (typeof current === 'string' && current.length > 0) {
      result[level] = current
    } else if (level === 'off') {
      result.off = null
    } else {
      // DeepSeek/OpenAI-compatible endpoints conventionally accept the level
      // spelling directly. Advanced gateways can preserve an existing custom
      // wire value, while this fallback keeps a newly enabled level usable.
      result[level] = level
    }
  }
  return result
}

/** Copy one model, setting or removing the fields the draft declares. */
function applyDraft(model: ModelProfile, draft: ModelDraft): ModelProfile {
  const { contextWindow: _contextWindow, maxTokens: _maxTokens, input: _input, ...rest } = model
  const next: Record<string, unknown> = {
    ...rest,
    reasoningEfforts: reasoningEffortsFor(draft.levels, model.reasoningEfforts),
  }
  // An absent field inherits the route or installed-catalog value, so clearing a
  // control removes the key instead of writing a copy of the inherited number.
  if (draft.contextWindow !== undefined) next.contextWindow = draft.contextWindow
  if (draft.maxTokens !== undefined) next.maxTokens = draft.maxTokens
  if (draft.input !== undefined) next.input = INPUT_MODALITIES.filter(modality => draft.input?.includes(modality))
  return next as ModelProfile
}

/**
 * Immutably update one configured model's reasoning levels, context window,
 * output cap, and input modalities without dropping its unrelated fields.
 * @param providers - configured `llm-pi-ai.providers` value.
 * @param providerId - route key owning the model.
 * @param modelId - model id inside that route's list.
 * @param draft - the normalized model settings to store.
 * @returns the updated providers value; untouched routes keep their identity.
 */
export function updateModelConfig(
  providers: unknown,
  providerId: string,
  modelId: string,
  draft: ModelDraft,
): ProviderProfiles {
  if (!isRecord(providers)) return {}
  const profile = providers[providerId]
  if (!isProviderProfile(profile) || !Array.isArray(profile.models)) return providers as ProviderProfiles
  const models = profile.models.map((rawModel) => {
    if (!isModelProfile(rawModel) || rawModel.id !== modelId) return rawModel
    return applyDraft(rawModel, draft)
  })
  return { ...providers, [providerId]: { ...profile, models } } as ProviderProfiles
}

/** Immutably update one configured model's reasoning levels only. */
export function updateModelEfforts(
  providers: unknown,
  providerId: string,
  modelId: string,
  levels: ReadonlySet<ThinkingLevel>,
): ProviderProfiles {
  const found = editableModels(providers).find(item => item.provider === providerId && item.model.id === modelId)
  if (found === undefined) return (isRecord(providers) ? providers : {}) as ProviderProfiles
  return updateModelConfig(providers, providerId, modelId, { ...modelDraft(found.model), levels })
}
