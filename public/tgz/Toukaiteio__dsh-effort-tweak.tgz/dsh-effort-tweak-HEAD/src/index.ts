import type { Context } from '@deepseek-ai/cordis'

export const name = 'dsh-effort-tweak'

/** The feature is entirely a Web UI settings contribution. */
export function apply(_ctx: Context): void {}

