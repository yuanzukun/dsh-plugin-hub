import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import type { ReasoningEffortSectionInjected } from './ReasoningEffortSection.js'
import { ReasoningEffortSection } from './ReasoningEffortSection.js'
import { en, zh, type EffortLocaleKey } from './locales.js'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'dsh-effort-tweak': EffortLocaleKey
  }
}

export const inject = ['slots', 'locale', 'connection', 'remote', 'settingsScope']

const NS = 'dsh-effort-tweak'

/** Register one focused Settings page for per-model reasoning capabilities. */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-effort-tweak: dictionaries')
  const t = ctx.locale.bind(NS)
  const scope = ctx.settingsScope.bind<Record<string, unknown>>({ namespace: 'llm-pi-ai' })
  const injected = (): ReasoningEffortSectionInjected => ({
    scope,
    settings: (ctx.get('connection') as { api: ReasoningEffortSectionInjected['settings'] }).api,
  })
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'effort-tweak',
    order: 15,
    label: () => t('nav'),
    inject: injected,
    locale: NS,
  }, ReasoningEffortSection))
}
