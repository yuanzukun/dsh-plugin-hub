import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
import { ReasoningEffortSection } from './ReasoningEffortSection.js'
import type { ReasoningEffortSectionInjected } from './ReasoningEffortSection.js'
import { en, zh, type EffortLocaleKey } from './locales.js'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'dsh-effort-tweak': EffortLocaleKey
  }
}

/** The Host plugin entry this page edits; `configForms.get` is keyed by it. */
const SETTINGS_ENTRY = 'llm-pi-ai'

export const inject = ['slots', 'locale', 'configForms']

const NS = 'dsh-effort-tweak'

/** Register one focused Settings page for per-model reasoning capabilities. */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-effort-tweak: dictionaries')
  const t = ctx.locale.bind(NS)
  const form = ctx.configForms.get<Record<string, unknown>>(SETTINGS_ENTRY)
  const injected = (): ReasoningEffortSectionInjected => ({ form })
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'effort-tweak',
    order: 15,
    label: () => t('nav'),
    inject: injected,
    locale: NS,
  }, ReasoningEffortSection))
}
