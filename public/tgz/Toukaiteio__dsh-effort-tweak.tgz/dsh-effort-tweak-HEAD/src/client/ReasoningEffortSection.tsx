import { useEffect, useMemo, useState, useSyncExternalStore } from 'react'
import type { ReactNode } from 'react'
import type { SettingsScope } from '@deepseek-ai/dsh-client-runtime/client'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import {
  THINKING_LEVELS,
  editableModels,
  supportedLevels,
  updateModelEfforts,
  type ThinkingLevel,
} from '../model.js'
import type { EffortLocaleKey } from './locales.js'
import css from './ReasoningEffortSection.module.css'

type SettingsProps = PropsRuntime<'settings.section'> & PropsLocale<'dsh-effort-tweak'>

export interface ReasoningEffortSectionInjected {
  readonly scope: SettingsScope<Record<string, unknown>>
  readonly settings: SettingsMutationApi
}

interface SettingsMutationApi {
  readonly settings: {
    mutate(request: {
      readonly ns: string
      readonly expectedRevision?: number
      readonly ops: readonly {
        readonly op: 'set'
        readonly path: readonly string[]
        readonly value: unknown
      }[]
    }): Promise<{ readonly result: { readonly ok: true; readonly value: unknown } | { readonly ok: false; readonly error: { readonly message: string } } }>
  }
}

type ReasoningEffortSectionProps = SettingsProps & Partial<ReasoningEffortSectionInjected>

function selectedLevels(value: unknown): Set<ThinkingLevel> {
  if (value === false) return new Set()
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return new Set()
  const entries = value as Record<string, unknown>
  return new Set(THINKING_LEVELS.filter(level => Object.hasOwn(entries, level)))
}

function levelKey(level: ThinkingLevel): EffortLocaleKey {
  return `level_${level}`
}

/** A narrow settings page that only edits model reasoning capabilities. */
export function ReasoningEffortSection({ scope, settings, t }: ReasoningEffortSectionProps): ReactNode {
  const snapshot = useSyncExternalStore(
    listener => scope?.subscribe(listener) ?? (() => {}),
    () => scope?.getSnapshot() ?? {
      status: 'unavailable' as const,
      value: undefined,
      base: undefined,
      user: undefined,
      revision: undefined,
      writable: false,
      mode: 'memory' as const,
    },
  )
  const models = useMemo(() => editableModels(snapshot.value?.providers), [snapshot.value])
  const [activeKey, setActiveKey] = useState<string | undefined>(undefined)
  const [levels, setLevels] = useState<Set<ThinkingLevel>>(new Set())
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ kind: 'success' | 'error'; text: string } | undefined>(undefined)

  useEffect(() => {
    const found = activeKey === undefined ? undefined : models.find(item => `${item.provider}\u0000${item.model.id}` === activeKey)
    const next = found ?? models[0]
    setActiveKey(next === undefined ? undefined : `${next.provider}\u0000${next.model.id}`)
    setLevels(next === undefined ? new Set() : selectedLevels(next.model.reasoningEfforts))
    setMessage(undefined)
  }, [models, activeKey])

  const active = activeKey === undefined ? undefined : models.find(item => `${item.provider}\u0000${item.model.id}` === activeKey)
  const activeLevels = active === undefined ? [] : supportedLevels(active.model)
  const dirty = active !== undefined
    && JSON.stringify([...levels].sort()) !== JSON.stringify([...selectedLevels(active.model.reasoningEfforts)].sort())

  const selectModel = (key: string): void => {
    const next = models.find(item => `${item.provider}\u0000${item.model.id}` === key)
    if (next === undefined) return
    setActiveKey(key)
    setLevels(selectedLevels(next.model.reasoningEfforts))
    setMessage(undefined)
  }

  const toggleLevel = (level: ThinkingLevel): void => {
    setLevels((current) => {
      const next = new Set(current)
      if (!next.delete(level)) next.add(level)
      return next
    })
    setMessage(undefined)
  }

  const save = async (): Promise<void> => {
    if (scope === undefined || settings === undefined || active === undefined || !dirty) {
      setMessage({ kind: 'success', text: t('unchanged') })
      return
    }
    setSaving(true)
    setMessage(undefined)
    try {
      const providers = updateModelEfforts(snapshot.value?.providers, active.provider, active.model.id, levels)
      const models = providers[active.provider]?.models
      if (models === undefined) throw new Error(t('unavailable'))
      const response = await settings.settings.mutate({
        ns: 'llm-pi-ai',
        ops: [{ op: 'set', path: ['providers', active.provider, 'models'], value: models }],
        ...snapshot.revision === undefined ? {} : { expectedRevision: snapshot.revision },
      })
      if (!response.result.ok) throw new Error(response.result.error.message)
      setMessage({ kind: 'success', text: levels.size === 0 ? t('disabled') : t('saved') })
    } catch (error) {
      setMessage({ kind: 'error', text: error instanceof Error ? error.message : t('unavailable') })
    } finally {
      setSaving(false)
    }
  }

  if (snapshot.status === 'loading') return <p className={css.status}>{t('loading')}</p>
  if (snapshot.status !== 'ready' || scope === undefined) return <p className={css.status}>{t('unavailable')}</p>

  return (
    <section className={css.section} aria-busy={saving}>
      <div className={css.heading}>
        <h2>{t('title')}</h2>
        <p>{t('description')}</p>
      </div>

      {models.length === 0
        ? <p className={css.empty}>{t('noModels')}</p>
        : (
          <>
            <div className={css.pickRow}>
              <label className={css.field}>
                <span>{t('provider')}</span>
                <select
                  value={active?.provider ?? ''}
                  disabled={saving}
                  onChange={(event) => {
                    const next = models.find(item => item.provider === event.currentTarget.value)
                    if (next !== undefined) selectModel(`${next.provider}\u0000${next.model.id}`)
                  }}
                >
                  {[...new Map(models.map(item => [item.provider, item])).values()].map(item => (
                    <option key={item.provider} value={item.provider}>{item.providerLabel}</option>
                  ))}
                </select>
              </label>
              <label className={css.field}>
                <span>{t('model')}</span>
                <select value={activeKey ?? ''} disabled={saving} onChange={(event) => { selectModel(event.currentTarget.value) }}>
                  {models.filter(item => item.provider === active?.provider).map(item => (
                    <option key={`${item.provider}\u0000${item.model.id}`} value={`${item.provider}\u0000${item.model.id}`}>
                      {item.model.name === undefined || item.model.name === item.model.id
                        ? item.model.id
                        : t('modelLabel', { name: item.model.name, id: item.model.id })}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <fieldset className={css.levels} disabled={saving || !snapshot.writable}>
              <legend>{t('enabledLevels')}</legend>
              <div className={css.levelGrid}>
                {THINKING_LEVELS.map(level => (
                  <label key={level} className={css.level}>
                    <input
                      type="checkbox"
                      checked={levels.has(level)}
                      onChange={() => { toggleLevel(level) }}
                    />
                    <span>{t(levelKey(level))}</span>
                  </label>
                ))}
              </div>
            </fieldset>

            {activeLevels.length === 0 && active?.model.reasoningEfforts === false
              ? <p className={css.hint}>{t('disabled')}</p>
              : null}
            {snapshot.writable ? null : <p className={css.warning}>{t('readOnly')}</p>}
            {message === undefined ? null : (
              <p className={message.kind === 'success' ? css.success : css.error} role={message.kind === 'error' ? 'alert' : 'status'}>
                {message.text}
              </p>
            )}
            <div className={css.actions}>
              <button type="button" className={css.save} disabled={saving || !snapshot.writable || !dirty} onClick={() => { void save() }}>
                {saving ? t('saving') : t('save')}
              </button>
            </div>
          </>
        )}
    </section>
  )
}
