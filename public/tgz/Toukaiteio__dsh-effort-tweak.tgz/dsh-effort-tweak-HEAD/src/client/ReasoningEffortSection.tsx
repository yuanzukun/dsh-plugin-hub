import { useEffect, useMemo, useState, useSyncExternalStore } from 'react'
import type { ReactNode } from 'react'
import type { ConfigForm } from '@deepseek-ai/dsh-client-ui-settings/client'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import {
  INPUT_MODALITIES,
  THINKING_LEVELS,
  editableModels,
  formatCapacity,
  inheritedCapacity,
  inheritedInput,
  modelDraft,
  parseDraft,
  sameDraft,
  updateModelConfig,
  type EditableModel,
  type InputModality,
  type ModelDraft,
  type ThinkingLevel,
} from '../model.js'
import type { EffortLocaleKey } from './locales.js'
import css from './ReasoningEffortSection.module.css'

type SettingsProps = PropsRuntime<'settings.section'> & PropsLocale<'dsh-effort-tweak'>

export interface ReasoningEffortSectionInjected {
  readonly form: ConfigForm<Record<string, unknown>>
}

type ReasoningEffortSectionProps = SettingsProps & Partial<ReasoningEffortSectionInjected>

/** The editing state of one model: raw text where the user may still be typing. */
interface Fields {
  readonly levels: ReadonlySet<ThinkingLevel>
  readonly contextWindow: string
  readonly maxTokens: string
  readonly input: ReadonlySet<InputModality>
}

function levelKey(level: ThinkingLevel): EffortLocaleKey {
  return `level_${level}`
}

function modalityKey(modality: InputModality): EffortLocaleKey {
  return `input_${modality}`
}

function itemKey(item: EditableModel): string {
  return `${item.provider}\u0000${item.model.id}`
}

/** The fields that display a model's stored configuration. */
function fieldsOf(model: EditableModel['model']): Fields {
  const draft = modelDraft(model)
  return {
    levels: draft.levels,
    contextWindow: draft.contextWindow === undefined ? '' : formatCapacity(draft.contextWindow),
    maxTokens: draft.maxTokens === undefined ? '' : formatCapacity(draft.maxTokens),
    input: new Set(draft.input ?? []),
  }
}

const EMPTY_FIELDS: Fields = { levels: new Set(), contextWindow: '', maxTokens: '', input: new Set() }

/** A narrow settings page that edits one model's capabilities. */
export function ReasoningEffortSection({ form, t }: ReasoningEffortSectionProps): ReactNode {
  const snapshot = useSyncExternalStore(
    listener => form?.subscribe(listener) ?? (() => {}),
    () => form?.getSnapshot() ?? {
      status: 'unavailable' as const,
      value: undefined,
      base: undefined,
      user: undefined,
      revision: undefined,
      writable: false,
    },
  )
  const models = useMemo(() => editableModels(snapshot.value?.providers), [snapshot.value])
  const [selectedKey, setSelectedKey] = useState<string | undefined>(undefined)
  /** The user's unsaved edits, together with the model key they belong to. */
  const [edit, setEdit] = useState<{ readonly key: string; readonly fields: Fields } | undefined>(undefined)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ kind: 'success' | 'error'; text: string } | undefined>(undefined)

  // The first model is selected until the user picks another one, so the page
  // never renders an empty form while models are available.
  const active = models.find(item => itemKey(item) === selectedKey) ?? models[0]
  const activeKey = active === undefined ? undefined : itemKey(active)
  const fields = edit !== undefined && edit.key === activeKey
    ? edit.fields
    : active === undefined ? EMPTY_FIELDS : fieldsOf(active.model)

  // A new accepted snapshot (another page's save, or this page's own recovery
  // read) invalidates the draft, which now describes a superseded value.
  useEffect(() => {
    setEdit(undefined)
  }, [snapshot.value])

  const parsed = parseDraft(fields)
  const draft: ModelDraft | undefined = parsed.kind === 'ok' ? parsed.draft : undefined
  const invalidField = parsed.kind === 'invalid' ? parsed.field : undefined
  const dirty = active !== undefined && draft !== undefined && !sameDraft(draft, modelDraft(active.model))

  const selectModel = (key: string): void => {
    if (!models.some(item => itemKey(item) === key)) return
    setSelectedKey(key)
    setEdit(undefined)
    setMessage(undefined)
  }

  const update = (patch: Partial<Fields>): void => {
    if (activeKey === undefined) return
    setEdit({ key: activeKey, fields: { ...fields, ...patch } })
    setMessage(undefined)
  }

  const toggleLevel = (level: ThinkingLevel): void => {
    const next = new Set(fields.levels)
    if (!next.delete(level)) next.add(level)
    update({ levels: next })
  }

  const toggleModality = (modality: InputModality): void => {
    const next = new Set(fields.input)
    if (!next.delete(modality)) next.add(modality)
    update({ input: next })
  }

  const save = async (): Promise<void> => {
    if (form === undefined || active === undefined || draft === undefined) {
      setMessage({ kind: 'error', text: t('capacityInvalid') })
      return
    }
    if (!dirty) {
      setMessage({ kind: 'success', text: t('unchanged') })
      return
    }
    setSaving(true)
    setMessage(undefined)
    try {
      const providers = updateModelConfig(snapshot.value?.providers, active.provider, active.model.id, draft)
      const models = providers[active.provider]?.models
      if (models === undefined) throw new Error(t('unavailable'))
      // The wire op carries plain JSON: round-trip drops the readonly shape and
      // any non-JSON member the profile type allows through its index signature.
      const accepted = await form.mutate(
        [{ op: 'set', path: ['providers', active.provider, 'models'], value: JSON.parse(JSON.stringify(models)) }],
        snapshot.revision,
      )
      if (!accepted) throw new Error(t('unavailable'))
      setEdit(undefined)
      setMessage({ kind: 'success', text: fields.levels.size === 0 ? t('disabled') : t('saved') })
    } catch (error) {
      setMessage({ kind: 'error', text: error instanceof Error ? error.message : t('unavailable') })
    } finally {
      setSaving(false)
    }
  }

  if (snapshot.status === 'loading') return <p className={css.status}>{t('loading')}</p>
  if (snapshot.status !== 'ready' || form === undefined) return <p className={css.status}>{t('unavailable')}</p>

  const disabled = saving || !snapshot.writable
  const contextInherited = active === undefined || fields.contextWindow.trim().length > 0
    ? undefined
    : inheritedCapacity(active, 'contextWindow')
  const maxTokensInherited = active === undefined || fields.maxTokens.trim().length > 0
    ? undefined
    : inheritedCapacity(active, 'maxTokens')
  // A model that declares no input list takes the route default, which may itself be unset.
  const inputInherited = active === undefined || fields.input.size > 0 ? undefined : inheritedInput(active)

  return (
    <section className={css.section} aria-busy={saving}>
      <div className={css.heading}>
        <h2>{t('title')}</h2>
        <p>{t('description')}</p>
      </div>

      {models.length === 0
        ? <p className={css.empty}>{t('noModels')}</p>
        : (
          <>
            <div className={css.pickRow}>
              <label className={css.field}>
                <span>{t('provider')}</span>
                <select
                  value={active?.provider ?? ''}
                  disabled={saving}
                  onChange={(event) => {
                    const next = models.find(item => item.provider === event.currentTarget.value)
                    if (next !== undefined) selectModel(itemKey(next))
                  }}
                >
                  {[...new Map(models.map(item => [item.provider, item])).values()].map(item => (
                    <option key={item.provider} value={item.provider}>{item.providerLabel}</option>
                  ))}
                </select>
              </label>
              <label className={css.field}>
                <span>{t('model')}</span>
                <select value={activeKey ?? ''} disabled={saving} onChange={(event) => { selectModel(event.currentTarget.value) }}>
                  {models.filter(item => item.provider === active?.provider).map(item => (
                    <option key={itemKey(item)} value={itemKey(item)}>
                      {item.model.name === undefined || item.model.name === item.model.id
                        ? item.model.id
                        : t('modelLabel', { name: item.model.name, id: item.model.id })}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <fieldset className={css.group} disabled={disabled}>
              <legend>{t('inputTypes')}</legend>
              <div className={css.levelGrid}>
                {INPUT_MODALITIES.map(modality => (
                  <label key={modality} className={css.level}>
                    <input
                      type="checkbox"
                      checked={fields.input.has(modality)}
                      onChange={() => { toggleModality(modality) }}
                    />
                    <span>{t(modalityKey(modality))}</span>
                  </label>
                ))}
              </div>
              <p className={css.hint}>
                {t('inputHint')}
                {inputInherited === undefined
                  ? null
                  : ` ${t('inheritedRoute', { value: inputInherited.join(', ') })}`}
              </p>
            </fieldset>

            <fieldset className={css.group} disabled={disabled}>
              <legend>{t('capacities')}</legend>
              <div className={css.pickRow}>
                <label className={css.field}>
                  <span>{t('contextWindow')}</span>
                  <input
                    type="text"
                    inputMode="numeric"
                    className={invalidField === 'contextWindow' ? css.invalid : undefined}
                    placeholder={t('contextWindowPlaceholder')}
                    value={fields.contextWindow}
                    aria-invalid={invalidField === 'contextWindow'}
                    onChange={(event) => { update({ contextWindow: event.currentTarget.value }) }}
                  />
                  <span className={css.hint}>
                    {contextInherited === undefined
                      ? null
                      : t(contextInherited.route ? 'inheritedRoute' : 'inheritedCatalog', { value: formatCapacity(contextInherited.value) })}
                  </span>
                </label>
                <label className={css.field}>
                  <span>{t('maxTokens')}</span>
                  <input
                    type="text"
                    inputMode="numeric"
                    className={invalidField === 'maxTokens' ? css.invalid : undefined}
                    placeholder={t('maxTokensPlaceholder')}
                    value={fields.maxTokens}
                    aria-invalid={invalidField === 'maxTokens'}
                    onChange={(event) => { update({ maxTokens: event.currentTarget.value }) }}
                  />
                  <span className={css.hint}>
                    {maxTokensInherited === undefined
                      ? null
                      : t(maxTokensInherited.route ? 'inheritedRoute' : 'inheritedCatalog', { value: formatCapacity(maxTokensInherited.value) })}
                  </span>
                </label>
              </div>
              <p className={css.hint}>{t('capacityHint')}</p>
            </fieldset>

            <fieldset className={css.group} disabled={disabled}>
              <legend>{t('enabledLevels')}</legend>
              <div className={css.levelGrid}>
                {THINKING_LEVELS.map(level => (
                  <label key={level} className={css.level}>
                    <input
                      type="checkbox"
                      checked={fields.levels.has(level)}
                      onChange={() => { toggleLevel(level) }}
                    />
                    <span>{t(levelKey(level))}</span>
                  </label>
                ))}
              </div>
            </fieldset>

            {active !== undefined && active.model.reasoningEfforts === false
              ? <p className={css.hint}>{t('disabled')}</p>
              : null}
            {snapshot.writable ? null : <p className={css.warning}>{t('readOnly')}</p>}
            {message === undefined ? null : (
              <p className={message.kind === 'success' ? css.success : css.error} role={message.kind === 'error' ? 'alert' : 'status'}>
                {message.text}
              </p>
            )}
            <div className={css.actions}>
              <button
                type="button"
                className={css.save}
                disabled={saving || !snapshot.writable || !dirty || draft === undefined}
                onClick={() => { void save() }}
              >
                {saving ? t('saving') : t('save')}
              </button>
            </div>
          </>
        )}
    </section>
  )
}
