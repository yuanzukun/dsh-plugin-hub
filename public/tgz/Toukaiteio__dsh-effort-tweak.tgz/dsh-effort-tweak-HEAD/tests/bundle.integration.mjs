import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const packagePath = resolve('package.json')
const clientPath = resolve('lib/client.js')
const hostPath = resolve('lib/index.js')
const manifest = JSON.parse(readFileSync(packagePath, 'utf8'))

if (manifest.name !== 'dsh-effort-tweak') throw new Error('Package name does not match the DSH module id.')
if (manifest.dsh?.bundle?.patch !== './cordis.patch.yml') throw new Error('Missing DSH bundle patch declaration.')
if (!existsSync(clientPath) || !existsSync(hostPath)) throw new Error('Expected bundle outputs were not built.')

const client = readFileSync(clientPath, 'utf8')
if (!client.includes('id: "dsh-effort-tweak"')) throw new Error('Client output is not wrapped for the DSH module loader.')
if (!client.includes('settings.section')) throw new Error('Client output does not register a settings section.')

/** Load the built CJS client through the loader shim the Web shell provides. */
function loadClient() {
  let loaded
  const window = { __ModuleLoader__: { load: (module) => { loaded = module } } }
  new Function('window', client)(window)
  if (loaded === undefined || loaded.id !== 'dsh-effort-tweak' || typeof loaded.factory !== 'function') {
    throw new Error('Client output does not expose the expected module loader shape.')
  }
  const shims = {
    'react': {
      useEffect() {},
      useMemo: (factory) => factory(),
      useState: (initial) => [initial, () => {}],
      useSyncExternalStore: (_subscribe, getSnapshot) => getSnapshot(),
    },
    'react/jsx-runtime': {
      jsx: (type, props) => ({ type, props }),
      jsxs: (type, props) => ({ type, props }),
      Fragment: 'fragment',
    },
  }
  return loaded.factory((id) => {
    const shim = shims[id]
    if (shim === undefined) throw new Error(`Client output requires an unexpected external module: ${id}`)
    return shim
  })
}

/** Apply the client half against a recording context and report what it contributed. */
function registerWithFakeContext(mod) {
  const registrations = []
  const ctx = {
    effect(factory) {
      return factory()
    },
    locale: {
      register() {
        return () => {}
      },
      bind: () => (key, params) => (params === undefined ? key : `${key}:${JSON.stringify(params)}`),
    },
    configForms: { get: (entryId) => ({ entryId }) },
    slots: {
      inject(name, factory) {
        return factory()
      },
      register(definition, component) {
        registrations.push({ definition, component })
        return () => {}
      },
    },
  }
  mod.apply(ctx)
  return registrations
}

const registrations = registerWithFakeContext(loadClient())
if (registrations.length !== 1) throw new Error(`Expected exactly one settings contribution, got ${registrations.length}.`)
const [{ definition, component }] = registrations
if (definition.name !== 'settings.section') throw new Error('Contribution is not a settings section.')
if (typeof definition.label !== 'function') throw new Error('Settings section is missing its localized label.')
if (definition.label() === '') throw new Error('Settings section label is empty.')
if (definition.locale !== 'dsh-effort-tweak') throw new Error('Settings section does not bind its locale namespace.')
if (typeof component !== 'function') throw new Error('Settings section has no component.')
if (typeof definition.inject !== 'function') throw new Error('Settings section does not inject its config form.')
const injected = definition.inject()
if (injected?.form?.entryId !== 'llm-pi-ai') throw new Error('Settings section does not bind the llm-pi-ai settings entry.')

/** Flatten a rendered element tree into the text this page would display. */
function textOf(node) {
  if (node === null || node === undefined || typeof node === 'boolean') return ''
  if (typeof node === 'string' || typeof node === 'number') return String(node)
  if (Array.isArray(node)) return node.map(textOf).join(' ')
  if (typeof node !== 'object') return ''
  if (typeof node.type === 'function') return textOf(node.type({ ...node.props, children: undefined }))
  return textOf(node.props?.children)
}

/** A ready settings snapshot holding one custom provider with two models. */
const snapshot = {
  status: 'ready',
  value: {
    providers: {
      custom: {
        displayName: 'Custom endpoint',
        defaultContextWindow: 262144,
        defaultMaxTokens: 32768,
        defaultInput: ['text'],
        models: [
          { id: 'vision-model', name: 'Vision model', contextWindow: 200000, maxTokens: 16384, input: ['text', 'image'], reasoningEfforts: { off: null, low: 'low', high: 'high' } },
          { id: 'chat-model', reasoningEfforts: false },
        ],
      },
    },
  },
  base: undefined,
  user: undefined,
  revision: 1,
  writable: true,
}
const readyForm = {
  getSnapshot: () => snapshot,
  subscribe: () => () => {},
  mutate: async () => true,
  set: async () => true,
  unset: async () => false,
}

const rendered = textOf(component({
  // Both copy shapes the page may use, so the assertion below holds for either dictionary.
  t: (key, params) => (params === undefined ? key : `${key}:${JSON.stringify(params)}`),
  form: readyForm,
}))
for (const expected of ['contextWindow', 'maxTokens', 'inputTypes', 'enabledLevels', 'input_text', 'input_image', 'level_max']) {
  if (!rendered.includes(expected)) throw new Error(`Rendered settings page is missing the ${expected} control.`)
}
if (!rendered.includes('vision-model')) throw new Error('Rendered settings page does not list the configured model.')
if (!rendered.includes('input_image') || !rendered.includes('input_text')) {
  throw new Error('Rendered settings page does not offer both input types.')
}

// A model that declares no capacities shows what each blank field would inherit.
const inheritingForm = {
  ...readyForm,
  getSnapshot: () => ({
    ...snapshot,
    value: {
      providers: {
        custom: {
          defaultContextWindow: 262144,
          defaultMaxTokens: 32768,
          defaultInput: ['text'],
          models: [{ id: 'bare-model', reasoningEfforts: false }],
        },
      },
    },
  }),
}
const inheriting = textOf(component({
  t: (key, params) => (params === undefined ? key : `${key}:${JSON.stringify(params)}`),
  form: inheritingForm,
}))
if (!inheriting.includes('inheritedRoute')) throw new Error('Rendered settings page does not show the inherited capacity hint.')
if (!inheriting.includes('262144')) throw new Error('Inherited capacity hint does not show the route context window.')
if (!inheriting.includes('32768')) throw new Error('Inherited capacity hint does not show the route output cap.')
if (!inheriting.includes('bare-model')) throw new Error('Rendered settings page does not list a model with no capacities.')

