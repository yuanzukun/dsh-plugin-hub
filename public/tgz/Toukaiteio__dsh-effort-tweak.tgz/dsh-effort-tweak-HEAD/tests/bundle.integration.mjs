import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'

const packagePath = resolve('package.json')
const clientPath = resolve('lib/client.js')
const hostPath = resolve('lib/index.js')
const manifest = JSON.parse(readFileSync(packagePath, 'utf8'))

if (manifest.name !== 'dsh-effort-tweak') throw new Error('Package name does not match the DSH module id.')
if (manifest.dsh?.bundle?.patch !== './cordis.patch.yml') throw new Error('Missing DSH bundle patch declaration.')
if (!existsSync(clientPath) || !existsSync(hostPath)) throw new Error('Expected bundle outputs were not built.')

const client = readFileSync(clientPath, 'utf8')
if (!client.includes('id: "dsh-effort-tweak"')) throw new Error('Client output is not wrapped for the DSH module loader.')
if (!client.includes('settings.section')) throw new Error('Client output does not register a settings section.')

