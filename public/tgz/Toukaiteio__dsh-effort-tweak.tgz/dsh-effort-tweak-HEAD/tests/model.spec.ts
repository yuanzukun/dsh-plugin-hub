import { describe, expect, it } from 'vitest'
import {
  DEFAULT_CONTEXT_WINDOW,
  DEFAULT_MAX_TOKENS,
  declaredInput,
  editableModels,
  formatCapacity,
  inheritedCapacity,
  inheritedInput,
  modelDraft,
  parseCapacity,
  parseDraft,
  reasoningEffortsFor,
  sameDraft,
  supportedLevels,
  updateModelConfig,
  updateModelEfforts,
} from '../src/model.js'
import { en, zh } from '../src/client/locales.js'

describe('interface localization', () => {
  it('keeps the English and Chinese dictionaries in lockstep', () => {
    expect(Object.keys(en).sort()).toEqual(Object.keys(zh).sort())
    expect(en.nav).not.toEqual('')
    expect(zh.nav).not.toEqual('')
  })

  it('localizes every input modality and reasoning level', () => {
    for (const key of Object.keys(en)) {
      expect(en[key as keyof typeof en]).not.toEqual('')
    }
  })
})

describe('capacity spelling', () => {
  it('reads counts, K, and M suffixes into plain token counts', () => {
    expect(parseCapacity('131072')).toEqual({ kind: 'value', value: 131072 })
    expect(parseCapacity('256K')).toEqual({ kind: 'value', value: 256_000 })
    expect(parseCapacity(' 1m ')).toEqual({ kind: 'value', value: 1_000_000 })
    expect(parseCapacity('1.5M')).toEqual({ kind: 'value', value: 1_500_000 })
  })

  it('separates an empty field from an unreadable one', () => {
    expect(parseCapacity('   ')).toEqual({ kind: 'inherit' })
    expect(parseCapacity('lots')).toEqual({ kind: 'invalid' })
    expect(parseCapacity('0')).toEqual({ kind: 'invalid' })
    expect(parseCapacity('-5')).toEqual({ kind: 'invalid' })
  })

  it('spells stored counts in the shortest round-tripping form', () => {
    expect(formatCapacity(1_000_000)).toEqual('1M')
    expect(formatCapacity(256_000)).toEqual('256K')
    expect(formatCapacity(262_144)).toEqual('262144')
    expect(parseCapacity(formatCapacity(262_144))).toEqual({ kind: 'value', value: 262_144 })
  })
})

describe('per-model reasoning effort configuration', () => {
  const providers = {
    custom: {
      displayName: 'Custom endpoint',
      defaultContextWindow: 262_144,
      defaultMaxTokens: 32_768,
      models: [
        {
          id: 'reasoning-model',
          name: 'Reasoning model',
          contextWindow: 128000,
          reasoningEfforts: { off: null, low: 'low', high: 'high' },
        },
        { id: 'chat-model', reasoningEfforts: false },
      ],
    },
    catalog: { baseURL: 'https://example.invalid' },
  }

  it('only exposes models configured in explicit provider model lists', () => {
    expect(editableModels(providers).map(item => `${item.provider}/${item.model.id}`)).toEqual([
      'custom/reasoning-model',
      'custom/chat-model',
    ])
  })

  it('exposes the route fallback each model inherits', () => {
    const [, inherited] = editableModels(providers)
    expect(inherited?.defaults).toEqual({
      contextWindow: 262_144,
      maxTokens: 32_768,
      input: undefined,
    })
    expect(DEFAULT_CONTEXT_WINDOW).toEqual(262_144)
    expect(DEFAULT_MAX_TOKENS).toEqual(32_768)
  })

  it('describes the value a blank capacity inherits, and which layer supplies it', () => {
    const [sized, unsized] = editableModels(providers)
    expect(sized === undefined ? undefined : inheritedCapacity(sized, 'contextWindow'))
      .toEqual({ value: 262_144, route: true })
    expect(unsized === undefined ? undefined : inheritedCapacity(unsized, 'maxTokens'))
      .toEqual({ value: 32_768, route: true })
    const bare = editableModels({ custom: { models: [{ id: 'm' }] } })[0]
    expect(bare === undefined ? undefined : inheritedCapacity(bare, 'contextWindow'))
      .toEqual({ value: DEFAULT_CONTEXT_WINDOW, route: false })
    expect(bare === undefined ? undefined : inheritedCapacity(bare, 'maxTokens'))
      .toEqual({ value: DEFAULT_MAX_TOKENS, route: false })
  })

  it('reports only the route-declared input fallback, since the catalog is not in this document', () => {
    const [declared, undeclared] = editableModels({
      custom: { defaultInput: ['text', 'image'], models: [{ id: 'a' }] },
      other: { models: [{ id: 'b' }] },
    })
    expect(declared === undefined ? 'missing' : inheritedInput(declared)).toEqual(['text', 'image'])
    expect(undeclared === undefined ? 'missing' : inheritedInput(undeclared)).toBeUndefined()
  })

  it('uses exactly the levels a model has declared', () => {
    const model = editableModels(providers)[0]?.model
    expect(model === undefined ? [] : supportedLevels(model)).toEqual(['off', 'low', 'high'])
  })

  it('preserves declared wire values and supplies a standard value for a new level', () => {
    expect(reasoningEffortsFor(new Set(['off', 'medium', 'high']), { off: null, high: 'provider-high' })).toEqual({
      off: null,
      medium: 'medium',
      high: 'provider-high',
    })
  })

  it('disables reasoning when no thinking level remains', () => {
    expect(reasoningEffortsFor(new Set(['off']), { off: null, low: 'low' })).toBe(false)
  })

  it('updates only the selected model and retains its other configuration', () => {
    const next = updateModelEfforts(providers, 'custom', 'reasoning-model', new Set(['minimal', 'high']))
    const model = editableModels(next).find(item => item.model.id === 'reasoning-model')?.model
    expect(model).toMatchObject({
      id: 'reasoning-model',
      name: 'Reasoning model',
      contextWindow: 128000,
      reasoningEfforts: { minimal: 'minimal', high: 'high' },
    })
    expect(editableModels(next).find(item => item.model.id === 'chat-model')?.model.reasoningEfforts).toBe(false)
  })
})

describe('per-model capacities and input types', () => {
  const providers = {
    custom: {
      defaultContextWindow: 262_144,
      defaultMaxTokens: 32_768,
      defaultInput: ['text', 'image'],
      models: [
        { id: 'sized', contextWindow: 128000, maxTokens: 8192, input: ['text'] },
        { id: 'unsized' },
      ],
    },
  }

  it('reads the capacities and modalities a model declares', () => {
    const model = editableModels(providers)[0]?.model
    expect(model === undefined ? undefined : modelDraft(model)).toEqual({
      levels: new Set(),
      contextWindow: 128000,
      maxTokens: 8192,
      input: ['text'],
    })
  })

  it('treats an empty or unknown declaration as inherited', () => {
    const model = editableModels(providers)[1]?.model
    expect(model === undefined ? undefined : modelDraft(model)).toEqual({
      levels: new Set(),
      contextWindow: undefined,
      maxTokens: undefined,
      input: undefined,
    })
    expect(declaredInput({ id: 'x', input: [] })).toBeUndefined()
    expect(declaredInput({ id: 'x', input: ['text', 'image'] })).toEqual(['text', 'image'])
  })

  it('writes capacities in canonical modality order and keeps unrelated fields', () => {
    const next = updateModelConfig(providers, 'custom', 'unsized', {
      levels: new Set(['low', 'high']),
      contextWindow: 1_000_000,
      maxTokens: 64_000,
      input: ['image', 'text'],
    })
    const model = editableModels(next).find(item => item.model.id === 'unsized')?.model
    expect(model).toMatchObject({
      id: 'unsized',
      contextWindow: 1_000_000,
      maxTokens: 64_000,
      input: ['text', 'image'],
      reasoningEfforts: { low: 'low', high: 'high' },
    })
    expect(editableModels(next).find(item => item.model.id === 'sized')?.model).toMatchObject({
      contextWindow: 128000,
      maxTokens: 8192,
      input: ['text'],
    })
  })

  it('removes a field the draft leaves inherited instead of copying the fallback', () => {
    const next = updateModelConfig(providers, 'custom', 'sized', {
      levels: new Set(['off', 'low']),
    })
    const model = editableModels(next).find(item => item.model.id === 'sized')?.model
    expect(model).toBeDefined()
    expect(model === undefined ? undefined : Object.hasOwn(model, 'contextWindow')).toBe(false)
    expect(model === undefined ? undefined : Object.hasOwn(model, 'maxTokens')).toBe(false)
    expect(model === undefined ? undefined : Object.hasOwn(model, 'input')).toBe(false)
    expect(model?.reasoningEfforts).toEqual({ off: null, low: 'low' })
  })

  it('compares drafts by value so an unchanged form is not dirty', () => {
    const model = editableModels(providers)[0]?.model
    expect(model === undefined ? false : sameDraft(modelDraft(model), modelDraft(model))).toBe(true)
    expect(sameDraft(
      { levels: new Set(), contextWindow: 128000, maxTokens: 8192, input: ['text'] },
      { levels: new Set(), contextWindow: 128000, maxTokens: 8192, input: ['text', 'image'] },
    )).toBe(false)
  })

  it('turns raw editor text into a draft or reports the offending field', () => {
    const ok = parseDraft({
      levels: new Set(['off', 'high']),
      contextWindow: '1M',
      maxTokens: '64K',
      input: new Set(['image']),
    })
    expect(ok).toEqual({
      kind: 'ok',
      draft: { levels: new Set(['off', 'high']), contextWindow: 1_000_000, maxTokens: 64_000, input: ['image'] },
    })
    expect(parseDraft({ levels: new Set(), contextWindow: 'nope', maxTokens: '', input: new Set() }))
      .toEqual({ kind: 'invalid', field: 'contextWindow' })
    expect(parseDraft({ levels: new Set(), contextWindow: '', maxTokens: 'nope', input: new Set() }))
      .toEqual({ kind: 'invalid', field: 'maxTokens' })
  })
})
