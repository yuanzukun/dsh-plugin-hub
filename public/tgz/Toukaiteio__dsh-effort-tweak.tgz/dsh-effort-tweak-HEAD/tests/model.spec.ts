import { describe, expect, it } from 'vitest'
import { editableModels, reasoningEffortsFor, supportedLevels, updateModelEfforts } from '../src/model.js'
import { en, zh } from '../src/client/locales.js'

describe('interface localization', () => {
  it('keeps the English and Chinese dictionaries in lockstep', () => {
    expect(Object.keys(en).sort()).toEqual(Object.keys(zh).sort())
    expect(en.nav).not.toEqual('')
    expect(zh.nav).not.toEqual('')
  })
})

describe('per-model reasoning effort configuration', () => {
  const providers = {
    custom: {
      displayName: 'Custom endpoint',
      models: [
        {
          id: 'reasoning-model',
          name: 'Reasoning model',
          contextWindow: 128000,
          reasoningEfforts: { off: null, low: 'low', high: 'high' },
        },
        { id: 'chat-model', reasoningEfforts: false },
      ],
    },
    catalog: { baseURL: 'https://example.invalid' },
  }

  it('only exposes models configured in explicit provider model lists', () => {
    expect(editableModels(providers).map(item => `${item.provider}/${item.model.id}`)).toEqual([
      'custom/reasoning-model',
      'custom/chat-model',
    ])
  })

  it('uses exactly the levels a model has declared', () => {
    const model = editableModels(providers)[0]?.model
    expect(model === undefined ? [] : supportedLevels(model)).toEqual(['off', 'low', 'high'])
  })

  it('preserves declared wire values and supplies a standard value for a new level', () => {
    expect(reasoningEffortsFor(new Set(['off', 'medium', 'high']), { off: null, high: 'provider-high' })).toEqual({
      off: null,
      medium: 'medium',
      high: 'provider-high',
    })
  })

  it('disables reasoning when no thinking level remains', () => {
    expect(reasoningEffortsFor(new Set(['off']), { off: null, low: 'low' })).toBe(false)
  })

  it('updates only the selected model and retains its other configuration', () => {
    const next = updateModelEfforts(providers, 'custom', 'reasoning-model', new Set(['minimal', 'high']))
    const model = editableModels(next).find(item => item.model.id === 'reasoning-model')?.model
    expect(model).toMatchObject({
      id: 'reasoning-model',
      name: 'Reasoning model',
      contextWindow: 128000,
      reasoningEfforts: { minimal: 'minimal', high: 'high' },
    })
    expect(editableModels(next).find(item => item.model.id === 'chat-model')?.model.reasoningEfforts).toBe(false)
  })
})
