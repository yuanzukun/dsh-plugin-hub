# DSH Effort Tweak

[English](README.md) | 中文

DSH Effort Tweak 为 DeepSeek Harness 自定义提供商中的每个模型增加一个轻量的“模型能力”设置页，用来集中设置输入类型、上下文窗口、最大输出和推理力度，解决这些字段必须手动编辑 `llm-pi-ai` 配置的问题。

## 功能

- 在 DSH Web UI 中增加“设置 → 模型能力”。
- 列出 `llm-pi-ai.providers.<提供商>.models` 中明确配置的模型。
- 同时编辑模型的四个字段：`input`（文本、图像）、`contextWindow`、`maxTokens` 与 `reasoningEfforts`。
- 逐个模型选择 `关闭`、`极低`、`低`、`中`、`高`、`很高` 或 `最高` 推理档位。
- 容量支持 `131072`、`256K`、`1M` 这类写法；留空表示继续继承，而不会把默认值复制进模型。
- 显示留空时会继承的提供商默认值（`defaultContextWindow`、`defaultMaxTokens`、`defaultInput`）。
- 保留模型的其他字段和已有的提供商自定义传输值。
- 通过 DSH 设置服务保存，不需要手动修改配置文件。

页面不会显示只有内置模型目录、没有显式 `models` 列表的提供商。请先在 DSH 官方“模型”页面中为自定义提供商添加模型，再打开本插件页面调整模型能力。

## 一键安装

### Windows PowerShell

```powershell
irm https://raw.githubusercontent.com/Toukaiteio/dsh-effort-tweak/main/scripts/Install-DshEffortTweak.ps1 | iex
```

安装到其他 Profile 且不自动启动 Web UI：

```powershell
$script = "$env:TEMP\Install-DshEffortTweak.ps1"
Invoke-WebRequest https://raw.githubusercontent.com/Toukaiteio/dsh-effort-tweak/main/scripts/Install-DshEffortTweak.ps1 -OutFile $script
& $script -Profile work -NoStart
```

### macOS 与 Linux

```bash
curl -fsSL https://raw.githubusercontent.com/Toukaiteio/dsh-effort-tweak/main/scripts/install-dsh-effort-tweak.sh | bash
```

安装到其他 Profile：

```bash
curl -fsSL https://raw.githubusercontent.com/Toukaiteio/dsh-effort-tweak/main/scripts/install-dsh-effort-tweak.sh -o install-dsh-effort-tweak.sh
bash install-dsh-effort-tweak.sh --profile work --no-start
```

脚本会下载最新 GitHub Release 压缩包；如果 GitHub 提供 SHA-256 摘要则会先校验，并将归档保留在 `DSH_HOME/plugin-archives/dsh-effort-tweak/` 以便后续解析依赖，然后通过 `dsh plugin` 安装。默认安装完成后启动 `web` Profile，使用 `--no-start` 或 `-NoStart` 可关闭自动启动。

## 本地开发

要求 Node.js 22.19 或更新版本，以及 pnpm 10。

```bash
pnpm install
pnpm check
pnpm pack --pack-destination artifacts
```

CI 会执行类型检查、单元测试、bundle 集成测试、构建，并上传插件压缩包。推送与版本号一致的标签（例如 `v0.1.0`）后，Release workflow 会自动创建 GitHub Release 并上传压缩包。

## 配置格式

插件编辑的是 `llm-pi-ai` 命名空间中的模型字段：

```yaml
providers:
  my-gateway:
    defaultContextWindow: 128000
    defaultMaxTokens: 8192
    defaultInput: [text]
    models:
      - id: my-reasoning-model
        contextWindow: 200000
        maxTokens: 16384
        input: [text, image]
        reasoningEfforts:
          off: null
          low: low
          high: high
```

- `input` 声明端点实际接受的输入类型。留空会移除该字段，由内置目录、再由提供商的 `defaultInput` 决定；`llm-pi-ai` 把空列表视作同一种“未声明”，因此本页面不会写入空列表。
- `contextWindow` 与 `maxTokens` 必须是正整数。留空会移除该字段，改用提供商的 `defaultContextWindow` 与 `defaultMaxTokens`，页面会把该值显示为继承提示。
- `reasoningEfforts` 决定 DSH 模型选择器能够提供哪些推理力度。已有档位会保留原来的传输值；新启用的档位会使用对应的标准名称初始化。

## 许可证

MIT，详见 [LICENSE](LICENSE)。
