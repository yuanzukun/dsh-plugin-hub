---
name: dsh-effort-tweak
description: Manage per-model input types, context window, maximum output, and reasoning effort for DeepSeek Harness custom providers through the Web UI.
---

# DSH Effort Tweak

Open **Settings → Model capabilities** to edit models explicitly configured under
`llm-pi-ai.providers.<provider>.models`.

For each model the page edits four fields and preserves every other provider and
model setting:

- `input` — the request modalities the endpoint accepts (text, image). Leaving
  every box unticked removes the field, so the installed catalog and then the
  provider's `defaultInput` decide.
- `contextWindow` — the maximum combined request and response context. Accepts
  `131072`, `256K`, or `1M`. Blank removes the field and inherits
  `defaultContextWindow`.
- `maxTokens` — the maximum output tokens, which `llm-pi-ai` also uses as this
  model's per-request default. Blank removes the field and inherits
  `defaultMaxTokens`.
- `reasoningEfforts` — the reasoning levels the endpoint accepts. At least one
  thinking level (`minimal` through `max`) is required to keep reasoning enabled;
  selecting only `off`, or no levels, stores `reasoningEfforts: false`.

Existing custom wire values are preserved. Newly enabled levels use their
canonical level spelling, suitable for OpenAI-compatible reasoning endpoints.
