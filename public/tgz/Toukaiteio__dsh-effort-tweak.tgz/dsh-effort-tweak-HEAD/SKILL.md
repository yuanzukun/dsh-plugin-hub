---
name: dsh-effort-tweak
description: Manage per-model reasoning effort capabilities for DeepSeek Harness custom providers through the Web UI.
---

# DSH Effort Tweak

Open **Settings → Reasoning effort** to edit models explicitly configured under
`llm-pi-ai.providers.<provider>.models`.

For each model, choose the reasoning levels its endpoint accepts. The plugin
writes the model's `reasoningEfforts` field only and preserves every other
provider and model setting.

- At least one thinking level (`minimal` through `max`) is required to keep
  reasoning enabled.
- Selecting only `off`, or no levels, stores `reasoningEfforts: false`.
- Existing custom wire values are preserved. Newly enabled levels use their
  canonical level spelling, suitable for OpenAI-compatible reasoning endpoints.

