import test from 'node:test'
import assert from 'node:assert/strict'
import {
  IDE_PATTERNS, EXE_NAME_MAP, NAME_ALIASES,
  isLikelyIdeExe, matchName, normalizeMatchText, normalizePath, pickExe, slugifyId, stripIconIndex,
} from '../lib.mjs'

test('normalizeMatchText 归一化连字符与空白', () => {
  assert.equal(normalizeMatchText('Visual-Studio-Code'), 'Visual Studio Code')
  assert.equal(normalizeMatchText('  sublime_text  3 '), 'sublime text 3')
})

test('Insiders 不会被误判为普通 VS Code', () => {
  assert.equal(matchName('Visual Studio Code - Insiders'), 'VS Code Insiders')
  assert.equal(matchName('Visual Studio Code Insiders'), 'VS Code Insiders')
  assert.equal(matchName('code-insiders'), 'VS Code Insiders')
  assert.equal(matchName('Visual Studio Code'), 'VS Code')
})

test('scoop/别名目录名可识别', () => {
  assert.equal(matchName('vscode'), 'VS Code')
  assert.equal(matchName('sublime-text'), 'Sublime Text')
  assert.equal(matchName('intellij-idea'), 'IntelliJ IDEA')
  assert.equal(matchName('android-studio'), 'Android Studio')
  assert.equal(matchName('VSCodium'), 'VSCodium')
})

test('新增 IDE 识别', () => {
  assert.equal(matchName('Android Studio Preview'), 'Android Studio')
  assert.equal(matchName('Eclipse IDE for Java Developers'), 'Eclipse')
  assert.equal(matchName('Visual Studio Community 2022'), 'Visual Studio')
  assert.equal(matchName('Visual Studio Build Tools 2022'), 'Visual Studio')
  assert.equal(matchName('Visual Studio Code'), 'VS Code')
})

test('VS 运行库/安装器不会被误判为 Visual Studio', () => {
  assert.equal(matchName('Microsoft Visual Studio 2010 Tools for Office Runtime (x64)'), null)
  assert.equal(matchName('Visual Studio Installer'), null)
})

test('系统与安装器 exe 不会被当作 IDE 主程序', () => {
  assert.equal(isLikelyIdeExe('C:\\Windows\\System32\\msiexec.exe', 'C:\\Windows'), false)
  assert.equal(isLikelyIdeExe('C:\\Windows\\System32\\msiexec.exe'), false)
  assert.equal(isLikelyIdeExe('C:\\App\\unins000.exe'), false)
  assert.equal(isLikelyIdeExe('C:\\Program Files\\Microsoft VS Code\\Code.exe'), true)
  assert.equal(isLikelyIdeExe('C:\\Windows\\System32\\notepad.exe'), false)
  assert.equal(isLikelyIdeExe('msiexec.exe /X{123}'), false)
})

test('matchName 对非字符串返回 null', () => {
  assert.equal(matchName(undefined), null)
  assert.equal(matchName(null), null)
  assert.equal(matchName(''), null)
  assert.equal(matchName('Notepad++'), null)
})

test('normalizePath 去掉引号与 %1', () => {
  assert.equal(normalizePath('"C:\\App\\Code.exe" "%1"'), 'C:\\App\\Code.exe')
  assert.equal(normalizePath('C:\\App\\Code.exe %1'), 'C:\\App\\Code.exe')
})

test('stripIconIndex 支持正负图标序号', () => {
  assert.equal(stripIconIndex('C:\\App\\Code.exe,0'), 'C:\\App\\Code.exe')
  assert.equal(stripIconIndex('C:\\App\\Code.exe,-12'), 'C:\\App\\Code.exe')
})

test('pickExe 优先已知主程序，其次 64 位', () => {
  assert.equal(pickExe(['unins000.exe', 'pycharm.exe', 'pycharm64.exe']), 'pycharm64.exe')
  assert.equal(pickExe(['Code.exe', 'unins000.exe']), 'Code.exe')
  assert.equal(pickExe([]), undefined)
})

test('slugifyId 生成稳定 id 并处理重名', () => {
  const used = {}
  assert.equal(slugifyId('VS Code', used), 'vs-code')
  assert.equal(slugifyId('VS Code', used), 'vs-code-2')
  assert.equal(slugifyId('资源管理器', used), '资源管理器')
})

test('字典覆盖度：patterns/maps 不包含空值', () => {
  for (const item of IDE_PATTERNS) {
    assert.ok(item.re instanceof RegExp)
    assert.equal(typeof item.name, 'string')
    assert.ok(item.name.length > 0)
  }
  for (const [exe, name] of Object.entries(EXE_NAME_MAP)) {
    assert.equal(typeof exe, 'string')
    assert.equal(typeof name, 'string')
  }
  for (const [alias, name] of Object.entries(NAME_ALIASES)) {
    assert.equal(typeof alias, 'string')
    assert.equal(typeof name, 'string')
  }
})
