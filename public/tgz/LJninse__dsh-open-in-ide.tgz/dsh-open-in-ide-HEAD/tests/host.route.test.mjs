import test from 'node:test'
import assert from 'node:assert/strict'
import { apply } from '../index.mjs'

const ENV_OUT = [
  'SystemRoot=C:\\Windows',
  'USERPROFILE=C:\\Users\\tester',
  'LOCALAPPDATA=C:\\Users\\tester\\AppData\\Local',
  'APPDATA=C:\\Users\\tester\\AppData\\Roaming',
  'PROGRAMFILES=C:\\Program Files',
  'PROGRAMFILES(X86)=C:\\Program Files (x86)',
  'PATH=C:\\Windows\\system32;C:\\Windows',
].join('\r\n')

function harness(prefs, cacheText = null) {
  let handler
  const written = {}
  const disposers = []
  const ctx = {
    subprocess: {
      resolveExecutable: async (command) => (typeof command === 'string' && command.includes('\\') ? command : command),
      spawn: (spec) => {
        const argv = Array.isArray(spec.argv) ? spec.argv : []
        const isEnv = argv.includes('/c') && argv.includes('set')
        return {
          pid: 42,
          done: Promise.resolve(),
          collected: {
            stdout: { readFrom: () => ({ text: isEnv ? ENV_OUT : '' }) },
            stderr: { readFrom: () => ({ text: '' }) },
          },
        }
      },
    },
    fs: {
      resolve: async (p) => ({ displayPath: String(p).replace(/^\.$/, 'F:/tmp') }),
      lstat: async (p) => {
        const path = p !== null && typeof p === 'object' && typeof p.displayPath === 'string' ? p.displayPath : String(p)
        if (path.endsWith('.dsh-open-in-ide-prefs.json') && prefs !== null) return { type: 'file' }
        if (path.endsWith('.dsh-open-in-ide-cache.json') && cacheText !== null) return { type: 'file' }
        return undefined
      },
      listDir: async () => [],
      readText: async (t) => {
        const path = t !== null && typeof t === 'object' && typeof t.displayPath === 'string' ? t.displayPath : String(t)
        if (path.endsWith('.dsh-open-in-ide-cache.json') && cacheText !== null) return cacheText
        return prefs === null ? '' : JSON.stringify(prefs)
      },
      writeText: async (t, text) => { written[String(t.displayPath || t)] = text },
    },
    webServer: {
      register: (spec) => {
        handler = spec.handler
        return () => { handler = undefined }
      },
    },
    get: () => ({ workspaceRoot: 'F:/tmp' }),
    effect: (fn) => {
      const dispose = fn()
      disposers.push(dispose)
      return typeof dispose === 'function' ? dispose : undefined
    },
  }
  apply(ctx)

  const call = async (method, body) => {
    const chunks = []
    const res = {
      statusCode: 0,
      headers: {},
      writeHead(status, headers) { this.statusCode = status; Object.assign(this.headers, headers) },
      end(text) { chunks.push(text) },
    }
    const req = body === undefined
      ? { method }
      : {
        method,
        on: (event, cb) => {
          if (event === 'data') cb(Buffer.from(JSON.stringify(body)))
          if (event === 'end') cb()
        },
      }
    await handler(req, res)
    return JSON.parse(chunks.join(''))
  }

  return { call, written, dispose: () => { for (const d of disposers) if (typeof d === 'function') d() } }
}

test('GET /open-in-ide 返回持久化自定义项并标记默认', async () => {
  const h = harness({
    v: 1,
    custom: [{ id: 'custom-1', name: '我的 IDE (自定义)', path: 'C:\\Tools\\MyIDE.exe', custom: true }],
    defaultId: 'custom-1',
    lastUsedId: '',
  })
  try {
    const res = await h.call('GET')
    assert.equal(res.length, 1)
    assert.equal(res[0].id, 'custom-1')
    assert.equal(res[0].custom, true)
    assert.equal(res[0].default, true)
  } finally {
    h.dispose()
  }
})

test('旧版检测缓存(v1)会被忽略，避免残留误检项', async () => {
  const h = harness(null, JSON.stringify({
    v: 1,
    scannedAt: Date.now(),
    items: [{ id: 'visual-studio', name: 'Visual Studio', path: 'C:\\Windows\\System32\\msiexec.exe', args: [], custom: false }],
  }))
  try {
    const res = await h.call('GET')
    assert.equal(res.length, 0)
  } finally {
    h.dispose()
  }
})

test('setDefault 拒绝未知 id', async () => {
  const h = harness(null)
  try {
    const res = await h.call('POST', { action: 'setDefault', id: 'nope' })
    assert.equal(res.ok, false)
  } finally {
    h.dispose()
  }
})

test('未知 action 返回 400', async () => {
  const h = harness(null)
  try {
    const res = await h.call('POST', { action: 'wat' })
    assert.equal(res.ok, false)
  } finally {
    h.dispose()
  }
})
