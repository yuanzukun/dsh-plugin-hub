/**
 * dsh-open-in-ide — 纯函数与检测字典。
 * 与 ctx/fs/subprocess 无关，宿主半直接复用，测试针对本模块编写。
 */

// 匹配前把 -/_ 归一化成空格，这样 "Visual-Studio-Code"、"sublime-text"
// 这类目录名/DisplayName 也能命中；别名表覆盖 scoop 等连写命名。
export const normalizeMatchText = (text) => String(text).replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim()

export const IDE_PATTERNS = [
  // 注意：Insiders 必须排在普通 VS Code 之前。
  { re: /\b(?:vs\s+|visual studio\s+)?code[\s-]*insiders\b/i, name: 'VS Code Insiders' },
  { re: /\b(?:vs\s+|visual studio\s+)?code\b/i, name: 'VS Code' },
  { re: /\bvscode\b/i, name: 'VS Code' },
  { re: /\bvscodium\b/i, name: 'VSCodium' },
  { re: /\bcursor\b/i, name: 'Cursor' },
  { re: /\bwindsurf\b/i, name: 'Windsurf' },
  { re: /\bzed\b/i, name: 'Zed' },
  { re: /\btrae\b/i, name: 'Trae' },
  { re: /\bintellij\s+idea\b/i, name: 'IntelliJ IDEA' },
  { re: /\bidea\b/i, name: 'IntelliJ IDEA' },
  { re: /\bandroid\s+studio\b/i, name: 'Android Studio' },
  { re: /\bpycharm\b/i, name: 'PyCharm' },
  { re: /\bwebstorm\b/i, name: 'WebStorm' },
  { re: /\bphpstorm\b/i, name: 'PhpStorm' },
  { re: /\bgoland\b/i, name: 'GoLand' },
  { re: /\bclion\b/i, name: 'CLion' },
  { re: /\brider\b/i, name: 'Rider' },
  { re: /\bdatagrip\b/i, name: 'DataGrip' },
  { re: /\brubymine\b/i, name: 'RubyMine' },
  { re: /\brustrover\b/i, name: 'RustRover' },
  { re: /\baqua\b/i, name: 'Aqua' },
  { re: /\bwriterside\b/i, name: 'Writerside' },
  { re: /\bfleet\b/i, name: 'Fleet' },
  { re: /\bsublime\s*text\b/i, name: 'Sublime Text' },
  { re: /\beclipse\s+ide\b/i, name: 'Eclipse' },
  { re: /\bvisual studio\b(?!\s*code\b|\s+installer\b|\s+\d{4}\s+tools\b)(?=\s+(?:\d{4}|community|professional|enterprise|build\s+tools|preview)\b)/i, name: 'Visual Studio' },
]

// 连字符/别名目录名（scoop、便携版目录）单独兜底。
export const NAME_ALIASES = {
  'vscode': 'VS Code',
  'vscode insiders': 'VS Code Insiders',
  'code insiders': 'VS Code Insiders',
  'vscodium': 'VSCodium',
  'codium': 'VSCodium',
  'intellij': 'IntelliJ IDEA',
  'idea': 'IntelliJ IDEA',
  'androidstudio': 'Android Studio',
  'studio': 'Android Studio',
  'subl': 'Sublime Text',
}

export const matchName = (text) => {
  if (typeof text !== 'string') return null
  const t = normalizeMatchText(text)
  if (t === '') return null
  for (let i = 0; i < IDE_PATTERNS.length; i += 1) {
    if (IDE_PATTERNS[i].re.test(t)) return IDE_PATTERNS[i].name
  }
  const alias = NAME_ALIASES[t.toLowerCase()]
  return alias === undefined ? null : alias
}

export const EXE_NAME_MAP = {
  'code.exe': 'VS Code',
  'code - insiders.exe': 'VS Code Insiders',
  'cursor.exe': 'Cursor',
  'windsurf.exe': 'Windsurf',
  'zed.exe': 'Zed',
  'trae.exe': 'Trae',
  'trae cn.exe': 'Trae',
  'vscodium.exe': 'VSCodium',
  'eclipse.exe': 'Eclipse',
  'devenv.exe': 'Visual Studio',
  'subl.exe': 'Sublime Text',
  'sublime_text.exe': 'Sublime Text',
  'idea64.exe': 'IntelliJ IDEA',
  'idea.exe': 'IntelliJ IDEA',
  'studio64.exe': 'Android Studio',
  'studio.exe': 'Android Studio',
  'pycharm64.exe': 'PyCharm',
  'pycharm.exe': 'PyCharm',
  'webstorm64.exe': 'WebStorm',
  'webstorm.exe': 'WebStorm',
  'phpstorm64.exe': 'PhpStorm',
  'phpstorm.exe': 'PhpStorm',
  'goland64.exe': 'GoLand',
  'goland.exe': 'GoLand',
  'clion64.exe': 'CLion',
  'clion.exe': 'CLion',
  'rider64.exe': 'Rider',
  'rider.exe': 'Rider',
  'datagrip64.exe': 'DataGrip',
  'datagrip.exe': 'DataGrip',
  'rubymine64.exe': 'RubyMine',
  'rubymine.exe': 'RubyMine',
  'rustrover64.exe': 'RustRover',
  'rustrover.exe': 'RustRover',
  'aqua64.exe': 'Aqua',
  'aqua.exe': 'Aqua',
  'fleet.exe': 'Fleet',
  'writerside64.exe': 'Writerside',
  'writerside.exe': 'Writerside',
}

export const ROOT_EXE = {
  'VS Code': 'Code.exe',
  'VS Code Insiders': 'Code - Insiders.exe',
  Cursor: 'Cursor.exe',
  Windsurf: 'Windsurf.exe',
  Zed: 'Zed.exe',
  Trae: 'Trae.exe',
  VSCodium: 'VSCodium.exe',
  'Android Studio': 'bin\\studio64.exe',
  Eclipse: 'eclipse.exe',
  'Visual Studio': 'Common7\\IDE\\devenv.exe',
}

export const TOOLBOX_NAMES = {
  'IDEA-U': 'IntelliJ IDEA Ultimate',
  'IDEA-C': 'IntelliJ IDEA Community',
  ideaIU: 'IntelliJ IDEA Ultimate',
  ideaIC: 'IntelliJ IDEA Community',
  'PyCharm-P': 'PyCharm Professional',
  'PyCharm-C': 'PyCharm Community',
  pycharmPC: 'PyCharm Professional',
  pycharmCE: 'PyCharm Community',
  WebStorm: 'WebStorm',
  PhpStorm: 'PhpStorm',
  GoLand: 'GoLand',
  CLion: 'CLion',
  Rider: 'Rider',
  DataGrip: 'DataGrip',
  RubyMine: 'RubyMine',
  RustRover: 'RustRover',
  Aqua: 'Aqua',
  Fleet: 'Fleet',
  Writerside: 'Writerside',
  studio: 'Android Studio',
}

export const ORDER = {
  'VS Code': 0,
  'VS Code Insiders': 1,
  Cursor: 2,
  Windsurf: 3,
  Zed: 4,
  Trae: 5,
  VSCodium: 6,
  'Android Studio': 35,
  Eclipse: 38,
  'Visual Studio': 39,
  'Sublime Text': 40,
  '资源管理器': 80,
}

// 选择 bin 目录里的“主程序” exe：优先已知主程序名，其次带 64，最后按名字长度。
export const pickExe = (files) => {
  const exes = files.filter((n) => /\.exe$/i.test(n))
  if (exes.length === 0) return undefined
  const known = exes.filter((n) => EXE_NAME_MAP[n.toLowerCase()] !== undefined)
  const pool = known.length > 0 ? known : exes
  pool.sort((a, b) => {
    const a64 = /64/i.test(a) ? 0 : 1
    const b64 = /64/i.test(b) ? 0 : 1
    return a64 - b64 || a.length - b.length || (a < b ? -1 : a > b ? 1 : 0)
  })
  return pool[0]
}

// 去掉引号、可选的 "%1" 占位参数，得到干净的路径。
export const normalizePath = (s) => {
  if (typeof s !== 'string') return ''
  let p = s.trim().replace(/"/g, '')
  p = p.replace(/\s*"%1"\s*$/i, '').replace(/\s*%1\s*$/i, '')
  return p
}


// Windows 自带/安装器进程即使出现在 DisplayIcon/UninstallString 中，也不是 IDE 主程序；
// 避免把 “Visual Studio Tools for Office” 等运行库的 msiexec.exe 当成 VS 可执行文件。
export const EXE_BLOCKLIST = new Set([
  'msiexec.exe', 'msiexec', 'misexec.exe',
  'unins000.exe', 'unins001.exe', 'uninstall.exe', 'uninst.exe', 'uninstaller.exe',
  'setup.exe', 'install.exe', 'installer.exe',
  'cmd.exe', 'powershell.exe', 'pwsh.exe', 'wscript.exe', 'cscript.exe',
  'rundll32.exe', 'regsvr32.exe', 'svchost.exe', 'conhost.exe', 'mshta.exe',
  'taskmgr.exe', 'regedit.exe', 'notepad.exe', 'explorer.exe',
])

export const isLikelyIdeExe = (path, systemRoot) => {
  if (typeof path !== 'string') return false
  const p = normalizePath(path).replace(/\//g, '\\')
  if (!/\.exe$/i.test(p)) return false
  const leaf = p.split('\\').pop().toLowerCase()
  if (EXE_BLOCKLIST.has(leaf)) return false
  const sys = typeof systemRoot === 'string' ? systemRoot.trim().replace(/\//g, '\\').replace(/\\+$/, '') : ''
  if (sys !== '' && p.toLowerCase().startsWith(sys.toLowerCase() + '\\')) return false
  return true
}

export const stripIconIndex = (s) => s.replace(/,\s*-?\d+\s*$/i, '')

// 由显示名生成稳定 id；同一次扫描/列表内的重名用 -2、-3 递增。
export const slugifyId = (name, used) => {
  const base0 = String(name).toLowerCase().replace(/[^a-z0-9\u4e00-\u9fff]+/g, '-').replace(/^-+|-+$/g, '')
  const base = base0 === '' ? 'ide' : base0
  let id = base
  let n = 2
  while (used[id] === true) { id = base + '-' + n; n += 1 }
  used[id] = true
  return id
}
