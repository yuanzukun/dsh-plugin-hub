/**
 * dsh-open-in-ide — 浏览器半插件（client bundle）。
 * 装载信封：window.__ModuleLoader__.load({id, factory})；factory 在模块被
 * 首次 require/import 时物化一次，返回 { name, inject, apply }。
 * UI 注册进 conversation.session.header.utilities（会话头部右上角），
 * 数据经同源 fetch 调 /open-in-ide（宿主半自建路由）。
 *
 * 检测结果缓存为模块级共享数据；菜单位置、状态提示、busy 标记等 UI 状态
 * 则保持为每个按钮实例独立。文案走 DSH locale（open-in-ide 命名空间）。
 */
window.__ModuleLoader__.load({
  id: 'dsh-open-in-ide',
  factory: (require) => {
    const React = require('react')
    const module = { exports: {} }
    const exports = module.exports

    const LOCALE_NS = 'open-in-ide'
    const DICTIONARIES = {
      zh: {
        'label.open': '在 IDE 中打开',
        'button.titleEmpty': '当前会话没有工作区目录',
        'button.titleOpen': '用 IDE 打开当前工作区目录',
        'button.titleOpenDirect': '用 {name} 打开当前工作区目录（右键或点 ▾ 选择其它）',
        'button.titleCaret': '更多 IDE 选项',
        'menu.scanning': '正在检测本机已安装的 IDE…',
        'menu.empty': '未自动检测到 IDE。可点击下方按钮选择程序手动添加，或点击「重新检测」再次扫描。',
        'menu.refresh': '重新检测',
        'menu.refreshRunning': '检测中…',
        'menu.pick': '选择 IDE 程序…',
        'menu.picking': '正在打开选择窗口…',
        'menu.hint': '未找到想要的 IDE？可点击「选择 IDE 程序…」手动添加任意 .exe。',
        'item.defaultBadge': '默认',
        'item.lastUsedBadge': '上次',
        'item.setDefaultTitle': '设为默认 IDE',
        'item.clearDefaultTitle': '取消默认',
        'item.removeTitle': '删除自定义项',
        'status.opened': '已在 {name} 中打开',
        'status.openFailed': '打开失败',
        'status.openError': '打开失败: {message}',
        'status.added': '已添加: {name}',
        'status.addFailed': '添加失败',
        'status.pickFailed': '选择失败: {message}',
        'status.removed': '已删除: {name}',
        'status.removeFailed': '删除失败: {message}',
        'status.defaultSet': '已设为默认: {name}',
        'status.defaultCleared': '已取消默认',
        'status.defaultFailed': '设置默认失败: {message}',
        'error.detect': '检测失败: {message}',
        'error.refresh': '重新检测失败: {message}',
        'error.invalidRefresh': '重新检测未返回有效结果',
      },
      en: {
        'label.open': 'Open in IDE',
        'button.titleEmpty': 'No workspace directory for this session',
        'button.titleOpen': 'Open current workspace in IDE',
        'button.titleOpenDirect': 'Open current workspace in {name} (right-click or ▾ for others)',
        'button.titleCaret': 'More IDE options',
        'menu.scanning': 'Detecting installed IDEs…',
        'menu.empty': 'No IDE detected. Pick an executable below, or run detection again.',
        'menu.refresh': 'Rescan',
        'menu.refreshRunning': 'Scanning…',
        'menu.pick': 'Choose IDE program…',
        'menu.picking': 'Opening chooser…',
        'menu.hint': 'Can\'t find your IDE? Use “Choose IDE program…” to add any .exe manually.',
        'item.defaultBadge': 'Default',
        'item.lastUsedBadge': 'Last used',
        'item.setDefaultTitle': 'Set as default IDE',
        'item.clearDefaultTitle': 'Clear default',
        'item.removeTitle': 'Remove custom entry',
        'status.opened': 'Opened in {name}',
        'status.openFailed': 'Open failed',
        'status.openError': 'Open failed: {message}',
        'status.added': 'Added: {name}',
        'status.addFailed': 'Add failed',
        'status.pickFailed': 'Pick failed: {message}',
        'status.removed': 'Removed: {name}',
        'status.removeFailed': 'Remove failed: {message}',
        'status.defaultSet': 'Default set: {name}',
        'status.defaultCleared': 'Default cleared',
        'status.defaultFailed': 'Set default failed: {message}',
        'error.detect': 'Detection failed: {message}',
        'error.refresh': 'Rescan failed: {message}',
        'error.invalidRefresh': 'Rescan returned no valid result',
      },
    }

    const fallbackT = (key, vars) => {
      let text = DICTIONARIES.zh[key] !== undefined ? DICTIONARIES.zh[key] : key
      if (vars !== null && typeof vars === 'object') {
        for (const [name, value] of Object.entries(vars)) text = text.replace('{' + name + '}', String(value))
      }
      return text
    }

    // —— 插件自身样式（物化时注入，模块装载器自动认领 data-plugin） ——
    const CSS =
      '.dsh-ide-wrap{position:relative;display:inline-flex;align-items:center;gap:6px}' +
      '.dsh-ide-split{display:inline-flex;align-items:center}' +
      '.dsh-ide-btn{display:inline-flex;align-items:center;justify-content:center;gap:5px;height:26px;padding:0 9px;border-radius:7px;border:1px solid var(--dsw-alias-border-l1);background:transparent;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1;cursor:pointer}' +
      '.dsh-ide-btn-main{border-top-right-radius:0;border-bottom-right-radius:0;border-right:0;padding-right:8px}' +
      '.dsh-ide-btn-caret{min-width:22px;padding:0 5px;border-top-left-radius:0;border-bottom-left-radius:0}' +
      '.dsh-ide-btn:hover:not(:disabled){color:var(--dsw-alias-label-primary);border-color:var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-2)}' +
      '.dsh-ide-btn:disabled{opacity:.45;cursor:default}' +
      '.dsh-ide-ico{display:inline-flex;align-items:center}' +
      '.dsh-ide-menu{position:fixed;z-index:400;display:flex;flex-direction:column;padding:5px;border-radius:10px;border:1px solid var(--dsw-alias-border-l1);background:var(--dsw-alias-bg-overlay);box-shadow:0 12px 32px rgba(0,0,0,.28);max-height:64vh;overflow-y:auto}' +
      '.dsh-ide-menu:focus{outline:none}' +
      '.dsh-ide-dir{padding:7px 9px 5px;font-size:11px;color:var(--dsw-alias-label-secondary);word-break:break-all;border-bottom:1px solid var(--dsw-alias-border-l1);margin-bottom:4px}' +
      '.dsh-ide-item-row{display:flex;align-items:stretch;gap:2px;width:100%}' +
      '.dsh-ide-item{display:flex;flex:1;min-width:0;flex-direction:column;align-items:flex-start;gap:1px;width:100%;padding:7px 9px;border:0;border-radius:7px;background:transparent;text-align:left;cursor:pointer}' +
      '.dsh-ide-item:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2)}' +
      '.dsh-ide-item:disabled{opacity:.55;cursor:default}' +
      '.dsh-ide-item-name{display:flex;align-items:center;gap:6px;font-size:12.5px;color:var(--dsw-alias-label-primary);white-space:nowrap;overflow:hidden;max-width:100%}' +
      '.dsh-ide-item-badge{flex:none;font-size:9.5px;line-height:1;padding:2px 4px;border-radius:4px;color:var(--dsw-alias-brand-primary);background:rgba(96,140,255,.16);background:color-mix(in srgb,var(--dsw-alias-brand-primary) 14%,transparent)}' +
      '.dsh-ide-item-path{font-size:10.5px;color:var(--dsw-alias-label-secondary);word-break:break-all}' +
      '.dsh-ide-item-actions{display:flex;flex:none;align-items:center;gap:1px;padding-right:5px}' +
      '.dsh-ide-action{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;margin:auto 0;padding:0;border:0;border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:1;cursor:pointer}' +
      '.dsh-ide-action:hover:not(:disabled){background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary)}' +
      '.dsh-ide-action:disabled{opacity:.4;cursor:default}' +
      '.dsh-ide-action-active{color:var(--dsw-alias-brand-primary)}' +
      '.dsh-ide-note{padding:9px;font-size:12px;color:var(--dsw-alias-label-secondary)}' +
      '.dsh-ide-note-error{color:var(--dsw-alias-state-error-primary)}' +
      '.dsh-ide-refresh{margin-top:2px;padding:6px 9px;border:0;border-top:1px solid var(--dsw-alias-border-l1);background:transparent;color:var(--dsw-alias-brand-primary);font-size:11.5px;cursor:pointer}' +
      '.dsh-ide-refresh:hover:not(:disabled){opacity:.8}' +
      '.dsh-ide-refresh:disabled{opacity:.45;cursor:default}' +
      '.dsh-ide-add{padding:8px 9px 4px;border-top:1px solid var(--dsw-alias-border-l1)}' +
      '.dsh-ide-pick-btn{width:100%;height:26px;border:1px solid var(--dsw-alias-border-l1);border-radius:6px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-brand-primary);font-size:12px;cursor:pointer}' +
      '.dsh-ide-pick-btn:hover:not(:disabled){border-color:var(--dsw-alias-brand-primary)}' +
      '.dsh-ide-pick-btn:disabled{opacity:.5;cursor:default}' +
      '.dsh-ide-hint{padding:4px 9px 6px;font-size:10.5px;color:var(--dsw-alias-label-secondary)}' +
      '.dsh-ide-status{font-size:11px;color:var(--dsw-alias-state-success-primary);max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}' +
      '.dsh-ide-status-err{color:var(--dsw-alias-state-error-primary)}'
    const styleEl = document.createElement('style')
    styleEl.textContent = CSS
    document.head.appendChild(styleEl)

    // —— 同源 RPC：宿主半的 /open-in-ide 路由 ——
    const ROUTE_PATH = '/open-in-ide'
    const rpc = async (action, payload) => {
      const res = await fetch(ROUTE_PATH, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(Object.assign({ action: action }, payload === undefined ? {} : payload)),
      })
      if (!res.ok) {
        let text = ''
        try { text = await res.text() } catch (e) { /* keep going */ }
        throw new Error('HTTP ' + res.status + (text === '' ? '' : ' ' + text))
      }
      return res.json()
    }

    const errorText = (e) => String((e !== null && typeof e === 'object' && e.message) || e)

    // —— 共享数据：检测结果列表（所有按钮实例共用） ——
    const itemsStore = { items: null, loading: false, error: null, seq: 0, pending: null }
    const itemsListeners = new Set()
    const itemsPatch = (next) => {
      Object.assign(itemsStore, next)
      itemsListeners.forEach((l) => l())
    }

    // 使进行中的 load/refresh 响应作废，并清掉共享 pending，
    // 这样下一次 ensure/load 会发起新请求而不是复用已作废的响应。
    const bumpSeq = () => {
      const seq = ++itemsStore.seq
      itemsStore.pending = null
      itemsPatch({ loading: false })
      return seq
    }

    const load = () => {
      if (itemsStore.pending !== null) return itemsStore.pending
      // loading 为真但无 pending：refresh 正在跑，不要另起 list 请求抢走它的 seq。
      if (itemsStore.loading) return null
      itemsStore.loading = true
      const seq = ++itemsStore.seq
      itemsPatch({ error: null })
      const p = rpc('list').then(
        (list) => {
          if (seq !== itemsStore.seq) return null
          if (itemsStore.pending === p) itemsStore.pending = null
          itemsStore.loading = false
          itemsPatch({ items: Array.isArray(list) ? list : [], error: null })
          return itemsStore.items
        },
        (e) => {
          if (seq !== itemsStore.seq) return null
          if (itemsStore.pending === p) itemsStore.pending = null
          itemsStore.loading = false
          itemsPatch({ items: [], error: { key: 'error.detect', message: errorText(e) } })
          return null
        },
      )
      itemsStore.pending = p
      return p
    }

    const findDefault = (items) => {
      if (!Array.isArray(items)) return null
      for (const item of items) {
        if (item !== null && typeof item === 'object' && item.default === true && typeof item.id === 'string' && item.id !== '' && typeof item.name === 'string' && item.name !== '') return item
      }
      return null
    }

    const refresh = () => {
      itemsStore.pending = null
      const seq = ++itemsStore.seq
      itemsStore.loading = true
      itemsPatch({ items: null, error: null })
      return rpc('refresh').then(
        (res) => {
          if (seq !== itemsStore.seq) return null
          itemsStore.loading = false
          if (res !== null && typeof res === 'object' && Array.isArray(res.items)) {
            itemsPatch({ items: res.items, error: null })
          } else {
            itemsPatch({ items: [], error: { key: 'error.invalidRefresh', message: '' } })
          }
          return itemsStore.items
        },
        (e) => {
          if (seq !== itemsStore.seq) return null
          itemsStore.loading = false
          itemsPatch({ items: [], error: { key: 'error.refresh', message: errorText(e) } })
          return null
        },
      )
    }

    const useIdeItems = () => {
      const [, force] = React.useState(0)
      React.useEffect(() => {
        const l = () => { force((x) => x + 1) }
        itemsListeners.add(l)
        return () => { itemsListeners.delete(l) }
      }, [])
      return itemsStore
    }

    function IdeMenuButton(props) {
      const ide = useIdeItems()
      const t = typeof props.t === 'function' ? props.t : fallbackT
      const [pos, setPos] = React.useState(null)
      const [status, setStatus] = React.useState(null)
      const [busyId, setBusyId] = React.useState(null)
      const [busyAction, setBusyAction] = React.useState(null)
      const [picking, setPicking] = React.useState(false)
      const rootRef = React.useRef(null)
      const menuRef = React.useRef(null)
      const openingRef = React.useRef(false)
      const statusTimer = React.useRef(null)
      const menuId = React.useId()

      const flash = React.useCallback((next) => {
        setStatus(next)
        if (statusTimer.current !== null) clearTimeout(statusTimer.current)
        statusTimer.current = setTimeout(() => { setStatus(null) }, 4000)
      }, [])

      React.useEffect(() => () => {
        if (statusTimer.current !== null) clearTimeout(statusTimer.current)
      }, [])

      // 点击菜单外部、窗口尺寸变化或滚动时关闭菜单。
      React.useEffect(() => {
        if (pos === null) return
        const close = () => { setPos(null) }
        const onPointerDown = (e) => {
          if (rootRef.current !== null && !rootRef.current.contains(e.target)) close()
        }
        window.addEventListener('pointerdown', onPointerDown, true)
        window.addEventListener('resize', close)
        // 只监听页面级滚动；菜单内部滚动（overflow-y:auto）不应关闭菜单。
        window.addEventListener('scroll', close, false)
        return () => {
          window.removeEventListener('pointerdown', onPointerDown, true)
          window.removeEventListener('resize', close)
          window.removeEventListener('scroll', close, false)
        }
      }, [pos])

      const sessionCwd = props.useSessions((s) => {
        const row = s !== null && typeof s === 'object' && s.byId !== null && typeof s.byId === 'object' ? s.byId[props.sessionId] : undefined
        return row === undefined ? undefined : row.cwd
      })
      const workspacePath = props.useWorkspaces((s) => {
        const items = s !== null && typeof s === 'object' && Array.isArray(s.items) ? s.items : []
        const w = items.find((x) => (Array.isArray(x.sessionIds) ? x.sessionIds : []).includes(props.sessionId))
        return w === undefined ? undefined : w.path
      })
      const dir = typeof sessionCwd === 'string' && sessionCwd !== '' ? sessionCwd : (typeof workspacePath === 'string' && workspacePath !== '' ? workspacePath : '')

      const placeMenu = () => {
        if (rootRef.current === null) return
        const r = rootRef.current.getBoundingClientRect()
        const margin = 8
        const width = 280
        const maxHeight = Math.max(180, Math.min(window.innerHeight - margin * 2, 480))
        let left = Math.max(margin, r.right - width)
        if (left + width > window.innerWidth || window.innerWidth < width + margin * 2) left = Math.max(margin, window.innerWidth - width - margin)
        let top = r.bottom + 6
        if (top + maxHeight > window.innerHeight - margin) top = Math.max(margin, window.innerHeight - margin - maxHeight)
        setPos({ top: top, left: left, maxHeight: maxHeight })
      }

      const showMenu = () => {
        placeMenu()
        if (ide.items === null && !ide.loading) load()
      }

      const toggleMenu = () => {
        if (pos !== null) { setPos(null); return }
        showMenu()
      }

      const applyItems = (res) => {
        if (res !== null && typeof res === 'object' && Array.isArray(res.items)) itemsPatch({ items: res.items, error: null })
      }

      const choose = async (item) => {
        if (openingRef.current) return
        openingRef.current = true
        setPos(null)
        setStatus(null)
        setBusyId(item.id)
        const seq = bumpSeq()
        try {
          const res = await rpc('open', { id: item.id, dir: dir })
          if (res !== null && typeof res === 'object' && res.ok === true) {
            if (seq === itemsStore.seq) applyItems(res)
            flash({ kind: 'ok', text: t('status.opened', { name: res.name }) })
          } else {
            flash({ kind: 'err', text: res !== null && typeof res === 'object' && typeof res.error === 'string' ? res.error : t('status.openFailed') })
          }
        } catch (e) {
          flash({ kind: 'err', text: t('status.openError', { message: errorText(e) }) })
        } finally {
          openingRef.current = false
          setBusyId(null)
          if (seq === itemsStore.seq && itemsStore.items === null && !itemsStore.loading) load()
        }
      }

      // 主按钮：有默认（★）时单击直接打开；列表尚未就绪时先拉取再决定，
      // 拉到默认直接打开，没有默认则自动展开菜单。
      const handleMainClick = () => {
        if (dir === '') return
        // 菜单展开时再点主按钮 = 收起菜单，避免想关菜单却误开默认 IDE。
        if (pos !== null) { setPos(null); return }
        const direct = findDefault(ide.items)
        if (direct !== null) {
          choose(direct)
          return
        }
        if (ide.items === null) {
          setPos(null)
          const p = load()
          if (p !== null) {
            p.then((items) => {
              const d = findDefault(items)
              if (d !== null) choose(d)
              else placeMenu()
            })
          } else {
            // refresh 正在跑：展开菜单显示“检测中…”，结果到了会直接出现在菜单里。
            placeMenu()
          }
          return
        }
        toggleMenu()
      }

      const pickExeFile = async () => {
        if (picking) return
        setPicking(true)
        // 让进行中的 load/refresh 响应作废，避免旧列表覆盖刚添加的自定义项；
        // bumpSeq 同时复位 loading，否则被作废的回调不会清位，会导致“检测中…”永久卡住。
        const seq = bumpSeq()
        try {
          const res = await rpc('pickAndAdd')
          if (res !== null && typeof res === 'object') {
            if (res.canceled === true) {
              if (seq === itemsStore.seq && itemsStore.items === null && !itemsStore.loading) load()
              return
            }
            if (res.ok === true) {
              if (seq === itemsStore.seq) applyItems(res)
              flash({ kind: 'ok', text: t('status.added', { name: res.name }) })
            } else {
              flash({ kind: 'err', text: typeof res.error === 'string' ? res.error : t('status.addFailed') })
            }
          }
        } catch (e) {
          flash({ kind: 'err', text: t('status.pickFailed', { message: errorText(e) }) })
        } finally {
          setPicking(false)
          if (seq === itemsStore.seq && itemsStore.items === null && !itemsStore.loading) load()
        }
      }

      const setDefault = async (item) => {
        setBusyAction('default:' + item.id)
        const seq = bumpSeq()
        try {
          const res = await rpc('setDefault', { id: item.default === true ? '' : item.id })
          if (res !== null && typeof res === 'object' && res.ok === true) {
            if (seq === itemsStore.seq) applyItems(res)
            flash({ kind: 'ok', text: item.default === true ? t('status.defaultCleared') : t('status.defaultSet', { name: item.name }) })
          } else {
            flash({ kind: 'err', text: res !== null && typeof res === 'object' && typeof res.error === 'string' ? res.error : t('status.defaultFailed', { message: '' }) })
          }
        } catch (e) {
          flash({ kind: 'err', text: t('status.defaultFailed', { message: errorText(e) }) })
        } finally {
          setBusyAction(null)
          if (seq === itemsStore.seq && itemsStore.items === null && !itemsStore.loading) load()
        }
      }

      const removeItem = async (item) => {
        setBusyAction('remove:' + item.id)
        const seq = bumpSeq()
        try {
          const res = await rpc('removeCustom', { id: item.id })
          if (res !== null && typeof res === 'object' && res.ok === true) {
            if (seq === itemsStore.seq) applyItems(res)
            flash({ kind: 'ok', text: t('status.removed', { name: res.name }) })
          } else {
            flash({ kind: 'err', text: res !== null && typeof res === 'object' && typeof res.error === 'string' ? res.error : t('status.removeFailed', { message: '' }) })
          }
        } catch (e) {
          flash({ kind: 'err', text: t('status.removeFailed', { message: errorText(e) }) })
        } finally {
          setBusyAction(null)
          if (seq === itemsStore.seq && itemsStore.items === null && !itemsStore.loading) load()
        }
      }

      const focusItem = (delta) => {
        if (menuRef.current === null) return
        const items = menuRef.current.querySelectorAll('[role="menuitem"]')
        if (items.length === 0) return
        const idx = Array.prototype.indexOf.call(items, document.activeElement)
        let next
        if (idx < 0) next = delta > 0 ? 0 : items.length - 1
        else next = idx + delta
        if (next < 0) next = items.length - 1
        if (next >= items.length) next = 0
        items[next].focus()
      }

      const onKeyDown = (e) => {
        if (e.key === 'Escape') { setPos(null); return }
        if (pos !== null && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
          e.preventDefault()
          focusItem(e.key === 'ArrowDown' ? 1 : -1)
          return
        }
        if (pos !== null && (e.key === 'Home' || e.key === 'End')) {
          e.preventDefault()
          const items = menuRef.current === null ? [] : menuRef.current.querySelectorAll('[role="menuitem"]')
          if (items.length > 0) {
            if (e.key === 'Home') items[0].focus()
            else items[items.length - 1].focus()
          }
        }
      }

      const ico = React.createElement('svg', { width: 14, height: 14, viewBox: '0 0 16 16', fill: 'none', stroke: 'currentColor', strokeWidth: 1.3, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': 'true' },
        React.createElement('path', { d: 'M1.8 3.2h12.4a1 1 0 0 1 1 1v6.6a1 1 0 0 1-1 1H1.8a1 1 0 0 1-1-1V4.2a1 1 0 0 1 1-1z' }),
        React.createElement('path', { d: 'M4.9 6.2 3.4 7.7l1.5 1.5' }),
        React.createElement('path', { d: 'm11.1 6.2 1.5 1.5-1.5 1.5' }),
      )

      const directItem = findDefault(ide.items)
      const btn = React.createElement('button', {
        type: 'button',
        className: 'dsh-ide-btn dsh-ide-btn-main',
        title: dir === '' ? t('button.titleEmpty') : (directItem !== null ? t('button.titleOpenDirect', { name: directItem.name }) : t('button.titleOpen')),
        disabled: dir === '',
        'aria-haspopup': 'menu',
        'aria-expanded': pos !== null,
        'aria-controls': pos === null ? undefined : menuId,
        onClick: handleMainClick,
        onContextMenu: (e) => { e.preventDefault(); showMenu() },
      },
        React.createElement('span', { className: 'dsh-ide-ico' }, ico),
        React.createElement('span', null, 'IDE'),
      )
      const caretBtn = React.createElement('button', {
        type: 'button',
        className: 'dsh-ide-btn dsh-ide-btn-caret',
        title: t('button.titleCaret'),
        'aria-label': t('button.titleCaret'),
        disabled: dir === '',
        'aria-haspopup': 'menu',
        'aria-expanded': pos !== null,
        'aria-controls': pos === null ? undefined : menuId,
        onClick: toggleMenu,
      }, '▾')
      const splitBtn = React.createElement('span', { className: 'dsh-ide-split' }, btn, caretBtn)

      let menu = null
      if (pos !== null) {
        let body
        if (ide.items === null) {
          body = React.createElement('div', { className: 'dsh-ide-note' }, t('menu.scanning'))
        } else if (ide.error !== null && ide.error !== '') {
          const errObj = typeof ide.error === 'object' && ide.error !== null ? ide.error : {}
          const message = typeof errObj.message === 'string' ? errObj.message : String(ide.error)
          const key = typeof errObj.key === 'string' && DICTIONARIES.zh[errObj.key] !== undefined ? errObj.key : 'error.detect'
          body = React.createElement('div', { className: 'dsh-ide-note dsh-ide-note-error' }, t(key, { message: message }))
        } else if (ide.items.length === 0) {
          body = React.createElement('div', { className: 'dsh-ide-note' }, t('menu.empty'))
        } else {
          body = ide.items.map((item) => {
            const badge = item.default === true
              ? React.createElement('span', { className: 'dsh-ide-item-badge' }, t('item.defaultBadge'))
              : item.lastUsed === true
                ? React.createElement('span', { className: 'dsh-ide-item-badge' }, t('item.lastUsedBadge'))
                : null
            const main = React.createElement('button', {
              key: item.id,
              type: 'button',
              className: 'dsh-ide-item',
              role: 'menuitem',
              disabled: busyId === item.id,
              onClick: () => { choose(item) },
            },
              React.createElement('span', { className: 'dsh-ide-item-name' }, item.name, badge),
              React.createElement('span', { className: 'dsh-ide-item-path' }, item.path),
            )
            const star = React.createElement('button', {
              type: 'button',
              className: 'dsh-ide-action' + (item.default === true ? ' dsh-ide-action-active' : ''),
              title: item.default === true ? t('item.clearDefaultTitle') : t('item.setDefaultTitle'),
              'aria-label': item.default === true ? t('item.clearDefaultTitle') : t('item.setDefaultTitle'),
              disabled: busyAction !== null,
              onClick: (e) => { e.stopPropagation(); setDefault(item) },
            }, item.default === true ? '★' : '☆')
            const remove = item.custom === true ? React.createElement('button', {
              type: 'button',
              className: 'dsh-ide-action',
              title: t('item.removeTitle'),
              'aria-label': t('item.removeTitle'),
              disabled: busyAction !== null,
              onClick: (e) => { e.stopPropagation(); removeItem(item) },
            }, '×') : null
            return React.createElement('div', { key: item.id, className: 'dsh-ide-item-row', role: 'none' },
              main,
              React.createElement('span', { className: 'dsh-ide-item-actions' }, star, remove),
            )
          })
        }
        const head = dir === '' ? null : React.createElement('div', { className: 'dsh-ide-dir' }, dir)
        const addRow = React.createElement('div', { className: 'dsh-ide-add' },
          React.createElement('button', { type: 'button', className: 'dsh-ide-pick-btn', disabled: picking, onClick: pickExeFile }, picking ? t('menu.picking') : t('menu.pick')),
        )
        const hintEl = React.createElement('div', { className: 'dsh-ide-hint' }, t('menu.hint'))
        const refreshBtn = React.createElement('button', { type: 'button', className: 'dsh-ide-refresh', disabled: ide.loading, onClick: () => { refresh() } }, ide.loading ? t('menu.refreshRunning') : t('menu.refresh'))
        const foot = React.createElement('div', null, addRow, hintEl, refreshBtn)
        menu = React.createElement('div', {
          className: 'dsh-ide-menu',
          id: menuId,
          role: 'menu',
          ref: menuRef,
          tabIndex: -1,
          style: { top: pos.top, left: pos.left, width: 280, maxHeight: pos.maxHeight },
        }, head, body, foot)
      }

      const statusEl = status === null ? null : React.createElement('span', {
        className: 'dsh-ide-status' + (status.kind === 'err' ? ' dsh-ide-status-err' : ''),
        title: status.text,
      }, status.text)

      return React.createElement('div', {
        className: 'dsh-ide-wrap',
        ref: rootRef,
        tabIndex: 0,
        onBlur: (e) => { if (!e.currentTarget.contains(e.relatedTarget)) setPos(null) },
        onKeyDown: onKeyDown,
      }, splitBtn, statusEl, menu)
    }

    exports.name = 'open-in-ide'
    exports.inject = ['slots', 'locale']
    exports.apply = (ctx) => {
      ctx.effect(() => {
        const disposers = []
        const disposeAll = (list) => { for (const dispose of list) { if (typeof dispose === 'function') dispose() } }
        try {
          for (const [locale, dict] of Object.entries(DICTIONARIES)) {
            disposers.push(ctx.locale.register(LOCALE_NS, locale, dict))
          }
        } catch (e) {
          disposeAll(disposers.reverse())
          throw e
        }
        return () => { disposeAll(disposers) }
      }, 'open-in-ide: locale dictionaries')

      ctx.slots.inject('conversation.session.header.utilities', () => ctx.slots.register(
        {
          name: 'conversation.session.header.utilities',
          id: 'open-in-ide',
          order: 10,
          label: () => { try { return ctx.locale.bind(LOCALE_NS)('label.open') } catch (e) { return '在 IDE 中打开' } },
          locale: LOCALE_NS,
        },
        (props) => React.createElement(IdeMenuButton, props),
      ))
    }

    return module.exports
  },
})
