/**
 * dsh-open-in-ide — 宿主半（Node）插件。
 *
 * 提供同源 HTTP 路由 /open-in-ide，浏览器半通过 fetch 调用：
 *   GET  /open-in-ide                → 返回当前 IDE 列表
 *   POST /open-in-ide {action:'list'}        → 同上
 *   POST /open-in-ide {action:'refresh'}     → 清缓存重新检测
 *   POST /open-in-ide {action:'pickAndAdd'}  → 弹 Windows 原生文件对话框选择 exe 并加入列表
 *   POST /open-in-ide {action:'open',id,dir} → 用所选 IDE 打开 dir
 *
 * 检测来源（按优先级）：注册表 App Paths / 卸载项（主要来源，覆盖任意自定义安装位置）、
 * 常见安装目录、PATH 里的 .cmd shim、scoop、JetBrains Toolbox、
 * Program Files 下 JetBrains、开始菜单 .lnk 快捷方式、自定义目录启发式扫描（便携版兜底）。
 * 检测结果会缓存到工作区下的 .dsh-open-in-ide-cache.json（TTL 30 分钟），
 * 插件启动后会延迟预热扫描；自定义项与默认 IDE 持久化到
 * .dsh-open-in-ide-prefs.json。
 */

import {
  EXE_NAME_MAP, ORDER, ROOT_EXE, TOOLBOX_NAMES,
  isLikelyIdeExe, matchName, normalizePath, pickExe, slugifyId, stripIconIndex,
} from './lib.mjs'

export const name = 'open-in-ide'

const ROUTE_PATH = '/open-in-ide'
const CACHE_FILE = '.dsh-open-in-ide-cache.json'
const CACHE_VERSION = 2
const PREFS_FILE = '.dsh-open-in-ide-prefs.json'
const CACHE_TTL_MS = 30 * 60 * 1000
const MAX_JSON_BODY_BYTES = 64 * 1024

export const inject = ['subprocess', 'fs', 'webServer']

export function apply(ctx) {
  const subprocess = ctx.subprocess
  const fs = ctx.fs
  const webServer = ctx.webServer

  const state = {
    list: null,
    scanning: null,
    custom: [],
    defaultId: '',
    lastUsedId: '',
    picking: false,
    opening: new Set(),
    scanSeq: 0,
    prefsLoaded: null,
    prefsReadError: false,
  }

  let cmdPathPromise
  let psPathPromise
  const resolveCmd = () => {
    if (cmdPathPromise === undefined) {
      cmdPathPromise = subprocess.resolveExecutable('cmd').then((p) => p, () => 'cmd.exe')
    }
    return cmdPathPromise
  }
  const resolvePs = () => {
    if (psPathPromise === undefined) {
      psPathPromise = subprocess.resolveExecutable('powershell').then((p) => p, () => 'powershell.exe')
    }
    return psPathPromise
  }

  // 带并发上限的异步 map。结果按下标放回原位；任一任务失败则整体 reject。
  const mapLimit = async (items, limit, fn) => {
    const results = new Array(items.length)
    let next = 0
    const workers = []
    const count = Math.min(limit, items.length)
    for (let w = 0; w < count; w += 1) {
      workers.push((async () => {
        while (next < items.length) {
          const i = next
          next += 1
          results[i] = await fn(items[i], i)
        }
      })())
    }
    await Promise.all(workers)
    return results
  }

  const runCollected = async (argv, cwd, maxBytes, timeoutMs) => {
    let controller
    let timer
    if (typeof timeoutMs === 'number' && timeoutMs > 0 && typeof AbortController === 'function') {
      controller = new AbortController()
      timer = setTimeout(() => { controller.abort() }, timeoutMs)
    }
    let handle
    try {
      handle = subprocess.spawn({
        argv: argv,
        cwd: cwd,
        stdio: { stdin: 'ignore', stdout: { maxBytes: maxBytes }, stderr: { maxBytes: 8192 } },
        graceMs: 5000,
        signal: controller === undefined ? undefined : controller.signal,
      })
      await handle.done
    } finally {
      if (timer !== undefined) clearTimeout(timer)
    }
    const read = (r) => (r === undefined ? '' : r.readFrom(0).text)
    return { out: read(handle.collected.stdout), err: read(handle.collected.stderr) }
  }

  const baseDir = async () => {
    try {
      const t = await fs.resolve('.', {})
      if (t !== undefined && typeof t.displayPath === 'string' && t.displayPath !== '') return t.displayPath
    } catch (e) { /* fall through */ }
    const sp = typeof ctx.get === 'function' ? ctx.get('sandboxPolicy') : undefined
    if (sp !== undefined && typeof sp.workspaceRoot === 'string' && sp.workspaceRoot !== '') return sp.workspaceRoot
    return process.cwd()
  }

  const readEnv = async () => {
    const env = {}
    const absorb = (source) => {
      if (source === null || source === undefined) return
      for (const key of Object.keys(source)) {
        const value = source[key]
        if (typeof key === 'string' && key.trim() !== '' && typeof value === 'string') {
          env[key.trim().toUpperCase()] = value
        }
      }
    }
    // 先取进程内环境，再用 `cmd /c set` 的结果覆盖，避免 set 不可用时拿不到 PATH。
    if (typeof process !== 'undefined' && process !== null && process.env !== undefined) absorb(process.env)
    try {
      const cmd = await resolveCmd()
      const cwd = await baseDir()
      const result = await runCollected([cmd, '/d', '/s', '/c', 'set'], cwd, 131072, 10000)
      const parsed = {}
      const lines = result.out.split(/\r?\n/)
      for (let i = 0; i < lines.length; i += 1) {
        const line = lines[i]
        const idx = line.indexOf('=')
        if (idx > 0) parsed[line.slice(0, idx).trim()] = line.slice(idx + 1)
      }
      absorb(parsed)
    } catch (e) { /* 进程内环境变量兜底 */ }
    return env
  }

  const isFile = async (p) => {
    if (p === '') return false
    try {
      const info = await fs.lstat(p, {})
      return info !== undefined && (info.type === 'file' || info.type === 'symlink')
    } catch (e) { return false }
  }

  const isDir = async (p) => {
    if (p === '') return false
    try {
      const info = await fs.lstat(p, {})
      return info !== undefined && info.type === 'directory'
    } catch (e) { return false }
  }

  const listChildren = async (p, type) => {
    try {
      const t = await fs.resolve(p, {})
      const entries = await fs.listDir(t)
      return entries.filter((e) => e.type === type).map((e) => e.name)
    } catch (e) { return [] }
  }

  // IDE 名称识别、exe 映射与排序等纯逻辑已抽到 ./lib.mjs（可单测）。

  // 开始菜单 .lnk 快捷方式（辅助来源）。
  const scanShortcuts = async () => {
    const script = [
      'try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false) } catch {}',
      '$ErrorActionPreference = "SilentlyContinue"',
      '$sh = New-Object -ComObject WScript.Shell',
      '$roots = @("$env:APPDATA\\Microsoft\\Windows\\Start Menu\\Programs", "$env:ProgramData\\Microsoft\\Windows\\Start Menu\\Programs")',
      'Get-ChildItem -Path $roots -Recurse -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object {',
      '  $lnk = $sh.CreateShortcut($_.FullName)',
      '  $tp = $lnk.TargetPath',
      '  if ($tp -and ($tp -match "\\.exe$") -and (Test-Path $tp)) { Write-Output ("S`t" + $_.Name + "`t" + $tp) }',
      '}',
    ].join('\n')
    const ps = await resolvePs()
    const cwd = await baseDir()
    const result = await runCollected([ps, '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], cwd, 131072, 45000)
    return result.out
  }

  // 注册表检测（主要来源）：
  //   1) App Paths —— 安装程序注册的“exe 名 → 真实路径”映射（HKLM 32/64 位 + HKCU），
  //      是 Windows 解析可执行文件的标准途径，能覆盖任意自定义安装位置；
  //   2) 卸载项 —— DisplayName + InstallLocation + DisplayIcon + UninstallString，
  //      用于补全 App Paths 未覆盖的 IDE（例如部分 Toolbox/便携式安装）。
  const scanRegistry = async () => {
    const script = [
      'try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false) } catch {}',
      '$ErrorActionPreference = "SilentlyContinue"',
      'function ExpandP($p) { if ($p) { try { return [Environment]::ExpandEnvironmentVariables([string]$p) } catch { return [string]$p } } return "" }',
      '$appRoots = @("HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths", "HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\App Paths", "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\App Paths", "HKCU:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\App Paths")',
      'foreach ($root in $appRoots) {',
      '  Get-ChildItem -Path $root -ErrorAction SilentlyContinue | ForEach-Object {',
      '    $k = Get-Item -Path $_.PSPath -ErrorAction SilentlyContinue',
      '    if ($k) { $def = ExpandP $k.GetValue("")',
      '      if ($def -ne "") { Write-Output ("A`t" + $_.PSChildName + "`t" + $def) } }',
      '  }',
      '}',
      '$unRoots = @("HKLM:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "HKLM:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall", "HKCU:\\SOFTWARE\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall")',
      'foreach ($root in $unRoots) {',
      '  Get-ItemProperty -Path ($root + "\\*") -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName } | ForEach-Object {',
      '    $loc = ""; if ($_.InstallLocation) { $loc = ExpandP $_.InstallLocation }',
      '    $icon = ""; if ($_.DisplayIcon) { $icon = ExpandP $_.DisplayIcon }',
      '    $un = ""; if ($_.UninstallString) { $un = ExpandP $_.UninstallString }',
      '    Write-Output ("U`t" + $_.DisplayName + "`t" + $loc + "`t" + $icon + "`t" + $un)',
      '  }',
      '}',
    ].join('\n')
    const ps = await resolvePs()
    const cwd = await baseDir()
    const result = await runCollected([ps, '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script], cwd, 262144, 45000)
    return result.out
  }

  // 路径规范化纯逻辑见 ./lib.mjs。

  // ROOT_EXE 里既可能是根目录下的 exe（Code.exe），也可能是相对路径
  // （Android Studio 的 bin\studio64.exe、VS 的 Common7\IDE\devenv.exe）。
  // base 可能已经指向 bin 目录，因此同时尝试“相对路径”与“叶子文件名”两种拼法。
  const rootExeCandidates = (base, name) => {
    const rootName = ROOT_EXE[name]
    if (rootName === undefined) return []
    const candidates = [base + '\\' + rootName]
    const leaf = rootName.split(/[\\/]/).pop()
    if (leaf !== rootName) candidates.push(base + '\\' + leaf)
    return candidates
  }

  const processPsOutput = async (out, push, systemRoot) => {
    const lines = out.split(/\r?\n/)
    await mapLimit(lines, 16, async (line) => {
      const parts = line.replace(/^\uFEFF/, '').split('\t')
      if (parts[0] === 'A' && parts.length >= 3) {
        // 注册表 App Paths：值名 = 可执行文件名，默认值 = 完整路径
        const exe = normalizePath(parts[2])
        if (!/\.exe$/i.test(exe) || !isLikelyIdeExe(exe, systemRoot) || !(await isFile(exe))) return
        let name = EXE_NAME_MAP[(parts[1] || '').toLowerCase()]
        if (name === undefined) name = EXE_NAME_MAP[exe.split(/[\\/]/).pop().toLowerCase()]
        if (name !== undefined) push(name, exe, [])
      } else if (parts[0] === 'U' && parts.length >= 5) {
        const name = matchName(parts[1])
        if (name === null) return
        let exe = ''
        const icon = stripIconIndex(normalizePath(parts[3]))
        if (icon !== '' && isLikelyIdeExe(icon, systemRoot) && await isFile(icon)) exe = icon
        if (exe === '') {
          const loc = normalizePath(parts[2])
          if (loc !== '') {
            const roots = rootExeCandidates(loc, name)
            if (roots.length > 0) {
              for (let r = 0; r < roots.length && exe === ''; r += 1) {
                if (await isFile(roots[r])) exe = roots[r]
              }
            } else {
              const binExe = pickExe(await listChildren(loc + '\\bin', 'file'))
              if (binExe !== undefined) exe = loc + '\\bin\\' + binExe
            }
          }
        }
        if (exe === '') {
          // 兜底：从 UninstallString 提取所在目录，再找 exe
          const un = normalizePath(parts[4])
          if (un !== '' && isLikelyIdeExe(un, systemRoot)) {
            const dir = un.replace(/\\[^\\]+$/i, '')
            if (dir !== '' && dir !== un) {
              const binExe = pickExe(await listChildren(dir + '\\bin', 'file'))
              if (binExe !== undefined) exe = dir + '\\bin\\' + binExe
              const roots = rootExeCandidates(dir, name)
              for (let r = 0; r < roots.length && exe === ''; r += 1) {
                if (await isFile(roots[r])) exe = roots[r]
              }
            }
          }
        }
        if (exe !== '') push(name, exe, [])
      } else if (parts[0] === 'S' && parts.length >= 3) {
        const name = matchName(parts[1])
        if (name === null) return
        if (isLikelyIdeExe(parts[2], systemRoot) && await isFile(parts[2])) push(name, parts[2], [])
      }
    })
  }

  const scanScoop = async (env, push) => {
    const home = env.USERPROFILE || ''
    if (home === '') return
    const appsRoot = home + '\\scoop\\apps'
    const apps = await listChildren(appsRoot, 'directory')
    await mapLimit(apps, 6, async (app) => {
      const name = matchName(app)
      if (name === null) return
      const current = appsRoot + '\\' + app + '\\current'
      const rootFiles = (await listChildren(current, 'file')).filter((n) => /\.exe$/i.test(n))
      const binFiles = (await listChildren(current + '\\bin', 'file')).filter((n) => /\.exe$/i.test(n))
      const candidates = rootFiles.map((n) => ({ name: n, path: current + '\\' + n }))
        .concat(binFiles.map((n) => ({ name: n, path: current + '\\bin\\' + n })))
      if (candidates.length === 0) return
      // pickExe 按 basename 判断主程序，选完再映射回完整路径。
      const chosen = pickExe(candidates.map((c) => c.name))
      const hit = candidates.find((c) => c.name === chosen)
      if (hit !== undefined) push(name, hit.path, [])
    })
  }

  // 扫描自定义安装位置：用户常见目录、LOCALAPPDATA/APPDATA、以及除 C: 外的其它盘符根目录（限深、限预算）。
  const scanCustomRoots = async (env, push) => {
    const userProfile = env.USERPROFILE || ''
    const localAppData = env.LOCALAPPDATA || ''
    const appData = env.APPDATA || ''
    const roots = []
    if (userProfile !== '') {
      const subs = ['Desktop', 'Downloads', 'Documents', 'tools', 'Apps', 'Software', 'IDE', 'IDEs', 'PortableApps', 'Portable']
      for (let i = 0; i < subs.length; i += 1) roots.push({ path: userProfile + '\\' + subs[i], depth: 3 })
    }
    if (localAppData !== '') roots.push({ path: localAppData + '\\Programs', depth: 2 })
    if (appData !== '') roots.push({ path: appData + '\\Programs', depth: 2 })
    for (let c = 68; c <= 90; c += 1) {
      const root = String.fromCharCode(c) + ':\\'
      if (await isDir(root)) roots.push({ path: root, depth: 2 })
    }

    const visited = new Set()
    const skipDirs = new Set(['system volume information', '.git', 'node_modules'])
    let budget = 1500
    const walk = async (dir, depth) => {
      if (depth < 0 || budget <= 0) return
      const key = dir.replace(/[\\/]+$/, '').toLowerCase()
      if (key === '' || visited.has(key)) return
      visited.add(key)
      let entries
      try {
        const t = await fs.resolve(dir, {})
        entries = await fs.listDir(t)
      } catch (e) { return }
      if (!Array.isArray(entries)) return
      for (let i = 0; i < entries.length; i += 1) {
        if (budget <= 0) return
        budget -= 1
        const e = entries[i]
        if (e.type === 'directory') {
          const n = e.name
          if (n.charAt(0) === '$' || skipDirs.has(n.toLowerCase())) continue
          await walk(dir + '\\' + n, depth - 1)
        } else if (e.type === 'file') {
          const name = EXE_NAME_MAP[e.name.toLowerCase()]
          if (name !== undefined) push(name, dir + '\\' + e.name, [])
        }
      }
    }
    // 各根目录并行推进，共享同一个条目预算。
    await mapLimit(roots, 4, (root) => walk(root.path, root.depth))
  }

  const scan = async () => {
    const generation = state.scanSeq
    const found = []
    const seen = {}
    const push = (name, exe, args) => {
      if (typeof exe !== 'string' || exe === '') return
      const key = exe.toLowerCase()
      if (seen[key] === true) return
      seen[key] = true
      found.push({ name: name, exe: exe, args: args || [], order: ORDER[name] !== undefined ? ORDER[name] : 10 })
    }

    // 三个慢源（注册表、开始菜单、环境变量）并行启动；
    // 注册表/快捷方式结果一就绪就开始解析，不必等目录扫描结束。
    const envPromise = readEnv().then((e) => e, () => ({}))
    const regPromise = scanRegistry().catch(() => '')
    const lnkPromise = scanShortcuts().catch(() => '')
    const env = await envPromise
    const systemRoot = env.SYSTEMROOT || ''
    await Promise.all([
      regPromise.then((out) => processPsOutput(out, push, systemRoot)),
      lnkPromise.then((out) => processPsOutput(out, push, systemRoot)),
    ])

    const local = env.LOCALAPPDATA || ''
    const pf = env.PROGRAMFILES || ''
    const pfx = env['PROGRAMFILES(X86)'] || ''
    const fixed = [
      { name: 'VS Code', exe: local === '' ? '' : local + '\\Programs\\Microsoft VS Code\\Code.exe', args: [] },
      { name: 'VS Code Insiders', exe: local === '' ? '' : local + '\\Programs\\Microsoft VS Code Insiders\\Code - Insiders.exe', args: [] },
      { name: 'Cursor', exe: local === '' ? '' : local + '\\Programs\\Cursor\\Cursor.exe', args: [] },
      { name: 'Windsurf', exe: local === '' ? '' : local + '\\Programs\\Windsurf\\Windsurf.exe', args: [] },
      { name: 'Zed', exe: local === '' ? '' : local + '\\Programs\\Zed\\zed.exe', args: [] },
      { name: 'Trae', exe: local === '' ? '' : local + '\\Programs\\Trae\\Trae.exe', args: [] },
      { name: 'Trae', exe: local === '' ? '' : local + '\\Programs\\Trae CN\\Trae CN.exe', args: [] },
      { name: 'VSCodium', exe: local === '' ? '' : local + '\\Programs\\VSCodium\\VSCodium.exe', args: [] },
      { name: 'Android Studio', exe: pf === '' ? '' : pf + '\\Android\\Android Studio\\bin\\studio64.exe', args: [] },
      { name: 'Android Studio', exe: pfx === '' ? '' : pfx + '\\Android\\Android Studio\\bin\\studio64.exe', args: [] },
      { name: 'Sublime Text', exe: pf === '' ? '' : pf + '\\Sublime Text\\subl.exe', args: [] },
      { name: 'Sublime Text', exe: pfx === '' ? '' : pfx + '\\Sublime Text\\subl.exe', args: [] },
      { name: '资源管理器', exe: (env.SYSTEMROOT || 'C:\\Windows') + '\\explorer.exe', args: [] },
    ]
    const fixedCandidates = fixed.filter((item) => item.exe !== '')
    await mapLimit(fixedCandidates, 8, async (item) => {
      if (await isFile(item.exe)) push(item.name, item.exe, item.args)
    })

    const cleanDir = (p) => {
      let x = p.trim().replace(/^"|"$/g, '')
      if (/^[A-Za-z]:\\$/.test(x)) return x
      return x.replace(/\\+$/, '')
    }
    const pathDirs = (env.PATH || '').split(';').map(cleanDir).filter((p) => p !== '').slice(0, 60)
    const shims = [
      { name: 'VS Code', file: 'code.cmd', real: 'Code.exe' },
      { name: 'VS Code Insiders', file: 'code-insiders.cmd', real: 'Code - Insiders.exe' },
      { name: 'Cursor', file: 'cursor.cmd', real: 'Cursor.exe' },
      { name: 'Windsurf', file: 'windsurf.cmd', real: 'Windsurf.exe' },
    ]
    const shimChecks = []
    for (let d = 0; d < pathDirs.length; d += 1) {
      const dir = pathDirs[d]
      for (let s = 0; s < shims.length; s += 1) shimChecks.push({ dir: dir, shim: shims[s] })
      shimChecks.push({ dir: dir, subl: true })
    }
    await mapLimit(shimChecks, 8, async (check) => {
      const dir = check.dir
      if (check.subl === true) {
        const subl = dir + '\\subl.exe'
        if (await isFile(subl)) push('Sublime Text', subl, [])
        return
      }
      const shim = dir + '\\' + check.shim.file
      if (!(await isFile(shim))) return
      const root = dir.replace(/(\\resources\\app)?\\bin$/i, '')
      const realExe = root === dir ? '' : root + '\\' + check.shim.real
      if (realExe !== '' && await isFile(realExe)) push(check.shim.name, realExe, [])
      else push(check.shim.name, shim, [])
    })

    await scanScoop(env, push)
    await scanCustomRoots(env, push)

    if (local !== '') {
      const appsRoot = local + '\\JetBrains\\Toolbox\\apps'
      const apps = await listChildren(appsRoot, 'directory')
      await mapLimit(apps, 4, async (app) => {
        const appDir = appsRoot + '\\' + app
        const channels = (await listChildren(appDir, 'directory')).filter((n) => /^ch-/i.test(n)).sort()
        const ch = channels[channels.length - 1]
        if (ch === undefined) return
        const binDir = appDir + '\\' + ch + '\\bin'
        const exe = pickExe(await listChildren(binDir, 'file'))
        if (exe === undefined) return
        push(TOOLBOX_NAMES[app] !== undefined ? TOOLBOX_NAMES[app] : app + ' (Toolbox)', binDir + '\\' + exe, [])
      })
    }

    const jbRoots = [pf, pfx]
    await mapLimit(jbRoots, 2, async (jbRoot) => {
      if (jbRoot === '') return
      const jb = jbRoot + '\\JetBrains'
      const entries = await listChildren(jb, 'directory')
      for (let e2 = 0; e2 < entries.length; e2 += 1) {
        const binDir = jb + '\\' + entries[e2] + '\\bin'
        const exe = pickExe(await listChildren(binDir, 'file'))
        if (exe === undefined) continue
        const stripped = entries[e2].replace(/\s+\d+(\.\d+)*$/, '')
        const matched = matchName(stripped)
        push(matched !== null ? matched : (stripped === '' ? entries[e2] : stripped), binDir + '\\' + exe, [])
      }
    })

    // 注册表是主要来源，先合并；.lnk 快捷方式作为补充。
    await regPromise
    await lnkPromise

    found.sort((a, b) => a.order - b.order || (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    const used = {}
    const items = found.map((f) => ({
      id: slugifyId(f.name, used),
      name: f.name,
      path: f.exe,
      cmd: /\.(cmd|bat)$/i.test(f.exe),
      args: f.args,
      custom: false,
    }))
    // 若刷新又启动了一次新扫描，旧一代结果不再写缓存，避免覆盖新结果。
    if (generation === state.scanSeq) void writeCachedItems(items)
    return items
  }

  const cacheFilePath = async () => (await baseDir()) + '\\' + CACHE_FILE
  const readCachedItems = async () => {
    try {
      const t = await fs.resolve(await cacheFilePath(), {})
      const info = await fs.lstat(t)
      if (info === undefined || info.type !== 'file') return null
      const data = JSON.parse(await fs.readText(t))
      if (data === null || typeof data !== 'object' || !Array.isArray(data.items)) return null
      if (data.v !== CACHE_VERSION) return null
      if (typeof data.scannedAt !== 'number' || Date.now() - data.scannedAt > CACHE_TTL_MS) return null
      return data.items.filter((i) => i !== null && typeof i === 'object' && typeof i.path === 'string' && i.path !== '' && typeof i.name === 'string' && typeof i.id === 'string')
        .map((i) => ({ ...i, args: Array.isArray(i.args) ? i.args : [], custom: i.custom === true }))
    } catch (e) { return null }
  }
  const writeCachedItems = async (items) => {
    try {
      const t = await fs.resolve(await cacheFilePath(), {})
      await fs.writeText(t, JSON.stringify({ v: CACHE_VERSION, scannedAt: Date.now(), items: items }))
    } catch (e) { /* 缓存写入失败只影响下次启动速度，不影响本次功能 */ }
  }

  const prefsFilePath = async () => (await baseDir()) + '\\' + PREFS_FILE

  const isValidCustom = (i) => i !== null && typeof i === 'object' &&
    typeof i.id === 'string' && i.id !== '' &&
    typeof i.name === 'string' && i.name !== '' &&
    typeof i.path === 'string' && i.path !== ''

  const loadPrefs = async () => {
    if (state.prefsLoaded === null) {
      state.prefsLoaded = (async () => {
        let info
        try {
          const t = await fs.resolve(await prefsFilePath(), {})
          info = await fs.lstat(t)
        } catch (e) {
          state.prefsReadError = true
          return
        }
        if (info === undefined || info.type !== 'file') return
        try {
          const data = JSON.parse(await fs.readText(await fs.resolve(await prefsFilePath(), {})))
          if (data === null || typeof data !== 'object') return
          if (Array.isArray(data.custom)) state.custom = data.custom.filter(isValidCustom)
          if (typeof data.defaultId === 'string') state.defaultId = data.defaultId
          if (typeof data.lastUsedId === 'string') state.lastUsedId = data.lastUsedId
        } catch (e) {
          // 读取/解析失败：保留原文件，禁止本次运行写回覆盖损坏的偏好。
          state.prefsReadError = true
        }
      })()
    }
    return state.prefsLoaded
  }

  const writePrefs = async () => {
    if (state.prefsReadError) return
    try {
      const t = await fs.resolve(await prefsFilePath(), {})
      await fs.writeText(t, JSON.stringify({ v: 1, custom: state.custom, defaultId: state.defaultId, lastUsedId: state.lastUsedId }))
    } catch (e) { /* 偏好写入失败只影响下次启动，不影响本次使用 */ }
  }

  const ensureList = async () => {
    await loadPrefs()
    if (state.list === null) {
      if (state.scanning === null) {
        state.scanning = (async () => {
          const cached = await readCachedItems()
          if (cached !== null) return cached
          return await scan()
        })()
      }
      const p = state.scanning
      try {
        const list = await p
        // refresh 可能已把 state.scanning 换成新一代扫描；只有自己仍是当前代时才写回。
        if (state.scanning === p && state.list === null) state.list = list
      } catch (e) {
        if (state.scanning === p && state.list === null) state.list = []
      }
      if (state.list === null) return ensureList()
    }
    const custom = state.custom || []
    const combined = custom.concat(state.list.filter((i) => !custom.some((c) => (c.path || '').toLowerCase() === (i.path || '').toLowerCase())))
    // 默认 IDE 置顶；没有显式默认时，最近使用过的置顶。
    const preferred = state.defaultId !== '' ? state.defaultId : state.lastUsedId
    if (preferred !== '') {
      const idx = combined.findIndex((i) => i.id === preferred)
      if (idx > 0) {
        const item = combined[idx]
        combined.splice(idx, 1)
        combined.unshift(item)
      }
    }
    return combined
  }

  const listItems = async () => {
    const items = await ensureList()
    return items.map((i) => ({
      id: i.id,
      name: i.name,
      path: i.path,
      custom: i.custom === true,
      default: i.id === state.defaultId,
      lastUsed: i.id === state.lastUsedId,
    }))
  }

  const nextCustomId = () => {
    const ids = new Set(state.custom.map((c) => c.id))
    let n = 1
    while (ids.has('custom-' + n)) n += 1
    return 'custom-' + n
  }

  const addCustomPath = async (exePath) => {
    await loadPrefs()
    if (!/\.exe$/i.test(exePath)) return { ok: false, error: '请选择 .exe 文件' }
    let resolved
    try { resolved = await subprocess.resolveExecutable(exePath) } catch (e) {
      return { ok: false, error: '找不到该文件: ' + exePath }
    }
    const existing = state.custom.find((c) => (c.path || '').toLowerCase() === resolved.toLowerCase())
    if (existing !== undefined) {
      return { ok: true, name: existing.name, added: false, items: await listItems() }
    }
    const base = resolved.split(/[\\/]/).pop().replace(/\.exe$/i, '')
    const matched = matchName(base)
    const name = (matched !== null ? matched : base) + ' (自定义)'
    state.custom.push({ id: nextCustomId(), name: name, path: resolved, cmd: false, args: [], custom: true })
    await writePrefs()
    return { ok: true, name: name, added: true, items: await listItems() }
  }

  const removeCustomPath = async (id) => {
    await loadPrefs()
    const idx = state.custom.findIndex((c) => c.id === id)
    if (idx < 0) return { ok: false, error: '未找到该自定义项' }
    const [removed] = state.custom.splice(idx, 1)
    if (state.defaultId === id) state.defaultId = ''
    if (state.lastUsedId === id) state.lastUsedId = ''
    await writePrefs()
    return { ok: true, name: removed.name, items: await listItems() }
  }

  const setDefaultId = async (id) => {
    await loadPrefs()
    const list = await ensureList()
    if (id !== '') {
      const item = list.find((i) => i.id === id)
      if (item === undefined) return { ok: false, error: '未知的 IDE: ' + id }
    }
    state.defaultId = id
    await writePrefs()
    return { ok: true, defaultId: id, items: await listItems() }
  }

  const pickExeViaDialog = async () => {
    const script = [
      'try { [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false) } catch {}',
      'try {',
      '  Add-Type -AssemblyName System.Windows.Forms',
      '  $d = New-Object System.Windows.Forms.OpenFileDialog',
      '  $d.Filter = "可执行文件 (*.exe)|*.exe|所有文件 (*.*)|*.*"',
      '  $d.Title = "选择 IDE 可执行文件"',
      '  $d.CheckFileExists = $true',
      '  $d.RestoreDirectory = $true',
      '  if ($d.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { Write-Output $d.FileName } else { Write-Output "" }',
      '} catch {',
      '  Write-Output ("ERR:" + $_.Exception.Message)',
      '}',
    ].join('\n')
    const ps = await resolvePs()
    const cwd = await baseDir()
    const result = await runCollected([ps, '-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', script], cwd, 65536, 120000)
    return result.out.trim()
  }

  const openInIde = async (body) => {
    const id = body !== null && typeof body === 'object' && typeof body.id === 'string' ? body.id : ''
    const dir = body !== null && typeof body === 'object' && typeof body.dir === 'string' ? body.dir : ''
    if (dir === '') return { ok: false, error: '缺少工作区目录' }
    const list = await ensureList()
    const item = list.find((i) => i.id === id)
    if (item === undefined) return { ok: false, error: '未知的 IDE: ' + id }
    if (state.opening.has(item.id)) return { ok: false, error: '该 IDE 正在启动中，请稍候' }

    // 先占位再 await，消除“检查→添加”之间的并发窗口；
    // 2 秒短窗口内阻止对同一 IDE 的重复点击，IDE 进程本身长驻不影响。
    state.opening.add(item.id)
    const release = setTimeout(() => state.opening.delete(item.id), 2000)
    if (release !== null && typeof release.unref === 'function') release.unref()

    let dirInfo
    try {
      dirInfo = await fs.lstat(dir, {})
    } catch (e) { dirInfo = undefined }
    if (dirInfo === undefined || dirInfo.type !== 'directory') {
      state.opening.delete(item.id)
      clearTimeout(release)
      return { ok: false, error: '目录不存在或不可用: ' + dir }
    }

    try {
      let argv
      if (item.cmd) {
        const cmd = await resolveCmd()
        // cmd /c 的标准双引号包装形式：""<cmd 路径>" "<目标目录>""
        const command = '""' + item.path + '" "' + dir + '""'
        argv = [cmd, '/d', '/s', '/c', command]
      } else {
        const resolved = await subprocess.resolveExecutable(item.path)
        argv = [resolved].concat(Array.isArray(item.args) ? item.args : []).concat([dir])
      }
      const handle = subprocess.spawn({
        argv: argv,
        cwd: dir,
        stdio: { stdin: 'ignore', stdout: { maxBytes: 8192 }, stderr: { maxBytes: 8192 } },
        graceMs: 5000,
      })
      handle.done.then(() => {}, () => {})
      state.lastUsedId = item.id
      void writePrefs()
      return { ok: true, name: item.name, pid: handle.pid, items: await listItems() }
    } catch (e) {
      state.opening.delete(item.id)
      clearTimeout(release)
      return { ok: false, error: '启动失败: ' + String((e !== null && typeof e === 'object' && e.message) || e) }
    }
  }

  const respondJson = (res, status, value) => {
    res.writeHead(status, {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
    })
    res.end(JSON.stringify(value))
  }

  const readJson = (req) => new Promise((resolve, reject) => {
    const decoder = new TextDecoder()
    let text = ''
    let received = 0
    let failed = false
    req.on('data', (chunk) => {
      if (failed) return
      const size = typeof chunk === 'string'
        ? Buffer.byteLength(chunk)
        : (typeof chunk.byteLength === 'number' ? chunk.byteLength : chunk.length)
      received += size
      if (received > MAX_JSON_BODY_BYTES) {
        failed = true
        const err = new Error('请求体过大')
        err.statusCode = 413
        reject(err)
        // 不 destroy 连接，让 handleRoute 能回写结构化 413；后续数据直接丢弃。
        if (typeof req.pause === 'function') req.pause()
        return
      }
      text += typeof chunk === 'string' ? chunk : decoder.decode(chunk, { stream: true })
    })
    req.on('end', () => {
      if (failed) return
      try { text += decoder.decode(); resolve(text === '' ? {} : JSON.parse(text)) } catch (e) { reject(e) }
    })
    req.on('error', reject)
  })

  const handleRoute = async (req, res) => {
    try {
      if (req.method === 'GET') return respondJson(res, 200, await listItems())
      if (req.method === 'POST') {
        const body = await readJson(req)
        const action = body !== null && typeof body === 'object' && typeof body.action === 'string' ? body.action : ''
        if (action === 'list') return respondJson(res, 200, await listItems())
        if (action === 'refresh') {
          state.list = null
          // 代际递增使旧扫描结果作废；随后强制重新扫描，绕过磁盘缓存。
          state.scanSeq += 1
          state.scanning = scan()
          return respondJson(res, 200, { ok: true, items: await listItems() })
        }
        if (action === 'pickAndAdd') {
          if (state.picking) return respondJson(res, 200, { ok: false, error: '已有文件选择窗口正在打开' })
          state.picking = true
          try {
            const picked = await pickExeViaDialog()
            if (picked === '') return respondJson(res, 200, { ok: false, canceled: true })
            if (picked.indexOf('ERR:') === 0) return respondJson(res, 200, { ok: false, error: '文件对话框不可用: ' + picked.slice(4) })
            return respondJson(res, 200, await addCustomPath(picked))
          } catch (e) {
            return respondJson(res, 200, { ok: false, error: '文件对话框不可用: ' + String((e !== null && typeof e === 'object' && e.message) || e) })
          } finally {
            state.picking = false
          }
        }
        if (action === 'removeCustom') {
          const id = body !== null && typeof body === 'object' && typeof body.id === 'string' ? body.id : ''
          if (id === '') return respondJson(res, 400, { ok: false, error: '缺少自定义项 id' })
          return respondJson(res, 200, await removeCustomPath(id))
        }
        if (action === 'setDefault') {
          const id = body !== null && typeof body === 'object' && typeof body.id === 'string' ? body.id : ''
          return respondJson(res, 200, await setDefaultId(id))
        }
        if (action === 'open') return respondJson(res, 200, await openInIde(body))
        return respondJson(res, 400, { ok: false, error: '未知 action: ' + action })
      }
      res.writeHead(405, { allow: 'GET, POST' })
      res.end()
    } catch (e) {
      const status = e !== null && typeof e === 'object' && typeof e.statusCode === 'number' ? e.statusCode : 500
      // 若连接已被销毁则放弃回写，避免 writeHead 抛错。
      if (res !== null && (res.writableEnded === true || res.destroyed === true)) return
      try { respondJson(res, status, { ok: false, error: String((e !== null && typeof e === 'object' && e.message) || e) }) } catch (e2) { /* socket 已关闭 */ }
    }
  }

  ctx.effect(() => {
    const unregister = webServer.register({ kind: 'exact', path: ROUTE_PATH, handler: handleRoute })
    if (typeof unregister === 'function') return unregister
    if (unregister !== null && typeof unregister === 'object' && typeof unregister.dispose === 'function') {
      return () => unregister.dispose()
    }
    return undefined
  }, 'open-in-ide: HTTP route')

  // 启动后延迟预热：首次点击时扫描通常已经完成或接近完成。
  const warmTimer = setTimeout(() => {
    if (state.list === null && state.scanning === null) ensureList().catch(() => {})
  }, 4000)
  if (warmTimer !== undefined && typeof warmTimer.unref === 'function') warmTimer.unref()
  ctx.effect(() => () => clearTimeout(warmTimer), 'open-in-ide: warmup timer')
}
