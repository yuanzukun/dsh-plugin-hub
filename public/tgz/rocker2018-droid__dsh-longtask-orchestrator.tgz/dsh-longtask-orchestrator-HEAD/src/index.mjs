/**
 * dsh-longtask-orchestrator — 长任务编排插件（宿主半区）
 *
 * 角色分工：
 *   - Codex（管理层）：规划（codex_plan）、打分（codex_score）、审核（codex_review）
 *   - DSH（执行层）：agent 用 DSH 原生工具实际执行子任务
 *   - Kimi（补充层）：视觉验收（kimi_call + image_path）、结果摘要（kimi_summarize）、
 *     交叉验证（kimi_review）
 *
 * 组成：
 *   1. codex_call / kimi_call —— 底层桥接（spawn codex CLI / HTTP 调 Moonshot）
 *   2. codex_plan / codex_score / codex_review —— Codex 封装（prompt 模板 + 严格 JSON）
 *   3. kimi_summarize / kimi_review —— Kimi 封装
 *   4. orchestrate_state / longtask_begin —— 状态持久化（.orchestrate/state.json）与会话内恢复
 *   5. longtask-orchestrator skill —— 循环模板（规划→执行→打分→迭代→终审）
 *   6. 「DeepSeek + 长任务编排」模型组 —— delegating adapter（选中后注入编排提示）
 *
 * 关键环境事实（已在目标机器实测）：
 *   - codex 二进制：/Applications/ChatGPT.app/Contents/Resources/codex（v0.148.0-alpha.9，
 *     支持 gpt-5.6-terra）；homebrew 版 0.136.0 太旧会报模型不支持，作为后备。
 *   - OpenAI 需要走系统代理（macOS 系统代理 127.0.0.1:7897），插件自动检测并传给子进程。
 *   - Kimi 配置复用 ~/.dsh/vision.env（VISION_API_KEY / VISION_BASE_URL / VISION_MODEL）。
 */
import { defineTool } from '@deepseek-ai/dsh-tools'
import { spawn, execFile } from 'node:child_process'
import { existsSync } from 'node:fs'
import { mkdir, readFile, writeFile, rm } from 'node:fs/promises'
import { join, resolve as pathResolve, isAbsolute } from 'node:path'
import { homedir } from 'node:os'

// ---------------------------------------------------------------------------
// 配置
// ---------------------------------------------------------------------------

const CODEX_BIN_CANDIDATES = [
  '/Applications/ChatGPT.app/Contents/Resources/codex',
  '/opt/homebrew/bin/codex',
  '/usr/local/bin/codex',
  'codex', // PATH 兜底
]

const KIMI_IMG_MAX_BYTES = 20 * 1024 * 1024

function resolveCodexBin() {
  const env = process.env.ORCHESTRATE_CODEX_BIN
  if (env && env.trim()) return env.trim()
  for (const candidate of CODEX_BIN_CANDIDATES) {
    if (candidate === 'codex') return candidate
    if (existsSync(candidate)) return candidate
  }
  return 'codex'
}

// 读取 ~/.dsh/vision.env（与 dsh-vision-tools 相同的格式）
function parseEnv(text) {
  const cfg = {}
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.trim()
    if (!line || line.startsWith('#')) continue
    const eq = line.indexOf('=')
    if (eq <= 0) continue
    let v = line.slice(eq + 1).trim()
    if (v.length >= 2 && ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'")))) v = v.slice(1, -1)
    cfg[line.slice(0, eq).trim()] = v
  }
  return cfg
}

async function kimiConfig() {
  const dshHome = process.env.DSH_HOME || join(homedir(), '.dsh')
  const candidates = [join(dshHome, 'vision.env'), join(homedir(), '.dsh', 'vision.env'), join(process.cwd(), '.dsh-vision.env')]
  let text = null
  let found = null
  for (const p of candidates) {
    try {
      text = await readFile(p, 'utf8')
      found = p
      break
    } catch {
      /* next */
    }
  }
  if (text === null) {
    throw new Error('未找到 Kimi 配置。请创建 ' + candidates[0] + '，内容：\nVISION_API_KEY=你的MoonshotKey\nVISION_BASE_URL=https://api.moonshot.cn/v1/chat/completions\nVISION_MODEL=kimi-k3')
  }
  const cfg = parseEnv(text)
  const key = process.env.ORCHESTRATE_KIMI_API_KEY || cfg.VISION_API_KEY || ''
  if (!key.trim()) throw new Error('Kimi 配置缺少 API Key（' + found + ' 中的 VISION_API_KEY）')
  return {
    key: key.trim(),
    endpoint: (process.env.ORCHESTRATE_KIMI_BASE_URL || cfg.VISION_BASE_URL || 'https://api.moonshot.cn/v1/chat/completions').trim(),
    model: (process.env.ORCHESTRATE_KIMI_MODEL || cfg.VISION_MODEL || 'kimi-k3').trim(),
  }
}

function stateDir() {
  return process.env.ORCHESTRATE_STATE_DIR || join(process.cwd(), '.orchestrate')
}
function stateFile() {
  return join(stateDir(), 'state.json')
}

// 检测 macOS 系统代理（OpenAI 需要代理才能连通）
function detectSystemProxy() {
  return new Promise((resolvePromise) => {
    execFile('scutil', ['--proxy'], { timeout: 5000 }, (err, stdout) => {
      if (err) return resolvePromise({})
      const host = /HTTPSProxy\s*:\s*([^\s]+)/.exec(stdout)?.[1]
      const port = /HTTPSPort\s*:\s*(\d+)/.exec(stdout)?.[1]
      if (!host || !port) return resolvePromise({})
      const url = `http://${host}:${port}`
      resolvePromise({ HTTPS_PROXY: url, HTTP_PROXY: url, ALL_PROXY: url })
    })
  })
}

// ---------------------------------------------------------------------------
// codex 桥接
// ---------------------------------------------------------------------------

// 串行队列：codex 与 Codex++ 共用 ChatGPT 登录态，必须避免并发抢 token
let codexQueue = Promise.resolve()
function serialized(fn) {
  const run = codexQueue.then(fn, fn)
  codexQueue = run.catch(() => {})
  return run
}

function parseCodexJsonl(stdout) {
  let threadId = null
  let lastText = null
  let failure = null
  for (const line of String(stdout).split('\n')) {
    const t = line.trim()
    if (!t.startsWith('{')) continue
    let d
    try {
      d = JSON.parse(t)
    } catch {
      continue
    }
    if (d.type === 'thread.started' && d.thread_id) threadId = d.thread_id
    if (d.type === 'turn.failed') {
      failure = d.error?.message || 'turn failed'
    }
    if (d.type === 'item.completed' && d.item) {
      if (d.item.type === 'agent_message' && typeof d.item.text === 'string') {
        lastText = d.item.text
      }
      if (d.item.type === 'error' && typeof d.item.message === 'string') {
        failure = failure || d.item.message
      }
    }
  }
  return { threadId, lastText, failure }
}

async function runCodex(prompt, opts = {}, exec) {
  const bin = resolveCodexBin()
  const cwd = opts.cwd ? pathResolve(String(opts.cwd)) : process.cwd()
  const args = ['exec', '--json', '--ephemeral', '--skip-git-repo-check', '-s', 'read-only', '-C', cwd]
  if (opts.model && String(opts.model).trim()) args.push('-m', String(opts.model).trim())
  args.push(String(prompt))

  const proxyEnv = await detectSystemProxy()
  const child = spawn(bin, args, {
    cwd,
    env: { ...process.env, ...proxyEnv },
    stdio: ['ignore', 'pipe', 'pipe'],
    signal: exec?.signal,
  })
  let stdout = ''
  let stderr = ''
  child.stdout.on('data', (d) => { stdout += d })
  child.stderr.on('data', (d) => { stderr += d })
  const exitCode = await new Promise((resolvePromise, reject) => {
    child.on('error', reject)
    child.on('close', resolvePromise)
  })
  if (exitCode !== 0) {
    const parsed = parseCodexJsonl(stdout)
    const detail = parsed.failure || stderr.trim().slice(-600) || `codex 退出码 ${exitCode}`
    throw new Error('codex 调用失败：' + detail)
  }
  const parsed = parseCodexJsonl(stdout)
  const text = (parsed.lastText || '').trim()
  if (!text) {
    throw new Error('codex 未返回有效回复' + (parsed.failure ? '：' + parsed.failure : ''))
  }
  return { text, thread_id: parsed.threadId }
}

function codexCallTool() {
  return defineTool({
    name: 'codex_call',
    description: '调用本地 Codex CLI（ChatGPT 登录态，只读沙箱，只做规划/评审/问答，不执行任何命令）。返回 Codex 的最终回复文本。prompt 为发给 Codex 的指令；cwd 为可选工作目录（默认当前工作区）；model 为可选模型覆盖（默认用 ~/.codex/config.toml 的配置）。',
    parameters: {
      prompt: { type: 'string', description: '发给 Codex 的完整指令', required: true },
      cwd: { type: 'string', description: 'Codex 的工作目录（默认当前工作区）' },
      model: { type: 'string', description: '模型覆盖，如 gpt-5.1-codex（默认不指定）' },
    },
    output: {
      schema: { type: 'object', properties: { text: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.text }],
    },
    timeoutMs: 600000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const result = await serialized(() => runCodex(args.prompt, { cwd: args.cwd, model: args.model }, exec))
      return { text: result.text }
    },
  })
}

// ---------------------------------------------------------------------------
// kimi 桥接
// ---------------------------------------------------------------------------

function mimeFor(path) {
  const ext = (String(path).split('.').pop() || '').toLowerCase()
  const map = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp' }
  return map[ext] || 'image/png'
}

async function loadImageBytes(rawPath) {
  const candidates = [rawPath]
  if (!isAbsolute(rawPath)) candidates.unshift(pathResolve(process.cwd(), rawPath))
  let lastErr = null
  for (const p of candidates) {
    try {
      const bytes = await readFile(p)
      if (bytes.byteLength > KIMI_IMG_MAX_BYTES) throw new Error('图片超过 20MB 上限：' + p)
      return { bytes, path: p }
    } catch (e) {
      lastErr = e
    }
  }
  throw new Error('无法读取图片文件 ' + rawPath + '：' + String((lastErr && lastErr.message) || lastErr))
}

async function kimiChat(prompt, opts = {}, exec) {
  const cfg = await kimiConfig()
  const content = []
  if (opts.image_path) {
    const { bytes, path } = await loadImageBytes(opts.image_path)
    content.push({ type: 'image_url', image_url: { url: 'data:' + mimeFor(path) + ';base64,' + Buffer.from(bytes).toString('base64') } })
    content.push({ type: 'text', text: String(prompt) })
  } else {
    content.push({ type: 'text', text: String(prompt) })
  }
  const payload = {
    model: (opts.model && String(opts.model).trim()) || cfg.model,
    messages: [{ role: 'user', content }],
    max_tokens: opts.max_tokens || 4096,
  }
  if (opts.system) payload.messages.unshift({ role: 'system', content: String(opts.system) })
  // 需要严格 JSON 的调用（如 kimi_review）强制 json_object 模式
  if (opts.json_object) payload.response_format = { type: 'json_object' }

  // 单次调用 + 空内容重试一次（应对 Moonshot 瞬时抖动/空响应）
  let lastErr = null
  for (let attempt = 0; attempt < 2; attempt++) {
    if (attempt > 0) await new Promise((r) => setTimeout(r, 800))
    let res
    try {
      res = await fetch(cfg.endpoint, {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + cfg.key, 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: exec?.signal,
      })
    } catch (e) {
      lastErr = new Error('请求 Kimi API 失败：' + String((e && e.message) || e))
      continue
    }
    const raw = await res.text()
    if (!res.ok) {
      lastErr = new Error('Kimi API 报错 HTTP ' + res.status + '：' + raw.slice(0, 800))
      continue
    }
    let data
    try {
      data = JSON.parse(raw)
    } catch {
      lastErr = new Error('Kimi API 返回无法解析：' + raw.slice(0, 400))
      continue
    }
    if (data.error) {
      lastErr = new Error('Kimi API 报错：' + JSON.stringify(data.error).slice(0, 800))
      continue
    }
    const choice = data.choices && data.choices[0]
    let text = choice && choice.message && choice.message.content
    if (Array.isArray(text)) text = text.map((p) => (p && typeof p.text === 'string') ? p.text : '').join('')
    if (typeof text === 'string' && text.trim()) return { text: text.trim() }
    lastErr = new Error('Kimi API 未返回有效内容')
  }
  throw lastErr || new Error('Kimi API 未返回有效内容')
}

function kimiCallTool() {
  return defineTool({
    name: 'kimi_call',
    description: '调用 Kimi（Moonshot）API：纯文本问答，或附图片做视觉理解（image_path 传本地图片路径）。返回 Kimi 的回复文本。',
    parameters: {
      prompt: { type: 'string', description: '发给 Kimi 的指令', required: true },
      image_path: { type: 'string', description: '本地图片路径（可选；提供后做视觉理解）' },
      model: { type: 'string', description: '模型覆盖（默认 kimi-k3）' },
    },
    output: {
      schema: { type: 'object', properties: { text: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.text }],
    },
    timeoutMs: 150000,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const result = await kimiChat(args.prompt, { image_path: args.image_path, model: args.model }, exec)
      return { text: result.text }
    },
  })
}

// ---------------------------------------------------------------------------
// 状态持久化
// ---------------------------------------------------------------------------

async function readState() {
  try {
    return JSON.parse(await readFile(stateFile(), 'utf8'))
  } catch {
    return null
  }
}
async function writeState(state) {
  await mkdir(stateDir(), { recursive: true })
  await writeFile(stateFile(), JSON.stringify(state, null, 2) + '\n', 'utf8')
  return state
}
async function clearState() {
  try {
    await rm(stateFile(), { force: true })
  } catch {
    /* already gone */
  }
  return { cleared: true }
}

function orchestrateStateTool() {
  return defineTool({
    name: 'orchestrate_state',
    description: '读写长任务编排状态文件（.orchestrate/state.json）。action 为 read（读取当前状态）/ save（保存 state 参数）/ clear（清空）。用于长任务会话内断点恢复。',
    parameters: {
      action: { type: 'string', description: 'read | save | clear', required: true },
      state: { type: 'string', description: 'action=save 时传入要保存的状态 JSON 字符串' },
    },
    output: {
      schema: { type: 'object', properties: { result: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.result }],
    },
    timeoutMs: 30000,
    isConcurrencySafe: () => false,
    async execute(args) {
      const action = String(args.action || '').trim()
      if (action === 'read') {
        const state = await readState()
        return { result: state ? JSON.stringify(state, null, 2) : '（无状态文件）' }
      }
      if (action === 'save') {
        let state
        try {
          state = JSON.parse(String(args.state || ''))
        } catch {
          throw new Error('state 不是有效 JSON')
        }
        state.updated_at = new Date().toISOString()
        await writeState(state)
        return { result: '已保存到 ' + stateFile() }
      }
      if (action === 'clear') {
        await clearState()
        return { result: '已清空 ' + stateFile() }
      }
      throw new Error('action 必须是 read / save / clear')
    },
  })
}

// ---------------------------------------------------------------------------
// prompt 模板（封装层）
// ---------------------------------------------------------------------------

const PLAN_TEMPLATE = (task, context) =>
  '你是长任务规划器（只做规划，不执行任何命令）。请把下面的任务拆解为可执行的子任务计划。\n' +
  '任务：' + task + '\n' +
  (context ? '背景/约束：\n' + context + '\n' : '') +
  '输出必须是严格的 JSON（不要用 markdown 代码块包裹，不要输出任何其他文字），格式：\n' +
  '{"tasks":[{"id":1,"description":"子任务描述","acceptance_criteria":"明确的验收标准","depends_on":[]}]}\n' +
  '规则：\n' +
  '1. 拆成 3-8 个子任务，每个子任务有可验证的验收标准；\n' +
  '2. depends_on 是前置子任务 id 数组（无依赖则空数组）；\n' +
  '3. 子任务按执行顺序排列，彼此无依赖的可以并行；\n' +
  '4. 只输出 JSON。'

const SCORE_TEMPLATE = (task, criteria, result) =>
  '你是执行质量评审员（只做评审，不执行任何命令）。请根据验收标准给执行结果打分。\n' +
  '子任务：' + task + '\n' +
  '验收标准：' + criteria + '\n' +
  '执行结果：\n' + result + '\n' +
  '输出必须是严格的 JSON（不要用 markdown 代码块包裹，不要输出任何其他文字）：\n' +
  '{"score":7,"assessment":"一句话评估","issues":["问题1"],"suggestions":["改进建议1"]}\n' +
  '规则：score 为 0-10 整数，7 分及以上视为通过；未通过时 suggestions 必须给出可执行的修改意见。只输出 JSON。'

const REVIEW_TEMPLATE = (plan, results) =>
  '你是长任务最终审核员（只做审核，不执行任何命令）。请审核以下计划与执行结果，判断任务是否全部完成。\n' +
  '计划：\n' + plan + '\n' +
  '执行结果：\n' + results + '\n' +
  '输出必须是严格的 JSON（不要用 markdown 代码块包裹，不要输出任何其他文字）：\n' +
  '{"passed":true,"summary":"总体结论","issues":["遗留问题（无则空数组）"]}\n' +
  '只输出 JSON。'

const SUMMARIZE_TEMPLATE = (text, maxChars) =>
  '请把下面的内容压缩成不超过 ' + maxChars + ' 字的摘要，保留关键事实、数字、文件路径和结论，去掉客套话：\n\n' + text

const CROSS_REVIEW_TEMPLATE = (result, criteria) =>
  '你是独立评审员。请对以下执行结果做第二次独立评估（不受已有评分影响），判断是否达到验收标准：\n' +
  '验收标准：' + criteria + '\n' +
  '执行结果：\n' + result + '\n' +
  '输出必须是严格的 JSON（不要用 markdown 代码块包裹，不要输出任何其他文字）：\n' +
  '{"agree":true,"score":8,"concerns":["疑虑（无则空数组）"]}\n' +
  '只输出 JSON。'

function parseStrictJson(text) {
  const cleaned = String(text).trim().replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/, '')
  const start = cleaned.indexOf('{')
  const end = cleaned.lastIndexOf('}')
  if (start === -1 || end === -1 || end <= start) {
    throw new Error('模型未返回 JSON：' + cleaned.slice(0, 300))
  }
  try {
    return JSON.parse(cleaned.slice(start, end + 1))
  } catch (e) {
    throw new Error('模型返回的 JSON 无法解析：' + cleaned.slice(0, 300))
  }
}

function codexPlanTool() {
  return defineTool({
    name: 'codex_plan',
    description: '用 Codex 把长任务拆解为子任务计划（JSON：tasks[{id,description,acceptance_criteria,depends_on}]）。task 为任务描述，context 为可选背景约束。',
    parameters: {
      task: { type: 'string', description: '长任务描述', required: true },
      context: { type: 'string', description: '背景/约束（可选）' },
      model: { type: 'string', description: 'Codex 模型覆盖（可选）' },
    },
    output: {
      schema: { type: 'object', properties: { text: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.text }],
    },
    timeoutMs: 600000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const result = await serialized(() => runCodex(PLAN_TEMPLATE(args.task, args.context), { model: args.model }, exec))
      const plan = parseStrictJson(result.text)
      return { text: '长任务计划：\n' + JSON.stringify(plan, null, 2) }
    },
  })
}

function codexScoreTool() {
  return defineTool({
    name: 'codex_score',
    description: '用 Codex 给执行结果打分（0-10，7 分及格），返回 JSON：{score,assessment,issues,suggestions}。task/criteria 为子任务描述与验收标准，result 为执行结果。',
    parameters: {
      task: { type: 'string', description: '子任务描述', required: true },
      criteria: { type: 'string', description: '验收标准', required: true },
      result: { type: 'string', description: '执行结果内容', required: true },
      model: { type: 'string', description: 'Codex 模型覆盖（可选）' },
    },
    output: {
      schema: { type: 'object', properties: { text: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.text }],
    },
    timeoutMs: 600000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const result = await serialized(() => runCodex(SCORE_TEMPLATE(args.task, args.criteria, args.result), { model: args.model }, exec))
      const parsed = parseStrictJson(result.text)
      const score = typeof parsed.score === 'number' ? parsed.score : Number(parsed.score) || 0
      const suggestions = Array.isArray(parsed.suggestions) ? parsed.suggestions.map(String) : []
      const issues = Array.isArray(parsed.issues) ? parsed.issues.map(String) : []
      return {
        text: 'Codex 评分：' + score + '/10' + (score >= 7 ? '（通过）' : '（未通过）') +
          '\n评估：' + String(parsed.assessment || '') +
          (issues.length ? '\n问题：' + issues.join('；') : '') +
          (suggestions.length ? '\n修改建议：' + suggestions.join('；') : ''),
      }
    },
  })
}

function codexReviewTool() {
  return defineTool({
    name: 'codex_review',
    description: '用 Codex 对整轮长任务做最终审核，返回 JSON：{passed,summary,issues}。plan 为计划 JSON 文本，results 为各子任务执行结果汇总。',
    parameters: {
      plan: { type: 'string', description: '计划（codex_plan 的输出）', required: true },
      results: { type: 'string', description: '各子任务执行结果汇总', required: true },
      model: { type: 'string', description: 'Codex 模型覆盖（可选）' },
    },
    output: {
      schema: { type: 'object', properties: { text: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.text }],
    },
    timeoutMs: 600000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const result = await serialized(() => runCodex(REVIEW_TEMPLATE(args.plan, args.results), { model: args.model }, exec))
      const parsed = parseStrictJson(result.text)
      const passed = parsed.passed === true
      const issues = Array.isArray(parsed.issues) ? parsed.issues.map(String) : []
      return {
        text: (passed ? '✅ Codex 终审通过：' : '❌ Codex 终审未通过：') + String(parsed.summary || '') +
          (issues.length ? '\n遗留问题：' + issues.join('；') : ''),
      }
    },
  })
}

function kimiSummarizeTool() {
  return defineTool({
    name: 'kimi_summarize',
    description: '用 Kimi 把大段内容压缩成摘要（默认 500 字），保留关键事实/数字/路径。用于把子任务结果压缩后再喂给 Codex，控制成本。',
    parameters: {
      text: { type: 'string', description: '要压缩的原文', required: true },
      max_chars: { type: 'number', description: '摘要最大字数（默认 500）' },
    },
    output: {
      schema: { type: 'object', properties: { summary: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.summary }],
    },
    timeoutMs: 120000,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const maxChars = Number(args.max_chars) || 500
      const result = await kimiChat(SUMMARIZE_TEMPLATE(args.text, maxChars), {}, exec)
      return { summary: result.text }
    },
  })
}

function kimiReviewTool() {
  return defineTool({
    name: 'kimi_review',
    description: '用 Kimi 对执行结果做第二次独立评审（交叉验证），返回 JSON：{agree,score,concerns}。result 为执行结果，criteria 为验收标准。',
    parameters: {
      result: { type: 'string', description: '执行结果', required: true },
      criteria: { type: 'string', description: '验收标准', required: true },
    },
    output: {
      schema: { type: 'object', properties: { text: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.text }],
    },
    timeoutMs: 120000,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const result = await kimiChat(CROSS_REVIEW_TEMPLATE(args.result, args.criteria), { json_object: true }, exec)
      const parsed = parseStrictJson(result.text)
      const agree = parsed.agree === true
      const score = typeof parsed.score === 'number' ? parsed.score : Number(parsed.score) || 0
      const concerns = Array.isArray(parsed.concerns) ? parsed.concerns.map(String) : []
      return {
        text: 'Kimi 独立评审：' + score + '/10' + (agree ? '（与 Codex 结论一致）' : '（⚠️ 与 Codex 结论不一致）') +
          (concerns.length ? '\n疑虑：' + concerns.join('；') : ''),
      }
    },
  })
}

function longtaskBeginTool() {
  return defineTool({
    name: 'longtask_begin',
    description: '开始一个长任务编排：调用 Codex 生成计划并写入 .orchestrate/state.json，返回计划与状态文件路径。goal 为任务描述，context 为可选背景。',
    parameters: {
      goal: { type: 'string', description: '长任务目标', required: true },
      context: { type: 'string', description: '背景/约束（可选）' },
    },
    output: {
      schema: { type: 'object', properties: { text: { type: 'string', required: true } }, additionalProperties: false },
      render: (args, value) => [{ type: 'text', text: value.text }],
    },
    timeoutMs: 600000,
    isConcurrencySafe: () => false,
    async execute(args, exec) {
      const result = await serialized(() => runCodex(PLAN_TEMPLATE(args.goal, args.context), {}, exec))
      const plan = parseStrictJson(result.text)
      const state = {
        goal: args.goal,
        context: args.context || '',
        plan: plan.tasks || [],
        results: {},
        current_id: null,
        iterations: {},
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }
      await writeState(state)
      return { text: '长任务已初始化，状态文件：' + stateFile() + '\n\n计划：\n' + JSON.stringify(plan, null, 2) }
    },
  })
}

// ---------------------------------------------------------------------------
// 循环模板 skill
// ---------------------------------------------------------------------------

const SKILL_CONTENT = `# 长任务编排（longtask-orchestrator）

当用户提出**多步骤、可拆解、需要质量把控的长任务**时，使用本模板：**Codex 当管理层（规划/打分/审核），DSH 当执行层（你来执行），Kimi 当补充层（视觉验收/摘要/交叉验证）**。

## 核心循环

1. **初始化**：调用 \`longtask_begin(goal, context?)\`（内部会调 Codex 生成计划并写入 \`.orchestrate/state.json\`）。拿到 \`tasks\` 数组（每个含 id/description/acceptance_criteria/depends_on）。
2. **逐项执行**（按依赖拓扑序，无依赖的可并行用 subagent）：
   - 用 DSH 自己的工具（bash / 文件 / subagent）执行子任务；
   - 结果较大时先 \`kimi_summarize\` 压缩（保留关键事实/路径）；
   - 涉及图片/截图验收时用 \`kimi_call\`（image_path）做视觉确认。
3. **打分**：\`codex_score(task, criteria, result)\` → score 0-10。
   - **score ≥ 7**：通过，记录结果，更新状态文件；
   - **score < 7**：按 suggestions 修改后重做，**每项最多重试 3 次**，仍不过则暂停并向用户报告；
   - 每完成 3 项（或分数恰好卡在及格线附近时）抽样一次 \`kimi_review\` 交叉验证；若与 Codex 结论冲突，以两者中更严格者为准并说明原因。
4. **状态维护**：每完成一个子任务调用 \`orchestrate_state(save, {...})\` 更新 \`.orchestrate/state.json\`（含 results/current_id/iterations）。会话中断后可 \`orchestrate_state(read)\` 恢复续跑。
5. **最终审核**：全部子任务通过后，\`codex_review(plan, results)\` 终审；未通过则按 issues 补做。
6. **总结**：\`kimi_summarize\` 压缩全程产出，向用户输出最终报告；\`orchestrate_state(clear)\` 清理状态。

## 规则

- Codex 只做规划/打分/审核，**绝不让 Codex 执行命令**（其沙箱本身是只读）。
- 每个子任务的验收标准必须可验证（有明确产物/数字/文件）。
- Codex 不可用（登录失效/限流/超时）时：**暂停并明确告诉用户，不用 Kimi 顶替规划/评审**。
- 简单任务不要启用本模板，直接正常回答。`

// ---------------------------------------------------------------------------
// 模型组：DeepSeek + 长任务编排（delegating adapter）
// ---------------------------------------------------------------------------

const ORCHESTRATION_SYSTEM_HINT =
  '\n\n[长任务编排模式] 本会话处于长任务编排模式：面对多步骤长任务时，请遵循 longtask-orchestrator skill 的循环模板，用 codex_plan/codex_score/codex_review 做规划打分审核，用 kimi_summarize/kimi_review/kimi_call 做补充，用 orchestrate_state 维护状态。简单问题照常直接回答。'

function registerOrchestrateRoute(ctx) {
  const ROUTE = 'deepseek-orchestrate'
  const BASE = 'deepseek-official'
  const baseAdapter = () => {
    try {
      return ctx.llm.registration(BASE).adapter
    } catch {
      return undefined
    }
  }
  const adapter = {
    providerInfo(provider) {
      return { id: provider, name: 'DeepSeek + 长任务编排' }
    },
    providerRetryPolicy(provider) {
      try {
        return ctx.llm.registration(BASE).retryPolicy
      } catch {
        return undefined
      }
    },
    async listModels(provider) {
      const base = baseAdapter()
      if (!base || typeof base.listModels !== 'function') return []
      try {
        const listed = await base.listModels(BASE)
        return (Array.isArray(listed) ? listed : []).map((m) => ({
          ...m,
          provider,
          id: m.id,
          name: (m.name || m.id) + '（编排）',
        }))
      } catch {
        return []
      }
    },
    async resolveModel(provider, model, signal) {
      const base = baseAdapter()
      if (!base || typeof base.resolveModel !== 'function') {
        return { provider, id: model, name: model + '（编排）' }
      }
      try {
        const meta = await base.resolveModel(BASE, model, signal)
        return { ...meta, provider, id: model, name: ((meta && meta.name) || model) + '（编排）' }
      } catch {
        return { provider, id: model, name: model + '（编排）' }
      }
    },
    async *stream(options) {
      const base = baseAdapter()
      if (!base || typeof base.stream !== 'function') {
        throw new Error('deepseek-official 适配器未就绪，无法使用「长任务编排」模型组')
      }
      const system = typeof options.system === 'string' ? options.system : ''
      yield* base.stream({ ...options, system: system + ORCHESTRATION_SYSTEM_HINT })
    },
  }
  const handle = ctx.llm.registerAdapter([ROUTE], adapter)
  ctx.effect(() => handle, 'dsh-longtask-orchestrator: adapter route')
}

// ---------------------------------------------------------------------------
// 插件入口
// ---------------------------------------------------------------------------

export default {
  name: 'dsh-longtask-orchestrator',
  // Cordis reads dependency requirements from the plugin object itself.
  // A separate named export is ignored by the loader.
  inject: ['tools', 'llm'],
  apply(ctx) {
    const tools = [
      codexCallTool(),
      kimiCallTool(),
      codexPlanTool(),
      codexScoreTool(),
      codexReviewTool(),
      kimiSummarizeTool(),
      kimiReviewTool(),
      orchestrateStateTool(),
      longtaskBeginTool(),
    ]
    for (const tool of tools) {
      ctx.effect(() => ctx.tools.register(tool))
    }

    // skill：长任务匹配时自动触发
    const skills = ctx.get('skills')
    if (skills !== undefined && typeof skills.register === 'function') {
      ctx.effect(() =>
        skills.register({
          name: 'longtask-orchestrator',
          title: '长任务编排 · Long-task Orchestrator',
          description:
            '多步骤长任务的规划-执行-打分-审核闭环：Codex 负责规划/协调/打分/审核，DSH 负责执行，Kimi 负责视觉验收/摘要/交叉验证｜ Plan-execute-score-review loop for long tasks: Codex plans/scores/reviews, DSH executes, Kimi supplements (vision/summary/cross-check)',
          whenToUse:
            '任务是多步骤、可拆解、需要质量把控的长任务（如：调研并产出报告、批量处理文件、多阶段开发、需要反复验证的工作）时使用。Use when the task is multi-step, decomposable, and needs quality control across stages.',
          source: 'dsh-longtask-orchestrator',
          content: SKILL_CONTENT,
        }),
      )
    }

    // 模型组：DeepSeek + 长任务编排
    registerOrchestrateRoute(ctx)

    console.log('[dsh-longtask-orchestrator] 已加载：codex/kimi 桥接工具 ×9、longtask-orchestrator skill、deepseek-orchestrate 模型组')
  },
}
