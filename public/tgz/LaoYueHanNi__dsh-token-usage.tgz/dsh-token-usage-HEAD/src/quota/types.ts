/**
 * The provider quota adapter contract (node half). One adapter owns one
 * provider family's quota endpoint: how to decide the route belongs to it
 * (`matches`) and how to query + normalize the response into the wire's
 * `QuotaWindow` vocabulary (`query`). The registry routes by provider route
 * key and base-URL host; adding a provider is one new file plus one
 * registry line — the shape cc-switch's `coding_plan.rs` proved out.
 *
 * Endpoint/field knowledge here comes from the cc-switch provider-usage
 * research (PROVIDER_USAGE_RESEARCH.md), whose endpoints are lifted from
 * working implementations.
 *
 * @module token-usage/quota/types
 */

import type { QuotaErrorKind, QuotaWindow } from '../wire.ts'

/** What an adapter sees when deciding whether it handles a route. */
export interface QuotaMatchInput {
  /** Provider route key exactly as session events carry it — the pi-ai
   * settings dict key (`zai-coding-cn`, `minimax`, a user-declared name)
   * or the direct adapter's `deepseek-official`. */
  provider: string
  /** The provider's inference base URL when one is resolvable (the
   * settings profile's `baseURL` override, else the catalog default);
   * undefined when neither is known. */
  baseUrl?: string
}
/** One DeepSeek account purse the host account service reports. Structural
 * on purpose: the plugin does not import the account package. */
export interface AccountPurseWallet {
  currency: string
  balance: string
}

/** The host account service's balance projection, or the failed variant. */
export interface AccountPurseBalance {
  status: 'ready' | 'failed'
  value?: readonly AccountPurseWallet[]
  bonusWallets?: readonly AccountPurseWallet[]
}

/** Reads the signed-in DeepSeek account's wallets. `null` means signed out
 * or the grant changed mid-query — the same signal `getBalance` returns. */
export type AccountBalanceReader = () => Promise<AccountPurseBalance | null>

/** Everything one adapter query needs; the service resolves and injects. */
export interface QuotaQueryContext {
  /** Provider route key (for diagnostics and per-provider behavior). */
  provider: string
  /** Resolved inference base URL (may influence host/station choice). */
  baseUrl?: string
  /** The provider's API key, resolved through the credentials seam.
   * Empty when the adapter does not use an API key. */
  apiKey: string
  /** The model id the asking session's request used (or the model chip
   * selected), when one is known — adapters that aggregate a whole
   * gateway's upstreams (magpie) filter their cards by it. */
  model?: string
  /** Deadline signal; the service stamps one per query. */
  signal?: AbortSignal
  /** Transport to use — global fetch in production, a stub in tests. */
  fetchFn: typeof fetch
  /** Present for the DeepSeek account route: the host's `getBalance`. */
  readAccountBalance?: AccountBalanceReader
}

/** What one adapter query returns; the service layers identity metadata. */
export interface QuotaQueryResult {
  windows: QuotaWindow[]
  /** Plan tier label when the provider reports one (Zhipu `data.level`). */
  planTier?: string
}

/** One provider family's quota integration. */
export interface QuotaAdapter {
  /** Stable id surfaced in diagnostics (`zhipu-coding-plan`, …). */
  id: string
  /** Human-readable family label — diagnostics, and the qualifier the
   * service appends to a host-matched custom route's display name. */
  label: string
  /** Route keys this adapter owns by catalog identity (the pi-ai settings
   * dict keys). A route that matched without being listed here is a
   * host-matched custom name — the service qualifies its display name
   * with {@link QuotaAdapter.label} so an alias cannot claim another
   * family's windows. Absent means the adapter claims every match. */
  routes?: readonly string[]
  /** When false, the route authenticates outside the API-key chain (the
   * DeepSeek account grant). The service still calls {@link query}.
   * Absent means the adapter needs an API key. */
  usesApiKey?: boolean
  /**
   * Whether this adapter handles the route. The base-URL host is the
   * stronger signal: a user-declared pi-ai route can carry any name while
   * pointing at a known coding-plan endpoint, so adapters check the host
   * first and treat the route key as the secondary signal. Conversely a
   * route key must only match when it is unambiguous (the pi-ai
   * `moonshotai` routes are the standard API, not Kimi For Coding, so the
   * kimi adapter matches on host or the catalog route `kimi-coding`).
   */
  matches(input: QuotaMatchInput): boolean
  /** Per-query deadline override, ms. Absent reads the service default —
   * an adapter whose gateway relays to upstreams with a longer deadline
   * of their own (magpie's 12s fan-out) raises it so the client does not
   * cut the relay off first. */
  queryTimeoutMs?: number
  /** Query the provider's quota endpoint and normalize the windows.
   * Transport failures throw {@link QuotaQueryError} with the normalized
   * kind; anything else is treated as a parse failure by the service. */
  query(ctx: QuotaQueryContext): Promise<QuotaQueryResult>
}

/** A quota query failure with its normalized wire kind. */
export class QuotaQueryError extends Error {
  constructor(readonly kind: QuotaErrorKind, message: string) {
    super(message)
    this.name = 'QuotaQueryError'
  }
}
