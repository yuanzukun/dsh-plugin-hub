/**
 * Composer-dock usage pill cost-figure inflate animation: per-request
 * intensity from token deltas and the parameters for `costPop`. Pure
 * functions only — the hook owns timers and DOM.
 *
 * @module token-usage/client/cost-inflate
 */

import type { UsageTotals } from '../wire.ts'

const MISS_RATE_CAP = 0.55
const OUT_CAP = 32_000

/** Clamp to the unit interval. */
export function clamp01(n: number): number {
  return Math.max(0, Math.min(1, n))
}

/** Token totals of one refresh minus the previous snapshot (non-negative). */
export function deltaTotals(prev: UsageTotals, next: UsageTotals): UsageTotals {
  return {
    requests: Math.max(0, next.requests - prev.requests),
    inputTokens: Math.max(0, next.inputTokens - prev.inputTokens),
    outputTokens: Math.max(0, next.outputTokens - prev.outputTokens),
    cacheReadTokens: Math.max(0, next.cacheReadTokens - prev.cacheReadTokens),
    cacheWriteTokens: Math.max(0, next.cacheWriteTokens - prev.cacheWriteTokens),
  }
}

/**
 * Single-step intensity from the latest request's token delta (not session
 * cumulative hit rate): `I = clamp01(0.55·norm(miss) + 0.45·norm(output))`.
 */
export function computeIntensityFromDelta(delta: UsageTotals): number {
  const served = delta.inputTokens + delta.cacheReadTokens
  const hitRate = served > 0 ? delta.cacheReadTokens / served : 0.5
  const miss = clamp01((1 - hitRate) / MISS_RATE_CAP)
  const out = clamp01(delta.outputTokens / OUT_CAP)
  return clamp01(0.55 * miss + 0.45 * out)
}

/** Parameters driving `costPop` for one request step. */
export interface CostInflateVars {
  inflateMs: number
  popScale: string
  warnMix: string
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t
}

/** Map step intensity I to animation parameters. */
export function animVars(I: number): CostInflateVars {
  const inflateMs = Math.round(lerp(1000, 1800, I))
  return {
    inflateMs,
    popScale: lerp(1.08, 1.32, I).toFixed(3),
    warnMix: `${Math.round(lerp(0, 55, I))}%`,
  }
}
