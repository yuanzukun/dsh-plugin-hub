/**
 * Browser half of the token-usage plugin. Two registrations share one
 * dictionary pair: the Token Usage stats page on the settings surface (data
 * from the host half's stats route, `/token-usage/stats`), and the plugin
 * configuration card on the Plugins tab (the `token-usage` settings
 * namespace — the data directory and the pricing region — edited through
 * the settings scope, with the relocation progress polled from
 * `/token-usage/migration`). The card's browse button rides the shell's
 * workspace navigation service (`ctx.uiWorkspace.pickDirectory`), the same
 * native directory picker the workspace flows use. Export discipline: the
 * /client entry exposes only what cordis loading needs.
 *
 * @module token-usage/client
 */

// dsh 0.1.2 removed dsh-client-runtime; its ClientContext was a plain alias
// of the cordis Context, so the type now comes from cordis directly.
// Type-only: pulls the ctx.slots declaration merge (owned by ui-renderer,
// whose published types no longer re-declare it through ui-session).
import type { Context as ClientContext } from '@deepseek-ai/cordis'
import type {} from '@deepseek-ai/dsh-client-ui-renderer/client'
// Type-only: pulls ctx.uiWorkspace (directory picker) into this program.
import type {} from '@deepseek-ai/dsh-client-ui-workspace/client'
// Type-only: pulls the ui-settings SlotMap merge ('settings.section') and the
// owner-share type into this program.
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
// Type-only: pulls the ui-settings-plugins keyed-slot declaration
// ('settings.plugin.item') into this program. The value face stays
// uncompromised: cross-plugin collaboration goes through the slot system.
import type {} from '@deepseek-ai/dsh-client-ui-settings-plugins/client'
// Type-only: pulls the ui-sidebar SlotMap merge ('sidebar.panellist.actions',
// dsh 0.2.1-rc.3+) into this program.
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
// Type-only: pulls the ui-layout SlotMap merge ('main' keyed) and the
// MainPanelId brand the layout service's selectPanel takes.
import type { MainPanelId } from '@deepseek-ai/dsh-client-ui-layout/client'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    /**
     * A bundle's own configuration on the Plugins page, keyed by package name.
     */
    'plugins.bundle.config': { kind: 'keyed'; scope: 'root'; owner: { readonly view: 'summary' | 'page' } }
  }
}
// Type-only: pulls the ui-conversation SlotMap merge ('conversation.view')
// so the Usage view tab registers against the same slot the Chat and
// Trajectory tabs live in. No runtime import — the slot service provides
// the standard kit (useSession/useSessions/useProjection/sessionId).
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
// Type-only: pulls the locale service's Context merge (ctx.locale) and the
// shared `common` vocabulary into the `t` seat's key domain.
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { ISessions } from '@deepseek-ai/dsh-api-session-controller/client'
import type { UiWorkspace } from '@deepseek-ai/dsh-client-ui-workspace/client'
import type { SessionId } from '@deepseek-ai/dsh-client-connection/client'

interface WorkspaceItemLike {
  readonly workspaceId: string
  readonly sessionIds: readonly SessionId[]
}

interface WorkspaceSnapshotLike {
  readonly items: readonly WorkspaceItemLike[]
  readonly phase?: 'pending' | 'ready'
}

interface WorkspacesLike {
  readonly list?: {
    getSnapshot(): WorkspaceSnapshotLike
  }
}
import { CardForm, createFallbackTarget, type CardFormTarget, type SectionValue } from './card-form.ts'
import { CostPill } from './CostPill.tsx'
import { PanellistMoreEntry } from './PanellistMoreEntry.tsx'
import { PanellistPinEntry } from './PanellistPinEntry.tsx'
import { QuotaButton, type ModelSelectionSource } from './QuotaButton.tsx'
import { TokenUsageCard } from './TokenUsageCard.tsx'
import { TokenUsageSection } from './TokenUsageSection.tsx'
import { UsagePanelPage } from './UsagePanelPage.tsx'
import { UsageView } from './UsageView.tsx'
import { en, NS, zh } from './locales.ts'

/**
 * Namespace of the token-usage settings section. Spelled here rather than
 * imported: a client package must not depend on a Host package.
 */
const TOKEN_USAGE_NS = 'token-usage'

/**
 * Main-panel id shared by the sidebar "More" menu row and the page it
 * opens. The `main` slot's key domain is open (keyed); the branded
 * assertion names the panel for the layout service's selectPanel.
 */
const USAGE_PANEL_ID = 'token-usage' as MainPanelId

/**
 * Candidate keys under which the Host may serve this plugin's settings
 * form. The 0.1.7 host keys `ConfigForms.get` by the plugin's ENTRY ID (the
 * namespace); the full package name stays as a fallback for a host that keyed
 * it by package instead.
 */
const CONFIG_FORM_KEYS = [TOKEN_USAGE_NS, '@laoyuehanni/dsh-token-usage'] as const

/** Minimal describe-mirror face: the served namespaces, subscription, first read. */
interface DescribeMirrorLike {
  getSnapshot(): { view?: { namespaces?: ReadonlyArray<{ ns: string }> } }
  subscribe(listener: () => void): () => void
  ensure?(): Promise<void>
}

/** The `configForms` service face as this plugin consumes it. */
interface ConfigFormsLike {
  /** Entry-id keyed form controller; the 0.1.7 host NEVER returns undefined. */
  get<T>(entryId: string): CardFormTarget<T>
  /** The shared describe mirror the forms derive from. */
  describe?(): DescribeMirrorLike | undefined
}

/**
 * Resolve the form target from the describe mirror's LIVE namespace list.
 * The 0.1.7 `ConfigForms.get()` unconditionally creates and caches a
 * controller for ANY key — it never returns undefined — so key validity must
 * come from the namespaces the mirror actually serves. A `get()` on a key the
 * mirror does not list yields a controller stuck at 'unavailable' forever,
 * and the card renders nothing. No view yet (mirror still loading) answers
 * undefined so the caller keeps its current target.
 */
const resolveConfigFormsTarget = (forms: ConfigFormsLike): CardFormTarget<SectionValue> | undefined => {
  const namespaces = typeof forms.describe === 'function'
    ? forms.describe()?.getSnapshot()?.view?.namespaces
    : undefined
  if (namespaces === undefined) return undefined
  const served = CONFIG_FORM_KEYS.find(key => namespaces.some(row => row.ns === key))
  return served === undefined ? undefined : forms.get<SectionValue>(served)
}

/** Required services: the slot registry, the locale dictionaries, the
 * workspace navigation service (its native directory picker backs the card's
 * browse button), and the session controller (the stats page's Ctrl+click
 * session jump reads the list and opens the target). Configuration sources
 * (`configForms` in dsh 0.1.7+, `settingsScope` in pre-0.1.7) attach dynamically. */
export const inject = ['slots', 'locale', 'connection', 'remote', 'uiWorkspace', 'sessions', 'workspaces']

/**
 * Register the dictionary pair, then the settings page and the plugin
 * configuration card once the shell's declarations are on the ledger.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'token-usage: dictionaries')
  // Stable per-namespace translate reading the active locale at call time;
  // the label thunk re-evaluates it per read, so the nav row follows switches.
  const t = ctx.locale.bind(NS)
  // The stats page's session jump: the pure predicate drives the Ctrl-hover
  // affordance (a session outside the controller's list — archived, or a
  // pre-install log row the list never saw — renders no dashed underline and
  // refuses the click), and the jump closes the settings panel and opens the
  // session via uiWorkspace.openSession.
  const getSessions = (): ISessions | undefined =>
    (ctx.get?.('sessions') as ISessions | undefined) ?? (ctx as unknown as { sessions?: ISessions }).sessions
  const getUiWorkspace = (): UiWorkspace | undefined =>
    (ctx.get?.('uiWorkspace') as UiWorkspace | undefined) ?? (ctx as unknown as { uiWorkspace?: UiWorkspace }).uiWorkspace
  const getWorkspaces = (): WorkspacesLike | undefined =>
    (ctx.get?.('workspaces') as WorkspacesLike | undefined) ?? (ctx as unknown as { workspaces?: WorkspacesLike }).workspaces

  const isSessionInController = (id: string): boolean => {
    const list = getSessions()?.list?.getSnapshot()
    return list?.byId?.[id as SessionId] !== undefined
  }

  const isWorkspaceAlive = (id: string): boolean => {
    const ws = getWorkspaces()?.list?.getSnapshot()
    if (!ws || ws.phase === 'pending') return true
    const sid = id as SessionId
    return ws.items.some(item => item.sessionIds.includes(sid))
  }

  const sessionListed = (id: string): boolean => {
    return isSessionInController(id) && isWorkspaceAlive(id)
  }

  const openSession = (id: string): { ok: boolean; reason?: 'workspaceDeleted' | 'sessionNotFound' } => {
    if (!isSessionInController(id)) return { ok: false, reason: 'sessionNotFound' }
    if (!isWorkspaceAlive(id)) return { ok: false, reason: 'workspaceDeleted' }
    getUiWorkspace()?.openSession(id as SessionId)
    return { ok: true }
  }
  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'token-usage',
    order: 50,
    label: () => t('nav.label'),
    locale: NS,
    inject: () => ({ sessionListed, openSession }),
  }, TokenUsageSection))

  // The main panel the sidebar entries open (the `main` keyed slot, an older
  // shell declaration than the sidebar regions). It rides ctx.slots.inject
  // WAITING on the shell's declaration — a shell without it never runs the
  // callback, so the page degrades silently and the settings section above
  // stays the only entry. The layout seat is resolved at click time (dynamic
  // like configForms below, never a top-level inject dependency): the sidebar
  // entries open this panel, and the page's session jump returns to the
  // conversation. The two sidebar entries themselves (the More-menu row and
  // the resident pinned row) register further down in syncEntries — the two
  // are mutually exclusive, so their registrations come and go with the
  // `sidebarPinned` setting.
  const selectMainPanel = (id: MainPanelId | null): void => {
    ;(ctx.get?.('layout') as { selectPanel?: (id: MainPanelId | null) => void } | undefined)?.selectPanel?.(id)
  }
  ctx.slots.inject('main', () => ctx.slots.register({
    name: 'main',
    key: USAGE_PANEL_ID,
    locale: NS,
    inject: () => ({ sessionListed, openSession, returnToConversation: () => selectMainPanel(null) }),
  }, UsagePanelPage))

  // The Usage view tab: one entry of the conversation view ring (beside the
  // built-in Chat tab and the Trajectory tab from ui-trajectory, rendered
  // by the session header's tab ring, one at a time). Registration is the
  // same trajectory pattern — a label thunk follows the active locale, and
  // the component reads the session through the standard kit.
  ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    id: 'usage',
    order: 20,
    label: () => t('view.usage'),
    locale: NS,
  }, UsageView))

  // The composer-dock usage pill: one entry of the
  // `conversation.composer.dock` slot list (`order: 10`, after the
  // official stats pills' `order: 0`), wearing the official pill skin so
  // the row reads as one family. The figure is the WITH-SUBAGENTS fold —
  // the one number no official surface carries; a solo session renders it
  // bare, and a subtree scope adds a quiet "with subagents" badge. The
  // click-open detail panel carries the folded token figure and cache-hit
  // rate (official pills show only the single-session token count), the
  // session / subagents split, and the per-model breakdown. The component
  // self-gates: a session with zero recorded requests renders nothing; a
  // transient fetch miss keeps the previous render.
  ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register({
    name: 'conversation.composer.dock',
    id: 'token-usage-cost',
    order: 10,
    locale: NS,
  }, CostPill))

  // The input-bar quota button: one entry of the `conversation.input.right`
  // slot list (the tool row's right end, before the send button — the host
  // renders slot entries left of the model chip). The button polls the
  // host's `/token-usage/quota` route for the ACTIVE session's provider and
  // self-gates: it renders nothing while the provider is undeterminable or
  // has no quota adapter, so the toolbar stays clean on unsupported
  // providers and the button reappears when a supported one takes over.
  // `order: 10` keeps it after any future lower-order utilities in the
  // same slot.
  //
  // Provider resolution follows the model CHIP: the shell's model-selection
  // service (`ctx.modelDirectories`, from ui-model-selection — the same
  // shared per-session directory the chip renders from) reports the host's
  // NEXT selection live, so the button appears the moment the user picks a
  // provider, before any request is sent. The service attaches through an
  // OPTIONAL inject — a shell without it falls back to the host's own
  // resolution (last request's provider, else the default selection).
  const modelDirectory: { service: ModelSelectionSource | undefined } = { service: undefined }
  ctx.inject(['modelDirectories'], (modelCtx) => {
    modelCtx.effect(() => {
      modelDirectory.service = (modelCtx as unknown as { modelDirectories?: ModelSelectionSource }).modelDirectories
      return () => { modelDirectory.service = undefined }
    }, 'token-usage: model directory seam')
  })
  ctx.slots.inject('conversation.input.right', () => ctx.slots.register({
    name: 'conversation.input.right',
    id: 'token-usage-quota',
    order: 10,
    locale: NS,
    inject: () => ({ modelDirectory }),
  }, QuotaButton))

  // Configuration source resolution:
  // - dsh 0.1.7+: ctx.configForms provides ConfigForm (keyed by the entry id
  //   the describe mirror actually serves; see resolveConfigFormsTarget)
  // - pre-0.1.7: ctx.settingsScope provides SettingsScope (bound by namespace)
  // - fallback: unavailable target preventing runtime errors if neither is mounted
  const lookupCurrentTarget = (): CardFormTarget<SectionValue> | undefined => {
    const configForms = ctx.get('configForms') as ConfigFormsLike | undefined
    if (configForms && typeof configForms.get === 'function') {
      const byMirror = resolveConfigFormsTarget(configForms)
      if (byMirror !== undefined) return byMirror
    }
    const settingsScope = ctx.get('settingsScope') as {
      bind<T>(options: { namespace: string }): CardFormTarget<T>
    } | undefined
    if (settingsScope && typeof settingsScope.bind === 'function') {
      return settingsScope.bind<SectionValue>({ namespace: TOKEN_USAGE_NS })
    }
    return undefined
  }

  const initialTarget = lookupCurrentTarget()
  let activeTarget: CardFormTarget<SectionValue> = initialTarget ?? createFallbackTarget()
  const targetListeners = new Set<() => void>()
  let unsubActive: (() => void) | undefined = activeTarget.subscribe(() => {
    for (const listener of targetListeners) listener()
  })

  const switchTarget = (next: CardFormTarget<SectionValue>): void => {
    if (next === activeTarget) return
    unsubActive?.()
    activeTarget = next
    unsubActive = activeTarget.subscribe(() => {
      for (const listener of targetListeners) listener()
    })
    for (const listener of targetListeners) listener()
  }

  ctx.inject(['configForms'], (configCtx) => {
    configCtx.effect(() => {
      const forms = configCtx.get('configForms') as ConfigFormsLike | undefined
      if (!forms || typeof forms.get !== 'function') return () => {}
      // The describe mirror loads asynchronously (its first snapshot holds no
      // view), so besides resolving now, follow the mirror: the moment the
      // namespace appears — or the host re-keys it — re-resolve and bind.
      const mirror = typeof forms.describe === 'function' ? forms.describe() : undefined
      const resolve = (): void => {
        const target = resolveConfigFormsTarget(forms)
        if (target !== undefined) switchTarget(target)
      }
      resolve()
      void mirror?.ensure?.()
      const unsubscribe = mirror?.subscribe(() => { resolve() })
      return () => { unsubscribe?.() }
    }, 'token-usage: configForms dynamic target')
  })

  ctx.inject(['settingsScope'], (scopeCtx) => {
    scopeCtx.effect(() => {
      const scopeService = scopeCtx.get('settingsScope') as {
        bind<T>(options: { namespace: string }): CardFormTarget<T>
      } | undefined
      if (scopeService && typeof scopeService.bind === 'function') {
        switchTarget(scopeService.bind<SectionValue>({ namespace: TOKEN_USAGE_NS }))
      }
      return () => {}
    }, 'token-usage: settingsScope dynamic target')
  })

  const dynamicTarget: CardFormTarget<SectionValue> = {
    getSnapshot: () => activeTarget.getSnapshot(),
    subscribe: (listener) => {
      targetListeners.add(listener)
      return () => { targetListeners.delete(listener) }
    },
    set: (field, value) => activeTarget.set(field, value),
    unset: (field) => activeTarget.unset(field),
  }

  // The two sidebar entries are mutually exclusive — exactly one exists at
  // any time. The `sidebarPinned` volatile setting picks which: while it
  // reads true the usage entry is a resident `sidebar.panellist` row, and the
  // More-menu row is gone; while it reads false the More-menu row is back and
  // the resident row is gone (the shell's pin store is in-memory, so
  // registration alone IS the durable pin — no shell API is driven). Both
  // registrations wait on their shell declarations via slots.inject (old
  // shells never run those callbacks, so the entry degrades silently to the
  // settings section); a rejected cell (a same-priority occupant) likewise
  // just means that entry stays absent.
  let residentDisposer: (() => void) | undefined
  let moreDisposer: (() => void) | undefined
  const syncEntries = (): void => {
    const pinned = activeTarget.getSnapshot().value?.sidebarPinned === true
    if (pinned && residentDisposer === undefined) {
      try {
        residentDisposer = ctx.slots.register({
          name: 'sidebar.panellist',
          id: USAGE_PANEL_ID,
          order: 50,
          locale: NS,
          label: () => t('nav.label'),
        }, PanellistPinEntry)
      } catch {
        residentDisposer = undefined
      }
    } else if (!pinned && residentDisposer !== undefined) {
      const dispose = residentDisposer
      residentDisposer = undefined
      dispose()
    }
    if (!pinned && moreDisposer === undefined) {
      try {
        moreDisposer = ctx.slots.register({
          name: 'sidebar.panellist.actions',
          id: 'token-usage-more',
          order: 50,
          locale: NS,
          inject: () => ({ openPanel: () => selectMainPanel(USAGE_PANEL_ID) }),
        }, PanellistMoreEntry)
      } catch {
        moreDisposer = undefined
      }
    } else if (pinned && moreDisposer !== undefined) {
      const dispose = moreDisposer
      moreDisposer = undefined
      dispose()
    }
  }
  ctx.slots.inject('sidebar.panellist', () => { syncEntries(); return () => {} })
  ctx.slots.inject('sidebar.panellist.actions', () => { syncEntries(); return () => {} })
  ctx.effect(() => {
    targetListeners.add(syncEntries)
    syncEntries()
    return () => {
      targetListeners.delete(syncEntries)
      if (residentDisposer !== undefined) {
        const dispose = residentDisposer
        residentDisposer = undefined
        dispose()
      }
      if (moreDisposer !== undefined) {
        const dispose = moreDisposer
        moreDisposer = undefined
        dispose()
      }
    }
  }, 'token-usage: sidebar entries sync')

  // The Plugins page dispatches keyed configuration for bundles through
  // `plugins.bundle.config` (keyed by the bundle's package name).
  const form = new CardForm(dynamicTarget)
  const store = form.bind()
  ctx.slots.inject('plugins.bundle.config', () => ctx.slots.register({
    name: 'plugins.bundle.config',
    key: '@laoyuehanni/dsh-token-usage',
    locale: NS,
    inject: () => ({
      hooks: { tokenUsageCard: store },
      ...form.actions(),
      // The shell's own directory picker (the workspace flows' chooser):
      // resolves the chosen absolute path, or null when the user dismisses.
      pickDirectory: () => (ctx.get('uiWorkspace') as {
        pickDirectory?: () => Promise<string | null>
      } | undefined)?.pickDirectory?.() ?? Promise.resolve(null),
    }),
  }, TokenUsageCard))
}
