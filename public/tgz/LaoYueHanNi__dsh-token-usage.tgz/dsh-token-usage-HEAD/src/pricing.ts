/**
 * Pricing vocabulary and store of the token-usage plugin: the per-model
 * price rules (¥ per million tokens) backing the cost figures of the stats
 * page. The single source is the cloud feed mirrored on every dsh startup
 * into `<data dir>/pricing.ccsa.json` (the same model-price-table source
 * cc-switch-analyzer pulls); an absent or malformed mirror reports costs
 * unavailable while usage remains readable. Pricing
 * data used to layer a hand-edited `pricing.json` on top, but that path was
 * removed (see docs/decisions/implemented/2026-09-05-abolish-manual-pricing-json.md):
 * no UI entry point, wholesale-replace semantics silently drop time rules
 * and tiers, and corrections belong upstream in the model-price-table feed.
 *
 * Every record is priced individually through the analyzer's rule chain —
 * time-rule container first, then context tier, then peak slot (a slot may be
 * restricted to ISO weekdays via `daysOfWeek`, matched on the request's local
 * day) — and the aggregation keeps rows per (day, model, rate identity), so
 * a pricing-context change rebuilds stored identities from raw history.
 * Context size is approximated by the request's input-side tokens (input +
 * cacheRead + cacheWrite): the log does not carry the raw context size.
 *
 * @module token-usage/pricing
 */

import { mkdir, readFile, rename, unlink, writeFile } from 'node:fs/promises'
import { dirname, join } from 'node:path'
import { createHash } from 'node:crypto'
import { createModelResolver, modelKey, validateModelIdentities } from './model-resolution.ts'
import { AssociationError, associationWritesPaused, pricingDirectoryEpoch, readAssociations, withPricingDirectoryRead, withPricingDirectoryWrite, type AssociationSnapshot } from './pricing-associations.ts'
import { consoleLogger, type LoggerLike } from './log.ts'
import type {
  ContextTier,
  DailySlot,
  ModelPricing,
  ModelRates,
  ModelResolution,
  PricingOverviewModel,
  PricingTable,
  PricingUnavailableReason,
  PricingAssociationStatus,
  PricingSyncResult,
  RateKey,
  TimeRule,
  UsageTotals,
} from './wire.ts'

/** The cloud-feed mirror written on every startup. */
export const PRICING_CCSA_FILE = 'pricing.ccsa.json'

/**
 * The default domestic (China) cloud pricing feed: the model-price-table
 * repository the analyzer also pulls from (¥ per million tokens, currency
 * RMB). Overridden through the `pricingUrlDomestic` config key.
 */
export const DEFAULT_PRICING_URL_DOMESTIC = 'https://gitee.com/oyw125/model-price-table/raw/master/model_pricing.json'

/**
 * The default overseas cloud pricing feed: the same model-price-table,
 * mirrored to GitHub because the gitee CDN is slow or unreliable outside
 * mainland China. Overridden through the `pricingUrlOverseas` config key.
 */
export const DEFAULT_PRICING_URL_OVERSEAS = 'https://raw.githubusercontent.com/LaoYueHanNi/model-price-table/master/model_pricing.json'

/** Backward-compatible alias: the domestic (gitee) default feed. */
export const DEFAULT_PRICING_URL = DEFAULT_PRICING_URL_DOMESTIC

/**
 * The RMB-per-USD rate used for display conversion when the cloud feed's
 * envelope does not carry a usable `usdExchangeRate` (older mirrors). The
 * feed owns the number; this is only the stand-in until it lands.
 */
export const DEFAULT_USD_EXCHANGE_RATE = 7

/** Which cloud mirror the pricing sync prefers when no explicit URL is set. */
export type PricingRegion = 'domestic' | 'overseas'

/** The URL inputs of the pricing sync: an explicit single feed, or the
 * per-region mirrors plus the chosen region. */
export interface PricingSourceInput {
  /** Explicit single feed URL; wins over every region/mirror setting. */
  pricingUrl?: string
  /** Domestic mirror override; defaults to the gitee feed. */
  pricingUrlDomestic?: string
  /** Overseas mirror override; defaults to the github feed. */
  pricingUrlOverseas?: string
  /** Which mirror to pull when `pricingUrl` is unset; defaults to `domestic`. */
  pricingRegion?: PricingRegion
}

/**
 * Resolve the feed URL to fetch: an explicit `pricingUrl` wins outright;
 * otherwise `pricingRegion` picks the domestic (default) or overseas mirror,
 * each overridable through its own key. Deliberately no IP sniffing — the
 * deployer sets the region once in the profile config, so the choice is
 * predictable and never depends on a third-party geo lookup.
 */
export function resolvePricingUrl(input: PricingSourceInput = {}): string {
  if (input.pricingUrl !== undefined) return input.pricingUrl
  if (input.pricingRegion === 'overseas') {
    return input.pricingUrlOverseas ?? DEFAULT_PRICING_URL_OVERSEAS
  }
  return input.pricingUrlDomestic ?? DEFAULT_PRICING_URL_DOMESTIC
}

/** A positive (or zero) finite number; rates may be 0 but never negative. */
function isRate(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value >= 0
}

// ---------------------------------------------------------------------------
// Cloud feed shapes (raw, as served by the model-price-table repository)
// ---------------------------------------------------------------------------

/** One raw rate node of the cloud feed. */
interface CloudRates {
  inputCostPerMillion: number
  outputCostPerMillion: number
  cacheReadCostPerMillion?: number
  cacheCreationCostPerMillion?: number
  dailySlots?: CloudSlot[]
}

/** One raw context tier of the cloud feed. */
interface CloudTier extends CloudRates {
  threshold: number
}

/** One raw time rule of the cloud feed. */
interface CloudTimeRule extends CloudRates {
  label?: string
  startTime: number
  endTime: number
  contextTiers?: CloudTier[]
}

/** One raw peak slot of the cloud feed. */
interface CloudSlot {
  label?: string
  windows: Array<{ startMinute: number; endMinute: number }>
  /** ISO weekdays 1..7 the slot applies to; absent = every day. */
  daysOfWeek?: number[]
  inputCostPerMillion: number
  outputCostPerMillion: number
  cacheReadCostPerMillion?: number
  cacheCreationCostPerMillion?: number
}

/** One raw model row of the cloud feed. */
export interface CloudPricingModel extends CloudRates {
  modelId: string
  /** Upstream family grouping (the feed's authoritative classification);
   * absent when the feed row carries none or a non-string value. */
  family?: string
  contextTiers?: CloudTier[]
  timeRules?: CloudTimeRule[]
  aliasPatterns?: string[]
}

/** The cloud feed envelope. */
export interface CloudPricingData {
  version: number
  updatedAt: number
  currency: string
  /** RMB per USD for display conversion; absent when the feed omits it or
   * the value is not a positive finite number. */
  usdExchangeRate?: number
  models: CloudPricingModel[]
}

/** A usable exchange rate: finite and strictly positive (0 would divide by zero). */
function isExchangeRate(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0
}

function coerceRates(value: unknown): CloudRates | null {
  if (typeof value !== 'object' || value === null) return null
  const node = value as Record<string, unknown>
  if (!isRate(node.inputCostPerMillion) || !isRate(node.outputCostPerMillion)) return null
  return {
    inputCostPerMillion: node.inputCostPerMillion,
    outputCostPerMillion: node.outputCostPerMillion,
    ...(isRate(node.cacheReadCostPerMillion) ? { cacheReadCostPerMillion: node.cacheReadCostPerMillion } : {}),
    ...(isRate(node.cacheCreationCostPerMillion) ? { cacheCreationCostPerMillion: node.cacheCreationCostPerMillion } : {}),
    ...(Array.isArray(node.dailySlots)
      ? { dailySlots: (node.dailySlots as unknown[]).map(coerceSlot).filter((slot): slot is CloudSlot => slot !== null) }
      : {}),
  }
}

function coerceTier(value: unknown): CloudTier | null {
  if (typeof value !== 'object' || value === null) return null
  const tier = value as Record<string, unknown>
  if (!isRate(tier.threshold)) return null
  const rates = coerceRates(value)
  return rates === null ? null : { ...rates, threshold: tier.threshold }
}

function coerceSlot(value: unknown): CloudSlot | null {
  if (typeof value !== 'object' || value === null) return null
  const slot = value as Record<string, unknown>
  if (!Array.isArray(slot.windows)) return null
  const windows: Array<{ startMinute: number; endMinute: number }> = []
  for (const window of slot.windows) {
    if (typeof window !== 'object' || window === null) continue
    const w = window as Record<string, unknown>
    if (isRate(w.startMinute) && isRate(w.endMinute)) windows.push({ startMinute: w.startMinute, endMinute: w.endMinute })
  }
  if (windows.length === 0) return null
  const rates = coerceRates(value)
  if (rates === null) return null
  // ISO weekdays 1..7 only; anything else degrades to "every day" (omit),
  // never to a slot that matches nothing.
  const days = Array.isArray(slot.daysOfWeek)
    ? [...new Set(slot.daysOfWeek.filter((day): day is number => typeof day === 'number' && Number.isInteger(day) && day >= 1 && day <= 7))]
    : []
  return {
    windows,
    inputCostPerMillion: rates.inputCostPerMillion,
    outputCostPerMillion: rates.outputCostPerMillion,
    ...(rates.cacheReadCostPerMillion !== undefined ? { cacheReadCostPerMillion: rates.cacheReadCostPerMillion } : {}),
    ...(rates.cacheCreationCostPerMillion !== undefined ? { cacheCreationCostPerMillion: rates.cacheCreationCostPerMillion } : {}),
    ...(days.length > 0 ? { daysOfWeek: days } : {}),
    ...(typeof slot.label === 'string' ? { label: slot.label } : {}),
  }
}

function coerceTimeRule(value: unknown): CloudTimeRule | null {
  if (typeof value !== 'object' || value === null) return null
  const rule = value as Record<string, unknown>
  if (!isRate(rule.startTime) || !isRate(rule.endTime)) return null
  const rates = coerceRates(value)
  if (rates === null) return null
  const tiers = Array.isArray(rule.contextTiers)
    ? (rule.contextTiers as unknown[]).map(coerceTier).filter((tier): tier is CloudTier => tier !== null)
    : []
  return {
    ...rates,
    startTime: rule.startTime,
    endTime: rule.endTime,
    ...(typeof rule.label === 'string' ? { label: rule.label } : {}),
    ...(tiers.length > 0 ? { contextTiers: tiers } : {}),
  }
}

/**
 * Coerce an unknown value into the cloud feed shape, dropping invalid model
 * rows. A wrong envelope (non-array models, non-object) reads as null, and
 * so does a non-RMB `currency` — this plugin bills in ¥ only.
 * @param value - the parsed `pricing.ccsa.json` content.
 * @returns the feed, or null when the value is not a usable RMB feed.
 */
export function coerceCloudPricing(value: unknown): CloudPricingData | null {
  if (typeof value !== 'object' || value === null) return null
  const feed = value as Record<string, unknown>
  if (!Array.isArray(feed.models)) return null
  if (typeof feed.currency !== 'string' || feed.currency !== 'RMB') return null
  const models: CloudPricingModel[] = []
  const identities: CanonicalModelRef[] = []
  for (const raw of feed.models as unknown[]) {
    if (typeof raw !== 'object' || raw === null) continue
    const row = raw as Record<string, unknown>
    // Upstream retains deprecated aliases; only aliasPatterns owns alias identity here.
    if (row.aliasPatterns !== undefined && (!Array.isArray(row.aliasPatterns)
      || !row.aliasPatterns.every(pattern => typeof pattern === 'string' && pattern !== ''))) return null
    if (typeof row.modelId === 'string' && row.modelId !== '') {
      identities.push({ modelId: row.modelId, ...(Array.isArray(row.aliasPatterns) ? { aliasPatterns: row.aliasPatterns as string[] } : {}) })
    } else if (row.aliasPatterns !== undefined) return null
    const rates = coerceRates(raw)
    if (rates === null || typeof row.modelId !== 'string' || row.modelId === '') continue
    models.push({
      ...rates,
      modelId: row.modelId,
      ...(typeof row.family === 'string' && row.family !== '' ? { family: row.family } : {}),
      ...(Array.isArray(row.contextTiers)
        ? {
          contextTiers: (row.contextTiers as unknown[]).map(coerceTier)
            .filter((tier): tier is CloudTier => tier !== null),
        }
        : {}),
      ...(Array.isArray(row.timeRules)
        ? {
          timeRules: (row.timeRules as unknown[]).map(coerceTimeRule)
            .filter((rule): rule is CloudTimeRule => rule !== null),
        }
        : {}),
      ...(Array.isArray(row.aliasPatterns) ? { aliasPatterns: row.aliasPatterns as string[] } : {}),
    })
  }
  try { validateModelIdentities(identities) } catch { return null }
  return {
    version: typeof feed.version === 'number' ? feed.version : 0,
    updatedAt: typeof feed.updatedAt === 'number' ? feed.updatedAt : 0,
    currency: feed.currency,
    ...(isExchangeRate(feed.usdExchangeRate) ? { usdExchangeRate: feed.usdExchangeRate } : {}),
    models,
  }
}

// ---------------------------------------------------------------------------
// Cloud feed → ModelRates
// ---------------------------------------------------------------------------

/** Map one raw rate node onto the wire's per-million prices. */
function toPricing(rates: CloudRates): ModelPricing {
  return {
    inputPerMillion: rates.inputCostPerMillion,
    outputPerMillion: rates.outputCostPerMillion,
    ...(rates.cacheReadCostPerMillion !== undefined ? { cacheReadPerMillion: rates.cacheReadCostPerMillion } : {}),
    ...(rates.cacheCreationCostPerMillion !== undefined ? { cacheWritePerMillion: rates.cacheCreationCostPerMillion } : {}),
  }
}

function toSlots(slots: CloudSlot[] | undefined): DailySlot[] {
  return slots?.map(slot => ({
    windows: slot.windows,
    ...(slot.daysOfWeek !== undefined ? { daysOfWeek: slot.daysOfWeek } : {}),
    rates: toPricing(slot),
    ...(slot.label !== undefined ? { label: slot.label } : {}),
  })) ?? []
}

function toTiers(tiers: CloudTier[] | undefined): ContextTier[] {
  return tiers?.map(tier => ({
    threshold: tier.threshold,
    rates: toPricing(tier),
    ...(tier.dailySlots !== undefined ? { dailySlots: toSlots(tier.dailySlots) } : {}),
  })) ?? []
}

function toTimeRules(rules: CloudTimeRule[] | undefined): TimeRule[] {
  return rules?.map(rule => ({
    startTime: rule.startTime,
    endTime: rule.endTime,
    rates: toPricing(rule),
    ...(rule.contextTiers !== undefined ? { contextTiers: toTiers(rule.contextTiers) } : {}),
    ...(rule.dailySlots !== undefined ? { dailySlots: toSlots(rule.dailySlots) } : {}),
    ...(rule.label !== undefined ? { label: rule.label } : {}),
  })) ?? []
}

/** The full rule set of one raw cloud model row. */
function cloudModelRates(model: CloudPricingModel): ModelRates {
  return {
    base: toPricing(model),
    contextTiers: toTiers(model.contextTiers),
    dailySlots: toSlots(model.dailySlots),
    timeRules: toTimeRules(model.timeRules),
  }
}

/**
 * Seed model IDs and resolve observed regex/provider names on demand.
 * Patterns cannot be expanded into a finite list of dictionary keys.
 * @param feed - the coerced cloud feed.
 * @returns a table keyed by model IDs and successfully looked-up names.
 */
export function cloudToTable(feed: CloudPricingData): PricingTable {
  const identify = createModelResolver(feed.models)
  const table = resolvedTable(name => identify(name).modelId)
  for (const model of feed.models) table[model.modelId] = cloudModelRates(model)
  return table
}

function resolvedTable(identify: (name: string) => string | undefined): PricingTable {
  const entries: PricingTable = Object.create(null)
  return new Proxy(entries, {
    get(target, key: string | symbol): unknown {
      if (typeof key !== 'string' || Object.hasOwn(target, key)) return Reflect.get(target, key)
      const id = identify(key)
      if (id === undefined) return undefined
      const rules = target[id]
      if (rules !== undefined) target[key] = rules
      return rules
    },
  })
}

/** One model row's identity for alias → modelId folding. */
export interface CanonicalModelRef {
  modelId: string
  aliasPatterns?: readonly string[]
}

/**
 * Resolve names lazily through the same ID/regex chain as pricing.
 * Only IDs and observed matches are enumerated; ambiguous names stay absent.
 * @param models - the feed's model rows (or the overview projection).
 * @returns name → modelId; unpriced names are not keys.
 */
export function canonicalMapOf(models: readonly CanonicalModelRef[]): Map<string, string> {
  const identify = createModelResolver(models)
  class CanonicalIndex extends Map<string, string> {
    override get(name: string): string | undefined {
      const id = identify(name).modelId
      if (id !== undefined) this.set(name, id)
      return id
    }
    override has(name: string): boolean { return this.get(name) !== undefined }
  }
  const map = new CanonicalIndex()
  for (const model of models) {
    map.get(model.modelId)
  }
  return map
}

/**
 * The canonical model-id of one usage name under a {@link canonicalMapOf}
 * map: a priced alias (or the modelId itself) resolves to the feed's
 * modelId; an unpriced name is returned unchanged.
 * @param name - the raw model string on a record or row.
 * @param map - the alias → modelId map; undefined / missing key → `name`.
 * @returns the name the byModel table should fold onto.
 */
export function canonicalName(name: string, map?: ReadonlyMap<string, string>): string {
  return map?.get(name) ?? map?.get(modelKey(name)) ?? name
}

// ---------------------------------------------------------------------------
// Per-record rate resolution (the analyzer's rule chain)
// ---------------------------------------------------------------------------

/** The context tier matching a context size: the highest threshold it reaches. */
function resolveTier(tiers: ContextTier[], contextSize: number): ContextTier | null {
  let best: ContextTier | null = null
  for (const tier of tiers) {
    if (tier.threshold <= contextSize && (best === null || tier.threshold > best.threshold)) best = tier
  }
  return best
}

/** The local minute-of-day of a Unix-seconds timestamp under a tz offset in hours. */
function localMinuteOfDay(epochSeconds: number, tzOffsetHours: number): number {
  const local = epochSeconds + tzOffsetHours * 3600
  const secondOfDay = ((local % 86400) + 86400) % 86400
  return Math.floor(secondOfDay / 60)
}

/** The ISO weekday (1=Monday … 7=Sunday) of a Unix-seconds timestamp under a
 * tz offset in hours: 1970-01-01 was a Thursday, so local day 0 maps to 4. */
function localWeekday(epochSeconds: number, tzOffsetHours: number): number {
  const localDay = Math.floor((epochSeconds + tzOffsetHours * 3600) / 86400)
  return (((localDay + 3) % 7) + 7) % 7 + 1
}

/** The first peak slot that applies to the timestamp — its windows contain the
 * local minute and its `daysOfWeek` (absent = every day) includes the local
 * weekday; -1 when off-peak. Slots skipped on the weekday check do not stop
 * the search, so a weekend inside a weekday-only window still bills off-peak. */
function matchingSlot(slots: DailySlot[] | undefined, epochSeconds: number, tzOffsetHours: number): number {
  if (slots === undefined || slots.length === 0) return -1
  const minute = localMinuteOfDay(epochSeconds, tzOffsetHours)
  const weekday = localWeekday(epochSeconds, tzOffsetHours)
  for (let index = 0; index < slots.length; index++) {
    const days = slots[index]!.daysOfWeek
    if (days !== undefined && days.length > 0 && !days.includes(weekday)) continue
    for (const window of slots[index]!.windows) {
      if (window.startMinute <= minute && minute < window.endMinute) return index
    }
  }
  return -1
}

/** One resolved node of the rule chain: its rates and its peak slots. */
interface RateNode {
  rates: ModelPricing
  slots: DailySlot[]
}

/**
 * Resolve the rate one request was billed at, mirroring the analyzer's chain:
 * the time rule covering the timestamp first (its tiers, its slots), else
 * the model root (its tiers, its slots), else the base rates.
 * @param rates - the model's full rule set.
 * @param timeMs - the request's epoch milliseconds.
 * @param contextTokens - the request's input-side tokens (tier approximation).
 * @param tzOffsetHours - local tz offset in hours for peak windows
 * (defaults to the host's).
 * @returns the billed prices plus the identity they resolved through.
 */
export function resolveRate(
  rates: ModelRates,
  timeMs: number,
  contextTokens: number,
  tzOffsetHours: number = -new Date().getTimezoneOffset() / 60,
): { prices: ModelPricing; key: RateKey } {
  const seconds = Math.floor(timeMs / 1000)
  const rule = rates.timeRules.find(r => seconds >= r.startTime && seconds <= r.endTime) ?? null
  const tiers = rule?.contextTiers ?? rates.contextTiers
  const tier = resolveTier(tiers, contextTokens)
  // Peak slots hang on each node itself (the rule's, the tier's, or the
  // model root's) — a rule without slots bills flat inside its window, they
  // never inherit down from the root.
  const node: RateNode = tier !== null
    ? { rates: tier.rates, slots: tier.dailySlots ?? [] }
    : rule !== null
      ? { rates: rule.rates, slots: rule.dailySlots ?? [] }
      : { rates: rates.base, slots: rates.dailySlots }
  const slot = matchingSlot(node.slots, seconds, tzOffsetHours)
  return {
    prices: slot >= 0 ? node.slots[slot]!.rates : node.rates,
    key: {
      ruleStart: rule?.startTime ?? 0,
      ruleEnd: rule?.endTime ?? 0,
      tier: tier?.threshold ?? 0,
      slot,
    },
  }
}

/**
 * Look the prices of a rate identity back up under the current rule set —
 * the re-pricing path for aggregated rows. Structural drift (a rule window
 * or tier threshold that no longer exists) falls back toward the base rates,
 * so an edited table degrades gracefully instead of mis-billing.
 * @param rates - the model's full rule set.
 * @param key - the identity one aggregation row carries.
 * @returns the prices the key resolves to.
 */
export function ratesForKey(rates: ModelRates, key: RateKey): ModelPricing {
  const rule = key.ruleStart !== 0 || key.ruleEnd !== 0
    ? rates.timeRules.find(r => r.startTime === key.ruleStart && r.endTime === key.ruleEnd) ?? null
    : null
  const tiers = rule?.contextTiers ?? rates.contextTiers
  const tier = key.tier > 0 ? tiers.find(t => t.threshold === key.tier) ?? null : null
  // Same node chain as resolveRate: peak slots hang on the node itself.
  const node: RateNode = tier !== null
    ? { rates: tier.rates, slots: tier.dailySlots ?? [] }
    : rule !== null
      ? { rates: rule.rates, slots: rule.dailySlots ?? [] }
      : { rates: rates.base, slots: rates.dailySlots }
  return key.slot >= 0 ? node.slots[key.slot]?.rates ?? node.rates : node.rates
}

/**
 * Billed cost of one totals row at resolved prices: each bucket billed at
 * its own per-million rate, cache buckets billed at their rate when present
 * and at the plain input rate otherwise (providers that fold cache tokens
 * into input still bill them, just at the same rate).
 * @param totals - the aggregated token buckets.
 * @param prices - the resolved per-million prices.
 * @returns the cost in ¥.
 */
export function costOf(totals: UsageTotals, prices: ModelPricing): number {
  const M = 1_000_000
  const cacheRead = prices.cacheReadPerMillion ?? prices.inputPerMillion
  const cacheWrite = prices.cacheWritePerMillion ?? prices.inputPerMillion
  return (totals.inputTokens * prices.inputPerMillion
    + totals.outputTokens * prices.outputPerMillion
    + totals.cacheReadTokens * cacheRead
    + totals.cacheWriteTokens * cacheWrite) / M
}

// ---------------------------------------------------------------------------
// File store: cloud mirror
// ---------------------------------------------------------------------------

/** Read one JSON file of a data directory, or null when absent/unreadable. */
async function readJsonFile(dir: string, name: string, logger: LoggerLike = consoleLogger): Promise<unknown> {
  let text: string
  try {
    text = await readFile(join(dir, name), 'utf8')
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return null
    logger.error(`[token-usage] cannot read ${name}:`, error)
    return null
  }
  try {
    return JSON.parse(text)
  } catch {
    logger.error(`[token-usage] ${name} is not valid JSON; treating as absent`)
    return null
  }
}

/**
 * The synced cloud table of one data directory plus the alias → modelId
 * lookup, compiled identity resolver, exchange rate and history fingerprint
 * from one validated feed and association snapshot.
 * @param dir - the plugin's data directory.
 * @param logger - diagnostic sink (defaults to console).
 * @returns the flat table and the canonical map (both empty when absent).
 */
export interface PricingContext {
  feedVersion?: number
  associations: AssociationSnapshot
  associationStatuses: PricingAssociationStatus[]
  unavailableReason?: PricingUnavailableReason
  table: PricingTable
  canonical: Map<string, string>
  available: boolean
  fingerprint: string
  usdExchangeRate: number
  models: PricingOverviewModel[]
  resolveModel(name: string): ModelResolution
  resolveAutomatic(name: string): ModelResolution
  ratesForModel(name: string): ModelRates | undefined
}

/** One immutable feed snapshot; its indexes are private and resolutions lazy. */
export function pricingContextOf(feed: CloudPricingData | null, unavailableReason: PricingUnavailableReason = 'invalid-feed',
  associations: AssociationSnapshot = { state: 'ready', source: null, file: { version: 1, revision: 0, associations: [] } },
): PricingContext {
  const identify = createModelResolver(feed?.models ?? [])
  const table = resolvedTable(name => resolveModel(name).modelId)
  const rates = new Map<string, ModelRates>()
  const models = (feed?.models ?? []).map(model => {
    const rules = cloudModelRates(model)
    rates.set(model.modelId, rules)
    table[model.modelId] = rules
    return {
      modelId: model.modelId,
      aliasPatterns: [...model.aliasPatterns ?? []],
      ...(model.family !== undefined ? { family: model.family } : {}),
      rules,
    }
  })
  const ids = new Map(models.map(model => [modelKey(model.modelId), model.modelId]))
  const associationStatuses: PricingAssociationStatus[] = (associations.state === 'ready' ? associations.file.associations : []).map(saved => {
    const automatic = identify(saved.sourceModel)
    const target = ids.get(modelKey(saved.targetModelId))
    const common = { ...saved, ...(target !== undefined ? { resolvedTargetModelId: target } : {}) }
    if (automatic.modelId !== undefined) return { ...common, state: 'automatic-takeover', automaticModelId: automatic.modelId,
      targetDiffers: modelKey(automatic.modelId) !== modelKey(saved.targetModelId) }
    return { ...common, state: feed === null ? 'pricing-unavailable' : target === undefined ? 'target-missing' : 'active' }
  })
  const savedByName = new Map(associationStatuses.map(saved => [modelKey(saved.sourceModel), saved]))
  const resolutions = new Map<string, ModelResolution>()
  const resolveModel = (name: string): ModelResolution => {
    const cached = resolutions.get(name)
    if (cached !== undefined) return cached
    const automatic = identify(name)
    const association = savedByName.get(modelKey(name))
    const result: ModelResolution = association?.state === 'active'
      ? { rawName: name, status: 'matched', modelId: association.resolvedTargetModelId!, method: 'manual', strippedPrefix: false, candidates: [], association, automatic }
      : association === undefined ? automatic : { ...automatic, association }
    if (result.modelId !== undefined) table[name] = rates.get(result.modelId)!
    resolutions.set(name, result)
    return result
  }
  class CanonicalIndex extends Map<string, string> {
    override get(name: string): string | undefined {
      const id = resolveModel(name).modelId
      if (id !== undefined) this.set(name, id)
      return id
    }
    override has(name: string): boolean { return this.get(name) !== undefined }
  }
  const canonical = new CanonicalIndex()
  // Regex names enter the dictionary/index only when observed.
  for (const model of models) canonical.get(model.modelId)
  // Display labels, family, feed version/timestamp and exchange rate cannot
  // change RateKey. Slot order is retained because RateKey uses slot indexes.
  const semantic = models.map(model => ({
    modelId: modelKey(model.modelId),
    aliasPatterns: [...model.aliasPatterns ?? []].sort(),
    rules: model.rules,
  })).sort((a, b) => a.modelId.localeCompare(b.modelId))
  const associationsKey = associations.state === 'ready'
    ? associations.file.associations.map(saved => [modelKey(saved.sourceModel), modelKey(saved.targetModelId)]).sort((a, b) => a[0]!.localeCompare(b[0]!))
    : null
  const fingerprint = createHash('sha256').update(JSON.stringify({ algorithm: 3, available: feed !== null, models: semantic, associations: associationsKey },
    (key, value: unknown) => key === 'label' ? undefined : value)).digest('hex')
  return {
    ...(feed !== null ? { feedVersion: feed.version } : {}),
    ...(feed === null ? { unavailableReason } : {}),
    table, canonical, available: feed !== null, fingerprint,
    usdExchangeRate: feed?.usdExchangeRate ?? DEFAULT_USD_EXCHANGE_RATE,
    associations, associationStatuses, models, resolveModel, resolveAutomatic: identify,
    ratesForModel: name => {
      const id = resolveModel(name).modelId
      return id === undefined ? undefined : rates.get(id)
    },
  }
}

const contextCache = new Map<string, { source: string | null; reason: PricingUnavailableReason; associationKey: string; context: PricingContext }>()

export async function readPricingContext(dir: string, logger: LoggerLike = consoleLogger): Promise<PricingContext> {
  return withPricingDirectoryRead(dir, () => readPricingContextLocked(dir, logger))
}

/** Internal seam for association mutations that already hold the directory queue. */
export async function readPricingContextLocked(dir: string, logger: LoggerLike = consoleLogger): Promise<PricingContext> {
  let reason: PricingUnavailableReason = 'invalid-feed'
  const [source, associations] = await Promise.all([readFile(join(dir, PRICING_CCSA_FILE), 'utf8').catch((error: unknown) => {
    reason = (error as NodeJS.ErrnoException).code === 'ENOENT' ? 'missing' : 'unreadable'
    if ((error as NodeJS.ErrnoException).code !== 'ENOENT') logger.error('[token-usage] cannot read pricing mirror:', error)
    return null
  }), readAssociations(dir)])
  const associationKey = JSON.stringify([associations.source, associations.state === 'unavailable' ? associations.error : null])
  const cached = contextCache.get(dir)
  if (cached !== undefined && cached.source === source && cached.associationKey === associationKey
    && (source !== null || cached.reason === reason)) return cached.context
  let value: unknown = null
  if (source !== null) {
    try { value = JSON.parse(source) } catch { reason = 'invalid-json'; logger.error('[token-usage] pricing mirror is not valid JSON') }
  }
  const context = pricingContextOf(coerceCloudPricing(value), reason, associations)
  contextCache.set(dir, { source, reason, associationKey, context })
  return context
}

async function readSyncedPricing(dir: string, logger: LoggerLike = consoleLogger): Promise<PricingTable> {
  const feed = coerceCloudPricing(await readJsonFile(dir, PRICING_CCSA_FILE, logger))
  return feed === null ? {} : cloudToTable(feed)
}

/**
 * Load the pricing table of one data directory: the synced cloud mirror
 * flattened through {@link cloudToTable}. Absent or malformed mirrors read
 * as empty so the stats route stays alive while the user retries the sync.
 * @param dir - the plugin's data directory.
 * @param logger - diagnostic sink (defaults to console).
 * @returns the validated table (possibly empty).
 */
export async function readPricingTable(dir: string, logger: LoggerLike = consoleLogger): Promise<PricingTable> {
  return readSyncedPricing(dir, logger)
}

/**
 * The effective USD conversion rate (RMB per USD) of one data directory:
 * the cloud feed envelope's `usdExchangeRate` when it carries a usable one,
 * else {@link DEFAULT_USD_EXCHANGE_RATE}. Absent, malformed, or non-RMB
 * mirrors fall back the same way — display conversion never blocks on a
 * broken feed.
 * @param dir - the plugin's data directory.
 * @param logger - diagnostic sink (defaults to console).
 * @returns the positive rate the stats page converts display costs with.
 */
export async function readUsdExchangeRate(dir: string, logger: LoggerLike = consoleLogger): Promise<number> {
  const feed = coerceCloudPricing(await readJsonFile(dir, PRICING_CCSA_FILE, logger))
  return feed?.usdExchangeRate ?? DEFAULT_USD_EXCHANGE_RATE
}

/**
 * The cloud feed of one data directory in its model-row shape (not flattened
 * through {@link cloudToTable}): one row per model carrying the modelId, the
 * alias patterns, upstream family, and full rule set — one row per model.
 * Absent, malformed, or non-RMB mirrors read as an
 * empty list, matching {@link readPricingTable}'s stay-alive semantics.
 * @param dir - the plugin's data directory.
 * @param logger - diagnostic sink (defaults to console).
 * @returns the model rows (possibly empty).
 */
export async function readPricingOverview(dir: string, logger: LoggerLike = consoleLogger): Promise<PricingOverviewModel[]> {
  return (await readPricingContext(dir, logger)).models
}

/** The outcome of one successful cloud sync, for the command's reply. */
export type CloudSyncResult = PricingSyncResult

/**
 * Fetch the cloud pricing feed and mirror it verbatim into
 * `<data dir>/pricing.ccsa.json` (atomically: temp file + rename). The raw
 * feed is stored as received; the flatten-and-merge happens on read.
 * @param dir - the plugin's data directory.
 * @param url - the feed URL (the config override or the default gitee feed).
 * @returns the sync summary.
 */
export async function syncCloudPricing(dir: string, url: string, isCurrent: () => boolean = () => true): Promise<CloudSyncResult> {
  if (associationWritesPaused(dir)) throw new AssociationError('migration-in-progress')
  const epoch = pricingDirectoryEpoch(dir)
  const response = await fetch(url, { signal: AbortSignal.timeout(5_000) })
  if (!response.ok) throw new Error(`HTTP ${String(response.status)}`)
  const text = await response.text()
  // Mirror the analyzer's payload cap: refuse feeds too big to be sane.
  if (text.length > 1_048_576) throw new Error('feed exceeds the 1MB limit')
  let value: unknown
  try {
    value = JSON.parse(text)
  } catch {
    throw new Error('feed is not valid JSON')
  }
  const feed = coerceCloudPricing(value)
  if (feed === null) throw new Error('feed is not a valid RMB pricing table')
  const target = join(dir, PRICING_CCSA_FILE)
  const tmp = join(dir, `${PRICING_CCSA_FILE}.tmp`)
  // A fresh install may not have recorded any usage yet, so the data dir can
  // legitimately not exist — create it (idempotent) before the mirror lands.
  await withPricingDirectoryWrite(dir, async () => {
    if (pricingDirectoryEpoch(dir) !== epoch) throw new AssociationError('directory-conflict')
    if (!isCurrent()) throw new AssociationError('pricing-source-changed')
    await mkdir(dirname(target), { recursive: true })
    try {
      await writeFile(tmp, text.endsWith('\n') ? text : `${text}\n`, 'utf8')
      if (pricingDirectoryEpoch(dir) !== epoch) throw new AssociationError('directory-conflict')
      if (!isCurrent()) throw new AssociationError('pricing-source-changed')
      await rename(tmp, target)
    } finally { await unlink(tmp).catch(() => undefined) }
  })
  return {
    version: feed.version,
    updatedAt: feed.updatedAt,
    models: feed.models.length,
    aliasPatterns: feed.models.reduce((sum, model) => sum + (model.aliasPatterns?.length ?? 0), 0),
    usdExchangeRate: feed.usdExchangeRate ?? DEFAULT_USD_EXCHANGE_RATE,
  }
}
