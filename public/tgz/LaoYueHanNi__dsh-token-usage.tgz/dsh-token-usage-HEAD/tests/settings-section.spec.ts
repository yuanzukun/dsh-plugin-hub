/**
 * Token-usage settings-section unit tests: the namespace constant, the
 * section schema's resolution (the data directory and the pricing-region
 * pick), the validator behind the empty-path refusal, and the guard verdict
 * the card's pre-save check renders.
 */
import { describe, expect, it } from 'vitest'
import { countInteractingSessions, directoryGuard, resolveDataDir, sectionSchema, TOKEN_USAGE_NS, validateSection, validateSectionChange } from '../src/index.ts'

describe('TOKEN_USAGE_NS', () => {
  it('is the kebab-case plugin name', () => {
    expect(TOKEN_USAGE_NS).toBe('token-usage')
  })
})

describe('countInteractingSessions', () => {
  it('counts sessions whose log ends inside an open turn, ignoring idle ones', () => {
    // Existence alone must not count: an idle session stays in the store
    // after its conversation ended, and only an open turn keeps appending.
    const openTurn = [{ type: 'user/message' }, { type: 'turn/start' }]
    const closedTurn = [{ type: 'turn/start' }, { type: 'user/message' }, { type: 'turn/end' }]
    const reopened = [...closedTurn, { type: 'turn/start' }]
    expect(countInteractingSessions([])).toBe(0)
    expect(countInteractingSessions([[], [{ type: 'session/title' }]])).toBe(0)
    expect(countInteractingSessions([closedTurn, [{ type: 'session/title' }]])).toBe(0)
    expect(countInteractingSessions([openTurn, closedTurn])).toBe(1)
    expect(countInteractingSessions([reopened, openTurn])).toBe(2)
  })
})

describe('directoryGuard', () => {
  const running = { runningDir: 'D:/running', interactingSessions: 0 }

  it('blocks a directory change exactly while sessions converse, counting them', () => {
    expect(directoryGuard('D:/elsewhere', { ...running, interactingSessions: 2 }))
      .toEqual({ blocked: true, interactingSessions: 2 })
    expect(directoryGuard('D:/elsewhere', running)).toEqual({ blocked: false, interactingSessions: 0 })
  })

  it('never blocks the same directory, a clear running on the default, or the first adoption', () => {
    expect(directoryGuard('D:/running', { ...running, interactingSessions: 3 })).toEqual({ blocked: false, interactingSessions: 3 })
    // A clear resolves back through the default: a no-op only while the
    // default is what runs; from an explicit directory it is a move.
    expect(directoryGuard(undefined, { runningDir: resolveDataDir(undefined), interactingSessions: 3 }))
      .toEqual({ blocked: false, interactingSessions: 3 })
    expect(directoryGuard(undefined, { ...running, interactingSessions: 3 }))
      .toEqual({ blocked: true, interactingSessions: 3 })
    // No running directory yet: the first start adopts the stored path.
    expect(directoryGuard('D:/elsewhere', { runningDir: undefined, interactingSessions: 3 }))
      .toEqual({ blocked: false, interactingSessions: 3 })
  })
})
