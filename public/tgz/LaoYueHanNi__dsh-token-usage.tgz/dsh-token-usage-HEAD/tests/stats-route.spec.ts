import { mkdtemp, readFile, unlink, writeFile } from 'node:fs/promises'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { Context, Service } from '@deepseek-ai/cordis'
import type { WebRoute } from '@deepseek-ai/dsh-host-webserver'
import * as plugin from '../src/index.ts'
import { createDirectoryGuardRoute, createFullSyncRoute, createMigrationRoute, createPricingRoute, createStatsRoute, DIR_GUARD_PATH, FULL_SYNC_PATH, isSameOriginFetch, MIGRATION_PATH, PRICING_PATH, STATS_PATH } from '../src/stats-route.ts'
import { ASSOCIATIONS_PATH, currencyOfRegion } from '../src/wire.ts'
import { PRICING_SYNC_PATH } from '../src/wire.ts'
import { createPricingSyncRoute } from '../src/stats-route.ts'
import { AssociationError } from '../src/pricing-associations.ts'
import { DEFAULT_PRICING_URL_OVERSEAS } from '../src/pricing.ts'
import type { UsageRecord } from '../src/usage-record.ts'
import { messageEvent } from './helpers.ts'
import { SESSION_ROW_LIMIT } from '../src/stats.ts'
import type { ProjectUsageRow, SessionRequestDetails, SessionUsageRow } from '../src/wire.ts'

/** Captures registrations instead of serving HTTP. */
class MockWebServer extends Service {
  readonly routes: WebRoute[] = []

  constructor(ctx: Context) {
    super(ctx, 'webServer')
  }

  register(route: WebRoute): () => void {
    this.routes.push(route)
    return () => {}
  }
}

/** One captured response for assertion. */
interface CapturedResponse {
  status: number
  headers: Record<string, string | string[] | number | undefined>
  body: string
}

function fakeRequest(overrides: Partial<IncomingMessage> = {}): IncomingMessage {
  return { method: 'GET', headers: {}, ...overrides } as IncomingMessage
}

function fakeResponse(): { res: ServerResponse; captured: CapturedResponse } {
  const captured: CapturedResponse = { status: 200, headers: {}, body: '' }
  const res = {
    writeHead: vi.fn((status: number, headers: Record<string, string | number>) => {
      captured.status = status
      captured.headers = { ...captured.headers, ...headers }
    }),
    end: vi.fn((body?: unknown) => {
      if (typeof body === 'string') captured.body += body
    }),
  } as unknown as ServerResponse
  return { res, captured }
}

/** One full record fixture. */
function fixtureRecord(time: number): UsageRecord {
  return {
    requestId: `req-${time}`,
    time,
    sessionId: 's1',
    model: 'deepseek-chat',
    usage: { inputTokens: 10, outputTokens: 5, cacheReadTokens: 3 },
  }
}

/** One record on a local calendar day with a chosen model. */
function dayRecord(day: number, model: string): UsageRecord {
  const time = new Date(2026, 0, 10 + day, 12).getTime()
  return { ...fixtureRecord(time), requestId: `req-${model}-${day}`, model }
}

/** A data dir holding three days × two models (day N contributes N+1 requests to chat). */
async function filteredDataDir(): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'token-usage-filter-'))
  const lines: string[] = []
  for (const day of [0, 1, 2]) {
    lines.push(JSON.stringify(dayRecord(day, 'deepseek-chat')))
    lines.push(JSON.stringify(dayRecord(day, 'deepseek-reasoner')))
  }
  await writeFile(join(dir, 'usage-2026-01-10.jsonl'), lines.slice(0, 2).join('\n') + '\n')
  await writeFile(join(dir, 'usage-2026-01-11.jsonl'), lines.slice(2, 4).join('\n') + '\n')
  await writeFile(join(dir, 'usage-2026-01-12.jsonl'), lines.slice(4).join('\n') + '\n')
  return dir
}

/**
 * A data dir with two sessions: `alpha` owns a chat row (01-11) and a
 * reasoner row (01-12); `child` owns a chat row (01-12) — the shape of a
 * parent session plus one subagent.
 */
async function sessionDataDir(): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'token-usage-session-'))
  const line = (record: UsageRecord): string => `${JSON.stringify(record)}\n`
  await writeFile(join(dir, 'usage-2026-01-11.jsonl'), line({
    ...dayRecord(1, 'deepseek-chat'), sessionId: 'alpha', requestId: 'alpha-chat',
  }))
  await writeFile(join(dir, 'usage-2026-01-12.jsonl'),
    line({ ...dayRecord(2, 'deepseek-reasoner'), sessionId: 'alpha', requestId: 'alpha-reasoner' })
    + line({ ...dayRecord(2, 'deepseek-chat'), sessionId: 'child', requestId: 'child-chat' }))
  return dir
}

/**
 * A data dir with a root, a direct child, a grandchild and one unrelated
 * session, plus the pricing mirror and the lineage metadata a scope-rule
 * read is expanded from. Only the first three own usage records.
 */
async function scopeDataDir(): Promise<string> {
  const dir = await mkdtemp(join(tmpdir(), 'token-usage-scope-'))
  const line = (sessionId: string, requestId: string, timing?: { ft: number; gen: number }): string =>
    `${JSON.stringify({
      ...dayRecord(1, 'deepseek-chat'), sessionId, requestId,
      ...(timing !== undefined ? {
        firstTokenLatencyMs: timing.ft,
        latencyMs: timing.ft + timing.gen,
        attemptTiming: { startedAt: 0, settledAt: timing.ft + timing.gen, firstTokenAt: timing.ft },
      } : {}),
    })}\n`
  await writeFile(join(dir, 'usage-2026-01-11.jsonl'),
    line('alpha', 'alpha-1') + line('child', 'child-1', { ft: 100, gen: 400 })
    + line('grandchild', 'gc-1', { ft: 200, gen: 600 }) + line('outsider', 'out-1'))
  await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({ currency: 'RMB', usdExchangeRate: 8, models: [
    { modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 3 },
  ] }))
  await writeFile(join(dir, 'sessions.json'), JSON.stringify({
    alpha: { title: 'Parent' },
    child: { parentSession: 'alpha', origin: 'subagent' },
    grandchild: { parentSession: 'child', origin: 'subagent' },
    outsider: { parentSession: 'elsewhere', origin: 'subagent' },
  }))
  return dir
}

describe('createStatsRoute', () => {
  it('shares identification across whole/session/chip/filter/children and overview, including genuine zero rates', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'resolution-route-'))
    const records = ['M', 'provider/m', 'ns/M-HIGH', 'free', 'other/missing'].map((model, i) => ({
      ...dayRecord(1, model), requestId: String(i), sessionId: i === 2 ? 'child' : 'root',
      usage: { inputTokens: 1_000_000, outputTokens: 0 },
    }))
    await writeFile(join(dir, 'usage-2026-01-11.jsonl'), records.map(r => JSON.stringify(r)).join('\n') + '\n')
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({ currency: 'RMB', usdExchangeRate: 8, models: [
      { modelId: 'm', aliasPatterns: ['^m-high$'], inputCostPerMillion: 2, outputCostPerMillion: 0 },
      { modelId: 'free', inputCostPerMillion: 0, outputCostPerMillion: 0 },
    ] }))
    const route = createStatsRoute(() => dir)
    const query = async (search = '') => {
      const { res, captured } = fakeResponse(); await route.handler(fakeRequest({ url: STATS_PATH + search }), res)
      expect(captured.status).toBe(200); return JSON.parse(captured.body)
    }
    const whole = await query()
    expect(whole).toMatchObject({ costState: 'ready', totalCost: 6, usdExchangeRate: 8, total: { requests: 5 }, unpricedModels: ['other/missing'] })
    expect(whole.byModel.find((row: { model: string }) => row.model === 'm').totals.requests).toBe(3)
    expect(whole.pricing['ns/M-HIGH']).toEqual(whole.pricing.m)
    expect(whole.modelResolutions.find((row: { rawName: string }) => row.rawName === 'ns/M-HIGH')).toMatchObject({ modelId: 'm', method: 'pattern' })
    const search = '?sessionId=root&sessionId=child&childId=child'
    for (const fields of ['full', 'session', 'chip']) {
      const scoped = await query(search + '&fields=' + fields)
      expect(scoped).toMatchObject({ totalCost: 6, costState: 'ready', total: { requests: 5 } })
      expect(scoped.children.child).toMatchObject({ costState: 'ready', totalCost: 2, total: { requests: 1 } })
    }
    const selected = await query('?sessionId=root&sessionId=child&fields=session&model=NS%2FM-HIGH')
    expect(selected).toMatchObject({ totalCost: 6, total: { requests: 3 }, byModel: [{ model: 'm' }] })
    expect(selected.requestSeries.reduce((n: number, point: { count: number }) => n + point.count, 0)).toBe(3)
    const { res, captured } = fakeResponse()
    await createPricingRoute(() => dir).handler(fakeRequest(), res)
    expect(JSON.parse(captured.body)).toMatchObject({ costState: 'ready', usdExchangeRate: 8, models: [{ modelId: 'm', aliasPatterns: ['^m-high$'] }, { modelId: 'free', aliasPatterns: [] }] })
  })

  it('propagates unavailable history to every response shape while retaining whole-scope cached usage', async () => {
    const dir = await sessionDataDir()
    const path = join(dir, 'pricing.ccsa.json')
    await writeFile(path, JSON.stringify({ currency: 'RMB', models: [{ modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 3 }] }))
    const route = createStatsRoute(() => dir)
    const query = async (url = STATS_PATH) => {
      const { res, captured } = fakeResponse(); await route.handler(fakeRequest({ url }), res); return JSON.parse(captured.body)
    }
    const before = await query()
    await unlink(join(dir, 'usage-2026-01-11.jsonl'))
    await writeFile(path, JSON.stringify({ currency: 'RMB', models: [{ modelId: 'deepseek-chat', inputCostPerMillion: 4, outputCostPerMillion: 3 }] }))
    const after = await query()
    expect(after.total).toEqual(before.total)
    expect(after).toMatchObject({ costState: 'history-incomplete', totalCost: 0 })
    for (const fields of ['chip', 'session', 'full']) {
      expect(await query(`${STATS_PATH}?sessionId=alpha&sessionId=child&childId=child&fields=${fields}`)).toMatchObject({ costState: 'history-incomplete', totalCost: 0, total: before.total,
        children: { child: { costState: 'history-incomplete', totalCost: 0, total: { requests: 1 } } } })
    }
  })

  // R11 / R14: the request pool rides ONLY the `session` read; legacy rows
  // use their reported cache data and retain sequence exclusions.
  it('carries requestDetails on session reads only, merging live rows over durable ones', async () => {
    const dir = await sessionDataDir()
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({ currency: 'RMB', models: [{ modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 3 }, { modelId: 'deepseek-reasoner', inputCostPerMillion: 2, outputCostPerMillion: 3 }] }))
    const seen: string[][] = []
    const route = createStatsRoute(() => dir, {
      live: () => ({
        snapshot: (sessionIds: readonly string[]) => {
          seen.push([...sessionIds])
          return {
            attempts: [{
              id: '42:alpha:t1:s2:a1',
              sessionId: 'alpha',
              kind: 'request',
              state: 'waiting',
              provider: 'deepseek-official',
              requestedModel: 'deepseek-chat',
              startedAt: new Date(2026, 0, 13, 12).getTime() + 5_000,
              turn: 1,
              step: 2,
            }],
            activeCount: 1,
          }
        },
        capability: 'lifecycle',
      }),
    })
    const query = async (search: string): Promise<Record<string, unknown>> => {
      const { res, captured } = fakeResponse(); await route.handler(fakeRequest({ url: STATS_PATH + search }), res)
      expect(captured.status).toBe(200); return JSON.parse(captured.body)
    }
    const scope = '?sessionId=alpha&sessionId=child'
    const chip = await query(scope + '&fields=chip')
    expect('requestDetails' in chip).toBe(false)
    const full = await query(scope + '&fields=full')
    expect('requestDetails' in full).toBe(false)
    const session = await query(scope + '&fields=session') as { requestDetails?: { items: Array<{ id: string; state: string; cache: { band: string; reason?: string } }>; limit: number; activeCount: number; liveCapability: string } }
    expect(session.requestDetails).toBeDefined()
    const details = session.requestDetails!
    expect(details.liveCapability).toBe('lifecycle')
    expect(details.activeCount).toBe(1)
    expect(details.limit).toBe(20)
    // The live waiting row tops the pool; the two durable alpha rows follow.
    expect(details.items[0]).toMatchObject({ state: 'waiting', sessionId: 'alpha' })
    expect(details.items.some(item => item.durableRequestId === 'alpha-chat')).toBe(true)
    // The snapshot covered exactly the requested scope.
    expect(seen.at(-1)).toEqual(['alpha', 'child'])
    // Provider metadata is not required; the session's first row stays excluded.
    const legacyRow = details.items.find(item => item.durableRequestId === 'alpha-chat')!
    expect(legacyRow.cache).toMatchObject({ band: 'excluded', reason: 'cold-start', rate: 3 / 13 })
    // Without an observer the pool degrades honestly to settled-only.
    const plain = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await plain.handler(fakeRequest({ url: STATS_PATH + scope + '&fields=session' }), res)
    const degraded = JSON.parse(captured.body) as { requestDetails: { liveCapability: string; activeCount: number } }
    expect(degraded.requestDetails.liveCapability).toBe('settled-only')
    expect(degraded.requestDetails.activeCount).toBe(0)
  })

  it('promotes an older active child only in tree scope, including when the parent has no requests', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-active-child-'))
    const route = createStatsRoute(() => dir, {
      live: () => ({
        capability: 'lifecycle',
        snapshot: (sessionIds: readonly string[]) => {
          const included = sessionIds.includes('child')
          return {
            attempts: included ? [{
              id: 'active-child', sessionId: 'child', kind: 'request' as const,
              state: 'streaming' as const, provider: 'deepseek-official',
              requestedModel: 'deepseek-chat', startedAt: 1_000, turn: 1, step: 1,
            }] : [],
            activeCount: included ? 1 : 0,
          }
        },
      }),
    })
    const query = async (tree: boolean): Promise<SessionRequestDetails> => {
      const { res, captured } = fakeResponse()
      await route.handler(fakeRequest({ url: `${STATS_PATH}?fields=session&sessionId=alpha${tree ? '&sessionId=child&childId=child' : ''}` }), res)
      expect(captured.status).toBe(200)
      return JSON.parse(captured.body).requestDetails
    }
    expect(await query(false)).toMatchObject({ items: [], activeCount: 0 })
    expect(await query(true)).toMatchObject({ items: [{ id: 'active-child', state: 'streaming' }], activeCount: 1 })

    await writeFile(join(dir, 'usage-2026-01-15.jsonl'), JSON.stringify({
      ...fixtureRecord(5_000), sessionId: 'alpha', requestId: 'parent-done', startedAt: 4_000,
    }) + '\n')
    const tree = await query(true)
    expect(tree.items.map(item => item.id)).toEqual(['active-child', 'parent-done'])
    expect(tree.activeCount).toBe(1)
    const root = await query(false)
    expect(root.items.map(item => item.id)).toEqual(['parent-done'])
    expect(root.activeCount).toBe(0)
  })

  it('serves the JSON summary on GET', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-route-'))
    await writeFile(join(dir, 'usage-2026-01-15.jsonl'), `${JSON.stringify(fixtureRecord(100))}\n`)
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(captured.status).toBe(200)
    expect(captured.headers['content-type']).toBe('application/json; charset=utf-8')
    expect(captured.headers['cache-control']).toBe('no-store')
    const body = JSON.parse(captured.body) as { total: { requests: number; inputTokens: number } }
    expect(body.total.requests).toBe(1)
    expect(body.total.inputTokens).toBe(10)
  })

  it('serves the provider dimension with the name registry on whole and session reads, never on chip', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-provider-'))
    const line = (record: UsageRecord): string => `${JSON.stringify(record)}\n`
    await writeFile(join(dir, 'usage-2026-01-15.jsonl'),
      line({ ...fixtureRecord(100), provider: 'deepseek-official' })
      + line({ ...fixtureRecord(200), provider: 'zai-coding-cn' })
      + line(fixtureRecord(300)))
    const route = createStatsRoute(() => dir, {
      providerNames: async () => ({ 'deepseek-official': 'DeepSeek' }),
    })
    const whole = fakeResponse()
    await route.handler(fakeRequest(), whole.res)
    expect(whole.captured.status).toBe(200)
    const wholeBody = JSON.parse(whole.captured.body) as {
      byProvider: Array<{ provider: string; totals: { requests: number } }>
      providerNames: Record<string, string>
    }
    expect(wholeBody.byProvider.map(row => [row.provider, row.totals.requests])).toEqual([
      ['deepseek-official', 1],
      ['zai-coding-cn', 1],
      ['', 1],
    ])
    expect(wholeBody.providerNames).toEqual({ 'deepseek-official': 'DeepSeek' })
    // The session-scoped read carries the same dimension and registry.
    const scoped = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionId=s1&fields=session` }), scoped.res)
    const scopedBody = JSON.parse(scoped.captured.body) as {
      byProvider: Array<{ provider: string }>
      providerNames: Record<string, string>
    }
    expect(scopedBody.byProvider.map(row => row.provider)).toEqual(['deepseek-official', 'zai-coding-cn', ''])
    expect(scopedBody.providerNames).toEqual({ 'deepseek-official': 'DeepSeek' })
    // The chip stays slim: no dimension, no registry.
    const chip = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionId=s1&fields=chip` }), chip.res)
    const chipBody = JSON.parse(chip.captured.body) as Record<string, unknown>
    expect(chipBody.byProvider).toBeUndefined()
    expect(chipBody.providerNames).toBeUndefined()
  })

  it('rejects non-GET methods with 405', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-route-'))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ method: 'POST' }), res)
    expect(captured.status).toBe(405)
  })

  it('refuses cross-site browser fetches with 403', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-route-'))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ headers: { 'sec-fetch-site': 'cross-site' } }), res)
    expect(captured.status).toBe(403)
  })

  it('answers an absent data directory with an empty summary', async () => {
    const dir = join(tmpdir(), `token-usage-absent-${Date.now()}`)
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(captured.status).toBe(200)
    expect(JSON.parse(captured.body)).toMatchObject({ total: { requests: 0 } })
  })

  it('filters by an inclusive day range', async () => {
    const dir = await filteredDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?from=2026-01-11&to=2026-01-12` }), res)
    expect(captured.status).toBe(200)
    const body = JSON.parse(captured.body) as { total: { requests: number }; byDay: Array<{ day: string }> }
    expect(body.total.requests).toBe(4)
    expect(body.byDay.map(row => row.day)).toEqual(['2026-01-11', '2026-01-12'])
  })

  it('filters by model and combines it with a day range', async () => {
    const dir = await filteredDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?model=deepseek-chat&from=2026-01-10` }), res)
    expect(captured.status).toBe(200)
    const body = JSON.parse(captured.body) as { total: { requests: number }; byModel: Array<{ model: string }> }
    expect(body.total.requests).toBe(3)
    expect(body.byModel.map(row => row.model)).toEqual(['deepseek-chat'])
  })

  it('treats blank query values as absent', async () => {
    const dir = await filteredDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?from=&to=&model=` }), res)
    expect(captured.status).toBe(200)
    expect(JSON.parse(captured.body).total.requests).toBe(6)
  })

  it('rejects a malformed day key with 400', async () => {
    const dir = await filteredDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?from=2026-1-1` }), res)
    expect(captured.status).toBe(400)
  })

  it('rejects an inverted day range with 400', async () => {
    const dir = await filteredDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?from=2026-01-12&to=2026-01-10` }), res)
    expect(captured.status).toBe(400)
  })

  it('serves an empty cost layer without a pricing table', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-route-'))
    await writeFile(join(dir, 'usage-2026-01-15.jsonl'), `${JSON.stringify(fixtureRecord(100))}\n`)
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    const body = JSON.parse(captured.body) as {
      totalCost: number
      unpricedModels: string[]
      pricing: Record<string, unknown>
      byModel: Array<{ model: string; cost: number }>
    }
    expect(body.totalCost).toBe(0)
    expect(body.unpricedModels).toEqual(['deepseek-chat'])
    expect(body.pricing).toEqual({})
    expect(body.byModel).toEqual([{ model: 'deepseek-chat', totals: expect.anything(), cost: 0 }])
  })

  it('defaults to CNY display with the built-in rate when no mirror exists', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-route-'))
    await writeFile(join(dir, 'usage-2026-01-15.jsonl'), `${JSON.stringify(fixtureRecord(100))}\n`)
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(JSON.parse(captured.body)).toMatchObject({ currency: 'CNY', usdExchangeRate: 7 })
  })

  it('stamps the currency thunk answer and the mirror rate as USD', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-route-'))
    await writeFile(join(dir, 'usage-2026-01-15.jsonl'), `${JSON.stringify(fixtureRecord(100))}\n`)
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 57, updatedAt: 1, currency: 'RMB', usdExchangeRate: 7.25,
      models: [{ modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 8 }],
    }))
    const route = createStatsRoute(() => dir, { currency: () => 'USD' })
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    const body = JSON.parse(captured.body) as { currency: string; usdExchangeRate: number; totalCost: number }
    expect(body.currency).toBe('USD')
    // The feed envelope's rate, not the built-in 7.
    expect(body.usdExchangeRate).toBe(7.25)
    // Wire amounts stay RMB — conversion is the client's job. The feed gives
    // no cache price, so cache reads bill at the plain input rate (2):
    // 10×2 + 5×8 + 3×2 = 66 per million tokens.
    expect(body.totalCost).toBeCloseTo(0.000066, 12)
  })

  it('computes costs from the cloud pricing mirror', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-route-'))
    await writeFile(join(dir, 'usage-2026-01-15.jsonl'), `${JSON.stringify(fixtureRecord(100))}\n`)
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 4, updatedAt: 1, currency: 'RMB',
      models: [{ modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 8, cacheReadCostPerMillion: 0.5 }],
    }))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    const body = JSON.parse(captured.body) as {
      totalCost: number
      unpricedModels: string[]
      pricing: Record<string, unknown>
      byModel: Array<{ model: string; cost: number }>
    }
    // 10 input × ¥2 + 5 output × ¥8 + 3 cache read × ¥0.5, per million.
    expect(body.totalCost).toBe(0.0000615)
    expect(body.unpricedModels).toEqual([])
    expect(body.pricing).toEqual({
      'deepseek-chat': {
        base: { inputPerMillion: 2, outputPerMillion: 8, cacheReadPerMillion: 0.5 },
        contextTiers: [],
        dailySlots: [],
        timeRules: [],
      },
    })
    expect(body.byModel[0]!.cost).toBe(0.0000615)
  })

  it('folds alias usage onto the pricing model-id', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-alias-'))
    const id = { ...fixtureRecord(100), model: 'deepseek-v4-flash', requestId: 'id' }
    const alias = { ...fixtureRecord(200), model: 'deepseek-v4-flash-0731', requestId: 'alias' }
    await writeFile(join(dir, 'usage-2026-01-15.jsonl'), `${JSON.stringify(id)}\n${JSON.stringify(alias)}\n`)
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 4, updatedAt: 1, currency: 'RMB',
      models: [{
        modelId: 'deepseek-v4-flash',
        inputCostPerMillion: 1, outputCostPerMillion: 2, cacheReadCostPerMillion: 0.5,
        aliasPatterns: ['^deepseek-v4-flash-0731$'],
      }],
    }))
    const route = createStatsRoute(() => dir)
    const whole = fakeResponse()
    await route.handler(fakeRequest(), whole.res)
    const body = JSON.parse(whole.captured.body) as {
      total: { requests: number }
      byModel: Array<{ model: string; totals: { requests: number }; cost: number }>
    }
    expect(body.byModel.map(row => row.model)).toEqual(['deepseek-v4-flash'])
    expect(body.byModel[0]!.totals.requests).toBe(2)
    expect(body.total.requests).toBe(2)
    // Filtering by the canonical id includes the alias's usage.
    const filtered = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?model=deepseek-v4-flash` }), filtered.res)
    const filteredBody = JSON.parse(filtered.captured.body) as {
      total: { requests: number }
      byModel: Array<{ model: string; totals: { requests: number } }>
    }
    expect(filteredBody.total.requests).toBe(2)
    expect(filteredBody.byModel.map(row => row.model)).toEqual(['deepseek-v4-flash'])
  })

  it('bills each record through the cloud rule chain at its own timestamp', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-route-'))
    // Two records on one day, local time: 10:00 falls inside the peak window
    // (09:00–12:00 local minutes), 20:00 is off-peak.
    const peak = { ...fixtureRecord(new Date(2026, 0, 15, 10).getTime()), requestId: 'peak' }
    const off = { ...fixtureRecord(new Date(2026, 0, 15, 20).getTime()), requestId: 'off' }
    await writeFile(join(dir, 'usage-2026-01-15.jsonl'), `${JSON.stringify(peak)}\n${JSON.stringify(off)}\n`)
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 57, updatedAt: 1, currency: 'RMB',
      models: [{
        modelId: 'deepseek-chat',
        inputCostPerMillion: 1, outputCostPerMillion: 2, cacheReadCostPerMillion: 0.1,
        dailySlots: [{ windows: [{ startMinute: 540, endMinute: 720 }], inputCostPerMillion: 3, outputCostPerMillion: 6, cacheReadCostPerMillion: 0.3 }],
      }],
    }))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    const body = JSON.parse(captured.body) as {
      totalCost: number
      rateRows: Array<{ rate: { slot: number }; totals: { inputTokens: number } }>
    }
    // Peak row: 10×3 + 5×6 + 3×0.3 = 60.9 per million tokens; off-peak:
    // 10×1 + 5×2 + 3×0.1 = 20.3 — two distinct rate rows on one day.
    expect(body.totalCost).toBeCloseTo((60.9 + 20.3) / 1_000_000, 12)
    expect(body.rateRows).toHaveLength(2)
    // Sorted by rate identity (slot -1 before 0), not by record time.
    expect(body.rateRows.map(row => row.rate.slot)).toEqual([-1, 0])
  })

  it('recomputes costs after filtering, dropping other models from the totals', async () => {
    const dir = await filteredDataDir()
    // Only chat is priced; reasoner stays unpriced.
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 4, updatedAt: 1, currency: 'RMB',
      models: [{ modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 8, cacheReadCostPerMillion: 0.5 }],
    }))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?model=deepseek-chat&from=2026-01-10&to=2026-01-12` }), res)
    const body = JSON.parse(captured.body) as {
      totalCost: number
      unpricedModels: string[]
      byModel: Array<{ model: string; cost: number }>
    }
    expect(body.byModel.map(row => row.model)).toEqual(['deepseek-chat'])
    expect(body.unpricedModels).toEqual([])
    expect(body.totalCost).toBeGreaterThan(0)
    expect(body.byModel[0]!.cost).toBe(body.totalCost)
  })

  it('scopes the summary to one session via repeated sessionId params', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionId=alpha` }), res)
    const body = JSON.parse(captured.body) as {
      total: { requests: number; inputTokens: number; outputTokens: number }
      byModel: Array<{ model: string }>
      recent: Array<{ sessionId: string }>
    }
    // alpha owns two records (chat one, reasoner one); beta's rows are excluded.
    expect(body.total.requests).toBe(2)
    expect(body.total.inputTokens).toBe(2 * 10)
    expect(body.total.outputTokens).toBe(2 * 5)
    expect(body.byModel.map(row => row.model)).toEqual(['deepseek-chat', 'deepseek-reasoner'])
    expect(body.recent.every(record => record.sessionId === 'alpha')).toBe(true)
  })

  it('aggregates a parent session with its subagent subtree in one request', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionId=alpha&sessionId=child` }), res)
    const body = JSON.parse(captured.body) as { total: { requests: number }; byModel: Array<{ model: string; totals: { requests: number } }> }
    expect(body.total.requests).toBe(3)
    const matches = body.byModel.find(row => row.model === 'deepseek-chat')
    expect(matches?.totals.requests).toBe(2)
  })

  it('carries the per-request series on session-scoped reads', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionId=alpha` }), res)
    const body = JSON.parse(captured.body) as {
      scope: 'session' | 'whole'
      sessionIds: string[]
      requestSeries: Array<{ time: number; tokens: number }>
    }
    // One point per request, in time order: alpha's chat row (01-11) first,
    // its reasoner row (01-12) second. 10 in + 5 out + 3 cache read = 18.
    expect(body.scope).toBe('session')
    expect(body.sessionIds).toEqual(['alpha'])
    expect(body.requestSeries).toEqual([
      { time: new Date(2026, 0, 11, 12).getTime(), tokens: 18 },
      { time: new Date(2026, 0, 12, 12).getTime(), tokens: 18 },
    ])
  })

  it('omits the request series from the whole-log settings read', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    const body = JSON.parse(captured.body) as {
      scope: 'session' | 'whole'
      requestSeries?: unknown
    }
    expect(body.scope).toBe('whole')
    expect('requestSeries' in body).toBe(false)
  })

  it('combines a session scope with the day-range and model filters', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({
      url: `${STATS_PATH}?sessionId=alpha&model=deepseek-reasoner&to=2026-01-11`,
    }), res)
    const body = JSON.parse(captured.body) as {
      total: { requests: number }
      byModel: Array<{ model: string }>
      recent: Array<{ sessionId: string }>
    }
    // alpha's reasoner row sits on the 12th, past `to=2026-01-11`, so the
    // scoped window holds no records at all.
    expect(body.total.requests).toBe(0)
    expect(body.byModel).toEqual([])
    expect(body.recent).toEqual([])
  })

  it('answers an empty summary for a session with no records', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionId=nobody` }), res)
    expect(captured.status).toBe(200)
    const body = JSON.parse(captured.body) as { total: { requests: number }; unpricedModels: string[] }
    expect(body.total.requests).toBe(0)
    expect(body.unpricedModels).toEqual([])
  })

  it('omits pricing and the request series on fields=chip', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionId=alpha&fields=chip` }), res)
    const body = JSON.parse(captured.body) as Record<string, unknown>
    expect(body.scope).toBe('session')
    expect(body.sessionIds).toEqual(['alpha'])
    expect(body.total).toMatchObject({ requests: 2 })
    expect('pricing' in body).toBe(false)
    expect('requestSeries' in body).toBe(false)
    expect('byModel' in body).toBe(false)
    expect('byDay' in body).toBe(false)
    expect('rateRows' in body).toBe(false)
    expect('recent' in body).toBe(false)
  })

  it('sends a pre-bucketed request series and model/day rows on fields=session', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionId=alpha&fields=session` }), res)
    const body = JSON.parse(captured.body) as {
      byModel: unknown[]
      byDay: unknown[]
      requestSeries: Array<{ time: number; tokens: number; count: number; end: number }>
      pricing?: unknown
      byHour?: unknown
      rateRows?: unknown
    }
    expect(body.byModel).toHaveLength(2)
    expect(body.byDay.length).toBeGreaterThan(0)
    expect(body.requestSeries.length).toBeGreaterThan(0)
    expect(body.requestSeries.length).toBeLessThanOrEqual(60)
    expect(body.requestSeries.every(point => point.count >= 1 && point.end > point.time)).toBe(true)
    expect(body.pricing).toBeUndefined()
    expect(body.byHour).toBeUndefined()
    expect(body.rateRows).toBeUndefined()
  })

  it('returns per-child totals for childId groups (session vs tree)', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const sessionScope = fakeResponse()
    await route.handler(fakeRequest({
      url: `${STATS_PATH}?sessionId=alpha&childId=child&fields=session`,
    }), sessionScope.res)
    const sessionBody = JSON.parse(sessionScope.captured.body) as {
      total: { requests: number }
      children: Record<string, { total: { requests: number } }>
    }
    expect(sessionBody.total.requests).toBe(2)
    expect(sessionBody.children.child.total.requests).toBe(1)

    const treeScope = fakeResponse()
    await route.handler(fakeRequest({
      url: `${STATS_PATH}?sessionId=alpha&sessionId=child&childId=child&fields=session`,
    }), treeScope.res)
    const treeBody = JSON.parse(treeScope.captured.body) as {
      total: { requests: number }
      children: Record<string, { total: { requests: number } }>
    }
    expect(treeBody.total.requests).toBe(3)
    expect(treeBody.children.child.total.requests).toBe(1)
  })
})

describe('isSameOriginFetch', () => {
  it('allows same-origin, none, and absent Sec-Fetch-Site', () => {
    expect(isSameOriginFetch(fakeRequest({ headers: { 'sec-fetch-site': 'same-origin' } }))).toBe(true)
    expect(isSameOriginFetch(fakeRequest({ headers: { 'sec-fetch-site': 'none' } }))).toBe(true)
    expect(isSameOriginFetch(fakeRequest({ headers: {} }))).toBe(true)
  })

  it('refuses cross-site and same-site values', () => {
    expect(isSameOriginFetch(fakeRequest({ headers: { 'sec-fetch-site': 'cross-site' } }))).toBe(false)
    expect(isSameOriginFetch(fakeRequest({ headers: { 'sec-fetch-site': 'same-site' } }))).toBe(false)
  })
})

describe('createMigrationRoute', () => {
  it('answers the live progress as JSON on GET', async () => {
    let status: { phase: 'copying' | 'cleaning'; done: number; total: number } | undefined
      = { phase: 'copying', done: 2, total: 5 }
    const route = createMigrationRoute(() => status)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(captured.status).toBe(200)
    expect(captured.headers['content-type']).toBe('application/json; charset=utf-8')
    expect(captured.headers['cache-control']).toBe('no-store')
    expect(JSON.parse(captured.body)).toEqual({ phase: 'copying', done: 2, total: 5 })
    // The next poll reads the moved fact: same route, new answer, no rebuild.
    status = { phase: 'cleaning', done: 4, total: 5 }
    const second = fakeResponse()
    await route.handler(fakeRequest(), second.res)
    expect(JSON.parse(second.captured.body)).toEqual({ phase: 'cleaning', done: 4, total: 5 })
  })

  it('answers null when no migration runs', async () => {
    const route = createMigrationRoute(() => undefined)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(captured.status).toBe(200)
    expect(captured.body).toBe('null')
  })

  it('rejects non-GET methods with 405', async () => {
    const route = createMigrationRoute(() => undefined)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ method: 'POST' }), res)
    expect(captured.status).toBe(405)
  })

  it('refuses cross-site browser fetches with 403', async () => {
    const route = createMigrationRoute(() => undefined)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ headers: { 'sec-fetch-site': 'cross-site' } }), res)
    expect(captured.status).toBe(403)
  })
})

describe('createDirectoryGuardRoute', () => {
  it('answers the judge verdict for the proposed path on GET', async () => {
    const judge = vi.fn((proposed: string | undefined) =>
      ({ blocked: proposed !== 'D:/running', interactingSessions: 2 }))
    const route = createDirectoryGuardRoute(judge)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${DIR_GUARD_PATH}?path=${encodeURIComponent('D:/elsewhere')}` }), res)
    expect(captured.status).toBe(200)
    expect(captured.headers['content-type']).toBe('application/json; charset=utf-8')
    expect(captured.headers['cache-control']).toBe('no-store')
    expect(JSON.parse(captured.body)).toEqual({ blocked: true, interactingSessions: 2 })
    expect(judge).toHaveBeenCalledWith('D:/elsewhere')
  })

  it('treats an absent or blank path as the clear-to-default gesture', async () => {
    const judge = vi.fn((proposed: string | undefined) => ({ blocked: proposed !== undefined, interactingSessions: 0 }))
    const route = createDirectoryGuardRoute(judge)
    for (const url of [DIR_GUARD_PATH, `${DIR_GUARD_PATH}?path=`]) {
      const { res, captured } = fakeResponse()
      await route.handler(fakeRequest({ url }), res)
      expect(JSON.parse(captured.body)).toEqual({ blocked: false, interactingSessions: 0 })
    }
    // Both the missing and the empty parameter mean "no stored path".
    expect(judge).toHaveBeenCalledTimes(2)
    expect(judge).toHaveBeenNthCalledWith(1, undefined)
    expect(judge).toHaveBeenNthCalledWith(2, undefined)
  })

  it('rejects non-GET methods with 405', async () => {
    const route = createDirectoryGuardRoute(() => ({ blocked: false, interactingSessions: 0 }))
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ method: 'POST' }), res)
    expect(captured.status).toBe(405)
  })

  it('refuses cross-site browser fetches with 403', async () => {
    const route = createDirectoryGuardRoute(() => ({ blocked: false, interactingSessions: 0 }))
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ headers: { 'sec-fetch-site': 'cross-site' } }), res)
    expect(captured.status).toBe(403)
  })
})

describe('createFullSyncRoute', () => {
  it('serves the live status as JSON on GET', async () => {
    let view = { status: 'running' as const, processed: 3, total: 10, added: 7, skipped: 0 }
    const route = createFullSyncRoute(() => view, () => ({ started: true }))
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ method: 'GET' }), res)
    expect(captured.status).toBe(200)
    expect(JSON.parse(captured.body)).toEqual(view)
  })

  it('returns 202 on POST when the trigger accepts', async () => {
    const route = createFullSyncRoute(
      () => ({ status: 'idle' as const }),
      () => ({ started: true }),
    )
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ method: 'POST' }), res)
    expect(captured.status).toBe(202)
    expect(JSON.parse(captured.body)).toEqual({ status: 'running' })
  })

  it('returns 409 on POST when the trigger refuses (already running)', async () => {
    const route = createFullSyncRoute(
      () => ({ status: 'running' as const, processed: 1, total: 5, added: 0, skipped: 0 }),
      () => ({ started: false, reason: 'already-running' as const }),
    )
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ method: 'POST' }), res)
    expect(captured.status).toBe(409)
    expect(JSON.parse(captured.body)).toEqual({ error: 'already-running' })
  })

  it('rejects non-GET/POST methods with 405', async () => {
    const route = createFullSyncRoute(
      () => ({ status: 'idle' as const }),
      () => ({ started: true }),
    )
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ method: 'PUT' }), res)
    expect(captured.status).toBe(405)
  })

  it('refuses cross-site browser fetches with 403 on both methods', async () => {
    const route = createFullSyncRoute(
      () => ({ status: 'idle' as const }),
      () => ({ started: true }),
    )
    const get = fakeResponse()
    await route.handler(fakeRequest({ method: 'GET', headers: { 'sec-fetch-site': 'cross-site' } }), get.res)
    expect(get.captured.status).toBe(403)
    const post = fakeResponse()
    await route.handler(fakeRequest({ method: 'POST', headers: { 'sec-fetch-site': 'cross-site' } }), post.res)
    expect(post.captured.status).toBe(403)
  })
})

describe('createStatsRoute relocation', () => {
  it('serves from whatever the directory thunk answers, without rebuilding', async () => {
    const first = await mkdtemp(join(tmpdir(), 'token-usage-reloc-a-'))
    const second = await mkdtemp(join(tmpdir(), 'token-usage-reloc-b-'))
    await writeFile(join(first, 'usage-2026-01-15.jsonl'), `${JSON.stringify(fixtureRecord(100))}\n`)
    await writeFile(join(second, 'usage-2026-01-16.jsonl'), `${JSON.stringify(fixtureRecord(200))}\n${JSON.stringify(fixtureRecord(300))}\n`)
    // The running directory flips mid-life, the way a settled relocation does.
    let dir = first
    const route = createStatsRoute(() => dir)
    const before = fakeResponse()
    await route.handler(fakeRequest(), before.res)
    expect(JSON.parse(before.captured.body).total.requests).toBe(1)
    dir = second
    const after = fakeResponse()
    await route.handler(fakeRequest(), after.res)
    expect(JSON.parse(after.captured.body).total.requests).toBe(2)
  })
})

describe('createPricingRoute', () => {
  it('serves the model-row overview on GET with the currency stamps', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-pricing-route-'))
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 76,
      updatedAt: 1,
      currency: 'RMB',
      usdExchangeRate: 7.25,
      models: [{
        modelId: 'deepseek-chat',
        family: 'deepseek',
        aliasPatterns: ['^deepseek-v3$'],
        inputCostPerMillion: 2,
        outputCostPerMillion: 8,
        cacheReadCostPerMillion: 1,
        cacheCreationCostPerMillion: 4,
      }],
    }))
    const route = createPricingRoute(() => dir, { currency: () => 'USD' })
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(captured.status).toBe(200)
    expect(captured.headers['content-type']).toBe('application/json; charset=utf-8')
    expect(captured.headers['cache-control']).toBe('no-store')
    const body = JSON.parse(captured.body) as {
      currency: string
      usdExchangeRate: number
      models: Array<{ modelId: string; family: string; aliasPatterns: string[]; rules: { base: Record<string, number> } }>
    }
    // The display stamps follow the region thunk; the wire rates stay RMB.
    expect(body.currency).toBe('USD')
    expect(body.usdExchangeRate).toBe(7.25)
    expect(body.models).toHaveLength(1)
    expect(body.models[0]).toMatchObject({ modelId: 'deepseek-chat', family: 'deepseek', aliasPatterns: ['^deepseek-v3$'] })
    expect(body.models[0]!.rules.base).toEqual({ inputPerMillion: 2, outputPerMillion: 8, cacheReadPerMillion: 1, cacheWritePerMillion: 4 })
  })

  it('rejects non-GET methods with 405', async () => {
    const route = createPricingRoute(() => '/')
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ method: 'POST' }), res)
    expect(captured.status).toBe(405)
  })

  it('refuses cross-site browser fetches with 403', async () => {
    const route = createPricingRoute(() => '/')
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ headers: { 'sec-fetch-site': 'cross-site' } }), res)
    expect(captured.status).toBe(403)
  })

  it('answers an absent mirror with an empty model list and the defaults', async () => {
    const dir = join(tmpdir(), `token-usage-pricing-absent-${Date.now()}`)
    const route = createPricingRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(captured.status).toBe(200)
    // Without a currency thunk the display defaults to CNY and the rate to
    // the built-in 7 — the overview stays servable, just empty.
    expect(JSON.parse(captured.body)).toEqual({ models: [], costState: 'pricing-unavailable', pricingUnavailableReason: 'missing', currency: 'CNY', usdExchangeRate: 7 })
  })

  it('maps a read failure to a 500 error JSON', async () => {
    const route = createPricingRoute(() => { throw new Error('boom') })
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(captured.status).toBe(500)
    expect(JSON.parse(captured.body)).toEqual({ error: 'boom' })
  })
})

describe('createPricingSyncRoute', () => {
  it('waits for the mirror write before reporting success', async () => {
    let finish!: (result: any) => void
    const sync = vi.fn(() => new Promise<any>(resolve => { finish = resolve }))
    const route = createPricingSyncRoute(sync)
    expect(route.path).toBe(PRICING_SYNC_PATH)
    const { res, captured } = fakeResponse()
    const request = route.handler(fakeRequest({ method: 'POST' }), res)
    expect(res.end).not.toHaveBeenCalled()
    const result = { version: 12, updatedAt: 1, models: 3, aliasPatterns: 1, usdExchangeRate: 7 }
    finish(result)
    await request
    expect(captured.status).toBe(200)
    expect(captured.headers['cache-control']).toBe('no-store')
    expect(JSON.parse(captured.body)).toEqual(result)
  })

  it.each([
    { method: 'GET', site: 'same-origin', status: 405 },
    { method: 'POST', site: 'cross-site', status: 403 },
  ])('rejects $method from $site without triggering a sync', async ({ method, site, status }) => {
    const sync = vi.fn()
    const { res, captured } = fakeResponse()
    await createPricingSyncRoute(sync).handler(fakeRequest({ method, headers: { 'sec-fetch-site': site } }), res)
    expect(captured.status).toBe(status)
    expect(sync).not.toHaveBeenCalled()
  })

  it.each([
    { error: new Error('upstream failed'), status: 502, code: 'sync-failed' },
    { error: new AssociationError('migration-in-progress'), status: 409, code: 'migration-in-progress' },
    { error: new AssociationError('pricing-source-changed'), status: 409, code: 'pricing-source-changed' },
  ])('reports $code without returning a success result', async ({ error, status, code }) => {
    const { res, captured } = fakeResponse()
    await createPricingSyncRoute(async () => { throw error }).handler(fakeRequest({ method: 'POST' }), res)
    expect(captured.status).toBe(status)
    expect(JSON.parse(captured.body)).toEqual({ error: code })
  })
})

describe('currencyOfRegion', () => {
  it('maps overseas to USD and everything else to CNY', () => {
    expect(currencyOfRegion('overseas')).toBe('USD')
    expect(currencyOfRegion('domestic')).toBe('CNY')
    expect(currencyOfRegion(undefined)).toBe('CNY')
  })
})

describe('plugin webServer wiring', () => {
  let ctx: Context | undefined
  let home: string
  const sessions: Array<{ id: string; events: unknown[] }> = []

  beforeEach(async () => {
    sessions.length = 0
    home = await mkdtemp(join(tmpdir(), 'token-usage-wire-'))
    vi.stubEnv('DSH_HOME', home)
  })

  afterEach(async () => {
    if (ctx !== undefined) {
      ctx.registry.delete(plugin)
      ctx = undefined
    }
    vi.unstubAllEnvs()
    vi.unstubAllGlobals()
  })

  it('manually refreshes the saved source during startup grace, coalesces clicks and preserves the old mirror on failure', async () => {
    const feed = (version: number) => JSON.stringify({ version, currency: 'RMB', models: [
      { modelId: 'm', inputCostPerMillion: version, outputCostPerMillion: 2 },
    ] })
    const fetch = vi.fn(async () => new Response(feed(1)))
    vi.stubGlobal('fetch', fetch)
    const next = new Context()
    await next.plugin(MockWebServer)
    await next.plugin(class extends Service {
      constructor(context: Context) { super(context, 'sessions') }
      list() { return [] }
    })
    await next.plugin(class extends Service {
      constructor(context: Context) { super(context, 'sessionPersistence') }
      async list() { return [] }
    })
    await next.plugin(class extends Service {
      constructor(context: Context) { super(context, 'commands') }
      register() { return () => {} }
    })
    await next.plugin(plugin, { pricingRegion: 'overseas' })
    ctx = next
    const mirror = join(home, 'token-usage', 'pricing.ccsa.json')
    await vi.waitFor(async () => { expect(JSON.parse(await readFile(mirror, 'utf8')).version).toBe(1) })
    const route = (next.webServer as unknown as MockWebServer).routes.find(row => row.path === PRICING_SYNC_PATH)!
    expect(route).toBeDefined()
    let finish!: (response: Response) => void
    fetch.mockImplementationOnce(() => new Promise<Response>(resolve => { finish = resolve }))
    const before = fetch.mock.calls.length
    const first = fakeResponse(), second = fakeResponse()
    const requests = [route.handler(fakeRequest({ method: 'POST' }), first.res), route.handler(fakeRequest({ method: 'POST' }), second.res)]
    expect(fetch).toHaveBeenCalledTimes(before + 1)
    expect(fetch).toHaveBeenLastCalledWith(DEFAULT_PRICING_URL_OVERSEAS, expect.anything())
    finish(new Response(feed(2)))
    await Promise.all(requests)
    expect(first.captured.status).toBe(200)
    expect(second.captured.body).toBe(first.captured.body)
    expect(JSON.parse(await readFile(mirror, 'utf8')).version).toBe(2)
    fetch.mockImplementationOnce(async () => new Response('offline', { status: 503 }))
    const failed = fakeResponse()
    await route.handler(fakeRequest({ method: 'POST' }), failed.res)
    expect(failed.captured.status).toBe(502)
    expect(JSON.parse(await readFile(mirror, 'utf8')).version).toBe(2)
  })

  it('registers the stats route when a webServer exists and serves live rows', async () => {
    const next = new Context()
    await next.plugin(MockWebServer)
    await next.plugin(class extends Service {
      constructor(context: Context) { super(context, 'sessions') }
      list(): Array<{ id: string; snapshotEvents(): unknown[] }> {
        return sessions.map(session => ({ id: session.id, snapshotEvents: () => session.events }))
      }
    })
    await next.plugin(class extends Service {
      constructor(context: Context) { super(context, 'sessionPersistence') }
      async list(): Promise<Array<{ header: { id: string } }>> { return sessions.map(session => ({ header: { id: session.id } })) }
      async open(id: string): Promise<{ read(): Promise<{ events: unknown[] }>; close(): Promise<void> }> {
        const session = sessions.find(candidate => candidate.id === id)
        if (session === undefined) throw new Error(`missing session ${id}`)
        return {
          read: () => Promise.resolve({ events: session.events }),
          close: () => Promise.resolve(),
        }
      }
    })
    await next.plugin(class extends Service {
      constructor(context: Context) { super(context, 'commands') }
      register(): () => void { return () => {} }
    })
    await next.plugin(plugin, {})
    ctx = next

    // ctx.inject runs the callback in a child fiber; wait for it to activate.
    const routes = (next.webServer as unknown as MockWebServer).routes
    const routeDeadline = Date.now() + 2_000
    let route: WebRoute | undefined
    while (Date.now() < routeDeadline) {
      route = routes.find(candidate => candidate.path === STATS_PATH)
      if (route !== undefined) break
      await new Promise(resolve => setTimeout(resolve, 20))
    }
    expect(route).toBeDefined()
    expect(route!.kind).toBe('exact')
    // The relocation progress route registers alongside the stats route.
    expect(routes.some(candidate => candidate.path === MIGRATION_PATH && candidate.kind === 'exact')).toBe(true)
    // The pricing-overview route registers alongside too.
    expect(routes.some(candidate => candidate.path === PRICING_PATH && candidate.kind === 'exact')).toBe(true)
    expect(routes.some(candidate => candidate.path === ASSOCIATIONS_PATH && candidate.kind === 'exact')).toBe(true)
    expect(routes.some(candidate => candidate.path === PRICING_SYNC_PATH && candidate.kind === 'exact')).toBe(true)

    // The directory-guard route registers too and answers the live verdict:
    // no session is mid-conversation here, so a proposed move is not blocked.
    const guardRoute = routes.find(candidate => candidate.path === DIR_GUARD_PATH)
    expect(guardRoute).toBeDefined()
    const guardAnswer = fakeResponse()
    await guardRoute!.handler(fakeRequest({ url: `${DIR_GUARD_PATH}?path=${encodeURIComponent('D:/elsewhere')}` }), guardAnswer.res)
    expect(guardAnswer.captured.status).toBe(200)
    expect(JSON.parse(guardAnswer.captured.body)).toEqual({ blocked: false, interactingSessions: 0 })

    // A live hook row is served by the route.
    next.emit('session/event', { id: 's1' }, messageEvent({ messageId: 'm1' }))
    const deadline = Date.now() + 2_000
    let body = ''
    while (Date.now() < deadline) {
      const { res, captured } = fakeResponse()
      await route!.handler(fakeRequest(), res)
      body = captured.body
      if (JSON.parse(body).total.requests > 0) break
      await new Promise(resolve => setTimeout(resolve, 20))
    }
    expect(JSON.parse(body).total.requests).toBe(1)
    expect(JSON.parse(body).recent[0]).toMatchObject({ requestId: 'm1', model: 'deepseek-chat' })
  })
})

describe('createStatsRoute session table', () => {
  it('serves complete projects before the session top-N cut, respecting day and model filters', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-projects-'))
    const records = Array.from({ length: SESSION_ROW_LIMIT + 1 }, (_, i) => ({
      ...dayRecord(1, 'deepseek-chat'), requestId: `root-${i}`, sessionId: `root-${i}`,
      time: dayRecord(1, 'deepseek-chat').time + i,
      usage: { inputTokens: i === SESSION_ROW_LIMIT ? 1 : 10, outputTokens: 0 },
    }))
    // The oldest and cheapest root must fall outside the bounded session
    // list, but its project (including its child) must remain complete.
    records[SESSION_ROW_LIMIT]!.time -= 10_000
    const child = { ...records[SESSION_ROW_LIMIT]!, requestId: 'child', sessionId: 'child' }
    await writeFile(join(dir, 'usage-2026-01-11.jsonl'), [...records, child, dayRecord(1, 'other-model')].map(row => JSON.stringify(row)).join('\n') + '\n')
    await writeFile(join(dir, 'usage-2026-01-12.jsonl'), JSON.stringify(dayRecord(2, 'deepseek-chat')) + '\n')
    await writeFile(join(dir, 'sessions.json'), JSON.stringify({
      ...Object.fromEntries(records.map((row, i) => [row.sessionId, { cwd: i === SESSION_ROW_LIMIT ? '/work/omitted' : '/work/main' }])),
      child: { cwd: '/work/child', parentSession: `root-${SESSION_ROW_LIMIT}` },
    }))
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({ currency: 'RMB', models: [
      { modelId: 'deepseek-chat', inputCostPerMillion: 1_000_000, outputCostPerMillion: 0 },
    ] }))
    const { res, captured } = fakeResponse()
    await createStatsRoute(() => dir).handler(fakeRequest({ url: `${STATS_PATH}?from=2026-01-11&to=2026-01-11&model=deepseek-chat` }), res)
    expect(captured.status).toBe(200)
    const body = JSON.parse(captured.body) as { sessionRows: SessionUsageRow[]; projectRows: ProjectUsageRow[] }
    expect(body.sessionRows).toHaveLength(SESSION_ROW_LIMIT)
    expect(body.sessionRows.some(row => row.sessionId === `root-${SESSION_ROW_LIMIT}`)).toBe(false)
    expect(body.projectRows.map(row => row.name)).toEqual(['main', 'omitted'])
    expect(body.projectRows[0]).toMatchObject({ sessionCount: SESSION_ROW_LIMIT, cost: 10 * SESSION_ROW_LIMIT })
    expect(body.projectRows[1]).toMatchObject({ sessionCount: 1, cost: 2, totals: { requests: 2, inputTokens: 2 } })
  })

  it('serves folded, cost-sorted session rows with metadata attached', async () => {
    const dir = await sessionDataDir()
    await writeFile(join(dir, 'sessions.json'), JSON.stringify({
      alpha: { title: 'Alpha root', cwd: '/work/app' },
      child: { title: 'Child task', cwd: '/work/app', parentSession: 'alpha' },
    }))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest(), res)
    expect(captured.status).toBe(200)
    const body = JSON.parse(captured.body) as {
      sessionRows: Array<{ sessionId: string; title?: string; cwd?: string; childCount?: number; totals: { requests: number } }>
      bySession?: unknown
    }
    // Default: alpha absorbs child, ranks first by cost.
    expect(body.sessionRows).toHaveLength(1)
    const row = body.sessionRows[0]!
    expect(row.sessionId).toBe('alpha')
    expect(row.title).toBe('Alpha root')
    expect(row.cwd).toBe('/work/app')
    expect(row.childCount).toBe(1)
    expect(row.totals.requests).toBe(3)
    // The granular cells stay behind the route.
    expect(body.bySession).toBeUndefined()
  })

  it('ignores a stale sessionScope query parameter (the fold is unconditional)', async () => {
    const dir = await sessionDataDir()
    await writeFile(join(dir, 'sessions.json'), JSON.stringify({
      alpha: { title: 'Alpha root', cwd: '/work/app' },
      child: { title: 'Child task', cwd: '/work/app', parentSession: 'alpha' },
    }))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionScope=flat` }), res)
    const body = JSON.parse(captured.body) as { sessionRows: Array<{ sessionId: string; childCount?: number }> }
    // The fold no longer takes a query dimension: rows always fold over
    // subagent subtrees, so the stale parameter changes nothing.
    expect(body.sessionRows).toHaveLength(1)
    expect(body.sessionRows[0]!.sessionId).toBe('alpha')
    expect(body.sessionRows[0]!.childCount).toBe(1)
  })

  it('falls back to short identities when the index is missing', async () => {
    const dir = await sessionDataDir()
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?sessionScope=flat` }), res)
    expect(captured.status).toBe(200)
    const body = JSON.parse(captured.body) as { sessionRows: Array<{ sessionId: string; title?: string; cwd?: string }> }
    // No sessions.json: rows still reconcile, identity fields simply omit.
    expect(body.sessionRows).toHaveLength(2)
    for (const row of body.sessionRows) {
      expect(row.title).toBeUndefined()
      expect(row.cwd).toBeUndefined()
    }
  })

  it('expands a root + scope range rule into ids and child groups server-side', async () => {
    const dir = await scopeDataDir()
    const route = createStatsRoute(() => dir)
    const query = async (search: string) => {
      const { res, captured } = fakeResponse()
      await route.handler(fakeRequest({ url: STATS_PATH + search }), res)
      expect(captured.status).toBe(200)
      return JSON.parse(captured.body)
    }
    const tree = await query('?root=alpha&scope=subtree&fields=session')
    expect(tree.total.requests).toBe(3)
    expect(tree.sessionIds).toEqual(['alpha', 'child', 'grandchild'])
    expect(Object.keys(tree.children)).toEqual(['child'])
    // The direct child's row folds in its own grandchild.
    expect(tree.children.child.total.requests).toBe(2)
    // TTFT / throughput come from the two timed records in the group, not
    // from a runtime session mirror projection.
    expect(tree.children.child.timing).toEqual({
      ttftMs: 300, ttftSteps: 2, decodeMs: 1_000, decodeTokens: 10,
    })
    // `self` keeps the header to the root, but the subagent table still
    // lists direct children (each with its own records only).
    const self = await query('?root=alpha&fields=session')
    expect(self.total.requests).toBe(1)
    expect(self.sessionIds).toEqual(['alpha'])
    expect(self.children.child.total.requests).toBe(1)
    expect(self.children.child.timing).toEqual({
      ttftMs: 100, ttftSteps: 1, decodeMs: 400, decodeTokens: 5,
    })
  })

  it('keeps the request size constant for a subtree of hundreds of sessions', async () => {
    const dir = await scopeDataDir()
    const meta = JSON.parse(await readFile(join(dir, 'sessions.json'), 'utf8')) as Record<string, unknown>
    for (let i = 0; i < 200; i += 1) meta[`child-${i}`] = { parentSession: 'alpha', origin: 'subagent' }
    await writeFile(join(dir, 'sessions.json'), JSON.stringify(meta))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    const url = `${STATS_PATH}?root=alpha&scope=subtree&fields=session`
    // This is the whole point: 200+ subagents used to produce a ~17 KiB
    // request line and HTTP 431; the rule stays under 80 characters.
    expect(url.length).toBeLessThan(80)
    await route.handler(fakeRequest({ url }), res)
    expect(captured.status).toBe(200)
    const body = JSON.parse(captured.body)
    expect(body.sessionIds).toHaveLength(203)
    expect(Object.keys(body.children)).toHaveLength(201)
    // Only three sessions own records; the extra children contribute rows,
    // not phantom usage.
    expect(body.total.requests).toBe(3)
  })

  it('degrades a root with no known lineage to the root alone instead of erroring', async () => {
    const dir = await scopeDataDir()
    await unlink(join(dir, 'sessions.json'))
    const route = createStatsRoute(() => dir)
    const { res, captured } = fakeResponse()
    await route.handler(fakeRequest({ url: `${STATS_PATH}?root=alpha&scope=subtree&fields=session` }), res)
    expect(captured.status).toBe(200)
    const body = JSON.parse(captured.body)
    expect(body.sessionIds).toEqual(['alpha'])
    expect(body.total.requests).toBe(1)
    expect(body.children).toBeUndefined()
  })
})
