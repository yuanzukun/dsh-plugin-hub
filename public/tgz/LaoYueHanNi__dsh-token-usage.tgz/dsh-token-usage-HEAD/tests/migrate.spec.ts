/**
 * Two-phase data-directory migration tests: files copy verbatim with size
 * verification, the target's same-named file wins, a copy failure aborts
 * with the source intact, and cleanup removes only files that verifiably
 * landed (same name, same size) plus the emptied directory.
 */
import { existsSync } from 'node:fs'
import { mkdir, mkdtemp, readFile, readdir, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { BACKUPS_DIR } from '../src/backup.ts'
import { cleanSource, copyData, type MigrationProgress } from '../src/migrate.ts'
import { ASSOCIATIONS_FILE } from '../src/pricing-associations.ts'

let oldDir: string
let newDir: string

beforeEach(async () => {
  oldDir = await mkdtemp(join(tmpdir(), 'token-usage-mig-old-'))
  newDir = await mkdtemp(join(tmpdir(), 'token-usage-mig-new-'))
})

describe('association migration byte protection', () => {
  it.each(['{broken', JSON.stringify({ version: 1, revision: 2, associations: [{ sourceModel: 'P/name', targetModelId: 'a' }] })])('copies even unparseable choices verbatim and cleans only identical bytes', async bytes => {
    await writeFile(join(oldDir, ASSOCIATIONS_FILE), bytes)
    expect(await copyData(oldDir, newDir)).toContain(ASSOCIATIONS_FILE)
    expect(await readFile(join(newDir, ASSOCIATIONS_FILE), 'utf8')).toBe(bytes)
    await cleanSource(oldDir, newDir)
    expect(existsSync(join(oldDir, ASSOCIATIONS_FILE))).toBe(false)
  })
  it('reuses an identical target file', async () => {
    await Promise.all([oldDir, newDir].map(dir => writeFile(join(dir, ASSOCIATIONS_FILE), 'same')))
    expect(await copyData(oldDir, newDir)).toContain(ASSOCIATIONS_FILE)
    await cleanSource(oldDir, newDir)
    expect(existsSync(oldDir)).toBe(false)
  })
  it('same-size conflict aborts before copying anything or deleting target rollup', async () => {
    await writeFile(join(oldDir, ASSOCIATIONS_FILE), 'left')
    await writeFile(join(newDir, ASSOCIATIONS_FILE), 'rght')
    await writeFile(join(oldDir, 'state.json'), 'marker')
    await writeFile(join(newDir, 'rollup.json'), 'cache')
    await expect(copyData(oldDir, newDir)).rejects.toThrow('migration conflict')
    expect(existsSync(join(newDir, 'state.json'))).toBe(false)
    expect(await readFile(join(newDir, 'rollup.json'), 'utf8')).toBe('cache')
    expect(await readFile(join(oldDir, ASSOCIATIONS_FILE), 'utf8')).toBe('left')
    expect(await readFile(join(newDir, ASSOCIATIONS_FILE), 'utf8')).toBe('rght')
  })
  it('cleanup keeps source if target choices changed with the same size', async () => {
    await writeFile(join(oldDir, ASSOCIATIONS_FILE), 'left')
    await copyData(oldDir, newDir)
    await writeFile(join(newDir, ASSOCIATIONS_FILE), 'rght')
    expect(await cleanSource(oldDir, newDir)).toMatchObject({ cleaned: 0 })
    expect(await readFile(join(oldDir, ASSOCIATIONS_FILE), 'utf8')).toBe('left')
  })
  it('an unreadable source is not treated as absent', async () => {
    await mkdir(join(oldDir, ASSOCIATIONS_FILE))
    await writeFile(join(newDir, 'rollup.json'), 'cache')
    await expect(copyData(oldDir, newDir)).rejects.toThrow()
    expect(await readFile(join(newDir, 'rollup.json'), 'utf8')).toBe('cache')
  })
})

describe('provider name registry', () => {
  it('copies providers.json with the data directory', async () => {
    await writeFile(join(oldDir, 'providers.json'), '{"deepseek-official":"DeepSeek"}')
    expect(await copyData(oldDir, newDir)).toContain('providers.json')
    expect(await readFile(join(newDir, 'providers.json'), 'utf8')).toBe('{"deepseek-official":"DeepSeek"}')
    await cleanSource(oldDir, newDir)
    expect(existsSync(join(oldDir, 'providers.json'))).toBe(false)
  })
})

describe('copyData', () => {
  it('copies every owned file verbatim and reports per-file progress', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'a\nb\n')
    await writeFile(join(oldDir, 'usage-2026-01-16.jsonl'), 'c\n')
    await writeFile(join(oldDir, 'state.json'), '{"initializedAt":1}')
    await writeFile(join(oldDir, 'pricing.json'), '{"deepseek-chat":{}}')
    await writeFile(join(oldDir, 'pricing.ccsa.json'), '{"version":4}')
    await writeFile(join(oldDir, 'rollup.json'), '{"upto":"2026-01-14"}')

    const seen: MigrationProgress[] = []
    const copied = await copyData(oldDir, newDir, p => { seen.push(p) })

    // The rollup is derived state: it stays behind (the source cleanup drops
    // it) instead of traveling, and the target rebuilds it on first read.
    expect(copied).toHaveLength(5)
    expect(await readFile(join(newDir, 'usage-2026-01-15.jsonl'), 'utf8')).toBe('a\nb\n')
    expect(await readFile(join(newDir, 'state.json'), 'utf8')).toBe('{"initializedAt":1}')
    // Day files keep their per-day names: nothing is re-bucketed.
    expect(existsSync(join(newDir, 'usage-2026-01-16.jsonl'))).toBe(true)
    // Monotone per-file progress over the copying phase.
    expect(seen.at(-1)).toMatchObject({ done: 5, total: 5, phase: 'copying' })
    expect(seen.every(step => step.phase === 'copying')).toBe(true)
    // The source is untouched by the copy phase.
    expect(await readFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'utf8')).toBe('a\nb\n')
  })

  it('drops a stale rollup sitting in the target directory', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'a\n')
    await writeFile(join(newDir, 'rollup.json'), '{"upto":"2025-12-31"}')

    await copyData(oldDir, newDir)

    // A stale aggregate would serve wrong totals until its lazy rebuild;
    // removing it makes the first stats read rebuild from the copied days.
    expect(existsSync(join(newDir, 'rollup.json'))).toBe(false)
  })

  it('leaves a target-side same-named file alone and counts it as settled', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'old content\n')
    await writeFile(join(newDir, 'usage-2026-01-15.jsonl'), 'live content\n')

    const copied = await copyData(oldDir, newDir)

    expect(copied).toEqual(['usage-2026-01-15.jsonl'])
    expect(await readFile(join(newDir, 'usage-2026-01-15.jsonl'), 'utf8')).toBe('live content\n')
  })

  it('ignores files the plugin does not own', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'a\n')
    await writeFile(join(oldDir, 'notes.txt'), 'user data')

    const copied = await copyData(oldDir, newDir)

    expect(copied).toEqual(['usage-2026-01-15.jsonl'])
    expect(existsSync(join(newDir, 'notes.txt'))).toBe(false)
  })

  it('aborts on a failed copy with the source fully intact', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'a\n')
    await writeFile(join(oldDir, 'usage-2026-01-16.jsonl'), 'c\n')
    // Real failure injection: a regular file where the target directory
    // must be, so the target mkdir/copy refuses.
    const { rm } = await import('node:fs/promises')
    await rm(newDir, { recursive: true })
    await writeFile(newDir, 'not a directory')

    await expect(copyData(oldDir, newDir)).rejects.toThrow()
    // The source kept everything.
    expect(existsSync(join(oldDir, 'usage-2026-01-15.jsonl'))).toBe(true)
    expect(existsSync(join(oldDir, 'usage-2026-01-16.jsonl'))).toBe(true)
  })

  it('is a no-op when the source directory does not exist', async () => {
    const copied = await copyData(join(oldDir, 'missing'), newDir)
    expect(copied).toEqual([])
    expect((await readdir(newDir)).length).toBe(0)
  })
})

describe('cleanSource', () => {
  it('removes files that verifiably landed, the source rollup, and the emptied directory', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'a\n')
    await writeFile(join(oldDir, 'rollup.json'), '{"upto":"2026-01-15"}')
    await copyData(oldDir, newDir)

    const seen: MigrationProgress[] = []
    const result = await cleanSource(oldDir, newDir, p => { seen.push(p) })

    expect(result).toMatchObject({ cleaned: 1 })
    expect(existsSync(join(oldDir, 'usage-2026-01-15.jsonl'))).toBe(false)
    // The derived rollup leaves with the directory so the source can go.
    expect(existsSync(join(oldDir, 'rollup.json'))).toBe(false)
    expect(existsSync(oldDir)).toBe(false)
    expect(seen.at(-1)).toMatchObject({ done: 1, total: 1, phase: 'cleaning' })
  })

  it('keeps a source file whose copy is missing in the target', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'a\n')
    await writeFile(join(oldDir, 'usage-2026-01-16.jsonl'), 'c\n')
    // Only one file was copied (the second failed and aborted).
    await copyFileSafe(join(oldDir, 'usage-2026-01-15.jsonl'), join(newDir, 'usage-2026-01-15.jsonl'))

    await cleanSource(oldDir, newDir)

    expect(existsSync(join(oldDir, 'usage-2026-01-15.jsonl'))).toBe(false)
    expect(existsSync(join(oldDir, 'usage-2026-01-16.jsonl'))).toBe(true)
    expect(existsSync(oldDir)).toBe(true)
  })

  it('keeps a source file whose landed copy has a different size', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'a\nb\nc\n')
    // A torn or diverged target copy must not authorize the delete.
    await writeFile(join(newDir, 'usage-2026-01-15.jsonl'), 'a\n')

    await cleanSource(oldDir, newDir)

    expect(existsSync(join(oldDir, 'usage-2026-01-15.jsonl'))).toBe(true)
  })

  it('keeps the directory when an unknown file remains', async () => {
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'a\n')
    await writeFile(join(oldDir, 'user-notes.txt'), 'keep me')
    await copyData(oldDir, newDir)

    await cleanSource(oldDir, newDir)

    expect(existsSync(join(oldDir, 'usage-2026-01-15.jsonl'))).toBe(false)
    expect(existsSync(join(oldDir, 'user-notes.txt'))).toBe(true)
    expect(existsSync(oldDir)).toBe(true)
  })
})

/** Plain copy used by the cleanup tests to stage a landed file. */
async function copyFileSafe(source: string, destination: string): Promise<void> {
  const { copyFile } = await import('node:fs/promises')
  await copyFile(source, destination)
}

describe('.backups migration compatibility', () => {
  it('copies plugin backup snapshots with size verification and empties source directory cleanly', async () => {
    const snap = '20261122-143000-001-00-reconcile'
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'live\n', 'utf8')
    await mkdir(join(oldDir, BACKUPS_DIR, snap), { recursive: true })
    await writeFile(join(oldDir, BACKUPS_DIR, snap, 'usage-2026-01-15.jsonl'), 'before-reconcile\n', 'utf8')

    const copied = await copyData(oldDir, newDir)
    expect(copied).toEqual([
      'usage-2026-01-15.jsonl',
      join(BACKUPS_DIR, snap, 'usage-2026-01-15.jsonl'),
    ])
    expect(await readFile(join(newDir, BACKUPS_DIR, snap, 'usage-2026-01-15.jsonl'), 'utf8'))
      .toBe('before-reconcile\n')

    const result = await cleanSource(oldDir, newDir)
    expect(result).toEqual({ copied: 2, cleaned: 2 })
    expect(existsSync(oldDir)).toBe(false)
  })

  it('preserves existing target backup files and keeps foreign files inside .backups intact', async () => {
    const snap = '20261122-143000-001-00-refile'
    await mkdir(join(oldDir, BACKUPS_DIR, snap), { recursive: true })
    await writeFile(join(oldDir, BACKUPS_DIR, snap, 'usage-2026-01-15.jsonl'), 'source-backup\n', 'utf8')
    await writeFile(join(oldDir, BACKUPS_DIR, 'user-notes.txt'), 'keep me', 'utf8')
    await mkdir(join(newDir, BACKUPS_DIR, snap), { recursive: true })
    await writeFile(join(newDir, BACKUPS_DIR, snap, 'usage-2026-01-15.jsonl'), 'target-backup\n', 'utf8')

    await copyData(oldDir, newDir)
    expect(await readFile(join(newDir, BACKUPS_DIR, snap, 'usage-2026-01-15.jsonl'), 'utf8'))
      .toBe('target-backup\n')

    await cleanSource(oldDir, newDir)
    expect(existsSync(join(oldDir, BACKUPS_DIR, snap))).toBe(false)
    expect(await readFile(join(oldDir, BACKUPS_DIR, 'user-notes.txt'), 'utf8')).toBe('keep me')
    expect(existsSync(oldDir)).toBe(true)
  })

  it('treats equivalent paths pointing to the same physical directory as a no-op without deleting files', async () => {
    const snap = '20261122-143000-001-00-reconcile'
    await writeFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'keep-me\n', 'utf8')
    await mkdir(join(oldDir, BACKUPS_DIR, snap), { recursive: true })
    await writeFile(join(oldDir, BACKUPS_DIR, snap, 'usage-2026-01-15.jsonl'), 'keep-backup\n', 'utf8')

    const equivalent = join(oldDir, '.')
    expect(await copyData(oldDir, equivalent)).toEqual([])
    expect(await cleanSource(oldDir, equivalent)).toEqual({ copied: 0, cleaned: 0 })
    expect(await readFile(join(oldDir, 'usage-2026-01-15.jsonl'), 'utf8')).toBe('keep-me\n')
    expect(await readFile(join(oldDir, BACKUPS_DIR, snap, 'usage-2026-01-15.jsonl'), 'utf8')).toBe('keep-backup\n')
  })
})
