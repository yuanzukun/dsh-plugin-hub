import { describe, expect, it } from 'vitest'
import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots'
import { currencyViewOf, failuresTooltip, formatCost, formatRate, formatRateWithSymbol, overheadTooltip, providerLabel } from '../src/client/format.ts'
import { en, zh } from '../src/client/locales.ts'

const t = ((key: string): string => (zh as Record<string, string>)[key] ?? key) as TranslateNS<'token-usage'>
const tEn = ((key: string): string => (en as Record<string, string>)[key] ?? key) as TranslateNS<'token-usage'>

describe('formatCost', () => {
  it('formats with two decimals and the suffixed ¥ symbol (number-first idiom)', () => {
    expect(formatCost(1.25)).toBe('1.25￥')
    expect(formatCost(0)).toBe('0.00￥')
    expect(formatCost(123.456)).toBe('123.46￥')
    expect(formatCost(12345.6)).toBe('12345.60￥')
  })

  it('converts through a USD view, dividing by the exchange rate', () => {
    const usd = currencyViewOf({ currency: 'USD', usdExchangeRate: 7 })
    expect(formatCost(0, usd)).toBe('0.00$')
    // 1.4 RMB ÷ 7 = 0.20$.
    expect(formatCost(1.4, usd)).toBe('0.20$')
    // 7 RMB ÷ 7 = 1.00$.
    expect(formatCost(7, usd)).toBe('1.00$')
    // 123.45 RMB ÷ 7 = 17.6357… → 17.64$.
    expect(formatCost(123.45, usd)).toBe('17.64$')
  })
})

describe('formatRate', () => {
  it('keeps integral rates bare', () => {
    expect(formatRate(2)).toBe('2')
    expect(formatRate(16)).toBe('16')
  })

  it('keeps a two-decimal minimum for fractional rates', () => {
    expect(formatRate(0.5)).toBe('0.50')
    expect(formatRate(1.5)).toBe('1.50')
  })

  it('keeps exact fractional rates up to four decimals', () => {
    expect(formatRate(0.25)).toBe('0.25')
    expect(formatRate(2.1)).toBe('2.10')
    expect(formatRate(0.025)).toBe('0.025')
  })

  it('converts through a USD view before formatting', () => {
    const usd = currencyViewOf({ currency: 'USD', usdExchangeRate: 7 })
    // 14 ÷ 7 = 2 stays integral and bare.
    expect(formatRate(14, usd)).toBe('2')
    // 8 ÷ 7 = 1.142857… → four decimals.
    expect(formatRate(8, usd)).toBe('1.1429')
    // 3.5 ÷ 7 = 0.5 → two-decimal minimum.
    expect(formatRate(3.5, usd)).toBe('0.50')
  })
})

describe('formatRateWithSymbol', () => {
  it('prefixes the view symbol onto the converted rate', () => {
    expect(formatRateWithSymbol(8)).toBe('￥8')
    expect(formatRateWithSymbol(0.5)).toBe('￥0.50')
    const usd = currencyViewOf({ currency: 'USD', usdExchangeRate: 7 })
    expect(formatRateWithSymbol(8, usd)).toBe('$1.1429')
    expect(formatRateWithSymbol(14, usd)).toBe('$2')
  })
})

describe('currencyViewOf', () => {
  it('returns the RMB pass-through view for CNY summaries', () => {
    expect(currencyViewOf({ currency: 'CNY', usdExchangeRate: 7 })).toEqual({ symbol: '￥', rate: 1 })
  })

  it('carries the wire exchange rate for USD summaries', () => {
    expect(currencyViewOf({ currency: 'USD', usdExchangeRate: 7.25 })).toEqual({ symbol: '$', rate: 7.25 })
  })
})

describe('failuresTooltip', () => {
  it('renders one label ×count line per class, largest first', () => {
    expect(failuresTooltip({ RATE_LIMIT: 16, TRANSPORT: 2 }, t)).toBe('限流 ×16\n网络异常 ×2')
    // Ties break on the code name ascending (RATE_LIMIT before TRANSPORT).
    expect(failuresTooltip({ TRANSPORT: 1, RATE_LIMIT: 1 }, t)).toBe('限流 ×1\n网络异常 ×1')
  })

  it('maps every tracked provider code to a Chinese label', () => {
    expect(failuresTooltip({ INVALID_REQUEST: 2, AUTH: 1 }, t)).toBe('请求无效 ×2\n鉴权失败 ×1')
  })

  it('localizes CONTENT_REFUSED and account/model failure codes in both zh and en', () => {
    expect(failuresTooltip({
      CONTENT_REFUSED: 3,
      ACCOUNT_QUOTA: 2,
      ACCOUNT_SIGN_IN_REQUIRED: 1,
      ACCOUNT_TOKEN_INVALID: 1,
    }, t)).toBe('内容安全拒绝 ×3\n账号余额不足 ×2\n需要登录账号 ×1\n账号凭证无效 ×1')
    expect(failuresTooltip({
      CONTENT_REFUSED: 3,
      ACCOUNT_QUOTA: 2,
      ACCOUNT_SIGN_IN_REQUIRED: 1,
      ACCOUNT_TOKEN_INVALID: 1,
    }, tEn)).toBe('Content refused ×3\nAccount quota exceeded ×2\nSign-in required ×1\nAccount token invalid ×1')
  })

  it('falls back to the raw code when the locale has no label', () => {
    expect(failuresTooltip({ BRAND_NEW_CODE: 3 }, t)).toBe('BRAND_NEW_CODE ×3')
  })

  it('yields an empty string for nothing to show', () => {
    expect(failuresTooltip(undefined, t)).toBe('')
    expect(failuresTooltip({}, t)).toBe('')
    expect(failuresTooltip({ RATE_LIMIT: 0 }, t)).toBe('')
  })
})

describe('providerLabel', () => {
  it('prefers the registry name and falls back to the route key', () => {
    expect(providerLabel('zai-coding-cn', { 'zai-coding-cn': '智谱 Coding' })).toBe('智谱 Coding')
    // A route the registry never saw still displays — the key is the identity.
    expect(providerLabel('gone', { 'zai-coding-cn': '智谱 Coding' })).toBe('gone')
    expect(providerLabel('gone')).toBe('gone')
    expect(providerLabel('gone', {})).toBe('gone')
  })

  it('treats an empty registry entry as no name', () => {
    expect(providerLabel('zai-coding-cn', { 'zai-coding-cn': '' })).toBe('zai-coding-cn')
  })
})

describe('overheadTooltip', () => {
  it('includes refused billed aux failures alongside successful calls', () => {
    expect(overheadTooltip([
      {
        auxKind: 'session-title',
        totals: { requests: 0, failures: 2, inputTokens: 20, outputTokens: 5, cacheReadTokens: 0, cacheWriteTokens: 0 },
        cost: 0.01,
        byModel: [],
      },
      {
        auxKind: 'auto-review',
        totals: { requests: 1, inputTokens: 10, outputTokens: 2, cacheReadTokens: 0, cacheWriteTokens: 0 },
        cost: 0.005,
        byModel: [],
      },
    ], t)).toBe('标题生成 ×2\n自动审查 ×1')
  })
})

describe('overheadTooltip', () => {
  it('localizes every AuxKind including timeline-report in zh and en', () => {
    const byKind = [
      { auxKind: 'auto-review' as const, totals: { requests: 2, inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }, cost: 0, byModel: [] },
      { auxKind: 'timeline-report' as const, totals: { requests: 3, inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 }, cost: 0, byModel: [] },
    ]
    expect(overheadTooltip(byKind, t)).toBe('时间线报告 ×3\n自动审查 ×2')
    expect(overheadTooltip(byKind, tEn)).toBe('Timeline reports ×3\nAuto review ×2')
  })
})
