import { mkdtemp, readFile, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  canonicalMapOf,
  canonicalName,
  cloudToTable,
  coerceCloudPricing,
  costOf,
  DEFAULT_PRICING_URL,
  DEFAULT_PRICING_URL_DOMESTIC,
  DEFAULT_PRICING_URL_OVERSEAS,
  ratesForKey,
  readPricingOverview,
  readPricingTable,
  readUsdExchangeRate,
  resolvePricingUrl,
  resolveRate,
  syncCloudPricing,
} from '../src/pricing.ts'
import type { ModelRates } from '../src/wire.ts'
import { hasRateRules } from '../src/wire.ts'
import type { UsageTotals } from '../src/wire.ts'

/** One totals row fixture. */
function totals(overrides: Partial<UsageTotals> = {}): UsageTotals {
  return {
    requests: 1,
    inputTokens: 0,
    outputTokens: 0,
    cacheReadTokens: 0,
    cacheWriteTokens: 0,
    ...overrides,
  }
}

/** A flat rule set (base rates only), the shape a cloud model produces. */
function flat(input: number, output: number, cacheRead?: number, cacheWrite?: number): ModelRates {
  return {
    base: {
      inputPerMillion: input,
      outputPerMillion: output,
      ...(cacheRead !== undefined ? { cacheReadPerMillion: cacheRead } : {}),
      ...(cacheWrite !== undefined ? { cacheWritePerMillion: cacheWrite } : {}),
    },
    contextTiers: [],
    dailySlots: [],
    timeRules: [],
  }
}

describe('costOf', () => {
  it('bills each bucket at its own per-million rate', () => {
    const row = totals({ inputTokens: 1_000_000, outputTokens: 500_000, cacheReadTokens: 250_000 })
    expect(costOf(row, { inputPerMillion: 2, outputPerMillion: 8, cacheReadPerMillion: 0.5 }))
      .toBe(2 + 4 + 0.125)
  })

  it('falls cache buckets back to the input rate when their rate is absent', () => {
    const row = totals({ inputTokens: 1_000_000, cacheReadTokens: 1_000_000, cacheWriteTokens: 1_000_000 })
    expect(costOf(row, { inputPerMillion: 2, outputPerMillion: 8 })).toBe(6)
  })

  it('supports zero and fractional rates', () => {
    const row = totals({ inputTokens: 2_000_000, outputTokens: 4_000_000 })
    expect(costOf(row, { inputPerMillion: 0.5, outputPerMillion: 0.25 })).toBe(1 + 1)
  })
})

describe('resolveRate (the analyzer rule chain)', () => {
  /** UTC+0 test tz: local minute == UTC minute. */
  const TZ = 0

  /** A model with every rule dimension, mirroring deepseek-v4-flash's shape. */
  const RULE_END = 1_786_710_000 // 2026-08-14 15:00 UTC
  const rules: ModelRates = {
    base: { inputPerMillion: 1.5, outputPerMillion: 4.5, cacheReadPerMillion: 0.05 },
    contextTiers: [{ threshold: 512_000, rates: { inputPerMillion: 3, outputPerMillion: 9, cacheReadPerMillion: 0.1 } }],
    dailySlots: [{
      windows: [{ startMinute: 540, endMinute: 720 }],
      rates: { inputPerMillion: 3.0, outputPerMillion: 9.0, cacheReadPerMillion: 0.1 },
    }],
    timeRules: [{
      startTime: 0,
      endTime: RULE_END,
      rates: { inputPerMillion: 1.0, outputPerMillion: 2.0, cacheReadPerMillion: 0.02 },
      contextTiers: [{ threshold: 256_000, rates: { inputPerMillion: 2.0, outputPerMillion: 4.0, cacheReadPerMillion: 0.04 } }],
    }],
  }

  it('bills inside a time rule at the rule rates', () => {
    // 2026-08-14 12:00 UTC (past the 540..720 window), inside the rule span.
    const at = Date.UTC(2026, 7, 14, 12, 0, 0)
    const resolved = resolveRate(rules, at, 1000, TZ)
    expect(resolved.prices.inputPerMillion).toBe(1.0)
    expect(resolved.key).toEqual({ ruleStart: 0, ruleEnd: RULE_END, tier: 0, slot: -1 })
  })

  it('bills after the rule window at the base rates, peak window at peak rates', () => {
    // 2026-08-15 10:00 UTC — after the rule, inside the peak window (540..720).
    const peak = resolveRate(rules, Date.UTC(2026, 7, 15, 10, 0, 0), 1000, TZ)
    expect(peak.prices.inputPerMillion).toBe(3.0)
    expect(peak.key).toEqual({ ruleStart: 0, ruleEnd: 0, tier: 0, slot: 0 })
    // Same day off-peak (20:00 UTC) falls to the base rates.
    const off = resolveRate(rules, Date.UTC(2026, 7, 15, 20, 0, 0), 1000, TZ)
    expect(off.prices.inputPerMillion).toBe(1.5)
    expect(off.key.slot).toBe(-1)
  })

  it('matches the tier inside the time rule by input-side tokens', () => {
    // Inside the rule with enough context: rule tier rates apply (no slots on it).
    const at = Date.UTC(2026, 7, 14, 10, 0, 0)
    const big = resolveRate(rules, at, 300_000, TZ)
    expect(big.prices.inputPerMillion).toBe(2.0)
    expect(big.key).toEqual({ ruleStart: 0, ruleEnd: RULE_END, tier: 256_000, slot: -1 })
    // Below the tier: plain rule rates — the rule window bills flat even at
    // a peak minute, because slots hang on the node, not the root.
    const small = resolveRate(rules, at, 100_000, TZ)
    expect(small.prices.inputPerMillion).toBe(1.0)
    expect(small.key).toEqual({ ruleStart: 0, ruleEnd: RULE_END, tier: 0, slot: -1 })
  })

  it('matches the root tier once outside every rule', () => {
    const at = Date.UTC(2026, 7, 15, 20, 0, 0) // off-peak, past the rule
    const big = resolveRate(rules, at, 600_000, TZ)
    expect(big.prices.inputPerMillion).toBe(3)
    expect(big.key).toEqual({ ruleStart: 0, ruleEnd: 0, tier: 512_000, slot: -1 })
  })

  it('respects the local timezone for peak windows', () => {
    // 01:00 UTC is 09:00 at UTC+8 → inside the 09:00–12:00 local window;
    // 08:00 UTC is 16:00 at UTC+8 → outside it.
    const rulesUtc8 = { ...rules, timeRules: [], contextTiers: [] }
    const inside = resolveRate(rulesUtc8, Date.UTC(2026, 7, 15, 1, 0, 0), 0, 8)
    expect(inside.key.slot).toBe(0)
    const outside = resolveRate(rulesUtc8, Date.UTC(2026, 7, 15, 8, 0, 0), 0, 8)
    expect(outside.key.slot).toBe(-1)
  })

  it('ratesForKey re-prices an identity under the same table', () => {
    expect(ratesForKey(rules, { ruleStart: 0, ruleEnd: RULE_END, tier: 0, slot: -1 }).inputPerMillion).toBe(1.0)
    expect(ratesForKey(rules, { ruleStart: 0, ruleEnd: 0, tier: 0, slot: 0 }).inputPerMillion).toBe(3.0)
    expect(ratesForKey(rules, { ruleStart: 0, ruleEnd: 0, tier: 512_000, slot: -1 }).inputPerMillion).toBe(3)
  })

  it('ratesForKey falls back to the base rates on structural drift', () => {
    // The rule window no longer exists in a trimmed table.
    const trimmed: ModelRates = { ...rules, timeRules: [], contextTiers: [], dailySlots: [] }
    expect(ratesForKey(trimmed, { ruleStart: 0, ruleEnd: RULE_END, tier: 0, slot: -1 }).inputPerMillion).toBe(1.5)
  })
})

describe('dailySlots.daysOfWeek (weekday-only peak)', () => {
  /** UTC+0 test tz unless stated otherwise. */
  const TZ = 0

  // DeepSeek V4 shape (feed v72): peak slots are weekdays-only since
  // 2026-08-23 (weekends all-day off-peak); the former every-day peak era
  // (08-17..08-22) is a time rule carrying its own unrestricted slot.
  const ERA_END = 1_787_414_399 // 2026-08-22 23:59:59 UTC+8
  const weekdayPeak: ModelRates = {
    base: { inputPerMillion: 1.5, outputPerMillion: 4.5, cacheReadPerMillion: 0.05 },
    contextTiers: [],
    dailySlots: [{
      windows: [{ startMinute: 540, endMinute: 720 }, { startMinute: 840, endMinute: 1080 }],
      daysOfWeek: [1, 2, 3, 4, 5],
      rates: { inputPerMillion: 3.0, outputPerMillion: 9.0, cacheReadPerMillion: 0.1 },
    }],
    timeRules: [{
      label: '每日峰谷期',
      startTime: 1_786_896_000, // 2026-08-17 00:00 UTC+8
      endTime: ERA_END,
      rates: { inputPerMillion: 1.5, outputPerMillion: 4.5, cacheReadPerMillion: 0.05 },
      dailySlots: [{
        windows: [{ startMinute: 540, endMinute: 720 }, { startMinute: 840, endMinute: 1080 }],
        rates: { inputPerMillion: 3.0, outputPerMillion: 9.0, cacheReadPerMillion: 0.1 },
      }],
    }],
  }

  it('bills a weekend inside the peak windows at the base (off-peak) rates', () => {
    // 2026-08-29 is a Saturday; 10:00 UTC sits inside the 540..720 window.
    const resolved = resolveRate(weekdayPeak, Date.UTC(2026, 7, 29, 10, 0, 0), 1000, TZ)
    expect(resolved.prices.inputPerMillion).toBe(1.5)
    expect(resolved.key).toEqual({ ruleStart: 0, ruleEnd: 0, tier: 0, slot: -1 })
  })

  it('bills a weekday inside the peak windows at the slot rates', () => {
    // 2026-08-31 is a Monday, same minute of day as the weekend case.
    const resolved = resolveRate(weekdayPeak, Date.UTC(2026, 7, 31, 10, 0, 0), 1000, TZ)
    expect(resolved.prices.inputPerMillion).toBe(3.0)
    expect(resolved.key).toEqual({ ruleStart: 0, ruleEnd: 0, tier: 0, slot: 0 })
  })

  it('keeps the historical era peak every day, weekends included', () => {
    // 2026-08-22 is a Saturday but sits in the every-day-peak era rule; the
    // era slot carries no daysOfWeek, so the weekday check must not apply.
    const resolved = resolveRate(weekdayPeak, Date.UTC(2026, 7, 22, 10, 0, 0), 1000, TZ)
    expect(resolved.prices.inputPerMillion).toBe(3.0)
    expect(resolved.key).toEqual({ ruleStart: 1_786_896_000, ruleEnd: ERA_END, tier: 0, slot: 0 })
  })

  it('matches the weekday on the local clock, not the UTC day', () => {
    // 2026-08-30 20:00 UTC is Monday 2026-08-31 10:00 at UTC+14 — inside the
    // peak window on the local (Monday) calendar, though the UTC day is Sunday.
    const resolved = resolveRate(weekdayPeak, Date.UTC(2026, 7, 30, 20, 0, 0), 1000, 14)
    expect(resolved.prices.inputPerMillion).toBe(3.0)
    expect(resolved.key.slot).toBe(0)
  })

  it('ratesForKey re-prices a weekend row at the base rates under the new table', () => {
    expect(ratesForKey(weekdayPeak, { ruleStart: 0, ruleEnd: 0, tier: 0, slot: -1 }).inputPerMillion).toBe(1.5)
  })

  it('coercion keeps valid ISO weekdays and degrades garbage to every-day', () => {
    const table = cloudToTable(coerceCloudPricing({
      version: 72,
      updatedAt: 0,
      currency: 'RMB',
      models: [{
        modelId: 'deepseek-v4',
        inputCostPerMillion: 1.5,
        outputCostPerMillion: 4.5,
        dailySlots: [
          { windows: [{ startMinute: 540, endMinute: 720 }], daysOfWeek: [1, '2', 0, 7.5, 8, 5, 1], inputCostPerMillion: 3, outputCostPerMillion: 9 },
          { windows: [{ startMinute: 540, endMinute: 720 }], daysOfWeek: ['x', 0], inputCostPerMillion: 3, outputCostPerMillion: 9 },
          { windows: [{ startMinute: 540, endMinute: 720 }], inputCostPerMillion: 3, outputCostPerMillion: 9 },
        ],
      }],
    })!)
    const slots = table['deepseek-v4']!.dailySlots
    expect(slots[0]!.daysOfWeek).toEqual([1, 5])
    expect(slots[1]!.daysOfWeek).toBeUndefined()
    expect(slots[2]!.daysOfWeek).toBeUndefined()
  })
})

describe('readPricingTable', () => {
  it('yields an empty table when the cloud mirror is absent', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-pricing-'))
    expect(await readPricingTable(dir)).toEqual({})
  })

  it('ignores a hand-edited pricing.json even when it carries valid entries', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-pricing-'))
    await writeFile(join(dir, 'pricing.json'), JSON.stringify({
      'deepseek-chat': { inputPerMillion: 1, outputPerMillion: 4 },
    }))
    // The manual file is no longer read: the only source is the cloud mirror,
    // absent here, so the table is empty rather than picking up the override.
    expect(await readPricingTable(dir)).toEqual({})
  })

  it('ignores a malformed pricing.json without affecting the cloud mirror', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-pricing-'))
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 4,
      updatedAt: 1,
      currency: 'RMB',
      models: [{ modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 8 }],
    }))
    await writeFile(join(dir, 'pricing.json'), '{not json')
    expect(await readPricingTable(dir)).toEqual({
      'deepseek-chat': flat(2, 8),
    })
  })

  it('flattens the cloud mirror and keeps the rule chain (tiers, slots, time rules)', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-pricing-'))
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 57,
      updatedAt: 1,
      currency: 'RMB',
      models: [{
        modelId: 'deepseek-v4-flash',
        inputCostPerMillion: 1.5, outputCostPerMillion: 4.5, cacheReadCostPerMillion: 0.05,
        contextTiers: [{ threshold: 512000, inputCostPerMillion: 3, outputCostPerMillion: 9, cacheReadCostPerMillion: 0.1 }],
        dailySlots: [{ label: '工作日高峰时段', windows: [{ startMinute: 540, endMinute: 720 }, { startMinute: 840, endMinute: 1080 }], daysOfWeek: [1, 2, 3, 4, 5], inputCostPerMillion: 3, outputCostPerMillion: 9, cacheReadCostPerMillion: 0.1 }],
        timeRules: [{ label: '原价', startTime: 0, endTime: 1786895999, inputCostPerMillion: 1, outputCostPerMillion: 2, cacheReadPerMillion: 0.02, cacheReadCostPerMillion: 0.02 }],
      }],
    }))
    const table = await readPricingTable(dir)
    const rules = table['deepseek-v4-flash']!
    expect(hasRateRules(rules)).toBe(true)
    expect(rules.timeRules[0]!.rates.inputPerMillion).toBe(1)
    expect(rules.contextTiers[0]!.threshold).toBe(512000)
    // The slot's label and weekday restriction survive the flatten — the
    // pricing dialog renders both.
    expect(rules.dailySlots[0]!.windows).toHaveLength(2)
    expect(rules.dailySlots[0]!.label).toBe('工作日高峰时段')
    expect(rules.dailySlots[0]!.daysOfWeek).toEqual([1, 2, 3, 4, 5])
  })
})

describe('readPricingOverview', () => {
  it('keeps the model-row shape: one row per model, aliases and family intact', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-overview-'))
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 76,
      updatedAt: 1,
      currency: 'RMB',
      models: [{
        modelId: 'deepseek-v4-flash',
        family: 'deepseek',
        aliasPatterns: ['^deepseek-flash$', '^dsv4-flash$'],
        inputCostPerMillion: 1.5,
        outputCostPerMillion: 4.5,
        contextTiers: [{ threshold: 512000, inputCostPerMillion: 3, outputCostPerMillion: 9 }],
      }],
    }))
    const rows = await readPricingOverview(dir)
    expect(rows).toHaveLength(1)
    // The row carries the model-row shape the overview serves — not the
    // alias-keyed flat table, which would repeat the model per alias.
    expect(rows[0]).toEqual({
      modelId: 'deepseek-v4-flash',
      aliasPatterns: ['^deepseek-flash$', '^dsv4-flash$'],
      family: 'deepseek',
      rules: {
        base: { inputPerMillion: 1.5, outputPerMillion: 4.5 },
        contextTiers: [{ threshold: 512000, rates: { inputPerMillion: 3, outputPerMillion: 9 } }],
        dailySlots: [],
        timeRules: [],
      },
    })
  })

  it('reads an empty list for absent, malformed, or non-RMB mirrors', async () => {
    const absent = await mkdtemp(join(tmpdir(), 'token-usage-overview-'))
    expect(await readPricingOverview(absent)).toEqual([])
    const broken = await mkdtemp(join(tmpdir(), 'token-usage-overview-'))
    await writeFile(join(broken, 'pricing.ccsa.json'), '{not json')
    expect(await readPricingOverview(broken)).toEqual([])
    const usd = await mkdtemp(join(tmpdir(), 'token-usage-overview-'))
    await writeFile(join(usd, 'pricing.ccsa.json'), JSON.stringify({ version: 1, currency: 'USD', models: [] }))
    expect(await readPricingOverview(usd)).toEqual([])
  })
})

describe('coerceCloudPricing', () => {
  it('accepts an RMB feed and drops invalid model rows', () => {
    const feed = coerceCloudPricing({
      version: 4,
      updatedAt: 1_780_000_000,
      currency: 'RMB',
      models: [
        { modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 8, aliasPatterns: ['^deepseek-v3$'] },
        { modelId: 'broken', inputCostPerMillion: -1, outputCostPerMillion: 2 },
        { inputCostPerMillion: 1, outputCostPerMillion: 2 },
      ],
    })
    expect(feed).not.toBeNull()
    expect(feed!.models).toHaveLength(1)
    expect(feed!.models[0]).toMatchObject({ modelId: 'deepseek-chat', aliasPatterns: ['^deepseek-v3$'] })
  })

  it('refuses non-RMB currencies and wrong envelopes', () => {
    expect(coerceCloudPricing({ version: 1, currency: 'USD', models: [] })).toBeNull()
    expect(coerceCloudPricing({ version: 1, models: [] })).toBeNull()
    expect(coerceCloudPricing({ models: 'nope' })).toBeNull()
    expect(coerceCloudPricing(null)).toBeNull()
  })

  it('parses a usable envelope exchange rate', () => {
    const feed = coerceCloudPricing({ version: 1, currency: 'RMB', usdExchangeRate: 7.25, models: [] })
    expect(feed).not.toBeNull()
    expect(feed!.usdExchangeRate).toBe(7.25)
  })

  it('drops missing, zero, negative, and non-numeric exchange rates', () => {
    const envelope = (rate: unknown) => coerceCloudPricing({ version: 1, currency: 'RMB', usdExchangeRate: rate, models: [] })
    expect(envelope(undefined)!.usdExchangeRate).toBeUndefined()
    expect(envelope(0)!.usdExchangeRate).toBeUndefined()
    expect(envelope(-1)!.usdExchangeRate).toBeUndefined()
    expect(envelope(NaN)!.usdExchangeRate).toBeUndefined()
    expect(envelope(Infinity)!.usdExchangeRate).toBeUndefined()
    expect(envelope('7')!.usdExchangeRate).toBeUndefined()
  })

  it('keeps a string family per model row and drops non-string or empty ones', () => {
    const feed = coerceCloudPricing({
      version: 76,
      currency: 'RMB',
      models: [
        { modelId: 'deepseek-chat', family: 'deepseek', inputCostPerMillion: 2, outputCostPerMillion: 8 },
        { modelId: 'glm-4.7', family: 'glm', inputCostPerMillion: 1, outputCostPerMillion: 2 },
        { modelId: 'weird-family', family: 7, inputCostPerMillion: 1, outputCostPerMillion: 2 },
        { modelId: 'empty-family', family: '', inputCostPerMillion: 1, outputCostPerMillion: 2 },
      ],
    })
    expect(feed!.models.map(model => model.family)).toEqual(['deepseek', 'glm', undefined, undefined])
  })
})

describe('readUsdExchangeRate', () => {
  it('returns the mirror envelope rate when present', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-rate-'))
    await writeFile(join(dir, 'pricing.ccsa.json'), JSON.stringify({
      version: 4, updatedAt: 0, currency: 'RMB', usdExchangeRate: 7.3,
      models: [],
    }))
    expect(await readUsdExchangeRate(dir)).toBe(7.3)
  })

  it('falls back to the built-in rate without a mirror or a rate', async () => {
    const absent = await mkdtemp(join(tmpdir(), 'token-usage-rate-'))
    expect(await readUsdExchangeRate(absent)).toBe(7)
    const noprice = await mkdtemp(join(tmpdir(), 'token-usage-rate-'))
    await writeFile(join(noprice, 'pricing.ccsa.json'), JSON.stringify({
      version: 4, updatedAt: 0, currency: 'RMB', models: [],
    }))
    expect(await readUsdExchangeRate(noprice)).toBe(7)
  })

  it('falls back on a broken or non-RMB mirror', async () => {
    const broken = await mkdtemp(join(tmpdir(), 'token-usage-rate-'))
    await writeFile(join(broken, 'pricing.ccsa.json'), 'not json')
    expect(await readUsdExchangeRate(broken)).toBe(7)
    const usd = await mkdtemp(join(tmpdir(), 'token-usage-rate-'))
    await writeFile(join(usd, 'pricing.ccsa.json'), JSON.stringify({ version: 1, currency: 'USD', models: [] }))
    expect(await readUsdExchangeRate(usd)).toBe(7)
  })
})

describe('cloudToTable', () => {
  it('resolves optional regex names through both helpers without enumerating or guessing aliases', () => {
    const models = [{ modelId: 'm', aliasPatterns: ['^other(-(low|high))?$'], inputCostPerMillion: 2, outputCostPerMillion: 3 }]
    const table = cloudToTable({ currency: 'RMB', version: 1, updatedAt: 0, models })
    const canonical = canonicalMapOf(models)
    expect(Object.keys(table)).toEqual(['m'])
    expect([...canonical]).toEqual([['m', 'm']])
    expect(table['provider/OTHER-high']).toBe(table.m)
    expect(canonical.get('provider/OTHER-high')).toBe('m')
    expect(canonical.has('other-low')).toBe(true)
    expect(table['other-fast']).toBeUndefined()
    expect(table['other-low\n']).toBeUndefined()
    expect(canonical.get('other-fast')).toBeUndefined()
    const conflict = cloudToTable({ currency: 'RMB', version: 1, updatedAt: 0, models: [
      ...models, { ...models[0]!, modelId: 'n' },
    ] })
    expect(conflict['other-high']).toBeUndefined()
  })
  it('maps fields, expands aliases, and keeps the rule chain', () => {
    const table = cloudToTable({
      version: 4,
      updatedAt: 0,
      currency: 'RMB',
      models: [{
        modelId: 'claude-sonnet-4-20250514',
        inputCostPerMillion: 21,
        outputCostPerMillion: 105,
        cacheReadCostPerMillion: 2.1,
        cacheCreationCostPerMillion: 26.25,
        aliasPatterns: ['^claude-sonnet-4$'],
        contextTiers: [{ threshold: 128000, inputCostPerMillion: 42, outputCostPerMillion: 210 }],
      }],
    })
    const expected: ModelRates = {
      base: { inputPerMillion: 21, outputPerMillion: 105, cacheReadPerMillion: 2.1, cacheWritePerMillion: 26.25 },
      contextTiers: [{ threshold: 128000, rates: { inputPerMillion: 42, outputPerMillion: 210 } }],
      dailySlots: [],
      timeRules: [],
    }
    expect(table['claude-sonnet-4']).toEqual(expected)
    expect(table['claude-sonnet-4-20250514']).toEqual(expected)
  })

  it('lets a model id win a collision with another model\'s alias', () => {
    const table = cloudToTable({
      version: 4,
      updatedAt: 0,
      currency: 'RMB',
      models: [
        { modelId: 'alias-holder', inputCostPerMillion: 1, outputCostPerMillion: 1, aliasPatterns: ['^shared-name$'] },
        { modelId: 'shared-name', inputCostPerMillion: 9, outputCostPerMillion: 9 },
      ],
    })
    expect(table['shared-name']!.base).toEqual({ inputPerMillion: 9, outputPerMillion: 9 })
  })
})

describe('canonicalMapOf', () => {
  it('maps aliases onto the modelId and leaves the id pointing at itself', () => {
    const map = canonicalMapOf([
      { modelId: 'deepseek-v4-flash', aliasPatterns: ['^deepseek-v4-flash-0731$', '^deepseek-v4-flash-08xx$'] },
    ])
    expect(map.get('deepseek-v4-flash')).toBe('deepseek-v4-flash')
    expect(map.get('deepseek-v4-flash-0731')).toBe('deepseek-v4-flash')
    expect(map.get('deepseek-v4-flash-08xx')).toBe('deepseek-v4-flash')
    expect(canonicalName('deepseek-v4-flash-0731', map)).toBe('deepseek-v4-flash')
    expect(canonicalName('unpriced-model', map)).toBe('unpriced-model')
    expect(canonicalName('unpriced-model')).toBe('unpriced-model')
  })

  it('lets a model id win a collision with another model\'s alias', () => {
    const map = canonicalMapOf([
      { modelId: 'alias-holder', aliasPatterns: ['^shared-name$'] },
      { modelId: 'shared-name' },
    ])
    expect(map.get('shared-name')).toBe('shared-name')
    expect(map.get('alias-holder')).toBe('alias-holder')
  })

  it('leaves a cross-model shared alias unresolved', () => {
    const map = canonicalMapOf([
      { modelId: 'a', aliasPatterns: ['^shared$'] },
      { modelId: 'b', aliasPatterns: ['^shared$'] },
    ])
    expect(map.get('shared')).toBeUndefined()
    expect(map.get('a')).toBe('a')
    expect(map.get('b')).toBe('b')
  })
})

describe('resolvePricingUrl', () => {
  it('defaults to the domestic (gitee) mirror', () => {
    expect(resolvePricingUrl()).toBe(DEFAULT_PRICING_URL_DOMESTIC)
    expect(resolvePricingUrl({})).toBe(DEFAULT_PRICING_URL_DOMESTIC)
    expect(DEFAULT_PRICING_URL).toBe(DEFAULT_PRICING_URL_DOMESTIC)
  })

  it('picks the overseas (github) mirror for the overseas region', () => {
    expect(resolvePricingUrl({ pricingRegion: 'overseas' })).toBe(DEFAULT_PRICING_URL_OVERSEAS)
  })

  it('lets per-region overrides replace their default', () => {
    expect(resolvePricingUrl({ pricingUrlDomestic: 'https://a/feed.json' }))
      .toBe('https://a/feed.json')
    expect(resolvePricingUrl({ pricingRegion: 'overseas', pricingUrlOverseas: 'https://b/feed.json' }))
      .toBe('https://b/feed.json')
  })

  it('lets an explicit pricingUrl win over every region setting', () => {
    expect(resolvePricingUrl({
      pricingUrl: 'https://explicit/feed.json',
      pricingRegion: 'overseas',
      pricingUrlDomestic: 'https://a',
      pricingUrlOverseas: 'https://b',
    })).toBe('https://explicit/feed.json')
  })
})

describe('syncCloudPricing', () => {
  afterEach(() => {
    vi.unstubAllGlobals()
  })

  /** A minimal RMB feed body. */
  const FEED = JSON.stringify({
    version: 4,
    updatedAt: 1_780_000_000,
    currency: 'RMB',
    models: [
      { modelId: 'deepseek-chat', inputCostPerMillion: 2, outputCostPerMillion: 8, aliasPatterns: ['^deepseek-v3$'] },
    ],
  })

  it('mirrors the feed verbatim and reports its shape', async () => {
    const fetch = vi.fn(async () => new Response(FEED))
    vi.stubGlobal('fetch', fetch)
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-sync-'))
    const result = await syncCloudPricing(dir, 'https://example.com/feed.json')
    expect(result).toEqual({ version: 4, updatedAt: 1_780_000_000, models: 1, aliasPatterns: 1, usdExchangeRate: 7 })
    expect(fetch).toHaveBeenCalledWith('https://example.com/feed.json', expect.anything())
    // The mirror keeps the raw feed (plus a trailing newline); the merged
    // read already reflects it.
    expect(await readFile(join(dir, 'pricing.ccsa.json'), 'utf8')).toBe(`${FEED}\n`)
    const table = await readPricingTable(dir)
    expect(Object.keys(table)).toEqual(['deepseek-chat'])
    expect(table['deepseek-v3']).toEqual(flat(2, 8))
  })
  it('syncs an upstream regex containing a literal colon', async () => {
    const payload = JSON.stringify({ version: 115, updatedAt: 1, currency: 'RMB', models: [{
      modelId: 'nemotron-3-super', inputCostPerMillion: 1, outputCostPerMillion: 2,
      aliasPatterns: ['^nemotron-3-super-120b-a12b:free$'],
    }] })
    vi.stubGlobal('fetch', vi.fn(async () => new Response(payload)))
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-colon-sync-'))
    const result = await syncCloudPricing(dir, 'https://example.com/feed.json')
    expect(result).toMatchObject({ version: 115, models: 1, aliasPatterns: 1 })
    expect(await readFile(join(dir, 'pricing.ccsa.json'), 'utf8')).toBe(`${payload}\n`)
    const table = await readPricingTable(dir)
    expect(table['nemotron-3-super-120b-a12b:free']).toBe(table['nemotron-3-super'])
  })

  it('rejects a non-RMB feed without writing the mirror', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
      version: 1, updatedAt: 0, currency: 'USD', models: [],
    }))))
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-sync-'))
    await expect(syncCloudPricing(dir, 'https://example.com/feed.json')).rejects.toThrow(/RMB/)
    expect(await readPricingTable(dir)).toEqual({})
  })

  it('surfaces HTTP failures', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('nope', { status: 503 })))
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-sync-'))
    await expect(syncCloudPricing(dir, 'https://example.com/feed.json')).rejects.toThrow(/503/)
  })

  it('retains the previous mirror when the source changes during a fetch', async () => {
    const dir = await mkdtemp(join(tmpdir(), 'token-usage-stale-sync-'))
    await writeFile(join(dir, 'pricing.ccsa.json'), FEED)
    let finish!: (response: Response) => void
    vi.stubGlobal('fetch', vi.fn(() => new Promise<Response>(resolve => { finish = resolve })))
    let current = true
    const task = syncCloudPricing(dir, 'https://example.com/old-feed.json', () => current)
    current = false
    finish(new Response(FEED.replace('"version":4', '"version":5')))
    await expect(task).rejects.toMatchObject({ code: 'pricing-source-changed' })
    expect(await readFile(join(dir, 'pricing.ccsa.json'), 'utf8')).toBe(FEED)
  })

  it('creates a missing data directory before landing the mirror', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(FEED)))
    // A fresh install may not have a data dir yet (no usage recorded).
    const dir = join(tmpdir(), `token-usage-absent-${Date.now()}-${Math.random().toString(36).slice(2)}`)
    const result = await syncCloudPricing(dir, 'https://example.com/feed.json')
    expect(result.models).toBe(1)
    const table = await readPricingTable(dir)
    expect(table['deepseek-chat']).toEqual(flat(2, 8))
    expect(table['deepseek-v3']).toBe(table['deepseek-chat'])
  })
})
