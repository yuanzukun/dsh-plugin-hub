import { mkdtemp } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { createHash } from 'node:crypto'
import { afterEach, describe, expect, it, vi } from 'vitest'
import {
  CODEX_TOKEN_URL,
  createCodexService,
  createPkce,
  decodeJwtPayload,
} from '../src/codex.js'
import { loadCodexCredential, saveCodexCredential } from '../src/storage.js'

function context(): { credentials: { set: ReturnType<typeof vi.fn>; unset: ReturnType<typeof vi.fn> }; logger: { info: ReturnType<typeof vi.fn>; warn: ReturnType<typeof vi.fn> }; values: Map<string, string> } {
  const values = new Map<string, string>()
  return {
    credentials: {
      set: vi.fn(async (ref: string, value: string) => void values.set(ref, value)),
      unset: vi.fn(async (ref: string) => void values.delete(ref)),
    },
    logger: { info: vi.fn(), warn: vi.fn() },
    values,
  }
}

function jwt(payload: Record<string, unknown>): string {
  const encode = (value: unknown) => Buffer.from(JSON.stringify(value)).toString('base64url')
  return `${encode({ alg: 'none' })}.${encode(payload)}.`
}

async function home(): Promise<string> {
  return mkdtemp(join(tmpdir(), 'dsh-oauth-codex-'))
}

afterEach(() => {
  vi.restoreAllMocks()
  vi.useRealTimers()
})

describe('Codex OAuth', () => {
  it('creates a correct PKCE S256 challenge', () => {
    const { verifier, challenge } = createPkce()
    expect(challenge).toBe(createHash('sha256').update(verifier).digest('base64url'))
  })

  it('decodes account ID claims without verifying JWT signatures', () => {
    const token = jwt({ 'https://api.openai.com/auth': { chatgpt_account_id: 'account-1' } })
    expect(decodeJwtPayload(token)).toMatchObject({ 'https://api.openai.com/auth': { chatgpt_account_id: 'account-1' } })
  })

  it('publishes authentication state through startup, logout, and refresh recovery', async () => {
    const dshHome = await home()
    const ctx = context()
    const states: boolean[] = []
    const service = createCodexService(ctx as never, { dshHome, onAuthStateChange: state => void states.push(state) })
    await service.initialize()
    expect(states).toEqual([false])

    await saveCodexCredential({ accessToken: 'access', refreshToken: 'refresh', expiresAt: Date.now() + 3_600_000, accountId: 'account' }, dshHome)
    await service.initialize()
    expect(states).toEqual([false, true])
    await service.logout()
    expect(states).toEqual([false, true, false])
    await service.dispose()
  })

  it('keeps OAuth successful when route synchronization fails', async () => {
    const dshHome = await home()
    const ctx = context()
    const originalFetch = globalThis.fetch
    const accessToken = jwt({ chatgpt_account_id: 'account-1' })
    vi.stubGlobal('fetch', vi.fn(async (input: RequestInfo | URL) => {
      if (String(input) === CODEX_TOKEN_URL) return new Response(JSON.stringify({ access_token: accessToken, refresh_token: 'refresh', expires_in: 3600 }))
      return originalFetch(input)
    }))
    const service = createCodexService(ctx as never, { dshHome, codexRedirectPort: 0, onAuthStateChange: async () => { throw new Error('settings unavailable') } })
    const { authUrl } = await service.startCodexLogin()
    const callbackPort = new URL(authUrl).searchParams.get('redirect_uri')!.match(/:(\d+)\//)![1]
    const state = new URL(authUrl).searchParams.get('state')!
    const callback = await originalFetch(`http://127.0.0.1:${callbackPort}/auth/callback?code=test-code&state=${encodeURIComponent(state)}`)
    expect(callback.status).toBe(200)
    expect(await loadCodexCredential(dshHome)).toMatchObject({ accessToken, refreshToken: 'refresh', accountId: 'account-1' })
    expect(ctx.values.get('DSH_OPENAI_CODEX_TOKEN')).toBe(accessToken)
    await service.dispose()
  })

  it('contains synchronous route retry failures', async () => {
    vi.useFakeTimers()
    const dshHome = await home()
    await saveCodexCredential({ accessToken: 'access', refreshToken: 'refresh', expiresAt: Date.now() + 3_600_000, accountId: 'account' }, dshHome)
    const callback = vi.fn(() => { throw new Error('settings conflict') })
    const service = createCodexService(context() as never, { dshHome, onAuthStateChange: callback })

    await service.initialize()
    expect(callback).toHaveBeenCalledTimes(1)
    await vi.advanceTimersByTimeAsync(1_000)
    expect(callback).toHaveBeenCalledTimes(2)
    await service.dispose()
  })

  it('rejects a mismatched OAuth state', async () => {
    const ctx = context()
    const service = createCodexService(ctx as never, { codexRedirectPort: 0 })
    const { authUrl } = await service.startCodexLogin()
    const port = new URL(authUrl).searchParams.get('redirect_uri')!.match(/:(\d+)\//)![1]
    const response = await fetch(`http://127.0.0.1:${port}/auth/callback?code=test&state=wrong`)
    expect(response.status).toBe(400)
    expect(ctx.logger.warn).toHaveBeenCalledWith('Codex login failed (CODEX_OAUTH_STATE_MISMATCH)')
    await service.dispose()
  })

  it('refreshes expired tokens and clears permanently invalid credentials', async () => {
    const dshHome = await home()
    const ctx = context()
    const states: boolean[] = []
    await saveCodexCredential({ accessToken: 'old', refreshToken: 'old-refresh', expiresAt: 0, accountId: 'account' }, dshHome)
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ access_token: 'new', expires_in: 3600 }), { status: 200 })))
    const service = createCodexService(ctx as never, { dshHome, onAuthStateChange: state => void states.push(state) })
    expect(await service.getCodexAccessToken()).toBe('new')
    expect((await loadCodexCredential(dshHome))?.refreshToken).toBe('old-refresh')
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ error: 'refresh_token_expired' }), { status: 400 })))
    await saveCodexCredential({ accessToken: 'old', refreshToken: 'old-refresh', expiresAt: 0, accountId: 'account' }, dshHome)
    await expect(service.getCodexAccessToken()).rejects.toMatchObject({ code: 'CODEX_AUTH_REQUIRED' })
    expect(await loadCodexCredential(dshHome)).toBeUndefined()
    expect(ctx.credentials.unset).toHaveBeenCalled()
    expect(states).toEqual([true, false])
    await service.dispose()
  })

  it('refreshes a still-valid token from the scheduled expiry window', async () => {
    vi.useFakeTimers()
    vi.setSystemTime(0)
    const dshHome = await home()
    const ctx = context()
    await saveCodexCredential({ accessToken: 'old', refreshToken: 'refresh', expiresAt: 120_000, accountId: 'account' }, dshHome)
    const fetch = vi.fn(async () => new Response(JSON.stringify({ access_token: 'new', expires_in: 3600 }), { status: 200 }))
    vi.stubGlobal('fetch', fetch)
    const service = createCodexService(ctx as never, { dshHome })

    await service.initialize()
    expect(ctx.values.get('DSH_OPENAI_CODEX_TOKEN')).toBe('old')
    await vi.advanceTimersByTimeAsync(60_001)
    vi.useRealTimers()
    await new Promise<void>(resolve => setTimeout(resolve, 10))

    expect(fetch).toHaveBeenCalledTimes(1)
    expect(ctx.values.get('DSH_OPENAI_CODEX_TOKEN')).toBe('new')
    await service.dispose()
  })

  it('retries a transient startup refresh failure', async () => {
    vi.useFakeTimers()
    vi.setSystemTime(0)
    const dshHome = await home()
    const ctx = context()
    await saveCodexCredential({ accessToken: 'old', refreshToken: 'refresh', expiresAt: 0, accountId: 'account' }, dshHome)
    let attempts = 0
    const fetch = vi.fn(async () => {
      attempts += 1
      if (attempts === 1) throw new Error('temporary network failure')
      return new Response(JSON.stringify({ access_token: 'new', expires_in: 3600 }), { status: 200 })
    })
    vi.stubGlobal('fetch', fetch)
    const service = createCodexService(ctx as never, { dshHome })

    await service.initialize()
    expect(fetch).toHaveBeenCalledTimes(1)
    await vi.advanceTimersByTimeAsync(30_001)
    vi.useRealTimers()
    await new Promise<void>(resolve => setTimeout(resolve, 10))

    expect(fetch).toHaveBeenCalledTimes(2)
    expect(ctx.values.get('DSH_OPENAI_CODEX_TOKEN')).toBe('new')
    await service.dispose()
  })

  it('serializes logout after an in-flight refresh', async () => {
    const dshHome = await home()
    const ctx = context()
    await saveCodexCredential({ accessToken: 'old', refreshToken: 'refresh', expiresAt: 0, accountId: 'account' }, dshHome)
    let resolveRefresh!: (response: Response) => void
    const refreshResponse = new Promise<Response>(resolve => {
      resolveRefresh = resolve
    })
    const fetch = vi.fn(() => refreshResponse)
    vi.stubGlobal('fetch', fetch)
    const service = createCodexService(ctx as never, { dshHome })

    const refresh = service.getCodexAccessToken()
    await vi.waitFor(() => expect(fetch).toHaveBeenCalledTimes(1))
    const logout = service.logout()
    resolveRefresh(new Response(JSON.stringify({ access_token: 'new', expires_in: 3600 }), { status: 200 }))

    await expect(refresh).resolves.toBe('new')
    await logout
    expect(await loadCodexCredential(dshHome)).toBeUndefined()
    expect(ctx.credentials.unset).toHaveBeenCalled()
    await service.dispose()
  })
})
