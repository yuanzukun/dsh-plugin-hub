// dsh-skills-manager 双语词典对齐测试（零第三方依赖）
// 断言：zh/en 词典 key 集合完全一致；每个模板的 {xxx} 占位符集合完全一致。
// 运行：node test/locale-test.mjs

import { readFile } from "node:fs/promises";
import react from "react";
import * as reactDom from "react-dom";

let passed = 0;
let failed = 0;
function ok(cond, msg) {
  if (cond) {
    passed++;
  } else {
    failed++;
    console.error("✗ " + msg);
  }
}
function eq(actual, expected, msg) {
  ok(
    actual === expected,
    msg +
      " (got " +
      JSON.stringify(actual) +
      ", want " +
      JSON.stringify(expected) +
      ")",
  );
}

/** 提取模板字符串中的 {xxx} 占位符集合（顺序无关）。 */
function placeholders(template) {
  const set = new Set();
  const re = /\{(\w+)\}/g;
  let match;
  while ((match = re.exec(template)) !== null) set.add(match[1]);
  return set;
}
/** 集合比较：与顺序无关，仅比对成员。 */
function sameSet(a, b, msg) {
  const av = JSON.stringify([...a].sort());
  const bv = JSON.stringify([...b].sort());
  ok(av === bv, msg + " (got " + av + ", want " + bv + ")");
}

const source = await readFile(
  new URL("../src/client.ts", import.meta.url),
  "utf8",
);
const literalSource = [
  source,
  await readFile(new URL("../src/repository-ui.ts", import.meta.url), "utf8"),
  await readFile(new URL("../src/plugin-update-ui.ts", import.meta.url), "utf8"),
].join("\n");
const bundleSource = await readFile(
  process.env.DSH_CLIENT_TEST_BUNDLE || new URL("../lib/client.js", import.meta.url),
  "utf8",
);
const manifest = JSON.parse(
  await readFile(new URL("../package.json", import.meta.url), "utf8"),
);

// 模拟宿主 AMD 加载器：执行 bundle，捕获 load 定义，再调用 factory 读取导出。
let loaded = null;
const fakeWindow = {
  __ModuleLoader__: {
    load(definition) {
      loaded = definition;
    },
  },
};
new Function("window", bundleSource)(fakeWindow);
ok(
  loaded !== null && typeof loaded.factory === "function",
  "client bundle registers via window.__ModuleLoader__.load with a factory",
);

const bundle = loaded.factory((id) => {
  if (id === "react") return react;
  if (id === "react/jsx-runtime") return { jsx: react.createElement, jsxs: react.createElement, Fragment: react.Fragment };
  if (id.startsWith("react-dom")) return reactDom;
  if (id === "@deepseek-ai/dsh-client-ui-primitives") {
    return {
      Button: (props) => react.createElement("button", props, props.children),
      Input: (props) => react.createElement("span", { className: props.className }, react.createElement("input", props)),
      Modal: (props) => props.open ? react.createElement("div", { role: "dialog", title: props.title }, props.children, props.footer) : null,
      Menu: (props) => react.createElement("div", { "data-menu-open": props.open }, props.anchor, props.open ? props.items?.map(it => react.createElement("button", { key: it.id, onClick: () => props.onSelect(it.id) }, it.label)) : null),
    };
  }
  throw new Error("unexpected require: " + id);
});

const DICT = bundle.DICT;
ok(
  DICT !== undefined && DICT.zh !== undefined && DICT.en !== undefined,
  "factory exports the zh/en dictionaries",
);

const zhKeys = Object.keys(DICT.zh).sort();
const enKeys = Object.keys(DICT.en).sort();
eq(
  zhKeys.length,
  enKeys.length,
  "zh and en dictionaries have the same key count",
);
for (let i = 0; i < Math.max(zhKeys.length, enKeys.length); i++) {
  eq(zhKeys[i], enKeys[i], "dictionary key " + (i + 1) + " is aligned");
}

// 命名约定：点分小写为主（如 btn.refresh、status.enabled）；业务错误码段允许 camelCase
// （如 error.skill.notFound、error.source.tooDeep），首段仍必须小写字母开头。
for (const key of zhKeys) {
  ok(
    /^[a-z][A-Za-z0-9]*(?:\.[A-Za-z0-9]+)*$/.test(key),
    "key uses dot-lowercase naming: " + key,
  );
}

// 占位符对齐：每个 key 的模板在 zh/en 中引用完全相同的参数名。
for (const key of zhKeys) {
  sameSet(
    placeholders(DICT.zh[key]),
    placeholders(DICT.en[key]),
    'placeholder set of "' + key + '" matches across zh/en',
  );
  ok(
    typeof DICT.zh[key] === "string" && DICT.zh[key].length > 0,
    'zh value of "' + key + '" is a non-empty string',
  );
  ok(
    typeof DICT.en[key] === "string" && DICT.en[key].length > 0,
    'en value of "' + key + '" is a non-empty string',
  );
}

const hostSources = await Promise.all([
  readFile(new URL("../lib/core.js", import.meta.url), "utf8"),
  readFile(new URL("../lib/index.js", import.meta.url), "utf8"),
]);
const hostCodes = new Set();
for (const hostSource of hostSources) {
  for (const match of hostSource.matchAll(
    /["']((?:error|warning|diagnostic)\.[A-Za-z]+(?:\.[A-Za-z]+)*)["']/g,
  ))
    hostCodes.add(match[1]);
}
for (const code of hostCodes) {
  ok(
    code in DICT.zh && code in DICT.en,
    "host error code exists in both dictionaries: " + code,
  );
}

const literalTranslationKeys = new Set();
for (const match of literalSource.matchAll(
  /\bt\(\s*["']([A-Za-z][A-Za-z0-9]*(?:\.[A-Za-z0-9]+)*)["']/g,
))
  literalTranslationKeys.add(match[1]);
for (const key of literalTranslationKeys) {
  ok(
    key in DICT.zh && key in DICT.en,
    "literal client translation key exists in both dictionaries: " + key,
  );
}

// 设置标题右侧与归档插件一致：项目主页和问题反馈均需使用各自对应的图标与链接。
ok(
  /className: "dssm-title-row"/.test(source),
  "settings title uses a dedicated title row for external actions",
);
ok(
  /className: "dssm-feedback-links"/.test(source),
  "settings title groups the project and feedback links together",
);
ok(
  !(await readFile(new URL("../src/plugin-ui.ts", import.meta.url), "utf8")).includes("from \"antd"),
  "设置页不再挂 Ant",
);
ok(
  /function GithubMark16\(\)/.test(source),
  "project link defines the archive plugin GitHub brand icon",
);
ok(
  /fill: "currentColor"/.test(source),
  "project link GitHub icon follows the active theme color",
);
ok(
  /icon: h\(GithubMark16\)/.test(source),
  "project link keeps the GitHub icon on an Ant Design button",
);
ok(
  /icon: h\(FeedbackIcon\)/.test(source),
  "feedback link keeps its icon on an Ant Design button",
);
ok(
  !source.includes(".dssm-feedback-link{"),
  "title links no longer use the old custom button chrome",
);
ok(
  /https:\/\/github\.com\/MichengAI\/dsh-skills-manager["']/.test(source) &&
  /window\.open|href/.test(source),
  "project link points to the Skills Manager repository",
);
ok(
  /https:\/\/github\.com\/MichengAI\/dsh-skills-manager\/issues["']/.test(source) &&
  /window\.open|href/.test(source),
  "feedback link points to the Skills Manager issue tracker",
);
ok(
  /"aria-label": t\("link\.feedback"\)/.test(source) &&
  /_blank/.test(source) && /noreferrer/.test(source),
  "feedback link opens safely with a localized accessible name",
);
ok(
  /variant: "outline", size: "sm"/.test(source) || /size: "small", shape: "default"/.test(source),
  "title links use small rectangular host buttons",
);
eq(
  DICT.zh["link.project"],
  "GitHub",
  "Chinese project link copy matches the archive plugin",
);
eq(
  DICT.en["link.project"],
  "GitHub",
  "English project link copy matches the archive plugin",
);
eq(
  DICT.zh["link.feedback"],
  "问题反馈",
  "Chinese feedback link copy is concise and actionable",
);
eq(
  DICT.en["link.feedback"],
  "Issues",
  "English feedback link copy matches the issue tracker destination",
);
ok(
  !("@deepseek-ai/dsh-client-runtime" in manifest.peerDependencies),
  "retired client-runtime is not installed as a peer",
);
ok(
  !manifest.dsh.client.inject.includes("@deepseek-ai/dsh-client-runtime"),
  "client metadata does not reference retired runtime",
);
ok(
  manifest.peerDependencies["@deepseek-ai/dsh-client-ui-primitives"] === manifest.peerDependencies["@deepseek-ai/dsh-client-ui-slots"],
  "primitives is a required host peer",
);
ok(
  manifest.dsh.client.inject.includes("@deepseek-ai/dsh-client-ui-primitives"),
  "client metadata injects primitives",
);
ok(
  /@media\(max-width:720px\)\{\.dssm-title-row\{flex-wrap:wrap\}/.test(source),
  "feedback title row wraps at the archive plugin breakpoint",
);

for (const locale of ["zh", "en"]) {
  for (const [key, value] of Object.entries(DICT[locale])) {
    ok(
      !/(?:已加载|已发现|\bLoaded\b|\bDiscovered\b)/.test(value),
      `${locale} translation avoids legacy loading terminology: ${key}`,
    );
  }
}

// ── translateError 纯函数测试（模拟宿主 translate 行为：{name} 占位符，miss 返回 key 本身）──
const translateError = bundle.translateError;
ok(typeof translateError === "function", "factory exports translateError");
const isSkillEnabled = bundle.isSkillEnabled;
ok(
  typeof isSkillEnabled === "function",
  "factory exports the shared enabled-state predicate",
);
ok(
  isSkillEnabled({
    invocationPolicyValid: true,
    modelInvocable: true,
    userInvocable: true,
  }),
  "valid model and user invocation is enabled",
);
ok(
  !isSkillEnabled({
    invocationPolicyValid: true,
    modelInvocable: true,
    userInvocable: false,
  }),
  "user-disabled skill is not enabled",
);
ok(
  !isSkillEnabled({
    invocationPolicyValid: false,
    modelInvocable: true,
    userInvocable: true,
  }),
  "invalid invocation policy is not enabled",
);
ok(
  isSkillEnabled({
    enabled: true,
    invocationPolicyValid: false,
    modelInvocable: false,
    userInvocable: false,
  }),
  "explicit manager policy is authoritative over source invocation fields",
);
const countKey = bundle.countKey;
ok(
  typeof countKey === "function",
  "factory exports locale plural-key selection",
);
eq(
  countKey("summary.shadowed", 1),
  "summary.shadowed.one",
  "singular count selects the one form",
);
eq(
  countKey("summary.shadowed", 0),
  "summary.shadowed.other",
  "zero count selects the other form",
);
eq(
  countKey("summary.shadowed", 2),
  "summary.shadowed.other",
  "plural count selects the other form",
);
for (const base of [
  "summary.total",
  "summary.enabled",
  "summary.disabled",
  "summary.shadowed",
  "summary.invalid",
  "upload.selected",
]) {
  ok(
    countKey(base, 1) in DICT.zh && countKey(base, 1) in DICT.en,
    `singular translation exists for ${base}`,
  );
  ok(
    countKey(base, 2) in DICT.zh && countKey(base, 2) in DICT.en,
    `plural translation exists for ${base}`,
  );
}
eq(
  DICT.en[countKey("summary.shadowed", 1)],
  "{count} shadowed",
  "English singular shadowed count is grammatical",
);
eq(
  DICT.en[countKey("upload.selected", 1)],
  "{count} file · {size}",
  "English singular upload count is grammatical",
);
const summarizeImportResult = bundle.summarizeImportResult;
ok(
  typeof summarizeImportResult === "function",
  "factory exports import-result summarization",
);

// ── 技能列表检索：对齐专家插件的名称/简介包含匹配与分类收窄 ──
const normalizeSkillQuery = bundle.normalizeSkillQuery;
const matchSkillQuery = bundle.matchSkillQuery;
const filterSkills = bundle.filterSkills;
const visibleSkillRoots = bundle.visibleSkillRoots;
ok(
  typeof normalizeSkillQuery === "function",
  "factory exports normalizeSkillQuery",
);
ok(typeof matchSkillQuery === "function", "factory exports matchSkillQuery");
ok(typeof filterSkills === "function", "factory exports filterSkills");
ok(
  typeof visibleSkillRoots === "function",
  "factory exports project-root presentation filtering",
);
eq(
  normalizeSkillQuery("  UI  "),
  "ui",
  "normalizeSkillQuery trims and lowercases",
);
eq(
  normalizeSkillQuery("   "),
  "",
  "normalizeSkillQuery treats whitespace-only as empty",
);
const sampleSkills = [
  {
    name: "travel-plan-viz",
    description: "把旅行行程做成网页",
    kind: "bundle",
    kindLabel: "目录插件",
    statusLabel: "已启用",
    rootKey: "dsh",
    rootLabel: "DSH skills",
  },
  {
    name: "photo-revival",
    description: "Turn photos into illustrations",
    kind: "single",
    kindLabel: "单文件",
    statusLabel: "已停用",
    rootKey: "agents",
    rootLabel: "Shared Agent skills",
  },
];
ok(matchSkillQuery(sampleSkills[0], ""), "empty query matches every skill");
ok(
  matchSkillQuery(sampleSkills[0], "  "),
  "whitespace-only query matches every skill",
);
ok(
  matchSkillQuery(sampleSkills[0], "行程"),
  "matchSkillQuery hits Chinese description",
);
ok(
  matchSkillQuery(sampleSkills[1], "Photo"),
  "matchSkillQuery is case-insensitive on name",
);
ok(
  matchSkillQuery(sampleSkills[0], "目录插件"),
  "matchSkillQuery hits localized kind label",
);
ok(
  matchSkillQuery(sampleSkills[1], "shared"),
  "matchSkillQuery hits root label",
);
ok(
  !matchSkillQuery(sampleSkills[0], "photo"),
  "unrelated query does not match",
);
eq(
  filterSkills(sampleSkills, { query: "   " }).length,
  2,
  "blank query keeps the full list",
);
eq(
  filterSkills(sampleSkills, { query: "illustration" })
    .map(function (item) {
      return item.name;
    })
    .join(","),
  "photo-revival",
  "filterSkills matches English description",
);
eq(
  filterSkills(sampleSkills, { rootKey: "dsh" })
    .map(function (item) {
      return item.name;
    })
    .join(","),
  "travel-plan-viz",
  "filterSkills narrows by root category",
);
eq(
  filterSkills(sampleSkills, { rootKey: "dsh", query: "photo" }).length,
  0,
  "category and query are combined",
);
eq(
  filterSkills(sampleSkills, { query: "SINGLE" })
    .map(function (item) {
      return item.name;
    })
    .join(","),
  "photo-revival",
  "filterSkills matches kind",
);
eq(
  visibleSkillRoots([
    { key: "project-empty", scope: "project", exists: false, skills: [] },
    { key: "project-used", scope: "project", skills: [{ name: "demo" }] },
    { key: "codex-absent", scope: "user", exists: false, skills: [] },
    { key: "codex", scope: "user", exists: true, skills: [] },
  ])
    .map(function (root) {
      return root.key;
    })
    .join(","),
  "project-used,codex",
  "main list hides absent read-only roots",
);

eq(
  bundle.scopeSkillRoots([
    { key: "dsh", scope: "user", mutable: true, exists: true, skills: [] },
    { key: "agents", scope: "user", mutable: false, exists: true, skills: [] },
    { key: "codex", scope: "user", mutable: false, exists: true, skills: [{ name: "foo" }] },
    { key: "project-dsh", scope: "project", mutable: true, exists: true, skills: [] },
  ])
    .map(function (root) {
      return root.key;
    })
    .join(","),
  "dsh,codex",
  "scopeSkillRoots retains mutable roots and non-empty read-only roots while excluding empty ones and project scope",
);

const parseApiResponse = bundle.parseApiResponse;
ok(
  typeof parseApiResponse === "function",
  "factory exports API response parsing for regression tests",
);
await parseApiResponse({
  status: 502,
  json: function () {
    return Promise.reject(new SyntaxError("Unexpected token <"));
  },
}).then(
  function () {
    ok(false, "non-JSON API response rejects");
  },
  function (error) {
    eq(
      error.code,
      "error.proto.nonJson",
      "non-JSON API error carries a translatable code",
    );
    eq(
      translateError(mockT, error),
      "Server returned a non-JSON response (HTTP 502)",
      "non-JSON API error uses the locale dictionary",
    );
  },
);
const trapModalFocus = bundle.trapModalFocus;
const recoverModalFocus = bundle.recoverModalFocus;
ok(typeof recoverModalFocus === "function", "异步提交后支持恢复丢失的弹窗焦点");
if (typeof recoverModalFocus === "function") {
  let recovered = 0;
  const body = {};
  const input = {};
  const modal = { focus() { recovered++; } };
  recoverModalFocus(modal, body, body);
  eq(recovered, 1, "按钮被禁用后焦点落到页面，应回到弹窗");
  recoverModalFocus(modal, input, body);
  eq(recovered, 1, "输入框仍持有焦点时不抢夺焦点");
  recoverModalFocus(null, body, body);
  eq(recovered, 1, "弹窗卸载后不再恢复焦点");
}
ok(
  typeof trapModalFocus === "function",
  "factory exports modal focus trapping for regression tests",
);
const inspectUploadSelection = bundle.inspectUploadSelection;
ok(
  typeof inspectUploadSelection === "function",
  "factory exports upload selection validation",
);
eq(
  inspectUploadSelection([{ name: "README.md", size: 1 }]).error.code,
  "select.file.invalid",
  "file picker rejects files other than ZIP or SKILL.md",
);
eq(
  inspectUploadSelection([{ name: "SKILL.md", size: 10 }]).kind,
  "skill",
  "single SKILL.md is accepted without an absolute path",
);
eq(
  inspectUploadSelection([{ name: "demo.zip", size: 10 }]).kind,
  "zip",
  "ZIP archive is accepted",
);
eq(
  inspectUploadSelection([
    { name: "SKILL.md", webkitRelativePath: "demo/SKILL.md", size: 10 },
    { name: "run.js", webkitRelativePath: "demo/scripts/run.js", size: 10 },
  ]).kind,
  "folder",
  "native folder selection is accepted as one upload",
);
eq(
  inspectUploadSelection([{ name: "fnos.zip", size: 11 << 20 }]).kind,
  "zip",
  "ZIP archives above the former 10 MiB limit are accepted",
);
eq(
  inspectUploadSelection([{ name: "SKILL.md", size: (32 << 20) + 1 }]).error
    .code,
  "error.upload.tooLarge",
  "single SKILL.md is rejected before exceeding the per-entry limit",
);
eq(
  inspectUploadSelection([{ name: "demo.zip", size: (32 << 20) + 1 }]).error
    .code,
  "error.upload.archiveTooLarge",
  "ZIP archives are rejected before exceeding the archive limit",
);
eq(
  inspectUploadSelection([
    { name: "SKILL.md", webkitRelativePath: "demo/SKILL.md", size: 10 },
    {
      name: "asset.bin",
      webkitRelativePath: "demo/asset.bin",
      size: (32 << 20) + 1,
    },
  ]).error.code,
  "error.upload.tooLarge",
  "folder selection rejects an oversized entry before reading file contents",
);
eq(
  inspectUploadSelection(
    [
      { name: "SKILL.md", webkitRelativePath: "demo/SKILL.md", size: 10 },
    ].concat(
      Array.from({ length: 3 }, (_, index) => ({
        name: `asset-${index}.bin`,
        webkitRelativePath: `demo/asset-${index}.bin`,
        size: 24 * (1 << 20),
      })),
    ),
  ).error.params.limit,
  64 << 20,
  "folder selection rejects decoded totals above 64 MiB",
);
eq(
  inspectUploadSelection(
    [
      { name: "SKILL.md", webkitRelativePath: "demo/SKILL.md", size: 10 },
    ].concat(
      Array.from({ length: 1000 }, (_, index) => ({
        name: `asset-${index}.txt`,
        webkitRelativePath: `demo/asset-${index}.txt`,
        size: 1,
      })),
    ),
  ).error.code,
  "error.upload.tooMany",
  "folder selection rejects more than 1000 entries",
);
let focused = "";
const firstButton = {
  focus: function () {
    focused = "first";
  },
};
const lastButton = {
  focus: function () {
    focused = "last";
  },
};
const fakeModal = {
  querySelectorAll: function () {
    return [firstButton, lastButton];
  },
  contains: function (node) {
    return node === fakeModal || node === firstButton || node === lastButton;
  },
};
const previousDocument = globalThis.document;
globalThis.document = { activeElement: lastButton };
let focusPrevented = false;
trapModalFocus(fakeModal, {
  key: "Tab",
  shiftKey: false,
  preventDefault: function () {
    focusPrevented = true;
  },
});
globalThis.document = previousDocument;
ok(
  focusPrevented && focused === "first",
  "modal focus trap wraps Tab from the last element",
);
focused = "";
focusPrevented = false;
globalThis.document = { activeElement: fakeModal };
trapModalFocus(fakeModal, {
  key: "Tab",
  shiftKey: true,
  preventDefault: function () {
    focusPrevented = true;
  },
});
globalThis.document = previousDocument;
ok(
  focusPrevented && focused === "last",
  "Shift+Tab from the dialog panel wraps to the last control",
);

function mockT(key, params) {
  const template = DICT.en[key] || key;
  if (!params) return template;
  return template.replace(/\{(\w+)\}/g, (m, name) =>
    name in params ? String(params[name]) : m,
  );
}

const rootDisplayName = bundle.rootDisplayName;
ok(
  typeof rootDisplayName === "function",
  "factory exports project-aware source labels",
);
eq(
  rootDisplayName(mockT, {
    key: "project-agents:abc",
    kind: "project-agents",
    localeKey: "projectAgents",
    label: "Project Agent",
    projectName: "demo",
  }),
  "Project Agent · demo",
  "project source labels include the workspace name without translating the dynamic key",
);
eq(
  rootDisplayName(mockT, { key: "codex", label: "Codex" }),
  "Codex",
  "fixed user source labels remain unchanged",
);
eq(DICT.zh["root.projectDsh"], DICT.zh["root.dsh"], "项目 DSH 与全局同名");
eq(DICT.en["root.projectDsh"], DICT.en["root.dsh"], "project DSH uses the same label as global DSH");
ok(
  DICT.zh["root.projectAgents"] && DICT.en["root.projectAgents"] && DICT.zh["root.copilot"] && DICT.en["root.copilot"] &&
    DICT.zh["root.windsurf"] && DICT.en["root.windsurfUser"] && DICT.zh["root.traeCn"] && DICT.en["root.openclaw"] &&
    DICT.zh["root.clawdbot"] && DICT.en["root.roo"] && DICT.zh["root.codebuddy"] && DICT.en["root.codebuddy"] &&
    DICT.zh["root.workbuddy"] && DICT.en["root.workbuddy"] &&
    DICT.zh["root.qoder"] && DICT.en["root.qoderCn"] && DICT.zh["root.lingma"] && DICT.en["root.lingma"],
  "project DSH, Agent, Copilot, and first-tier Agent sources are localized in both languages",
);
ok(
  DICT.zh["scope.user"] && DICT.en["scope.project"] && DICT.zh["import.global"] && DICT.en["filter.status"],
  "scope tabs, global import, and status filter are localized in both languages",
);
eq(
  DICT.zh["status.enabled"],
  "已启用",
  "Chinese status describes invocation policy without claiming body loading",
);
eq(
  DICT.en["status.enabled"],
  "Enabled",
  "English status describes invocation policy without claiming body loading",
);
ok(
  DICT.zh["summary.enabled.one"] && DICT.en["summary.enabled.other"] &&
    DICT.zh["summary.shadowed.one"] && DICT.en["summary.invalid.other"],
  "enabled, shadowed, and invalid summary terminology is localized in both languages",
);
eq(
  mockT("status.shadowedBy", { source: rootDisplayName(mockT, { key: "dsh", label: "DSH skills" }) }),
  "Overridden by the same skill in DSH skills",
  "shadow hints use the localized source display name",
);
ok(typeof bundle.currentSessionId === "function", "factory exports currentSessionId");
eq(bundle.currentSessionId({ current: "legacy-session" }), undefined, "currentSessionId ignores the pre-0.2 current field");
eq(
  bundle.currentSessionId({
    ids: ["other", "main"],
    byId: {
      other: { retainedBy: { sidebar: 1 } },
      main: { retainedBy: { mainView: 1 } },
    },
  }),
  "main",
  "currentSessionId follows retainedBy.mainView",
);
eq(
  bundle.currentSessionId({
    current: "legacy-session",
    byId: { main: { retainedBy: { mainView: 1 } } },
  }),
  "main",
  "currentSessionId ignores a legacy current field when mainView is present",
);
eq(bundle.currentSessionId({ byId: { other: { retainedBy: { sidebar: 1 } } } }), undefined, "currentSessionId ignores non-main retains");
eq(bundle.currentSessionId({}), undefined, "currentSessionId is absent without a current session");
ok(bundle.canToggleSource({ key: "copilot", toggleable: true }), "user Agent sources keep a source toggle");
ok(bundle.canToggleSource({ key: "project-copilot:abc", kind: "project-copilot", toggleable: true }), "read-only project Agent sources expose a source toggle");
ok(bundle.canToggleSource({ key: "dsh", toggleable: true }), "user DSH exposes a source-wide toggle");
ok(!bundle.canToggleSource({ key: "project-dsh:abc", kind: "project-dsh", toggleable: true }), "project DSH has no source-wide toggle");
eq(
  JSON.stringify(bundle.countSkillStatuses([
    { skill: { enabled: true, loadable: true } },
    { skill: { enabled: true, loadable: true } },
    { skill: { enabled: false, loadable: true } },
    { skill: { enabled: true, loadable: true, shadowedBy: { root: "dsh" } } },
    { skill: { enabled: false, loadable: false } },
  ])),
  JSON.stringify({ total: 5, enabled: 2, disabled: 1, shadowed: 1, invalid: 1 }),
  "summary counts match status-filter buckets",
);
ok(
  DICT.zh["dest.scope.workspace"] && DICT.en["dest.scope.workspace"] && DICT.zh["workspace.noSkills"] && DICT.en["workspace.noSkills"] && DICT.en["trash.source"],
  "workspace destination, project page and Trash source labels are localized in both languages",
);

eq(
  summarizeImportResult(mockT, { imported: [{ name: "alpha" }], skipped: [] })
    .text,
  "Import complete: alpha",
  "successful import names the imported skill",
);
eq(
  summarizeImportResult(mockT, { imported: [], skipped: [{ name: "alpha" }] })
    .text,
  "No skills were imported; existing skills were skipped: alpha",
  "all-skipped import is never reported as completed",
);
ok(
  summarizeImportResult(mockT, { imported: [], skipped: [{ name: "alpha" }] })
    .ok === false,
  "all-skipped import is rendered as a warning/error state",
);
eq(
  summarizeImportResult(mockT, {
    imported: [{ name: "alpha" }],
    skipped: [{ name: "beta" }],
  }).text,
  "Imported: alpha; skipped existing skills: beta",
  "partial import reports both imported and skipped names",
);
const importWarning = summarizeImportResult(mockT, {
  imported: [
    {
      name: "alpha",
      warnings: [
        {
          code: "warning.backupUncleaned",
          params: { path: "C:\\bak", error: "EPERM" },
        },
      ],
    },
  ],
  skipped: [],
});
ok(
  importWarning.warning === true,
  "import cleanup warnings use the warning presentation state",
);
eq(
  importWarning.text,
  "Import complete: alpha; warnings: Old version backup was not cleaned up: C:\\bak (EPERM)",
  "import cleanup warnings remain visible in the result summary",
);

eq(
  translateError(mockT, {
    code: "error.skill.notFound",
    params: { name: "foo" },
    error: "技能不存在: foo",
  }),
  "Skill not found: foo",
  "translateError translates a known error code with params",
);
eq(
  translateError(mockT, { code: "error.unknown", error: "原文错误" }),
  "原文错误",
  "unknown code keeps the server sentence when one is present",
);
eq(
  translateError(mockT, { code: "ENOENT", error: "ENOENT: no such file or directory, open C:/tmp" }),
  "ENOENT: no such file or directory, open C:/tmp",
  "node errno keeps the full message instead of the bare code",
);
eq(
  translateError(mockT, { code: "ENOENT" }),
  "ENOENT",
  "bare code is kept only when there is no sentence",
);
eq(
  translateError(mockT, {
    code: "error.root.readonly",
    params: { action: "toggle" },
    error: "公共 Agent 技能目录不允许启用或停用",
  }),
  "This source does not allow enabling or disabling",
  "translateError maps the action param through the action.* dictionary",
);
eq(
  translateError(mockT, new Error("boom")),
  "boom",
  "translateError handles Error objects",
);
eq(
  translateError(mockT, "plain"),
  "plain",
  "translateError passes through plain strings",
);
eq(
  translateError(() => null, {
    code: "error.skill.notFound",
    params: {},
    error: "原文",
  }),
  "原文",
  "translateError falls back when the host t returns null (not a string)",
);
eq(
  translateError(() => undefined, {
    code: "error.skill.notFound",
    params: {},
    error: "原文",
  }),
  "原文",
  "translateError falls back when the host t returns undefined",
);
eq(
  translateError(mockT, {
    code: "error.proto.forbiddenHost",
    error: "forbidden host",
  }),
  "Forbidden request origin (invalid host)",
  "translateError maps illegal Host to forbiddenHost",
);
eq(
  translateError(mockT, {
    code: "error.import.rollbackFailed",
    params: { path: "C:\\bak", error: "EPERM" },
    error: "覆盖导入回滚失败",
  }),
  "Overwrite import rollback failed; backups kept at: C:\\bak (EPERM)",
  "translateError translates rollback failure with params",
);
eq(
  translateError(mockT, {
    code: "error.trash.rollbackFailed",
    params: { path: "C:\\stage", error: "EPERM" },
    error: "移入回收站回滚失败",
  }),
  "Move-to-trash rollback failed; unrecovered content was kept at: C:\\stage (EPERM)",
  "translateError translates move-to-trash rollback preservation",
);
eq(
  translateError(mockT, {
    code: "error.trash.projectUnavailable",
    params: { path: "C:\\project" },
    error: "原项目不活动",
  }),
  "The original project is not an active workspace, so this skill cannot be restored: C:\\project",
  "translateError explains that project restore requires an active workspace",
);
eq(
  translateError(mockT, {
    code: "error.root.unsafe",
    params: { path: "C:\\project\\.dsh\\skills" },
    error: "不安全目录",
  }),
  "The project skill directory is unsafe, so the write was refused: C:\\project\\.dsh\\skills",
  "translateError explains linked project-root write rejection",
);
eq(
  translateError(mockT, {
    code: "error.state.invalid",
    params: { path: "C:\\state.json" },
    error: "状态不可读",
  }),
  "The manager state file could not be read, so overwriting it was refused: C:\\state.json",
  "translateError translates invalid-state write refusal",
);
eq(
  translateError(mockT, {
    code: "warning.backupUncleaned",
    params: { path: "C:\\bak", error: "EPERM" },
    error: "旧版本备份未清理",
  }),
  "Old version backup was not cleaned up: C:\\bak (EPERM)",
  "translateError translates backup cleanup warning",
);

// ── 注册契约断言：inject 声明 locale，settings.section 注册携带 locale 命名空间 ──
ok(
  Array.isArray(bundle.inject) && bundle.inject.includes("locale"),
  "bundle.inject declares the locale service",
);
ok(
  Array.isArray(bundle.inject) && bundle.inject.includes("slots"),
  "bundle.inject declares slots",
);
ok(
  !bundle.inject.includes("workspaces"),
  "bundle no longer invokes the Node-hosted workspace directory picker",
);
ok(
  source.includes('type: "file"') && source.includes('accept: ".zip,.md"'),
  "import dialog accepts ZIP and SKILL.md in the native picker",
);
ok(
  source.includes("webkitdirectory"),
  "import dialog exposes a native folder picker",
);
ok(
  source.includes("pickerOpenRef.current"),
  "native picker has a synchronous multi-click guard",
);
ok(
  source.includes('post("/upload"'),
  "selected content is uploaded instead of sending an absolute path",
);
ok(
  source.includes('result && modal !== "import"'),
  "upload feedback is not left behind the active import modal",
);
ok(
  source.includes('role: "alert" }, result.text'),
  "import modal renders upload feedback where it remains visible",
);
ok(
  /setResult\(null\);\s*setUpload\(null\);\s*setImportDestination\(defaultDestination\(\)\);\s*setModal\("import"\)/.test(source),
  "opening import clears stale upload feedback and selection",
);
ok(
  /filterActionButton\(t\("btn\.refresh"\),\s*strokeIcon\(.*refresh\(false\);/.test(source),
  "settings exposes an explicit refresh action for project file changes",
);
ok(
  source.includes("createDestination") && source.includes("allowAgents: true") && !source.includes("value: form.root"),
  "create and import dialogs use the shared destination picker including Shared Agent",
);
ok(
  source.includes('t("trash.source", { source: trashRootLabel(item) })'),
  "Trash identifies the original user or project source before restore",
);
ok(
  !source.includes("!createRoot") && source.includes("openCreate"),
  "creation does not depend on the current project or on a single global root",
);
ok(
  source.includes("canToggleSource(root)") &&
    source.includes('root.kind !== "project-dsh"'),
  "source-level toggles are available for Agent sources on both tabs, except DSH roots",
);
ok(
  !source.includes('"status.discovered"'),
  "project rows no longer use the ambiguous Discovered status",
);
ok(
  !source.includes('"summary.loaded"'),
  "summary no longer claims that enabled Skill bodies are loaded",
);
ok(
  !source.includes("dssm-loaded"),
  "internal status styling also uses enabled terminology",
);
ok(
  /h\(SourceSelect,\s*\{\s*value:\s*activeSource,\s*label:\s*t\("filter.source"\),\s*options(?:\s*:\s*options)?/.test(
    source,
  ),
  "source selector uses the validated source key",
);
ok(
  !source.includes('setModal("browse")'),
  "native selection never chains into a second directory browser",
);
ok(
  !source.includes('callApi("/browse"'),
  "client no longer uses the in-app absolute-path browser",
);
ok(
  !source.includes("btn.repair.enable") && !source.includes("repairable"),
  "toggle UI never offers a source-rewriting repair action",
);
ok(
  source.includes("(data.warnings || []).map"),
  "state-level warnings are rendered in the settings page",
);
ok(
  source.includes("dssm-warning"),
  "warning feedback has a distinct visual state",
);
ok(
  source.includes("@container(max-width:520px)") && source.includes(".dssm-skill-row{flex-wrap:wrap}"),
  "skill rows respond to the settings content width rather than only the viewport",
);
ok(
  source.includes(".dssm-source-actions{display:flex"),
  "source toggles stay in the collapsible source header",
);
ok(
  source.includes("SegmentedTabs") && source.includes("dssm-scope-tabs"),
  "范围页签使用宿主分段页签并铺满",
);

let registerOptions = null;
const fakeCtx = {
  effect(fn) {
    return fn();
  },
  locale: {
    register() {
      return () => {};
    },
    bind() {
      return () => "title";
    },
  },
  slots: {
    inject(name, fn) {
      if (name === "settings.section") registerOptions = fn();
    },
    register(opts) {
      return opts;
    },
  },
};
bundle.apply(fakeCtx);
ok(
  registerOptions !== null && registerOptions.name === "settings.section",
  "apply registers the settings.section entry",
);
ok(
  registerOptions !== null && registerOptions.locale === "skills-manager",
  "settings.section registration declares the locale namespace",
);
ok(
  registerOptions !== null && typeof registerOptions.label === "function",
  "settings.section label is a thunk (re-read per locale revision)",
);
ok(
  registerOptions !== null && registerOptions.icon === "skill",
  "settings.section registers the skill nav icon",
);

// 界面语言覆盖系统默认区域；多条警告使用对应语言的分隔符。
for (const lang of ["zh", "en"]) {
  const translator = (key, params = {}) => (DICT[lang][key] || key).replace(/\{(\w+)\}/g, (_, name) => String(params[name] ?? ""));
  const date = "2026-09-12T13:04:05Z";
  eq(bundle.formatTrashTime?.(translator, date), new Date(date).toLocaleString(lang === "zh" ? "zh-CN" : "en-US"), `${lang} trash time follows UI language`);
  const result = summarizeImportResult(translator, { imported: [{ name: "alpha", warnings: ["first", "second"] }] });
  ok(result.text.includes(lang === "zh" ? "first；second" : "first; second"), `${lang} warning separator follows UI language`);
}

// en-GB 字典回退到 en-US 词典，但日期必须保留有效宿主区域。
let hostActive = "en-GB";
bundle.apply({ ...fakeCtx, effect() {}, locale: { ...fakeCtx.locale, getLocale() { return { active: hostActive, revision: 1, locales: [] }; } } });
const britishT = key => DICT.en[key] || key;
const britishDate = "2026-09-12T13:04:05Z";
eq(bundle.formatTrashTime(britishT, britishDate), new Date(britishDate).toLocaleString("en-GB"), "en-GB 日期不被 en-US 字典回退覆盖");
hostActive = "zh";
eq(bundle.formatTrashTime(britishT, britishDate), new Date(britishDate).toLocaleString("zh"), "宿主有效 locale 优先于词典格式区域，语言切换实时读取");
console.log(`\n${passed} passed, ${failed} failed`);
if (failed > 0) process.exit(1);
