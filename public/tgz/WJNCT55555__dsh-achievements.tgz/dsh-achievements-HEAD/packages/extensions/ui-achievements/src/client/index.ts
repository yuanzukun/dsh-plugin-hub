/**
 * Achievements browser surface: the settings-section gallery, the trophy
 * footer action, the composer dock readout, and the trophy-toggled gallery
 * overlay plus unlock toast stack. The apply world polls the achievements
 * Remote (`recent` + `dock`) on a timer and feeds one shared store; components
 * read through the bound selector hook and write through the store actions.
 */

import type { Context } from '@deepseek-ai/cordis'
import achievementsRemote from '@wjnct55555/dsh-achievements/remote'
// Type-only: pulls the ctx.remote merge (the achievements Remote namespace).
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type {} from '@wjnct55555/dsh-achievements/remote'
// Type-only: pulls the settings shell SlotMap merge ('settings.section').
import type {} from '@deepseek-ai/dsh-client-ui-settings/client'
// Type-only: pulls the layout shell SlotMap merge ('shell.overlay').
import type {} from '@deepseek-ai/dsh-client-ui-layout/client'
// Type-only: pulls the sidebar footer-action owner share ('sidebar.footer.action').
import type {} from '@deepseek-ai/dsh-client-ui-sidebar/client'
// Type-only: pulls the conversation dock owner share ('conversation.composer.dock').
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
// Type-only: pulls the locale plugin's Context merge (ctx.locale).
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type { AchievementsHeatmap, AchievementsRates, AchievementsSnapshot, AchievementsTelemetry } from '@wjnct55555/dsh-achievements/types'
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol'
import { bindSnapshotSelector } from './bind.ts'
import { AchievementsSection, type AchievementsSectionInjected } from './AchievementsSection.tsx'
import { DockReadout, type DockInjected } from './dock.tsx'
import { GalleryOverlay } from './gallery.tsx'
import { ToastStack, type ToastStackInjected } from './toast.tsx'
import { Trophy, type TrophyInjected } from './trophy.tsx'
import { AchievementsStore } from './store.ts'
import { en, zh, type AchievementsKey } from './locales.ts'

export type { AchievementsSectionInjected } from './AchievementsSection.tsx'
export type { AchievementsKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** The achievements gallery copy. */
    achievements: AchievementsKey
  }
}

/** Dictionary namespace owned by this plugin. */
const NS = 'achievements'

/** DSH 0.2 no longer ships a separate client runtime package; the root Context carries the client service merges. */
type ClientContext = Context

/** Poll cadence for the recent-unlock queue and dock readout. */
const POLL_MS = 3000

/** Required services: slots, remote, and copy (timer is optional). */
export const inject = ['slots', 'locale', 'remote']

/**
 * Client plugin body: register the copy and the four surfaces, and start the
 * Remote poll that feeds the shared store.
 * @param ctx - client root context.
 * @returns Cleanup for the mounted achievements remote contribution.
 */
export async function apply(ctx: ClientContext): Promise<() => Promise<void>> {
  const disposeRemote = await ctx.remote.$mount(achievementsRemote)
  try {
    const surfaces = await ctx.plugin({
      name: 'ui-achievements: surfaces',
      inject: ['remote.achievements'],
      apply: mountUi,
    })
    return async () => {
      await surfaces.dispose()
      await disposeRemote()
    }
  } catch (error) {
    await disposeRemote()
    throw error
  }
}

/** Register the achievements UI surfaces after its remote namespace is ready. */
function mountUi(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'ui-achievements: dictionaries')

  const store = new AchievementsStore()
  const useSnapshot = bindSnapshotSelector(store.store)
  const t = ctx.locale.bind(NS)
  const list = (): Promise<RemoteResult<AchievementsSnapshot>> => ctx.remote.achievements.list()
  // The deep-insights / telemetry / clear Remote methods may be absent on hosts
  // that predate them; keep the plugin applyable so the gallery still opens there.
  const deepRemote = (ctx.remote.achievements as unknown as {
    deepState?: () => Promise<RemoteResult<{ enabled: boolean }>>
    setDeepInsights?: (enabled: boolean) => Promise<RemoteResult<{ enabled: boolean }>>
    rates?: () => Promise<RemoteResult<AchievementsRates | null>>
    telemetryState?: () => Promise<RemoteResult<AchievementsTelemetry>>
    setTelemetry?: (enabled: boolean) => Promise<RemoteResult<AchievementsTelemetry>>
    clear?: () => Promise<RemoteResult<AchievementsSnapshot>>
    heatmap?: () => Promise<RemoteResult<AchievementsHeatmap>>
  })
  const deepState = deepRemote.deepState
  const setDeepInsights = deepRemote.setDeepInsights
  const rates = deepRemote.rates
  const telemetryState = deepRemote.telemetryState
  const setTelemetry = deepRemote.setTelemetry
  const clear = deepRemote.clear
  const heatmap = deepRemote.heatmap

  const poll = async (): Promise<void> => {
    const recent = await ctx.remote.achievements.recent()
    const dock = await ctx.remote.achievements.dock()
    if (recent.ok && dock.ok) {
      store.ingest(dock.value, recent.value.unlocks)
    }
    store.prune()
  }
  // The timer drives the poll; every surface re-renders from the store.
  const timer = ctx.get('timer') as { interval: (cb: () => void, ms: number) => () => void } | undefined
  if (timer !== undefined) {
    ctx.effect(() => timer.interval(() => { void poll() }, POLL_MS), 'ui-achievements: remote poll')
  }
  void poll()

  const injected = (): AchievementsSectionInjected => ({
    list,
    ...deepState !== undefined ? { deepState } : {},
    ...setDeepInsights !== undefined ? { setDeepInsights } : {},
    ...rates !== undefined ? { rates } : {},
    ...telemetryState !== undefined ? { telemetryState } : {},
    ...setTelemetry !== undefined ? { setTelemetry } : {},
    ...clear !== undefined ? { clear } : {},
    ...heatmap !== undefined ? { heatmap } : {},
  })

  ctx.slots.inject('settings.section', () => ctx.slots.register({
    name: 'settings.section',
    id: 'achievements',
    order: 30,
    label: () => t('nav'),
    locale: NS,
    inject: injected,
  }, AchievementsSection))

  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'achievements-toast',
    order: 100,
    locale: NS,
    inject: (): ToastStackInjected => ({ useSnapshot, dismiss: (clientAt) => { store.dismiss(clientAt) } }),
  }, ToastStack))

  ctx.slots.inject('shell.overlay', () => ctx.slots.register({
    name: 'shell.overlay',
    id: 'achievements-gallery',
    order: 101,
    locale: NS,
    inject: () => ({
      useSnapshot,
      close: () => { store.closeGallery() },
      list,
      ...deepState !== undefined ? { deepState } : {},
      ...setDeepInsights !== undefined ? { setDeepInsights } : {},
      ...rates !== undefined ? { rates } : {},
      ...telemetryState !== undefined ? { telemetryState } : {},
      ...setTelemetry !== undefined ? { setTelemetry } : {},
      ...clear !== undefined ? { clear } : {},
      ...heatmap !== undefined ? { heatmap } : {},
    }),
  }, GalleryOverlay))

  ctx.slots.inject('sidebar.footer.action', () => ctx.slots.register({
    name: 'sidebar.footer.action',
    id: 'achievements-trophy',
    order: 5,
    locale: NS,
    inject: (): TrophyInjected => ({ useSnapshot, toggle: () => { store.toggleGallery() } }),
  }, Trophy))

  ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register({
    name: 'conversation.composer.dock',
    id: 'achievements',
    order: 1,
    locale: NS,
    inject: (): DockInjected => ({ useSnapshot }),
  }, DockReadout))
}
