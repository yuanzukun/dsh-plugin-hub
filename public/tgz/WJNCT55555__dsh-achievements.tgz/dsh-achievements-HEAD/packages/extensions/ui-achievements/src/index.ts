/** Host loader entry for the browser-only achievements surface plugin. */

/** Provides no host-side behavior. */
export function apply(): void {}
