/**
 * Bind a bare snapshot source to a selector hook using React's built-in
 * external-store subscription. The client package is CSR-only, so the server
 * snapshot argument is intentionally omitted.
 */
import { useSyncExternalStore } from 'react'
import type { HostObservable, SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots'

/**
 * Create a selector hook for a snapshot source.
 * @param source - Observable source owned by the achievements store.
 * @returns A hook that selects the requested value from the current snapshot.
 */
export function bindSnapshotSelector<T>(source: HostObservable<T>): SnapshotSelectorHook<T> {
  const subscribe = (listener: () => void) => source.subscribe(listener)
  const getSnapshot = () => source.getSnapshot()
  return function useSelector<S>(selector: (snapshot: T) => S): S {
    return selector(useSyncExternalStore(subscribe, getSnapshot))
  }
}
