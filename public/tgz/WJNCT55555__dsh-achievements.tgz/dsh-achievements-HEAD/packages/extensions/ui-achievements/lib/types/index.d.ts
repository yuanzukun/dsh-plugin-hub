/** Host loader entry for the browser-only achievements surface plugin. */
/** Provides no host-side behavior. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map