import type { HostObservable, SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
/**
 * Create a selector hook for a snapshot source.
 * @param source - Observable source owned by the achievements store.
 * @returns A hook that selects the requested value from the current snapshot.
 */
export declare function bindSnapshotSelector<T>(source: HostObservable<T>): SnapshotSelectorHook<T>;
//# sourceMappingURL=bind.d.ts.map