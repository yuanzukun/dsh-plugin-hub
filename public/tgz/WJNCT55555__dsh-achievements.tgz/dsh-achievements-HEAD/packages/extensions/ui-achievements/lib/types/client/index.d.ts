/**
 * Achievements browser surface: the settings-section gallery, the trophy
 * footer action, the composer dock readout, and the trophy-toggled gallery
 * overlay plus unlock toast stack. The apply world polls the achievements
 * Remote (`recent` + `dock`) on a timer and feeds one shared store; components
 * read through the bound selector hook and write through the store actions.
 */
import type { Context } from '@deepseek-ai/cordis';
import { type AchievementsKey } from './locales.ts';
export type { AchievementsSectionInjected } from './AchievementsSection.tsx';
export type { AchievementsKey } from './locales.ts';
type ClientContext = Context;
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The achievements gallery copy. */
        achievements: AchievementsKey;
    }
}
/** Required services: slots, remote, and copy (timer is optional). */
export declare const inject: string[];
/**
 * Client plugin body: register the copy and the four surfaces, and start the
 * Remote poll that feeds the shared store.
 * @param ctx - client root context.
 * @returns Cleanup for the mounted achievements remote contribution.
 */
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
//# sourceMappingURL=index.d.ts.map