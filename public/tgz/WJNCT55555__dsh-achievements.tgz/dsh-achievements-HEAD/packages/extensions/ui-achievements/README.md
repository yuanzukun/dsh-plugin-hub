# Achievements 成就系统（浏览器面）

设置页画廊、解锁 toast、侧栏奖杯、输入区进度读条和奖杯弹出的全屏画廊：按分类分组，稀有度差异化底色（普通灰/稀有蓝/史诗紫/传说金），Twemoji 图标（CDN SVG + emoji 兜底），进度条，隐藏成就解锁前显示 `???`。数据通过 achievements Remote 命名空间获取。

## Model Experience

### Request context and condition

#### What the model sees

无。本包是纯浏览器展示，不注册模型可见工具、不注入 system-prompt 内容；模型可见的 `list_achievements` 工具由 `@deepseek-ai/dsh-achievements`（Host 包）注册。

#### Token effect

零直接 token 效果。

#### KV Cache effect

Independent behavior：纯展示包，不参与请求组装。

## Known Limitations and Deferred Work

- 浏览器面只读取 Host achievements Remote；所有计数、解锁和持久化以 Host 端为唯一事实来源。
- 依赖 DSH 0.2 的 `@deepseek-ai/dsh-client-store` 与四个 Web 槽位；0.1.x 不兼容。
