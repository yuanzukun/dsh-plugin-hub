/**
 * Assemble the installable root client bundle from the UI package's built
 * client half. The shipped bundle is the package's client face, so its module
 * id must be the bundle package name, and it must request the 0.2 client store
 * from the shell's platform table rather than the retired runtime package.
 */
import { copyFile, mkdir, readFile, writeFile } from 'node:fs/promises'
import { dirname, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..')
const source = resolve(root, 'packages/extensions/ui-achievements/lib/client.js')
const target = resolve(root, 'lib/client.js')

let code = await readFile(source, 'utf8')
code = code.replace(
  /id:\s*["']@wjnct55555\/dsh-client-ui-achievements["']/,
  'id: "@wjnct55555/dsh-achievements-bundle"',
)
code = code.replaceAll('@deepseek-ai/dsh-client-runtime/client', '@deepseek-ai/dsh-client-store')

if (!code.includes('id: "@wjnct55555/dsh-achievements-bundle"')) {
  throw new Error('assemble-client: client bundle id was not rewritten')
}
if (code.includes('@deepseek-ai/dsh-client-runtime')) {
  throw new Error('assemble-client: retired dsh-client-runtime import remains')
}

await mkdir(dirname(target), { recursive: true })
await writeFile(target, code)

try {
  await copyFile(`${source}.map`, `${target}.map`)
} catch {
  // The source map is optional; a missing map must not fail packaging.
}

console.log(`assemble-client: wrote ${target}`)
