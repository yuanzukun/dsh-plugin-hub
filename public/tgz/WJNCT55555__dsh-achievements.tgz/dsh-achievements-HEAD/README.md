# dsh-achievements · DeepSeek Harness 成就系统

为 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（DSH）编写的**进程级（全局）成就系统**插件。观察 agent / session 事件，把工具调用、文件操作、子代理、workflow、goal、preset 切换等行为折叠成成就进度，解锁时弹出 toast 并写入一次性队列，供浏览器画廊、侧栏奖杯与输入坞读条展示。

## 组成

仓库有一个可安装的 bundle，以及两个仅用于组织源码的实现目录：

| 包 | 目录 | 说明 |
|---|---|---|
| `@wjnct55555/dsh-achievements-bundle` | 仓库根 | 唯一对外安装包；它包含下面两部分的构建产物，并声明 `dsh.bundle` patch |
| 宿主侧引擎 | `packages/extensions/achievements/` | 事件监听、计数、解锁队列、只读 Remote（`list` / `recent` / `dock` / `deepState` / `setDeepInsights` / `telemetryState` / `setTelemetry` / `rates` / `stats`）与 `list_achievements` 工具 |
| 浏览器侧界面 | `packages/extensions/ui-achievements/` | 设置页画廊、toast 堆栈、侧栏奖杯、输入坞读条、画廊浮层 |

外部用户只需安装根 bundle；无需、也不应单独安装两个实现目录。

## 设计文档

架构、规则引擎、52 个成就目录、客户端数据流与未来演进方向（参考 AGPA 的可达性审计 / 规则扩展 / hint-tip 引导等候选）见 **[docs/DESIGN.md](docs/DESIGN.md)**。

## 功能

- **52 个成就**，分 `启程 / 工具大师 / 文件工匠 / 编排 / 目标 / 技能 / 模型 / 行为 / 联动 / 隐藏` 十类，稀有度覆盖 `普通 → 稀有 → 史诗 → 传说`。
- **本地持久化**：计数与解锁写入 `~/.agent-achievements/state.json`，重启后完整保留。
- **画廊双排序**：按分类（默认）或按难度（稀有度）查看。
- **数据仪表盘**：分类进度中空环形图与当月活动日历热力图并排一行（高度对齐，均可折叠）；稀有度分布以按稀有度着色的分段滑条呈现。
- **成就管理**：红色「清除成就记录」按钮带二次确认弹窗，一键清空全部进度（匿名统计开关与匿名标识保留）。
- **多 UI 表面**：解锁 toast（史诗/传说带彩纸）、侧栏奖杯（未读角标）、输入坞进度读条、设置页画廊与奖杯弹出的全屏画廊。
- **联动成就「吾栖之肤」**：检测到 `dsh-deep-whale` 鲸鱼娘皮肤插件（[github.com/Small-tailqwq/dsh-deep-whale](https://github.com/Small-tailqwq/dsh-deep-whale)）已安装时自动解锁。
- **隐藏成就**：达成前名称/描述以 `？？？` 显示。

## 截图

奖杯按钮弹出的成就画廊（复古终端风格）：

![成就画廊](assets/gallery.png)

## 隐私

**分层设计，默认零上传。**
- **基础层（默认）**：监听器只读取叶子标量（工具名、成功标志、agent id、事件类型、文件路径、token 计数），从不读取消息正文、文件内容、错误详情或搜索结果。
- **深度洞察层（opt-in，默认关闭）**：首次运行通过设置页询问，启用后允许对消息正文正则匹配与历史会话扫描，仅用于成就解锁；正文只在运行时匹配、**绝不落盘**。
- **匿名统计（opt-in，默认关闭）**：为显示「约 x% 用户获得」，用户可在画廊设置中显式开启。开启后**仅上报**成就 id、稀有度与随机匿名安装标识（`POST {endpoint}/unlock`），**绝不包含**会话、工具、文件或内容数据；获得率通过 `GET {endpoint}/stats` 拉取并本地缓存。未配置 `telemetryEndpoint` 或未开启时**不发生任何网络请求**。免费后端参考实现见 [docs/telemetry-worker.js](docs/telemetry-worker.js)（Cloudflare Workers 免费层，零成本）。
- **持久化**：只保存成就进度与匿名统计开关到本地 JSON（`~/.agent-achievements/state.json`），不含任何消息/文件内容。

### 启用匿名统计

```yaml
# cordis.yml 中给插件配置统计端点（部署免费 Worker 后替换为你的地址）
- plugin: @wjnct55555/dsh-achievements-bundle
  config:
    telemetryEndpoint: https://your-name.workers.dev
```

然后在成就画廊设置里打开「匿名统计」开关。开关状态会持久化，重启后保留。

## 构建与安装

### 从 tarball 安装（推荐）

```sh
npm pack
dsh plugin --profile web add ./wjnct55555-dsh-achievements-bundle-0.2.0.tgz
dsh web
```

bundle 自带宿主引擎和浏览器 UI 的运行产物，tarball 不包含仓库的 `node_modules`，因此不会把旧版 DSH 包带进宿主。

### 从 GitHub 安装

```sh
dsh plugin --profile web add github:WJNCT55555/dsh-achievements
dsh web
```

要求仓库 HEAD 已包含 0.2.2 兼容修复；否则拉到的仍是 0.1.0 的两包版本。

### 本地 checkout

```sh
git clone https://github.com/WJNCT55555/dsh-achievements
cd dsh-achievements
npm pack
dsh plugin --profile web add ./wjnct55555-dsh-achievements-bundle-0.2.0.tgz
```

不要直接 `dsh plugin add .`：link 安装会保留 checkout 自己的 `node_modules`，旧版 DSH 包会与宿主 0.2.2 混用并导致 import 失败。

### 从源码构建

仓库已提交可安装的 `lib/` 产物；日常安装不需要构建。只有修改实现源码时才需要 DSH 0.2.2 的源码工作区（本仓库的 tsconfig/tsdown 配置引用该工作区路径），构建浏览器实现后运行 `pnpm run assemble-client` 将 UI bundle 封装成根 bundle：

```sh
pnpm install
pnpm exec tsc -b packages/extensions/achievements packages/extensions/ui-achievements
pnpm exec tsdown --env.DSH_BUILD_FACE host   # 生成宿主侧 Typert 工件
pnpm --filter @wjnct55555/dsh-client-ui-achievements bundle  # 构建浏览器侧
pnpm run assemble-client
npm pack
```

宿主侧依赖 `@deepseek-ai/cordis-plugin-loader` 读取 Loader 条目以检测联动皮肤。浏览器侧挂载于 `settings.section`、`shell.overlay`、`sidebar.footer.action`、`conversation.composer.dock` 四个槽位。

## 测试

```sh
pnpm exec vitest run packages/extensions/achievements/tests/achievements.spec.ts
```

覆盖：会话播种、工具计数、连击重置、并发子代理、phoenix 恢复解锁、marathon 回合隔离、联动皮肤检测、token 按会话去重、匿名统计开关与上报等 27 个用例。

## 许可

MIT。见各包 `package.json` 与本仓库根目录 `LICENSE`。

## 兼容性

- 需要 DSH Web `0.2.2-rc.1` 或更新版本（`0.2.x`）；`0.1.x` 不再支持。
- 浏览器侧使用 0.2 的 `@deepseek-ai/dsh-client-store`，宿主侧使用 `agent/created` 与 Session snapshot 读取；生成的 Typert 0.1 工件在 `assemble-client` 中补上 0.2 要求的 strict codec `create()` 工厂。
- 可与 `dsh-crt-theme` 同时安装。主题仅修改视觉 token、字体与控件外观；成就插件独占自己的数据文件和 Remote 名称。成就画廊会采用当前主题的基础配色，功能与进度不受影响。
- 可与 `dsh-web-preview-float` 同时安装。预览插件拥有工作区预览/文件浏览能力，成就插件不读取其窗口状态；两者不共用状态文件、Remote 名称或浏览器模块 id。
- 三者使用 DSH Web 的正式扩展点，可任意安装顺序加载。若未来 DSH 大版本改动槽位或主题 token，请先升级三个插件到声明兼容的版本；遇到纯视觉异常时，可临时停用 CRT 主题以区分主题样式与功能问题。
- 成就进度是机器本地的全局数据，存放在 `~/.agent-achievements/state.json`；卸载插件不会自动删除该文件。
