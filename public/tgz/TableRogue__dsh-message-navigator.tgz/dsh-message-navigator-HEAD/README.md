# dsh-message-navigator

**消息导航条(Message Navigator)** —— DeepSeek Harness 网页聊天界面右侧的垂直消息索引条:每条用户输入对应一个半透明短横线 marker,点击平滑跳转,滚动时当前阅读位置实时高亮,适合超长对话快速定位。

> A slim right-edge message index for the DeepSeek Harness web GUI: one marker per user input, click to jump, active marker follows scroll.

![演示截图](docs/screenshot.png)

## 特性

- **点击跳转** `scrollIntoView`(平滑居中,已在视口附近时跳过动画,不产生横向位移)
- **滚动同步** 视口 40% 处为阅读线,实时高亮对应 marker;滚动路径纯算术计算,零 DOM 查询、零 re-render
- **Hover 预览** 统一 240px 卡片式 tooltip,1–2 行省略
- **动态同步** 新消息/删除/加载历史/切换会话自动重建;AI 流式输出不生成 marker
- **稳定标识** marker ↔ 消息经 `data-chat-flow-key`(内含 messageId)一一对应,不依赖 DOM 索引
- **性能与响应式** 几百条消息仍流畅;≤1100px 隐藏 tooltip,≤880px 隐藏组件

## 安装(每次启动自动加载)

```bash
# 本地 checkout
dsh plugin --profile web add ./dsh-message-navigator

# 或从 GitHub(纯 JS,无构建步骤)
dsh plugin --profile web add github:TableRogue/dsh-message-navigator
```

安装后自动追加进 profile 的 `dsh.profile.bundles`,启动 `dsh --profile web` 即生效,无需重建 Web 产物。验证 / 卸载:

```bash
dsh --profile web --dump-config        # 应看到 # == dsh-message-navigator 层
dsh plugin --profile web remove dsh-message-navigator
```

**临时方式(动态插件,单次进程)**:把 `src/client.js` 头注释以下的内容填入 `cordis_define` 的 `code.client` 并 `cordis_run`,详见文件头注释。

## 实现契约

```
用户消息 → messageId → data-chat-flow-key → marker → 消息行 DOM(滚动目标)
```

只读使用产品自身滚动记忆所依赖的稳定锚点:`[data-conversation-scroll]`(滚动容器)、`[data-chat-flow-key]`、`[data-chat-flow-kind="user"|"steering"]`;UI 挂载在加法式 `shell.overlay` 层,不替换任何现有界面。

## 定制

`lib/client.js` 顶部常量:`STRIP_W`(条宽 20)、`EDGE_GAP`(4)、`PAD`(14)、`GAP`(marker 间距 12)、`LINE_FRAC`(阅读线 0.4);样式类前缀 `mnv-`,颜色随主题 token `--dsw-alias-label-primary` 自适应亮/暗。

> 已知限制:依赖上述 DOM 契约,产品改版后可能需要同步更新选择器;本地链接安装时改源码重启即生效。

## License

[MIT](./LICENSE) © 2026 TableRogue
