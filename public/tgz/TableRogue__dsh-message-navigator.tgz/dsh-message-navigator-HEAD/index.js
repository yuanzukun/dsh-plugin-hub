/**
 * dsh-message-navigator — node (host) half. Pure UI plugin: the empty apply
 * exists so the plugin appears in the host Loader; the browser half ships via
 * exports["./client"], discovered through the package.json `dsh.client`
 * declaration and served by the client-modules node half.
 */
/** Host plugin body — no host-side behavior for this surface plugin. */
export function apply() {}
