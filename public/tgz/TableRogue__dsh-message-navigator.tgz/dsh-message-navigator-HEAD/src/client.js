/**
 * dsh-message-navigator — Client half (dynamic Cordis Plugin)
 *
 * This file is the exact `code.client` body for the dynamic Cordis Plugin
 * "Message Navigator" (`msgnv-1`). It is plain JavaScript — no TypeScript,
 * no JSX, no imports — and returns a Cordis Plugin object.
 *
 * To activate it in a DeepSeek Harness session:
 *
 *   1. Copy the entire contents of this file (below this header comment)
 *      into the `code.client` field of a `cordis_define` tool call
 *      (omit `code.host`: this plugin is Client-only).
 *   2. Call `cordis_run` with the returned pluginId/packageId and mode "run".
 *   3. Approve the activation card when prompted.
 *
 * The runtime is a temporary extension: it lives only for the current DSH
 * process. This repository is the shareable source of truth.
 *
 * For a persistent install that auto-loads on every startup, use the bundle
 * form instead (package.json dsh.bundle/dsh.client + cordis.patch.yml +
 * lib/client.js): `dsh plugin --profile <name> add ./dsh-message-navigator`.
 */

const CSS = `
.mnv-strip[data-mnv-strip]{
  position:absolute;width:20px;pointer-events:none;display:none;opacity:0;
  transition:opacity .25s ease;z-index:1;
}
.mnv-strip[data-mnv-strip].mnv-visible{display:block;opacity:1}
.mnv-marker{
  position:absolute;left:0;width:20px;height:16px;margin:0;padding:0;border:0;
  background:transparent;display:flex;align-items:center;justify-content:center;
  cursor:pointer;pointer-events:auto;transform:translateY(-8px);
  transition:top .18s ease-out;border-radius:10px;-webkit-tap-highlight-color:transparent;
}
.mnv-marker:focus{outline:none}
.mnv-marker:focus-visible{outline:1px solid var(--dsw-alias-label-primary,#9e9e9e);outline-offset:1px}
.mnv-dash{
  display:block;width:12px;height:3px;border-radius:999px;
  background:var(--dsw-alias-label-primary,#c9c9c9);opacity:.3;
  transition:opacity .15s ease,width .15s ease,height .15s ease;
}
.mnv-marker:hover .mnv-dash{opacity:.8;width:16px;height:4px}
.mnv-marker.mnv-active .mnv-dash{opacity:1;width:18px;height:5px}
.mnv-strip.mnv-dense .mnv-marker{height:10px}
.mnv-strip.mnv-dense .mnv-dash{width:8px;height:2px}
.mnv-strip.mnv-dense .mnv-marker.mnv-active .mnv-dash{width:11px;height:3px}
.mnv-tip{
  position:absolute;right:calc(100% + 12px);transform:translateY(-50%);
  width:240px;max-width:min(280px,40vw);max-height:3.2em;
  padding:6px 10px;border-radius:8px;
  background:rgba(23,23,28,.92);color:rgba(255,255,255,.95);
  font:12px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;
  text-align:left;
  pointer-events:none;white-space:pre-wrap;overflow:hidden;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;
  box-shadow:0 6px 20px rgba(0,0,0,.28);
}
@media (max-width:1100px){.mnv-tip{display:none}}
@media (max-width:880px){.mnv-strip[data-mnv-strip]{display:none!important}}
`

styles.insert(CSS)

const STRIP_W = 20
const EDGE_GAP = 4
const PAD = 14
const GAP = 12
const LINE_FRAC = 0.4
const USER_SELECTOR = '[data-chat-flow-kind="user"],[data-chat-flow-kind="steering"]'

function MessageNavigator(props) {
  const timer = props.timer
  const stripRef = React.useRef(null)
  const markerEls = React.useRef(new Map())
  const apiRef = React.useRef(null)
  const [markers, setMarkers] = React.useState([])
  const [visible, setVisible] = React.useState(false)
  const [dense, setDense] = React.useState(false)
  const [tip, setTip] = React.useState(null)

  React.useEffect(() => {
    let disposed = false
    let scrollport = null
    let rows = []
    let sig = ''
    let activeKey = null
    let pendingKey = null
    let pendingUntil = 0
    let rafId = 0
    let measureT = 0
    let rescanT = 0
    let beatT = 0
    let lastScrollH = 0
    let lastClientH = 0
    let mo = null
    let ro = null

    const requestFrame = typeof window.requestAnimationFrame === 'function'
      ? (fn) => window.requestAnimationFrame(fn)
      : (fn) => window.setTimeout(() => fn(), 16)

    function later(fn, ms) {
      if (timer !== undefined && typeof timer.timeout === 'function') return timer.timeout(fn, ms)
      return window.setTimeout(fn, ms)
    }
    function cancel(id) {
      if (id === 0 || id === undefined || id === null) return
      if (typeof id === 'function') id()
      else window.clearTimeout(id)
    }

    const previewOf = (el) => {
      const text = (el.textContent || '').replace(/\s+/g, ' ').trim()
      return text || '用户消息'
    }

    const findScrollport = () => document.querySelector('[data-conversation-scroll]')

    function layerOrigin() {
      const host = stripRef.current !== null ? stripRef.current.parentElement : null
      if (host === null) return { x: 0, y: 0 }
      const rect = host.getBoundingClientRect()
      return { x: rect.left, y: rect.top }
    }

    function stripGeometry() {
      if (scrollport === null) return null
      const rect = scrollport.getBoundingClientRect()
      const origin = layerOrigin()
      return {
        left: rect.right - origin.x - STRIP_W - EDGE_GAP,
        top: rect.top - origin.y,
        height: rect.height,
      }
    }

    function layoutYs() {
      const n = rows.length
      const geo = stripGeometry()
      if (geo === null || n === 0) return
      const usable = Math.max(24, geo.height - 2 * PAD)
      if (n === 1) {
        rows[0].y = PAD + usable / 2
        return
      }
      const idealTotal = (n - 1) * GAP
      if (idealTotal <= usable) {
        const start = PAD + (usable - idealTotal) / 2
        for (let i = 0; i < n; i++) rows[i].y = start + i * GAP
      } else {
        const step = usable / (n - 1)
        for (let i = 0; i < n; i++) rows[i].y = PAD + i * step
      }
    }

    function updateActive() {
      if (scrollport === null || rows.length === 0) return
      const line = scrollport.scrollTop + scrollport.clientHeight * LINE_FRAC
      let key
      if (pendingKey !== null && Date.now() < pendingUntil) {
        key = pendingKey
        for (const r of rows) {
          if (r.key === pendingKey && Math.abs(r.docTop + r.height / 2 - line) < 90) pendingKey = null
        }
      } else {
        pendingKey = null
        let active = rows[0]
        for (const r of rows) {
          if (r.docTop <= line) active = r
          else break
        }
        key = active.key
      }
      if (key !== activeKey) {
        activeKey = key
        markerEls.current.forEach((el, k) => {
          if (k === key) el.classList.add('mnv-active')
          else el.classList.remove('mnv-active')
        })
      }
    }

    function measure() {
      cancel(measureT)
      measureT = 0
      const port = scrollport
      if (port === null || !document.contains(port)) { rescan(); return }
      const rect = port.getBoundingClientRect()
      const st = port.scrollTop
      for (const r of rows) {
        const rr = r.el.getBoundingClientRect()
        r.docTop = rr.top - rect.top + st
        r.height = rr.height
      }
      lastScrollH = port.scrollHeight
      lastClientH = port.clientHeight
      const geo = stripGeometry()
      if (stripRef.current !== null && geo !== null) {
        stripRef.current.style.left = Math.round(geo.left) + 'px'
        stripRef.current.style.top = Math.round(geo.top) + 'px'
        stripRef.current.style.height = Math.round(geo.height) + 'px'
      }
      if (geo !== null) {
        layoutYs()
        const usable = Math.max(24, geo.height - 2 * PAD)
        const denseNow = rows.length > 1 && (rows.length - 1) * GAP > usable
        setDense((prev) => (prev === denseNow ? prev : denseNow))
        setMarkers((prev) => {
          if (prev.length === rows.length && prev.every((p, i) => p.key === rows[i].key && p.text === rows[i].text && Math.abs(p.y - rows[i].y) < 0.75)) return prev
          return rows.map((r) => ({ key: r.key, text: r.text, y: Math.round(r.y * 10) / 10 }))
        })
        setVisible(rows.length >= 2)
      }
      updateActive()
    }

    function scheduleMeasure() {
      if (measureT !== 0 || disposed) return
      measureT = later(measure, 260)
    }

    function onScroll() {
      if (rafId !== 0 || disposed) return
      rafId = requestFrame(() => {
        rafId = 0
        const port = scrollport
        if (port === null) return
        if (port.scrollHeight !== lastScrollH || port.clientHeight !== lastClientH) scheduleMeasure()
        updateActive()
      })
    }

    function attach(port) {
      port.addEventListener('scroll', onScroll, { passive: true })
      if (typeof window.MutationObserver === 'function') {
        mo = new window.MutationObserver(() => {
          if (rescanT === 0 && !disposed) rescanT = later(rescan, 160)
        })
        mo.observe(port, { childList: true, subtree: true })
      }
      if (typeof window.ResizeObserver === 'function') {
        ro = new window.ResizeObserver(() => scheduleMeasure())
        ro.observe(port)
      }
    }

    function detach() {
      if (scrollport !== null) scrollport.removeEventListener('scroll', onScroll)
      if (mo !== null) { mo.disconnect(); mo = null }
      if (ro !== null) { ro.disconnect(); ro = null }
    }

    function rescan() {
      cancel(rescanT)
      rescanT = 0
      const port = findScrollport()
      if (port !== scrollport) {
        detach()
        scrollport = port
        if (port !== null) attach(port)
      }
      if (port === null) {
        rows = []
        sig = ''
        activeKey = null
        pendingKey = null
        setMarkers([])
        setVisible(false)
        setDense(false)
        setTip(null)
        return
      }
      const els = Array.from(port.querySelectorAll(USER_SELECTOR))
      const nextSig = els.map((el) => el.dataset.chatFlowKey || '').join('\u0001')
      const byKey = new Map(rows.map((r) => [r.key, r]))
      rows = els.map((el) => {
        const key = el.dataset.chatFlowKey || ''
        const old = byKey.get(key)
        if (old !== undefined) {
          old.el = el
          old.text = previewOf(el)
          return old
        }
        return { key, el, text: previewOf(el), docTop: 0, height: 0, y: 0 }
      })
      if (nextSig !== sig) {
        sig = nextSig
        measure()
      } else {
        scheduleMeasure()
      }
    }

    function rowByKey(key) {
      let row = rows.find((r) => r.key === key)
      if (row !== undefined && document.contains(row.el)) return row
      if (scrollport === null) return undefined
      let q = null
      try {
        const esc = typeof window.CSS !== 'undefined' && typeof window.CSS.escape === 'function' ? window.CSS.escape(key) : key
        q = scrollport.querySelector('[data-chat-flow-key="' + esc + '"]')
      } catch (err) {
        q = null
      }
      if (q !== null) {
        const existing = rows.find((r) => r.key === key)
        if (existing !== undefined) {
          existing.el = q
          existing.text = previewOf(q)
          row = existing
        }
      }
      return row
    }

    function jump(key) {
      const port = scrollport
      if (port === null) return
      const row = rowByKey(key)
      if (row === undefined || !document.contains(row.el)) return
      const el = row.el
      const portRect = port.getBoundingClientRect()
      const rect = el.getBoundingClientRect()
      const center = rect.top + rect.height / 2
      const line = portRect.top + portRect.height * LINE_FRAC
      const fullyIn = rect.top >= portRect.top - 2 && rect.bottom <= portRect.bottom + 2
      const reduceMotion = typeof window.matchMedia === 'function' && window.matchMedia('(prefers-reduced-motion: reduce)').matches
      if (!(fullyIn && Math.abs(center - line) < portRect.height * 0.32)) {
        try {
          el.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth', block: 'center', inline: 'nearest' })
        } catch (err) {
          el.scrollIntoView(true)
        }
      }
      pendingKey = key
      pendingUntil = Date.now() + 1600
      updateActive()
    }

    apiRef.current = {
      jump,
      rowByKey,
      stripHeight: () => (scrollport !== null ? scrollport.getBoundingClientRect().height : 0),
    }

    rescan()
    beatT = later(function beat() {
      if (disposed) return
      const port = findScrollport()
      if (port !== scrollport) rescan()
      else if (port !== null && (port.scrollHeight !== lastScrollH || port.clientHeight !== lastClientH)) scheduleMeasure()
      beatT = later(beat, 1500)
    }, 1500)

    return () => {
      disposed = true
      detach()
      if (rafId !== 0 && typeof window.cancelAnimationFrame === 'function') window.cancelAnimationFrame(rafId)
      cancel(measureT)
      cancel(rescanT)
      cancel(beatT)
      apiRef.current = null
    }
  }, [timer])

  const onMarkerClick = React.useCallback((key) => {
    if (apiRef.current !== null) apiRef.current.jump(key)
  }, [])

  const onMarkerEnter = React.useCallback((key) => {
    const api = apiRef.current
    if (api === null) return
    const row = api.rowByKey(key)
    if (row === undefined) return
    const h = api.stripHeight()
    const y = Math.min(Math.max(row.y, 34), Math.max(34, h - 34))
    setTip({ text: row.text, y })
  }, [])

  const onMarkerLeave = React.useCallback(() => setTip(null), [])

  const stripClassName = 'mnv-strip' + (visible ? ' mnv-visible' : '') + (dense ? ' mnv-dense' : '')

  return React.createElement(
    'div',
    {
      ref: stripRef,
      className: stripClassName,
      'data-mnv-strip': '',
      role: 'navigation',
      'aria-label': '消息导航',
    },
    markers.map((m) => {
      const label = m.text.length > 80 ? m.text.slice(0, 80) + '…' : m.text
      return React.createElement(
        'button',
        {
          key: m.key,
          type: 'button',
          className: 'mnv-marker',
          style: { top: m.y },
          'data-mnv-key': m.key,
          'aria-label': '定位到用户消息：' + label,
          ref: (el) => {
            if (el === null) markerEls.current.delete(m.key)
            else markerEls.current.set(m.key, el)
          },
          onClick: () => onMarkerClick(m.key),
          onMouseEnter: () => onMarkerEnter(m.key),
          onMouseLeave: onMarkerLeave,
        },
        React.createElement('span', { className: 'mnv-dash' }),
      )
    }),
    tip !== null
      ? React.createElement('div', { className: 'mnv-tip', style: { top: tip.y }, role: 'tooltip' }, tip.text)
      : null,
  )
}

return {
  apply(ctx) {
    const slots = ctx.get('slots')
    if (slots === undefined) return
    const timer = ctx.get('timer')
    slots.inject('shell.overlay', () => slots.register(
      {
        name: 'shell.overlay',
        id: 'message-navigator',
        order: 0,
        label: () => '消息导航',
      },
      () => React.createElement(MessageNavigator, { timer }),
    ))
  },
}
