/**
 * Minimal writable snapshot store — the self-contained slice this package
 * feeds to the renderer's synthesized selector hooks. dsh 0.1.2-alpha.1
 * rehomed the shared engine (`createSnapshotStore`) into the
 * `dsh-client-store` platform package, whose npm artifact does not exist for
 * out-of-tree typechecking; the contract this store implements is the same
 * observable face (`getSnapshot`/`subscribe`) plus the write face
 * (`set`/`update`) the settings form needs, so the renderer can bind it
 * without knowing the difference.
 * @module @sundusk/dsh-waterball/client/snapshot-store
 */

/**
 * A store the renderer can bind to React selector hooks and business code can
 * write wholesale or through a draft.
 */
export interface SnapshotStore<T> {
  /** @returns the current snapshot (stable reference until the next write). */
  getSnapshot(): T
  /**
   * Observe snapshot replacements.
   * @param listener - invoked after each published write.
   * @returns the disposer removing this listener.
   */
  subscribe(listener: () => void): () => void
  /**
   * Replace the state wholesale.
   * @param next - next state.
   */
  set(next: T): void
  /**
   * Mutate the state through a draft copy.
   * @param mutator - receives a shallow draft; return value is ignored.
   */
  update(mutator: (draft: T) => void): void
}

/**
 * Create a synchronous snapshot store over one initial state. Writes notify
 * subscribers immediately; `getSnapshot` keeps returning the identical
 * reference between writes so `useSyncExternalStore`-style binding is stable.
 * @param init - initial state.
 * @returns the store.
 */
export function createSnapshotStore<T>(init: T): SnapshotStore<T> {
  let state = init
  const listeners = new Set<() => void>()
  const write = (next: T): void => {
    if (Object.is(state, next)) return
    state = next
    // Copy before dispatch so one listener subscribing or disposing during
    // notification cannot skip or double-notify the others.
    for (const listener of [...listeners]) listener()
  }
  return {
    getSnapshot: () => state,
    subscribe: (listener) => {
      listeners.add(listener)
      return () => {
        listeners.delete(listener)
      }
    },
    set: write,
    update: (mutator) => {
      const draft = { ...state }
      mutator(draft)
      write(draft)
    },
  }
}
