/**
 * dsh-waterball browser half — renders the floating water ball and drives it
 * from the host's same-origin `GET /api/waterball/status` endpoint, gated by
 * the `waterball` settings namespace `enabled` master switch. It also seats a
 * plugin configuration card directly in the settings plugin section, on the
 * same level as the built-in Shell / Agent loop / Web search cards and the
 * "Web UI 插件" family group.
 *
 * dsh 0.1.2-alpha.1 dissolved the `dsh-client-runtime` package: the client
 * context is now the plain cordis `Context` with services merged in by their
 * owning packages, and this plugin declares the merges it consumes locally
 * (the locale merge rides the `dsh-client-locale` type import). No
 * `@deepseek-ai` module is imported for values, so the bundle's only module
 * table requests are the platform seed entries (react family).
 * @module @sundusk/dsh-waterball/client
 */

import type { Context as ClientContext } from '@deepseek-ai/cordis'
// Type-only: pulls the SlotMap/LocaleNamespaceMap vocabulary this file merges into.
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import { WaterballDockEntry } from './WaterballPet.tsx'
import { WaterballSettingsCard, WaterballSettingsCardController, type WaterballSettings } from './WaterballSettingsCard.tsx'
import type { SettingsScopeBinder } from './settings-contract.ts'
import { NS, en, zh } from './locales.ts'

/** Settings namespace the settings card edits (the host plugin registers it). */
const WATERBALL_SETTINGS_NS = 'waterball'

/** Required services. */
export const inject = ['slots', 'locale', 'settingsScope']

declare module '@deepseek-ai/cordis' {
  interface Context {
    /** The renderer-owned slot registry service (provided by ui-renderer). */
    slots: SlotRegistryFace
    /** The settings-namespace scope binder (provided by ui-settings). */
    settingsScope: SettingsScopeBinder
    /** The browser-side locale registry (provided by the locale plugin). */
    locale: LocaleRuntimeFace
  }
}

/** The locale registry members this plugin consumes. */
export interface LocaleRuntimeFace {
  /**
   * Register dictionaries for one namespace, one entry per locale id.
   * @param ns - the namespace these dictionaries answer.
   * @param dicts - locale id to flat template dictionary.
   * @returns the disposer removing every dictionary registered by this call.
   */
  register(ns: string, dicts: Record<string, Record<string, string>>): () => void
}

/** The SlotRegistry members this plugin consumes. */
export interface SlotRegistryFace {
  /**
   * Register one slot entry.
   * @param options - entry declaration (name, optional key/id/order/locale/inject).
   * @param component - the entry component.
   * @returns the disposer removing the entry.
   */
  register(options: {
    /** Declared slot name. */
    name: string
    /** Keyed-slot instance key. */
    key?: string
    /** List-slot identity. */
    id?: string
    /** List-slot ordering. */
    order?: number
    /** Declared dictionary namespace (the renderer synthesizes the `t` seat). */
    locale?: string
    /** Injected business face handed to the component. */
    inject?: () => object
  }, component: unknown): () => void
  /**
   * Own one slot registration on the caller's fiber lifetime.
   * @param key - declared slot name.
   * @param registrar - callback registering (and returning the disposer).
   * @returns the disposer for the whole registration.
   */
  inject(key: string, registrar: () => (() => void) | void): () => void
}

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface SlotMap {
    /**
     * One plugin's configuration card inside the settings plugin section,
     * keyed by the settings namespace the card edits.
     * Type-only local copy of the slot the official SDK
     * (`dsh-client-ui-settings-plugins`) declares at runtime; kept here so
     * this plugin's typecheck stays self-contained. The slot is
     * `keyed` — the tab dispatches `settings.plugin.item` with
     * `entryKey: <namespace>` for every namespace the Host serves, so the
     * card registers under the `waterball` namespace key. Registering here
     * puts the card on the same level as the built-in Shell / Agent loop /
     * Web search cards and the "Web UI 插件" family group.
     */
    'settings.plugin.item': { kind: 'keyed'; scope: 'root'; owner: SettingsPluginItemOwnerProps }
    /** Frame-wide overlay that is rendered on both the new-session and active-session pages. */
    'shell.overlay': { kind: 'list'; scope: 'root'; owner: ShellOverlayOwnerProps }
  }
}

/** Owner share of a plugin card (the settings section supplies nothing). */
export interface SettingsPluginItemOwnerProps {
  /** Marker field: card owner props are intentionally empty. */
  children?: never
}

/** Owner share of the frame-wide overlay (the layout supplies no props). */
export interface ShellOverlayOwnerProps {
  /** Marker field: overlay owner props are intentionally empty. */
  children?: never
}

/**
 * Client plugin body: register dictionaries, mount the water ball and its
 * poll loop while the plugin is enabled, and seat the settings card in the
 * settings plugin section.
 * @param ctx - client root context.
 */
export function apply(ctx: ClientContext): void {
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'waterball: dictionaries')

  const settingsScope = ctx.settingsScope.bind<WaterballSettings>({ namespace: WATERBALL_SETTINGS_NS })
  const enabled = (): boolean => {
    const snapshot = settingsScope.getSnapshot()
    return snapshot.status === 'ready'
      ? snapshot.value?.enabled ?? true
      : snapshot.status === 'unavailable'
  }
  // 「隐藏」只影响网页端是否渲染水球，不关停 host 的状态监听与 /api/waterball/status
  const hidden = (): boolean => {
    const snapshot = settingsScope.getSnapshot()
    return snapshot.status === 'ready'
      ? snapshot.value?.hidden ?? true
      : false
  }
  const persistPosition = (right: number, bottom: number): void => {
    void settingsScope.set('right', Math.round(right))
    void settingsScope.set('bottom', Math.round(bottom))
  }

  // Plugin configuration card: one staged form over the `waterball` settings
  // namespace, contributed to the settings plugin section at the top level
  // (a sibling of the built-in Shell / Agent loop / Web search cards and the
  // "Web UI 插件" family group card). The tab keys the card by the settings
  // namespace it edits — the same string the host registers — so the tab
  // dispatches it whenever the `waterball` namespace is served.
  const card = new WaterballSettingsCardController(settingsScope)
  ctx.slots.inject('settings.plugin.item', () => ctx.slots.register({
    name: 'settings.plugin.item',
    key: WATERBALL_SETTINGS_NS,
    locale: NS,
    inject: () => card.inject(),
  }, WaterballSettingsCard))

  // The dock entry (and its poll loop) lives while the plugin is enabled and
  // not hidden; toggling `enabled` off or `hidden` on removes the ball from
  // the web UI without touching the host-side status route.
  let disposeUi: (() => void) | undefined
  const syncUi = (): void => {
    if (enabled() && !hidden() && disposeUi === undefined) {
      disposeUi = ctx.slots.inject('shell.overlay', () => ctx.slots.register({
        name: 'shell.overlay',
        id: 'waterball',
        order: 110,
        locale: NS,
        inject: () => ({ persistPosition }),
      }, WaterballDockEntry))
    } else if ((!enabled() || hidden()) && disposeUi !== undefined) {
      disposeUi()
      disposeUi = undefined
    }
  }
  settingsScope.subscribe(syncUi)
  syncUi()
}
