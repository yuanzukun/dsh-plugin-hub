/**
 * Local structural contracts for the settings-namespace scope service, kept
 * self-contained so this package typechecks without importing dsh client
 * type homes. dsh 0.1.2-alpha.1 moved these declarations (the dissolved
 * `dsh-client-runtime` package's scope contract) into
 * `@deepseek-ai/dsh-client-ui-settings/client`; the shapes here mirror that
 * 0.1.2 contract — the Host serves and the binder binds exactly these
 * members, so structural conformance is the whole contract.
 * @module @sundusk/dsh-waterball/client/settings-contract
 */
/**
 * One namespace's derived client view. `loading` until the first accepted
 * section, `ready` while one stands, and `unavailable` when the namespace is
 * not exposed to this client or the connection keeps preferences
 * process-local (memory mode).
 */
export interface SettingsScopeSnapshot<T> {
    /** See the interface JSDoc. */
    status: 'loading' | 'ready' | 'unavailable';
    /** Last accepted schema-resolved section; undefined before the first acceptance. */
    value: T | undefined;
    /** Composition layer the Host resolved `value` over, when the plugin declared one. */
    base: unknown;
    /** Raw user layer as stored, when one exists; field presence marks overridden. */
    user: unknown;
    /** Namespace revision fencing the next write; undefined before the first Host view. */
    revision: number | undefined;
    /** Whether the Host document accepts writes; memory mode never does. */
    writable: boolean;
    /** `host` syncs with the Host document; `memory` keeps a remote browser process-local. */
    mode: 'host' | 'memory';
}
/**
 * Domain-owned description of one settings namespace consumed by a browser
 * plugin. The namespace is registered by the owning Host plugin; `decode`
 * stays undeclared so the section validates against the namespace's own
 * serialized wire schema.
 */
export interface SettingsScopeSpec<T = unknown> {
    /** Settings namespace registered by the owning Host plugin. */
    namespace: string;
}
/**
 * Reactive owner handle over one namespace's durable section — the browser
 * mirror of the Host-side settings scope. Domains read and observe the
 * snapshot and route explicit user choices through its mutation methods.
 */
export interface SettingsScope<T> {
    /** @returns the current sync snapshot (stable reference until the next change). */
    getSnapshot(): SettingsScopeSnapshot<T>;
    /**
     * Observe snapshot replacements.
     * @param listener - invoked after each snapshot change.
     * @returns the disposer removing this listener.
     */
    subscribe(listener: () => void): () => void;
    /**
     * Queue one field write.
     * @param field - scalar field inside the namespace section.
     * @param value - JSON-shaped value selected by the user.
     * @returns settlement after the write.
     */
    set(field: string, value: unknown): Promise<void>;
    /**
     * Queue one field clear, so the field re-inherits the composition layer.
     * @param field - scalar field inside the namespace section.
     * @returns settlement after the clear.
     */
    unset(field: string): Promise<void>;
}
/**
 * The settings domain's base service face (`ctx.settingsScope`). Features
 * that own a preference bind one namespace scope through it rather than
 * touching the settings transport themselves.
 */
export interface SettingsScopeBinder {
    /**
     * Bind one namespace scope on the caller's plugin lifecycle.
     * @param spec - domain-owned namespace contract.
     * @returns the bound scope consumed by the domain's services and cards.
     */
    bind<T>(spec: SettingsScopeSpec): SettingsScope<T>;
}
