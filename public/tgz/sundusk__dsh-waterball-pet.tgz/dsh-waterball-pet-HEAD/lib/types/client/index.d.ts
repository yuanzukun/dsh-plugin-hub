/**
 * dsh-waterball browser half — renders the floating water ball and drives it
 * from the host's same-origin `GET /api/waterball/status` endpoint, gated by
 * the `waterball` settings namespace `enabled` master switch. It also seats a
 * plugin configuration card directly in the settings plugin section, on the
 * same level as the built-in Shell / Agent loop / Web search cards and the
 * "Web UI 插件" family group.
 *
 * dsh 0.1.2-alpha.1 dissolved the `dsh-client-runtime` package: the client
 * context is now the plain cordis `Context` with services merged in by their
 * owning packages, and this plugin declares the merges it consumes locally
 * (the locale merge rides the `dsh-client-locale` type import). No
 * `@deepseek-ai` module is imported for values, so the bundle's only module
 * table requests are the platform seed entries (react family).
 * @module @sundusk/dsh-waterball/client
 */
import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { SettingsScopeBinder } from './settings-contract.ts';
/** Required services. */
export declare const inject: string[];
declare module '@deepseek-ai/cordis' {
    interface Context {
        /** The renderer-owned slot registry service (provided by ui-renderer). */
        slots: SlotRegistryFace;
        /** The settings-namespace scope binder (provided by ui-settings). */
        settingsScope: SettingsScopeBinder;
        /** The browser-side locale registry (provided by the locale plugin). */
        locale: LocaleRuntimeFace;
    }
}
/** The locale registry members this plugin consumes. */
export interface LocaleRuntimeFace {
    /**
     * Register dictionaries for one namespace, one entry per locale id.
     * @param ns - the namespace these dictionaries answer.
     * @param dicts - locale id to flat template dictionary.
     * @returns the disposer removing every dictionary registered by this call.
     */
    register(ns: string, dicts: Record<string, Record<string, string>>): () => void;
}
/** The SlotRegistry members this plugin consumes. */
export interface SlotRegistryFace {
    /**
     * Register one slot entry.
     * @param options - entry declaration (name, optional key/id/order/locale/inject).
     * @param component - the entry component.
     * @returns the disposer removing the entry.
     */
    register(options: {
        /** Declared slot name. */
        name: string;
        /** Keyed-slot instance key. */
        key?: string;
        /** List-slot identity. */
        id?: string;
        /** List-slot ordering. */
        order?: number;
        /** Declared dictionary namespace (the renderer synthesizes the `t` seat). */
        locale?: string;
        /** Injected business face handed to the component. */
        inject?: () => object;
    }, component: unknown): () => void;
    /**
     * Own one slot registration on the caller's fiber lifetime.
     * @param key - declared slot name.
     * @param registrar - callback registering (and returning the disposer).
     * @returns the disposer for the whole registration.
     */
    inject(key: string, registrar: () => (() => void) | void): () => void;
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /**
         * One plugin's configuration card inside the settings plugin section,
         * keyed by the settings namespace the card edits.
         * Type-only local copy of the slot the official SDK
         * (`dsh-client-ui-settings-plugins`) declares at runtime; kept here so
         * this plugin's typecheck stays self-contained. The slot is
         * `keyed` — the tab dispatches `settings.plugin.item` with
         * `entryKey: <namespace>` for every namespace the Host serves, so the
         * card registers under the `waterball` namespace key. Registering here
         * puts the card on the same level as the built-in Shell / Agent loop /
         * Web search cards and the "Web UI 插件" family group.
         */
        'settings.plugin.item': {
            kind: 'keyed';
            scope: 'root';
            owner: SettingsPluginItemOwnerProps;
        };
        /** Frame-wide overlay that is rendered on both the new-session and active-session pages. */
        'shell.overlay': {
            kind: 'list';
            scope: 'root';
            owner: ShellOverlayOwnerProps;
        };
    }
}
/** Owner share of a plugin card (the settings section supplies nothing). */
export interface SettingsPluginItemOwnerProps {
    /** Marker field: card owner props are intentionally empty. */
    children?: never;
}
/** Owner share of the frame-wide overlay (the layout supplies no props). */
export interface ShellOverlayOwnerProps {
    /** Marker field: overlay owner props are intentionally empty. */
    children?: never;
}
/**
 * Client plugin body: register dictionaries, mount the water ball and its
 * poll loop while the plugin is enabled, and seat the settings card in the
 * settings plugin section.
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
