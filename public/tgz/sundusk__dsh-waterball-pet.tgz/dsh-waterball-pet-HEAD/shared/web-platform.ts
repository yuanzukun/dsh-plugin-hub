/**
 * Shared browser platform modules — mirrors the dsh 0.1.2-alpha.1 shell seed
 * table (`packages/client/web/src/platform.ts`). Seeding, bundling externals,
 * and Vite aliases consume this list so their module identities cannot drift.
 * @module @sundusk/dsh-waterball/shared/web-platform
 */

/** The module specifiers the shell shares into the frozen module table. */
export const PLATFORM_MODULES = [
  'react', 'react/jsx-runtime', 'react-dom', 'react-dom/client', '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-store',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-ui-primitives',
] as const

/** One platform module specifier (a seed-table key). */
export type PlatformModule = (typeof PLATFORM_MODULES)[number]
