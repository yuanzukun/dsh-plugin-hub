/**
 * Type definitions for the Finance DB plugin.
 * Based on the direct data-source capabilities in Awesome-finance-skills.
 */

export interface StockQuote {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  volume: number;
  marketCap?: number;
  peRatio?: number;
  timestamp: number;
}

export interface OHLCV {
  timestamp: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface StockFundamentals {
  symbol: string;
  name: string;
  marketCap?: number;
  peRatio?: number;
  pbRatio?: number;
  dividendYield?: number;
  eps?: number;
  revenue?: number;
  netIncome?: number;
  totalAssets?: number;
  totalDebt?: number;
  roe?: number;
  roa?: number;
  source?: string;
}

export interface NewsItem {
  id: string;
  title: string;
  summary: string;
  source: string;
  url: string;
  publishedAt: number;
  symbols?: string[];
  sentiment?: SentimentScore;
  category: 'news' | 'announcement' | 'research' | 'social';
}

export interface SentimentScore {
  score: number; // -1.0 to +1.0
  label: 'positive' | 'negative' | 'neutral';
  confidence: number;
  model: 'finbert' | 'llm' | 'ensemble';
}

export interface PredictionResult {
  symbol: string;
  horizon: '1d' | '5d' | '20d' | '60d';
  predictedPrice: number;
  predictedChange: number;
  confidence: number;
  model: 'kronos' | 'kronos-news';
  factors: string[];
  timestamp: number;
}

export interface SignalEvent {
  id: string;
  symbol: string;
  signalType: 'buy' | 'sell' | 'hold' | 'strengthen' | 'weaken' | 'falsify';
  strength: number; // 0-1
  reason: string;
  source: 'technical' | 'fundamental' | 'news' | 'sentiment' | 'prediction';
  timestamp: number;
  expiry?: number;
}

export interface LogicChainNode {
  id: string;
  type: 'event' | 'factor' | 'impact' | 'conclusion';
  label: string;
  description: string;
  confidence: number;
  children: string[];
  parent?: string;
}

export interface LogicChain {
  rootId: string;
  nodes: Record<string, LogicChainNode>;
  metadata: {
    symbol: string;
    generatedAt: number;
    model: string;
  };
}

export interface FinanceReport {
  id: string;
  title: string;
  symbol?: string;
  sections: ReportSection[];
  charts: ChartData[];
  generatedAt: number;
  model: string;
}

export interface ReportSection {
  title: string;
  content: string;
  type: 'overview' | 'analysis' | 'risk' | 'recommendation' | 'chart';
}

export interface ChartData {
  type: 'line' | 'bar' | 'candlestick' | 'area';
  title: string;
  data: any[];
  config?: Record<string, any>;
}

export interface SearchResult {
  query: string;
  results: Array<{
    title: string;
    url: string;
    snippet: string;
    source: string;
    relevance: number;
  }>;
  timestamp: number;
}

export interface MarketOverview {
  indices: Array<{
    symbol: string;
    name: string;
    price: number;
    change: number;
    changePercent: number;
  }>;
  sectors: Array<{
    name: string;
    changePercent: number;
    topGainers: string[];
    topLosers: string[];
  }>;
  newsCount: number;
  timestamp: number;
}

// Configuration types
export interface FinanceDBConfig {
  /** Jina API key for the optional direct web-search provider. */
  jinaApiKey?: string;
  /** Default market: 'A' | 'HK' | 'US' | 'global' */
  defaultMarket?: 'A' | 'HK' | 'US' | 'global';
  /** Cache TTL in milliseconds */
  cacheTtl?: number;
  /** Enable local/agent news sentiment analysis when a provider is mounted. */
  enableSentiment?: boolean;
  /** Enable Kronos predictions */
  enablePrediction?: boolean;
  /** Request timeout in ms */
  timeout?: number;
}

// Service interface
export interface FinanceDBService {
  // Stock data
  getQuote(symbol: string, market?: string): Promise<StockQuote>;
  getOHLCV(symbol: string, period: '1d' | '5d' | '1m' | '3m' | '6m' | '1y' | '5y', market?: string): Promise<OHLCV[]>;
  getFundamentals(symbol: string, market?: string): Promise<StockFundamentals>;
  searchStocks(query: string, market?: string): Promise<Array<{ symbol: string; name: string; market: string }>>;

  // News & sentiment
  getNews(symbol?: string, limit?: number, category?: string): Promise<NewsItem[]>;
  getSentiment(text: string): Promise<SentimentScore>;
  getNewsSentiment(symbol: string, hours?: number): Promise<SentimentScore>;

  // Predictions
  getPrediction(symbol: string, horizon: '1d' | '5d' | '20d' | '60d', useNews?: boolean): Promise<PredictionResult>;

  // Signals
  getSignals(symbol?: string, limit?: number): Promise<SignalEvent[]>;
  trackSignal(signalId: string): Promise<SignalEvent | null>;

  // Logic visualization
  getLogicChain(symbol: string, event?: string): Promise<LogicChain>;
  exportLogicChain(chain: LogicChain, format: 'drawio' | 'mermaid' | 'json'): Promise<string>;

  // Reports
  generateReport(symbol: string, type: 'quick' | 'full' | 'earnings' | 'technical'): Promise<FinanceReport>;

  // Search
  searchWeb(query: string, source?: 'jina' | 'ddg' | 'baidu'): Promise<SearchResult>;
  searchLocal(query: string, collection?: string): Promise<SearchResult>;

  // Market overview
  getMarketOverview(): Promise<MarketOverview>;

  // Health
  healthCheck(): Promise<{ status: 'ok' | 'degraded' | 'down'; services: Record<string, boolean> }>;
}

// Context key for dependency injection
export const FINANCE_DB_KEY = Symbol.for('dsh.finance.db');

declare module '@deepseek-ai/cordis' {
  interface Context {
    [FINANCE_DB_KEY]?: FinanceDBService;
  }
}
