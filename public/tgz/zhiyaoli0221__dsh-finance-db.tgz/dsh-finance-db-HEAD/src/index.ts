import type { Context } from '@deepseek-ai/cordis';
import type { ToolRuntime } from '@deepseek-ai/dsh-tools';
import { FinanceDBServiceImpl } from './service.js';
import { registerFinanceTools } from './tools.js';
import type { FinanceDBConfig } from './types.js';

export { FinanceDBServiceImpl } from './service.js';
export { APIClient } from './api-client.js';
export { FinanceCache } from './cache.js';
export { registerFinanceTools, financeTools } from './tools.js';
export * from './types.js';

/** DSH host plugin. It registers read-only finance data tools in the active profile. */
export const financePlugin = Object.assign((ctx: Context, config: FinanceDBConfig = {}) => {
  const service = new FinanceDBServiceImpl({
    ...config,
    jinaApiKey: config.jinaApiKey ?? (globalThis as typeof globalThis & { process?: { env?: Record<string, string | undefined> } }).process?.env?.JINA_API_KEY,
  });
  const runtimeCtx = ctx as Context & { tools: ToolRuntime; provide: (name: string, value: unknown) => () => void; effect: (body: () => () => void) => unknown };
  const provide = runtimeCtx.provide('finance.db', service);
  const disposeTools = registerFinanceTools(runtimeCtx.tools, service);
  runtimeCtx.effect(() => () => {
    disposeTools();
    provide();
  });
}, { inject: ['tools'] as string[] });

export default financePlugin;
