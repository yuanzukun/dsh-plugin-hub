/**
 * FinanceDB Service — the core service that exposes all finance capabilities.
 * Wires up the API client, cache, and provides the FinanceDBService interface.
 */

import type {
  FinanceDBService, FinanceDBConfig, StockQuote, OHLCV,
  StockFundamentals, NewsItem, SentimentScore, PredictionResult,
  SignalEvent, LogicChain, FinanceReport, SearchResult, MarketOverview,
} from './types.js';
import { APIClient } from './api-client.js';
import { FinanceCache, cacheKey } from './cache.js';

export class FinanceDBServiceImpl implements FinanceDBService {
  private api: APIClient;
  private cache: FinanceCache;

  constructor(private config: FinanceDBConfig = {}) {
    this.api = new APIClient({
      jinaApiKey: config.jinaApiKey,
      timeout: config.timeout ?? 15_000,
    });
    this.cache = new FinanceCache(config.cacheTtl ?? 60_000);
  }

  // ── Stock data ────────────────────────────────────────────────────

  async getQuote(symbol: string, market?: string): Promise<StockQuote> {
    const key = cacheKey.quote(symbol, market ?? this.config.defaultMarket);
    const cached = this.cache.get<StockQuote>(key);
    if (cached) return cached;

    const data = await this.api.getQuote(symbol, market ?? this.config.defaultMarket);
    this.cache.set(key, data, 30_000); // 30s for live quotes
    return data;
  }

  async getOHLCV(symbol: string, period: '1d' | '5d' | '1m' | '3m' | '6m' | '1y' | '5y', market?: string): Promise<OHLCV[]> {
    const key = cacheKey.ohlcv(symbol, period, market ?? this.config.defaultMarket);
    const cached = this.cache.get<OHLCV[]>(key);
    if (cached) return cached;

    const data = await this.api.getOHLCV(symbol, period, market ?? this.config.defaultMarket);
    this.cache.set(key, data, 5 * 60_000); // 5m for OHLCV
    return data;
  }

  async getFundamentals(symbol: string, market?: string): Promise<StockFundamentals> {
    const key = cacheKey.fundamentals(symbol, market ?? this.config.defaultMarket);
    const cached = this.cache.get<StockFundamentals>(key);
    if (cached) return cached;

    const data = await this.api.getFundamentals(symbol, market ?? this.config.defaultMarket);
    this.cache.set(key, data, 30 * 60_000); // 30m for fundamentals
    return data;
  }

  async searchStocks(query: string, market?: string): Promise<Array<{ symbol: string; name: string; market: string }>> {
    const key = cacheKey.searchStocks(query, market ?? this.config.defaultMarket);
    const cached = this.cache.get<Array<{ symbol: string; name: string; market: string }>>(key);
    if (cached) return cached;

    const data = await this.api.searchStocks(query, market ?? this.config.defaultMarket);
    this.cache.set(key, data, 10 * 60_000); // 10m for search results
    return data;
  }

  // ── News & sentiment ──────────────────────────────────────────────

  async getNews(symbol?: string, limit = 20, category?: string): Promise<NewsItem[]> {
    const key = cacheKey.news(symbol, limit, category);
    const cached = this.cache.get<NewsItem[]>(key);
    if (cached) return cached;

    const data = await this.api.getNews(symbol, limit, category);
    this.cache.set(key, data, 60_000); // 1m for news
    return data;
  }

  async getSentiment(text: string): Promise<SentimentScore> {
    const key = cacheKey.sentiment(text);
    const cached = this.cache.get<SentimentScore>(key);
    if (cached) return cached;

    const data = await this.api.getSentiment(text);
    this.cache.set(key, data, 60 * 60_000); // 1h for sentiment (stable)
    return data;
  }

  async getNewsSentiment(symbol: string, hours = 24): Promise<SentimentScore> {
    const key = cacheKey.newsSentiment(symbol, hours);
    const cached = this.cache.get<SentimentScore>(key);
    if (cached) return cached;

    const data = await this.api.getNewsSentiment(symbol, hours);
    this.cache.set(key, data, 5 * 60_000); // 5m for aggregated sentiment
    return data;
  }

  // ── Predictions ───────────────────────────────────────────────────

  async getPrediction(symbol: string, horizon: '1d' | '5d' | '20d' | '60d', useNews = false): Promise<PredictionResult> {
    const key = cacheKey.prediction(symbol, horizon, useNews);
    const cached = this.cache.get<PredictionResult>(key);
    if (cached) return cached;

    const data = await this.api.getPrediction(symbol, horizon, useNews);
    this.cache.set(key, data, 30 * 60_000); // 30m for predictions
    return data;
  }

  // ── Signals ───────────────────────────────────────────────────────

  async getSignals(symbol?: string, limit = 10): Promise<SignalEvent[]> {
    const key = cacheKey.signals(symbol, limit);
    const cached = this.cache.get<SignalEvent[]>(key);
    if (cached) return cached;

    const data = await this.api.getSignals(symbol, limit);
    this.cache.set(key, data, 2 * 60_000); // 2m for signals
    return data;
  }

  async trackSignal(signalId: string): Promise<SignalEvent | null> {
    return this.api.trackSignal(signalId);
  }

  // ── Logic visualization ───────────────────────────────────────────

  async getLogicChain(symbol: string, event?: string): Promise<LogicChain> {
    return this.api.getLogicChain(symbol, event);
  }

  async exportLogicChain(chain: LogicChain, format: 'drawio' | 'mermaid' | 'json'): Promise<string> {
    if (format === 'json') return JSON.stringify(chain, null, 2);

    if (format === 'mermaid') {
      return this.toMermaid(chain);
    }

    // drawio XML
    return this.toDrawio(chain);
  }

  private toMermaid(chain: LogicChain): string {
    const lines = ['graph TD'];
    for (const node of Object.values(chain.nodes)) {
      const shape = node.type === 'event' ? '([{{label}}])' :
        node.type === 'conclusion' ? '{{' + node.label + '}}' :
          `[${node.label}]`;
      lines.push(`  ${node.id}${shape}`);
      for (const child of node.children) {
        lines.push(`  ${node.id} --> ${child}`);
      }
    }
    return lines.join('\n');
  }

  private toDrawio(chain: LogicChain): string {
    const cells: string[] = [];
    let x = 0, y = 0;

    for (const node of Object.values(chain.nodes)) {
      const style = node.type === 'event' ? 'ellipse' :
        node.type === 'conclusion' ? 'rhombus' : 'rectangle';
      const w = Math.max(120, node.label.length * 8);
      cells.push(
        `<mxCell id="${node.id}" value="${this.xmlEscape(node.label)}" style="${style};whiteSpace=wrap;" vertex="1" parent="1">`,
        `  <mxGeometry x="${x}" y="${y}" width="${w}" height="40" as="geometry"/>`,
        `</mxCell>`
      );
      x += w + 40;

      for (const child of node.children) {
        cells.push(
          `<mxCell id="edge_${node.id}_${child}" style="edgeStyle=orthogonalEdgeStyle" edge="1" parent="1" source="${node.id}" target="${child}"/>`
        );
      }
    }

    return `<mxfile><diagram><mxGraphModel><root><mxCell id="0"/><mxCell id="1" parent="0"/>${cells.join('\n')}</root></mxGraphModel></diagram></mxfile>`;
  }

  private xmlEscape(s: string): string {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ── Reports ───────────────────────────────────────────────────────

  async generateReport(symbol: string, type: 'quick' | 'full' | 'earnings' | 'technical'): Promise<FinanceReport> {
    return this.api.generateReport(symbol, type);
  }

  // ── Search ────────────────────────────────────────────────────────

  async searchWeb(query: string, source: 'jina' | 'ddg' | 'baidu' = 'jina'): Promise<SearchResult> {
    return this.api.searchWeb(query, source);
  }

  async searchLocal(query: string, collection = 'default'): Promise<SearchResult> {
    return this.api.searchLocal(query, collection);
  }

  // ── Market overview ───────────────────────────────────────────────

  async getMarketOverview(): Promise<MarketOverview> {
    const key = cacheKey.marketOverview();
    const cached = this.cache.get<MarketOverview>(key);
    if (cached) return cached;

    const data = await this.api.getMarketOverview();
    this.cache.set(key, data, 60_000);
    return data;
  }

  // ── Health ────────────────────────────────────────────────────────

  async healthCheck(): Promise<{ status: 'ok' | 'degraded' | 'down'; services: Record<string, boolean> }> {
    const raw = await this.api.healthCheck();
    return {
      status: raw.status === 'ok' ? 'ok' : raw.status === 'degraded' ? 'degraded' : 'down',
      services: raw.services,
    };
  }

  // ── Cache management (exposed for tool use) ───────────────────────

  invalidateCache(pattern?: string): number {
    return this.cache.invalidate(pattern);
  }

  cacheStats(): { size: number; keys: string[] } {
    return this.cache.stats();
  }
}
