/**
 * In-memory TTL cache for finance API responses.
 * Avoids hammering external APIs for repeated queries within short windows.
 */

interface CacheEntry<T> {
  value: T;
  expiresAt: number;
}

export class FinanceCache {
  private store = new Map<string, CacheEntry<any>>();
  private defaultTtl: number;

  constructor(defaultTtlMs = 60_000) {
    this.defaultTtl = defaultTtlMs;
  }

  get<T>(key: string): T | undefined {
    const entry = this.store.get(key);
    if (!entry) return undefined;
    if (Date.now() > entry.expiresAt) {
      this.store.delete(key);
      return undefined;
    }
    return entry.value as T;
  }

  set<T>(key: string, value: T, ttlMs?: number): void {
    this.store.set(key, {
      value,
      expiresAt: Date.now() + (ttlMs ?? this.defaultTtl),
    });
  }

  has(key: string): boolean {
    return this.get(key) !== undefined;
  }

  invalidate(pattern?: string): number {
    if (!pattern) {
      const size = this.store.size;
      this.store.clear();
      return size;
    }
    let count = 0;
    for (const key of this.store.keys()) {
      if (key.includes(pattern)) {
        this.store.delete(key);
        count++;
      }
    }
    return count;
  }

  get size(): number {
    return this.store.size;
  }

  stats(): { size: number; keys: string[] } {
    // Clean expired entries
    const now = Date.now();
    for (const [key, entry] of this.store) {
      if (now > entry.expiresAt) this.store.delete(key);
    }
    return { size: this.store.size, keys: [...this.store.keys()] };
  }
}

// Cache key generators
export const cacheKey = {
  quote: (symbol: string, market?: string) => `quote:${market ?? 'global'}:${symbol}`,
  ohlcv: (symbol: string, period: string, market?: string) => `ohlcv:${market ?? 'global'}:${symbol}:${period}`,
  fundamentals: (symbol: string, market?: string) => `fund:${market ?? 'global'}:${symbol}`,
  searchStocks: (query: string, market?: string) => `search:${market ?? 'global'}:${query}`,
  news: (symbol: string | undefined, limit: number, category?: string) => `news:${symbol ?? 'all'}:${limit}:${category ?? 'all'}`,
  sentiment: (text: string) => `sentiment:${text.slice(0, 100)}`,
  newsSentiment: (symbol: string, hours: number) => `newsSent:${symbol}:${hours}`,
  prediction: (symbol: string, horizon: string, useNews: boolean) => `pred:${symbol}:${horizon}:${useNews}`,
  signals: (symbol: string | undefined, limit: number) => `signals:${symbol ?? 'all'}:${limit}`,
  marketOverview: () => 'market:overview',
} as const;
