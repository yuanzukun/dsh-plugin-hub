/** Direct adapters for the raw sources used by Awesome-finance-skills. */

import type {
  StockQuote, OHLCV, StockFundamentals, NewsItem, SentimentScore,
  SearchResult, MarketOverview,
} from './types.js';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

export interface APIClientConfig {
  jinaApiKey?: string;
  timeout: number;
}

export class FinanceProviderError extends Error {
  constructor(
    public readonly provider: string,
    message: string,
    public readonly cause?: unknown,
  ) {
    super(`${provider}: ${message}`);
    this.name = 'FinanceProviderError';
  }
}

const EASTMONEY_LIST_URL = 'https://push2.eastmoney.com/api/qt/clist/get';
const EASTMONEY_KLINE_URL = 'https://push2his.eastmoney.com/api/qt/stock/kline/get';
const YAHOO_CHART_URL = 'https://query1.finance.yahoo.com/v8/finance/chart';
const NEWSNOW_URL = 'https://newsnow.busiyi.world/api/s';
const JINA_SEARCH_URL = 'https://s.jina.ai/';
const EASTMONEY_TOKEN = 'fa5fd1943c7b386f172d6893dbfba10b';

type EastMoneyItem = Record<string, number | string | null | undefined>;

export class APIClient {
  private config: APIClientConfig;

  constructor(config: Partial<APIClientConfig> = {}) {
    this.config = { jinaApiKey: config.jinaApiKey, timeout: config.timeout ?? 15_000 };
  }

  private async json<T>(url: string, provider: string, init: RequestInit = {}): Promise<T> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.config.timeout);
    try {
      const response = await fetch(url, {
        ...init,
        signal: controller.signal,
        headers: { Accept: 'application/json', 'User-Agent': 'dsh-finance-db/0.1.0', ...init.headers },
      });
      const body = await response.text();
      if (!response.ok) throw new FinanceProviderError(provider, `HTTP ${response.status}: ${body.slice(0, 180)}`);
      try {
        return JSON.parse(body) as T;
      } catch (error) {
        throw new FinanceProviderError(provider, `returned non-JSON data: ${body.slice(0, 180)}`, error);
      }
    } catch (error) {
      if (error instanceof FinanceProviderError) throw error;
      const detail = error instanceof Error ? error.message : String(error);
      if (detail.toLowerCase().includes('abort')) throw new FinanceProviderError(provider, `request timed out after ${this.config.timeout}ms`, error);
      if (provider === 'EastMoney') {
        try {
          const { stdout } = await execFileAsync('curl', [
            '--silent', '--show-error', '--ipv4', '--max-time', String(Math.ceil(this.config.timeout / 1000)),
            '-A', 'dsh-finance-db/0.1.0', url,
          ], { timeout: this.config.timeout + 1000, maxBuffer: 4 * 1024 * 1024 });
          return JSON.parse(stdout) as T;
        } catch (fallbackError) {
          const fallbackDetail = fallbackError instanceof Error ? fallbackError.message : String(fallbackError);
          throw new FinanceProviderError(provider, `fetch failed (${detail}); curl fallback failed (${fallbackDetail})`, fallbackError);
        }
      }
      throw new FinanceProviderError(provider, `network request failed: ${detail}`, error);
    } finally {
      clearTimeout(timer);
    }
  }

  private marketFor(symbol: string, market?: string): 'A' | 'HK' | 'US' {
    const normalized = (market ?? '').toUpperCase();
    if (normalized === 'A' || normalized === 'HK' || normalized === 'US') return normalized;
    if (/^[A-Z][A-Z0-9.-]*$/i.test(symbol)) return 'US';
    if (/^\d{5}$/.test(symbol.replace(/\D/g, ''))) return 'HK';
    return 'A';
  }

  private cleanSymbol(symbol: string): string {
    return symbol.trim().replace(/\.(SZ|SH|HK|US)$/i, '').toUpperCase();
  }

  private secid(symbol: string, market?: string): string {
    const clean = this.cleanSymbol(symbol).replace(/\D/g, '');
    if (this.marketFor(symbol, market) === 'HK') return `116.${clean}`;
    return clean.startsWith('6') || clean.startsWith('9') ? `1.${clean}` : `0.${clean}`;
  }

  private eastMoneyFilter(market: 'A' | 'HK'): string {
    return market === 'HK' ? 'm:128+t:3,m:128+t:4,m:128+t:1,m:128+t:2' : 'm:0+t:6,m:0+t:80,m:1+t:2,m:1+t:23';
  }

  private async eastMoneyList(market: 'A' | 'HK', pageSize = 5000): Promise<EastMoneyItem[]> {
    const params = new URLSearchParams({
      pn: '1', pz: String(pageSize), po: '1', np: '1', fltt: '2', invt: '2', fid: 'f12',
      fs: this.eastMoneyFilter(market),
      fields: 'f2,f3,f4,f5,f6,f9,f12,f14,f15,f16,f17,f18,f20,f21,f23,f26,f100', ut: EASTMONEY_TOKEN,
    });
    const payload = await this.json<{ data?: { diff?: EastMoneyItem[] } }>(`${EASTMONEY_LIST_URL}?${params}`, 'EastMoney');
    return payload.data?.diff ?? [];
  }

  private toNumber(value: unknown): number | undefined {
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string' && value.trim() !== '') {
      const parsed = Number(value.replace(/,/g, ''));
      return Number.isFinite(parsed) ? parsed : undefined;
    }
    return undefined;
  }

  private async eastMoneyItem(symbol: string, market?: string): Promise<EastMoneyItem> {
    const resolved = this.marketFor(symbol, market);
    if (resolved === 'US') throw new FinanceProviderError('stock', `EastMoney does not provide US ticker ${symbol}`);
    const clean = this.cleanSymbol(symbol).replace(/\D/g, '');
    const item = (await this.eastMoneyList(resolved)).find((candidate) => String(candidate.f12 ?? '') === clean);
    if (!item) throw new FinanceProviderError('EastMoney', `ticker ${symbol} was not found in the ${resolved} list`);
    return item;
  }

  private async eastMoneyQuote(symbol: string, market?: string): Promise<EastMoneyItem> {
    const params = new URLSearchParams({
      invt: '2', fltt: '2', secid: this.secid(symbol, market),
      fields: 'f43,f47,f48,f57,f58,f162,f167,f169,f170,f20,f21',
    });
    const payload = await this.json<{ data?: EastMoneyItem }>(
      `https://push2.eastmoney.com/api/qt/stock/get?${params}`, 'EastMoney',
    );
    if (!payload.data?.f57) throw new FinanceProviderError('EastMoney', `ticker ${symbol} was not found`);
    return payload.data;
  }

  async getQuote(symbol: string, market?: string): Promise<StockQuote> {
    const resolved = this.marketFor(symbol, market);
    if (resolved === 'US') {
      const chart = await this.yahooChart(this.cleanSymbol(symbol), '5d', '1d');
      const meta = chart.chart.result?.[0]?.meta;
      const quote = chart.chart.result?.[0]?.indicators?.quote?.[0];
      const closes = quote?.close?.filter((value: unknown): value is number => typeof value === 'number') ?? [];
      const price = meta?.regularMarketPrice ?? closes.at(-1);
      if (price === undefined) throw new FinanceProviderError('Yahoo Finance', `no quote returned for ${symbol}`);
      const previous = meta?.previousClose ?? closes.at(-2) ?? price;
      const change = price - previous;
      return {
        symbol: this.cleanSymbol(symbol), name: meta?.longName ?? meta?.shortName ?? this.cleanSymbol(symbol), price,
        change, changePercent: previous ? change / previous * 100 : 0,
        volume: quote?.volume?.filter((value: unknown): value is number => typeof value === 'number').at(-1) ?? 0,
        timestamp: Date.now(),
      };
    }
    const item = await this.eastMoneyQuote(symbol, resolved);
    const price = this.toNumber(item.f43) ?? 0;
    return {
      symbol: String(item.f57 ?? this.cleanSymbol(symbol)), name: String(item.f58 ?? symbol), price,
      change: this.toNumber(item.f169) ?? 0, changePercent: this.toNumber(item.f170) ?? 0,
      volume: this.toNumber(item.f47) ?? 0, marketCap: this.toNumber(item.f20), peRatio: this.toNumber(item.f162), timestamp: Date.now(),
    };
  }

  private periodDates(period: string): { start: string; end: string } {
    const days: Record<string, number> = { '1d': 3, '5d': 9, '1m': 35, '3m': 100, '6m': 200, '1y': 400, '5y': 2200 };
    const end = new Date();
    const start = new Date(end.getTime() - (days[period] ?? 100) * 86_400_000);
    const fmt = (date: Date) => date.toISOString().slice(0, 10).replaceAll('-', '');
    return { start: fmt(start), end: fmt(end) };
  }

  private async eastMoneyKline(symbol: string, period: string, market?: string): Promise<OHLCV[]> {
    const dates = this.periodDates(period);
    const params = new URLSearchParams({
      secid: this.secid(symbol, market), fields1: 'f1,f2,f3,f4,f5,f6', fields2: 'f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61',
      klt: '101', fqt: '1', beg: dates.start, end: dates.end, lmt: '5000', ut: EASTMONEY_TOKEN,
    });
    const payload = await this.json<{ data?: { klines?: string[] } }>(`${EASTMONEY_KLINE_URL}?${params}`, 'EastMoney');
    return (payload.data?.klines ?? []).map((line) => {
      const [date, open, close, high, low, volume] = line.split(',');
      return { timestamp: Date.parse(`${date}T00:00:00Z`), open: Number(open), high: Number(high), low: Number(low), close: Number(close), volume: Number(volume) };
    }).filter((item) => Number.isFinite(item.timestamp) && Number.isFinite(item.close));
  }

  private async yahooChart(symbol: string, range: string, interval: string): Promise<any> {
    const params = new URLSearchParams({ range, interval, events: 'history', includePrePost: 'false' });
    return this.json(`${YAHOO_CHART_URL}/${encodeURIComponent(symbol)}?${params}`, 'Yahoo Finance');
  }

  async getOHLCV(symbol: string, period: '1d' | '5d' | '1m' | '3m' | '6m' | '1y' | '5y', market?: string): Promise<OHLCV[]> {
    const resolved = this.marketFor(symbol, market);
    if (resolved !== 'US') {
      try {
        return await this.eastMoneyKline(symbol, period, market);
      } catch (error) {
        const clean = this.cleanSymbol(symbol);
        const yahooSymbol = resolved === 'HK' ? `${clean}.HK` : `${clean}.${clean.startsWith('6') || clean.startsWith('9') ? 'SS' : 'SZ'}`;
        try {
          return await this.yahooOHLCV(yahooSymbol, period);
        } catch {
          throw error;
        }
      }
    }
    return this.yahooOHLCV(this.cleanSymbol(symbol), period);
  }

  private async yahooOHLCV(symbol: string, period: string): Promise<OHLCV[]> {
    const payload = await this.yahooChart(symbol, period === '1d' ? '5d' : period, '1d');
    const result = payload.chart.result?.[0];
    const timestamps: number[] = result?.timestamp ?? [];
    const quote = result?.indicators?.quote?.[0] ?? {};
    return timestamps.map((timestamp, index) => ({ timestamp: timestamp * 1000, open: quote.open?.[index] ?? 0, high: quote.high?.[index] ?? 0, low: quote.low?.[index] ?? 0, close: quote.close?.[index] ?? 0, volume: quote.volume?.[index] ?? 0 })).filter((item: OHLCV) => Number.isFinite(item.close));
  }

  async getFundamentals(symbol: string, market?: string): Promise<StockFundamentals> {
    const quote = await this.getQuote(symbol, market);
    return {
      symbol: quote.symbol, name: quote.name, marketCap: quote.marketCap, peRatio: quote.peRatio,
      pbRatio: undefined, dividendYield: undefined, eps: undefined, revenue: undefined, netIncome: undefined,
      totalAssets: undefined, totalDebt: undefined, roe: undefined, roa: undefined,
      source: this.marketFor(symbol, market) === 'US' ? 'Yahoo Finance chart' : 'EastMoney quote list',
    };
  }

  async searchStocks(query: string, market?: string): Promise<Array<{ symbol: string; name: string; market: string }>> {
    const resolved = this.marketFor(query, market);
    if (resolved === 'US') {
      const symbol = this.cleanSymbol(query);
      return [{ symbol, name: symbol, market: 'US' }];
    }
    const needle = query.trim().toLowerCase();
    if (/^\d{5,6}$/.test(needle)) {
      try {
        const quote = await this.getQuote(needle, resolved);
        return [{ symbol: quote.symbol, name: quote.name, market: resolved }];
      } catch {
        // Continue with the cached/list endpoint for unusual codes.
      }
    }
    return (await this.eastMoneyList(resolved)).filter((item) => String(item.f12 ?? '').toLowerCase().includes(needle) || String(item.f14 ?? '').toLowerCase().includes(needle)).slice(0, 20).map((item) => ({ symbol: String(item.f12 ?? ''), name: String(item.f14 ?? ''), market: resolved }));
  }

  async getNews(symbol?: string, limit = 20, _category?: string): Promise<NewsItem[]> {
    const source = symbol ? 'cls' : 'wallstreetcn';
    const payload = await this.json<{ items?: Array<Record<string, unknown>> }>(`${NEWSNOW_URL}?${new URLSearchParams({ id: source })}`, 'NewsNow');
    return (payload.items ?? []).slice(0, limit).map((item, index) => ({
      id: String(item.id ?? `${source}-${index}`), title: String(item.title ?? ''), summary: String(item.description ?? item.title ?? ''), source,
      url: String(item.url ?? ''), publishedAt: Date.parse(String(item.publish_time ?? '')) || Date.now(), symbols: symbol ? [symbol] : undefined, category: 'news',
    }));
  }

  async getSentiment(_text: string): Promise<SentimentScore> {
    throw new FinanceProviderError('sentiment', 'the original skill uses optional local BERT or agent-side LLM analysis; no remote sentiment API is configured');
  }

  async getNewsSentiment(_symbol: string, _hours = 24): Promise<SentimentScore> {
    throw new FinanceProviderError('sentiment', 'news sentiment is computed after news retrieval by local/agent analysis; no remote API is configured');
  }

  async getMarketOverview(): Promise<MarketOverview> {
    const params = new URLSearchParams({ fltt: '2', invt: '2', fields: 'f2,f3,f4,f12,f14', secids: '1.000001,0.399001,116.00700', ut: EASTMONEY_TOKEN });
    const payload = await this.json<{ data?: { diff?: EastMoneyItem[] } }>(`https://push2.eastmoney.com/api/qt/ulist/get?${params}`, 'EastMoney');
    const indices = (payload.data?.diff ?? []).map((item) => ({ symbol: String(item.f12 ?? ''), name: String(item.f14 ?? ''), price: this.toNumber(item.f2) ?? 0, change: this.toNumber(item.f4) ?? 0, changePercent: this.toNumber(item.f3) ?? 0 }));
    return { indices, sectors: [], newsCount: 0, timestamp: Date.now() };
  }

  async searchWeb(query: string, source: 'jina' | 'ddg' | 'baidu' = 'jina'): Promise<SearchResult> {
    if (source !== 'jina' || !this.config.jinaApiKey) throw new FinanceProviderError('search', 'only Jina direct search is supported; configure JINA_API_KEY');
    const payload = await this.json<unknown>(`${JINA_SEARCH_URL}${encodeURIComponent(query)}`, 'Jina Search', { headers: { Authorization: `Bearer ${this.config.jinaApiKey}` } });
    const items = Array.isArray(payload) ? payload : (payload as { data?: unknown[] })?.data ?? [];
    return { query, results: items.slice(0, 10).map((item: any, index) => ({ title: String(item?.title ?? `Result ${index + 1}`), url: String(item?.url ?? ''), snippet: String(item?.content ?? item?.description ?? ''), source: 'jina', relevance: 1 - index / 10 })), timestamp: Date.now() };
  }

  async searchLocal(_query: string, _collection = 'default'): Promise<SearchResult> {
    throw new FinanceProviderError('local search', 'local SQLite/news search has not been mounted in the Node host plugin yet');
  }

  async getPrediction(_symbol: string, _horizon: string, _useNews = false): Promise<never> {
    throw new FinanceProviderError('prediction', 'the original project runs Kronos locally; no remote prediction API is configured');
  }

  async getSignals(_symbol?: string, _limit = 10): Promise<never> {
    throw new FinanceProviderError('signals', 'signal tracking is implemented by the original local agent workflow, not a remote API');
  }

  async trackSignal(_signalId: string): Promise<null> {
    return null;
  }

  async getLogicChain(_symbol: string, _event?: string): Promise<never> {
    throw new FinanceProviderError('logic visualizer', 'logic-chain generation is a local prompt workflow, not a remote API');
  }

  async generateReport(_symbol: string, _type: string): Promise<never> {
    throw new FinanceProviderError('reporter', 'report generation is a local agent workflow, not a remote API');
  }

  async healthCheck(): Promise<{ status: 'ok' | 'degraded' | 'down'; services: Record<string, boolean> }> {
    return { status: 'degraded', services: { eastmoney: true, yahooFinance: true, newsNow: true, localSentiment: false } };
  }
}
