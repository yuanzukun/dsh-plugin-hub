import { defineTool, type ToolDefinition, type ToolRuntime } from '@deepseek-ai/dsh-tools';
import type { FinanceDBService } from './types.js';

type Json = { type: 'json' };

const jsonOutput: any = {
  schema: { type: 'json' } satisfies Json,
  render: (_args: unknown, value: unknown) => [{ type: 'text', text: JSON.stringify(value) }],
};

/**
 * DSH validates the canonical tool result before the renderer runs. Normalize
 * service responses at that boundary so optional fields containing undefined
 * cannot make the result fail lossless-JSON validation.
 */
export function toLosslessJson<T>(value: T): any {
  const serialized = JSON.stringify(value);
  if (serialized === undefined) throw new Error('Tool result must be a JSON value.');
  return JSON.parse(serialized);
}

const textParam = (description: string, required = true): any => ({ type: 'string', description, ...(required ? { required: true as const } : {}) });
const integerParam = (description: string): any => ({ type: 'integer', description });

export function financeTools(service: FinanceDBService): ToolDefinition[] {
  return [
    defineTool({
      name: 'finance_quote',
      description: 'Get a current stock quote. Always state the market and timestamp when presenting the result.',
      parameters: { symbol: textParam('Ticker, company name, or market-specific identifier.'), market: textParam('Market: A, HK, US, or global.', false) },
      output: jsonOutput,
      execute: async (args: any) => toLosslessJson(await service.getQuote(args.symbol, args.market)),
    } as any),
    defineTool({
      name: 'finance_ohlcv',
      description: 'Get historical OHLCV price data for a stock over a bounded period.',
      parameters: { symbol: textParam('Ticker or market-specific identifier.'), period: { type: 'string', enum: ['1d', '5d', '1m', '3m', '6m', '1y', '5y'] as const, description: 'Lookback period.', required: true }, market: textParam('Market: A, HK, US, or global.', false) },
      output: { schema: { type: 'array', items: { type: 'json' } }, render: (_args: any, value: any) => [{ type: 'text', text: JSON.stringify(value) }] },
      execute: async (args: any) => toLosslessJson(await service.getOHLCV(args.symbol, args.period, args.market)),
    } as any),
    defineTool({
      name: 'finance_fundamentals',
      description: 'Get company fundamentals such as valuation, profitability, revenue, assets, and debt.',
      parameters: { symbol: textParam('Ticker or market-specific identifier.'), market: textParam('Market: A, HK, US, or global.', false) },
      output: jsonOutput,
      execute: async (args: any) => toLosslessJson(await service.getFundamentals(args.symbol, args.market)),
    } as any),
    defineTool({
      name: 'finance_news',
      description: 'Fetch recent finance news, optionally filtered by symbol and category.',
      parameters: { symbol: textParam('Optional ticker filter.', false), limit: integerParam('Maximum number of items, preferably 1-50.'), category: textParam('news, announcement, research, or social.', false) },
      output: { schema: { type: 'array', items: { type: 'json' } }, render: (_args: any, value: any) => [{ type: 'text', text: JSON.stringify(value) }] },
      execute: async (args: any) => toLosslessJson(await service.getNews(args.symbol, args.limit ?? 20, args.category)),
    } as any),
    defineTool({
      name: 'finance_sentiment',
      description: 'Score the sentiment of a finance-related text or a symbol recent-news aggregate.',
      parameters: { text: textParam('Text to score.', false), symbol: textParam('Ticker for recent-news sentiment.', false), hours: integerParam('News lookback window in hours.') },
      output: jsonOutput,
      execute: async (args: any) => {
        if (args.text) return toLosslessJson(await service.getSentiment(args.text));
        if (args.symbol) return toLosslessJson(await service.getNewsSentiment(args.symbol, args.hours ?? 24));
        throw new Error('Provide either text or symbol.');
      },
    } as any),
    defineTool({
      name: 'finance_search_stocks',
      description: 'Search stocks by ticker, company name, or market.',
      parameters: { query: textParam('Search query.'), market: textParam('Market: A, HK, US, or global.', false) },
      output: { schema: { type: 'array', items: { type: 'json' } }, render: (_args: any, value: any) => [{ type: 'text', text: JSON.stringify(value) }] },
      execute: async (args: any) => toLosslessJson(await service.searchStocks(args.query, args.market)),
    } as any),
    defineTool({
      name: 'finance_market_overview',
      description: 'Get a broad market overview including indices, sectors, and news count.',
      parameters: {},
      output: jsonOutput,
      execute: async () => toLosslessJson(await service.getMarketOverview()),
    } as any),
    defineTool({
      name: 'finance_health',
      description: 'Check availability of the configured finance data backend.',
      parameters: {},
      output: jsonOutput,
      execute: async () => toLosslessJson(await service.healthCheck()),
    } as any),
  ];
}

export function registerFinanceTools(runtime: ToolRuntime, service: FinanceDBService): () => void {
  const disposers = financeTools(service).map((tool) => runtime.register(tool));
  return () => disposers.reverse().forEach((dispose) => dispose());
}
