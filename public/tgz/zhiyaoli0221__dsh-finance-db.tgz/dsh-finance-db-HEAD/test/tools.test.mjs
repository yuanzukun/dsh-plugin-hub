import test from 'node:test';
import assert from 'node:assert/strict';
import { financeTools, toLosslessJson } from '../lib/tools.js';

test('finance tool catalog is read-only and complete', () => {
  const service = {};
  const names = financeTools(service).map((tool) => tool.name);
  assert.deepEqual(names, [
    'finance_quote', 'finance_ohlcv', 'finance_fundamentals', 'finance_news',
    'finance_sentiment', 'finance_search_stocks', 'finance_market_overview', 'finance_health',
  ]);
});

test('tool results are lossless JSON before DSH validation', () => {
  assert.deepEqual(toLosslessJson({ price: 123.45, marketCap: undefined }), { price: 123.45 });
  assert.deepEqual(toLosslessJson([{ value: Number.NaN }]), [{ value: null }]);
});

test('finance_quote removes undefined optional fields at the tool boundary', async () => {
  const quoteTool = financeTools({
    getQuote: async () => ({ symbol: '600519', price: 123.45, marketCap: undefined }),
  })[0];

  assert.deepEqual(await quoteTool.execute({ symbol: '600519' }), { symbol: '600519', price: 123.45 });
});
