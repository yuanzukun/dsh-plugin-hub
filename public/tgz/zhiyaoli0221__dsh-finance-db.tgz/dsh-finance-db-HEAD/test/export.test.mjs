import test from 'node:test';
import assert from 'node:assert/strict';
import { FinanceDBServiceImpl } from '../lib/service.js';

test('logic chain exporters produce safe deterministic output', async () => {
  const service = new FinanceDBServiceImpl();
  const chain = { rootId: 'root', nodes: { root: { id: 'root', type: 'event', label: '<earnings>', description: '', confidence: 1, children: ['end'] }, end: { id: 'end', type: 'conclusion', label: 'hold', description: '', confidence: 0.8, children: [] } }, metadata: { symbol: 'AAPL', generatedAt: 1, model: 'test' } };
  const mermaid = await service.exportLogicChain(chain, 'mermaid');
  const drawio = await service.exportLogicChain(chain, 'drawio');
  assert.match(mermaid, /root --> end/);
  assert.match(drawio, /&lt;earnings&gt;/);
});
