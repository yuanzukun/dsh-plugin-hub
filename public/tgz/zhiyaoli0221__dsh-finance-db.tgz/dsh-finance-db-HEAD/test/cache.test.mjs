import test from 'node:test';
import assert from 'node:assert/strict';
import { FinanceCache } from '../lib/cache.js';

test('FinanceCache stores, expires, and invalidates values', async () => {
  const cache = new FinanceCache(20);
  cache.set('quote:US:AAPL', { price: 1 });
  assert.deepEqual(cache.get('quote:US:AAPL'), { price: 1 });
  assert.equal(cache.invalidate('quote:'), 1);
  assert.equal(cache.get('quote:US:AAPL'), undefined);
  cache.set('short', 1, 1);
  await new Promise((resolve) => setTimeout(resolve, 5));
  assert.equal(cache.get('short'), undefined);
});
