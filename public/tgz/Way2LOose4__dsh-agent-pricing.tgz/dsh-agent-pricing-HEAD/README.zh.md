# dsh-agent-pricing

> [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) 的**实时会话成本预览**：输入框下方的成本读数、今日用量图表悬浮窗、`price_estimate` / `session_cost` 两个 Agent 工具——**价格与 DeepSeek 官网价格页实时对齐**（支持峰谷定价）。

[English](README.md) | [中文](README.zh.md)

[![dsh-plugin](https://img.shields.io/badge/dsh--plugin-%E2%9C%93-5B4CF0?style=flat-square)](https://github.com/topics/dsh-plugin)
[![DeepSeek Harness](https://img.shields.io/badge/DeepSeek%20Harness-生态插件-4D6BFE?logo=deepseek&logoColor=white)](https://github.com/deepseek-ai/deepseek-harness)
[![GitHub stars](https://img.shields.io/github/stars/Way2LOose4/dsh-agent-pricing?logo=github)](https://github.com/Way2LOose4/dsh-agent-pricing/stargazers)
[![License](https://img.shields.io/github/license/Way2LOose4/dsh-agent-pricing)](LICENSE)
[![Last commit](https://img.shields.io/github/last-commit/Way2LOose4/dsh-agent-pricing)](https://github.com/Way2LOose4/dsh-agent-pricing/commits/main)

---

## 功能

- **输入框下方成本读数**：当前会话的累计成本，每 5 秒刷新，CNY ⇄ USD 一键切换——这就是你边用边看的「大致余额消耗」。
- **今日用量悬浮窗**：今日输入/输出/缓存 tokens、按小时柱状图、按模型分解；同时显示本次计价**来自哪一层价表来源**、最近核验时间，峰谷计费生效后还会标注当前处于**峰段**还是**谷段**。
- **Agent 工具**：`price_estimate`（单次调用估价）、`session_cost`（会话完整用量，与 Web 统计条同源）——Agent 可以在任务中途自己报账。
- **价格实时对齐官网**：激活时及此后每 30 分钟抓取一次 [DeepSeek 官网价格页](https://api-docs.deepseek.com/quick_start/pricing)（当前生效价 **+ 已公告的峰谷价及其生效时间**）；抓取失败逐级回退，断网不影响计价。

```
工作区 agent-pricing.json   (1) 用户覆盖，优先级最高
        ↓ 不存在
官网价格页抓取               (2) DeepSeek 各行（含已公告峰谷档）
        ↓ 挂掉 / 结构变化
本仓库 prices.json          (3) 在 GitHub 上改价表 → 所有安装端
        ↓ 挂掉                 30 分钟内自取，无需重装
内置价表                    (4) 离线兜底，自带已公告峰谷档
```

DeepSeek 峰谷计费（公告 **2026-08-16 16:00 UTC 生效**，峰时为 UTC 01:00–04:00 与 06:00–10:00）按**每条用量事件自身的时间戳**计价：切换前的用量仍按平价，峰时调用自动按峰价。

---

## 安装

运行环境：DeepSeek Harness（Web profile），已在 `0.1.0-rc.6` 验证。

### 方式一：DSH 插件市场（推荐）

1. 还没有市场插件的话，先装 **dsh-plugin-marketplace**（[仓库与一行安装脚本](https://github.com/bradeGithub/DSH-Plugins-Marketplace)）。
2. 打开 **设置 → DSH插件市场**，搜索 `dsh-agent-pricing`，点 **安装**。
3. **重启 DSH**（重新运行 `dsh web`），刷新页面。

### 方式二：dsh CLI（pnpm 直接吃 GitHub 地址）

```sh
dsh plugin --profile web add github:Way2LOose4/dsh-agent-pricing
# 然后重启 Web profile。
```

### 方式三：手动

克隆到 `%DSH_HOME%/profiles/web/node_modules/dsh-agent-pricing`，并向 `%DSH_HOME%/profiles/web/cordis.patch.yml` 追加：

```yaml
- insert:
    - id: agent-pricing
      name: dsh-agent-pricing
```

重启 DSH。Web profile 关闭了 HMR——改代码必须重启才生效。

---

## 使用

1. 打开任意会话，输入框下方会出现一行紧凑的成本读数；
2. 点 **CNY/USD** 切币种，点 **▸ 图表** 展开今日用量悬浮窗；
3. 直接问 Agent「这轮花了多少钱」——它会自己调 `session_cost` 回答，也能用 `price_estimate` 报预估价。

## 配置（可选）

在工作区根目录放一份 `agent-pricing.json` 即可整体覆盖价表，格式与本仓库 [`prices.json`](prices.json) 一致：

```json
{ "models": [{ "keys": ["my-model"], "label": "我的模型", "input": 1.0, "output": 2.0 }] }
```

可选行字段：`cacheRead`、`cacheWrite`，以及 `tiers`（`{ "effectiveAt", "peakHoursUtc", "peak": {...}, "offPeak": {...} }`）。激活时与每次周期刷新都会重读。匹配不到价目行的模型按 0 计，并在结果的 `note` 里列出。

## HTTP 接口与工具

| 接口 | 方法 | 说明 |
|---|---|---|
| `/api/pricing/session-cost?sessionId=…&currency=CNY` | GET | 会话完整用量与成本 |
| `/api/pricing/today?currency=CNY` | GET | 今日 tokens/成本 + 逐小时序列 + 价表来源 |
| `/api/pricing/estimate?model=…&input_tokens=…&output_tokens=…` | GET | 单次调用估价 |
| `/api/pricing/debug` | GET | 价表分层、同步状态、峰谷行 |
| `/api/pricing/reload` | 任意 | 强制刷新价表 |

注册的模型工具：`price_estimate`、`session_cost`。

## 价格维护

DeepSeek 各行会自动跟官网对齐。其余厂商的价：编辑本仓库的 [`prices.json`](prices.json)，所有安装端每 30 分钟自动拉取。本地工作区存在 `agent-pricing.json` 时仍以它为准。

## 仓库结构

```
├─ package.json        bundle 清单（dsh.client + dsh.bundle.patch）
├─ cordis.patch.yml    profile 挂载行
├─ prices.json         仓库托管价表（安装端自动拉取）
├─ lib/
│  ├─ index.js         宿主：路由、工具、价表分层、官网页解析器
│  └─ client.js        浏览器：成本读数 + 今日用量悬浮窗
├─ test.mjs            官网页解析 + 计价逻辑（峰谷、CNY/USD）
└─ test-refresh.mjs    价表分层优先级：文件 > 官网 > 仓库 > 内置
```

用一份本地保存的官网价格页跑测试：

```sh
node test.mjs official-pricing.html
node test-refresh.mjs official-pricing.html
```

## 限制与安全说明

- 所有数字都是**估算**：镜像官网公开价目，不含你账户的协议价或剩余额度。DeepSeek 有真实的 `/user/balance` 接口；本插件刻意只读公开数据，不需要任何 API Key。
- 成本算自本地会话日志；除「官网价格页」和「本仓库 raw `prices.json`」两张价表请求外，没有任何数据离开你的机器。
- 只安装你信任的插件——插件包会注册进 Web profile 并随 DSH 每次启动加载。

## 兼容性

| DSH 版本 | 状态 |
|---|---|
| 0.1.0-rc.6 | ✅ 已验证 |

## 许可

MIT — 见 [LICENSE](LICENSE)。
