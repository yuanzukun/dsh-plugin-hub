// Integration test: price-layer precedence inside refreshPrices
// (workspace file > official scrape > repo remote > builtin).
// Usage: node test-refresh.mjs <official.html> <workspace-with-file> <workspace-empty>
import { readFileSync, mkdtempSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { _refreshPricesForTest as refresh, _tableForTest as TABLE } from './lib/index.js'

// Isolate from the real DSH_HOME: candidateWorkspaceRoots falls back to the
// durable workspace registry (~storages/workspace.json), which points at the
// real workspace during manual runs and would outrank every mocked layer.
const fakeHome = mkdtempSync(join(tmpdir(), 'dsh-home-'))
process.env.DSH_HOME = fakeHome

const officialHtml = readFileSync(process.argv[2], 'utf8')
const remotePrices = readFileSync(new URL('./prices.json', import.meta.url), 'utf8')

const realFetch = globalThis.fetch
globalThis.fetch = async (url) => {
  const u = String(url)
  if (u.includes('api-docs.deepseek.com')) return { ok: true, text: async () => officialHtml }
  if (u.includes('raw.githubusercontent.com')) return { ok: true, text: async () => remotePrices }
  return realFetch(url)
}

let failures = 0
function ok(name, cond, extra) {
  if (!cond) { failures++; console.error('FAIL', name, extra ?? '') }
  else console.log('ok  ', name)
}
function findRow(keyPrefix) {
  return TABLE.find((r) => r.keys[0].startsWith(keyPrefix))
}
function ctxFor(root) {
  return {
    get: (name) => (name === 'sandboxPolicy' ? { workspaceRoot: root } : undefined),
    logger: { info: () => {} }
  }
}

// ── Case 1: workspace has agent-pricing.json → file wins over all ──
const fileRoot = mkdtempSync(join(tmpdir(), 'pricing-file-'))
writeFileSync(join(fileRoot, 'agent-pricing.json'), JSON.stringify({
  models: [{ keys: ['deepseek-v4-flash'], label: 'OVERRIDDEN', input: 9.99, output: 8.88 }]
}))
await refresh(ctxFor(fileRoot))
ok('file wins: single-row table', TABLE.length === 1, JSON.stringify(TABLE))
ok('file wins: overridden row', findRow('deepseek-v4-flash').label === 'OVERRIDDEN')

// ── Case 2: no workspace file → official scrape wins for deepseek rows ──
const emptyRoot = mkdtempSync(join(tmpdir(), 'pricing-empty-'))
await refresh(ctxFor(emptyRoot))
const flash = findRow('deepseek-v4-flash')
ok('official wins: flash flat input', flash.input === 0.14, JSON.stringify(flash))
ok('official tiers carried', flash.tiers && flash.tiers.peak.input === 0.44)
ok('non-deepseek rows survive (kimi)', !!findRow('kimi-k3'))
ok('table size reasonable', TABLE.length >= 25, String(TABLE.length))

// ── Case 3: broken official page → fallback chain intact ──
globalThis.fetch = async (url) => {
  const u = String(url)
  if (u.includes('api-docs.deepseek.com')) return { ok: true, text: async () => '<html>garbage</html>' }
  if (u.includes('raw.githubusercontent.com')) return { ok: true, text: async () => remotePrices }
  return realFetch(url)
}
await refresh(ctxFor(emptyRoot))
const flashAfter = findRow('deepseek-v4-flash')
ok('broken official → remote layer supplies tiers', flashAfter.tiers && flashAfter.tiers.peak.input === 0.44, JSON.stringify(flashAfter))

console.log(failures === 0 ? '\nALL PASS' : '\n' + failures + ' FAILURES')
process.exit(failures === 0 ? 0 : 1)
