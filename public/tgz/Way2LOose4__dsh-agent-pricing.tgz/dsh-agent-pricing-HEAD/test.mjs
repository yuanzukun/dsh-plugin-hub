// Self-test for dsh-agent-pricing: official-page parser + tier-aware pricing math.
// Usage: node test.mjs <path-to-official-pricing.html>
import { readFileSync } from 'node:fs'
import { parseOfficialPricing, rateOf, costFor } from './lib/index.js'

const html = readFileSync(process.argv[2], 'utf8')
let failures = 0
function eq(name, got, want) {
  const norm = (v) => {
    if (Array.isArray(v)) return v.map(norm)
    if (v && typeof v === 'object') {
      return Object.fromEntries(Object.keys(v).sort().map((k) => [k, norm(v[k])]))
    }
    return v
  }
  const ok = JSON.stringify(norm(got)) === JSON.stringify(norm(want))
  if (!ok) { failures++; console.error('FAIL', name, 'got', JSON.stringify(got), 'want', JSON.stringify(want)) }
  else console.log('ok  ', name)
}

const parsed = parseOfficialPricing(html)
if (!parsed) { console.error('FAIL parse returned null'); process.exit(1) }

eq('current flash', parsed.current['deepseek-v4-flash'], { cacheRead: 0.0028, input: 0.14, output: 0.28 })
eq('current pro', parsed.current['deepseek-v4-pro'], { cacheRead: 0.003625, input: 0.435, output: 0.87 })
eq('effectiveAt', parsed.future.effectiveAt, Date.parse('2026-08-16T16:00:00Z'))
eq('peakHours', parsed.future.peakHoursUtc, [1, 2, 3, 6, 7, 8, 9])
eq('future flash', parsed.future.models['deepseek-v4-flash'], {
  peak: { cacheRead: 0.014, input: 0.44, output: 1.32 },
  offPeak: { cacheRead: 0.007, input: 0.22, output: 0.66 }
})
eq('future pro', parsed.future.models['deepseek-v4-pro'], {
  peak: { cacheRead: 0.044, input: 1.32, output: 3.96 },
  offPeak: { cacheRead: 0.022, input: 0.66, output: 1.98 }
})

// tier-aware rate selection
const row = {
  keys: ['deepseek-v4-flash'], input: 0.14, cacheRead: 0.0028, output: 0.28,
  tiers: {
    effectiveAt: Date.parse('2026-08-16T16:00:00Z'),
    peakHoursUtc: [1, 2, 3, 6, 7, 8, 9],
    peak: { input: 0.44, cacheRead: 0.014, output: 1.32 },
    offPeak: { input: 0.22, cacheRead: 0.007, output: 0.66 }
  }
}
const before = Date.parse('2026-08-16T15:00:00Z')
const atPeak = Date.parse('2026-08-17T02:00:00Z')
const atOff = Date.parse('2026-08-17T12:00:00Z')
eq('rate before switch = flat', rateOf(row, before).tier, 'flat')
eq('rate before switch input', rateOf(row, before).input, 0.14)
eq('rate at peak = peak', rateOf(row, atPeak).tier, 'peak')
eq('rate at peak input', rateOf(row, atPeak).input, 0.44)
eq('rate at offpeak = off-peak', rateOf(row, atOff).tier, 'off-peak')
eq('rate at offpeak output', rateOf(row, atOff).output, 0.66)

// cost math: 1M input + 100k output at peak, USD
const c = costFor(row, 1e6, 1e5, 0, 0, 0, 'USD', 7.2, atPeak)
eq('cost peak total USD', c.total_cost, 0.572)
const cOff = costFor(row, 0, 0, 1e6, 0, 0, 'USD', 7.2, atOff)
eq('cost offpeak cacheRead USD', cOff.total_cost, 0.007)
const cny = costFor(row, 1e6, 0, 0, 0, 0, 'CNY', 7.2, before)
eq('cost flat CNY', cny.total_cost, 1.008)

console.log(failures === 0 ? '\nALL PASS' : '\n' + failures + ' FAILURES')
process.exit(failures === 0 ? 0 : 1)
