/**
 * dsh-deveco — Typert Host manifest.
 *
 * Hand-written TYPERT manifest (the format the DSH typert-loader consumes from
 * the package's `./typert` export). It describes the `harmonyDevEco` Remote
 * service the Host half publishes so the browser Client half can call it
 * through `ctx.remote.harmonyDevEco.{getConfig, deviceList, hilogStreamStart,
 * uiDump, ...}`.
 *
 * Keep the invocation ids, service/namespace names and method names in sync
 * with `index.js` (HarmonyDevEcoService) and `client.js`.
 */

import { z } from "zod";

// ---- shared shapes ---------------------------------------------------------

const errorSchema = z
  .object({
    code: z.string().readonly(),
    message: z.string().readonly().optional(),
  })
  .readonly();

/** A successful response envelope: `{ ok: true, value }`. */
function okValue(valueSchema) {
  return z
    .object({
      ok: z.literal(true).readonly(),
      value: valueSchema,
    })
    .readonly();
}

/** A failed response envelope: `{ ok: false, error }`. */
function errValue() {
  return z
    .object({
      ok: z.literal(false).readonly(),
      error: errorSchema,
    })
    .readonly();
}

/** Either a successful or failed envelope — the standard Remote return. */
function unionResult(valueSchema) {
  return z.union([okValue(valueSchema), errValue()]);
}

// ---- toolchain / config / discovery schemas -------------------------------

const resolvedSchema = z
  .object({
    source: z.enum(["devecocli", "clt", "studio", "none"]).readonly(),
    exec: z.string().readonly().optional(),
    path: z.string().readonly().optional(),
    version: z.union([z.array(z.number()).readonly(), z.string().readonly()]).optional(),
    minVersionOk: z.boolean().readonly(),
    // Runtime capability probes (not part of the pure resolver): whether a
    // real devecocli binary exists and whether the SDK-bundled hdc was found.
    // Both are optional for backward compatibility with older Host halves.
    cliAvailable: z.boolean().readonly().optional(),
    hdcAvailable: z.boolean().readonly().optional(),
    message: z.string().readonly(),
  })
  .readonly();

const configSchema = z
  .object({
    studioPath: z.string().readonly(),
    cltPath: z.string().readonly(),
    updatedAt: z.number().readonly(),
  })
  .readonly();

const discoveryStudioSchema = z
  .object({
    path: z.string().readonly(),
    kind: z.literal("studio").readonly(),
  })
  .readonly();

const discoveryCltSchema = z
  .object({
    path: z.string().readonly(),
    version: z.string().readonly(),
    kind: z.literal("clt").readonly(),
  })
  .readonly();

const discoverySchema = z
  .object({
    schemaVersion: z.number().readonly(),
    platform: z.enum(["win32", "darwin", "linux"]).readonly(),
    scannedAt: z.number().readonly(),
    studios: z.array(discoveryStudioSchema).readonly(),
    clts: z.array(discoveryCltSchema).readonly(),
  })
  .readonly();

// ---- device schemas --------------------------------------------------------

const deviceSchema = z
  .object({
    serial: z.string().readonly(),
    name: z.string().readonly(),
    state: z.string().readonly(),
    type: z.string().readonly(),
  })
  .readonly();

const deviceInfoSchema = z
  .object({
    serial: z.string().readonly(),
    stdout: z.string().readonly(),
    stderr: z.string().readonly(),
    code: z.union([z.number().readonly(), z.null()]),
  })
  .readonly();

// ---- HiLog schemas ---------------------------------------------------------

const hilogLineSchema = z
  .object({
    timestamp: z.string().readonly().optional(),
    pid: z.number().readonly().optional(),
    tid: z.number().readonly().optional(),
    level: z.string().readonly().optional(),
    domain: z.string().readonly().optional(),
    tag: z.string().readonly().optional(),
    message: z.string().readonly().optional(),
    raw: z.string().readonly().optional(),
  })
  .readonly();

const hilogReadSchema = z
  .object({
    lines: z.array(hilogLineSchema).readonly(),
    closed: z.boolean().readonly(),
    error: z.string().readonly().optional(),
  })
  .readonly();

const hilogStreamStartSchema = z
  .object({
    streamId: z.string().readonly(),
  })
  .readonly();

const hilogStreamStopSchema = z
  .object({
    stopped: z.boolean().readonly(),
  })
  .readonly();

const hilogListSchema = z
  .object({
    lines: z.array(hilogLineSchema).readonly(),
  })
  .readonly();

// ---- ArkUI Inspector schemas ----------------------------------------------

const boundsSchema = z
  .object({
    left: z.number().readonly(),
    top: z.number().readonly(),
    right: z.number().readonly(),
    bottom: z.number().readonly(),
    width: z.number().readonly(),
    height: z.number().readonly(),
  })
  .readonly();

const boxSidesSchema = z
  .object({
    top: z.number().readonly(),
    right: z.number().readonly(),
    bottom: z.number().readonly(),
    left: z.number().readonly(),
  })
  .readonly();

const uiNodeSchema = z
  .object({
    index: z.number().readonly(),
    depth: z.number().readonly(),
    parentIndex: z.number().readonly(),
    windowId: z.number().readonly(),
    text: z.string().readonly(),
    resourceId: z.string().readonly(),
    className: z.string().readonly(),
    // Visible rect (clipped by scrolling parents / occluded by other windows).
    bounds: boundsSchema,
    boundsStr: z.string().readonly(),
    // True layout rect — drives the highlight overlay and the box model.
    origBounds: boundsSchema.optional(),
    origBoundsStr: z.string().optional(),
    // Measured content region (union of children's rects) — the only
    // box-model geometry the device dump actually provides.
    contentBox: boundsSchema.optional(),
    // @Component struct instance name when this node is one (else "").
    componentName: z.string().optional(),
    // Nearest ancestor that is a custom component — labels the anonymous
    // `__Common__` placeholders the toolchain emits for component internals.
    ownerComponent: z.string().optional(),
    // Original direct-child count and structural-pruning markers stay stable even
    // when Swiper/visibility trimming removes every returned child.
    childCount: z.number().optional(),
    childrenOmitted: z.boolean().optional(),
    hiddenDirect: z.number().optional(),
    // Developer-assigned `.id('…')` — empty when unset, never an accessibilityId.
    devId: z.string().optional(),
    key: z.string().optional(),
    accessibilityId: z.string().optional(),
    originalText: z.string().optional(),
    bundleName: z.string().optional(),
    abilityName: z.string().optional(),
    pagePath: z.string().optional(),
    focused: z.boolean().optional(),
    selected: z.boolean().optional(),
    checked: z.boolean().optional(),
    checkable: z.boolean().optional(),
    clipped: z.boolean().optional(),
    longClickable: z.boolean().optional(),
    scrollable: z.boolean().optional(),
    zIndex: z.number().optional(),
    hitTestBehavior: z.string().optional(),
    hierarchy: z.string().optional(),
    hashcode: z.string().optional(),
    displayId: z.string().optional(),
    backgroundColor: z.string().optional(),
    backgroundImage: z.string().optional(),
    blur: z.string().optional(),
    description: z.string().optional(),
    hint: z.string().optional(),
    // Every attribute the device reports, verbatim (nothing dropped).
    rawAttrs: z.record(z.string(), z.string()).optional(),
    // Box-model layers stay undefined when the device dump does not report them
    // (HarmonyOS uitest exposes no padding/margin/border data at all).
    padding: boxSidesSchema.optional(),
    margin: boxSidesSchema.optional(),
    borderWidth: z.number().optional(),
    borderRadius: z.number().optional(),
    borderColor: z.string().optional(),
    opacity: z.number().readonly(),
    visible: z.boolean().readonly(),
    enabled: z.boolean().readonly(),
    clickable: z.boolean().readonly(),
    attrs: z.record(z.string(), z.union([z.string(), z.number(), z.boolean()])).readonly(),
  })
  .readonly();

const uiDumpSchema = z
  .object({
    nodes: z.array(uiNodeSchema).readonly(),
  })
  .readonly();

const uiDevEcoTreeSchema = z
  .object({
    nodes: z.array(uiNodeSchema).readonly(),
    source: z.string().readonly(),
  })
  .readonly();

// ---- ArkWeb Web DOM schemas ------------------------------------------------

const webTargetSchema = z
  .object({
    id: z.string().readonly(),
    type: z.string().readonly(),
    title: z.string().readonly(),
    url: z.string().readonly(),
    pid: z.number().readonly(),
    socketName: z.string().readonly(),
    packageName: z.string().readonly().optional(),
    description: z.string().readonly().optional(),
  })
  .readonly();

const webTargetsValueSchema = z
  .object({
    targets: z.array(webTargetSchema).readonly(),
    socketCount: z.number().readonly(),
    warnings: z.array(z.string()).readonly().optional(),
  })
  .readonly();

const webDomNodeSchema = z
  .object({
    index: z.number().readonly(),
    depth: z.number().readonly(),
    parentIndex: z.number().readonly(),
    nodeType: z.number().readonly(),
    tag: z.string().readonly(),
    name: z.string().readonly(),
    nodeName: z.string().readonly().optional(),
    localName: z.string().readonly().optional(),
    text: z.string().readonly(),
    childCount: z.number().readonly(),
    childrenOmitted: z.boolean().readonly().optional(),
    hiddenDirect: z.number().readonly().optional(),
    attrCount: z.number().readonly(),
    id: z.string().readonly().optional(),
    classes: z.array(z.string()).readonly().optional(),
    frameId: z.string().readonly().optional(),
    shadowRootType: z.string().readonly().optional(),
    attributes: z.record(z.string(), z.string()).readonly().optional(),
  })
  .readonly();

const webDomReadValueSchema = z
  .object({
    source: z.literal("webdevtools").readonly(),
    target: webTargetSchema,
    nodeCount: z.number().readonly(),
    truncated: z.boolean().readonly(),
    hiddenNodes: z.number().readonly(),
    nodes: z.array(webDomNodeSchema).readonly(),
    html: z.string().readonly().optional(),
    htmlTruncated: z.boolean().readonly().optional(),
  })
  .readonly();

const uiWindowSchema = z
  .object({
    id: z.number().readonly(),
    name: z.string().readonly(),
    pid: z.number().readonly(),
    displayId: z.number().readonly(),
    focused: z.boolean().readonly(),
  })
  .readonly();

const uiWindowListSchema = z
  .object({
    windows: z.array(uiWindowSchema).readonly(),
  })
  .readonly();

const uiScreenshotSchema = z
  .object({
    savedTo: z.string().readonly(),
    stdout: z.string().readonly(),
    stderr: z.string().readonly(),
    dataUrl: z.string().readonly(),
    imageWidth: z.number().readonly(),
    imageHeight: z.number().readonly(),
    byteSize: z.number().readonly(),
  })
  .readonly();

const okFlagSchema = z
  .object({
    ok: z.literal(true).readonly(),
  })
  .readonly();

const stdoutExecSchema = z
  .object({
    stdout: z.string().readonly(),
    stderr: z.string().readonly(),
    code: z.union([z.number().readonly(), z.null()]),
  })
  .readonly();

// ---- project schemas -------------------------------------------------------

const projectSchema = z
  .object({
    path: z.string().readonly(),
    name: z.string().readonly(),
    bundleName: z.string().readonly().optional(),
    moduleCount: z.number().readonly().optional(),
  })
  .readonly();

const projectsSchema = z
  .object({
    projects: z.array(projectSchema).readonly(),
  })
  .readonly();

// ---- parameter schemas -----------------------------------------------------

const _harmonyDevEco_getConfig_parameter_0$schema = z.object({}).readonly();

const _harmonyDevEco_rescan_parameter_0$schema = z.object({}).readonly();

const _harmonyDevEco_deviceList_parameter_0$schema = z.object({}).readonly();

const _harmonyDevEco_deviceInfo_parameter_0$schema = z
  .object({
    device: z.string().readonly(),
  })
  .readonly();

const _harmonyDevEco_deviceIpConn_parameter_0$schema = z
  .object({
    ip: z.string().readonly(),
    port: z.number().readonly(),
  })
  .readonly();

const ipConnectValueSchema = z
  .object({
    address: z.string().readonly(),
    connected: z.boolean().readonly(),
    message: z.string().readonly(),
    hdc: z.string().readonly(),
  })
  .readonly();

const ipDisconnectValueSchema = z
  .object({
    address: z.string().readonly(),
    disconnected: z.boolean().readonly(),
    message: z.string().readonly(),
    hdc: z.string().readonly(),
  })
  .readonly();

const _harmonyDevEco_deviceProcessPids_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    bundle: z.string().readonly(),
  })
  .readonly();

const processPidsValueSchema = z
  .object({
    bundle: z.string().readonly(),
    pids: z.array(z.number()).readonly(),
  })
  .readonly();

const _harmonyDevEco_hilogList_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    level: z.string().optional().readonly(),
    bundle: z.string().optional().readonly(),
    keyword: z.string().optional().readonly(),
    tail: z.number().optional().readonly(),
    from: z.string().optional().readonly(),
    to: z.string().optional().readonly(),
  })
  .readonly();

const _harmonyDevEco_hilogStreamStart_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    level: z.string().optional().readonly(),
    bundle: z.string().optional().readonly(),
    keyword: z.string().optional().readonly(),
  })
  .readonly();

const _harmonyDevEco_hilogStreamRead_parameter_0$schema = z
  .object({
    streamId: z.string().readonly(),
    maxLines: z.number().optional().readonly(),
  })
  .readonly();

const _harmonyDevEco_hilogStreamStop_parameter_0$schema = z
  .object({
    streamId: z.string().readonly(),
  })
  .readonly();

const _harmonyDevEco_uiDump_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    windowId: z.number().optional().readonly(),
    allWindows: z.boolean().optional().readonly(),
  })
  .readonly();

const _harmonyDevEco_uiDevEcoTree_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    pid: z.number().optional().readonly(),
    packageName: z.string().optional().readonly(),
  })
  .readonly();

const _harmonyDevEco_webTargets_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    pid: z.number().optional().readonly(),
    packageName: z.string().optional().readonly(),
  })
  .readonly();

const _harmonyDevEco_webDomRead_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    pid: z.number().optional().readonly(),
    packageName: z.string().optional().readonly(),
    targetId: z.string().optional().readonly(),
    selector: z.string().optional().readonly(),
    depth: z.number().optional().readonly(),
    maxNodes: z.number().optional().readonly(),
    includeAttrs: z.boolean().optional().readonly(),
    includeHtml: z.boolean().optional().readonly(),
    pierce: z.boolean().optional().readonly(),
  })
  .readonly();

const _harmonyDevEco_uiWindowList_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    all: z.boolean().optional().readonly(),
  })
  .readonly();

const _harmonyDevEco_uiScreenshot_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    outPath: z.string().readonly(),
  })
  .readonly();

const _harmonyDevEco_uiTap_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    x: z.number().readonly(),
    y: z.number().readonly(),
  })
  .readonly();

const _harmonyDevEco_uiSwipe_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    x1: z.number().readonly(),
    y1: z.number().readonly(),
    x2: z.number().readonly(),
    y2: z.number().readonly(),
    speed: z.union([z.number().readonly(), z.string().readonly()]).optional(),
  })
  .readonly();

const _harmonyDevEco_uiText_parameter_0$schema = z
  .object({
    device: z.string().optional().readonly(),
    text: z.string().readonly(),
  })
  .readonly();

const _harmonyDevEco_listProjects_parameter_0$schema = z.object({}).readonly();

// ---- composite result schemas ---------------------------------------------

const getConfigValueSchema = z
  .object({
    config: configSchema,
    resolved: resolvedSchema,
    discovery: discoverySchema.nullable(),
  })
  .readonly();

const setPathValueSchema = z
  .object({
    config: configSchema,
    resolved: resolvedSchema,
  })
  .readonly();

const readTextFileValueSchema = z
  .object({
    path: z.string().readonly(),
    content: z.string().readonly(),
    bytes: z.number().readonly(),
    truncated: z.boolean().readonly(),
  })
  .readonly();

const pathRequestSchema = z
  .object({
    path: z.string().readonly(),
  })
  .readonly();

const rescanValueSchema = z
  .object({
    discovery: discoverySchema,
  })
  .readonly();

const deviceListValueSchema = z
  .object({
    devices: z.array(deviceSchema).readonly(),
  })
  .readonly();

const deviceInfoValueSchema = z
  .object({
    info: deviceInfoSchema,
  })
  .readonly();

// ---- helper to build invocation entries -----------------------------------

/**
 * Build an invocation entry for the given method. Mirrors the layout used in
 * dsh-memory-manager/typert.host.js and dsh-token-stats/typert.host.js so the
 * typert-loader accepts it without surprises.
 */
function iv(method, paramSchema, resultValueSchema, summary, jsDoc) {
  // A parameter-less Remote (getConfig / getSettingsNamespace / rescan /
  // deviceList / listProjects) passes `null` and declares NO wire parameter —
  // the gateway rejects args missing a declared parameter, so such methods
  // must not produce a request slot. Passing the empty-object schema is not
  // reliable: these schemas are wrapped in .readonly(), whose `.shape` is
  // undefined, not `{}`.
  const parameters = paramSchema === null ? [] : [
    {
      name: "request",
      wire: "request",
      source: "json",
      codec: {
        mode: "strict",
        typeSymbol: "dsh-deveco#HarmonyDevEco" + method[0].toUpperCase() + method.slice(1) + "Request",
        // Dual-shape codec (see dsh-memory-manager): <= 0.1.5 validators read
        // `codec.schema`, >= 0.1.7 (and 0.2.0) call `codec.create()` — carry both.
        schema: paramSchema,
        create: () => paramSchema,
      },
    },
  ];
  return {
    id: "dsh-deveco#harmonyDevEco/" + method,
    service: "harmonyDevEco",
    namespace: "harmonyDevEco",
    method,
    invocation: { kind: "direct" },
    parameters,
    result: {
      mode: "strict",
      typeSymbol: "dsh-deveco#HarmonyDevEco" + method[0].toUpperCase() + method.slice(1) + "Result",
      schema: unionResult(resultValueSchema),
      create: () => unionResult(resultValueSchema),
    },
    sourceLocation: { file: "index.js", line: 1, column: 1 },
  };
}

// ---- export ----------------------------------------------------------------

export const TYPERT = {
  package: "@duke-dsh-plugins/dsh-deveco",
  face: "host",
  schemas: [],
  invocations: [
    iv("getConfig", null, getConfigValueSchema,
      "Read the current toolchain config, the resolved CLI source, and the latest discovery snapshot.",
      "/**\n * Read the current toolchain config, the resolved CLI source, and the latest discovery snapshot.\n */"),

    iv("setStudioPath", pathRequestSchema, setPathValueSchema,
      "Persist the DevEco Studio path (clears cltPath; empty string clears the field).",
      "/**\n * Persist the DevEco Studio path. Writing Studio clears cltPath (mutual exclusion).\n * @param request - `{ path }` absolute install root, or empty string to clear.\n */"),

    iv("setCltPath", pathRequestSchema, setPathValueSchema,
      "Persist the HarmonyOS Command Line Tools path (clears studioPath; empty string clears the field).",
      "/**\n * Persist the HarmonyOS Command Line Tools path. Writing CLT clears studioPath (mutual exclusion).\n * @param request - `{ path }` absolute CLT root, or empty string to clear.\n */"),

    iv("readTextFile", pathRequestSchema, readTextFileValueSchema,
      "Read a UTF-8 text file from an absolute host path (2 MiB cap) for the .ets sidebar viewer.",
      "/**\n * Read a UTF-8 text file from an absolute host path for the .ets viewer.\n * @param request - `{ path }` absolute host path.\n * @returns `{ path, content, bytes, truncated }`.\n */"),

    iv("rescan", null, rescanValueSchema,
      "Re-run toolchain auto-discovery and persist the result to disk.",
      "/**\n * Re-run toolchain auto-discovery and persist the result to disk.\n */"),

    iv("deviceList", null, deviceListValueSchema,
      "Enumerate devices and emulators currently known to the toolchain.",
      "/**\n * Enumerate devices and emulators currently known to the toolchain.\n */"),

    iv("deviceInfo", _harmonyDevEco_deviceInfo_parameter_0$schema, deviceInfoValueSchema,
      "Fetch detailed metadata for a single device.",
      "/**\n * Fetch detailed metadata for a single device.\n * @param request - `{ device }` the device serial / id.\n */"),

    iv("deviceConnectIp", _harmonyDevEco_deviceIpConn_parameter_0$schema, ipConnectValueSchema,
      "Connect a device over TCP/IP via `hdc tconn <ip>:<port>` (devecocli has no equivalent).",
      "/**\n * Connect a device over TCP/IP via `hdc tconn <ip>:<port>`.\n * @param request - `{ ip, port }`; port is REQUIRED (hdc has no default) and must match the debug port the device exposes (enable debugging on the device first).\n */"),

    iv("deviceDisconnectIp", _harmonyDevEco_deviceIpConn_parameter_0$schema, ipDisconnectValueSchema,
      "Disconnect a TCP device target via `hdc tconn <ip>:<port> -remove`.",
      "/**\n * Disconnect a TCP device target via `hdc tconn <ip>:<port> -remove`.\n * @param request - `{ ip, port }`; port is REQUIRED (hdc has no default).\n */"),

    iv("deviceProcessPids", _harmonyDevEco_deviceProcessPids_parameter_0$schema, processPidsValueSchema,
      "Resolve the PIDs of a bundle's processes via `hdc shell ps -ef` (exact + `:suffix` match). HiLog lines carry no bundle name, so the client-side real-time bundle filter maps bundle→pids through this.",
      "/**\n * Resolve the PIDs of a bundle's processes on the device.\n * @param request - `{ bundle }` exact bundle name, plus optional `device`.\n * @returns `{ bundle, pids }` — empty pids when the app is not running.\n */"),

    iv("hilogList", _harmonyDevEco_hilogList_parameter_0$schema, hilogListSchema,
      "Read a one-shot snapshot of HiLog lines matching the given filters.",
      "/**\n * Read a one-shot snapshot of HiLog lines matching the given filters.\n * @param request - optional device/level/bundle/keyword/tail/from/to filters.\n */"),

    iv("hilogStreamStart", _harmonyDevEco_hilogStreamStart_parameter_0$schema, hilogStreamStartSchema,
      "Start a live HiLog stream and return an opaque streamId for later reads.",
      "/**\n * Start a live HiLog stream and return an opaque streamId for later reads.\n * @param request - optional device/level/bundle/keyword filters.\n */"),

    iv("hilogStreamRead", _harmonyDevEco_hilogStreamRead_parameter_0$schema, hilogReadSchema,
      "Drain up to `maxLines` buffered HiLog lines from a live stream.",
      "/**\n * Drain up to `maxLines` buffered HiLog lines from a live stream.\n * @param request - `{ streamId, maxLines? }`.\n */"),

    iv("hilogStreamStop", _harmonyDevEco_hilogStreamStop_parameter_0$schema, hilogStreamStopSchema,
      "Stop and dispose a live HiLog stream.",
      "/**\n * Stop and dispose a live HiLog stream.\n * @param request - `{ streamId }`.\n */"),

    iv("uiDump", _harmonyDevEco_uiDump_parameter_0$schema, uiDumpSchema,
      "Dump the current UI tree of a device or emulator into a flat node list. Pass `windowId` to restrict the dump to one window, or `allWindows` to include every window; each node carries the `windowId` it belongs to.",
      "/**\n * Dump the current UI tree of a device or emulator into a flat node list.\n * @param request - optional `{ device }` filter, plus `windowId` (single window) or `allWindows` (every window); each node reports its owning `windowId`.\n */"),

    iv("uiDevEcoTree", _harmonyDevEco_uiDevEcoTree_parameter_0$schema, uiDevEcoTreeSchema,
      "Fetch the component tree through DevEco Studio's own development-debug channel (`hdc fport ark:<pid>@<pkg>` + WebSocket `type:root`). The only source that reports declared padding/margin/border and component/Builder names (`viewTag`). Requires the app to expose its ArkUI inspector socket: debug build, `aa attach` (run automatically), and no DevEco Inspector panel holding the single client slot.",
      "/**\n * DevEco development-debug tree source.\n * @param request - optional `{ device }`, `pid` (default: focused window's pid), `packageName`.\n * @returns `{ nodes, source: \"deveco\" }` — same node shape as uiDump, plus declared box-model values.\n */"),

    iv("webTargets", _harmonyDevEco_webTargets_parameter_0$schema, webTargetsValueSchema,
      "List ArkWeb DevTools targets discovered through webview_devtools_remote_<pid> sockets and the forwarded /json endpoint.",
      "/**\n * List ArkWeb DevTools targets.\n * @param request - optional `{ device, pid, packageName }` filters.\n * @returns `{ targets, socketCount, warnings? }`; targets omit stale device-side websocket URLs.\n */"),

    iv("webDomRead", _harmonyDevEco_webDomRead_parameter_0$schema, webDomReadValueSchema,
      "Read a bounded DOM tree or outerHTML from one ArkWeb page target through Chromium CDP, with one-shot fport cleanup.",
      "/**\n * Read ArkWeb page DOM through Chromium CDP.\n * @param request - `{ device?, pid?, packageName?, targetId?, selector?, depth?, maxNodes?, includeAttrs?, includeHtml?, pierce? }`.\n * @returns `{ source: \"webdevtools\", target, nodeCount, truncated, hiddenNodes, nodes, html?, htmlTruncated? }`.\n */"),

    iv("uiWindowList", _harmonyDevEco_uiWindowList_parameter_0$schema, uiWindowListSchema,
      "List the device's UI windows (id, name, pid, displayId, focused) for the Inspector's window selector.",
      "/**\n * List the device's UI windows.\n * @param request - optional `{ device }` filter and `all` to include system windows.\n * @returns `{ windows }` — each `{ id, name, pid, displayId, focused }`.\n */"),

    iv("uiScreenshot", _harmonyDevEco_uiScreenshot_parameter_0$schema, uiScreenshotSchema,
      "Capture a screenshot to the given host-side path.",
      "/**\n * Capture a screenshot to the given host-side path.\n * @param request - `{ outPath }` absolute host path; optional `device` filter.\n */"),

    iv("uiTap", _harmonyDevEco_uiTap_parameter_0$schema, stdoutExecSchema,
      "Tap an absolute coordinate on the device's screen.",
      "/**\n * Tap an absolute coordinate on the device's screen.\n * @param request - `{ x, y }` plus optional `device`.\n */"),

    iv("uiSwipe", _harmonyDevEco_uiSwipe_parameter_0$schema, stdoutExecSchema,
      "Swipe from (x1,y1) to (x2,y2) on the device's screen.",
      "/**\n * Swipe from (x1,y1) to (x2,y2) on the device's screen.\n * @param request - `{ x1, y1, x2, y2, speed? }` plus optional `device`.\n */"),

    iv("uiText", _harmonyDevEco_uiText_parameter_0$schema, stdoutExecSchema,
      "Type the given text into the focused input field on the device.",
      "/**\n * Type the given text into the focused input field on the device.\n * @param request - `{ text }` plus optional `device`.\n */"),

    iv("listProjects", null, projectsSchema,
      "List the HarmonyOS project at the Host working directory, if any.",
      "/**\n * List the HarmonyOS project at the Host working directory, if any.\n */"),
  ],
  model: {
    services: [
      {
        description:
          "HarmonyOS development suite: DevEco Studio / Command Line Tools / PATH-devecocli toolchain resolution with auto-discovery and mutually exclusive configuration, device enumeration, HiLog batch + live streaming, ArkUI Inspector (UI dump / screenshot / tap / swipe / text), and project browsing.",
        summary: "HarmonyOS development suite service.",
        tags: [],
        jsDoc:
          "/**\n * HarmonyOS Suite — DevEco Studio / Command Line Tools path resolution, HiLog, ArkUI Inspector.\n */",
        key: "harmonyDevEco",
        exportName: "HarmonyDevEcoService",
        members: [
          {
            kind: "method",
            name: "getConfig",
            signature: "@Remote('getConfig') async getConfig(): Promise<HarmonyDevEcoGetConfigResult>",
            summary: "Read the current toolchain config + resolved CLI source + latest discovery.",
            jsDoc:
              "/**\n * Read the current toolchain config + resolved CLI source + latest discovery.\n * @returns the config, resolved source, and discovery snapshot.\n */",
          },
          {
            kind: "method",
            name: "setStudioPath",
            signature: "@Remote('setStudioPath') async setStudioPath(request: HarmonyDevEcoPathRequest): Promise<HarmonyDevEcoSetPathResult>",
            summary: "Persist the DevEco Studio path (clears cltPath).",
            jsDoc:
              "/**\n * Persist the DevEco Studio path. Writing Studio clears cltPath (mutual exclusion).\n * @param request - `{ path }` absolute install root, or empty string to clear.\n */",
          },
          {
            kind: "method",
            name: "setCltPath",
            signature: "@Remote('setCltPath') async setCltPath(request: HarmonyDevEcoPathRequest): Promise<HarmonyDevEcoSetPathResult>",
            summary: "Persist the HarmonyOS Command Line Tools path (clears studioPath).",
            jsDoc:
              "/**\n * Persist the HarmonyOS Command Line Tools path. Writing CLT clears studioPath (mutual exclusion).\n * @param request - `{ path }` absolute CLT root, or empty string to clear.\n */",
          },
          {
            kind: "method",
            name: "readTextFile",
            signature: "@Remote('readTextFile') async readTextFile(request: HarmonyDevEcoPathRequest): Promise<HarmonyDevEcoReadTextFileResult>",
            summary: "Read a UTF-8 text file from an absolute host path (2 MiB cap).",
            jsDoc:
              "/**\n * Read a UTF-8 text file from an absolute host path for the .ets viewer.\n * @param request - `{ path }` absolute host path.\n * @returns `{ path, content, bytes, truncated }`.\n */",
          },
          {
            kind: "method",
            name: "rescan",
            signature: "@Remote('rescan') async rescan(): Promise<HarmonyDevEcoRescanResult>",
            summary: "Re-run toolchain auto-discovery and persist the result.",
            jsDoc:
              "/**\n * Re-run toolchain auto-discovery and persist the result.\n * @returns the fresh discovery snapshot.\n */",
          },
          {
            kind: "method",
            name: "deviceList",
            signature: "@Remote('deviceList') async deviceList(): Promise<HarmonyDevEcoDeviceListResult>",
            summary: "Enumerate devices and emulators currently known to the toolchain.",
            jsDoc:
              "/**\n * Enumerate devices and emulators currently known to the toolchain.\n * @returns the parsed device list (serial / name / state / type).\n */",
          },
          {
            kind: "method",
            name: "deviceInfo",
            signature: "@Remote('deviceInfo') async deviceInfo(request: HarmonyDevEcoDeviceInfoRequest): Promise<HarmonyDevEcoDeviceInfoResult>",
            summary: "Fetch detailed metadata for a single device.",
            jsDoc:
              "/**\n * Fetch detailed metadata for a single device.\n * @param request - `{ device }` serial / id.\n */",
          },
          {
            kind: "method",
            name: "deviceConnectIp",
            signature: "@Remote('deviceConnectIp') async deviceConnectIp(request: HarmonyDevEcoDeviceIpConnRequest): Promise<HarmonyDevEcoDeviceConnectIpResult>",
            summary: "Connect a device over TCP/IP via `hdc tconn <ip>:<port>` (devecocli has no equivalent).",
            jsDoc:
              "/**\n * Connect a device over TCP/IP via `hdc tconn <ip>:<port>`.\n * @param request - `{ ip, port }`; port is REQUIRED (hdc has no default).\n * @returns `{ address, connected, message, hdc }`.\n */",
          },
          {
            kind: "method",
            name: "deviceDisconnectIp",
            signature: "@Remote('deviceDisconnectIp') async deviceDisconnectIp(request: HarmonyDevEcoDeviceIpConnRequest): Promise<HarmonyDevEcoDeviceDisconnectIpResult>",
            summary: "Disconnect a TCP device target via `hdc tconn <ip>:<port> -remove`.",
            jsDoc:
              "/**\n * Disconnect a TCP device target via `hdc tconn <ip>:<port> -remove`.\n * @param request - `{ ip, port }`; port is REQUIRED (hdc has no default).\n * @returns `{ address, disconnected, message, hdc }`.\n */",
          },
          {
            kind: "method",
            name: "deviceProcessPids",
            signature: "@Remote('deviceProcessPids') async deviceProcessPids(request: HarmonyDevEcoDeviceProcessPidsRequest): Promise<HarmonyDevEcoDeviceProcessPidsResult>",
            summary: "Resolve the PIDs of a bundle's processes (`hdc shell ps -ef`); powers the real-time bundle filter.",
            jsDoc:
              "/**\n * Resolve the PIDs of a bundle's processes on the device.\n * @param request - `{ bundle }` exact bundle name, plus optional `device`.\n * @returns `{ bundle, pids }` — empty pids when the app is not running.\n */",
          },
          {
            kind: "method",
            name: "hilogList",
            signature: "@Remote('hilogList') async hilogList(request?: HarmonyDevEcoHilogListRequest): Promise<HarmonyDevEcoHilogListResult>",
            summary: "Read a one-shot snapshot of HiLog lines matching the given filters.",
            jsDoc:
              "/**\n * Read a one-shot snapshot of HiLog lines matching the given filters.\n * @param request - optional device/level/bundle/keyword/tail/from/to filters.\n */",
          },
          {
            kind: "method",
            name: "hilogStreamStart",
            signature: "@Remote('hilogStreamStart') async hilogStreamStart(request?: HarmonyDevEcoHilogStreamStartRequest): Promise<HarmonyDevEcoHilogStreamStartResult>",
            summary: "Start a live HiLog stream and return an opaque streamId for later reads.",
            jsDoc:
              "/**\n * Start a live HiLog stream and return an opaque streamId for later reads.\n * @param request - optional device/level/bundle/keyword filters.\n */",
          },
          {
            kind: "method",
            name: "hilogStreamRead",
            signature: "@Remote('hilogStreamRead') async hilogStreamRead(request: HarmonyDevEcoHilogStreamReadRequest): Promise<HarmonyDevEcoHilogStreamReadResult>",
            summary: "Drain up to `maxLines` buffered HiLog lines from a live stream.",
            jsDoc:
              "/**\n * Drain up to `maxLines` buffered HiLog lines from a live stream.\n * @param request - `{ streamId, maxLines? }`.\n */",
          },
          {
            kind: "method",
            name: "hilogStreamStop",
            signature: "@Remote('hilogStreamStop') async hilogStreamStop(request: HarmonyDevEcoHilogStreamStopRequest): Promise<HarmonyDevEcoHilogStreamStopResult>",
            summary: "Stop and dispose a live HiLog stream.",
            jsDoc:
              "/**\n * Stop and dispose a live HiLog stream.\n * @param request - `{ streamId }`.\n */",
          },
          {
            kind: "method",
            name: "uiDump",
            signature: "@Remote('uiDump') async uiDump(request?: HarmonyDevEcoUiDumpRequest): Promise<HarmonyDevEcoUiDumpResult>",
            summary: "Dump the current UI tree of a device or emulator into a flat node list.",
            jsDoc:
              "/**\n * Dump the current UI tree of a device or emulator into a flat node list.\n * @param request - optional `{ device }` filter, plus `windowId` (single window) or `allWindows` (every window); each node reports its owning `windowId`.\n */",
          },
          {
            kind: "method",
            name: "uiDevEcoTree",
            signature: "@Remote('uiDevEcoTree') async uiDevEcoTree(request?: HarmonyDevEcoUiDevEcoTreeRequest): Promise<HarmonyDevEcoUiDevEcoTreeResult>",
            summary: "Fetch the component tree through DevEco's development-debug channel (ark socket + WebSocket); the only source with declared padding/margin/border and component names.",
            jsDoc:
              "/**\n * DevEco development-debug tree source (`hdc fport ark:<pid>@<pkg>` + WebSocket `type:root`).\n * @param request - optional `{ device }`, `pid` (default: focused window's pid), `packageName`.\n * @returns `{ nodes, source: \"deveco\" }` — same node shape as uiDump, plus declared box-model values.\n */",
          },
          {
            kind: "method",
            name: "webTargets",
            signature: "@Remote('webTargets') async webTargets(request?: HarmonyDevEcoWebTargetsRequest): Promise<HarmonyDevEcoWebTargetsResult>",
            summary: "List ArkWeb DevTools targets (webview_devtools_remote_<pid> + /json).",
            jsDoc:
              "/**\n * List ArkWeb DevTools targets.\n * @param request - optional `{ device, pid, packageName }` filters.\n * @returns `{ targets, socketCount, warnings? }`.\n */",
          },
          {
            kind: "method",
            name: "webDomRead",
            signature: "@Remote('webDomRead') async webDomRead(request?: HarmonyDevEcoWebDomReadRequest): Promise<HarmonyDevEcoWebDomReadResult>",
            summary: "Read a bounded Web DOM tree or outerHTML through Chromium CDP.",
            jsDoc:
              "/**\n * Read ArkWeb page DOM through Chromium CDP.\n * @param request - target id plus optional selector/depth/maxNodes/includeAttrs/includeHtml/pierce.\n * @returns `{ source: \"webdevtools\", target, nodeCount, truncated, hiddenNodes, nodes, html? }`.\n */",
          },
          {
            kind: "method",
            name: "uiWindowList",
            signature: "@Remote('uiWindowList') async uiWindowList(request?: HarmonyDevEcoUiWindowListRequest): Promise<HarmonyDevEcoUiWindowListResult>",
            summary: "List the device's UI windows (id, name, pid, displayId, focused) for the Inspector's window selector.",
            jsDoc:
              "/**\n * List the device's UI windows.\n * @param request - optional `{ device }` filter and `all` to include system windows.\n * @returns `{ windows }` — each `{ id, name, pid, displayId, focused }`.\n */",
          },
          {
            kind: "method",
            name: "uiScreenshot",
            signature: "@Remote('uiScreenshot') async uiScreenshot(request: HarmonyDevEcoUiScreenshotRequest): Promise<HarmonyDevEcoUiScreenshotResult>",
            summary: "Capture a screenshot to the given host-side path.",
            jsDoc:
              "/**\n * Capture a screenshot to the given host-side path.\n * @param request - `{ outPath }` plus optional `device`.\n */",
          },
          {
            kind: "method",
            name: "uiTap",
            signature: "@Remote('uiTap') async uiTap(request: HarmonyDevEcoUiTapRequest): Promise<HarmonyDevEcoUiTapResult>",
            summary: "Tap an absolute coordinate on the device's screen.",
            jsDoc:
              "/**\n * Tap an absolute coordinate on the device's screen.\n * @param request - `{ x, y }` plus optional `device`.\n */",
          },
          {
            kind: "method",
            name: "uiSwipe",
            signature: "@Remote('uiSwipe') async uiSwipe(request: HarmonyDevEcoUiSwipeRequest): Promise<HarmonyDevEcoUiSwipeResult>",
            summary: "Swipe from (x1,y1) to (x2,y2) on the device's screen.",
            jsDoc:
              "/**\n * Swipe from (x1,y1) to (x2,y2) on the device's screen.\n * @param request - `{ x1, y1, x2, y2, speed? }` plus optional `device`.\n */",
          },
          {
            kind: "method",
            name: "uiText",
            signature: "@Remote('uiText') async uiText(request: HarmonyDevEcoUiTextRequest): Promise<HarmonyDevEcoUiTextResult>",
            summary: "Type the given text into the focused input field on the device.",
            jsDoc:
              "/**\n * Type the given text into the focused input field on the device.\n * @param request - `{ text }` plus optional `device`.\n */",
          },
          {
            kind: "method",
            name: "listProjects",
            signature: "@Remote('listProjects') async listProjects(): Promise<HarmonyDevEcoListProjectsResult>",
            summary: "List the HarmonyOS project at the Host working directory, if any.",
            jsDoc:
              "/**\n * List the HarmonyOS project at the Host working directory, if any.\n */",
          },
        ],
        types: [
          {
            name: "HarmonyDevEcoGetConfigRequest",
            declaration: "export interface HarmonyDevEcoGetConfigRequest {}",
          },
          {
            name: "HarmonyDevEcoGetConfigResult",
            declaration:
              "export type HarmonyDevEcoGetConfigResult = { ok: true; value: { config: { studioPath: string; cltPath: string; updatedAt: number }; resolved: { source: 'devecocli'|'clt'|'studio'|'none'; exec?: string; path?: string; version?: readonly number[] | string; minVersionOk: boolean; cliAvailable?: boolean; hdcAvailable?: boolean; message: string }; discovery: HarmonyDevEcoDiscovery | null } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoPathRequest",
            declaration: "export interface HarmonyDevEcoPathRequest {\n    readonly path: string;\n}",
          },
          {
            name: "HarmonyDevEcoSetPathResult",
            declaration:
              "export type HarmonyDevEcoSetPathResult = { ok: true; value: { config: HarmonyDevEcoConfig; resolved: HarmonyDevEcoResolved } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoReadTextFileResult",
            declaration:
              "export type HarmonyDevEcoReadTextFileResult = { ok: true; value: { path: string; content: string; bytes: number; truncated: boolean } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoRescanRequest",
            declaration: "export interface HarmonyDevEcoRescanRequest {}",
          },
          {
            name: "HarmonyDevEcoRescanResult",
            declaration:
              "export type HarmonyDevEcoRescanResult = { ok: true; value: { discovery: HarmonyDevEcoDiscovery } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoDeviceListRequest",
            declaration: "export interface HarmonyDevEcoDeviceListRequest {}",
          },
          {
            name: "HarmonyDevEcoDeviceListResult",
            declaration:
              "export type HarmonyDevEcoDeviceListResult = { ok: true; value: { devices: readonly HarmonyDevEcoDevice[] } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoDeviceInfoRequest",
            declaration: "export interface HarmonyDevEcoDeviceInfoRequest {\n    readonly device: string;\n}",
          },
          {
            name: "HarmonyDevEcoDeviceInfoResult",
            declaration:
              "export type HarmonyDevEcoDeviceInfoResult = { ok: true; value: { info: { serial: string; stdout: string; stderr: string; code: number | null } } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoHilogListRequest",
            declaration:
              "export interface HarmonyDevEcoHilogListRequest {\n    readonly device?: string;\n    readonly level?: string;\n    readonly bundle?: string;\n    readonly keyword?: string;\n    readonly tail?: number;\n    readonly from?: string;\n    readonly to?: string;\n}",
          },
          {
            name: "HarmonyDevEcoHilogListResult",
            declaration:
              "export type HarmonyDevEcoHilogListResult = { ok: true; value: { lines: readonly HarmonyDevEcoHilogLine[] } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoHilogStreamStartRequest",
            declaration:
              "export interface HarmonyDevEcoHilogStreamStartRequest {\n    readonly device?: string;\n    readonly level?: string;\n    readonly bundle?: string;\n    readonly keyword?: string;\n}",
          },
          {
            name: "HarmonyDevEcoHilogStreamStartResult",
            declaration:
              "export type HarmonyDevEcoHilogStreamStartResult = { ok: true; value: { streamId: string } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoHilogStreamReadRequest",
            declaration:
              "export interface HarmonyDevEcoHilogStreamReadRequest {\n    readonly streamId: string;\n    readonly maxLines?: number;\n}",
          },
          {
            name: "HarmonyDevEcoHilogStreamReadResult",
            declaration:
              "export type HarmonyDevEcoHilogStreamReadResult = { ok: true; value: { lines: readonly HarmonyDevEcoHilogLine[]; closed: boolean; error?: string } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoHilogStreamStopRequest",
            declaration:
              "export interface HarmonyDevEcoHilogStreamStopRequest {\n    readonly streamId: string;\n}",
          },
          {
            name: "HarmonyDevEcoHilogStreamStopResult",
            declaration:
              "export type HarmonyDevEcoHilogStreamStopResult = { ok: true; value: { stopped: boolean } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoUiDumpRequest",
            declaration: "export interface HarmonyDevEcoUiDumpRequest {\n    readonly device?: string;\n    readonly windowId?: number;\n    readonly allWindows?: boolean;\n}",
          },
          {
            name: "HarmonyDevEcoUiDevEcoTreeRequest",
            declaration: "export interface HarmonyDevEcoUiDevEcoTreeRequest {\n    readonly device?: string;\n    readonly pid?: number;\n    readonly packageName?: string;\n}",
          },
          {
            name: "HarmonyDevEcoUiDevEcoTreeResult",
            declaration:
              "export type HarmonyDevEcoUiDevEcoTreeResult = { ok: true; value: { nodes: readonly HarmonyDevEcoUiNode[]; source: string } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoUiDumpResult",
            declaration:
              "export type HarmonyDevEcoUiDumpResult = { ok: true; value: { nodes: readonly HarmonyDevEcoUiNode[] } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoWebTargetsRequest",
            declaration:
              "export interface HarmonyDevEcoWebTargetsRequest {\n    readonly device?: string;\n    readonly pid?: number;\n    readonly packageName?: string;\n}",
          },
          {
            name: "HarmonyDevEcoWebTarget",
            declaration:
              "export interface HarmonyDevEcoWebTarget {\n    readonly id: string;\n    readonly type: string;\n    readonly title: string;\n    readonly url: string;\n    readonly pid: number;\n    readonly socketName: string;\n    readonly packageName?: string;\n    readonly description?: string;\n}",
          },
          {
            name: "HarmonyDevEcoWebTargetsResult",
            declaration:
              "export type HarmonyDevEcoWebTargetsResult = { ok: true; value: { targets: readonly HarmonyDevEcoWebTarget[]; socketCount: number; warnings?: readonly string[] } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoWebDomReadRequest",
            declaration:
              "export interface HarmonyDevEcoWebDomReadRequest {\n    readonly device?: string;\n    readonly pid?: number;\n    readonly packageName?: string;\n    readonly targetId?: string;\n    readonly selector?: string;\n    readonly depth?: number;\n    readonly maxNodes?: number;\n    readonly includeAttrs?: boolean;\n    readonly includeHtml?: boolean;\n    readonly pierce?: boolean;\n}",
          },
          {
            name: "HarmonyDevEcoWebDomNode",
            declaration:
              "export interface HarmonyDevEcoWebDomNode {\n    readonly index: number;\n    readonly depth: number;\n    readonly parentIndex: number;\n    readonly nodeType: number;\n    readonly tag: string;\n    readonly name: string;\n    readonly nodeName?: string;\n    readonly localName?: string;\n    readonly text: string;\n    readonly childCount: number;\n    readonly childrenOmitted?: boolean;\n    readonly hiddenDirect?: number;\n    readonly attrCount: number;\n    readonly id?: string;\n    readonly classes?: readonly string[];\n    readonly frameId?: string;\n    readonly shadowRootType?: string;\n    readonly attributes?: Readonly<Record<string, string>>;\n}",
          },
          {
            name: "HarmonyDevEcoWebDomReadResult",
            declaration:
              "export type HarmonyDevEcoWebDomReadResult = { ok: true; value: { source: 'webdevtools'; target: HarmonyDevEcoWebTarget; nodeCount: number; truncated: boolean; hiddenNodes: number; nodes: readonly HarmonyDevEcoWebDomNode[]; html?: string; htmlTruncated?: boolean } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoUiWindowListRequest",
            declaration: "export interface HarmonyDevEcoUiWindowListRequest {\n    readonly device?: string;\n    readonly all?: boolean;\n}",
          },
          {
            name: "HarmonyDevEcoUiWindowListResult",
            declaration:
              "export type HarmonyDevEcoUiWindowListResult = { ok: true; value: { windows: readonly HarmonyDevEcoUiWindow[] } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoUiWindow",
            declaration:
              "export interface HarmonyDevEcoUiWindow {\n    readonly id: number;\n    readonly name: string;\n    readonly pid: number;\n    readonly displayId: number;\n    readonly focused: boolean;\n}",
          },
          {
            name: "HarmonyDevEcoUiScreenshotRequest",
            declaration:
              "export interface HarmonyDevEcoUiScreenshotRequest {\n    readonly device?: string;\n    readonly outPath: string;\n}",
          },
          {
            name: "HarmonyDevEcoUiScreenshotResult",
            declaration:
              "export type HarmonyDevEcoUiScreenshotResult = { ok: true; value: { savedTo: string; stdout: string; stderr: string; dataUrl: string; imageWidth: number; imageHeight: number; byteSize: number } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoUiTapRequest",
            declaration:
              "export interface HarmonyDevEcoUiTapRequest {\n    readonly device?: string;\n    readonly x: number;\n    readonly y: number;\n}",
          },
          {
            name: "HarmonyDevEcoUiTapResult",
            declaration:
              "export type HarmonyDevEcoUiTapResult = { ok: true; value: { stdout: string; stderr: string; code: number | null } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoUiSwipeRequest",
            declaration:
              "export interface HarmonyDevEcoUiSwipeRequest {\n    readonly device?: string;\n    readonly x1: number;\n    readonly y1: number;\n    readonly x2: number;\n    readonly y2: number;\n    readonly speed?: number | string;\n}",
          },
          {
            name: "HarmonyDevEcoUiSwipeResult",
            declaration:
              "export type HarmonyDevEcoUiSwipeResult = { ok: true; value: { stdout: string; stderr: string; code: number | null } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoUiTextRequest",
            declaration:
              "export interface HarmonyDevEcoUiTextRequest {\n    readonly device?: string;\n    readonly text: string;\n}",
          },
          {
            name: "HarmonyDevEcoUiTextResult",
            declaration:
              "export type HarmonyDevEcoUiTextResult = { ok: true; value: { stdout: string; stderr: string; code: number | null } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoListProjectsRequest",
            declaration: "export interface HarmonyDevEcoListProjectsRequest {}",
          },
          {
            name: "HarmonyDevEcoListProjectsResult",
            declaration:
              "export type HarmonyDevEcoListProjectsResult = { ok: true; value: { projects: readonly { path: string; name: string; bundleName?: string; moduleCount?: number }[] } } | { ok: false; error: { code: string; message?: string } };",
          },
          {
            name: "HarmonyDevEcoConfig",
            declaration:
              "export interface HarmonyDevEcoConfig {\n    readonly studioPath: string;\n    readonly cltPath: string;\n    readonly updatedAt: number;\n}",
          },
          {
            name: "HarmonyDevEcoResolved",
            declaration:
              "export interface HarmonyDevEcoResolved {\n    readonly source: 'devecocli'|'clt'|'studio'|'none';\n    readonly exec?: string;\n    readonly path?: string;\n    readonly version?: readonly number[] | string;\n    readonly minVersionOk: boolean;\n    readonly cliAvailable?: boolean;\n    readonly hdcAvailable?: boolean;\n    readonly message: string;\n}",
          },
          {
            name: "HarmonyDevEcoDiscovery",
            declaration:
              "export interface HarmonyDevEcoDiscovery {\n    readonly schemaVersion: number;\n    readonly platform: 'win32'|'darwin'|'linux';\n    readonly scannedAt: number;\n    readonly studios: readonly { readonly path: string; readonly kind: 'studio' }[];\n    readonly clts: readonly { readonly path: string; readonly version: string; readonly kind: 'clt' }[];\n}",
          },
          {
            name: "HarmonyDevEcoDevice",
            declaration:
              "export interface HarmonyDevEcoDevice {\n    readonly serial: string;\n    readonly name: string;\n    readonly state: string;\n    readonly type: string;\n}",
          },
          {
            name: "HarmonyDevEcoHilogLine",
            declaration:
              "export interface HarmonyDevEcoHilogLine {\n    readonly timestamp?: string;\n    readonly pid?: number;\n    readonly tid?: number;\n    readonly level?: string;\n    readonly domain?: string;\n    readonly tag?: string;\n    readonly message?: string;\n    readonly raw?: string;\n}",
          },
          {
            name: "HarmonyDevEcoUiNode",
            declaration:
              "export interface HarmonyDevEcoUiNode {\n    readonly index: number;\n    readonly depth: number;\n    readonly parentIndex: number;\n    readonly windowId: number;\n    readonly text: string;\n    readonly resourceId: string;\n    readonly className: string;\n    readonly bounds: { readonly left: number; readonly top: number; readonly right: number; readonly bottom: number; readonly width: number; readonly height: number };\n    readonly boundsStr: string;\n    readonly padding: HarmonyDevEcoUiBoxSides;\n    readonly margin: HarmonyDevEcoUiBoxSides;\n    readonly borderWidth: number;\n    readonly borderRadius: number;\n    readonly borderColor: string;\n    readonly opacity: number;\n    readonly visible: boolean;\n    readonly enabled: boolean;\n    readonly clickable: boolean;\n    readonly attrs: Readonly<Record<string, string | number | boolean>>;\n}\n\nexport interface HarmonyDevEcoUiBoxSides {\n    readonly top: number;\n    readonly right: number;\n    readonly bottom: number;\n    readonly left: number;\n}",
          },
        ],
      },
    ],
    events: [],
    objects: [],
  },
};