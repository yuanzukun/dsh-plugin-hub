#!/usr/bin/env bash
# 从 AtomGit Skills 上游同步六个技能到 skills/。
#
# 用法: scripts/sync-skills.sh [<ref>]   # ref 默认 main,可传 tag 或 commit
#
# 只同步 SKILL.md 与 references/(SKILL.md 引用的资源);上游每个技能目录里的
# agents/openai.yaml 是 Codex IDE 专用配置,SKILL.md 不引用它,dsh 不需要,故跳过。
# 上游许可证(MulanPSL-2.0)随技能一起复制到 skills/LICENSE。

set -euo pipefail
cd "$(dirname "$0")/.."

REF="${1:-main}"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

echo "cloning atomgit-skills @ ${REF} ..."
git clone --quiet --depth 1 --branch "$REF" \
  https://atomgit.com/hust-open-atom-club/atomgit-skills.git "$TMP/atomgit-skills"

SKILLS=(atomgit-plan-issues atomgit-implement-issue atomgit-review-pr \
        atomgit-merge-pr atomgit-publish-cli-release atomgit-mirror-to-github)

for skill in "${SKILLS[@]}"; do
  src="$TMP/atomgit-skills/$skill"
  if [[ ! -f "$src/SKILL.md" ]]; then
    echo "error: upstream $skill has no SKILL.md at ${REF}" >&2
    exit 1
  fi
  rm -rf "skills/$skill"
  mkdir -p "skills/$skill/references"
  cp "$src/SKILL.md" "skills/$skill/"
  if [[ -d "$src/references" ]]; then
    cp "$src/references/"* "skills/$skill/references/"
  fi
  echo "synced $skill"
done

cp "$TMP/atomgit-skills/LICENSE" skills/LICENSE
echo "skills synced @ ${REF}"
