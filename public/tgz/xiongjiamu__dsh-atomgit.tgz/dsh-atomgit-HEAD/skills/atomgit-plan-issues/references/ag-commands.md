# `ag` issue commands

The optional repository argument is `owner/repo`; omit it in an unambiguous
AtomGit repository checkout. Use the installed command's `--help` as the source
of truth if it differs from this reference.

```text
ag auth status
ag issue list [<owner>/<repo>] [--state open|closed|all] [--limit <count>] [--json]
ag issue view [<owner>/<repo>] <number> [--json] [--web]
ag issue create [<owner>/<repo>] --title <title> [--body <body> | --body-file <path-or->]
```

`ag issue list` defaults to `--state open` and `--limit 30`; use
`--state all --limit 100` for the deduplication pass. Short forms are `-s` for
state, `-L` for limit, `-t` for title, `-b` for body, and `-F` for body file.
Use `--body-file` for multiline issue bodies; pass `-` to read the body from
stdin. Do not combine `--json` with `--web`.
