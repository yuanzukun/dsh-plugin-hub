---
name: atomgit-plan-issues
description: Analyze the current codebase for concrete missing features, incomplete implementations, defects, tests, and documentation, then draft or create deduplicated AtomGit issues with actionable scope and acceptance criteria. Use when asked to audit a repository, identify work that remains, build a backlog, or automatically create AtomGit issues from repository evidence using the ag CLI.
---

# Plan AtomGit Issues

Turn repository evidence into a small, prioritized set of independently actionable issues. Read [references/ag-commands.md](references/ag-commands.md) before invoking `ag`.

## Workflow

1. Establish repository context.
   - Read every applicable `AGENTS.md` and the main project documentation.
   - Inspect `git status`, recent history, remotes, build configuration, tests, and the primary code paths.
   - Resolve `<owner>/<repo>` from the AtomGit remote. If it is ambiguous, state the selected repository before any remote write.
2. Find evidence, not speculation.
   - Search for TODO/FIXME markers, stubs, unregistered commands, inconsistent public behavior, missing error handling, weak test coverage, and documentation/code drift.
   - Run safe static checks or tests when useful. Do not treat a failed dependency download as a product defect.
   - Trace each candidate to specific files, symbols, output, or reproducible behavior.
3. Deduplicate against existing work.
   - Run `ag issue list <owner>/<repo> --state all --limit 100`.
   - View likely matches before deciding that a new issue is needed.
   - Drop duplicates and candidates already implemented on the default branch.
4. Rank and scope candidates.
   - Prefer user-visible gaps, correctness, security, data loss, and broken workflows.
   - Split candidates when they can be implemented and verified independently.
   - Exclude broad rewrites and style-only cleanup unless repository evidence shows material value.
5. Draft each issue with:
   - a concise, outcome-oriented title;
   - evidence and current behavior;
   - desired behavior;
   - a bounded implementation scope;
   - testable acceptance criteria;
   - relevant file paths without prescribing an unnecessarily rigid implementation.
6. Create issues only when the user explicitly requested remote creation. Otherwise return the drafts for approval. Use one `ag issue create` call per accepted issue and record every returned issue number and URL.
7. Report created, skipped-as-duplicate, and deferred candidates separately.

## Quality Bar

- Never invent behavior from filenames alone; inspect the implementation.
- Never create an issue solely because a TODO exists; confirm that it is current and valuable.
- Keep one outcome per issue and avoid overlapping acceptance criteria.
- Do not expose tokens, credentials, private configuration, or sensitive source excerpts in issue bodies.
- Stop before remote creation if authentication, repository identity, or user intent is uncertain.
