---
name: atomgit-publish-cli-release
description: Fully test AtomGit CLI with local and real-account checks, update its Debian CHANGELOG.md, publish and verify the tag, AtomGit Release artifacts, seven npm platform packages and launcher, then remind the user to notify downstream package maintainers. Use when asked to release or publish a new atomgit-cli version, retry a partial release, validate release readiness, or audit an already published version end to end.
---

# Publish AtomGit CLI Release

Publish from the `hust-open-atom-club/atomgit-cli` repository with explicit
checkpoints and resumable operations. Read [references/release-workflow.md](references/release-workflow.md)
before running release commands.

## Release contract

- Read every applicable `AGENTS.md`, `README.md`, `CHANGELOG.md`, release guide,
  repository scripts, and live command help; treat the checked-out repository as
  authoritative when this skill differs.
- Resolve the AtomGit remote, default branch, exact `vX.Y.Z` version, release
  channel, target commit, test account and disposable test repository, npm
  registry, and downstream package channels. Ask for a missing version or
  unsafe test target; never infer either one.
- Fetch the default branch and tags. Require a clean worktree on the intended
  default branch and record the initial HEAD before release preparation.
- Inspect the tag, AtomGit Release, seven platform packages, and launcher
  package. Classify each as absent, complete, incomplete, or conflicting;
  resume matching partial work and stop on conflicts.
- Before the first remote write, report the exact version, commit, test targets,
  publication destinations, artifact counts, and downstream reminder list. An
  explicit request to publish authorizes only these scoped writes.

## Six-stage workflow

1. Fully test the current version with local and real-account validation.
   - Build the current checkout and use that binary, never a previously installed
     `ag`, for all functional checks.
   - Run the complete repository format, vet, unit, race, build, npm, packaging,
     archive, checksum, and snapshot checks described in the reference.
   - Derive a real-account test matrix from the current command tree and docs.
     Cover every feature family with either a read-only live operation or a
     reversible mutation in the dedicated test repository.
   - Record each live target and result. Delete only objects created by this test
     run, verify cleanup, and never mutate credentials, SSH keys, collaborators,
     production repositories, or pre-existing user data for coverage.
   - Stop before release preparation if any required local or live check fails,
     the test account is not authenticated, or a safe test namespace is missing.

2. Add the version changes to `CHANGELOG.md` and prepare the release commit.
   - Compare the newest published release for the selected channel with the
     recorded HEAD. Verify the previous tag is an ancestor and inspect commits,
     diffs, PRs, issues, and contributors rather than trusting subjects alone.
   - Prepend one Debian-format `atomgit-cli (vX.Y.Z)` stanza to `CHANGELOG.md`,
     following the repository's existing urgency, bullet, maintainer, timestamp,
     and wrapping conventions. Include only verified user-visible changes.
   - Generate a temporary Markdown Release Notes file from that exact changelog
     stanza. Formatting and verified PR/contributor references may be added, but
     the notes must not claim changes absent from the stanza.
   - Synchronize all npm versions with `npm run version:npm -- X.Y.Z`, review the
     complete preparation diff, rerun affected checks and the release snapshot,
     then commit only the changelog and release-preparation files.

3. Create and push the release tag.
   - Recheck that the worktree is clean and all required checks passed at the
     exact commit.
   - Follow the repository's existing tag type. Never move, recreate, or
     force-push an existing version tag.
   - Push the release commit and tag to the AtomGit remote without force.
   - Confirm the remote tag resolves to the exact release commit.

4. Create the AtomGit Release from the changelog and upload artifacts.
   - Run the repository's authoritative release publication entry only after the
     remote tag points to HEAD. Use the generated notes file and exact commit.
   - Verify every checksum scope, archive path, native binary version, metadata,
     and expected attachment before and after upload. Never attach npm tarballs.
   - Treat publication as resumable. Skip an existing attachment only after
     downloading and proving it matches; never overwrite a conflict.

5. Publish all npm packages and verify automatic platform selection.
   - Inspect and verify every generated tarball. Publish all seven immutable
     platform packages first and wait until each exact version is visible.
   - Publish the launcher only after all platform packages are visible. Confirm
     its optional dependencies select the package for the current OS and CPU.
   - Install the exact launcher version in a temporary prefix, run `ag version`,
     compare it with the tag, and remove the prefix.

6. Remind the user to notify downstream package maintainers.
   - Discover the currently documented package-manager channels from repository
     docs and the published artifact manifest. At minimum include Homebrew,
     Scoop, WinGet, and Nix/nixpkgs when they remain documented.
   - Give the user a concise handoff checklist containing the exact version,
     tag and Release URL, channel-specific artifact names and checksums, and the
     maintainer or team when repository evidence identifies one.
   - Do not contact maintainers, send messages, create or update downstream
     issues or PRs, modify package repositories, or submit anything for review.
     The reminder completes this stage; downstream acceptance is outside scope.

## Completion and recovery

- Read back the AtomGit tag and Release, download compatible artifacts and
  verify checksums, and record all eight npm versions plus the downstream
  maintainer reminder.
- Report completed, skipped matching, and blocked publication destinations
  separately. On failure, state the last proven stage and exact safe resume
  point; never delete a published tag, Release, or package unless explicitly
  asked.
- If GitHub mirroring was requested, hand the verified AtomGit tag and Release
  to `$atomgit-mirror-to-github`; mirroring does not replace the reminder.

## Safety Rules

- Never print, read back, or interpolate authentication tokens.
- Never publish snapshot artifacts.
- Never attach npm tarballs to AtomGit Releases.
- Never publish the main npm launcher before all platform packages are visible.
- Never use a real account to exercise destructive or account-wide features;
  use read-only checks or disposable objects in the declared test namespace.
- Never treat command exit status alone as publication proof; perform remote
  read-back and consumer-level checks.
- Preserve unrelated worktree changes and stop if they prevent a clean release.
