# AtomGit CLI release workflow

Use live `--help` output and repository scripts when they differ from this
reference.

## Contents

- [Release surfaces](#release-surfaces)
- [Preflight](#preflight)
- [Full current-version validation](#full-current-version-validation)
- [Changelog and release notes](#changelog-and-release-notes)
- [Prepare the release commit and tag](#prepare-the-release-commit-and-tag)
- [Artifact verification](#artifact-verification)
- [AtomGit publication](#atomgit-publication)
- [npm publication](#npm-publication)
- [Downstream maintainer reminder](#downstream-maintainer-reminder)
- [End-to-end verification and recovery](#end-to-end-verification-and-recovery)

## Release surfaces

| Surface | Expected content |
| --- | --- |
| AtomGit tag | `vX.Y.Z` at the release commit |
| AtomGit Release | Seven ordinary archives, two installers, root checksum, fifteen managed archives, managed manifest, and managed checksum |
| npm | Seven platform packages, then `@hust-open-atom-club/atomgit-cli` |
| Downstream packaging | A user reminder with the published inputs for each documented channel |

The root `checksums.txt` covers the seven ordinary archives and two installers.
`package-managers/package-managers-checksums.txt` covers the fifteen managed
archives. The separate `npm/checksums.txt` covers eight npm tarballs. Never mix
the three checksum scopes.

## Preflight

Run from the `atomgit-cli` repository:

```text
git status --short --branch
git remote -v
git fetch <atomgit-remote> --tags --prune
ag auth status
npm whoami
go version
node --version
goreleaser --version
```

Read `AGENTS.md`, `README.md`, `CHANGELOG.md`, `docs/releasing.md`, `Makefile`,
`.goreleaser.yaml`, `scripts/build-release.sh`, `package.json`, and the package
manager manifest generator. Inspect live help:

```text
ag release --help
ag release create --help
ag release upload --help
npm publish --help
```

Resolve and record:

- the exact version and stable or prerelease channel;
- the initial full HEAD, default branch, and AtomGit remote;
- the authenticated AtomGit and npm identities without exposing tokens;
- a dedicated real-account test repository or namespace;
- every documented downstream package channel to include in the final reminder.

Check remote state before writing:

```text
git ls-remote --tags <atomgit-remote> refs/tags/vX.Y.Z
ag release view hust-open-atom-club/atomgit-cli vX.Y.Z
npm view @hust-open-atom-club/atomgit-cli@X.Y.Z version
```

Also query all seven platform package names. A not-found result is expected for
a new version; authentication, DNS, and permission errors are not.

## Full current-version validation

Build a temporary local binary from the recorded checkout and use its absolute
path for every real-account test. Do not allow `PATH` to select an installed
copy accidentally. Derive `<current-version>` from the checked-in npm metadata;
it is the version under test and may differ from the requested next version.
Run the complete local suite before changing version files:

```text
git diff --check
test -z "$(gofmt -l .)"
go vet ./...
go test ./...
go test -race ./...
go build -trimpath -o <temporary-directory>/ag ./cmd/ag
npm test
make release-snapshot VERSION=v<current-version>
```

Verify all snapshot checksum scopes, archive inventories, archive paths,
installers, npm tarball metadata, and the compatible native binary. A snapshot
is test-only and must never be uploaded. Do not pass the requested next version
to this pre-change snapshot because its npm metadata has not been synchronized
yet; build `vX.Y.Z` only in the release-preparation stage below.

Create a temporary real-account checklist from the locally built command's
current `--help` tree and `docs/usage.md`. Group commands by feature family,
including authentication, repositories, branches and protection, tags, issues,
pull requests and comments, releases, Actions, organizations, collaborators,
labels, webhooks, SSH keys, search, browse, API, version, and update checks.
For each family record:

1. the exact local-binary command and authenticated identity;
2. the declared test repository or other live target;
3. a read-only operation or reversible mutation that proves live API behavior;
4. expected and actual output, including structured output when supported;
5. created object identifiers and the verified cleanup result.

Use read-only coverage for account-wide or high-impact surfaces such as auth
mutation, SSH keys, collaborators, browser launch, repository deletion, and
production settings. Create mutable objects only inside the declared disposable
test repository. Never alter pre-existing objects merely to increase coverage,
and never print credentials or raw authentication responses. Stop the release
if a required family is untested, a live check fails, or cleanup cannot be
verified.

## Changelog and release notes

After all current-version tests pass, identify the changelog comparison range:

```text
notes_head=$(git rev-parse HEAD)
ag release list hust-open-atom-club/atomgit-cli --limit 100
git merge-base --is-ancestor <previous-release-tag> "$notes_head"
git log --first-parent --reverse --format=fuller <previous-release-tag>.."$notes_head"
git diff --stat <previous-release-tag>.."$notes_head"
git diff --name-status <previous-release-tag>.."$notes_head"
```

Select `<previous-release-tag>` from the latest published AtomGit Release for
the requested stable or prerelease channel, not merely from local tag sorting.
Confirm the tag exists on the AtomGit remote, resolves locally, and is an
ancestor of `notes_head`. Stop for direction if the release cannot be mapped to
a trustworthy local tag.

Use the first-parent history as the primary list so merged branches are not
reported twice. Inspect the full range and relevant diffs to understand terse
or ambiguous subjects. Read referenced PRs and issues when available. Prepend a
Debian-format stanza to `CHANGELOG.md` using the repository's established
package name, `vX.Y.Z` version spelling, distribution, urgency, indentation,
maintainer identity, RFC 2822 timestamp, and line wrapping:

```text
atomgit-cli (vX.Y.Z) unstable; urgency=medium

  * Verified user-visible change.

 -- <configured maintainer identity>  <RFC 2822 timestamp>
```

Do not invent a maintainer identity. Use an explicitly configured release
identity consistent with repository convention, and stop if it is unavailable.
Summarize features, fixes, packaging, and documentation in concise bullets;
exclude merge boilerplate, generated files, internal preparation commits, and
unsupported claims.

Use the new changelog stanza as the sole content source for a temporary Markdown
Release Notes file. It may regroup the same bullets and add verified PR and
contributor references plus the comparison range, but it must not introduce a
change absent from the stanza:

```markdown
## Highlights

- The most important verified user-visible changes.

## Features

- Change summary (!PR, when verified)

## Fixes

- Change summary (!PR, when verified)

## Packaging and installation

- Change summary (!PR, when verified)

## Documentation

- Change summary (!PR, when verified)

**Full comparison:** `<previous-release-tag>..<notes-head-short-sha>`
```

Omit empty sections and Highlights when there is no defensible highlight.
Present the changelog stanza and derived notes before the first remote write.

## Prepare the release commit and tag

Use the version without `v` for npm metadata:

```text
npm run version:npm -- X.Y.Z
git diff --check
git diff
test -z "$(gofmt -l .)"
go test -race ./...
go test ./...
go vet ./...
go build ./cmd/ag
npm test
make release-snapshot VERSION=vX.Y.Z
```

Use a writable temporary `GOCACHE` if the managed environment blocks the
default cache. Review the complete diff and commit only `CHANGELOG.md`, the npm
version files, and other proven release-preparation files. The changelog and npm
version synchronization belong to the same release commit.

After committing, recheck every required check at the exact commit. Create the
repository's normal tag type, push the release commit and tag to AtomGit without
force, and confirm the remote tag resolves to the full local HEAD. Never move an
existing tag. Run the final build only when the clean worktree, HEAD, local tag,
and remote tag all resolve to the same commit:

```text
make release VERSION=vX.Y.Z
```

## Artifact verification

The root directory `dist/vX.Y.Z/` must contain exactly:

```text
ag_linux_amd64.tar.gz
ag_linux_arm64.tar.gz
ag_linux_loong64.tar.gz
ag_darwin_amd64.tar.gz
ag_darwin_arm64.tar.gz
ag_windows_amd64.zip
ag_windows_arm64.zip
install.sh
install.ps1
checksums.txt
```

The root also contains `package-managers/` with fifteen managed archives,
`package-managers-manifest.json`, and `package-managers-checksums.txt`. The
`dist/vX.Y.Z/npm/` directory must contain eight `.tgz` files plus
`checksums.txt`. Verify all three checksum manifests with `sha256sum -c` on
Linux or `shasum -a 256 -c` on macOS. Inspect every archive for the expected
`ag` or `ag.exe` path and reject absolute paths or `..` traversal entries.

## AtomGit publication

Prefer the repository's authoritative single publication entry, which rebuilds,
validates, creates or resumes the Release, uploads attachments, and reads them
back:

```text
make publish VERSION=vX.Y.Z NOTES_FILE=<notes-file>
```

The underlying equivalent creates metadata with the changelog-derived notes
file and exact target commit:

```text
ag release create hust-open-atom-club/atomgit-cli vX.Y.Z --name "vX.Y.Z" --body-file <notes-file> --target <commit>
ag release upload hust-open-atom-club/atomgit-cli vX.Y.Z <file> [--name <asset-name>] [--skip-existing | --overwrite] [--timeout <duration>]
ag release view hust-open-atom-club/atomgit-cli vX.Y.Z
```

Add `--prerelease` when requested. Upload each file printed by
`scripts/build-release.sh` as an independent AtomGit Release attachment,
including files stored locally under `package-managers/`. For a safe resume,
list current attachments first and use `--skip-existing` only after downloading
and verifying an existing attachment. Do not use `--overwrite` without explicit
conflict resolution.
Short forms are `-n` for release or asset name, `-b` for body, `-F` for body
file, and `-L` for the release-list limit.

Read back with `ag release view`. When structured verification is needed, use
the authenticated generic API command against the documented release endpoint
instead of parsing presentation text.

## npm publication

Derive package names and tarball filenames from generated package metadata; do
not hard-code glob order. For every tarball:

1. Inspect `npm pack --dry-run --json`.
2. Confirm its name and version.
3. Confirm the version is absent from the registry.
4. Publish with public access.
5. Poll `npm view <name>@<version> version` until visible.

Publish all seven platform packages before the main package. npm versions are
immutable: if a version already exists, verify its registry metadata and stop
on any uncertainty rather than attempting replacement.

After the launcher is visible, install its exact version into a temporary
prefix on the current platform. Confirm the selected optional dependency matches
the current OS and CPU and that `ag version` reports the exact tag.

## Downstream maintainer reminder

After AtomGit and npm verification succeeds, discover the current channel list
from the installation docs and the published package-manager manifest. Include
Homebrew tap, Scoop bucket, WinGet, and Nix/nixpkgs when they remain documented;
do not assume old repository names or maintainer identities.

Return a concise reminder for the user to notify the relevant package-manager
maintainers. For each channel include:

- exact `vX.Y.Z` and AtomGit Release URL;
- the intended published artifact names, download URLs, architectures, and
  SHA-256 values from the Release manifest;
- the package name and current maintainer or team only when repository evidence
  identifies them;
- a request to update the package and submit it through that channel's normal
  review process.

This stage is read-only. Do not contact anyone, send email or chat messages,
modify a downstream repository, open or edit an issue or PR, request reviewers,
or submit a package for review. The reminder itself completes stage 6; do not
wait for downstream packaging or treat its acceptance as a release blocker.

## End-to-end verification and recovery

- Confirm the AtomGit tag resolves to the release commit.
- Confirm the AtomGit Release title, notes, state, and the exact asset names
  printed by the release build.
- Confirm the Release body is derived from the committed `CHANGELOG.md` stanza.
- Download each checksum manifest and one compatible archive from AtomGit;
  verify the archive and run `ag version`.
- Install `@hust-open-atom-club/atomgit-cli@X.Y.Z` into a temporary npm prefix
  and run its `ag version`.
- Return the AtomGit URL, all npm package versions, commit, tag, real-account
  test checklist and cleanup status, and the downstream maintainer reminder.

Report complete, skipped matching, and blocked publication destinations
separately. On failure, preserve already published immutable objects, identify
the last proven stage, and give the exact safe resume command or action.

GitHub repository and Release mirroring belong to
`$atomgit-mirror-to-github`. Invoke that skill separately only when the user
requests the GitHub mirror.
