---
name: atomgit-mirror-to-github
description: Create, update, resume, and verify a GitHub mirror of an AtomGit repository, including only the main branch, tags, Git LFS objects, repository metadata, and optionally Releases and their assets. Use when asked to mirror, synchronize, migrate, back up, or copy an AtomGit repository to GitHub.
---

# Mirror AtomGit to GitHub

Mirror repository state without assuming that destructive ref synchronization
is desired. Read [references/mirror-workflow.md](references/mirror-workflow.md)
before invoking Git or host-management commands.

## Workflow

1. Define the mirror contract.
   - Resolve the exact AtomGit source and GitHub destination.
   - Limit Git branch synchronization to `refs/heads/main`. Do not enumerate,
     fetch, push, compare, delete, or rewrite any other branch.
   - Determine whether the request also includes tags, LFS objects, repository
     metadata, Releases, and wiki history.
   - Default to additive synchronization: create a missing `main`, fast-forward
     an existing `main`, and create missing tags without deleting or rewriting
     GitHub state.
   - Treat exact parity for `main` and tags as a separate destructive mode.
     Before using it, list every GitHub-only tag that would be deleted and every
     divergent included ref that would be rewritten, then obtain explicit
     authorization. Other branches remain out of scope in every mode.

2. Inspect both hosts before writing.
   - Read applicable repository guidance and inspect local remotes when a
     checkout is available.
   - Authenticate with `ag`, `gh`, Git, and Git LFS as required without
     displaying credentials.
   - Use `ag repo view --json` and `gh repo view --json` to compare visibility,
     default branch, description, homepage, and archive state.
   - Inspect source and destination `main`, tags, LFS usage, submodules,
     workflows, releases, and release assets. Do not inventory other branches.
   - Stop if the destination is ambiguous, belongs to an unexpected owner, or
     is more public than the source without explicit approval.

3. Prepare an isolated Git mirror.
   - Use a temporary bare repository and explicit fetch refspecs for
     `refs/heads/main` and `refs/tags/*`.
   - Do not import AtomGit merge-request refs, temporary host refs, or local
     remote-tracking refs. Do not import any branch other than `main`.
   - Inspect ref differences before pushing. Reject a non-fast-forward `main`
     and conflicting tags in additive mode.
   - If Git LFS is used, transfer all reachable LFS objects before publishing
     refs that point to them.

4. Create or update the GitHub repository.
   - If the destination is absent and creation is authorized by the mirror
     request, create it with matching or stricter visibility and without
     generated README, license, or `.gitignore` commits.
   - Push `main` and tags without force in additive mode.
   - Set the GitHub default branch to `main` only after it exists.
   - Preserve every target-only branch. Preserve target-only tags unless exact
     parity for tags was explicitly authorized.
   - Warn that pushed `.github/workflows` may execute on GitHub; never copy
     secrets, deploy keys, tokens, webhooks, or environment credentials.

5. Mirror optional surfaces deliberately.
   - Copy description and homepage when requested; do not loosen visibility or
     archive the destination implicitly.
   - Treat submodules as Gitlink references. Report their URLs and do not
     create or migrate the referenced repositories unless separately requested.
   - Migrate wiki history only when requested and only through its separate Git
     repository.
   - Migrate Releases only after their tags exist on GitHub. Enumerate AtomGit
     metadata and explicit attachments, then preserve titles, notes,
     prerelease/latest state, and attachment contents.
   - Treat an existing GitHub Release as a resume or conflict case. Upload only
     proven-missing assets to matching metadata; stop on differing notes,
     status, names, sizes, or hashes instead of clobbering.
   - Copy explicit AtomGit attachments but not host-generated source archives.
   - Do not claim to preserve Issues, Pull Requests, discussions, reviews,
     identities, branch protections, Actions secrets, or analytics. These are
     outside Git transport and require separate migration work.

6. Verify authoritative parity.
   - Re-read `refs/heads/main` and both remote tag maps and compare object IDs.
     Do not read or compare other branches.
   - Verify the GitHub default branch and repository visibility.
   - For LFS repositories, clone from GitHub into a temporary directory and
     confirm representative LFS objects materialize rather than remaining
     pointer files.
   - For Releases, compare tag, title, notes, prerelease/latest state,
     attachment names, sizes, and SHA-256 digests after downloading from both
     hosts.
   - Report mirrored, skipped, divergent, and excluded surfaces separately.
     State explicitly that branches other than `main` were not processed.
     Never report success from a push exit code alone.

## Safety Rules

- Never use `git push --mirror` as the default; it can publish internal refs and
  delete unrelated destination refs.
- Never force-push or delete `main`, tags, change visibility, or overwrite
  Release assets without explicit authorization for those exact effects.
- Never modify or delete a branch other than `main`, including in exact parity
  mode.
- Never mirror credentials or expose authenticated remote URLs in output.
- Never use a working repository with unrelated changes as temporary state.
- Keep temporary mirrors outside the source checkout and remove them after
  verification.
- On partial failure, retain remote state, identify the last verified stage,
  and provide a safe resume point instead of rolling back automatically.
