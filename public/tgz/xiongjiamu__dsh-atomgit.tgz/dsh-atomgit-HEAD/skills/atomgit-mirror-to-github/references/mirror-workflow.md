# AtomGit to GitHub mirror workflow

Use installed command help as the source of truth when it differs from this
reference.

## Scope matrix

| Surface | Default | Method | Important boundary |
| --- | --- | --- | --- |
| `main` branch | Yes | Git | The only branch processed; fast-forward or create only |
| Other branches | No | None | Do not inspect, fetch, push, compare, or delete |
| Tags | Yes | Git | Never replace a conflicting tag by default |
| Git LFS | When detected | Git LFS | Transfer objects before refs |
| Description/homepage | Inspect | `ag` and `gh` | Change only when requested |
| Visibility | Preserve | `gh repo create/edit` | Never make the mirror more public implicitly |
| Releases | Optional | `ag release` and `gh release` | Copy explicit assets, not generated sources |
| Wiki | Optional | Separate Git repository | Not part of the main repository refs |
| Issues/PRs/secrets/rules | No | Separate migration | Git mirroring cannot preserve these faithfully |

## Preflight

Resolve and record:

```text
SOURCE=atomgit-owner/repository
DESTINATION=github-owner/repository
SOURCE_URL=<authenticated-or-public-atomgit-git-url>
DESTINATION_URL=<github-git-url>
```

Do not print URLs containing embedded credentials. Check tools and host state:

```text
ag auth status
gh auth status
git --version
git lfs version
ag repo view [<owner>/<repo>] --json
gh repo view DESTINATION --json
git ls-remote --symref SOURCE_URL HEAD
git ls-remote SOURCE_URL refs/heads/main
git ls-remote --tags SOURCE_URL
git ls-remote --symref DESTINATION_URL HEAD
git ls-remote DESTINATION_URL refs/heads/main
git ls-remote --tags DESTINATION_URL
```

A missing GitHub repository is different from an authentication or network
failure. Create a destination only after confirming the exact owner, name, and
visibility. Do not use `--add-readme`, `--license`, or `--gitignore`, because
they create a destination-only root commit.

Stop if `refs/heads/main` does not exist at the AtomGit source. Do not fall back
to another source branch, and do not use `git ls-remote --heads` because other
branches are outside this workflow.

## Isolated ref transfer

Create a temporary directory with `mktemp -d` and initialize a bare repository.
Use explicit refspecs:

```text
git init --bare <temporary-repository>
git -C <temporary-repository> remote add atomgit SOURCE_URL
git -C <temporary-repository> fetch --prune atomgit \
  '+refs/heads/main:refs/heads/main' \
  '+refs/tags/*:refs/tags/*'
git -C <temporary-repository> remote add github DESTINATION_URL
```

This intentionally excludes every branch other than `main` as well as
host-specific merge-request refs. Before pushing, compare the included source
and destination refs. In additive mode:

- allow a missing destination ref;
- allow `main` when the destination commit is an ancestor of the source;
- allow an existing tag only when its ref object and peeled target match;
- stop on destination-ahead or divergent `main`, or a conflicting tag.

Push without force:

```text
git -C <temporary-repository> push github \
  'refs/heads/main:refs/heads/main'
git -C <temporary-repository> push github \
  'refs/tags/*:refs/tags/*'
```

Avoid `--all` when the bare repository may contain helper refs. Avoid
`git push --mirror`, which includes every ref namespace and enables deletions.

## Exact parity mode

Exact parity is destructive. Build and show two explicit plans before acting:

1. GitHub-only tags that would be deleted.
2. Divergent `main` or same-name tags that would require rewriting.

Require authorization for the displayed plan. Scope branch operations to
`refs/heads/main` and tag operations to `refs/tags/*`; never broaden exact
parity to other heads or `refs/*`. Preserve every branch other than `main`
without enumerating or comparing it. Re-query the included refs immediately
before applying the plan so concurrent changes are detected. Prefer
`--force-with-lease=<ref>:<observed-object-id>` over unconditional force for
each authorized rewrite.

## Git LFS

Detect LFS through `.gitattributes` and `git lfs ls-files --all`. When present:

```text
git -C <temporary-repository> lfs fetch --all atomgit
git -C <temporary-repository> lfs push --all github
```

Because the temporary repository contains only `main` and tags,
`lfs fetch --all` remains limited to objects reachable through those included
refs. Transfer LFS content before `main` and tags. Afterward, perform a fresh
GitHub clone with LFS smudge enabled and verify representative tracked files do
not contain only the LFS pointer header.

If Git LFS is unavailable or the destination quota rejects objects, stop before
claiming parity. Do not silently mirror only pointer files.

## Destination metadata

For a new repository, use `gh repo create` non-interactively with matching or
stricter visibility. For an existing repository, inspect before editing:

```text
gh repo view DESTINATION --json nameWithOwner,visibility,defaultBranchRef,description,homepageUrl,isArchived
```

After refs are present, set the default branch to `main` when requested. Copy
description and homepage only when they are intended to stay synchronized. Do
not copy credentials embedded in homepage or clone URLs.

Inspect `.github/workflows` before pushing and report that GitHub Actions may
run. Secrets, variables, environments, webhooks, deploy keys, collaborators,
branch protections, rulesets, and Pages settings are not Git data.

## Release migration

Enumerate AtomGit Releases and their explicit `type=attach` assets. Use the
current `ag release list/view/download` commands or structured `ag api` output
instead of scraping a web page.

Current command shapes are:

```text
ag release list [<owner>/<repo>] [--limit <count>]
ag release view [<owner>/<repo>] <tag>
ag release download [<owner>/<repo>] <tag> <asset> --output <path> [--overwrite] [--timeout <duration>]
ag api <relative-v5-endpoint> [--paginate]
```

Short forms are `-L` for the release-list limit and `-o` for the download
output path. `--output` is required; download refuses to replace an existing
file unless `--overwrite` is explicit.

For each release:

1. Record the AtomGit tag, target commit, title, body, release status, and every
   explicit attachment name, size, and download identity.
2. Confirm the same tag exists on GitHub at the expected Git object. Never let
   `gh release create` synthesize a tag from the default branch.
3. Read the GitHub Release if it already exists and classify it as complete,
   incomplete, or conflicting.
4. Download AtomGit attachments into a tag-specific temporary directory.
5. Compute SHA-256 and record asset name and size before any GitHub write.
6. Create a missing GitHub Release with the exact title and a notes file, using
   `--verify-tag` and `--prerelease` or `--latest` when the source state
   requires it.
7. For a matching incomplete Release, upload only assets whose names are absent.
   Never replace an existing same-name asset without explicit conflict
   resolution.
8. Re-read GitHub metadata, download every explicit GitHub asset, and compare
   title, body, status, asset name, size, and SHA-256 with the AtomGit source.

Typical GitHub inspection and creation commands are:

```text
gh release view TAG --repo DESTINATION \
  --json tagName,name,body,isPrerelease,isDraft,assets
gh release create TAG <explicit-asset-files...> \
  --repo DESTINATION \
  --verify-tag \
  --title <title> \
  --notes-file <notes-file>
```

Add `--prerelease` when the AtomGit Release is a prerelease. Preserve the
source latest designation when GitHub supports an equivalent state. Before
resuming, download existing assets with `gh release download` and verify them;
do not accept matching names as proof of matching content.

Do not upload AtomGit-generated source archives: GitHub provides its own source
archives. Do not use clobber to hide an asset conflict. If a matching checksum
manifest exists, verify it in addition to comparing per-file hashes.

## Verification report

Report:

- source and destination repository URLs;
- source and GitHub default branches;
- exact object-ID parity for `main` and every mirrored tag;
- confirmation that branches other than `main` were not inspected or modified;
- LFS object verification or an explicit “not used” result;
- Release counts and asset verification when included;
- destination-only tags preserved in additive mode and confirmation that other
  branches were untouched by construction;
- non-Git surfaces that were excluded.

Remove temporary repositories only after recording the verification evidence.
