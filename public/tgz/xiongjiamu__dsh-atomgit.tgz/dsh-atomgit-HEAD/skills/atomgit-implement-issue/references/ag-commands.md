# `ag` and Git commands

The optional repository argument is `owner/repo`; omit it in an unambiguous
AtomGit repository checkout. Use the installed command's `--help` as the source
of truth if it differs from this reference.

```text
ag auth status
ag issue view [<owner>/<repo>] <number> [--json] [--web]
ag issue comment view [<owner>/<repo>] <number>
ag pr create [<owner>/<repo>] --title <title> [--body <body> | --body-file <path-or->] [--base <branch>] [--head <branch>]
ag pr link-issues [<owner>/<repo>] <pr-number> --issue <issue-number> [--issue <issue-number> ...]
ag pr issues [<owner>/<repo>] <pr-number>
ag pr view [<owner>/<repo>] <pr-number> [--json] [--web]
ag pr merge [<owner>/<repo>] <pr-number> [--squash] [--rebase] [--admin] [--subject <text>] [--body <text>] [--delete-branch]
```

Short forms are `-t` for the PR title, `-b` for the body, `-F` for the body
file, and `-i` for each issue link. `--base` defaults to the repository's
default branch. Use `--body-file` for multiline PR bodies; pass `-` to read the
body from stdin.

Use Git for branch creation, commits, and pushes. For a fork, `--head` may need `<fork-owner>:<branch>` rather than only the branch name. Never place tokens in Git remote URLs or command arguments.

`ag pr merge` changes repository history immediately and has no built-in confirmation prompt. It is outside the implementation workflow: invoke `$atomgit-merge-pr` only when the current user request explicitly authorizes merging the specific PR. Never infer merge, `--admin`, or branch-deletion permission from implementation or submission authority.
