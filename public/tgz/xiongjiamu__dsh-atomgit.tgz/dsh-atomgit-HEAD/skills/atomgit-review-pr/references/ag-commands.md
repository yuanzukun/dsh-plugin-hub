# `ag` review commands

The optional repository argument is `owner/repo`; omit it in an unambiguous
AtomGit repository checkout. Use the installed command's `--help` as the source
of truth if it differs from this reference.

```text
ag auth status
ag pr view [<owner>/<repo>] <pr-number> [--json] [--web]
ag pr diff [<owner>/<repo>] <pr-number>
ag pr issues [<owner>/<repo>] <pr-number>
ag pr comment view [<owner>/<repo>] <pr-number>
ag pr checks [<owner>/<repo>] <pr-number> [--watch] [--interval <duration>]
ag issue view [<owner>/<repo>] <issue-number> [--json] [--web]
ag pr comment create [<owner>/<repo>] <pr-number> [--body <text> | --body-file <path>]
ag pr review <owner>/<repo> <pr-number> --approve [--force]
ag pr merge [<owner>/<repo>] <pr-number> [--squash] [--rebase] [--admin] [--subject <text>] [--body <text>] [--delete-branch]
```

`ag pr diff` supports no command-specific flags, including `--json`. For a PR comment, choose `-b`/`--body` or `-F`/`--body-file`. The command publishes a general PR comment rather than a line-specific thread, so include file paths and line numbers in its Markdown body. Store a multiline review in a temporary file, publish it with `--body-file`, and remove the temporary file afterward.

`ag pr checks` reads workflow runs for the PR's current head commit. It returns
nonzero when no current-head run exists, any run failed or was canceled, or
checks remain pending without `--watch`. With `--watch`, it polls until a
terminal state. The command reports observed runs but does not infer which
checks repository policy requires. In an ordinary review, report this state
without treating it as merge authorization.

`ag pr review` uses AtomGit's formal review API, which currently supports
approval only. The current command requires an explicit `owner/repo`;
`--approve` is required, and `--force` performs administrator approval. Use
`ag pr comment create` for ordinary comments because request-changes reviews
and review bodies are not supported by the public API. Never infer approval or
administrator-force authorization from a general review request.

`ag pr merge` is not a review action and has no built-in confirmation prompt. Do not invoke it from an ordinary review request. When the current user explicitly authorizes merging the specific PR, use `$atomgit-merge-pr` after the review is complete; require separate authorization for `--admin` and `--delete-branch`.
