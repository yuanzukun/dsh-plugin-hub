# `ag` PR merge commands

The optional repository argument is `owner/repo`; omit it in an unambiguous
AtomGit repository checkout. Use the installed command's `--help` as the source
of truth if it differs from this reference.

## Read-only preflight

```text
ag auth status
ag pr checks --help
ag pr merge --help
ag pr view [<owner>/<repo>] <number> [--json] [--web]
ag pr issues [<owner>/<repo>] <number>
ag pr comment view [<owner>/<repo>] <number>
ag pr diff [<owner>/<repo>] <number>
ag pr checks [<owner>/<repo>] <number>
ag pr checks [<owner>/<repo>] <number> --watch [--interval <duration>]
ag issue view [<owner>/<repo>] <issue-number> [--json] [--web]
ag api /repos/<owner>/<repo>/pulls/<number>
```

Use the API response to verify `state`, `merged`, `mergeable`, `head.sha`, `head.ref`, `head.repo.full_name`, and `base.ref`. Avoid printing or storing authentication tokens.

## Mandatory pipeline gate

Run `ag pr checks` for every merge. The command first resolves the PR's current
head SHA and filters workflow runs to that exact commit:

- exit zero means every observed current-head run is `COMPLETED` or `IGNORED`;
- failed or canceled runs return nonzero;
- pending runs return nonzero unless `--watch` is used;
- no current-head runs, stale-only runs, authentication failures, and API
  errors return nonzero.

If checks are pending, use `--watch` to poll until they reach a terminal state.
Do not merge unless the command exits successfully. The command does not infer
repository required-check semantics, so do not claim more than the observed
current-head result.

After successful checks, query the PR again and compare `head.sha` with the SHA
that was checked. If it changed, rerun the entire pipeline gate. `--admin` does
not bypass this skill-level requirement.

Short flags for checks are `-w` for `--watch` and `-i` for `--interval`.

## Merge

```text
ag pr merge [<owner>/<repo>] <number>
ag pr merge [<owner>/<repo>] <number> --squash
ag pr merge [<owner>/<repo>] <number> --rebase
ag pr merge [<owner>/<repo>] <number> --rebase --squash
ag pr merge [<owner>/<repo>] <number> --subject <text> --body <text>
ag pr merge [<owner>/<repo>] <number> --admin
ag pr merge [<owner>/<repo>] <number> --delete-branch
```

Short flags are `-s` for `--squash`, `-r` for `--rebase`, `-t` for `--subject`, `-b` for `--body`, and `-d` for `--delete-branch`.

The current command performs the merge immediately and has no `--yes` flag or interactive confirmation. A normal merge is the default. `--squash` can be combined with `--rebase`. `--admin` may bypass repository requirements. Branch deletion runs after a successful merge and can fail independently, so verify both outcomes.

## Verification

```text
ag api /repos/<owner>/<repo>/pulls/<number>
ag api /repos/<head-owner>/<head-repo>/branches/<url-escaped-branch>
```

Treat a missing branch as expected only when deletion was explicitly requested and the merge itself has already been independently verified.
