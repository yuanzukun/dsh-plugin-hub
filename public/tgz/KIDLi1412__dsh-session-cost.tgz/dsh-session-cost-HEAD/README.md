# dsh-session-cost

DSH（DeepSeek Harness）Web 插件：把**本次会话的 Token 费用估算**与 **DeepSeek API 余额**并入输入框下方的**自带统计栏**。

- 费用估算：服务端按**模型逐条计价**——从会话事件日志折叠出每个模型的输入/输出/缓存命中 token（语义与 `dsh-token-meter` 的 `tokenUsage` 投影一致），再按 CNY 单价表（`lib/cost.js`）计算费用，混合多模型的会话也精确。
- 余额查询：复用官方余额接口 `GET {baseURL}/user/balance`（参考插件 [dsh-usage-stats](https://github.com/Ychris12138/dsh-usage-stats) 的余额方案），凭据经 DSH 的 credentials 缝解析，2 分钟内存缓存 + 单飞防抖；`?refresh=1` 可强制绕过缓存（状态栏的 ⟳ 手动刷新即用此参数）。
- 每 30 秒刷新费用、每 5 分钟刷新余额；token 用量变化后自动触发费用刷新；**点击统计栏里的费用 pill** 展开分模型明细与余额构成（充值/赠送），面板内 ⟳ 手动刷新（强制查询上游，成功后短暂显示"已更新 HH:MM"），面板最后一行直接改**低余额阈值**。

## 界面

费用/余额是一个与自带统计项**同款的可点击 pill**，追加在自带统计栏同一行；若该会话自带统计栏整行都不存在（全新会话，或冷会话加载的头一秒），pill 会**先独立显示在输入框上方**（同一套字号/内边距/圆角），统计栏一出现就自动并回那一行：

![自带统计栏里的费用 pill（第三个）与点击展开的明细面板](docs/sample.jpg)

- **点击 pill** 在统计栏上方展开明细面板，用的是自带两个 pill 点击展开时的**同一套皮肤**（圆角 12、`--dsw-specific-menu` 背景、标题 + 分隔线 + `dt/dd` 网格、12/18 字号）：标题行左侧「费用」、右侧总额；网格里**每个模型一行**（输入/输出 tokens 与费用，跨峰谷时附 `高峰/空闲` 拆分），然后是余额与充值/赠送构成——**读数网格只有数字**；再往下是「更新于 HH:MM + ⟳ 手动刷新」一行，其**下一行就是低余额阈值输入框**（`低余额阈值 [ 10 ] 元`，见下）；最底是计价说明。点击面板外或按 `Esc` 关闭。
- 面板以 `position:fixed` 挂到 `document.body` 并做视口夹取（与原生 stat dialog 相同的 measure→place 流程、同样的 8px 间距 / 12px 边距），所以不会被**任何祖先容器的 `overflow`** 裁掉；数据更新走**原地 patch**（不重建节点），因此面板开着时刷新数值不会闪断、也不会丢焦点。
- DSH 0.1.5 起自带统计栏改为 **`StatsPills`**：居中的 flex 行、由带图标的 pill 组成，取代了此前单行省略号文本的 `StatsLine`。本插件的 pill 因此按同一套字号层级、同一 `1px 8px` 内边距、同一 hover / `aria-expanded` 背景渲染，自带 ¥ 图标，视觉上与自带 pill 齐平。
  > **0.2.1 把这一行拆了**：原来一个 `StatsPills` 容器（`data-composer-stats`）装上全部读数，现在 `activity`（轮数/步数）与 `usage`（token/速度）是**两个** composer-dock 条目，各自带单数 `data-composer-stat`；pill 圆角也从 `999px` 改成 `--dsw-radius-sm`（8px）。费用段依旧追加在同一行的末尾，只是这一行现在是 **dock 容器**（两个自带条目的公共父节点）——细节见下文「兼容性 0.3.2」。
- **自带统计栏会"迟到"**：自带读数在会话有步骤或 token 之前渲染 `null`（整行都不存在；0.2.1 起是两个条目各自 `null`），所以插件必须能在统计栏**之后**挂载的情况下仍然接上去——见下文「兼容性」。
- **数据也会迟到**：刚重启 host 时首次费用/余额响应还在路上，组件却已经挂载（费用等第一次 summary、余额等上游查询或缓存）。所以观察器**无条件安装**：曾经在"暂时没东西可画"时干脆不装，结果没有任何人在等统计栏出现，费用段要等页面刷新（数据已被预热）才显示——这就是「每次重启后打开界面都要刷新一次」的原因。现在首个 payload 到达前 `sync()` 只是不画东西，观察器始终在岗。
- **切换会话时整个输入区会被拆掉重建**：打开一个**没有客户端缓存**的会话要等约 1 秒，这一秒里锚点处于**已脱离文档**的子树中。观察器过去只在"宿主仍然连在文档里"时才重新挂载自己——一次这样的回调就让它**永久失效**，费用段再也回不来，只能刷新页面（刷新等于重新挂载、装上新的观察器）。现在重新挂载是**无条件**的（脱离文档的节点依然会派发子树变更），另有一个 1 秒看门狗兜底：只要该显示的 pill 不在位（节点被 React 抹掉、统计栏被整体换掉、锚点换了父节点）就重新接回去。
- **自带统计栏的布局一律不改**：0.1.5 的统计栏是**居中 flex 行**（`width:100%`、`max-width:748px`、`gap:12px`，且不做 `overflow` 裁剪），追加的费用段只是这一组里的第三项，宽度本来就够——插件**不写统计栏的任何行内样式**。0.1.x 早期版本曾需要把统计行放宽才能显示追加段（≤ 0.1.4 的 `StatsLine` 有 748px 上限 + 省略号截断），那个补丁已在 0.2.3 删除。

设置项就在**明细面板里、「更新于 / ⟳」的下一行**：`低余额阈值 [ 10 ] 元`，改完按回车或点开别处即生效。从 0.3.0 起这个值作为**本插件的 profile 配置**保存（DSH 0.2.0 的设置模型：`Config` → 以 entry id `session-cost` 为键的表单 → 写进 profile patch），旧的 `~/.dsh/settings.yaml` 阈值会被 Host 在升级后**一次性抢救**回配置；0.1.1 及更早版本的 localStorage 配置也会在首次加载时自动迁移。

- **低余额阈值**（默认 10 元）：余额**低于**该值时显示为红色，达到或高于时显示为黑色。变红同时作用于明细面板里的「账户余额」和统计栏 pill 的余额读数：

![余额低于阈值时读数变红](docs/sample-red.jpg)

> 0.2.6 起**不再有**「设置 → 插件 → 插件配置 → 会话费用显示」那张卡片：这个阈值只影响本面板与 pill 的颜色，所以编辑器搬进了面板本身（持久化的 namespace 没变，旧值原样沿用）。
>
> 0.1.5 起移除了「独立状态栏」显示方式（统计栏下方单独一行），只保留并入统计栏；旧配置里的 `displayMode` 键会被忽略。

展开面板内容（示例）：

```
费用                                    ¥1.9400
────────────────────────────────────────────────
deepseek-v4-flash     输入 169,013 · 输出 46,512 · ¥1.8900
deepseek-v4-pro       输入 1,000 · 输出 500 · ¥0.0500 · 高峰 ¥0.02 · 空闲 ¥0.03
余额                                    ¥36.44
充值余额                                ¥30.00
赠送余额                                 ¥6.44
更新于 10:32                                 ⟳
低余额阈值                              [ 10 ] 元
费用为估算值：token 用量来自会话日志，单价见官方定价页（…）。
```

## 安装

从 npm 安装：

```powershell
dsh plugin --profile web add @kidli1412/dsh-session-cost
```

从 GitHub 安装：

```powershell
dsh plugin --profile web add github:KIDLi1412/dsh-session-cost
```

本地开发（链接安装，改动即时生效）：

```powershell
dsh plugin --profile web add link:path/to/dsh-session-cost
```

安装后重启 `dsh web`，浏览器硬刷新（Ctrl+Shift+R）。打开任意会话即可在自带统计行末尾看到费用与余额。

移除：

```powershell
dsh plugin --profile web remove @kidli1412/dsh-session-cost
```

## 兼容性 / Compatibility

- **DSH 版本线**：官方 npm 的 `latest` 已从 `0.2.0-rc.2` 移到 **`0.2.1-rc.5`**（`alpha` 是 `0.2.2-alpha.2`），`0.2.0` 与 `0.2.1` 两条线都支持；manifest 通过 `dsh.compatibility.dshReleases` 把 `0.2.0-rc.2`、`0.2.1-rc.2`、`0.2.1-rc.5` 声明为 `compatible`（DSH STORE 取 `latest` 及其前两个发行版做窗口，`rc.5` 就是当前窗口内的那条精确记录；仅范围声明不会恢复上架）。插件使用的客户端注入（`dsh-api-remotes` / `dsh-client-connection` / `dsh-client-locale` / `dsh-client-ui-conversation` / `dsh-client-ui-settings`）、客户端服务（`slots` / `locale` / `configForms`）与 Host 服务（`webServer` 精确路由、`settings.describe` / `settings.update`、`credentials.resolve`、`session.seq` + `session.eventAt`）在两条版本线上均已在真实安装中逐项核对（客户端注入的 5 个包在 0.2.1 的客户端模块图里、`slots`/`locale`/`configForms` 三个服务名、`conversation.composer.dock` 槽位、`credentials.resolve` 的 `{value, source}`、`webServer.register` 的 `kind` 分表与精确表优先，均逐条复核通过）。`0.2.1-rc.5` 上另做过一次端到端实测：插件路由返回自己的 JSON（`404 unknown-session`）、`GET /api/session-cost/balance` 返回 **200 与真实余额**、外站 `Host` 被 403 拒绝、未匹配的 `/api/...` 仍 401。
- **Node**：`^22.19.0 || >=24.0.0`（与 DSH 一致）。
- **宿主要求（dsh-market 显示）**：`engines.dsh: ^0.2.0-rc.2 || ^0.2.1-rc.2`，并将运行时依赖的 lockstep 宿主包声明为 `peerDependencies`（`dsh-host-webserver` / `dsh-session` / `dsh-credentials` / `dsh-settings` 与客户端模块 `dsh-api-remotes` / `dsh-client-connection` / `dsh-client-locale` / `dsh-client-ui-conversation` / `dsh-client-ui-settings`，均为 `^0.2.0-rc.2 || ^0.2.1-rc.2`）；插件市场会据此显示"宿主要求"并判断与当前 DSH 是否匹配（市场读的就是 `engines.dsh` 与 `peerDependencies` 里 `@deepseek-ai/dsh*` 这两处，官方市场索引则把 `engines.dsh` 交给同一个 `evaluatePluginCompatibility`）。这些包由 DSH 运行时提供、本插件**从不 import**，所以同时标为 `peerDependenciesMeta.optional`——npm/pnpm 不再把它们装进依赖树（0.2.0 起它们彼此还有 peer 关系，沿用旧的自动安装会直接解析冲突），而"宿主要求"的语义不受影响。
  > **为什么是"并集"而不是单个 caret**：`^0.2.0-rc.2` 在**带 `includePrerelease` 的判定**（DSH 挂载闸门与 dsh-market 都用它）下已经覆盖 `0.2.1-rc.2`，但在**普通 semver** 下不覆盖——semver 规定"带先行版本号的版本，只有当比较器集合里有**同一个 `[major,minor,patch]` 元组**且自身带先行版本号的比较器时才可能满足"，而 `^0.2.0-rc.2` 只点名了 `0.2.0`。npm/pnpm 的 peer 解析、以及任何不显式打开 `includePrerelease` 的工具，都会据此认为插件不支持当前宿主，所以把 0.2.1 线**显式写出来**，两种语义下都成立（也顺带覆盖 `0.2.1` 稳定版与后续 `0.2.1-rc.x`）。`0.2.2-rc.x` 这类**下一个**补丁线的先行版本在普通 semver 下仍不匹配——这是 semver 的固有规则，只能靠再点名一条线来跟进。
- **0.3.3（同步 0.2.1-rc.5：没有代码改动，只补兼容证据）**：DSH 0.2.1-rc.5 现在是 npm `latest`。rc.2 → rc.5 的三个发行版——rc.3「侧栏/会话视图/右侧栏的『更多』菜单，便于浏览与创建插件」、rc.4「修 ACP 模式下诊断输出混进 stdout」、rc.5「优化思考内容展示」——都不碰本插件用到的契约，逐项复核也确认：自带统计栏仍是 `activity`/`usage` 两个条目 + 单数 `data-composer-stat`，`.bOPqQW_anchor` / `.bOPqQW_pill`（`--dsw-radius-sm`、`1px 8px` padding、`6px` gap）与 `.uV2eYG_dock` 的 CSS 与 rc.2 **逐字节一致**，`volatileForm` 的「has no volatile fields」、`conversation.composer.dock` 槽位、`session.eventAt` 也都还在。所以本版**不动代码**，只把 `0.2.1-rc.5` 写进 `dshReleases`（`engines.dsh` 的范围本来就覆盖 rc.5：`[0,2,1]` 元组在普通 semver 下同样匹配）。rc.3 / rc.4 由范围覆盖，但不登记精确记录——只声明真在真实安装里验过的版本。
  > 顺手修了预检脚本的老毛病：`temp/compat-preflight.mjs` 原来写死 pnpm store 路径，这次 DSH 更新连**全局根目录的 hash 都换了**（`v11/6664-…` → `v11/d14-…`），脚本直接找不到 `dsh-app-boot`；现在改成扫描 `~/AppData/Local/pnpm/global/v11/*` 取最新 store，`-Path` 写死这类路径不会再过期。
- **0.3.2（DSH 0.2.1 适配：统计栏拆成两个条目 + 宿主线的依赖声明）**：0.2.1 把自带统计栏从**一个** `StatsPills` 行拆成**两个** composer-dock 条目——`activity`（order 0）与 `usage`（order 1），标记也从复数 `data-composer-stats` 改成单数 `data-composer-stat`——并顺带改了宿主闸门与网页鉴权的判定方式：
  1. **定位（否则费用段长在别人的 pill 里）**：旧逻辑先找 `[data-composer-stats]`、找不到再退回 `N 轮 M 步` 文本匹配；拆分后旧属性已不存在，而**文本回退正好命中 `activity` 那一个 pill**，于是费用段被追加进 activity pill 的锚点**内部**（离它该在的那一行差一个 gap，还借用了别人的盒子）。现在按单数属性判定"自带读数在场"，并把 **dock 容器本身**当作"这一行"——费用段重新成为两个自带条目旁边的**同级**元素，位置与 0.2.0 时（追加在行尾）一致；0.1.5–0.2.0 的旧属性与 ≤ 0.1.4 的文本行仍按原样识别，两条线共用同一套代码。
  2. **皮肤**：`.bOPqQW_root` 已整个消失，pill 圆角由 0.2.0 的 `999px` + `corner-shape:round` 改成 `--dsw-radius-sm`（8px）；0.2.0 里从 `.bOPqQW_root` 继承来的 13/20 字号层级也一起没了（dock 容器自己不定字号），所以合并段现在自带 `font-size: calc(var(--dsh-content-font-size-secondary,13px) - 1px)` 与配套 `line-height`，圆角跟 `--dsw-radius-sm` 走。`.uV2eYG_dock`（居中 flex 行）与 stat-dialog 面板（`--dsw-radius-lg` + `--dsw-menu-backdrop-filter`）不变。
  3. **宿主闸门**：`engines.dsh` 一旦声明就**单独决定**能否挂载——`dsh-app-boot` 的 `unmetRequirements()` 命中 `engines.dsh` 就立即返回，`peerDependencies` 里那 9 个宿主包**不参与挂载判定**（只在没写 `engines.dsh` 时才逐条比对）。因此换线时 `engines.dsh` 必须写对；那 9 个 peer 现在的用途是喂给 dsh-market 的"宿主要求"显示。本次把 `engines.dsh` 与 9 个 peer 一起改成 `^0.2.0-rc.2 || ^0.2.1-rc.2`，并在 `dshReleases` 里补上 `0.2.1-rc.2`。
  4. **鉴权（0.2.1 实测，与 0.2.0 时期说法不同）**：签名 cookie 只挂在 `/api` **前缀**路由上，而本插件注册的是 `kind: "exact"` 精确路由，路由表**先查精确表**，所以未带 cookie 的 loopback 请求会**直接到达插件**（实测 `GET /api/session-cost/summary?session=x` 返回插件自己的 `404 unknown-session`；**未匹配**的 `/api/...` 才 401）。插件自己那两道 fence（loopback peer + `Host` 校验）因此是插件端点唯一的闸门——外站 `Host` 实测被拒（403）。**别再拿 401 判断插件是否挂载**。
  > 另记：`session.eventAt()` / `snapshotEvents()` / `ownEvents()` 在 0.2.1 被标为 `@deprecated`（**仍可用**，官方注明 "new calls are prohibited"）。本插件的 `liveSessionEvents()` 仍走 `eventAt`，等官方投影 API 定稿后再迁移。
- **0.3.1（阈值设置生效；`.volatile()` 是硬要求）**：0.2.0 的设置表单**只认带 `meta.volatile` 的字段**——`SettingsForms` 用 `volatileForm(schema)` 建表单，一个 volatile 字段都没有就返回 `undefined`：条目**从 `describe()` 里消失**（浏览器端表单永远停在 `unavailable`，于是余额一直按兜底默认值 10 上色，改了什么也看不出来），并且任何写入都抛 `Plugin entry "session-cost" has no volatile fields`（值根本不落盘）。0.3.0 的 `Config` 少了这个标记，因此"低余额阈值设置不生效"，抢救逻辑也一起静默失败。0.3.1 给字段补上 `.volatile()`，并把"必须至少有一个 volatile 字段"写成断言。
  > 另外记一笔：volatile 字段解析出来的是**活单元格 `{ get() }` 而不是普通值**（`JSON.stringify` 为 `{}`），所以 Host 侧不要直接读它做运算；默认值比较也要用独立常量，而不是 `Config({}).字段`。DSH 自己会在投影表单前把单元格拆成普通值。
- **0.3.0（DSH 0.2.0 适配）**：DSH 0.2.0 换了三套契约，宿主兼容闸门会**直接拒绝挂载**声明不符的 bundle（真实现象：插件在市场里显示"不兼容"、`rows: []`、统计栏里什么都没有）——
  1. **宿主要求必须落在 0.2.0 线上**：闸门比对运行时版本（`semver.satisfies(..., { includePrerelease: true })`；当时逐条比对 `peerDependencies` 里的 `@deepseek-ai/dsh*`，0.2.1 起改为**优先只看 `engines.dsh` 并短路 peer**，见上文 0.3.2），`^0.1.5-rc.1` 不满足 `0.2.0-rc.2`（caret 封顶在 `<0.2.0`），因此本版把 `engines.dsh` 与 9 个宿主 peer 一起提到 `^0.2.0-rc.2`。顺带把宿主包标为 optional peer，见上一条。
  2. **设置模型重做**：0.1.x 的"插件自建 settings namespace + `settings.register(ns, schema)`"没了，`settings.get(ns)` 也没了。现在**插件导出的 `Config`（schemastery）就是设置表单**，以**profile entry id**（本插件 bundle patch 里的 `id: session-cost`）为键；Host 通过 `ctx.settings.describe()` 读别人的条目、`ctx.settings.update(ns, patch)` 写；浏览器端用 `ctx.configForms.get("session-cost")`（`getSnapshot` / `subscribe` / `set`），旧的 `ctx.settingsScope.bind({ namespace })` 已从客户端消失。本插件的配置存取因此整体改到这上面（面板里的阈值输入框 UI 不变）。
  3. **统计栏与面板的皮肤同步**：`.bOPqQW_root` 不再自带宽度/内边距（`width:100%` + 748px 上限 + 侧边 clearance 移交给 composer 的 dock 容器），字号降到 `calc(--dsh-content-font-size-secondary - 1px)`，pill 圆角由 24px 改为 `999px` + `corner-shape:round`，stat-dialog 面板改用 `--dsw-radius-lg` 并加 `backdrop-filter`。本插件的 pill、solo 兜底行与明细面板按同一套值重绘，视觉仍与自带 pill 齐平。
  4. **整站浏览器鉴权**：0.2.0 给 `dsh web` 的每个请求加了签名 cookie（`dsh web authentication required`），插件的两个端点因此只有带 cookie 的同源页面能到达；Host 侧的 loopback 精确路由fence 保留为第二道防线。
  > 升级时会**自动抢救旧阈值**：DSH 自己的 `settings.yaml` 导入按 entry id 进行，而当时本插件正因上面的 peer 不符被拒挂载，导入失败后值只留在 `~/.dsh/settings.yaml.imported` 里。本版 Host 在启动后（等 Loader settle）读一次该文档，若条目还没有用户值就把非默认的 `lowBalanceThreshold` 写进配置——一次性、只读、失败即跳过。
- **0.2.0（DSH 0.1.5 适配 + 交互重做）**：三处必须改动，否则统计栏里**完全看不到**费用/余额段——
  1. **不再 require `@deepseek-ai/dsh-client-ui-primitives`**。0.1.5 起该包不再随 DSH 安装（依赖树里已无此包，客户端模块图因此没有这一行），而 plugin bundle 的 `require()` 对**未注册模块是抛错**的（loader 的 loud 语义），一处 require 就会让**整个客户端 half 加载失败**：dock 锚点、合并段、面板全部消失。本插件的图标改为内联 SVG 自绘，bundle 不再依赖任何可选宿主模块。
  2. **统计栏标记与定位**：优先按 `data-composer-stats` 属性定位（0.1.5 新增），文本 `N 轮 · M 步` 只作旧版回退且改为非锚定匹配（0.1.5 的 pill 文本已无 `·` 分隔）。
  3. **两个"迟到"**必须同时处理：`StatsPills` 在会话有步骤/token 前返回 `null`（**统计栏迟到**）→ 观察器必须监听容器**子树**（`childList` + `characterData` + `subtree`）；重启 host 后首次 summary/余额响应仍在路上（**数据迟到**）→ 观察器必须**无条件安装**。
  4. **价格与模型 id 同步跟进**：0.1.5 把 V4-Flash 路由成短 id `deepseek-flash`，且官方在 2026-09-10 发布 V4.1-Flash 并调价；本版引入**价格世代**模型（`legacy` / `v4:*` / 当前 `peak`/`offpeak`）与别名解析，详见下文「定价表」。
  交互上，费用/余额段从"悬停气泡"改为**与自带统计项同款的可点击 pill + 点击展开面板**。
- **0.2.1（切会话丢费用 + 统计栏缺席时的显示）**：
  1. **切会话不再丢 pill**。切换会话（尤其是**没有客户端缓存**、要等约 1 秒的旧会话）时整个输入区被拆掉重建，锚点会短暂处于**脱离文档**的子树中，而 0.2.0 只在宿主仍 `isConnected` 时才重新挂载观察器——一次这样的回调就让观察器**永久失效**：费用消失，切回新会话也不恢复，必须刷新页面（刷新等于重新挂载、装上新的观察器）。0.2.1 无条件重挂（脱离文档的子树照样派发变更），并加 1 秒看门狗兜底补挂；观察器也改为**每个组件挂载只装一次**，数据变化走 `sync()` 推入（不再每 30 秒拆掉重建节点）。
  2. **统计栏缺席时先挂在锚点自身**（`[data-solo]`，字号/内边距/最大宽度照抄 `.bOPqQW_root`），统计栏一出现即挪回栏内——全新会话与冷会话加载中都有费用读数。
- **0.2.2（修复 0.2.1 的点击展开回归）**：0.2.1 让合并节点不再每次数据变化都重建，于是暴露出一个更早就存在的缺陷——**面板是 `document.body` 的 portal**，而原地 patch 用 `node.querySelector("[data-slot=panel]")` 找它，恒为 `null`。后果是面板里的读数（总额、余额、更新时间）从来不刷新，并且 0.2.1 之后**点击 pill 打不开面板**（展开态写不进那个"找不到的"面板）。0.2.2 改为通过 `mergePanels` 注册表（`panelOf`）取面板，展开/收起、读数更新都真正落在同一个面板元素上；同时处理器改为**点击时**从组件的稳定 state 对象上读取（节点寿命已跨越多次渲染，刷新按钮必须作用于当前会话）。
- **0.2.3（去掉统计栏宽度补丁）**：≤ 0.1.4 的 `StatsLine` 自带 748px 上限 + `overflow:hidden` + 省略号截断，会把追加的费用段裁掉，早期版本的插件因此用**行内样式**把统计行"放宽 + 取消裁剪"（效果同 zh_pro「统计全显示」，自包含、不依赖它，卸载时按 WeakMap 记下的原值精确还原）。0.1.5 的 `StatsPills` 根节点（`.bOPqQW_root`）是**居中 flex 行**（`width:100%`、`max-width:748px`、`gap:12px`），既没有 `overflow:hidden` 也不做省略号截断——追加段只是这一组里的第三项，宽度本来就够，补丁已删除，插件**不再写自带统计栏的任何行内样式**（`dom-smoke` 断言统计栏的行内样式在挂载 / 重新挂载 / 卸载后逐项不变，重新引入任何 `max-width` 写入都会失败）。
- **0.2.5（展开面板的原地更新补全）**：面板列表里的**每个单元格本身就是 slot**（`dt` 是 `row-label`，`dd` 是 `row-value` / `panel-balance`），而原地 patch 过去用 `cell.querySelector("[data-slot=row-value]")` 去取它们——`querySelector` 只搜**后代**，于是每个单元格都返回 `null`、`patchText` 直接跳过：**手动 ⟳ 刷新后「账户余额」会跟着变（它按 slot 名单独 patch），「充值余额 / 赠送余额」和逐模型读数却停在旧值**。0.2.5 改为直接 patch 单元格自身，并补齐两处：`data-warn` 的同步（模型变成未计价时那一行要变红）与列表在原位**增长 / 收缩**（`暂无 token 用量` ↔ 模型行，节点自身 slot 数不变时不再抛错或被吞掉）。
- **0.2.7（阈值行落到「更新于 / ⟳」下面一行）**：0.2.6 把它放在读数网格（`dt/dd`）的最后一行，读数和设置混在一起；现在它是面板里独立的一行、紧跟在更新时间与 ⟳ 刷新下面，左边标签、右边输入框（与读数同一右边界）。读数网格因此恢复为**纯数字**（模型行 + 余额构成），设置项与面板的控制按钮聚在一起。位置之外的行为不变（提交/回车、拒绝空值与负数、刷新不覆盖半途输入、写回同一个 namespace）。
- **0.2.6（低余额阈值搬进面板）**：阈值原本是「设置 → 插件 → 插件配置 → 会话费用显示」里的一张卡片，而它唯一的作用就是给**本面板与 pill 的余额读数**上色——要改颜色得先离开看颜色的地方。0.2.6 把编辑器搬进明细面板，并**取消 `settings.plugin.item` 注册**（客户端从此只注册 composer dock 一个槽位）。持久化路径没变：仍是 `session-cost` settings namespace → `~/.dsh/settings.yaml`，旧值原样沿用，0.1.1 及更早的 localStorage 迁移逻辑仍在。空串或负数不提交并把输入框恢复成已存值。
- **0.1.8（DSH 0.1.2 适配）**：rc.1 起 live session 不再携带 `.events` 数组——事件总数读 `session.seq`、逐条读 `session.eventAt(seq)`（与官方 `dsh-token-meter` 相同的读法），费用折叠已适配；客户端注入模块列表同步为新架构模块（见上）。
- **降级说明**：`dshReleases` 列的是 `0.2.0-rc.2`、`0.2.1-rc.2` 与 `0.2.1-rc.5`（当前 npm `latest`），`engines.dsh` 是 `^0.2.0-rc.2 || ^0.2.1-rc.2`（范围已覆盖整条 0.2.1 线，含 rc.3 / rc.4）。需要 **DSH 0.1.5 线**的用户请使用 **0.2.7**；需要 **0.1.2 线**的请使用 **0.1.9**（更早的 0.1.x 见各自版本的 README）。

## 架构

| 文件 | 角色 |
| --- | --- |
| `lib/index.js` | 服务端：导出 `Config`（`lowBalanceThreshold`，DSH 0.2.0 据此生成设置表单）；`GET /api/session-cost/summary?session=<id>`（增量折叠会话事件并按模型计价）、`GET /api/session-cost/balance`（DeepSeek 余额，loopback-only 精确路由，`?refresh=1` 强制绕过缓存）；经 `settings.describe()` 读 `llm-deepseek` 条目、经 credentials 缝解析 API Key；启动后一次性抢救旧 `settings.yaml` 里的阈值 |
| `lib/cost.js` | 纯函数：按模型 token 折叠（replace-last-sample 语义）+ CNY 单价表 + 费用计算 |
| `lib/balance.js` | 纯函数：DeepSeek 余额接口查询与状态归一化 |
| `lib/client.js` | 浏览器端：**只注册** `conversation.composer.dock` 槽位（id `session-cost`, order 100）；把费用/余额 pill 追加进自带统计栏 DOM（`findStatsRow` 先认 `data-composer-stats` 单行容器、再认 0.2.1 的单数 `data-composer-stat` → 此时"这一行"是 dock 容器本身、费用段与 `activity`/`usage` 两个自带条目同级，最后才是 ≤ 0.1.4 的文本行回退；`startStatsRowObserver`：子树 MutationObserver + 无条件重挂 + 1 秒看门狗，统计栏迟到/被 React 重渲染/切会话重建后都会重新挂载；两个自带条目都不在场时先挂在锚点自身；`updateMergeNode` 原地 patch 数值；**不改统计栏自身的任何样式**），点击展开挂到 `document.body` 的明细面板（`placeOpenPanel` 做视口夹取），面板里「更新于 / ⟳」下面一行是低余额阈值输入框（经 `ctx.configForms.get("session-cost")` 读写本插件配置） |

费用为**估算值**：token 用量来自会话日志中 provider 上报的 usage 样本，单价表为写死的默认值，价格变动后请更新 `lib/cost.js` 的 `DEFAULT_PRICING`（或通过插件配置 `pricing` 覆盖）。

## 定价表（默认，CNY / 百万 tokens）

取自官方定价页（[模型 & 价格](https://api-docs.deepseek.com/quick_start/pricing/) 中文版）。计费为**峰谷 + 价格世代**两层：

- **峰谷**：高峰 = 北京时间工作日 9:00–12:00、14:00–18:00（官网英文页写作 UTC 周一至周五 01:00–04:00 / 06:00–10:00），高峰价 = 空闲价的 2 倍；**2026-08-23 0 时起周末（周六、周日）全天按空闲价**。
- **价格世代**（同一条会话可以跨越多次调价，插件按每条 usage 样本的**事件时间**归属世代，不回溯改价）：

| 世代 | 生效区间（北京时间） | 说明 |
| --- | --- | --- |
| `peak` / `offpeak` | 2026-09-10 0:00 起（V4.1-Flash 发布） | 当前价，见下表 |
| `v4:peak` / `v4:offpeak` | 2026-08-17 0:00 – 2026-09-09 | V4 时代的峰谷价（Flash ¥1.5/3、¥0.05/0.10、¥4.5/9），`V4_ERA_PRICING` |
| `legacy` | 2026-08-17 0:00 之前 | 平峰旧价（Flash ¥1、¥0.02、¥2），`LEGACY_PRICING` |

**当前价（2026-09-10 起，CNY / 百万 tokens）**：

| 模型 id | 输入（缓存未命中）空闲 / 高峰 | 输入（缓存命中）空闲 / 高峰 | 输出 空闲 / 高峰 |
| --- | --- | --- | --- |
| deepseek-flash（V4.1-Flash，**DSH 0.1.5 实际路由的 id**） | ¥1 / ¥2 | ¥0.02 / ¥0.04 | ¥4 / ¥8 |
| deepseek-v4-flash（已下线，别名到 V4.1-Flash） | ¥1 / ¥2 | ¥0.02 / ¥0.04 | ¥4 / ¥8 |
| deepseek-v41-flash（同一模型的另一种拼写） | ¥1 / ¥2 | ¥0.02 / ¥0.04 | ¥4 / ¥8 |
| deepseek-v4-flash-vision-exp（已下线，别名到 V4.1-Flash） | ¥1 / ¥2 | ¥0.02 / ¥0.04 | ¥4 / ¥8 |
| deepseek-v4-pro（V4-Pro-0813，官方确认 2026-09-14 后继续提供） | ¥4.5 / ¥9 | ¥0.15 / ¥0.30 | ¥13.5 / ¥27 |
| deepseek-chat / deepseek-reasoner（V3 遗留名，2026-07-24 起别名到 Flash） | ¥1 / ¥2 | ¥0.02 / ¥0.04 | ¥4 / ¥8 |

> **模型 id 会变，变了就会静默算成 ¥0**：DSH 0.1.5 把 V4-Flash 路由成短 id `deepseek-flash`（界面显示 "DeepSeek-V41-Flash"），而旧表里只有 `deepseek-v4-flash` —— 找不到单价 → 整场会话费用恒为 0，这正是 0.1.5 升级后的"费用一直是 0"。因此本版：
> - 当前表列出**全部仍被接受的 id**（含已下线的旧名，避免历史会话读成未计价）；
> - 匹配改为**名称边界前缀**：`deepseek-v4-flash-2026-01` 这类带日期后缀的 id 归到 `deepseek-v4-flash`，而 `deepseek-v99` 这种不同型号**不会**被误当成 flash，而是判为未计价；世代表（`V4_ERA_PRICING`/`LEGACY_PRICING`）通过 `PRICING_ALIASES` 做同样的别名解析，旧世代里的新 id 也按旧价计费；
> - 明细面板里未匹配到单价的模型显示红色 **未计价**，不再伪装成 ¥0；`GET /api/session-cost/summary` 附带 `diagnostics`（事件数 / 已识别模型 / 已计价模型数），便于一眼定位。

`cacheWrite` 无 DeepSeek 等价项（上下文缓存自动命中计费），默认按缓存未命中输入价计（分时段），避免低估。

明细面板会显示高峰 / 空闲 / V4 价 / 旧价的费用拆分（跨时段或跨世代时）。

> 官方英文页另有**美元**价格（Flash $0.15/$0.30 输入、$0.003/$0.006 缓存命中、$0.6/$1.2 输出），与本表的人民币价按同一份价目表换算，插件统一按**人民币**计价（与余额接口的 CNY 口径一致）。

插件配置（可选）可覆盖定价——平峰格式（所有时段同价）或分时段格式：

```yaml
# ~/.dsh/settings.yaml 或 profile 插件配置
session-cost:
  pricing:
    deepseek-v4-flash:
      input: 1
      cacheRead: 0.02
      cacheWrite: 1
      output: 2
    # 或分时段（offpeak/peak 各自覆盖，未给字段继承默认）：
    # deepseek-v4-pro:
    #   offpeak: { input: 4.5, output: 13.5 }
    #   peak: { input: 9, output: 27 }
```

`pricing` 与配置卡写入的 `lowBalanceThreshold` 共存于同一个 `session-cost:` section，互不覆盖（schemastery 解析保留未知键；`pricing` 仍由服务端从插件 config 读取）。

## 安全

- 两个端点均为 loopback-only 精确路由（peer socket 地址 + Host 双重校验），浏览器同源调用。
- API Key 不落盘：请求时经 credentials 缝解析 `llm-deepseek` 命名空间的 `apiKeyEnv`（默认 `DEEPSEEK_API_KEY`）。
- 余额缓存仅存于内存，2 分钟 TTL。

## License

MIT
