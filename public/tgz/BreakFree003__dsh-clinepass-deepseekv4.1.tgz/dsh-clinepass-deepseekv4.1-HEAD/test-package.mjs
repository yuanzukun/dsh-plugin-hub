/**
 * Packaging invariants — the things that make the two install routes safe to
 * point people at.
 *
 * The plugin can be mounted as a dsh *bundle* (`dsh plugin --profile web add
 * github:...`, which reads this package's own `cordis.patch.yml`) or by
 * `install.mjs` (which writes a row into the profile's patch file). Both must
 * describe the same mount, or "install it either way" quietly means two
 * different installs.
 *
 * Deliberately parser-free and dsh-free: this package ships no dependencies and
 * this file must run anywhere: the bundle patch carries one `- insert:` row
 * and one `- id: llm-pi-ai` provider row, which this file compares against the
 * blocks the installer and uninstaller write.
 *
 * Each invariant guarded here was a real bug or a real trap:
 *   - the `install` lifecycle script made pnpm refuse a git-hosted install
 *     (`ERR_PNPM_IGNORED_BUILDS`) and would have rewritten the *host's*
 *     `$DSH_HOME` on any plain `pnpm install`;
 *   - a bundle patch missing from `files` turns a working repo install into a
 *     broken tarball;
 *   - a bundle row that drifts from the installer row is invisible until a user
 *     reports a config that does not apply.
 *
 * Run: node test-package.mjs
 */
import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const failures = []
const check = (label, ok, detail) => {
  console.log(`${ok ? '  ok  ' : ' FAIL '} ${label}${detail === undefined ? '' : ` — ${detail}`}`)
  if (!ok) failures.push(label)
}

const manifest = JSON.parse(fs.readFileSync(path.join(HERE, 'package.json'), 'utf8'))
const read = (file) => fs.readFileSync(path.join(HERE, file), 'utf8')

// ── 1. the bundle declaration ───────────────────────────────────────────────
console.log('\n── 1. bundle declaration ─────────────────────────────────')
const declared = manifest.dsh?.bundle?.patch
check('the manifest declares dsh.bundle.patch', declared === './cordis.patch.yml', String(declared))
check('the declared patch exists', typeof declared === 'string' && fs.existsSync(path.join(HERE, declared)))
check('the patch is in "files", so a tarball ships it', (manifest.files ?? []).includes('cordis.patch.yml'), JSON.stringify(manifest.files ?? []))
check('the entry point the manifest names exists', typeof manifest.main === 'string' && fs.existsSync(path.join(HERE, manifest.main)), String(manifest.main))

// ── 2. nothing that runs on someone else's machine ──────────────────────────
console.log('\n── 2. no lifecycle scripts ───────────────────────────────')
for (const hook of ['preinstall', 'install', 'postinstall', 'prepare', 'prepublishOnly']) {
  check(`no ${hook} script`, manifest.scripts?.[hook] === undefined, String(manifest.scripts?.[hook]))
}
check('no runtime dependencies', Object.keys(manifest.dependencies ?? {}).length === 0, JSON.stringify(manifest.dependencies ?? {}))
check('no peer dependencies', Object.keys(manifest.peerDependencies ?? {}).length === 0, JSON.stringify(manifest.peerDependencies ?? {}))

// ── 3. version and changelog agree ──────────────────────────────────────────
console.log('\n── 3. version ────────────────────────────────────────────')
const top = /^## (\S+)/m.exec(read('CHANGELOG.md'))
check('the changelog has a version section', top !== null)
check('the top changelog section is the manifest version', top?.[1] === manifest.version, `changelog ${top?.[1]} vs manifest ${manifest.version}`)

// ── 4. the bundle row and the installer row describe one mount ──────────────
console.log('\n── 4. bundle patch parity ────────────────────────────────')
/** Lines that carry meaning: no blanks, no comments, no trailing space. */
const meaningful = (text) =>
  text
    .split('\n')
    .map((line) => line.replace(/\s+$/, ''))
    .filter((line) => line.trim() !== '' && !line.trim().startsWith('#'))
/** Top-level patch entries: a `- ` line starts one, everything after it belongs to it. */
const entriesOf = (text) => {
  const entries = []
  for (const line of meaningful(text)) {
    if (/^- /.test(line)) entries.push([line])
    else if (entries.length > 0) entries[entries.length - 1].push(line)
  }
  return entries
}
const bundleEntries = entriesOf(read('cordis.patch.yml'))
const insertBlock = bundleEntries.find((entry) => entry[0] === '- insert:')
const providerEntry = bundleEntries.find((entry) => entry[0] === '- id: llm-pi-ai')
check(
  'the bundle patch carries the mount and the provider card, and nothing else',
  bundleEntries.length === 2 && insertBlock !== undefined && providerEntry !== undefined,
  JSON.stringify(bundleEntries.map((entry) => entry[0])),
)

const block = /const FETCH_BLOCK = `([\s\S]*?)`\n/.exec(read('install.mjs'))
check('install.mjs still has a FETCH_BLOCK to compare against', block !== null)
if (block !== null && insertBlock !== undefined) {
  const installerLines = meaningful(block[1])
  // The one permitted difference is the module specifier: the bundle resolves its
  // own bare package name, the installer points at the file it copied.
  const specifierNeutral = (lines) => lines.map((line) => (line.trim().startsWith('name:') ? '  name: <row>' : line))
  check(
    'both rows carry the same config',
    JSON.stringify(specifierNeutral(insertBlock)) === JSON.stringify(specifierNeutral(installerLines)),
    JSON.stringify(insertBlock),
  )
  check('the bundle row mounts the same id as the installer', insertBlock.includes('    - id: clinepass') && installerLines.includes('    - id: clinepass'))
  check('the bundle row names the bare package', insertBlock.includes('      name: dsh-clinepass'), JSON.stringify(insertBlock))
}
check('the row is an insert, not a disable/override', insertBlock?.[0] === '- insert:')

// The provider card ships as data, and the installer writes the same block.
// Both are load-bearing: without the first the card only shows up when a run-time
// settings write lands (not dependable on 0.1.7 — see the README), and without
// the second the installer route mounts a hook with no card.
const providerBlock = /const PROVIDER_BLOCK = `([\s\S]*?)`\n/.exec(read('install.mjs'))
check('install.mjs has a PROVIDER_BLOCK to compare against', providerBlock !== null)
if (providerBlock !== null && providerEntry !== undefined) {
  check('the installer declares the same provider card', JSON.stringify(meaningful(providerBlock[1])) === JSON.stringify(providerEntry), JSON.stringify(providerEntry))
}
const uninstallBlock = /const PROVIDER_BLOCK = `([\s\S]*?)`\n/.exec(read('uninstall.mjs'))
check(
  'uninstall.mjs knows the same block, so it deletes only its own',
  uninstallBlock !== null && providerBlock !== null && meaningful(uninstallBlock[1]).join('\n') === meaningful(providerBlock[1]).join('\n'),
)
const providerText = (providerEntry ?? []).join('\n')
check(
  'the provider card names the pi-ai route, the key env, the gateway and the model',
  ['- id: llm-pi-ai', 'cline-pass:', 'api: openai-completions', 'apiKeyEnv: CLINE_PASS_API_KEY', 'baseURL: https://api.cline.bot/api/v1', 'id: cline-pass/deepseek-v4.1-flash'].every(
    (needle) => providerText.includes(needle),
  ),
  JSON.stringify(providerEntry),
)
check('…and carries exactly one patch row, so it cannot replace a second one', (providerEntry ?? []).filter((line) => /^- /.test(line)).length === 1, JSON.stringify(providerEntry))

// ── 5. the browser half is declared the way the client module system reads it ─
console.log('\n── 5. client half declaration ────────────────────────────')
// `dsh-client-modules` finds a plugin's client bundle by scanning the enabled
// loader entries upward to the nearest package.json, then reading
// `dsh.client.platform` and `exports["./client"]`. Both are silent when wrong:
// the host half keeps working and the card simply never appears.
const clientExport = manifest.exports?.['./client']
check('the manifest exports a ./client bundle', typeof clientExport === 'string', JSON.stringify(manifest.exports ?? {}))
check('…that exists', typeof clientExport === 'string' && fs.existsSync(path.join(HERE, clientExport)), String(clientExport))
check('…and is shipped', (manifest.files ?? []).includes('client.js'), JSON.stringify(manifest.files ?? []))
check('the manifest declares it as a web client half', manifest.dsh?.client?.platform === 'web', JSON.stringify(manifest.dsh?.client))
check('the installer copies it too', /const files = \[[^\]]*'client\.js'/.test(read('install.mjs')), 'install.mjs file list')
if (typeof clientExport === 'string' && fs.existsSync(path.join(HERE, clientExport))) {
  const client = read(clientExport)
  // The loader registers factories by module id, and `<bare id>` must resolve to
  // the same exports as `<bare id>/client` — a mismatched id here is a bundle
  // that loads and never activates.
  check('the bundle registers under the package name', client.includes(`id: '${manifest.name}'`), manifest.name)
  check('…and the module id uses the bare name, not a scoped path', !client.includes(`id: '${manifest.name}/client'`))
}

console.log('\n── 6. manifest references resolve ────────────────────────')
// A manifest is a set of promises about files, and the installer keeps its own
// hand-written copy list. The two have already drifted once: `files` and
// `dsh.bundle.patch` both name `cordis.patch.yml` while the copy list omitted
// it, so a manual install produced a package whose own manifest pointed at a
// file that was not there. Neither half fails loudly on its own.
//
// These compare the manifest against the *source* checkout, the only place the
// full `files` list and `install.mjs` coexist (an installed copy deliberately
// receives the runtime and the tests, not the docs or the installer).
// `install.mjs` is repo-only, so its presence is the signal.
if (!fs.existsSync(path.join(HERE, 'install.mjs'))) {
  console.log('  skip  source-checkout checks: installed copy (no install.mjs)')
} else {
  const shipped = manifest.files ?? []
  const missingFromDisk = shipped.filter((entry) => !fs.existsSync(path.join(HERE, entry)))
  check('every file package.json ships exists on disk', missingFromDisk.length === 0, `missing=${missingFromDisk.join(',')}`)

  const installerList = (read('install.mjs').match(/const files = \[([^\]]*)\]/)?.[1] ?? '')
    .split(',')
    .map((entry) => entry.trim().replace(/^['"]|['"]$/g, ''))
    .filter(Boolean)
  const referenced = [manifest.main, manifest.dsh?.bundle?.patch, ...Object.values(manifest.exports ?? {})]
    .filter((value) => typeof value === 'string' && value.startsWith('./'))
    .map((value) => value.slice(2))
  check('the manifest references at least one file', referenced.length > 0, JSON.stringify(referenced))
  const notCopied = referenced.filter((entry) => !installerList.includes(entry))
  check('the installer copies every file the manifest references', notCopied.length === 0, `not copied=${notCopied.join(',')}`)
  check(
    '…including the bundle patch the loader row consumes',
    installerList.includes('cordis.patch.yml') && referenced.includes('cordis.patch.yml'),
    JSON.stringify({ referenced, installerList }),
  )
}

console.log(`\nRESULT: ${failures.length === 0 ? 'PACKAGE OK' : `FAILED (${failures.join(' | ')})`}`)
process.exit(failures.length === 0 ? 0 : 2)
