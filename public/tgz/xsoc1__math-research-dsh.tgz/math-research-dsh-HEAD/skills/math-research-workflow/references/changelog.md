# Release history

## 2.0.0

Concise, independent research guidance; reusable experience from successful and failed routes; versioned literature and annotations; current-state continuity; exact Lean target verification and reusable local feedback. Legacy immutable evidence stays readable. See the repository 2.0 implementation report for tested scope.

## Changelog (2026-09-05, v1.15.0)

- Added compact latest-checkpoint inspection, idempotent receipt preparation,
  draft/concurrent-state blocking and fresh account-quota observations.
- Added opt-in physical skill-source diagnostics. Metric comparison now
  preserves unknown values, normalizes aliases and rejects mismatched designs.
- Whiteboard writes follow material decisions. Intermediate Lean verification
  follows the declared tier while preserving independent proof and final gates.
- Deterministic fixtures and scoped independent review cover library/recovery
  behavior. No new end-to-end mathematical speedup is claimed.

## Changelog (2026-08-31, v1.14.1)

- Fixed scoped pipeline validation for versioned recovery artifacts. The gate
  now verifies the latest sealed checkpoint and validates the whiteboard and
  closure gate bound by its state, while preserving immutable ancestors.
- A stale latest checkpoint fails closed without ancestor fallback. The
  checkpoint smoke covers legacy sequence-00 records, compliant versioned
  successors, and post-seal tampering.

## Changelog (2026-08-31, v1.14.0)

- Stage A now treats `blueprint-project.json` as the physical-layout authority
  and requires one active manage-plugin `runtime/blueprintctl.py ensure`
  binding before canonical knowledge operations.
- Validation, snapshot retrieval, proposal validation, and integration use the
  plugin-owned gateway. Project-local Blueprint tools are neither copied nor
  executed, and configured cross-root artifacts remain hash-verifiable.

## Changelog (2026-08-30, v1.13.0)

- Added canonical `consume` and `verify-consumption` commands. After a live
  exact-copy receipt returns `READY`, Stage C records one immutable sibling
  consumption bound to the receipt hash, consumer root, artifact snapshot, and
  an already registered anchor. Duplicate, relocated, or unbound consumption
  records fail closed.
- Consumption explicitly leaves mathematical and verification status
  unchanged. Historical verification permits legitimate destination-scaffold
  evolution, while receipt/source drift, project-ID change, anchor removal, or
  a claimed promotion remains invalid. Seal and consume now use exclusive file
  creation to close their overwrite TOCTOU window.

## Changelog (2026-08-30, v1.12.0)

- Added `formalization_handoff.py seal/verify` for exact-copy Tier 0 scaffolds
  moving from an isolated Stage B logical root into a different Stage C Lean
  project. The immutable receipt binds both project identities, the source run
  manifest/proof/scaffold, the destination scaffold, and durable registration
  anchors.
- The v1 handoff intentionally rejects full `formalization=requested` packages,
  path escape, nested git roots, artifact or marker drift, missing manifest
  entries, unequal copy hashes, output overwrite, and removed registration
  anchors. It never upgrades a scaffold to `FORMALLY_VERIFIED`.

## Changelog (2026-08-30, v1.11.0)

- Added `validate_pipeline.py --scope <relative-logical-root>` for a complete
  nested project inside a legacy repository. Scoped discovery, hash bindings,
  formalization paths, checkpoints, and scoped git cleanliness are confined to
  that root; the output explicitly states that a scoped PASS is not a
  whole-project PASS.
- Scope roots must carry `project.json` or `blueprint-project.json`; absolute,
  escaping, markerless, and nested-git scopes fail before validation. Relative
  source and formalization bindings can no longer escape their validation root.

## Changelog (2026-08-30, v1.10.0)

- Added `checkpoint_resume.py advance`: it verifies the predecessor pair,
  versions checkpoint-bound whiteboard and closure artifacts, writes a guarded
  next-segment draft, and prevents in-place edits from invalidating earlier
  checkpoints.
- Added unambiguous project/cwd path normalization, canonical UTC timestamps,
  seven-digit fractional-second support, and typed `REFINES`/`SUPERSEDES`
  obligation lineage with automatic predecessor-action retirement.

## Changelog (2026-08-29, v1.9.0)

- Added a deterministic quota interruption boundary: semantic state binds
  completed/open obligations, in-flight workers, do-not-repeat actions, exact
  resume work, and all referenced artifacts; immutable checkpoints verify as
  `READY` before any resumed model call.
- Added benchmark continuity: prompt/harness/source/workspace bindings,
  hidden-gold state, segment number, and cumulative metrics survive resume;
  unresolved workers are reconciled before dispatch and completed work cannot
  be selected as the first action. Later segments bind the unique predecessor
  receipt; experiment identity, finite metrics including cost, action IDs, and
  reviewed status transitions are checked across the complete chain. Resume
  receipts consume the verified in-memory state snapshot, and status upgrades
  require proof/audit bindings that are fresh across the full lineage.

## Changelog (2026-08-28, v1.8.0)

- Stage B now consumes the rigorous hash-bound completion certificate. A
  zero-gap fresh package audit triggers a hard fast-close scheduling boundary:
  no further Worker, route, bonus-claim, or repeated global-audit model calls.
- Added deterministic validation plus positive and adversarial smoke cases for
  STOP and bounded-frontier records, including all artifact hashes.

## Changelog (2026-08-27, v1.7.0)

- Stage B now inherits the rigorous closure-first spawn gate: the Planner
  directly attacks and cheaply falsifies the first load-bearing claim before
  Worker dispatch, then requires a durable `decision_delta` for continuation.
- Empty, duplicate, and no-delta Worker returns are rejected without a second
  global review; reusable or load-bearing outputs retain independent audit.

## Changelog (2026-08-24, v1.6.0)

- Moved release history behind this pointer, reducing the always-loaded
  `SKILL.md` from 37,819 to 29,426 bytes. Added the Codex execution fast path:
  indexed discovery, targeted reads, bounded programmable batching for
  independent deterministic work, explicit semantic decision boundaries, and
  artifact-based reconstruction before compaction.

## Changelog (2026-08-14)

- Distilled the OpenProver method (arXiv:2607.09217, github.com/kripner/OpenProver)
  into stage B/C: Planner-Worker-Verifier solve loop with a mandatory compact
  `whiteboard.md` per run (current plan, route history with outcome markers,
  deferred ideas, open obligations, key-artifact index); independent parallel
  Workers that never see each other's or the Planner's reasoning traces;
  independent Verifier feedback on finished Worker outputs; repository items
  addressed by slug with a verified-items-only rule for Lean snippets; a Lean
  real-time verification loop (`lean_verify` / `lean_search` via LeanExplore /
  `lean_store` context accumulation); a formalization feedback loop that routes
  proof-layer flaws back to the solve-run lead; and interactive steering for
  human-in-the-loop runs. `validate_pipeline.py` hard-requires the whiteboard
  (fields + sections) for stage B runs started on or after 2026-08-14; new
  `tests/smoke_whiteboard.py` wired into CI.
- Cachebuster bumped to `0.1.0+codex.20260814120000` to propagate the protocol.

## Changelog (2026-08-13)

- Added `scripts/doctor.py`, an environment preflight: verifies the workflow
  plugin, the three dependency skills, the marketplace, and the `config.toml`
  enable entry; prints exact repair commands. Stage A runs it before dispatch
  (guards against the desktop app rewriting `config.toml` and dropping the
  plugin-enable entry).
- `validate_pipeline.py` now enforces numerical-evidence discipline: a gate
  status requires `candidate_proof.md` or `audit_report.md` in the run
  directory; numerical labels mixed with strong claims need a strict label or
  an explicit downgrade statement; `verification.json` verdict
  `FORMALLY_VERIFIED` requires `machine.build_passed == true` and zero
  sorry/axiom hits; `STATUS.md` cannot claim `FORMALLY_VERIFIED` without the
  verdict file. Fixed lean-manifest input-hash resolution (paths are relative
  to `lean-proof/` and may use Windows separators).
- Fork-sync specifics removed from this plugin; git sync now defers to the
  manage skill's generic remote-topology configuration.
- Cachebuster bumped to `0.1.0+codex.20260813054312` to propagate the gate.

- Stage B now starts with a mandatory B0 novelty preflight: openness check
  (genuinely open as of the research date), divergent novelty audit with
  `query -> result -> locator` provenance, snapshot-hash backfill into the
  manage skill's literature frontier, and a deterministic gate - every
  solve/disprove/construct task packet must carry a `## Novelty preflight`
  section (openness verdict + audit path or explicit skip + snapshot hash),
  enforced by `validate_pipeline.py`. A missing preflight is a hard FAIL at
  the A -> B boundary.
- Cachebuster bumped to `0.1.0+codex.20260813101438` to propagate the B0 gate.

- Interruption handoff and resume protocol: when a stage stops before
  completion, the interrupting agent writes
  `runs/<run_id>/handoff-interrupted-<ts>.md` from
  `assets/interruption-handoff.template.md` - run/packet IDs, interrupt
  reason, task state, completed/open obligations, every route tried with
  `[FAILED|BLOCKED|PARTIAL|SUCCEEDED]` outcome markers, exact next actions,
  and hashed artifact paths; the successor agent resumes from the handoff and
  must not re-run a FAILED route without a new recorded reason.
  `validate_pipeline.py` hard-fails handoffs missing required fields or
  sections. Added `tests/smoke_handoff.py` (+ good/bad fixtures) and wired it
  into CI.
- Cachebuster bumped to `0.1.0+codex.20260813144928` to propagate the handoff protocol.

## Changelog (2026-08-14, formalization decision gate)
- 修复静默跳过 Lean 验证: 声称完成状态 (已证/CANDIDATE_COMPLETE_PROOF) 的 run 必须在
  run-manifest 记录形式化决策 (formalization: requested | not_requested | skipped);
  requested 要求 formalization_manifest 指向存在文件 + lean-proof/verification.json
  干净机器裁决; skipped 要求非占位 formalization_reason 且重新验证义务保持开放;
  门禁机械强制 (validate_pipeline.py), 缺失决策即 FAIL.
- 任务包模板新增可选 Verify: yes|no|not-requested 字段 (manage skill).
- 新增 tests/smoke_formalization.py + 三个 fixtures (good/missing/requested).

## Changelog (2026-08-16, distilled methods round 2)
- 多 agent 协作增强 (纯增量): Stage B 新增义务认领协议 (claim before work -
  ledger 记录唯一所有者, 防重复证明; 来自 dsh-suite plugin-team-board);
  Loop control 新增缺口回灌硬规则 (非 PASS 评审输出必须被修订轮消费或登记为
  路由义务, 静默丢弃 = 门禁失败; 来自 dsh-proof); Efficiency rules 新增并行
  失败聚合 (收集全部成员失败, 不短路; 来自 dsh-agent-team-gui) 与循环检测
  (无新机制重试失败路线即阻断并记录见证; 来自 dsh-trajectory-governance).
- Stage C 新增 Lean 升级通道: 证明关键且可机器验证的断言先形式化验证再声称
  完成状态 (先 Lean 再落地, 非事后补验; 来自 dsh-rigorquant).

## Changelog (2026-08-16, progress registration + formalization scaffolding)
- Stage B/C: 每个新结果 (含 RIGOROUS_PARTIAL_RESULT / 结构定理 / 反例 /
  约化) 都必须登记并创建 Lean scaffold; 只有完成标签 (已证 /
  CANDIDATE_COMPLETE_PROOF) 才做完整 Lean 验证.
- run-manifest 形式化决策新增 `scaffold`: 必须指向存在的 scaffold 文件
  (.lean 或 formalization_progress.md), 不要求 verification.json, 不得声称
  FORMALLY_VERIFIED.
- 门禁 (validate_pipeline.py): 2026-08-16 之后开始且有实质进展的 run 必须记录
  `formalization: scaffold | requested`, 否则 FAIL; 旧 run 不追溯.

## Changelog (2026-08-16, handoff improvement)
- 交接记录独立成文并增强: 必须包含 `Completed work progress` (已完成工作进度,
  后续不得重做) 与 `Tools and methods tried` (尝试过的工具/方法/命令 + 结果标记
  + 证据路径 + sha256); 门禁新增这两个必需 section, 缺失即 FAIL.
- Lean 中间验证与覆盖: Stage B 增加 Intermediate Lean checkpoints (承重引理
  尽早 lean_verify); Stage C 明确更先进结果可把旧 scaffold/partial 标记
  `superseded` 并保留历史.
- 新增 Proof submission audit: 证明文件提交仓库前必须走 仓库比对 -> Lean 验证与
  审计 -> 依规则加入 三阶段流程 (由 manage 8e 负责).
- 效率优化: 引入 Tier 0/1/2 分级验证 (scaffold / 单引理机器验证 / 全量验证);
  新增 lemma reuse index, 证明前先查 `lean-proof/LEMMA_INDEX.md` 避免重复证明.
- Rethlas 蒸馏: Stage B 增加失败综合与反例复用 (key_failures_summary + 反例库),
  并明确搜索是支撑不是替代.
- 双轨审计: Stage C 增加非正式审计 + Lean 形式化双轨验证矩阵, 冲突裁决规则
  (非正式 gap > Lean 通过; Lean 失败 > 非正式通过; 论文级失败 > 两者).
- OpenProver token-conscious 吸收: 新增 `references/openprover-absorption.md`;
  Stage B 增加 Planner action 协议、Repository item 系统、`theorem.lean`
  前置骨架、Planner history、token budget pause+handoff+resume.
- 研究地图: Stage A/B/C 阶段边界强制更新 `research_map.md` (路线/方法/中间
  结果/失败原因/工具/开放方向/avoid list/人类补充); 深挖子分支前先读地图避免
  钻牛角尖.

## Changelog (2026-08-16, cost-tiered escalation)
- Stage B 新增 cost-tiered escalation (light first): Planner 先跑 Tier 0/1
  cheap probes (已有工件/工具库/特化/弱化/实例化/局部修补), 按信息增益/成本
  排序行动, 只有 zero-gain / 反例障碍 / load-bearing gap / 用户授权才升到
  Tier 2/3; 并行 fan-out 视为 Tier 3, 禁止无记录直接并行; 白板模板新增
  `current_cost_tier` 与 `last_escalation_reason`; 详细协议见 rigorous
  `references/escalation-ladder.md`.

## Changelog (2026-08-23, lightweight reuse protocol)
- Stage B 新增轻量 reuse 协议 (mandatory default): compact pre-scan (research_map +
  tools/README + LEMMA_INDEX + latest final/handoff), 不再要求 per-route REUSE
  标记; 每个实质 run 必须写 `reuse_summary.md` 并满足最低产物清单; 新 STRICT/
  partial 结果必须补 Lean scaffold. 详细协议见 `references/reuse-protocol.md`.
- 来源: 三轮受控 plugin 性能实验 (A6 / B3 / DensBC O1'), 轻量协议在硬问题上
  显著减少步骤/工具调用/cache, 同时保留可审计产物.

## Changelog (2026-08-23, performance observability)
- Stage B 新增性能可观测与示警: 运行后若有 performance.json, 用
  `scripts/performance_alert.py` 与可比 baseline 比较; 成本指标大幅上升且
  产物/复用未改善时, 写 `performance_alert.md` 并在 final_report 中向用户
  示警. 告警是候选, 不是定论: 单次实验可能误导 (e.g. reuse-gate 在简单/困难
  问题上呈现不同权衡), 需同问题类重跑或换问题类验证后才下结论.
- 新增 `references/performance-observability.md` 与
  `assets/performance-alert.template.md`.

## Changelog (2026-09-09, DSH 2.0 adaptation)

- Short runtime notes describe skill loading and bundled paths. Research
  choices remain with the parent 2.0 guidance and the user's project.
- Background jobs and task fan-out are optional execution tools; the layer
  adds no prescribed research roles, stage sequence or quota procedure.
- Sync carries root smoke/unit tests, plugin-level helpers and v2 guides.
  Only declared layout rewrites and DSH-owned files differ from the parent.
