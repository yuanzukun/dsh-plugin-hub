/** Deterministic scripted Phone provider for unit and assembled tests. */

import { createHash, randomUUID } from 'node:crypto'
import { setTimeout as waitTimer } from 'node:timers/promises'
import { PhoneDeviceId, PhoneDeviceRegistry, PhoneError, PhoneObservationId } from '../core/index.ts'
import type {
  PhoneCapture,
  PhoneDevice,
  PhoneDeviceId as PhoneDeviceIdType,
  PhoneDeviceInfo,
  PhoneHierarchy,
  PhoneKey,
  PhoneObservation,
  PhoneScreenshot,
  PhoneShellRequest,
  PhoneUIElement,
  StableScreenOptions,
  StableScreenResult,
} from '../core/index.ts'
import type { Context } from '@deepseek-ai/cordis'

/** Low-level operation recorded by a fake device. */
export type FakePhoneOperation =
  | { readonly type: 'tap'; readonly x: number; readonly y: number }
  | { readonly type: 'long_press'; readonly x: number; readonly y: number; readonly durationMs: number }
  | { readonly type: 'swipe'; readonly x1: number; readonly y1: number; readonly x2: number; readonly y2: number; readonly durationMs: number }
  | { readonly type: 'input_text'; readonly text: string }
  | { readonly type: 'replace_text'; readonly text: string }
  | { readonly type: 'setup_unicode_input' }
  | { readonly type: 'press_key'; readonly key: PhoneKey }
  | { readonly type: 'back' }
  | { readonly type: 'home' }
  | { readonly type: 'open_app'; readonly packageName: string }
  | { readonly type: 'shell'; readonly request: PhoneShellRequest }

/** One state transition accepted by a scripted fake screen. */
export interface FakePhoneTransition {
  /** Exact low-level operation expected. */
  readonly operation: FakePhoneOperation
  /** Destination screen id. */
  readonly to: string
  /** Optional failure injected before the transition. */
  readonly error?: Error
}

/** One named screen and its accepted transitions. */
export interface FakePhoneScreen {
  /** Screen id referenced by transitions. */
  readonly id: string
  /** Coherent capture returned while this screen is active. */
  readonly capture: PhoneCapture
  /** Operations accepted from this screen. */
  readonly transitions: readonly FakePhoneTransition[]
}

/** Script for one fake Android device. */
export interface FakePhoneScript {
  /** Device record returned by discovery. */
  readonly device: PhoneDeviceInfo
  /** Initial screen id. */
  readonly initialScreen: string
  /** Complete finite screen set. */
  readonly screens: readonly FakePhoneScreen[]
}

/** Deterministic fake device with an observable operation ledger. */
export class FakePhoneDevice implements PhoneDevice {
  /** Accepted operations in execution order. */
  readonly operations: FakePhoneOperation[] = []
  private readonly screens: ReadonlyMap<string, FakePhoneScreen>
  private current: string

  /**
   * Create one scripted device.
   * @param script - Finite screen graph and discovery record.
   */
  constructor(private readonly script: FakePhoneScript) {
    this.screens = new Map(script.screens.map(screen => [screen.id, screen]))
    if (!this.screens.has(script.initialScreen)) throw new Error(`fake phone initial screen ${script.initialScreen} is missing`)
    this.current = script.initialScreen
  }

  /** Bound fake device identity. */
  get id(): PhoneDeviceIdType {
    return this.script.device.id
  }

  /** @inheritdoc */
  getState(): Promise<PhoneCapture> {
    return Promise.resolve(this.screen().capture)
  }

  /** @inheritdoc */
  screenshot(): Promise<PhoneScreenshot> {
    return Promise.resolve(this.screen().capture.screenshot)
  }

  /** @inheritdoc */
  getUIHierarchy(): Promise<PhoneHierarchy> {
    const observation = this.screen().capture.observation
    return Promise.resolve({
      elements: observation.elements,
      signature: observation.uiSignature,
      truncated: observation.hierarchyTruncated,
    })
  }

  /** @inheritdoc */
  tap(x: number, y: number): Promise<void> {
    return this.perform({ type: 'tap', x, y })
  }

  /** @inheritdoc */
  longPress(x: number, y: number, durationMs: number): Promise<void> {
    return this.perform({ type: 'long_press', x, y, durationMs })
  }

  /** @inheritdoc */
  swipe(x1: number, y1: number, x2: number, y2: number, durationMs: number): Promise<void> {
    return this.perform({ type: 'swipe', x1, y1, x2, y2, durationMs })
  }

  /** @inheritdoc */
  inputText(text: string): Promise<void> {
    return this.perform({ type: 'input_text', text })
  }

  /** @inheritdoc */
  replaceText(text: string): Promise<void> {
    return this.perform({ type: 'replace_text', text })
  }

  /** @inheritdoc */
  setupUnicodeInput(): Promise<void> {
    return this.perform({ type: 'setup_unicode_input' })
  }

  /** @inheritdoc */
  pressKey(key: PhoneKey): Promise<void> {
    return this.perform({ type: 'press_key', key })
  }

  /** @inheritdoc */
  back(): Promise<void> {
    return this.perform({ type: 'back' })
  }

  /** @inheritdoc */
  home(): Promise<void> {
    return this.perform({ type: 'home' })
  }

  /** @inheritdoc */
  openApp(packageName: string): Promise<void> {
    return this.perform({ type: 'open_app', packageName })
  }

  /** @inheritdoc */
  async shell(request: PhoneShellRequest): Promise<string> {
    await this.perform({ type: 'shell', request })
    return ''
  }

  /** @inheritdoc */
  async wait(ms: number, signal?: AbortSignal): Promise<void> {
    await waitTimer(ms, undefined, { signal })
  }

  /** @inheritdoc */
  waitForStableScreen(_options: StableScreenOptions): Promise<StableScreenResult> {
    return Promise.resolve({
      screenshot: this.screen().capture.screenshot,
      stable: true,
      timedOut: false,
      samples: 1,
      difference: 0,
    })
  }

  private perform(operation: FakePhoneOperation): Promise<void> {
    this.operations.push(operation)
    const transition = this.screen().transitions.find(candidate =>
      JSON.stringify(candidate.operation) === JSON.stringify(operation))
    if (transition === undefined) {
      return Promise.reject(new PhoneError(
        'PHONE_ACTION_REJECTED',
        `fake screen ${JSON.stringify(this.current)} does not accept ${JSON.stringify(operation)}`,
      ))
    }
    if (transition.error !== undefined) return Promise.reject(transition.error)
    if (!this.screens.has(transition.to)) return Promise.reject(new Error(`fake transition target ${transition.to} is missing`))
    this.current = transition.to
    return Promise.resolve()
  }

  private screen(): FakePhoneScreen {
    const screen = this.screens.get(this.current)
    if (screen === undefined) throw new Error(`fake screen ${this.current} is missing`)
    return screen
  }
}

/** `ctx.phone` provider whose devices are finite scripted state machines. */
export class FakePhoneDeviceRegistry extends PhoneDeviceRegistry {
  private readonly devices: ReadonlyMap<PhoneDeviceIdType, FakePhoneDevice>

  /**
   * Register fake scripts as one Phone provider.
   * @param ctx - Cordis context receiving `ctx.phone`.
   * @param scripts - One script per fake device.
   */
  constructor(ctx: Context, scripts: readonly FakePhoneScript[]) {
    super(ctx)
    this.devices = new Map(scripts.map(script => [script.device.id, new FakePhoneDevice(script)]))
  }

  /** @inheritdoc */
  list(): Promise<readonly PhoneDeviceInfo[]> {
    return Promise.resolve([...this.devices.values()].map(device => ({ id: device.id, status: 'device' })))
  }

  /** @inheritdoc */
  connect(): Promise<PhoneDeviceInfo> {
    return Promise.reject(new PhoneError('PHONE_ACTION_REJECTED', 'fake devices do not support wireless connection'))
  }

  /** @inheritdoc */
  open(id: PhoneDeviceIdType): Promise<PhoneDevice> {
    const device = this.devices.get(id)
    return device === undefined
      ? Promise.reject(new PhoneError('PHONE_DEVICE_NOT_FOUND', `fake device ${JSON.stringify(id)} was not found`))
      : Promise.resolve(device)
  }

  /**
   * Return a fake device for ledger assertions.
   * @param id - Scripted device identity.
   * @returns Exact fake device instance.
   */
  device(id: PhoneDeviceIdType): FakePhoneDevice {
    const device = this.devices.get(id)
    if (device === undefined) throw new Error(`fake device ${id} is missing`)
    return device
  }
}

/** Input for the compact fake-capture builder. */
export interface FakeCaptureInput {
  /** Device identity. */
  readonly deviceId?: PhoneDeviceIdType
  /** Display width. */
  readonly width?: number
  /** Display height. */
  readonly height?: number
  /** Foreground package. */
  readonly foregroundPackage?: string
  /** Foreground activity. */
  readonly activity?: string
  /** Retained UI elements. */
  readonly elements?: readonly PhoneUIElement[]
  /** Unique semantic state label. */
  readonly state?: string
}

/**
 * Build a coherent small capture for scripted tests.
 * @param input - Optional geometry, app identity, elements, and state label.
 * @returns Capture with deterministic signatures and valid PNG header bytes.
 */
export function createFakeCapture(input: FakeCaptureInput = {}): PhoneCapture {
  const deviceId = input.deviceId ?? PhoneDeviceId('fake-1')
  const width = input.width ?? 1080
  const height = input.height ?? 2400
  const elements = input.elements ?? []
  const state = input.state ?? JSON.stringify(elements)
  const timestamp = Date.now()
  const digest = createHash('sha256').update(state).digest('hex')
  const screenshot: PhoneScreenshot = {
    data: Buffer.from('89504e470d0a1a0a', 'hex'),
    width,
    height,
    timestamp,
    digest,
    comparisonSignature: Buffer.alloc(32 * 32, digest.charCodeAt(0)).toString('base64'),
  }
  const observation: PhoneObservation = {
    id: PhoneObservationId(randomUUID()),
    deviceId,
    timestamp,
    width,
    height,
    orientation: width === height ? 'square' : width > height ? 'landscape' : 'portrait',
    screenshotDigest: digest,
    screenshotSignature: screenshot.comparisonSignature,
    ...(input.foregroundPackage === undefined ? {} : { foregroundPackage: input.foregroundPackage }),
    ...(input.activity === undefined ? {} : { activity: input.activity }),
    elements,
    uiSignature: createHash('sha256').update(JSON.stringify(elements)).update(state).digest('hex'),
    hierarchyTruncated: false,
  }
  return { observation, screenshot }
}
