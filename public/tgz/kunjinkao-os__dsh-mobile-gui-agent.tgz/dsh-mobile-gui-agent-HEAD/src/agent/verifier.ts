/** Deterministic before/after Phone action verification. */

import type { PhoneAction, PhoneObservation, PhoneUIElement, PhoneVerification } from '../core/index.ts'
import { findStablePhoneElement } from './elements.ts'

/**
 * Compare independent UI evidence after one device action.
 * @param before - Fresh pre-action observation.
 * @param action - Executed action.
 * @param after - Fresh stable post-action observation.
 * @param target - Semantic target resolved before execution, when any.
 * @returns Verification success, change fact, and evidence statements.
 */
export function verifyPhoneAction(
  before: PhoneObservation,
  action: PhoneAction,
  after: PhoneObservation,
  target?: PhoneUIElement,
): PhoneVerification {
  const evidence: string[] = []
  const appChanged = before.foregroundPackage !== after.foregroundPackage
  const activityChanged = before.activity !== after.activity
  const geometryChanged = before.width !== after.width || before.height !== after.height
  const uiChanged = before.uiSignature !== after.uiSignature
  const screenshotChanged = before.screenshotSignature !== after.screenshotSignature
  if (appChanged) evidence.push(`foreground package changed from ${before.foregroundPackage ?? 'unknown'} to ${after.foregroundPackage ?? 'unknown'}`)
  if (activityChanged) evidence.push(`activity changed from ${before.activity ?? 'unknown'} to ${after.activity ?? 'unknown'}`)
  if (geometryChanged) evidence.push(`display changed from ${before.width}x${before.height} to ${after.width}x${after.height}`)
  if (uiChanged) evidence.push('compact UI hierarchy changed')
  if (screenshotChanged) evidence.push('screenshot changed')
  const changed = appChanged || activityChanged || geometryChanged || uiChanged || screenshotChanged
  const facts = {
    foregroundPackageChanged: appChanged,
    activityChanged,
    displayChanged: geometryChanged,
    uiHierarchyChanged: uiChanged,
    screenshotChanged,
  }

  const textVerification = verifyTextAction(before, action, after, evidence)
  if (textVerification !== undefined) {
    return { success: textVerification, changed, evidence, facts: { ...facts, textChanged: textVerification } }
  }

  if (action.type === 'setup_unicode_input') {
    evidence.push('the provider installed or probed the Unicode helper and restored the previous input method')
    return { success: true, changed, evidence, facts }
  }

  if (target?.checked !== undefined) {
    const matching = findStablePhoneElement(target, after.elements)
    if (matching?.checked !== undefined && matching.checked !== target.checked) {
      evidence.push(`target checked changed from ${String(target.checked)} to ${String(matching.checked)}`)
      return { success: true, changed: true, evidence, facts: { ...facts, uiHierarchyChanged: true } }
    }
  }
  if (action.type === 'open_app') {
    const success = after.foregroundPackage === action.packageName
    if (success) evidence.push(`foreground package is ${action.packageName}`)
    else evidence.push(`foreground package is ${after.foregroundPackage ?? 'unknown'}, expected ${action.packageName}`)
    return { success, changed, evidence, facts }
  }
  if (action.type === 'wait') {
    evidence.push(changed ? 'screen settled after observable change' : 'screen remained stable')
    return { success: true, changed, evidence, facts }
  }
  if (action.type === 'finish') {
    evidence.push('terminal decision used a fresh observation')
    return { success: true, changed, evidence, facts }
  }
  if (!changed) evidence.push('no foreground, hierarchy, geometry, or screenshot change was observed')
  return { success: changed, changed, evidence, facts }
}

/** Verify text-editing actions against the focused editable field, never the whole screen. */
function verifyTextAction(
  before: PhoneObservation,
  action: PhoneAction,
  after: PhoneObservation,
  evidence: string[],
): boolean | undefined {
  if (action.type === 'press_key' && action.key !== 'delete') return undefined
  if (action.type !== 'press_key' && action.type !== 'input_text' && action.type !== 'replace_text') return undefined
  const beforeField = before.elements.find(element => element.editable && element.focused)
  if (beforeField === undefined) {
    evidence.push('no focused editable field was present before the text action')
    return false
  }
  const afterField = findStablePhoneElement(beforeField, after.elements)
  if (afterField === undefined) {
    evidence.push('the focused editable field could not be matched after the text action')
    return false
  }
  const beforeText = beforeField.text ?? ''
  const afterText = afterField.text ?? ''
  if (action.type === 'press_key') {
    if (Array.from(afterText).length < Array.from(beforeText).length) {
      evidence.push(`focused editable text length changed from ${Array.from(beforeText).length} to ${Array.from(afterText).length}`)
      return true
    }
    evidence.push('focused editable text did not become shorter')
    return false
  }
  if (action.type === 'input_text') {
    if (afterText !== beforeText) {
      evidence.push('focused editable text changed after input')
      return true
    }
    evidence.push('focused editable text did not change after input')
    return false
  }
  if (afterText === action.text && afterText !== beforeText) {
    evidence.push('focused editable text matches the requested replacement')
    return true
  }
  evidence.push('focused editable text does not show the requested replacement')
  return false
}
