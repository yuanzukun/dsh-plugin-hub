/** Phone run orchestration configuration and explicit defaults. */

import type { Config } from './index.ts'

/** Complete validated run configuration. */
export interface ResolvedConfig {
  readonly maxSteps: number
  readonly taskTimeoutMs: number
  readonly actionTimeoutMs: number
  readonly maxConsecutiveFailures: number
  readonly stablePollMs: number
  readonly stableSamples: number
  readonly stableTimeoutMs: number
  readonly stableDifferenceThreshold: number
  readonly approvalEnabled: boolean
  readonly traceScreenshots: boolean
  readonly maxTraceSteps: number
}

/**
 * Materialize and validate Phone run defaults.
 * @param config - Loader-parsed configuration.
 * @returns Complete configuration.
 */
export function resolveConfig(config: Config): ResolvedConfig {
  const resolved: ResolvedConfig = {
    maxSteps: config.maxSteps ?? 50,
    taskTimeoutMs: config.taskTimeoutMs ?? 10 * 60_000,
    actionTimeoutMs: config.actionTimeoutMs ?? 10_000,
    maxConsecutiveFailures: config.maxConsecutiveFailures ?? 5,
    stablePollMs: config.stablePollMs ?? 300,
    stableSamples: config.stableSamples ?? 3,
    stableTimeoutMs: config.stableTimeoutMs ?? 5_000,
    stableDifferenceThreshold: config.stableDifferenceThreshold ?? 0.01,
    approvalEnabled: config.approvalEnabled ?? true,
    traceScreenshots: config.traceScreenshots ?? true,
    maxTraceSteps: config.maxTraceSteps ?? 100,
  }
  for (const key of [
    'maxSteps',
    'taskTimeoutMs',
    'actionTimeoutMs',
    'maxConsecutiveFailures',
    'stablePollMs',
    'stableSamples',
    'stableTimeoutMs',
    'maxTraceSteps',
  ] as const) {
    if (!Number.isSafeInteger(resolved[key]) || resolved[key] < 1) {
      throw new Error(`phone-agent: ${key} must be a positive safe integer`)
    }
  }
  if (!Number.isFinite(resolved.stableDifferenceThreshold)
    || resolved.stableDifferenceThreshold < 0
    || resolved.stableDifferenceThreshold > 1) {
    throw new Error('phone-agent: stableDifferenceThreshold must be between 0 and 1')
  }
  return resolved
}
