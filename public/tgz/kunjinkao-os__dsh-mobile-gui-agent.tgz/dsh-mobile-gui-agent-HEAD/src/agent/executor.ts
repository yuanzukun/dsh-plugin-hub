/** Deterministic one-action Phone executor with approval, stabilization, and verification. */

import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { PhoneError } from '../core/index.ts'
import type {
  PhoneAction,
  PhoneActionError,
  PhoneCapture,
  PhoneDevice,
  PhoneUIElement,
  PhoneVerification,
  StableScreenResult,
} from '../core/index.ts'
import { classifyPhoneAction, requirePhoneApproval } from './approval.ts'
import type { PhoneApprovalRequest } from './approval.ts'
import type { ResolvedConfig } from './config.ts'
import { verifyPhoneAction } from './verifier.ts'

/** Raw executor outcome before run counters, stuck detection, and model serialization. */
export interface ExecutedPhoneAction {
  /** Whether a device side effect was attempted. */
  readonly executed: boolean
  /** Fresh state after execution or rejection. */
  readonly after: PhoneCapture
  /** Verification based on before and after. */
  readonly verification: PhoneVerification
  /** Structured execution failure. */
  readonly error?: PhoneActionError
  /** Adaptive stabilization facts without duplicate screenshot bytes. */
  readonly stability?: Omit<StableScreenResult, 'screenshot'>
  /** Semantic element resolved before execution. */
  readonly target?: PhoneUIElement
}

/** Runtime progress exposed while one action is still unsettled. */
export type PhoneActionExecutionPhase = 'executing' | 'awaiting_approval' | 'stabilizing'

/** Executes one approved Phone action against one device handle. */
export class PhoneActionExecutor {
  /**
   * Create an executor using existing Harness services and run policy.
   * @param ctx - Context carrying optional approval.
   * @param config - Resolved action, stability, and approval limits.
   */
  constructor(
    private readonly ctx: Context,
    private readonly config: ResolvedConfig,
  ) {}

  /**
   * Execute one non-terminal action and always attempt a post-action observation.
   * @param agent - Agent whose current tool turn owns approval.
   * @param device - Reserved Phone device.
   * @param before - Fresh pre-action state.
   * @param action - Strict non-terminal action.
   * @param signal - Run and tool cancellation.
   * @param onApprovalRequired - Optional callback before the shared approval request opens.
   * @param onProgress - Optional callback publishing execution progress.
   * @returns Execution, stabilization, verification, and recoverable error facts.
   */
  async execute(
    agent: Agent,
    device: PhoneDevice,
    before: PhoneCapture,
    action: Exclude<PhoneAction, { readonly type: 'finish' }>,
    signal: AbortSignal,
    onApprovalRequired?: (request: PhoneApprovalRequest) => void,
    onProgress?: (phase: PhoneActionExecutionPhase) => void,
  ): Promise<ExecutedPhoneAction> {
    let operationSignal = signal
    const target = action.type === 'tap_element'
      ? before.observation.elements.find(element => element.id === action.elementId)
      : undefined
    if (action.type === 'tap_element' && target === undefined) {
      const message = `element ${action.elementId} is absent from the fresh observation`
      return {
        executed: false,
        after: before,
        verification: { success: false, changed: false, evidence: [message] },
        error: { code: 'PHONE_ELEMENT_NOT_FOUND', message },
      }
    }
    try {
      const request = classifyPhoneAction(action, before.observation)
      const approvalRequired = request !== undefined
        && (this.config.approvalEnabled || action.type === 'setup_unicode_input')
      if (approvalRequired) {
        onProgress?.('awaiting_approval')
        onApprovalRequired?.(request)
        await requirePhoneApproval(this.ctx, agent, request, signal)
        onProgress?.('executing')
      }
      operationSignal = AbortSignal.any([signal, AbortSignal.timeout(this.config.actionTimeoutMs)])
      await executeDeviceAction(device, action, target, operationSignal)
    } catch (error: unknown) {
      const after = await recoverState(device, before, operationSignal)
      const structured = actionError(error, operationSignal)
      return {
        executed: !isPreflightRejection(structured.code),
        after,
        verification: { success: false, changed: stateChanged(before, after), evidence: [structured.message] },
        error: structured,
        ...(target === undefined ? {} : { target }),
      }
    }
    let stability: StableScreenResult | undefined
    try {
      onProgress?.('stabilizing')
      stability = await device.waitForStableScreen({
        pollMs: this.config.stablePollMs,
        stableSamples: this.config.stableSamples,
        timeoutMs: this.config.stableTimeoutMs,
        differenceThreshold: this.config.stableDifferenceThreshold,
      }, operationSignal)
      const after = await device.getState(operationSignal)
      const { screenshot: _screenshot, ...stabilityFacts } = stability
      return {
        executed: true,
        after,
        verification: verifyPhoneAction(before.observation, action, after.observation, target),
        stability: stabilityFacts,
        ...(target === undefined ? {} : { target }),
      }
    } catch (error: unknown) {
      const after = await recoverState(device, before, operationSignal)
      const structured = actionError(error, operationSignal)
      return {
        executed: true,
        after,
        verification: { success: false, changed: stateChanged(before, after), evidence: [structured.message] },
        error: structured,
        ...(stability === undefined ? {} : {
          stability: {
            stable: stability.stable,
            timedOut: stability.timedOut,
            samples: stability.samples,
            difference: stability.difference,
          },
        }),
        ...(target === undefined ? {} : { target }),
      }
    }
  }

}

/** Dispatch one canonical action to exactly one device method. */
async function executeDeviceAction(
  device: PhoneDevice,
  action: Exclude<PhoneAction, { readonly type: 'finish' }>,
  target: PhoneUIElement | undefined,
  signal: AbortSignal,
): Promise<void> {
  switch (action.type) {
    case 'tap_element': {
      if (target === undefined) throw new PhoneError('PHONE_ELEMENT_NOT_FOUND', `element ${action.elementId} is absent`)
      const x = Math.floor((target.bounds[0] + target.bounds[2]) / 2)
      const y = Math.floor((target.bounds[1] + target.bounds[3]) / 2)
      await device.tap(x, y, signal)
      return
    }
    case 'tap': await device.tap(action.x, action.y, signal); return
    case 'long_press': await device.longPress(action.x, action.y, action.durationMs ?? 800, signal); return
    case 'swipe': await device.swipe(action.x1, action.y1, action.x2, action.y2, action.durationMs ?? 300, signal); return
    case 'input_text': await device.inputText(action.text, signal); return
    case 'replace_text': await device.replaceText(action.text, signal); return
    case 'setup_unicode_input': {
      if (device.setupUnicodeInput === undefined) {
        throw new PhoneError('PHONE_UNICODE_INPUT_UNSUPPORTED', 'the active Phone provider does not support approved Unicode helper setup')
      }
      await device.setupUnicodeInput(signal)
      return
    }
    case 'press_key': await device.pressKey(action.key, signal); return
    case 'back': await device.back(signal); return
    case 'home': await device.home(signal); return
    case 'open_app': await device.openApp(action.packageName, signal); return
    case 'wait': await device.wait(action.ms, signal); return
  }
}

/** Errors known to occur before a device side effect is attempted. */
function isPreflightRejection(code: PhoneActionError['code']): boolean {
  return code === 'PHONE_APPROVAL_DENIED'
    || code === 'PHONE_ELEMENT_NOT_FOUND'
    || code === 'PHONE_UNICODE_INPUT_UNSUPPORTED'
}

/** Capture recovery state without replacing the original actionable error. */
async function recoverState(device: PhoneDevice, before: PhoneCapture, signal: AbortSignal): Promise<PhoneCapture> {
  try {
    return await device.getState(signal.aborted ? undefined : signal)
  } catch (_postFailureObservationUnavailable) {
    return before
  }
}

/** Normalize provider, approval, and timeout failures. */
function actionError(error: unknown, signal: AbortSignal): PhoneActionError {
  if (error instanceof PhoneError) return { code: error.code, message: error.message }
  if (signal.aborted) return { code: 'PHONE_ACTION_TIMEOUT', message: 'Phone action timed out or was cancelled' }
  return { code: 'PHONE_ADB_FAILED', message: error instanceof Error ? error.message : String(error) }
}

/** Compare the state dimensions used by recovery verification. */
function stateChanged(before: PhoneCapture, after: PhoneCapture): boolean {
  return before.observation.uiSignature !== after.observation.uiSignature
    || before.observation.screenshotSignature !== after.observation.screenshotSignature
    || before.observation.foregroundPackage !== after.observation.foregroundPackage
    || before.observation.activity !== after.observation.activity
}
