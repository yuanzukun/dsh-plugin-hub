/** Stable semantic element matching across independently captured hierarchies. */

import type {
  PhoneActionError,
  PhoneBounds,
  PhoneObservation,
  PhoneUIElement,
} from '../core/index.ts'
import type { PhoneAction } from '../core/index.ts'

/** Successful rebinding of an observation-local semantic tap. */
export interface RevalidatedTapElementAction {
  /** Action rewritten to the fresh observation and element ids. */
  readonly action: Extract<PhoneAction, { readonly type: 'tap_element' }>
  /** Unique matching element in the fresh hierarchy. */
  readonly target: PhoneUIElement
}

/** Failed semantic tap rebinding. */
export interface RejectedTapElementAction {
  /** Structured stale-observation reason. */
  readonly error: PhoneActionError
}

/**
 * Find one unique element using attributes that should survive text and list-order changes.
 * @param target - Element from an earlier observation.
 * @param elements - Elements in a fresh observation.
 * @returns The unique stable match, otherwise undefined.
 */
export function findStablePhoneElement(
  target: PhoneUIElement,
  elements: readonly PhoneUIElement[],
): PhoneUIElement | undefined {
  const matches = elements.filter(element =>
    element.className === target.className
    && element.resourceId === target.resourceId
    && element.contentDescription === target.contentDescription
    && sameBounds(element.bounds, target.bounds))
  return matches.length === 1 ? matches[0] : undefined
}

/**
 * Revalidate only a semantic tap target instead of rejecting unrelated screen changes.
 * @param action - Model-authored semantic tap.
 * @param visible - Last observation actually shown to the model.
 * @param fresh - Fresh pre-action observation.
 * @returns A fresh observation-local action or a structured stale rejection.
 */
export function revalidateTapElementAction(
  action: Extract<PhoneAction, { readonly type: 'tap_element' }>,
  visible: PhoneObservation | undefined,
  fresh: PhoneObservation,
): RevalidatedTapElementAction | RejectedTapElementAction {
  if (visible === undefined || action.observationId !== visible.id) {
    return stale('element action does not reference the last model-visible observation')
  }
  const originalTarget = visible.elements.find(element => element.id === action.elementId)
  if (originalTarget === undefined) {
    return stale(`element ${action.elementId} is absent from the model-visible observation`)
  }
  const target = findStablePhoneElement(originalTarget, fresh.elements)
  if (target === undefined) {
    return stale(`element ${action.elementId} moved, changed identity, disappeared, or became ambiguous`)
  }
  return {
    action: {
      type: 'tap_element',
      observationId: fresh.id,
      elementId: target.id,
    },
    target,
  }
}

/** Exact bounds equality prevents clicks after target movement. */
function sameBounds(left: PhoneBounds, right: PhoneBounds): boolean {
  return left.every((value, index) => value === right[index])
}

/** Build one consistent stale-target result. */
function stale(message: string): RejectedTapElementAction {
  return { error: { code: 'PHONE_STALE_OBSERVATION', message } }
}
