/** Typert Remote adapter for the Phone GUI; business behavior remains in `ctx.phoneRuns`. */

import { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import '../core/index.ts'
import type { PhoneDeviceId, PhoneDeviceInfo, PhoneRunView, StartPhoneRunRequest } from '../core/index.ts'
import { Remote, TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol'
import type { PhoneScreenshotResponse } from './types.ts'

export type { PhoneScreenshotResponse } from './types.ts'

declare module '@deepseek-ai/cordis' {
  interface Context {
    phoneAgent: PhoneAgentRemote
  }
}

/** Host Remote namespace that delegates every call to the abstract Phone run service. */
export class PhoneAgentRemote extends TypertRemoteService {
  /** Agent lookup and Phone run service dependencies. */
  static inject = ['agents', 'phoneRuns']

  /** Register the `phoneAgent` Remote namespace. */
  constructor(ctx: Context) {
    super(ctx, 'phoneAgent')
  }

  /**
   * List current provider devices.
   * @returns Device records including unusable states.
   */
  @Remote('listDevices')
  listDevices(): Promise<readonly PhoneDeviceInfo[]> {
    return this.ctx.phoneRuns.listDevices()
  }

  /**
   * Connect one wireless ADB endpoint.
   * @param address - Host and port.
   * @returns Connected device record.
   */
  @Remote('connect')
  connect(address: string): Promise<PhoneDeviceInfo> {
    return this.ctx.phoneRuns.connect(address)
  }

  /**
   * Return the exact Agent's current Phone run.
   * @param agent - Typert-resolved live Agent.
   * @returns Run view or undefined before start.
   */
  @Remote('getView')
  getView(agent: Agent): PhoneRunView | undefined {
    return this.ctx.phoneRuns.getView(agent)
  }

  /**
   * Capture a screenshot for the active run or selected idle device.
   * @param agent - Typert-resolved live Agent.
   * @param deviceId - Optional selected device before start.
   * @returns Bounded base64 PNG and intrinsic metadata.
   */
  @Remote('getScreenshot')
  async getScreenshot(agent: Agent, deviceId?: PhoneDeviceId): Promise<PhoneScreenshotResponse> {
    const screenshot = await this.ctx.phoneRuns.getScreenshot(agent, deviceId)
    return {
      data: Buffer.from(screenshot.data).toString('base64'),
      width: screenshot.width,
      height: screenshot.height,
      timestamp: screenshot.timestamp,
    }
  }

  /**
   * Start one Phone run.
   * @param agent - Typert-resolved live Agent.
   * @param request - Concrete device and task.
   * @returns Initial run view.
   */
  @Remote('start')
  start(agent: Agent, request: StartPhoneRunRequest): Promise<PhoneRunView> {
    return this.ctx.phoneRuns.start(agent, request)
  }

  /**
   * Pause one Phone run.
   * @param agent - Typert-resolved live Agent.
   * @returns Paused run view.
   */
  @Remote('pause')
  pause(agent: Agent): Promise<PhoneRunView> {
    return this.ctx.phoneRuns.pause(agent)
  }

  /**
   * Resume one Phone run.
   * @param agent - Typert-resolved live Agent.
   * @returns Running run view.
   */
  @Remote('resume')
  resume(agent: Agent): Promise<PhoneRunView> {
    return this.ctx.phoneRuns.resume(agent)
  }

  /**
   * Stop one Phone run.
   * @param agent - Typert-resolved live Agent.
   * @returns Stopped run view after quiescence.
   */
  @Remote('stop')
  stop(agent: Agent): Promise<PhoneRunView> {
    return this.ctx.phoneRuns.stop(agent)
  }
}

export default PhoneAgentRemote
