/** ADB Service Provider for the Android Phone capability. */

import { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { PhoneDeviceId, PhoneDeviceRegistry, PhoneError } from '../core/index.ts'
import type { PhoneDevice, PhoneDeviceId as PhoneDeviceIdType, PhoneDeviceInfo } from '../core/index.ts'
import { AdbClient } from './adb-client.ts'
import { AdbPhoneDevice } from './adb-device.ts'
import { resolveConfig, type ResolvedConfig } from './config.ts'
import { parseAdbDevices, parseWirelessAddress } from './devices.ts'

export { AdbClient } from './adb-client.ts'
export { AdbPhoneDevice } from './adb-device.ts'
export { resolveConfig } from './config.ts'
export type { ResolvedConfig } from './config.ts'
export { boundsCenter, extractHierarchyXml, parseUiHierarchy, serializeHierarchy } from './hierarchy.ts'
export { parseAdbDevices, parseWirelessAddress } from './devices.ts'
export { decodeScreenshot, screenshotDifference } from './screenshot.ts'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'phone-adb'
/** Services required by the ADB provider. */
export const inject = ['subprocess']

/** Deployment tunables for bounded ADB observation and actions. */
export interface Config {
  /** ADB executable path or PATH name. */
  adbPath?: string
  /** Absolute path to a user-reviewed ADB Keyboard APK eligible for approved installation. */
  unicodeImeApkPath?: string
  /** Per-command timeout in milliseconds. */
  commandTimeoutMs?: number
  /** Process termination grace in milliseconds. */
  processGraceMs?: number
  /** Maximum PNG bytes accepted from one screenshot. */
  screenshotMaxBytes?: number
  /** Maximum hierarchy XML bytes accepted from one dump. */
  hierarchyMaxBytes?: number
  /** Maximum diagnostic bytes accepted from one command. */
  diagnosticMaxBytes?: number
  /** Maximum retained hierarchy element count. */
  hierarchyMaxElements?: number
  /** Maximum compact hierarchy text bytes. */
  hierarchyMaxSerializedBytes?: number
  /** Total UIAutomator capture attempts before an observation fails. */
  hierarchyAttempts?: number
  /** Delay between failed UIAutomator capture attempts in milliseconds. */
  hierarchyRetryDelayMs?: number
  /** Stable-screen poll interval in milliseconds. */
  stablePollMs?: number
  /** Consecutive stable comparisons required. */
  stableSamples?: number
  /** Stable-screen total timeout in milliseconds. */
  stableTimeoutMs?: number
  /** Normalized thumbnail difference considered stable. */
  stableDifferenceThreshold?: number
}

/** Public alias naming this provider's configuration. */
export type AdbPhoneConfig = Config

/** Loader-visible ADB provider configuration schema. */
export const Config: z<Config> = z.object({
  adbPath: z.string().default('adb'),
  unicodeImeApkPath: z.string(),
  commandTimeoutMs: z.number().default(10_000),
  processGraceMs: z.number().default(1_000),
  screenshotMaxBytes: z.number().default(16 * 1024 * 1024),
  hierarchyMaxBytes: z.number().default(4 * 1024 * 1024),
  diagnosticMaxBytes: z.number().default(64 * 1024),
  hierarchyMaxElements: z.number().default(400),
  hierarchyMaxSerializedBytes: z.number().default(64 * 1024),
  hierarchyAttempts: z.number().default(3),
  hierarchyRetryDelayMs: z.number().default(300),
  stablePollMs: z.number().default(300),
  stableSamples: z.number().default(3),
  stableTimeoutMs: z.number().default(5_000),
  stableDifferenceThreshold: z.number().default(0.01),
})

/** Concrete `ctx.phone` registry backed by the configured ADB executable. */
export class AdbPhoneDeviceRegistry extends PhoneDeviceRegistry {
  /** Required subprocess capability for direct class and Loader composition. */
  static inject = ['subprocess']
  /** Loader-visible provider configuration. */
  static Config = Config

  private readonly config: ResolvedConfig
  private readonly client: AdbClient

  /**
   * Register an ADB-backed Phone provider.
   * @param ctx - Cordis context carrying the subprocess capability.
   * @param config - Provider deployment configuration.
   */
  constructor(ctx: Context, config: Config = {}) {
    super(ctx)
    this.config = resolveConfig(config)
    this.client = new AdbClient(ctx.subprocess, this.config)
  }

  /** @inheritdoc */
  async list(signal?: AbortSignal): Promise<readonly PhoneDeviceInfo[]> {
    const result = await this.client.text(['devices', '-l'], this.config.diagnosticMaxBytes, signal)
    return parseAdbDevices(result.stdout)
  }

  /** @inheritdoc */
  async connect(address: string, signal?: AbortSignal): Promise<PhoneDeviceInfo> {
    const endpoint = parseWirelessAddress(address)
    await this.client.text(['connect', endpoint], this.config.diagnosticMaxBytes, signal)
    const record = (await this.list(signal)).find(device => device.id === endpoint)
    if (record === undefined) {
      throw new PhoneError('PHONE_DEVICE_NOT_FOUND', `ADB connected ${endpoint} but did not list the device`)
    }
    return record
  }

  /** @inheritdoc */
  async open(id: PhoneDeviceIdType, signal?: AbortSignal): Promise<PhoneDevice> {
    const record = (await this.list(signal)).find(device => device.id === id)
    if (record === undefined) throw new PhoneError('PHONE_DEVICE_NOT_FOUND', `ADB device ${JSON.stringify(id)} was not found`)
    if (record.status === 'offline') throw new PhoneError('PHONE_DEVICE_OFFLINE', `ADB device ${JSON.stringify(id)} is offline`)
    if (record.status === 'unauthorized') {
      throw new PhoneError('PHONE_DEVICE_UNAUTHORIZED', `authorize ADB debugging on device ${JSON.stringify(id)}`)
    }
    return new AdbPhoneDevice(PhoneDeviceId(id), this.client, this.config)
  }
}

export default AdbPhoneDeviceRegistry
