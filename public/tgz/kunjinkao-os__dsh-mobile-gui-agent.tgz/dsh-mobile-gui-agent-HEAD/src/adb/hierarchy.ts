/** UIAutomator XML parsing, pruning, and compact serialization. */

import { createHash } from 'node:crypto'
import { XMLParser } from 'fast-xml-parser'
import { PhoneError } from '../core/index.ts'
import type { PhoneBounds, PhoneHierarchy, PhoneUIElement } from '../core/index.ts'
import { serializePhoneElement } from '../core/serialize.ts'

/** Pruning limits applied before hierarchy data reaches a model or trace. */
export interface HierarchyLimits {
  /** Current display width. */
  readonly width: number
  /** Current display height. */
  readonly height: number
  /** Maximum retained element count. */
  readonly maxElements: number
  /** Maximum compact serialized UTF-8 bytes. */
  readonly maxSerializedBytes: number
}

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '',
  parseAttributeValue: false,
  trimValues: false,
})

/**
 * Parse and prune one complete UIAutomator XML document.
 * @param xml - XML beginning at its declaration or hierarchy root.
 * @param limits - Display geometry and output caps.
 * @returns Compact hierarchy with deterministic ids and signature.
 */
export function parseUiHierarchy(xml: string, limits: HierarchyLimits): PhoneHierarchy {
  let document: unknown
  try {
    document = parser.parse(xml)
  } catch (error: unknown) {
    throw new PhoneError('PHONE_HIERARCHY_INVALID', 'UIAutomator returned malformed XML', error)
  }
  const root = asRecord(document)?.hierarchy
  const roots = childNodes(asRecord(root)?.node)
  if (roots.length === 0 && !xml.includes('<hierarchy')) {
    throw new PhoneError('PHONE_HIERARCHY_INVALID', 'UIAutomator output did not contain a hierarchy')
  }
  const retained: PhoneUIElement[] = []
  let bytes = 0
  let truncated = false
  const visit = (node: unknown): void => {
    const record = asRecord(node)
    if (record === undefined) return
    const element = toElement(record, retained.length + 1, limits.width, limits.height)
    if (element !== undefined) {
      const lineBytes = Buffer.byteLength(serializePhoneElement(element), 'utf8') + 1
      if (retained.length >= limits.maxElements || bytes + lineBytes > limits.maxSerializedBytes) {
        truncated = true
        return
      }
      retained.push(element)
      bytes += lineBytes
    }
    for (const child of childNodes(record.node)) visit(child)
  }
  for (const node of roots) visit(node)
  const semantic = retained.map(({ id: _id, ...element }) => element)
  return {
    elements: retained,
    signature: createHash('sha256').update(JSON.stringify(semantic)).digest('hex'),
    truncated,
  }
}

/**
 * Extract the XML document from noisy UIAutomator stdout.
 * @param output - Complete bounded stdout or file content.
 * @returns XML suffix beginning at the declaration or hierarchy root.
 */
export function extractHierarchyXml(output: string): string {
  const declaration = output.indexOf('<?xml')
  const hierarchy = output.indexOf('<hierarchy')
  const start = declaration >= 0 ? declaration : hierarchy
  if (start < 0) throw new PhoneError('PHONE_HIERARCHY_INVALID', 'UIAutomator output did not contain XML')
  const end = output.lastIndexOf('</hierarchy>')
  if (end < start) throw new PhoneError('PHONE_HIERARCHY_INVALID', 'UIAutomator hierarchy was incomplete')
  return output.slice(start, end + '</hierarchy>'.length)
}

/**
 * Serialize retained elements into token-efficient model text.
 * @param hierarchy - Pruned hierarchy.
 * @returns One compact element per line.
 */
export function serializeHierarchy(hierarchy: PhoneHierarchy): string {
  const lines = hierarchy.elements.map(serializePhoneElement)
  if (hierarchy.truncated) lines.push('[hierarchy truncated]')
  return lines.length === 0 ? '[no meaningful UI elements]' : lines.join('\n')
}

/**
 * Compute one element's safe display center.
 * @param bounds - Visible bounds.
 * @returns Integer center coordinate.
 */
export function boundsCenter(bounds: PhoneBounds): readonly [x: number, y: number] {
  return [Math.floor((bounds[0] + bounds[2]) / 2), Math.floor((bounds[1] + bounds[3]) / 2)]
}

/** Convert one raw node into a retained compact element. */
function toElement(node: Record<string, unknown>, id: number, width: number, height: number): PhoneUIElement | undefined {
  if (node['visible-to-user'] === 'false') return undefined
  const bounds = parseBounds(stringValue(node.bounds), width, height)
  if (bounds === undefined) return undefined
  const className = stringValue(node.class) ?? ''
  const text = nonEmpty(stringValue(node.text))
  const resourceId = nonEmpty(stringValue(node['resource-id']))
  const contentDescription = nonEmpty(stringValue(node['content-desc']))
  const clickable = booleanValue(node.clickable)
  const longClickable = booleanValue(node['long-clickable'])
  const scrollable = booleanValue(node.scrollable)
  const editable = className.endsWith('EditText') || booleanValue(node.editable)
  const focusable = booleanValue(node.focusable)
  const focused = booleanValue(node.focused)
  const enabled = node.enabled !== 'false'
  const selected = booleanValue(node.selected)
  const password = booleanValue(node.password)
  const checkable = booleanValue(node.checkable) || /(?:Switch|CheckBox|RadioButton)$/u.test(className)
  const meaningful = clickable || longClickable || scrollable || editable || focusable || focused
    || selected || checkable || text !== undefined || resourceId !== undefined || contentDescription !== undefined
  if (!meaningful) return undefined
  const semantic = [className, text, resourceId, contentDescription, bounds.join(','), clickable, scrollable, editable].join('|')
  return {
    id,
    className,
    ...(text === undefined ? {} : { text }),
    ...(resourceId === undefined ? {} : { resourceId }),
    ...(contentDescription === undefined ? {} : { contentDescription }),
    clickable,
    longClickable,
    scrollable,
    editable,
    focusable,
    focused,
    enabled,
    selected,
    ...(checkable ? { checked: booleanValue(node.checked) } : {}),
    password,
    bounds,
    fingerprint: createHash('sha256').update(semantic).digest('hex').slice(0, 16),
  }
}

/** Parse and clip Android's `[left,top][right,bottom]` syntax. */
function parseBounds(value: string | undefined, width: number, height: number): PhoneBounds | undefined {
  const match = /^\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]$/u.exec(value ?? '')
  if (match === null) return undefined
  const values = match.slice(1).map(Number)
  const [rawLeft, rawTop, rawRight, rawBottom] = values
  if (rawLeft === undefined || rawTop === undefined || rawRight === undefined || rawBottom === undefined) return undefined
  const left = Math.max(0, Math.min(width, rawLeft))
  const top = Math.max(0, Math.min(height, rawTop))
  const right = Math.max(0, Math.min(width, rawRight))
  const bottom = Math.max(0, Math.min(height, rawBottom))
  return right > left && bottom > top ? [left, top, right, bottom] : undefined
}

/** Normalize a potentially plural parser field to a node list. */
function childNodes(value: unknown): readonly unknown[] {
  if (Array.isArray(value)) return value
  return value === undefined ? [] : [value]
}

/** Narrow parsed XML objects. */
function asRecord(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
    ? value as Record<string, unknown>
    : undefined
}

/** Return XML attributes only when the parser produced strings. */
function stringValue(value: unknown): string | undefined {
  return typeof value === 'string' ? value : undefined
}

/** Trim an optional string and omit empties. */
function nonEmpty(value: string | undefined): string | undefined {
  const trimmed = value?.trim()
  return trimmed === undefined || trimmed.length === 0 ? undefined : trimmed
}

/** Parse UIAutomator boolean attributes. */
function booleanValue(value: unknown): boolean {
  return value === 'true' || value === true
}
