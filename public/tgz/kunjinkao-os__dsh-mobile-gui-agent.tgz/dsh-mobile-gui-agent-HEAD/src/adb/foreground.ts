/** Android dumpsys foreground, keyboard, and lock-state parsing. */

/** Foreground application identity parsed from window or activity diagnostics. */
export interface ForegroundState {
  /** Foreground package. */
  readonly packageName?: string
  /** Foreground activity component. */
  readonly activity?: string
}

/** Minimal hierarchy fact needed for a conservative package fallback. */
export interface ResourceIdentifiedElement {
  /** Android resource id such as `com.example:id/search`. */
  readonly resourceId?: string
}

/**
 * Parse the first focused package/activity component from Android diagnostics.
 * @param output - `dumpsys window` or activity output.
 * @returns Foreground identity, possibly empty when Android omits it.
 */
export function parseForegroundState(output: string): ForegroundState {
  const match = /(?:mCurrentFocus|mFocusedApp|mFocusedWindow|mResumedActivity|topResumedActivity)[^\n]*?\s([A-Za-z0-9._]+)\/([A-Za-z0-9.$_]+)/u.exec(output)
    ?? /ActivityRecord\{[^\n]*?\s([A-Za-z0-9._]+)\/([A-Za-z0-9.$_]+)/u.exec(output)
  if (match === null) return {}
  const packageName = match[1]
  const activityName = match[2]
  if (packageName === undefined || activityName === undefined) return {}
  return { packageName, activity: `${packageName}/${activityName}` }
}

/**
 * Infer one unambiguous foreground package from hierarchy resource ids.
 * @param elements - Retained UI elements from the same coherent capture.
 * @returns The uniquely most frequent application package, or undefined on no evidence/a tie.
 */
export function inferForegroundPackage(elements: readonly ResourceIdentifiedElement[]): string | undefined {
  const counts = new Map<string, number>()
  for (const element of elements) {
    const packageName = /^([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+):id\//u.exec(element.resourceId ?? '')?.[1]
    if (packageName === undefined) continue
    counts.set(packageName, (counts.get(packageName) ?? 0) + 1)
  }
  const ranked = [...counts].sort((left, right) => right[1] - left[1] || left[0].localeCompare(right[0]))
  const first = ranked[0]
  if (first === undefined || first[1] === ranked[1]?.[1]) return undefined
  return first[0]
}

/**
 * Parse software-keyboard visibility from input-method diagnostics.
 * @param output - `dumpsys input_method` output.
 * @returns Visibility when a supported fact is present.
 */
export function parseKeyboardVisible(output: string): boolean | undefined {
  if (/mInputShown=true|mIsInputViewShown=true/u.test(output)) return true
  if (/mInputShown=false|mIsInputViewShown=false/u.test(output)) return false
  const visibility = /mImeWindowVis=0x([0-9a-f]+)/iu.exec(output)?.[1]
  if (visibility !== undefined) return (Number.parseInt(visibility, 16) & 0x2) !== 0
  return undefined
}

/**
 * Parse lock-screen state from window policy diagnostics.
 * @param output - `dumpsys window policy` output.
 * @returns Lock state when a supported fact is present.
 */
export function parseLocked(output: string): boolean | undefined {
  if (/isStatusBarKeyguard=true|mShowingLockscreen=true|showing=true/u.test(output)) return true
  if (/isStatusBarKeyguard=false|mShowingLockscreen=false/u.test(output)) return false
  return undefined
}
