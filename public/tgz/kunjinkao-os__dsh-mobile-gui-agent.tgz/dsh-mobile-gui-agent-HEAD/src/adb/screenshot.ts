/** PNG validation and comparison signatures. */

import { createHash } from 'node:crypto'
import sharp from 'sharp'
import { PhoneError } from '../core/index.ts'
import type { PhoneScreenshot } from '../core/index.ts'

const THUMBNAIL_SIZE = 32

/**
 * Validate PNG bytes and compute exact and low-resolution signatures.
 * @param data - Bounded `screencap -p` stdout.
 * @param timestamp - Capture time.
 * @returns Intrinsic screenshot metadata and comparison signature.
 */
export async function decodeScreenshot(data: Uint8Array, timestamp: number): Promise<PhoneScreenshot> {
  try {
    const image = sharp(data, { failOn: 'error' })
    const metadata = await image.metadata()
    if (metadata.format !== 'png') {
      throw new Error('screenshot is not a PNG')
    }
    const thumbnail = await image
      .resize(THUMBNAIL_SIZE, THUMBNAIL_SIZE, { fit: 'fill' })
      .grayscale()
      .raw()
      .toBuffer()
    return {
      data,
      width: metadata.width,
      height: metadata.height,
      timestamp,
      digest: createHash('sha256').update(data).digest('hex'),
      comparisonSignature: thumbnail.toString('base64'),
    }
  } catch (error: unknown) {
    throw new PhoneError('PHONE_SCREENSHOT_INVALID', 'ADB screencap did not return a valid PNG', error)
  }
}

/**
 * Compute normalized mean absolute pixel difference between comparison signatures.
 * @param before - Base64 grayscale thumbnail.
 * @param after - Base64 grayscale thumbnail.
 * @returns Difference from zero to one, or one for incompatible signatures.
 */
export function screenshotDifference(before: string, after: string): number {
  const left = Buffer.from(before, 'base64')
  const right = Buffer.from(after, 'base64')
  if (left.length === 0 || left.length !== right.length) return 1
  let total = 0
  for (let index = 0; index < left.length; index++) {
    total += Math.abs((left[index] ?? 0) - (right[index] ?? 0))
  }
  return total / (left.length * 255)
}
