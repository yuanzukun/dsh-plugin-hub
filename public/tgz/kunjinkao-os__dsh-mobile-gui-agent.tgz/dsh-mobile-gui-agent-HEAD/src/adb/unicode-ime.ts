/** Supported opt-in Android input-method helpers for Unicode text entry. */

/** ADB Keyboard component and broadcast protocol details. */
export const ADB_KEYBOARD = {
  component: 'com.android.adbkeyboard/.AdbIME',
  packageName: 'com.android.adbkeyboard',
  inputAction: 'ADB_INPUT_B64',
  clearAction: 'ADB_CLEAR_TEXT',
} as const

/** Read-only readiness result for the supported helper IME. */
export type AdbKeyboardAvailability = 'ready' | 'not-installed' | 'not-enabled' | 'not-selected'

/**
 * Classify ADB Keyboard readiness from Android package and secure-setting output.
 * @param installed - Output from `ime list -s`.
 * @param enabled - Value of `enabled_input_methods`.
 * @param selected - Value of `default_input_method`.
 * @returns The first missing prerequisite, or `ready`.
 */
export function adbKeyboardAvailability(
  installed: string,
  enabled: string,
  selected: string,
): AdbKeyboardAvailability {
  if (!containsComponent(installed, ADB_KEYBOARD.component)) return 'not-installed'
  if (!containsComponent(enabled, ADB_KEYBOARD.component)) return 'not-enabled'
  return containsComponent(selected, ADB_KEYBOARD.component) ? 'ready' : 'not-selected'
}

/** Extract the first exact Android input-method component from secure settings output. */
export function selectedInputMethod(output: string): string | undefined {
  return output.match(/[A-Za-z0-9._]+\/(?:\.[A-Za-z0-9.$_]+|[A-Za-z0-9.$_]+)/u)?.[0]
}

/** Whether an Android component spelling identifies the supported helper. */
export function isAdbKeyboardComponent(component: string): boolean {
  return normalizeComponent(component) === normalizeComponent(ADB_KEYBOARD.component)
}

/** Normalize short Android component syntax before exact comparison. */
function containsComponent(output: string, expected: string): boolean {
  const normalizedExpected = normalizeComponent(expected)
  const components = output.match(/[A-Za-z0-9._]+\/(?:\.[A-Za-z0-9.$_]+|[A-Za-z0-9.$_]+)/gu) ?? []
  return components.some(component => normalizeComponent(component) === normalizedExpected)
}

/** Expand `package/.Class` to the full component spelling. */
function normalizeComponent(component: string): string {
  const slash = component.indexOf('/')
  const packageName = component.slice(0, slash)
  const className = component.slice(slash + 1)
  return `${packageName}/${className.startsWith('.') ? packageName + className : className}`
}
