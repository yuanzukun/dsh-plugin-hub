/** Managed direct-argv ADB process client. */

import type { Readable } from 'node:stream'
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess'
import { PhoneError, phoneAbortError } from '../core/index.ts'
import type { ResolvedConfig } from './config.ts'

/** Successful bounded ADB text execution. */
export interface AdbTextResult {
  /** Process stdout. */
  readonly stdout: string
  /** Process stderr. */
  readonly stderr: string
}

/** Direct ADB invocation wrapper over the Harness subprocess capability. */
export class AdbClient {
  private executable: Promise<string> | undefined

  /**
   * Create an ADB client.
   * @param subprocess - Execution-world subprocess provider.
   * @param config - Resolved ADB limits and timeouts.
   */
  constructor(
    private readonly subprocess: SubprocessRuntime,
    private readonly config: ResolvedConfig,
  ) {}

  /**
   * Execute ADB and collect bounded UTF-8 streams.
   * @param argv - Arguments after the ADB executable.
   * @param stdoutMaxBytes - Maximum stdout bytes.
   * @param signal - Cooperative cancellation.
   * @returns Collected stdout and stderr.
   */
  async text(argv: readonly string[], stdoutMaxBytes: number, signal?: AbortSignal): Promise<AdbTextResult> {
    const executable = await this.resolve(signal)
    const operationSignal = combinedSignal(signal, this.config.commandTimeoutMs)
    const handle = this.subprocess.spawn({
      argv: [executable, ...argv],
      cwd: process.cwd(),
      stdio: {
        stdin: 'ignore',
        stdout: { maxBytes: stdoutMaxBytes },
        stderr: { maxBytes: this.config.diagnosticMaxBytes },
      },
      graceMs: this.config.processGraceMs,
      signal: operationSignal,
    })
    let outcome
    try {
      outcome = await handle.done
    } catch (error: unknown) {
      throw new PhoneError('PHONE_ADB_FAILED', `failed to start adb ${argv[0] ?? ''}`.trim(), error)
    }
    const stdoutRead = handle.collected.stdout?.readFrom(0)
    const stderrRead = handle.collected.stderr?.readFrom(0)
    if (stdoutRead === undefined || stderrRead === undefined) {
      throw new PhoneError('PHONE_ADB_FAILED', 'subprocess provider did not retain requested ADB streams')
    }
    if (operationSignal.aborted) {
      throw phoneAbortError(operationSignal, `adb command timed out or was cancelled: ${argv.join(' ')}`)
    }
    if (stdoutRead.lossy) throw new PhoneError('PHONE_ADB_FAILED', `adb stdout exceeded ${stdoutMaxBytes} bytes`)
    const stderr = stderrRead.text.trim()
    if (outcome.exitCode !== 0) {
      throw new PhoneError('PHONE_ADB_FAILED', stderr || `adb exited with code ${String(outcome.exitCode)}`)
    }
    return { stdout: stdoutRead.text, stderr: stderrRead.text }
  }

  /**
   * Execute ADB with raw bounded stdout for PNG or other binary data.
   * @param argv - Arguments after the ADB executable.
   * @param maxBytes - Maximum stdout bytes.
   * @param signal - Cooperative cancellation.
   * @returns Exact stdout bytes.
   */
  async binary(argv: readonly string[], maxBytes: number, signal?: AbortSignal): Promise<Uint8Array> {
    const executable = await this.resolve(signal)
    const operationSignal = combinedSignal(signal, this.config.commandTimeoutMs)
    const handle = this.subprocess.spawn({
      argv: [executable, ...argv],
      cwd: process.cwd(),
      stdio: {
        stdin: 'ignore',
        stdout: 'pipe',
        stderr: { maxBytes: this.config.diagnosticMaxBytes },
      },
      graceMs: this.config.processGraceMs,
      signal: operationSignal,
    })
    const stdout = handle.stdout
    if (stdout === undefined) throw new PhoneError('PHONE_ADB_FAILED', 'subprocess provider did not expose requested ADB stdout')
    const read = readBounded(stdout, maxBytes, () => { handle.terminate() })
    let outcome
    try {
      ;[outcome] = await Promise.all([handle.done, read.done])
    } catch (error: unknown) {
      handle.terminate()
      await handle.waitForExit().catch(() => false)
      if (error instanceof PhoneError) throw error
      throw new PhoneError('PHONE_ADB_FAILED', `failed to run adb ${argv[0] ?? ''}`.trim(), error)
    }
    const stderrRead = handle.collected.stderr?.readFrom(0)
    if (operationSignal.aborted) {
      throw phoneAbortError(operationSignal, `adb command timed out or was cancelled: ${argv.join(' ')}`)
    }
    if (outcome.exitCode !== 0) {
      throw new PhoneError('PHONE_ADB_FAILED', stderrRead?.text.trim() || `adb exited with code ${String(outcome.exitCode)}`)
    }
    return read.bytes()
  }

  private resolve(signal?: AbortSignal): Promise<string> {
    this.executable ??= this.subprocess.resolveExecutable(this.config.adbPath, undefined, signal)
      .catch((error: unknown) => {
        this.executable = undefined
        throw new PhoneError('PHONE_ADB_NOT_FOUND', `ADB executable ${JSON.stringify(this.config.adbPath)} is unavailable`, error)
      })
    return this.executable
  }
}

/** Combine caller cancellation with one bounded command deadline. */
function combinedSignal(signal: AbortSignal | undefined, timeoutMs: number): AbortSignal {
  const timeout = AbortSignal.timeout(timeoutMs)
  return signal === undefined ? timeout : AbortSignal.any([signal, timeout])
}

/** Consume a raw stream without permitting unbounded buffering. */
function readBounded(stream: Readable, maxBytes: number, overflow: () => void): {
  readonly done: Promise<void>
  readonly bytes: () => Uint8Array
} {
  const chunks: Buffer[] = []
  let size = 0
  let settled = false
  const done = new Promise<void>((resolve, reject) => {
    stream.on('data', (chunk: Buffer | string) => {
      if (settled) return
      const bytes = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)
      size += bytes.byteLength
      if (size > maxBytes) {
        settled = true
        overflow()
        reject(new PhoneError('PHONE_ADB_FAILED', `ADB binary stdout exceeded ${maxBytes} bytes`))
        return
      }
      chunks.push(bytes)
    })
    stream.once('error', (error: unknown) => {
      if (settled) return
      settled = true
      reject(error instanceof Error ? error : new Error(String(error)))
    })
    stream.once('end', () => {
      if (settled) return
      settled = true
      resolve()
    })
  })
  return { done, bytes: () => Buffer.concat(chunks, size) }
}
