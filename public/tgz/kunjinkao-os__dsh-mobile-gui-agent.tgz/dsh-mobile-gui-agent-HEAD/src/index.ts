/** Installable DeepSeek Harness plugin composing Android device, Agent, and GUI Remote roles. */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import * as Adb from './adb/index.ts'
import * as Agent from './agent/index.ts'
import { PhoneAgentRemote } from './remote/index.ts'

export * from './core/index.ts'
export * from './remote/index.ts'
export * as Adb from './adb/index.ts'
export * as PhoneAgent from './agent/index.ts'
export * as PhoneTools from './tools/index.ts'
export { AdbClient, AdbPhoneDevice, AdbPhoneDeviceRegistry } from './adb/index.ts'
export { PhoneAgentService } from './agent/index.ts'
export type { AdbPhoneConfig } from './adb/index.ts'
export type { PhoneAgentConfig } from './agent/index.ts'

/** Cordis plugin name used by loader diagnostics. */
export const name = 'mobile-gui-agent'

/** Host services required by the composed Phone plugin. */
export const inject = ['subprocess', 'agents', 'attachments', 'llm', 'systemPrompt', 'tools']

/** Standalone bundle configuration grouped by provider and run policy. */
export interface Config {
  /** ADB provider and observation limits. */
  adb: Adb.Config
  /** Iterative Agent run, verification, approval, and trace limits. */
  agent: Agent.Config
}

/** Loader-visible standalone plugin configuration. */
export const Config: z<Config> = z.object({
  adb: Adb.Config,
  agent: Agent.Config,
})

/**
 * Mount all Phone capability roles beneath one Loader-owned plugin fiber.
 * @param ctx - Harness Host context with the standard base and Web services.
 * @param config - Validated ADB and Agent configuration.
 */
export async function apply(ctx: Context, config: Config): Promise<void> {
  await ctx.plugin(Adb.AdbPhoneDeviceRegistry, config.adb)
  await ctx.plugin(Agent.PhoneAgentService, config.agent)
  await ctx.plugin(PhoneAgentRemote)
}

export default apply
