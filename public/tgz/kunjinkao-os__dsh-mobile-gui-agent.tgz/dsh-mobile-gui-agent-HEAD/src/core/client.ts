/** Client-safe Phone Remote vocabulary. */

export type * from './brand.ts'
export type * from './types.ts'
