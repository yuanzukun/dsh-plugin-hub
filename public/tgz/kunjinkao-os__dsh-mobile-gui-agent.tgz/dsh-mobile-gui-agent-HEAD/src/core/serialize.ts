/** Serialize one compact UI element for hierarchy and model output. */

import type { PhoneUIElement } from './types.ts'

export function serializePhoneElement(element: PhoneUIElement): string {
  const shortClass = element.className.slice(element.className.lastIndexOf('.') + 1) || 'Node'
  const label = element.text ?? element.contentDescription ?? element.resourceId
  const flags = [
    element.clickable ? 'clickable' : undefined,
    element.longClickable ? 'long-clickable' : undefined,
    element.scrollable ? 'scrollable' : undefined,
    element.editable ? 'editable' : undefined,
    element.focused ? 'focused' : undefined,
    element.enabled ? undefined : 'disabled',
    element.checked === undefined ? undefined : `checked=${String(element.checked)}`,
    element.selected ? 'selected' : undefined,
  ].filter(value => value !== undefined)
  return `[${element.id}] ${shortClass}${label === undefined ? '' : ` ${JSON.stringify(label)}`}`
    + `${flags.length === 0 ? '' : ` ${flags.join(' ')}`} bounds=(${element.bounds.join(',')})`
}
