/** Android Phone Agent session view. */

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client'
import { Button } from '@deepseek-ai/dsh-client-ui-primitives'
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots'
import type { PhoneDeviceId, PhoneDeviceInfo } from '../core/client.ts'
import type { PhoneRunView } from '../core/client.ts'
import type { PhoneScreenshotResponse } from '../remote/types.ts'
import type { PhoneViewActions } from './types.ts'
import { describePhoneAction, phoneActionOverlay, preferPhoneRunView } from './view-model.ts'
import {
  buildSemanticAgentSteps,
  semanticRunTitle,
  type SemanticAgentStep,
} from './semantic-steps.ts'
import css from './PhoneAgentView.module.css'

const SCREEN_REFRESH_MS = 1_200
const RUN_REFRESH_MS = 800

/** Full props of the Mobile conversation view. */
export type PhoneAgentPanelProps = InjectFace<PhoneViewActions> & PropsLocale<'phone-agent'>

/** Full props supplied by the registered Mobile conversation-view slot. */
export type PhoneAgentViewProps = ConvViewProps & PhoneAgentPanelProps

function deviceLabel(device: PhoneDeviceInfo): string {
  return device.model === undefined ? device.id : `${device.model} · ${device.id}`
}

function stepIcon(step: SemanticAgentStep): string {
  if (step.type === 'strategy_change') return '↳'
  if (step.status === 'pending') return '●'
  if (step.status === 'success') return '✓'
  if (step.status === 'error') return '×'
  if (step.status === 'warning') return '⚠'
  return '○'
}

function durationText(startedAt: number, completedAt = Date.now()): string {
  const duration = Math.max(0, completedAt - startedAt)
  return duration < 1_000 ? `${duration} ms` : `${(duration / 1_000).toFixed(1)} s`
}

function TechnicalTrace({ step, t, expanded = false }: {
  readonly step: SemanticAgentStep
  readonly t: PhoneAgentPanelProps['t']
  readonly expanded?: boolean
}) {
  const raw = step.rawSteps
  if (raw.length === 0 && step.rawPendingStep === undefined) return null
  return (
    <details className={css.technicalDetails} open={expanded}>
      <summary>{t('steps.technical')}</summary>
      {[...raw, ...(step.rawPendingStep === undefined ? [] : [{
        step: step.rawPendingStep.step,
        action: step.rawPendingStep.action,
        result: undefined,
        timestamp: step.rawPendingStep.startedAt,
      }])].map((entry, index) => {
        const result = 'result' in entry ? entry.result : undefined
        const context = 'context' in entry ? entry.context : undefined
        const action = entry.action
        const observationId = action.type === 'tap_element'
          ? action.observationId
          : context?.before.observationId
        const elementId = action.type === 'tap_element' ? action.elementId : context?.target?.elementId
        return (
          <dl key={`${entry.step}-${index}`} className={css.technicalGrid}>
            <dt>{t('steps.tool')}</dt><dd>{action.type}</dd>
            {elementId !== undefined && <><dt>{t('steps.elementId')}</dt><dd>{elementId}</dd></>}
            {observationId !== undefined && <><dt>{t('steps.observationId')}</dt><dd>{String(observationId)}</dd></>}
            {context !== undefined && <>
              <dt>{t('steps.before')}</dt>
              <dd><code>{JSON.stringify(context.before)}</code></dd>
            </>}
            {result?.observation !== undefined && <>
              <dt>{t('steps.after')}</dt>
              <dd><code>{JSON.stringify({
                observationId: result.observation.id,
                foregroundPackage: result.observation.foregroundPackage,
                activity: result.observation.activity,
                uiSignature: result.observation.uiSignature,
                screenshotSignature: result.observation.screenshotSignature,
              })}</code></dd>
            </>}
            {result !== undefined && <>
              <dt>{t('steps.executed')}</dt><dd>{result.executed ? t('common.yes') : t('common.no')}</dd>
              <dt>{t('steps.duration')}</dt>
              <dd>{durationText('startedAt' in entry && entry.startedAt !== undefined ? entry.startedAt : entry.timestamp, 'completedAt' in entry ? entry.completedAt ?? entry.timestamp : entry.timestamp)}</dd>
              <dt>{t('steps.stuck')}</dt><dd><code>{JSON.stringify(result.stuck)}</code></dd>
              {result.stability !== undefined && <><dt>{t('steps.stability')}</dt><dd><code>{JSON.stringify(result.stability)}</code></dd></>}
              {result.error !== undefined && <><dt>{t('steps.result')}</dt><dd><code>{JSON.stringify(result.error)}</code></dd></>}
            </>}
            <dt>{t('steps.rawAction')}</dt><dd><code>{JSON.stringify(action)}</code></dd>
            {result !== undefined && <>
              <dt>{t('steps.rawVerification')}</dt><dd><code>{JSON.stringify(result.verification)}</code></dd>
            </>}
          </dl>
        )
      })}
    </details>
  )
}

function SemanticStepItem({ step, t }: { readonly step: SemanticAgentStep; readonly t: PhoneAgentPanelProps['t'] }) {
  const facts = step.verification
  return (
    <li className={`${css.semanticStep} ${css[`step_${step.status}`] ?? ''}`} data-step-type={step.type}>
      <span className={css.timelineIcon} aria-hidden="true">{stepIcon(step)}</span>
      <details className={css.semanticDetails}>
        <summary>
          <span className={css.semanticTitle}>{step.title}</span>
          <span className={css.semanticDescription}>{step.description}</span>
        </summary>
        <dl className={css.semanticGrid}>
          {step.goal !== undefined && <><dt>{t('steps.goal')}</dt><dd>{step.goal}</dd></>}
          {step.reason !== undefined && <><dt>{t('steps.reason')}</dt><dd>{step.reason}</dd></>}
          {step.actionSummary !== undefined && <><dt>{t('steps.operation')}</dt><dd>{step.actionSummary}</dd></>}
          {step.resultSummary !== undefined && <><dt>{t('steps.result')}</dt><dd>{step.resultSummary}</dd></>}
          {step.judgment !== undefined && <><dt>{t('steps.judgment')}</dt><dd>{step.judgment}</dd></>}
          {step.nextStep !== undefined && <><dt>{t('steps.next')}</dt><dd>{step.nextStep}</dd></>}
          {facts !== undefined && <>
            <dt>{t('steps.verification')}</dt>
            <dd>
              <span>{facts.summary}</span>
              <ul className={css.verificationList}>
                {facts.uiHierarchyChanged === true && <li>✓ {t('steps.uiHierarchyChanged')}</li>}
                {facts.screenshotChanged === true && <li>✓ {t('steps.screenshotChanged')}</li>}
                {facts.foregroundPackageChanged === true && <li>✓ {t('steps.foregroundChanged')}</li>}
                {facts.activityChanged === true && <li>✓ {t('steps.activityChanged')}</li>}
              </ul>
            </dd>
          </>}
        </dl>
        <TechnicalTrace step={step} t={t} />
      </details>
    </li>
  )
}

/**
 * Render device selection, screenshot polling, lifecycle controls, and verified steps.
 * @param props - Session slot kit, bound Remote operations, and locale.
 * @returns Phone Agent tab content.
 */
export function PhoneAgentView({
  restoreState, persistState, getView, listDevices, connect, screenshot, start, pause, resume, stop, t,
}: PhoneAgentPanelProps) {
  const restored = useMemo(restoreState, [restoreState])
  const [run, setRun] = useState<PhoneRunView | undefined>(restored?.run)
  const [devices, setDevices] = useState<readonly PhoneDeviceInfo[]>([])
  const [selectedId, setSelectedId] = useState<PhoneDeviceId | undefined>(restored?.selectedId ?? restored?.run?.deviceId)
  const [address, setAddress] = useState('')
  const [task, setTask] = useState(restored?.task ?? restored?.run?.task ?? '')
  const [capture, setCapture] = useState<PhoneScreenshotResponse | undefined>()
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | undefined>()
  const [pollError, setPollError] = useState<string | undefined>()
  const traceRef = useRef<HTMLDivElement>(null)

  const settle = useCallback(<T,>(result: Awaited<ReturnType<() => Promise<import('@deepseek-ai/dsh-typert-protocol').RemoteResult<T>>>>): T | undefined => {
    if (!result.ok) {
      setError(`${result.error.code}: ${result.error.message}`)
      return undefined
    }
    setError(undefined)
    return result.value
  }, [])

  const refreshDevices = useCallback(async (): Promise<void> => {
    const value = settle(await listDevices())
    if (value === undefined) return
    setDevices(value)
    setSelectedId((current) => {
      if (run?.deviceId !== undefined) return run.deviceId
      if (current !== undefined && value.some(device => device.id === current && device.status === 'device')) return current
      return value.find(device => device.status === 'device')?.id
    })
  }, [listDevices, run?.deviceId, settle])

  const refreshScreenshot = useCallback(async (): Promise<void> => {
    const deviceId = run?.deviceId ?? selectedId
    if (deviceId === undefined) return
    const value = settle(await screenshot(deviceId))
    if (value !== undefined) setCapture(value)
  }, [run?.deviceId, screenshot, selectedId, settle])

  useEffect(() => { void refreshDevices() }, [refreshDevices])
  useEffect(() => {
    persistState({
      ...(run === undefined ? {} : { run }),
      ...(selectedId === undefined ? {} : { selectedId }),
      task,
    })
  }, [persistState, run, selectedId, task])
  useEffect(() => {
    let active = true
    let timer: number | undefined
    const poll = async (): Promise<void> => {
      try {
        const result = await getView()
        if (!active) return
        if (result.ok) {
          if (result.value !== undefined) {
            const value = result.value
            setRun(current => preferPhoneRunView(current, value))
            setTask(current => current === '' ? value.task : current)
          }
          setPollError(undefined)
        } else {
          setPollError(`${result.error.code}: ${result.error.message}`)
        }
      } catch (reason: unknown) {
        if (active) setPollError(reason instanceof Error ? reason.message : String(reason))
      } finally {
        if (active) timer = window.setTimeout(() => { void poll() }, RUN_REFRESH_MS)
      }
    }
    void poll()
    return () => {
      active = false
      if (timer !== undefined) window.clearTimeout(timer)
    }
  }, [getView])
  useEffect(() => {
    if (run?.deviceId !== undefined) setSelectedId(run.deviceId)
  }, [run?.deviceId])
  useEffect(() => {
    let active = true
    const poll = async (): Promise<void> => {
      const deviceId = run?.deviceId ?? selectedId
      if (deviceId === undefined) return
      const result = await screenshot(deviceId)
      if (!active) return
      if (result.ok) setCapture(result.value)
    }
    void poll()
    const timer = window.setInterval(() => { void poll() }, SCREEN_REFRESH_MS)
    return () => {
      active = false
      window.clearInterval(timer)
    }
  }, [run?.deviceId, screenshot, selectedId])

  const execute = async (operation: () => Promise<import('@deepseek-ai/dsh-typert-protocol').RemoteResult<PhoneRunView>>): Promise<void> => {
    setBusy(true)
    try {
      const value = settle(await operation())
      if (value !== undefined) setRun(current => preferPhoneRunView(current, value))
    } finally { setBusy(false) }
  }

  const begin = async (): Promise<void> => {
    if (selectedId === undefined) {
      setError(t('error.deviceRequired'))
      return
    }
    if (task.trim() === '') {
      setError(t('error.taskRequired'))
      return
    }
    await execute(() => start(selectedId, task.trim()))
  }

  const connectWireless = async (): Promise<void> => {
    if (address.trim() === '') return
    setBusy(true)
    try {
      const device = settle(await connect(address.trim()))
      if (device !== undefined) {
        setSelectedId(device.id)
        await refreshDevices()
      }
    } finally { setBusy(false) }
  }

  const selected = devices.find(device => device.id === selectedId)
  const running = run !== undefined && ['starting', 'running', 'pausing', 'stopping'].includes(run.status)
  const canStart = selected?.status === 'device' && !running && run?.status !== 'paused'
  const semanticSteps = useMemo(
    () => run === undefined ? [] : buildSemanticAgentSteps(run, t),
    [run, t],
  )
  const traceTitle = semanticRunTitle(run, semanticSteps.length, t)
  useEffect(() => {
    const trace = traceRef.current
    if (trace !== null) trace.scrollTop = trace.scrollHeight
  }, [semanticSteps.length, run?.pendingStep?.phase])
  const lastStep = run?.steps.at(-1)
  const overlay = useMemo(() => phoneActionOverlay(
    lastStep,
    run?.observation?.elements ?? [],
    capture?.width ?? run?.observation?.width ?? 0,
    capture?.height ?? run?.observation?.height ?? 0,
  ), [capture?.height, capture?.width, lastStep, run?.observation])

  const statusText = (status: PhoneDeviceInfo['status']): string => t(`status.${status}`)
  const screenContent = capture === undefined
    ? <div className={css.emptyScreen}>{t('screen.empty')}</div>
    : (
      <div className={css.screenCanvas}>
        <img className={css.screenImage} src={`data:image/png;base64,${capture.data}`} alt="Android screen" />
        {overlay !== undefined && <span className={css.actionOverlay} style={overlay} />}
        {lastStep !== undefined && <span className={css.actionBadge}>{describePhoneAction(lastStep.action)}</span>}
      </div>
    )
  const stepsContent = semanticSteps.length === 0
    ? <div className={css.emptySteps}>{t('steps.empty')}</div>
    : <ol className={css.steps}>{semanticSteps.map(step => <SemanticStepItem key={step.id} step={step} t={t} />)}</ol>

  return (
    <div className={css.root}>
      <section className={css.screenColumn}>
        <div className={css.deviceBar}>
          <label className={css.label} htmlFor="phone-device">{t('device.label')}</label>
          <select
            id="phone-device"
            className={css.select}
            value={selectedId ?? ''}
            disabled={running || busy}
            onChange={(event) => { setSelectedId(event.target.value as PhoneDeviceId); setCapture(undefined) }}
          >
            {devices.length === 0 && <option value="">{t('device.none')}</option>}
            {devices.map(device => <option key={device.id} value={device.id}>{deviceLabel(device)} · {statusText(device.status)}</option>)}
          </select>
          <Button size="sm" variant="toolbar" disabled={busy} onClick={() => { void refreshDevices() }}>{t('device.refresh')}</Button>
        </div>
        <div className={css.connectRow}>
          <input
            className={css.input}
            value={address}
            disabled={busy}
            placeholder={t('device.address')}
            onChange={(event) => { setAddress(event.target.value) }}
          />
          <Button size="sm" variant="outline" disabled={busy || address.trim() === ''} onClick={() => { void connectWireless() }}>{t('device.connect')}</Button>
        </div>
        <div className={css.screenFrame}>
          {screenContent}
        </div>
        <Button size="sm" variant="toolbar" disabled={selectedId === undefined || busy} onClick={() => { void refreshScreenshot() }}>{t('screen.refresh')}</Button>
      </section>

      <section className={css.controlColumn}>
        <div className={css.taskPanel}>
          <label className={css.label} htmlFor="phone-task">{t('task.label')}</label>
          <textarea
            id="phone-task"
            className={css.taskInput}
            value={task}
            disabled={running || busy}
            placeholder={t('task.placeholder')}
            onChange={(event) => { setTask(event.target.value) }}
          />
          <div className={css.actions}>
            <Button variant="primary" disabled={!canStart || busy} onClick={() => { void begin() }}>{t('action.start')}</Button>
            <Button variant="outline" disabled={!running || busy} onClick={() => { void execute(pause) }}>{t('action.pause')}</Button>
            <Button variant="outline" disabled={run?.status !== 'paused' || busy} onClick={() => { void execute(resume) }}>{t('action.resume')}</Button>
            <Button variant="ghost" disabled={run === undefined || ['completed', 'failed', 'stopped'].includes(run.status) || busy} onClick={() => { void execute(stop) }}>{t('action.stop')}</Button>
          </div>
          <p className={css.approval}>{t('approval.shared')}</p>
          {error !== undefined && <div role="alert" className={css.error}>{error}</div>}
          {pollError !== undefined && <div role="alert" className={css.error}>{pollError}</div>}
          {run?.message !== undefined && <div className={css.message}>{run.message}</div>}
        </div>

        <div className={css.stepsPanel}>
          <div className={css.stepsHeading}>
            <span>
              {t('steps.title')}
              {run?.traceTruncated === true
                && <small className={css.traceRange}> {t('steps.showing')} {run.traceStartStep ?? 1}-{run.stepCount}</small>}
            </span>
            <span className={css.runStatus}>{traceTitle}</span>
          </div>
          <div ref={traceRef} className={css.traceScroller}>
            {stepsContent}
            {run !== undefined && (run.steps.length > 0 || run.pendingStep !== undefined) && (
              <details className={css.developerTrace}>
                <summary>{t('steps.developerTrace')}</summary>
                {run.steps.map(step => (
                  <div key={step.result.actionId} className={css.developerCall}>
                    <strong>Step {step.step}</strong>
                    <TechnicalTrace step={{
                      id: String(step.result.actionId),
                      index: step.step,
                      type: step.result.verification.success ? 'action' : 'failure',
                      status: step.result.verification.success ? 'success' : 'error',
                      title: describePhoneAction(step.action),
                      description: '',
                      rawSteps: [step],
                    }} t={t} expanded />
                  </div>
                ))}
              </details>
            )}
          </div>
        </div>
      </section>
    </div>
  )
}
