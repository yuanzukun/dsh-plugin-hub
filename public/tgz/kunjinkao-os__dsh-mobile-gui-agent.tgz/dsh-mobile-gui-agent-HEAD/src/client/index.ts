/** Phone Agent browser plugin contributing one session view through standard slots. */

import type { ClientContext, SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-api-remotes/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import type { PhoneDeviceId } from '../core/client.ts'
import phoneAgentRemote from '../../generated/typert.remote-client.js'
import { MobileLauncher } from './MobileLauncher.tsx'
import { PhoneAgentView } from './PhoneAgentView.tsx'
import { en, zh, type PhoneAgentKey } from './locales.ts'
import type { PhoneViewActions, PhoneViewSessionState } from './types.ts'

export { PhoneAgentView } from './PhoneAgentView.tsx'
export type { PhoneAgentPanelProps, PhoneAgentViewProps } from './PhoneAgentView.tsx'
export { MobileLauncher } from './MobileLauncher.tsx'
export type { MobileLauncherProps } from './MobileLauncher.tsx'
export { describePhoneAction, phoneActionOverlay } from './view-model.ts'
export type { PhoneOverlay } from './view-model.ts'
export { buildSemanticAgentSteps, semanticRunTitle } from './semantic-steps.ts'
export type { AgentStepStatus, AgentStepType, SemanticAgentStep, SemanticVerification } from './semantic-steps.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    /** Phone Agent tab copy. */
    'phone-agent': PhoneAgentKey
  }
}

/** Locale namespace owned by the Phone Agent view. */
const NS = 'phone-agent'

/** Required standard client services and the Typert Remote carrier. */
export const inject = ['slots', 'locale', 'remote']

/**
 * Register the Phone Agent tab and bind Remote calls to each owning session.
 * @param ctx - Client Cordis root.
 */
export async function apply(ctx: ClientContext): Promise<() => Promise<void>> {
  const disposeRemote = await ctx.remote.$mount(phoneAgentRemote)
  const phoneAgent = ctx.get('remote.phoneAgent')
  if (phoneAgent === undefined) {
    await disposeRemote()
    throw new Error('phoneAgent Remote service was not registered after mounting its Typert artifact')
  }
  const disposeLocale = ctx.locale.register(NS, { zh, en })
  const t = ctx.locale.bind(NS)
  const sessionStates = new Map<SessionId, PhoneViewSessionState>()
  const bindActions = (sessionId: SessionId): PhoneViewActions => ({
    restoreState: () => sessionStates.get(sessionId),
    persistState: state => { sessionStates.set(sessionId, state) },
    getView: () => phoneAgent.getView(sessionId),
    listDevices: () => phoneAgent.listDevices(),
    connect: address => phoneAgent.connect(address),
    screenshot: (deviceId?: PhoneDeviceId) => phoneAgent.getScreenshot(sessionId, deviceId),
    start: (deviceId, task) => phoneAgent.start(sessionId, { deviceId, task }),
    pause: () => phoneAgent.pause(sessionId),
    resume: () => phoneAgent.resume(sessionId),
    stop: () => phoneAgent.stop(sessionId),
  })
  const disposeView = ctx.slots.inject('conversation.view', () => ctx.slots.register({
    name: 'conversation.view',
    id: 'phone-agent',
    order: 20,
    locale: NS,
    label: () => t('view.phone'),
    inject: bindActions,
  }, PhoneAgentView))
  const disposeLauncher = ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
    name: 'conversation.input.left',
    id: 'phone-agent-launcher',
    order: 20,
    locale: NS,
    inject: bindActions,
  }, MobileLauncher))
  return async () => {
    sessionStates.clear()
    disposeLauncher()
    disposeView()
    disposeLocale()
    await disposeRemote()
  }
}
