/** Injected Phone Agent view operations. */

import type { PhoneDeviceId, PhoneDeviceInfo, PhoneRunView } from '../core/client.ts'
import type { PhoneScreenshotResponse } from '../remote/types.ts'
import type { RemoteResult } from '@deepseek-ai/dsh-typert-protocol'

/** Session-bound Remote operations consumed by the Phone view. */
export interface PhoneViewActions {
  /** Restore the latest UI snapshot for this owning session. */
  restoreState: () => PhoneViewSessionState | undefined
  /** Preserve UI state while the conversation view is unmounted. */
  persistState: (state: PhoneViewSessionState) => void
  /** Read this session's current bounded run view. */
  getView: () => Promise<RemoteResult<PhoneRunView | undefined>>
  /** Discover current ADB devices. */
  listDevices: () => Promise<RemoteResult<readonly PhoneDeviceInfo[]>>
  /** Connect a wireless ADB address. */
  connect: (address: string) => Promise<RemoteResult<PhoneDeviceInfo>>
  /** Capture the active or selected idle device. */
  screenshot: (deviceId?: PhoneDeviceId) => Promise<RemoteResult<PhoneScreenshotResponse>>
  /** Start a run for this session. */
  start: (deviceId: PhoneDeviceId, task: string) => Promise<RemoteResult<PhoneRunView>>
  /** Pause this session's run. */
  pause: () => Promise<RemoteResult<PhoneRunView>>
  /** Resume this session's run. */
  resume: () => Promise<RemoteResult<PhoneRunView>>
  /** Stop this session's run. */
  stop: () => Promise<RemoteResult<PhoneRunView>>
}

/** Session-local state retained across conversation view switches. */
export interface PhoneViewSessionState {
  readonly run?: PhoneRunView
  readonly selectedId?: PhoneDeviceId
  readonly task: string
}
