/** Build Host ESM, declarations, Typert artifacts, and the lazy browser plugin bundle. */

import { cp, mkdir, readFile, rm, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'
import { spawn } from 'node:child_process'
import { build } from 'esbuild'

const root = resolve(import.meta.dirname, '..')
const lib = resolve(root, 'lib')
const temporary = resolve(root, '.client-build')
const platformModules = [
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-web-react',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-attachment',
  '@deepseek-ai/dsh-client-schema-form',
  '@deepseek-ai/dsh-client-runtime/client',
]

await rm(lib, { recursive: true, force: true })
await rm(temporary, { recursive: true, force: true })
await mkdir(lib, { recursive: true })

await run('tsc', ['-p', 'tsconfig.json'])
await run('tsc', ['-p', 'tsconfig.client.json'])

for (const name of ['typert.host.js', 'typert.host.d.ts', 'typert.remote-client.js', 'typert.remote-client.d.ts']) {
  await cp(resolve(root, 'generated', name), resolve(lib, name))
}

await build({
  absWorkingDir: root,
  entryPoints: ['src/client/index.ts'],
  bundle: true,
  outfile: '.client-build/client.js',
  format: 'cjs',
  platform: 'browser',
  target: 'es2022',
  jsx: 'automatic',
  external: platformModules,
  loader: { '.module.css': 'local-css' },
  define: {
    'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    'import.meta.env.MODE': JSON.stringify(process.env.NODE_ENV ?? 'production'),
    'import.meta.env': JSON.stringify({ MODE: process.env.NODE_ENV ?? 'production' }),
  },
  logLevel: 'info',
})

const javascript = (await readFile(resolve(temporary, 'client.js'), 'utf8')).replace(/[ \t]+$/gmu, '')
const css = await readFile(resolve(temporary, 'client.css'), 'utf8')
const tagId = 'dsh-mobile-gui-agent/PhoneAgentView.module.css'
const client = [
  `window.__ModuleLoader__.load({ id: ${JSON.stringify('dsh-mobile-gui-agent')}, factory: (require) => {`,
  'var module = { exports: {} }; var exports = module.exports;',
  `const css = ${JSON.stringify(css)};`,
  `const tagId = ${JSON.stringify(tagId)};`,
  'if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]") === null) {',
  '  const tag = document.createElement("style");',
  `  tag.dataset.plugin = ${JSON.stringify('dsh-mobile-gui-agent')};`,
  '  tag.dataset.pluginCss = tagId;',
  '  tag.textContent = css;',
  '  document.head.appendChild(tag);',
  '}',
  javascript,
  'return module.exports; } });',
  '',
].join('\n')
await writeFile(resolve(lib, 'client.js'), client)
await rm(temporary, { recursive: true, force: true })

/** Run one local build executable and preserve its exit signal. */
async function run(command, args) {
  await new Promise((resolveRun, reject) => {
    const executable = process.platform === 'win32' ? `${command}.cmd` : command
    const child = spawn(executable, args, { cwd: root, stdio: 'inherit' })
    child.once('error', reject)
    child.once('exit', (code, signal) => {
      if (code === 0) resolveRun()
      else reject(new Error(`${command} ${args.join(' ')} failed with ${signal ?? `exit ${code}`}`))
    })
  })
}
