/** Verify the standalone bundle manifest and generated entry points before publication. */

import { access, readFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const root = resolve(import.meta.dirname, '..')
const pkg = JSON.parse(await readFile(resolve(root, 'package.json'), 'utf8'))
const patch = await readFile(resolve(root, 'cordis.patch.yml'), 'utf8')
const clientBundle = await readFile(resolve(root, 'lib/client.js'), 'utf8')

if (pkg.name !== 'dsh-mobile-gui-agent') throw new Error('package name must match the Cordis plugin row')
if (pkg.dsh?.bundle?.patch !== './cordis.patch.yml') throw new Error('dsh.bundle.patch must name cordis.patch.yml')
if (pkg.dsh?.client?.platform !== 'web') throw new Error('dsh.client.platform must be web')
if (!patch.includes('name: dsh-mobile-gui-agent')) throw new Error('bundle patch does not insert the package plugin')
if ((patch.match(/^\s*- id:/gmu) ?? []).length !== 1) throw new Error('standalone bundle must insert exactly one root plugin row')

for (const section of ['dependencies', 'peerDependencies', 'devDependencies']) {
  for (const [name, range] of Object.entries(pkg[section] ?? {})) {
    if (String(range).startsWith('workspace:')) throw new Error(`${section}.${name} uses a workspace-only range`)
  }
}

for (const file of [
  'lib/index.js',
  'lib/types/index.d.ts',
  'lib/client.js',
  'lib/types/client/index.d.ts',
  'lib/typert.host.js',
  'lib/typert.remote-client.js',
]) await access(resolve(root, file))

if (!clientBundle.includes('require("react/jsx-runtime")') || clientBundle.includes('React.createElement')) {
  throw new Error('browser bundle must use the automatic React JSX runtime supplied by Harness')
}

const { TYPERT } = await import(`${new URL('../lib/typert.host.js', import.meta.url).href}?verify=${Date.now()}`)
if (TYPERT?.package !== pkg.name || TYPERT?.face !== 'host') {
  throw new Error('generated Host Typert contribution is not owned by this package')
}

const remote = await import(`${new URL('../lib/typert.remote-client.js', import.meta.url).href}?verify=${Date.now()}`)
if (remote.TYPERT_REMOTE?.package !== pkg.name) {
  throw new Error('generated Remote contribution is not owned by this package')
}

process.stdout.write('standalone package manifest and artifacts verified\n')
