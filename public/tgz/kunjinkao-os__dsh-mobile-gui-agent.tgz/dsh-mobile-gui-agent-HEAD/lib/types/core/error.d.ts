/** Stable Phone capability errors. */
/** Machine-readable Phone failure categories shared across providers and consumers. */
export type PhoneErrorCode = 'PHONE_ADB_NOT_FOUND' | 'PHONE_ADB_FAILED' | 'PHONE_DEVICE_NOT_FOUND' | 'PHONE_DEVICE_AMBIGUOUS' | 'PHONE_DEVICE_OFFLINE' | 'PHONE_DEVICE_UNAUTHORIZED' | 'PHONE_DEVICE_BUSY' | 'PHONE_SCREENSHOT_INVALID' | 'PHONE_HIERARCHY_INVALID' | 'PHONE_COORDINATE_OUT_OF_BOUNDS' | 'PHONE_ELEMENT_NOT_FOUND' | 'PHONE_STALE_OBSERVATION' | 'PHONE_UNICODE_INPUT_UNSUPPORTED' | 'PHONE_PACKAGE_NOT_LAUNCHABLE' | 'PHONE_ACTION_REJECTED' | 'PHONE_APPROVAL_DENIED' | 'PHONE_ACTION_TIMEOUT' | 'PHONE_RUN_NOT_FOUND' | 'PHONE_RUN_NOT_ACTIVE' | 'PHONE_RUN_LIMIT_REACHED';
/** Error carrying a stable code while preserving a provider or policy cause. */
export declare class PhoneError extends Error {
    /** Stable failure category. */
    readonly code: PhoneErrorCode;
    /**
     * Construct a Phone failure.
     * @param code - Stable failure category.
     * @param message - Human-readable diagnostic.
     * @param cause - Optional underlying failure.
     */
    constructor(code: PhoneErrorCode, message: string, cause?: unknown);
}
/**
 * Convert any AbortSignal reason into a structured Phone error without object stringification.
 * @param signal - Aborted cooperative signal.
 * @param fallback - Contextual message used when the reason is not an Error or string.
 * @returns A stable Phone cancellation error preserving the original cause.
 */
export declare function phoneAbortError(signal: AbortSignal, fallback: string): PhoneError;
/** Throw a structured cancellation only when the optional signal is aborted. */
export declare function throwIfPhoneAborted(signal: AbortSignal | undefined, fallback: string): void;
//# sourceMappingURL=error.d.ts.map