/** Blank-session-safe Mobile launcher rendered in the resident composer toolbar. */
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PhoneAgentPanelProps } from './PhoneAgentView.tsx';
/** Full props supplied by the session-scoped composer toolbar entry. */
export type MobileLauncherProps = PropsRuntime<'conversation.input.left'> & PhoneAgentPanelProps;
/** Open the complete Mobile task panel without requiring a prior chat turn. */
export declare function MobileLauncher(props: MobileLauncherProps): import("react").JSX.Element;
//# sourceMappingURL=MobileLauncher.d.ts.map