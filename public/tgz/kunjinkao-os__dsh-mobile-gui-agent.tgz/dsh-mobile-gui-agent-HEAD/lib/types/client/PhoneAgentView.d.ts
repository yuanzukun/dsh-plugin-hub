/** Android Phone Agent session view. */
import type { ConvViewProps } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { PhoneViewActions } from './types.ts';
/** Full props of the Mobile conversation view. */
export type PhoneAgentPanelProps = InjectFace<PhoneViewActions> & PropsLocale<'phone-agent'>;
/** Full props supplied by the registered Mobile conversation-view slot. */
export type PhoneAgentViewProps = ConvViewProps & PhoneAgentPanelProps;
/**
 * Render device selection, screenshot polling, lifecycle controls, and verified steps.
 * @param props - Session slot kit, bound Remote operations, and locale.
 * @returns Phone Agent tab content.
 */
export declare function PhoneAgentView({ restoreState, persistState, getView, listDevices, connect, screenshot, start, pause, resume, stop, t, }: PhoneAgentPanelProps): import("react").JSX.Element;
//# sourceMappingURL=PhoneAgentView.d.ts.map