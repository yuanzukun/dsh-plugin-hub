/** Pure Phone view presentation helpers. */
import type { PhoneAction, PhoneRunStep, PhoneRunView, PhoneUIElement } from '../core/client.ts';
/** Percentage rectangle displayed over the rendered screenshot. */
export interface PhoneOverlay {
    /** Horizontal start percentage. */
    readonly left: number;
    /** Vertical start percentage. */
    readonly top: number;
    /** Width percentage. */
    readonly width: number;
    /** Height percentage. */
    readonly height: number;
}
/** Keep a newer run snapshot from being overwritten by a late polling response. */
export declare function preferPhoneRunView(current: PhoneRunView | undefined, incoming: PhoneRunView): PhoneRunView;
/**
 * Describe a strict action without exposing arbitrary JSON.
 * @param action - Accepted Phone action.
 * @returns Compact human-readable action.
 */
export declare function describePhoneAction(action: PhoneAction): string;
/**
 * Resolve the most recent coordinate or semantic target for screenshot debug overlay.
 * @param step - Last settled step.
 * @param elements - Latest observed semantic elements.
 * @param screenWidth - Screenshot width.
 * @param screenHeight - Screenshot height.
 * @returns Percentage rectangle, or undefined for non-positional actions.
 */
export declare function phoneActionOverlay(step: PhoneRunStep | undefined, elements: readonly PhoneUIElement[], screenWidth: number, screenHeight: number): PhoneOverlay | undefined;
//# sourceMappingURL=view-model.d.ts.map