/** Semantic execution trace projection over raw Phone tool actions. */
import type { PhonePendingStep, PhoneRunStep, PhoneRunView } from '../core/client.ts';
export type AgentStepType = 'goal' | 'action' | 'observation' | 'verification' | 'failure' | 'strategy_change';
export type AgentStepStatus = 'pending' | 'success' | 'warning' | 'error' | 'info';
export interface SemanticVerification {
    readonly summary: string;
    readonly changed: boolean;
    readonly uiHierarchyChanged?: boolean;
    readonly screenshotChanged?: boolean;
    readonly foregroundPackageChanged?: boolean;
    readonly activityChanged?: boolean;
}
export interface SemanticAgentStep {
    readonly id: string;
    readonly index: number;
    readonly type: AgentStepType;
    readonly status: AgentStepStatus;
    readonly title: string;
    readonly description: string;
    readonly goal?: string;
    readonly reason?: string;
    readonly actionSummary?: string;
    readonly resultSummary?: string;
    readonly judgment?: string;
    readonly nextStep?: string;
    readonly verification?: SemanticVerification;
    readonly retryCount?: number;
    readonly pendingPhase?: PhonePendingStep['phase'];
    readonly rawSteps: readonly PhoneRunStep[];
    readonly rawPendingStep?: PhonePendingStep;
}
type Translate = (key: SemanticCopyKey) => string;
type SemanticCopyKey = 'semantic.openApp' | 'semantic.openAppGoal' | 'semantic.openAppAction' | 'semantic.openAppSuccess' | 'semantic.enterSearch' | 'semantic.enterSearchGoal' | 'semantic.tapTarget' | 'semantic.searchOpened' | 'semantic.selectTarget' | 'semantic.selectedTarget' | 'semantic.executeSearch' | 'semantic.searchResults' | 'semantic.inputText' | 'semantic.inputGoal' | 'semantic.inputAction' | 'semantic.inputSuccess' | 'semantic.inputFailure' | 'semantic.retryCount' | 'semantic.adjustInput' | 'semantic.reactivateInput' | 'semantic.useHistory' | 'semantic.useHistoryReason' | 'semantic.strategyReason' | 'semantic.back' | 'semantic.home' | 'semantic.scroll' | 'semantic.wait' | 'semantic.waitResult' | 'semantic.complete' | 'semantic.taskCompleted' | 'semantic.operation' | 'semantic.tapPage' | 'semantic.pressKey' | 'semantic.setupInput' | 'semantic.actionSucceeded' | 'semantic.actionFailed' | 'semantic.screenChanged' | 'semantic.screenUnchanged' | 'semantic.pending' | 'semantic.failureJudgment' | 'semantic.roleTextField' | 'semantic.roleButton' | 'semantic.roleSwitch' | 'semantic.rolePage' | 'steps.title' | 'steps.completed' | 'steps.count' | 'steps.problem' | 'steps.executing' | 'steps.deciding' | 'activity.observing' | 'activity.executing' | 'activity.awaiting_approval' | 'activity.stabilizing' | 'activity.verifying';
/** Convert raw chronological tool actions into a user-facing execution trace. */
export declare function buildSemanticAgentSteps(run: PhoneRunView, t: Translate): readonly SemanticAgentStep[];
/** Header copy whose count follows semantic execution steps, not reasoning turns. */
export declare function semanticRunTitle(run: PhoneRunView | undefined, stepCount: number, t: Translate): string;
export {};
//# sourceMappingURL=semantic-steps.d.ts.map