/** Supported opt-in Android input-method helpers for Unicode text entry. */
/** ADB Keyboard component and broadcast protocol details. */
export declare const ADB_KEYBOARD: {
    readonly component: "com.android.adbkeyboard/.AdbIME";
    readonly packageName: "com.android.adbkeyboard";
    readonly inputAction: "ADB_INPUT_B64";
    readonly clearAction: "ADB_CLEAR_TEXT";
};
/** Read-only readiness result for the supported helper IME. */
export type AdbKeyboardAvailability = 'ready' | 'not-installed' | 'not-enabled' | 'not-selected';
/**
 * Classify ADB Keyboard readiness from Android package and secure-setting output.
 * @param installed - Output from `ime list -s`.
 * @param enabled - Value of `enabled_input_methods`.
 * @param selected - Value of `default_input_method`.
 * @returns The first missing prerequisite, or `ready`.
 */
export declare function adbKeyboardAvailability(installed: string, enabled: string, selected: string): AdbKeyboardAvailability;
/** Extract the first exact Android input-method component from secure settings output. */
export declare function selectedInputMethod(output: string): string | undefined;
/** Whether an Android component spelling identifies the supported helper. */
export declare function isAdbKeyboardComponent(component: string): boolean;
//# sourceMappingURL=unicode-ime.d.ts.map