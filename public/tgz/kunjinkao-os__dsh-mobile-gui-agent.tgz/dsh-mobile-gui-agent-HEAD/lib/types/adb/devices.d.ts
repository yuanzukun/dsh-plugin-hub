/** ADB device-list parsing and wireless-address validation. */
import type { PhoneDeviceInfo } from '../core/index.ts';
/**
 * Parse `adb devices -l` without dropping offline or unauthorized records.
 * @param output - Complete bounded command stdout.
 * @returns Device records in ADB order.
 */
export declare function parseAdbDevices(output: string): readonly PhoneDeviceInfo[];
/**
 * Validate one direct-argv wireless ADB endpoint.
 * @param address - Hostname, IPv4, or bracketed IPv6 plus port.
 * @returns Trimmed validated address.
 */
export declare function parseWirelessAddress(address: string): string;
//# sourceMappingURL=devices.d.ts.map