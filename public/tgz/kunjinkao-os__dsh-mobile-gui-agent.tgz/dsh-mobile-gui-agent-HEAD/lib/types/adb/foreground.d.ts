/** Android dumpsys foreground, keyboard, and lock-state parsing. */
/** Foreground application identity parsed from window or activity diagnostics. */
export interface ForegroundState {
    /** Foreground package. */
    readonly packageName?: string;
    /** Foreground activity component. */
    readonly activity?: string;
}
/** Minimal hierarchy fact needed for a conservative package fallback. */
export interface ResourceIdentifiedElement {
    /** Android resource id such as `com.example:id/search`. */
    readonly resourceId?: string;
}
/**
 * Parse the first focused package/activity component from Android diagnostics.
 * @param output - `dumpsys window` or activity output.
 * @returns Foreground identity, possibly empty when Android omits it.
 */
export declare function parseForegroundState(output: string): ForegroundState;
/**
 * Infer one unambiguous foreground package from hierarchy resource ids.
 * @param elements - Retained UI elements from the same coherent capture.
 * @returns The uniquely most frequent application package, or undefined on no evidence/a tie.
 */
export declare function inferForegroundPackage(elements: readonly ResourceIdentifiedElement[]): string | undefined;
/**
 * Parse software-keyboard visibility from input-method diagnostics.
 * @param output - `dumpsys input_method` output.
 * @returns Visibility when a supported fact is present.
 */
export declare function parseKeyboardVisible(output: string): boolean | undefined;
/**
 * Parse lock-screen state from window policy diagnostics.
 * @param output - `dumpsys window policy` output.
 * @returns Lock state when a supported fact is present.
 */
export declare function parseLocked(output: string): boolean | undefined;
//# sourceMappingURL=foreground.d.ts.map