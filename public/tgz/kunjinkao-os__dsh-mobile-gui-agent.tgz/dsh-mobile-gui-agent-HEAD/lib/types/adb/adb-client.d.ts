/** Managed direct-argv ADB process client. */
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import type { ResolvedConfig } from './config.ts';
/** Successful bounded ADB text execution. */
export interface AdbTextResult {
    /** Process stdout. */
    readonly stdout: string;
    /** Process stderr. */
    readonly stderr: string;
}
/** Direct ADB invocation wrapper over the Harness subprocess capability. */
export declare class AdbClient {
    private readonly subprocess;
    private readonly config;
    private executable;
    /**
     * Create an ADB client.
     * @param subprocess - Execution-world subprocess provider.
     * @param config - Resolved ADB limits and timeouts.
     */
    constructor(subprocess: SubprocessRuntime, config: ResolvedConfig);
    /**
     * Execute ADB and collect bounded UTF-8 streams.
     * @param argv - Arguments after the ADB executable.
     * @param stdoutMaxBytes - Maximum stdout bytes.
     * @param signal - Cooperative cancellation.
     * @returns Collected stdout and stderr.
     */
    text(argv: readonly string[], stdoutMaxBytes: number, signal?: AbortSignal): Promise<AdbTextResult>;
    /**
     * Execute ADB with raw bounded stdout for PNG or other binary data.
     * @param argv - Arguments after the ADB executable.
     * @param maxBytes - Maximum stdout bytes.
     * @param signal - Cooperative cancellation.
     * @returns Exact stdout bytes.
     */
    binary(argv: readonly string[], maxBytes: number, signal?: AbortSignal): Promise<Uint8Array>;
    private resolve;
}
//# sourceMappingURL=adb-client.d.ts.map