/** ADB Service Provider for the Android Phone capability. */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { PhoneDeviceRegistry } from '../core/index.ts';
import type { PhoneDevice, PhoneDeviceId as PhoneDeviceIdType, PhoneDeviceInfo } from '../core/index.ts';
export { AdbClient } from './adb-client.ts';
export { AdbPhoneDevice } from './adb-device.ts';
export { resolveConfig } from './config.ts';
export type { ResolvedConfig } from './config.ts';
export { boundsCenter, extractHierarchyXml, parseUiHierarchy, serializeHierarchy } from './hierarchy.ts';
export { parseAdbDevices, parseWirelessAddress } from './devices.ts';
export { decodeScreenshot, screenshotDifference } from './screenshot.ts';
/** Cordis plugin name used by loader diagnostics. */
export declare const name = "phone-adb";
/** Services required by the ADB provider. */
export declare const inject: string[];
/** Deployment tunables for bounded ADB observation and actions. */
export interface Config {
    /** ADB executable path or PATH name. */
    adbPath?: string;
    /** Absolute path to a user-reviewed ADB Keyboard APK eligible for approved installation. */
    unicodeImeApkPath?: string;
    /** Per-command timeout in milliseconds. */
    commandTimeoutMs?: number;
    /** Process termination grace in milliseconds. */
    processGraceMs?: number;
    /** Maximum PNG bytes accepted from one screenshot. */
    screenshotMaxBytes?: number;
    /** Maximum hierarchy XML bytes accepted from one dump. */
    hierarchyMaxBytes?: number;
    /** Maximum diagnostic bytes accepted from one command. */
    diagnosticMaxBytes?: number;
    /** Maximum retained hierarchy element count. */
    hierarchyMaxElements?: number;
    /** Maximum compact hierarchy text bytes. */
    hierarchyMaxSerializedBytes?: number;
    /** Total UIAutomator capture attempts before an observation fails. */
    hierarchyAttempts?: number;
    /** Delay between failed UIAutomator capture attempts in milliseconds. */
    hierarchyRetryDelayMs?: number;
    /** Stable-screen poll interval in milliseconds. */
    stablePollMs?: number;
    /** Consecutive stable comparisons required. */
    stableSamples?: number;
    /** Stable-screen total timeout in milliseconds. */
    stableTimeoutMs?: number;
    /** Normalized thumbnail difference considered stable. */
    stableDifferenceThreshold?: number;
}
/** Public alias naming this provider's configuration. */
export type AdbPhoneConfig = Config;
/** Loader-visible ADB provider configuration schema. */
export declare const Config: z<Config>;
/** Concrete `ctx.phone` registry backed by the configured ADB executable. */
export declare class AdbPhoneDeviceRegistry extends PhoneDeviceRegistry {
    /** Required subprocess capability for direct class and Loader composition. */
    static inject: string[];
    /** Loader-visible provider configuration. */
    static Config: z<Config>;
    private readonly config;
    private readonly client;
    /**
     * Register an ADB-backed Phone provider.
     * @param ctx - Cordis context carrying the subprocess capability.
     * @param config - Provider deployment configuration.
     */
    constructor(ctx: Context, config?: Config);
    /** @inheritdoc */
    list(signal?: AbortSignal): Promise<readonly PhoneDeviceInfo[]>;
    /** @inheritdoc */
    connect(address: string, signal?: AbortSignal): Promise<PhoneDeviceInfo>;
    /** @inheritdoc */
    open(id: PhoneDeviceIdType, signal?: AbortSignal): Promise<PhoneDevice>;
}
export default AdbPhoneDeviceRegistry;
//# sourceMappingURL=index.d.ts.map