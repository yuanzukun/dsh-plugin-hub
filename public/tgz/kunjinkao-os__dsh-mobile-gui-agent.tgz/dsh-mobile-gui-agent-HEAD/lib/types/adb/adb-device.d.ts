/** Device-bound ADB Phone implementation. */
import type { PhoneCapture, PhoneDevice, PhoneDeviceId, PhoneHierarchy, PhoneKey, PhoneScreenshot, PhoneShellRequest, StableScreenOptions, StableScreenResult } from '../core/index.ts';
import type { ResolvedConfig } from './config.ts';
import type { AdbClient } from './adb-client.ts';
/** Android device handle whose every operation is routed through one serial. */
export declare class AdbPhoneDevice implements PhoneDevice {
    readonly id: PhoneDeviceId;
    private readonly client;
    private readonly config;
    /**
     * Bind a provider client to one usable device.
     * @param id - Concrete ADB serial.
     * @param client - Managed direct-argv client.
     * @param config - Resolved provider limits.
     */
    constructor(id: PhoneDeviceId, client: AdbClient, config: ResolvedConfig);
    /** @inheritdoc */
    screenshot(signal?: AbortSignal): Promise<PhoneScreenshot>;
    /** @inheritdoc */
    getUIHierarchy(signal?: AbortSignal): Promise<PhoneHierarchy>;
    /** @inheritdoc */
    getState(signal?: AbortSignal): Promise<PhoneCapture>;
    /** @inheritdoc */
    tap(x: number, y: number, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    longPress(x: number, y: number, durationMs: number, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    swipe(x1: number, y1: number, x2: number, y2: number, durationMs: number, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    inputText(text: string, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    replaceText(text: string, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    setupUnicodeInput(signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    pressKey(key: PhoneKey, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    back(signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    home(signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    openApp(packageName: string, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    shell(request: PhoneShellRequest, signal?: AbortSignal): Promise<string>;
    /** @inheritdoc */
    wait(ms: number, signal?: AbortSignal): Promise<void>;
    /** @inheritdoc */
    waitForStableScreen(options: StableScreenOptions, signal?: AbortSignal): Promise<StableScreenResult>;
    private captureHierarchy;
    private dumpHierarchy;
    private dumpHierarchyOnce;
    private diagnostic;
    private runShell;
    /** Read the supported helper's install, enabled, and selection state. */
    private adbKeyboardState;
    /** Use an installed helper temporarily, always restoring the user's selected and enabled IME state. */
    private withAdbKeyboard;
    /** Send one package-scoped ADB Keyboard broadcast with optional UTF-8 Base64 text. */
    private broadcastAdbKeyboard;
    private assertCoordinates;
}
//# sourceMappingURL=adb-device.d.ts.map