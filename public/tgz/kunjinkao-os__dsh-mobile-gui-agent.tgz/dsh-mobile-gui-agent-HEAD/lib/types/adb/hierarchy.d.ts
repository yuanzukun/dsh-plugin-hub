/** UIAutomator XML parsing, pruning, and compact serialization. */
import type { PhoneBounds, PhoneHierarchy } from '../core/index.ts';
/** Pruning limits applied before hierarchy data reaches a model or trace. */
export interface HierarchyLimits {
    /** Current display width. */
    readonly width: number;
    /** Current display height. */
    readonly height: number;
    /** Maximum retained element count. */
    readonly maxElements: number;
    /** Maximum compact serialized UTF-8 bytes. */
    readonly maxSerializedBytes: number;
}
/**
 * Parse and prune one complete UIAutomator XML document.
 * @param xml - XML beginning at its declaration or hierarchy root.
 * @param limits - Display geometry and output caps.
 * @returns Compact hierarchy with deterministic ids and signature.
 */
export declare function parseUiHierarchy(xml: string, limits: HierarchyLimits): PhoneHierarchy;
/**
 * Extract the XML document from noisy UIAutomator stdout.
 * @param output - Complete bounded stdout or file content.
 * @returns XML suffix beginning at the declaration or hierarchy root.
 */
export declare function extractHierarchyXml(output: string): string;
/**
 * Serialize retained elements into token-efficient model text.
 * @param hierarchy - Pruned hierarchy.
 * @returns One compact element per line.
 */
export declare function serializeHierarchy(hierarchy: PhoneHierarchy): string;
/**
 * Compute one element's safe display center.
 * @param bounds - Visible bounds.
 * @returns Integer center coordinate.
 */
export declare function boundsCenter(bounds: PhoneBounds): readonly [x: number, y: number];
//# sourceMappingURL=hierarchy.d.ts.map