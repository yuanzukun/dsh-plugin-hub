# Contributing

Thanks for improving `dsh-mobile-gui-agent`.

## Development setup

Use Node.js `^22.19.0 || >=24.0.0`, pnpm `11.7.0`, Android Platform Tools for ADB integration work, and a current DeepSeek Harness Web profile for browser acceptance.

```bash
pnpm install
pnpm run check
pnpm pack
```

The normal test suite is keyless and uses `FakePhoneDevice`. Set `DSH_PHONE_ADB_INTEGRATION_DEVICE` only when running the read-only real-device test. Set `DSH_PHONE_ADB_MUTATION_TESTS=1` as well only on a device where Home, Back, tap, swipe, and text input are safe.

## Change expectations

- Keep the project as one installable Harness bundle plugin and use Cordis lifecycle effects.
- Add behavior through Harness capability, tool, Remote, slot, event, and approval extension points; do not patch the upstream Agent loop.
- Keep ADB commands behind `PhoneDevice` and use direct argv execution.
- Add focused tests for behavior changes and update English and Chinese documentation together.
- Never commit API keys, device screenshots containing personal data, or local profile files.
- Commit rebuilt `lib/` and generated Typert artifacts when their sources change.

Before opening a pull request, confirm `pnpm run check`, `pnpm pack`, and `git diff --check` pass. Describe any real-device checks and whether they changed device state.
