import { describe, expect, it } from 'vitest'
import { TYPERT } from '../../generated/typert.host.js'
import type { PhoneAction, PhoneObservation, PhoneRunStep, PhoneRunView } from '../../src/core/client.ts'

const observation: PhoneObservation = {
  id: 'observation-after' as never,
  deviceId: 'device-1' as never,
  timestamp: 10,
  width: 1080,
  height: 2400,
  orientation: 'portrait',
  screenshotDigest: 'digest',
  screenshotSignature: 'screenshot-signature',
  elements: [],
  uiSignature: 'ui-signature',
  hierarchyTruncated: false,
}

function step(index: number, action: PhoneAction): PhoneRunStep {
  return {
    step: index,
    action,
    result: {
      actionId: `action-${String(index)}` as never,
      action,
      executed: action.type !== 'finish',
      verification: {
        success: true,
        changed: action.type !== 'finish',
        evidence: ['verified'],
        facts: {
          foregroundPackageChanged: false,
          activityChanged: false,
          displayChanged: false,
          uiHierarchyChanged: action.type !== 'finish',
          screenshotChanged: action.type !== 'finish',
          ...(action.type === 'replace_text' ? { textChanged: true } : {}),
        },
      },
      stuck: { stuck: false },
      observation,
    },
    context: {
      before: {
        observationId: `observation-${String(index)}` as never,
        uiSignature: `ui-${String(index)}`,
        screenshotSignature: `screen-${String(index)}`,
      },
    },
    timestamp: index,
    startedAt: index,
    completedAt: index + 1,
  }
}

describe('generated Typert artifacts', () => {
  it('accepts a complete getView trace containing text replacement', () => {
    const actions: readonly PhoneAction[] = [
      { type: 'tap_element', observationId: 'launcher' as never, elementId: 63 },
      { type: 'replace_text', text: '华为手机' },
      { type: 'tap_element', observationId: 'search' as never, elementId: 28 },
      { type: 'finish', success: true, message: '搜索结果页已加载' },
    ]
    const view: PhoneRunView = {
      id: 'run-1' as never,
      deviceId: observation.deviceId,
      task: '打开淘宝，搜索华为手机',
      status: 'completed',
      activity: 'finished',
      stepCount: actions.length,
      consecutiveFailures: 0,
      startedAt: 1,
      updatedAt: 10,
      observation,
      steps: actions.map((action, index) => step(index + 1, action)),
      traceStartStep: 1,
      traceTruncated: false,
      message: '搜索结果页已加载',
    }
    const invocation = TYPERT.invocations.find(candidate => candidate.id.endsWith('phoneAgent/getView'))

    expect(invocation?.result.schema.safeParse(view)).toMatchObject({ success: true })
  })
})
