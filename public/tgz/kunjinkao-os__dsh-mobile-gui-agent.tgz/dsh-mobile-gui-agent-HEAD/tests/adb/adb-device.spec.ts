import { describe, expect, it } from 'vitest'
import { AdbPhoneDevice, resolveConfig } from '../../src/adb/index.ts'
import type { AdbClient, AdbTextResult } from '../../src/adb/index.ts'
import { PhoneDeviceId } from '../../src/core/index.ts'

const ADB_KEYBOARD = 'com.android.adbkeyboard/.AdbIME'

class InputAdbClient {
  readonly calls: string[][] = []
  private installed: string
  private enabled: string
  private selected: string

  constructor(
    installed = ADB_KEYBOARD,
    enabled = ADB_KEYBOARD,
    selected = ADB_KEYBOARD,
  ) {
    this.installed = installed
    this.enabled = enabled
    this.selected = selected
  }

  text(argv: readonly string[]): Promise<AdbTextResult> {
    this.calls.push([...argv])
    if (argv[2] === 'install') {
      this.installed = ADB_KEYBOARD
      return Promise.resolve({ stdout: 'Success', stderr: '' })
    }
    const command = argv.slice(3).join(' ')
    if (command === 'ime list -a -s') return Promise.resolve({ stdout: this.installed, stderr: '' })
    if (command === 'ime list -s') return Promise.resolve({ stdout: this.enabled, stderr: '' })
    if (command === 'settings get secure enabled_input_methods') return Promise.resolve({ stdout: this.enabled, stderr: '' })
    if (command === 'settings get secure default_input_method') return Promise.resolve({ stdout: this.selected, stderr: '' })
    if (command === `ime enable ${ADB_KEYBOARD}`) {
      this.enabled = [this.enabled, ADB_KEYBOARD].filter(Boolean).join(':')
      return Promise.resolve({ stdout: `Input method ${ADB_KEYBOARD}: now enabled`, stderr: '' })
    }
    if (command === `ime disable ${ADB_KEYBOARD}`) {
      this.enabled = this.enabled.split(':').filter(component => component !== ADB_KEYBOARD).join(':')
      return Promise.resolve({ stdout: `Input method ${ADB_KEYBOARD}: now disabled`, stderr: '' })
    }
    if (command.startsWith('ime set ')) {
      this.selected = command.slice('ime set '.length)
      return Promise.resolve({ stdout: `Input method ${this.selected} selected`, stderr: '' })
    }
    return Promise.resolve({ stdout: 'Broadcast completed: result=0', stderr: '' })
  }

  inputMethodState(): { readonly enabled: string; readonly selected: string } {
    return { enabled: this.enabled, selected: this.selected }
  }
}

class AbortOnBroadcastAdbClient extends InputAdbClient {
  constructor(
    private readonly controller: AbortController,
    installed: string,
    enabled: string,
    selected: string,
  ) {
    super(installed, enabled, selected)
  }

  override async text(argv: readonly string[], _maxOutputBytes?: number, signal?: AbortSignal): Promise<AdbTextResult> {
    if (signal?.aborted === true) throw new Error('command received an aborted signal')
    const result = await super.text(argv)
    if (argv.includes('broadcast')) {
      this.controller.abort(new Error('cancel during Unicode broadcast'))
      throw new Error('cancel during Unicode broadcast')
    }
    return result
  }
}

function createDevice(client: InputAdbClient, unicodeImeApkPath?: string): AdbPhoneDevice {
  return new AdbPhoneDevice(
    PhoneDeviceId('fake'),
    client as unknown as AdbClient,
    resolveConfig({ ...(unicodeImeApkPath === undefined ? {} : { unicodeImeApkPath }) }),
  )
}

describe('AdbPhoneDevice text input', () => {
  it('requires an absolute configured helper APK path', () => {
    expect(() => resolveConfig({ unicodeImeApkPath: 'ADBKeyboard.apk' })).toThrow('must be an absolute path')
    expect(resolveConfig({ unicodeImeApkPath: '/reviewed/ADBKeyboard.apk' }).unicodeImeApkPath)
      .toBe('/reviewed/ADBKeyboard.apk')
  })

  it('keeps printable ASCII on Android input text', async () => {
    const client = new InputAdbClient('', '', '')
    await createDevice(client).inputText('hello world')

    expect(client.calls).toEqual([
      ['-s', 'fake', 'shell', 'input', 'text', 'hello%sworld'],
    ])
  })

  it('sends Unicode as UTF-8 Base64 when ADB Keyboard is installed, enabled, and selected', async () => {
    const client = new InputAdbClient()
    await createDevice(client).inputText('中文')

    expect(client.calls.at(-1)).toEqual([
      '-s', 'fake', 'shell', 'am', 'broadcast',
      '-a', 'ADB_INPUT_B64', '-p', 'com.android.adbkeyboard', '--es', 'msg', '5Lit5paH',
    ])
  })

  it('rejects Unicode without installing, enabling, or switching an IME', async () => {
    const client = new InputAdbClient('', '', '')

    await expect(createDevice(client).inputText('中文')).rejects.toMatchObject({
      code: 'PHONE_UNICODE_INPUT_UNSUPPORTED',
      message: expect.stringContaining('not installed'),
    })
    const shell = client.calls.flat().join(' ')
    expect(shell).not.toMatch(/\b(?:install|enable|set)\b/u)
    expect(shell).not.toContain('am broadcast')
  })

  it('installs and probes a configured helper only through explicit setup, then restores the previous IME', async () => {
    const previous = 'com.example/.UserIme'
    const client = new InputAdbClient('', previous, previous)
    const device = createDevice(client, '/reviewed/ADBKeyboard.apk')

    await device.setupUnicodeInput()

    expect(client.calls).toContainEqual(['-s', 'fake', 'install', '-r', '/reviewed/ADBKeyboard.apk'])
    expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'enable', ADB_KEYBOARD])
    expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'set', ADB_KEYBOARD])
    expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'set', previous])
    expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'disable', ADB_KEYBOARD])
    expect(client.inputMethodState()).toEqual({ enabled: previous, selected: previous })
  })

  it('temporarily selects an installed helper without an explicit setup action', async () => {
    const previous = 'com.example/.UserIme'
    const client = new InputAdbClient(ADB_KEYBOARD, `${previous}:${ADB_KEYBOARD}`, previous)

    await createDevice(client).inputText('中文')

    expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'list', '-a', '-s'])
    expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'set', ADB_KEYBOARD])
    expect(client.calls).toContainEqual([
      '-s', 'fake', 'shell', 'am', 'broadcast',
      '-a', 'ADB_INPUT_B64', '-p', 'com.android.adbkeyboard', '--es', 'msg', '5Lit5paH',
    ])
    expect(client.inputMethodState()).toEqual({ enabled: `${previous}:${ADB_KEYBOARD}`, selected: previous })
  })

  it('temporarily enables and selects an installed disabled helper, then restores both settings', async () => {
    const previous = 'com.example/.UserIme'
    const client = new InputAdbClient(ADB_KEYBOARD, previous, previous)

    await createDevice(client).inputText('中文')

    expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'enable', ADB_KEYBOARD])
    expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'set', ADB_KEYBOARD])
    expect(client.calls).toContainEqual([
      '-s', 'fake', 'shell', 'am', 'broadcast',
      '-a', 'ADB_INPUT_B64', '-p', 'com.android.adbkeyboard', '--es', 'msg', '5Lit5paH',
    ])
    expect(client.inputMethodState()).toEqual({ enabled: previous, selected: previous })
  })

  it('restores the previous IME with a fresh cleanup signal when Unicode input is cancelled', async () => {
    const previous = 'com.example/.UserIme'
    const controller = new AbortController()
    const client = new AbortOnBroadcastAdbClient(controller, ADB_KEYBOARD, previous, previous)
    const device = createDevice(client)

    await expect(device.inputText('中文', controller.signal)).rejects.toThrow('cancel during Unicode broadcast')

    expect(client.inputMethodState()).toEqual({ enabled: previous, selected: previous })
    expect(client.calls.slice(-2)).toEqual([
      ['-s', 'fake', 'shell', 'ime', 'set', previous],
      ['-s', 'fake', 'shell', 'ime', 'disable', ADB_KEYBOARD],
    ])
  })

  it('fails setup without side effects when no reviewed helper APK path is configured', async () => {
    const client = new InputAdbClient('', '', 'com.example/.UserIme')

    await expect(createDevice(client).setupUnicodeInput()).rejects.toMatchObject({
      code: 'PHONE_UNICODE_INPUT_UNSUPPORTED',
      message: expect.stringContaining('unicodeImeApkPath'),
    })
    expect(client.calls.some(call => call.includes('install') || call.includes('enable') || call.includes('set'))).toBe(false)
  })

  it('clears and replaces Unicode text through the ready helper', async () => {
    const client = new InputAdbClient()
    await createDevice(client).replaceText('新内容')

    expect(client.calls.slice(-2)).toEqual([
      ['-s', 'fake', 'shell', 'am', 'broadcast', '-a', 'ADB_CLEAR_TEXT', '-p', 'com.android.adbkeyboard'],
      ['-s', 'fake', 'shell', 'am', 'broadcast', '-a', 'ADB_INPUT_B64', '-p', 'com.android.adbkeyboard', '--es', 'msg', '5paw5YaF5a65'],
    ])
  })

  it('replaces ASCII text without requiring a helper', async () => {
    const client = new InputAdbClient('', '', '')
    await createDevice(client).replaceText('new value')

    expect(client.calls).toEqual([
      ['-s', 'fake', 'shell', 'input', 'keycombination', 'KEYCODE_CTRL_LEFT', 'KEYCODE_A'],
      ['-s', 'fake', 'shell', 'input', 'keyevent', 'KEYCODE_DEL'],
      ['-s', 'fake', 'shell', 'input', 'text', 'new%svalue'],
    ])
  })
})
