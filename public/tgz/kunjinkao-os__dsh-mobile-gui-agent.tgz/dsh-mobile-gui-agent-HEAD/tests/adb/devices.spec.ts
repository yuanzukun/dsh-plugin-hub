import { describe, expect, it } from 'vitest'
import { parseAdbDevices, parseWirelessAddress } from '../../src/adb/index.ts'

describe('ADB device discovery', () => {
  it('retains usable and diagnosable device states', () => {
    expect(parseAdbDevices(`List of devices attached
emulator-5554 device product:sdk_gphone64_arm64 model:sdk_gphone64_arm64 transport_id:1
serial-off offline transport_id:2
serial-auth unauthorized usb:1-1
`)).toEqual([
      {
        id: 'emulator-5554',
        status: 'device',
        product: 'sdk_gphone64_arm64',
        model: 'sdk_gphone64_arm64',
        transportId: '1',
      },
      { id: 'serial-off', status: 'offline', transportId: '2' },
      { id: 'serial-auth', status: 'unauthorized' },
    ])
  })

  it('accepts host ports and rejects ambiguous shell-like text', () => {
    expect(parseWirelessAddress('192.168.1.109:41141')).toBe('192.168.1.109:41141')
    expect(parseWirelessAddress('[fe80::1]:5555')).toBe('[fe80::1]:5555')
    expect(() => parseWirelessAddress('host:5555; reboot')).toThrow(/HOST:PORT/)
    expect(() => parseWirelessAddress('host:70000')).toThrow(/65535/)
  })
})
