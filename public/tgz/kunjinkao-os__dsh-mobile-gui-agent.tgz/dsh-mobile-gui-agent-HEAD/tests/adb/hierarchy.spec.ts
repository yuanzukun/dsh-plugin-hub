import { describe, expect, it } from 'vitest'
import { boundsCenter, extractHierarchyXml, parseUiHierarchy, serializeHierarchy } from '../../src/adb/index.ts'

const XML = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<hierarchy rotation="0">
  <node index="0" text="" resource-id="" class="android.widget.FrameLayout" clickable="false" enabled="true" bounds="[0,0][1080,2400]">
    <node index="0" text="Wi-Fi" resource-id="android:id/title" class="android.widget.TextView" clickable="true" enabled="true" bounds="[24,100][600,180]" />
    <node index="1" text="" resource-id="android:id/switch_widget" class="android.widget.Switch" checkable="true" checked="false" clickable="true" enabled="true" bounds="[840,90][1032,186]" />
    <node index="2" text="" resource-id="" class="android.view.View" clickable="false" enabled="true" bounds="[0,0][0,0]" />
  </node>
</hierarchy>`

describe('UIAutomator hierarchy', () => {
  it('extracts noisy XML, prunes containers, and assigns short semantic ids', () => {
    const xml = extractHierarchyXml(`UI dump started\n${XML}\nUI hierchary dumped to: /dev/tty`)
    const hierarchy = parseUiHierarchy(xml, {
      width: 1080,
      height: 2400,
      maxElements: 20,
      maxSerializedBytes: 4_096,
    })
    expect(hierarchy.elements).toHaveLength(2)
    expect(hierarchy.elements[0]).toMatchObject({ id: 1, text: 'Wi-Fi', clickable: true })
    expect(hierarchy.elements[1]).toMatchObject({ id: 2, checked: false, bounds: [840, 90, 1032, 186] })
    expect(boundsCenter(hierarchy.elements[1]!.bounds)).toEqual([936, 138])
    expect(serializeHierarchy(hierarchy)).toContain('[2] Switch "android:id/switch_widget" clickable checked=false')
    expect(serializeHierarchy(hierarchy)).not.toContain('<node')
  })

  it('reports truncation before exceeding count or serialized limits', () => {
    const hierarchy = parseUiHierarchy(XML, {
      width: 1080,
      height: 2400,
      maxElements: 1,
      maxSerializedBytes: 4_096,
    })
    expect(hierarchy.elements).toHaveLength(1)
    expect(hierarchy.truncated).toBe(true)
  })

  it('rejects incomplete UIAutomator output', () => {
    expect(() => extractHierarchyXml('<hierarchy>')).toThrow(/incomplete/)
  })
})
