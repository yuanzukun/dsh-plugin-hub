import sharp from 'sharp'
import { describe, expect, it, vi } from 'vitest'
import { PhoneDeviceId } from '../../src/core/index.ts'
import { AdbPhoneDevice, resolveConfig } from '../../src/adb/index.ts'
import type { AdbClient } from '../../src/adb/index.ts'

const XML = '<?xml version="1.0" encoding="UTF-8"?><hierarchy rotation="0"><node class="android.widget.Button" text="Retry" clickable="true" enabled="true" bounds="[0,0][3,3]"/></hierarchy>'

async function screenshotBytes(): Promise<Buffer> {
  return sharp({
    create: { width: 4, height: 6, channels: 4, background: { r: 12, g: 34, b: 56, alpha: 1 } },
  }).png().toBuffer()
}

describe('UIAutomator hierarchy retries', () => {
  it('retries the direct and fallback paths after a transient empty dump', async () => {
    let directAttempts = 0
    const text = vi.fn((argv: readonly string[]) => {
      if (argv.at(-1) === '/dev/tty') {
        directAttempts++
        return Promise.resolve({ stdout: directAttempts === 1 ? 'ERROR: could not get idle state.' : XML, stderr: '' })
      }
      return Promise.resolve({ stdout: '', stderr: '' })
    })
    const client = {
      binary: () => screenshotBytes(),
      text,
    } as unknown as AdbClient
    const device = new AdbPhoneDevice(
      PhoneDeviceId('serial'),
      client,
      resolveConfig({ hierarchyAttempts: 2, hierarchyRetryDelayMs: 1 }),
    )

    await expect(device.getUIHierarchy()).resolves.toMatchObject({
      elements: [expect.objectContaining({ text: 'Retry' })],
    })
    expect(directAttempts).toBe(2)
  })

  it('reports the bounded attempt count when every dump is empty', async () => {
    let directAttempts = 0
    const client = {
      binary: () => screenshotBytes(),
      text: (argv: readonly string[]) => {
        if (argv.at(-1) === '/dev/tty') directAttempts++
        return Promise.resolve({ stdout: '', stderr: '' })
      },
    } as unknown as AdbClient
    const device = new AdbPhoneDevice(
      PhoneDeviceId('serial'),
      client,
      resolveConfig({ hierarchyAttempts: 2, hierarchyRetryDelayMs: 1 }),
    )

    await expect(device.getUIHierarchy()).rejects.toMatchObject({
      code: 'PHONE_HIERARCHY_INVALID',
      message: 'UIAutomator did not return XML after 2 attempts',
    })
    expect(directAttempts).toBe(2)
  })
})
