import { Context } from '@deepseek-ai/cordis'
import { describe, expect, it } from 'vitest'
import LocalSubprocessRuntime from '@deepseek-ai/dsh-subprocess-local'
import AdbPhoneDeviceRegistry from '../../src/adb/index.ts'
import { PhoneDeviceId } from '../../src/core/index.ts'

const deviceId = process.env.DSH_PHONE_ADB_INTEGRATION_DEVICE
const mutations = process.env.DSH_PHONE_ADB_MUTATION_TESTS === '1'

describe.skipIf(deviceId === undefined)('real ADB provider', () => {
  it('captures screenshot and compact UI state', async () => {
    const ctx = new Context()
    const subprocessFiber = await ctx.plugin(LocalSubprocessRuntime)
    const providerFiber = await ctx.plugin(AdbPhoneDeviceRegistry, {})
    try {
      const device = await ctx.phone.open(PhoneDeviceId(deviceId!))
      const capture = await device.getState()
      expect(capture.screenshot.data.byteLength).toBeGreaterThan(8)
      expect(capture.observation.width).toBeGreaterThan(0)
      expect(capture.observation.height).toBeGreaterThan(0)
      expect(capture.observation.elements).toBeInstanceOf(Array)
    } finally {
      await providerFiber.dispose()
      await subprocessFiber.dispose()
    }
  }, 60_000)

  it.skipIf(!mutations)('executes bounded navigation, input, tap, and swipe actions', async () => {
    const ctx = new Context()
    const subprocessFiber = await ctx.plugin(LocalSubprocessRuntime)
    const providerFiber = await ctx.plugin(AdbPhoneDeviceRegistry, {})
    try {
      const device = await ctx.phone.open(PhoneDeviceId(deviceId!))
      const screenshot = await device.screenshot()
      await device.home()
      await device.tap(Math.floor(screenshot.width / 2), Math.floor(screenshot.height / 2))
      await device.swipe(
        Math.floor(screenshot.width / 2),
        Math.floor(screenshot.height * 0.75),
        Math.floor(screenshot.width / 2),
        Math.floor(screenshot.height * 0.25),
        300,
      )
      await device.inputText('hello%sworld')
      await device.back()
    } finally {
      await providerFiber.dispose()
      await subprocessFiber.dispose()
    }
  }, 60_000)
})
