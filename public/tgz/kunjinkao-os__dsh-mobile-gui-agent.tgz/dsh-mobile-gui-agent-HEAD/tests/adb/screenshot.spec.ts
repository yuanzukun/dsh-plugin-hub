import sharp from 'sharp'
import { describe, expect, it } from 'vitest'
import { decodeScreenshot, screenshotDifference } from '../../src/adb/index.ts'

describe('ADB screenshot decoding', () => {
  it('reports intrinsic PNG metadata and a bounded comparison signature', async () => {
    const data = await sharp({
      create: { width: 4, height: 6, channels: 4, background: { r: 12, g: 34, b: 56, alpha: 1 } },
    }).png().toBuffer()
    const screenshot = await decodeScreenshot(data, 123)
    expect(screenshot).toMatchObject({ width: 4, height: 6, timestamp: 123 })
    expect(screenshot.digest).toHaveLength(64)
    expect(screenshotDifference(screenshot.comparisonSignature, screenshot.comparisonSignature)).toBe(0)
  })

  it('rejects non-image output', async () => {
    await expect(decodeScreenshot(Buffer.from('adb diagnostic'), 123)).rejects.toMatchObject({
      code: 'PHONE_SCREENSHOT_INVALID',
    })
  })
})
