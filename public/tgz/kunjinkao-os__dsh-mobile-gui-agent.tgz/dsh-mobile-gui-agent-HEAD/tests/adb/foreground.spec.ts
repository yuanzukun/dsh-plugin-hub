import { readFileSync } from 'node:fs'
import { describe, expect, it } from 'vitest'
import { inferForegroundPackage, parseForegroundState, parseKeyboardVisible } from '../../src/adb/foreground.ts'

const hyperosWindow = readFileSync(new URL('../fixtures/hyperos-window.txt', import.meta.url), 'utf8')
const hyperosInputMethod = readFileSync(new URL('../fixtures/hyperos-input-method.txt', import.meta.url), 'utf8')

describe('Android state diagnostics', () => {
  it('parses the HyperOS focused-window component', () => {
    expect(parseForegroundState(hyperosWindow)).toEqual({
      packageName: 'com.taobao.taobao',
      activity: 'com.taobao.taobao/com.taobao.tao.TBMainActivity',
    })
  })

  it('parses the Android IME visible bit used by HyperOS', () => {
    expect(parseKeyboardVisible(hyperosInputMethod)).toBe(true)
    expect(parseKeyboardVisible('mImeWindowVis=0x1')).toBe(false)
  })

  it('infers an unambiguous foreground package from hierarchy resource ids', () => {
    expect(inferForegroundPackage([
      { resourceId: 'com.taobao.taobao:id/search_bar' },
      { resourceId: 'com.taobao.taobao:id/title' },
      { resourceId: 'android:id/content' },
    ])).toBe('com.taobao.taobao')
  })

  it('keeps the foreground unknown when resource-id package counts are tied', () => {
    expect(inferForegroundPackage([
      { resourceId: 'com.example.one:id/title' },
      { resourceId: 'com.example.two:id/title' },
    ])).toBeUndefined()
  })
})
