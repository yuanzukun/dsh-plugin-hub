import { describe, expect, it } from 'vitest'
import type { PhoneAction, PhoneRunStep, PhoneRunView, PhoneVerification } from '../../src/core/client.ts'
import { buildSemanticAgentSteps, semanticRunTitle } from '../../src/client/semantic-steps.ts'
import { zh } from '../../src/client/locales.ts'

const t = (key: keyof typeof zh): string => zh[key]

function rawStep(
  step: number,
  action: PhoneAction,
  success: boolean,
  target?: { readonly text?: string; readonly accessibilityLabel?: string; readonly role?: string },
): PhoneRunStep {
  const verification: PhoneVerification = {
    success,
    changed: success,
    evidence: success ? ['compact UI hierarchy changed', 'screenshot changed'] : ['focused editable text did not change'],
    facts: {
      foregroundPackageChanged: action.type === 'open_app',
      activityChanged: false,
      displayChanged: false,
      uiHierarchyChanged: success,
      screenshotChanged: success,
      ...(action.type === 'input_text' || action.type === 'replace_text' ? { textChanged: success } : {}),
    },
  }
  return {
    step,
    action,
    result: {
      actionId: `action-${step}` as never,
      action,
      executed: true,
      verification,
      stuck: { stuck: false },
      observation: {
        id: `after-${step}`,
        elements: [],
        foregroundPackage: action.type === 'open_app' ? action.packageName : 'com.taobao.taobao',
      } as never,
    },
    context: {
      before: {
        observationId: `before-${step}` as never,
        foregroundPackage: 'com.android.launcher',
        uiSignature: `ui-${step}`,
        screenshotSignature: `screen-${step}`,
      },
      ...(target === undefined ? {} : { target: { elementId: 125, ...target } }),
    },
    timestamp: step,
  }
}

function run(steps: readonly PhoneRunStep[], status: PhoneRunView['status'] = 'running'): PhoneRunView {
  return {
    id: 'run' as never,
    deviceId: 'device' as never,
    task: '打开淘宝，搜索华为手机',
    status,
    activity: 'thinking',
    stepCount: steps.length,
    consecutiveFailures: 0,
    startedAt: 1,
    updatedAt: steps.length + 1,
    steps,
  }
}

describe('semantic execution trace', () => {
  it('formats a normal app search flow in chronological semantic order', () => {
    const steps = buildSemanticAgentSteps(run([
      rawStep(1, { type: 'open_app', packageName: 'com.taobao.taobao' }, true),
      rawStep(2, { type: 'tap_element', observationId: 'before-2' as never, elementId: 125 }, true, { accessibilityLabel: '搜索栏', role: 'text_field' }),
      rawStep(3, { type: 'replace_text', text: '华为手机' }, true, { role: 'text_field' }),
      rawStep(4, { type: 'press_key', key: 'enter' }, true, { role: 'text_field' }),
      rawStep(5, { type: 'finish', success: true, message: 'Search complete.' }, true),
    ]), t)

    expect(steps.map(step => step.title)).toEqual(['打开淘宝', '进入搜索', '输入“华为手机”', '执行搜索', '验证任务结果'])
    expect(steps.map(step => step.index)).toEqual([1, 2, 3, 4, 5])
    expect(steps[1]?.description).toBe('点击「搜索栏」')
    expect(steps.some(step => step.title.includes('Taobao is open'))).toBe(false)
  })

  it('keeps every settled action visible through retries and completion', () => {
    const raw = [
      rawStep(1, { type: 'tap_element', observationId: 'launcher' as never, elementId: 63 }, true, { text: '淘宝' }),
      rawStep(2, { type: 'tap_element', observationId: 'home' as never, elementId: 124 }, true, { text: '搜索栏' }),
      rawStep(3, { type: 'replace_text', text: '华为手机' }, false),
      rawStep(4, { type: 'tap_element', observationId: 'search' as never, elementId: 29 }, true, { text: '搜索框' }),
      rawStep(5, { type: 'replace_text', text: '华为手机' }, false),
      rawStep(6, { type: 'tap_element', observationId: 'query' as never, elementId: 28 }, true, { text: '搜索' }),
      rawStep(7, { type: 'finish', success: true, message: '搜索结果页已加载' }, true),
    ]

    const steps = buildSemanticAgentSteps(run(raw, 'completed'), t)
    expect(steps.flatMap(step => step.rawSteps)).toEqual(raw)
    expect(steps.at(-1)).toMatchObject({
      type: 'verification',
      title: '验证任务结果',
      description: '搜索结果页已加载',
    })
  })

  it('aggregates repeated input failures and emits a separate strategy change', () => {
    const steps = buildSemanticAgentSteps(run([
      rawStep(1, { type: 'replace_text', text: '小米手机' }, false, { role: 'text_field' }),
      rawStep(2, { type: 'replace_text', text: '小米手机' }, false, { role: 'text_field' }),
      rawStep(3, { type: 'tap_element', observationId: 'before-3' as never, elementId: 9 }, true, { text: '小米手机', role: 'control' }),
    ]), t)

    expect(steps).toHaveLength(3)
    expect(steps[0]).toMatchObject({ type: 'failure', retryCount: 2, rawSteps: [{ step: 1 }, { step: 2 }] })
    expect(steps[0]?.resultSummary).toContain('已重试 2 次')
    expect(steps[1]).toMatchObject({ type: 'strategy_change', title: '改用历史搜索' })
    expect(steps[2]?.type).toBe('action')
  })

  it('keeps structured verification behind the semantic result', () => {
    const [step] = buildSemanticAgentSteps(run([
      rawStep(1, { type: 'tap_element', observationId: 'before-1' as never, elementId: 125 }, true, { accessibilityLabel: '搜索栏' }),
    ]), t)
    expect(step?.verification).toMatchObject({
      uiHierarchyChanged: true,
      screenshotChanged: true,
      foregroundPackageChanged: false,
    })
    expect(step?.description).not.toContain('hierarchy')
  })

  it('falls back without exposing coordinates or element ids', () => {
    const [step] = buildSemanticAgentSteps(run([
      rawStep(1, { type: 'tap', x: 500, y: 300 }, true),
    ]), t)
    expect(step).toMatchObject({ title: '执行操作', description: '点击页面元素' })
    expect(`${step?.title} ${step?.description}`).not.toMatch(/500|300|element #/u)
  })

  it('uses semantic execution counts and lifecycle-aware titles', () => {
    const active = run([rawStep(1, { type: 'home' }, true)])
    expect(semanticRunTitle(active, 1, t)).toBe('Agent 正在执行')
    expect(semanticRunTitle({ ...active, status: 'completed' }, 1, t)).toBe('Agent 已完成 · 1 步')
    expect(semanticRunTitle(run([]), 0, t)).toBe('正在确定下一步…')
    expect(semanticRunTitle({ ...active, status: 'failed' }, 1, t)).toBe('Agent 遇到问题')
  })
})
