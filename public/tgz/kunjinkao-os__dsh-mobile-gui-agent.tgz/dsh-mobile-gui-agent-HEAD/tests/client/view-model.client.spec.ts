import { describe, expect, it } from 'vitest'
import type { PhoneAction, PhoneRunStep, PhoneRunView, PhoneUIElement } from '../../src/core/client.ts'
import { describePhoneAction, phoneActionOverlay, preferPhoneRunView } from '../../src/client/view-model.ts'

const element: PhoneUIElement = {
  id: 7,
  className: 'android.widget.Button',
  text: 'Wi-Fi',
  clickable: true,
  longClickable: false,
  scrollable: false,
  editable: false,
  focusable: true,
  focused: false,
  enabled: true,
  selected: false,
  password: false,
  bounds: [100, 400, 300, 480],
  fingerprint: 'wifi-button',
}

function step(action: PhoneAction): PhoneRunStep {
  return { action } as PhoneRunStep
}

describe('Phone Agent view model', () => {
  it('describes every action family without arbitrary object rendering', () => {
    expect(describePhoneAction({ type: 'tap_element', observationId: 'o1' as never, elementId: 7 })).toBe('tap element #7')
    expect(describePhoneAction({ type: 'swipe', x1: 1, y1: 2, x2: 3, y2: 4 })).toContain('→')
    expect(describePhoneAction({ type: 'input_text', text: 'hello' })).toBe('input "hello"')
    expect(describePhoneAction({ type: 'replace_text', text: 'hello' })).toBe('replace text with "hello"')
    expect(describePhoneAction({ type: 'finish', success: false, message: 'missing' })).toBe('fail: missing')
  })

  it('projects semantic element bounds into screenshot percentages', () => {
    expect(phoneActionOverlay(
      step({ type: 'tap_element', observationId: 'o1' as never, elementId: 7 }),
      [element],
      400,
      800,
    )).toEqual({ left: 25, top: 50, width: 50, height: 10 })
  })

  it('returns no overlay for absent, unresolved, or non-positional actions', () => {
    expect(phoneActionOverlay(undefined, [element], 400, 800)).toBeUndefined()
    expect(phoneActionOverlay(step({ type: 'tap_element', observationId: 'o1' as never, elementId: 99 }), [element], 400, 800)).toBeUndefined()
    expect(phoneActionOverlay(step({ type: 'home' }), [element], 400, 800)).toBeUndefined()
  })

  it('rejects late run snapshots that would remove newer steps', () => {
    const current = { id: 'run-1', startedAt: 1, updatedAt: 4, stepCount: 2, steps: [{}, {}] } as PhoneRunView
    const late = { id: 'run-1', startedAt: 1, updatedAt: 3, stepCount: 1, steps: [{}] } as PhoneRunView
    expect(preferPhoneRunView(current, late)).toBe(current)
  })

  it('accepts a newer run and a newer phase snapshot with the same timestamp', () => {
    const current = { id: 'run-1', startedAt: 1, updatedAt: 4, stepCount: 1, steps: [{}] } as PhoneRunView
    const phase = { ...current, activity: 'stabilizing' } as PhoneRunView
    const replacement = { id: 'run-2', startedAt: 5, updatedAt: 5, stepCount: 0, steps: [] } as PhoneRunView
    expect(preferPhoneRunView(current, phase)).toBe(phase)
    expect(preferPhoneRunView(current, replacement)).toBe(replacement)
  })
})
