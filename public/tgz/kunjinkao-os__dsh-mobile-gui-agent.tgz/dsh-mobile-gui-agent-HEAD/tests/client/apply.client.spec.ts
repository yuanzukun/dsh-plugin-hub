import type { SessionId } from '@deepseek-ai/dsh-client-runtime/client'
import { describe, expect, it, vi } from 'vitest'
import { MobileLauncher } from '../../src/client/MobileLauncher.tsx'
import { PhoneAgentView } from '../../src/client/PhoneAgentView.tsx'
import { apply, inject } from '../../src/client/index.ts'
import { en, zh } from '../../src/client/locales.ts'
import type { PhoneViewActions } from '../../src/client/types.ts'
import type { PhoneDeviceId } from '../../src/core/client.ts'

const SESSION_ID = 'blank-phone-session' as SessionId
const DEVICE_ID = 'emulator-5554' as PhoneDeviceId

async function bench() {
  type Entry = {
    readonly options: { readonly name: string; readonly id?: string }
    readonly component: unknown
    readonly inject?: unknown
  }
  const registered = new Map<string, Entry[]>()
  const slots = {
    inject: (_name: string, register: () => () => void) => register(),
    register: (options: Entry['options'] & { readonly inject?: unknown }, component: unknown) => {
      const entry = { options, component, inject: options.inject }
      const entries = registered.get(options.name) ?? []
      entries.push(entry)
      registered.set(options.name, entries)
      return () => {
        registered.set(options.name, (registered.get(options.name) ?? []).filter(value => value !== entry))
      }
    },
    entries: (name: string) => registered.get(name) ?? [],
  }
  const disposeRemote = vi.fn(() => Promise.resolve())
  const remote = { $mount: vi.fn(() => Promise.resolve(disposeRemote)) }
  const phoneAgent = {
    getView: vi.fn(() => Promise.resolve({ ok: true as const, value: undefined })),
    listDevices: vi.fn(() => Promise.resolve({ ok: true as const, value: [] })),
    connect: vi.fn(),
    getScreenshot: vi.fn(),
    start: vi.fn(() => Promise.resolve({ ok: true as const, value: {} as never })),
    pause: vi.fn(),
    resume: vi.fn(),
    stop: vi.fn(),
  }
  const disposeLocale = vi.fn()
  const ctx = {
    remote,
    slots,
    locale: {
      register: vi.fn(() => disposeLocale),
      bind: vi.fn(() => (key: string) => key),
    },
    get: (name: string) => name === 'remote.phoneAgent' ? phoneAgent : undefined,
  }
  return { ctx, slots, phoneAgent, disposeRemote }
}

describe('Phone Agent client plugin', () => {
  it('uses mobile_gui_agent for every visible entry label', () => {
    expect(zh['view.phone']).toBe('mobile_gui_agent')
    expect(zh['launcher.open']).toBe('mobile_gui_agent')
    expect(en['view.phone']).toBe('mobile_gui_agent')
    expect(en['launcher.open']).toBe('mobile_gui_agent')
  })

  it('declares every client service it uses', () => {
    expect(inject).toEqual(['slots', 'locale', 'remote'])
  })

  it('registers the normal view and a blank-session Mobile launcher with the same session binding', async () => {
    const b = await bench()
    const dispose = await apply(b.ctx as never)

    const view = b.slots.entries('conversation.view')[0]!
    const launcher = b.slots.entries('conversation.input.left')[0]!
    expect(view.options.id).toBe('phone-agent')
    expect(view.component).toBe(PhoneAgentView)
    expect(launcher.options.id).toBe('phone-agent-launcher')
    expect(launcher.component).toBe(MobileLauncher)

    const actions = (launcher.inject as unknown as (sessionId: SessionId) => PhoneViewActions)(SESSION_ID)
    actions.persistState({ task: '打开设置' })
    expect(actions.restoreState()).toEqual({ task: '打开设置' })
    await actions.start(DEVICE_ID, '打开设置')
    expect(b.phoneAgent.start).toHaveBeenCalledWith(SESSION_ID, {
      deviceId: DEVICE_ID,
      task: '打开设置',
    })

    await dispose()
    expect(b.slots.entries('conversation.view')).toHaveLength(0)
    expect(b.slots.entries('conversation.input.left')).toHaveLength(0)
    expect(b.disposeRemote).toHaveBeenCalledOnce()
  })
})
