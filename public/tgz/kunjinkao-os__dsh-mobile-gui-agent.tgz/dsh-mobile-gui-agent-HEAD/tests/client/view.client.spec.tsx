// @vitest-environment jsdom

import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import { afterEach, describe, expect, it, vi } from 'vitest'
import type { PhoneDeviceId, PhoneRunView } from '../../src/core/client.ts'
import { PhoneAgentView, type PhoneAgentViewProps } from '../../src/client/PhoneAgentView.tsx'
import { MobileLauncher, type MobileLauncherProps } from '../../src/client/MobileLauncher.tsx'

afterEach(cleanup)

const DEVICE_ID = 'emulator-5554' as PhoneDeviceId

function props() {
  const run = {
    id: 'run-1',
    deviceId: DEVICE_ID,
    task: '打开设置',
    status: 'running',
    stepCount: 0,
    consecutiveFailures: 0,
    startedAt: 1,
    updatedAt: 1,
    steps: [],
  } as PhoneRunView
  const start = vi.fn(() => Promise.resolve({ ok: true as const, value: run }))
  let state: ReturnType<PhoneAgentViewProps['restoreState']>
  return {
    start,
    value: {
      restoreState: () => state,
      persistState: value => { state = value },
      useProjection: () => null,
      getView: () => Promise.resolve({ ok: true as const, value: undefined }),
      listDevices: () => Promise.resolve({
        ok: true as const,
        value: [{ id: DEVICE_ID, status: 'device' as const, model: 'Pixel' }],
      }),
      connect: () => Promise.resolve({ ok: true as const, value: { id: DEVICE_ID, status: 'device' as const } }),
      screenshot: () => Promise.resolve({ ok: true as const, value: {
        data: 'iVBORw0KGgo=', width: 1080, height: 2400, timestamp: 1,
      } }),
      start,
      pause: () => Promise.resolve({ ok: true as const, value: {} as never }),
      resume: () => Promise.resolve({ ok: true as const, value: {} as never }),
      stop: () => Promise.resolve({ ok: true as const, value: {} as never }),
      t: (key: string) => key,
    } as unknown as PhoneAgentViewProps,
  }
}

describe('Phone Agent view', () => {
  it('loads a connected device and starts a natural-language task through the bound Remote action', async () => {
    const fixture = props()
    render(<PhoneAgentView {...fixture.value} />)
    await waitFor(() => { expect(screen.getByRole('option', { name: /Pixel/ })).toBeTruthy() })
    fireEvent.change(screen.getByLabelText('task.label'), { target: { value: '打开设置' } })
    fireEvent.click(screen.getByRole('button', { name: 'action.start' }))
    await waitFor(() => { expect(fixture.start).toHaveBeenCalledWith(DEVICE_ID, '打开设置') })
  })

  it('opens Mobile and starts a task without a prior chat message', async () => {
    const fixture = props()
    render(<MobileLauncher {...fixture.value as unknown as MobileLauncherProps} />)

    fireEvent.click(screen.getByRole('button', { name: 'launcher.open' }))
    await waitFor(() => { expect(screen.getByRole('dialog', { name: 'view.phone' })).toBeTruthy() })
    await waitFor(() => { expect(screen.getByRole('option', { name: /Pixel/ })).toBeTruthy() })
    fireEvent.change(screen.getByLabelText('task.label'), {
      target: { value: '打开淘宝并搜索小米手机' },
    })
    fireEvent.click(screen.getByRole('button', { name: 'action.start' }))

    await waitFor(() => {
      expect(fixture.start).toHaveBeenCalledWith(DEVICE_ID, '打开淘宝并搜索小米手机')
    })
  })

  it('restores the task and Agent steps after switching away and back', async () => {
    const fixture = props()
    const run = {
      id: 'run-restored',
      deviceId: DEVICE_ID,
      task: '打开设置并进入 WLAN',
      status: 'running',
      stepCount: 1,
      consecutiveFailures: 0,
      startedAt: 1,
      updatedAt: 2,
      activity: 'thinking',
      traceStartStep: 1,
      traceTruncated: false,
      steps: [{
        step: 1,
        action: { type: 'wait', ms: 500 },
        result: {
          actionId: 'action-1',
          executed: true,
          verification: { success: true, changed: true, evidence: ['Wi-Fi 页面已出现'] },
          stability: { stable: true, timedOut: false, samples: 3, difference: 0.001 },
          stuck: { stuck: false },
          observation: {
            foregroundPackage: 'com.android.settings',
            activity: '.Settings$WifiSettingsActivity',
            width: 1080,
            height: 2400,
            orientation: 'portrait',
          },
        },
        timestamp: 2,
        startedAt: 1,
        completedAt: 2,
      }],
    } as PhoneRunView
    fixture.value.getView = vi.fn()
      .mockResolvedValueOnce({ ok: true as const, value: run })
      .mockResolvedValue({ ok: true as const, value: undefined })

    const first = render(<PhoneAgentView {...fixture.value} />)
    await waitFor(() => {
      expect((screen.getByLabelText('task.label') as HTMLTextAreaElement).value).toBe(run.task)
      expect(screen.getByText('semantic.wait')).toBeTruthy()
      expect(screen.queryByText('Wi-Fi 页面已出现')).toBeNull()
    })
    first.unmount()

    render(<PhoneAgentView {...fixture.value} />)
    expect((screen.getByLabelText('task.label') as HTMLTextAreaElement).value).toBe(run.task)
    expect(screen.getByText('semantic.wait')).toBeTruthy()
    fireEvent.click(screen.getByText('semantic.wait'))
    fireEvent.click(screen.getAllByText('steps.technical')[0]!)
    expect(screen.getAllByText(/com.android.settings/).length).toBeGreaterThan(0)
    expect(screen.getAllByText(/"evidence":\["Wi-Fi 页面已出现"\]/).length).toBeGreaterThan(0)
  })

  it('shows an unsettled action and its current runtime phase', async () => {
    const fixture = props()
    fixture.value.getView = vi.fn().mockResolvedValue({
      ok: true as const,
      value: {
        id: 'run-pending',
        deviceId: DEVICE_ID,
        task: '发送消息',
        status: 'running',
        activity: 'awaiting_approval',
        stepCount: 0,
        consecutiveFailures: 0,
        startedAt: 1,
        updatedAt: 2,
        steps: [],
        traceStartStep: 1,
        traceTruncated: false,
        pendingStep: {
          step: 1,
          actionId: 'action-pending',
          action: { type: 'tap', x: 10, y: 20 },
          phase: 'awaiting_approval',
          startedAt: 2,
        },
      } as PhoneRunView,
    })

    render(<PhoneAgentView {...fixture.value} />)
    await waitFor(() => {
      expect(screen.getByText('activity.awaiting_approval')).toBeTruthy()
      expect(screen.queryByText(/tap \(10, 20\)/)).toBeNull()
    })
    fireEvent.click(screen.getByText('semantic.operation'))
    fireEvent.click(screen.getByText('steps.technical'))
    expect(screen.getByText(/"x":10,"y":20/)).toBeTruthy()
  })
})
