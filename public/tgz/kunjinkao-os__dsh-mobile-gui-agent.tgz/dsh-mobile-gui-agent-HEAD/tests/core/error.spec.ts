import { describe, expect, it } from 'vitest'
import { phoneAbortError } from '../../src/core/index.ts'

describe('Phone cancellation normalization', () => {
  it('normalizes an object cancellation reason without object stringification', () => {
    const controller = new AbortController()
    controller.abort({ kind: 'user' })

    expect(phoneAbortError(controller.signal, 'Phone action was cancelled')).toMatchObject({
      code: 'PHONE_ACTION_TIMEOUT',
      message: 'Phone action was cancelled (user)',
      cause: { kind: 'user' },
    })
  })

  it('preserves a useful Error reason message', () => {
    const controller = new AbortController()
    controller.abort(new Error('Stopped by user'))

    expect(phoneAbortError(controller.signal, 'Phone action was cancelled')).toMatchObject({
      code: 'PHONE_ACTION_TIMEOUT',
      message: 'Stopped by user',
    })
  })
})
