import { Context } from '@deepseek-ai/cordis'
import { describe, expect, it } from 'vitest'
import { PhoneDeviceId, PhoneDeviceRegistry } from '../../src/core/index.ts'
import type { PhoneDevice, PhoneDeviceInfo } from '../../src/core/index.ts'

class StubRegistry extends PhoneDeviceRegistry {
  list(): Promise<readonly PhoneDeviceInfo[]> {
    return Promise.resolve([{ id: PhoneDeviceId('serial-1'), status: 'device', model: 'Pixel' }])
  }

  connect(address: string): Promise<PhoneDeviceInfo> {
    return Promise.resolve({ id: PhoneDeviceId(address), status: 'device' })
  }

  open(): Promise<PhoneDevice> {
    return Promise.reject(new Error('not needed by this service registration test'))
  }
}

describe('PhoneDeviceRegistry', () => {
  it('registers one provider and preserves branded device identity', async () => {
    const ctx = new Context()
    const fiber = await ctx.plugin(StubRegistry)
    await expect(ctx.phone.list()).resolves.toEqual([
      { id: PhoneDeviceId('serial-1'), status: 'device', model: 'Pixel' },
    ])
    await expect(ctx.plugin(class SecondRegistry extends StubRegistry {}))
      .rejects.toThrow(/service "phone" has been registered/)
    await fiber.dispose()
  })
})
