import { Context } from '@deepseek-ai/cordis'
import { describe, expect, it } from 'vitest'
import { PhoneDeviceId } from '../../src/core/index.ts'
import { createFakeCapture, FakePhoneDeviceRegistry } from '../../src/testing/index.ts'

describe('FakePhoneDevice', () => {
  it('follows scripted transitions and records low-level operations', async () => {
    const ctx = new Context()
    const registry = new FakePhoneDeviceRegistry(ctx, [{
      device: { id: PhoneDeviceId('fake-1'), status: 'device' },
      initialScreen: 'home',
      screens: [
        {
          id: 'home',
          capture: createFakeCapture({ state: 'home' }),
          transitions: [{ operation: { type: 'open_app', packageName: 'com.android.settings' }, to: 'settings' }],
        },
        { id: 'settings', capture: createFakeCapture({ state: 'settings' }), transitions: [] },
      ],
    }])
    const device = await registry.open(PhoneDeviceId('fake-1'))
    const before = await device.getState()
    await device.openApp('com.android.settings')
    const after = await device.getState()
    expect(before.observation.uiSignature).not.toBe(after.observation.uiSignature)
    expect(registry.device(PhoneDeviceId('fake-1')).operations).toEqual([
      { type: 'open_app', packageName: 'com.android.settings' },
    ])
  })

  it('rejects an unscripted operation without changing state', async () => {
    const ctx = new Context()
    const registry = new FakePhoneDeviceRegistry(ctx, [{
      device: { id: PhoneDeviceId('fake-1'), status: 'device' },
      initialScreen: 'home',
      screens: [{ id: 'home', capture: createFakeCapture({ state: 'home' }), transitions: [] }],
    }])
    const device = await registry.open(PhoneDeviceId('fake-1'))
    const before = await device.getState()
    await expect(device.tap(5, 5)).rejects.toMatchObject({ code: 'PHONE_ACTION_REJECTED' })
    const after = await device.getState()
    expect(after.observation.uiSignature).toBe(before.observation.uiSignature)
  })
})
