import { describe, expect, it } from 'vitest'
import { validateArgs } from '@deepseek-ai/dsh-tools'
import { PHONE_ACTION_PARAMETERS, parsePhoneAction } from '../../src/tools/index.ts'

describe('phone_act schema', () => {
  it.each([
    { type: 'tap_element', observation_id: 'observation-1', element_id: 14 },
    { type: 'tap', x: 100, y: 200 },
    { type: 'long_press', x: 100, y: 200, duration_ms: 800 },
    { type: 'swipe', x1: 100, y1: 800, x2: 100, y2: 200, duration_ms: 300 },
    { type: 'input_text', text: 'hello world' },
    { type: 'replace_text', text: '' },
    { type: 'setup_unicode_input' },
    { type: 'press_key', key: 'enter' },
    { type: 'back' },
    { type: 'home' },
    { type: 'open_app', package_name: 'com.android.settings' },
    { type: 'wait', ms: 500 },
    { type: 'finish', success: true, message: 'Wi-Fi is on' },
  ])('accepts exactly one $type action', (action) => {
    expect(validateArgs(PHONE_ACTION_PARAMETERS, { action })).toEqual([])
    expect(parsePhoneAction(action).type).toBe(action.type)
  })

  it('parses an atomic empty replacement as a clear operation', () => {
    expect(parsePhoneAction({ type: 'replace_text', text: '' })).toEqual({ type: 'replace_text', text: '' })
  })

  it('accepts and unwraps one accidental nested action object', () => {
    const nested = { action: { action: { type: 'tap', x: 100, y: 200 } } }
    expect(validateArgs(PHONE_ACTION_PARAMETERS, nested)).toEqual([])
    expect(parsePhoneAction(nested.action)).toEqual({ type: 'tap', x: 100, y: 200 })
  })

  it.each([
    { action: {} },
    { action: { type: 'tap', x: 1.5, y: 2 } },
    { action: { type: 'tap', x: 1, y: 2, surprise: true } },
    { action: { type: 'finish', success: true, message: '' } },
    { action: { type: 'open_app', package_name: '' } },
    { action: { type: 'wait', ms: 70_000 } },
    { action: { type: 'back', x: 1 } },
    { action: { action: { action: { type: 'back' } } } },
  ])('rejects an invalid action %#', (value) => {
    const violations = validateArgs(PHONE_ACTION_PARAMETERS, value)
    if (violations.length > 0) return
    expect(() => parsePhoneAction(value.action)).toThrow()
  })
})
