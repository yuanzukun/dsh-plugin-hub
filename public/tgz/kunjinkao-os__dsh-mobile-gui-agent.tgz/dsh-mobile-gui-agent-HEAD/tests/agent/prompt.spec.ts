import { describe, expect, it } from 'vitest'
import { PHONE_AGENT_PROMPT, PHONE_TERMINAL_PROMPT } from '../../src/agent/index.ts'

describe('PHONE_AGENT_PROMPT', () => {
  it('uses installed Unicode input support without a setup-first model action', () => {
    expect(PHONE_AGENT_PROMPT).toContain('Use input_text or replace_text directly for non-ASCII text')
    expect(PHONE_AGENT_PROMPT).toContain('call setup_unicode_input once')
    expect(PHONE_AGENT_PROMPT).toContain('the helper is not installed')
    expect(PHONE_AGENT_PROMPT).not.toContain('Before entering non-ASCII text, call setup_unicode_input once')
  })
})

describe('PHONE_TERMINAL_PROMPT', () => {
  it('prevents chat text from being treated as a late native approval', () => {
    expect(PHONE_TERMINAL_PROMPT).toContain('Phone task has ended')
    expect(PHONE_TERMINAL_PROMPT).toContain('Ordinary chat text cannot approve or resume it')
    expect(PHONE_TERMINAL_PROMPT).toContain('Start a new Phone task from the Mobile view')
  })
})
