import { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { PhoneDeviceId, PhoneError, PhoneObservationId } from '../../src/core/index.ts'
import type { PhoneUIElement } from '../../src/core/index.ts'
import { PhoneActionExecutor, resolveConfig } from '../../src/agent/index.ts'
import type { PhoneApprovalRequest } from '../../src/agent/index.ts'
import { createFakeCapture, FakePhoneDevice } from '../../src/testing/index.ts'
import { describe, expect, it, vi } from 'vitest'

const row: PhoneUIElement = {
  id: 3,
  className: 'android.widget.TextView',
  text: 'Network & internet',
  clickable: true,
  longClickable: false,
  scrollable: false,
  editable: false,
  focusable: true,
  focused: false,
  enabled: true,
  selected: false,
  password: false,
  bounds: [100, 200, 900, 320],
  fingerprint: 'network-row',
}

describe('PhoneActionExecutor', () => {
  it('resolves an element id to its center and verifies the resulting state', async () => {
    const before = createFakeCapture({ state: 'settings', elements: [row] })
    const after = createFakeCapture({ state: 'network', elements: [] })
    const device = new FakePhoneDevice({
      device: { id: PhoneDeviceId('fake-1'), status: 'device' },
      initialScreen: 'settings',
      screens: [
        {
          id: 'settings',
          capture: before,
          transitions: [{ operation: { type: 'tap', x: 500, y: 260 }, to: 'network' }],
        },
        { id: 'network', capture: after, transitions: [] },
      ],
    })
    const executor = new PhoneActionExecutor(new Context(), resolveConfig({ approvalEnabled: false }))
    const result = await executor.execute(
      {} as Agent,
      device,
      before,
      { type: 'tap_element', observationId: PhoneObservationId('visible'), elementId: 3 },
      new AbortController().signal,
    )
    expect(result).toMatchObject({ executed: true, verification: { success: true, changed: true } })
    expect(device.operations).toEqual([{ type: 'tap', x: 500, y: 260 }])
  })

  it('leaves the device ledger empty when the element is absent', async () => {
    const before = createFakeCapture({ state: 'settings', elements: [] })
    const device = new FakePhoneDevice({
      device: { id: PhoneDeviceId('fake-1'), status: 'device' },
      initialScreen: 'settings',
      screens: [{ id: 'settings', capture: before, transitions: [] }],
    })
    const executor = new PhoneActionExecutor(new Context(), resolveConfig({ approvalEnabled: false }))
    const result = await executor.execute(
      {} as Agent,
      device,
      before,
      { type: 'tap_element', observationId: PhoneObservationId('visible'), elementId: 99 },
      new AbortController().signal,
    )
    expect(result).toMatchObject({ executed: false, error: { code: 'PHONE_ELEMENT_NOT_FOUND' } })
    expect(device.operations).toEqual([])
  })

  it('reports an unavailable Unicode capability as not executed', async () => {
    const before = createFakeCapture({ state: 'search', elements: [] })
    const device = new FakePhoneDevice({
      device: { id: PhoneDeviceId('fake-1'), status: 'device' },
      initialScreen: 'search',
      screens: [{
        id: 'search',
        capture: before,
        transitions: [{
          operation: { type: 'input_text', text: '中文' },
          to: 'search',
          error: new PhoneError('PHONE_UNICODE_INPUT_UNSUPPORTED', 'helper missing'),
        }],
      }],
    })
    const executor = new PhoneActionExecutor(new Context(), resolveConfig({ approvalEnabled: false }))

    const result = await executor.execute(
      {} as Agent,
      device,
      before,
      { type: 'input_text', text: '中文' },
      new AbortController().signal,
    )

    expect(result).toMatchObject({
      executed: false,
      error: { code: 'PHONE_UNICODE_INPUT_UNSUPPORTED' },
      verification: { success: false },
    })
  })

  it('requires approval for Unicode setup even when ordinary action approvals are disabled', async () => {
    const before = createFakeCapture({ state: 'search', elements: [] })
    const device = new FakePhoneDevice({
      device: { id: PhoneDeviceId('fake-1'), status: 'device' },
      initialScreen: 'search',
      screens: [{
        id: 'search',
        capture: before,
        transitions: [{ operation: { type: 'setup_unicode_input' }, to: 'search' }],
      }],
    })
    const executor = new PhoneActionExecutor(new Context(), resolveConfig({ approvalEnabled: false }))

    const result = await executor.execute(
      {} as Agent,
      device,
      before,
      { type: 'setup_unicode_input' },
      new AbortController().signal,
    )

    expect(result).toMatchObject({ executed: false, error: { code: 'PHONE_APPROVAL_DENIED' } })
    expect(device.operations).toEqual([])
  })

  it('starts the device action timeout only after a human approval settles', async () => {
    const before = createFakeCapture({ state: 'search', elements: [] })
    const device = new FakePhoneDevice({
      device: { id: PhoneDeviceId('fake-1'), status: 'device' },
      initialScreen: 'search',
      screens: [{
        id: 'search',
        capture: before,
        transitions: [{ operation: { type: 'setup_unicode_input' }, to: 'search' }],
      }],
    })
    const ctx = new Context()
    ctx.provide('approval', {
      request: ({ signal }: { readonly signal: AbortSignal }) => new Promise<'allowed-once' | 'cancelled'>(resolve => {
        const timer = setTimeout(() => resolve('allowed-once'), 25)
        signal.addEventListener('abort', () => {
          clearTimeout(timer)
          resolve('cancelled')
        }, { once: true })
      }),
    } as never)
    const executor = new PhoneActionExecutor(ctx, resolveConfig({ approvalEnabled: false, actionTimeoutMs: 5 }))

    const result = await executor.execute(
      {} as Agent,
      device,
      before,
      { type: 'setup_unicode_input' },
      new AbortController().signal,
    )

    expect(result).toMatchObject({ executed: true, verification: { success: true } })
    expect(device.operations).toEqual([{ type: 'setup_unicode_input' }])
  })

  it('publishes approval metadata before the shared approval request executes the action', async () => {
    const send = { ...row, text: 'Send' }
    const before = createFakeCapture({ state: 'draft', elements: [send] })
    const after = createFakeCapture({ state: 'sent', elements: [] })
    const device = new FakePhoneDevice({
      device: { id: PhoneDeviceId('fake-1'), status: 'device' },
      initialScreen: 'draft',
      screens: [
        {
          id: 'draft',
          capture: before,
          transitions: [{ operation: { type: 'tap', x: 500, y: 260 }, to: 'sent' }],
        },
        { id: 'sent', capture: after, transitions: [] },
      ],
    })
    const ctx = new Context()
    ctx.provide('approval', { request: () => Promise.resolve('allowed-once') } as never)
    const notice = vi.fn<(request: PhoneApprovalRequest) => void>()
    const progress = vi.fn()
    const executor = new PhoneActionExecutor(ctx, resolveConfig({ approvalEnabled: true }))
    const result = await executor.execute(
      {} as Agent,
      device,
      before,
      { type: 'tap_element', observationId: PhoneObservationId('visible'), elementId: 3 },
      new AbortController().signal,
      notice,
      progress,
    )
    expect(notice).toHaveBeenCalledOnce()
    expect(notice.mock.calls[0]?.[0].reason).toContain('send')
    expect(progress.mock.calls.map(call => call[0])).toEqual([
      'awaiting_approval',
      'executing',
      'stabilizing',
    ])
    expect(result.executed).toBe(true)
  })
})
