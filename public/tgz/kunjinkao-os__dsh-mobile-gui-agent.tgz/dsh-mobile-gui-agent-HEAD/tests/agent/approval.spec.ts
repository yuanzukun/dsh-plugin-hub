import { describe, expect, it } from 'vitest'
import { PhoneDeviceId, PhoneObservationId } from '../../src/core/index.ts'
import type { PhoneObservation, PhoneUIElement } from '../../src/core/index.ts'
import { classifyPhoneAction } from '../../src/agent/index.ts'

function button(text: string): PhoneUIElement {
  return {
    id: 1,
    className: 'android.widget.Button',
    text,
    clickable: true,
    longClickable: false,
    scrollable: false,
    editable: false,
    focusable: true,
    focused: false,
    enabled: true,
    selected: false,
    password: false,
    bounds: [100, 100, 300, 200],
    fingerprint: text,
  }
}

function observation(element: PhoneUIElement): PhoneObservation {
  return {
    id: PhoneObservationId('o'),
    deviceId: PhoneDeviceId('d'),
    timestamp: 1,
    width: 1080,
    height: 2400,
    orientation: 'portrait',
    screenshotDigest: 'x',
    screenshotSignature: 'x',
    elements: [element],
    uiSignature: 'x',
    hierarchyTruncated: false,
  }
}

describe('Phone approval classification', () => {
  it.each(['发送', 'Pay now', '删除', 'Place order', '拨打电话', 'Install APK'])('requires approval for %s', (label) => {
    const state = observation(button(label))
    expect(classifyPhoneAction({ type: 'tap_element', observationId: state.id, elementId: 1 }, state)).toBeDefined()
  })

  it('does not require approval to open settings or type a draft', () => {
    const state = observation(button('Wi-Fi'))
    expect(classifyPhoneAction({ type: 'open_app', packageName: 'com.android.settings' }, state)).toBeUndefined()
    expect(classifyPhoneAction({ type: 'input_text', text: 'draft' }, state)).toBeUndefined()
  })

  it('always requires approval before setting up Unicode input', () => {
    const state = observation(button('Search'))
    expect(classifyPhoneAction({ type: 'setup_unicode_input' }, state)).toMatchObject({
      reason: expect.stringContaining('Unicode input helper'),
      impact: expect.stringContaining('APK'),
    })
  })
})
