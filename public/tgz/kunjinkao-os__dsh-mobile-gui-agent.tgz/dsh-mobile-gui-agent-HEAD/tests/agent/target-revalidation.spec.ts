import { describe, expect, it } from 'vitest'
import { PhoneDeviceId, PhoneObservationId } from '../../src/core/index.ts'
import type { PhoneObservation, PhoneUIElement } from '../../src/core/index.ts'
import { revalidateTapElementAction } from '../../src/agent/index.ts'

function target(id: number, bounds: PhoneUIElement['bounds'] = [40, 100, 1040, 220]): PhoneUIElement {
  return {
    id,
    className: 'android.widget.Button',
    text: id === 1 ? 'Search' : 'Search updated',
    resourceId: 'com.example:id/search',
    contentDescription: 'Search',
    clickable: true,
    longClickable: false,
    scrollable: false,
    editable: false,
    focusable: true,
    focused: false,
    enabled: true,
    selected: false,
    password: false,
    bounds,
    fingerprint: `target-${id}`,
  }
}

function dynamicRecommendation(id: number): PhoneUIElement {
  return {
    ...target(id, [40, 300, 1040, 420]),
    resourceId: 'com.example:id/recommendation',
    contentDescription: 'Trending suggestion',
  }
}

function observation(id: string, elements: readonly PhoneUIElement[], state: string): PhoneObservation {
  return {
    id: PhoneObservationId(id),
    deviceId: PhoneDeviceId('fake'),
    timestamp: 1,
    width: 1080,
    height: 2400,
    orientation: 'portrait',
    screenshotDigest: state,
    screenshotSignature: state,
    foregroundPackage: 'com.example',
    activity: 'com.example/.Main',
    elements,
    uiSignature: state,
    hierarchyTruncated: false,
  }
}

describe('tap_element target revalidation', () => {
  const visible = observation('visible', [target(1), dynamicRecommendation(2)], 'screen-a')
  const action = { type: 'tap_element' as const, observationId: visible.id, elementId: 1 }

  it('rebinds an unchanged target after unrelated dynamic content changes', () => {
    const fresh = observation('fresh', [dynamicRecommendation(3), target(9)], 'screen-b')

    expect(revalidateTapElementAction(action, visible, fresh)).toMatchObject({
      action: { type: 'tap_element', observationId: fresh.id, elementId: 9 },
      target: { id: 9 },
    })
  })

  it('rejects a target that moved even when its resource identity is unchanged', () => {
    const fresh = observation('fresh', [target(9, [40, 140, 1040, 260])], 'screen-b')

    expect(revalidateTapElementAction(action, visible, fresh)).toMatchObject({
      error: { code: 'PHONE_STALE_OBSERVATION' },
    })
  })

  it('rejects an action that does not reference the last model-visible observation', () => {
    expect(revalidateTapElementAction(
      { ...action, observationId: PhoneObservationId('older') },
      visible,
      visible,
    )).toMatchObject({ error: { code: 'PHONE_STALE_OBSERVATION' } })
  })
})
