import { Context } from '@deepseek-ai/cordis'
import AgentRegistry from '@deepseek-ai/dsh-agent'
import AgentLoop from '@deepseek-ai/dsh-agent-loop'
import { AttachmentStore } from '@deepseek-ai/dsh-attachment'
import type { ImageAttachmentRef, SaveImageAttachment, StoredImageAttachment } from '@deepseek-ai/dsh-attachment'
import LlmRuntime, { createUserMessage } from '@deepseek-ai/dsh-llm'
import { PhoneDeviceId } from '../../src/core/index.ts'
import type { PhoneBounds, PhoneRunView, PhoneUIElement } from '../../src/core/index.ts'
import PhoneAgentService from '../../src/agent/index.ts'
import { createFakeCapture, FakePhoneDeviceRegistry } from '../../src/testing/index.ts'
import SessionStore, { SessionId } from '@deepseek-ai/dsh-session'
import SystemPrompt from '@deepseek-ai/dsh-system-prompt'
import ToolRuntime from '@deepseek-ai/dsh-tools'
import { describe, expect, it, vi } from 'vitest'
import { MockAdapter, textResponse, toolCallResponse } from '../support/mock-adapter.ts'

class TestAttachmentStore extends AttachmentStore {
  readonly imageLimits = {
    maxImageBytes: 1024,
    maxImagesPerMessage: 1,
    maxMessageImageBytes: 1024,
    maxImagePixels: 1_000_000,
    mediaTypes: ['image/png'] as const,
  }

  validateImage(_input: SaveImageAttachment): Promise<void> {
    return Promise.resolve()
  }

  saveImage(_input: SaveImageAttachment): Promise<ImageAttachmentRef> {
    return Promise.reject(new Error('text-only mock route must not save screenshots'))
  }

  readImage(_ref: ImageAttachmentRef): Promise<StoredImageAttachment> {
    return Promise.reject(new Error('not used'))
  }
}

function element(id: number, text: string, bounds: PhoneBounds, editable = false): PhoneUIElement {
  return {
    id,
    className: editable ? 'android.widget.EditText' : 'android.widget.TextView',
    text,
    clickable: true,
    longClickable: false,
    scrollable: false,
    editable,
    focusable: editable,
    focused: false,
    enabled: true,
    selected: false,
    password: false,
    bounds,
    fingerprint: `${id}:${text}`,
  }
}

const deviceId = PhoneDeviceId('fake-1')
const homeCapture = createFakeCapture({
  deviceId,
  state: 'home',
  foregroundPackage: 'com.android.launcher',
  activity: 'com.android.launcher/.Launcher',
})
const settingsCapture = createFakeCapture({
  deviceId,
  state: 'settings',
  foregroundPackage: 'com.android.settings',
  activity: 'com.android.settings/.Settings',
  elements: [element(1, 'Network & internet', [40, 240, 1040, 360])],
})
const networkCapture = createFakeCapture({
  deviceId,
  state: 'network',
  foregroundPackage: 'com.android.settings',
  activity: 'com.android.settings/.Settings$NetworkDashboardActivity',
  elements: [element(1, 'Wi-Fi', [40, 240, 1040, 360])],
})
const wifiCapture = createFakeCapture({
  deviceId,
  state: 'wifi',
  foregroundPackage: 'com.android.settings',
  activity: 'com.android.settings/.wifi.WifiSettings',
  elements: [element(1, 'Use Wi-Fi', [40, 240, 1040, 360])],
})
const browserCapture = createFakeCapture({
  deviceId,
  state: 'browser',
  foregroundPackage: 'com.android.chrome',
  activity: 'com.google.android.apps.chrome.Main',
  elements: [element(1, 'Search or type web address', [40, 120, 1040, 240], true)],
})
const addressCapture = createFakeCapture({
  deviceId,
  state: 'address-focused',
  foregroundPackage: 'com.android.chrome',
  activity: 'com.google.android.apps.chrome.Main',
  elements: [{ ...element(1, 'Search or type web address', [40, 120, 1040, 240], true), focused: true }],
})
const typedCapture = createFakeCapture({
  deviceId,
  state: 'hello-world',
  foregroundPackage: 'com.android.chrome',
  activity: 'com.google.android.apps.chrome.Main',
  elements: [{ ...element(1, 'hello world', [40, 120, 1040, 240], true), focused: true }],
})
const replacedCapture = createFakeCapture({
  deviceId,
  state: 'unicode-query',
  foregroundPackage: 'com.android.chrome',
  activity: 'com.google.android.apps.chrome.Main',
  elements: [{ ...element(1, '中文', [40, 120, 1040, 240], true), focused: true }],
})

class ScriptedPhoneRegistry extends FakePhoneDeviceRegistry {
  constructor(ctx: Context) {
    super(ctx, [{
      device: { id: deviceId, status: 'device', model: 'Pixel Fake' },
      initialScreen: 'home',
      screens: [
        {
          id: 'home',
          capture: homeCapture,
          transitions: [
            { operation: { type: 'open_app', packageName: 'com.android.settings' }, to: 'settings' },
            { operation: { type: 'open_app', packageName: 'com.android.chrome' }, to: 'browser' },
          ],
        },
        {
          id: 'settings',
          capture: settingsCapture,
          transitions: [{ operation: { type: 'tap', x: 540, y: 300 }, to: 'network' }],
        },
        {
          id: 'network',
          capture: networkCapture,
          transitions: [{ operation: { type: 'tap', x: 540, y: 300 }, to: 'wifi' }],
        },
        {
          id: 'wifi',
          capture: wifiCapture,
          transitions: [],
        },
        {
          id: 'browser',
          capture: browserCapture,
          transitions: [{ operation: { type: 'tap', x: 540, y: 180 }, to: 'address-focused' }],
        },
        {
          id: 'address-focused',
          capture: addressCapture,
          transitions: [
            { operation: { type: 'input_text', text: 'hello world' }, to: 'hello-world' },
            { operation: { type: 'replace_text', text: '中文' }, to: 'unicode-query' },
          ],
        },
        { id: 'hello-world', capture: typedCapture, transitions: [] },
        { id: 'unicode-query', capture: replacedCapture, transitions: [] },
      ],
    }])
  }
}

async function createPhoneLoop(adapter: MockAdapter, sessionId: string): Promise<{
  readonly ctx: Context
  readonly agent: ReturnType<Context['agentLoop']['create']>
  readonly registry: ScriptedPhoneRegistry
  readonly eventTypes: string[]
  readonly terminalViews: PhoneRunView[]
}> {
  const ctx = new Context()
  await ctx.plugin(LlmRuntime)
  await ctx.plugin(SessionStore)
  await ctx.plugin(SystemPrompt)
  await ctx.plugin(ToolRuntime)
  await ctx.plugin(AgentRegistry)
  await ctx.plugin(TestAttachmentStore)
  await ctx.plugin(ScriptedPhoneRegistry)
  await ctx.plugin(PhoneAgentService, { approvalEnabled: false, stableSamples: 1 })
  await ctx.plugin(AgentLoop, { agents: [] })
  ctx.llm.registerAdapter(['mock'], adapter)
  const eventTypes: string[] = []
  const terminalViews: PhoneRunView[] = []
  ctx.on('phone/action/completed', () => { eventTypes.push('phone/action/completed') })
  ctx.on('phone/action/failed', () => { eventTypes.push('phone/action/failed') })
  ctx.on('phone/task/completed', ({ run }) => {
    eventTypes.push('phone/task/completed')
    terminalViews.push(run)
  })
  ctx.on('phone/task/failed', ({ run }) => {
    eventTypes.push('phone/task/failed')
    terminalViews.push(run)
  })
  return {
    ctx,
    agent: ctx.agentLoop.create(SessionId(sessionId), { provider: 'mock', model: 'mock' }),
    registry: ctx.phone as ScriptedPhoneRegistry,
    eventTypes,
    terminalViews,
  }
}

describe('Phone Agent through the existing Agent loop', () => {
  it('observes, executes one action, verifies, re-observes, and finishes', async () => {
    const adapter = new MockAdapter([
      toolCallResponse('phone-1', 'phone_act', {
        action: { type: 'open_app', package_name: 'com.android.settings' },
      }),
      toolCallResponse('phone-2', 'phone_act', {
        action: { type: 'finish', success: true, message: 'Android Settings is open.' },
      }),
    ])
    const { ctx, agent, registry, eventTypes } = await createPhoneLoop(adapter, 'phone-loop')

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Open Android Settings' })
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(2)
    expect(adapter.requests[0]?.system).toContain('You control an Android phone.')
    expect(adapter.requests[0]?.tools?.map(tool => tool.name).sort()).toEqual(['phone_act', 'phone_observe'])
    expect(registry.device(deviceId).operations).toEqual([
      { type: 'open_app', packageName: 'com.android.settings' },
    ])
    expect(eventTypes.filter(type => type === 'phone/action/completed')).toHaveLength(2)
    expect(eventTypes).toContain('phone/task/completed')
    expect(eventTypes).not.toContain('phone/action/failed')
    const terminal = ctx.phoneRuns.getView(agent)
    expect(terminal).toMatchObject({
      status: 'completed',
      activity: 'finished',
      traceStartStep: 1,
      traceTruncated: false,
    })
    expect(terminal?.pendingStep).toBeUndefined()
    expect(terminal?.steps.every(step => step.completedAt >= step.startedAt)).toBe(true)
  })

  it('opens Settings and reaches Wi-Fi through fresh semantic observations', async () => {
    const adapter = new MockAdapter([
      toolCallResponse('wifi-open-settings', 'phone_act', {
        action: { type: 'open_app', package_name: 'com.android.settings' },
      }),
      toolCallResponse('wifi-network', 'phone_act', {
        action: { type: 'tap_element', observation_id: settingsCapture.observation.id, element_id: 1 },
      }),
      toolCallResponse('wifi-page', 'phone_act', {
        action: { type: 'tap_element', observation_id: networkCapture.observation.id, element_id: 1 },
      }),
      toolCallResponse('wifi-finish', 'phone_act', {
        action: { type: 'finish', success: true, message: 'Wi-Fi settings is open.' },
      }),
    ])
    const { ctx, agent, registry, eventTypes } = await createPhoneLoop(adapter, 'phone-loop-wifi')

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Open Settings and go to Wi-Fi' })
    await agent.whenIdle()

    expect(registry.device(deviceId).operations).toEqual([
      { type: 'open_app', packageName: 'com.android.settings' },
      { type: 'tap', x: 540, y: 300 },
      { type: 'tap', x: 540, y: 300 },
    ])
    expect(eventTypes).toContain('phone/task/completed')
    const trace = ctx.phoneRuns.getView(agent)?.steps
    expect(trace?.[1]?.context).toMatchObject({
      before: {
        observationId: settingsCapture.observation.id,
        foregroundPackage: 'com.android.settings',
      },
      target: { elementId: 1, text: 'Network & internet', role: 'control' },
    })
    expect(trace?.[1]?.result.verification.facts).toMatchObject({
      uiHierarchyChanged: true,
      screenshotChanged: true,
    })
  })

  it('opens a browser and focuses its address field', async () => {
    const adapter = new MockAdapter([
      toolCallResponse('browser-open', 'phone_act', {
        action: { type: 'open_app', package_name: 'com.android.chrome' },
      }),
      toolCallResponse('browser-address', 'phone_act', {
        action: { type: 'tap_element', observation_id: browserCapture.observation.id, element_id: 1 },
      }),
      toolCallResponse('browser-finish', 'phone_act', {
        action: { type: 'finish', success: true, message: 'The address field is focused.' },
      }),
    ])
    const { ctx, agent, registry, eventTypes } = await createPhoneLoop(adapter, 'phone-loop-browser')
    const device = registry.device(deviceId)
    const getState = device.getState.bind(device)
    let browserReads = 0
    vi.spyOn(device, 'getState').mockImplementation(async () => {
      const capture = await getState()
      if (capture !== browserCapture || ++browserReads !== 2) return capture
      return createFakeCapture({
        deviceId,
        state: 'browser-with-rotated-suggestions',
        foregroundPackage: 'com.android.chrome',
        activity: 'com.google.android.apps.chrome.Main',
        elements: [
          element(7, 'Trending now', [40, 300, 1040, 420]),
          { ...browserCapture.observation.elements[0]!, id: 9 },
        ],
      })
    })

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Open the browser and focus the address bar' })
    await agent.whenIdle()

    expect(registry.device(deviceId).operations).toEqual([
      { type: 'open_app', packageName: 'com.android.chrome' },
      { type: 'tap', x: 540, y: 180 },
    ])
    expect(eventTypes).toContain('phone/task/completed')
  })

  it('types hello world only after focusing a text field', async () => {
    const adapter = new MockAdapter([
      toolCallResponse('text-open', 'phone_act', {
        action: { type: 'open_app', package_name: 'com.android.chrome' },
      }),
      toolCallResponse('text-focus', 'phone_act', {
        action: { type: 'tap_element', observation_id: browserCapture.observation.id, element_id: 1 },
      }),
      toolCallResponse('text-input', 'phone_act', {
        action: { type: 'input_text', text: 'hello world' },
      }),
      toolCallResponse('text-finish', 'phone_act', {
        action: { type: 'finish', success: true, message: 'hello world is entered.' },
      }),
    ])
    const { ctx, agent, registry, eventTypes } = await createPhoneLoop(adapter, 'phone-loop-input')

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Type hello world in the browser address field' })
    await agent.whenIdle()

    expect(registry.device(deviceId).operations).toEqual([
      { type: 'open_app', packageName: 'com.android.chrome' },
      { type: 'tap', x: 540, y: 180 },
      { type: 'input_text', text: 'hello world' },
    ])
    expect(eventTypes).toContain('phone/task/completed')
  })

  it('replaces focused text atomically through the model action schema', async () => {
    const adapter = new MockAdapter([
      toolCallResponse('replace-open', 'phone_act', {
        action: { type: 'open_app', package_name: 'com.android.chrome' },
      }),
      toolCallResponse('replace-focus', 'phone_act', {
        action: { type: 'tap_element', observation_id: browserCapture.observation.id, element_id: 1 },
      }),
      toolCallResponse('replace-text', 'phone_act', {
        action: { type: 'replace_text', text: '中文' },
      }),
      toolCallResponse('replace-finish', 'phone_act', {
        action: { type: 'finish', success: true, message: 'The field contains the requested query.' },
      }),
    ])
    const { ctx, agent, registry, eventTypes } = await createPhoneLoop(adapter, 'phone-loop-replace')

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Replace the browser query with Chinese text' })
    await agent.whenIdle()

    expect(registry.device(deviceId).operations).toEqual([
      { type: 'open_app', packageName: 'com.android.chrome' },
      { type: 'tap', x: 540, y: 180 },
      { type: 'replace_text', text: '中文' },
    ])
    expect(eventTypes).toContain('phone/task/completed')
    expect(eventTypes).not.toContain('phone/action/failed')
  })

  it('re-observes after a nonexistent element and reports the task blocked without a device action', async () => {
    const visible = homeCapture
    const adapter = new MockAdapter([
      toolCallResponse('phone-missing', 'phone_act', {
        action: {
          type: 'tap_element',
          observation_id: visible.observation.id,
          element_id: 999,
        },
      }),
      toolCallResponse('phone-reobserve', 'phone_observe', {}),
      toolCallResponse('phone-blocked', 'phone_act', {
        action: { type: 'finish', success: false, message: 'The requested button is not present.' },
      }),
    ])
    const { ctx, agent, registry, eventTypes, terminalViews } = await createPhoneLoop(adapter, 'phone-loop-missing')

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Tap the button that does not exist' })
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(3)
    expect(registry.device(deviceId).operations).toEqual([])
    expect(eventTypes.filter(type => type === 'phone/action/failed')).toHaveLength(1)
    expect(eventTypes).toContain('phone/task/failed')
    expect(terminalViews.at(-1)?.message).toBe('The requested button is not present.')
  })

  it('handles stale Phone tool calls safely after a terminal run', async () => {
    const adapter = new MockAdapter([
      toolCallResponse('terminal-finish', 'phone_act', {
        action: { type: 'finish', success: false, message: 'Native approval expired.' },
      }),
      toolCallResponse('stale-phone-action', 'phone_act', {
        action: { type: 'tap', x: 100, y: 200 },
      }),
      textResponse('The previous Phone task has ended. Start a new task from Mobile.'),
      toolCallResponse('new-run-finish', 'phone_act', {
        action: { type: 'finish', success: true, message: 'The new Phone task is active.' },
      }),
    ])
    const { ctx, agent, registry } = await createPhoneLoop(adapter, 'phone-loop-terminal-guard')

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Tap after approval' })
    await agent.whenIdle()
    await new Promise<void>(resolve => { setTimeout(resolve, 0) })
    agent.followup(createUserMessage({
      source: { kind: 'user' },
      content: [{ type: 'text', text: '我批准' }],
    }))
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(3)
    expect(adapter.requests[1]?.tools?.map(tool => tool.name).sort()).toEqual(['phone_act', 'phone_observe'])
    expect(adapter.requests[1]?.system).toContain('Ordinary chat text cannot approve or resume it')
    expect(JSON.stringify(adapter.requests[2]?.messages)).toContain('PHONE_RUN_NOT_ACTIVE')
    expect(JSON.stringify(adapter.requests[2]?.messages)).not.toContain('unknown tool')
    expect(registry.device(deviceId).operations).toEqual([])

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Start a fresh Phone task' })
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(4)
    expect(adapter.requests[3]?.system).toContain('You control an Android phone.')
    expect(adapter.requests[3]?.system).not.toContain('Ordinary chat text cannot approve or resume it')
    expect(adapter.requests[3]?.tools?.find(tool => tool.name === 'phone_act')?.description)
      .toContain('Execute exactly one Android action')
  })

  it('releases the device when the owning Agent turn is cancelled before finish', async () => {
    const adapter = new MockAdapter([
      toolCallResponse('cancel-open', 'phone_act', {
        action: { type: 'open_app', package_name: 'com.android.settings' },
      }),
      'hang',
      toolCallResponse('after-cancel-finish', 'phone_act', {
        action: { type: 'finish', success: true, message: 'The replacement run completed.' },
      }),
    ])
    const { ctx, agent, eventTypes, terminalViews } = await createPhoneLoop(adapter, 'phone-loop-cancel-release')

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Open Settings, then wait' })
    await vi.waitFor(() => { expect(adapter.requests).toHaveLength(2) })
    agent.cancel({ kind: 'user' })
    await agent.whenIdle()

    expect(ctx.phoneRuns.getView(agent)).toMatchObject({
      status: 'stopped',
      message: 'Agent turn ended before the Phone task called finish',
    })
    expect(eventTypes).toContain('phone/task/failed')
    expect(terminalViews.at(-1)?.status).toBe('stopped')

    await ctx.phoneRuns.start(agent, { deviceId, task: 'Start again on the same device' })
    await agent.whenIdle()

    expect(adapter.requests).toHaveLength(3)
    expect(ctx.phoneRuns.getView(agent)?.status).toBe('completed')
  })
})
