import { describe, expect, it } from 'vitest'
import { serializePhoneActionResult } from '../../src/agent/index.ts'
import { PhoneActionId } from '../../src/core/index.ts'
import type { PhoneActionResult } from '../../src/core/index.ts'

describe('serializePhoneActionResult', () => {
  it('labels a settle deadline as non-fatal when the action was verified', () => {
    const result: PhoneActionResult = {
      actionId: PhoneActionId('action-1'),
      action: { type: 'tap', x: 10, y: 20 },
      executed: true,
      verification: { success: true, changed: true, evidence: ['screenshot changed'] },
      stability: { stable: false, timedOut: true, samples: 4, difference: 0.2 },
      stuck: { stuck: false },
      observation: {} as PhoneActionResult['observation'],
    }

    const text = serializePhoneActionResult(result, 'next observation')

    expect(text).toContain('Settle: deadline reached (non-fatal); samples: 4')
    expect(text).not.toContain('timeout: true')
  })
})
