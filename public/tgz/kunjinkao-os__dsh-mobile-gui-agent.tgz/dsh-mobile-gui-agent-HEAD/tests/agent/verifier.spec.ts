import { describe, expect, it } from 'vitest'
import { PhoneObservationId, PhoneDeviceId } from '../../src/core/index.ts'
import type { PhoneObservation, PhoneUIElement } from '../../src/core/index.ts'
import { verifyPhoneAction } from '../../src/agent/index.ts'

const toggle: PhoneUIElement = {
  id: 1,
  className: 'android.widget.Switch',
  text: 'Wi-Fi',
  clickable: true,
  longClickable: false,
  scrollable: false,
  editable: false,
  focusable: true,
  focused: false,
  enabled: true,
  selected: false,
  checked: false,
  password: false,
  bounds: [800, 100, 1000, 200],
  fingerprint: 'wifi-toggle',
}

function focusedField(text: string): PhoneUIElement {
  return {
    id: 4,
    className: 'android.widget.EditText',
    text,
    resourceId: 'com.example:id/search',
    contentDescription: 'Search',
    clickable: true,
    longClickable: true,
    scrollable: false,
    editable: true,
    focusable: true,
    focused: true,
    enabled: true,
    selected: false,
    password: false,
    bounds: [40, 100, 1040, 220],
    fingerprint: `search:${text}`,
  }
}

function observation(overrides: Partial<PhoneObservation> = {}): PhoneObservation {
  return {
    id: PhoneObservationId('observation'),
    deviceId: PhoneDeviceId('fake'),
    timestamp: 1,
    width: 1080,
    height: 2400,
    orientation: 'portrait',
    screenshotDigest: 'image',
    screenshotSignature: 'screen-a',
    foregroundPackage: 'com.android.settings',
    activity: 'com.android.settings/.Settings',
    elements: [toggle],
    uiSignature: 'ui-a',
    hierarchyTruncated: false,
    ...overrides,
  }
}

describe('verifyPhoneAction', () => {
  it('verifies successful Unicode helper setup without relying on screen animation', () => {
    const before = observation()
    expect(verifyPhoneAction(before, { type: 'setup_unicode_input' }, before)).toMatchObject({
      success: true,
      changed: false,
      evidence: [expect.stringContaining('restored')],
    })
  })

  it('verifies a switch from its semantic checked transition', () => {
    const afterToggle = { ...toggle, checked: true }
    const result = verifyPhoneAction(
      observation(),
      { type: 'tap_element', observationId: PhoneObservationId('observation'), elementId: 1 },
      observation({ elements: [afterToggle], uiSignature: 'ui-b', screenshotSignature: 'screen-b' }),
      toggle,
    )
    expect(result).toMatchObject({ success: true, changed: true })
    expect(result.evidence).toContain('target checked changed from false to true')
  })

  it('does not assume an unchanged tap succeeded', () => {
    expect(verifyPhoneAction(observation(), { type: 'tap', x: 10, y: 10 }, observation()))
      .toMatchObject({ success: false, changed: false })
  })

  it('verifies open_app against the actual foreground package', () => {
    expect(verifyPhoneAction(
      observation(),
      { type: 'open_app', packageName: 'com.android.chrome' },
      observation({ foregroundPackage: 'com.android.chrome', activity: 'com.android.chrome/.Main', uiSignature: 'chrome' }),
    )).toMatchObject({ success: true })
  })

  it('does not verify Delete from an unrelated screenshot animation', () => {
    const field = focusedField('query')
    const result = verifyPhoneAction(
      observation({ elements: [field] }),
      { type: 'press_key', key: 'delete' },
      observation({ elements: [{ ...field }], screenshotSignature: 'animated-screen' }),
    )

    expect(result).toMatchObject({ success: false, changed: true })
    expect(result.evidence).toContain('focused editable text did not become shorter')
  })

  it('verifies Delete only when the focused editable text becomes shorter', () => {
    const result = verifyPhoneAction(
      observation({ elements: [focusedField('query')] }),
      { type: 'press_key', key: 'delete' },
      observation({ elements: [focusedField('quer')], uiSignature: 'text-shorter' }),
    )

    expect(result).toMatchObject({ success: true, changed: true })
    expect(result.evidence).toContain('focused editable text length changed from 5 to 4')
  })

  it('does not verify input_text from suggestion animation without a field change', () => {
    const field = focusedField('query')
    expect(verifyPhoneAction(
      observation({ elements: [field] }),
      { type: 'input_text', text: '中文' },
      observation({ elements: [{ ...field }], screenshotSignature: 'suggestions-rotated' }),
    )).toMatchObject({ success: false, changed: true })
  })

  it('verifies replace_text against the resulting focused field value', () => {
    expect(verifyPhoneAction(
      observation({ elements: [focusedField('old')] }),
      { type: 'replace_text', text: '中文' },
      observation({ elements: [focusedField('中文')], uiSignature: 'replaced' }),
    )).toMatchObject({ success: true, changed: true })
  })
})
