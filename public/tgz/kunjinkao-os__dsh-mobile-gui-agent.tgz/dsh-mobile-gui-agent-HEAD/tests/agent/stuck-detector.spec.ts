import { describe, expect, it } from 'vitest'
import { PhoneStuckDetector } from '../../src/agent/index.ts'

describe('PhoneStuckDetector', () => {
  it('detects an identical action repeated on one unchanged screen', () => {
    const detector = new PhoneStuckDetector()
    for (let index = 0; index < 2; index++) {
      expect(detector.record({ action: { type: 'tap', x: 10, y: 20 }, before: 'a', after: 'a', success: false }).stuck).toBe(false)
    }
    expect(detector.record({ action: { type: 'tap', x: 10, y: 20 }, before: 'a', after: 'a', success: false }))
      .toEqual({ stuck: true, reason: 'repeated-action', recovery: 'choose-another-element' })
  })

  it('detects a bounded two-state cycle', () => {
    const detector = new PhoneStuckDetector()
    detector.record({ action: { type: 'back' }, before: 'b', after: 'a', success: true })
    detector.record({ action: { type: 'home' }, before: 'a', after: 'b', success: true })
    detector.record({ action: { type: 'back' }, before: 'b', after: 'a', success: true })
    expect(detector.record({ action: { type: 'home' }, before: 'a', after: 'b', success: true }))
      .toEqual({ stuck: true, reason: 'state-cycle', recovery: 'back' })
  })
})
