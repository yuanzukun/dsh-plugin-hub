# Blank-Session Mobile Entry Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let a user open the Mobile task surface and start a phone task from a blank Harness conversation without first sending an unrelated chat message.

**Architecture:** Keep the existing `conversation.view` Mobile tab for nonblank sessions, and add a second, additive entry in the always-rendered `conversation.input.left` composer toolbar. The new launcher opens the same `PhoneAgentView` inside the standard Harness `Modal`, using the current blank session's `SessionId` to bind the existing Remote actions; starting a phone run naturally opens the first Agent turn, after which the normal Mobile tab is also visible.

**Tech Stack:** React 18, DeepSeek Harness client slots, Harness UI primitives, Typert Remote client, Vitest, Testing Library, CSS Modules.

## Global Constraints

- Make all product changes in `dsh-mobile-gui-agent/`; do not patch the Harness checkout.
- Preserve the existing `conversation.view` registration and Phone Remote protocol.
- Use only additive public Harness slots; do not replace the Hero, composer, or session shell.
- The launcher must not send a synthetic chat message or touch a phone until the user clicks Start.
- Do not commit, push, tag, or publish without separate user authorization.

---

### Task 1: Pin the blank-session user flow with client tests

**Files:**
- Modify: `tests/client/view.client.spec.tsx`
- Create: `tests/client/apply.client.spec.ts`

**Interfaces:**
- Consumes: `PhoneViewActions`, the `phone-agent` locale dictionary, and the existing generated `phoneAgent` Remote namespace.
- Produces: regression coverage proving that `MobileLauncher` opens a task-capable Mobile surface and that `apply()` registers both client entries.

- [ ] **Step 1: Write the failing launcher test**

Add a test that renders the launcher with the existing fake Phone actions, clicks the localized launcher button, enters `打开淘宝并搜索小米手机`, and verifies that `start(DEVICE_ID, task)` is called without any conversation composer submission:

```tsx
it('opens Mobile and starts a task without a prior chat message', async () => {
  const fixture = props()
  render(<MobileLauncher {...fixture.value} />)
  fireEvent.click(screen.getByRole('button', { name: 'launcher.open' }))
  await waitFor(() => { expect(screen.getByRole('dialog', { name: 'view.phone' })).toBeTruthy() })
  fireEvent.change(screen.getByLabelText('task.label'), {
    target: { value: '打开淘宝并搜索小米手机' },
  })
  fireEvent.click(screen.getByRole('button', { name: 'action.start' }))
  await waitFor(() => {
    expect(fixture.start).toHaveBeenCalledWith(DEVICE_ID, '打开淘宝并搜索小米手机')
  })
})
```

- [ ] **Step 2: Write the failing slot-registration test**

Build a real `SlotRegistry` fixture with both public holes, mount the plugin with a fake `$mount` and `remote.phoneAgent`, then assert the two entries and their shared per-session binding:

```ts
expect(slots.entries('conversation.view')[0]?.options.id).toBe('phone-agent')
expect(slots.entries('conversation.input.left')[0]?.options.id).toBe('phone-agent-launcher')

const injected = launcher.inject!(SESSION_ID)
await injected.start(DEVICE_ID, '打开设置')
expect(phoneAgent.start).toHaveBeenCalledWith(SESSION_ID, {
  deviceId: DEVICE_ID,
  task: '打开设置',
})
```

- [ ] **Step 3: Run the tests and verify they fail for the missing launcher**

Run:

```bash
pnpm exec vitest run tests/client/view.client.spec.tsx tests/client/apply.client.spec.ts
```

Expected: failure because `MobileLauncher` and the `conversation.input.left` registration do not exist.

### Task 2: Add the additive Mobile launcher

**Files:**
- Create: `src/client/MobileLauncher.tsx`
- Create: `src/client/MobileLauncher.module.css`
- Modify: `src/client/PhoneAgentView.tsx`
- Modify: `src/client/index.ts`
- Modify: `src/client/locales.ts`

**Interfaces:**
- Consumes: `PhoneViewActions`, `PropsRuntime<'conversation.input.left'>`, `PropsLocale<'phone-agent'>`, `Button`, and `Modal`.
- Produces: `MobileLauncher`, `MobileLauncherProps`, and a shared `PhoneAgentPanelProps` accepted by the existing view and the modal launcher.

- [ ] **Step 1: Extract the reusable Phone panel props**

In `PhoneAgentView.tsx`, keep the registered view type while allowing the panel to render outside `conversation.view`:

```ts
export type PhoneAgentPanelProps = InjectFace<PhoneViewActions> & PropsLocale<'phone-agent'>
export type PhoneAgentViewProps = ConvViewProps & PhoneAgentPanelProps

export function PhoneAgentView({
  getView, listDevices, connect, screenshot, start, pause, resume, stop, t,
}: PhoneAgentPanelProps) {
  // Keep the current state, effects, callbacks, and rendered panel body after this signature.
}
```

- [ ] **Step 2: Implement the launcher and modal**

Create `MobileLauncher.tsx`:

```tsx
import { useState } from 'react'
import { Button, Modal } from '@deepseek-ai/dsh-client-ui-primitives'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import { PhoneAgentView, type PhoneAgentPanelProps } from './PhoneAgentView.tsx'
import type { PhoneViewActions } from './types.ts'
import css from './MobileLauncher.module.css'

export type MobileLauncherProps =
  PropsRuntime<'conversation.input.left'>
  & PhoneAgentPanelProps

export function MobileLauncher(props: MobileLauncherProps) {
  const [open, setOpen] = useState(false)
  const { t } = props
  return (
    <>
      <Button size="sm" variant="toolbar" onClick={() => { setOpen(true) }}>
        {t('launcher.open')}
      </Button>
      <Modal
        open={open}
        onClose={() => { setOpen(false) }}
        title={t('view.phone')}
        closeLabel={t('launcher.close')}
        className={css.dialog}
      >
        <div className={css.panel}>
          <PhoneAgentView {...props} />
        </div>
      </Modal>
    </>
  )
}
```

Style the modal as a bounded desktop work surface with a responsive single-column fallback:

```css
.dialog {
  width: min(1200px, calc(100vw - 32px));
  max-height: calc(100vh - 32px);
  padding-bottom: 0;
}

.panel {
  width: 100%;
  height: min(760px, calc(100vh - 140px));
  min-height: 420px;
  overflow: hidden;
}
```

- [ ] **Step 3: Register both session surfaces with the same action binder**

In `src/client/index.ts`, extract one session action binder and inject both public slots:

```ts
const bindActions = (sessionId: SessionId): PhoneViewActions => ({
  getView: () => phoneAgent.getView(sessionId),
  listDevices: () => phoneAgent.listDevices(),
  connect: address => phoneAgent.connect(address),
  screenshot: deviceId => phoneAgent.getScreenshot(sessionId, deviceId),
  start: (deviceId, task) => phoneAgent.start(sessionId, { deviceId, task }),
  pause: () => phoneAgent.pause(sessionId),
  resume: () => phoneAgent.resume(sessionId),
  stop: () => phoneAgent.stop(sessionId),
})

const disposeView = ctx.slots.inject('conversation.view', () => ctx.slots.register({
  name: 'conversation.view', id: 'phone-agent', order: 20, locale: NS,
  label: () => t('view.phone'), inject: bindActions,
}, PhoneAgentView))

const disposeLauncher = ctx.slots.inject('conversation.input.left', () => ctx.slots.register({
  name: 'conversation.input.left', id: 'phone-agent-launcher', order: 20,
  locale: NS, inject: bindActions,
}, MobileLauncher))
```

Dispose both registrations before locale and Remote teardown.

- [ ] **Step 4: Add localized launcher copy**

Add matching dictionary keys:

```ts
'launcher.open': '移动端',
'launcher.close': '关闭移动端',
```

and:

```ts
'launcher.open': 'Mobile',
'launcher.close': 'Close Mobile',
```

- [ ] **Step 5: Run the focused client tests**

Run:

```bash
pnpm exec vitest run tests/client/view.client.spec.tsx tests/client/apply.client.spec.ts
```

Expected: both test files pass; opening the launcher performs no Remote mutation until Start is clicked.

### Task 3: Document and validate the blank-session entry

**Files:**
- Modify: `README.md`
- Modify: `docs/README.zh.md`
- Modify: `lib/**` through the repository build

**Interfaces:**
- Consumes: the final client behavior from Task 2.
- Produces: accurate user instructions, rebuilt package output, and a verified local development runtime.

- [ ] **Step 1: Replace the nonblank-session workaround in both READMEs**

Document the two supported paths exactly:

```text
In a blank conversation, select Mobile in the composer toolbar to open the task dialog immediately. After the task starts, the regular Mobile conversation tab is also available.
```

```text
在空白新会话中，点击输入框工具栏里的“移动端”即可直接打开任务面板；任务开始后也可以继续使用常规“移动端”会话标签页。
```

Remove instructions that require sending an unrelated prompt first.

- [ ] **Step 2: Run focused and full verification**

Run:

```bash
pnpm exec vitest run tests/client/view.client.spec.tsx tests/client/apply.client.spec.ts
pnpm run check
pnpm pack
```

Expected: all client tests and the complete check pass, package verification succeeds, and the tarball contains the new launcher source plus rebuilt `lib/client.js` and declarations.

- [ ] **Step 3: Reload the local development Harness**

Run:

```bash
MOBILE_DEV_NO_OPEN=1 ../mobile-dev
../mobile-dev status
```

Expected: Harness is ready on `http://127.0.0.1:3081`, with the linked local plugin rebuilt and restarted. Verify only the Web UI entry unless the user separately authorizes a real phone action.

- [ ] **Step 4: Commit only with explicit authorization**

If the user authorizes a commit, use the repository's atomic-commit workflow and stage only the implementation, tests, documentation, plan, and rebuilt artifacts for this feature. Do not push, tag, or publish without separate authorization.
