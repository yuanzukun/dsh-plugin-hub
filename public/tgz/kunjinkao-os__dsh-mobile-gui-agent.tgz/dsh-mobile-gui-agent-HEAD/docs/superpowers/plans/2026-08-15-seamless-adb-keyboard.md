# Seamless ADB Keyboard Implementation Plan

> **For agentic workers:** Implement inline in this session. Do not delegate, commit, push, tag, publish, install an APK, switch a real device IME, or enter real-device text unless the user separately authorizes that operation.

**Goal:** Make non-ASCII `input_text` and `replace_text` use an already-installed ADB Keyboard automatically, restore the user's original IME after every operation, and stop non-fatal settle deadlines from looking like action failures.

**Architecture:** Determine installation with Android's all-IME query (`ime list -a -s`) and determine enabled/selected state separately. The ADB provider owns the temporary enable/select/broadcast/restore transaction, so the model issues only the requested text action; `setup_unicode_input` remains a fallback only when the helper is truly absent and a reviewed APK path is configured. Preserve the existing strict action schema compatibility and foreground inference fixes already present in the dirty worktree.

**Tech Stack:** TypeScript, direct-argv ADB, Harness/Cordis tools and approvals, Vitest, pnpm.

## Global Constraints

- Preserve the user's current IME and its enabled state after every successful, failed, or cancelled Unicode operation.
- Never auto-install an APK without the existing Harness approval flow.
- Never accept an APK path from model-authored tool arguments.
- Preserve public `PhoneDevice`, `phone_observe`, and `phone_act` protocol names.
- Keep generated tracked `lib/` output synchronized with `src/`.
- Do not commit, push, tag, publish, or mutate the connected real device in this task.

---

### Task 1: Correct IME discovery and transparent use

**Files:**

- Modify: `src/adb/adb-device.ts`
- Test: `tests/adb/adb-device.spec.ts`

**Interfaces:**

- Consumes: `adbKeyboardAvailability(installed, enabled, selected)` and the existing `ADB_KEYBOARD` protocol constants.
- Produces: non-ASCII `inputText(text, signal)` and `replaceText(text, signal)` that transparently use any installed helper without a preceding model setup action.

- [x] **Step 1: Make the fake ADB client distinguish all installed IMEs from enabled IMEs**

```ts
if (command === 'ime list -a -s') return Promise.resolve({ stdout: this.installed, stderr: '' })
if (command === 'settings get secure enabled_input_methods') return Promise.resolve({ stdout: this.enabled, stderr: '' })
```

- [x] **Step 2: Add a regression test for an installed, enabled, non-selected helper**

```ts
it('temporarily selects an installed helper without an explicit setup action', async () => {
  const previous = 'com.example/.UserIme'
  const client = new InputAdbClient(ADB_KEYBOARD, `${previous}:${ADB_KEYBOARD}`, previous)

  await createDevice(client).inputText('中文')

  expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'set', ADB_KEYBOARD])
  expect(client.calls).toContainEqual([
    '-s', 'fake', 'shell', 'am', 'broadcast',
    '-a', 'ADB_INPUT_B64', '-p', 'com.android.adbkeyboard', '--es', 'msg', '5Lit5paH',
  ])
  expect(client.inputMethodState()).toEqual({ enabled: `${previous}:${ADB_KEYBOARD}`, selected: previous })
})
```

- [x] **Step 3: Add a regression test for an installed but disabled helper**

```ts
it('temporarily enables and selects an installed disabled helper, then restores both settings', async () => {
  const previous = 'com.example/.UserIme'
  const client = new InputAdbClient(ADB_KEYBOARD, previous, previous)

  await createDevice(client).inputText('中文')

  expect(client.calls).toContainEqual(['-s', 'fake', 'shell', 'ime', 'enable', ADB_KEYBOARD])
  expect(client.inputMethodState()).toEqual({ enabled: previous, selected: previous })
})
```

- [x] **Step 4: Run the focused test and verify the old explicit-setup gate fails**

Run: `pnpm exec vitest run tests/adb/adb-device.spec.ts`

Expected before implementation: the Unicode calls reject with `PHONE_UNICODE_INPUT_UNSUPPORTED` because `unicodeInputSetup` is false.

- [x] **Step 5: Query all installed IMEs and remove the per-device setup gate**

```ts
const [installed, enabled, selected] = await Promise.all([
  this.runShell(['ime', 'list', '-a', '-s'], signal),
  this.runShell(['settings', 'get', 'secure', 'enabled_input_methods'], signal),
  this.runShell(['settings', 'get', 'secure', 'default_input_method'], signal),
])
```

`withAdbKeyboard` must reject only `not-installed`; for `not-enabled` and `not-selected`, it must enable/select as needed, prove readiness, run the broadcast, restore the previous selected IME with a fresh cleanup signal, and disable the helper only when this operation enabled it.

- [x] **Step 6: Run the focused ADB tests**

Run: `pnpm exec vitest run tests/adb/adb-device.spec.ts`

Expected: all tests pass, including cancellation cleanup and true missing-helper rejection.

### Task 2: Keep the model out of normal IME setup

**Files:**

- Modify: `src/agent/prompt.ts`
- Test: `tests/agent/prompt.spec.ts`

**Interfaces:**

- Consumes: the provider-owned transparent Unicode path from Task 1.
- Produces: model guidance that calls `input_text`/`replace_text` directly and reserves `setup_unicode_input` for a true missing-helper response.

- [x] **Step 1: Add prompt assertions for direct non-ASCII input**

```ts
expect(PHONE_AGENT_PROMPT).toContain('Use input_text or replace_text directly for non-ASCII text')
expect(PHONE_AGENT_PROMPT).toContain('call setup_unicode_input once only when the error says the helper is not installed')
expect(PHONE_AGENT_PROMPT).not.toContain('Before entering non-ASCII text, call setup_unicode_input once')
```

- [x] **Step 2: Run the prompt test and verify the old setup-first rule fails**

Run: `pnpm exec vitest run tests/agent/prompt.spec.ts`

Expected before implementation: the direct-input assertion fails.

- [x] **Step 3: Replace the setup-first rules**

```text
13. Use input_text or replace_text directly for non-ASCII text; the provider transparently activates an installed helper and restores the user's previous IME.
14. If text entry returns PHONE_UNICODE_INPUT_UNSUPPORTED and explicitly says the helper is not installed, call setup_unicode_input once. Never retry setup after approval is denied or after a missing APK-path error.
```

- [x] **Step 4: Run prompt, executor, approval, and schema tests**

Run: `pnpm exec vitest run tests/agent/prompt.spec.ts tests/agent/executor.spec.ts tests/agent/approval.spec.ts tests/tools/schema.spec.ts`

Expected: all tests pass; the one-wrapper schema compatibility remains covered.

### Task 3: Label settle deadlines as non-fatal

**Files:**

- Modify: `src/agent/serializer.ts`
- Test: `tests/agent/serializer.spec.ts`

**Interfaces:**

- Consumes: `PhoneActionResult.stability` and `PhoneActionResult.verification.success`.
- Produces: model-visible output that distinguishes a verified action from a page that kept animating until the settle deadline.

- [x] **Step 1: Add a serializer regression test**

```ts
expect(text).toContain('Settle: deadline reached (non-fatal); samples: 4')
expect(text).not.toContain('timeout: true')
```

- [x] **Step 2: Run the serializer test and verify the old wording fails**

Run: `pnpm exec vitest run tests/agent/serializer.spec.ts`

Expected before implementation: output contains `Stable: false; timeout: true`.

- [x] **Step 3: Serialize stable and deadline outcomes explicitly**

```ts
lines.push(result.stability.timedOut
  ? `Settle: deadline reached (non-fatal); samples: ${result.stability.samples}`
  : `Settle: stable; samples: ${result.stability.samples}`)
```

- [x] **Step 4: Run the serializer test**

Run: `pnpm exec vitest run tests/agent/serializer.spec.ts`

Expected: all tests pass.

### Task 4: Documentation and generated artifacts

**Files:**

- Modify: `README.md`
- Modify: `docs/README.zh.md`
- Modify generated tracked output under: `lib/`

**Interfaces:**

- Consumes: Tasks 1-3 behavior.
- Produces: accurate install/use docs and publishable generated output.

- [x] **Step 1: Document transparent temporary selection**

State that an installed ADB Keyboard is discovered with `ime list -a -s`, is enabled/selected only as needed for the Unicode broadcast, and the user's previous IME and enabled set are restored. Keep the reviewed-path plus approval requirement for a truly absent helper.

- [x] **Step 2: Run the complete repository check**

Run: `pnpm run check`

Expected: typecheck, build, all unit/integration tests, FakePhoneDevice coverage, and package verification pass; tracked `lib/` is rebuilt.

- [x] **Step 3: Pack and inspect**

Run: `pnpm pack`

Expected: package generation succeeds and contains no downloaded or local-only APK.

- [x] **Step 4: Review without committing**

Run: `git diff --check`, `git status --short --branch`, `git diff --stat`

Expected: no whitespace errors; changes remain uncommitted on `dev`; no real-device mutation, push, tag, or release occurred.
