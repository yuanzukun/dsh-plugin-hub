# dsh-git-workflow 实现详解

> Git 工作流插件：规范提交（Conventional Commits）、自动 changelog、PR 描述生成、分支推送。
> 面向想给 dsh 贡献插件的开发者：记录工具插件的标准形态——纯函数核心 + `defineTool` 注册 + 测试接缝。

## 一、目标与范围

- **纯 git CLI**：不依赖 GitHub/GitCode API、不依赖 token，任何远端通用。
- **五个工具**：`git_status` / `git_commit` / `git_changelog` / `git_pr_summary` / `git_push`。
- **规范驱动**：`git_commit` 默认强制 Conventional Commits（可配置关闭）。
- **模型友好输出**：changelog 与 PR 描述直接输出可粘贴的 Markdown。

## 二、架构分层

```
src/
  index.ts  插件入口：schema、buildTools(config) → ToolDefinition[]、apply 注册
  git.ts    纯 git 操作：execFile 封装 + 解析 + 生成（不依赖 dsh）
```

关键决策：**工具构建抽成公开的 `buildTools(config)`**。apply 里只是 `for (const tool of buildTools(config)) ctx.tools.register(tool)`。好处：

1. 测试不需要 harness——直接拿 `ToolDefinition` 调 `execute(args, {})`。
2. 配置分辨率集中一处（`workdir` 缺省 = 会话工作目录）。
3. 与 article-publish 的"apply 里逐个注册"相比，可测性更好，且不破坏插件形态。

## 三、核心设计决策

### 1. execFile，不用 shell 拼接

所有 git 调用走 `execFile('git', args, { cwd, timeout, maxBuffer })`：

- 参数数组直接传，**无 shell 注入面**（工具参数来自模型，必须假设不可信）。
- 非零退出 → reject，错误信息带 `git <args> 退出码 N：<stderr>`，工具层 throw 即 `isError`。
- 30s 超时、8 MiB 输出上限（`git diff --stat` 大仓库可能输出较多）。

### 2. Conventional Commits 校验

```ts
const CONVENTIONAL_RE = /^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\([\w./-]+\))?!?: .+/;
```

- 校验失败时**不返回失败文本，而是 throw 带修复指引**：报错包含格式说明和"收到什么"，Agent 看到 `isError` 能自行改写。
- 破坏性变更：类型后可选 `!`（subject 或 body 含 `BREAKING CHANGE:` 均识别，changelog/PR 里单列 ⚠️ 段）。

### 3. 提交解析用单元分隔符

changelog/PR 需要按提交拆出 hash / subject / body，多行 body 用换行拆会错位。用：

```
git log --no-merges --pretty=format:%h%x1f%s%x1f%b%x1e <range>
```

`\x1f` 分字段、`\x1e` 分记录——body 里的换行安全保留，再按类型聚合。

### 4. dom/dow 双限制的 OR 语义

cron 的边界语义（同样实现在 dsh-scheduler 的 cron.ts 里）：dom 与 dow 都非通配时，**日期命中 = dom 命中 OR dow 命中**（标准 cron）。changelog 从 `from..to` 取提交（`from` 默认最近 tag，无 tag 时报错引导显式传参）。

### 5. 工作目录守卫

每个工具先 `isRepo(cwd)`（`git rev-parse --is-inside-work-tree`），非仓库直接 throw 提示 `git init` 或配置 `workdir`。避免模型在随机目录调用 git 拿到一串 confusing 的 stderr。

## 四、工具形态

`defineTool` 的固定骨架（与官方 cookbook 一致）：

```ts
defineTool({
  name: 'git_status',
  description: '…模型看到的说明，含何时该用…',
  parameters: { /* 参数 schema，required 标注 */ },
  output: {
    schema: { type: 'string' },
    render: (_args, value) => [{ type: 'text', text: value }],
  },
  execute: async (args) => { /* 返回规范值字符串；异常 throw */ },
})
```

要点：

- **description 要写"什么时候用"**（如"提交前先调用它确认变更范围"），这是模型正确选择工具的依据。
- `output.schema` 声明 `string`，`render` 转文本——工具返回规范 JSON 值，UI 卡片/模型文本各走各的渲染。
- 参数校验由 dsh-tools 在 execute 前完成（类型/必填），execute 内只做领域校验。

## 五、测试

`test/git-workflow.test.mjs`（7 场景，真仓库端到端）：

```
临时仓库：main 分支 chore 提交 → feat/greeter 分支 feat 提交 → 工作区未暂存改动
 1. git_status  → 分支/变更数/文件名正确
 2. git_commit  → 非规范 message 被拒（正则匹配报错文案）
 3. git_commit  → 规范 message 落库（git log 可查）
 4. git_changelog → 按类型分组（新功能/修复）
 5. git_pr_summary → 标题建议 + 提交列表 + diff 统计
 6. git_push    → 推送到本地 bare remote，-u 上游建立
 7. 非仓库守卫  → workdir 指向非仓库时 throw
```

测试直接调 `buildTools(config)` 返回的 `execute(args, {})`，无 harness 依赖。

## 六、使用示例

```
我：帮我把这次改动提交了
Agent：git_status → 3 个文件变更
     → git_commit message="feat: add login flow" all=true
     → "已提交 a1b2c3d：feat: add login flow"
我：生成 PR 描述
Agent：git_pr_summary base=main
     → "# PR 建议标题\nadd login flow\n## 描述模板…\n### 提交列表…\n### 变更统计…"
```

## 七、给贡献者的经验

1. **工具 = 纯函数核心 + 薄注册层**：逻辑放独立模块（`git.ts`），`index.ts` 只做 schema 与注册，测试接缝就有了。
2. **错误 throw，成功返值**：dsh-tools 会把 throw 归一为 `isError`；返回文本会把失败伪装成成功结果。
3. **模型视角的 description 决定工具命中率**：写明适用场景、参数含义、返回内容。
4. **CLI 调用永远 execFile + 参数数组**：任何 shell 字符串拼接都是注入面。
5. **输出要可直接用**：changelog/PR 描述直接是可粘贴 Markdown，模型不需要二次加工。
