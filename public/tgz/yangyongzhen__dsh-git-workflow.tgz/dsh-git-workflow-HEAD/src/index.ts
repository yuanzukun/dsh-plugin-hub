/**
 * dsh-git-workflow — conventional git workflow tools for DeepSeek Harness.
 *
 * Registers five model-visible tools over the local `git` binary:
 *   - git_status     : branch / ahead-behind / staged files / recent commits
 *   - git_commit     : validates Conventional Commits, stages (optional) and commits
 *   - git_changelog  : markdown changelog grouped by type since a ref/tag
 *   - git_pr_summary : PR title + description skeleton for a base..head range
 *   - git_push       : push the current branch with upstream tracking
 *
 * Works against any git remote (GitCode / GitHub / self-hosted); no platform
 * API or token is required.
 *
 * @module dsh-git-workflow
 */
import z from '@deepseek-ai/schemastery';
import type { Context } from '@deepseek-ai/cordis';
import { defineTool, type ToolDefinition } from '@deepseek-ai/dsh-tools';
import {
	changelogText,
	commitChanges,
	isRepo,
	prSummaryText,
	pushBranch,
	statusText,
	type GitWorkflowConfig
} from './git.js';

/** Stable Cordis plugin name. */
const name = 'git-workflow';
/** Core service required before tools can be registered. */
const inject = ['tools'];

const Config = z.object({
	enabled: z.boolean().default(true),
	workdir: z.string(),
	conventional: z.boolean().default(true),
	defaultBranch: z.string().default('main')
});

/** Guard every tool: fail fast when the working directory is not a repo. */
async function repoGuard(cwd: string | undefined): Promise<string | null> {
	if (!(await isRepo(cwd))) {
		return '当前工作目录不是 git 仓库。请先 `git init` 或在配置里设置 workdir 指向仓库。';
	}
	return null;
}

/** Build the five git tools against a resolved working directory. */
export function buildTools(config: GitWorkflowConfig): ToolDefinition[] {
	const cwd = config.workdir !== undefined && config.workdir !== '' ? config.workdir : undefined;
	return [
		defineTool({
			name: 'git_status',
			description:
				'查看当前 git 仓库状态：分支、与上游的领先/落后、已暂存/未暂存/未跟踪文件、最近提交。提交前先调用它确认变更范围。',
			parameters: {},
			output: {
				schema: { type: 'string' },
				render: (_args, value) => [{ type: 'text', text: value }]
			},
			execute: async () => {
				const problem = await repoGuard(cwd);
				if (problem !== null) throw new Error(problem);
				return statusText(cwd);
			}
		}),
		defineTool({
			name: 'git_commit',
			description:
				'提交暂存区变更（或 all=true 时先暂存全部变更）。message 必须符合 Conventional Commits：`<type>(<scope>)?: <subject>`，' +
				'type 为 feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert，破坏性变更在冒号前加 `!`。返回提交短哈希与主题。',
			parameters: {
				message: { type: 'string', required: true, description: '提交信息（Conventional Commits 格式）' },
				all: { type: 'boolean', description: 'true 时先执行 git add -A 再提交；默认 true' }
			},
			output: {
				schema: { type: 'string' },
				render: (_args, value) => [{ type: 'text', text: value }]
			},
			execute: async (args) => {
				const problem = await repoGuard(cwd);
				if (problem !== null) throw new Error(problem);
				return commitChanges(cwd, args.message as string, args.all !== false, config.conventional);
			}
		}),
		defineTool({
			name: 'git_changelog',
			description:
				'生成 Markdown 变更日志：按 Conventional Commits 类型分组（新功能/修复/破坏性变更等）。' +
				'from 默认取最近一个 tag；无 tag 时必须显式传入 from（如 "HEAD~5"）。返回完整 changelog 文本。',
			parameters: {
				from: { type: 'string', description: '起始引用（tag/commit/branch）；默认最近 tag' },
				to: { type: 'string', description: '结束引用；默认 HEAD' }
			},
			output: {
				schema: { type: 'string' },
				render: (_args, value) => [{ type: 'text', text: value }]
			},
			execute: async (args) => {
				const problem = await repoGuard(cwd);
				if (problem !== null) throw new Error(problem);
				return changelogText(cwd, args.from as string | undefined, args.to as string | undefined);
			}
		}),
		defineTool({
			name: 'git_pr_summary',
			description:
				'生成 PR 标题建议与描述模板：列出 base...head 之间的提交、diff 统计、破坏性变更，' +
				'输出可直接粘贴到 GitHub / GitCode PR 页面的 Markdown。base 默认取配置的 defaultBranch（main）。',
			parameters: {
				base: { type: 'string', description: '基准分支（被合入方）；默认 main 或配置值' },
				head: { type: 'string', description: '特性分支；默认当前分支' }
			},
			output: {
				schema: { type: 'string' },
				render: (_args, value) => [{ type: 'text', text: value }]
			},
			execute: async (args) => {
				const problem = await repoGuard(cwd);
				if (problem !== null) throw new Error(problem);
				return prSummaryText(cwd, args.base as string | undefined, args.head as string | undefined, config.defaultBranch);
			}
		}),
		defineTool({
			name: 'git_push',
			description: '把当前分支推送到远端并设置上游跟踪（git push -u）。remote 默认 origin，branch 默认当前分支。',
			parameters: {
				remote: { type: 'string', description: '远端名；默认 origin' },
				branch: { type: 'string', description: '分支名；默认当前分支' }
			},
			output: {
				schema: { type: 'string' },
				render: (_args, value) => [{ type: 'text', text: value }]
			},
			execute: async (args) => {
				const problem = await repoGuard(cwd);
				if (problem !== null) throw new Error(problem);
				return pushBranch(cwd, args.remote as string | undefined, args.branch as string | undefined);
			}
		})
	];
}

/**
 * Mount the plugin: register the five git tools.
 */
function apply(ctx: Context, rawConfig: unknown) {
	const config = Config(rawConfig as never) as GitWorkflowConfig;
	if (!config.enabled) return;
	for (const tool of buildTools(config)) ctx.tools.register(tool);
}

export { Config, apply, inject, name };
export {
	isRepo,
	statusText,
	commitChanges,
	validateConventional,
	changelogText,
	prSummaryText,
	pushBranch,
	runGit,
	type GitWorkflowConfig
} from './git.js';
