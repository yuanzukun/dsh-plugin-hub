/**
 * Pure git operations for dsh-git-workflow.
 *
 * All functions run `git` via execFile (no shell interpolation) inside a
 * configured working directory and throw readable Chinese errors on failure,
 * so tools can surface `isError` instead of swallowing bad states.
 *
 * @module dsh-git-workflow/git
 */
import { execFile } from 'node:child_process';

/** Resolved plugin configuration shared by every tool. */
export interface GitWorkflowConfig {
	enabled: boolean;
	/** Repository working directory; defaults to the session workspace. */
	workdir?: string;
	/** Enforce Conventional Commits on git_commit. */
	conventional: boolean;
	/** Assumed PR base branch when the caller omits it. */
	defaultBranch: string;
}

export interface GitResult {
	stdout: string;
	stderr: string;
	code: number;
}

const CONVENTIONAL_RE = /^(feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert)(\([\w./-]+\))?!?: .+/;

/** Run one git command; rejects with the command's stderr (or stdout) on failure. */
export async function runGit(args: readonly string[], cwd: string | undefined, timeoutMs = 30_000): Promise<GitResult> {
	return new Promise((resolve, reject) => {
		execFile('git', [...args], { cwd, timeout: timeoutMs, maxBuffer: 8 << 20, windowsHide: true }, (error, stdout, stderr) => {
			if (error !== null) {
				const code = typeof (error as { code?: unknown }).code === 'number' ? (error as { code: number }).code : -1;
				const detail = (stderr || stdout).trim().slice(0, 2000);
				reject(new Error(`git ${args.join(' ')} 退出码 ${code}${detail !== '' ? `：${detail}` : ''}`));
				return;
			}
			resolve({ stdout: stdout.trim(), stderr: stderr.trim(), code: 0 });
		});
	});
}

/** True when the working directory is inside a git repository. */
export async function isRepo(cwd: string | undefined): Promise<boolean> {
	try {
		await runGit(['rev-parse', '--is-inside-work-tree'], cwd, 10_000);
		return true;
	} catch {
		return false;
	}
}

/** Current branch short name (`git rev-parse --abbrev-ref HEAD`). */
export async function currentBranch(cwd: string | undefined): Promise<string> {
	const res = await runGit(['rev-parse', '--abbrev-ref', 'HEAD'], cwd);
	return res.stdout;
}

interface StatusFile {
	index: string;
	worktree: string;
	path: string;
}

interface ParsedStatus {
	branch: string;
	ahead: number;
	behind: number;
	files: StatusFile[];
}

/** Parse `git status --porcelain=v1 -b` output. */
export function parseStatus(raw: string): ParsedStatus {
	const lines = raw.split('\n').filter((l) => l !== '');
	const branchLine = lines.find((l) => l.startsWith('## ')) ?? '## unknown';
	const branchMatch = /^## ([^ .]+)(?:\.\.\.([^ ]+))?(?: \[ahead (\d+)(?:, behind (\d+))?| behind (\d+)\])?/.exec(branchLine);
	const files: StatusFile[] = [];
	for (const line of lines) {
		if (line.startsWith('## ')) continue;
		const index = line.slice(0, 2);
		const path = line.slice(3);
		files.push({ index: index[0], worktree: index[1], path });
	}
	return {
		branch: branchMatch?.[1] ?? 'unknown',
		ahead: Number(branchMatch?.[3] ?? 0),
		behind: Number(branchMatch?.[4] ?? branchMatch?.[5] ?? 0),
		files
	};
}

function statusLabel(file: StatusFile): string {
	if (file.index === '?' && file.worktree === '?') return '未跟踪';
	if (file.index !== ' ' && file.index !== '?') return '已暂存';
	return '未暂存';
}

/** Human-readable repository status (git_status tool body). */
export async function statusText(cwd: string | undefined): Promise<string> {
	const res = await runGit(['status', '--porcelain=v1', '-b'], cwd);
	const parsed = parseStatus(res.stdout);
	const lines: string[] = [`分支：${parsed.branch}`];
	if (parsed.ahead > 0 || parsed.behind > 0) {
		lines.push(`同步状态：领先 ${parsed.ahead} / 落后 ${parsed.behind}`);
	} else {
		lines.push('同步状态：与上游一致');
	}
	if (parsed.files.length === 0) {
		lines.push('工作区干净');
	} else {
		const staged = parsed.files.filter((f) => f.index !== ' ' && f.index !== '?');
		const unstaged = parsed.files.filter((f) => f.index === ' ' || f.index === '?');
		lines.push(`变更：${staged.length} 个已暂存，${unstaged.length} 个未暂存/未跟踪`);
		for (const f of parsed.files.slice(0, 40)) lines.push(`- [${statusLabel(f)}] ${f.path}`);
		if (parsed.files.length > 40) lines.push(`… 另有 ${parsed.files.length - 40} 个文件`);
	}
	// recent commits (tolerate empty history)
	try {
		const log = await runGit(['log', '--oneline', '-8'], cwd);
		if (log.stdout !== '') {
			lines.push('最近提交：');
			for (const line of log.stdout.split('\n')) lines.push(`  ${line}`);
		}
	} catch {
		// no commits yet
	}
	return lines.join('\n');
}

/** Validate a Conventional Commits message; returns the error text or null. */
export function validateConventional(message: string): string | null {
	const firstLine = message.split('\n')[0].trim();
	if (!CONVENTIONAL_RE.test(firstLine)) {
		return (
			'提交信息不符合 Conventional Commits 规范。格式：`<type>(<scope>)?: <subject>`，' +
			'type 为 feat|fix|docs|style|refactor|perf|test|build|ci|chore|revert；破坏性变更在冒号前加 `!`。' +
			`收到：${firstLine}`
		);
	}
	return null;
}

/** Stage everything (optional) and commit; returns short hash + subject. */
export async function commitChanges(
	cwd: string | undefined,
	message: string,
	all: boolean,
	conventional: boolean
): Promise<string> {
	const firstLine = message.split('\n')[0].trim();
	if (firstLine === '') throw new Error('提交信息不能为空');
	if (conventional) {
		const problem = validateConventional(message);
		if (problem !== null) throw new Error(problem);
	}
	if (all) await runGit(['add', '-A'], cwd);
	await runGit(['commit', '-m', message], cwd);
	const hash = await runGit(['rev-parse', '--short', 'HEAD'], cwd);
	return `已提交 ${hash.stdout}：${firstLine}`;
}

interface LogEntry {
	hash: string;
	subject: string;
	body: string;
}

/** Commit records between two revisions, excluding merges. */
async function logEntries(cwd: string | undefined, range: string): Promise<LogEntry[]> {
	const res = await runGit(['log', '--no-merges', `--pretty=format:%h%x1f%s%x1f%b%x1e`, range], cwd);
	const entries: LogEntry[] = [];
	for (const record of res.stdout.split('\x1e')) {
		const [hash, subject, body] = record.split('\x1f');
		if (hash !== undefined && subject !== undefined) {
			entries.push({ hash, subject: subject.trim(), body: (body ?? '').trim() });
		}
	}
	return entries;
}

const TYPE_ORDER = ['feat', 'fix', 'docs', 'refactor', 'perf', 'test', 'build', 'ci', 'chore', 'revert'];

function entryType(subject: string): string | null {
	const m = /^([a-z]+)(\([\w./-]+\))?(!)?:/.exec(subject);
	return m !== null ? m[1] : null;
}

function isBreaking(subject: string, body: string): boolean {
	return subject.includes('!') || /^BREAKING CHANGE:/m.test(body);
}

/** Markdown changelog for `from..to` (defaults: last tag .. HEAD). */
export async function changelogText(cwd: string | undefined, from: string | undefined, to: string | undefined): Promise<string> {
	let fromRev = from;
	if (fromRev === undefined) {
		try {
			const tag = await runGit(['describe', '--tags', '--abbrev=0'], cwd);
			fromRev = tag.stdout;
		} catch {
			throw new Error('找不到上一个 tag。请显式传入 from（commit/tag/branch），例如 from: "HEAD~5"。');
		}
	}
	const toRev = to ?? 'HEAD';
	const range = `${fromRev}..${toRev}`;
	const entries = await logEntries(cwd, range);
	if (entries.length === 0) return `${range} 之间没有提交。`;

	const groups = new Map<string, LogEntry[]>();
	const others: LogEntry[] = [];
	const breaking: LogEntry[] = [];
	for (const entry of entries) {
		if (isBreaking(entry.subject, entry.body)) {
			breaking.push(entry);
			continue;
		}
		const type = entryType(entry.subject);
		if (type !== null && TYPE_ORDER.includes(type)) {
			const list = groups.get(type) ?? [];
			list.push(entry);
			groups.set(type, list);
		} else {
			others.push(entry);
		}
	}

	const TYPE_LABEL: Record<string, string> = {
		feat: '新功能',
		fix: '修复',
		docs: '文档',
		refactor: '重构',
		perf: '性能',
		test: '测试',
		build: '构建',
		ci: 'CI',
		chore: '杂项',
		revert: '回滚'
	};

	const out: string[] = [`# Changelog（${range}）`, ''];
	if (breaking.length > 0) {
		out.push('## ⚠️ 破坏性变更', '');
		for (const e of breaking) out.push(`- \`${e.hash}\` ${e.subject}`);
		out.push('');
	}
	for (const type of TYPE_ORDER) {
		const list = groups.get(type);
		if (list === undefined) continue;
		out.push(`## ${TYPE_LABEL[type]}`, '');
		for (const e of list) out.push(`- \`${e.hash}\` ${e.subject}`);
		out.push('');
	}
	if (others.length > 0) {
		out.push('## 其他', '');
		for (const e of others) out.push(`- \`${e.hash}\` ${e.subject}`);
	}
	return out.join('\n').trim();
}

/** PR title/description skeleton for `base...head` (defaults: defaultBranch..current). */
export async function prSummaryText(cwd: string | undefined, base: string | undefined, head: string | undefined, defaultBranch: string): Promise<string> {
	const headRef = head ?? (await currentBranch(cwd));
	const baseRef = base ?? defaultBranch;
	try {
		await runGit(['rev-parse', '--verify', baseRef], cwd);
	} catch {
		throw new Error(`找不到基准分支 "${baseRef}"。可用分支：${(await runGit(['branch', '--format=%(refname:short)'], cwd)).stdout.split('\n').join(', ')}`);
	}
	const range = `${baseRef}...${headRef}`;
	const entries = await logEntries(cwd, range);
	if (entries.length === 0) {
		return `${baseRef}...${headRef} 之间没有差异提交。`;
	}
	const stat = await runGit(['diff', '--stat', range], cwd);

	const firstFeat = entries.find((e) => entryType(e.subject) === 'feat');
	const titleSource = firstFeat ?? entries[0];
	const title = titleSource.subject.replace(/^[a-z]+(\([\w./-]+\))?!?: /, '');

	const breaking = entries.filter((e) => isBreaking(e.subject, e.body));
	const out: string[] = [
		`# PR 建议标题`,
		`${title}`,
		'',
		`## 描述模板（${baseRef} → ${headRef}，共 ${entries.length} 个提交）`,
		'',
		'### 变更内容',
		'',
		'- [ ] 用一句话说明改动',
		'- [ ] 补充影响范围与验证方式',
		'',
		'### 提交列表',
		''
	];
	for (const e of entries) out.push(`- \`${e.hash}\` ${e.subject}`);
	out.push('', '### 变更统计', '', '```', stat.stdout, '```');
	if (breaking.length > 0) {
		out.push('', '### ⚠️ 破坏性变更', '');
		for (const e of breaking) out.push(`- \`${e.hash}\` ${e.subject}`);
	}
	return out.join('\n');
}

/** Push `branch` (default: current) to `remote` (default: origin) with -u. */
export async function pushBranch(cwd: string | undefined, remote: string | undefined, branch: string | undefined): Promise<string> {
	const remoteName = remote ?? 'origin';
	const branchName = branch ?? (await currentBranch(cwd));
	await runGit(['push', '-u', remoteName, branchName], cwd, 120_000);
	return `已推送 ${branchName} → ${remoteName}/${branchName}`;
}
