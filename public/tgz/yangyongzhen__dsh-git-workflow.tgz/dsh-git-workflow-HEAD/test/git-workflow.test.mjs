/**
 * dsh-git-workflow end-to-end tests: a real temp git repository driven
 * through the plugin's exported tool definitions (execute called directly,
 * no dsh runtime required).
 *
 * Run: node test/git-workflow.test.mjs
 */
import { mkdtempSync, writeFileSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { buildTools } from '../lib/index.js';

const REPO = mkdtempSync(join(tmpdir(), 'dsh-git-workflow-'));
const REMOTE = mkdtempSync(join(tmpdir(), 'dsh-git-workflow-remote-'));
const CONFIG = { enabled: true, conventional: true, defaultBranch: 'main' };

function git(args, cwd = REPO) {
	return execFileSync('git', args, { cwd, stdio: ['ignore', 'pipe', 'pipe'] });
}

function tool(name) {
	return buildTools({ ...CONFIG, workdir: REPO }).find((t) => t.name === name);
}

async function call(name, args = {}) {
	return tool(name).execute(args, {});
}

let passed = 0;
async function check(label, fn) {
	try {
		await fn();
		passed += 1;
		console.log(`ok - ${label}`);
	} catch (err) {
		console.error(`FAIL - ${label}: ${err.message}`);
		process.exitCode = 1;
	}
}

async function main() {
	// --- setup: real repo with a feature branch and working-tree changes ---
	git(['init', '-b', 'main']);
	git(['config', 'user.name', 'test']);
	git(['config', 'user.email', 'test@example.com']);
	writeFileSync(join(REPO, 'README.md'), '# demo\n');
	git(['add', '-A']);
	git(['commit', '-m', 'chore: initial scaffold']);
	git(['checkout', '-b', 'feat/greeter']);
	writeFileSync(join(REPO, 'greeter.js'), 'export const greet = (n) => `hi ${n}`;\n');
	git(['add', '-A']);
	git(['commit', '-m', 'feat: add greeter module']);
	writeFileSync(join(REPO, 'greeter.js'), 'export const greet = (n) => `hello ${n}`;\n'); // unstaged change

	// --- 1. git_status reflects branch and working-tree state ---
	await check('git_status shows branch and changes', async () => {
		const out = await call('git_status');
		assert.match(out, /分支：feat\/greeter/);
		assert.match(out, /变更：0 个已暂存，1 个未暂存/);
		assert.match(out, /greeter\.js/);
	});

	// --- 2. conventional enforcement rejects bad messages ---
	await check('git_commit rejects non-conventional message', async () => {
		await assert.rejects(() => call('git_commit', { message: 'fix stuff' }), /不符合 Conventional Commits/);
	});

	// --- 3. valid conventional commit lands ---
	await check('git_commit applies a conventional message', async () => {
		const out = await call('git_commit', { message: 'fix: correct greeting wording', all: true });
		assert.match(out, /已提交/);
		assert.match(out, /fix: correct greeting wording/);
		const log = git(['log', '--oneline', '-1']);
		assert.match(String(log), /fix: correct greeting wording/);
	});

	// --- 4. changelog groups commits by type ---
	await check('git_changelog groups feat/fix since a ref', async () => {
		const out = await call('git_changelog', { from: 'HEAD~2' });
		assert.match(out, /## 新功能/);
		assert.match(out, /feat: add greeter module/);
		assert.match(out, /## 修复/);
		assert.match(out, /fix: correct greeting wording/);
	});

	// --- 5. PR summary builds title + commits + diffstat ---
	await check('git_pr_summary produces PR skeleton', async () => {
		const out = await call('git_pr_summary', { base: 'main', head: 'feat/greeter' });
		assert.match(out, /# PR 建议标题/);
		assert.match(out, /add greeter module/);
		assert.match(out, /提交列表/);
		assert.match(out, /变更统计/);
	});

	// --- 6. push to a local bare remote ---
	await check('git_push pushes to a bare remote', async () => {
		execFileSync('git', ['init', '--bare', REMOTE], { stdio: 'ignore' });
		git(['remote', 'add', 'origin', REMOTE]);
		const out = await call('git_push', { remote: 'origin' });
		assert.match(out, /已推送 feat\/greeter → origin\/feat\/greeter/);
	});

	// --- 7. non-repo guard ---
	await check('tools reject a non-repo working directory', async () => {
		const notRepo = mkdtempSync(join(tmpdir(), 'dsh-not-repo-'));
		const tools = buildTools({ ...CONFIG, workdir: notRepo });
		await assert.rejects(() => tools.find((t) => t.name === 'git_status').execute({}, {}), /不是 git 仓库/);
	});

	console.log(`\n${passed} checks passed`);
	rmSync(REPO, { recursive: true, force: true });
	rmSync(REMOTE, { recursive: true, force: true });
}

main().catch((err) => {
	console.error('FATAL', err);
	process.exit(1);
});
