/**
 * dsh-git-workflow — conventional git workflow tools for DeepSeek Harness.
 *
 * Registers five model-visible tools over the local `git` binary:
 *   - git_status     : branch / ahead-behind / staged files / recent commits
 *   - git_commit     : validates Conventional Commits, stages (optional) and commits
 *   - git_changelog  : markdown changelog grouped by type since a ref/tag
 *   - git_pr_summary : PR title + description skeleton for a base..head range
 *   - git_push       : push the current branch with upstream tracking
 *
 * Works against any git remote (GitCode / GitHub / self-hosted); no platform
 * API or token is required.
 *
 * @module dsh-git-workflow
 */
import z from '@deepseek-ai/schemastery';
import type { Context } from '@deepseek-ai/cordis';
import { type ToolDefinition } from '@deepseek-ai/dsh-tools';
import { type GitWorkflowConfig } from './git.js';
/** Stable Cordis plugin name. */
declare const name = "git-workflow";
/** Core service required before tools can be registered. */
declare const inject: string[];
declare const Config: z<Schemastery.ObjectS<{
    enabled: z<boolean, boolean>;
    workdir: z<string, string>;
    conventional: z<boolean, boolean>;
    defaultBranch: z<string, string>;
}>, Schemastery.ObjectT<{
    enabled: z<boolean, boolean>;
    workdir: z<string, string>;
    conventional: z<boolean, boolean>;
    defaultBranch: z<string, string>;
}>>;
/** Build the five git tools against a resolved working directory. */
export declare function buildTools(config: GitWorkflowConfig): ToolDefinition[];
/**
 * Mount the plugin: register the five git tools.
 */
declare function apply(ctx: Context, rawConfig: unknown): void;
export { Config, apply, inject, name };
export { isRepo, statusText, commitChanges, validateConventional, changelogText, prSummaryText, pushBranch, runGit, type GitWorkflowConfig } from './git.js';
