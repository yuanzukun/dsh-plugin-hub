/** Resolved plugin configuration shared by every tool. */
export interface GitWorkflowConfig {
    enabled: boolean;
    /** Repository working directory; defaults to the session workspace. */
    workdir?: string;
    /** Enforce Conventional Commits on git_commit. */
    conventional: boolean;
    /** Assumed PR base branch when the caller omits it. */
    defaultBranch: string;
}
export interface GitResult {
    stdout: string;
    stderr: string;
    code: number;
}
/** Run one git command; rejects with the command's stderr (or stdout) on failure. */
export declare function runGit(args: readonly string[], cwd: string | undefined, timeoutMs?: number): Promise<GitResult>;
/** True when the working directory is inside a git repository. */
export declare function isRepo(cwd: string | undefined): Promise<boolean>;
/** Current branch short name (`git rev-parse --abbrev-ref HEAD`). */
export declare function currentBranch(cwd: string | undefined): Promise<string>;
interface StatusFile {
    index: string;
    worktree: string;
    path: string;
}
interface ParsedStatus {
    branch: string;
    ahead: number;
    behind: number;
    files: StatusFile[];
}
/** Parse `git status --porcelain=v1 -b` output. */
export declare function parseStatus(raw: string): ParsedStatus;
/** Human-readable repository status (git_status tool body). */
export declare function statusText(cwd: string | undefined): Promise<string>;
/** Validate a Conventional Commits message; returns the error text or null. */
export declare function validateConventional(message: string): string | null;
/** Stage everything (optional) and commit; returns short hash + subject. */
export declare function commitChanges(cwd: string | undefined, message: string, all: boolean, conventional: boolean): Promise<string>;
/** Markdown changelog for `from..to` (defaults: last tag .. HEAD). */
export declare function changelogText(cwd: string | undefined, from: string | undefined, to: string | undefined): Promise<string>;
/** PR title/description skeleton for `base...head` (defaults: defaultBranch..current). */
export declare function prSummaryText(cwd: string | undefined, base: string | undefined, head: string | undefined, defaultBranch: string): Promise<string>;
/** Push `branch` (default: current) to `remote` (default: origin) with -u. */
export declare function pushBranch(cwd: string | undefined, remote: string | undefined, branch: string | undefined): Promise<string>;
export {};
