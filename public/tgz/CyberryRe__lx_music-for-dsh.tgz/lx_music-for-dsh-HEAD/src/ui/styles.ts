// 插件 UI 样式（注入 <style>，类名 lxm- 前缀）。使用 DSH 主题 CSS 变量融入现有样式。

export const STYLE_TAG = 'lx-music-for-dsh/styles'

export const CSS = `/* ── 实验性功能警示（音乐画像默认关闭，开启需二次确认）─────────────────────
   用户可见的"红线"：警示条与确认弹窗都必须一眼看出是危险/实验性操作。 */
.lxm-danger {
  display: flex; flex-direction: column; gap: 6px;
  padding: 10px 12px; margin-bottom: 8px;
  border: 1px solid var(--dsw-alias-state-error-primary, #f56c6c);
  border-radius: 8px;
  background: color-mix(in srgb, var(--dsw-alias-state-error-primary, #f56c6c) 12%, transparent);
  min-width: 0; max-width: 100%;
}
.lxm-danger-title {
  font-size: 13px; font-weight: 700;
  color: var(--dsw-alias-state-error-primary, #f56c6c);
  min-width: 0; max-width: 100%; overflow-wrap: anywhere;
}
.lxm-danger-body {
  font-size: 12px; line-height: 1.6;
  color: var(--dsw-alias-label-primary, #e6e6e6);
  display: flex; flex-direction: column; gap: 4px;
  min-width: 0; max-width: 100%; overflow-wrap: anywhere;
}
.lxm-danger-btn {
  border-color: var(--dsw-alias-state-error-primary, #f56c6c) !important;
  color: var(--dsw-alias-state-error-primary, #f56c6c) !important;
  align-self: flex-start;
}
.lxm-modal-backdrop {
  position: absolute; inset: 0; z-index: 20;
  display: flex; align-items: center; justify-content: center;
  padding: 16px;
  background: rgba(0, 0, 0, 0.45);
}
.lxm-modal-card {
  display: flex; flex-direction: column; gap: 8px;
  width: auto; max-width: 100%; max-height: 100%;
  overflow-y: auto;
  padding: 14px 16px;
  border: 2px solid var(--dsw-alias-state-error-primary, #f56c6c);
  border-radius: 10px;
  background: var(--dsw-specific-sidebar-fill, #1e1e1e);
  box-shadow: 0 12px 40px rgba(0, 0, 0, 0.5);
  color: var(--dsw-alias-label-primary, #e6e6e6);
}
.lxm-card {
  display: flex;
  flex-direction: column;
  gap: 6px;
  padding: 10px 12px;
  border-radius: 10px;
  background: color-mix(in srgb, var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.08)) 60%, transparent);
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.15));
  cursor: pointer;
  user-select: none;
  /* 卡片是会话侧边栏里的 flex/grid 子项：**必须**允许被压缩到容器宽度。
     否则一段长文本（最典型的是报错信息，含 URL/JSON 且没有空格）会把它撑出侧边栏，
     覆盖住旁边的设置入口，导致用户连设置都点不到。 */
  box-sizing: border-box;
  width: 100%;
  max-width: 100%;
  min-width: 0;
  overflow: hidden;
}
.lxm-card:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.12)); }
.lxm-card-head { display: flex; gap: 8px; align-items: center; min-width: 0; }
.lxm-cover {
  width: 42px; height: 42px; border-radius: 8px; object-fit: cover; flex: none;
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.15));
}
.lxm-title { min-width: 0; flex: 1; overflow: hidden; }
.lxm-name {
  font-size: 13px; font-weight: 600; color: var(--dsw-alias-label-primary, #e6e6e6);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.lxm-singer {
  font-size: 11px; color: var(--dsw-alias-label-tertiary, #999);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
/* 报错信息单独一行：换行而不是撑宽容器，最多两行，完整内容在 title 里。
   ⚠️ 全仓库只有这一处 .lxm-error 定义，卡片（Card）与窗口（MainWindow）共用它。
   这里曾经有第二条同选择器的规则（在文件后半段），两条规则按属性互相覆盖，
   读代码时无法直接看出最终样式，改任一条都可能静默影响另一处。
   新增样式请改这一处，不要再写第二条 .lxm-error。 */
.lxm-error {
  flex: none;
  font-size: 12px; line-height: 1.4;
  color: #ff7b72;
  background: color-mix(in srgb, #ff7b72 10%, transparent);
  border: 1px solid color-mix(in srgb, #ff7b72 30%, transparent);
  border-radius: 8px;
  padding: 6px 10px;
  min-width: 0; max-width: 100%;
  overflow-wrap: anywhere; word-break: break-word;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.lxm-progress { display: flex; align-items: center; gap: 6px; }
.lxm-progress input[type="range"] {
  flex: 1; margin: 0; height: 4px; cursor: pointer;
  accent-color: var(--dsw-alias-state-business-primary, #4c8dff);
}
/* 音量（1.3.0）：二级面板 = 一根竖滑块，点喇叭后向上弹出。
   ⚠️ 这里**必须**是 position: fixed —— 面板由 VolumePopover 用 portal 挂到 <body>，
   因为卡片 .lxm-card 有 overflow: hidden（可压缩容器，不能去掉）。只要面板还留在
   卡片内部，溢出部分就会被裁掉，z-index 再大都没用（裁剪先于合成发生）。
   面板里只有一根滑块（没有数值、没有喇叭按钮），所以走极简样式：细轨道 + 圆点。
   top/right 由组件按按钮矩形实时算（含"上方放不下就翻到下面"），这里只负责外观。 */
.lxm-volume-pop {
  position: fixed; z-index: 10040;
  display: flex; align-items: flex-end; justify-content: center;
  padding: 9px 6px;
  background: var(--dsw-specific-sidebar-fill, #1e1e1e);
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.25));
  border-radius: 9px;
  box-shadow: 0 8px 24px rgba(0, 0, 0, 0.45);
}
/* 翻到按钮下方时，箭头指回上面的按钮 */
.lxm-volume-pop::after {
  content: ""; position: absolute; left: 50%; bottom: -5px;
  width: 8px; height: 8px; margin-left: -4px;
  background: inherit;
  border-right: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.25));
  border-bottom: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.25));
  transform: rotate(45deg);
}
.lxm-volume-pop[data-flip="true"]::after {
  top: -5px; bottom: auto;
  border-right: none; border-bottom: none;
  border-left: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.25));
  border-top: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.25));
}
/* 竖滑块：writing-mode 是标准做法（Chrome 111+ / Firefox / Safari）。
   direction: rtl 让**上端 = 100%**；否则竖着的 range 会变成"上面是 0"。
   轨道用渐变画：蓝=已设音量，灰=剩余，滑块只留一个圆点。 */
.lxm-volume-pop input[type="range"] {
  -webkit-appearance: none; appearance: none;
  writing-mode: vertical-lr; direction: rtl;
  width: 16px; height: 96px; margin: 0; padding: 7px 0; cursor: pointer;
  background: transparent;
  --lxm-fill: var(--dsw-alias-state-business-primary, #4c8dff);
}
.lxm-volume-pop input[type="range"]::-webkit-slider-runnable-track {
  width: 4px; height: 100%; border-radius: 2px;
  background: linear-gradient(to top, var(--lxm-fill) calc(var(--lxm-vol) * 1%), var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.3)) 0);
}
.lxm-volume-pop input[type="range"]::-moz-range-track {
  width: 4px; height: 100%; border-radius: 2px;
  background: linear-gradient(to top, var(--lxm-fill) calc(var(--lxm-vol) * 1%), var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.3)) 0);
}
.lxm-volume-pop input[type="range"]::-webkit-slider-thumb {
  -webkit-appearance: none; appearance: none;
  width: 12px; height: 12px; margin-left: -4px; border-radius: 50%;
  background: var(--dsw-alias-label-primary, #e6e6e6);
  border: none; cursor: pointer;
}
.lxm-volume-pop input[type="range"]::-moz-range-thumb {
  width: 12px; height: 12px; border-radius: 50%;
  background: var(--dsw-alias-label-primary, #e6e6e6);
  border: none; cursor: pointer;
}
.lxm-volume-pop input[type="range"]:hover::-webkit-slider-thumb { background: #fff; }
.lxm-volume-pop input[type="range"]:hover::-moz-range-thumb { background: #fff; }
.lxm-time { font-size: 10px; color: var(--dsw-alias-label-tertiary, #999); font-variant-numeric: tabular-nums; }
.lxm-controls { display: flex; align-items: center; justify-content: space-between; gap: 4px; }
.lxm-btn {
  display: inline-flex; align-items: center; justify-content: center;
  /* 用 min-width（而不是固定 width）+ nowrap：图标按钮仍是 26px 见方，但文字按钮会自然撑开。
     曾经用固定 width，导致独立放置的文字按钮被挤成**竖排文字**并溢出、与相邻内容交叠
     （tests/ui-styles.test.ts 把这条约定钉住了）。 */
  min-width: 26px; height: 26px; border: none; border-radius: 6px; cursor: pointer;
  background: transparent; color: var(--dsw-alias-label-secondary, #bbb); font-size: 14px;
  padding: 0 4px; white-space: nowrap;
}
.lxm-btn:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.15)); color: var(--dsw-alias-label-primary, #e6e6e6); }
.lxm-btn-primary { color: var(--dsw-alias-state-business-primary, #4c8dff); }
.lxm-btn:disabled { opacity: 0.4; cursor: default; }
.lxm-btn-mode { width: auto; min-width: 26px; padding: 0 2px; font-size: 12px; }
/* 文字按钮：自带「按钮框」，不依赖父容器（放进 .lxm-toolbar 也保持一致）。 */
.lxm-btn-text {
  width: auto; height: auto; padding: 4px 10px; font-size: 12px;
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.2));
  border-radius: 6px;
}
/* 间距 3px + 显式居中：喇叭按钮里是 SVG，不居中会随行高漂移。
   音量面板已经 portal 到 body，不再受这一行的间距影响。 */
.lxm-btn-row { display: flex; align-items: center; gap: 3px; }
.lxm-modes {
  display: inline-flex; gap: 2px; padding: 2px; flex: none;
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.08));
  border-radius: 8px;
}
.lxm-mode-btn {
  display: inline-flex; align-items: center; gap: 3px;
  border: none; background: transparent; color: var(--dsw-alias-label-tertiary, #999);
  font-size: 11px; padding: 3px 7px; border-radius: 6px; cursor: pointer;
  white-space: nowrap; line-height: 1;
}
.lxm-mode-btn:hover { color: var(--dsw-alias-label-primary, #e6e6e6); }
.lxm-mode-btn[data-active="true"] {
  background: var(--dsw-alias-state-business-primary, #4c8dff); color: #fff;
}

.lxm-window {
  position: fixed; z-index: 10000; display: flex; flex-direction: column;
  background: var(--dsw-specific-sidebar-fill, #1e1e1e);
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.25));
  border-radius: 12px; box-shadow: 0 12px 40px rgba(0,0,0,0.5);
  color: var(--dsw-alias-label-primary, #e6e6e6);
  font-size: 13px; overflow: hidden;
}
.lxm-window-titlebar {
  display: flex; align-items: center; gap: 8px; padding: 8px 12px;
  cursor: move; flex: none;
  border-bottom: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.15));
  background: color-mix(in srgb, var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.06)) 50%, transparent);
}
.lxm-window-title { font-weight: 600; font-size: 13px; flex: 1; }
.lxm-window-close {
  width: 24px; height: 24px; border: none; border-radius: 6px; cursor: pointer;
  background: transparent; color: var(--dsw-alias-label-tertiary, #999); font-size: 14px;
}
.lxm-window-close:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.15)); color: var(--dsw-alias-label-primary); }
.lxm-window-body { flex: 1; min-height: 0; display: flex; flex-direction: column; }
.lxm-window-resize {
  position: absolute; right: 0; bottom: 0; width: 14px; height: 14px; cursor: nwse-resize;
}
.lxm-tabs { display: flex; gap: 4px; padding: 8px 12px 0; flex: none; }
.lxm-tab {
  border: none; background: transparent; color: var(--dsw-alias-label-tertiary, #999);
  font-size: 13px; padding: 6px 12px; border-radius: 8px 8px 0 0; cursor: pointer;
  border-bottom: 2px solid transparent;
}
.lxm-tab[data-active="true"] { color: var(--dsw-alias-label-primary, #e6e6e6); border-bottom-color: var(--dsw-alias-state-business-primary, #4c8dff); }
.lxm-panel { flex: 1; min-height: 0; display: flex; flex-direction: column; padding: 10px 12px; gap: 8px; overflow: hidden; }

.lxm-input, .lxm-select, .lxm-textarea {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.1));
  border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.2));
  border-radius: 8px; color: var(--dsw-alias-label-primary, #e6e6e6);
  padding: 6px 10px; font-size: 13px; outline: none; min-width: 0;
}
.lxm-input:focus, .lxm-select:focus, .lxm-textarea:focus { border-color: var(--dsw-alias-state-business-primary, #4c8dff); }
.lxm-searchbar { display: flex; gap: 6px; flex: none; }
.lxm-searchbar .lxm-input { flex: 1; }
.lxm-search-btn {
  border: none; border-radius: 8px; padding: 6px 14px; cursor: pointer;
  background: var(--dsw-alias-state-business-primary, #4c8dff); color: #fff; font-size: 13px;
}
.lxm-search-btn:disabled { opacity: 0.5; cursor: default; }
.lxm-list { flex: 1; min-height: 0; overflow-y: auto; display: flex; flex-direction: column; gap: 4px; padding: 2px; }
.lxm-row {
  display: flex; align-items: center; gap: 8px; padding: 6px 8px; border-radius: 8px;
  cursor: pointer; min-width: 0;
}
.lxm-row:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.12)); }
.lxm-row[data-active="true"] { background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4c8dff) 14%, transparent); }
.lxm-row-cover { width: 34px; height: 34px; border-radius: 6px; object-fit: cover; flex: none; background: var(--dsw-alias-interactive-bg-hover); }
.lxm-row-main { flex: 1; min-width: 0; }
.lxm-row-name { font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.lxm-row-sub { font-size: 11px; color: var(--dsw-alias-label-tertiary, #999); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.lxm-badge {
  font-size: 10px; padding: 1px 5px; border-radius: 4px; flex: none;
  background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4c8dff) 16%, transparent);
  color: var(--dsw-alias-state-business-primary, #4c8dff);
}
.lxm-badge-gray {
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.15));
  color: var(--dsw-alias-label-tertiary, #999);
}
.lxm-dur { font-size: 11px; color: var(--dsw-alias-label-tertiary, #999); flex: none; font-variant-numeric: tabular-nums; }
.lxm-empty { color: var(--dsw-alias-label-tertiary, #999); font-size: 12px; text-align: center; padding: 24px 0; }
.lxm-toolbar { display: flex; gap: 6px; align-items: center; flex: none; flex-wrap: wrap; }
.lxm-toolbar .lxm-btn { width: auto; padding: 4px 10px; font-size: 12px; border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.2)); border-radius: 6px; }
.lxm-drag-handle { cursor: grab; color: var(--dsw-alias-label-tertiary, #666); font-size: 12px; flex: none; padding: 0 2px; }
.lxm-dragging { opacity: 0.4; }
.lxm-drop-hint { border-top: 2px solid var(--dsw-alias-state-business-primary, #4c8dff); }

.lxm-settings-grid { display: flex; flex-direction: column; gap: 14px; overflow-y: auto; flex: 1; min-height: 0; padding: 2px; }
.lxm-field { display: flex; flex-direction: column; gap: 4px; }
.lxm-field-label { font-size: 12px; color: var(--dsw-alias-label-secondary, #bbb); }
.lxm-field-hint { font-size: 11px; color: var(--dsw-alias-label-tertiary, #999); }
.lxm-switch-row { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
.lxm-switch {
  position: relative; width: 34px; height: 20px; border-radius: 10px; border: none; cursor: pointer;
  background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.3)); transition: background 0.15s;
}
.lxm-switch[data-on="true"] { background: var(--dsw-alias-state-business-primary, #4c8dff); }
.lxm-switch::after {
  content: ""; position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border-radius: 50%;
  background: #fff; transition: left 0.15s;
}
.lxm-switch[data-on="true"]::after { left: 16px; }
.lxm-source-row { display: flex; flex-direction: column; gap: 6px; padding: 8px 10px; border: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.15)); border-radius: 10px; }
.lxm-source-head { display: flex; align-items: center; gap: 8px; min-width: 0; }
.lxm-source-meta { flex: 1; min-width: 0; }
.lxm-source-name { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.lxm-source-sub { font-size: 11px; color: var(--dsw-alias-label-tertiary, #999); }
.lxm-source-status { font-size: 10px; padding: 1px 6px; border-radius: 4px; }
.lxm-source-status[data-ok="true"] { color: #3fb950; background: color-mix(in srgb, #3fb950 14%, transparent); }
.lxm-source-status[data-ok="false"] { color: #ff7b72; background: color-mix(in srgb, #ff7b72 14%, transparent); }
.lxm-prio-list { display: flex; flex-direction: column; gap: 2px; }
.lxm-prio-item { display: flex; align-items: center; gap: 6px; font-size: 12px; padding: 2px 4px; border-radius: 6px; }
.lxm-prio-item:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.1)); }
.lxm-section-title { font-size: 12px; font-weight: 600; color: var(--dsw-alias-label-secondary, #bbb); margin: 4px 0 0; }

/* ── 滚动歌词窗口（1.3.0）───────────────────────────────────────────────── */
.lxm-spacer { flex: 1; }
.lxm-btn-text[data-active="true"] {
  color: var(--dsw-alias-state-business-primary, #4c8dff);
  border-color: var(--dsw-alias-state-business-primary, #4c8dff);
}
.lxm-lyric-toolbar { flex-wrap: wrap; }
.lxm-lyric-song {
  font-size: 12px; color: var(--dsw-alias-label-secondary, #bbb);
  max-width: 42%; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.lxm-lyric-body {
  flex: 1; min-height: 0; overflow-y: auto; padding: 4px 10px;
  display: flex; flex-direction: column; gap: 2px;
  /* 歌词是"扫一眼就能读"的内容：行高放宽，滚动时不做字重突变，避免视觉跳动 */
  line-height: 1.7; scrollbar-gutter: stable;
}
/* 上下留白：让第一句/最后一句也能滚到视觉中心 */
.lxm-lyric-pad { flex: none; height: 45%; }
.lxm-lyric-line {
  flex: none; padding: 5px 8px; border-radius: 8px; cursor: pointer;
  color: var(--dsw-alias-label-tertiary, #999);
  transition: color 0.15s, background 0.15s;
  min-width: 0; overflow-wrap: anywhere;
}
.lxm-lyric-line:hover { background: var(--dsw-alias-interactive-bg-hover, rgba(128,128,128,0.1)); }
.lxm-lyric-line[data-past="true"] { color: var(--dsw-alias-label-secondary, #bbb); }
.lxm-lyric-line[data-active="true"] {
  color: var(--dsw-alias-label-primary, #e6e6e6);
  font-weight: 600;
  background: color-mix(in srgb, var(--dsw-alias-state-business-primary, #4c8dff) 12%, transparent);
}
.lxm-lyric-text { display: block; }
.lxm-lyric-word {
  color: var(--dsw-alias-label-secondary, #bbb);
  transition: color 0.12s;
}
.lxm-lyric-line[data-active="true"] .lxm-lyric-word[data-on="true"] {
  color: var(--dsw-alias-state-business-primary, #4c8dff);
}
.lxm-lyric-line[data-active="true"] .lxm-lyric-word[data-current="true"] {
  text-shadow: 0 0 10px color-mix(in srgb, var(--dsw-alias-state-business-primary, #4c8dff) 60%, transparent);
}
.lxm-lyric-tr {
  display: block; font-size: 0.82em; font-weight: 400;
  color: var(--dsw-alias-label-tertiary, #999);
}
.lxm-lyric-ro {
  display: block; font-size: 0.78em; font-weight: 400;
  color: var(--dsw-alias-label-tertiary, #888); opacity: 0.85;
}
.lxm-lyric-foot {
  flex: none; padding: 6px 12px;
  border-top: 1px solid var(--dsw-alias-border-l2, rgba(128,128,128,0.15));
  min-width: 0; overflow-wrap: anywhere;
}
`
