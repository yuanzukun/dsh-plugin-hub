/**
 * Recursive workspace scanning with include/ignore filtering, binary detection,
 * and size caps.
 *
 * The walk is iterative (explicit stack) in a deterministic order (entries
 * sorted by name). A file lands in the index when it:
 *   - is a file (not a symlink to a dir), is non-empty, and is under caps;
 *   - matches at least one `include` basename glob;
 *   - is not matched by any `ignore` rule;
 *   - contains no NUL bytes in its leading bytes (binary check).
 */

import { lstat, open, readFile, readdir } from 'node:fs/promises'
import { join, relative, sep } from 'node:path'
import { TextDecoder } from 'node:util'
import { languageForPath } from './languages.ts'

export interface ScannedFile {
  /** Absolute path. */
  path: string
  /** Root-relative path, forward slashes. */
  rel: string
  language: string
  size: number
  mtimeMs: number
  content: string
}

export interface ScanOptions {
  root: string
  /** Basename globs; a file matches when at least one matches its basename. */
  include: string[]
  /** Exact segment names and/or glob patterns (matched against the rel path). */
  ignore: string[]
  maxFileBytes: number
  /** Stop adding files once this many files have been indexed. */
  maxFiles: number
  /** Stop adding files once their total content bytes exceed this. */
  maxTotalBytes: number
  /** Skip reading file content (metadata-only; used by incremental refresh). */
  readContent?: boolean
  /** Stop scanning when the caller cancels the build. */
  signal?: AbortSignal
}

export interface ScanResult {
  files: ScannedFile[]
  /** True when scanning stopped early because a cap was reached. */
  truncated: boolean
  /** Files skipped: reason → count. */
  skipped: Map<string, number>
  /** Relative paths skipped because their content is binary. */
  skippedBinary: string[]
  /** Unreadable entries (permission, transient errors). */
  errors: string[]
}

/** Convert a glob (with `**` and `*`) into a RegExp. */
export function globToRegExp(pattern: string): RegExp {
  const fixed = pattern
    .replace(/[.+^${}()|[\]\\]/g, '\\$&')
    .replace(/\*\*\//g, '\u0000')
    .replace(/\*\*/g, '\u0001')
    .replace(/\*/g, '[^/]*')
    .replace(/\u0000/g, '(?:.*/)?')
    .replace(/\u0001/g, '.*')
  return new RegExp(`^${fixed}$`)
}

/** Whether an ignore rule swallows a rel path (forward-slash normalized). */
function isIgnored(rel: string, segments: string[], ignore: string[]): boolean {
  for (const rule of ignore) {
    if (rule.length === 0) continue
    if (rule.includes('*')) {
      if (globToRegExp(rule).test(rel)) return true
    } else if (segments.includes(rule)) {
      return true
    }
  }
  return false
}

/** Whether a basename matches at least one include glob. */
function isIncluded(basename: string, include: string[]): boolean {
  for (const pattern of include) {
    if (globToRegExp(pattern).test(basename)) return true
  }
  return false
}

/** Cheap binary detection: NUL bytes in the leading chunk. */
export function isBinaryContent(content: string): boolean {
  const head = content.slice(0, 8192)
  return head.includes('\u0000')
}

/** Measure decoded bytes and detect binary content without retaining the file. */
async function inspectContent(
  path: string,
  signal?: AbortSignal,
): Promise<{ binary: boolean; bytes: number }> {
  const handle = await open(path, 'r')
  try {
    const buffer = Buffer.alloc(64 * 1024)
    const decoder = new TextDecoder('utf-8', { ignoreBOM: true })
    let bytes = 0
    let headCodeUnits = 8192
    let position = 0
    while (true) {
      if (signal?.aborted) throw new Error('embedding aborted')
      const { bytesRead } = await handle.read(buffer, 0, buffer.length, position)
      if (bytesRead === 0) break
      position += bytesRead
      const content = decoder.decode(buffer.subarray(0, bytesRead), { stream: true })
      const head = content.slice(0, headCodeUnits)
      if (head.includes('\u0000')) return { binary: true, bytes: 0 }
      headCodeUnits -= head.length
      bytes += Buffer.byteLength(content, 'utf8')
    }
    if (signal?.aborted) throw new Error('embedding aborted')
    const tail = decoder.decode()
    if (tail.slice(0, headCodeUnits).includes('\u0000')) return { binary: true, bytes: 0 }
    bytes += Buffer.byteLength(tail, 'utf8')
    return { binary: false, bytes }
  } finally {
    await handle.close()
  }
}

/**
 * Scan a workspace tree.
 *
 * Order is deterministic (sorted sibling names). When a cap is hit, scanning
 * stops and `truncated` is set; callers should surface this in stats so users
 * know the index is partial.
 */
export async function scanWorkspace(opts: ScanOptions): Promise<ScanResult> {
  const { root } = opts
  const files: ScannedFile[] = []
  const skipped = new Map<string, number>()
  const skippedBinary: string[] = []
  const errors: string[] = []
  let truncated = false
  let totalBytes = 0
  const bump = (reason: string): void => {
    skipped.set(reason, (skipped.get(reason) ?? 0) + 1)
  }
  const throwIfAborted = (): void => {
    if (opts.signal?.aborted) throw new Error('embedding aborted')
  }

  throwIfAborted()
  const stack: string[] = [root]
  while (stack.length > 0) {
    throwIfAborted()
    const dir = stack.pop()!
    let entries
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch (error) {
      throwIfAborted()
      errors.push(`cannot read directory ${dir}: ${error instanceof Error ? error.message : String(error)}`)
      continue
    }
    throwIfAborted()
    entries.sort((a, b) => (a.name < b.name ? -1 : a.name > b.name ? 1 : 0))
    for (const entry of entries) {
      throwIfAborted()
      const abs = join(dir, entry.name)
      const rel = relative(root, abs).split(sep).join('/')
      const segments = rel.split('/')
      if (isIgnored(rel, segments, opts.ignore)) continue

      if (entry.isDirectory()) {
        stack.push(abs)
        continue
      }
      if (!entry.isFile()) continue

      if (files.length >= opts.maxFiles) {
        truncated = true
        return { files, truncated, skipped, skippedBinary, errors }
      }

      let stat
      try {
        stat = await lstat(abs)
      } catch (error) {
        throwIfAborted()
        errors.push(`cannot stat ${rel}: ${error instanceof Error ? error.message : String(error)}`)
        continue
      }
      throwIfAborted()
      if (!stat.isFile() || stat.size === 0) {
        if (!stat.isFile()) bump('non-file')
        else bump('empty')
        continue
      }
      if (!isIncluded(entry.name, opts.include)) {
        bump('not-included')
        continue
      }
      if (stat.size > opts.maxFileBytes) {
        bump('too-large')
        continue
      }

      const language = languageForPath(abs)?.name ?? 'text'

      if (opts.readContent === false) {
        let measurement: { binary: boolean; bytes: number }
        try {
          measurement = await inspectContent(abs, opts.signal)
        } catch (error) {
          throwIfAborted()
          errors.push(`cannot read ${rel}: ${error instanceof Error ? error.message : String(error)}`)
          continue
        }
        if (measurement.binary) {
          bump('binary')
          skippedBinary.push(rel)
          continue
        }
        if (totalBytes + measurement.bytes > opts.maxTotalBytes) {
          truncated = true
          return { files, truncated, skipped, skippedBinary, errors }
        }
        totalBytes += measurement.bytes
        files.push({
          path: abs,
          rel,
          language,
          size: stat.size,
          mtimeMs: stat.mtimeMs,
          content: '',
        })
        continue
      }

      let content: string
      try {
        content = await readFile(abs, { encoding: 'utf8', signal: opts.signal })
      } catch (error) {
        throwIfAborted()
        errors.push(`cannot read ${rel}: ${error instanceof Error ? error.message : String(error)}`)
        continue
      }
      throwIfAborted()
      if (isBinaryContent(content)) {
        bump('binary')
        skippedBinary.push(rel)
        continue
      }
      const contentBytes = Buffer.byteLength(content, 'utf8')
      if (totalBytes + contentBytes > opts.maxTotalBytes) {
        truncated = true
        return { files, truncated, skipped, skippedBinary, errors }
      }
      totalBytes += contentBytes

      files.push({
        path: abs,
        rel,
        language,
        size: stat.size,
        mtimeMs: stat.mtimeMs,
        content,
      })
    }
  }
  return { files, truncated, skipped, skippedBinary, errors }
}
