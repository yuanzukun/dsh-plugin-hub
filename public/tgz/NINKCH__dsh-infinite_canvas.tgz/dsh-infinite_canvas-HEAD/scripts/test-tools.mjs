#!/usr/bin/env node
/**
 * 对话工具契约测试（dev-only，不随包发布）。
 *
 * 覆盖两类事故：
 *  1) 静态：parameters 必须是标准 JSON Schema（属性级 required:true 是 defineTool 方言，会被 API 拒绝）
 *  2) 动态：真正执行每个工具的 execute()，把**返回值**与它声明的 output.schema 逐字段比对
 *     （第 2 类曾两次逃逸：返回值多字段 / 类型不符 → 整轮请求被 API 拒绝）
 *
 * 执行期使用临时目录（DSH_IC_PROJECTS_DIR / DSH_IC_CONFIG_PATH），不触碰真实画布数据。
 *
 * 运行：node scripts/test-tools.mjs
 * 退出码：0 = 通过；1 = 失败。
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import process from 'node:process';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const SANDBOX = fs.mkdtempSync(path.join(os.tmpdir(), 'dsh-ic-tools-'));
process.env.DSH_IC_PROJECTS_DIR = path.join(SANDBOX, 'projects');
process.env.DSH_IC_CONFIG_PATH = path.join(SANDBOX, 'config.json');

const errs = [];
const tools = [];
const providers = [];
const fakeSkills = { registerProvider: (fn) => { providers.push(fn()); return () => {}; } };
const fakeCtx = {
  effect(fn) { fn(); return () => {}; },
  get(name) { return name === 'skills' ? fakeSkills : undefined; },
  webServer: { register: () => () => {} },
  tools: { register: (def) => { tools.push(def); return () => {}; } },
};

const mod = await import(pathToFileURL(path.join(ROOT, 'index.js')).href);
try {
  mod.apply(fakeCtx);
} catch (e) {
  console.error('✗ apply(ctx) 执行失败：' + ((e && e.stack) || e));
  process.exit(1);
}
if (!tools.length) { console.error('✗ 没有捕获到任何工具'); process.exit(1); }

// ---------- 【DSH 铁律】工具结果必须"无损 JSON"（任何层级出现 undefined/NaN/Infinity 即非法）----------
// 此前 canvas_node_status 在无产物节点上返回 assetId: undefined → Agent 每次轮询必炸。
// 这里给每个工具的 execute 再包一层校验，让所有后续断言都跑在这条铁律之下。
function assertLossless(value, path, where) {
  if (value === undefined) { errs.push(`${where}: 结果含 undefined（${path}）→ DSH 判为非无损 JSON，整个结果作废`); return; }
  if (typeof value === 'number' && !Number.isFinite(value)) { errs.push(`${where}: 结果含 ${value}（${path}）`); return; }
  if (typeof value === 'function' || typeof value === 'symbol') { errs.push(`${where}: 结果含不可序列化值（${path}）`); return; }
  if (Array.isArray(value)) { value.forEach((v, i) => assertLossless(v, `${path}[${i}]`, where)); return; }
  if (value && typeof value === 'object') { for (const [k, v] of Object.entries(value)) assertLossless(v, `${path}.${k}`, where); }
}
for (const def of tools) {
  const inner = def.execute;
  def.execute = async (args, exec) => {
    const r = await inner(args, exec);
    assertLossless(r, '$', def.name);
    return r;
  };
}

// ---------- 静态：参数/输出 schema 必须是标准 JSON Schema ----------
function checkSchema(node, where) {
  if (!node || typeof node !== 'object' || Array.isArray(node)) { errs.push(`${where}: schema 必须是对象`); return; }
  if (node.required !== undefined && !Array.isArray(node.required)) {
    errs.push(`${where}.required 必须是字符串数组，收到 ${JSON.stringify(node.required)}（属性级 required:true 是 defineTool 方言，标准 JSON Schema 不接受）`);
  }
  if (Array.isArray(node.required) && node.properties) {
    for (const k of node.required) {
      if (!Object.prototype.hasOwnProperty.call(node.properties, k)) errs.push(`${where}.required 引用了不存在的属性: ${k}`);
    }
  }
  if (node.type !== undefined && typeof node.type !== 'string') errs.push(`${where}.type 必须是字符串`);
  if (node.enum !== undefined && !Array.isArray(node.enum)) errs.push(`${where}.enum 必须是数组`);
  for (const key of Object.keys(node)) {
    if (!['type', 'description', 'properties', 'required', 'items', 'enum', 'additionalProperties'].includes(key)) {
      errs.push(`${where}: 含有非标准 JSON Schema 关键字 "${key}"`);
    }
  }
  if (node.properties) for (const [k, v] of Object.entries(node.properties)) checkSchema(v, `${where}.properties.${k}`);
  if (node.items) checkSchema(node.items, `${where}.items`);
}

const TYPES = { string: 'string', number: 'number', integer: 'number', boolean: 'boolean', object: 'object', array: 'object' };
/** 用声明的 output.schema 校验实际返回值（必填、类型、additionalProperties:false 时的多余字段）。 */
function validateValue(schema, value, where) {
  if (!schema || typeof schema !== 'object') return;
  if (value === undefined || value === null) {
    if (Array.isArray(schema.required) && schema.required.length) errs.push(`${where}: 返回值为空但 schema 要求必填字段 ${schema.required.join(',')}`);
    return;
  }
  const want = TYPES[schema.type];
  if (want && typeof value !== want) { errs.push(`${where}: 期望 ${schema.type}，实际 ${typeof value}`); return; }
  if (schema.type === 'integer' && !Number.isInteger(value)) errs.push(`${where}: 期望 integer，实际 ${value}`);
  if (Array.isArray(schema.required)) {
    for (const k of schema.required) {
      if (value[k] === undefined) errs.push(`${where}: 缺少必填字段 "${k}"（实际字段：${Object.keys(value).join(',')}）`);
    }
  }
  if (schema.properties) {
    for (const [k, sub] of Object.entries(schema.properties)) {
      if (value[k] !== undefined) validateValue(sub, value[k], `${where}.${k}`);
    }
    if (schema.additionalProperties === false) {
      for (const k of Object.keys(value)) {
        if (!Object.prototype.hasOwnProperty.call(schema.properties, k)) errs.push(`${where}: 返回了未声明的字段 "${k}"，而 schema 声明 additionalProperties:false（会被 API 拒绝）`);
      }
    }
  }
  if (schema.type === 'array' && schema.items && Array.isArray(value)) {
    value.forEach((v, i) => validateValue(schema.items, v, `${where}[${i}]`));
  }
}

const byName = new Map();
const seen = new Set();
for (const t of tools) {
  const nm = t && t.name;
  if (!nm || !/^[a-z][a-z0-9_]*$/.test(nm)) { errs.push(`工具名不合法: ${JSON.stringify(nm)}`); continue; }
  if (seen.has(nm)) errs.push(`工具名重复: ${nm}`);
  seen.add(nm);
  byName.set(nm, t);
  if (typeof t.description !== 'string' || !t.description.trim()) errs.push(`${nm}: description 缺失`);
  if (typeof t.execute !== 'function') errs.push(`${nm}: execute 缺失`);
  if (!t.parameters || t.parameters.type !== 'object') errs.push(`${nm}: parameters 必须是 type=object`);
  else checkSchema(t.parameters, `${nm}.parameters`);
  if (!t.output || !t.output.schema || typeof t.output.render !== 'function') { errs.push(`${nm}: output.schema/render 缺失`); continue; }
  checkSchema(t.output.schema, `${nm}.output.schema`);
  try {
    const rendered = t.output.render({}, {});
    if (!Array.isArray(rendered) || !rendered.length || typeof rendered[0].text !== 'string') errs.push(`${nm}: output.render 返回值不是 [{ type:'text', text }]`);
  } catch (e) {
    errs.push(`${nm}: output.render 抛错 → ${(e && e.message) || e}`);
  }
}

// ---------- 动态：按依赖顺序真实执行，逐个校验返回值 ----------
async function run(name, args) {
  const t = byName.get(name);
  if (!t) { errs.push(`缺少工具: ${name}`); return null; }
  let value;
  try {
    value = await t.execute(args, {});
  } catch (e) {
    errs.push(`${name}.execute 抛错 → ${(e && e.message) || e}`);
    return null;
  }
  validateValue(t.output.schema, value, `${name} 返回值`);
  const brief = value ? { ...value, text: value.text ? String(value.text).slice(0, 36) + '…' : value.text } : value;
  console.log(`  ${name} → ${JSON.stringify(brief)}`);
  return value;
}

console.log(`捕获工具 ${tools.length} 个：${[...byName.keys()].join(', ')}`);

// ---------- 内置技能（操作规程 + 创作方法论）----------
try {
  if (providers.length !== 1) errs.push(`skills 提供方数量应为 1，实际 ${providers.length}`);
  const p = providers[0];
  if (!p || p.name !== 'dsh-infinite-canvas') errs.push('技能提供方 name 不正确');
  const list = await p.list();
  if (!Array.isArray(list) || list.length !== 6) errs.push(`技能列表应包含 6 个内置技能（四件套 + 导演工作坊 + 供应商适配器），实际 ${Array.isArray(list) ? list.length : '非数组'}`);
  const names = (list || []).map((c) => c && c.name).sort();
  if (names.join(',') !== 'canvas-craft,canvas-director,canvas-layout,canvas-provider,canvas-studio,director-workshop') errs.push('内置技能名应为 canvas-craft/canvas-director/canvas-layout/canvas-provider/canvas-studio/director-workshop，实际 ' + names.join(','));
  const needBySkill = {
    'canvas-studio': ['canvas_list_projects', 'canvas_write_node', 'canvas_create_project', 'canvas_get_bible', 'canvas_update_bible', 'canvas_create_node', '设定集先行', 'output'],
    'canvas-craft': ['景别', '运镜', '分镜', '提示词', '设定集'],
    'canvas-layout': ['一类型一列', 'canvas_relayout', '绝不重叠'],
    'canvas-provider': ['module.exports', 'generateImage', 'generateVideo', 'canvas_provider_validate', 'canvas_provider_save'],
    'director-workshop': ['导演', '启动仪式'],
  };
  for (const cand of list || []) {
    if (!Number.isFinite(cand.rank)) errs.push(`${cand.name}: 技能 rank 必须是有限数字（registry 强制要求）`);
    if (!cand.description || !cand.description.trim()) errs.push(`${cand.name}: 技能缺少 description`);
    if (!cand.invocation || cand.invocation.modelInvocable !== true) errs.push(`${cand.name}: 技能必须 modelInvocable（否则 Agent 无法加载）`);
    const got = await p.get(cand, {});
    if (!got.content || got.content.length < 300) errs.push(`${cand.name}: 技能正文过短，可能未正确解析 SKILL.md`);
    for (const need of needBySkill[cand.name] || []) {
      if (!String(got.content).includes(need)) errs.push(`${cand.name}: 技能正文未包含关键内容：${need}`);
    }
    if (got.rank !== undefined || got.locator !== undefined) errs.push(`${cand.name}: 技能 get() 应剥离 rank/locator 内部字段`);
    console.log(`  技能 ${cand.name}（rank=${cand.rank}，正文 ${got.content.length} 字）`);
  }
} catch (e) {
  errs.push('技能提供方校验失败 → ' + ((e && e.message) || e));
}

// ---------- 自定义供应商工具：validate → save → list → get → delete ----------
try {
  const providerSource = `module.exports = {
    id: "toolProvider",
    label: "工具供应商",
    fields: [{ key: "apiKey", label: "API Key", type: "password" }],
    models: [{ id: "img", label: "图片", type: "image" }],
    async generateImage(ctx, req) {
      return [{ mediaType: "image", type: "url", url: "https://example.com/a.png" }];
    },
  };`;
  const v = await byName.get('canvas_provider_validate').execute({ source: providerSource }, {});
  if (!v || !v.ok) errs.push('canvas_provider_validate 未通过：' + ((v && (v.error || v.text)) || '未知'));
  const saved = await byName.get('canvas_provider_save').execute({ source: providerSource }, {});
  if (!saved || !saved.ok) errs.push('canvas_provider_save 未通过：' + ((saved && (saved.error || saved.text)) || '未知'));
  const listed = await byName.get('canvas_provider_list').execute({}, {});
  if (!listed || !listed.providers || !listed.providers.some((p) => p.id === 'toolProvider')) errs.push('canvas_provider_list 未列出新适配器');
  const got = await byName.get('canvas_provider_get').execute({ id: 'toolProvider' }, {});
  if (!got || !got.ok || !String(got.source || '').includes('toolProvider')) errs.push('canvas_provider_get 未返回源码');
  const deleted = await byName.get('canvas_provider_delete').execute({ id: 'toolProvider', confirm: '删除 toolProvider' }, {});
  if (!deleted || !deleted.ok) errs.push('canvas_provider_delete 未通过');
} catch (e) {
  errs.push('自定义供应商工具链失败 → ' + ((e && e.message) || e));
}

console.log('执行契约测试（临时目录隔离）：');
const created = await run('canvas_create_project', { name: '__契约测试__', scriptText: '创作意图文本', nodeName: '创作意图' });
const projectId = created && created.projectId;

// 幂等：同名再建必须复用而不是新建（用户反馈的核心问题）
try {
  const again = await byName.get('canvas_create_project').execute({ name: '__契约测试__' }, {});
  if (!again || again.projectId !== projectId) errs.push('同名项目未复用（重复创建会把画布塞满空壳项目）');
  const all = await mod._internals.projectsList();
  if (all.length !== 1) errs.push(`同名创建后项目数应为 1，实际 ${all.length}`);
} catch (e) {
  errs.push('幂等创建校验失败 → ' + ((e && e.message) || e));
}

await run('canvas_list_projects', {});
const written = await run('canvas_write_node', { projectId, text: '第一节剧本：雨夜接信', name: '第一节剧本' });
const nodeId = written && written.nodeId;

// 设定集先行：读/写设定集与通用建节点
try {
  const b0 = await byName.get('canvas_get_bible').execute({ projectId }, {});
  if (!b0 || !b0.ok) errs.push('canvas_get_bible 未返回 ok');
  const bb = await mod._internals.canvasGetBible({ projectId });
  if (!bb || !bb.bible) errs.push('canvas_get_bible 未返回设定集');
  const w = await byName.get('canvas_update_bible').execute({
    projectId,
    bible: {
      worldview: '城市褶皱里的时空邮局', style: '写实电影感，暖色调',
      characters: [{ name: '陈拾', desc: '24 岁，旧邮差制服，帆布邮包' }],
      scenes: [{ name: '褶皱巷', desc: '雨夜老城区窄巷' }],
      props: [{ name: '火漆信', desc: '火漆印着邮戳' }],
    },
  }, {});
  if (!w || !w.ok) errs.push('canvas_update_bible 写入失败');
  // 合并语义：同名更新、不同名追加
  await byName.get('canvas_update_bible').execute({
    projectId,
    bible: { characters: [{ name: '陈拾', desc: '改：加了怀表' }, { name: '林小满', desc: '17 岁学生' }] },
  }, {});
  const b1 = await mod._internals.canvasGetBible({ projectId });
  const chars = b1.bible.characters || [];
  if (chars.length !== 2) errs.push(`设定集合并后角色数应为 2，实际 ${chars.length}`);
  const chen = chars.find((x) => x.name === '陈拾');
  if (!chen || !chen.desc.includes('怀表')) errs.push('设定集同名条目未更新');
  if (!b1.bible.worldview) errs.push('设定集世界观未保留');
  if (!b1.bibleUpdatedAt) errs.push('设定集缺少 bibleUpdatedAt（客户端无法感知同步）');
  // 通用建节点：角色参考图节点（合并后的 image 类型：有 prompt = 待生成的空节点）
  const n = await byName.get('canvas_create_node').execute({ projectId, type: 'image', name: '角色-陈拾 参考图', prompt: '中近景，陈拾，旧邮差制服' }, {});
  if (!n || !n.ok || !n.nodeId) errs.push('canvas_create_node 未返回 nodeId');
  const doc = await mod._internals.projectsGet({ id: projectId });
  const created = doc.nodes[n.nodeId];
  if (!created || created.type !== 'image') errs.push('canvas_create_node 未创建合并后的 image 节点');
  if (!created || !(created.data.prompt || '').includes('陈拾')) errs.push('canvas_create_node 未写入提示词');
  if (!created || created.data.label !== '角色-陈拾 参考图') errs.push('canvas_create_node 丢失了节点名（data.label 被覆盖）');
  if (!created || created.data.size !== '2K' || created.data.ratio !== '16:9') errs.push('image 节点缺少默认清晰度/比例');
  // 旧类型名兼容：image-gen / image-asset 必须自动映射为 image（旧项目与旧调用都能用）
  for (const legacy of ['image-gen', 'image-asset']) {
    const l = await byName.get('canvas_create_node').execute({ projectId, type: legacy, name: '旧名-' + legacy, prompt: 'x' }, {});
    const d = await mod._internals.projectsGet({ id: projectId });
    const ln = d.nodes[l.nodeId];
    if (!ln || ln.type !== 'image') errs.push('canvas_create_node 未把旧类型 ' + legacy + ' 映射为 image');
    if (!l.text || !l.text.includes('旧类型')) errs.push('canvas_create_node 未告知 ' + legacy + ' 已映射为合并节点');
  }

  // 新增：读节点（含对话框提示词与参数）→ 改节点（不必删节点重建）→ 触发不等待
  const st1 = await byName.get('canvas_node_status').execute({ projectId, nodeId: n.nodeId }, {});
  if (!st1 || !(st1.prompt || '').includes('陈拾')) errs.push('canvas_node_status 未返回生成节点的对话框提示词（prompt）');
  if (!st1 || st1.type !== 'image') errs.push('canvas_node_status 未按合并类型显示节点（期望 image，实际 ' + (st1 && st1.type) + '）');
  // 坐标必须可读：对话侧要能回答/判断节点位置与重叠（此前 x/y 只存在于文档，工具全部不透出）
  if (!st1 || !Number.isFinite(st1.x) || !Number.isFinite(st1.y)) errs.push('canvas_node_status 未返回节点坐标 x/y');
  if (!st1 || !Number.isFinite(st1.w) || !Number.isFinite(st1.h)) errs.push('canvas_node_status 未返回节点尺寸 w/h');
  if (!st1 || !/x=\d/.test(String(st1.text)) || !/y=\d/.test(String(st1.text))) errs.push('canvas_node_status 文本未渲染节点坐标');
  const lstAfterNode = await byName.get('canvas_list_projects').execute({}, {});
  const nodeLine = String(lstAfterNode && lstAfterNode.text || '').split(/\r?\n/).find((line) => line.includes(n.nodeId)) || '';
  if (!/x=\d/.test(nodeLine) || !/y=\d/.test(nodeLine)) errs.push('canvas_list_projects 节点摘要未透出坐标 x/y：' + nodeLine);
  const up = await byName.get('canvas_update_node').execute({
    projectId, nodeId: n.nodeId,
    patch: { prompt: '特写，陈拾，雨夜，旧邮差制服', ratio: '9:16', size: '2K', duration: 5, resolution: '1080P', id: '不可改' },
  }, {});
  if (!up || !up.ok) errs.push('canvas_update_node 未返回 ok');
  const doc2 = await mod._internals.projectsGet({ id: projectId });
  const nd2 = doc2.nodes[n.nodeId];
  if (!nd2 || nd2.data.prompt !== '特写，陈拾，雨夜，旧邮差制服') errs.push('canvas_update_node 未改到提示词');
  if (!nd2 || nd2.data.ratio !== '9:16' || nd2.data.size !== '2K') errs.push('canvas_update_node 未改到生成参数');
  if (!nd2 || nd2.data.duration !== 5 || nd2.data.resolution !== '1080P') errs.push('canvas_update_node 数值/分辨率字段未生效');
  if (nd2 && nd2.id !== n.nodeId) errs.push('canvas_update_node 误改了结构字段 id');
  try {
    await byName.get('canvas_update_node').execute({ projectId, nodeId: n.nodeId, patch: { x: 999 } }, {});
    errs.push('canvas_update_node 对不可改字段应报错而不是静默');
  } catch { /* 预期：无可用字段时报错 */ }
  const gen = await byName.get('canvas_generate_node').execute({ projectId, nodeId: n.nodeId, waitSeconds: 0 }, {});
  if (!gen || !gen.ok) errs.push('canvas_generate_node 触发未返回 ok');
} catch (e) {
  errs.push('设定集/建节点校验失败 → ' + ((e && e.message) || e));
}

// 剧本节点语义：写 output 不带 nodeId 必须复用已有剧本节点（idea 与 output 落在同一节点），
// 且 idea 参数能与 text/target 一次写全 —— 直接对应用户反馈的"两个半残节点"问题
try {
  const before = await mod._internals.projectsGet({ id: projectId });
  const beforeScripts = Object.values(before.nodes).filter((n) => n.type === 'script').length;
  const w = await byName.get('canvas_write_node').execute({ projectId, text: '第一版成稿', target: 'output', name: '第一节剧本' }, {});
  const after = await mod._internals.projectsGet({ id: projectId });
  const afterScripts = Object.values(after.nodes).filter((n) => n.type === 'script').length;
  if (afterScripts !== beforeScripts) errs.push(`写 output 时新建了剧本节点（${beforeScripts} → ${afterScripts}）：应当复用已有剧本节点`);
  const t0 = after.nodes[w.nodeId];
  if (!t0) errs.push('写入返回的 nodeId 在文档中不存在');
  else {
    if (!String(t0.data.output || '').trim()) errs.push('成稿未写入 output');
    if (!String(t0.data.idea || '').trim()) errs.push('复用后该剧本节点仍缺少 idea（出现"只有结果"的半残节点）');
  }
  // 已写成稿的节点：不带 overwrite 必须拒绝覆盖（防止对话静默吃掉用户稿件）
  let blocked = false;
  try {
    await byName.get('canvas_write_node').execute({ projectId, nodeId: w.nodeId, text: '误覆盖', target: 'output' }, {});
  } catch { blocked = true; }
  if (!blocked) errs.push('已写成稿的节点被无 overwrite 的写入覆盖：应拒绝并提示');
  const w2 = await byName.get('canvas_write_node').execute({ projectId, nodeId: w.nodeId, text: '第二版成稿', target: 'output', idea: '第二版意图', overwrite: true }, {});
  const doc2 = await mod._internals.projectsGet({ id: projectId });
  const n2 = doc2.nodes[w2.nodeId];
  if (!n2 || n2.data.output !== '第二版成稿' || n2.data.idea !== '第二版意图') errs.push('idea 参数未与 text/target 同时生效（无法一次写全意图与成稿）');
  // name 匹配不到时必须新建节点（而不是给旧节点改名后覆盖）
  const before3 = Object.values(doc2.nodes).filter((n) => n.type === 'script').length;
  const w3 = await byName.get('canvas_write_node').execute({ projectId, text: '第二节创作意图', name: '第二节' }, {});
  const doc3 = await mod._internals.projectsGet({ id: projectId });
  const after3 = Object.values(doc3.nodes).filter((n) => n.type === 'script').length;
  if (after3 !== before3 + 1) errs.push(`name 匹配不到时应新建剧本节点（${before3} → ${after3}）`);
  if (w3.nodeId === w.nodeId) errs.push('name 匹配不到时复用了旧节点（会给旧节点改名并覆盖稿件）');
  if (String(doc3.nodes[w.nodeId].data.output || '') !== '第二版成稿') errs.push('新建节点时旧节点的成稿被改动');
  // 分镜必须用分镜表节点：创建时**自动连线**到已有剧本（二选一：有连线不收 prompt/粘贴）
  const sb = await byName.get('canvas_create_node').execute({ projectId, type: 'storyboard', name: '第一节分镜表', prompt: '这段提示词应被忽略' }, {});
  const docSb = await mod._internals.projectsGet({ id: projectId });
  const sbNode = docSb.nodes[sb.nodeId];
  if (!sbNode || sbNode.type !== 'storyboard') errs.push('storyboard 节点类型不正确');
  const autoEdge = (docSb.edges || []).find((e) => e.toNode === sb.nodeId && e.toPort === 'script');
  if (!autoEdge) errs.push('分镜表节点未自动连线到上游剧本（二选一约束失效）');
  if (sbNode && String(sbNode.data.script || '').trim()) errs.push('已连线的分镜表仍接收了 prompt 文本（连线与提示词未二选一）');
  // 已连线的分镜表：拒绝把剧本文本粘贴进来（内容只从连线取）
  let wiredBlocked = false;
  try { await byName.get('canvas_write_node').execute({ projectId, nodeId: sb.nodeId, target: 'output', text: '手写剧本来源', overwrite: true }, {}); } catch { wiredBlocked = true; }
  if (!wiredBlocked) errs.push('已连线的分镜表被写入了粘贴的剧本来源（应拒绝，连线与粘贴二选一）');
  // shots JSON 写入不受二选一限制（这是分镜的输出通道）：落到 data.shots 而非 output。
  // 夹具必须通过 G2 质量闸门（时长/画面/景别/大特写/衔接字段），否则后续建视频节点会被闸门拒绝
  const shotsJson = JSON.stringify({ shots: [
    { title: '镜1', visual: '中景，雨夜巷口，陈拾收伞回望', motion: '横移跟随', characters: ['陈拾'], scene: '巷口', props: [], duration: 3, seg: 'opening', tail: '陈拾转身欲走', cam: '横移回正', start: '' },
    { title: '镜2', visual: '大特写，火漆信上的邮戳裂开', motion: '缓推', characters: [], scene: '巷口', props: ['火漆信'], duration: 2, seg: 'closeup', tail: '邮戳裂开定格', cam: '推进到位', start: '特写起幅' },
  ] });
  await byName.get('canvas_write_node').execute({ projectId, nodeId: sb.nodeId, target: 'output', text: shotsJson, overwrite: true }, {});
  const docSb3 = await mod._internals.projectsGet({ id: projectId });
  if (!docSb3.nodes[sb.nodeId] || !Array.isArray(docSb3.nodes[sb.nodeId].data.shots) || docSb3.nodes[sb.nodeId].data.shots.length !== 2) errs.push('shots JSON 未写入分镜节点的 data.shots');
  // 分镜参数读面（0.20.5 补注册）：canvas_update_node 写 targetDuration/combatMode/cont 后
  // canvas_node_status 必须能读回——写面有读面无 = 对话侧不可发现（2026-11-11 审计缺口）。
  {
    await byName.get('canvas_update_node').execute({ projectId, nodeId: sb.nodeId, patch: { targetDuration: 15, combatMode: 'on', cont: true } }, {});
    const st = await byName.get('canvas_node_status').execute({ projectId, nodeId: sb.nodeId }, {});
    if (!st || st.targetDuration !== 15) errs.push('canvas_node_status 未读回 targetDuration（写面有读面无）');
    if (!st || st.combatMode !== 'on') errs.push('canvas_node_status 未读回 combatMode（写面有读面无）');
    if (!st || st.cont !== true) errs.push('canvas_node_status 未读回 cont（写面有读面无）');
    if (st && !/总时长硬约束 15s/.test(String(st.text))) errs.push('canvas_node_status 文本未渲染总时长硬约束');
    if (st && !/打斗判定 on/.test(String(st.text))) errs.push('canvas_node_status 文本未渲染打斗判定');
    // 非法值宽松归一：combatMode 非三态值 → 归一为 auto（与 cont 宽松归一同口径；抛错会中断整个 patch）
    await byName.get('canvas_update_node').execute({ projectId, nodeId: sb.nodeId, patch: { combatMode: 'xyz' } }, {});
    const stBad = await byName.get('canvas_node_status').execute({ projectId, nodeId: sb.nodeId }, {});
    if (!stBad || stBad.combatMode !== 'auto') errs.push('canvas_update_node 收到非法 combatMode 未归一为 auto（得到 ' + (stBad && stBad.combatMode) + '）');
  }
  // 连线工具：剧本 → 分镜表（工作流的核心，必须有边且类型校验生效）
  const scriptNode = Object.values(docSb3.nodes).find((n) => n.type === 'script' && n.data.label === '第一节剧本');
  const conn = await byName.get('canvas_connect').execute({ projectId, fromNode: scriptNode.id, toNode: sb.nodeId }, {});
  if (!conn || !conn.ok || !conn.edgeId) errs.push('canvas_connect 未返回 edgeId');
  const docC = await mod._internals.projectsGet({ id: projectId });
  const edge = (docC.edges || []).find((e) => e.id === conn.edgeId);
  if (!edge || edge.fromNode !== scriptNode.id || edge.toNode !== sb.nodeId || edge.toPort !== 'script') errs.push('连线未正确写入文档边');
  let mismatchBlocked = false;
  try { await byName.get('canvas_connect').execute({ projectId, fromNode: sb.nodeId, toNode: scriptNode.id }, {}); } catch { mismatchBlocked = true; }
  if (!mismatchBlocked) errs.push('storyboard→script 连线未被拒绝（剧本节点没有输入端口）');
  // connectFrom：创建即连线（分镜表连到剧本节点）
  const sb2 = await byName.get('canvas_create_node').execute({ projectId, type: 'storyboard', name: '第二节分镜表', connectFrom: scriptNode.id }, {});
  const docCf = await mod._internals.projectsGet({ id: projectId });
  const cfEdge = (docCf.edges || []).find((e) => e.fromNode === scriptNode.id && e.toNode === sb2.nodeId && e.toPort === 'script');
  if (!cfEdge) errs.push('connectFrom 未在创建时自动连线');
  // 多镜头工作流：video（合并类型）无 prompt + 项目里有分镜表 → 自动连到分镜表（优先有镜头的，多镜头提示词从连线取）
  const vg = await byName.get('canvas_create_node').execute({ projectId, type: 'video', name: '第二节多镜头视频' }, {});
  const docVg = await mod._internals.projectsGet({ id: projectId });
  if (!docVg.nodes[vg.nodeId] || docVg.nodes[vg.nodeId].type !== 'video') errs.push('canvas_create_node 未创建合并后的 video 节点');
  const vgEdge = (docVg.edges || []).find((e) => e.toNode === vg.nodeId && e.toPort === 'prompt' && docVg.nodes[e.fromNode] && docVg.nodes[e.fromNode].type === 'storyboard');
  if (!vgEdge) errs.push('video 未自动连线到上游分镜表（多镜头一次性生成工作流失效）');
  if (vgEdge && vgEdge.fromNode !== sb.nodeId) errs.push('video 自动连线未优先选择有镜头的分镜表');
  if (docVg.nodes[vg.nodeId] && String(docVg.nodes[vg.nodeId].data.prompt || '').trim()) errs.push('已连线的 video 仍写入了 prompt（连线与提示词未二选一）');
  // G3 一表一视频：同一分镜表的第二个视频节点被拒绝（改参数走 canvas_update_node，不新建）
  const vg2 = await byName.get('canvas_create_node').execute({ projectId, type: 'video-gen', name: '第二节单镜头视频', prompt: '固定镜头，猫跳上柜台' }, {});
  if (!vg2 || vg2.ok !== false || vg2.gate !== 'G3') errs.push('同一分镜表的第二个 video 未被 G3 拒绝（一表一视频闸门失效）');
  if (vg2 && !vg2.existingVideoId) errs.push('G3 拒绝结果未指回既有视频节点（existingVideoId）');
  // G3/G2 逃生舱：override（用户显式 + 原话）放行——用户明确要求时永远可以，但必须留审计
  const vgOv = await byName.get('canvas_create_node').execute({ projectId, type: 'video', name: '第二节 override 版本', override: { by: 'user-explicit', quote: '用户：我就要再建一个版本对比着看' } }, {});
  if (!vgOv || vgOv.ok !== true || !vgOv.nodeId) errs.push('G3 override 未放行（用户显式指令应优先）');
  // 连线工具可用性：手动连 sb2 → override 版视频（单线输入端口替换语义）
  const connSbVg = await byName.get('canvas_connect').execute({ projectId, fromNode: sb2.nodeId, toNode: vgOv.nodeId }, {});
  if (!connSbVg || !connSbVg.edgeId) errs.push('分镜表 → 视频生成 连线被拒（storyboard 应有文本输出口）');
} catch (e) {
  errs.push('剧本节点语义校验失败 → ' + ((e && e.message) || e));
}
await run('canvas_write_node', { projectId, nodeId, text: '成稿内容……', target: 'output', overwrite: true });
await run('canvas_run_node', { projectId, nodeId });
await run('canvas_node_status', { projectId, nodeId });
await run('canvas_open', { projectId });
await run('canvas_delete_node', { projectId, nodeId, confirm: '清理这个测试节点' });
// 删除的节点必须留墓碑（否则客户端按本地内容推送会把它复活）
try {
  const afterDel = await mod._internals.projectsGet({ id: projectId });
  if (afterDel.nodes[nodeId]) errs.push('canvas_delete_node 后节点仍在文档里');
  if (!Array.isArray(afterDel.tombstones) || !afterDel.tombstones.includes(nodeId)) errs.push('canvas_delete_node 未写入墓碑（tombstones）');
} catch (e) {
  errs.push('墓碑校验失败 → ' + ((e && e.message) || e));
}
// 3D-BOX 自然语言改景：注入假 LLM，验证 action=edit 写回 + 校验失败可见
try {
  mod._internals.setDataRoot(path.join(SANDBOX, 'data'));
  const spec0 = { title: 'edit-test', duration: 5, characters: [{ name: 'A', pos: [0, 0, 0] }], cameras: [{ name: 'c', pos: [0, 2, 6], target: [0, 1, 0], fov: 42 }], shots: [{ camera: 'c', start: 0, end: 5 }] };
  const a0 = await byName.get('canvas_director_stage').execute({ action: 'apply', projectId, spec: spec0 }, {});
  if (!a0 || !a0.ok) throw new Error('apply failed');
  const spec1 = JSON.parse(JSON.stringify(spec0));
  spec1.cameras[0].pos = [0, 1.1, 6];
  spec1.duration = 6;
  spec1.models = [{ assetId: 'not_a_local_asset', pos: [0, 0, 0] }];
  mod._internals.__auto.setRoomLlm(async () => JSON.stringify(spec1));
  const ed = await byName.get('canvas_director_stage').execute({ action: 'edit', projectId, instruction: '机位低一点，时长改成6秒' }, {});
  if (!ed || !ed.ok) throw new Error('edit failed');
  if (!ed.spec || ed.spec.cameras[0].pos[1] !== 1.1) throw new Error('edit spec not applied');
  if (Array.isArray(ed.spec.models) && ed.spec.models.length) throw new Error('edit accepted an invented assetId');
  const got = await byName.get('canvas_director_stage').execute({ action: 'get', projectId }, {});
  if (!got || !got.spec || got.spec.duration !== 6) throw new Error('edit not persisted');
  mod._internals.__auto.setRoomLlm(async () => 'not json');
  let bad = false;
  try { await byName.get('canvas_director_stage').execute({ action: 'edit', projectId, instruction: '乱改' }, {}); } catch { bad = true; }
  if (!bad) throw new Error('invalid LLM output was accepted');
  // AI 运镜：自然语言 → {keys:[...]}，校验后写回
  mod._internals.__auto.setRoomLlm(async () => JSON.stringify({ keys: [
    { t: 0, pos: [0, 1.1, 6], target: [0, 1, 0], fov: 42 },
    { t: 3, pos: [2, 1.4, 5], target: [0, 1, 0], fov: 40 },
  ] }));
  const cam = await byName.get('canvas_director_stage').execute({ action: 'camera', projectId, prompt: '环绕香水瓶，最后推近' }, {});
  if (!cam || !cam.ok) throw new Error('AI camera failed');
  if (!cam.spec || !cam.spec.cameras[0].keys || cam.spec.cameras[0].keys.length !== 2) throw new Error('AI camera keys not applied');
  if (!cam.spec.cameraPrompt) throw new Error('AI camera prompt not recorded');
  mod._internals.__auto.setRoomLlm(async () => JSON.stringify({ keys: [{ t: 0, pos: [0, 1, 0] }] }));
  let badCam = false;
  try { await byName.get('canvas_director_stage').execute({ action: 'camera', projectId, prompt: '乱运镜' }, {}); } catch { badCam = true; }
  if (!badCam) throw new Error('invalid AI camera keys was accepted');
  // 3D-BOX 库：AI brief 生成完整 spec；同一项目多次生成必须保留多条 stage
  const rpc = mod._internals.rpcMethods();
  const aiSpec = (title, name) => JSON.stringify({
    title, duration: 6,
    characters: [{ name, pos: [-1, 0, 0], rotY: 1, clip: 'run', path: [[-1, 0], [4, 0]], locomotion: { source: 'clip', clip: 'run', stride: 1.1, cycle: 0.8, refSpeed: 4 } }],
    models: [{ assetId: 'bld_a', pos: [-5, 0, -2], h: 12 }],
    props: [
      { name: '路面', preset: 'plane', pos: [0, 0, 0], scale: [20, 1, 8], color: '#9aa3ad' },
      { name: '警车', pos: [2, 0, 1], parts: [
        { preset: 'box', pos: [0, 0.35, 0], scale: [4, 0.7, 1.8], color: '#15181d' },
        { preset: 'box', pos: [0, 1.05, 0], scale: [2, 0.7, 1.6], color: '#2f6fed' },
        { preset: 'not_a_preset', pos: [0, 1.4, 0], scale: [0.8, 0.2, 0.4], color: '#ff2d2d' },
      ] },
      { name: '手枪', preset: 'box', pos: [0, 1, 0], scale: [0.08, 0.12, 0.3], attach: { to: '警', bone: 'RightHand', offset: [0, 0, 0.12] } },
    ],
    cameras: [{ name: '跟拍', pos: [0, 1.6, 6], target: [0, 1, 0], fov: 40 }],
    shots: [{ camera: '跟拍', start: 0, end: 6 }],
  });
  mod._internals.__auto.setRoomLlm(async () => aiSpec('AI 追车 A', '警'));
  const briefR = await rpc.directorStageBrief({ projectId, brief: '城市街头警匪追车，6秒' });
  if (!briefR || !briefR.ok) throw new Error('directorStageBrief failed');
  if (briefR.source !== 'llm' || !briefR.stageId) throw new Error('brief did not use AI or stageId missing');
  if (!briefR.spec || !briefR.spec.characters || !briefR.spec.characters[0].path) throw new Error('AI brief did not produce action staging');
  if (!briefR.spec.models || briefR.spec.models[0].assetId !== 'bld_a' || briefR.spec.models[0].h !== 12) throw new Error('AI brief did not use local model assets');
  const carProp = (briefR.spec.props || []).find((p) => p.name === '警车');
  if (!carProp || !Array.isArray(carProp.parts) || carProp.parts.length !== 3) throw new Error('AI brief did not keep parametric parts');
  if (carProp.parts[2].preset !== 'box') throw new Error('invalid part preset was not normalized');
  const gunProp = (briefR.spec.props || []).find((p) => p.name === '手枪');
  if (!gunProp || !gunProp.attach || gunProp.attach.bone !== 'RightHand') throw new Error('AI brief dropped bone attachment');
  // AI 失败兜底：本地模板 + enrich，追车 brief 至少要补一台参数化警车
  mod._internals.__auto.setRoomLlm(async () => 'not json at all');
  const fb = await rpc.directorStageBrief({ projectId, brief: '夜晚街头警匪追车，6秒' });
  if (!fb || !fb.ok || fb.source !== 'fallback' || !fb.warning) throw new Error('brief fallback did not degrade visibly');
  const fbCar = ((fb.spec && fb.spec.props) || []).find((p) => p.name === '警车');
  if (!fbCar || !Array.isArray(fbCar.parts) || fbCar.parts.length < 5) throw new Error('fallback brief did not add a parametric police car');
  mod._internals.__auto.setRoomLlm(async () => aiSpec('AI 追车 B', '匪'));
  const briefR2 = await rpc.directorStageBrief({ projectId, brief: '另一条追车，6秒' });
  if (!briefR2 || !briefR2.ok || !briefR2.stageId || briefR2.stageId === briefR.stageId) throw new Error('second brief did not create a new stage');
  const listR = await rpc.directorStageList();
  if (!listR || !listR.ok || !Array.isArray(listR.items) || !listR.items.some((x) => x.projectId === projectId)) throw new Error('directorStageList missing current project');
  const stages = listR.items.filter((x) => x.projectId === projectId && x.stageId);
  if (stages.length < 2) throw new Error('old 3D-BOX stages disappeared from the library');
  const firstLoad = await rpc.directorStageLoad({ projectId, stageId: briefR.stageId });
  if (!firstLoad || !firstLoad.ok || !firstLoad.found || firstLoad.spec.title !== 'AI 追车 A') throw new Error('first stage no longer loadable after a new brief');
  // 运镜/转场预设库：清单 + 施加
  const presets = await byName.get('canvas_list_presets').execute({ kind: 'transition' }, {});
  if (!presets || !presets.ok || !Array.isArray(presets.presets) || !presets.presets.some((x) => x.id === 'travel_zoom_in')) throw new Error('canvas_list_presets missing transition preset');
  const applied = await byName.get('canvas_apply_preset').execute({ projectId, presetId: 'travel_zoom_in' }, {});
  if (!applied || !applied.ok || !applied.spec || applied.spec.motionPreset !== 'travel_zoom_in') throw new Error('canvas_apply_preset failed');
  if (!applied.spec.cameras || !applied.spec.cameras[0].keys || applied.spec.cameras[0].keys.length < 2) throw new Error('canvas_apply_preset did not create camera keys');
  const priceR = await rpc.productionPrice();
  if (!priceR || !priceR.ok || typeof priceR.price !== 'number') throw new Error('productionPrice RPC failed');
} catch (e) {
  errs.push('3D-BOX 自然语言改景失败 → ' + ((e && e.message) || e));
} finally {
  mod._internals.__auto.setRoomLlm(async () => '');
}
// Agent 素材导入/挂载：本地文件 → 资产库 → image 节点 assetId（create + update）
try {
  const importPath = path.join(SANDBOX, 'import-test.png');
  fs.writeFileSync(importPath, Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]));
  const imp = await byName.get('canvas_import_asset').execute({ projectId, path: importPath, kind: 'image', name: '导入测试图' }, {});
  if (!imp || !imp.ok || !imp.assetId) throw new Error('canvas_import_asset failed');
  const listA = await byName.get('canvas_list_assets').execute({ projectId }, {});
  if (!listA || !listA.ok || !Array.isArray(listA.assets) || !listA.assets.some((a) => a.id === imp.assetId)) throw new Error('canvas_list_assets missing imported asset');
  const nodeA = await byName.get('canvas_create_node').execute({ projectId, type: 'image', name: '导入素材节点', assetId: imp.assetId }, {});
  const stA = await byName.get('canvas_node_status').execute({ projectId, nodeId: nodeA.nodeId }, {});
  if (!stA || stA.assetId !== imp.assetId) throw new Error('canvas_create_node assetId not applied');
  const nodeB = await byName.get('canvas_create_node').execute({ projectId, type: 'image', name: '挂载素材节点' }, {});
  await byName.get('canvas_update_node').execute({ projectId, nodeId: nodeB.nodeId, patch: { assetId: imp.assetId } }, {});
  const stB = await byName.get('canvas_node_status').execute({ projectId, nodeId: nodeB.nodeId }, {});
  if (!stB || stB.assetId !== imp.assetId) throw new Error('canvas_update_node assetId not applied');
  // 音频节点 + 成片 audio 输入：默认连线应落到 audio 端口
  const audioPath = path.join(SANDBOX, 'import-test.mp3');
  fs.writeFileSync(audioPath, Buffer.from([0x49, 0x44, 0x33, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]));
  const impA = await byName.get('canvas_import_asset').execute({ projectId, path: audioPath, kind: 'audio', name: '导入测试音频' }, {});
  if (!impA || !impA.ok || !impA.assetId) throw new Error('audio import failed');
  const audioNode = await byName.get('canvas_create_node').execute({ projectId, type: 'audio', name: 'BGM', assetId: impA.assetId }, {});
  const stAudio = await byName.get('canvas_node_status').execute({ projectId, nodeId: audioNode.nodeId }, {});
  if (!stAudio || stAudio.type !== 'audio' || stAudio.assetId !== impA.assetId) throw new Error('audio node not created with assetId');
  const finalNode = await byName.get('canvas_create_node').execute({ projectId, type: 'finalcut', name: '成片测试' }, {});
  const edgeA = await byName.get('canvas_connect').execute({ projectId, fromNode: audioNode.nodeId, toNode: finalNode.nodeId }, {});
  if (!edgeA || !edgeA.edgeId) throw new Error('audio → finalcut connect failed');
  const docA = await mod._internals.projectsGet({ id: projectId });
  const ae = (docA.edges || []).find((e) => e.id === edgeA.edgeId);
  if (!ae || ae.toPort !== 'audio') throw new Error('audio → finalcut did not land on audio port');
} catch (e) {
  errs.push('Agent 素材导入/挂载失败 → ' + ((e && e.message) || e));
}
await run('canvas_delete_project', { projectId, confirm: '删除整个测试项目' });

// 运行/打开请求与删除通知必须一次性消费（projectsSync 读走即清空）
try {
  const sync1 = await mod._internals.projectsSync();
  const sync2 = await mod._internals.projectsSync();
  if (!sync1.runRequest) errs.push('canvas_run_node 写入的 runRequest 未被 projectsSync 读到');
  if (!Array.isArray(sync1.deletedProjects) || !sync1.deletedProjects.includes(projectId)) errs.push('canvas_delete_project 未通知客户端删除（deletedProjects）');
  if (sync2.runRequest || sync2.openRequest || sync2.deletedProjects) errs.push('projectsSync 未一次性消费 openRequest/runRequest/deletedProjects');
} catch (e) {
  errs.push('projectsSync 消费行为校验失败 → ' + ((e && e.message) || e));
}

try { fs.rmSync(SANDBOX, { recursive: true, force: true }); } catch { /* 忽略 */ }

if (errs.length) {
  console.error(`\n✗ 工具契约测试未通过（${errs.length} 项）：`);
  for (const e of errs) console.error('  - ' + e);
  process.exit(1);
}
console.log('\n✓ 工具 schema 与返回值契约全部通过');
process.exit(0);
