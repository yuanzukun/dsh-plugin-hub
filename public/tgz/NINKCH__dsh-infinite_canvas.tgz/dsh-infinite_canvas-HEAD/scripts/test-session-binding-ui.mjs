#!/usr/bin/env node
/**
 * 会话↔画布绑定 UI 结构契约测试（dev-only，源码级断言）：
 *  1) composer 注入：slots.inject('conversation.input.left') 存在，且带 try/catch 旧 runner 守卫
 *  2) 三态 chip：建画布项目 / 绑画布(未绑) / 已绑定锁定的渲染分支与 i18n key 双语齐全
 *  3) RPC 数据面：sessionBindingGet / sessionBindingSet / sessionBindingClear / workspaceProjectCreate 四个调用齐全
 *  4) 会话广播与跟随：S.activeSessionId 上报 + bindingRev 驱动画布面板跟随（pane 宿主守卫）+ 绑定打开走 hydrate
 *  5) 占用提示：占用画布在菜单里标「已被其他会话占用」
 * 运行：node scripts/test-session-binding-ui.mjs（退出码 0=通过）
 */
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = readFileSync(path.join(ROOT, 'client.js'), 'utf8');
const errs = [];
const ok = (c, m) => { if (!c) errs.push(m); };

// ---------------- 1) composer 注入 + 守卫 ----------------
{
  const i = src.indexOf("slots.inject('conversation.input.left'");
  ok(i >= 0, '缺少 conversation.input.left 槽位注入（composer 画布选择器）');
  if (i >= 0) {
    const tail = src.slice(Math.max(0, i - 300), i + 900); // try 包在注入之前，窗口向后扩
    ok(/try\s*\{/.test(tail) && /catch/.test(tail), 'conversation.input.left 注入必须包 try/catch（旧 runner 降级）');
    ok(/旧 runner|旧宿主|降级/.test(tail), '注入处缺降级注释/守卫说明');
  }
}

// ---------------- 2) 三态 + i18n 双语 ----------------
const KEYS = [
  'bindSessionOnly', 'bindCreateProjectAction', 'bindOpenCanvas', 'bindNewCanvas',
  'bindNewCanvasPlaceholder', 'bindOccupied', 'bindFail', 'bindCreating', 'bindHostStale', 'bindChipBound',
];
{
  const mZh = /const DICT_ZH = \{/.exec(src);
  const mEn = /const DICT_EN = \{/.exec(src);
  const zhStart = mZh ? mZh.index : -1;
  const enStart = mEn ? mEn.index : -1;
  ok(zhStart >= 0 && enStart >= 0 && zhStart < enStart, 'DICT_ZH / DICT_EN 字典缺失');
  if (zhStart >= 0 && enStart >= 0) {
    for (const k of KEYS) {
      const re = new RegExp("('" + k + "')\\s*:");
      ok(re.test(src.slice(zhStart, enStart)), 'DICT_ZH 缺 key：' + k);
      ok(re.test(src.slice(enStart)), 'DICT_EN 缺 key：' + k);
    }
    // 绑定文案禁止括号注释（「这是功能，不是草稿纸」）：绑定 key 的值里不得出现中文/英文括号
    const bindLines = src.slice(zhStart, enStart).split('\n').filter((l) => /'bind[A-Z]/.test(l));
    ok(bindLines.length > 0, '找不到绑定文案行');
    for (const l of bindLines) ok(!/[（(]/.test(l), '绑定文案含括号注释：' + l.trim());
  }
  for (const k of ['bindSessionOnly', 'bindOpenCanvas', 'bindChipBound', 'bindHostStale']) {
    ok(src.includes("T('" + k + "')"), 'key ' + k + ' 未在渲染代码中使用');
  }
  // 未绑定态 chip 显示当前选中值「仅会话」（禁止显示提示语「选择画布」）
  ok(/S\.bindingCreating \? T\('bindCreating'\) : T\('bindSessionOnly'\)/.test(src), '未绑定态 chip 未显示「仅会话」选中值');
  ok(!/'bindChipSelect'/.test(src), 'bindChipSelect 提示语残留（chip 必须显示选中值）');
}

// ---------------- 3) RPC 数据面 ----------------
for (const m of ['sessionBindingGet', 'sessionBindingSet', 'sessionBindingClear', 'workspaceProjectCreate']) {
  ok(src.includes("hostRpc('" + m + "'"), '缺少 RPC 调用：' + m);
}

// ---------------- 4) 会话广播 + 面板跟随 ----------------
{
  ok(src.includes('S.activeSessionId'), '缺少活动会话上报（S.activeSessionId）');
  ok(src.includes('bindingRev'), '缺少跟随驱动信号（bindingRev）');
  // 跟随 effect：绑定存在 → switchProject + switchCanvas + hydrate，且 pane 宿主守卫
  const followIdx = src.indexOf('followBoundCanvas');
  ok(followIdx >= 0, '缺少 followBoundCanvas 跟随实现');
  if (followIdx >= 0) {
    const seg = src.slice(followIdx, followIdx + 1600);
    ok(/switchProject/.test(seg) && /switchCanvas/.test(seg), '跟随未切换项目/画布');
    ok(/hydrateCanvasFromHost/.test(seg), '跟随未拉取远端画布文档（ hydrate ）');
    ok(/pane/.test(seg), '跟随缺 pane 宿主守卫（全屏面板不跟随）');
  }
}

// ---------------- 5) 占用提示 + 两级菜单（宿主选择器格式） ----------------
{
  ok(/occupied/.test(src), '绑定数据未消费 occupied 占用图');
  ok(src.includes("T('bindOccupied')"), '菜单缺「占用中」提示');
  // 无项目态也必须给选择：菜单里提供「创建项目」与「仅会话」
  ok(/createWorkspaceProject\(sessionId\)/.test(src), '无项目态缺「创建项目」动作');
  ok(/T\('bindCreateProjectAction'\)/.test(src), '无项目态缺「创建项目」菜单行');
  ok(/T\('bindSessionOnly'\)/.test(src), '缺「仅会话」常驻行');
  ok(/unbindSession\(sessionId\)/.test(src), '「仅会话」在已绑定态未执行解绑');
  // 项目列表数据源 = 客户端项目表（老项目必现）；宿主 RPC 仅补充
  const menuIdx = src.indexOf('function BindingMenu');
  const menuSeg = menuIdx >= 0 ? src.slice(menuIdx, menuIdx + 5200) : '';
  ok(/S\.projects/.test(menuSeg), '菜单未使用客户端项目表（老项目会看不到）');
  ok(/canvasesFromProject/.test(menuSeg), '菜单画布清单未用客户端注册表兜底');
  ok(/dshic-bind-err-inmenu/.test(src), '菜单内缺失败原因显示');
  // 绑定成功即乐观更新 chip（不等宿主回读）
  const bindIdx = src.indexOf('async function bindSessionToCanvas');
  ok(bindIdx >= 0 && /s\.sessionBinding = \{/.test(src.slice(bindIdx, bindIdx + 2600)), '绑定后未乐观更新 chip（选了位置不变）');
  // 创建项目双通道：工作区内嵌失败 → 普通建项目通道
  ok(/hostRpc\('canvasCreateProject'/.test(src), '缺普通建项目通道兜底（会话未挂工作区时无法创建）');
  // 两级菜单：未绑定列项目（客户端表为主 + bindableProjects 补充）+ 展开二级子画布
  ok(/hostRpc\('bindableProjects'/.test(src), '缺可绑定项目补充来源（bindableProjects）');
  ok(/S\.bindingMenuProject/.test(src), '缺项目展开状态（两级菜单）');
  ok(/is-selected/.test(src), '菜单缺选中行高亮（宿主选择器格式）');
  ok(/T\('bindOpenCanvas'\)/.test(src), '已绑定态缺「打开画布」行');
  // 一体式下拉（与宿主「选择工作区」选择器同构）：chip 内置 ⌄，禁止拆分独立箭头按钮
  ok(!/dshic-bind-arrow/.test(src), 'chip 与箭头不得拆成两个按钮（一体式下拉）');
  ok(/dshic-bind-caret/.test(src), 'chip 缺内置 ⌄ 指示');
  // 会话侧建子画布必须本地登记（项目树立即可见，不能只写宿主）
  const ccIdx = src.indexOf('async function createCanvasAndBind');
  ok(ccIdx >= 0 && /registerLocalCanvas\(/.test(src.slice(ccIdx, ccIdx + 1800)), '会话建画布未本地登记（项目树看不到新画布）');
  ok(/function registerLocalCanvas/.test(src), '缺 registerLocalCanvas 本地登记实现');
  // 折叠只折叠下方画布列表：搜索行不得随折叠消失
  ok(!/proj && !collapsed/.test(src), '折叠把搜索行一起隐藏（折叠只应折叠下方列表）');
  ok(/data-role': 'canvas-searchbar'/.test(src), '搜索行缺失');
  // 版本/能力握手：旧宿主（进程未重启）必须显式提示并拦截，不得静默失败
  ok(/hostRpc\('bindingCapabilities'/.test(src), '缺 bindingCapabilities 探针（旧宿主无法识别）');
  ok(/hostBindingStale/.test(src), '缺旧宿主状态标记');
  ok(/bindingStaleGuard\(\)/.test(src), '绑定动作缺旧宿主拦截守卫');
  ok(/dshic-bind-warn/.test(src), '菜单缺旧宿主置顶警告');
}

// ---------------- 7) 记忆查看器（统一弹窗第三页签） ----------------
{
  ok(/tabBtn\('memory'/.test(src), '统一弹窗缺「记忆」页签');
  ok(/openStudioModal\('memory'\)/.test(src), '侧栏缺「记忆」入口按钮');
  ok(/hostRpc\('memoryGet'/.test(src), '查看器未接 memoryGet RPC');
  ok(/function MemoryTab/.test(src), '缺少 MemoryTab 组件');
  for (const k of ['memViewerTab', 'memViewerEmpty', 'memRefresh', 'memViewerHint']) {
    const re = new RegExp("('" + k + "')\\s*:");
    ok(re.test(src.slice(src.search(/const DICT_ZH = \{/), src.search(/const DICT_EN = \{/))), 'DICT_ZH 缺 key：' + k);
    ok(re.test(src.slice(src.search(/const DICT_EN = \{/))), 'DICT_EN 缺 key：' + k);
  }
  ok(/ICONS\.memory|memory:\s*'M/.test(src), '缺 memory 图标');
}

// ---------------- 8) 记忆纪律门禁（canvas-studio 技能正文，防复活） ----------------
{
  const skillPath = path.join(ROOT, 'assets', 'canvas-studio', 'SKILL.md');
  const skill = readFileSync(skillPath, 'utf8');
  ok(/记忆先行/.test(skill), 'canvas-studio 缺「记忆先行」纪律');
  ok(/canvas_read_memory/.test(skill), 'canvas-studio 缺 canvas_read_memory 指引');
  ok(/canvas_write_memory/.test(skill), 'canvas-studio 缺 canvas_write_memory 指引');
  ok(/canvas_my_canvas/.test(skill), 'canvas-studio 缺 canvas_my_canvas 指引');
  ok(/会话[=＝]画布工作台|会话绑定/.test(skill), 'canvas-studio 缺「会话=画布工作台」口径');
  ok(/禁止跨(画布|项目)/.test(skill), 'canvas-studio 缺代码级跨画布/跨项目禁令');
  ok(/解绑/.test(skill), 'canvas-studio 缺「先解绑」指引');
  ok(/回写/.test(skill), 'canvas-studio 缺「回写」要求');
  ok(/bible/i.test(skill) && /记忆/.test(skill), '记忆与设定集（bible）分工口径缺失');
}

// ---------------- 结果 ----------------
if (errs.length) {
  console.error('✗ test-session-binding-ui FAIL（' + errs.length + '）:');
  for (const m of errs) console.error('  - ' + m);
  process.exit(1);
}
console.log('✓ test-session-binding-ui PASS');
