#!/usr/bin/env node
/**
 * IC-03 回归：视频厂商路由——**厂商格式（设置下拉）是唯一权威**。
 *
 * 2026-10-30 修订：移除"模型名猜测路由"。此前 wan3.0-video（moyu 中转站）因模型名
 * 命中 wan 正则被改道 DashScope 官方格式，中转站解析不到图字段 → 502 三连。
 * 新口径：
 *   ① 显式 vendor（设置下拉）= 唯一权威，模型名绝不参与；
 *   ② URL 特征兜底（用户填的 URL 也是显式配置的一部分，且设置卡会回填 vendor）；
 *   ③ 兜底 openai。
 * 保留：gatewayPrefixFor / wanEndpoints / apiVideo 未知厂商降级提示（原有断言不松）。
 *
 * 运行：node scripts/test-vendor-detect.mjs   退出码 0 = 通过；1 = 失败
 */
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = readFileSync(path.join(ROOT, 'client.js'), 'utf8');
const errs = [];
const ok = (c, m) => { if (!c) errs.push(m); };
const noop = () => {};

// ---------------- 假 React / DOM（与 test-drag-alt 同套路） ----------------
function mkEl(type, props, ...kids) { return { __el: true, type, props: Object.assign({}, props || {}, { children: kids.length <= 1 ? kids[0] : kids }) }; }
const fakeReact = {
  createElement: mkEl,
  useState: (init) => [typeof init === 'function' ? init() : init, () => {}],
  useEffect: () => {}, useLayoutEffect: () => {}, useRef: (v) => ({ current: v }),
  useCallback: (f) => f, useMemo: (f) => f(),
};
const lsStub = { _m: new Map(), getItem(k) { return this._m.has(k) ? this._m.get(k) : null; }, setItem(k, v) { this._m.set(k, String(v)); }, removeItem(k) { this._m.delete(k); }, clear() { this._m.clear(); } };
const sandbox = {
  window: { devicePixelRatio: 1, innerWidth: 1600, innerHeight: 900, addEventListener: noop, removeEventListener: noop, matchMedia: () => ({ matches: false, addEventListener: noop }), localStorage: lsStub, location: { href: 'http://localhost/' }, AudioContext: undefined, webkitAudioContext: undefined, __DSH_IC_SMOKE__: true },
  document: {
    createElement: () => ({ style: {}, dataset: {}, children: [], appendChild: noop, remove: noop, setAttribute: noop, addEventListener: noop, removeEventListener: noop, getBoundingClientRect: () => ({ left: 0, top: 0, right: 100, bottom: 100, width: 100, height: 100 }) }),
    addEventListener: noop, removeEventListener: noop, body: { appendChild: noop }, head: { appendChild: noop }, documentElement: { style: {} },
  },
  localStorage: lsStub, navigator: { language: 'zh-CN', userAgent: 'node' }, location: { href: 'http://localhost/' },
  setTimeout, clearTimeout, setInterval: (f) => setTimeout(f, 0), clearInterval: noop, queueMicrotask,
  fetch: () => Promise.reject(new Error('no-net')), console,
  performance: { now: () => Date.now() }, requestAnimationFrame: (f) => setTimeout(f, 0), cancelAnimationFrame: noop,
  TextEncoder, TextDecoder, URL, URLSearchParams, Promise, JSON, Math, Date, Number, String, Array, Object, Map, Set, Error, RegExp, parseInt, parseFloat, isNaN, isFinite, Buffer, Blob: class {},
};
sandbox.globalThis = sandbox;
sandbox.window.globalThis = sandbox.window;
vm.createContext(sandbox);
let mod = null;
sandbox.window.__ModuleLoader__ = { load(def) { mod = def; } };
try {
  vm.runInContext(src, sandbox, { filename: 'client.js' });
  const plugin = mod.factory((name) => { if (name === 'react') return fakeReact; throw new Error('意外 require: ' + name); });
  plugin.apply({ effect(fn) { fn(); }, locale: { register: noop, subscribe: () => () => {} }, slots: { inject(n, cb) { cb(); }, register: () => () => {} }, sidebarRightTabs: { register: () => () => {} } });
} catch (e) {
  console.error('✗ client.js 顶层执行失败：' + e.message);
  process.exit(1);
}
const SEG = sandbox.window.__DSH_IC_VENDOR__;
if (!SEG || typeof SEG.detectVideoVendor !== 'function') {
  console.error('✗ 未暴露 window.__DSH_IC_VENDOR__（vendor 识别的测试缝隙缺失）');
  process.exit(1);
}
const detect = SEG.detectVideoVendor;

// ---------------- ① 显式 vendor = 唯一权威（模型名绝不改道） ----------------
ok(detect({ vendor: 'openai', model: 'wan3.0-video', url: '' }) === 'openai', '显式 openai：wan3.0-video 模型名不得改道 wan（moyu 事故回归）');
ok(detect({ vendor: 'wan', model: 'gpt-4o', url: '' }) === 'wan', '显式 wan：任何模型名都走 wan');
ok(detect({ vendor: 'kling', model: 'wan3.0-video' }) === 'kling', '显式 kling：wan3.0-video 不得改道');
ok(detect({ vendor: 'seedance', model: 'wan3.0-video' }) === 'seedance', '显式 seedance：wan3.0-video 不得改道');
ok(detect({ vendor: 'openai', model: 'kling-v2' }) === 'openai', '显式 openai：kling 模型名不得改道 kling');

// ---------------- ② URL 特征兜底（旧配置 vendor 为空的过渡） ----------------
ok(detect({ vendor: '', model: '', url: 'https://dashscope.aliyuncs.com' }) === 'wan', 'URL 兜底：dashscope → wan');
ok(detect({ vendor: '', model: '', url: 'https://api.klingai.com' }) === 'kling', 'URL 兜底：klingai → kling');
ok(detect({ vendor: '', model: '', url: 'https://www.moyu.info/v1/video/generations' }) === 'openai', 'URL 兜底：无特征的中转站 → openai（moyu 默认）');
ok(detect({ vendor: '', model: '', url: '' }) === 'openai', 'URL 兜底：全空 → openai');

// ---------------- ③ protocol=seedance 保留 ----------------
ok(detect({ vendor: '', model: '', protocol: 'seedance' }) === 'seedance', 'protocol=seedance → seedance');
ok(detect({ vendor: '', model: '', url: 'https://ark.cn-beijing.volces.com/api/v3/contents/generations/tasks' }) === 'seedance', 'URL 兜底：contents/generations/tasks → seedance');

// ---------------- ④ 空对象/缺参 ----------------
ok(detect(null) === 'openai', 'null → openai');
ok(detect({}) === 'openai', '空对象 → openai');

// ---------------- ⑤ 源码契约：模型名正则已移除 ----------------
ok(!/wanx\|万相/.test(src), 'detectVideoVendor 不应再有 wan 模型名正则（模型名路由已移除）');
ok(/if \(s\.vendor\) return s\.vendor;/.test(src), '显式 vendor 优先必须保留');

// ---------------- ⑥ 通用图片字段兜底（不新增厂商） ----------------
{
  const needs = SEG.needsSimpleMediaRetry;
  const build = SEG.buildSimpleMediaRetryBody;
  ok(typeof needs === 'function' && typeof build === 'function', '缺少通用图片字段兜底测试缝隙');
  if (typeof needs === 'function' && typeof build === 'function') {
    ok(needs('{"error":"图片接口代理请求失败：需要 http(s) 接口 url"}'), '应识别“图片代理需要 http(s) URL”错误');
    ok(!needs('{"error":"Invalid API key"}'), '鉴权错误不得触发图片字段兜底');
    ok(!needs('{"error":"rate limit exceeded"}'), '限流错误不得触发图片字段兜底');
    const base = { model: 'wan3.0-video', prompt: 'p', duration: 5, resolution: '720P', ratio: '16:9' };
    const first = build(base, { frameDataUrl: 'data:image/png;base64,AAA' });
    ok(first.input_reference === 'data:image/png;base64,AAA', '纯首帧兜底应使用 input_reference=dataURL');
    ok(!first.image && !first.images, '纯首帧兜底不得再发 image / images');
    ok(first.resolution === '720P', '兜底请求应保留大写分辨率');
    const refs = build(base, { refDataUrls: ['data:image/png;base64,AAA', 'data:image/jpeg;base64,BBB'] });
    ok(Array.isArray(refs.images) && refs.images.every((x) => typeof x === 'string'), '参考图兜底 images 必须是字符串 dataURL 数组');
    ok(!refs.images.some((x) => x && typeof x === 'object' && 'role' in x), '参考图兜底不得再发 {url,role} 对象');
    const mixed = build(base, { frameDataUrl: 'data:image/png;base64,FFF', refDataUrls: ['data:image/png;base64,AAA'] });
    ok(Array.isArray(mixed.images) && mixed.images.length === 2 && mixed.images[0] === 'data:image/png;base64,FFF', '首帧+参考图应统一降级为 images 字符串数组，首帧排第一');
    const audio = build(base, { refDataUrls: ['data:image/png;base64,AAA'], audioDataUrls: ['data:audio/wav;base64,CCC'] });
    ok(Array.isArray(audio.media) && audio.media[0].type === 'reference_image' && audio.media[1].type === 'reference_audio', '带参考音频时应使用 media[] 且保留参考音频');
  }
  ok(/needsSimpleMediaRetry\(res\.text\)/.test(src), 'apiVideo 未接入通用图片字段兜底');
  ok(/buildSimpleMediaRetryBody\(/.test(src), 'apiVideo 未使用简化参考字段请求体');
}

// ---------------- ⑦ wan（DashScope 兼容中转）响应形态归一 ----------------
// tiantoken 等 DashScope 系中转会改写响应结构：task_id / 状态 / 成品地址的位置和大小写都可能变。
// 归一口径：位置按序兼容 + 状态统一小写；集合外状态（含 unknown）一律继续轮询，绝不误杀。
{
  const tidOf = SEG.wanTaskIdOf, stOf = SEG.wanStatusOf, pollOf = SEG.wanPollState;
  ok(typeof pollOf === 'function', '缺少 wan 响应归一测试缝隙（wanTaskIdOf/wanStatusOf/wanPollState）');
  if (typeof tidOf === 'function' && typeof stOf === 'function' && typeof pollOf === 'function') {
    // task_id 多形态
    ok(tidOf({ output: { task_id: 'a' } }) === 'a', 'task_id：output.task_id 官方形态优先');
    ok(tidOf({ task_id: 'b' }) === 'b', 'task_id：中转顶层 task_id');
    ok(tidOf({ data: { task_id: 'c' } }) === 'c', 'task_id：data.task_id');
    ok(tidOf({ id: 'd' }) === 'd', 'task_id：裸 id');
    ok(tidOf({}) === null && tidOf(null) === null, 'task_id：缺失返回 null');
    // 状态多形态 + 小写化
    ok(stOf({ output: { task_status: 'SUCCEEDED' } }) === 'succeeded', '状态：官方大写 → 小写比较');
    ok(stOf({ status: 'Running' }) === 'running', '状态：顶层 status（中转改写形态）');
    ok(stOf({ task_status: 'Unknown' }) === 'unknown', '状态：顶层 task_status');
    ok(stOf({ output: { status: 'Done' } }) === 'done', '状态：output.status');
    ok(stOf({}) === '' && stOf(null) === '', '状态：缺失返回空串');
    // 轮询判定
    ok(pollOf({ output: { task_status: 'SUCCEEDED', video_url: 'https://x/v.mp4' } }).state === 'done'
      && pollOf({ output: { task_status: 'SUCCEEDED', video_url: 'https://x/v.mp4' } }).url === 'https://x/v.mp4', '轮询：官方成功形态取 output.video_url');
    ok(pollOf({ status: 'success', video_url: 'https://x/v.mp4' }).state === 'done', '轮询：小写 success + 顶层 url');
    ok(pollOf({ output: { task_status: 'SUCCEEDED' } }).state === 'fail', '轮询：成功但无地址 → 快失败，不空转 2 小时');
    ok(pollOf({ data: { result_url: 'https://x/v.mp4' }, output: { task_status: 'Success' } }).url === 'https://x/v.mp4', '轮询：data.result_url 兜底成品地址');
    ok(pollOf({ status: 'unknown' }).state === 'wait', '轮询：unknown ≠ 失败（中转刚提交常回 unknown，误杀回归）');
    ok(pollOf({ output: { task_status: 'PENDING' } }).state === 'wait', '轮询：PENDING 继续等');
    ok(pollOf({ status: 'Running' }).state === 'wait', '轮询：running 继续等');
    ok(pollOf({}).state === 'wait' && pollOf(null).state === 'wait', '轮询：无状态字段 → wait');
    const f1 = pollOf({ output: { task_status: 'FAILED', code: 'InvalidParameter', message: 'bad media' } });
    ok(f1.state === 'fail' && /InvalidParameter/.test(f1.error) && /bad media/.test(f1.error), '轮询：失败带 output.code + output.message');
    ok(pollOf({ status: 'Expired' }).state === 'fail', '轮询：expired 终态');
    ok(pollOf({ status: 'Cancelled' }).state === 'fail', '轮询：cancelled（双 l）终态');
    const f2 = pollOf({ status: 'Timeout', message: 'upstream timeout' });
    ok(f2.state === 'fail' && /upstream timeout/.test(f2.error), '轮询：顶层 message 兜底错误信息');
  }
  ok(/const tid = wanTaskIdOf\(j1\)/.test(src), 'wan runner 未接入 task_id 多形态提取');
  ok(/return wanPollState\(j\)/.test(src), 'wan runner 轮询未接入状态归一');
}

// ---------------- ⑧ 三宝影像工坊（Sanbao）任务制多参考 ----------------
// 协议：POST /openapi/v1/videos（任务制）+ GET 轮询 data.status；本地素材 dataURL 直传
// （全模型 media_inputs 含 data_url，实测格式校验通过）；报图片/素材格式类错误 →
// 用专用 uploadKey（扩展参数）走 /openapi/v1/uploads/raw 转公网 URL 后重试一次。
{
  const build = SEG.buildSanbaoVideoBody;
  const tidOf = SEG.sanbaoTaskIdOf;
  const pollOf = SEG.sanbaoPollState;
  const retry = SEG.needsSanbaoMediaRetry;
  ok(typeof build === 'function' && typeof pollOf === 'function' && typeof retry === 'function', '缺少三宝测试缝隙（buildSanbaoVideoBody/sanbaoTaskIdOf/sanbaoPollState/needsSanbaoMediaRetry）');
  if (typeof build === 'function') {
    const base = { model: 'wan30_720p_real', prompt: 'p', ratio: '9:16', resolution: '720P', duration: 5 };
    const b1 = build(base, { frameDataUrl: 'data:image/png;base64,AAA', refDataUrls: ['data:image/jpeg;base64,BBB', 'data:image/jpeg;base64,CCC'] });
    ok(b1.model === 'wan30_720p_real', '三宝：model 透传');
    ok(Array.isArray(b1.images) && b1.images.length === 3 && b1.images[0] === 'data:image/png;base64,AAA', '三宝：首帧降级为首张参考图，images 字符串数组');
    ok(b1.reference === 'all', '三宝：多参考模式 reference=all');
    ok(b1.resolution === '720p', '三宝：resolution 小写化（模型表枚举 480p/720p/1080p/2k）');
    ok(b1.ratio === '9:16' && b1.duration === 5, '三宝：ratio/duration 透传');
    const b2 = build(base, { refDataUrls: ['data:image/jpeg;base64,BBB'] });
    ok(!('input_reference' in b2) && Array.isArray(b2.images) && b2.images.length === 1, '三宝：无首帧只发参考图');
    const b3 = build(base, { frameDataUrl: 'data:image/png;base64,AAA', audioDataUrls: ['data:audio/mpeg;base64,CCC'] });
    ok(Array.isArray(b3.audios) && b3.audios[0].tag === '音频1' && /^data:audio/.test(b3.audios[0].url), '三宝：参考音频走 audios[{tag,url}]');
    const b4 = build(base, { refDataUrls: ['https://sanbaobeauty.com/a.jpg'] });
    ok(b4.images[0] === 'https://sanbaobeauty.com/a.jpg', '三宝：公网 URL 与 dataURL 同通道（上传兜底重试共用构造器）');
    ok(!('parameters' in b1) && !('watermark' in b1), '三宝：不发明其他协议的字段');
  }
  if (typeof tidOf === 'function') {
    ok(tidOf({ data: { id: 'task_x' } }) === 'task_x', '三宝：任务 id 在 data.id');
    ok(tidOf({ id: 't2' }) === 't2', '三宝：顶层 id 兼容');
    ok(tidOf({}) === null && tidOf(null) === null, '三宝：无 id 返回 null');
  }
  if (typeof pollOf === 'function') {
    ok(pollOf({ data: { status: 'succeeded', video_url: 'https://x/v.mp4' } }).state === 'done'
      && pollOf({ data: { status: 'succeeded', video_url: 'https://x/v.mp4' } }).url === 'https://x/v.mp4', '三宝：succeeded → data.video_url');
    ok(pollOf({ data: { status: 'succeeded', download_url: 'https://x/d.mp4' } }).url === 'https://x/d.mp4', '三宝：download_url 兜底（签名直链）');
    ok(pollOf({ data: { status: 'succeeded' } }).state === 'fail', '三宝：成功但无地址 → 快失败');
    const f1 = pollOf({ data: { status: 'failed', error: '敏感内容' } });
    ok(f1.state === 'fail' && /敏感内容/.test(f1.error), '三宝：failed → data.error');
    ok(pollOf({ data: { status: 'queued' } }).state === 'wait' && pollOf({ data: { status: 'processing', progress: 40 } }).state === 'wait', '三宝：queued/processing 继续等');
    ok(pollOf({}).state === 'wait' && pollOf(null).state === 'wait', '三宝：无状态 → wait');
  }
  if (typeof retry === 'function') {
    ok(retry('图片格式不支持，请提供 http(s) url'), '三宝兜底：图片格式类错误触发');
    ok(retry('素材拉取失败'), '三宝兜底：素材类错误触发');
    ok(!retry('余额不足'), '三宝兜底：余额错误绝不重试');
    ok(!retry('{"code":"INSUFFICIENT_CREDITS"}'), '三宝兜底：积分错误绝不重试');
    ok(!retry('Invalid API key'), '三宝兜底：鉴权错误绝不重试');
    ok(!retry('请求过于频繁'), '三宝兜底：限流绝不重试');
    ok(!retry(''), '三宝兜底：空错误不触发');
  }
  ok(detect({ vendor: '', model: '', url: 'https://sanbaobeauty.com/openapi/v1/videos' }) === 'sanbao', 'URL 兜底：sanbaobeauty → sanbao');
  ok(/openapi\/v1\/videos/.test(src), '三宝：任务创建/查询端点未接入');
  ok(/sanbaoUploadRaw/.test(src) && /uploads\/raw/.test(src), '三宝：素材上传口未接入');
  ok(/uploadKey/.test(src), '三宝：专用上传 key（扩展参数 uploadKey）未接入');
  ok(/audioDataUrls: await Promise\.all\(\(o\.audioRefs \|\| \[\]\)\.slice\(0,\s*3\)\.map/.test(src), '三宝：参考音频未按上限切片（≤3，与告警口径一致）');
}

// ---------------- ⑨ 注入分工：视频总控锁 + 风格锚 ----------------
// 分工契约：导演语言（运镜/镜头语言/色调细节）只在分镜层字段化（逐镜 camera/motion/visual），
// 视频请求只带全片级总控（美学短语/交付规格/≤6 条负向词）+ 结构化正文；风格全文进剧本/分镜
// LLM 消化，请求只带风格锚（styleAnchor 优先，缺省取 style 第一句，语义分句、绝不字数截断）。
{
  const anchor = SEG.bibleStyleAnchor;
  ok(typeof anchor === 'function', '缺少风格锚测试缝隙（bibleStyleAnchor）');
  if (typeof anchor === 'function') {
    ok(anchor({ styleAnchor: '港片复古，霓虹雨夜' }) === '港片复古，霓虹雨夜', '风格锚：styleAnchor 字段优先');
    ok(anchor({ style: '港片复古质感：霓虹反光、高对比撞色。雨夜街道，胶片颗粒。高对比暖橙。' }) === '港片复古质感：霓虹反光、高对比撞色。', '风格锚：无锚取 style 第一句（语义分句，非字数截断）');
    ok(anchor({ style: '无句读的整段风格描述' }) === '无句读的整段风格描述', '风格锚：无句读整段保留（不切割）');
    ok(anchor({ style: '' }) === '' && anchor(null) === '', '风格锚：空设定返回空');
  }
  const i0 = src.indexOf('async function buildShotLockText');
  const i1 = src.indexOf('async function loadModelIndex');
  ok(i0 > 0 && i1 > i0, 'buildShotLockText 源码切片定位失败');
  if (i0 > 0 && i1 > i0) {
    const vlock = src.slice(i0, i1);
    ok(!/yamlBlock/.test(vlock), '视频锁不得再注入透镜 YAML（导演语言已字段化进分镜）');
    ok(!/pickSections/.test(vlock), '视频锁不得倾倒教材小节全文');
    ok(!/常见场面颗粒/.test(vlock), '视频锁不得注入题材颗粒长文');
    ok(!/禁止漂移/.test(vlock), '视频锁不得注入题材禁项长文');
    ok(!/'色彩命题'/.test(vlock), '视频锁不得注入色彩命题长文（色调已下沉分镜 visual）');
    ok(!/'影调与光比'/.test(vlock), '视频锁不得注入影调光比长文');
    ok(!/'材质响应'/.test(vlock), '视频锁不得注入材质长文');
    ok(/成像底层/.test(vlock), '视频锁保留影调美学短语（成像底层摘要，≤200B）');
    ok(/交付规格/.test(vlock), '视频锁保留交付规格（单镜时长口径）');
    ok(/slice\(0,\s*6\)/.test(vlock), '视频锁内联负向词 ≤6 条（稀释规则）');
    ok(!/2400/.test(vlock), '视频锁不得保留旧 2400B 负向词预算');
  }
  const anchorUses = (src.match(/bibleStyleAnchor\(/g) || []).length;
  ok(anchorUses >= 4, '风格锚接入点不足（定义 + 生效提示词/结构化正文/设定图模板至少各 1 处）');
  ok(/把本镜色调|色调按/.test(src), '分镜契约缺「色调写进 visual」显式要求');
  const idxSrc = readFileSync(path.join(ROOT, 'index.js'), 'utf8');
  ok(/styleAnchor/.test(idxSrc), 'canvas_update_bible 未支持 styleAnchor 产出（风格锚字段）');
}

// ---------------- ⑩ 三宝下载缓存重试（succeeded ≠ 文件可下载） ----------------
// 三宝任务成功只代表转码完成；CDN 缓存未铺开时首次 GET 会 502（实测 2–3 分钟，最迟 5 分钟）。
// 生成成功只有一次下载机会 → 必须给窗口重试，且每次重试前刷新签名地址。
{
  const retryable = SEG.retryableDownloadError;
  const dlRetry = SEG.downloadVideoWithRetry;
  ok(typeof retryable === 'function' && typeof dlRetry === 'function', '缺少三宝下载重试测试缝隙（retryableDownloadError/downloadVideoWithRetry）');
  ok(SEG.SANBAO_DOWNLOAD_RETRY_MS === 10 * 60 * 1000 && SEG.SANBAO_DOWNLOAD_RETRY_STEP_MS === 10 * 1000,
    '三宝下载重试窗口/步长不是 10 分钟/10 秒');
  if (typeof retryable === 'function') {
    const mk = (status) => ({ status });
    ok(retryable(mk(502)) && retryable(mk(503)) && retryable(mk(504)), '502/503/504 可重试');
    ok(retryable(mk(404)) && retryable(mk(403)) && retryable(mk(429)) && retryable(mk(408)), '缓存未就绪类 4xx 可重试');
    ok(retryable(new Error('network')), '无 HTTP 状态的网络错误可重试');
    ok(!retryable(mk(401)) && !retryable(mk(400)) && !retryable(mk(405)), '鉴权/请求格式错误不重试');
  }
  if (typeof dlRetry === 'function') {
    // 前两次 502、第三次成功：每次重试前刷新签名地址
    let hits = 0; const urls = []; const blob = { size: 9 };
    const out = await dlRetry('https://x/a.mp4', {}, {
      windowMs: 60000, stepMs: 1000,
      download: async (u) => { urls.push(u); hits++; if (hits < 3) { const e = new Error('下载视频失败 HTTP 502'); e.status = 502; throw e; } return blob; },
      sleep: async () => {},
      isAborted: () => false,
      refreshUrl: async () => 'https://x/fresh' + hits + '.mp4',
    });
    ok(out === blob && hits === 3, '502 重试直到成功（不是单次失败即死）');
    ok(urls[1] === 'https://x/fresh1.mp4' && urls[2] === 'https://x/fresh2.mp4', '重试前刷新签名地址（旧地址可能过期）');
    // 401 立即失败（不重试）
    let n401 = 0; let e401 = null;
    try {
      await dlRetry('u', {}, {
        windowMs: 60000,
        download: async () => { n401++; const e = new Error('下载视频失败 HTTP 401'); e.status = 401; throw e; },
      });
    } catch (e) { e401 = e; }
    ok(n401 === 1 && !!e401 && /401/.test(e401.message), '401 立即失败不重试');
    // 10 分钟窗口边界：每 10s 一次，第 61 次（t=600s）失败后停止
    let t = 0; let nWin = 0; let eWin = null;
    try {
      await dlRetry('u', {}, {
        windowMs: 600000, stepMs: 10000, now: () => t, sleep: async (ms) => { t += ms; },
        download: async () => { nWin++; const e = new Error('下载视频失败 HTTP 502'); e.status = 502; throw e; },
      });
    } catch (e) { eWin = e; }
    ok(nWin === 61 && t === 600000, '10 分钟窗口按 10s 重试，到点停止（61 次）');
    ok(!!eWin && /10 分钟内仍无法下载/.test(eWin.message) && /502/.test(eWin.message), '窗口耗尽错误带时长与最后状态');
    // 中断优先：不再发起下载
    let dlCalled = false; let eAbort = null;
    try {
      await dlRetry('u', {}, { isAborted: () => true, download: async () => { dlCalled = true; return blob; } });
    } catch (e) { eAbort = e; }
    ok(!dlCalled && !!eAbort, '中断后不再发起下载');
  }
  // 源码契约：三宝 runner 必须走重试助手，且不再裸调 downloadVideo
  const s0 = src.indexOf('async sanbao(prompt, frameBlob, s, o)');
  const s1 = src.indexOf('// —— MiniMax 海螺', s0);
  ok(s0 > 0 && s1 > s0, '三宝 runner 源码切片失败');
  if (s0 > 0 && s1 > s0) {
    const body = src.slice(s0, s1);
    ok(/downloadVideoWithRetry\(/.test(body), '三宝 runner 未接入下载重试');
    ok(!/return await downloadVideo\(url, \{\}\)/.test(body), '三宝 runner 仍是单次下载（502 立即失败）');
    ok(/SANBAO_DOWNLOAD_RETRY_MS/.test(body) && /refreshUrl/.test(body), '三宝下载重试缺窗口常量或签名地址刷新');
  }
}

// ---------------- ⑪ 三宝图片任务协议（/openapi/v1/images，异步） ----------------
// 通用同步格式在三宝会 504（出图 >120s 代理 abort，无任务 id、已扣费无法回查）。
// 图片与视频同构：提交拿任务 id（onTask 持久化）→ 轮询 → 带重试下载。
{
  const build = SEG.buildSanbaoImageBody;
  const pollOf = SEG.sanbaoImagePollState;
  const urlOf = SEG.sanbaoImageResultOf;
  ok(typeof build === 'function' && typeof pollOf === 'function' && typeof urlOf === 'function',
    '缺少三宝图片任务测试缝隙（buildSanbaoImageBody/sanbaoImagePollState/sanbaoImageResultOf）');
  if (typeof build === 'function') {
    const b1 = build({ model: 'gpt-image2', prompt: '海报', aspect_ratio: '16:9', quality: 'high' }, { refUrls: ['https://sanbaobeauty.com/uploads/a.jpg'] });
    ok(b1.model === 'gpt-image2' && b1.prompt === '海报', '三宝图片：model/prompt 透传');
    ok(b1.aspect_ratio === '16:9' && b1.quality === 'high', '三宝图片：aspect_ratio/quality 透传');
    ok(Array.isArray(b1.images) && b1.images[0] === 'https://sanbaobeauty.com/uploads/a.jpg', '三宝图片：参考图走 images 公网 URL 数组');
    ok(!('uploadKey' in b1) && !('watermark' in b1), '三宝图片：uploadKey 绝不进请求体 / 不发明其他协议字段');
    const b2 = build({ model: '', prompt: 'p', aspect_ratio: '', quality: '' }, {});
    ok(b2.aspect_ratio === 'auto' && b2.quality === 'high' && !('images' in b2), '三宝图片：缺省 aspect_ratio=auto、quality=high、无参考图不带 images');
  }
  if (typeof pollOf === 'function') {
    ok(pollOf({ data: { status: 'succeeded', image_url: 'https://x/a.png' } }).state === 'done'
      && pollOf({ data: { status: 'succeeded', image_url: 'https://x/a.png' } }).url === 'https://x/a.png', '三宝图片：succeeded → data.image_url');
    ok(urlOf({ data: { status: 'succeeded', images: ['https://x/b.png'] } }) === 'https://x/b.png', '三宝图片：images[0] 字符串兜底');
    ok(urlOf({ data: { status: 'succeeded', images: [{ url: 'https://x/c.png' }] } }) === 'https://x/c.png', '三宝图片：images[0] 对象 {url} 兜底');
    ok(urlOf({ data: { status: 'succeeded', download_url: 'https://x/d.png' } }) === 'https://x/d.png', '三宝图片：download_url 兜底');
    const f1 = pollOf({ data: { status: 'failed', error: '敏感内容拦截' } });
    ok(f1.state === 'fail' && /敏感内容/.test(f1.error), '三宝图片：failed → data.error');
    const f2 = pollOf({ data: { status: 'succeeded' } });
    ok(f2.state === 'fail' && /无图片地址/.test(f2.error), '三宝图片：成功但无地址 → 明确失败');
    ok(pollOf({ data: { status: 'queued' } }).state === 'wait' && pollOf({ data: { status: 'processing', progress: 40 } }).state === 'wait', '三宝图片：queued/processing 继续等');
    ok(pollOf({}).state === 'wait' && pollOf(null).state === 'wait', '三宝图片：无状态 → wait');
  }
  // 源码契约：apiImage 域名命中 sanbaobeauty 自动切任务式；模式显式值 sanbao；onTask 透传到节点
  ok(/sanbaoRoute = /.test(src) && /sanbaobeauty/.test(src), '三宝图片：域名自动路由未接入');
  ok(/s\.mode === 'sanbao'/.test(src), '三宝图片：显式模式未接入');
  ok(/sanbaoImageTask\(prompt, refs, s, opts\)/.test(src), '三宝图片：apiImage 未接入任务式运行器');
  ok(/onTask: \(tid, qurl\) => \{[\s\S]{0,200}?nd\.data\.taskId = String\(tid \|\| ''\)/.test(src), '三宝图片：任务 id 未持久化到节点（代理超时后无法回查）');
  ok(/await sanbaoUploadRaw\(base, uploadKey, raw, 'image'\)/.test(src), '三宝图片：本地参考图未走 uploads/raw 转公网');
  // 通用格式瞬态重试：502/503/504/429 补一次尝试（401/400 不重试，判定与下载同口径）
  ok(/image api not ready \(HTTP/.test(src), '通用图片提交缺瞬态重试日志');
  ok(/let res = await send\(body, '图片 API'\);[\s\S]{0,400}?retryableDownloadError\(\{ status: res\.status \}\)/.test(src), '通用图片提交未接瞬态重试判定');
}

if (errs.length) {
  console.error('✗ 厂商识别回归未通过（' + errs.length + '）：');
  for (const e of errs) console.error('  - ' + e);
  process.exit(1);
}
console.log('✓ 厂商识别回归通过：显式 vendor 唯一权威 / 模型名路由已移除 / URL 兜底保留 / moyu 默认 openai');
