// 内置动作库：成熟动作 clip（本地化）能被资产加载并真实播放
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const E = await import(pathToFileURL(path.join(ROOT, 'assets/director/engine.js')).href);
const errs = [];
const ok = (c, m) => { if (!c) errs.push(m); };

const CLIP_DIR = path.join(ROOT, 'assets/director/clips');
const manifestPath = path.join(CLIP_DIR, 'manifest.json');
ok(fs.existsSync(manifestPath), '缺少动作库 manifest.json');
const manifest = fs.existsSync(manifestPath) ? JSON.parse(fs.readFileSync(manifestPath, 'utf8')) : { clips: [] };
ok(Array.isArray(manifest.clips), '动作库 manifest 结构错误');
// 动作库允许为空（只使用内置动作），不为空时逐项校验

// ① 每个动作文件结构正确
const clips = [];
for (const it of manifest.clips) {
  const f = path.join(CLIP_DIR, it.file);
  ok(fs.existsSync(f), '缺少动作文件 ' + it.file);
  if (!fs.existsSync(f)) continue;
  const j = JSON.parse(fs.readFileSync(f, 'utf8'));
  ok(Array.isArray(j.tracks) && j.tracks.length >= 40, it.name + ' 轨道数不足（' + (j.tracks || []).length + '）');
  ok(Number(j.duration) > 0.1, it.name + ' 时长无效');
  const badNode = j.tracks.filter((t) => !(Number(t.node) >= 0)).length;
  ok(badNode === 0, it.name + ' 存在未映射轨道 ' + badNode + ' 条');
  const badPath = j.tracks.filter((t) => t.path !== 'rotation' && t.path !== 'translation').length;
  ok(badPath === 0, it.name + ' 存在非法 path ' + badPath + ' 条');
  clips.push(j);
}

// ② 资产加载动作库后，只能加载骨架兼容的动作。
// awplanet-explorer 动作的局部坐标与 xbot 不同；直接套到 xbot 会整身扭曲。
// 这类动作必须只出现在同源骨架上（Explorer），不能因为名字不重复就盲加进 xbot。
const pack = JSON.parse(fs.readFileSync(path.join(ROOT, 'assets/director/models/xbot.json'), 'utf8'));
const asset = E.decodeModelPack(pack, E.decodeActionClips(clips));
const compatibleWith = (targetRig, clip) => !clip.sourceRig || clip.sourceRig === targetRig;
for (const it of manifest.clips) {
  const c = asset.clipByName(it.name);
  const compatible = compatibleWith('xbot', it);
  if (compatible) {
    ok(!!c, '兼容动作缺失：' + it.name);
    if (c) ok(c.tracks.length >= 40 && c.duration > 0.1, it.name + ' 加载后轨道/时长异常');
  } else {
    const c2 = asset.clipByName(it.name);
    ok(!(c2 && c2.sourceRig === it.sourceRig), '异骨架动作库版本被错误加载到 xbot：' + it.name + '（sourceRig=' + (it.sourceRig || '-') + '）');
  }
}

// Explorer 同源骨架必须能加载全部 awplanet-explorer 动作
const explorerPackPath = path.join(ROOT, 'assets/director/models/explorer.json');
if (fs.existsSync(explorerPackPath)) {
  const explorerPack = JSON.parse(fs.readFileSync(explorerPackPath, 'utf8'));
  const explorer = E.decodeModelPack(explorerPack, E.decodeActionClips(clips));
  for (const it of manifest.clips.filter((x) => x.sourceRig === 'awplanet-explorer')) {
    const c = explorer.clipByName(it.name);
    ok(!!c, 'Explorer 缺少同源动作 ' + it.name);
    if (c) ok(c.tracks.length >= 40 && c.duration > 0.1, it.name + ' 在 Explorer 上加载后轨道/时长异常');
  }
}

// ③ 真实播放：只测 xbot 骨架兼容动作；异骨架动作已在上面拒绝
for (const it of manifest.clips) {
  const c = asset.clipByName(it.name);
  if (!c) continue;
  // 采样密度必须与时长匹配：短动作（跑/跳 0.6-1.0s）只用 10 帧会把正常运动放大成"跳变"。
  // 统一 ≥24 帧且每帧 ≤40ms（25fps 以上），否则测量本身失真。
  const steps = Math.min(60, Math.max(24, Math.round(c.duration * 25)));
  let prev = null, maxJump = 0, total = 0, n = 0, moved = 0;
  for (let i = 0; i <= steps; i++) {
    const t = (c.duration * i) / steps;
    const sk = E.skinModel(asset, it.name, t, null, null, {});
    if (!sk) { ok(false, it.name + ' 蒙皮返回空'); break; }
    if (prev) {
      let m = 0;
      const N = Math.min(sk.pos.length, prev.length);
      for (let k = 0; k < N; k += 3) {
        const d = Math.hypot(sk.pos[k] - prev[k], sk.pos[k + 1] - prev[k + 1], sk.pos[k + 2] - prev[k + 2]);
        if (d > m) m = d;
      }
      maxJump = Math.max(maxJump, m); total += m; n++;
      if (m > 0.002) moved++;
    }
    if (!prev || prev.length !== sk.pos.length) prev = new Float32Array(sk.pos.length);
    prev.set(sk.pos);
  }
  ok(moved >= n * 0.5, it.name + ' 动作几乎没有运动（moving ' + moved + '/' + n + '）');
  // 待机类动作本来就极轻微（呼吸/重心微调，4-10mm 是正常值），阈值按类别区分；
  // 其余动作要求有明显运动（≥10mm/帧）。
  const isIdle = /idle/i.test(it.name);
  ok((total / n) > (isIdle ? 0.002 : 0.01), it.name + ' 平均运动量过小（' + ((total / n) * 1000).toFixed(1) + 'mm）');
  const fast = /knockdown|hit_recoil|jump|dance|low_sweep|spear_ground|crouch/.test(it.name);
  const jumpLimit = fast ? 2.0 : 1.2;
  ok(maxJump < jumpLimit, it.name + ' 存在跳变（单帧 ' + (maxJump * 1000).toFixed(0) + 'mm，限 ' + jumpLimit * 1000 + 'mm）');
}

// ④ 内置片段必须保持原样（动作库只追加，不覆盖）
{
  const packRaw = JSON.parse(fs.readFileSync(path.join(ROOT, 'assets/director/models/xbot.json'), 'utf8'));
  const builtinNames = (packRaw.animations || []).map((a) => a.name);
  for (const nm of builtinNames) {
    const c = asset.clipByName(nm);
    ok(!!c, '内置动作丢失：' + nm);
    const raw = (packRaw.animations || []).find((a) => a.name === nm);
    ok(c && c.tracks.length === raw.tracks.length, '内置动作 ' + nm + ' 轨道数被改动（' + (c ? c.tracks.length : 0) + ' vs ' + raw.tracks.length + '）');
  }
  ok(builtinNames.includes('idle') && builtinNames.includes('walk'), '内置应含待机与行走');
}

if (errs.length) {
  console.error('✗ 动作库测试未通过（' + errs.length + ' 项）：');
  for (const e of errs) console.error('  - ' + e);
  process.exit(1);
}
console.log('✓ 动作库通过：' + manifest.clips.length + ' 个打斗动作可加载、真实播放、连续无跳变；内置待机/行走不被覆盖');
process.exit(0);
