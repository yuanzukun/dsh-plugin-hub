# Changelog

All notable changes to `@ninkch/dsh-infinite-canvas` are documented here (newest first).
GitHub Releases carry the same notes in English; maintainer-facing runbooks live in
[`RELEASING.md`](RELEASING.md) and [`docs/release.md`](docs/release.md).

## [Unreleased]

## [0.20.4] — 2026-11-10

### Added
- **New video vendor: 6789API (task-based `/v1/videos`).** One adapter covers
  both protocol families this gateway style serves on the same paths, routed
  by model id: `seedance*` sends `{model, prompt, duration, ratio, resolution,
  image_urls?}` (resolution lowercased; duration/ratio/resolution passed
  through untouched — the gateway validates and its errors stay visible;
  reference cap 9, or 30 for seedance2.5), while `minimax*` sends
  `{model, prompt, seconds, size, workflow_id, images?}` with the canvas
  ratio×resolution mapped to the exact pixel size the API demands (2K/4K sent
  uppercase; 480p has no slot and degrades to the 768P tier with a visible
  warning) and the workflow chosen automatically (text-to-video /
  multi-reference / cf-multi-reference; 2K/4K hard-fails up front with a
  readable error when no reference image is attached, per the API's own
  constraint). Submit carries an `Idempotency-Key` UUID; polling every 5s up
  to 30 minutes (task id persists on the node for recovery); results are
  extracted through four tiers (`download_url` → `video_url` → `data`-wrapped
  compat fields → relative `file` path resolved against the API origin) and
  downloads reuse the 10-minute retry window with a status re-query before
  each attempt (signed URLs expire). Local reference images are sent as
  data URLs; if the gateway demands public https links the submit error says
  so and points at the extended-params escape hatch
  (`{"image_urls":["https://…"]}`, field name `images` for minimax). Any
  site speaking this format works — pick the vendor in the dropdown, fill in
  your own Base URL.
- **Storyboard total duration is now a hard constraint.** The storyboard node's
  duration dropdown gains a first option 「按镜头节奏自动」 (auto pacing, the new
  default — behaves exactly as before: the skill distributes per-shot durations
  by its pacing spectrum). Picking any preset (6-30s) or a custom value (1-300s,
  one decimal) pins the storyboard node's TOTAL duration: whether the scene is
  split into 5 shots or 50, the shot durations must add up to exactly the set
  value. Enforced twice — a hard-override clause in the generation prompt (more
  shots = proportionally shorter shots; compress rather than drop dialogue) and
  a mechanical rescale after parsing (proportional scaling with the last shot
  absorbing rounding residue), so what lands on the canvas always sums to the
  target. The legacy `segMaxSeconds` (per-segment cap) field is retired — with
  top vendors generating 30s in one call, capping a segment at 1-30s had no
  meaning; segmentation planning, expansion, budget quotes and the auto-mode
  duration gate all read the same total-duration value now.

### Fixed
- **Dropdown menus kept snapping back to the pre-mirror layout.** The mirror
  placement (search box hugging the button on flip) was computed in a layout
  effect, but the composer-follow chain still used the old fixed-280px formula
  and — worse — wrote its position without the `flipped` flag, so any node
  drag / canvas zoom / reposition while a menu was open silently reverted the
  whole menu to the legacy top placement. All three placement sites (open,
  composer-follow, post-render measure) now share one `placeMenu()` that
  decides mirror direction and clamps to the viewport in one place.
- **Dropdown menus stay attached to their trigger wherever the composer sits.**
  Menus were placed with a fixed "menu max height 280px" assumption: when the
  composer sits below its node (near the viewport bottom) the menu flipped
  upward by that full height, but the real menu is much shorter — it ended up
  floating ~130px above the button ("flies away when the composer is below the
  node; fine when above"). After opening, the menu now measures its real height
  in a layout effect and pins itself: upward flip = menu bottom exactly 6px
  above the button top; downward overflow = clamp to the viewport; and the
  composer's reposition chain (node drag / canvas zoom) keeps it attached.
- **Model dropdowns no longer detach from their trigger or crash the canvas.** Two
  broken fixes taught the real root cause: the generate-composer is a live
  `position:fixed` overlay that repositions itself when the node moves or the
  canvas zooms, but a dropdown menu only computed its coordinates once at open
  time — it stayed behind at a stale spot ("flew away"), and the two attempted
  fixes (world-space coordinate conversion, then manually re-parenting the menu
  to `<body>`) made it worse: the re-parent fought React's reconciler and
  crashed rendering with `removeChild` NotFoundError. The menu now renders
  in place (React-owned, no manual DOM moves) and registers into the
  composer's existing `composerReposition` chain — every composer move
  (node drag, canvas zoom/pan, window resize) re-computes the menu position
  from the button's fresh rect, plus a next-frame correction right after
  opening so a just-positioned composer can't leave the menu behind.
- **Image/video model dropdowns no longer show 「跟随设置」 (follow settings).**
  Language models legitimately have that option (the session model is the
  fallback), but image/video models have a real default — the ★ starred model
  in settings — so the node dropdown now lists only the configured models and
  displays the starred one when the node has no explicit pick (matching what
  the request side already did via `resolveImageModelCfg`/`resolveVideoModelCfg`).
- **Dropdown menus no longer fly to a wrong position on zoomed/panned canvases.**
  `PopupSelect` menus and the @-mention popover are rendered inside the
  transformed `dshic-world` layer, where `position:fixed` resolves against the
  transform ancestor instead of the viewport; their viewport-based coordinates
  are now converted to world coordinates (same formula as `screenToWorld`), so
  menus stay attached to their trigger at any zoom/pan.

### Changed
- **Segmentation planning reads the total duration.** With `segMaxSeconds`
  retired, the per-storyboard cap used by segmentation planning, canvas
  expansion, budget quotes and the auto-mode duration gate is now the node's
  total-duration value (default 15s when unset) — one number, one meaning,
  everywhere.

### Internal
- **Regression suites updated for the field retirement.** Budget-fingerprint,
  segment-plan and drift-guard assertions now exercise `targetDuration`
  instead of the removed `segMaxSeconds` field.

## [0.20.3] — 2026-11-10

### Fixed
- **The 0.20.2 npm package was missing `shot-segments.js`, so every npm-installed host
  died on load with `ERR_MODULE_NOT_FOUND`.** `index.js` and `production.js` import
  `./shot-segments.js` at module load, but the packaging whitelist (`files` in
  package.json) was never updated when the module was added — the tarball shipped
  without it and the import blew up before any code ran (local `link:` installs were
  unaffected, which is why it slipped through). This release adds `shot-segments.js`
  to the whitelist, and check-pack gains a mechanical import-resolution audit: it scans
  every `.js` file in the pack manifest (including `assets/`) for static relative
  imports (`from './x'` / `import('./x')` / `require('./x')`), resolves each against the
  file's directory and asserts the target is packed too — so a newly added module
  missing from the whitelist now turns regress red instead of killing every user's
  install (keywords: packaging whitelist / shot-segments / ERR_MODULE_NOT_FOUND /
  import-resolution).

- **Settings cards no longer silently roll back each other's edits (cross-card lost
  updates).** Every settings card used to hold a snapshot taken at mount time and write
  the whole settings object back on each save, so editing card B after card A silently
  reverted card A's changes — and anything lost this way was gone for good after
  exiting (the cross-card editing scenario reported in issue #6). All write-backs now go
  through `updateSettings`, which reads the freshest settings from disk as its base and
  applies only the card's own field changes on top; the card's local snapshot is
  re-synced from the written-back value, so a second edit on the same card renders from
  current state instead of a stale mount-time copy.

### Added
- **The TTS editor is unified to the provider + model form, and voices are editable.**
  The old flat TTS config (one entry = one model = one fixed voice) is replaced by the
  same provider + model list shape the image and video sections already use. Each model
  carries its own editable voice, the ★ default route is picked per model
  (`providerId|modelId`), the timeout is per provider, and dropdowns only list entries
  whose model name is filled (same rule as image/video). Legacy `ttsApis` settings are
  migrated automatically on load (deterministic derived ids, the old default route
  carried over), and node data never stored a TTS config id, so there is zero node-data
  migration burden.

### Internal
- **check-pack gained an import-resolution audit over the packed file list.** After
  `npm pack --dry-run --json` produces the manifest, every packed `.js` file (including
  `assets/`) is scanned for static relative imports — `from './x'`, `import('./x')`,
  `require('./x')` — with comments stripped first (string literals preserved), each target
  resolved against the file's own directory, and any target outside the manifest fails
  the check with the offending pair named. This is the mechanical guard born from the
  0.20.2 shot-segments incident: hand-maintained required-file lists drift exactly like
  the changelog COVERAGE list did, and now that drift fails regress instead of shipping.
- **Settings-card regression is behavior-level across every card: mount first, then
  alternate writes.** The cross-card tests no longer reuse a single render — each card
  is mounted before writing, edits are interleaved across cards, and a three-card
  snapshot-revert mutation check verifies the suite's teeth actually cover all settings
  cards (the mutated old write-back mode is caught, the fixed one passes).

## [0.20.2] — 2026-11-09

### Added
- **Auto creation generates entity reference images before the paid run.** When a scene's
  storyboard has segments still to generate, the runner first builds 「<类别>-<名> 设定图」
  image nodes for the entities named in its shots (characters / scenes / props), generates
  them, and connects each one (`ref` port) to every video segment node of that scene before
  any video executes — generation reads references strictly from wired edges, so the wires
  must exist first. Entities shared across scenes are generated once per run; entities that
  already own a reference asset (name-boundary match against the project asset index) are
  skipped; a failed reference image never blocks the video segments. The budget sheet gains
  a reference-image row item so the cost of the setup pass is visible before approval.
- **Partial paid runs: execute selected scenes only.** `canvas_auto_generate` accepts a
  `scenes` array of 1-based scene numbers (matching the budget sheet's scene numbering);
  only the picked scenes produce video nodes — excluded scenes build nothing, and their
  entities are never collected (not even reference images). The approval token and its
  fingerprint are untouched: the full-budget check still gates the run, `scenes` is purely
  an execution filter, and omitting it keeps the old full-run behavior byte for byte.
- **Free-phase checkpoint resume.** The writers-room free phase now persists its progress
  into the canvas's production state after every completed unit (research → pitch A →
  pitch B → critique → decision → write-back → script → per-scene boards). A run that died
  mid-way (failure or abort) resumes from the checkpoint: completed units replay their
  stored outputs directly — no LLM calls, no node rebuilding — and only the remaining units
  execute. Corrupted, stale or already-finished checkpoints are treated as "no
  persistence" and start fresh; a checkpoint write failure never blocks the pipeline.
- **Video request preview, pre-submission checks, and a sanitized submission log.** The
  video node panel gains a read-only 请求预览: model, duration, resolution, first-frame
  anchor mode, reference-image roles and the full final prompt — computed with exactly the
  same assembly as the real submission, so what you review is what gets sent. A
  validation-checks block surfaces concrete problems (missing references, conflicting
  anchor modes, empty prompts) before the money is spent. Every video submission, finish
  and failure is appended to `<project>/submissions.jsonl` with method, parameters and
  result summary — the host redacts secrets on write (sk- keys, Bearer tokens, signed
  query URLs), the log is capped at 500 lines (oldest trimmed), and any log failure is
  swallowed so bookkeeping can never block generation.
- **Settings card gains the auto-creation action entries.** The 自动创作（实验） card now
  carries the full action row: 启动创作 (one-line brief + start), 刷新预算, 批准付费
  (with an inline confirmation input requiring your own words), 开始生成 and 中止 — plus
  a live budget summary line (scenes / shots / seconds / pending calls / estimated cost)
  and a hint pointing at the video unit-price setting when no price is configured. During
  any action every button disables (re-entry guard).

### Fixed
- **Production tools crashed with a ReferenceError (P0).** The tool-registry wrappers for
  `productionStatus` / `productionCapabilities` / `productionAdvance` invoked the methods
  bare (missing the `methods.` prefix), so every call from the chat agent threw
  ReferenceError instead of returning the stage report — the monitor round's main source
  of ground truth was dead on real machines. All three now route through the method table,
  pinned by registration-shape assertions.
- **The multiAgent capability flag is read from the probe verdict, not a text line.**
  `productionStatus` derived `multiAgent` from a substring match on a rendered text line,
  which made the flag always-true. It now takes `caps.multiAgent` directly from the
  capability probe (undefined when the probe itself fails — unknown, not "available").
- **Prose no longer breaks the monitor's decision round.** A prose sentence containing
  braces ("我认为{这是花括号}") before the real JSON made the parser latch onto the first
  `{` and kill the genuine object; a prose-only reply failed the whole run. Extraction now
  scans every `{` candidate with a string/escape-aware depth counter (fenced block first,
  full text as fallback), and a failed parse retries the monitor round once locally
  instead of sinking the entire free phase.
- **G2 regeneration injects the complete failure list.** On a failed storyboard quality
  gate, the automatic regeneration used to rerun with the node's original requirement —
  the same prompt produced the same violations (11 items, verbatim, on a real machine).
  The full numbered failure list is now appended to the storyboard's requirement before
  the rerun (every item, not a truncated two) and the original requirement is restored
  after the recheck passes, so node data is never polluted.
- **Budget `videoCalls` is estimated by the same shot-segmentation algorithm that executes.**
  The quote counted one video call per storyboard while the paid runner actually generates
  per shot-segment, so a 40s scene billed 4 calls against a budget of 1. `planShotSegments`
  is now a shared module (`shot-segments.js`) imported by both host and client — quote and
  execution agree by construction (same empty-plan fallback: one call). The budget
  fingerprint covers the segmentation results and per-board caps, so **approvals issued
  before this change expire once and require a fresh human review** (deliberate, no
  compatibility shim); the paid runner logs a budget-vs-actual deviation when shots were
  edited after approval.
- **Every scene is capped at 15 seconds — enforced twice.** A project guide saying 「每场
  ≤15 秒」 was ignored and the writers room produced 40s scenes. The monitor round's
  `scriptIdea` contract now states the cap explicitly (longer stories must split into more
  scenes, never stretch one), and after storyboard generation each scene's shot durations
  are checked with the shared segmentation algorithm (same `segMaxSeconds` source as the
  client, default 15); an over-cap scene gets a repair requirement injected and is
  regenerated automatically.
- **Paid videos are split per shot-segment, not one request per storyboard.** The paid
  runner generated a whole storyboard in a single video request — a 40s scene hit the
  vendor's per-request limit (relay 400, money burned). Each segment from
  `planShotSegments` now becomes its own video node (named 「…·段k/N」, prompt constrained
  to its shot range, segment metadata in the node data for the client's tail-chaining),
  the final-cut node connects to the last finished segment, and legacy single-node
  storyboards still resume correctly (only the missing segments are built). Retry
  semantics are per segment.
- **Dialogue fragments no longer flagged as unregistered entities; bible edits refresh
  storyboard warnings.** A line like 「来了个带纸的」 extracted a prop 「带纸的」 that
  tripped the unregistered-entity warning on every storyboard. Names ending in 「的」 that
  literally appear in the scene's dialogue text are now exempt (host
  `storyboardConsistencyWarnings` and client `checkShotConsistency` share the identical
  rule, guarded against drift; the @mention channel is never exempt). Separately, editing
  the bible now bumps a `bibleTick` signal so open storyboard detail panels recompute
  their consistency warnings automatically — no more stale warnings after fixing the
  设定集.

### Changed
- **Budget approvals are invalidated by the new estimate basis (one-time).** Because
  `videoCalls` now counts shot-segments (see above), the approval fingerprint changes for
  every existing budget: a previously approved quote is rejected once and the budget must
  be re-reviewed and re-approved with your own confirmation words. This is the intended
  safety semantic — money-relevant numbers changed, so the old human sign-off no longer
  applies.

### Internal
- **Settings-card actions are behavior-tested.** The panel suite gained real click
  assertions for the start flow (brief carried into `autoStart`) and the approve flow
  (recent quote id + confirmation words into `autoApprove`), and the busy-state
  re-entry assertion was rewritten to match every action role exactly (the old regex
  had a dead branch that could silently pass).
- **Repo housekeeping.** `.superpowers/` (SDD process directories) and `.worktrees/`
  (isolated work trees) are now git-ignored.

## [0.20.1] — 2026-11-06

### Added
- **Skill-profile awareness in the writers room.** The monitor's decision round in
  autoRoom now receives a "project skill-pack profile" header (renderProfile, same
  source as the skill-pack head) so its picks align with the configured genre/look/form;
  brief still owns the story, unconfigured projects say so explicitly and behave
  unchanged. Pinned by a writers-room regression with a written skill profile.

### Fixed
- **Image-gen bridge models actually generate again (P0).** `flattenImageModels` dropped
  `viaImageGen` / `imageGenProvider` when flattening providers into the picker view, so a
  bridged `dsh-image-gen` model showed up in node dropdowns but routed to the plain
  image API on generate — empty base URL, "image API not configured", bridge always
  broken. Both fields now survive the flatten (provider-level flag + per-model provider
  name), non-bridge providers stay unflagged, and a behavior regression (real
  `flattenImageModels` in the sandbox) pins the contract.

### Changed
- **Bridge status line no longer multiplies by the switch.** 「已配置 / 未配置」 on the
  dsh-image-gen bridge card now reflects the plugin-side config state only; the toggle
  governs model sync alone (configured-but-off no longer lies as "not configured").
- **Bridge sync writes nothing when nothing changed.** `syncBridgeModels` diffs the
  previous settings before saving, so probing on every settings mount no longer triggers
  saveSettings → notify re-render loops.
- **Fight-rhythm card injects only for action/conflict genres.** The 4.9KB fight-rhythm
  moves card no longer rides along with every storyboard build; it joins when the
  project's genre is one of twelve action/conflict genres (wuxia, action-mission,
  gunstandoff, crime-police, hk-retro, wasteland-chase, mo-lei-tau, revenge-face-slap,
  multi-thread-caper, neon-dystopia, rebirth-transmigration, adventure). camera-moves
  stays mandatory for storyboards. Host (skill-pack.js) and client (buildSkillPackText)
  share the same whitelist.

### Internal
- **Bridge model flattening is behavior-tested, not regex-guessed.** `flattenImageModels`
  and `resolveImageModelCfg` are exposed through the `__DSH_IC_SETTINGS__` test gap; the
  panel suite asserts flag passthrough on real objects, the skill-pack suite pins the
  conditional fight-rhythm matrix (action genre / calm genre / no genre), and
  test-production asserts the monitor round carries the profile header.

## [0.20.0] — 2026-11-06

### Added
- **Image models from `dsh-image-gen` (zero duplicate config).** The settings tab gains 「图片模型（来自 dsh-image-gen）」: it probes that plugin's own `/plugins/dsh-image-gen/studio` bridge, lists only the providers it has already configured, and lets you pick provider + model. With the switch on, canvas image generation goes through the same bridge — `apiGenBridge` POSTs `{mode, provider, model, prompt, ratio, references}` and reads the returned attachment back through `/plugins/dsh-image-gen/image`, so **credentials never leave the image-gen host and the canvas needs no base URL or key**. Reference images are converted to the bridge's encoded form (up to 4) and failures surface the upstream message verbatim. The bridge card is a toggle plus a 未配置/已配置 status line — enabling it syncs image-gen's models into the node model dropdown as a 「桥接dsh-image-gen」 group, so you select them right on the image node; disabling removes them. When the plugin is absent the card hides itself instead of breaking canvas-side providers. Routing through image-gen also covers its full provider set (Google native, DashScope, Seedream, xAI, Zhipu, OpenAI-compatible channels, ComfyUI, subscriptions) instead of re-implementing adapters.
- **Auto creation becomes a real chat-driven chain (P0–P2).** The switch alone used to gate RPCs nobody could reach: the chat agent had no auto tools and the persona kept asking questions. Now: **five agent tools** (`canvas_auto_status` / `canvas_auto_start` / `canvas_auto_budget` / `canvas_auto_generate` / `canvas_auto_abort`) let the conversation drive everything; **the persona and the canvas-studio skill gain an explicit branch** — with the switch on, the agent opens the canvas itself (`canvas_open`), forbids step-by-step questions (director/genre/spec/look are chosen by the 监制 with a recorded rationale), extracts the brief, starts the writers room, and only stops once for the budget; with it off, the guided workshop stays. The free phase now runs all the way to the promised end: writers room → bible → script idea → **script generation** (canvas auto-opened and polled) → split by 【场N】 → scene text + storyboard nodes (`tail→prev` chained) → **storyboard generation + G2 check** (one automatic regeneration on failure) → **budget sheet**. The paid phase v1 lands behind it: approval required, per-storyboard video nodes (G2/G3 gates), generation with 2 retries, and a final-cut node at the end; the settings card shows the budget (scenes/shots/seconds/pending calls/cost), an approve button and a generate button, all reporting progress through `autoStatus`. Everything is exercised end-to-end in `test-production` with injected LLM + canvas runners (2-scene project → 2 storyboards → budget → 2 videos + final cut).
- **Precise node layout — and `canvas_relayout` stops stacking everything into one column.** The agent can now place nodes exactly where you ask instead of only "re-laying out" the whole board: `canvas_layout_get` returns the full geometry map (every node's `nodeId / name / type / x / y / w / h / pinned` plus the canvas bounds), and `canvas_layout_node` batch-sets positions (negative coordinates allowed), resizes media nodes **while preserving the picture ratio** (give only `w` or only `h` and the other side is derived; an inconsistent pair is refused with the exact derived value instead of being silently reset), and pins a node (`pinned:true`) so later relayouts leave it alone. `canvas_relayout` now respects pinned nodes and packs rows in bands by height: isolated clusters used to all start at x≈80 and read as one endless vertical column; they now wrap into a grid-like board; the canvas-layout skill documents which tool to use for which request. Relayout correctness is now pinned by an invariant: **same-depth siblings inside one cluster stack vertically instead of landing on identical coordinates** (a script feeding six scenes used to stack all six storyboards exactly on top of each other), pinned nodes act as obstacles the packer must not cover, and a pairwise zero-overlap assertion over every node gates both fixes in the regression suite.
- **Production stage machine + six code gates (0.20.0 groundwork).** Every canvas (one episode) now carries a host-owned production stage — `brief → bible → assets → script → storyboard → shots_ready → generating → qc → post → delivered` — inferred from the document for projects that predate the feature (nothing blocks on upgrade) and materialised into `<project home>/production/<canvasKey>.json` on the first write, with an append-only history and an override audit trail. The stage governs *process*, never *content*: it decides which class of operation is in order, not what the story is. Six gates are enforced in code rather than prose (the rule text only explains them): **G1** bible-first (script/storyboard generation requires worldview + style + ≥1 character), **G2** storyboard quality (non-empty shots, durations, concrete shot sizes, ≥1 big close-up, no three consecutive identical motions, legal `seg`, ≤24 shots), **G3** one video per storyboard (edit the existing node's parameters instead of creating a second), **G4** no per-shot nodes (names containing 镜N are refused — consistency comes from reference-image assets), **G5** destructive-operation confirmation (`confirm` must carry the user's own words), and **G6** stage-order (video generation requires `shots_ready`). Each gate refuses with structured fields (`gate`/`missing`/`fails`/`fix`) and every gate has an escape hatch — `override: { by: 'user-explicit', quote: '…' }` — because an explicit user instruction always outranks process; overrides land in the audit log. New tools `canvas_production_status` (stage, gate verdicts, evidence counts, blockers, next step; the only basis for claiming "done" — `ready:true`) and `canvas_production_advance` (explicit advance/rollback for rework, `reason` mandatory); `canvas_node_status` now returns the current stage, and `productionCapabilities` probes for host session services so the upcoming multi-agent mode degrades cleanly instead of failing to load.
- **Auto-creation mode: the A1 two-phase data plane (experimental, off by default).** The multi-agent auto-creation entry point gains the part that must never be improvised — money. `autoModeGet`/`autoModeSet` expose a switch that is **off unless the user turns it on**: while off, every `auto*` RPC refuses with `disabled:true` and nothing is scheduled, so an install behaves exactly like 0.19.21. With it on, `autoQuote` produces the budget sheet at the end of the free phase — scenes, shot count, total seconds, and how many video calls are actually pending (storyboards that already own a video node cost nothing) — and, when a unit price is configured, an estimated amount. `autoApprove` issues a **one-shot approval token bound to the budget fingerprint**: the quote id is derived from the storyboards, their shots and durations, so changing any shot invalidates the previous approval and forces a fresh human review; approval also requires the user's own words (audited like every other gate). `autoStatus` reports switch, stage, blockers, approval validity and the current quote in one call. No session is spawned and no provider is called in this increment — the runner lands with the role presets.

### Fixed
- **Paid phase can be aborted, and the settings cards are switch-only.** `autoAbort` now also stops the paid runner between videos (finished ones are kept), and both experimental cards were slimmed to switch + status — the entry point for auto creation is the Harness chat composer (`canvas_auto_*` tools), not the settings panel.
- **Paid phase can be aborted, and the settings cards are switch-only.** `autoAbort` now also stops the paid runner between videos (finished ones are kept), and both experimental cards were slimmed to switch + status — the entry point for auto creation is the Harness chat composer (`canvas_auto_*` tools), not the settings panel.
- **Paid-phase abort hardening + docs refresh.** The paid runner honours the abort flag between every video and retry, `docs/auto-creation-design.md` was rewritten to match the shipped in-process implementation, and README/guide (EN+ZH) gained sections for the stage machine, auto creation, the image-gen bridge and the precise layout tools.
- **The binding chip no longer breaks the composer row.** A bound session's chip label (`project·episode`) is wider than 仅会话, and the wrapper had no shrink constraints, so the host composer's right group (database/mic/send) was pushed out of the border. The wrapper is now `flex:0 1 auto; min-width:0; max-width:180px`, the chip `max-width:100%`, and the label `min-width:0` with ellipsis; a panel-structure gate pins the constraints.
- **Workspace projects are named after the workspace, not its folder.** `wsProjectCreateAt` derived the project name from `path.basename(workspace.path)` — when the folder is a random id (`wsmw3hao7et2ll`) while the workspace display name is `test-2`, the project showed up as the id and the chip (which reads the workspace title) disagreed with the project dropdown. Names now prefer the workspace **title**, then the folder name, then 画布项目; `workspaceProjectCreate` returns the real `name` and the client registers that instead of a stale/empty binding name (an unknown name is no longer written as the project id). Existing machine-named projects (name equals the folder, the project id, or a `ws…` random string) are renamed to the workspace title on the next adopt/bind, while user-renamed projects are never touched.
- **Auto mode no longer asks questions, and a bound session can no longer see the whole board.** The persona and the canvas-studio skill used to leave one escape hatch — "if the brief is too thin, ask one question" — which the model took, so enabling auto creation still ended in an `ask_user_question`. Both texts now **forbid questioning outright** (when the switch is on, the 监制/编剧室 invents three candidate directions and picks one, recording the rationale), and `canvas_auto_status` re-states the rule in its tool output every turn ("【自动模式·硬规则】禁止提问…本轮必须 canvas_auto_start"), so the instruction survives compaction and long contexts. A regression gate asserts the persona keeps the hard rule and never regains the "只问 1 个" phrasing. Separately, the session↔canvas lock only applied to tools that declare a `projectId`, so `canvas_list_projects` — which declares none — leaked every project, every node and every coordinate to a bound session (the model happily reported "4 projects, 129 nodes"). Bound sessions now see **only their bound project** in `canvas_list_projects`, and `canvas_create_project` is **refused** inside a bound session (unbind first); unbound sessions keep the old unrestricted behaviour. Both are covered by regression.
- **Deletion gates no longer break existing flows silently.** The strict regression suite now passes the user's confirmation words for deletions and ships gate-passing storyboard fixtures, so G5/G2 are proven end-to-end instead of relying on prose rules.

### Changed
- **Deletion RPCs now require `confirm`.** `canvas_delete_node` and `canvas_delete_project` refuse without it and return `gate: "G5"` with the fix spelled out — the model can no longer delete "to reset" a node on its own initiative.
- **`canvas-studio` rewritten as a flow manual (M2).** 415+ lines of百科 prose → 168 lines led by the stage machine and the six gates: the manual now opens with 阶段机/闸门/逃生舱 (the enforcement this release adds), keeps every hard rule (bible-first, project dedupe, one-script-node idea+output, storyboard granularity, `tail→prev` continuity, lip-sync, four continuation fields, G2 self-check, multi-canvas, memory-first discipline) in compressed form, and hands craft detail to `canvas-craft` / `canvas-director` / `canvas-layout` instead of duplicating it. All 23 `canvas_*` tools remain referenced; the skill-pack slices are untouched (they read manifest cards, not this prose). The skill grew *shorter* so the model actually reads it — adherence is enforced by the gates, not by the length of the manual.

### Internal
- **Gate refusals are structured results, not thrown errors.** `canvasCreateNode` / `canvasRunNode` / `canvasGenerateNode` return `{ ok:false, gate, missing|fails, fix }`, and every tool wrapper propagates those fields instead of reporting success.
- **`canvas_production_status` reports the multi-agent capability.** The tool output carries the M0 probe verdict (host exposes session services or not), so the auto-creation runner can be verified from inside a conversation without any HTTP access to the desktop host.
- **Settings card for the auto-creation switch + M3 runner design.** The settings tab gains 「自动创作（实验）」: the on/off toggle wired to `autoModeGet`/`autoModeSet`, live capability line (multi-agent available / host lacks session services), and an explicit "restart Harness" hint on old hosts instead of silent failure. `docs/auto-creation-design.md` freezes the M3 implementation plan (role presets YAML draft, tool matrix, runner dispatch order, M0 verification checklist, rollback) so the runner lands the moment the probe confirms session services.
- **Production stage row in the projects tab.** The right panel shows the active canvas's current stage (「制作阶段：分镜定稿 · 可交付」) with blocker count, refreshed on canvas switch and every 30s via `productionStatus`; on old hosts the row silently hides (no RPC → no noise), so the stage machine becomes visible without touching the canvas graph UI.
- **Writers-room runner — the free phase actually runs (experimental).** With the switch on, the settings card gains the one-line brief input and 「启动免费段」: five structured role rounds execute in-process over the plugin's LLM channel — 题材调研（离线知识，明确标注） → 编剧A/编剧B **independent pitches** (neither sees the other) → cross-critique (冲突强度/动机可信/成本可行性, ≤3 each) → 监制决策 (pick-or-merge with rationale) — and the outcome lands where the canvas workflow expects it: the full transcript becomes a 「编剧室会议」 text node, the decision's bible draft is merged via `canvas_update_bible`, and 第1节剧本 is created with the decided idea and triggered (generation still belongs to the node; open the canvas to watch it). Zero paid calls — the run stops before anything costs money, `autoAbort` keeps partial outputs, `autoStatus` streams phase/log, and the runner tolerates models that nest `scriptIdea` inside `bible` (reads both). Rules govern the process and format only: the story comes solely from the brief. The multi-session executor (real per-role DSH sessions) upgrades this path behind the same RPCs once the host exposes `sessionController`; the design stays in `docs/auto-creation-design.md`.

## [0.19.21] — 2026-11-03

### Added
- **Workspace-embedded projects (`<workspace>/.infinite-canvas/`).** A workspace directory can host a project home: `project.json`, `canvases/`, `memory/`, `bindings.json` live under `.infinite-canvas/` inside the workspace, discovered by a host-side workspace-registry scan (marker file, stable id inside the doc — re-adding the directory re-adopts the same project). The document layer routes transparently (`readDocOrNull`/`writeIcDoc`), so every tool and RPC works on workspace projects unchanged; `projectsList` merges both sources (workspace entries carry `origin:"workspace"` + `wsId`/`wsPath`); deleting a workspace project removes `.infinite-canvas/` only, never the workspace itself. Media keeps flowing through the data-root pipeline (known trade-off: copying the workspace carries all docs/memory/canvas documents, media stays in the data root). Old hosts without a workspace registry degrade to no-op.
- **Project memory store (per-episode memory + scheduling index).** Each canvas (one episode) gets a memory body `memory/episodes/<canvasId>.md` plus a project-level index `memory/index.json` (title / ≤120-char summary / keywords / drafting-done status), written atomically with a same-project write chain and an `index.backup.json` of the last good state; corrupt or missing indexes rebuild as empty instead of failing. Memory homes follow the project: workspace projects embed it in `.infinite-canvas/memory/`, data-root projects use the project folder, and with no data root at all it lands in `PROJECTS_DIR/<pid>/` — the feature never goes missing for IndexedDB users.

- **Workspace watcher + session-binding RPC surface.** The host polls `workspaceRegistry` every 5s (defensive `ctx.get` — never declared in `inject`, so hosts without the service just run the watcher as a no-op): workspaces without a `.infinite-canvas` marker get a project auto-created (default canvas 第1集, named after the directory), marked directories are adopted as-is, and when a workspace project has no bindings yet and exactly one session exists, that first session is auto-bound to the default canvas (multi-session workspaces never guess — manual binding). A vanished directory skips without deleting anything. New RPCs: `sessionBindingGet` (workspace + project + binding + canvas list + occupancy map, `supported:false` on old hosts), `sessionBindingSet` (workspace-embedded projects only, alive-map occupancy), `sessionBindingClear`, `workspaceProjectCreate` (auto-binds only when it actually creates; reuse never force-binds), `memoryGet`/`memoryPut`. An RPC-side single-workspace rescan no longer wipes other workspaces' cache (full-registry rescan only).
- **Composer canvas-binding chip + panel follow (client).** A compact transparent-line chip sits in the composer tool row (the `conversation.input.left` session-scoped slot — the runner hands it `sessionId` for free): workspaces without a project show 建画布项目 (one click creates the embedded project and binds this session to episode 1); bound sessions show 第N集·画布名 and clicking jumps the right-pane canvas to the bound episode; the ▾ menu binds any listed canvas (occupied ones marked 已被其他会话占用), creates a named canvas inline, or unbinds. The canvas pane auto-follows the active session's binding (pane host only — the fullscreen panel never auto-switches), hydrating from the host so the graph is never stale. Old runners without the slot or old hosts without the RPCs degrade to today's behavior (chip absent, global canvas state).
- **Memory viewer (studio modal "memory" tab).** The left icon rail gains a 记忆 entry beside 设定集; the tab lists the project's per-episode memory index (episode number, title, drafting/done status, ≤120-char summary) and clicking an episode shows its full memory body read-only — any episode's memory at a glance, exactly what cross-episode continuity needs. Data comes from the same `memoryGet` RPC the agent writes through; humans never edit, so agent-maintained memory stays single-source.
- **Memory-first discipline in the canvas-studio skill (hard constraint #18).** 会话=画布工作台：`canvas_my_canvas` first to self-identify the episode, memory index + own-episode body read via `canvas_read_memory` before writing (index = the cross-episode ledger of character state / foreshadowing / timeline; bible keeps the static settings — the two never duplicate), and `canvas_write_memory` is mandatory at every episode milestone (not writing back = the next episode re-invents settings and loses foreshadowing). A contract gate pins the wording against silent removal.
- **Session-aware tool defaults + `canvas_my_canvas` (chat agent operates the whole bound canvas).** With the「媒体创作」preset driving a bound session, every `canvas_*` tool now resolves the calling session (defensive sniff of `exec.agent` session identity across harness versions) and defaults missing `projectId`/`canvasId` to the bound project/canvas — the agent writes, connects, runs, deletes and reads any node on its episode canvas without repeating ids, and can still touch any other project/canvas by passing explicit args (explicit always wins; sniff failure silently keeps the old behavior). Injection only touches params the tool's schema actually declares. `canvas_my_canvas` self-identifies ("this session = episode N of project X", memory status hint, full-content operation pointer) so the agent orients before creating.
- **Session↔canvas bindings (one session = one episode canvas).** A session binds to exactly one canvas of one project (`bindings.json` in the project home: `{sessionId, canvasId, boundAt}`); rebinding a session replaces its own entry. One canvas serves one session: binding onto a canvas held by a living session is rejected with `occupied` + the holder's id, while a holder that no longer exists (deleted session) is treated as an orphan and overridden. Unbind is idempotent. Canvas/project ids are validated before any file touch.

### Fixed
- **仅会话 works from any bound project (including old data-root projects).** `sessionBindingClear` still resolved the target project from the session's workspace project, so unbinding a session that was bound to a data-root project (时空邮递员 etc.) found nothing and silently returned `removed:false` — the menu closed and the chip stayed bound. Clearing now resolves the session's **actual binding** globally (same lookup as the read-back), and the client clears its local binding state optimistically so the chip flips to 仅会话 instantly, returning the menu to the project-picking state.
- **New sub-canvases from the chat selector appear in the project tree immediately.** The selector's 新建子画布 only wrote the host registration and never updated the client project store the tree reads from, so the canvas existed (and was even bound) yet the right-panel tree showed only 默认画布. Creation now registers locally — append to `S.projects[...].canvases`, persist, seed an empty canvas document — before binding, so the tree and the chip agree instantly.
- **Collapsing the canvas list no longer hides the search row.** The search/new-canvas row was rendered under `proj && !collapsed`; collapse now hides only the canvas list below, exactly as 「折叠下方」 implies — the search box and the new-canvas button stay visible.
- **Chip shows the selected value, and a stale host is called out.** The unbound chip now reads **仅会话** (the current selection) instead of the hint text 选择画布 — picking 仅会话 visibly "takes", and any canvas pick shows 项目·画布 immediately. A capability probe (`bindingCapabilities`, rev 2) runs when the chip mounts: if the host process predates this build (the web client updates on page reload but `index.js` only loads at Harness startup), the menu shows a top warning 「宿主插件是旧版本：请完全退出并重启 DeepSeek Harness 后再试」 and every bind/unbind/create action is intercepted with the same message — no more silent failures against a stale host.
- **Canvas selector actually shows your projects and reflects the choice.** The menu's project list now comes from the client project table (the same source as the canvas app's project dropdown), so existing/old projects always appear — the host's `bindableProjects` is only a supplement (it was previously the sole source, which left the menu empty whenever projects lived client-side or host discovery hadn't caught up). Clicking a canvas binds and immediately updates the chip from local knowledge (project·canvas shown without waiting for the host read-back); bound menus fall back to the local canvas registry when host read-back is thin. 创建项目 now has two channels: workspace-embedded when the session is attached to a workspace, otherwise the ordinary project-creation path (then bind) — and failures render inside the open menu instead of vanishing. Structural gates pin the data source, optimistic update, fallback channel, and in-menu error row.
- **Canvas selector: host-format two-level menu with clean labels.** The composer control is one integrated dropdown (folder icon + selected text + built-in ⌄, light filled pill like 「选择工作区」) — no separate arrow button; bound text reads 项目·画布 (e.g. 门缝里的字条·第一集 — no duplicated episode prefix). Unbound: 仅会话 (highlighted) / 创建项目 / existing projects (project row expands inline to its sub-canvases + 新建子画布) — clicking the chip never creates anything by itself. Bound: the project is locked, the menu lists only that project's sub-canvases (current highlighted, occupied dimmed with 占用中) + 新建子画布, plus 打开画布 and 仅会话 (= unbind). Menu follows the host selector's look: icon rows, selected-row highlight, 1px separators before action groups. UI copy carries no parenthetical notes (仅会话 / 创建项目 / 打开画布 / 新建子画布 / 占用中); a gate forbids parentheses in binding labels. UI rule #44 rewritten.
- **Review-pass hardenings.** One session = one canvas is enforced globally: rebinding a session in another project removes its stale binding there, so session-aware tool defaults can never land in the wrong project silently. Workspace doc ids are re-validated through the `projectFile` charset check before mapping to `.infinite-canvas/...` paths (a `pid__cv__../../x` probe reads as "project not found" instead of touching the filesystem), and `docExists` returns false for illegal ids instead of throwing.

### Changed
- **Bindings can target any project; the selector lists them all.** A new `bindableProjects` RPC returns workspace-embedded and data-root projects together (each with its canvas list, sorted by recency); `sessionBindingSet` no longer restricts to workspace projects, bindings live in each project's home, and every lookup (session read-back, one-session-one-canvas uniqueness, session-aware tool defaults) now scans all projects, so a session bound to a data-root project resolves and locks exactly like a workspace one.
- **Explicit-only binding: the workspace watcher no longer creates or binds anything.** A session may run coding or other non-canvas work, so binding must never be imposed: the watcher is discovery-only — it scans workspaces for an existing `.infinite-canvas/project.json` marker and lists it, but never auto-creates a project and never auto-binds a session; deleting a project can't resurrect (there is no auto-create path at all). Binding happens only when the user acts in the composer chip: 建画布项目 (creates episode 1 and binds) or 绑画布 (picks an existing canvas). Not touching the chip = session only, permanently — nothing binds back after an unbind.
- **Code-level cross-canvas ban for bound sessions.** A bound session's `canvas_*` tools reject any explicit `projectId`/`canvasId` that differs from the binding (other projects, other canvases in the same project, even the default canvas) with `locked:true` and a "请先解绑" pointer — hard enforcement in the tool wrapper, not skill discipline. Omitted ids still resolve to the bound canvas; unbound sessions keep full freedom across all projects/canvases.

### Internal
- **Contract tests for workspace projects and the memory store** (`scripts/test-workspace-projects.mjs`, `scripts/test-memory.mjs`): marker discovery, document routing, list merge, workspace-project deletion, watch-tick degradation; memory roundtrip, index ordering/caps, backup-on-overwrite, workspace placement, concurrent-write serialization; review-pass regressions (§5b–5e: delete tombstone, unbind persistence, global session uniqueness, path-escape rejection).
- **Binding-layer contract test** (`scripts/test-binding.mjs`): bind/rebind/occupancy/orphan-override/unbind idempotence, workspace placement, illegal-input rejection.
- **Memory agent tools** `canvas_read_memory` / `canvas_write_memory` (`scripts/test-memory.mjs` §7): tool-plane write→read roundtrip, index rendering, body fetch, missing-canvasId rejection, discipline wording in descriptions.

## [0.19.20] — 2026-11-02

### Added
- **Genre cards v3: option-menu mechanism libraries, no mandated story direction.** All 37 genre cards rebuilt: the five story-playbook sections (pressure engine, character strategy, payoff, hook orientation, act pacing) become option menus — conflict/personnel/payoff-hook/pacing libraries, each listing 3+ selectable directions that can be combined, adapted or skipped; 题材核心 becomes a short 题材基调与世界观; drift bans keep only visual/factual rules. The script-slice pack head now carries the doctrine — entries are combinable parts, events and direction belong to the script — plus the material precedence (existing novel/script text and the bible outrank the genre library; style and camera always apply). A regression gate bans the old single-direction sections and template phrases across all cards.
- **Shanhai Myth genre card with material libraries.** 异兽图志库（12 beasts with form/habitat/habitat-scale cues）、法术能力库（八门能力，各配画面呈现）、神器地理库 — tagged as a `library` slice consumed only by the asset-sheet capability (beast sheets can be drawn straight from the library); script and storyboard never receive it, so library settings can never override an imported novel. Its 冲突机制库 deliberately includes cost-covenant as ONE optional pattern, never a mandate.

### Fixed
- **Canvas nodes take the asset's name; the "image" category is gone; unified import handles text.** Adding assets to the canvas now names nodes after the asset (no more 图片1/视频2/文本1) on both the single-add and batch paths. The redundant "image" asset category is removed — character/prop/scene already are images, everything else lands in General — with legacy `image`-tagged assets normalized at read time (filter/search/card dropdown), no data migration. The single Import button now routes by file type: images/videos as before, plus `.txt`/`.md` files import as script text assets (name from file name) ready to batch-place on the canvas as storyboard sources.
- **Assets panel: strict project isolation, search/scope on one row, project dropdown on text cards.** The filter used to let General-project assets bleed into every project's view; scope now filters strictly (General assets are visible only under the "General project" scope or "All"). The search box (with an embedded magnifier) and the project selector share one row (≈2/3 + ≈1/3). Text assets (scripts/storyboards) get the same project dropdown as media cards — the ownership control was missing there, not the data.

### Changed
- (无。)

### Internal
- (无。)

## [0.19.19] — 2026-11-01

### Added
- **Sanbao image task protocol (async, queryable).** Sanbao's OpenAI-compatible image endpoint times out at the proxy (>120s to render) with no task id to recover from — the money was spent but the image was lost. Image requests against `sanbaobeauty.com` now auto-route to the async task protocol (`POST /openapi/v1/images` → poll `GET /openapi/v1/images/{taskId}` → download), also selectable explicitly as the「三宝图片任务」mode. Local reference images upload via `/openapi/v1/uploads/raw` using the extended-param `uploadKey`; the task id persists on the node (`taskId`/`taskQueryUrl`) so any interrupted run can be recovered by id; the result download reuses the transient retry window. Generic OpenAI-compatible submits additionally get one transient retry on 502/503/504/429/408 (401/400 never retried).
- **FX-driven storyboard contract (`fx_motion`).** Fantasy-facing genres and looks can declare `fx_motion: true`; the storyboard contract then injects an FX extension block: the motion bearer is decided by the picture (a still body plus one moving effect is a legal shot), `timeBeats` become picture-state beats for FX-led shots (exempt from the mandatory three body beats), a fantasy VFX lexicon, per-character FX signatures quoted verbatim across shots, the speed iron law (instant events are state differences across cuts — never animated inside a shot), and a keyframe-first tip for materialized techniques. Realist projects without fx cards behave exactly as before.
- **`state_jump` segment type (same-framing state jump).** Lantern-flash reveals, "a shadow already there", shadow-to-solid: now a legal cut point (`join='cut'`, no tail-frame chaining, camera locked) with explicit prompt language ("the subject is already fully present and STATIC in frame 1; never animate an entrance"), and the "characters popping in or out" negative is replaced on such segments with precise bans (no walking/drifting into frame, no morph). New 山海神话 (shanhaijing-myth) genre card with a seven-family FX lexicon (silhouette streak, summon four-beat, landing shockwave, per-character signatures); four fantasy looks (dark-myth-cg, guoman-3d-xianxia, east-epic-3d, saturated-epic) and four genres (fantasy, xianxia-cultivation, wuxia, smalltown-uncanny) flagged `fx_motion`.
- **Chat-side shot edits keep the four FX fields.** `canvas_update_node`, `canvas_node_status` and the RPC schema now round-trip `timeBeats` / `camera` / `vfx` / `negative`, so chat-authored FX shots no longer degrade to visual+motion when written through Host tools.

### Fixed
- **Storyboard capacity warning judges real shot count, not script length.** The warning fired on any scene script over 600 characters — regardless of how many shots were actually generated (a 914-char scene producing 9 shots reported "beyond 100-shot capacity"). The check now compares the generated shot count against `MAX_STORYBOARD_SHOTS` (100) and the message reports the real number; detailed FX storyboards no longer trigger it.
- **One tail frame per video.** Two uncoordinated pipelines could each save a "last frame" asset for the same video — the generation tail block (last + scored pick) and the media-node fallback effect racing in on an `assetsTick` — so one generation produced three tail assets in the library. The generation path now owns tail extraction exclusively (a `tailPending` placeholder locks out the fallback, which still handles imported/external videos), and only ONE frame is stored: the scored best pick when it differs from the true last frame, otherwise the last frame; both the `last` and `tailpick` chain ports point at it.

### Changed
- (无。)

### Internal
- (无。)

## [0.19.18] — 2026-11-01

### Added
- **Assets multi-select with batch add-to-canvas and batch delete.** Asset cards now carry a checkbox and click-to-select (double-click still adds a single node directly); a batch bar appears when selection is non-empty with "add to canvas (n)", "delete (n)" and "clear". Batch add places nodes to the right of the rightmost existing node via `layoutBatchColumns` (≤5 per column, stacked top-down, 60/40px gaps, zero overlap with existing nodes or each other), selects the created nodes, and skips audio assets with a count note. Batch delete reuses the per-asset deletion path (server delete + node unbind + history cleanup) behind a single confirmation showing the first few names, plus a select-all-page checkbox.

### Fixed
- **Sanbao downloads retry while the CDN cache warms.** A `succeeded` task only means transcoding finished; the first GET can return 502 for 2–3 minutes (worst case ~5) while the file propagates. The runner downloaded once and failed the whole generation. It now retries inside a 10-minute window (10s interval), refreshing the signed URL from the task status before each attempt; 401/400 still fail immediately, and a window timeout reports the task id so the result can be recovered.
- **Asset self-heal now runs on every startup.** The relink pass was only scheduled from the host-sync merge and canvas-switch hooks — a plain boot has no `docChanged` signal, so the pass never ran at all (the missing trigger behind "the fix did nothing" after restarts). The boot effect now schedules it explicitly (2s primary + 10s fallback) and every decisive path logs one `[IC] asset-relink: orphans=… recs=… fixes=…` line for runtime diagnosis.
- **Host sync no longer wipes repaired asset pointers.** `mergeHostDoc` keeps a local non-null `assetId`/`lastAssetId` for image/video nodes when the Host copy carries null (`protectMediaPointer`). This was the last link in the preview-loss chain: relinked pointers survived only until the next 3-second sync merge overwrote them with the stale Host document.
- **Generated nodes lost their asset previews after refresh / cross-machine open — and the reference itself was being permanently erased.** A MediaNodeBody history-cleanup effect could run before the store was known (refresh race) or against a local DB that lacks the asset rows (cross-machine), classify live assets as dead, and write `assetId = null` into the graph. The cleanup is now guarded (`store` must be known) and prunes only the history array — `data.assetId` is never erased by it. Damaged projects self-heal: on canvas load, nodes with `done` status but no asset are re-linked to their asset by exact `nodeLabel` match (latest one not referenced by other nodes), with a toast summary.
- **Auto-relink retry hardened.** The once-per-canvas repair memo no longer burns when the canvas graph has not loaded yet (startup race), so damaged projects relink their assets on the next scheduled pass instead of never.

### Changed
- **Assets page: one toolbar row and a jump-to-page pager.** Sync-all, import, select-page, batch add-to-canvas / delete / clear, and pagination now share the single row below the project selector instead of stacking as separate rows. Buttons are outline-only (transparent background, 1px border, text; red outline for delete) with no grey fill. Pagination is `‹ [page input] / N ›` with Enter/blur jump, invalid text ignored, out-of-range clamped, and the total count on the right; the row wraps on narrow windows with the pager pinned right.

### Internal
- Repaired asset relinking is driven by the `repairPlan` pure helper and end-to-end regression on the real damaged-project shape (orphan node + exact `nodeLabel` match).

## [0.19.17] — 2026-11-01

### Added
- **Selected nodes light up their connected edges.** All incoming and outgoing edges of selected (or box-selected) nodes render in bright green (`#2fe08a`, fixed high-contrast color) with a double drop-shadow outer glow and slightly thicker stroke; the glow clears when selection clears and never stacks with the edge's own selected style.
- **Update source auto-detection with China mirror fallback.** Update check and install now probe `registry.npmjs.org` and `registry.npmmirror.com` concurrently (3s timeout, probing the actual packument path). Official reachable → official (authoritative); official down with mirror reachable → China mirror (mainland direct-connection shape); both down → official (previous behavior preserved). The choice is cached in config for 24h and re-probed after expiry. The update banner gains a three-option source selector (自动检测 / npm 官方源 / 中国大陆镜像源) with manual override taking precedence, and install/check results report the source actually used. `pnpm add` gets `--registry` from a strict allow-list only — non-allow-list values are rejected before reaching the command line. Fallback chain: if the selected source fails, the other one is tried once, so a wrong guess never blocks an update.
- **Sanbao (三宝影像工坊) video vendor adapter for multi-reference generation.** Task-based protocol (`POST /openapi/v1/videos` + polling `data.status`), `reference: "all"` multi-reference mode, reference images as string data-URLs (accepted by every model per its `media_inputs`, live-verified), reference audio as `audios: [{tag, url}]`, lowercase `resolution` (480p/720p/1080p/2k) and pass-through `ratio`/`duration`. Select 三宝影像工坊 in the vendor dropdown; Base URL `https://sanbaobeauty.com`.
- **Style anchor (`styleAnchor`) on the series bible.** One-sentence (~40 chars) whole-film visual anchor produced alongside `style` by `canvas_update_bible`; legacy projects fall back to the first sentence of `style` (semantic sentence split, never a character-count cut). `style` full text keeps flowing into the script/storyboard LLMs — only the anchor reaches image/video requests.

### Changed
- **Video requests now use a master style lock (≤1.6KB) instead of the 17KB skill-pack dump.** Injection division of labor: the director's camera language, lens grammar and fine tone are digested at the storyboard layer into per-shot `camera`/`motion`/`visual` fields (the storyboard slice keeps the camera-moves lexicon, lens shot sections, fight rhythm and the look's colour thesis, plus a new contract line that writes the per-shot tone into `visual`). The video lock keeps only whole-film controls: the look's aesthetic phrase (≤200B), the delivery pacing line, and ≤6 inline negative phrases (dilution rule; field-routed negatives for vendors that support them come later). Teach-material sections (lens YAML, lighting rules, look essays, genre granules, drift bans) never enter generation requests.
- **Effective-prompt style lines and asset-sheet templates now use the style anchor** instead of the full `bible.style` text; the bible merge/normalize layers pass `styleAnchor` through end to end.

### Fixed
- **Image style lock silently dropped for every profile-configured project (since 0.19.14).** `buildImageLockText` referenced an undefined `EOL` in its return statement; the resulting ReferenceError was swallowed by the call-site guard, so lens bits / colour thesis / tone / material / genre material / negatives never reached image requests — with zero test coverage masking it. Fixed (`EOL` → `\n`, byte counting without `TextEncoder` so test sandboxes work) and now covered by functional assertions: the image lock must contain the header, lens bits, colour thesis, tone, genre material, negatives (≤2.6KB), and the assets variant must include the material section.
- **Sanbao runner now caps reference audio at 3** (`slice(0, 3)` on submit and on the upload-fallback retry path), matching the pre-flight warning instead of sending the full list and failing the relay's 400 limit.
- **Scene-header markdown tightened.** `parseScriptScenes` required an optional `场` in `#{1,4} 场?N` headers, so ordinary numeric headings like `## 2024年度总结` / `### 3 个技巧` were misread as scene breaks and produced ghost scene nodes; `场` is now required (`## 场N` still recognized), with counter-examples asserted in `scripts/test-script-scenes.mjs`.
- **"Expand to scenes" no longer loses the last scene's body.** The trailing-list stripper (`parseScriptScenes`) matched the first `人物：/角色：` line anywhere in the final scene and swallowed everything after it — scripts whose scenes carry their own `人物：` line (a common per-scene format) had the last scene reduced to its title. The stripper now only removes a pure trailing list block (人物/角色/场景/道具/地点 lines + blank + （终）/完 markers, including the combined `场景/道具：` form) that runs to the very end of the text; in-scene list lines and the （终） marker stay in the body. `parseScriptScenes` is exported for regression (`scripts/test-script-scenes.mjs`, new strict-regression entry).

### Internal
- If the submit request fails with an image/material-format or URL error, the runner uploads local blobs once via `POST /openapi/v1/uploads/raw` (raw binary body) using a dedicated `uploadKey` from extended params (`{"uploadKey":"sk-sanbao-…"}`, falling back to the main key) and retries with the returned `file.url`. Credits, auth, rate-limit and account-restriction errors never trigger the retry. Pure helpers (`buildSanbaoVideoBody` / `sanbaoTaskIdOf` / `sanbaoPollState` / `needsSanbaoMediaRetry`) are exposed for regression assertions in `scripts/test-vendor-detect.mjs`.

## [0.19.16] — 2026-10-30

### Fixed
- **Wan (DashScope) runner now accepts relay-rewritten response shapes.** DashScope-compatible relays (tiantoken-style) move `task_id`, task status, and the result URL to different positions and casings. The wan runner now reads `task_id` from `output.task_id / task_id / data.task_id / id`, lowercases the status found at `output.task_status / output.status / task_status / status`, treats `unknown`/`pending`/`running` as still-running (never a false kill), fails fast with `output.code + output.message` (top-level `message` as fallback), and falls back to `output.url` / `data.result_url` for the result video. No new vendor adapter was added.

### Added
- (无独立新增；本版为 wan runner 响应兼容性收紧。)

### Changed
- (无独立变更。)

### Internal
- Response parsing extracted into pure helpers (`wanTaskIdOf` / `wanStatusOf` / `wanPollState`) exposed via the `__DSH_IC_VENDOR__` test seam, with relay-shape regression assertions in `scripts/test-vendor-detect.mjs`.

## [0.19.15] — 2026-10-30

### Fixed
- **Rolls back the unverified moyu image-field experiment from 0.19.14** (live-tested: the generic path was already accepted; see 0.19.14 notes for evidence).
- **Relay video requests retry with simple image fields when only the image-proxy URL shape is rejected.** The generic OpenAI-compatible path keeps its original request first; if the response explicitly says the image proxy needs an http(s) URL, it retries once with `input_reference` for a lone frame or `images` string data-URLs for reference images, without adding a vendor adapter.

### Added
- (从 0.19.14 顺延) 建点布局代码级强控制与 moyu 实验回滚说明见 0.19.14 段。

### Changed
- (无独立变更；本版为 0.19.14 实验回滚 + 布局强控制首发。)

### Internal
- Rollback engineering for the moyu image-field experiment (live-tested with the vendor key before deciding).

## [0.19.14] — 2026-10-30

### Added

### Fixed

- **Canvas node placement is now enforced by code, not by caller discipline.** `addNodeAt` used to take whatever coordinates the caller passed — toolbar shortcuts spawn at `worldCenter ± fixed offset`, the double-click add menu adds `±30px random`, reference-image quick-create uses `±400` — so building two image nodes in a row from the toolbar put them at overlapping positions. `addNodeAt` now runs every spawn through `nextNodePosClient` (the client twin of the Host's `nextNodePos`): same-type nodes align to their type column (min x, y = column tail + 40), a first-of-type starts a new column at the caller position, and any candidate box intersecting an existing node (28px min gap) is pushed below it — up to 80 rounds. The caller's position is only used to start a new column. Regression `test-addnode-column.mjs` seeds a graph and asserts column alignment, collision resolution and a zero-overlap sweep; exposed via `__DSH_IC_LAYOUT__`.

### Changed
- **Vendor-format dropdown is the single source of routing truth.** Model-name routing (11 regexes) removed — `wan3.0-video` on a relay no longer gets rebuilt as a DashScope request; legacy providers get `vendor` backfilled from URL traits. (Detailed in 0.19.13 below; listed here because the fix commits ride on top of it.)

## [0.19.13] — 2026-10-30

### Fixed
- **`wan3.0-video` on relay gateways no longer gets routed into the DashScope protocol.** The vendor auto-detect used to guess from the model name — `wan3.0-video` matched the wan regex and the request was built as `{input:{prompt, media[]}, parameters{}}` with `X-DashScope-Async`, which a relay like moyu.info cannot parse; its internal image proxy then replied 需要http(s)接口url and the whole generation 502'd three times (main + both fallbacks). **The vendor format dropdown is now the single source of routing truth**: all eleven model-name guesses are removed. Routing order: explicit `vendor` (set in the dropdown) → URL traits (dashscope/klingai/…, also explicit config) → openai fallback. Legacy providers whose `vendor` field is empty get it backfilled once from URL traits at settings render.
- **Image fields for URL-only relays are now shaped per vendor.** The openai video branch detects `moyu.info` and switches to its documented shapes: first frame → `input_reference` (dataURL), reference images → `images: ["dataURL", …]` (plain string array, base64 accepted per vendor support), `resolution` in uppercase enum (`1080P`), `duration` clamped to [2,30], and `generate_audio`/`output_format` are not sent (unknown parameters there). JUAI-style gateways keep the existing `[{url, role}]` array — behavior unchanged outside the moyu flavor.
- **Async polling covers the moyu response shape.** `extractVideoUrl` now reads `data.result_url`; `taskFailureOf` reads `data.fail_reason`; `data.status` SUCCESS/FAILURE map through the existing lowe
- **Canvas node placement is now enforced by code, not by caller discipline.** `addNodeAt` used to take whatever coordinates the caller passed — toolbar shortcuts spawn at `worldCenter ± fixed offset`, the double-click add menu adds `±30px random`, reference-image quick-create uses `±400` — so building two image nodes in a row from the toolbar put them at overlapping positions. `addNodeAt` now runs every spawn through `nextNodePosClient` (the client twin of the Host's `nextNodePos`): same-type nodes align to their type column (min x, y = column tail + 40), a first-of-type starts a new column at the caller position, and any candidate box intersecting an existing node (28px min gap) is pushed below it — up to 80 rounds. The caller's position is only used to start a new column. Regression `test-addnode-column.mjs` seeds a graph and asserts column alignment, collision resolution and a zero-overlap sweep; exposed via `__DSH_IC_LAYOUT__` (`nextNodePosClient` / `addNodeAt` / `addGraphNodes` / `graph`).rcase normalizer.
- Regression: `test-vendor-detect.mjs` rewritten for the new routing contract (explicit vendor wins, model name never routes, moyu defaults to openai); new `test-video-image-url.mjs` locks the image-field shapes and the JUAI structure. Gate 81 → 82 items, all green.

## [0.19.12] — 2026-10-29

### Fixed
- **Custom director actions now survive save/apply and playback.** User actions retain `poseKeys`, action clips and loop metadata; applying an action restores those fields, pose loops actually wrap during playback, and the skinning cache invalidates when pose keys or clips change.

- **Cross-rig action clips no longer deform the mannequin.** Action clips tagged with their source rig are only mounted on a matching skeleton; the awplanet-explorer walk/run set can no longer be applied to `xbot`, where its local joint axes produced full-body twisting.
- **The `双手抱头` pose now puts the hands beside the head.** The old fixed Euler recipe left both hands near the hips; directional arm/forearm constraints now raise the elbows and bring the hands to head height.
- **Image generation recovers from unsupported-field 400s.** When a strict vendor rejects a field such as `watermark`, the adapter removes that field and retries once instead of failing the whole generation.

## [0.19.11] — 2026-10-28

### Added
- **Video style-lock regression harness.** A direct build of the four-layer video lock now verifies that director, genre, spec and look each inject only their prompt capability slices, script/storyboard-only sections stay out, an empty configuration injects nothing, and `buildShotLockText` can be addressed by project id for panel/chat parity tests.

### Changed
- **Text and script node bodies scroll with the mouse wheel.** The canvas wheel handler now distinguishes genuinely scrollable content from short previews: text, script, shot lists and dropdown lists scroll natively when they overflow; short content and empty canvas keep wheel zoom.
- **Dropdown scrollbars are easier to see and hit.** Dropdowns, text/script previews and shot lists share a themed 12px scrollbar with a 32px minimum thumb and a hover state.
- **Handwritten vendor-structured video prompts are now treated as a direct path.** A prompt containing `subject_definitions` keeps its user-authored structure and receives only the series-bible entity text; the canvas no longer appends the style lock or continuity preamble that could pollute a vendor protocol payload.
- **Cross-layer negative prompts are merged before injection.** Director, genre, spec and look negatives are globally de-duplicated into one bounded block instead of repeating overlapping prohibitions card by card.

### Fixed
- **Open dropdowns no longer expose node resize arrows underneath.** While a dropdown is open, node resize hit zones are suspended; normal node interaction resumes when it closes.
- **Video prompts no longer risk a negative-prompt wall.** The merged negative block is capped at 2,400 UTF-8 bytes; overflow is dropped at phrase boundaries rather than cut mid-phrase.
### Internal
- `test-node-layout.mjs` covers the wheel routing matrix, visible scrollbar contract and dropdown-open resize-handle suspension.
- `test-skill-panel.mjs` covers the real video lock output, reverse slicing assertions, negative de-duplication/budget behaviour, empty-profile short-circuiting and the handwritten structured-prompt exemption.
- `test-stage-spec.mjs`, `test-pose-anim.mjs` and `test-pose-keys.mjs` cover action persistence, pose-key interpolation, looping, cache invalidation and timeline editing.
- `test-action-library.mjs`, `test-pose-semantics.mjs` and `test-body-variants.mjs` cover rig compatibility and pose semantics under animation.## [0.19.10] — 2026-10-28

### Added
- **Carries the three fixes that were briefly shipped in the withdrawn 0.19.9** (that build loaded on nothing — see below): the image-generation compact style lock (`buildImageLockText`, 16.6 KB of prose per image request → 2.4 KB, text no longer painted into the frame), the `kind is not defined` crash in `saveTextAssetRecord` (text assets now actually reach the library, thumbnails restored to `saveAssetRecord`), and the segmenter fixes (cut-point shots open the next segment; tiny tails merge back — the reported scenes now segment clean instead of forced).

- **Numeric generation controls now accept custom values.** Storyboard shot count accepts any integer from **1–100** (the generator no longer silently clips at 24), and the per-segment generation cap accepts **1–300 seconds** with one decimal. Video duration accepts **1–300 seconds** with one decimal when the video node is standalone.
- **Manual storyboard shot count is a hard override.** A user-set count is injected as a user parameter that explicitly overrides the contract's “count follows content / never use a fixed count” defaults and requests exactly that many shots. The Auto setting now passes `0` through unchanged instead of being polluted into a 6-shot hint.
- **Video nodes connected to a storyboard are duration-locked to the storyboard.** The duration control is greyed out with a “Storyboard duration” label; the API request uses the sum of the selected segment's shot durations instead of the node's stored duration. If the storyboard has no usable shot durations yet, the request falls back to 5s with a visible warning. Unconnected video nodes keep manual/custom duration.
- **Chat can now read canvas geometry.** `canvas_list_projects` includes each node's `x/y/w/h`, `canvas_node_status` returns and renders the same geometry, and the tool output schema declares those fields. Node geometry remains read-only through tools — layout changes still go through `canvas_relayout`.

### Added
- **The director lens set grows from 24 to 45.** Twenty-one lenses were added, each written to the same depth as the original twenty-four rather than as a colour swatch: fourteen sections, a thirteen-key machine-readable style block, three prompt templates (Chinese brief / EN image-to-video / EN keyframe) and a worked example on the shared control scene, so all forty-five can be read side by side.
  - **Chinese 8 → 16**: Ang Lee, Edward Yang, Jia Zhangke, Jiang Wen, Johnnie To, Ning Hao, Stephen Chow, Wong Jing.
  - **Japan/Korea 2 → 7**: Bong Joon-ho, Kore-eda Hirokazu, Lee Chang-dong, Miyazaki Hayao, Shinkai Makoto.
  - **Western 14 → 22**: Ridley Scott, David Lynch, Alfonso Cuarón, Iñárritu, Wes Anderson, George Miller, Almodóvar, Guy Ritchie.
  - Group counts are enforced by the panel filter, so the three groups stay usable: 16 / 7 / 22.
- **Two of the new lenses close a gap that was already visible in the look layer**: `looks/ghibli-watercolor` and `looks/shinkai-light` existed with no director to drive them. Miyazaki and Shinkai now say explicitly that the texture follows those look cards and the lens only owns how it is shot.
- **The craft layer is now machine-checked for every new lens**, not just described in prose. The panel gate asserts, per lens: at least three contrast entries each naming the adjacent director and the mechanical difference; an ASL range in seconds, a transition bias and an anchor-shot plan in the cutting section; the four sound layers (music / ambience / dialogue / silence) plus which one carries the scene; and a worked example carrying both a weak and a strong prompt. The original twenty-four predate this bar and are exempted explicitly in the test rather than silently passing.
- **The genre layer grows from 21 to 36**, so the new directors have something to actually tell. A lens only owns *how it is shot*; the genre owns *what it is about* and *why anyone watches*. Three of the twenty-one new lenses had no genre that could carry them at all — Wong Jing's card game, Stephen Chow's mo-lei-tau, Guy Ritchie's multi-thread caper — and the rest were borrowing cards written for other things.
  - **New narrative genres (15)**: 赌局翻盘, 对峙困局, 多线劫案, 港式无厘头, 荒诞寓言, 县城漂移, 阶级困局, 青春距离, 废土追逐, 小镇异闻, 家庭情节剧, 古怪机构, 霓虹废都, 生存宿命, 社会横穿.
  - **Grouping attempt reverted; the genre layer is a flat wall.** A first cut at three universal categories (故事/情感/视效, multi-membership) was taken out again: too many of the thirty-six cards span eras and looks, so the assignment was arguable everywhere and an arguable filter is worse than none. The tiles render flat; discovery runs on the per-card `aliases` (`mo-lei-tau=港式无厘头（无厘头/港式喜剧/周星驰式/搞笑/扮嘢/反高潮）`) shown by `canvas_list_skills`, and on the chat side matching the user's own words to a card id.
  - Each carries the same ten sections the existing cards use (dramatic engine, pressure source, character strategy, audience payoff, scene granules, episode hooks, act structure, production difficulty, anti-drift, confidence) plus a **类型级负向词** block, and each names the genre it is commonly confused with and the mechanical difference.

### Added
- **The "Media Studio" preset mode now ships with this plugin.** Installing the canvas bundle mounts the mode in the picker (`order: 5`, director-first persona with runtime self-checks, guided workshop flow) plus the bundled **director-workshop** skill — previously a separate package `@ninkch/dsh-media-studio-preset`, now merged. The patch deliberately mounts neither the canvas nor ArtCraft plugin rows (double registration breaks the webserver); discovery of both still runs at runtime via `canvas_list_skills` / `artcraft_status`.
- **Conversation-triggered canvas now opens as a right-pane tab instead of hijacking the session.** `canvas_open` and node-run requests used to call `layout.selectPanel` (full-screen). All three trigger points now prefer `ctx.sidebarRight.openTab` — chat on the left, canvas on the right, no jump — falling back to full-screen on old runners; the left-rail full-screen entry is untouched.

### Changed
- **The look layer grows from 9 to 15 and is decoupled from directors — it is now a palette library, not a fandom annex.** The reference pack had its 200 directors organised into ten colour families, so the six families the look layer could not previously express were mined from those palette.json files: for each family every director's six primary colours (each with a ratio) were aggregated into a weighted cluster, and the top eight cluster HEX values became the card's colour block. Every HEX on the six new cards is that measured aggregate, not an invented palette — cold-noir's #1A232D is what twenty cold-thriller directors actually average.
  - **New looks (6)**: 冷调悬疑 cold-noir · 大地暖调 earth-warmth · 极简冷灰 minimal-grey · 巴洛克浓彩 aroque-rich · 高饱和史诗 saturated-epic · 浪漫柔光 soft-romance. All legacy looks got semantic groups (国漫/日系/港味/写实) alongside the new families (冷调/暖调/浓彩/柔光), shown flat in the panel.
  - **Decoupling verified end to end**: the same lens (ng_lee) composed with cold-noir versus earth-warmth produces prompt slices whose HEX sets do not intersect — the look layer genuinely constrains colour independently of who is holding the camera.
### Fixed
- **The withdrawn 0.19.8 / 0.19.9 builds could not load at all.** The persona block added in the first 0.19.8 inserted seven bullet lines at **zero indentation** inside the `prefix: |` block scalar, which terminated the scalar and left `- **先查后建**…` at document level; the YAML parser then read `*先查后建*` as an alias and the whole profile failed with `unidentified alias` — the plugin would not install anywhere. Response:
  - the seven lines are re-indented into the block;
  - `test-mode-preset.mjs` now runs a **block-scalar indent check** over the whole patch (every line after `key: |` must sit deeper than the key until a structural line appears; zero-indent `- **` lines are rejected outright) — sabotage-tested by re-breaking one line and watching the gate go red;
  - string-matching assertions were never going to catch structural YAML damage; the patch gate is now a shape check, not a keyword check.
  - npm 0.19.8/0.19.9 were unpublished by the maintainer and their GitHub releases/tags deleted; this 0.19.8 reissue is the first installable build carrying the fix.
- **Generated images came out full of unreadable text.** `buildShotLockText` was written for *video* models and reused for image generation unchanged, so one image request carried **16.6 KB of Chinese prose** — lens YAML, the whole look card, genre granularity, prohibition sentences. Text-to-image models read structured text as content to render, so the style lock was literally being painted into the frame (a character sheet came back with a wall of glyph soup down its right column). Images now get a dedicated compact lock (`buildImageLockText`) extracting only what a still frame needs — focal lengths, key ratio, dominant palette, saturation/contrast, colour proposition, plus a capped negative list — **2.4 KB instead of 16.6 KB (-86%)**. Video keeps the full text, which it actually uses.
- **`kind is not defined` on every storyboard/script save — and text assets never reached the library.** A single line `if (kind === 'image') queueThumb(rec.id)` had been pasted into `saveTextAssetRecord`, where `kind` does not exist. It threw `ReferenceError` unconditionally, *after* the markdown file was written but *before* `assetCreate`, so every AI storyboard generation ended with a red error in the composer **and** the script/storyboard `.md` never entered the asset index. The line belonged in `saveAssetRecord` (where `kind` is a parameter) — moved there, which also restores image thumbnails (`queueThumb` had no remaining call site).
- **Storyboard totals read as impossible.** The segment summary said «最长 19.8 秒» for a 20-second scene — it reported the longest *segment*, not the longest *shot*, and never showed the scene total, so the arithmetic looked broken. It now reads «2 段 · 共 13 镜 · 总 20.8 秒 · 单段最长 19.8 秒».
- **Clean cut points were being put on the wrong side of the split.** `findBreak` treated a cut-point shot (`scene_change` / `closeup` / `new_character`) as the *last* shot of a segment, so the next segment could only start on the `continuation` shot after it — exactly the "starts mid-action" condition that raised the hard-cut warning on AI-generated storyboards. A cut-point shot now opens the next segment. With a new tail rule (a final segment under ~20% of the cap merges back when it fits within a 10% overrun, instead of splitting off a 1-second fragment), the two reported scenes now segment as **1 段 / clean** and **10.5s + 15.2s / clean** where they previously produced forced cuts.
- **The preset knew how to create nodes but not how to iterate on them.** The persona and the workshop skill both described only the first-build path (write → storyboard → generate); nothing told the agent that an existing node should be *edited* rather than replaced, so a failed roll of a character portrait invited `canvas_create_node` again — the canvas accumulated duplicate nodes for the same character, each with its own connections and history. Added:
  - A **节点生命周期（复用优先，禁止删了重建）** section in the persona: check first, edit in place (`canvas_node_status` → `canvas_update_node` → `canvas_generate_node`), create only for genuinely new subjects, never delete as a "reset", let connections carry content, and use `canvas_get_bible` as the read-only source for character appearance.
  - A **重生成** branch in the workshop's generation stage plus a duplicate-node check in its exit checklist.
  - `canvas_update_node`'s own description now states it is the iteration path — the agent reads tool descriptions more reliably than persona prose.
  - Five previously unmentioned tools are now routed: `canvas_update_node`, `canvas_create_node`, `canvas_connect`, `canvas_open` (right-pane reveal), `canvas_get_bible`, `canvas_director_stage`.
- **`director-workshop` failed to load on strict DSH builds: "loaded skill name must be a string".** The bundled `skills.js` provider returned `{ summary, content }` from `get()`, but the Host contract expects a **flat** skill object — `validateDefinition` reads `definition.name` at the top level, got `undefined`, and threw. The original two-package preset predates the strict validator and slipped through; the merge carried the bug into this package, where the panel gate caught nothing because it never exercised `provider.get()`. Fixed to return the flat shape (`name/description/invocation/provider/source/rank/resourceBase/content`), and `test-mode-preset.mjs` now runs the provider through the same field checks the Host applies — verified by sabotage: reverting the shape turns the gate red on six assertions.
- **Genre cards had no grip on the finished picture.** Two separate holes, both closed:
  - **The genre's negative constraints never reached the video prompt.** `buildShotLockText` — the function that actually attaches skill text to image and video generation — only pulled one section out of a genre card, `常见场面颗粒`, because that is the only section tagged `prompt`. So `禁止漂移` (the "don't show this, don't let that stand in for story" list) was sliced as `story shot` and could never arrive, and no genre card carried a negative-word block at all, while `forms`, `lenses` and `looks` all did. The genre layer was therefore decorative on the generation side: it could shape a script, and had no say in what a clip looked like.
  - **The panel gate now requires both.** Every genre card must carry ≥4 negative phrases plus a `禁止漂移` and a `常见场面颗粒` section, and `buildShotLockText` pushes `本题材的画面禁项` and `本题材负向词` alongside the granules. Verified end to end: a `stephen_chow` + `mo-lei-tau` + `short-drama` pack now emits the mo-lei-tau granules *and* its seven negative phrases into the prompt slice.

### Fixed
- **Seventy-two dead `../xxx.md` references are gone from the lens pack.** Thirteen of the original twenty-four lenses ended every section with «见 `../cinematic-language.md`（要点）» — but `assets/canvas-director/` has no such sibling files, so a reader following the pointer found nothing. They were backtick text rather than markdown links, which is exactly why the gate never saw them. The references predated this release and were carried forward by copy-paste; they are fixed here rather than filed as a known issue.
  - **The annotation text is kept, only the path is dropped.** The parenthesised clause after each pointer was a distilled rule ("切点逻辑：剪辑点优先动作匹配与视线匹配；转场默认硬切；ASL 按情绪曲线分配，不许均匀"), not a restatement of the linking sentence — a check across all 72 references confirmed each target file's clause was globally unique. So the rule now lives inline where it was read, and nothing the reader needed is lost.
  - **The trailing «配套参考：» line became a bulleted «配套参考要点：» list** in the thirteen affected lenses (33 items), because a run-on single line of three to four stacked pointers reads as one sentence in Chinese and is unreadable once the filenames are removed.
- **The gate now catches this class of defect.** `test-skill-panel.mjs` gets a `!`-assertion for backtick `../` pointers alongside the existing markdown-link check — verified by planting one in `ang_lee.md` and watching it go red before reverting. The old assertion only matched `](../`, so a bare backtick reference was structurally invisible to it.

### Notes
- Ten of the new directors had no prior module in any local reference (Ang Lee, Edward Yang, Jia Zhangke, Jiang Wen, Johnnie To, Ning Hao, Stephen Chow, Wong Jing and Guy Ritchie); their lenses were written from scratch, the same way 徐克 / 路阳 / 袁和平 / 乌尔善 were originally. Every ASL band, key ratio, light-source convention and sound-layer assignment is stated as a number so two people filling a shot list arrive at compatible results.
- `test-changelog.mjs`'s hand-maintained `COVERAGE` list is cleared: 0.19.6 shipped (33eec44), so `main..dev` is empty and those four shas now live in the released section. The list has to be cleared at each release, otherwise the next time `Unreleased` gains content the coverage check stops falling back to the released section and reports shipped commits as missing.

## [0.19.6] — 2026-10-26

### Added
- **The panel now reads the skill configuration back from the project document.** `canvas_skill_pack({set:true})` from the chat side used to write the document while the panel kept showing its own `localStorage` copy — the "both sides share one source" claim only held in one direction. `mergeHostDoc` now compares `skillUpdatedAt` and writes the newer configuration back to the panel, mirroring how the series bible already syncs.
- **Asset-sheet nodes get their own slice.** Image nodes whose label ends in 设定图 (created by `assetSheetNodeSpec`) now take the `assets` slice instead of the generic prompt slice — imaging and material only, no storyboard or editing rules. Detection failure falls back to the prompt slice.
- **The fight-rhythm card is finally injected.** `moves` shipped two cards but only `camera-moves` was ever read; the storyboard path now carries `fight-rhythm` as well, on both the Host and client sides.

### Changed
- **「类型规格」is now「规格」** (English: "Delivery form" → "Spec") across the UI, Host tool descriptions, skill text and both user guides — 81 occurrences over 13 files. Code identifiers (`forms` / `form` / `skillForm`) are untouched, so stored configurations stay valid.
- **All three skill-profile default sets now agree the form is unset.** `pack.js`, `index-core-skill-profile.js` and the client previously disagreed (`'short-drama'` vs `''` vs `'short-drama'`), which meant the two sides had different ideas of "nothing configured".
- **Dead profile fields removed** — `aspect`, `targetSec` and `platform` had no UI controls and stopped meaning anything once the spec stopped deciding aspect.

### Fixed
- **Selecting only a spec injected nothing on the canvas side.** `buildSkillPackText` and `buildShotLockText` short-circuited on `lens`/`genres`/`look` but not `form`, so a project configured with just a spec got 0 bytes on every canvas path while `canvas_skill_pack` returned 4.7–9 KB — the two sides wrote against different rules. Verified: form-only now yields 4727 / 9087 / 7934 bytes for script / storyboard / prompt, and a fully empty profile still yields 0.
- **An unconfigured project was still injected with 5.5 KB of camera moves on the Host side** — the moves loop ran before the empty check, so `storyboard` and `prompt` always carried `camera-moves` even with all four layers empty. Moves are now only added once a layer card has resolved.
- **A kind with no matching slice returned a header-only shell** — `assets` for a spec with no assets sections produced 365 bytes of pure header. `buildPackText` now returns empty when no section survives slicing.
- **`canvas_skill_pack` accepted any `kind`** — `{kind:'nonsense'}` returned 「【画布技能包 · nonsense】」plus empty slices. The tool now rejects anything outside the four documented kinds.
- **A `readSkillPack` RPC shipped with no consumer.** The client reads card files over the static `plugin-asset` HTTP route and the chat side loads skills through the skills service, so the RPC (with its whole path-whitelist guard) was a second channel nobody called. Removed; its path-boundary tests now target the loader directly.

### Internal
- New regression assertions in `test-skill-pack.mjs`: spec-only configuration must inject on all three generation kinds, a fully empty profile must inject nothing (moves included), the three default sets must agree on an unset spec, the assets kind must return empty rather than a header-only shell, the storyboard path must carry the fight-rhythm card, and the tool source must validate `kind`.

## [0.19.5] — 2026-10-26

### Added
- **Nineteen Mixamo action clips converted from awplanet's FBX set** (idle ×2, walk ×5, run ×5, run-stop, turn ×2, jump, running jump, sit-laugh, dodge-back) and merged into the action library. Conversion is reproducible: `scripts/build-director-actions.mjs` runs FBX2glTF, resamples every track to 30 fps, and zeroes the root node's horizontal translation so an action plays its pose in place while paths and keyframes own the movement. The single-frame "pirate" FBX was dropped — it is a static pose, not an action.
- **A pose library of 41 entries, including 19 director poses replicated from awplanet's `DIRECTOR_POSE_RECIPES`** (relaxed / contrapposto / alert / lean / crossed arms / hands on hips / sitting ×2 / crouch / kneeling ×2 / prone / supine / point / reach / guard / surrender / hands-on-head / talking) — translated 1:1 from additive Euler recipes to the existing `BONE_POSES` quaternion pipeline, with ground poses carrying `rootY` so lying figures do not sink through the floor. A **Pose dropdown** next to the Action selector exposes the whole library on any selected character.
- **`scripts/build-director-actions.mjs`** converts awplanet's semantic Mixamo FBX clips into the action-library format. It detects FBX2glTF (env `FBX2GLTF`, PATH, or the `fbx2gltf` npm package's bundled binary) and skips with install instructions when absent, so the gate never depends on an external binary. The FBX sources stay in `_refs` (converted clip JSONs are what ships).
- **An engine-staleness banner**: `engine.js` is imported once per page load, so plugin updates were invisible until a full refresh with no hint anything changed. `ENGINE_VERSION` is now bumped with every engine change (`explorer-1`), and opening the director desk compares it against `sessionStorage` — a persistent banner with a reload button appears when the page is running a stale engine.

### Changed
- **Male body deformation is now visible at storyai magnitude.** The muscle multiplier per limb went 0.22 → 0.55 and `m_standard` moved to waist 1.24 / muscle 0.50 / hip 0.96 (a masculine taper); muscular/plump push further. A new `head` parameter scales the head/neck vertex region for child (+18%) and teen (+8%) proportions. Verified on Explorer: waist and thigh verts move ≥2 cm at `m_standard`, child head ≥10% of stature, feet stay planted.
- **Character colours are high-saturation** (storyai-style vivid blue/magenta/emerald/violet/amber/orange/crimson) instead of pastel — and the type colour is now the **render fallback** (`ob.color || mannequinColorOf(typeId) || clay`) across the WebGL paths, the Canvas2D fallback and the asset-rail thumbnails, so existing scenes pick it up without touching user data.

### Fixed
- **The directo desk UI and the male mannequin base, in one pass.** The male body types are back on the xbot base mesh — Explorer is a spacesuit character and grading it as the male asset was a mis-pick (it stays in the library, relabelled 宇航员). Node dropdowns (`MiniSelect`) now stop `pointerdown`, `mousedown` **and** `click`, so a select inside a node opens and works instead of the node swallowing the press and popping the generator dialog. Image nodes gained a zoom button that opens the original in the lightbox; video nodes replaced the redundant reference badge with a fullscreen button and the in-player control bar gained its own. The director-stage timeline dock shrank from `min(33vh,320px)` to `min(22vh,214px)` so it stops eating the viewport. A double comma before the closing bracket of `BONE_POSES` had created an array hole that crashed pose blending — removed.
- **Child and teen heads no longer detach.** The head-scaling deformation only grew vertices dominated by the head bone, leaving the neck at its old size, so the enlarged head floated free. The scale now applies to the Head/Neck bone skinning matrices before the skinning loop (Head at full ratio, Neck at half for a smooth transition), so bone and vertices grow together — head width scales 1.182× for a 1.18 child ratio with no tearing.
- **Newly added actions never appeared, and cached assets kept missing them.** `loadModel` returned a cached asset unchanged, and the asset had usually been registered before the action library finished loading, so clips merged silently never reached it. A cache hit now diffs the clip list and re-decodes the pack (already in memory) to merge the missing names before returning — verified: 17 missing clips on a stale cache, 21 actions present after the merge.
- **The media action keys sit beside the resolution chip.** The image zoom and video fullscreen buttons moved from the top-right corner into one bottom-right cluster with the ratio chip (button, then resolution text, in a row), hidden while the video control bar is up so they never cover the scrubber.
- **Object height is editable in the property panel.** The `dirHeight` label existed but was never rendered, so the only way to change a figure's size was editing `MANNEQUIN_TYPES` — and that table is read at placement time, which meant already-placed objects kept their old height forever. A height input now sits under Position for model objects and writes the object's own `h`. The 少年 / 儿童 tiers were also corrected downward (teen 1.60 → 1.35, child 1.18 → 1.00) because the head-scaling pass had been pushing their crowns above the configured height.
- **`ENGINE_VERSION` is now bumped per engine change** (`explorer-2`), so a page still holding an older module shows the reload banner instead of silently serving stale behaviour.
- **The gizmo origin is absolute and pose root motion stays on bones.** `applyPlayhead` had been adding a pose's `rootY` to `pos.y` on top of the bone-level Hips translation that already applies the same offset — a double application that moved the object's logical origin, so the axis rose to hip height whenever a pose with root motion was active. The offset now applies to bones only, the follow-body opt-in around `poseCenterY` is gone, and the axis sits at `(pos.x, pos.y, pos.z)` — a humanoid's sole centre — always, in both the draw and pick paths. The regression asserts the gizmo paths contain no `poseCenterY` and no follow switch at all.
- **Body-shape deformation silently did nothing on non-metre meshes.** The waist/chest/belly/bust bands used absolute metre coordinates tuned for xbot (rawHeight ≈ 1.8); soldier is a ~44-unit mesh and Explorer ~194 — the bands landed at ankle height and the deformation quietly missed. All bands are now relative to the mesh's posed height, so the same `m_standard` shape deforms every rig proportionally (verified: waist verts on the 44-unit soldier move with feet anchored).

### Internal
- Body-type regression data: colour and proportion keys for the 12 mannequin types, Explorer asset integrity, deformation magnitudes and the pose-library census are asserted in the new `test-body-variants.mjs` (registered in the strict suite). The Explorer pack (`models/explorer.json`, 1.28 MB) ships in `assets/director/models/` and is registered in the library index.

## [0.19.4] — 2026-10-25

### Fixed
- **The gizmo axis floated in mid-air.** Its origin had been lifted to the animated hip height so that a fall-down pose would not leave the axis behind on the ground. That was the wrong fix: the axis must sit at the object's **own coordinate origin** — for a humanoid, the centre of the soles — and stay there however the pose moves. The orientation was never the problem: it already comes from `objectAxes(sel)`, so the axis follows the object's rotation (tip the figure over and the z axis still points at the head rather than at the world zenith). The default origin is `(pos.x, pos.y, pos.z)` again, hip-following became an explicit opt-in (`sel.gizmoFollowBody`), and the pick branch takes the same origin rule so drawing and hit-testing stay aligned. A regression block now pins it: standing and fallen poses both keep the origin at `y = 0`, a 90° x-rotation moves the z axis off world +Z, and a 90° y-rotation moves the x axis onto world ±Z.

## [0.19.3] — 2026-10-25

### Added
- **A dedicated "技能" (Craft) page on the right sidebar**: the old one-line expert dropdown is now a four-layer visual console with **no dropdowns at all** — every option is an icon tile. **Director lens** (24, the top layer because it owns the camera language), **genre** (21 narrative + 10 sector cards, multi-select, swaps automatically for the commercial form), **delivery form** (8: structure blocks, ASL floor, rhythm, quality bar — **aspect is not part of it**), **look** (9: imaging, material, texture; empty = follow the lens), plus the expert as a tile row. Selection is per project.
- **All four layers feed every prompt-generating path, not just scripts.** Script nodes, storyboard nodes, bible drafts and asset-sheet prompts receive the capability-specific slice; image and video nodes additionally get a `[镜头语言锁]` block carrying the lens's style parameters and negative phrases. Unconfigured projects inject nothing, so existing behaviour is unchanged.
- **`canvas-director` skill**: 24 director lenses (each with 14 sections and a machine-readable style-parameter YAML block), 21 narrative genre cards, 10 sector cards, 8 delivery-form cards (with a parseable `spec` block), 9 look cards (palette hex, key-ratio ranges, negative words), a camera-move dictionary and a fight-rhythm card. Four Chinese-language directors (徐克 / 路阳 / 袁和平 / 乌尔善) were written from scratch because they were missing from the reference material.
- **`canvas_list_skills` and `canvas_skill_pack` tools**: the first lists the plugin's four skills, the full four-layer card inventory and the project's current selection — so any conversation that touches the canvas immediately knows what craft is available; the second returns the assembled slice for `script` / `storyboard` / `prompt` / `assets`, optionally overriding a layer or persisting the config (`set: true`).
- **`readSkillPack` RPC** for the client to load card files, with a strict path whitelist (`canvas-director/` prefix, no `..`, no absolute paths, `.md`/`.js`/`.json` only, must resolve inside the pack directory, 256 KB cap).

### Changed
- **The "专家" (expert) layer is gone.** It was a single `general` option whose persona restated — verbatim — the rules already in the `canvas-craft` skill (four scene elements, six visual elements, one extreme close-up per scene, causal hooks, collision points, the 180° axis, terminology), and it even said "when the skill disagrees, the skill wins". Injecting both meant saying the same thing twice and risking contradictory instructions whenever the two copies drifted. The hard rules now have exactly one source (`canvas-craft`); `buildExpertContext` returns `persona: ''` plus that skill's text, so every caller keeps working unchanged.
- **The image/video prompt block became a full four-layer enhancement, not just style parameters.** Previously the prompt path carried only the lens's YAML and some negative words, so the look's imaging/material/optics, the genre's concrete scene granules and the form's rhythm were all dropped — the first shot matched and everything after drifted. It now pulls `prompt`/`assets` slices from all four layers (lens style parameters + lighting rules, look imaging + material + optics, genre scene granules, form ASL + negatives, plus the three negative lists), ~15 KB instead of ~3 KB.
- **The delivery form no longer decides aspect ratio.** Aspect and resolution belong to the video node at generation time — 短剧 can be shot vertical *or* horizontal, and a short drama is not a licence to shoot cheaply. Every form card now states a **quality bar** (real key ratios, motivated light, readable depth) instead of an aspect; the `spec.aspect` field is gone and a regression asserts it stays gone.
- **The eight forms are re-cut along real delivery boundaries**: 短剧 (single 60–180 s unit, **multi-episode included** — a series is just episode after episode, so there is no separate "连续剧" form) · **电影质感** (a *texture* spec, not a feature-length one: ASL floor 1.5 s, 24 fps, every shot must survive a cinema screen; its duration tiers stop at 30–300 s because a video model only emits 3–8 s at a time — a 120-minute tier would be fiction) · **商业片** (宣传片 / 广告片 / 产品片 merged: near-identical needs, split internally by block ratios instead of three cards) · 纪实 · 音乐视频 · 预告 · 解说 · 访谈.
- **Every form card now states its generation-count arithmetic** (a video model emits 3–8 s per clip, so 90 s ≈ 12–30 clips; long takes are stitched with tail-frame continuation rather than assumed to come out in one generation).
- **The skill configuration is stored on the project document** (`skillProfile` + `skillUpdatedAt`), mirroring how the series bible syncs, so the conversation side reads the same selection the panel shows. Old projects have no such field and fall back to the defaults.
- **`canvas-studio` now opens with a skill inventory table** listing all four skills, what each owns and when to load it, plus the rule that every prompt should go through `canvas_skill_pack` first.

### Fixed
- **The skill panel showed nothing until the manifest arrived**: the card list was held only in component state, so the first paint after opening the tab was an empty page. It now seeds from the module-level cache and falls back to it on every render.
- **An invalid stored value could pin a layer to a dead id**: numbers, objects and arrays written into the profile were read back verbatim (`"[object Object]"`). Only string scalars are accepted now; anything else falls back to the default.
- **A project with no craft configured still paid a prompt prefix**: the config header was emitted even when no card had been read. When zero cards resolve, nothing at all is injected.

### Internal
- `assets/canvas-director/pack.js` is a **pure-function module shared by Host and Client** (section splitting by `<!-- slice:xxx -->` markers with a title-based fallback, `KIND_SLICES` mapping capability → section tags, YAML/spec/negative-word extraction, manifest validation, profile normalisation), so the panel and the conversation produce identical slices.
- New regression scripts: `test-skill-panel.mjs` (card structure across all five layers, reverse assertions that `script` never receives style parameters and `prompt` never receives narrative method, per-project isolation, three sidebar tabs, zero `<select>` on the craft page, 72-glyph closure, injection matrix across six paths) and `test-skill-pack.mjs` (`readSkillPack` boundary cases, four registered skills, both new tools end to end). The gate now runs 78 suites.
- Updated `test-panel-layout.mjs` (three tabs), `test-tools.mjs` and `test-skill-inject.mjs` (four skills, expert moved off the settings page) for the new structure.

## [0.19.2] — 2026-10-25

### Added
- **Action library for the 3D director stage**: `props.keys` keyframes so a prop (spear shaft, tip) can follow a hand through time; `autoRigMap()` maps any humanoid skeleton (Mixamo, VRM 0.x/1.0, Blender `.L/.R`, Daz/Genesis, Unreal, MakeHuman) onto 21 canonical semantic joints, so one action can drive any humanoid model without a per-rig allowlist; a collapsible **Custom action** panel groups IK, constraints, action layers and per-bone editing behind one toggle so the properties column stays readable.
- **Two-bone analytic IK** (`solveTwoBoneDirs`, `resolveIkAndConstraints`): cosine-law solve with pole vector, pivot-correct aiming that converges in 3 iterations even when the parent has non-uniform scale, plus `damped_track` / `copy_rotation` / `limit_rotation` constraints. Evaluation order follows FK → constraints → IK.
- **Mocap intake** (`parseBVH`, `mapBVHToBones`, `retargetBVH`, `sampleClips`): BVH hierarchy/motion parsing, rest-delta retargeting to pose keys, and NLA-lite layering with `replace` / `add` / `multiply`, `influence`, `loop` and `t0/t1`.
- **Dual-quaternion skinning** (`mat4ToDualQuat`, `dqTransformPoint`, `skinPointWithMats`): `skinModel` accepts `skinning: 'lbs' | 'dqs' | 'auto'`, so large joint rotations no longer collapse the mesh.
- **Keyframe interpolation parity**: Bezier F-Curve evaluation (binary-search `t` + cubic Bezier, handle-overlap correction), a full easing table (`smoothstep`/`linear`/`sine`/`quad`/`cubic`/`quart`/`quint`/`expo`/`circ`/`back`/`elastic`/`bounce` × `in`/`out`/`in_out`), quaternion slerp for pose keys and tracks, and per-key easing in `poseAnim`.

### Fixed
- **Poses and root offsets sat above or below the floor**: `rootY` (crouch / qinggong / knockdown) was applied in metres to a node translation measured in centimetres, so every pose that relied on it kept its feet off the ground (crouch was 30 cm in the air). It is now scaled to the node unit, which puts crouch at 1 cm and knockdown at 7 mm.
- **The gizmo stayed on the floor while the character lay down**: the axis origin was pinned to the object root. It now follows the animated hip height (`poseCenterY`), so the axis sits on the body in every pose while drawing and picking stay on the same origin.
- **The timeline dock grew without limit** and squeezed the viewport to a strip. It is now capped at `min(33vh, 320px)` with its own vertical scroll and a sticky toolbar.
- **The legacy-asset migration never ran after startup**: `autoMigrateAssetsToRoot` only fired once at boot and returned early when no data root was configured, and the 0.19.1 thumbnail path refused assets without a `rel`, so pre-0.18 IndexedDB-only assets showed as grey placeholders. The migration is now idempotent, runs on boot / data-root change / first asset access, keeps the original asset id when writing the file and the SQLite row, and deletes the IndexedDB record; assets whose blob is genuinely gone are reported as missing instead of silently failing.
- **Button labels wrapped out of their boxes and overlapped the next row**: buttons are now `inline-flex` with `white-space: nowrap` and rows wrap instead of clipping, and the longest director labels were shortened.

### Internal
- New regression scripts: `test-director-anim.mjs` (Bezier/easing/slerp), `test-dqs.mjs` (dual-quaternion skinning), `test-ik.mjs` (IK + constraints), `test-bvh.mjs` (BVH parse/retarget/layers), `test-rig-map.mjs` (skeleton mapping across five naming conventions), `test-action-library.mjs` (action clips load and play), `test-director-panels.mjs` (custom-action panel wiring), `test-asset-migration.mjs` (legacy asset self-heal). The gate now runs 76 suites.

## [0.19.1] — 2026-10-25

### Added
- **Node previews are now cheap derived thumbnails, not the originals.** Every image (generated, imported or uploaded) and every video (first frame, including imported videos) gets a system-generated 512 px JPEG preview (`<rel>.thumb.jpg`; videos reuse `<rel>.poster.jpg`) written next to the original. Nodes render only that preview, so a board of large 2K–4K stills no longer pins hundreds of megabytes of decoded textures. The thumbnails are **not assets**: they never enter `assets.json`, the asset library or the data-root import scan, and they are deleted together with the original.
- **Originals load on demand, one at a time.** Double-clicking an image fetches its original only then (single `<img>`, unmounted when the lightbox closes); clicking play mounts one `<video src=original>` and pauses/unmounts it when playback stops. Download resolves the original on click too — nothing prefetches originals any more.

### Fixed
- **A white flash while zooming the page or while the assistant streamed a reply** — the whole board (dozens of large images, edges, filters) sat in one composited layer via a permanent `will-change: transform` on `.dshic-world`; changing the page zoom made Chromium reallocate that huge texture and paint tiles white before re-rasterising. `will-change` is now applied only while a pointer interaction is in progress.
- **Ctrl+wheel zoomed the whole page as well as the canvas** — the director viewport used React's `onWheel`, which is registered as a passive listener, so `preventDefault()` was ignored. It now uses a native non-passive wheel listener.
- **`createImageBitmap` could hang instead of throwing**, which would leave thumbnail generation awaiting forever and the node stuck on its placeholder. Thumbnail creation now races the bitmap call against a 1.5 s timeout and falls back to `<img>` + canvas.
- **Missing media flashed between skeleton and placeholder** — a 404 used to be retried on every render. Missing files now hit a per-session negative cache and render a stable "file missing" card with a retry button; the poster probe also no longer counts a 405 as a fatal error.
- **The running-node sheen animation used `filter: brightness()`**, which forces a repaint each frame; it now animates opacity.

### Internal
- New `scripts/test-thumbs.mjs` (registered in `scripts/regress.mjs`) pins the thumbnail contract: derived-file naming and exclusion, the `/api/thumb` route, node images using `*.thumb.jpg`, originals only on demand, the missing-media negative cache, the removal of the permanent composited layer and the non-passive wheel listener.
- `scripts/test-canvas-perf.mjs` updated for the new media-node hook order (thumbnail URL + lazy play URL) and its fake canvas gained `fillRect` so the downscaled first-frame path is exercised.

## [0.19.0] — 2026-10-25

### Added
- **A real 3D director stage (WebGL2)** replaces the Canvas2D v0 rasteriser: PBR shading (Oren–Nayar diffuse + GGX specular), a 2048² PCF shadow map with slope-scaled bias, hemisphere sky light, distance fog, a depth-of-field post pass and AgX tone mapping, with an automatic Canvas2D fallback when WebGL is unavailable. Characters are true skinned glTF assets (`xbot`) driven by `idle / walk / run / sneak` clips, and walking a path drives the locomotion cycle automatically.
- **A 40-model set-dressing library ships with the plugin**: 3 human rigs, 12 trees, 11 furniture pieces and 14 buildings, plus primitives and ancient-street set pieces (pitched-roof houses, stalls, stone steps). Tabbed and searchable, one click to place.
- **Three view modes** — **Static previz** (fixed studio look, paused), **Dynamic previz** (studio look + timeline playback) and **Live render** (final daylight, shadows and materials, no guides). Static/Dynamic deliberately ignore the render settings so blocking never drifts while the sun or exposure is tuned; the right panel is context-sensitive (object properties / lens and shot settings / render settings).
- **Direct manipulation** — local-axis translate/rotate/scale gizmo, **Alt + drag a scale handle** for ratio-preserving uniform scale, marquee select, drop-to-ground, and **W/A/S/D + Q/E fly navigation** (hold Shift for 4x speed; the mouse still looks around).
- **Shots, timeline and optics** — shot rail with per-shot start/end, camera keyframes with ease curves, markers, loop playback and timeline zoom; FOV, focal length, sensor size and roll stay consistent, and shot-size presets report a live framing percentage.
- **Export** — a PNG still or an MP4 (H.264, WebM fallback) clip rendered by the same pipeline as Live render, written back onto the canvas as image/video nodes.
- **Bilingual documentation** — both READMEs and both user guides gained a 3D Director Stage chapter with 16 new UI screenshots (English and Chinese UI).

- **A 3D director stage for blocking and framing a shot**, opened from a new camera icon in the left rail: a full-screen stage with a grid ground plane, draggable figures and primitives (box / sphere / cylinder / plane), an orbitable camera, key + ambient light, per-shot size / move / duration settings and a live viewport. Dragging empty space orbits the camera around its target, dragging a figure moves it on the ground, and clicking picks the object under the cursor. "Export this camera as a still" renders the current camera at 1280×720, saves it through the existing `saveAssetRecord` path (asset library, `source: 'director'`) and drops a ready image node on the canvas, so the shot can go straight into video generation.
  The stage is **rendered by a self-contained Canvas2D software rasteriser** (`directorLookAt` / `directorProject` plus depth-sorted convex faces), not three.js: this plugin is a single file with no build step and no `node_modules`, and vendoring three.js would add 743 KB of prebuilt asset plus MIME, packaging and provenance work for a v1 that only needs blocking and one frame. The renderer's interface is stable, so moving to WebGL later touches one function. A real headless-Chrome render was inspected while building it, which is how two genuine bugs surfaced: every limb of the figure collapsed to the floor (a dropped vertical offset in the limb helper), and the fixed figure then read as a totem pole (limbs too thin, head detached) — both fixed.
- **The stage compiles its blocking into a video prompt** (`compileDirectorPrompt`): shot size, height-derived angle (low / eye level / high), distance, move and duration, plus an explicit standing map ("who stands where, facing where") built from the coloured figures. The prompt states in hard terms that **the coloured mannequins must be rendered as real people** — without that line a video model paints blue and yellow puppets. Scene data lives in `localStorage` (`dsh-ic:director:<projectId>`, versioned, corrupt data falls back to the default stage) so the project document never carries vertex arrays; the exported still is the real product.
- **A storyboard is no longer one generation: it is cut at real shot boundaries** (`planShotSegments`): the whole table used to be flattened into a single prompt whose duration was the sum of every shot, so a 13-shot / 62-second table was squeezed into one 15-second request and the model could only compress — which is exactly why the motion came out as nothing but a slow pan. The planner now walks the shots and may only break a segment on a real cut — `scene_change` / `closeup` / `new_character` (or the table's first shot); one continuous `continuation` action beat always stays inside one segment because its motion phase cannot be split, and a segment that would exceed the per-segment cap is cut at the nearest legal cut point. When no legal cut exists it still refuses to cut mid-shot silently: the segment is marked `seamRisk: 'forced'` and the canvas surfaces the warning. Each segment becomes its own video node carrying `segShotFrom` / `segShotTo` / `segIndex` / `segCount`, so the prompt composer (`buildStoryboardVideoPrompt(sb, segment)`) writes only that segment's shots. The storyboard node shows the plan before you expand ("N segments / M shots / longest S seconds" plus a clean-vs-forced indicator) and the composer gained a per-segment cap (`segMaxSeconds`, 6–30s, default 15) — set 6–10s for weak-continuity models like MiniMax, 15s for Seedance 2.5.
- **Weak-continuity models stop being asked to match pictures** (`segmentNeedsHardFrame`): tail-frame chaining is now only used when the segment genuinely crosses a continuous action *and* the model can honour a hard first frame. Segments that start on a cut declare "do not continue the previous picture, establish this shot fresh" in the prompt, so the edit is a clean cut instead of a forced match — no double image, no stutter at the join. MiniMax / Hailuo / Pika / Stability are detected as weak-continuity and never get an automatic tail-frame chain.
- **Shot prompts now carry the four things the model cannot invent**: `timeBeats` (three action beats per shot — wind-up → drive → settle, because one beat is performed as one static pose), `camera` (shot size + focal length + aperture + a move with a start and an end, instead of the empty "push in / pan" template), `vfx` (named physical effects — slanted rain, dust in a light shaft, coat hem in the wind — since an unwritten effect simply does not exist), and `negative` (face swap, drift, clipping, flicker, lip-sync mismatch, plus genre extras). All four are stored per shot and injected into the prompt; nothing is invented when they are empty.
- **The storyboard generator is told how to cut and how to layer motion**: the JSON contract now demands 3 `timeBeats` for every shot ≥2s, a single primary camera move written start→end, 1–3 named VFX, and a `negative` list, and it carries a new segmentation rule — never split one character's one continuous action into several `continuation` shots; when you genuinely change the camera, make the next shot a scene change / insert close-up / new character so the cut is clean. The English contract gained the same rules.
- **`canvas-craft` gained four methodology sections** (+169 lines, nothing removed): `timeBeats` (3 beats with a per-genre example table and a "a single beat = pan only" failure mode), `camera` (shot size × focal length, aperture × depth of field, twelve named moves with their trigger conditions, and a capacity limit of one move + one action chain per shot), `vfx` (five categories with writing examples and a "at least 3 shots per scene" floor), and `negative` (eleven generic failure modes with a positive-avoidance rewrite for each, plus genre additions). A new "field landing" section explains which JSON key each block must go into, and the delivery checklist gained the matching items.
- **Video nodes now show a static poster until the user presses play**: the idle canvas renders one cheap `<img>` from a disk-cached `<asset rel>.poster.jpg` instead of a permanently mounted `<video preload="metadata">`, so a board with ten clips no longer initialises ten decoders or re-rasterises them while dragging; the `<video>` element is mounted only while playing (poster attribute included) and unmounted on pause/end. A new Host route `POST /api/poster` writes the first-frame JPEG under the data root (path-guarded), while the client probes with HEAD, generates once per asset (concurrency ≤2, in-flight dedupe) and silently falls back to a neutral placeholder on failure. `mediaState` is `ready` as soon as the poster exists, so the skeleton appears only once during first poster generation and never flickers back.

### Fixed
- **Director-stage picking was offset on HiDPI and non-square viewports** — the screen projection scaled both axes by `min(w,h)/2` and mixed device pixels (drawing) with CSS pixels (picking), so clicks landed beside the gizmo. Projection and gizmo metrics now share one source (`directorScreenOf`, `gizmoMetrics`) and the renderer takes a device-pixel ratio.
- **View-mode buttons needed an extra click on the viewport** — the render effect did not depend on the mode. Viewport refresh is now driven by a single `viewRev` revision and all three buttons go through `setMode`.
- **Alt-drag uniform scaling was unreachable** — the orbit branch claimed Alt+left before the gizmo was hit-tested. It now only orbits when no scale handle is under the cursor, and uniform scale is applied as a ratio so non-uniform objects keep their proportions.
- **Distant objects could not be selected and marquee selection was unavailable once something was selected** — object picking gained a screen-space tolerance, the marquee is always available (a plain click toggles one object) and its rectangle is now visibly blue instead of a dark outline.
- **Exported clips dropped colours/materials and included path guides** — export now preserves object colour, material and lighting while stripping every editing aid (grid, paths, labels, gizmo), and export/live render use the same scene builder.
- **The Z-axis scale handle was flatter than X/Y and could be hidden under the rotation rings** — all three handles are now screen-facing squares of identical size, drawn after the rings.

- **The canvas no longer flickers between skeleton and picture**: the old flow reset `mediaState` to `idle` on every asset change and waited for `onLoadedMetadata`, so a re-render could briefly unmount the media and show the skeleton again. Video readiness now comes from the poster `img`, and a poster failure is a neutral placeholder rather than a repeating skeleton; image nodes keep their existing single-load path.

### Changed
- **Every screenshot in both READMEs and both guides now shows the current UI**: the old overview, pipeline, provider-detail, projects and bible images are gone; the case studies were rewritten around the new panel (floating icon rail, project dropdown with `project · canvas` rows, unified bible/assets modal, generation panel) and both languages gained shortcuts and help screenshots.
- **Asset lookup and node dragging got much cheaper**: `idbGet` now hits `assetMem` → `hostRpc('assetsGet')` first (IndexedDB only in JSON mode, only once per miss in SQLite mode, or when the RPC throws), removing a pointless IDB transaction on every lookup; large blob object URLs (>8MB) are no longer cached (LRU cap 40 entries / 48MB for small ones) so tens-of-MB videos stop being pinned in memory. Node dragging is coalesced into one `requestAnimationFrame` per frame with only the dragged node + neighbours in the snap/push candidate list, writes `style.left/top` and edge paths imperatively with zero `notify` during the drag, emits exactly one `notify` on pointerup, temporarily disables the running-sheen filter via `is-node-dragging`, and skips `MediaNodeBody` re-renders through a stable `_rev`/edge-signature memo. Nodes also get `contain:layout style` (no paint containment, so ports stay clickable), and edge paths are recomputed at most once per frame and only for edges touching the moved nodes.

### Internal
- `scripts/test-changelog.mjs` no longer fails a release build: an empty `main..dev` range is treated as the normal already-released state, while a genuinely missing git still fails under `--strict`.
- `scripts/test-director-stage.mjs` (registered in `scripts/regress.mjs`) pins the director stage: the scene serialises as plain JSON, camera maths projects the target to screen centre and rejects points behind the camera, every primitive yields finite (non-NaN) faces, the renderer actually fills pixels (and draws fewer lines with the grid off), picking hits the object at screen centre and misses empty space, the compiled prompt always demands mannequins become real people, `save`→`load` round-trips while corrupt data falls back to a usable default, the rail entry exists inside `IconRail` and `DirectorStage` is mounted, and reverse assertions forbid both `require('three')` and any reference-project identifier from leaking into our source.
- `scripts/test-segment-plan.mjs` (registered in `scripts/regress.mjs`) pins the segmentation contract: segments cover every shot exactly once in order, every segment boundary lands on a cut (and a boundary that unavoidably falls on a `continuation` shot must be flagged `needsTailChain` + a non-`none` `seamRisk`), a segment that starts on a cut must NOT request tail chaining, no non-single-shot segment exceeds the cap, an over-long single shot produces a warning instead of silence, the weak/strong model split returns the expected answer for MiniMax / Hailuo / Seedance, the composer writes only its own segment's shots and injects `timeBeats` / `camera` / `vfx` / `negative`, and reverse assertions stop the old "sum the whole storyboard into one generation" code from coming back.
- `scripts/test-canvas-perf.mjs` (registered in `scripts/regress.mjs`) covers the poster/video lifecycle, poster cache/generation/HEAD/POST/fallback and concurrency limit, Host `/api/poster` write + `../` rejection + GET readback, the `idbGet` order/miss/JSON/throw-fallback cases, the imperative rAF drag (no notify during move, exactly one on pointerup, `is-node-dragging`), and `MediaNodeBody` memo behaviour; `test-node-layout` now accepts the lazy `<video>` (asserts it appears only after play) and `test-drag-alt` looks at the extracted `applyNodeDragFrame`.
- **The BLK-01 / BLK-02 investigation records now live in the repository** under [`docs/evidence/`](docs/evidence/) instead of outside it: `client.js` cites `docs/evidence/BLK-02-静默错位-20261019.md` for the "never send a relative path without a base" rule and `scripts/test-delete-project.mjs` cites `docs/evidence/BLK-01-删除项目残留-20261019-1512.md` for its ten acceptance criteria, so cloning the repo gives you the evidence those comments depend on.

## [0.18.7] — 2026-10-22

### Added
- **One「专家 / Expert」picker replaces the two skill dropdowns**: the settings card is now just「技能增强 / Skill boost」with a single「专家 / Expert」select; an expert bundles a per-capability persona (`script` / `storyboard`) with a `skills` list, and the picker only lists plugin experts — the current build ships `general`（「通用专家 / General expert」, the default）, whose persona and `canvas-craft` skill are exactly the previous built-in experts, so generation quality and prompt structure are unchanged. Script and storyboard generation now resolve through the same `buildExpertContext(kind, settings)` path (and so does bible drafting), so one selection drives both; unknown/missing ids fall back to `general`. The registry is a plain `EXPERTS` array so future experts (ancient-costume / wuxia / marketing) only need their own `persona` + `skills`; Harness-wide skills (artcraft-* / noteboard-* / office-* / diagnose-*) are never offered. Old settings with `skillScript` / `skillStoryboard` but no `expert` migrate silently to `general` (the legacy keys are no longer written or read), and a corrupt value never throws.
- **The client plugin loads again after the shortcut work**: the skill shortcut probed `ctx.shortcuts` directly, and the client runner rejects reading a service a module did not declare in its `inject` list (`cannot get property "shortcuts" without inject`) — that threw during the module's `apply`, so the whole client half failed to synchronise and the panel never appeared. `shortcuts` is now declared in `inject`, and the probe is wrapped so an older runner without the service only skips the shortcut instead of breaking the plugin.
- **Image and video generation nodes are merged with their asset counterparts**: `image` replaces the old `image-gen` + `image-asset` pair and `video` replaces `video-gen` + `video-asset`. One node now covers both states — it is an asset when it has a result (`assetId`) and a generator when it has a prompt — so expanding a storyboard builds one video node instead of a generator-plus-asset chain, and the canvas no longer grows two columns for the same content.
- **A single generation composer replaces the in-node input areas**: clicking any node opens one floating panel anchored just below it (flipped above when there is no room, clamped to the viewport, with a caret pointing at the node). It carries the reference row, the prompt, the controls and the send button, and it follows the node while panning, zooming, resizing the window or resizing the node.
- **Model pickers list only configured models**: text uses the models available to the current Harness session; image and video use the providers/models configured in the plugin settings. The picker has a fixed width (~172px), ellipsizes long names, shows the full provider · model on hover and opens a searchable list with the provider name on the right.
- **Per-type controls in the panel**: text/script/storyboard get the text model only; image gets image model + ratio + quality (1K/2K/4K) + count (1–4); video gets video model + ratio + resolution (480P/720P/1080P) + duration; final cut gets ratio/resolution only. Controls never mix between node kinds.
- **Storyboard predecessor picker**: the shot count shows just 「N 镜」 and continuity is now chosen from a storyboard dropdown (or 「不衔接」) instead of a toggle; selecting a predecessor draws the bottom-center → top-center continuation wire and keeps the existing `prev` semantics (one predecessor per storyboard).
- **Single-point ports with automatic semantic routing**: every node has one input dot at the left edge center and one output dot at the right edge center (plus the storyboard's top/bottom continuation dots). When a wire is dropped, the system decides the internal semantic port from the upstream node kind (text → prompt/script, image → ref/frame, video → frame or final-cut `in`), so users no longer have to aim at tiny per-port dots.

- **The floating icon rail is a slim square-cornered pill over the canvas**: the icons float vertically centred on the left edge with the dotted canvas showing through above and below, the pill hugs them (38 px wide, solid theme background, 1 px border, light shadow, square corners), and clicks on the empty strip fall through to the canvas.
- **A fixed left icon rail groups every action**: text, script, storyboard, image, video and final cut add a node at the viewport centre (same add path and default 360×360 size as everywhere else); assets and the series bible open the unified modal and highlight while that tab is active; run workflow (or stop, while running) lives there too. The rail is a fixed column outside the pannable/scalable world, with hover tooltips.
- **Assets and the series bible now share one modal**: two tabs（设定集 / 资产）, a close button, Esc and click-on-mask to dismiss. The assets tab is a card grid (thumbnail or video first frame, name, category, time) with search, category and project filters, client-side pagination, preview/download and add-to-canvas; the bible tab keeps every entry card and now also shows the thumbnails of the assets bound to a character/scene/prop.
- **The project switcher moved to the far left of the toolbar, right after the back icon**: 「返回会话」 is now an icon-only `<` button placed to the left of the project name (the text label is gone), and renaming a project is an in-place edit — double-click the name (or click the pencil in that project's dropdown row) to turn just that name into an input, with Enter to commit, Esc to cancel, blur to commit and an empty name rejected while the old name stays. The current project is marked by the blue accent background/text alone (the trailing ✓ is gone), and the row's pencil works for the selected project too: starting the edit on pointerdown and guarding the row click by event source keep the row's switch/close behaviour from swallowing the click and unmounting the inline input. Each row is a single line —「项目名 · 画布名」, with the canvas name in the secondary colour and one size smaller (the current project shows its active canvas, other projects their default canvas, omitted once the default canvas is deleted); the inline rename only edits the project-name part while the canvas name stays on the same line, and the input width is sized from the name so the row does not jump. The pencil beside the toolbar name is gone, the toolbar no longer shows a separate canvases-name chip (read it from the dropdown or the right panel), and the dropdown keeps only the project list (each row with its own edit button) plus「新建项目…」; the old「重命名项目…」item does not come back. The dropdown is a searchable list whose height follows its content: up to 5 projects it is exactly N×38 px tall with no empty space, and only when more than 5 match does the list lock to 5×38 px and add a pager at the bottom — `‹  [page] / N  ›`, where the middle is a numeric input that jumps on Enter/blur, clamps values outside 1..N and leaves the page unchanged for non-numeric text. The top row is `[+] [search]`: creating a project is now an icon-only `+` button to the left of the search field (tooltip only, no text/border/fill, still opens the required-name dialog), the bottom「+ 新建项目…」text row is gone, and the search field carries a magnifier inside its right edge (`position:absolute; right:8px`, pointer-events none) with a single input border and no extra wrapper/background. Switching page or search first commits or cancels an in-progress inline rename, so no input is silently unmounted.
- **Projects hold multiple canvases, and the right panel shows only the current one**: the「项目」tab is a compact tree of the active project — a 38 px project row (in-place rename, delete with confirmation) above 33 px canvas rows (switch, in-place rename, delete) with an 18 px indent, so the two levels read as one hierarchy instead of a giant project header over tiny children. A fold arrow collapses the canvas list (state remembered in localStorage), a search box filters the canvases as you type (usable with hundreds of them), and the panel only manages the current project: the「+ 新建项目」button is gone because creating a project always goes through the project-name dropdown at the top left (where the naming dialog still requires a name), and the old bottom「+ 新建画布」row is gone too — a pure `+` icon button now sits to the left of the search field (icon only, tooltip, no text/border/fill), while the magnifier is rendered inside the search input on its right edge (`position:absolute;right:8px`) and the search row itself adds no second border or background. Every canvas — including the default one — can be renamed in place and deleted with an inline confirmation; when the project has only one canvas left the delete buttons are hidden for both the default and sub-canvases (the pencil stays, renaming is always available), and deleting the default canvas switches to the first remaining canvas while its document content is cleared. Sub-canvases are their own documents (create / switch / rename / delete, blank first entry); assets and the series bible stay project-scoped.
- **The default canvas got a name and a delete path of its own**: a project document now stores `defaultCanvasName` (missing on old projects → falls back to「默认画布」with zero migration) and `defaultCanvasDeleted` for the case where the default canvas was removed. `canvasRename` accepts `canvasId: null` and writes that name; `canvasDelete` accepts `canvasId: null` (clears the default document content + name, marks it deleted, returns `nextCanvasId`); `canvasesList` / `canvasCreate` / `canvasDelete` all return `defaultCanvasName` / `defaultCanvasDeleted` so every surface agrees, and the toolbar and project dropdown show the active canvas name next to the project name. Deleting the default canvas is refused by the host when it is the only canvas, and deleting a project still removes every canvas document.
- **Shortcuts, support and update check are back at the top right, as icon-only buttons**: three icon buttons (keyboard / help / download, with hover tooltips and an up-arrow when an update is available) sit at the right end of the toolbar, and the right panel no longer has the action row — it only holds the tab bodies.
- **Every popover/menu/dialog/toast is a solid theme surface now**: all of them — project dropdown, context/add menus, shortcuts panel, model picker, modals and the unified studio modal, mask editor, toast, minimap — use `--dsw-alias-bg-layer-1` (white in the light theme, dark in dark themes), a 1 px `--dshic-line2` border (theme border in dark), a 14–16 px radius and `--dshic-shadow-lg`, with hover on `--dsw-alias-interactive-bg-hover` and the selected row on `--dshic-accent-soft` + `--dshic-accent` (brand tint in dark). `--dsw-alias-bg-overlay` (a blue-grey wash), translucent backgrounds and `backdrop-filter` blur are gone from the plugin CSS, and the in-node media chips/controls (status badge, reference badge, duration pill, player controls) are solid too; only the modal scrim and the fullscreen lightbox keep a neutral dim behind the surface.

### Fixed
- **Media nodes now keep the picture aspect exactly, with fixed chrome around it**: a media node is a preview box whose aspect equals the media itself (short side 360, long side up to 800) plus a **fixed-height header bar and a fixed-height action bar that are not part of the picture ratio and never stretch** — 16:9 renders as a 640×360 preview inside a 640×424 node, with no crop and no letterbox. Loading a document corrects image/video boxes to their recorded aspect (falling back to the asset's pixel size, then 16:9), unloaded or failed media show a neutral skeleton rather than a broken-image placeholder, dragging resizes the preview proportionally (double-clicking the bottom edge restores it), and text/script/storyboard nodes stay fixed at 360×360 and stretch their scrollable content instead of leaving empty space.
- **Node and composer styling now follows the reviewed prototype**: colours, radii, shadows, header gradient, status pills, reference badges, dashed empty states, the action bar (with its own padding and top border so buttons never touch the picture), and the floating panel's caret, thumbnails, 28 px controls and circular send button are all driven by one `--dshic-*` variable block, so the values match the prototype instead of drifting.
- **The generation panel got simpler**: reference images live in a single horizontal strip at the top — drag a thumbnail to change the order, which is exactly the `[图N]` numbering bound into the prompt and sent to the vendor — and the duplicated text list of references (with its up/down buttons) is gone. Everything advanced (continuity mode, next-shot chaining, voice extraction, extra JSON parameters, redraw/mask/craft, history, warnings) now sits behind a collapsed "更多" that is closed by default, so the panel shows only the reference strip, the prompt and one control row.
- **Video previews expose controls only while playing**: a single round play button sits on the picture; pressing it reveals a bar with play/pause, a draggable progress bar with elapsed/total time, and volume with mute. Pausing or finishing hides the bar again and leaves just the round button (now a replay icon).
- **Generated media consumes only the references you actually wired**: the collector used to append the assets a `@entity@` mention resolved to (bible-bound images plus name-matched variants and older generations), so a node with 6 wired references could hit a vendor limit warning for 9. References are now strictly the edges into the reference port in `refOrder`, the limit warning and the panel badge read the same list, and mentions inject text only — never images.
- **Binding a reference image to a bible entry now lists every asset**: the picker read the local IndexedDB leftovers only, so older generations, other devices and non-thumbnail assets were missing. It now pages through the host asset API to the end, merges local leftovers, sorts newest first, and searches name, prompt and id.
- **`@entity@` in a storyboard now injects the bible text into the video prompt**: after the reference fix a mention no longer drags images along, so the appearance and voice description had to come from the bible itself. Structured video prompts gain a `series_bible` block for text-only mentions (appearance plus the voice line), hand-written structured prompts get the same block appended, dialogue falls back to the entity's voice, and the tail-continuation path is covered too — text only, reference counts unchanged.
- **Script and storyboard skills now enforce shot-level detail**: scene-to-scene causal hooks, the four beats per scene, the six elements of a shot description (with a required big close-up per scene), a start-move-end motion formula that forbids bare pans and three identical moves in a row, an impact/conflict beat per scene with four concrete techniques, a terminology errata list, and a pre-generation quality gate that blocks video generation from coarse storyboards.
- **The built-in expert personas now carry the same rules**: the hard-coded storyboard expert used to ask only for a five-part visual summary, so the assistant kept producing coarse shots regardless of the skills. Both persona constants (storyboard, script) now demand the six-element shot description, one big close-up per scene, the start-move-end motion formula with no repeated move across three shots, an impact beat per scene, causal hooks between scenes and correct terminology — with the JSON output contract untouched.
- **The creative skills are available to the Harness itself, with a shortcut**: the plugin already registers `canvas-craft` / `canvas-studio` / `canvas-layout` into the Harness skill catalogue through the skill service, so the chat agent can load them; a new `infinite-canvas.skill` shortcut (Ctrl/⌘+Shift+K) opens the canvas and a skill palette that copies any of the three skills' full text to the clipboard, and the command also shows up in the Harness shortcut catalogue and the plugin's own shortcuts panel.
- **Clicking a node opens the panel only from its content area**: the header stays the drag/rename strip and the bottom bar stays the action strip — clicking either no longer pops the composer. Media previews and text bodies open it; on a video, a single click on the picture opens the panel, a double click plays, and the round play button plays without opening anything.
- **The composer controls stay on one row**: the panel has a 520 px minimum width (up to 720 px), the control row no longer wraps, and the model picker shrinks with an ellipsis while the send button always stays inline — with the model first, then shot count / continuity, ratio / quality / count, duration, `@`, send.
- **Existing projects keep loading after the type merge**: every document entry point normalizes legacy node types (`image-gen`/`image-asset` → `image`, `video-gen`/`video-asset` → `video`) while leaving node data untouched, so old projects keep their results (`assetId`), prompts, sizes and every edge endpoint; migration is idempotent. The Host read path and project summaries apply the same normalization, so `canvas_list_projects` / `canvas_node_status` report the merged type.
- **The old "generator → asset" wiring no longer overwrites reference images**: result propagation to a downstream node only follows the legacy `out → in` link, so a downstream image node wired as a reference no longer inherits the upstream video's `assetId`.
- **Legacy names keep working in the agent tools**: `canvas_create_node` still accepts `image-gen` / `image-asset` / `video-gen` / `video-asset`, maps them to the merged type and says so in the response, while `canvas_connect` picks the target port by semantics (script/prev/prompt/ref/frame/in).

### Changed
- **Nodes show results only**: image/video nodes render the preview (or a dashed empty state saying 「点击描述画面生成图片/视频」) with a status badge at the top-left and a reference badge (thumbnail + count) at the top-right; empty media nodes carry no generate button at all. Result actions (download / regenerate / refs) sit at the node's bottom-left. Script and storyboard nodes show the script body / shot summary instead of input areas; text nodes show a read-only preview.
- **Every node defaults to 360×360 and persists `w`/`h`**: generated image/video nodes grow in exactly one direction to match the frame ratio (16:9 widens, 9:16 heightens) with a long-edge cap of 800; text/script/storyboard keep their 360×360 size until the user drags an edge (content scrolls inside).
- **Port positions changed**: input/output wires now attach at the left/right edge centers, and the storyboard continuation wire runs from the bottom-center of the predecessor to the top-center of the next storyboard.
- **Canvas skills describe the merged nodes**: the studio/layout/craft docs now talk about 「图片节点」/「视频节点」, state that a node with a result is the asset itself and that an empty node is generated from its panel, and stop teaching the old generator/asset split.
- **The canvas panel no longer leaves a blank strip on top**: the page used to inherit the host's `--dsh-frame-top-clearance` as a top padding, which opened the canvas with an empty band above the toolbar (same in the right-pane host). The padding is gone, so the toolbar sits flush against the top edge.
- **The left icon rail is chrome-free and floats in the middle of the column**: the rail container has no border, background, box-shadow or border-radius at all — only the icon buttons themselves remain, with a light hover tint on the buttons as the sole interaction feedback. The rail itself is `flex:none` + `height:auto` + `align-self:center` + `margin:auto 0`, so it hugs its content (≈347 px for the nine actions) and stays vertically centred instead of stretching from the top edge to the bottom. The element also carries an inline zero-reset (`border:0`, `background:transparent`, `boxShadow:none`, `borderRadius:0`, `height:auto`) so a host/global stylesheet left over in an installed build cannot paint the old full-height bordered strip, and the regression test now scans **every** CSS rule whose selector matches `.dshic-rail` (not just the first one) and asserts the rendered element's inline/computed chrome is zero plus a box-model check that its height stays well under the parent with ≥20 px whitespace above and below.
- **The settings page no longer dumps a paragraph of storage diagnostics**: the data-root card used to render one long line (“存储实况：SQLite 库（… MB + WAL … MB）· N 项目 · M 资产 · 检索 …”) plus the database path underneath. It now shows a single compact status (“存储 · SQLite · 62MB”, one line with ellipsis) and an ⓘ button; the full details (size/WAL, project/asset counts, search backend and the database file path) only appear after expanding, inside a solid theme surface (`--dsw-alias-bg-layer-1` + 1px `--dshic-line2`, radius 12, no highlight), and collapse again on the second click. The ↻ re-check stays as a small icon.
- **The right panel only keeps Projects and Settings**: assets and the series bible were removed from the right panel because they live in the unified modal now; the project tab is the multi-canvas directory tree.
- **A project's default canvas keeps the old storage key**: a canvas without an id (`canvasId = null`) still stores its document under the project id, on the client and on the host (`projectsPut` / `projectsGet`), so every existing project, host database and skill workflow opens exactly as before with zero migration; only a named sub-canvas uses its own document (`projectId::canvasId` on the client, `projectId__cv__canvasId` on the host). The default canvas name and its "deleted" state travel as `defaultCanvasName` / `defaultCanvasDeleted` on the project document, and a project whose default canvas was deleted reopens on its first sub-canvas instead of a missing default.
- **The project dropdown now speaks the same visual language as the generation panel**: the old popover used `--dsw-alias-bg-overlay` (a blue-grey wash in the light theme) with a 12 px radius and a hard-coded shadow. It now uses the theme background `--dsw-alias-bg-layer-1` (white in light, automatically dark in dark themes), a 1 px `--dshic-line2` border, a 15 px radius and `--dshic-shadow-lg` — no literal colours at all. Items are 32 px tall with a 9 px radius and the panel font size; each row carries its own pencil「修改」button that turns that row's name into an inline input, hover uses `--dsw-alias-interactive-bg-hover`, the current project uses a theme-brand tint with brand-coloured text and its ✓, and the project list is separated from「+ 新建项目…」by a 1 px `--dshic-line` rule instead of a colour block. The menu is clamped to the viewport on both axes and caps its height from its own top offset, so a long project list scrolls instead of spilling out. The「重命名项目…」dropdown item stays removed: renaming is the double-click on the name, the pencil in the dropdown row, or the rename button in the right panel.

### Internal
- `scripts/test-skill-inject.mjs` now also pins the expert system: `loadSettings()` migrates old `skillScript`/`skillStoryboard` (and missing/illegal values) to `expert === 'general'` without throwing and no longer emits the legacy fields; `EXPERTS` contains only `general` with a `persona` (script/storyboard) plus a plugin-only `skills` list; the settings card renders one `ExpertSelect` with a single「通用专家」option and no Harness skill names (artcraft-*/noteboard-*/office-*/diagnose-*), no「剧本技能」/「分镜技能」labels and a parenthetical-free title; and `buildExpertContext` returns the general persona + canvas-craft rules for both script and storyboard, while an injected fake second expert proves the registry/dispatch is per-id rather than hard-coded.
- `scripts/test-node-merge.mjs` loads a legacy document (four old node types, five wires, `assetId` and prompts) and asserts the type normalization, preserved wires/endpoints/data and idempotency of repeated migration; it is registered in the regression gate.
- `test-tools` now covers `image`/`video` creation, the legacy-name mapping and the merged `type` reported by `canvas_node_status`; `test-expand-assets` asserts expansion creates `image` nodes and a single merged `video` node; `test-node-actions` pins the result actions of the merged media node and the empty state (no generate button), and renders the composer for every node kind; `smoke-render` walks `MediaNodeBody` and `GenComposer` for all node kinds.
- `scripts/audit.mjs` knows the merged runnable types and the two-sided port table keeps both sides in sync.
- `scripts/test-panel-layout.mjs` pins the new panel structure: no top clearance/padding and the toolbar is the first block; the icon rail order, add-node behaviour (viewport-centre add with default size), that the rail only takes the middle of the column (`height:auto` / `align-self:center` / `margin:auto 0`, no `flex:1`) and that its container rule has no border/background/box-shadow/border-radius at all; the unified modal's two tabs, assets data source `assetsForPicker`, grid cards, Esc/mask close and the removal of the assets/bible tabs from the right panel; the icon-only back button left of the project name and the absence of the toolbar pencil; project renaming by double-click and by the per-row dropdown pencil, rendered as an inline input with Enter/Esc/blur/empty-name paths and names syncing to the toolbar and the right panel; the dropdown's adaptive list (12 projects → 5 rows on page 1 with the `.is-paged` fixed 5×38 px height, pager `1/3`, page 2 showing 6–10; a filtered 3-project result rendering only 3 rows with no fixed height and no filler rows; search filtering to ≤5 rows with correct results, empty state for no match, pager only above 5 results), that each row renders a single `项目名 · 画布名` line (no separate canvas sub-row node, canvas name before/after order, inline edit keeps the canvas name on the same row and renames only the project), that the toolbar renders no active-canvas chip (source + render) while the project name and caret remain, and that changing page or search settles an in-progress inline rename instead of dropping the input; the current project row having no ✓ while its pencil still starts the inline edit from pointerdown/click without switching the project or closing the menu; the right panel showing only the current project with project/canvas inline rename, delete, fold (persisted to localStorage), a search field whose magnifier sits inside the input on the right, a pure `+` icon before the search field (no text/border/fill, tooltip retained) and no「新建项目」/bottom「新建画布」button, plus the size contract (project row 36–40 px, canvas row 32–34 px, 12.5–13.5 px / 12–13 px fonts, 16–20 px indent, height gap ≤ 8 px); the default canvas row offering the same inline pencil (name syncing to `canvasNameFor(null)`, the toolbar canvas chip, the dropdown row and the panel, blank names rejected) and a delete path that switches to the remaining canvas and drops the default document cache; the delete buttons being hidden (not disabled) on every canvas row when the project has only one canvas, with the pencil still there; the global solid-surface contract (every popover container on `--dsw-alias-bg-layer-1`, 1 px border, 14–16 px radius, `--dshic-shadow-lg`, no `--dsw-alias-bg-overlay` / rgba / `backdrop-filter` anywhere in the CSS, and no literal colours inside popovers); and the multi-canvas data layer (default-canvas key compatibility, independent canvas documents, blank first entry, rename/delete, undo-stack reset on switch, project-scoped assets and bible, the canvas naming dialog). It also pins the top row (`+` icon-only create button before the search field, no text but a tooltip, magnifier inside the search input at its right edge with a single input border and no extra wrapper), the bottom pager (only above 5 results: prev / page input / `/ N` / next, positioned after the list, page jump on Enter and blur, clamping 0→first and >N→last, non-numeric text leaving the page unchanged, and no pager row or placeholder at ≤5 results), the rail's chrome-free contract across **all** CSS rules matching `.dshic-rail` plus the rendered inline zero-reset and a box-model check (content height well under the parent with ≥20 px whitespace above/below, mounted as the first direct child of `.dshic-main` with no wrapper), and the settings storage card (compact one-line status default, no long diagnostics/db path until expanded, ⓘ toggles details with the db path + counts + search backend, collapse again, details surface solid theme). `test-node-layout` now pins the solid media chips (status badge / reference badge / duration pill) and `test-drag-alt` asserts the shortcuts entry sits in the top toolbar (compact) instead of the right panel.
- `scripts/test-multi-canvas.mjs` drives the host protocol in a temporary directory: the default canvas document id equals the project id, a sub-canvas document id is `projectId__cv__canvasId`, `projectsPut`/`projectsGet` accept `canvasId` (nodes, edges and view stay in the right document), `projectsList` never lists canvas documents and attaches the canvas registry, `canvasCreate`/`canvasRename`/`canvasDelete`/`canvasesList` work and reject blank names, every `canvas_*` agent tool accepts `canvasId` (missing it means the default canvas, so cross-canvas lookups fail as expected), the `docChanged` sync signal carries `canvasId`, deleting a project removes its canvas documents (and late pushes are still refused by the deletion tombstone), and a legacy project without a `canvases` field still opens its default canvas unchanged. It also covers the default canvas: `canvasesList` falls back to「默认画布」on old projects, `canvasRename` with `canvasId: null` writes `defaultCanvasName` (blank rejected, duplicates against sub-canvases rejected both ways), `canvasCreate`/`canvasDelete` return the name, `canvasDelete` with `canvasId: null` clears the default document/name, marks `defaultCanvasDeleted` and returns `nextCanvasId`, refuses when it is the only canvas, and the deleted default canvas can no longer be read or renamed.
- The canvas document key is abstracted as `canvasDocKey(projectId, canvasId)` / `activeGraphKey()` / `listCanvases()` / `switchCanvas()` / `createCanvasNamed()` / `renameCanvasNamed()` / `deleteCanvasNamed()`; `S.activeCanvasId = null` is the project default canvas, so old data and the host protocol keep working unchanged, while a named canvas reads and writes its own `projectId::canvasId` document. The host mirrors each canvas document to `<data root>/projects/<project folder>/canvases/<canvasId>.json` so a JSON-mode data-root import/export carries sub-canvases as well, and project deletion removes them along with the project folder.

## [0.18.6] — 2026-10-21

### Added
- **Expanding a storyboard now builds asset nodes that are ready to generate**: every character, scene and prop the shots mention is resolved against the asset library first — an image that exists becomes an asset node wired to the video's reference port, and one that does not becomes an **image-generation node whose prompt is already written** to the asset-sheet layout (character six-block sheet, scene main-image-plus-surrounding-panels, prop title + 45° hero + details + side view + colour swatches; 2K landscape). The bible's appearance notes and style baseline are injected automatically, so the reference sheet is usable in one click instead of being hand-written. Re-expanding the same storyboard reuses same-label generator nodes rather than stacking duplicates.

### Fixed
- **No more empty 「待补充」 placeholder nodes after expanding**: the old placeholders made a video node look wired up while its reference list stayed empty; they are replaced by the generator nodes above, and the toast reports how many asset nodes were created versus reused from the library.

### Changed
- **The canvas skill documents the new expansion contract**: what expansion creates for each missing entity, the naming convention of the generated sheets, and the order to generate in (assets first, then video).
- **Result actions now sit at the node's bottom-left on every node**: the script node had 铺开到场景 / 存为资产 between the generate button and the script body, while every other result-bearing node kept its actions after the content. The script node follows the storyboard convention now (save-as-asset, then the primary expand), and the layout skill states the rule: buttons that act on a generated result go last and left-aligned, input controls stay in the input area.

### Internal
- `scripts/test-expand-assets.mjs` drives the real expansion in a sandbox (3 entities → 3 generator nodes with sheet prompts and 3 reference edges, no placeholders, no duplicates on a second run); `test-mentions` covers the prompt generator for all three asset kinds plus the English variant, and the regression gate lists the new test.

## [0.18.5] — 2026-10-21

### Added
- **The canvas now lives beside the chat as a right-pane tab**: the Harness right pane is a tab system, and the plugin registers an 无限画布 tab (full canvas UI) plus an entry card on the Start page that opens it — chat on the left, storyboard/generation/final-cut on the right, no more flipping between two views. The canvas runs in exactly one place at a time (shared node graph and generation state): opening it in the pane while the full-page canvas is open (or vice versa) moves the live instance instead of duplicating it, and claiming the narrow pane collapses the canvas's own side panel to fit.
- **Full node control for the agent** (`canvas_update_node`, `canvas_generate_node`): the assistant can now read and patch any field of an existing node (prompt, ratio, size, duration, resolution, shots, …) instead of being limited to create/write, and can trigger a generation and wait for the finished asset in one call. `canvas_node_status` additionally exposes the effective prompts and generation parameters, and nodes surface reference-cap warnings. Settings gained a storage statistics panel.
- **Vendor-format video prompts from the storyboard**: prompts for storyboard-driven shots are composed in the reference-generation format the video vendors actually expect — subject/picture binding, speaker-tagged dialogue with per-speaker voice, an absolute timeline, and a soundscape paragraph — replacing the previous mechanical sentence assembly.
- **Segment continuity**: separately generated segments now actually connect. Shots carry explicit hand-off state (`tail` = where this shot ends, plus camera), and the next shot's prompt inherits the previous shot's hand-off instead of inventing its own starting pose.
- **Alt-drag to place a node freely** while keeping the existing collision-pushing behaviour as the default, plus a **keyboard-shortcuts panel** listing every canvas shortcut (the entry lives in the top toolbar).
- **Unknown video vendors degrade instead of dying**: a recognized vendor name without an official adapter no longer hard-fails the generation (`暂未适配的视频厂商格式`) — it falls back to the OpenAI-compatible chain (with its existing Seedance-content[]/Sora fallbacks) and shows a node-level notice naming the vendor, the format used, and where to set the vendor explicitly.
- **EXIF rotation is reported, not just survived**: when a Compshare reference upload is registered with the raw file dimensions after the decoded-dims attempt was rejected, the node now shows a visible note with both dimension pairs (previously console-only).

### Fixed
- **Opening the canvas tab now shows the canvas**: the Start-page card was there but the pane rendered only 「这类内容还没有可用的查看方式」. The shell dispatches a tab body by `renderSlot(seat, {}, { entryKey: definition?.id ?? tab.kind })` — the registered type's **id**, with `kind` only as the no-registration fallback — while the body/title slots were keyed by kind. Both now key on the registration id (the same single-constant convention the shipped terminal tab uses), and the tab chip gets its custom title back.
- **The right-pane tab kind is now registered in the pane registry**: registering only the pane-tab body slot left the Start page without a canvas entry — the Start page renders its standard cards from the tab-type **registry** (one `guide` array per kind), and a `guide.entry` slot override has nothing to override unless that kind is registered. The plugin now registers the kind (title, description, icon), and the hand-drawn card/title slots are gone.
- **Storyboard consistency warnings can be re-checked on demand**: the check ran once at generation time, so warnings about bible entries that were missing then stayed red even after those entries were completed. The consistency card has a 刷新 button that re-runs the check against the current series bible and asset index and updates the node in place (no regeneration, no cost).
- **Opening the panel no longer creates a placeholder project**: on a clean browser (no canvas state), mounting the Infinite Canvas panel materialized an empty project named 「我的画布」 and the startup push wrote it into `canvas.db` — the projects table grew by one on every open (QA measured 13 -> 14, repeatedly). An empty project list is now an empty state: the projects panel shows guidance toward the explicit "New project" button (or creating one from chat), and nothing is written until a project actually exists. Deleting the last project enters the same empty state instead of recreating a placeholder.
- **The no-models hint no longer claims runs will fail**: the provider card said 「未配置模型——节点运行将报错」 while generations could succeed, so the copy overstated it. It now states what actually happens: runs ask you to configure a model first and surface a readable error in chat.
- **Final-cut merge could never complete**: `composeFinalCut` referenced an undeclared `dur` variable, so every merge threw `ReferenceError: dur is not defined` and no finished cut could be produced. The whole compose loop was hardened while fixing it.
- **Continuity fixes found by an end-to-end audit**: 13 defects across storyboard segmentation, ports and skills (including two incompatible vocabularies for shot size that silently fell through to the wrong matching mode), and a semantic inversion where a shot's tail was read as its own starting state instead of the previous shot's end state.
- **Character-sheet skill**: the built-in prompt now forbids foreign objects and declares an empty-handed stance plus a whitelist of allowed items.
- **Craft outputs no longer survive project deletion**: deleting a project now also removes its ArtCraft `craft/` directory (resolved through the same project-folder base as every other call), idempotent and with visible failures. The root cause was fixed too: projects that only ever existed in SQL storage mode never registered their data-root folder entry — which is why on-disk folders showed the project id instead of the name.
- **Asset-dimension measurement failures name the file**: the error now includes the sniffed MIME type and hints the file may be corrupt, instead of a bare sentence.
- **Path traversal in project deletion is rejected**: `canvas_delete_project` / `projectsDelete` passed the caller-supplied project id straight into the disk-cleanup candidates, so a crafted id (`..`-segments, an absolute path, or a bare `.`) made `rmrf` target a directory outside the data root — up to and including the whole `projects/` tree. Cleanup candidates are now resolved and must land strictly inside `<dataRoot>/projects` as a subdirectory; rejections are reported in the RPC result, and a folder name that sanitizes to a dot-form falls back to an unnamed-project label.
- **Structured video prompts bound subjects to the wrong reference images in continuation segments**: when a tail frame leads the request's reference list (image 1 = the previous segment's last frame), `subject_definitions` still counted entity refs from `<Picture 1>`, contradicting the same prompt's own `[图1]=tail` labeling — every subject pointed one image off and the reference-generation format's subject-to-asset anchor was broken. Both prompt composers now number entity refs 2..N+1 in that mode (hard first-frame mode keeps 1..N).
- **canvas_generate_node could report the previous run as this run's result**: the host polls every 2.5s while the canvas consumes run requests on its 3s tick, so for any node that had run before, the first poll read the stale done/error — with the old asset id presented as the new result (always with the canvas page closed, ~17% with it open). The wait loop now snapshots the node at trigger time and only trusts a terminal state after the run was observed to start (or the document timestamp moved past the trigger); otherwise it keeps waiting and says so.
- **Deleting a project no longer hides disk-cleanup failures**: a partially failed `rmrf` (file locks) was invisible to both consumers — the agent tool always answered 已删除 and the client fired the request without reading the result. Both now surface the failures; the client also cleans the ArtCraft directory **before** the delete so the meta entry still resolves the physical folder (this also removes the craft-cleanup race's false success).
- **The shortcuts panel now shows descriptions**: the row helper dropped its third argument, so every row rendered the key name twice (`Alt + 拖动|0`) and none of the fifteen descriptions appeared.
- **Storyboard shot counts can go back to auto**: `canvas_update_node` rejected `count: 0` although both the tool description and project creation define 0 as "auto by content beat".
- **Node warnings are no longer overwritten mid-run**: the size/duration probe replaced the whole `genWarn`, wiping earlier warnings (auto tail-frame pickup, reference truncation, vendor degradation); it now appends.
- **Vendors without a reference-image input no longer misreport it**: eight protocols that take no entity references (Kling, Vidu, Runway, Veo, Luma, PixVerse, MiniMax V1, Stability) were labeled "max 1" — exactly one reference was dropped silently with no warning, two or more were reported as "using the first 1" while zero were sent. They now warn that references are unsupported, and unknown vendors follow the degraded chain's limit (8).
- **The degraded video submission keeps voice references**: falling back to the content[] format no longer silently drops `audioRefs`, so voice/timbre alignment survives the retry.
### Changed
- **Assets always land in the project folder**: newly generated media (text/image/video) is written to `projects/<project>/<kind>/` and recorded in `canvas.db`; IndexedDB writes were dropped from the upload path. Without a configured data root, generation now fails with a clear error instead of silently storing media in the browser. Recording is mp4-first (webm remains the fallback).
- **The three extension mappings now have one documented responsibility each**: disk persistence takes the MIME subtype as-is; Craft paths keep filename-first (the name is the stable identifier inside ArtCraft projects); user downloads keep MIME-first with a whitelisted filename fallback (`final.2026` never becomes `.2026`, `setup.exe` never passes). Every call site is pinned to its own mapping.

### Internal
- One regression entry point (`scripts/regress.mjs`) with unified four-state reporting (PASS/FAIL/SKIP/ERROR) and a `--strict` release gate; `RELEASING.md` and `docs/release.md` now share one script list instead of disagreeing (12 vs 10). The film-merge path (`test-compose`) is finally part of the gate.
- Deleting a project now also clears its disk mirror directory and its FTS rows (regression from the 0.18.0 storage rewrite).
- Canvas → ArtCraft calls now pass an absolute `base` (project directory) with a relative `path`, fixing silent misplacement when the bridge resolved paths against the plugin process cwd.
- Download filenames follow the real container instead of a hardcoded extension.
- The content-addressed object store's **write path is retired**: new uploads never create `objects/` (media goes to `projects/<project>/<kind>/` via `/api/asset`), and `POST`/`PUT /api/object` now answer `405` with an explanation instead of silently accepting. The **read path is kept**, so media created on 0.18.0–0.18.4 still loads, and unreferenced legacy objects are still reclaimed by reference count when their last asset is deleted.
- The reference-upload trio (magic-byte sniffing, raw-dimension parsing, rejected-dims registration retry) is extracted as testable pure functions and pinned by `test-image-upload.mjs` **before** any further hardening (it was patched five times in ten days with zero coverage); vendor detection, gateway-prefix normalization and the unknown-vendor fallback are pinned by `test-vendor-detect.mjs` (18 model-name + 9 URL cases).
- A one-shot `ftsReconcile` maintenance RPC removes `assets_fts` rows whose asset is gone and repairs the inverse (direct SQL inserts skip FTS), idempotent with explicit counts — stock orphans from the 0.18.0 rewrite (58 vs 56 on the live library) converge on first run.
- The three extension mappings are pinned by `test-ext-mapping.mjs` (per-surface binding, dangerous-suffix rejection) and the craft-directory cleanup by `test-craft-cleanup.mjs`. The regression gate grows from 24 to 29 items.
- The release runbook no longer hard-codes the regression item count (both spots defer to `node scripts/regress.mjs --list` as the live source of truth), and this Unreleased section itself is kept complete by a coverage assertion — every unreferenced commit must be recorded here before the gate passes.

## [0.18.4] — 2026-10-18

### Fixed
- **Reference images with EXIF rotation no longer fail asset registration on Compshare**: the platform verifies the declared width/height against the dimensions it parses from the uploaded file, while the browser's decoder returns them rotated (portrait photos come back swapped) — registration was rejected with `Params [Width/Height] not available`. The generator now parses the **raw file dimensions** itself (PNG IHDR / JPEG SOF markers, unit-tested) and, when registration is rejected, **retries once with the raw dimensions**; the console logs the successful switch. Decode failures also fall back to the raw dimensions instead of aborting.
- **Compshare API errors echo the parameters that were actually sent** (`已发送参数：object_key=… file_size=… width=… height=…`), so a rejection states what the server received instead of leaving the payload to guesswork.

## [0.18.3] — 2026-10-18

### Fixed
- **Reference-image uploads on Compshare rejected mismatched encodings up front**: `Params [Width/Height] not available` came from the asset-registration step, where the platform parses the uploaded file to verify its pixel size. Files whose real encoding did not match their extension (AVIF/HEIC renamed to `.jpg`, common from chat apps and cloud drives) are now detected by **magic-byte sniffing** and rejected with an actionable message (convert to JPG/PNG) instead of a platform-side puzzle. Declared MIME now always matches the actual bytes.
- **Task-API errors name the failing step**: every Compshare error now carries method + path (e.g. `优云图片 API POST /image/v1/tasks 失败：…`), so a failure points at the exact stage instead of a bare gateway message.
- **Provider "Extended params (JSON)" field is visible for every video vendor**: the field was gated on an `openai`/`seedance` whitelist, so a MiniMax H3 (V2) provider showed no place to put `use_context_ir` / `mute_audio` / `skill_id`.

### Changed
- **Character-sheet prompt formalized as the proven six-block structure** (built-in creation skills): 【总起】layout/background/style + all-panels-identical → 【身份锚】reference photos are the only source of identity, ignore temporary accessories in them → 【主体】quantified build with explicit negative exclusions → 【三视图 /* must-have */】→ 【右侧窄栏】face close-up / accessory panel / 6 expressions in two rows, each block drawn exactly once in the whole sheet → 【文字规则 + 画面白名单】≤3-character labels only, plus an anti-hallucination whitelist ("only this character and the panels above; no people, no other animals, no instruments, no watermark"). The studio skill summary mirrors it.

## [0.18.2] — 2026-10-18

### Added
- **Per-node manual extra params**: image and video generation nodes get a dedicated "Extended params (JSON)" field; node-level parameters merge over provider-level extras (node wins). MiniMax H3's `use_context_ir` / `mute_audio` / `skill_id` belong here.
- **Asset re-import script** (`scripts/reimport-assets.mjs`): standalone, idempotent recovery for data directories whose asset index was missed by the one-shot v1→v2 migration (e.g. `canvas.meta.json` absent or empty at first database creation — exactly the "nodes are there, assets are gone" report). Scans folder-by-folder without needing the manifest; project docs missing locally are restored from `project.json` mirrors; records created after 0.18 (already CAS-backed) are never overwritten.

### Fixed
- **Fetch proxy deduplicated forwarded headers** (lowercase normalization): a client-sent `Content-Type` plus the proxy's defaulting `content-type` were forwarded as two headers, which strict gateways reject with `400 Content-Type must be application/json` (observed on Compshare's task API). This removes the same latent risk for every vendor routed through the proxy.
- **Compshare image hosts auto-route to the task API**: an `*.compshare.cn` base URL configured with the OpenAI-compatible style used to 401 (`invalid api key`) because that gateway has no such surface; it now always uses the task API regardless of the configured style. Pasted API keys are trimmed (stray whitespace/newlines used to break auth).
- **Settings changes refresh the canvas immediately**: node model dropdowns and star defaults kept a stale list until an unrelated re-render happened.
- **Node history strips follow asset deletion**: deleting an asset sweeps its entries from every node's generation history (plus stale last-frame references); existing ghost "…" entries self-heal when the node opens — pruning is skipped while the server is unreachable, so valid history is never mistakenly removed.

## [0.18.1] — 2026-10-18

### Fixed
- **Image prompts no longer inject the series bible behind your back** — the effective prompt builder appended the matched entity's full bible description twice (once inside the `[图N]` reference binding, once as a `设定集：…` block) on top of the visible node prompt. Text-rendering image models (Qwen-Image) painted that injected text straight onto the picture (a garbled attribute panel in the corner), story vocabulary leaked in as phantom props (the un-removable violin), and the long text diluted the reference images' control over appearance. Image generation now uses a **light** effective prompt: style line + `[图N]` name bindings + your prompt, nothing else — the reference images are the source of appearance truth. Video generation keeps the full context (video models don't render text, and the bible context helps consistency).
- **Asset-sheet templates go text-free** (built-in creation skills): the sheet layouts no longer ask the model to render attribute panels (name/gender/age lines, costume notes, inscriptions or poems) — long rendered text is guaranteed garbling. Panel text is now limited to ≤4-character labels (panel names / expression names / color names); with reference images connected, the reference appearance is the only source of truth, replicated strictly across every panel.

## [0.18.0] — 2026-10-18

### Added
- **Server-side asset library** (storage architecture change): asset metadata moves from per-browser IndexedDB to a SQLite database (`canvas.db`) inside the data directory — the single source of truth. Every browser, including remote machines reaching the host over a tunnel, now sees the same library. Project documents (nodes/edges/storyboards/setting bible) move into the same database; the old mirror files (`project.json`, `assets.json`, `canvas.meta.json`) are frozen in place as a migration snapshot and no longer written.
- **Content-addressed object store (CAS)**: media files live under `dataRoot/objects/<sha2>/<sha256>` — identical images/videos are stored once (dedup), integrity is hash-verifiable, and content is served by the new `GET /api/object?sha=…` route with immutable caching and Range support (smooth remote video scrubbing). Uploads (`POST /api/object`) hash server-side and dedupe transparently; objects are reference-counted and reclaimed when the last referencing asset is deleted (`objectsGc` maintenance RPC included).
- **Paged, searchable asset panel**: the panel lists assets from the server with keyset pagination (50 per page + load-more) and server-side search — Chinese substring search over names and prompts via an FTS5 trigram index (queries under 3 characters fall back to `LIKE`). Rename, category change and move-between-projects are written through to the server.
- **One-shot v1→v2 migration**: first mount of a data directory auto-imports legacy `assets.json` indexes and project documents (newer-wins by `updatedAt`) into `canvas.db`; legacy media files stay untouched in their old layout with `rel` pointers preserved — zero-risk migration with no file moves. Legacy blobs that never left a browser upload automatically on that browser's next launch.
- **JSON fallback**: hosts without `node:sqlite` (Node < 22.5) fall back to the legacy file storage with the same RPC surface (list emulated, no full-text search) — engine detection never hard-fails the plugin.
- **Migration guide**: [`docs/migration-0.18.md`](docs/migration-0.18.md) covers upgrading the production machine and moving a data directory to a new machine.

### Fixed
- **Assets "disappeared" on other computers**: the library was sourced from per-browser IndexedDB, so any fresh browser showed an empty panel. With the server as the source of truth this class of confusion is gone; the old boot-time full-replace index sync (which could wipe the server index from an empty browser) is removed outright.

### Notes
- Requires the DSH host to run Node ≥ 22.5 (bundled Node 24 satisfies). `node:sqlite` is a core module — no packaging changes, no native dependencies.
- The data directory now **is** the complete data package: copy it to a new machine, point the data root at it, open the canvas — no import step needed. See the migration guide for the exact steps and rollback story.

## [0.17.18] — 2026-10-18

### Added
- **Real-time collision physics for the canvas** — dragging a node now pushes overlapping neighbors away live (all directions get equal treatment, overlapping axis resolved first, cascading up to 4 passes) with no post-release jumping; released positions stick exactly where the collision stopped. Extended to **every size change**: node edge handles (width/height), heightening a text dialog, list resizing and streaming growth — measured on the node root, so every node type is covered (a 260 ms "push everything below" fallback is replaced by the same physical pass).
- **Dialog height memory** — heightening a text dialog with its own bottom-right grip is stored in node data and restored across page switches, project switches and reloads (all prompt fields: generation prompt, scene text, script idea/output, storyboard script/requirements, shot visuals/motion).
- **`canvas-layout` skill** (third built-in skill, agent-facing): canvas layout discipline — one node type per column, strict column order, never overlap, creation rhythm, and `canvas_relayout` for cleanup. Node creation on the host now always appends to the same-type column tail, regardless of which node the edge comes from.

### Fixed
- **A stray dot after the CSS template's closing backtick broke the whole plugin load** (blank unstyled page); fixed, and the render smoke test covers the component tree to catch this class of error.
- **Prompt boxes paint one line past the border**: the highlight overlay behind transparent textareas was not height-locked when the box height was content-driven — the overflowing line stayed fully visible outside the frame. The overlay is now clipped at the rounded box edge and its height is locked to the real textarea height (scroll stays aligned); the focus ring moved to the wrapper so it is not clipped.
- **Storyboard list grip squeezing prompts above**: heightening the shot list on a manually-resized node squeezed the prompt fields above it. Node height now grows together with the list; releasing the grip heals any historical squeeze to the natural content height. The prompt grip previously did nothing inside manually-resized nodes — its drag delta now converts into node height growth. Prompt fields are exempt from flex shrinking in manual-height mode (they keep a readable height; short overflow just clips below).
- **Half-clipped last line at the bottom of prompt boxes** (trailing-newline line-box compensation for the highlight overlay) plus scroll sync after value changes; the remaining plain textareas moved onto the highlight layer so every text surface behaves identically.
- **Mention glyphs misaligned with the caret**: bold mention highlight changed font metrics between the overlay and the transparent textarea — dropped bold (color only); hidden the overlay scrollbar gutter width mismatch.
- **Unclosed `@Name` mentions auto-repaired** against names known from the project at generation time (models often drop the closing `@` at sentence end), producing stray delimiters in prompts and asset matching; the studio skill's mention section rewritten to the `@Name@` double-at syntax. `@Name@` highlighting is now uniform on every text surface.

## [0.17.17] — 2026-10-17

### Added
- **Professional asset-sheet layouts** replace the simple three-view prompts (methodology added to the built-in creation skills, served live):
  - **Character sheet** (16:9): info panel (name/gender/age/identity/personality/palette) + dominant full-body illustration + facial features (front & profile close-ups with annotations) + costume notes + a 2×3 detail-crop grid (each captioned) + a 2×5 expression grid (per-cell labels); the character must look identical across every panel.
  - **Prop sheet (orientation free)**: title + category subtitle, hero shot at 45° with atmosphere, material/part detail crops, side view, and 3–5 named color swatches — horizontal or vertical chosen by the prop's traits (long items favor vertical; composite/scene-like props favor horizontal); the layout logic stays the same either way.
  - **Scene sheet (main view + surrounding panels)**: one dominant establishing view of the scene, surrounded by 3–6 supporting panels — other angles, other times of day/weather, and detail crops (landmark/entry/texture/prop placement), each captioned. Replaces the old equal-sized triptych, which lost the scene's overall sense; the arrangement is a loose reference, not a strict grid, and light/weather must stay consistent with the main view.
- Simple three-view prompts are explicitly disallowed for asset images — they don't carry enough information to sustain character consistency in downstream video generation.

## [0.17.16] — 2026-10-17

### Added
- **Image generation carries reference images in the standard mode**: `/images/generations` no longer ignores reference images — connected refs and `@Name@`-matched assets are sent as an `image` array of data-URLs (the mainstream convention for multi-reference image APIs, in the same order as the `[图N]` binding lines). Vendors that do not support the field report it explicitly.
- **Image requests default to `watermark: false`** on both `/images/generations` and the multipart `/images/edits` path (many image vendors default to watermarked output); extra params can override.

### Fixed
- The edits (multipart) path appended the whole reference meta object instead of the image blob — such requests would have sent `"[object Object]"` as file content.

## [0.17.15] — 2026-10-17

### Added
- **Per-vendor video API audit against official docs** (latest models per vendor): every adapter's parameters, endpoints, result fields and status semantics re-verified from vendor documentation/official SDKs, with fixes listed below.
- **Video vendor routing fixed end-to-end**: the explicitly chosen vendor format now reaches the request layer (previously dropped during settings flattening, falling back to model-name/URL guessing); vendor auto-detection additionally matches by model id (e.g. `wan3.0-video`, `kling-v2.6`, `MiniMax-Hailuo-02`); shared `vendorBase()` normalization strips gateway-style `/v1` suffixes for all runners; every runner accepts **extra params** (top-level override + `parameters` deep-merge) as an escape hatch for gateway quirks.
- **Duration is never silently truncated**: the requested duration is passed through to every vendor (Kling/MiniMax/Vidu/Runway/Luma/PixVerse/Seedance/Wan) — unsupported values surface as explicit API errors instead of hidden clamping; the duration selector extends to 30s (Wan 3.0) and keeps out-of-list values (e.g. a 32s storyboard total).
- **Post-generation self-check**: the real output resolution/duration is probed after each video; mismatches with the node's ratio/duration settings show a visible warning on the node (e.g. "vendor returned 1080×1920 portrait, 16:9 requested").
- **`canvas_relayout` tool**: one call re-arranges a canvas by rows — horizontal data flow decides columns, vertical links (continuity `prev`, first-frame `frame`) stay in the same column, each row is one horizontal group (e.g. "scene N text ↔ scene N storyboard"), with collision avoidance.
- **Node layout on creation**: realistic per-type height estimates (image/video/storyboard cards), brand-new types start their own column, and a minimum-gap collision check prevents overlapping cards.
- **Click-to-front**: clicking a node (or dragging a multi-selection) raises it above all others; the z-order persists.
- **Help & feedback**: a toolbar button and a settings entry open a compact dialog with the GitHub issue link and a WeChat contact QR (shipped inside the plugin via a whitelisted static-asset route).
- **API key reveal toggle**: key fields are masked by default with an eye button to show the plaintext.
- **Short-drama methodology distilled** into the built-in creation skills (canvas-craft/studio): a shot-pacing spectrum (narrative 2–4s, rapid conflict 0.3–0.8s, reversal 1–2s, emotional long take ≥5s — durations may use one decimal and must never be uniform), an emotion→shot-size map, the four-beat scene arc, the six-component director brief and a pitfalls checklist.

### Fixed
- **Wan 3.0**: the adapter used 2.x-era parameters — `size` does not exist in the 3.0 API and `img_url` was ignored, so resolution/ratio were silently defaulted (portrait 1080p) and reference images never reached the model. Now uses the official `parameters.resolution/ratio/duration` (+ stable `watermark:false`, `prompt_extend:true`) and `input.media[]` (`first_frame` / up to 10 `reference_image`, Base64) with the correct gateway prefix handling.
- **Kling**: default model id corrected to the current REST format (`kling-v2-6`; `kling-v2.5-turbo-t2v`-style ids were invalid); `cfg_scale` no longer sent unconditionally (unsupported by v2.x models); new plural `/v1/videos/*` endpoints with singular fallback; result read from `data.task_result.videos[]`; `aspect_ratio` only for text-to-video.
- **MiniMax**: `duration` is an integer (a string was sent); result download is two-step (`file_id` → `/v1/files/retrieve` → `download_url`, 1h validity); `resolution` passes through (512P/720P/768P/1080P).
- **Vidu**: default model `viduq3-pro`; polling hits `/ent/v2/tasks/{id}/creations` (the old path always 404'd); result read from `creations[].url`; `aspect_ratio` only for text-to-video; resolution passes through.
- **PixVerse**: endpoints corrected to the current `/openapi/v2/video/{text,img}/generate`; image-to-video uploads the first frame (`img_id`, the API does not accept Base64); status semantics corrected (1=done, 5/9/10=processing, **7/8=failed** — previously treated as "still running", which could hang forever); default model v6.
- **Runway**: text-to-video defaults to `gen4.5` (`gen4_turbo` is image-to-video only); model passes through (the API now hosts per-model schemas).
- **Veo**: `durationSeconds` was never sent (the official field name; not `duration`); `resolution` passes through; default model `veo-3.1-generate-preview`.
- **Luma**: `aspect_ratio` and resolution pass through (official enums).
- **Seedance (Ark)**: `generate_audio` no longer forced to `false` when the checkbox is unchecked — the vendor default (`true`) applies unless explicitly enabled.
- **Stability**: marked offline — the current official API no longer exposes any video endpoint; the adapter remains only for legacy configs and reports the 404 clearly.
- **Storyboard duration**: the hard 15s cap and automatic longest-shot trimming are removed — shot durations follow the scene's content (pacing spectrum above), and unsupported durations surface as explicit video-API errors instead of silent re-timing.
- **Host/client sync**: an incoming copy without shots no longer wipes an existing storyboard's generated shots (both merge sides protect them) — regenerating the next scene could previously erase the previous scene's results.
- **Consistency warnings use the `@Name@` lexer on the host too**: the old scanner treated every closing `@` as the start of a new mention and reported prose between references as unregistered assets.
- **`canvas_connect` picks the semantic default port** for storyboards (script/text → `script`, storyboard → `prev`) instead of the first input port.
- **Project deletion could crash the host on non-ASCII paths**: `fs.rmSync(recursive)` aborts the Node process on Chinese-named directories — replaced by a safe recursive delete.
- Wiring is drawn as straight lines when ports are vertically aligned; the storyboard `tail`/`prev` dots are centred on their anchors.

## [0.17.14] — 2026-10-15

### Added
- **`@Name@` asset references (double-@ syntax)**: the closing `@` is an explicit terminator, so adjacent or glued references can never swallow the following text. The UI hides both `@`s and renders the name in **bold blue** in prompt fields, text nodes and storyboard shots (typing `@Name@` turns blue as you finish it). Unknown `@Name@` is still reported by the consistency check so the asset gets registered.
- **Asset anchoring in scripts and scene texts**: generated episode scripts wrap every character/scene/prop name as `@Name@`, and the storyboard contract carries those anchors into shots — downstream generation always knows which words are assets.
- **`canvas_relayout` tool**: one call re-arranges a canvas by rows — horizontal data flow decides columns (`text → storyboard → video`), vertical links (continuity `prev`, first-frame `frame`) stay in the same column, each row is one horizontal group (e.g. "scene N text ↔ scene N storyboard"), with collision avoidance and a minimum gap.
- **Help & feedback entry**: a toolbar button plus a one-line settings entry open a compact dialog with the GitHub issue link and the WeChat group QR code (shipped inside the plugin and served through a whitelisted static-asset route).
- **API key reveal toggle**: key fields are masked by default; an eye button shows the plaintext for verification.
- Node auto-layout on the agent side: new nodes land in type-based rows with collision detection (28px minimum gap), so freshly created cards never overlap; the storyboard shot list is drag-resizable and the node grows downward with it.

### Fixed
- **Project deletion could crash the host on non-ASCII paths**: `fs.rmSync(recursive)` aborts the Node process (STATUS_STACK_BUFFER_OVERRUN) on Chinese-named directories — deleting a project could take DSH down with it. Replaced by a safe recursive delete (readdir + unlink/rmdir).
- **Generated shots are no longer lost to stale sync**: both the client merge and the host merge keep an existing storyboard's shots when an incoming copy has none (previously generating the next scene could silently wipe the previous scene's shots).
- **Storyboard wiring picks the right port**: `canvas_connect` without an explicit target port now chooses by semantics (script/text → `script`, storyboard → `prev`) instead of blindly using the first input port.
- **Consistency warnings use the `@Name@` lexer on both sides**: the previous host-side scanner treated every closing `@` as the start of a new mention and reported prose between references as unregistered assets (and bible updates recomputed those bogus entries).
- Continuity wires are drawn as straight lines when the two ports are vertically aligned, and the storyboard `tail` / `prev` dots are centred on their anchors so wires leave the dot centre.
- Packaged files: `assets/support/*` now ships with the plugin, so the WeChat QR is visible for every install (not just the author's machine).

## [0.17.13] — 2026-10-14

### Fixed
- package.json is published without a UTF-8 BOM (the BOM broke DSH plugin validation on install).

## [0.17.12] — 2026-10-14

### Added
- **Storyboard continuity ports**: storyboard nodes now expose a `prev` input ("continue previous tail", top) and a `tail` output (bottom). Wire `prev storyboard.tail → next.prev` and generation injects the previous tail shot as a **hard continuity constraint** — shot 1 continues from the previous last action, overlap ≤ 0.2s, ambient background sound continuous, no re-establishing shots. Wiring is the only continuity source (never name/position matching).
- **Per-node chaining mode** on video nodes with a first-frame input: **Fuse with refs** (default — tail frame becomes reference image #1), **Hard first frame** (true `first_frame` param, drops refs — the gateway forbids mixing), **Ignore frame**.
- **Lip-sync hard rules**: storyboard shots carrying dialogue must show the speaker talking on screen (close/medium-close, face visible, never back-to-camera or off-frame); video prompts state "spoken on screen, lip-synced" per dialogue shot — no more voice-over with closed mouths.
- **Video vendor preset layer**: pick a vendor format in settings, then only Base URL + model id — endpoints, auth, parameter shapes, polling and result download are handled per vendor. Adapters: **Kling** (AK:SK → auto-signed JWT), **Alibaba Wan/DashScope**, **MiniMax Hailuo**, **Vidu**, **Runway Gen-4**, **Google Veo (Gemini API)**, **Luma**, **PixVerse**, **Stability AI**, plus the existing **Volcengine Ark Seedance** and **OpenAI-compatible** formats. Legacy configs auto-detect.
- **Video-asset nodes gain a `last` output** with automatic tail-frame extraction for imported/uploaded videos; every node holding a video (generated or imported) auto-extracts its tail frame.
- Resilient video task polling: gateway blips (5xx/timeouts/network) never abort a task — only the task's own terminal state decides; 2h safety window; **task id + query URL persisted on the node** (and surfaced via `canvas_node_status`) so interrupted runs can be recovered.

### Fixed
- First frame and reference images are never mixed in one request (Seedance gateways reject the combination) — across all protocols.
- Dialogue and SFX annotations now flow through shots into video prompts, the storyboard UI, saved assets and `canvas_node_status` (previously dropped on the way to the video prompt).
- Asset index sync keeps file-backed records (manual data-root registrations survive); saving the same data-root no longer rebuilds the index; "Import from data root" is always clickable.
- Agent-side storyboard writes keep the `sfx` field; continuity notes are no longer duplicated across fallback protocols.
- UI: lightbox viewer for images/videos, selectable+copyable storyboard shots with a drag-resize shot list, video history thumbnails show real covers.

## [0.17.11] — 2026-10-14

### Script → Scene → Storyboard → Video pipeline (macro rework)
- **Script nodes produce one episode** (60–120s of screen time, 4–10 scenes) and every scene must start with its own `【场N】name (location · time)` header — the machine-readable hook for scene expansion.
- **New "Expand to scenes" action on script nodes**: splits the episode by scene headers into per-scene text nodes + storyboard nodes, wired automatically (text → storyboard, one storyboard per 10–15s scene). The agent side replicates the same split via `canvas_create_node` / `canvas_write_node` / `canvas_connect`.
- **Storyboard contract hardened**: full coverage of the wired scene (every action and every line lands in a shot — no summarizing, no cherry-picking); per-shot `dialogue` annotations (verbatim lines with roles — feeds voice-reference extraction); shot count follows the actual action beats (auto mode — never a fixed number); total duration hard-capped to **≤ 15s** (longest shots auto-trimmed after parse).
- Capacity warnings: a wired source far beyond one storyboard's 10–15s budget raises a warning the agent can see on `canvas_node_status`.
- Skill rewritten around the macro flow: episode script → expand to scenes → per-scene multi-shot video → tail-frame chaining; hard rules against wiring a whole episode into one storyboard or manufacturing per-shot image/video nodes.

### Video API compatibility
- **OpenAI-style video endpoints** (JUAI and similar aggregators): URL normalization (bare domain / `/v1` / full endpoint all work), lowercase resolution, first-frame mode forces `ratio: "adaptive"`, references sent as `{url, role}` objects, first-frame and references never mixed, result extracted from `metadata.url`, terminal "completed without URL" reported instead of polling forever.
- **Automatic fallback chain** when the primary submit is rejected: flat format → Seedance-native `content[]` format (poll `GET /v1/video/query?task_id=`) → Sora-style `/v1/videos` (submit / poll / authenticated content download). Covers gateways such as RelayRouter where `/v1/video/generations` does not serve seedance channels.
- Video errors now include the actual request URL and a response excerpt.

### Model configuration: providers + models
- Image/video API settings restructured into **two levels** — a provider (URL/key configured once) with multiple models underneath; star one model as the **default route**.
- Node model dropdowns list configured models directly (the "default config" pseudo-entry is gone): an empty selection routes to the starred default; nothing configured fails the run with a clear error instead of silently generating a demo.
- **Extra params (JSON)** per provider merge vendor-specific keys (`watermark`, `prompt_extend`, `output_format`, `seed`, …) into the request body last — switching vendors needs no code changes.
- Optional video params: `generate_audio` (sent only when checked) and `output_format` (sent only when filled).
- Video downloads retry once with credentials on 401/403 (authenticated content proxies).
- Legacy flat API configs and node-level api ids migrate automatically.

### Voice consistency
- **Character voice references**: audio assets bound to a character (named `角色-<name> 声音` or linked to the bible entry) are attached automatically as `audios[]` (`reference_audio`) to video requests; sync audio is force-enabled when present.
- **"Extract voice reference"** on video/finalcut nodes: type a character name — every dialogue window is located automatically from the storyboard `dialogue` annotations (shot-duration-proportional mapping onto the real timeline with breath padding) and merged into **one WAV** reference file (WebAudio decoding, no external dependencies). Manual time-range mode stays as a fallback.

### Fixes
- Agent-side node deletions are no longer resurrected by stale client pushes: the sync "live canvas wins" exemption now applies only to nodes the user deleted in the UI and restored via undo.
- Storyboard JSON containing unescaped straight quotes inside string values (e.g. `喷漆"拆"字`) is repaired (state-machine scan → 「」) and re-parsed instead of failing the whole generation.
- Reference images and first frames are downscaled (1024px JPEG) before embedding — multi-reference requests no longer exceed the 16MB proxy limit (HTTP 413).

## [0.17.10] — 2026-10-13

### Added
- **Consistency-warning loop closed.** `canvas_node_status` now returns `warnings` for storyboard nodes — the list of entities that appear in shots but are **not registered** in the series bible or **registered with an empty description** (including `@mentions` found in the visual/motion text, which the shot arrays alone could miss). The agent side reads this list and fills every entry via `canvas_update_bible` (names verbatim, workable descriptions) — a hard rule in the skill.
- Warnings **recompute automatically** whenever they could go stale: shots written, the bible updated from the chat side, or the client pushing bible changes — so a filled bible clears the outdated warnings within seconds.
- **Asset categories are now derived from the naming convention** (`角色-`/`场景-`/`道具-`/`剧本-`/`分镜-` prefixes → character/scene/prop/script/storyboard) when `@mentions` don't resolve — generated assets no longer fall into "General" just because the prompt skipped the `@` syntax.
- Startup self-check **re-categorizes legacy assets** that sit in "General" but follow the naming convention (toast reports the count; manually-set categories are never touched).

### Fixed
- Consistency-check ordering: missing entries are auto-registered (with empty descriptions) **before** the check runs, so the warnings no longer flag entities that were just auto-registered; duplicates removed.

## [0.17.9] — 2026-10-12

### Changed
- Data-root card simplified: the **"Migrate existing assets" button was removed** — migration is now fully automatic (on data-root set and on every startup, browser-stored assets are moved to the data root, then the `assets.json` index re-aligns; a toast reports the count).
- "Open folder" and "Import from data root" merged into a single row (with an ⓘ hover hint).

## [0.17.8] — 2026-10-12

### Changed
- Settings redesigned. Card order: Language → Data root → Craft → Skills → Text model → Image → Video → TTS (all model cards grouped together).
- **Text model card selects the model only** — maxTokens/temperature inputs removed; generation parameters always come from Harness (legacy stored values are stripped and never sent).
- **Skills** split into their own card.
- Long explanations moved into ⓘ hover tooltips; the UI keeps controls only.

### Craft (ArtCraft) bridge
- Craft card is **collapsible** (collapsed by default with an "n/n ready" summary; toggle at the far right).
- Status lights now render the **whole Craft family dynamically** — every bin reported by ArtCraft `/status` (12 crafts) gets a light, instead of a hardcoded three.
- Craft file paths unified under the **canvas data root**: FilmCraft timeline/SRT/project/MP4 output, PhotoCraft graded images and synced media all live in `projects/<project>/craft/…` next to scripts, storyboards and assets.
- The separate ArtCraft data-root wording was removed; when ArtCraft's own root differs from the canvas data root, the card shows a red mismatch warning.

## [0.17.7] — 2026-10-12

### Fixed
- **Image APIs finally work from the browser.** All third-party gateway calls are proxied through the Harness host (`/api/fetch-proxy`) — browser-direct calls were blocked by CORS (`Failed to fetch`) because image gateways don't return CORS headers. Covers image `generations`, multi-reference `edits` (multipart), signed-URL downloads, generic video submit+poll, the **Seedance official protocol**, video downloads and TTS. Status codes, bodies and content-types are relayed verbatim; upstream timeouts surface as readable "timeout" errors.

### Added
- **The data root is now a portable data package.** Project folders use the **project name** (project ids stay as logical paths, mapped by the host at the I/O boundary). Each project folder mirrors `project.json` (nodes/edges/**series bible incl. assetIds bindings**) and `assets.json` (asset metadata index) plus media files, updated in real time. `canvas.meta.json` keeps the id→folder map.
- **One-click import**: copy the data folder to a new machine → set it as data root → *Import from data root* restores projects, nodes, bible and assets (newest-wins by `updatedAt`).
- Asset names follow **"node name + time"** everywhere (scripts, storyboards, images, videos, final cuts).
- **Asset deletion syncs the data root** (file deleted via the id→folder mapping + index entry removed).
- The asset index **self-heals**: the startup full sync replaces `assets.json` from the browser library (single source of truth; empty projects align too).
- Storyboard nodes got a manual **"Save as asset"** button; text assets (script/storyboard markdown) persist to the data root.

### Fixed
- **Project deletion resurrection**: deleting no longer pushes the doomed document to the host first (race), and the host now keeps a long-lived deletion tombstone — late `projectsPut`s (debounce races, startup snapshot pushes) are rejected. Importing a project clears its tombstone.
- Bible merging no longer drops `assetIds` bindings; `projectsPut` writes atomically and mirrors to the data root.

## [0.17.6] — 2026-10-12

### Changed
- **Storyboard workflow corrected: one storyboard = one multi-shot generation.** Expanding a storyboard wires it to a *single* video node; all shots (order + per-shot duration) are composed into one multi-shot prompt and the video model renders the whole clip in one call — no per-shot videos, no stitching seams.
- AI storyboard contract rewritten: 2–5 s per shot (one continuous action beat), durations sum to the target length (15 s ≈ 4–7 shots); default shot count 12 → 6; 12 s/15 s added to video durations; agent-created video nodes auto-connect to the latest storyboard.

### Fixed
- Node-deletion resurrection (three rounds): marquee/single-click/Delete-key deletions now record tombstones and push immediately; tombstones respect the in-memory canvas; undo/redo reconciles tombstones.
- Asset-delete confirmation dialog white screen; panel error boundary (crashes show a copyable card instead).

### Added
- Asset library: project scope filter with a **General project**, assets can move between projects, binding dialog v2; storyboards auto-register missing bible entries.

## [0.17.5] — skipped (unreleased)

## [0.17.4] — 2026-10-11

### Added
- **Data root**: images/videos persist to any disk you choose, organized in per-project folders (no longer filling browser IndexedDB on C:); served with HTTP Range support for video seeking.
- System **folder picker** for the data root (no more hand-typing paths).

## [0.17.3] — 2026-10-11

### Fixed
- "Check update" silently doing nothing on old hosts (mixed-version `behind=0` combination).

### Changed
- **Real update install** ("Go upgrade" actually installs): runs `pnpm add <pkg>@<exact>` inside the owning profile, syncs the bundle list, then only *prompts* to restart Harness — never auto-restarts. Graceful degradation to guidance-only when in link/dev mode, pnpm is missing, or the install fails; a supply-chain cooldown is applied automatically.

## [0.17.2] — 2026-10-11

### Added
- **Unified update check** (independent of install mode): latest version = npm registry `latest`; local version = the running `package.json`; outdated → banner with a "Go upgrade" action. Update semantics never compare hashes and never auto-refresh.
- Release tooling: GitHub Actions publish workflow (npm Trusted Publishing / OIDC) and bilingual publishing notes.

### Changed
- Update button shows a text badge instead of a version number; hovering shows the running version.

## [0.17.1] — 2026-10-10

### Fixed
- Black screen caused by a v0.17.0 toolbar scope error.
- Version badge now prefers the actually-running version.

## [0.17.0] — 2026-10-10

### Added
- In-plugin **update check + one-click update**.
- GitHub Actions publish workflow (npm Trusted Publishing / OIDC — no npm token anywhere).

### Changed
- Package renamed to the scoped `@ninkch/dsh-infinite-canvas`.

## [0.16.0] — 2026-10-10

First public npm release: infinite-canvas studio for DeepSeek Harness — script/storyboard/image-gen/video-gen/final-cut nodes, series-bible consistency, `@mention` reference binding, multi-config generation backends (OpenAI-compatible images, generic + Seedance video, TTS), demo mode, ArtCraft (PhotoCraft/FilmCraft/EffectCraft) bridge.
