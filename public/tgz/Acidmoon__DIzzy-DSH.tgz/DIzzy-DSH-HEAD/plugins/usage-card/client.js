/**
 * dizzy-dsh-usage-card Client 半区 —— 会话视图「用量」Tab
 *
 * 本文件是 client bundle(ModuleLoader 工厂格式),由 client-modules 按
 * 包名扫描 dsh.client 声明后自动加载,无需构建链 —— factory 内 require()
 * 由平台 seed 提供(react 等)。
 *
 * 挂载:conversation.view 视图环(list,会话域)。宿主 ui-conversation
 * 把每个 entry 投影为会话页头的一个 Tab(label 即 Tab 文本),经
 * renderSlot(..., { only: activeId }) 一次只渲染激活视图;chat order 0、
 * trajectory order 10,本视图 order 20,列在「轨迹」右侧。选中状态存于
 * 宿主每会话 store(persist: dsh.conversation.chat),刷新页面后保持;
 * 插件卸载后宿主自动回退 chat 视图。
 *
 * 视图结构(数据:GET /dizzy/usage?month=YYYY-MM,Host 聚合本地会话日志):
 *   - 页头:标题 + 月份导航(‹ › ±1 月;点月份开年/12 月格选择器,
 *     Esc / 点外侧关闭)+ 手动刷新;每 60s 自动重取当前月份
 *   - 统计卡:本月合计 / 活跃天数 / 活跃日均 / 峰值日
 *   - 月度热力图 + 近 7 天用量曲线(平滑贝塞尔过点):热力图周一起始,
 *     行=周一~周日、列=周,DeepSeek 蓝阶四档,格内日期数字,今日描边+
 *     脉冲;格悬浮弹窗显示输入(未命中)/输入(命中缓存)/输出。曲线按鼠标横坐标吸附
 *     最近一天,竖线跟随鼠标 X,弹窗跟鼠标并避让视口边缘
 *   - 今日明细:按模型分行(provider/model 归属),条形统一蓝色底,
 *     内部分三段(输入未命中 / 输入命中缓存 / 输出),悬浮显示分项
 *   - 底部:北京时间峰谷时钟(高峰 9:00-12:00 / 14:00-18:00 红,
 *     空闲绿,进入高峰前 30 分钟渐变)
 *
 * 兼容:Host 未升级(响应无 detail 字段)时,热力图/统计/曲线照常
 * (曲线退化为查看月数据),分项弹窗只显总量,今日明细显示重启提示。
 *
 * 外观吃宿主 --dsw-* token(明暗主题跟随)。静态 client bundle 运行在
 * 真实浏览器环境(非动态守卫),fetch、setInterval 等全局可用;数据经
 * host 路由获取,浏览器不接触任何凭据。
 */
window.__ModuleLoader__.load({
  id: 'dizzy-dsh-usage-card',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' })

    const React = require('react')

    // DeepSeek 官方现行模型名 + 仍在用的历史名(与 Host 的 OFFICIAL_PRICES /
    // OFFICIAL_PRICE_ALIASES 对齐;只用于价格来源提示文案)。
    const OFFICIAL_MODEL_NAMES = [
      'deepseek-flash',
      'deepseek-v4-pro',
      'deepseek-v4-flash',
      'deepseek-v4-flash-vision-exp',
      'deepseek-v4-pro-0813',
      'deepseek-v3.2',
    ]

    const apply = (ctx) => {
      const slots = ctx.get('slots')
      if (slots === undefined) return

      const style = document.createElement('style')
      style.textContent = [
        // ── 视图骨架:吃宿主 token,明暗主题跟随 ─────────────────
        '.dsh-usage-view{--dsh-usage-lv0:transparent;--dsh-usage-lv1:var(--dsw-static-deepseek-200);--dsh-usage-lv2:var(--dsw-static-deepseek-300);--dsh-usage-lv3:var(--dsw-static-deepseek-400);--dsh-usage-lv4:var(--dsw-static-deepseek-500);--dsh-usage-seg-in:var(--dsw-static-deepseek-500);--dsh-usage-seg-cache:#2dd4bf;--dsh-usage-seg-out:#f59e0b;box-sizing:border-box;width:100%;max-width:860px;margin:0 auto;padding:28px 24px 64px;display:flex;flex-direction:column;gap:16px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family,ui-sans-serif,system-ui,sans-serif)}',
        'body[data-ds-dark-theme] .dsh-usage-view{--dsh-usage-lv1:var(--dsw-static-deepseek-600);--dsh-usage-lv2:var(--dsw-static-deepseek-500);--dsh-usage-lv3:var(--dsw-static-deepseek-400);--dsh-usage-lv4:var(--dsw-static-deepseek-300);--dsh-usage-seg-in:var(--dsw-static-deepseek-400);--dsh-usage-seg-cache:#5eead4;--dsh-usage-seg-out:#fbbf24}',
        // ── 页头:标题 + 月份导航 + 刷新 ──────────────────────
        '.dsh-usage-topbar{display:flex;align-items:flex-end;justify-content:space-between;gap:16px;flex-wrap:wrap}',
        '.dsh-usage-title{margin:0;font-size:20px;font-weight:600;line-height:28px;color:var(--dsw-alias-label-primary)}',
        '.dsh-usage-subtitle{margin-top:4px;font-size:12px;line-height:16px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-nav{position:relative;display:inline-flex;align-items:center;gap:2px;font-variant-numeric:tabular-nums}',
        '.dsh-usage-btn{display:inline-flex;align-items:center;justify-content:center;min-width:30px;min-height:30px;padding:0 6px;border:0;border-radius:8px;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:13px;line-height:1;cursor:pointer;transition:background var(--ds-transition-duration-fast,0.1s) var(--ds-ease-in-out,ease),color var(--ds-transition-duration-fast,0.1s) var(--ds-ease-in-out,ease)}',
        '.dsh-usage-btn:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}',
        '.dsh-usage-btn:focus-visible,.dsh-usage-cell:focus-visible,.dsh-usage-mbtn:focus-visible,.dsh-usage-row:focus-visible{outline:2px solid var(--dsw-static-deepseek-500);outline-offset:1px}',
        '.dsh-usage-month{min-width:92px;font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary)}',
        '.dsh-usage-refresh.is-spinning svg{animation:dsh-usage-spin .9s linear infinite}',
        '@keyframes dsh-usage-spin{to{transform:rotate(360deg)}}',
        // ── 月份选择器浮层 ──────────────────────────────────
        '.dsh-usage-pop{position:absolute;right:0;top:34px;z-index:12;width:196px;padding:10px;border-radius:10px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-overlay);box-shadow:0 8px 24px var(--dsw-alias-bg-mask-2)}',
        '.dsh-usage-yrow{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}',
        '.dsh-usage-yrow span{font-size:13px;font-weight:600;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-primary)}',
        '.dsh-usage-mgrid{display:grid;grid-template-columns:repeat(4,1fr);gap:4px}',
        '.dsh-usage-mbtn{height:28px;border:0;border-radius:6px;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;cursor:pointer}',
        '.dsh-usage-mbtn:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}',
        '.dsh-usage-mbtn.is-on{background:var(--dsw-alias-state-business-tertiary);color:var(--dsw-alias-state-business-primary);font-weight:600}',
        '.dsh-usage-now{display:block;width:100%;margin-top:8px;height:28px;border:0;border-radius:6px;background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;cursor:pointer}',
        // ── 统计卡 ─────────────────────────────────────────
        '.dsh-usage-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}',
        '.dsh-usage-stat{box-sizing:border-box;padding:14px 16px;border-radius:14px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1)}',
        '.dsh-usage-stat-label{font-size:12px;line-height:16px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-stat-value{margin-top:6px;font-size:22px;font-weight:600;letter-spacing:-.02em;line-height:1.15;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-primary)}',
        '.dsh-usage-stat-sub{margin-top:4px;font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-skel{display:inline-block;height:22px;width:72px;border-radius:6px;background:var(--dsw-alias-bg-skeleton);animation:dsh-usage-pulse 1.2s ease-in-out infinite}',
        '@keyframes dsh-usage-pulse{0%,100%{opacity:1}50%{opacity:.4}}',
        '@media (prefers-reduced-motion:reduce){.dsh-usage-skel{animation:none}.dsh-usage-refresh.is-spinning svg{animation:none}.dsh-usage-cell{transition:none}.dsh-usage-cell.is-today:after{animation:none}}',
        // ── 面板(热力图 / 明细共用容器)──────────────────────
        '.dsh-usage-panel{box-sizing:border-box;padding:18px 20px;border-radius:16px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1)}',
        '.dsh-usage-panel-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:14px}',
        '.dsh-usage-panel-title{font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary)}',
        '.dsh-usage-panel-side{font-size:12px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary));font-variant-numeric:tabular-nums}',
        '.dsh-usage-legend{display:flex;align-items:center;gap:5px;font-size:11px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-swatch{width:12px;height:12px;border-radius:3px;background:var(--dsh-usage-lv0)}',
        '.dsh-usage-swatch.lv1{background:var(--dsh-usage-lv1)}',
        '.dsh-usage-swatch.lv2{background:var(--dsh-usage-lv2)}',
        '.dsh-usage-swatch.lv3{background:var(--dsh-usage-lv3)}',
        '.dsh-usage-swatch.lv4{background:var(--dsh-usage-lv4)}',
        // ── 热力图 + 近 7 天曲线 并排 ───────────────────────
        '.dsh-usage-heatflex{display:flex;gap:28px;flex-wrap:wrap}',
        '.dsh-usage-heat{flex:none;display:flex;gap:10px;align-items:stretch}',
        '.dsh-usage-wd{display:grid;grid-template-rows:repeat(7,34px);gap:6px}',
        '.dsh-usage-wdl{display:flex;align-items:center;justify-content:center;font-size:11px;line-height:1;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary));user-select:none}',
        '.dsh-usage-cells{display:grid;grid-template-rows:repeat(7,34px);gap:6px}',
        '.dsh-usage-cell{position:relative;box-sizing:border-box;width:34px;height:34px;padding:0;border:0;border-radius:6px;background:transparent;cursor:default;font:inherit;font-size:11px;line-height:1;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary));transition:transform .16s cubic-bezier(.2,.8,.3,1.4),box-shadow .16s ease}',
        '.dsh-usage-cell.is-void{visibility:hidden;pointer-events:none}',
        '.dsh-usage-cell.lv1{background:var(--dsh-usage-lv1);color:#16245c}',
        '.dsh-usage-cell.lv2{background:var(--dsh-usage-lv2);color:#16245c}',
        '.dsh-usage-cell.lv3{background:var(--dsh-usage-lv3);color:#16245c}',
        '.dsh-usage-cell.lv4{background:var(--dsh-usage-lv4);color:#fff}',
        'body[data-ds-dark-theme] .dsh-usage-cell.lv1{color:#fff}',
        'body[data-ds-dark-theme] .dsh-usage-cell.lv2{color:#fff}',
        'body[data-ds-dark-theme] .dsh-usage-cell.lv4{color:#16245c}',
        '.dsh-usage-cell.is-today{outline:1.5px solid var(--dsw-alias-label-primary);outline-offset:1.5px}',
        '.dsh-usage-cell.is-today:after{content:"";position:absolute;inset:0;border-radius:6px;box-shadow:0 0 0 0 color-mix(in srgb,var(--dsw-alias-label-primary) 35%,transparent);animation:dsh-usage-today 2.6s ease-out 1s infinite;pointer-events:none}',
        '@keyframes dsh-usage-today{70%{box-shadow:0 0 0 5px transparent}100%{box-shadow:0 0 0 0 transparent}}',
        '.dsh-usage-cell:hover:not(.is-void){transform:scale(1.12);z-index:3;box-shadow:0 0 12px color-mix(in srgb,currentColor 35%,transparent)}',
        // ── 近 7 天曲线:平滑贝塞尔 + 面积淡填 + 竖线吸附 ─────
        '.dsh-usage-curvebox{flex:1;min-width:280px;display:flex;flex-direction:column}',
        '.dsh-usage-curve-head{display:flex;align-items:baseline;justify-content:space-between;gap:12px;margin-bottom:6px}',
        '.dsh-usage-curve-title{font-size:12px;font-weight:600;color:var(--dsw-alias-label-secondary)}',
        '.dsh-usage-curve-sum{font-size:11px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary));font-variant-numeric:tabular-nums}',
        '.dsh-usage-curve-body{flex:1;display:flex;align-items:center;min-height:0}',
        '.dsh-usage-curve-svg{width:100%;height:auto;display:block;overflow:visible;cursor:crosshair}',
        '.dsh-usage-curve-line{fill:none;stroke:var(--dsw-alias-state-business-primary);stroke-width:2;stroke-linecap:round;pointer-events:none}',
        '.dsh-usage-curve-area{fill:color-mix(in srgb,var(--dsw-alias-state-business-primary) 12%,transparent);pointer-events:none}',
        '.dsh-usage-curve-dot{fill:var(--dsw-alias-bg-layer-1);stroke:var(--dsw-alias-state-business-primary);stroke-width:1.6;pointer-events:none}',
        '.dsh-usage-curve-dot.is-on{fill:var(--dsw-alias-state-business-primary)}',
        '.dsh-usage-curve-rule{stroke:var(--dsw-alias-state-business-primary);stroke-width:1;stroke-dasharray:2 3;opacity:.5;pointer-events:none}',
        '.dsh-usage-curve-x{font-size:10px;fill:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary));font-variant-numeric:tabular-nums;pointer-events:none}',
        '.dsh-usage-curve-hit{fill:transparent;pointer-events:all}',
        // ── 今日明细(分模型):统一蓝底堆叠条 + 数值 ──────────
        '.dsh-usage-rows{display:flex;flex-direction:column;gap:8px}',
        '.dsh-usage-row{display:flex;align-items:center;gap:12px;margin:0;padding:0;border:0;background:transparent;width:100%;text-align:left;font:inherit;cursor:default}',
        '.dsh-usage-rowlabel{flex:none;width:132px;font-size:12px;line-height:18px;color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}',
        '.dsh-usage-track{flex:1;min-width:0;height:10px;border-radius:5px;background:var(--dsw-alias-bg-base)}',
        '.dsh-usage-bar{display:flex;height:100%;border-radius:5px;overflow:hidden;background:var(--dsh-usage-seg-in)}',
        '.dsh-usage-seg{flex:none;height:100%}',
        '.dsh-usage-seg.is-in{background:var(--dsh-usage-seg-in)}',
        '.dsh-usage-seg.is-cache{background:var(--dsh-usage-seg-cache)}',
        '.dsh-usage-seg.is-out{background:var(--dsh-usage-seg-out)}',
        '.dsh-usage-seglg{display:flex;align-items:center;flex-wrap:wrap;gap:10px;margin:0 0 12px;font-size:11px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary));user-select:none}',
        '.dsh-usage-seglg>span{display:inline-flex;align-items:center;gap:4px}',
        '.dsh-usage-segdot{width:8px;height:8px;border-radius:2px;flex:none}',
        '.dsh-usage-segdot.is-in{background:var(--dsh-usage-seg-in)}',
        '.dsh-usage-segdot.is-cache{background:var(--dsh-usage-seg-cache)}',
        '.dsh-usage-segdot.is-out{background:var(--dsh-usage-seg-out)}',
        '.dsh-usage-rowvalue{flex:none;width:76px;text-align:right;font-size:12px;line-height:18px;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-primary)}',
        '.dsh-usage-rowcost{flex:none;width:64px;text-align:right;font-size:11px;line-height:18px;font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-empty{padding:20px 0 8px;text-align:center;font-size:13px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        // ── 错误条 + 底部峰谷时钟 ───────────────────────────
        '.dsh-usage-error{display:flex;align-items:center;gap:10px;padding:12px 16px;border-radius:12px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-state-error-primary);font-size:13px}',
        '.dsh-usage-foot{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:0 4px;font-size:12px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-dot{width:6px;height:6px;border-radius:50%;flex:none;transition:background .5s linear}',
        '.dsh-usage-clock{font-family:var(--ds-font-family-code,ui-monospace,SFMono-Regular,Menlo,Consolas,monospace);font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-secondary)}',
        '.dsh-usage-period{color:var(--dsw-alias-label-secondary)}',
        '.dsh-usage-note{margin-left:auto;text-align:right}',
        '.dsh-usage-tip{position:fixed;z-index:50;pointer-events:none;padding:6px 8px;border-radius:8px;max-width:280px;background:var(--dsw-alias-tooltip-bg,rgba(30,32,38,.97));color:var(--dsw-alias-label-primary-inverted,var(--dsw-alias-label-primary-foreground,#f7f8fa));font-size:12px;line-height:16px;box-shadow:0 4px 16px var(--dsw-alias-bg-mask-2);white-space:normal}',
        '.dsh-usage-tip-sub{margin-top:2px;font-size:11px;line-height:15px;opacity:.85}',
        'body[data-ds-dark-theme] .dsh-usage-tip{color:var(--dsw-alias-label-primary,#f9fafb)}',
        // ── 设置页「用量统计」段 ─────────────────────────────
        '.dsh-usage-settings{display:flex;flex-direction:column;gap:14px;padding:4px 2px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family,ui-sans-serif,system-ui,sans-serif)}',
        '.dsh-usage-settings-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px}',
        '.dsh-usage-settings-cell{box-sizing:border-box;padding:12px 14px;border-radius:12px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1)}',
        '.dsh-usage-settings-label{font-size:12px;line-height:16px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-settings-value{margin-top:4px;font-size:18px;font-weight:600;font-variant-numeric:tabular-nums;letter-spacing:-.01em}',
        '.dsh-usage-settings-src{font-size:12px;font-weight:400;line-height:16px;color:var(--dsw-alias-label-secondary);word-break:break-all}',
        '.dsh-usage-settings-guide{font-size:12px;line-height:18px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-settings-yaml{margin:0;padding:12px 14px;border-radius:10px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);font-family:var(--ds-font-family-code,ui-monospace,SFMono-Regular,Menlo,Consolas,monospace);font-size:12px;line-height:18px;white-space:pre;overflow-x:auto;color:var(--dsw-alias-label-secondary)}',
        '.dsh-usage-settings-actions{display:flex;gap:8px;flex-wrap:wrap}',
        '.dsh-usage-settings-btn{display:inline-flex;align-items:center;justify-content:center;min-height:30px;padding:0 12px;border:0;border-radius:8px;background:var(--dsw-alias-state-business-tertiary);color:var(--dsw-alias-state-business-primary);font:inherit;font-size:13px;cursor:pointer;transition:filter var(--ds-transition-duration-fast,0.1s) var(--ds-ease-in-out,ease)}',
        '.dsh-usage-settings-btn:hover{filter:brightness(1.08)}',
        '.dsh-usage-settings-err{padding:10px 12px;border-radius:8px;border:1px solid color-mix(in srgb,var(--dsw-alias-state-error-primary) 35%,transparent);color:var(--dsw-alias-state-error-primary);font-size:12px}',
        // ── 设置页:搜索框 + 模型列表 + 详情弹层 ─────────────
        '.dsh-usage-settings-search{display:flex;align-items:center;gap:8px}',
        '.dsh-usage-settings-q{flex:1;min-width:0;box-sizing:border-box;height:34px;padding:0 12px;border-radius:9px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;outline:none;transition:border-color var(--ds-transition-duration-fast,0.1s) var(--ds-ease-in-out,ease)}',
        '.dsh-usage-settings-q:focus{border-color:var(--dsw-alias-state-business-primary)}',
        '.dsh-usage-settings-listhead{display:flex;align-items:center;justify-content:space-between;padding:0 4px;font-size:11px;line-height:16px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-settings-list{display:flex;flex-direction:column;gap:2px;max-height:340px;overflow-y:auto;padding:2px}',
        '.dsh-usage-settings-rowbtn{display:flex;align-items:center;justify-content:space-between;gap:12px;width:100%;box-sizing:border-box;padding:8px 12px;border:0;border-radius:8px;background:transparent;color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;cursor:pointer;text-align:left;transition:background var(--ds-transition-duration-fast,0.1s) var(--ds-ease-in-out,ease)}',
        '.dsh-usage-settings-rowbtn:hover{background:var(--dsw-alias-interactive-bg-hover)}',
        '.dsh-usage-settings-listname{font-variant-numeric:tabular-nums;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
        '.dsh-usage-settings-listsrc{flex:none;font-size:11px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-settings-empty{padding:14px 4px;text-align:center;font-size:12px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}',
        '.dsh-usage-settings-modal{position:fixed;inset:0;z-index:60;display:flex;align-items:center;justify-content:center;background:var(--dsw-alias-bg-mask-2,rgba(10,12,18,.5));padding:24px}',
        '.dsh-usage-settings-modalbox{box-sizing:border-box;width:100%;max-width:400px;max-height:85vh;overflow-y:auto;padding:18px 20px;border-radius:14px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-overlay);box-shadow:0 16px 48px var(--dsw-alias-bg-mask-2);display:flex;flex-direction:column;gap:12px}',
        '.dsh-usage-settings-modalhead{display:flex;align-items:center;gap:10px}',
        '.dsh-usage-settings-modaltitle{flex:1;min-width:0;font-size:14px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
        '.dsh-usage-settings-modalsrc{flex:none;font-size:11px;padding:2px 8px;border-radius:99px;background:var(--dsw-alias-state-business-tertiary);color:var(--dsw-alias-state-business-primary)}',
        '.dsh-usage-settings-close{min-width:28px;min-height:28px;padding:0;border-radius:7px;flex:none}',
        '.dsh-usage-settings-field{display:flex;align-items:center;gap:10px}',
        '.dsh-usage-settings-fieldname{flex:none;width:120px;font-size:12px;color:var(--dsw-alias-label-secondary)}',
        '.dsh-usage-settings-input{box-sizing:border-box;flex:1;min-width:0;height:32px;padding:0 10px;border-radius:8px;border:1px solid var(--dsw-alias-border-l2);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:13px;font-variant-numeric:tabular-nums;outline:none;transition:border-color var(--ds-transition-duration-fast,0.1s) var(--ds-ease-in-out,ease)}',
        '.dsh-usage-settings-input:focus{border-color:var(--dsw-alias-state-business-primary)}',
        '.dsh-usage-settings-btn-primary{background:var(--dsw-alias-state-business-primary);color:var(--dsw-alias-label-primary-inverted,var(--dsw-alias-label-primary-foreground,#fff))}',
        '.dsh-usage-settings-btn:disabled{opacity:.55;cursor:not-allowed}',
        '.dsh-usage-settings-msg{font-size:12px;line-height:16px;color:var(--dsw-alias-state-success-primary,var(--dsw-alias-state-business-primary))}',
      ].join('')
      document.head.append(style)

      // ── 工具函数 ────────────────────────────────────────────────
      function monthStr(date) {
        return date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0')
      }
      function dayStr(date) {
        return monthStr(date) + '-' + String(date.getDate()).padStart(2, '0')
      }
      function tokenRgb(name, fallback) {
        const raw = getComputedStyle(document.body).getPropertyValue(name).trim()
        const match = raw.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/)
        if (match === null) return fallback
        return [Number(match[1]), Number(match[2]), Number(match[3])]
      }
      function shiftMonth(month, delta) {
        const parts = month.split('-').map(Number)
        return monthStr(new Date(parts[0], parts[1] - 1 + delta, 1))
      }
      function fmtTokens(n) {
        if (typeof n !== 'number' || !Number.isFinite(n)) return '—'
        if (n >= 1e8) return (n / 1e8).toFixed(2) + '亿'
        if (n >= 1e4) return (n / 1e4).toFixed(1) + '万'
        return String(n)
      }
      // 金额格式化:按 Host cost.currency 前缀,两位小数,去无意义的 .00
      function fmtCost(value, currency) {
        if (typeof value !== 'number' || !Number.isFinite(value)) return '—'
        const rounded = Math.round(value * 100) / 100
        const text = Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(2)
        return (currency === undefined || currency === '' ? '' : currency) + text
      }
      // 价格来源提示文本(Host 每模型 price.source:local/official/openrouter/none)。
      // modelKey 用来把「官方模型名但走了第三方网关」与「真·无价格」说清楚 ——
      // 后者若显示成「OpenRouter 聚合目录」会误导。
      function priceSourceLabel(source, modelKey) {
        const bare = typeof modelKey === 'string' ? modelKey.split('/').pop() : ''
        const officialName = OFFICIAL_MODEL_NAMES.includes(bare)
        if (source === 'local') return '价格来自本地配置(dizzy-usage-card.prices)'
        if (source === 'official') return '价格来自 DeepSeek 官网(含峰谷两档)'
        if (source === 'openrouter') return '价格来自 OpenRouter 聚合目录'
        if (officialName) return 'DeepSeek 官方模型名,但这次没走官方路由;该网关价目表里没有对应条目,按 0 计'
        return '该模型无价格,按 0 计'
      }
      // 北京时间(Asia/Shanghai)的 时/分/秒
      const bjFmt = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Shanghai',
        hour12: false,
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      })
      function beijingParts(date) {
        const parts = Object.create(null)
        for (const part of bjFmt.formatToParts(date)) {
          if (part.type !== 'literal') parts[part.type] = Number(part.value)
        }
        return { h: parts.hour, m: parts.minute, s: parts.second }
      }
      // 官方峰谷:高峰 9:00-12:00、14:00-18:00(北京时间),其余空闲;
      // 进入高峰前 30 分钟由绿渐变红,高峰结束后 30 分钟由红渐变回绿
      function mix(x, from, to) {
        return 'rgb(' + [0, 1, 2].map((i) => Math.round(from[i] + (to[i] - from[i]) * x)).join(',') + ')'
      }
      function periodOf(date) {
        const green = tokenRgb('--dsw-static-green-500', [34, 197, 94])
        const red = tokenRgb('--dsw-static-red-500', [239, 68, 68])
        const p = beijingParts(date)
        const m = p.h * 60 + p.m
        const T = 30
        const t = (a, b) => (m - a) / (b - a)
        if (m >= 8 * 60 + 30 && m < 9 * 60) return { color: mix(t(8 * 60 + 30, 9 * 60), green, red), label: '即将进入高峰' }
        if (m >= 9 * 60 && m < 12 * 60) return { color: mix(1, green, red), label: '高峰时段' }
        if (m >= 12 * 60 && m < 12 * 60 + T) return { color: mix(t(12 * 60, 12 * 60 + T), red, green), label: '高峰刚结束' }
        if (m >= 13 * 60 + 30 && m < 14 * 60) return { color: mix(t(13 * 60 + 30, 14 * 60), green, red), label: '即将进入高峰' }
        if (m >= 14 * 60 && m < 18 * 60) return { color: mix(1, green, red), label: '高峰时段' }
        if (m >= 18 * 60 && m < 18 * 60 + T) return { color: mix(t(18 * 60, 18 * 60 + T), red, green), label: '高峰刚结束' }
        return { color: mix(0, green, red), label: '空闲时段' }
      }
      // 周一起始的月网格:列 = 周,行 = 周一~周日
      function monthWeeks(year, month) {
        const daysInMonth = new Date(year, month + 1, 0).getDate()
        const firstDow = (new Date(year, month, 1).getDay() + 6) % 7
        const weeks = []
        let day = 1 - firstDow
        while (day <= daysInMonth) {
          const week = []
          for (let i = 0; i < 7; i += 1) {
            const d = day + i
            week.push(d >= 1 && d <= daysInMonth ? new Date(year, month, d) : null)
          }
          weeks.push(week)
          day += 7
        }
        return weeks
      }
      // 用量相对峰值的四档分级(0 = 无用量),热力图用
      function levelOf(tokens, max) {
        if (tokens <= 0 || max <= 0) return 0
        const r = tokens / max
        if (r > 0.75) return 4
        if (r > 0.5) return 3
        if (r > 0.25) return 2
        return 1
      }
      // 分项弹窗的第二行(无 detail 的旧 host 返回 null)
      function partsLine(parts) {
        if (parts === null || parts === undefined) return null
        return '输入(未命中) ' + fmtTokens(parts.input)
          + ' · 输入(命中缓存) ' + fmtTokens(parts.cacheRead)
          + ' · 输出 ' + fmtTokens(parts.output)
      }
      // 弹窗跟鼠标:默认右下,贴边则翻到左/上,始终留 8px 边距
      function placeTip(x, y, w, h) {
        const gap = 14
        let left = x + gap
        let top = y + gap
        if (left + w > window.innerWidth - 8) left = x - gap - w
        if (left < 8) left = 8
        if (top + h > window.innerHeight - 8) top = y - gap - h
        if (top < 8) top = 8
        return { left: Math.round(left), top: Math.round(top) }
      }
      function applyTipPos(el, x, y) {
        const next = placeTip(x, y, el.offsetWidth, el.offsetHeight)
        el.style.left = next.left + 'px'
        el.style.top = next.top + 'px'
      }
      // 'provider/model' → 显示用短名(全名进悬浮弹窗)
      function modelLabel(key) {
        const i = key.lastIndexOf('/')
        return i === -1 ? key : key.slice(i + 1)
      }
      const WEEKDAYS = ['一', '二', '三', '四', '五', '六', '日']

      function PeakClock() {
        const [now, setNow] = React.useState(new Date())
        React.useEffect(() => {
          const timer = setInterval(() => setNow(new Date()), 15000)
          return () => clearInterval(timer)
        }, [])
        const period = periodOf(now)
        const bj = beijingParts(now)
        const clockText = String(bj.h).padStart(2, '0') + ':' + String(bj.m).padStart(2, '0')
        return React.createElement(React.Fragment, null, [
          React.createElement('span', { key: 'dot', className: 'dsh-usage-dot', style: { background: period.color } }),
          React.createElement('span', { key: 'clock', className: 'dsh-usage-clock' }, clockText),
          React.createElement('span', { key: 'period', className: 'dsh-usage-period' }, period.label),
        ])
      }
      function Chevron({ dir }) {
        return React.createElement('svg', {
          width: 12,
          height: 12,
          viewBox: '0 0 12 12',
          fill: 'none',
          'aria-hidden': 'true',
        }, React.createElement('path', {
          d: dir < 0 ? 'M7.5 2.5L4 6l3.5 3.5' : 'M4.5 2.5L8 6 4.5 9.5',
          stroke: 'currentColor',
          strokeWidth: 1.4,
          strokeLinecap: 'round',
          strokeLinejoin: 'round',
        }))
      }
      function RefreshIcon() {
        return React.createElement('svg', {
          width: 12,
          height: 12,
          viewBox: '0 0 12 12',
          fill: 'none',
          'aria-hidden': 'true',
        }, [
          React.createElement('path', {
            key: 'arc',
            d: 'M10 6a4 4 0 1 1-1.2-2.85',
            stroke: 'currentColor',
            strokeWidth: 1.4,
            strokeLinecap: 'round',
          }),
          React.createElement('path', {
            key: 'head',
            d: 'M9.9 1v2.4H7.5',
            stroke: 'currentColor',
            strokeWidth: 1.4,
            strokeLinecap: 'round',
            strokeLinejoin: 'round',
          }),
        ])
      }

      // ── 近 7 天曲线:Catmull-Rom 转三次贝塞尔,平滑过点 ──────────
      function UsageCurve({ points, onTip, onTipEnd }) {
        const [hoverKey, setHoverKey] = React.useState(null)
        const ruleRef = React.useRef(null)
        const hoverKeyRef = React.useRef(null)
        const lineXRef = React.useRef(null)
        if (!Array.isArray(points) || points.length < 2) {
          return null
        }
        const W = 360
        const H = 150
        const pad = { l: 10, r: 10, t: 14, b: 24 }
        let max = 0
        for (const p of points) if (p.tokens > max) max = p.tokens
        const span = max <= 0 ? 1 : max
        const stepX = (W - pad.l - pad.r) / (points.length - 1)
        const pts = points.map((p, i) => ({
          key: p.key,
          label: p.label,
          tokens: p.tokens,
          parts: p.parts,
          x: pad.l + i * stepX,
          y: pad.t + (1 - p.tokens / span) * (H - pad.t - pad.b),
        }))
        let d = 'M ' + pts[0].x.toFixed(1) + ' ' + pts[0].y.toFixed(1)
        for (let i = 0; i < pts.length - 1; i += 1) {
          const p0 = pts[Math.max(0, i - 1)]
          const p1 = pts[i]
          const p2 = pts[i + 1]
          const p3 = pts[Math.min(pts.length - 1, i + 2)]
          const c1x = p1.x + (p2.x - p0.x) / 6
          const c1y = p1.y + (p2.y - p0.y) / 6
          const c2x = p2.x - (p3.x - p1.x) / 6
          const c2y = p2.y - (p3.y - p1.y) / 6
          d += ' C ' + c1x.toFixed(1) + ' ' + c1y.toFixed(1) + ', ' + c2x.toFixed(1) + ' ' + c2y.toFixed(1) + ', ' + p2.x.toFixed(1) + ' ' + p2.y.toFixed(1)
        }
        const base = H - pad.b
        const area = d + ' L ' + pts[pts.length - 1].x.toFixed(1) + ' ' + base + ' L ' + pts[0].x.toFixed(1) + ' ' + base + ' Z'
        const clientToViewX = (event) => {
          const svg = event.currentTarget
          const ctm = typeof svg.getScreenCTM === 'function' ? svg.getScreenCTM() : null
          if (ctm !== null && typeof ctm.inverse === 'function') {
            const pt = svg.createSVGPoint()
            pt.x = event.clientX
            pt.y = event.clientY
            return pt.matrixTransform(ctm.inverse()).x
          }
          const rect = svg.getBoundingClientRect()
          if (rect.width <= 0) return pts[0].x
          return ((event.clientX - rect.left) / rect.width) * W
        }
        const nearest = (viewX) => {
          let best = pts[0]
          let bestDist = Math.abs(viewX - pts[0].x)
          for (let i = 1; i < pts.length; i += 1) {
            const dist = Math.abs(viewX - pts[i].x)
            if (dist < bestDist) {
              best = pts[i]
              bestDist = dist
            }
          }
          return best
        }
        const showAt = (event) => {
          const viewX = clientToViewX(event)
          const p = nearest(viewX)
          const lineX = Math.min(W - pad.r, Math.max(pad.l, viewX))
          lineXRef.current = lineX
          if (ruleRef.current !== null) {
            ruleRef.current.setAttribute('x1', String(lineX))
            ruleRef.current.setAttribute('x2', String(lineX))
            ruleRef.current.setAttribute('visibility', 'visible')
          }
          if (hoverKeyRef.current !== p.key) {
            hoverKeyRef.current = p.key
            setHoverKey(p.key)
          }
          onTip(
            event,
            p.key + ' · ' + (p.tokens > 0 ? fmtTokens(p.tokens) + ' tokens' : '无用量'),
            partsLine(p.parts)
          )
        }
        const hideAt = () => {
          hoverKeyRef.current = null
          lineXRef.current = null
          if (ruleRef.current !== null) ruleRef.current.setAttribute('visibility', 'hidden')
          setHoverKey(null)
          onTipEnd()
        }
        const children = [
          React.createElement('path', { key: 'area', className: 'dsh-usage-curve-area', d: area }),
          React.createElement('path', { key: 'line', className: 'dsh-usage-curve-line', d }),
        ]
        children.push(React.createElement('line', {
          key: 'rule',
          ref: ruleRef,
          className: 'dsh-usage-curve-rule',
          x1: lineXRef.current === null ? pts[0].x : lineXRef.current,
          x2: lineXRef.current === null ? pts[0].x : lineXRef.current,
          y1: pad.t,
          y2: base,
          visibility: hoverKey === null ? 'hidden' : 'visible',
        }))
        for (const p of pts) {
          children.push(React.createElement('circle', {
            key: p.key,
            className: 'dsh-usage-curve-dot' + (hoverKey === p.key ? ' is-on' : ''),
            cx: p.x,
            cy: p.y,
            r: hoverKey === p.key ? 5 : 3.5,
          }))
        }
        for (const p of pts) {
          children.push(React.createElement('text', {
            key: 'x' + p.key,
            className: 'dsh-usage-curve-x',
            x: p.x,
            y: H - 8,
            textAnchor: 'middle',
          }, p.label))
        }
        children.push(React.createElement('rect', {
          key: 'hit',
          className: 'dsh-usage-curve-hit',
          x: 0,
          y: 0,
          width: W,
          height: H,
        }))
        return React.createElement('svg', {
          className: 'dsh-usage-curve-svg',
          viewBox: '0 0 ' + W + ' ' + H,
          role: 'img',
          'aria-label': '近 7 天用量曲线',
          onMouseEnter: showAt,
          onMouseMove: showAt,
          onMouseLeave: hideAt,
        }, children)
      }

      // ── 用量视图(conversation.view entry)────────────────────────
      function UsageView() {
        const [month, setMonth] = React.useState(monthStr(new Date()))
        const [data, setData] = React.useState(null)
        const [loading, setLoading] = React.useState(true)
        const [error, setError] = React.useState(null)
        const [pickerOpen, setPickerOpen] = React.useState(false)
        const [pickerYear, setPickerYear] = React.useState(new Date().getFullYear())
        const [tip, setTip] = React.useState(null)
        const [tick, setTick] = React.useState(0)
        const pickerRef = React.useRef(null)
        const tipRef = React.useRef(null)
        const tipStateRef = React.useRef(null)
        const tipPosRef = React.useRef({ x: 0, y: 0 })
        const dataRef = React.useRef(null)
        dataRef.current = data
        tipStateRef.current = tip
        const hideTip = () => setTip(null)
        React.useLayoutEffect(() => {
          if (tip === null || tipRef.current === null) return
          applyTipPos(tipRef.current, tipPosRef.current.x, tipPosRef.current.y)
          tipRef.current.style.visibility = 'visible'
        })

        // 拉取:月份切换 / 手动刷新 / 60s 自动。查看月份已有数据时静默
        // 刷新(保留旧数不闪骨架);无数据时失败才进错误态。
        const stamp = (r) => {
          r.requested = month
          return r
        }
        React.useEffect(() => {
          let alive = true
          const ctrl = new AbortController()
          const cached = dataRef.current
          if (cached === null || cached.month !== month) setLoading(true)
          fetch('/dizzy/usage?month=' + encodeURIComponent(month), { credentials: 'same-origin', signal: ctrl.signal })
            .then((response) => {
              if (!response.ok) throw new Error('usage ' + response.status)
              return response.json()
            })
            .then((r) => {
              if (!alive) return
              if (r === null || typeof r !== 'object' || typeof r.total !== 'number') {
                throw new Error('usage shape')
              }
              setData(stamp(r))
              setError(null)
              setLoading(false)
            })
            .catch(() => {
              if (!alive) return
              setLoading(false)
              const held = dataRef.current
              if (held === null || held.month !== month) setError('用量拉取失败')
            })
          return () => {
            alive = false
            ctrl.abort()
          }
        }, [month, tick])

        React.useEffect(() => {
          const timer = setInterval(() => setTick((n) => n + 1), 60000)
          return () => clearInterval(timer)
        }, [])

        React.useEffect(() => {
          if (!pickerOpen) return
          const onDown = (event) => {
            if (pickerRef.current !== null && !pickerRef.current.contains(event.target)) {
              setPickerOpen(false)
            }
          }
          const onKey = (event) => {
            if (event.key === 'Escape') setPickerOpen(false)
          }
          document.addEventListener('mousedown', onDown)
          document.addEventListener('keydown', onKey)
          return () => {
            document.removeEventListener('mousedown', onDown)
            document.removeEventListener('keydown', onKey)
          }
        }, [pickerOpen])

        // 激活即回顶:scrollBody 与对话视图共用,会带着上个视图的滚动位置
        React.useEffect(() => {
          const scroller = document.querySelector('[data-conversation-scroll]')
          if (scroller !== null) scroller.scrollTop = 0
        }, [])

        // 只展示与「请求月」匹配的数据:切月瞬间旧月数据立即视为未加载,
        // 同月静默刷新则继续展示旧数直到新数到达。请求月没有任何用量时
        // Host 会回落到最近一个有数据的月,那时用返回的 month 渲染,而
        // `requested` 一直保留请求月,所以不用改本地 month 状态。
        // 这个回落是**默认行为**(就像编辑器打开最近一次编辑的位置),
        // 不在界面上标注。
        const viewData = data !== null && data !== undefined
          && (data.month === month || data.requested === month)
          ? data
          : null
        const shownMonth = viewData !== null && typeof viewData.month === 'string' ? viewData.month : month
        const monthsWithData = viewData !== null && Array.isArray(viewData.monthsWithData)
          ? viewData.monthsWithData
          : []
        // 当前月没有用量时,给出前后最近的有数据月,供一键跳转。
        const hasData = monthsWithData.includes(shownMonth)
        const newerMonth = hasData ? null : (monthsWithData.find((value) => value > shownMonth) ?? null)
        const olderMonth = hasData ? null : ([...monthsWithData].reverse().find((value) => value < shownMonth) ?? null)
        const parts = shownMonth.split('-').map(Number)
        const weeks = monthWeeks(parts[0], parts[1] - 1)
        const days = viewData !== null && viewData.days !== null && typeof viewData.days === 'object'
          ? viewData.days
          : null
        // Host 分项版的附加块:逐日分项 / 近 7 天 / 今日分模型
        const detail = viewData !== null && viewData.detail !== null && typeof viewData.detail === 'object'
          ? viewData.detail
          : null
        const dayParts = detail !== null && detail.days !== null && typeof detail.days === 'object'
          ? detail.days
          : null
        let max = 0
        let activeDays = 0
        let peakDay = null
        if (days !== null) {
          for (const key of Object.keys(days)) {
            const value = days[key]
            if (typeof value !== 'number' || value <= 0) continue
            activeDays += 1
            if (value > max) {
              max = value
              peakDay = key
            }
          }
        }
        const todayStr = dayStr(new Date())
        const total = viewData === null ? null : viewData.total ?? 0
        // 金额:Host 聚合价 + 用户本地价;旧 Host 无 cost 字段时金额全部隐藏
        const costInfo = viewData !== null && viewData.cost !== null && typeof viewData.cost === 'object'
          ? viewData.cost
          : null
        const currency = costInfo !== null && typeof costInfo.currency === 'string' ? costInfo.currency : '¥'

        const showTip = (event, title, sub) => {
          const rect = event.currentTarget.getBoundingClientRect()
          const keyed = event.clientX !== 0 || event.clientY !== 0
          const x = keyed ? event.clientX : rect.left + rect.width / 2
          const y = keyed ? event.clientY : rect.top
          tipPosRef.current = { x, y }
          const nextSub = sub ?? null
          const held = tipStateRef.current
          if (held !== null && held.title === title && held.sub === nextSub) {
            if (tipRef.current !== null) applyTipPos(tipRef.current, x, y)
            return
          }
          setTip({ title, sub: nextSub })
        }

        // ── 页头:标题 + 月份导航 + 刷新 ──────────────────────
        const monthButtons = []
        for (let m = 1; m <= 12; m += 1) {
          const value = pickerYear + '-' + String(m).padStart(2, '0')
          monthButtons.push(React.createElement('button', {
            key: value,
            type: 'button',
            className: 'dsh-usage-mbtn' + (value === shownMonth ? ' is-on' : ''),
            onClick: () => {
              setMonth(value)
              setPickerOpen(false)
            },
          }, String(m)))
        }
        // ── 汇总标记:上次汇总于何时 + 上次汇总到现在的增量 ────────────
        // Host 每次真要重扫才推进 scannedAt;被节流跳过时 scannedAt 与
        // deltaTokens 都留在上一轮,所以这里的标记始终对应一次真实汇总。
        const fmtTime = (value) => new Date(value).toLocaleString('zh-CN', {
          month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false,
        })
        const scanMark = viewData === null || typeof viewData.scannedAt !== 'number' || viewData.scannedAt <= 0
          ? null
          : {
              at: viewData.scannedAt,
              previous: typeof viewData.previousScannedAt === 'number' && viewData.previousScannedAt > 0
                ? viewData.previousScannedAt
                : null,
              delta: typeof viewData.deltaTokens === 'number' && viewData.deltaTokens > 0 ? viewData.deltaTokens : 0,
            }
        const subtitle = loading && viewData === null
          ? '正在汇总本地会话…'
          : scanMark === null
            ? '本地会话 token 汇总'
            : '上次汇总于 ' + fmtTime(scanMark.at)
              + (scanMark.previous !== null ? '(上一轮 ' + fmtTime(scanMark.previous) + ')' : '')
              + ' · 较上次新增 ' + fmtTokens(scanMark.delta)
              + (typeof viewData.errors === 'number' && viewData.errors > 0
                ? ' · ⚠ ' + viewData.errors + ' 个日志文件解析失败,用量可能被低估'
                : '')

        const topbar = React.createElement('div', { key: 'topbar', className: 'dsh-usage-topbar' }, [
          React.createElement('div', { key: 'title' }, [
            React.createElement('h1', { key: 't', className: 'dsh-usage-title' }, '用量'),
            React.createElement('div', { key: 's', className: 'dsh-usage-subtitle' }, subtitle),
          ]),
          React.createElement('div', { key: 'nav', className: 'dsh-usage-nav', ref: pickerRef }, [
            newerMonth !== null
              ? React.createElement('button', {
                  key: 'newer',
                  type: 'button',
                  className: 'dsh-usage-btn dsh-usage-latest',
                  title: '这个月没有用量,跳到更近的有数据月份',
                  onClick: () => {
                    setMonth(newerMonth)
                    setPickerYear(Number(newerMonth.slice(0, 4)))
                    setPickerOpen(false)
                  },
                }, '› ' + newerMonth)
              : null,
            olderMonth !== null
              ? React.createElement('button', {
                  key: 'older',
                  type: 'button',
                  className: 'dsh-usage-btn dsh-usage-latest',
                  title: '这个月没有用量,跳到更早的有数据月份',
                  onClick: () => {
                    setMonth(olderMonth)
                    setPickerYear(Number(olderMonth.slice(0, 4)))
                    setPickerOpen(false)
                  },
                }, '‹ ' + olderMonth)
              : null,
            React.createElement('button', {
              key: 'prev',
              type: 'button',
              className: 'dsh-usage-btn',
              'aria-label': '上个月',
              onClick: () => {
                const next = shiftMonth(month, -1)
                setMonth(next)
                setPickerYear(Number(next.slice(0, 4)))
              },
            }, React.createElement(Chevron, { dir: -1 })),
            React.createElement('button', {
              key: 'month',
              type: 'button',
              className: 'dsh-usage-btn dsh-usage-month',
              'aria-expanded': pickerOpen,
              'aria-haspopup': 'dialog',
              onClick: () => {
                setPickerYear(parts[0])
                setPickerOpen((open) => !open)
              },
            }, parts[0] + '年' + parts[1] + '月'),
            React.createElement('button', {
              key: 'next',
              type: 'button',
              className: 'dsh-usage-btn',
              'aria-label': '下个月',
              onClick: () => {
                const next = shiftMonth(month, 1)
                setMonth(next)
                setPickerYear(Number(next.slice(0, 4)))
              },
            }, React.createElement(Chevron, { dir: 1 })),
            React.createElement('button', {
              key: 'refresh',
              type: 'button',
              className: 'dsh-usage-btn dsh-usage-refresh' + (loading ? ' is-spinning' : ''),
              'aria-label': '刷新',
              title: '刷新',
              onClick: () => {
                setLoading(true)
                fetch('/dizzy/usage?month=' + encodeURIComponent(month), { credentials: 'same-origin' })
                  .then((response) => {
                    if (!response.ok) throw new Error('usage ' + response.status)
                    return response.json()
                  })
                  .then((r) => {
                    if (r === null || typeof r !== 'object' || typeof r.total !== 'number') throw new Error('usage shape')
                    setData(stamp(r))
                    setError(null)
                    setLoading(false)
                  })
                  .catch(() => {
                    setLoading(false)
                    setError('用量拉取失败')
                  })
              },
            }, React.createElement(RefreshIcon)),
            pickerOpen ? React.createElement('div', {
              key: 'pop',
              className: 'dsh-usage-pop',
              role: 'dialog',
              'aria-label': '选择月份',
            }, [
              React.createElement('div', { key: 'y', className: 'dsh-usage-yrow' }, [
                React.createElement('button', {
                  key: 'yp',
                  type: 'button',
                  className: 'dsh-usage-btn',
                  'aria-label': '上一年',
                  onClick: () => setPickerYear((year) => year - 1),
                }, React.createElement(Chevron, { dir: -1 })),
                React.createElement('span', { key: 'yl' }, String(pickerYear)),
                React.createElement('button', {
                  key: 'yn',
                  type: 'button',
                  className: 'dsh-usage-btn',
                  'aria-label': '下一年',
                  onClick: () => setPickerYear((year) => year + 1),
                }, React.createElement(Chevron, { dir: 1 })),
              ]),
              React.createElement('div', { key: 'g', className: 'dsh-usage-mgrid' }, monthButtons),
              React.createElement('button', {
                key: 'now',
                type: 'button',
                className: 'dsh-usage-now',
                onClick: () => {
                  const nowMonth = monthStr(new Date())
                  setMonth(nowMonth)
                  setPickerYear(Number(nowMonth.slice(0, 4)))
                  setPickerOpen(false)
                },
              }, '回到本月'),
            ]) : null,
          ]),
        ])

        // ── 统计卡 ─────────────────────────────────────────
        const statValue = (text) => loading && viewData === null
          ? React.createElement('span', { className: 'dsh-usage-skel', 'aria-hidden': 'true' })
          : text
        const peakLabel = peakDay === null
          ? '—'
          : Number(peakDay.slice(5, 7)) + '月' + Number(peakDay.slice(8, 10)) + '日'
        const stats = React.createElement('div', { key: 'stats', className: 'dsh-usage-stats' }, [
          React.createElement('div', { key: 'cost', className: 'dsh-usage-stat' }, [
            React.createElement('div', { key: 'l', className: 'dsh-usage-stat-label' }, '本月花费'),
            React.createElement('div', { key: 'v', className: 'dsh-usage-stat-value' },
              statValue(costInfo === null
                ? '—'
                : fmtCost(costInfo.total ?? 0, currency))),
          ]),
          React.createElement('div', { key: 'total', className: 'dsh-usage-stat' }, [
            React.createElement('div', { key: 'l', className: 'dsh-usage-stat-label' }, '本月合计'),
            React.createElement('div', { key: 'v', className: 'dsh-usage-stat-value' },
              statValue(total === null ? '—' : fmtTokens(total))),
            React.createElement('div', { key: 's', className: 'dsh-usage-stat-sub' }, 'tokens · 本地会话'),
          ]),
          React.createElement('div', { key: 'days', className: 'dsh-usage-stat' }, [
            React.createElement('div', { key: 'l', className: 'dsh-usage-stat-label' }, '活跃天数'),
            React.createElement('div', { key: 'v', className: 'dsh-usage-stat-value' },
              statValue(days === null ? '—' : String(activeDays))),
            React.createElement('div', { key: 's', className: 'dsh-usage-stat-sub' }, '有用量记录的天数'),
          ]),
          React.createElement('div', { key: 'avg', className: 'dsh-usage-stat' }, [
            React.createElement('div', { key: 'l', className: 'dsh-usage-stat-label' }, '活跃日均'),
            React.createElement('div', { key: 'v', className: 'dsh-usage-stat-value' },
              statValue(total === null || activeDays === 0 ? '—' : fmtTokens(Math.round(total / activeDays)))),
            React.createElement('div', { key: 's', className: 'dsh-usage-stat-sub' }, 'tokens / 活跃天'),
          ]),
          React.createElement('div', { key: 'peak', className: 'dsh-usage-stat' }, [
            React.createElement('div', { key: 'l', className: 'dsh-usage-stat-label' }, '峰值日'),
            React.createElement('div', { key: 'v', className: 'dsh-usage-stat-value' },
              statValue(peakDay === null ? '—' : fmtTokens(max))),
            React.createElement('div', { key: 's', className: 'dsh-usage-stat-sub' }, peakLabel),
          ]),
        ])

        // ── 月度热力图 + 近 7 天曲线 ─────────────────────────
        const wd = WEEKDAYS.map((name) => React.createElement('div', {
          key: name,
          className: 'dsh-usage-wdl',
        }, name))
        const heatCells = []
        for (let row = 0; row < 7; row += 1) {
          for (let col = 0; col < weeks.length; col += 1) {
            const date = weeks[col][row]
            if (date === null || date === undefined) {
              heatCells.push(React.createElement('span', {
                key: 'v' + row + '-' + col,
                className: 'dsh-usage-cell is-void',
              }))
              continue
            }
            const key = dayStr(date)
            const tokens = days === null ? 0 : (days[key] ?? 0)
            const level = levelOf(tokens, max)
            const tipTitle = key + ' · ' + (tokens > 0 ? fmtTokens(tokens) + ' tokens' : '无用量')
            const tipSub = partsLine(dayParts === null ? null : dayParts[key])
            heatCells.push(React.createElement('button', {
              key: key,
              type: 'button',
              className: 'dsh-usage-cell' + (level > 0 ? ' lv' + level : '') + (key === todayStr ? ' is-today' : ''),
              'aria-label': tipTitle,
              onMouseEnter: (event) => showTip(event, tipTitle, tipSub),
              onMouseMove: (event) => showTip(event, tipTitle, tipSub),
              onMouseLeave: hideTip,
              onFocus: (event) => showTip(event, tipTitle, tipSub),
              onBlur: hideTip,
            }, String(date.getDate())))
          }
        }
        const legend = React.createElement('div', { key: 'legend', className: 'dsh-usage-legend' }, [
          '少',
          React.createElement('span', { key: 'l1', className: 'dsh-usage-swatch lv1' }),
          React.createElement('span', { key: 'l2', className: 'dsh-usage-swatch lv2' }),
          React.createElement('span', { key: 'l3', className: 'dsh-usage-swatch lv3' }),
          React.createElement('span', { key: 'l4', className: 'dsh-usage-swatch lv4' }),
          '多',
        ])

        // 曲线数据:Host detail.recent7(近 7 天,与查看月无关);
        // 旧 host 退化为查看月内 7 天(本月截至今,其他月取月末)
        let curvePoints
        if (detail !== null && Array.isArray(detail.recent7) && detail.recent7.length === 7) {
          curvePoints = detail.recent7.map((r) => ({
            key: r.date,
            label: Number(r.date.slice(5, 7)) + '/' + Number(r.date.slice(8, 10)),
            tokens: typeof r.total === 'number' ? r.total : 0,
            parts: { input: r.input ?? 0, output: r.output ?? 0, cacheRead: r.cacheRead ?? 0 },
          }))
        } else {
          const isCurrent = month === monthStr(new Date())
          const ref = isCurrent ? new Date() : new Date(parts[0], parts[1], 0)
          curvePoints = []
          for (let i = 6; i >= 0; i -= 1) {
            const d = new Date(ref.getFullYear(), ref.getMonth(), ref.getDate() - i)
            const key = dayStr(d)
            curvePoints.push({
              key,
              label: (d.getMonth() + 1) + '/' + d.getDate(),
              tokens: days === null ? 0 : (days[key] ?? 0),
              parts: null,
            })
          }
        }
        let curveSum = 0
        for (const p of curvePoints) curveSum += p.tokens

        const heatPanel = React.createElement('div', { key: 'heat', className: 'dsh-usage-panel' }, [
          React.createElement('div', { key: 'head', className: 'dsh-usage-panel-head' }, [
            React.createElement('span', { key: 't', className: 'dsh-usage-panel-title' }, '月度热力图'),
            legend,
          ]),
          React.createElement('div', { key: 'flex', className: 'dsh-usage-heatflex' }, [
            React.createElement('div', { key: 'heat', className: 'dsh-usage-heat' }, [
              React.createElement('div', { key: 'wd', className: 'dsh-usage-wd' }, wd),
              React.createElement('div', {
                key: 'cells',
                className: 'dsh-usage-cells',
                style: { gridTemplateColumns: 'repeat(' + weeks.length + ', 34px)' },
              }, heatCells),
            ]),
            React.createElement('div', { key: 'curve', className: 'dsh-usage-curvebox' }, [
              React.createElement('div', { key: 'head', className: 'dsh-usage-curve-head' }, [
                React.createElement('span', { key: 't', className: 'dsh-usage-curve-title' }, '近 7 天'),
                React.createElement('span', { key: 's', className: 'dsh-usage-curve-sum' }, '合计 ' + fmtTokens(curveSum)),
              ]),
              React.createElement('div', { key: 'body', className: 'dsh-usage-curve-body' },
                React.createElement(UsageCurve, { points: curvePoints, onTip: showTip, onTipEnd: hideTip })),
            ]),
          ]),
          !loading && total === 0
            ? React.createElement('div', { key: 'empty', className: 'dsh-usage-empty' }, '本月暂无用量记录')
            : null,
        ])

        // ── 今日明细(分模型)─────────────────────────────────
        const today = detail !== null && detail.today !== null && typeof detail.today === 'object'
          ? detail.today
          : null
        const todayModels = today !== null && today.models !== null && typeof today.models === 'object'
          ? today.models
          : {}
        const modelRows = Object.keys(todayModels)
          .map((key) => ({ key, ...todayModels[key] }))
          .filter((row) => typeof row.total === 'number' && row.total > 0)
          .sort((a, b) => b.total - a.total)
        let modelMax = 0
        let todayTotal = 0
        const labelCount = {}
        for (const row of modelRows) {
          if (row.total > modelMax) modelMax = row.total
          todayTotal += row.total
          const short = modelLabel(row.key)
          labelCount[short] = (labelCount[short] ?? 0) + 1
        }
        // 同名模型跨 provider 时显示 'provider / model' 消歧( provider 在前,截断也可辨)
        const displayName = (key) => {
          const short = modelLabel(key)
          return labelCount[short] > 1 ? key.replace('/', ' / ') : short
        }
        let todaySide = null
        if (today !== null && typeof today.date === 'string') {
          const tDate = new Date(today.date + 'T00:00:00')
          const costPart = typeof today.cost === 'number'
            ? ' · 约 ' + fmtCost(today.cost, currency)
            : ''
          todaySide = Number(today.date.slice(5, 7)) + '月' + Number(today.date.slice(8, 10)) + '日 周'
            + WEEKDAYS[(tDate.getDay() + 6) % 7] + ' · 合计 ' + fmtTokens(todayTotal) + costPart
        }

        let todayBody
        if (today === null) {
          todayBody = React.createElement('div', { key: 'hint', className: 'dsh-usage-empty' },
            '分模型明细将在 dsh web 重启后可用(Host 半区需重新加载)')
        } else if (modelRows.length === 0) {
          todayBody = React.createElement('div', { key: 'hint', className: 'dsh-usage-empty' }, '今日暂无用量记录')
        } else {
          todayBody = React.createElement('div', { key: 'rows', className: 'dsh-usage-rows' },
            modelRows.map((row) => {
              const pct = Math.max(2, Math.round((row.total / modelMax) * 100))
              const input = typeof row.input === 'number' ? row.input : 0
              const cacheRead = typeof row.cacheRead === 'number' ? row.cacheRead : 0
              const output = typeof row.output === 'number' ? row.output : 0
              const partsSum = input + cacheRead + output
              const segs = []
              const pushSeg = (key, cls, n) => {
                if (n <= 0 || partsSum <= 0) return
                segs.push(React.createElement('span', {
                  key,
                  className: 'dsh-usage-seg ' + cls,
                  style: { width: ((n / partsSum) * 100).toFixed(2) + '%' },
                }))
              }
              pushSeg('in', 'is-in', input)
              pushSeg('cache', 'is-cache', cacheRead)
              pushSeg('out', 'is-out', output)
              const rowTip = row.key + ' · ' + fmtTokens(row.total) + ' tokens'
              // 金额:新 Host 每行带 cost 与 price.source;旧 Host 无则隐藏
              const rowCost = typeof row.cost === 'number'
                ? React.createElement('div', {
                    key: 'c',
                    className: 'dsh-usage-rowcost',
                    title: row.price !== null && typeof row.price === 'object'
                      ? priceSourceLabel(row.price.source, row.key)
                      : undefined,
                  }, fmtCost(row.cost, currency))
                : null
              return React.createElement('button', {
                key: row.key,
                type: 'button',
                className: 'dsh-usage-row',
                'aria-label': rowTip,
                onMouseEnter: (event) => showTip(event, row.key, partsLine(row)),
                onMouseMove: (event) => showTip(event, row.key, partsLine(row)),
                onMouseLeave: hideTip,
                onFocus: (event) => showTip(event, row.key, partsLine(row)),
                onBlur: hideTip,
              }, [
                React.createElement('div', {
                  key: 'd',
                  className: 'dsh-usage-rowlabel',
                  title: row.key,
                }, displayName(row.key)),
                React.createElement('div', { key: 't', className: 'dsh-usage-track' },
                  React.createElement('div', {
                    className: 'dsh-usage-bar',
                    style: { width: pct + '%' },
                  }, segs)),
                React.createElement('div', { key: 'v', className: 'dsh-usage-rowvalue' }, fmtTokens(row.total)),
                rowCost,
              ])
            }))
        }
        const todayLegend = modelRows.length === 0 ? null : React.createElement('div', { key: 'lg', className: 'dsh-usage-seglg' }, [
          React.createElement('span', { key: 'in' }, [
            React.createElement('span', { key: 'i', className: 'dsh-usage-segdot is-in' }),
            '输入(未命中)',
          ]),
          React.createElement('span', { key: 'cache' }, [
            React.createElement('span', { key: 'i', className: 'dsh-usage-segdot is-cache' }),
            '输入(命中缓存)',
          ]),
          React.createElement('span', { key: 'out' }, [
            React.createElement('span', { key: 'i', className: 'dsh-usage-segdot is-out' }),
            '输出',
          ]),
        ])
        const todayPanel = React.createElement('div', { key: 'today', className: 'dsh-usage-panel' }, [
          React.createElement('div', { key: 'head', className: 'dsh-usage-panel-head' }, [
            React.createElement('span', { key: 't', className: 'dsh-usage-panel-title' }, '今日明细'),
            todaySide === null
              ? null
              : React.createElement('span', { key: 's', className: 'dsh-usage-panel-side' }, todaySide),
          ]),
          todayLegend,
          todayBody,
        ])

        // ── 错误条 + 底部峰谷时钟 ───────────────────────────
        const errorBar = error === null ? null : React.createElement('div', {
          key: 'error',
          className: 'dsh-usage-error',
          role: 'alert',
        }, [
          React.createElement('span', { key: 'msg' }, error),
          React.createElement('button', {
            key: 'retry',
            type: 'button',
            className: 'dsh-usage-btn',
            onClick: () => {
              setError(null)
              setTick((n) => n + 1)
            },
          }, '重试'),
        ])

        const foot = React.createElement('div', { key: 'foot', className: 'dsh-usage-foot' }, [
          React.createElement(PeakClock, { key: 'clock' }),
          React.createElement('span', { key: 'note', className: 'dsh-usage-note' },
            '统计本地会话日志的 token 消耗,与官方控制台「用量」口径可能不同'),
        ])

        const tipNode = tip === null ? null : React.createElement('div', {
          key: 'tip',
          ref: tipRef,
          className: 'dsh-usage-tip',
          role: 'tooltip',
          style: { visibility: 'hidden', left: 0, top: 0 },
        }, [
          React.createElement('div', { key: 't' }, tip.title),
          tip.sub === null
            ? null
            : React.createElement('div', { key: 's', className: 'dsh-usage-tip-sub' }, tip.sub),
        ])

        return React.createElement('div', { className: 'dsh-usage-view' }, [
          topbar,
          errorBar,
          stats,
          heatPanel,
          todayPanel,
          foot,
          tipNode,
        ])
      }

      // ── 设置页「用量统计」段(settings.section)──────────────────
      // 花费概览 + 模型价格管理:搜索框 → 模型列表 → 点击弹详情编辑。
      // 数据自取 GET /dizzy/usage + GET /dizzy/usage-prices;改价经
      // POST /dizzy/usage-prices 写回 settings.yaml(Host scope.update,
      // 保留注释),watch 触发重算 → 下一次请求实时按新价计算。
      function UsageSettingsSection() {
        const [data, setData] = React.useState(null)
        const [catalog, setCatalog] = React.useState(null)
        const [error, setError] = React.useState(null)
        const [query, setQuery] = React.useState('')
        const [selected, setSelected] = React.useState(null) // 详情编辑的模型
        const [draft, setDraft] = React.useState(null)       // 编辑草稿
        const [saving, setSaving] = React.useState(false)
        const [saveMsg, setSaveMsg] = React.useState(null)
        const reload = () => {
          const now = new Date()
          const month = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0')
          fetch('/dizzy/usage?month=' + month)
            .then((response) => response.json())
            .then((body) => { setData(body); setError(null) })
            .catch((err) => setError(err instanceof Error ? err.message : String(err)))
          fetch('/dizzy/usage-prices')
            .then((response) => response.json())
            .then((body) => { setCatalog(body); setError(null) })
            .catch((err) => setError(err instanceof Error ? err.message : String(err)))
        }
        React.useEffect(() => {
          let cancelled = false
          const now = new Date()
          const month = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0')
          fetch('/dizzy/usage?month=' + month)
            .then((response) => response.json())
            .then((body) => { if (!cancelled) { setData(body); setError(null) } })
            .catch((err) => { if (!cancelled) setError(err instanceof Error ? err.message : String(err)) })
          fetch('/dizzy/usage-prices')
            .then((response) => response.json())
            .then((body) => { if (!cancelled) setCatalog(body) })
            .catch(() => {})
          return () => { cancelled = true }
        }, [])
        const cost = data !== null && data.cost !== null && typeof data.cost === 'object' ? data.cost : null
        const pricing = data !== null && data.pricing !== null && typeof data.pricing === 'object' ? data.pricing : null
        const sourceText = pricing === null
          ? '价格表待 Host 加载'
          : '官方价(DeepSeek 官网,含峰谷) → 本地价 → OpenRouter 聚合价(每 6 小时同步)' + (pricing.asOf > 0 ? ' · ' + new Date(pricing.asOf).toLocaleTimeString() : '')
              + (typeof pricing.error === 'string' && pricing.error !== '' ? ' · 聚合拉取失败:' + pricing.error : '')
        // 搜索过滤:模型名 / provider 子串匹配
        const q = query.trim().toLowerCase()
        const list = catalog === null ? [] : catalog.prices
        const filtered = q === '' ? list : list.filter((item) => item.name.toLowerCase().includes(q))
        // 打开详情:草稿 = 当前价格(本地/官方/聚合),本地覆盖时仍可改回
        const openDetail = (item) => {
          setSelected(item)
          setDraft({
            key: item.name,
            inputPerM: String(item.inputPerM ?? 0),
            outputPerM: String(item.outputPerM ?? 0),
            cachePerM: String(item.cachePerM ?? 0),
            source: item.source,
          })
          setSaveMsg(null)
        }
        const savePrice = () => {
          const inputPerM = Number(draft.inputPerM)
          const outputPerM = Number(draft.outputPerM)
          const cachePerM = Number(draft.cachePerM)
          if (![inputPerM, outputPerM, cachePerM].every((n) => Number.isFinite(n) && n >= 0)) {
            setSaveMsg('请输入非负数字')
            return
          }
          setSaving(true)
          const patch = { ...(catalog === null ? {} : catalog.prices.reduce((acc, item) => {
            if (item.source === 'local') acc[item.name] = { inputPerM: item.inputPerM, outputPerM: item.outputPerM, cachePerM: item.cachePerM }
            return acc
          }, {})) }
          patch[draft.key] = { inputPerM, outputPerM, cachePerM }
          fetch('/dizzy/usage-prices', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ prices: patch }),
          })
            .then((response) => response.json())
            .then((body) => {
              setSaving(false)
              if (body.ok === true) {
                setSaveMsg('已保存 ✓ 金额将实时按新价格计算')
                setSelected(null)
                setDraft(null)
                reload()
              } else {
                setSaveMsg('保存失败:' + (body.error ?? '未知错误'))
              }
            })
            .catch((err) => {
              setSaving(false)
              setSaveMsg('保存失败:' + (err instanceof Error ? err.message : String(err)))
            })
        }
        const resetPrice = () => {
          // 删除本地覆盖:从本地表移除该键 → 回落到官方/聚合价
          const patch = { ...(catalog === null ? {} : catalog.prices.reduce((acc, item) => {
            if (item.source === 'local' && item.name !== draft.key) acc[item.name] = { inputPerM: item.inputPerM, outputPerM: item.outputPerM, cachePerM: item.cachePerM }
            return acc
          }, {})) }
          setSaving(true)
          fetch('/dizzy/usage-prices', {
            method: 'POST',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ prices: patch }),
          })
            .then((response) => response.json())
            .then((body) => {
              setSaving(false)
              if (body.ok === true) {
                setSaveMsg('已还原为默认价格 ✓')
                setSelected(null)
                setDraft(null)
                reload()
              } else {
                setSaveMsg('还原失败:' + (body.error ?? '未知错误'))
              }
            })
            .catch((err) => {
              setSaving(false)
              setSaveMsg('还原失败:' + (err instanceof Error ? err.message : String(err)))
            })
        }
        // 详情弹层:三个价格输入 + 保存/还原
        const detailModal = selected === null || draft === null
          ? null
          : React.createElement('div', { key: 'modal', className: 'dsh-usage-settings-modal' }, [
              React.createElement('div', { key: 'box', className: 'dsh-usage-settings-modalbox' }, [
                React.createElement('div', { key: 'head', className: 'dsh-usage-settings-modalhead' }, [
                  React.createElement('span', { key: 't', className: 'dsh-usage-settings-modaltitle' }, selected.name),
                  React.createElement('span', { key: 'src', className: 'dsh-usage-settings-modalsrc' },
                    draft.source === 'local' ? '本地覆盖' : draft.source === 'official' ? 'DeepSeek 官网价(峰谷)' : draft.source === 'openrouter' ? 'OpenRouter 聚合价' : '无价格'),
                  React.createElement('button', {
                    key: 'x', type: 'button', className: 'dsh-usage-settings-btn dsh-usage-settings-close',
                    'aria-label': '关闭', onClick: () => { setSelected(null); setDraft(null) },
                  }, '✕'),
                ]),
                React.createElement('div', { key: 'hint', className: 'dsh-usage-settings-guide' },
                  '单位:每百万 token 价格(人民币)。保存后实时生效,无需重启。'),
                React.createElement('label', { key: 'l1', className: 'dsh-usage-settings-field' }, [
                  React.createElement('span', { key: 'n', className: 'dsh-usage-settings-fieldname' }, '输入(未命中缓存)'),
                  React.createElement('input', {
                    key: 'i', type: 'number', min: '0', step: '0.01',
                    className: 'dsh-usage-settings-input', value: draft.inputPerM,
                    onChange: (event) => setDraft({ ...draft, inputPerM: event.target.value }),
                  }),
                ]),
                React.createElement('label', { key: 'l2', className: 'dsh-usage-settings-field' }, [
                  React.createElement('span', { key: 'n', className: 'dsh-usage-settings-fieldname' }, '输出'),
                  React.createElement('input', {
                    key: 'i', type: 'number', min: '0', step: '0.01',
                    className: 'dsh-usage-settings-input', value: draft.outputPerM,
                    onChange: (event) => setDraft({ ...draft, outputPerM: event.target.value }),
                  }),
                ]),
                React.createElement('label', { key: 'l3', className: 'dsh-usage-settings-field' }, [
                  React.createElement('span', { key: 'n', className: 'dsh-usage-settings-fieldname' }, '缓存命中'),
                  React.createElement('input', {
                    key: 'i', type: 'number', min: '0', step: '0.01',
                    className: 'dsh-usage-settings-input', value: draft.cachePerM,
                    onChange: (event) => setDraft({ ...draft, cachePerM: event.target.value }),
                  }),
                ]),
                saveMsg === null ? null : React.createElement('div', { key: 'msg', className: 'dsh-usage-settings-msg' }, saveMsg),
                React.createElement('div', { key: 'actions', className: 'dsh-usage-settings-actions' }, [
                  React.createElement('button', {
                    key: 'save', type: 'button', className: 'dsh-usage-settings-btn dsh-usage-settings-btn-primary',
                    disabled: saving, onClick: savePrice,
                  }, saving ? '保存中…' : '保存'),
                  React.createElement('button', {
                    key: 'reset', type: 'button', className: 'dsh-usage-settings-btn',
                    disabled: saving, onClick: resetPrice,
                  }, '还原为默认'),
                ]),
              ]),
            ])
        return React.createElement('div', { className: 'dsh-usage-settings' }, [
          React.createElement('div', { key: 'row', className: 'dsh-usage-settings-row' }, [
            React.createElement('div', { key: 'cost', className: 'dsh-usage-settings-cell' }, [
              React.createElement('div', { key: 'l', className: 'dsh-usage-settings-label' }, '本月花费'),
              React.createElement('div', { key: 'v', className: 'dsh-usage-settings-value' },
                cost === null ? '—' : fmtCost(cost.total ?? 0, cost.currency ?? '¥')),
            ]),
            React.createElement('div', { key: 'tokens', className: 'dsh-usage-settings-cell' }, [
              React.createElement('div', { key: 'l', className: 'dsh-usage-settings-label' }, '本月 tokens'),
              React.createElement('div', { key: 'v', className: 'dsh-usage-settings-value' },
                data === null ? '—' : fmtTokens(data.total ?? 0)),
            ]),
            React.createElement('div', { key: 'src', className: 'dsh-usage-settings-cell' }, [
              React.createElement('div', { key: 'l', className: 'dsh-usage-settings-label' }, '价格来源'),
              React.createElement('div', { key: 'v', className: 'dsh-usage-settings-value dsh-usage-settings-src' }, sourceText),
            ]),
          ]),
          React.createElement('div', { key: 'search', className: 'dsh-usage-settings-search' }, [
            React.createElement('input', {
              key: 'q', type: 'search', placeholder: '搜索模型(如 deepseek-v4-flash / grok)…',
              className: 'dsh-usage-settings-input dsh-usage-settings-q', value: query,
              onChange: (event) => setQuery(event.target.value),
            }),
          ]),
          React.createElement('div', { key: 'listhead', className: 'dsh-usage-settings-listhead' }, [
            React.createElement('span', { key: 'm', className: 'dsh-usage-settings-listcol' }, '模型'),
            React.createElement('span', { key: 's', className: 'dsh-usage-settings-listcol' }, '价格来源'),
          ]),
          React.createElement('div', { key: 'list', className: 'dsh-usage-settings-list' },
            catalog === null
              ? React.createElement('div', { key: 'load', className: 'dsh-usage-settings-empty' }, '正在加载价格目录…')
              : filtered.length === 0
                ? React.createElement('div', { key: 'none', className: 'dsh-usage-settings-empty' }, '没有匹配的模型')
                : filtered.map((item) => React.createElement('button', {
                    key: item.name,
                    type: 'button',
                    className: 'dsh-usage-settings-rowbtn',
                    onClick: () => openDetail(item),
                  }, [
                    React.createElement('span', { key: 'n', className: 'dsh-usage-settings-listname' }, item.name),
                    React.createElement('span', { key: 's', className: 'dsh-usage-settings-listsrc' },
                      item.source === 'local' ? '本地覆盖' : item.source === 'official' ? '官网价' : '聚合价'),
                  ]))),
          React.createElement('div', { key: 'note', className: 'dsh-usage-settings-guide' }, [
            '点击模型可调整价格;金额 = tokens ÷ 1M × 单价,按每条消息的时间自动区分高峰/空闲(DeepSeek 官方价)。',
          ]),
          error === null ? null : React.createElement('div', { key: 'err', className: 'dsh-usage-settings-err' },
            '用量数据获取失败:' + error),
          detailModal,
        ])
      }

      // conversation.view 视图环:chat(0)/轨迹(10)右侧的「用量」Tab。
      // 宿主按 entry 投影 Tab 并只渲染激活视图;卸载时宿主回退 chat。
      slots.inject('conversation.view', () => slots.register(
        {
          name: 'conversation.view',
          id: 'usage',
          order: 20,
          label: '用量',
          registrant: 'dizzy-dsh-usage-card',
        },
        () => React.createElement(UsageView)
      ))

      // 设置页「用量统计」段:金额概览 + 价格源状态 + 配置指引。
      slots.inject('settings.section', () => slots.register(
        {
          name: 'settings.section',
          id: 'usage-card',
          order: 60,
          label: '用量统计',
          registrant: 'dizzy-dsh-usage-card',
        },
        () => React.createElement(UsageSettingsSection)
      ))

      return () => {
        style.remove()
      }
    }

    exports.apply = apply
    return module.exports
  },
})
