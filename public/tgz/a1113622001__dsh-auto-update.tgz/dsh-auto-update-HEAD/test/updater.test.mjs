import { test } from "node:test";
import assert from "node:assert/strict";
import { resolve } from "node:path";
import {
  parseVersion,
  compareVersions,
  isNewerVersion,
  npmPrefixForInstall,
  helperScriptPath,
  isDshInstall,
  readVersionFromInstall,
  PACKAGE_NAME,
  isWindows,
  npmCommand,
  isContainer,
  resolveRelaunchCommand,
} from "../lib/updater.js";

test("parseVersion parses plain and prerelease versions", () => {
  assert.deepEqual(parseVersion("1.2.3"), { major: 1, minor: 2, patch: 3, pre: null });
  assert.deepEqual(parseVersion("0.1.0-rc.6"), { major: 0, minor: 1, patch: 0, pre: ["rc", "6"] });
  assert.deepEqual(parseVersion("v2.0.0-beta.1"), { major: 2, minor: 0, patch: 0, pre: ["beta", "1"] });
});

test("parseVersion rejects malformed input", () => {
  for (const bad of [null, undefined, 42, "", "1.2", "1.2.3.4", "a.b.c", "1..2"]) {
    assert.equal(parseVersion(bad), null, `expected null for ${JSON.stringify(bad)}`);
  }
});

test("compareVersions orders releases and prereleases", () => {
  // major / minor / patch precedence
  assert.ok(compareVersions("2.0.0", "1.9.9") > 0);
  assert.ok(compareVersions("1.10.0", "1.9.9") > 0);
  assert.ok(compareVersions("1.2.3", "1.2.2") > 0);
  assert.equal(compareVersions("1.2.3", "1.2.3"), 0);
  // a release beats its own prerelease
  assert.ok(compareVersions("1.2.3", "1.2.3-rc.1") > 0);
  assert.ok(compareVersions("1.2.3-rc.1", "1.2.3") < 0);
  // prerelease ordering
  assert.ok(compareVersions("0.1.0-rc.7", "0.1.0-rc.6") > 0);
  assert.ok(compareVersions("0.1.0-alpha", "0.1.0-beta") < 0);
  // malformed returns NaN
  assert.ok(Number.isNaN(compareVersions("1.2.3", "nope")));
});

test("isNewerVersion only returns true for a strictly newer candidate", () => {
  assert.equal(isNewerVersion("0.1.0-rc.7", "0.1.0-rc.6"), true);
  assert.equal(isNewerVersion("1.2.3", "1.2.3"), false);
  assert.equal(isNewerVersion("1.2.2", "1.2.3"), false);
  assert.equal(isNewerVersion("1.2.3-rc.1", "1.2.3"), false); // release > prerelease
  assert.equal(isNewerVersion("garbage", "1.2.3"), false);
});

test("npmPrefixForInstall unwraps install root to the npm prefix", () => {
  const root = resolve("/node_modules/@deepseek-ai/dsh");
  // npmPrefixForInstall = dirname(dirname(dirname(root)))
  // For <prefix>/node_modules/@deepseek-ai/dsh this unwraps to the prefix.
  const prefix = npmPrefixForInstall(root);
  assert.equal(prefix, resolve("/"));
  // A deeper global install root also unwraps to its prefix.
  const deep = resolve("/opt/lib/node_modules/@deepseek-ai/dsh");
  assert.equal(npmPrefixForInstall(deep), resolve("/opt/lib"));
});

test("helperScriptPath resolves to bin/apply-update.js", () => {
  const p = helperScriptPath();
  assert.ok(p.endsWith(`${/^win/.test(process.platform) ? "\\" : "/"}apply-update.js`), p);
  assert.match(p, /apply-update\.js$/);
});

test("isDshInstall and readVersionFromInstall work on a real package root", () => {
  // The plugin's own root is not a dsh install, so these must be false/null.
  assert.equal(isDshInstall("."), false);
  assert.equal(readVersionFromInstall("."), null);
});

test("platform helpers are booleans/strings", () => {
  assert.equal(typeof isWindows(), "boolean");
  assert.ok(typeof npmCommand() === "string" && npmCommand().length > 0);
  assert.equal(PACKAGE_NAME, "@deepseek-ai/dsh");
});

test("isContainer detects container environment or honors override", () => {
  const orig = process.env.DSH_FORCE_CONTAINER;
  try {
    process.env.DSH_FORCE_CONTAINER = "1";
    assert.equal(isContainer(), true);
    process.env.DSH_FORCE_CONTAINER = "0";
    assert.equal(isContainer(), false);
  } finally {
    if (orig !== undefined) process.env.DSH_FORCE_CONTAINER = orig;
    else delete process.env.DSH_FORCE_CONTAINER;
  }
});

test("resolveRelaunchCommand handles default and manifest structures", () => {
  assert.deepEqual(resolveRelaunchCommand(null), { command: "dsh", args: ["web"] });
  assert.deepEqual(resolveRelaunchCommand({ relaunchArgs: ["profile", "start"] }), {
    command: "dsh",
    args: ["profile", "start"],
  });
});
