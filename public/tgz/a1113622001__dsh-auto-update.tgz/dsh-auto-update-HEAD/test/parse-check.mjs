import { test } from "node:test";
import assert from "node:assert/strict";
import {
  parseVersion,
  isNewerVersion,
  npmPrefixForInstall,
  helperScriptPath,
} from "../lib/updater.js";

// Exercises the npm pack --json output parsing branch and the semver helpers
// against real-world shapes used during staging.
test("parses a real npm pack --json output shape", () => {
  const out =
    '[{"id":"@deepseek-ai/dsh@0.1.0-rc.6","name":"@deepseek-ai/dsh","version":"0.1.0-rc.6","filename":"deepseek-ai-dsh-0.1.0-rc.6.tgz","entryCount":20}]';
  const parsed = JSON.parse(out.trim());
  const filename =
    Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0]?.filename === "string"
      ? parsed[0].filename
      : null;
  assert.equal(filename, "deepseek-ai-dsh-0.1.0-rc.6.tgz");
});

test("parseVersion parses a prerelease like the pack output", () => {
  assert.deepEqual(parseVersion("0.1.0-rc.6"), {
    major: 0,
    minor: 1,
    patch: 0,
    pre: ["rc", "6"],
  });
});

test("npmPrefixForInstall unwraps a Windows-style install root", () => {
  const root = "C:/Users/testuser/AppData/Roaming/npm/node_modules/@deepseek-ai/dsh";
  // npmPrefixForInstall is dirname(dirname(dirname(resolve(root)))); on
  // non-Windows resolve() prefixes the cwd, so we assert the normalized trailing segments.
  const prefix = npmPrefixForInstall(root).replace(/\\/g, "/");
  const expectedTail = ["AppData/Roaming/npm", "Roaming/npm"].some((seg) =>
    prefix.endsWith(seg),
  );
  assert.ok(expectedTail, `expected prefix to end with the npm dir, got: ${prefix}`);
});

test("helperScriptPath points at the apply helper", () => {
  const p = helperScriptPath();
  assert.match(p, /apply-update\.js$/);
});

test("isNewerVersion on the rc series", () => {
  assert.equal(isNewerVersion("0.1.0-rc.7", "0.1.0-rc.6"), true);
  assert.equal(isNewerVersion("0.1.0-rc.6", "0.1.0-rc.6"), false);
  assert.equal(isNewerVersion("0.1.0", "0.1.0-rc.6"), true);
});
