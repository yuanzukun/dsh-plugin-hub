#!/usr/bin/env node
/**
 * 模型资产构建：models/*.json → shared/models.generated.js
 *
 * 规则（见 docs/MODEL_ASSET_SPEC.md）：
 *   - models/*.json 是模型定义的唯一来源，单模型单文件、字段扁平；
 *   - 生成 shared/models.generated.js，contract.js 只做 re-export；
 *   - 生成结果不含时间戳，保证相同输入产出相同文件（git diff 只反映模型变化）。
 *
 * 用法：
 *   node tools/build-assets.mjs          生成 shared/models.generated.js
 *   node tools/build-assets.mjs --check  只校验生成文件是否与 models/ 同步
 */

import { readFile, readdir, writeFile } from 'node:fs/promises'
import { dirname, join, relative } from 'node:path'
import { fileURLToPath, pathToFileURL } from 'node:url'

import { PIPELINE_ACCEL_KEYS, SETTINGS } from '../shared/contract.js'

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)))
const MODELS_DIR = join(ROOT, 'models')

const GENERATED_REL = 'shared/models.generated.js'

/** 每个模型文件必须存在的顶层字段。只做存在性检查，不搞字段白名单。 */
const REQUIRED_FIELDS = [
  'id',
  'order',
  'label',
  'family',
  'short',
  'description',
  'repo',
  'params',
  'license',
  'licenseKind',
  'gated',
  'gpus',
  'tier',
  'size',
  'steps',
  'cfg',
  'negativeHint',
  'promptStyle',
  'qualityPrefix',
  'sizeOptions',
  'runtime',
  'supportsNegative',
  'supportsReference',
  'pipeline',
  'measured',
]

/** measured 里允许出现的实测指标；缺失或 null 表示尚未实测。 */
const MEASURED_FIELDS = ['peakVramMb', 'loadSeconds', 'steadySeconds', 'downloadGb']

/**
 * 提示词配方：模型按什么口径理解提示词。`danbooru` 逗号标签、`natural` 自然语言段落、
 * `concise` 简短短语；`lib/intent.js` 据此动态约束宿主模型整理出的英文提示词。
 */
const PROMPT_STYLES = ['danbooru', 'natural', 'concise']

function fail(message) {
  throw new Error(message)
}

/** 读取并校验 models/ 下的全部资产，按 order 排序返回。 */
export async function loadModels(modelsDir = MODELS_DIR) {
  let entries
  try {
    entries = await readdir(modelsDir, { withFileTypes: true })
  } catch (error) {
    fail(`无法读取 models 目录：${error?.message ?? error}`)
  }

  const files = entries
    .filter((entry) => entry.isFile() && entry.name.endsWith('.json') && !entry.name.startsWith('.'))
    .map((entry) => entry.name)
    .sort()
  if (files.length === 0) fail('models/ 下没有任何模型 JSON 文件')

  const models = []
  const seenIds = new Set()
  const seenOrders = new Set()
  for (const file of files) {
    const path = join(modelsDir, file)
    let model
    try {
      model = JSON.parse(await readFile(path, 'utf8'))
    } catch (error) {
      fail(`${file} 不是合法 JSON：${error?.message ?? error}`)
    }

    const where = relative(ROOT, path)
    if (!model || typeof model !== 'object' || Array.isArray(model)) fail(`${where} 必须是 JSON 对象`)
    for (const field of REQUIRED_FIELDS) {
      if (!(field in model)) fail(`${where} 缺少字段 ${field}`)
    }

    const expectedId = file.replace(/\.json$/, '')
    if (model.id !== expectedId) fail(`${where} 的 id（${model.id}）必须与文件名（${expectedId}）一致`)
    if (seenIds.has(model.id)) fail(`模型 id 重复：${model.id}`)
    seenIds.add(model.id)

    if (!Number.isFinite(model.order)) fail(`${where} 的 order 必须是数字`)
    if (seenOrders.has(model.order)) fail(`模型 order 重复：${model.order}（用于决定预设顺序，必须唯一）`)
    seenOrders.add(model.order)

    // 展示字段：家族、触发器短名与中英双语定位描述。卡面直接消费这三项，缺一不可。
    if (typeof model.family !== 'string' || !model.family.trim()) {
      fail(`${where} 的 family 必须是非空字符串（如 SDXL / FLUX）`)
    }
    if (typeof model.short !== 'string' || !model.short.trim()) {
      fail(`${where} 的 short 必须是非空字符串（触发器用的短名）`)
    }
    if (!model.description || typeof model.description !== 'object' || Array.isArray(model.description)) {
      fail(`${where} 的 description 必须是 { zh, en } 对象`)
    }
    for (const lang of ['zh', 'en']) {
      if (typeof model.description[lang] !== 'string' || !model.description[lang].trim()) {
        fail(`${where} 的 description.${lang} 必须是非空字符串`)
      }
    }

    if (model.runtime !== 'default') {
      fail(`${where} 的 runtime 目前只支持 "default"；特殊运行时模型等后续阶段再开放`)
    }
    if (!model.pipeline || typeof model.pipeline !== 'object' || Array.isArray(model.pipeline)) {
      fail(`${where} 的 pipeline 必须是对象`)
    }
    if (typeof model.pipeline.loader !== 'string' || !model.pipeline.loader) {
      fail(`${where} 的 pipeline.loader 必须是非空字符串`)
    }
    // 推理加速开关（阶段十五 Phase C1 脚手架）：可选对象，只允许契约登记过的布尔键；
    // 缺省（整块省略）表示全部关闭，远端代码路径必须与改造前逐字一致。
    // 未知键直接失败而不是静默忽略：开关名写错会让「以为开了、其实没开」的 A/B 数据失真。
    if (model.pipeline.accel !== undefined) {
      const accel = model.pipeline.accel
      if (!accel || typeof accel !== 'object' || Array.isArray(accel)) {
        fail(`${where} 的 pipeline.accel 必须是对象（允许的键：${PIPELINE_ACCEL_KEYS.join(' / ')}）`)
      }
      const unknown = Object.keys(accel).filter((key) => !PIPELINE_ACCEL_KEYS.includes(key))
      if (unknown.length) {
        fail(
          `${where} 的 pipeline.accel 含未知键 ${unknown.join(', ')}` +
            `（允许的键：${PIPELINE_ACCEL_KEYS.join(' / ')}）`,
        )
      }
      for (const key of Object.keys(accel)) {
        if (typeof accel[key] !== 'boolean') fail(`${where} 的 pipeline.accel.${key} 必须是布尔值`)
      }
    }
    if (!model.measured || typeof model.measured !== 'object' || Array.isArray(model.measured)) {
      fail(`${where} 的 measured 必须是对象（允许指标为 null，表示尚未实测）`)
    }
    for (const field of MEASURED_FIELDS) {
      const value = model.measured[field]
      if (value !== null && !Number.isFinite(value)) {
        fail(`${where} 的 measured.${field} 必须是数字或 null`)
      }
    }
    if (
      model.measured.downloadGb !== null &&
      model.pipeline.downloadGb !== undefined &&
      model.pipeline.downloadGb !== null &&
      model.measured.downloadGb !== model.pipeline.downloadGb
    ) {
      fail(
        `${where} 的 pipeline.downloadGb (${model.pipeline.downloadGb}) 与 measured.downloadGb (${model.measured.downloadGb}) 不一致`,
      )
    }
    if (!Array.isArray(model.sizeOptions) || model.sizeOptions.length === 0) {
      fail(`${where} 的 sizeOptions 必须是非空数组`)
    }
    // 提示词配方：意图解析据此切换英文提示词的书写口径；qualityPrefix 允许为空串。
    if (typeof model.promptStyle !== 'string' || !PROMPT_STYLES.includes(model.promptStyle)) {
      fail(`${where} 的 promptStyle 必须是 ${PROMPT_STYLES.join(' | ')} 之一`)
    }
    if (typeof model.qualityPrefix !== 'string') {
      fail(`${where} 的 qualityPrefix 必须是字符串（没有质量词前缀时写空串）`)
    }
    // 负向提示词能力：管线是否真的消费 negative_prompt（不是「cfg 是否 > 0」）。
    // diffusers 的 Flux2Pipeline 没有 negative_prompt 参数，所以 flux2 必须显式标 false；
    // 旧资产缺省时按 false 处理，避免界面/助手把无效参数当成有效能力。
    if (typeof model.supportsNegative !== 'boolean') {
      fail(`${where} 的 supportsNegative 必须是布尔值（管线是否真的消费 negative_prompt）`)
    }
    // 算力来源能力位（可选）：只能在指定远端后端运行的模型显式声明（如 9B 级权重只在
    // Colab A100/G4 跑得动，Kaggle 2×T4 必然 OOM）。缺省 = 契约 SETTINGS.providers 全可用，
    // 与历史资产语义一致；显式给出时必须是取值域内的非空、无重复数组，避免「写错来源名」
    // 让门控静默失效（漏掉的来源会被当成全可用）。
    if (model.providers !== undefined) {
      const providers = model.providers
      const allowed = SETTINGS.providers
      if (!Array.isArray(providers) || providers.length === 0) {
        fail(`${where} 的 providers 必须是非空数组（允许值：${allowed.join(' / ')}）`)
      }
      const unknown = providers.filter((id) => !allowed.includes(id))
      if (unknown.length > 0) {
        fail(`${where} 的 providers 含未知来源 ${unknown.join(', ')}（允许值：${allowed.join(' / ')}）`)
      }
      if (new Set(providers).size !== providers.length) {
        fail(`${where} 的 providers 有重复项：${providers.join(', ')}`)
      }
    }
    // 图生图（垫图重绘）能力：可以缺省（缺省按 false 归一），显式给出时必须是布尔值。
    // 只有整套 diffusers 管线能用 AutoPipelineForImage2Image.from_pipe 复用的模型才能标 true。
    if ('supportsImg2Img' in model && typeof model.supportsImg2Img !== 'boolean') {
      fail(`${where} 的 supportsImg2Img 必须是布尔值（缺省按 false 处理）`)
    }
    // 模型原生参考生图能力（阶段十五 Phase C1）：必填布尔值，语义是「基础管线原生接收
    // image=[PIL...] 参考条件，宽高仍由请求决定，没有 strength / 蒙版」。
    // 与 supportsImg2Img 是两条不同的请求形状（`references` 数组 vs `reference` 单图），
    // 同一预设同时标 true 会让 Host / 客户端无法判断该走哪条路径，因此本轮要求互斥；
    // 未来某个模型两者都支持时，再放开这条联合约束并给客户端补「优先走哪条」的口径。
    if (typeof model.supportsReference !== 'boolean') {
      fail(
        `${where} 的 supportsReference 必须是布尔值（原生参考生图能力；不支持时写 false）`,
      )
    }
    if (model.supportsReference === true && model.supportsImg2Img === true) {
      fail(
        `${where} 同时标了 supportsReference 与 supportsImg2Img：两者是互斥的请求形状` +
          '（原生参考图列表 vs 单图垫图重绘），Host / 客户端无法判断该走哪条路径；' +
          '本轮要求一个预设只声明一种参考能力',
      )
    }
    // 中文提示词原生理解能力：可以缺省（缺省按 false 归一），显式给出时必须是布尔值。
    if ('supportsChinese' in model && typeof model.supportsChinese !== 'boolean') {
      fail(`${where} 的 supportsChinese 必须是布尔值（缺省按 false 处理）`)
    }
    // 局部重绘（Inpaint）能力：能否用 AutoPipelineForInpainting.from_pipe 复用同一底座。
    // 首期只对 SDXL 家族开放，且必须同时支持图生图（蒙版叠在参考图上）。
    if ('supportsInpaint' in model && typeof model.supportsInpaint !== 'boolean') {
      fail(`${where} 的 supportsInpaint 必须是布尔值（缺省按 false 处理）`)
    }
    if (model.supportsInpaint === true && model.supportsImg2Img !== true) {
      fail(`${where} 标了 supportsInpaint 却没标 supportsImg2Img：局部重绘必须基于参考图`)
    }
    // 专用 inpaint 权重（inpaintOnly）：只用于局部重绘，不能文生图/纯图生图。
    // 必须同时声明 supportsInpaint，且 pipeline 里要标 nativeInpaint（daemon 据此加载专用管线）。
    if ('inpaintOnly' in model && typeof model.inpaintOnly !== 'boolean') {
      fail(`${where} 的 inpaintOnly 必须是布尔值（缺省按 false 处理）`)
    }
    if (model.inpaintOnly === true) {
      if (model.supportsInpaint !== true) {
        fail(`${where} 标了 inpaintOnly 却没标 supportsInpaint`)
      }
      if (!model.pipeline || model.pipeline.nativeInpaint !== true) {
        fail(`${where} 标了 inpaintOnly 时 pipeline.nativeInpaint 必须为 true`)
      }
    }
    // 可调步数档位范围：fast 模型通常固定步数可省略或为 null；usable 模型提供 { min, max, step, fast, balanced, fine }。
    if (model.stepRange !== undefined && model.stepRange !== null) {
      const r = model.stepRange
      if (typeof r !== 'object' || Array.isArray(r)) fail(`${where} 的 stepRange 必须是对象或 null`)
      const keys = ['min', 'max', 'step', 'fast', 'balanced', 'fine']
      for (const k of keys) {
        if (!Number.isFinite(r[k])) fail(`${where} 的 stepRange.${k} 必须是数字`)
      }
      if (!(r.step > 0 && r.min <= r.fast && r.fast <= r.balanced && r.balanced <= r.fine && r.fine <= r.max)) {
        fail(`${where} 的 stepRange 数值序关系非法（需满足 step>0 且 min<=fast<=balanced<=fine<=max）`)
      }
      if (model.steps < r.min || model.steps > r.max) {
        fail(`${where} 的默认 steps=${model.steps} 超出 stepRange [${r.min}, ${r.max}]`)
      }
    }

    models.push(model)
  }

  return models.sort((a, b) => a.order - b.order || a.id.localeCompare(b.id))
}

/** 公开预设视图：在预设基础上剔除仅远端消费的 pipeline，供 Client 安全打包。 */
function projectPublicPresets(presets) {
  return presets.map(({ pipeline, ...rest }) => rest)
}

/** 契约使用的预设视图：模型事实字段 + 卡面展示字段（family / short / description）。 */
function projectPresets(models) {
  return models.map((model) => ({
    id: model.id,
    label: model.label,
    family: model.family,
    short: model.short,
    description: model.description,
    repo: model.repo,
    params: model.params,
    license: model.license,
    licenseKind: model.licenseKind,
    gated: model.gated,
    gpus: model.gpus,
    downloadGb: model.measured.downloadGb,
    size: model.size,
    steps: model.steps,
    stepRange: model.stepRange || null,
    cfg: model.cfg,
    peakVramMb: model.measured.peakVramMb,
    loadSeconds: model.measured.loadSeconds,
    steadySeconds: model.measured.steadySeconds,
    tier: model.tier,
    negativeHint: model.negativeHint,
    promptStyle: model.promptStyle,
    qualityPrefix: model.qualityPrefix,
    // 中文提示词原生理解能力：面板据此显示语言能力标记与英文提醒，助手决定是否免翻译。
    supportsChinese: model.supportsChinese === true,
    // 图生图（垫图重绘）能力：客户端据此决定是否允许放参考图；daemon 侧还会按 loader 兜底。
    supportsImg2Img: model.supportsImg2Img === true,
    // 模型原生参考生图能力：客户端据此开放「1~N 张参考图」槽位；daemon 侧按 loader 白名单兜底。
    supportsReference: model.supportsReference === true,
    // 局部重绘（Inpaint）能力：客户端据此决定是否开放涂抹蒙版；daemon 侧同样按 loader 兜底。
    supportsInpaint: model.supportsInpaint === true,
    // 专用局部重绘权重：只能带蒙版使用（不做文生图 / 纯图生图），客户端与 daemon 都要拦。
    inpaintOnly: model.inpaintOnly === true,
    // 负向提示词能力：客户端据此显隐「排除项」、助手据此决定是否输出 negative。
    supportsNegative: model.supportsNegative === true,
    // 算力来源能力位（可选）：显式声明时才输出该字段，缺省 = Kaggle / Colab 都可用。
    // 未声明的模型不写空数组 / null，保证既有 10 个模型的对外快照逐字不变。
    ...(Array.isArray(model.providers) ? { providers: [...model.providers] } : {}),
    sizeOptions: model.sizeOptions,
    pipeline: model.pipeline,
  }))
}

/** 渲染生成文件内容（纯函数；供 check-contract 复用）。 */
export function renderGenerated(models) {
  const banner = [
    '/**',
    ' * 本文件由 tools/build-assets.mjs 从 models/*.json 生成，请勿手改。',
    ' * 修改模型请编辑 models/<id>.json，然后运行 npm run models:build。',
    ' */',
    '',
  ].join('\n')
  const presets = projectPresets(models)
  const publicJson = JSON.stringify(projectPublicPresets(presets), null, 2)
  const presetsJson = JSON.stringify(presets, null, 2)
  return `${banner}export const PUBLIC_PRESETS = ${publicJson}\n\nexport const PRESETS = ${presetsJson}\n`
}

/** 读取生成文件内容；不存在返回 null。 */
export async function readGenerated() {
  try {
    return await readFile(join(ROOT, GENERATED_REL), 'utf8')
  } catch {
    return null
  }
}

/** 生成或校验；返回 { ok, models, wrote }，失败抛错。 */
async function buildAssets({ check = false } = {}) {
  const models = await loadModels()
  const expected = renderGenerated(models)
  if (check) {
    const actual = await readGenerated()
    if (actual === expected) return { ok: true, models, wrote: false }
    const reason = actual === null ? '生成文件不存在' : '生成文件与 models/ 不同步'
    fail(`${reason}：请运行 npm run models:build`)
  }
  await writeFile(join(ROOT, GENERATED_REL), expected, 'utf8')
  return { ok: true, models, wrote: true }
}

async function main() {
  const check = process.argv.includes('--check')
  const result = await buildAssets({ check })
  const ids = result.models.map((model) => model.id).join(', ')
  if (check) {
    console.log(`模型资产与生成文件一致（${result.models.length} 个：${ids}）`)
    return
  }
  console.log(`已生成 ${GENERATED_REL}（${result.models.length} 个模型：${ids}）`)
}

const invokedDirectly = process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href
if (invokedDirectly) {
  main().catch((error) => {
    console.error(`模型资产构建失败：${error?.message ?? error}`)
    process.exitCode = 1
  })
}