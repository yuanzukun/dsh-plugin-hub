/**
 * 测试专用入口：在发布产物之外额外暴露内部实现，供渲染测试挂载组件。
 *
 * 这个文件只在 `node build.mjs --test` 时打包成 test/.build/client.test.js，
 * 发布产物 client.js 由 src/index.js 打包，不含任何测试出口。
 */

export { inject, apply } from './index.js'

import * as dict from './dict/index.js'
import * as theme from './theme.js'
import * as constants from './constants.js'
import * as logic from './logic/index.js'
import * as runtime from './runtime.js'
import * as api from './api.js'
import * as i18n from './i18n.js'
import { StatusChip } from './components/StatusChip.js'
import { Studio } from './studio/Studio.jsx'
import { StudioIcon } from './studio/StudioIcon.jsx'
import { Gallery } from './studio/Gallery.jsx'
import { Filmstrip } from './studio/Filmstrip.jsx'
import { GuidanceCard } from './studio/GuidanceCard.jsx'
import { PipelineBar } from './studio/PipelineBar.jsx'
import { QueueNotice } from './studio/QueueNotice.jsx'
import { Rail } from './studio/Rail.jsx'
import { ChatPanel } from './studio/ChatPanel.jsx'
import { Stage } from './studio/Stage.jsx'
import { TopBar } from './studio/TopBar.jsx'
import { LogsDrawer } from './studio/LogsDrawer.jsx'
import { SettingsDrawer } from './studio/SettingsDrawer.jsx'
import { ModelCardPicker } from './studio/ModelCardPicker.jsx'
import { useChatThread } from './studio/hooks/useChatThread.js'
import { useKaggleLogin } from './studio/hooks/useKaggleLogin.js'
import { useStudioUi } from './studio/hooks/useStudioUi.js'
import { useStudio } from './studio/useStudio.js'

export const __test = {
  dict,
  theme,
  constants,
  logic,
  runtime,
  api,
  i18n,
  // 域 hook 直接暴露给渲染测试：用最小 Harness 组件挂载，断言真实状态流转。
  hooks: {
    useChatThread,
    useKaggleLogin,
    useStudioUi,
    useStudio,
  },
  components: {
    StatusChip,
    Studio,
    StudioIcon,
    Gallery,
    Filmstrip,
    GuidanceCard,
    PipelineBar,
    QueueNotice,
    Rail,
    ChatPanel,
    Stage,
    TopBar,
    LogsDrawer,
    SettingsDrawer,
    ModelCardPicker,
  },
}