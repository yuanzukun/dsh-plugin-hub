import { describe, expect, it } from 'vitest'

import { systemEvidenceContainsQuote } from '../src/project/system-evidence-quotes.js'

describe('systemEvidenceContainsQuote', () => {
  it('matches raw nested string values without JSON escaping artifacts', () => {
    const quote = 'FeignClient(value="sfa-backend")'
    const evidence = { records: [{ conflicts: [`uses ${quote} as an internal contract`] }] }

    expect(systemEvidenceContainsQuote(evidence, quote)).toBe(true)
    expect(systemEvidenceContainsQuote(evidence, 'FeignClient(value=\\"sfa-backend\\")')).toBe(false)
  })
})
