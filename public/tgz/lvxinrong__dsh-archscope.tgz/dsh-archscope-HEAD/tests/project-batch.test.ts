import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'

import type { Context } from '@deepseek-ai/cordis'
import { describe, expect, it } from 'vitest'

import type { ProjectScanResult } from '../src/contracts/project-scan.js'
import { SYSTEM_SCAN_PROTOCOL } from '../src/contracts/system-scan.js'
import { ProjectBatchCoordinator } from '../src/project/batch.js'
import type { ProjectScanCoordinator } from '../src/project/coordinator.js'
import { createProjectScanMessage, projectProfileArtifactPath } from '../src/tools/project-scan.js'

function result(projectKey: string, status: ProjectScanResult['status']): ProjectScanResult {
  return {
    runId: 'project-' + projectKey + '-20260101000000-aaaaaaaa', projectKey, projectDir: projectKey,
    specialization: projectKey === 'web' ? 'web-vue' : 'java-spring-backend',
    projectRevision: status === 'COMPLETED' ? 'P0001' : 'PENDING', sourceSystemRevision: 'S0001', status,
    gate: status === 'COMPLETED' ? 'READY' : 'BLOCKED', validation: status === 'COMPLETED' ? 'PASSED' : 'NOT_RUN',
    indexStatus: 'FRESH', evidenceStatus: 'COLLECTED', scopeViolationCount: 0, conflictCount: 0,
    blockingConflictCount: 0, reconciliationStatus: 'NOT_REQUIRED', outputDirectory: 'archscope_docs', reused: false,
  }
}

describe('project batch coordinator', () => {
  it('reports current artifacts only for completed publications', () => {
    const completed = result('api', 'COMPLETED')
    const blocked = { ...result('api', 'BLOCKED'), projectRevision: 'P0003', validation: 'FAILED' as const }
    expect(projectProfileArtifactPath(completed)).toBe('archscope_docs/projects/api/00-project-profile.md')
    expect(projectProfileArtifactPath(blocked)).toBe('archscope_docs/runs/' + blocked.runId + '/project/00-project-profile.md')
    expect(createProjectScanMessage(blocked)).toContain('/runs/' + blocked.runId + '/project/00-project-profile.md')
  })

  it('uses one pinned system revision and aggregates isolated project writer results', async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), 'archscope-project-batch-'))
    const output = path.join(root, 'archscope_docs')
    const systemRunId = 'system-20260101000000-aaaaaaaa'
    const systemRoot = path.join(output, 'runs', systemRunId, 'system')
    await mkdir(systemRoot, { recursive: true })
    const projects = ['api', 'web'].map(projectKey => ({ projectKey, projectName: projectKey, projectDir: projectKey, gitHead: null, projectType: 'generic' as const, classificationEvidence: [], productionStatus: 'UNCONFIRMED' as const }))
    await Promise.all([
      writeFile(path.join(output, 'runs', 'latest.json'), JSON.stringify({ runId: systemRunId })),
      writeFile(path.join(output, 'runs', systemRunId, 'state.json'), JSON.stringify({ protocolVersion: SYSTEM_SCAN_PROTOCOL, runId: systemRunId, documentRevision: 'S0001', status: 'COMPLETED', validation: 'PASSED', gate: 'READY' })),
      writeFile(path.join(systemRoot, 'project-registry.json'), JSON.stringify({ protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt: new Date(0).toISOString(), workspaceRoot: '.', discoveryMaxDepth: 3, projectCount: 2, projects, skippedDirectories: [] })),
    ])
    const requests: Record<string, unknown>[] = []
    const ctx = { get(name: string) { return name === 'subagents' ? { getProvider() { return {} }, async start(_provider: string, request: Record<string, unknown>) { requests.push(request); return { result: Promise.resolve({ stopReason: 'completed', output: [] }), async dispose() {} } } } : undefined } } as unknown as Context
    const projectCoordinator = {
      async scan(projectKey: string, options: { sourceSystemRunId?: string, sourceSystemRevision?: string }) {
        expect(options).toMatchObject({ sourceSystemRunId: systemRunId, sourceSystemRevision: 'S0001' })
        return result(projectKey, 'AWAITING_PROJECT_SYNTHESIS')
      },
      async inspect(runId: string) { return result(runId.includes('api') ? 'api' : 'web', 'COMPLETED') },
    } as unknown as ProjectScanCoordinator
    const coordinator = new ProjectBatchCoordinator(ctx, { workspaceRoot: root, outputDirectory: 'archscope_docs', discoveryMaxDepth: 3, projectConcurrency: 2, registerCommand: false, registerSystemScanTool: false, registerProjectScanTool: false, registerStatusTool: false }, projectCoordinator)

    const batch = await coordinator.scan({ mode: 'ALL_ELIGIBLE' }, { agent: {} as never })

    expect(batch).toMatchObject({ status: 'COMPLETED', sourceSystemRevision: 'S0001', completedCount: 2, failedCount: 0, blockedCount: 0 })
    expect(batch.items.map(item => item.projectKey)).toEqual(['api', 'web'])
    expect(requests).toHaveLength(2)
    expect(requests[0]).toMatchObject({ maxDepth: 1, toolFilter: { allow: expect.arrayContaining(['archscope_finalize_project_synthesis']) } })
    const persisted = JSON.parse(await readFile(path.join(output, 'project-batches', batch.batchId, 'state.json'), 'utf8')) as { sourceSystemRevision: string }
    expect(persisted.sourceSystemRevision).toBe('S0001')
  })
})
