import { createHash } from 'node:crypto'

import { describe, expect, it } from 'vitest'

import { SYSTEM_SCAN_PROTOCOL, type IndexManifest, type ProjectRegistry, type SystemEvidenceBundle } from '../src/contracts/system-scan.js'
import { loadProtocolPack } from '../src/protocol/catalog.js'
import { buildSystemRelationCatalog } from '../src/system/relations.js'
import {
  buildSystemSynthesisPage,
  buildSystemSynthesisReadManifest,
  SYNTHESIS_PAGE_MAX_BYTES,
} from '../src/system/synthesis-pages.js'
import { buildSystemSynthesisContext, systemSynthesisInputDigest } from '../src/system/synthesis.js'

const generatedAt = '2026-08-20T00:00:00.000Z'
const registry: ProjectRegistry = {
  protocolVersion: SYSTEM_SCAN_PROTOCOL,
  generatedAt,
  workspaceRoot: '.',
  discoveryMaxDepth: 3,
  projectCount: 1,
  skippedDirectories: [],
  projects: [{ projectKey: 'service-a', projectName: 'service-a', projectDir: 'service-a', gitHead: null, projectType: 'java-project', classificationEvidence: ['pom.xml'], productionStatus: 'UNCONFIRMED' }],
}
const indexes: IndexManifest = {
  protocolVersion: SYSTEM_SCAN_PROTOCOL,
  generatedAt,
  records: [{ projectKey: 'service-a', projectDir: 'service-a', provider: 'codebase-memory-mcp', status: 'FRESH', reason: 'ready' }],
}

function evidence(payloadSize: number): SystemEvidenceBundle {
  return {
    protocolVersion: SYSTEM_SCAN_PROTOCOL,
    generatedAt,
    records: [{
      projectKey: 'service-a',
      projectDir: 'service-a',
      status: 'COLLECTED',
      projectTypeCandidates: ['java-service'],
      entries: ['entry-' + '界'.repeat(payloadSize)],
      outboundDependencies: [],
      relationCandidates: [{
        targetAlias: 'external-ledger',
        relationType: 'CONFIGURED_ENDPOINT',
        evidenceStrength: 'CONFIGURATION',
        description: 'Ledger integration candidate remains complete.',
        evidencePaths: ['application.yml'],
        runtimeStatus: 'UNCONFIRMED',
      }],
      dataAssets: [],
      infrastructure: [],
      aliases: [],
      capabilityCandidates: [],
      evidencePaths: ['application.yml'],
      conflicts: [],
      scopeStatus: 'CLEAN',
      scopeViolations: [],
    }],
  }
}

describe('lossless system synthesis paging', () => {
  it('keeps the bootstrap below the DSH spill threshold without injecting raw evidence or relations', async () => {
    const bundle = evidence(150_000)
    const relations = buildSystemRelationCatalog(registry, bundle)
    const inputDigest = systemSynthesisInputDigest(registry, indexes, bundle, relations)
    const manifest = buildSystemSynthesisReadManifest(inputDigest, registry, indexes, bundle, relations)
    const context = buildSystemSynthesisContext('run-paged', await loadProtocolPack(), registry, indexes, bundle, relations, manifest)

    expect(context).toMatchObject({ evidenceMode: 'PAGED', pageMaxBytes: SYNTHESIS_PAGE_MAX_BYTES, relationCount: 1 })
    expect(Buffer.byteLength(context.prompt, 'utf8')).toBeLessThan(45_000)
    expect(context.prompt).toContain('archscope_get_system_synthesis_page')
    expect(context.prompt).not.toContain('Ledger integration candidate remains complete.')
    expect(context.prompt).not.toContain('entry-界界界')
  })

  it('returns every relation record unchanged within a digest-protected byte budget', () => {
    const bundle = evidence(100)
    const relations = buildSystemRelationCatalog(registry, bundle)
    let cursor: string | null = '0:0'
    const jsonRecords: string[] = []
    while (cursor !== null) {
      const page = buildSystemSynthesisPage('run-relations', 'protocol-digest', 'RELATIONS', cursor, registry, indexes, bundle, relations)
      expect(page.pageBytes).toBeLessThanOrEqual(SYNTHESIS_PAGE_MAX_BYTES)
      expect(Buffer.byteLength(JSON.stringify(page), 'utf8')).toBeLessThan(45_000)
      jsonRecords.push(...page.items.map(item => item.json))
      cursor = page.nextCursor
    }

    expect(jsonRecords.map(value => JSON.parse(value))).toEqual(relations.records)
    expect(createHash('sha256').update('[' + jsonRecords.join(',') + ']').digest('hex')).toBe(
      buildSystemSynthesisReadManifest('input', registry, indexes, bundle, relations).datasets.find(item => item.dataset === 'RELATIONS')?.globalDigest,
    )
  })

  it('splits an oversized project record only at UTF-8 boundaries and reconstructs it byte-for-byte', () => {
    const bundle = evidence(80_000)
    const relations = buildSystemRelationCatalog(registry, bundle)
    let cursor: string | null = '0:0'
    let reconstructed = ''
    let expectedOffset = 0
    let digest = ''
    while (cursor !== null) {
      const page = buildSystemSynthesisPage('run-evidence', 'protocol-digest', 'PROJECT_EVIDENCE', cursor, registry, indexes, bundle, relations)
      expect(page.items).toHaveLength(1)
      expect(page.items[0]?.byteOffset).toBe(expectedOffset)
      expect(Buffer.byteLength(JSON.stringify(page), 'utf8')).toBeLessThan(45_000)
      reconstructed += page.items[0]?.json ?? ''
      expectedOffset += Buffer.byteLength(page.items[0]?.json ?? '', 'utf8')
      digest = page.items[0]?.recordDigest ?? digest
      cursor = page.nextCursor
    }

    const expected = JSON.stringify(bundle.records[0])
    expect(reconstructed).toBe(expected)
    expect(createHash('sha256').update(reconstructed).digest('hex')).toBe(digest)
    expect(JSON.parse(reconstructed)).toEqual(bundle.records[0])
  })
})
