import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { afterEach, describe, expect, it } from 'vitest'

import { collectSpringProjectFacts, deterministicStatistics } from '../src/project/deterministic-facts.js'

const roots: string[] = []
afterEach(async () => { await Promise.all(roots.splice(0).map(root => rm(root, { recursive: true, force: true }))) })

describe('collectSpringProjectFacts', () => {
  it('owns Spring filesystem and annotation metrics with explicit units and negative-claim rules', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'archscope-spring-facts-'))
    roots.push(root)
    const moduleRoot = path.join(root, 'demo-webapi')
    const javaRoot = path.join(moduleRoot, 'src', 'main', 'java', 'demo')
    const resources = path.join(moduleRoot, 'src', 'main', 'resources')
    await mkdir(path.join(resources, 'config'), { recursive: true })
    await mkdir(path.join(resources, 'mapper'), { recursive: true })
    await mkdir(javaRoot, { recursive: true })
    await mkdir(path.join(javaRoot, 'build'), { recursive: true })
    await writeFile(path.join(root, 'pom.xml'), '<project><modules><module>demo-webapi</module></modules></project>')
    await writeFile(path.join(moduleRoot, 'pom.xml'), '<project/>')
    await writeFile(path.join(resources, 'config', 'application-local.yaml'), 'spring:\n  application:\n    name: demo\n')
    await writeFile(path.join(resources, 'bootstrap.properties'), 'spring.cloud.nacos.server-addr=example\n')
    await writeFile(path.join(resources, 'mapper', 'OrderMapper.xml'), '<mapper/>')
    await writeFile(path.join(javaRoot, 'OrderController.java'), `
      @RestController
      class OrderController {
        @GetMapping("/orders") void list() {}
      }
    `)
    await writeFile(path.join(javaRoot, 'OrderMapper.java'), 'interface OrderMapper {}')
    await writeFile(path.join(javaRoot, 'OrderService.java'), `
      class OrderService {
        @DS("read") @Transactional void load() {}
        @XxlJob("sync") void sync() {}
        @Scheduled(cron="0 0 * * * ?") void schedule() {}
        // @DS("commented") must not be counted
        String marker = "@FeignClient in a literal";
      }
    `)
    await writeFile(path.join(javaRoot, 'RemoteClient.java'), '@FeignClient("remote") interface RemoteClient {}')
    await writeFile(path.join(javaRoot, 'build', 'AddressBuilder.java'), 'class AddressBuilder {}')

    const facts = await collectSpringProjectFacts(root, '2026-08-25T00:00:00.000Z')
    const metrics = new Map(facts.metrics.map(metric => [metric.metricId, metric.value]))

    expect(facts).toMatchObject({ scanStatus: 'COMPLETE', boundary: 'PROJECT_ROOT_ONLY', skippedFileCount: 0 })
    expect(facts.moduleManifests).toEqual(['demo-webapi/pom.xml', 'pom.xml'])
    expect(facts.configurationFiles).toEqual([
      'demo-webapi/src/main/resources/bootstrap.properties',
      'demo-webapi/src/main/resources/config/application-local.yaml',
    ])
    expect(metrics.get('SPRING-MAVEN-CHILD-MODULES')).toBe(1)
    expect(metrics.get('SPRING-CONFIG-FILES')).toBe(2)
    expect(metrics.get('SPRING-JAVA-SOURCE-FILES')).toBe(5)
    expect(metrics.get('SPRING-CONTROLLER-NAMED-FILES')).toBe(1)
    expect(metrics.get('SPRING-CONTROLLER-ANNOTATIONS')).toBe(1)
    expect(metrics.get('SPRING-MAPPER-XML-FILES')).toBe(1)
    expect(metrics.get('SPRING-DS-ANNOTATIONS')).toBe(1)
    expect(metrics.get('SPRING-FEIGN-ANNOTATIONS')).toBe(1)
    expect(metrics.get('SPRING-XXLJOB-ANNOTATIONS')).toBe(1)
    expect(metrics.get('SPRING-SCHEDULED-ANNOTATIONS')).toBe(1)
    const localConfigRule = facts.negativeClaimRules.find(rule => rule.ruleId === 'SPRING-NO-LOCAL-CONFIG')
    expect(localConfigRule?.allowed).toBe(false)
    const violatesLocalConfigRule = (claim: string) => localConfigRule?.forbiddenPatterns.some(pattern => new RegExp(pattern, 'iu').test(claim)) ?? false
    expect(violatesLocalConfigRule('无 logstash/logback 本地配置文件证据')).toBe(true)
    expect(violatesLocalConfigRule('bootstrap 引导，仓库内无 bootstrap 文本')).toBe(true)
    expect(violatesLocalConfigRule('无 Micrometer 自定义代码；确定性清单确认 logback.xml 文件存在')).toBe(false)
    expect(violatesLocalConfigRule('bootstrap.properties 文件存在，但内容无法确认')).toBe(false)
    expect(facts.negativeClaimRules.find(rule => rule.ruleId === 'SPRING-NO-DS-ANNOTATION')?.allowed).toBe(false)
    expect(deterministicStatistics(facts).every(metric => metric.authority === 'PARENT_DETERMINISTIC')).toBe(true)
  })

  it('owns internal Maven module dependency direction and ignores dependency management', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'archscope-maven-edges-'))
    roots.push(root)
    await mkdir(path.join(root, 'demo-api'), { recursive: true })
    await mkdir(path.join(root, 'demo-service'), { recursive: true })
    await mkdir(path.join(root, 'demo-webapi'), { recursive: true })
    await writeFile(path.join(root, 'pom.xml'), '<project><artifactId>demo-parent</artifactId><modules><module>demo-api</module><module>demo-service</module><module>demo-webapi</module></modules></project>')
    await writeFile(path.join(root, 'demo-api', 'pom.xml'), '<project><parent><artifactId>demo-parent</artifactId></parent><artifactId>demo-api</artifactId></project>')
    await writeFile(path.join(root, 'demo-service', 'pom.xml'), '<project><parent><artifactId>demo-parent</artifactId></parent><artifactId>demo-service</artifactId><dependencies><dependency><artifactId>demo-api</artifactId></dependency></dependencies></project>')
    await writeFile(path.join(root, 'demo-webapi', 'pom.xml'), '<project><parent><artifactId>demo-parent</artifactId></parent><artifactId>demo-webapi</artifactId><dependencyManagement><dependencies><dependency><artifactId>demo-api</artifactId></dependency></dependencies></dependencyManagement><dependencies><dependency><artifactId>demo-service</artifactId><scope>runtime</scope></dependency></dependencies></project>')

    const facts = await collectSpringProjectFacts(root, '2026-08-25T00:00:00.000Z')
    expect(facts.moduleDependencies).toEqual([
      { sourceModule: 'demo-service', targetModule: 'demo-api', sourceManifest: 'demo-service/pom.xml', targetManifest: 'demo-api/pom.xml', scope: 'COMPILE', optional: false },
      { sourceModule: 'demo-webapi', targetModule: 'demo-service', sourceManifest: 'demo-webapi/pom.xml', targetManifest: 'demo-service/pom.xml', scope: 'RUNTIME', optional: false },
    ])
  })
})
