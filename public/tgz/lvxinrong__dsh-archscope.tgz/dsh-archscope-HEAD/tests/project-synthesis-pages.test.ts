import { describe, expect, it } from 'vitest'
import { buildProjectSynthesisPage, buildProjectSynthesisReadManifest, createProjectSynthesisReadLedger, PROJECT_SYNTHESIS_PAGE_MAX_BYTES } from '../src/project/synthesis-pages.js'
import { PROJECT_SCAN_PROTOCOL, type ProjectSynthesisInputs } from '../src/contracts/project-scan.js'
import { SYSTEM_SCAN_PROTOCOL } from '../src/contracts/system-scan.js'

function input(): ProjectSynthesisInputs {
  const item = { summary: 'x'.repeat(PROJECT_SYNTHESIS_PAGE_MAX_BYTES * 2), evidencePaths: ['src/App.java'], confidence: 'DIRECT_SOURCE' as const }
  return {
    sourceSystemFactBase: '# system',
    project: { projectKey: 'demo', projectName: 'demo', projectDir: 'demo', gitHead: null, projectType: 'java-project', classificationEvidence: ['pom.xml'], productionStatus: 'UNCONFIRMED' },
    index: { projectKey: 'demo', projectDir: 'demo', provider: 'codebase-memory-mcp', status: 'FRESH', reason: 'ready', mcpProject: 'demo-index' },
    systemEvidence: { projectKey: 'demo', projectDir: 'demo', status: 'COLLECTED', projectTypeCandidates: ['java'], entries: [], outboundDependencies: [], dataAssets: [], infrastructure: [], aliases: [], capabilityCandidates: [], evidencePaths: ['pom.xml'], conflicts: [], scopeStatus: 'CLEAN', scopeViolations: [] },
    relatedRelations: [],
    deterministicFacts: {
      protocolVersion: 'archscope/project-deterministic-facts/v1', specialization: 'java-spring-backend', generatedAt: new Date(0).toISOString(),
      boundary: 'PROJECT_ROOT_ONLY', scanStatus: 'COMPLETE', scannedFileCount: 1, skippedFileCount: 0,
      moduleManifests: ['pom.xml'], moduleDependencies: [], configurationFiles: [], metrics: [], negativeClaimRules: [], coverageGaps: [],
    },
    projectEvidence: { protocolVersion: PROJECT_SCAN_PROTOCOL, generatedAt: new Date(0).toISOString(), projectKey: 'demo', projectDir: 'demo', mcpProject: 'demo-index', specialization: 'java-spring-backend', framework: 'spring-boot', specializationDecision: { specialization: 'java-spring-backend', template: 'java-backend', framework: 'spring-boot', confidence: 'HIGH', matchedSignals: ['pom.xml'], conflictingSignals: [], decisionReason: 'test fixture', dispatchable: true }, template: 'java-backend', status: 'COLLECTED', identity: [item], statistics: [], technology: [], buildAndRun: [], configuration: [], entrypoints: [], dependencies: [], dataAssets: [], structure: [], security: [], observability: [], deployment: [], tests: [], capabilities: [], dataFlows: [], chainCandidates: [], risks: [], constraints: [], coverageGaps: [], conflicts: [], moduleCandidates: [], evidencePaths: ['src/App.java'], scopeStatus: 'CLEAN', scopeViolations: [] },
  }
}

describe('project lossless synthesis pages', () => {
  it('splits oversized project evidence without truncating the record', () => {
    const value = input()
    const manifest = buildProjectSynthesisReadManifest('input-digest', value)
    const ledger = createProjectSynthesisReadLedger('project-demo-20260101000000-aaaaaaaa', 'protocol-digest', manifest)
    expect(ledger.protocolVersion).toBe(PROJECT_SCAN_PROTOCOL)
    let cursor: string | null = '0:0'
    let reconstructed = ''
    let pages = 0
    while (cursor !== null) {
      const page = buildProjectSynthesisPage('project-demo-20260101000000-aaaaaaaa', 'protocol-digest', 'PROJECT_EVIDENCE', cursor, value)
      reconstructed += page.items.map(item => item.json).join('')
      cursor = page.nextCursor
      pages += 1
    }
    expect(pages).toBeGreaterThan(2)
    expect(JSON.parse('[' + reconstructed + ']')[0].identity[0].summary).toHaveLength(PROJECT_SYNTHESIS_PAGE_MAX_BYTES * 2)
    const factsPage = buildProjectSynthesisPage('project-demo-20260101000000-aaaaaaaa', 'protocol-digest', 'DETERMINISTIC_FACTS', '0:0', value)
    expect(JSON.parse('[' + factsPage.items.map(item => item.json).join('') + ']')[0].protocolVersion).toBe('archscope/project-deterministic-facts/v1')
  })
})
