import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'

import type { Context } from '@deepseek-ai/cordis'
import { afterEach, describe, expect, it } from 'vitest'

import { SYSTEM_SCAN_PROTOCOL, type ProjectRecord } from '../src/contracts/system-scan.js'
import { DshSystemAnalyzer } from '../src/system/analyzer.js'

const project: ProjectRecord = {
  projectKey: 'service',
  projectName: 'service',
  projectDir: 'service',
  gitHead: '0123456789abcdef0123456789abcdef01234567',
  projectType: 'java-project',
  classificationEvidence: ['pom.xml'],
  productionStatus: 'UNCONFIRMED',
}

const temporaryRoots: string[] = []

afterEach(async () => {
  await Promise.all(temporaryRoots.splice(0).map(root => rm(root, { recursive: true, force: true })))
})

function success(value: unknown) {
  return { isError: false, value, content: [] }
}

describe('DshSystemAnalyzer', () => {
  it('indexes through the DSH MCP tool bridge and collects isolated structured evidence', async () => {
    const workspaceRoot = await mkdtemp(path.join(os.tmpdir(), 'archscope-analyzer-'))
    temporaryRoots.push(workspaceRoot)
    await mkdir(path.join(workspaceRoot, 'service', 'src'), { recursive: true })
    await Promise.all([
      writeFile(path.join(workspaceRoot, 'service', 'pom.xml'), '<project />'),
      writeFile(path.join(workspaceRoot, 'service', 'src', 'Main.java'), 'class Main {}'),
      writeFile(path.join(workspaceRoot, 'service', 'src', 'InventoryClient.java'), 'interface InventoryClient {}'),
    ])
    const calls: Array<{ name: string, arguments: unknown }> = []
    let subagentRequest: Record<string, unknown> | undefined
    const tools = {
      get(name: string) {
        return name.startsWith('mcp__codebase_memory_mcp__') ? {} : undefined
      },
      async execute(input: { name: string, arguments: unknown }) {
        calls.push(input)
        if (input.name.endsWith('__list_projects')) {
          return success({ content: [{ type: 'text', text: JSON.stringify({ projects: [] }) }] })
        }
        if (input.name.endsWith('__index_repository')) {
          return success({ content: [{ type: 'text', text: JSON.stringify({ project: 'indexed-service', nodes: 12, edges: 20 }) }] })
        }
        if (input.name.endsWith('__index_status')) {
          return success({ content: [{ type: 'text', text: JSON.stringify({ project: 'indexed-service', status: 'ready', nodes: 12, edges: 20 }) }] })
        }
        if (input.name.endsWith('__get_architecture')) {
          return success({ content: [{ type: 'text', text: JSON.stringify({ languages: ['Java'], packages: ['src'] }) }] })
        }
        throw new Error(`unexpected tool: ${input.name}`)
      },
    }
    const subagents = {
      getProvider(name: string) {
        return name === 'spawn' ? {} : undefined
      },
      async start(_name: string, request: Record<string, unknown>) {
        subagentRequest = request
        return {
          result: Promise.resolve({
            stopReason: 'completed',
            output: [],
            structured: {
              projectTypeCandidates: ['java-backend'],
              entries: ['HTTP entry — src/Main.java'],
              outboundDependencies: [],
              relationCandidates: [{
                targetAlias: 'inventory-service',
                relationType: 'FEIGN_CLIENT',
                evidenceStrength: 'DIRECT_SOURCE',
                description: 'Inventory client contract',
                evidencePaths: ['src/InventoryClient.java'],
                runtimeStatus: 'UNCONFIRMED',
              }],
              dataAssets: ['Repository candidate — src/OrderRepository.java'],
              infrastructure: ['Spring configuration — pom.xml'],
              aliases: ['service-a'],
              capabilityCandidates: ['Order capability — src/order'],
              evidencePaths: ['pom.xml', 'src/Main.java'],
              conflicts: [],
              scopeStatus: 'CLEAN',
              scopeViolations: ['无：仅使用唯一授权 project，未发生越界'],
            },
          }),
          async dispose() {},
        }
      },
    }
    const ctx = {
      get(name: string) {
        if (name === 'tools') return tools
        if (name === 'subagents') return subagents
        return undefined
      },
    } as unknown as Context
    const analyzer = new DshSystemAnalyzer(ctx, {
      outputDirectory: 'archscope_docs',
      discoveryMaxDepth: 3,
      registerCommand: true,
      registerSystemScanTool: true,
      registerStatusTool: true,
    })
    const options = {
      workspaceRoot,
      generatedAt: '2026-08-19T00:00:00.000Z',
      refresh: true,
      agent: {} as never,
    }

    const indexes = await analyzer.index([project], options)
    const evidence = await analyzer.collectEvidence([project], indexes, options)

    expect(indexes).toEqual({
      protocolVersion: SYSTEM_SCAN_PROTOCOL,
      generatedAt: options.generatedAt,
      records: [expect.objectContaining({ status: 'FRESH', mcpProject: 'indexed-service' })],
    })
    expect(calls.map(call => call.name)).toEqual(expect.arrayContaining([
      'mcp__codebase_memory_mcp__list_projects',
      'mcp__codebase_memory_mcp__index_repository',
      'mcp__codebase_memory_mcp__index_status',
      'mcp__codebase_memory_mcp__get_architecture',
    ]))
    expect(evidence.records[0]).toMatchObject({
      status: 'COLLECTED',
      entries: ['HTTP entry — src/Main.java'],
      relationCandidates: [expect.objectContaining({
        targetAlias: 'inventory-service',
        relationType: 'FEIGN_CLIENT',
        evidenceStrength: 'DIRECT_SOURCE',
      })],
      scopeStatus: 'CLEAN',
      scopeViolations: [],
    })
    expect(subagentRequest).toMatchObject({
      maxDepth: 1,
      toolFilter: { allow: expect.arrayContaining(['mcp__codebase_memory_mcp__get_architecture']) },
    })
    expect(JSON.stringify(subagentRequest?.outputSchema)).not.toContain('maxItems')
    expect(JSON.stringify(subagentRequest?.outputSchema)).toContain('relationCandidates')
    expect(subagentRequest).toMatchObject({
      persona: expect.stringContaining('不存在 Glob、Inspect、OUT'),
    })
  })

  it('dispatches a short project task envelope without embedding runtime context or protocol bodies', async () => {
    const workspaceRoot = await mkdtemp(path.join(os.tmpdir(), 'archscope-project-abort-'))
    temporaryRoots.push(workspaceRoot)
    await mkdir(path.join(workspaceRoot, 'service'), { recursive: true })
    await writeFile(path.join(workspaceRoot, 'service', 'pom.xml'), '<project><artifactId>spring-boot-maven-plugin</artifactId></project>')
    const systemQuote = 'openapi 模块为 @FeignClient(value="sfa-backend") 自暴露契约，实际消费方无本仓库证据'
    let request: Record<string, unknown> | undefined
    let starts = 0
    const tools = {
      get(name: string) { return name.startsWith('mcp__codebase_memory_mcp__') || name.startsWith('archscope_get_project_') ? {} : undefined },
      async execute(input: { name: string }) { throw new Error('unexpected parent tool: ' + input.name) },
    }
    const subagents = {
      getProvider(name: string) { return name === 'spawn' ? {} : undefined },
      async start(_name: string, candidate: Record<string, unknown>) {
        starts += 1
        request = candidate
        return {
          result: Promise.resolve({
            stopReason: 'completed',
            output: [],
            structured: {
              template: 'java-backend',
              identity: [{ summary: 'Spring service', evidencePaths: ['pom.xml'], confidence: 'DIRECT_SOURCE' }],
              statistics: [],
              conflicts: [{
                kind: 'REFINEMENT', systemEvidencePointer: 'SYSTEM_FACT_BASE', systemEvidenceQuote: systemQuote,
                systemAssertion: '系统证据记录了 openapi 契约', projectAssertion: '项目证据补充了契约细节',
                rationale: '细化上层结论', evidencePaths: ['pom.xml'], confidence: 'DIRECT_SOURCE',
              }],
              evidencePaths: ['pom.xml'],
              scopeStatus: 'CLEAN',
              scopeViolations: [],
            },
          }),
          async dispose() {},
        }
      },
    }
    const ctx = { get(name: string) { if (name === 'tools') return tools; if (name === 'subagents') return subagents; return undefined } } as unknown as Context
    const analyzer = new DshSystemAnalyzer(ctx, {
      outputDirectory: 'archscope_docs',
      discoveryMaxDepth: 3,
      registerCommand: true,
      registerSystemScanTool: true,
      registerStatusTool: true,
    })
    const evidence = await analyzer.collectProjectEvidence(project, {
      projectKey: project.projectKey,
      projectDir: project.projectDir,
      provider: 'codebase-memory-mcp',
      status: 'FRESH',
      reason: 'ready',
      mcpProject: 'indexed-service',
    }, {
      workspaceRoot,
      generatedAt: '2026-08-24T00:00:00.000Z',
      refresh: false,
      agent: {} as never,
      projectContext: {
        runId: 'project-service-test', sourceSystemRevision: 'S0001',
        sourceSystemFactBase: '# DO_NOT_INLINE_SYSTEM_FACT_BASE', systemEvidence: { conflicts: [systemQuote] } as never,
      },
    })

    expect(evidence).toMatchObject({ status: 'COLLECTED', template: 'java-backend', evidencePaths: ['pom.xml'] })
    expect(evidence.conflicts).toEqual([expect.objectContaining({ systemEvidencePointer: 'SYSTEM_EVIDENCE', systemEvidenceQuote: systemQuote })])
    expect(starts).toBe(1)
    const serialized = JSON.stringify(request)
    expect(serialized).toContain('ARCHSCOPE_PROJECT_EVIDENCE_TASK_V1')
    expect(serialized).toContain('archscope_get_project_evidence_context')
    expect(serialized).toContain('archscope/specialization/java-spring-backend/evidence/v1')
    expect(serialized).not.toContain('DO_NOT_INLINE_SYSTEM_FACT_BASE')
    const taskText = ((request?.prompt as Array<{ text: string }> | undefined)?.[0]?.text) ?? ''
    expect(taskText.length).toBeLessThan(3_000)
    expect(request).toMatchObject({ toolFilter: { allow: expect.arrayContaining([
      'archscope_get_project_evidence_context', 'archscope_get_project_evidence_page', 'archscope_get_project_protocol_resource',
      'mcp__codebase_memory_mcp__get_architecture',
    ]) } })
  })

  it('repairs nonexistent project evidence paths once before failing the scan', async () => {
    const workspaceRoot = await mkdtemp(path.join(os.tmpdir(), 'archscope-project-repair-'))
    temporaryRoots.push(workspaceRoot)
    await mkdir(path.join(workspaceRoot, 'service'), { recursive: true })
    await writeFile(path.join(workspaceRoot, 'service', 'pom.xml'), '<project><artifactId>spring-boot-maven-plugin</artifactId></project>')
    const requests: Record<string, unknown>[] = []
    const tools = {
      get(name: string) { return name.startsWith('mcp__codebase_memory_mcp__') || name.startsWith('archscope_get_project_') ? {} : undefined },
      async execute(input: { name: string }) {
        if (input.name.endsWith('__get_architecture')) return success({ languages: ['Java'] })
        throw new Error('unexpected tool: ' + input.name)
      },
    }
    const subagents = {
      getProvider(name: string) { return name === 'spawn' ? {} : undefined },
      async start(_name: string, request: Record<string, unknown>) {
        requests.push(request)
        const evidencePath = requests.length === 1 ? 'src/Missing.java' : 'pom.xml'
        return { result: Promise.resolve({ stopReason: 'completed', output: [], structured: { template: 'java-backend', identity: [{ summary: 'Spring service', evidencePaths: [evidencePath], confidence: 'DIRECT_SOURCE' }], statistics: [], conflicts: [], evidencePaths: [evidencePath], scopeStatus: 'CLEAN', scopeViolations: [] } }), async dispose() {} }
      },
    }
    const ctx = { get(name: string) { if (name === 'tools') return tools; if (name === 'subagents') return subagents; return undefined } } as unknown as Context
    const analyzer = new DshSystemAnalyzer(ctx, { outputDirectory: 'archscope_docs', discoveryMaxDepth: 3, registerCommand: false, registerSystemScanTool: false, registerStatusTool: false })
    const evidence = await analyzer.collectProjectEvidence(project, { projectKey: project.projectKey, projectDir: project.projectDir, provider: 'codebase-memory-mcp', status: 'FRESH', reason: 'ready', mcpProject: 'indexed-service' }, {
      workspaceRoot, generatedAt: '2026-08-24T00:00:00.000Z', refresh: false, agent: {} as never,
      projectContext: { runId: 'project-service-repair', sourceSystemRevision: 'S0001', sourceSystemFactBase: '# system', systemEvidence: {} as never },
    })

    expect(evidence.evidencePaths).toEqual(['pom.xml'])
    expect(requests).toHaveLength(2)
    expect(requests[1]).toMatchObject({ label: 'archscope-project-evidence-repair:java-spring-backend:service' })
    expect(JSON.stringify(requests[1])).toContain('src/Missing.java')
  })

  it('repairs project evidence that contradicts deterministic configuration facts before writer handoff', async () => {
    const workspaceRoot = await mkdtemp(path.join(os.tmpdir(), 'archscope-project-deterministic-repair-'))
    temporaryRoots.push(workspaceRoot)
    await mkdir(path.join(workspaceRoot, 'service'), { recursive: true })
    await writeFile(path.join(workspaceRoot, 'service', 'pom.xml'), '<project><artifactId>spring-boot-maven-plugin</artifactId></project>')
    const requests: Record<string, unknown>[] = []
    const tools = {
      get(name: string) { return name.startsWith('mcp__codebase_memory_mcp__') || name.startsWith('archscope_get_project_') ? {} : undefined },
      async execute(input: { name: string }) { throw new Error('unexpected parent tool: ' + input.name) },
    }
    const subagents = {
      getProvider(name: string) { return name === 'spawn' ? {} : undefined },
      async start(_name: string, request: Record<string, unknown>) {
        requests.push(request)
        const summary = requests.length === 1
          ? 'bootstrap 引导，仓库内无 bootstrap 文本'
          : 'bootstrap.properties 文件存在，但运行值未验证'
        return { result: Promise.resolve({ stopReason: 'completed', output: [], structured: { template: 'java-backend', identity: [{ summary: 'Spring service', evidencePaths: ['pom.xml'], confidence: 'DIRECT_SOURCE' }], configuration: [{ summary, evidencePaths: [], confidence: 'CONFIGURATION' }], statistics: [], conflicts: [], evidencePaths: ['pom.xml'], scopeStatus: 'CLEAN', scopeViolations: [] } }), async dispose() {} }
      },
    }
    const ctx = { get(name: string) { if (name === 'tools') return tools; if (name === 'subagents') return subagents; return undefined } } as unknown as Context
    const analyzer = new DshSystemAnalyzer(ctx, { outputDirectory: 'archscope_docs', discoveryMaxDepth: 3, registerCommand: false, registerSystemScanTool: false, registerStatusTool: false })
    const evidence = await analyzer.collectProjectEvidence(project, { projectKey: project.projectKey, projectDir: project.projectDir, provider: 'codebase-memory-mcp', status: 'FRESH', reason: 'ready', mcpProject: 'indexed-service' }, {
      workspaceRoot, generatedAt: '2026-08-24T00:00:00.000Z', refresh: false, agent: {} as never,
      projectContext: {
        runId: 'project-service-deterministic-repair', sourceSystemRevision: 'S0001', sourceSystemFactBase: '# system', systemEvidence: {} as never,
        deterministicFacts: {
          protocolVersion: 'archscope/project-deterministic-facts/v1', specialization: 'java-spring-backend', generatedAt: '2026-08-24T00:00:00.000Z', boundary: 'PROJECT_ROOT_ONLY', scanStatus: 'COMPLETE', scannedFileCount: 1, skippedFileCount: 0,
          moduleManifests: ['pom.xml'], moduleDependencies: [], configurationFiles: ['src/main/resources/config/bootstrap.properties'], metrics: [], coverageGaps: [],
          negativeClaimRules: [{ ruleId: 'SPRING-NO-LOCAL-CONFIG', claim: '仓库不存在本地 Spring 配置', allowed: false, reason: 'deterministic inventory found 1 local configuration file', forbiddenPatterns: ['仓库内无 bootstrap'] }],
        },
      },
    })

    expect(evidence.configuration[0]?.summary).toContain('文件存在')
    expect(requests).toHaveLength(2)
    expect(JSON.stringify(requests[1])).toContain('exact matched text “仓库内无 bootstrap”')
    expect(JSON.stringify(requests[1])).toContain('unverified, not absent')
  })

  it('fails closed when the DSH tools service is unavailable', async () => {
    const ctx = { get() { return undefined } } as unknown as Context
    const analyzer = new DshSystemAnalyzer(ctx, {
      outputDirectory: 'archscope_docs',
      discoveryMaxDepth: 3,
      registerCommand: false,
      registerSystemScanTool: false,
      registerStatusTool: false,
    })
    const options = { workspaceRoot: '/workspace', generatedAt: '2026-08-19T00:00:00.000Z', refresh: false }

    const indexes = await analyzer.index([project], options)
    const evidence = await analyzer.collectEvidence([project], indexes, options)

    expect(indexes.records[0]).toMatchObject({ provider: 'unavailable', status: 'PENDING' })
    expect(evidence.records[0]).toMatchObject({ status: 'SKIPPED' })
  })

  it('reuses an exact-root ready index without rebuilding it', async () => {
    const calls: string[] = []
    const tools = {
      get(name: string) {
        return name.startsWith('mcp__codebase_memory_mcp__') ? {} : undefined
      },
      async execute(input: { name: string }) {
        calls.push(input.name)
        if (input.name.endsWith('__list_projects')) {
          return success({ content: [{ type: 'text', text: JSON.stringify({
            projects: [{ name: 'existing-service', root_path: '/workspace/service', nodes: 10, edges: 15 }],
          }) }] })
        }
        if (input.name.endsWith('__index_status')) {
          return success({ content: [{ type: 'text', text: JSON.stringify({ project: 'existing-service', status: 'ready', nodes: 10, edges: 15 }) }] })
        }
        throw new Error(`unexpected tool: ${input.name}`)
      },
    }
    const ctx = { get(name: string) { return name === 'tools' ? tools : undefined } } as unknown as Context
    const analyzer = new DshSystemAnalyzer(ctx, {
      outputDirectory: 'archscope_docs',
      discoveryMaxDepth: 3,
      registerCommand: false,
      registerSystemScanTool: false,
      registerStatusTool: false,
    })

    const indexes = await analyzer.index([project], {
      workspaceRoot: '/workspace',
      generatedAt: '2026-08-19T00:00:00.000Z',
      refresh: false,
    })

    expect(indexes.records[0]).toMatchObject({ status: 'FRESH', mcpProject: 'existing-service' })
    expect(calls).not.toContain('mcp__codebase_memory_mcp__index_repository')
    expect(calls).toContain('mcp__codebase_memory_mcp__index_status')
  })
})
