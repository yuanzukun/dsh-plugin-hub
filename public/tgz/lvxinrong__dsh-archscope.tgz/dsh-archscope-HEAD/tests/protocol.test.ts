import { describe, expect, it } from 'vitest'

import { SYSTEM_SCAN_PROTOCOL, type IndexManifest, type ProjectRegistry, type SystemEvidenceBundle } from '../src/contracts/system-scan.js'
import { loadProjectProtocolPack, loadProtocolPack, parseProtocolContract, protocolResource } from '../src/protocol/catalog.js'
import { projectAgentSpec, projectProtocolResourceIds } from '../src/project/specializations.js'
import { activeProjectBlockers, markdownHeadings, validateSensitiveContent, validateSystemDocument } from '../src/protocol/validation.js'
import { renderSystemFactBase, validateSystemArtifacts } from '../src/system/artifacts.js'

const artifactPaths = [
  'system/00-system-fact-base.md',
  'system/project-registry.json',
  'system/index-manifest.json',
  'system/evidence/index.json',
  'system/relations.json',
  'system/protocol-lock.json',
  'system/validation.json',
  'system/synthesis.json',
  'system/history.json',
  'system/diagrams/01-system-context.mmd',
  'system/diagrams/02-internal-relations.mmd',
  'system/diagrams/03-entry-overview.mmd',
]

function fixture(): { registry: ProjectRegistry, indexes: IndexManifest, evidence: SystemEvidenceBundle, generatedAt: string } {
  const generatedAt = '2026-08-19T00:00:00.000Z'
  const registry: ProjectRegistry = {
    protocolVersion: SYSTEM_SCAN_PROTOCOL,
    generatedAt,
    workspaceRoot: '.',
    discoveryMaxDepth: 3,
    projectCount: 0,
    projects: [],
    skippedDirectories: [],
  }
  return {
    generatedAt,
    registry,
    indexes: { protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt, records: [] },
    evidence: { protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt, records: [] },
  }
}

describe('system protocol pack', () => {
  it('loads every versioned resource and produces a reproducible lock', async () => {
    const pack = await loadProtocolPack()

    expect(pack.manifest.packId).toBe('archscope/protocol/system/v1')
    expect(pack.resources).toHaveLength(pack.manifest.resources.length)
    expect(pack.lock.packDigest).toMatch(/^[a-f0-9]{64}$/u)
    expect(pack.lock.resources.every(resource => /^[a-f0-9]{64}$/u.test(resource.digest))).toBe(true)
  })

  it('keeps the rendered system template aligned with the document contract', async () => {
    const pack = await loadProtocolPack()
    const { registry, indexes, evidence, generatedAt } = fixture()
    const validation = validateSystemArtifacts(registry, indexes, generatedAt, evidence)
    const factBase = renderSystemFactBase(registry, indexes, evidence, validation)
    const contract = parseProtocolContract<{ headings: string[] }>(pack, 'archscope/contract/system-document/v1')

    expect(markdownHeadings(factBase)).toEqual(contract.headings)
    expect(validateSystemDocument(factBase, artifactPaths, pack).filter(issue => issue.severity === 'ERROR')).toEqual([])
  })

  it('fails closed on missing artifacts, invalid structure, credentials, and local paths while preserving architecture identifiers', async () => {
    const pack = await loadProtocolPack()
    const { registry, indexes, evidence, generatedAt } = fixture()
    const validation = validateSystemArtifacts(registry, indexes, generatedAt, evidence)
    const unsafe = renderSystemFactBase(registry, indexes, evidence, validation)
      .replace('## 21. 后续分析任务拆分', '## 22. 错误章节')
      .concat('\npassword=abcdefghijklmnop\nAuthorization: Bearer abcdefghijklmnop\n-----BEGIN PRIVATE KEY-----\n内部域名 internal.example.com\n主库 hotkidceo_production\n本机 /Users/example/workspace\n')
    const issues = validateSystemDocument(unsafe, artifactPaths.slice(0, -1), pack)

    expect(issues.map(issue => issue.code)).toEqual(expect.arrayContaining([
      'SYSTEM_HEADINGS_INVALID',
      'SYSTEM_ARTIFACT_MISSING',
      'SENSITIVE_VALUE_DETECTED',
      'SYSTEM_LOCAL_PATH_LEAK',
    ]))
    expect(issues.filter(issue => issue.code === 'SENSITIVE_VALUE_DETECTED')).toHaveLength(3)
    expect(validateSensitiveContent('认证头格式为 "Bearer department "，后接运行时令牌；不得记录真实令牌。', pack)).toEqual([])
    expect(validateSensitiveContent('Authorization: Bearer abcdefghijklmnop', pack).map(issue => issue.code)).toEqual(['SENSITIVE_VALUE_DETECTED'])
  })

  it('recognizes only active project-level blocker rows', async () => {
    const pack = await loadProtocolPack()
    const { registry, indexes, evidence, generatedAt } = fixture()
    const validation = validateSystemArtifacts(registry, indexes, generatedAt, evidence)
    const rendered = renderSystemFactBase(registry, indexes, evidence, validation)
    const safe = rendered.replace('索引、证据或契约校验尚未完整', '当前无源码视角阻断项')
    const blocked = rendered.replace('索引、证据或契约校验尚未完整', '重复工程归属尚未仲裁')

    expect(activeProjectBlockers(safe)).toEqual([])
    expect(activeProjectBlockers(blocked)).toEqual(['重复工程归属尚未仲裁'])
    expect(validateSystemDocument(blocked, artifactPaths, pack).map(issue => issue.code)).toContain('PROJECT_GATE_BLOCKED_BY_DOCUMENT')
  })

  it('rejects project-level route details and unbounded tables in worldview sections', async () => {
    const pack = await loadProtocolPack()
    const { registry, indexes, evidence, generatedAt } = fixture()
    const validation = validateSystemArtifacts(registry, indexes, generatedAt, evidence)
    const safe = renderSystemFactBase(registry, indexes, evidence, validation)
    const rows = Array.from({ length: 7 }, (_value, index) => `| detail-${index} | project | 1 | raw | pending |`).join('\n')
    const unsafe = safe.replace('## 6. 基础设施事实', `${rows}\n| leaked | POST /users | 1 | raw | pending |\n\n## 6. 基础设施事实`)
    const issues = validateSystemDocument(unsafe, artifactPaths, pack)

    expect(issues.map(issue => issue.code)).toEqual(expect.arrayContaining([
      'SYSTEM_SECTION_TOO_DETAILED',
      'SYSTEM_BOUNDARY_EXCEEDED',
    ]))
  })

  it('rejects implementation audits in the project registry and historical-project sections', async () => {
    const pack = await loadProtocolPack()
    const { registry, indexes, evidence, generatedAt } = fixture()
    const validation = validateSystemArtifacts(registry, indexes, generatedAt, evidence)
    const safe = renderSystemFactBase(registry, indexes, evidence, validation)
    const unsafe = safe
      .replace('## 4. 生产服务边界', '| service | service | java-project | 主后端（约 170 个控制器/1600 条路由） | UNCONFIRMED | evidence/service.json | 无 application.yml |\n\n## 4. 生产服务边界')
      .replace('## 13. 术语表', '| service 内部 | 功能停用 | InterviewIssueController 的 selectIssues 返回空 | 否 | stable/stableNew 与 table.sql 遗留 |\n\n## 13. 术语表')
    const issues = validateSystemDocument(unsafe, artifactPaths, pack)
    const boundaryMessages = issues.filter(issue => issue.code === 'SYSTEM_BOUNDARY_EXCEEDED').map(issue => issue.message)

    expect(boundaryMessages).toEqual(expect.arrayContaining([
      expect.stringContaining('## 3. 工程清单与归属'),
      expect.stringContaining('## 12. 废弃、历史与旁支工程'),
    ]))
  })
})

describe('project protocol pack', () => {
  it('keeps every specialization mapping versioned and present in the pack', async () => {
    const pack = await loadProjectProtocolPack()
    const specializations = ['java-spring-backend', 'web-vue', 'web-frontend', 'miniprogram-wechat', 'android-native', 'ios-native', 'generic'] as const

    expect(pack.manifest.packId).toBe('archscope/protocol/project/v1')
    for (const specialization of specializations) {
      const spec = projectAgentSpec(specialization)
      const evidenceIds = projectProtocolResourceIds(specialization, 'EVIDENCE')
      const writerIds = projectProtocolResourceIds(specialization, 'WRITER')
      expect(evidenceIds).toContain(spec.evidenceResourceId)
      expect(writerIds).toContain(spec.templateResourceId)
      for (const resourceId of [...evidenceIds, ...writerIds]) {
        const resource = protocolResource(pack, resourceId)
        expect(resource.id).toBe(resourceId)
        expect(resource.version).toMatch(/^\d+\.\d+\.\d+$/u)
        expect(resource.digest).toMatch(/^[a-f0-9]{64}$/u)
      }
    }
  })

  it('keeps every Markdown template heading-aligned with the machine document contract', async () => {
    const pack = await loadProjectProtocolPack()
    const contract = parseProtocolContract<{ templates: Record<string, { headings: string[] }> }>(pack, 'archscope/contract/project-document/v1')
    const resources: Record<string, string> = {
      'java-backend': 'archscope/template/java-backend/v1',
      'web-frontend': 'archscope/template/web-frontend/v1',
      'miniprogram-wechat': 'archscope/template/miniprogram-wechat/v1',
      android: 'archscope/template/android/v1',
      ios: 'archscope/template/ios/v1',
      generic: 'archscope/template/generic/v1',
    }

    for (const [template, resourceId] of Object.entries(resources)) {
      expect(markdownHeadings(protocolResource(pack, resourceId).content)).toEqual(contract.templates[template]?.headings)
    }
  })
})


describe('system semantic claim boundaries', () => {
  it('uses deployment-unit candidates and rejects an unproven unified gateway claim', async () => {
    const pack = await loadProtocolPack()
    const { registry, indexes, evidence, generatedAt } = fixture()
    const validation = validateSystemArtifacts(registry, indexes, generatedAt, evidence)
    const safe = renderSystemFactBase(registry, indexes, evidence, validation)
    expect(safe).toContain('| 工程/部署单元候选 |')
    expect(safe).not.toContain('| 生产服务 |')
    const unsafe = safe.replace('## 10. 外部系统与第三方依赖', '系统统一经 hotkidceo 网关域对外。\n\n## 10. 外部系统与第三方依赖')
    expect(validateSystemDocument(unsafe, artifactPaths, pack).map(issue => issue.code)).toContain('SYSTEM_GATEWAY_CLAIM_TOO_STRONG')
  })
})
