import { mkdir, mkdtemp, readFile, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { describe, expect, it } from 'vitest'

import { PROJECT_DOCUMENT_PROTOCOL, PROJECT_SCAN_PROTOCOL, type ProjectDeepEvidence, type ProjectEvidenceDataset, type ProjectSynthesisDataset, type ProjectSynthesisInputs } from '../src/contracts/project-scan.js'
import { SYSTEM_SCAN_PROTOCOL, type IndexManifest, type ProjectRegistry, type SystemEvidenceBundle, type SystemRelationCatalog } from '../src/contracts/system-scan.js'
import { loadProjectProtocolPack, parseProtocolContract, protocolResource } from '../src/protocol/catalog.js'
import { ProjectScanCoordinator } from '../src/project/coordinator.js'
import { prepareProjectArtifacts } from '../src/project/artifacts.js'
import { PROJECT_EVIDENCE_CONTEXT_RESOURCE_ID } from '../src/project/protocol-resources.js'
import { projectProtocolResourceIds } from '../src/project/specializations.js'
import type { SystemAnalyzer } from '../src/system/analyzer.js'

const generatedAt = new Date(0).toISOString()
const project = { projectKey: 'demo-service', projectName: 'demo-service', projectDir: 'demo-service', gitHead: null, projectType: 'java-project' as const, classificationEvidence: ['pom.xml'], productionStatus: 'UNCONFIRMED' as const }
const index = { projectKey: project.projectKey, projectDir: project.projectDir, provider: 'codebase-memory-mcp' as const, status: 'FRESH' as const, reason: 'ready', mcpProject: 'demo-index' }
const systemEvidence = { projectKey: project.projectKey, projectDir: project.projectDir, status: 'COLLECTED' as const, projectTypeCandidates: ['java'], entries: ['main'], outboundDependencies: [], dataAssets: [], infrastructure: [], aliases: [], capabilityCandidates: ['demo'], evidencePaths: ['pom.xml'], conflicts: [], scopeStatus: 'CLEAN' as const, scopeViolations: [] }

function deepEvidence(): ProjectDeepEvidence {
  const fact = { summary: 'Spring Boot executable service', evidencePaths: ['pom.xml'], confidence: 'DIRECT_SOURCE' as const }
  const specializationDecision = { specialization: 'java-spring-backend' as const, template: 'java-backend' as const, framework: 'spring-boot' as const, confidence: 'HIGH' as const, matchedSignals: ['pom.xml', 'build:spring-boot-plugin'], conflictingSignals: [], decisionReason: 'test fixture', dispatchable: true }
  return { protocolVersion: PROJECT_SCAN_PROTOCOL, generatedAt, projectKey: project.projectKey, projectDir: project.projectDir, mcpProject: 'demo-index', specialization: 'java-spring-backend', framework: 'spring-boot', specializationDecision, template: 'java-backend', status: 'COLLECTED', identity: [fact], statistics: [{ metric: 'module', count: 1, unit: '个', queryMethod: 'project root', exclusions: 'generated files', evidencePaths: ['pom.xml'], confidence: 'DIRECT_SOURCE' }], technology: [fact], buildAndRun: [fact], configuration: [], entrypoints: [fact], dependencies: [], dataAssets: [], structure: [fact], security: [], observability: [], deployment: [], tests: [], capabilities: [fact], dataFlows: [], chainCandidates: [], risks: [], constraints: [], coverageGaps: [], conflicts: [], moduleCandidates: [fact], evidencePaths: ['pom.xml'], scopeStatus: 'CLEAN', scopeViolations: [] }
}

async function fixture(root: string) {
  const output = path.join(root, 'archscope_docs')
  const runId = 'system-20260101000000-aaaaaaaa'
  const systemRoot = path.join(output, 'runs', runId, 'system')
  await mkdir(path.join(systemRoot, 'evidence'), { recursive: true })
  await mkdir(path.join(root, project.projectDir), { recursive: true })
  await writeFile(path.join(root, project.projectDir, 'pom.xml'), '<project><build><plugins><plugin><artifactId>spring-boot-maven-plugin</artifactId></plugin></plugins></build></project>')
  const registry: ProjectRegistry = { protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt, workspaceRoot: '.', discoveryMaxDepth: 3, projectCount: 1, projects: [project], skippedDirectories: [] }
  const indexes: IndexManifest = { protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt, records: [index] }
  const evidence: SystemEvidenceBundle = { protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt, records: [systemEvidence] }
  const relations: SystemRelationCatalog = { protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt, projectCount: 1, projectsWithRelations: 0, totalCount: 0, internalCount: 0, unresolvedCount: 0, records: [] }
  await Promise.all([
    writeFile(path.join(output, 'runs', 'latest.json'), JSON.stringify({ runId })),
    writeFile(path.join(output, 'runs', runId, 'state.json'), JSON.stringify({ protocolVersion: SYSTEM_SCAN_PROTOCOL, protocol: { packId: 'system', version: '1', digest: 'digest' }, runId, documentRevision: 'S0001', status: 'COMPLETED', gate: 'READY', validation: 'PASSED', startedAt: generatedAt, updatedAt: generatedAt, finishedAt: generatedAt, workspaceRoot: '.', outputDirectory: 'archscope_docs', refresh: false, projectCount: 1, indexedProjectCount: 1, evidenceProjectCount: 1, scopeViolationCount: 0, transitions: [] })),
    writeFile(path.join(systemRoot, 'project-registry.json'), JSON.stringify(registry)),
    writeFile(path.join(systemRoot, 'index-manifest.json'), JSON.stringify(indexes)),
    writeFile(path.join(systemRoot, 'evidence', 'index.json'), JSON.stringify(evidence)),
    writeFile(path.join(systemRoot, 'relations.json'), JSON.stringify(relations)),
    writeFile(path.join(systemRoot, '00-system-fact-base.md'), '# system S0001'),
  ])
}

describe('project scan coordinator', () => {
  it('ships distinct fixed templates for six project forms', async () => {
    const pack = await loadProjectProtocolPack()
    const contract = parseProtocolContract<{ templates: Record<string, { headings: string[] }> }>(pack, 'archscope/contract/project-document/v1')
    expect(Object.keys(contract.templates).sort()).toEqual(['android', 'generic', 'ios', 'java-backend', 'miniprogram-wechat', 'web-frontend'])
    expect(contract.templates['java-backend'].headings).not.toEqual(contract.templates['web-frontend'].headings)
    expect(contract.templates.android.headings).not.toEqual(contract.templates.ios.headings)
  })

  it('enforces the system gate, collects deep evidence, pages all inputs, and publishes P0001', async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), 'archscope-project-'))
    await fixture(root)
    const analyzer: SystemAnalyzer = {
      async index(): Promise<IndexManifest> { return { protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt, records: [index] } },
      async collectEvidence(): Promise<SystemEvidenceBundle> { return { protocolVersion: SYSTEM_SCAN_PROTOCOL, generatedAt, records: [systemEvidence] } },
      async collectProjectEvidence(_project, _index, options) {
        const runId = options.projectContext?.runId as string
        const evidenceContext = await coordinator.evidenceTaskContext(runId)
        expect(evidenceContext).toMatchObject({ evidenceMode: 'PAGED' })
        expect(evidenceContext.manifest.datasets.map(item => item.dataset)).toEqual(['SAFE_METADATA', 'DETERMINISTIC_FACTS', 'SYSTEM_PROJECT_EVIDENCE', 'SYSTEM_FACT_BASE'])
        expect(JSON.stringify(evidenceContext)).not.toContain('sourceSystemFactBase')
        const systemFactBase = evidenceContext.manifest.datasets.find(item => item.dataset === 'SYSTEM_FACT_BASE')
        await expect(coordinator.evidencePage(runId, {
          dataset: 'SYSTEM_FACT_BASE', cursor: systemFactBase?.nextCursor as string,
        })).rejects.toThrow('expected SAFE_METADATA')
        for (const dataset of evidenceContext.manifest.datasets) {
          let cursor = dataset.nextCursor
          while (cursor !== null) {
            const page = await coordinator.evidencePage(runId, { dataset: dataset.dataset as ProjectEvidenceDataset, cursor })
            cursor = page.nextCursor
          }
        }
        const replay = await coordinator.evidencePage(runId, { dataset: 'SAFE_METADATA', cursor: '0:0' })
        expect(replay).toMatchObject({ dataset: 'SAFE_METADATA', cursor: '0:0' })
        const ledgerPath = path.join(root, 'archscope_docs', 'runs', runId, 'project', 'protocol-read-ledger.json')
        const pack = await loadProjectProtocolPack()
        const contextLedger = JSON.parse(await readFile(ledgerPath, 'utf8')) as { reads: Array<{ phase: 'EVIDENCE', resourceId: string, version: string, digest: string, readAt: string }> }
        expect(contextLedger.reads.some(item => item.resourceId === PROJECT_EVIDENCE_CONTEXT_RESOURCE_ID)).toBe(true)
        const reads = [...contextLedger.reads, ...projectProtocolResourceIds('java-spring-backend', 'EVIDENCE').map(resourceId => {
          const resource = protocolResource(pack, resourceId)
          return { phase: 'EVIDENCE', resourceId, version: resource.version, digest: resource.digest, readAt: generatedAt }
        })]
        await writeFile(ledgerPath, JSON.stringify({ protocolVersion: PROJECT_SCAN_PROTOCOL, runId, updatedAt: generatedAt, reads }))
        return deepEvidence()
      },
    }
    const coordinator = new ProjectScanCoordinator({ workspaceRoot: root, outputDirectory: 'archscope_docs', discoveryMaxDepth: 3, registerCommand: false, registerSystemScanTool: false, registerProjectScanTool: false, registerStatusTool: false }, analyzer)
    const scan = await coordinator.scan(project.projectKey)
    expect(scan.status).toBe('AWAITING_PROJECT_SYNTHESIS')
    const context = await coordinator.context(scan.runId)
    expect(context.prompt).toContain('ARCHSCOPE_PROJECT_WRITER_TASK_V1')
    expect(context.prompt).not.toContain('## 1. 工程身份与职责')
    expect(context.prompt.length).toBeLessThan(3_000)
    expect(context.manifest.datasets.map(item => item.dataset)).toContain('DETERMINISTIC_FACTS')
    const resources = await Promise.all(context.protocolResourceIds.map(resourceId => coordinator.projectProtocolResource(scan.runId, { resourceId })))
    for (const resource of resources) {
      const resourceId = resource.resourceId
      expect(resource).toMatchObject({ runId: scan.runId, phase: 'WRITER', resourceId })
      expect(resource.content.length).toBeGreaterThan(0)
    }
    await expect(coordinator.projectProtocolResource(scan.runId, { resourceId: 'archscope/specialization/java-spring-backend/evidence/v1' })).rejects.toThrow('not allowed')
    for (const dataset of context.manifest.datasets) {
      let cursor = dataset.nextCursor
      while (cursor !== null) {
        const page = await coordinator.page(scan.runId, { dataset: dataset.dataset as ProjectSynthesisDataset, cursor })
        cursor = page.nextCursor
      }
    }
    const pack = await loadProjectProtocolPack()
    const contract = parseProtocolContract<{ templates: Record<string, { headings: string[] }> }>(pack, 'archscope/contract/project-document/v1')
    const metadata = ['协议版本','项目事实版本','文档状态','证据状态','下层门禁','校验状态','工程键','工程目录','系统事实版本','工程类型']
      .map(key => '| ' + key + ' | PENDING |').join('\n')
    const profile = '# demo-service — 项目级画像（Java 后端）\n\n| 字段 | 值 |\n|---|---|\n' + metadata + '\n\n' + contract.templates['java-backend'].headings.map((heading, i) => heading + '\n\n' + (i === 0 ? '证据见 evidence.json；系统事实版本 S0001。' : '| 结论 | 证据 |\n|---|---|\n| 待确认 | pom.xml |')).join('\n\n')
    const diagram = 'flowchart LR\n  A[源码] --> B[工程]\n  L[实线=源码证据；虚线=待确认推断；不代表生产运行]'
    await expect(coordinator.stageArtifact({ artifact: 'PROFILE', content: profile + '\n\nflowchart LR\n  X --> Y' })).rejects.toThrow('PROJECT_PROFILE_EMBEDS_DIAGRAM')
    const first = await coordinator.stageArtifact({ artifact: 'PROFILE', content: profile })
    expect(first).toMatchObject({ runId: scan.runId, stagedCount: 1, readyToFinalize: false })
    expect(first.missingArtifacts).toEqual(['PROJECT_CONTEXT_DIAGRAM', 'STRUCTURE_DIAGRAM', 'ENTRY_DEPENDENCY_DIAGRAM'])
    const incomplete = await coordinator.finalizeStaged({ writer: { kind: 'dsh-project-writer-agent', specialization: 'java-spring-backend', sessionId: 'test' } })
    expect(incomplete).toMatchObject({ finalizeStatus: 'INCOMPLETE', stagedCount: 1 })

    await coordinator.stageArtifact({ artifact: 'PROJECT_CONTEXT_DIAGRAM', content: diagram })
    await coordinator.stageArtifact({ artifact: 'STRUCTURE_DIAGRAM', content: diagram })
    const fourth = await coordinator.stageArtifact({ artifact: 'ENTRY_DEPENDENCY_DIAGRAM', content: diagram })
    expect(fourth).toMatchObject({ stagedCount: 4, readyToFinalize: true, missingArtifacts: [] })

    const stagedProfile = path.join(root, 'archscope_docs', 'runs', scan.runId, 'project', 'synthesis', 'staged', 'profile.md')
    await writeFile(stagedProfile, profile + '\nchanged outside staging')
    await expect(coordinator.finalizeStaged({ writer: { kind: 'dsh-project-writer-agent', specialization: 'java-spring-backend', sessionId: 'test' } })).rejects.toThrow('staged artifact changed')
    await coordinator.stageArtifact({ artifact: 'PROFILE', content: profile })

    const result = await coordinator.finalizeStaged({ writer: { kind: 'dsh-project-writer-agent', specialization: 'java-spring-backend', sessionId: 'test' } })
    expect(result).toMatchObject({ finalizeStatus: 'COMMITTED', commit: { status: 'COMPLETED', validation: 'PASSED', gate: 'READY', projectRevision: 'P0001', sourceSystemRevision: 'S0001' } })
    const current = await readFile(path.join(root, 'archscope_docs', 'projects', project.projectKey, '00-project-profile.md'), 'utf8')
    expect(current).toContain('| 项目事实版本 | P0001 |')
    expect(current).toContain('| 协议版本 | ' + PROJECT_DOCUMENT_PROTOCOL + ' |')
    expect(current).toContain('SPRING-JAVA-SOURCE-FILES')
    expect(current).toContain('deterministic-facts.json')
    await expect(readFile(path.join(root, 'archscope_docs', 'projects', project.projectKey, 'deterministic-facts.json'), 'utf8')).resolves.toContain('SPRING-JAVA-SOURCE-FILES')
  })

  it('keeps validation separate from reconciliation and blocks only on blocking conflicts', async () => {
    const pack = await loadProjectProtocolPack()
    const contract = parseProtocolContract<{ templates: Record<string, { headings: string[] }> }>(pack, 'archscope/contract/project-document/v1')
    const evidence = deepEvidence()
    evidence.conflicts = [{
      conflictId: 'PC-identity', kind: 'IDENTITY_MISMATCH', severity: 'BLOCKING',
      systemEvidencePointer: 'SYSTEM_FACT_BASE', systemEvidenceQuote: 'system S0001',
      systemAssertion: '系统注册表把工程识别为普通库', projectAssertion: 'pom.xml 证明它是可执行 Spring Boot 服务',
      rationale: '工程身份影响模板和下层扫描边界', evidencePaths: ['pom.xml'], confidence: 'DIRECT_SOURCE',
      reconciliationStatus: 'BLOCKED', sourceSystemRevision: 'S0001',
    }]
    const input: ProjectSynthesisInputs = { sourceSystemFactBase: '# system S0001', project, index, systemEvidence, relatedRelations: [], projectEvidence: evidence }
    const metadata = ['协议版本','项目事实版本','文档状态','证据状态','下层门禁','校验状态','工程键','工程目录','系统事实版本','工程类型'].map(key => '| ' + key + ' | PENDING |').join('\n')
    const profile = '# demo-service — 项目级画像（Java 后端）\n\n| 字段 | 值 |\n|---|---|\n' + metadata + '\n\n' + contract.templates['java-backend'].headings.map((heading, i) => heading + '\n\n' + (i === 0 ? '证据见 evidence.json；系统事实版本 S0001。' : '| 结论 | 证据 |\n|---|---|\n| 待确认 | pom.xml |')).join('\n\n') + '\n\nPC-identity'
    const diagram = 'flowchart LR\n  A[源码] --> B[工程]\n  L[实线=源码证据；虚线=待确认推断；不代表生产运行]'
    const prepared = prepareProjectArtifacts(input, generatedAt, pack, { profile, diagrams: { projectContext: diagram, structure: diagram, entryDependency: diagram } }, 'P0001', 'S0001')

    expect(prepared.validation).toMatchObject({ status: 'PASSED', gate: 'BLOCKED', conflictCount: 1, blockingConflictCount: 1, reconciliationStatus: 'BLOCKED' })
    expect(prepared.profile).toContain('| 校验状态 | PASSED |')
    expect(prepared.profile).toContain('| 下层门禁 | BLOCKED |')

    const badId = prepareProjectArtifacts(input, generatedAt, pack, { profile: profile.replace('PC-identity', 'PC-typo'), diagrams: { projectContext: diagram, structure: diagram, entryDependency: diagram } }, 'P0001', 'S0001')
    expect(badId.validation.issues.map(issue => issue.code)).toEqual(expect.arrayContaining(['PROJECT_CONFLICT_REFERENCE_UNKNOWN', 'PROJECT_CONFLICT_REFERENCE_MISSING']))

    const badCitation = prepareProjectArtifacts(input, generatedAt, pack, { profile: profile + '\n\n`Run.java`', diagrams: { projectContext: diagram, structure: diagram, entryDependency: diagram } }, 'P0001', 'S0001')
    expect(badCitation.validation.issues.map(issue => issue.code)).toContain('PROJECT_PROFILE_EVIDENCE_CITATION_INVALID')

    const deterministicInput: ProjectSynthesisInputs = {
      ...input,
      deterministicFacts: {
        protocolVersion: 'archscope/project-deterministic-facts/v1', specialization: 'java-spring-backend', generatedAt,
        boundary: 'PROJECT_ROOT_ONLY', scanStatus: 'COMPLETE', scannedFileCount: 10, skippedFileCount: 0,
        moduleManifests: ['pom.xml'], moduleDependencies: [], configurationFiles: ['src/main/resources/application.yml'], coverageGaps: [],
        metrics: [
          { metricId: 'SPRING-CONFIG-FILES', label: 'Spring 本地配置文件', value: 1, unit: 'file', scope: 'all source modules', method: 'filesystem', exclusions: 'generated resources and mapper XML', evidencePaths: ['src/main/resources/application.yml'], completeness: 'COMPLETE' },
          { metricId: 'SPRING-DS-ANNOTATIONS', label: '@DS 注解', value: 3, unit: 'occurrence', scope: 'all source modules', method: 'source scan', exclusions: 'dependencies', evidencePaths: ['pom.xml'], completeness: 'COMPLETE' },
          { metricId: 'SPRING-CONTROLLER-NAMED-FILES', label: '*Controller.java 文件', value: 2, unit: 'file', scope: 'all source modules', method: 'filesystem', exclusions: 'generated', evidencePaths: ['pom.xml'], completeness: 'COMPLETE' },
        ],
        negativeClaimRules: [
          { ruleId: 'SPRING-NO-LOCAL-CONFIG', claim: 'no config', allowed: false, reason: 'found 1 file', forbiddenPatterns: ['仓库内[^\\n]{0,20}0\\s*个[^\\n]{0,40}(?:ya?ml|properties|配置文件)'] },
          { ruleId: 'SPRING-NO-DS-ANNOTATION', claim: 'no @DS', allowed: false, reason: 'found 3 annotations', forbiddenPatterns: ['@DS[^\\n]{0,20}无命中'] },
        ],
      },
    }
    const unsupportedNegative = prepareProjectArtifacts(deterministicInput, generatedAt, pack, { profile: profile + '\n\n仓库内 0 个 yml/properties 配置文件，@DS 无命中。', diagrams: { projectContext: diagram, structure: diagram, entryDependency: diagram } }, 'P0001', 'S0001')
    expect(unsupportedNegative.validation.issues.map(issue => issue.code)).toEqual(expect.arrayContaining(['PROJECT_NEGATIVE_CLAIM_UNSUPPORTED', 'PROJECT_DETERMINISTIC_METRIC_MISMATCH']))
    const negativeIssue = unsupportedNegative.validation.issues.find(issue => issue.code === 'PROJECT_NEGATIVE_CLAIM_UNSUPPORTED' && issue.message.includes('SPRING-NO-LOCAL-CONFIG'))
    expect(negativeIssue?.message).toContain('Exact matched text: “仓库内 0 个 yml/properties 配置文件”')
    expect(negativeIssue?.message).toContain('Restage PROFILE')
    expect(negativeIssue?.message).toContain('unverified, not absent')
    const badDiagramMetric = prepareProjectArtifacts(deterministicInput, generatedAt, pack, { profile, diagrams: { projectContext: diagram, structure: diagram + '\n  C[Controller 47 files]', entryDependency: diagram } }, 'P0001', 'S0001')
    expect(badDiagramMetric.validation.issues.map(issue => issue.code)).toContain('PROJECT_DETERMINISTIC_METRIC_MISMATCH')

    const p0006Regression = prepareProjectArtifacts(deterministicInput, generatedAt, pack, {
      profile: profile + '\n\nRealtimeDataServiceImpl（202 方法）与 RealtimeDataController 是巨型类候选；EstimateApplication（230 方法）下接 Mapper XML；测试资产 150 个文件，代表样本是 PartnerDailyReportRealDwdControllerIT.java。',
      diagrams: { projectContext: diagram, structure: diagram, entryDependency: diagram },
    }, 'P0001', 'S0001')
    expect(p0006Regression.validation.issues.filter(issue => issue.code === 'PROJECT_DETERMINISTIC_METRIC_MISMATCH')).toEqual([])

    const relationEvidencePath = 'src/main/java/demo/BusinessTripServiceImpl.java'
    const relationInput: ProjectSynthesisInputs = {
      ...input,
      relatedRelations: [{ relationId: 'REL-business', sourceProjectKey: project.projectKey, sourceProjectDir: project.projectDir, targetAlias: 'amap', relationType: 'CONFIGURED_ENDPOINT', evidenceStrength: 'DIRECT_SOURCE', description: 'AMap endpoint', evidencePaths: [relationEvidencePath], runtimeStatus: 'UNCONFIRMED', scope: 'EXTERNAL_OR_UNRESOLVED' }],
    }
    const relationCitation = prepareProjectArtifacts(relationInput, generatedAt, pack, { profile: profile + `\n\n\`${relationEvidencePath}\``, diagrams: { projectContext: diagram, structure: diagram, entryDependency: diagram } }, 'P0001', 'S0001')
    expect(relationCitation.validation.issues.map(issue => issue.code)).not.toContain('PROJECT_PROFILE_EVIDENCE_CITATION_INVALID')

    const moduleInput: ProjectSynthesisInputs = {
      ...deterministicInput,
      deterministicFacts: {
        ...deterministicInput.deterministicFacts!,
        moduleManifests: ['demo-api/pom.xml', 'demo-service/pom.xml'],
        moduleDependencies: [{ sourceModule: 'demo-service', targetModule: 'demo-api', sourceManifest: 'demo-service/pom.xml', targetManifest: 'demo-api/pom.xml', scope: 'COMPILE', optional: false }],
      },
    }
    const badModuleDiagram = diagram + '\n  API[demo-api]\n  SERVICE[demo-service]\n  API --> SERVICE'
    const badModule = prepareProjectArtifacts(moduleInput, generatedAt, pack, { profile, diagrams: { projectContext: diagram, structure: badModuleDiagram, entryDependency: diagram } }, 'P0001', 'S0001')
    expect(badModule.validation.issues.map(issue => issue.code)).toEqual(expect.arrayContaining(['PROJECT_MODULE_DEPENDENCY_MISMATCH', 'PROJECT_MODULE_DEPENDENCY_MISSING']))
    const goodModuleDiagram = diagram + '\n  API[demo-api]\n  SERVICE[demo-service]\n  SERVICE --> API'
    const goodModule = prepareProjectArtifacts(moduleInput, generatedAt, pack, { profile, diagrams: { projectContext: diagram, structure: goodModuleDiagram, entryDependency: diagram } }, 'P0001', 'S0001')
    expect(goodModule.validation.issues.map(issue => issue.code)).not.toContain('PROJECT_MODULE_DEPENDENCY_MISMATCH')
    expect(goodModule.validation.issues.map(issue => issue.code)).not.toContain('PROJECT_MODULE_DEPENDENCY_MISSING')

    const badHeading = prepareProjectArtifacts(input, generatedAt, pack, { profile: profile.replace('## 1.1 统计口径与覆盖范围', '### 1.1 统计口径与覆盖范围'), diagrams: { projectContext: diagram, structure: diagram, entryDependency: diagram } }, 'P0001', 'S0001')
    const headingIssue = badHeading.validation.issues.find(issue => issue.code === 'PROJECT_HEADINGS_INVALID')
    expect(headingIssue?.message).toContain('expected "## 1.1 统计口径与覆盖范围", received "### 1.1 统计口径与覆盖范围"')

    evidence.conflicts[0] = { ...evidence.conflicts[0]!, systemEvidenceQuote: 'not present in the bound system input' }
    const badSystemQuote = prepareProjectArtifacts(input, generatedAt, pack, { profile, diagrams: { projectContext: diagram, structure: diagram, entryDependency: diagram } }, 'P0001', 'S0001')
    expect(badSystemQuote.validation.issues.map(issue => issue.code)).toContain('PROJECT_CONFLICT_SYSTEM_EVIDENCE_INVALID')
  })
})
