import { mkdir, mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import path from 'node:path'

import { afterEach, describe, expect, it } from 'vitest'

import { collectSafeProjectMetadata } from '../src/system/project-metadata.js'

const temporaryRoots: string[] = []

afterEach(async () => {
  await Promise.all(temporaryRoots.splice(0).map(root => rm(root, { recursive: true, force: true })))
})

describe('collectSafeProjectMetadata', () => {
  it('reads bounded metadata, preserves architecture facts, and removes credentials before model injection', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'archscope-metadata-'))
    temporaryRoots.push(root)
    const outside = path.join(root, '..', `${path.basename(root)}-outside.txt`)
    await writeFile(outside, 'outside-secret', 'utf8')
    temporaryRoots.push(outside)
    await mkdir(path.join(root, '.github', 'workflows'), { recursive: true })
    await writeFile(path.join(root, 'package.json'), JSON.stringify({
      name: 'demo',
      repository: 'https://user:password@example.com/private.git',
      password: 'super-secret-value',
    }), 'utf8')
    await writeFile(path.join(root, '.env.production'), 'API_TOKEN=raw-token\nPUBLIC_NAME=demo\nSERVICE_URL=https://internal.example.com/sfa\n', 'utf8')
    await writeFile(path.join(root, '.github', 'workflows', 'ci.yml'), 'steps:\n  - run: echo ok\n', 'utf8')
    await symlink(outside, path.join(root, 'README.md'))

    const metadata = await collectSafeProjectMetadata(root)
    const serialized = JSON.stringify(metadata)

    expect(metadata.boundary).toBe('PROJECT_ROOT_ONLY')
    expect(metadata.files.map(file => file.path)).toEqual(expect.arrayContaining([
      '.env.production',
      '.github/workflows/ci.yml',
      'package.json',
    ]))
    expect(metadata.files.map(file => file.path)).not.toContain('README.md')
    expect(serialized).not.toContain('raw-token')
    expect(serialized).not.toContain('super-secret-value')
    expect(serialized).not.toContain('outside-secret')
    expect(serialized).toContain('API_TOKEN=<redacted>')
    expect(serialized).toContain('PUBLIC_NAME=demo')
    expect(serialized).toContain('SERVICE_URL=https://internal.example.com/sfa')
    expect(serialized).toContain('https://<redacted-credentials>@example.com/private.git')
    await expect(readFile(outside, 'utf8')).resolves.toBe('outside-secret')
  })

  it('collects bounded Spring multi-module configuration without traversing mapper resources', async () => {
    const root = await mkdtemp(path.join(tmpdir(), 'archscope-spring-metadata-'))
    temporaryRoots.push(root)
    const moduleRoot = path.join(root, 'demo-webapi')
    const resources = path.join(moduleRoot, 'src', 'main', 'resources')
    await mkdir(path.join(resources, 'config'), { recursive: true })
    await mkdir(path.join(resources, 'mapper'), { recursive: true })
    await writeFile(path.join(root, 'pom.xml'), '<project><modules><module>demo-webapi</module></modules></project>', 'utf8')
    await writeFile(path.join(moduleRoot, 'pom.xml'), '<project><artifactId>demo-webapi</artifactId></project>', 'utf8')
    await writeFile(path.join(resources, 'config', 'application-local.yaml'), 'spring:\n  application:\n    name: demo\n', 'utf8')
    await writeFile(path.join(resources, 'bootstrap.properties'), 'spring.cloud.nacos.server-addr=nacos.example\n', 'utf8')
    await writeFile(path.join(resources, 'logback.xml'), '<configuration/>', 'utf8')
    await writeFile(path.join(resources, 'mapper', 'OrderMapper.xml'), '<mapper namespace="OrderMapper"/>', 'utf8')

    const metadata = await collectSafeProjectMetadata(root)
    const paths = metadata.files.map(file => file.path)

    expect(paths).toEqual(expect.arrayContaining([
      'pom.xml',
      'demo-webapi/pom.xml',
      'demo-webapi/src/main/resources/config/application-local.yaml',
      'demo-webapi/src/main/resources/bootstrap.properties',
      'demo-webapi/src/main/resources/logback.xml',
    ]))
    expect(paths).not.toContain('demo-webapi/src/main/resources/mapper/OrderMapper.xml')
  })
})
