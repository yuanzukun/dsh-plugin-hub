import { describe, expect, it } from 'vitest'

import { PROJECT_SCAN_PROTOCOL, type ProjectEvidenceDataset, type ProjectEvidenceInputs } from '../src/contracts/project-scan.js'
import { buildProjectEvidencePage, buildProjectEvidenceReadManifest, createProjectEvidenceReadLedger, projectEvidenceInputDigest, PROJECT_EVIDENCE_DATASETS, PROJECT_EVIDENCE_PAGE_MAX_BYTES } from '../src/project/evidence-pages.js'

function input(): ProjectEvidenceInputs {
  return {
    sourceSystemFactBase: '# system\n' + '世界观'.repeat(PROJECT_EVIDENCE_PAGE_MAX_BYTES),
    systemEvidence: { projectKey: 'demo', projectDir: 'demo', status: 'COLLECTED', projectTypeCandidates: ['java'], entries: [], outboundDependencies: [], dataAssets: [], infrastructure: [], aliases: [], capabilityCandidates: [], evidencePaths: ['pom.xml'], conflicts: [], scopeStatus: 'CLEAN', scopeViolations: [] },
    safeMetadata: {
      boundary: 'PROJECT_ROOT_ONLY', omittedFiles: 0,
      files: [
        { path: 'pom.xml', kind: 'manifest', excerpt: '<project/>' },
        { path: 'src/main/resources/config/bootstrap.properties', kind: 'configuration', excerpt: 'spring.application.name=demo\nspring.cloud.nacos.password=<redacted>' },
      ],
    },
    deterministicFacts: {
      protocolVersion: 'archscope/project-deterministic-facts/v1', specialization: 'java-spring-backend', generatedAt: new Date(0).toISOString(),
      boundary: 'PROJECT_ROOT_ONLY', scanStatus: 'COMPLETE', scannedFileCount: 2, skippedFileCount: 0,
      moduleManifests: ['pom.xml'], moduleDependencies: [], configurationFiles: ['src/main/resources/config/bootstrap.properties'],
      metrics: [{ metricId: 'SPRING-CONFIG-FILES', label: 'Spring 本地配置文件', value: 1, unit: 'file', scope: 'main resources', method: 'filesystem', exclusions: 'generated', evidencePaths: ['src/main/resources/config/bootstrap.properties'], completeness: 'COMPLETE' }],
      negativeClaimRules: [{ ruleId: 'SPRING-NO-LOCAL-CONFIG', claim: 'no config', allowed: false, reason: 'found 1 file', forbiddenPatterns: ['无 bootstrap'] }], coverageGaps: [],
    },
  }
}

function readDataset(dataset: ProjectEvidenceDataset, value: ProjectEvidenceInputs): Map<string, string> {
  let cursor: string | null = '0:0'
  const chunks = new Map<string, string>()
  while (cursor !== null) {
    const page = buildProjectEvidencePage('project-demo-20260101000000-aaaaaaaa', 'protocol-digest', dataset, cursor, value)
    for (const item of page.items) chunks.set(item.recordKey, (chunks.get(item.recordKey) ?? '') + item.json)
    cursor = page.nextCursor
  }
  return chunks
}

describe('project evidence lossless pages', () => {
  it('prioritizes safe metadata and deterministic facts without embedding the monolithic system context', () => {
    const value = input()
    const digest = projectEvidenceInputDigest(value)
    const manifest = buildProjectEvidenceReadManifest(digest, value)
    const ledger = createProjectEvidenceReadLedger('project-demo-20260101000000-aaaaaaaa', 'protocol-digest', manifest)
    expect(manifest.datasets.map(item => item.dataset)).toEqual(PROJECT_EVIDENCE_DATASETS)
    expect(ledger.protocolVersion).toBe(PROJECT_SCAN_PROTOCOL)
    expect(manifest.datasets.find(item => item.dataset === 'SYSTEM_FACT_BASE')?.totalBytes).toBeGreaterThan(PROJECT_EVIDENCE_PAGE_MAX_BYTES)

    const metadata = readDataset('SAFE_METADATA', value)
    expect(JSON.parse(metadata.get('src/main/resources/config/bootstrap.properties') ?? '{}')).toMatchObject({
      path: 'src/main/resources/config/bootstrap.properties', kind: 'configuration', excerpt: expect.stringContaining('spring.application.name=demo'),
    })
    const facts = readDataset('DETERMINISTIC_FACTS', value)
    expect(JSON.parse(facts.get('deterministic-overview') ?? '{}').configurationFiles).toContain('src/main/resources/config/bootstrap.properties')
    expect(JSON.parse(facts.get('metric:SPRING-CONFIG-FILES') ?? '{}')).toMatchObject({ value: 1, unit: 'file' })
  })
})
