import { mkdir, mkdtemp, rm, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'

import { afterEach, describe, expect, it } from 'vitest'

import { detectProjectSpecialization } from '../src/project/specializations.js'

const roots: string[] = []
async function projectRoot(): Promise<string> { const root = await mkdtemp(path.join(os.tmpdir(), 'archscope-specialization-')); roots.push(root); return root }
afterEach(async () => { await Promise.all(roots.splice(0).map(root => rm(root, { recursive: true, force: true }))) })

describe('deterministic project specialization', () => {
  it('does not dispatch a plain Maven library to the Spring backend Agent', async () => {
    const root = await projectRoot()
    await writeFile(path.join(root, 'pom.xml'), '<project><artifactId>shared-dto</artifactId></project>')
    await mkdir(path.join(root, 'src/main/java/demo'), { recursive: true })
    await writeFile(path.join(root, 'src/main/java/demo/Dto.java'), 'package demo; public record Dto(String id) {}')

    await expect(detectProjectSpecialization(root)).resolves.toMatchObject({ specialization: 'generic', template: 'generic', dispatchable: true })
  })

  it('routes a Spring Cloud executable service to the Spring backend Agent', async () => {
    const root = await projectRoot()
    await mkdir(path.join(root, 'src/main/java/demo'), { recursive: true })
    await writeFile(path.join(root, 'pom.xml'), '<project><dependency>spring-cloud-starter-openfeign</dependency><plugin>spring-boot-maven-plugin</plugin></project>')
    await writeFile(path.join(root, 'src/main/java/demo/App.java'), '@SpringBootApplication class App { public static void main(String[] a) { SpringApplication.run(App.class, a); } }')

    await expect(detectProjectSpecialization(root)).resolves.toMatchObject({ specialization: 'java-spring-backend', template: 'java-backend', framework: 'spring-cloud', dispatchable: true })
  })

  it('separates Vue, native Android, and native iOS agents', async () => {
    const vue = await projectRoot()
    await writeFile(path.join(vue, 'package.json'), JSON.stringify({ dependencies: { vue: '^3.0.0' }, devDependencies: { vite: '^7.0.0' } }))
    await mkdir(path.join(vue, 'src/router'), { recursive: true })

    const android = await projectRoot()
    await mkdir(path.join(android, 'app/src/main'), { recursive: true })
    await writeFile(path.join(android, 'app/src/main/AndroidManifest.xml'), '<manifest/>')
    await writeFile(path.join(android, 'app/build.gradle'), "plugins { id 'com.android.application' }; android { defaultConfig { applicationId 'demo.app' } }")

    const ios = await projectRoot()
    await mkdir(path.join(ios, 'Demo.xcodeproj'), { recursive: true })
    await mkdir(path.join(ios, 'Demo'), { recursive: true })
    await writeFile(path.join(ios, 'Demo/Info.plist'), '<plist/>')

    await expect(detectProjectSpecialization(vue)).resolves.toMatchObject({ specialization: 'web-vue', template: 'web-frontend' })
    await expect(detectProjectSpecialization(android)).resolves.toMatchObject({ specialization: 'android-native', template: 'android' })
    await expect(detectProjectSpecialization(ios)).resolves.toMatchObject({ specialization: 'ios-native', template: 'ios' })
  })

  it('does not mistake React Native generated folders for native Android or iOS', async () => {
    const root = await projectRoot()
    await writeFile(path.join(root, 'package.json'), JSON.stringify({ dependencies: { 'react-native': '1.0.0' } }))
    await mkdir(path.join(root, 'android/app/src/main'), { recursive: true })
    await writeFile(path.join(root, 'android/app/src/main/AndroidManifest.xml'), '<manifest/>')
    await mkdir(path.join(root, 'ios/Demo.xcodeproj'), { recursive: true })
    await writeFile(path.join(root, 'ios/Info.plist'), '<plist/>')

    await expect(detectProjectSpecialization(root)).resolves.toMatchObject({ specialization: 'generic', template: 'generic', dispatchable: true })
  })

  it('fails closed for a composite Java service and frontend analysis unit', async () => {
    const root = await projectRoot()
    await mkdir(path.join(root, 'src/main/java/demo'), { recursive: true })
    await writeFile(path.join(root, 'pom.xml'), '<project><plugin>spring-boot-maven-plugin</plugin></project>')
    await writeFile(path.join(root, 'src/main/java/demo/App.java'), '@SpringBootApplication class App {}')
    await writeFile(path.join(root, 'package.json'), JSON.stringify({ dependencies: { vue: '3' } }))
    await mkdir(path.join(root, 'src/router'), { recursive: true })

    await expect(detectProjectSpecialization(root)).resolves.toMatchObject({ specialization: 'generic', template: 'generic', dispatchable: false, conflictingSignals: expect.arrayContaining(['java-spring-backend', 'web-vue']) })
  })
})
