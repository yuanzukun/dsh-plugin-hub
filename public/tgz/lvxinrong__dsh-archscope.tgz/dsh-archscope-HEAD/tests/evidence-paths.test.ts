import { mkdir, mkdtemp, rm, symlink, writeFile } from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'

import { afterEach, describe, expect, it } from 'vitest'

import { invalidEvidencePathsAtRoot, nonAtomicEvidencePaths } from '../src/system/evidence-paths.js'

const temporaryRoots: string[] = []

afterEach(async () => {
  await Promise.all(temporaryRoots.splice(0).map(root => rm(root, { recursive: true, force: true })))
})

describe('atomic evidence paths', () => {
  it('rejects grouped, annotated, combined, URL, and line-suffixed values', () => {
    expect(nonAtomicEvidencePaths([
      'src/{Main,Config}.java',
      'src/*.java',
      'pom.xml（依赖）',
      'src/Main.java:42',
      'index.html:8 (script reference)',
      '.env.development / .env.production',
      'https://example.com/source',
    ])).toHaveLength(7)
    expect(nonAtomicEvidencePaths(['pom.xml', 'src/Main.java'])).toEqual([])
  })

  it('requires every accepted relative path to resolve to a regular in-project file', async () => {
    const root = await mkdtemp(path.join(os.tmpdir(), 'archscope-evidence-paths-'))
    temporaryRoots.push(root)
    await mkdir(path.join(root, 'src'), { recursive: true })
    await writeFile(path.join(root, 'src', 'Main.java'), 'class Main {}')
    await symlink(path.join(root, 'src', 'Main.java'), path.join(root, 'src', 'MainLink.java'))

    const invalid = await invalidEvidencePathsAtRoot(root, [
      'src/Main.java',
      'src/Missing.java',
      'src',
      'src/MainLink.java',
    ])

    expect(invalid).toEqual(expect.arrayContaining([
      { path: 'src/Missing.java', reason: 'file does not exist' },
      { path: 'src', reason: 'path does not identify a file' },
      { path: 'src/MainLink.java', reason: 'symbolic links are not accepted as evidence files' },
    ]))
    expect(invalid.map(item => item.path)).not.toContain('src/Main.java')
  })
})
