import type {
  GateStatus,
  IndexRecord,
  ProjectRecord,
  ProjectSystemEvidence,
  ProtocolRunReference,
  SystemRelationRecord,
  SystemSynthesisPageItem,
  ValidationIssue,
  ValidationStatus,
} from './system-scan.js'

export const PROJECT_SCAN_PROTOCOL = 'archscope/project-scan/v1'
export const PROJECT_DOCUMENT_PROTOCOL = 'archscope/contract/project-document/v1'

export type ProjectTemplate =
  | 'java-backend'
  | 'web-frontend'
  | 'miniprogram-wechat'
  | 'android'
  | 'ios'
  | 'generic'

export type ProjectSpecialization =
  | 'java-spring-backend'
  | 'web-vue'
  | 'web-frontend'
  | 'miniprogram-wechat'
  | 'android-native'
  | 'ios-native'
  | 'generic'

export type SpringFrameworkVariant = 'spring-framework' | 'spring-boot' | 'spring-cloud'

export interface ProjectSpecializationDecision {
  specialization: ProjectSpecialization
  template: ProjectTemplate
  framework?: SpringFrameworkVariant
  confidence: 'HIGH' | 'MEDIUM' | 'LOW'
  matchedSignals: string[]
  conflictingSignals: string[]
  decisionReason: string
  dispatchable: boolean
}

export type ProjectScanStatus =
  | 'VALIDATING_SYSTEM_GATE'
  | 'PREPARING_INDEX'
  | 'COLLECTING_PROJECT_EVIDENCE'
  | 'AWAITING_PROJECT_SYNTHESIS'
  | 'SYNTHESIZING'
  | 'COMPLETED'
  | 'BLOCKED'
  | 'FAILED'

export interface ProjectRunTransition {
  status: ProjectScanStatus
  at: string
}

export interface ProjectScanRunState {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  protocol: ProtocolRunReference
  runId: string
  projectKey: string
  projectDir: string
  specialization: ProjectSpecialization
  framework?: SpringFrameworkVariant
  projectRevision: string
  sourceSystemRunId: string
  sourceSystemRevision: string
  status: ProjectScanStatus
  gate: GateStatus
  validation: ValidationStatus
  startedAt: string
  updatedAt: string
  finishedAt?: string
  workspaceRoot: '.'
  outputDirectory: string
  refresh: boolean
  indexStatus: IndexRecord['status']
  evidenceStatus: 'PENDING' | 'COLLECTED' | 'FAILED'
  scopeViolationCount: number
  conflictCount: number
  blockingConflictCount: number
  reconciliationStatus: ProjectReconciliationStatus
  synthesisInputDigest?: string
  synthesisAttempts?: number
  transitions: ProjectRunTransition[]
  error?: string
}

export type ProjectEvidenceConfidence = 'DIRECT_SOURCE' | 'CONFIGURATION' | 'INFERENCE'

export type ProjectConflictKind =
  | 'REFINEMENT'
  | 'LOCAL_SOURCE_CONTRADICTION'
  | 'CROSS_PROJECT_CONTRADICTION'
  | 'RUNTIME_SCOPE_MISMATCH'
  | 'STALE_UPSTREAM'
  | 'IDENTITY_MISMATCH'

export type ProjectConflictSeverity = 'NON_BLOCKING' | 'BLOCKING'
export type ProjectReconciliationStatus = 'NOT_REQUIRED' | 'OPEN' | 'BLOCKED' | 'RESOLVED'

export interface ProjectEvidenceItem {
  summary: string
  evidencePaths: string[]
  confidence: ProjectEvidenceConfidence
}

export interface ProjectConflictRecord {
  conflictId: string
  kind: ProjectConflictKind
  severity: ProjectConflictSeverity
  systemClaimId?: string
  systemEvidencePointer: 'SYSTEM_FACT_BASE' | 'SYSTEM_EVIDENCE'
  systemEvidenceQuote: string
  systemAssertion: string
  projectAssertion: string
  rationale: string
  evidencePaths: string[]
  confidence: ProjectEvidenceConfidence
  reconciliationStatus: ProjectReconciliationStatus
  sourceSystemRevision?: string
}

export interface ProjectStatistic {
  metricId?: string
  metric: string
  count: number
  unit: string
  scope?: string
  queryMethod: string
  exclusions: string
  evidencePaths: string[]
  confidence: ProjectEvidenceConfidence
  authority?: 'PARENT_DETERMINISTIC' | 'AGENT_OBSERVED'
  completeness?: 'COMPLETE' | 'PARTIAL'
}

export interface ProjectDeterministicMetric {
  metricId: string
  label: string
  value: number
  unit: string
  scope: string
  method: string
  exclusions: string
  evidencePaths: string[]
  completeness: 'COMPLETE' | 'PARTIAL'
}

export interface ProjectNegativeClaimRule {
  ruleId: string
  claim: string
  allowed: boolean
  reason: string
  forbiddenPatterns: string[]
}

export interface ProjectModuleDependency {
  sourceModule: string
  targetModule: string
  sourceManifest: string
  targetManifest: string
  scope: 'COMPILE' | 'PROVIDED' | 'RUNTIME' | 'TEST' | 'SYSTEM' | 'IMPORT'
  optional: boolean
}

export interface ProjectDeterministicFacts {
  protocolVersion: 'archscope/project-deterministic-facts/v1'
  specialization: 'java-spring-backend'
  generatedAt: string
  boundary: 'PROJECT_ROOT_ONLY'
  scanStatus: 'COMPLETE' | 'PARTIAL'
  scannedFileCount: number
  skippedFileCount: number
  moduleManifests: string[]
  moduleDependencies: ProjectModuleDependency[]
  configurationFiles: string[]
  metrics: ProjectDeterministicMetric[]
  negativeClaimRules: ProjectNegativeClaimRule[]
  coverageGaps: string[]
}

export interface ProjectDeepEvidence {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  generatedAt: string
  projectKey: string
  projectDir: string
  mcpProject: string
  specialization: ProjectSpecialization
  framework?: SpringFrameworkVariant
  specializationDecision: ProjectSpecializationDecision
  template: ProjectTemplate
  status: 'COLLECTED' | 'FAILED'
  identity: ProjectEvidenceItem[]
  statistics: ProjectStatistic[]
  technology: ProjectEvidenceItem[]
  buildAndRun: ProjectEvidenceItem[]
  configuration: ProjectEvidenceItem[]
  entrypoints: ProjectEvidenceItem[]
  dependencies: ProjectEvidenceItem[]
  dataAssets: ProjectEvidenceItem[]
  structure: ProjectEvidenceItem[]
  security: ProjectEvidenceItem[]
  observability: ProjectEvidenceItem[]
  deployment: ProjectEvidenceItem[]
  tests: ProjectEvidenceItem[]
  capabilities: ProjectEvidenceItem[]
  dataFlows: ProjectEvidenceItem[]
  chainCandidates: ProjectEvidenceItem[]
  risks: ProjectEvidenceItem[]
  constraints: ProjectEvidenceItem[]
  coverageGaps: ProjectEvidenceItem[]
  conflicts: ProjectConflictRecord[]
  moduleCandidates: ProjectEvidenceItem[]
  evidencePaths: string[]
  scopeStatus: 'CLEAN' | 'VIOLATION'
  scopeViolations: string[]
  failureReason?: string
}

export interface ProjectSynthesisInputs {
  sourceSystemFactBase: string
  project: ProjectRecord
  index: IndexRecord
  systemEvidence: ProjectSystemEvidence
  relatedRelations: SystemRelationRecord[]
  projectEvidence: ProjectDeepEvidence
  deterministicFacts?: ProjectDeterministicFacts
}

export type ProjectSynthesisDataset =
  | 'SYSTEM_FACT_BASE'
  | 'PROJECT_IDENTITY'
  | 'SYSTEM_RELATIONS'
  | 'PROJECT_EVIDENCE'
  | 'DETERMINISTIC_FACTS'

export interface ProjectSynthesisDatasetManifest {
  dataset: ProjectSynthesisDataset
  totalRecords: number
  totalBytes: number
  globalDigest: string
  nextCursor: string | null
  complete: boolean
}

export interface ProjectSynthesisReadManifest {
  inputDigest: string
  pageMaxBytes: number
  datasets: ProjectSynthesisDatasetManifest[]
}

export interface ProjectSynthesisDatasetReadState {
  dataset: ProjectSynthesisDataset
  globalDigest: string
  totalRecords: number
  nextCursor: string | null
  coveredRecordKeys: string[]
  pageDigests: string[]
  complete: boolean
}

export interface ProjectSynthesisReadLedger {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  runId: string
  protocolDigest: string
  inputDigest: string
  pageMaxBytes: number
  createdAt: string
  updatedAt: string
  datasets: ProjectSynthesisDatasetReadState[]
}

export interface ProjectSynthesisPage {
  runId: string
  protocolDigest: string
  dataset: ProjectSynthesisDataset
  cursor: string
  nextCursor: string | null
  pageDigest: string
  globalDigest: string
  pageBytes: number
  pageRecordCount: number
  coveredRecordCount: number
  totalRecords: number
  complete: boolean
  items: SystemSynthesisPageItem[]
}

export interface ProjectSynthesisContext {
  runId: string
  projectKey: string
  projectDir: string
  specialization: ProjectSpecialization
  framework?: SpringFrameworkVariant
  template: ProjectTemplate
  protocolDigest: string
  evidenceMode: 'PAGED'
  evidenceBytes: number
  pageMaxBytes: number
  manifest: ProjectSynthesisReadManifest
  protocolResourceIds: string[]
  prompt: string
}

export type ProjectEvidenceDataset =
  | 'SAFE_METADATA'
  | 'DETERMINISTIC_FACTS'
  | 'SYSTEM_PROJECT_EVIDENCE'
  | 'SYSTEM_FACT_BASE'

export interface ProjectEvidenceInputs {
  sourceSystemFactBase: string
  systemEvidence: ProjectSystemEvidence
  safeMetadata: {
    files: Array<{ path: string, kind: string, excerpt: string }>
    omittedFiles: number
    boundary: 'PROJECT_ROOT_ONLY'
  }
  deterministicFacts?: ProjectDeterministicFacts
}

export interface ProjectEvidenceDatasetManifest {
  dataset: ProjectEvidenceDataset
  totalRecords: number
  totalBytes: number
  globalDigest: string
  nextCursor: string | null
  complete: boolean
}

export interface ProjectEvidenceReadManifest {
  inputDigest: string
  pageMaxBytes: number
  datasets: ProjectEvidenceDatasetManifest[]
}

export interface ProjectEvidenceDatasetReadState {
  dataset: ProjectEvidenceDataset
  globalDigest: string
  totalRecords: number
  nextCursor: string | null
  coveredRecordKeys: string[]
  pageDigests: string[]
  complete: boolean
}

export interface ProjectEvidenceReadLedger {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  runId: string
  protocolDigest: string
  inputDigest: string
  pageMaxBytes: number
  createdAt: string
  updatedAt: string
  datasets: ProjectEvidenceDatasetReadState[]
}

export interface ProjectEvidencePage {
  runId: string
  protocolDigest: string
  dataset: ProjectEvidenceDataset
  cursor: string
  nextCursor: string | null
  pageDigest: string
  globalDigest: string
  pageBytes: number
  pageRecordCount: number
  coveredRecordCount: number
  totalRecords: number
  complete: boolean
  items: SystemSynthesisPageItem[]
}

export interface ProjectEvidenceTaskContext {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  runId: string
  projectKey: string
  projectDir: string
  specialization: ProjectSpecialization
  framework?: SpringFrameworkVariant
  mcpProject: string
  sourceSystemRevision: string
  evidenceMode: 'PAGED'
  manifest: ProjectEvidenceReadManifest
  protocolResourceIds: string[]
}

export interface ProjectProtocolResourceResult {
  runId: string
  phase: 'EVIDENCE' | 'WRITER'
  resourceId: string
  version: string
  kind: string
  digest: string
  content: string
}

export interface ProjectSynthesisDraft {
  profile: string
  diagrams: {
    projectContext: string
    structure: string
    entryDependency: string
  }
}

export interface ProjectSynthesisWriter {
  kind: 'dsh-project-writer-agent'
  specialization: ProjectSpecialization
  sessionId: string
  provider?: string
  model?: string
}

export interface ProjectSynthesisRecord {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  runId: string
  projectKey: string
  projectRevision: string
  previousRevision?: string
  sourceSystemRevision: string
  generatedAt: string
  writer: ProjectSynthesisWriter
  attempt: number
  protocolDigest: string
  inputDigest: string
  outputDigest: string
}

export interface ProjectValidationReport {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  protocol?: ProtocolRunReference
  generatedAt: string
  status: ValidationStatus
  gate: GateStatus
  conflictCount: number
  blockingConflictCount: number
  reconciliationStatus: ProjectReconciliationStatus
  issues: ValidationIssue[]
}

export interface ProjectHistoryRevision {
  revision: string
  previousRevision?: string
  runId: string
  sourceSystemRevision: string
  generatedAt: string
  status: ProjectScanStatus
  gate: GateStatus
  validation: ValidationStatus
  conflictCount: number
  blockingConflictCount: number
  reconciliationStatus: ProjectReconciliationStatus
  protocol: ProtocolRunReference
  synthesisAttempt: number
  outputDigest: string
  publishedAsCurrent: boolean
  artifactRoot: string
}

export interface ProjectHistoryIndex {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  projectKey: string
  updatedAt: string
  latestRevision?: string
  currentRevision?: string
  revisions: ProjectHistoryRevision[]
}

export interface ProjectScanProgress {
  stage: ProjectScanStatus
  message: string
  completed?: number
  total?: number
}

export interface ProjectScanResult {
  runId: string
  projectKey: string
  projectDir: string
  specialization: ProjectSpecialization
  framework?: SpringFrameworkVariant
  projectRevision: string
  sourceSystemRevision: string
  status: ProjectScanStatus
  gate: GateStatus
  validation: ValidationStatus
  indexStatus: IndexRecord['status']
  evidenceStatus: ProjectScanRunState['evidenceStatus']
  scopeViolationCount: number
  conflictCount: number
  blockingConflictCount: number
  reconciliationStatus: ProjectReconciliationStatus
  outputDirectory: string
  reused: boolean
}

export type ProjectBatchSelection =
  | { mode: 'PROJECT_KEYS'; projectKeys: string[] }
  | { mode: 'ALL_ELIGIBLE' }

export type ProjectBatchStatus = 'RUNNING' | 'COMPLETED' | 'PARTIAL' | 'FAILED'

export interface ProjectBatchProgress {
  batchId: string
  stage: 'PLANNING' | 'SCANNING' | 'SYNTHESIZING' | 'AGGREGATING' | 'COMPLETED'
  message: string
  completed: number
  total: number
  projectKey?: string
}

export interface ProjectBatchItemResult {
  projectKey: string
  status: 'COMPLETED' | 'BLOCKED' | 'FAILED'
  runId?: string
  result?: ProjectScanResult
  error?: string
}

export interface ProjectBatchRunState {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  batchId: string
  selection: ProjectBatchSelection
  sourceSystemRunId: string
  sourceSystemRevision: string
  status: ProjectBatchStatus
  startedAt: string
  updatedAt: string
  finishedAt?: string
  maxConcurrency: number
  projectKeys: string[]
  completedCount: number
  failedCount: number
  blockedCount: number
  conflictCount: number
  blockingConflictCount: number
  items: ProjectBatchItemResult[]
}

export interface ProjectBatchResult extends ProjectBatchRunState {
  outputDirectory: string
}

export interface ProjectSynthesisCommitResult extends ProjectScanResult {
  synthesisAttempt: number
  retryAllowed: boolean
  issues: ValidationIssue[]
}

export const PROJECT_SYNTHESIS_ARTIFACTS = [
  'PROFILE',
  'PROJECT_CONTEXT_DIAGRAM',
  'STRUCTURE_DIAGRAM',
  'ENTRY_DEPENDENCY_DIAGRAM',
] as const

export type ProjectSynthesisArtifact = typeof PROJECT_SYNTHESIS_ARTIFACTS[number]

export interface ProjectSynthesisStagedArtifact {
  artifact: ProjectSynthesisArtifact
  bytes: number
  digest: string
  stagedAt: string
  path: string
}

export interface ProjectSynthesisStagingState {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  runId: string
  updatedAt: string
  artifacts: ProjectSynthesisStagedArtifact[]
}

export interface ProjectSynthesisStageResult {
  runId: string
  projectKey: string
  artifact: ProjectSynthesisArtifact
  stagedCount: number
  totalArtifacts: number
  missingArtifacts: ProjectSynthesisArtifact[]
  readyToFinalize: boolean
}

export interface ProjectSynthesisFinalizeResult {
  finalizeStatus: 'INCOMPLETE' | 'COMMITTED'
  runId: string
  projectKey: string
  stagedCount: number
  totalArtifacts: number
  missingArtifacts: ProjectSynthesisArtifact[]
  commit?: ProjectSynthesisCommitResult
}
