import { createHash } from 'node:crypto'

import {
  SYSTEM_SCAN_PROTOCOL,
  type IndexManifest,
  type ProjectRegistry,
  type ProjectSystemEvidence,
  type SystemEvidenceBundle,
  type SystemRelationCatalog,
  type SystemRelationRecord,
  type SystemSynthesisDataset,
  type SystemSynthesisPage,
  type SystemSynthesisReadLedger,
  type SystemSynthesisReadManifest,
} from '../contracts/system-scan.js'

export const SYNTHESIS_PAGE_MAX_BYTES = 20 * 1024
export const SYSTEM_SYNTHESIS_DATASETS: SystemSynthesisDataset[] = [
  'PROJECT_REGISTRY',
  'INDEX_MANIFEST',
  'RELATIONS',
  'PROJECT_EVIDENCE',
]

interface SynthesisSourceRecord {
  key: string
  json: string
}

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex')
}

function recordSources(
  dataset: SystemSynthesisDataset,
  registry: ProjectRegistry,
  indexes: IndexManifest,
  evidence: SystemEvidenceBundle,
  relations: SystemRelationCatalog,
): SynthesisSourceRecord[] {
  if (dataset === 'PROJECT_REGISTRY') return [{ key: 'project-registry', json: JSON.stringify(registry) }]
  if (dataset === 'INDEX_MANIFEST') return [{ key: 'index-manifest', json: JSON.stringify(indexes) }]
  if (dataset === 'RELATIONS') {
    return relations.records.map((record: SystemRelationRecord) => ({ key: record.relationId, json: JSON.stringify(record) }))
  }
  return evidence.records.map((record: ProjectSystemEvidence) => ({ key: record.projectKey, json: JSON.stringify(record) }))
}

function serializedDataset(records: SynthesisSourceRecord[]): string {
  return '[' + records.map(record => record.json).join(',') + ']'
}

function sourceDigest(records: SynthesisSourceRecord[]): string {
  return sha256(serializedDataset(records))
}

function sourceBytes(records: SynthesisSourceRecord[]): number {
  return Buffer.byteLength(serializedDataset(records), 'utf8')
}

function parseCursor(cursor: string): { recordIndex: number, byteOffset: number } {
  const match = /^(\d+):(\d+)$/u.exec(cursor)
  if (match === null) throw new Error('Invalid ArchScope synthesis page cursor: ' + cursor)
  return { recordIndex: Number(match[1]), byteOffset: Number(match[2]) }
}

function utf8Prefix(value: string, maxBytes: number): string {
  let bytes = 0
  let result = ''
  for (const character of value) {
    const size = Buffer.byteLength(character, 'utf8')
    if (bytes + size > maxBytes) break
    result += character
    bytes += size
  }
  return result
}

export function buildSystemSynthesisReadManifest(
  inputDigest: string,
  registry: ProjectRegistry,
  indexes: IndexManifest,
  evidence: SystemEvidenceBundle,
  relations: SystemRelationCatalog,
  ledger?: SystemSynthesisReadLedger,
): SystemSynthesisReadManifest {
  return {
    inputDigest,
    pageMaxBytes: SYNTHESIS_PAGE_MAX_BYTES,
    datasets: SYSTEM_SYNTHESIS_DATASETS.map(dataset => {
      const records = recordSources(dataset, registry, indexes, evidence, relations)
      const state = ledger?.datasets.find(candidate => candidate.dataset === dataset)
      return {
        dataset,
        totalRecords: records.length,
        totalBytes: sourceBytes(records),
        globalDigest: sourceDigest(records),
        nextCursor: state === undefined ? (records.length === 0 ? null : '0:0') : state.nextCursor,
        complete: state?.complete ?? records.length === 0,
      }
    }),
  }
}

export function createSystemSynthesisReadLedger(
  runId: string,
  protocolDigest: string,
  manifest: SystemSynthesisReadManifest,
  now = new Date().toISOString(),
): SystemSynthesisReadLedger {
  return {
    protocolVersion: SYSTEM_SCAN_PROTOCOL,
    runId,
    protocolDigest,
    inputDigest: manifest.inputDigest,
    pageMaxBytes: manifest.pageMaxBytes,
    createdAt: now,
    updatedAt: now,
    datasets: manifest.datasets.map(dataset => ({
      dataset: dataset.dataset,
      globalDigest: dataset.globalDigest,
      totalRecords: dataset.totalRecords,
      nextCursor: dataset.nextCursor,
      coveredRecordKeys: [],
      pageDigests: [],
      complete: dataset.complete,
    })),
  }
}

export function buildSystemSynthesisPage(
  runId: string,
  protocolDigest: string,
  dataset: SystemSynthesisDataset,
  cursor: string,
  registry: ProjectRegistry,
  indexes: IndexManifest,
  evidence: SystemEvidenceBundle,
  relations: SystemRelationCatalog,
): SystemSynthesisPage {
  const records = recordSources(dataset, registry, indexes, evidence, relations)
  let { recordIndex, byteOffset } = parseCursor(cursor)
  if (recordIndex > records.length || (recordIndex === records.length && byteOffset !== 0)) {
    throw new Error('ArchScope synthesis page cursor is outside ' + dataset + '.')
  }
  const items: SystemSynthesisPage['items'] = []
  let pageBytes = 0
  while (recordIndex < records.length && pageBytes < SYNTHESIS_PAGE_MAX_BYTES) {
    const record = records[recordIndex] as SynthesisSourceRecord
    const recordBuffer = Buffer.from(record.json, 'utf8')
    const fullBytes = recordBuffer.byteLength
    if (byteOffset > fullBytes) throw new Error('ArchScope synthesis page cursor is outside record ' + record.key + '.')
    const remaining = byteOffset === 0 ? record.json : recordBuffer.subarray(byteOffset).toString('utf8')
    const chunk = utf8Prefix(remaining, SYNTHESIS_PAGE_MAX_BYTES - pageBytes)
    if (chunk === '') break
    const chunkBytes = Buffer.byteLength(chunk, 'utf8')
    const completeRecord = byteOffset + chunkBytes === fullBytes
    items.push({
      recordKey: record.key,
      recordDigest: sha256(record.json),
      json: chunk,
      byteOffset,
      totalBytes: fullBytes,
      completeRecord,
    })
    pageBytes += chunkBytes
    if (completeRecord) {
      recordIndex += 1
      byteOffset = 0
    } else {
      byteOffset += chunkBytes
      break
    }
  }
  const complete = recordIndex === records.length
  const nextCursor = complete ? null : String(recordIndex) + ':' + String(byteOffset)
  const pageDigest = sha256(JSON.stringify({ dataset, cursor, nextCursor, items }))
  return {
    runId,
    protocolDigest,
    dataset,
    cursor,
    nextCursor,
    pageDigest,
    globalDigest: sourceDigest(records),
    pageBytes,
    pageRecordCount: items.filter(item => item.completeRecord).length,
    coveredRecordCount: recordIndex,
    totalRecords: records.length,
    complete,
    items,
  }
}
