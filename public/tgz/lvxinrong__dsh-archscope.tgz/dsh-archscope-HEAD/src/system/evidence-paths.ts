import { lstat } from 'node:fs/promises'
import path from 'node:path'

const NON_ATOMIC_PATH_PATTERNS: Array<{ reason: string, pattern: RegExp }> = [
  { reason: 'absolute path', pattern: /^(?:\/|[A-Za-z]:[\\/])/u },
  { reason: 'parent traversal', pattern: /(?:^|[\\/])\.\.(?:[\\/]|$)/u },
  { reason: 'URL instead of a file path', pattern: /^[a-z][a-z0-9+.-]*:\/\//iu },
  { reason: 'glob or grouped path', pattern: /[*?{}[\]]/u },
  { reason: 'human annotation', pattern: /[（）]|\s+与\s+|、/u },
  { reason: 'multiple paths in one value', pattern: /\s+\/\s+/u },
  { reason: 'line reference instead of a file path', pattern: /:\d+(?:[-,]\d+)*(?:\s*[（(][^）)]*[）)])?$/u },
]

export function atomicEvidencePathProblem(value: string): string | undefined {
  const path = value.trim()
  if (path === '') return 'empty path'
  const match = NON_ATOMIC_PATH_PATTERNS.find(candidate => candidate.pattern.test(path))
  return match?.reason
}

export function nonAtomicEvidencePaths(values: Iterable<string>): Array<{ path: string, reason: string }> {
  return [...values].flatMap(value => {
    const reason = atomicEvidencePathProblem(value)
    return reason === undefined ? [] : [{ path: value, reason }]
  })
}

export async function invalidEvidencePathsAtRoot(
  projectRoot: string,
  values: Iterable<string>,
): Promise<Array<{ path: string, reason: string }>> {
  const paths = [...values]
  const invalid = nonAtomicEvidencePaths(paths)
  const invalidValues = new Set(invalid.map(item => item.path))
  const root = path.resolve(projectRoot)
  const filesystemResults = await Promise.all(paths.filter(value => !invalidValues.has(value)).map(async value => {
    const resolved = path.resolve(root, value)
    const relative = path.relative(root, resolved)
    if (relative === '' || relative.startsWith('..' + path.sep) || path.isAbsolute(relative)) {
      return { path: value, reason: 'path escapes the project root' }
    }
    try {
      const status = await lstat(resolved)
      if (status.isSymbolicLink()) return { path: value, reason: 'symbolic links are not accepted as evidence files' }
      if (!status.isFile()) return { path: value, reason: 'path does not identify a file' }
      return undefined
    } catch {
      return { path: value, reason: 'file does not exist' }
    }
  }))
  return [...invalid, ...filesystemResults.filter((item): item is { path: string, reason: string } => item !== undefined)]
}
