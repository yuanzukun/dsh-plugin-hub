import { createHash } from 'node:crypto'

import type {
  IndexManifest,
  ProjectRegistry,
  SystemEvidenceBundle,
  SystemRelationCatalog,
  SystemSynthesisContext,
  SystemSynthesisDraft,
  SystemSynthesisReadManifest,
} from '../contracts/system-scan.js'
import { protocolResource, type LoadedProtocolPack } from '../protocol/catalog.js'
import { projectTypeDistribution } from './artifacts.js'
import { systemRelationMetricValues } from './relations.js'

const SYSTEM_SCAN_PROMPT = 'archscope/prompt/system-scan/v1'
const SYSTEM_ANALYSIS_POLICY = 'archscope/policy/system-analysis/v1'
const EVIDENCE_POLICY = 'archscope/policy/evidence-and-redaction/v1'
const LAYER_GATE_POLICY = 'archscope/policy/layer-gates/v1'
const SYSTEM_DOCUMENT_CONTRACT = 'archscope/contract/system-document/v1'

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex')
}

export function systemSynthesisInputDigest(
  registry: ProjectRegistry,
  indexes: IndexManifest,
  evidence: SystemEvidenceBundle,
  relations: SystemRelationCatalog,
): string {
  return sha256(JSON.stringify({ registry, indexes, evidence, relations }))
}

export function systemSynthesisOutputDigest(draft: SystemSynthesisDraft): string {
  return sha256(JSON.stringify(draft))
}

export function buildSystemSynthesisContext(
  runId: string,
  pack: LoadedProtocolPack,
  registry: ProjectRegistry,
  indexes: IndexManifest,
  evidence: SystemEvidenceBundle,
  relations: SystemRelationCatalog,
  manifest: SystemSynthesisReadManifest,
): SystemSynthesisContext {
  const evidenceBytes = Buffer.byteLength(JSON.stringify(evidence.records), 'utf8')
  const relationMetrics = systemRelationMetricValues(relations)
  const projectMetrics = { '工程形态构成': projectTypeDistribution(registry.projects, evidence) }
  const datasetMetadata = {
    registry: {
      generatedAt: registry.generatedAt,
      projectCount: registry.projectCount,
      skippedDirectoryCount: registry.skippedDirectories.length,
    },
    indexes: { generatedAt: indexes.generatedAt, recordCount: indexes.records.length },
    relations: {
      generatedAt: relations.generatedAt,
      projectCount: relations.projectCount,
      projectsWithRelations: relations.projectsWithRelations,
      totalCount: relations.totalCount,
      internalCount: relations.internalCount,
      unresolvedCount: relations.unresolvedCount,
    },
    evidence: { generatedAt: evidence.generatedAt, recordCount: evidence.records.length },
  }
  const prompt = [
    '你是当前 DeepSeek Harness 会话的 ArchScope 系统级主写者。多个只读子 Agent 已分别完成单工程取证；现在必须由你建立跨工程世界观并生成最终系统级文档。系统级定世界观，项目级定工程画像，模块级定内部边界，代码级定具体链路。',
    '',
    '你不是证据采集 worker。不得重新扫描代码。原始输入采用无损分页，不压缩、不截断。你只能调用 archscope_get_system_synthesis_page 按清单读取 PROJECT_REGISTRY、INDEX_MANIFEST、RELATIONS、PROJECT_EVIDENCE 四个数据集，读取完毕后调用 archscope_commit_system_synthesis。除此之外不得调用其他取证工具。',
    '',
    '必须从每个数据集清单里的 nextCursor 开始顺序读取，后续逐字使用每页返回的 nextCursor，直到 complete=true。items[].json 是原始 JSON：completeRecord=true 时可直接解析；记录被跨页拆分时，必须按 recordKey 和 byteOffset 无缝拼接全部片段，并用 recordDigest 校验完整记录。不得跳页、抽样或只读高影响工程。服务端完整性账本会记录每一页；四个数据集未全部覆盖时提交会被拒绝。单页原始载荷上限 ' + String(manifest.pageMaxBytes) + ' UTF-8 bytes，完整 evidence 共 ' + String(evidenceBytes) + ' bytes、完整关系共 ' + String(relations.totalCount) + ' 条。',
    '',
    '工作要求：',
    '1. 阅读并执行完整的系统级指令、分析政策、证据政策、门禁政策和文档契约。',
    '2. 统一工程名、服务名和别名，综合入口、能力、基础设施、数据资产、内部关系、外部依赖与冲突。必须逐项仲裁分页读取到的完整 relations 目录；DIRECT_SOURCE/CONFIGURATION/NAME_MATCH 是证据强度而非生产状态，所有关系默认运行态未确认。关系数量只能引用下方“ArchScope 机器关系统计”，不得自行重新计数；插件会确定性写入机器字段并拒绝矛盾数字。工程类型的精确数量只能逐字引用“ArchScope 机器工程形态统计”，不得自行合并类别或换算；不需要精确数量时使用定性描述。',
    '3. 每条可信结论必须引用 evidence JSON 和/或其中给出的源码相对路径；不能只引用“模型判断”。',
    '4. 仅源码证据不得写成生产启用、生产入口、生产调用或生产归属。没有运行态或人工确认时必须明确写“待确认”。',
    '5. 不做项目级、模块级或代码级深挖，不写业务流程、重构建议、技术债务或代码热点。',
    '6. 生成严格符合契约顺序的完整 Markdown。不要省略任何章节；证据不足的章节保留并明确边界。',
    '7. 生成三个 Mermaid flowchart 源码，不要使用 Markdown 代码围栏，不要包含密码、Token、API Key、私钥、嵌入式账号密码或签名参数。架构标识可以保留，但图仍须保持系统级边界。每张图必须包含“实线=源码证据、虚线=待确认推断、不代表生产运行”的明确图例；候选或推断关系必须使用虚线。',
    '8. 机器字段“协议版本、事实版本、文档状态、证据状态、下层门禁、校验状态”和自检中的“项目级门禁”由插件在提交时规范化；你仍须保留对应表格行。事实版本由插件在终态提交时分配。若第 16 节存在真实的“阻断项目级”问题，最终门禁必须为 BLOCKED；READY 时该分类只能写“当前无阻断项”。',
    '9. 完成后必须调用 archscope_commit_system_synthesis，参数 runId 固定为 ' + runId + '，并提交 factBase 与三个 Mermaid 图。若工具返回可修订的校验失败，依据 issues 修订后最多再提交一次。',
    '10. 提交成功后，用中文向用户汇报系统世界观摘要、主要可信边界、校验结果和产物路径。只使用工作区相对路径；history.json 位于当前发布根 system/history.json，不在 runs/<run-id>/system 快照内。',
    '',
    '===== 系统级主写者指令 =====',
    protocolResource(pack, SYSTEM_SCAN_PROMPT).content,
    '',
    '===== 系统级分析政策 =====',
    protocolResource(pack, SYSTEM_ANALYSIS_POLICY).content,
    '',
    '===== 证据保真与凭据政策 =====',
    protocolResource(pack, EVIDENCE_POLICY).content,
    '',
    '===== 层级门禁政策 =====',
    protocolResource(pack, LAYER_GATE_POLICY).content,
    '',
    '===== 系统文档契约 =====',
    protocolResource(pack, SYSTEM_DOCUMENT_CONTRACT).content,
    '',
    '===== 无损分页读取清单（完整性账本） =====',
    JSON.stringify(manifest),
    '',
    '===== 数据集元数据（原始记录必须从分页工具完整读取） =====',
    JSON.stringify(datasetMetadata),
    '',
    '===== ArchScope 机器关系统计（唯一数字事实，不得重算） =====',
    JSON.stringify(relationMetrics),
    '',
    '===== ArchScope 机器工程形态统计（唯一数字事实，不得重算） =====',
    JSON.stringify(projectMetrics),
    '',
    '现在先按读取清单逐页读取全部四个数据集；账本完整后再开始跨工程语义综合。不要把确定性分类候选直接当作结论；必须进行证据仲裁后再提交。',
  ].join('\n')

  return {
    runId,
    protocolDigest: pack.lock.packDigest,
    evidenceMode: 'PAGED',
    evidenceBytes,
    pageMaxBytes: manifest.pageMaxBytes,
    relationCount: relations.totalCount,
    manifest,
    prompt,
  }
}
