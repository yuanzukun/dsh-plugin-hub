import Schema from '@deepseek-ai/schemastery'

export interface Config {
  workspaceRoot?: string
  outputDirectory: string
  discoveryMaxDepth: number
  codebaseMemoryServerName?: string
  indexMode?: 'fast' | 'moderate' | 'full'
  evidenceProvider?: string
  systemConcurrency?: number
  projectConcurrency?: number
  evidenceContextMode?: 'auto' | 'full' | 'bounded'
  fullEvidenceMaxBytes?: number
  registerCommand: boolean
  registerSystemScanTool: boolean
  registerProjectScanTool?: boolean
  registerStatusTool: boolean
}

export const Config: Schema<Config> = Schema.object({
  workspaceRoot: Schema.string()
    .description('Optional scan-root override. By default ArchScope uses the current DeepSeek Harness session workspace; relative overrides resolve from that workspace.'),
  outputDirectory: Schema.string()
    .default('archscope_docs')
    .description('Directory where ArchScope will write generated analysis artifacts.'),
  discoveryMaxDepth: Schema.number()
    .min(1)
    .max(12)
    .default(3)
    .description('Maximum directory depth used to discover Git project roots.'),
  codebaseMemoryServerName: Schema.string()
    .default('codebase_memory_mcp')
    .description('DSH MCP server namespace that provides codebase-memory tools.'),
  indexMode: Schema.union(['fast', 'moderate', 'full'] as const)
    .default('moderate')
    .description('codebase-memory indexing mode used for newly indexed or refreshed projects.'),
  evidenceProvider: Schema.string()
    .default('spawn')
    .description('DSH one-shot subagent provider used for read-only per-project system evidence workers.'),
  systemConcurrency: Schema.number()
    .min(1)
    .max(16)
    .default(4)
    .description('Maximum concurrent indexing and system evidence tasks.'),
  projectConcurrency: Schema.number()
    .min(1)
    .max(16)
    .default(4)
    .description('Maximum concurrent project pipelines in a project batch. Single-project scans use the same pipeline with a batch size of one.'),
  evidenceContextMode: Schema.union(['auto', 'full', 'bounded'] as const)
    .default('auto')
    .description('Deprecated compatibility option. System synthesis now always uses lossless paging.'),
  fullEvidenceMaxBytes: Schema.number()
    .min(65536)
    .max(4194304)
    .default(524288)
    .description('Deprecated compatibility option. Lossless page size is protocol-owned and cannot be overridden.'),
  registerCommand: Schema.boolean()
    .default(true)
    .description('Register the deterministic /archscope command when a command adapter is available.'),
  registerSystemScanTool: Schema.boolean()
    .default(true)
    .description('Register the archscope_scan_system model-facing tool.'),
  registerProjectScanTool: Schema.boolean()
    .default(true)
    .description('Register project scan, lossless synthesis, and commit tools.'),
  registerStatusTool: Schema.boolean()
    .default(true)
    .description('Register the archscope_status run inspection tool.'),
})
