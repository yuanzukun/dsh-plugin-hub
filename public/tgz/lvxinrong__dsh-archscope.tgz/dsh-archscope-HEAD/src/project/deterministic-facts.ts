import { lstat, readdir, readFile } from 'node:fs/promises'
import path from 'node:path'

import type { ProjectDeterministicFacts, ProjectDeterministicMetric, ProjectModuleDependency, ProjectStatistic } from '../contracts/project-scan.js'

const MAX_FILES = 100_000
const MAX_SOURCE_BYTES = 2 * 1024 * 1024
const MAX_EVIDENCE_PATHS = 12

const EXCLUDED_DIRECTORIES = new Set([
  '.git', '.gradle', '.idea', '.next', '.nuxt', '.svn',
  'archscope_docs', 'node_modules', 'target',
])
const OUTPUT_DIRECTORIES = new Set(['build', 'coverage', 'dist', 'vendor'])

interface Counter {
  value: number
  paths: Set<string>
}

function counter(): Counter { return { value: 0, paths: new Set() } }
function add(target: Counter, relativePath: string, count = 1): void {
  target.value += count
  if (target.paths.size < MAX_EVIDENCE_PATHS) target.paths.add(relativePath)
}
function occurrences(content: string, pattern: RegExp): number { return [...content.matchAll(pattern)].length }
function portable(relativePath: string): string { return relativePath.split(path.sep).join('/') }
function errorCode(value: unknown): string {
  return typeof value === 'object' && value !== null && 'code' in value && typeof value.code === 'string' ? value.code : 'READ_FAILED'
}
function javaCodeOnly(value: string): string {
  let output = ''
  let state: 'CODE' | 'LINE_COMMENT' | 'BLOCK_COMMENT' | 'STRING' | 'CHAR' | 'TEXT_BLOCK' = 'CODE'
  for (let index = 0; index < value.length; index += 1) {
    const character = value[index] as string
    const next = value[index + 1]
    if (state === 'CODE') {
      if (value.slice(index, index + 3) === '"""') { state = 'TEXT_BLOCK'; output += '   '; index += 2 }
      else if (character === '/' && next === '/') { state = 'LINE_COMMENT'; output += '  '; index += 1 }
      else if (character === '/' && next === '*') { state = 'BLOCK_COMMENT'; output += '  '; index += 1 }
      else if (character === '"') { state = 'STRING'; output += ' ' }
      else if (character === "'") { state = 'CHAR'; output += ' ' }
      else output += character
      continue
    }
    if (state === 'LINE_COMMENT') {
      if (character === '\n') { state = 'CODE'; output += '\n' } else output += ' '
      continue
    }
    if (state === 'BLOCK_COMMENT') {
      if (character === '*' && next === '/') { state = 'CODE'; output += '  '; index += 1 }
      else output += character === '\n' ? '\n' : ' '
      continue
    }
    if (state === 'TEXT_BLOCK') {
      if (value.slice(index, index + 3) === '"""') { state = 'CODE'; output += '   '; index += 2 }
      else output += character === '\n' ? '\n' : ' '
      continue
    }
    const quote = state === 'STRING' ? '"' : "'"
    if (character === '\\') { output += ' '; if (next !== undefined) { output += next === '\n' ? '\n' : ' '; index += 1 } }
    else if (character === quote) { state = 'CODE'; output += ' ' }
    else output += character === '\n' ? '\n' : ' '
  }
  return output
}
function inside(root: string, candidate: string): boolean {
  const relative = path.relative(root, candidate)
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative))
}
function excludedDirectory(relativePath: string, name: string): boolean {
  if (EXCLUDED_DIRECTORIES.has(name)) return true
  const normalized = portable(relativePath).toLowerCase()
  const insideJavaSource = normalized.startsWith('src/main/java/') || normalized.includes('/src/main/java/')
    || normalized.startsWith('src/test/java/') || normalized.includes('/src/test/java/')
  if (name === 'build' && insideJavaSource) return false
  return OUTPUT_DIRECTORIES.has(name)
}
function springConfigurationPath(relativePath: string): boolean {
  const normalized = portable(relativePath).toLowerCase()
  if (!normalized.includes('/src/main/resources/')) return false
  const name = path.basename(normalized)
  return /^(?:application|bootstrap)(?:[-.][^/]*)?\.(?:ya?ml|properties)$/u.test(name)
    || /^(?:logback(?:-spring)?|mybatis-config)\.xml$/u.test(name)
    || normalized.includes('/src/main/resources/config/') && /\.(?:ya?ml|properties|conf|config|xml|json|toml)$/u.test(name)
}
function mainJavaPath(relativePath: string): boolean {
  const normalized = portable(relativePath).toLowerCase()
  return normalized.startsWith('src/main/java/') || normalized.includes('/src/main/java/')
}
function mainResourcesPath(relativePath: string): boolean {
  const normalized = portable(relativePath).toLowerCase()
  return normalized.startsWith('src/main/resources/') || normalized.includes('/src/main/resources/')
}

function withoutXmlSection(content: string, name: string): string {
  return content.replace(new RegExp(`<${name}\\b[^>]*>[\\s\\S]*?<\\/${name}>`, 'giu'), '')
}

function xmlElement(content: string, name: string): string | undefined {
  const match = new RegExp(`<${name}\\b[^>]*>\\s*([^<]+?)\\s*<\\/${name}>`, 'iu').exec(content)
  return match?.[1]?.trim()
}

async function collectMavenModuleDependencies(
  root: string,
  manifests: string[],
  coverageGaps: string[],
): Promise<ProjectModuleDependency[]> {
  const poms = new Map<string, { artifactId: string, content: string }>()
  for (const manifest of manifests) {
    const absolute = path.resolve(root, manifest)
    const stat = await lstat(absolute).catch(() => undefined)
    if (stat === undefined || !stat.isFile() || stat.isSymbolicLink() || stat.size > MAX_SOURCE_BYTES) {
      coverageGaps.push(`${manifest}: Maven module dependency metadata was not scanned`)
      continue
    }
    const content = await readFile(absolute, 'utf8').catch(error => {
      coverageGaps.push(`${manifest}: ${errorCode(error)}`)
      return undefined
    })
    if (content === undefined || content.includes('\u0000')) continue
    const normalized = withoutXmlSection(content.replace(/<!--[\s\S]*?-->/gu, ''), 'parent')
    const artifactId = xmlElement(normalized, 'artifactId')
    if (artifactId !== undefined) poms.set(manifest, { artifactId, content })
  }

  const manifestsByArtifact = new Map<string, string[]>()
  for (const [manifest, pom] of poms) {
    manifestsByArtifact.set(pom.artifactId, [...(manifestsByArtifact.get(pom.artifactId) ?? []), manifest])
  }
  const dependencies: ProjectModuleDependency[] = []
  for (const [sourceManifest, pom] of poms) {
    let dependencySource = pom.content.replace(/<!--[\s\S]*?-->/gu, '')
    for (const section of ['dependencyManagement', 'build', 'profiles', 'reporting']) dependencySource = withoutXmlSection(dependencySource, section)
    for (const match of dependencySource.matchAll(/<dependency\b[^>]*>([\s\S]*?)<\/dependency>/giu)) {
      const block = match[1] ?? ''
      const targetArtifact = xmlElement(block, 'artifactId')
      if (targetArtifact === undefined || targetArtifact === pom.artifactId) continue
      const targets = manifestsByArtifact.get(targetArtifact)
      if (targets === undefined || targets.length !== 1) continue
      const rawScope = (xmlElement(block, 'scope') ?? 'compile').toUpperCase()
      const scope = ['COMPILE', 'PROVIDED', 'RUNTIME', 'TEST', 'SYSTEM', 'IMPORT'].includes(rawScope)
        ? rawScope as ProjectModuleDependency['scope']
        : 'COMPILE'
      dependencies.push({
        sourceModule: pom.artifactId,
        targetModule: targetArtifact,
        sourceManifest,
        targetManifest: targets[0] as string,
        scope,
        optional: (xmlElement(block, 'optional') ?? 'false').toLowerCase() === 'true',
      })
    }
  }
  return dependencies
    .filter((item, index, values) => values.findIndex(candidate => candidate.sourceModule === item.sourceModule && candidate.targetModule === item.targetModule && candidate.scope === item.scope) === index)
    .sort((left, right) => `${left.sourceModule}\0${left.targetModule}\0${left.scope}`.localeCompare(`${right.sourceModule}\0${right.targetModule}\0${right.scope}`))
}

export async function collectSpringProjectFacts(projectRoot: string, generatedAt: string): Promise<ProjectDeterministicFacts> {
  const root = path.resolve(projectRoot)
  const moduleManifests = new Set<string>()
  const configurationFiles = new Set<string>()
  const coverageGaps: string[] = []
  let scannedFileCount = 0
  let skippedFileCount = 0
  let traversalTruncated = false

  const values = {
    javaFiles: counter(), controllerNamedFiles: counter(), controllerAnnotatedFiles: counter(), controllerAnnotations: counter(),
    mapperJavaFiles: counter(), mapperXmlFiles: counter(), dataSourceFiles: counter(), dataSourceAnnotations: counter(),
    feignFiles: counter(), feignAnnotations: counter(), xxlJobFiles: counter(), xxlJobAnnotations: counter(),
    scheduledFiles: counter(), scheduledAnnotations: counter(), kafkaFiles: counter(), kafkaAnnotations: counter(),
    rabbitFiles: counter(), rabbitAnnotations: counter(), transactionalFiles: counter(), transactionalAnnotations: counter(),
    routeFiles: counter(), routeAnnotations: counter(), bootEntryFiles: counter(), bootEntryAnnotations: counter(),
  }

  async function visit(relativeDirectory: string): Promise<void> {
    if (scannedFileCount >= MAX_FILES) { traversalTruncated = true; return }
    const absoluteDirectory = path.resolve(root, relativeDirectory)
    if (!inside(root, absoluteDirectory)) return
    const stat = await lstat(absoluteDirectory).catch(() => undefined)
    if (stat === undefined || !stat.isDirectory() || stat.isSymbolicLink()) return
    const entries = await readdir(absoluteDirectory, { withFileTypes: true }).catch(error => {
      coverageGaps.push(`${portable(relativeDirectory || '.')}: ${errorCode(error)}`)
      return []
    })
    for (const entry of entries) {
      if (scannedFileCount >= MAX_FILES) { traversalTruncated = true; return }
      const relative = portable(path.join(relativeDirectory, entry.name))
      if (entry.isSymbolicLink()) { skippedFileCount += 1; continue }
      if (entry.isDirectory()) {
        if (!excludedDirectory(relative, entry.name)) await visit(relative)
        continue
      }
      if (!entry.isFile()) continue
      scannedFileCount += 1
      if (entry.name === 'pom.xml') moduleManifests.add(relative)
      if (springConfigurationPath(relative)) configurationFiles.add(relative)
      if (entry.name.endsWith('Mapper.xml') && mainResourcesPath(relative)) add(values.mapperXmlFiles, relative)
      if (!entry.name.endsWith('.java')) continue
      add(values.javaFiles, relative)
      if (!mainJavaPath(relative)) continue
      if (entry.name.endsWith('Controller.java')) add(values.controllerNamedFiles, relative)
      if (entry.name.endsWith('Mapper.java')) add(values.mapperJavaFiles, relative)
      const absoluteFile = path.resolve(root, relative)
      const fileStat = await lstat(absoluteFile).catch(() => undefined)
      if (fileStat === undefined || !fileStat.isFile() || fileStat.isSymbolicLink() || fileStat.size > MAX_SOURCE_BYTES) {
        skippedFileCount += 1
        coverageGaps.push(`${relative}: source content was not scanned`)
        continue
      }
      const content = await readFile(absoluteFile, 'utf8').catch(error => {
        coverageGaps.push(`${relative}: ${errorCode(error)}`)
        return undefined
      })
      if (content === undefined || content.includes('\u0000')) { skippedFileCount += 1; continue }
      const source = javaCodeOnly(content)
      const count = (key: keyof typeof values, pattern: RegExp) => {
        const total = occurrences(source, pattern)
        if (total > 0) add(values[key], relative, total)
        return total
      }
      const controllerCount = count('controllerAnnotations', /@(?:RestController|Controller)\b/gu)
      if (controllerCount > 0) add(values.controllerAnnotatedFiles, relative)
      const dataSourceCount = count('dataSourceAnnotations', /@DS(?:\s*\(|\b)/gu)
      if (dataSourceCount > 0) add(values.dataSourceFiles, relative)
      const feignCount = count('feignAnnotations', /@FeignClient(?:\s*\(|\b)/gu)
      if (feignCount > 0) add(values.feignFiles, relative)
      const xxlCount = count('xxlJobAnnotations', /@XxlJob(?:\s*\(|\b)/gu)
      if (xxlCount > 0) add(values.xxlJobFiles, relative)
      const scheduledCount = count('scheduledAnnotations', /@Scheduled(?:\s*\(|\b)/gu)
      if (scheduledCount > 0) add(values.scheduledFiles, relative)
      const kafkaCount = count('kafkaAnnotations', /@KafkaListener(?:\s*\(|\b)/gu)
      if (kafkaCount > 0) add(values.kafkaFiles, relative)
      const rabbitCount = count('rabbitAnnotations', /@RabbitListener(?:\s*\(|\b)/gu)
      if (rabbitCount > 0) add(values.rabbitFiles, relative)
      const transactionalCount = count('transactionalAnnotations', /@Transactional(?:\s*\(|\b)/gu)
      if (transactionalCount > 0) add(values.transactionalFiles, relative)
      const routeCount = count('routeAnnotations', /@(?:RequestMapping|GetMapping|PostMapping|PutMapping|DeleteMapping|PatchMapping)(?:\s*\(|\b)/gu)
      if (routeCount > 0) add(values.routeFiles, relative)
      const bootCount = count('bootEntryAnnotations', /@SpringBootApplication\b/gu)
      if (bootCount > 0) add(values.bootEntryFiles, relative)
    }
  }

  await visit('')
  const moduleDependencies = await collectMavenModuleDependencies(root, [...moduleManifests].sort(), coverageGaps)
  if (traversalTruncated) coverageGaps.push(`project traversal stopped at ${MAX_FILES} files`)
  const completeness = coverageGaps.length === 0 && !traversalTruncated ? 'COMPLETE' as const : 'PARTIAL' as const
  const metric = (metricId: string, label: string, value: Counter, unit: string, method: string, exclusions: string, scope = 'production source roots'): ProjectDeterministicMetric => ({
    metricId, label, value: value.value, unit, scope, method, exclusions,
    evidencePaths: [...value.paths], completeness,
  })
  const configCounter = { value: configurationFiles.size, paths: new Set([...configurationFiles].slice(0, MAX_EVIDENCE_PATHS)) }
  const moduleCounter = { value: [...moduleManifests].filter(item => item !== 'pom.xml').length, paths: new Set([...moduleManifests].slice(0, MAX_EVIDENCE_PATHS)) }
  const metrics = [
    metric('SPRING-MAVEN-CHILD-MODULES', 'Maven 子模块描述文件', moduleCounter, 'file', 'filesystem pom.xml inventory excluding root pom.xml', 'target and ignored directories', 'project root'),
    metric('SPRING-CONFIG-FILES', 'Spring 本地配置文件', configCounter, 'file', 'filesystem src/main/resources configuration inventory', 'generated resources and mapper XML', 'all main resource roots'),
    metric('SPRING-JAVA-SOURCE-FILES', 'Java 源文件', values.javaFiles, 'file', 'filesystem .java inventory', 'target, build and ignored directories', 'repository source tree including tests'),
    metric('SPRING-CONTROLLER-NAMED-FILES', '*Controller.java 文件', values.controllerNamedFiles, 'file', 'filesystem filename suffix', 'generated and ignored directories'),
    metric('SPRING-CONTROLLER-ANNOTATED-FILES', '@Controller/@RestController 命中文件', values.controllerAnnotatedFiles, 'file', 'lexical source annotation scan excluding comments and literals', 'composed annotations'),
    metric('SPRING-CONTROLLER-ANNOTATIONS', '@Controller/@RestController 注解', values.controllerAnnotations, 'occurrence', 'lexical source annotation scan excluding comments and literals', 'composed annotations'),
    metric('SPRING-MAPPER-JAVA-FILES', '*Mapper.java 文件', values.mapperJavaFiles, 'file', 'filesystem filename suffix', 'non-suffix mapper interfaces'),
    metric('SPRING-MAPPER-XML-FILES', '*Mapper.xml 文件', values.mapperXmlFiles, 'file', 'filesystem filename suffix', 'non-suffix XML mapping files'),
    metric('SPRING-DS-ANNOTATED-FILES', '@DS 命中文件', values.dataSourceFiles, 'file', 'lexical source annotation scan excluding comments and literals', 'meta-annotations'),
    metric('SPRING-DS-ANNOTATIONS', '@DS 注解', values.dataSourceAnnotations, 'occurrence', 'lexical source annotation scan excluding comments and literals', 'meta-annotations'),
    metric('SPRING-FEIGN-ANNOTATED-FILES', '@FeignClient 命中文件', values.feignFiles, 'file', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-FEIGN-ANNOTATIONS', '@FeignClient 注解', values.feignAnnotations, 'occurrence', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-XXLJOB-ANNOTATED-FILES', '@XxlJob 命中文件', values.xxlJobFiles, 'file', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-XXLJOB-ANNOTATIONS', '@XxlJob 注解', values.xxlJobAnnotations, 'occurrence', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-SCHEDULED-ANNOTATED-FILES', '@Scheduled 命中文件', values.scheduledFiles, 'file', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-SCHEDULED-ANNOTATIONS', '@Scheduled 注解', values.scheduledAnnotations, 'occurrence', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-KAFKA-LISTENER-FILES', '@KafkaListener 命中文件', values.kafkaFiles, 'file', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-KAFKA-LISTENER-ANNOTATIONS', '@KafkaListener 注解', values.kafkaAnnotations, 'occurrence', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-RABBIT-LISTENER-FILES', '@RabbitListener 命中文件', values.rabbitFiles, 'file', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-RABBIT-LISTENER-ANNOTATIONS', '@RabbitListener 注解', values.rabbitAnnotations, 'occurrence', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-TRANSACTIONAL-ANNOTATED-FILES', '@Transactional 命中文件', values.transactionalFiles, 'file', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-TRANSACTIONAL-ANNOTATIONS', '@Transactional 注解', values.transactionalAnnotations, 'occurrence', 'source annotation scan', 'dependency bytecode'),
    metric('SPRING-ROUTE-ANNOTATED-FILES', 'Spring MVC 路由注解命中文件', values.routeFiles, 'file', 'source annotation scan', 'composed custom annotations and WebFlux functional routes'),
    metric('SPRING-ROUTE-ANNOTATIONS', 'Spring MVC 路由注解', values.routeAnnotations, 'occurrence', 'source annotation scan', 'composed custom annotations and WebFlux functional routes'),
    metric('SPRING-BOOT-ENTRY-FILES', '@SpringBootApplication 命中文件', values.bootEntryFiles, 'file', 'source annotation scan', 'Servlet initializer without annotation'),
    metric('SPRING-BOOT-ENTRY-ANNOTATIONS', '@SpringBootApplication 注解', values.bootEntryAnnotations, 'occurrence', 'source annotation scan', 'Servlet initializer without annotation'),
  ]
  const configMetric = metrics.find(item => item.metricId === 'SPRING-CONFIG-FILES') as ProjectDeterministicMetric
  const dsMetric = metrics.find(item => item.metricId === 'SPRING-DS-ANNOTATIONS') as ProjectDeterministicMetric
  const bootMetric = metrics.find(item => item.metricId === 'SPRING-BOOT-ENTRY-FILES') as ProjectDeterministicMetric
  return {
    protocolVersion: 'archscope/project-deterministic-facts/v1', specialization: 'java-spring-backend', generatedAt,
    boundary: 'PROJECT_ROOT_ONLY', scanStatus: completeness, scannedFileCount, skippedFileCount,
    moduleManifests: [...moduleManifests].sort(), moduleDependencies, configurationFiles: [...configurationFiles].sort(), metrics,
    negativeClaimRules: [
      {
        ruleId: 'SPRING-NO-LOCAL-CONFIG', claim: '仓库不存在本地 Spring 配置',
        allowed: completeness === 'COMPLETE' && configMetric.value === 0,
        reason: configMetric.value > 0 ? `deterministic inventory found ${configMetric.value} local configuration files` : `scan completeness is ${completeness}`,
        forbiddenPatterns: [
          '(?:仓库内)?[^，。；;\\n]{0,12}(?:没有|不存在|无(?!法)|0\\s*个|未发现)[^，。；;\\n]{0,40}(?:ya?ml|properties|logback|bootstrap|application|本地配置文件)',
          '(?:ya?ml|properties|logback|bootstrap|application|本地配置文件)[^，。；;\\n]{0,30}(?:没有|不存在|无(?!法)|0\\s*个|未发现)',
          '(?:全部|完全)[^\\n]{0,30}(?:配置|运行期)[^\\n]{0,30}(?:Nacos|外部化)',
        ],
      },
      {
        ruleId: 'SPRING-NO-DS-ANNOTATION', claim: '源码不存在 @DS 注解',
        allowed: completeness === 'COMPLETE' && dsMetric.value === 0,
        reason: dsMetric.value > 0 ? `deterministic source scan found ${dsMetric.value} @DS annotations` : `scan completeness is ${completeness}`,
        forbiddenPatterns: ['@DS[^\\n]{0,20}(?:无命中|未发现|0\\s*(?:处|个))', '(?:无命中|未发现|0\\s*(?:处|个))[^\\n]{0,20}@DS'],
      },
      {
        ruleId: 'SPRING-UNIQUE-BOOT-ENTRY', claim: '工程只有一个 Spring Boot 启动入口',
        allowed: completeness === 'COMPLETE' && bootMetric.value === 1,
        reason: `deterministic source scan found ${bootMetric.value} @SpringBootApplication files with ${completeness} completeness`,
        forbiddenPatterns: ['(?:唯一|仅有|只有)[^\\n]{0,24}(?:启动类|启动入口|Spring Boot 入口)', '仅[^\\n]{0,24}可启动'],
      },
    ],
    coverageGaps,
  }
}

export function deterministicStatistics(facts: ProjectDeterministicFacts): ProjectStatistic[] {
  return facts.metrics.map(item => ({
    metricId: item.metricId, metric: item.label, count: item.value, unit: item.unit, scope: item.scope,
    queryMethod: item.method, exclusions: item.exclusions, evidencePaths: item.evidencePaths,
    confidence: 'DIRECT_SOURCE', authority: 'PARENT_DETERMINISTIC', completeness: item.completeness,
  }))
}

export interface DeterministicClaimViolation {
  ruleId: string
  claim: string
  reason: string
  index: number
  matchedText: string
}

export function deterministicClaimViolations(content: string, facts: ProjectDeterministicFacts | undefined): DeterministicClaimViolation[] {
  if (facts === undefined) return []
  const violations: DeterministicClaimViolation[] = []
  for (const rule of facts.negativeClaimRules) {
    if (rule.allowed) continue
    for (const pattern of rule.forbiddenPatterns) {
      const match = new RegExp(pattern, 'iu').exec(content)
      if (match === null) continue
      violations.push({ ruleId: rule.ruleId, claim: rule.claim, reason: rule.reason, index: match.index, matchedText: match[0] })
      break
    }
  }
  return violations
}

export function deterministicEvidencePaths(facts: ProjectDeterministicFacts): string[] {
  return [...new Set([
    ...facts.moduleManifests,
    ...(facts.moduleDependencies ?? []).flatMap(item => [item.sourceManifest, item.targetManifest]),
    ...facts.configurationFiles,
    ...facts.metrics.flatMap(item => item.evidencePaths),
  ])]
}
