import { createHash } from 'node:crypto'

import type { ProjectSynthesisContext, ProjectSynthesisDraft, ProjectSynthesisInputs, ProjectSynthesisReadManifest } from '../contracts/project-scan.js'
import type { LoadedProtocolPack } from '../protocol/catalog.js'
import { projectAgentSpec, projectProtocolResourceIds } from './specializations.js'

function sha256(value: string): string { return createHash('sha256').update(value).digest('hex') }

export function projectSynthesisInputDigest(input: ProjectSynthesisInputs): string {
  return sha256(JSON.stringify(input))
}

export function projectSynthesisOutputDigest(draft: ProjectSynthesisDraft): string {
  return sha256(JSON.stringify(draft))
}

export function buildProjectSynthesisContext(
  runId: string,
  pack: LoadedProtocolPack,
  input: ProjectSynthesisInputs,
  manifest: ProjectSynthesisReadManifest,
): ProjectSynthesisContext {
  const agentSpec = projectAgentSpec(input.projectEvidence.specialization)
  const protocolResourceIds = projectProtocolResourceIds(input.projectEvidence.specialization, 'WRITER')
  const prompt = `ARCHSCOPE_PROJECT_WRITER_TASK_V1
runId=${runId}
projectKey=${input.project.projectKey}
projectDir=${input.project.projectDir}
writerRole=${agentSpec.writerRole}
specialization=${input.projectEvidence.specialization}
framework=${input.projectEvidence.framework ?? 'not-applicable'}
template=${input.projectEvidence.template}
protocolTool=archscope_get_project_protocol_resource
protocolResourceIds=${protocolResourceIds.join(',')}

执行顺序：
1. 对每个 protocolResourceId 分别调用 protocolTool；未读完不得分页或写作。
2. 按 manifest 顺序无损读完全部综合数据集；若存在 DETERMINISTIC_FACTS，它是模块清单、Maven 模块依赖方向、配置、注解与数量事实的唯一权威来源。
3. 依次暂存 PROFILE、PROJECT_CONTEXT_DIAGRAM、STRUCTURE_DIAGRAM、ENTRY_DEPENDENCY_DIAGRAM；PROFILE 只能包含固定模板正文，严禁附加 Mermaid 源码或图标题，三张图必须各自独立暂存。
4. 调用 archscope_finalize_project_synthesis；首次校验失败时按 issues 修正一次。`
  return {
    runId, projectKey: input.project.projectKey, projectDir: input.project.projectDir,
    specialization: input.projectEvidence.specialization,
    ...(input.projectEvidence.framework === undefined ? {} : { framework: input.projectEvidence.framework }),
    template: input.projectEvidence.template, protocolDigest: pack.lock.packDigest, evidenceMode: 'PAGED',
    evidenceBytes: Buffer.byteLength(JSON.stringify(input), 'utf8'), pageMaxBytes: manifest.pageMaxBytes, manifest, protocolResourceIds, prompt,
  }
}
