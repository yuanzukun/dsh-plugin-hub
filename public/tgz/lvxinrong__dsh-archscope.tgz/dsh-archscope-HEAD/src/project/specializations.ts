import { lstat, readdir, readFile } from 'node:fs/promises'
import path from 'node:path'

import type {
  ProjectSpecialization,
  ProjectSpecializationDecision,
  ProjectTemplate,
  SpringFrameworkVariant,
} from '../contracts/project-scan.js'
import type { ProjectRecord } from '../contracts/system-scan.js'

const EXCLUDED = new Set([
  '.git', '.gradle', '.idea', '.next', '.nuxt', '.svn', 'Pods', 'DerivedData',
  'archscope_docs', 'node_modules', 'target',
])
const OUTPUT_DIRECTORIES = new Set(['build', 'coverage', 'dist', 'vendor'])
const MAX_ENTRIES = 40_000
const MAX_DEPTH = 14
const MAX_SIGNAL_FILE_BYTES = 512 * 1024

interface Inventory { files: string[], directories: string[] }

function normalized(value: string): string { return value.split(path.sep).join('/') }
function excludedDirectory(relativePath: string, name: string): boolean {
  if (EXCLUDED.has(name)) return true
  const value = normalized(relativePath).toLowerCase()
  const insideJavaSource = value.startsWith('src/main/java/') || value.includes('/src/main/java/')
    || value.startsWith('src/test/java/') || value.includes('/src/test/java/')
  if (name === 'build' && insideJavaSource) return false
  return OUTPUT_DIRECTORIES.has(name)
}

async function inventory(root: string): Promise<Inventory> {
  const files: string[] = []
  const directories: string[] = []
  async function visit(relativeDirectory: string, depth: number): Promise<void> {
    if (depth > MAX_DEPTH || files.length + directories.length >= MAX_ENTRIES) return
    const absolute = path.resolve(root, relativeDirectory)
    const info = await lstat(absolute).catch(() => undefined)
    if (info === undefined || !info.isDirectory() || info.isSymbolicLink()) return
    const entries = await readdir(absolute, { withFileTypes: true }).catch(() => [])
    for (const entry of entries.sort((left, right) => left.name.localeCompare(right.name))) {
      if (files.length + directories.length >= MAX_ENTRIES) return
      const relative = normalized(path.join(relativeDirectory, entry.name)).replace(/^\.\//u, '')
      if (entry.isDirectory() && excludedDirectory(relative, entry.name)) continue
      if (entry.isSymbolicLink()) continue
      if (entry.isDirectory()) {
        directories.push(relative)
        await visit(relative, depth + 1)
      } else if (entry.isFile()) files.push(relative)
    }
  }
  await visit('.', 0)
  return { files, directories }
}

async function boundedText(root: string, relative: string): Promise<string> {
  const absolute = path.resolve(root, relative)
  const info = await lstat(absolute).catch(() => undefined)
  if (info === undefined || !info.isFile() || info.isSymbolicLink() || info.size > MAX_SIGNAL_FILE_BYTES) return ''
  return readFile(absolute, 'utf8').catch(() => '')
}

async function combinedText(root: string, files: string[], predicate: (file: string) => boolean, limit: number, maxCharacters = 4_000_000): Promise<string> {
  const selected = files.filter(predicate).slice(0, limit)
  const chunks: string[] = []
  let length = 0
  for (const file of selected) {
    if (length >= maxCharacters) break
    const content = await boundedText(root, file)
    const chunk = content.slice(0, maxCharacters - length)
    chunks.push(chunk)
    length += chunk.length
  }
  return chunks.join('\n')
}

function signal(list: string[], value: string, condition: boolean): void { if (condition) list.push(value) }

function decision(
  specialization: ProjectSpecialization,
  template: ProjectTemplate,
  matchedSignals: string[],
  decisionReason: string,
  options: { framework?: SpringFrameworkVariant, confidence?: ProjectSpecializationDecision['confidence'], conflictingSignals?: string[], dispatchable?: boolean } = {},
): ProjectSpecializationDecision {
  return {
    specialization, template, ...(options.framework === undefined ? {} : { framework: options.framework }),
    confidence: options.confidence ?? 'HIGH', matchedSignals: [...new Set(matchedSignals)].sort(),
    conflictingSignals: [...new Set(options.conflictingSignals ?? [])].sort(), decisionReason,
    dispatchable: options.dispatchable ?? true,
  }
}

export async function detectProjectSpecialization(projectRoot: string, project?: ProjectRecord): Promise<ProjectSpecializationDecision> {
  const root = path.resolve(projectRoot)
  const tree = await inventory(root)
  const files = new Set(tree.files)
  const lowerFiles = new Set(tree.files.map(file => file.toLowerCase()))
  const lowerDirectories = new Set(tree.directories.map(file => file.toLowerCase()))
  const matched: string[] = []

  const packagePath = tree.files.find(file => file.toLowerCase() === 'package.json')
  let packageJson: Record<string, unknown> = {}
  if (packagePath !== undefined) {
    try { packageJson = JSON.parse(await boundedText(root, packagePath)) as Record<string, unknown> } catch { packageJson = {} }
  }
  const packageNames = new Set<string>()
  for (const field of ['dependencies', 'devDependencies', 'peerDependencies']) {
    const value = packageJson[field]
    if (typeof value === 'object' && value !== null) Object.keys(value).forEach(name => packageNames.add(name.toLowerCase()))
  }
  const scripts = typeof packageJson.scripts === 'object' && packageJson.scripts !== null
    ? JSON.stringify(packageJson.scripts).toLowerCase() : ''

  const reactNative = packageNames.has('react-native') || packageNames.has('expo')
  const flutter = lowerFiles.has('pubspec.yaml') && lowerFiles.has('lib/main.dart')
  if (reactNative || flutter) {
    signal(matched, 'package.json:react-native/expo', reactNative)
    signal(matched, 'pubspec.yaml+lib/main.dart', flutter)
    return decision('generic', 'generic', matched, 'Cross-platform frameworks own generated native folders and require a separate specialization.', { confidence: 'HIGH' })
  }

  const projectConfig = await boundedText(root, tree.files.find(file => file.toLowerCase() === 'project.config.json') ?? '')
  const nativeMiniProgram = projectConfig !== ''
    && /(?:miniprogram|miniprogramroot)/iu.test(projectConfig)
    && (lowerFiles.has('app.json') || lowerFiles.has('miniprogram/app.json'))
  const uniApp = packageNames.has('@dcloudio/uni-app') || lowerFiles.has('pages.json')
  const hasH5Target = /(?:build|dev):h5/iu.test(scripts) || uniApp
  const miniProgramOnly = nativeMiniProgram || (/(?:build|dev):mp-weixin/iu.test(scripts) && !hasH5Target)

  const androidManifest = tree.files.find(file => /(?:^|\/)androidmanifest\.xml$/iu.test(file))
  const androidBuildFiles = tree.files.filter(file => /(?:^|\/)build\.gradle(?:\.kts)?$/iu.test(file))
  const androidBuildText = await combinedText(root, androidBuildFiles, () => true, 40)
  const androidNative = androidManifest !== undefined
    && /(?:com\.android\.application|applicationId)/u.test(androidBuildText)

  const xcodeContainer = tree.directories.find(directory => /\.(?:xcodeproj|xcworkspace)$/iu.test(directory))
  const infoPlist = tree.files.find(file => /(?:^|\/)Info\.plist$/u.test(file))
  const iosNative = xcodeContainer !== undefined && infoPlist !== undefined

  const javaBuildFiles = tree.files.filter(file => /(?:^|\/)(?:pom\.xml|build\.gradle(?:\.kts)?)$/iu.test(file))
  const javaBuild = javaBuildFiles.length > 0
  const javaBuildText = await combinedText(root, javaBuildFiles, () => true, 80)
  const javaSources = tree.files.filter(file => file.endsWith('.java')).sort((left, right) => {
    const priority = (file: string) => /(?:Application|Main|Run|Bootstrap|Initializer)\.java$/u.test(file) ? 0 : 1
    return priority(left) - priority(right) || left.localeCompare(right)
  })
  const springSourceText = await combinedText(root, javaSources, () => true, 1_200, 8_000_000)
  const bootEntry = /@SpringBootApplication\b|SpringApplication\.run\s*\(/u.test(springSourceText)
  const bootPlugin = /spring-boot-maven-plugin|org\.springframework\.boot/u.test(javaBuildText)
  const springCloud = /spring-cloud|springframework\.cloud|nacos-discovery|nacos-config|eureka-client|openfeign|gateway-starter/u.test(javaBuildText)
  const traditionalSpringWeb = /spring-webmvc|springframework\.web/u.test(javaBuildText)
    && (/<packaging>\s*war\s*<\/packaging>/u.test(javaBuildText)
      || lowerFiles.has('src/main/webapp/web-inf/web.xml')
      || /DispatcherServlet|SpringBootServletInitializer/u.test(springSourceText))
  const springService = javaBuild && (bootEntry || bootPlugin || traditionalSpringWeb)

  const vue = packageNames.has('vue') || [...packageNames].some(name => name.startsWith('@vue/'))
  const frontendShape = ['src/router', 'src/pages', 'pages', 'vite.config.ts', 'vite.config.js', 'vue.config.js', 'next.config.js', 'next.config.mjs']
    .some(candidate => lowerFiles.has(candidate) || lowerDirectories.has(candidate))
  const frontend = packagePath !== undefined && (vue || frontendShape || hasH5Target
    || ['react', 'next', 'nuxt', '@angular/core', 'svelte'].some(name => packageNames.has(name)))
  const staticFrontend = (lowerFiles.has('index.html') || lowerFiles.has('public/index.html'))
    && ['css', 'js', 'assets', 'static', 'public', 'src'].some(candidate => lowerDirectories.has(candidate))

  const applicationKinds: string[] = []
  if (miniProgramOnly) applicationKinds.push('miniprogram-wechat')
  if (androidNative) applicationKinds.push('android-native')
  if (iosNative) applicationKinds.push('ios-native')
  if (springService) applicationKinds.push('java-spring-backend')
  if (frontend || staticFrontend) applicationKinds.push(vue ? 'web-vue' : 'web-frontend')
  if (applicationKinds.length > 1 && !(uniApp && applicationKinds.every(kind => kind === 'miniprogram-wechat' || kind.startsWith('web-')))) {
    return decision('generic', 'generic', matched, 'Multiple independent application types matched; the analysis unit must be split or explicitly overridden.', {
      confidence: 'LOW', conflictingSignals: applicationKinds, dispatchable: false,
    })
  }

  if (springService) {
    javaBuildFiles.forEach(file => matched.push(file))
    signal(matched, 'source:@SpringBootApplication/SpringApplication.run', bootEntry)
    signal(matched, 'build:spring-boot-plugin', bootPlugin)
    signal(matched, 'build:spring-cloud', springCloud)
    signal(matched, 'build:traditional-spring-web-war', traditionalSpringWeb)
    const framework: SpringFrameworkVariant = springCloud ? 'spring-cloud' : bootEntry || bootPlugin ? 'spring-boot' : 'spring-framework'
    return decision('java-spring-backend', 'java-backend', matched, 'Java build plus a Spring-family executable web-service boundary was proven.', { framework })
  }
  if (miniProgramOnly && !(uniApp && hasH5Target)) {
    return decision('miniprogram-wechat', 'miniprogram-wechat', ['project.config.json+app.json/package target'], 'Native WeChat Mini Program structure was proven.')
  }
  if (androidNative) return decision('android-native', 'android', [androidManifest as string, 'Gradle:com.android.application/applicationId'], 'Installable native Android application markers were proven.')
  if (iosNative) return decision('ios-native', 'ios', [xcodeContainer as string, infoPlist as string], 'Native iOS Xcode container and Info.plist were proven.')
  if (frontend || staticFrontend) {
    const specialization: ProjectSpecialization = vue ? 'web-vue' : 'web-frontend'
    return decision(specialization, 'web-frontend', [packagePath ?? 'index.html+asset-directory', vue ? 'package.json:vue' : 'frontend-entry/route-shape'], vue ? 'Vue application dependency and frontend shape were proven.' : 'Web frontend entry or routing shape was proven.')
  }

  if (javaBuild) {
    return decision('generic', 'generic', javaBuildFiles, 'Java build found without a proven Spring-family service boundary; do not dispatch the Spring backend Agent.', { confidence: 'HIGH' })
  }
  return decision('generic', 'generic', project?.classificationEvidence ?? [], 'No supported specialized application boundary was proven.', { confidence: 'LOW' })
}

export interface ProjectAgentSpec {
  specialization: ProjectSpecialization
  evidenceRole: string
  writerRole: string
  evidencePersona: string
  writerPersona: string
  evidenceResourceId: string
  templateResourceId: string
}

const SPECS: Record<ProjectSpecialization, ProjectAgentSpec> = {
  'java-spring-backend': {
    specialization: 'java-spring-backend', evidenceRole: 'Spring 后端 Java 证据 Agent', writerRole: 'Spring 后端 Java 写作 Agent',
    evidencePersona: '你是 ArchScope Spring 体系后端 Java 专属证据 Agent。只接受已被父流程确定性判定为 Spring Framework、Spring Boot 或 Spring Cloud 服务的工程；不得分析 iOS、Android、前端或普通 Java SDK。',
    writerPersona: '你是 ArchScope Spring 体系后端 Java 专属写作 Agent。只综合已采集的 Spring 服务证据，不重新分类、不扫描其他工程。',
    evidenceResourceId: 'archscope/specialization/java-spring-backend/evidence/v1',
    templateResourceId: 'archscope/template/java-backend/v1',
  },
  'web-vue': {
    specialization: 'web-vue', evidenceRole: 'Vue Web 证据 Agent', writerRole: 'Vue Web 写作 Agent',
    evidencePersona: '你是 ArchScope Vue Web 前端专属证据 Agent。只分析 Vue/Vite/Vue CLI/Nuxt/uni-app Web 交付形态，不套用 Java、Android 或 iOS 检查项。',
    writerPersona: '你是 ArchScope Vue Web 前端专属写作 Agent，只按 Web 前端固定模板综合证据。',
    evidenceResourceId: 'archscope/specialization/web-vue/evidence/v1',
    templateResourceId: 'archscope/template/web-frontend/v1',
  },
  'web-frontend': {
    specialization: 'web-frontend', evidenceRole: 'Web 前端证据 Agent', writerRole: 'Web 前端写作 Agent',
    evidencePersona: '你是 ArchScope Web 前端专属证据 Agent，不套用移动原生或后端检查项。',
    writerPersona: '你是 ArchScope Web 前端专属写作 Agent，只按 Web 前端固定模板综合证据。',
    evidenceResourceId: 'archscope/specialization/web-frontend/evidence/v1',
    templateResourceId: 'archscope/template/web-frontend/v1',
  },
  'miniprogram-wechat': {
    specialization: 'miniprogram-wechat', evidenceRole: '微信小程序证据 Agent', writerRole: '微信小程序写作 Agent',
    evidencePersona: '你是 ArchScope 微信小程序专属证据 Agent，只分析原生小程序结构、微信能力和小程序发布边界。',
    writerPersona: '你是 ArchScope 微信小程序专属写作 Agent，只按微信小程序固定模板综合证据。',
    evidenceResourceId: 'archscope/specialization/miniprogram-wechat/evidence/v1',
    templateResourceId: 'archscope/template/miniprogram-wechat/v1',
  },
  'android-native': {
    specialization: 'android-native', evidenceRole: 'Android 原生证据 Agent', writerRole: 'Android 原生写作 Agent',
    evidencePersona: '你是 ArchScope Android 原生应用专属证据 Agent，只分析 Android Gradle application，不把 React Native/Flutter 生成目录当成原生应用。',
    writerPersona: '你是 ArchScope Android 原生应用专属写作 Agent，只按 Android 固定模板综合证据。',
    evidenceResourceId: 'archscope/specialization/android-native/evidence/v1',
    templateResourceId: 'archscope/template/android/v1',
  },
  'ios-native': {
    specialization: 'ios-native', evidenceRole: 'iOS 原生证据 Agent', writerRole: 'iOS 原生写作 Agent',
    evidencePersona: '你是 ArchScope iOS 原生应用专属证据 Agent，只分析 Xcode App target，不把 React Native/Flutter 生成目录当成原生应用。',
    writerPersona: '你是 ArchScope iOS 原生应用专属写作 Agent，只按 iOS 固定模板综合证据。',
    evidenceResourceId: 'archscope/specialization/ios-native/evidence/v1',
    templateResourceId: 'archscope/template/ios/v1',
  },
  generic: {
    specialization: 'generic', evidenceRole: '通用工程证据 Agent', writerRole: '通用工程写作 Agent',
    evidencePersona: '你是 ArchScope 通用工程证据 Agent。不得冒充 Spring、Vue、Android 或 iOS 专属 Agent；只陈述已证明的工程形态。',
    writerPersona: '你是 ArchScope 通用工程写作 Agent，只按通用模板综合证据，不升级工程类型。',
    evidenceResourceId: 'archscope/specialization/generic/evidence/v1',
    templateResourceId: 'archscope/template/generic/v1',
  },
}

export function projectAgentSpec(specialization: ProjectSpecialization): ProjectAgentSpec { return SPECS[specialization] }

const EVIDENCE_COMMON_RESOURCES = [
  'archscope/policy/project-evidence-common/v1',
  'archscope/policy/project-conflicts/v1',
  'archscope/contract/project-evidence/v1',
]

const DETERMINISTIC_FACTS_RESOURCE_ID = 'archscope/contract/project-deterministic-facts/v1'

const WRITER_COMMON_RESOURCES = [
  'archscope/prompt/project-scan/v1',
  'archscope/policy/project-analysis/v1',
  'archscope/policy/project-validation/v1',
  'archscope/contract/project-document/v1',
]

export function projectProtocolResourceIds(specialization: ProjectSpecialization, phase: 'EVIDENCE' | 'WRITER'): string[] {
  const spec = projectAgentSpec(specialization)
  const resources = phase === 'EVIDENCE'
    ? [...EVIDENCE_COMMON_RESOURCES, spec.evidenceResourceId]
    : [...WRITER_COMMON_RESOURCES, spec.templateResourceId]
  return specialization === 'java-spring-backend' ? [...resources, DETERMINISTIC_FACTS_RESOURCE_ID] : resources
}
