import { createHash, randomUUID } from 'node:crypto'
import type { Dirent } from 'node:fs'
import { mkdir, readFile, readdir } from 'node:fs/promises'
import path from 'node:path'
import type { ToolExecutionInput } from '@deepseek-ai/dsh-tools'

import type { Config } from '../config.js'
import { PROJECT_SCAN_PROTOCOL, PROJECT_SYNTHESIS_ARTIFACTS, type ProjectEvidenceDataset, type ProjectEvidenceInputs, type ProjectEvidencePage, type ProjectEvidenceReadLedger, type ProjectEvidenceTaskContext, type ProjectHistoryIndex, type ProjectHistoryRevision, type ProjectProtocolResourceResult, type ProjectScanProgress, type ProjectScanResult, type ProjectScanRunState, type ProjectScanStatus, type ProjectSynthesisArtifact, type ProjectSynthesisCommitResult, type ProjectSynthesisContext, type ProjectSynthesisDataset, type ProjectSynthesisDraft, type ProjectSynthesisFinalizeResult, type ProjectSynthesisInputs, type ProjectSynthesisPage, type ProjectSynthesisReadLedger, type ProjectSynthesisStageResult, type ProjectSynthesisStagingState, type ProjectSynthesisWriter } from '../contracts/project-scan.js'
import type { IndexManifest, ProjectRegistry, SystemEvidenceBundle, SystemRelationCatalog, SystemScanRunState } from '../contracts/system-scan.js'
import { loadProjectProtocolPack, protocolResource } from '../protocol/catalog.js'
import { atomicWriteJson, atomicWriteText } from '../system/artifacts.js'
import type { SystemAnalyzer } from '../system/analyzer.js'
import { collectSafeProjectMetadata } from '../system/project-metadata.js'
import { prepareProjectArtifacts, projectProfileBoundaryIssues, writeProjectArtifacts } from './artifacts.js'
import { collectSpringProjectFacts, deterministicEvidencePaths, deterministicStatistics } from './deterministic-facts.js'
import { buildProjectEvidencePage, buildProjectEvidenceReadManifest, createProjectEvidenceReadLedger, projectEvidenceInputDigest } from './evidence-pages.js'
import { detectProjectSpecialization } from './specializations.js'
import { buildProjectSynthesisContext, projectSynthesisInputDigest, projectSynthesisOutputDigest } from './synthesis.js'
import { buildProjectSynthesisPage, buildProjectSynthesisReadManifest, createProjectSynthesisReadLedger } from './synthesis-pages.js'
import { assertProjectProtocolReads, PROJECT_EVIDENCE_CONTEXT_RESOURCE_ID, recordProjectProtocolRead } from './protocol-resources.js'
import { projectProtocolResourceIds } from './specializations.js'

export interface ScanProjectOptions { refresh?: boolean, signal?: AbortSignal, workspaceRoot?: string, agent?: ToolExecutionInput['agent'], sourceSystemRunId?: string, sourceSystemRevision?: string, onProgress?: (progress: ProjectScanProgress) => void }
export interface ProjectContextOptions { workspaceRoot?: string }
export interface ProjectProtocolResourceOptions extends ProjectContextOptions { resourceId: string }
export interface ProjectPageOptions extends ProjectContextOptions { dataset: ProjectSynthesisDataset, cursor: string }
export interface ProjectEvidencePageOptions extends ProjectContextOptions { dataset: ProjectEvidenceDataset, cursor: string }
export interface CommitProjectOptions extends ProjectContextOptions { runId: string, draft: ProjectSynthesisDraft, writer: ProjectSynthesisWriter }
export interface StageProjectArtifactOptions extends ProjectContextOptions { runId?: string, artifact: ProjectSynthesisArtifact, content: string }
export interface FinalizeStagedProjectOptions extends ProjectContextOptions { runId?: string, writer: ProjectSynthesisWriter }
interface Workspace { root: string, outputRoot: string, outputDirectory: string }

const MAX_PROJECT_SYNTHESIS_ATTEMPTS = 3

function errorMessage(value: unknown): string { return value instanceof Error ? value.message : String(value) }
function safeKey(value: string): string {
  if (!/^[a-zA-Z0-9][a-zA-Z0-9._-]*$/u.test(value)) throw new Error('Invalid ArchScope project key: ' + value)
  return value
}
function projectRunId(projectKey: string, now: Date): string {
  const timestamp = now.toISOString().replace(/[-:.TZ]/gu, '').slice(0, 14)
  return 'project-' + projectKey.toLowerCase().replace(/[^a-z0-9]+/gu, '-') + '-' + timestamp + '-' + randomUUID().slice(0, 8)
}
function nextRevision(history: ProjectHistoryIndex): string {
  const highest = history.revisions.reduce((maximum, item) => {
    const match = /^P(\d+)$/u.exec(item.revision)
    return match === null ? maximum : Math.max(maximum, Number(match[1]))
  }, 0)
  return 'P' + String(highest + 1).padStart(4, '0')
}

const PROJECT_SYNTHESIS_ARTIFACT_FILES: Record<ProjectSynthesisArtifact, string> = {
  PROFILE: 'profile.md',
  PROJECT_CONTEXT_DIAGRAM: 'project-context.mmd',
  STRUCTURE_DIAGRAM: 'structure.mmd',
  ENTRY_DEPENDENCY_DIAGRAM: 'entry-dependency.mmd',
}

function sha256(value: string): string { return createHash('sha256').update(value).digest('hex') }

export class ProjectScanCoordinator {
  private readonly active = new Map<string, Promise<ProjectScanResult>>()
  constructor(private readonly config: Config, private readonly analyzer: SystemAnalyzer) {}

  async scan(projectKey: string, options: ScanProjectOptions = {}): Promise<ProjectScanResult> {
    const workspace = this.workspace(options.workspaceRoot)
    const key = safeKey(projectKey)
    const activeKey = workspace.root + '\0' + key
    const existing = this.active.get(activeKey)
    if (existing !== undefined) return existing
    const task = this.performScan(key, options, workspace)
    this.active.set(activeKey, task)
    try { return await task } finally { if (this.active.get(activeKey) === task) this.active.delete(activeKey) }
  }

  async inspect(runId: string, options: ProjectContextOptions = {}): Promise<ProjectScanResult> {
    const workspace = this.workspace(options.workspaceRoot)
    return this.result(await this.readState(workspace.outputRoot, runId), false)
  }

  async evidenceTaskContext(runId: string, options: ProjectContextOptions = {}): Promise<ProjectEvidenceTaskContext> {
    const workspace = this.workspace(options.workspaceRoot)
    const state = await this.readState(workspace.outputRoot, runId)
    if (state.status !== 'COLLECTING_PROJECT_EVIDENCE') throw new Error('Project evidence context is available only while evidence collection is active.')
    const context = JSON.parse(await readFile(path.join(workspace.outputRoot, 'runs', runId, 'project', 'evidence-task-context.json'), 'utf8')) as ProjectEvidenceTaskContext
    if (context.protocolVersion !== PROJECT_SCAN_PROTOCOL || context.runId !== runId || context.specialization !== state.specialization) throw new Error('Project evidence task context does not match the active run.')
    const readAt = new Date().toISOString()
    await recordProjectProtocolRead(workspace.outputRoot, runId, {
      phase: 'EVIDENCE', resourceId: PROJECT_EVIDENCE_CONTEXT_RESOURCE_ID,
      version: PROJECT_SCAN_PROTOCOL, digest: sha256(JSON.stringify(context)), readAt,
    })
    return context
  }

  async evidencePage(runId: string, options: ProjectEvidencePageOptions): Promise<ProjectEvidencePage> {
    const workspace = this.workspace(options.workspaceRoot)
    const state = await this.readState(workspace.outputRoot, runId)
    if (state.status !== 'COLLECTING_PROJECT_EVIDENCE') throw new Error('Project evidence pages are available only while evidence collection is active.')
    const pack = await loadProjectProtocolPack()
    const input = await this.readEvidenceInput(workspace.outputRoot, runId)
    const digest = projectEvidenceInputDigest(input)
    const ledger = await this.readEvidenceLedger(workspace.outputRoot, runId)
    if (ledger === undefined) throw new Error('Load archscope_get_project_evidence_context before requesting project evidence pages.')
    const manifest = buildProjectEvidenceReadManifest(digest, input)
    this.assertEvidenceLedger(ledger, runId, pack.lock.packDigest, manifest)
    const dataset = ledger.datasets.find(item => item.dataset === options.dataset)
    if (dataset === undefined) throw new Error('Unknown ArchScope project evidence dataset: ' + options.dataset)
    const allComplete = ledger.datasets.every(item => item.complete)
    if (!allComplete) {
      const expectedDataset = ledger.datasets.find(item => !item.complete)
      if (expectedDataset?.dataset !== options.dataset) throw new Error('ArchScope project evidence datasets must be read in manifest order; expected ' + expectedDataset?.dataset + '.')
      if (dataset.nextCursor !== options.cursor) throw new Error('ArchScope project evidence cursor is out of sequence; expected ' + dataset.nextCursor + '.')
    }
    const page = buildProjectEvidencePage(runId, pack.lock.packDigest, options.dataset, options.cursor, input)
    if (page.globalDigest !== dataset.globalDigest) throw new Error('ArchScope project evidence dataset changed while paging.')
    if (allComplete) return page
    dataset.coveredRecordKeys = [...new Set([...dataset.coveredRecordKeys, ...page.items.filter(item => item.completeRecord).map(item => item.recordKey)])]
    dataset.pageDigests.push(page.pageDigest)
    dataset.nextCursor = page.nextCursor
    dataset.complete = page.complete
    ledger.updatedAt = new Date().toISOString()
    await this.writeEvidenceLedger(workspace.outputRoot, ledger)
    return page
  }

  async projectProtocolResource(runId: string, options: ProjectProtocolResourceOptions): Promise<ProjectProtocolResourceResult> {
    const workspace = this.workspace(options.workspaceRoot)
    const state = await this.readState(workspace.outputRoot, runId)
    const phase = state.status === 'COLLECTING_PROJECT_EVIDENCE'
      ? 'EVIDENCE' as const
      : state.status === 'AWAITING_PROJECT_SYNTHESIS' || state.status === 'SYNTHESIZING'
        ? 'WRITER' as const
        : undefined
    if (phase === undefined) throw new Error('Project protocol resources are unavailable in state ' + state.status + '.')
    const allowed = projectProtocolResourceIds(state.specialization, phase)
    if (!allowed.includes(options.resourceId)) throw new Error('Project protocol resource is not allowed for ' + state.specialization + ' during ' + phase + ': ' + options.resourceId + '.')
    const pack = await loadProjectProtocolPack()
    if (state.protocol.digest !== pack.lock.packDigest) throw new Error('ArchScope project protocol changed after this run started.')
    const resource = protocolResource(pack, options.resourceId)
    const readAt = new Date().toISOString()
    await recordProjectProtocolRead(workspace.outputRoot, runId, { phase, resourceId: resource.id, version: resource.version, digest: resource.digest, readAt })
    return { runId, phase, resourceId: resource.id, version: resource.version, kind: resource.kind, digest: resource.digest, content: resource.content }
  }

  async context(runId: string, options: ProjectContextOptions = {}): Promise<ProjectSynthesisContext> {
    const workspace = this.workspace(options.workspaceRoot)
    const state = await this.readState(workspace.outputRoot, runId)
    this.assertSynthesizing(state)
    const pack = await loadProjectProtocolPack()
    if (state.protocol.digest !== pack.lock.packDigest) throw new Error('ArchScope project protocol changed after evidence collection; start a new project scan.')
    const input = await this.readInput(workspace.outputRoot, runId)
    const digest = projectSynthesisInputDigest(input)
    if (state.synthesisInputDigest !== digest) throw new Error('ArchScope project synthesis inputs changed after evidence collection.')
    let ledger = await this.readLedger(workspace.outputRoot, runId)
    const manifest = buildProjectSynthesisReadManifest(digest, input, ledger)
    if (ledger === undefined) {
      ledger = createProjectSynthesisReadLedger(runId, pack.lock.packDigest, manifest)
      await this.writeLedger(workspace.outputRoot, ledger)
    } else this.assertLedger(ledger, runId, pack.lock.packDigest, manifest)
    if (state.status === 'AWAITING_PROJECT_SYNTHESIS') await this.transition(workspace.outputRoot, state, 'SYNTHESIZING')
    return buildProjectSynthesisContext(runId, pack, input, buildProjectSynthesisReadManifest(digest, input, ledger))
  }

  async page(runId: string, options: ProjectPageOptions): Promise<ProjectSynthesisPage> {
    const workspace = this.workspace(options.workspaceRoot)
    const state = await this.readState(workspace.outputRoot, runId)
    this.assertSynthesizing(state)
    const pack = await loadProjectProtocolPack()
    const input = await this.readInput(workspace.outputRoot, runId)
    const digest = projectSynthesisInputDigest(input)
    if (state.protocol.digest !== pack.lock.packDigest || state.synthesisInputDigest !== digest) throw new Error('ArchScope project synthesis inputs or protocol changed.')
    const ledger = await this.readLedger(workspace.outputRoot, runId)
    if (ledger === undefined) throw new Error('Load archscope_get_project_synthesis_context before requesting project pages.')
    const manifest = buildProjectSynthesisReadManifest(digest, input)
    this.assertLedger(ledger, runId, pack.lock.packDigest, manifest)
    const dataset = ledger.datasets.find(item => item.dataset === options.dataset)
    if (dataset === undefined) throw new Error('Unknown ArchScope project synthesis dataset: ' + options.dataset)
    if (dataset.complete || dataset.nextCursor === null) throw new Error('ArchScope project synthesis dataset is already completely read: ' + options.dataset)
    if (dataset.nextCursor !== options.cursor) throw new Error('ArchScope project synthesis cursor is out of sequence; expected ' + dataset.nextCursor + '.')
    const page = buildProjectSynthesisPage(runId, pack.lock.packDigest, options.dataset, options.cursor, input)
    if (page.globalDigest !== dataset.globalDigest) throw new Error('ArchScope project synthesis dataset changed while paging.')
    dataset.coveredRecordKeys = [...new Set([...dataset.coveredRecordKeys, ...page.items.filter(item => item.completeRecord).map(item => item.recordKey)])]
    dataset.pageDigests.push(page.pageDigest)
    dataset.nextCursor = page.nextCursor
    dataset.complete = page.complete
    ledger.updatedAt = new Date().toISOString()
    await this.writeLedger(workspace.outputRoot, ledger)
    return page
  }

  async stageArtifact(options: StageProjectArtifactOptions): Promise<ProjectSynthesisStageResult> {
    const workspace = this.workspace(options.workspaceRoot)
    const state = await this.resolveSynthesisState(workspace.outputRoot, options.runId)
    this.assertSynthesizing(state)
    if (!PROJECT_SYNTHESIS_ARTIFACTS.includes(options.artifact)) throw new Error('Unknown ArchScope project synthesis artifact: ' + options.artifact)
    if (options.content.trim().length === 0) throw new Error('ArchScope project synthesis artifact must not be blank: ' + options.artifact)
    const maxCharacters = options.artifact === 'PROFILE' ? 180000 : 50000
    if (options.content.length > maxCharacters) throw new Error('ArchScope project synthesis artifact exceeds the protocol character limit: ' + options.artifact)
    if (options.artifact === 'PROFILE') {
      const boundaryIssues = projectProfileBoundaryIssues(options.content)
      if (boundaryIssues.length > 0) throw new Error(boundaryIssues.map(item => item.code + ': ' + item.message).join('\n'))
    }

    const pack = await loadProjectProtocolPack()
    const input = await this.readInput(workspace.outputRoot, state.runId)
    const digest = projectSynthesisInputDigest(input)
    if (state.protocol.digest !== pack.lock.packDigest || state.synthesisInputDigest !== digest) throw new Error('ArchScope project synthesis inputs or protocol changed.')

    const stagedAt = new Date().toISOString()
    const relativePath = path.join('runs', state.runId, 'project', 'synthesis', 'staged', PROJECT_SYNTHESIS_ARTIFACT_FILES[options.artifact]).split(path.sep).join('/')
    await atomicWriteText(path.join(workspace.outputRoot, relativePath), options.content)
    const staging = await this.readStaging(workspace.outputRoot, state.runId)
    const artifact = {
      artifact: options.artifact,
      bytes: Buffer.byteLength(options.content, 'utf8'),
      digest: sha256(options.content),
      stagedAt,
      path: relativePath,
    }
    const artifacts = [...staging.artifacts.filter(item => item.artifact !== options.artifact), artifact]
      .sort((left, right) => PROJECT_SYNTHESIS_ARTIFACTS.indexOf(left.artifact) - PROJECT_SYNTHESIS_ARTIFACTS.indexOf(right.artifact))
    await this.writeStaging(workspace.outputRoot, { protocolVersion: PROJECT_SCAN_PROTOCOL, runId: state.runId, updatedAt: stagedAt, artifacts })
    const missingArtifacts = PROJECT_SYNTHESIS_ARTIFACTS.filter(candidate => !artifacts.some(item => item.artifact === candidate))
    return { runId: state.runId, projectKey: state.projectKey, artifact: options.artifact, stagedCount: artifacts.length, totalArtifacts: PROJECT_SYNTHESIS_ARTIFACTS.length, missingArtifacts, readyToFinalize: missingArtifacts.length === 0 }
  }

  async finalizeStaged(options: FinalizeStagedProjectOptions): Promise<ProjectSynthesisFinalizeResult> {
    const workspace = this.workspace(options.workspaceRoot)
    const state = await this.resolveSynthesisState(workspace.outputRoot, options.runId)
    this.assertSynthesizing(state)
    const staging = await this.readStaging(workspace.outputRoot, state.runId)
    const contents = new Map<ProjectSynthesisArtifact, string>()
    for (const artifact of PROJECT_SYNTHESIS_ARTIFACTS) {
      const record = staging.artifacts.find(item => item.artifact === artifact)
      if (record === undefined) continue
      const expectedPath = path.join('runs', state.runId, 'project', 'synthesis', 'staged', PROJECT_SYNTHESIS_ARTIFACT_FILES[artifact]).split(path.sep).join('/')
      if (record.path !== expectedPath) throw new Error('ArchScope project synthesis staging path changed: ' + artifact)
      try {
        const content = await readFile(path.join(workspace.outputRoot, expectedPath), 'utf8')
        if (record.bytes !== Buffer.byteLength(content, 'utf8') || record.digest !== sha256(content)) throw new Error('ArchScope project synthesis staged artifact changed after submission: ' + artifact)
        contents.set(artifact, content)
      } catch (error) {
        if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) throw error
      }
    }
    const missingArtifacts = PROJECT_SYNTHESIS_ARTIFACTS.filter(artifact => !contents.has(artifact))
    if (missingArtifacts.length > 0) {
      return { finalizeStatus: 'INCOMPLETE', runId: state.runId, projectKey: state.projectKey, stagedCount: contents.size, totalArtifacts: PROJECT_SYNTHESIS_ARTIFACTS.length, missingArtifacts }
    }
    const commit = await this.commit({
      runId: state.runId,
      workspaceRoot: workspace.root,
      writer: options.writer,
      draft: {
        profile: contents.get('PROFILE') as string,
        diagrams: {
          projectContext: contents.get('PROJECT_CONTEXT_DIAGRAM') as string,
          structure: contents.get('STRUCTURE_DIAGRAM') as string,
          entryDependency: contents.get('ENTRY_DEPENDENCY_DIAGRAM') as string,
        },
      },
    })
    return { finalizeStatus: 'COMMITTED', runId: state.runId, projectKey: state.projectKey, stagedCount: contents.size, totalArtifacts: PROJECT_SYNTHESIS_ARTIFACTS.length, missingArtifacts: [], commit }
  }

  async commit(options: CommitProjectOptions): Promise<ProjectSynthesisCommitResult> {
    const workspace = this.workspace(options.workspaceRoot)
    let state = await this.readState(workspace.outputRoot, options.runId)
    this.assertSynthesizing(state)
    const pack = await loadProjectProtocolPack()
    const input = await this.readInput(workspace.outputRoot, options.runId)
    const digest = projectSynthesisInputDigest(input)
    if (state.protocol.digest !== pack.lock.packDigest || state.synthesisInputDigest !== digest) throw new Error('ArchScope project synthesis inputs or protocol changed.')
    if (options.writer.specialization !== input.projectEvidence.specialization) throw new Error('Project writer specialization does not match the frozen project evidence specialization.')
    await assertProjectProtocolReads(workspace.outputRoot, state.runId, 'WRITER', projectProtocolResourceIds(state.specialization, 'WRITER').map(resourceId => protocolResource(pack, resourceId)))
    const ledger = await this.readLedger(workspace.outputRoot, options.runId)
    if (ledger === undefined) throw new Error('ArchScope project synthesis input has not been read.')
    const manifest = buildProjectSynthesisReadManifest(digest, input)
    this.assertLedger(ledger, options.runId, pack.lock.packDigest, manifest)
    const incomplete = ledger.datasets.filter(item => !item.complete || item.coveredRecordKeys.length !== item.totalRecords)
    if (incomplete.length > 0) throw new Error('Continue lossless project paging before commit: ' + incomplete.map(item => item.dataset + ' ' + item.coveredRecordKeys.length + '/' + item.totalRecords).join(', ') + '.')

    const attempt = (state.synthesisAttempts ?? 0) + 1
    const generatedAt = new Date().toISOString()
    let prepared = prepareProjectArtifacts(input, generatedAt, pack, options.draft, 'PENDING', state.sourceSystemRevision)
    const retryAllowed = prepared.validation.status === 'FAILED' && attempt < MAX_PROJECT_SYNTHESIS_ATTEMPTS
    const history = retryAllowed ? undefined : await this.readHistory(workspace.outputRoot, state.projectKey)
    const revision = history === undefined ? 'PENDING' : nextRevision(history)
    if (history !== undefined) prepared = prepareProjectArtifacts(input, generatedAt, pack, options.draft, revision, state.sourceSystemRevision)
    const nextStatus: ProjectScanStatus = retryAllowed ? 'SYNTHESIZING' : prepared.validation.status === 'PASSED' && prepared.validation.gate === 'READY' ? 'COMPLETED' : 'BLOCKED'
    const publishCurrent = !retryAllowed && prepared.validation.status === 'PASSED' && prepared.validation.gate === 'READY'
    const synthesis = {
      protocolVersion: PROJECT_SCAN_PROTOCOL, runId: state.runId, projectKey: state.projectKey,
      projectRevision: revision, ...(history?.latestRevision === undefined ? {} : { previousRevision: history.latestRevision }),
      sourceSystemRevision: state.sourceSystemRevision, generatedAt, writer: options.writer, attempt,
      protocolDigest: pack.lock.packDigest, inputDigest: digest, outputDigest: projectSynthesisOutputDigest(options.draft),
    } as const
    await writeProjectArtifacts({ outputRoot: workspace.outputRoot, projectKey: state.projectKey, input, draft: options.draft, profile: prepared.profile, validation: prepared.validation, synthesis, protocolLock: pack.lock, publishCurrent })
    if (history !== undefined) {
      const record: ProjectHistoryRevision = {
        revision, ...(history.latestRevision === undefined ? {} : { previousRevision: history.latestRevision }),
        runId: state.runId, sourceSystemRevision: state.sourceSystemRevision, generatedAt, status: nextStatus,
        gate: prepared.validation.gate, validation: prepared.validation.status, protocol: state.protocol,
        conflictCount: prepared.validation.conflictCount, blockingConflictCount: prepared.validation.blockingConflictCount, reconciliationStatus: prepared.validation.reconciliationStatus,
        synthesisAttempt: attempt, outputDigest: synthesis.outputDigest, publishedAsCurrent: publishCurrent,
        artifactRoot: 'runs/' + state.runId + '/project',
      }
      await this.writeHistory(workspace.outputRoot, { protocolVersion: PROJECT_SCAN_PROTOCOL, projectKey: state.projectKey, updatedAt: generatedAt, latestRevision: revision, ...(publishCurrent ? { currentRevision: revision } : history.currentRevision === undefined ? {} : { currentRevision: history.currentRevision }), revisions: [...history.revisions, record] })
    }
    state = await this.transition(workspace.outputRoot, state, nextStatus, { projectRevision: revision, synthesisAttempts: attempt, validation: prepared.validation.status, gate: prepared.validation.gate, conflictCount: prepared.validation.conflictCount, blockingConflictCount: prepared.validation.blockingConflictCount, reconciliationStatus: prepared.validation.reconciliationStatus, ...(retryAllowed ? {} : { finishedAt: generatedAt }) })
    return { ...this.result(state, false), synthesisAttempt: attempt, retryAllowed, issues: prepared.validation.issues }
  }

  private async performScan(projectKey: string, options: ScanProjectOptions, workspace: Workspace): Promise<ProjectScanResult> {
    const system = await this.readLatestSystem(workspace.outputRoot)
    if (system.status !== 'COMPLETED' || system.validation !== 'PASSED' || system.gate !== 'READY') throw new Error('Project scan is blocked: the latest system scan must be COMPLETED, PASSED, and READY.')
    if (options.sourceSystemRunId !== undefined && options.sourceSystemRunId !== system.runId) throw new Error('Project batch system binding changed before project execution: expected run ' + options.sourceSystemRunId + ', found ' + system.runId + '.')
    if (options.sourceSystemRevision !== undefined && options.sourceSystemRevision !== system.documentRevision) throw new Error('Project batch system revision changed before project execution: expected ' + options.sourceSystemRevision + ', found ' + system.documentRevision + '.')
    const pack = await loadProjectProtocolPack()
    if (!options.refresh) {
      const reused = await this.readLatestProjectState(workspace.outputRoot, projectKey)
      if (reused !== undefined && reused.status === 'COMPLETED' && reused.sourceSystemRevision === system.documentRevision && reused.protocol.digest === pack.lock.packDigest) return this.result(reused, true)
    }
    const { registry, indexes, evidence, relations } = await this.readSystemInputs(workspace.outputRoot, system.runId)
    const project = registry.projects.find(item => item.projectKey === projectKey)
    if (project === undefined) throw new Error('Project key is not registered by the latest system scan: ' + projectKey)
    const systemIndex = indexes.records.find(item => item.projectKey === projectKey)
    const systemEvidence = evidence.records.find(item => item.projectKey === projectKey)
    if (systemIndex === undefined || systemEvidence === undefined) throw new Error('Latest system run is missing index or evidence for ' + projectKey + '.')
    const sourceSystemFactBase = await readFile(path.join(workspace.outputRoot, 'runs', system.runId, 'system', '00-system-fact-base.md'), 'utf8')
    const specializationDecision = await detectProjectSpecialization(path.resolve(workspace.root, project.projectDir), project)
    if (!specializationDecision.dispatchable) throw new Error('Project scan requires an explicit analysis-unit override: ' + specializationDecision.decisionReason + ' Signals: ' + specializationDecision.conflictingSignals.join(', ') + '.')

    await mkdir(path.join(workspace.outputRoot, 'runs'), { recursive: true })
    const now = new Date()
    let state: ProjectScanRunState = {
      protocolVersion: PROJECT_SCAN_PROTOCOL, protocol: { packId: pack.lock.packId, version: pack.lock.version, digest: pack.lock.packDigest },
      runId: projectRunId(projectKey, now), projectKey, projectDir: project.projectDir,
      specialization: specializationDecision.specialization,
      ...(specializationDecision.framework === undefined ? {} : { framework: specializationDecision.framework }),
      projectRevision: 'PENDING',
      sourceSystemRunId: system.runId, sourceSystemRevision: system.documentRevision, status: 'VALIDATING_SYSTEM_GATE',
      gate: 'BLOCKED', validation: 'NOT_RUN', startedAt: now.toISOString(), updatedAt: now.toISOString(), workspaceRoot: '.',
      outputDirectory: workspace.outputDirectory, refresh: options.refresh ?? false, indexStatus: systemIndex.status,
      evidenceStatus: 'PENDING', scopeViolationCount: 0, conflictCount: 0, blockingConflictCount: 0, reconciliationStatus: 'NOT_REQUIRED', transitions: [{ status: 'VALIDATING_SYSTEM_GATE', at: now.toISOString() }],
    }
    await this.writeState(workspace.outputRoot, state)
    try {
      state = await this.transition(workspace.outputRoot, state, 'PREPARING_INDEX')
      options.onProgress?.({ stage: 'PREPARING_INDEX', message: '系统门禁已通过，开始准备 ' + projectKey + ' 的独立代码智能索引' })
      let index = systemIndex
      if (options.refresh || systemIndex.status !== 'FRESH') {
        const refreshed = await this.analyzer.index([project], { workspaceRoot: workspace.root, generatedAt: now.toISOString(), refresh: true, signal: options.signal, agent: options.agent })
        index = refreshed.records[0] ?? systemIndex
      }
      if (index.status !== 'FRESH') throw new Error('Project code-intelligence index is not FRESH: ' + index.reason)
      if (this.analyzer.collectProjectEvidence === undefined) throw new Error('Configured analyzer does not support project-level deep evidence.')
      state = await this.transition(workspace.outputRoot, state, 'COLLECTING_PROJECT_EVIDENCE', { indexStatus: index.status })
      options.onProgress?.({ stage: 'COLLECTING_PROJECT_EVIDENCE', message: '索引已就绪，子 Agent 正在深挖 ' + projectKey + ' 的工程画像证据' })
      const safeMetadata = await collectSafeProjectMetadata(path.resolve(workspace.root, project.projectDir)).catch(() => ({ files: [], omittedFiles: 0, boundary: 'PROJECT_ROOT_ONLY' as const }))
      const deterministicFacts = specializationDecision.specialization === 'java-spring-backend'
        ? await collectSpringProjectFacts(path.resolve(workspace.root, project.projectDir), new Date().toISOString())
        : undefined
      const evidenceProtocolResourceIds = projectProtocolResourceIds(specializationDecision.specialization, 'EVIDENCE')
      const evidenceInput: ProjectEvidenceInputs = {
        sourceSystemFactBase, systemEvidence, safeMetadata,
        ...(deterministicFacts === undefined ? {} : { deterministicFacts }),
      }
      const evidenceInputDigest = projectEvidenceInputDigest(evidenceInput)
      const evidenceManifest = buildProjectEvidenceReadManifest(evidenceInputDigest, evidenceInput)
      const evidenceLedger = createProjectEvidenceReadLedger(state.runId, pack.lock.packDigest, evidenceManifest)
      const evidenceTaskContext: ProjectEvidenceTaskContext = {
        protocolVersion: PROJECT_SCAN_PROTOCOL, runId: state.runId, projectKey, projectDir: project.projectDir,
        specialization: specializationDecision.specialization,
        ...(specializationDecision.framework === undefined ? {} : { framework: specializationDecision.framework }),
        mcpProject: index.mcpProject as string, sourceSystemRevision: system.documentRevision,
        evidenceMode: 'PAGED', manifest: evidenceManifest, protocolResourceIds: evidenceProtocolResourceIds,
      }
      await Promise.all([
        atomicWriteJson(path.join(workspace.outputRoot, 'runs', state.runId, 'project', 'evidence-task-context.json'), evidenceTaskContext),
        atomicWriteJson(path.join(workspace.outputRoot, 'runs', state.runId, 'project', 'evidence', 'input.json'), evidenceInput),
        this.writeEvidenceLedger(workspace.outputRoot, evidenceLedger),
      ])
      const projectEvidence = await this.analyzer.collectProjectEvidence(project, index, {
        workspaceRoot: workspace.root, generatedAt: new Date().toISOString(), refresh: options.refresh ?? false,
        signal: options.signal, agent: options.agent,
        projectContext: { runId: state.runId, sourceSystemRevision: system.documentRevision, sourceSystemFactBase, systemEvidence, safeMetadata, deterministicFacts, specializationDecision },
      })
      await assertProjectProtocolReads(workspace.outputRoot, state.runId, 'EVIDENCE', [
        { id: PROJECT_EVIDENCE_CONTEXT_RESOURCE_ID, version: PROJECT_SCAN_PROTOCOL, digest: sha256(JSON.stringify(evidenceTaskContext)) },
        ...evidenceProtocolResourceIds.map(resourceId => protocolResource(pack, resourceId)),
      ])
      const completedEvidenceLedger = await this.readEvidenceLedger(workspace.outputRoot, state.runId)
      if (completedEvidenceLedger === undefined) throw new Error('Project evidence datasets were not read.')
      this.assertEvidenceLedger(completedEvidenceLedger, state.runId, pack.lock.packDigest, evidenceManifest)
      const incompleteEvidence = completedEvidenceLedger.datasets.filter(item => !item.complete || item.coveredRecordKeys.length !== item.totalRecords)
      if (incompleteEvidence.length > 0) throw new Error('Project evidence agent did not finish lossless paging: ' + incompleteEvidence.map(item => item.dataset + ' ' + item.coveredRecordKeys.length + '/' + item.totalRecords).join(', ') + '.')
      if (projectEvidence.status !== 'COLLECTED') throw new Error('Project deep evidence collection did not complete: ' + (projectEvidence.failureReason ?? 'unknown reason'))
      if (projectEvidence.scopeStatus !== 'CLEAN' || projectEvidence.scopeViolations.length > 0) throw new Error('Project deep evidence crossed the target project boundary.')
      if (deterministicFacts !== undefined) {
        projectEvidence.statistics = [
          ...deterministicStatistics(deterministicFacts),
          ...projectEvidence.statistics.map(item => ({ ...item, authority: item.authority ?? 'AGENT_OBSERVED' as const })),
        ]
        projectEvidence.evidencePaths = [...new Set([...projectEvidence.evidencePaths, ...deterministicEvidencePaths(deterministicFacts)])]
      }
      projectEvidence.conflicts = projectEvidence.conflicts.map(conflict => ({ ...conflict, sourceSystemRevision: system.documentRevision }))
      const conflictCount = projectEvidence.conflicts.length
      const blockingConflictCount = projectEvidence.conflicts.filter(conflict => conflict.severity === 'BLOCKING').length
      const reconciliationStatus = blockingConflictCount > 0 ? 'BLOCKED' as const : projectEvidence.conflicts.some(conflict => conflict.reconciliationStatus === 'OPEN') ? 'OPEN' as const : 'NOT_REQUIRED' as const
      const relatedRelations = relations.records.filter(item => item.sourceProjectKey === projectKey || item.targetProjectKey === projectKey)
      const input: ProjectSynthesisInputs = {
        sourceSystemFactBase, project, index, systemEvidence, relatedRelations, projectEvidence,
        ...(deterministicFacts === undefined ? {} : { deterministicFacts }),
      }
      await atomicWriteJson(path.join(workspace.outputRoot, 'runs', state.runId, 'project', 'synthesis-input.json'), input)
      await atomicWriteJson(path.join(workspace.outputRoot, 'runs', state.runId, 'project', 'conflicts.json'), { sourceSystemRunId: system.runId, sourceSystemRevision: system.documentRevision, reconciliationStatus, conflicts: projectEvidence.conflicts })
      state = await this.transition(workspace.outputRoot, state, 'AWAITING_PROJECT_SYNTHESIS', {
        evidenceStatus: 'COLLECTED',
        scopeViolationCount: 0,
        conflictCount,
        blockingConflictCount,
        reconciliationStatus,
        synthesisInputDigest: projectSynthesisInputDigest(input),
      })
      options.onProgress?.({ stage: 'AWAITING_PROJECT_SYNTHESIS', message: projectEvidence.specialization + ' 深证据已持久化，等待项目专属写作 Agent 综合工程画像' })
      return this.result(state, false)
    } catch (error) {
      state = await this.transition(workspace.outputRoot, state, 'FAILED', { validation: 'FAILED', gate: 'BLOCKED', evidenceStatus: state.evidenceStatus === 'PENDING' ? 'FAILED' : state.evidenceStatus, finishedAt: new Date().toISOString(), error: errorMessage(error) })
      throw error
    }
  }

  private workspace(invocation?: string): Workspace {
    const session = invocation?.trim()
    const configured = this.config.workspaceRoot?.trim()
    if ((!session || session === '') && (!configured || configured === '' || !path.isAbsolute(configured))) throw new Error('ArchScope requires the current absolute DSH workspace.')
    if (session && !path.isAbsolute(session)) throw new Error('DSH workspace must be an absolute path.')
    const root = !configured ? path.resolve(session as string) : path.isAbsolute(configured) ? path.resolve(configured) : path.resolve(session as string, configured)
    if (path.isAbsolute(this.config.outputDirectory)) throw new Error('ArchScope outputDirectory must be relative.')
    const outputRoot = path.resolve(root, this.config.outputDirectory)
    const relative = path.relative(root, outputRoot)
    if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('ArchScope outputDirectory must stay inside the workspace.')
    return { root, outputRoot, outputDirectory: relative.split(path.sep).join('/') }
  }

  private async resolveSynthesisState(outputRoot: string, runId?: string): Promise<ProjectScanRunState> {
    if (runId?.trim()) return this.readState(outputRoot, runId)
    let entries: Dirent[]
    try { entries = await readdir(path.join(outputRoot, 'projects'), { withFileTypes: true }) }
    catch (error) { if (error instanceof Error && 'code' in error && error.code === 'ENOENT') entries = []; else throw error }
    const candidates: ProjectScanRunState[] = []
    for (const entry of entries) {
      if (!entry.isDirectory()) continue
      try {
        const latest = JSON.parse(await readFile(path.join(outputRoot, 'projects', entry.name, 'latest.json'), 'utf8')) as { runId?: unknown }
        if (typeof latest.runId !== 'string') continue
        const state = await this.readState(outputRoot, latest.runId)
        if (state.status === 'AWAITING_PROJECT_SYNTHESIS' || state.status === 'SYNTHESIZING') candidates.push(state)
      } catch (error) {
        if (!(error instanceof Error && 'code' in error && error.code === 'ENOENT')) throw error
      }
    }
    if (candidates.length === 1) return candidates[0] as ProjectScanRunState
    if (candidates.length === 0) throw new Error('No active ArchScope project synthesis run was found; pass runId explicitly.')
    throw new Error('Multiple active ArchScope project synthesis runs were found; pass runId explicitly: ' + candidates.map(item => item.runId).join(', ') + '.')
  }

  private async readStaging(outputRoot: string, runId: string): Promise<ProjectSynthesisStagingState> {
    try {
      const value = JSON.parse(await readFile(path.join(outputRoot, 'runs', runId, 'project', 'synthesis', 'staging.json'), 'utf8')) as ProjectSynthesisStagingState
      if (value.protocolVersion !== PROJECT_SCAN_PROTOCOL || value.runId !== runId || !Array.isArray(value.artifacts)) throw new Error('Malformed ArchScope project synthesis staging state.')
      return value
    } catch (error) {
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') return { protocolVersion: PROJECT_SCAN_PROTOCOL, runId, updatedAt: new Date(0).toISOString(), artifacts: [] }
      throw error
    }
  }

  private async writeStaging(outputRoot: string, staging: ProjectSynthesisStagingState): Promise<void> {
    await atomicWriteJson(path.join(outputRoot, 'runs', staging.runId, 'project', 'synthesis', 'staging.json'), staging)
  }

  private async readLatestSystem(outputRoot: string): Promise<SystemScanRunState> {
    const latest = JSON.parse(await readFile(path.join(outputRoot, 'runs', 'latest.json'), 'utf8')) as { runId?: unknown }
    if (typeof latest.runId !== 'string' || !latest.runId.startsWith('system-')) throw new Error('No latest ArchScope system run was found.')
    return JSON.parse(await readFile(path.join(outputRoot, 'runs', latest.runId, 'state.json'), 'utf8')) as SystemScanRunState
  }
  private async readSystemInputs(outputRoot: string, runId: string): Promise<{ registry: ProjectRegistry, indexes: IndexManifest, evidence: SystemEvidenceBundle, relations: SystemRelationCatalog }> {
    const root = path.join(outputRoot, 'runs', runId, 'system')
    const values = await Promise.all(['project-registry.json','index-manifest.json','evidence/index.json','relations.json'].map(file => readFile(path.join(root, file), 'utf8')))
    return { registry: JSON.parse(values[0] as string), indexes: JSON.parse(values[1] as string), evidence: JSON.parse(values[2] as string), relations: JSON.parse(values[3] as string) }
  }
  private async writeState(outputRoot: string, state: ProjectScanRunState): Promise<void> {
    await atomicWriteJson(path.join(outputRoot, 'runs', state.runId, 'state.json'), state)
    await atomicWriteJson(path.join(outputRoot, 'projects', state.projectKey, 'latest.json'), { runId: state.runId })
  }
  private async transition(outputRoot: string, state: ProjectScanRunState, status: ProjectScanStatus, changes: Partial<ProjectScanRunState> = {}): Promise<ProjectScanRunState> {
    const at = new Date().toISOString()
    const next = { ...state, ...changes, status, updatedAt: at, transitions: [...state.transitions, { status, at }] }
    await this.writeState(outputRoot, next)
    return next
  }
  private async readState(outputRoot: string, runId: string): Promise<ProjectScanRunState> {
    if (!/^project-[a-z0-9][a-z0-9-]*$/u.test(runId)) throw new Error('Invalid ArchScope project run id.')
    const state = JSON.parse(await readFile(path.join(outputRoot, 'runs', runId, 'state.json'), 'utf8')) as ProjectScanRunState
    if (state.protocolVersion !== PROJECT_SCAN_PROTOCOL) throw new Error('Unsupported ArchScope project run protocol.')
    return state
  }
  private async readLatestProjectState(outputRoot: string, projectKey: string): Promise<ProjectScanRunState | undefined> {
    try {
      const latest = JSON.parse(await readFile(path.join(outputRoot, 'projects', projectKey, 'latest.json'), 'utf8')) as { runId?: unknown }
      return typeof latest.runId === 'string' ? await this.readState(outputRoot, latest.runId) : undefined
    } catch (error) { if (error instanceof Error && 'code' in error && error.code === 'ENOENT') return undefined; throw error }
  }
  private async readEvidenceInput(outputRoot: string, runId: string): Promise<ProjectEvidenceInputs> { return JSON.parse(await readFile(path.join(outputRoot, 'runs', runId, 'project', 'evidence', 'input.json'), 'utf8')) as ProjectEvidenceInputs }
  private async readEvidenceLedger(outputRoot: string, runId: string): Promise<ProjectEvidenceReadLedger | undefined> {
    try { return JSON.parse(await readFile(path.join(outputRoot, 'runs', runId, 'project', 'evidence', 'read-ledger.json'), 'utf8')) as ProjectEvidenceReadLedger }
    catch (error) { if (error instanceof Error && 'code' in error && error.code === 'ENOENT') return undefined; throw error }
  }
  private async writeEvidenceLedger(outputRoot: string, ledger: ProjectEvidenceReadLedger): Promise<void> { await atomicWriteJson(path.join(outputRoot, 'runs', ledger.runId, 'project', 'evidence', 'read-ledger.json'), ledger) }
  private assertEvidenceLedger(ledger: ProjectEvidenceReadLedger, runId: string, protocolDigest: string, manifest: ReturnType<typeof buildProjectEvidenceReadManifest>): void {
    if (ledger.runId !== runId || ledger.protocolDigest !== protocolDigest || ledger.inputDigest !== manifest.inputDigest || ledger.pageMaxBytes !== manifest.pageMaxBytes) throw new Error('ArchScope project evidence ledger no longer matches the run.')
    for (const expected of manifest.datasets) { const actual = ledger.datasets.find(item => item.dataset === expected.dataset); if (!actual || actual.globalDigest !== expected.globalDigest || actual.totalRecords !== expected.totalRecords) throw new Error('ArchScope project evidence dataset changed: ' + expected.dataset) }
  }
  private async readInput(outputRoot: string, runId: string): Promise<ProjectSynthesisInputs> { return JSON.parse(await readFile(path.join(outputRoot, 'runs', runId, 'project', 'synthesis-input.json'), 'utf8')) as ProjectSynthesisInputs }
  private async readLedger(outputRoot: string, runId: string): Promise<ProjectSynthesisReadLedger | undefined> {
    try { return JSON.parse(await readFile(path.join(outputRoot, 'runs', runId, 'project', 'synthesis', 'read-ledger.json'), 'utf8')) as ProjectSynthesisReadLedger }
    catch (error) { if (error instanceof Error && 'code' in error && error.code === 'ENOENT') return undefined; throw error }
  }
  private async writeLedger(outputRoot: string, ledger: ProjectSynthesisReadLedger): Promise<void> { await atomicWriteJson(path.join(outputRoot, 'runs', ledger.runId, 'project', 'synthesis', 'read-ledger.json'), ledger) }
  private assertSynthesizing(state: ProjectScanRunState): void { if (state.status !== 'AWAITING_PROJECT_SYNTHESIS' && state.status !== 'SYNTHESIZING') throw new Error('ArchScope project run ' + state.runId + ' is ' + state.status + '; it does not accept synthesis.') }
  private assertLedger(ledger: ProjectSynthesisReadLedger, runId: string, protocolDigest: string, manifest: ReturnType<typeof buildProjectSynthesisReadManifest>): void {
    if (ledger.runId !== runId || ledger.protocolDigest !== protocolDigest || ledger.inputDigest !== manifest.inputDigest || ledger.pageMaxBytes !== manifest.pageMaxBytes) throw new Error('ArchScope project synthesis ledger no longer matches the run.')
    for (const expected of manifest.datasets) { const actual = ledger.datasets.find(item => item.dataset === expected.dataset); if (!actual || actual.globalDigest !== expected.globalDigest || actual.totalRecords !== expected.totalRecords) throw new Error('ArchScope project synthesis dataset changed: ' + expected.dataset) }
  }
  private async readHistory(outputRoot: string, projectKey: string): Promise<ProjectHistoryIndex> {
    try {
      const parsed = JSON.parse(await readFile(path.join(outputRoot, 'projects', projectKey, 'history.json'), 'utf8')) as ProjectHistoryIndex
      if (parsed.protocolVersion !== PROJECT_SCAN_PROTOCOL || !Array.isArray(parsed.revisions)) throw new Error('Malformed ArchScope project history.')
      return parsed
    } catch (error) { if (error instanceof Error && 'code' in error && error.code === 'ENOENT') return { protocolVersion: PROJECT_SCAN_PROTOCOL, projectKey, updatedAt: new Date(0).toISOString(), revisions: [] }; throw error }
  }
  private async writeHistory(outputRoot: string, history: ProjectHistoryIndex): Promise<void> { await atomicWriteJson(path.join(outputRoot, 'projects', history.projectKey, 'history.json'), history) }
  private result(state: ProjectScanRunState, reused: boolean): ProjectScanResult { return { runId: state.runId, projectKey: state.projectKey, projectDir: state.projectDir, specialization: state.specialization, ...(state.framework === undefined ? {} : { framework: state.framework }), projectRevision: state.projectRevision, sourceSystemRevision: state.sourceSystemRevision, status: state.status, gate: state.gate, validation: state.validation, indexStatus: state.indexStatus, evidenceStatus: state.evidenceStatus, scopeViolationCount: state.scopeViolationCount, conflictCount: state.conflictCount ?? 0, blockingConflictCount: state.blockingConflictCount ?? 0, reconciliationStatus: state.reconciliationStatus ?? 'NOT_REQUIRED', outputDirectory: state.outputDirectory, reused } }
}
