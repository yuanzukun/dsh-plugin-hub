import { createHash } from 'node:crypto'

import {
  PROJECT_SCAN_PROTOCOL,
  type ProjectEvidenceDataset,
  type ProjectEvidenceInputs,
  type ProjectEvidencePage,
  type ProjectEvidenceReadLedger,
  type ProjectEvidenceReadManifest,
} from '../contracts/project-scan.js'

export const PROJECT_EVIDENCE_PAGE_MAX_BYTES = 12 * 1024
export const PROJECT_EVIDENCE_DATASETS: ProjectEvidenceDataset[] = [
  'SAFE_METADATA',
  'DETERMINISTIC_FACTS',
  'SYSTEM_PROJECT_EVIDENCE',
  'SYSTEM_FACT_BASE',
]

interface SourceRecord { key: string, json: string }

function sha256(value: string): string { return createHash('sha256').update(value).digest('hex') }

export function projectEvidenceInputDigest(input: ProjectEvidenceInputs): string { return sha256(JSON.stringify(input)) }

function sources(dataset: ProjectEvidenceDataset, input: ProjectEvidenceInputs): SourceRecord[] {
  if (dataset === 'SAFE_METADATA') {
    return [
      { key: 'safe-metadata-boundary', json: JSON.stringify({ boundary: input.safeMetadata.boundary, omittedFiles: input.safeMetadata.omittedFiles, redaction: 'APPLIED_BEFORE_AGENT' }) },
      ...input.safeMetadata.files.map(file => ({ key: file.path, json: JSON.stringify(file) })),
    ]
  }
  if (dataset === 'DETERMINISTIC_FACTS') {
    const facts = input.deterministicFacts
    if (facts === undefined) return []
    return [
      {
        key: 'deterministic-overview',
        json: JSON.stringify({
          protocolVersion: facts.protocolVersion, specialization: facts.specialization, generatedAt: facts.generatedAt,
          boundary: facts.boundary, scanStatus: facts.scanStatus, scannedFileCount: facts.scannedFileCount,
          skippedFileCount: facts.skippedFileCount, moduleManifests: facts.moduleManifests,
          moduleDependencies: facts.moduleDependencies ?? [], configurationFiles: facts.configurationFiles,
          negativeClaimRules: facts.negativeClaimRules, coverageGaps: facts.coverageGaps,
        }),
      },
      ...facts.metrics.map(metric => ({ key: 'metric:' + metric.metricId, json: JSON.stringify(metric) })),
    ]
  }
  if (dataset === 'SYSTEM_PROJECT_EVIDENCE') {
    return [{ key: input.systemEvidence.projectKey, json: JSON.stringify(input.systemEvidence) }]
  }
  return [{ key: 'system-fact-base', json: JSON.stringify({ markdown: input.sourceSystemFactBase }) }]
}

function serialized(records: SourceRecord[]): string { return '[' + records.map(record => record.json).join(',') + ']' }

function parseCursor(cursor: string): { recordIndex: number, byteOffset: number } {
  const match = /^(\d+):(\d+)$/u.exec(cursor)
  if (match === null) throw new Error('Invalid ArchScope project evidence page cursor: ' + cursor)
  return { recordIndex: Number(match[1]), byteOffset: Number(match[2]) }
}

function utf8Prefix(value: string, maxBytes: number): string {
  let bytes = 0
  let result = ''
  for (const character of value) {
    const size = Buffer.byteLength(character, 'utf8')
    if (bytes + size > maxBytes) break
    result += character
    bytes += size
  }
  return result
}

export function buildProjectEvidenceReadManifest(
  inputDigest: string,
  input: ProjectEvidenceInputs,
  ledger?: ProjectEvidenceReadLedger,
): ProjectEvidenceReadManifest {
  return {
    inputDigest,
    pageMaxBytes: PROJECT_EVIDENCE_PAGE_MAX_BYTES,
    datasets: PROJECT_EVIDENCE_DATASETS.map(dataset => {
      const records = sources(dataset, input)
      const value = serialized(records)
      const state = ledger?.datasets.find(candidate => candidate.dataset === dataset)
      return {
        dataset, totalRecords: records.length, totalBytes: Buffer.byteLength(value, 'utf8'), globalDigest: sha256(value),
        nextCursor: state === undefined ? (records.length === 0 ? null : '0:0') : state.nextCursor,
        complete: state?.complete ?? records.length === 0,
      }
    }),
  }
}

export function createProjectEvidenceReadLedger(
  runId: string,
  protocolDigest: string,
  manifest: ProjectEvidenceReadManifest,
  now = new Date().toISOString(),
): ProjectEvidenceReadLedger {
  return {
    protocolVersion: PROJECT_SCAN_PROTOCOL, runId, protocolDigest, inputDigest: manifest.inputDigest,
    pageMaxBytes: manifest.pageMaxBytes, createdAt: now, updatedAt: now,
    datasets: manifest.datasets.map(dataset => ({
      dataset: dataset.dataset, globalDigest: dataset.globalDigest, totalRecords: dataset.totalRecords,
      nextCursor: dataset.nextCursor, coveredRecordKeys: [], pageDigests: [], complete: dataset.complete,
    })),
  }
}

export function buildProjectEvidencePage(
  runId: string,
  protocolDigest: string,
  dataset: ProjectEvidenceDataset,
  cursor: string,
  input: ProjectEvidenceInputs,
): ProjectEvidencePage {
  const records = sources(dataset, input)
  let { recordIndex, byteOffset } = parseCursor(cursor)
  if (recordIndex > records.length || (recordIndex === records.length && byteOffset !== 0)) throw new Error('ArchScope project evidence cursor is outside ' + dataset + '.')
  const items: ProjectEvidencePage['items'] = []
  let pageBytes = 0
  while (recordIndex < records.length && pageBytes < PROJECT_EVIDENCE_PAGE_MAX_BYTES) {
    const record = records[recordIndex] as SourceRecord
    const recordBuffer = Buffer.from(record.json, 'utf8')
    const fullBytes = recordBuffer.byteLength
    if (byteOffset > fullBytes) throw new Error('ArchScope project evidence cursor is outside record ' + record.key + '.')
    const remaining = byteOffset === 0 ? record.json : recordBuffer.subarray(byteOffset).toString('utf8')
    const chunk = utf8Prefix(remaining, PROJECT_EVIDENCE_PAGE_MAX_BYTES - pageBytes)
    if (chunk === '') break
    const chunkBytes = Buffer.byteLength(chunk, 'utf8')
    const completeRecord = byteOffset + chunkBytes === fullBytes
    items.push({ recordKey: record.key, recordDigest: sha256(record.json), json: chunk, byteOffset, totalBytes: fullBytes, completeRecord })
    pageBytes += chunkBytes
    if (completeRecord) { recordIndex += 1; byteOffset = 0 } else { byteOffset += chunkBytes; break }
  }
  const complete = recordIndex === records.length
  const nextCursor = complete ? null : String(recordIndex) + ':' + String(byteOffset)
  return {
    runId, protocolDigest, dataset, cursor, nextCursor,
    pageDigest: sha256(JSON.stringify({ dataset, cursor, nextCursor, items })),
    globalDigest: sha256(serialized(records)), pageBytes,
    pageRecordCount: items.filter(item => item.completeRecord).length,
    coveredRecordCount: recordIndex, totalRecords: records.length, complete, items,
  }
}
