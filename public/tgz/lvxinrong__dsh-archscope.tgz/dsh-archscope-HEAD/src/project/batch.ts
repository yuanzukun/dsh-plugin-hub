import { randomUUID } from 'node:crypto'
import { readFile } from 'node:fs/promises'
import path from 'node:path'

import type { Context } from '@deepseek-ai/cordis'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { ToolExecutionInput } from '@deepseek-ai/dsh-tools'

import type { Config } from '../config.js'
import { PROJECT_SCAN_PROTOCOL, type ProjectBatchItemResult, type ProjectBatchProgress, type ProjectBatchResult, type ProjectBatchRunState, type ProjectBatchSelection, type ProjectScanResult } from '../contracts/project-scan.js'
import type { ProjectRegistry, SystemScanRunState } from '../contracts/system-scan.js'
import { atomicWriteJson } from '../system/artifacts.js'
import { ProjectScanCoordinator } from './coordinator.js'
import { projectAgentSpec } from './specializations.js'

interface SubagentResultLike { output: ContentBlock[], structured?: unknown, stopReason: string }
interface SubagentRunLike { result: Promise<SubagentResultLike>, dispose(): Promise<void> }
interface SubagentRuntimeLike { getProvider(name: string): unknown, start(name: string, request: unknown): Promise<SubagentRunLike> }

export interface ScanProjectsOptions {
  refresh?: boolean
  maxConcurrency?: number
  signal?: AbortSignal
  workspaceRoot?: string
  agent?: ToolExecutionInput['agent']
  onProgress?: (progress: ProjectBatchProgress) => void
}

interface Workspace { root: string, outputRoot: string, outputDirectory: string }

function batchId(now: Date): string {
  const timestamp = now.toISOString().replace(/[-:.TZ]/gu, '').slice(0, 14)
  return 'project-batch-' + timestamp + '-' + randomUUID().slice(0, 8)
}

function errorMessage(error: unknown): string { return error instanceof Error ? error.message : String(error) }

async function mapLimit<T, R>(values: readonly T[], limit: number, worker: (value: T) => Promise<R>): Promise<R[]> {
  const output = new Array<R>(values.length)
  let cursor = 0
  async function consume() {
    while (cursor < values.length) {
      const index = cursor++
      const value = values[index]
      if (value !== undefined) output[index] = await worker(value)
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, values.length) }, consume))
  return output
}

export class ProjectBatchCoordinator {
  constructor(private readonly ctx: Context, private readonly config: Config, private readonly projects: ProjectScanCoordinator) {}

  async scan(selection: ProjectBatchSelection, options: ScanProjectsOptions = {}): Promise<ProjectBatchResult> {
    const workspace = this.workspace(options.workspaceRoot)
    const { system, registry } = await this.systemBinding(workspace.outputRoot)
    if (system.status !== 'COMPLETED' || system.validation !== 'PASSED' || system.gate !== 'READY') throw new Error('Project batch is blocked: the latest system scan must be COMPLETED, PASSED, and READY.')
    const available = new Set(registry.projects.map(project => project.projectKey))
    const requested = selection.mode === 'ALL_ELIGIBLE' ? registry.projects.map(project => project.projectKey) : selection.projectKeys
    const projectKeys = [...new Set(requested.map(key => key.trim()).filter(Boolean))]
    if (projectKeys.length === 0) throw new Error('Project batch selection is empty.')
    const unknown = projectKeys.filter(key => !available.has(key))
    if (unknown.length > 0) throw new Error('Project keys are not registered by the bound system revision: ' + unknown.join(', ') + '.')
    if (options.agent === undefined) throw new Error('Project batch execution requires the invoking DSH agent.')

    const provider = this.config.evidenceProvider ?? 'spawn'
    const runtime = (this.ctx as unknown as { get(name: string): unknown }).get('subagents') as SubagentRuntimeLike | undefined
    if (runtime === undefined || runtime.getProvider(provider) === undefined) throw new Error('Project batch writer provider is unavailable: ' + provider + '.')
    const tools = ['archscope_get_project_synthesis_context', 'archscope_get_project_protocol_resource', 'archscope_get_project_synthesis_page', 'archscope_stage_project_artifact', 'archscope_finalize_project_synthesis']
    const maxConcurrency = Math.max(1, Math.min(16, options.maxConcurrency ?? this.config.projectConcurrency ?? this.config.systemConcurrency ?? 4))
    const now = new Date()
    let state: ProjectBatchRunState = {
      protocolVersion: PROJECT_SCAN_PROTOCOL, batchId: batchId(now), selection,
      sourceSystemRunId: system.runId, sourceSystemRevision: system.documentRevision,
      status: 'RUNNING', startedAt: now.toISOString(), updatedAt: now.toISOString(), maxConcurrency,
      projectKeys, completedCount: 0, failedCount: 0, blockedCount: 0,
      conflictCount: 0, blockingConflictCount: 0, items: [],
    }
    await this.writeState(workspace.outputRoot, state)
    options.onProgress?.({ batchId: state.batchId, stage: 'PLANNING', message: '项目批次已绑定系统事实版本 ' + system.documentRevision + '，共 ' + projectKeys.length + ' 个工程', completed: 0, total: projectKeys.length })

    let persist = Promise.resolve()
    const record = (item: ProjectBatchItemResult) => {
      persist = persist.then(async () => {
        const items = [...state.items.filter(existing => existing.projectKey !== item.projectKey), item]
        const results = items.flatMap(entry => entry.result === undefined ? [] : [entry.result])
        state = {
          ...state, items, updatedAt: new Date().toISOString(), completedCount: items.length,
          failedCount: items.filter(entry => entry.status === 'FAILED').length,
          blockedCount: items.filter(entry => entry.status === 'BLOCKED').length,
          conflictCount: results.reduce((sum, result) => sum + result.conflictCount, 0),
          blockingConflictCount: results.reduce((sum, result) => sum + result.blockingConflictCount, 0),
        }
        await this.writeState(workspace.outputRoot, state)
      })
      return persist
    }

    await mapLimit(projectKeys, maxConcurrency, async projectKey => {
      let runId: string | undefined
      try {
        options.signal?.throwIfAborted()
        options.onProgress?.({ batchId: state.batchId, stage: 'SCANNING', message: '开始项目深取证：' + projectKey, completed: state.completedCount, total: projectKeys.length, projectKey })
        let result = await this.projects.scan(projectKey, {
          refresh: options.refresh, signal: options.signal, workspaceRoot: workspace.root, agent: options.agent,
          sourceSystemRunId: system.runId, sourceSystemRevision: system.documentRevision,
        })
        runId = result.runId
        if (result.status === 'AWAITING_PROJECT_SYNTHESIS' || result.status === 'SYNTHESIZING') {
          const agentSpec = projectAgentSpec(result.specialization)
          options.onProgress?.({ batchId: state.batchId, stage: 'SYNTHESIZING', message: '项目专属写作 Agent 正在综合：' + projectKey, completed: state.completedCount, total: projectKeys.length, projectKey })
          const writer = await runtime.start(provider, {
            label: 'archscope-project-writer:' + result.specialization + ':' + projectKey,
            prompt: [{ type: 'text', text: `ARCHSCOPE_PROJECT_WRITER_DISPATCH_V1\nrunId=${result.runId}\nprojectKey=${projectKey}\nspecialization=${result.specialization}\nframework=${result.framework ?? 'not-applicable'}\ncontextTool=archscope_get_project_synthesis_context\n\n立即调用 contextTool；严格执行其返回的短任务信封和资源清单。提交进入 COMPLETED 或 BLOCKED 后再结束。` }],
            parent: options.agent, signal: options.signal ?? new AbortController().signal,
            persona: agentSpec.writerPersona + ' 只能调用请求允许的项目综合工具，不得调用扫描、shell、文件读取或系统综合工具。',
            maxDepth: 1, toolFilter: { allow: tools },
          })
          try {
            const writerResult = await writer.result
            if (writerResult.stopReason !== 'completed') throw new Error('project writer stopped with ' + writerResult.stopReason)
          } finally { await writer.dispose().catch(() => undefined) }
          result = await this.projects.inspect(result.runId, { workspaceRoot: workspace.root })
        }
        if (result.status !== 'COMPLETED' && result.status !== 'BLOCKED') throw new Error('project writer ended before a terminal project state: ' + result.status)
        await record({ projectKey, status: result.status, runId: result.runId, result })
      } catch (error) {
        await record({ projectKey, status: 'FAILED', ...(runId === undefined ? {} : { runId }), error: errorMessage(error) })
      }
      options.onProgress?.({ batchId: state.batchId, stage: 'AGGREGATING', message: '项目结果已归集：' + projectKey, completed: state.completedCount, total: projectKeys.length, projectKey })
    })
    await persist
    const finishedAt = new Date().toISOString()
    const status = state.failedCount === projectKeys.length ? 'FAILED' as const : state.failedCount > 0 ? 'PARTIAL' as const : 'COMPLETED' as const
    state = { ...state, status, finishedAt, updatedAt: finishedAt, items: projectKeys.map(key => state.items.find(item => item.projectKey === key) as ProjectBatchItemResult) }
    await this.writeState(workspace.outputRoot, state)
    await atomicWriteJson(path.join(workspace.outputRoot, 'project-batches', state.batchId, 'conflicts.json'), {
      sourceSystemRunId: state.sourceSystemRunId, sourceSystemRevision: state.sourceSystemRevision,
      conflictCount: state.conflictCount, blockingConflictCount: state.blockingConflictCount,
      projects: state.items.flatMap(item => item.result === undefined ? [] : [{ projectKey: item.projectKey, runId: item.result.runId, reconciliationStatus: item.result.reconciliationStatus, conflictCount: item.result.conflictCount, blockingConflictCount: item.result.blockingConflictCount }]),
    })
    options.onProgress?.({ batchId: state.batchId, stage: 'COMPLETED', message: '项目批次完成：成功 ' + state.completedCount + '，失败 ' + state.failedCount + '，阻断 ' + state.blockedCount, completed: state.completedCount, total: projectKeys.length })
    return { ...state, outputDirectory: workspace.outputDirectory }
  }

  private workspace(invocation?: string): Workspace {
    const session = invocation?.trim()
    const configured = this.config.workspaceRoot?.trim()
    if ((!session || session === '') && (!configured || configured === '' || !path.isAbsolute(configured))) throw new Error('ArchScope requires the current absolute DSH workspace.')
    if (session && !path.isAbsolute(session)) throw new Error('DSH workspace must be an absolute path.')
    const root = !configured ? path.resolve(session as string) : path.isAbsolute(configured) ? path.resolve(configured) : path.resolve(session as string, configured)
    const outputRoot = path.resolve(root, this.config.outputDirectory)
    const relative = path.relative(root, outputRoot)
    if (!relative || relative.startsWith('..') || path.isAbsolute(relative)) throw new Error('ArchScope outputDirectory must stay inside the workspace.')
    return { root, outputRoot, outputDirectory: relative.split(path.sep).join('/') }
  }

  private async systemBinding(outputRoot: string): Promise<{ system: SystemScanRunState, registry: ProjectRegistry }> {
    const latest = JSON.parse(await readFile(path.join(outputRoot, 'runs', 'latest.json'), 'utf8')) as { runId?: unknown }
    if (typeof latest.runId !== 'string' || !latest.runId.startsWith('system-')) throw new Error('No latest ArchScope system run was found.')
    const [state, registry] = await Promise.all([
      readFile(path.join(outputRoot, 'runs', latest.runId, 'state.json'), 'utf8'),
      readFile(path.join(outputRoot, 'runs', latest.runId, 'system', 'project-registry.json'), 'utf8'),
    ])
    return { system: JSON.parse(state) as SystemScanRunState, registry: JSON.parse(registry) as ProjectRegistry }
  }

  private async writeState(outputRoot: string, state: ProjectBatchRunState): Promise<void> {
    await atomicWriteJson(path.join(outputRoot, 'project-batches', state.batchId, 'state.json'), state)
    await atomicWriteJson(path.join(outputRoot, 'project-batches', 'latest.json'), { batchId: state.batchId })
  }
}
