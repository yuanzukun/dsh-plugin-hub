import { mkdir, rename, writeFile } from 'node:fs/promises'
import path from 'node:path'

import { PROJECT_DOCUMENT_PROTOCOL, PROJECT_SCAN_PROTOCOL, type ProjectDeterministicFacts, type ProjectSynthesisDraft, type ProjectSynthesisInputs, type ProjectSynthesisRecord, type ProjectValidationReport, type ProjectTemplate } from '../contracts/project-scan.js'
import type { ValidationIssue } from '../contracts/system-scan.js'
import type { LoadedProtocolPack } from '../protocol/catalog.js'
import { parseProtocolContract } from '../protocol/catalog.js'
import { markdownHeadings, metadataValues, validatePortableContent, validateSensitiveContent } from '../protocol/validation.js'
import { nonAtomicEvidencePaths } from '../system/evidence-paths.js'
import { deterministicClaimViolations } from './deterministic-facts.js'
import { systemEvidenceContainsQuote } from './system-evidence-quotes.js'

interface ProjectDocumentContract {
  metadata: Record<string, string[]>
  requiredMetadata: string[]
  templates: Record<ProjectTemplate, { label: string, titlePattern: string, headings: string[] }>
  requiredArtifacts: string[]
  rules: { maxDocumentCharacters: number, requiredEvidencePointer: string, requiredSystemPointer: string, minTrustedConclusionRows: number }
}

async function atomicWrite(file: string, content: string): Promise<void> {
  await mkdir(path.dirname(file), { recursive: true })
  const temp = file + '.' + process.pid + '.tmp'
  await writeFile(temp, content, 'utf8')
  await rename(temp, file)
}
async function atomicJson(file: string, value: unknown): Promise<void> { await atomicWrite(file, JSON.stringify(value, null, 2) + '\n') }

function replaceMetadata(content: string, key: string, value: string): string {
  const escaped = key.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&')
  const pattern = new RegExp('(^\\|\\s*' + escaped + '\\s*\\|)\\s*[^|]*\\|', 'mu')
  return content.replace(pattern, '$1 ' + value + ' |')
}

function normalize(content: string, input: ProjectSynthesisInputs, revision: string, validation: 'PASSED' | 'FAILED', gate: 'READY' | 'BLOCKED'): string {
  const sourceComplete = input.index.status === 'FRESH' && input.projectEvidence.status === 'COLLECTED' && input.projectEvidence.scopeStatus === 'CLEAN'
  const values: Record<string, string> = {
    '协议版本': PROJECT_DOCUMENT_PROTOCOL, '项目事实版本': revision,
    '文档状态': validation === 'PASSED' && sourceComplete ? '完整' : '草稿',
    '证据状态': sourceComplete ? '源码视角已完成，运行态待确认' : '证据不足',
    '下层门禁': gate, '校验状态': validation, '工程键': input.project.projectKey,
    '工程目录': input.project.projectDir, '系统事实版本': 'BOUND',
    '工程类型': input.projectEvidence.specialization + (input.projectEvidence.framework === undefined ? '' : ' / ' + input.projectEvidence.framework),
  }
  return Object.entries(values).reduce((result, [key, value]) => replaceMetadata(result, key, value), content)
}

function validateDiagram(name: string, content: string, pack: LoadedProtocolPack): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  if (!/^\s*(?:flowchart|graph)\s/iu.test(content) || content.includes('```') || content.length > 50000) {
    issues.push({ severity: 'ERROR', code: 'PROJECT_DIAGRAM_INVALID', message: name + ' must be Mermaid flowchart source without a fence.' })
  }
  if (!/(?:实线[^\n]*源码证据|源码证据[^\n]*实线)/u.test(content) || !/(?:虚线[^\n]*待确认|待确认[^\n]*虚线)/u.test(content) || !/不代表生产运行/u.test(content)) {
    issues.push({ severity: 'ERROR', code: 'PROJECT_DIAGRAM_LEGEND_MISSING', message: name + ' must explain evidence edge semantics.' })
  }
  issues.push(...validateSensitiveContent(content, pack, name + ' diagram'))
  issues.push(...validatePortableContent(content, name + ' diagram'))
  return issues
}

export function projectProfileBoundaryIssues(content: string): ValidationIssue[] {
  if (!/^\s*(?:flowchart|graph)\s/imu.test(content)) return []
  return [{
    severity: 'ERROR',
    code: 'PROJECT_PROFILE_EMBEDS_DIAGRAM',
    message: 'PROFILE must contain only the fixed project document; stage Mermaid sources only in the three diagram artifacts.',
  }]
}

function referencedIds(content: string, pattern: RegExp): Set<string> {
  return new Set([...content.matchAll(pattern)].flatMap(match => match[0] === undefined ? [] : [match[0]]))
}

function markdownCell(value: string): string { return value.replace(/\|/gu, '\\|').replace(/\r?\n/gu, ' ') }

function injectDeterministicStatistics(profile: string, facts: ProjectDeterministicFacts | undefined): string {
  if (facts === undefined) return profile
  const heading = '## 1.1 统计口径与覆盖范围'
  const start = profile.indexOf(heading)
  if (start < 0) return profile
  const afterHeading = start + heading.length
  const nextHeading = profile.slice(afterHeading).search(/\n## (?!#)/u)
  const end = nextHeading < 0 ? profile.length : afterHeading + nextHeading
  const rows = facts.metrics.map(metric => {
    const evidence = metric.evidencePaths.length === 0 ? '—' : metric.evidencePaths.slice(0, 3).map(item => `\`${item}\``).join('、')
    return `| ${metric.metricId} | ${markdownCell(metric.label)} | ${metric.value} | ${metric.unit} | ${markdownCell(metric.scope)} | ${markdownCell(metric.method)} | ${markdownCell(metric.exclusions)} | ${metric.completeness} | ${evidence} |`
  })
  const dependencyRows = (facts.moduleDependencies ?? []).map(dependency =>
    `| ${markdownCell(dependency.sourceModule)} | ${markdownCell(dependency.targetModule)} | ${dependency.scope} | ${dependency.optional ? '是' : '否'} | \`${dependency.sourceManifest}\` |`,
  )
  const dependencySection = dependencyRows.length === 0
    ? '工程内 Maven 模块依赖边：无机器确认记录。'
    : `工程内 Maven 模块依赖边（箭头方向为 source 依赖 target）：\n\n| Source module | Target module | Scope | Optional | 来源 POM |\n|---|---|---|---|---|\n${dependencyRows.join('\n')}`
  const gaps = facts.coverageGaps.length === 0 ? '无确定性扫描缺口。' : facts.coverageGaps.map(item => `- ${item}`).join('\n')
  const section = `${heading}\n\n> 本节由父协调器依据 \`deterministic-facts.json\` 生成；Writer 不拥有这些数量或 Maven 模块依赖方向。扫描状态：${facts.scanStatus}，扫描文件 ${facts.scannedFileCount}，跳过 ${facts.skippedFileCount}。\n\n| Metric ID | 指标 | 数值 | 单位 | 范围 | 方法 | 排除项 | 完整性 | 证据样本 |\n|---|---|---:|---|---|---|---|---|---|\n${rows.join('\n')}\n\n${dependencySection}\n\n覆盖缺口：\n${gaps}\n`
  return profile.slice(0, start) + section + profile.slice(end)
}

function validateSemanticReferences(profile: string, input: ProjectSynthesisInputs): ValidationIssue[] {
  const issues: ValidationIssue[] = []
  const expectedConflicts = new Set(input.projectEvidence.conflicts.map(conflict => conflict.conflictId))
  const profileConflicts = referencedIds(profile, /\bPC-[a-z0-9]+\b/giu)
  const unknownConflicts = [...profileConflicts].filter(id => !expectedConflicts.has(id))
  const missingConflicts = [...expectedConflicts].filter(id => !profileConflicts.has(id))
  if (unknownConflicts.length > 0) issues.push({ severity: 'ERROR', code: 'PROJECT_CONFLICT_REFERENCE_UNKNOWN', message: 'Project profile references unknown conflict IDs: ' + unknownConflicts.join(', ') + '.' })
  if (missingConflicts.length > 0) issues.push({ severity: 'ERROR', code: 'PROJECT_CONFLICT_REFERENCE_MISSING', message: 'Project profile does not present all structured conflicts: ' + missingConflicts.join(', ') + '.' })

  const knownRelations = new Set(input.relatedRelations.map(relation => relation.relationId))
  const unknownRelations = [...referencedIds(profile, /\bREL-[a-z0-9]+\b/giu)].filter(id => !knownRelations.has(id))
  if (unknownRelations.length > 0) issues.push({ severity: 'ERROR', code: 'PROJECT_RELATION_REFERENCE_UNKNOWN', message: 'Project profile references unknown relation IDs: ' + unknownRelations.join(', ') + '.' })

  for (const conflict of input.projectEvidence.conflicts) {
    const matches = conflict.systemEvidencePointer === 'SYSTEM_EVIDENCE'
      ? systemEvidenceContainsQuote(input.systemEvidence, conflict.systemEvidenceQuote)
      : input.sourceSystemFactBase.includes(conflict.systemEvidenceQuote)
    if (!matches) {
      issues.push({ severity: 'ERROR', code: 'PROJECT_CONFLICT_SYSTEM_EVIDENCE_INVALID', message: conflict.conflictId + ' does not quote its bound ' + conflict.systemEvidencePointer + ' input exactly.' })
    }
  }

  const evidenceGroups = [
    input.projectEvidence.identity, input.projectEvidence.technology, input.projectEvidence.buildAndRun,
    input.projectEvidence.configuration, input.projectEvidence.entrypoints, input.projectEvidence.dependencies,
    input.projectEvidence.dataAssets, input.projectEvidence.structure, input.projectEvidence.security,
    input.projectEvidence.observability, input.projectEvidence.deployment, input.projectEvidence.tests,
    input.projectEvidence.capabilities, input.projectEvidence.dataFlows, input.projectEvidence.chainCandidates,
    input.projectEvidence.risks, input.projectEvidence.constraints, input.projectEvidence.coverageGaps,
    input.projectEvidence.moduleCandidates,
  ]
  const knownPaths = new Set([
    ...input.projectEvidence.evidencePaths,
    ...evidenceGroups.flatMap(items => items.flatMap(item => item.evidencePaths)),
    ...input.projectEvidence.statistics.flatMap(item => item.evidencePaths),
    ...input.projectEvidence.conflicts.flatMap(item => item.evidencePaths),
    ...input.systemEvidence.evidencePaths,
    ...(input.systemEvidence.relationCandidates ?? []).flatMap(item => item.evidencePaths),
    ...input.relatedRelations.flatMap(item => item.evidencePaths),
    ...(input.deterministicFacts?.moduleManifests ?? []),
    ...(input.deterministicFacts?.moduleDependencies?.flatMap(item => [item.sourceManifest, item.targetManifest]) ?? []),
    ...(input.deterministicFacts?.configurationFiles ?? []),
    ...(input.deterministicFacts?.metrics.flatMap(metric => metric.evidencePaths) ?? []),
  ])
  const generatedPointers = new Set(['evidence.json', 'deterministic-facts.json', 'conflicts.json', 'input.json', 'validation.json', 'synthesis.json'])
  const invalidCitations: string[] = []
  for (const match of profile.matchAll(/`([^`\r\n]+)`/gu)) {
    const citation = match[1]?.trim()
    const looksLikeFile = citation !== undefined && (
      /\.(?:java|kt|kts|swift|m|mm|xml|ya?ml|json|properties|gradle|toml|md)$/iu.test(citation)
      || (!citation.startsWith('/') && /^[A-Za-z0-9_.-]+\/\S+$/u.test(citation))
    )
    if (!citation || !looksLikeFile) continue
    if (/[*?{}]|:\d+(?::\d+)?$/u.test(citation)) invalidCitations.push(citation)
    else if (!knownPaths.has(citation) && !generatedPointers.has(citation)) invalidCitations.push(citation)
  }
  if (invalidCitations.length > 0) issues.push({ severity: 'ERROR', code: 'PROJECT_PROFILE_EVIDENCE_CITATION_INVALID', message: 'Project profile contains non-atomic or unrecognized evidence citations: ' + [...new Set(invalidCitations)].slice(0, 10).join(', ') + '.' })
  return issues
}

function validateDeterministicClaims(content: string, facts: ProjectDeterministicFacts | undefined, artifact: string): ValidationIssue[] {
  if (facts === undefined) return []
  const issues: ValidationIssue[] = []
  const stageArtifact = artifact === 'project profile' ? 'PROFILE' : artifact === 'projectContext diagram' ? 'PROJECT_CONTEXT_DIAGRAM' : artifact === 'structure diagram' ? 'STRUCTURE_DIAGRAM' : 'ENTRY_DEPENDENCY_DIAGRAM'
  for (const violation of deterministicClaimViolations(content, facts)) {
    const line = content.slice(0, violation.index).split(/\r?\n/gu).length
    const excerpt = violation.matchedText.replace(/\s+/gu, ' ').trim().slice(0, 160)
    const repair = violation.ruleId === 'SPRING-NO-LOCAL-CONFIG'
      ? 'Replace the absence wording with the deterministic file-existence fact; describe unread configuration content or runtime values as unverified, not absent.'
      : `Replace the absence or uniqueness wording with the machine-owned ${violation.claim} fact.`
    issues.push({ severity: 'ERROR', code: 'PROJECT_NEGATIVE_CLAIM_UNSUPPORTED', message: `${artifact} line ${line} violates ${violation.ruleId}: ${violation.reason}. Exact matched text: “${excerpt}”. Restage ${stageArtifact}. ${repair}` })
  }
  const values = new Map(facts.metrics.map(metric => [metric.metricId, metric.value]))
  const families: Array<{ id: string, pattern: RegExp, metrics: string[], units: Set<string> }> = [
    { id: 'CONTROLLER', pattern: /@(?:Rest)?Controller\b|Controller(?:文件|类|注解|数量|数)?(?=$|[\s，。：；、/)|\]])|控制器/giu, metrics: ['SPRING-CONTROLLER-NAMED-FILES', 'SPRING-CONTROLLER-ANNOTATED-FILES', 'SPRING-CONTROLLER-ANNOTATIONS'], units: new Set(['个', '处', '份', '文件', '类', '声明', '注解', 'file', 'files', 'class', 'classes', 'occurrence', 'occurrences']) },
    { id: 'MAPPER_XML', pattern: /Mapper(?:\s*XML|\.xml)/giu, metrics: ['SPRING-MAPPER-XML-FILES'], units: new Set(['个', '份', '文件', 'file', 'files']) },
    { id: 'DATA_SOURCE', pattern: /@DS\b/giu, metrics: ['SPRING-DS-ANNOTATED-FILES', 'SPRING-DS-ANNOTATIONS'], units: new Set(['个', '处', '份', '文件', '声明', '注解', 'file', 'files', 'occurrence', 'occurrences']) },
    { id: 'FEIGN', pattern: /@FeignClient\b/giu, metrics: ['SPRING-FEIGN-ANNOTATED-FILES', 'SPRING-FEIGN-ANNOTATIONS'], units: new Set(['个', '处', '份', '文件', '接口', '声明', '注解', 'file', 'files', 'occurrence', 'occurrences']) },
    { id: 'XXL_JOB', pattern: /@XxlJob\b/giu, metrics: ['SPRING-XXLJOB-ANNOTATED-FILES', 'SPRING-XXLJOB-ANNOTATIONS'], units: new Set(['个', '处', '份', '文件', '声明', '注解', 'file', 'files', 'occurrence', 'occurrences']) },
    { id: 'SCHEDULED', pattern: /@Scheduled\b/giu, metrics: ['SPRING-SCHEDULED-ANNOTATED-FILES', 'SPRING-SCHEDULED-ANNOTATIONS'], units: new Set(['个', '处', '份', '文件', '声明', '注解', 'file', 'files', 'occurrence', 'occurrences']) },
    { id: 'KAFKA', pattern: /@KafkaListener\b/giu, metrics: ['SPRING-KAFKA-LISTENER-FILES', 'SPRING-KAFKA-LISTENER-ANNOTATIONS'], units: new Set(['个', '处', '份', '文件', '声明', '注解', 'file', 'files', 'occurrence', 'occurrences']) },
    { id: 'RABBIT', pattern: /@RabbitListener\b/giu, metrics: ['SPRING-RABBIT-LISTENER-FILES', 'SPRING-RABBIT-LISTENER-ANNOTATIONS'], units: new Set(['个', '处', '份', '文件', '声明', '注解', 'file', 'files', 'occurrence', 'occurrences']) },
    { id: 'LOCAL_CONFIG', pattern: /(?:ya?ml|properties|logback|bootstrap|application|本地配置文件)/giu, metrics: ['SPRING-CONFIG-FILES'], units: new Set(['个', '份', '文件', 'file', 'files']) },
  ]
  const distance = (left: { index: number, end: number }, right: { index: number, end: number }) => Math.max(0, left.index - right.end, right.index - left.end)
  for (const [lineIndex, line] of content.split(/\r?\n/gu).entries()) {
    const deterministicTableRow = /^\|\s*SPRING-[A-Z0-9-]+\s*\|/u.test(line)
    for (const metric of facts.metrics) {
      if (!line.includes(metric.metricId)) continue
      if (deterministicTableRow) continue
      if (!new RegExp(`(?:^|\\D)${metric.value}(?:\\D|$)`, 'u').test(line)) {
        issues.push({ severity: 'ERROR', code: 'PROJECT_DETERMINISTIC_METRIC_MISMATCH', message: `${artifact} line ${lineIndex + 1} references ${metric.metricId} without its machine-owned value ${metric.value}.` })
      }
    }
    if (deterministicTableRow) continue
    const unitCounts = [...line.matchAll(/(\d[\d,]*)\s*(个|处|份|文件|类|接口|声明|注解|files?|classes?|occurrences?)/giu)].flatMap(match => {
      if (match.index === undefined || match[1] === undefined || match[2] === undefined) return []
      return [{ value: Number(match[1].replace(/,/gu, '')), unit: match[2].toLowerCase(), index: match.index, end: match.index + match[0].length }]
    })
    const namedCounts = [...line.matchAll(/(?:数量|共计|合计|约)\s*[:=：]?\s*(\d[\d,]*)/giu)].flatMap(match => {
      if (match.index === undefined || match[1] === undefined) return []
      return [{ value: Number(match[1].replace(/,/gu, '')), unit: '', index: match.index, end: match.index + match[0].length }]
    })
    for (const family of families) {
      const mentions = [...line.matchAll(family.pattern)].flatMap(match => match.index === undefined ? [] : [{ index: match.index, end: match.index + match[0].length }])
      if (mentions.length === 0) continue
      const allowed = family.metrics.flatMap(metricId => values.has(metricId) ? [values.get(metricId) as number] : [])
      const claims = [...unitCounts.filter(item => family.units.has(item.unit)), ...namedCounts]
        .filter(count => mentions.some(mention => distance(count, mention) <= 24))
      const invalid = claims.find(claim => !allowed.includes(claim.value))
      if (allowed.length === 0 || invalid === undefined) continue
      issues.push({ severity: 'ERROR', code: 'PROJECT_DETERMINISTIC_METRIC_MISMATCH', message: `${artifact} line ${lineIndex + 1} has an unowned ${family.id} count ${invalid.value}; allowed deterministic values: ${[...new Set(allowed)].join(', ')}.` })
    }
  }
  return issues
}

function moduleDependencyDiagramIssues(content: string, facts: ProjectDeterministicFacts | undefined): ValidationIssue[] {
  const moduleDependencies = facts?.moduleDependencies ?? []
  if (moduleDependencies.length === 0) return []
  const modules = [...new Set(moduleDependencies.flatMap(item => [item.sourceModule, item.targetModule]))]
  const suffixes = new Map<string, string[]>()
  for (const module of modules) {
    const suffix = module.split('-').at(-1)?.toLowerCase() ?? module.toLowerCase()
    suffixes.set(suffix, [...(suffixes.get(suffix) ?? []), module])
  }
  const aliases = new Map<string, string>()
  for (const line of content.split(/\r?\n/gu)) {
    const node = /^\s*([A-Za-z][\w-]*)\s*[\[({]([^\n]*)/u.exec(line)
    if (node?.[1] === undefined || node[2] === undefined) continue
    const nodeId = node[1]
    const haystack = `${nodeId} ${node[2]}`.toLowerCase()
    const exact = modules.find(module => haystack.includes(module.toLowerCase()))
    if (exact !== undefined) { aliases.set(nodeId, exact); continue }
    const suffix = [...suffixes].find(([candidate, owners]) => owners.length === 1 && new RegExp(`(?:^|[^a-z0-9])${candidate}(?:[^a-z0-9]|$)`, 'u').test(haystack))
    if (suffix !== undefined) aliases.set(nodeId, suffix[1][0] as string)
  }
  const observed = new Set<string>()
  const invalid: string[] = []
  const allowed = new Set(moduleDependencies.map(item => `${item.sourceModule}\0${item.targetModule}`))
  for (const line of content.split(/\r?\n/gu)) {
    const edge = /^\s*([A-Za-z][\w-]*)\s+.*?(?:-->|==>|\.->)\s*(?:\|[^|]*\|\s*)?([A-Za-z][\w-]*)\b/u.exec(line)
    if (edge?.[1] === undefined || edge[2] === undefined) continue
    const source = aliases.get(edge[1])
    const target = aliases.get(edge[2])
    if (source === undefined || target === undefined || source === target) continue
    const key = `${source}\0${target}`
    observed.add(key)
    if (!allowed.has(key)) invalid.push(`${source} -> ${target}`)
  }
  const issues: ValidationIssue[] = []
  if (invalid.length > 0) issues.push({ severity: 'ERROR', code: 'PROJECT_MODULE_DEPENDENCY_MISMATCH', message: 'structure diagram contains Maven module dependency edges not owned by DETERMINISTIC_FACTS: ' + [...new Set(invalid)].join(', ') + '.' })
  if (new Set(aliases.values()).size === modules.length) {
    const missing = [...allowed].filter(edge => !observed.has(edge)).map(edge => edge.replace('\0', ' -> '))
    if (missing.length > 0) issues.push({ severity: 'ERROR', code: 'PROJECT_MODULE_DEPENDENCY_MISSING', message: 'structure diagram omits machine-owned Maven module dependency edges: ' + missing.join(', ') + '.' })
  }
  return issues
}

export function prepareProjectArtifacts(input: ProjectSynthesisInputs, generatedAt: string, pack: LoadedProtocolPack, draft: ProjectSynthesisDraft, revision = 'PENDING', sourceSystemRevision = 'UNKNOWN'): { profile: string, validation: ProjectValidationReport } {
  const contract = parseProtocolContract<ProjectDocumentContract>(pack, 'archscope/contract/project-document/v1')
  const issues: ValidationIssue[] = []
  if (input.index.status !== 'FRESH') issues.push({ severity: 'ERROR', code: 'PROJECT_INDEX_NOT_FRESH', message: 'Project index must be FRESH.' })
  if (input.projectEvidence.status !== 'COLLECTED') issues.push({ severity: 'ERROR', code: 'PROJECT_EVIDENCE_INCOMPLETE', message: 'Project evidence was not collected.' })
  if (input.projectEvidence.scopeStatus !== 'CLEAN' || input.projectEvidence.scopeViolations.length > 0) issues.push({ severity: 'ERROR', code: 'PROJECT_SCOPE_VIOLATION', message: 'Project evidence crossed its project boundary.' })
  if (nonAtomicEvidencePaths(input.projectEvidence.evidencePaths).length > 0) issues.push({ severity: 'ERROR', code: 'PROJECT_EVIDENCE_PATH_INVALID', message: 'Project evidence contains non-atomic paths.' })
  if (input.projectEvidence.specializationDecision.template !== input.projectEvidence.template
    || input.projectEvidence.specializationDecision.specialization !== input.projectEvidence.specialization) {
    issues.push({ severity: 'ERROR', code: 'PROJECT_SPECIALIZATION_MISMATCH', message: 'Project evidence specialization does not match the deterministic parent decision.' })
  }
  const conflictCount = input.projectEvidence.conflicts.length
  const blockingConflictCount = input.projectEvidence.conflicts.filter(conflict => conflict.severity === 'BLOCKING').length
  const reconciliationStatus = blockingConflictCount > 0
    ? 'BLOCKED' as const
    : input.projectEvidence.conflicts.some(conflict => conflict.reconciliationStatus === 'OPEN')
      ? 'OPEN' as const
      : 'NOT_REQUIRED' as const
  const preliminary = issues.some(issue => issue.severity === 'ERROR') ? 'FAILED' : 'PASSED'
  let profile = normalize(draft.profile, input, revision, preliminary, preliminary === 'PASSED' && blockingConflictCount === 0 ? 'READY' : 'BLOCKED')
  profile = replaceMetadata(profile, '系统事实版本', sourceSystemRevision)
  profile = injectDeterministicStatistics(profile, input.deterministicFacts)
  const template = contract.templates[input.projectEvidence.template]
  const title = profile.split(/\r?\n/u)[0]?.trim() ?? ''
  if (!new RegExp(template.titlePattern, 'u').test(title)) issues.push({ severity: 'ERROR', code: 'PROJECT_TITLE_INVALID', message: 'Project title does not match the selected ' + input.projectEvidence.template + ' template.' })
  const expectedHeadings = template.headings
  const actualHeadings = markdownHeadings(profile)
  if (JSON.stringify(actualHeadings) !== JSON.stringify(expectedHeadings)) {
    const mismatch = Array.from({ length: Math.max(expectedHeadings.length, actualHeadings.length) }, (_value, index) => index)
      .find(index => expectedHeadings[index] !== actualHeadings[index]) ?? 0
    issues.push({
      severity: 'ERROR', code: 'PROJECT_HEADINGS_INVALID',
      message: 'Project headings differ from the ' + input.projectEvidence.template + ' template at position ' + (mismatch + 1)
        + ': expected ' + JSON.stringify(expectedHeadings[mismatch] ?? '<end>')
        + ', received ' + JSON.stringify(actualHeadings[mismatch] ?? '<end>') + '.',
    })
  }
  const metadata = metadataValues(profile, [...Object.keys(contract.metadata), ...contract.requiredMetadata])
  for (const [key, allowed] of Object.entries(contract.metadata)) {
    const value = metadata[key]
    if (value === undefined) issues.push({ severity: 'ERROR', code: 'PROJECT_METADATA_MISSING', message: 'Missing project metadata row: ' + key + '.' })
    else if (key === '项目事实版本' ? !/^(?:PENDING|P\d{4,})$/u.test(value) : !allowed.includes(value)) issues.push({ severity: 'ERROR', code: 'PROJECT_METADATA_INVALID', message: 'Invalid project metadata ' + key + '=' + value + '.' })
  }
  for (const key of contract.requiredMetadata) if (!metadata[key]) issues.push({ severity: 'ERROR', code: 'PROJECT_METADATA_MISSING', message: 'Missing project metadata row: ' + key + '.' })
  if (profile.length > contract.rules.maxDocumentCharacters) issues.push({ severity: 'ERROR', code: 'PROJECT_DOCUMENT_TOO_LARGE', message: 'Project profile exceeds the protocol character limit.' })
  issues.push(...projectProfileBoundaryIssues(profile))
  if (!profile.includes(contract.rules.requiredEvidencePointer)) issues.push({ severity: 'ERROR', code: 'PROJECT_EVIDENCE_POINTER_MISSING', message: 'Project profile must point to evidence.json.' })
  if (!profile.includes(contract.rules.requiredSystemPointer)) issues.push({ severity: 'ERROR', code: 'PROJECT_SYSTEM_POINTER_MISSING', message: 'Project profile must bind its system fact revision.' })
  issues.push(...validateSemanticReferences(profile, input))
  issues.push(...validateDeterministicClaims(profile, input.deterministicFacts, 'project profile'))
  issues.push(...validateSensitiveContent(profile, pack, 'project profile'))
  issues.push(...validatePortableContent(profile, 'project profile'))
  issues.push(...validateDiagram('projectContext', draft.diagrams.projectContext, pack), ...validateDiagram('structure', draft.diagrams.structure, pack), ...validateDiagram('entryDependency', draft.diagrams.entryDependency, pack))
  issues.push(...validateDeterministicClaims(draft.diagrams.projectContext, input.deterministicFacts, 'projectContext diagram'))
  issues.push(...validateDeterministicClaims(draft.diagrams.structure, input.deterministicFacts, 'structure diagram'))
  issues.push(...validateDeterministicClaims(draft.diagrams.entryDependency, input.deterministicFacts, 'entryDependency diagram'))
  issues.push(...moduleDependencyDiagramIssues(draft.diagrams.structure, input.deterministicFacts))
  const status = issues.some(issue => issue.severity === 'ERROR') ? 'FAILED' : 'PASSED'
  const gate = status === 'PASSED' && blockingConflictCount === 0 ? 'READY' : 'BLOCKED'
  profile = normalize(profile, input, revision, status, gate)
  profile = replaceMetadata(profile, '系统事实版本', sourceSystemRevision)
  return { profile, validation: { protocolVersion: PROJECT_SCAN_PROTOCOL, protocol: { packId: pack.lock.packId, version: pack.lock.version, digest: pack.lock.packDigest }, generatedAt, status, gate, conflictCount, blockingConflictCount, reconciliationStatus, issues } }
}

export async function writeProjectArtifacts(options: { outputRoot: string, projectKey: string, input: ProjectSynthesisInputs, draft: ProjectSynthesisDraft, profile: string, validation: ProjectValidationReport, synthesis: ProjectSynthesisRecord, protocolLock: LoadedProtocolPack['lock'], publishCurrent: boolean }): Promise<void> {
  const runRoot = path.join(options.outputRoot, 'runs', options.synthesis.runId, 'project')
  const attemptRoot = path.join(runRoot, 'attempts', 'attempt-' + options.synthesis.attempt)
  const writeSet = async (root: string) => {
    await Promise.all([
      atomicWrite(path.join(root, '00-project-profile.md'), options.profile),
      atomicJson(path.join(root, 'evidence.json'), options.input.projectEvidence),
      ...(options.input.deterministicFacts === undefined ? [] : [atomicJson(path.join(root, 'deterministic-facts.json'), options.input.deterministicFacts)]),
      atomicJson(path.join(root, 'conflicts.json'), { sourceSystemRevision: options.synthesis.sourceSystemRevision, reconciliationStatus: options.validation.reconciliationStatus, conflicts: options.input.projectEvidence.conflicts }),
      atomicJson(path.join(root, 'input.json'), { project: options.input.project, index: options.input.index, systemEvidence: options.input.systemEvidence, relatedRelations: options.input.relatedRelations, deterministicFacts: options.input.deterministicFacts }),
      atomicJson(path.join(root, 'protocol-lock.json'), options.protocolLock), atomicJson(path.join(root, 'validation.json'), options.validation), atomicJson(path.join(root, 'synthesis.json'), options.synthesis),
      atomicWrite(path.join(root, 'diagrams', '01-project-context.mmd'), options.draft.diagrams.projectContext),
      atomicWrite(path.join(root, 'diagrams', '02-structure-overview.mmd'), options.draft.diagrams.structure),
      atomicWrite(path.join(root, 'diagrams', '03-entry-dependency.mmd'), options.draft.diagrams.entryDependency),
    ])
  }
  await writeSet(attemptRoot)
  await writeSet(runRoot)
  if (options.publishCurrent) await writeSet(path.join(options.outputRoot, 'projects', options.projectKey))
}
