export function nestedStringValues(value: unknown): string[] {
  const output: string[] = []
  const pending: unknown[] = [value]
  const visited = new Set<object>()
  while (pending.length > 0) {
    const current = pending.pop()
    if (typeof current === 'string') output.push(current)
    else if (typeof current === 'object' && current !== null && !visited.has(current)) {
      visited.add(current)
      pending.push(...(Array.isArray(current) ? current : Object.values(current)))
    }
  }
  return output
}

export function systemEvidenceContainsQuote(systemEvidence: unknown, quote: string): boolean {
  return quote !== '' && nestedStringValues(systemEvidence).some(value => value.includes(quote))
}
