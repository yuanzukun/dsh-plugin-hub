import { readFile } from 'node:fs/promises'
import path from 'node:path'

import { PROJECT_SCAN_PROTOCOL } from '../contracts/project-scan.js'
import { atomicWriteJson } from '../system/artifacts.js'

export type ProjectProtocolPhase = 'EVIDENCE' | 'WRITER'
export const PROJECT_EVIDENCE_CONTEXT_RESOURCE_ID = 'archscope/runtime/project-evidence-context/v1'

export interface ProjectProtocolReadRecord {
  phase: ProjectProtocolPhase
  resourceId: string
  version: string
  digest: string
  readAt: string
}

export interface ProjectProtocolReadLedger {
  protocolVersion: typeof PROJECT_SCAN_PROTOCOL
  runId: string
  updatedAt: string
  reads: ProjectProtocolReadRecord[]
}

function ledgerPath(outputRoot: string, runId: string): string {
  return path.join(outputRoot, 'runs', runId, 'project', 'protocol-read-ledger.json')
}

const ledgerWrites = new Map<string, Promise<void>>()

export async function readProjectProtocolLedger(outputRoot: string, runId: string): Promise<ProjectProtocolReadLedger> {
  try {
    const parsed = JSON.parse(await readFile(ledgerPath(outputRoot, runId), 'utf8')) as ProjectProtocolReadLedger
    if (parsed.protocolVersion !== PROJECT_SCAN_PROTOCOL || parsed.runId !== runId || !Array.isArray(parsed.reads)) throw new Error('Malformed project protocol read ledger.')
    return parsed
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      return { protocolVersion: PROJECT_SCAN_PROTOCOL, runId, updatedAt: new Date(0).toISOString(), reads: [] }
    }
    throw error
  }
}

export async function recordProjectProtocolRead(outputRoot: string, runId: string, record: ProjectProtocolReadRecord): Promise<void> {
  const key = ledgerPath(outputRoot, runId)
  const previous = ledgerWrites.get(key)
  const current = (async () => {
    await previous?.catch(() => undefined)
    const ledger = await readProjectProtocolLedger(outputRoot, runId)
    const reads = [...ledger.reads.filter(item => item.phase !== record.phase || item.resourceId !== record.resourceId), record]
      .sort((left, right) => left.phase.localeCompare(right.phase) || left.resourceId.localeCompare(right.resourceId))
    await atomicWriteJson(key, { ...ledger, updatedAt: record.readAt, reads })
  })()
  ledgerWrites.set(key, current)
  try {
    await current
  } finally {
    if (ledgerWrites.get(key) === current) ledgerWrites.delete(key)
  }
}

export async function assertProjectProtocolReads(outputRoot: string, runId: string, phase: ProjectProtocolPhase, requiredResources: Array<{ id: string, version: string, digest: string }>): Promise<void> {
  const ledger = await readProjectProtocolLedger(outputRoot, runId)
  const reads = ledger.reads.filter(item => item.phase === phase)
  const missing = requiredResources.filter(resource => !reads.some(item => item.resourceId === resource.id && item.version === resource.version && item.digest === resource.digest))
    .map(resource => resource.id + '@' + resource.version)
  if (missing.length > 0) throw new Error('Project ' + phase.toLowerCase() + ' agent did not load required protocol resources: ' + missing.join(', ') + '.')
}
