import { createHash } from 'node:crypto'

import {
  PROJECT_SCAN_PROTOCOL,
  type ProjectSynthesisDataset,
  type ProjectSynthesisInputs,
  type ProjectSynthesisPage,
  type ProjectSynthesisReadLedger,
  type ProjectSynthesisReadManifest,
} from '../contracts/project-scan.js'

export const PROJECT_SYNTHESIS_PAGE_MAX_BYTES = 20 * 1024
export const PROJECT_SYNTHESIS_DATASETS: ProjectSynthesisDataset[] = [
  'SYSTEM_FACT_BASE',
  'PROJECT_IDENTITY',
  'SYSTEM_RELATIONS',
  'PROJECT_EVIDENCE',
  'DETERMINISTIC_FACTS',
]

interface SourceRecord {
  key: string
  json: string
}

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex')
}

function sources(dataset: ProjectSynthesisDataset, input: ProjectSynthesisInputs): SourceRecord[] {
  if (dataset === 'SYSTEM_FACT_BASE') {
    return [{ key: 'system-fact-base', json: JSON.stringify({ markdown: input.sourceSystemFactBase }) }]
  }
  if (dataset === 'PROJECT_IDENTITY') {
    return [{
      key: input.project.projectKey,
      json: JSON.stringify({ project: input.project, index: input.index, systemEvidence: input.systemEvidence }),
    }]
  }
  if (dataset === 'SYSTEM_RELATIONS') {
    return input.relatedRelations.map(relation => ({ key: relation.relationId, json: JSON.stringify(relation) }))
  }
  if (dataset === 'DETERMINISTIC_FACTS') {
    return input.deterministicFacts === undefined
      ? []
      : [{ key: input.project.projectKey, json: JSON.stringify(input.deterministicFacts) }]
  }
  return [{ key: input.project.projectKey, json: JSON.stringify(input.projectEvidence) }]
}

function serialized(records: SourceRecord[]): string {
  return '[' + records.map(record => record.json).join(',') + ']'
}

function parseCursor(cursor: string): { recordIndex: number, byteOffset: number } {
  const match = /^(\d+):(\d+)$/u.exec(cursor)
  if (match === null) throw new Error('Invalid ArchScope project synthesis page cursor: ' + cursor)
  return { recordIndex: Number(match[1]), byteOffset: Number(match[2]) }
}

function utf8Prefix(value: string, maxBytes: number): string {
  let bytes = 0
  let result = ''
  for (const character of value) {
    const size = Buffer.byteLength(character, 'utf8')
    if (bytes + size > maxBytes) break
    result += character
    bytes += size
  }
  return result
}

export function buildProjectSynthesisReadManifest(
  inputDigest: string,
  input: ProjectSynthesisInputs,
  ledger?: ProjectSynthesisReadLedger,
): ProjectSynthesisReadManifest {
  return {
    inputDigest,
    pageMaxBytes: PROJECT_SYNTHESIS_PAGE_MAX_BYTES,
    datasets: PROJECT_SYNTHESIS_DATASETS.map(dataset => {
      const records = sources(dataset, input)
      const value = serialized(records)
      const state = ledger?.datasets.find(candidate => candidate.dataset === dataset)
      return {
        dataset,
        totalRecords: records.length,
        totalBytes: Buffer.byteLength(value, 'utf8'),
        globalDigest: sha256(value),
        nextCursor: state === undefined ? (records.length === 0 ? null : '0:0') : state.nextCursor,
        complete: state?.complete ?? records.length === 0,
      }
    }),
  }
}

export function createProjectSynthesisReadLedger(
  runId: string,
  protocolDigest: string,
  manifest: ProjectSynthesisReadManifest,
  now = new Date().toISOString(),
): ProjectSynthesisReadLedger {
  return {
    protocolVersion: PROJECT_SCAN_PROTOCOL,
    runId,
    protocolDigest,
    inputDigest: manifest.inputDigest,
    pageMaxBytes: manifest.pageMaxBytes,
    createdAt: now,
    updatedAt: now,
    datasets: manifest.datasets.map(dataset => ({
      dataset: dataset.dataset,
      globalDigest: dataset.globalDigest,
      totalRecords: dataset.totalRecords,
      nextCursor: dataset.nextCursor,
      coveredRecordKeys: [],
      pageDigests: [],
      complete: dataset.complete,
    })),
  }
}

export function buildProjectSynthesisPage(
  runId: string,
  protocolDigest: string,
  dataset: ProjectSynthesisDataset,
  cursor: string,
  input: ProjectSynthesisInputs,
): ProjectSynthesisPage {
  const records = sources(dataset, input)
  let { recordIndex, byteOffset } = parseCursor(cursor)
  if (recordIndex > records.length || (recordIndex === records.length && byteOffset !== 0)) {
    throw new Error('ArchScope project synthesis page cursor is outside ' + dataset + '.')
  }
  const items: ProjectSynthesisPage['items'] = []
  let pageBytes = 0
  while (recordIndex < records.length && pageBytes < PROJECT_SYNTHESIS_PAGE_MAX_BYTES) {
    const record = records[recordIndex] as SourceRecord
    const recordBuffer = Buffer.from(record.json, 'utf8')
    const fullBytes = recordBuffer.byteLength
    if (byteOffset > fullBytes) throw new Error('ArchScope project synthesis cursor is outside record ' + record.key + '.')
    const remaining = byteOffset === 0 ? record.json : recordBuffer.subarray(byteOffset).toString('utf8')
    const chunk = utf8Prefix(remaining, PROJECT_SYNTHESIS_PAGE_MAX_BYTES - pageBytes)
    if (chunk === '') break
    const chunkBytes = Buffer.byteLength(chunk, 'utf8')
    const completeRecord = byteOffset + chunkBytes === fullBytes
    items.push({
      recordKey: record.key,
      recordDigest: sha256(record.json),
      json: chunk,
      byteOffset,
      totalBytes: fullBytes,
      completeRecord,
    })
    pageBytes += chunkBytes
    if (completeRecord) {
      recordIndex += 1
      byteOffset = 0
    } else {
      byteOffset += chunkBytes
      break
    }
  }
  const complete = recordIndex === records.length
  const nextCursor = complete ? null : String(recordIndex) + ':' + String(byteOffset)
  return {
    runId,
    protocolDigest,
    dataset,
    cursor,
    nextCursor,
    pageDigest: sha256(JSON.stringify({ dataset, cursor, nextCursor, items })),
    globalDigest: sha256(serialized(records)),
    pageBytes,
    pageRecordCount: items.filter(item => item.completeRecord).length,
    coveredRecordCount: recordIndex,
    totalRecords: records.length,
    complete,
    items,
  }
}
