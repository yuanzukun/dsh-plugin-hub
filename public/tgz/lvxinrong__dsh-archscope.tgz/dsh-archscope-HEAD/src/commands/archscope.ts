import type { CommandDefinition, CommandResult } from '@deepseek-ai/dsh-commands'
import { createUserMessage } from '@deepseek-ai/dsh-llm'
import type { ToolExecutionInput } from '@deepseek-ai/dsh-tools'

import type { ProjectBatchProgress, ProjectBatchResult, ProjectScanProgress, ProjectScanResult } from '../contracts/project-scan.js'
import type { SystemScanProgress, SystemScanResult } from '../contracts/system-scan.js'
import type { ArchScopeIntent, ArchScopeIntentParseResult } from '../intents.js'
import { createProjectBatchMessage, createProjectScanMessage, projectProfileArtifactPath } from '../tools/project-scan.js'
import { createSystemScanMessage } from '../tools/system-scan.js'

const SUBCOMMAND_ALIASES = new Map<string, string>([
  ['system', 'system'],
  ['系统级扫描', 'system'],
  ['project', 'project'],
  ['项目级扫描', 'project'],
  ['projects', 'projects'],
  ['项目级批量扫描', 'projects'],
  ['resume', 'resume'],
  ['继续', 'resume'],
  ['help', 'help'],
  ['帮助', 'help'],
])

export const ARCHSCOPE_COMMAND_HELP = `ArchScope · 证据驱动的系统架构勘察

系统级定世界观，项目级定工程画像，模块级定职责边界，代码级定执行链路。

当前可用：
  /archscope system            扫描当前 DSH 工作区，并复用已有代码智能索引
  /archscope system --refresh  扫描当前 DSH 工作区，并强制刷新全部工程索引
  /archscope project <工程键>   基于系统事实底座深挖单个工程画像
  /archscope project <工程键> --refresh  刷新该工程索引后重新扫描
  /archscope projects --all    并行扫描系统注册表中的全部合格工程
  /archscope projects <工程键...>  并行扫描指定的一组工程
  /archscope help              显示本指南；直接输入 /archscope 效果相同

运行说明：
  - 系统扫描会自动发现工程、准备索引、采集证据并持续汇报进度
  - 单项目与多项目使用同一批处理执行器；每个工程由隔离的取证 Agent 和写作 Agent 完成，当前主 Agent 只接收聚合结果
  - 普通扫描优先复用索引；只有确实需要重建索引时才使用 --refresh
  - DSH 当前无法在空白新会话中执行 Slash Command；请先选择已有会话，或发送普通消息创建会话

规划中：失败恢复、模块级分析与代码链路追踪。`

function failure(message: string): ArchScopeIntentParseResult {
  return { ok: false, error: `${message}\n\n${ARCHSCOPE_COMMAND_HELP}` }
}

function parseRefreshArguments(args: string[], usage: string): ArchScopeIntentParseResult | boolean {
  if (args.length === 0) return false
  if (args.length === 1 && args[0] === '--refresh') return true
  return failure(`Invalid arguments. Usage: ${usage}`)
}

function parseOptionalRunId(args: string[], usage: string): ArchScopeIntentParseResult {
  if (args.length > 1 || args[0]?.startsWith('-')) {
    return failure(`Invalid arguments. Usage: ${usage}`)
  }
  return {
    ok: true,
    intent: args[0] === undefined ? { kind: 'run.resume' } : { kind: 'run.resume', runId: args[0] },
  }
}

export function parseArchScopeCommand(rawInput: string): ArchScopeIntentParseResult {
  const command = '/archscope'
  const tokens = rawInput.trim().split(/\s+/u).filter(Boolean)
  if (tokens.length === 0) return { ok: true, intent: { kind: 'help' } }

  const [rawSubcommand, ...args] = tokens
  const subcommand = rawSubcommand === undefined ? undefined : SUBCOMMAND_ALIASES.get(rawSubcommand)

  switch (subcommand) {
    case 'help':
      return args.length === 0
        ? { ok: true, intent: { kind: 'help' } }
        : failure(`Invalid arguments. Usage: ${command} help`)
    case 'system': {
      const refresh = parseRefreshArguments(args, `${command} system [--refresh]`)
      return typeof refresh === 'boolean'
        ? { ok: true, intent: { kind: 'system.scan', refresh } }
        : refresh
    }
    case 'project': {
      const [projectKey, ...rest] = args
      if (projectKey === undefined || projectKey.startsWith('-')) {
        return failure(`Missing project-key. Usage: ${command} project <project-key> [--refresh]`)
      }
      const refresh = parseRefreshArguments(rest, `${command} project <project-key> [--refresh]`)
      return typeof refresh === 'boolean'
        ? { ok: true, intent: { kind: 'project.scan', projectKey, refresh } }
        : refresh
    }
    case 'projects': {
      const refresh = args.includes('--refresh')
      const values = args.filter(value => value !== '--refresh')
      if (values.length === 1 && values[0] === '--all') return { ok: true, intent: { kind: 'projects.scan', allEligible: true, projectKeys: [], refresh } }
      if (values.length === 0 || values.some(value => value.startsWith('-'))) return failure(`Missing or invalid project selection. Usage: ${command} projects --all [--refresh] | ${command} projects <project-key...> [--refresh]`)
      return { ok: true, intent: { kind: 'projects.scan', allEligible: false, projectKeys: values, refresh } }
    }
    case 'resume':
      return parseOptionalRunId(args, `${command} resume [run-id]`)
    default:
      return failure(`Unknown ArchScope subcommand: ${rawSubcommand ?? ''}`)
  }
}

export interface ArchScopeCommandRuntime {
  scanSystem(options: { refresh?: boolean, signal?: AbortSignal, workspaceRoot?: string, agent?: ToolExecutionInput['agent'], onProgress?: (progress: SystemScanProgress) => void }): Promise<SystemScanResult>
  scanProject?(projectKey: string, options: { refresh?: boolean, signal?: AbortSignal, workspaceRoot?: string, agent?: ToolExecutionInput['agent'], onProgress?: (progress: ProjectScanProgress) => void }): Promise<ProjectScanResult>
  scanProjects?(selection: { mode: 'PROJECT_KEYS', projectKeys: string[] } | { mode: 'ALL_ELIGIBLE' }, options: { refresh?: boolean, signal?: AbortSignal, workspaceRoot?: string, agent?: ToolExecutionInput['agent'], onProgress?: (progress: ProjectBatchProgress) => void }): Promise<ProjectBatchResult>
}

function createSystemScanStartedMessage(refresh: boolean) {
  return createUserMessage({
    content: [{
      type: 'text',
      text: `Reply to the user in Chinese with one short sentence confirming that ArchScope has started the full system-level scan in the current DSH workspace${refresh ? ' with index refresh enabled' : ''}. Mention that it will discover projects, prepare indexes, collect evidence, and report progress automatically. Do not call any tools.`,
    }],
    source: {
      kind: 'plugin',
      plugin: 'archscope',
      form: 'notice',
      summary: 'ArchScope 系统级扫描已开始 · 正在发现工程',
    },
  })
}

function createHelpMessage() {
  return createUserMessage({
    content: [{
      type: 'text',
      text: `The user asked for ArchScope help. Reply in Chinese as a clear, concise, normal conversational answer—not as a tool result, command log, or thinking note. Do not call any tools. Preserve the meaning and commands in this guide:\n\n${ARCHSCOPE_COMMAND_HELP}`,
    }],
    source: {
      kind: 'plugin',
      plugin: 'archscope',
      form: 'notice',
      summary: 'ArchScope 使用指南',
    },
  })
}

function createSystemScanCompletedMessage(result: SystemScanResult) {
  const sourceAnalysisComplete = result.projectCount > 0
    && result.indexedProjectCount === result.projectCount
    && result.evidenceProjectCount === result.projectCount
    && result.scopeViolationCount === 0
  const systemAnalysis = sourceAnalysisComplete
    ? 'source-level analysis completed; runtime/production evidence remains unconfirmed'
    : 'source-level analysis is incomplete; inspect index, evidence, and scope counts'
  const projectAnalysis = result.gate === 'READY' ? 'available' : 'not yet available'
  const artifactRoot = result.validation === 'PASSED'
    ? `${result.outputDirectory}/system`
    : `${result.outputDirectory}/runs/${result.runId}/system`

  return createUserMessage({
    content: [{
      type: 'text',
      text: `ArchScope's model-backed system-level scan has finished after main-agent synthesis and deterministic validation. Report these exact user-facing facts in concise Chinese and do not call any tools:
- scan execution: ${result.reused ? 'reused from a compatible completed run' : 'completed now'}
- discovered projects: ${result.projectCount}
- fresh indexes: ${result.indexedProjectCount}/${result.projectCount}
- collected project evidence: ${result.evidenceProjectCount}/${result.projectCount}
- actual evidence scope violations: ${result.scopeViolationCount}
- system-level analysis: ${systemAnalysis}
- system artifact validation (structure, evidence, relation statistics, scope, gate, credential checks, and portable paths): ${result.validation}
- project-level analysis: ${projectAnalysis}
- system fact-base revision: ${result.documentRevision}
- artifact: ${artifactRoot}/00-system-fact-base.md
- current history index: ${result.outputDirectory}/system/history.json

Put these raw fields under a final "技术详情" line instead of leading with them:
- run: ${result.runId}
- machine status: ${result.status}
- project-scan gate: ${result.gate}

Do not describe the aggregate validation field as structure-only validation. Clearly distinguish source-level completion from missing runtime evidence and from the project-level gate.`,
    }],
    source: {
      kind: 'plugin',
      plugin: 'archscope',
      form: 'notice',
      summary: `ArchScope 系统级扫描结束 · ${result.evidenceProjectCount}/${result.projectCount} 个工程已取证 · ${result.gate}`,
    },
  })
}

function createSystemSynthesisRequestedMessage(result: SystemScanResult) {
  return createUserMessage({
    content: [{
      type: 'text',
      text: `你是本次 ArchScope 系统扫描的主 Agent。${result.projectCount} 个工程的隔离取证已经结束，现在必须由你汇总并建立系统世界观。立即调用 archscope_get_system_synthesis_context，runId=${result.runId}；完整遵循工具返回的主写者协议，先用 archscope_get_system_synthesis_page 无损读完清单中的全部数据集，再生成系统级事实底座和三张 Mermaid 图，并调用 archscope_commit_system_synthesis 提交。不要重新扫描代码，不要跳过提交，不要在提交前向用户宣称系统分析已完成。`,
    }],
    source: {
      kind: 'plugin',
      plugin: 'archscope',
      form: 'notice',
      summary: `ArchScope 主 Agent 综合 · ${result.evidenceProjectCount}/${result.projectCount} 个工程证据已就绪`,
    },
  })
}

function createSystemScanFailedMessage(error: unknown) {
  const reason = error instanceof Error ? error.message : String(error)
  return createUserMessage({
    content: [{
      type: 'text',
      text: `ArchScope's system scan failed. Tell the user concisely in Chinese that the scan failed with this reason and do not call any tools: ${reason}`,
    }],
    source: {
      kind: 'plugin',
      plugin: 'archscope',
      form: 'notice',
      summary: 'ArchScope 系统级扫描失败',
    },
  })
}

function createProjectScanStartedMessage(projectKey: string, refresh: boolean) {
  return createUserMessage({ content: [{ type: 'text', text: `用中文简短确认 ArchScope 已开始项目级扫描 ${projectKey}${refresh ? '，并刷新该工程索引' : ''}。说明它使用统一批处理执行器，由项目专属取证 Agent 和写作 Agent 完成。不要调用工具。` }], source: { kind: 'plugin', plugin: 'archscope', form: 'notice', summary: `ArchScope 项目级扫描已开始 · ${projectKey}` } })
}

function createProjectProgressMessage(progress: ProjectScanProgress) {
  return createUserMessage({ content: [{ type: 'text', text: `用中文输出这一行 ArchScope 项目扫描进度，不要调用工具：${progress.message}` }], source: { kind: 'plugin', plugin: 'archscope', form: 'notice', summary: `ArchScope · ${progress.message}` } })
}

function createProjectBatchCompletedMessage(result: ProjectBatchResult) {
  return createUserMessage({ content: [{ type: 'text', text: `用中文简洁汇报 ArchScope 项目批次结果，不要调用工具。批次=${result.batchId}，状态=${result.status}，系统事实版本=${result.sourceSystemRevision}，工程数=${result.projectKeys.length}，已归集=${result.completedCount}，失败=${result.failedCount}，阻断=${result.blockedCount}，冲突=${result.conflictCount}，阻断型冲突=${result.blockingConflictCount}，账本=${result.outputDirectory}/project-batches/${result.batchId}/state.json。说明单个工程失败不会抹掉其他工程结果，冲突不会在批次中静默修改系统事实。` }], source: { kind: 'plugin', plugin: 'archscope', form: 'notice', summary: `ArchScope 项目批次结束 · ${result.completedCount}/${result.projectKeys.length} 已归集` } })
}

function createProjectCompletedMessage(result: ProjectScanResult) {
  return createUserMessage({ content: [{ type: 'text', text: `用中文简洁汇报 ArchScope 项目扫描结果，不要调用工具。工程=${result.projectKey}，项目事实版本=${result.projectRevision}，系统事实版本=${result.sourceSystemRevision}，状态=${result.status}，校验=${result.validation}，模块级门禁=${result.gate}，证据=${result.evidenceStatus}，范围违规=${result.scopeViolationCount}，产物=${projectProfileArtifactPath(result)}。只有 COMPLETED/READY 指向 projects current；BLOCKED 指向当前 run 的失败快照。明确源码级完成不代表生产运行已验证。` }], source: { kind: 'plugin', plugin: 'archscope', form: 'notice', summary: `ArchScope 项目级扫描结束 · ${result.projectKey} · ${result.gate}` } })
}

function createProjectFailedMessage(projectKey: string, error: unknown) {
  const reason = error instanceof Error ? error.message : String(error)
  return createUserMessage({ content: [{ type: 'text', text: `用中文简洁告诉用户 ArchScope 项目扫描 ${projectKey} 失败，原因：${reason}。不要调用工具。` }], source: { kind: 'plugin', plugin: 'archscope', form: 'notice', summary: `ArchScope 项目级扫描失败 · ${projectKey}` } })
}

function createSystemScanProgressMessage(progress: SystemScanProgress) {
  return createUserMessage({
    content: [{
      type: 'text',
      text: `Reply to the user in Chinese with this one-line ArchScope progress update and do not call any tools: ${progress.message}`,
    }],
    source: {
      kind: 'plugin',
      plugin: 'archscope',
      form: 'notice',
      summary: `ArchScope · ${progress.message}`,
    },
  })
}

export async function executeArchScopeIntent(
  intent: ArchScopeIntent,
  runtime: ArchScopeCommandRuntime,
  signal?: AbortSignal,
  workspaceRoot?: string,
): Promise<CommandResult> {
  switch (intent.kind) {
    case 'help':
      return { kind: 'success', text: ARCHSCOPE_COMMAND_HELP }
    case 'system.scan': {
      const result = await runtime.scanSystem({ refresh: intent.refresh, signal, workspaceRoot })
      return { kind: 'success', text: createSystemScanMessage(result) }
    }
    case 'project.scan': {
      if (runtime.scanProject === undefined) throw new Error('Project-level scanning is unavailable in this runtime.')
      const result = await runtime.scanProject(intent.projectKey, { refresh: intent.refresh, signal, workspaceRoot })
      return { kind: 'success', text: createProjectScanMessage(result) }
    }
    case 'projects.scan': {
      if (runtime.scanProjects === undefined) throw new Error('Project batch scanning is unavailable in this runtime.')
      const selection = intent.allEligible ? { mode: 'ALL_ELIGIBLE' as const } : { mode: 'PROJECT_KEYS' as const, projectKeys: intent.projectKeys }
      const result = await runtime.scanProjects(selection, { refresh: intent.refresh, signal, workspaceRoot })
      return { kind: 'success', text: createProjectBatchMessage(result) }
    }
    case 'run.resume':
      return {
        kind: 'error',
        text: 'ArchScope persists system runs, but resumable task execution is not implemented yet. No action was taken.',
      }
  }
}

export function createArchScopeCommand(runtime: ArchScopeCommandRuntime): CommandDefinition {
  return {
    name: 'archscope',
    description: '证据驱动的系统架构勘察；需在已创建的会话中运行',
    input: { hint: 'system [--refresh] | project <project-key> [--refresh] | projects --all|<project-key...> [--refresh] | help' },
    handler: async ({ rawInput, signal, agent }) => {
      const parsed = parseArchScopeCommand(rawInput)
      if (!parsed.ok) return { kind: 'error', text: parsed.error }

      if (parsed.intent.kind === 'help') {
        agent.followup(createHelpMessage())
        return { kind: 'success' }
      }

      if (parsed.intent.kind === 'system.scan') {
        agent.followup(createSystemScanStartedMessage(parsed.intent.refresh))
        try {
          const result = await runtime.scanSystem({
            refresh: parsed.intent.refresh,
            signal,
            workspaceRoot: agent.session.header.cwd,
            agent,
            onProgress(progress) {
              agent.followup(createSystemScanProgressMessage(progress))
            },
          })
          if (result.status === 'AWAITING_SYNTHESIS' || result.status === 'SYNTHESIZING') {
            agent.followup(createSystemSynthesisRequestedMessage(result))
          } else {
            agent.followup(createSystemScanCompletedMessage(result))
          }
          return { kind: 'success', text: createSystemScanMessage(result) }
        } catch (error: unknown) {
          agent.followup(createSystemScanFailedMessage(error))
          throw error
        }
      }

      if (parsed.intent.kind === 'project.scan') {
        if (runtime.scanProject === undefined) return { kind: 'error', text: 'Project-level scanning is unavailable in this runtime.' }
        const projectKey = parsed.intent.projectKey
        const lifecycle = new AbortController()
        agent.followup(createProjectScanStartedMessage(projectKey, parsed.intent.refresh))
        void runtime.scanProject(projectKey, {
          refresh: parsed.intent.refresh,
          signal: lifecycle.signal,
          workspaceRoot: agent.session.header.cwd,
          agent,
          onProgress(progress) { agent.followup(createProjectProgressMessage(progress)) },
        }).then((result) => {
          agent.followup(createProjectCompletedMessage(result))
        }).catch((error: unknown) => {
          agent.followup(createProjectFailedMessage(projectKey, error))
        })
        return { kind: 'success', text: 'ArchScope project scan started in background · ' + projectKey + '.' }
      }

      if (parsed.intent.kind === 'projects.scan') {
        if (runtime.scanProjects === undefined) return { kind: 'error', text: 'Project batch scanning is unavailable in this runtime.' }
        const lifecycle = new AbortController()
        const selection = parsed.intent.allEligible ? { mode: 'ALL_ELIGIBLE' as const } : { mode: 'PROJECT_KEYS' as const, projectKeys: parsed.intent.projectKeys }
        const label = parsed.intent.allEligible ? '全部合格工程' : parsed.intent.projectKeys.join(', ')
        agent.followup(createUserMessage({ content: [{ type: 'text', text: `用中文简短确认 ArchScope 已开始项目批次扫描：${label}。说明每个工程独立执行并行取证与综合，当前主 Agent 只接收结果聚合。不要调用工具。` }], source: { kind: 'plugin', plugin: 'archscope', form: 'notice', summary: 'ArchScope 项目批次已开始' } }))
        void runtime.scanProjects(selection, { refresh: parsed.intent.refresh, signal: lifecycle.signal, workspaceRoot: agent.session.header.cwd, agent }).then(result => agent.followup(createProjectBatchCompletedMessage(result))).catch((error: unknown) => agent.followup(createProjectFailedMessage(label, error)))
        return { kind: 'success', text: 'ArchScope project batch started in background · ' + label + '.' }
      }

      return executeArchScopeIntent(parsed.intent, runtime, signal, agent.session.header.cwd)
    },
  }
}
