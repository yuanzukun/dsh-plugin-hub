import { defineTool, type ToolRunContext } from '@deepseek-ai/dsh-tools'

import type { SystemSynthesisCommitResult, SystemSynthesisDataset } from '../contracts/system-scan.js'
import type { ArchScopeService } from '../service.js'

function requireAgent(exec: ToolRunContext) {
  if (exec.agent === undefined) throw new Error('ArchScope system synthesis requires the invoking DeepSeek Harness main agent.')
  const workspaceRoot = exec.agent.session.header.cwd
  if (workspaceRoot === undefined || workspaceRoot.trim() === '') {
    throw new Error('ArchScope system synthesis requires the current DeepSeek Harness session workspace.')
  }
  return { agent: exec.agent, workspaceRoot }
}

export function createSystemSynthesisContextTool(service: ArchScopeService) {
  return defineTool({
    name: 'archscope_get_system_synthesis_context',
    description: 'Internal ArchScope bootstrap for the current main agent. Load the complete writer protocol plus a digest-protected manifest for sequential lossless input paging.',
    parameters: {
      runId: { type: 'string', required: true, description: 'Exact ArchScope system run id awaiting main-agent synthesis.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          runId: { type: 'string', required: true },
          protocolDigest: { type: 'string', required: true },
          evidenceMode: { type: 'string', required: true },
          evidenceBytes: { type: 'number', required: true },
          pageMaxBytes: { type: 'number', required: true },
          manifest: { type: 'json', required: true },
          relationCount: { type: 'number', required: true },
          prompt: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.prompt }],
    },
    async execute(args, exec) {
      const { workspaceRoot } = requireAgent(exec)
      return service.getSystemSynthesisContext(args.runId, { workspaceRoot }) as never
    },
  })
}

export function createSystemSynthesisPageTool(service: ArchScopeService) {
  return defineTool({
    name: 'archscope_get_system_synthesis_page',
    description: 'Read the next lossless, digest-protected ArchScope synthesis page. Pages must be consumed sequentially for every dataset before commit; no record is summarized, truncated, or discarded.',
    parameters: {
      runId: { type: 'string', required: true, description: 'Exact ArchScope system run id currently being synthesized.' },
      dataset: { type: 'string', required: true, description: 'One exact dataset name from the bootstrap manifest: PROJECT_REGISTRY, INDEX_MANIFEST, RELATIONS, or PROJECT_EVIDENCE.' },
      cursor: { type: 'string', required: true, description: 'Exact nextCursor from the bootstrap manifest or preceding page.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          runId: { type: 'string', required: true },
          protocolDigest: { type: 'string', required: true },
          dataset: { type: 'string', required: true },
          cursor: { type: 'string', required: true },
          nextCursor: { type: 'json', required: true },
          pageDigest: { type: 'string', required: true },
          globalDigest: { type: 'string', required: true },
          pageBytes: { type: 'number', required: true },
          pageRecordCount: { type: 'number', required: true },
          coveredRecordCount: { type: 'number', required: true },
          totalRecords: { type: 'number', required: true },
          complete: { type: 'boolean', required: true },
          items: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                recordKey: { type: 'string', required: true },
                recordDigest: { type: 'string', required: true },
                json: { type: 'string', required: true },
                byteOffset: { type: 'number', required: true },
                totalBytes: { type: 'number', required: true },
                completeRecord: { type: 'boolean', required: true },
              },
            },
          },
        },
      },
      render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }],
    },
    async execute(args, exec) {
      const { workspaceRoot } = requireAgent(exec)
      return service.getSystemSynthesisPage(args.runId, {
        workspaceRoot,
        dataset: args.dataset as SystemSynthesisDataset,
        cursor: args.cursor,
      })
    },
  })
}

export function createSystemProjectEvidenceTool(service: ArchScopeService) {
  return defineTool({
    name: 'archscope_get_system_project_evidence',
    description: 'Legacy targeted evidence lookup for diagnostics. It does not advance the mandatory lossless synthesis read ledger; normal synthesis must use archscope_get_system_synthesis_page.',
    parameters: {
      runId: { type: 'string', required: true, description: 'Exact ArchScope system run id currently being synthesized.' },
      projectKeys: {
        type: 'array',
        required: true,
        description: 'One to eight exact projectKey values from the ArchScope project registry.',
        items: { type: 'string' },
      },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          runId: { type: 'string', required: true },
          protocolDigest: { type: 'string', required: true },
          projectKeys: { type: 'array', required: true, items: { type: 'string' } },
          missingProjectKeys: { type: 'array', required: true, items: { type: 'string' } },
          evidenceJson: { type: 'string', required: true },
        },
      },
      render: (_args, value) => [{ type: 'text', text: value.evidenceJson }],
    },
    async execute(args, exec) {
      const { workspaceRoot } = requireAgent(exec)
      return service.getSystemProjectEvidence(args.runId, { workspaceRoot, projectKeys: args.projectKeys })
    },
  })
}

export function createCommitSystemSynthesisTool(service: ArchScopeService) {
  return defineTool({
    name: 'archscope_commit_system_synthesis',
    description: 'Commit the current DSH main agent system worldview for an ArchScope run. ArchScope normalizes machine facts and validates evidence, exact relation statistics, portable paths, credential safety, structure, and the project-level gate.',
    parameters: {
      runId: { type: 'string', required: true },
      factBase: { type: 'string', required: true, description: 'Complete 22-section system fact-base Markdown, without a surrounding code fence.' },
      systemContextDiagram: { type: 'string', required: true, description: 'Mermaid flowchart source for the system context diagram, without a code fence.' },
      internalRelationsDiagram: { type: 'string', required: true, description: 'Mermaid flowchart source for internal project relations, without a code fence.' },
      entryOverviewDiagram: { type: 'string', required: true, description: 'Mermaid flowchart source for the coarse entry overview, without a code fence.' },
    },
    output: {
      schema: {
        type: 'object',
        additionalProperties: false,
        properties: {
          runId: { type: 'string', required: true },
          documentRevision: { type: 'string', required: true },
          status: { type: 'string', required: true },
          gate: { type: 'string', required: true },
          validation: { type: 'string', required: true },
          projectCount: { type: 'number', required: true },
          indexedProjectCount: { type: 'number', required: true },
          evidenceProjectCount: { type: 'number', required: true },
          scopeViolationCount: { type: 'number', required: true },
          outputDirectory: { type: 'string', required: true },
          reused: { type: 'boolean', required: true },
          synthesisAttempt: { type: 'number', required: true },
          retryAllowed: { type: 'boolean', required: true },
          issues: {
            type: 'array',
            required: true,
            items: {
              type: 'object',
              additionalProperties: false,
              properties: {
                severity: { type: 'string', required: true },
                code: { type: 'string', required: true },
                message: { type: 'string', required: true },
              },
            },
          },
        },
      },
      render: (_args, value) => {
        const result = value as unknown as SystemSynthesisCommitResult
        const errors = result.issues.filter(issue => issue.severity === 'ERROR')
        const action = result.retryAllowed
          ? `Validation failed with ${errors.length} error(s). Revise the document from these issues and call archscope_commit_system_synthesis once more:\n${errors.map(issue => `- ${issue.code}: ${issue.message}`).join('\n')}`
          : `System synthesis committed as document revision ${result.documentRevision}. Validation ${result.validation}; machine status ${result.status}; project-scan gate ${result.gate}. Report only machine-provided counts in Chinese. Published artifacts are under ${result.outputDirectory}/system; the immutable snapshot is ${result.outputDirectory}/runs/${result.runId}/system; the mutable history index is ${result.outputDirectory}/system/history.json and must not be listed inside the run snapshot.`
        return [{ type: 'text', text: action }]
      },
    },
    async execute(args, exec) {
      const { agent, workspaceRoot } = requireAgent(exec)
      return service.commitSystemSynthesis({
        runId: args.runId,
        workspaceRoot,
        writer: {
          kind: 'dsh-main-agent',
          sessionId: String(agent.id),
          ...agent.options.provider === undefined ? {} : { provider: agent.options.provider },
          ...agent.options.model === undefined ? {} : { model: agent.options.model },
        },
        draft: {
          factBase: args.factBase,
          diagrams: {
            systemContext: args.systemContextDiagram,
            internalRelations: args.internalRelationsDiagram,
            entryOverview: args.entryOverviewDiagram,
          },
        },
      })
    },
  })
}
