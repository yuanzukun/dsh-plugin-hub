import { defineTool } from '@deepseek-ai/dsh-tools'
import type { ProjectBatchResult, ProjectScanResult } from '../contracts/project-scan.js'
import type { ArchScopeService } from '../service.js'

export function projectProfileArtifactPath(result: ProjectScanResult): string {
  return result.status === 'COMPLETED'
    ? result.outputDirectory + '/projects/' + result.projectKey + '/00-project-profile.md'
    : result.outputDirectory + '/runs/' + result.runId + '/project/00-project-profile.md'
}

export function createProjectScanMessage(result: ProjectScanResult): string {
  if (result.status === 'AWAITING_PROJECT_SYNTHESIS' || result.status === 'SYNTHESIZING') return [
    'ArchScope project evidence ready · ' + result.projectKey + ' · awaiting current main-agent project synthesis.',
    'Next: call archscope_get_project_synthesis_context with runId ' + result.runId + ', read every page, stage PROFILE plus three diagrams with archscope_stage_project_artifact, then call archscope_finalize_project_synthesis.',
    'Evidence: ' + result.outputDirectory + '/runs/' + result.runId + '/project/synthesis-input.json',
  ].join('\n')
  return 'ArchScope project scan ' + result.status + ' · ' + result.projectKey + ' · revision ' + result.projectRevision + ' · validation ' + result.validation + ' · module gate ' + result.gate + '.\nArtifact: ' + projectProfileArtifactPath(result)
}

export function createProjectScanTool(service: ArchScopeService) {
  return defineTool({
    name: 'archscope_scan_project',
    description: 'Compatibility entry point for one project. Internally executes the unified project-batch pipeline with a selection size of one, including dedicated evidence and writer agents.',
    parameters: { projectKey: { type: 'string', required: true }, refresh: { type: 'boolean' } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      runId: { type: 'string', required: true }, projectKey: { type: 'string', required: true }, projectDir: { type: 'string', required: true }, specialization: { type: 'string', required: true }, framework: { type: 'string' }, projectRevision: { type: 'string', required: true }, sourceSystemRevision: { type: 'string', required: true }, status: { type: 'string', required: true }, gate: { type: 'string', required: true }, validation: { type: 'string', required: true }, indexStatus: { type: 'string', required: true }, evidenceStatus: { type: 'string', required: true }, scopeViolationCount: { type: 'number', required: true }, conflictCount: { type: 'number', required: true }, blockingConflictCount: { type: 'number', required: true }, reconciliationStatus: { type: 'string', required: true }, outputDirectory: { type: 'string', required: true }, reused: { type: 'boolean', required: true },
    } }, render: (_args, value) => [{ type: 'text', text: createProjectScanMessage(value as unknown as ProjectScanResult) }] },
    execute(args, exec) { return service.scanProject(args.projectKey, { refresh: args.refresh ?? false, signal: exec.signal, workspaceRoot: exec.agent?.session.header.cwd, agent: exec.agent }) },
  })
}

export function createProjectBatchMessage(result: ProjectBatchResult): string {
  return [
    'ArchScope project batch ' + result.status + ' · ' + result.completedCount + '/' + result.projectKeys.length + ' project pipelines settled.',
    'System binding: ' + result.sourceSystemRevision + ' (' + result.sourceSystemRunId + ').',
    'Failed: ' + result.failedCount + ' · blocked: ' + result.blockedCount + ' · conflicts: ' + result.conflictCount + ' (' + result.blockingConflictCount + ' blocking).',
    'Batch ledger: ' + result.outputDirectory + '/project-batches/' + result.batchId + '/state.json',
  ].join('\n')
}

export function createProjectBatchTool(service: ArchScopeService) {
  return defineTool({
    name: 'archscope_scan_projects',
    description: 'Run the unified ArchScope project pipeline for selected registered project keys or every eligible project. Each project has isolated evidence and writer agents; the caller receives only aggregated result envelopes.',
    parameters: {
      allEligible: { type: 'boolean', description: 'Select every project registered by the bound system revision.' },
      projectKeys: { type: 'array', items: { type: 'string' }, description: 'Exact registered project keys. Use this when allEligible is not true.' },
      refresh: { type: 'boolean' },
      maxConcurrency: { type: 'integer', description: 'Bounded project pipeline concurrency, 1-16.' },
    },
    output: {
      schema: { type: 'object', additionalProperties: true, properties: {
        batchId: { type: 'string' }, status: { type: 'string' }, sourceSystemRunId: { type: 'string' }, sourceSystemRevision: { type: 'string' }, completedCount: { type: 'number' }, failedCount: { type: 'number' }, blockedCount: { type: 'number' }, conflictCount: { type: 'number' }, blockingConflictCount: { type: 'number' }, outputDirectory: { type: 'string' }, items: { type: 'array' },
      } },
      render: (_args, value) => [{ type: 'text', text: createProjectBatchMessage(value as unknown as ProjectBatchResult) }],
    },
    execute(args, exec): Promise<never> {
      const selection = args.allEligible === true
        ? { mode: 'ALL_ELIGIBLE' as const }
        : { mode: 'PROJECT_KEYS' as const, projectKeys: args.projectKeys ?? [] }
      return service.scanProjects(selection, { refresh: args.refresh ?? false, maxConcurrency: args.maxConcurrency, signal: exec.signal, workspaceRoot: exec.agent?.session.header.cwd, agent: exec.agent }) as Promise<never>
    },
  })
}
