import { defineTool, type ToolRunContext } from '@deepseek-ai/dsh-tools'
import type {
  ProjectEvidenceDataset,
  ProjectSpecialization,
  ProjectSynthesisArtifact,
  ProjectSynthesisCommitResult,
  ProjectSynthesisDataset,
  ProjectSynthesisFinalizeResult,
  ProjectSynthesisStageResult,
} from '../contracts/project-scan.js'
import type { ArchScopeService } from '../service.js'

function requireAgent(exec: ToolRunContext) {
  if (!exec.agent) throw new Error('ArchScope project subagent tools require the invoking DSH agent.')
  const workspaceRoot = exec.agent.session.header.cwd
  if (!workspaceRoot?.trim()) throw new Error('ArchScope project subagent tools require the current DSH workspace.')
  return { agent: exec.agent, workspaceRoot }
}

function writer(exec: ReturnType<typeof requireAgent>['agent'], specialization: ProjectSpecialization) {
  return {
    kind: 'dsh-project-writer-agent' as const,
    specialization,
    sessionId: String(exec.id),
    ...(exec.options.provider === undefined ? {} : { provider: exec.options.provider }),
    ...(exec.options.model === undefined ? {} : { model: exec.options.model }),
  }
}

export function createProjectSynthesisContextTool(service: ArchScopeService) {
  return defineTool({ name: 'archscope_get_project_synthesis_context', description: 'Load the project writer protocol and lossless paging manifest.',
    parameters: { runId: { type: 'string', required: true } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      runId: { type: 'string', required: true }, projectKey: { type: 'string', required: true }, projectDir: { type: 'string', required: true }, specialization: { type: 'string', required: true }, framework: { type: 'string' }, template: { type: 'string', required: true }, protocolDigest: { type: 'string', required: true }, evidenceMode: { type: 'string', required: true }, evidenceBytes: { type: 'number', required: true }, pageMaxBytes: { type: 'number', required: true }, manifest: { type: 'json', required: true }, protocolResourceIds: { type: 'array', required: true, items: { type: 'string' } }, prompt: { type: 'string', required: true },
    } }, render: (_args, value) => [{ type: 'text', text: 'ArchScope 项目综合上下文已加载。runId=' + value.runId + '\n\n' + value.prompt }] },
    execute(args, exec) { const { workspaceRoot } = requireAgent(exec); return service.getProjectSynthesisContext(args.runId, { workspaceRoot }) as never },
  })
}

export function createProjectEvidenceContextTool(service: ArchScopeService) {
  return defineTool({ name: 'archscope_get_project_evidence_context', description: 'Load the compact manifest for one active paged project evidence task. No arbitrary file access.',
    parameters: { runId: { type: 'string', required: true } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      protocolVersion: { type: 'string', required: true }, runId: { type: 'string', required: true }, projectKey: { type: 'string', required: true }, projectDir: { type: 'string', required: true }, specialization: { type: 'string', required: true }, framework: { type: 'string' }, mcpProject: { type: 'string', required: true }, sourceSystemRevision: { type: 'string', required: true }, evidenceMode: { type: 'string', required: true }, manifest: { type: 'json', required: true }, protocolResourceIds: { type: 'array', required: true, items: { type: 'string' } },
    } }, render: (_args, value) => [{ type: 'text', text: 'ArchScope 项目证据分页上下文已加载。runId=' + value.runId + '\n' + JSON.stringify(value) }] },
    execute(args, exec) { const { workspaceRoot } = requireAgent(exec); return service.getProjectEvidenceTaskContext(args.runId, { workspaceRoot }) as never },
  })
}

export function createProjectEvidencePageTool(service: ArchScopeService) {
  return defineTool({ name: 'archscope_get_project_evidence_page', description: 'Read the next sequential lossless page for project evidence. Read SAFE_METADATA and DETERMINISTIC_FACTS first.',
    parameters: { runId: { type: 'string', required: true }, dataset: { type: 'string', required: true }, cursor: { type: 'string', required: true } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      runId: { type: 'string', required: true }, protocolDigest: { type: 'string', required: true }, dataset: { type: 'string', required: true }, cursor: { type: 'string', required: true }, nextCursor: { type: 'json', required: true }, pageDigest: { type: 'string', required: true }, globalDigest: { type: 'string', required: true }, pageBytes: { type: 'number', required: true }, pageRecordCount: { type: 'number', required: true }, coveredRecordCount: { type: 'number', required: true }, totalRecords: { type: 'number', required: true }, complete: { type: 'boolean', required: true }, items: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: { recordKey: { type: 'string', required: true }, recordDigest: { type: 'string', required: true }, json: { type: 'string', required: true }, byteOffset: { type: 'number', required: true }, totalBytes: { type: 'number', required: true }, completeRecord: { type: 'boolean', required: true } } } },
    } }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
    execute(args, exec) { const { workspaceRoot } = requireAgent(exec); return service.getProjectEvidencePage(args.runId, { workspaceRoot, dataset: args.dataset as ProjectEvidenceDataset, cursor: args.cursor }) },
  })
}

export function createProjectProtocolResourceTool(service: ArchScopeService) {
  return defineTool({ name: 'archscope_get_project_protocol_resource', description: 'Read one versioned project protocol resource allowed by the active run specialization and phase.',
    parameters: { runId: { type: 'string', required: true }, resourceId: { type: 'string', required: true } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      runId: { type: 'string', required: true }, phase: { type: 'string', required: true }, resourceId: { type: 'string', required: true }, version: { type: 'string', required: true }, kind: { type: 'string', required: true }, digest: { type: 'string', required: true }, content: { type: 'string', required: true },
    } }, render: (_args, value) => [{ type: 'text', text: '[' + value.resourceId + '@' + value.version + ' · ' + value.digest + ']\n\n' + value.content }] },
    execute(args, exec) { const { workspaceRoot } = requireAgent(exec); return service.getProjectProtocolResource(args.runId, { workspaceRoot, resourceId: args.resourceId }) },
  })
}

export function createProjectSynthesisPageTool(service: ArchScopeService) {
  return defineTool({ name: 'archscope_get_project_synthesis_page', description: 'Read the next sequential lossless page for project synthesis.',
    parameters: { runId: { type: 'string', required: true }, dataset: { type: 'string', required: true }, cursor: { type: 'string', required: true } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      runId: { type: 'string', required: true }, protocolDigest: { type: 'string', required: true }, dataset: { type: 'string', required: true }, cursor: { type: 'string', required: true }, nextCursor: { type: 'json', required: true }, pageDigest: { type: 'string', required: true }, globalDigest: { type: 'string', required: true }, pageBytes: { type: 'number', required: true }, pageRecordCount: { type: 'number', required: true }, coveredRecordCount: { type: 'number', required: true }, totalRecords: { type: 'number', required: true }, complete: { type: 'boolean', required: true }, items: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: { recordKey: { type: 'string', required: true }, recordDigest: { type: 'string', required: true }, json: { type: 'string', required: true }, byteOffset: { type: 'number', required: true }, totalBytes: { type: 'number', required: true }, completeRecord: { type: 'boolean', required: true } } } },
    } }, render: (_args, value) => [{ type: 'text', text: JSON.stringify(value) }] },
    execute(args, exec) { const { workspaceRoot } = requireAgent(exec); return service.getProjectSynthesisPage(args.runId, { workspaceRoot, dataset: args.dataset as ProjectSynthesisDataset, cursor: args.cursor }) },
  })
}

export function createStageProjectSynthesisArtifactTool(service: ArchScopeService) {
  return defineTool({ name: 'archscope_stage_project_artifact', description: 'Stage exactly one project synthesis artifact. Call once per profile or diagram; runId may be omitted only when one active project synthesis exists.',
    parameters: { runId: { type: 'string' }, artifact: { type: 'string', required: true }, content: { type: 'string', required: true } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      runId: { type: 'string', required: true }, projectKey: { type: 'string', required: true }, artifact: { type: 'string', required: true }, stagedCount: { type: 'number', required: true }, totalArtifacts: { type: 'number', required: true }, missingArtifacts: { type: 'array', required: true, items: { type: 'string' } }, readyToFinalize: { type: 'boolean', required: true },
    } }, render: (_args, value) => {
      const result = value as unknown as ProjectSynthesisStageResult
      const missing = result.missingArtifacts.length === 0 ? 'none' : result.missingArtifacts.join(', ')
      return [{ type: 'text', text: 'Project artifact staged · runId=' + result.runId + ' · ' + result.artifact + ' · ' + result.stagedCount + '/' + result.totalArtifacts + ' · missing: ' + missing + '.' }]
    } },
    execute(args, exec) {
      const { workspaceRoot } = requireAgent(exec)
      return service.stageProjectSynthesisArtifact({ ...(args.runId?.trim() ? { runId: args.runId } : {}), workspaceRoot, artifact: args.artifact as ProjectSynthesisArtifact, content: args.content })
    },
  })
}

export function createFinalizeProjectSynthesisTool(service: ArchScopeService) {
  return defineTool({ name: 'archscope_finalize_project_synthesis', description: 'Deterministically publish the four staged project synthesis artifacts. Returns missing artifact names without publishing when staging is incomplete.',
    parameters: { runId: { type: 'string', required: true } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      finalizeStatus: { type: 'string', required: true }, runId: { type: 'string', required: true }, projectKey: { type: 'string', required: true }, stagedCount: { type: 'number', required: true }, totalArtifacts: { type: 'number', required: true }, missingArtifacts: { type: 'array', required: true, items: { type: 'string' } }, commit: { type: 'json' },
    } }, render: (_args, value) => {
      const result = value as unknown as ProjectSynthesisFinalizeResult
      if (result.finalizeStatus === 'INCOMPLETE' || result.commit === undefined) {
        return [{ type: 'text', text: 'Project synthesis is not published. runId=' + result.runId + '. Stage the missing artifacts, then finalize again: ' + result.missingArtifacts.join(', ') + '.' }]
      }
      const errors = result.commit.issues.filter(item => item.severity === 'ERROR')
      if (result.commit.retryAllowed) {
        return [{ type: 'text', text: 'Project validation failed for runId=' + result.runId + '. Restage only the affected artifact(s), then call archscope_finalize_project_synthesis again with this exact runId.\n' + errors.map(item => '- ' + item.code + ': ' + item.message).join('\n') }]
      }
      return [{ type: 'text', text: 'Project synthesis committed · ' + result.commit.projectKey + ' · revision ' + result.commit.projectRevision + ' · validation ' + result.commit.validation + ' · module gate ' + result.commit.gate + '.' }]
    } },
    async execute(args, exec) {
      const { agent, workspaceRoot } = requireAgent(exec)
      const context = await service.getProjectSynthesisContext(args.runId, { workspaceRoot })
      return service.finalizeProjectSynthesis({ runId: args.runId, workspaceRoot, writer: writer(agent, context.specialization) }) as never
    },
  })
}

export function createCommitProjectSynthesisTool(service: ArchScopeService) {
  return defineTool({ name: 'archscope_commit_project_synthesis', description: 'Legacy compatibility: submit the project profile and all three diagrams in one call. Prefer staged artifact tools.',
    parameters: { runId: { type: 'string', required: true }, profile: { type: 'string', required: true }, projectContextDiagram: { type: 'string', required: true }, structureDiagram: { type: 'string', required: true }, entryDependencyDiagram: { type: 'string', required: true } },
    output: { schema: { type: 'object', additionalProperties: false, properties: {
      runId: { type: 'string', required: true }, projectKey: { type: 'string', required: true }, projectDir: { type: 'string', required: true }, specialization: { type: 'string', required: true }, framework: { type: 'string' }, projectRevision: { type: 'string', required: true }, sourceSystemRevision: { type: 'string', required: true }, status: { type: 'string', required: true }, gate: { type: 'string', required: true }, validation: { type: 'string', required: true }, indexStatus: { type: 'string', required: true }, evidenceStatus: { type: 'string', required: true }, scopeViolationCount: { type: 'number', required: true }, outputDirectory: { type: 'string', required: true }, reused: { type: 'boolean', required: true }, synthesisAttempt: { type: 'number', required: true }, retryAllowed: { type: 'boolean', required: true }, issues: { type: 'array', required: true, items: { type: 'object', additionalProperties: false, properties: { severity: { type: 'string', required: true }, code: { type: 'string', required: true }, message: { type: 'string', required: true } } } },
    } }, render: (_args, value) => { const result = value as unknown as ProjectSynthesisCommitResult; const errors = result.issues.filter(item => item.severity === 'ERROR'); return [{ type: 'text', text: result.retryAllowed ? 'Legacy project validation failed for runId=' + result.runId + '. Resubmit all five required fields: runId, profile, projectContextDiagram, structureDiagram, entryDependencyDiagram.\n' + errors.map(item => '- ' + item.code + ': ' + item.message).join('\n') : 'Project synthesis committed · ' + result.projectKey + ' · revision ' + result.projectRevision + ' · validation ' + result.validation + ' · module gate ' + result.gate + '.' }] } },
    async execute(args, exec) { const { agent, workspaceRoot } = requireAgent(exec); const context = await service.getProjectSynthesisContext(args.runId, { workspaceRoot }); return service.commitProjectSynthesis({ runId: args.runId, workspaceRoot, writer: writer(agent, context.specialization), draft: { profile: args.profile, diagrams: { projectContext: args.projectContextDiagram, structure: args.structureDiagram, entryDependency: args.entryDependencyDiagram } } }) },
  })
}
