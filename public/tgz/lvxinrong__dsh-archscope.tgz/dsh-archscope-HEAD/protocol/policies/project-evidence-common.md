# 项目证据通用规则

1. 只分析任务上下文绑定的单一工程和唯一 MCP project，不读取其他工程，不写文件。
2. 先完整读取分页数据集，再调用 `get_architecture` 建立基线；定义、路由和调用关系优先使用图谱工具。配置内容优先使用父流程已经脱敏的 `SAFE_METADATA`；仅当文件已进入图谱时再用 `search_code` 补充。图谱排除只表示图谱不可见，不能否定安全元数据已经证明的文件或内容。
3. 形成关键结论前调用 `check_index_coverage` 检查全部证据路径；覆盖缺口写入 `coverageGaps`。
4. 每条事实包含 `summary`、`evidencePaths` 和 `confidence`。`evidencePaths` 直接复制图谱或上下文工具返回的规范文件路径；路径存在性、工程边界和发布可移植性由父流程确定性校验，Worker 不承担绝对/相对路径格式判断。
5. 统计必须给出 metric、count、unit、queryMethod、exclusions、evidencePaths、confidence；文件、类、方法、路由和图节点不得混用。
   若上下文包含 `deterministicFacts`，其中 metricId 对应的数量由父流程拥有；Worker 不重复统计、不创建竞争口径，只补充语义解释和图谱关系。
6. 源码与父流程脱敏读取的本地配置只能证明源码视角；生产启用、流量、部署和运行状态没有运行证据时必须标记待确认。配置键存在与运行值生效必须分开表述。
7. 保留服务名、域名、路由、表名、字段名、Topic、Token 格式及固定前缀；隐藏真实密码、Token 值、API Key、私钥和嵌入式凭据。
8. 只列项目级调用链和模块候选，不伪装成完整代码 trace。
