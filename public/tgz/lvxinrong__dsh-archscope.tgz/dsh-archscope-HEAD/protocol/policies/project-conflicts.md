# 项目与系统冲突规则

只有项目证据与绑定系统输入中可逐字定位的断言存在差异时才创建 conflict。

- 每条冲突必须提供 `systemEvidencePointer`、短原文 `systemEvidenceQuote`、`systemAssertion`、`projectAssertion`、`rationale`、原子证据路径和置信度。
- `systemEvidenceQuote` 必须逐字存在于 `SYSTEM_FACT_BASE` 正文或 `SYSTEM_EVIDENCE` 的某个字符串字段；引用字段值中的双引号时写原始字符，不写 JSON 转义形式。
- `systemEvidencePointer` 应指向包含该原文的数据集。若原文只存在于另一个绑定数据集，插件会确定性纠正 pointer；两个数据集都不存在时才拒绝冲突。
- 细化但不否定上层结论使用 `REFINEMENT`。
- 本工程源码直接否定系统结论使用 `LOCAL_SOURCE_CONTRADICTION`；涉及其他工程使用 `CROSS_PROJECT_CONTRADICTION`。
- 只有上层明确陈述运行态、而项目仅有源码视角时才使用 `RUNTIME_SCOPE_MISMATCH`。
- 上游明显陈旧使用 `STALE_UPSTREAM`；工程身份不一致使用 `IDENTITY_MISMATCH`。
- 普通风险、待确认、索引排除和配置缺失分别进入 `risks`、`constraints` 或 `coverageGaps`，不得放入 conflicts。
- 没有绑定系统输入时 conflicts 必须为空。项目 Agent 不得修改系统事实。
