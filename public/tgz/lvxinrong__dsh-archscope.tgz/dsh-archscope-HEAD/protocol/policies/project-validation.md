# ArchScope 项目级校验策略

校验覆盖固定模板、元数据、证据引用、工程边界、凭据、可移植路径、三张 Mermaid 图、系统事实版本绑定和 module-scan gate。PASSED 表示项目产物符合协议；READY 表示可以继续模块级扫描，不表示运行态或生产环境已验证。

语义校验还必须验证：专长与模板绑定一致；报告中的 PC/REL ID 来自输入数据；每个结构化冲突在报告中出现且其系统原文可在绑定数据集中逐字找到；反引号证据引用必须是 evidence.json 中的原子工程相对路径，不能使用 basename、目录、glob 或行号后缀。

确定性否定结论校验失败时，反馈必须包含受影响产物、行号、精确命中片段和改写边界。修复 Agent 应只重写命中句：已由确定性清单证明存在的文件或注解不能写成“不存在”；未读取的配置内容、运行值或生产启用状态应写成“未核验”，不能写成“无”。项目综合最多允许三次确定性校验尝试，第三次仍失败才形成 BLOCKED 快照。

Spring 后端还必须校验 `DETERMINISTIC_FACTS`：正文与三张图中的 Controller、Mapper XML、`@DS`、Feign、任务、消息和本地配置数量只能使用父流程拥有的指标值；只有与指标词在局部语义范围内直接绑定的计数才按该指标校验，类方法数、测试文件数等无关数字不得因同一行出现类名而被误判。structure 图中的 Maven 模块边必须来自 moduleDependencies。negativeClaimRules 未允许的否定性结论直接阻断发布。索引排除和扫描不完整只能形成 coverage gap，不能生成“0 个”结论。

PROFILE 与三张图是四个互斥产物。PROFILE 中出现 Mermaid flowchart/graph 源码即阻断；三张图不得反向嵌回正文。证据引用白名单由 PROJECT_EVIDENCE、SYSTEM_RELATIONS、SYSTEM_EVIDENCE 与 DETERMINISTIC_FACTS 的结构化 evidencePaths 合并产生，不能只依赖单个顶层数组。

产物校验与上下层复核是两个独立维度：非阻断冲突允许 validation=PASSED、gate=READY、reconciliation=OPEN；阻断型冲突允许 validation=PASSED，但 gate 必须为 BLOCKED、reconciliation=BLOCKED，且只隔离对应工程。
