# Android 原生项目证据清单

覆盖 Gradle 模块、variant/flavor、Manifest 组件与 Deep Link、启动和导航、生命周期与状态流、线程/协程、网络鉴权、存储与权限、第三方 SDK、混合容器、签名发布、CI 和测试。不得把 React Native/Flutter 生成目录当成原生应用事实。

