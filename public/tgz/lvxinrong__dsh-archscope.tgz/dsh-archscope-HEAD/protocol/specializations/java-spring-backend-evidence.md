# Spring 体系后端 Java 项目证据清单

仅适用于父流程已证明为 Spring Framework、Spring Boot 或 Spring Cloud 可执行服务的工程。

1. 服务身份与执行边界：artifact、application name、JDK、Maven/Gradle 模块、JAR/WAR、main/Servlet 入口、profile。
2. Spring 体系：Framework/Boot/Cloud 版本与 BOM、starter、自动配置、组件扫描、Bean/Configuration、条件装配。
3. 入口族：MVC/WebFlux、Filter/Interceptor/Security、Feign/Dubbo/gRPC、MQ Listener/Producer、Scheduled/XXL/Quartz、WebSocket/SSE、batch/CLI。
4. 分层与模块：delivery/application/domain/infrastructure、Controller/Service/Repository、模块边界破坏；Maven 工程内模块依赖方向直接使用 `DETERMINISTIC_FACTS.moduleDependencies`，不从目录顺序或 import 印象重算。
5. 出站与韧性：Feign/RestTemplate/WebClient/RPC、服务发现、超时、重试、熔断和限流。
6. 数据与一致性：JPA/MyBatis/MyBatis-Plus、Mapper XML、数据源路由、事务、迁移、Redis/搜索、锁、幂等、补偿和 Outbox。
7. 配置链：application/bootstrap、ConfigurationProperties/Value、Nacos/Apollo/Config Server、部署注入及未覆盖配置。
8. 安全边界：Spring Security/Filter/Interceptor/网关信任、token/session、白名单、CORS/CSRF、租户和数据权限。
9. 可观测与运行：Actuator、health/readiness、metrics、trace、日志关联、优雅停机、端口/context-path、Docker/K8s/CI/JVM 参数。
10. 测试与风险：单元/slice/集成/契约/Testcontainers、跳过测试配置、巨型类、高扇入扇出、环依赖和阻塞调用。
11. Controller、Mapper、`@DS`、Feign、Listener、任务和本地配置等已有 `DETERMINISTIC_FACTS` 指标时直接引用 metricId，不重新计数；configurationFiles 证明文件存在。`SAFE_METADATA` 是父流程直接读取并脱敏后的配置内容证据；图谱排除只表示图谱不可见，不得再写成“内容不存在”或“仓库内无文本”。图谱独有指标必须另列口径，不得与文件数、类数、方法数或注解出现次数混用。
12. 输出核心调用链候选和有证据的模块拆分候选。
