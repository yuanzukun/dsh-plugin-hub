# iOS 原生项目证据清单

覆盖 Xcode target/scheme/configuration、启动与 Deep Link、导航、生命周期和状态流、Swift concurrency、网络鉴权、存储/Keychain、entitlements、第三方 SDK、混合容器、签名发布、CI 和测试。不得把 React Native/Flutter 生成目录当成原生应用事实。

