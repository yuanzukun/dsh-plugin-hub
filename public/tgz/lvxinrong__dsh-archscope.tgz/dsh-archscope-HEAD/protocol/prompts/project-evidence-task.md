# 项目级深取证 Worker 契约

运行时首条提示必须使用 `ARCHSCOPE_PROJECT_EVIDENCE_TASK_V1` 短任务信封，只携带 runId、工程身份、冻结专长、唯一 MCP project、只读上下文/分页工具名和版本化资源 ID。上下文工具只返回分页 manifest；Worker 必须依次完整读取 `SAFE_METADATA`、`DETERMINISTIC_FACTS`、`SYSTEM_PROJECT_EVIDENCE`、`SYSTEM_FACT_BASE`，每页按 nextCursor 串行推进到 null。同一 `recordKey` 被拆成多页时，必须按 `byteOffset` 顺序拼接全部 `json` 片段，直到 `completeRecord=true` 后再解析；不得只读取首片或把片段当作完整 JSON。系统事实、安全元数据与本协议正文不得内联。所有数据集和资源必须逐项读完，服务端在接受工程证据前核对分页账本与资源读取账本。

父流程必须先按 `project-specialization/v1` 冻结工程专长，再派发对应的专属 Worker。Worker 不得自行选择模板、升级工程类型或套用其他平台的检查项。只分析一个 projectKey 对应的唯一 MCP project。使用代码图谱定位入口、调用、依赖与结构，使用安全元数据核对构建、配置、部署和文档。证据路径直接复制允许工具返回的规范文件路径，不自行判断绝对或相对格式。不得调用不存在的 Glob、Inspect、OUT、Read 或 shell 工具。

父流程负责证据文件存在性、工程边界、发布可移植性及确定性事实一致性校验；若路径无效或摘要与 `DETERMINISTIC_FACTS` 冲突，最多发起一次定向修复，反馈必须给出精确命中片段。Worker 必须依据分页数据与工具结果返回完整结构，不能猜测同名文件。

项目事实与绑定的系统事实不一致时，输出结构化冲突：区分细化、单工程源码矛盾、跨工程矛盾、运行态范围差异、上游陈旧与工程身份不一致。每条冲突必须携带系统数据集指针和可在绑定输入中逐字找到的短原文；无法逐字定位时不是可发布冲突。索引排除、缺配置等范围问题进入 coverageGaps，普通风险和待确认项不写入冲突数组。项目 Worker 不得修改系统事实。
