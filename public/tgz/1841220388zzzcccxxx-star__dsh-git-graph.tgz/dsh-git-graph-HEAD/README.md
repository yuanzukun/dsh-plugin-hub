# dsh-git-graph

🌏 中文 · [English](./README_EN.md)

> 🧭 **一句话定位：DSH 生态里开箱即用的 Git 可视化工具。** 在 DeepSeek Harness 对话界面内直接嵌入 GitHub 风格的提交历史图、分支管理、代码 Diff 与 VSCode 风格未提交改动面板——AI 开发时不用再切到别的 Git 客户端。

DeepSeek Harness（DSH）Web GUI 的嵌入式 Git 仓库图谱可视化插件。

在对话界面里直接查看、浏览、管理 git 仓库：提交历史图、分支过滤、提交详情、文件 diff、工作区状态、右键 git 操作，全部内嵌在 harness 界面中，无需离开当前对话。提交图一目了然，未提交改动像 VSCode 一样分组展示，一眼看清"改了什么、谁改的、要不要提交"。

**适合谁**：用 DeepSeek Harness / DSH 做 AI 编程、Agent 开发的开发者；想在同一个界面里同时看清提交历史、分支、工作区改动的 Git 用户；需要比命令行更直观的 Git 可视化工具的开发者与团队。

> 🔍 搜索关键词：DSH 插件 · DeepSeek Harness 插件 · Git 可视化 · Git 图谱 · 提交历史图 · 分支管理 · 代码 Diff · VSCode 风格改动面板 · Git 效率工具 · AI 编程助手

> 🛠 本项目由 AI 辅助开发（AI-assisted development）。

![Git 图谱](https://img.shields.io/badge/DSH-Plugin-58a6ff)

## 📸 效果预览

<img src="assets/git-graph-demo.png" alt="Git 图谱演示" width="720">

## ✨ 功能

- **提交历史图**：GitHub 风格提交列表，分支分组折叠、分支着色（本地与远程分支各有独立分组）
- **跟随当前对话（自动识别工作区）**：自动定位当前对话的工作目录（v0.13 修复会话工作区识别）并显示其中的 git 仓库，切换对话自动跟随；非 git 仓库的对话显示空态提示，并可「🖥 在当前对话目录下查找 Git 仓库」一键扫描工作区及其子目录中的仓库（v0.13）
- **📂 打开文件夹（v0.11）**：不局限于当前对话工作区——点击顶栏「打开」或在空态中点「打开文件夹」，可浏览磁盘（驱动器 → 目录逐层进入，带 git 标记），选择任意文件夹（如另一个工作区的仓库 B）查看其版本管理；添加过的仓库持久保存，顶部下拉随时切换，刷新后仍可继续查看
- **分支过滤**：勾选 = 显示该分支 · 不勾 = 完全隐藏（全部不勾选则列表为空）
- **提交详情**：提交信息、文件变更列表、单文件 diff、两次提交对比（Ctrl+点击）、📜 文件历史（查看单个文件的所有历史提交）
- **未提交改动（VSCode 风格，常驻图谱顶部）**：已暂存 / 更改 / 未跟踪三组文件列表、状态徽标（A/M/D/R/U/?）、每文件 +/− 行数、点击行展开单文件 diff（语法高亮）、重命名 `旧 → 新`、未跟踪文件直接显示内容；☑ 分组开关可单独隐藏某组，面板与分组均可点击折叠；**每行可 暂存/取消暂存/还原，顶栏 全部暂存/提交，勾选复选框可批量 暂存选中/取消暂存选中/还原选中/忽略选中/提交选中**（破坏性操作执行前弹确认框）；提交对话框内可 **✨ AI 生成提交信息**（依据 diff 自动生成候选，可编辑）
- **右键菜单**：复制哈希/消息、查看详情、🏷️ 打标签（可改名/删除）、🌿 从提交新建分支、🌐 打开 GitHub 提交页、复制仓库路径、在文件管理器中打开
- **远程/分支操作**：顶栏 `⬇ 拉取`（git fetch）与 `⬆ 推送`（git push 当前分支，确认后执行）；分支组头右键——本地分支可 🔄 切换 / ⬆ 推送 / 🗑️ 删除（已合并才可删，HEAD 受保护），远程分支可 ⬇ 拉取 / 复制远程分支名
- **远程分支可见**：远程分支组头始终显示（即使与本地完全同步），并标注「已同步」/「已包含」状态
- **自动更新（按挂载形态降级）**：常规安装时打开图谱静默检查 GitHub 最新版本，发现新版本顶栏显示「🔄 新版本 vX.Y」，一键自动下载并替换插件文件（自动备份旧版，失败自动回滚），重启后生效；以 git 工作区（`link:`）挂载时自动隐藏更新按钮，改为提示 `git pull`，绝不改写 git 管理的文件
- **状态记忆**：分支过滤、☑ 分组开关、面板/分组折叠状态、主题自动保存，刷新后保留（v0.8 起键统一为 `gg2-*`，首次打开分支默认全部展开）
- **多仓库切换**：图谱页头部下拉快速切换多个仓库
- **大仓库优化**：提交列表分页加载（200 条/页 + 加载更多），上万提交也不卡
- **键盘快捷键**：`Ctrl+F` 搜索、`Ctrl+/` 快捷键面板、`Ctrl+B` 折叠/展开全部分支组、`↑↓`/`j`/`k` 导航、`Enter` 详情、`Esc` 关闭
- **自动刷新**：页面可见时每 5 秒监听工作区改动与新增提交，自动更新统计与列表
- **主题系统**：自动跟随 / 深色 / 浅色，外加 **8 种风格方案**（与拾光记同款）——🌸 樱花（飘落花瓣）、🌊 海洋（波浪/气泡/鱼群）、🌲 森林（树木/落叶/萤火虫/蝴蝶）、🌙 夜空（星星/月亮/流星）、🍬 糖果（彩虹/彩带/棒棒糖）、💼 商务（几何/玻璃浮块）、✨ 星河（繁星/月亮/流星/地球）、🤖 科技（电路/齿轮/芯片），每种风格自带专属动态背景（海洋/科技/商务/糖果元素密度更高）
- **挂载位置**：会话页内「Git 图谱」标签（位于「轨迹」标签旁）

## 📦 安装

### 方式一：官方 CLI 一键安装（推荐）

```bash
# 从 GitHub 安装
dsh plugin --profile web add github:1841220388zzzcccxxx-star/dsh-git-graph

# 或从 npm 安装（scope 包名，见下方「发布渠道」）
dsh plugin --profile web add @1841220388zzzcccxxx-star/dsh-git-graph
```

装完重启 `dsh web` 即生效。命令会自动把插件注册进 profile 的 bundle 层（`dsh.profile.bundles`），并按 `peerDependencies["@deepseek-ai/dsh"]` 校验与你本机 DSH 的兼容性——不满足会拒绝安装并给出原因。

### 方式二：本地目录直挂（开发者 / 离线）

```bash
dsh plugin --profile web add link:<本插件仓库路径>
```

`link:` 直接挂载仓库目录，改完代码重启 `dsh web` 即可看到效果（无需复制文件）。

### 可选：固定仓库白名单

默认**无需任何配置**——图谱自动发现当前会话工作区中的 git 仓库，也可用图谱页顶栏「📂 打开」浏览并添加任意文件夹的仓库（添加过的仓库会记住）。如需固定白名单，在 profile 的 `cordis.patch.yml` 里为插件行加 `config`：

```yaml
- insert:
    - id: git-graph
      name: dsh-git-graph
      config:
        repo: "C:/path/to/your/repo"   # 或 repos: [ ... ] 数组
```

打开 http://127.0.0.1:3080 ，在任意会话页内点「Git 图谱」标签（位于「轨迹」标签旁）即可查看。

> **权限与来源说明**：本插件会在你授权的目录内执行只读的 `git` 命令（图谱/差异/日志），
> 写操作（暂存/提交/推送等）均需你在图谱页内逐次确认。**自更新按挂载形态自动降级**：
> 以 git 工作区（`link:`）形式挂载时不提供一键自更新（避免改写你 git 管理的文件），
> 请在插件仓库目录 `git pull` 升级；其他安装形态保留 GitHub 一键自更新（有备份回滚）。
> 兼容范围声明与隔离实测证据见 [docs/compatibility.md](docs/compatibility.md)，
> 发版前可用 `node scripts/check-compat.mjs` 检查是否覆盖官方 latest/next 发行窗口。

### 发布渠道

- **GitHub**：本仓库已带 `dsh-plugin` topic，`dsh plugin add github:…` 直装
- **npm**：`@1841220388zzzcccxxx-star/dsh-git-graph`（以 `npm whoami` 得到的 scope 发布；发布前跑 `npm run publish:npm` 做检查链）

### 兼容范围

声明于 `package.json`：`engines.dsh` 与 `peerDependencies["@deepseek-ai/dsh"]` 均为 `>=0.1.0-rc.6 <0.3.0`。隔离实测（独立 `DSH_HOME`，add → dump-config → remove 全链路）通过版本：**0.1.7-rc.2**（latest 稳定线）与 **0.2.0-rc.1**（next 预览线），证据见 [docs/compatibility.md](docs/compatibility.md)。

## 🖱️ 使用

| 操作 | 说明 |
| --- | --- |
| 会话页「Git 图谱」标签 | 在该对话内查看图谱（跟随当前对话工作区） |
| 📂 打开 / 空态「打开文件夹」 | 浏览磁盘选择任意 Git 仓库（如其他工作区的文件夹 B），添加后显示其版本管理（v0.11） |
| 顶部仓库下拉 | 切换仓库；旁边小字显示当前仓库完整路径 |
| 分支组标题 | 点击折叠 / 展开该分支 |
| ☑ 分支过滤 | 勾选 = 显示该分支，不勾 = 完全隐藏 |
| 图谱顶部「未提交改动」区块 | 已暂存/更改/未跟踪一览（含未跟踪文件），点击行展开 diff；☑ 分组可隐藏某组；点击顶栏或组标题折叠；行内「暂存/取消暂存/还原」，顶栏「全部暂存/提交」，勾选复选框批量 暂存/取消暂存/还原/忽略/提交 |
| 提交行 | 点击查看详情，Ctrl+点击与另一提交对比 |
| 提交行右键 | 复制 / 查看详情 / 打标签 / 从提交新建分支 / 打开 GitHub 提交页 / 复制仓库路径 / 打开文件夹 |
| 提交详情里的 📜 | 查看该文件的历史提交 |
| 底部状态栏「未提交改动」 | 点击滚动到顶部改动区块 |
| ↻ 刷新 | 重新加载仓库数据 |

## 🛠️ 开发

```
git-graph/
├── index.js          # 服务端：git API（graph/branches/workstatus/workfile/diff/...）
├── client.js         # 客户端插件：会话页「Git 图谱」标签
├── web/index.html    # 图谱界面（iframe 内独立页面）
├── package.json      # 插件清单（dsh.client + bundle patch + peerDependencies）
├── cordis.patch.yml  # profile 挂载点
└── scripts/          # check-compat.mjs / publish.mjs / compat-isolated-test.ps1
```

开发工作流（单一真源 = 本仓库，profile 以 `link:` 直挂）：

```bash
# 首次挂载（此后改代码不需要重复此步）
dsh plugin --profile web add link:<本仓库路径>

# 改动后
node --check index.js client.js   # 语法检查（web/index.html 内联脚本同法）
# 重启 dsh web 生效（index.js / client.js 改动需重启；web/index.html 刷新即生效）
```

发版流程：`npm run check:compat`（官方窗口覆盖检查）→ `pwsh -File scripts/compat-isolated-test.ps1`（锚点版本隔离实测）→ 版本号 +1 → `npm run publish:npm`（scope 改名后）→ `git commit` → `git tag vX.Y` → push。

## 📄 开源协议

[MIT](./LICENSE)

## 🙏 致谢

- [DeepSeek Harness](https://github.com/deepseek-ai/) —— 插件运行平台
