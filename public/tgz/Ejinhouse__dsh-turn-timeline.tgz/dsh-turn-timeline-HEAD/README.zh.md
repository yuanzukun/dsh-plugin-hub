# dsh-turn-timeline

左侧栏「任务时间线」面板：把一个会话里做过的**每一轮**摊开成时间线，让你不必滚 200 条消息去找"那个任务是在哪一轮做的"。

## 它解决什么

DSH 的会话是线性的。一个会话里干了好几件事（调研 → 装插件 → 修 bug），一周后只记得最后一次结果，前面的工作埋在第 3 轮里。这个插件把会话折叠成"任务段 + 轮次 + 该轮产出的文件"，点文件直接在右侧预览。

## 截图

| 轮次视图 | 台账视图 | 面板内预览 |
| --- | --- | --- |
| <img src="assets/timeline-turns.png" width="300" alt="一轮一行：工具用量、产出文件 chip、交付物标"> | <img src="assets/timeline-ledger.png" width="300" alt="展开台账：待办、待核实、负责人与天数"> | <img src="assets/timeline-preview.png" width="300" alt="右键文件 chip，在面板内预览该文件"> |

截图来自一个虚构的演示工作区，不含任何真实会话数据、路径或台账原文；头行的 `1.0.0 bs sb` 服务标记在截图里隐藏了。

## 长什么样

- 左侧栏图标（在"常用"上方，可钉住）→ 点开成为一栏面板。
- **会话列表**：当前工作区的所有会话，倒序；标题取日志里**最后一条** `session/title`——也就是工作区会话列表显示的摘要名——确实没有才退回第一句用户消息 / 短 id。
- 展开一个会话 → **任务段**（连续几轮合为一段）+ 每轮的 #轮次号、那句话的首行作为任务名、工具用量。
- 每轮下方是**该轮产出的文件**（chip）→ 左键跳回产出它的那一轮并在右侧栏打开，右键在本面板内预览（有 better-sidebar 用它的编辑器，否则用内建预览）；右侧栏拒绝时（面板占着主区、会话不在屏上），同一个面板内退化为只读预览，左上角 `←` 返回。
- 输入框筛选会话；⟳ 重新拉取。

## 用法

1. 左侧栏点「任务时间线」打开面板；按工作区列出会话，展开会话看到任务段与轮次。
2. **左键点产出文件**：跳到该文件所在的会话 → 滚动并闪烁高亮产出它的那一轮 → 在该会话的右侧栏打开文件。这段时序是刻意排的：右侧栏是"每会话一张脸"，只有会话在主区时才有可绘制的位置，所以必须先切过去再开文件。如果这一轮本来就在屏上，则**不重挂会话视图**——重挂会重新加载历史，而有历史缺陷的会话（例如升级后 subagent 描述符对不上）正是重挂时才会报错。
3. **右键点产出文件**：不跳转，直接在面板内预览（markdown 排版、代码逐行着色、图片内嵌）。
4. 面板右上角 `⧉`：把当前预览的文件推给右侧栏并切回会话；`A−`/`A+` 调整面板字号（记忆在本机）。
5. **右侧栏缩放**：把鼠标放在右侧栏上，`Ctrl+滚轮` 缩放（0.6–2.4 倍，记忆在本机；`Ctrl+Alt+=`/`-`/`0` 是等效的键盘入口）。它用 CSS `zoom` 缩整块右栏视口，markdown、代码、图片、表格一起变，不受右侧预览插件自己的字号设置影响；鼠标在别处时 `Ctrl+滚轮` 仍是页面缩放。
6. **子代理会话**默认折在列表底部的「▸ 子代理会话 (N)」里：它们是父会话的细节，父会话不在线时只读、且不能重挂；展开后会带上「子代理」标签。
7. 会话行的标题取会话日志里**最后一条** `session/title`——即工作区会话列表显示的摘要名；只有 Harness 从未写过标题时才退回第一句用户消息。Host 侧缓存，并在收到新的 `session/title` 时失效重算，所以**重进面板不会再退回序列号**；确实没有内容的空会话才显示短 id。首次加载会花一两秒补齐标题，之后是 20ms 级。
8. 头行的 `1.0.0 bs sb` 是版本与服务标记：`--` 表示对应服务没注入成功。

## 数据从哪来

| 用途 | 来源 |
| --- | --- |
| 轮次边界、用户原话、工具用量、`present` 交付物 | `ctx.sessionQuery.readSession(id)` 的原始事件（不是折叠过的 surface） |
| 该轮改动的文件（含 shell 创建的文件） | turn-rewind 的 change ledger：`勾选点 N vs N+1` 的 manifest diff |
| 直接写文件类工具的 `file_path` | `tool/call` 的 `write`/`edit` 等参数 |

ledger 缺失时自动降级，只列文件工具写过的文件。

## 未关闭事项台账（1.1.0）

时间线回答"发生了什么"，台账回答"**还欠什么**"。前者能从会话日志重建，后者丢了就是丢了——所以台账的真源留在工作区 markdown 里，插件只读、从不写入。

面板顶部多一条「未关闭项」，数据来自两个地方：

| 来源 | 路径 | 写什么 |
| --- | --- | --- |
| 全局池 | `<工作区>/50-knowledge/OPEN-ITEMS.md` | 跨会话、项目级的事 |
| 会话笔记 | `<工作区>/10-sessions/<会话目录>/NOTES.md` | 只跟某次会话有关的事 |

只解析 ```` ```ledger ```` 围栏里的行，块外的散文一律忽略（所以笔记可以随便写）。两处出现同一个 id 时以全局池为准，只算一次。行的格式：

```ledger
- [ ] L-0007 | 待核实 | 良品率98.2%无来源 | owner=你补 | 2026-11-12 | 会话=20261112_1504 轮=12
- [x] L-0006 | 待办 | 建会话目录模板 | owner=AI | 2026-11-12 | 关闭=2026-11-12 已交付
```

- 点条目 → 面板内打开它的原文；`⧉` → 打开本工作区的 `OPEN-ITEMS.md`。
- 未关闭且超过 14 天 → 标「陈」；解析失败的行不猜，只计数标红，点开原文自己看。
- 工作区下拉框里带未关闭数（`· 3 未关闭项`），换工作区前就知道那边欠着什么。

## 限制（诚实版）

- **最后一轮永远不完整**：ledger 的检查点记的是"本轮开始前"，最后一轮还没有下一个检查点可 diff。
- **跨会话**：ledger 按 workspace 存，会话按 sessionId 过滤；子代理会话不写 ledger。
- **工作区非 git / 没装 turn-rewind**：没有 ledger，只剩 write/edit 的清单（`pwsh` 创建的文件不会出现）。
- 面板只读会话日志，不修改、不压缩、不调用模型（默认零 token）。
- **会话自己的聊天记录坏了不归它管**：若某个会话在聊天区报 `历史加载失败：subagent descriptor is unavailable`，那是宿主重挂该会话时解析不出 subagent 描述符（多见于升级后重开旧会话），时间线照样能从日志里列出它的轮次与文件；点文件时会先尝试在现有视图里定位，定位不到才切会话。
- **台账徽标只做到工作区级**：DSH 的 sessionId 与 `10-sessions\<目录名>` 没有可靠对应关系，所以不往会话行挂徽标，只在工作区与顶部汇总处显示计数。

## 安装

**从插件市场（推荐）**：打开左侧栏的市场（dshmarket），搜 `任务时间线` 或 `timeline`，点安装。

**命令行**：

```powershell
dsh plugin --profile desktop add "https://github.com/Ejinhouse/dsh-turn-timeline/releases/latest/download/dsh-turn-timeline.tgz"
```

装完**完全退出并重开**桌面端；新面板出现在左侧栏，图标是一个时钟。

> 需要 DSH 0.2.x。插件零依赖、不发网络请求、不调用模型。

## 结构

- `lib/index.js` — host 半边：`/turn-timeline/index`、`/turn-timeline/session/<id>`、`/turn-timeline/file?session=&path=` 三个只读路由，加 1.1.0 的 `/turn-timeline/ledger` 与 `/turn-timeline/ledger/file?cwd=&path=`；手写、零依赖。`/file` 只读"该会话自己产出过的路径"，不会变成通用文件读取器；>512KB 或二进制直接拒绝。`/ledger/file` 只放行 `50-knowledge/OPEN-ITEMS.md` 与 `10-sessions/*/NOTES.md` 两种路径，并做越界检查。
- `lib/ledger.js` — 台账解析器：纯函数、零依赖、无 DSH 运行时依赖，可以用裸 node 直接跑单测。只认 ```` ```ledger ```` 区块，解析失败降级为 `errors`，绝不猜。
- `lib/client.js` — 浏览器半边：注册 `main` 面板 + `sidebar.panellist` 图标，`window.__ModuleLoader__` 手写 bundle，无构建步骤。
- `cordis.patch.yml` — bundle 插入声明。


## 整理与管理（0.2.0）

面板里现在能自己搭结构，不再是被动列表：

- **新建文件夹**：工具条 `＋ 新建文件夹`，输入名字回车。文件夹永远显示（空文件夹也能当投放目标）。
- **拖动归类**：按住会话行拖到文件夹名上松手即归入；拖到「未分类」= 取消归类。
- **重命名**：会话行 `✎` 给会话起自己的名字（优先于日志标题）；文件夹名**双击**可改。名字都会持久化，重启后还在。
- **移除**：会话行 `×` 把它从时间线挪走——**不删会话、不删日志**，只是不再是时间线的条目。
- **找回**：工具条 `▸ 未进入时间线 (n)` 是被移除的会话池，点 `＋` 加回来。
- **自动收录**：新会话默认就在时间线里（除非被移除），刷新 `⟳` 即可看到。

数据存在 `$DSH_HOME/storages/turn-timeline-v1.json`（默认 `~/.dsh/storages/`），只记"文件夹 + 每个会话的名字/归类/是否移除"，不复制任何会话内容；宿主重启后自动读回。

路由新增两个（`lib/index.js`）：

```text
GET  /turn-timeline/layout            → { folders, items }
POST /turn-timeline/layout            → { op: folder.create|folder.rename|folder.delete|item.assign|item.rename|item.remove|item.restore, ... }
```

`POST` 只接受 ≤64KB 的 JSON，写入走"临时文件 + rename"，写一半断电不会留下半个布局文件。


## 源码与发布

- 仓库：<https://github.com/Ejinhouse/dsh-turn-timeline>
- 推一个 `v*` tag，GitHub Actions 会自动打包并挂到 Release：`dsh-turn-timeline.tgz`（npm 布局，`package/` 前缀，资产名不带版本号，`releases/latest/download/` 永远可解析）
- 包内只有 `package.json`、`cordis.patch.yml`、`lib/*.js`、两份 README、CHANGELOG、LICENSE —— 没有构建产物、没有依赖、没有 node_modules。

## 卸载

```powershell
dsh plugin --profile desktop remove dsh-turn-timeline
```
