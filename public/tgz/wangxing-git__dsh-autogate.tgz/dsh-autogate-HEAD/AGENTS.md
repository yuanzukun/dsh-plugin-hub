# AGENTS.md — dsh-autogate

DeepSeek Harness 自动审批插件。在 **workspace-write 沙箱之上** 增加 Auto 权限档，采用「L0 确定性规则 + L1 LLM 安全审批 + L2 被拒绝方主动人工审批」分层决策。保留工作区沙箱边界，不放宽为 full-access。

> 本文件是项目级 agent 指令。DSH 全局规则位于 `~/.dsh/AGENTS.md`，本文件只记录本项目特有约定；本机环境事实（DSH_HOME、settings.yaml 位置等）归 `AGENTS.local.md`（若不存在则按需创建，无本机特殊事实时保持缺失即可），禁止硬编码进本文件或源码。

## 核心安全约束（最高优先级，不可违反）

1. **fail-closed**：分类器异常 / 超时 / 无路由 / 输出格式错误一律拒绝（deny），不得退化为放行。
2. **沙箱保持 workspace-write**：任何改动都不得放宽为 full-access；即使 LLM 误判放行，文件写入仍由沙箱拦截 + escalation 兜底。
3. **分层不可颠倒**：L0 硬 deny（提权、系统级自毁（shutdown/reboot/halt/poweroff/mkfs 等；进程杀手 killall/pkill/taskkill/stop-process 已降级 L1 语义审查）、凭据外传、文件系统根与系统/凭据关键路径（/usr/local 除外）的变更/删除、家目录根删除）必须同步返回、后续监听器无法覆盖；家目录根变更、DSH_HOME 与 /usr/local 的变更/删除属可授权操作，走工作区外通用路径（沙箱拦截 + escalation 审批）。L1 只在「沙箱不拦截但语义危险」时由 LLM 两态裁决；L2 由被拒绝方（AI）主动向用户发起，插件不主动弹窗。
4. **脱敏与限界**：进入 LLM 分类器的输入必须经 `sanitizeClassifierArguments` / `sanitizeClassifierText` 处理；唯一的授权依据是「最近的直接人类消息」与 `ask_user_question` 的问答对（回答是用户授权、问题仅提供上下文），不得引入其他上下文。
5. **`preflight` 开关（默认 `false`）**：关闭时跳过普通 L0 规则与 L1 LLM 分类，完全依赖沙盒策略；L0 硬 deny（guard）与审批请求预审（approval/request：escalation 提权 + 工具自身 ask）始终生效，不受开关影响。改动 pre-execute 判定顺序时不得破坏这一边界。

## 常用命令

| 命令 | 说明 |
|------|------|
| `npm run build` | 编译（tsc + 客户端 bundle 构建） |
| `npm run typecheck` | 仅类型检查，不产出 |
| `npm test` | vitest 全量测试 |

环境要求 Node `>=22.19.0`。构建产物 `lib/` 由 `build` 生成，**禁止手改**；改动只写在 `src/`。

## 目录结构

```
src/
  index.ts        入口：guard + tools/pre-execute 两态判定 + 审批请求预审（escalation 提权 + 工具自身 ask）+ 轨迹 RPC
  policy.ts       工具级确定性规则（L0）与危险识别
  shell.ts        bash/pwsh 静态分析（L0 硬 deny + 危险 shell 识别）
  classifier.ts   LLM 分类器（DSH 内部 LLM / 可选 HTTP 端点）+ 脱敏 + 系统提示词
  paths.ts        路径规范化（含 symlink realpath 加固）、危险路径判定、工作区根解析
  trail.ts        审批轨迹（进程级环形缓冲，只增不持久化）
  types.ts        共享类型（Assessment / ClassifierInput / ClassifierDecision / SafetyClassifier）
  client.tsx      插件页配置表单 + 审批轨迹面板（客户端 bundle）
tests/            与 src 模块一一对应的 *.spec.ts
scripts/
  build-client.mjs   客户端 bundle 构建脚本
  fix-session-zstd.py 会话 zstd 修复脚本
cordis.patch.yml   权限预设表（插入 auto-ask 半自动 + auto-full 全自动档，sandbox=workspace-write）
lib/               编译产物（由 build 生成并纳入版本控制，勿手改）
```

## 编码约定

- **TypeScript 严格模式**：`strict: true`、`module: NodeNext`、`moduleResolution: NodeNext`、`verbatimModuleSyntax: true`。
- **相对导入必须带 `.js` 后缀**（NodeNext 约定）：`import { assessTool } from './policy.js'`。
- **类型导入用 `import type` / `export type`**（verbatimModuleSyntax 要求，运行时类型必须显式标注）。
- **用字符串字面量联合类型，不用 enum**：如 `type ApprovalDecision = 'allow' | 'deny' | 'ask'`。
- **中文注释与 JSDoc**：新代码的注释、类型说明、拒绝原因（`reason`）用简体中文。
- **共享类型集中到 `types.ts`**，模块间引用其类型而非重复定义。

## 测试约定

- 测试框架 vitest，文件放 `tests/<module>.spec.ts`，与 `src/` 模块一一对应。
- **改动任何规则 / 分类逻辑必须同步增补或更新测试**：L0 规则对应 `policy.spec.ts` / `shell.spec.ts` / `paths.spec.ts`；分类器对应 `classifier.spec.ts`；配置对应 `settings.spec.ts`；入口集成对应 `index.spec.ts`。
- 测试中构造 `ToolExecution` 用最小字段 mock（参考 `tests/policy.spec.ts` 的 `execution()` 辅助函数）。
- 路径判定测试使用显式根（`resolveRoots('/ws', { home })`），不依赖本机真实路径。

## 修改指引（按改动位置）

| 改动 | 文件 | 同步动作 |
|------|------|---------|
| L0 确定性规则 | `policy.ts` / `shell.ts` / `paths.ts` | 更新对应 spec |
| LLM 分类逻辑 / 系统提示词 | `classifier.ts`（含 `CLASSIFIER_SYSTEM_PROMPT`） | 更新 `classifier.spec.ts` |
| 配置项 | `index.ts` 的 `Config` schema | 同步 README「配置」段 + 设置卡（client.tsx） |
| 审批轨迹字段 | `trail.ts` | 更新 `trail.spec.ts` |
| 客户端 UI | `client.tsx` | 重新 `npm run build` 验证 bundle |

## 关键不变量（review 时核对）

- 新增「危险操作」类别时，确认其落入 L0 硬 deny 还是 L1 分类，并检查脱敏是否覆盖。
- 新增配置项必须：`z.object` 校验（含 default / min / max / pattern 约束）+ README 文档 + 插件页配置表单（`client.tsx` 的 `SafeAutoCard`）。
- **授权判定只读投影，禁止新增同步事件读取**：`Session.snapshotEvents` / `eventAt` / `ownEvents` 自 DSH 0.1.6 起弃用（官方 agent note `2026-09-09-deprecate-synchronous-session-event-reads`），Session 实现仍保留内存事件序列属过渡态。权限档一律经 `PermissionPresetResolver` 读取（生产实现为 `ctx.sessionProjections.stateOf(session, 'autogatePermission')`，投影单元见 `applyAuthorizationPreset`）；工具参数回退走 `session/event` 订阅维护的 `toolCallArguments` 缓存。**全插件仅 `trustedUserMessages` 一处保留同步历史读取**（需问答对跨事件配对与「紧邻前一条 assistant」的邻接关系，非投影可表达），已就地附豁免论证，**不得据此新增同类调用**。
- **授权投影必须保留 source 语义**：`applyAuthorizationPreset` 跳过 `source === 'autogate'` 的继承标记。改用官方 `permissions` 投影会丢失该区分（官方单元只取 `data.preset`），使子代理会话的继承标记成为授权依据、放宽授权。
- 轨迹为进程级环形缓冲（默认 200 条），只增不持久化，重启即清空；不得引入持久化副作用。
- **`approval/request` 监听器必须 `{ prepend: true }` 注册**：本插件 bundle 的 `insert` 无锚点、落在 api-gateway（dsh-host-apiproxy）之后加载，不 prepend 则被 host-apiproxy 的 UI answerer 抢先 claim，LLM 预审（L2）永不执行。
- **配置界面注册在插件管理页的 `plugins.bundle.config`（keyed by bundle 包名 `dsh-autogate`）**：DSH 0.1.6-alpha.2 已移除设置页的 `settings.plugin.item` 槽；宿主以 `view: 'page'` 调用（`summary` 分支按契约保留但当前不触发）。slot 名或 key 写错**不报错、不留日志**，只是配置界面静默消失——改这里必须走 UI 实测验证（见 `BUNDLE_CONFIG_SLOT` / `BUNDLE_PACKAGE_NAME` 注释）。
- **客户端「当前会话」必须读 `ctx.uiSession.adapter.current`**：DSH 0.1.6-alpha.2 起 `SessionListState` 已移除 `current` 字段（官方注释 `navigation belongs to view owners`），改读官方会话作用域适配器 `SlotScopeAdapter.current` 的 binding，取 `props.sessionId ?? key`（无选中时是缺席投影）。客户端 `ctx` 为 `any` 类型、**typecheck 覆盖不到**，此类字段移除只会静默失效（轨迹浮窗退化为「显示全部」）——禁止再用 `sessions.list.getSnapshot().current`。
- **子代理权限继承必须挂 `agent/created`，禁止在 `session/created` 派发窗口写 Session**：DSH 0.2.2 起 `SessionStore.announce` 先置 `announcement='dispatching'` 再**同步**派发 `session/created`，该窗口内 Session 只读——任何 `session.append`（含 `setApprovalPolicy`）都会抛 `cannot append before session/created completes`，监听器抛错使 announce 失败、整个子代理创建回滚（症状：任何 `subagent`/`workflow` 调用直接报该错）。`agent/created` 在 session announce 与 setup（dsh-subagent 于此后追加 delegation 的 `approval=never`）之后**串行**派发，Session 已可写，且早于子代理首次工具调用，后写的 `ask` 稳定覆盖 `never`；官方 `dsh-permission-presets` 同样在此事件用 `{ prepend: true }` 补写 `permission/preset`。写入必须 try/catch 兜底（串行派发抛错会阻断创建，失败即保持 DSH 默认 `never`）。
- 对 `cordis.patch.yml` 的修改仅限权限预设与插件注册段，保持 auto-full 档 `sandbox: workspace-write`。
