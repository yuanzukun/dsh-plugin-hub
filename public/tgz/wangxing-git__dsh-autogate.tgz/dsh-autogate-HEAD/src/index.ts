import type { Context, Volatile } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { z as zod } from 'zod'
import type { LlmCallConfig } from '@deepseek-ai/dsh-llm'
import type { PreToolDecision, ToolExecution } from '@deepseek-ai/dsh-tools'
import { CLASSIFIER_SYSTEM_PROMPT, createDshClassifier, createHttpClassifier, extractEscalationJustification, isEscalationApprovalReason, sanitizeClassifierArguments, sanitizeClassifierText, sanitizeClassifierTextTail } from './classifier.js'
import { resolveRoots, type RootOptions } from './paths.js'
import { assessTool, hardDenyReason, isSandboxEscalationRetry, summarizeToolArguments } from './policy.js'
import { setApprovalPolicy, type ApprovalOutcome } from '@deepseek-ai/dsh-user-approval'
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session'
import type {} from '@deepseek-ai/dsh-settings'
// 引入 declaration merging：'loader/volatile-update' 事件类型（配置热更新派发）由 loader 扩展。
import type {} from '@deepseek-ai/cordis-plugin-loader'
// 引入 declaration merging：'permission/preset' 事件类型由 dsh-permission-presets 扩展到 SessionEventMap。
import type {} from '@deepseek-ai/dsh-permission-presets'
// 引入 declaration merging：ctx.sessionProjections 服务与 SessionProjectionStateMap（本插件的授权投影 key）。
import type {} from '@deepseek-ai/dsh-session-projection'
import type { ClassifierInput, ClassifierTokenUsage, ManagedMode, SafetyClassifier } from './types.js'
import { createApprovalTrail, type ApprovalDecision, type ApprovalLayer } from './trail.js'
import type { UiLocale } from './i18n.js'

export * from './paths.js'
export * from './policy.js'
export * from './shell.js'
export * from './classifier.js'
export type * from './types.js'
export * from './trail.js'

export const name = 'autogate'
export const inject = ['tools', 'llm']

/**
 * Fetch 路由最小契约（运行时由 dsh-client-connection 提供的 connection 服务；
 * 仅声明本插件用到的形状，避免引入 client 端运行时依赖）。服务端连接服务始终存在，
 * 缺失时（极端环境）跳过轨迹查询端点即可——用 ctx.get 可选读取，不声明 inject。
 *
 * 迁移说明：DSH 0.1.5 起 connection.rpc.handle() 内部经 service 自身的 ctx 访问
 * webServer 注册路由，而 connection 插件只 inject 'credentials'（webServer 不可达），
 * 该 API 注册必失败（症状：端点 405 / 静默缺失）。官方改用 connection.fetch 的精确
 * 路由扩展点，本插件同步迁移，与 dsh-tool-session 的事件通道同一模式。
 */
interface TrailFetchRoute {
  path: string
  methods: readonly ('GET' | 'HEAD' | 'POST')[]
  /** 请求体呈现模式（DSH 0.1.5 起必填）；本路由只读 JSON，取 buffered。 */
  requestBody: 'buffered' | 'streaming'
  fetch: (request: Request) => Promise<Response>
}
interface TrailFetchHost {
  register(route: TrailFetchRoute): () => Promise<void>
}

/** 审批轨迹查询端点路径（/api 下经共享通道认证；与 client.tsx 的请求路径保持一致）。 */
export const TRAIL_ENDPOINT = '/api/autogate/trail'

/** 从 trail 查询载荷提取 sessionId（非空字符串）；缺失或非法时返回 undefined，表示不过滤。 */
function trailSessionId(payload: unknown): string | undefined {
  if (payload === null || typeof payload !== 'object' || Array.isArray(payload)) return undefined
  const value = (payload as Record<string, unknown>).sessionId
  return typeof value === 'string' && value !== '' ? value : undefined
}

/** 解析轨迹查询请求体（JSON 对象）；空体或非法 JSON 视为不过滤，不因客户端请求格式拒绝服务。 */
async function readTrailPayload(request: Request): Promise<unknown> {
  try {
    return await request.json()
  } catch {
    return undefined
  }
}

/** 半自动权限预设键（自动但危险时转人工兜底弹窗；默认档）。 */
export const SEMI_AUTO_PERMISSION_PRESET = 'auto-ask'

/**
 * 全自动权限预设键（LLM 全权裁决，不再人工兜底弹窗）。
 * 0.1.6 起官方把 `auto` 收作实验性 Auto review 模式的保留名（执行包为
 * `danger-full-access` + `approval: never`，与本档语义相反），presets 表里
 * 出现同名键会直接抛错，故本档改用 `auto-full`。
 */
export const AUTO_PERMISSION_PRESET = 'auto-full'

/**
 * 宿主策略配置。
 *
 * DSH 0.1.7 起设置机制改为「profile 条目 Config + volatile 引用」：Loader 用
 * {@link Config} schema 校验后，把每个字段包成稳定访问器 {@link Volatile} 传入——
 * 引用身份不随配置更新改变，新值由 Loader 就地提交，读方按需 `.get()`。
 * 只有标注 `.volatile()` 的字段才进入插件配置表单（未标注的字段既不显示、
 * 写入时也会被 `Config field "x" is not volatile` 拒绝），故全部可配置项都要标注。
 *
 * 字段类型对应：schema 有 `default()` → `Volatile<T>`；无默认值 → `Volatile<T | undefined>`。
 */
export interface Config {
  /** 半自动权限预设键（默认 auto-ask）：危险操作转人工兜底弹窗。 */
  readonly presetName: Volatile<string>
  readonly workspaceRoot: Volatile<string | undefined>
  readonly tempRoots: Volatile<string[] | undefined>
  readonly classifierEndpoint: Volatile<string | undefined>
  readonly classifierProvider: Volatile<string | undefined>
  readonly classifierModel: Volatile<string | undefined>
  readonly classifierPrompt: Volatile<string>
  readonly classifierApiKeyEnv: Volatile<string>
  readonly classifierTimeoutMs: Volatile<number>
  readonly classifierMaxOutputTokens: Volatile<number>
  /** 分类器输出解析失败时静默重试一次；默认开启（temperature 0 下偶发格式抖动）。 */
  readonly classifierRetry: Volatile<boolean>
  /** HTTP 分类端点请求显式关闭思考模式（reasoning_effort: "none"）；默认开启，端点不支持该参数（如 DeepSeek 官方 API 报 400）时关闭。 */
  readonly classifierHttpDisableReasoning: Volatile<boolean>
  /** 短指代消息长度阈值（字符）：长度不超过该值的直接人类消息才携带 AI 提议上下文用于消解指代；默认 10。 */
  readonly proposalContextMaxMessageLen: Volatile<number>
  /** 单条 AI 提议上下文上限（字符）；默认 400。 */
  readonly proposalContextMaxChars: Volatile<number>
  /** AI 提议上下文总预算（字符）：多条消息的上下文合计不超过该值；默认 2000。 */
  readonly proposalContextMaxTotalChars: Volatile<number>
  /** 沙盒前拦截判断开关：true 执行普通 L0 规则 + LLM 分类，false 完全依赖沙盒（硬 deny 与提权审批不受影响）。 */
  readonly preflight: Volatile<boolean>
  /** 审批轨迹浮窗开关（默认显示）：关闭则不显示右下角浮窗，且客户端停止轮询轨迹接口。 */
  readonly showTrail: Volatile<boolean>
  /** 全自动权限预设键（默认 auto-full）：该预设下审批不再人工弹窗，LLM 裁决为最终决定。 */
  readonly fullAutoPresetName: Volatile<string>
}

// 注意：不能再写显式标注 `z<Config>` —— volatile 字段把 schema 的 mode 从 plain 改为
// volatile，与手工声明的 plain 类型不再匹配，交由 schema 自行推断（volatile 类型一致性
// 由下方 Config 接口与 .volatile() 标注的逐字段对应关系保证）。
export const Config = z.object({
  presetName: z.string().default(SEMI_AUTO_PERMISSION_PRESET).description('半自动权限预设键（默认 auto-ask）：危险操作转人工兜底弹窗').volatile(),
  workspaceRoot: z.string().description('覆盖工作区根目录（默认取会话 cwd）').volatile(),
  tempRoots: z.array(z.string()).description('信任的临时目录列表（默认系统临时目录）').volatile(),
  classifierEndpoint: z.string().description('独立 OpenAI 兼容分类端点（HTTPS；loopback 可用 http）').volatile(),
  classifierProvider: z.string().description('固定分类 provider（须与 classifierModel 成对配置）').volatile(),
  classifierModel: z.string().description('固定分类模型（须与 classifierProvider 成对配置）').volatile(),
  classifierPrompt: z.string().default(CLASSIFIER_SYSTEM_PROMPT).description('审查（分类）系统提示词').volatile(),
  classifierApiKeyEnv: z.string().default('DEEPSEEK_API_KEY').pattern(/^[A-Za-z_][A-Za-z0-9_]*$/).description('HTTP 分类端点 API Key 的环境变量名').volatile(),
  classifierTimeoutMs: z.number().default(8_000).min(100).max(60_000).description('分类器超时毫秒数，超时 fail-closed').volatile(),
  classifierMaxOutputTokens: z.number().default(1_024).min(64).max(4_096).description('分类器输出 token 上限').volatile(),
  classifierRetry: z.boolean().default(true).description('分类器输出解析失败时静默重试一次；默认开启').volatile(),
  classifierHttpDisableReasoning: z.boolean().default(true).description('HTTP 分类端点请求显式关闭思考模式（reasoning_effort=none）；端点不支持该参数时关闭').volatile(),
  proposalContextMaxMessageLen: z.natural().default(10).min(1).max(200).description('短指代消息长度阈值（字符）：长度不超过该值才携带 AI 提议上下文；默认 10').volatile(),
  proposalContextMaxChars: z.natural().default(400).min(64).max(4_000).description('单条 AI 提议上下文上限（字符）；默认 400').volatile(),
  proposalContextMaxTotalChars: z.natural().default(2_000).min(64).max(8_000).description('AI 提议上下文总预算（字符）；默认 2000').volatile(),
  preflight: z.boolean().default(false).description('沙盒前拦截判断开关：开启执行确定性规则与 LLM 分类，关闭则完全依赖沙盒策略（硬 deny 与提权审批不受影响）').volatile(),
  showTrail: z.boolean().default(true).description('审批轨迹浮窗开关：默认显示；关闭则不显示浮窗且客户端停止轮询轨迹接口').volatile(),
  fullAutoPresetName: z.string().default(AUTO_PERMISSION_PRESET).description('全自动权限预设键（默认 auto-full）：该预设下审批不再人工弹窗，LLM 裁决为最终决定').volatile(),
})

/**
 * 解包 volatile 引用后的配置值，供内部逻辑使用（等价于 DSH 0.1.7 之前的 Config 形状）。
 * 派生对象（分类器、根选项）在 {@link resolveConfig} 时一次性构造，故读取发生在业务操作之外。
 */
interface ResolvedConfig {
  presetName?: string
  workspaceRoot?: string
  tempRoots?: readonly string[]
  classifierEndpoint?: string
  classifierProvider?: string
  classifierModel?: string
  classifierPrompt?: string
  classifierApiKeyEnv?: string
  classifierTimeoutMs?: number
  classifierMaxOutputTokens?: number
  classifierRetry?: boolean
  classifierHttpDisableReasoning?: boolean
  proposalContextMaxMessageLen?: number
  proposalContextMaxChars?: number
  proposalContextMaxTotalChars?: number
  preflight?: boolean
  showTrail?: boolean
  fullAutoPresetName?: string
}

/**
 * 把 volatile 引用逐字段求值为普通配置值。每次读取都取当前值（Loader 就地提交新值到
 * 同一引用），因此重建派生态时必须重新调用本函数。
 *
 * 字段可缺省：cordis 正常注入时 schema 已填好默认值，但直接调 `apply(ctx)` 的测试路径
 * 拿到的是空对象，故用可选链兜底。
 */
function resolveConfig(config: Partial<Config>): ResolvedConfig {
  return {
    presetName: config.presetName?.get(),
    workspaceRoot: config.workspaceRoot?.get(),
    tempRoots: config.tempRoots?.get(),
    classifierEndpoint: config.classifierEndpoint?.get(),
    classifierProvider: config.classifierProvider?.get(),
    classifierModel: config.classifierModel?.get(),
    classifierPrompt: config.classifierPrompt?.get(),
    classifierApiKeyEnv: config.classifierApiKeyEnv?.get(),
    classifierTimeoutMs: config.classifierTimeoutMs?.get(),
    classifierMaxOutputTokens: config.classifierMaxOutputTokens?.get(),
    classifierRetry: config.classifierRetry?.get(),
    classifierHttpDisableReasoning: config.classifierHttpDisableReasoning?.get(),
    proposalContextMaxMessageLen: config.proposalContextMaxMessageLen?.get(),
    proposalContextMaxChars: config.proposalContextMaxChars?.get(),
    proposalContextMaxTotalChars: config.proposalContextMaxTotalChars?.get(),
    preflight: config.preflight?.get(),
    showTrail: config.showTrail?.get(),
    fullAutoPresetName: config.fullAutoPresetName?.get(),
  }
}

/**
 * 本插件写入子代理会话的权限档继承标记 source。
 * 只用于让子代理会话的权限档投影（UI 显示）与父会话一致，不是用户授权：
 * 授权解析（isAutoPermissionExecution / managedPermissionAuthority）必须跳过该标记，
 * 沿 durable parentSession 链把授权依据锚定在顶层 Auto 会话（唯一持有直接人类消息的会话）。
 */
const INHERITED_PRESET_SOURCE = 'autogate'

/**
 * 授权投影单元 key：本插件自有的**宿主专用**投影（不进客户端快照），
 * 状态为「最近一次用户真实切换的权限预设名」。
 *
 * 为什么不直接用官方的 `permissions` 投影：官方单元对 `permission/preset` 只取
 * `data.preset`，不区分 source——autogate 写入的继承标记会覆盖其 preset 值，
 * 直接用于授权判定会把子代理会话误判为 Auto 档（放宽授权）。故自持一份**保留
 * source 语义**的投影，授权依据仍锚定顶层 Auto 会话。
 */
const AUTHORIZATION_PROJECTION_KEY = 'autogatePermission'

declare module '@deepseek-ai/dsh-session-projection/types' {
  interface SessionProjectionStateMap {
    /** 最近一次用户真实切换（非 {@link INHERITED_PRESET_SOURCE} 继承标记）的权限预设名；无则为 null。 */
    autogatePermission: string | null
  }
}

/** 状态 schema：投影缓存反序列化时的校验（非法持久化状态被拒，回落到全量重放）。
 *  会话投影的 stateSchema 契约为 zod（dsh-session-projection 的 ZodType），与插件配置用的 schemastery 不同源。 */
const authorizationPresetSchema = zod.union([zod.string(), zod.null()])

/**
 * 授权投影单元的单事件转移：记录最近一次「用户真实切换」的权限预设名。
 *
 * 跳过本插件写入的继承标记（source 为 {@link INHERITED_PRESET_SOURCE}）：它只让子代理
 * 会话的权限档投影与父会话一致（UI 显示），不构成用户授权。与事件无关时返回**同一引用**
 * ——注册表以 `Object.is` 判定状态变化，同引用不产生下游工作。
 */
export function applyAuthorizationPreset(state: string | null, event: SessionEvent): string | null {
  if (event.type !== 'permission/preset') return state
  // source 是插件自有扩展字段，SessionEventMap 未声明（见 writeInheritedPreset）。
  const data = event.data as { preset: string; source?: unknown }
  return data.source === INHERITED_PRESET_SOURCE ? state : data.preset
}

/**
 * 解析一个会话的授权预设：读本插件的授权投影，key 未注册或注册表未挂载时返回 undefined。
 * 未命中一律 fail-closed（调用方视作「非托管 Auto」，不授予任何自动审批）。 */
export type PermissionPresetResolver = (session: Session) => string | undefined

/** 当前会话是否使用 Auto 权限预设（授权依据取自 `resolvePreset`，不读同步事件历史）。 */
export function isAutoPermissionExecution(
  exec: Readonly<ToolExecution>,
  resolvePreset: PermissionPresetResolver,
  presetName = AUTO_PERMISSION_PRESET,
): boolean {
  const session = exec.agent?.session
  return session !== undefined && resolvePreset(session) === presetName
}

type ParentSessionId = NonNullable<NonNullable<ToolExecution['agent']>['session']['header']['parentSession']>
type ParentAgentLookup = (sessionId: ParentSessionId) => ToolExecution['agent'] | undefined

/**
 * 解析授权本次执行的 Auto 会话。
 * DSH 把子代理 approval pin 到 never，因此沿 durable parentSession 链继承 Auto，
 * 否则子代理的工具调用会在 Auto 会话中被一刀切拒绝。
 */
export function autoPermissionAuthority(
  exec: Readonly<ToolExecution>,
  parentAgent: ParentAgentLookup,
  resolvePreset: PermissionPresetResolver,
  presetName = AUTO_PERMISSION_PRESET,
): ToolExecution['agent'] | undefined {
  if (isAutoPermissionExecution(exec, resolvePreset, presetName)) return exec.agent
  let session = exec.agent?.session
  const visited = new Set<string>()
  while (session?.header?.origin === 'subagent' && session.header.parentSession !== undefined) {
    const parentSessionId = session.header.parentSession
    const parentKey = String(parentSessionId)
    if (visited.has(parentKey)) return undefined
    visited.add(parentKey)
    const parent = parentAgent(parentSessionId)
    if (parent === undefined) return undefined
    const parentExec = { ...exec, agent: parent }
    if (isAutoPermissionExecution(parentExec, resolvePreset, presetName)) return parent
    session = parent.session
  }
  return undefined
}

/** 沿 durable parentSession 链解析执行所属的托管权限：返回授权 agent 与模式，未命中返回 undefined。 */
export function managedPermissionAuthority(
  agent: ToolExecution['agent'],
  parentAgent: ParentAgentLookup,
  resolvePreset: PermissionPresetResolver,
  semiPreset = SEMI_AUTO_PERMISSION_PRESET,
  fullPreset = AUTO_PERMISSION_PRESET,
): { agent: NonNullable<ToolExecution['agent']>; mode: ManagedMode } | undefined {
  const modeOf = (target: ToolExecution['agent']): ManagedMode | undefined => {
    const session = target?.session
    if (session === undefined) return undefined
    const preset = resolvePreset(session)
    if (preset === semiPreset) return 'semi-auto'
    if (preset === fullPreset) return 'full-auto'
    return undefined
  }
  const direct = modeOf(agent)
  if (direct !== undefined && agent !== undefined) return { agent, mode: direct }
  let session = agent?.session
  const visited = new Set<string>()
  while (session?.header?.origin === 'subagent' && session.header.parentSession !== undefined) {
    const parentSessionId = session.header.parentSession
    const parentKey = String(parentSessionId)
    if (visited.has(parentKey)) return undefined
    visited.add(parentKey)
    const parent = parentAgent(parentSessionId)
    if (parent === undefined) return undefined
    const mode = modeOf(parent)
    if (mode !== undefined) return { agent: parent, mode }
    session = parent.session
  }
  return undefined
}

/** 从配置构造根路径选项：空 tempRoots 归一化为默认（系统临时目录）。 */
function rootOptionsFrom(config: ResolvedConfig): RootOptions {
  const tempRoots = config.tempRoots === undefined || config.tempRoots.length === 0 ? undefined : config.tempRoots
  return {
    ...(config.workspaceRoot === undefined ? {} : { workspaceRoot: config.workspaceRoot }),
    ...(tempRoots === undefined ? {} : { tempRoots }),
  }
}

/**
 * schema 无法表达的跨字段/协议约束。
 *
 * DSH 0.1.7 起 settings 服务不再提供写入期 validate 钩子（写入只做 JSON 形状 +
 * schemastery + volatile 路径校验），故本函数改由 rebuild 在应用配置前调用：
 * 非法配置不生效（沿用上一份有效配置），首次加载即非法则 fail-fast 抛出。
 */
function validateConfig(config: ResolvedConfig): void {
  const hasProvider = config.classifierProvider !== undefined && config.classifierProvider !== ''
  const hasModel = config.classifierModel !== undefined && config.classifierModel !== ''
  if (hasProvider !== hasModel) throw new Error('classifierProvider 与 classifierModel 必须成对配置')
  if (config.presetName !== undefined && config.presetName === config.fullAutoPresetName) {
    throw new Error('presetName 与 fullAutoPresetName 不能相同')
  }
  if (config.classifierEndpoint !== undefined && config.classifierEndpoint.trim() !== '') {
    const endpoint = new URL(config.classifierEndpoint)
    const loopback = ['localhost', '127.0.0.1', '::1'].includes(endpoint.hostname)
    if (endpoint.protocol !== 'https:' && !(endpoint.protocol === 'http:' && loopback)) {
      throw new Error('classifierEndpoint 必须使用 HTTPS（loopback 可用 HTTP）')
    }
  }
}

function classifierFrom(ctx: Context, config: ResolvedConfig, locale: () => UiLocale | undefined): SafetyClassifier {
  const timeoutMs = config.classifierTimeoutMs ?? 8_000
  const systemPrompt = config.classifierPrompt === undefined || config.classifierPrompt.trim() === '' ? undefined : config.classifierPrompt
  if (!Number.isFinite(timeoutMs) || timeoutMs < 100 || timeoutMs > 60_000) {
    throw new Error('classifierTimeoutMs must be between 100 and 60000')
  }
  const maxOutputTokens = config.classifierMaxOutputTokens ?? 1_024
  if (!Number.isInteger(maxOutputTokens) || maxOutputTokens < 64 || maxOutputTokens > 4_096) {
    throw new Error('classifierMaxOutputTokens must be an integer between 64 and 4096')
  }
  if (config.classifierEndpoint === undefined || config.classifierEndpoint.trim() === '') {
    return createDshClassifier(ctx.llm, {
      timeoutMs,
      maxOutputTokens,
      systemPrompt,
      locale,
      ...(config.classifierProvider === undefined ? {} : { provider: config.classifierProvider }),
      ...(config.classifierModel === undefined ? {} : { model: config.classifierModel }),
      retryOnFailure: config.classifierRetry ?? true,
    })
  }
  const endpoint = new URL(config.classifierEndpoint)
  const loopback = ['localhost', '127.0.0.1', '::1'].includes(endpoint.hostname)
  if (endpoint.protocol !== 'https:' && !(endpoint.protocol === 'http:' && loopback)) {
    throw new Error('classifierEndpoint must use HTTPS (HTTP is accepted only for a loopback test service)')
  }
  const envName = config.classifierApiKeyEnv ?? 'DEEPSEEK_API_KEY'
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(envName)) throw new Error('classifierApiKeyEnv must be an environment-variable name')
  const apiKey = process.env[envName]
  return createHttpClassifier({
    endpoint: endpoint.href,
    model: config.classifierModel ?? 'deepseek-chat',
    systemPrompt,
    locale,
    ...(apiKey === undefined || apiKey === '' ? {} : { apiKey }),
    timeoutMs,
    retryOnFailure: config.classifierRetry ?? true,
    disableReasoning: config.classifierHttpDisableReasoning ?? true,
  })
}

function modelRoute(agent: ToolExecution['agent']): Pick<LlmCallConfig, 'provider' | 'model'> | undefined {
  type AgentSession = NonNullable<ToolExecution['agent']>['session']
  const session = agent?.session as (AgentSession & { requestHeader?: () => { config: LlmCallConfig } | undefined }) | undefined
  const request = session?.requestHeader?.()?.config
  if (request !== undefined) return { provider: request.provider, model: request.model }
  const provider = agent?.options?.provider
  const model = agent?.options?.model
  return provider === undefined || model === undefined ? undefined : { provider, model }
}

/**
 * 审批上下文的「授权依据」：最近的直接人类消息，以及 ask_user_question 的问答对。
 * 问答对中问题是 AI 提问（提供上下文），回答是用户选择（授权本身）；两者一并脱敏、
 * 限界后进入分类器，使分类器能识别「用户已通过问答明确授权」而不再重复人工弹窗。
 *
 * 除授权文本外，还返回每条直接人类消息紧邻前的 AI 提议文本（contexts，不可信）：
 * 当用户用极短指代（如「A」「第一个」）回应 AI 的方案列表时，分类器凭该上下文消解指代，
 * 判断用户是否明确授权了某个具体操作。上下文仅用于消解指代，绝不作授权依据。
 */
/** 提案上下文限界参数：由 Config 注入，避免硬编码。 */
interface ProposalContextLimits {
  /** 短指代消息长度阈值（字符）：长度不超过该值才携带 AI 提议上下文。 */
  maxMessageLen: number
  /** 单条 AI 提议上下文上限（字符）。 */
  maxChars: number
  /** AI 提议上下文总预算（字符）。 */
  maxTotalChars: number
}

/**
 * 取最近若干条「直接人类消息」及其指代消解上下文（AI 提议文本），作为分类器的唯一授权依据。
 *
 * 豁免说明（DSH 0.1.6 起 Session.snapshotEvents 等同步事件读取弃用，见官方 agent note
 * `2026-09-09-deprecate-synchronous-session-event-reads`）：本函数需要**完整历史序列**而非投影状态——
 * ① 授权依据是「最近的直接人类消息」，须在全量序列上倒序筛选；
 * ② ask_user_question 的问答对按 callId 跨事件配对（问题在 tool/call、回答在 tool/result），
 *    间接调用时则整段落在一处 tool/ptc-dispatch，二者都需要回看事件记录；
 * ③ 指代消解上下文是「紧邻前一条 assistant 文本」，属事件间的**邻接关系**，任何「当前值」投影都无法表达。
 * 官方 note 承认此类 genuinely-need-complete-history 的操作仍需历史读（其显式存储读路径尚未提供）；
 * 且本函数收集的是原始对话文本，迁入投影会使其落进投影缓存、构成持久化副作用，同样不可取。
 *
 * 该豁免仅限本函数：不得据此新增其它同步历史读取调用。
 */
function trustedUserMessages(authority: ToolExecution['agent'], limits: ProposalContextLimits): { messages: string[]; contexts: string[] } {
  if (authority === undefined) return { messages: [], contexts: [] }
  let remaining = 4_000

  // 第一阶段（从前往后）：建立 ask_user_question 的问答对映射。DSH 中 ask_user_question 经 run_code 间接调用，
  // 问题与回答一并落在 tool/ptc-dispatch 事件（arguments 为已解析对象、content 为标准 answers JSON）；
  // 直接调用场景则问题随 tool/call 落盘、回答随 tool/result 落盘，二者按 callId 配对。
  // 同时记录每条直接人类消息紧邻前的 assistant 文本，作为指代消解上下文。
  const askQuestions = new Map<string, string>()
  const dispatchQa = new Map<number, string>()
  const proposalContexts = new Map<number, string>()
  let lastAssistant = ''
  const events = authority.session.snapshotEvents()
  for (let index = 0; index < events.length; index += 1) {
    const event = events[index]
    if (event?.type === 'tool/call' && event.data.name === 'ask_user_question') {
      const text = askUserQuestionsText(event.data.arguments)
      if (text !== '') askQuestions.set(String(event.data.callId), text)
      continue
    }
    if (event?.type === 'tool/ptc-dispatch' && event.data.name === 'ask_user_question') {
      const question = askUserQuestionsText(event.data.arguments)
      const answer = askUserAnswerTextFromDispatch(event.data.content)
      if (question !== '' || answer !== '') {
        const combined = question === ''
          ? '[ask_user_question] 回答: ' + answer
          : '[ask_user_question] 问题: ' + question + '；回答: ' + answer
        dispatchQa.set(index, combined)
      }
      continue
    }
    if (event?.type === 'assistant/message') {
      const text = assistantMessageText(event.data.message)
      if (text !== '') lastAssistant = text
      continue
    }
    if (event?.type === 'user/message' && event.data.source.kind === 'user') {
      proposalContexts.set(index, lastAssistant)
    }
  }

  // 第二阶段（从后往前）：收集最近的直接人类消息与问答对（最近优先）。
  // 先按从新到旧收集候选（消息文本 + proposal 原文），随后在第三阶段按从旧到新分组决定
  // proposal 上下文归属：同一 AI 回复后的消息组内只要有短指代，就把上下文附给组内最早（第一条）消息。
  type CollectedMessage = { sanitized: string; short: boolean; proposal: string }
  const collected: CollectedMessage[] = []
  for (let index = events.length - 1; index >= 0 && collected.length < 8 && remaining > 0; index -= 1) {
    const event = events[index]
    if (event?.type === 'user/message' && event.data.source.kind === 'user') {
      const text = event.data.content
        .filter((block): block is Extract<(typeof event.data.content)[number], { type: 'text' }> => block.type === 'text')
        .map(block => block.text)
        .join('\n')
        .trim()
      if (text === '') continue
      const sanitized = sanitizeClassifierText(text).slice(0, remaining)
      collected.push({ sanitized, short: text.length <= limits.maxMessageLen, proposal: proposalContexts.get(index) ?? '' })
      remaining -= sanitized.length
      continue
    }
    if (dispatchQa.has(index)) {
      const sanitized = sanitizeClassifierText(dispatchQa.get(index) ?? '').slice(0, remaining)
      collected.push({ sanitized, short: false, proposal: '' })
      remaining -= sanitized.length
      continue
    }
    if (event?.type === 'tool/result') {
      const question = askQuestions.get(String(event.data.message.source.callId))
      // 只有确认该 tool/result 是 ask_user_question 直接调用的结果（tool/call 已落盘配对）才提取回答，
      // 避免从任意工具输出（如 run_code 的 stdout）误提取 answers 伪造用户授权。
      if (question === undefined) continue
      const answer = askUserAnswerText(event.data.message)
      if (answer === '') continue
      const combined = '[ask_user_question] 问题: ' + question + '；回答: ' + answer
      const sanitized = sanitizeClassifierText(combined).slice(0, remaining)
      collected.push({ sanitized, short: false, proposal: '' })
      remaining -= sanitized.length
    }
  }

  // 第三阶段（从旧到新）：按「同一 AI 回复后的连续消息」分组决定 proposal 上下文归属。
  // 组内只要有短指代需要消解，就只给组内最早（第一条）消息附上下文——不管第一条本身长短；
  // 其余消息不附，避免同一 proposal 被重复拼接浪费 token。截断保留末尾，保证 AI 最后的问询授权不被丢弃。
  const ordered = collected.reverse()
  const messages = ordered.map(item => item.sanitized)
  const contexts: string[] = new Array(ordered.length).fill('')
  let contextBudget = limits.maxTotalChars
  for (let i = 0; i < ordered.length; i += 1) {
    const proposal = ordered[i].proposal
    if (proposal === '') continue
    let j = i
    while (j < ordered.length && ordered[j].proposal === proposal) j += 1
    const needsContext = ordered.slice(i, j).some(item => item.short)
    if (needsContext && contextBudget > 0) {
      contexts[i] = sanitizeClassifierTextTail(proposal, limits.maxChars).slice(-contextBudget)
      contextBudget -= contexts[i].length
    }
    i = j - 1
  }
  return { messages, contexts }
}

/** 从 assistant/message 事件提取纯文本（仅 text block，忽略 tool-call 等其他块）。 */
function assistantMessageText(message: unknown): string {
  if (typeof message !== 'object' || message === null) return ''
  const content = (message as Record<string, unknown>).content
  if (!Array.isArray(content)) return ''
  return content
    .filter((block): block is { type: 'text'; text: string } =>
      typeof block === 'object' && block !== null &&
      (block as Record<string, unknown>).type === 'text' &&
      typeof (block as Record<string, unknown>).text === 'string')
    .map(block => block.text)
    .join('\n')
    .trim()
}

/** 从 ask_user_question 的调用参数提取问题文本：tool/call 为未解析 JSON 字符串，tool/ptc-dispatch 为已解析对象。 */
function askUserQuestionsText(rawArguments: unknown): string {
  let parsed: unknown
  if (typeof rawArguments === 'string') {
    try { parsed = JSON.parse(rawArguments) } catch { return '' }
  } else {
    parsed = rawArguments
  }
  if (typeof parsed !== 'object' || parsed === null) return ''
  const questions = (parsed as Record<string, unknown>).questions
  if (!Array.isArray(questions)) return ''
  const parts: string[] = []
  for (const question of questions) {
    if (typeof question !== 'object' || question === null) continue
    const item = question as Record<string, unknown>
    const title = typeof item.question === 'string' ? item.question.trim() : ''
    const header = typeof item.header === 'string' ? item.header.trim() : ''
    const options = Array.isArray(item.options)
      ? item.options
          .filter((option): option is Record<string, unknown> => typeof option === 'object' && option !== null)
          .map(option => {
            const label = typeof option.label === 'string' ? option.label.trim() : ''
            if (label === '') return ''
            const description = typeof option.description === 'string' ? option.description.trim() : ''
            return description === '' ? label : label + '（' + description + '）'
          })
          .filter(text => text !== '')
      : []
    if (title === '' && header === '' && options.length === 0) continue
    let text = title
    if (header !== '') text = header + (text === '' ? '' : ': ') + text
    if (options.length > 0) text += ' (选项: ' + options.join('/') + ')'
    parts.push(text)
  }
  return parts.join('；')
}

/** 从一组内容块里递归提取 ask_user_question 的回答文本（answers 以 compact JSON 文本嵌在 text block 中）。 */
function askUserAnswerTextFromBlocks(blocks: unknown): string {
  if (!Array.isArray(blocks)) return ''
  for (const block of blocks) {
    if (typeof block !== 'object' || block === null) continue
    const entry = block as Record<string, unknown>
    if (entry.type === 'text' && typeof entry.text === 'string') {
      let parsed: unknown
      try { parsed = JSON.parse(entry.text) } catch { parsed = undefined }
      if (typeof parsed === 'object' && parsed !== null) {
        const answers = (parsed as Record<string, unknown>).answers
        if (Array.isArray(answers)) {
          const text = formatAskUserAnswers(answers)
          if (text !== '') return text
        }
      }
    }
    // 嵌套 content（tool/result 的 tool-result 块内含 content 数组）。
    const nested = entry.content
    if (nested !== undefined) {
      const text = askUserAnswerTextFromBlocks(nested)
      if (text !== '') return text
    }
  }
  return ''
}

/** 从 ask_user_question 的 tool/result 消息提取回答文本（答案以 compact JSON 文本呈现）。 */
function askUserAnswerText(message: unknown): string {
  if (typeof message !== 'object' || message === null) return ''
  return askUserAnswerTextFromBlocks((message as Record<string, unknown>).content)
}

/** 从 ask_user_question 的 tool/ptc-dispatch 结果 content 提取回答文本。 */
function askUserAnswerTextFromDispatch(content: unknown): string {
  return askUserAnswerTextFromBlocks(content)
}

/** 把 ask_user_question 的回答列表格式化为可读文本。 */
function formatAskUserAnswers(answers: unknown[]): string {
  const parts: string[] = []
  for (const answer of answers) {
    if (typeof answer !== 'object' || answer === null) continue
    const item = answer as Record<string, unknown>
    const id = typeof item.id === 'string' ? item.id : ''
    const selected = Array.isArray(item.selected)
      ? item.selected.filter((value): value is string => typeof value === 'string')
      : []
    const custom = typeof item.custom === 'string' ? item.custom.trim() : ''
    const pieces: string[] = []
    if (selected.length > 0) pieces.push(selected.join(', '))
    if (custom !== '') pieces.push('custom: ' + custom)
    if (pieces.length === 0) continue
    parts.push(id === '' ? pieces.join('；') : id + ': ' + pieces.join('；'))
  }
  return parts.join(' | ')
}

/**
 * tool/call 参数缓存（执行会话侧）容量上限，与 pendingApprovalArgs 同量级：
 * 调用正常完成时条目不会被审批取回，需有界淘汰避免进程级内存增长。
 */
const TOOL_CALL_ARGUMENTS_LIMIT = 100

/**
 * 把一条 tool/call 事件折进参数缓存：事件里的 arguments 是模型产出的未解析 JSON 字符串，
 * 解析后按 callId 存放（与 pendingApprovalArgs 的值形态一致，供分类器直接使用）。
 * 非字符串或非法 JSON 一律不缓存——读取侧会回落到 reason 兜底。
 */
export function rememberToolCallArguments(cache: Map<string, unknown>, event: SessionEvent): void {
  if (event.type !== 'tool/call') return
  const raw = event.data.arguments
  if (typeof raw !== 'string') return
  let parsed: unknown
  try {
    parsed = JSON.parse(raw)
  } catch {
    return
  }
  cache.set(String(event.data.callId), parsed)
  if (cache.size > TOOL_CALL_ARGUMENTS_LIMIT) {
    const oldest = cache.keys().next().value
    if (oldest !== undefined) cache.delete(oldest)
  }
}

/** 安装自动权限策略到官方工具流水线。 */
export function apply(ctx: Context, config: Partial<Config> = {}): void {
  // 当前 UI 语言：跟随 DSH 设置语言（locale.preference）；未显式设置时回退中文，
  // 与客户端浏览器语言 fallback（中文优先）保持一致。
  let uiLocale: UiLocale = 'zh'
  // 派生态：由 rebuild() 从 volatile 引用求值（分类器与根选项是构造出来的对象，
  // 无法逐次读取，故配置变化后必须整体重建）。
  let presetName: string = SEMI_AUTO_PERMISSION_PRESET
  let fullAutoPresetName: string = AUTO_PERMISSION_PRESET
  let classifier!: SafetyClassifier
  let rootOptions: RootOptions = {}
  let preflight = false
  let proposalContextMaxMessageLen = 10
  let proposalContextMaxChars = 400
  let proposalContextMaxTotalChars = 2_000

  let built = false
  const rebuild = (): void => {
    try {
      const cfg = resolveConfig(config)
      // 原 settings 写入期校验的替代：非法配置不落地，沿用上一份有效配置。
      validateConfig(cfg)
      presetName = cfg.presetName ?? SEMI_AUTO_PERMISSION_PRESET
      fullAutoPresetName = cfg.fullAutoPresetName ?? AUTO_PERMISSION_PRESET
      classifier = classifierFrom(ctx, cfg, () => uiLocale)
      rootOptions = rootOptionsFrom(cfg)
      preflight = cfg.preflight ?? false
      proposalContextMaxMessageLen = cfg.proposalContextMaxMessageLen ?? 10
      proposalContextMaxChars = cfg.proposalContextMaxChars ?? 400
      proposalContextMaxTotalChars = cfg.proposalContextMaxTotalChars ?? 2_000
      built = true
    } catch (error) {
      if (!built) throw error
      ctx.logger.warn('autogate: 配置重建失败，沿用上一份有效配置', error)
    }
  }

  // 接入 DSH 设置：DSH 0.1.7 起插件不再自注册配置段（installSection 已移除），改为在
  // profile 条目 Config 上声明 volatile 字段——Loader 就地把新值提交到已有引用，并派发
  // loader/volatile-update（只发给该条目自己的 fiber），本插件据此重建派生态。
  // configure({ auto: false }) 声明本插件自带配置页面（客户端 plugins.bundle.config 槽）；
  // owner 必须显式传 ctx.fiber——默认值是 settings 服务自身的 fiber，会把策略挂错实例。
  ctx.inject(['settings'], (sctx) => {
    sctx.effect(() => sctx.settings.configure({ auto: false }, ctx.fiber))
    sctx.on('loader/volatile-update', () => { rebuild() })
  })
  rebuild()

  // 跟随 DSH 设置语言：locale.preference（'zh'|'en'）由 dsh-client-locale 持久化在其
  // profile 条目的配置里；据此让 L0 理由与 L1 分类 reason 使用对应语言。
  // DSH 0.1.7 起 settings 不再向业务提供按 namespace 取值（get 已移除），改从 describe()
  // 的表单投影里读取：descriptor.value 是解包 volatile 后的普通值，ns 即 profile 条目 id
  // （dsh-client-locale 的条目 id 为 'locale'）。describe() 会同步遍历全部条目并推进
  // revision，故只在挂载与语言变更时调用，不进热路径。变更事件为 settings/document-updated。
  ctx.inject(['settings'], (sctx) => {
    const localeNs = 'locale'
    const readLocale = (): void => {
      const row = sctx.settings.describe().find(item => String(item.ns) === localeNs)
      const value = row?.value as { preference?: UiLocale } | undefined
      // 未显式设置（preference 缺失）时回退中文，与客户端浏览器语言 fallback 一致。
      uiLocale = value?.preference ?? 'zh'
    }
    readLocale()
    sctx.on('settings/document-updated', (ns: unknown) => {
      if (String(ns) === localeNs) readLocale()
    })
    // settings 服务卸载时回退中文（未显式设置语言时的默认行为）。
    sctx.effect(() => () => { uiLocale = 'zh' })
  })

  // 审批轨迹：进程级环形缓冲，记录每次 Auto 决策供客户端面板拉取展示。
  const trail = createApprovalTrail()

  // ApprovalRequest 不携带 arguments：pre-execute 阶段缓存原始参数，approval/request 阶段按 callId 取回，
  // 供分类器判断具体目标。缓存同时覆盖沙箱提权重试与工具自身声明需要审批（ask）两类请求。
  const pendingApprovalArgs = new Map<string, unknown>()

  // 参数回退缓存（callId → 已解析参数），由 session/event 增量维护。pre-execute 监听器被更早注册的
  // 监听器短路时 pendingApprovalArgs 不会写入，此时按 callId 从本缓存取回参数，分类器仍能评估具体目标。
  //
  // 之所以用订阅而非扫描会话事件（DSH 0.1.6 起同步事件读取已弃用）：查询目标恒为「当前正在审批的
  // 调用」，其 tool/call 事件必然在本插件加载之后 append，`session/event` 为 append 内的同步派发、
  // 覆盖全部会话，故订阅即可完整覆盖；判定成本同时由 O(日志长度) 降为 O(1)。
  // 缓存按 callId 存放、不区分会话，故子代理场景（授权会话是执行会话的祖先）同样命中。
  const toolCallArguments = new Map<string, unknown>()
  ctx.on('session/event', (_session, event) => { rememberToolCallArguments(toolCallArguments, event) })

  const rootsFor = (exec: Readonly<ToolExecution>) => resolveRoots(exec.agent?.session.header.cwd, rootOptions)
  const parentAgent: ParentAgentLookup = sessionId => ctx.get('agents')?.get(sessionId)
  // 授权预设解析：读本插件自注的授权投影（applyAuthorizationPreset）——DSH 0.1.6 起
  // 同步事件读取（Session.snapshotEvents/eventAt/ownEvents）已弃用，授权判定改走投影。
  // 注册表未挂载或 key 未注册时恒为 undefined：未命中即 fail-closed，不授予任何自动审批。
  let resolvePreset: PermissionPresetResolver = () => undefined
  ctx.inject(['sessionProjections'], (pctx) => {
    pctx.sessionProjections.register({
      key: AUTHORIZATION_PROJECTION_KEY,
      stateVersion: 1,
      stateSchema: authorizationPresetSchema,
      init: () => null,
      apply: applyAuthorizationPreset,
    })
    resolvePreset = session => pctx.sessionProjections.stateOf(session, AUTHORIZATION_PROJECTION_KEY) ?? undefined
  })
  const authorityOf = (target: ToolExecution['agent']) => managedPermissionAuthority(target, parentAgent, resolvePreset, presetName, fullAutoPresetName)
  const authorityFor = (exec: Readonly<ToolExecution>) => authorityOf(exec.agent)

  // 子代理被 DSH 硬编码 approval=never（dsh-subagent 的 appendDelegatedPolicyOverrides），其提权请求会在
  // approval/request 事件触发前被 decide() 短路拒绝，LLM 终审收不到。对「父会话是托管 Auto」的子代理把
  // approval 改回 ask，让提权请求走到 approval/request 由 LLM 终审裁决；非 Auto 子代理保持 DSH 默认
  // never（fail-closed，不放开）。
  // 时序依赖：dsh-subagent 在子代理 session 未发布窗口（unpublished creation window）内追加 delegation 的
  // never，而 session/created 在 announce（发布）时触发、晚于该窗口，故此处追加的 ask 覆盖 never 生效；
  // 若 DSH 未来改为在 announce 之后追加 delegation 覆盖，本放开逻辑会失效需重新评估。
  ctx.on('session/created', (session) => {
    const header = session.header
    if (header.origin !== 'subagent') return
    const parentId = header.parentSession
    const parent = parentId === undefined ? undefined : parentAgent(parentId)
    if (parent === undefined) {
      // 父会话 agent 未就绪或已释放；保持 DSH 默认 never。
      ctx.logger.debug('autogate: 子代理父会话 agent 未就绪或已释放，保持默认 never')
      return
    }
    // 沿 parentSession 链判断是否存在托管 Auto 祖先（含父自身也是子代理的多级链）。
    const authority = authorityOf(parent)
    if (authority === undefined) {
      // 父会话非托管 Auto；保持 DSH 默认 never。
      ctx.logger.debug('autogate: 子代理父会话非托管 Auto，保持默认 never')
      return
    }
    // 继承父链的托管权限档：DSH 的子代理 delegation 只携带 sandbox override 与 approval=never，
    // 不带 permission/preset——若不补写，子代理的权限档投影按 sandbox=workspace-write + approval=ask
    // 推导为「工作区读写」档而非父会话的 Auto 档。带 source 继承标记补写 permission/preset，
    // 只影响投影显示；授权解析（applyAuthorizationPreset / resolvePreset）跳过该标记，授权依据仍锚定顶层 Auto 会话。
    // source 是插件自有扩展字段，SessionEventMap 未声明；运行时 dsh-permission-presets 的投影
    // 只读 data.preset、忽略其余字段，带 source 不影响投影。
    session.append('permission/preset', {
      preset: authority.mode === 'semi-auto' ? presetName : fullAutoPresetName,
      source: INHERITED_PRESET_SOURCE,
    } as { preset: string })
    setApprovalPolicy(session, 'ask')
  })

  /** 取 agent 所属会话的 id（字符串）；无 agent 或无 header.id 时返回空字符串。 */
  const sessionIdOf = (agent: ToolExecution['agent']): string => {
    const id = agent?.session.header.id
    return id === undefined ? '' : String(id)
  }

  /** 底层轨迹写入：L1/L2 统一入口。classifierInput / tokenUsage 缺省时省略字段（「无」不写成 undefined）。 */
  const recordTrailEntry = (entry: {
    callId: string
    toolName: string
    summary: string
    decision: ApprovalDecision
    layer: ApprovalLayer
    reason: string
    durationMs: number
    sessionId: string
    execSessionId: string
    classifierInput?: ClassifierInput
    tokenUsage?: ClassifierTokenUsage
  }): void => {
    trail.record({
      callId: entry.callId,
      toolName: entry.toolName,
      summary: entry.summary,
      decision: entry.decision,
      layer: entry.layer,
      reason: entry.reason,
      durationMs: entry.durationMs,
      sessionId: entry.sessionId,
      execSessionId: entry.execSessionId,
      ...(entry.classifierInput === undefined ? {} : { classifierInput: entry.classifierInput }),
      ...(entry.tokenUsage === undefined ? {} : { tokenUsage: entry.tokenUsage }),
    })
  }

  /** 审批轨迹记录：authority 由调用方解析后传入（避免每条记录重复沿 parentSession 链查找），sessionId 取授权会话保证按当前会话隔离查询。 */
  const recordTrail = (exec: Readonly<ToolExecution>, authority: ReturnType<typeof authorityFor>, decision: ApprovalDecision, layer: ApprovalLayer, reason: string, durationMs: number, classifierInput?: ClassifierInput, tokenUsage?: ClassifierTokenUsage): void => {
    recordTrailEntry({
      callId: exec.callId === undefined ? '' : String(exec.callId),
      toolName: exec.name,
      summary: summarizeToolArguments(exec.name, exec.arguments),
      decision,
      layer,
      reason,
      durationMs,
      sessionId: sessionIdOf(authority?.agent ?? exec.agent),
      execSessionId: sessionIdOf(exec.agent),
      classifierInput,
      tokenUsage,
    })
  }

  // 同步硬 deny：单调 guard，后续监听器/分类器无法覆盖。
  ctx.tools.guard(exec => {
    const authority = authorityFor(exec)
    if (authority === undefined) return undefined
    const reason = hardDenyReason(exec, rootsFor(exec), uiLocale, authority.mode)
    // 同步硬 deny 同样落入审批轨迹：guard 阶段直接拒绝，不会进入 pre-execute，
    // 因此需在此处记录，否则轨迹面板看不到这类决策。
    if (reason !== undefined) recordTrail(exec, authority, 'deny', 'L0', reason, 0)
    return reason
  })

  // 异步判定：allow 放行 / deny 拒绝 / 无法静态分类转人工或交 LLM 两态裁决。
  ctx.on('tools/pre-execute', async (exec, next): Promise<PreToolDecision> => {
    const authority = authorityFor(exec)
    if (authority === undefined) return next()

    // 审批耗时：从进入审批管道到做出决策的墙钟毫秒数（L0 规则 / L1 LLM 分类）。
    const startedAt = Date.now()

    // 缓存所有带 callId 的调用参数（ApprovalRequest 不携带 arguments，approval/request 阶段按 callId 取回
    // 供分类器评估具体目标：既覆盖沙箱提权重试，也覆盖工具自身声明需要审批的调用）。
    if (exec.callId !== undefined) {
      pendingApprovalArgs.set(String(exec.callId), exec.arguments)
      // 环形上限：审批请求未到达 approval/request（沙箱直接拒绝未生成审批、调用正常完成）时缓存不会被取回，
      // 限制容量并淘汰最旧项，避免进程级内存缓慢增长。
      if (pendingApprovalArgs.size > 100) {
        const oldest = pendingApprovalArgs.keys().next().value
        if (oldest !== undefined) pendingApprovalArgs.delete(oldest)
      }
    }

    // 沙箱提权重试：bash/pwsh 带 sandbox_permissions 直接放行，escalation 审批在 approval/request 监听里先过 LLM 判断。
    if (isSandboxEscalationRetry(exec.name, exec.arguments)) {
      return next()
    }

    // 前置拦截开关：关闭时跳过普通 L0 规则与 LLM 分类，完全依赖沙盒策略。
    // 硬 deny 已在 guard 同步生效，escalation 提权审批在 approval/request 监听，两者均不受本开关影响。
    if (!preflight) return next()

    const roots = rootsFor(exec)
    const assessment = assessTool(exec, roots, uiLocale, authority.mode)
    if (assessment.decision === 'deny') {
      recordTrail(exec, authority, 'deny', 'L0', assessment.reason, Date.now() - startedAt)
      return { kind: 'deny', reason: '[autogate hard deny] ' + assessment.reason }
    }
    if (assessment.decision === 'allow') {
      recordTrail(exec, authority, 'allow', 'L0', assessment.reason, Date.now() - startedAt)
      return next()
    }
    // 剩余均为交 LLM 两态裁决的模糊/危险操作。
    try {
      const route = modelRoute(exec.agent) ?? modelRoute(authority.agent)
      const { messages: trustedMessages, contexts: proposalContexts } = trustedUserMessages(authority.agent, {
        maxMessageLen: proposalContextMaxMessageLen,
        maxChars: proposalContextMaxChars,
        maxTotalChars: proposalContextMaxTotalChars,
      })
      const classifierInput: ClassifierInput = {
        toolName: exec.name,
        arguments: sanitizeClassifierArguments(exec.arguments),
        workspaceRoot: roots.workspace,
        policyReason: assessment.reason,
        trustedUserMessages: trustedMessages,
        proposalContexts,
        ...(route === undefined ? {} : { route }),
      }
      const decision = await classifier.classify(classifierInput, exec.signal)
      if (decision.decision === 'allow') {
        recordTrail(exec, authority, 'allow', 'L1', decision.reason, Date.now() - startedAt, classifierInput, decision.usage)
        return next()
      }
      recordTrail(exec, authority, 'deny', 'L1', decision.reason, Date.now() - startedAt, classifierInput, decision.usage)
      return { kind: 'deny', reason: '[autogate classifier deny] ' + decision.reason }
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : String(error)
      ctx.logger.warn('autogate: L1 分类器异常，拒绝操作（工具: ' + exec.name + '）', error)
      recordTrail(exec, authority, 'deny', 'L1', message, Date.now() - startedAt)
      return { kind: 'deny', reason: '[autogate classifier unavailable] ' + message }
    }
  })

  // 审批请求预审（沙箱提权 + 工具自身声明需要审批）：先过 LLM 判断是否合理，合理则直接批准（不人工弹窗）。
  // 半自动：危险/不确定委派人工兜底弹窗；全自动：LLM 裁决为最终决定，拒绝即拒绝、不再人工弹窗。
  // prepend：本插件 bundle 的 insert 无锚点、落在 api-gateway（dsh-host-apiproxy）之后加载，
  // 而 host-apiproxy 的 approval/request answerer 总是先 claim（弹窗）——不 prepend 则本插件的 LLM 预审
  // 永远排在其后、不被调用。必须抢在所有 UI answerer 之前先过 LLM。
  ctx.on('approval/request', async (req, next): Promise<ApprovalOutcome> => {
    const authority = authorityOf(req.agent)
    if (authority === undefined) return next()
    const mode = authority.mode
    // 子代理（origin=subagent）无可靠人工弹窗通道：其一切审批（沙箱提权 + 工具自身 ask）LLM 终审拒绝即拒绝，不转人工兜底。
    const subagentDenyFinal = req.agent?.session?.header?.origin === 'subagent'
    // 审批耗时：审批请求从进入本监听器到 LLM 预审得出结论的墙钟毫秒数。
    const startedAt = Date.now()

    // 审批来源：沙箱提权（reason 以 escalate sandbox to 开头）与工具自身声明需要审批（其余 reason）。
    // 二者都先过 LLM 预审，仅在 reason 提取方式与 policyReason 前缀上不同。
    const escalation = isEscalationApprovalReason(req.reason)
    const reason = escalation ? extractEscalationJustification(req.reason) : (req.reason ?? '')
    // 工具自身 ask 可能不携带 reason（PreToolDecision 的 ask.reason 可选）：以工具名兜底，保证分类器有上下文。
    const reasonText = reason.trim() === '' ? 'tool ' + req.toolName + ' requires approval' : reason
    const callId = req.callId === undefined ? '' : String(req.callId)
    const summary = reasonText.replace(/\s+/g, ' ').trim().slice(0, 80)
    try {
      const route = modelRoute(authority.agent)
      const roots = resolveRoots(authority.agent.session.header.cwd, rootOptions)
      // 取回原始参数（含 file_path/content/command），让分类器评估具体目标，而非只凭 reason 猜测。
      // 优先用 pre-execute 缓存；未命中（如工具 pre-execute 监听器短路了本插件）时取 session/event
      // 订阅维护的 tool/call 参数缓存；仍无则用 reason 兜底（分类器信息不足时倾向 fail-closed）。
      const rawArguments = pendingApprovalArgs.get(callId)
        ?? toolCallArguments.get(callId)
        ?? { reason }
      pendingApprovalArgs.delete(callId)
      const { messages: trustedMessages, contexts: proposalContexts } = trustedUserMessages(authority.agent, {
        maxMessageLen: proposalContextMaxMessageLen,
        maxChars: proposalContextMaxChars,
        maxTotalChars: proposalContextMaxTotalChars,
      })
      const classifierInput: ClassifierInput = {
        toolName: req.toolName,
        arguments: sanitizeClassifierArguments(rawArguments),
        workspaceRoot: roots.workspace,
        policyReason: (escalation ? 'sandbox escalation request: ' : 'tool approval request: ') + sanitizeClassifierText(reasonText),
        trustedUserMessages: trustedMessages,
        proposalContexts,
        ...(subagentDenyFinal ? { subagent: true } : {}),
        ...(route === undefined ? {} : { route }),
      }
      const decision = await classifier.classify(classifierInput, req.signal ?? new AbortController().signal)
      if (decision.decision === 'allow') {
        recordTrailEntry({ callId, toolName: req.toolName, summary, decision: 'allow', layer: 'L2', reason: decision.reason, durationMs: Date.now() - startedAt, sessionId: sessionIdOf(authority.agent), execSessionId: sessionIdOf(req.agent), classifierInput, tokenUsage: decision.usage })
        return 'allowed-once'
      }
      recordTrailEntry({ callId, toolName: req.toolName, summary, decision: (mode === 'full-auto' || subagentDenyFinal) ? 'deny' : 'ask', layer: 'L2', reason: decision.reason, durationMs: Date.now() - startedAt, sessionId: sessionIdOf(authority.agent), execSessionId: sessionIdOf(req.agent), classifierInput, tokenUsage: decision.usage })
    } catch (error: unknown) {
      // 分类器异常：半自动 fail-closed 到人工弹窗；全自动直接拒绝。保留具体错误并写日志，便于上报排查。
      const message = error instanceof Error ? error.message : String(error)
      ctx.logger.warn('autogate: L2 审批预审分类器异常（工具: ' + req.toolName + '）', error)
      recordTrailEntry({ callId, toolName: req.toolName, summary, decision: (mode === 'full-auto' || subagentDenyFinal) ? 'deny' : 'ask', layer: 'L2', reason: 'classifier unavailable: ' + message, durationMs: Date.now() - startedAt, sessionId: sessionIdOf(authority.agent), execSessionId: sessionIdOf(req.agent) })
    }
    // 全自动与子代理：LLM 裁决为最终决定，直接拒绝不再人工弹窗；半自动主代理：委派人工兜底。
    if (mode === 'full-auto' || subagentDenyFinal) return 'rejected'
    return next()
  }, { prepend: true })

  // 审批轨迹查询端点：客户端以 POST /api/autogate/trail（JSON body）拉取。
  // connection 服务由 client-connection 在自身 fiber 中 provide，本插件 apply 时可能尚未激活；
  // 同步 ctx.get 会取到 undefined 导致端点静默缺失，须用 ctx.inject 等待服务就绪后再注册。
  ctx.inject(['connection'], (connCtx) => {
    const connection = connCtx.get('connection') as { fetch?: TrailFetchHost } | undefined
    const register = connection?.fetch?.register
    if (register === undefined) return // 极端环境无 fetch 注册器：跳过轨迹端点
    connCtx.effect(async () => {
      const dispose = await register({
        path: TRAIL_ENDPOINT,
        methods: ['POST'],
        requestBody: 'buffered',
        fetch: async (request) => {
          const payload = await readTrailPayload(request)
          const records = trail.snapshot()
          const sessionId = trailSessionId(payload)
          return Response.json({
            ok: true,
            value: sessionId === undefined ? records : records.filter((record) => record.sessionId === sessionId || record.execSessionId === sessionId),
          })
        },
      })
      return () => void dispose()
    }, 'autogate: trail fetch route')
  })
}
