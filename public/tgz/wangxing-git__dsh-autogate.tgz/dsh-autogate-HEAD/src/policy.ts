import type { ToolExecution } from '@deepseek-ai/dsh-tools'
import { hardDestructiveTargetReason, isCriticalPath, isProtectedProjectPath, isSensitiveConfigFile, isWithin, normalizePath, type PolicyRoots } from './paths.js'
import { assessShell, hardDenyShellReason } from './shell.js'
import type { Assessment, ManagedMode } from './types.js'
import { noEscalationHint, reasonText, type UiLocale } from './i18n.js'

function allow(reason: string): Assessment {
  return { decision: 'allow', reason }
}

function deny(reason: string): Assessment {
  return { decision: 'deny', reason }
}

function classify(reason: string): Assessment {
  return { decision: 'ask', reason }
}

/** 只读文件工具。 */
const READ_TOOLS = new Set(['read', 'read_image', 'grep', 'glob', 'lsp'])

/** 会话 / 目标状态工具（无文件副作用）。 */
const SESSION_STATE_TOOLS = new Set([
  'ask_user_question', 'todo_write', 'get_goal', 'create_goal', 'update_goal',
  'exit_plan_mode', 'skill', 'report',
])

/** 只读 Harness 查询工具。 */
const HARNESS_READ_TOOLS = new Set(['job_output', 'job_list', 'session_search', 'session_event_search'])

/** 编排工具：子调用独立走本策略。 */
const ORCHESTRATION_TOOLS = new Set([
  'subagent', 'subagent_fork', 'workflow', 'ralph', 'send_message',
  'list_agents', 'interrupt_agent', 'wait_agents',
])

/** 代码执行容器：内部工具调用各自经过本策略与沙箱评估，容器本身直接放行。 */
const CODE_EXECUTION_TOOLS = new Set(['run_code'])

/** 外部写工具：可能影响工作区之外。 */
const EXTERNAL_WRITE_TOOLS = new Set(['git_push', 'deploy', 'publish', 'send_email', 'create_issue', 'create_pull_request'])

/** 工具名本身表明破坏性的危险标记。 */
const DESTRUCTIVE_TOOL_NAME = /(?:^|[_-])(?:delete|destroy|remove|erase|purge|drop|truncate|wipe|unlink|rmdir|reset|revoke)(?:$|[_-])/i

function record(value: unknown): Record<string, unknown> | undefined {
  return typeof value === 'object' && value !== null && !Array.isArray(value) ? value as Record<string, unknown> : undefined
}

function pathArgument(args: Record<string, unknown> | undefined): string | undefined {
  if (args === undefined) return undefined
  for (const key of ['file_path', 'path', 'cwd', 'workdir']) {
    const value = args[key]
    if (typeof value === 'string') return value
  }
  return undefined
}

/** 参数中是否携带凭据 / 私钥材料（用于外发调用检测）。 */
function containsCredentialMaterial(argumentsValue: unknown): boolean {
  let serialized: string
  try {
    serialized = JSON.stringify(argumentsValue ?? '')
  } catch {
    // 参数不可序列化（BigInt / 循环引用）时无法做凭据文本匹配；返回 false 不误杀——
    // 该调用仍会进入 LLM 分类器（sanitize 会把不可序列化值降级为占位符，不会令分类器失败）
    // 与沙箱兜底，避免同步 guard 因序列化崩溃。
    return false
  }
  // 按「真实凭据形态」判定，避免 web_search query / send_email body 等自然语言字段里
  // 「Bearer + 英文单词」「sk- + 英文单词」被误拦：
  // - Bearer 值长度 >= 20 且含数字或符号（JWT 含点、随机 token 含数字；英文单词是纯字母）；
  // - sk- / ghp_ / github_pat / xox* 前缀 token 长度 >= 12 且含数字。
  // 纯字母长 token 可能漏检，交 L1 语义审查与沙箱兜底。
  return /(?:BEGIN (?:RSA |OPENSSH )?PRIVATE KEY|\b(?:sk|ghp|github_pat|xox[baprs])[-_](?=[A-Za-z0-9_-]*\d)(?=[A-Za-z0-9_-]{12,})[A-Za-z0-9_-]+|Bearer\s+(?=[A-Za-z0-9._~+\/-]*[0-9._~+\/-])(?=[A-Za-z0-9._~+\/-]{20})[A-Za-z0-9._~+\/-]+|\.ssh[\\/](?:id_|config)|\.credentials\.yaml)/i.test(serialized)
}

/** 同步硬 deny：供 ctx.tools.guard() 与 pre-execute 共用，后续监听器无法覆盖。 */
export function hardDenyReason(exec: Readonly<ToolExecution>, roots: PolicyRoots, locale?: UiLocale, mode?: ManagedMode): string | undefined {
  const name = exec.name
  const args = record(exec.arguments)
  if ((name === 'bash' || name === 'pwsh') && typeof args?.command === 'string') {
    return hardDenyShellReason(args.command, name, roots, locale, mode)
  }
  if ((/^(?:web_fetch|web_search|curl|wget)/i.test(name) || EXTERNAL_WRITE_TOOLS.has(name)) && containsCredentialMaterial(exec.arguments)) {
    return reasonText(locale, '外部调用包含凭据或私钥材料', 'external call contains credential or private-key material') + noEscalationHint(locale)
  }
  if (['write', 'edit', 'apply_patch'].includes(name)) {
    const path = pathArgument(args)
    if (path !== undefined) {
      const reason = hardDestructiveTargetReason(path, roots, locale, 'mutation')
      if (reason !== undefined) return reasonText(locale, '变更目标为 ', 'mutation targets ') + reason + noEscalationHint(locale)
    }
  }
  if (DESTRUCTIVE_TOOL_NAME.test(name)) {
    const path = pathArgument(args)
    if (path !== undefined) {
      const reason = hardDestructiveTargetReason(path, roots, locale)
      if (reason !== undefined) return reasonText(locale, '破坏性工具目标为 ', 'destructive tool targets ') + reason + noEscalationHint(locale)
    }
  }
  return undefined
}

/**
 * 工具级三级判定：
 * - allow：确定性安全的只读 / 会话状态 / 工作区内编辑；
 * - deny：硬危险（关键路径、凭据外传、提权）；
 * - ask：模糊 / 语义危险操作交 LLM 两态裁决。
 */
export function assessTool(exec: Readonly<ToolExecution>, roots: PolicyRoots, locale?: UiLocale, mode?: ManagedMode): Assessment {
  const hard = hardDenyReason(exec, roots, locale, mode)
  if (hard !== undefined) return deny(hard)

  const name = exec.name
  const args = record(exec.arguments)

  if ((name === 'bash' || name === 'pwsh') && typeof args?.command === 'string') {
    return assessShell(args.command, name, roots, locale, mode)
  }
  if (name === 'bash' || name === 'pwsh') {
    return allow(name + reasonText(locale, ' 命令参数缺失或无效；workspace-write 沙箱适用', ' command argument is missing or invalid; workspace-write sandbox applies'))
  }

  if (READ_TOOLS.has(name)) {
    const path = pathArgument(args)
    if (path === undefined) return allow(reasonText(locale, '只读项目检查', 'read-only project inspection'))
    const normalized = normalizePath(path, roots.workspace, roots.home)
    // symlink 加固：以真实落点判定，防止工作区内 symlink 逃逸读取敏感路径时被误放行。
    const real = roots.resolveReal(normalized)
    if (isWithin(roots.workspace, real)) return allow(reasonText(locale, '工作区内只读项目检查', 'read-only project inspection inside the workspace'))
    // 工作区外读：敏感路径（凭据/系统目录）交 LLM 审查，普通路径直接放行（只读无副作用，workspace-write 沙箱本就不限读）。
    return isCriticalPath(real, roots)
      ? classify(reasonText(locale, '读取工作区外关键路径需语义审查：', 'reading a critical path outside the workspace requires semantic review: ') + real)
      : allow(reasonText(locale, '读取工作区外非关键路径', 'read-only inspection of a non-critical path outside the workspace'))
  }

  if (name === 'write' || name === 'edit' || name === 'apply_patch') {
    const path = pathArgument(args)
    if (path === undefined) return allow(name + reasonText(locale, ' 目标路径缺失；workspace-write 沙箱适用', ' target path is missing; workspace-write sandbox applies'))
    const normalized = normalizePath(path, roots.workspace, roots.home)
    // symlink 加固：以真实落点判定，工作区内 symlink 逃逸到区外时不再误判为“区内编辑”。
    const real = roots.resolveReal(normalized)
    // 工作区内受保护路径（.git 等）交 LLM；工作区外敏感 shell/凭据配置文件同样交 LLM，其余直接放行交给沙箱拦截 + escalation。
    if (isWithin(roots.workspace, real)) {
      return isProtectedProjectPath(real, roots)
        ? classify(reasonText(locale, '变更受保护项目路径需语义审查：', 'mutation of protected project path requires semantic review: ') + real)
        : allow(reasonText(locale, '常规项目本地文件编辑', 'routine project-local file edit'))
    }
    // 工作区外的敏感 shell / 凭据配置文件（.zshrc/.bashrc/.gitconfig/.env 等）提前交 LLM 审查，不再完全依赖沙箱拦截 + escalation 兜底。
    if (isSensitiveConfigFile(real, roots)) {
      return classify(reasonText(locale, '变更工作区外敏感配置文件需语义审查：', 'mutation of a sensitive config file outside the workspace requires semantic review: ') + real)
    }
    return allow(reasonText(locale, '工作区外变更；workspace-write 沙箱将拦截并提供提权', 'mutation outside the workspace; workspace-write sandbox will block it and offer escalation'))
  }

  if (SESSION_STATE_TOOLS.has(name)) return allow(reasonText(locale, '受信任的 Harness 会话状态操作', 'trusted Harness session-state operation'))
  if (HARNESS_READ_TOOLS.has(name)) return allow(reasonText(locale, '受信任的 Harness 只读操作', 'trusted read-only Harness operation'))
  if (ORCHESTRATION_TOOLS.has(name)) return allow(reasonText(locale, '编排调用；子工具动作仍被独立检查', 'orchestration call; child tool actions remain independently checked'))
  if (CODE_EXECUTION_TOOLS.has(name)) return allow(reasonText(locale, '代码执行容器；内部工具调用由策略与沙箱独立检查', 'code execution container; inner tool calls are independently checked by policy and sandbox'))

  if (EXTERNAL_WRITE_TOOLS.has(name)) return classify(reasonText(locale, '外部写入需用户明确授权：', 'external write requires specific user authorization: ') + name)

  if (DESTRUCTIVE_TOOL_NAME.test(name)) {
    return classify(reasonText(locale, '注册的工具名表示破坏性操作：', 'registered tool name indicates a destructive operation: ') + name)
  }

  if (name === 'terminal_open' || name === 'terminal_send') {
    return classify(reasonText(locale, '有状态终端执行需独立分类', 'stateful terminal execution requires independent classification'))
  }

  // 未识别工具一律交 LLM 分类，不默认放行；即使分类器误判 allow，仍有 workspace-write 沙箱兜底文件写入。
  return classify(reasonText(locale, '未识别工具需独立分类：', 'unrecognized tool requires independent classification: ') + name)
}

/** 常见工具的轨迹摘要字段（按优先级取第一个非空字符串）。 */
const SUMMARY_FIELDS: Record<string, string[]> = {
  bash: ['command', 'description'],
  pwsh: ['command', 'description'],
  read: ['file_path'],
  read_image: ['file_path'],
  write: ['file_path'],
  edit: ['file_path'],
  apply_patch: ['file_path', 'path'],
  glob: ['pattern', 'path'],
  grep: ['pattern', 'path'],
  run_code: ['description'],
  web_search: ['query'],
  web_fetch: ['url'],
}

/** 未命中工具清单时的兜底字段。 */
const SUMMARY_FALLBACK_FIELDS = ['command', 'file_path', 'path', 'pattern', 'description', 'query', 'url', 'repo', 'workdir', 'cwd']

/** 参数摘要：提取工具参数中能识别“是哪个操作”的关键字段，供轨迹标注展示，与工具节点形成对应关系。 */
export function summarizeToolArguments(name: string, args: unknown): string {
  const parsed = record(args)
  if (parsed === undefined) return ''
  const fields = SUMMARY_FIELDS[name] ?? SUMMARY_FALLBACK_FIELDS
  for (const field of fields) {
    const value = parsed[field]
    if (typeof value !== 'string' || value.trim() === '') continue
    const oneLine = value.replace(/\s+/g, ' ').trim()
    return oneLine.length > 80 ? oneLine.slice(0, 80) + '…' : oneLine
  }
  return ''
}

/** 参数是否携带非空 sandbox_permissions（任意工具）：用于缓存提权重试的原始参数供 approval/request 分类器取回。 */
export function hasSandboxEscalation(args: unknown): boolean {
  const parsed = record(args)
  if (parsed === undefined) return false
  const permissions = parsed.sandbox_permissions
  return typeof permissions === 'string' && permissions.trim() !== ''
}

/** 是否为沙箱提权重试：带 sandbox_permissions 的 bash/pwsh 调用交由 DSH 内建 escalation 审批（人工弹窗，不过本插件的 LLM）。 */
export function isSandboxEscalationRetry(name: string, args: unknown): boolean {
  if (name !== 'bash' && name !== 'pwsh') return false
  return hasSandboxEscalation(args)
}