import type { Context, Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ToolExecution } from '@deepseek-ai/dsh-tools';
import type { Session, SessionEvent } from '@deepseek-ai/dsh-session';
import type { ProjectionDefinition } from '@deepseek-ai/dsh-session-projection';
import type { ManagedMode } from './types.js';
export * from './paths.js';
export * from './policy.js';
export * from './shell.js';
export * from './classifier.js';
export type * from './types.js';
export * from './trail.js';
export declare const name = "autogate";
export declare const inject: string[];
/** 审批轨迹查询端点路径（/api 下经共享通道认证；与 client.tsx 的请求路径保持一致）。 */
export declare const TRAIL_ENDPOINT = "/api/autogate/trail";
/** 半自动权限预设键（自动但危险时转人工兜底弹窗；默认档）。 */
export declare const SEMI_AUTO_PERMISSION_PRESET = "auto-ask";
/**
 * 全自动权限预设键（LLM 全权裁决，不再人工兜底弹窗）。
 * 0.1.6 起官方把 `auto` 收作实验性 Auto review 模式的保留名（执行包为
 * `danger-full-access` + `approval: never`，与本档语义相反），presets 表里
 * 出现同名键会直接抛错，故本档改用 `auto-full`。
 */
export declare const AUTO_PERMISSION_PRESET = "auto-full";
/**
 * 宿主策略配置。
 *
 * DSH 0.1.7 起设置机制改为「profile 条目 Config + volatile 引用」：Loader 用
 * {@link Config} schema 校验后，把每个字段包成稳定访问器 {@link Volatile} 传入——
 * 引用身份不随配置更新改变，新值由 Loader 就地提交，读方按需 `.get()`。
 * 只有标注 `.volatile()` 的字段才进入插件配置表单（未标注的字段既不显示、
 * 写入时也会被 `Config field "x" is not volatile` 拒绝），故全部可配置项都要标注。
 *
 * 字段类型对应：schema 有 `default()` → `Volatile<T>`；无默认值 → `Volatile<T | undefined>`。
 */
export interface Config {
    /** 半自动权限预设键（默认 auto-ask）：危险操作转人工兜底弹窗。 */
    readonly presetName: Volatile<string>;
    readonly workspaceRoot: Volatile<string | undefined>;
    readonly tempRoots: Volatile<string[] | undefined>;
    readonly classifierEndpoint: Volatile<string | undefined>;
    readonly classifierProvider: Volatile<string | undefined>;
    readonly classifierModel: Volatile<string | undefined>;
    readonly classifierPrompt: Volatile<string>;
    readonly classifierApiKeyEnv: Volatile<string>;
    readonly classifierTimeoutMs: Volatile<number>;
    readonly classifierMaxOutputTokens: Volatile<number>;
    /** 分类器输出解析失败时静默重试一次；默认开启（temperature 0 下偶发格式抖动）。 */
    readonly classifierRetry: Volatile<boolean>;
    /** HTTP 分类端点请求显式关闭思考模式（reasoning_effort: "none"）；默认开启，端点不支持该参数（如 DeepSeek 官方 API 报 400）时关闭。 */
    readonly classifierHttpDisableReasoning: Volatile<boolean>;
    /** 短指代消息长度阈值（字符）：长度不超过该值的直接人类消息才携带 AI 提议上下文用于消解指代；默认 10。 */
    readonly proposalContextMaxMessageLen: Volatile<number>;
    /** 单条 AI 提议上下文上限（字符）；默认 400。 */
    readonly proposalContextMaxChars: Volatile<number>;
    /** AI 提议上下文总预算（字符）：多条消息的上下文合计不超过该值；默认 2000。 */
    readonly proposalContextMaxTotalChars: Volatile<number>;
    /** 沙盒前拦截判断开关：true 执行普通 L0 规则 + LLM 分类，false 完全依赖沙盒（硬 deny 与提权审批不受影响）。 */
    readonly preflight: Volatile<boolean>;
    /** 审批轨迹浮窗开关（默认显示）：关闭则不显示右下角浮窗，且客户端停止轮询轨迹接口。 */
    readonly showTrail: Volatile<boolean>;
    /** 全自动权限预设键（默认 auto-full）：该预设下审批不再人工弹窗，LLM 裁决为最终决定。 */
    readonly fullAutoPresetName: Volatile<string>;
}
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    presetName: z<string, string, "volatile-defined">;
    workspaceRoot: z<string, string, "volatile">;
    tempRoots: z<NoInfer<string[]>, NoInfer<string[]>, "volatile">;
    classifierEndpoint: z<string, string, "volatile">;
    classifierProvider: z<string, string, "volatile">;
    classifierModel: z<string, string, "volatile">;
    classifierPrompt: z<string, string, "volatile-defined">;
    classifierApiKeyEnv: z<string, string, "volatile-defined">;
    classifierTimeoutMs: z<number, number, "volatile-defined">;
    classifierMaxOutputTokens: z<number, number, "volatile-defined">;
    classifierRetry: z<boolean, boolean, "volatile-defined">;
    classifierHttpDisableReasoning: z<boolean, boolean, "volatile-defined">;
    proposalContextMaxMessageLen: z<number, number, "volatile-defined">;
    proposalContextMaxChars: z<number, number, "volatile-defined">;
    proposalContextMaxTotalChars: z<number, number, "volatile-defined">;
    preflight: z<boolean, boolean, "volatile-defined">;
    showTrail: z<boolean, boolean, "volatile-defined">;
    fullAutoPresetName: z<string, string, "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    presetName: z<string, string, "volatile-defined">;
    workspaceRoot: z<string, string, "volatile">;
    tempRoots: z<NoInfer<string[]>, NoInfer<string[]>, "volatile">;
    classifierEndpoint: z<string, string, "volatile">;
    classifierProvider: z<string, string, "volatile">;
    classifierModel: z<string, string, "volatile">;
    classifierPrompt: z<string, string, "volatile-defined">;
    classifierApiKeyEnv: z<string, string, "volatile-defined">;
    classifierTimeoutMs: z<number, number, "volatile-defined">;
    classifierMaxOutputTokens: z<number, number, "volatile-defined">;
    classifierRetry: z<boolean, boolean, "volatile-defined">;
    classifierHttpDisableReasoning: z<boolean, boolean, "volatile-defined">;
    proposalContextMaxMessageLen: z<number, number, "volatile-defined">;
    proposalContextMaxChars: z<number, number, "volatile-defined">;
    proposalContextMaxTotalChars: z<number, number, "volatile-defined">;
    preflight: z<boolean, boolean, "volatile-defined">;
    showTrail: z<boolean, boolean, "volatile-defined">;
    fullAutoPresetName: z<string, string, "volatile-defined">;
}>>, "plain">;
/**
 * 授权投影单元的单事件转移：记录最近一次「用户真实切换」的权限预设名。
 *
 * 跳过本插件写入的继承标记（source 为 {@link INHERITED_PRESET_SOURCE}）：它只让子代理
 * 会话的权限档投影与父会话一致（UI 显示），不构成用户授权。与事件无关时返回**同一引用**
 * ——注册表以 `Object.is` 判定状态变化，同引用不产生下游工作。
 */
export declare function applyAuthorizationPreset(state: string | null, event: SessionEvent): string | null;
/**
 * 授权投影的注册定义。
 *
 * 提取为独立常量并显式标注类型（与官方各包的「先定义常量、再传入 register」样式一致）：
 * 内联对象字面量传入 register 时，TS 需在泛型反向推断与
 * `Omit<ProjectionDefinition<...>, 'wire'>` 的实例化之间互相求值；DSH 0.2.1-alpha.3 起
 * SessionProjectionStateMap 经 declaration merging 扩大后，该推断链超出 TS 深度上限
 * （TS2589 / 编译期 OOM）。
 */
export declare const authorizationProjectionDefinition: ProjectionDefinition<'autogatePermission', string | null>;
/**
 * 解析一个会话的授权预设：读本插件的授权投影，key 未注册或注册表未挂载时返回 undefined。
 * 未命中一律 fail-closed（调用方视作「非托管 Auto」，不授予任何自动审批）。 */
export type PermissionPresetResolver = (session: Session) => string | undefined;
/** 当前会话是否使用 Auto 权限预设（授权依据取自 `resolvePreset`，不读同步事件历史）。 */
export declare function isAutoPermissionExecution(exec: Readonly<ToolExecution>, resolvePreset: PermissionPresetResolver, presetName?: string): boolean;
type ParentSessionId = NonNullable<NonNullable<ToolExecution['agent']>['session']['header']['parentSession']>;
type ParentAgentLookup = (sessionId: ParentSessionId) => ToolExecution['agent'] | undefined;
/**
 * 解析授权本次执行的 Auto 会话。
 * DSH 把子代理 approval pin 到 never，因此沿 durable parentSession 链继承 Auto，
 * 否则子代理的工具调用会在 Auto 会话中被一刀切拒绝。
 */
export declare function autoPermissionAuthority(exec: Readonly<ToolExecution>, parentAgent: ParentAgentLookup, resolvePreset: PermissionPresetResolver, presetName?: string): ToolExecution['agent'] | undefined;
/** 沿 durable parentSession 链解析执行所属的托管权限：返回授权 agent 与模式，未命中返回 undefined。 */
export declare function managedPermissionAuthority(agent: ToolExecution['agent'], parentAgent: ParentAgentLookup, resolvePreset: PermissionPresetResolver, semiPreset?: string, fullPreset?: string): {
    agent: NonNullable<ToolExecution['agent']>;
    mode: ManagedMode;
} | undefined;
/**
 * 把一条 tool/call 事件折进参数缓存：事件里的 arguments 是模型产出的未解析 JSON 字符串，
 * 解析后按 callId 存放（与 pendingApprovalArgs 的值形态一致，供分类器直接使用）。
 * 非字符串或非法 JSON 一律不缓存——读取侧会回落到 reason 兜底。
 */
export declare function rememberToolCallArguments(cache: Map<string, unknown>, event: SessionEvent): void;
/** 安装自动权限策略到官方工具流水线。 */
export declare function apply(ctx: Context, config?: Partial<Config>): void;
