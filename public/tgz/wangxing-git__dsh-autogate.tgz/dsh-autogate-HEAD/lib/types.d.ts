import type { ToolExecution } from '@deepseek-ai/dsh-tools';
/** 一次工具调用的确定性判定结果。 */
export type Assessment = {
    decision: 'allow' | 'ask' | 'deny';
    reason: string;
};
/** 交给 LLM 分类器的输入（已脱敏、已限界）。 */
export interface ClassifierInput {
    toolName: string;
    arguments: unknown;
    workspaceRoot: string;
    policyReason: string;
    /** 最近的直接人类消息（唯一授权依据，已脱敏）。 */
    trustedUserMessages: string[];
    /** 每条用户消息紧邻前的 AI 提议文本（不可信，仅用于消解指代，已脱敏、限界）；与 trustedUserMessages 同序配对，无上下文时为 ''。 */
    proposalContexts?: string[];
    /** 当前会话的 provider/model 路由（供 DSH 内部分类器复用）。 */
    route?: {
        provider: string;
        model: string;
    };
    /** 请求是否来自子代理（origin=subagent）：子代理提权无人工兜底，分类器须施加更严格的 fail-closed 门槛。 */
    subagent?: boolean;
}
/** 一次审查 LLM 调用的 token 消耗。 */
export interface ClassifierTokenUsage {
    /** 缓存输入 token（cache read hit）。 */
    cachedInputTokens: number;
    /** 未缓存输入 token（uncached input）。 */
    uncachedInputTokens: number;
    /** 输出 token。 */
    outputTokens: number;
}
/** LLM 分类器输出（严格两态：放行或拒绝；拒绝后由被拒绝方主动向用户发起人工审批）。 */
export interface ClassifierDecision {
    decision: 'allow' | 'deny';
    reason: string;
    /** 该次 LLM 调用的 token 消耗；未能取得（异常 / 无 usage 信息）时缺省。 */
    usage?: ClassifierTokenUsage;
}
/** 安全分类器接口：默认走 DSH 内部 LLM，可替换为独立 HTTP 端点。 */
export interface SafetyClassifier {
    classify(input: ClassifierInput, signal: AbortSignal): Promise<ClassifierDecision>;
}
/** 供策略函数复用的最小执行字段。 */
export type PendingExecution = Pick<ToolExecution, 'name' | 'arguments' | 'agent' | 'signal'>;
/** 托管权限模式：半自动（保留人工兜底弹窗）/ 全自动（无人工兜底，全部交由 LLM 裁决）。 */
export type ManagedMode = 'semi-auto' | 'full-auto';
