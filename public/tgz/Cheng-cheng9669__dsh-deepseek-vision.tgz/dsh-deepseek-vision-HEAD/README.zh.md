# dsh-deepseek-vision

给纯文本 DeepSeek 模型补上「看图」能力的 DSH 插件。

注册 `deepseek_vision` 工具，调用本地
[`deepseek-vision-cli`](https://github.com/menghuanshiguang/deepseek-vision-cli)
（浏览器自动化驱动 chat.deepseek.com 的识图模式），把图片转换为文字描述后返回给模型。

## 工具

- `deepseek_vision(image, prompt?)`
  - `image`：本地图片绝对路径（PNG/JPG/WebP/GIF；HEIC 不支持）
  - `prompt`：可选，对图片的提问/分析要求

## 安装

```bash
dsh plugin --profile web add D:/Dsh/tools/dsh-deepseek-vision
```

或使用发布包：

```bash
dsh plugin --profile web add dsh-deepseek-vision-0.0.1.tgz
```

## 首次登录

DeepSeek 网页识图需要网页登录态。当前网页端已改为「密码/第三方登录」，推荐使用
手动登录助手：

```powershell
py -3.13 D:\Dsh\tools\deepseek-vision-cli\dsv_manual_login.py
```

执行后会弹出 Edge 窗口并打开 DeepSeek 登录页，手动登录成功后脚本自动保存 token
到 `D:\Dsh\.cache\dsv_token`。

### Token 登录（备选）

如果你已经在常用浏览器里登录了 DeepSeek，也可以直接复制 token：

1. 打开 `https://chat.deepseek.com` 并登录。
2. 按 `F12` → `Application` → `Local Storage` → `https://chat.deepseek.com`。
3. 找到 `userToken`，复制它的 `value` 字段。
4. 保存到 `D:\Dsh\.cache\dsv_token`（不要引号、不要换行）：

```powershell
[IO.File]::WriteAllText(
  'D:\Dsh\.cache\dsv_token',
  '粘贴你的token',
  (New-Object Text.UTF8Encoding($false))
)
```

token 只保存在本地 `D:\Dsh\.cache\dsv_token`，不会提交到本仓库。

## 配置

插件默认配置已适配本机：

- `pythonCommand`：`py`
- `pythonVersion`：`-3.13`
- `dsvScript`：`D:/Dsh/tools/deepseek-vision-cli/dsv.py`
- `timeoutMs`：`180000`
- `maxOutputChars`：`20000`

可在 profile patch 中覆盖。

## 安全说明

- 工具只接受本地文件路径，命令通过 DSH `subprocess` 服务以 argv 数组调用，不经过 shell。
- 图片会发送到 DeepSeek 网页端，不是本地识别。
- 该方案依赖非官方网页接口，存在风控/封号风险，建议小号低频使用。
- 静态审计会因「spawn 子进程」报 critical，这是包装外部 CLI 的固有行为；已人工确认
  仅调用固定 `dsv.py`，无命令拼接、无额外外传。

## License

MIT
