/**
 * @dsh-external/dsh-deepseek-vision — DeepSeek 网页识图桥。
 *
 * 注册 `deepseek_vision` 工具：把图片路径交给本地 dsv CLI（浏览器自动化驱动
 * chat.deepseek.com 识图模式），将视觉模型返回的文本描述作为工具结果交给
 * 纯文本 DeepSeek 模型。
 *
 * 安全边界：
 * - 工具只接受本地文件路径，不接收任意 shell 命令；
 * - 外部命令通过 DSH subprocess 服务的 argv 数组调用，不经过 shell；
 * - 只透传最小环境变量，强制 UTF-8 输出，超时与输出上限可配置。
 */
import { existsSync, statSync } from 'node:fs'
import { resolve } from 'node:path'
import { defineTool } from '@deepseek-ai/dsh-tools'
import z from '@deepseek-ai/schemastery'

export const name = 'dsh-deepseek-vision'
export const inject = ['tools', 'subprocess']

export const Config = z.object({
  pythonCommand: z.string().default('py'),
  pythonVersion: z.string().default('-3.13'),
  dsvScript: z.string().default('D:/Dsh/tools/deepseek-vision-cli/dsv.py'),
  timeoutMs: z.number().default(180_000),
  maxOutputChars: z.number().default(20_000),
})

function truncate(text, max) {
  if (text.length <= max) return text
  return `${text.slice(0, max)}\n…[输出已截断，共 ${text.length} 字符]`
}

async function readStream(stream) {
  if (!stream) return ''
  let text = ''
  for await (const chunk of stream) text += chunk.toString()
  return text
}

async function runDsv(ctx, argv, config) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), config.timeoutMs)
  try {
    const child = ctx.subprocess.spawn({
      argv,
      cwd: process.cwd(),
      stdio: {
        stdin: 'ignore',
        stdout: 'pipe',
        stderr: 'pipe',
      },
      env: {
        PATH: process.env.PATH ?? '',
        SystemRoot: process.env.SystemRoot ?? 'C:\\Windows',
        WINDIR: process.env.WINDIR ?? process.env.SystemRoot ?? 'C:\\Windows',
        PYTHONIOENCODING: 'utf-8',
        PYTHONUTF8: '1',
        DSV_TOKEN_FILE: 'D:/Dsh/.cache/dsv_token',
        DSV_EDGE_PROFILE: 'D:/Dsh/.cache/dsv_edge_profile',
      },
      signal: controller.signal,
      graceMs: 3_000,
    })

    const stdoutPromise = readStream(child.stdout)
    const stderrPromise = readStream(child.stderr)

    let outcome
    try {
      outcome = await child.done
    } catch (error) {
      if (controller.signal.aborted) {
        const timeoutError = new Error(`dsv 识图超时（${config.timeoutMs}ms）`)
        timeoutError.killed = true
        throw timeoutError
      }
      throw error
    }

    const [stdout, stderr] = await Promise.all([stdoutPromise, stderrPromise])

    if (outcome.exitCode !== 0) {
      const error = new Error(`dsv exited with code ${String(outcome.exitCode)}`)
      error.code = outcome.exitCode
      error.stdout = stdout
      error.stderr = stderr
      throw error
    }

    return { stdout, stderr }
  } finally {
    clearTimeout(timer)
  }
}

export function apply(ctx, config) {
  ctx.effect(() => ctx.tools.register(defineTool({
    name: 'deepseek_vision',
    description: '识别本地图片：把图片交给 DeepSeek 网页识图模式，返回图片内容的文字描述。模型本身无多模态时用此工具。',
    parameters: {
      image: {
        type: 'string',
        required: true,
        description: '本地图片绝对路径（支持 PNG/JPG/WebP/GIF；HEIC 不支持）。',
      },
      prompt: {
        type: 'string',
        description: '对图片的提问或分析要求，默认详细描述图片内容。',
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: String(value) }],
    },
    async execute(args) {
      const imagePath = resolve(args.image)
      if (!existsSync(imagePath) || !statSync(imagePath).isFile()) {
        return `图片不存在或不是文件：${args.image}`
      }

      const cmdArgs = []
      if (config.pythonVersion.trim()) {
        cmdArgs.push(config.pythonVersion.trim())
      }
      cmdArgs.push(config.dsvScript, imagePath)
      if (args.prompt?.trim()) {
        cmdArgs.push(args.prompt.trim())
      }

      try {
        const { stdout, stderr } = await runDsv(ctx, [config.pythonCommand, ...cmdArgs], config)
        const out = stdout.trim()
        if (out) {
          return truncate(out, config.maxOutputChars)
        }
        const err = stderr.trim()
        if (err) {
          return truncate(`dsv 未输出内容，stderr：\n${err}`, config.maxOutputChars)
        }
        return 'dsv 已执行但未返回内容。'
      } catch (error) {
        const detail = [
          error.stdout?.toString().trim(),
          error.stderr?.toString().trim(),
        ].filter(Boolean).join('\n')

        if (error.code === 4) {
          return 'DeepSeek 网页识图未登录或 token 失效。请先运行 `dsv --login <手机号>`，收到短信后运行 `dsv --verify <验证码>`，再重试。'
        }
        if (error.code === 5) {
          return '另一个 dsv 识图进程正在运行，请稍后重试。'
        }
        if (error.killed) {
          return `dsv 识图超时（${config.timeoutMs}ms）。可适当调大 timeoutMs 后重试。\n${detail}`.trim()
        }
        return truncate(`dsv 识图失败：${error.message ?? '未知错误'}\n${detail}`.trim(), config.maxOutputChars)
      }
    },
  })), '@dsh-external/dsh-deepseek-vision: deepseek_vision tool')
}
