#!/bin/bash
# Build dsh-deepseek-vision: copy the ESM host entry to lib/.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

mkdir -p lib
cp src/index.js lib/index.js
echo "=== Build complete ==="
