// Mock Ollama server for offline testing of the dsh-llm-ollama plugin.
// Implements GET /api/tags and POST /api/chat (NDJSON streaming, including a
// tool-call reply when the request carries tools, and an `images=N` echo when
// messages carry base64 image data). Records the last /api/chat request body to
// /tmp/ollama-mock-last.json so the num_ctx / num_predict / keep_alive / images
// wiring can be asserted.
//
// Usage: node scripts/mock-ollama.mjs   (listens on 127.0.0.1:11434; set PORT to override)
import { createServer } from 'node:http'
import { writeFileSync } from 'node:fs'

const PORT = Number(process.env.PORT ?? 11434)
const MODELS = [
  { name: 'llama3.2:3b', modified_at: '2024-01-01T00:00:00Z', size: 2019393181 },
  { name: 'qwen2.5:7b', modified_at: '2024-01-01T00:00:00Z', size: 4683593488 }
]

const server = createServer((req, res) => {
  const chunks = []
  req.on('data', (c) => chunks.push(c))
  req.on('end', () => {
    const raw = Buffer.concat(chunks).toString('utf8')
    const url = new URL(req.url, 'http://x')
    if (req.method === 'GET' && url.pathname === '/api/tags') {
      res.writeHead(200, { 'content-type': 'application/json' })
      res.end(JSON.stringify({ models: MODELS }))
      return
    }
    if (req.method === 'POST' && url.pathname === '/api/chat') {
      let body
      try {
        body = JSON.parse(raw)
      } catch {
        res.writeHead(400, { 'content-type': 'application/json' })
        res.end(JSON.stringify({ error: 'bad json' }))
        return
      }
      try {
        writeFileSync('/tmp/ollama-mock-last.json', JSON.stringify(body, null, 2))
      } catch {}
      // Faithful to real ollama: /api/chat rejects tool_calls history whose
      // function.arguments is a JSON *string* (it must be an object) with this
      // exact 400 body. Sending it WITHOUT a trailing newline also mirrors the
      // real wire behaviour, so the client must surface the error even when
      // the line is not newline-terminated.
      for (const message of Array.isArray(body.messages) ? body.messages : []) {
        if (message !== null && typeof message === 'object' && Array.isArray(message.tool_calls)) {
          for (const call of message.tool_calls) {
            const fn = call !== null && typeof call === 'object' ? call.function : undefined
            if (fn !== null && typeof fn === 'object' && typeof fn.arguments === 'string') {
              res.writeHead(400, { 'content-type': 'application/json' })
              res.end('{"error":"Value looks like object, but can\'t find closing \'}\' symbol"}')
              return
            }
          }
        }
      }
      res.writeHead(200, { 'content-type': 'application/x-ndjson' })
      const send = (obj) => res.write(`${JSON.stringify(obj)}\n`)
      if (Array.isArray(body.tools) && body.tools.length > 0) {
        // Simulate a tool-call response streamed across frames.
        send({ model: body.model, created_at: new Date().toISOString(), message: { role: 'assistant', content: '' }, done: false })
        send({ model: body.model, created_at: new Date().toISOString(), message: { role: 'assistant', tool_calls: [{ index: 0, id: 'call_abc123', type: 'function', function: { name: body.tools[0].function.name, arguments: '{"city":"Bei' } }] }, done: false })
        send({ model: body.model, created_at: new Date().toISOString(), message: { role: 'assistant', tool_calls: [{ index: 0, id: 'call_abc123', type: 'function', function: { name: '', arguments: 'jing"}' } }] }, done: false })
        send({ model: body.model, created_at: new Date().toISOString(), message: { role: 'assistant', content: '' }, done: true, done_reason: 'tool_calls', prompt_eval_count: 31, eval_count: 11 })
        res.end()
        return
      }
      if (body.stream !== false) {
        // When thinking is enabled (body.think !== false and not explicitly
        // denied), emit a reasoning trace in `message.thinking` before the
        // final `message.content`, mirroring real Ollama's shape so the
        // client's reasoning-surface path is exercised offline.
        const thinkOn = body.think !== false
        const thinkWords = thinkOn ? `Reasoning: the model thinks step by step. `.split(' ') : []
        const parts = [`Hello from mock ollama (model ${body.model}).`]
        if (body.options && body.options.num_ctx) parts.push(`num_ctx=${body.options.num_ctx}`)
        if (body.options && body.options.num_predict) parts.push(`num_predict=${body.options.num_predict}`)
        const imageCount = (body.messages ?? []).reduce((n, m) => n + (Array.isArray(m.images) ? m.images.length : 0), 0)
        if (imageCount > 0) parts.push(`images=${imageCount}`)
        const text = parts.join(' ')
        const words = text.split(' ')
        let i = 0
        const total = thinkWords.length + words.length
        const timer = setInterval(() => {
          if (i < thinkWords.length) {
            send({ model: body.model, created_at: new Date().toISOString(), message: { role: 'assistant', thinking: `${thinkWords[i]} `, content: '' }, done: false })
            i++
          } else if (i < total) {
            send({ model: body.model, created_at: new Date().toISOString(), message: { role: 'assistant', content: `${words[i - thinkWords.length]} ` }, done: false })
            i++
          } else {
            clearInterval(timer)
            send({
              model: body.model,
              created_at: new Date().toISOString(),
              message: { role: 'assistant', content: '' },
              done: true,
              done_reason: 'stop',
              prompt_eval_count: 24,
              eval_count: total,
              ...(body.keep_alive !== undefined ? { keep_alive_received: body.keep_alive } : {})
            })
            res.end()
          }
        }, 5)
      } else {
        send({ model: body.model, created_at: new Date().toISOString(), message: { role: 'assistant', content: `non-stream reply for ${body.model}` }, done: true, done_reason: 'stop', prompt_eval_count: 5, eval_count: 3 })
        res.end()
      }
      return
    }
    res.writeHead(404, { 'content-type': 'application/json' })
    res.end(JSON.stringify({ error: 'not found' }))
  })
})

server.listen(PORT, '127.0.0.1', () => {
  console.log(`mock ollama listening on ${PORT}`)
})
