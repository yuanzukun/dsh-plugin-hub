// Client half of @zhangyi/dsh-llm-ollama: a whole-page "Ollama" settings
// section (the `settings.section` list slot), so the plugin needs no
// modification of dsh's own packages. The page manages the `llm-ollama`
// settings namespace (provider profiles) through the wire API, fetches models
// from the Ollama server through the host plugin's /api/tags discovery, and
// edits per-model Context window / Max output tokens (which the host adapter
// sends as num_ctx / num_predict).
window.__ModuleLoader__.load({
	id: "@zhangyi/dsh-llm-ollama",
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		let react = require("react");
		let _deepseek_ai_dsh_client_ui_primitives = require("@deepseek-ai/dsh-client-ui-primitives");

		const NS = "llm-ollama";
		const OLLAMA_API = "ollama-chat";
		const ROUTE_PATTERN = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
		const CAPACITY_PATTERN = /^(\d+(?:\.\d+)?)\s*([kKmM]?)$/;
		// K and M count as 1024-based here so "32K" parses to the exact 32K
		// (32768) default the host adapter sends as num_ctx.
		const CAPACITY_SCALE = { k: 1024, m: 1024 * 1024 };
		// Common context-window presets offered by the /ollama-context command panel.
		const PRESET_CONTEXTS = [4096, 8192, 16384, 32768, 65536, 131072];
		// Reasoning-effort levels the host adapter accepts (mapped to Ollama's
		// top-level `think` field). Per Ollama's docs most open thinking models
		// only support a boolean on/off, so the default mode is `boolean`
		// (off/on); models that accept granular levels (e.g. GPT-OSS) opt into
		// `levels` (off/low/medium/high/max).
		const THINK_MODES = ["boolean", "levels"];
		const EFFORT_IDS_BY_MODE = {
			boolean: ["off", "on"],
			levels: ["off", "low", "medium", "high", "max"]
		};

		/** Parse a capacity field ("32K", "4096", "1M"); blank -> undefined, unreadable -> NaN. */
		function parseCapacity(text) {
			const trimmed = text.trim();
			if (trimmed.length === 0) return void 0;
			const match = CAPACITY_PATTERN.exec(trimmed);
			if (match === null) return NaN;
			const suffix = match[2]?.toLowerCase();
			const scale = suffix === "k" || suffix === "m" ? CAPACITY_SCALE[suffix] : 1;
			return Number(match[1]) * scale;
		}
		/** Spell a stored capacity ("32768" -> "32K"). */
		function formatCapacity(value) {
			if (!Number.isInteger(value) || value <= 0) return String(value);
			if (value % CAPACITY_SCALE.m === 0) return `${String(value / CAPACITY_SCALE.m)}M`;
			if (value % CAPACITY_SCALE.k === 0) return `${String(value / CAPACITY_SCALE.k)}K`;
			return String(value);
		}
		function stringOf(value) {
			return typeof value === "string" ? value : "";
		}
		function numberTextOf(value) {
			return typeof value === "number" ? String(value) : "";
		}
		function messageOf(error) {
			return error instanceof Error ? error.message : String(error);
		}
		/** Derive the conventional credential ref for a route (mirrors the Models page). */
		function deriveKeyRef(provider) {
			return `${provider.toUpperCase().replace(/[^A-Z0-9]+/g, "_")}_API_KEY`;
		}

		/** Disclosure chevron; rotates to point down while its row is open (same glyph as the Models page). */
		function IconChevron({ open }) {
			return react.createElement("svg", {
				width: "14",
				height: "14",
				viewBox: "0 0 16 16",
				fill: "none",
				"aria-hidden": true,
				style: {
					transform: open ? "rotate(90deg)" : void 0,
					transition: "transform 120ms ease"
				}
			}, react.createElement("path", {
				d: "M6 3.5L10.5 8L6 12.5",
				stroke: "currentColor",
				strokeWidth: "1.5",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}));
		}
		/** Removal glyph for one model row (same glyph as the Models page). */
		function IconTrash() {
			return react.createElement("svg", {
				width: "14",
				height: "14",
				viewBox: "0 0 16 16",
				fill: "none",
				"aria-hidden": true
			}, react.createElement("path", {
				d: "M2.5 4h11M6.5 4V2.5h3V4M4 4l.7 9a1 1 0 001 .9h4.6a1 1 0 001-.9L12 4M6.5 6.8v4.4M9.5 6.8v4.4",
				stroke: "currentColor",
				strokeWidth: "1.3",
				strokeLinecap: "round",
				strokeLinejoin: "round"
			}));
		}
		/** Disclosure chevron for native selects: RIGHT when the dropdown is
		 * closed, rotating 90° to point DOWN while it is open (matches the
		 * disclosure glyph the plugin already uses for the model row). */
		function SelectChevron() {
			return react.createElement("svg", { width: "14", height: "14", viewBox: "0 0 16 16", fill: "none", "aria-hidden": true }, react.createElement("path", { d: "M6 3.5L10.5 8L6 12.5", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }));
		}
		/**
		 * A labeled native select with a system-style expanding chevron. The open
		 * state is tracked in React (not focus): clicking toggles it, and it
		 * resets after an option is chosen or on blur, so each click flips the
		 * icon (closed = right, open = down).
		 */
		function FieldSelect({ label, spanFull, disabled, value, onChange, children }) {
			const [open, setOpen] = react.useState(false);
			const handleChange = (event) => { setOpen(false); onChange(event); };
			return react.createElement("div", { className: "dslollama_field" + (spanFull ? " dslollama_spanFull" : "") },
				react.createElement("span", { className: "dslollama_label" }, label),
				react.createElement("div", { className: "dslollama_selectWrap" },
					react.createElement("select", { className: "dslollama_input", value, disabled, onChange: handleChange, onClick: () => setOpen((current) => !current), onBlur: () => setOpen(false) }, children),
					react.createElement("span", { className: "dslollama_selectChevron" + (open ? " dslollama_selectChevronOpen" : ""), "aria-hidden": true },
						react.createElement(SelectChevron, null))));
		}

		/** Copy dictionaries for the Ollama settings section. */
		const en = {
			nav: "Ollama",
			title: "Ollama",
			intro: "Configure Ollama providers. Each provider talks to an Ollama server through its native /api/chat protocol.",
			readOnly: "The settings document is read-only in this deployment.",
			loadFailed: "Loading the Ollama configuration failed",
			retry: "Retry",
			add: "Add provider",
			route: "Provider ID",
			routeHint: "Lowercase identifier, starting with a letter, that uniquely names this provider.",
			routeInvalid: "Start with a lowercase letter; then lowercase letters, digits, and dashes.",
			routeTaken: "A provider already uses this ID.",
			displayName: "Display name",
			baseUrl: "Base URL",
			baseUrlPlaceholder: "http://localhost:11434",
			baseUrlHint: "Ollama's native API base — the default local server is http://localhost:11434.",
			baseUrlRequired: "A provider needs a base URL.",
			keepAlive: "Keep alive (model stay-loaded duration)",
			temperature: "Temperature",
			temperatureInvalid: "Temperature must be a number between 0 and 2.",
			keyInput: "API key",
			keyPlaceholder: "Optional — Ollama usually needs no key",
			models: "Models",
			modelsEmpty: "No models yet. Fetch them from the server or add them by hand.",
			fetchModels: "Fetch available models",
			fetching: "Asking the server…",
			fetchNeedsBaseUrl: "Enter the base URL first, then fetch.",
			fetchEmpty: "The server listed no models. Add them by hand.",
			fetchTitle: "Choose models to add",
			fetchDescription: "These are the models this provider has available. Choose the ones to add.",
			fetchAdopt: "Add selected",
			cancel: "Cancel",
			close: "Close",
			addModel: "Add model",
			removeModel: "Delete model",
			modelId: "Model ID",
			modelName: "Display name",
			contextWindow: "Context window",
			maxTokens: "Max output tokens",
			thinkingCapable: "Reasoning control",
			thinkingCapableAuto: "Auto (from server)",
			thinkingCapableForce: "Show (reasoning-capable)",
			thinkingCapableHide: "Hide (non-reasoning)",
			thinkingCapableHint: "By default reasoning support is auto-detected from the model's capabilities, so only reasoning models show a reasoning-level selector in the bottom-right picker. Use the override only when the server reports it incorrectly.",
			reasoningEffort: "Default reasoning level",
			reasoningEffortDefault: "Not set (follow Ollama)",
			reasoningEffortHint: "This model's default reasoning effort in the bottom-right model selector. Off disables reasoning; on enables it; low/medium/high/max tune it (levels mode only). Leave unset to follow Ollama's own default.",
			effortOff: "Off",
			effortOn: "On",
			effortLow: "Low",
			effortMedium: "Medium",
			effortHigh: "High",
			effortMax: "Max",
			thinkingMode: "Reasoning levels",
			thinkingModeBoolean: "On/off switch (most models)",
			thinkingModeLevels: "Granular levels (low/medium/high/max)",
			thinkingModeHint: "Most open reasoning models (Qwen3, DeepSeek-R1) only support an on/off switch. Choose granular levels only for models that accept them (e.g. GPT-OSS).",
			ollamaNumCtxHint: "Ollama sends each model's Context window as the num_ctx request option and Max output tokens as num_predict — whatever you enter here is passed to the API exactly.",
			modelInvalid: "Each model needs a unique ID; capacities must be positive counts like 4096, 32K, or 1M.",
			save: "Save",
			saving: "Saving…",
			saved: "Saved.",
			delete: "Delete",
			deleteConfirm: "Delete this provider?",
			deleting: "Deleting…",
			notConfigured: "Not configured yet — fill in the fields and save.",
			configured: "Configured",
			custom: "Custom",
			conflict: "These settings changed while the card was open. Reload and retry.",
			expandCapacities: "Capacities",
			commandDesc: "Set this session's context window (Ollama num_ctx)",
			followSystem: "Follow system configuration",
			customValue: "Custom value…",
			customHint: "Enter any context window size, e.g. 4096, 32K, or 1M.",
			contextTitle: "Session context window",
			contextDescription: "This value overrides the provider's per-model Context window for this session only. New sessions and the \"follow system\" option use the configured value.",
			customInvalid: "Enter a valid context size, e.g. 4096, 32K, or 1M.",
			contextSaved: "Session context updated."
		};
		const zh = {
			nav: "Ollama",
			title: "Ollama",
			intro: "配置 Ollama 提供方。每个提供方通过其原生 /api/chat 协议连接一台 Ollama 服务器。",
			readOnly: "当前部署的设置文档为只读。",
			loadFailed: "加载 Ollama 配置失败",
			retry: "重试",
			add: "添加提供方",
			route: "Provider ID",
			routeHint: "以小写字母开头的标识，在请求中唯一标识该提供方。",
			routeInvalid: "需以小写字母开头，之后可用小写字母、数字和短横线。",
			routeTaken: "已有提供方使用了这个 ID。",
			displayName: "显示名称",
			baseUrl: "API 地址",
			baseUrlPlaceholder: "http://localhost:11434",
			baseUrlHint: "Ollama 原生 API 地址，本地默认服务为 http://localhost:11434。",
			baseUrlRequired: "提供方需要填写 API 地址。",
			keepAlive: "保持时间（模型驻留时长）",
			temperature: "温度",
			temperatureInvalid: "温度必须是 0 到 2 之间的数字。",
			keyInput: "API 密钥",
			keyPlaceholder: "可选——Ollama 通常无需密钥",
			models: "模型目录",
			modelsEmpty: "还没有模型。可以从服务器获取，也可以手动添加。",
			fetchModels: "获取可用模型",
			fetching: "正在询问服务器…",
			fetchNeedsBaseUrl: "请先填写 API 地址，再获取。",
			fetchEmpty: "服务器没有列出任何模型，请手动添加。",
			fetchTitle: "选择要添加的模型",
			fetchDescription: "以下是模型提供方的可用模型，勾选要添加的模型。",
			fetchAdopt: "添加所选",
			cancel: "取消",
			close: "关闭",
			addModel: "添加模型",
			removeModel: "删除模型",
			modelId: "模型 ID",
			modelName: "显示名称",
			contextWindow: "上下文窗口",
			maxTokens: "最大输出 token",
			thinkingCapable: "推理控制",
			thinkingCapableAuto: "自动识别（推荐）",
			thinkingCapableForce: "始终显示（推理型）",
			thinkingCapableHide: "始终隐藏（非推理型）",
			thinkingCapableHint: "默认按服务器的模型能力自动识别：只有推理型模型才会在右下角模型选择器显示「推理等级」。仅当自动判断不准时，才手动覆盖为始终显示或始终隐藏。",
			reasoningEffort: "默认推理等级",
			reasoningEffortDefault: "不设置（跟随 Ollama）",
			reasoningEffortHint: "该模型在右下角模型选择器中的默认推理等级。Off 关闭推理、On 开启推理；low/medium/high/max 调节强度（仅多档等级模式）。不设置时跟随 Ollama 默认。",
			effortOff: "关闭",
			effortOn: "开启",
			effortLow: "低",
			effortMedium: "中",
			effortHigh: "高",
			effortMax: "最大",
			thinkingMode: "推理等级类型",
			thinkingModeBoolean: "开关（多数模型）",
			thinkingModeLevels: "多档等级（low/medium/high/max）",
			thinkingModeHint: "大多数开源推理模型（Qwen3、DeepSeek-R1 等）只支持开关；仅 GPT-OSS 等模型支持多档等级，才选用该项。",
			ollamaNumCtxHint: "Ollama 会将每个模型的上下文窗口作为 num_ctx 请求参数、最大输出 token 作为 num_predict 发送——这里填多少，API 就传多少。",
			modelInvalid: "每个模型需要唯一的 ID；容量需为正数，例如 4096、32K 或 1M。",
			save: "保存",
			saving: "保存中…",
			saved: "已保存。",
			delete: "删除",
			deleteConfirm: "删除该提供方？",
			deleting: "删除中…",
			notConfigured: "尚未配置——填写字段后保存。",
			configured: "已配置",
			custom: "自定义",
			conflict: "这张卡片打开期间，设置已被其他地方改动。请刷新后重试。",
			expandCapacities: "容量",
			commandDesc: "设置当前会话的上下文窗口（Ollama num_ctx）",
			followSystem: "跟随系统配置",
			customValue: "自定义值…",
			customHint: "输入任意上下文窗口大小，例如 4096、32K 或 1M。",
			contextTitle: "会话上下文窗口",
			contextDescription: "该值仅对当前会话生效，优先级高于提供方中每个模型配置的上下文窗口；新会话或选择“跟随系统配置”时使用系统配置。",
			customInvalid: "请输入有效的上下文大小，例如 4096、32K 或 1M。",
			contextSaved: "会话上下文已更新。"
		};

		/** Scoped styles for this page (injected once, mirroring the product's css tag pattern). */
		const css = `
.dslollama_section{max-width:720px}
.dslollama_title{font-size:20px;font-weight:600;margin:0 0 8px;color:var(--dsw-alias-label-primary)}
.dslollama_intro{color:var(--dsw-alias-label-tertiary);font-size:13px;line-height:20px;margin:0 0 16px}
.dslollama_notice{color:var(--dsw-alias-label-tertiary);font-size:12px;margin:0 0 12px}
.dslollama_error{color:var(--dsw-alias-state-error-primary);font-size:13px;margin:4px 0 8px}
.dslollama_card{border:1px solid var(--dsw-alias-border-l2);border-radius:10px;padding:16px;margin-bottom:14px;background:var(--dsw-alias-bg-layer-1)}
.dslollama_cardHead{display:flex;align-items:center;gap:8px;margin-bottom:10px}
.dslollama_name{font-weight:600;font-size:14px;color:var(--dsw-alias-label-primary)}
.dslollama_route{color:var(--dsw-alias-label-tertiary);font-size:12px}
.dslollama_tag{font-size:11px;padding:1px 6px;border-radius:8px;background:var(--dsw-alias-bg-module-platform);color:var(--dsw-alias-label-tertiary)}
.dslollama_tagOk{background:var(--dsw-alias-bg-module-platform);color:var(--dsw-alias-state-success-primary)}
.dslollama_field{display:flex;flex-direction:column;gap:4px;margin-bottom:10px}
.dslollama_fieldRow{display:grid;grid-template-columns:1fr 1fr;gap:10px}
.dslollama_fieldRow .dslollama_field{margin-bottom:10px}
.dslollama_label{font-size:12px;color:var(--dsw-alias-label-secondary)}
.dslollama_input{border:1px solid var(--dsw-alias-border-l2);border-radius:6px;background:var(--dsw-alias-bg-module-platform);color:var(--dsw-alias-label-primary);padding:6px 8px;font-size:13px;width:100%;min-width:0;box-sizing:border-box}
.dslollama_input:focus{outline:none;border-color:var(--dsw-alias-brand-primary)}
select.dslollama_input{cursor:pointer}
select.dslollama_input:disabled{cursor:default;opacity:1}
.dslollama_hint{color:var(--dsw-alias-label-tertiary);font-size:12px;line-height:18px;margin:2px 0 8px}
.dslollama_models{border-top:1px solid var(--dsw-alias-border-l3);padding-top:10px;margin-top:4px}
.dslollama_modelsHead{display:flex;align-items:center;gap:8px;margin-bottom:8px}
.dslollama_modelsTitle{font-size:13px;font-weight:600;color:var(--dsw-alias-label-primary)}
.dslollama_modelRow{display:grid;grid-template-columns:1fr 1fr 28px 28px;gap:6px;align-items:center}
.dslollama_modelAdvanced{display:grid;grid-template-columns:1fr 1fr;gap:8px 12px;padding:0 0 2px;margin-top:6px}
.dslollama_modelAdvanced .dslollama_field{margin-bottom:0}
.dslollama_spanFull{grid-column:1 / -1}
.dslollama_selectWrap{position:relative;display:block}
.dslollama_selectWrap select.dslollama_input{appearance:none;-webkit-appearance:none;-moz-appearance:none;padding-right:28px;cursor:pointer}
.dslollama_selectWrap select.dslollama_input:disabled{cursor:default}
.dslollama_selectWrap .dslollama_selectChevron{position:absolute;right:8px;top:50%;transform:translateY(-50%) rotate(0deg);color:var(--dsw-alias-label-caption);pointer-events:none;display:inline-flex;transition:transform .12s}
.dslollama_selectWrap .dslollama_selectChevronOpen{transform:translateY(-50%) rotate(90deg)}
.dslollama_iconButton{border:0;background:transparent;color:var(--dsw-alias-label-secondary);width:28px;height:28px;display:inline-flex;align-items:center;justify-content:center;border-radius:6px;cursor:pointer;padding:0}
.dslollama_iconButton:not(:disabled):hover{background:var(--dsw-alias-interactive-bg-hover)}
.dslollama_iconButtonDanger:not(:disabled):hover{background:var(--dsw-alias-interactive-bg-hover-danger);color:var(--dsw-alias-state-error-primary)}
.dslollama_btn{border:1px solid var(--dsw-alias-border-l2);border-radius:6px;background:transparent;color:var(--dsw-alias-label-primary);padding:4px 10px;font-size:12px;cursor:pointer}
.dslollama_btn:disabled{opacity:.5;cursor:default}
.dslollama_btn:not(:disabled):hover{background:var(--dsw-alias-interactive-bg-hover)}
.dslollama_btnPrimary{background:var(--dsw-alias-button-primary-fill);border-color:transparent;color:var(--dsw-alias-label-primary-foreground)}
.dslollama_btnPrimary:not(:disabled):hover{background:var(--dsw-alias-button-primary-hover)}
.dslollama_btnDanger{color:var(--dsw-alias-state-error-primary);border-color:var(--dsw-alias-border-l2)}
.dslollama_btnDanger:not(:disabled):hover{background:var(--dsw-alias-interactive-bg-hover-danger)}
.dslollama_fetchDialog{width:min(560px,100%)}
.dslollama_contextDialog{width:min(420px,100%)}
.dslollama_candidateList{list-style:none;margin:0;padding:0}
.dslollama_candidate{margin:0 0 6px}
.dslollama_candidateLabel{display:flex;gap:8px;align-items:center;font-size:13px;color:var(--dsw-alias-label-primary)}
.dslollama_candidateId{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
`;
		const tagId = "@zhangyi/dsh-llm-ollama/ollama.css";
		if (typeof document !== "undefined" && document.querySelector(`style[data-plugin-css="${tagId}"]`) === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@zhangyi/dsh-llm-ollama";
			tag.dataset.pluginCss = tagId;
			tag.textContent = css;
			document.head.appendChild(tag);
		}

		/**
		* Model list editor: rows of id/name with expandable capacities, plus a
		* "fetch from the server" action that interrogates /api/tags through the
		* host plugin.
		*/
		function ModelListEditor(props) {
			const { api, t, baseURL, models, onChange, disabled } = props;
			const [busy, setBusy] = react.useState(false);
			const [failure, setFailure] = react.useState(void 0);
			const [candidates, setCandidates] = react.useState(void 0);
			const [picked, setPicked] = react.useState(new Set());
			const [expanded, setExpanded] = react.useState(new Set());

			const fetchModels = async () => {
				setBusy(true);
				setFailure(void 0);
				try {
					const response = await api.llm.discoverModels({
						settingsNs: NS,
						...(baseURL.trim().length > 0 ? { baseURL: baseURL.trim() } : {}),
						api: OLLAMA_API
					});
					if (!response.result.ok) {
						setFailure(response.result.error.message);
						return;
					}
					const found = response.result.value.models;
					if (found.length === 0) {
						setFailure(t("fetchEmpty"));
						return;
					}
					const known = new Set(models.map((model) => stringOf(model.id)));
					setCandidates(found);
					setPicked(new Set(found.filter((model) => !known.has(model.id)).map((model) => model.id)));
				} catch (error) {
					setFailure(messageOf(error));
				} finally {
					setBusy(false);
				}
			};
			const adoptPicked = () => {
				if (candidates === void 0) return;
				const byId = new Map(models.map((model) => [stringOf(model.id), model]));
				for (const candidate of candidates) {
					if (!picked.has(candidate.id)) continue;
					byId.set(candidate.id, byId.get(candidate.id) ?? { id: candidate.id, ...(candidate.name !== void 0 ? { name: candidate.name } : {}) });
				}
				onChange([...byId.values()]);
				setCandidates(void 0);
				setPicked(new Set());
			};
			const patch = (index, next) => {
				onChange(models.map((model, at) => {
					if (at !== index) return model;
					const cleared = new Set(Object.entries(next).filter(([, value]) => value === void 0 || value === "").map(([key]) => key));
					return Object.fromEntries(Object.entries({ ...model, ...next }).filter(([key]) => !cleared.has(key)));
				}));
			};
			const editCapacity = (index, field, text) => {
				const parsed = parseCapacity(text);
				if (parsed === void 0 || Number.isNaN(parsed)) {
					// blank clears; unreadable text simply does not commit (the
					// controlled input snaps back to the stored value)
					if (parsed === void 0) patch(index, { [field]: void 0 });
					return;
				}
				if (!Number.isInteger(parsed) || parsed <= 0) return;
				patch(index, { [field]: parsed });
			};
			const capacityText = (model, field) => {
				const value = model[field];
				return typeof value === "number" ? formatCapacity(value) : "";
			};
			const toggleExpanded = (index) => {
				setExpanded((current) => {
					const next = new Set(current);
					if (!next.delete(index)) next.add(index);
					return next;
				});
			};
			const togglePicked = (id) => {
				setPicked((current) => {
					const next = new Set(current);
					if (!next.delete(id)) next.add(id);
					return next;
				});
			};

			return react.createElement("div", { className: "dslollama_models" },
				react.createElement("div", { className: "dslollama_modelsHead" },
					react.createElement("span", { className: "dslollama_modelsTitle" }, t("models")),
					react.createElement("button", {
						className: "dslollama_btn",
						disabled: disabled || busy || baseURL.trim().length === 0,
						title: baseURL.trim().length === 0 ? t("fetchNeedsBaseUrl") : void 0,
						onClick: () => { fetchModels(); }
					}, busy ? t("fetching") : t("fetchModels"))
				),
				models.length === 0 ? react.createElement("p", { className: "dslollama_hint" }, t("modelsEmpty")) : null,
				models.map((model, index) => react.createElement("div", { key: index, className: "dslollama_card", style: { padding: 10, marginBottom: 8 } },
					react.createElement("div", { className: "dslollama_modelRow" },
						react.createElement("input", { className: "dslollama_input", type: "text", value: stringOf(model.id), placeholder: t("modelId"), disabled, onChange: (e) => patch(index, { id: e.target.value }) }),
						react.createElement("input", { className: "dslollama_input", type: "text", value: stringOf(model.name), placeholder: t("modelName"), disabled, onChange: (e) => patch(index, { name: e.target.value === "" ? void 0 : e.target.value }) }),
						react.createElement("button", { className: "dslollama_iconButton", type: "button", title: t("expandCapacities"), "aria-label": `${t("expandCapacities")} ${index + 1}`, "aria-expanded": expanded.has(index), disabled, onClick: () => toggleExpanded(index) },
							react.createElement(IconChevron, { open: expanded.has(index) })),
						react.createElement("button", { className: "dslollama_iconButton dslollama_iconButtonDanger", type: "button", title: t("removeModel"), "aria-label": `${t("removeModel")} ${index + 1}`, disabled, onClick: () => onChange(models.filter((_m, at) => at !== index)) },
							react.createElement(IconTrash, null))
					),
					expanded.has(index) ? react.createElement("div", { className: "dslollama_modelAdvanced" },
						react.createElement("div", { className: "dslollama_field" },
							react.createElement("span", { className: "dslollama_label" }, t("contextWindow")),
							react.createElement("input", { className: "dslollama_input", type: "text", inputMode: "numeric", value: capacityText(model, "contextWindow"), placeholder: "32K", disabled, onChange: (e) => editCapacity(index, "contextWindow", e.target.value) })),
						react.createElement("div", { className: "dslollama_field" },
							react.createElement("span", { className: "dslollama_label" }, t("maxTokens")),
							react.createElement("input", { className: "dslollama_input", type: "text", inputMode: "numeric", value: capacityText(model, "maxTokens"), placeholder: "32K", disabled, onChange: (e) => editCapacity(index, "maxTokens", e.target.value) })),
						react.createElement("p", { className: "dslollama_hint dslollama_spanFull" }, t("ollamaNumCtxHint")),
						react.createElement(FieldSelect, { label: t("thinkingCapable"), spanFull: true, disabled, value: model.thinkingCapable === true ? "true" : model.thinkingCapable === false ? "false" : "", onChange: (e) => { const next = e.target.value; patch(index, { thinkingCapable: next === "true" ? true : next === "false" ? false : void 0 }); },
							children: [
								react.createElement("option", { value: "" }, t("thinkingCapableAuto")),
								react.createElement("option", { value: "true" }, t("thinkingCapableForce")),
								react.createElement("option", { value: "false" }, t("thinkingCapableHide"))
							] }),
						model.thinkingCapable !== false ? react.createElement(react.Fragment, null,
							react.createElement(FieldSelect, { label: t("thinkingMode"), disabled, value: model.thinkingMode === "levels" ? "levels" : "boolean", onChange: (e) => { const mode = e.target.value; const ids = EFFORT_IDS_BY_MODE[mode]; const current = model.reasoningEffort; patch(index, { thinkingMode: mode, ...(current !== void 0 && !ids.includes(current) ? { reasoningEffort: void 0 } : {}) }); },
								children: [
									react.createElement("option", { value: "boolean" }, t("thinkingModeBoolean")),
									react.createElement("option", { value: "levels" }, t("thinkingModeLevels"))
								] }),
							react.createElement(FieldSelect, { label: t("reasoningEffort"), disabled, value: stringOf(model.reasoningEffort), onChange: (e) => { const next = e.target.value; patch(index, { reasoningEffort: next.length === 0 ? void 0 : next }); },
								children: [
									react.createElement("option", { value: "" }, t("reasoningEffortDefault")),
									(model.thinkingMode === "levels" ? [["off", t("effortOff")], ["low", t("effortLow")], ["medium", t("effortMedium")], ["high", t("effortHigh")], ["max", t("effortMax")]] : [["off", t("effortOff")], ["on", t("effortOn")]]).map(([level, label]) => react.createElement("option", { key: level, value: level }, label))
								] }),
							react.createElement("p", { className: "dslollama_hint dslollama_spanFull" }, t("reasoningEffortHint"))) : null,
						react.createElement("p", { className: "dslollama_hint dslollama_spanFull" }, t("thinkingCapableHint"))
					) : null
				)),
				react.createElement("button", { className: "dslollama_btn", disabled, onClick: () => onChange([...models, { id: "" }]) }, t("addModel")),
				failure !== void 0 ? react.createElement("p", { className: "dslollama_error" }, failure) : null,
				react.createElement(_deepseek_ai_dsh_client_ui_primitives.Modal, {
					open: candidates !== void 0,
					onClose: () => { setCandidates(void 0); setPicked(new Set()); },
					title: t("fetchTitle"),
					closeLabel: t("close"),
					description: t("fetchDescription"),
					className: "dslollama_fetchDialog",
					footer: react.createElement("div", { style: { display: "flex", gap: 8, justifyContent: "flex-end" } },
						react.createElement(_deepseek_ai_dsh_client_ui_primitives.Button, { variant: "outline", onClick: () => { setCandidates(void 0); setPicked(new Set()); } }, t("cancel")),
						react.createElement(_deepseek_ai_dsh_client_ui_primitives.Button, { variant: "outline", onClick: adoptPicked }, t("fetchAdopt")))
				}, react.createElement("ul", { className: "dslollama_candidateList" },
					(candidates ?? []).map((candidate) => react.createElement("li", { key: candidate.id, className: "dslollama_candidate" },
						react.createElement("label", { className: "dslollama_candidateLabel" },
							react.createElement("input", { type: "checkbox", checked: picked.has(candidate.id), onChange: () => togglePicked(candidate.id) }),
							react.createElement("span", { className: "dslollama_candidateId" }, candidate.id))))))
			);
		}

		/**
		* One provider card: edits one route's profile in the `llm-ollama`
		* namespace and writes it through the settings wire API.
		*/
		function ProviderCard(props) {
			const { api, t, route, profile, taken, writable, revision, onDone, onCancel } = props;
			const isConfigured = profile !== void 0;
			const isNew = route === void 0;
			const [routeDraft, setRouteDraft] = react.useState(isNew ? "" : route);
			const [displayName, setDisplayName] = react.useState(isConfigured ? stringOf(profile.displayName) : "");
			const [baseURL, setBaseURL] = react.useState(isConfigured ? stringOf(profile.baseURL) : "");
			const [keepAlive, setKeepAlive] = react.useState(isConfigured ? stringOf(profile.keepAlive) : "");
			const [temperature, setTemperature] = react.useState(isConfigured ? numberTextOf(profile.temperature) : "");
			const [keyDraft, setKeyDraft] = react.useState("");
			const [models, setModels] = react.useState(isConfigured ? (Array.isArray(profile.models) ? profile.models.map((model) => ({ ...model })) : []) : []);
			const [busy, setBusy] = react.useState(false);
			const [failure, setFailure] = react.useState(void 0);
			const [saved, setSaved] = react.useState(false);
			const [confirmDelete, setConfirmDelete] = react.useState(false);
			const [deleting, setDeleting] = react.useState(false);

			const routeInvalid = routeDraft.length > 0 && !ROUTE_PATTERN.test(routeDraft);
			const routeTaken = isNew && taken.includes(routeDraft);
			const effectiveRoute = isNew ? routeDraft : route;
			const temperatureNumber = Number.parseFloat(temperature);
			const temperatureValid = temperature.trim().length === 0 || Number.isFinite(temperatureNumber) && temperatureNumber >= 0 && temperatureNumber <= 2;
			const modelError = (() => {
				const seen = new Set();
				for (const model of models) {
					const id = stringOf(model.id).trim();
					if (id.length === 0) return t("modelInvalid");
					if (seen.has(id)) return t("modelInvalid");
					seen.add(id);
					for (const field of ["contextWindow", "maxTokens"]) {
						const value = model[field];
						if (value !== void 0 && (typeof value !== "number" || !Number.isInteger(value) || value <= 0)) return t("modelInvalid");
					}
					if (model.thinkingCapable !== void 0 && typeof model.thinkingCapable !== "boolean") return t("modelInvalid");
					if (model.thinkingMode !== void 0 && !THINK_MODES.includes(model.thinkingMode)) return t("modelInvalid");
					const mode = model.thinkingMode === "levels" ? "levels" : "boolean";
					if (model.reasoningEffort !== void 0 && !EFFORT_IDS_BY_MODE[mode].includes(model.reasoningEffort)) return t("modelInvalid");
				}
				return void 0;
			})();
			const ready = effectiveRoute !== void 0 && effectiveRoute.length > 0 && !routeInvalid && !routeTaken && baseURL.trim().length > 0 && modelError === void 0 && temperatureValid;

			const save = async () => {
				setBusy(true);
				setFailure(void 0);
				setSaved(false);
				try {
					const storesKey = keyDraft.trim().length > 0;
					const keyRef = deriveKeyRef(effectiveRoute);
					const profileValue = {
						...(displayName.trim().length > 0 ? { displayName: displayName.trim() } : {}),
						api: OLLAMA_API,
						baseURL: baseURL.trim(),
						...(storesKey ? { apiKeyEnv: keyRef } : {}),
						models: models.map((model) => {
							const next = { id: stringOf(model.id).trim() };
							if (stringOf(model.name).trim().length > 0) next.name = model.name.trim();
							if (model.contextWindow !== void 0) next.contextWindow = model.contextWindow;
							if (model.maxTokens !== void 0) next.maxTokens = model.maxTokens;
							if (model.reasoningEffort !== void 0) next.reasoningEffort = model.reasoningEffort;
							if (model.thinkingCapable !== void 0) next.thinkingCapable = model.thinkingCapable;
							if (model.thinkingMode === "levels") next.thinkingMode = "levels";
							return next;
						}),
						...(keepAlive.trim().length > 0 ? { keepAlive: keepAlive.trim() } : {}),
						...(temperature.trim().length > 0 ? { temperature: temperatureNumber } : {})
					};
					const response = await api.settings.mutate({
						ns: NS,
						ops: [{ op: "set", path: ["providers", effectiveRoute], value: profileValue }],
						expectedRevision: revision
					});
					if (!response.result.ok) {
						setFailure(isSettingsConflict(response.result.error.code) ? t("conflict") : response.result.error.message);
						return;
					}
					if (storesKey) {
						const stored = await api.credentials.set({ ref: keyRef, value: keyDraft.trim() });
						if (!stored.result.ok) {
							setFailure(stored.result.error.message);
							return;
						}
					}
					setSaved(true);
					onDone();
				} catch (error) {
					setFailure(messageOf(error));
				} finally {
					setBusy(false);
				}
			};
			const remove = async () => {
				setDeleting(true);
				setFailure(void 0);
				try {
					if (isConfigured && typeof profile.apiKeyEnv === "string" && profile.apiKeyEnv.length > 0) {
						const credential = await api.credentials.unset({ ref: profile.apiKeyEnv });
						if (!credential.result.ok) {
							setFailure(credential.result.error.message);
							return;
						}
					}
					const response = await api.settings.mutate({
						ns: NS,
						ops: [{ op: "unset", path: ["providers", effectiveRoute] }],
						expectedRevision: revision
					});
					if (!response.result.ok) {
						setFailure(isSettingsConflict(response.result.error.code) ? t("conflict") : response.result.error.message);
						return;
					}
					onDone();
				} catch (error) {
					setFailure(messageOf(error));
				} finally {
					setDeleting(false);
				}
			};

			const field = (label, children) => react.createElement("div", { className: "dslollama_field" },
				react.createElement("span", { className: "dslollama_label" }, label),
				children
			);
			const textInput = (value, onChange, placeholder, extra) => react.createElement("input", Object.assign({
				className: "dslollama_input",
				type: "text",
				value,
				placeholder,
				disabled: busy || !writable,
				onChange
			}, extra || {}));

			return react.createElement("div", { className: "dslollama_card" },
				react.createElement("div", { className: "dslollama_cardHead" },
					react.createElement("span", { className: "dslollama_name" }, displayName.trim().length > 0 ? displayName : (isNew ? t("add") : effectiveRoute)),
					react.createElement("span", { className: "dslollama_route" }, effectiveRoute),
					isConfigured
						? react.createElement("span", { className: "dslollama_tag dslollama_tagOk" }, t("configured"))
						: react.createElement("span", { className: "dslollama_tag" }, t("custom"))
				),
				isNew ? field(t("route"), react.createElement("div", null,
					textInput(routeDraft, (e) => setRouteDraft(e.target.value), "my-ollama"),
					routeInvalid ? react.createElement("p", { className: "dslollama_error" }, t("routeInvalid"))
						: routeTaken ? react.createElement("p", { className: "dslollama_error" }, t("routeTaken"))
						: react.createElement("p", { className: "dslollama_hint" }, t("routeHint"))
				)) : null,
				field(t("displayName"), textInput(displayName, (e) => setDisplayName(e.target.value), effectiveRoute)),
				field(t("baseUrl"), react.createElement("div", null,
					textInput(baseURL, (e) => setBaseURL(e.target.value), t("baseUrlPlaceholder")),
					react.createElement("p", { className: "dslollama_hint" }, t("baseUrlHint"))
				)),
				react.createElement("div", { className: "dslollama_fieldRow" },
					field(t("keepAlive"), textInput(keepAlive, (e) => setKeepAlive(e.target.value), "5m")),
					field(t("temperature"), react.createElement("div", null,
						textInput(temperature, (e) => setTemperature(e.target.value), "0.8", { inputMode: "decimal" }),
						temperature.trim().length > 0 && !temperatureValid ? react.createElement("p", { className: "dslollama_error" }, t("temperatureInvalid")) : null
					))
				),
				field(t("keyInput"), textInput(keyDraft, (e) => setKeyDraft(e.target.value), t("keyPlaceholder"), { type: "password", autoComplete: "off" })),
				react.createElement(ModelListEditor, { api, t, baseURL, models, onChange: setModels, disabled: busy || !writable }),
				!isConfigured ? react.createElement("p", { className: "dslollama_hint" }, t("notConfigured")) : null,
				modelError !== void 0 ? react.createElement("p", { className: "dslollama_error" }, modelError) : null,
				failure !== void 0 ? react.createElement("p", { className: "dslollama_error" }, failure) : null,
				saved ? react.createElement("p", { className: "dslollama_hint", role: "status" }, t("saved")) : null,
				react.createElement("div", { style: { display: "flex", gap: 8, marginTop: 4 } },
					react.createElement("button", { className: "dslollama_btn dslollama_btnPrimary", disabled: busy || deleting || !writable || !ready, onClick: () => { save(); } },
						busy ? t("saving") : t("save")),
					isConfigured ? (confirmDelete
						? react.createElement("div", { style: { display: "flex", gap: 8, alignItems: "center" } },
							react.createElement("span", { className: "dslollama_label" }, t("deleteConfirm")),
							react.createElement("button", { className: "dslollama_btn dslollama_btnDanger", disabled: busy || deleting || !writable, onClick: () => { remove(); } }, deleting ? t("deleting") : t("delete")),
							react.createElement("button", { className: "dslollama_btn", disabled: busy || deleting, onClick: () => setConfirmDelete(false) }, t("cancel")))
						: react.createElement("button", { className: "dslollama_btn dslollama_btnDanger", disabled: busy || !writable, onClick: () => setConfirmDelete(true) }, t("delete")))
					: isNew ? react.createElement("button", { className: "dslollama_btn", disabled: busy || !writable, onClick: onCancel }, t("cancel")) : null
				)
			);
		}

		/**
		* The whole-page Ollama settings section. Joins the `llm-ollama`
		* namespace view (profiles) with the configurable-provider directory,
		* then renders one card per provider (the dormant `ollama` route appears
		* as an unconfigured card) plus an "add provider" action.
		*/
		function OllamaSection(props) {
			const { api, t, subscribe } = props;
			const [snapshot, setSnapshot] = react.useState({ status: "loading", error: null, writable: false, revision: 0, rows: [] });
			const [adding, setAdding] = react.useState(false);
			const loadRef = react.useRef(null);

			const load = () => {
				setSnapshot((current) => ({ ...current, status: "loading", error: null }));
				Promise.all([api.settings.describe({}), api.llm.providers({})]).then(([settingsRes, providersRes]) => {
					if (!settingsRes.result.ok) throw new Error(settingsRes.result.error.message);
					if (!providersRes.result.ok) throw new Error(providersRes.result.error.message);
					const ns = settingsRes.result.value.namespaces.find((candidate) => candidate.ns === "llm-ollama");
					const value = ns?.value ?? { providers: {} };
					const profiles = new Map(Object.entries(value.providers ?? {}).map(([route, profile]) => [route, profile]));
					const directory = providersRes.result.value.providers.filter((entry) => entry.settingsNs === "llm-ollama");
					// Every directory route, plus any configured profile route not in the directory.
					const routes = new Set(directory.map((entry) => entry.provider));
					for (const route of profiles.keys()) routes.add(route);
					const rows = [...routes].map((route) => ({ route, profile: profiles.get(route) }));
					setSnapshot({ status: "ready", error: null, writable: settingsRes.result.value.writable, revision: ns?.revision ?? 0, rows });
				}, (error) => {
					setSnapshot((current) => ({ ...current, status: "error", error: messageOf(error) }));
				});
			};
			loadRef.current = load;

			react.useEffect(() => {
				loadRef.current();
				return subscribe !== void 0 ? subscribe(() => loadRef.current()) : void 0;
			}, []);

			if (snapshot.status === "loading") {
				return react.createElement("div", { className: "dslollama_section" }, react.createElement("p", { className: "dslollama_hint" }, "…"));
			}
			if (snapshot.status === "error") {
				return react.createElement("div", { className: "dslollama_section" },
					react.createElement("p", { className: "dslollama_error" }, `${t("loadFailed")}: ${snapshot.error}`),
					react.createElement("button", { className: "dslollama_btn", onClick: load }, t("retry"))
				);
			}
			const taken = snapshot.rows.map((row) => row.route);
			return react.createElement("div", { className: "dslollama_section" },
				react.createElement("h2", { className: "dslollama_title" }, t("title")),
				react.createElement("p", { className: "dslollama_intro" }, t("intro")),
				!snapshot.writable ? react.createElement("p", { className: "dslollama_notice" }, t("readOnly")) : null,
				snapshot.rows.map((row) => react.createElement(ProviderCard, {
					key: row.route,
					api,
					t,
					route: row.route,
					profile: row.profile,
					taken,
					writable: snapshot.writable,
					revision: snapshot.revision,
					onDone: load
				})),
				adding ? react.createElement(ProviderCard, {
					api,
					t,
					route: void 0,
					profile: void 0,
					taken,
					writable: snapshot.writable,
					revision: snapshot.revision,
					onDone: () => { setAdding(false); load(); },
					onCancel: () => setAdding(false)
				}) : react.createElement("button", { className: "dslollama_btn", disabled: !snapshot.writable, onClick: () => setAdding(true) },
					react.createElement(_deepseek_ai_dsh_client_ui_primitives.IconPlusOutline16, { size: 14 }), " ", t("add"))
			);
		}

		/**
		* Tiny module-level store for the /ollama-context custom-value modal. The popup
		* shell (popupSelect) closes as soon as its option is picked, so the
		* "custom value" flow hands off here: the modal renders into
		* `shell.overlay` and subscribes to this store. Snapshot identity is
		* stable between open/close so it is safe as a useSyncExternalStore
		* source.
		*/
		const modalStore = (() => {
			let state = { open: false, sessionId: void 0 };
			const listeners = new Set();
			return {
				subscribe(listener) {
					listeners.add(listener);
					return () => listeners.delete(listener);
				},
				getSnapshot() {
					return state;
				},
				open(sessionId) {
					state = { open: true, sessionId };
					for (const listener of [...listeners]) listener();
				},
				close() {
					state = { open: false, sessionId: void 0 };
					for (const listener of [...listeners]) listener();
				}
			};
		})();

		/**
		* Custom-value modal for the /ollama-context command: a free-text capacity
		* input (4K / 32K / 1M / raw token counts) plus quick preset chips.
		* Saving writes the session-scoped override into the `llm-ollama`
		* namespace (`sessions.<sessionId>.contextWindow`), which the host
		* adapter then sends as `options.num_ctx` for this session's requests.
		*/
		function ContextSizeModal(props) {
			const { api, t } = props;
			const state = react.useSyncExternalStore(modalStore.subscribe, modalStore.getSnapshot);
			const [draft, setDraft] = react.useState("");
			const [busy, setBusy] = react.useState(false);
			const [error, setError] = react.useState(void 0);
			const [saved, setSaved] = react.useState(false);

			react.useEffect(() => {
				if (!state.open) return;
				setDraft("");
				setBusy(false);
				setError(void 0);
				setSaved(false);
				let cancelled = false;
				api.settings.describe({}).then((response) => {
					if (cancelled) return;
					if (!response.result.ok) return;
					const ns = response.result.value.namespaces.find((candidate) => candidate.ns === NS);
					const current = ns?.value?.sessions?.[state.sessionId]?.contextWindow;
					if (typeof current === "number" && !Number.isNaN(current)) setDraft(formatCapacity(current));
				}).catch(() => {});
				return () => {
					cancelled = true;
				};
			}, [state.open, state.sessionId]);

			const parsed = parseCapacity(draft);
			const parsedValid = parsed !== void 0 && !Number.isNaN(parsed) && Number.isInteger(parsed) && parsed > 0;

			const applyCustom = async () => {
				if (!parsedValid) {
					setError(t("customInvalid"));
					return;
				}
				setBusy(true);
				setError(void 0);
				setSaved(false);
				try {
					const response = await api.settings.mutate({
						ns: NS,
						ops: [{ op: "set", path: ["sessions", state.sessionId], value: { contextWindow: parsed } }]
					});
					if (!response.result.ok) {
						setError(isSettingsConflict(response.result.error.code) ? t("conflict") : response.result.error.message);
						return;
					}
					setSaved(true);
					setTimeout(() => modalStore.close(), 450);
				} catch (error) {
					setError(messageOf(error));
				} finally {
					setBusy(false);
				}
			};

			return react.createElement(_deepseek_ai_dsh_client_ui_primitives.Modal, {
				open: state.open,
				onClose: () => modalStore.close(),
				title: t("contextTitle"),
				closeLabel: t("close"),
				description: t("contextDescription"),
				className: "dslollama_contextDialog",
				footer: react.createElement("div", { style: { display: "flex", gap: 8, justifyContent: "flex-end", alignItems: "center" } },
					saved ? react.createElement("span", { className: "dslollama_hint", role: "status" }, t("contextSaved")) : null,
					react.createElement(_deepseek_ai_dsh_client_ui_primitives.Button, { variant: "outline", disabled: busy, onClick: () => modalStore.close() }, t("cancel")),
					react.createElement(_deepseek_ai_dsh_client_ui_primitives.Button, { variant: "primary", disabled: busy || !parsedValid, onClick: () => { applyCustom(); } }, busy ? t("saving") : t("save")))
			},
				react.createElement("div", { style: { display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 10 } },
					PRESET_CONTEXTS.map((size) => react.createElement("button", {
						key: size,
						type: "button",
						className: "dslollama_btn",
						disabled: busy,
						onClick: () => { setDraft(formatCapacity(size)); setError(void 0); }
					}, formatCapacity(size)))),
				react.createElement("div", { className: "dslollama_field" },
					react.createElement("span", { className: "dslollama_label" }, t("contextWindow")),
					react.createElement("input", {
						className: "dslollama_input",
						type: "text",
						inputMode: "numeric",
						value: draft,
						placeholder: "32K",
						autoFocus: true,
						disabled: busy,
						onChange: (e) => setDraft(e.target.value),
						onKeyDown: (e) => {
							if (e.key === "Enter") {
								e.preventDefault();
								applyCustom();
							}
						}
					}),
					parsedValid && draft.trim().length > 0
						? react.createElement("p", { className: "dslollama_hint" }, `${formatCapacity(parsed)} = ${String(parsed)} tokens`)
						: react.createElement("p", { className: "dslollama_hint" }, t("customHint")),
					error !== void 0 ? react.createElement("p", { className: "dslollama_error" }, error) : null
				)
			);
		}

		// Every Remote namespace is its own injected property: cordis throws
		// `cannot get property "remote.settings" without inject` on an undeclared
		// one, and the slots runtime answers such a throw by abdicating the entry
		// — the Ollama panel then opens blank instead of failing loudly.
		const inject = [
			"slots",
			"locale",
			"connection",
			"remote",
			"remote.credentials",
			"remote.llm",
			"remote.settings",
			"commandUi"
		];

		/**
		* Wire calls as the client used to reach them: one `{ result }` envelope
		* per call, unary verbs taking a single request object.
		*
		* The harness moved every Host capability onto the typed Remote face and
		* dropped `api` from the Connection handle (`ctx.connection` now carries
		* only connection state and `reconnect`), so this section's calls have to
		* be re-expressed over `ctx.remote`: each namespace is a method group
		* (`settings.describe()`, `credentials.set(ref, value)`,
		* `llm.listConfigurableProviders()`, `llm.discoverModels(ns, request)`)
		* that answers a RemoteResult (`{ok:true,value}` / `{ok:false,error}`),
		* and the settings namespace + edit list are positional arguments rather
		* than fields of one request object. Adapting here keeps every call site
		* below unchanged.
		*/
		function remoteApi(remote) {
			const settle = async (call) => ({ result: await call });
			const unwrap = (response, value) => response.ok ? { result: { ok: true, value: value(response.value) } } : { result: response };
			return {
				settings: {
					describe: () => settle(remote.settings.describe()),
					mutate: ({ ns, ops, expectedRevision }) => settle(remote.settings.mutate(ns, ops, expectedRevision))
				},
				credentials: {
					set: ({ ref, value }) => settle(remote.credentials.set(ref, value)),
					unset: ({ ref }) => settle(remote.credentials.unset(ref))
				},
				llm: {
					// The configurable-provider directory: one entry per route an adapter
					// can activate, each naming the settings namespace that configures it.
					providers: async () => unwrap(await remote.llm.listConfigurableProviders(), (providers) => ({ providers })),
					// The answer is the model list itself; the legacy envelope nested it
					// under `models`.
					discoverModels: async ({ settingsNs, ...request }) => unwrap(await remote.llm.discoverModels(settingsNs, request), (models) => ({ models }))
				}
			};
		}

		/** Whether a settings write lost the optimistic-concurrency check. */
		function isSettingsConflict(code) {
			return code === "settings/conflict" || code === "settings-conflict";
		}

		function apply(ctx) {
			ctx.effect(() => ctx.locale.register(NS, { zh, en }), "dsh-llm-ollama: copy dictionaries");
			const t = ctx.locale.bind(NS);
			// Harnesses before the Remote migration answered these calls on
			// `connection.api`; current ones do not carry it at all.
			const api = ctx.get("connection")?.api ?? remoteApi(ctx.remote);
			const commandUi = ctx.get("commandUi");
			const refreshListeners = new Set();
			const subscribe = (listener) => {
				refreshListeners.add(listener);
				return () => refreshListeners.delete(listener);
			};
			const injected = () => ({ api, t, subscribe });

			// /ollama-context: session-scoped context-window override. A popupSelect
			// panel offers "follow system", the common presets, and a custom
			// value; picking a preset or follow writes the override (or removes
			// it) straight into the `llm-ollama` namespace, while "custom"
			// hands off to the ContextSizeModal above. Registered inside an
			// effect so the locale dictionary (registered above) is in place
			// when the description is resolved, and so the registration is
			// disposed with this plugin's fiber.
			ctx.effect(() => {
				commandUi.register({
					name: "ollama-context",
					description: t("commandDesc"),
					available: () => true,
					ui: {
						kind: "popupSelect",
						options: async (session) => {
							let current;
							try {
								const response = await api.settings.describe({});
								if (response.result.ok) {
									const ns = response.result.value.namespaces.find((candidate) => candidate.ns === NS);
									current = ns?.value?.sessions?.[session.sessionId]?.contextWindow;
								}
							} catch {
								// no override read → all rows render unselected
							}
							const rows = [
								{ id: "follow", label: t("followSystem"), active: current === void 0 }
							];
							for (const size of PRESET_CONTEXTS) {
								rows.push({
									id: `ctx-${String(size)}`,
									label: formatCapacity(size),
									detail: `${String(size)} tokens`,
									active: current === size
								});
							}
							rows.push({ id: "custom", label: t("customValue"), detail: t("customHint") });
							return rows;
						},
						onSelect: async (option, session) => {
							if (option.id === "custom") {
								modalStore.open(session.sessionId);
								return;
							}
							const sessionId = session.sessionId;
							if (option.id === "follow") {
								await api.settings.mutate({
									ns: NS,
									ops: [{ op: "unset", path: ["sessions", sessionId] }]
								});
								return;
							}
							const size = Number(option.id.slice(4));
							await api.settings.mutate({
								ns: NS,
								ops: [{ op: "set", path: ["sessions", sessionId], value: { contextWindow: size } }]
							});
						}
					}
				});
			}, "dsh-llm-ollama: /ollama-context command");
			ctx.slots.inject("shell.overlay", () => ctx.slots.register({
				name: "shell.overlay",
				id: "ollama-context-modal",
				order: 1,
				inject: () => ({ api, t })
			}, ContextSizeModal));
			ctx.slots.inject("settings.section", () => ctx.slots.register({
				name: "settings.section",
				id: "ollama",
				order: 11,
				label: () => t("nav"),
				inject: injected
			}, OllamaSection));
			// The settings shell currently chooses section icons internally and falls
			// back to the gear for plugin-owned sections. Reuse the Models icon for
			// Ollama until the shell exposes an icon slot/configuration field.
			ctx.effect(() => {
				if (typeof document === "undefined" || typeof MutationObserver === "undefined") return;
				const copyModelsIcon = () => {
					const buttons = [...document.querySelectorAll("button")];
					const ollamaButton = buttons.find((button) => button.textContent?.trim() === t("nav"));
					const modelsButton = buttons.find((button) => {
						const label = button.textContent?.trim();
						return label === "Models" || label === "模型";
					});
					const sourceIcon = modelsButton?.querySelector("svg");
					if (ollamaButton === void 0 || sourceIcon === null) return;
					const currentIcon = ollamaButton.querySelector("svg");
					if (currentIcon === null) {
						ollamaButton.prepend(sourceIcon.cloneNode(true));
					} else if (currentIcon.outerHTML !== sourceIcon.outerHTML) {
						currentIcon.replaceWith(sourceIcon.cloneNode(true));
					}
				};
				copyModelsIcon();
				const observer = new MutationObserver(copyModelsIcon);
				observer.observe(document.body, { childList: true, subtree: true });
				return () => observer.disconnect();
			}, "dsh-llm-ollama: reuse Models settings icon");
			ctx.effect(() => {
				const notify = () => {
					for (const listener of [...refreshListeners]) {
						try {
							listener();
						} catch (error) {
							console.error("dsh-llm-ollama: refresh listener failed", error);
						}
					}
				};
				const disposers = [
					ctx.remote.$on("settings/document-updated", notify),
					ctx.remote.$on("llm/adapters-updated", notify),
					ctx.on("connection/reset", notify)
				];
				return () => {
					for (const dispose of disposers) dispose();
				};
			}, "dsh-llm-ollama: invalidations");
		}

		exports.apply = apply;
		exports.inject = inject;
		return module.exports;
	}
});
