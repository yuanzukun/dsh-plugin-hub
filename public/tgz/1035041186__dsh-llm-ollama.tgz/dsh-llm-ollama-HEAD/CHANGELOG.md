# 更新日志

所有项目变更都会记录在此文件中。

---

## [v0.1.17] - 2026-09-10 10:40:03

**更新作者**: ZhangYi
**更新类型**: BUG修复

### 更新内容
- 修复 **DSH 升级后设置页 Ollama 面板「打不开 / 打开是空白」** 的问题。根因有两处，均来自 harness 0.1.2-rc.1 的 Remote 迁移：
  - **`ctx.connection.api` 已不存在**：Connection 句柄现在只携带 `generation` / `state` / `reconnect` / `rpc`，旧代码取到 `undefined` 后在 `useEffect` 里同步抛错。新增 `remoteApi()` 适配层，把本节全部调用改走类型化 Remote 面（`ctx.remote.<ns>.<method>()`），并把 RemoteResult（`{ok,value}` / `{ok,error}`）重新包成旧的 `{result: …}` 信封，所有调用点保持不变：
    - `settings.describe({})` → `remote.settings.describe()`
    - `settings.mutate({ns,ops,expectedRevision})` → `remote.settings.mutate(ns, ops, expectedRevision)`（改为位置传参）
    - `credentials.set/unset({ref,…})` → `remote.credentials.set/unset(ref, …)`
    - `llm.providers({})` → `remote.llm.listConfigurableProviders()`（值包回 `{providers}`）
    - `llm.discoverModels({settingsNs,…})` → `remote.llm.discoverModels(settingsNs, request)`（值包回 `{models}`）
  - **Remote 命名空间必须显式 inject**（真正的空白原因）：新版 cordis 把 `ctx.remote` 的每个命名空间当作独立注入属性，未声明即抛 `cannot get property "remote.settings" without inject`；而新版 slots 运行时会捕获条目抛错并**移除（abdicate）该条目**——界面不报错、控制台之外无迹可寻，只渲染一片空白。客户端 `inject` 因此补齐 `remote.settings` / `remote.llm` / `remote.credentials`（与官方 ui-settings-models 的写法一致）
- 兼容 settings 冲突错误码改名：`settings-conflict` → `settings/conflict`（新增 `isSettingsConflict()` 同时接受两种）
- `dsh.client.inject` 清理：移除已不存在的 `@deepseek-ai/dsh-client-runtime`，改为真实存在的 `@deepseek-ai/dsh-client-connection`、`@deepseek-ai/dsh-client-ui-commands`
- 新增两个回归脚本，供下次 harness 升级时复现同类问题：
  - `scripts/client-harness.mjs`：无依赖，直接按浏览器方式加载 client bundle，并用**复刻了 cordis inject 守卫**的假 Remote 面驱动设置页完整调用序列（13 项断言；漏声明 `remote.*` 会直接复现原始报错）
  - `scripts/browser-check.mjs`：无头 Chromium 真开「设置 → Ollama」，断言条目未被 abdicate、面板有内容、控制台零报错；`--save` 可顺带验证设置写入落盘
- 实测（隔离 `DSH_HOME` + 真实 Chromium）：修复前面板空白且控制台报 `cannot get property "remote.settings" without inject`；修复后面板完整渲染、控制台零报错，保存后 `settings.yaml` 正确写入 `llm-ollama.providers.ollama`

### 影响文件
- `client.js` — `inject` 补齐 `remote.*` 命名空间；新增 `remoteApi()` 适配层与 `isSettingsConflict()`；`apply()` 改为 `ctx.get("connection")?.api ?? remoteApi(ctx.remote)`（兼容迁移前的 harness）
- `package.json` — `dsh.client.inject` 指向真实客户端包；版本递增至 0.1.17
- `scripts/client-harness.mjs` — 新增：client bundle 回归 harness（含 cordis inject 守卫复刻）
- `scripts/browser-check.mjs` — 新增：真实浏览器面板实测脚本

---

## [v0.1.16] - 2026-08-31 17:15:55

**更新作者**: ZhangYi
**更新类型**: 需求调整

### 更新内容
- 设置页术语统一：把「思考控制」「思考等级类型」改为「**推理控制**」「**推理等级类型**」，相关选项与提示（始终显示推理型 / 始终隐藏非推理型 / 开源推理模型等）与下拉菜单的「推理等级」措辞保持一致（中英文同步）
- 三个下拉（推理控制、推理等级类型、默认推理等级）去原生箭头，改用系统风格的右侧展开/收起图标：
  - `appearance:none` 隐藏浏览器原生 select 箭头，右侧叠加与 Models 页一致的 disclosure chevron（`SelectChevron`，颜色用 `--dsw-alias-label-caption`）：**收起时朝右、展开时朝下**（rotate 90°）
  - 展开状态由 React state 驱动（`FieldSelect` 组件）：**每次点击切换**（点击一次朝下、再点一次朝右），选择后或失焦复位；鼠标态 `cursor:pointer`

### 影响文件
- `client.js` — 中英文文案推理措辞统一；新增 `SelectChevron` / `FieldSelect` 组件包装三个 select（含展开/收起 state）；新增 `.dslollama_selectWrap` 系列样式
- `README.md` — 功能特性与使用步骤中的「思考」措辞统一为「推理」
- `package.json` — 版本递增至 0.1.16

---

## [v0.1.15] - 2026-08-31 17:05:59

**更新作者**: ZhangYi
**更新类型**: 需求调整

### 更新内容
- 调整设置页模型展开行的说明顺序：把「Ollama 会将每个模型的上下文窗口…作为 num_ctx/num_predict 发送」这段提示从最下方移动到**上下文窗口 / 最大输出 token 之下、思考控制之上**，让“容量配置”与「思考控制 / 思考等级 / 默认推理等级」分组更清晰

### 影响文件
- `client.js` — 展开行中 `ollamaNumCtxHint` 提示位置调整
- `package.json` — 版本递增至 0.1.15

---

## [v0.1.14] - 2026-08-31 16:46:00

**更新作者**: ZhangYi
**更新类型**: BUG 修复

### 更新内容
- 修复 **自动识别后模型选择器打不开（右下角“选择模型”出不来）** 的问题：
  - 根因：适配器的 `resolveModel` 被 harness 在构建模型目录时逐个 `await`，而自动识别在其内部**同步等待 `GET /api/tags`**；当服务器响应慢/卡住时（实测 `/api/tags` 偶发超过 5s 甚至更久），`resolveModel` 一直挂起/异常，导致整个提供方被目录构建丢弃——右下角就没了模型
  - 修复：能力探针改为**完全非阻塞**——`resolveModel` 只读已缓存的快照、**绝不等网络**（也绝不让 `resolveModel` 抛错）；能力探测在后台执行（带 `--max-time 5` 上限、失败静默、结果按 baseURL 缓存并去重），并在插件加载/设置变化时预热
  - 效果：目录始终秒开（0ms 返回），模型选择器恢复正常；服务器 `/api/tags` 响应快时自动识别正常；响应慢/离线时模型按“非思考”安全处理（不发送 `think`），可用模型级 `thinkingCapable: true/false` 手动覆盖兜底
- 实测：冷缓存下 `resolveModel` 0ms 返回不阻塞；预热后思考型模型（capabilities 含 `thinking`）正确暴露 reasoning，非思考型不暴露

### 影响文件
- `lib/index.js` — 能力探测改为非阻塞后台探针（`readCapabilities` 同步读缓存 + 触发后台 fetch）；`resolveModel` 不再等待网络；`refreshProfiles` 预热缓存
- `package.json` — 版本递增至 0.1.14

---

## [v0.1.13] - 2026-08-31 14:09:34

**更新作者**: ZhangYi
**更新类型**: 功能新增

### 更新内容
- **自动识别思考型模型**：适配器读取 Ollama `/api/tags` 返回的每个模型 `capabilities`（含 `thinking`），据此判断模型是否思考型——只有思考型模型才在右下角模型选择器显示「推理等级」菜单（“只对思考型模型显示”），不再需要手工勾选
  - `capabilities` 按 baseURL 缓存（5 分钟 TTL）并做并发去重，避免每次解析都请求服务器、目录并行加载时重复打 `/api/tags`
  - 支持手动覆盖：模型级 `thinkingCapable` 为 `true`（始终显示）/ `false`（始终隐藏）；不设置则自动识别。设置页「思考控制」由勾选框改为「自动识别 / 始终显示 / 始终隐藏」三选下拉
  - 被判定为非思考的模型不公布 `reasoning` 元数据，因此不显示推理菜单、也不会向它发送 `think`，避免向不支持思考的模型发送 `think: true` 造成的异常
- 实测（真实 Ollama）：`qwen3.5:4b` / `qwen3.5:9b` 自动判定为思考型（`thinking` 能力），`freehuntx/qwen3-coder:14b` / `smtek/Qwen3.8-27B:IQ2_M-12gb` 判定为非思考型；手动 `true`/`false` 覆盖均生效

### 影响文件
- `lib/index.js` — 新增 `capabilities` 自动识别（缓存 + 并发去重）；`resolveModel()` 默认按能力判断，`thinkingCapable: true/false` 手动覆盖
- `client.js` — 「思考控制」三选下拉（自动/始终显示/始终隐藏）与提示文案（中英文）；保存逻辑支持持久化 `false`
- `README.md` — 功能特性、使用步骤与 settings.yaml 注释
- `package.json` — 版本递增至 0.1.13

---

## [v0.1.12] - 2026-08-31 13:58:51

**更新作者**: ZhangYi
**更新类型**: BUG 修复

### 更新内容
- 修复 **Ollama 思考型模型不再显示思考过程（“不思考”）** 的问题：
  - 根因：Ollama 原生 `/api/chat` 在开启思考时，把推理轨迹放在 `message.thinking`（此时 `message.content` 为空），末段答案放在 `message.content`；而适配器的流式解析只读取 `message.content`，完全忽略 `message.thinking`，导致思考轨迹被丢弃——模型其实在思考，但界面看不到
  - 修复：解析器新增对 `message.thinking` 的处理，作为 `reasoning` 内容块（`block-start: reasoning` / `reasoning-delta` / `block-end: {"type":"reasoning",...}`）输出，交由 harness 渲染思考过程
  - 实测：对真实 Ollama（`qwen3.5:4b`）`think:true` 请求，适配器 `stream()` 产出数百帧 `reasoning-delta` 与 `reasoning` 块；对 `think:false` 则无思考（该字段正确关闭）；不勾选（不发送 `think`）时按 Ollama 默认开启思考并显示轨迹
- `scripts/mock-ollama.mjs` 同步在 `think` 开启时模拟输出 `message.thinking`（`think:false` 时不输出），便于离线回归思考显示路径

### 影响文件
- `lib/index.js` — 流式解析新增 `message.thinking` → `reasoning` 内容块
- `scripts/mock-ollama.mjs` — 按 `body.think` 输出/抑制 `message.thinking`
- `package.json` — 版本递增至 0.1.12

---

## [v0.1.11] - 2026-08-31 13:45:47

**更新作者**: ZhangYi
**更新类型**: 需求调整

### 更新内容
- 澄清「推理型模型」勾选框语义：勾选才在右下角显示「推理等级」控制；**不勾选则遵循 Ollama 默认——支持思考的模型默认仍开启思考，只是此处无法关闭**
  - 设置页将该勾选框标记由「支持思考（推理型模型）」改为「推理型模型」，并补充说明文案（中英文）
  - 「默认推理等级」提示补充 on/off 与多档等级两种模式说明
  - README 功能特性、使用步骤与 settings.yaml 注释同步说明该默认行为

### 影响文件
- `client.js` — 「推理型模型」勾选框名称与提示、默认推理等级提示的中英文文案调整
- `README.md` — 功能特性、使用步骤与 settings.yaml 注释
- `package.json` — 版本递增至 0.1.11

---

## [v0.1.10] - 2026-08-31 13:36:58

**更新作者**: ZhangYi
**更新类型**: 功能新增

### 更新内容
- 新增**推理等级（reasoning effort）**支持：**仅对勾选了「支持思考（推理型模型）」(`thinkingCapable: true`) 的模型**，Ollama 适配器才向 harness 公布推理等级元数据，右下角模型选择器才为该模型显示「推理等级」(Effort) 菜单；纯文本模型不显示该菜单
  - 默认菜单为**开关**两项：`off` → `think: false`（关闭）、`on` → `think: true`（开启）。这与大多数开源思考模型（Qwen3、DeepSeek-R1 / v3.1）只支持布尔 `think` 一致（对齐 [Ollama Thinking 文档](https://docs.ollama.com/capabilities/thinking)）
  - 仅当模型支持多档等级（如 GPT-OSS）时，把模型级「思考等级类型」(`thinkingMode`) 设为 `levels`，菜单才扩展为 `off` / `low` / `medium` / `high` / `max`
  - 未选择等级时不发送 `think`，跟随 Ollama 默认（支持思考的模型默认开启）
- 新增模型级**支持思考**开关、**思考等级类型**与**默认推理等级**配置：在设置页展开模型勾选/设置，勾选后保存作为该模型在右下角选择器中的默认 `defaultEffort`；不设置时菜单显示“Default”
- 根因：适配器此前未在 `resolveModel()` 返回 `reasoning` 元数据，会话目录只公布提供方分组与模型，不显示推理等级行

### 影响文件
- `lib/index.js` — 新增 boolean/levels 两档思考等级常量；`resolveModel()` 仅在 `thinkingCapable` 时按 `thinkingMode` 返回 `reasoning`（含 `defaultEffort`）；`stream()` 将 `options.reasoningEffort` 映射为 `body.think`（off/on/等级）；设置 envelope 与 `resolveConfig` 校验模型级 `reasoningEffort` / `thinkingCapable` / `thinkingMode`
- `client.js` — 设置页展开行新增「支持思考」勾选框、「思考等级类型」下拉与按模式变化的「默认推理等级」下拉、校验、保存逻辑与中英文文案；重构展开行布局：把「支持思考」勾选改为整行（跨两列）的开关行，思考等级类型/默认推理等级两个下拉并排一行，避免此前勾选框被压缩在单列、下拉孤悬造成参差（新增 `dslollama_spanFull` / `dslollama_checkRow` 样式与 `select.dslollama_input` 指针）
- `README.md` — 功能特性、使用步骤与 settings.yaml 示例
- `package.json` — 版本递增至 0.1.10

---

## [v0.1.9] - 2026-08-22 21:55:00

**更新作者**: ZhangYi
**更新类型**: Bug 修复

### 更新内容
- 兼容 DeepSeek Harness 更新到 `dsh-llm@0.1.1-rc.2` 后的适配器契约：该版本起每个 `LlmAdapter` 都必须暴露 `prepareCall(provider, model, signal)`，用于把「模型元数据解析」与「实际流式分发」绑定到同一代适配器注册，避免准备与分发之间配置变化把一代能力拼到另一代端点上
  - 此前插件以纯对象字面量注册适配器，未继承抽象基类 `LlmAdapter` 提供的默认 `prepareCall`，任何路由到本插件的请求都会在 harness 内部抛出 `registration.adapter.prepareCall is not a function`，导致整轮对话失败
  - 现在在适配器对象上显式声明 `async prepareCall`：先 `await this.resolveModel(...)` 解析出该模型的完整元数据（provider/id/name/inputModalities/context/defaultMaxTokens），再返回 `{ model, stream }`，其中 `stream` 复用本适配器既有的 `stream`（保留会话级上下文覆盖、图片附件、工具调用、流式错误还原等全部既有行为）
  - 返回的 `model` 与旧代码路径 `resolveModel` 产出的形状一致，经 harness 的 `normalizeModelInfo` 校验无额外校验负担

### 影响文件
- `lib/index.js` — 适配器对象新增 `async prepareCall` 方法（`resolveModel` 之后、`stream` 之前）
- `package.json` — 版本递增至 0.1.9

---

## [v0.1.8] - 2026-08-18 22:30:00

**更新作者**: ZhangYi
**更新类型**: Bug 修复

### 更新内容
- 修复工具调用历史回传导致 Ollama 拒绝请求的问题（`ollama: stream ended without a done frame` / `STREAM_CLOSED`）：
  - 根因：Ollama 原生 `/api/chat` 要求历史消息 `tool_calls[].function.arguments` 必须是 JSON **对象**，而插件把上一次响应解析出的参数字符串原样透传，Ollama 返回 HTTP 400 `Value looks like object, but can't find closing '}' symbol`，流在 `done` 帧前被掐断——每次对话的第二个请求必然失败，与模型大小/显存无关
  - `buildMessages` 发送前将字符串形式的 `arguments` `JSON.parse` 为对象
- 修复错误被吞成泛化提示的问题：Ollama 的错误响应体（如 400）不带结尾换行符，按行解析的流式读取会把它留在缓冲区直到 EOF 才丢弃；现在 EOF 时刷新缓冲区残留行并解析其中的 `error` 字段，让真实错误以 `INVALID_REQUEST` 浮出，而非误导性的 `STREAM_CLOSED`
- `scripts/mock-ollama.mjs` 忠实模拟真实 Ollama 的该行为：请求历史中 `arguments` 为字符串时返回完全一致的 400 错误体（同样无结尾换行），并支持 `PORT` 环境变量覆盖监听端口，便于在真实 Ollama 占用 11434 时离线回归

### 影响文件
- `lib/index.js` — `buildMessages` 的 assistant tool_calls 映射改为解析 `arguments` 为对象；`stream()` 流解析在 EOF 时刷新缓冲区残留行
- `scripts/mock-ollama.mjs` — 新增字符串 `arguments` 的 400 校验与 `PORT` 环境变量
- `package.json` — 版本递增至 0.1.8

---

## [v0.1.7] - 2026-08-18 18:59:09

**更新作者**: ZhangYi
**更新类型**: 需求新增

### 更新内容
- 会话级上下文覆盖与右下角上下文指示同步：通过 `ctx.sessions` 把「实际生效的 contextWindow」（覆盖值 → 模型配置 → 默认 32K）折叠进会话日志的 `request/context` 事件（token-meter 的 `contextPressure` 投影按 last-wins 读取该事件），`/ollama-context` 调整后右下角 meter 立即跟随，发请求时再次校正以覆盖 agent-loop 写入的模型级值
  - 仅处理路由到本插件提供方（`llm-ollama` 命名空间）的会话，其他提供方的会话一律跳过，不会被本插件的默认值/覆盖值改写显示
  - 仅在生效值有变化且会话已有 provider/model 路由时追加，避免日志累积重复

### 影响文件
- `lib/index.js` — 新增 `publishContextWindow`（设置变更 watcher + `stream()` 两处触发，把生效 contextWindow 写入会话 `request/context`）
- `README.md` — 会话级上下文覆盖特性说明补充右下角上下文指示同步
- `package.json` — 版本递增至 0.1.7

---

## [v0.1.6] - 2026-08-18 16:48:42

**更新作者**: ZhangYi
**更新类型**: 需求新增

### 更新内容
- 新增图片附件支持：用户消息中的图片块（`ImageBlock`）经 `ctx.attachments.readImage` 解析为字节后，以 base64 编码放入消息的 `images` 数组发送给 Ollama `/api/chat`（JSON 协议下 `images` 字段仅接受 base64 字符串）
  - 工具结果（tool-result）中嵌套的图片同样提取到对应 `tool` 消息的 `images` 字段
  - `listModels` / `resolveModel` 的能力声明由 `['text']` 更新为 `['text', 'image']`，客户端可正常上传图片
  - 附件服务缺失或读取失败时给出明确错误（`UNSUPPORTED_CONTENT` / `ATTACHMENT_READ_FAILED`）
  - 图片需配合支持视觉的多模态模型（如 `llava`、`llama3.2-vision`、`qwen2.5vl` 等）使用，纯文本模型收到图片会由 Ollama 报错
- 移除原先「图片附件不支持」的拦截逻辑

### 影响文件
- `lib/index.js` — `buildMessages` 改为异步并新增 `contentToTextAndImages` 辅助函数；`stream()` 组装请求时 `await` 消息转换；模型能力声明加入 `image`
- `scripts/mock-ollama.mjs` — 流式回复新增 `images=N` 回显，便于断言图片透传
- `README.md` — 功能特性补充图片附件支持，已知限制改为多模态模型说明；开发调试补充 `link:` 软链实时跟随源码的说明
- `package.json` — 版本递增至 0.1.6

---

## [v0.1.5] - 2026-08-18 15:03:36

**更新作者**: ZhangYi
**更新类型**: 需求新增

### 更新内容
- 新增 `/ollama-context` 命令：在输入框输入 `/ollama-context` 即可调出当前会话的上下文窗口（Context window）设置面板
  - 面板提供常用预设（4K / 8K / 16K / 32K / 64K / 128K）、**自定义值**输入（支持 `4096`、`32K`、`1M` 等写法）以及**跟随系统配置**选项
  - 会话级覆盖的优先级高于设置页中每个模型配置的 Context window：设置了覆盖后，当前会话请求 Ollama 时以该值作为 `options.num_ctx`
  - 新会话或选择「跟随系统配置」时恢复为系统配置（模型自身的 Context window 或默认 32K）
  - 覆盖值持久化在 `llm-ollama` 设置命名空间的 `sessions.<sessionId>.contextWindow` 字段中，仅对有覆盖的会话生成记录

### 影响文件
- `lib/index.js` — 设置命名空间 schema/校验新增 `sessions` 字典；适配器 `stream()` 发送 `num_ctx` 时优先取当前会话的覆盖值
- `client.js` — 新增 `/ollama-context` 命令贡献（popupSelect 面板：预设 / 跟随系统配置 / 自定义值）与自定义值输入弹窗（挂载到 `shell.overlay`），写入会话级覆盖
- `README.md` — 功能与使用说明补充 `/ollama-context` 命令；新增「接入 Ollama：本地或远程部署」章节与已知限制更新
- `package.json` — 版本递增至 0.1.5

---

## [v0.1.4] - 2026-08-18 14:44:08

**更新作者**: ZhangYi
**更新类型**: 需求调整

### 更新内容
- 调整模型列表行布局间距：移除 `.dslollama_modelRow` 下边距，改由 `.dslollama_modelAdvanced` 上边距承担，修正高级选项行与上一行的间距

### 影响文件
- `client.js` — 调整 `.dslollama_modelRow` / `.dslollama_modelAdvanced` 样式间距

---

## [v0.1.3] - 2026-08-18 13:58:02

**更新作者**: ZhangYi
**更新类型**: 需求新增

### 更新内容
- 新增 Bundle 层自动挂载机制：`cordis.patch.yml` 补丁文件 + `package.json` 的 `dsh.bundle.patch` 元数据。`dsh plugin --profile web add` 安装成功后，dsh 自动把本包追加到 profile 的 `dsh.profile.bundles`，启动时作为 bundle 层将 `llm-ollama` 插件行挂进组合树，无需再手动编辑 `~/.dsh/profiles/web/cordis.patch.yml`
- 更新 README 安装说明：改为一步安装（`add` + 自动挂载），补充从旧版（≤0.1.2）升级的迁移指南——需先删除手动添加的 `llm-ollama` 行，避免 `duplicate loader entry id: llm-ollama` 启动错误
- 版本号由 0.1.2 递增至 0.1.3，`files` 发布清单加入 `cordis.patch.yml`

### 影响文件
- `cordis.patch.yml` — 新增 bundle 补丁，自动挂载 `llm-ollama` 插件行
- `package.json` — 新增 `dsh.bundle.patch` 元数据，版本递增至 0.1.3，发布清单加入补丁文件
- `README.md` — 更新安装/升级说明，架构章节补充 Bundle 层说明

---
