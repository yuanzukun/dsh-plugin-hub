import { createHash } from 'node:crypto'
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { describe, expect, it, vi } from 'vitest'
import {
  downloadLatestMoliBinary,
  fetchLatestMoliReleaseTag,
  findOnPath,
  getLocalMoliVersion,
  getMoliReleaseAsset,
  getPluginPackageVersion,
  isExecutableFile,
  isNewerVersion,
  parseSemVer,
  resolveCdpBackend,
  resolveMoliBinary,
  syncLatestMoliBinary,
  verifyArchiveDigest,
  withFsLockRetry,
} from '../src/moli-resolve.ts'

describe('moli-resolve', () => {
  it('findOnPath finds executables on system PATH', () => {
    const nodePath = findOnPath('node')
    expect(nodePath).toBeDefined()
    expect(typeof nodePath).toBe('string')
    expect(isExecutableFile(nodePath!)).toBe(true)
  })

  it('findOnPath returns undefined for non-existent commands', () => {
    expect(findOnPath('definitely-not-a-real-executable-xyz123')).toBeUndefined()
  })

  it('getMoliReleaseAsset returns release asset for current platform', () => {
    const asset = getMoliReleaseAsset()
    expect(asset.filename).toBeDefined()
    expect(asset.filename).toMatch(/^moli-/)
    if (process.platform === 'win32') {
      expect(asset.filename).toMatch(/\.zip$/)
      expect(asset.isZip).toBe(true)
    } else {
      expect(asset.filename).toMatch(/\.tar\.gz$/)
      expect(asset.isZip).toBe(false)
    }
  })

  it('resolveMoliBinary throws on non-existent configured path', async () => {
    await expect(resolveMoliBinary('/non/existent/path/to/moli')).rejects.toThrow(
      'configured moli path "/non/existent/path/to/moli" does not exist',
    )
  })

  it('downloadLatestMoliBinary returns existing binary or downloads', { timeout: 60_000 }, async () => {
    const bin = await downloadLatestMoliBinary()
    expect(bin).toBeDefined()
    expect(isExecutableFile(bin)).toBe(true)
  })

  it('resolveMoliBinary finds moli on PATH or fallback locations', { timeout: 60_000 }, async () => {
    const bin = await resolveMoliBinary()
    expect(bin).toBeDefined()
    expect(isExecutableFile(bin)).toBe(true)
  })

  it('getPluginPackageVersion returns valid semver from package.json', () => {
    const ver = getPluginPackageVersion()
    expect(ver).toMatch(/^\d+\.\d+\.\d+/)
  })

  it('parseSemVer parses semver strings accurately', () => {
    expect(parseSemVer('1.1.9')).toEqual([1, 1, 9])
    expect(parseSemVer('v1.1.9')).toEqual([1, 1, 9])
    expect(parseSemVer('0.5.1-alpha.1')).toEqual([0, 5, 1])
    expect(parseSemVer('invalid')).toBeNull()
  })

  it('isNewerVersion compares semver versions correctly', () => {
    expect(isNewerVersion('1.1.9', '1.1.8')).toBe(true)
    expect(isNewerVersion('1.1.8', '1.1.9')).toBe(false)
    expect(isNewerVersion('1.1.9', '1.1.9')).toBe(false)
    expect(isNewerVersion('2.0.0', '1.9.9')).toBe(true)
    expect(isNewerVersion('1.2.0', '1.1.9')).toBe(true)
    expect(isNewerVersion('1.1.9', '1.2.0')).toBe(false)
    expect(isNewerVersion('1.1.9', '1.1.9-beta.1')).toBe(true)
    expect(isNewerVersion('1.1.9-beta.1', '1.1.9')).toBe(false)
  })

  it('getLocalMoliVersion inspects binary version string', async () => {
    const bin = await resolveMoliBinary()
    const ver = await getLocalMoliVersion(bin)
    if (ver !== null) {
      expect(typeof ver).toBe('string')
      expect(ver).toMatch(/^\d+\.\d+\.\d+/)
    } else {
      expect(ver).toBeNull()
    }
  })

  // This assertion reaches the real GitHub API, so its budget must exceed
  // vitest's 5s default: a slow-but-healthy response would otherwise fail as a
  // timeout instead of exercising the "returns null" branch the assertion is
  // about. Kept unmocked so a release tag the updater cannot parse still
  // surfaces here.
  it('fetchLatestMoliReleaseTag fetches remote release tag or returns null on network issues', async () => {
    const tag = await fetchLatestMoliReleaseTag()
    if (tag !== null) {
      expect(tag).toMatch(/^\d+\.\d+\.\d+/)
    } else {
      expect(tag).toBeNull()
    }
  }, 30_000)

  it('syncLatestMoliBinary fast-path skips check when version stamp matches', async () => {
    const t0 = performance.now()
    await syncLatestMoliBinary()
    const elapsed = performance.now() - t0
    // Fast path should complete in under 50ms without network roundtrip
    expect(elapsed).toBeLessThan(100)
  })

  it('resolveCdpBackend returns usable chromium driver', () => {
    const chromium = resolveCdpBackend()
    expect(chromium).toBeDefined()
    expect(typeof chromium.connectOverCDP).toBe('function')
  })

  it('withFsLockRetry retries transient EBUSY/EPERM locks until success', async () => {
    let calls = 0
    const result = await withFsLockRetry(() => {
      calls++
      if (calls < 3) {
        const err = new Error('resource busy or locked') as NodeJS.ErrnoException
        err.code = 'EBUSY'
        throw err
      }
      return 'ok'
    }, 'test op', 5000)
    expect(result).toBe('ok')
    expect(calls).toBe(3)
  })

  it('withFsLockRetry rethrows non-transient errors immediately', async () => {
    let calls = 0
    await expect(withFsLockRetry(() => {
      calls++
      const err = new Error('no such file') as NodeJS.ErrnoException
      err.code = 'ENOENT'
      throw err
    }, 'test op', 5000)).rejects.toThrow('no such file')
    // no retries: single call, error propagates untouched
    expect(calls).toBe(1)
  })

  it('withFsLockRetry gives up after the retry budget with a contextual error', async () => {
    const t0 = Date.now()
    await expect(withFsLockRetry(() => {
      const err = new Error('resource busy or locked') as NodeJS.ErrnoException
      err.code = 'EPERM'
      throw err
    }, 'persistently locked op', 700)).rejects.toThrow('persistently locked op')
    // waited at least the budget before giving up
    expect(Date.now() - t0).toBeGreaterThanOrEqual(600)
  })

  it('withFsLockRetry never blocks the event loop while retrying', { timeout: 5_000 }, async () => {
    let calls = 0
    let eventLoopServed = false
    const ticker = setInterval(() => { eventLoopServed = true }, 10)
    try {
      const result = await withFsLockRetry(() => {
        calls++
        if (calls < 3) {
          const err = new Error('resource busy or locked') as NodeJS.ErrnoException
          err.code = 'EBUSY'
          throw err
        }
        return 'ok'
      }, 'test op', 5_000)
      expect(result).toBe('ok')
      expect(calls).toBe(3)
      // Real-timer sleeps between attempts let timers fire: a synchronous
      // variant (Atomics.wait) would have starved them completely.
      expect(eventLoopServed).toBe(true)
    } finally {
      clearInterval(ticker)
    }
  })

  it('getLocalMoliVersion returns null for a non-existent binary without blocking', async () => {
    expect(await getLocalMoliVersion('/non/existent/moli')).toBeNull()
  })
})


describe('release digest verification (supply-chain integrity)', () => {
  const ASSET = 'moli-x86_64-unknown-linux-gnu.tar.gz'

  /** Write a temp archive whose sha256 the caller can predict. */
  async function archiveWith(content: string): Promise<{ path: string; sha256: string; dir: string }> {
    const dir = mkdtempSync(join(tmpdir(), 'moli-digest-'))
    const path = join(dir, 'asset.tar.gz')
    writeFileSync(path, content)
    const sha256 = createHash('sha256').update(content).digest('hex')
    return { path, sha256, dir }
  }

  it('accepts an archive whose digest matches the release metadata', async () => {
    const { path, sha256, dir } = await archiveWith('trusted payload')
    const info = vi.spyOn(console, 'info').mockImplementation(() => {})
    try {
      await expect(
        verifyArchiveDigest(path, ASSET, [{ name: ASSET, digest: `sha256:${sha256}` }]),
      ).resolves.toBeUndefined()
      expect(info.mock.calls.flat().join(' ')).toContain('verified')
    } finally {
      info.mockRestore()
      rmSync(dir, { recursive: true, force: true })
    }
  })

  it('rejects an archive whose digest does not match, before any extraction', async () => {
    const { path, dir } = await archiveWith('tampered payload')
    try {
      await expect(
        verifyArchiveDigest(path, ASSET, [{ name: ASSET, digest: `sha256:${'0'.repeat(64)}` }]),
      ).rejects.toThrow(/refusing to install a tampered or truncated archive/)
    } finally {
      rmSync(dir, { recursive: true, force: true })
    }
  })

  it('warns loudly instead of silently proceeding when no digest is published', async () => {
    const { path, dir } = await archiveWith('unverified payload')
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    try {
      await expect(
        verifyArchiveDigest(path, ASSET, [{ name: ASSET, digest: undefined }]),
      ).resolves.toBeUndefined()
      const said = warn.mock.calls.flat().join(' ')
      expect(said).toContain('integrity NOT verified')
      expect(said).toContain(ASSET)
    } finally {
      warn.mockRestore()
      rmSync(dir, { recursive: true, force: true })
    }
  })

  it('warns when the release metadata itself is unreachable', async () => {
    const { path, dir } = await archiveWith('offline payload')
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    try {
      await expect(verifyArchiveDigest(path, ASSET, undefined)).resolves.toBeUndefined()
      const said = warn.mock.calls.flat().join(' ')
      expect(said).toContain('integrity NOT verified')
      expect(said).toContain('unreachable')
    } finally {
      warn.mockRestore()
      rmSync(dir, { recursive: true, force: true })
    }
  })

  it('treats an unrecognized digest format as unverified rather than failed', async () => {
    const { path, dir } = await archiveWith('odd format payload')
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    try {
      await expect(
        verifyArchiveDigest(path, ASSET, [{ name: ASSET, digest: 'unsupported:abc' }]),
      ).resolves.toBeUndefined()
      expect(warn.mock.calls.flat().join(' ')).toContain('unrecognized digest format')
    } finally {
      warn.mockRestore()
      rmSync(dir, { recursive: true, force: true })
    }
  })
})
