/**
 * Config schema defaults, CDP endpoint normalizer, and concurrency limits for Moli.
 */
import { describe, expect, it } from 'vitest'
import {
  Config,
  DEFAULT_CDP_ENDPOINT,
  DEFAULT_CHALLENGE_RETRIES,
  DEFAULT_CHALLENGE_WAIT_MS,
  DEFAULT_MAX_CONCURRENCY_CDP,
  DEFAULT_MAX_CONCURRENCY_LOCAL,
  DEFAULT_TIMEOUT_MS,
  MAX_CHALLENGE_RETRIES,
  MAX_CHALLENGE_WAIT_MS,
  MAX_CONCURRENCY_CEILING,
  MAX_TIMEOUT_MS,
  effectiveChallengeRetries,
  effectiveChallengeWaitMs,
  effectiveContextMode,
  effectiveMaxConcurrency,
  effectiveTimeoutMs,
  normalizeCdpEndpoint,
  readLive,
  resolveConfig,
} from '../src/config.ts'

describe('Config', () => {
  it('fills every field default it owns (maxConcurrency stays optional)', () => {
    const resolved = resolveConfig(Config({}))
    expect(resolved).toEqual({
      backend: 'local',
      moliPath: '',
      cdpEndpoint: '',
      shareBrowserContext: true,
      bypassCsp: true,
      autoScrollSentinel: true,
      denoise: true,
      timeoutMs: DEFAULT_TIMEOUT_MS,
      maxConcurrency: undefined,
      challengeWaitMs: DEFAULT_CHALLENGE_WAIT_MS,
      challengeRetries: DEFAULT_CHALLENGE_RETRIES,
    })
  })

  it('declares every field volatile, which is what makes the settings form exist', () => {
    // The settings domain derives a form from the volatile fields alone; a
    // field without the marker is not served, and a schema with none is
    // skipped entirely, so the configuration card would never appear.
    const dict = (Config as unknown as { dict: Record<string, { meta?: { volatile?: boolean } }> }).dict
    const fields = Object.keys(dict)
    expect(fields.length).toBeGreaterThan(0)
    for (const field of fields) expect([field, dict[field]?.meta?.volatile]).toEqual([field, true])
  })

  it('accepts a full CDP section unchanged', () => {
    const resolved = resolveConfig(Config({
      backend: 'cdp',
      cdpEndpoint: 'browser.lan:9223',
      shareBrowserContext: false,
      bypassCsp: false,
      autoScrollSentinel: false,
      denoise: false,
      timeoutMs: 45_000,
      maxConcurrency: 50,
      challengeWaitMs: 30_000,
      challengeRetries: 2,
    }))
    expect(resolved).toEqual({
      backend: 'cdp',
      moliPath: '',
      cdpEndpoint: 'browser.lan:9223',
      shareBrowserContext: false,
      bypassCsp: false,
      autoScrollSentinel: false,
      denoise: false,
      timeoutMs: 45_000,
      maxConcurrency: 50,
      challengeWaitMs: 30_000,
      challengeRetries: 2,
    })
  })

  it('accepts maxConcurrency across its whole integer range and rejects outside it', () => {
    expect(readLive(Config({ maxConcurrency: 1 }).maxConcurrency, undefined)).toBe(1)
    expect(readLive(Config({ maxConcurrency: MAX_CONCURRENCY_CEILING }).maxConcurrency, undefined)).toBe(MAX_CONCURRENCY_CEILING)
    expect(() => Config({ maxConcurrency: 0 })).toThrow()
    expect(() => Config({ maxConcurrency: MAX_CONCURRENCY_CEILING + 1 })).toThrow()
    expect(() => Config({ maxConcurrency: 2.5 })).toThrow()
  })

  it('accepts the challenge knobs across their ranges, rejects outside them', () => {
    expect(readLive(Config({ challengeWaitMs: 0 }).challengeWaitMs, NaN)).toBe(0)
    expect(readLive(Config({ challengeWaitMs: MAX_CHALLENGE_WAIT_MS }).challengeWaitMs, NaN)).toBe(MAX_CHALLENGE_WAIT_MS)
    expect(() => Config({ challengeWaitMs: -1 })).toThrow()
    expect(() => Config({ challengeWaitMs: MAX_CHALLENGE_WAIT_MS + 1 })).toThrow()
    expect(readLive(Config({ challengeRetries: 0 }).challengeRetries, NaN)).toBe(0)
    expect(readLive(Config({ challengeRetries: MAX_CHALLENGE_RETRIES }).challengeRetries, NaN)).toBe(MAX_CHALLENGE_RETRIES)
    expect(() => Config({ challengeRetries: -1 })).toThrow()
    expect(() => Config({ challengeRetries: MAX_CHALLENGE_RETRIES + 1 })).toThrow()
  })

  it('accepts timeoutMs across valid range and rejects outside it', () => {
    expect(readLive(Config({ timeoutMs: 1000 }).timeoutMs, NaN)).toBe(1000)
    expect(readLive(Config({ timeoutMs: 60_000 }).timeoutMs, NaN)).toBe(60_000)
    expect(readLive(Config({ timeoutMs: MAX_TIMEOUT_MS }).timeoutMs, NaN)).toBe(MAX_TIMEOUT_MS)
    expect(() => Config({ timeoutMs: 0 })).toThrow()
    expect(() => Config({ timeoutMs: -1000 })).toThrow()
    expect(() => Config({ timeoutMs: MAX_TIMEOUT_MS + 1000 })).toThrow()
  })
})

describe('readLive', () => {
  it('reads a volatile reference, passes a plain value through, and falls back when absent', () => {
    expect(readLive(Config({ timeoutMs: 45_000 }).timeoutMs, 0)).toBe(45_000)
    expect(readLive(45_000, 0)).toBe(45_000)
    expect(readLive(false, true)).toBe(false)
    expect(readLive(undefined, 0)).toBe(0)
  })

  it('falls back when a reference carries undefined', () => {
    // A reference over an optional field (such as `maxConcurrency`) yields
    // undefined until the profile sets it.
    const reference = { get: (): number | undefined => undefined }
    expect(readLive<number | undefined>(reference, 7)).toBe(7)
  })
})

describe('effectiveTimeoutMs', () => {
  it('returns configured timeoutMs when provided, falls back to DEFAULT_TIMEOUT_MS', () => {
    expect(effectiveTimeoutMs({ timeoutMs: 30_000 })).toBe(30_000)
    expect(effectiveTimeoutMs({ timeoutMs: 120_000 })).toBe(120_000)
    expect(effectiveTimeoutMs({})).toBe(DEFAULT_TIMEOUT_MS)
  })
})

describe('effective challenge knobs', () => {
  it('an explicit wait wins; a missing one falls back to the schema default', () => {
    expect(effectiveChallengeWaitMs({ challengeWaitMs: 0 })).toBe(0)
    expect(effectiveChallengeWaitMs({ challengeWaitMs: 7_500 })).toBe(7_500)
    expect(effectiveChallengeWaitMs({})).toBe(DEFAULT_CHALLENGE_WAIT_MS)
  })

  it('an explicit retry count wins; a missing one falls back to the schema default', () => {
    expect(effectiveChallengeRetries({ challengeRetries: 0 })).toBe(0)
    expect(effectiveChallengeRetries({ challengeRetries: 3 })).toBe(3)
    expect(effectiveChallengeRetries({})).toBe(DEFAULT_CHALLENGE_RETRIES)
  })
})

describe('effectiveMaxConcurrency', () => {
  it('defaults per backend: local Moli and remote CDP', () => {
    expect(effectiveMaxConcurrency({ backend: 'local' })).toBe(DEFAULT_MAX_CONCURRENCY_LOCAL)
    expect(effectiveMaxConcurrency({ backend: 'cdp' })).toBe(DEFAULT_MAX_CONCURRENCY_CDP)
    expect(DEFAULT_MAX_CONCURRENCY_CDP).toBeGreaterThan(DEFAULT_MAX_CONCURRENCY_LOCAL)
  })

  it('an explicit setting wins over all backend defaults', () => {
    expect(effectiveMaxConcurrency({ backend: 'local', maxConcurrency: 50 })).toBe(50)
    expect(effectiveMaxConcurrency({ backend: 'cdp', maxConcurrency: 2 })).toBe(2)
  })
})

describe('effectiveContextMode', () => {
  it('shares the profile by default for cdp; isolates for local', () => {
    expect(effectiveContextMode({ backend: 'cdp' })).toBe('profile')
    expect(effectiveContextMode({ backend: 'cdp', shareBrowserContext: true })).toBe('profile')
    expect(effectiveContextMode({ backend: 'cdp', shareBrowserContext: false })).toBe('isolated')
    expect(effectiveContextMode({ backend: 'local' })).toBe('isolated')
    expect(effectiveContextMode({ backend: 'local', shareBrowserContext: false })).toBe('isolated')
  })
})

describe('normalizeCdpEndpoint', () => {
  it('defaults a blank endpoint to the loopback address', () => {
    expect(normalizeCdpEndpoint('')).toBe(`http://${DEFAULT_CDP_ENDPOINT}`)
    expect(normalizeCdpEndpoint('   ')).toBe(`http://${DEFAULT_CDP_ENDPOINT}`)
  })

  it('prefixes bare host:port with the http scheme', () => {
    expect(normalizeCdpEndpoint('127.0.0.1:9222')).toBe('http://127.0.0.1:9222')
    expect(normalizeCdpEndpoint('browser.internal:9222')).toBe('http://browser.internal:9222')
  })

  it('passes http(s)/ws(s) endpoints through', () => {
    expect(normalizeCdpEndpoint('http://127.0.0.1:9222')).toBe('http://127.0.0.1:9222')
    expect(normalizeCdpEndpoint('https://browser.corp:9222')).toBe('https://browser.corp:9222')
    expect(normalizeCdpEndpoint('ws://127.0.0.1:9222/devtools/browser/abc')).toBe('ws://127.0.0.1:9222/devtools/browser/abc')
  })

  it('rejects unparseable values', () => {
    expect(() => normalizeCdpEndpoint('http://')).toThrow()
    expect(() => normalizeCdpEndpoint('://missing-host')).toThrow()
  })
})
