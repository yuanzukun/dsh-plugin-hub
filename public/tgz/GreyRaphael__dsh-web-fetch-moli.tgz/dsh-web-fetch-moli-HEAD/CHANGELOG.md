# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.7.0] - 2026-10-26

### Fixed

- **设置卡片在 DSH 0.1.7+ 完全消失（DSH 0.2.1-rc.3 上表现为“配置项不见了”）**: DSH 在 `0.1.7-alpha.1`（2026-09-22，`601d6761e4` / PR #4587 `feat(settings): project volatile Config through profile-backed forms`）把 `SettingsProvider` 整体换成了 `SettingsForms`，`ctx.settings.installSection` / `register` / `settingsNamespace` 这整套 API 被删除。旧代码调用的结果是一个被 cordis 捕获、只写进启动日志的错误：`TypeError: settingsCtx.settings.installSection is not a function`——插件主体（`moli` fetch provider）照常注册并工作，所以只有设置卡静默消失。本次迁移到新契约：
  - `src/config.ts`：`Config` 每个字段加 `.volatile()`。这是新契约的**必要条件**——`SettingsForms.describe()` 用 `volatileForm(schema)` 过滤条目，没有任何 volatile 字段的 schema 会被整条跳过、不产生表单。`maxConcurrency` 保持无 schema 默认值（缺省即走后端默认 20/50），因此其类型为 `Volatile<number | undefined>`。
  - `src/index.ts`：删除 `ctx.inject(['settings'], …installSection…)` 整段。改为 `resolveConfig(config)` 每次操作现读 volatile 引用，`apply(ctx, config = {})` 同时兼容 Loader 传入的引用与直挂（测试/内嵌）传入的普通值。
  - `src/config.ts` 新增 `readLive` / `resolveConfig` / `ResolvedConfig`（显式接口，不再从 `Required<Config>` 推导，因为后者现在会带 `Volatile` 包装）。
  - `src/client/index.ts`：`@deepseek-ai/dsh-client-runtime/client` 在 0.2 世代已不存在，`ctx.slots` 现由 `@deepseek-ai/dsh-client-ui-renderer/client` 声明，改为类型导入后者。浏览器半仍注册 `plugins.bundle.config`（key 为 `dsh-web-fetch-moli`）并通过 `ctx.configForms.whileServed(['web-fetch-moli'], …)` 绑定生命周期。
  - 依赖世代对齐：devDependencies 升到 `0.2.1-rc.3`（cordis `4.0.5`、schemastery `3.18.5`），schemastery 运行时下限提到 `>=3.18.3`（`.volatile()` 自 3.18.3 才存在），peer 下限提到 `0.1.7-alpha.1`，并新增 `dsh.engines.dsh: ">=0.1.7-alpha.1"` 让版本不满足时安装/激活阶段就明确报错，而不是运行时静默失效。
  - 顺带删除 `pnpm-workspace.yaml` 里锁在 0.1.2 世代的 `overrides`（`dsh-session`/`dsh-invariants`/`dsh-scope`/`dsh-llm`/`dsh-timeout`/`dsh-typert-protocol`），它们让依赖树里同时存在两份 schemastery，并触发 `TS2742`。

- **`provider.ts` 的 `withDefaults` 与 `resolveConfig` 重复维护同一张默认值表**: 改为 `resolveConfig(config)` 转发，只补 `timeoutMs` 这一个 `ResolvedConfig` 允许缺省的字段。同时清掉因此不再使用的三个 `DEFAULT_*` 导入。两张表并存时，改一处忘另一处会让 provider 与 settings 表单对同一个字段给出不同的默认值。

### Added

- 测试：`tests/config.spec.ts` 增加“每个字段都声明了 volatile”（直接断言新契约的前提，防止再次静默失效）与 `readLive` 的三条取值路径；`tests/cordis-integration.spec.ts` 增加“表单可被投放”“volatile 编辑在下一次操作生效且不重挂插件”“直挂缺字段时回落到文档默认值”。共 171 个测试（含 `tests/moli-resolve.spec.ts` 的网络用例）。

- `tests/client-fields.spec.ts`（Node 安全）：覆盖三个 spec 工厂的格式化与拒绝分支，并断言四个数字字段的边界与 Host schema 上限一致（300000 / 200 / 60000 / 3）。
- 原 `tests/client-form.spec.ts` 删除：它测的是 `CardForm` 这份平台模型的副本。真正需要本插件守护的是自己的 spec 逻辑，而 `SettingsFormModel` 的暂存/保存/回滚语义由平台自己的 `settings-form-model.client.spec.ts` 覆盖。

### Changed

- **依赖清单精简（声明项 29 → 23，净删 6 项）**:
  - 删除 `@deepseek-ai/dsh-settings` 的 dev 声明——迁移后运行时与类型层都不再引用它。
  - 删除 `@types/mozilla__readability`：`@mozilla/readability` 自 0.6.0 起自带 `index.d.ts`，这份 `@types` 是它的过时影子包，删掉后 `tsc --noEmit` 仍然通过。
  - 删除 `react-dom` 与 `@types/react-dom`：本插件从不 import `react-dom`（`lib/client.js` 唯一的外部依赖是 `react/jsx-runtime`，由宿主模块表提供）；同时从 `tsconfig.json` 的 `types` 里移除 `react-dom`。
  - 删除 `@deepseek-ai/dsh-brand`、`@deepseek-ai/dsh-client-ui-settings-plugins` 两个既无 import、也不在 `dsh.client.inject` 里的 devDependencies。
  - 保留 `@deepseek-ai/dsh-client-store`：它不是直接 import，但 `dsh-client-ui-slots` 的 `.d.ts` 引用它，缺了会让 `InjectFace` 的推断退化成 `any`（`src/client/card.tsx` 随即报 TS7006）——已实测复现。
  - `linkedom` 由 `^0.18.13` 升到 `^0.18.14`（同一 minor 的 patch）。

- **`react` 与 `@types/react` 有意停留在 18.x（宿主提供的是 18.3.1）**: 宿主 `apps/web` 依赖 `^18.2.0`，浏览器模块表 `PLATFORM_MODULES` 分发的也是 18.3.1，vite 侧还配了 `dedupe: ['react','react-dom']`。升到 19 会与宿主并存两份 React，拆散 hook 与 element identity。

- **工具链升级到当前 harness 世代**: `typescript` `^5.8` → `^6.0.3`（与 harness 自身一致）、`tsdown` `^0.22` → `^0.23.2`、`vitest` `^4.1` → `^5.0.5`、`lightningcss` `^1.32` → `^1.33`。为适配 TypeScript 6 的两个破坏性变更：
  - `tsconfig.json` 去掉 `baseUrl`（TS 6 已弃用，`paths` 改为相对配置文件解析）。
  - `tsconfig.build.json` 显式声明 `rootDir: "src"`（TS 6 不再从 `include` 推断公共源目录）。

- **`@mdream/js` 与 `mdream` 有意停留在 1.x（不跟随 latest 2.0.3）**: 2.x 把 `data:` URI 的图片源整个丢弃，插件为此专门实现的“base64 载荷替换为 `data:image/png;base64,...3.0KB` 占位符”因此失效，图片在 markdown 里退化成 `![alt]()`，丢失 MIME 与尺寸线索；同时 2.x 不再把 `<title>` 输出到正文（1.x 会）。实测对照（独立 pack 出 1.7.2 与 2.0.3 各跑一遍，避免依赖 node_modules 里已被升级的那一份）：

  ```
  1.7.2 → ![shot](data:image/png;base64,...3.0KB)
  2.0.3 → ![shot]()
  ```

  升级 2.x 需要重写 `elideDataUriImages` 的占位策略，并复核 `tests/markdown.spec.ts` 的两条 data-URI 断言，属独立任务。

- **`@types/node` 停留在 24.x**: 与 Node 运行时主版本对齐，跨大版本会引入无关类型噪声。

- **客户端改用平台共享的 settings-form 套件，删除 935 行手工转写层**: `form.ts`(396) / `fields.tsx`(195) / `PluginCard.tsx`(71) 及两个 CSS(317) 全部删除，改为使用浏览器壳层已种入冻结模块表的 `@deepseek-ai/dsh-client-ui-primitives` 与 `dsh-client-store`。这些文件头部原本写明“external client bundles cannot value-import `@deepseek-ai/*` packages”——该限制来自插件自己的 purity gate，而 rc.3 的模块表已经开放这两个 specifier，于是限制的前提不再成立。
  - `form.ts` 的 `CardForm` → 平台 `SettingsFormModel`；`ValueField` → `SettingsValueField`；`CheckboxField` → `Checkbox`；`PluginCard` → `SettingsForm`。
  - 插件自己只剩两处平台未覆盖的形状：backend 单选组（它的两个选项要联动禁用其它字段）、以及复选框旁的“已覆盖 + 恢复默认”徽章。二者落在 `card.module.css`（111 行，原为 317 行）。
  - `controller.ts` 从 103 行降至 116 行且不再包含任何模型逻辑，只声明字段与投影；新 `fields.ts`(73 行) 承载三个 spec 工厂（boolean / 有界整数 / 选项集），并且只用 `import type`，因此在 Node 下可直接测试。
  - 数字字段的客户端范围校验**保留**（`settingsBoundedNumberField` 带 min/max）。平台自带的 `settingsNumberField` 不接收边界，直接换用会让越界值直到 Host 才被拒——这是本次唯一刻意偏离平台默认的地方。

- **`package.json` 声明 `dsh.client.external`**: 新增 `@deepseek-ai/dsh-client-store` 与 `@deepseek-ai/dsh-client-ui-primitives` 两个模块表请求，与 `tsdown.config.ts` 的 `PLATFORM_EXTERNALS` 一一对应。两者必须同名，否则 bundle 会 require 一个模块表答不出的 specifier。产物从 36.4KB 降至 21.9KB（−39%），且 `lib/client.js` 只剩三个 require，全部命中模块表。

## [0.6.1] - 2026-09-30

### Changed

- **无限滚动与动态 SPA 水合性能全面重构与通用优化**:
  - 提取并统一 `CARD_ITEMS_SELECTOR`，将 `scrollIntoView` 默认对齐方式规范为 `{ block: 'end' }`，解决底层基于 `IntersectionObserver` 监听哨兵视口相交的现代无限滚动列表空滚与漏触发问题。
  - 批次动态哨兵等待（`waitForSentinelBatch`）：引入卡片元素数量与 HTML 总长度双重增量检测与动态防抖机制，大幅缩减单轮等待延迟。
  - 动态水合门禁（`settleDynamicSpa`）：对主流 SPA（`#root` / `#app`）增加真实内容充实度判断（`rootTextLen > 300` 且包含实质节点），彻底消除微前端骨架屏提前收敛与误判；为静态长文档补充免滚动快速通道（`skipScroll`）。
  - 实测性能显著提升：复杂微前端无限滚动（如阿里云百炼 189 个模型卡片）抓取耗时从 ~35s-40s 稳定压缩至 ~20s，静态文档与普通 SPA 保持 0.3s-3s 秒级收敛。

- **Moli 守护进程生命周期与并发安全加固**:
  - 增加启动所有权校验（`this.child !== child`）与孤儿进程防护：当启动过程被并发的 `stop()` 或后续 `ensure()` 抢占替代时，主动通过 `killTree(child)` 销毁失管的旧子进程并抛出自愈重试异常，彻底消除后台僵尸进程泄漏。
  - 完善多进程并发竞态与超时处理的单元测试覆盖。

- **长列表与新闻门户正文智能识别改进**:
  - 改进 Readability 对大列表页面中局部侧边 Prose "About" Widget 的误判截断：当页面总长大于 3000 且候选文章占比偏低时，自动保留全量 Feed 内容（如腾讯网要闻等综合门户）。

## [0.6.0] - 2026-09-26

### Added

- **Moli 二进制同步更新机制升级**:
  - 引入 24 小时检查周期 TTL（`DEFAULT_MOLI_CHECK_INTERVAL_MS`），解耦 Moli 发版与插件自身的 npm 发版周期；距离上次检查超过 24h 时在启动后台自动异步探测 GitHub Releases。
  - 增加 SemVer 语义化版本严格比对（`parseSemVer` / `isNewerVersion`），支持 Pre-release 判定，仅当远端版本严格高于本地版本时触发更新，防止覆盖本地开发调试版本。
  - 补充并发检测去重（`inFlightSyncs`），避免启动预热与用户请求并发触发多次远端探测。
  - 优化离线与网络抖动容错：远端检查失败时不施加 24 小时冷却锁，保持无网环境下平滑降级到已有本地二进制。

### Changed

- **适配最新 DeepSeek Harness 客户端架构（`configForms` 迁移与槽位规范化）**:
  - 彻底移除已废弃的 `settingsScope` / `@deepseek-ai/dsh-client-runtime` 依赖，切换为注入 `['slots', 'locale', 'configForms']`。
  - 将设置卡片单点收敛注册至 bundle 规范槽位 `plugins.bundle.config`（Key 为 `dsh-web-fetch-moli`），支持 `view === 'summary'` 与 `view === 'page'` 双视图，并使用 `ctx.configForms.whileServed([WEB_FETCH_MOLI_NS], ...)` 绑定生命周期。
  - 移除多余的手风琴折叠外壳、重复标题和无用图标样式，使 `PluginCard.tsx` 纯粹化为表单容器组件。
  - 为 `CardForm` 与 `MoliCardController` 增加 `dispose()` 回收机制，在插件卸载或重载时彻底释放监听。

## [0.5.1] - 2026-09-23

### Fixed

- **`engines.node` 更正为 `>=22`（与运行时不符的声明）**:
  - `src/cdp-client.ts` 通过全局 `new WebSocket(...)` 驱动 CDP，该 API 自 Node 22 起默认启用（Node 20 无此全局）。原 `engines: node >=20` 声明会让 Node 20 用户安装后在连接 CDP 时运行时崩溃。
  - `README.md` 与 `README.zh-CN.md` 的 Requirements 同步更正为 Node.js ≥ 22 并注明原因。

- **`challengeRetries` 暴露到设置卡片（文档与 UI 失配）**:
  - README 配置表格与 provider 均已实现该字段，但设置卡片（`src/client/controller.ts` 字段列表、`MoliSettings`/`MoliCardState`、`locales.ts` 中英文词典、`card.tsx` 渲染）全部缺失——用户无法通过 UI 配置。现已按 schema 范围（0–3）以 `numberField` 补齐全部四处并新增中英文 hint/占位符文案。
  - `tests/client-form.spec.ts` 新增 `challengeRetries` 字段规格与专项测试（0..3 范围往返、超上限拒绝）。

- **`package.json` disclosure.permissions 去重**:
  - `network:fetch` 权限出现两次（local 与 CDP profile mode 各一条），合并为一条覆盖两种后端的表述。

- **消除类型逃逸（`as any`）**:
  - `src/index.ts` 的 `tools/execute` 钩子：`(toolsCtx as any).on('tools/execute', (exec: any, ...))` 改为经由 `import type {} from '@deepseek-ai/dsh-tools'`（devDependency，`@deepseek-ai/dsh-tools@0.1.2-alpha.5`，与现有 dsh 系列依赖同代）引入的 cordis 模块增强直接以声明签名调用 `toolsCtx.on('tools/execute', ...)` 与 `toolsCtx.tools.get(...)`。类型导入零运行时足迹——`lib/index.js` 构建产物无任何 `dsh-tools` 引用。
  - `src/client/card.tsx`：`t(\`${field}Hint\` as any)` / `t(\`${field}Placeholder\` as any)` 收敛为类型安全的模板字面量键——字段名联合与词典键一一对应（`bindValue` 字段集补充 `challengeRetries`，并为 `cdpEndpoint` 补齐缺失的空 `cdpEndpointPlaceholder` 键使联合完备）。

## [0.5.0] - 2026-09-21

### Fixed

- **修复 `Semaphore.release()` 排队交接路径的槽位泄漏（严重并发缺陷）**:
  - 旧实现：`release()` 在队列非空时只调用队首 waiter 的 `start()`（内部 `active++`），而跳过当前持有者的 `active--`，每次"释放→交接"净增 1 个幽灵槽位。
  - 触发条件：并发 fetch 排队后逐个完成（模型 fan-out 多个 `web_fetch` 即触发），`active` 单调递增直至并发额度被幽灵槽位占满，后续请求全部 20s 排队超时（`WEB_FETCH_TIMEOUT`"rendering slots stayed busy"）。
  - 修复：`release()` 先 `active = Math.max(0, active - 1)` 归还持有者槽位，再从队首 promote 下一个 waiter；`drain()` 语义不变。
  - 新增回归测试 `completing queued handoffs never leak slots`：12 个会完成的 fetch 走 `maxConcurrency: 3` 的排队交接，验证全部 fulfilled 且后续新 fetch 立即启动（修复前该测试 20s 排队超时失败，修复后通过）。
  - 根因说明：既有并发测试全部用永久阻塞的 `openSession`（排队者只测 abort/超时失败路径），从未覆盖"释放→交接→完成"的成功路径；真实 Moli 集成测试的 burst 用例（6 并发、limit 10）从不排队，因此泄漏一直未被发现。

### Changed

- **文档与配置默认值三方对齐（`challengeWaitMs` / `challengeRetries` / `timeoutMs`）**:
  - `challengeWaitMs` 默认值更正为 `5000`（0.3.x 系列已由 commit c0c640e 从 15000 调低，但文档未同步）：`README.md`、`README.zh-CN.md` 配置表格与 `src/client/locales.ts` 中英文占位符（`(default: 15000)` → `(default: 5000)`）全部对齐 `src/config.ts` 的 `DEFAULT_CHALLENGE_WAIT_MS = 5_000`。
  - `challengeRetries` 默认值更正为 `0`（同上，文档原写 `1`）。
  - `timeoutMs` 默认值更正为 `90000`（`DEFAULT_TIMEOUT_MS`，文档原写 60000）：README 表格与 locale 占位符同步更正并注明"bundle 层出厂 60000，schema 默认 90000"；locale hint 不再误述"对齐 tool-web fetchTimeoutMs (默认 60000ms)"。
  - 配置表格补齐缺失的 `timeoutMs` 行（README 中英文双份）。
  - `maxConcurrency` 的 hint/占位符移除已废弃的 CLI 模式（"CLI 8"），仅保留 local 20 / CDP 50。
  - 清理源码注释中残留的 CLI 模式表述（`src/config.ts`、`src/provider.ts`、`src/types.ts`、`src/client/card.tsx` 的模块级/字段级注释）——CLI 模式已于 v0.4.0 移除。

## [0.4.1] - 2026-09-20

### Fixed

- **修复 Windows 上二进制安装偶发 `EBUSY` 失败（CI windows-latest 复现）**:
  - 新增 `withFsLockRetry` 同步重试助手：对 `EBUSY`/`EPERM`/`EACCES` 等 Windows 瞬态文件锁（Defender/索引服务对新解压 `.exe` 的短暂独占扫描）执行指数退避重试（150ms 起步、2s 封顶、默认 ~10s 总预算，通过 `Atomics.wait` 实现同步上下文休眠）。
  - `downloadLatestMoliBinary` 安装路径的 `copyFileSync`/`chmodSync`/`renameSync`/`rmSync`（含降级 copy-in-place 兜底与 finally 清理）全部纳入重试保护；非锁错误（如 `ENOENT`）保持立即抛出不被掩盖。
  - 新增 3 项单元测试覆盖：重试至成功、非瞬态错误直通、超预算后带上下文放弃。

### Changed

- **Moli 二进制上游切换至 `GreyRaphael/moli` fork（性能增强版）**:
  - `src/moli-resolve.ts` 新增 `MOLI_RELEASES_URL` / `MOLI_REPO_SLUG` 常量，将版本探测（curl HEAD 与原生 fetch 兜底）与二进制自动下载的 3 处硬编码 `lexmount/moli` URL 全部切换为 `GreyRaphael/moli`。
  - 新增 `MOLI_LATEST_DOWNLOAD_URL` 常量固化 GitHub "latest" 资产的正确下载路径格式（`/releases/latest/download/<asset>`），修复仅拼 `/releases/download/<asset>`（缺少 `latest` 段）导致 404 的隐患。
  - fork 完整保留上游 release asset 命名（`moli-<target>.tar.gz` / `.zip`），平台与架构探测逻辑零改动。
  - `src/index.ts` 新增导出 `downloadLatestMoliBinary`、`getMoliReleaseAsset`、`MOLI_RELEASES_URL`、`MOLI_REPO_SLUG`，方便外部工具复用解析与下载能力。
  - 同步更新 `README.md`、`README.zh-CN.md` 与 `.github/workflows/ci.yml` 中的全部上游链接与安装命令。
  - 新增 `scripts/switch-moli.mjs` 迁移脚本：走插件自身解析器校验新发布源并强制刷新本地 `~/.cache/moli/moli` 二进制（支持 `--force`）。

### Verified

- 本地缓存的 moli 二进制已升级至 fork 的 **v1.1.8**（原 1.1.7）。
- 测试套件 13 个文件 137 项测试全部通过（含真实 moli 守护进程集成测试）。
- 端到端验证：`moli serve` CDP 守护进程就绪、健康检查通过、页面渲染（example.com 返回 200）与去噪 Markdown 输出正常。

## [0.4.0] - 2026-09-17

### Changed

- **彻底移除 `cli`（单次命令行）模式，统一收敛为原生轻量 CDP 驱动**:
  - 移除了 `src/cli-runner.ts` 及所有相关的单次命令行进程启动与解析逻辑。
  - `MoliBackend` 运行模式严格收敛为 `'local' | 'cdp'`；`maxConcurrency` 的 CLI 默认并发配置也一并清理。
  - 重构前端 WebUI 配置面板：移除 `cli` 单选，并将仅在 `cdp` 模式下生效的 `shareBrowserContext` 配置下沉内嵌至 `cdp` 模式设置块中，消除“配置项在 local 下无效却暴露在全局”的体验混淆。
  - 精简相关测试套件，13 个测试文件共 134 项测试全部通过。

## [0.3.12] - 2026-09-16

### Fixed

- **修复弱网/慢速环境下微前端与复杂 SPA 瀑布流卡片提前中断与未去噪问题**:
  - **建议 1 修复（动态渲染与无限滚动）**:
    - 优化 `settleDynamicSpa`：延长骨架屏/加载动画等待上限至 `Math.min(25_000, ...)`，且当卡片或 Sentinel 已挂载到 DOM 时优先判定已就绪，避免因页面常驻的微弱 `.ant-spin` 类误判未就绪导致超时退出。
    - 修复 `runSentinelRounds` 误触底提早退出：移除 `(res.cardsCount > 0 && !res.hasSentinel)` 的过早中断逻辑，严格要求 `unchangedRounds >= 2` 才判定停止增长；同时保留此前已见 Sentinel 后的 `everHadSentinel && !res.hasSentinel` 触底快速收敛机制，防止首轮尚未挂载 Sentinel 时直接中断。
    - 优化单轮等待节奏至 1200ms，为弱网环境下的下一批数据请求保留充裕的网络往返与 DOM 挂载时间。
  - **建议 2 修复（配置容错与默认兜底）**:
    - 在 `src/index.ts` 的 `apply` 中对外部传入的 `config` 默认通过 `Config(config ?? {})` 注入 schema 完整默认值；在 `MoliFetchProvider` 内部增设 `withDefaults` 深度兜底。
    - 修复判断条件从 `!config.denoise` 改为严格的 `config.denoise === false`，彻底消除未配置时回退为未去噪原始 HTML 并在 100,000 字符处被截断的问题。
    - 将 `DEFAULT_TIMEOUT_MS` 提升至 90s，为多达 10 轮排版物化与网络加载的重型微前端页面（如阿里云百炼 179 张卡片）提供充裕的端到端执行预算。

### Fixed

- **自动穿透与对齐 Preset 预设作用域的 `web_fetch` 超时预算**:
  - 针对 DSH Web 模式下 Agent Preset（如 `standard` 预设）漏设 `fetchTimeoutMs` 导致 `web_fetch` 被局部作用域 30s 默认值遮蔽（shadowing）的问题，通过 Cordis `ctx.inject(['tools'])` 安全挂载 `tools/execute` 前置流水线钩子（`prepend: true`）。
  - 在每次分发 `web_fetch` 前，动态把当前会话/预设作用域中的 `tool.timeoutMs` 提升并对齐至 Moli 的实际配置预算（默认 60s），确保上层 `@deepseek-ai/dsh-tool-call-timeout-policy` 守卫自动采用 60s 倒计时，彻底告别 `Error: tool call timed out after 30000ms`。
  - 遵循 Cordis 严格的服务依赖隔离规范，零破坏性，无需用户修改 DSH 源码或自定义 Preset。

## [0.3.10] - 2026-09-16

### Fixed

- **修复 Cordis 插件激活时非法访问未注入服务导致崩溃的问题**:
  - 彻底移除 `src/index.ts` 中对未在 `inject` 声明的 `(ctx as any).tools` 的非法访问，解决 `Error: cannot get property "tools" without inject` 导致的插件激活失败（`1 entry did not activate`）。
  - 超时完全由插件自身的 `Config.timeoutMs`（默认 60s）与 `cordis.patch.yml` 声明控制，且与传入的外部 `signal` 自动协同，遵循 Cordis 严格的服务依赖隔离契约。

## [0.3.9] - 2026-09-16

### Added

- **深度对齐 DSH `fetchTimeoutMs` (60s) 超时预算**:
  - 在 `Config` 中新增 `timeoutMs` 配置字段，并将抓取全局兜底预算从写死的 25s 提升至 60,000ms（与 `cordis.patch.yml` 中 `tool-web` 的 60s 预算完全对齐）。
  - 运行时动态感知 `ctx.tools.get('web_fetch')?.timeoutMs`，实现与上层 DSH 工具守卫预算的双向智能自动同步。
  - 前端 UI 设置卡片与中英本地化字典全面增加 `timeoutMs` 配置支持。

### Changed

- **重构预导航与安全 CDP 指令管道**:
  - 严格仅保留 6 项有实际业务改变意义的非默认 CDP 配置（`Page/Runtime/Network.enable`、`Page.setBypassCSP`、`Security.setIgnoreCertificateErrors`、`Network.setBypassServiceWorker`）。
  - 省略 Moli 原生出厂自带的 1080P 桌面视口与 `navigator.webdriver=false`，规避旧版 Moli 报错 `UnknownMethod`。
  - `setBypassCSP` 动态透传前端配置的布尔值，杜绝连接池复用时的状态遗留。
- **Micro-Clip 物化与 W3C 标准滚动机制**:
  - 彻底废除 UserScript 猴子补丁，采用极简 1x1 Micro-Clip 截图促发 Moli 布局树物化，结合 W3C 原生 `scrollIntoView` 机制稳定加载 179+ 瀑布流卡片。
- **Moli 内核升级**:
  - 插件升级时自动检测并从 GitHub Releases 同步最新版 Moli 二进制。

## [0.3.2] - 2026-09-14

### Fixed

- **修复微前端及复杂 SPA 在 DOM 就绪前过早退出的数据截断问题**:
  - 移除脆弱且依赖类名猜测的 `waitForSpaHydration` 探测，避免在微前端加载脚本阶段因 DOM 尚未生成 spinner 而误判退出。
  - 恢复健全的 Sentinel 观测生命周期，增加 800ms 初始加载宽限期与 400ms 重试，为慢速 SPA 提供充足的微前端容器加载时间。
  - 优化 Sentinel 触发轮次为 2 轮（每轮 500ms 间隔）及 500ms 沉淀时间，相比旧版减少 16s 无效等待，将阿里云百炼（179 个模型卡片，2.1 万字 Markdown）抓取时间稳定在 14s 内完成，彻底杜绝 30s 工具调用超时。
  - 为 `runSentinelRounds` 增加 `page.evaluate` 安全守卫，增强 mock 单元测试与无 evaluate 环境下的健壮性。

## [0.3.1] - 2026-09-14

### Fixed

- **修复单包构建产物与依赖打包问题**:
  - 将 `linkedom`、`@mozilla/readability`、`@mdream/js` 完全内联打包入 `lib/index.js` 单一 ESM 产物，避免动态加载分块缺失。
  - 优化微前端加载状态处理，解决 `session.v3` 日志中发现的工具调用超时问题。

## [0.3.0] - 2026-09-14

### Changed

- **升级为高性能双阶段 Markdown 管道（方案 C）**:
  - **阶段 1（降噪与正文提取）**: 采用轻量级虚拟 DOM 引擎 `linkedom` 结合 `@mozilla/readability`，以极低内存开销精准提取主体正文并剔除导航、页脚、侧边栏等冗余布局。
  - **阶段 2（HTML 转 Markdown）**: 采用 `mdream`（Rust 原生 NAPI 加速，自动回退纯 JS `@mdream/js`），专为大语言模型优化的 Markdown 生成算法，完美处理复杂嵌套表格、代码块及语义化排版。
  - 全面替换旧版简易正则转换引擎，彻底解决阿里云百炼等复杂页面 Markdown 生成时内容丢失与格式破碎问题。

## [0.2.1] - 2026-09-14

### Fixed

- **修复包发布缺少动态代码分块（cdp-client chunk）的问题**: 将 `src/moli-resolve.ts` 中对 `cdp-client.ts` 的引用改为静态导入，使 `lib/index.js` 单独打包为一个完整自包含的 ESM bundle；同时将 `package.json` 的 `files` 字段规范为包括完整的 `lib` 目录，避免插件打包或发布时遗漏生成的产物。

## [0.2.0] - 2026-09-14

### Changed

- **零重型外部依赖重构（Zero Heavy External Dependencies）**:
  - 移除 `playwright-core`，基于 Node.js 原生 `fetch` 与 `WebSocket` 实现纯 TypeScript 原生 CDP 客户端（`src/cdp-client.ts`），支持会话管理、目标附加、网络请求拦截路由与页面生命周期监听。
  - 移除 `jsdom`、`@mozilla/readability`、`dompurify`、`turndown` 及 `@joplin/turndown-plugin-gfm`，实现零依赖纯原生 HTML 清洗与 GFM Markdown 转换引擎（`src/markdown.ts`），大幅降低内存占用与 GC 压力，解析性能提升数十倍。
  - 生产依赖仅保留 `@deepseek-ai/schemastery`，安装体积减少数十 MB，消除潜在供应链依赖安全风险。

## [0.1.6] - 2026-09-14

### Fixed

- **Fix incomplete response on asynchronous micro-frontend and lazy-loaded SPA pages**: Extended IntersectionObserver sentinel discovery timeout (`maxSentinelWaitMs` from 3.5s to 10s) and per-round render settle time (from 1.2s to 1.5s) in `runSentinelRounds`. Added immediate early-break when sentinels mount. Enables full infinite-scroll catalog extraction on complex micro-frontend platforms (such as Alibaba Cloud Bailian Model Market, extracting all 179 model cards).
- **Update real-world micro-frontend benchmark timeout**: Raised vitest timeout in `tests/bailian-benchmark.spec.ts` from 60s to 90s to comfortably accommodate full catalog extraction across multiple network batches.

## [0.1.5] - 2026-09-14

### Fixed

- **Eliminate deprecated `whatwg-encoding` subdependency warning**: Upgraded `jsdom` from `^26.0.0` to `^29.1.1`. Modern jsdom uses `@exodus/bytes` and `html-encoding-sniffer@^6.0.0`, eliminating the npm deprecation warning for `whatwg-encoding@3.1.1` during plugin installation.
- **Mark `@deepseek-ai/dsh-settings` and `@deepseek-ai/dsh-web` optional in `peerDependenciesMeta`**: When installing the plugin into a DSH profile via `dsh plugin --profile <name> add`, pnpm no longer flags missing peer dependency warnings for host-injected services.
- **Modernize tsdown bundling options**: Updated `tsdown.config.ts` from deprecated `external` / `noExternal` to `deps: { neverBundle, alwaysBundle }`, eliminating compiler warnings during build.
- **Dependency updates**: Bumped `@joplin/turndown-plugin-gfm` to `^1.0.68`, `dompurify` to `^3.4.15`, and aligned devDependency `@deepseek-ai/cordis` to `4.0.2`.

## [0.1.4] - 2026-09-14

### Changed

- **Clean and standardized Moli provider registration**: Standardized provider identity strictly to `moli` (id: `moli`). Cleaned up legacy client radio group form names to `moli-backend`. Added Cordis integration test coverage verifying provider registration into `ctx.web`.

### Fixed

- **Boot no longer fails against dsh-settings 0.1.2+** (`dsh web` died with `plugin tree failed to load … The requested module '@deepseek-ai/dsh-settings' does not provide an export named 'installSettingsSection'`). The plugin was built against the 0.1.1-era API whose top-level helpers (`installSettingsSection`, `settingsNamespace`) no longer exist: dsh-settings 0.1.2 moved that behavior onto the settings service itself (`ctx.settings.installSection(owner, ns, schema, entry, hooks)`) and replaced the runtime `settingsNamespace()` factory with the plain `SettingsNamespace` string type. The host resolves a plugin's bare `@deepseek-ai/*` imports against its own module graph (the loader imports entry packages with the host context as resolution parent), so the plugin's local 0.1.1-rc.1 copy never shields it — the moment the host runs dsh-settings ≥0.1.2, ESM's strict named-export check kills the whole plugin tree at link time. `apply()` now follows the same idiom as the shipped providers (see `web-search-deepseek`): the namespace is a literal constant and the section installs through `ctx.inject(['settings'], (settingsCtx) => settingsCtx.settings.installSection(...))`, so `lib/index.js` no longer imports `@deepseek-ai/dsh-settings` at runtime at all. Dependencies were aligned to the host generation: devDependencies to `0.1.2-alpha.5` (plus `@deepseek-ai/dsh-client-store`, which the published ui-slots types import but do not declare — without it `InjectFace`'s `HostObservable` inference silently degrades to `any` and `card.tsx` fails typecheck), `@deepseek-ai/schemastery` to `>=3.18.2`, and the dsh-settings/dsh-web peer ranges tightened to `>=0.1.2-alpha.0 <0.3.0` (older hosts lack `installSection` and can no longer load this plugin). Verified against the host's real module graph: namespace `web-fetch-moli` registers, the `moli` fetch provider lands in `ctx.web`, and a committed settings change reaches the provider's config thunk; the full suite (126 tests) stays green.

- **Normal pages of Cloudflare-Bot-Management sites no longer misclassify as challenges** (badcase: `https://openrouter.ai/openai/gpt-6-astra-pro`). Cloudflare injects its passive JavaScript-Detections (JSD) telemetry into EVERY normal page of a protected zone — either as a direct `<script src="/cdn-cgi/challenge-platform/scripts/jsd/main.js">` or as that URL strung inside a hidden-1x1-iframe bootstrap's inline script text. The URL embeds the `/cdn-cgi/challenge-platform/` prefix, so the content-level marker scan read every such plain-200 real-content page as an interstitial; the live DOM probe then correctly said "not challenged", but the chained-round recheck re-ran the same false positive and overrode it, burning the whole wait budget and all retries and failing with `WEB_FETCH_CHALLENGE` ("last status 200"). The classifier now strips the `scripts/jsd/` telemetry directory before the challenge-platform prefix check (`classifyChallengeHtml`) and the DOM probe excludes it from its script-src scan (`CHALLENGE_DOM_PROBE`); the bare `/cdn-cgi/scripts/jsd/main.js` marker left the list entirely — it is telemetry in every spelling. Real interstitials still classify: they load orchestrate scripts (`/cdn-cgi/challenge-platform/h/…`) plus `window._cf_chl_opt` / `#challenge-*` / the title family, none of which live under `scripts/jsd/` (regression-tested, including an interstitial that carries the JSD script alongside its own orchestrate scripts). Verified live: the openrouter.ai badcase and nowsecure.nl both return their real articles now, and the full suite (126 tests incl. real-browser challenge integration) stays green.

### Removed

- `dsh.plugin.json`, the standalone plugin manifest. Its content was fully redundant with what the host already reads from `package.json` (the `dsh.*` fields plus `cordis.patch.yml` via `dsh.bundle.patch`), and as a second version-carrying file it had already drifted once (0.2.4's lockstep note) — the package manifest is now the single version source. The stale `"dsh.plugin.json"` entry is gone from the `files` list too, so the published tarball no longer claims a file it does not carry.

## [0.2.6] - 2026-08-27

### Fixed

- **Windows `$PATH` discovery works** (issue #1): `findOnPath` split `process.env.PATH` on a literal `:`, but Windows joins PATH entries with `;` — the whole variable read as one bogus directory, so auto-discovering a `playwright` executable (blank `playwrightPath`) never found anything and silently fell through to the bundled `playwright-core`. It now splits on Node's `path.delimiter`, and a regression test scans a multi-directory PATH with the probe in a non-first entry (the case both Windows reproducers in the issue hit).
- **`pnpm build` is cross-platform** (issue #1): the build script cleaned `lib/` with `rm -rf`, which does not exist on Windows PowerShell — `'rm' is not recognized` killed the build before TypeScript declarations or tsdown ever ran, and since `prepare` runs the same script, installing from a git checkout failed on Windows too. The clean step is now `node -e "require('node:fs').rmSync('lib',{recursive:true,force:true})"`, which works everywhere Node does (a follow-up `scripts/clean.mjs` was considered and dropped to keep the pipeline in one place; tsdown's own `clean` cannot replace it — it runs after `tsc` and would delete the declarations just emitted).
- CI now runs the full check (install, typecheck, test, build) on `windows-latest` alongside `ubuntu-latest`, Node 22/24 — so the PATH-split and build-script regressions above cannot land again unnoticed. The tarball content verification stays Linux-only (`/tmp` + `tar`/`grep` piping); it checks npm packaging, not platform behavior.
- Known Windows limitation, documented rather than fixed here: npm/pnpm global installs expose `playwright` as `.cmd`/`.ps1` shims whose upward walk cannot find the package root, so PATH auto-discovery may still land on the bundled core. Setting `playwrightPath` to the package root or a browser executable selects the intended installation; PATHEXT-aware probing is tracked as a follow-up.

## [0.2.5] - 2026-08-25

### Added

- **Bounded Cloudflare-challenge wait** (issue #2): when a navigation lands on a challenge interstitial, the fetch now keeps the **same page and browser context** and waits for the browser's own verification to clear it, instead of returning the interstitial as content (the behavior before this release — with a strict site that meant "Just a moment…" as markdown within ~1s, the real article never captured even though the browser would have passed the check seconds later).
  - Detection is layered with a suspicion gate: the documented `cf-mitigated: challenge` response header (set on every challenge page type), then 403/503 HTML from a `server: cloudflare` edge, then content-level markers — the localized interstitial title family ("Just a moment...", "请稍候…", "Минутку…", …) plus structural markers (`/cdn-cgi/challenge-platform/` scripts, `#challenge-*` elements, `cf-chl-widget-` frames, `window._cf_chl_opt`, the `.footer .footer-inner .ray-id` footer). Markers are attribute/assignment-shaped so an article that merely quotes them stays clean, and the content tier only runs on challenge-compatible responses (`isChallengeCompatibleResponse`: 403/429/503, or `server: cloudflare` / `cf-ray` present) — interstitials never ship a plain 200, so a normal article cannot be misread as a challenge (and normal fetches skip the extra content read entirely). Hard-block pages ("Attention Required!", "you have been blocked" + a `cf-headline`/`cf-error-details` layout) classify separately and fail immediately.
  - During the wait the provider tracks the **last main-frame navigation response** (the real page reloads in after the clear) and probes the live DOM every 500ms, so SPA-style clears (content swapped with no navigation) are captured too; a probe that throws mid-navigation (context destroyed) counts as "still challenged". A clear that lands on a *chained* round (JS test → Turnstile interstitial) is caught by a settled-DOM recheck — content-level, deliberately, so SPA clears whose response stays 403 forever still pass — and consumes one of the retries.
  - Knobs: `challengeWaitMs` (0–60000, default 15000; **0 disables the whole path and restores the exact pre-0.2.5 behavior**) and `challengeRetries` (0–3, default 1 — a same-tab re-navigation whose context keeps any clearance cookies the browser earned). Everything stays inside the 45s per-fetch deadline with a finish reserve; on exhaustion the fetch fails with the new provider-specific `WEB_FETCH_CHALLENGE` code (the web seam's open-string `code` tolerates provider codes) naming the site, budget, and last challenge status.
  - Cookie lifecycle is unchanged by design: isolated fetches' clearance dies with their context (verified: a second isolated fetch is challenged again), profile-mode clearance stays in the remote browser's own profile (verified: a second profile fetch skips the challenge); nothing is exported, copied, or manufactured. No clicking, no CAPTCHA answers, no fingerprint spoofing.
  - Settings card gains a *Cloudflare challenge wait (ms)* number field; `scripts/challenge-demo.mjs` runs a local simulated strict edge through the baseline and the feature for a before/after printout.
- New exports: `classifyChallengeResponse`, `classifyChallengeHtml`, `isChallengeCompatibleResponse`, `CHALLENGE_DOM_PROBE`, `CHALLENGE_TITLE_RE`, `CHALLENGE_POLL_INTERVAL_MS`, `CHALLENGE_FINISH_RESERVE_MS`, `WEB_FETCH_CHALLENGE_CODE`, `DEFAULT_CHALLENGE_WAIT_MS`, `DEFAULT_CHALLENGE_RETRIES`, `effectiveChallengeWaitMs`, `effectiveChallengeRetries`, and the `ChallengeVerdict` type.

## [0.2.4] - 2026-08-25

### Fixed

- Denoise now elides inline `data:` image payloads (`data:image/png;base64,...`) to size placeholders like `![alt](data:image/png;base64,...8.9KB)`. Build tools (Docusaurus/webpack) inline images above a size cutoff straight into the HTML; they survived Readability, DOMPurify, and Turndown as raw base64 — on the onlyoffice.com docs events page that was **65% of the returned body** (100k chars, truncated at the cap). With the placeholder the same page returns 41.8k chars complete. The elision happens in the DOM before extraction, so both the article and whole-document fallback paths apply it; it runs under the denoise toggle only (raw-HTML mode is untouched) and keeps alt text, MIME type, and the approximate size.
- `dsh.plugin.json` version had drifted (still 0.2.2 after the 0.2.3 release); both manifests now move in lockstep at 0.2.4.

## [0.2.3] - 2026-08-24

### Fixed

- The bundle layer no longer pins `searchProvider: deepseek-official` on the `web` row. The pin out-ranked every later layer, so a user's own search-provider bundle could register and stay healthy yet never be selected — and `$DSH_WEB_SEARCH_PROVIDER` was dead config too (the row's config beat the env). The row's whole config is still replaced by the patch (no deep merge), so `searchProvider` is now simply **omitted**: with the base bundle's single registered search provider, auto-selection picks it exactly as before, while any later layer — a user search bundle, the profile/home `cordis.patch.yml`, or `$DSH_WEB_SEARCH_PROVIDER` — is free to pin search. Two usable search providers with no explicit selection still fail loud (`WEB_PROVIDER_AMBIGUOUS`) instead of guessing. Fetch stays pinned to `moli`; this bundle owns fetch, not search.

## [0.2.2] - 2026-08-24

### Added

- CDP context modes: a new `shareBrowserContext` setting (checkbox *Share the browser context (profile logins)* nested under the Remote CDP option in the plugin-configuration card, default **on**) selects how each CDP fetch is scoped. **Profile mode** (default): each fetch is a tab in the remote browser's default context — its real profile — so cookies/localStorage are shared and the browser's persistent logins apply; the tab closes when the fetch ends, the shared context never closes. **Isolated mode** (unchecked): the previous behavior — a fresh incognito-like context per fetch.
- `effectiveContextMode(config)` and the exported `CdpContextMode` / `CdpAcquireMode` types.
- Popup guard: popups a fetched page spawns (`window.open`) are closed so no tab outlives its fetch in the remote browser.

### Changed

- The fetch lease is now page-scoped: `CdpLease` carries `page` + `persistent`, `CdpConnectionPool.acquire` takes a mode, and `release` closes only what the lease owns (page always; context unless it is the remote default context). The connection-management core (ensure/connect/watch/drop/dispose) is unchanged — a `browser.close()` on a CDP handle only disconnects, so the remote browser always survives.
- Resource-subrequest filtering moved from context level to **page level**, so profile mode never intercepts tabs it does not own (an operator's manual tabs in the same context).
- Local-backend pages are closed explicitly on teardown (previously the page relied on its context's close to take it down).

### Fixed

- Local sessions now close in a defined order — page, context, browser — each grace-bounded, instead of leaving the page to the context-close side effect.
- Partial-failure leaks: an isolated lease whose `newPage()` fails on a live connection now closes the context it just created (it previously stayed open until the whole connection went away), and the local backend closes its launched browser when `newContext()`/`newPage()` fail after a successful launch (a whole Chromium previously stayed running).

### Security

- Profile mode is a semantic upgrade: fetched pages see the remote browser's logged-in identity, and requests they goad the agent into carry its session cookies. README (en/zh) documents the risk notes and the persistent-`user-data-dir` browser setup; the disclosure adds a credentialed-fetch permission entry.

## [0.2.1] - 2026-08-23

### Fixed

- CI no longer fails on every push: the matrix dropped Node 20 and runs on Node 22/24. `pnpm/action-setup` with a floating `version: 11` resolves to pnpm 11.22.0, which requires Node ≥ 22.13 (`node:sqlite`) and crashed the Node 20 job inside `setup-node` before any step ran, with fail-fast cancelling the healthy 22/24 jobs. Node 20 cannot be restored by pinning pnpm alone: the `tsdown` 0.22 build (run by `prepare` on install) also requires Node ≥ 22.18.
- `CONTRIBUTING.md` now states the toolchain needs Node ≥ 22 while the published plugin itself still runs on Node ≥ 20 (no Node 22+ APIs in the runtime code or build output).

## [0.2.0] - 2026-08-21

### Changed

- CDP backend architecture: instead of one `connectOverCDP` per fetch, the provider now keeps a **single shared connection** to the remote browser for its lifetime; each fetch leases an isolated context (a tab) and closes only that. Reconnects automatically when the connection drops or the configured endpoint changes; the connection is dropped on plugin unload. Concurrent fetches therefore cost tabs, not connections or browsers.
- Concurrency is backend-priced: `maxConcurrency` is now optional with backend-dependent defaults — **4** for local (each slot launches a whole Chromium) and **50** for CDP (each slot is a tab in the already-running browser), range widened to 1–200. The settings card explains the auto default; an explicit value still wins.

### Fixed

- `web fetch aborted while waiting for a free browser slot` no longer surfaces as the common failure under parallel `web_fetch` bursts: the CDP default alone covers 50 concurrent tabs, and a queued fetch that gets no slot within 20s fails fast with `WEB_FETCH_TIMEOUT` plus a retry/`maxConcurrency` hint instead of hanging until an abort mislabels it.
- Queue-wait errors translate through the standard taxonomy: the provider's own deadline expiring while queued reports `WEB_FETCH_TIMEOUT`, and a caller cancelling a queued fetch keeps the precise slot message under `WEB_ABORTED`.
- Cleanup hardening: context/browser closes in the fetch teardown are grace-bounded (2s), so a wedged Playwright close can no longer pin a concurrency slot forever (which previously made every later fetch die on the queue), and a queued fetch that fails to acquire never releases a phantom slot.

### Added

- `CdpConnectionPool` (exported): the shared-connection core — one connect under concurrent acquires, per-fetch context leases, liveness probes (`isConnected` + `disconnected`), single reconnect-and-retry, generation-guarded abandonment of connects made stale by an endpoint change or dispose.
- `effectiveMaxConcurrency(config)` and the `DEFAULT_MAX_CONCURRENCY_LOCAL` / `DEFAULT_MAX_CONCURRENCY_CDP` / `MAX_CONCURRENCY_CEILING` constants.
- Provider `dispose()` plus a `ctx.effect` teardown hook in the plugin entry that drops the shared CDP connection on unload.
- Tests: the CDP pool (8 cases), provider-level CDP behavior (one connection, tabs closed per fetch, 50-way tab burst, dead endpoint), queue cases, and a real-Chromium CDP integration smoke (debugging port, denoise fetch, 12-tab concurrent burst) that self-skips without a browser.

## [0.1.1] - 2026-08-21

### Fixed

- Peer ranges for `@deepseek-ai/dsh-settings` and `@deepseek-ai/dsh-web` now carry an explicit prerelease branch (`>=0.1.0-rc.6 <0.2.0 || >=0.1.1-rc.1 <1`): a bare `>=0.1.0-rc.6 <1` silently excludes `0.1.1-rc.1` builds under node-semver's prerelease rule, which would resolve an older host package copy for npm installs.

### Added

- Tests for the client card form model (staging, save writes, failed-save retention, discard, radio/checkbox fields) and GFM edge cases (strikethrough, checkbox lists, table separators).
- `CONTRIBUTING.md`, `SECURITY.md`, GitHub issue/PR templates, and README links to them.

## [0.1.0] - 2026-08-21

### Added

- First public release as a DSH bundle plugin.
- `PlaywrightFetchProvider` registered with `ctx.web` under id `playwright`; the bundle patch pins the web seam's `fetchProvider` to it and enables the `web_fetch` tool with a 60s budget.
- Local backend: path / `$PATH` / bundled `playwright-core` resolution with native-executable sniffing and package-root discovery.
- Remote backend: CDP connect (`connectOverCDP`) with fresh isolated context per fetch.
- Denoise pipeline: jsdom → Mozilla Readability → DOMPurify (layout tags dropped, `KEEP_CONTENT: false`) → Turndown + GFM with `tool-web`-consistent style and table rules.
- Per-fetch deadline (45s), concurrent-fetch semaphore (2), resource-subrequest filtering, 100k body cap, `WEB_*` error taxonomy parity with the shipped HTTP provider.
- Client settings card (*Playwright 网页爬取*) with backend radio, nested path/CDP inputs, denoise checkbox, and zh/en locales.
- Unit tests (config, markdown, playwright resolution, provider over a fake browser) plus a self-skipping real-browser integration smoke.
