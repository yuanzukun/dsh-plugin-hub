# 更新记录 / Changelog

## [Unreleased]

## [0.2.1] - 2026-10-02

### 修复 / Fixed

- 修复 DSH `0.2.0-rc.2` 不再暴露旧式 React fiber 后，会话“…”菜单缺少“移入回收站”和“彻底删除”的问题；优先使用稳定的 `data-row-key` 读取精确会话 ID，并保留旧版兼容路径。

- Restored the trash and permanent-delete session menu actions on DSH `0.2.0-rc.2` by reading the stable `data-row-key`, while retaining the legacy React-fiber fallback.

## [0.2.0] - 2026-10-01

### 兼容 / Compatibility

- 适配并完整隔离验证 DSH `0.2.0-rc.2`。
- 删除策略改用 DSH 0.2 的 volatile 插件 `Config`，配置页迁入原生「插件」管理界面；旧索引策略首次自动迁移并保留降级镜像。
- DSH 0.2 不再提供当前会话快照时，按 `aria-selected` 的精确会话行识别当前会话，删除前仍会安全切换。

Verified against DSH `0.2.0-rc.2`, migrated deletion policy to the native volatile plugin Config contract and Plugins page, and added an exact selected-row fallback when the current-session snapshot is absent.

### 验证 / Validation

- 隔离 Host 验证 live 会话移入回收站后的 Agent/Session 释放、同 ID 阻止、恢复、重启持久化阻止与永久删除。
- 浏览器验证原生插件配置页的暂存、放弃、保存及 profile patch 落盘。

Validated live teardown, blocking, restore, restart persistence, permanent deletion, and native settings save/discard behavior in an isolated DSH home.

## [0.1.3] - 2026-09-21

### 修复 / Fixes

- 会话移入回收站时完整释放 live Agent 与 Session，并在恢复或彻底删除前持续阻止同 ID 重新加载。
- 恢复后解除运行时阻止并刷新 DSH 会话列表；释放失败时不写入回收站索引。

Release live Agent and Session instances when moving a session to trash, keep the ID blocked until restore or purge, and leave the session visible when teardown fails.

## [0.1.2] - 2026-09-21

### 修复 / Fixes

- 彻底删除 live 会话前先完整释放 Agent 与 Session 运行时实例，避免文件已删除后会话仍被 DSH 列表返回。
- 删除期间阻止同 ID 会话重新加载；运行时释放失败时保留日志、回收站索引和工作区关联以便重试。

Release live Agent and Session instances before permanent deletion, block same-ID reactivation during the deletion window, and retain all recoverable state when runtime teardown fails.

## [0.1.1] - 2026-09-16

### 修复 / Fixes

- 兼容 ACP 创建的裸 UUID 会话，使其正常显示“移入回收站”和“彻底删除”。
- 工作区分组展开时立即重新应用隐藏状态，避免回收站会话短暂闪现。

Support bare UUID session IDs created through ACP, and immediately reapply hidden state when expanding workspace groups to prevent trashed sessions from flashing briefly.

## [0.1.0] - 2026-09-16

### 功能 / Features

- 会话菜单删除、回收站面板、侧边栏状态点和原生设置分区。
- 保留时间配置、自动到期清理与精确会话 ID 过滤。

Session deletion controls, trash management, sidebar status, native settings, retention policies, expiration cleanup, and exact-ID filtering.

### 修复 / Fixes

- 删除失败保留索引，批量失败互不阻断，成功后清理工作区关联。
- 删除请求固定意图，防止策略变化把软删除升级为永久删除。
- 保存暂存位置及删除阶段，完整暂存可恢复；不完整或冲突状态不误报成功。
- 策略补丁在队列中合并，避免并发覆盖。
- 幽灵探测绕过旧缓存进行复核，并限制请求和定时器数量。
- 永久删除当前会话时先切走，成功后统一刷新列表。
- 限制旧版暂存路径的递归删除范围，拒绝越界路径。
- 将显式永久删除的登记和清理合并到同一个写队列操作，避免恢复插入后误报成功。
- 核实并覆盖 DSH 原生删除工作区后的恢复与永久删除行为。

Retained failed entries and isolated batch failures; fixed deletion intent, staged recovery, concurrent policy updates, ghost-probe scheduling, current-session switching, legacy staging-path containment, atomic permanent deletion, and native workspace-removal interaction.

### 工程 / Project

- 中文默认 README、英文 README、开发文档和 MIT 许可证。
- 默认隔离测试入口、文档链接检查、GitHub CI 和协作模板。

Chinese-default and English READMEs, development and release guides, MIT license, isolated test commands, package checks, CI and GitHub Release automation, and collaboration templates.
