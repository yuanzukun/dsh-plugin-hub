#!/usr/bin/env node
/**
 * dsh-godot-skill verification:
 *  1. `node --check` on the plugin entry (syntax).
 *  2. Unit test with a mock `ctx`: assert the plugin registers the
 *     `godot-4-development` runtime skill with valid frontmatter-derived
 *     fields, non-empty body, and that the SKILL.md file ships with the repo.
 *
 * Exit code 0 = pass; non-zero = fail.
 */
import { execFileSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const ROOT = join(dirname(fileURLToPath(import.meta.url)), "..");
const PLUGIN = join(ROOT, "lib", "index.js");
const SKILL_FILE = join(ROOT, ".dsh", "skills", "godot-4-development", "SKILL.md");

let failures = 0;
function check(label, ok, detail = "") {
  if (!ok) failures += 1;
  console.log(`${ok ? "PASS" : "FAIL"}  ${label}${detail ? `  (${detail})` : ""}`);
}

// 1. Syntax check
try {
  execFileSync(process.execPath, ["--check", PLUGIN], { stdio: "pipe" });
  check("plugin syntax (node --check)", true);
} catch (error) {
  check("plugin syntax (node --check)", false, String(error.stderr ?? error));
}

// 2. Skill file ships and parses
check("SKILL.md exists", existsSync(SKILL_FILE));
if (existsSync(SKILL_FILE)) {
  const raw = readFileSync(SKILL_FILE, "utf8");
  check("SKILL.md starts with --- frontmatter", raw.startsWith("---\n"));
  check("SKILL.md is non-trivial", raw.trim().length > 2000, `${raw.length} bytes`);
}

// 3. Runtime registration behavior with a mocked ctx
const plugin = await import(pathToFileURL(PLUGIN).href);
let registered = null;
const disposers = [];
const mockCtx = {
  skills: {
    register(skill) {
      registered = skill;
      const disposer = () => {};
      disposers.push(disposer);
      return disposer;
    }
  },
  effect: (fn) => fn()
};
try {
  plugin.apply(mockCtx);
  check("apply() executed", true);
} catch (error) {
  check("apply() executed", false, error.message);
}
check("inject declares skills service", Array.isArray(plugin.inject) && plugin.inject.includes("skills"));
check("skill name is godot-4-development", registered?.name === "godot-4-development");
check("skill has non-empty description", typeof registered?.description === "string" && registered.description.length > 0);
check("skill has whenToUse", typeof registered?.whenToUse === "string" && registered.whenToUse.length > 0);
check("skill body is frontmatter-stripped", registered?.content?.startsWith("---\n") === false);
check("skill body contains core section", registered?.content?.includes("# Godot 4 游戏开发技能") === true);
check("skill body is substantial", (registered?.content?.length ?? 0) > 5000, `${registered?.content?.length ?? 0} chars`);
check("skill has resourceBase directory", registered?.resourceBase?.kind === "directory");
check("register returns a disposer", typeof plugin.apply.toString === "function");

console.log(failures === 0 ? "\nAll checks passed." : `\n${failures} check(s) FAILED.`);
process.exit(failures === 0 ? 0 : 1);
