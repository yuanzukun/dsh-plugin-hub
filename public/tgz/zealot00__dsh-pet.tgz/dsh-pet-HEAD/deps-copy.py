#!/usr/bin/env python3
"""Copy dsh-pet's leaf dependency tree into a dsh profile's node_modules.

Locates the dsh installation via the `dsh` binary symlink chain and copies:
    @deepseek-ai/schemastery  (needs @deepseek-ai/cosmokit, @standard-schema/spec)
Both leaves are zero-dependency, so this 3-package copy is complete.
Usage: deps-copy.py <profile-dir>
"""
import os
import shutil
import subprocess
import sys

profile = sys.argv[1]
dsh_bin = shutil.which("dsh")
if not dsh_bin:
    print("  ! cannot locate the dsh command; install these into profile/node_modules manually:")
    print("    @deepseek-ai/schemastery, @deepseek-ai/cosmokit, @standard-schema/spec")
    sys.exit(1)

real = os.path.realpath(dsh_bin)
d = os.path.dirname(real)
found = None
while True:
    cand = os.path.join(d, "node_modules")
    if os.path.isdir(cand):
        found = cand
        break
    parent = os.path.dirname(d)
    if parent == d:
        break
    d = parent
if not found:
    print("  ! no node_modules found under the dsh installation tree")
    sys.exit(1)

ok = True
for rel in ("@deepseek-ai/schemastery", "@deepseek-ai/cosmokit", "@standard-schema/spec"):
    src = os.path.join(found, rel)
    dst = os.path.join(profile, "node_modules", rel)
    if not os.path.isdir(src):
        print("  ! dependency source missing: " + src)
        ok = False
        continue
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.isdir(dst):
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    print("  copied " + rel)
sys.exit(0 if ok else 1)
