#!/usr/bin/env bash
# 卸载 dsh-pet 桌面宠物插件
# 用法：./uninstall.sh
set -euo pipefail

PROFILE="${DSH_PROFILE:-$HOME/.dsh/profiles/web}"
DEST="$PROFILE/node_modules/@dsh-local/dsh-pet"
PATCH="$PROFILE/cordis.patch.yml"

if [ -d "$DEST" ]; then
  rm -rf "$DEST"
  echo "✓ 已删除插件包"
else
  echo "（插件包不存在，跳过）"
fi

if [ -f "$PATCH" ]; then
  cp "$PATCH" "$PATCH.bak.$(date +%s)"
  BACKUP="$(ls -t "$PATCH".bak.* 2>/dev/null | head -1)"
  if [ -n "$BACKUP" ]; then
    python3 - "$BACKUP" > "$PATCH" <<'PYEOF'
import re
import sys

NL = chr(10)
src = open(sys.argv[1], encoding="utf-8").read()
lines = src.split(NL)
out = []
i = 0
while i < len(lines):
    line = lines[i]
    m = re.match(r"^(\s*)- insert:\s*$", line)
    if m:
        indent = m.group(1)
        block = [line]
        j = i + 1
        has_pet = False
        while j < len(lines):
            nxt = lines[j]
            if nxt.strip() == "" or nxt.startswith(indent + "  ") or nxt.startswith(indent + "-"):
                block.append(nxt)
                if "dsh-pet" in nxt:
                    has_pet = True
                j += 1
            else:
                break
        if not has_pet:
            out.extend(block)
        i = j
    else:
        out.append(line)
        i += 1
sys.stdout.write(NL.join(out))
PYEOF
  fi
  CLEAN="$(grep -v '^[[:space:]]*#' "$PATCH" 2>/dev/null | grep -v '^[[:space:]]*$' || true)"
  if [ -z "$CLEAN" ]; then
    printf '[]\n' > "$PATCH"
  fi
  echo "✓ 已从 cordis.patch.yml 移除插件行（原配置已备份）"
else
  echo "（无 cordis.patch.yml，跳过）"
fi

echo ""
echo "✅ 卸载完成！重启 dsh 后宠物消失："
echo "   dsh web"
