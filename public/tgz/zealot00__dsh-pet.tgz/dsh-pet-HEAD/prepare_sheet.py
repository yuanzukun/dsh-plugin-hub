#!/usr/bin/env python3
"""Assemble a 5x4 sprite sheet from AI-generated action strips + procedural fallback."""
import os
import sys
from collections import deque
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
AI_DIR = os.path.join(HERE, "zfy-ai")
SRC = os.path.join(HERE, "dsh-pet", "assets", "zhuangfangyi.png")
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "dsh-pet", "assets", "zhuangfangyi.sheet.png")

CELL_W, CELL_H = 200, 284
COLS = 4
STATES = ["idle", "thinking", "working", "done", "sleeping"]

CANDIDATES = {
    "idle": ["idle_a1_001.jpg", "idle_a2_001.jpg", "idle_a3_001.jpg"],
    "thinking": ["thinking_a1_001.jpg", "thinking_a2_001.jpg", "thinking_a3_001.jpg"],
    "working": ["working_a1_001.jpg", "working_a2_001.jpg", "working_a3_001.jpg"],
    "done": ["done_001.jpg"],
    "sleeping": ["sleeping_a1_001.jpg", "sleeping_a2_001.jpg", "sleeping_a3_001.jpg"],
}

PROCEDURAL = {
    "idle": [(0, 0, 0), (0, -0.03, 0), (0, -0.06, 0), (0, -0.03, 0)],
    "thinking": [(0, 0, 0), (0, -0.02, -4), (0, -0.02, 0), (0, -0.02, 4)],
    "working": [(0, 0, 0), (0, -0.12, 0), (0, 0, 0), (0, -0.06, 0)],
    "done": [(0, -0.10, 0), (0, -0.18, -3), (0, -0.08, 3), (0, 0, 0)],
    "sleeping": [(0, 0, 0), (0, -0.015, 0), (0, 0, 0), (0, -0.015, 0)],
}


def cutout(img):
    img = img.convert("RGBA")
    w, h = img.size
    px = img.load()
    visited = [[False] * w for _ in range(h)]
    q = deque()

    def is_bg(c):
        r, g, b, a = c
        return a > 100 and r > 230 and g > 230 and b > 230

    for x in range(w):
        for y in (0, h - 1):
            if not visited[y][x] and is_bg(px[x, y]):
                visited[y][x] = True; q.append((x, y))
    for y in range(h):
        for x in (0, w - 1):
            if not visited[y][x] and is_bg(px[x, y]):
                visited[y][x] = True; q.append((x, y))
    while q:
        x, y = q.popleft()
        px[x, y] = (255, 255, 255, 0)
        for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
            nx, ny = x + dx, y + dy
            if 0 <= nx < w and 0 <= ny < h and not visited[ny][nx] and is_bg(px[nx, ny]):
                visited[ny][nx] = True
                q.append((nx, ny))
    return img


def split_frames(img, cols):
    w, h = img.size
    alpha = img.getchannel("A")
    col_count = []
    for x in range(w):
        n = sum(1 for y in range(0, h, 4) if alpha.getpixel((x, y)) > 30)
        col_count.append(n)
    spans = []
    in_span = False
    start = 0
    for x in range(w):
        if col_count[x] > 0 and not in_span:
            in_span = True; start = x
        elif col_count[x] == 0 and in_span:
            in_span = False
            spans.append((start, x - 1))
    if in_span:
        spans.append((start, w - 1))
    if not spans:
        return []
    merged = []
    for s in spans:
        if merged and s[0] - merged[-1][1] < 20:
            merged[-1] = [merged[-1][0], s[1]]
        else:
            merged.append(list(s))
    if len(merged) >= cols:
        merged.sort(key=lambda s: s[1] - s[0], reverse=True)
        chosen = sorted(merged[:cols])
    else:
        chosen = merged
    frames = []
    for (sx, ex) in chosen:
        frames.append(img.crop((max(0, sx - 4), 0, min(w, ex + 4), h)))
    while len(frames) < cols:
        frames.append(frames[-1] if frames else img)
    return frames[:cols]


def frames_ok(frames):
    """AI strip is usable only if each frame has a substantial character."""
    ok = 0
    for f in frames:
        alpha = f.getchannel("A")
        xs = []; ys = []
        for x in range(0, f.width, 4):
            for y in range(0, f.height, 4):
                if alpha.getpixel((x, y)) > 40:
                    xs.append(x); ys.append(y)
        if not xs:
            continue
        bh = (max(ys) - min(ys)) / f.height
        if bh >= 0.30:
            ok += 1
    return ok >= len(frames) // 2


def fit_keep_ratio(src, cell_w, cell_h):
    w, h = src.size
    scale = min(cell_w / w, cell_h / h)
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    return src.resize((nw, nh), Image.LANCZOS)


def procedural_frames(state):
    src = Image.open(SRC).convert("RGBA")
    base = fit_keep_ratio(src, CELL_W, CELL_H)
    frames = []
    for dx, dy, deg in PROCEDURAL[state]:
        off = Image.new("RGBA", base.size, (0, 0, 0, 0))
        off.paste(base, (int(dx * base.width), int(dy * base.height)), base)
        if deg:
            off = off.rotate(deg, resample=Image.BICUBIC, expand=False)
        frames.append(off)
    return frames


def content_bbox(frame, pad=4):
    alpha = frame.getchannel("A")
    xs = []; ys = []
    for x in range(0, frame.width, 2):
        for y in range(0, frame.height, 2):
            if alpha.getpixel((x, y)) > 30:
                xs.append(x); ys.append(y)
    if not xs:
        return None
    return (max(0, min(xs) - pad), max(0, min(ys) - pad),
            min(frame.width, max(xs) + pad + 1), min(frame.height, max(ys) + pad + 1))


def cell_of(frame):
    cell = Image.new("RGBA", (CELL_W, CELL_H), (0, 0, 0, 0))
    box = content_bbox(frame)
    src = frame.crop(box) if box else frame
    f = fit_keep_ratio(src, CELL_W - 8, CELL_H - 8)
    cell.paste(f, ((CELL_W - f.width) // 2, CELL_H - f.height), f)
    return cell


def main():
    sheet = Image.new("RGBA", (CELL_W * COLS, CELL_H * len(STATES)), (0, 0, 0, 0))
    used_ai = {}
    for r, state in enumerate(STATES):
        frames = None
        for cand in CANDIDATES[state]:
            p = os.path.join(AI_DIR, cand)
            if os.path.exists(p):
                try:
                    cut = cutout(Image.open(p))
                    fr = split_frames(cut, COLS)
                    if len(fr) >= 2 and frames_ok(fr):
                        frames = fr
                        used_ai[state] = cand
                        break
                except Exception as e:
                    print("  [" + state + "] " + cand + " failed: " + str(e))
        if frames is None:
            print("  [" + state + "] AI missing -> procedural fallback")
            frames = procedural_frames(state)
        for c, fr in enumerate(frames[:COLS]):
            cell = cell_of(fr)
            sheet.paste(cell, (c * CELL_W, r * CELL_H), cell)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    sheet.save(OUT)
    print("saved:", OUT, sheet.size)
    print("AI used:", used_ai)
    print("procedural:", [s for s in STATES if s not in used_ai])


if __name__ == "__main__":
    main()
