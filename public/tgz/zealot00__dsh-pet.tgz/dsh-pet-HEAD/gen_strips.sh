#!/usr/bin/env bash
set -euo pipefail
cd "$(cd "$(dirname "$0")" && pwd)"
REF="$PWD/dsh-pet/assets/zhuangfangyi.png"

check() {
  python3 - "$1" <<'EOF'
import sys
from PIL import Image
img = Image.open(sys.argv[1]).convert("RGB")
w, h = img.size
xs, ys = [], []
for x in range(0, w, 6):
    for y in range(0, h, 6):
        r, g, b = img.getpixel((x, y))
        if r < 235 or g < 235 or b < 235:
            xs.append(x); ys.append(y)
if not xs:
    print("EMPTY"); sys.exit(0)
bw, bh = max(xs)-min(xs), max(ys)-min(ys)
print("bbox_h=" + format(bh/h, ".2f") + " bbox_w=" + format(bw/w, ".2f"))
if bh/h >= 0.40 and bw/w >= 0.55:
    print("PASS")
else:
    print("TOO_SMALL")
EOF
}

gen() {
  local name="$1" actions="$2"
  for attempt in 1 2 3; do
    echo "===== $name attempt $attempt ====="
    mmx image generate       --prompt "创建一条横向 Q 版角色动作条，画面中恰好 4 个完整的 Q 版角色，角色要大、占满画面高度至少75%、头顶接近画布上边缘、脚底接近画布下边缘，横向等距排列。所有角色完全相同（同一角色、相同服装发型、相同大小、相同脚底基线）。动作从左到右：$actions 。背景为完全均匀的纯白色 #FFFFFF，无阴影无地面无渐变无纹理。无文字无Logo无水印。"       --aspect-ratio 16:9       --subject-ref "type=character,image=$REF"       --out-dir zfy-ai --out-prefix "$name"_a"$attempt" --quiet >/dev/null 2>&1
    local file="zfy-ai/$name"_a"$attempt"_001.jpg
    if [ -f "$file" ]; then
      local verdict
      verdict=$(check "$file")
      echo "  check: $verdict"
      if echo "$verdict" | grep -q PASS; then
        echo "  OK -> keep $file"
        return 0
      fi
    fi
  done
  echo "  GAVE UP on $name"
  return 1
}

gen idle "第1帧站立待机双手下垂；第2帧身体微微上浮脚尖离地；第3帧浮到最高点发丝飘起；第4帧缓缓落回站立" || true
gen thinking "第1帧站立歪头思考；第2帧单手托下巴思考；第3帧双手抱胸思考；第4帧抬头看天思考" || true
gen working "第1帧双手握拳准备干活；第2帧快速小跳一下；第3帧落地继续蹦跳；第4帧再次起跳" || true
gen sleeping "第1帧站着打哈欠；第2帧缓缓蹲下；第3帧蜷缩坐地闭眼；第4帧完全睡着头歪一边" || true
echo ALL_DONE
