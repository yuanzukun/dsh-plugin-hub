#!/usr/bin/env bash
# 一键安装 dsh-pet 桌面宠物插件到本机 dsh web profile
# 用法：./install.sh
# 可用环境变量：DSH_PROFILE=/path/to/profile  （默认 ~/.dsh/profiles/web）
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
PROFILE="${DSH_PROFILE:-$HOME/.dsh/profiles/web}"

if [ ! -d "$PROFILE" ]; then
  echo "✗ 找不到 dsh profile：$PROFILE"
  echo "  如果你的 profile 不是 web，请设置 DSH_PROFILE 环境变量后重试。"
  exit 1
fi

echo "▶ 安装插件包到 $PROFILE/node_modules ..."
DEST="$PROFILE/node_modules/@dsh-local/dsh-pet"
mkdir -p "$PROFILE/node_modules/@dsh-local"
rm -rf "$DEST"
mkdir -p "$DEST"
cp -r "$SRC/lib" "$SRC/assets" "$SRC/package.json" "$DEST/"
echo "  ✓ 包已就位（含 assets 皮肤目录）"

echo "▶ 检查依赖 @deepseek-ai/schemastery ..."
if [ -d "$PROFILE/node_modules/@deepseek-ai/schemastery" ] && [ -d "$PROFILE/node_modules/@deepseek-ai/cosmokit" ] && [ -d "$PROFILE/node_modules/@standard-schema/spec" ]; then
  echo "  ✓ 依赖已就位"
else
  echo "  ▶ 从 dsh 安装树复制依赖..."
  python3 "$SRC/deps-copy.py" "$PROFILE"
fi

PATCH="$PROFILE/cordis.patch.yml"
if [ -f "$PATCH" ] && grep -q "dsh-pet" "$PATCH" 2>/dev/null; then
  echo "▶ cordis.patch.yml 已注册过该插件，跳过"
else
  echo "▶ 注册插件行到 cordis.patch.yml ..."
  if [ -f "$PATCH" ]; then
    cp "$PATCH" "$PATCH.bak.$(date +%s)"
  fi
  CLEAN="$(grep -v '^[[:space:]]*#' "$PATCH" 2>/dev/null | grep -v '^[[:space:]]*$' || true)"
  if [ -z "$CLEAN" ] || [ "$CLEAN" = "[]" ]; then
    cat > "$PATCH" <<'PEO'
# dsh-pet desktop pet - installed by install.sh
- insert:
    - id: dsh-pet
      name: '@dsh-local/dsh-pet'
PEO
  else
    cat >> "$PATCH" <<'PEO'

# dsh-pet desktop pet - installed by install.sh
- insert:
    - id: dsh-pet
      name: '@dsh-local/dsh-pet'
PEO
  fi
  echo "  ✓ 已注册（原配置已备份为 cordis.patch.yml.bak.*）"
fi

echo "▶ 验证 loader 解析 ..."
if (cd "$PROFILE" && node --input-type=module -e "import('@dsh-local/dsh-pet').then(m => { console.log('  ✓ RESOLVE_OK apply=' + typeof m.apply); process.exit(0) }).catch(e => { console.log('  ✗ ' + e.message.split(String.fromCharCode(10))[0]); process.exit(1) })"); then
  :
else
  echo "  ⚠ 解析失败：请检查上面的错误（通常是依赖缺失）"
  exit 1
fi

echo ""
echo "✅ 安装完成！请重启 dsh 生效："
echo "   dsh web        # 或你平时的启动命令"
echo ""
echo "   重启后：右下角出现宠物；左键点击说话，右键弹出设置面板。"
echo "   皮肤图片放 $DEST/assets/ 目录，设置面板里填文件名即可切换。"
