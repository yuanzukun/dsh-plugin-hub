#!/usr/bin/env python3
"""Generate a 5-state x 32-frame sprite sheet from a transparent single image.

Rows: 0=idle 1=thinking 2=working 3=done 4=sleeping
32 frames per state, dense sine/piecewise sampling so frame-to-frame motion
is tiny (~1px steps) — combined with client-side cross-fade interpolation
this reads as smooth, natural animation.

Usage: python3 scripts-gen-sheet.py [input.png] [output.sheet.png]
"""
import math
import os
import sys
from PIL import Image

CELL_W, CELL_H = 200, 284
N = 32  # frames per state


def half_sine(peak):
    """breathing curve: 0 -> peak -> 0 over the frame window"""
    return [round(peak * math.sin(math.pi * i / (N - 1)), 4) for i in range(N)]


def bounce(peak, cycles=2):
    return [(0, round(-peak * abs(math.sin(math.pi * cycles * i / (N - 1))), 4), 0) for i in range(N)]


def sway(deg, cycles=1):
    return [(0, -0.01, round(deg * math.sin(2 * math.pi * cycles * i / (N - 1)), 2)) for i in range(N)]


def jump():
    out = []
    for i in range(N):
        p = i / (N - 1)
        if p < 0.4:
            q = p / 0.4
            out.append((0, round(-26 * math.sin(math.pi * q), 4), round(7 * math.sin(math.pi * q), 2)))
        else:
            out.append((0, 0, 0))
    return out


STATES = {
    "idle":      [(0, v, 0) for v in half_sine(-0.042)],
    "thinking":  sway(4.5, 1),
    "working":   bounce(0.16, 2),
    "done":      jump(),
    "sleeping":  [(0, v, 0) for v in half_sine(-0.012)],
}


def fit(img, cell_w, cell_h):
    w, h = img.size
    scale = min(cell_w / w, cell_h / h)
    nw, nh = max(1, int(w * scale)), max(1, int(h * scale))
    return img.resize((nw, nh), Image.LANCZOS)


def transform(src, dx, dy, deg):
    w, h = src.size
    off = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    off.paste(src, (int(dx * w), int(dy * h)), src)
    if deg:
        off = off.rotate(deg, resample=Image.BICUBIC, expand=False)
    return off


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    src_path = sys.argv[1] if len(sys.argv) > 1 else os.path.join(here, "assets", "zhuangfangyi.png")
    out_path = sys.argv[2] if len(sys.argv) > 2 else os.path.join(here, "assets", "zhuangfangyi.sheet.png")

    if not os.path.exists(src_path):
        print("input not found:", src_path)
        sys.exit(1)

    src = Image.open(src_path).convert("RGBA")
    base = fit(src, CELL_W, CELL_H)

    rows = len(STATES)
    cols = N
    sheet = Image.new("RGBA", (CELL_W * cols, CELL_H * rows), (0, 0, 0, 0))

    for r, (state, frames) in enumerate(STATES.items()):
        assert len(frames) == cols, state
        for c, (dx, dy, deg) in enumerate(frames):
            frame = transform(base, dx, dy, deg)
            sheet.paste(frame, (c * CELL_W + (CELL_W - frame.width) // 2,
                                r * CELL_H + (CELL_H - frame.height) // 2), frame)

    sheet.save(out_path)
    print("sheet saved:", out_path)
    print("size:", sheet.size, "| grid:", cols, "x", rows)


if __name__ == "__main__":
    main()
