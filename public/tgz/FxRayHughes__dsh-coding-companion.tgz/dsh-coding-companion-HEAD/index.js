/**
 * dsh-coding-companion (编程陪伴) host half.
 *
 * Opens a configured site in a dedicated Chromium `--app` popup and drives it
 * from the Node host to follow the agent's state:
 *
 *   - working (an agent is running, nothing pending for the user): RESUME the
 *     window's whole process tree, maximize and focus it — playback continues.
 *   - blocked (all agents idle, or an approval / question is waiting): minimize
 *     the window, then SUSPEND its entire process tree so video and audio freeze
 *     and no CPU is spent. This is also the "don't steal focus" rule: whenever
 *     the user is needed (pending question / approval) the companion gets out of
 *     the way; it only comes to the front for pure background work.
 *
 * Design notes:
 *   - Persistence: each site gets a stable per-site `--user-data-dir` under
 *     `~/.dsh-coding-companion/<siteId>/`, so logins/cookies survive restarts
 *     and are isolated per site. The data dir doubles as the process marker.
 *   - Multi-site: settings carry a `sites` list and an `activeSiteId`; the
 *     companion is a singleton showing the active site. Switching relaunches.
 *   - Return-to-chat: a bundled unpacked extension injects a floating button in
 *     the window; clicking it hits the host route `/coding-companion/return`,
 *     which suspends the companion so the chat behind it is usable again.
 *   - Follows the parent: on host shutdown (graceful dispose or process exit)
 *     the window's process tree is resumed and killed — never left frozen.
 *
 * Windows-only: window show/hide uses Win32 ShowWindowAsync/SetForegroundWindow
 * and freezing uses ntdll NtSuspendProcess/NtResumeProcess over the full process
 * tree, both via an inline PowerShell controller.
 */
import { spawn, spawnSync } from 'node:child_process'
import { existsSync, mkdirSync, writeFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { basename, dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

export const name = 'dsh-coding-companion'

/** Settings namespace this companion reads its site list / flags from. */
const SETTINGS_NAMESPACE = 'coding-companion'
/** Tool call whose pending state counts as "waiting for the user". */
const QUESTION_TOOL = 'ask_user_question'
/** Persistent per-site profile root (logins/cookies live here). */
const PERSIST_BASE = join(homedir(), '.dsh-coding-companion')
/** Bundled unpacked extension that injects the "回到对话" button. */
const EXTENSION_DIR = join(dirname(fileURLToPath(import.meta.url)), 'return-extension')
/** Host route the extension pings to return to the chat. */
const RETURN_ROUTE = '/coding-companion/return'
/** Fallback site list when settings/config provide none. */
const DEFAULT_SITES = [{ id: 'douyin', name: '抖音精选', url: 'https://www.douyin.com/jingxuan' }]

/** Chromium install locations checked when no browser path is configured. */
const WINDOWS_BROWSER_CANDIDATES = [
  'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
]

/**
 * Pick a browser executable. An explicit config value wins; otherwise the
 * common Windows install paths are probed before falling back to PATH lookup.
 * @param {string | undefined} explicit - configured browser command or undefined.
 * @returns {string} an executable path or command.
 */
function resolveBrowser(explicit) {
  if (typeof explicit === 'string' && explicit.trim() !== '') return explicit.trim()
  for (const candidate of WINDOWS_BROWSER_CANDIDATES) {
    if (existsSync(candidate)) return candidate
  }
  return 'msedge'
}

/**
 * Quote a string as a PowerShell single-quoted literal (backslashes stay
 * literal; embedded single quotes are doubled). Required because the marker is
 * a Windows path full of backslashes: `JSON.stringify` would escape them to
 * `\\`, and a PowerShell *double*-quoted string keeps `\\` as two characters,
 * so the marker would never match the real single-backslash command line.
 * @param {string} value - the raw string.
 * @returns {string} a PowerShell single-quoted literal.
 */
function psQuote(value) {
  return `'${value.replace(/'/g, "''")}'`
}

/**
 * Build the PowerShell controller for one action against a marked window. The
 * marker (the window's unique `--user-data-dir`) identifies the Chromium root
 * process by its command line; the full process tree is gathered by parent
 * links. `restore` resumes then maximizes+focuses; `suspend` minimizes then
 * freezes the tree; `close` resumes (clean kill) then taskkills the tree.
 * @param {string} marker - unique marker substring present in the browser argv.
 * @param {'restore' | 'suspend' | 'close'} action - the control action.
 * @param {string} processName - executable name to filter by (e.g. `msedge.exe`).
 * @returns {string} a complete Windows PowerShell script.
 */
function controllerScript(marker, action, processName) {
  const markerLiteral = psQuote(marker)
  const actionLiteral = psQuote(action)
  const filterLiteral = psQuote(`Name='${processName}'`)
  return `$ErrorActionPreference = 'SilentlyContinue'
$marker = ${markerLiteral}
$action = ${actionLiteral}
$root = Get-CimInstance Win32_Process -Filter ${filterLiteral} | Where-Object { $_.CommandLine -like ('*' + $marker + '*') } | Select-Object -First 1
if ($null -eq $root) { exit 2 }
$rootId = [int]$root.ProcessId

$byParent = @{}
foreach ($p in (Get-CimInstance Win32_Process)) {
  $ppid = [int]$p.ParentProcessId
  if (-not $byParent.ContainsKey($ppid)) { $byParent[$ppid] = New-Object System.Collections.ArrayList }
  [void]$byParent[$ppid].Add([int]$p.ProcessId)
}
$tree = New-Object System.Collections.ArrayList
$stack = New-Object System.Collections.Stack
$stack.Push($rootId)
while ($stack.Count -gt 0) {
  $cur = $stack.Pop()
  [void]$tree.Add($cur)
  if ($byParent.ContainsKey($cur)) { foreach ($c in $byParent[$cur]) { $stack.Push($c) } }
}

Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class DshCompanionWin {
  [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("kernel32.dll")] public static extern IntPtr OpenProcess(int access, bool inherit, int pid);
  [DllImport("kernel32.dll")] public static extern bool CloseHandle(IntPtr h);
  [DllImport("ntdll.dll")] public static extern int NtSuspendProcess(IntPtr h);
  [DllImport("ntdll.dll")] public static extern int NtResumeProcess(IntPtr h);
  private const int PROCESS_SUSPEND_RESUME = 0x0800;
  public static void Suspend(int pid) { IntPtr h = OpenProcess(PROCESS_SUSPEND_RESUME, false, pid); if (h != IntPtr.Zero) { NtSuspendProcess(h); CloseHandle(h); } }
  public static void Resume(int pid) { IntPtr h = OpenProcess(PROCESS_SUSPEND_RESUME, false, pid); if (h != IntPtr.Zero) { NtResumeProcess(h); CloseHandle(h); } }
}
'@

function Get-MainHandle($processId) {
  for ($i = 0; $i -lt 40; $i++) {
    $h = (Get-Process -Id $processId).MainWindowHandle
    if ($h -ne 0) { return $h }
    Start-Sleep -Milliseconds 250
  }
  return [IntPtr]::Zero
}

switch ($action) {
  'restore' {
    foreach ($id in $tree) { [DshCompanionWin]::Resume($id) }
    $handle = Get-MainHandle $rootId
    if ($handle -ne 0) {
      [DshCompanionWin]::ShowWindowAsync($handle, 3) | Out-Null
      [DshCompanionWin]::SetForegroundWindow($handle) | Out-Null
    }
    exit 0
  }
  'suspend' {
    $handle = (Get-Process -Id $rootId).MainWindowHandle
    if ($handle -ne 0) { [DshCompanionWin]::ShowWindowAsync($handle, 6) | Out-Null }
    Start-Sleep -Milliseconds 400
    foreach ($id in $tree) { [DshCompanionWin]::Suspend($id) }
    exit 0
  }
  'close' {
    foreach ($id in $tree) { [DshCompanionWin]::Resume($id) }
    & taskkill.exe /PID $rootId /T /F | Out-Null
    exit 0
  }
  default { exit 4 }
}
`
}

/**
 * Host plugin. Config is the bundle row's `config` from cordis.patch.yml.
 * @param {import('@deepseek-ai/cordis').Context} ctx - host cordis context.
 * @param {{ sites?: Array<{id:string,name:string,url:string}>, activeSiteId?: string, browser?: string, enabled?: boolean }} [config] - companion options.
 */
export function apply(ctx, config = {}) {
  const options = {
    sites: DEFAULT_SITES,
    activeSiteId: undefined,
    browser: undefined,
    enabled: true,
    ...config,
  }

  if (options.enabled === false || process.platform !== 'win32') return

  const browser = resolveBrowser(options.browser)
  const processName = basename(browser)

  /** @type {null | { marker: string, url: string, siteId: string }} */
  let launched = null
  let lastNonce = 0

  const readSection = () => {
    const settings = ctx.get('settings')
    const section = settings ? settings.get(SETTINGS_NAMESPACE) : undefined
    return section && typeof section === 'object' ? section : undefined
  }

  const currentSites = () => {
    const section = readSection()
    const sites = section && Array.isArray(section.sites) ? section.sites : options.sites
    return sites.length > 0 ? sites : DEFAULT_SITES
  }

  const currentActiveSite = () => {
    const sites = currentSites()
    const section = readSection()
    const activeId = (section && typeof section.activeSiteId === 'string' ? section.activeSiteId : undefined) ?? options.activeSiteId
    return sites.find(site => site.id === activeId) ?? sites[0]
  }

  const currentEnabled = () => {
    const section = readSection()
    return section && typeof section.enabled === 'boolean' ? section.enabled : options.enabled
  }

  /** "暂停陪伴": when true the window stays closed regardless of agent state. */
  const currentPaused = () => {
    const section = readSection()
    return section && typeof section.paused === 'boolean' ? section.paused : false
  }

  /** Monotonic counter the widget bumps to request an explicit open/restore. */
  const currentNonce = () => {
    const section = readSection()
    return section && typeof section.openNonce === 'number' ? section.openNonce : 0
  }

  lastNonce = currentNonce()

  const runningAgents = new Set()
  const pendingApprovals = new Set()
  const pendingQuestions = new Set()

  const blocked = () =>
    runningAgents.size === 0 || pendingApprovals.size > 0 || pendingQuestions.size > 0

  /** Per-site persistent Chromium profile directory (also the process marker). */
  const userDataDirFor = siteId => join(PERSIST_BASE, siteId)

  function launchBrowser() {
    const site = currentActiveSite()
    const userDataDir = userDataDirFor(site.id)
    try {
      mkdirSync(userDataDir, { recursive: true })
    } catch { /* Chromium will create it; a pre-create failure is non-fatal. */ }
    const args = [
      `--app=${site.url}`,
      `--user-data-dir=${userDataDir}`,
      '--new-window',
      '--window-size=1920,1080',
      '--window-position=0,0',
      '--no-first-run',
      '--no-default-browser-check',
      '--disable-features=Translate',
    ]
    if (existsSync(EXTENSION_DIR)) {
      args.push(`--load-extension=${EXTENSION_DIR}`, `--disable-extensions-except=${EXTENSION_DIR}`)
    }
    const child = spawn(browser, args, { detached: true, stdio: 'ignore' })
    child.on('error', (error) => {
      ctx.logger.warn(`${name}: failed to launch ${browser}: ${error.message}`)
    })
    child.unref()
    launched = { marker: userDataDir, url: site.url, siteId: site.id }
  }

  /**
   * Run one controller action against the launched window.
   * @param {'restore' | 'suspend' | 'close'} action - the control action.
   * @returns {Promise<number>} exit code (2 = window gone; -1 = spawn failure).
   */
  function control(action) {
    return new Promise((resolve) => {
      if (launched === null) { resolve(-1); return }
      const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', controllerScript(launched.marker, action, processName)], {
        stdio: 'ignore',
        windowsHide: true,
      })
      child.on('error', (error) => {
        ctx.logger.warn(`${name}: window control failed (${action}): ${error.message}`)
        resolve(-1)
      })
      child.on('exit', (code) => { resolve(code ?? -1) })
    })
  }

  /** Synchronously resume+kill the launched window's tree (for process exit). */
  function closeSync() {
    if (launched === null) return
    try {
      spawnSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', controllerScript(launched.marker, 'close', processName)], {
        stdio: 'ignore',
        windowsHide: true,
        timeout: 8000,
      })
    } catch { /* best effort on the way out */ }
    launched = null
  }

  function syncWindow() {
    if (!currentEnabled() || currentPaused()) {
      if (launched !== null) {
        control('close')
        launched = null
      }
      return
    }
    if (blocked()) {
      if (launched !== null) control('suspend')
      return
    }
    if (launched === null) {
      launchBrowser()
      control('restore')
      return
    }
    void control('restore').then((code) => {
      // exit 2 = root process gone: the user closed the window by hand. Relaunch
      // if we are still in a state that wants it visible.
      if (code === 2 && launched !== null && !blocked() && currentEnabled() && !currentPaused()) {
        launchBrowser()
        control('restore')
      }
    })
  }

  /** Force the window open now (manual "open / restore"), recovering a hand-closed one. */
  function forceOpen() {
    if (!currentEnabled() || currentPaused()) return
    if (launched === null) {
      launchBrowser()
      control('restore')
      return
    }
    void control('restore').then((code) => {
      if (code === 2) {
        launchBrowser()
        control('restore')
      }
    })
  }

  // The return-to-chat route + the extension config that points at it. Mounted
  // only where a web server exists; harmless (never hit) otherwise.
  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: RETURN_ROUTE,
      handler: (_req, res) => {
        control('suspend')
        res.writeHead(204, { 'access-control-allow-origin': '*', 'cache-control': 'no-store' })
        res.end()
      },
    }), 'coding-companion: return route')

    // Tell the bundled extension where to ping. 127.0.0.1 regardless of bind host.
    const returnUrl = `http://127.0.0.1:${webCtx.webServer.port}${RETURN_ROUTE}`
    try {
      if (existsSync(EXTENSION_DIR)) {
        writeFileSync(join(EXTENSION_DIR, 'config.js'), `self.__DSH_RETURN_URL = ${JSON.stringify(returnUrl)};\n`)
      }
    } catch (error) {
      webCtx.logger.warn(`${name}: failed to write extension config: ${error instanceof Error ? error.message : String(error)}`)
    }
  })

  ctx.on('agent/status', ({ agent, status }) => {
    const wasBlocked = blocked()
    if (status === 'running') runningAgents.add(agent.id)
    else runningAgents.delete(agent.id)
    if (blocked() !== wasBlocked) syncWindow()
  })

  ctx.on('session/event', (_session, event) => {
    const wasBlocked = blocked()
    if (event.type === 'approval/asked') {
      pendingApprovals.add(event.data.id)
    } else if (event.type === 'approval/decided') {
      pendingApprovals.delete(event.data.id)
    } else if (event.type === 'tool/call' && event.data.name === QUESTION_TOOL) {
      pendingQuestions.add(event.data.callId)
    } else if (event.type === 'tool/result') {
      const callId = event.data.message?.content?.[0]?.toolCallId
      if (callId !== undefined) pendingQuestions.delete(callId)
    }
    if (blocked() !== wasBlocked) syncWindow()
  })

  ctx.on('settings/updated', (ns) => {
    if (ns !== SETTINGS_NAMESPACE) return
    // Active site or its URL changed: close so the next sync relaunches fresh
    // (a different site means a different persistent profile).
    if (launched !== null) {
      const site = currentActiveSite()
      if (launched.siteId !== site.id || launched.url !== site.url) {
        control('close')
        launched = null
      }
    }
    const nonce = currentNonce()
    if (nonce > lastNonce) {
      lastNonce = nonce
      forceOpen()
      return
    }
    syncWindow()
  })

  // Follow the parent: resume+kill the tree on graceful dispose and on process
  // exit, so the window is never left as a frozen (suspended) zombie.
  const onExit = () => { closeSync() }
  const onSignal = () => { closeSync(); process.exit(0) }
  process.once('exit', onExit)
  process.once('SIGINT', onSignal)
  process.once('SIGTERM', onSignal)

  ctx.effect(function* () {
    yield () => {
      process.off('exit', onExit)
      process.off('SIGINT', onSignal)
      process.off('SIGTERM', onSignal)
      if (launched !== null) closeSync()
    }
  })
}
