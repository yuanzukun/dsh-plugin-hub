/**
 * Content script: inject a floating "↩ 回到对话" button. Clicking it asks the
 * DSH host to minimize + suspend the companion window so the chat behind it is
 * usable again.
 *
 * The host is reached over TWO paths for robustness, because Chromium `--app`
 * windows are quirky about extensions:
 *   1. a direct fetch from the content script (works when the page CSP allows
 *      connecting to 127.0.0.1), and
 *   2. a message to the background service worker, which fetches from the
 *      extension context (bypasses page CSP — the fallback when 1 is blocked).
 * Both hit the same idempotent route, so a double-fire is harmless. The button
 * also flashes feedback and logs to the console for diagnosis (open the
 * companion window's DevTools with Ctrl+Shift+I).
 */
(function () {
  if (window.top !== window.self) return
  if (document.getElementById('dsh-return-button')) return

  const RETURN_URL = (typeof self.__DSH_RETURN_URL === 'string' && self.__DSH_RETURN_URL)
    || 'http://127.0.0.1:3080/coding-companion/return'

  const button = document.createElement('button')
  button.id = 'dsh-return-button'
  button.type = 'button'
  button.textContent = '↩ 回到对话'
  Object.assign(button.style, {
    position: 'fixed',
    right: '16px',
    bottom: '16px',
    zIndex: '2147483647',
    padding: '8px 14px',
    font: '13px/1.4 system-ui, sans-serif',
    color: '#fff',
    background: 'rgba(20,20,20,0.82)',
    border: '1px solid rgba(255,255,255,0.24)',
    borderRadius: '999px',
    boxShadow: '0 4px 14px rgba(0,0,0,0.35)',
    cursor: 'pointer',
    opacity: '0.55',
    transition: 'opacity 0.15s ease',
  })
  button.addEventListener('mouseenter', () => { button.style.opacity = '1' })
  button.addEventListener('mouseleave', () => { button.style.opacity = '0.55' })

  const flash = (text) => {
    const original = '↩ 回到对话'
    button.textContent = text
    setTimeout(() => { button.textContent = original }, 1200)
  }

  button.addEventListener('click', () => {
    console.log('[dsh-companion] return clicked →', RETURN_URL)
    flash('↩ 返回中…')

    // Path 1: direct fetch (subject to page CSP connect-src).
    fetch(RETURN_URL, { method: 'GET', mode: 'no-cors', cache: 'no-store', keepalive: true })
      .then(() => { console.log('[dsh-companion] direct fetch ok') })
      .catch((error) => { console.warn('[dsh-companion] direct fetch failed:', error && error.message) })

    // Path 2: via background service worker (extension context, bypasses CSP).
    try {
      chrome.runtime.sendMessage({ type: 'dsh-return', url: RETURN_URL }, () => {
        // Reading lastError avoids "Unchecked runtime.lastError" noise when no SW.
        void chrome.runtime.lastError
      })
    } catch (error) {
      console.warn('[dsh-companion] sendMessage failed:', error && error.message)
    }
  })

  const mount = () => {
    if (document.body) document.body.appendChild(button)
    else requestAnimationFrame(mount)
  }
  mount()
  console.log('[dsh-companion] return button mounted')
})()
