/**
 * Background service worker: on a "dsh-return" message from the content script,
 * ping the DSH host's return route. The fetch runs in the extension context
 * (host_permissions), so the page's CSP does not block the localhost call —
 * this is the reliable path when the page forbids connecting to 127.0.0.1.
 *
 * The URL comes from the message (content script read it from config.js); if
 * absent we fall back to config.js here, then to the default dev port.
 */
let RETURN_URL = 'http://127.0.0.1:3080/coding-companion/return'
try {
  importScripts('config.js')
  if (typeof self.__DSH_RETURN_URL === 'string') RETURN_URL = self.__DSH_RETURN_URL
} catch {
  /* config.js not written yet: keep the default */
}

chrome.runtime.onMessage.addListener((message) => {
  if (!message || message.type !== 'dsh-return') return
  const url = typeof message.url === 'string' && message.url ? message.url : RETURN_URL
  fetch(url, { method: 'GET', cache: 'no-store', keepalive: true })
    .then(() => { console.log('[dsh-companion:sw] return ok', url) })
    .catch((error) => { console.warn('[dsh-companion:sw] return failed', error && error.message) })
})
