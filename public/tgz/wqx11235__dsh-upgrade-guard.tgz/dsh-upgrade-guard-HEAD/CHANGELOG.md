# Changelog

## 0.2.1 — 2026-11-07

针对 **DSH 桌面端 0.2.1-rc.5 /**（Electron 44.7.0 · Node 24.21.0）的一次实地维护。
触发原因很直接：在跑 `scan` 时它报出 `plugins scanned=0 / critical=0` —— 一份"全部干净"的假结论。

### 修掉的三处"守卫自己失明"

- **`DSH_PROFILE` 是名字，不是路径**。桌面端注入的是 `DSH_PROFILE=desktop`，真目录在 `DSH_PROFILE_DIR`。
  旧代码把名字当目录拼成 `desktop/node_modules`，读不到任何包 → 扫 0 个插件却显示 0 个问题。
  现在名称与路径两种语义都能解析（`--profile desktop` 也可以了）。
- **写报告失败会吞掉整次扫描**。`$DSH_HOME/upgrade-guard` 不可写（沙箱 / 只读盘）时 `mkdir` 抛 EPERM，
  JSON 还没输出进程就死了，宿主路由只能拿到 500。现在主路径失败自动退到系统临时目录，结论永远能回传。
- **导出表恒为空**。本机这份 `dsh-client-ui-primitives` 的 `package.json` 声明了
  `types: lib/types/index.d.ts`，但该文件根本不存在（只有 31 个分散的 `.d.ts`）——旧实现只认两个写死路径，
  于是"引用了不存在的导出"这条检查一直静默跳过。现在按 package.json 入口读，入口缺失时聚合 `lib/types/*.d.ts`，
  并从 `export * from './x'` 递归收集。实测能收到 102 个导出名。

### 适配打包桌面端（这是 0.2.x 上第一次能看见真实宿主版本）

- 桌面端把整个 dsh 打包进 `app.asar`，`profiles/node_modules` 里那份 `@deepseek-ai/dsh` 是**陈旧的**
  （本机实测 0.1.7-rc.2，真正在跑的是 0.2.1-rc.5）。现在直接解析 asar 头读产品版本，
  顺序为 `asar` → 宿主写下的缓存 → `dsh-runtimes/*/runtime.json` → profile 依赖树，并在 UI 上标出来源。
- 新增 `status` 子命令：只探测不扫描（profile / 宿主版本 / 导出表可用性 / 插件计数）。
- 新增运行期实测 `ctx.get` 是否仍返回服务（0.2.x 收紧后返回 `undefined`），结果显示在设置页脚注。

### 导出表检查现在会明说"跳过"

0.2.1-rc.5 的 asar 里**已经不存在** `dsh-client-ui-primitives` 这个包（拆成了一堆 `dsh-client-ui-*`），
磁盘上只剩 0.1.0-rc.6。拿 0.1 的表去判 0.2 的插件必然误报，所以：

- primitives 与宿主不在同一条 minor 线时，`missing-host-export` 检查**明确跳过**并说明原因，
  报告与 UI 都写清楚"这一类风险本次没有覆盖"；
- 想真覆盖就用 `--primitives` 指向与宿主同版本的目录。

### 减少假阳性

- **不再扫自己**：`KNOWN_RULES` 的定义里必然写着 `settingsScope` / `conversationEvents`，
  旧版会把 guard.mjs 的规则目录报成 2 个 critical。
- **探测式取服务降级为 warn**：`configForms === void 0 ? ctx.get("settingsScope") : void 0` 这类
  兼容分支本来就是"旧宿主才走的路"，实测 dsh-image-gen 被误报成 critical。

### 其它

- 设置页「插件 0.2.0」改为从 package.json 读取，不再硬编码。
- 空 profile（0 个插件）不再被当成"全部健康"——计数为 0 时会连同原因一起显示。

---

## 0.2.0 — 2026-10-17

- 严格官方插件格式；零 `@deepseek-ai/*` import；桌面端 / 网页端双兼容；契约目录 4 条规则。

## 0.1.0 — 2026-09-29

- 首版：`scan` / `preflight` / `smoke` 三个能力。
