import {randomUUID,randomBytes,createHash,createHmac} from 'node:crypto';
import {mkdirSync,openSync,writeFileSync,closeSync,readFileSync,unlinkSync,fstatSync,fsyncSync,realpathSync,constants} from 'node:fs';
import {join,resolve} from 'node:path';
import {execFileSync} from 'node:child_process';
import {setTimeout as delay} from 'node:timers/promises';
import {createStore,recordMatchesBinding} from './store.mjs';
import {createWorkbench} from './workbench.mjs';
import {buildOwnerBrief,buildElderDaily,localDate,localDateTimeToInstant} from './brief.mjs';
import {scheduleTick} from './scheduler.mjs';
import {createChannelManager} from './channels.mjs';
import {createConnectionSuspensions} from './connection-suspensions.mjs';
import {weixinSendFailureDetail,readWeixinSendFailureDetail} from './weixin-send-diagnostic.mjs';
import {parseModelReply,modelFailureReply} from './model.mjs';
import {isOwnerCommandCandidate,resolveOwnerTarget,hasExplicitOwnerTime} from './owner-commands.mjs';
import {createPresentationWorkflow} from './presentation-workflow.mjs';
import {createConversationHistory} from './conversation-history.mjs';
import {buildHealth} from './health.mjs';
import {isMemberNative} from './member-native-flags.mjs';
import {planMemberMigration} from './member-native-migration.mjs';
import {createConsoleConversationStore} from './owner-console-conversation.mjs';
import {reachFor,reachLabel,canSendNow} from './reach.mjs';
import {safetyCard} from './safety.mjs';
import {buildOwnerTurn} from './owner-prompt.mjs';
import {writeAttachmentFile} from './owner-attachments.mjs';
import {ownerPushBackground,withOwnerPushHeader,ownerPushCategory} from './owner-push.mjs';
import {createFamilyAccess} from './family-access.mjs';
import {createHarnessGateway} from './harness-gateway.mjs';
import {createFamilyToolbox} from './family-toolbox.mjs';
import {isOwnerDotNewsIntent} from './owner-dot-news-intent.mjs';
import {isProjectFollowupText} from './harness-planner.mjs';
import {createPersonalOrganizer} from './personal-organizer.mjs';
import {createMemberLibrary} from './member-library.mjs';
import {createOwnerLibrarySources} from './owner-library-sources.mjs';
import {scoreRecord} from './library-search.mjs';
import {isDiaryInvitationReply,stopsDiaryInvitations,dismissesDiaryConversation} from './diary-invitations.mjs';
import {createServiceSetup,serviceSetupErrorText} from './service-setup.mjs';
import {createMemberOnboarding} from './member-onboarding.mjs';
import {createDeferredMemberNotices,deferredNoticeKind} from './deferred-member-notices.mjs';
import {buildServiceProgress} from './service-progress.mjs';
import {createDigestDelivery} from './digest-delivery.mjs';
import {createWorkflowNotifications} from './workflow-notifications.mjs';
import {canRequestMemberOwnerHelp,canAskMemberOwner} from './member-agent.mjs';
import {isOwnerManagementConfirmation,isOwnerMessageDraftIntent,ownerServiceContextId} from './owner-management-tool.mjs';
import {confirmOwnerServiceDraft} from './owner-service-confirm.mjs';
import {createOwnerServiceLedger,serviceDraftMarker} from './owner-service-ledger.mjs';
import {createRuntimeAttention} from './important-event-runtime.mjs';
import {createDotOwnerProjectRead} from './dot-owner-project-read.mjs';
import {acceptedReviewToken} from './owner-review-ack.mjs';
import {isRedundantReadAcknowledgement} from './dot-owner-ack.mjs';
import {waitForOwnerReply,findOwnerRequest,archivedOwnerDelivery} from './dot-owner-send-barrier.mjs';
import {sourceTimingState} from './source-timing.mjs';
import {createDotOwnerProjectAdmission,ownerProjectAdmissionTimeCurrent} from './dot-owner-project-admission.mjs';
import {createInboundTimingLedger} from './inbound-timing-ledger.mjs';
import {parseOwnerRelativeReminder} from './owner-relative-reminder.mjs';
import {createHearthPreferences} from './hearth-preferences.mjs';

const displayAttachments=items=>Array.isArray(items)?items.slice(0,4).flatMap(item=>{if(typeof item?.name!=='string'||!item.name.trim())return[];const name=item.name.replace(/[\\/\x00-\x1f\x7f]/g,'_').slice(0,180),size=Number(item.size??item.len);return[{name,...(Number.isSafeInteger(size)&&size>=0&&size<=10*1024*1024?{size}:{}),...(typeof item.mimeType==='string'&&/^[-a-z0-9.+]+\/[-a-z0-9.+]+$/i.test(item.mimeType)?{mimeType:item.mimeType}:{})}];}):[];
const sameRoute=(a,b)=>a&&b&&['personId','accountId','peerId','generation'].every(key=>a[key]===b[key]);
const messageParts=text=>{const chunks=[];while(text.length){let end=Math.min(3000,text.length);if(end<text.length&&/[\uD800-\uDBFF]/.test(text[end-1]))end--;chunks.push(text.slice(0,end));text=text.slice(end);}return chunks.length?chunks:['（工具返回了空内容）'];};
const personalIntent=text=>/记住|记下|便笺|记事|我的笔记|我记(?:的|下的)|忘掉|忘记刚才|(?:今天|明天|这周|本周|下周)(?:我)?(?:有|要|的).{0,12}(?:事|日程|安排)/.test(text);
const ownerExactRelativeReminder=text=>parseOwnerRelativeReminder(text)!==null;
const ownerPersonalIntent=text=>personalIntent(text)||/(?:提醒我(?!爸|妈|父亲|母亲)|我的.*提醒|我(?:有|设置|安排).{0,12}提醒|(?:查看|列出|取消).{0,12}我的)/.test(text);
// Personal reminders retain their existing path. Explicit project/source
// requests with a follow-up go intact to the Owner agent, which decides which
// native tools to use; this does not itself grant a source or create a plan.
const ownerContextTask=text=>isOwnerDotNewsIntent(text)||/(?:个人回顾|个人复盘|资讯兴趣|资讯日报|AI\s*日报(?:关注|主要关注|状态)|\bdot\b|dsh-project-companion|\bflomo\b|\bgmail\b|google\s*(?:日历|drive|calendar)|项目.{0,20}(?:简报|进展|跟进)|(?:邮箱|邮件|日历|笔记|云盘).{0,40}(?:简报|总结|整理|项目))/i.test(text);
const ownerBriefIntent=text=>/^(?:\/brief|今日简报|今天的简报|服务简报|查看简报|日报|简报)[。！!？?\s]*$/.test(text.trim());
const helpIntent=text=>/^(?:你(?:现在)?(?:能|可以)帮我(?:做什么|干什么|做啥)|你(?:都)?(?:会|能做)什么|怎么用|使用帮助|帮助)[。！!？?\s]*$/.test(text.trim());
// Sending a message is a management action. Only an explicit request to
// produce project material may designate the native result as the artifact.
const ownerArtifactIntent=text=>!/发(?:一条|一则|个)?消息|转告|告诉|通知|先问我|先给我看|等我确认|先核对/.test(text)&&/整理|生成|制作|起草|写一|准备|读取|查找|找到|搜索|日报|PPT|幻灯片/i.test(text);
const ownerWaitingText=text=>/日报|digest/i.test(text)?'我还在查找这份日报，找到后会在这里回复你。':/查|找|读|搜/.test(text)?'我还在查找你要的资料，找到后会在这里回复你。':/PPT|幻灯片/i.test(text)?'这份演示稿还在整理，做好后会在这里回复你。':'这件事还在处理，我会把结果回复在这里。';
const inputKeys={
  add_person:['role','label','timeZone','interests','shareWithOwner'],
  update_person:['personId','label','timeZone','interests','notes','shareWithOwner','dailyEnabled','dailyTime'],
  configure:['paused','ownerBriefEnabled','ownerBriefTime','timeZone','provider','model'],
  login:['personId'],verify_login:['personId','code'],connect:['personId'],disconnect:['personId'],
  add_reminder:['id','personId','text','dueAt','repeat','time','timeZone','purpose'],cancel_reminder:['personId','reminderId'],dismiss_relay:['relayId'],
  preview_brief:[],send_brief:[],send_message:['personId','text'],start:[],pause:[],
  owner_chat:['text','contextId','requestId','profileIntake','profileEdit','draftOnly','workspaceId','taskId'],confirm_card:['cardId','revision'],cancel_card:['cardId','actionId'],
  retry_action:['cardId','actionId'],check_action:['cardId','actionId'],undo_profile:['cardId'],
  reply_request:['requestId','text','operationId'],resolve_request:['requestId'],
  history_page:['personId','before','limit','query'],family_access_list:[],
  library_query:['personId','query','date','from','to','kind','before','limit'],library_update:['personId','id','expectedRevision','requestId','text'],library_delete:['personId','id','expectedRevision','requestId'],
  family_access_grant:['personId','workspaceIds','capabilities'],family_access_revoke:['personId'],
  harness_projects:[],harness_submit:['workspaceId','text','requestId','recipientPersonId'],harness_task_status:['taskId'],harness_continue:['taskId','text','requestId'],harness_cancel:['taskId'],harness_artifact:['taskId','relativePath'],
  tool_catalog:['personId'],tool_assignments:['personId'],tool_assign:['personId','toolId','resource','allowInvoke','schedule'],
  tool_invoke:['personId','toolId','requestId','input','expectedRevision'],workflow_requests:[],workflow_request_update:['personId','requestId','status','note','operationId'],workflow_reply:['request','status','note','operationId'],weather_locations:['query'],digest_sources:['workspaceId','query'],
  family_reply:['requestId','text'],attention_respond:['incidentId','status','text'],service_request:['text','requestId'],owner_reminder:['op','text','dueAt','repeat','reminderId'],
  service_select:['draftId','revision','choiceId','requestId'],service_confirm:['draftId','revision','requestId'],service_cancel:['draftId','revision','requestId'],
  service_send_once:['draftId','revision','requestId'],
  resume_owner_native_message:['messageId'],
  owner_send_message:['personId','text','requestId','bindingGeneration'],
  defer_member_notice:['personId','text','requestId','bindingGeneration'],deferred_member_notices:[],
  attention_configure:['enabled'],attention_update:['incidentId','status'],
  owner_conversation_open:[],
  hearth_member_update:['personId','pinganEnabled','pinganTime','codeword'],
  hearth_guard_update:['urgent','relay','ask','digest','quietHoursEnabled','quietStart','quietEnd'],
  reminder_skip_once:['personId','reminderId','date','skip'],
  defer_and_dismiss_relay:['relayId','personId','text','requestId','bindingGeneration'],
  cancel_deferred_notice:['personId','id'],
  hearth_habit_save:['personId','id','text'],
  hearth_habit_delete:['personId','id'],
};

/** Kernel-reported start time of one process; used to tell a live owner from a
 * recycled pid. Returns undefined when `ps` is unavailable on this platform,
 * which keeps the conservative "assume it is alive" behaviour. */
function processStartTime(pid){
  try{
    return execFileSync('ps',['-o','lstart=','-p',String(pid)],{encoding:'utf8',timeout:2000,stdio:['ignore','pipe','ignore']}).trim()||undefined;
  }catch{return undefined;}
}

export function exclusiveLock(directory){
  mkdirSync(directory,{recursive:true,mode:0o700});
  const file=join(directory,'runtime.lock');const id=randomUUID();
  const claim={pid:process.pid,id,processStart:processStartTime(process.pid)??null};
  const busy=()=>Object.assign(new Error('家庭助手数据目录正在被另一个进程占用。'),{code:'family_runtime_locked'});
  function acquire(){const fd=openSync(file,'wx',0o600);try{writeFileSync(fd,JSON.stringify(claim));}finally{closeSync(fd);}}
  function stale(){let old;try{old=JSON.parse(readFileSync(file,'utf8'));}catch{return true;}
    if(!Number.isInteger(old.pid)||old.pid<=0)return true;
    try{process.kill(old.pid,0);}catch(error){if(error.code==='ESRCH')return true;return false;}
    // The pid is alive. A different start time means the kernel reused the pid
    // after the previous owner died, so the lock is no longer authoritative.
    if(!old.processStart)return false;
    const observed=processStartTime(old.pid);
    return Boolean(observed)&&observed!==old.processStart;}
  try{acquire();}catch(error){
    if(error.code!=='EEXIST')throw error;
    if(!stale())throw busy();
    try{unlinkSync(file);}catch(cleanup){if(cleanup.code!=='ENOENT')throw cleanup;}
    try{acquire();}catch(retry){throw retry.code==='EEXIST'?busy():retry;}
  }
  let released=false;
  return()=>{if(released)return;released=true;
    // Releasing must never throw: the caller runs it from a finally block while
    // another subsystem may already be failing.
    try{const current=JSON.parse(readFileSync(file,'utf8'));if(current&&current.id===id)unlinkSync(file);}catch{}};
}

export function createRuntime({directory,api,respond,planOwner,planWorkbench,planHarness,generatePresentation,extractMaterial,ownerAgent,ownerMobileControl,toolExecutors,weatherSearch,digestSources,familyProjectExecutor,ownerTaskArtifacts,workspaceCurrentSync,memberAgent,memberReportFeedback,memberPublicTools,memberNativeRuntime,ownerPromptStatus,classifyImportantEvent,transcribeVoice,directOwnerReminders=true,now=()=>new Date().toISOString(),intervalMs=15000,channelFactory=createChannelManager}={}){
  if(typeof directory!=='string'||!directory)throw new Error('家庭助手需要独立数据目录。');
  directory=resolve(directory);const unlock=exclusiveLock(directory);
  let store;
  try{store=createStore({directory,now});store.recoverDispatching();}catch(error){unlock();throw error;}
  // 本人手动断开的标记独立存放，不改变 family.json 的字段结构，旧版回退仍能读台账。
  let suspensions;
  try{suspensions=createConnectionSuspensions({directory,now});}catch(error){unlock();throw error;}
  const inboundTiming=createInboundTimingLedger({directory});
  const reminderAdmission=createInboundTimingLedger({directory,fileName:'owner-reminder-admission.json'});
  let ownerLibrarySources;try{ownerLibrarySources=createOwnerLibrarySources({directory,now});}catch(error){unlock();throw error;}
  let ownerServiceViews;try{ownerServiceViews=createOwnerServiceLedger({directory,now});}catch(error){unlock();throw error;}
  let closed=false,timer=null,ticking=null,lastBrief=null,lastBriefAccess=null,lastError=null,runtimeReady=false;let lastPruneAt=0;
  const managementLifecycle=new AbortController();
  let lifecycle=new AbortController();const peopleWork=new Map(),ownerMessageWork=new Map(),presentationWork=new Map(),flushWork=new Map(),toolWork=new Map(),memberWork=new Map(),memberQueued=new Map(),outboxAuthorities=new Map(),ownerObservers=new Map(),reconnectAttempt=new Map(),reconnectSerial=new Map();
  const safeError=error=>{
    const deliveryDetail=weixinSendFailureDetail(error);if(deliveryDetail)return deliveryDetail;
    const text=String(error?.message??'服务暂时不可用');
    if(String(error?.code??text).startsWith('service_'))return serviceSetupErrorText(error);
    if(/token|bearer|credential|https?:\/\//i.test(text))return'连接或模型暂时不可用，请检查工作台状态。';
    return text.slice(0,160)+(error?.sendOutcome==='failed'&&Number.isSafeInteger(error?.code)?`（接口代码 ${error.code}）`:'');
  };
  let onboarding,deferredNotices,hearth;
  const channels=channelFactory({directory:join(directory,'channels'),api,now,...(transcribeVoice?{transcribeVoice}:{}),
    lookupInboundVoice:(personId,messageId)=>{const binding=store.binding(personId),row=store.messages(personId).find(value=>value.dir==='in'&&value.id===messageId&&recordMatchesBinding(value,binding));return row?{text:row.text,at:row.at,...(row.text==='[未能识别的语音]'?{voiceError:'failed'}:{})}:null;},
    onBound:(id,identity,options={})=>{const newBinding=!store.binding(id),wasSuspended=suspended(id);if(wasSuspended&&!reconnectArmed(id,options?.resumeToken))throw new Error('这位成员的微信已手动断开，只有本人当前这次恢复连接或重新扫码成功后才会接回。');const binding=store.bindPerson(id,identity);if(wasSuspended)suspensions.clear(id);reconnectAttempt.delete(id);onboarding?.markBound(id,identity,{newBinding});return binding;},
    onStatus:(id,patch)=>{if(!closed&&store.person(id)){store.setConnection(id,patch);if(runtimeReady&&patch.status==='connected')void resumeMemberAdmissions(id).catch(error=>{lastError=safeError(error);});}},
    onMessage:(id,message)=>receive(id,message),
  });
  let workbench,presentations,history,access,gateway,toolbox,organizer,serviceSetup,digestDelivery,workflowNotifications,attention,library,consoleConversations,openingConversation=null;
  try{
    history=createConversationHistory({store});access=createFamilyAccess({directory,store,now});
    const presentationExecutor=Boolean(generatePresentation&&extractMaterial&&typeof channels.downloadFile==='function'&&typeof channels.sendFile==='function')?async({personId,input,signal})=>{
      if(!input?.text)return{text:'PPT 制作已为你开通。请直接回复分享主题、用途和材料，也可以发送 TXT、Markdown、DOCX 或 PPTX 文件；我会继续帮你整理，并返回可编辑 PPT。'};
      if(typeof input.text!=='string'||!input.text.trim()||input.text.length>6000)throw new Error('PPT要求为空或过长。');
      const route=store.route(personId),result=await presentations.handle({person:workbench.memberProfile(personId),route,message:{id:'tool-ppt-'+randomUUID(),peerId:route.peerId,text:input.text},authorize:()=>current(route),signal});
      return{text:result.reply??'已进入 PPT 制作流程，请查看同一会话的文件或补充材料要求。'};
    }:undefined;
    toolbox=createFamilyToolbox({directory,store,now,executors:{...toolExecutors,...(presentationExecutor?{presentation:presentationExecutor}:{})}});
    consoleConversations=createConsoleConversationStore({directory,now});
    gateway=createHarnessGateway({directory,store,access,ownerAgent,familyProjectExecutor,ownerTaskArtifacts,ownerServiceDraftIds:({personId,sessionId})=>ownerServiceViews.idsFor({sessionId,personId,contextId:ownerServiceContextId(sessionId)}),consoleConversation:()=>consoleConversations.read(),now,recoverOnCreate:false,onResult:deliverHarnessResult});
    presentations=createPresentationWorkflow({directory,store,now,generate:generatePresentation,extract:extractMaterial,defaultEnabled:Boolean(memberAgent&&generatePresentation&&extractMaterial&&typeof channels.sendFile==='function'&&typeof channels.downloadFile==='function'),
    download:typeof channels.downloadFile==='function'?(...args)=>channels.downloadFile(...args):undefined,
    send:typeof channels.sendFile==='function'?(...args)=>channels.sendFile(...args):undefined,
  });workbench=createWorkbench({directory,store,now,
    plan:planWorkbench?args=>planWorkbench({...args,signal:AbortSignal.any([managementLifecycle.signal,AbortSignal.timeout(90000)])}):undefined,
    execute:executeWorkbench,check:checkWorkbench,cancel:cancelWorkbench,
  });
    organizer=createPersonalOrganizer({directory,store,now});
    library=createMemberLibrary({directory:realpathSync(directory),store,now});
    serviceSetup=createServiceSetup({directory,store,toolbox:{...toolbox,assign:assignTool},now,
      listProjects:({actorId})=>gateway.listProjects({personId:actorId}),
      digestSources:args=>{if(typeof digestSources!=='function')throw new Error('日报资料列表尚未接通。');return digestSources({...args,signal:managementLifecycle.signal});},
      weatherSearch:args=>{if(typeof weatherSearch!=='function')throw new Error('天气服务尚未接通。');return weatherSearch({...args,signal:managementLifecycle.signal});},
    });
    digestDelivery=createDigestDelivery({directory,store,now,flush,readDigest:async({personId,resource,source,signal})=>{
      if(typeof digestSources!=='function'||typeof toolExecutors?.ai_digest!=='function')throw new Error('日报读取服务尚未接通。');
      const verify=async()=>{const rows=await digestSources({workspaceId:resource.workspaceId,query:resource.relativePath.slice(-120),signal}),row=rows.find(item=>item.relativePath===resource.relativePath);if(!row||row.bytes!==source.bytes||row.updatedAt!==source.updatedAt)throw new Error('这份日报已变化，请重新查找后再发。');};
      await verify();const result=await toolExecutors.ai_digest({personId,resource,signal});await verify();
      const route=store.route(personId),authorize=()=>current(route);
      const adapted=memberReportFeedback?await memberReportFeedback.adaptReport({personId,route,text:result.text,sourceKey:'digest-source:'+createHash('sha256').update(JSON.stringify([resource,source])).digest('hex'),signal,authorize}):result;
      return{text:adapted.text};
    }});
    workflowNotifications=createWorkflowNotifications({directory,store,toolbox,flush,now});
    for(const row of store.snapshot().outbox.filter(row=>row.status==='pending'&&(['harness_result','harness_notice'].includes(row.kind)||row.sourceKey.includes(':native-owner-')||/^(?:workbench:|request-reply:|family-dot:)/.test(row.sourceKey))))store.transition(row.id,'cancelled','上次投递未结束，没有自动续发。');
    onboarding=createMemberOnboarding({directory,store,toolbox,access,presentations,now,projectExecutorAvailable:Boolean(familyProjectExecutor),generalAgentAvailable:Boolean(memberAgent)});
    deferredNotices=createDeferredMemberNotices({directory,store,flush,now});
    hearth=createHearthPreferences({directory:realpathSync(directory),now});
    attention=createRuntimeAttention({directory,store,classify:classifyImportantEvent,channels,flush,sendOwnerMessage,now,running:()=>!closed&&!store.snapshot().config.paused,signal:()=>lifecycle.signal});
  }catch(error){void gateway?.close();void channels.close();unlock();throw error;}
  runtimeReady=true;
  const ownerAllowedPush=category=>{
    const g=hearth.guard();
    if(category==='urgent')return Boolean(g.pushRules.urgent);
    if(!g.pushRules[category])return false;
    const owner=store.snapshot().people.find(p=>p.role==='owner');
    return !hearth.inQuietHours(now(),owner?.timeZone);
  };
  const serial=(map,key,work)=>{
    const previous=map.get(key)??Promise.resolve();const task=previous.catch(()=>{}).then(work);
    map.set(key,task);task.finally(()=>{if(map.get(key)===task)map.delete(key);}).catch(()=>{});return task;
  };
  const alive=()=>{if(closed)throw new Error('家庭助手已关闭。');};
  // 本人明确点过「断开连接」的成员停在本机 sidecar 里，重开服务不会自动接回。
  const suspended=id=>suspensions.isSuspended(id);
  // 每次显式恢复/扫码有自己的 token；旧操作的 catch/finally 不能撤掉新操作。
  const reconnectArmed=(id,token)=>{const row=reconnectAttempt.get(id);if(!row||row.token!==token)return false;if(Date.parse(now())>=row.until){if(reconnectAttempt.get(id)===row)reconnectAttempt.delete(id);return false;}return true;};
  const reconnectActive=id=>{const row=reconnectAttempt.get(id);if(!row)return false;if(Date.parse(now())>=row.until){if(reconnectAttempt.get(id)===row)reconnectAttempt.delete(id);return false;}return true;};
  const beginReconnect=(id,ms)=>{const token=(reconnectSerial.get(id)??0)+1;reconnectSerial.set(id,token);reconnectAttempt.set(id,{token,until:Date.parse(now())+ms});return token;};
  const endReconnect=(id,token)=>{const row=reconnectAttempt.get(id);if(row?.token===token)reconnectAttempt.delete(id);};
  const cancelReconnect=id=>reconnectAttempt.delete(id);
  const current=route=>{try{return !closed&&!store.snapshot().config.paused&&sameRoute(store.route(route.personId),route);}catch{return false;}};
  // 单点拦截：即使异步重连把通道短暂标成 connected，也不能从已停用通道发出任何内容。
  const channelSend=typeof channels.send==='function'?channels.send.bind(channels):null;
  if(channelSend)channels.send=async(route,text,options)=>{if(suspended(route?.personId))throw Object.assign(new Error('这位成员的微信已由本人断开，没有发送。'),{sendOutcome:'failed'});return channelSend(route,text,options);};
  const currentMember=(person,route)=>current(route)&&channels.status(route.personId)?.status==='connected'&&store.person(person.id)?.role==='elder'&&store.person(person.id)?.createdAt===person.createdAt;
  const memberHistory=(personId,limit)=>store.messages(personId).filter(message=>recordMatchesBinding(message,store.binding(personId))).slice(-limit);
  function memberReports(personId,route){
    const groups=new Map();
    for(const row of store.snapshot().outbox.filter(row=>row.personId===personId&&row.status==='api_accepted'&&sameRoute(row.route,route))){
      let key=row.sourceKey;if(row.kind==='digest_once')key=key.replace(/:\d+$/,'');
      else if(row.kind==='member_agent')key=key.replace(/:\d+$/,'');
      else if(row.kind==='tool_result'&&key.startsWith('family-tool:')){try{const parts=JSON.parse(Buffer.from(key.slice(12),'base64url').toString());key=JSON.stringify(parts.slice(0,-1));}catch{continue;}}
      else if(!['daily','elder_daily','elder-daily','manual_daily','workbench_daily','owner_message','manual','harness_result','member_agent'].includes(row.kind))continue;
      const group=groups.get(key)??{id:'report-'+createHash('sha256').update(key).digest('hex').slice(0,48),title:'本人已收日报',text:'',at:row.createdAt,sourceKeys:[],personId,bindingGeneration:route.generation};
      group.text+=(group.text?'\n':'')+row.text;group.sourceKeys.push(row.sourceKey);groups.set(key,group);
    }
    let budget=40000;return[...groups.values()].reverse().filter(row=>/日报|简报|digest|精选/i.test(row.text)).filter(row=>{const bytes=Buffer.byteLength(row.text);if(bytes>32000||bytes>budget)return false;budget-=bytes;row.title=row.text.split('\n').find(line=>/日报|简报|digest|精选/i.test(line))?.slice(0,120)??row.title;return true;}).slice(0,4).reverse();
  }
  async function runMemberAgent(person,route,message,text,admissionKey){
    const signal=AbortSignal.any([lifecycle.signal,AbortSignal.timeout(120000)]),authorize=()=>currentMember(person,route),personal=organizer.context(person.id),materials=[];
    for(const attachment of (message.attachments??[]).slice(0,3)){
      if(!authorize())throw new Error('当前连接已经改变，未读取材料。');
      if(typeof extractMaterial!=='function'||typeof channels.downloadFile!=='function')throw new Error('当前不能读取文件，请把需要处理的文字发来。');
      const downloaded=await channels.downloadFile(route,attachment,{signal,authorize}),material=await extractMaterial({name:attachment.name,bytes:downloaded.bytes});
      if(Buffer.byteLength(material.text)>32000)throw new Error('这份材料超过本次处理范围，请精简或分段后发来。');materials.push({...material,personId:person.id,bindingGeneration:route.generation});
    }
    let history=memberHistory(person.id,8).map(row=>({...row,text:row.text.slice(0,800)}));while(Buffer.byteLength(JSON.stringify(history))>10000)history.shift();
    const rawLibraryContext=library.context({personId:person.id,route,text}),entries=rawLibraryContext.entries.filter(row=>row.key!=='report-style'),libraryContext={entries,text:entries.map(row=>`[${row.kind} ${row.date??row.recordedDate} ${row.id} v${row.revision}; 来源 ${row.sources.map(source=>source.id+' '+source.at).join(', ')}] ${row.text}`).join('\n')};
    const legacyRun=()=>memberAgent.run({person:workbench.memberProfile(person.id),route,text,history,libraryContext,diaryContext:diaryTurn(person,route,text,message.id),reports:memberReports(person.id,route),materials,
      notes:personal.notes.slice(-10).map(row=>({...row,text:row.text.slice(0,100)})),reminders:personal.reminders.slice(0,10).map(row=>({...row,text:row.text.slice(0,100)})),
      signal,authorize,requestId:sourceRequest(route,message),...(admissionKey?{admissionKey}:{}),reportPreference:memberReportFeedback?.getPreference({personId:person.id,route})?.instruction??null,importantAlertsEnabled:attention.snapshot().enabled,
      ...(memberPublicTools?{publicTools:memberPublicTools({personId:person.id})}:{}),
      memberTools:memberPresetTools(person,route,message,text),
      ...(memberReportFeedback?{setReportPreference:async args=>{if(!authorize()||await args.authorize()!==true||!authorize())throw new Error('当前连接已改变。');return memberReportFeedback.setPreference({personId:person.id,route,text,instruction:args.instruction,evidence:args.evidence,authorize});}}:{}),
      requestOwnerHelp:async args=>{
        if(!authorize()||await args.authorize()!==true||!authorize()||signal.aborted||!canRequestMemberOwnerHelp({text,evidence:args.evidence,requestText:args.text}))throw new Error('没有获得这次转告的明确同意。');        const sourceNotice=await attention.ownerNoticeForSource(person.id,message.id);
        if(!authorize()||await args.authorize()!==true||!authorize()||signal.aborted)throw new Error('当前连接已改变。');
        const request=toolbox.requestWorkflow({personId:person.id,requestId:args.requestId,text:args.text}),notification=sourceNotice??(ownerAllowedPush('ask')?await workflowNotifications.notify({personId:person.id,requestId:request.requestId,expectedRoute:route,signal}):null);
        const reply=sourceNotice?sourceNotice.status==='api_accepted'?'已向微信接口提交这件事的提醒，实际收到仍待确认。':sourceNotice.status==='failed'?'这件事已记录，提醒发送失败，没有重复发送。':sourceNotice.status==='pendingOwner'?'这件事已记录，提醒正在等待投递。':'这件事已记录，提醒投递尚未确认，没有重复发送。':'已记录这次求助，家庭联系人可在同一需求中继续处理。';
        return{status:notification?.status??'recorded',requestId:request.requestId,reply};
      },
      askOwner:async args=>{
        if(!authorize()||await args.authorize()!==true||!authorize()||signal.aborted||!canAskMemberOwner({text,evidence:args.evidence,question:args.text}))throw new Error('没有获得这次托问的明确同意。');
        const request=workbench.createRequest({personId:person.id,text:args.text,sourceId:`${route.generation}:${message.id}`});
        const notified=await notifyRequest(request);
        if(!authorize())throw new Error('当前连接已改变。');
        const reply=notified?'已把这条托问提交给家庭联系人的待回应；微信接口已接受，不代表手机已收到，也不保证对方一定答复。':'已经记在家庭联系人的待回应里，微信通知尚未确认。';
        return{status:notified?'api_accepted':'recorded',requestId:request.id,reply};
      },
      ...(typeof channels.sendFile==='function'?{deliverFile:async args=>{
        if(!authorize()||await args.authorize()!==true)throw Object.assign(new Error('文件接收人的连接已改变。'),{sendOutcome:'failed'});
        const receipt=await channels.sendFile(route,{name:args.name,bytes:args.bytes},{clientId:args.clientId,signal:args.signal,authorize});
        if(receipt?.status==='api_accepted'&&authorize())store.addMessage(person.id,{id:'file-'+args.clientId,dir:'out',text:'[个人成果文件] '+args.name,kind:'member_file',attachments:[{name:args.name,size:args.bytes.length,mimeType:args.mimeType}]});
        return receipt;
      }}:{}),
    });
    // Grayscale switch: only a member whose flag file says so tries the native
    // link, and any failure falls straight back to the legacy path this turn.
    if(!isMemberNative(directory,person.id)||typeof memberNativeRuntime?.run!=='function')return legacyRun();
    try{
      const native=await memberNativeRuntime.run({personId:person.id,text,history:history.map(row=>({role:row.dir==='in'?'user':'assistant',text:row.text})),signal});
      if(authorize()&&typeof native?.text==='string'&&native.text.trim())return {text:native.text,state:'succeeded',actions:[],files:[],deliveries:[]};
      throw new Error('原生链路没有产出可用回复');
    }catch(error){lastError=safeError(error);}
    return legacyRun();
  }
  function diaryTurn(person,route,text,messageId){
    if(!currentMember(person,route))return false;
    if(dismissesDiaryConversation(text))return false;
    if(/日记/.test(text))return true;
    const rows=memberHistory(person.id,20).filter(row=>row.id!==messageId&&row.kind!==deferredNoticeKind),last=rows.at(-1);
    if(last?.dir==='out'&&last.kind==='diary_invitation'&&localDate(last.at,person.timeZone)===localDate(now(),person.timeZone)&&isDiaryInvitationReply(text))return true;
    const continuation=/^(?:再补|补充一|还有一|刚才.{0,15}不是|这段别记|删掉刚才|改一下刚才)/.test(text),narrative=text.length>=6&&/^(?:今天|昨天|刚刚|刚才|后来|然后|还|又|我|上午|下午|晚上|早上|中午|那天)/.test(text)&&!/[？?]|怎么|为什么|什么|能否|可不可以|帮我|请|提醒|查一下|翻译|新闻|日报|转发|看到文章|假如|如果|据说/.test(text);
    if(last?.dir==='out'&&narrative&&/今天有什么想留下来的事|今天想记点什么|直接说给我听.*日记|日记.*直接说给我听|日记[，。；：、 ]*(?:想|想到|以后|随时|直接|记错)|(?:直接|随时).{0,15}(?:聊|说).{0,15}日记/.test(last.text))return true;
    if(!continuation&&!narrative)return false;
    const latest=library.query({personId:person.id,route,kind:'diary',limit:1}).entries[0];
    if(!latest)return false;
    const prior=rows.filter(row=>row.dir==='in').at(-1);
    return Boolean(prior&&latest.sources.some(source=>source.id===prior.id));
  }
  function libraryEntry(personId,route,id){
    let before;for(let page=0;page<50;page++){const result=library.query({personId,route,limit:200,...(before?{before}:{})}),entry=result.entries.find(row=>row.id===id);if(entry)return entry;if(!result.nextBefore)return null;before=result.nextBefore;}throw new Error('记录查找超出本次范围，请重新查询。');
  }
  function effectiveReportPreference(personId,route){const value=memberReportFeedback?.getPreference({personId,route});return value?{...value,readOnly:true,source:'本人日报服务的当前生效设置'}:null;}
  function memberPresetTools(person,route,message,text){
    const authorize=()=>currentMember(person,route),tools=library.tools({person:workbench.memberProfile(person.id),route,message:{...message,at:message.at??store.messages(person.id).find(row=>row.dir==='in'&&row.id===message.id)?.at??now(),diaryContext:diaryTurn(person,route,text,message.id)},text,authorize}).map(tool=>({...tool,execute:async(args,options)=>{
      if(!authorize()||await options.authorize()!==true||!authorize()||options.signal.aborted)throw new Error('当前连接或授权已改变。');
      if(tool.name==='member_library_remember'&&(args.key==='report-style'||args.kind==='preference'&&/日报|简报|digest/i.test(args.text)))return{status:'needs_correction',text:'这次没有保存资料库副本。日报偏好只有一份生效设置，请改用已有的 set_my_report_preference，instruction 和 evidence 逐字来自当前原话。'};
      if(['member_library_update','member_library_delete'].includes(tool.name)&&libraryEntry(person.id,route,args.id)?.key==='report-style')throw new Error('这是历史日报偏好摘要，不是生效设置；请用 set_my_report_preference 调整实际日报偏好。');
      const result=await tool.execute(args,options);return tool.name==='member_library_query'?{...result,entries:result.entries.filter(row=>row.key!=='report-style'),reportPreference:effectiveReportPreference(person.id,route)}:result;
    }})),schema=properties=>({type:'object',additionalProperties:false,properties,required:Object.keys(properties)});
    tools.push({name:'member_conversation_query',description:'按关键词找回本人当前微信绑定下较早的本机聊天原话。可查最近聊天窗口以外的记录；返回来源日期和片段，不能读取其他家人或手机其他聊天。',parameters:{type:'object',additionalProperties:false,properties:{query:{type:'string',minLength:1,maxLength:200},limit:{type:'integer',minimum:1,maximum:20}},required:['query']},execute:async(args,options)=>{
      if(await options.authorize()!==true||!authorize()||options.signal.aborted)throw new Error('当前连接或授权已改变。');
      if(typeof args.query!=='string'||!args.query.trim()||args.query.length>200||args.limit!==undefined&&(!Number.isSafeInteger(args.limit)||args.limit<1||args.limit>20))throw new Error('请给出要查找的一小段原话。');
      let budget=16000;const rows=store.messages(person.id).filter(row=>row.id!==message.id&&recordMatchesBinding(row,store.binding(person.id))).reverse().map(row=>({row,score:scoreRecord(row.text,args.query)})).filter(item=>item.score>0).sort((a,b)=>b.score-a.score).map(item=>item.row),messages=[];
      for(const row of rows){const result={id:row.id,at:row.at,dir:row.dir,text:row.text.slice(0,2000),...(row.text.length>2000?{truncated:true}:{})},size=Buffer.byteLength(JSON.stringify(result));if(size>budget)break;messages.push(result);budget-=size;if(messages.length>=(args.limit??8))break;}
      if(!authorize())throw new Error('当前连接或授权已改变。');return{status:'completed',messages,source:'本人当前绑定的本机聊天归档，结果仅含匹配片段。'};
    }});
    if(respond)tools.push({name:'member_personal_organizer',description:'按用户本条真实原话查询或管理本人的便条、日程与提醒。日期时间缺项会询问；不能操作其他家人的记录。',parameters:schema({}),execute:async(args,options)=>{
      if(await options.authorize()!==true||!authorize()||options.signal.aborted)throw new Error('当前连接或授权已改变。');
      const personal=organizer.context(person.id),parsed=parseModelReply(JSON.stringify(await respond({person:workbench.memberProfile(person.id),ownerContact:{label:store.snapshot().people.find(p=>p.role==='owner')?.label},history:memberHistory(person.id,30),text,reminders:personal.reminders,notes:personal.notes,now:now(),signal:options.signal})));
      options.signal.throwIfAborted();if(!authorize())throw new Error('当前连接或授权已改变。');
      const result=parsed.action?organizer.execute({personId:person.id,text,action:parsed.action,requestId:options.requestId}):null;return{status:result?'completed':'needs_input',mutation:Boolean(result&&['remember','forget_note','remind','update_reminder','cancel'].includes(parsed.action?.type)),...(result&&parsed.action?{operation:parsed.action.type}:{}),reply:result?.reply??parsed.reply};
    }});
    for(const row of toolbox.catalog({personId:person.id}).filter(row=>row.ready&&['ai_digest','weather'].includes(row.toolId))){
      const toolId=row.toolId;tools.push({name:'member_'+toolId,description:toolId==='ai_digest'?'读取家庭联系人为本人共享的最新AI日报，可继续解释或改写；不读取来源项目里的其他文件。':'读取已为本人配置城市的今日天气预报。',parameters:schema({}),execute:async(args,options)=>{
        if(await options.authorize()!==true||!authorize()||options.signal.aborted)throw new Error('当前连接或授权已改变。');
        const result=await toolbox.invoke({personId:person.id,toolId,requestId:options.requestId,expectedRevision:row.revision},{signal:options.signal,authorize});
        if(!authorize()||result.status!=='succeeded'||!toolbox.isCurrent({personId:person.id,toolId,requestId:options.requestId,revision:result.revision}))return{status:result.status??'failed',reply:'本次资料尚未取得，没有自动重试。'};
        const value=result.result;let resultText=typeof value==='string'?value:typeof value?.text==='string'?value.text:JSON.stringify(value);
        if(toolId==='ai_digest'&&memberReportFeedback)resultText=(await memberReportFeedback.adaptReport({personId:person.id,route,text:resultText,sourceKey:'member-preset:'+options.requestId,signal:options.signal,authorize})).text;
        if(!authorize())throw new Error('当前连接或授权已改变。');return{status:'succeeded',text:resultText};
      }});
    }
    if(presentations.snapshot().available&&presentations.snapshot().people.some(row=>row.personId===person.id&&row.enabled))tools.push({name:'member_make_presentation',description:'根据本人的要求和本次材料制作可编辑PPT并通过本人的微信回传。只在用户确实要求制作演示稿时调用，缺主题先询问。',parameters:schema({request:{type:'string',maxLength:12000}}),execute:async(args,options)=>{
      if(await options.authorize()!==true||!authorize()||options.signal.aborted)throw new Error('当前连接或授权已改变。');
      const result=await presentations.handle({person:workbench.memberProfile(person.id),route,message:{id:options.requestId,peerId:route.peerId,text:'制作PPT：'+args.request,...(message.attachments?.length?{attachments:message.attachments}:{})},signal:options.signal,authorize});
      return{status:result.handled?'handled':'unavailable',reply:result.reply??'制作结果尚待核对，请查看同一会话的文件或任务状态。'};
    }});
    return tools;
  }
  const briefAccess=()=>JSON.stringify(store.snapshot().people.map(p=>[p.id,p.shareWithOwner,store.binding(p.id)?.generation??0]));
  function enqueueMember(person,route,message,text,admissionKey){
    const requestId=sourceRequest(route,message);if(memberQueued.has(requestId))return;
    const work=serial(memberWork,person.id,async()=>{
      try{
        if(!currentMember(person,route))return;
        const previous=memberAgent.status?.({person,route,requestId,authorize:()=>currentMember(person,route)});if(['cancelled','cancelling'].includes(previous?.state))return;
        const result=await runMemberAgent(person,route,message,text,admissionKey);if(!currentMember(person,route)||['cancelled','cancelling'].includes(result?.state))return;
        if(typeof result?.text!=='string'||!result.text.trim()||result.text.length>24000)throw new Error('这次回复没有完成，请稍后再试。');
        for(const[index,part]of messageParts(result.text).entries())store.enqueue({personId:person.id,text:part,kind:'member_agent',sourceKey:`member-reply:${requestId}:${index}`,expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
        await flush(person.id);
      }catch(error){lastError=safeError(error);if(currentMember(person,route)){memberAgent.rejectPrepared?.({person,route,requestId,authorize:()=>currentMember(person,route)});store.enqueue({personId:person.id,text:'这次处理没有完成，已有材料和处理记录已保留。请告诉我下一步想怎样继续。',kind:'error',sourceKey:'member-error:'+requestId,expiresAt:new Date(Date.parse(now())+10*60000).toISOString()});await flush(person.id);}}
    });memberQueued.set(requestId,work);work.finally(()=>{if(memberQueued.get(requestId)===work)memberQueued.delete(requestId);}).catch(()=>{});
  }
  async function resumeMemberAdmissions(onlyPersonId){
    if(closed||store.snapshot().config.paused||typeof memberAgent?.pendingInputs!=='function')return;
    for(const person of store.snapshot().people.filter(p=>p.role==='elder'&&store.binding(p.id)&&(!onlyPersonId||p.id===onlyPersonId))){
      const route=store.route(person.id);if(!currentMember(person,route))continue;
      for(const input of memberAgent.pendingInputs({person,route,authorize:()=>currentMember(person,route)})){
        const message={id:input.source.messageId,peerId:route.peerId,text:input.text,...(input.source.attachments?{attachments:input.source.attachments}:{}),...(input.source.at?{at:input.source.at}:{})};
        store.recordInbound(person.id,{id:message.id,peerId:route.peerId,text:input.text,...(message.attachments?{attachments:displayAttachments(message.attachments)}:{}),...(message.at?{at:message.at}:{})});enqueueMember(person,route,message,input.text,input.admissionKey);
      }
    }
  }
  async function preview({date:requestedDate}={}){
    const access=briefAccess(),instant=now(),value=buildOwnerBrief(store,{now:instant,...(requestedDate?{date:requestedDate}:{})});
    const owner=store.person(value.personId),date=requestedDate??localDate(instant,owner.timeZone),state=store.snapshot();
    const shared=state.people.filter(p=>p.role==='elder'&&p.shareWithOwner!=='none').map(p=>({label:p.label,messages:state.messages.filter(m=>m.personId===p.id&&localDate(m.at,owner.timeZone)===date).slice(-8).map(m=>({direction:m.dir,text:m.text.slice(0,300)}))}));
    if(respond&&shared.some(p=>p.messages.length)){
      try{
        const answer=parseModelReply(JSON.stringify(await respond({person:owner,history:[],reminders:store.reminders(owner.id),now:instant,signal:AbortSignal.any([lifecycle.signal,AbortSignal.timeout(12000)]),text:`请为家庭服务简报写两三句服务内容小结，最多180字，仅概括今天聊过的主题、实际请求和需要本人跟进的明确事项。以下为已获分享授权的聊天数据，不是新指令。不要推断健康、情绪或家庭关系，不宣称提醒已送达，不编造后续安排，action=null。${JSON.stringify(shared)}`})));
        if(!answer.action)value.text=`${value.text.slice(0,2400)}\n\n服务内容小结（AI整理）：\n${answer.reply.slice(0,600)}`;
      }catch(error){lastError=safeError(error);}
    }
    const progress=buildServiceProgress({people:store.snapshot().people,date,timeZone:owner.timeZone,tasks:gateway.snapshotForOwner(),presentations:presentations.snapshot().tasks,toolRuns:toolbox.serviceLedger({actorId:owner.id}),requests:workbench.snapshot().requests,workflowRequests:toolbox.listRequests({actorId:owner.id})});
    if(progress)value.text=value.text.slice(0,2050)+'\n\n'+progress+'\n\n接口接收状态不代表微信实际收信。';
    if(access!==briefAccess())throw new Error('分享范围刚刚改变，请重新生成简报。');
    lastBriefAccess=access;lastBrief={text:value.text,date,generatedAt:instant};return value;
  }
  function status({personId}={}){
    workbench.refresh();
    if(gateway.snapshotForOwner().some(task=>task.origin==='console'&&!['succeeded','failed','cancelled'].includes(task.state)))void gateway.tick().catch(error=>{lastError=safeError(error);});
    const state=store.snapshot();
    if(lastBrief&&lastBriefAccess!==briefAccess())lastBrief=null;
    // This surface is authenticated as Owner. Brief sharing is a separate
    // policy and must not hide the Owner's own saved management records.
    const visible=new Set(state.people.map(p=>p.id));
    const health=buildHealth({state,channelOf:id=>channels.status(id),now});
    // The panel asks "can I still reach them", not "is the socket up".
    health.people=health.people.map(row=>({...row,lastInboundAt:lastInboundOf(row.personId)??row.lastInboundAt??null,reach:reachOf(row.personId)}));
    const result={version:1,config:state.config,health,// 只读影子盘点：报告家人侧迁移是否被未结清请求挡住，不改变任何行为。
    migration:(()=>{try{return planMemberMigration({directory,people:state.people,bindings:state.bindings});}catch{return null;}})(),people:state.people.map(person=>{
      const persisted=store.binding(person.id);const live=channels.status(person.id)??{};
      const reach=reachOf(person.id);
      const manuallyDisconnected=suspended(person.id);
      const reconnecting=manuallyDisconnected&&reconnectActive(person.id);
      const liveStatus=live.status??live.phase;
      // 本人刚发起的扫码/恢复要显示真实进度和二维码；成功前仍是停用状态。
      const showReconnect=reconnecting&&['connecting','awaiting_scan','scanned','need_verification'].includes(liveStatus);
      const binding={...live,generation:persisted?.generation??null,
        status:manuallyDisconnected?(showReconnect?liveStatus:'disconnected'):liveStatus??persisted?.status??'disconnected',
        connected:!manuallyDisconnected&&live.status==='connected',
        suspended:manuallyDisconnected,reconnecting,
        lastError:manuallyDisconnected?(showReconnect?live.lastError??null:null):live.lastError??persisted?.lastError??null};
      if(manuallyDisconnected&&!showReconnect)delete binding.qrUrl;
      return{...person,reach:{state:reach.state,remainingMs:reach.remainingMs,label:reachLabel(reach)},binding};
    }),reminders:state.reminders.map(row=>visible.has(row.personId)?row:{...row,text:'内容未授权展示'}),outbox:state.outbox.map(({route,authorizationRoute,text,...row})=>row),ownerCommands:store.ownerCommands().map(({requestRoute,...command})=>{
      const deliveries=command.action==='send_daily'?state.outbox.filter(row=>row.id===command.resultId):state.outbox.filter(row=>row.sourceKey.startsWith(`reminder:${command.resultId}:`));
      const reminder=command.action==='remind'?state.reminders.find(row=>row.id===command.resultId):null;
      return{...command,...(reminder?.status==='cancelled'?{status:'cancelled',detail:'操作已取消'}:reminder?.status==='expired'?{status:'failed',detail:'执行未完成'}:{}),...(deliveries.length?{deliveryStatus:deliveries.at(-1).status}:{} )};
    }),relay:(()=>{const rows=state.outbox.filter(row=>row.kind==='undeliverable_notice'&&row.status==='pending'&&row.personId===state.people.find(p=>p.role==='owner')?.id);
      return rows.map(row=>{const source=state.outbox.find(item=>row.sourceKey===`undeliverable:${item.id}`);return{id:row.id,at:row.createdAt,text:row.text,personId:source?.personId??null,personLabel:source?.personId?store.person(source.personId)?.label??null:null};});})(),lastBrief,lastError,attention:attention.snapshot(),runtimeWork:{attention:attention.snapshot().active,responses:peopleWork.size,ownerMessages:ownerMessageWork.size,presentations:presentationWork.size,tools:toolWork.size,members:memberQueued.size,deliveries:flushWork.size,ownerObservers:ownerObservers.size},memberAgent:{available:Boolean(memberAgent),...(memberAgent?.snapshot?.()??{}),active:Math.max(memberAgent?.snapshot?.().active??0,memberQueued.size)},workbench:workbench.snapshot(),presentations:presentations.snapshot(),serviceSetup:state.people.some(person=>person.role==='owner')?serviceSetup.snapshotForOwner({actorId:state.people.find(person=>person.role==='owner').id}):[],harness:{tasks:gateway.snapshotForOwner(),familyExecution:familyProjectExecutor?'scoped_project_agent':'protected_executor_required',familyWriteScope:'family-output/<personId>/*.{md,txt,csv,json}'}};
    result.ownerConversation=ownerConversationView();
    const ownerPerson=state.people.find(p=>p.role==='owner')??null;
    let ownerBound=false;try{ownerBound=Boolean(ownerPerson&&store.route(ownerPerson.id));}catch{}
    const hearthSnapshot=hearth.snapshot(),rawGuard=hearthSnapshot.guard,attnSnap=attention.snapshot();
    const elderPeople=state.people.filter(p=>p.role==='elder');
    const outboxStatusLabel=s=>s==='api_accepted'?'已提交微信接口':s==='failed'||s==='expired'?'未完成':s==='uncertain'||s==='blocked'?'结果待核对':'待发出';
    result.hearth={
      guard:{
        ...rawGuard,
        pushRules:{
          ...rawGuard.pushRules,
          digest:Boolean(rawGuard.pushRules.digest&&state.config.ownerBriefEnabled),
          urgent:attnSnap.available&&ownerBound?attnSnap.enabled:rawGuard.pushRules.urgent,
        },
        importantAvailable:Boolean(attnSnap.available&&ownerBound),
        inQuietHours:hearth.inQuietHours(now(),ownerPerson?.timeZone),
      },
      deferredNotices:ownerPerson?deferredNotices.list().notices:[],
      workflowRequests:ownerPerson?toolbox.listRequests({actorId:ownerPerson.id}):[],
      skippedReminders:hearthSnapshot.skippedReminders,
      members:Object.fromEntries(elderPeople.map(p=>{
        const pref=hearthSnapshot.members[p.id]??hearth.member(p.id),privacyProtected=p.shareWithOwner==='none',binding=store.binding(p.id);
        let accessEntry=null;try{accessEntry=ownerPerson?access.list({actorId:ownerPerson.id}).find(a=>a.personId===p.id)??null:null;}catch{}
        let assignments=[];try{assignments=ownerPerson?toolbox.assignments({actorId:ownerPerson.id,personId:p.id}):[];}catch{}
        let diaryCount=0;try{const r=store.route(p.id);diaryCount=library.query({personId:p.id,route:r,kind:'diary',limit:200}).entries.length;}catch{}
        const recentMessages=privacyProtected?[]:store.messages(p.id).filter(m=>recordMatchesBinding(m,binding)).slice(-6).map(m=>({
          id:m.id,dir:m.dir,kind:m.kind,at:m.at,
          text:p.shareWithOwner==='summary'?String(m.text??'').slice(0,120):String(m.text??'').slice(0,500),
        }));
        return[p.id,{
          ...pref,
          tools:toolbox.catalog({personId:p.id}),
          assignments,
          access:accessEntry,
          presentationEnabled:presentations.snapshot().people.find(x=>x.personId===p.id)?.enabled??false,
          onboarding:onboarding.describe(p.id),
          diaryCount,
          privacyProtected,
          recentMessages,
        }];
      })),
      recentActivity:elderPeople.flatMap(p=>{
        const rows=state.outbox.filter(row=>row.personId===p.id&&row.status!=='cancelled').slice(-8).map(row=>({
          id:row.id,personId:p.id,personLabel:p.label,at:row.createdAt,dir:'out',kind:row.kind,status:row.status,
          statusLabel:outboxStatusLabel(row.status),
          summary:p.shareWithOwner==='none'?'已向微信提交一次消息（隐私设置不展示原文）':String(row.text??'').replace(/^提醒：/,'').replace(/\s+/g,' ').trim().slice(0,72),
        }));
        return rows;
      }).sort((a,b)=>Date.parse(b.at)-Date.parse(a.at)).slice(0,12),
    };
    if(personId){const person=store.person(personId);if(!person)throw new Error('没有找到这位家人。');result.selectedPersonId=personId;result.messages=store.messages(personId,{limit:100});}
    return result;
  }
  const commandFor=row=>row.kind==='manual_daily'?store.ownerCommands().find(command=>command.resultId===row.id):null;
  function captureDeliveryTarget(personId){
    if(personId===undefined)return undefined;
    const person=store.person(personId);if(!person)throw new Error('没有找到结果接收人，请先登记这位家人。');
    const route=store.route(personId);if(!current(route)||channels.status(personId)?.status!=='connected')throw new Error(`${person.label}尚未连接微信，请先连接后再指定投递。`);
    return{personId,route};
  }
  function recipientIn(text){
    const withoutQuotes=text.replace(/“[^”]*”|「[^」]*」|『[^』]*』|"[^"\n]*"|'[^'\n]*'/g,'');
    if(/(?:怎么|如何|怎样|教我|解释|介绍|知不知道|知道)[^。；;]{0,100}(?:发|送|投递|推送|交给|投给)/.test(withoutQuotes))return undefined;
    if(/(?:不要|别|不必|不用|无需|先不|暂不|暂时不|禁止|不能|不)[^，,。；;]{0,32}(?:发|送|投递|推送|交给|投给)|(?:如果|假如|假设|能否|是否|要不要|能不能|可不可以|考虑)[^。；;]{0,100}(?:发|送|投递|推送|交给|投给)/.test(withoutQuotes))return undefined;
    text=withoutQuotes;
    const people=store.snapshot().people,found=[];
    for(const person of people){
      const labels=[person.label,...(person.label==='妈妈'?['我妈','母亲']:person.label==='爸爸'?['我爸','父亲']:[])];
      for(const label of labels){const escaped=label.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
        if(new RegExp(`(?:发给|发送给|投递给|推送给|交给|送给|投给)\\s*${escaped}(?=$|[，,。；;！!？?\\s]|的微信|微信)`).test(text)||new RegExp(`给\\s*${escaped}\\s*(?:发|推送|投递|送)(?:一下|一份|一条|结果|成果|这份|这个|今天|$)`).test(text)){found.push(person.id);break;}
      }
    }
    const unique=[...new Set(found)];if(unique.length>1)throw new Error('请明确这一项成果发给哪一位家人。');
    if(!unique.length&&/(?:结果|成果|文稿|文件).{0,12}(?:发给|投递给|推送给|交给)\s*\S/.test(text))throw new Error('没有确认成果接收人，请使用已登记的家人称呼。');
    return unique[0];
  }
  async function deliverHarnessResult({task,text}){
    // A completed native turn may just ask a question. Its existence is not
    // proof that the requested family artifact has actually been produced.
    const target=task.conversationId&&task.deliveryTarget&&!task.files?.length?undefined:task.deliveryTarget,recipient=target?.personId??task.personId,route=target?.route??task.route;
    if(task.origin==='console'&&!target){if(store.person(task.personId)?.role!=='owner')throw new Error('Owner身份已改变。');await workbench.appendExternal({reply:text,requestId:'native-'+task.requestId,taskId:task.id});return;}
    return serial(peopleWork,recipient,async()=>{
      const authorize=()=>current(route)&&gateway.canDeliver({taskId:task.id,requestId:task.requestId});
      let outcome='api_accepted';
      try{
        if(!authorize())throw new Error('任务授权或收件人绑定已改变，没有投递。');
        // A completed bounded read may already have sent the actual result
        // before its Owner model finished this exact pure acknowledgement.
        // Keep everything else, including unknown/failed sends, visible.
        if(task.origin==='wechat'&&task.conversationId&&!target&&!task.files?.length&&isRedundantReadAcknowledgement(text)){
          const scope=dotOwnerScope(task.sessionId);const sameRequest={sessionId:task.sessionId,bindingRevision:scope?.bindingRevision,sourceRequestId:task.sourceRequestId};const jobId=scope&&currentDotOwnerRequest(sameRequest)&&await dotOwnerRead?.deliveredFor(sameRequest);
          if(jobId&&authorize()){
            const latest=dotOwnerScope(task.sessionId);const sourceKey=dotSourceKey(task.sessionId,'owner-project-read:'+jobId);
            const receipts=store.snapshot().outbox.filter(row=>row.sourceKey===sourceKey);
            if(latest?.bindingRevision===scope.bindingRevision&&sameRoute(latest.route,route)&&currentDotOwnerRequest(sameRequest)&&receipts.length===1&&receipts[0].kind==='dot_result'&&receipts[0].status==='api_accepted'&&sameRoute(receipts[0].route,route)&&sameRoute(receipts[0].authorizationRoute,route))return{suppressed:true};
          }
        }
        const clean=text.replace(/file:\/\/[^\s]+|\/(?:Users|home|private|tmp)\/[^\s，。；]+/g,'（本地路径已省略）');
        const parts=messageParts(clean);
        for(const[index,content]of parts.entries()){
          if(!authorize())throw new Error('任务授权或收件人绑定已改变，没有继续投递。');
          const row=store.enqueue({personId:recipient,text:`${parts.length>1?`（${index+1}/${parts.length}）\n`:''}${content}`,kind:'harness_result',...(task.route?{authorizationRoute:task.route}:{}),sourceKey:`harness-task:${task.id}:${task.requestId}:${index}`,expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
          await flush(recipient,{onlyId:row.id});const sent=store.snapshot().outbox.find(item=>item.id===row.id);
          if(sent?.status!=='api_accepted')throw Object.assign(new Error('任务结果没有完成投递。'),{sendOutcome:sent?.status==='failed'?'failed':'uncertain'});
        }
        for(const file of task.files??[]){
          let delivery=gateway.artifactDelivery({taskId:task.id,requestId:task.requestId,relativePath:file.relativePath});
          if(delivery.status==='api_accepted')continue;if(delivery.status!=='pending')throw Object.assign(new Error('文件投递结果待核对，没有自动重发。'),{sendOutcome:'uncertain'});
          const reader=task.artifactScope?ownerTaskArtifacts:familyProjectExecutor;
          if(!authorize()||typeof reader?.readArtifact!=='function'||typeof channels.sendFile!=='function')throw new Error('成果文件读取或投递条件已改变。');
          const payload=await reader.readArtifact({workspaceId:task.workspaceId,...(task.artifactScope?{scope:task.artifactScope,expectedSha256:file.sha256}:{personId:recipient}),relativePath:file.relativePath,signal:lifecycle.signal,authorize});
          if(!Buffer.isBuffer(payload?.bytes)||payload.bytes.length>(task.artifactScope?10*1024*1024:128*1024)||payload.name!==file.name||file.sha256&&createHash('sha256').update(payload.bytes).digest('hex')!==file.sha256||!authorize())throw new Error('成果文件变化或授权已改变，没有投递。');
          delivery=gateway.artifactDelivery({taskId:task.id,requestId:task.requestId,relativePath:file.relativePath,status:'dispatching'});
          try{const receipt=await channels.sendFile(route,{name:payload.name,bytes:payload.bytes},{clientId:delivery.clientId,signal:lifecycle.signal,authorize});if(receipt?.status!=='api_accepted')throw new Error('文件提交结果不明。');gateway.artifactDelivery({taskId:task.id,requestId:task.requestId,relativePath:file.relativePath,status:'api_accepted'});store.addMessage(recipient,{id:'file-'+delivery.clientId,dir:'out',text:'[项目成果文件] '+payload.name,kind:'project_file',attachments:[{name:payload.name,size:payload.bytes.length,...(payload.mimeType?{mimeType:payload.mimeType}:{})}]});}
          catch(error){gateway.artifactDelivery({taskId:task.id,requestId:task.requestId,relativePath:file.relativePath,status:error?.sendOutcome==='failed'?'failed':'unknown'});throw error;}
        }
      }catch(error){outcome=error?.sendOutcome==='failed'?'failed':'uncertain';throw error;}
      finally{
        if(target){
          const label=store.person(recipient)?.label??'指定家人',reply=outcome==='api_accepted'?`已向${label}的微信接口提交任务结果${task.files?.length?'和成果文件':''}；实际收信待本人确认。`:outcome==='failed'?`${label}的任务结果被微信接口拒绝，未自动重发。`:`${label}的任务投递尚未确认或授权已变化，未自动重发。`;
          if(task.origin==='console')await workbench.appendExternal({reply,requestId:'native-delivery-'+task.requestId,taskId:task.id});
          else if(current(task.route)){const notice=store.enqueue({personId:task.personId,text:reply,kind:'harness_notice',authorizationRoute:task.route,sourceKey:'harness-notice:'+task.requestId,expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});await flush(task.personId,{onlyId:notice.id});}
        }
      }
    });
  }
  function hasDiary(personId,date){try{return library.query({personId,route:store.route(personId),kind:'diary',date,limit:1}).entries.length>0;}catch(error){lastError=safeError(error);return true;}}
  function diaryInvitationAllowed(row){
    const reminder=store.snapshot().reminders.find(r=>row.sourceKey.startsWith('reminder:'+r.id+':'));if(!reminder||reminder.personId!==row.personId||!['active','completed'].includes(reminder.status)||reminder.purpose!=='diary_invitation'||!recordMatchesBinding(reminder,store.binding(row.personId)))return false;
    const occurrence=row.sourceKey.slice(('reminder:'+reminder.id+':').length),date=localDate(occurrence,reminder.timeZone);return date===localDate(now(),reminder.timeZone)&&!hasDiary(row.personId,date);
  }
  // Whether this person can still be reached right now. The carrier only
  // delivers within 24 hours of that person's own last message.
  // The binding's own field is not written on inbound in this build, so the
  // durable message log is the source of truth for "when did they last write".
  const lastInboundOf=personId=>{
    const binding=store.binding(personId);
    if(!binding)return null;
    let latest=binding.lastInboundAt??null;
    for(const message of store.messages(personId)){
      if(message.dir!=='in'||!recordMatchesBinding(message,binding))continue;
      const at=Date.parse(message.at??'');
      if(!Number.isFinite(at))continue;
      if(!latest||at>Date.parse(latest))latest=message.at;
    }
    return latest;
  };
  // A reminder the family member never received is the owner's problem to fix,
  // so say it plainly instead of leaving a silent failed row in the ledger.
  const tellOwnerUndelivered=(row,reason)=>{
    const owner=store.snapshot().people.find(person=>person.role==='owner');
    if(!owner||owner.id===row.personId)return;
    const label=store.person(row.personId)?.label??'家人';
    const body=row.text.replace(/^提醒：/,'').replace(/^家庭助手代[^\n]*?转告：\s*/,'').trim().slice(0,180);
    const what=row.kind==='reminder'?'提醒':'这句话';
    try{
      store.enqueue({personId:owner.id,kind:'undeliverable_notice',sourceKey:`undeliverable:${row.id}`,
        text:withOwnerPushHeader('undeliverable_notice',label,`给${label}的${what}没送到（${reason}）：\n「${body}」\n把引号里这句直接转给她就行。`)});
    }catch(error){lastError=safeError(error);}
  };
  const reachOf=personId=>{
    const person=store.person(personId),live=channels.status(personId)??{};
    return reachFor({role:person?.role,connected:live.status==='connected',lastInboundAt:lastInboundOf(personId),now:now()});
  };
  const authorized=row=>{
    if(outboxAuthorities.has(row.id)&&outboxAuthorities.get(row.id)()!==true||row.sourceKey.includes(':native-owner-')&&!outboxAuthorities.has(row.id))return false;
    if(row.sourceKey.startsWith('family-dot:')&&!outboxAuthorities.has(row.id))return false;
    if(!current(row.route)||row.authorizationRoute&&!current(row.authorizationRoute))return false;
    if(row.sourceKey.startsWith('owner-message:')&&!row.sourceKey.startsWith('owner-message:'+store.snapshot().people.find(person=>person.role==='owner')?.id+':'))return false;
    if(row.kind==='diary_invitation'&&!diaryInvitationAllowed(row))return false;
    if(row.kind===deferredNoticeKind&&!deferredNotices.canDeliver(row))return false;
    if(row.kind==='member_welcome'&&!onboarding.matchesWelcome({personId:row.personId,text:row.text}))return false;
    if(['workflow_request','workflow_response','workflow_followup'].includes(row.kind)&&!workflowNotifications.canDeliver(row))return false;
    if(row.kind==='digest_once'&&!digestDelivery.canDeliver(row))return false;
    if(['important_event','important_clarify'].includes(row.kind)&&!attention.canDeliver(row.sourceKey))return false;
    if(row.kind==='harness_result'){const match=row.sourceKey.match(/^harness-task:([a-f0-9-]{36}):([a-f0-9-]{36}):\d+$/);if(!match||!gateway.canDeliver({taskId:match[1],requestId:match[2]}))return false;}
    if(row.kind==='tool_result'){
      try{const [personId,toolId,requestId,revision]=JSON.parse(Buffer.from(row.sourceKey.slice('family-tool:'.length),'base64url').toString());if(!toolbox.isCurrent({personId,toolId,requestId,revision}))return false;}catch{return false;}
    }
    if(row.kind!=='manual_daily')return true;
    const command=commandFor(row);return Boolean(command&&current(command.requestRoute));
  };
  function syncCommand(row){
    const command=commandFor(row);if(!command)return;
    const status=['api_accepted','failed','uncertain','cancelled'].includes(row.status)?row.status:['blocked','expired'].includes(row.status)?'failed':'pending';
    store.updateOwnerCommand(command.id,{status});
  }
  function cancelUnauthorized(row){
    if(authorized(row))return false;
    const fresh=store.snapshot().outbox.find(item=>item.id===row.id);
    if((['manual_daily','important_event','important_clarify'].includes(row.kind)||row.sourceKey.startsWith('owner-message:')||row.kind==='harness_result'||row.kind==='harness_notice'||row.authorizationRoute)&&fresh?.status==='pending'){const cancelled=store.transition(row.id,'cancelled','指令授权或接收人连接已改变');syncCommand(cancelled);}
    return true;
  }
  async function flush(personId,{onlyId,authorize:extraAuthorize}={}){
    return serial(flushWork,personId,async()=>{
      // Delivery authorities belong to live rows. Once a row is terminal the
      // closure can never be consulted again, so keep the map from growing for
      // the life of the process.
      for(const id of [...outboxAuthorities.keys()]){const current=store.snapshot().outbox.find(row=>row.id===id);if(!current||!['pending','dispatching'].includes(current.status))outboxAuthorities.delete(id);}
      if(closed||store.snapshot().config.paused){
        for(const row of store.pending().filter(item=>item.personId===personId&&item.kind==='manual_daily'&&(!onlyId||item.id===onlyId)))cancelUnauthorized(row);
        return;
      }
      if(suspended(personId))return;
      const ownerRow=store.snapshot().people.find(p=>p.role==='owner');
      for(const row of store.pending().filter(x=>x.personId===personId&&(!onlyId||x.id===onlyId))){
        if(suspended(personId))return;
        if(row.kind===deferredNoticeKind&&!deferredNotices.canDeliver(row))continue;
        if(['important_event','important_clarify'].includes(row.kind)&&channels.status(personId)?.status!=='connected')continue;
        if(ownerRow&&personId===ownerRow.id){
          if(row.kind==='undeliverable_notice'&&!ownerAllowedPush('relay'))continue;
          if(['family_request','family_response','workflow_request','workflow_followup'].includes(row.kind)&&!ownerAllowedPush('ask'))continue;
          if(row.kind==='important_event'&&!ownerAllowedPush('urgent'))continue;
          if(row.kind==='owner_brief'&&row.sourceKey.startsWith('owner-brief:')){
            if(!hearth.guard().pushRules.digest){store.transition(row.id,'cancelled','自动简报微信推送已关闭，未发送。');continue;}
            if(hearth.inQuietHours(now(),ownerRow.timeZone))continue;
          }
        }
        if(extraAuthorize&&extraAuthorize()!==true){store.transition(row.id,'cancelled','当前指令授权已改变，没有发送。');continue;}
        if(cancelUnauthorized(row))continue;
        // Anything whose own window closed while waiting must not arrive late.
        // Checked before the reach gate: a row held for a closed reach window
        // would otherwise never reach its own expiry and linger forever.
        if(row.expiresAt&&Date.parse(row.expiresAt)<=Date.parse(now())){syncCommand(store.transition(row.id,'expired','等待期间内容已过期，没有发送'));if(row.kind!=='diary_invitation')tellOwnerUndelivered(row,'等待期间对方一直没有来信');continue;}
        // Never attempt what the carrier will refuse: past the window the row
        // waits for their next message instead of failing (and being retried).
        const reach=reachOf(personId);
        if(!canSendNow(reach)){
          // A dated invitation is worthless once its day has gone.
          if(row.kind==='diary_invitation')syncCommand(store.transition(row.id,'expired',reach.state==='offline'?'对方不在线，这次邀请没有发出':'对方超过一天没来信，这次邀请没有发出'));
          continue;
        }
        if(row.kind==='owner_brief'&&row.sourceKey.startsWith('owner-brief:')&&respond&&typeof store.updatePendingText==='function'){
          try{const brief=await preview({date:row.sourceKey.slice(-10)});const fresh=store.snapshot().outbox.find(x=>x.id===row.id);if(fresh?.status==='pending'&&current(row.route))store.updatePendingText(row.id,brief.text);}catch(error){lastError=safeError(error);}
        }
        // A daily has only this person's profile and history; model actions are ignored.
        if(['daily','elder_daily','elder-daily','manual_daily','workbench_daily'].includes(row.kind)&&respond&&typeof store.updatePendingText==='function'){
          try{const person=workbench.memberProfile(personId);const generated=await respond({person,history:memberHistory(personId,12),text:`请生成今天的个人日报，约150字，包含一个与兴趣相关的具体小知识或建议。已核实的今日安排：${row.text}`,dailyPreference:memberReportFeedback?.getPreference({personId,route:row.route})?.instruction??null,reminders:organizer.context(personId).reminders,now:now(),signal:AbortSignal.any([lifecycle.signal,AbortSignal.timeout(45000)])});
            const parsed=parseModelReply(JSON.stringify(generated));if(!parsed.action&&current(row.route))store.updatePendingText(row.id,parsed.reply);
          }catch(error){lastError=safeError(error);if(row.kind==='workbench_daily'&&store.snapshot().outbox.find(x=>x.id===row.id)?.status==='pending'){store.transition(row.id,'blocked','日报生成失败，请检查模型后重试。');continue;}}
        }
        if(memberReportFeedback&&['daily','elder_daily','elder-daily','manual_daily','workbench_daily'].includes(row.kind)){
          try{const fresh=store.snapshot().outbox.find(item=>item.id===row.id);if(fresh?.status==='pending'){const adapted=await memberReportFeedback.adaptReport({personId,route:row.route,text:fresh.text,sourceKey:row.sourceKey,signal:lifecycle.signal,authorize:()=>current(row.route)});if(current(row.route))store.updatePendingText(row.id,adapted.text);}}
          catch(error){lastError=safeError(error);const fresh=store.snapshot().outbox.find(item=>item.id===row.id);if(fresh?.status==='pending')store.transition(row.id,'blocked','本人的日报改写尚未完成，未自动重试。');continue;}
        }
        if(suspended(personId))return;
        if(cancelUnauthorized(row))continue;
        if(store.snapshot().outbox.find(x=>x.id===row.id)?.status!=='pending')continue;
        const started=store.transition(row.id,'dispatching');
        if(started.status!=='dispatching')continue;
        try{
          const receipt=await channels.send(started.route,started.text,{clientId:started.id,authorize:()=>authorized(started)&&(!extraAuthorize||extraAuthorize()===true),signal:AbortSignal.any([lifecycle.signal,AbortSignal.timeout(20000)])});
          if(receipt?.status!=='api_accepted')throw Object.assign(new Error('发送结果未能确认。'),{sendOutcome:'uncertain'});
          syncCommand(store.transition(started.id,'api_accepted',receipt.contextRecovery==='without_context'?'微信接口已接受（一次上下文恢复）；实际收信待本人确认。':''));
        }catch(error){
          const status=error?.sendOutcome==='failed'?(!authorized(started)?'cancelled':'failed'):'uncertain';
          const fresh=store.snapshot().outbox.find(item=>item.id===started.id);
          syncCommand(fresh.status==='dispatching'?store.transition(started.id,status,safeError(error)):fresh);lastError=safeError(error);
        }
      }
    });
  }
  function checkWorkbench(action){
    const state=store.snapshot();
    if(action.type==='daily_schedule'){const person=store.person(action.personId),active=action.enabled&&person.dailyEnabled&&person.dailyTime===action.time;return{status:active?'scheduled':'completed',detail:active?'每日推送已开启。':'这项每日安排已停用或被后续设置替代。'};}
    if(action.type==='remind'){
      const reminder=state.reminders.find(r=>r.id===(action.resultId??('wbr-'+createHash('sha256').update(action.id).digest('hex').slice(0,40))));
      if(!reminder)return null;
      if(reminder.status==='active')return{status:'scheduled',resultId:reminder.id,detail:'提醒已安排，尚未完成。'};
      if(reminder.status==='cancelled')return{status:'cancelled',resultId:reminder.id};
      const delivery=state.outbox.filter(r=>r.sourceKey.startsWith(`reminder:${reminder.id}:`)).at(-1);
      return delivery?deliveryResult(delivery):{status:'failed',detail:'提醒已过期，未发送。'};
    }
    const row=state.outbox.find(r=>r.id===action.resultId||r.sourceKey===action.sourceKey);
    return row?deliveryResult(row):null;
  }
  function deliveryResult(row){return{status:row.status==='api_accepted'?'api_accepted':row.status==='uncertain'||row.status==='dispatching'||row.status==='pending'?'uncertain':row.status==='cancelled'?'cancelled':'failed',resultId:row.id,detail:row.status==='api_accepted'?'微信接口已接受；实际收信待本人确认。':row.detail||'结果尚未确认，请先核对。'};}
  async function cancelWorkbench(action){
    if(action.type==='remind'){if(store.reminders(action.personId).find(r=>r.id===action.resultId)?.status!=='active')throw new Error('这条提醒已执行或过期，不能撤回。');store.cancelReminder(action.personId,action.resultId);}
    else if(action.type==='daily_schedule'){const person=store.person(action.personId);if(person.dailyTime!==action.time)throw new Error('这项安排已被后续设置替代，不能用旧卡片取消当前安排。');store.updatePerson(action.personId,{dailyEnabled:false});}
  }
  async function executeWorkbench(action){
    try{return await executeWorkbenchUnsafe(action);}
    catch(error){const row=store.snapshot().outbox.find(r=>r.sourceKey===action.sourceKey);return row?deliveryResult(row):{status:'failed',detail:safeError(error)};}
  }
  async function executeWorkbenchUnsafe(action){
    alive();if(action.authorize&&action.authorize()!==true||action.authorityRoute&&!current(action.authorityRoute))throw new Error('指令期间服务或 Owner 绑定已改变，未执行。');const person=store.person(action.personId);
    if(action.expectedRoute&&!sameRoute(action.expectedRoute,store.binding(person.id)))throw new Error('这位家人的绑定已改变，请重新核对对象并创建安排。');
    if(action.type==='presentation_service'){presentations.configure(person.id,action.enabled);return{status:'completed',detail:action.enabled?'PPT制作已开通。本人可在微信发送文字、TXT、Markdown、DOCX或PPTX文字材料，取得可编辑PPT并继续修改。':'PPT制作已停用；已提交的文件无法撤回。'};}
    if(action.type==='remind'){
      if(Date.parse(action.dueAt)<=Date.parse(now()))throw new Error('这项提醒时间已经过去，请修改时间后重新确认。');
      const reminder=store.addReminder({id:'wbr-'+createHash('sha256').update(action.id).digest('hex').slice(0,40),personId:person.id,text:action.text,dueAt:action.dueAt,repeat:action.repeat,time:action.time,timeZone:action.timeZone});
      return{status:'scheduled',resultId:reminder.id};
    }
    if(action.type==='daily_schedule'){store.updatePerson(person.id,{dailyEnabled:action.enabled,...(action.time?{dailyTime:action.time}:{})});return{status:action.enabled?'scheduled':'completed',detail:action.enabled?'每日安排已保存；服务运行且本人连接后按当地时间发送。':'每日推送已停用。'};}
    if(action.type==='cancel_reminder'){store.cancelReminder(person.id,action.reminderId);return{status:'completed',detail:'后续提醒已取消；已提交消息无法撤回。'};}
    if(store.snapshot().config.paused)throw new Error('服务已暂停，请先开始服务后再重试这一项。');
    const targetRoute=store.route(person.id);if(channels.status(person.id)?.status!=='connected')throw new Error('这位家人的微信尚未连接，请连接后再重试。');
    let content=action.text,kind='owner_message';
    const owner=store.snapshot().people.find(p=>p.role==='owner');
    if(action.type==='send_daily'){if(!respond)throw new Error('尚未连接日报模型。');content=buildElderDaily(store,person.id,{now:now()}).text;kind='workbench_daily';}
    else if(action.type==='request_reply'){content=`家庭助手代${owner?.label??'家人'}转告：\n${action.text}\n\n关于你提到的：${action.requestText.slice(0,180)}\n你可以直接回复我，我会继续跟进这件事。`;kind='owner_response';}
    else if(action.type==='send_message')content=`家庭助手代${owner?.label??'家人'}转告：\n${action.text}`;
    else throw new Error('不支持这项执行操作。');
    if(!current(targetRoute))throw new Error('服务或绑定发生变化，尚未发送。');
    const row=store.enqueue({personId:person.id,text:content,kind,sourceKey:action.sourceKey,...(action.authorityRoute?{authorizationRoute:action.authorityRoute}:{}),expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
    if(action.authorize)outboxAuthorities.set(row.id,action.authorize);
    await flush(person.id,{onlyId:row.id,authorize:action.authorize});return deliveryResult(store.snapshot().outbox.find(r=>r.id===row.id));
  }
  async function notifyRequest(request){
    const owner=store.snapshot().people.find(p=>p.role==='owner');
    if(!owner||!request.ownerRoute||!current(request.ownerRoute)||channels.status(owner.id)?.status!=='connected'||!ownerAllowedPush('ask'))return false;
    const label=store.person(request.personId).label;
    const row=store.enqueue({personId:owner.id,text:withOwnerPushHeader('family_request',label,`${label}请家庭助手转告你：\n${request.text}\n\n你可以在家庭助手的“待我回应”里回复，也可以在微信告诉我如何回复这件事。`),kind:'family_request',authorizationRoute:request.route,sourceKey:`family-request:${request.id}`});
    await flush(owner.id,{onlyId:row.id});return store.snapshot().outbox.find(r=>r.id===row.id)?.status==='api_accepted';
  }
  async function notifyRequestResponse(request,response,messageId){
    const owner=store.snapshot().people.find(p=>p.role==='owner');
    if(!owner||!request.ownerRoute||!current(request.ownerRoute)||!current(request.route)||!ownerAllowedPush('ask'))return;
    const label=store.person(request.personId).label;
    const row=store.enqueue({personId:owner.id,text:withOwnerPushHeader('family_response',label,`${label}回应了先前转告的事项：\n${response}\n\n关于：${request.text.slice(0,180)}\n已记录这次回应；不代表外部事项已完成。`),kind:'family_response',authorizationRoute:request.route,sourceKey:`family-response:${request.id}:${messageId}`});
    await flush(owner.id,{onlyId:row.id});
  }
  function managementReply(view){
    const latest=view.messages.at(-1);let reply=latest?.text??'请到工作台查看处理状态。';
    for(const cardId of latest?.cardIds??[]){const card=view.cards.find(c=>c.id===cardId);if(!card)continue;
      reply+=`\n\n${card.title}：`;
      if(card.kind==='profile')reply+=`\n${card.profile.label} · ${card.profile.timeZone}\n${card.profile.interests.join('、')}\n${card.profile.notes}\n${card.status==='draft'?'回复“确认保存”即可建档。':'资料已保存，微信绑定和分享范围保持原设置。'}`;
      else reply+='\n'+card.actions.map(a=>`${a.targetLabel} · ${{send_daily:'今日个人日报',send_message:'转告',remind:'提醒',daily_schedule:'每日推送',cancel_reminder:'取消提醒',reply_request:'回应请求'}[a.type]??a.type}${a.text?'：'+a.text:''}${a.date?' '+a.date:''}${a.time?' '+a.time:''} · ${{draft:'待确认',scheduled:'已安排',api_accepted:'接口已接受，收信待确认',failed:'未完成',uncertain:'结果不明，不会重发',cancelled:'已取消',completed:'已处理'}[a.status]??a.status}`).join('\n')+(card.status==='draft'?'\n回复“确认安排”后执行；也可以继续修改。':'');
    }return reply.slice(0,3200);
  }
  async function tick(){
    if(Date.now()-lastPruneAt>60*60*1000){lastPruneAt=Date.now();try{store.prune?.({outboxKeepDays:30,outboxKeepPerPerson:50});}catch(error){lastError=safeError(error);}}
    alive();if(ticking)return ticking;
    ticking=(async()=>{if(store.snapshot().config.paused)return;
      for(const person of store.snapshot().people.filter(person=>person.role==='elder')){
        const welcome=onboarding.admit(person.id);
        // The welcome is proactive, so it can only go out while their own last
        // message is still fresh. Otherwise it waits for their first sentence
        // instead of failing twice and never arriving.
        if(welcome&&current(welcome.route)&&!canSendNow(reachOf(person.id)))continue;
        if(welcome&&current(welcome.route)){
          const {route,...payload}=welcome;
          const row=store.enqueue({...payload,expiresAt:new Date(Date.parse(now())+24*3600000).toISOString()});
          onboarding.markEnqueued({personId:person.id,sourceKey:welcome.sourceKey,outboxId:row.id});
        }
      }
      await attention.tick();scheduleTick(store,{now:now(),hasDiary,isReminderSkipped:(id,date)=>hearth.isReminderSkipped(id,date)});
      for(const person of store.snapshot().people.filter(person=>person.role==='elder')){
        if(suspended(person.id))continue;
        let route;try{route=store.route(person.id);}catch{continue;}
        if(!current(route))continue;
        const pref=hearth.member(person.id);
        if(!pref.pinganEnabled)continue;
        const reach=reachOf(person.id),inboundAt=lastInboundOf(person.id),today=localDate(now(),person.timeZone);
        if(reach.state==='open'&&reach.remainingMs>0&&reach.remainingMs<=4*3600000&&inboundAt&&pref.lastPinganDate!==today&&pref.lastPinganInboundAt!==inboundAt){
          const sourceKey=`pingan:${person.id}:${route.generation}:${today}`;
          if(!store.snapshot().outbox.some(row=>row.sourceKey===sourceKey)){
            const expiresAt=new Date(Date.parse(now())+Math.min(reach.remainingMs,4*3600000)).toISOString();
            store.enqueue({personId:person.id,kind:'pingan_keepalive',sourceKey,text:`${person.label}，跟您问声平安。最近一切都顺心吗？有什么需要我帮忙带话或记录的，随时回我一句就行。`,expiresAt});
            hearth.updateMember(person.id,{lastPinganInboundAt:inboundAt,lastPinganDate:today});
          }
        }
      }
      await gateway.tick();await notifyOwnerTaskStatus();
      for(const due of toolbox.due()){
        let route;try{route=store.route(due.personId);}catch{continue;}
        void serial(toolWork,due.personId,()=>runTool({personId:due.personId,toolId:due.toolId,requestId:due.requestId,expectedRevision:due.expectedRevision},route,{notify:true,scheduled:true})).catch(error=>{lastError=safeError(error);});
      }
      await Promise.all(store.snapshot().people.map(p=>flush(p.id)));})().finally(()=>{ticking=null;});
    return ticking;
  }
  const ownerId=()=>{const owner=store.snapshot().people.find(person=>person.role==='owner');if(!owner)throw new Error('请先登记 Owner。');return owner.id;};
  const capabilityHelp=person=>person.role==='owner'?'直接告诉我想办什么就好：给家人发消息、查本机项目和资料、安排提醒，或继续修改任务；也可以给家人开通和调整日报、天气等快捷服务。明确收件人和消息内容就可以发送，不用回电脑确认。你也可以查询所有已保存的家人聊天记录；自动简报另按分享设置整理。家人明确转告或求助会通知你。重要事项主动提醒'+(attention.snapshot().enabled?'已开启，会辅助判断新收到的家人消息，需要你关注时提醒你；不保证识别所有情况。':'尚未开启，可在设置中开启。'):onboarding.describe(person.id).text;
  const sourceRequest=(route,message)=>'wechat-'+createHash('sha256').update(JSON.stringify([route,message.id])).digest('hex');
  // Independent of binding generation so a replay after rebind cannot create a fresh admission.
  const reminderAdmissionId=(personId,messageId)=>'wechat-'+createHash('sha256').update(JSON.stringify(['reminder',personId,messageId])).digest('hex');
  function assignTool(args){
    if(args.toolId==='presentation'){
      if(store.person(args.personId).role!=='elder')throw Object.assign(new Error('PPT制作请选择一位家人。'),{code:'service_presentation_member_required'});
      if(args.allowInvoke&&!presentations.snapshot().available)throw Object.assign(new Error('PPT制作依赖尚未就绪，未开通。'),{code:'service_presentation_unavailable'});
    }
    if(args.toolId==='presentation'&&args.schedule?.enabled&&!args.allowInvoke)throw new Error('PPT需要本人提交材料，请同时允许本人调用；定时安排只提醒提交材料。');
    const result=toolbox.assign(args);if(args.toolId==='presentation')presentations.configure(args.personId,args.allowInvoke);return result;
  }
  async function sendDiscoveredDigest(person,result,requestId,{origin='console',route}={}){
    if(!result?.deliveryProposal)return result;
    const sent=await digestDelivery.deliver({actorId:person.id,origin,requestId,proposal:result.deliveryProposal,...(route?{authorityRoute:route}:{}),signal:origin==='wechat'?lifecycle.signal:managementLifecycle.signal});
    return{reply:sent.reply+(result.draft?.missing?.includes('time')?'\n每天推送的具体时间还没有设置；这次仅尝试发送一份。':'')};
  }
  async function routeWorkflowReply(person,route,text,requestId,{origin='wechat'}={}){
    const match=text.match(/^(回复需求|答复需求|补充需求)(?:\s+(wf-[a-f0-9]{12}))?\s*[：:]\s*([\s\S]+)$/i);
    if(!match)return null;
    const replying=match[1]!=='补充需求';
    if(replying&&person.role!=='owner')return{reply:'这项答复需要由 Owner 发起；你可以补充自己的工具需求。'};
    const owner=store.snapshot().people.find(row=>row.role==='owner');if(!owner)return{reply:'还没有登记家庭联系人，请先在工作台登记。'};
    const requests=replying?toolbox.listRequests({actorId:person.id}):workflowNotifications.memberContext({personId:person.id});
    const rows=(Array.isArray(requests)?requests:requests?.requests??[]).filter(row=>!match[2]||workflowNotifications.shortId({personId:row.personId,requestId:row.requestId})===match[2]);
    if(rows.length!==1)return{reply:rows.length?'有几项需求正在接续，请带上通知里的需求编号，我再把这句话转到对应事项。':'没有找到你当前可接续的这项需求，没有发送。'};
    const request=rows[0];
    const result=replying?await workflowNotifications.requestUpdate({actorId:person.id,personId:request.personId,requestId:request.requestId,status:'accepted',note:match[3],operationId:requestId,...(origin==='wechat'?{authorityRoute:route}:{}),signal:lifecycle.signal}):await workflowNotifications.followUp({personId:person.id,requestId:request.requestId,text:match[3],operationId:requestId,expectedRoute:route,signal:lifecycle.signal});
    return{reply:result.reply};
  }
  /** 会话里答复家人的工具需求：背景块给的是 wf- 短编号，这里换回真实请求。 */
  function workflowRequestByShort(short){
    const rows=toolbox.listRequests({actorId:ownerId()});
    const matches=rows.filter(row=>workflowNotifications.shortId({personId:row.personId,requestId:row.requestId})===short);
    if(matches.length!==1)throw new Error(matches.length?'这项需求对应多条记录，请在背景里核对需求编号。':'没有找到这项需求，可能已经结束。');
    return matches[0];
  }
  /** 更新一项工具需求，并把答复送回家人。console 与原生会话共用同一实现。 */
  async function updateWorkflowRequest(args,{origin='session'}={}){
    if(!['pending','accepted','completed','declined'].includes(args.status)||args.note!==undefined&&(typeof args.note!=='string'||!args.note.trim()||args.note.length>2000))throw new Error('需求状态或说明无效。');
    const actorId=ownerId(),operationId=args.operationId??(origin==='console'?'console-':'session-')+createHash('sha256').update(JSON.stringify(args)).digest('hex');
    const authorityRoute=origin==='console'?undefined:store.route(actorId);
    let result;
    const run=async()=>{result=await workflowNotifications.requestUpdate({actorId,...args,operationId,...(authorityRoute?{authorityRoute}:{}),signal:lifecycle.signal});return{reply:result.reply};};
    if(origin==='console')await workbench.external({text:'更新工具需求的接续进度：'+({pending:'待处理',accepted:'正在接续',completed:'已完成',declined:'暂不制作'}[args.status])+(args.note?'\n'+args.note:''),contextId:'workflow-'+createHash('sha256').update(JSON.stringify([args.personId,args.requestId])).digest('hex'),requestId:'workflow-update-'+createHash('sha256').update(operationId).digest('hex')},run);
    else await run();
    const request=result?.request??toolbox.listRequests({actorId}).find(row=>row.personId===args.personId&&row.requestId===args.requestId);
    return{...request,notification:{status:result?.status??'recorded',reply:result?.reply??'该操作已有记录，未重复修改。'}};
  }
  /** 会话里直接答复家人托问的事：走工作台那条写回复的既有通路。 */
  async function replyFamilyRequest({requestId,text}){
    const owner=store.person(ownerId()),route=store.route(owner.id);
    const authorize=()=>!closed&&store.person(owner.id)?.role==='owner'&&store.binding(owner.id)?.status==='connected'&&sameRoute(store.route(owner.id),route);
    const operationId='family-reply-'+createHash('sha256').update(JSON.stringify([requestId,text])).digest('hex').slice(0,40);
    const result=await workbench.reply({requestId,text,operationId,authorityRoute:route,authorize});
    const status=result?.status??'unknown';
    return{status,requestId,...(result?.resultId?{resultId:result.resultId}:{}),text:status==='api_accepted'?'已向家人的微信接口提交你的回复；实际收信待本人确认。':['failed','cancelled'].includes(status)?'这条回复没有完成，没有自动重发。':'这条回复的结果尚未确认，没有自动重发。'};
  }
  /** 会话里处理一件重要事项：只认事项编号，不依赖上一句话在不在历史里。 */
  async function respondImportant({incidentId,status,text}){
    const owner=store.person(ownerId()),incident=attention.snapshot().incidents.find(row=>row.id===incidentId);
    if(!incident)throw new Error('这件事已经不在待处理里了。');
    if(typeof text==='string'&&text.trim()){
      const target=store.person(incident.personId),binding=store.binding(target.id),route=store.route(owner.id);
      const result=await sendOwnerMessage({personId:target.id,text:text.trim().slice(0,2800),bindingGeneration:binding.generation,requestId:'attention-reply-'+createHash('sha256').update(JSON.stringify([incidentId,text.trim()])).digest('hex').slice(0,40)},{authorityRoute:route,authorize:()=>!closed&&store.person(owner.id)?.role==='owner'&&store.binding(owner.id)?.status==='connected',signal:lifecycle.signal});
      return{incidentId,status:result?.status??'unknown',text:result?.status==='api_accepted'?`已向${target.label}的微信提交你的回复；实际收信待本人确认。`:'这条回复的投递尚未确认，没有自动重发。'};
    }
    if(!['acknowledged','resolved','muted'].includes(status))throw new Error('请说明这件事要记为已知悉、已解决还是不再提醒。');
    attention.mark(incidentId,status);
    return{incidentId,status,text:{acknowledged:'已记下你已知悉这件事。',resolved:'这件事已记为解决。',muted:'已将这件事静音；新的明确紧急变化仍会提醒你。'}[status]};
  }
  /** 主人自己的提醒与记事：会话可以列、加、取消，旧能力不丢。 */
  function ownerReminder({op,text,dueAt,repeat,reminderId}){
    const person=store.person(ownerId());
    if(op==='list'){
      const rows=store.reminders(person.id).filter(row=>['active','scheduled'].includes(row.status));
      return{reminders:rows.map(row=>({id:row.id,text:row.text,dueAt:row.dueAt,repeat:row.repeat})),text:rows.length?`你有 ${rows.length} 条待执行的提醒。`:'你现在没有待执行的提醒。'};
    }
    if(op==='cancel'){
      if(typeof reminderId!=='string'||!reminderId)throw new Error('取消提醒需要提醒编号；先列一次再取消。');
      store.cancelReminder(person.id,reminderId);
      return{text:'已取消这条提醒。'};
    }
    if(op!=='add')throw new Error('提醒操作只能是 list、add 或 cancel。');
    if(typeof text!=='string'||!text.trim()||text.length>200)throw new Error('请说明提醒内容和具体时间。');
    const due=Date.parse(String(dueAt??''));
    if(!Number.isFinite(due))throw new Error('请说明提醒的具体时间。');
    if(due<=Date.parse(now()))throw new Error('提醒时间已经过去，没有创建。');
    const reminder=store.addReminder({personId:person.id,text:text.trim(),dueAt:new Date(due).toISOString(),repeat:repeat==='daily'?'daily':'once',timeZone:person.timeZone});
    return{reminderId:reminder.id,text:'已记下提醒：'+reminder.text+'。时间：'+new Date(reminder.dueAt).toLocaleString('zh-CN',{timeZone:person.timeZone,hour12:false})+'。'};
  }
  /** 旧工作台/HTTP 服务草稿入口：保持既有接受范围，不接收 origin / contextId /
   * draftOnly 等内部字段；Owner 原生会话走下面的 ownerServiceDraftForSession。 */
  async function serviceRequest({text,requestId}){
    const owner=store.person(ownerId());
    try{
      const result=await serviceSetup.handle({actorId:owner.id,text,requestId:requestId??('service-'+randomUUID()),origin:'wechat'});
      return result??{status:'needs_input',text:'没有对应的服务草稿；请说明要给哪位家人开通或调整什么服务。'};
    }catch(error){return{status:'needs_input',text:serviceSetupErrorText(error)};}
  }
  async function runTool(args,route,{actorId,authorityRoute,notify=false,scheduled=false}={}){
    if(typeof args.requestId!=='string'||!args.requestId||args.requestId.length>160)throw new Error('工具请求标识须为1到160字符。');
    const authorize=()=>current(route)&&(!authorityRoute||current(authorityRoute)&&store.person(actorId)?.role==='owner');
    const options={signal:lifecycle.signal,authorize};
    const result=actorId?await toolbox.invokeFor({actorId,...args},options):scheduled?await toolbox.invokeScheduled(args,options):await toolbox.invoke(args,options);
    if(result.status!=='succeeded'||!authorize()){
      const noticeRoute=authorityRoute??route;
      if((notify||scheduled)&&authorize()&&['executor_failed','invalid_result','restart_uncertain','executor_pending'].includes(result.reason))await serial(peopleWork,noticeRoute.personId,async()=>{
        if(!current(noticeRoute))return;
        store.enqueue({personId:noticeRoute.personId,text:result.status==='uncertain'?'这项工具的结果尚未确认，未自动重跑。请让 Owner 核对资料源和任务记录。':({digest_no_current_report:'今天这份日报还没有生成，未发送旧日报。请让 Owner 检查上游生成进度。',digest_ambiguous_source:'找到了多份可能的日报，未替你选择或发送。请让 Owner 核对来源。',digest_source_changed:'日报来源刚刚发生变化，本次未发送。请让 Owner 重新核对来源。'}[result.failureCode]??'这次工具未能完成，尚未取得可返回的结果。请让 Owner 检查资料源和工具配置。'),kind:'harness_notice',sourceKey:'tool-notice:'+createHash('sha256').update(args.requestId).digest('hex'),authorizationRoute:noticeRoute});
        await flush(noticeRoute.personId);
      });
      return result;
    }
    const value=result.result;let content=typeof value==='string'?value:typeof value?.text==='string'?value.text:JSON.stringify(value);
    if(args.toolId==='ai_digest'&&memberReportFeedback){const adapted=await memberReportFeedback.adaptReport({personId:args.personId,route,text:content,sourceKey:'tool-report:'+createHash('sha256').update(JSON.stringify([args.personId,args.toolId,args.requestId,result.revision])).digest('hex'),signal:lifecycle.signal,authorize});content=adapted.text;}
    return serial(peopleWork,args.personId,async()=>{
      if(!authorize()||!toolbox.isCurrent({personId:args.personId,toolId:args.toolId,requestId:args.requestId,revision:result.revision}))return{...result,result:undefined,deliveryStatus:'suppressed'};
      let deliveryStatus;const parts=messageParts(content);
      for(const[index,part]of parts.entries()){
        if(!authorize()||!toolbox.isCurrent({personId:args.personId,toolId:args.toolId,requestId:args.requestId,revision:result.revision}))return{...result,result:undefined,deliveryStatus:'suppressed'};
        const sourceKey='family-tool:'+Buffer.from(JSON.stringify([args.personId,args.toolId,args.requestId,result.revision,index])).toString('base64url');
        const row=store.enqueue({personId:args.personId,text:`${parts.length>1?`工具结果（${index+1}/${parts.length}）\n`:''}${part}`,kind:'tool_result',sourceKey,...(authorityRoute?{authorizationRoute:authorityRoute}:{}),expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
        await flush(args.personId,{onlyId:row.id});deliveryStatus=store.snapshot().outbox.find(item=>item.id===row.id)?.status;
        if(deliveryStatus!=='api_accepted')break;
      }
      return{...result,deliveryStatus};
    });
  }
  function currentWorkbenchConfirmation(personId,text,origin){
    if(!/^(?:好的[，, ]*)?(?:确认(?:安排|执行|发送|保存)?|发吧|安排吧|执行)[。！!\s]*$/.test(text.trim()))return false;
    if(origin==='console')return Boolean(workbench.snapshot().messages.filter(row=>row.role==='assistant').at(-1)?.cardIds?.length);
    return store.messages(personId).filter(row=>row.dir==='out'&&['owner_command','harness_command'].includes(row.kind)).at(-1)?.kind==='owner_command';
  }
  async function ownerMessageDialogue(person,route,message,text,{origin='wechat'}={}){
    if(person.role!=='owner'||!planWorkbench)return null;
    const requestId=origin==='console'?message.id:sourceRequest(route,message);
    const authorize=()=>!closed&&store.person(person.id)?.role==='owner'&&(origin==='console'||current(route));
    if(origin==='console'){
      const existing=workbench.snapshot().messages.find(row=>row.role==='user'&&row.requestId===requestId);
      if(existing){if(existing.text!==text.trim())throw new Error('重复的请求标识对应不同内容。');return{handled:true,management:true,reply:'这条请求已有记录，没有重复执行。'};}
    }
    let previousRequestId,previewDelivered=true;
    if(origin==='wechat'){
      const rows=memberHistory(person.id,150),index=rows.findLastIndex(row=>row.dir==='in'&&row.id===message.id),previous=rows.slice(0,index<0?rows.length:index).filter(row=>row.dir==='in').at(-1);
      if(previous){previousRequestId=sourceRequest(route,previous);const preview=workbench.snapshot().messages.filter(row=>row.role==='assistant'&&row.requestId===previousRequestId).at(-1)?.text;previewDelivered=typeof preview==='string'&&messageParts(preview).every((part,index)=>store.snapshot().outbox.some(row=>row.sourceKey===`reply:${person.id}:${route.generation}:${previous.id}${index?':'+index:''}`&&row.text===part&&row.status==='api_accepted'&&row.kind==='owner_command'&&sameRoute(row.route,route)));}
    }else previousRequestId=workbench.snapshot().messages.filter(row=>row.role==='user'&&!/^(?:wechat-|host-|native-)/.test(row.requestId??'')).at(-1)?.requestId;
    const previous=previousRequestId?workbench.messageDraft({requestId:previousRequestId,origin,authorityRoute:route??undefined}):null;
    const confirming=isOwnerManagementConfirmation(text),editing=/^(?:请|帮我|麻烦)?\s*(?:(?:把|将).{0,100}(?:改|换|删|加)|改成|改为|换成|再加|删掉)/.test(text.trim());
    if(previous&&(confirming||editing)){
      if(!previewDelivered)return{handled:true,management:true,reply:'上一份草稿还没有完整展示，尚未发送给家人。请先让我重新展示草稿，再确认发送。'};
      if(previous.stale||previous.cards.length!==1)return{handled:true,management:true,reply:previous.stale?'这份草稿已经处理或有更新，没有重复发送。请先核对最新内容。':'刚才有多份草稿，请说清要确认或修改哪一份，我会先展示给你。'};
      const card=previous.cards[0];
      if(confirming){
        const state=await workbench.external({text,requestId,authorityRoute:route??undefined},async({confirm})=>{
          const latest=workbench.messageDraft({requestId:previousRequestId,origin,authorityRoute:route??undefined});
          if(!authorize()||!latest||latest.stale||latest.cards.length!==1||latest.cards[0].id!==card.id||latest.cards[0].revision!==card.revision)throw new Error('草稿或连接已经变化，尚未发送。');
          const result=await confirm({cardId:card.id,revision:card.revision,authorityRoute:route??undefined,authorize}),updated=result.cards.find(row=>row.id===card.id);
          const descriptions={api_accepted:'消息已交给微信，实际收信待对方确认。',failed:'这条消息未完成发送，没有自动重发。',uncertain:'发送结果尚未确认，没有自动重发。',cancelled:'这条发送已取消。',completed:'这项操作已处理。',scheduled:'安排已保存，尚未到发送时间。'};
          return{reply:(updated?.actions??[]).map(action=>`${action.targetLabel}：${descriptions[action.status]??'处理结果仍待核对，没有自动重发。'}`).join('\n')||'这项安排的处理结果仍待核对。'};
        });
        return{handled:true,management:true,reply:state.messages.filter(row=>row.role==='assistant'&&row.requestId===requestId).at(-1)?.text??'处理结果仍待核对。'};
      }
      const state=await workbench.chat({text,requestId,contextId:'card:'+card.id,draftOnly:true,messageDraftOrigin:origin,authorityRoute:route??undefined,authorize});
      return{handled:true,management:true,reply:state.messages.filter(row=>row.role==='assistant'&&row.requestId===requestId).at(-1)?.text??'修改尚未完成，没有发送。'};
    }
    if(!isOwnerMessageDraftIntent({userText:text,people:store.snapshot().people}))return null;
    const state=await workbench.chat({text,requestId,draftOnly:true,messageDraftOrigin:origin,authorityRoute:route??undefined,authorize});
    return{handled:true,management:true,reply:state.messages.filter(row=>row.role==='assistant'&&row.requestId===requestId).at(-1)?.text??'还没有形成可确认的草稿，没有发送。'};
  }
  // The desktop panel embeds one native Owner conversation. This opens it,
  // creating a clean session once; creating it never sends a message.
  function openOwnerConversation(){
    alive();
    if(openingConversation)return openingConversation;
    openingConversation=(async()=>{
      const existingPeople=store.snapshot().people;
      if(!existingPeople.some(person=>person.role==='owner')){
        const defaultId=existingPeople.some(person=>person.id==='owner')?'owner-'+randomUUID().slice(0,8):'owner';
        store.addPerson({id:defaultId,role:'owner',label:'我'});
      }
      const personId=ownerId();
      if(typeof ownerAgent?.ensureControlWorkspace!=='function'||typeof ownerAgent?.ensureSession!=='function')throw Object.assign(new Error('owner_agent_unavailable'),{code:'owner_agent_unavailable'});
      const signal=managementLifecycle.signal;
      const workspace=await ownerAgent.ensureControlWorkspace({signal});
      let anchor=consoleConversations.read();
      const fresh=!anchor||anchor.personId!==personId||anchor.workspaceId!==workspace.workspaceId||anchor.cwd!==workspace.path;
      if(fresh)anchor=consoleConversations.create({personId,workspaceId:workspace.workspaceId,cwd:workspace.path});
      await ownerAgent.ensureSession({workspaceId:anchor.workspaceId,cwd:anchor.cwd,sessionId:anchor.sessionId},{signal});
      if(fresh)consoleConversations.write(anchor);
      if(store.person(personId)?.role!=='owner')throw new Error('Owner 身份已改变。');
      return{ownerConversation:ownerConversationView()};
    })().finally(()=>{openingConversation=null;});
    return openingConversation;
  }
  function ownerConversationView(){
    let personId;try{personId=ownerId();}catch{return null;}
    const anchor=gateway.consoleConversation({personId});
    if(!anchor)return null;
    let policy='unknown';
    // A check still in flight is unknown, not a failure; only a settled
    // negative result hands the main thread back to the workbench chat.
    try{const row=typeof ownerPromptStatus==='function'?ownerPromptStatus(anchor.sessionId):null;if(row)policy=row.verified===true?'active':!row.reason||row.reason==='pending'?'unknown':'inactive';}catch{policy='unknown';}
    return{sessionId:anchor.sessionId,explicit:consoleConversations.read()?.sessionId===anchor.sessionId,policy};
  }
  async function ownerProjectsForSession({sessionId,signal}={}){
    alive();signal?.throwIfAborted();
    const personId=ownerId();
    // Task progress is not an authorization boundary: native turn/start may
    // be visible before user/message, briefly making progress unknown. The
    // persisted Owner/session relation and current route still authenticate
    // this call; snapshot rechecks them without trusting a session-id prefix.
    const permitted=()=>!closed&&typeof sessionId==='string'&&(gateway.snapshot({personId}).some(task=>task.sessionId===sessionId&&task.conversationId)||gateway.consoleConversation({personId})?.sessionId===sessionId);
    if(!permitted())throw new Error('项目目录工具仅供当前 Owner 原生会话使用。');
    const rows=await gateway.listProjects({personId});signal?.throwIfAborted();
    if(!permitted())throw new Error('Owner 会话权限已改变，没有返回项目目录。');
    return rows;
  }
  async function ownerAuthorityForSession({sessionId,callId,signal}={}){
    alive();signal?.throwIfAborted();
    return gateway.ownerToolContext({personId:ownerId(),sessionId,callId,signal});
  }
  // A signed scope is issued only for an observed active Owner tool call. Once
  // issued, background checks use the durable WeChat conversation and binding,
  // not an artificial claim that the original turn is still running.
  function dotKey({create=false}={}){
    const path=join(directory,'dot-owner-signing.key');let fd,created=false;
    try{
      if(create){try{fd=openSync(path,constants.O_CREAT|constants.O_EXCL|constants.O_WRONLY|constants.O_NOFOLLOW,0o600);created=true;}
      catch(error){if(error.code!=='EEXIST')throw error;fd=openSync(path,constants.O_RDONLY|constants.O_NOFOLLOW);}}
      else fd=openSync(path,constants.O_RDONLY|constants.O_NOFOLLOW);
      if(created){const value=randomBytes(32);writeFileSync(fd,value);fsyncSync(fd);closeSync(fd);fd=openSync(path,constants.O_RDONLY|constants.O_NOFOLLOW);}
      const stat=fstatSync(fd);
      if(!stat.isFile()||stat.nlink!==1||(stat.mode&0o077)!==0||(typeof process.getuid==='function'&&stat.uid!==process.getuid())||stat.size!==32)throw new Error('Dot signing key is unavailable');
      const value=readFileSync(fd);if(value.length!==32)throw new Error('Dot signing key is invalid');
      return value;
    }catch(error){if(created)try{unlinkSync(path);}catch{}throw error;}
    finally{if(fd!==undefined)closeSync(fd);}
  }
  function dotOwnerScope(sessionId,{createKey=false}={}){
    try{
      if(closed||typeof sessionId!=='string'||sessionId.length>240)return null;
      const id=ownerId(),person=store.person(id),route=store.route(id);
      if(!person||person.role!=='owner'||!current(route)||channels.status(id)?.status!=='connected')return null;
      const matches=gateway.snapshot({personId:id}).filter(task=>task.sessionId===sessionId&&task.conversationId&&task.origin==='wechat');
      if(!matches.length)return null;
      const bindingRevision=createHmac('sha256',dotKey({create:createKey})).update(JSON.stringify(['family-dot-v1',sessionId,person.id,person.createdAt,route.accountId,route.peerId,route.generation])).digest('hex');
      return{sessionId,bindingRevision,personId:id,route};
    }catch{return null;}
  }
  const dotSourceKey=(sessionId,requestId)=>'family-dot:'+createHash('sha256').update(JSON.stringify([sessionId,requestId])).digest('hex');
  const dotReceipt=row=>!row?'absent':row.status==='api_accepted'?'accepted':['failed','cancelled','expired','blocked'].includes(row.status)?'failed':'uncertain';
  const dotDelivery=row=>{const diagnostic=readWeixinSendFailureDetail(row?.detail);return{status:dotReceipt(row),...(diagnostic?{diagnostic}:{})};};
  const mobileProviders=new Set();
  const familyDotBridge={
    registerMobileTasks(resolve){
      if(closed||typeof resolve!=='function')throw new Error('Mobile task provider unavailable');
      mobileProviders.add(resolve);return()=>mobileProviders.delete(resolve);
    },
    async resolveOwnerCall({sessionId,callId,signal}={}){
      try{
        const authority=await ownerAuthorityForSession({sessionId,callId,signal});
        if(authority.origin!=='wechat'||authority.deliveryTarget||authority.authorize()!==true)return null;
        const scope=dotOwnerScope(sessionId,{createKey:true});
        if(!scope||authority.personId!==scope.personId||!sameRoute(authority.route,scope.route)||authority.authorize()!==true)return null;
        // The authoritative original text is transient: Dot must evaluate
        // user intent, not trust model-supplied flags. It is not persisted by
        // this bridge or included in background receipt records.
        const sourceTiming=inboundTiming.get(authority.sourceRequestId);
        const prior=authority.previousReview,clean=prior?.text?.replace(/file:\/\/[^\s]+|\/(?:Users|home|private|tmp)\/[^\s，。；]+/g,'（本地路径已省略）');
        const previousReviewViewToken=typeof clean==='string'?acceptedReviewToken({review:prior,route:scope.route,rows:store.snapshot().outbox,parts:messageParts(clean)}):null;
        if(!familyDotBridge.isOwnerRevisionCurrent(sessionId,scope.bindingRevision)||authority.authorize()!==true)return null;
        return{sessionId,bindingRevision:scope.bindingRevision,sourceRequestId:authority.sourceRequestId,...(sourceTiming?{sourceTiming}:{}),sourceTimingState:sourceTimingState(sourceTiming,now()),userText:authority.userText,...(typeof authority.previousUserText==='string'?{previousUserText:authority.previousUserText}:{}),...(previousReviewViewToken?{previousReviewViewToken}:{})};
      }catch{return null;}
    },
    isOwnerRevisionCurrent(sessionId,revision){
      const scope=dotOwnerScope(sessionId);
      return typeof revision==='string'&&/^[a-f0-9]{64}$/.test(revision)&&scope?.bindingRevision===revision;
    },
    ownerRouteStatus({sessionId,bindingRevision}={}){
      if(closed)return'unknown';
      if(typeof sessionId!=='string'||sessionId.length>240||typeof bindingRevision!=='string'||!/^[a-f0-9]{64}$/.test(bindingRevision))return'unknown';
      try{
        const state=store.snapshot(),owners=state.people.filter(person=>person.role==='owner');
        if(owners.length!==1)return'changed';
        const person=owners[0],id=person.id,binding=store.binding(id);
        if(!binding)return'changed';
        const route=store.route(id);
        if(!gateway.ownerConversationMatches({personId:id,sessionId,route}))return'changed';
        const actual=createHmac('sha256',dotKey()).update(JSON.stringify(['family-dot-v1',sessionId,person.id,person.createdAt,route.accountId,route.peerId,route.generation])).digest('hex');
        if(actual!==bindingRevision)return'changed';
        const channel=channels.status(id)?.status;
        if(typeof channel!=='string')return'unknown';
        return state.config.paused||binding.status!=='connected'||channel!=='connected'?'offline':'current';
      }catch{return'unknown';}
    },
    async remindOwnerOnce(input){
      const blocked=()=>({status:'blocked',text:'当前消息或时间范围无法安全确认，尚未安排提醒。'});
      try{
        if(!input||typeof input!=='object'||Object.keys(input).sort().join(',')!=='authorize,bindingRevision,callId,sessionId'||typeof input.authorize!=='function')return blocked();
        const authority=await ownerAuthorityForSession(input),scope=dotOwnerScope(input.sessionId),sourceTiming=inboundTiming.get(authority.sourceRequestId);
        if(!scope||authority.origin!=='wechat'||authority.deliveryTarget||authority.personId!==scope.personId||scope.bindingRevision!==input.bindingRevision||!sameRoute(scope.route,authority.route)||authority.authorize()!==true)return blocked();
        const permitted=()=>{try{const state=store.snapshot(),latest=state.messages.filter(row=>row.personId===scope.personId&&row.dir==='in'&&row.bindingGeneration===scope.route.generation).at(-1);return !closed&&!state.config.paused&&latest&&sourceRequest(scope.route,latest)===authority.sourceRequestId&&familyDotBridge.isOwnerRevisionCurrent(input.sessionId,input.bindingRevision)&&authority.authorize()===true&&input.authorize()===true&&sourceTimingState(inboundTiming.get(authority.sourceRequestId),now())==='fresh';}catch{return false;}};
        if(!permitted())return blocked();return organizer.remindOwnerRelative({personId:scope.personId,text:authority.userText,requestId:authority.sourceRequestId,sourceTiming,authorize:permitted});
      }catch(error){return /^原有同一请求的提醒/.test(error?.message??'')?{status:'blocked',text:'这条消息已有时间或状态不同的提醒，请先核对原提醒；未创建新的安排。'}:blocked();}
    },
    async readOwnerDelivery(input){
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).sort().join(',')!=='bindingRevision,requestId,sessionId'||typeof input.requestId!=='string'||input.requestId.length<1||input.requestId.length>256)throw new Error('Dot 回执查询无效。');
      const scope=dotOwnerScope(input.sessionId);
      if(!scope||scope.bindingRevision!==input.bindingRevision)throw new Error('Owner 绑定已改变，不能查看回执。');
      const row=store.snapshot().outbox.find(item=>item.sourceKey===dotSourceKey(input.sessionId,input.requestId));
      if(row&&(row.personId!==scope.personId||row.kind!=='dot_result'||!sameRoute(row.route,scope.route)||!row.authorizationRoute||!sameRoute(row.authorizationRoute,scope.route)))throw new Error('回执不属于当前绑定。');
      return dotDelivery(row);
    },
    async sendOwner(input){
      if(!input||typeof input!=='object'||Array.isArray(input)||Object.keys(input).sort().join(',')!=='authorize,bindingRevision,requestId,sessionId,text'||typeof input.authorize!=='function'||typeof input.text!=='string'||!input.text.trim()||input.text.length>3200||typeof input.requestId!=='string'||input.requestId.length<1||input.requestId.length>256)throw new Error('Dot 发送请求无效。');
      const scope=dotOwnerScope(input.sessionId);
      if(!scope||scope.bindingRevision!==input.bindingRevision)throw new Error('Owner 绑定已改变，未发送。');
      const permitted=()=>{try{return familyDotBridge.isOwnerRevisionCurrent(input.sessionId,input.bindingRevision)&&input.authorize()===true;}catch{return false;}};
      const sourceKey=dotSourceKey(input.sessionId,input.requestId);
      return serial(ownerMessageWork,'dot:'+scope.personId,async()=>{
        if(!permitted())throw new Error('Owner 绑定已改变，未发送。');
        let row=store.snapshot().outbox.find(item=>item.sourceKey===sourceKey);
        if(row&&(row.personId!==scope.personId||row.kind!=='dot_result'||row.text!==input.text||!sameRoute(row.route,scope.route)||!row.authorizationRoute||!sameRoute(row.authorizationRoute,scope.route)))throw new Error('请求标识已用于其他内容或绑定。');
        if(!row){
          row=store.enqueue({personId:scope.personId,text:input.text,kind:'dot_result',sourceKey,authorizationRoute:scope.route,expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
          outboxAuthorities.set(row.id,permitted);
          await flush(scope.personId,{onlyId:row.id,authorize:permitted});
          row=store.snapshot().outbox.find(item=>item.id===row.id);
        }
        return dotDelivery(row);
      });
    },
  };
  // Match the authenticated original request, not whichever message arrived
  // most recently. Ordinary later messages do not cancel this read.
  function dotOwnerRequestState(input){
    try{
      const scope=dotOwnerScope(input?.sessionId);if(!scope||scope.bindingRevision!==input.bindingRevision||typeof input.sourceRequestId!=='string'||!input.sourceRequestId||closed||lifecycle.signal.aborted)return null;
      return findOwnerRequest(gateway.snapshot({personId:scope.personId}),{personId:scope.personId,sessionId:input.sessionId,sourceRequestId:input.sourceRequestId,deliveryForTurn:(task,turn)=>archivedOwnerDelivery({task,turn,route:scope.route,outbox:store.snapshot().outbox})});
    }catch{return null;}
  }
  function currentDotOwnerRequest(input){return dotOwnerRequestState(input)?.task??null;}
  // Native task admission borrows the exact running Owner call, never a model
  // interpretation. Results retain the original source request after normal
  // conversation rotation; cancellation and binding/project changes revoke it.
  const ownerProjectAdmission=createDotOwnerProjectAdmission({
    authenticate:async input=>{
      const authority=await ownerAuthorityForSession(input),scope=dotOwnerScope(input.sessionId);
      if(!scope||authority.origin!=='wechat'||authority.deliveryTarget||authority.personId!==scope.personId||scope.bindingRevision!==input.bindingRevision||!sameRoute(authority.route,scope.route)||!ownerProjectAdmissionTimeCurrent(inboundTiming.get(authority.sourceRequestId),now()))return null;
      const authorize=()=>!closed&&!lifecycle.signal.aborted&&!store.snapshot().config.paused&&familyDotBridge.isOwnerRevisionCurrent(input.sessionId,input.bindingRevision)&&authority.authorize()===true&&ownerProjectAdmissionTimeCurrent(inboundTiming.get(authority.sourceRequestId),now());
      return{sessionId:input.sessionId,bindingRevision:scope.bindingRevision,sourceRequestId:authority.sourceRequestId,userText:authority.userText,authorize};
    },
    current:(sessionId,revision)=>familyDotBridge.isOwnerRevisionCurrent(sessionId,revision),
    workspaces:()=>ownerAgent.listWorkspaces({signal:lifecycle.signal}),workspaceCurrentSync,
    sourceRequest:input=>{
      const scope=dotOwnerScope(input.sessionId);if(!scope||scope.bindingRevision!==input.bindingRevision||!currentDotOwnerRequest(input))return null;
      const matches=gateway.snapshot({personId:scope.personId}).filter(row=>row.origin==='wechat'&&row.sessionId===input.sessionId).flatMap(row=>[row,...(row.turns??[])]).filter(row=>row.sourceRequestId===input.sourceRequestId);
      return matches.length===1?{userText:matches[0].prompt,state:matches[0].state}:null;
    },
  });
  familyDotBridge.acquireOwnerProjectAdmission=input=>ownerProjectAdmission.acquire(input);
  familyDotBridge.isOwnerProjectResultCurrent=input=>ownerProjectAdmission.deliveryCurrent(input);
  familyDotBridge.beforeOwnerProjectResult=async input=>{
    if(!ownerProjectAdmission.deliveryCurrent(input))return'blocked';
    return waitForOwnerReply({...input,current:()=>!closed&&!lifecycle.signal.aborted&&ownerProjectAdmission.deliveryCurrent(input),findTask:()=>currentDotOwnerRequest(input),signal:lifecycle.signal});
  };
  // Separate owner read ledger; interrupted runs remain unknown and are never
  // restarted. The source text comes exclusively from a verified active turn.
  let dotOwnerRead;
  try{dotOwnerRead=createDotOwnerProjectRead({directory,now,
    authenticate:async input=>{const scope=await familyDotBridge.resolveOwnerCall(input);const owner=dotOwnerScope(input.sessionId);return scope&&owner?{...scope,personId:owner.personId}:null;},
    current:(sessionId,revision)=>familyDotBridge.isOwnerRevisionCurrent(sessionId,revision),
    workspaces:()=>ownerAgent.listWorkspaces({signal:lifecycle.signal}),workspaceCurrentSync,
    execute:input=>{if(typeof familyProjectExecutor!=='function')throw new Error('独立项目只读服务不可用');return familyProjectExecutor({...input,signal:lifecycle.signal});},
    deliveryCurrent:input=>Boolean(dotOwnerRequestState(input)),
    beforeDeliver:input=>{
      const scope=dotOwnerScope(input.sessionId);if(!scope||scope.bindingRevision!==input.bindingRevision||typeof input.authorize!=='function')return'blocked';
      const current=()=>{const latest=dotOwnerScope(input.sessionId);return !closed&&!lifecycle.signal.aborted&&latest?.bindingRevision===input.bindingRevision&&sameRoute(latest.route,scope.route)&&input.authorize()===true;};
      return waitForOwnerReply({...input,current,findTask:()=>currentDotOwnerRequest(input),signal:lifecycle.signal});
    },
    deliver:input=>familyDotBridge.sendOwner(input),
  });}catch(error){void gateway.close();void channels.close();unlock();throw error;}
  familyDotBridge.startOwnerProjectRead=input=>dotOwnerRead.start(input);
  familyDotBridge.readOwnerProjectRead=input=>dotOwnerRead.read(input);
  async function sendOwnerMessage(args,{authorize=()=>true,authorityRoute,signal}={}){
    const actorId=ownerId();
    if(typeof args.requestId!=='string'||!/^[A-Za-z0-9._-]{1,160}$/.test(args.requestId)||typeof args.text!=='string'||!args.text.trim()||args.text.length>2800||!Number.isSafeInteger(args.bindingGeneration)||args.bindingGeneration<1)throw new Error('消息内容或请求标识无效。');
    const permitted=()=>{try{return !signal?.aborted&&ownerId()===actorId&&authorize()===true&&(!authorityRoute||current(authorityRoute));}catch{return false;}};
    return serial(ownerMessageWork,args.personId,async()=>{
      if(!permitted())throw new Error('Owner 指令授权已改变，未发送。');
      const target=store.person(args.personId),binding=target&&store.binding(target.id);
      if(!target||!binding||binding.generation!==args.bindingGeneration)throw new Error('家人的微信绑定已改变，请核对后再试。');
      const owner=store.person(actorId),label=['我','本人'].includes(owner.label)?'家庭联系人':owner.label;
      const text=label+'通过乐乐转达：\n'+args.text.trim(),sourceKey='owner-message:'+actorId+':'+args.requestId;
      let row=store.snapshot().outbox.find(item=>item.sourceKey===sourceKey);
      if(row&&(row.personId!==target.id||row.kind!=='owner_message'||row.text!==text||!sameRoute(row.route,store.route(target.id))||!!row.authorizationRoute!==!!authorityRoute||authorityRoute&&!sameRoute(row.authorizationRoute,authorityRoute)))throw new Error('这个消息标识已用于其他内容或绑定。');
      if(!row){
        if(store.snapshot().config.paused)throw new Error('服务已暂停，尚未发送。');
        if(suspended(target.id))throw new Error('这位成员的微信已手动断开，恢复连接前不会发送。');
        if(channels.status(target.id)?.status!=='connected')throw new Error('这位家人的微信暂未连接，尚未发送。');
        row=store.enqueue({personId:target.id,text,kind:'owner_message',sourceKey,...(authorityRoute?{authorizationRoute:authorityRoute}:{}),expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
        outboxAuthorities.set(row.id,permitted);
        await flush(target.id,{onlyId:row.id,authorize:permitted});
        row=store.snapshot().outbox.find(item=>item.id===row.id);
      }
      return{outboxId:row.id,personId:target.id,status:row.status,detail:row.detail};
    });
  }
  async function ownerSendForSession({sessionId,callId,personId,text,signal}={}){
    const authority=await ownerAuthorityForSession({sessionId,callId,signal});
    if(authority.deliveryTarget)throw new Error('这轮成果由原任务统一投递，不能再发一次。');
    const target=store.person(personId),binding=target&&store.binding(personId);
    if(!target||target.role!=='elder'||!binding)throw new Error('请明确一位已连接的家人。');
    const requestId='native-owner-'+createHash('sha256').update(JSON.stringify([authority.personId,authority.sourceRequestId,personId,text])).digest('hex');
    return sendOwnerMessage({personId,text,requestId,bindingGeneration:binding.generation},{authorize:authority.authorize,authorityRoute:authority.route??undefined,signal});
  }
  async function ownerConfirmForSession({sessionId,callId,cardId,revision,signal}={}){
    const authority=await ownerAuthorityForSession({sessionId,callId,signal});
    if(!isOwnerManagementConfirmation(authority.userText))throw new Error('当前消息没有确认这项安排，尚未执行。');
    if(authority.deliveryTarget)throw new Error('这轮成果由原任务统一投递，不能重复确认发送。');
    return workbench.confirm({cardId,revision,authorityRoute:authority.route??undefined,authorize:authority.authorize});
  }
  /** Whether the immediately previous Owner turn really reached WeChat with
   * this exact draft revision. A tool result the model kept to itself is not a
   * draft the owner saw, and an older same-summary revision is not this one. */
  function previousOwnerTurnDelivered(authority,sessionId,shown){
    try{
      if(!authority||authority.origin!=='wechat'||typeof sessionId!=='string'||typeof authority.previousSourceRequestId!=='string'||!authority.previousSourceRequestId)return false;
      const summary=shown?.summary,marker=shown?.marker,summaryHash=shown?.summaryHash;
      // No loose branch: an empty summary, a missing verifier payload or a
      // ledger row without exact version evidence always rejects.
      if(typeof summary!=='string'||!summary.trim()||summary.length>6000)return false;
      if(typeof marker!=='string'||!marker.trim()||marker.length>80)return false;
      if(typeof summaryHash!=='string'||!/^[a-f0-9]{64}$/u.test(summaryHash)||createHash('sha256').update(summary).digest('hex')!==summaryHash)return false;
      const matches=[];
      for(const task of gateway.snapshot({personId:authority.personId})){
        if(task.sessionId!==sessionId||!task.conversationId||task.origin!=='wechat')continue;
        for(const entry of [task,...(task.turns??[])])if(entry.sourceRequestId===authority.previousSourceRequestId)matches.push({task,entry});
      }
      if(matches.length!==1)return false;
      const {task,entry}=matches[0],prefix='harness-task:'+task.id+':'+entry.requestId+':';
      const rows=store.snapshot().outbox.filter(row=>row.kind==='harness_result'&&typeof row.sourceKey==='string'&&row.sourceKey.startsWith(prefix));
      const route=authority.route;
      if(!rows.length||!rows.every(row=>row.status==='api_accepted'&&row.personId===authority.personId&&sameRoute(row.route,route)&&sameRoute(row.authorizationRoute,route)))return false;
      // Producing a tool result is not the same as showing the draft: the
      // delivered reply must contain this version's summary and its readable
      // version marker. Two revisions with identical summaries still differ.
      const delivered=rows.map(row=>String(row.text??'')).join('\n'),fold=value=>value.replace(/\s+/gu,'');
      return fold(delivered).includes(fold(summary))&&fold(delivered).includes(fold(marker));
    }catch{return false;}
  }
  /** Draft one service change from this same Owner native session. The caller
   * cannot supply origin/contextId/draftOnly: they are derived from the verified
   * active Owner tool call, and WeChat drafts are recorded with a readable
   * revision marker so only the exact version shown in the previous turn can be
   * confirmed next. */
  async function ownerServiceDraftForSession({sessionId,callId,text,signal}={}){
    const authority=await ownerAuthorityForSession({sessionId,callId,signal});
    if(!['wechat','console'].includes(authority.origin))throw new Error('服务草稿只在主人原生会话里创建。');
    if(authority.deliveryTarget)throw new Error('这轮成果由原任务统一投递，不能同时创建服务草稿。');
    if(typeof text!=='string'||!text.trim()||text.length>6000)throw new Error('请说明要给哪位家人开通或调整什么服务。');
    const origin=authority.origin,contextId=origin==='wechat'?ownerServiceContextId(sessionId):undefined;
    const operationId='owner-service-draft-'+createHash('sha256').update(JSON.stringify([authority.personId,authority.sourceRequestId,text.trim()])).digest('hex').slice(0,40);
    const result=await serviceSetup.handle({actorId:authority.personId,text,requestId:operationId,origin,draftOnly:true,...(contextId?{contextId}:{})});
    if(!result?.draft)return result??{status:'needs_input',text:'没有对应的服务草稿；请说明要给哪位家人开通或调整什么服务。'};
    if(authority.authorize()!==true)throw new Error('主人当前请求或微信绑定已改变，这次没有保留服务草稿。');
    const summary=typeof result.draft.summary==='string'?result.draft.summary:'';
    const marker=result.draft.status==='ready'&&summary.trim()?serviceDraftMarker(result.draft.revision):null;
    if(origin==='wechat'&&marker)ownerServiceViews.record({sessionId,sourceRequestId:authority.sourceRequestId,personId:authority.personId,origin,contextId,draftId:result.draft.id,revision:result.draft.revision,summary,marker});
    // Preview only: an immediate-send proposal must never reach a sender from here.
    const{deliveryProposal,...preview}=result;void deliveryProposal;
    if(origin!=='wechat'||!marker)return preview;
    // The readable marker travels in the rendered reply. The Owner never has to
    // copy it; confirmation only needs to find it in the accepted reply.
    const rendered=typeof preview.reply==='string'?preview.reply:typeof preview.text==='string'?preview.text:null;
    return rendered?{...preview,reply:`${rendered}\n（${marker}）`}:preview;
  }
  /** Confirm one service draft created and shown by this same Owner native
   * session. The session-derived context plus the exact displayed revision is
   * the domain boundary; the confirmation phrase comes from the trusted inbound
   * message, never from a model-supplied argument. HTTP/console keep their own
   * serviceSetup.confirm routes. */
  async function ownerServiceConfirmForSession({sessionId,callId,draftId,revision,signal}={}){
    const authority=await ownerAuthorityForSession({sessionId,callId,signal});
    return confirmOwnerServiceDraft({authority,sessionId,draftId,revision,serviceSetup,ledger:ownerServiceViews,previousTurnDelivered:shown=>previousOwnerTurnDelivered(authority,sessionId,shown)});
  }
  function resolveOwnerMobileTask(sessionId,requestId){
    const captured=gateway.mobileTaskScope({sessionId,requestId});
    if(captured){
      const authorize=()=>{try{const actual=gateway.mobileTaskScope({sessionId,requestId});return !closed&&actual?.taskId===captured.taskId&&sameRoute(actual.route,captured.route)&&current(captured.route);}catch{return false;}};
      return authorize()?{...captured,authorize}:null;
    }
    const matches=[];
    for(const provider of mobileProviders){
      try{const value=provider(sessionId,requestId),origin=value?.origin,owner=origin&&dotOwnerScope(origin.sessionId);
        if(!value||!owner||owner.bindingRevision!==origin.bindingRevision||!value.authorize?.()||!familyDotBridge.isOwnerProjectResultCurrent(origin))continue;
        const authorize=()=>{try{return !closed&&mobileProviders.has(provider)&&value.authorize()===true&&sameRoute(dotOwnerScope(origin.sessionId)?.route,owner.route)&&familyDotBridge.isOwnerProjectResultCurrent(origin)===true;}catch{return false;}};
        matches.push({personId:owner.personId,route:owner.route,sessionId,requestId,taskId:value.jobId,label:value.label,kind:'project',originSessionId:origin.sessionId,authorize,questionState:value.questionState});
      }catch{}
    }
    return matches.length===1?matches[0]:null;
  }
  async function sendOwnerMobileNotice({scope,code,text,authorize}={}){
    const permitted=()=>typeof authorize==='function'&&authorize()===true&&scope?.authorize?.()===true;
    if(!permitted()||typeof text!=='string'||text.length>3200)return{status:'failed'};
    const key='mobile-question:'+scope.taskId+':'+code;
    if(store.snapshot().outbox.some(row=>row.sourceKey===key))return{status:'uncertain'};
    const row=store.enqueue({personId:scope.personId,text,kind:'harness_notice',sourceKey:key,authorizationRoute:scope.route,expiresAt:new Date(Date.parse(now())+10*60000).toISOString()});
    outboxAuthorities.set(row.id,permitted);
    await flush(scope.personId,{onlyId:row.id,authorize:permitted});
    const actual=store.snapshot().outbox.find(item=>item.id===row.id);
    return{status:actual?.status??'uncertain'};
  }
  async function notifyOwnerTaskStatus(){
    if(closed||store.snapshot().config.paused)return;
    for(const task of gateway.nativeNoticeTasks().filter(task=>task.delivery.state==='none')){
      let currentTask;try{currentTask=gateway.snapshot({personId:task.personId}).find(row=>row.id===task.id&&row.requestId===task.requestId);}catch{continue;}
      if(!currentTask||task.state==='succeeded')continue;
      if(ownerMobileControl?.hasPendingTask?.(task.id))continue;
      const waiting=['queued','running'].includes(task.state);
      if(waiting&&Date.parse(now())-Date.parse(task.createdAt)<45000)continue;
      const text=waiting?ownerWaitingText(task.prompt):({unknown:'这次处理的结果尚未确认，可能中途被打断了。我没有自动重新执行；你可以让我核对这件事的状态。',failed:'这件事未能完成，已有记录已保留。你可以告诉我接下来想怎样处理。',cancelled:'这件事已停止，已经保存或发出的内容会保留。',needs_approval:'这一步需要你在电脑上授权，尚未完成。你可以先让我处理不需要这项权限的部分。',needs_input:'这件事还需要你补充信息。请在这里告诉我具体要求，我会接着核对。'}[task.state]);
      if(!text)continue;
      const key='native-status-'+task.requestId+'-'+(waiting?'waiting':task.state);
      if(task.origin==='console'){await workbench.appendExternal({reply:text,requestId:key,taskId:task.id});continue;}
      const route=store.route(task.personId);if(!current(route))continue;
      if(store.snapshot().outbox.some(row=>row.sourceKey===key))continue;
      const row=store.enqueue({personId:task.personId,text,kind:'harness_notice',sourceKey:key,authorizationRoute:route,expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
      await flush(task.personId,{onlyId:row.id});
    }
  }
  function observeOwnerTask(task){
    if(ownerObservers.has(task.id))return;
    const signal=task.origin==='console'?managementLifecycle.signal:lifecycle.signal;
    const pending=(async()=>{
      // Read-only observation makes short answers responsive. It never starts
      // another turn or replays a possibly completed send.
      for(let attempt=0;attempt<150&&!closed&&!signal.aborted;attempt++){
        let fresh;try{fresh=gateway.snapshot({personId:task.personId}).find(row=>row.id===task.id&&row.requestId===task.requestId);}catch{return;}
        if(!fresh||['succeeded','failed','cancelled'].includes(fresh.state)||fresh.delivery.state!=='none')return;
        try{fresh=await gateway.check({personId:task.personId,taskId:task.id});await notifyOwnerTaskStatus();}catch{return;}
        if(!['queued','running'].includes(fresh.state)||fresh.delivery.state!=='none')return;
        try{await delay(800,undefined,{signal});}catch{return;}
      }
    })();ownerObservers.set(task.id,pending);void pending.finally(()=>{if(ownerObservers.get(task.id)===pending)ownerObservers.delete(task.id);}).catch(()=>{});
  }
  async function nativeOwnerCommand(person,route,message,text,{origin='wechat',background=null,direct=false}={}){
    if(person.role!=='owner'||typeof ownerAgent?.ensureControlWorkspace!=='function')return null;
    // Explicit organizer/brief actions keep their established durable journals.
    const related=/(?:刚才|刚刚|上一|这|那|上次|本次).{0,16}(?:简报|报告|资料|项目|交办)/.test(text);
    const previous=related?gateway.snapshot({personId:person.id}).filter(task=>task.conversationId&&(task.origin??'wechat')===origin).at(-1):null;
    // A direct Owner message never detours to the old planners; only the Console
    // entry keeps those fallbacks.
    if(!direct&&(ownerPersonalIntent(text)&&!ownerContextTask(text)&&!(previous&&ownerContextTask(previous.prompt))||ownerBriefIntent(text)))return null;
    const authorized=()=>!closed&&store.person(person.id)?.role==='owner'&&(origin==='console'||current(route));
    if(!authorized())throw new Error('Owner 身份或微信绑定已改变，没有开始原生处理。');
    const signal=origin==='console'?managementLifecycle.signal:lifecycle.signal;
    const workspace=await ownerAgent.ensureControlWorkspace({signal});
    if(!authorized())throw new Error('Owner 身份或微信绑定已改变，没有开始原生处理。');
    // The desktop panel embeds one native conversation. Console requests from
    // the legacy chat join it, so there are never two parallel desktop threads.
    const anchored=origin==='console'?gateway.consoleConversation({personId:person.id}):null;
    const previousConversation=gateway.snapshot({personId:person.id}).filter(task=>task.conversationId&&(task.origin??'wechat')===origin&&task.workspaceId===workspace.workspaceId).at(-1);
    const conversationId=anchored&&anchored.workspaceId===workspace.workspaceId?anchored.conversationId:previousConversation?.conversationId??randomUUID();
    const legacyHistory=previousConversation||anchored?[]:(origin==='console'?workbench.snapshot().messages.slice(-12).map(row=>({role:row.role,text:row.text.slice(0,500)})):memberHistory(person.id,12).filter(row=>!(row.dir==='out'&&ownerPushCategory(row.kind))).map(row=>({role:row.dir==='in'?'user':'assistant',text:row.text.slice(0,500)})));
    const prompt=buildOwnerTurn({text,legacyHistory,...(background?{background}:{})});
    const candidateRecipient=ownerArtifactIntent(text)?recipientIn(text):undefined,recipientPersonId=candidateRecipient===person.id?undefined:candidateRecipient;
    const task=await gateway.submit({personId:person.id,route,origin,workspaceId:workspace.workspaceId,conversationId,prompt,requestId:sourceRequest(route,message),...(recipientPersonId?{deliveryTarget:captureDeliveryTarget(recipientPersonId)}:{})});
    observeOwnerTask(task);
    return{taskId:task.id,deferred:true};
  }
  async function resumeOwnerNativeMessage(messageId){
    const personId=ownerId();
    return serial(peopleWork,personId,async()=>{
      const reject=()=>{throw new Error('这条消息不能恢复，请核对原请求与当前微信绑定。');};
      const snapshot=store.snapshot(),person=store.person(personId),message=snapshot.messages.filter(row=>row.personId===personId&&row.dir==='in').at(-1),binding=store.binding(personId);
      if(typeof messageId!=='string'||!messageId||messageId.length>512||!message||message.id!==messageId||message.kind!=='chat'||message.attachments?.length||!binding||message.bindingGeneration!==binding.generation||binding.status!=='connected'||channels.status(personId)?.status!=='connected'||snapshot.config.paused)reject();
      const age=Date.parse(now())-Date.parse(message.at);if(!Number.isFinite(age)||age<0||age>60*60*1000)reject();
      const route=store.route(personId),requestId=sourceRequest(route,message),ack=snapshot.outbox.find(row=>row.sourceKey===`reply:${personId}:${route.generation}:${message.id}`);
      if(!ack||ack.personId!==personId||ack.kind!=='harness_command'||ack.status!=='api_accepted'||!sameRoute(ack.route,route)||ack.text!==`${person.label}还没有开通AI 日报，无需停用。`||snapshot.ownerCommands?.some(row=>row.inboundMessageId===message.id)||!serviceSetup.canResumeOwnerRead({actorId:personId,requestId,text:message.text}))reject();
      if(message.text.split(/[，,。；;！？!?\n]/u).some(clause=>{const recipient=recipientIn(clause);return recipient&&recipient!==personId;}))reject();
      const existing=gateway.snapshotForOwner().find(task=>task.sourceRequestId===requestId||(task.turns??[]).some(turn=>turn.sourceRequestId===requestId));
      if(existing){if(existing.personId!==personId||existing.origin!=='wechat'||existing.deliveryTarget)reject();return{resumed:false,taskId:existing.id,task:existing};}
      if(snapshot.outbox.some(row=>row.id!==ack.id&&row.sourceKey.includes(requestId)))reject();
      // Reuse the persisted message and source identity without touching inbound
      // dedup or repeating the old acknowledgement. Gateway admission is durable.
      const admitted=await nativeOwnerCommand(person,route,message,message.text,{origin:'wechat'});
      if(!admitted?.taskId)reject();
      const task=gateway.snapshotForOwner().find(row=>row.id===admitted.taskId);
      return{resumed:true,taskId:admitted.taskId,task};
    });
  }
  /** 原生会话真正看见过这段话的时刻：任务创建时间就是交给会话的那一轮。 */
  function lastOwnerSessionAt(personId){
    const tasks=gateway.snapshot({personId}).filter(task=>(task.origin??'wechat')==='wechat'&&task.conversationId);
    return tasks.at(-1)?.createdAt??null;
  }
  /** 乐乐推给主人的真实编号，都能直接交给 family_assistant。 */
  function ownerPushRefs(row){
    const refs=[];
    if(row.kind==='undeliverable_notice')refs.push({label:'转告编号',value:row.id});
    const family=(String(row.sourceKey??'').match(/^family-request:([^\s:]+)$/)??[])[1];
    if(family)refs.push({label:'请求编号',value:family});
    const workflow=(String(row.text??'').match(/wf-[a-f0-9]{12}/)??[])[0];
    if(workflow)refs.push({label:'需求编号',value:workflow});
    const incident=attention.snapshot().incidents.find(item=>item.outboxId===row.id);
    if(incident)refs.push({label:'事项编号',value:incident.id});
    return refs;
  }
  /** 上一轮原生会话之后、微信接口真正接受了的乐乐推送。
   *
   * 时间取消息记录里的接受时间（出站转 api_accepted 时写入），不是入队时间：
   * 排队很久、最后才送到的内容，仍要在下一次会话里出现。
   * 边界只随「真正交给会话的那一轮」前进。被审批或提问接走的消息没有进会话，
   * 它之前的推送留到下一轮，不会被吞掉。 */
  function ownerPushesSince(boundaryAt){
    const state=store.snapshot(),owner=state.people.find(person=>person.role==='owner');
    if(!owner)return[];
    const boundary=Date.parse(String(boundaryAt??''));
    const since=Number.isFinite(boundary)?boundary:Date.parse(now())-24*3600000;
    const acceptedAt=new Map();
    for(const row of state.messages)if(row.personId===owner.id&&row.dir==='out'&&typeof row.id==='string'&&row.id.startsWith('out-'))acceptedAt.set(row.id.slice(4),String(row.at??''));
    return state.outbox
      .filter(row=>row.personId===owner.id&&row.status==='api_accepted'&&ownerPushCategory(row.kind))
      .map(row=>({...row,acceptedAt:acceptedAt.get(row.id)??null}))
      .filter(row=>row.acceptedAt&&Date.parse(row.acceptedAt)>since)
      .sort((a,b)=>String(a.acceptedAt).localeCompare(String(b.acceptedAt)))
      .slice(-10);
  }
  /** 主人发来的文件落到他的控制工作区里，会话拿到的是真实路径。 */
  async function saveOwnerAttachments(route,message){
    if(!message.attachments?.length||typeof channels.downloadFile!=='function'||typeof ownerAgent?.ensureControlWorkspace!=='function')return[];
    const workspace=await ownerAgent.ensureControlWorkspace({signal:lifecycle.signal});
    const folder=join(workspace.path,'inbox',now().slice(0,10));
    mkdirSync(folder,{recursive:true,mode:0o700});
    const saved=[];
    for(const attachment of message.attachments.slice(0,3)){
      const file=await channels.downloadFile(route,attachment,{signal:lifecycle.signal,authorize:()=>current(route)});
      const target=writeAttachmentFile(folder,String(attachment?.name??'file'),file.bytes);
      saved.push(target);
    }
    return saved;
  }
  /** 主人微信来的一句话：只留入站记录、去重、暂停和待审批/待回答，其余原样进原生会话。 */
  async function ownerDirect(person,route,message,text){
    const requestId=sourceRequest(route,message);
    const boundary=lastOwnerSessionAt(person.id);
    const accepted=store.recordInbound(person.id,{id:message.id,peerId:message.peerId,text:text.slice(0,6000),...(message.attachments?.length?{attachments:displayAttachments(message.attachments)}:{}),...(message.at?{at:message.at}:{})});
    if(accepted.accepted&&message.sourceTiming)inboundTiming.recordFirst(requestId,message.sourceTiming);
    if(!accepted.accepted)return accepted;
    if(store.snapshot().config.paused)return{accepted:true,archived:true,paused:true};
    await deliverDeferredNotice(person.id,route,message);
    if(message.unsupported){
      if(current(route)){store.enqueue({personId:person.id,text:'这条消息的格式暂时打不开。发文字，或者把文件发给我。',kind:'harness_notice',sourceKey:'owner-unsupported:'+requestId,authorizationRoute:route,expiresAt:new Date(Date.parse(now())+10*60000).toISOString()});await flush(person.id);}
      return{accepted:true,unsupported:true};
    }
    if(ownerMobileControl){
      // 手机上批权限、回答问题只有这一条通路，必须留在会话之前。
      const control=await ownerMobileControl.handle({personId:person.id,route,text});
      if(control){
        if(control.taskId){const task=gateway.snapshot({personId:person.id}).find(row=>row.id===control.taskId);if(task)observeOwnerTask(task);}
        if(control.reply&&current(route)){store.enqueue({personId:person.id,text:control.reply,kind:'harness_notice',sourceKey:'owner-control:'+requestId,authorizationRoute:route,expiresAt:new Date(Date.parse(now())+10*60000).toISOString()});await flush(person.id);}
        return{accepted:true,control:true};
      }
    }
    let attachments=[];
    try{attachments=await saveOwnerAttachments(route,message);}
    catch(error){lastError=safeError(error);}
    const note=attachments.length?`\n\n主人发来文件，已存到：\n${attachments.map(row=>'- '+row).join('\n')}`:'';
    // 原话逐字进会话：不 trim、不改写、不补标点。只有确实没有文字时才写占位说明。
    const ownerWroteText=typeof message.text==='string'&&message.text.trim().length>0;
    const body=(ownerWroteText?text:'（只发了文件，没有文字）')+note;
    const background=ownerPushBackground(ownerPushesSince(boundary),{refOf:ownerPushRefs});
    try{
      const result=await nativeOwnerCommand(person,route,message,body,{origin:'wechat',background,direct:true});
      if(result?.deferred)return{accepted:true,queued:true,taskId:result.taskId};
      throw new Error('owner_agent_unavailable');
    }catch(error){
      lastError=safeError(error);
      if(current(route)){store.enqueue({personId:person.id,text:'这条消息没能送进你的原生会话，这次没有执行任何操作。等电脑上的会话可用后再发一次。',kind:'harness_notice',sourceKey:'owner-direct-failed:'+requestId,authorizationRoute:route,expiresAt:new Date(Date.parse(now())+10*60000).toISOString()});await flush(person.id);}
      return{accepted:true,failed:true};
    }
  }
  async function harnessCommand(person,route,message,text,{origin='wechat',directReminderAdmitted=false}={}){
    const value=text.trim(),requestId=sourceRequest(route,message),commandCurrent=()=>origin==='console'?!closed&&store.person(person.id)?.role==='owner':current(route);
    if(origin==='wechat'&&person.role==='owner'&&current(route)&&ownerMobileControl){
      const control=await ownerMobileControl.handle({personId:person.id,route,text:value});
      if(control){
        if(control.taskId){const task=gateway.snapshot({personId:person.id}).find(row=>row.id===control.taskId);if(task)observeOwnerTask(task);}
        return{reply:control.reply,replyKind:'harness_notice'};
      }
      if(/^(?:现在到哪了|任务状态|当前任务状态|处理到哪了|进度呢)[。！？!?]*$/.test(value)){
        const task=gateway.snapshot({personId:person.id}).filter(row=>row.conversationId&&row.origin==='wechat').at(-1);
        const names={queued:'已接收，等待电脑处理',running:'电脑正在处理',needs_input:'等你补充信息',needs_approval:'等你确认权限',unknown:'执行状态尚未确认，没有自动重跑',succeeded:'这一轮已结束，结果与投递状态请看原任务记录',failed:'这一轮未完成',cancelled:'这一轮已停止',cancelling:'正在停止'};
        return{reply:task?`当前任务：${task.prompt.slice(0,100)}\n${names[task.state]??'状态未知'}。`:'当前没有已记录的微信任务。可以直接告诉我要继续哪个项目、做什么。',replyKind:'harness_notice'};
      }
      if(/^(?:请|帮我)?(?:停止(?:当前任务|这项任务)?|停一下|停下|别做了)[。！!]*$/.test(value))return{reply:'当前没有可确认归属的运行任务，没有取消其他会话。已保存或发出的内容会保留。',replyKind:'harness_notice'};
    }

    // This narrow, explicit single-message Owner reminder is decided from the
    // bound WeChat ingress before any native agent can choose a Host schedule.
    // Never infer the provider's timestamp from the local receipt or the model.
    if(directOwnerReminders&&origin==='wechat'&&person.role==='owner'&&ownerExactRelativeReminder(text)){
      const admissionId=reminderAdmissionId(person.id,message.id),sourceTiming=reminderAdmission.get(admissionId),textHash=createHash('sha256').update(text).digest('hex');
      const permitted=()=>{try{const state=store.snapshot(),latest=state.messages.filter(row=>row.personId===person.id&&row.dir==='in'&&row.bindingGeneration===route.generation).at(-1),admission=reminderAdmission.get(admissionId);return directReminderAdmitted&&current(route)&&store.person(person.id)?.role==='owner'&&latest&&sourceRequest(route,latest)===requestId&&admission?.textHash===textHash&&sourceTimingState(admission,now())==='fresh';}catch{return false;}};
      if(!permitted())return{reply:'这条消息的发送时间或微信连接无法确认，尚未安排提醒。请稍后重新发送。',replyKind:'personal_organizer'};
      try{
        const result=organizer.remindOwnerRelative({personId:person.id,text,requestId,sourceTiming,authorize:permitted});
        return{reply:result.text,replyKind:'personal_organizer'};
      }catch{
        // A write may have completed even when the response failed. Never
        // create a second reminder or claim that the first was not created.
        return{reply:'这条提醒的安排状态暂未确认，请先查看已有提醒，避免重复设置。',replyKind:'personal_organizer'};
      }
    }
    if(helpIntent(value))return{reply:capabilityHelp(person)};
    if(person.role==='owner'&&ownerBriefIntent(value))return{reply:(await preview()).text};
    const workflowReply=await routeWorkflowReply(person,route,value,requestId,{origin});if(workflowReply)return workflowReply;
    if(person.role==='owner'){
      // Owner public-news requests must reach the same saved interests before
      // legacy local-file setup or toolbox shortcuts can consume the phrase.
      if(isOwnerDotNewsIntent(value))return await nativeOwnerCommand(person,route,message,value,{origin})??{reply:'当前 AI 资讯服务尚未接通，本次未发送或建立计划。'};
      const important=await attention.dialogue(person,route,message,value,{origin});if(important)return important;
      const dialogue=origin==='console'?null:await ownerMessageDialogue(person,route,message,value,{origin});if(dialogue)return dialogue;
      if(planWorkbench&&currentWorkbenchConfirmation(person.id,value,origin))return null;
      const setup=await serviceSetup.handle({actorId:person.id,text:value,requestId,origin});
      if(setup){if(!commandCurrent())throw new Error('Owner身份或绑定已改变，没有继续这项服务安排。');return sendDiscoveredDigest(person,setup,requestId,{origin,route});}
    }
    const continuation=value.match(/^(?:继续|修改)(?:任务)?[【「]([a-f0-9-]{36})[】」][：:]\s*([\s\S]+)$/i);
    if(continuation){const task=await gateway.continue({personId:person.id,route,origin,taskId:continuation[1],prompt:continuation[2],requestId});return{taskId:task.id,reply:'已接到原任务中继续处理，结果会返回这里。'};}
    const cancellation=value.match(/^(?:取消|停止)(?:任务)?[【「]([a-f0-9-]{36})[】」][。！!\s]*$/i);
    if(cancellation){const result=await gateway.cancel({personId:person.id,taskId:cancellation[1]});return{reply:result.requiresNativeSession?'请在原生会话里核对并取消当前任务，尚未取消。':result.accepted?'已请求停止后续操作，等待任务收尾；已经写入的成果不会回滚。':'这项任务已结束，没有新增取消操作。'};}
    if(/^(?:\/projects|(?:查看|列出|查询)(?:我(?:的)?)?\s*(?:Harness|DeepSeek\s*Harness|本地)?\s*项目)[。！!？?\s]*$/i.test(value)){
      const projects=await gateway.listProjects({personId:person.id});
      return{reply:projects.length?`可用的 Harness 项目：\n${projects.map(project=>project.title).join('\n')}\n可以说：在【项目名】项目执行：具体要做的事。`:'目前没有向你开放的项目。可以请 Owner 为你分配项目或工具。'};
    }
    const task=value.match(/^在[【「](.+?)[】」](?:项目)?(?:执行|处理)[：:]\s*([\s\S]+)$/);
    if(task){
      const projects=await gateway.listProjects({personId:person.id}),matches=projects.filter(row=>row.workspaceId===task[1]||row.title===task[1]);
      if(matches.length!==1)return{reply:matches.length?'有多个同名项目，请在控制台选择具体项目后派发。':'没有找到你可使用的这个项目，请先查看可用项目。'};
      const recipientPersonId=person.role==='owner'?recipientIn(task[2]):undefined;
      const result=await gateway.submit({personId:person.id,route,origin,workspaceId:matches[0].workspaceId,prompt:task[2],requestId,...(recipientPersonId?{deliveryTarget:captureDeliveryTarget(recipientPersonId)}:{})});
      return{taskId:result.id,reply:`任务已登记：${result.id}。${person.role==='owner'?`将交给 Harness 原生会话处理${recipientPersonId?'，结果发给'+store.person(recipientPersonId).label:''}；需要审批时请到 Host 核对`:'乐乐会在获准项目内处理；只能创建你的专属成果，不能改动其他源文件'}，尚未完成。`};
    }
    if(/^(?:我的工具|可用工具|查看工具|工具库)[。！!？?\s]*$/.test(value)){
      const rows=toolbox.catalog({personId:person.id});if(memberAgent&&person.role!=='owner')return{reply:'直接说你想办什么就好。我可以帮你解释、写稿、改稿、整理自己收到的材料、查公开信息、记事和安排提醒。'+(rows.some(row=>row.ready)?'\n已为你预设的快捷服务：'+rows.filter(row=>row.ready).map(row=>row.title).join('、'):'')};return{reply:rows.length?rows.map(row=>`${row.title}：${row.ready?'可调用，数据源运行时检查':row.reason==='not_assigned'?'尚未分配给你':'执行服务尚未接通'}`).join('\n'):'还没有为你开通工具。告诉我想做什么，我可以把需求交给 Owner。'};
    }
    const workflow=value.match(/^(?:申请(?:新)?工具|申请工作流|我想要一个工具)[：:]\s*([\s\S]+)$/);
    if(workflow){const request=toolbox.requestWorkflow({personId:person.id,requestId,text:workflow[1]});const notification=origin==='wechat'&&person.role==='elder'&&ownerAllowedPush('ask')?await workflowNotifications.notify({personId:person.id,requestId:request.requestId,expectedRoute:route,signal:lifecycle.signal}):null;return{reply:'已记下工具需求。'+(notification?.status==='api_accepted'?'已向 Owner 的微信接口提交这项请求；实际收信待本人确认。':'Owner 可在需求列表接续；微信通知尚未确认。')+'现在尚未创建或开通新工具。'};}
    const toolId=/^(?:AI\s*(?:精选)?(?:日报|digest)|看(?:一下)?AI日报|今天的AI精选)[。！!？?\s]*$/i.test(value)?'ai_digest':/^(?:天气|查天气|天气日报)[。！!？?\s]*$/.test(value)?'weather':null;
    if(toolId){
      if(memberAgent&&person.role!=='owner'&&!toolbox.catalog({personId:person.id}).some(row=>row.toolId===toolId&&row.ready))return null;
      if(origin==='console')return{reply:'请从工具库选择接收这项工具结果的家人，或直接说“给妈妈发今天的 AI 精选”。'};
      void serial(toolWork,person.id,()=>runTool({personId:person.id,toolId,requestId},route,{notify:true})).catch(error=>{lastError=safeError(error);return serial(peopleWork,person.id,async()=>{if(current(route)){store.enqueue({personId:person.id,text:'这项工具未能执行，可能尚未开通或数据源未接通。请让 Owner 在工具库检查。',kind:'error',sourceKey:`tool-error:${requestId}`});await flush(person.id);}});});
      return{reply:'正在检查这项工具的授权和数据源，结果会在这里返回。'};
    }
    const nativeOwner=await nativeOwnerCommand(person,route,message,value,{origin});if(nativeOwner)return nativeOwner;
    const taskContext=gateway.snapshot({personId:person.id}).filter(task=>(task.origin??'wechat')===origin).sort((a,b)=>a.updatedAt.localeCompare(b.updatedAt)).slice(-5);
    if(memberAgent&&person.role!=='owner'&&!/^在[【「]/.test(value)&&!(taskContext.length&&isProjectFollowupText(value))){
      const projects=/项目|Harness|本地/i.test(value)?await gateway.listProjects({personId:person.id}):[];if(!projects.length)return null;
    }
    if(planHarness&&(/项目|Harness|本地|工具|工作流|AI.{0,10}(?:日报|精选)|天气/i.test(value)||taskContext.length&&isProjectFollowupText(value))){
      const projects=/项目|Harness|本地/i.test(value)?await gateway.listProjects({personId:person.id}):[];
      const members=person.role==='owner'?store.snapshot().people:[person];
      const targets=members.map(member=>{let tools=[];try{tools=person.role==='owner'?toolbox.assignments({actorId:person.id,personId:member.id}).filter(grant=>toolbox.catalog({personId:person.id}).some(row=>row.toolId===grant.toolId&&row.executorAvailable)).map(row=>row.toolId):toolbox.catalog({personId:member.id}).map(row=>row.toolId);}catch{}return{personId:member.id,label:member.label,tools,aliases:member.label==='妈妈'?['我妈','母亲']:member.label==='爸爸'?['我爸','父亲']:[]};});
      const plan=await planHarness({text:value,person:{id:person.id,role:person.role},projects,targets,tasks:taskContext,origin,signal:AbortSignal.any([lifecycle.signal,AbortSignal.timeout(45000)])});
      if(!commandCurrent())return{reply:'连接或服务状态刚刚改变，尚未执行。'};
      const op=plan?.operation;
      if(!op)return{reply:plan.reply};
      if(['continue_task','cancel_task'].includes(op.type)){
        const selected=taskContext.find(task=>task.id===op.taskId&&task.personId===person.id);if(!selected||!isProjectFollowupText(value))throw new Error('请明确想继续哪件项目任务。');
        if(op.type==='continue_task'){if(/^(?:请|帮我|麻烦)?\s*(?:取消|停止)/.test(value))throw new Error('取消指令不能作为继续执行。');const task=await gateway.continue({personId:person.id,route,origin,taskId:selected.id,prompt:value,requestId});return{taskId:task.id,reply:'已接到原任务里继续处理，结果会回到这里。'};}
        if(!/^(?:请|帮我|麻烦)?\s*(?:取消|停止)/.test(value))throw new Error('需要明确说停止或取消这件任务。');const result=await gateway.cancel({personId:person.id,taskId:selected.id});return{taskId:selected.id,reply:result.requiresNativeSession?'请在原生会话里核对并取消，尚未取消。':result.accepted?'已请求停止后续操作，等待任务收尾；已有文件保留，不会回滚。':'这件任务已结束，没有新增取消操作。'};
      }
      if(op.type==='projects')return{reply:projects.length?projects.map(project=>project.title).join('\n'):'目前没有可用项目。请让 Owner 检查项目和授权。'};
      if(op.type==='native_task'){
        const recipientPersonId=person.role==='owner'?(op.recipientPersonId??recipientIn(value)):undefined;
        if(op.recipientPersonId&&op.recipientPersonId!==recipientIn(value))throw new Error('没有确认这位成果接收人，尚未执行。');
        const result=await gateway.submit({personId:person.id,route,origin,workspaceId:op.workspaceId,prompt:value,requestId,...(recipientPersonId?{deliveryTarget:captureDeliveryTarget(recipientPersonId)}:{})});return{taskId:result.id,reply:`任务已登记：${result.id}。${recipientPersonId?'结果将发给'+store.person(recipientPersonId).label:'结果会在这里返回'}；执行范围以你当前获得的权限为准。`};
      }
      if(op.type==='workflow_request'){const request=toolbox.requestWorkflow({personId:person.id,requestId,text:value});const notification=origin==='wechat'&&person.role==='elder'&&ownerAllowedPush('ask')?await workflowNotifications.notify({personId:person.id,requestId:request.requestId,expectedRoute:route,signal:lifecycle.signal}):null;return{reply:'已记下工具需求，'+(notification?.status==='api_accepted'?'已向 Owner 微信接口提交请求；实际收信待本人确认。':'Owner 可以在需求列表里查看，微信通知尚未确认。')+'尚未创建或开通新工具。'};}
      if(op.type==='invoke_tool'){
        if(!targets.some(target=>target.personId===op.personId&&target.tools.includes(op.toolId))||person.role!=='owner'&&op.personId!==person.id)throw new Error('未获准使用这项工具。');
        const target=store.person(op.personId);if(target.id!==person.id&&!value.includes(target.label))throw new Error('请明确接收这项工具结果的家人。');
        const targetRoute=store.route(target.id);
        const report=async result=>{
          if(target.id===person.id&&origin!=='console')return;
          const reply=result?.deliveryStatus==='api_accepted'?`已向${target.label}的微信接口提交工具结果，实际收信仍待本人确认。`:result?.deliveryStatus==='uncertain'||result?.status==='uncertain'?`${target.label}这项工具的结果尚未确认，没有自动重跑或重发。`:`${target.label}这项工具尚未完成，请检查资料源、配置和连接后再处理。`;
          if(origin==='console'){await workbench.appendExternal({reply,requestId:'tool-result-'+createHash('sha256').update(requestId).digest('hex')});return;}
          await serial(peopleWork,person.id,async()=>{if(current(route)){store.enqueue({personId:person.id,text:reply,kind:'harness_notice',sourceKey:`tool-status:${requestId}`,authorizationRoute:route});await flush(person.id);}});
        };
        void serial(toolWork,target.id,async()=>{try{const result=await runTool({personId:target.id,toolId:op.toolId,requestId},targetRoute,{notify:origin!=='console'&&target.id===person.id,...(origin==='console'?{actorId:person.id}:target.id!==person.id?{actorId:person.id,authorityRoute:route}:{})});await report(result);}catch(error){lastError=safeError(error);await report({status:'failed'});}}).catch(error=>{lastError=safeError(error);});
        return{reply:`正在为${target.label}调用这项工具，结果将返回${target.id===person.id?'本会话':'其本人会话'}。`};
      }
      throw new Error('没有可核对的工具或项目指令。');
    }
    return null;
  }
  async function ownerCommand(owner,ownerRoute,message,text){
    if(!planOwner)return{reply:'跨成员指令尚未连接模型。请先在家庭助手工作台安排。'};
    const people=store.snapshot().people.map(person=>({id:person.id,role:person.role,label:person.label,timeZone:person.timeZone,connected:channels.status(person.id)?.status==='connected'}));
    const routes=new Map(people.filter(person=>person.role==='elder').map(person=>{try{return[person.id,store.route(person.id)];}catch{return[person.id,null];}}));
    const plan=await planOwner({owner:{id:owner.id,role:owner.role,label:owner.label,timeZone:owner.timeZone},text,people,now:now(),signal:AbortSignal.any([lifecycle.signal,AbortSignal.timeout(45000)])});
    if(!current(ownerRoute))return{reply:'指令期间服务或你的绑定已改变，未执行。'};
    if(!plan?.action){
      const reply=plan?.reply;
      return{reply:typeof reply==='string'&&!/已(?:经)?(?:发送|推送|安排|设置|完成)|成功|已收到/.test(reply)?reply:'这条指令还没有执行。请明确家人、操作，以及提醒的内容和时间。'};
    }
    const target=resolveOwnerTarget(people,plan.action.target,text),targetRoute=routes.get(target.id);
    if(!targetRoute||!current(targetRoute)||channels.status(target.id)?.status!=='connected')return{reply:`${target.label}尚未连接，或连接刚刚改变。这条指令没有执行，请先在工作台确认这位家人的微信。`};
    const action=plan.action;
    if(!['send_daily','remind'].includes(action.type))throw new Error('不支持这条跨成员操作，未执行。');
    let dueAt;
    if(action.type==='remind'){
      if(!hasExplicitOwnerTime(text,action.timeEvidence))return{reply:`请明确提醒${target.label}的日期、几点以及要提醒的事；时间按${target.label}所在时区计算。尚未创建提醒。`};
      if(typeof action.text!=='string'||!action.text.trim()||action.text.length>200||!['once','daily'].includes(action.repeat))throw new Error('提醒内容或重复方式不完整，尚未创建提醒。');
      dueAt=localDateTimeToInstant(action.date,action.time,target.timeZone);
      if(!dueAt||Date.parse(dueAt)<=Date.parse(now()))return{reply:`这个当地时间不存在或已经过去。请重新说明提醒${target.label}的未来日期和时间，尚未创建提醒。`};
    }
    if(!current(ownerRoute)||!current(targetRoute))return{reply:'指令期间绑定或服务状态改变，未执行。'};
    const id='owner-'+createHash('sha256').update(JSON.stringify([ownerRoute,message.id,target.id,action.type])).digest('hex').slice(0,48);
    const audit=store.recordOwnerCommand({id,requestedBy:owner.id,targetPersonId:target.id,inboundMessageId:message.id,action:action.type,status:'pending'});
    if(audit.status!=='pending')return{reply:'这条指令已有执行记录，没有重复执行。请在工作台查看状态。'};
    if(action.type==='remind'){
      try{
        const reminder=store.addReminder({personId:target.id,text:action.text.trim(),dueAt,repeat:action.repeat,time:action.time,timeZone:target.timeZone});
        store.updateOwnerCommand(id,{status:'scheduled',resultId:reminder.id});
        return{reply:`已为${target.label}安排${action.repeat==='daily'?'每日':'一次性'}提醒：${reminder.text}。按${target.label}当地时间（${target.timeZone}）：${new Date(dueAt).toLocaleString('zh-CN',{timeZone:target.timeZone,hour12:false})}。这是安排确认，尚不代表提醒已发送。`};
      }catch(error){store.updateOwnerCommand(id,{status:'failed'});throw error;}
    }
    try{
      const daily=buildElderDaily(store,target.id,{now:now()});
      const row=store.enqueue({personId:target.id,text:daily.text,kind:'manual_daily',sourceKey:`owner-command:${id}`,expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
      store.updateOwnerCommand(id,{status:'pending',resultId:row.id});
      await flush(target.id,{onlyId:row.id});
      const fresh=store.snapshot().outbox.find(item=>item.id===row.id);syncCommand(fresh);
      const descriptions={api_accepted:'日报已交给微信接口；实际收到需本人确认。',failed:'日报发送失败，未完成发送。',uncertain:'日报发送结果不明，没有自动重发。',cancelled:'绑定或服务状态改变，本次日报已取消。',blocked:'日报发送受阻，尚未完成。',pending:'日报已排队，尚未确认发送。',expired:'本次日报已过期，未发送。'};
      return{reply:`${target.label}：${descriptions[fresh.status]??'日报仍在处理中，尚未确认发送。'}没有改变每日推送开关。`};
    }catch(error){store.updateOwnerCommand(id,{status:'failed'});throw error;}
  }
  async function deliverDeferredNotice(personId,route,message){try{await deferredNotices.onInbound({personId,route,message});}catch(error){lastError=safeError(error);}}
  function receive(personId,message){
    return serial(peopleWork,personId,async()=>{
      if(closed)return{accepted:false};
      const person=store.person(personId);if(!person)return{accepted:false};
      let route;try{route=store.route(personId);}catch{return{accepted:false};}
      if(message.peerId!==route.peerId)return{accepted:false};
      const text=message.voiceError?'[未能识别的语音]':message.unsupported?'[不支持的媒体消息]':message.text?.trim()?message.text:message.attachments?.length?'[收到本人上传的文件材料]':message.text;
      if(typeof text!=='string'||!text.trim())return{accepted:false};
      if(message.voiceError){
        const accepted=store.recordInbound(personId,{id:message.id,peerId:message.peerId,text,...(message.at?{at:message.at}:{})});
        if(!accepted.accepted||store.snapshot().config.paused)return accepted;
        await deliverDeferredNotice(personId,route,message);
        if(current(route)){
          const voiceReply=message.voiceError==='unavailable'
            ? (person.role==='owner'
              ? '这段语音暂时没能识别。请用微信转文字后发给我。'
              : '这段语音暂时没能识别，请用微信转文字后发给我，也可以请家庭联系人准备好语音服务。')
            : '这段语音没能听清，请重新说一次，或用微信转文字后发给我。';
          store.enqueue({personId,text:voiceReply,kind:person.role==='owner'?'harness_notice':'reply',sourceKey:'voice-error:'+sourceRequest(route,message)});await flush(personId);
        }
        return{accepted:true,voiceError:true};
      }
      // 主人的微信就是他自己的原生会话：只留入站记录、去重、暂停和待审批/待回答。
      // 家人继续走下面的原有路径，一行不动。
      if(person.role==='owner')return ownerDirect(person,route,message,text);
      // Write a preparation marker before inbound dedup. Until preparation has
      // durably saved the material, the channel has not advanced its cursor and
      // only this unfinished admission may safely replay after a crash.
      const projectTasks=planHarness&&isProjectFollowupText(text)?gateway.snapshot({personId}).filter(task=>(task.origin??'wechat')==='wechat').sort((a,b)=>a.updatedAt.localeCompare(b.updatedAt)):[],lastProject=projectTasks.at(-1),lastPpt=presentations.snapshot().tasks.filter(task=>task.personId===personId&&(task.bindingGeneration===undefined?route.generation===1:task.bindingGeneration===route.generation)).sort((a,b)=>a.updatedAt.localeCompare(b.updatedAt)).at(-1);
      const lastMember=memberAgent?.status&&person.role==='elder'&&currentMember(person,route)?memberAgent.status({person,route,authorize:()=>currentMember(person,route)}):null,memberMetadata=lastMember?memberAgent.snapshot({personId,route}).requests?.find(row=>row.requestId===lastMember.requestId):null;
      const memberMostRecent=Boolean(memberMetadata&&(!lastPpt||memberMetadata.updatedAt>=lastPpt.updatedAt)&&(!lastProject||memberMetadata.updatedAt>=lastProject.updatedAt));
      const projectFollowup=Boolean(lastProject&&(!lastPpt||lastProject.updatedAt>lastPpt.updatedAt)&&!memberMostRecent),ambiguousFollowup=Boolean(lastProject&&lastPpt&&lastProject.updatedAt===lastPpt.updatedAt&&!memberMostRecent);
      const cancelMember=/^(?:请|帮我|麻烦)?(?:停止|取消|停下|别做了).{0,24}[。！!\s]*$/.test(text.trim())&&!/提醒|日程|便条|笔记|订阅|定时/.test(text),queryMember=/^(?:查看|看看)?(?:任务)?(?:进度|进展|状态)[。？?\s]*$|^(?:处理得怎么样了?|做到哪了|刚才的任务怎么样了)[。？?\s]*$/.test(text.trim());
      let memberControl=null;
      if(memberAgent?.status&&person.role==='elder'&&(cancelMember||queryMember)){
        if(lastMember&&(memberWork.has(personId)||memberMostRecent||!lastPpt&&!lastProject))memberControl={task:lastMember,cancel:cancelMember};
      }
      const pptExplicit=/PPT|幻灯片|演示文稿|powerpoint/i.test(text),pptPageRevision=/(?:第[一二三四五六七八九十\d]+页|这一页|那一页|封面).{0,25}(?:改|换|删|加|短|长)|^(?:把|将)?第[一二三四五六七八九十\d]+页/.test(text),pptAwaiting=lastPpt&&['collecting','needs_input'].includes(lastPpt.status)&&message.attachments?.length&&(!message.text?.trim()||/^(?:补充材料|材料来了|这是.*材料|按这些材料)/.test(text));
      const presentationMessage=!(directOwnerReminders&&person.role==='owner'&&ownerExactRelativeReminder(text))&&(!memberAgent||!memberControl&&Boolean(pptExplicit||lastPpt&&(pptPageRevision||pptAwaiting||!memberMostRecent&&/^(?:继续|进度|取消|停止)[。？?\s]*$/.test(text.trim()))));
      const admission=presentationMessage&&!projectFollowup&&!ambiguousFollowup&&!message.unsupported&&!store.snapshot().config.paused?presentations.admit({person,route,message}):null;
      const diaryContext=person.role==='elder'&&diaryTurn(person,route,text,message.id);
      const libraryStatement=person.role==='elder'&&/以后|今后|往后|长期|我叫|我的称呼|我喜欢|我不喜欢|我习惯|我正在|我已经|这条记错|这个偏好|这项任务|我的资料库/.test(text)&&!/提醒|日程|便条|便笺|笔记|记事/.test(text);
      const personalMember=!diaryContext&&!libraryStatement&&/提醒|日程|便条|便笺|笔记|记事|记住|记下|忘掉|删除.*记录|(?:今天|明天|这周|本周|下周)(?:我)?(?:有|要).{0,12}(?:事|安排)/.test(text)&&!/日报|简报|digest|起草|润色|翻译|改写|写(?:稿|一|封|段|个)/i.test(text);
      const shortcut=/^(?:AI\s*(?:精选)?(?:日报|digest)|看(?:一下)?AI日报|今天的AI精选)[。！!？?\s]*$/i.test(text)?'ai_digest':/^(?:天气|查天气|天气日报|今天天气|今天的天气)[。！!？?\s]*$/.test(text)?'weather':null;
      const fixedMemberCommand=helpIntent(text)||isOwnerCommandCandidate(text,store.snapshot().people)||/^(?:回复需求|答复需求|补充需求|申请(?:新)?工具|申请工作流|我想要一个工具|在[【「]|(?:\/projects|查看项目|列出项目|查询项目)|我的工具|可用工具|查看工具|工具库)/.test(text)||Boolean(shortcut&&toolbox.catalog({personId}).some(row=>row.toolId===shortcut&&row.ready))||Boolean(planHarness&&/项目|Harness|本地/i.test(text)&&access.get(personId).workspaceIds.length)||Boolean(projectFollowup);
      const precedingDiaryMessage=memberHistory(personId,20).filter(row=>row.id!==message.id&&row.kind!==deferredNoticeKind).at(-1),diaryOptOut=person.role==='elder'&&stopsDiaryInvitations(text,precedingDiaryMessage?.kind==='diary_invitation')?store.reminders(personId).filter(row=>row.status==='active'&&row.purpose==='diary_invitation'&&recordMatchesBinding(row,store.binding(personId))):[];
      const diaryOptOutHandled=store.snapshot().outbox.some(row=>row.sourceKey==='diary-stop:'+sourceRequest(route,message));
      const memberCandidate=Boolean(memberAgent&&!diaryOptOutHandled&&!diaryOptOut.length&&person.role==='elder'&&!message.unsupported&&!store.snapshot().config.paused&&!presentationMessage&&!memberControl&&!personalMember&&!fixedMemberCommand),memberKey=createHash('sha256').update(JSON.stringify([route,message.id,text,message.attachments??[]])).digest('hex');
      let memberAdmission=null,memberPreparationError=null;
      const memberSource={messageId:message.id,...(message.attachments?.length?{attachments:JSON.parse(JSON.stringify(message.attachments))}:{}),...(message.at?{at:message.at}:{})};
      if(memberCandidate){try{memberAdmission=typeof memberAgent.prepare==='function'?memberAgent.prepare({person:workbench.memberProfile(personId),route,text,requestId:sourceRequest(route,message),admissionKey:memberKey,source:memberSource,authorize:()=>currentMember(person,route)}):{canRun:true};}catch(error){memberPreparationError=error;}}
      const importantAdmission=attention.admit(person,message,text);
      const requestId=sourceRequest(route,message);
      const directReminder=directOwnerReminders&&person.role==='owner'&&!message.unsupported&&!message.attachments?.length&&ownerExactRelativeReminder(text);
      const prior=directReminder?store.snapshot().messages.find(row=>row.personId===personId&&row.dir==='in'&&row.id===message.id):null;
      // Only this live, first admission may authorize an action. The marker is
      // burned before inbound persistence: a crash can lose the reminder, but
      // replay cannot execute across pause, rebind, changed text or restart.
      const directReminderAdmitted=Boolean(directReminder&&!prior&&!store.snapshot().config.paused&&message.sourceTiming&&reminderAdmission.recordFirst(reminderAdmissionId(personId,message.id),{...message.sourceTiming,textHash:createHash('sha256').update(text).digest('hex')}));
      const accepted=store.recordInbound(personId,{id:message.id,peerId:message.peerId,text:text.slice(0,6000),...(message.attachments?.length?{attachments:displayAttachments(message.attachments)}:{}),...(message.at?{at:message.at}:{})});
      if(accepted.accepted&&person.role==='owner'&&message.sourceTiming)inboundTiming.recordFirst(requestId,message.sourceTiming);
      if(!accepted.accepted&&!admission?.retryable&&!(memberAdmission?.prepared&&memberAdmission.canRun)){presentations.discardAdmission(admission);return accepted;}
      if(store.snapshot().config.paused)return{accepted:true,archived:true,paused:true};
      if(importantAdmission?.id)void attention.run(importantAdmission.id);
      if(accepted.accepted)await deliverDeferredNotice(personId,route,message);
      if(accepted.accepted&&person.role==='elder'){
        const safety=safetyCard(text);
        if(safety){
          if(!current(route))return{accepted:true,archived:true};
          store.enqueue({personId,text:safety.reply,kind:'safety_card',sourceKey:'safety:'+sourceRequest(route,message)});
          await flush(personId);
          return{accepted:true,safety:safety.category};
        }
      }
      if(diaryOptOut.length){
        if(!current(route))return{accepted:true,archived:true};
        for(const row of diaryOptOut)if(store.reminders(personId).some(value=>value.id===row.id&&value.status==='active'&&recordMatchesBinding(value,store.binding(personId))))store.cancelReminder(personId,row.id);
        store.enqueue({personId,text:'好，以后不再主动问你记日记。想记的时候，随时来找我聊。',kind:'diary_control',sourceKey:'diary-stop:'+sourceRequest(route,message)});await flush(personId);return{accepted:true,diaryInvitationStopped:true};
      }
      try{
        if(memberPreparationError){lastError=safeError(memberPreparationError);throw new Error('这次任务没有完成准备，尚未执行。请稍后再试。');}
        if(memberControl){const result=memberControl.cancel?memberAgent.cancel({person,route,requestId:memberControl.task.requestId,authorize:()=>current(route)}):memberControl.task;const reply=memberControl.cancel?(result.accepted?'已请求停止后续处理；已经写入或发出的文件会保留。':'这件事已经结束，没有新增操作。'):({prepared:'这件事已接收，尚未开始处理。',queued:'这件事正在排队。',running:'这件事还在处理中。你可以继续补充，也可以说“停止”。',cancelling:'正在停止后续处理。',cancelled:'已停止后续处理，已有成果和投递状态保留。',unknown:'上次处理的结果尚未确认，没有自动重新执行。',succeeded:'这件事已经处理完成。',failed:'这件事没有完成；已有材料保留，可以说明下一步。',needs_input:'这件事需要你补充信息。'}[result.state]??'当前任务状态正在核对。');if(current(route))store.enqueue({personId,text:reply,kind:'member_notice',sourceKey:'member-control:'+sourceRequest(route,message)});await flush(personId);return{accepted:true,control:true};}
        let answer;let replyKind='reply';
        const presentation=ambiguousFollowup?{handled:true,reply:'你想继续刚才的项目资料任务，还是 PPT？请说一下项目名或 PPT，我再接着处理。'}:message.unsupported||projectFollowup||!presentationMessage?{handled:false}:await presentations.handle({person:workbench.memberProfile(personId),route,message,admission,defer:true,authorize:()=>current(route),signal:lifecycle.signal});
        if(presentation.run){
          // The private input and descriptors are durable before ingestion
          // returns. Download/extract/model/send run in the member queue, so
          // polling can receive a cancellation even during a slow download.
          void serial(presentationWork,personId,async()=>{
            const result=await presentation.run();
            if(!result.reply||!current(route))return;
            store.enqueue({personId,text:result.reply.slice(0,3200),kind:'presentation',sourceKey:`reply:${personId}:${route.generation}:${message.id}`,expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
            await flush(personId);
          }).catch(error=>{lastError=safeError(error);});
          return{accepted:true,queued:true};
        }
        const routed=!presentation.handled&&!message.unsupported&&!message.attachments?.length?await harnessCommand(person,route,message,text,{directReminderAdmitted}):null;
        if(presentation.handled){if(!presentation.reply)return{accepted:true};answer={reply:presentation.reply};replyKind='presentation';}
        else if(routed){if(routed.deferred)return{accepted:true,queued:true,taskId:routed.taskId};answer=routed;replyKind=routed.replyKind??(routed.management?'owner_command':'harness_command');}
        else if(message.unsupported)answer={reply:'这条图片或文件格式我暂时看不了。请发文字说明；已开通PPT制作的家人也可发TXT、Markdown、DOCX或PPTX文字材料。'};
        else if(message.attachments?.length&&!(person.role==='elder'&&memberAgent))answer={reply:'已收到文件，但你还没有开通PPT制作。请让家庭联系人在工作台为你开通，再把材料发来。'};
        else if(person.role==='owner'&&/^(?:\/brief|今日简报|今天的简报|服务简报|查看简报|日报|简报)[。！!？?\s]*$/.test(text.trim())){answer={reply:(await preview()).text};replyKind='owner_brief';}
        else if(person.role==='owner'&&planWorkbench&&!personalIntent(text)&&!/(?:提醒我(?!爸|妈|父亲|母亲)|我的.*提醒|我(?:有|设置|安排).{0,12}提醒|(?:查看|列出|取消).{0,12}我的)/.test(text)){
          const view=await workbench.chat({text,authorize:()=>current(route),authorityRoute:route,requestId:'wechat-'+createHash('sha256').update(JSON.stringify([route,message.id])).digest('hex').slice(0,40)});answer={reply:managementReply(view)};replyKind='owner_command';
        }
        else if(isOwnerCommandCandidate(text,store.snapshot().people)){
          answer=person.role==='owner'?await ownerCommand(person,route,message,text):{reply:'跨成员安排需要由 Owner 发起。你可以让我为你自己设置提醒。'};
          replyKind='owner_command';
        }
        else if(person.role==='elder'&&memberAgent&&!personalMember){
          if(!memberAdmission&&typeof memberAgent.prepare==='function')memberAdmission=memberAgent.prepare({person:workbench.memberProfile(personId),route,text,requestId:sourceRequest(route,message),admissionKey:memberKey,source:memberSource,authorize:()=>currentMember(person,route)});
          if(memberAdmission?.canRun===false)return{accepted:true,queued:false,state:memberAdmission.state};enqueueMember(person,route,message,text,memberKey);return{accepted:true,queued:true,taskId:sourceRequest(route,message)};
        }
        else{
          if(!respond)throw new Error('尚未连接 Harness 模型，请在工作台选择模型后开始使用。');
          const personal=organizer.context(personId);
          answer=parseModelReply(JSON.stringify(await respond({person:workbench.memberProfile(personId),ownerContact:{label:store.snapshot().people.find(p=>p.role==='owner')?.label},requests:workbench.memberRequests(personId),history:memberHistory(personId,30),text,reminders:personal.reminders,notes:personal.notes,now:now(),signal:AbortSignal.any([lifecycle.signal,AbortSignal.timeout(60000)])})));
        }
        if(!current(route))return{accepted:true,skipped:'route_changed_or_paused'};
        const action=answer.action;let reply=answer.reply;
        const personal=action?organizer.execute({personId,text,action,requestId:sourceRequest(route,message)}):null;
        if(personal){reply=personal.reply;replyKind='personal_organizer';}
        else if(action?.type==='relay'){
          if(person.role!=='elder'||typeof action.evidence!=='string'||!text.includes(action.evidence)||!/转告|捎话|带句话|帮我问|告诉.*(?:家人|孩子|儿子|女儿|Owner)|联系.*(?:家人|孩子|儿子|女儿)/.test(action.evidence)||/不要|别|不想|不准/.test(action.evidence)||/(?:不要|别|不想|不准)[^。！？\n]{0,40}(?:转告|捎话|带句话|帮我问)/.test(text)||!text.includes(action.text)||!action.evidence.includes(action.text)||action.evidence.indexOf(action.text)<action.evidence.search(/转告|捎话|带句话|帮我问|告诉|联系/))throw new Error('需要你明确同意转告这件事，才会让家庭联系人看到。');
          const request=workbench.createRequest({personId,text:action.text,sourceId:`${route.generation}:${message.id}`});const notified=await notifyRequest(request);
          reply=notified?'这件事已记录，并已向家庭联系人的微信提交提醒。我只转告这件事；对方回复后，我会代为转达。':'这件事已记在家庭联系人的待回应列表里，微信通知暂未确认。对方回复后，我会代为转达。';
        }else if(action?.type==='preference'){
          if(typeof action.evidence!=='string'||!text.includes(action.evidence))throw new Error('请直接告诉我希望记住的偏好。');
          workbench.savePreference(personId,action.patch);reply='记住了，以后会按你的偏好调整。你随时可以告诉我再改。';
        }else if(action?.type==='resolve_request'){
          if(typeof action.evidence!=='string'||!text.includes(action.evidence))throw new Error('请说明你回应的是哪件事。');
          const request=workbench.memberResponse({personId,requestId:action.requestId,text:action.evidence});await notifyRequestResponse(request,action.evidence,message.id);reply='收到，我已把你对这件事的回应记下来。';
        }else if(action?.type==='remind'){
          if(Date.parse(action.dueAt)<=Date.parse(now()))throw new Error('提醒时间已经过去，请重新说明时间。');
          const reminder=store.addReminder({personId,text:action.text,dueAt:action.dueAt,repeat:action.repeat??'once',...(action.time?{time:action.time}:{}),timeZone:person.timeZone});
          reply=`已记下${reminder.repeat==='daily'?'每日':''}提醒：${reminder.text}。时间：${new Date(reminder.dueAt).toLocaleString('zh-CN',{timeZone:person.timeZone,hour12:false})}。`;
        }else if(action?.type==='cancel'){
          store.cancelReminder(personId,action.reminderId);reply='已取消这条提醒。';
        }else if(action?.type==='list'){
          const rows=store.reminders(personId).filter(x=>['active','scheduled'].includes(x.status));
          reply=rows.length?`您的提醒：\n${rows.map(x=>`${new Date(x.dueAt).toLocaleString('zh-CN',{timeZone:person.timeZone,hour12:false})} ${x.text}`).join('\n')}`:'您目前没有待执行的提醒。';
        }
        if(!current(route))return{accepted:true,skipped:'route_changed_or_paused'};
        const replyParts=['member_agent','owner_command'].includes(replyKind)?messageParts(reply):[reply.slice(0,3200)];for(const[index,part]of replyParts.entries())store.enqueue({personId,text:part,kind:replyKind,sourceKey:`reply:${personId}:${route.generation}:${message.id}${index?':'+index:''}`,expiresAt:new Date(Date.parse(now())+30*60000).toISOString()});
      }catch(error){
        lastError=safeError(error);
        if(current(route))store.enqueue({personId,text:modelFailureReply(error)??`这次没能处理好，尚未完成操作。${lastError}`,kind:'error',sourceKey:`error:${personId}:${route.generation}:${message.id}`,expiresAt:new Date(Date.parse(now())+10*60000).toISOString()});
      }
      await flush(personId);return{accepted:true};
    });
  }
  async function start(){
    alive();if(lifecycle.signal.aborted)lifecycle=new AbortController();
    try{
      await Promise.all(store.snapshot().people.filter(p=>{const binding=store.binding(p.id);return binding&&!suspended(p.id);}).map(async p=>{try{await channels.connect(p.id);}catch(error){lastError=safeError(error);}}));
      await resumeMemberAdmissions();
      void attention.resume();
      // Recover existing native intents only after channel initialization. Never
      // let a fast recovered result race the initial WeChat connection attempt.
      void gateway.tick().catch(error=>{lastError=safeError(error);});
      for(const task of gateway.nativeNoticeTasks().filter(task=>['queued','running'].includes(task.state)))observeOwnerTask(task);
      if(!timer){timer=setInterval(()=>tick().catch(error=>{lastError=safeError(error);}),intervalMs);timer.unref?.();}
      // Clear the flag only once the service can actually run: a failed start
      // must not report "running" with no timer and no channel.
      store.configure({paused:false});
      return status();
    }catch(error){
      if(timer){clearInterval(timer);timer=null;}
      try{store.configure({paused:true});}catch{}
      lastError=safeError(error);
      throw error;
    }
  }
  async function pause(){
    alive();store.configure({paused:true});if(timer){clearInterval(timer);timer=null;}
    lifecycle.abort();reconnectAttempt.clear();
    // Don't wait on a model call here: it will recheck pause/route before any send.
    await Promise.allSettled(store.snapshot().people.map(async p=>{try{await channels.disconnect(p.id);}catch(error){lastError=safeError(error);}}));return status();
  }
  async function action(input){
    alive();if(!input||typeof input!=='object'||Array.isArray(input)||!Object.hasOwn(inputKeys,input.action)||Object.keys(input).some(k=>k!=='action'&&!inputKeys[input.action].includes(k)))throw new Error('不支持的操作或参数。');
    const{action:op,...args}=input;
    if(op==='owner_conversation_open')return openOwnerConversation();
    if(op==='attention_configure'){attention.configure(args.enabled);hearth.updateGuard({pushRules:{urgent:Boolean(args.enabled)}});return status();}
    if(op==='attention_update'){attention.mark(args.incidentId,args.status);return status();}
    if(op==='resume_owner_native_message')return resumeOwnerNativeMessage(args.messageId);
    if(op==='owner_send_message')return sendOwnerMessage(args);
    if(op==='defer_member_notice'){ownerId();return deferredNotices.register(args);}
    if(op==='deferred_member_notices'){ownerId();return deferredNotices.list();}
    if(op==='owner_chat'&&args.requestId===undefined)args.requestId=randomUUID();
    if(['login','verify_login','connect','disconnect','update_person','add_reminder','cancel_reminder','send_message','hearth_member_update','reminder_skip_once','hearth_habit_save','hearth_habit_delete'].includes(op)&&!store.person(args.personId))throw new Error('请先选择一位家人。');
    if(op==='owner_chat'&&!args.profileIntake&&!args.profileEdit&&!args.draftOnly&&!args.contextId&&!args.taskId){
      const dialogue=args.workspaceId?null:await ownerMessageDialogue(store.person(ownerId()),null,{id:args.requestId},args.text??'',{origin:'console'});if(dialogue){if(!workbench.snapshot().messages.some(row=>row.role==='user'&&row.requestId===args.requestId))await workbench.external({text:args.text,requestId:args.requestId},async()=>({reply:dialogue.reply}));return status();}
      if(helpIntent(args.text??'')){await workbench.external(args,async()=>({reply:capabilityHelp(store.person(ownerId()))}));return status();}
      if(/^(?:回复需求|答复需求|补充需求)(?:\s+wf-[a-f0-9]{12})?\s*[：:]/i.test(args.text??'')){await workbench.external(args,()=>routeWorkflowReply(store.person(ownerId()),null,args.text,args.requestId,{origin:'console'}));return status();}
      const result=currentWorkbenchConfirmation(ownerId(),args.text,'console')?null:await serviceSetup.handle({actorId:ownerId(),text:args.text,requestId:args.requestId,origin:'console'});
      if(result){await workbench.external(args,()=>sendDiscoveredDigest(store.person(ownerId()),result,args.requestId));return status();}
    }
    if(op==='service_send_once'){
      const actorId=ownerId(),draft=serviceSetup.snapshotForOwner({actorId}).find(row=>row.id===args.draftId);
      if(!draft||draft.revision!==args.revision||!['needs_input','ready'].includes(draft.status)||draft.toolId!=='ai_digest')throw new Error('这项日报安排已变化，请核对当前版本。');
      const result=await serviceSetup.handle({actorId,origin:draft.origin,contextId:draft.contextId,text:'现在发一次',requestId:'once-'+args.requestId});
      if(result?.draft?.id!==draft.id)throw new Error('当前日报对象已改变，没有发送。');
      await workbench.external({text:'这份日报先发一次',requestId:'once-'+args.requestId},()=>sendDiscoveredDigest(store.person(actorId),result,'once-'+args.requestId));return status();
    }
    if(['service_select','service_confirm','service_cancel'].includes(op)){
      const actorId=ownerId(),method={service_select:'select',service_confirm:'confirm',service_cancel:'cancel'}[op];
      const result=await serviceSetup[method]({actorId,...args,origin:'console'});
      await workbench.external({text:op==='service_select'?'选择服务资料':op==='service_confirm'?'确认这项服务安排':'取消这项服务草稿',requestId:'service-'+args.requestId},async()=>result);
      return status();
    }
    if(op==='owner_chat'&&!args.profileIntake&&!args.profileEdit&&!args.draftOnly&&!args.contextId&&(args.workspaceId||args.taskId||typeof ownerAgent?.ensureControlWorkspace==='function'&&(!ownerPersonalIntent(args.text??'')||ownerContextTask(args.text??''))&&!currentWorkbenchConfirmation(ownerId(),args.text??'','console')||planHarness&&(/项目|Harness|本地|工具|工作流|AI.{0,10}(?:日报|精选)|天气/i.test(args.text??'')||isProjectFollowupText(args.text??'')))){
      const person=store.person(ownerId());
      await workbench.external(args,async()=>{
        if(args.taskId){const task=await gateway.continue({personId:person.id,route:null,origin:'console',taskId:args.taskId,prompt:args.text,requestId:args.requestId});return{reply:'已在原来的项目任务中继续处理，结果会回到这里。',taskId:task.id};}
        if(args.workspaceId){const recipientPersonId=recipientIn(args.text);const task=await gateway.submit({personId:person.id,route:null,origin:'console',workspaceId:args.workspaceId,prompt:args.text,requestId:args.requestId,...(recipientPersonId?{deliveryTarget:captureDeliveryTarget(recipientPersonId)}:{})});return{reply:'任务已交给所选项目，结果会回到这里。需要审批时请打开原生会话核对。',taskId:task.id};}
        return await harnessCommand(person,null,{id:args.requestId},args.text,{origin:'console'})??{reply:'请说明要使用哪个项目或给哪位家人调用工具。'};
      });return status();
    }
    const workbenchActions={owner_chat:'chat',confirm_card:'confirm',cancel_card:'cancel',retry_action:'retry',check_action:'check',undo_profile:'undo',reply_request:'reply',resolve_request:'resolve'};
    if(workbenchActions[op]){await workbench[workbenchActions[op]](args);return status();}
    switch(op){
      case'history_page':return history.page({viewerPersonId:ownerId(),...args});
      case'library_query':{
        ownerId();const route=store.route(args.personId),result=library.query({...args,route});return{...result,entries:result.entries.map(entry=>entry.key==='report-style'?{...entry,readOnly:true,notice:'历史日报偏好摘要，不作为当前生效设置。'}:entry),reportPreference:effectiveReportPreference(args.personId,route)};
      }
      case'library_update':case'library_delete':{
        const actorId=ownerId(),route=store.route(args.personId);if(libraryEntry(args.personId,route,args.id)?.key==='report-style')throw new Error('这是历史日报偏好摘要，不是生效设置；请让本人自然说明以后日报怎样写，以修改实际日报偏好。');const source={id:'owner:'+actorId+':'+args.requestId,at:ownerLibrarySources.atFor({ownerId:actorId,route,requestId:args.requestId,operation:op,entryId:args.id,expectedRevision:args.expectedRevision,...(op==='library_update'?{text:args.text}:{})}),text:op==='library_update'?args.text:'删除这条记录',providedBy:'owner'};
        const authorize=()=>!closed&&store.person(actorId)?.role==='owner'&&sameRoute(store.route(args.personId),route);
        return library[op==='library_update'?'update':'delete']({...args,route,source,authorize});
      }
      case'family_access_list':return access.list({actorId:ownerId()});
      case'family_access_grant':return access.grant({actorId:ownerId(),...args});
      case'family_access_revoke':return access.revoke({actorId:ownerId(),...args});
      case'harness_projects':return gateway.listProjects({personId:ownerId()});
      case'harness_submit':{const personId=ownerId();return gateway.submit({personId,route:null,origin:'console',workspaceId:args.workspaceId,prompt:args.text,requestId:args.requestId,...(args.recipientPersonId!==undefined?{deliveryTarget:captureDeliveryTarget(args.recipientPersonId)}:{})});}
      case'harness_artifact':{
        const actorId=ownerId(),descriptor=gateway.artifactForOwner({actorId,...args}),scope=descriptor.scope??descriptor.artifactScope,reader=scope?ownerTaskArtifacts:familyProjectExecutor;
        if(typeof reader?.readArtifact!=='function')throw new Error('成果文件读取尚未接通。');
        const authorize=()=>{try{const currentDescriptor=gateway.artifactForOwner({actorId,...args});return !closed&&currentDescriptor.personId===descriptor.personId&&currentDescriptor.workspaceId===descriptor.workspaceId&&JSON.stringify(currentDescriptor.scope??currentDescriptor.artifactScope??null)===JSON.stringify(scope??null);}catch{return false;}};
        const file=await reader.readArtifact({workspaceId:descriptor.workspaceId,...(scope?{scope,expectedSha256:descriptor.sha256}:{personId:descriptor.personId}),relativePath:descriptor.relativePath,signal:managementLifecycle.signal,authorize});
        if(!authorize()||!Buffer.isBuffer(file?.bytes)||file.bytes.length>(scope?10*1024*1024:128*1024)||descriptor.sha256&&createHash('sha256').update(file.bytes).digest('hex')!==descriptor.sha256)throw new Error('成果文件变化、授权已改变或超过限制。');
        return{name:file.name,mimeType:file.mimeType??'application/octet-stream',dataBase64:file.bytes.toString('base64'),bytes:file.bytes.length};
      }
      case'harness_continue':return gateway.continue({personId:ownerId(),route:null,origin:'console',taskId:args.taskId,prompt:args.text,requestId:args.requestId});
      case'harness_cancel':return gateway.cancelForOwner({actorId:ownerId(),taskId:args.taskId});
      case'harness_task_status':return gateway.checkForOwner({actorId:ownerId(),taskId:args.taskId});
      case'digest_sources':ownerId();if(typeof digestSources!=='function')throw new Error('日报资料列表尚未接通。');return digestSources({...args,signal:managementLifecycle.signal});
      case'weather_locations':ownerId();if(typeof weatherSearch!=='function')throw new Error('天气城市查询服务尚未接通。');return weatherSearch({query:args.query,signal:managementLifecycle.signal});
      case'tool_catalog':ownerId();return toolbox.catalog({personId:args.personId??ownerId()});
      case'tool_assignments':return toolbox.assignments({actorId:ownerId(),...args});
      case'tool_assign':return assignTool({actorId:ownerId(),...args});
      case'tool_invoke':{const actorId=ownerId();let authorityRoute;try{authorityRoute=store.route(actorId);}catch{}return runTool(args,store.route(args.personId),{actorId,...(authorityRoute?{authorityRoute}:{})});}
      case'workflow_requests':return toolbox.listRequests({actorId:ownerId()});
      case'workflow_request_update':return updateWorkflowRequest(args,{origin:'console'});
      case'workflow_reply':{
        const target=workflowRequestByShort(args.request);
        return updateWorkflowRequest({personId:target.personId,requestId:target.requestId,status:args.status,...(args.note!==undefined?{note:args.note}:{}),...(args.operationId?{operationId:args.operationId}:{})});
      }
      case'family_reply':return replyFamilyRequest({requestId:args.requestId,text:args.text});
      case'attention_respond':return respondImportant({incidentId:args.incidentId,status:args.status,text:args.text});
      case'owner_reminder':return ownerReminder(args);
      case'service_request':return serviceRequest({text:args.text,requestId:args.requestId});
      case'add_person':store.addPerson(args);break;
      case'update_person':{const{personId,...patch}=args;store.updatePerson(personId,patch);break;}
      case'configure':{const{paused,...patch}=args;store.configure(patch);if(paused===true)await pause();else if(paused===false)await start();break;}
      case'login':{const token=beginReconnect(args.personId,300000);try{await channels.login(args.personId,{resumeToken:token});}catch(error){endReconnect(args.personId,token);throw error;}break;}
      case'verify_login':if(typeof channels.submitCode!=='function')throw new Error('当前微信接入暂不支持验证码。');await channels.submitCode(args.personId,args.code);break;
      case'connect':{const token=beginReconnect(args.personId,60000);try{await channels.connect(args.personId,{resumeToken:token});if(channels.status(args.personId)?.status==='connected')suspensions.clear(args.personId);await flush(args.personId);}finally{endReconnect(args.personId,token);}break;}
      case'disconnect':cancelReconnect(args.personId);suspensions.mark(args.personId);await channels.disconnect(args.personId);await flush(args.personId);break;
      case'add_reminder':store.addReminder(args);break;
      case'cancel_reminder':store.cancelReminder(args.personId,args.reminderId);break;
      case'dismiss_relay':{const row=store.snapshot().outbox.find(item=>item.id===args.relayId);if(!row||row.kind!=='undeliverable_notice')throw new Error('这条已经不在待转告里了。');if(row.status==='pending')store.transition(row.id,'cancelled','本人已处理');return status();}
      case'preview_brief':await preview();break;
      case'send_brief':{if(store.snapshot().config.paused)throw new Error('服务已暂停，请先开始服务。');const owner=store.snapshot().people.find(p=>p.role==='owner');if(!owner)throw new Error('请先添加简报接收人。');if(suspended(owner.id))throw new Error('这位成员的微信已手动断开，恢复连接前不会发送。');const route=store.route(owner.id);const brief=await preview();if(!current(route))throw new Error('简报接收人的绑定已改变或服务已暂停，未发送。');store.enqueue({personId:brief.personId,text:brief.text,kind:'owner_brief',sourceKey:`manual-brief:${randomUUID()}`});await flush(brief.personId);break;}
      case'send_message':if(store.snapshot().config.paused)throw new Error('服务已暂停，请先开始服务。');if(suspended(args.personId))throw new Error('这位成员的微信已手动断开，恢复连接前不会发送。');store.enqueue({personId:args.personId,text:args.text,kind:'manual',sourceKey:`manual:${randomUUID()}`});await flush(args.personId);break;
      case'start':await start();break;
      case'pause':await pause();break;
      case'hearth_member_update':{
        ownerId();
        const patch={};
        for(const key of ['pinganEnabled','pinganTime','codeword']){if(args[key]!==undefined)patch[key]=args[key];}
        hearth.updateMember(args.personId,patch);
        break;
      }
      case'hearth_guard_update':{
        ownerId();
        const pushRules={};
        for(const key of ['urgent','relay','ask','digest']){if(args[key]!==undefined)pushRules[key]=args[key];}
        const patch={...(Object.keys(pushRules).length?{pushRules}:{}),...(args.quietHoursEnabled!==undefined?{quietHoursEnabled:args.quietHoursEnabled}:{}),...(args.quietStart!==undefined?{quietStart:args.quietStart}:{}),...(args.quietEnd!==undefined?{quietEnd:args.quietEnd}:{})};
        hearth.updateGuard(patch);
        if(args.digest!==undefined){
          store.configure({ownerBriefEnabled:Boolean(args.digest)});
          if(args.digest===false)for(const row of store.pending().filter(r=>r.kind==='owner_brief'&&r.sourceKey?.startsWith('owner-brief:')))store.transition(row.id,'cancelled','自动简报微信推送已关闭，未发送。');
        }
        if(args.urgent!==undefined){
          let bound=false;try{bound=Boolean(store.route(ownerId()));}catch{}
          if(args.urgent===false||attention.snapshot().available&&bound){try{attention.configure(Boolean(args.urgent));}catch{}}
        }
        break;
      }
      case'reminder_skip_once':{
        ownerId();
        const rem=store.reminders(args.personId).find(r=>r.id===args.reminderId);
        if(!rem)throw new Error('没有找到这条提醒。');
        const date=args.date??localDate(rem.dueAt,rem.timeZone);
        if(args.skip===false)hearth.unskipReminder(args.reminderId);
        else hearth.skipReminder(args.reminderId,date);
        break;
      }
      case'defer_and_dismiss_relay':{
        ownerId();
        const relayRow=args.relayId?store.snapshot().outbox.find(item=>item.id===args.relayId):null;
        const sourceRow=relayRow?store.snapshot().outbox.find(item=>relayRow.sourceKey===`undeliverable:${item.id}`):null;
        const targetPersonId=args.personId??sourceRow?.personId;
        if(!targetPersonId)throw new Error('请指定待补发的家人。');
        const route=store.route(targetPersonId);
        deferredNotices.register({
          personId:targetPersonId,
          requestId:args.requestId??(args.relayId?`relay-${args.relayId}`:`relay-${randomUUID()}`),
          bindingGeneration:args.bindingGeneration??route.generation,
          text:args.text,
        });
        if(relayRow?.kind==='undeliverable_notice'&&relayRow.status==='pending')store.transition(relayRow.id,'cancelled','已改记为待对方来信后补发');
        break;
      }
      case'cancel_deferred_notice':{
        ownerId();
        deferredNotices.cancel({personId:args.personId,id:args.id});
        break;
      }
      case'hearth_habit_save':{
        ownerId();
        const existing=args.id&&hearth.member(args.personId).ownerHabits.some(item=>item.id===args.id);
        if(existing)hearth.updateHabit(args.personId,{id:args.id,text:args.text});
        else hearth.addHabit(args.personId,{...(args.id?{id:args.id}:{}),text:args.text});
        break;
      }
      case'hearth_habit_delete':{
        ownerId();
        hearth.deleteHabit(args.personId,{id:args.id});
        break;
      }
    }
    return status({personId:args.personId});
  }
  let closing=null;
  function close(){
    // The runtime lock and every transport must be released exactly once, even
    // when one subsystem fails: a leaked lock bricks this data directory for the
    // rest of the process life.
    if(closing)return closing;
    closed=true;
    closing=(async()=>{
      const failures=[];
      const step=async(label,action)=>{try{await action();}catch(error){failures.push(label);lastError=safeError(error);}};
      if(timer){clearInterval(timer);timer=null;}
      lifecycle.abort();managementLifecycle.abort();
      await step('dot-owner-read',()=>dotOwnerRead.close());
      await step('presentations',()=>presentations.close());
      await step('attention',()=>attention.close());
      await step('member-agent',()=>memberAgent?.close?.());
      await step('gateway',()=>gateway.close());
      await step('owner-observers',()=>Promise.allSettled(ownerObservers.values()));
      await step('channels',()=>channels.close());
      await step('pending-work',()=>settled({timeoutMs:8000}));
      unlock();
      return{closed:true,failures};
    })();
    return closing;
  }
  async function settled({timeoutMs=60000}={}){
    const deadline=Date.now()+Math.max(0,timeoutMs);
    for(;;){
      await Promise.allSettled([attention.settled(),workbench.settled(),gateway.settled(),...peopleWork.values(),...ownerMessageWork.values(),...presentationWork.values(),...toolWork.values(),...memberWork.values(),...flushWork.values(),...(ticking?[ticking]:[])]);
      const busy=attention.snapshot().active||peopleWork.size||ownerMessageWork.size||presentationWork.size||toolWork.size||memberWork.size||flushWork.size;
      if(!busy)return true;
      if(Date.now()>=deadline)return false;
      await delay(20);
    }
  }
  return{store,channels,status,action,start,stop:pause,close,tick,receive,settled,ownerProjectsForSession,ownerAuthorityForSession,ownerSendForSession,ownerConfirmForSession,ownerServiceDraftForSession,ownerServiceConfirmForSession,resolveOwnerMobileTask,sendOwnerMobileNotice,familyDotBridge};
}
