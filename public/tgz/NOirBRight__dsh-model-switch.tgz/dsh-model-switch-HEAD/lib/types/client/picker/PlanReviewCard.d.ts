import type { PendingQuestion } from '@deepseek-ai/dsh-client-ui-user-questions/client';
import type { ConfigFormSnapshot } from '@deepseek-ai/dsh-client-ui-settings/client';
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { MainSettingsView } from '../../client-contract.ts';
import { type PickerDirectoryFace } from './PickerDirectory.ts';
import type { PickerInteractionOperations } from './popup-dismissal.ts';
import { type RuntimeProviderLock } from '../runtime-lock.ts';
export interface PlanReviewFace extends PickerDirectoryFace {
    available: boolean;
    resolveInteractionOperations?: () => PickerInteractionOperations | undefined;
    /** Resolve a provider key to its ProviderDirectory role for runtime icons. */
    roleOf?: (providerKey: string) => string | undefined;
    /** Shared native-binding lock state for the seat session. */
    providerLockStore: {
        subscribe: (listener: () => void) => () => void;
        getSnapshot: () => {
            provider: RuntimeProviderLock;
            failed: boolean;
        };
    };
    /** Re-read the native binding now (mount, turn transitions, pre-selection). */
    refreshProviderLock: () => void;
    subscribeMainDefaults: (listener: () => void) => () => void;
    getMainDefaultsSnapshot: () => ConfigFormSnapshot<MainSettingsView>;
    /** Live catalog-group-id → card-key map from ProviderDirectory. */
    catalogRoutes?: () => Readonly<Record<string, string>>;
}
export type PlanReviewCardProps = PropsRuntime<'conversation.composer'> & PropsLocale<'composer-picker'> & InjectFace<PlanReviewFace> & {
    matched: PendingQuestion;
};
/** Match the model seat's admission guard before letting either picker offer a change. */
export declare function mainDefaultsUnavailableReason(snapshot: ConfigFormSnapshot<MainSettingsView>, t: PlanReviewCardProps['t']): string | undefined;
/** Inline failed lock-read status; history and log reading stay unaffected. */
export declare function ProviderLockHint(props: {
    t: PlanReviewCardProps['t'];
}): import("react").JSX.Element;
export declare function PlanReviewCard(props: PlanReviewCardProps): import("react").JSX.Element;
