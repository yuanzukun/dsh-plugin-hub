export const zh = {
  nav: '模型切换', title: '模型切换', subtitle: '为主会话、子代理和能力工具设置默认模型。修改只影响新请求。',
  conversationRoutes: '对话路由', capabilityRoutes: '能力路由', sendProtection: '发送保护', settingsSynced: '设置已同步', remoteSettingsUnavailable: '官方 DSH 在非本机浏览器禁用配置读取与写入；请在 Host 的 127.0.0.1 页面打开设置。', defaultBadge: '默认', cancel: '取消',
  compactOnSwitch: '切换时压缩', compactOnSwitchHelp: '发送且换了模型时，先按目标窗口检查上下文；超了就用切换前的模型压一次历史，再继续请求。只选模型、不发送，不会压缩。官方自动压缩和 /compact 不受影响。压缩会产生额外模型用量，摘要可能省略细节。',
  main: '主模型', provider: '提供商', model: '模型', providerDefault: '使用提供商默认值', providerDefaultShort: 'Provider 默认', effort: '推理强度', save: '保存', saving: '保存中…', saved: '已保存',
  subagent: '子代理默认路由', subagentHelp: 'DSH 已有官方子代理模型白名单：模型自己点名 provider/model 时以它为准。这里只在未点名时使用。', subagentOff: '未指定时使用官方继承', agentBadge: 'Agent',
  search: 'Web 搜索', searchHelp: '下拉选择的是期望使用的搜索 Adapter/模型；仅当全局 Web searchProvider=model-switch 时官方 web_search 才会使用该选择，否则保持原有路由不变。', image: '图像生成', imageHelp: '统一 generate_image 会调用所选 Codex 或 Grok Adapter；Provider 原有图片工具仍保留。', unavailable: '未接入', loading: '正在加载设置…', readonly: '设置为只读', requestFailed: '保存失败', catalogFailed: '无法加载模型目录。', conflict: '设置已在其他位置更改，请检查最新值后重试。',
  'reason.central-subagent-routing': 'Alpha.4 没有全局子代理启动路由接口。', 'reason.packaged-preset-roots': 'Alpha.4 不支持插件提供额外 preset root。', 'reason.tool-owner-suppression': 'Alpha.4 没有工具所有者或来源抑制接口。',
  'reason.search-provider-adapters': '当前公开版本没有可按模型切换的搜索 Provider Adapter。', 'reason.vision-provider-adapters': '尚无 Provider 注册可独立路由的 Vision Adapter。', 'reason.image-provider-adapters': '当前公开版本没有图像生成 Provider Adapter。',
} as const

export const en: Record<keyof typeof zh, string> = {
  nav: 'Model Switch', title: 'Model Switch', subtitle: 'Set default models for Main, Subagents, and capability tools. Changes affect new requests only.',
  conversationRoutes: 'Conversation routes', capabilityRoutes: 'Capability routes', sendProtection: 'Send protection', settingsSynced: 'Settings synced', remoteSettingsUnavailable: 'Official DSH disables settings reads and writes in non-loopback browsers. Open Settings on the Host loopback URL to edit model routes.', defaultBadge: 'Default', cancel: 'Cancel',
  compactOnSwitch: 'Compact on switch', compactOnSwitchHelp: 'When a sent message uses a new model, check the target window first. If needed, compact history with the previous model, then continue. Choosing a model does not compact. Official automatic compaction and /compact are unchanged. Compaction uses extra model quota and may omit details.',
  main: 'Main model', provider: 'Provider', model: 'Model', providerDefault: 'Provider default', providerDefaultShort: 'Provider default', effort: 'Reasoning effort', save: 'Save', saving: 'Saving…', saved: 'Saved',
  subagent: 'Default Subagent route', subagentHelp: 'DSH already has an official Allowlist for child models the agent names. This default applies only when the spawn names none.', subagentOff: 'Official inherit when unnamed', agentBadge: 'Agent',
  search: 'Web search', searchHelp: 'The dropdown selects the requested search adapter/model. The official web_search uses it only when the global Web searchProvider is model-switch; otherwise the original route is unchanged.', image: 'Image generation', imageHelp: 'The stable generate_image tool calls the selected Codex or Grok Adapter; existing provider image tools remain available.', unavailable: 'Unavailable', loading: 'Loading settings…', readonly: 'Settings are read-only', requestFailed: 'Save failed', catalogFailed: 'Could not load the model catalog.', conflict: 'Settings changed elsewhere. Review the latest values and retry.',
  'reason.central-subagent-routing': 'Alpha.4 exposes no global Subagent start-routing seam.', 'reason.packaged-preset-roots': 'Alpha.4 exposes no plugin-owned preset root.', 'reason.tool-owner-suppression': 'Alpha.4 exposes no tool owner or provenance suppression seam.',
  'reason.search-provider-adapters': 'This release exposes no model-selectable Search provider adapter.', 'reason.vision-provider-adapters': 'No Provider has registered an independently routable Vision Adapter.', 'reason.image-provider-adapters': 'This release exposes no image-generation provider adapter.',
}

export type ModelSwitchLocaleKey = keyof typeof zh
