/**
 * src/client/twin-panel.js — 中栏大视图面板：UR 模型 + TCP 坐标系 gizmo + 轨迹 + 数值面板。
 *
 * ## 数据流（只读）
 * `state.getSnapshot()`（Task 6，轮询 host 的只读 `/twin/state`）
 *   → `interpolateAt(prev, cur, now())`（Task 4 平滑）
 *   → `fkChain(kin, q)`（Task 3，运动学链取自构建期内联的 `assets/kinematics.json`）
 *   → `handle.applyFK(result)`（Task 7 写姿态）
 *   → `sceneHandle.render()`（Task 7 的场景）
 * **本面板不下发任何机器人指令**：没有 `fetch`、没有写路由、没有 MCP 工具调用。
 *
 * ## Ruling 29（依赖注入，硬约束）
 * `WebGLRenderer` 要真实 WebGL 上下文、`requestAnimationFrame` 在 Node 里不存在
 * ⇒ 写死的面板**一行都测不了**（本环境又没有 GUI 做手动验收）。故全部外部副作用都从参数进来：
 * `sceneFactory` / `modelLoader` / `raf` / `caf` / `now`。**缺省值保持真实行为**，
 * 循环里一律用注入的 `raf`/`caf`，不直接摸全局。
 * DOM 也是注入的：面板从 `container.ownerDocument` 取文档（真实浏览器里就是 `document`），
 * 这样单测可以喂一个最小假 DOM。
 *
 * ## 关键实现约束（逐条对应计划 Task 8 Step 1）
 * - 模型入场景用 **`scene.add(handle.root)`**：Task 7 的 `assemble()` 已把 7 个装配组挂回 `root`，
 *   再手动 add `groups[0]` 会把它从 root 摘走。
 * - 轨迹的 `BufferGeometry` **预分配固定容量**（`TRAJECTORY_CAPACITY` 点），逐帧只覆写
 *   position 数据 + `setDrawRange`，**绝不每帧重建 geometry**；缓冲本身按容量与龄期双重淘汰。
 * - 数值面板**节流到 ~10 Hz**（`HUD_INTERVAL_MS`），不每帧写 DOM。
 * - 未连接：显示中文状态文案、隐藏 3D 视图、**不创建空场景、不 render**；恢复连接自动显示。
 * - 型号变化：重新 `modelLoader(id)`，新模型入场景、旧模型从场景摘除并 `dispose()`。
 * - `dispose()` 幂等：`caf` 停循环、释放模型与场景资源、清空 DOM、摘掉监听。
 *
 * ## 时间轴（偏差 D1，见报告）
 * 快照的 `ts` 来自 host（`lib/twin-routes.js` 的 `ts: Date.now()`，epoch 毫秒），
 * 而注入的 `now` 缺省是 `performance.now()`（原点不是 epoch）。两者直接相减会让
 * `interpolateAt` 的 alpha 恒被钳到 0（= 永远显示上一帧采样、永不插值）。
 * ⇒ 面板用**相对增量锚定**把快照时间戳映射到 `now()` 的时钟轴上（只做加法，不改采样间隔），
 * 于是两种时钟域都能得到正确的 alpha；宿主时间倒退（重连/host 重启）时重新锚定并丢弃跨断层的插值对。
 *
 * ## 渲染滞后一个采样周期（fix round 1，控制器裁决 U2）
 * 只做上述锚定还不够：最新样本的**到达时刻 ≈ 它的产生时刻** ⇒ `now` 几乎总是 ≥ `cur.ts`，
 * alpha 仍被钳到 1，结果只是 ~10 Hz 阶梯、等于没有插值。
 * ⇒ 渲染时刻取 `now() - delayMs`，而 `delayMs = cur.ts - prev.ts`（用宿主 ts 的差值**自校准**，
 * 不需要知道轮询间隔）：滞后恰好一个采样周期后，渲染时刻落在 `[prev.ts, cur.ts]` 内，
 * alpha ∈ (0,1)，帧与帧之间连续推进就是真正的插值平滑。
 * 采样间隔异常大（host 卡顿/丢帧）时滞后被钳到 `RENDER_DELAY_MAX_MS`，避免画面无限滞后在很久以前。
 * 只有单个样本（`prev` 为空）时不做插值，直接返回该样本。
 * 轨迹的时间戳**不**受这个滞后影响：轨迹按样本真实的 `ts` 记录（`pushTrajectorySample` 用 `snap.ts`）。
 */

import {
  BufferGeometry,
  DynamicDrawUsage,
  Float32BufferAttribute,
  Line,
  LineBasicMaterial,
} from 'three'

import kinematicsJson from '../../assets/kinematics.json' with { type: 'json' }
// 离线仿真开关与面板控制写路由的宿主路径常量（零依赖共享模块，与 state/stream 同一份真源）。
import { TWIN_JOG_PATH, TWIN_SIM_PATH, TWIN_STATE_PATH } from '../../lib/twin-paths.js'

import { createScene } from './robot/scene.js'
import {
  createTcpAxes,
  disposeTcpAxes,
  tcpAxesSizeFor,
  updateTcpAxesSize,
  TCP_AXES_SIZE,
} from './robot/tcp-axes.js'
import { linkLengthsFromKinematics, loadRobotModel, tintJointLinks } from './robot/loader.js'
import { singularityHint } from './robot/manipulability.js'
import { createGhostArm, disposeGhostArm } from './robot/ghost-arm.js'
import {
  createCogMarker,
  createForceArrow,
  createReachSphere,
  disposeOverlay,
  formatForce,
  reachRadiusFromKinematics,
  updateForceArrow,
} from './robot/overlays.js'
import { fkChain } from './robot/fk.js'
import { interpolateAt } from './robot/interpolate.js'
import { pushSample, trajectoryColors, trajectoryCsv, trajectoryPoints } from './robot/trajectory.js'
import { injectStyles } from './styles.js'
import {
  buildRail,
  createMotionLock,
  mountRightRail,
  stageColumns,
} from './twin-controls.js'
import { liveStrings } from './strings.js'
import { resolveTheme, watchTheme } from './theme.js'

/**
 * 当前语言的文案表（清单第 15 条）。
 *
 * ⚠️ **必须定义在模块最前面**：下面的 `SAFETY_TEXT = S.safetyMode` 等映射表在**模块求值期**
 * 就会读它，放到后面会直接 TDZ 报错（`Cannot access 'S' before initialization`）。
 *
 * 用 `liveStrings()` 而不是绑死的 `activeStrings()`：桌面切换语言时改的是 `<html lang>`，
 * 面板下一次渲染就取到新语言，不需要刷新页面。`STATUS_*` 等导出常量刻意保持
 * 中文原样 —— 它们是大量既有测试的断言目标，而运行时一律走这里。
 */
const S = liveStrings()
import { captureTwinPng, downloadDataUrl, screenshotFileName } from './robot/screenshot.js'

/* ------------------------------------------------------------------ *
 * 常量（可单测的纯数据）
 * ------------------------------------------------------------------ */

/** 轨迹 `BufferGeometry` 的预分配容量（点）。超过就淘汰最老的，**不重建 geometry**。 */
export const TRAJECTORY_CAPACITY = 600

/** 轨迹样本最大保留时长（毫秒，按快照自带 ts 的差值计）。 */
export const TRAJECTORY_MAX_AGE_MS = 60_000

/** 数值面板节流间隔（毫秒）≈ 10 Hz。 */
export const HUD_INTERVAL_MS = 100

/**
 * 多久没有**新的采样**就把数据通道标成"停滞"（毫秒）。
 *
 * 宿主按 100 ms 一帧推流，正常时 2.5 s 意味着"少了二十多帧"。之所以必须有这条判据：
 * 机器人运动时 Python worker（单线程 stdin 队列）被运动指令占住，仿真的读会排队 ——
 * 以前宿主在那种情况下**一个事件都不发**，画面就静静停在最后一帧，界面上没有任何提示。
 * 现场最危险的误导就是"看着像静止、其实数据早停了"。
 */
export const FEED_STALE_MS = 2500

/** 停滞超过这个时长就**强制重建**数据通道（毫秒）：退避定时器可能被浏览器节流，不能干等。 */
export const FEED_RECONNECT_MS = 10000

/**
 * 型号加载失败后的重试间隔（毫秒）。
 *
 * 型号是**数据驱动**的：宿主每帧都告诉我们"这个 IP 上的机器人报的是什么型号"。
 * 加载失败（GLB 一时取不到、WebGL 上下文正在恢复）时如果就此把请求记成"已处理"，
 * 仿真会**永远**停在上一个型号的网格上，而面板上连一句"它说的是另一台"都没有。
 * 所以失败要能重试，但也不能每帧（60 Hz）重试 —— 隔一段时间再试。
 */
export const MODEL_RETRY_MS = 3000

/** 两次强制重建之间的最小间隔（毫秒），避免对一条真的连不上的通道反复拆建。 */
export const FEED_RETRY_INTERVAL_MS = 10000

/** 数据停滞/重连时那行提示的前缀（与既有状态行分开，避免与「未连接」语义混淆）。 */
export const FEED_STALE_PREFIX = '数据已停止更新'
/** 正在重连时的提示。 */
export const FEED_RETRYING_TEXT = '数据通道重连中…'

/** 渲染滞后的下限（毫秒）：采样间隔退化（≤0 / 非有限）时退化为"不滞后"。 */
export const RENDER_DELAY_MIN_MS = 0

/**
 * 渲染滞后的上限（毫秒）。
 * host 卡顿/丢帧导致采样间隔异常大时，滞后不能跟着无限增长，否则画面会"卡在很久以前"。
 */
export const RENDER_DELAY_MAX_MS = 400

/** TCP 坐标系 gizmo 的轴长（米）——与机械臂尺度（~0.8 m）相称，肉眼可见又不喧宾夺主。 */
export { TCP_AXES_SIZE }

/** 未连接时的中文状态文案。 */
export const STATUS_DISCONNECTED = '未连接机器人'
/** 已连接但模型尚未就绪。 */
export const STATUS_LOADING = '已连接 · 正在加载模型…'
/** 已连接（前缀，后面接型号）。 */
export const STATUS_CONNECTED = '已连接'
/** 近似几何体回退提示后缀。 */
export const STATUS_FALLBACK_SUFFIX = '（无内置模型，使用近似几何体）'
/** 渲染异常前缀（帧内异常被吞掉并显示，不影响循环存活）。 */
export const STATUS_ERROR_PREFIX = '渲染异常：'
/**
 * 渲染异常在错误行上的**最短驻留时间**（毫秒）。
 *
 * 以前是"下一帧成功就清空"——60 Hz 下等于亮 16 ms，人眼根本读不到；而它恰恰是"这一帧为什么
 * 没画出来"的唯一线索。现在至少留 5 s（或直到用户下一次操作），长到能看清、又不至于占住错误行。
 */
export const ERROR_HOLD_MS = 5000
/** 模型加载失败前缀。 */
export const STATUS_LOAD_FAILED = '模型加载失败：'
/** 3D 不可用（没有 WebGL）时的回退文案：数值通道仍然可用。 */
export const STATUS_NO_WEBGL = '当前环境不支持 WebGL：已切换为纯数值模式（关节角与 TCP 仍会更新）'
/** 位姿载荷不完整（q 不足 6 维）时的提示。 */
export const STATUS_INCOMPLETE = '机器人未返回完整的关节角'
/** 上下文丢失提示。 */
export const STATUS_CONTEXT_LOST = '3D 上下文丢失（GPU 重置）—— 收起并重新展开面板可恢复'
/** 安全模式异常时跟在模式名后面的处置提示（状态行会用它取代常规的「已连接 · 型号」）。 */
export const STATUS_SAFETY_HINT = '机器人可能已停止，请检查示教器'

/**
 * 把 host 给的 `code` 翻译成一句人话。
 *
 * 为什么需要：host 的失败响应里既有 `code` 也有 `reason`，但客户端以前**只**渲染一句固定的
 * 「未连接机器人」——于是"worker 进程挂了"、"机器人没连上"、"两台机器人有歧义"这三种完全
 * 不同的处置方式在界面上长得一模一样（而且歧义那种情况还会永远白轮询下去）。
 *
 * @param {string} code host 的机器可读错误码
 * @param {string} reason host 附带的原因（可能为空）
 * @param {string[]} ips 歧义时 host 给出的候选
 * @returns {string} 面向用户的状态文案
 */
export function describeDisconnected(code, reason, ips) {
  switch (code) {
    case 'no_robot':
      return S.disconnectNeverConnected
    case 'robot_not_connected':
      return S.disconnectReason(reason)
    case 'ambiguous_robot':
return S.disconnectAmbiguous(S.disconnectCandidates(ips))
    case 'worker_unavailable':
      return S.disconnectWorkerDown(reason)
    case 'robot_error':
      return S.disconnectReadFailed(reason)
    default:
      return reason ? S.disconnectReason(reason) : S.statusDisconnected
  }
}

/** 构建期内联的运动学表（14 个型号；esbuild 会把 JSON 直接打进 bundle，无运行时读取）。 */
export const KINEMATICS = kinematicsJson

/** 型号缺失时的兜底运动学键（`assets/kinematics.json` 必含）。 */
export const DEFAULT_KINEMATICS_KEY = 'ur3'

/**
 * **绝对取景**用的参考半径（米）：全部内置型号里**最大**的那个可达上界（UR20≈2.17 m）。
 *
 * 为什么需要它：取景默认按**当前型号自己的包围盒**自适应（换小臂不至于贴脸、换大臂不至于出画），
 * 代价是**每个型号在画面里都撑满** —— 机型长度差 2.7 倍、可达范围差 2.7 倍，画面上却
 * "看起来一样大"（用户 2026-10-12 的反馈）。所以打开「可达范围」图层时改用这个固定半径取景：
 * 所有型号共用**同一把尺子**，UR3 的可达球（≈0.80 m）只占画面约 37%，UR20 的（≈2.17 m）正好撑满，
 * 基座网格也随取景半径变成固定刻度。
 */
export const REACH_VIEW_RADIUS = Math.max(
  0,
  ...Object.values(KINEMATICS).map((entry) => reachRadiusFromKinematics(entry?.links) ?? 0),
)

/**
 * 型号 id → 运动学链（纯函数，可单测）。
 *
 * 未知/空型号**不抛错**，退回 `DEFAULT_KINEMATICS_KEY`（再退到表里第一项），
 * 这样机器人报出一个我们没有资产的型号时面板仍能摆姿态而不是每帧抛异常。
 *
 * @param {string} modelId 型号（大小写不敏感，如 `UR5E` / `ur5e`）
 * @returns {{links: Array<object>, jointLimits?: number[][]}|null}
 */
export function resolveKinematics(modelId) {
  const table = KINEMATICS ?? {}
  const id = String(modelId ?? '').trim().toLowerCase()
  return table[id] ?? table[DEFAULT_KINEMATICS_KEY] ?? Object.values(table)[0] ?? null
}

/**
 * 6 关节角（**弧度**）→ 数值面板文本（**度**）。
 *
 * @param {number[]} joints 关节角（弧度）
 * @returns {string} 如 `关节角 (°)  J1 5.7  J2 -22.9  …`
 */
export function formatJoints(joints) {
  const parts = []
  for (let i = 0; i < 6; i++) {
    const v = joints?.[i]
    const deg = Number.isFinite(v) ? (v * 180) / Math.PI : null
    parts.push(`J${i + 1} ${deg === null ? '--' : deg.toFixed(1)}`)
  }
  return `${S.jointsPrefix}  ${parts.join('  ')}`
}

/**
 * 找出**超出关节限位**的关节编号（1 基）。
 *
 * `kinematics.json` 里每个型号都带 `jointLimits`（`[[min,max], …]`，个别关节是 `null`），
 * 但在此之前客户端从未用过它。这是**零新增数据**的可视化：超限了就直接在 HUD 上标出来，
 * 而不是让操作员自己去比对六个数字。
 *
 * 纯函数：缺值、`null` 限位、长度不齐一律跳过而不是抛错 —— 一个畸形的限位表不该让整块
 * HUD 停止更新。
 *
 * @param {ArrayLike<number>} joints 六个关节角（弧度）
 * @param {ArrayLike<ArrayLike<number>|null>} limits 与 `joints` 对齐的限位表
 * @returns {number[]} 超限关节编号（1 基，升序）
 */
export function overLimitJoints(joints, limits) {
  if (joints == null || limits == null) return []
  const over = []
  const count = Math.min(joints.length ?? 0, limits.length ?? 0)
  for (let i = 0; i < count; i++) {
    const limit = limits[i]
    const value = joints[i]
    // 必须先确认限位是数组：`limit = 0` 这种坏数据会让数组解构直接抛 TypeError，
    // 而那会打断整帧、让 HUD 停在上一笔读数上。
    if (!Array.isArray(limit) || !Number.isFinite(value)) continue
    const [min, max] = limit
    if (!Number.isFinite(min) || !Number.isFinite(max)) continue
    // 反转区间（min > max）是坏数据：拿它去判定只会凭空把好关节标红，直接跳过。
    if (min > max) continue
    if (value < min || value > max) over.push(i + 1)
  }
  return over
}

/**
 * TCP 六维 → 数值面板文本（位置 4 位小数 / 姿态 3 位小数）。
 *
 * ⚠️ 姿态三个数 `rx/ry/rz` 是 UR 的**轴角旋转向量**（方向=旋转轴、模长=旋转角，弧度），
 * **不是** roll/pitch/yaw。以前只写 `rx ry rz` 会让人按 RPY 去读，从而得出错误的朝向。
 *
 * @param {number[]} tcp `[x, y, z, rx, ry, rz]`
 * @returns {string} 如 `TCP(米/轴角弧度)  x 0.1234  y -0.2345  z 0.3456  rx 0.000  ry 0.000  rz 0.000`
 */
export function formatTcp(tcp) {
  const names = ['x', 'y', 'z', 'rx', 'ry', 'rz']
  const parts = names.map((n, i) => {
    const v = tcp?.[i]
    if (!Number.isFinite(v)) return `${n} --`
    return `${n} ${v.toFixed(i < 3 ? 4 : 3)}`
  })
  return `${S.tcpPrefix}  ${parts.join('  ')}`
}

/* ------------------------------------------------------------------ *
 * detail=1（dashboard 侧状态）—— 纯映射，可单测
 * ------------------------------------------------------------------ */

/**
 * 安全模式原始串 → 中文。**未知值原样返回**：宁可显示 `SOMETHING_NEW` 也不要显示空白，
 * 否则固件新增一个模式时界面会假装"一切正常"。
 */
const SAFETY_TEXT = S.safetyMode

/** 机器人模式原始串 → 中文（未知值原样返回）。 */
const ROBOT_MODE_TEXT = S.robotMode

/** 程序状态原始串 → 中文（未知值原样返回）。 */
const PROGRAM_STATE_TEXT = S.programState

/**
 * dashboard 查询失败时 host 给的哨兵值（见 `python/ur_worker.py` 的 `dash()`）：
 * 语义是"这个字段没问到"，与"字段为空"不是一回事。
 */
export const DETAIL_QUERY_FAILED = '<查询失败>'

/** 把原始状态串翻成人话；空值/缺失/查询失败都有明确文案。 */
function translate(raw, table) {
  const value = typeof raw === 'string' ? raw.trim() : ''
  if (value === '') return '--'
  if (value === DETAIL_QUERY_FAILED) return S.queryFailed
  return table[value] ?? value
}

/**
 * 数据通道健康度 → 一行提示（纯函数，可单测）。
 *
 * 返回空串表示"通道正常，不必占用界面"。
 *
 * @param {object} input
 * @param {string} [input.status] `state.getStreamHealth().status`
 *   （`idle` / `connecting` / `open` / `retrying` / `unsupported` / `polling`）
 * @param {boolean} [input.connected] 最近一帧是否"确实连着机器人"
 * @param {boolean} [input.feedStale] 宿主自报"这一帧读还没回来"
 * @param {number} [input.ageMs] 距最近一次新采样的毫秒数
 * @param {number} [input.frames] 已收到的帧数（诊断）
 * @param {number} [input.frameErrors] 单帧失败次数（诊断）
 * @returns {string} 一行提示；通道正常时为空串
 */
export function describeFeedHealth(input = {}) {
  const status = typeof input.status === 'string' ? input.status : ''
  const frames = Number.isFinite(input.frames) ? input.frames : 0
  const errors = Number.isFinite(input.frameErrors) ? input.frameErrors : 0
  const diag = `（已收 ${frames} 帧${errors > 0 ? `，失败 ${errors} 帧` : ''}）`
  if (status === 'unsupported') return `当前环境没有 EventSource：${FEED_STALE_PREFIX}${diag}`
  // "正在重连"优先展示：这时用户最需要知道的是"它在自己恢复"，而不是"画面为什么不动"。
  if (status === 'retrying' || status === 'connecting') return `${FEED_RETRYING_TEXT}${diag}`
  const ageMs = Number.isFinite(input.ageMs) ? Math.max(0, input.ageMs) : 0
  if (input.feedStale === true || ageMs > FEED_STALE_MS) {
    // 未连接时"数据停滞"已经是状态行的语义（未连接机器人），这里不重复刷屏。
    if (input.connected !== true) return ''
    return `${FEED_STALE_PREFIX} ${(ageMs / 1000).toFixed(1)}s · 正在重试${diag}`
  }
  return ''
}

/** @param {unknown} raw `detail.safety_mode` @returns {string} 中文安全模式 */
export const describeSafetyMode = (raw) => translate(raw, SAFETY_TEXT)
/** @param {unknown} raw `detail.robot_mode` @returns {string} 中文机器人模式 */
export const describeRobotMode = (raw) => translate(raw, ROBOT_MODE_TEXT)
/** @param {unknown} raw `detail.program_state` @returns {string} 中文程序状态 */
export const describeProgramState = (raw) => translate(raw, PROGRAM_STATE_TEXT)

/**
 * 安全模式是否"需要操作员立刻看一眼"。
 *
 * `NORMAL` / `REDUCED` 是正常运行态；**查询失败与未知值都算异常**（宁可多提醒一次，
 * 也不要因为固件换了个字符串就把一次保护性停止显示成正常）。
 * 没有 detail（还没问到）时返回 false —— 那是"未知"，不是"异常"。
 *
 * @param {unknown} raw `detail.safety_mode`
 * @returns {boolean}
 */
export function isSafetyHazard(raw) {
  if (typeof raw !== 'string') return false
  const value = raw.trim().toUpperCase()
  if (value === '') return false
  return value !== 'NORMAL' && value !== 'REDUCED'
}

/**
 * 速度倍率 → `x1.00`。宿主给的是 0–1 的比例（`model.SpeedScaling()`）。
 *
 * @param {unknown} raw `detail.speed_scaling`
 * @returns {string}
 */
export function formatSpeedScaling(raw) {
  const value = typeof raw === 'number' ? raw : Number(raw)
  if (!Number.isFinite(value)) return '--'
  return `x${value.toFixed(2)}`
}

/**
 * 六路关节量 → 紧凑一行（HUD 里的关节角/温度共用这个形状）。
 *
 * @param {unknown} values 六元数组
 * @param {string} label 行首标签
 * @param {number} [digits=0] 小数位
 * @param {string} [unit=''] 单位后缀
 * @returns {string}
 */
function formatJointRow(values, label, digits = 0, unit = '') {
  if (!Array.isArray(values) || values.length === 0) return `${label}  --`
  const parts = []
  for (let i = 0; i < values.length; i++) {
    const v = values[i]
    parts.push(`J${i + 1} ${Number.isFinite(v) ? v.toFixed(digits) + unit : '--'}`)
  }
  return `${label}  ${parts.join('  ')}`
}

/**
 * detail → HUD 几行文本（纯函数）。
 *
 * 返回的每一行都可能为空串（表示"这一项这次没有"），由调用方决定是否保留旧的 DOM 内容。
 *
 * @param {object|null|undefined} detail host 的 `body.detail`
 * @returns {{status: string, temps: string, power: string, hazard: boolean}}
 */
export function formatDetail(detail) {
  const d = detail && typeof detail === 'object' ? detail : null
  if (d === null || typeof d.error === 'string') {
    // detail 通道自己报错（host 把 dashboard 失败包成 `{error}`）：如实说，不冒充"没有异常"。
    return {
      status: d?.error ? S.detailStatusFailed(d.error) : '',
      temps: '',
      power: '',
      currents: '',
      tcpSpeed: '',
      hazard: false,
    }
  }
  const bits = [
    `安全 ${describeSafetyMode(d.safety_mode)}`,
    `模式 ${describeRobotMode(d.robot_mode)}`,
    `程序 ${describeProgramState(d.program_state)}`,
    `速度 ${formatSpeedScaling(d.speed_scaling)}`,
  ]
  if (d.running === true) bits.push(S.detailRunning)
  /*
   * 估算标注（P1）：仿真下这几行是**运动学估算**（宿主用 `telemetry_estimated` 标出来），面板必须
   * 一并说出来 —— 否则界面显示的是"和真机一样的数字"，工具回复里那句"估算，不是测量"就丢了。
   */
  const est = d.telemetry_estimated === true ? S.detailEstimatedSuffix : ''
  const withEst = (row) => (row === '' || row === undefined ? '' : `${row}${est}`)
  const speed = tcpSpeedLine(d.tcp_speed)
  return {
    status: bits.join('  '),
    temps: withEst(formatJointRow(d.joint_temperatures, S.detailTempsPrefix)),
    power: Number.isFinite(Number(d.robot_voltage)) && Number.isFinite(Number(d.robot_current))
      ? withEst(S.detailBus(Number(d.robot_voltage).toFixed(1), Number(d.robot_current).toFixed(2)))
      : '',
    // 这两个字段（关节电流、TCP 速度）本来就在 detail 里传到客户端了，只是没人渲染（P1 补上）。
    currents: withEst(Array.isArray(d.joint_currents)
      ? formatJointRow(d.joint_currents, S.detailCurrentsPrefix, 2)
      : ''),
    tcpSpeed: withEst(speed),
    hazard: isSafetyHazard(d.safety_mode),
  }
}

/** TCP 速度行：六维向量取**线速度模长**（`[vx,vy,vz,ωx,ωy,ωz]`）；拿不到就给空串，不编数字。 */
function tcpSpeedLine(value) {
  if (!Array.isArray(value) || value.length < 3) return ''
  const [vx, vy, vz] = value.slice(0, 3).map(Number)
  if (!Number.isFinite(vx) || !Number.isFinite(vy) || !Number.isFinite(vz)) return ''
  return S.detailTcpSpeed(Math.hypot(vx, vy, vz).toFixed(3))
}

/** 视图预设按钮（顺序即 UI 顺序；`reset` 是"对准当前模型"而不是某个固定方向）。 */
export const VIEW_BUTTONS = [
  { key: 'reset', label: S.viewReset },
  { key: 'iso', label: S.viewIso },
  { key: 'front', label: S.viewFront },
  { key: 'side', label: S.viewSide },
  { key: 'top', label: S.viewTop },
]

/**
 * 渲染滞后（毫秒）：**自校准**为"一个采样周期"，使渲染时刻恰好落在最近两个样本的时间窗内。
 *
 * 间隔用样本自己的 ts 差值度量 ⇒ 与轮询间隔无关（无需把 `baseMs` 传进来），
 * host 卡顿/丢帧导致间隔异常大时由 `RENDER_DELAY_MAX_MS` 兜底。
 * 间隔非法（≤0 / 非有限）时退化为 `RENDER_DELAY_MIN_MS`（不滞后）。
 *
 * @param {{q: number[], ts: number}} prev 前一个样本
 * @param {{q: number[], ts: number}} cur 当前样本
 * @returns {number} 滞后毫秒数，落在 [RENDER_DELAY_MIN_MS, RENDER_DELAY_MAX_MS]
 */
export function renderDelayMs(prev, cur) {
  const span = cur?.ts - prev?.ts
  if (!Number.isFinite(span)) return RENDER_DELAY_MIN_MS
  return Math.min(RENDER_DELAY_MAX_MS, Math.max(RENDER_DELAY_MIN_MS, span))
}

/* ------------------------------------------------------------------ *
 * 内部小工具
 * ------------------------------------------------------------------ */

/** 建一个带 class（可选 data 标记）的元素。 */
function makeEl(doc, tag, className, dataAttr) {
  const node = doc.createElement(tag)
  if (className) node.className = className
  if (dataAttr) node.setAttribute(dataAttr, '')
  return node
}

/** 从场景摘掉一个对象（优先用场景的 remove；没有则退回父节点摘除）。 */
function detach(scene, obj) {
  if (!obj) return
  if (typeof scene?.remove === 'function') scene.remove(obj)
  else obj.parent?.remove?.(obj)
}

/** 本插件挂进场景的机器人根节点名 —— 换型号时"清空原有机器人"只认这个名字。 */
const ROBOT_ROOT_NAME = 'ursim-twin-robot'

/**
 * 工程辅助图层的**默认开关状态**（单一真源）。
 *
 * 「基座系」默认开：用户要求 3D 界面底部那颗 `基座系` 按钮默认就是选中态（一眼看清基座
 * 坐标系朝向，才读得懂 TCP 位姿的正负）。「幽灵臂」保持默认开（目标与当前不一致时才显现）。
 * 「可达范围」「受力」默认关 —— 一次全画出来会看不清真臂。
 *
 * 按钮的 `aria-pressed` 与场景里各对象的 `visible` 都从这里出发，避免"按钮看着没按、
 * 场景里其实画着"这种表里不一（`layers` 在场景构建里定义，比 HUD 按钮晚）。
 */
const LAYER_DEFAULTS = Object.freeze({ reach: false, base: true, force: false, ghost: true })

/**
 * 摘掉场景里**除 `keep` 之外**的所有本插件机器人根节点。
 *
 * 正常路径由 `detach(handle.root)` + `handle.dispose()` 负责；这一层是兜底：异常路径（加载
 * 中途失败、重复挂载、上一次 dispose 没摘干净）下旧节点可能留在场景里，两个型号的网格叠在
 * 一起比不显示更糟 —— 分不清正在看的是哪一台。
 *
 * 只认自己的名字、且**只摘不 dispose**：几何体可能与即将挂上的新句柄共享（loader 有缓存），
 * 在这里释放会把新机器人一起毁掉。幽灵臂的根节点名是 `ursim-twin-ghost-arm`，不在此列。
 */
function removeStrayRobots(scene, keep) {
  if (!scene || !Array.isArray(scene.children)) return
  for (const child of scene.children.slice()) {
    if (!child || child === keep) continue
    if (child.name !== ROBOT_ROOT_NAME) continue
    detach(scene, child)
  }
}

/* ------------------------------------------------------------------ *
 * 面板
 * ------------------------------------------------------------------ */

/**
 * 在 `container` 里挂载数字仿真大视图面板。
 *
 * @param {object} options
 * @param {HTMLElement} options.container 宿主容器（其 `ownerDocument` 决定用哪个文档）
 * @param {{getSnapshot: () => object, subscribe?: Function}} options.state 只读状态源（Task 6）
 * @param {(canvas: HTMLCanvasElement, options?: {theme?: 'light'|'dark'}) => object} [options.sceneFactory=createScene]
 *   场景工厂（注入点）。第二个实参传当前主题，真实工厂据此选基座网格配色。
 * @param {(modelId: string) => Promise<object>} [options.modelLoader=loadRobotModel] 模型加载（注入点）
 * @param {(cb: Function) => number} [options.raf=globalThis.requestAnimationFrame] 帧调度（注入点）
 * @param {(id: number) => void} [options.caf=globalThis.cancelAnimationFrame] 帧取消（注入点）
 * @param {() => number} [options.now=() => performance.now()] 时钟（注入点）
 * @param {(url: string, init?: object) => Promise<{json: () => Promise<any>}>} [options.request=globalThis.fetch]
 *   HTTP 请求实现（注入点）。面板的写请求只有仿真开关这一类：`POST TWIN_SIM_PATH` 开关仿真。
 * @param {boolean} [options.autoSim=true] 打开面板时是否**主动进入离线仿真**
 *   （默认型号 UR12e、全零位、倍率 1；已经在仿真中则沿用那一台）。收起面板时停仿真。
 *   注入点存在是为了给"不想自动开仿真"的宿主留口子，也让其余用例不必被这套默认行为干扰。
 * @returns {{dispose: () => void}} 幂等的卸载句柄
 */
export function mountTwinPanel({
  container,
  state,
  sceneFactory = createScene,
  modelLoader = loadRobotModel,
  raf = globalThis.requestAnimationFrame,
  caf = globalThis.cancelAnimationFrame,
  now = () => performance.now(),
  request = globalThis.fetch,
  autoSim = true,
} = {}) {
  if (!container || typeof container.appendChild !== 'function') {
    throw new TypeError('mountTwinPanel: 需要一个可用的 container 元素')
  }
  const doc = container.ownerDocument ?? globalThis.document
  if (!doc || typeof doc.createElement !== 'function') {
    throw new TypeError('mountTwinPanel: 需要可用的 DOM（container.ownerDocument 或 globalThis.document）')
  }

  injectStyles(doc)

  /* ---------------- 可变状态 ---------------- */
  let disposed = false
  /**
   * 当前主题（`light` / `dark`）。
   *
   * 面板 CSS **不需要**它：`styles.js` 的颜色全走 `--dsw-*` token，宿主 token 会随
   * `body[data-ds-dark-theme]` 自己翻转。这个值只为 WebGL 侧服务 —— 基座网格线的颜色
   * 烘在几何体顶点色里，CSS 管不到（见 `theme.js` 与 `scene.js` 的 `paintBaseGrid`）。
   */
  let theme = resolveTheme({ document: doc, window: doc.defaultView ?? globalThis })
  let frameId = null
  let sceneHandle = null
  let handle = null // Task 7 的模型句柄
  let requestedModelId = '' // 最近一次请求加载的型号（小写）
  let loadedModelId = '' // 已挂进场景的型号（小写）
  let loadToken = 0 // 型号重建的代次，避免旧加载覆盖新模型
  /** 加载失败且**尚未重试**的型号（小写）：同一个型号的重试受 `MODEL_RETRY_MS` 节流。 */
  let failedModelId = ''
  /** 下一次允许重试该型号的时刻（面板时钟毫秒；0 = 不节流）。 */
  let modelRetryAtMs = 0
  let trajectory = []
  let lastTrajectoryTs = 0
  let lastSnapshotTs = null // 已消费的快照 ts（判断"是否新采样"）
  /** 最近一笔快照（截图水印要用它读型号/IP/读数）。 */
  let lastSnapshot = null
  /** 轨迹是否暂停记录（清单第 18 条）——暂停只停止记录，不清空已有的线。 */
  let trajectoryPaused = false
  /** 多机器人候选的最近一次签名（清单第 19 条）——只在变化时重建 DOM。 */
  let lastRobotsSignature = null
  let prevSample = null
  let curSample = null
  let clock = null // 快照时间戳 → now() 时钟轴的锚点
  let wasConnected = false
  let lastHudMs = -Infinity
  /** C1/C4 的"上次结果"：只在变化时动 DOM/材质（材质克隆是真实开销）。 */
  let lastRiskText = null
  let lastOverKey = null
  /** 模式角标的"上次显示"（模式 + 文案 + title）：`step()` 每帧都调，值没变就不写 DOM（P2）。 */
  let lastBadgeKey = null
  /** 面板根节点上 `data-ursim-twin-sim` 的上次写入值：每帧无条件写属性会持续触发样式重算（P2）。 */
  let lastSimAttr = null
  /** 错误行当前驻留的文案（空串=没有错误）与它的最早清除时刻（面板时钟毫秒）。 */
  let heldErrorText = ''
  let errorHoldUntilMs = 0
  /** 最近一次"尺寸还没量出来"的重试计数（见 ensureSized）。 */
  let pendingResize = false
  /** 3D 上下文是否已丢失（丢失后不再尝试渲染，只显示提示）。 */
  let contextLost = false
  /** 没有 WebGL 时置位：改用纯数值模式，不再尝试建场景。 */
  let sceneUnavailable = false
  /** 最近一次模型加载失败的原因（空串=没有失败）。 */
  let loadError = ''
  /** host 报告位姿载荷不完整（q 不足 6 维）。 */
  let snapDegraded = false
  /** detail 里的安全模式是否处于异常态（状态行据此在保护性停止时让位）。 */
  let snapHazard = false
  /**
   * 数据通道看门狗（0.6.6）。
   *
   * `lastFeedAtMs` / `lastFeedTs`：最近一次**看到新采样**的面板时刻与它对应的快照 ts。
   * `lastFeedRetryMs`：最近一次强制重建通道的时刻（节流）。
   * `lastFeedText`：最近写进提示行的文本（避免每帧写 DOM）。
   */
  let lastFeedAtMs = null
  let lastFeedTs = null
  let lastFeedRetryMs = -Infinity
  let lastFeedText = null
  /**
   * 按需渲染的脏标记：只有"确实有新东西要画"时才调用 `render()`。
   *
   * 以前是**每帧无条件渲染**：机器人静止时画面完全没变也照画 60 fps；未连接时虽然 `step()`
   * 提前返回，循环末尾仍会渲染一帧空场景 —— 纯烧 GPU。现在帧循环照旧跑（成本只是一次函数
   * 调用），但 `render()` 只在 `dirty` 或插值窗口内发生。
   */
  let dirty = true
  /** 插值推进到此毫秒之前必须连续出帧（否则平滑会退化成阶梯）。 */
  let animatingUntil = -Infinity
  /**
   * 最近一次真正算出来的 FK 结果（`applyPoseToScene` 的返回值）。
   *
   * 静止帧（见 `step()` 里的 `staticFrame`）直接复用它，于是**不重算** FK / 姿态矩阵 / 轨迹：
   * 那个结果与上一帧逐位相同，重算是纯浪费（60 Hz 全跑，而有新信息的只有 10 Hz 的采样与它
   * 之后的一小段插值窗口）。
   */
  let poseResult = null
  /**
   * 姿态是否已经**收敛到测量值**（插值窗口结束后的那一帧算完即置位）。
   *
   * 只有置位之后才允许复用 `poseResult`：窗口内最后一帧算的是内插值，而那之后的第一个静止帧
   * 才会把姿态精确收敛到"控制器最近报出的那一笔"。
   */
  let poseSettled = false
  /** 页面是否在后台。隐藏时**彻底停帧**（见 onVisibility / pauseLoop）。 */
  let hidden = doc.hidden === true

  /* ---------------- DOM ---------------- */
  const root = makeEl(doc, 'div', 'ursim-twin-panel', 'data-ursim-twin-panel')
  root.setAttribute('data-ursim-twin-connected', 'false')

  const view = makeEl(doc, 'div', 'ursim-twin-view', 'data-ursim-twin-view')
  const canvas = makeEl(doc, 'canvas', 'ursim-twin-canvas', 'data-ursim-twin-canvas')
  /*
   * 可访问性（清单第 16 条）：
   *
   * - canvas 对读屏软件完全不可见，所以给它 `role="img"` + `aria-label`，让"这里有一个
   *   3D 机器人视图"至少能被读出来；
   * - `tabindex="0"` 让它可聚焦 —— 只有能聚焦，下面的方向键才有意义；
   * - 方向键切视角预设（与工具栏同一套 `VIEW_PRESETS`）。这是纯键盘用户目前**唯一**能操作
   *   3D 的途径：OrbitControls 的旋转/缩放在鼠标之外没有等价键盘操作。
   */
  canvas.setAttribute('role', 'img')
  canvas.setAttribute('aria-label', S.canvasLabel)
  canvas.setAttribute('tabindex', '0')
  canvas.addEventListener('keydown', (event) => {
    const key = event?.key
    // 方向键映射到**工具栏已有的那套 key**（`iso`/`front`/`side`/`top` + 工具栏特殊处理的
    // `reset`）。⚠️ 别凭直觉造 key —— `VIEW_PRESETS` 里没有 `left`/`right`。
    const preset = key === 'ArrowUp' ? 'top'
      : key === 'ArrowDown' ? 'iso'
        : key === 'ArrowLeft' ? 'side'
          : key === 'ArrowRight' ? 'front'
            : key === 'Home' ? 'reset'
              : null
    if (preset === null) return
    event.preventDefault?.()
    applyView(preset)
  })
  view.appendChild(canvas)

  /*
   * 离线仿真的水印角标（0.7.0）。
   *
   * 贴在 3D 视图角上、`pointer-events:none`（不挡操作），只要这一帧来自仿真就显示。
   * 它存在的理由很直接：仿真里的机械臂动起来与真机**视觉上完全一样**，没有这个角标，
   * 站在旁边的人分不出"AI 在动真机"还是"AI 在动虚拟机器人"。
   */
  const simBadge = makeEl(doc, 'div', 'ursim-twin-sim-badge', 'data-ursim-twin-sim-badge')
  simBadge.setAttribute('title', S.simBadgeTitle)
  simBadge.textContent = S.simBadge
  simBadge.style.display = 'none'
  view.appendChild(simBadge)

  const hud = makeEl(doc, 'div', 'ursim-twin-hud', 'data-ursim-twin-hud')
  // HUD 是纯读数：`aria-live="polite"` 让关节角/TCP/状态的**变化**被播报，而不是每次都
  // 重读整块（`aria-atomic` 保持默认的 false）。
  hud.setAttribute('role', 'status')
  hud.setAttribute('aria-live', 'polite')
  hud.setAttribute('aria-label', S.hudLabel)
  // 多机器人选择（清单第 19 条）：host 在 2 台以上且未指定 ip 时返回歧义候选，这里给出切换入口。
  const hudRobots = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-robots')
  // 待审批的运动目标（清单第 8 条）：审批弹窗说"要动了"，这里同步写出"要往哪动"。
  const hudPending = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-pending')
  /**
   * 数据通道健康度（0.6.6）。
   *
   * **与身份行同一行显示**（用户要求）：状态行的语义是"机器人是什么状态"、这一行的语义是
   * "**数据**是什么状态"（停滞 / 正在重连），两者仍是两个不同的东西，只是不再各占一行 ——
   * 停滞提示紧跟在"机器人 <型号> · <IP>"后面（见下面 `hudIdentity.appendChild(hudFeed)`）。
   * 没有停滞时它是 `display:none`，这一行就只剩身份。
   */
  const hudFeed = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-feed')
  hudFeed.style.display = 'none'
  // 身份行放最上面：多机场景下"我在看哪一台"比任何读数都重要，而 `ip` 以前只被写进
  // `data-ursim-twin-ip` 属性、界面上一个字都看不到。
  const hudIdentity = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-identity')
  /**
   * 身份**文字**单独一个 `span`。
   *
   * ⚠️ 不能把文字直接写在 `hudIdentity` 上：DOM 里给 `textContent` 赋值会**移除该元素的全部子节点** ——
   * 那样第一帧 HUD 更新就会把并进这一行的数据停滞提示（`hudFeed`）删掉，界面上再也看不到它。
   * 所以身份文字有自己的节点，更新只碰它。
   */
  const hudIdentityText = makeEl(doc, 'span', 'ursim-twin-identity-text', 'data-ursim-twin-identity-text')
  /**
   * 控制轨**提示行与报错栏的共用槽位**（0.3.6 起错误行、0.3.8 起提示行）。
   *
   * 用户要求"把右轨顶部那两行（数据通道停滞提示 / 命令失败报错）移到身份行右侧、与系统报错栏共存"。
   * 这里只放一个**空壳 span**：真正的两个节点由 `mountRightRail` 通过 `deps.noteHost` /
   * `deps.errorHost` 挂进来（`noteHost === errorHost === hudIdentityError`），这样它们与身份文字同一行，
   * 而各条链路的写入互不覆盖 —— 系统级错误仍走 `errorLine`（`data-ursim-twin-error`），
   * 数据通道健康度仍走 `hudFeed`，命令失败/整块禁用则走这两个节点。
   *
   * 两个节点都有 `:empty { display: none }`：没有内容时槽位是空的，这一行就只剩身份文字。
   */
  const hudIdentityError = makeEl(doc, 'span', 'ursim-twin-identity-error', 'data-ursim-twin-identity-error')
  const hudJoints = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-joints')
  const hudTcp = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-tcp')
  // dashboard 侧状态（detail=1）：安全模式/机器人模式/程序状态/速度倍率一行，温度与母线一行。
  const hudDetail = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-detail')
  /*
   * 高频行对读屏**闭嘴**（P2）。
   *
   * 上面 HUD 容器是 `aria-live="polite"`：它的任何文本变化都会被播报。而下面这几行每 100 ms 就被
   * 整行重写一次（关节角/TCP/detail），读屏会在每个节拍把整段数字重新念一遍 —— 满屏数字被念成
   * 一串噪音，真正要报的"状态"反而淹在里面。所以逐行关掉 live，只让状态行（及风险/停滞提示）
   * 继续作为可播报的内容。容器本身保持 polite（既有测试与语义都依赖它）。
   */
  hudJoints.setAttribute('aria-live', 'off')
  hudTcp.setAttribute('aria-live', 'off')
  hudDetail.setAttribute('aria-live', 'off')
  const hudPower = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-power')
  /** 奇异点/可操作度提示行（0.1.11，C1）。 */
  const hudRisk = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-risk-row')
  hud.appendChild(hudRobots)
  hud.appendChild(hudPending)
  hud.appendChild(hudIdentity)
  // 数据通道健康度**并进身份行**：与"机器人 <型号> · <IP>"同一行、排在身份文字之后
  // （用户要求）。没有停滞时它是 `display:none`，这一行就只剩身份。
  hudIdentity.appendChild(hudIdentityText)
  hudIdentity.appendChild(hudFeed)
  // 控制轨的提示行/报错栏紧跟在数据停滞提示之后：同一行、独立槽位（见 `hudIdentityError` 的说明）。
  hudIdentity.appendChild(hudIdentityError)
  // 工程辅助图层的开关（清单第 9 条）。默认状态见 `LAYER_DEFAULTS`：`基座系` 与 `幽灵臂` 默认开，
  // 其余默认关（一次全画出来会看不清真臂）。
  //
  // 这里引用后面才定义的 `layers` 与 `invalidate` 是安全的：`layers` 只在**点击回调**里
  // 求值（那时早已初始化），`invalidate` 是函数声明、会提升。初始的 `aria-pressed` 直接取
  // `LAYER_DEFAULTS`，所以按钮的初始外观与场景里实际画着的对象始终一致。
  const hudLayers = makeEl(doc, 'div', 'ursim-twin-hud-row', 'data-ursim-twin-layers')
  /** 图层按钮句柄：可达范围那颗要顺带显示当前型号的可达上界（见 `loadModel`）。 */
  const layerButtons = {}
  // ⚠️ 这里**刻意不暴露"重心"图层**：`createCogMarker` 已经就绪，但插件目前**没有读回
  // 载荷的 op**（只有 `ursim_set_payload*`，没有对应的 get），打开它只会得到一个点了没反应的
  // 死按钮 —— 那比没有更糟。等补上读回接口再接（见交接账本）。
  for (const [layerKey, layerLabel] of [
    ['reach', S.layerReach],
    ['base', S.layerBase],
    ['force', S.layerForce],
    ['ghost', S.layerGhost],
  ]) {
    const button = makeEl(doc, 'button', 'ursim-twin-layer-toggle', `data-ursim-twin-layer-${layerKey}`)
    button.type = 'button'
    button.textContent = layerLabel
    button.setAttribute('aria-pressed', LAYER_DEFAULTS[layerKey] === true ? 'true' : 'false')
    layerButtons[layerKey] = button
    button.addEventListener('click', () => {
      layers[layerKey] = !layers[layerKey]
      button.setAttribute('aria-pressed', layers[layerKey] ? 'true' : 'false')
      applyLayers()
      // 「可达范围」图层决定取景尺度（固定参考 ↔ 型号自适应），切换时重新取景 ——
      // 否则打开图层看到的仍是"被自适应放大过"的可达球，比较不出来。
      if (layerKey === 'reach') frameView()
      invalidate()
    })
    hudLayers.appendChild(button)
  }
  hud.appendChild(hudLayers)
  // 截图导出（清单第 17 条）：带型号/IP/时间的 PNG，现场报障用（不必再拿手机拍屏幕）。
  const shotButton = makeEl(doc, 'button', 'ursim-twin-layer-toggle', 'data-ursim-twin-screenshot')
  shotButton.type = 'button'
  shotButton.textContent = S.screenshot
  shotButton.setAttribute('aria-label', S.screenshotLabel)
  shotButton.addEventListener('click', () => {
    /*
     * ⚠️ 顺序很关键：WebGL canvas 的绘制缓冲默认不保留，**让出控制权之后可能已被清空**，
     * 那样导出的是全黑图。所以先**同步**渲染这一帧，再**同步**取图，中间不能 await。
     */
    renderFrame()
    const target = sceneHandle?.renderer?.domElement ?? canvas
    const dataUrl = captureTwinPng(target, lastSnapshot, { document: doc })
    if (dataUrl === null) return
    downloadDataUrl(dataUrl, screenshotFileName(lastSnapshot, new Date()), { document: doc })
  })
  hudLayers.appendChild(shotButton)

  /*
   * 轨迹操作（清单第 18 条）：清空 / 暂停 / 导出。
   *
   * 原先只有一条单色线，既不能清、不能停、也拿不出来 —— 现场想"把刚才那段轨迹带走"
   * 是做不到的。导出走 CSV（复用截图那条 `downloadDataUrl`），带位置**也带关节角**。
   */
  const trajectoryButton = (label, key, onClick) => {
    const button = makeEl(doc, 'button', 'ursim-twin-layer-toggle', `data-ursim-twin-trajectory-${key}`)
    button.type = 'button'
    button.textContent = label
    button.setAttribute('aria-pressed', 'false')
    button.addEventListener('click', () => {
      onClick(button)
      invalidate()
    })
    hudLayers.appendChild(button)
    return button
  }

  trajectoryButton(S.trajectoryClear, 'clear', () => {
    trajectory = []
    trajGeometry.setDrawRange(0, 0)
  })

  trajectoryButton(S.trajectoryPause, 'pause', (button) => {
    trajectoryPaused = !trajectoryPaused
    button.setAttribute('aria-pressed', trajectoryPaused ? 'true' : 'false')
    button.textContent = trajectoryPaused ? S.trajectoryResume : S.trajectoryPause
  })

  trajectoryButton(S.trajectoryExport, 'export', () => {
    const csv = trajectoryCsv(trajectory)
    const dataUrl = `data:text/csv;charset=utf-8,${encodeURIComponent(csv)}`
    downloadDataUrl(dataUrl, `ursim-twin-trajectory-${screenshotFileName(lastSnapshot, new Date()).replace(/^ursim-twin-|\.png$/gu, '')}.csv`, { document: doc })
  })
  hud.appendChild(hudJoints)
  hud.appendChild(hudTcp)
  hud.appendChild(hudDetail)
  hud.appendChild(hudPower)
  hud.appendChild(hudRisk)

  /*
   * I/O 与寄存器读数（0.1.9）。
   *
   * ⚠️ **按需读**：折叠着就一个请求都不发（面板默认只读镜像真机，别让"展开一次"变成常态流量）。
   * 展开时：数字位与模拟输入随 HUD 节拍刷新；**寄存器只在展开的那一刻读一次** —— 它们是逐下标
   * getter，一次要 24 次往返，没有理由跟着刷新。
   */
  const ioBox = makeEl(doc, 'details', 'ursim-twin-io', 'data-ursim-twin-io')
  const ioSummary = makeEl(doc, 'summary', 'ursim-twin-io-summary', 'data-ursim-twin-io-summary')
  ioSummary.textContent = S.ioSummary
  const ioBody = makeEl(doc, 'div', 'ursim-twin-io-body', 'data-ursim-twin-io-body')
  /*
   * ⚠️ body 必须拆成**两个固定子节点**（与上面 `hudIdentityText` 是同一类问题的同一个正解）：
   * DOM 里给 `textContent` 赋值会**移除该元素的全部子节点**。以前读数与寄存器行同住 `ioBody`，
   * 而 1 Hz 的 HUD 节拍会调 `refreshIo(false)` **重新写一遍读数** ⇒ 刚展开时追加的寄存器行
   * 被整块清掉，最多闪一帧、之后再也不回来。
   * 现在两个分区各有自己的节点与 `data-*` 标记：`renderIo` 只写 `ioBits`，
   * `renderRegisters` 只写 `ioRegs`，互不相干。
   */
  const ioBits = makeEl(doc, 'div', 'ursim-twin-io-bits', 'data-ursim-twin-io-bits')
  const ioRegs = makeEl(doc, 'div', 'ursim-twin-io-regs', 'data-ursim-twin-io-regs')
  ioBody.appendChild(ioBits)
  ioBody.appendChild(ioRegs)
  ioBox.appendChild(ioSummary)
  ioBox.appendChild(ioBody)
  hud.appendChild(ioBox)

  /** 寄存器分片：类型与每片长度（宿主侧 `count` 上限 16）。 */
  const REGISTER_SETS = ['int', 'double', 'bit']
  const REGISTER_COUNT = 8
  /** 展开时的 I/O 刷新间隔：**1 Hz**（面板 HUD 是 10 Hz，但这两条 op 没必要跟着跑）。 */
  const IO_REFRESH_MS = 1000
  let lastIoMs = -Infinity
  /** 折叠着就一个请求都不发（见上面那段注释）。 */
  ioBox.addEventListener('toggle', () => {
    if (ioBox.open === true) {
      lastIoMs = -Infinity
      void refreshIo(true)
    }
  })

  /*
   * 视角工具栏。
   *
   * 以前没有任何找回视角的办法：OrbitControls 允许把相机推远/缩进机械臂内部，而面板只有
   * 一个画布 —— 唯一的"重置"是收起面板再展开。`scene.js` 的注释还提到过一个"重置视角"，
   * 但那个控件在面板里从未存在。这里补上：`reset` 按当前模型重新取景，其余四个是固定方向。
   */
  const toolbar = makeEl(doc, 'div', 'ursim-twin-toolbar', 'data-ursim-twin-toolbar')
  for (const button of VIEW_BUTTONS) {
    // 属性名不能叫 `data-ursim-twin-view` —— 视图容器本身就用着那个名字，查询会多命中一个容器。
    const el = makeEl(doc, 'button', 'ursim-twin-toolbar-button', 'data-ursim-twin-view-button')
    el.setAttribute('type', 'button')
    el.setAttribute('data-ursim-twin-view-button', button.key)
    el.setAttribute('title', button.label)
    el.textContent = button.label
    el.addEventListener('click', () => applyView(button.key))
    toolbar.appendChild(el)
  }

  const status = makeEl(doc, 'div', 'ursim-twin-status', 'data-ursim-twin-status')
  const errorLine = makeEl(doc, 'div', 'ursim-twin-error', 'data-ursim-twin-error')

  /*
   * ── 离线仿真开关（0.7.0）──────────────────────────────────────────────
   *
   * 默认**关**：面板保持"只读镜像真机"的原有行为。打开后，运动类工具驱动的是
   * `127.0.0.1` 上那台运动学虚拟机器人，面板跟着它动（数据源切到该地址），真机不受影响。
   *
   * 这是面板唯一会**写**的东西：POST 到宿主新增的 `TWIN_SIM_PATH`（见 lib/index.js 的
   * `isTrustedWrite`），而那条路由只能创建/销毁回环地址上的仿真 —— 结构上碰不到真机。
   *
   * 必选项：**型号**（决定网格/运动学/关节限位）之外，还给了**起始姿态**与**速度倍率**：
   * 没有起始姿态就没法确定"从哪里开始动"，没有速度倍率就没法复现"真机上速度被限住"的场景。
   */
  const simBar = makeEl(doc, 'div', 'ursim-twin-sim', 'data-ursim-twin-sim-bar')
  const simToggle = makeEl(doc, 'button', 'ursim-twin-sim-toggle', 'data-ursim-twin-sim-toggle')
  simToggle.setAttribute('type', 'button')
  simToggle.setAttribute('aria-pressed', 'false')
  simToggle.setAttribute('aria-label', S.simTitle)
  simToggle.textContent = S.simToggleOn
  simToggle.addEventListener('click', () => { void applySim(!simActive) })

  const simModelSelect = doc.createElement('select')
  simModelSelect.setAttribute('data-ursim-twin-sim-model', '')
  simModelSelect.setAttribute('aria-label', S.simModelLabel)
  const simPresetSelect = doc.createElement('select')
  simPresetSelect.setAttribute('data-ursim-twin-sim-preset', '')
  simPresetSelect.setAttribute('aria-label', S.simPresetLabel)
  const simSpeedSelect = doc.createElement('select')
  simSpeedSelect.setAttribute('data-ursim-twin-sim-speed', '')
  simSpeedSelect.setAttribute('aria-label', S.simSpeedLabel)

  const simNote = makeEl(doc, 'div', 'ursim-twin-sim-note', 'data-ursim-twin-sim-note')
  const simError = makeEl(doc, 'div', 'ursim-twin-sim-error', 'data-ursim-twin-sim-error')

  simBar.appendChild(simToggle)
  simBar.appendChild(simModelSelect)
  simBar.appendChild(simPresetSelect)
  simBar.appendChild(simSpeedSelect)
  simBar.appendChild(simNote)
  simBar.appendChild(simError)

  /*
   * 仿真能力清单（P2）：数据本来就在 `GET /twin/sim` 的 `capabilities` 里（`sim_capabilities()`），
   * 过去只有工具侧拿得到。折成一行可展开的说明挂在仿真行下面：折叠态不占版面，展开就是
   * 「能做什么 / 不能做什么」。正文只写"每一项几项"（避免把 python 侧的中文散文混进英文界面），
   * 完整清单放 `title` 里悬停可见。
   */
  const simCaps = makeEl(doc, 'details', 'ursim-twin-sim-caps', 'data-ursim-twin-sim-caps')
  const simCapsSummary = makeEl(doc, 'summary', 'ursim-twin-sim-caps-summary', 'data-ursim-twin-sim-caps-summary')
  simCapsSummary.textContent = S.simCapsSummary
  const simCapsBody = makeEl(doc, 'div', 'ursim-twin-sim-caps-body', 'data-ursim-twin-sim-caps-body')
  simCaps.appendChild(simCapsSummary)
  simCaps.appendChild(simCapsBody)
  simCaps.style.display = 'none'
  simBar.appendChild(simCaps)

  /*
   * ── 三栏骨架：左轨 / 3D 画布 / 右轨 ────────────────────────────────────
   *
   * 两条控制轨**可收起**：展开时列宽 180 / 350，收起后 24（只留一个把手），3D 自动占满
   * 中间那一列。收起状态存 localStorage、跨会话保持 —— 所以这里先读一次，并按它算**首帧**
   * 列宽，否则每次打开面板都会先撑开再收一下。
   *
   * 方向由 `twin-controls.js` 负责（控件 DOM 与收起状态机）；本文件只把 stage 插进布局、
   * 把快照喂给它、把命令出口留好。
   */
  const stage = makeEl(doc, 'div', 'ursim-twin-stage', 'data-ursim-twin-stage')
  /*
   * 三栏 grid：左轨 / 3D / 右轨。
   * 静态结构（display/align-items/flex/min-*）住在 `styles.js` 的 `TWIN_CSS` 里；
   * 这里**只**写真正随运行状态变化的列宽 —— 它的唯一拼法是 `stageColumns()`。
   * 收起/展开时轨宽由 CSS 列宽决定，不再额外写 `rail.style.width`（两个真源会打架）。
   */
  /** 控制轨状态存储：隐私模式下连**取 localStorage** 都可能抛，必须包起来。 */
  const railStorage = (() => {
    try {
      return (doc.defaultView ?? globalThis)?.localStorage ?? null
    } catch {
      return null
    }
  })()

  /**
   * 按控制轨的当前收起状态重算 grid 列宽。
   *
   * 列宽变化后画布必须**重新量一次**：`ResizeObserver` 也会通知，但它要等浏览器完成一次
   * 布局才回调，中间那一帧仍按旧尺寸渲染（被 CSS 拉伸、画面发糊）。这里先主动 `resize()`，
   * 下一帧再由 observer 兜底。
   */
  function refreshStageColumns() {
    stage.style.gridTemplateColumns = stageColumns({ right: rightRail.isCollapsed() })
    resize()
    invalidate()
  }

  const rightRail = buildRail(doc, railStorage, { onChange: refreshStageColumns })
  stage.appendChild(view)
  stage.appendChild(rightRail.rail)
  // 首帧列宽直接按存储恢复的状态算（不走 refreshStageColumns：挂载期不该 resize/invalidate）。
  stage.style.gridTemplateColumns = stageColumns({ right: rightRail.isCollapsed() })

  /*
   * 控制轨内容都在 twin-controls.js 里建好（2026-10-20 起合并为**单条右轨**：只读读数 +
   * 位姿数值 + 坐标系 + 点动盘/步长 + 六关节滑块）。
   *   - 命令走 `deps.send(body)`（body 就是宿主 `/twin/jog` 的路由 body）；
   *   - 状态走返回的 `sync(snapshot)`（每帧喂最新快照）；
   *   - 拖关节滑块时走 `deps.previewJoints(q)` 做**本地 FK 预览**（见下面的 `previewQ`）；
   *   - 点动与位姿/关节共用一把运动闸门（`createMotionLock()`），同一时刻只下发一条命令。
   */
  /**
   * 拖关节滑块时的本地预览关节角（`null` = 不预览）。
   *
   * 设计 §6.1：拖动时 3D 跟着动、**不发命令**，松手才下发一条 `movej`。面板是唯一
   * 知道"怎么把关节角摆进场景"的一方（`applyPoseToScene`），所以预览状态放在这里：
   * 预览期间 `step()` 用这组关节角出帧，而不是复现实测姿态；松手后右轨传 `null`
   * 结束预览，下一帧回到实际姿态（命令的结果随后由状态帧带来）。
   */
  let previewQ = null
  /**
   * 面板控制命令的唯一出口：POST 到宿主 `/twin/jog`（路径真源在 `lib/twin-paths.js`）。
   *
   * 失败**抛给左轨**（它把原因写到控件区的错误行上）：这里不吞异常，也不弹窗 ——
   * 面板没有审批应答者，任何一次失败都只能如实显示。`body.ok !== true` 是宿主拒绝，
   * 把 `body.error` 原样带出去。
   */
  async function sendJog(payload) {
    if (typeof request !== 'function') throw new Error('请求实现不可用')
    const res = await request(TWIN_JOG_PATH, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(payload),
    })
    const body = await res.json()
    if (body === null || typeof body !== 'object' || body.ok !== true) {
      throw new Error(String(body?.error ?? '宿主拒绝了这次点动'))
    }
    return body
  }

  // 一条轨里现在同时有点动盘、位姿输入与关节滑块：三者必须共用**一把**运动闸门，
  // 否则"点动流还在跑时拖关节"会并发下发两条命令（宿主按顺序处理，读数会来回跳）。
  const motionLock = createMotionLock()
  const railDeps = {
    send: sendJog,
    lock: motionLock,
    // 控制轨的提示行（数据通道停滞/整块禁用原因）与报错栏都挂进 HUD 身份行
    // （与"机器人 <型号> · <IP>"同一行，共用同一个槽位），不再占轨内顶部两行。
    noteHost: hudIdentityError,
    errorHost: hudIdentityError,
    getSnapshot: () => state?.getSnapshot?.() ?? {},
    /**
     * 右轨拖动关节滑块时的本地 FK 预览：只把 3D 摆到拖动值，不发命令、不改读数。
     * 传 `null` 结束预览（松手 / 命令落定 / 控件禁用 / 卸载）。
     */
    previewJoints(q) {
      const next = Array.isArray(q) && q.length === 6 && q.every(Number.isFinite)
        ? q.slice()
        : null
      if (next === null && previewQ === null) return
      previewQ = next
      // 结束预览时必须让下一帧**重算**姿态（不能复用静止帧里缓存的预览结果）。
      poseSettled = false
      dirty = true
    },
    /**
     * 控件层的错误（目前是"停止指令发不出去"）也写到同一条错误行。
     * 以前左轨只在宿主节点上留一个 `data-ursim-stop-failed` 属性，界面上一个字都没有 ——
     * 而"按了松手却没能停下"恰恰是最必须被看见的那种失败。
     */
    reportError(message) {
      if (typeof message !== 'string' || message === '') return
      holdError(message)
    },
  }
  const rightControls = mountRightRail(doc, rightRail.body, railDeps)

  root.appendChild(toolbar)
  root.appendChild(simBar)
  root.appendChild(stage)
  root.appendChild(hud)
  root.appendChild(status)
  root.appendChild(errorLine)
  container.appendChild(root)

  /*
   * 错误行的写入统一走这两个入口（P2）。
   *
   * 以前渲染异常只在 catch 里写一行，下一帧成功就立刻清空 —— 60 Hz 下**等于亮 16 ms**，人眼
   * 什么都看不到；而它恰恰是"这一帧为什么没画出来"的唯一线索。现在写入即驻留 ERROR_HOLD_MS，
   * 期间即使帧恢复正常也不擦；用户下一次动手（pointerdown/keydown）立即清掉，因为那时他已经
   * 在看控件、错误提示反而成了噪音。
   */
  function holdError(text) {
    heldErrorText = text
    errorHoldUntilMs = now() + ERROR_HOLD_MS
    errorLine.textContent = text
  }

  function clearError() {
    if (heldErrorText === '' && errorLine.textContent === '') return
    heldErrorText = ''
    errorHoldUntilMs = 0
    errorLine.textContent = ''
  }

  function clearErrorIfExpired(atMs) {
    if (heldErrorText === '') return
    if (atMs < errorHoldUntilMs) return
    clearError()
  }

  // 捕获阶段监听：先清错误行，再让控件自己的处理器写新的错误/命令。
  const onUserAction = () => clearError()
  root.addEventListener('pointerdown', onUserAction, true)
  root.addEventListener('keydown', onUserAction, true)

  /* 未连接态：不显示空 3D（隐藏工具栏/视图/HUD，只留状态文案）。
     ⚠️ 仿真开关行**不在此列**：打开面板即自动进仿真，而未连接正是一次失败时最常见的样子，
     这一行（含失败原因与重试按钮）必须从头就在。 */
  toolbar.style.display = 'none'
  // 未连接时整块三栏都藏起来：只留侧轨的把手（里面还是空的）比不显示更让人困惑。
  stage.style.display = 'none'
  view.style.display = 'none'
  hud.style.display = 'none'
  status.textContent = STATUS_DISCONNECTED

  /* ---------------- 3D 资源（预分配，不进循环重建） ---------------- */
  // 幽灵臂（清单第 7 条）：叠加显示"控制器打算去哪"的目标姿态。模型就绪后创建。
  let ghost = null
  /** 上一次用于算幽灵臂的目标关节角**引用** —— 只在变化时重算 FK（detail 是 1 Hz 通道）。 */
  let ghostTargetQ = null
  /**
   * 目标姿态与**当前实际**姿态是否明显不同（决定幽灵臂该不该露出来）。
   *
   * 为什么要这个判断：`target_q` 在稳态下与 `q` 几乎相等，此时再叠一层半透明臂**毫无信息**，
   * 视觉上却像"画面里多了一台机器人"（用户报过这个误读）。所以只在两者拉开足够差距
   * （运动中的交融/追赶）时才显示 —— 那时它才真的在表达"目标 vs 实际"。
   */
  let ghostWanted = false
  /** 判定"明显不同"的阈值（弧度）：约 1.15°，低于它按数值噪声处理，不让画面闪。 */
  const GHOST_MIN_DELTA_RAD = 0.02
  /**
   * 最近一次**成功写进场景**的六个关节角（`null` = 还一次都没收到过姿态）。
   *
   * 用途：换型号时新模型**立刻**摆到这个姿态（见 `applyPoseToScene` 与 `loadModel`）。
   * 装配完成但还没写 FK 的模型，7 个网格会各自留在自己的连杆坐标系里叠在基座原点 ——
   * 那看上去就是"机械臂非正常折叠"（实机报障的确切症状）；而换型号恰好常发生在数据面
   * 正在抖动的时刻（仿真重启 / worker 重挂载 ⇒ 状态路由返回 `q: []`）。
   */
  let lastAppliedQ = null

  // 工程辅助图层（清单第 9 条）：可达范围包络、基座坐标系、TCP 受力箭头、负载重心标记，
  // 以及**目标姿态**（幽灵臂）。除幽灵臂外**默认全关** —— 一次全画出来画面会花到看不清真臂；
  // 幽灵臂默认**开**（它原本就是自动显示的），但必须能被关掉：它长得太像真臂，会被误读成
  // "多了一台机器人"，只能由用户自己决定要不要看。
  //
  // 可达球按**单位半径**造一次，之后只改 `scale`：半径随型号变化时不需要重建几何体
  // （这个项目明令禁止在运行期反复创建几何体）。
  const reachSphere = createReachSphere(1)
  const baseAxes = createTcpAxes(TCP_AXES_SIZE)
  baseAxes.name = 'ursim-twin-base-axes'
  const cogMarker = createCogMarker()
  const forceArrow = createForceArrow(null)
  // 图层默认状态取 `LAYER_DEFAULTS`（`基座系` 默认开），`cog` 没有对应按钮、恒关。
  const layers = { ...LAYER_DEFAULTS, cog: false }

  /** 幽灵臂的**唯一**可见性入口（图层开关 + 目标差异两个条件都满足才显示）。 */
  function syncGhost() {
    if (!ghost) return
    ghost.setVisible?.(layers.ghost === true && ghostWanted === true)
  }

  /** 把 `layers` 的状态同步到场景对象上。 */
  function applyLayers() {
    reachSphere.visible = layers.reach
    baseAxes.visible = layers.base
    forceArrow.visible = false // 由 updateForceArrow 按力的大小决定
    cogMarker.visible = layers.cog
    syncGhost()
  }
  applyLayers()

  // 带 X/Y/Z 字母标签的 TCP 坐标轴（清单第 6 条）：轴长在每次取景后按模型半径自适应。
  const tcpAxes = createTcpAxes(TCP_AXES_SIZE)
  tcpAxes.matrixAutoUpdate = false // 每帧由 tool0 直接写 matrix

  const trajGeometry = new BufferGeometry()
  // 预分配固定容量：一次分配，逐帧只覆写数据（Ruling：不得每帧重建 geometry）。
  const trajPosition = new Float32BufferAttribute(new Float32Array(TRAJECTORY_CAPACITY * 3), 3)
  trajPosition.setUsage(DynamicDrawUsage)
  trajGeometry.setAttribute('position', trajPosition)
  // 顶点颜色（清单第 18 条）：单色线看不出方向与相对速度，按样本新旧渐变就能同时表达两者。
  const trajColor = new Float32BufferAttribute(new Float32Array(TRAJECTORY_CAPACITY * 3), 3)
  trajColor.setUsage(DynamicDrawUsage)
  trajGeometry.setAttribute('color', trajColor)
  trajGeometry.setDrawRange(0, 0)
  const trajArray = trajPosition.array
  const trajColorArray = trajColor.array

  const trajLine = new Line(trajGeometry, new LineBasicMaterial({ color: 0x35d0ff, vertexColors: true }))
  trajLine.name = 'ursim-twin-trajectory'
  trajLine.frustumCulled = false // 逐帧改写顶点，包围球会过期；关掉剔除免得整条线消失

  /* ---------------- 尺寸监听（必须可摘除） ---------------- */
  const win = doc.defaultView ?? (typeof globalThis.addEventListener === 'function' ? globalThis : null)
  const onResize = () => resize()
  win?.addEventListener?.('resize', onResize)

  /*
   * 侧栏是**用户可拖动改宽**的，而 `window.resize` 只在窗口尺寸变化时触发 —— 拖动侧栏
   * 不会触发它，于是画布会被 CSS 拉伸（画面变形/发虚）直到下次窗口变化。
   * `ResizeObserver` 能在容器尺寸变化时立刻回调；环境没有它就退回窗口监听 + 每帧重试。
   */
  let resizeObserver = null
  const ResizeObserverImpl = doc.defaultView?.ResizeObserver ?? globalThis.ResizeObserver
  if (typeof ResizeObserverImpl === 'function') {
    try {
      resizeObserver = new ResizeObserverImpl(() => resize())
      resizeObserver.observe(container)
      /*
       * 同时观察**画布容器**：把侧轨收起/展开只改中间那一列的宽度，宿主容器（侧栏）的
       * 外框尺寸一动不动 —— 只盯 container 的话，收起侧轨后画布会一直用旧尺寸渲染，
       * 直到用户拖动窗口。观察 view 才是"列宽变了"这件事的真正信号。
       */
      resizeObserver.observe?.(view)
    } catch {
      resizeObserver = null
    }
  }

  /* ---------------- 状态文案 ---------------- */
  function setStatus(text) {
    status.textContent = text
  }

  function refreshStatus() {
    if (contextLost) {
      setStatus(STATUS_CONTEXT_LOST)
      return
    }
    if (!wasConnected) {
      // host 的失败原因（含机器可读 code）必须显示出来：以前四种完全不同的故障
      // （worker 挂了 / 没连机器人 / 多台机器人有歧义 / 读取失败）都渲染成同一句
      // 「未连接机器人」，用户没有任何可操作信息。
      const snap = state?.getSnapshot?.() ?? {}
      setStatus(describeDisconnected(snap.code, snap.error, snap.ips))
      return
    }
    if (snapDegraded) {
      setStatus(`${STATUS_CONNECTED} · ${STATUS_INCOMPLETE}`)
      return
    }
    // 安全状态**压过**一切常规文案：以前机器人处于保护性停止时，状态行照样写着
    // 「已连接 · ur5e」，界面看上去一切正常 —— 而这正是最该被一眼看到的情况。
    const safetyRaw = state?.getSnapshot?.()?.detail?.safety_mode
    if (isSafetyHazard(safetyRaw)) {
      setStatus(`${describeSafetyMode(safetyRaw)} · ${STATUS_SAFETY_HINT}`)
      return
    }
    if (sceneUnavailable) {
      setStatus(STATUS_NO_WEBGL)
      return
    }
    if (loadError !== '') {
      setStatus(`${STATUS_CONNECTED} · ${STATUS_LOAD_FAILED}${loadError}${S.statusLoadRetrying}`)
      return
    }
    if (!handle) {
      setStatus(STATUS_LOADING)
      return
    }
    // 仿真态优先于普通"已连接 · 型号"：这一条把"你在看的是一台虚拟机器人"直接写在状态行上
    // （角标在画布上，状态行在下面，两处一起说，屏幕截图也带得走）。
    if (simActive) {
      const modelId = String(loadedModelId || state?.getSnapshot?.()?.model || '')
      setStatus(S.simActiveStatus(canonicalModelLabel(modelId)))
      return
    }
    // 型号正在换：网格还是上一台的（加载中），先把"它已经换了"说出来，别让用户以为没反应。
    if (requestedModelId !== '' && requestedModelId !== loadedModelId) {
      setStatus(`${STATUS_CONNECTED} · ${S.statusSwitchingModel(requestedModelId)}`)
      return
    }
    setStatus(
      handle.usedFallback
        ? `${STATUS_CONNECTED} · ${loadedModelId}${STATUS_FALLBACK_SUFFIX}`
        : `${STATUS_CONNECTED} · ${loadedModelId}`,
    )
  }

  /* ---------------- 主题跟随（宿主的 light/dark/system 设置） ---------------- */
  /**
   * 订阅宿主主题变化。
   *
   * 两件事分工：**CSS 那一半不用管**（`styles.js` 的颜色全走 `--dsw-*` token，宿主 token
   * 随 `body[data-ds-dark-theme]` 自动翻转）；这里只把新主题转给 WebGL 侧重刷网格线颜色，
   * 并标脏重画一帧。卸载时取消订阅（`dispose()`）。
   */
  const stopThemeWatch = watchTheme(
    (next) => {
      if (next === theme) return
      theme = next
      try {
        sceneHandle?.applyTheme?.(theme)
      } catch {
        /* 主题切换失败不得影响面板其余部分 */
      }
      invalidate()
    },
    { document: doc, window: doc.defaultView ?? globalThis },
  )

  /* ---------------- 场景（懒创建：未连接不建空 3D） ---------------- */
  function ensureScene() {
    if (sceneHandle || sceneUnavailable) return sceneHandle
    try {
      sceneHandle = sceneFactory(canvas, { theme }) ?? {}
    } catch (e) {
      // 没有 WebGL（或在构造中抛错）时**不能**让异常变成未处理的 promise rejection：
      // 那样 `handle` 永远是 null，状态行会永久停在「正在加载模型…」而画布一片空白。
      // 改成降级为纯数值模式（HUD 仍然更新）。
      sceneUnavailable = true
      sceneHandle = null
      loadError = e instanceof Error ? e.message : String(e)
      refreshStatus()
      return null
    }
    sceneHandle.scene?.add?.(tcpAxes)
    sceneHandle.scene?.add?.(trajLine)
    sceneHandle.scene?.add?.(reachSphere)
    sceneHandle.scene?.add?.(baseAxes)
    sceneHandle.scene?.add?.(cogMarker)
    sceneHandle.scene?.add?.(forceArrow)
    // 相机被拖动（含阻尼收敛）时也要重画：按需渲染下缺这个回调，画面会停在上一帧。
    sceneHandle.onCameraChange?.(() => invalidate())
    // 场景可能是在主题变化之后才建出来的（懒创建）：创建时就把当前主题喂给网格。
    try {
      sceneHandle.applyTheme?.(theme)
    } catch {
      /* 主题应用失败不应把整个 3D 降级成数值模式 */
    }
    watchContextLoss()
    ensureSized()
    return sceneHandle
  }

  /** 把 canvas 的 CSS 尺寸告诉渲染器；量到 0 就先记为待处理，下一帧继续试。 */
  function ensureSized() {
    if (!sceneHandle || contextLost) return
    let ok = false
    try {
      ok = sceneHandle.resize?.() !== false
    } catch {
      ok = false
    }
    pendingResize = !ok
  }

  /**
   * 监听 WebGL 上下文丢失/恢复。
   *
   * 没有这个监听时，GPU 重置（驱动更新、显存回收、标签长时间后台）之后画布会永久变黑，
   * 而状态行仍显示「已连接」——用户完全看不出发生了什么。这里至少如实说明，并允许
   * 恢复事件到达后继续渲染。
   */
  function watchContextLoss() {
    const target = sceneHandle?.renderer?.domElement ?? canvas
    if (!target?.addEventListener) return
    target.addEventListener('webglcontextlost', (event) => {
      event?.preventDefault?.()
      contextLost = true
      refreshStatus()
    })
    target.addEventListener('webglcontextrestored', () => {
      contextLost = false
      ensureSized()
      refreshStatus()
    })
  }

  function resize() {
    ensureSized()
  }

  function renderFrame() {
    sceneHandle?.render?.()
  }

  /** 标脏：下一帧确实要画。 */
  function invalidate() {
    dirty = true
  }

  /**
   * 应用一个视角按钮。
   *
   * `reset` = 按**当前模型**重新取景（换了大臂之后"贴脸"就是靠这一步修正）；
   * 其余四个只改相机方向、沿用上一次的取景中心与半径，所以来回切换不会越切越偏。
   * 场景还没建好（未连接 / 无 WebGL）时静默忽略 —— 此时工具栏本来就隐藏着。
   */
  function applyView(key) {
    if (key === 'reset') sceneHandle?.fitTo?.(handle?.root)
    else sceneHandle?.setViewPreset?.(key)
    invalidate()
  }

  /** 停帧：取消已排队的那一帧，并且不再续排（后台标签、卸载都走这里）。 */
  function pauseLoop() {
    if (frameId !== null) {
      caf?.(frameId)
      frameId = null
    }
  }

  /** 恢复帧循环（回到前台、或首次启动）。已经排着帧时是空操作。 */
  function wake() {
    if (disposed || hidden || frameId !== null) return
    frameId = raf(frame)
  }

  /** 后台标签彻底停帧；回到前台再续上。 */
  const onVisibility = () => {
    hidden = doc.hidden === true
    if (hidden) pauseLoop()
    else {
      // 回到前台：后台期间退避定时器可能被浏览器节流到几乎不触发，这里推一把
      // （`retryNow()` 只在"正在重连"时真正动手，不动健康连接）。
      try { state?.retryNow?.(false) } catch { /* 状态源自身的问题，吞掉 */ }
      invalidate()
      wake()
    }
  }
  // 注册点必须在 `onVisibility` 初始化之后（同一作用域里提前读 const 会命中 TDZ）。
  win?.addEventListener?.('visibilitychange', onVisibility)

  /* ---------------- 数据通道看门狗 ---------------- */

  /**
   * 更新"数据通道"提示行，并在停滞过久时**强制重建**通道。
   *
   * 为什么必须做：宿主那边的背压是"上一帧读没回来就不发下一帧"，而机器人运动时 Python
   * worker 被运动指令占住是**常态** —— 于是流会安静很久。以前的实现里这段时间界面上
   * 什么都不说，用户只能看到"仿真不动了"，分不清"机器人停了"和"数据停了"。
   *
   * @param {number} nowMs 面板时钟
   * @param {object} snap 当前快照
   * @param {boolean} connected 快照是否连着机器人
   */
  function updateFeed(nowMs, snap, connected) {
    const ts = Number.isFinite(snap?.ts) ? snap.ts : null
    if (ts === null || ts !== lastFeedTs) {
      lastFeedTs = ts
      lastFeedAtMs = nowMs
    }
    const health = state?.getStreamHealth?.() ?? {}
    const ageMs = lastFeedAtMs === null ? 0 : Math.max(0, nowMs - lastFeedAtMs)
    const text = describeFeedHealth({
      status: health.status,
      connected,
      feedStale: snap?.feedStale === true,
      ageMs,
      frames: health.frames,
      frameErrors: health.frameErrors,
    })
    if (text !== lastFeedText) {
      lastFeedText = text
      hudFeed.textContent = text
      hudFeed.style.display = text === '' ? 'none' : ''
      hudFeed.setAttribute(
        'data-ursim-twin-feed-state',
        text === '' ? 'ok' : (text.startsWith(FEED_RETRYING_TEXT) ? 'retrying' : 'stale'),
      )
    }
    // 停滞过久 ⇒ 强制重建。浏览器对后台窗口的定时器节流会让"退避重连"迟迟不触发，
    // 面板自己再推一把，比等一个可能已被节流掉的定时器可靠。
    if (connected && ageMs > FEED_RECONNECT_MS && nowMs - lastFeedRetryMs >= FEED_RETRY_INTERVAL_MS) {
      lastFeedRetryMs = nowMs
      try { state?.retryNow?.(true) } catch { /* 状态源自身的问题，吞掉 */ }
    }
  }

  /* ---------------- 离线仿真开关（0.7.0） ---------------- */
  /** 保留的仿真地址（与 python 的 `SIM_IP` 一致；宿主写路由只认它）。 */
  const SIM_IP = '127.0.0.1'

  /**
   * **打开面板时主动进入仿真**用的默认配置（用户裁定）：固定 UR12e、**竖直收拢**、倍率 100%。
   *
   * 起始姿态取「竖直收拢」而不是全零位（用户 2026-10-12 裁定）：新载入的机器人默认站成收拢的
   * 直立姿态 —— 那是 UR 的"待机位"，比整条臂平伸出去的全零位更像一台刚上电的机器人。这条默认值
   * 同时被「换型号」沿用（见 `simModelSelect` 的 change 处理），所以换一台机器人也从竖直收拢开始。
   *
   * ⚠️ 刻意**不因真机在线而跳过** —— 面板一打开就是这台虚拟机器人，与真机连没连无关。
   * 已经开着仿真时（AI 用 `ursim_sim_start` 开的、或另一个窗口开的）**沿用那一台**，
   * 绝不按这里的默认型号重建：重建会把那台已经摆好姿态的虚拟机器人推回起始位。
   */
  const SIM_DEFAULT_MODEL = 'ur12e'
  const SIM_DEFAULT_PRESET = 'upright'
  const SIM_DEFAULT_SCALING = 1
  /** GET 失败时的兜底型号清单（与 assets/models 里的 14 个 GLB 一致）。 */
  const SIM_MODEL_FALLBACK = [
    'ur3', 'ur3e', 'ur5', 'ur5e', 'ur7e', 'ur10', 'ur10e', 'ur12e',
    'ur16e', 'ur8long', 'ur15', 'ur18', 'ur20', 'ur30',
  ]
  const SIM_PRESETS = ['zero', 'upright', 'reach']
  const SIM_SPEEDS = [1, 0.5, 0.25, 0.1]
  /** 当前**数据**里这一帧是不是仿真（以宿主为准，不是以本地开关为准）。 */
  let simActive = false
  /** 正在 POST（按钮禁用 + 文案显示"切换中"，避免连点）。 */
  let simApplying = false
  /** 本地配置：开仿真时要 POST 的型号/起始姿态/速度倍率。 */
  let simConfig = { model: 'ur5e', preset: 'zero', speed_scaling: 1 }
  let simModels = [...SIM_MODEL_FALLBACK]
  /** 宿主自报的 `active`（GET /twin/sim）；`null` = 还没读到或读失败。 */
  let hostSimActive = null
  /** 上次**跨重启恢复**失败的原因（0.1.10）：非空时状态行改成说明它，而不是静默什么都没有。 */
  let simRestoreError = ''
  /*
   * 当前模式指示（P0）与能力清单（P2）的数据：都来自 `GET /twin/sim`。
   *
   * `motionMode` 缺省按最保守的 `sim` 处理：在读到宿主回答之前，角标显示「未连接」而不是
   * 冒充某一种模式。真机模式下角标必须**常显**（见 renderModeBadge）。
   */
  let motionMode = 'sim'
  let realRobots = []
  let simCapsData = null
  /**
   * 数据源是不是**本面板**切到仿真地址的。
   *
   * 收起面板时要把数据源切回"按宿主解析"（`setIp('')`），但不能因此把别人选的真机 IP 抹掉 ——
   * 只有确实是我们切过去的时候才由我们切回来。
   */
  let simIpOwned = false

  /** `ur5e` → `UR5e`（与真机 dashboard、python 侧 `canonical_model_name` 同一写法）。 */
  function canonicalModelLabel(id) {
    const value = String(id ?? '')
    return value.toLowerCase().startsWith('ur') ? `UR${value.slice(2)}` : value
  }

  /** 重建 `<select>` 的选项并选中 `current`（找不到就选第一项）。 */
  function fillSelect(select, entries, current) {
    while (select.firstChild) select.removeChild(select.firstChild)
    for (const item of entries) {
      const option = doc.createElement('option')
      option.value = item.value
      option.textContent = item.label
      select.appendChild(option)
    }
    const has = entries.some((item) => item.value === current)
    select.value = has ? current : (entries[0]?.value ?? '')
  }

  /** 把仿真控件的显示同步到当前状态（幂等，可每帧调）。 */
  function renderSimBar() {
    simToggle.setAttribute('aria-pressed', simActive ? 'true' : 'false')
    simToggle.textContent = simActive ? S.simToggleOff : S.simToggleOn
    // 没有 request 实现（Node 里没注入）时开关不可用，而不是点了没反应。
    simToggle.disabled = simApplying || typeof request !== 'function'
    const presetLabels = { zero: S.simPresetZero, upright: S.simPresetUpright, reach: S.simPresetReach }
    fillSelect(simModelSelect,
      simModels.map((id) => ({ value: id, label: canonicalModelLabel(id) })), simConfig.model)
    fillSelect(simPresetSelect,
      SIM_PRESETS.map((key) => ({ value: key, label: presetLabels[key] ?? key })), simConfig.preset)
    fillSelect(simSpeedSelect,
      SIM_SPEEDS.map((value) => ({ value: String(value), label: `${Math.round(value * 100)}%` })),
      String(simConfig.speed_scaling))
    for (const select of [simModelSelect, simPresetSelect, simSpeedSelect]) select.disabled = simApplying
    const idleNote = simRestoreError !== ''
      ? S.simRestoreFailed(simRestoreError)
      : (simApplying ? S.simApplying : (simActive ? S.simUnsupported : S.simUses))
    // 仿真开着时补一句"收起面板会停掉它"：dispose 里确实会停（`stopSimOnDispose`），但那时面板
    // 已经销毁、没地方再说；等用户发现虚拟机器人自己停了才去猜是最差的顺序。
    simNote.textContent = simActive && simRestoreError === ''
      ? `${idleNote} ${S.simCollapseStops}`
      : idleNote
    renderSimCaps()
  }

  /** 能力清单的正文（P2）：正文只给"每一项几项"，完整清单进 `title`。 */
  function renderSimCaps() {
    const caps = simCapsData !== null && typeof simCapsData === 'object' ? simCapsData : null
    if (caps === null) {
      simCaps.style.display = 'none'
      simCapsBody.textContent = ''
      // `?.()`：测试用的假 DOM 不实现 removeAttribute（本仓库既有约定）。
      simCapsBody.removeAttribute?.('title')
      return
    }
    const buckets = [
      [S.simCapsMotion, caps.motion],
      [S.simCapsRead, caps.read],
      [S.simCapsIo, caps.io],
      [S.simCapsTelemetry, caps.telemetry],
    ].filter(([, list]) => Array.isArray(list) && list.length > 0)
    const bits = buckets.map(([label, list]) => S.simCapsBucket(label, list.length))
    const missing = Array.isArray(caps.not_simulated) ? caps.not_simulated : []
    if (missing.length > 0) bits.push(S.simCapsCannot(missing.length))
    simCapsBody.textContent = bits.join('  ·  ')
    const detail = buckets.map(([label, list]) => `${label}: ${list.join(', ')}`)
    if (missing.length > 0) detail.push(`${S.simCapsCannot(missing.length)}: ${missing.join('; ')}`)
    if (detail.length > 0) simCapsBody.setAttribute('title', detail.join('\n'))
    else simCapsBody.removeAttribute?.('title')
    simCaps.style.display = bits.length > 0 ? '' : 'none'
  }

  /**
   * 读一次 I/O（数字位 + 模拟输入）与寄存器。
   *
   * `withRegisters` 只在**展开的那一刻**为真：寄存器是逐下标 getter（一次 24 次往返），
   * 没有理由跟着 HUD 节拍刷新。数字位则很便宜（两条 op），随节拍刷新才能看到变化。
   */
  let ioRequestToken = 0
  async function refreshIo(withRegisters) {
    if (typeof request !== 'function') return
    /*
     * 序号去重（P2）：这个函数有两条并发调用路径 —— 展开 I/O 块时的全量读（含寄存器，要串行
     * 好几个往返），以及 HUD 1 Hz 的只读数字位。后者可能在前者还没回来时又发一次请求；没有序号
     * 时**晚到的旧响应会覆盖新数据**（展开瞬间最明显：读数刚刷新，又被上一拍的响应盖回去）。
     * 谁手里的 token 最新，谁才有写权限；其余响应直接丢弃。
     */
    const token = ++ioRequestToken
    const stale = () => disposed || token !== ioRequestToken
    const snap = state?.getSnapshot?.() ?? {}
    const ip = typeof snap.ip === 'string' ? snap.ip : ''
    const prefix = ip === '' ? '' : `ip=${encodeURIComponent(ip)}&`
    // ⚠️ 只写**读数分区**：寄存器行在 `ioRegs` 里，这里碰不到它（见 ioBody 处的注释）。
    writeIoBits([S.ioReading])
    try {
      const res = await request(`${TWIN_STATE_PATH}?${prefix}io=1`, { cache: 'no-store' })
      const body = await res.json()
      if (stale()) return
      renderIo(body?.io ?? null)
      if (withRegisters !== true) return
      for (const set of REGISTER_SETS) {
        const r2 = await request(`${TWIN_STATE_PATH}?${prefix}reg=${set}&from=0&count=${REGISTER_COUNT}`, {
          cache: 'no-store',
        })
        const b2 = await r2.json()
        if (stale()) return
        renderRegisters(b2?.registers ?? null, set)
      }
    } catch (e) {
      // 失败同样要按 token 判断：过期请求的报错不该盖掉更新那次的结果。
      if (!stale()) writeIoBits([S.ioFailed(e instanceof Error ? e.message : String(e))])
    }
  }

  /** 位串：每 8 位空一格（std 0-7 / config 8-15 正好两组）。 */
  function bitString(bits) {
    if (!Array.isArray(bits)) return '—'
    const groups = []
    for (let i = 0; i < bits.length; i += 8) {
      groups.push(bits.slice(i, i + 8).map((b) => (b === true ? '1' : '0')).join(''))
    }
    return groups.join(' ')
  }

  /*
   * `ioBody` 的 title 由**两段**拼成：读数段 + 每 set 一段寄存器。
   * 以前 renderIo 每次都用「只含读数」的 title 整体覆盖，寄存器信息永远进不了 title；
   * 现在两段各记各的，任一渲染函数只更新自己那段。
   */
  let ioBitsTitle = ''
  const ioRegTitles = new Map()
  function syncIoBodyTitle() {
    const parts = [ioBitsTitle, ...ioRegTitles.values()].filter((line) => line !== '')
    ioBody.setAttribute('title', parts.join('\n'))
  }

  /** 只写**读数分区**；重复调用是覆盖而不是追加（不会越积越多行）。 */
  function writeIoBits(lines) {
    ioBits.textContent = lines.join('\n')
    ioBitsTitle = lines.join('\n')
    syncIoBodyTitle()
  }

  function renderIo(io) {
    const lines = []
    if (io !== null && typeof io === 'object' && typeof io.error !== 'string') {
      lines.push(S.ioDigitalOut(bitString(io.digital_out)))
      lines.push(S.ioDigitalIn(bitString(io.digital_in)))
      const analog = Array.isArray(io.analog_in) ? io.analog_in : []
      const fmt = (v) => (Number.isFinite(Number(v)) ? Number(v).toFixed(3) : '—')
      lines.push(S.ioAnalogIn(fmt(analog[0]), fmt(analog[1])))
      // 仿真下输入没有生产者，必须说出来 —— 否则那两行 0 会被读成"信号是 0"。
      if (io.simulated === true) lines.push(S.ioSimInputNote)
    } else if (io !== null && typeof io === 'object') {
      lines.push(S.ioFailed(io.error))
    }
    writeIoBits(lines)
  }

  /**
   * 寄存器：**每个 set 一行**（既有呈现不变），但重复调用只改该行的文本、**不追加**。
   *
   * 行键优先用本次请求的类型 `requestedSet`：宿主正常会在响应里带上 `set`，出错时可能没有；
   * 用请求类型兜底才能保证"每 set 一行"不随返回值缺字段而退化（旧写法每次调用都 append，
   * 重复展开会积累出重复行）。
   */
  const ioRegRows = new Map()
  function renderRegisters(registers, requestedSet) {
    if (registers === null || typeof registers !== 'object') return
    const setKey = String(requestedSet ?? registers.set ?? '')
    const line = typeof registers.error === 'string'
      ? S.ioFailed(registers.error)
      : S.ioRegisters(String(registers.set ?? ''), String(registers.from ?? 0),
        (Array.isArray(registers.values) ? registers.values : [])
          .map((v) => (typeof v === 'boolean' ? (v ? '1' : '0') : String(v ?? '—')))
          .join(' '))
    let row = ioRegRows.get(setKey)
    if (row === undefined) {
      row = makeEl(doc, 'div', 'ursim-twin-io-row', 'data-ursim-twin-io-reg-row')
      ioRegRows.set(setKey, row)
      ioRegs.appendChild(row)
    }
    row.textContent = line
    ioRegTitles.set(setKey, line)
    syncIoBodyTitle()
  }
  /**
   * 当前模式角标（P0）：**仿真中 / 真机模式 / 未连接** 三态。
   *
   * 为什么不能只有"仿真"角标：真机模式下原本一个标识都没有，而"没有角标"读起来就是"安全"。
   * 仿真中 = 紫色（沿用旧水印）；真机模式 = 红色且**常显**（含允许的 IP，白名单为空时明说
   * 全部拒绝）；未连接 = 中性灰（既没仿真也没连真机，没有任何东西会被驱动）。
   */
  function renderModeBadge(simNow) {
    const mode = motionMode === 'real' ? 'real' : (simNow === true ? 'sim' : 'idle')
    const text = mode === 'real'
      ? (realRobots.length > 0 ? S.realModeBadge(realRobots.join('、')) : S.realModeBadgeEmpty)
      : (mode === 'sim' ? S.simBadge : S.modeBadgeIdle)
    const title = mode === 'real' ? S.realModeBadgeTitle : (mode === 'sim' ? S.simBadgeTitle : S.modeBadgeIdleTitle)
    /*
     * 值没变就一个 DOM 写都不做（P2）。
     *
     * 本函数由 `step()` **每帧**调用（约 60 Hz），而角标实际几百帧才变一次。以前每次都重写
     * attribute + textContent + title，持续触发样式重算与无障碍树更新 —— 纯浪费。用"模式 + 文案"
     * 做键去重：文案里已包含 IP 白名单（真机模式），所以键相同 ⇒ 显示完全相同。
     */
    const key = `${mode}\u0000${text}\u0000${title}`
    if (key === lastBadgeKey) return
    lastBadgeKey = key
    simBadge.setAttribute('data-ursim-twin-mode', mode)
    simBadge.textContent = text
    simBadge.setAttribute('title', title)
    simBadge.style.display = ''
  }

  /**
   * 面板根节点上的"是否正在展示仿真"属性（样式表据此给画面描紫边）。
   *
   * `step()` 每帧都会走到这里，但值只在开关仿真/断连时变化 —— 重复 `setAttribute` 会让浏览器
   * 每帧重算样式（约 60 次/秒），所以用 `lastSimAttr` 去重；两条写入点（断连清空、每帧同步）
   * 共用这一个入口，避免一处更新缓存、另一处绕过。
   */
  function setRootSimAttr(simNow) {
    const value = simNow === true ? 'true' : 'false'
    if (value === lastSimAttr) return
    lastSimAttr = value
    root.setAttribute('data-ursim-twin-sim', value)
  }

  /**
   * 读宿主的仿真状态（无副作用）：**只用来初始化选择项**（型号清单 + 上次的配置）。
   *
   * ⚠️ 刻意**不**在这里设置"开关是否打开"：那个状态以**帧数据**（`snap.simulated`）为准 ——
   * 一次 GET 与一条流可能来自不同时刻（AI 随时能开/关仿真），让两条路各写同一个变量必然打架。
   * 显示状态只有一个真源：面板正在展示的那一帧。
   */
  async function refreshSimState() {
    if (typeof request !== 'function') return
    try {
      const res = await request(TWIN_SIM_PATH, { cache: 'no-store' })
      const body = await res.json()
      if (disposed || body === null || typeof body !== 'object') return
      hostSimActive = body.active === true
      if (Array.isArray(body.models) && body.models.length > 0) simModels = body.models.map(String)
      // 模式是**配置**（人写的），与运行状态无关 —— 但它必须在界面上一直可见（P0）。
      motionMode = body.motion_mode === 'real' ? 'real' : 'sim'
      realRobots = Array.isArray(body.real_robots) ? body.real_robots.map(String) : []
      simCapsData = body.capabilities !== null && typeof body.capabilities === 'object' ? body.capabilities : null
      // 跨重启恢复失败的原因（0.1.10）：让"这里为什么没有仿真"有个说法 —— 从前是静默空着。
      simRestoreError = typeof body.restore_error === 'string' ? body.restore_error : ''
      const modelId = typeof body.model_id === 'string' && body.model_id !== ''
        ? body.model_id : String(body.model ?? '').toLowerCase()
      if (modelId !== '') simConfig.model = modelId
      if (typeof body.preset === 'string' && body.preset !== '') simConfig.preset = body.preset
      if (Number.isFinite(body.speed_scaling)) simConfig.speed_scaling = body.speed_scaling
      renderSimBar()
      renderModeBadge(simActive)
    } catch {
      /* 读不到就保持缺省显示：这只影响选择项的初值，不影响开关本身 */
    }
  }

  /**
   * 开关/改配置：POST 到宿主。
   *
   * 成功后才把数据源切到仿真地址（`state.setIp`）—— 顺序很重要：先切数据源会让面板在
   * 仿真还没建起来时对着一个不存在的地址轮询。失败则**回滚显示**并写出原因。
   */
  async function applySim(enabled) {
    if (simApplying || typeof request !== 'function') return
    simApplying = true
    simError.textContent = ''
    renderSimBar()
    try {
      const payload = enabled
        ? {
            enabled: true,
            model: simConfig.model,
            preset: simConfig.preset,
            speed_scaling: simConfig.speed_scaling,
          }
        : { enabled: false }
      const res = await request(TWIN_SIM_PATH, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const body = await res.json()
      if (disposed) return
      if (body === null || typeof body !== 'object' || body.ok !== true) {
        throw new Error(String(body?.error ?? '宿主拒绝了这次切换'))
      }
      if (enabled && typeof body.model_id === 'string' && body.model_id !== '') {
        simConfig.model = body.model_id
      }
      // 仿真数据源与"真机/自动"数据源的切换点。
      state?.setIp?.(enabled ? SIM_IP : '')
      simIpOwned = enabled
      simActive = enabled
    } catch (e) {
      if (!disposed) {
        simActive = false
        simError.textContent = S.simFailed(e instanceof Error ? e.message : String(e))
      }
    } finally {
      simApplying = false
      if (!disposed) renderSimBar()
    }
  }

  /**
   * 打开面板时**主动进入离线仿真**（用户裁定）。
   *
   * 顺序很重要：先读宿主状态，再决定"沿用"还是"新建"。
   *   - 宿主已经开着仿真（`active`，通常是 AI 用 `ursim_sim_start` 开的）⇒ 只把数据源指过去，
   *     **绝不重建** —— 重建会把它推回起始姿态，等于把刚摆好的位姿抹掉；
   *   - 否则按默认配置（UR12e / 全零位 / 倍率 1）新建一台。**不因真机在线而跳过**。
   *
   * 失败时（宿主没装 python、worker 起不来、保留地址被占……）不抛错：原因写在仿真开关行上，
   * 而那一行刻意不随连接态隐藏，正是留给这种时候的。
   */
  async function autoEnterSim() {
    if (typeof request !== 'function' || disposed) return
    await refreshSimState()
    if (disposed) return
    if (hostSimActive === true || simActive) {
      // 沿用已经开着的那一台：只切数据源，一个 POST 都不发。
      simActive = true
      state?.setIp?.(SIM_IP)
      simIpOwned = true
      renderSimBar()
      return
    }
    simConfig.model = SIM_DEFAULT_MODEL
    simConfig.preset = SIM_DEFAULT_PRESET
    simConfig.speed_scaling = SIM_DEFAULT_SCALING
    renderSimBar()
    await applySim(true)
  }

  /**
   * 收起面板时停掉仿真（用户裁定：**收起即停**，包含 AI 用 `ursim_sim_start` 开的那台），
   * 并把数据源切回"按宿主解析"。
   *
   * `{enabled:false}` 本身幂等，所以没开仿真时调它也无害。刻意不复用 `applySim()`：
   * 那时面板正在被销毁，不需要（也不应该）再去碰 DOM。
   */
  function stopSimOnDispose() {
    const owned = simIpOwned
    if (owned) {
      try {
        state?.setIp?.('')
      } catch {
        /* 数据源切不回去也不该阻断卸载 */
      }
      simIpOwned = false
    }
    // 只有"这台仿真确实与本面板有关"时才去停它：本面板开过（`simActive`），或宿主自报开着
    // （`hostSimActive`，含 AI 用 `ursim_sim_start` 开的那台）。都没参与过就别多发一条写请求。
    if (!owned && !simActive && hostSimActive !== true) return
    if (typeof request !== 'function') return
    try {
      const result = request(TWIN_SIM_PATH, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ enabled: false }),
        // `keepalive`：这一条恰恰在**页面卸载过程中**发出（面板收起/切换视图），浏览器会把
        // 正在飞的普通 fetch 直接 abort ⇒ 虚拟机器人在宿主里继续跑，而用户以为它停了，下一个
        // 打开面板的人还会"沿用"它。载荷只有几十字节，远在 keepalive 的 64 KB 限制内。
        keepalive: true,
      })
      if (result && typeof result.catch === 'function') result.catch(() => {})
    } catch {
      /* 停不掉也只能算了：面板已经收起，没有地方报错 */
    }
  }

  simModelSelect.addEventListener('change', () => {
    // 换型号 = 换一台机器人（用户裁定）：3D 空间里原有的机器人要被清空（见 `loadModel` 的
    // `removeStrayRobots`），新载入的机器人从**竖直收拢**开始。所以起始姿态一并重置为默认预设，
    // 并让下拉同步过去 —— 否则下拉还停在旧姿态、仿真却已按新预设重建，两边说法不一致。
    simConfig.model = String(simModelSelect.value || simConfig.model)
    simConfig.preset = SIM_DEFAULT_PRESET
    if (simActive) void applySim(true) // 改型号 = 按新型号重建仿真（含换网格）
    else renderSimBar() // 未进仿真时也要刷下拉（renderSimBar 会按 simConfig 重新填充）
  })
  simPresetSelect.addEventListener('change', () => {
    simConfig.preset = String(simPresetSelect.value || simConfig.preset)
    if (simActive) void applySim(true) // 改起始姿态 = 重新开始，落在新姿态上
    else renderSimBar()
  })
  simSpeedSelect.addEventListener('change', () => {
    const value = Number(simSpeedSelect.value)
    simConfig.speed_scaling = Number.isFinite(value) && value > 0 ? value : 1
    if (simActive) void applySim(true)
    else renderSimBar()
  })

  renderSimBar()
  // 打开面板就主动进仿真（默认行为）；`autoSim:false` 时退回原来的"只读一次宿主状态"。
  if (autoSim) void autoEnterSim()
  else void refreshSimState()

  /* ---------------- 连接态切换 ---------------- */
  function applyConnection(connected) {
    if (connected !== wasConnected) {
      wasConnected = connected
      root.setAttribute('data-ursim-twin-connected', connected ? 'true' : 'false')
      // 空串 = 把显示交回样式表（`.ursim-twin-stage` 在 TWIN_CSS 里是 grid）：
      // 这里只负责"连不上就藏起来"，不再把 grid 这个静态值抄进 inline。
      stage.style.display = connected ? '' : 'none'
      view.style.display = connected ? '' : 'none'
      hud.style.display = connected ? '' : 'none'
      toolbar.style.display = connected ? '' : 'none'
      // ⚠️ 仿真开关行**不随连接态隐藏**（用户裁定）：未连接正是"打开面板自动进仿真"失败时
      // 最常见的样子，这一行是唯一能看到失败原因、也是唯一能重试的入口。
      if (!connected) {
        // 断连：丢弃插值对与轨迹，避免重连后画出跨越断层的直线/错误插值。
        prevSample = null
        curSample = null
        clock = null
        lastSnapshotTs = null
        trajectory = []
        lastTrajectoryTs = 0
        trajGeometry.setDrawRange(0, 0)
        hudIdentityText.textContent = ''
        hudPending.textContent = ''
        hudJoints.textContent = ''
        hudJoints.setAttribute('data-ursim-twin-overlimit', 'false')
        hudTcp.textContent = ''
        hudDetail.textContent = ''
        hudPower.textContent = ''
        /*
         * C1/C4 的收尾（0.1.12 修）：风险行必须跟着清空，**3D 上的超限着色也必须撤掉**。
         *
         * 上一版漏了这几件事，后果是断连后残留两条假信息：① HUD 还挂着上一次的「⚠ 奇异点
         * 腕 1.2°」；② 那节被染红的连杆**继续红着** —— 重连到另一台机器人、甚至换了型号之后
         * 仍然红，而被点名的关节早已不是那个位姿。两个 `last*` 缓存也必须一起重置，否则重连后
         * 会因"结果没变"而跳过重新渲染与重新着色。
         */
        hudRisk.textContent = ''
        hudRisk.setAttribute('data-ursim-twin-risk', 'ok')
        hudRisk.setAttribute('title', '')
        lastRiskText = null
        lastOverKey = null
        tintJointLinks(handle?.root ?? null, [])
        // 数据通道看门狗：断连即重置（重连后从新的一帧重新计时）。
        hudFeed.textContent = ''
        hudFeed.style.display = 'none'
        lastFeedText = null
        lastFeedAtMs = null
        lastFeedTs = null
        lastFeedRetryMs = -Infinity
        root.setAttribute('data-ursim-twin-hazard', 'false')
        // 未连接就谈不上"正在展示一台虚拟机器人"：水印必须跟着消失。
        // 但角标本身**不隐藏** —— 真机模式下断连也仍然是真机模式（P0：没有角标 ≠ 安全）。
        setRootSimAttr(false)
        renderModeBadge(false)
        lastHudMs = -Infinity
      }
      invalidate()
      resize()
      refreshStatus()
    } else if (!connected) {
      // 一直是未连接：host 的**失败原因可能变了**（例如从"还没有连过机器人"变成
      // "worker 进程挂了"）。状态行必须跟着变，否则用户看到的永远是第一次那句。
      refreshStatus()
    }
  }

  /**
   * 取景：换型号时、以及切换「可达范围」图层时调用。
   *
   * 默认按**当前型号的包围盒**自适应 —— 链路长度从 UR3（≈0.94 m）到 UR20（≈2.4 m）相差 2.6 倍，
   * 固定相机与固定网格必然对其中一端是错的（"换个大臂就贴脸"就是这么来的）。
   *
   * **但打开「可达范围」图层时改用固定参考半径**（`REACH_VIEW_RADIUS`，全部型号里最大那台的上界）：
   * 那个图层的用途就是比较可达范围，而按型号自适应会让每个型号都撑满画面 —— 机型长度差 2.7 倍，
   * 画面上却"看起来一样大"（用户 2026-10-12 的反馈）。固定参考 = 同一把尺子。
   */
  function frameView() {
    sceneHandle?.fitTo?.(handle?.root, layers.reach ? { minRadius: REACH_VIEW_RADIUS } : {})
    // 取景完成后才知道模型有多大：把轴长按半径缩放，否则 UR3 上偏大、UR30 上偏小。
    updateTcpAxesSize(tcpAxes, tcpAxesSizeFor(sceneHandle?.currentFitRadius?.()))
  }

  /**
   * 把一套关节角写进 3D —— 真臂装配组 + TCP gizmo + 受力箭头。**这是"模型已被摆上姿态"的唯一入口**，
   * 因此它顺带做两件与姿态绑定的事：
   *
   * ① **把根节点置为可见**。装配完成但还没写 FK 的模型，7 个网格各自留在自己的连杆坐标系里
   *    叠在基座原点（两根长管并排、法兰盘落在基座旁）—— 实机报障的"机械臂非正常折叠"就是它，
   *    所以绝不能在未摆姿态时展示根节点；
   * ② **记住这一次的关节角**，供换型号时给新模型摆姿态（见 `loadModel`）。
   *
   * @param {ArrayLike<number>} q 六个关节角（弧度）
   * @param {{links: Array<object>}} kinEntry 该型号的运动学链（`resolveKinematics` 的结果）
   * @returns {object} `fkChain` 的结果，供 HUD 复用
   */
  function applyPoseToScene(q, kinEntry) {
    const result = fkChain(kinEntry, q)
    handle?.applyFK?.(result)
    // TCP 坐标系 gizmo：贴到 tool0（第六关节之后的累积变换）。
    if (Array.isArray(result.tool0)) {
      tcpAxes.matrix.fromArray(result.tool0)
      tcpAxes.matrixWorldNeedsUpdate = true
      // TCP 受力箭头（清单第 9 条）：贴在 TCP 位置，方向按**世界系**受力方向 ——
      // 刻意不继承 TCP 的旋转，因为力是环境施加的，不是工具坐标系里的量。
      forceArrow.position.set(result.tool0[12], result.tool0[13], result.tool0[14])
      if (layers.force) updateForceArrow(forceArrow, lastSnapshot?.detail?.tcp_force)
      else forceArrow.visible = false
    }
    // 只有**真的写进了场景**才记账：模型还在异步装载（`handle` 为 null）时这一帧什么都没摆，
    // 不能算作"已知姿态"，否则装载完成时会再摆一次（同一帧两次 applyFK），也让"藏起来直到
    // 第一帧姿态"这条保证失效。
    if (handle?.root) {
      handle.root.visible = true
      lastAppliedQ = q === null || q === undefined ? null : Array.from(q).slice(0, 6)
    }
    return result
  }

  /* ---------------- 模型加载（型号变化 → 重建） ---------------- */
  async function loadModel(rawModel) {
    const token = ++loadToken
    const wantId = String(rawModel).trim().toLowerCase()
    let next = null
    try {
      // 把该型号的真实连杆长度一并传下去：GLB 加载失败时回退臂会用它们建几何体，
      // 否则未知型号会退化成 UR3 量级（清单第 14 条）。
      next = await modelLoader(rawModel, {
        armLinks: linkLengthsFromKinematics(resolveKinematics(rawModel)?.links) ?? undefined,
      })
    } catch (e) {
      if (!disposed && token === loadToken) {
        loadError = e instanceof Error ? e.message : String(e)
        // 失败后**必须**允许重试：型号是每帧都在收到的数据，一次失败不该让画面永远停在
        // 上一台机器人的网格上。节流到 MODEL_RETRY_MS，免得每帧（60 Hz）重试。
        requestedModelId = ''
        failedModelId = wantId
        modelRetryAtMs = now() + MODEL_RETRY_MS
        refreshStatus()
      }
      return
    }
    if (!next) return
    // 面板已卸载 / 型号又被换掉：把这次拿到的模型直接释放，避免泄漏。
    if (disposed || token !== loadToken) {
      next.dispose?.()
      return
    }

    loadError = ''
    // 加载成功：清掉重试节流（下次换型号可以立刻加载）。
    failedModelId = ''
    modelRetryAtMs = 0
    const scene = ensureScene()?.scene
    // 给根节点打上自己的名字：换型号时"清空 3D 空间里原有的机器人"要靠它只认自己挂上去的
    // 节点（`removeStrayRobots` 的兜底清扫同理），不动场景里别人的东西。
    if (next.root && typeof next.root === 'object') next.root.name = ROBOT_ROOT_NAME
    scene?.add?.(next.root) // ★ 只 add root：7 个装配组已挂在 root 下（Task 7 assemble）
    if (handle) {
      detach(scene, handle.root)
      handle.dispose?.()
    }
    // 兜底清扫：确保场景里**只有**这一台机器人（旧的那台必须已经不在画面里了）。
    removeStrayRobots(scene, next.root)
    handle = next
    // 幽灵臂：克隆真臂的装配结构（浅拷 —— geometry 与真臂共享，多一层几乎不占显存），
    // 换一层半透明材质。目标姿态只在 detail 通道里来，所以默认隐藏。
    disposeGhostArm(ghost)
    ghost = null
    ghostTargetQ = null
    try {
      ghost = createGhostArm(handle)
      scene?.add?.(ghost.root)
    } catch {
      // 克隆失败只是少一层叠加显示，绝不能因此让模型加载失败。
      ghost = null
    }
    const previousModelId = loadedModelId
    loadedModelId = wantId
    // **换了一台机器人**（不是首次加载）：上一台的插值对与轨迹不属于这一台。
    // 留着会让新机械臂从旧姿态"滑"过去，并在两个型号的 TCP 之间拉出一条根本不存在的直线。
    if (previousModelId !== '' && previousModelId !== loadedModelId) {
      resetMotionMemory()
    }
    // 新模型**立刻**摆到最近一次已知姿态（见 applyPoseToScene）：换型号时数据面常常正好在
    // "q 不完整"的窗口里（实测：仿真被换掉 / worker 重挂载后，仿真状态路由返回 `q: []`）。
    // 若不摆，就要等下一帧带 q 的采样 —— 而那一帧可能永远不来，画面于是永久停在装配态
    // （所有连杆叠在基座上），即用户看到的"机械臂非正常折叠"。
    // 连一次姿态都还没收到过（首次加载且尚无 q）时先把根节点藏起来：展示堆叠态比不展示更误导。
    const kinNow = resolveKinematics(loadedModelId)
    if (kinNow && Array.isArray(lastAppliedQ)) applyPoseToScene(lastAppliedQ, kinNow)
    else next.root.visible = false
    // 换装即重新取景（默认按本型号自适应；打开「可达范围」图层时用固定参考半径，见 frameView）。
    frameView()
    // 可达范围包络：半径只取决于型号（与姿态无关），所以换装时更新一次即可。
    // 球体几何恒为**单位半径**，这里只改 scale —— 不重建几何体。
    const reach = reachRadiusFromKinematics(resolveKinematics(loadedModelId)?.links)
    if (reach !== null) {
      reachSphere.scale.setScalar(reach)
      // 把该型号的可达上界写在图层开关上：数字是可比的，而画面比例在自适应取景下不一定可比。
      if (layerButtons.reach) layerButtons.reach.textContent = `${S.layerReach} ${reach.toFixed(2)} m`
    }
    dirty = true
    refreshStatus()
  }

  /**
   * 丢掉"属于上一台机器人"的运动记忆：插值对、轨迹与采样基准。
   *
   * 只在**型号真的变了**时调用（首次加载不算）。不调用的后果是看得见的：新臂会从旧臂的
   * 最后姿态插值过去，轨迹线还会把两台机器人的 TCP 连成一条直线 —— 那是一段从未发生过的运动。
   * 面板时钟（`clock`）**不重置**：宿主的时间戳是连续的，重置反而会让插值重新锚定到错误的位置。
   */
  function resetMotionMemory() {
    prevSample = null
    curSample = null
    lastSnapshotTs = null
    trajectory = []
    lastTrajectoryTs = 0
    trajGeometry.setDrawRange(0, 0)
    dirty = true
  }

  /* ---------------- 时间轴锚定 ---------------- */
  function resolveSampleTime(hostTs, nowMs) {
    if (!Number.isFinite(hostTs)) return { ts: nowMs, reset: false }
    if (clock === null || hostTs < clock.hostTs) {
      // 首次 / 宿主时间倒退（重连、host 重启）→ 重新锚定；跨断层的插值对作废。
      clock = { hostTs, localTs: nowMs }
      return { ts: nowMs, reset: true }
    }
    return { ts: clock.localTs + (hostTs - clock.hostTs), reset: false }
  }

  /* ---------------- 轨迹 ---------------- */
  function pushTrajectorySample(snap) {
    // 暂停时只停止**记录**，不清空已有的线：现场常要"停下动作、保留刚才那段"。
    if (trajectoryPaused) return
    const tcp = snap?.tcp
    if (!Array.isArray(tcp) || tcp.length < 3 || !Number.isFinite(tcp[0])) return
    const ts = Number.isFinite(snap.ts) ? snap.ts : lastTrajectoryTs + 1
    lastTrajectoryTs = ts
    // 除了位置也记**关节角**（清单第 18 条）：只记 TCP 的话，导出的数据无法复现姿态。
    const q = Array.isArray(snap?.q) && snap.q.length >= 6 ? [...snap.q] : undefined
    trajectory = pushSample(
      trajectory,
      { tcp: [tcp[0], tcp[1], tcp[2]], ts, ...(q === undefined ? {} : { q }) },
      TRAJECTORY_MAX_AGE_MS,
    )
    if (trajectory.length > TRAJECTORY_CAPACITY) {
      trajectory = trajectory.slice(trajectory.length - TRAJECTORY_CAPACITY)
    }
  }

  /** 把轨迹缓冲写进**已预分配**的 position/color 属性（覆写 + drawRange，零重建）。 */
  function drawTrajectory() {
    const points = trajectoryPoints(trajectory)
    const count = Math.min(points.length, TRAJECTORY_CAPACITY)
    const start = points.length - count
    // 颜色要按**同一段**尾部样本算新旧比例，否则画出来的渐变与线的起点对不上。
    const colors = trajectoryColors(trajectory.slice(start))
    for (let i = 0; i < count; i++) {
      const p = points[start + i]
      trajArray[i * 3] = p[0]
      trajArray[i * 3 + 1] = p[1]
      trajArray[i * 3 + 2] = p[2]
      const c = colors[i] ?? [1, 1, 1]
      trajColorArray[i * 3] = c[0]
      trajColorArray[i * 3 + 1] = c[1]
      trajColorArray[i * 3 + 2] = c[2]
    }
    trajPosition.needsUpdate = true
    trajColor.needsUpdate = true
    trajGeometry.setDrawRange(0, count)
  }

  /* ---------------- 数值面板（节流 ~10 Hz） ---------------- */
  /** 优先用控制器报的 TCP；没有时才退回 FK 的 tool0 位置（姿态填 0，并靠 title 说明）。 */
  function tcpForHud(snap, fkResult) {
    const tcp = snap?.tcp
    if (Array.isArray(tcp) && tcp.length >= 3) return tcp
    const m = fkResult?.tool0
    return Array.isArray(m) ? [m[12], m[13], m[14], 0, 0, 0] : null
  }

  /**
   * 写数值面板。
   *
   * `joints` 必须是**测量值**（host 报出的那一笔），不是插值值 —— 插值只服务于网格的观感，
   * 工程读数不能是"算出来的中间态"。
   */
  function writeHud(nowMs, snap, joints, fkResult, kin) {
    if (!(nowMs - lastHudMs >= HUD_INTERVAL_MS)) return
    lastHudMs = nowMs
    // 身份行：机型 + 机器人 IP。IP 以前只落在属性上，界面上看不到。
    const identity = [snap?.model ?? loadedModelId, snap?.ip].filter(v => typeof v === 'string' && v !== '')
    hudIdentityText.textContent = identity.length === 0 ? '' : S.identity(snap?.model ?? loadedModelId, snap?.ip)
    hudIdentity.setAttribute('title', hudIdentityText.textContent)
    // 多机器人选择（清单第 19 条）：候选或当前目标变了才重建 DOM（这不是热路径，
    // 但每帧重建按钮会让点击落空 —— 手指还没抬起来按钮就被换掉了）。
    const candidates = Array.isArray(snap?.ips)
      ? snap.ips.filter((value) => typeof value === 'string' && value !== '')
      : []
    const resolvedIp = typeof snap?.ip === 'string' ? snap.ip : ''
    const robotsSignature = `${resolvedIp}|${candidates.join(',')}`
    if (robotsSignature !== lastRobotsSignature) {
      lastRobotsSignature = robotsSignature
      hudRobots.textContent = ''
      for (const candidate of candidates) {
        const button = makeEl(doc, 'button', 'ursim-twin-layer-toggle', 'data-ursim-twin-robot')
        button.type = 'button'
        button.textContent = candidate
        button.setAttribute('aria-pressed', candidate === resolvedIp ? 'true' : 'false')
        button.addEventListener('click', () => { state?.setIp?.(candidate) })
        hudRobots.appendChild(button)
      }
    }
    // 待审批目标：审批进行中才有内容，结束后 host 不再返回该字段、这里自然清空。
    const pendingSummary = typeof snap?.pendingMotion?.summary === 'string' ? snap.pendingMotion.summary : ''
    hudPending.textContent = pendingSummary === '' ? '' : `${S.pendingPrefix}  ${pendingSummary}`
    hudPending.setAttribute('title', hudPending.textContent)
    // 关节角：同时标出**超出限位**的关节。限位表来自 `resolveKinematics()`（= kinematics.json），
    // **不是** `fkChain()` 的返回值 —— 后者恒为 `{links, tool0}`，从来没有 `jointLimits` 字段，
    // 于是旧写法恒传 `undefined`、`overLimitJoints` 第一行就 `return []`：这个提示 100% 不生效，
    // 而测试是绿的（假 handle 记录的同样是真 `fkChain` 的输出）。
    const over = overLimitJoints(joints, kin?.jointLimits)
    hudJoints.textContent = over.length === 0
      ? formatJoints(joints)
      : `${formatJoints(joints)}  ${S.overLimit(`J${over.join('/J')}`)}`
    hudJoints.setAttribute('data-ursim-twin-overlimit', over.length === 0 ? 'false' : 'true')
    /*
     * C1/C4（0.1.11）：奇异点提示 + 把"哪一节有问题"标到 3D 上。
     *
     * 只在这两处**结果变化**时才动 DOM/材质（`hudRisk` 的文本与 `tintJointLinks` 的调用）：
     * 静态帧不该每帧重写材质（材质克隆是真实开销，且渲染器要重编程序）。
     * 着色按关节下标 → `groups[i+1]` 的映射，见 `loader.js` 的 `tintJointLinks`。
     */
    const hint = singularityHint({
      kin,
      joints,
      limits: kin?.jointLimits ?? null,
      reach: reachRadiusFromKinematics(kin?.links) ?? null,
    })
    const riskText = hint === null
      ? ''
      : [
          hint.level === 'at' ? S.riskAt : (hint.level === 'near' ? S.riskNear : S.riskOk),
          S.riskWrist(hint.wristDeg.toFixed(1)),
          hint.manip === null ? '' : S.riskManip(hint.manip.toFixed(4)),
          // 阈值判断在模块里（hint.limitNear）：面板不再硬编码 5°，否则改常量会两边不一致。
          hint.limitNear === true ? S.riskLimit(hint.limitJoint, hint.limitDeg.toFixed(1)) : '',
        ].filter(Boolean).join('  ·  ')
    if (riskText !== lastRiskText) {
      lastRiskText = riskText
      hudRisk.textContent = riskText
      hudRisk.setAttribute('title', riskText === '' ? '' : S.riskTitle)
      hudRisk.setAttribute('data-ursim-twin-risk', hint?.level ?? 'ok')
    }
    const overKey = over.join(',')
    if (overKey !== lastOverKey) {
      lastOverKey = overKey
      if (handle !== null) tintJointLinks(handle.root, over)
    }
    // 关节行在窄侧栏里会被省略号截断；把完整值放到 title 上，鼠标悬停即可读到 J5/J6。
    hudJoints.setAttribute('title', hudJoints.textContent)
    // TCP 行优先用控制器报的 TCP；拿不到时才退回 FK 的 tool0 位置（并标注是推算值）。
    const tcp = tcpForHud(snap, fkResult)
    hudTcp.textContent = tcp ? formatTcp(tcp) : 'TCP  --'
    hudTcp.setAttribute('title', hudTcp.textContent)
    // dashboard 侧状态（detail=1 的慢节拍）：安全模式/机器人模式/程序状态/速度倍率一行，
    // 关节温度与母线电压电流一行。`hazard` 同时写到面板根节点上，供 CSS 把状态行染红。
    const detail = formatDetail(snap?.detail)
    hudDetail.textContent = detail.status
    hudDetail.setAttribute('title', detail.status)
    hudDetail.setAttribute('data-ursim-twin-hazard', detail.hazard ? 'true' : 'false')
    const power = [detail.temps, detail.power, detail.currents, detail.tcpSpeed].filter(Boolean).join('   ')
    hudPower.textContent = power
    hudPower.setAttribute('title', power)
    root.setAttribute('data-ursim-twin-hazard', detail.hazard ? 'true' : 'false')
    if (snap?.ip) root.setAttribute('data-ursim-twin-ip', String(snap.ip))
    // I/O 折叠块展开着才刷新（1 Hz；寄存器只在展开那一刻读一次，见 refreshIo）。
    if (ioBox.open === true && nowMs - lastIoMs >= IO_REFRESH_MS) {
      lastIoMs = nowMs
      void refreshIo(false)
    }
  }

  /* ---------------- 单帧 ---------------- */
  function step(nowMs) {
    const snap = state?.getSnapshot?.() ?? {}
    const connected = snap.connected === true
    const wasDegraded = snapDegraded
    snapDegraded = snap.degraded === true
    applyConnection(connected)
    // 数据通道健康度要**连未连接时也更新**：此时最该看到的正是"正在重连"。
    updateFeed(nowMs, snap, connected)
    /*
     * 控制轨：**未连接也要喂**（它们据此把整块控件禁用并显示原因），所以放在提前返回之前。
     * "数据停滞"有两个来源：宿主自报的 `feedStale`，以及面板自己的看门狗（采样超过
     * `FEED_STALE_MS` 没推进）。后者只在这里合成到喂给轨道的快照上 —— 状态源本身不改。
     */
    const feedStale = snap?.feedStale === true
      || (lastFeedAtMs !== null && nowMs - lastFeedAtMs > FEED_STALE_MS)
    const railSnap = feedStale === (snap?.feedStale === true) ? snap : { ...snap, feedStale }
    rightControls.sync(railSnap)
    if (!connected) return
    if (wasDegraded !== snapDegraded) refreshStatus()

    /*
     * 仿真水印以**数据**为准（宿主按"型号 + 推送行"两处给出 `simulated`），而不是以本地开关
     * 为准：AI 用 `ursim_sim_start` 开的仿真、或另一个窗口开的仿真，这里同样要显示水印 ——
     * 界面绝不能出现"实际在跑仿真、面板却说这是真机"。
     */
    const simNow = snap.simulated === true
    if (simNow !== simActive) {
      simActive = simNow
      renderSimBar()
      refreshStatus()
    }
    setRootSimAttr(simNow)
    renderModeBadge(simNow)

    // 安全模式只在 detail 通道（慢节拍）变化，连接态本身没变 —— 但它必须能改写状态行，
    // 否则一次保护性停止要等到下次断连/重连才会显示出来。
    const hazard = isSafetyHazard(snap?.detail?.safety_mode)
    if (hazard !== snapHazard) {
      snapHazard = hazard
      refreshStatus()
    }

    // 型号：首次或变化 → （重新）加载。宿主的型号是按 IP + **连接代次**给的，所以
    // "同一个 IP 换了一台别的型号"会在这里表现为 snap.model 变化（见 lib/twin-routes.js）。
    const rawModel = String(snap.model ?? '').trim()
    const wantModelId = rawModel.toLowerCase()
    if (wantModelId !== '' && wantModelId !== requestedModelId) {
      // 同一个型号刚失败过就等一会儿再试（`MODEL_RETRY_MS`）；换成**另一个**型号则立刻加载。
      const throttled = wantModelId === failedModelId && nowMs < modelRetryAtMs
      if (!throttled) {
        requestedModelId = wantModelId
        // 网格加载是异步的（GLB 可能几帧才到）：先把"正在切换型号"写出来，
        // 否则换机器人时状态行会一直显示上一台的型号，看上去像没反应。
        refreshStatus()
        void loadModel(rawModel)
      }
    }

    const kin = resolveKinematics(loadedModelId || wantModelId)
    const joints = Array.isArray(snap.q) && snap.q.length >= 6 ? snap.q : null
    let fkResult = null

    if (kin && joints) {
      const sampled = resolveSampleTime(snap.ts, nowMs)
      if (sampled.reset) {
        prevSample = null
        curSample = null
      }
      // 只在"确实换了采样"时推进插值对（同一样本被重复读到不重复入队）。
      const finiteTs = Number.isFinite(snap.ts)
      // 截图水印要读最近一笔快照（型号/IP/读数/安全模式）。
    lastSnapshot = snap
    const isNewSample = !finiteTs || snap.ts !== lastSnapshotTs || curSample === null
      if (finiteTs) lastSnapshotTs = snap.ts
      if (isNewSample) {
        prevSample = curSample
        curSample = { q: joints.slice(), ts: sampled.ts }
        // ⚠️ 轨迹样本**只在新采样时**入队。以前这行每帧都跑（60 fps），而采样只有 10 Hz
        // ⇒ 同一个 ts 被重复压入约 6 次，600 点的容量实际只装下 ~100 个真样本（约 10 s，
        // 而不是注释里说的 60 s），并且每帧都要重建 ~600 个数组（持续 GC 抖动）。
        pushTrajectorySample(snap)
        dirty = true
        poseSettled = false // 新样本 ⇒ 重新进入"插值 → 收敛"过程
        // 插值要在 `nowMs - delay` 走过 [prev, cur] 这段时间内连续出帧；多留 64 ms（≈4 帧）
        // 吸收调度抖动，否则最后一次插值会被按需渲染跳过、画面退化成阶梯。
        animatingUntil = nowMs + renderDelayMs(prevSample, curSample) + 64
      }

      /*
       * 静止帧（①）：既不脏、插值窗口也走完、采样也没换 —— 此刻 `interpolateAt` 在窗口外会把
       * 结果**钳到 curSample**，所以本帧的 `smooth` 与上一帧逐位相同，FK 结果与姿态矩阵自然
       * 也相同。旧写法照样每帧重算一遍（FK + 若干矩阵写入 + 一次轨迹重绘），60 Hz 全跑。
       */
      const windowDone = nowMs >= animatingUntil
      /*
       * 右轨拖滑块期间的本地预览：3D 摆到拖动值，但**不改测量值、不发命令**。
       * 预览期间必须绕过静止帧复用 —— 否则数据面每来一帧就会把预览姿态盖回实际姿态，
       * 滑块在动、画面却在原地跳。
       */
      const previewing = previewQ !== null
      const staticFrame = !previewing && !isNewSample && !dirty && windowDone && poseSettled && poseResult !== null
      if (staticFrame) {
        fkResult = poseResult
      } else {
        // 渲染滞后一个采样周期（自校准）：只有一个样本时不插值，直接呈现该样本。
        const smooth = previewing
          ? previewQ.slice()
          : (prevSample
            ? interpolateAt(prevSample, curSample, nowMs - renderDelayMs(prevSample, curSample))
            : curSample.q.slice())
        // 姿态：只在模型就绪时写（applyFK 不产生 GPU 资源，无需暂存）。这一步同时把模型置为
        // 可见、并把本次关节角记下来（换型号时新模型据此立刻摆姿态）—— 见 applyPoseToScene。
        fkResult = applyPoseToScene(smooth, kin)
        poseResult = fkResult
        /*
         * ⚠️ 窗口**刚结束**的那一帧必须照常算（`windowDone && !poseSettled` 走的就是这里）：
         * 窗口内最后一帧算的是**内插值**，而这一帧 `interpolateAt` 已把结果钳到 `curSample`，
         * 于是 `lastResult` 才精确等于"控制器最近报出的那一笔" —— 画面与读数都收敛到测量值。
         * 只有算过这一帧之后，同样的数据才允许复用。
         */
        poseSettled = windowDone
      }

      // 幽灵臂：把"控制器打算去哪"画出来，与上面的**实际**姿态叠加 —— 跟随误差、滞后与
      // 交融过程一眼可见。
      //
      // 目标姿态来自 detail 慢通道（1 Hz 级）而这里是 60 fps，所以只在**引用变化**时重算
      // FK：省掉 59/60 的无效计算，同时画面稳定停在最近一次收到的目标上。
      if (ghost) {
        // 可画的关节角有两个来源：**待审批**目标优先（它是"即将发生的事"，比当前目标
        // 更该被看见），其次是控制器当前的目标。
        const pending = snap?.pendingMotion
        const pendingQ = pending?.kind === 'joints' ? pending.q : null
        const liveQ = snap?.detail?.target_q
        // 数值防御：非有限的关节角会让 fkChain 产出坏矩阵，画出来是扭曲的假臂 ——
        // 那比不画更误导。
        const usable = (q) => Array.isArray(q) && q.length === 6 && q.every(Number.isFinite)
        const chosen = usable(pendingQ) ? pendingQ : (usable(liveQ) ? liveQ : null)
        /*
         * 与**当前实际**关节角比较后才决定要不要露出来。
         *
         * 稳态下 `target_q` 与 `q` 几乎相等，此时这一层叠加**没有信息**（两臂完全重合），
         * 运动时才有意义（"目标 vs 实际"的差距就是交融过程）。以前无条件显示：一旦两者
         * 稍微错开，用户就会在画面里看到"第二台机器人"，而且它的关节与真臂不一样 —— 报障
         * 过。现在只有**明显不同**才显示；待审批目标例外（它与当前必定不同，且是"即将发生
         * 的事"，比控制器目标更该被看见）。
         */
        const currentQ = usable(snap?.q) ? snap.q : null
        const differs = chosen !== null && currentQ !== null
          && chosen.some((v, i) => Math.abs(v - currentQ[i]) > GHOST_MIN_DELTA_RAD)
        ghostWanted = chosen !== null && (usable(pendingQ) || differs)
        if (ghostWanted) {
          if (chosen !== ghostTargetQ) {
            ghostTargetQ = chosen
            ghost.applyFK(fkChain(kin, chosen))
          }
          // 橙色 = 还没批准、将要发生；青色 = 控制器当前的目标。
          ghost.setPending(usable(pendingQ))
        } else {
          ghostTargetQ = null
        }
        // 可见性只有**一个**入口（图层开关 + 目标差异），不在别处直接 setVisible。
        syncGhost()
      }

      // TCP gizmo 与受力箭头已随 applyPoseToScene 一起写好（与姿态同一个入口，不会各写一次）。

      // 轨迹只在**新采样**时才会多一个点（见上面的 `pushTrajectorySample`），所以静止帧
      // 重绘它只是把同一批顶点再上传一次 —— 跳过。
      if (!staticFrame) drawTrajectory()
      // HUD 用**测量值**而不是插值值：插值是为了让网格看起来连续，而工程读数必须是
      // 控制器真实报出的那一笔（两者可能相差一个采样周期 + 渲染滞后）。
      writeHud(nowMs, snap, joints, fkResult, kin)
    }

    // 画布尺寸：面板刚展开时 flex 高度可能还没算出来（量到 0×0），必须每帧重试，
    // 否则那一帧之后 canvas 会一直用默认后备缓冲被 CSS 拉伸（糊成一片）。
    if (pendingResize) ensureSized()

    // 按需渲染：只有"确实有新东西"（新采样/尺寸变化/模型换装/相机被动过）或插值窗口尚未
    // 走完时才真的画。未连接时 `step()` 早已提前返回，这里也不会再画空场景。
    if (dirty || nowMs < animatingUntil) {
      renderFrame()
      dirty = false
    }
  }

  function frame() {
    // `hidden` 也要挡：`caf` 只是"请求取消"，浏览器可能已经把这一帧排好队了
    // （测试里的假 caf 更是不删队列），所以面板必须自己守住"后台不出帧"。
    if (disposed || hidden) return
    try {
      step(now())
      // 错误行驻留期间不碰它；过了驻留窗口、且这一帧没再抛错，才允许清空。
      clearErrorIfExpired(now())
    } catch (e) {
      // 单帧异常不得打死循环，也不得静默：驻留 ERROR_HOLD_MS（以前下一帧就擦掉 = 亮 16 ms）。
      holdError(`${STATUS_ERROR_PREFIX}${e instanceof Error ? e.message : String(e)}`)
    } finally {
      // 后台标签不再续帧（回到前台由 `onVisibility` → `wake()` 重新起链）。
      if (disposed || hidden) frameId = null
      else frameId = raf(frame)
    }
  }

  wake()

  /* ---------------- 卸载（幂等） ---------------- */
  function dispose() {
    if (disposed) return
    disposed = true

    // 收起面板即停仿真（含 AI 开的那台），并把数据源切回"按宿主解析"。
    stopSimOnDispose()

    // 控件自己的定时器（点动长按重复）与运动闸门必须在这里清掉，否则面板卸载后还会继续发命令。
    rightControls.dispose?.()
    previewQ = null

    if (frameId !== null) {
      caf?.(frameId)
      frameId = null
    }
    win?.removeEventListener?.('resize', onResize)
    win?.removeEventListener?.('visibilitychange', onVisibility)
    // 错误行的"用户一动手就清"监听也必须摘掉：它们挂在 root 上，而 root 会被清空，
    // 保留闭包只会让整个面板对象被这两个监听吊住、无法回收。
    root.removeEventListener?.('pointerdown', onUserAction, true)
    root.removeEventListener?.('keydown', onUserAction, true)
    stopThemeWatch?.()
    resizeObserver?.disconnect?.()
    resizeObserver = null

    const scene = sceneHandle?.scene
    if (handle) {
      detach(scene, handle.root)
      handle.dispose?.()
      handle = null
    }
    detach(scene, tcpAxes)
    detach(scene, trajLine)
    disposeGhostArm(ghost)
    ghost = null
    for (const overlay of [reachSphere, baseAxes, cogMarker, forceArrow]) disposeOverlay(overlay)
    sceneHandle?.dispose?.()

    disposeTcpAxes(tcpAxes)
    trajGeometry.dispose()
    trajLine.material?.dispose?.()

    trajectory = []
    prevSample = null
    curSample = null
    clock = null
    sceneHandle = null

    // 清空宿主容器（样式 `<style>` 是共享资源，故意保留）。
    if (root.parentNode === container) container.removeChild(root)
    else root.remove?.()
    while (root.firstChild) root.removeChild(root.firstChild)
  }

  return { dispose }
}
