/**
 * Task 5 — unit tests for the pure twin route handlers (lib/twin-routes.js).
 *
 * Run directly:  node --test test/twin-routes.test.mjs
 * (Do NOT use `npm test` — npm spawns children over piped stdio, which the
 *  current sandbox rejects with `spawn EPERM`.)
 */

import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { readFileSync } from 'node:fs';
import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { registerHooks } from 'node:module';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import {
  TWIN_STATE_PATH,
  TWIN_ASSET_PATH,
  TWIN_MODELS_PATH,
  TWIN_JOG_PATH,
  TWIN_CODES,
  TWIN_MODEL_TTL_MS,
  TWIN_STREAM_FRAME_ERROR_EVENT,
  TWIN_STREAM_STALE_EVENT,
  createTwinStateHandler,
  createTwinAssetHandler,
  createTwinModelsHandler,
  createTwinStreamHandler,
  normalizeModelEntry,
  parseJogRequest,
  twinStateQuery,
} from '../lib/twin-routes.js';

/*
 * ── 路由级用例的装配钩子 ────────────────────────────────────────────────────
 *
 * 下面几条 jog 用例要驱动**真实的** `lib/index.js`（`apply()` 挂路由；405 / 403 / 400 /
 * 503 / 200 的响应契约与**守卫顺序**都只存在于那里的 handler 闭包里，`parseJogRequest`
 * 的单测一行都摸不到）。这里只桩掉两个 peer 依赖 —— 它们的真实实现不在本仓库。
 * 手法与 `test/sim-persistence.test.mjs` 的 `drive()` 相同：那个文件的 `registerHooks` 是
 * 文件内私有的，所以照它的形状内联一份最小版本。
 */
registerHooks({
  resolve(specifier, context, nextResolve) {
    if (specifier === '@deepseek-ai/dsh-tools') return { url: 'stub:dsh-tools', shortCircuit: true };
    if (specifier === '@deepseek-ai/schemastery') return { url: 'stub:schemastery', shortCircuit: true };
    return nextResolve(specifier, context);
  },
  load(url, context, nextLoad) {
    if (url === 'stub:dsh-tools') {
      return { format: 'module', shortCircuit: true, source: 'export function defineTool(spec) { return spec }' };
    }
    if (url === 'stub:schemastery') {
      return {
        format: 'module',
        shortCircuit: true,
        source: `
          const chain = new Proxy(function () {}, {
            get: () => (...a) => chain,
            apply: () => chain,
            construct: () => chain,
          })
          const z = new Proxy({}, { get: () => chain, apply: () => chain })
          export default z
        `,
      };
    }
    return nextLoad(url, context);
  },
});

/*
 * ★ 路由那一层到底把哪些查询参数转给了读取逻辑 —— 这一步曾经被漏掉：`/state` 的路由处理器
 * 只转发 `detail`，把 `io` / `reg` / `from` / `count` 全丢了，于是读取逻辑里 `wantsIo` /
 * `wantsRegisters` 恒为 false，**面板的 I/O 与寄存器永远读不出值**。四道门全绿的原因是：
 * 所有 I/O / 寄存器单测都**直接调用读取逻辑**，从不经过路由那一层。
 * 这条测试改打纯函数 `twinStateQuery`（路由用它），把"到底转发了什么"钉死。
 */
test('★ /state 查询参数白名单：io / reg / from / count / detail 必须原样转发', () => {
  assert.deepEqual(twinStateQuery('/nonead-ursim/twin/state?ip=127.0.0.1&io=1'), {
    detail: '', io: '1', reg: '', from: '', count: '',
  });
  assert.deepEqual(
    twinStateQuery('/nonead-ursim/twin/state?reg=int&from=8&count=16&detail=1'),
    { detail: '1', io: '', reg: 'int', from: '8', count: '16' },
  );
  // 缺省 / 畸形 URL 一律空串，绝不抛（路由那一层不能因为一个坏 URL 变成 500 或挂住）。
  assert.deepEqual(twinStateQuery(undefined), { detail: '', io: '', reg: '', from: '', count: '' });
  assert.deepEqual(twinStateQuery('http://[bad'), { detail: '', io: '', reg: '', from: '', count: '' });
  // `ip` 不在白名单里：本插件只操作离线仿真，目标由路由钉死在 SIM_IP 上。
  assert.equal('ip' in twinStateQuery('/x?ip=1.2.3.4'), false);
});

/** 包名（取自 package.json）—— 错误响应里不得泄露它；改名时这条断言自动跟随。 */
const PKG_NAME = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8')).name;

// ── fixtures ───────────────────────────────────────────────────────────────

// 真实信封形状：`UrWorker.call()` resolve 的是响应里的 `data`，而每个 op 自身返回
// `{message, data:{…}}`（见 python/ur_worker.py 的 `ok()`：原样返回传入的 dict）。
// **不要**把它"简化"成扁平对象 —— 那正是当初路由读错层级（恒返回空 model/q/tcp、连上机器人
// 也只显示黑屏）却仍然全绿的原因。
const worker = {
  call: async (op, params) => ({
    get_joint_pose: { message: '当前关节姿态', data: { joint_positions: [0, 0, 0, 0, 0, 0], ip: params?.ip } },
    get_tcp_pose: { message: '当前TCP位置', data: { tcp_pose: [0, 0, 0.5, 0, 0, 0], ip: params?.ip } },
    get_robot_model: { message: 'UR3', data: { robot_model: 'UR3', remote_control: false, ip: params?.ip } },
  }[op]),
};

const assetsDir = await mkdtemp(join(tmpdir(), 'ursim-twin-assets-'));
await writeFile(join(assetsDir, 'ur3.glb'), Buffer.from([0x67, 0x6c, 0x54, 0x46]));

after(async () => {
  await rm(assetsDir, { recursive: true, force: true });
});

// ── route constants ────────────────────────────────────────────────────────

test('导出固定的宿主路由路径常量', () => {
  assert.equal(TWIN_STATE_PATH, '/nonead-ursim/twin/state');
  assert.equal(TWIN_ASSET_PATH, '/nonead-ursim/twin/asset');
  assert.equal(TWIN_MODELS_PATH, '/nonead-ursim/twin/models');
});

// ── 机器可读的失败原因（0.5.0）─────────────────────────────────────────────
//
// 客户端以前只能拿到一句中文 reason，于是"worker 挂了"、"机器人没连"、"两台机器人有歧义"
// 全都渲染成同一行「未连接机器人」——没有地址、没有原因，而且歧义那种情况还会永远每隔
// ≤2 s 白轮询下去。现在每种失败都带一个稳定的 `code`。

test('失败必须带机器可读的 code（客户端据此给出不同提示）', async () => {
  assert.deepEqual(TWIN_CODES, {
    NO_ROBOT: 'no_robot',
    NOT_CONNECTED: 'robot_not_connected',
    AMBIGUOUS: 'ambiguous_robot',
    WORKER_UNAVAILABLE: 'worker_unavailable',
    ROBOT_ERROR: 'robot_error',
    BAD_REQUEST: 'bad_request',
  });

  const none = await createTwinStateHandler({ worker, connectedIps: () => new Set() })({});
  assert.equal(none.body.connected, false);
  assert.equal(none.body.code, 'no_robot');

  const notConnected = await createTwinStateHandler({ worker, connectedIps: () => new Set(['9.9.9.9']) })({ ip: '1.2.3.4' });
  assert.equal(notConnected.body.code, 'robot_not_connected');
  assert.equal(notConnected.body.ip, '1.2.3.4', '必须回显是哪台机器人');

  const noWorker = await createTwinStateHandler({ worker: null, connectedIps: () => new Set(['1.2.3.4']) })({ ip: '1.2.3.4' });
  assert.equal(noWorker.body.code, 'worker_unavailable');

  const boom = await createTwinStateHandler({
    worker: { call: async () => { throw new Error('机器人掉线了'); } },
    connectedIps: () => new Set(['1.2.3.4']),
  })({ ip: '1.2.3.4' });
  assert.equal(boom.body.code, 'robot_error');
  assert.equal(boom.status, 200, '机器人错误不得变成 5xx');

  const ambiguous = await createTwinStateHandler({
    worker,
    connectedIps: () => new Set(['1.1.1.1', '2.2.2.2']),
  })({});
  assert.equal(ambiguous.status, 400);
  assert.equal(ambiguous.body.code, 'ambiguous_robot');
  assert.deepEqual(ambiguous.body.ips, ['1.1.1.1', '2.2.2.2'], '必须列出候选，客户端才能提示选哪台');
});

test('状态响应必须禁止缓存（缓存的位姿比没有位姿更糟）', async () => {
  const h = createTwinStateHandler({ worker, connectedIps: () => new Set(['1.2.3.4']) });
  const r = await h({ ip: '1.2.3.4' });
  assert.match(r.headers['cache-control'], /no-store/);
  const miss = await createTwinStateHandler({ worker, connectedIps: () => new Set() })({});
  assert.match(miss.headers['cache-control'], /no-store/, '失败响应同样不得被缓存');
});

test('模型名按 IP 记忆：常数不能每次轮询都去问一遍 Dashboard', async () => {
  let asked = 0;
  const counting = {
    call: async (op, params) => {
      if (op === 'get_robot_model') asked += 1;
      return worker.call(op, params);
    },
  };
  const cache = new Map([['1.2.3.4', 'UR5e']]);
  const h = createTwinStateHandler({
    worker: counting,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: (ip) => cache.get(ip) ?? null,
  });
  const r = await h({ ip: '1.2.3.4' });
  assert.equal(r.body.model, 'UR5e');
  assert.equal(asked, 0, '记忆命中时不得再去问 dashboard');

  // 没有记忆时仍要读一次并回填
  const cold = await createTwinStateHandler({ worker: counting, connectedIps: () => new Set(['1.2.3.4']) })({ ip: '1.2.3.4' });
  assert.equal(cold.body.model, 'UR3');
  assert.equal(asked, 1);
});

// ── 换机器人：型号必须跟着换（0.7.0）────────────────────────────────────────
//
// 现场场景：仿真正显示 UR3，**同一个 IP** 上被换成一台 UR10e。型号在一台机器人的连接
// 存续期间确实不变，所以缓存是对的 —— 但缓存必须能失效。以前的失效条件只有
// "connect/disconnect 工具被调用过"，于是仿真会永远停在旧型号上（网格、取景、可达范围、
// 关节限位全部沿用旧型号），而界面上没有任何异常。

test('★ 读到的型号必须写回缓存：同一连接代次内每帧轮询不得反复问 Dashboard', async () => {
  let asked = 0;
  const store = new Map();
  const counting = {
    call: async (op, params) => {
      if (op === 'get_robot_model') asked += 1;
      return worker.call(op, params);
    },
  };
  const h = createTwinStateHandler({
    worker: counting,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: (ip) => store.get(ip) ?? null,
    setModelFor: (ip, entry) => store.set(ip, entry),
    telemetryEpoch: () => '1:1',
  });

  assert.equal((await h({ ip: '1.2.3.4' })).body.model, 'UR3');
  assert.equal(asked, 1);
  await h({ ip: '1.2.3.4' });
  await h({ ip: '1.2.3.4' });
  assert.equal(asked, 1, '★ 读到的型号必须回填，否则 10 Hz 轮询每帧都在打 Dashboard');
  assert.equal(store.get('1.2.3.4').epoch, '1:1', '回填时必须带上读它时的连接代次');
  assert.equal(store.get('1.2.3.4').name, 'UR3');
});

test('★ 同一个 IP 换了另一台型号（连接代次变化）⇒ 型号必须重读，绝不永远停在旧值', async () => {
  let asked = 0;
  let reported = 'UR3';
  let epoch = '1:1';
  const store = new Map();
  const fake = {
    call: async (op, params) => {
      if (op === 'get_robot_model') {
        asked += 1;
        return { message: reported, data: { robot_model: reported, ip: params?.ip } };
      }
      return worker.call(op, params);
    },
  };
  const h = createTwinStateHandler({
    worker: fake,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: (ip) => store.get(ip) ?? null,
    setModelFor: (ip, entry) => store.set(ip, entry),
    telemetryEpoch: () => epoch,
  });

  assert.equal((await h({ ip: '1.2.3.4' })).body.model, 'UR3');
  assert.equal(asked, 1);
  assert.equal((await h({ ip: '1.2.3.4' })).body.model, 'UR3');
  assert.equal(asked, 1, '代次没变 ⇒ 用缓存，不付 Dashboard 往返');

  // 现场换机器人：worker 会发现旧 RTDE 掉了并重连 ⇒ 新代次
  reported = 'UR10e';
  epoch = '1:2';
  const after = await h({ ip: '1.2.3.4' });
  assert.equal(after.body.model, 'UR10e', '★ 代次变了必须重读型号（客户端据此换网格）');
  assert.equal(asked, 2);
});

test('连接代次也可以直接从推送遥测里取（不注入 telemetryEpoch 时）', async () => {
  const store = new Map();
  let asked = 0;
  const fake = {
    call: async (op, params) => {
      if (op === 'get_robot_model') asked += 1;
      return worker.call(op, params);
    },
  };
  let pushed = { at: 0, ts: 0, q: [0, 0, 0, 0, 0, 0], tcp: [0, 0, 0.5, 0, 0, 0], epoch: '7:1' };
  const h = createTwinStateHandler({
    worker: fake,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: (ip) => store.get(ip) ?? null,
    setModelFor: (ip, entry) => store.set(ip, entry),
    telemetry: () => pushed,
  });

  await h({ ip: '1.2.3.4' });
  await h({ ip: '1.2.3.4' });
  assert.equal(asked, 1, '同一代次内不得重读');

  // worker 重启：进程内计数从 1 重来，但 `epoch` 带了"第几个子进程"，不会撞车
  pushed = { ...pushed, epoch: '8:1' };
  await h({ ip: '1.2.3.4' });
  assert.equal(asked, 2, '★ 代次变化（含 worker 重启）必须重读');
});

test('拿不到连接代次时按 TTL 兜底重读（推送关掉 / 旧版 worker 也不会永远停在旧型号）', async () => {
  let asked = 0;
  let reported = 'UR3';
  let now = 1000;
  const store = new Map();
  const fake = {
    call: async (op, params) => {
      if (op === 'get_robot_model') {
        asked += 1;
        return { message: reported, data: { robot_model: reported, ip: params?.ip } };
      }
      return worker.call(op, params);
    },
  };
  const h = createTwinStateHandler({
    worker: fake,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: (ip) => store.get(ip) ?? null,
    setModelFor: (ip, entry) => store.set(ip, entry),
    modelTtlMs: 5000,
    now: () => now,
  });

  assert.equal((await h({ ip: '1.2.3.4' })).body.model, 'UR3');
  assert.equal(asked, 1, '冷缓存必须读一次');
  now += 4000;
  await h({ ip: '1.2.3.4' });
  assert.equal(asked, 1, 'TTL 未到 ⇒ 用缓存');

  reported = 'UR20';
  now += 2000; // 累计 6000 > 5000
  const stale = await h({ ip: '1.2.3.4' });
  assert.equal(asked, 2, '★ TTL 到期必须重读（没有代次可依时的安全网）');
  assert.equal(stale.body.model, 'UR20');
});

test('读不到型号（空串）时不得把它写进缓存冒充"未知型号"，并且退避窗口过后必须重读', async () => {
  const store = new Map();
  let asked = 0;
  let nowMs = 0;
  const fake = {
    call: async (op, params) => {
      if (op === 'get_robot_model') {
        asked += 1;
        return { message: '', data: { robot_model: '   ', ip: params?.ip } };
      }
      return worker.call(op, params);
    },
  };
  const h = createTwinStateHandler({
    worker: fake,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: (ip) => store.get(ip) ?? null,
    setModelFor: (ip, entry) => store.set(ip, entry),
    telemetryEpoch: () => '1:1',
    now: () => nowMs,
    modelBackoffMs: 5000,
  });
  const r = await h({ ip: '1.2.3.4' });
  assert.equal(r.body.model, '');
  assert.equal(store.size, 0, '空型号不得进缓存');
  assert.equal(asked, 1);

  // 退避窗口内：**不再发**型号读（否则运动期间每帧都要排 2.5 s 队列）。
  await h({ ip: '1.2.3.4' });
  assert.equal(asked, 1, '退避窗口内不得重读');

  // 过了退避窗口：必须重读，而不是记住"没有型号"。
  nowMs = 5001;
  await h({ ip: '1.2.3.4' });
  assert.equal(asked, 2, '上一次没读到 ⇒ 退避过后必须再读，而不是记住"没有型号"');
});

/*
 * ── 运动期间的"零往返"（0.3.11）────────────────────────────────────────────
 *
 * 背景（实测，15 s 连续运动）：推送通道本身是健康的（20 Hz、龄期 ≤52 ms、零缺失），
 * 但帧路径**仍会提交** worker 读 —— `get_robot_model`（缓存失效后每帧一次）与详情节拍
 * （每 2 s 一次的 `status` + `get_target_values`）。这些读在运动期间排在单线程 stdin
 * 队列里，等满 2.5 s 预算才超时；超时是抛异常 ⇒ 外层 catch 回放陈旧帧 ⇒ 界面
 * 「数据已停止更新 Ns」。SSE 实测只跑到 6.4 Hz，最大间隔 2606 ms。
 *
 * 下面三条把"运动期间帧路径一次 worker 调用都不发、且失败也不许把帧打成陈旧"钉住。
 */

test('★ 推送行自带型号时，帧路径一次型号读都不发（冷缓存 / TTL 过期 / 代次变化都一样）', async () => {
  let asked = 0;
  const calls = [];
  let now = 1000;
  const store = new Map();
  const counting = {
    call: async (op, params) => {
      calls.push(op);
      if (op === 'get_robot_model') asked += 1;
      return worker.call(op, params);
    },
  };
  let pushed = {
    at: 1000,
    ts: 1000,
    q: [0, 0, 0, 0, 0, 0],
    tcp: [0, 0, 0.5, 0, 0, 0],
    epoch: '1:5',
    simulated: true,
    model: 'UR12e',
  };
  const h = createTwinStateHandler({
    worker: counting,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: (ip) => store.get(ip) ?? null,
    setModelFor: (ip, entry) => store.set(ip, entry),
    telemetry: () => ({ ...pushed, at: now }),
    now: () => now,
  });

  const r1 = await h({ ip: '1.2.3.4' });
  assert.equal(r1.body.model, 'UR12e', '型号直接取推送行');
  assert.equal(r1.body.simulated, true);
  assert.equal(asked, 0, '★ 推送给了型号 ⇒ 不得再去问 dashboard');
  assert.deepEqual(calls, [], '★ 这一帧必须零 worker 往返（运动期间才可能连续出帧）');

  // TTL 早过期、连接代次也变了：仍然零往返 —— 型号是静态事实，推送每 50 ms 都在给。
  now += 60000;
  pushed = { ...pushed, epoch: '2:9' };
  const r2 = await h({ ip: '1.2.3.4' });
  assert.equal(r2.body.model, 'UR12e');
  assert.equal(asked, 0, '★ 推送自带型号 ⇒ 永远不需要型号读');
  assert.deepEqual(calls, [], '★ 仍然零往返');

  // 顺手写回缓存：别的路径（工具返回值 / 后续帧）也能直接用。
  assert.equal(store.get('1.2.3.4')?.name, 'UR12e');
  assert.equal(store.get('1.2.3.4')?.simulated, true);
});

test('★ 型号读超时不得把整帧退化成陈旧回放：用上一次已知型号，并按退避重试', async () => {
  let asked = 0;
  let now = 1000;
  const store = new Map([['1.2.3.4', { name: 'UR5e', epoch: '1:1', at: 0, simulated: false }]]);
  const hanging = {
    call: (op) => {
      if (op === 'get_robot_model') {
        asked += 1;
        // 运动期间的样子：请求提交进去了，但要等运动结束才被处理 ⇒ 远晚于有界预算才返回。
        // （用一个**ref 着的**定时器挂住，别让事件循环空掉 —— 否则 `node --test` 会以
        //  "Promise resolution is still pending" 把这个文件后面所有用例一起判失败。）
        return new Promise((resolve) => {
          setTimeout(() => resolve({ message: '', data: { robot_model: '' } }), 200);
        });
      }
      return worker.call(op);
    },
  };
  const h = createTwinStateHandler({
    worker: hanging,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: (ip) => store.get(ip) ?? null,
    setModelFor: (ip, entry) => store.set(ip, entry),
    // 代次都对不上 ⇒ 每帧都"想"读型号；这正是运动期间卡顿的来源
    telemetry: () => ({
      at: now, ts: now, q: [0, 0, 0, 0, 0, 0], tcp: [0, 0, 0.5, 0, 0, 0], epoch: '1:2',
    }),
    now: () => now,
    modelReadBudgetMs: 20,
    modelBackoffMs: 5000,
  });

  const r1 = await h({ ip: '1.2.3.4' });
  assert.equal(asked, 1, '冷/失效缓存要试一次');
  assert.equal(r1.body.model, 'UR5e', '★ 读不到就用上一次已知型号兜底');
  assert.equal(r1.body.stale, undefined, '★ 绝不能因为"问不到型号"把整帧标成陈旧');
  assert.equal(r1.body.q.length, 6, '★ 位姿通道必须完好');

  await h({ ip: '1.2.3.4' });
  assert.equal(asked, 1, '★ 退避窗口内不得再提交型号读（否则每帧白付一次排队）');
});

test('★ 详情不阻塞帧：有缓存就直接用，后台刷新按最小间隔节流', async () => {
  let statusCalls = 0;
  let now = 1000;
  const slowDetail = {
    call: async (op) => {
      if (op === 'status') {
        statusCalls += 1;
        // 第二次起故意慢 200 ms：帧路径若还在等它，这一帧就会被拖到 200 ms 以上。
        if (statusCalls > 1) await new Promise((resolve) => { setTimeout(resolve, 200); });
        return { message: '', data: { safety_mode: 'NORMAL', robot_mode: 'RUNNING' } };
      }
      if (op === 'get_target_values') {
        return { message: '', data: { target_q: [0, 0, 0, 0, 0, 0] } };
      }
      return worker.call(op);
    },
  };
  const h = createTwinStateHandler({
    worker: slowDetail,
    connectedIps: () => new Set(['1.2.3.4']),
    telemetry: () => ({
      at: now, ts: now, q: [0, 0, 0, 0, 0, 0], tcp: [0, 0, 0.5, 0, 0, 0], epoch: '1:1',
    }),
    now: () => now,
    detailBackoffMs: 5000,
    // 先把后台刷新按住 60 s，单独验证"帧不等详情"这件事。
    detailRefreshMinMs: 60000,
  });
  const query = { ip: '1.2.3.4', detail: '1' };

  // 第一帧：没有缓存 ⇒ 允许一次有界等待（空闲时它是很快的一次真读）
  const first = await h(query);
  assert.equal(statusCalls, 1);
  assert.equal(typeof first.body.detail, 'object');

  // 第二帧：缓存命中 ⇒ 立刻返回缓存，绝不等那次慢读
  const t0 = Date.now();
  const second = await h(query);
  const elapsed = Date.now() - t0;
  assert.deepEqual(second.body.detail, first.body.detail, '★ 直接用上一笔详情');
  assert.ok(elapsed < 150, `★ 有缓存时详情不再让帧排队（实测 ${elapsed} ms）`);
  assert.equal(statusCalls, 1, '★ 节流窗口内不提交后台刷新');
  assert.equal(second.body.stale, undefined, '★ 详情慢不是"数据停滞"');

  // 窗口过去：后台刷新照常发起，但这一帧**仍然**不等它
  now += 60001;
  const t1 = Date.now();
  const third = await h(query);
  const elapsed3 = Date.now() - t1;
  assert.equal(statusCalls, 2, '★ 刷新窗口过了才提交一次');
  assert.ok(elapsed3 < 150, `★ 后台刷新同样不让帧排队（实测 ${elapsed3} ms）`);
  assert.deepEqual(third.body.detail, first.body.detail, '本帧展示的还是上一笔，新的后台读不阻塞它');
});

test('★ 详情超时后退避：运动期间不再每 2 s 提交一次把读槽位占满', async () => {
  let statusCalls = 0;
  let now = 1000;
  const transient = () => {
    const e = new Error('worker 正忙');
    e.code = 'WORKER_TIMEOUT';
    return e;
  };
  const busy = {
    call: async (op) => {
      if (op === 'status') {
        statusCalls += 1;
        throw transient();
      }
      if (op === 'get_target_values') throw transient();
      return worker.call(op);
    },
  };
  const h = createTwinStateHandler({
    worker: busy,
    connectedIps: () => new Set(['1.2.3.4']),
    telemetry: () => ({
      at: now, ts: now, q: [0, 0, 0, 0, 0, 0], tcp: [0, 0, 0.5, 0, 0, 0], epoch: '1:1',
    }),
    now: () => now,
    detailBackoffMs: 5000,
  });

  // 模拟 SSE 的详情慢节拍：每 2 s 一帧，共 12 s
  const frames = [];
  for (let t = 1000; t <= 11000; t += 2000) {
    now = t;
    frames.push(await h({ ip: '1.2.3.4', detail: '1' }));
  }
  assert.equal(frames.length, 6);
  assert.ok(statusCalls <= 2, `★ 12 s 内最多提交 2 次详情读（实际 ${statusCalls} 次）`);
  assert.equal(statusCalls, 2, '第一次 + 退避到期后那次');
  // 一帧都不能少：退避只影响详情这个加分项
  for (const frame of frames) {
    assert.equal(frame.status, 200);
    assert.equal(frame.body.stale, undefined, '★ 详情失败不得牵连位姿通道');
    assert.equal(frame.body.q.length, 6);
    assert.equal(typeof frame.body.detail?.error, 'string', '降级成"这一拍没有新详情"');
  }
});

test('拿不到代次也拿不到龄期的裸字符串按可信记忆处理（兼容既有调用方）', () => {
  assert.deepEqual(normalizeModelEntry('UR5e'),
    { name: 'UR5e', epoch: undefined, at: undefined, simulated: false });
  assert.equal(normalizeModelEntry('   '), null);
  assert.equal(normalizeModelEntry(null), null);
  assert.equal(normalizeModelEntry({ name: '' }), null);
  assert.deepEqual(normalizeModelEntry({ name: ' UR10 ', epoch: '1:2', at: 42, simulated: true }), {
    name: 'UR10',
    epoch: '1:2',
    at: 42,
    simulated: true,
  });
  assert.deepEqual(normalizeModelEntry({ name: 'UR3', epoch: '', at: NaN }), {
    name: 'UR3',
    epoch: undefined,
    at: undefined,
    simulated: false,
  });
  // 哨兵：TTL 常量必须存在且为正（宿主与文档都引它）
  assert.ok(TWIN_MODEL_TTL_MS > 0);
});

// ── 离线仿真标记（0.7.0）────────────────────────────────────────────────────
//
// 面板与截图必须知道"这一帧是不是一台虚拟机器人"。标记跟型号一起读出来（python 的
// get_robot_model 带 simulated），所以它必须**同生命周期**：型号条目在、标记就在。

test('★ 仿真标记随型号一起进入帧（读取 / 缓存命中 / 推送行三条路都要给对）', async () => {
  const simWorker = {
    call: async (op, params) => (op === 'get_robot_model'
      ? { message: 'UR5e', data: { robot_model: 'UR5e', simulated: true, ip: params?.ip } }
      : worker.call(op, params)),
  };

  // ① 冷缓存：读一次就带上标记
  const store = new Map();
  const h = createTwinStateHandler({
    worker: simWorker,
    connectedIps: () => new Set(['127.0.0.1']),
    modelFor: (ip) => store.get(ip) ?? null,
    setModelFor: (ip, entry) => store.set(ip, entry),
    telemetryEpoch: () => '1:1',
  });
  const first = await h({ ip: '127.0.0.1' });
  assert.equal(first.body.simulated, true, '★ 仿真帧必须带 simulated:true');
  assert.equal(store.get('127.0.0.1').simulated, true, '标记要与型号一起写回缓存');

  // ② 缓存命中（不再读）：标记必须还在 —— 否则面板会闪一下水印又没了
  const second = await h({ ip: '127.0.0.1' });
  assert.equal(second.body.simulated, true, '缓存命中也必须保留仿真标记');

  // ③ 真机帧不得被误标
  const real = await createTwinStateHandler({ worker, connectedIps: () => new Set(['1.2.3.4']) })({ ip: '1.2.3.4' });
  assert.equal(real.body.simulated, false, '真机帧必须是 false');

  // ④ 推送行自带的 simulated 也算证据（型号条目还没刷新时的兜底）
  const pushed = { at: 0, ts: 0, q: [0, 0, 0, 0, 0, 0], tcp: [0, 0, 0.5, 0, 0, 0], epoch: '1:1', simulated: true };
  const viaPush = await createTwinStateHandler({
    worker,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: () => ({ name: 'UR3', epoch: '1:1', at: 0 }),
    telemetry: () => pushed,
  })({ ip: '1.2.3.4' });
  assert.equal(viaPush.body.simulated, true, '推送行带 simulated 时也必须标出来');
});

test('detail=1 附带 dashboard 状态；detail 查询失败不影响位姿通道', async () => {
  const withDetail = {
    call: async (op, params) => {
      if (op === 'status') {
        return { message: 'ok', data: { safety_mode: 'NORMAL', robot_mode: 'RUNNING', running: true, joint_temperatures: [30, 31, 32, 33, 34, 35] } };
      }
      return worker.call(op, params);
    },
  };
  const h = createTwinStateHandler({ worker: withDetail, connectedIps: () => new Set(['1.2.3.4']) });
  const r = await h({ ip: '1.2.3.4', detail: '1' });
  assert.equal(r.body.connected, true);
  assert.equal(r.body.detail.safety_mode, 'NORMAL');
  assert.equal(r.body.detail.running, true);
  assert.equal(r.body.detail.joint_temperatures.length, 6);

  // 不带 detail 时不得付出 dashboard 往返的代价
  const lean = await h({ ip: '1.2.3.4' });
  assert.equal(lean.body.detail, undefined);

  // detail 通道出错：位姿必须照常返回
  const brokenDetail = {
    call: async (op, params) => {
      if (op === 'status') throw new Error('dashboard 挂了');
      return worker.call(op, params);
    },
  };
  const r2 = await createTwinStateHandler({ worker: brokenDetail, connectedIps: () => new Set(['1.2.3.4'])})({ ip: '1.2.3.4', detail: '1' });
  assert.equal(r2.body.connected, true, 'detail 失败不得让位姿通道一起失败');
  assert.equal(r2.body.q.length, 6);
  assert.match(r2.body.detail.error, /dashboard/);
});

test('关节角不完整时给出 degraded 标记，而不是静默冻结画面', async () => {
  const shortQ = {
    call: async (op, params) => ({
      get_joint_pose: { message: '', data: { joint_positions: [] } },
      get_tcp_pose: { message: '', data: { tcp_pose: [] } },
      get_robot_model: { message: '', data: { robot_model: 'UR3' } },
    }[op]),
  };
  const r = await createTwinStateHandler({ worker: shortQ, connectedIps: () => new Set(['1.2.3.4'])})({ ip: '1.2.3.4' });
  assert.equal(r.body.connected, true);
  assert.equal(r.body.degraded, true, '必须显式标记 q 不完整');
  assert.equal(r.body.code, 'incomplete_pose');
});

// ── /twin/state ────────────────────────────────────────────────────────────

test('已连接时返回 connected + model + q + tcp + ts', async () => {
  const h = createTwinStateHandler({ worker, connectedIps: () => new Set(['1.2.3.4']) });
  const r = await h({ ip: '1.2.3.4' });
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, true);
  assert.equal(r.body.model, 'UR3');
  assert.equal(r.body.q.length, 6);
  assert.equal(r.body.tcp.length, 6);
  assert.equal(typeof r.body.ts, 'number');
});

test('契约：路由读的是 op 信封的 .data —— 扁平返回值不得被当成数据', async () => {
  // 反向守卫：真实的 Python 侧就是信封形状（`{message, data}`）。若有人把返回「简化」成扁平
  // 对象却没同步路由，这条会红；反之若有人把路由改回按扁平字段读，上一条用例会红。
  const flat = {
    call: async (op) => ({
      get_joint_pose: { joint_positions: [0, 0, 0, 0, 0, 0] },
      get_tcp_pose: { tcp_pose: [0, 0, 0.5, 0, 0, 0] },
      get_robot_model: { robot_model: 'UR3' },
    }[op]),
  };
  const h = createTwinStateHandler({ worker: flat, connectedIps: () => new Set(['1.2.3.4']) });
  const r = await h({ ip: '1.2.3.4' });
  assert.equal(r.body.connected, true, 'op 成功就是 connected（载荷为空是另一回事）');
  assert.equal(r.body.model, '', '扁平形状不得被当作数据');
  assert.deepEqual(r.body.q, []);
  assert.deepEqual(r.body.tcp, []);
});

test('未连接时返回 connected:false 与原因', async () => {
  const h = createTwinStateHandler({ worker, connectedIps: () => new Set() });
  const r = await h({ ip: '1.2.3.4' });
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, false);
  assert.equal(typeof r.body.reason, 'string');
});

// ── Ruling 35：`ip` 可省略，由 host 依据连接注册表解析 ──────────────────────
// 动机：浏览器半**不知道也不该猜**机器人 IP（计划原稿没定义来源，实现者只能退到默认值
// `192.168.1.199`，而真实机器人是 `192.168.2.201` ⇒ 会永远显示"未连接"）。
// host 本来就持有 connectedIps，故把解析放到 host。

test('省略 ip 且无任何机器人连接时返回 200 + connected:false（不是 400/500）', async () => {
  const h = createTwinStateHandler({ worker, connectedIps: () => new Set() });
  const r = await h({});
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, false);
  assert.match(r.body.reason, /no robot connected/i);
});

test('省略 ip 且恰好一个机器人连接时自动解析到它，并回填 body.ip', async () => {
  const seen = [];
  const spy = { call: async (op, params) => { seen.push(params.ip); return worker.call(op, params); } };
  const h = createTwinStateHandler({ worker: spy, connectedIps: () => new Set(['192.168.2.201']) });
  const r = await h({});
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, true);
  assert.equal(r.body.ip, '192.168.2.201');
  assert.ok(seen.length > 0, 'worker 应被调用');
  assert.deepEqual([...new Set(seen)], ['192.168.2.201'], '所有 worker 调用都必须用解析出的 IP');
});

test('省略 ip 但连接了多个机器人时返回 400（有歧义，必须显式指定）', async () => {
  const h = createTwinStateHandler({
    worker,
    connectedIps: () => new Set(['192.168.2.201', '10.0.0.7']),
  });
  const r = await h({});
  assert.equal(r.status, 400);
  assert.deepEqual(r.body.ips, ['10.0.0.7', '192.168.2.201']);
});

test('ip 为空白字符串时按"省略"处理（走注册表解析），不再直接 400', async () => {
  const h = createTwinStateHandler({ worker, connectedIps: () => new Set(['1.2.3.4']) });
  const r = await h({ ip: '   ' });
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, true);
  assert.equal(r.body.ip, '1.2.3.4');
});

test('显式传入一个未连接的 ip 仍返回 connected:false（原行为不变）', async () => {
  const h = createTwinStateHandler({ worker, connectedIps: () => new Set(['1.2.3.4']) });
  const r = await h({ ip: '9.9.9.9' });
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, false);
  assert.match(r.body.reason, /9\.9\.9\.9/);
});

test('worker 抛错时返回 connected:false 而非 500', async () => {
  const bad = { call: async () => { throw new Error('worker down'); } };
  const h = createTwinStateHandler({ worker: bad, connectedIps: () => new Set(['1.2.3.4']) });
  const r = await h({ ip: '1.2.3.4' });
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, false);
  assert.match(r.body.reason, /worker down/);
});

// ── 0.6.6：读"暂时拿不到"必须降级，不能把机器人报成未连接 ────────────────────
//
// `UrWorker` 是单线程 stdin 队列：机器人执行运动指令期间仿真的读会排队并超时（常态）。
// 以前这被映射成 connected:false ⇒ 客户端藏掉整个 3D 视图与 HUD、写上「未连接机器人」，
// 用户看到的就是"仿真同步两个动作后就不动了"。

/** 造一个"读暂时失败"的 worker（错误码可控）。 */
function flakyWorker(codeRef) {
  return {
    call: async (op, params) => {
      if (codeRef.code !== null) {
        const error = new Error(codeRef.message ?? '暂时拿不到答案');
        error.code = codeRef.code;
        throw error;
      }
      return worker.call(op, params);
    },
  };
}

test('★ 读暂时失败 ⇒ 回放最后一笔已知读数并标 stale（connected 必须保持 true）', async () => {
  const codeRef = { code: null };
  const clock = { t: 1000 };
  const h = createTwinStateHandler({
    worker: flakyWorker(codeRef),
    connectedIps: () => new Set(['1.2.3.4']),
    now: () => clock.t,
  });

  const ok = await h({ ip: '1.2.3.4' });
  assert.equal(ok.body.connected, true);
  assert.equal(ok.body.ts, 1000, 'ts 用注入的时钟');
  assert.equal(ok.body.stale, undefined);

  codeRef.code = 'WORKER_TIMEOUT';
  clock.t = 4000;
  const stale = await h({ ip: '1.2.3.4' });
  assert.equal(stale.status, 200, '绝不变 5xx');
  assert.equal(stale.body.connected, true, '★ 不得报成未连接（否则客户端会藏掉 3D）');
  assert.equal(stale.body.stale, true);
  assert.equal(stale.body.stale_reason, 'WORKER_TIMEOUT');
  assert.equal(stale.body.stale_ms, 3000, '必须给出这帧有多旧');
  assert.deepEqual(stale.body.q, ok.body.q, '必须回放最后一笔已知关节角');
  assert.equal(stale.body.ts, 1000, '★ ts 不得回填 —— 客户端靠它算龄期');
});

test('★ 只有"暂时拿不到"才降级：真正的连接错误仍然必须是 connected:false', async () => {
  const codeRef = { code: null };
  const h = createTwinStateHandler({
    worker: flakyWorker(codeRef),
    connectedIps: () => new Set(['1.2.3.4']),
  });
  await h({ ip: '1.2.3.4' });

  // Python 侧的结构化错误（机器人真的连不上）不是"暂时"类：不许假装还连着。
  codeRef.code = 'TIMEOUT';
  codeRef.message = 'RTDE did not start after connecting to 1.2.3.4';
  const hard = await h({ ip: '1.2.3.4' });
  assert.equal(hard.body.connected, false, '★ 真连接错误不得被降级伪装成陈旧帧');
  assert.equal(hard.body.code, 'robot_error');
  assert.equal(hard.body.stale, undefined);
});

test('★ 陈旧帧回放有窗口：超过 staleMaxMs 之后不再假装知道机器人现在在哪', async () => {
  const codeRef = { code: null };
  const clock = { t: 1000 };
  const h = createTwinStateHandler({
    worker: flakyWorker(codeRef),
    connectedIps: () => new Set(['1.2.3.4']),
    now: () => clock.t,
    staleMaxMs: 5000,
  });
  await h({ ip: '1.2.3.4' });

  codeRef.code = 'WORKER_BUSY';
  clock.t = 5000;                                        // 恰好还在窗口内
  assert.equal((await h({ ip: '1.2.3.4' })).body.stale, true);

  clock.t = 20000;                                       // 远超窗口
  const expired = await h({ ip: '1.2.3.4' });
  assert.equal(expired.body.connected, false, '★ 十分钟前的姿态比"不知道"更危险');
  assert.equal(expired.body.code, 'robot_error');
});

test('worker 为 null（Python 半初始化失败）时返回 200 + connected:false', async () => {
  const h = createTwinStateHandler({ worker: null, connectedIps: () => new Set(['1.2.3.4']) });
  const r = await h({ ip: '1.2.3.4' });
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, false);
  assert.equal(typeof r.body.reason, 'string');
});

test('connectedIps 注册表抛错时降级为未连接而非崩溃', async () => {
  const h = createTwinStateHandler({
    worker,
    connectedIps: () => { throw new Error('registry boom'); },
  });
  const r = await h({ ip: '1.2.3.4' });
  assert.equal(r.status, 200);
  assert.equal(r.body.connected, false);
});

// ── /twin/asset ────────────────────────────────────────────────────────────

test('合法型号命中时返回 200 + model/gltf-binary + Buffer', async () => {
  const h = createTwinAssetHandler({ assetsDir });
  const r = await h({ model: 'ur3' });
  assert.equal(r.status, 200);
  assert.equal(r.headers['content-type'], 'model/gltf-binary');
  assert.ok(Buffer.isBuffer(r.body), 'body 必须是 Buffer');
  assert.equal(r.body.length, 4);
  assert.equal(r.headers['content-length'], '4');
});

test('未知型号（白名单合法但无文件）返回 404', async () => {
  const h = createTwinAssetHandler({ assetsDir });
  const r = await h({ model: 'ur9999' });
  assert.equal(r.status, 404);
  assert.ok(!Buffer.isBuffer(r.body));
});

test('assets/models 目录尚不存在时优雅返回 404（不抛错）', async () => {
  const h = createTwinAssetHandler({ assetsDir: join(assetsDir, 'does-not-exist-yet', 'models') });
  const r = await h({ model: 'ur3' });
  assert.equal(r.status, 404);
});

test('未提供 assetsDir 时返回 404（不抛错）', async () => {
  const h = createTwinAssetHandler({});
  const r = await h({ model: 'ur3' });
  assert.equal(r.status, 404);
});

test('缺少 model 参数时返回 400', async () => {
  const h = createTwinAssetHandler({ assetsDir });
  const r = await h({});
  assert.equal(r.status, 400);
});

test('路径穿越取值一律被拒且不泄露文件内容', async () => {
  const h = createTwinAssetHandler({ assetsDir });
  const attacks = [
    '../../package.json',
    '..\\..\\package.json',
    'ur3/../../package.json',
    '../ur3',
    'ur3.glb',
    '/etc/passwd',
    '....//....//package.json',
    'UR3',
    'ur 3',
    'ur3\u0000',
  ];
  for (const model of attacks) {
    const r = await h({ model });
    assert.equal(r.status, 400, `「${model}」必须被拒（实际 ${r.status}）`);
    assert.ok(!Buffer.isBuffer(r.body), `「${model}」不得返回文件内容`);
    assert.doesNotMatch(JSON.stringify(r.body), new RegExp(PKG_NAME.replace(/[.*+?^${}()|[\]\\]/gu, '\\$&')));
  }
});

// ── 资产缓存（0.5.0）───────────────────────────────────────────────────────
//
// 关掉面板会释放模型句柄（loader 的引用计数到 0），而资产路由以前没有任何校验器 ——
// 于是每次展开面板都要重新下载并解析 1.5–3.5 MB 的 GLB。

test('资产响应带强 ETag 与不可变缓存指令', async () => {
  const h = createTwinAssetHandler({ assetsDir });
  const r = await h({ model: 'ur3' });
  assert.match(r.headers.etag ?? '', /^"[0-9a-f]{40}"$/, '必须是内容哈希形式的强校验器');
  assert.match(r.headers['cache-control'] ?? '', /immutable/);
  assert.match(r.headers['cache-control'] ?? '', /max-age=\d{6,}/);
});

test('If-None-Match 命中时返回 304 且不带正文', async () => {
  const h = createTwinAssetHandler({ assetsDir });
  const first = await h({ model: 'ur3' });
  const again = await h({ model: 'ur3' }, { 'if-none-match': first.headers.etag });
  assert.equal(again.status, 304);
  assert.equal(again.body, '', '304 不得带正文');
  assert.equal(again.headers.etag, first.headers.etag, '304 仍应回带 ETag');

  // 多值 If-None-Match（浏览器/代理会拼起来）也要能命中
  const multi = await h({ model: 'ur3' }, { 'if-none-match': `"deadbeef", ${first.headers.etag}` });
  assert.equal(multi.status, 304);

  // 不匹配时必须照常返回正文
  const changed = await h({ model: 'ur3' }, { 'if-none-match': '"deadbeef"' });
  assert.equal(changed.status, 200);
  assert.ok(Buffer.isBuffer(changed.body));
});

// ── /twin/models ───────────────────────────────────────────────────────────

test('模型清单只列出目录里真实存在的 .glb', async () => {
  const h = createTwinModelsHandler({ assetsDir });
  const r = await h();
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.models, ['ur3']);
});

test('模型清单在目录缺失/未配置时返回空列表而不是报错', async () => {
  const missing = await createTwinModelsHandler({ assetsDir: join(assetsDir, 'nope') })();
  assert.deepEqual(missing.body.models, []);
  const unset = await createTwinModelsHandler({})();
  assert.deepEqual(unset.body.models, []);
});

// ── /twin/stream（0.6.3 起是 SSE）───────────────────────────────────────────
//
// 这一段是 0.6.6 补的：此前**这条路由一条测试都没有**，于是两个真机缺陷长期全绿：
//   ① `pumping` 背压 + 读卡住 ⇒ **一个事件都不发**（客户端只能看到"开着的、安静的流"，
//      画面停在最后一帧且没有提示）—— 机器人运动时 worker 被占住是常态；
//   ② 事件名叫 `error` ⇒ 被浏览器的 `EventSource.onerror` 接走 ⇒ 一次单帧失败就拆流，
//      连来 8 次就进入终态 gaveup，仿真永久冻结。

/** 捕获 SSE 写入的假响应（按 `\n\n` 切事件，解析 `event:` / `data:`）。 */
function makeSseCapture() {
  const events = [];
  let buffer = '';
  const handlers = new Map();
  const res = {
    statusCode: 0,
    headers: {},
    ended: false,
    writeHead(status, headers) { res.statusCode = status; Object.assign(res.headers, headers ?? {}); },
    setHeader(name, value) { res.headers[name] = value; },
    write(chunk) {
      buffer += String(chunk);
      let at;
      while ((at = buffer.indexOf('\n\n')) !== -1) {
        const raw = buffer.slice(0, at);
        buffer = buffer.slice(at + 2);
        const type = /^event: (.*)$/mu.exec(raw)?.[1] ?? 'message';
        const dataLine = /^data: (.*)$/mu.exec(raw)?.[1];
        events.push({ type, data: dataLine === undefined ? undefined : JSON.parse(dataLine) });
      }
      return true;
    },
    end() { res.ended = true; },
    on(event, fn) {
      if (!handlers.has(event)) handlers.set(event, new Set());
      handlers.get(event).add(fn);
    },
    /**
     * 测试收尾：触发 `close`，让 handler 清掉自己的 interval。
     *
     * ⚠️ **每个用例末尾都必须调用**，否则那条 SSE 的 `setInterval` 会一直挂着，
     * `node test/x.test.mjs` 跑完之后进程不退出（表现成"测试卡住"）。
     */
    close() { for (const fn of handlers.get('close') ?? []) fn(); },
  };
  return { res, events };
}

/** 假请求（handler 只读 method/url 与 close/error 事件）。 */
function requestOf(url = '/twin/stream?ip=1.2.3.4') {
  const handlers = new Map();
  return {
    method: 'GET',
    url,
    on(event, fn) {
      if (!handlers.has(event)) handlers.set(event, new Set());
      handlers.get(event).add(fn);
    },
    close() { for (const fn of handlers.get('close') ?? []) fn(); },
  };
}

/** 轮询等待条件成立（比固定 sleep 稳，不受 CI 抖动影响）。 */
async function waitFor(condition, timeoutMs = 2000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (condition()) return true;
    await new Promise((r) => setTimeout(r, 5));
  }
  return condition();
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

test('事件名常量：单帧失败**绝不能**叫 error（否则会被 EventSource.onerror 接走）', () => {
  assert.equal(TWIN_STREAM_FRAME_ERROR_EVENT, 'frame-error');
  assert.notEqual(TWIN_STREAM_FRAME_ERROR_EVENT, 'error');
  assert.notEqual(TWIN_STREAM_STALE_EVENT, 'error');
  assert.equal(TWIN_STREAM_STALE_EVENT, 'stale');
});

test('SSE 响应头与首帧：立刻推一帧 state（订阅者不该先干等一个 interval）', async () => {
  const { res, events } = makeSseCapture();
  const req = requestOf();
  const handler = createTwinStreamHandler({
    worker,
    connectedIps: () => new Set(['1.2.3.4']),
    intervalMs: 1000,
    detailMs: 0,
  });
  handler(req, res);

  assert.match(res.headers['content-type'], /text\/event-stream/);
  assert.match(res.headers['cache-control'], /no-store/);
  assert.equal(res.headers['x-accel-buffering'], 'no');
  assert.equal(res.statusCode, 200);
  await waitFor(() => events.length >= 1);
  assert.equal(events[0].type, 'state', '首个事件必须是 state');
  assert.equal(events[0].data.connected, true);
  assert.equal(events[0].data.q.length, 6);
  req.close();
  assert.equal(res.ended, true, '客户端断开后必须收尾（不留 interval）');
});

test('非 GET 一律 405', () => {
  const { res } = makeSseCapture();
  createTwinStreamHandler({ worker, connectedIps: () => new Set() })(
    { method: 'POST', url: '/twin/stream', on() {} },
    res,
  );
  assert.equal(res.statusCode, 405);
});

test('★ H-3：同一 handler 的并发订阅有上限，超额订阅明确回 503（而不是让所有订阅一起饿死）', () => {
  const handler = createTwinStreamHandler({
    worker,
    connectedIps: () => new Set(['1.2.3.4']),
    intervalMs: 1000,
    detailMs: 0,
    maxClients: 2, // 便于测试；真实默认值 = 读类在飞槽位数（TWIN_STREAM_MAX_CLIENTS，当前 3）
  });

  const a = makeSseCapture();
  const b = makeSseCapture();
  const c = makeSseCapture();
  const reqA = requestOf();
  const reqB = requestOf();
  const reqC = requestOf();
  handler(reqA, a.res);
  handler(reqB, b.res);
  handler(reqC, c.res);

  assert.equal(a.res.statusCode, 200);
  assert.equal(b.res.statusCode, 200);
  assert.equal(c.res.statusCode, 503, '第 3 路必须被明确拒绝');
  assert.match(String(c.res.headers['content-type']), /application\/json/);
  assert.equal(c.res.ended, true);

  // 前面的订阅关闭后必须能再接受新的：计数是幂等的，不会漏减、也不会被减两次。
  reqA.close();
  reqB.close();
  const d = makeSseCapture();
  const reqD = requestOf();
  handler(reqD, d.res);
  assert.equal(d.res.statusCode, 200, '订阅关闭后计数必须回落');
  reqC.close(); // 压根没被接受的那条：cleanup 不得把计数减第二次
  reqD.close();
});

test('★ worker 被占住（机器人运动中）时**绝不静默**：改发 stale 事件', async () => {
  let blocked = true;
  const slowWorker = {
    call: async (op, params) => {
      if (blocked) await sleep(300);
      return worker.call(op, params);
    },
  };
  const { res, events } = makeSseCapture();
  const handler = createTwinStreamHandler({
    worker: slowWorker,
    connectedIps: () => new Set(['1.2.3.4']),
    intervalMs: 10,
    staleNotifyMs: 20,
    frameTimeoutMs: 5000,
    detailMs: 0,
  });
  const req = requestOf();
  handler(req, res);

  assert.ok(
    await waitFor(() => events.some((e) => e.type === 'stale')),
    1000,
  );
  const stale = events.find((e) => e.type === 'stale');
  assert.ok(Number.isFinite(stale.data.pendingMs), 'stale 必须带上"这一帧已经等了多久"');
  assert.equal(events.filter((e) => e.type === 'state').length, 0, '读还没回来，不该有 state');
  assert.ok(events.every((e) => e.type !== 'error'), '★ 服务端事件里绝不出现名叫 error 的事件');

  // 放开 worker：必须立刻恢复推 state（这就是"机器人运动完仿真自动跟上"）
  blocked = false;
  assert.ok(await waitFor(() => events.some((e) => e.type === 'state')), 2000);
  req.close();
});

test('★ 单帧读抛错（暂时拿不到）⇒ 回放陈旧帧，而不是把机器人报成未连接', async () => {
  let broken = false; // 先成功一帧，攒下"最后一笔已知读数"
  const flaky = {
    call: async (op, params) => {
      if (broken) {
        const error = new Error('UR call "get_joint_pose" timed out after 2500ms');
        error.code = 'WORKER_TIMEOUT';
        throw error;
      }
      return worker.call(op, params);
    },
  };
  const { res, events } = makeSseCapture();
  const handler = createTwinStreamHandler({
    worker: flaky,
    connectedIps: () => new Set(['1.2.3.4']),
    intervalMs: 10,
    detailMs: 0,
  });
  const req = requestOf();
  handler(req, res);

  assert.ok(await waitFor(() => events.some((e) => e.type === 'state')), 2000);
  const first = events.find((e) => e.type === 'state');
  assert.equal(first.data.stale, undefined, '第一帧是好帧，不该被标成陈旧');

  broken = true;
  assert.ok(
    await waitFor(() => events.some((e) => e.type === 'state' && e.data.stale === true)),
    2000,
    '★ 读暂时失败必须降级成陈旧帧（客户端据此保留 3D 与读数）',
  );
  const stale = events.filter((e) => e.type === 'state' && e.data.stale === true).at(-1);
  assert.equal(stale.data.connected, true, '★ 绝不能变成"未连接"（那会把 3D 视图整个藏起来）');
  assert.deepEqual(stale.data.q, first.data.q, '必须回放最后一笔已知关节角');
  assert.equal(stale.data.ts, first.data.ts, '★ ts 必须保持不变 —— 龄期要靠它自然增长');
  assert.equal(stale.data.stale_reason, 'WORKER_TIMEOUT');
  assert.ok(Number.isFinite(stale.data.stale_ms));
  assert.ok(events.every((e) => e.type !== 'error'), '★ 绝不发名为 error 的事件');

  broken = false;
  assert.ok(
    await waitFor(() => events.some((e) => e.type === 'state' && e.data.stale === undefined)),
    2000,
    '恢复后必须重新推新鲜帧',
  );
  req.close();
});

test('★ 读永不 settle 时有安全网：放弃该帧、发 frame-error、随后恢复', async () => {
  let hang = true;
  const hanging = {
    call: async (op, params) => {
      if (hang) return new Promise(() => {});
      return worker.call(op, params);
    },
  };
  const { res, events } = makeSseCapture();
  const handler = createTwinStreamHandler({
    worker: hanging,
    connectedIps: () => new Set(['1.2.3.4']),
    intervalMs: 10,
    staleNotifyMs: 10,
    frameTimeoutMs: 60,
    detailMs: 0,
  });
  const req = requestOf();
  handler(req, res);

  assert.ok(
    await waitFor(() => events.some((e) => e.type === TWIN_STREAM_FRAME_ERROR_EVENT && e.data.reason === 'read_timeout')),
    2000,
    '超时没回来必须被放弃并如实上报',
  );
  assert.equal(res.ended, false, '安全网不得拆流');

  hang = false;
  assert.ok(await waitFor(() => events.some((e) => e.type === 'state')), 2000, '放弃该帧后必须能重新读数');
  req.close();
});

test('★ 背压：同一时刻只有一帧读在飞（绝不向单线程 worker 叠加请求）', async () => {
  let concurrent = 0;
  let peak = 0;
  const slowish = {
    call: async (op, params) => {
      concurrent += 1;
      peak = Math.max(peak, concurrent);
      await sleep(40);
      concurrent -= 1;
      return worker.call(op, params);
    },
  };
  const { res, events } = makeSseCapture();
  const handler = createTwinStreamHandler({
    worker: slowish,
    connectedIps: () => new Set(['1.2.3.4']),
    intervalMs: 5,
    staleNotifyMs: 10,
    detailMs: 0,
  });
  const req = requestOf();
  handler(req, res);
  await waitFor(() => events.some((e) => e.type === 'state'), 2000);
  await sleep(120);
  // 一帧的读 = get_joint_pose + get_tcp_pose（外加可能的 detail），但帧与帧之间必须串行：
  // 若叠帧，40ms 的读 + 5ms 的节拍会轻易把这个峰值推到 6 以上。
  assert.ok(peak <= 3, `并发 worker 调用峰值 ${peak} 过高 —— 帧之间没有串行（会堆满 maxInFlight=8）`);
  req.close();
});

// ── 主动推送遥测：机器人运动期间仿真不再断流 ────────────────────────────────
//
// 背景：Python worker 是单线程 stdin 队列，运动命令（`_movej_confirm` / `_wait_robot_idle`
// 那类确认循环）会占住它几十秒，仿真的读排在后面并超时 —— 用户看到的是「数据已停止更新
// Ns · 正在重试」。现在 worker 主动推送 RTDE 缓存里的姿态（见 lib/worker.js 的 `_onPush`），
// 仿真优先读它，于是每一帧**零 worker 往返**。

test('★ 新鲜的主动推送让仿真帧完全绕开 worker（运动时唯一还通的路）', async () => {
  let workerCalls = 0;
  const countingWorker = {
    call: async () => {
      workerCalls += 1;
      throw new Error('运动期间这次读会排在运动命令后面并超时；新鲜推送时本就不该调用它');
    },
  };
  const now = 1_700_000_000_000;
  const handler = createTwinStateHandler({
    worker: countingWorker,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: () => 'UR3',
    now: () => now,
    telemetry: (ip) => (ip === '1.2.3.4'
      ? { at: now - 20, ts: now - 20, q: [0.1, 0.2, 0.3, 0.4, 0.5, 0.6], tcp: [0.3, 0, 0.5, 0, 0, 0] }
      : undefined),
  });

  const result = await handler({ ip: '1.2.3.4' });

  assert.equal(result.status, 200);
  assert.equal(result.body.connected, true);
  assert.deepEqual(result.body.q, [0.1, 0.2, 0.3, 0.4, 0.5, 0.6]);
  assert.deepEqual(result.body.tcp, [0.3, 0, 0.5, 0, 0, 0]);
  assert.equal(result.body.ts, now - 20, 'ts 必须是采样时刻，而不是推送到达的时刻');
  assert.equal(workerCalls, 0, '新鲜推送时一次 worker 往返都不该发生');
});

test('推送过期就回退到显式读（陈旧缓存绝不冒充实时读数）', async () => {
  let workerCalls = 0;
  const now = 1_700_000_000_001;
  const handler = createTwinStateHandler({
    worker: {
      call: async (op, params) => {
        workerCalls += 1;
        return {
          get_joint_pose: { message: '', data: { joint_positions: [1, 1, 1, 1, 1, 1], ip: params?.ip } },
          get_tcp_pose: { message: '', data: { tcp_pose: [0, 0, 1, 0, 0, 0], ip: params?.ip } },
        }[op];
      },
    },
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: () => 'UR3',
    now: () => now,
    telemetry: () => ({ at: now - 5000, ts: now - 5000, q: [9, 9, 9, 9, 9, 9], tcp: [9, 9, 9, 9, 9, 9] }),
  });

  const result = await handler({ ip: '1.2.3.4' });

  assert.deepEqual(result.body.q, [1, 1, 1, 1, 1, 1], '过期推送不得被当成实时读数');
  assert.equal(result.body.ts, now, '这一帧是现读的，ts 用读取时刻');
  assert.ok(workerCalls >= 2, '过期时必须回退到真实读');
});

test('推送读取抛错时静默降级到显式读（遥测是加分项，不能弄坏查询）', async () => {
  const handler = createTwinStateHandler({
    worker,
    connectedIps: () => new Set(['1.2.3.4']),
    modelFor: () => 'UR3',
    telemetry: () => { throw new Error('推送缓存坏了') },
  });

  const result = await handler({ ip: '1.2.3.4' });

  assert.equal(result.body.connected, true);
  assert.deepEqual(result.body.q, [0, 0, 0, 0, 0, 0]);
});


// ── I/O 与寄存器通道（0.1.9）────────────────────────────────────────────────

test('★ 0.1.9：io=1 一次读回数字位与模拟输入，并带上"仿真没有输入源"的说明', async () => {
  const calls = [];
  const ioWorker = {
    call: async (op, params) => {
      calls.push({ op, params });
      // ⚠️ 名字必须与 `python/ur_worker.py` 的 HANDLERS 一致：数字输出是 `get_digital_output_bits`
      // （output），不是 `get_digital_out_bits`（out）—— 工具名 `ursim_get_digital_out_bits` 少一个
      // "put"，这里曾经跟着伪造，于是"面板 I/O 读不出值"在四道门全绿的情况下漏到了用户面前。
      if (op === 'get_digital_output_bits') {
        return { data: { bits: [true, false, false, false, false, false, false, false,
                               false, false, false, false, false, false, false, true] } };
      }
      if (op === 'get_digital_input_bits') {
        return { data: { bits: new Array(16).fill(false), note: '仿真没有输入信号源：恒为 0。' } };
      }
      if (op === 'get_analog_in') return { data: { value: 0 } };
      return { data: {} };
    },
  };
  const res = await createTwinStateHandler({ worker: ioWorker, connectedIps: () => new Set(['9.9.9.9']) })(
    { ip: '9.9.9.9', io: '1' },
  );
  assert.equal(res.status, 200);
  assert.equal(res.body.io.digital_out.length, 16);
  assert.equal(res.body.io.digital_out[0], true);
  assert.equal(res.body.io.digital_out[15], true);
  assert.equal(res.body.io.digital_in.length, 16);
  assert.equal(res.body.io.digital_in.every((b) => b === false), true);
  assert.deepEqual(res.body.io.analog_in, [0, 0]);
  assert.match(String(res.body.io.note), /输入/);
  // ⚠️ 状态路由**总会**读位姿与型号，所以这里只筛 I/O 相关 op 来断言。
  assert.deepEqual(
    calls.filter((c) => /digital|analog/.test(c.op)).map((c) => c.op).sort(),
    ['get_analog_in', 'get_analog_in', 'get_digital_input_bits', 'get_digital_output_bits'],
    '★ 只走 RTDE 侧的读法（不走会打断程序的 get_digital_in(which=tool)）',
  );
});

test('★ 0.1.9：寄存器按 set + from/count 分片，count 有硬上限、上界按集合截断', async () => {
  const seen = [];
  const regWorker = {
    call: async (op, params) => {
      seen.push({ op, index: params.index });
      return { data: { value: params.index } };
    },
  };
  const make = () => createTwinStateHandler({ worker: regWorker, connectedIps: () => new Set(['9.9.9.9']) });

  const res = await make()({ ip: '9.9.9.9', reg: 'int', from: '0', count: '999' });
  assert.equal(res.body.registers.set, 'int');
  assert.equal(res.body.registers.values.length, 16, '★ count 必须被夹到 16');
  assert.deepEqual(res.body.registers.values.slice(0, 3), [0, 1, 2]);
  // 同样只筛寄存器 op：状态路由总会先读位姿与型号。
  const regOps = (list) => list.filter((c) => c.op.startsWith('get_int_register') || c.op.startsWith('get_bit_register'));
  assert.equal(regOps(seen).every((c) => c.op === 'get_int_register'), true);
  assert.equal(regOps(seen).length, 16, 'int 分片应恰好读 16 个下标');

  seen.length = 0;
  const tail = await make()({ ip: '9.9.9.9', reg: 'bit', from: '60', count: '8' });
  assert.equal(tail.body.registers.values.length, 4, 'bit 集合的上界是 63 ⇒ 60 起只剩 4 个');
  assert.equal(regOps(seen).every((c) => c.op === 'get_bit_register'), true);
});

test('★ 0.1.9：I/O 读失败只写进自己的字段，位姿通道照常', async () => {
  const picky = {
    call: async (op) => {
      if (op === 'get_joint_pose') return { data: { joint_positions: [0, 0, 0, 0, 0, 0] } };
      if (op === 'get_tcp_pose') return { data: { tcp_pose: [0, 0, 0.5, 0, 0, 0] } };
      if (op === 'get_robot_model') return { data: { robot_model: 'UR3', remote_control: false } };
      throw new Error('I/O 读不到');
    },
  };
  const res = await createTwinStateHandler({ worker: picky, connectedIps: () => new Set(['9.9.9.9']) })(
    { ip: '9.9.9.9', io: '1' },
  );
  assert.equal(res.body.connected, true, '★ 位姿通道不受影响');
  assert.match(String(res.body.io.error), /I\/O 读不到/);
});

// ── P0-2：I/O 与寄存器的扇出必须收进读类闸门 ────────────────────────────────
//
// 读类闸门（`TWIN_READ_MAX_IN_FLIGHT = 3`）按**单次调用**计数。一帧 `/state?io=1` 自己就发 4 个
// 读（寄存器最多 16 个）—— 用 `Promise.all` 并发扇出会在宿主侧被自己的闸门拒成 WORKER_BUSY，
// 而 `Promise.all` 首个 reject 就把整块 I/O / 寄存器变成 `{error}`（面板显示"读取失败"）。
// 所以扇出必须串行执行：同一帧任何时刻只占 1 个读槽。

/**
 * 假 worker：**模拟读类闸门**（任一时刻最多 `cap` 个在飞，超出立刻 WORKER_BUSY）。
 *
 * 形状对齐 `lib/worker.js` 的准入语义（H-3）。每个读故意跨一个宏任务再完成 —— 如果实现又退回
 * `Promise.all`，第 4 个并发读一定会撞上闸门。
 */
function gatedTwinWorker(cap = 3) {
  const inFlight = new Set();
  let seq = 0;
  let maxSeen = 0;
  const reply = (op, params) => {
    if (op === 'get_joint_pose') return { message: 'q', data: { joint_positions: [0, 0, 0, 0, 0, 0] } };
    if (op === 'get_tcp_pose') return { message: 'tcp', data: { tcp_pose: [0, 0, 0.5, 0, 0, 0] } };
    if (op === 'get_robot_model') return { message: 'UR3', data: { robot_model: 'UR3', remote_control: false } };
    if (op === 'get_digital_output_bits') return { message: 'o', data: { bits: new Array(16).fill(true) } };
    if (op === 'get_digital_input_bits') return { message: 'i', data: { bits: new Array(16).fill(false) } };
    if (op === 'get_analog_in') return { message: 'a', data: { value: 0 } };
    if (op === 'get_int_register') return { message: 'r', data: { value: params.index } };
    return { message: 'stub', data: {} };
  };
  return {
    maxSeen: () => maxSeen,
    inFlight: () => inFlight.size,
    call: async (op, params) => {
      if (inFlight.size >= cap) {
        const error = new Error(`UR worker 的 twin-read 类请求已达上限（${cap}）：读类请求不得挤占命令槽位。`);
        error.code = 'WORKER_BUSY';
        throw error;
      }
      const token = (seq += 1);
      inFlight.add(token);
      maxSeen = Math.max(maxSeen, inFlight.size);
      try {
        await new Promise((resolve) => setTimeout(resolve, 0));
        return reply(op, params);
      } finally {
        inFlight.delete(token);
      }
    },
  };
}

test('★ P0-2：一帧 io=1 的 4 个扇出读不得撞上读类闸门（不出现 WORKER_BUSY）', async () => {
  const worker = gatedTwinWorker(3);
  const res = await createTwinStateHandler({ worker, connectedIps: () => new Set(['9.9.9.9']) })(
    { ip: '9.9.9.9', io: '1' },
  );

  assert.equal(res.status, 200);
  assert.equal(res.body.connected, true);
  assert.equal(
    res.body.io.error,
    undefined,
    `一帧 4 个 I/O 读必须全部成功（旧 Promise.all 扇出会让第 4 个拿到 WORKER_BUSY）：${res.body.io.error ?? ''}`,
  );
  assert.equal(res.body.io.digital_out.length, 16);
  assert.deepEqual(res.body.io.analog_in, [0, 0]);
  assert.ok(worker.maxSeen() <= 3, `并发读最多只能占 3 个槽，实测 ${worker.maxSeen()}`);
  assert.equal(worker.inFlight(), 0, '全部读完必须释放槽位');
});

test('★ P0-2：一帧 16 个寄存器读（count 上限）不得出现 WORKER_BUSY', async () => {
  const worker = gatedTwinWorker(3);
  const res = await createTwinStateHandler({ worker, connectedIps: () => new Set(['9.9.9.9']) })(
    { ip: '9.9.9.9', reg: 'int', from: '0', count: '16' },
  );

  assert.equal(res.status, 200);
  assert.equal(
    res.body.registers.error,
    undefined,
    `16 个寄存器读必须全部成功：${res.body.registers.error ?? ''}`,
  );
  assert.equal(res.body.registers.values.length, 16, '★ count 必须被夹到 16 且全部读回');
  assert.equal(res.body.registers.values.at(-1), 15);
  assert.ok(worker.maxSeen() <= 3, `并发读最多只能占 3 个槽，实测 ${worker.maxSeen()}`);
  assert.equal(worker.inFlight(), 0, '全部读完必须释放槽位');
});

test('★ P0-2：I/O 某一拍读失败时用上一笔成功读数降级，而不是整块变成错误行', async () => {
  const state = { fail: false, ioCalls: 0 };
  const worker = {
    call: async (op) => {
      if (/digital|analog/.test(op)) {
        state.ioCalls += 1;
        // 模拟"这一拍撞上读类闸门 / worker 正被运动命令占住"。
        if (state.fail) {
          const error = new Error('读类闸门忙，这一拍读不到');
          error.code = 'WORKER_BUSY';
          throw error;
        }
        if (op === 'get_digital_output_bits') {
          return { message: 'o', data: { bits: [true, ...new Array(15).fill(false)] } };
        }
        if (op === 'get_digital_input_bits') {
          return { message: 'i', data: { bits: new Array(16).fill(false) } };
        }
        return { message: 'a', data: { value: 0 } };
      }
      if (op === 'get_joint_pose') return { message: 'q', data: { joint_positions: [0, 0, 0, 0, 0, 0] } };
      if (op === 'get_tcp_pose') return { message: 'tcp', data: { tcp_pose: [0, 0, 0.5, 0, 0, 0] } };
      if (op === 'get_robot_model') return { message: 'UR3', data: { robot_model: 'UR3' } };
      return { message: 'stub', data: {} };
    },
  };
  const handler = createTwinStateHandler({ worker, connectedIps: () => new Set(['9.9.9.9']) });

  const first = await handler({ ip: '9.9.9.9', io: '1' });
  assert.equal(first.body.io.error, undefined, '第一拍是好的（下面断言缓存来自它）');
  assert.equal(first.body.io.digital_out[0], true);

  state.fail = true;
  const callsBefore = state.ioCalls;
  const second = await handler({ ip: '9.9.9.9', io: '1' });
  assert.equal(second.body.connected, true, '★ 失败的一拍不得毁掉位姿通道');
  // 有缓存之后就不再让帧等 I/O（与详情同一策略）：直接给上一笔，连错误行都不必糊上去。
  assert.equal(second.body.io.error, undefined, '★ 有缓存时直接给上一笔，不拿错误行糊住面板');
  assert.equal(second.body.io.digital_out.length, 16, '★ 必须带上上一笔成功读数');
  assert.equal(second.body.io.digital_out[0], true, '缓存里的值必须原样保留');
  assert.ok(state.ioCalls > callsBefore, '★ 后台仍然试着刷新一次（失败只是不更新缓存）');
});

// ── 面板控制（jog）路由的请求校验 ───────────────────────────────────────────

test('★ jog 路由：只接受 cartesian / rotate / joint / pose / home / speed / velocity / stop 八种 mode', () => {
  /*
   * ⚠️ 这条负例必须是「**其余字段全部合法、只有 mode 非法**」。
   *
   * 裸 `{ mode: 'nope' }` 是**空测**：它连 axis / deltaRad 都没有，下游守卫本来就会
   * 返回 null —— 把白名单整句删掉（只留 `typeof mode !== 'string'`）它也照样变红，
   * 于是「六种 mode 的白名单」根本没有用例守护。下面这条带着完整的合法载荷：
   * 只有去掉 `TWIN_JOG_MODES.has(mode)` 才会返回非 null。
   */
  assert.equal(
    parseJogRequest({ mode: 'nope', axis: 'rx', deltaRad: 0.02 }),
    null,
    '★ mode 白名单：其余字段全部合法时也必须拒（这条才能真正钉住白名单）',
  );
  for (const body of [null, {}, { mode: 'nope' }, { mode: 'speed', fraction: '0.5' }]) {
    assert.equal(parseJogRequest(body), null, `${JSON.stringify(body)} 应被拒绝`);
  }
});

/*
 * 八种 mode 各一条**正向**用例，用 `deepEqual` 钉住整形结果。
 *
 * 为什么不能用 `assert.ok(x !== null)`：那只证明"没被拒"，证明不了白名单里真的有这一项 ——
 * 把 `TWIN_JOG_MODES` 里任意一个成员删掉，对应的这一条会立刻变红。返回对象的形状
 * （缺省 frame、speed 的 requested、数值是否被原样保留）也一并被钉死。
 */
const JOG_MODE_POSITIVES = [
  {
    mode: 'cartesian',
    body: { mode: 'cartesian', axis: 'y', distance: 0.02, frame: 'base' },
    expected: { mode: 'cartesian', axis: 'y', distance: 0.02, frame: 'base' },
  },
  {
    mode: 'rotate',
    body: { mode: 'rotate', axis: 'ry', deltaRad: -0.03 },
    expected: { mode: 'rotate', axis: 'ry', deltaRad: -0.03, frame: 'tool' },
  },
  {
    mode: 'joint',
    body: { mode: 'joint', q: [0, -1.5, 0, -1.5, -1.5, 0] },
    expected: { mode: 'joint', q: [0, -1.5, 0, -1.5, -1.5, 0] },
  },
  {
    mode: 'pose',
    body: { mode: 'pose', pose: [0.1, -0.2, 0.3, 0, 0.1, 0] },
    expected: { mode: 'pose', pose: [0.1, -0.2, 0.3, 0, 0.1, 0] },
  },
  { mode: 'home', body: { mode: 'home' }, expected: { mode: 'home' } },
  {
    mode: 'speed',
    body: { mode: 'speed', fraction: 0.5 },
    expected: { mode: 'speed', fraction: 0.5, requested: 0.5 },
  },
  {
    mode: 'velocity',
    body: { mode: 'velocity', twist: [0.05, 0, 0, 0, 0, 0] },
    // 缺省 frame 必须是 **base**（与 cartesian/rotate 的 tool 不同），ttlMs 缺省 400。
    expected: { mode: 'velocity', twist: [0.05, 0, 0, 0, 0, 0], frame: 'base', ttlMs: 400 },
  },
  {
    mode: 'velocity(tool)',
    body: { mode: 'velocity', twist: [0, 0, 0, 0, 0, 0.2], frame: 'tool', ttlMs: 250 },
    expected: { mode: 'velocity', twist: [0, 0, 0, 0, 0, 0.2], frame: 'tool', ttlMs: 250 },
  },
  { mode: 'stop', body: { mode: 'stop' }, expected: { mode: 'stop' } },
];

for (const { mode, body, expected } of JOG_MODE_POSITIVES) {
  test(`★ jog 路由：${mode} 的整形结果必须精确（白名单删掉这一项就红）`, () => {
    assert.deepEqual(parseJogRequest(body), expected);
  });
}

test('★ jog 路由：speed 模式把倍率钳到 0.01–1.0，并回显原始值', () => {
  const low = parseJogRequest({ mode: 'speed', fraction: 0.001 });
  assert.equal(low.fraction, 0.01);
  assert.equal(low.requested, 0.001);
  const high = parseJogRequest({ mode: 'speed', fraction: 9 });
  assert.equal(high.fraction, 1);
});

test('★ jog 路由：cartesian / rotate 的 frame 只接受 tool / base', () => {
  assert.equal(parseJogRequest({ mode: 'cartesian', axis: 'x', distance: 0.005, frame: 'moon' }), null);
  assert.ok(parseJogRequest({ mode: 'rotate', axis: 'rx', deltaRad: 0.02, frame: 'base' }));
});

/*
 * 速度流（长按连续点动）的校验。
 *
 * `twist` 是六元有限数（m/s / rad/s）：少一维、含 NaN、字符串数字都必须拒绝 ——
 * 放过去就是一条语义未定义的速度指令，而它会让机械臂**持续**运动（不是走一步）。
 * 全零 twist 是合法的（等价于 stop，协议明确允许），所以这里**不**把它当非法值。
 */
test('★ jog 路由：velocity 的 twist 必须是 6 个有限数（5 元 / NaN / 字符串一律拒绝）', () => {
  assert.equal(parseJogRequest({ mode: 'velocity' }), null, '缺 twist 必须拒绝');
  assert.equal(parseJogRequest({ mode: 'velocity', twist: [0, 0, 0, 0, 0] }), null, '5 元必须拒绝');
  assert.equal(
    parseJogRequest({ mode: 'velocity', twist: [0, 0, 0, 0, 0, NaN] }),
    null,
    'NaN 不能靠"是 number"混过去',
  );
  assert.equal(
    parseJogRequest({ mode: 'velocity', twist: ['0.05', 0, 0, 0, 0, 0] }),
    null,
    '字符串数字必须拒绝（不做隐式转换）',
  );
  assert.equal(
    parseJogRequest({ mode: 'velocity', twist: [0, 0, 0, 0, 0, Infinity] }),
    null,
    'Infinity 必须拒绝',
  );
  // 全零合法：协议规定它等价于 stop。
  assert.deepEqual(
    parseJogRequest({ mode: 'velocity', twist: [0, 0, 0, 0, 0, 0] }),
    { mode: 'velocity', twist: [0, 0, 0, 0, 0, 0], frame: 'base', ttlMs: 400 },
    '全零 twist 必须被接受（等价于 stop）',
  );
});

test('★ jog 路由：velocity 的 frame 只接受 tool / base，缺省 base', () => {
  assert.equal(parseJogRequest({ mode: 'velocity', twist: [0, 0, 0, 0, 0, 0], frame: 'world' }), null);
  assert.equal(parseJogRequest({ mode: 'velocity', twist: [0, 0, 0, 0, 0, 0] }).frame, 'base');
  assert.equal(
    parseJogRequest({ mode: 'velocity', twist: [0, 0, 0, 0, 0, 0], frame: 'tool' }).frame,
    'tool',
  );
});

test('★ jog 路由：velocity 的 ttlMs 缺省 400，越界钳到 100 / 2000（不是报错）', () => {
  const base = { mode: 'velocity', twist: [0.05, 0, 0, 0, 0, 0] };
  assert.equal(parseJogRequest(base).ttlMs, 400, '缺省必须是 400ms');
  assert.equal(parseJogRequest({ ...base, ttlMs: 0 }).ttlMs, 100, '0 必须钳到下限 100');
  assert.equal(parseJogRequest({ ...base, ttlMs: 99999 }).ttlMs, 2000, '99999 必须钳到上限 2000');
  assert.equal(parseJogRequest({ ...base, ttlMs: 250 }).ttlMs, 250, '区间内原样保留');
  // 非数值/NaN 不能钳（钳 NaN 仍是 NaN）—— 必须拒绝。
  assert.equal(parseJogRequest({ ...base, ttlMs: NaN }), null);
  assert.equal(parseJogRequest({ ...base, ttlMs: '400' }), null);
  assert.equal(parseJogRequest({ ...base, ttlMs: Infinity }), null);
});

test('★ jog 路由：stop 无额外字段（多传的一律忽略，停止不该被参数卡住）', () => {
  assert.deepEqual(parseJogRequest({ mode: 'stop' }), { mode: 'stop' });
  assert.deepEqual(
    parseJogRequest({ mode: 'stop', twist: [1, 2, 3, 4, 5, 6], ttlMs: 'nope', junk: true }),
    { mode: 'stop' },
  );
});

test('★ jog 路由：joint 必须是 6 个有限数，pose 必须是 6 个有限数', () => {
  assert.equal(parseJogRequest({ mode: 'joint', q: [0, 0, 0] }), null);
  assert.equal(parseJogRequest({ mode: 'joint', q: [0, 0, 0, 0, 0, NaN] }), null);
  assert.equal(parseJogRequest({ mode: 'pose', pose: [0, 0, 0, 0, 0] }), null);
});

/*
 * axis 白名单（两处**互不相同**的守卫）。
 *
 * 为什么值得单独测：白名单是**唯一**拦住"把轴名拼进 op 名"的地方 —— cartesian 的
 * `move_${axis}` / `move_tool_${axis}` 是字符串拼出来的，一个拼错的轴名会变成一条
 * worker 不认识的 op；rotate 的轴则直接进 `jog_rotate`。两处白名单各自只能拦自己那一
 * 半（平移轴 vs 旋转轴），所以两边各要一条反例，否则删掉任一处都不会变红。
 */
test('★ jog 路由：cartesian 的 axis 只收 x / y / z（未知轴与旋转轴都拒绝）', () => {
  // 正向：三个平移轴都要能派发（只留 'x'、删掉 'y' 或 'z' 会让这条立刻变红）。
  for (const axis of ['x', 'y', 'z']) {
    assert.deepEqual(
      parseJogRequest({ mode: 'cartesian', axis, distance: 0.01 }),
      { mode: 'cartesian', axis, distance: 0.01, frame: 'tool' },
      `cartesian 的 ${axis} 轴必须被接受`,
    );
  }
  // 不传 frame ⇒ 缺省必须是 'tool'（面板下拉框的默认，也是"点动一下"最直觉的坐标系）。
  assert.equal(
    parseJogRequest({ mode: 'cartesian', axis: 'z', distance: 0.01 }).frame,
    'tool',
    '★ 省略 frame 时必须缺省成 tool',
  );
  // 未知轴：既不是平移也不是旋转。
  assert.equal(parseJogRequest({ mode: 'cartesian', axis: 'w', distance: 0.005 }), null);
  // 旋转轴在这个分支里非法：`distance` 单位是米，`rx` 是弧度轴（那是 rotate 的事）。
  assert.equal(parseJogRequest({ mode: 'cartesian', axis: 'rx', distance: 0.005 }), null);
});

test('★ jog 路由：rotate 的 axis 只收 rx / ry / rz（平移轴拒绝）', () => {
  // 正向：三个旋转轴都要能派发（删掉 'ry' 会被这条抓住）。
  for (const axis of ['rx', 'ry', 'rz']) {
    assert.deepEqual(
      parseJogRequest({ mode: 'rotate', axis, deltaRad: 0.02 }),
      { mode: 'rotate', axis, deltaRad: 0.02, frame: 'tool' },
      `rotate 的 ${axis} 轴必须被接受`,
    );
  }
  // 平移轴进 `jog_rotate` 会被 Python 侧当非法轴 —— 宿主这一层就该先拒。
  assert.equal(parseJogRequest({ mode: 'rotate', axis: 'x', deltaRad: 0.02 }), null);
});

/*
 * 零值与非法数值（两条独立的守卫）。
 *
 * 零位移不是"无害的边界值"：它是面板松手/浮点下溢的产物，放过去就是一条**空转的**
 * 运动指令 —— worker 是单线程 stdin 队列，那条指令照样占住队列直到自己超时。
 * 字符串 `'0.005'` 与 `Infinity` 覆盖的是同一条 `Number.isFinite` 判据的另一半：
 * `typeof v === 'number'` 挡不住 `NaN`，`=== 0` 也挡不住 `Infinity`。
 */
test('★ jog 路由：cartesian 的 distance 必须是非零有限数', () => {
  assert.equal(parseJogRequest({ mode: 'cartesian', axis: 'x', distance: 0 }), null);
  assert.equal(parseJogRequest({ mode: 'cartesian', axis: 'x', distance: Infinity }), null);
  assert.equal(parseJogRequest({ mode: 'cartesian', axis: 'x', distance: '0.005' }), null);
});

test('★ jog 路由：rotate 的 deltaRad 必须是非零有限数', () => {
  assert.equal(parseJogRequest({ mode: 'rotate', axis: 'rx', deltaRad: 0 }), null);
  assert.equal(parseJogRequest({ mode: 'rotate', axis: 'rx', deltaRad: -Infinity }), null);
  assert.equal(parseJogRequest({ mode: 'rotate', axis: 'rx', deltaRad: '0.02' }), null);
});

/*
 * 非法数值与顶层形状。
 *
 * `NaN` 能通过 `typeof v === 'number'`，所以数值校验必须是 `Number.isFinite`：
 * 否则 `Math.min(1, Math.max(0.01, NaN))` 仍是 `NaN`，倍率会被原样发给控制器。
 */
test('★ jog 路由：speed 的 fraction 必须是有限数，NaN 不能靠"是 number"混过去', () => {
  assert.equal(parseJogRequest({ mode: 'speed', fraction: NaN }), null);
  assert.equal(parseJogRequest({ mode: 'speed', fraction: Infinity }), null);
});

/*
 * 顶层形状：断言的是 `parseJogRequest` 的**总函数性** —— 请求体被改坏时给 `null`，
 * 绝不抛 `TypeError`（路由那一层只会把它当 400，不该被一个坏 body 打成 500）。
 */
test('★ jog 路由：非对象请求体（[] / 字符串）一律给 null，不抛错', () => {
  assert.equal(parseJogRequest([]), null);
  assert.equal(parseJogRequest('x'), null);
});

/* ── 路由级测试：真实 `apply()` 挂载出来的 POST /twin/jog ────────────────────
 *
 * 为什么必须有这一层：`a621f72` 的核心改动是「把仿真守卫前移到解析之前」，以及
 * 405 / 403 / 400 / 503 / 200 各自的响应契约 —— 这些**只**存在于 `lib/index.js` 的
 * handler 闭包里。`parseJogRequest` 的单测无论怎么写都摸不到它们：把 SIM_ONLY 段挪回
 * 解析之后、删掉 503、或删掉 `message` 透出，纯函数用例一条都不会红。
 *
 * 手法照 `test/sim-persistence.test.mjs` 的 `drive({ mountRoutes:true })`（第 143 行）
 * 与它的假 req/res（第 301–327 行）：桩掉 `UrWorker.prototype.call`（**绝不起 Python
 * 子进程**），用假 `hostCtx.webServer` 收集路由，再用假 req/res 驱动 handler。
 */

/** 让"发起但不等待"的装配跑完（与 sim-persistence 的同名 helper 同义）。 */
const settleMount = () => new Promise((resolve) => setTimeout(resolve, 20));

/** 浏览器同源写请求的默认形状：回环 Host + 同源 Origin + JSON content-type。 */
function trustedHeaders(overrides = {}) {
  return {
    host: '127.0.0.1:12460',
    origin: 'http://127.0.0.1:12460',
    'content-type': 'application/json',
    ...overrides,
  };
}

/**
 * 挂载真实的 `apply()`（只桩 worker 的 `call` / `stats`）。
 *
 * `persistSimState:false`：测试不得把仿真记忆写进开发者本机的 `~/.dsh` —— 这是
 * `test/sim-persistence.test.mjs` 已经踩过的坑（会弄脏真实配置）。
 *
 * `worker()` 返回本次 `apply()` 建出来的 `UrWorker` 实例：实例是**闭包私有**的，这里靠
 * `stats()` 在 `noteSimEnabled()` 里被调用的时机把 `this` 记下来（自愈登记口会调它）。
 */
async function mountTwinRoutes({ replies = {} } = {}) {
  const { UrWorker } = await import('../lib/worker.js');
  const mod = await import('../lib/index.js');
  let instance = null;
  UrWorker.prototype.stats = function stats() {
    instance = this;
    return { respawnCount: 0, running: true, disposed: false, pid: 1234 };
  };
  UrWorker.prototype.call = async function call(op, params) {
    if (typeof replies[op] === 'function') return replies[op](params);
    return { message: `stub:${op}`, data: { op, params } };
  };
  const routes = new Map();
  const registered = new Map();
  const hostCtx = {
    logger: { info() {}, warn() {}, error() {} },
    effect: (fn) => {
      const disposer = fn();
      return typeof disposer === 'function' ? disposer : () => {};
    },
    webServer: {
      register: (route) => {
        routes.set(route.path, route);
        return () => {};
      },
    },
  };
  mod.apply(
    {
      logger: { info() {}, warn() {}, error() {} },
      effect: () => () => {},
      get: () => undefined,
      inject: (_deps, callback) => {
        callback(hostCtx);
        return () => {};
      },
      tools: { register: (tool) => registered.set(tool.name, tool) },
    },
    { persistSimState: false },
  );
  await settleMount();
  return { routes, registered, worker: () => instance };
}

/** 真实 `op_connect` 的响应形状（python 的 connect = 确保仿真在跑 + 返回 sim_status 那一份）。 */
const SIM_CONNECT_REPLY = () => ({
  message: '已连接：离线仿真机器人（UR12E）在保留地址 127.0.0.1。',
  data: {
    simulated: true,
    active: true,
    connected: true,
    ip: '127.0.0.1',
    model: 'UR12E',
    model_id: 'ur12e',
    preset: 'upright',
    speed_scaling: 1,
  },
});

/** 挂载并"连接"仿真：宿主 `simIps` 登记上保留回环地址后，jog 路由才会放行。 */
async function mountTwinRoutesWithSim(options = {}) {
  const mounted = await mountTwinRoutes({
    replies: { connect: SIM_CONNECT_REPLY, ...(options.replies ?? {}) },
  });
  const connectTool = mounted.registered.get('ursim_connect');
  assert.ok(connectTool, 'ursim_connect 必须已注册（用它打开宿主侧的仿真登记）');
  await connectTool.execute({}, { agent: {} });
  return mounted;
}

/** 假响应：收集状态码、响应头与正文（`sendJson` 只会调 writeHead + end）。 */
function makeResponseCapture() {
  const state = { status: null, headers: {}, body: '' };
  return {
    state,
    res: {
      writeHead(code, headers) {
        state.status = code;
        Object.assign(state.headers, headers ?? {});
      },
      setHeader(name, value) { state.headers[name] = value; },
      end(chunk) { state.body = chunk === undefined || chunk === null ? '' : String(chunk); },
    },
  };
}

/**
 * 用浏览器同源写请求的形状驱动 jog 路由。
 *
 * 请求体必须在 handler 挂上 `data` / `end` 监听**之后**再发（`setImmediate`）——
 * `readJsonBody` 是事件驱动的，同步 emit 会丢事件。
 */
async function callJogRoute(route, { method = 'POST', headers = trustedHeaders(), body, rawBody } = {}) {
  const req = new EventEmitter();
  req.method = method;
  req.url = TWIN_JOG_PATH;
  req.headers = headers;
  const { state, res } = makeResponseCapture();
  const done = route.handler(req, res);
  setImmediate(() => {
    if (rawBody !== undefined) req.emit('data', Buffer.from(rawBody, 'utf8'));
    else if (body !== undefined) req.emit('data', Buffer.from(JSON.stringify(body), 'utf8'));
    req.emit('end');
  });
  await done;
  return state;
}

test('★ jog 路由（路由级）：非 POST（GET）→ 405，且 allow 头必须是 POST', async () => {
  const { routes } = await mountTwinRoutes();
  const route = routes.get(TWIN_JOG_PATH);
  assert.ok(route, `POST ${TWIN_JOG_PATH} 必须被挂载`);

  const got = await callJogRoute(route, { method: 'GET' });
  assert.equal(got.status, 405);
  assert.equal(got.headers.allow, 'POST', '405 必须告诉调用方这条路由只收 POST');
});

test('★ jog 路由（路由级）：信任栅栏失败（缺 Origin / 非 JSON）一律 403', async () => {
  const { routes } = await mountTwinRoutesWithSim();
  const route = routes.get(TWIN_JOG_PATH);

  // 没带 Origin：只有非浏览器客户端（或伪造）才会这样，写路由一律拒绝。
  const noOrigin = await callJogRoute(route, {
    headers: trustedHeaders({ origin: '' }),
    body: { mode: 'home' },
  });
  assert.equal(noOrigin.status, 403, '没有 Origin ⇒ 写请求必须被拒');
  assert.equal(noOrigin.body, 'forbidden');

  // content-type 不是 JSON：同样过不了 isTrustedWrite。
  const notJson = await callJogRoute(route, {
    headers: trustedHeaders({ 'content-type': 'text/plain' }),
    body: { mode: 'home' },
  });
  assert.equal(notJson.status, 403, '非 application/json ⇒ 写请求必须被拒');
  assert.equal(notJson.body, 'forbidden');
});

test('★ jog 路由（路由级）：仿真未登记时坏 body 也必须先回 403 SIM_ONLY（守卫顺序）', async () => {
  // 不 connect ⇒ 宿主 simIps 为空（真机模式 / 未开仿真）。
  // body 同时是"坏 JSON"与"结构非法"：只要把仿真守卫挪回解析之后，这里就会先变成 400。
  const { routes } = await mountTwinRoutes();
  const route = routes.get(TWIN_JOG_PATH);

  const badJson = await callJogRoute(route, { rawBody: '{ 这不是 JSON' });
  assert.equal(badJson.status, 403, '★ 未开仿真时不得出现看起来"只差参数"的 400');
  assert.equal(JSON.parse(badJson.body).code, 'SIM_ONLY');

  const badCmd = await callJogRoute(route, { body: { mode: 'nope' } });
  assert.equal(badCmd.status, 403);
  assert.equal(
    JSON.parse(badCmd.body).code,
    'SIM_ONLY',
    '★ 即使 body 结构也非法，也必须先回 SIM_ONLY（安全判定先于任何内容判断）',
  );
});

test('★ jog 路由（路由级）：坏 JSON → 400 + code BAD_JSON', async () => {
  const { routes } = await mountTwinRoutesWithSim();
  const route = routes.get(TWIN_JOG_PATH);

  const got = await callJogRoute(route, { rawBody: '{"mode": "joint", ' });
  assert.equal(got.status, 400);
  const body = JSON.parse(got.body);
  assert.equal(body.code, 'BAD_JSON');
  assert.equal(body.ok, false);
});

test('★ jog 路由（路由级）：结构非法（joint 只有 3 个关节）→ 400 + code BAD_COMMAND', async () => {
  const { routes } = await mountTwinRoutesWithSim();
  const route = routes.get(TWIN_JOG_PATH);

  const got = await callJogRoute(route, { body: { mode: 'joint', q: [0, 0, 0] } });
  assert.equal(got.status, 400);
  const body = JSON.parse(got.body);
  assert.equal(body.code, 'BAD_COMMAND');
  assert.equal(body.ok, false);
});

test('★ jog 路由（路由级）：worker 不可派发 → 503 + code WORKER_UNAVAILABLE', async () => {
  const mounted = await mountTwinRoutesWithSim();
  const route = mounted.routes.get(TWIN_JOG_PATH);
  const worker = mounted.worker();
  assert.ok(worker, 'connect 期间必须能拿到 worker 实例（stats() 会记下它）');

  // 模拟"仿真已登记、但 worker 已经不可派发"（初始化失败 / 已被 dispose 的部署状态）。
  worker.call = null;

  const got = await callJogRoute(route, { body: { mode: 'home' } });
  assert.equal(got.status, 503, '部署状态 → 503，而不是让它抛成未捕获异常变成 500');
  const body = JSON.parse(got.body);
  assert.equal(body.code, 'WORKER_UNAVAILABLE');
  assert.equal(body.ok, false);
});

test('★ jog 路由（路由级）：成功响应透出 worker 的 message，并回显 speed 的 requested', async () => {
  const calls = [];
  const mounted = await mountTwinRoutesWithSim({
    replies: {
      set_speed_scaling: (params) => {
        calls.push(params);
        return { message: '速度倍率已设为 1%', data: { fraction: 0.01 } };
      },
    },
  });
  const route = mounted.routes.get(TWIN_JOG_PATH);

  const got = await callJogRoute(route, { body: { mode: 'speed', fraction: 0.001 } });
  assert.equal(got.status, 200);
  const body = JSON.parse(got.body);
  assert.equal(body.ok, true);
  assert.equal(
    body.message,
    '速度倍率已设为 1%',
    '★ worker 的 message 必须原样回给面板（只回 data 的话面板说不出控制器怎么回应）',
  );
  assert.equal(body.fraction, 0.01, '派发的是钳位后的实际值');
  assert.equal(
    body.requested,
    0.001,
    '★ 客户端原始倍率必须回显：面板要能显示「拖到 0.5%，实际 1%」',
  );
  assert.deepEqual(
    calls,
    [{ ip: '127.0.0.1', fraction: 0.01 }],
    '派发给 worker 的必须是钳位后的值',
  );
});

test('★ jog 路由（路由级）：八种 mode 的 body → worker op 与参数（含 deltaRad 改名、home 常量、速度流）', async () => {
  // 用户 2026-10-20 裁定的回零位形（机座 0°、肩部 −90°、肘部 0°、手腕1 −90°、手腕2 0°、手腕3 0°）；
  // 与型号无关的关节角，真源在 lib/index.js 的 `HOME_JOINTS`。
  const HOME_Q = [0, -Math.PI / 2, 0, -Math.PI / 2, 0, 0];

  /**
   * 这张表把「面板发的 body」到「真正派给 worker 的 op + 参数」的映射钉死。
   *
   * 它防的是**只改了一边**的错误：路由 body 用 `deltaRad`（驼峰），而 worker op 收的是
   * `delta_rad`（下划线）—— 这种改名点没有类型检查保护，只有断言能挡住。同理 `home`
   * 的关节常量若被改错，这里会立刻红。
   *
   * 判定方式：`replies` 只挂**期望的那个 op**，若 dispatch 拼出别的 op 名，桩不会命中，
   * `calls` 保持空 ⇒ 断言失败。
   */
  const rows = [
    {
      name: 'cartesian 默认工具系',
      body: { mode: 'cartesian', axis: 'x', distance: 0.005 },
      op: 'move_tool_x',
      params: { ip: '127.0.0.1', distance: 0.005 },
    },
    {
      name: 'cartesian 基座系负向',
      body: { mode: 'cartesian', axis: 'z', distance: -0.01, frame: 'base' },
      op: 'move_z',
      params: { ip: '127.0.0.1', distance: -0.01 },
    },
    {
      name: 'rotate 工具系（deltaRad → delta_rad）',
      body: { mode: 'rotate', axis: 'rz', deltaRad: 0.02 },
      op: 'jog_rotate',
      params: { ip: '127.0.0.1', axis: 'rz', delta_rad: 0.02, frame: 'tool' },
    },
    {
      name: 'rotate 基座系负向',
      body: { mode: 'rotate', axis: 'rx', deltaRad: -0.035, frame: 'base' },
      op: 'jog_rotate',
      params: { ip: '127.0.0.1', axis: 'rx', delta_rad: -0.035, frame: 'base' },
    },
    {
      name: 'joint',
      body: { mode: 'joint', q: [0, -1.5, 0, -1.5, -1.5, 0] },
      op: 'movej',
      params: { ip: '127.0.0.1', q: [0, -1.5, 0, -1.5, -1.5, 0] },
    },
    {
      name: 'pose',
      body: { mode: 'pose', pose: [0.1, -0.2, 0.3, 0.4, 0.5, 0.6] },
      op: 'movel',
      params: { ip: '127.0.0.1', pose: [0.1, -0.2, 0.3, 0.4, 0.5, 0.6] },
    },
    {
      name: 'home（回零位形）',
      body: { mode: 'home' },
      op: 'movej',
      params: { ip: '127.0.0.1', q: HOME_Q },
    },
    {
      name: 'speed',
      body: { mode: 'speed', fraction: 0.5 },
      op: 'set_speed_scaling',
      params: { ip: '127.0.0.1', fraction: 0.5 },
    },
    {
      // 长按连续点动：twist → 真机 op 的 `xd`；frame / ttl_ms 一并转发（仿真侧用它们
      // 决定坐标系与看门狗，真机侧 op_speedl 忽略这两个键）。
      name: 'velocity（基座系 + 缺省 ttl）',
      body: { mode: 'velocity', twist: [0.05, 0, 0, 0, 0, 0] },
      op: 'speedl',
      params: {
        ip: '127.0.0.1',
        xd: [0.05, 0, 0, 0, 0, 0],
        frame: 'base',
        ttl_ms: 400,
      },
    },
    {
      name: 'velocity（工具系 + 指定 ttl）',
      body: { mode: 'velocity', twist: [0, 0, 0, 0, 0, 0.2], frame: 'tool', ttlMs: 250 },
      op: 'speedl',
      params: {
        ip: '127.0.0.1',
        xd: [0, 0, 0, 0, 0, 0.2],
        frame: 'tool',
        ttl_ms: 250,
      },
    },
    {
      name: 'stop（松手立即停）',
      body: { mode: 'stop' },
      op: 'stopl',
      params: { ip: '127.0.0.1' },
    },
  ];

  for (const row of rows) {
    const calls = [];
    const mounted = await mountTwinRoutesWithSim({
      replies: {
        [row.op]: (params) => {
          calls.push(params);
          return { message: `stub:${row.op}`, data: {} };
        },
      },
    });

    const got = await callJogRoute(mounted.routes.get(TWIN_JOG_PATH), { body: row.body });
    assert.equal(got.status, 200, `${row.name} 应返回 200`);
    assert.equal(JSON.parse(got.body).ok, true, `${row.name} 应成功`);
    assert.deepEqual(calls, [row.params], `★ ${row.name}：派发的 op=${row.op} 与参数必须与表一致`);
  }
});
