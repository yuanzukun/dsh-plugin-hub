#!/usr/bin/env node
/**
 * MCP（Model Context Protocol）server — 让 Claude Code、Codex 等任意 MCP
 * 客户端使用免费的网页搜索（Parallel 默认 / Exa 备用，匿名免 key）。
 *
 * 零依赖：只复用 core.js（fetch + JSON 解析），与 DSH 插件本体完全解耦。
 *
 * ## 双传输
 * - **stdio**（默认）：`node lib/mcp-server.js`
 *   - `claude mcp add dsh-web-search -- node <路径>/lib/mcp-server.js`
 *   - `codex mcp add dsh-web-search -- node <路径>/lib/mcp-server.js`
 * - **HTTP/SSE**（监听端口）：`node lib/mcp-server.js --http --port 3100`
 *   - `claude mcp add --transport http dsh-web-search http://127.0.0.1:3100`
 *   - `codex mcp add --transport http dsh-web-search http://127.0.0.1:3100`
 *   - 兼容 Streamable HTTP（`POST /`）与老式 SSE（`GET /sse` + `POST /messages`）
 *
 * 环境变量：EXA_API_KEY（可选，提升 Exa 匿名限额）。
 *
 * @module @sheep233_/dsh-web-search-free/mcp-server
 */
import { createInterface } from 'node:readline';
import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { parallelSearch, exaSearch } from './core.js';

const SERVER_NAME = 'dsh-web-search-free';
const VERSION = '0.3.0';
const DEFAULT_PROTOCOL = '2025-03-26';

/** 暴露给 MCP 客户端的工具清单。 */
const TOOLS = [
  {
    name: 'web_search',
    description: '免费网页搜索：Parallel（默认，匿名免 key）或 Exa（备用）。返回结构化结果数组（title / url / snippet / publishedAt）。',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: '搜索查询词' },
        provider: { type: 'string', enum: ['parallel', 'exa'], description: '免费后端：parallel（默认）/ exa（备用）' },
        numResults: { type: 'number', description: '返回结果条数上限（默认 8）' },
      },
      required: ['query'],
    },
  },
];

/** 执行一次 tools/call；抛 { code, message } 表示工具级错误。 */
async function callTool(name: string, args: unknown): Promise<{ content: Array<{ type: string; text: string }> }> {
  if (name !== 'web_search') throw { code: -32602, message: `unknown tool: ${name}` };
  const params = (args ?? {}) as { query?: unknown; provider?: unknown; numResults?: unknown };
  const query = typeof params.query === 'string' && params.query.trim().length > 0 ? params.query.trim() : null;
  if (query === null) throw { code: -32602, message: 'query is required' };
  const provider = params.provider === 'exa' ? 'exa' : 'parallel';
  const numResults = typeof params.numResults === 'number' && Number.isFinite(params.numResults)
    ? Math.max(1, Math.floor(params.numResults))
    : 8;
  const sources = provider === 'exa'
    ? await exaSearch(query, numResults, process.env.EXA_API_KEY)
    : await parallelSearch(query, numResults);
  return { content: [{ type: 'text', text: JSON.stringify(sources, null, 2) }] };
}

/** 处理一条 JSON-RPC 消息，返回 { result } 或抛 { code, message }。 */
async function handleRequest(message: { method?: unknown; params?: { protocolVersion?: unknown; name?: unknown; arguments?: unknown } }): Promise<unknown> {
  switch (message.method) {
    case 'initialize':
      return {
        protocolVersion: message.params?.protocolVersion ?? DEFAULT_PROTOCOL,
        capabilities: { tools: {} },
        serverInfo: { name: SERVER_NAME, version: VERSION },
      };
    case 'tools/list':
      return { tools: TOOLS };
    case 'tools/call':
      return callTool(message.params?.name as string, message.params?.arguments);
    case 'ping':
      return {};
    default:
      throw { code: -32601, message: `method not found: ${String(message.method)}` };
  }
}

/** 把一条请求消息解析为 JSON-RPC 信封并执行；notification（无 id）返回 null。 */
async function dispatch(line: string): Promise<unknown> {
  let message: { id?: unknown; method?: unknown; params?: unknown };
  try {
    message = JSON.parse(line) as typeof message;
  } catch {
    return undefined;
  }
  if (message.id === undefined) return null; // 通知不响应
  try {
    return { jsonrpc: '2.0', id: message.id, result: await handleRequest(message as { method: string; params: { protocolVersion?: unknown; name?: unknown; arguments?: unknown } }) };
  } catch (error) {
    const e = error as { code?: number; message?: string };
    return { jsonrpc: '2.0', id: message.id, error: { code: typeof e.code === 'number' ? e.code : -32603, message: String(e.message ?? error) } };
  }
}

// ── stdio 传输（默认）───────────────────────────────────────────────────────
function runStdio(): void {
  const rl = createInterface({ input: process.stdin, crlfDelay: Infinity });
  rl.on('line', (line) => {
    const trimmed = line.trim();
    if (trimmed.length === 0) return;
    void dispatch(trimmed).then((response) => {
      if (response !== null && response !== undefined) {
        process.stdout.write(`${JSON.stringify(response)}\n`);
      }
    });
  });
}

// ── HTTP/SSE 传输（--http [--port <n>] [--host <addr>]）──────────────────────
function runHttp(host: string, port: number): void {
  /** sessionId → 老式 SSE 响应流（GET /sse 建立的连接）。 */
  const sseChannels = new Map<string, import('node:http').ServerResponse>();

  const server = createServer((req, res) => {
    const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);

    // 健康检查 / 服务信息
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/health')) {
      res.writeHead(200, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ name: SERVER_NAME, version: VERSION, transport: 'http/sse', port }));
      return;
    }

    // 老式 SSE 通道：GET /sse（MCP-Session-Id 关联后续 POST /messages）
    if (req.method === 'GET' && url.pathname === '/sse') {
      const sessionId = req.headers['mcp-session-id'] as string | undefined ?? randomUUID();
      res.writeHead(200, {
        'content-type': 'text/event-stream',
        'cache-control': 'no-cache',
        connection: 'keep-alive',
        'mcp-session-id': sessionId,
      });
      res.write(`event: endpoint\ndata: /messages?session_id=${sessionId}\n\n`);
      sseChannels.set(sessionId, res);
      req.on('close', () => { sseChannels.delete(sessionId); });
      return;
    }

    // 消息端点：POST / 与 POST /messages
    if (req.method === 'POST' && (url.pathname === '/' || url.pathname === '/messages')) {
      const sessionId = (req.headers['mcp-session-id'] as string | undefined) ?? url.searchParams.get('session_id') ?? undefined;
      let body = '';
      req.on('data', (chunk: Buffer) => { body += chunk.toString(); });
      req.on('end', () => {
        void dispatch(body).then((response) => {
          if (response === null) { res.writeHead(202).end(); return; } // 通知
          const payload = JSON.stringify(response);
          // 老式 SSE：向通道连接推送；否则走 Streamable HTTP 直接响应（JSON 或 SSE）
          if (url.pathname === '/messages' && sessionId !== undefined && sseChannels.has(sessionId)) {
            const channel = sseChannels.get(sessionId)!;
            channel.write(`data: ${payload}\n\n`);
            res.writeHead(202, { 'mcp-session-id': sessionId }).end();
            return;
          }
          const accept = String(req.headers.accept ?? '');
          if (accept.includes('text/event-stream')) {
            res.writeHead(200, {
              'content-type': 'text/event-stream',
              'cache-control': 'no-cache',
              ...(sessionId !== undefined ? { 'mcp-session-id': sessionId } : {}),
            });
            res.end(`data: ${payload}\n\n`);
            return;
          }
          res.writeHead(200, { 'content-type': 'application/json', ...(sessionId !== undefined ? { 'mcp-session-id': sessionId } : {}) });
          res.end(payload);
        });
      });
      return;
    }

    res.writeHead(404, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ error: 'not found', hint: 'MCP endpoints: POST / (streamable http), GET /sse + POST /messages (legacy sse), GET / (info)' }));
  });

  server.listen(port, host, () => {
    process.stdout.write(`[dsh-web-search-mcp] HTTP/SSE listening on http://${host}:${port} (MCP: POST /, GET /sse + POST /messages)\n`);
  });
}

// ── 入口：参数解析 ──────────────────────────────────────────────────────────
const args = process.argv.slice(2);
const httpMode = args.includes('--http') || args.includes('--transport') && args[args.indexOf('--transport') + 1] === 'http';
const portIndex = args.indexOf('--port');
const port = portIndex >= 0 && args[portIndex + 1] !== undefined ? Number(args[portIndex + 1]) : 3100;
const hostIndex = args.indexOf('--host');
const host = hostIndex >= 0 && args[hostIndex + 1] !== undefined ? args[hostIndex + 1] : '127.0.0.1';

if (httpMode) {
  runHttp(host, Number.isFinite(port) ? port : 3100);
} else {
  runStdio();
}
