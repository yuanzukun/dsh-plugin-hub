/**
 * 零依赖搜索核心：Parallel（默认免费）与 Exa（备用免费）两个后端的统一封装。
 *
 * 本模块**不依赖任何 DSH 包**（只用 fetch + 内置类型），因此既被 DSH 插件
 * host 侧引用，也被独立的 MCP server（Claude Code / Codex 等外部客户端）
 * 直接复用。两个后端都是 OpenCode 内置 websearch 工具的同款免费 MCP 端点，
 * 匿名可用、无需 API key。
 *
 * @module @sheep233_/dsh-web-search-free/core
 */

/** 规范化搜索结果（与 DSH `ctx.web` seam 的 WebSearchSource 结构兼容）。 */
export interface SearchSource {
  readonly url: string;
  readonly title?: string;
  readonly snippet?: string;
  /** Publication/crawl timestamp（ISO-8601 或提供方原样字符串）。 */
  readonly publishedAt?: string;
}

/** Parallel Web Search 免费 MCP 端点（匿名可用，OpenCode 默认后端之一）。 */
export const PARALLEL_MCP_URL = 'https://search.parallel.ai/mcp';

/** Exa 免费 MCP 端点（匿名可用；设 EXA_API_KEY 可提升限额）。 */
export const EXA_MCP_URL = 'https://mcp.exa.ai/mcp';

const USER_AGENT = 'dsh-web-search-free/0.2.0';

/** 从 JSON 或 SSE 响应中提取 MCP `tools/call` 的 result.content[].text。 */
export function extractToolText(body: string): string | undefined {
  const parsePayload = (text: string): string | undefined => {
    try {
      const data = JSON.parse(text) as { result?: { content?: Array<{ type: string; text?: string }> } };
      const item = data.result?.content?.find((c) => c.type === 'text' && typeof c.text === 'string');
      if (item?.text !== undefined && item.text.length > 0) return item.text;
    } catch {
      // 不是 JSON 载荷，交给外层 SSE 解析
    }
    return undefined;
  };
  const trimmed = body.trim();
  const direct = trimmed.length > 0 ? parsePayload(trimmed) : undefined;
  if (direct !== undefined) return direct;
  for (const line of body.split('\n')) {
    if (!line.startsWith('data: ')) continue;
    const data = parsePayload(line.slice(6));
    if (data !== undefined) return data;
  }
  return undefined;
}

/** Parallel 响应解析：result.content[].text 是内嵌 JSON `{ results: [...] }`。 */
export function mapParallelResponse(text: string): SearchSource[] {
  let payload: { results?: Array<{ url: string; title?: string; publish_date?: string; excerpts?: string[] }> };
  try {
    payload = JSON.parse(text) as typeof payload;
  } catch (error) {
    throw new Error(`Parallel search returned an unprocessable payload: ${String(error)}`);
  }
  const sources: SearchSource[] = [];
  for (const item of payload.results ?? []) {
    if (item.url === undefined || item.url.length === 0) continue;
    sources.push({
      url: item.url,
      ...(item.title != null && item.title.length > 0 ? { title: item.title } : {}),
      ...(item.excerpts != null && item.excerpts.length > 0 ? { snippet: item.excerpts.join(' ') } : {}),
      ...(item.publish_date != null && item.publish_date.length > 0 ? { publishedAt: item.publish_date } : {}),
    });
  }
  return sources;
}

/**
 * Exa 响应解析：result.content[].text 是纯文本块，每条结果以 `Title: ` 开头：
 * ```
 * Title: <标题>
 * URL: <链接>
 * Published: <日期 | N/A>
 * Author: <作者 | N/A>
 * Highlights:
 * <正文摘要>
 * ```
 */
export function parseExaText(text: string): SearchSource[] {
  const blocks = text.split(/(?=^Title: )/m).filter((block) => block.trim().length > 0);
  const sources: SearchSource[] = [];
  for (const block of blocks) {
    const url = block.match(/^URL: (\S+)$/m)?.[1];
    if (url === undefined) continue;
    const title = block.match(/^Title: (.+)$/m)?.[1]?.trim();
    const published = block.match(/^Published: (.+)$/m)?.[1]?.trim();
    const highlights = block.split(/^Highlights:\s*$/m)[1]?.trim();
    sources.push({
      url,
      ...(title !== undefined && title.length > 0 ? { title } : {}),
      ...(highlights !== undefined && highlights.length > 0 ? { snippet: highlights.slice(0, 500) } : {}),
      ...(published !== undefined && published.length > 0 && published !== 'N/A' ? { publishedAt: published } : {}),
    });
  }
  return sources;
}

/** Parallel 搜索（默认免费后端）。 */
export async function parallelSearch(
  query: string,
  maxResults?: number,
  signal?: AbortSignal,
): Promise<SearchSource[]> {
  const body = {
    jsonrpc: '2.0',
    id: 1,
    method: 'tools/call',
    params: {
      name: 'web_search',
      arguments: {
        objective: query,
        search_queries: [query],
      },
    },
  };
  const response = await fetch(PARALLEL_MCP_URL, {
    method: 'POST',
    redirect: 'error',
    headers: {
      'content-type': 'application/json',
      'accept': 'application/json, text/event-stream',
      'user-agent': USER_AGENT,
    },
    body: JSON.stringify(body),
    ...(signal !== undefined ? { signal } : {}),
  });
  if (!response.ok) {
    throw new Error(`Parallel search API error (HTTP ${response.status})`);
  }
  const toolText = extractToolText(await response.text());
  if (toolText === undefined) throw new Error('Parallel search returned no tool result');
  const sources = mapParallelResponse(toolText);
  return maxResults !== undefined ? sources.slice(0, maxResults) : sources;
}

/** Exa 搜索（备用免费后端；apiKey 可选，用于提升匿名限额）。 */
export async function exaSearch(
  query: string,
  maxResults?: number,
  apiKey?: string,
  signal?: AbortSignal,
): Promise<SearchSource[]> {
  const endpoint = apiKey !== undefined && apiKey.length > 0
    ? `${EXA_MCP_URL}?exaApiKey=${encodeURIComponent(apiKey)}`
    : EXA_MCP_URL;
  const body = {
    jsonrpc: '2.0',
    id: 1,
    method: 'tools/call',
    params: {
      name: 'web_search_exa',
      arguments: {
        query,
        type: 'auto',
        numResults: maxResults ?? 8,
        livecrawl: 'fallback',
      },
    },
  };
  const response = await fetch(endpoint, {
    method: 'POST',
    redirect: 'error',
    headers: {
      'content-type': 'application/json',
      'accept': 'application/json, text/event-stream',
      'user-agent': USER_AGENT,
    },
    body: JSON.stringify(body),
    ...(signal !== undefined ? { signal } : {}),
  });
  if (!response.ok) {
    throw new Error(`Exa search API error (HTTP ${response.status})`);
  }
  const toolText = extractToolText(await response.text());
  if (toolText === undefined) throw new Error('Exa search returned no tool result');
  const sources = parseExaText(toolText);
  return maxResults !== undefined ? sources.slice(0, maxResults) : sources;
}
