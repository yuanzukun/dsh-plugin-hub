/**
 * @sheep233_/dsh-web-search-free — Client 半（ModuleLoader 最终格式，构建时直接复制为 lib/client.js）。
 *
 * 设置面板「插件设置 → 可配置」里的「免费网页搜索」卡片：
 * 一个开关（enabled），绑定 host 侧 `web-search-free` settings namespace；
 * 开关变更自动写 settings scope（host 侧同步维护 profile 补丁的 web 行
 * searchProvider），重启后生效。
 */
window.__ModuleLoader__.load({
  id: '@sheep233_/dsh-web-search-free',
  factory: (require) => {
    var module = { exports: {} }
    var exports = module.exports
    const React = require('react')

    const NS = 'web-search-free'

    const CSS = [
      '.wfsf-card { border: 1px solid var(--dsw-alias-border-l1); border-radius: 10px; padding: 14px 16px;',
      '  background: var(--dsw-alias-bg-layer-1); display: flex; flex-direction: column; gap: 10px; }',
      '.wfsf-title { margin: 0; font-size: 14px; font-weight: 600; color: var(--dsw-alias-label-primary); }',
      '.wfsf-desc { margin: 0; font-size: 13px; line-height: 1.75; color: var(--dsw-alias-label-secondary); }',
      '.wfsf-row { display: flex; align-items: center; gap: 10px; }',
      '.wfsf-state { font-size: 12px; color: var(--dsw-alias-label-secondary); }',
      '.wfsf-state b { color: var(--dsw-alias-label-primary); font-weight: 600; }',
      '.wfsf-hint { margin: 0; padding: 8px 10px; border-radius: 8px; font-size: 12px; line-height: 1.6;',
      '  color: var(--dsw-alias-label-secondary); background: var(--dsw-alias-bg-layer-2);',
      '  border: 1px solid var(--dsw-alias-border-l1); }',
      '.wfsf-switch { position: relative; width: 38px; height: 22px; flex: none; cursor: pointer; }',
      '.wfsf-switch input { position: absolute; opacity: 0; width: 100%; height: 100%; margin: 0; cursor: pointer; }',
      '.wfsf-track { position: absolute; inset: 0; border-radius: 11px; background: var(--dsw-alias-bg-layer-2);',
      '  border: 1px solid var(--dsw-alias-border-l2); transition: background .15s ease; }',
      '.wfsf-thumb { position: absolute; top: 2px; left: 2px; width: 16px; height: 16px; border-radius: 50%;',
      '  background: var(--dsw-alias-label-secondary); transition: transform .15s ease; }',
      '.wfsf-switch input:checked + .wfsf-track { background: var(--dsw-alias-state-success-primary); border-color: var(--dsw-alias-state-success-primary); }',
      '.wfsf-switch input:checked + .wfsf-track .wfsf-thumb { transform: translateX(16px); background: #fff; }',
      '.wfsf-switch input:disabled + .wfsf-track { opacity: .45; cursor: not-allowed; }',
      '.wfsf-provider-row { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; }',
      '.wfsf-provider-label { font-size: 12px; color: var(--dsw-alias-label-secondary); }',
      '.wfsf-radio { display: flex; align-items: center; gap: 6px; font-size: 13px; cursor: pointer;',
      '  color: var(--dsw-alias-label-primary); }',
      '.wfsf-radio input { margin: 0; cursor: pointer; }',
      '.wfsf-radio-badge { font-size: 11px; padding: 1px 6px; border-radius: 6px;',
      '  border: 1px solid var(--dsw-alias-border-l2); color: var(--dsw-alias-label-secondary); }',
    ].join('\n')

    function insertStyles() {
      const marker = 'data-plugin-css'
      if (document.querySelector('style[' + marker + '="@sheep233_/dsh-web-search-free"]') !== null) {
        return function () {}
      }
      const el = document.createElement('style')
      el.setAttribute('data-plugin', '@sheep233_/dsh-web-search-free')
      el.setAttribute(marker, '@sheep233_/dsh-web-search-free')
      el.textContent = CSS
      document.head.appendChild(el)
      return function () {
        el.remove()
      }
    }

    /**
     * 免费网页搜索卡片：开关 + 免费后端选择（Parallel 默认 / Exa 备用）。
     * props：useWebSearchFree（snapshot hook）、setEnabled、setProvider（写设置）。
     */
    function FreeSearchCard(props) {
      const snapshot = props.useWebSearchFree((s) => s)
      const ready = snapshot.status === 'ready'
      const enabled = ready && snapshot.value != null && snapshot.value.enabled === true
      const provider = ready && snapshot.value != null && snapshot.value.provider != null
        ? snapshot.value.provider
        : 'parallel-free'
      const writable = ready && snapshot.writable
      const [busy, setBusy] = React.useState(false)

      const toggle = async () => {
        if (busy || !writable) return
        setBusy(true)
        try {
          await props.setEnabled(!enabled)
        } catch (e) {
          console.error('[web-search-free] 开关写入失败:', e)
        }
        setBusy(false)
      }

      const chooseProvider = async (value) => {
        if (busy || !writable || value === provider) return
        setBusy(true)
        try {
          await props.setProvider(value)
        } catch (e) {
          console.error('[web-search-free] 后端选择写入失败:', e)
        }
        setBusy(false)
      }

      const providerLabel = provider === 'exa-free' ? '免费搜索（exa-free，备用）' : '免费搜索（parallel-free，默认）'
      const providerName = provider === 'exa-free' ? 'Exa' : 'Parallel'

      return React.createElement(
        'div', { className: 'wfsf-card' },
        React.createElement('p', { className: 'wfsf-title' }, '免费网页搜索'),
        React.createElement(
          'p', { className: 'wfsf-desc' },
          '用 OpenCode 同款免费搜索（Parallel 默认 / Exa 备用，均匿名免 key）替代官方 DeepSeek 计费搜索。'
        ),
        React.createElement(
          'div', { className: 'wfsf-row' },
          React.createElement(
            'label', { className: 'wfsf-switch' },
            React.createElement('input', {
              type: 'checkbox',
              checked: enabled === true,
              disabled: !writable || busy,
              onChange: toggle,
              'aria-label': '启用免费网页搜索',
            }),
            React.createElement(
              'span', { className: 'wfsf-track' },
              React.createElement('span', { className: 'wfsf-thumb' })
            )
          ),
          React.createElement(
            'span', { className: 'wfsf-state' },
            enabled === true
              ? React.createElement(React.Fragment, null, '当前：', React.createElement('b', null, providerLabel))
              : React.createElement(React.Fragment, null, '当前：', React.createElement('b', null, '官方搜索（deepseek-official）'))
          )
        ),
        enabled === true
          ? React.createElement(
              'div', { className: 'wfsf-provider-row' },
              React.createElement('span', { className: 'wfsf-provider-label' }, '免费后端：'),
              React.createElement(
                'label', { className: 'wfsf-radio' },
                React.createElement('input', {
                  type: 'radio',
                  name: 'wfsf-provider',
                  checked: provider === 'parallel-free',
                  disabled: !writable || busy,
                  onChange: () => { chooseProvider('parallel-free') },
                }),
                'Parallel（默认）',
                React.createElement('span', { className: 'wfsf-radio-badge' }, 'search.parallel.ai')
              ),
              React.createElement(
                'label', { className: 'wfsf-radio' },
                React.createElement('input', {
                  type: 'radio',
                  name: 'wfsf-provider',
                  checked: provider === 'exa-free',
                  disabled: !writable || busy,
                  onChange: () => { chooseProvider('exa-free') },
                }),
                'Exa（备用）',
                React.createElement('span', { className: 'wfsf-radio-badge' }, 'mcp.exa.ai')
              )
            )
          : null,
        !ready
          ? React.createElement('p', { className: 'wfsf-hint' }, '设置加载中…')
          : !snapshot.writable
            ? React.createElement('p', { className: 'wfsf-hint' }, '当前连接不可写（内存模式），开关不可用。')
            : React.createElement('p', { className: 'wfsf-hint' }, '开关/后端变更会写入 profile 补丁（web 行 searchProvider=' + provider + '），重启 DSH 后生效。'),
        busy
          ? React.createElement('p', { className: 'wfsf-hint' }, '保存中…')
          : null
      )
    }

    /** Required services (cordis fiber inject)：settingsScope 与 slots 均在 apply 中直接使用。 */
    const inject = [
      'slots',
      'settingsScope'
    ]

    function apply(ctx) {
      const disposeStyles = insertStyles()
      const scope = ctx.settingsScope.bind({ namespace: NS })
      ctx.effect(() => () => {
        disposeStyles()
      }, 'web-search-free: styles')

      ctx.slots.inject('settings.plugin.item', function* () {
        yield ctx.slots.register({
          name: 'settings.plugin.item',
          key: NS,
          inject: () => ({
            hooks: {
              webSearchFree: {
                getSnapshot: () => scope.getSnapshot(),
                subscribe: (listener) => scope.subscribe(listener),
              },
            },
            setEnabled: (value) => scope.set('enabled', value),
            setProvider: (value) => scope.set('provider', value),
          }),
        }, FreeSearchCard)
      })
    }

    exports.apply = apply
    exports.inject = inject
    return module.exports
  },
})
