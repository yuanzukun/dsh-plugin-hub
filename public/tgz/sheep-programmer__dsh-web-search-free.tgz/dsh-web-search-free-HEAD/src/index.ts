/**
 * DSH 免费网页搜索 provider + 设置开关。
 *
 * 背景：DSH 默认的 `web_search` 工具走 `ctx.web` seam，唯一 provider 是
 * `deepseek-official`（@deepseek-ai/dsh-web-search-deepseek），每次搜索调用
 * DeepSeek 官方 Anthropic 兼容 API 的原生 `web_search_20250305`，按 token 计费。
 *
 * 本插件注册两个**完全免费**的搜索 provider（均为 OpenCode 内置 `websearch`
 * 工具同款免费 MCP 端点，匿名可用、无需 API key、不扣任何余额）：
 * - `parallel-free`（**默认**）：Parallel Web Search — https://search.parallel.ai/mcp
 * - `exa-free`（**备用**）：Exa — https://mcp.exa.ai/mcp（可选 `EXA_API_KEY` 提额）
 *
 * ## 设置开关（DSH 设置面板 → 插件设置 → 可配置 → 免费网页搜索）
 * - `enabled`（默认 **false** = 使用官方搜索）：开启后切换为免费搜索。
 * - `provider`（默认 **parallel-free**）：选择免费后端（Parallel 默认 / Exa 备用）。
 * - 开关变更时自动维护 profile 用户层 `cordis.patch.yml` 的 `web` 行
 *   `config.searchProvider`：开 → 写入当前 provider id；关 → 删除覆盖块
 *   （回退官方 `deepseek-official`）。
 * - `WebRuntime` 在进程启动时读取该配置确定 provider 选择，因此**开关变更
 *   需重启 DSH 生效**；未重启前，`available()` 动态反映开关状态，保证
 *   当前进程在"关"时回退官方、不产生歧义。
 * - 注意：**不能**把 `DSH_*` 变量写进 `~/.dsh/.env` — dsh-app-boot 的
 *   bootstrap-only 环境守卫会拒绝任何 `.env` 里的 `DSH_` 前缀变量（启动即
 *   fail-loud），provider 选择只能走 patch 层 config 或启动环境。
 *
 * @module @sheep233_/dsh-web-search-free
 */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { WebError } from '@deepseek-ai/dsh-web';
import type { WebSearchProvider, WebSearchRequest, WebSearchResult } from '@deepseek-ai/dsh-web';
import { settingsNamespace, installSettingsSection } from '@deepseek-ai/dsh-settings';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';
import { parallelSearch, exaSearch } from './core.js';
import type { SearchSource } from './core.js';

/** Cordis 插件名（loader 诊断用）。 */
export const name = 'web-search-free';

/** 依赖的 seam：web 服务必须先于本插件就绪。 */
export const inject = ['web'];

/** 默认免费后端 provider id（Parallel）。 */
export const PARALLEL_PROVIDER_ID = 'parallel-free';

/** 备用免费后端 provider id（Exa）。 */
export const EXA_PROVIDER_ID = 'exa-free';

/** 免费 provider id 集合（设置下拉可选值）。 */
export const FREE_PROVIDER_IDS = [PARALLEL_PROVIDER_ID, EXA_PROVIDER_ID] as const;

/** 每次操作解析的选项（设置可动态变化，操作入口快照一次）。 */
export interface FreeSearchOptions {
  /** 免费搜索开关状态：关闭时 `available()` 为 false（回退官方）。 */
  readonly enabled: boolean;
  /** 执行一次搜索（已绑定后端）。 */
  readonly search: (query: string, signal?: AbortSignal) => Promise<SearchSource[]>;
}

/** 插件配置：无（后端端点固定于 core，无需覆盖）。 */
export const Config = z.object({});

/** 设置段 schema：`enabled` 免费搜索开关 + `provider` 后端选择。 */
export const SettingsSchema = z.object({
  enabled: z.boolean().default(false),
  provider: z.string().default(PARALLEL_PROVIDER_ID),
});

/** 设置面板中展示的段名。 */
export const WEB_SEARCH_FREE_SETTINGS_NAMESPACE = settingsNamespace('web-search-free');

/**
 * Profile 用户层补丁文件（web profile）：开关把 provider 选择写进 `web` 行的
 * `config.searchProvider`（WebRuntime 的配置通道，启动时读取；`.env` 里的
 * `DSH_*` 变量被 dsh-app-boot 守卫拒绝，不能用作持久通道）。
 */
const DEFAULT_PROFILE_PATCH_PATH = () => join(homedir(), '.dsh', 'profiles', 'web', 'cordis.patch.yml');

/** 自动维护块的行标记：`web` 行 searchProvider 覆盖（勿手改）。 */
const OVERRIDE_START = '# >>> web-search-free: 免费搜索 provider 选择（自动维护，勿手改）';
const OVERRIDE_END = '# <<< web-search-free';

/** 生成（或清除）profile 补丁里的 web 行覆盖块。 */
export function syncProviderSearch(enabled: boolean, providerId: string = PARALLEL_PROVIDER_ID, patchPath: string = DEFAULT_PROFILE_PATCH_PATH()): void {
  try {
    const text = existsSync(patchPath) ? readFileSync(patchPath, 'utf8') : '';
    const lines = text.split('\n');
    const kept: string[] = [];
    let skipping = false;
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed === OVERRIDE_START.trim()) { skipping = true; continue; }
      if (skipping && trimmed === OVERRIDE_END.trim()) { skipping = false; continue; }
      if (!skipping) kept.push(line);
    }
    // 除注释与空白外只剩 `[]`/`{}` 视为空列表占位：官方默认 cordis.patch.yml 是
    // 注释头 + `[]`，若把覆盖块直接追加在 `[]` 之后会产生两个 YAML 文档，
    // dsh 启动解析即炸（end of the stream or a document separator is expected）。
    const meaningful = kept.filter((line) => {
      const t = line.trim();
      return t !== '' && !t.startsWith('#');
    });
    const isEmptyList = meaningful.length === 0
      || (meaningful.length === 1 && (meaningful[0] === '[]' || meaningful[0] === '{}'));
    const header = kept
      .filter((line) => line.trim() !== '[]' && line.trim() !== '{}')
      .join('\n')
      .replace(/\n+$/u, '');
    const block = [
      OVERRIDE_START,
      '- id: web',
      '  config:',
      `    searchProvider: ${providerId}`,
      OVERRIDE_END,
    ].join('\n');
    if (!enabled) {
      writeFileSync(patchPath, isEmptyList || header.length === 0 ? '[]\n' : `${header}\n`);
      return;
    }
    if (isEmptyList) {
      writeFileSync(patchPath, header.length > 0 ? `${header}\n${block}\n` : `${block}\n`);
      return;
    }
    writeFileSync(patchPath, `${header}\n${block}\n`);
  } catch (error) {
    console.warn(`[web-search-free] 更新 ${patchPath} 失败：${String(error)}`);
  }
}

/** 函数封装以绕过 TS 对 const 参数属性的控制流收窄；类型守卫让调用后 signal 收窄为已存在。 */
function isAborted(signal: AbortSignal | undefined): signal is AbortSignal {
  return signal?.aborted === true;
}

/** 判断 fetch 的 AbortError（TS DOM 类型缺失时按名称兜底）。 */
function isAbortError(error: unknown): boolean {
  return error instanceof DOMException && error.name === 'AbortError';
}

/** 把 core 抛出的普通错误包装为 seam 规范的 WebError。 */
function asWebError(error: unknown, action: string): WebError {
  if (error instanceof WebError) return error;
  return new WebError(`${action} failed: ${String(error)}`, 'WEB_PROVIDER_ERROR', { cause: error });
}

/** 免费搜索 provider：注册进 `ctx.web`，开关开启时才可用。 */
export class FreeSearchProvider implements WebSearchProvider {
  constructor(
    readonly id: string,
    private readonly resolveOptions: () => FreeSearchOptions,
  ) {}

  /** 廉价本地可用性检查：仅取决于开关；不发网络请求。 */
  available(): boolean {
    try {
      return this.resolveOptions().enabled === true;
    } catch {
      return false;
    }
  }

  /** 执行一次搜索；honor 调用方取消信号。 */
  async search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult> {
    if (isAborted(signal)) throw new WebError(`${this.id} search aborted`, 'WEB_ABORTED', { cause: signal.reason });
    let sources: SearchSource[];
    try {
      sources = await this.resolveOptions().search(request.query, signal);
    } catch (error) {
      if (isAbortError(error)) throw new WebError(`${this.id} search aborted`, 'WEB_ABORTED', { cause: error });
      throw asWebError(error, `${this.id} search`);
    }
    return { sources, truncated: false };
  }
}

/** 注册免费搜索 provider 到 `ctx.web`，并挂载设置开关（联动 profile 补丁的 web 行覆盖）。 */
export function apply(ctx: Context, config: { endpoint?: string }): void {
  let current = (): { enabled: boolean; provider: string } => ({ enabled: false, provider: PARALLEL_PROVIDER_ID });
  installSettingsSection(ctx, WEB_SEARCH_FREE_SETTINGS_NAMESPACE, SettingsSchema, {}, {
    setSource: (source) => {
      current = () => {
        const section = source();
        const provider = (FREE_PROVIDER_IDS as readonly string[]).includes(section.provider ?? '')
          ? section.provider as string
          : PARALLEL_PROVIDER_ID;
        return {
          enabled: section.enabled === true,
          provider,
        };
      };
    },
    onChange: () => {
      const { enabled, provider } = current();
      syncProviderSearch(enabled, provider);
    },
  });
  const run = (query: string, signal?: AbortSignal): Promise<SearchSource[]> => {
    const { provider } = current();
    return provider === EXA_PROVIDER_ID ? exaSearch(query, undefined, undefined, signal) : parallelSearch(query, undefined, signal);
  };
  // 两个 provider 都注册；开关开启时均可用，实际选择由 web 行的 searchProvider 决定。
  ctx.web.registerSearchProvider(new FreeSearchProvider(PARALLEL_PROVIDER_ID, () => ({ enabled: current().enabled, search: run })));
  ctx.web.registerSearchProvider(new FreeSearchProvider(EXA_PROVIDER_ID, () => ({ enabled: current().enabled, search: run })));
}
