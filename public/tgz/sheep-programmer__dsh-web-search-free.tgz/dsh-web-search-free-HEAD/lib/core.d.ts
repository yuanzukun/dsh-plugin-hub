/**
 * 零依赖搜索核心：Parallel（默认免费）与 Exa（备用免费）两个后端的统一封装。
 *
 * 本模块**不依赖任何 DSH 包**（只用 fetch + 内置类型），因此既被 DSH 插件
 * host 侧引用，也被独立的 MCP server（Claude Code / Codex 等外部客户端）
 * 直接复用。两个后端都是 OpenCode 内置 websearch 工具的同款免费 MCP 端点，
 * 匿名可用、无需 API key。
 *
 * @module @sheep233_/dsh-web-search-free/core
 */
/** 规范化搜索结果（与 DSH `ctx.web` seam 的 WebSearchSource 结构兼容）。 */
export interface SearchSource {
    readonly url: string;
    readonly title?: string;
    readonly snippet?: string;
    /** Publication/crawl timestamp（ISO-8601 或提供方原样字符串）。 */
    readonly publishedAt?: string;
}
/** Parallel Web Search 免费 MCP 端点（匿名可用，OpenCode 默认后端之一）。 */
export declare const PARALLEL_MCP_URL = "https://search.parallel.ai/mcp";
/** Exa 免费 MCP 端点（匿名可用；设 EXA_API_KEY 可提升限额）。 */
export declare const EXA_MCP_URL = "https://mcp.exa.ai/mcp";
/** 从 JSON 或 SSE 响应中提取 MCP `tools/call` 的 result.content[].text。 */
export declare function extractToolText(body: string): string | undefined;
/** Parallel 响应解析：result.content[].text 是内嵌 JSON `{ results: [...] }`。 */
export declare function mapParallelResponse(text: string): SearchSource[];
/**
 * Exa 响应解析：result.content[].text 是纯文本块，每条结果以 `Title: ` 开头：
 * ```
 * Title: <标题>
 * URL: <链接>
 * Published: <日期 | N/A>
 * Author: <作者 | N/A>
 * Highlights:
 * <正文摘要>
 * ```
 */
export declare function parseExaText(text: string): SearchSource[];
/** Parallel 搜索（默认免费后端）。 */
export declare function parallelSearch(query: string, maxResults?: number, signal?: AbortSignal): Promise<SearchSource[]>;
/** Exa 搜索（备用免费后端；apiKey 可选，用于提升匿名限额）。 */
export declare function exaSearch(query: string, maxResults?: number, apiKey?: string, signal?: AbortSignal): Promise<SearchSource[]>;
