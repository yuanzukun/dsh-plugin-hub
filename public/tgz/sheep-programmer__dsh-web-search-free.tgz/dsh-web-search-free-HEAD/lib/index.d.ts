/**
 * DSH 免费网页搜索 provider + 设置开关。
 *
 * 背景：DSH 默认的 `web_search` 工具走 `ctx.web` seam，唯一 provider 是
 * `deepseek-official`（@deepseek-ai/dsh-web-search-deepseek），每次搜索调用
 * DeepSeek 官方 Anthropic 兼容 API 的原生 `web_search_20250305`，按 token 计费。
 *
 * 本插件注册两个**完全免费**的搜索 provider（均为 OpenCode 内置 `websearch`
 * 工具同款免费 MCP 端点，匿名可用、无需 API key、不扣任何余额）：
 * - `parallel-free`（**默认**）：Parallel Web Search — https://search.parallel.ai/mcp
 * - `exa-free`（**备用**）：Exa — https://mcp.exa.ai/mcp（可选 `EXA_API_KEY` 提额）
 *
 * ## 设置开关（DSH 设置面板 → 插件设置 → 可配置 → 免费网页搜索）
 * - `enabled`（默认 **false** = 使用官方搜索）：开启后切换为免费搜索。
 * - `provider`（默认 **parallel-free**）：选择免费后端（Parallel 默认 / Exa 备用）。
 * - 开关变更时自动维护 profile 用户层 `cordis.patch.yml` 的 `web` 行
 *   `config.searchProvider`：开 → 写入当前 provider id；关 → 删除覆盖块
 *   （回退官方 `deepseek-official`）。
 * - `WebRuntime` 在进程启动时读取该配置确定 provider 选择，因此**开关变更
 *   需重启 DSH 生效**；未重启前，`available()` 动态反映开关状态，保证
 *   当前进程在"关"时回退官方、不产生歧义。
 * - 注意：**不能**把 `DSH_*` 变量写进 `~/.dsh/.env` — dsh-app-boot 的
 *   bootstrap-only 环境守卫会拒绝任何 `.env` 里的 `DSH_` 前缀变量（启动即
 *   fail-loud），provider 选择只能走 patch 层 config 或启动环境。
 *
 * @module @sheep233_/dsh-web-search-free
 */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { WebSearchProvider, WebSearchRequest, WebSearchResult } from '@deepseek-ai/dsh-web';
import type { SearchSource } from './core.js';
/** Cordis 插件名（loader 诊断用）。 */
export declare const name = "web-search-free";
/** 依赖的 seam：web 服务必须先于本插件就绪。 */
export declare const inject: string[];
/** 默认免费后端 provider id（Parallel）。 */
export declare const PARALLEL_PROVIDER_ID = "parallel-free";
/** 备用免费后端 provider id（Exa）。 */
export declare const EXA_PROVIDER_ID = "exa-free";
/** 免费 provider id 集合（设置下拉可选值）。 */
export declare const FREE_PROVIDER_IDS: readonly ["parallel-free", "exa-free"];
/** 每次操作解析的选项（设置可动态变化，操作入口快照一次）。 */
export interface FreeSearchOptions {
    /** 免费搜索开关状态：关闭时 `available()` 为 false（回退官方）。 */
    readonly enabled: boolean;
    /** 执行一次搜索（已绑定后端）。 */
    readonly search: (query: string, signal?: AbortSignal) => Promise<SearchSource[]>;
}
/** 插件配置：无（后端端点固定于 core，无需覆盖）。 */
export declare const Config: z<Schemastery.ObjectS<{}>, Schemastery.ObjectT<{}>>;
/** 设置段 schema：`enabled` 免费搜索开关 + `provider` 后端选择。 */
export declare const SettingsSchema: z<Schemastery.ObjectS<{
    enabled: z<boolean, boolean>;
    provider: z<string, string>;
}>, Schemastery.ObjectT<{
    enabled: z<boolean, boolean>;
    provider: z<string, string>;
}>>;
/** 设置面板中展示的段名。 */
export declare const WEB_SEARCH_FREE_SETTINGS_NAMESPACE: import("@deepseek-ai/dsh-settings").SettingsNamespace;
/** 生成（或清除）profile 补丁里的 web 行覆盖块。 */
export declare function syncProviderSearch(enabled: boolean, providerId?: string, patchPath?: string): void;
/** 免费搜索 provider：注册进 `ctx.web`，开关开启时才可用。 */
export declare class FreeSearchProvider implements WebSearchProvider {
    readonly id: string;
    private readonly resolveOptions;
    constructor(id: string, resolveOptions: () => FreeSearchOptions);
    /** 廉价本地可用性检查：仅取决于开关；不发网络请求。 */
    available(): boolean;
    /** 执行一次搜索；honor 调用方取消信号。 */
    search(request: WebSearchRequest, signal?: AbortSignal): Promise<WebSearchResult>;
}
/** 注册免费搜索 provider 到 `ctx.web`，并挂载设置开关（联动 profile 补丁的 web 行覆盖）。 */
export declare function apply(ctx: Context, config: {
    endpoint?: string;
}): void;
