// 端到端验证 v0.2.0：
//   1. profile 补丁联动（开关 + provider 选择）
//   2. core 搜索核心真实调用（Parallel 默认 / Exa 备用）
//   3. provider 选择矩阵（双 provider + WebRuntime seam）
//   4. MCP stdio server 冒烟（initialize / tools/list / tools/call）
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawn } from 'node:child_process';
import { Context } from '@deepseek-ai/cordis';
import { WebRuntime } from '@deepseek-ai/dsh-web';
import { DeepSeekSearchProvider, DEEPSEEK_DEFAULT_BASE_URL } from 'file:///opt/homebrew/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-web-search-deepseek/lib/index.js';
import {
  FreeSearchProvider,
  PARALLEL_PROVIDER_ID,
  EXA_PROVIDER_ID,
  syncProviderSearch,
} from '../lib/index.js';
import { parallelSearch, exaSearch, parseExaText } from '../lib/core.js';

const TIMEOUT = 30000;

const fakeDeepseek = () => new DeepSeekSearchProvider(() => ({
  apiKey: 'sk-fake-key-for-availability-check',
  baseURL: DEEPSEEK_DEFAULT_BASE_URL,
  model: 'deepseek-v4-flash',
  apiVersion: '2023-06-01',
  maxTokens: 4096,
  maxUses: 5,
}));

// —— 1. syncProviderSearch 写/删行为（临时文件，不碰真实 profile patch；含 provider 参数）
{
  const dir = mkdtempSync(join(tmpdir(), 'wfs-'));
  const patch = join(dir, 'cordis.patch.yml');
  writeFileSync(patch, '- id: rea\n  name: "keep-me"\n');
  syncProviderSearch(false, PARALLEL_PROVIDER_ID, patch);
  const off = readFileSync(patch, 'utf8');
  syncProviderSearch(true, PARALLEL_PROVIDER_ID, patch);
  const onParallel = readFileSync(patch, 'utf8');
  syncProviderSearch(true, EXA_PROVIDER_ID, patch);
  const onExa = readFileSync(patch, 'utf8');
  syncProviderSearch(false, PARALLEL_PROVIDER_ID, patch);
  const off2 = readFileSync(patch, 'utf8');
  console.log(`[1] 关→无覆盖块: ${!off.includes('searchProvider')}`);
  console.log(`[1] 开(默认)→web 行 searchProvider=parallel-free: ${onParallel.includes('searchProvider: parallel-free')}`);
  console.log(`[1] 开(备用)→web 行 searchProvider=exa-free: ${onExa.includes('searchProvider: exa-free')}`);
  console.log(`[1] 开→保留其他行: ${onParallel.includes('keep-me')}`);
  console.log(`[1] 再关→删块: ${!off2.includes('searchProvider')}`);
  rmSync(dir, { recursive: true, force: true });
}

// —— 2. core 真实调用：Parallel（默认后端）
{
  const sources = await parallelSearch('DeepSeek Harness', 3, AbortSignal.timeout(TIMEOUT));
  console.log(`[2] Parallel 真实搜索成功: ${sources.length} 条，首条=${sources[0]?.url?.slice(0, 60)}`);
}

// —— 3. core 真实调用：Exa（备用后端，匿名）
{
  const sources = await exaSearch('DeepSeek Harness', 3, undefined, AbortSignal.timeout(TIMEOUT));
  console.log(`[3] Exa 真实搜索成功: ${sources.length} 条，首条=${sources[0]?.url?.slice(0, 60)}`);
}

// —— 4. provider 选择矩阵（WebRuntime seam）
{
  // 4a. 开关默认关 + 未配置 id → 选中官方（假 key 触发官方 401）
  delete process.env.DSH_WEB_SEARCH_PROVIDER;
  const ctx = new Context();
  await ctx.plugin(WebRuntime);
  ctx.web.registerSearchProvider(fakeDeepseek());
  ctx.web.registerSearchProvider(new FreeSearchProvider(PARALLEL_PROVIDER_ID, () => ({ enabled: false, search: (q, s) => parallelSearch(q, 3, s) })));
  ctx.web.registerSearchProvider(new FreeSearchProvider(EXA_PROVIDER_ID, () => ({ enabled: false, search: (q, s) => exaSearch(q, 3, undefined, s) })));
  try {
    await ctx.web.search({ query: 'DeepSeek Harness', maxResults: 2 });
    console.log('[4a] 意外成功');
  } catch (e) {
    const isDeepseekPicked = e.code === 'WEB_PROVIDER_ERROR' && /Authentication|api key/i.test(String(e.message));
    console.log(`[4a] 默认关 → 选中官方 provider（=${isDeepseekPicked}）`);
  }

  // 4b. 开关开 + 配置 id=parallel-free → Parallel 免费搜索成功
  process.env.DSH_WEB_SEARCH_PROVIDER = PARALLEL_PROVIDER_ID;
  const ctxB = new Context();
  await ctxB.plugin(WebRuntime);
  ctxB.web.registerSearchProvider(fakeDeepseek());
  ctxB.web.registerSearchProvider(new FreeSearchProvider(PARALLEL_PROVIDER_ID, () => ({ enabled: true, search: (q, s) => parallelSearch(q, 3, s) })));
  ctxB.web.registerSearchProvider(new FreeSearchProvider(EXA_PROVIDER_ID, () => ({ enabled: true, search: (q, s) => exaSearch(q, 3, undefined, s) })));
  const rB = await ctxB.web.search({ query: 'DeepSeek Harness', maxResults: 3 });
  console.log(`[4b] 开+parallel-free → 免费搜索成功 ${rB.sources.length} 条`);

  // 4c. 开关开 + 配置 id=exa-free → Exa 免费搜索成功（备用后端被选中）
  process.env.DSH_WEB_SEARCH_PROVIDER = EXA_PROVIDER_ID;
  const ctxC = new Context();
  await ctxC.plugin(WebRuntime);
  ctxC.web.registerSearchProvider(fakeDeepseek());
  ctxC.web.registerSearchProvider(new FreeSearchProvider(PARALLEL_PROVIDER_ID, () => ({ enabled: true, search: (q, s) => parallelSearch(q, 3, s) })));
  ctxC.web.registerSearchProvider(new FreeSearchProvider(EXA_PROVIDER_ID, () => ({ enabled: true, search: (q, s) => exaSearch(q, 3, undefined, s) })));
  const rC = await ctxC.web.search({ query: 'DeepSeek Harness', maxResults: 3 });
  console.log(`[4c] 开+exa-free → Exa 备用后端搜索成功 ${rC.sources.length} 条`);
}

// —— 5. MCP stdio server 冒烟测试（initialize → tools/list → tools/call）
{
  const root = join(new URL('..', import.meta.url).pathname); // scripts/ 的上级
  const child = spawn(process.execPath, [join(root, 'lib/mcp-server.js')], { stdio: ['pipe', 'pipe', 'inherit'] });
  const pending = new Map();
  const stdout = [];
  child.stdout.on('data', (chunk) => { stdout.push(chunk.toString()); });
  let buffer = '';
  const responses = [];
  const nextResponse = () => new Promise((resolve) => {
    const timer = setInterval(() => {
      const idx = buffer.indexOf('\n');
      if (idx === -1) return;
      const line = buffer.slice(0, idx);
      buffer = buffer.slice(idx + 1);
      clearInterval(timer);
      resolve(JSON.parse(line));
    }, 10);
    setTimeout(() => { clearInterval(timer); resolve(null); }, 15000);
  });
  child.stdout.on('data', (chunk) => { buffer += chunk.toString(); });

  const send = (msg) => { child.stdin.write(JSON.stringify(msg) + '\n'); };

  send({ jsonrpc: '2.0', id: 1, method: 'initialize', params: { protocolVersion: '2025-03-26', capabilities: {}, clientInfo: { name: 'verify', version: '0' } } });
  const init = await nextResponse();
  send({ jsonrpc: '2.0', id: 2, method: 'tools/list' });
  const list = await nextResponse();
  send({ jsonrpc: '2.0', id: 3, method: 'tools/call', params: { name: 'web_search', arguments: { query: 'DeepSeek Harness', numResults: 2, provider: 'parallel' } } });
  const call = await nextResponse();
  child.kill();

  const initOk = init && init.result && init.result.serverInfo && init.result.serverInfo.name === 'dsh-web-search-free';
  const listOk = list && list.result && Array.isArray(list.result.tools) && list.result.tools.some((t) => t.name === 'web_search');
  let callOk = false;
  if (call && call.result && Array.isArray(call.result.content)) {
    const text = call.result.content.find((c) => c.type === 'text')?.text ?? '[]';
    try { callOk = Array.isArray(JSON.parse(text)) && JSON.parse(text).length > 0; } catch { callOk = false; }
  }
  console.log(`[5] MCP stdio initialize: ${initOk}`);
  console.log(`[5] MCP stdio tools/list 含 web_search: ${listOk}`);
  console.log(`[5] MCP stdio tools/call 真实搜索: ${callOk}`);
}

// —— 6. MCP HTTP/SSE 双端口冒烟测试（POST / initialize → tools/list → tools/call + GET /sse）
{
  const root = join(new URL('..', import.meta.url).pathname);
  const port = 34123;
  const child = spawn(process.execPath, [join(root, 'lib/mcp-server.js'), '--http', '--port', String(port)], { stdio: ['ignore', 'pipe', 'inherit'] });
  await new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('HTTP server 未就绪')), 10000);
    child.stdout.on('data', (chunk) => {
      if (String(chunk).includes('listening')) { clearTimeout(timer); resolve(); }
    });
  });
  const base = `http://127.0.0.1:${port}`;
  const post = async (id, method, params, accept = 'application/json') => {
    const res = await fetch(`${base}/`, {
      method: 'POST',
      headers: { 'content-type': 'application/json', accept },
      body: JSON.stringify({ jsonrpc: '2.0', id, method, params }),
    });
    const raw = await res.text();
    // SSE 响应剥掉 data: 前缀再解析
    const line = raw.split('\n').find((l) => l.startsWith('data: '));
    return JSON.parse(line ? line.slice(6) : raw);
  };
  const initR = await post(1, 'initialize', { protocolVersion: '2025-03-26', capabilities: {}, clientInfo: { name: 'verify-http', version: '0' } });
  const listR = await post(2, 'tools/list', {});
  const callR = await post(3, 'tools/call', { name: 'web_search', arguments: { query: 'DeepSeek Harness', numResults: 2, provider: 'parallel' } }, 'application/json, text/event-stream');
  const infoRes = await fetch(`${base}/`);
  const info = await infoRes.json();
  // 老式 SSE 通道存在性
  const sseRes = await fetch(`${base}/sse`);
  const sseOk = sseRes.status === 200 && String(sseRes.headers.get('content-type')).includes('text/event-stream');
  await sseRes.body?.cancel();
  child.kill();

  const initOk = initR.result?.serverInfo?.name === 'dsh-web-search-free';
  const listOk = Array.isArray(listR.result?.tools) && listR.result.tools.some((t) => t.name === 'web_search');
  let callOk = false;
  const text = callR.result?.content?.find((c) => c.type === 'text')?.text ?? '[]';
  try { callOk = Array.isArray(JSON.parse(text)) && JSON.parse(text).length > 0; } catch { callOk = false; }
  const infoOk = info.name === 'dsh-web-search-free' && info.transport === 'http/sse';
  console.log(`[6] MCP HTTP POST / initialize: ${initOk}`);
  console.log(`[6] MCP HTTP tools/list 含 web_search: ${listOk}`);
  console.log(`[6] MCP HTTP tools/call 真实搜索: ${callOk}`);
  console.log(`[6] MCP GET / 服务信息: ${infoOk}`);
  console.log(`[6] MCP GET /sse 老式 SSE 通道: ${sseOk}`);
}
