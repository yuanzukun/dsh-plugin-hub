#!/usr/bin/env bash
# dsh-web-search-free 构建脚本：探测 DSH_CHECKOUT → 软链 peer 类型 → tsc 编译
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ -z "${DSH_CHECKOUT:-}" ]]; then
  if [[ -d /opt/homebrew/lib/node_modules/@deepseek-ai/dsh ]]; then
    DSH_CHECKOUT=/opt/homebrew/lib/node_modules/@deepseek-ai/dsh
  else
    DSH_CHECKOUT="$(node -e "try{console.log(require.resolve('@deepseek-ai/dsh/package.json').replace(/\/package\.json$/,''))}catch(e){process.exit(1)}" 2>/dev/null || true)"
  fi
fi
if [[ -z "${DSH_CHECKOUT:-}" || ! -d "$DSH_CHECKOUT/node_modules/@deepseek-ai" ]]; then
  echo "error: DSH_CHECKOUT not found" >&2
  exit 1
fi
echo "DSH_CHECKOUT=$DSH_CHECKOUT"

mkdir -p node_modules/@deepseek-ai node_modules/@types
for pkg in @deepseek-ai/cordis @deepseek-ai/dsh-web @deepseek-ai/schemastery @deepseek-ai/dsh-settings @types/node typescript; do
  if [[ -e "$DSH_CHECKOUT/node_modules/$pkg" && ! -e "node_modules/$pkg" ]]; then
    ln -s "$DSH_CHECKOUT/node_modules/$pkg" "node_modules/$pkg"
    echo "linked $pkg"
  fi
done

rm -rf lib
TSC_BIN=""
if [[ -x node_modules/.bin/tsc ]]; then TSC_BIN="node_modules/.bin/tsc"; fi
if [[ -z "$TSC_BIN" && -x "$DSH_CHECKOUT/node_modules/.bin/tsc" ]]; then TSC_BIN="$DSH_CHECKOUT/node_modules/.bin/tsc"; fi
if [[ -z "$TSC_BIN" ]]; then
  export npm_config_cache="${npm_config_cache:-$(pwd)/.npm-cache}"
  mkdir -p "$npm_config_cache"
  TSC_BIN="npx -y -p typescript tsc"
fi
$TSC_BIN -p tsconfig.json

# Client 半：ModuleLoader 最终格式，直接复制（零转换）。
mkdir -p lib
cp src/client/client.js lib/client.js

# MCP server 需要可执行权限（bin 入口；tsc 保留 shebang）。
chmod +x lib/mcp-server.js
echo "build ok (host + client + mcp-server)"
