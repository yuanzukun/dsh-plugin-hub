# DSH Hacker Terminal Theme

A standalone hacker-terminal theme plugin for the DeepSeek Harness Web UI.

It turns DSH into a green-on-black secure terminal with a Latin letter and number matrix rain, glass composer, HUD bars, scan effects, local monospace fonts, and fully reversible cleanup.

![DSH Hacker Terminal Theme preview](preview.png)

## Highlights

- Installs as a normal DSH bundle and activates automatically.
- Uses only `A-Z`, `0-9`, and terminal symbols in the matrix rain.
- Embeds Share Tech Mono for HUD labels and JetBrains Mono for content.
- Falls back to PingFang SC for Chinese text.
- Supports `prefers-reduced-motion`.
- Removes every injected style, element, listener, observer, and timer when unloaded.
- Does not send analytics or make network requests.

## Install from GitHub

```bash
dsh plugin --profile web add github:chengwill45-bot/dsh-hacker-terminal-theme
```

Restart the current `dsh web` process and refresh the page.

Because the compiled `lib/` files are committed, installation from GitHub does not need a `prepare` script or pnpm build authorization.

## Install from a local checkout

```bash
git clone https://github.com/chengwill45-bot/dsh-hacker-terminal-theme.git
cd dsh-hacker-terminal-theme
npm test
dsh plugin --profile web add "link:$PWD"
```

Restart DSH and refresh the Web UI.

## Remove

```bash
dsh plugin --profile web remove dsh-client-ui-skin-hacker-terminal
```

Restart DSH and refresh the page. The plugin cleanup is reversible and does not modify conversation data or DSH configuration outside the profile dependency entry.

## Development

```bash
npm run build
npm test
npm run check
```

The project intentionally has no runtime npm dependencies.

## Compatibility

DeepSeek Harness is currently a developer preview and may introduce breaking UI changes. This plugin targets the current DSH Web UI composer and layout structure.

## License

Plugin code is released under the MIT License. Bundled Share Tech Mono and JetBrains Mono font files are distributed under the SIL Open Font License 1.1. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) and the license files under [`fonts/`](fonts/).
