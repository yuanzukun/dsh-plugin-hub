import assert from 'node:assert/strict'
import { readFile } from 'node:fs/promises'
import test from 'node:test'

const root = new URL('../', import.meta.url)

test('package exposes a standalone DSH web bundle', async () => {
  const pkg = JSON.parse(await readFile(new URL('./package.json', root), 'utf8'))
  assert.equal(pkg.name, 'dsh-client-ui-skin-hacker-terminal')
  assert.equal(pkg.dsh.bundle.patch, './cordis.patch.yml')
  assert.equal(pkg.dsh.client.platform, 'web')
  assert.equal(pkg.dsh.client.immediately, true)
})

test('built client is self-contained and reversible', async () => {
  const client = await readFile(new URL('./lib/client.js', root), 'utf8')
  assert.match(client, /id: "dsh-client-ui-skin-hacker-terminal"/)
  assert.match(client, /ctx\.effect\(/)
  assert.match(client, /body\.removeAttribute\("data-dsh-hacker-terminal"\)/)
  assert.doesNotMatch(client, /__DSH_(?:SHARE_TECH|JETBRAINS)_MONO__/)
})

test('matrix uses Latin glyphs and the input echo fix is included', async () => {
  const client = await readFile(new URL('./lib/client.js', root), 'utf8')
  assert.match(client, /ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789/)
  assert.doesNotMatch(client, /[\u3040-\u30ff]/u)
  assert.match(client, /data-input-backdrop=true/)
})

test('system appearance changes can suspend and restore the full skin', async () => {
  const client = await readFile(new URL('./lib/client.js', root), 'utf8')
  assert.match(client, /data-ds-theme/)
  assert.match(client, /hasExternalHackerAppearance/)
  assert.match(client, /setEnabled\(body\.getAttribute\("data-ds-theme"\) === "hacker"\)/)
  assert.match(client, /body\.toggleAttribute\("data-dsh-hacker-terminal", next\)/)
})

test('composer glass uses green highlights without visible cyan accents', async () => {
  const client = await readFile(new URL('./lib/client.js', root), 'utf8')
  assert.match(client, /greenGlassCss/)
  assert.match(client, /inset 0 -1px 0 #39ff881a/)
  assert.match(client, /dsh-hacker-input-prompt::before\{color:#72ffaa!important\}/)
})
