export const name = 'dsh-client-ui-skin-hacker-terminal'

export function apply() {}
