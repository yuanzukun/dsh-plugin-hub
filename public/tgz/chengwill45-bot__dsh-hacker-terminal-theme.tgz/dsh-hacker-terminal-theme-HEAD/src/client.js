window.__ModuleLoader__.load({
  id: "dsh-client-ui-skin-hacker-terminal",
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    const css = "body[data-dsh-hacker-terminal]{--dsw-font-family:\"JetBrains Mono\",\"SFMono-Regular\",Menlo,Monaco,Consolas,monospace;--ds-font-family-code:\"JetBrains Mono\",\"SFMono-Regular\",Menlo,Monaco,Consolas,monospace;--dsw-alias-bg-base:#030806;--dsw-alias-bg-layer-1:#07120d;--dsw-alias-bg-layer-2:#0b1a12;--dsw-alias-bg-layer-3:#10261a;--dsw-alias-bg-overlay:#07120d;--dsw-alias-bg-module-platform:#030806;--dsw-alias-bg-multi-select:#10261a;--dsw-alias-bg-mask-1:#001208cc;--dsw-alias-bg-mask-2:#00120899;--dsw-alias-bg-mask-3:#000000e6;--dsw-alias-bg-skeleton:#39ff8814;--dsw-alias-border-l1:#39ff881f;--dsw-alias-border-l2:#39ff8838;--dsw-alias-border-l2-darkmode-thin:#39ff8838;--dsw-alias-border-l3:#39ff8866;--dsw-alias-border-l4:#39ff88a6;--dsw-alias-border-inverted:#d7ffe566;--dsw-alias-border-inverted2:#d7ffe599;--dsw-alias-brand-primary:#39ff88;--dsw-alias-brand-primary-invert:#001b0b;--dsw-alias-brand-text:#72ffaa;--dsw-alias-button-primary-fill:#39ff88;--dsw-alias-button-primary-hover:#72ffaa;--dsw-alias-button-primary-dimmed:#174d2d;--dsw-alias-button-info-fill:#21d972;--dsw-alias-button-info-hover:#39ff88;--dsw-alias-button-contrast-fill:#d7ffe5;--dsw-alias-button-elevated-fill:#0b1a12;--dsw-alias-button-floating-fill:#0b1a12;--dsw-alias-button-floating-hover:#123421;--dsw-alias-button-ghost-active-border:#39ff8880;--dsw-alias-button-ghost-active-fill:#143923;--dsw-alias-button-ghost-active-hover:#174d2d;--dsw-alias-button-tool-bar-fill:#39ff8826;--dsw-alias-button-tool-bar-fill-invisible:#39ff8814;--dsw-alias-button-tool-bar-hover:#39ff8840;--dsw-alias-interactive-bg-active:#174d2d;--dsw-alias-interactive-bg-hover:#10261a;--dsw-alias-interactive-bg-hover-accent:#143923;--dsw-alias-interactive-bg-hover-danger:#351016;--dsw-alias-interactive-bg-hover-solid:#39ff88;--dsw-alias-label-primary:#d7ffe5;--dsw-alias-label-secondary:#9cd8ae;--dsw-alias-label-tertiary:#6ea17d;--dsw-alias-label-caption:#659773;--dsw-alias-label-dimmed:#4f795c;--dsw-alias-label-primary-dimmed:#93c9a3;--dsw-alias-label-primary-foreground:#001b0b;--dsw-alias-label-primary-inverted:#001b0b;--dsw-alias-markdown-code-block:#07120d;--dsw-alias-markdown-code-block-banner:#0b1a12;--dsw-alias-markdown-inline-code:#0b1a12;--dsw-alias-markdown-citation:#10261a;--dsw-alias-markdown-code-segment-selected:#143923;--dsw-alias-markdown-code-segment-unselected:#07120d;--dsw-alias-markdown-placeholder:#0b1a12;--dsw-alias-markdown-tag:#10261a;--dsw-alias-state-business-primary:#39ff88;--dsw-alias-state-business-tertiary:#143923;--dsw-alias-state-error-primary:#ff5f6d;--dsw-alias-state-error-secondary:#ff8791;--dsw-alias-state-success-primary:#39ff88;--dsw-alias-state-success-secondary:#72ffaa;--dsw-alias-state-success-tertiary:#123421;--dsw-alias-state-warn-primary:#ffd166;--dsw-alias-toast-bg:#0b1a12;--dsw-alias-tooltip-bg:#10261a;--dsw-specific-bubble:#0b1a12;--dsw-specific-bubble-highlight:#123421;--dsw-specific-input-major:#07120d;--dsw-specific-login-input:#07120d;--dsw-specific-menu:#07120d;--dsw-specific-selector:#10261a;--dsw-specific-sidebar-fill:#050d09;--dsw-specific-sidebar-nav-item-active:#143923;--dsw-specific-sidebar-nav-item-active-accent:#39ff88;--dsw-specific-sidebar-nav-item-hover:#0b1a12;--dsw-specific-tip:#0b1a12;box-sizing:border-box;color:#d7ffe5;background-color:#030806;background-image:radial-gradient(circle at 78% 8%,#39ff8812,transparent 26%),linear-gradient(#39ff8808 1px,transparent 1px),linear-gradient(90deg,#39ff8808 1px,transparent 1px);background-size:auto,32px 32px,32px 32px;padding:36px 6px 27px}body[data-dsh-hacker-terminal][data-ds-dark-theme]{--dsw-alias-bg-base:#030806;--dsw-alias-bg-layer-1:#07120d;--dsw-alias-bg-layer-2:#0b1a12;--dsw-alias-bg-layer-3:#10261a;--dsw-alias-label-primary:#d7ffe5;--dsw-alias-label-secondary:#9cd8ae;--dsw-alias-label-primary-foreground:#001b0b;--dsw-alias-markdown-code-block:#07120d;--dsw-alias-markdown-inline-code:#0b1a12;--dsw-alias-button-primary-fill:#39ff88;--dsw-alias-button-primary-hover:#72ffaa;--dsw-specific-bubble:#0b1a12;--dsw-specific-sidebar-fill:#050d09}body[data-dsh-hacker-terminal] [id=root]{position:relative;z-index:1;height:calc(100vh - 63px)!important;min-height:0!important;background:#030806df;border:1px solid #39ff8845;box-shadow:0 0 0 1px #000,0 0 28px #39ff8824,inset 0 0 60px #001b0b66;overflow:hidden}body[data-dsh-hacker-terminal] [id=root]::after{content:\"\";position:absolute;inset:6px;z-index:99999;pointer-events:none;background:linear-gradient(#39ff88,#39ff88) 0 0/28px 1px no-repeat,linear-gradient(#39ff88,#39ff88) 0 0/1px 28px no-repeat,linear-gradient(#39ff88,#39ff88) 100% 0/28px 1px no-repeat,linear-gradient(#39ff88,#39ff88) 100% 0/1px 28px no-repeat,linear-gradient(#39ff88,#39ff88) 0 100%/28px 1px no-repeat,linear-gradient(#39ff88,#39ff88) 0 100%/1px 28px no-repeat,linear-gradient(#39ff88,#39ff88) 100% 100%/28px 1px no-repeat,linear-gradient(#39ff88,#39ff88) 100% 100%/1px 28px no-repeat;opacity:.5}body[data-dsh-hacker-terminal] *{scrollbar-color:#246b3f #050d09}body[data-dsh-hacker-terminal] ::selection{color:#001b0b;background:#39ff88}body[data-dsh-hacker-terminal] ::-webkit-scrollbar{width:9px;height:9px}body[data-dsh-hacker-terminal] ::-webkit-scrollbar-track{background:#050d09}body[data-dsh-hacker-terminal] ::-webkit-scrollbar-thumb{background:#246b3f;border:2px solid #050d09}body[data-dsh-hacker-terminal] button,body[data-dsh-hacker-terminal] input,body[data-dsh-hacker-terminal] textarea,body[data-dsh-hacker-terminal] [role=button]{font-family:var(--dsw-font-family)}body[data-dsh-hacker-terminal] button{letter-spacing:.02em}body[data-dsh-hacker-terminal] input:focus,body[data-dsh-hacker-terminal] textarea:focus{box-shadow:0 0 0 1px #39ff8899,0 0 18px #39ff881a!important}body[data-dsh-hacker-terminal] pre{border:1px solid #39ff8838!important;box-shadow:inset 3px 0 #39ff8866}body[data-dsh-hacker-terminal] code{color:#b8ffce}body[data-dsh-hacker-terminal] a{color:#72ffaa;text-decoration-color:#39ff8870}body[data-dsh-hacker-terminal]::after{content:\"\";position:fixed;inset:0;z-index:2147483000;pointer-events:none;background:repeating-linear-gradient(0deg,#0000 0,#0000 3px,#0006 4px);opacity:.16;mix-blend-mode:multiply}.dsh-hacker-matrix{position:fixed;inset:32px 0 23px;z-index:2;width:100%;height:calc(100% - 55px);pointer-events:none;opacity:.13;mix-blend-mode:screen;filter:drop-shadow(0 0 3px #39ff8866)}.dsh-hacker-bar{position:fixed;left:0;right:0;z-index:1000000;display:flex;align-items:center;box-sizing:border-box;color:#9cd8ae;background:#030806ed;border-color:#39ff8845;font:600 11px/1 var(--dsw-font-family);letter-spacing:.09em;text-transform:uppercase;user-select:none;backdrop-filter:blur(10px)}.dsh-hacker-top{top:0;height:32px;padding:0 12px;border-bottom:1px solid #39ff8845;box-shadow:0 5px 22px #000}.dsh-hacker-bottom{bottom:0;height:23px;padding:0 10px;border-top:1px solid #39ff8838}.dsh-hacker-mark{display:inline-flex;align-items:center;gap:8px;color:#39ff88}.dsh-hacker-mark>span:last-child{text-shadow:1px 0 #39ff88,-1px 0 #00c8ff;animation:dsh-hacker-glitch 7s steps(1,end) infinite}.dsh-hacker-prompt{color:#d7ffe5}.dsh-hacker-prompt::after{content:\"_\";display:inline-block;margin-left:4px;color:#39ff88;animation:dsh-hacker-blink 1.1s steps(1,end) infinite}.dsh-hacker-spacer{flex:1}.dsh-hacker-chip{display:inline-flex;align-items:center;height:100%;padding:0 10px;border-left:1px solid #39ff8826;color:#6ea17d;letter-spacing:.06em}.dsh-hacker-chip strong{color:#9cd8ae;font-weight:600}.dsh-hacker-clock{min-width:72px;color:#72ffaa;font-variant-numeric:tabular-nums}.dsh-hacker-led{width:7px;height:7px;margin-right:7px;border-radius:50%;background:#39ff88;box-shadow:0 0 8px #39ff88;animation:dsh-hacker-pulse 1.8s ease-in-out infinite}.dsh-hacker-sigil{width:18px;height:18px;display:grid;place-items:center;border:1px solid #39ff8880;color:#39ff88;box-shadow:inset 0 0 8px #39ff8824;font-size:12px}.dsh-hacker-wave{display:flex;align-items:center;gap:2px;height:13px;margin-left:12px}.dsh-hacker-wave i{display:block;width:2px;height:4px;background:#39ff88;box-shadow:0 0 4px #39ff88;animation:dsh-hacker-wave .8s ease-in-out infinite alternate}.dsh-hacker-wave i:nth-child(2){animation-delay:-.55s}.dsh-hacker-wave i:nth-child(3){animation-delay:-.3s}.dsh-hacker-wave i:nth-child(4){animation-delay:-.65s}.dsh-hacker-wave i:nth-child(5){animation-delay:-.15s}@keyframes dsh-hacker-blink{0%,48%{opacity:1}49%,100%{opacity:0}}@keyframes dsh-hacker-pulse{50%{opacity:.45;box-shadow:0 0 3px #39ff88}}@keyframes dsh-hacker-wave{to{height:12px}}@keyframes dsh-hacker-glitch{0%,94%,100%{transform:none;text-shadow:1px 0 #39ff88,-1px 0 #00c8ff}95%{transform:translate(1px);text-shadow:-2px 0 #ff3b81,2px 0 #00c8ff}96%{transform:translate(-1px)}97%{transform:none}}@media (prefers-reduced-motion:reduce){.dsh-hacker-prompt::after,.dsh-hacker-led,.dsh-hacker-wave i,.dsh-hacker-mark>span:last-child{animation:none}.dsh-hacker-matrix{opacity:.08}}@media (max-width:760px){body[data-dsh-hacker-terminal]{padding-left:0;padding-right:0}.dsh-hacker-chip[data-optional=true]{display:none}.dsh-hacker-top{padding:0 8px}.dsh-hacker-chip{padding:0 7px}}";
    const tagId = "dsh-client-ui-skin-hacker-terminal/hacker-terminal.css";
    const fxCss = ".dsh-hacker-scan{position:fixed;left:7px;right:7px;top:33px;z-index:4;height:110px;pointer-events:none;background:linear-gradient(180deg,transparent,#39ff8805 42%,#72ffaa22 49%,#39ff8808 52%,transparent);mix-blend-mode:screen;animation:dsh-hacker-scan 8s cubic-bezier(.4,0,.6,1) infinite}.dsh-hacker-rail{position:fixed;top:42px;bottom:34px;right:10px;z-index:5;width:18px;pointer-events:none;color:#39ff8878;font:600 8px/1 var(--ds-font-family-code);letter-spacing:.14em;text-transform:uppercase;display:flex;flex-direction:column;align-items:center;justify-content:space-between}.dsh-hacker-rail::before{content:\"\";position:absolute;top:0;bottom:0;left:8px;width:1px;background:repeating-linear-gradient(to bottom,#39ff8880 0 1px,transparent 1px 12px)}.dsh-hacker-rail span{position:relative;padding:4px 1px;background:#030806;writing-mode:vertical-rl;text-orientation:mixed}.dsh-hacker-rail b{position:relative;width:7px;height:7px;border:1px solid #39ff8880;background:#030806;transform:rotate(45deg);box-shadow:0 0 7px #39ff8840}.dsh-hacker-sync{position:fixed;inset:32px 0 23px;z-index:6;pointer-events:none;opacity:0;background:linear-gradient(90deg,transparent 0,#39ff8812 42%,#d7ffe566 50%,#39ff8812 58%,transparent 100%);transform:scaleX(.02)}.dsh-hacker-sync.is-active{animation:dsh-hacker-sync .36s ease-out}.dsh-hacker-input-host{position:relative!important}.dsh-hacker-input-host textarea{padding-top:24px!important}.dsh-hacker-input-prompt{position:absolute;z-index:3;top:8px;left:14px;pointer-events:none;color:#39ff88;font:600 10px/1 var(--ds-font-family-code);letter-spacing:.08em;text-shadow:0 0 8px #39ff8866}.dsh-hacker-input-prompt::before{content:\"⌁ \";color:#31d7ff}.dsh-hacker-input-prompt::after{content:\"_\";margin-left:4px;animation:dsh-hacker-blink 1.1s steps(1,end) infinite}.dsh-hacker-decode{animation:dsh-hacker-decode .48s cubic-bezier(.2,.7,.2,1) both}.dsh-hacker-target{position:fixed;z-index:7;width:22px;height:22px;pointer-events:none;opacity:0;border:1px solid #39ff8855;transform:translate(-50%,-50%);transition:opacity .18s}.dsh-hacker-target::before,.dsh-hacker-target::after{content:\"\";position:absolute;background:#39ff8899}.dsh-hacker-target::before{left:-5px;right:-5px;top:10px;height:1px}.dsh-hacker-target::after{top:-5px;bottom:-5px;left:10px;width:1px}body[data-dsh-hacker-terminal]:hover>.dsh-hacker-target{opacity:.32}@keyframes dsh-hacker-scan{0%{transform:translateY(-130px);opacity:0}8%{opacity:.65}48%{opacity:.28}92%{opacity:.55}100%{transform:translateY(calc(100vh - 50px));opacity:0}}@keyframes dsh-hacker-sync{0%{opacity:0;transform:scaleX(.02)}35%{opacity:.75;transform:scaleX(1)}100%{opacity:0;transform:scaleX(1)}}@keyframes dsh-hacker-decode{0%{opacity:0;filter:blur(3px);clip-path:inset(0 100% 0 0);text-shadow:-3px 0 #ff3b81,3px 0 #31d7ff}45%{opacity:.78;filter:blur(.5px);text-shadow:2px 0 #31d7ff}100%{opacity:1;filter:none;clip-path:inset(0);text-shadow:none}}@media (prefers-reduced-motion:reduce){.dsh-hacker-scan,.dsh-hacker-target{display:none}.dsh-hacker-decode,.dsh-hacker-sync.is-active,.dsh-hacker-input-prompt::after{animation:none}}@media (max-width:760px){.dsh-hacker-rail,.dsh-hacker-target{display:none}}";
    const glassCss = ".dsh-hacker-input-host{background:linear-gradient(135deg,#d7ffe50c 0%,#39ff8807 36%,#31d7ff0a 72%,#03080670 100%)!important;border:1px solid #72ffaa55!important;border-radius:27px!important;box-shadow:inset 0 1px 0 #d7ffe526,inset 1px 0 0 #39ff8814,inset 0 -1px 0 #31d7ff1f,0 16px 46px #000b,0 0 32px #39ff8814!important;backdrop-filter:blur(22px) saturate(145%);-webkit-backdrop-filter:blur(22px) saturate(145%);overflow:hidden}.dsh-hacker-input-host::before{content:\"\";position:absolute;inset:0;z-index:0;pointer-events:none;background:linear-gradient(115deg,#fff0 18%,#d7ffe50d 38%,#fff0 57%),radial-gradient(circle at 12% 0%,#72ffaa18,transparent 34%);background-size:220% 100%,100% 100%;animation:dsh-hacker-glass-shine 9s ease-in-out infinite}.dsh-hacker-input-host::after{content:\"\";position:absolute;inset:1px;z-index:0;pointer-events:none;border-radius:26px;box-shadow:inset 0 0 24px #31d7ff0a}.dsh-hacker-input-host textarea{position:relative;z-index:1;background:transparent!important;color:#d7ffe5!important;caret-color:#39ff88}.dsh-hacker-input-host textarea::placeholder{color:transparent!important;opacity:0!important}.dsh-hacker-input-host .dsh-hacker-input-prompt{z-index:2}.dsh-hacker-input-host:focus-within{border-color:#72ffaa99!important;box-shadow:inset 0 1px 0 #d7ffe538,inset 0 0 34px #39ff880d,0 18px 52px #000c,0 0 38px #39ff8829!important}@keyframes dsh-hacker-glass-shine{0%,68%,100%{background-position:120% 0,0 0}82%{background-position:-80% 0,0 0}}@media (prefers-reduced-motion:reduce){.dsh-hacker-input-host::before{animation:none}}";
    const compactCss = ".dsh-hacker-input-host{overflow:visible!important}.dsh-hacker-input-host::before{border-radius:inherit}.dsh-hacker-input-host textarea{padding-top:0!important}.dsh-hacker-input-host textarea:focus{outline:none!important;box-shadow:none!important}.dsh-hacker-input-host .dsh-hacker-input-prompt{top:0!important;left:20px!important;padding:1px 8px;transform:translateY(-50%);border:1px solid #72ffaa3d;border-radius:999px;background:#07120de8;box-shadow:0 0 14px #39ff8817;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}";
    const lineFixCss = "body[data-dsh-hacker-terminal] .dsh-hacker-input-host textarea:focus,body[data-dsh-hacker-terminal] .dsh-hacker-input-host textarea:focus-visible{outline:0!important;border-color:transparent!important;box-shadow:none!important}";
    const promptPositionCss = ".dsh-hacker-input-host .dsh-hacker-input-prompt{top:12px!important;left:18px!important;padding:0!important;transform:none!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;opacity:1;transition:opacity .16s ease,transform .16s ease}.dsh-hacker-input-host:focus-within .dsh-hacker-input-prompt{opacity:0;transform:translateY(-3px)!important}";
    const promptAlwaysCss = ".dsh-hacker-input-host textarea{height:48px!important;padding-top:16px!important;padding-bottom:0!important}.dsh-hacker-input-host:focus-within .dsh-hacker-input-prompt{opacity:1!important;transform:none!important}";
    const inputEchoFixCss = ".dsh-hacker-input-host [data-input-backdrop=true]{opacity:0!important;pointer-events:none!important}";
    const greenGlassCss = ".dsh-hacker-input-host{background:linear-gradient(135deg,#d7ffe50c 0%,#39ff8809 38%,#72ffaa08 72%,#03080670 100%)!important;box-shadow:inset 0 1px 0 #d7ffe526,inset 1px 0 0 #39ff8814,inset 0 -1px 0 #39ff881a,0 16px 46px #000b,0 0 32px #39ff8814!important}.dsh-hacker-input-host::after{box-shadow:inset 0 0 24px #39ff880a!important}.dsh-hacker-input-prompt::before{color:#72ffaa!important}";
    const fontCss = "@font-face{font-family:'DshShareTechMono';src:url(data:font/ttf;base64,__DSH_SHARE_TECH_MONO__) format('truetype');font-style:normal;font-weight:400;font-display:swap}@font-face{font-family:'DshJetBrainsMono';src:url(data:font/ttf;base64,__DSH_JETBRAINS_MONO__) format('truetype');font-style:normal;font-weight:400;font-display:swap}body[data-dsh-hacker-terminal]{--dsw-font-family:'DshJetBrainsMono','JetBrains Mono','PingFang SC','SFMono-Regular',Menlo,Monaco,Consolas,monospace;--ds-font-family-code:'DshJetBrainsMono','JetBrains Mono','PingFang SC','SFMono-Regular',Menlo,Monaco,Consolas,monospace;--dsh-hud-font:'DshShareTechMono','Share Tech Mono','DshJetBrainsMono','PingFang SC',monospace}.dsh-hacker-bar,.dsh-hacker-rail,.dsh-hacker-input-prompt,.dsh-hacker-chip,.dsh-hacker-mark,.dsh-hacker-prompt,.dsh-hacker-sigil{font-family:var(--dsh-hud-font)!important}";
    if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]") === null) {
      const tag = document.createElement("style");
      tag.dataset.plugin = "dsh-client-ui-skin-hacker-terminal";
      tag.dataset.pluginCss = tagId;
      tag.textContent = css + fxCss + glassCss + compactCss + lineFixCss + promptPositionCss + promptAlwaysCss + inputEchoFixCss + greenGlassCss + fontCss;
      document.head.appendChild(tag);
    }

    function makeChip(text, optional) {
      const chip = document.createElement("span");
      chip.className = "dsh-hacker-chip";
      if (optional) chip.dataset.optional = "true";
      chip.textContent = text;
      return chip;
    }

    function createMatrixCanvas() {
      const canvas = document.createElement("canvas");
      canvas.className = "dsh-hacker-matrix";
      canvas.dataset.skinChrome = "matrix";
      canvas.setAttribute("aria-hidden", "true");
      const context = canvas.getContext && canvas.getContext("2d");
      if (!context) return { canvas, dispose() {} };
      const glyphs = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789{}[]<>/\\$#";
      const size = 14;
      let columns = 0;
      let drops = [];
      let frame = 0;
      let last = 0;
      let stopped = false;
      const reduced = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      const resize = () => {
        const ratio = Math.min(window.devicePixelRatio || 1, 2);
        canvas.width = Math.floor(window.innerWidth * ratio);
        canvas.height = Math.floor(Math.max(1, window.innerHeight - 55) * ratio);
        canvas.style.width = window.innerWidth + "px";
        canvas.style.height = Math.max(1, window.innerHeight - 55) + "px";
        context.setTransform(ratio, 0, 0, ratio, 0, 0);
        columns = Math.ceil(window.innerWidth / size);
        drops = Array.from({ length: columns }, (_, index) => drops[index] || -Math.random() * 30);
      };
      const draw = (time) => {
        if (stopped) return;
        if (time - last > 72 || reduced) {
          last = time;
          context.fillStyle = "rgba(3,8,6,0.13)";
          context.fillRect(0, 0, window.innerWidth, Math.max(1, window.innerHeight - 55));
          context.font = "12px monospace";
          for (let index = 0; index < columns; index += 1) {
            const glyph = glyphs[Math.floor(Math.random() * glyphs.length)];
            const y = drops[index] * size;
            context.fillStyle = Math.random() > 0.985 ? "#d7ffe5" : "#39ff88";
            context.fillText(glyph, index * size, y);
            if (y > window.innerHeight && Math.random() > 0.975) drops[index] = 0;
            drops[index] += 0.48 + (index % 5) * 0.035;
          }
          if (reduced) return;
        }
        frame = window.requestAnimationFrame(draw);
      };
      resize();
      window.addEventListener("resize", resize);
      frame = window.requestAnimationFrame(draw);
      return {
        canvas,
        dispose() {
          stopped = true;
          window.cancelAnimationFrame(frame);
          window.removeEventListener("resize", resize);
        },
      };
    }

    function apply(ctx) {
      ctx.effect(() => {
        const body = document.body;
        const originalTitle = document.title;
        const hasExternalHackerAppearance = () => document.querySelector('style[data-plugin="dsh-client-ui-skin-hacker-terminal"]:not([data-plugin-css])') !== null;
        let linkedAppearance = hasExternalHackerAppearance();
        let enabled = !linkedAppearance || body.getAttribute("data-ds-theme") === "hacker";
        let renderedEnabled = null;

        const top = document.createElement("div");
        top.className = "dsh-hacker-bar dsh-hacker-top";
        top.dataset.skinChrome = "titlebar";
        top.setAttribute("aria-hidden", "true");
        const mark = document.createElement("span");
        mark.className = "dsh-hacker-mark";
        mark.innerHTML = '<span class="dsh-hacker-sigil">⌁</span><span>DSH // SECURE SHELL</span>';
        const spacer = document.createElement("span");
        spacer.className = "dsh-hacker-spacer";
        const prompt = document.createElement("span");
        prompt.className = "dsh-hacker-prompt";
        prompt.textContent = "root@deepseek:~$";
        const clock = makeChip("00:00:00", true);
        clock.className += " dsh-hacker-clock";
        const updateClock = () => { clock.textContent = new Date().toLocaleTimeString("en-GB", { hour12: false }); };
        updateClock();
        const clockTimer = window.setInterval(updateClock, 1000);
        top.append(mark, spacer, makeChip("KERNEL 0x7F", true), makeChip("AES-256", true), clock, prompt);

        const bottom = document.createElement("div");
        bottom.className = "dsh-hacker-bar dsh-hacker-bottom";
        bottom.dataset.skinChrome = "statusbar";
        bottom.setAttribute("aria-hidden", "true");
        const status = document.createElement("span");
        status.className = "dsh-hacker-mark";
        status.innerHTML = '<span class="dsh-hacker-led"></span><span>SYSTEM ONLINE</span>';
        const wave = document.createElement("span");
        wave.className = "dsh-hacker-wave";
        wave.innerHTML = "<i></i><i></i><i></i><i></i><i></i>";
        const bottomSpacer = document.createElement("span");
        bottomSpacer.className = "dsh-hacker-spacer";
        bottom.append(status, wave, makeChip("LINK: ENCRYPTED", true), bottomSpacer, makeChip("NODE 127.0.0.1"), makeChip("UTF-8", true));

        const matrix = createMatrixCanvas();
        const scan = document.createElement("div");
        scan.className = "dsh-hacker-scan";
        scan.dataset.skinChrome = "scan";
        scan.setAttribute("aria-hidden", "true");
        const rail = document.createElement("div");
        rail.className = "dsh-hacker-rail";
        rail.dataset.skinChrome = "rail";
        rail.setAttribute("aria-hidden", "true");
        rail.innerHTML = "<span>SECTOR 07</span><b></b><span>GHOST LINK</span><b></b><span>NODE ACTIVE</span>";
        const sync = document.createElement("div");
        sync.className = "dsh-hacker-sync";
        sync.dataset.skinChrome = "sync";
        sync.setAttribute("aria-hidden", "true");
        const target = document.createElement("div");
        target.className = "dsh-hacker-target";
        target.dataset.skinChrome = "target";
        target.setAttribute("aria-hidden", "true");

        let inputHost = null;
        let inputPrompt = null;
        const attachInputPrompt = () => {
          if (!enabled) return;
          const textbox = document.querySelector("textarea");
          const host = textbox && textbox.parentElement && textbox.parentElement.parentElement && textbox.parentElement.parentElement.parentElement;
          if (!textbox || !host) return;
          if (host === inputHost) {
            if (!host.classList.contains("dsh-hacker-input-host")) host.classList.add("dsh-hacker-input-host");
            if (inputPrompt && inputPrompt.parentElement !== host) host.appendChild(inputPrompt);
            return;
          }
          if (inputPrompt) inputPrompt.remove();
          if (inputHost) inputHost.classList.remove("dsh-hacker-input-host");
          inputHost = host;
          inputHost.classList.add("dsh-hacker-input-host");
          inputPrompt = document.createElement("span");
          inputPrompt.className = "dsh-hacker-input-prompt";
          inputPrompt.textContent = "SECURE INPUT // COMMAND CHANNEL";
          inputHost.appendChild(inputPrompt);
        };

        const chromeElements = [matrix.canvas, scan, rail, sync, target, top, bottom];
        const setEnabled = (next) => {
          enabled = next;
          if (renderedEnabled === next) return;
          renderedEnabled = next;
          body.toggleAttribute("data-dsh-hacker-terminal", next);
          for (const element of chromeElements) {
            if (next) element.style.removeProperty("display");
            else element.style.setProperty("display", "none", "important");
          }
          if (next) {
            if (!favicon.isConnected) document.head.appendChild(favicon);
            document.title = "DSH // Hacker Terminal";
            attachInputPrompt();
          } else {
            favicon.remove();
            if (inputPrompt) inputPrompt.remove();
            if (inputHost) inputHost.classList.remove("dsh-hacker-input-host");
            document.title = linkedAppearance ? "DeepSeek Harness" : originalTitle;
          }
        };

        const syncAppearance = () => {
          linkedAppearance = linkedAppearance || hasExternalHackerAppearance();
          if (linkedAppearance) setEnabled(body.getAttribute("data-ds-theme") === "hacker");
        };

        const animateNewContent = (node) => {
          if (!(node instanceof Element)) return;
          const targets = [];
          if (node.matches("p, pre")) targets.push(node);
          for (const item of node.querySelectorAll("p, pre")) targets.push(item);
          for (const item of targets.slice(-4)) {
            if (item.closest("[data-skin-chrome]")) continue;
            item.classList.add("dsh-hacker-decode");
            window.setTimeout(() => item.classList.remove("dsh-hacker-decode"), 650);
          }
        };
        const observer = new MutationObserver((records) => {
          if (records.some((record) => record.target === body && record.attributeName === "data-ds-theme")) syncAppearance();
          if (!enabled) return;
          attachInputPrompt();
          for (const record of records) for (const node of record.addedNodes) animateNewContent(node);
        });
        observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["class", "data-ds-theme"] });
        attachInputPrompt();

        let syncTimer = 0;
        const onNavigate = (event) => {
          if (!enabled) return;
          if (!(event.target instanceof Element) || !event.target.closest('[role="treeitem"]')) return;
          sync.classList.remove("is-active");
          void sync.offsetWidth;
          sync.classList.add("is-active");
          window.clearTimeout(syncTimer);
          syncTimer = window.setTimeout(() => sync.classList.remove("is-active"), 420);
        };
        const onPointer = (event) => {
          if (!enabled) return;
          target.style.left = event.clientX + "px";
          target.style.top = event.clientY + "px";
        };
        document.addEventListener("click", onNavigate, true);
        document.addEventListener("pointermove", onPointer, { passive: true });

        const favicon = document.createElement("link");
        favicon.rel = "icon";
        favicon.href = "data:image/svg+xml," + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" rx="8" fill="#030806"/><path d="M15 19l14 13-14 13M32 45h17" fill="none" stroke="#39ff88" stroke-width="6" stroke-linecap="square" stroke-linejoin="miter"/></svg>');
        body.prepend(matrix.canvas);
        body.append(scan, rail, sync, target, top, bottom);
        setEnabled(enabled);

        return () => {
          body.removeAttribute("data-dsh-hacker-terminal");
          window.clearInterval(clockTimer);
          matrix.dispose();
          matrix.canvas.remove();
          observer.disconnect();
          document.removeEventListener("click", onNavigate, true);
          document.removeEventListener("pointermove", onPointer);
          window.clearTimeout(syncTimer);
          if (inputPrompt) inputPrompt.remove();
          if (inputHost) inputHost.classList.remove("dsh-hacker-input-host");
          scan.remove();
          rail.remove();
          sync.remove();
          target.remove();
          top.remove();
          bottom.remove();
          favicon.remove();
          if (document.title === "DSH // Hacker Terminal") document.title = originalTitle;
        };
      }, "ui-skin-hacker-terminal: terminal chrome");
    }

    exports.apply = apply;
    return module.exports;
  }
});
