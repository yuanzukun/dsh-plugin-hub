# DSH 黑客终端皮肤

一个可独立安装的 DeepSeek Harness Web UI 黑客终端主题插件。

安装后，DSH 会变成绿色黑底的安全终端界面，包含英文与数字字符雨、玻璃输入框、HUD 状态栏、扫描效果和本地内嵌等宽字体；卸载时会完整清理所有副作用。

![DSH 黑客终端皮肤预览](preview.png)

## 特点

- 作为标准 DSH 组合包安装并自动启用；
- 字符雨仅使用 `A-Z`、`0-9` 与少量终端符号；
- HUD 使用 Share Tech Mono，正文与输入使用 JetBrains Mono；
- 中文自动回退到苹方；
- 支持系统“减少动态效果”设置；
- 卸载时清除所有样式、DOM、监听器、观察器与定时器；
- 不包含统计代码，不发起网络请求。

## 从 GitHub 安装

```bash
dsh plugin --profile web add github:chengwill45-bot/dsh-hacker-terminal-theme
```

安装后重启当前 `dsh web` 进程并刷新页面。

仓库会提交已经构建好的 `lib/` 文件，因此从 GitHub 安装不需要运行 `prepare`，也不需要授权 pnpm 执行安装脚本。

## 从本地目录安装

```bash
git clone https://github.com/chengwill45-bot/dsh-hacker-terminal-theme.git
cd dsh-hacker-terminal-theme
npm test
dsh plugin --profile web add "link:$PWD"
```

随后重启 DSH 并刷新 Web UI。

## 卸载

```bash
dsh plugin --profile web remove dsh-client-ui-skin-hacker-terminal
```

重启 DSH 并刷新页面即可恢复。插件不会修改对话数据，也不会改动 profile 依赖项之外的 DSH 配置。

## 开发

```bash
npm run build
npm test
npm run check
```

项目没有运行时 npm 依赖。

## 兼容性

DeepSeek Harness 目前仍处于开发者预览阶段，未来可能出现破坏性 UI 变更。本插件针对当前 DSH Web UI 的布局与输入组件开发。

## 许可

插件代码使用 MIT 许可证。随包分发的 Share Tech Mono 与 JetBrains Mono 字体使用 SIL Open Font License 1.1。详见 [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) 和 [`fonts/`](fonts/) 目录内的许可证文件。
