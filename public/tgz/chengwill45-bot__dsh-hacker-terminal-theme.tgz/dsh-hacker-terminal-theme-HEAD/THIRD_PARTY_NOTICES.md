# Third-Party Notices

This project bundles the following font software:

## Share Tech Mono

- Copyright (c) 2012, Carrois Type Design, Ralph du Carrois
- License: SIL Open Font License 1.1
- License text: `fonts/OFL-ShareTechMono.txt`
- Source: https://github.com/google/fonts/tree/main/ofl/sharetechmono

## JetBrains Mono

- Copyright 2020 The JetBrains Mono Project Authors
- License: SIL Open Font License 1.1
- License text: `fonts/OFL-JetBrainsMono.txt`
- Source: https://github.com/JetBrains/JetBrainsMono
