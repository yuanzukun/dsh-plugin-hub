import { mkdir, readFile, writeFile } from 'node:fs/promises'
import { resolve } from 'node:path'

const root = new URL('.', import.meta.url)
const moduleId = 'dsh-client-ui-skin-hacker-terminal'

const [clientTemplate, serverEntry, shareTechMono, jetBrainsMono] = await Promise.all([
  readFile(new URL('./src/client.js', root), 'utf8'),
  readFile(new URL('./src/index.js', root), 'utf8'),
  readFile(new URL('./fonts/ShareTechMono-Regular.ttf', root)),
  readFile(new URL('./fonts/JetBrainsMono-Regular.ttf', root)),
])

const client = clientTemplate
  .replace('__DSH_SHARE_TECH_MONO__', shareTechMono.toString('base64'))
  .replace('__DSH_JETBRAINS_MONO__', jetBrainsMono.toString('base64'))

if (!client.includes(`id: "${moduleId}"`)) {
  throw new Error(`client module id must be ${moduleId}`)
}
if (/__DSH_(?:SHARE_TECH|JETBRAINS)_MONO__/.test(client)) {
  throw new Error('font placeholder was not replaced')
}

await mkdir(new URL('./lib/', root), { recursive: true })
await Promise.all([
  writeFile(new URL('./lib/client.js', root), client),
  writeFile(new URL('./lib/index.js', root), serverEntry),
])

if (process.argv.includes('--check')) {
  const built = await readFile(new URL('./lib/client.js', root), 'utf8')
  if (!built.includes('window.__ModuleLoader__.load')) throw new Error('client loader wrapper missing')
  if (!built.includes('exports.apply = apply')) throw new Error('client apply export missing')
  if (!built.includes('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789')) throw new Error('Latin matrix glyph set missing')
  if (/[\u3040-\u30ff]/u.test(built)) throw new Error('Japanese glyphs must not be present')
}

console.log(`built ${resolve(new URL('./lib/client.js', root).pathname)}`)
