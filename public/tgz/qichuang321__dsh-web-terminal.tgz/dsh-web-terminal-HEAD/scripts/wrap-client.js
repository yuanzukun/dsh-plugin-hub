import fs from 'fs'

const file = 'lib/client.js'
let content = fs.readFileSync(file, 'utf8')

// Skip if already wrapped
if (content.includes('__ModuleLoader__')) {
  console.log('Already wrapped, skipping.')
  process.exit(0)
}

const banner = `window.__ModuleLoader__.load({ id: "dsh-web-terminal", factory: (require) => {
var module = { exports: {} }; var exports = module.exports;
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
`

const footer = `
return module.exports;
} });
`

content = banner + content + footer
fs.writeFileSync(file, content)
console.log('Wrapped lib/client.js for DSH client module loader.')
