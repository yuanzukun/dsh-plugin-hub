// Generate src/client/xterm-css.ts + src/client/dock-css.ts from the raw CSS
// sources (tsdown/rolldown cannot resolve '?raw' imports, so the CSS text is
// embedded at authoring time — same approach as dsh-ssh's xterm.css.ts).
// Run: node scripts/gen-css.mjs
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { fileURLToPath } from 'node:url'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const clientDir = join(root, 'src', 'client')

function toTs(name, css) {
  const escaped = css
    .replace(/\\/g, '\\\\')
    .replace(/`/g, '\\`')
    .replace(/\$\{/g, '\\${')
  return `/** GENERATED — do not edit by hand. Run \`node scripts/gen-css.mjs\` after touching the CSS source. */\nexport const ${name} = \`${escaped}\`\n`
}

// xterm.css comes from the installed @xterm/xterm package.
const xtermCss = readFileSync(join(root, 'node_modules', '@xterm', 'xterm', 'css', 'xterm.css'), 'utf8')
writeFileSync(join(clientDir, 'xterm-css.ts'), toTs('XTERM_CSS', xtermCss))

// dock styles are authored in styles.css (source of truth).
const dockCss = readFileSync(join(root, 'src', 'client', 'styles.css'), 'utf8')
writeFileSync(join(clientDir, 'dock-css.ts'), toTs('DOCK_CSS', dockCss))

console.log('generated xterm-css.ts (%d chars) and dock-css.ts (%d chars)', xtermCss.length, dockCss.length)
