// Smoke test: open a real WebSocket PTY session against the live GUI.
// Usage: node scripts/smoke-ws.mjs
import WebSocket from 'ws'

const ws = new WebSocket('ws://127.0.0.1:3080/api/dsh-web-terminal/session?cols=80&rows=24')
let buffer = ''
let ready = false

const done = (code, why) => {
  console.log(why)
  try { ws.close() } catch { /* closed */ }
  setTimeout(() => process.exit(code), 50)
}

ws.on('open', () => {
  console.log('WS OPEN')
  setTimeout(() => {
    ws.send(JSON.stringify({ type: 'input', data: 'echo WEB-TERMINAL-OK\r' }))
  }, 2000)
})

ws.on('message', (raw) => {
  let frame
  try { frame = JSON.parse(String(raw)) } catch { return }
  if (frame.type === 'ready') {
    ready = true
    console.log(`READY view=${frame.view} cols=${frame.cols} rows=${frame.rows}`)
  } else if (frame.type === 'output') {
    buffer += frame.data
    if (buffer.includes('WEB-TERMINAL-OK')) {
      console.log('PTY OUTPUT OK — sample:', JSON.stringify(frame.data.slice(0, 100)))
      done(0, 'SMOKE PASS')
    }
  } else if (frame.type === 'exit') {
    done(frame.code === 0 ? 0 : 1, `EXIT code=${frame.code} error=${frame.error ?? ''}`)
  }
})

ws.on('close', () => { if (!buffer.includes('WEB-TERMINAL-OK')) done(1, 'CLOSED before output; buffer tail: ' + JSON.stringify(buffer.slice(-120))) })
ws.on('error', (e) => done(1, 'WS ERROR: ' + e.message))

setTimeout(() => done(1, 'TIMEOUT; buffer tail: ' + JSON.stringify(buffer.slice(-120))), 20000)
