/**
 * The /api/dsh-web-terminal route family: the views REST endpoint and the
 * WebSocket PTY terminal upgrade. Every route carries the loopback-only trust
 * fence (plus browser same-origin markers) — these endpoints spawn local
 * shells, so LAN-exposed dsh web deployments must not serve them.
 */

import type { IncomingMessage, ServerResponse } from 'node:http'
import { appendFileSync, mkdirSync } from 'node:fs'
import { join } from 'node:path'
import { WebSocket, WebSocketServer } from 'ws'
import type { WebRoute, WebUpgradeRoute } from '@deepseek-ai/dsh-host-webserver'
import { spawnPty, killPty } from './pty.ts'
import {
  BACKPRESSURE_HIGH_WATER,
  BACKPRESSURE_LOW_WATER,
  WT_API,
  type ServerFrame,
  parseClientFrame,
  clampCols,
  clampRows,
  SHELL_VIEW_ID,
} from './protocol.ts'
import type { WebTerminalRegistry } from './tui-registry.ts'

/** One noServer WebSocket server for terminal upgrades (browser uses a real RFC 6455 client). */
const terminalWss = new WebSocketServer({ noServer: true })

/** Diagnostics sink (dev aid): DSH_HOME/dsh-web-terminal-diag.log. */
function diagLog(line: string): void {
  try {
    const dir = process.env.DSH_HOME ?? '.'
    mkdirSync(dir, { recursive: true })
    appendFileSync(join(dir, 'dsh-web-terminal-diag.log'), `${new Date().toISOString()} ${line}\n`)
  } catch {
    // diagnostics must never break the plugin
  }
}

/** Loopback literal check plus browser same-origin markers (mirrors dsh-ssh routes.ts:42-62). */
export function isLoopbackRequest(request: IncomingMessage): boolean {
  const address = request.socket.remoteAddress
  if (address !== '127.0.0.1' && address !== '::1' && address !== '::ffff:127.0.0.1') return false
  const host = request.headers.host
  if (typeof host !== 'string') return false
  let hostUrl: URL
  try {
    hostUrl = new URL(`http://${host}`)
  } catch {
    return false
  }
  if (hostUrl.hostname !== '127.0.0.1' && hostUrl.hostname !== 'localhost' && hostUrl.hostname !== '[::1]') return false
  if (request.headers['sec-fetch-site'] === 'cross-site') return false
  const origin = request.headers.origin
  if (origin === undefined) return true
  try {
    return new URL(origin).host === hostUrl.host
  } catch {
    return false
  }
}

function writeJson(res: ServerResponse, status: number, body: unknown): void {
  const payload = JSON.stringify(body)
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'referrer-policy': 'no-referrer' })
  res.end(payload)
}

/** Query-string helper (first value, decoded). */
function queryParam(url: URL, name: string): string | undefined {
  const value = url.searchParams.get(name)
  return value === null ? undefined : value
}

/**
 * Build the routes + the terminal upgrade for the plugin.
 * @param registry - the TUI view registry (also used for spawn resolution).
 */
export function makeRoutes(registry: WebTerminalRegistry): { routes: WebRoute[]; upgrade: WebUpgradeRoute } {
  const routes: WebRoute[] = [
    // ------------------------------------------------------------- views
    {
      kind: 'exact',
      path: WT_API.views,
      handler: (req, res) => {
        if (!isLoopbackRequest(req)) {
          writeJson(res, 403, { error: 'forbidden: loopback-only' })
          return
        }
        if ((req.method ?? 'GET') !== 'GET') {
          writeJson(res, 405, { error: `method not allowed: ${req.method}` })
          return
        }
        writeJson(res, 200, { views: registry.list() })
      },
    },
    // ------------------------------------------------------------ diag
    {
      kind: 'exact',
      path: WT_API.diag,
      handler: (req, res) => {
        if (!isLoopbackRequest(req)) {
          writeJson(res, 403, { error: 'forbidden: loopback-only' })
          return
        }
        const chunks: Buffer[] = []
        let size = 0
        req.on('data', (chunk: Buffer) => {
          size += chunk.length
          if (size > 4096) { req.destroy(); return }
          chunks.push(chunk)
        })
        req.on('end', () => {
          const body = Buffer.concat(chunks).toString('utf8')
          let msg = body
          try {
            const parsed = JSON.parse(body) as { msg?: unknown }
            msg = typeof parsed.msg === 'string' ? parsed.msg : JSON.stringify(parsed)
          } catch { /* raw body */ }
          diagLog(`[client] ${msg}`)
          writeJson(res, 200, { ok: true })
        })
      },
    },
  ]

  // ---------------------------------------------------------- terminal
  const upgrade: WebUpgradeRoute = {
    path: WT_API.session,
    handler: (req, socket, head) => {
      if (!isLoopbackRequest(req)) {
        socket.write('HTTP/1.1 403 Forbidden\r\nConnection: close\r\n\r\n')
        socket.destroy()
        return
      }
      const url = new URL(req.url ?? '/', 'http://localhost')
      const viewId = queryParam(url, 'view') ?? SHELL_VIEW_ID
      const cols = clampCols(Number(queryParam(url, 'cols')))
      const rows = clampRows(Number(queryParam(url, 'rows')))

      terminalWss.handleUpgrade(req, socket, head, (ws) => {
        let term: ReturnType<typeof spawnPty> | undefined
        let paused = false
        let closed = false

        const resume = (): void => {
          if (paused && ws.bufferedAmount < BACKPRESSURE_LOW_WATER) {
            paused = false
            term?.resume()
          }
        }
        const sendFrame = (frame: ServerFrame): void => {
          if (closed || ws.readyState !== WebSocket.OPEN) return
          ws.send(JSON.stringify(frame), resume)
          if (!paused && ws.bufferedAmount > BACKPRESSURE_HIGH_WATER) {
            paused = true
            term?.pause()
          }
        }
        const cleanup = (): void => {
          if (closed) return
          closed = true
          const opened = term
          term = undefined
          if (opened !== undefined) killPty(opened)
        }
        const fail = (error: unknown): void => {
          sendFrame({ type: 'exit', code: null, error: error instanceof Error ? error.message : String(error) })
          cleanup()
          try { ws.close(1000) } catch { /* already closed */ }
        }

        // Resolve the view: registered spawn → program; otherwise default shell.
        void (async () => {
          let spec
          try {
            spec = await registry.resolveSpawn(viewId, { cols, rows, env: {} })
          } catch (error) {
            fail(error)
            return
          }
          if (ws.readyState !== WebSocket.OPEN) return
          try {
            term = spawnPty({
              cols,
              rows,
              command: spec?.command,
              args: spec?.args,
              shell: spec?.shell,
              cwd: spec?.cwd,
              env: spec?.env,
            })
          } catch (error) {
            fail(error)
            return
          }
          // Disconnect-during-spawn race: the close handler may have run
          // while we awaited the view spawn, so the PTY must die here too.
          if (closed || ws.readyState !== WebSocket.OPEN) {
            killPty(term)
            term = undefined
            return
          }
          sendFrame({ type: 'ready', view: viewId, cols, rows })
          const view = registry.get(viewId)
          if (view !== undefined && view.id !== SHELL_VIEW_ID && view.label !== undefined) {
            // Notify the client which view title to show in the tab.
            sendFrame({ type: 'title', title: view.label })
          }
          term.onData((data) => sendFrame({ type: 'output', data }))
          term.onExit(({ exitCode }) => {
            sendFrame({ type: 'exit', code: exitCode })
            cleanup()
            try { ws.close(1000) } catch { /* already closed */ }
          })
        })()

        ws.on('message', (data) => {
          let raw: unknown
          try {
            raw = JSON.parse(String(data))
          } catch {
            return
          }
          const frame = parseClientFrame(raw)
          if (frame === null) return
          if (frame.type === 'input') {
            term?.write(frame.data)
          } else {
            term?.resize(frame.cols, frame.rows)
          }
        })
        ws.on('close', () => cleanup())
        ws.on('error', () => cleanup())
      })
    },
  }

  return { routes, upgrade }
}
