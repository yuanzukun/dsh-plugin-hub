/**
 * Host-side TUI view registry — the extension seam that lets other DSH
 * plugins integrate terminal-designed TUI views into the web terminal dock.
 *
 * A plugin registers a view with `ctx.get('webTerminal')?.registerView(def)`
 * inside its own `ctx.effect(...)`. The dock then lists it via
 * GET /api/dsh-web-terminal/views and opens it through the session WebSocket.
 *
 * Two view kinds:
 *  - 'pty': `spawn(ctx) → SpawnSpec` — the host spawns the program/TUI as a
 *    full-emulation ConPTY child and bridges it 1:1 over the WebSocket.
 *  - 'dom': no spawn — the client renders plugin-authored content into the
 *    dock via the window CustomEvent channel ('activate' event).
 */

import type { WebTerminalViewSummary } from './protocol.ts'
import type { SpawnSpec } from './pty.ts'

/** Cols/rows/cwd/env handed to a view's spawn() hook. */
export interface SpawnCtx {
  cols: number
  rows: number
  cwd?: string
  env: Record<string, string>
}

/** A host-side view definition. */
export interface WebTerminalViewDef {
  /** Unique, namespaced id — 'pluginId:viewId'. */
  id: string
  label: string
  icon?: string
  order?: number
  /**
   * PTY views: return the command to spawn (or null/throw to fall back to a
   * default shell inside the same session).
   */
  spawn?: (ctx: SpawnCtx) => SpawnSpec | Promise<SpawnSpec>
}

/** One registered view, flattened for the wire. */
export interface RegisteredView extends WebTerminalViewDef {
  kind: 'pty' | 'dom'
  order: number
}

/** Registry state kept inside the plugin context. */
export class WebTerminalRegistry {
  private readonly views = new Map<string, RegisteredView>()
  private nextDefaultOrder = 100

  /** Register (or replace) one view; returns a disposer. */
  registerView(def: WebTerminalViewDef): () => void {
    const id = def.id
    if (typeof id !== 'string' || id.length === 0) {
      throw new Error('webTerminal.registerView: id must be a non-empty string')
    }
    if (!/^[\w.-]+:[\w.-]+$/.test(id) && id !== 'shell') {
      // Recommend namespacing, but keep 'shell' (reserved) and loose ids usable.
      console.warn(`[dsh-web-terminal] view id "${id}" is not namespaced 'pluginId:viewId'`)
    }
    const entry: RegisteredView = {
      ...def,
      kind: def.spawn !== undefined ? 'pty' : 'dom',
      order: def.order ?? this.nextDefaultOrder++,
    }
    this.views.set(id, entry)
    return () => {
      this.views.delete(id)
    }
  }

  /** All views for the /views route, ordered. */
  list(): WebTerminalViewSummary[] {
    return [...this.views.values()]
      .sort((a, b) => a.order - b.order || (a.id < b.id ? -1 : 1))
      .map((view) => ({
        id: view.id,
        label: view.label,
        icon: view.icon,
        order: view.order,
        kind: view.kind,
      }))
  }

  /** Look up one view by id (undefined for the built-in shell). */
  get(id: string): RegisteredView | undefined {
    return this.views.get(id)
  }

  /** Resolve a view's spawn spec, or undefined when it has none. */
  async resolveSpawn(id: string, ctx: SpawnCtx): Promise<SpawnSpec | undefined> {
    const view = this.views.get(id)
    if (view?.spawn === undefined) return undefined
    return await view.spawn(ctx)
  }
}
