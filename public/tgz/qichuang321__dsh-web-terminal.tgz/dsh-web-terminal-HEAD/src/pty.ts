/**
 * Local PTY layer — node-pty direct (v1.1.0, prebuilt win32-x64 ConPTY).
 *
 * Why not ctx.subprocess.spawnTerminal: that seam hard-codes name:'dumb',
 * never injects TERM on Windows (vim/htop/TUI degrade to raw line mode),
 * scrubs env, and its handle has no resize()/pause()/resume() — impossible
 * to run a full-emulation TUI or apply WebSocket backpressure. The proven
 * in-the-wild pattern (dsh-ssh) is: own WebSocket upgrade + own PTY.
 */

import * as pty from 'node-pty'
import { existsSync } from 'node:fs'
import { homedir } from 'node:os'
import { join } from 'node:path'

/** How to start one interactive shell on Windows (bash only via Git-for-Windows/WSL). */
export interface ShellChoice {
  file: string
  args: string[]
}

/**
 * Pick the best interactive shell available on this Windows host:
 * pwsh (PS7) → powershell.exe (always present) → cmd.exe (last resort).
 */
export function pickShell(): ShellChoice {
  const programFiles = process.env.ProgramFiles ?? 'C:\\Program Files'
  const pwsh = join(programFiles, 'PowerShell', '7', 'pwsh.exe')
  if (existsSync(pwsh)) return { file: pwsh, args: ['-NoLogo', '-NoExit'] }
  const windowsPowerShell = join(process.env.windir ?? 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe')
  if (existsSync(windowsPowerShell)) return { file: windowsPowerShell, args: ['-NoLogo', '-NoExit'] }
  return { file: process.env.COMSPEC ?? 'cmd.exe', args: [] }
}

/** Base env for every PTY child: host env + TERM/COLORTERM + embed marker. */
export function basePtyEnv(): Record<string, string> {
  const env: Record<string, string> = {}
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined) env[key] = value
  }
  // node-pty NEVER derives TERM from the 'name' option on Windows — set it
  // explicitly or TUI apps (vim/htop) degrade or fail.
  env.TERM = 'xterm-256color'
  env.COLORTERM = 'truecolor'
  // Embed marker: terminal-designed TUI plugins that talk to the harness
  // (dsh CLI / JSON-RPC / ACP on localhost) can detect the web dock.
  env.DSH_WEB_TERMINAL = '1'
  return env
}

/** What a registered TUI view may return from its spawn() hook. */
export interface SpawnSpec {
  command: string
  args?: string[]
  cwd?: string
  env?: Record<string, string>
  /** When true, run `command` (and args joined) through the default shell: powershell.exe -NoLogo -Command. */
  shell?: boolean
}

/** Spawn options for one session. */
export interface PtySpawnOptions {
  cols: number
  rows: number
  cwd?: string
  env?: Record<string, string>
  /** When given, spawn this program instead of the interactive shell. */
  command?: string
  args?: string[]
  shell?: boolean
}

/**
 * Spawn one full-emulation PTY.
 * @returns the node-pty IPty handle, already sized to cols×rows.
 */
export function spawnPty(options: PtySpawnOptions): pty.IPty {
  const env = { ...basePtyEnv(), ...options.env }
  const cwd = options.cwd ?? homedir()

  if (options.command !== undefined && !options.shell) {
    return pty.spawn(options.command, options.args ?? [], {
      name: 'xterm-256color',
      cols: options.cols,
      rows: options.rows,
      cwd,
      env,
      useConpty: true,
    })
  }

  if (options.command !== undefined && options.shell) {
    // Run a command through the default Windows shell. The command may be a
    // WHOLE command line ('npx --yes dsh-tui'); it must reach powershell
    // -Command verbatim — quoting it would turn the whole string into a
    // single path lookup and fail to launch.
    const shell = pickShell()
    const commandLine = [
      options.command,
      ...(options.args ?? []).map((arg) => /[\s"]/.test(arg) ? `"${arg.replace(/"/g, '""')}"` : arg),
    ].join(' ')
    return pty.spawn(shell.file, [...shell.args, '-Command', commandLine], {
      name: 'xterm-256color',
      cols: options.cols,
      rows: options.rows,
      cwd,
      env,
      useConpty: true,
    })
  }

  // Interactive default shell (no command).
  const shell = pickShell()
  return pty.spawn(shell.file, shell.args, {
    name: 'xterm-256color',
    cols: options.cols,
    rows: options.rows,
    cwd,
    env,
    useConpty: true,
  })
}

/** Safely kill a PTY on Windows (kill(signal) throws; always bare kill()). */
export function killPty(term: pty.IPty): void {
  try {
    term.kill()
  } catch {
    // Already dead or unsupported — nothing else to do.
  }
}
