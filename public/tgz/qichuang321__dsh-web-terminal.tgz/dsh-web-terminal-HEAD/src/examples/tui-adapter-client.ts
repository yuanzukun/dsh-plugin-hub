/**
 * Demo TUI adapter — browser half. Registers the 'dom' panel demo view
 * through the window CustomEvent channel and renders it when the dock
 * activates it. Proves the extension API from the client side.
 */

import {
  TUI_EVENTS,
  onTuiEvent,
  dispatchRegister,
  dispatchUnregister,
} from '../client/tui-channel.ts'
import { DEMO_PANEL_VIEW_ID } from './tui-adapter-host.ts'

/** Mount the demo adapter client; returns a disposer (call inside ctx.effect). */
export function mountDemoAdapterClient(): () => void {
  dispatchRegister({ id: DEMO_PANEL_VIEW_ID, label: 'Panel', icon: 'layout', order: 20, kind: 'dom' })

  // Render the 'dom' panel when the dock activates it.
  const disposeActivate = onTuiEvent(TUI_EVENTS.activate, (event) => {
    const detail = event.detail as { id?: string; container?: HTMLElement }
    if (detail.id !== DEMO_PANEL_VIEW_ID || !(detail.container instanceof HTMLElement)) return
    const container = detail.container
    container.classList.remove('wt-hidden')
    container.textContent = ''
    const panel = document.createElement('div')
    panel.className = 'wt-demo-panel'
    panel.innerHTML = `
      <h3>Demo DOM view</h3>
      <p>This panel is rendered by the demo TUI adapter through the
      <code>dsh-web-terminal:activate</code> CustomEvent channel — a
      terminal-designed TUI plugin needs no host cooperation to add a view.</p>
      <button type="button" data-demo-ok>ok</button>
    `
    container.appendChild(panel)
    panel.querySelector('[data-demo-ok]')?.addEventListener('click', () => {
      panel.dataset.ack = 'acknowledged'
    })
  })

  return () => {
    disposeActivate()
    dispatchUnregister(DEMO_PANEL_VIEW_ID)
  }
}
