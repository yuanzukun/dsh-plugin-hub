/**
 * Demo TUI adapter — host half. Proves the extension API end-to-end with ONE
 * view:
 *  - 'demo:panel' (kind dom): no spawn — the browser half renders a tiny
 *    React panel through the window CustomEvent 'activate' channel.
 *
 * (A 'demo:dsh-tui' PTY view existed before; it was removed because the
 * dsh-tui client's interactive mode uses GET/SSE on /api/events.mux while the
 * current DSH (0.1.0-rc.6) requires a WebSocket upgrade (HTTP 426), so it
 * reconnect-loops and redraws constantly.)
 */

import type { WebTerminalRegistry } from '../tui-registry.ts'

/** Stable ids used by both halves of the demo adapter. */
export const DEMO_PANEL_VIEW_ID = 'demo:panel'

/** Mount the demo views; returns a disposer (call inside ctx.effect). */
export function mountExampleViews(registry: WebTerminalRegistry): () => void {
  const disposers: Array<() => void> = []

  disposers.push(registry.registerView({
    id: DEMO_PANEL_VIEW_ID,
    label: 'Panel',
    icon: 'layout',
    order: 20,
    // No spawn → kind 'dom': the client renders it via the CustomEvent channel.
  }))

  return () => {
    for (const dispose of disposers.splice(0)) dispose()
  }
}
