/**
 * dsh-web-terminal — host half. Mounts the local PTY terminal bridge
 * (node-pty + WebSocket), the /api/dsh-web-terminal route family, the
 * `webTerminal` TUI-view registry service, and the demo TUI adapter views.
 * The browser half (./client) renders the hideable split-screen dock.
 */

import type { Context } from '@deepseek-ai/cordis'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import z from 'schemastery'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { makeRoutes } from './routes.ts'
import { WebTerminalRegistry } from './tui-registry.ts'
import { mountExampleViews } from './examples/tui-adapter-host.ts'

/** Stable cordis plugin name. */
export const name = 'web-terminal'

/** Services required before the surfaces mount. */
export const inject = ['webServer']

/** Settings namespace of the terminal capability (same spelling as the browser half). */
export const WT_SETTINGS_NAMESPACE = settingsNamespace('dsh-web-terminal')

/** Plugin config. */
export interface Config {
  /** Master switch for the plugin (routes, service, examples). */
  enabled?: boolean
  /** Mount the demo TUI adapter views (two example views). */
  demoViews?: boolean
}

export const Config: z<Config> = z.object({
  enabled: z.boolean().default(true),
  demoViews: z.boolean().default(true),
})

const DEFAULT_ENABLED = true
const DEFAULT_DEMO_VIEWS = true

/**
 * Mount the terminal routes + registry service.
 * @param ctx - host plugin context carrying webServer.
 * @param config - resolved plugin config.
 */
export function apply(ctx: Context, config?: Config): void {
  let current: () => Config = () => config ?? {}
  const resolve = (): Config => ({
    enabled: current().enabled ?? DEFAULT_ENABLED,
    demoViews: current().demoViews ?? DEFAULT_DEMO_VIEWS,
  })

  const registry = new WebTerminalRegistry()

  // The plugin surface itself: `ctx.get('webTerminal')?.registerView(...)` is
  // the extension seam other plugins use to add TUI views to the dock.
  let disposeService: (() => void) | undefined
  let disposeRoutes: (() => void) | undefined
  let disposeExamples: (() => void) | undefined

  const sync = (): void => {
    if (disposeService !== undefined) { disposeService(); disposeService = undefined }
    if (disposeRoutes !== undefined) { disposeRoutes(); disposeRoutes = undefined }
    if (disposeExamples !== undefined) { disposeExamples(); disposeExamples = undefined }
    if (!resolve().enabled) return

    disposeService = ctx.effect(
      () => ctx.provide('webTerminal', {
        registerView: (def: Parameters<WebTerminalRegistry['registerView']>[0]) => registry.registerView(def),
        list: () => registry.list(),
      }),
      'dsh-web-terminal: webTerminal service',
    )

    const { routes, upgrade } = makeRoutes(registry)
    disposeRoutes = ctx.effect(
      () => {
        const disposers = routes.map((route) => ctx.webServer.register(route))
        const upgradeDisposer = ctx.webServer.registerUpgrade(upgrade)
        return () => {
          for (const dispose of disposers) dispose()
          upgradeDisposer()
        }
      },
      'dsh-web-terminal: routes',
    )

    if (resolve().demoViews) {
      disposeExamples = mountExampleViews(registry)
    }
  }

  try {
    installSettingsSection(ctx, WT_SETTINGS_NAMESPACE, Config, config ?? {}, {
      setSource: (source) => {
        current = source
        sync()
      },
      onChange: sync,
    })
  } catch (error) {
    // Settings surface unavailable — the plugin still works with defaults.
    console.warn('[dsh-web-terminal] settings section skipped:', error)
  }

  sync()
}
