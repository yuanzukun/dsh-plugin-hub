/**
 * dsh-web-terminal — host half. Mounts the local PTY terminal bridge
 * (node-pty + WebSocket), the /api/dsh-web-terminal route family, the
 * `webTerminal` TUI-view registry service, and the demo TUI adapter views.
 * The browser half (./client) renders the bottom-band dock.
 *
 * 0.2 note: the settings page is generated from this plugin's `Config` schema
 * by the running Harness, so the host half no longer imports dsh-settings.
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import type {} from '@deepseek-ai/dsh-host-webserver'
import { makeRoutes } from './routes.ts'
import { WebTerminalRegistry } from './tui-registry.ts'
import { mountExampleViews } from './examples/tui-adapter-host.ts'

/** Stable cordis plugin name. */
export const name = 'web-terminal'

/** Services required before the surfaces mount. */
export const inject = ['webServer']

/** Plugin config. */
export interface Config {
  /** Master switch for the plugin (routes, service, examples). */
  enabled?: boolean
  /** Mount the demo TUI adapter views (two example views). */
  demoViews?: boolean
}

export const Config: z<Config> = z.object({
  enabled: z.boolean().default(true),
  demoViews: z.boolean().default(true),
})

const DEFAULT_ENABLED = true
const DEFAULT_DEMO_VIEWS = true

/**
 * Mount the terminal routes + registry service.
 * @param ctx - host plugin context carrying webServer.
 * @param config - resolved plugin config.
 */
export function apply(ctx: Context, config?: Config): void {
  const enabled = config?.enabled ?? DEFAULT_ENABLED
  const demoViews = config?.demoViews ?? DEFAULT_DEMO_VIEWS

  if (!enabled) return

  const registry = new WebTerminalRegistry()

  // The plugin surface itself: `ctx.get('webTerminal')?.registerView(...)` is
  // the extension seam other plugins use to add TUI views to the dock.
  ctx.effect(
    () => ctx.provide('webTerminal', {
      registerView: (def: Parameters<WebTerminalRegistry['registerView']>[0]) => registry.registerView(def),
      list: () => registry.list(),
    }),
    'dsh-web-terminal: webTerminal service',
  )

  const { routes, upgrade } = makeRoutes(registry)
  ctx.effect(
    () => {
      const disposers = routes.map((route) => ctx.webServer.register(route))
      const upgradeDisposer = ctx.webServer.registerUpgrade(upgrade)
      return () => {
        for (const dispose of disposers) dispose()
        upgradeDisposer()
      }
    },
    'dsh-web-terminal: routes',
  )

  if (demoViews) {
    mountExampleViews(registry)
  }
}
