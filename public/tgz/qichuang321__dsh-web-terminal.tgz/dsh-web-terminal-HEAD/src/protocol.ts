/**
 * Shared wire protocol for the dsh-web-terminal dock — imported by BOTH the
 * host half (src/routes.ts) and the browser half (src/client/api.ts).
 * Only lossless JSON crosses the WebSocket; keep every frame shape here so
 * the two halves can never drift apart.
 */

/** Route family (same origin; the webserver serves these paths). */
export const WT_API = {
  /** GET → { views: WebTerminalViewSummary[] } (loopback-fenced). */
  views: '/api/dsh-web-terminal/views',
  /** WS upgrade: /api/dsh-web-terminal/session?view=<id>&cols=&rows= (loopback-fenced). */
  session: '/api/dsh-web-terminal/session',
  /** POST /api/dsh-web-terminal/diag — client→host diagnostics log (loopback-fenced, dev aid). */
  diag: '/api/dsh-web-terminal/diag',
} as const

/** Default shell view id (no plugin view requested → plain local shell). */
export const SHELL_VIEW_ID = 'shell'

/** Backpressure thresholds (mirror dsh-ssh routes.ts:36-39). */
export const BACKPRESSURE_HIGH_WATER = 1024 * 1024
export const BACKPRESSURE_LOW_WATER = 512 * 1024

/** A view as advertised by the host /views route. */
export interface WebTerminalViewSummary {
  id: string
  label: string
  icon?: string
  order: number
  /** 'pty' when the host spawns a child for it, 'dom' when the client renders it. */
  kind: 'pty' | 'dom'
}

/** Server → client frames. */
export type ServerFrame =
  | { type: 'ready'; view: string; cols: number; rows: number }
  | { type: 'output'; data: string }
  | { type: 'title'; title?: string }
  | { type: 'exit'; code: number | null; error?: string }

/** Client → server frames. */
export type ClientFrame =
  | { type: 'input'; data: string }
  | { type: 'resize'; cols: number; rows: number }

/** Clamp a column count to a sane PTY range. */
export function clampCols(value: number | undefined, fallback = 80): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback
  return Math.max(2, Math.min(1000, Math.floor(value)))
}

/** Clamp a row count to a sane PTY range. */
export function clampRows(value: number | undefined, fallback = 24): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) return fallback
  return Math.max(1, Math.min(500, Math.floor(value)))
}

/** Parse a client frame, returning null for anything not shaped like input/resize. */
export function parseClientFrame(raw: unknown): ClientFrame | null {
  if (typeof raw !== 'object' || raw === null) return null
  const frame = raw as Record<string, unknown>
  if (frame.type === 'input' && typeof frame.data === 'string') {
    return { type: 'input', data: frame.data }
  }
  if (frame.type === 'resize') {
    return {
      type: 'resize',
      cols: clampCols(typeof frame.cols === 'number' ? frame.cols : undefined),
      rows: clampRows(typeof frame.rows === 'number' ? frame.rows : undefined),
    }
  }
  return null
}
