/**
 * The terminal dock — the split-screen centerpiece.
 *
 * Mounts a React root inside the center column ([data-pane="conversation"],
 * dsh-ssh mount.tsx precedent) and splits that column: when visible, the chat
 * stays mounted above and the terminal dock takes the bottom band. Hiding is
 * a data attribute on <html> (dsh-ssh precedent) — the dock node, the xterm
 * instance and the PTY session all survive hide/show, so nothing is torn down
 * on toggle (VS Code behavior).
 */

import { createRoot, type Root } from 'react-dom/client'
import { Component, useEffect, useRef, useState, useSyncExternalStore, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react'
import { Terminal } from '@xterm/xterm'
import { FitAddon } from '@xterm/addon-fit'
import { TerminalConnection, fetchViews, diag } from './api.ts'
import { SHELL_VIEW_ID, type WebTerminalViewSummary } from '../protocol.ts'
import {
  TUI_EVENTS,
  onTuiEvent,
  dispatchReady,
  dispatchActivate,
  dispatchDeactivate,
  dispatchViewState,
  type TuiViewRegistration,
} from './tui-channel.ts'
// CSS is embedded as TS string modules (tsdown/rolldown cannot resolve
// '?raw'); regenerate with `node scripts/gen-css.mjs` after editing
// styles.css / upgrading @xterm/xterm.
import { XTERM_CSS } from './xterm-css.ts'
import { DOCK_CSS } from './dock-css.ts'

export const WT_DOCK_SELECTOR = '[data-dsh-web-terminal-dock]'
// The current shell (0.1.0-rc.6) does NOT emit data-pane attributes — its
// columns are CSS-module classes: centerCol / sidebarCol / detailsCol.
// Match both the legacy attribute (dsh-ssh era) and the live class.
const CONVERSATION_COLUMN_SELECTOR = '[data-pane="conversation"], [class*="centerCol"]'
const VISIBLE_ATTR = 'data-wt-visible'
const STORAGE_KEY = 'dsh.webTerminal.v1'
const DEFAULT_DOCK_SIZE = 300

/** ------------------------------------------------------------------ store */
interface DockState {
  visible: boolean
  activeView: string
  /** Views from GET /views (shell implicit + host-registered). */
  views: WebTerminalViewSummary[]
  /** Views registered live by adapters over the CustomEvent channel. */
  customViews: TuiViewRegistration[]
  dockSize: number
}

function loadPersisted(): Partial<DockState> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw === null) return {}
    const parsed = JSON.parse(raw) as Partial<DockState>
    return typeof parsed === 'object' && parsed !== null ? parsed : {}
  } catch {
    return {}
  }
}

const persisted = loadPersisted()
let state: DockState = {
  visible: persisted.visible === true,
  activeView: SHELL_VIEW_ID,
  views: [],
  customViews: [],
  dockSize: typeof persisted.dockSize === 'number' && persisted.dockSize > 120 ? persisted.dockSize : DEFAULT_DOCK_SIZE,
}
const listeners = new Set<() => void>()

function setState(patch: Partial<DockState>): void {
  state = { ...state, ...patch }
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ visible: state.visible, dockSize: state.dockSize }))
  } catch {
    // storage unavailable (private mode) — fine
  }
  // The html attribute is the single source of truth for CSS visibility.
  if (patch.visible !== undefined) {
    if (state.visible) document.documentElement.setAttribute(VISIBLE_ATTR, '1')
    else document.documentElement.removeAttribute(VISIBLE_ATTR)
  }
  // Keep the pane's bottom padding (CSS var) in sync with the dock height —
  // the split padding and the dock must always reference the same value.
  if (patch.dockSize !== undefined) {
    applyDockSizeVar()
  }
  for (const listener of listeners) listener()
}

/** Write --wt-dock-size onto the conversation pane so padding+dock stay aligned. */
function applyDockSizeVar(): void {
  const pane = document.querySelector<HTMLElement>(CONVERSATION_COLUMN_SELECTOR)
  if (pane !== null) pane.style.setProperty('--wt-dock-size', `${state.dockSize}px`)
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

function getState(): DockState {
  return state
}

/** Hook for React components (the header toggle button). */
export function useDockStore(): DockState {
  return useSyncExternalStore(subscribe, getState)
}

/** Toggle dock visibility (also used by the Ctrl+` shortcut). */
export function toggleDock(): void {
  const next = !state.visible
  console.log('[web-terminal] toggle →', next)
  diag(`toggle → ${next}`)
  setState({ visible: next })
}

/** ----------------------------------------------------------------- mount */
let mountWarned = false

/** Catches render/effect errors inside the dock and reports them via diag. */
class DockErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state: { error: Error | null } = { error: null }

  static getDerivedStateFromError(error: Error): { error: Error | null } {
    return { error }
  }

  componentDidCatch(error: Error): void {
    diag('Dock render error: ' + error.message)
    console.error('[web-terminal] Dock render error', error)
  }

  render(): ReactNode {
    if (this.state.error !== null) {
      return (
        <div className="wt-dock wt-dock-error">
          <div className="wt-dock-tabbar"><span>[web-terminal]</span></div>
          <div className="wt-dock-body" style={{ padding: 16, fontSize: 13 }}>
            dock failed: {this.state.error.message}
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

export function mountDock(): () => void {
  let root: Root | undefined
  let container: HTMLDivElement | undefined

  const ensure = (): void => {
    const column = document.querySelector<HTMLElement>(CONVERSATION_COLUMN_SELECTOR)
    // Migrate a body-fallback dock into the column once it appears.
    if (container !== undefined && container.isConnected && column !== null && container.parentElement !== column) {
      container.className = 'wt-dock-root'
      column.appendChild(container)
      diag('dock migrated into column')
    }
    if (container !== undefined) {
      if (container.isConnected) return
      root?.unmount()
      root = undefined
      container.remove()
      container = undefined
    }
    const target = column ?? document.body
    container = document.createElement('div')
    container.dataset.dshWebTerminalDock = ''
    container.className = column !== null ? 'wt-dock-root' : 'wt-dock-root wt-dock-root-fixed'
    target.appendChild(container)
    root = createRoot(container)
    root.render(<DockErrorBoundary><Dock /></DockErrorBoundary>)
    if (column !== null) {
      console.log('[web-terminal] dock mounted into', column.tagName, column.className)
      diag(`dock mounted into ${column.tagName}.${String(column.className).slice(0, 60)}`)
    } else {
      if (!mountWarned) {
        mountWarned = true
        console.warn('[web-terminal] conversation column not found, using body fallback:', CONVERSATION_COLUMN_SELECTOR)
      }
      diag('dock mounted into BODY FALLBACK (column selector: ' + CONVERSATION_COLUMN_SELECTOR + ')')
    }
  }

  // The frame mounts after boot settlement; watch for the column's arrival
  // and self-heal when a React re-render displaces the appended node.
  const waitObserver = new MutationObserver(() => { ensure() })
  waitObserver.observe(document.body, { childList: true, subtree: true })

  ensure()
  // Reflect persisted visibility on <html>.
  if (state.visible) document.documentElement.setAttribute(VISIBLE_ATTR, '1')
  else document.documentElement.removeAttribute(VISIBLE_ATTR)
  applyDockSizeVar()

  return () => {
    waitObserver.disconnect()
    document.documentElement.removeAttribute(VISIBLE_ATTR)
    root?.unmount()
    root = undefined
    container?.remove()
    container = undefined
  }
}

/** A view as rendered in the tab bar. */
interface DockView {
  id: string
  label: string
  icon?: string
  order: number
  kind: 'pty' | 'dom'
}

/** ------------------------------------------------------------------ dock */
function Dock() {
  const { visible, activeView, views, customViews, dockSize } = useDockStore()
  const terminalHostRef = useRef<HTMLDivElement>(null)
  const domHostRef = useRef<HTMLDivElement>(null)
  const termRef = useRef<Terminal | null>(null)
  const fitRef = useRef<FitAddon | null>(null)
  const connRef = useRef<TerminalConnection | null>(null)
  // Tracks the view the CURRENT session effect belongs to; updated inside the
  // effect so the previous view is always the pre-switch one.
  const activeViewRef = useRef(activeView)
  const [hostViews, setHostViews] = useState<WebTerminalViewSummary[]>(views)

  // Merge host-registered views with live adapter registrations.
  const hostMapped: DockView[] = hostViews.map((view) => ({
    id: view.id, label: view.label, icon: view.icon, order: view.order, kind: view.kind,
  }))
  const customMapped: DockView[] = customViews
    .filter((view) => !hostViews.some((host) => host.id === view.id))
    .map((view) => ({
      id: view.id, label: view.label, icon: view.icon, order: view.order ?? 100, kind: view.kind,
    }))
  const shellView: DockView = { id: SHELL_VIEW_ID, label: 'Shell', order: 0, kind: 'pty' }
  const allViews: DockView[] = [shellView, ...hostMapped, ...customMapped]
    .sort((a, b) => a.order - b.order || (a.id < b.id ? -1 : 1))

  // ---------------------------------------------------------- lifecycle
  useEffect(() => {
    let disposed = false
    const disposers: Array<() => void> = []

    // Inject the dock + xterm styles once (removed with the dock).
    const styleEl = document.createElement('style')
    styleEl.dataset.dshWebTerminalCss = ''
    styleEl.textContent = XTERM_CSS + '\n' + DOCK_CSS
    document.head.appendChild(styleEl)
    disposers.push(() => styleEl.remove())
    console.log('[web-terminal] styles injected')
    diag('styles injected')

    // Pull host-registered views (shell + registerView views).
    void fetchViews().then((list) => {
      if (!disposed) setHostViews(list)
    }).catch(() => { /* plugin host half not mounted yet — adapters will re-register */ })

    // TUI adapter channel: live register/unregister + ready self-heal.
    disposers.push(onTuiEvent(TUI_EVENTS.register, (event) => {
      const detail = event.detail as TuiViewRegistration
      if (detail && typeof detail.id === 'string' && typeof detail.label === 'string') {
        setState({ customViews: [...state.customViews.filter((v) => v.id !== detail.id), detail] })
      }
    }))
    disposers.push(onTuiEvent(TUI_EVENTS.unregister, (event) => {
      const id = (event.detail as { id?: string }).id
      if (typeof id === 'string') {
        setState({ customViews: state.customViews.filter((v) => v.id !== id) })
        if (state.activeView === id) setState({ activeView: SHELL_VIEW_ID })
      }
    }))
    // The dock is live: let adapters (re-)register (self-heal).
    dispatchReady()

    return () => {
      disposed = true
      for (const dispose of disposers.splice(0)) dispose()
      connRef.current?.close()
      connRef.current = null
      termRef.current?.dispose()
      termRef.current = null
      fitRef.current = null
    }
  }, [])

  // ------------------------------------------------------ terminal session
  // (Re)open the PTY session when the dock becomes visible or the active view
  // changes; close it when hidden. Full try/catch + diag so a failure inside
  // xterm/WebSocket init is never silent.
  useEffect(() => {
    const host = terminalHostRef.current
    if (host === null) {
      diag('session: terminal host ref null')
      return
    }
    const previousView = activeViewRef.current
    activeViewRef.current = activeView

    // Close the previous session unconditionally.
    connRef.current?.close()
    connRef.current = null
    const prev = allViews.find((entry) => entry.id === previousView)
    if (prev !== undefined && prev.kind === 'dom') {
      dispatchDeactivate(previousView)
    }

    if (!visible) return
    diag(`session open av=${activeView} vis=1`)

    try {
      // Lazy-create the xterm instance on first show.
      if (termRef.current === null) {
        const term = new Terminal({
          convertEol: false,
          cursorBlink: true,
          fontSize: 13,
          fontFamily: 'Consolas, "Cascadia Mono", monospace',
          scrollback: 5000,
        })
        const fit = new FitAddon()
        term.loadAddon(fit)
        term.open(host)
        termRef.current = term
        fitRef.current = fit
        diag('xterm created')
      }
      const term = termRef.current
      const fit = fitRef.current
      if (term === null || fit === null) return

      const view = allViews.find((entry) => entry.id === activeView)
      if (view !== undefined && view.kind === 'dom') {
        // DOM view: hand the container to the adapter.
        term.element?.classList.add('wt-hidden')
        const domHost = domHostRef.current
        if (domHost !== null) {
          dispatchActivate(activeView, domHost)
          dispatchViewState(activeView, 'running')
        }
        return
      }

      term.element?.classList.remove('wt-hidden')
      const cols = Math.max(2, Math.floor((host.clientWidth ?? 800) / 9))
      const rows = Math.max(1, Math.floor((host.clientHeight ?? 300) / 19))
      const conn = new TerminalConnection(activeView, cols, rows, {
        onReady: (viewId, c, r) => {
          fit.fit()
          dispatchViewState(viewId, 'running')
        },
        onOutput: (data) => term.write(data),
        onTitle: (title) => {
          // Keep the tab label in sync with the view's title frame.
          setState({ customViews: state.customViews.map((v) => v.id === activeViewRef.current ? { ...v, label: title } : v) })
        },
        onExit: (code, error) => {
          dispatchViewState(activeViewRef.current, code === null ? 'error' : 'exit', code, error)
          if (error !== undefined) term.write(`\r\n\x1b[31m[web-terminal] session ended: ${error}\x1b[0m\r\n`)
        },
      })
      connRef.current = conn
      diag('pty connection opened: ' + activeView)

      const dataDisposable = term.onData((data) => conn.send(data))

      // PTY resize is the expensive path for full-screen TUIs (ink redraws
      // the whole screen on every SIGWINCH). Debounce ALL sources (fit, RO,
      // xterm onResize) into a single 250ms trailing resize, and only send it
      // when the cell size actually changed. This kills the resize→redraw→
      // flicker feedback loop at small dock heights.
      let rafId = 0
      let resizeTimer: number | undefined
      let lastCols = 0
      let lastRows = 0
      const sendResize = (cols: number, rows: number): void => {
        if (resizeTimer !== undefined) clearTimeout(resizeTimer)
        resizeTimer = window.setTimeout(() => {
          resizeTimer = undefined
          if (connRef.current === null) return
          if (cols === lastCols && rows === lastRows) return
          lastCols = cols
          lastRows = rows
          connRef.current.resize(cols, rows)
        }, 250)
      }
      const resizeDisposable = term.onResize(({ cols: c, rows: r }) => sendResize(c, r))

      const fitNow = (): void => {
        if (rafId !== 0) return
        rafId = requestAnimationFrame(() => {
          rafId = 0
          try {
            fit.fit()
            sendResize(term.cols, term.rows)
          } catch {
            // hidden element — fit will run again on show
          }
        })
      }
      fitNow()
      const ro = new ResizeObserver(fitNow)
      ro.observe(host)

      return () => {
        if (rafId !== 0) cancelAnimationFrame(rafId)
        if (resizeTimer !== undefined) clearTimeout(resizeTimer)
        ro.disconnect()
        dataDisposable.dispose()
        resizeDisposable.dispose()
        connRef.current?.close()
        connRef.current = null
      }
    } catch (error) {
      diag('session error: ' + (error instanceof Error ? error.message : String(error)))
      console.error('[web-terminal] session error', error)
      connRef.current?.close()
      connRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeView, visible])

  // Re-fit when the dock becomes visible again.
  useEffect(() => {
    if (visible) {
      requestAnimationFrame(() => {
        try { fitRef.current?.fit() } catch { /* hidden */ }
      })
    }
  }, [visible])

  // ----------------------------------------------------------- resize drag
  const onPointerDown = (event: ReactPointerEvent<HTMLDivElement>): void => {
    const target = event.currentTarget
    target.setPointerCapture(event.pointerId)
    const startY = event.clientY
    const startSize = state.dockSize
    const onMove = (move: PointerEvent): void => {
      const next = startSize + (startY - move.clientY)
      setDockSize(next)
    }
    const onUp = (): void => {
      target.removeEventListener('pointermove', onMove)
      target.removeEventListener('pointerup', onUp)
      try { target.releasePointerCapture(event.pointerId) } catch { /* released */ }
    }
    target.addEventListener('pointermove', onMove)
    target.addEventListener('pointerup', onUp)
  }

  return (
    <div className="wt-dock" style={{ height: dockSize }}>
      <div className="wt-dock-tabbar">
        {allViews.map((view) => (
          <button
            key={view.id}
            type="button"
            className={'wt-dock-tab' + (view.id === activeView ? ' wt-dock-tab-active' : '')}
            data-view={view.id}
            onClick={() => {
              if (view.id !== activeView) {
                setState({ activeView: view.id })
              }
            }}
          >
            {view.label}
          </button>
        ))}
        <button type="button" className="wt-dock-close" title="Hide terminal (Ctrl+`)" onClick={() => toggleDock()}>
          ×
        </button>
      </div>
      <div className="wt-dock-body">
        <div ref={terminalHostRef} className="wt-dock-terminal" />
        <div ref={domHostRef} className="wt-dock-dom wt-hidden" />
      </div>
      <div className="wt-dock-resize" onPointerDown={onPointerDown} />
    </div>
  )
}

function setDockSize(next: number): void {
  const clamped = Math.max(120, Math.min(900, next))
  setState({ dockSize: clamped })
}
