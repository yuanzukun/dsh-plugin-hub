/**
 * The terminal dock — a full-width bottom band registered into `shell.bottom`.
 *
 * The shell owns the geometry: the band's rendered height reduces the three
 * columns' available height, so showing the dock is a real split-screen and
 * hiding it (height 0 / display none) gives the space back — no DOM surgery,
 * no padding hacks, no body fallback.
 *
 * Hide/show keeps the xterm instance AND the PTY session alive (VS Code
 * behavior): the component stays mounted, only its box collapses.
 */

import { Component, useEffect, useRef, useState, useSyncExternalStore, type PointerEvent as ReactPointerEvent, type ReactNode } from 'react'
import { Terminal } from '@xterm/xterm'
import { FitAddon } from '@xterm/addon-fit'
import { TerminalConnection, fetchViews, diag } from './api.ts'
import { SHELL_VIEW_ID, type WebTerminalViewSummary } from '../protocol.ts'
import {
  TUI_EVENTS,
  onTuiEvent,
  dispatchReady,
  dispatchActivate,
  dispatchDeactivate,
  dispatchViewState,
  type TuiViewRegistration,
} from './tui-channel.ts'
// CSS is embedded as TS string modules (tsdown/rolldown cannot resolve
// '?raw'); regenerate with `node scripts/gen-css.mjs` after editing
// styles.css / upgrading @xterm/xterm.
import { XTERM_CSS } from './xterm-css.ts'
import { DOCK_CSS } from './dock-css.ts'

const STORAGE_KEY = 'dsh.webTerminal.v1'
const DEFAULT_DOCK_SIZE = 300

/** ------------------------------------------------------------------ store */
interface DockState {
  visible: boolean
  activeView: string
  /** Views from GET /views (shell implicit + host-registered). */
  views: WebTerminalViewSummary[]
  /** Views registered live by adapters over the CustomEvent channel. */
  customViews: TuiViewRegistration[]
  dockSize: number
}

function loadPersisted(): Partial<DockState> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw === null) return {}
    const parsed = JSON.parse(raw) as Partial<DockState>
    return typeof parsed === 'object' && parsed !== null ? parsed : {}
  } catch {
    return {}
  }
}

const persisted = loadPersisted()
let state: DockState = {
  visible: persisted.visible === true,
  activeView: SHELL_VIEW_ID,
  views: [],
  customViews: [],
  dockSize: typeof persisted.dockSize === 'number' && persisted.dockSize > 120 ? persisted.dockSize : DEFAULT_DOCK_SIZE,
}
const listeners = new Set<() => void>()

function setState(patch: Partial<DockState>): void {
  state = { ...state, ...patch }
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ visible: state.visible, dockSize: state.dockSize }))
  } catch {
    // storage unavailable (private mode) — fine
  }
  for (const listener of listeners) listener()
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener)
  return () => listeners.delete(listener)
}

function getState(): DockState {
  return state
}

/** Hook for React components (clicking the dock the toggle button drives). */
export function useDockStore(): DockState {
  return useSyncExternalStore(subscribe, getState)
}

/** Toggle dock visibility (also used by the Ctrl+` shortcut). */
export function toggleDock(): void {
  const next = !state.visible
  diag(`toggle → ${next}`)
  setState({ visible: next })
}

/** Catches render/effect errors inside the dock and reports them via diag. */
class DockErrorBoundary extends Component<{ children: ReactNode }, { error: Error | null }> {
  state: { error: Error | null } = { error: null }

  static getDerivedStateFromError(error: Error): { error: Error | null } {
    return { error }
  }

  componentDidCatch(error: Error): void {
    diag('Dock render error: ' + error.message)
    console.error('[web-terminal] Dock render error', error)
  }

  render(): ReactNode {
    if (this.state.error !== null) {
      return (
        <div className="wt-dock wt-dock-error">
          <div className="wt-dock-tabbar"><span>[web-terminal]</span></div>
          <div className="wt-dock-body" style={{ padding: 16, fontSize: 13 }}>
            dock failed: {this.state.error.message}
          </div>
        </div>
      )
    }
    return this.props.children
  }
}

/** A view as rendered in the tab bar. */
interface DockView {
  id: string
  label: string
  icon?: string
  order: number
  kind: 'pty' | 'dom'
}

/** ------------------------------------------------------------------ dock */
function DockInner() {
  const { visible, activeView, views, customViews, dockSize } = useDockStore()
  const terminalHostRef = useRef<HTMLDivElement>(null)
  const domHostRef = useRef<HTMLDivElement>(null)
  const termRef = useRef<Terminal | null>(null)
  const fitRef = useRef<FitAddon | null>(null)
  const connRef = useRef<TerminalConnection | null>(null)
  // Tracks the view the CURRENT session effect belongs to; updated inside the
  // effect so the previous view is always the pre-switch one.
  const activeViewRef = useRef(activeView)
  const [hostViews, setHostViews] = useState<WebTerminalViewSummary[]>(views)

  // Merge host-registered views with live adapter registrations.
  const hostMapped: DockView[] = hostViews.map((view) => ({
    id: view.id, label: view.label, icon: view.icon, order: view.order, kind: view.kind,
  }))
  const customMapped: DockView[] = customViews
    .filter((view) => !hostViews.some((host) => host.id === view.id))
    .map((view) => ({
      id: view.id, label: view.label, icon: view.icon, order: view.order ?? 100, kind: view.kind,
    }))
  const shellView: DockView = { id: SHELL_VIEW_ID, label: 'Shell', order: 0, kind: 'pty' }
  const allViews: DockView[] = [shellView, ...hostMapped, ...customMapped]
    .sort((a, b) => a.order - b.order || (a.id < b.id ? -1 : 1))

  // ---------------------------------------------------------- lifecycle
  useEffect(() => {
    let disposed = false
    const disposers: Array<() => void> = []

    // Inject the dock + xterm styles once (removed with the dock).
    const styleEl = document.createElement('style')
    styleEl.dataset.dshWebTerminalCss = ''
    styleEl.textContent = XTERM_CSS + '\n' + DOCK_CSS
    document.head.appendChild(styleEl)
    disposers.push(() => styleEl.remove())
    diag('styles injected')

    // Pull host-registered views (shell + registerView views).
    void fetchViews().then((list) => {
      if (!disposed) setHostViews(list)
    }).catch(() => { /* plugin host half not mounted yet — adapters will re-register */ })

    // TUI adapter channel: live register/unregister + ready self-heal.
    disposers.push(onTuiEvent(TUI_EVENTS.register, (event) => {
      const detail = event.detail as TuiViewRegistration
      if (detail && typeof detail.id === 'string' && typeof detail.label === 'string') {
        setState({ customViews: [...state.customViews.filter((v) => v.id !== detail.id), detail] })
      }
    }))
    disposers.push(onTuiEvent(TUI_EVENTS.unregister, (event) => {
      const id = (event.detail as { id?: string }).id
      if (typeof id === 'string') {
        setState({ customViews: state.customViews.filter((v) => v.id !== id) })
        if (state.activeView === id) setState({ activeView: SHELL_VIEW_ID })
      }
    }))
    // The dock is live: let adapters (re-)register (self-heal).
    dispatchReady()

    return () => {
      disposed = true
      for (const dispose of disposers.splice(0)) dispose()
      connRef.current?.close()
      connRef.current = null
      termRef.current?.dispose()
      termRef.current = null
      fitRef.current = null
    }
  }, [])

  // ------------------------------------------------------ terminal session
  // Open the PTY session on first show and on view switches; a hide keeps the
  // session alive (the component stays mounted, the box collapses). Full
  // try/catch + diag so a failure inside xterm/WebSocket init is never silent.
  useEffect(() => {
    if (!visible) return
    const host = terminalHostRef.current
    if (host === null) {
      diag('session: terminal host ref null')
      return
    }
    const previousView = activeViewRef.current
    activeViewRef.current = activeView

    // Reuse a live connection for the same view (hide → show round trip).
    if (connRef.current !== null && previousView === activeView) return

    // Close the previous session unconditionally.
    connRef.current?.close()
    connRef.current = null
    const prev = allViews.find((entry) => entry.id === previousView)
    if (prev !== undefined && prev.kind === 'dom') {
      dispatchDeactivate(previousView)
    }

    diag(`session open av=${activeView}`)

    try {
      // Lazy-create the xterm instance on first show.
      if (termRef.current === null) {
        const term = new Terminal({
          convertEol: false,
          cursorBlink: true,
          fontSize: 13,
          fontFamily: 'Consolas, "Cascadia Mono", monospace',
          scrollback: 5000,
        })
        const fit = new FitAddon()
        term.loadAddon(fit)
        term.open(host)
        termRef.current = term
        fitRef.current = fit
        diag('xterm created')
      }
      const term = termRef.current
      const fit = fitRef.current
      if (term === null || fit === null) return

      const view = allViews.find((entry) => entry.id === activeView)
      if (view !== undefined && view.kind === 'dom') {
        // DOM view: hand the container to the adapter.
        term.element?.classList.add('wt-hidden')
        const domHost = domHostRef.current
        if (domHost !== null) {
          domHost.classList.remove('wt-hidden')
          dispatchActivate(activeView, domHost)
          dispatchViewState(activeView, 'running')
        }
        return
      }
      domHostRef.current?.classList.add('wt-hidden')
      term.element?.classList.remove('wt-hidden')
      const cols = Math.max(2, Math.floor((host.clientWidth ?? 800) / 9))
      const rows = Math.max(1, Math.floor((host.clientHeight ?? 300) / 19))
      const conn = new TerminalConnection(activeView, cols, rows, {
        onReady: (viewId, _c, _r) => {
          fit.fit()
          dispatchViewState(viewId, 'running')
        },
        onOutput: (data) => term.write(data),
        onTitle: (title) => {
          // Keep the tab label in sync with the view's title frame.
          setState({ customViews: state.customViews.map((v) => v.id === activeViewRef.current ? { ...v, label: title } : v) })
        },
        onExit: (code, error) => {
          dispatchViewState(activeViewRef.current, code === null ? 'error' : 'exit', code, error)
          if (error !== undefined) term.write(`\r\n\x1b[31m[web-terminal] session ended: ${error}\x1b[0m\r\n`)
        },
      })
      connRef.current = conn
      diag('pty connection opened: ' + activeView)

      const dataDisposable = term.onData((data) => conn.send(data))

      // PTY resize is the expensive path for full-screen TUIs (ink redraws
      // the whole screen on every SIGWINCH). Debounce ALL sources (fit, RO,
      // xterm onResize) into a single 250ms trailing resize, and only send it
      // when the cell size actually changed.
      let rafId = 0
      let resizeTimer: number | undefined
      let lastCols = 0
      let lastRows = 0
      const sendResize = (cols: number, rows: number): void => {
        if (resizeTimer !== undefined) clearTimeout(resizeTimer)
        resizeTimer = window.setTimeout(() => {
          resizeTimer = undefined
          if (connRef.current === null) return
          if (cols === lastCols && rows === lastRows) return
          lastCols = cols
          lastRows = rows
          connRef.current.resize(cols, rows)
        }, 250)
      }
      const resizeDisposable = term.onResize(({ cols: c, rows: r }) => sendResize(c, r))

      const fitNow = (): void => {
        if (rafId !== 0) return
        rafId = requestAnimationFrame(() => {
          rafId = 0
          try {
            fit.fit()
            sendResize(term.cols, term.rows)
          } catch {
            // hidden element — fit will run again on show
          }
        })
      }
      fitNow()
      const ro = new ResizeObserver(fitNow)
      ro.observe(host)

      return () => {
        if (rafId !== 0) cancelAnimationFrame(rafId)
        if (resizeTimer !== undefined) clearTimeout(resizeTimer)
        ro.disconnect()
        dataDisposable.dispose()
        resizeDisposable.dispose()
        // The connection itself survives a hide; only a view switch or unmount
        // closes it here.
        conn.close()
        if (connRef.current === conn) connRef.current = null
      }
    } catch (error) {
      diag('session error: ' + (error instanceof Error ? error.message : String(error)))
      console.error('[web-terminal] session error', error)
      connRef.current?.close()
      connRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeView, visible])

  // Re-fit when the dock becomes visible again.
  useEffect(() => {
    if (visible) {
      requestAnimationFrame(() => {
        try { fitRef.current?.fit() } catch { /* hidden */ }
      })
    }
  }, [visible])

  // ----------------------------------------------------------- resize drag
  const onPointerDown = (event: ReactPointerEvent<HTMLDivElement>): void => {
    const target = event.currentTarget
    target.setPointerCapture(event.pointerId)
    const startY = event.clientY
    const startSize = state.dockSize
    const onMove = (move: PointerEvent): void => {
      const next = startSize + (startY - move.clientY)
      setDockSize(next)
    }
    const onUp = (): void => {
      target.removeEventListener('pointermove', onMove)
      target.removeEventListener('pointerup', onUp)
      try { target.releasePointerCapture(event.pointerId) } catch { /* released */ }
    }
    target.addEventListener('pointermove', onMove)
    target.addEventListener('pointerup', onUp)
  }

  if (!visible) {
    // Keep the component (and the PTY) mounted; collapse the box only.
    return <div className="wt-dock wt-dock-collapsed" aria-hidden="true" />
  }

  return (
    <div className="wt-dock" style={{ height: dockSize }}>
      <div className="wt-dock-tabbar">
        {allViews.map((view) => (
          <button
            key={view.id}
            type="button"
            className={'wt-dock-tab' + (view.id === activeView ? ' wt-dock-tab-active' : '')}
            data-view={view.id}
            onClick={() => {
              if (view.id !== activeView) {
                setState({ activeView: view.id })
              }
            }}
          >
            {view.label}
          </button>
        ))}
        <button type="button" className="wt-dock-close" title="Hide terminal (Ctrl+`)" onClick={() => toggleDock()}>
          ×
        </button>
      </div>
      <div className="wt-dock-body">
        <div ref={terminalHostRef} className="wt-dock-terminal" />
        <div ref={domHostRef} className="wt-dock-dom wt-hidden" />
      </div>
      <div className="wt-dock-resize" onPointerDown={onPointerDown} />
    </div>
  )
}

/** Slot component: the dock plus its error boundary. */
export function Dock(): ReactNode {
  return <DockErrorBoundary><DockInner /></DockErrorBoundary>
}

function setDockSize(next: number): void {
  const clamped = Math.max(120, Math.min(900, next))
  setState({ dockSize: clamped })
}
