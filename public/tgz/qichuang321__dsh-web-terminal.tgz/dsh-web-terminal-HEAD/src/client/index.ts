/**
 * Browser-half entry for dsh-web-terminal — runs inside the dsh web GUI.
 *
 * 0.2 contract: the dock is an ordinary React component registered into the
 * shell's `shell.bottom` slot (a full-width band below the three columns whose
 * height reduces the columns' available height). No DOM poking, no body
 * fallback, no createRoot. The header toggle registers into
 * `conversation.session.header.utilities`; Ctrl+` keeps working globally.
 */

import * as React from 'react'
import { Dock, useDockStore, toggleDock } from './dock.tsx'
import { diag } from './api.ts'
import { mountDemoAdapterClient } from '../examples/tui-adapter-client.ts'

/** Locale namespace this plugin owns. */
const NS = 'dsh-web-terminal'

/** Surface copy. */
const zh = {
  'toggle.label': '终端',
  'toggle.tooltip': '显示/隐藏终端 (Ctrl+`)',
  'dock.shell': 'Shell',
  'dock.close': '隐藏终端 (Ctrl+`)',
} as const

const en = {
  'toggle.label': 'Terminal',
  'toggle.tooltip': 'Toggle terminal (Ctrl+`)',
  'dock.shell': 'Shell',
  'dock.close': 'Hide terminal (Ctrl+`)',
} as const

/** Minimal shapes of the 0.2 client services this plugin consumes. */
interface SlotsService {
  inject(key: string, callback: () => () => void): () => void
  register(options: Record<string, unknown>, component: unknown): () => void
}

interface LocaleSnapshot {
  locale?: string
}

interface LocaleService {
  register(ns: string, dicts: Record<string, Record<string, string>>): () => void
  bind(ns: string): (key: string) => string
  getSnapshot(): LocaleSnapshot
  subscribe(listener: () => void): () => void
}

/** The client context surface used here (`ctx.slots`, `ctx.locale`, `ctx.effect`). */
export interface WebTerminalClientContext {
  slots: SlotsService
  locale: LocaleService
  effect(callback: () => void | (() => void), label?: string): () => void
}

/** Services the shell must provide before apply runs. */
export const inject = ['slots', 'locale']

let translate: (key: string) => string = (key) => (en as Record<string, string>)[key] ?? key

/** The header toggle button (slot renders it; hooks come from the shell React). */
function ToggleButton(): React.ReactElement {
  // Re-render when the dock opens/closes so the active state stays truthful.
  useDockStore()
  return React.createElement(
    'button',
    {
      type: 'button',
      className: 'wt-header-toggle',
      title: translate('toggle.tooltip'),
      onClick: () => { toggleDock() },
    },
    translate('toggle.label'),
  )
}

/** Stable client entry (export discipline: values stay internal). */
export function apply(ctx: WebTerminalClientContext): void {
  diag('apply')

  // Locale: dictionaries + a translator that follows the active locale.
  let t: (key: string) => string = (key) => (en as Record<string, string>)[key] ?? key
  translate = (key) => t(key)
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-web-terminal: dictionaries')
  t = ctx.locale.bind(NS)

  const disposers: Array<() => void> = []
  try {
    // 1. The dock itself: a full-width bottom band owned by the shell.
    disposers.push(ctx.slots.inject('shell.bottom', () => ctx.slots.register({
      name: 'shell.bottom',
    }, Dock)))

    // 2. Header toggle beside the session title.
    disposers.push(ctx.slots.inject('conversation.session.header.utilities', () => ctx.slots.register({
      name: 'conversation.session.header.utilities',
      id: 'web-terminal:toggle',
      order: 30,
      label: () => t('toggle.label'),
    }, ToggleButton)))

    // 3. Ctrl+` shortcut (ignored while the terminal itself has focus).
    const onKeydown = (event: KeyboardEvent): void => {
      if (!event.ctrlKey || event.key !== '`') return
      const target = event.target as HTMLElement | null
      if (target !== null && target.closest('.wt-dock') !== null) return
      event.preventDefault()
      toggleDock()
    }
    window.addEventListener('keydown', onKeydown, true)
    disposers.push(() => window.removeEventListener('keydown', onKeydown, true))

    // 4. Demo TUI adapter (proves the extension API; both demo views).
    disposers.push(mountDemoAdapterClient())
  } catch (error) {
    // A throwing apply fails the whole web boot — degrade instead.
    console.warn('[dsh-web-terminal] mount failed:', error)
    diag('mount failed: ' + (error instanceof Error ? error.message : String(error)))
  }

  ctx.effect(() => () => {
    for (const dispose of disposers.splice(0)) dispose()
  }, 'dsh-web-terminal: ui mounts')
}
