/**
 * Browser-half entry for dsh-web-terminal — runs inside the dsh web GUI.
 *
 * Mounts the split-screen terminal dock into the center column, registers the
 * header toggle button (conversation.session.header.actions slot), the Ctrl+`
 * shortcut, and the demo TUI adapter. Failure policy: DOM mounting problems
 * are logged, never thrown — a throwing apply fails the whole web boot.
 */

import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-slots'
import * as React from 'react'
import { mountDock, toggleDock } from './dock.tsx'
import { diag } from './api.ts'
import { mountDemoAdapterClient } from '../examples/tui-adapter-client.ts'

/** Locale namespace this plugin owns. */
const NS = 'dsh-web-terminal'

/** Surface copy. */
const zh = {
  'toggle.label': '终端',
  'toggle.tooltip': '显示/隐藏终端 (Ctrl+`)',
  'dock.shell': 'Shell',
} as const

const en = {
  'toggle.label': 'Terminal',
  'toggle.tooltip': 'Toggle terminal (Ctrl+`)',
  'dock.shell': 'Shell',
} as const

type WtKey = keyof typeof en

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'dsh-web-terminal': WtKey
  }
  // The web shell declares the real slots; this build does not depend on the
  // shell package, so the single key we register into is declared here too.
  interface SlotMap {
    'conversation.session.header.actions': {
      kind: 'list'
      scope: 'session'
    }
  }
}

/** Required services (fiber inject waiting — the runtime must be up first). */
export const inject = ['slots', 'locale']

/** Stable client entry (export discipline: values stay internal). */
export function apply(ctx: ClientContext): void {
  console.log('[web-terminal] apply')
  diag('apply')
  // Probe which column-ish class names exist in the live DOM (dev aid for the
  // dock mount selector).
  try {
    const colClasses = [...new Set(
      Array.from(document.querySelectorAll('[class]'))
        .flatMap((el) => Array.from(el.classList))
        .filter((name) => /col|pane|frame/i.test(name)),
    )].slice(0, 24)
    diag('col-ish classes: ' + colClasses.join(','))
  } catch { /* ignore */ }
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-web-terminal: dictionaries')
  const t = ctx.locale.bind(NS)

  const disposers: Array<() => void> = []
  try {
    // 1. The dock itself (DOM-mounted into the center column, self-healing).
    disposers.push(mountDock())

    // 2. Header toggle button via the sanctioned slot seam.
    // NOTE: this component is rendered by the SHELL's React (slot renderer),
    // while this bundle carries its own inlined React copy. It must therefore
    // never call hooks (double-React → invalid hook call → inactive entry).
    // The active highlight comes from CSS (html[data-wt-visible="1"] ...).
    disposers.push(ctx.slots.inject('conversation.session.header.actions', () => ctx.slots.register({
      name: 'conversation.session.header.actions',
      id: 'web-terminal:toggle',
      order: 30,
      label: () => t('toggle.label'),
    }, () => React.createElement(
      'button',
      {
        type: 'button',
        className: 'wt-header-toggle',
        title: t('toggle.tooltip'),
        onClick: () => toggleDock(),
      },
      t('toggle.label'),
    ))))

    // 3. Ctrl+` shortcut (ignored while the terminal itself has focus).
    const onKeydown = (event: KeyboardEvent): void => {
      if (!event.ctrlKey || event.key !== '`') return
      const target = event.target as HTMLElement | null
      if (target !== null && target.closest('.wt-dock') !== null) return
      event.preventDefault()
      toggleDock()
    }
    window.addEventListener('keydown', onKeydown, true)
    disposers.push(() => window.removeEventListener('keydown', onKeydown, true))

    // 4. Demo TUI adapter (proves the extension API; both demo views).
    disposers.push(mountDemoAdapterClient())
  } catch (error) {
    // DOM failures degrade the dock, never the GUI.
    console.warn('[dsh-web-terminal] mount failed:', error)
  }

  ctx.effect(() => () => {
    for (const dispose of disposers.splice(0)) dispose()
  }, 'dsh-web-terminal: ui mounts')
}
