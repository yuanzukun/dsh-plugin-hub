/** GENERATED — do not edit by hand. Run `node scripts/gen-css.mjs` after touching the CSS source. */
export const DOCK_CSS = `/* ------------------------------------------------------------------ band */
/* The dock is the occupant of the shell's \`shell.bottom\` slot: a full-width
   band below the three columns. The shell subtracts its rendered height from
   the columns, so an open dock is a real split-screen; a collapsed dock
   reserves no space at all. */

.wt-dock {
  display: flex;
  flex-direction: column;
  width: 100%;
  background: var(--dsw-alias-bg-layer-1, #1e1e2e);
  border-top: 1px solid var(--dsw-alias-border-l1, #3a3a4a);
  color: var(--dsw-alias-label-primary, #e6e6e6);
  font-family: inherit;
  box-sizing: border-box;
  position: relative;
}

.wt-dock-collapsed {
  display: none;
}

.wt-dock-error {
  height: auto;
}

/* ------------------------------------------------------------------ tabbar */
.wt-dock-tabbar {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 4px 8px 0;
  border-bottom: 1px solid var(--dsw-alias-border-l1, #3a3a4a);
  flex: 0 0 auto;
  min-height: 30px;
}

.wt-dock-tab {
  appearance: none;
  border: 1px solid transparent;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #9a9aa8);
  font-size: 12px;
  line-height: 1;
  padding: 6px 10px;
  border-radius: 6px 6px 0 0;
  cursor: pointer;
  max-width: 180px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.wt-dock-tab:hover {
  color: var(--dsw-alias-label-primary, #e6e6e6);
}

.wt-dock-tab-active {
  color: var(--dsw-alias-brand-primary, #4f8cff);
  border-color: var(--dsw-alias-border-l1, #3a3a4a);
  border-bottom-color: transparent;
  background: var(--dsw-alias-bg-base, #181825);
}

.wt-dock-close {
  appearance: none;
  margin-left: auto;
  border: none;
  background: transparent;
  color: var(--dsw-alias-label-secondary, #9a9aa8);
  font-size: 16px;
  line-height: 1;
  padding: 2px 8px;
  cursor: pointer;
  border-radius: 4px;
}

.wt-dock-close:hover {
  color: var(--dsw-alias-state-error-primary, #f38ba8);
  background: var(--dsw-alias-bg-overlay, #2a2a3a);
}

/* ------------------------------------------------------------------- body */
.wt-dock-body {
  position: relative;
  flex: 1 1 auto;
  min-height: 0;
}

.wt-dock-terminal {
  position: absolute;
  inset: 0;
  padding: 4px 0 4px 8px;
  overflow: hidden;
}

.wt-dock-terminal .xterm {
  height: 100%;
}

.wt-dock-terminal .xterm-viewport {
  background-color: transparent !important;
}

.wt-dock-dom {
  position: absolute;
  inset: 0;
  overflow: auto;
}

.wt-hidden {
  display: none !important;
}

/* ----------------------------------------------------------------- resize */
.wt-dock-resize {
  position: absolute;
  top: -3px;
  left: 0;
  right: 0;
  height: 6px;
  cursor: ns-resize;
  z-index: 5;
}

.wt-dock-resize:hover,
.wt-dock-resize:active {
  background: var(--dsw-alias-brand-primary, #4f8cff);
  opacity: 0.5;
}

/* ------------------------------------------------------------- header btn */
.wt-header-toggle {
  appearance: none;
  border: 1px solid var(--dsw-alias-border-l1, #3a3a4a);
  background: var(--dsw-alias-bg-layer-1, #1e1e2e);
  color: var(--dsw-alias-label-primary, #e6e6e6);
  font-size: 12px;
  line-height: 1;
  padding: 5px 10px;
  border-radius: 6px;
  cursor: pointer;
}

.wt-header-toggle:hover {
  border-color: var(--dsw-alias-brand-primary, #4f8cff);
}

/* ------------------------------------------------------------ demo panel */
.wt-demo-panel {
  padding: 16px;
  font-size: 13px;
  line-height: 1.6;
}

.wt-demo-panel h3 {
  margin: 0 0 8px;
  font-size: 14px;
}

.wt-demo-panel code {
  background: var(--dsw-alias-bg-overlay, #2a2a3a);
  padding: 1px 4px;
  border-radius: 4px;
}

.wt-demo-panel[data-ack]::after {
  content: ' ✓ acknowledged';
  color: var(--dsw-alias-state-success-primary, #a6e3a1);
}
`
