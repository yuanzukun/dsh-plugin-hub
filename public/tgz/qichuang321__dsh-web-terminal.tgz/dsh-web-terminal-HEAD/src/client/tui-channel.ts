/**
 * Window CustomEvent channel — the only way client halves of DIFFERENT
 * plugins talk to the terminal dock (plugin bundles cannot import each
 * other; precedent: the 'dsh-panel-activate' cross-plugin event).
 *
 * Adapter → dock:  register / unregister
 * Dock → adapter:  ready / activate / deactivate / view-state
 */

/** A view a TUI plugin registers into the dock. */
export interface TuiViewRegistration {
  id: string
  label: string
  icon?: string
  order?: number
  kind: 'pty' | 'dom'
}

export const TUI_EVENTS = {
  register: 'dsh-web-terminal:register',
  unregister: 'dsh-web-terminal:unregister',
  ready: 'dsh-web-terminal:ready',
  activate: 'dsh-web-terminal:activate',
  deactivate: 'dsh-web-terminal:deactivate',
  viewState: 'dsh-web-terminal:view-state',
} as const

/** Adapter → dock: register one view. */
export function dispatchRegister(def: TuiViewRegistration): void {
  window.dispatchEvent(new CustomEvent(TUI_EVENTS.register, { detail: def }))
}

/** Adapter → dock: unregister one view. */
export function dispatchUnregister(id: string): void {
  window.dispatchEvent(new CustomEvent(TUI_EVENTS.unregister, { detail: { id } }))
}

/** Dock → adapter: the dock mounted (adapters re-register — self-heal). */
export function dispatchReady(): void {
  window.dispatchEvent(new CustomEvent(TUI_EVENTS.ready, { detail: {} }))
}

/** Dock → adapter: a 'dom' view is being activated; render into container. */
export function dispatchActivate(id: string, container: HTMLElement): void {
  window.dispatchEvent(new CustomEvent(TUI_EVENTS.activate, { detail: { id, container } }))
}

/** Dock → adapter: the view was deactivated. */
export function dispatchDeactivate(id: string): void {
  window.dispatchEvent(new CustomEvent(TUI_EVENTS.deactivate, { detail: { id } }))
}

/** Dock → adapter: PTY lifecycle state change for one view. */
export function dispatchViewState(id: string, state: 'running' | 'exit' | 'error', code?: number | null, error?: string): void {
  window.dispatchEvent(new CustomEvent(TUI_EVENTS.viewState, { detail: { id, state, code, error } }))
}

/** Subscribe to a dock↔adapter event; returns a disposer. */
export function onTuiEvent(name: string, handler: (event: CustomEvent) => void): () => void {
  const listener = (event: Event): void => {
    handler(event as CustomEvent)
  }
  window.addEventListener(name, listener)
  return () => window.removeEventListener(name, listener)
}
