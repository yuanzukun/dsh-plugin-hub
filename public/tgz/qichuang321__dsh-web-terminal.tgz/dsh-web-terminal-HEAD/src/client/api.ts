/**
 * Browser-side API client for the /api/dsh-web-terminal route family —
 * plain fetch + WebSocket, same origin. The only data access path the dock
 * components use.
 */

import { WT_API, type ClientFrame, type ServerFrame, type WebTerminalViewSummary } from '../protocol.ts'

/** Query-string helper. */
function query(params: Record<string, string | number | undefined>): string {
  const search = new URLSearchParams()
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== '') search.set(key, String(value))
  }
  const text = search.toString()
  return text === '' ? '' : '?' + text
}

/** Fire-and-forget diagnostics beacon to the host (dev aid; never throws). */
export function diag(msg: string): void {
  try {
    void fetch(WT_API.diag, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ msg }),
    }).catch(() => undefined)
  } catch {
    // never break the UI for diagnostics
  }
}

/** List the registered TUI views (plus the implicit 'shell' view). */
export async function fetchViews(): Promise<WebTerminalViewSummary[]> {
  const response = await fetch(WT_API.views)
  if (!response.ok) {
    throw new Error(`fetch views failed: HTTP ${response.status}`)
  }
  const body = (await response.json()) as { views?: WebTerminalViewSummary[] }
  return body.views ?? []
}

/** One open terminal connection (WebSocket JSON frames). */
export interface TerminalCallbacks {
  onReady?: (view: string, cols: number, rows: number) => void
  onOutput?: (data: string) => void
  onTitle?: (title: string) => void
  onExit?: (code: number | null, error?: string) => void
}

/** A live WebSocket terminal session. */
export class TerminalConnection {
  private readonly socket: WebSocket
  private readonly callbacks: TerminalCallbacks
  private closed = false

  constructor(view: string, cols: number, rows: number, callbacks: TerminalCallbacks) {
    this.callbacks = callbacks
    const scheme = window.location.protocol === 'https:' ? 'wss' : 'ws'
    const url = scheme + '://' + window.location.host + WT_API.session + query({ view, cols, rows })
    this.socket = new WebSocket(url)

    this.socket.onmessage = (event: MessageEvent<string>) => {
      let frame: ServerFrame
      try {
        frame = JSON.parse(event.data) as ServerFrame
      } catch {
        return
      }
      if (frame.type === 'ready') this.callbacks.onReady?.(frame.view, frame.cols, frame.rows)
      else if (frame.type === 'output') this.callbacks.onOutput?.(frame.data)
      else if (frame.type === 'title' && frame.title !== undefined) this.callbacks.onTitle?.(frame.title)
      else if (frame.type === 'exit') this.callbacks.onExit?.(frame.code, frame.error)
    }
    this.socket.onclose = () => {
      if (!this.closed) {
        this.closed = true
        this.callbacks.onExit?.(null, 'connection closed')
      }
    }
    this.socket.onerror = () => {
      this.callbacks.onExit?.(null, 'connection error')
    }
  }

  get readyState(): number {
    return this.socket.readyState
  }

  /** Send raw input to the PTY (no EOL conversion — ConPTY emits CRLF natively). */
  send(data: string): void {
    if (this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({ type: 'input', data } satisfies ClientFrame))
    }
  }

  /** Resize the remote PTY. */
  resize(cols: number, rows: number): void {
    if (this.socket.readyState === WebSocket.OPEN) {
      this.socket.send(JSON.stringify({ type: 'resize', cols, rows } satisfies ClientFrame))
    }
  }

  /** Close the socket (the host kills the PTY). */
  close(): void {
    if (this.closed) return
    this.closed = true
    try {
      this.socket.close()
    } catch {
      // already closed
    }
  }
}
