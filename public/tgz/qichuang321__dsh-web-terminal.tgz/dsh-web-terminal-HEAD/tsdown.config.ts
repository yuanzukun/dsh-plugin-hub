import { defineConfig } from 'tsdown'
import type { Plugin } from 'rolldown'

/**
 * Rolldown plugin: wraps the built client.js in DSH's
 * window.__ModuleLoader__.load({ id, factory }) envelope.
 * Runs during generateBundle (before write), so both `build` and `watch`
 * produce a correctly wrapped client.js automatically.
 */
const wrapClientPlugin: Plugin = {
  name: 'dsh-wrap-client-loader',
  generateBundle(_options, bundle) {
    for (const [fileName, chunk] of Object.entries(bundle)) {
      if (fileName === 'client.js' && chunk.type === 'chunk') {
        if (chunk.code.includes('__ModuleLoader__')) {
          continue
        }
        chunk.code = `window.__ModuleLoader__.load({ id: "dsh-web-terminal", factory: (require) => {
var module = { exports: {} }; var exports = module.exports;
Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
` + chunk.code + `
return module.exports;
} });`
        console.log('[dsh-wrap-client-loader] Wrapped client.js for DSH module loader.')
      }
    }
  },
}

/**
 * Two separate builds (tsdown accepts an array of configs):
 *  - host:   src/index.ts  → lib/index.js   (node-pty/ws/schemastery/@deepseek-ai/* stay external, resolved from the profile's node_modules at runtime)
 *  - client: src/client/index.ts → lib/client.js (xterm + react + react-dom INLINED — the web shell loads one self-contained bundle, dsh-ssh pattern)
 */

/** Host-half build. */
const host = defineConfig({
  entry: { index: 'src/index.ts' },
  outDir: 'lib',
  format: ['esm'],
  target: 'node22.19.0',
  platform: 'node',
  outExtensions: () => ({ js: '.js' }),
  clean: true,
  dts: false,
  deps: {
    neverBundle: [
      /^node:/,
      'node-pty',
      'ws',
      'schemastery',
      '@deepseek-ai/cordis',
      '@deepseek-ai/dsh-settings',
      '@deepseek-ai/dsh-host-webserver',
    ],
  },
})

/** Browser-half build (bundled so the served client.js is standalone). */
const client = defineConfig({
  entry: { client: 'src/client/index.ts' },
  outDir: 'lib',
  format: ['cjs'],
  target: 'es2022',
  platform: 'browser',
  outExtensions: () => ({ js: '.js' }),
  dts: false,
  define: {
    'process.env.NODE_ENV': '"production"',
  },
  plugins: [wrapClientPlugin],
  deps: {
    neverBundle: ['@deepseek-ai/cordis'],
    // /^react/ covers react, react-dom, react-dom/client and react/jsx-runtime —
    // ALL of them must be inlined as ONE copy, or hooks + createRoot tear
    // across two React instances (dispatcher null → "Cannot read properties
    // of null (reading 'useSyncExternalStore')").
    alwaysBundle: [/^react/, '@xterm/xterm', '@xterm/addon-fit'],
  },
})

export default [host, client]
