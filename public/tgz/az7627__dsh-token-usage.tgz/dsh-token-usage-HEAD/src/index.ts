/**
 * Token usage timeline service: the `/usage` RPC channel. The browser half
 * calls `usage.timeline` for per-request usage series of selected sessions;
 * this half reads each session's validated log through the unified query
 * service and folds it into time-stamped points.
 *
 * The host half deliberately imports only packages reachable from both
 * compilation programs (the package project builds under the client
 * aggregate too), so the connection transport and the session corpus are
 * addressed through local structural faces via `ctx.get` instead of the
 * packages that carry their host-side Context merges.
 * @module @deepseek-ai/dsh-token-usage
 */

import type { Context } from '@deepseek-ai/cordis'
import type { RpcResult } from '@deepseek-ai/dsh-host-apiproxy/api'
import type { SessionEvent, SessionId } from '@deepseek-ai/dsh-session'
import { foldUsageSeries, MAX_TIMELINE_POINTS } from './fold.ts'
import { TIMELINE_ENDPOINT, timelineRequestSchema, type UsagePoint, type UsageTimelineValue } from './schemas.ts'

/** Stable Cordis plugin name. */
export const name = 'token-usage'

/** Services the endpoint reads: the shared transport registry, the session corpus, and the live session store. */
export const inject = ['connection', 'sessionQuery', 'sessions']

/** Channel prefix and trust policy: local browser only — the endpoint returns session billing data. */
const CHANNEL: string = '/usage'

/** Structural transport face (the real service is `ctx.connection` from dsh-client-connection). */
interface ConnectionRpcFace {
  handle(
    channel: string,
    handler: (endpoint: string, payload: unknown, signal: AbortSignal) => Promise<RpcResult<unknown>>,
    options: { authority: 'trusted-host' | 'loopback' },
  ): () => Promise<void>
}

/** Structural query face (the real service is `ctx.sessionQuery` from dsh-session-query). */
interface SessionQueryFace {
  readSession(sessionId: SessionId): Promise<{ events: SessionEvent[] }>
  /**
   * Batch projector the query service offers for exact multi-session reads:
   * concurrent persisted inspections plus borrowed (uncloned) event arrays
   * valid only for the synchronous projection call. Absent on runtimes older
   * than the seam, in which case the handler falls back to `readSession`.
   */
  projectMany?(
    sessionIds: readonly SessionId[],
    project: (source: { events: readonly SessionEvent[] }) => UsagePoint[],
    signal?: AbortSignal,
  ): Promise<Array<{ sessionId: SessionId; status: 'fulfilled' | 'rejected'; value?: UsagePoint[]; reason?: unknown }>>
}

/** Structural live-store face (the real service is `ctx.sessions` from dsh-session). */
interface SessionsFace {
  get(sessionId: SessionId): { events: readonly SessionEvent[] } | undefined
}

/**
 * Build the `/usage` channel handler bound to the plugin's query service.
 *
 * Live sessions fold directly over their borrowed in-memory event arrays —
 * no log clone, no replay validation — so the common single-conversation
 * open stays near-instant. Persisted sessions go through the query service's
 * batch projector when available (concurrent inspections, borrowed events,
 * only the folded points retained); older runtimes fall back to sequential
 * `readSession`.
 * @param sessionQuery - the session corpus reader.
 * @param sessions - the live session store.
 * @returns a handler answering unknown endpoints and invalid payloads with
 * `bad-request`, missing sessions with `session-not-found`, and query
 * failures with `internal`.
 */
function createUsageHandler(sessionQuery: SessionQueryFace, sessions: SessionsFace): (
  endpoint: string,
  payload: unknown,
  signal: AbortSignal,
) => Promise<RpcResult<unknown>> {
  return async (endpoint, payload, signal): Promise<RpcResult<unknown>> => {
    if (endpoint !== TIMELINE_ENDPOINT) {
      return {
        ok: false,
        error: {
          code: 'bad-request',
          message: `unknown endpoint ${JSON.stringify(endpoint)}`,
          details: { issues: [] },
        },
      }
    }
    const parsed = timelineRequestSchema.safeParse(payload)
    if (!parsed.success) {
      return {
        ok: false,
        error: {
          code: 'bad-request',
          message: 'invalid usage.timeline request',
          details: { issues: parsed.error.issues },
        },
      }
    }
    if (signal.aborted) return cancelledResult()
    const { sessionIds, from, to } = parsed.data
    const result: UsageTimelineValue['sessions'] = []
    let pointCount = 0
    const pushSeries = (sessionId: SessionId, series: UsagePoint[]): RpcResult<unknown> | null => {
      pointCount += series.length
      if (pointCount > MAX_TIMELINE_POINTS) {
        return {
          ok: false,
          error: {
            code: 'bad-request',
            message: 'usage.timeline response would be too large; narrow the time range',
            details: { issues: [] },
          },
        }
      }
      result.push({ sessionId: String(sessionId), series })
      return null
    }

    // Live sessions never touch the query service: their events are already
    // in memory and the fold borrows them without retaining the array.
    const persistedIds: SessionId[] = []
    for (const sessionId of sessionIds) {
      const live = sessions.get(sessionId)
      if (live !== undefined) {
        const overflow = pushSeries(sessionId, foldUsageSeries(live.events, from, to))
        if (overflow !== null) return overflow
      } else {
        persistedIds.push(sessionId)
      }
    }
    if (persistedIds.length === 0) return { ok: true, value: { sessions: result } satisfies UsageTimelineValue }

    const projectMany = sessionQuery.projectMany
    if (projectMany !== undefined) {
      let projected
      try {
        projected = await projectMany(
          persistedIds,
          source => foldUsageSeries(source.events, from, to),
          signal,
        )
      } catch (error) {
        return internalResult(error)
      }
      // Re-checked after the awaited batch: the carrier can abort while the
      // inspections are in flight.
      if (signal.aborted) return cancelledResult()
      for (const entry of projected) {
        if (entry.status === 'rejected') return classifySessionError(entry.reason, entry.sessionId)
        const overflow = pushSeries(entry.sessionId, entry.value ?? [])
        if (overflow !== null) return overflow
      }
      return { ok: true, value: { sessions: result } satisfies UsageTimelineValue }
    }

    // Fallback for runtimes without the batch projector: sequential reads.
    for (const sessionId of persistedIds) {
      let events
      try {
        events = (await sessionQuery.readSession(sessionId)).events
      } catch (error) {
        // The exact error code the query service documents for a missing
        // session; duck-typed because the host half must stay importable from
        // the client compilation program.
        if ((error as { code?: unknown } | null)?.code === 'SESSION_QUERY_SESSION_NOT_FOUND') {
          return {
            ok: false,
            error: {
              code: 'session-not-found',
              message: error instanceof Error ? error.message : String(error),
              details: { sessionId },
            },
          }
        }
        return internalResult(error)
      }
      const overflow = pushSeries(sessionId, foldUsageSeries(events, from, to))
      if (overflow !== null) return overflow
      // Re-checked after each awaited read: the carrier can abort between
      // sessions while the first read is still in flight.
      // oxlint-disable-next-line typescript/no-unnecessary-condition -- abort lands asynchronously during the await above
      if (signal.aborted) return cancelledResult()
    }
    return { ok: true, value: { sessions: result } satisfies UsageTimelineValue }
  }
}

/** Classify one rejected batch projection into the wire error it corresponds to. */
function classifySessionError(reason: unknown, sessionId: SessionId): RpcResult<unknown> {
  if ((reason as { code?: unknown } | null)?.code === 'SESSION_QUERY_SESSION_NOT_FOUND') {
    return {
      ok: false,
      error: {
        code: 'session-not-found',
        message: reason instanceof Error ? reason.message : String(reason),
        details: { sessionId },
      },
    }
  }
  return internalResult(reason)
}

/** Internal-failure result with the reason's message. */
function internalResult(reason: unknown): RpcResult<unknown> {
  return {
    ok: false,
    error: {
      code: 'internal',
      message: reason instanceof Error ? reason.message : String(reason),
      details: {},
    },
  }
}

/** Cancellation result with the carrier's exact reason. */
function cancelledResult(): RpcResult<unknown> {
  return {
    ok: false,
    error: { code: 'cancelled', message: 'usage.timeline cancelled', details: {} },
  }
}

/**
 * Register the `/usage` channel on the shared transport; the registration
 * leaves with the plugin fiber.
 * @param ctx - host context carrying the connection transport and the session corpus.
 */
export function apply(ctx: Context): void {
  const connection = ctx.get('connection') as unknown as { rpc: ConnectionRpcFace }
  const sessionQuery = ctx.get('sessionQuery') as unknown as SessionQueryFace
  const sessions = ctx.get('sessions') as unknown as SessionsFace
  const handler = createUsageHandler(sessionQuery, sessions)
  ctx.effect(
    // trusted-host (not loopback): phones on the deployment's WireGuard
    // authority must be able to read their usage timeline, and the
    // trusted-host fence is the same authority gate the rest of the remote
    // UI passes.
    () => connection.rpc.handle(CHANNEL, handler, { authority: 'trusted-host' }),
    'token-usage: /usage rpc channel',
  )
}
