/**
 * ECharts wrapper for the stacked usage chart: one instance per mount,
 * option updates on data change, resize on container change (panel drags
 * alter the container box without a window resize), disposal on unmount.
 * The option itself is the pure {@link buildUsageOption} builder.
 */

import { useEffect, useRef } from 'react'
import * as echarts from 'echarts/core'
import { BarChart } from 'echarts/charts'
import { DataZoomComponent, GridComponent, LegendComponent, TooltipComponent } from 'echarts/components'
import { CanvasRenderer } from 'echarts/renderers'
import type { UsageBucket } from './timeline.ts'
import { buildUsageOption, type UsageChartColors, type UsageChartLabels } from './chart-option.ts'

echarts.use([BarChart, GridComponent, TooltipComponent, LegendComponent, DataZoomComponent, CanvasRenderer])

/** One mounted chart's minimum contract. */
type UsageChartInstance = ReturnType<typeof echarts.init>

/** Props: the projected buckets plus the presentation inputs the option needs. */
export interface UsageChartProps {
  buckets: readonly UsageBucket[]
  bucketMs: number
  colors: UsageChartColors
  labels: UsageChartLabels
  /** Chart container class from the owning module sheet (absent without one). */
  className: string | undefined
}

/**
 * Render the container and own the echarts instance lifecycle.
 * @param props - buckets and presentation inputs.
 * @returns the chart container div.
 */
export function UsageChart({ buckets, bucketMs, colors, labels, className }: UsageChartProps): React.JSX.Element {
  const containerRef = useRef<HTMLDivElement | null>(null)
  const chartRef = useRef<UsageChartInstance | null>(null)

  useEffect(() => {
    const container = containerRef.current
    /* v8 ignore next -- the container div is always rendered when effects run */
    if (container === null) return
    const chart = echarts.init(container)
    chartRef.current = chart
    const onResize = (): void => { chart.resize() }
    let resizeObserver: ResizeObserver | null = null
    if (typeof ResizeObserver !== 'undefined') {
      resizeObserver = new ResizeObserver(onResize)
      resizeObserver.observe(container)
    }
    window.addEventListener('resize', onResize)
    return () => {
      window.removeEventListener('resize', onResize)
      resizeObserver?.disconnect()
      chart.dispose()
      chartRef.current = null
    }
  }, [])

  useEffect(() => {
    // The mount effect always runs first, so the instance exists here; the
    // optional call only guards against effect-order regressions.
    /* v8 ignore next -- the mount effect initializes the instance before this effect */
    chartRef.current?.setOption(buildUsageOption(buckets, bucketMs, colors, labels))
  }, [buckets, bucketMs, colors, labels])

  return <div ref={containerRef} className={className} />
}
