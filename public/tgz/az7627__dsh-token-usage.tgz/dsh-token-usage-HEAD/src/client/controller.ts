/**
 * Browser-side fetch controller for the `/usage` channel: validates the
 * outbound request and the inbound response at their wire boundaries, and
 * maps transport/error codes onto one panel-facing failure shape.
 * @module @deepseek-ai/dsh-token-usage/client
 */

import type { ClientConnectionRpc } from '@deepseek-ai/dsh-client-connection/client'
import type { RpcErrorCode } from '@deepseek-ai/dsh-host-apiproxy/api'
import { timelineRequestSchema, timelineValueSchema, type UsageTimelineRequest, type UsageTimelineValue } from '../schemas.ts'

/** Failure codes the panel distinguishes for copy and retry behavior. */
export type UsageFetchFailureCode = RpcErrorCode | 'transport'

/** One fetch failure: wire error code plus the host's message. */
export class UsageFetchError extends Error {
  /**
   * @param code - classified failure code.
   * @param message - host-provided or transport-level message.
   */
  constructor(readonly code: UsageFetchFailureCode, message: string) {
    super(message)
    this.name = 'UsageFetchError'
  }
}

/** Transport failures (HTTP status, rpcId mismatch, envelope parse) collapse into one code. */
function transportError(message: string): UsageFetchError {
  return new UsageFetchError('transport', message)
}

/**
 * Call `usage.timeline` through the shared browser transport.
 * @param rpc - the browser RPC caller of the connection service.
 * @param request - the panel's request (validated again at the wire boundary).
 * @param signal - optional cancellation.
 * @returns the validated response value.
 * @throws {@link UsageFetchError} with a classified code on failure.
 */
export async function fetchTimeline(
  rpc: ClientConnectionRpc,
  request: UsageTimelineRequest,
  signal?: AbortSignal,
): Promise<UsageTimelineValue> {
  const parsedRequest = timelineRequestSchema.parse(request)
  let result
  try {
    result = await rpc.call('/usage', 'timeline', parsedRequest, signal)
  } catch (error) {
    throw transportError(error instanceof Error ? error.message : String(error))
  }
  if (!result.ok) {
    throw new UsageFetchError(result.error.code, result.error.message)
  }
  try {
    return timelineValueSchema.parse(result.value)
  } catch (error) {
    /* v8 ignore next -- zod parse failures are always Error instances */
    throw transportError(`invalid usage.timeline response: ${error instanceof Error ? error.message : String(error)}`)
  }
}
