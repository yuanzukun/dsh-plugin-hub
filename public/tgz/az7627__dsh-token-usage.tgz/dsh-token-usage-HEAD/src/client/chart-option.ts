/**
 * Pure echarts option builder for the stacked usage chart: three disjoint
 * buckets stacked per time slot, exact-number tooltips, and an initial zoom
 * window that keeps long spans readable. Colors arrive as plain strings (the
 * panel resolves them from theme tokens); no React, no echarts instance.
 * @module @deepseek-ai/dsh-token-usage/client
 */

import type { EChartsCoreOption } from 'echarts/core'
import type { UsageBucket } from './timeline.ts'
import { axisLabel, formatTokensExact } from './timeline.ts'

/** Series colors and axis chrome resolved from the theme (tokens) or defaults. */
export interface UsageChartColors {
  cacheRead: string
  input: string
  output: string
  text: string
  grid: string
}

/** Series display names (localized copy passed by the panel). */
export interface UsageChartLabels {
  cacheRead: string
  input: string
  output: string
}

/** Initial zoom window shows at most this many trailing buckets. */
export const CHART_ZOOM_WINDOW_BUCKETS = 288

/**
 * Read the three series colors plus axis chrome from CSS theme tokens; the
 * fallbacks cover environments without the theme sheet (jsdom tests).
 * @returns resolved colors.
 */
export function readUsageColors(): UsageChartColors {
  const style = typeof document === 'undefined' ? undefined : getComputedStyle(document.documentElement)
  const token = (name: string, fallback: string): string => {
    const value = style?.getPropertyValue(name).trim()
    return value === '' || value === undefined ? fallback : value
  }
  return {
    cacheRead: token('--dsw-alias-state-warn-primary', '#b7791f'),
    input: token('--dsw-alias-state-business-primary', '#2f6bff'),
    output: token('--dsw-alias-state-success-primary', '#1f9d6b'),
    text: token('--dsw-alias-label-secondary', '#64748b'),
    grid: token('--dsw-alias-border-l2', '#e2e8f0'),
  }
}

/** One axis-triggered tooltip entry (the fields echarts supplies per series). */
export interface UsageTooltipItem {
  /** Category value: the bucket start epoch ms (shape varies across echarts paths). */
  axisValue: unknown
  seriesName: string
  value: number
}

/**
 * Normalize an echarts tick value into the bucket-start epoch ms. ECharts
 * passes different shapes on different internal paths: the raw number, a
 * numeric string, or a `{ value: number }` tick object (the label-layout
 * estimation path wraps ticks that way). Anything else is not a time.
 * @param value - whatever the formatter received.
 * @returns the epoch-ms number, or NaN when the value is unusable.
 */
export function normalizeTick(value: unknown): number {
  if (typeof value === 'number') return value
  if (typeof value === 'string' && value !== '') return Number(value)
  if (typeof value === 'object' && value !== null && 'value' in value) {
    const inner = (value as { value: unknown }).value
    return typeof inner === 'number' ? inner : typeof inner === 'string' && inner !== '' ? Number(inner) : Number.NaN
  }
  return Number.NaN
}

/**
 * Render the axis tooltip: bucket wall-clock label plus one exact-numbered
 * line per series. Values arrive as numbers for the bar series.
 * @param params - echarts axis-trigger payload (single item or array).
 * @param bucketMs - granularity for the bucket label.
 * @returns HTML string consumed by echarts.
 */
export function usageTooltip(params: unknown, bucketMs: number): string {
  const list = Array.isArray(params) ? params as UsageTooltipItem[] : [params as UsageTooltipItem]
  const first = list[0]
  if (first === undefined) return ''
  const head = axisLabel(normalizeTick(first.axisValue), bucketMs)
  const lines = list
    .map(item => `${item.seriesName}：${formatTokensExact(item.value)}`)
    .join('<br/>')
  return `${head}<br/>${lines}`
}

/**
 * Build the chart option for one bucket series.
 * @param buckets - ascending contiguous buckets (possibly empty).
 * @param bucketMs - granularity driving axis labels.
 * @param colors - resolved theme colors.
 * @param labels - localized series names.
 * @returns a complete echarts option.
 */
export function buildUsageOption(
  buckets: readonly UsageBucket[],
  bucketMs: number,
  colors: UsageChartColors,
  labels: UsageChartLabels,
): EChartsCoreOption {
  const data = buckets.map(bucket => bucket.start)
  const zoom = buckets.length > CHART_ZOOM_WINDOW_BUCKETS
    ? [{
      type: 'inside' as const,
    }, {
      type: 'slider' as const,
      height: 18,
      start: Math.round((1 - CHART_ZOOM_WINDOW_BUCKETS / buckets.length) * 100),
      end: 100,
    }]
    : []
  return {
    animation: false,
    color: [colors.cacheRead, colors.input, colors.output],
    grid: { left: 8, right: 8, top: 28, bottom: zoom.length > 0 ? 40 : 8, containLabel: true },
    legend: {
      top: 0,
      itemWidth: 10,
      itemHeight: 10,
      textStyle: { color: colors.text, fontSize: 12 },
      data: [labels.cacheRead, labels.input, labels.output],
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      formatter: (params: unknown) => usageTooltip(params, bucketMs),
    },
    xAxis: {
      type: 'category',
      data,
      axisLine: { lineStyle: { color: colors.grid } },
      axisTick: { show: false },
      axisLabel: {
        color: colors.text,
        fontSize: 11,
        hideOverlap: true,
        formatter: (tick: unknown) => axisLabel(normalizeTick(tick), bucketMs),
      },
    },
    yAxis: {
      type: 'value',
      splitLine: { lineStyle: { color: colors.grid } },
      axisLabel: { color: colors.text, fontSize: 11 },
    },
    series: [
      { name: labels.cacheRead, type: 'bar', stack: 'usage', barMaxWidth: 28, data: buckets.map(bucket => bucket.cacheRead) },
      { name: labels.input, type: 'bar', stack: 'usage', barMaxWidth: 28, data: buckets.map(bucket => bucket.input) },
      { name: labels.output, type: 'bar', stack: 'usage', barMaxWidth: 28, data: buckets.map(bucket => bucket.output) },
    ],
    dataZoom: zoom,
  }
}
