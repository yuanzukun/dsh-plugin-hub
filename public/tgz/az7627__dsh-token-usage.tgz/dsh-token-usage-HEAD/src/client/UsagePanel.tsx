/**
 * Usage statistics panel: the right third column of the Web layout. It owns
 * conversation multi-select (sidebar-equivalent visibility with archived and
 * subagent toggles), granularity presets plus a custom minute count, range
 * presets plus custom start/end dates, the stacked usage chart, exact totals,
 * and a scrollable per-conversation table. While open it reserves its width
 * by setting the layout's center column margin, shifts left when the details
 * column opens, is resizable through its left drag handle up to half the
 * conversation area, and animates in and out through the owner's close
 * choreography.
 */

import { useEffect, useMemo, useRef, useState } from 'react'
import { IconCloseOutline16, IconRefreshOutline14 } from '@deepseek-ai/dsh-client-ui-primitives'
import type { SessionId, SessionListState, WorkspaceListState } from '@deepseek-ai/dsh-client-runtime/client'
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots'
// Type-only merge edge: the `title` projection key session rows read.
import type {} from '@deepseek-ai/dsh-session-title/client'
import type { UsageTimelineRequest, UsageTimelineValue } from '../schemas.ts'
import { readUsageColors } from './chart-option.ts'
import type { TokenUsageKey } from './locales.ts'
import {
  BUCKET_PRESETS,
  RANGE_PRESETS,
  bucketPreset,
  endOfDayLocal,
  fallbackSessionLabel,
  formatDateInput,
  formatTokensExact,
  parseCustomBucketMinutes,
  parseDateInput,
  projectTimeline,
  rangeBounds,
  type BucketPresetKey,
  type RangePresetKey,
  type TimelineProjectionResult,
  type UsageTotals,
} from './timeline.ts'
import { UsageChart } from './UsageChart.tsx'
import css from './UsagePanel.module.css'

/** Panel-width bounds and storage key. The maximum is dynamic: half the conversation area. */
export const PANEL_WIDTH_MIN = 300
export const PANEL_WIDTH_DEFAULT = 360
/** Ceiling used only while the frame is unmeasurable (before wiring or in tests). */
export const PANEL_WIDTH_FALLBACK_MAX = 800
/** Fraction of the conversation area the panel may take at most. */
export const PANEL_WIDTH_RATIO = 0.5
export const PANEL_WIDTH_STORAGE_KEY = 'dsh-token-usage.width'

/** Granularity-control display keys per preset. */
const BUCKET_LABEL_KEYS: Record<BucketPresetKey, TokenUsageKey> = {
  '15m': 'bucket.15m',
  '1h': 'bucket.1h',
  '1d': 'bucket.1d',
}

/** Range-control display keys per preset. */
const RANGE_LABEL_KEYS: Record<RangePresetKey, TokenUsageKey> = {
  '7d': 'range.7d',
  '30d': 'range.30d',
  'all': 'range.all',
}

/** Granularity choice: one preset or the custom minute input. */
type BucketChoice = BucketPresetKey | 'custom'

/** Range choice: one preset or the custom date range. */
type RangeChoice = RangePresetKey | 'custom'

/** One fetch outcome plus the request window it answered. */
type UsageLoad =
  | { status: 'loading'; bounds: { from?: number; to?: number } }
  | { status: 'error'; message: string; bounds: { from?: number; to?: number } }
  | { status: 'ready'; value: UsageTimelineValue; bounds: { from?: number; to?: number } }

/** Panel props: the current conversation, the global session/workspace feeds, the fetch callback, and the close choreography. */
export interface UsagePanelProps {
  sessionId: SessionId
  useSessions: SnapshotSelectorHook<SessionListState>
  useWorkspaces: SnapshotSelectorHook<WorkspaceListState>
  fetchTimeline: (request: UsageTimelineRequest, signal?: AbortSignal) => Promise<UsageTimelineValue>
  /** Ask the owner to start the exit animation; the owner flips `closing`. */
  onRequestClose: () => void
  /** The owner renders the panel while it animates out; the panel reports when the exit finished. */
  onExited: () => void
  /** Exit phase: slides the panel out and releases the center-column reservation. */
  closing: boolean
  t: (key: TokenUsageKey) => string
}

/** Read the stored panel width, clamped into the allowed range for the current frame. */
function readStoredWidth(): number {
  if (typeof localStorage === 'undefined') return PANEL_WIDTH_DEFAULT
  const raw = Number(localStorage.getItem(PANEL_WIDTH_STORAGE_KEY))
  if (!Number.isFinite(raw) || raw <= 0) return PANEL_WIDTH_DEFAULT
  const max = typeof window === 'undefined'
    ? PANEL_WIDTH_FALLBACK_MAX
    : maxPanelWidth(findFrame(), window.innerWidth)
  return clampWidth(raw, max)
}

/** Clamp one width into the panel's allowed range. */
function clampWidth(width: number, max: number): number {
  return Math.min(max, Math.max(PANEL_WIDTH_MIN, width))
}

/** The app frame's grid signature: browsers serialize `minmax` with 0 or 0px and varied spacing. */
const FRAME_GRID = /minmax\(\s*0(?:px)?\s*,\s*1fr\)/

/**
 * Locate the app frame: the element whose inline grid carries the three
 * columns. Matching is token-normalized because the CSSOM serialization of
 * `minmax(0, 1fr)` differs across browsers (`0` vs `0px`, comma spacing).
 * @returns the frame element, or null when the layout is not mounted.
 */
function findFrame(): HTMLElement | null {
  for (const element of Array.from(document.querySelectorAll<HTMLElement>('[style]'))) {
    const grid = element.style.gridTemplateColumns
    if (grid !== '' && FRAME_GRID.test(grid)) return element
  }
  return null
}

/**
 * Locate the center column (the grid item hosting the conversation): climb
 * from the conversation scrollport up to the frame's direct child, falling
 * back to the second grid item.
 * @param frame - the app frame.
 * @returns the center column element, or undefined when not mounted.
 */
function findCenterColumn(frame: HTMLElement): HTMLElement | undefined {
  const scrollport = frame.querySelector<HTMLElement>('[data-conversation-scroll]')
  if (scrollport !== null) {
    let node = scrollport.parentElement
    while (node !== null && node.parentElement !== frame) node = node.parentElement
    if (node !== null) return node
  }
  return frame.children[1] as HTMLElement | undefined
}

/** The details column's current width in px (0 while collapsed), read from the frame's inline grid. */
function detailsWidthOf(frame: HTMLElement | null): number {
  return gridColumnWidths(frame).details
}

/** Parse the sidebar and details pixel tracks out of the frame's inline grid. */
function gridColumnWidths(frame: HTMLElement | null): { sidebar: number; details: number } {
  if (frame === null) return { sidebar: 0, details: 0 }
  // Browsers normalize `minmax(0, 1fr)` spacing, so strip that token before
  // splitting: the remaining tokens are exactly [sidebar, details].
  const columns = frame.style.gridTemplateColumns
    .replace(/minmax\([^)]*\)/, ' ')
    .split(/\s+/)
    .filter(token => token !== '')
  const pixel = (token: string | undefined): number => {
    if (token === undefined) return 0
    const parsed = Number.parseInt(token, 10)
    return Number.isFinite(parsed) ? Math.max(0, parsed) : 0
  }
  return { sidebar: pixel(columns[0]), details: pixel(columns[1]) }
}

/**
 * The widest the panel may currently be: half of the conversation area —
 * the viewport minus the sidebar and the details column — so the panel
 * scales with the browser window while always leaving the conversation
 * column at least as much room. Falls back to the fixed ceiling while the
 * frame is not measurable.
 * @param frame - the app frame, or null while unmounted.
 * @param viewportWidth - the current window width.
 * @returns the dynamic maximum width in px.
 */
export function maxPanelWidth(frame: HTMLElement | null, viewportWidth: number): number {
  if (frame === null || !Number.isFinite(viewportWidth) || viewportWidth <= 0) {
    return PANEL_WIDTH_FALLBACK_MAX
  }
  const { sidebar, details } = gridColumnWidths(frame)
  const conversationArea = viewportWidth - sidebar - details
  return Math.max(PANEL_WIDTH_MIN, Math.floor(conversationArea * PANEL_WIDTH_RATIO))
}

/**
 * Render the drawer body as the fixed right third column.
 * @param props - current session, feeds, fetch callback, close, and copy.
 * @returns the panel tree.
 */
export function UsagePanel({
  sessionId, useSessions, useWorkspaces, fetchTimeline, onRequestClose, onExited, closing, t,
}: UsagePanelProps) {
  const [selection, setSelection] = useState<ReadonlySet<string>>(() => new Set([String(sessionId)]))
  const [bucketKey, setBucketKey] = useState<BucketChoice>('1h')
  const [customMinutes, setCustomMinutes] = useState('30')
  const [rangeKey, setRangeKey] = useState<RangeChoice>('30d')
  const [customFrom, setCustomFrom] = useState(() => formatDateInput(Date.now() - 30 * 86_400_000))
  const [customTo, setCustomTo] = useState(() => formatDateInput(Date.now()))
  const [showArchived, setShowArchived] = useState(false)
  const [includeSubagents, setIncludeSubagents] = useState(false)
  const [refreshNonce, setRefreshNonce] = useState(0)
  const [load, setLoad] = useState<UsageLoad>({ status: 'loading', bounds: {} })
  const [width, setWidth] = useState(readStoredWidth)
  const panelRef = useRef<HTMLDivElement | null>(null)
  const frameRef = useRef<HTMLElement | null>(null)
  const dragStart = useRef<{ x: number; width: number } | null>(null)
  const colors = useMemo(readUsageColors, [])
  const labels = useMemo(() => ({
    cacheRead: t('totals.cacheRead'),
    input: t('totals.input'),
    output: t('totals.output'),
  }), [t])

  // The drawer defaults to the conversation it opened from; a later switch of
  // the current conversation resets the selection to that conversation. The
  // first render already carries that default, so only real changes reset.
  const mountedSession = useRef(sessionId)
  useEffect(() => {
    if (mountedSession.current === sessionId) return
    mountedSession.current = sessionId
    setSelection(new Set([String(sessionId)]))
  }, [sessionId])

  // Escape starts the close choreography (the button and the header close button too).
  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent): void => {
      if (event.key === 'Escape') onRequestClose()
    }
    document.addEventListener('keydown', onKeyDown)
    return () => { document.removeEventListener('keydown', onKeyDown) }
  }, [onRequestClose])

  // While open, the panel reserves its width: the center column gets a
  // matching margin and the panel shifts left when the details column opens.
  // While closing, the reservation releases with the same transition as the
  // panel's slide-out so the conversation column reclaims the space smoothly.
  // The frame may not be locatable on the very first tick (it is guaranteed
  // only after the app shell mounts), so the wiring retries briefly.
  useEffect(() => {
    let cancelled = false
    const cleanup: (() => void)[] = []

    const wire = (frame: HTMLElement, center: HTMLElement | undefined): void => {
      frameRef.current = frame
      const details = frame.children[2] as HTMLElement | undefined
      const applyLayout = (): void => {
        const detailsWidth = detailsWidthOf(frame)
        if (center !== undefined) {
          if (closing) {
            center.style.transition = 'margin-right 160ms ease'
            center.style.marginRight = '0px'
          } else {
            center.style.transition = ''
            center.style.marginRight = `${width}px`
          }
        }
        if (panelRef.current !== null) panelRef.current.style.right = `${detailsWidth}px`
      }
      applyLayout()
      // Column widths move through inline-style updates that change element
      // boxes, not attributes, so observe the boxes themselves.
      if (typeof ResizeObserver !== 'undefined') {
        const resizeObserver = new ResizeObserver(applyLayout)
        if (center !== undefined) resizeObserver.observe(center)
        if (details !== undefined) resizeObserver.observe(details)
        cleanup.push(() => resizeObserver.disconnect())
      }
      cleanup.push(() => {
        if (center !== undefined) {
          center.style.marginRight = ''
          center.style.transition = ''
        }
      })
      // A window resize can shrink the conversation area below the current
      // width; re-clamp so the panel never covers the whole column.
      setWidth(prev => clampWidth(prev, maxPanelWidth(frame, window.innerWidth)))
    }

    const attempt = (retriesLeft: number): void => {
      const frame = findFrame()
      if (frame !== null) {
        wire(frame, findCenterColumn(frame))
        return
      }
      if (retriesLeft > 0 && !cancelled) {
        const timer = setTimeout(() => { attempt(retriesLeft - 1) }, 120)
        cleanup.push(() => { clearTimeout(timer) })
      }
    }
    attempt(4)
    return () => {
      cancelled = true
      for (const dispose of cleanup) dispose()
    }
  }, [width, closing])

  // Re-clamp the width when the browser window resizes.
  useEffect(() => {
    const onWindowResize = (): void => {
      setWidth(prev => clampWidth(prev, maxPanelWidth(frameRef.current, window.innerWidth)))
    }
    window.addEventListener('resize', onWindowResize)
    return () => { window.removeEventListener('resize', onWindowResize) }
  }, [])

  // Exit choreography: while `closing`, the CSS transition slides the panel
  // out; report completion on the first transition event with a timer
  // fallback, and skip straight to the report under reduced motion.
  useEffect(() => {
    if (!closing) return
    const node = panelRef.current
    const reducedMotion = typeof window.matchMedia === 'function'
      && window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (node === null || reducedMotion) {
      onExited()
      return
    }
    let finished = false
    const finish = (): void => {
      if (finished) return
      finished = true
      onExited()
    }
    node.addEventListener('transitionend', finish, { once: true })
    const timer = setTimeout(finish, 240)
    return () => {
      clearTimeout(timer)
      node.removeEventListener('transitionend', finish)
    }
  }, [closing, onExited])

  // Drag handle: resize the column, clamped and persisted.
  const onHandlePointerDown = (event: React.PointerEvent<HTMLDivElement>): void => {
    dragStart.current = { x: event.clientX, width }
    event.currentTarget.setPointerCapture(event.pointerId)
  }
  const onHandlePointerMove = (event: React.PointerEvent<HTMLDivElement>): void => {
    const start = dragStart.current
    if (start === null) return
    const max = maxPanelWidth(frameRef.current, window.innerWidth)
    const next = clampWidth(start.width - (event.clientX - start.x), max)
    setWidth(next)
    try {
      localStorage.setItem(PANEL_WIDTH_STORAGE_KEY, String(next))
    } catch {
      // Storage can be unavailable (private mode); the width just stays in memory.
    }
  }
  const onHandlePointerUp = (event: React.PointerEvent<HTMLDivElement>): void => {
    dragStart.current = null
    event.currentTarget.releasePointerCapture(event.pointerId)
  }

  // Effective window bounds: preset windows or the custom inclusive-day range.
  const bounds = useMemo<{ from?: number; to?: number; valid: boolean }>(() => {
    if (rangeKey === 'custom') {
      const from = parseDateInput(customFrom)
      const to = parseDateInput(customTo)
      if (from === null || to === null || from > to) return { valid: false }
      return { from, to: endOfDayLocal(to), valid: true }
    }
    return { ...rangeBounds(rangeKey, Date.now()), valid: true }
  }, [rangeKey, customFrom, customTo])

  // Effective bucket duration: preset ms or the validated custom minute count.
  const bucketMs = useMemo(() => {
    if (bucketKey !== 'custom') return bucketPreset(bucketKey).ms
    return parseCustomBucketMinutes(customMinutes) ?? null
  }, [bucketKey, customMinutes])
  const bucketInvalid = bucketKey === 'custom' && bucketMs === null

  // Fetch on selection/range changes, on open, and on explicit refresh.
  useEffect(() => {
    const abort = new AbortController()
    if (!bounds.valid) {
      setLoad({ status: 'ready', value: { sessions: [] }, bounds })
      return () => { abort.abort() }
    }
    const windowBounds: { from?: number; to?: number } = {
      ...(bounds.from === undefined ? {} : { from: bounds.from }),
      ...(bounds.to === undefined ? {} : { to: bounds.to }),
    }
    setLoad({ status: 'loading', bounds: windowBounds })
    const ids = [...selection]
    fetchTimeline({ sessionIds: ids as SessionId[], ...windowBounds }, abort.signal)
      .then((value) => { setLoad({ status: 'ready', value, bounds: windowBounds }) })
      .catch((error: unknown) => {
        if (abort.signal.aborted) return
        setLoad({ status: 'error', message: error instanceof Error ? error.message : String(error), bounds: windowBounds })
      })
    return () => { abort.abort() }
  }, [selection, rangeKey, customFrom, customTo, bounds, refreshNonce, fetchTimeline])

  const sessionsState = useSessions(state => state)
  const workspacesState = useWorkspaces(state => state)
  const archived = useMemo(() => new Set(workspacesState.archivedSessionIds.map(String)), [workspacesState])

  // Sidebar-equivalent visibility: archived and subagent sessions hidden
  // unless their toggles are on; blank sessions only for the current one.
  const entries = useMemo(() => sessionsState.ids
    .filter((id) => {
      const summary = sessionsState.byId[id]
      if (summary === undefined) return false
      if (summary.origin === 'subagent' && !includeSubagents) return false
      if (archived.has(String(id)) && !showArchived) return false
      if (summary.blank === true && String(id) !== String(sessionId)) return false
      return true
    })
    .map((id) => {
      const title = sessionsState.byId[id]?.projectionValues?.title
      return {
        id,
        label: typeof title === 'string' && title !== '' ? title : fallbackSessionLabel(String(id)),
      }
    }), [sessionsState, archived, showArchived, includeSubagents, sessionId])

  const selectAll = (): void => { setSelection(new Set(entries.map(entry => String(entry.id)))) }
  const selectCurrent = (): void => { setSelection(new Set([String(sessionId)])) }
  const toggleSession = (id: SessionId): void => {
    setSelection((prev) => {
      const key = String(id)
      if (prev.has(key)) {
        if (prev.size === 1) return prev
        const next = new Set(prev)
        next.delete(key)
        return next
      }
      const next = new Set(prev)
      next.add(key)
      return next
    })
  }
  const retry = (): void => { setRefreshNonce(value => value + 1) }

  const projection = useMemo<TimelineProjectionResult | undefined>(() => {
    if (load.status !== 'ready' || bucketMs === null) return undefined
    return projectTimeline(
      load.value.sessions,
      bucketMs,
      load.bounds.from,
      load.bounds.to,
    )
  }, [load, bucketMs])

  const tableRows = useMemo(() => {
    if (projection?.kind !== 'ok') return []
    return entries
      .filter(entry => selection.has(String(entry.id)))
      .map(entry => ({ id: entry.id, label: entry.label, totals: projection.projection.perSession[String(entry.id)] }))
      .filter((row): row is { id: SessionId; label: string; totals: UsageTotals } => row.totals !== undefined)
      .sort((left, right) => right.totals.total - left.totals.total)
  }, [entries, selection, projection])

  return (
    <div
      className={`${css.panel}${closing ? ` ${css.closing}` : ''}`}
      ref={panelRef}
      style={{ width: `${width}px` }}
      role="dialog"
      aria-modal="true"
      aria-label={t('panel.title')}
    >
      <div
        className={css.dragHandle}
        onPointerDown={onHandlePointerDown}
        onPointerMove={onHandlePointerMove}
        onPointerUp={onHandlePointerUp}
        aria-hidden="true"
      />
      <header className={css.header}>
        <h2 className={css.title}>{t('panel.title')}</h2>
        <button type="button" className={css.close} aria-label={t('panel.close')} onClick={onRequestClose}>
          <IconCloseOutline16 size={14} />
        </button>
      </header>
      <div className={css.body}>
        <section className={css.controls} aria-label={t('sessions.label')}>
          <div className={css.controlRow}>
            <span className={css.controlLabel}>{t('sessions.label')}</span>
            <div className={css.controlActions}>
              <button type="button" className={css.controlButton} onClick={selectAll}>
                {t('sessions.all')}
              </button>
              <button type="button" className={css.controlButton} onClick={selectCurrent}>
                {t('sessions.current')}
              </button>
            </div>
          </div>
          <div className={css.controlRow}>
            <span className={css.controlLabel} />
            <div className={css.controlActions}>
              <label className={css.toggleLabel}>
                <input
                  type="checkbox"
                  checked={showArchived}
                  onChange={() => { setShowArchived(value => !value) }}
                />
                <span>{t('sessions.showArchived')}</span>
              </label>
              <label className={css.toggleLabel}>
                <input
                  type="checkbox"
                  checked={includeSubagents}
                  onChange={() => { setIncludeSubagents(value => !value) }}
                />
                <span>{t('sessions.includeSubagents')}</span>
              </label>
            </div>
          </div>
          <div className={css.sessionList}>
            {entries.map(entry => (
              <label key={String(entry.id)} className={css.sessionRow}>
                <input
                  type="checkbox"
                  checked={selection.has(String(entry.id))}
                  onChange={() => { toggleSession(entry.id) }}
                />
                <span className={css.sessionLabel}>{entry.label}</span>
              </label>
            ))}
          </div>
          <div className={css.controlRow}>
            <span className={css.controlLabel}>{t('bucket.label')}</span>
            <div className={css.controlActions} role="group" aria-label={t('bucket.label')}>
              {BUCKET_PRESETS.map(preset => (
                <button
                  key={preset.key}
                  type="button"
                  className={css.controlButton}
                  aria-pressed={bucketKey === preset.key}
                  onClick={() => { setBucketKey(preset.key) }}
                >
                  {t(BUCKET_LABEL_KEYS[preset.key])}
                </button>
              ))}
              <button
                type="button"
                className={css.controlButton}
                aria-pressed={bucketKey === 'custom'}
                onClick={() => { setBucketKey('custom') }}
              >
                {t('bucket.custom')}
              </button>
            </div>
          </div>
          {bucketKey === 'custom' && (
            <div className={css.controlRow}>
              <span className={css.controlLabel} />
              <div className={css.controlActions}>
                <input
                  className={css.numberInput}
                  type="number"
                  min={1}
                  max={1_440}
                  step={1}
                  value={customMinutes}
                  onChange={(event) => { setCustomMinutes(event.target.value) }}
                  aria-label={t('bucket.custom')}
                  aria-invalid={bucketInvalid || undefined}
                />
                <span className={css.controlHint}>{t('bucket.minutesSuffix')}</span>
                {bucketInvalid && <span className={css.invalidText}>{t('bucket.invalid')}</span>}
              </div>
            </div>
          )}
          <div className={css.controlRow}>
            <span className={css.controlLabel}>{t('range.label')}</span>
            <div className={css.controlActions} role="group" aria-label={t('range.label')}>
              {RANGE_PRESETS.map(preset => (
                <button
                  key={preset.key}
                  type="button"
                  className={css.controlButton}
                  aria-pressed={rangeKey === preset.key}
                  onClick={() => { setRangeKey(preset.key) }}
                >
                  {t(RANGE_LABEL_KEYS[preset.key])}
                </button>
              ))}
              <button
                type="button"
                className={css.controlButton}
                aria-pressed={rangeKey === 'custom'}
                onClick={() => { setRangeKey('custom') }}
              >
                {t('range.custom')}
              </button>
            </div>
          </div>
          {rangeKey === 'custom' && (
            <div className={css.controlRow}>
              <span className={css.controlLabel} />
              <div className={css.controlActions}>
                <span className={css.controlHint}>{t('range.from')}</span>
                <input
                  className={css.dateInput}
                  type="date"
                  value={customFrom}
                  onChange={(event) => { setCustomFrom(event.target.value) }}
                  aria-label={t('range.from')}
                />
                <span className={css.controlHint}>{t('range.to')}</span>
                <input
                  className={css.dateInput}
                  type="date"
                  value={customTo}
                  onChange={(event) => { setCustomTo(event.target.value) }}
                  aria-label={t('range.to')}
                />
                {!bounds.valid && <span className={css.invalidText}>{t('range.invalid')}</span>}
              </div>
            </div>
          )}
          <div className={css.controlRow}>
            <span className={css.controlLabel} />
            <div className={css.controlActions}>
              <button type="button" className={css.controlButton} onClick={retry}>
                <IconRefreshOutline14 size={12} />
                {t('refresh')}
              </button>
            </div>
          </div>
        </section>
        <main className={css.content}>
          <PanelContent
            load={load}
            projection={projection}
            tableRows={tableRows}
            bucketMs={bucketMs ?? 3_600_000}
            colors={colors}
            labels={labels}
            t={t}
            onRetry={retry}
          />
        </main>
      </div>
    </div>
  )
}

/** Chart-plus-totals body inputs the main panel computes. */
interface PanelContentProps {
  load: UsageLoad
  projection: TimelineProjectionResult | undefined
  tableRows: { id: SessionId; label: string; totals: UsageTotals }[]
  bucketMs: number
  colors: ReturnType<typeof readUsageColors>
  labels: { cacheRead: string; input: string; output: string }
  t: (key: TokenUsageKey) => string
  onRetry: () => void
}

/** Render the load-state-dependent body: error, loading, empty, or the chart with totals. */
function PanelContent({
  load, projection, tableRows, bucketMs, colors, labels, t, onRetry,
}: PanelContentProps) {
  if (load.status === 'error') {
    return (
      <div className={css.stateRow}>
        <span className={css.stateText}>{t('error.title')}：{load.message}</span>
        <button type="button" className={css.controlButton} onClick={onRetry}>{t('error.retry')}</button>
      </div>
    )
  }
  if (load.status === 'loading') {
    return (
      <div className={css.skeleton} role="status" aria-label={t('panel.loading')}>
        <div className={css.skeletonBlock} style={{ height: 220 }} />
        <div className={css.skeletonLine} />
        <div className={css.skeletonLine} style={{ width: '70%' }} />
      </div>
    )
  }
  if (projection === undefined || projection.kind === 'empty') {
    return <div className={css.stateRow}><span className={css.stateText}>{t('panel.empty')}</span></div>
  }
  if (projection.kind === 'too-many-buckets') {
    return <div className={css.stateRow}><span className={css.stateText}>{t('panel.tooManyBuckets')}</span></div>
  }
  const result = projection.projection
  return (
    <>
      <div className={css.totals}>
        <TotalsCell label={t('totals.cacheRead')} value={result.totals.cacheRead} />
        <TotalsCell label={t('totals.input')} value={result.totals.input} />
        <TotalsCell label={t('totals.output')} value={result.totals.output} />
        <TotalsCell label={t('totals.total')} value={result.totals.total} />
      </div>
      <UsageChart
        buckets={result.buckets}
        bucketMs={bucketMs}
        colors={colors}
        labels={labels}
        className={css.chart}
      />
      {tableRows.length > 0 && (
        <div className={css.tableWrap}>
          <table className={css.table}>
            <thead>
              <tr>
                <th>{t('table.session')}</th>
                <th>{t('totals.cacheRead')}</th>
                <th>{t('totals.input')}</th>
                <th>{t('totals.output')}</th>
                <th>{t('totals.total')}</th>
              </tr>
            </thead>
            <tbody>
              {tableRows.map(row => (
                <tr key={String(row.id)}>
                  <td>{row.label}</td>
                  <td>{formatTokensExact(row.totals.cacheRead)}</td>
                  <td>{formatTokensExact(row.totals.input)}</td>
                  <td>{formatTokensExact(row.totals.output)}</td>
                  <td>{formatTokensExact(row.totals.total)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </>
  )
}

/** One exact-numbered totals cell. */
function TotalsCell({ label, value }: { label: string; value: number }) {
  return (
    <div className={css.totalCell}>
      <span className={css.totalLabel}>{label}</span>
      <span className={css.totalValue}>{formatTokensExact(value)}</span>
    </div>
  )
}
