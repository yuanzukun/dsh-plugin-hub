/**
 * Browser-side pure timeline math: calendar-aligned local-time bucketing of
 * usage points, preset tables, exact-number formatting, and axis labels.
 * No React, no cordis — every function is a plain pure transform.
 * @module @deepseek-ai/dsh-token-usage/client
 */

import type { UsagePoint, UsageSessionSeries } from '../schemas.ts'

/** One chart granularity preset; `ms` always divides a 24-hour day exactly. */
export type BucketPresetKey = '15m' | '1h' | '1d'

/** One time-range preset; `ms` null means the complete history. */
export type RangePresetKey = '7d' | '30d' | 'all'

/** Bucket granularity table rendered as the granularity control. */
export interface BucketPreset {
  key: BucketPresetKey
  ms: number
}

/** Range table rendered as the range control. */
export interface RangePreset {
  key: RangePresetKey
  ms: number | null
}

/** Chart granularity options (ascending granularity). */
export const BUCKET_PRESETS: readonly BucketPreset[] = [
  { key: '15m', ms: 15 * 60_000 },
  { key: '1h', ms: 60 * 60_000 },
  { key: '1d', ms: 24 * 60 * 60_000 },
]

/** Chart range options. */
export const RANGE_PRESETS: readonly RangePreset[] = [
  { key: '7d', ms: 7 * 86_400_000 },
  { key: '30d', ms: 30 * 86_400_000 },
  { key: 'all', ms: null },
]

/** Hard cap on one projection's bucket count; beyond it the UI asks for a coarser granularity. */
export const MAX_TIMELINE_BUCKETS = 5_000

const DAY_MS = 86_400_000

/** One aggregated bucket: calendar-aligned start plus the three disjoint billing sums. */
export interface UsageBucket {
  /** Bucket start in Unix epoch milliseconds (local wall-clock aligned). */
  start: number
  cacheRead: number
  input: number
  output: number
}

/** The three disjoint billing sums plus their total. */
export interface UsageTotals {
  cacheRead: number
  input: number
  output: number
  total: number
}

/** The full chart projection: bucket series, grand totals, and per-session totals. */
export interface TimelineProjection {
  buckets: UsageBucket[]
  totals: UsageTotals
  perSession: Record<string, UsageTotals>
}

/** Projection outcome; `too-many-buckets` names the span the caller must shrink. */
export type TimelineProjectionResult =
  | { kind: 'ok'; projection: TimelineProjection }
  | { kind: 'empty' }
  | { kind: 'too-many-buckets'; count: number }

/** Local calendar-day start (epoch ms) of the timestamp's day. */
function localDayStart(date: Date): number {
  return new Date(date.getFullYear(), date.getMonth(), date.getDate()).getTime()
}

/**
 * Calendar-aligned bucket start for one timestamp, in the browser's local
 * zone. Alignment anchors on each local day (`dayStart + k * bucketMs`), so
 * buckets stay on local wall-clock boundaries across DST shifts; a duration
 * that does not divide the day leaves a partial tail bucket before midnight.
 * @param time - epoch ms.
 * @param bucketMs - bucket duration (any positive integer).
 * @returns the bucket's local-aligned start.
 */
export function bucketStartLocal(time: number, bucketMs: number): number {
  const date = new Date(time)
  const dayStart = localDayStart(date)
  return dayStart + Math.floor((time - dayStart) / bucketMs) * bucketMs
}

/**
 * Enumerate contiguous local-aligned bucket starts covering `[first, last]`,
 * walking calendar days so DST-length days keep wall-clock alignment. A
 * bucket duration that does not divide a day ends the day with one partial
 * bucket (its start stays `dayStart + k * bucketMs` under the next midnight).
 * @param first - inclusive first bucket start (already bucket-aligned).
 * @param last - inclusive last bucket start (already bucket-aligned).
 * @param bucketMs - bucket duration (any positive integer).
 * @returns ascending starts, or null when the span exceeds {@link MAX_TIMELINE_BUCKETS}.
 */
export function enumerateBucketStarts(first: number, last: number, bucketMs: number): number[] | null {
  const starts: number[] = []
  const cursor = new Date(first)
  for (;;) {
    const dayStart = localDayStart(cursor)
    if (dayStart > last) return starts
    const nextStart = localDayStart(new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate() + 1))
    for (let k = 0; dayStart + k * bucketMs < nextStart; k++) {
      const start = dayStart + k * bucketMs
      if (start > last) return starts
      if (start >= first) {
        starts.push(start)
        if (starts.length > MAX_TIMELINE_BUCKETS) return null
      }
    }
    cursor.setDate(cursor.getDate() + 1)
  }
}

/** Sum one series' disjoint buckets. */
export function sumTotals(points: readonly UsagePoint[]): UsageTotals {
  let cacheRead = 0
  let input = 0
  let output = 0
  for (const point of points) {
    cacheRead += point.cacheRead
    input += point.input
    output += point.output
  }
  return { cacheRead, input, output, total: cacheRead + input + output }
}

/** Exhaustive-switch helper for the closed preset unions. */
function assertNever(value: never): never {
  throw new Error(`token-usage: unexpected preset key ${JSON.stringify(value)}`)
}

/** Look up one granularity preset (closed union: the default arm is unreachable). */
export function bucketPreset(key: BucketPresetKey): BucketPreset {
  const preset = BUCKET_PRESETS.find(entry => entry.key === key)
  if (preset === undefined) return assertNever(key as never)
  return preset
}

/** Epoch-ms fetch window for one range preset; `all` leaves both bounds open. */
export function rangeBounds(rangeKey: RangePresetKey, now: number): { from?: number; to?: number } {
  const preset = RANGE_PRESETS.find(entry => entry.key === rangeKey)
  if (preset === undefined) return assertNever(rangeKey as never)
  return preset.ms === null ? {} : { from: now - preset.ms }
}

/**
 * Project selected sessions into one bucket series. Series are assumed
 * already window-filtered (the host folds them from the request window);
 * buckets are zero-filled across `[max(from, first point), min(to, last
 * point)]` so activity gaps stay visible on the axis.
 * @param sessions - the host's per-session series.
 * @param bucketMs - granularity.
 * @param from - window lower bound echoed by the caller, or undefined.
 * @param to - window upper bound echoed by the caller, or undefined.
 * @returns the projection, an empty marker, or the oversized-span marker.
 */
export function projectTimeline(
  sessions: readonly UsageSessionSeries[],
  bucketMs: number,
  from?: number,
  to?: number,
): TimelineProjectionResult {
  const perSession: Record<string, UsageTotals> = {}
  let minTime = Number.POSITIVE_INFINITY
  let maxTime = Number.NEGATIVE_INFINITY
  const points: UsagePoint[] = []
  for (const { sessionId, series } of sessions) {
    perSession[sessionId] = sumTotals(series)
    for (const point of series) {
      points.push(point)
      if (point.time < minTime) minTime = point.time
      if (point.time > maxTime) maxTime = point.time
    }
  }
  if (points.length === 0) return { kind: 'empty' }
  const first = bucketStartLocal(from === undefined ? minTime : Math.max(from, minTime), bucketMs)
  const last = bucketStartLocal(to === undefined ? maxTime : Math.min(to, maxTime), bucketMs)
  if (last < first) return { kind: 'empty' }
  const starts = enumerateBucketStarts(first, last, bucketMs)
  if (starts === null) return { kind: 'too-many-buckets', count: Math.floor((last - first) / bucketMs) + 1 }
  const index = new Map<number, number>()
  starts.forEach((start, position) => { index.set(start, position) })
  const buckets: UsageBucket[] = starts.map(start => ({ start, cacheRead: 0, input: 0, output: 0 }))
  for (const point of points) {
    const position = index.get(bucketStartLocal(point.time, bucketMs))
    if (position === undefined) continue
    const bucket = buckets[position] as UsageBucket
    bucket.cacheRead += point.cacheRead
    bucket.input += point.input
    bucket.output += point.output
  }
  const totals = buckets.reduce<UsageTotals>(
    (acc, bucket) => {
      acc.cacheRead += bucket.cacheRead
      acc.input += bucket.input
      acc.output += bucket.output
      acc.total += bucket.cacheRead + bucket.input + bucket.output
      return acc
    },
    { cacheRead: 0, input: 0, output: 0, total: 0 },
  )
  return { kind: 'ok', projection: { buckets, totals, perSession } }
}

/** Exact count with thousands grouping: `1,234,567`. */
export function formatTokensExact(tokens: number): string {
  return tokens.toLocaleString('en-US')
}

/** Two-digit zero-padded number. */
function pad(value: number): string {
  return value < 10 ? `0${value}` : String(value)
}

/** Axis label for one bucket start: `HH:mm` below a day, `MM-DD` for daily buckets, '' for invalid times. */
export function axisLabel(start: number, bucketMs: number): string {
  if (!Number.isFinite(start)) return ''
  const date = new Date(start)
  return bucketMs >= DAY_MS
    ? `${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
    : `${pad(date.getHours())}:${pad(date.getMinutes())}`
}

/** Allowed custom granularity: any integer minute count within one day. */
export const CUSTOM_BUCKET_MINUTES_MIN = 1
export const CUSTOM_BUCKET_MINUTES_MAX = 1_440

/**
 * Parse the custom granularity input into its bucket duration in ms.
 * @param input - the minutes field text.
 * @returns the bucket ms, or null when the input is not an integer minute count in range.
 */
export function parseCustomBucketMinutes(input: string): number | null {
  const trimmed = input.trim()
  if (!/^\d+$/.test(trimmed)) return null
  const minutes = Number(trimmed)
  if (!Number.isInteger(minutes) || minutes < CUSTOM_BUCKET_MINUTES_MIN || minutes > CUSTOM_BUCKET_MINUTES_MAX) {
    return null
  }
  return minutes * 60_000
}

/** Format an epoch-ms instant as a local `yyyy-MM-dd` date-input value. */
export function formatDateInput(time: number): string {
  const date = new Date(time)
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`
}

/**
 * Parse a `yyyy-MM-dd` date-input value into the local start-of-day epoch ms.
 * @param input - the date input value.
 * @returns local midnight epoch ms, or null when the value is not a real date.
 */
export function parseDateInput(input: string): number | null {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(input.trim())
  if (match === null) return null
  const year = Number(match[1])
  const month = Number(match[2])
  const day = Number(match[3])
  const date = new Date(year, month - 1, day)
  if (date.getFullYear() !== year || date.getMonth() !== month - 1 || date.getDate() !== day) return null
  return date.getTime()
}

/** Local end-of-day epoch ms (the instant just before the next local midnight). */
export function endOfDayLocal(dayStart: number): number {
  const date = new Date(dayStart)
  return new Date(date.getFullYear(), date.getMonth(), date.getDate() + 1).getTime() - 1
}

/** Short display name for a session row without a durable title. */
export function fallbackSessionLabel(sessionId: string): string {
  const separator = sessionId.indexOf('-')
  return separator <= 0 ? sessionId : `${sessionId.slice(0, separator)}…`
}
