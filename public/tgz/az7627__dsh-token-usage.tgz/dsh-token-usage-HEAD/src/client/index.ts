/** Browser half of the token usage plugin: header button + drawer registration. */
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client'
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client'
// Type-only merge edges: the locale Context seat and the conversation slot table.
import type {} from '@deepseek-ai/dsh-client-locale/client'
import type {} from '@deepseek-ai/dsh-client-ui-conversation/client'
import { fetchTimeline } from './controller.ts'
import { UsageHeaderAction, type UsageHeaderActionInjected } from './UsageHeaderAction.tsx'
import { NS, en, zh, type TokenUsageKey } from './locales.ts'

declare module '@deepseek-ai/dsh-client-ui-slots' {
  interface LocaleNamespaceMap {
    'token-usage': TokenUsageKey
  }
}

/** Services the browser half waits for. */
export const inject = ['slots', 'locale', 'connection']

/**
 * Register the locale dictionaries and mount the header-utilities entry.
 * @param ctx - browser context carrying slots, locale, and the connection.
 */
export function apply(ctx: ClientContext): void {
  const connection = ctx.get('connection') as ConnectionHandle
  ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'token-usage: browser dictionaries')
  ctx.slots.inject('conversation.session.header.utilities', () => ctx.slots.register({
    name: 'conversation.session.header.utilities',
    id: 'token-usage',
    locale: NS,
    inject: (): UsageHeaderActionInjected => ({
      fetchTimeline: (request, signal) => fetchTimeline(connection.rpc, request, signal),
    }),
  }, UsageHeaderAction))
}
