/**
 * Session-header entry: the usage button on the header's right edge plus the
 * portal-mounted right column it toggles. The column animates in on open and
 * stays mounted through its exit animation: the header control, the column's
 * own close control, and Escape all move the phase to `closing`, and only the
 * column's transition-completion report moves it to `closed`.
 */

import { useCallback, useState } from 'react'
import { createPortal } from 'react-dom'
import { IconDataOutline16 } from '@deepseek-ai/dsh-client-ui-primitives'
import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { UsageTimelineRequest, UsageTimelineValue } from '../schemas.ts'
import { NS } from './locales.ts'
import { UsagePanel } from './UsagePanel.tsx'
import css from './UsageHeaderAction.module.css'

/** Injected face: the browser fetch bound to the connection RPC caller. */
export interface UsageHeaderActionInjected {
  fetchTimeline: (request: UsageTimelineRequest, signal?: AbortSignal) => Promise<UsageTimelineValue>
}

/** Full props of the header-utilities contribution. */
export type UsageHeaderActionProps =
  PropsRuntime<'conversation.session.header.utilities'>
  & InjectFace<UsageHeaderActionInjected>
  & PropsLocale<typeof NS>

/** Panel lifecycle: hidden, fully open, or animating out before unmount. */
type PanelPhase = 'closed' | 'open' | 'closing'

/**
 * Render the header button and its portal column.
 * @param props - framework session kit, injected fetch, and locale seat.
 * @returns the button plus, while open or closing, the column portal.
 */
export function UsageHeaderAction({ sessionId, useSessions, useWorkspaces, fetchTimeline, t }: UsageHeaderActionProps) {
  const [phase, setPhase] = useState<PanelPhase>('closed')
  const handleExited = useCallback((): void => {
    setPhase(prev => (prev === 'closing' ? 'closed' : prev))
  }, [])
  const requestClose = useCallback((): void => {
    setPhase(prev => (prev === 'open' ? 'closing' : prev))
  }, [])
  const toggle = (): void => {
    setPhase(prev => (prev === 'open' ? 'closing' : 'open'))
  }
  return (
    <>
      <button
        type="button"
        className={css.usageButton}
        aria-expanded={phase !== 'closed'}
        onClick={toggle}
      >
        <IconDataOutline16 size={12} />
        <span>{t('button.label')}</span>
      </button>
      {phase !== 'closed' && createPortal(
        <UsagePanel
          sessionId={sessionId}
          useSessions={useSessions}
          useWorkspaces={useWorkspaces}
          fetchTimeline={fetchTimeline}
          closing={phase === 'closing'}
          onRequestClose={requestClose}
          onExited={handleExited}
          t={t}
        />,
        document.body,
      )}
    </>
  )
}
