/**
 * Wire contracts for the `/usage` RPC channel: the timeline request payload,
 * the per-request usage point, and the per-session series value. Both halves
 * consume these schemas — the host validates inbound requests and the browser
 * validates the response it parses off the wire.
 * @module @deepseek-ai/dsh-token-usage
 */

import { z } from 'zod'
import type { SessionId } from '@deepseek-ai/dsh-session'

/** Endpoint name served under the `/usage` channel. */
export const TIMELINE_ENDPOINT = 'timeline'

/** One brand cast after string-shape validation (the only cast point in this module). */
export const sessionIdSchema = z.string().min(1) as unknown as z.ZodType<SessionId>

/** Hard bound on one request: a listing this large is already a degenerate UI state. */
export const MAX_TIMELINE_SESSIONS = 500

/** One usage.timeline request: which sessions, and an optional epoch-ms time window. */
export const timelineRequestSchema = z.object({
  sessionIds: z.array(sessionIdSchema).min(1).max(MAX_TIMELINE_SESSIONS),
  from: z.number().int().nonnegative().optional(),
  to: z.number().int().nonnegative().optional(),
}).refine(
  request => request.from === undefined || request.to === undefined || request.from <= request.to,
  { message: 'from must not exceed to' },
)
export type UsageTimelineRequest = z.infer<typeof timelineRequestSchema>

/** One model call's disjoint billing buckets at a point in time. */
export interface UsagePoint {
  /** Event timestamp in Unix epoch milliseconds. */
  time: number
  /** Cached-input tokens the provider read from cache (cache hit). */
  cacheRead: number
  /** Uncached input tokens plus any cache-write tokens (disjoint from cacheRead). */
  input: number
  /** Completion tokens. */
  output: number
}

/** One session's usage points in ascending time order. */
export interface UsageSessionSeries {
  sessionId: string
  series: UsagePoint[]
}

/** usage.timeline response value: one series per requested session. */
export interface UsageTimelineValue {
  sessions: UsageSessionSeries[]
}

/** Wire validation for one usage point (all counts are non-negative integers). */
export const usagePointSchema = z.object({
  time: z.number().int().nonnegative(),
  cacheRead: z.number().int().nonnegative(),
  input: z.number().int().nonnegative(),
  output: z.number().int().nonnegative(),
})

/** Wire validation for one session series. */
export const usageSessionSeriesSchema = z.object({
  sessionId: z.string().min(1),
  series: z.array(usagePointSchema),
})

/** Wire validation for the usage.timeline response value. */
export const timelineValueSchema = z.object({
  sessions: z.array(usageSessionSeriesSchema),
})
