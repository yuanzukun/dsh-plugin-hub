/**
 * Fold a validated session log into per-request usage points. Each
 * `assistant/message` event carries the step's TokenUsage, so one step maps
 * to one point; chunks are never folded, which keeps the mapping duplicate-free.
 * @module @deepseek-ai/dsh-token-usage
 */

import type { SessionEvent } from '@deepseek-ai/dsh-session'
import type { UsagePoint } from './schemas.ts'

/** Hard bound on one response: crossing it fails the request rather than streaming an oversized payload. */
export const MAX_TIMELINE_POINTS = 100_000

/**
 * Fold usage-carrying assistant messages into one point per model step.
 * Points keep ascending time order (the log is ascending by seq, and seq
 * grows with time within one session). Events whose adapter reported no
 * usage, and all-zero reports, contribute nothing.
 * @param events - one session's raw validated log.
 * @param from - inclusive epoch-ms lower bound; absent = unbounded.
 * @param to - inclusive epoch-ms upper bound; absent = unbounded.
 * @returns the session's usage points.
 */
export function foldUsageSeries(
  events: readonly SessionEvent[],
  from?: number,
  to?: number,
): UsagePoint[] {
  const points: UsagePoint[] = []
  for (const event of events) {
    if (event.type !== 'assistant/message') continue
    if (from !== undefined && event.time < from) continue
    if (to !== undefined && event.time > to) continue
    const usage = event.data.usage
    if (usage === undefined) continue
    const cacheRead = usage.cacheReadTokens ?? 0
    const input = usage.inputTokens + (usage.cacheWriteTokens ?? 0)
    const output = usage.outputTokens
    if (cacheRead === 0 && input === 0 && output === 0) continue
    points.push({ time: event.time, cacheRead, input, output })
  }
  return points
}
