// Test-only primitives face: local copies of the three icons the plugin
// renders, so tests never resolve into the harness checkout.

interface IconProps {
  size?: number
  className?: string
}

/** ic_ds_data_outline_16 (copied from dsh-client-ui-primitives for tests). */
export function IconDataOutline16({ size = 16, className }: IconProps) {
  return (
    <svg width={size} height={size} className={className} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M1 1H15V15H1V1Z" stroke="currentColor" strokeWidth="1" />
      <path d="M4 4H12V12H4V4Z" fill="currentColor" />
    </svg>
  )
}

/** ic_ds_refresh_outline_14 (copied from dsh-client-ui-primitives for tests). */
export function IconRefreshOutline14({ size = 14, className }: IconProps) {
  return (
    <svg width={size} height={size} className={className} viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="7" cy="7" r="6" stroke="currentColor" strokeWidth="1" />
      <path d="M7 2V0.5" stroke="currentColor" strokeWidth="1" />
    </svg>
  )
}

/** ic_ds_close_outline_16 (copied from dsh-client-ui-primitives for tests). */
export function IconCloseOutline16({ size = 16, className }: IconProps) {
  return (
    <svg width={size} height={size} className={className} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 3L13 13M13 3L3 13" stroke="currentColor" strokeWidth="1.2" />
    </svg>
  )
}
