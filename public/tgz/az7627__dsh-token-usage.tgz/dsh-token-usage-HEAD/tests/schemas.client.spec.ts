/** Wire schema validation for the /usage channel: request bounds and value shape. */
import { describe, expect, it } from 'vitest'
import {
  MAX_TIMELINE_SESSIONS,
  timelineRequestSchema,
  timelineValueSchema,
} from '../src/schemas.ts'

const sessionId = (value: string) => value as never

describe('timelineRequestSchema', () => {
  it('accepts a single session without a window', () => {
    expect(timelineRequestSchema.parse({ sessionIds: [sessionId('a')] })).toEqual({ sessionIds: ['a'] })
  })

  it('accepts a bounded window with from <= to', () => {
    expect(timelineRequestSchema.parse({
      sessionIds: [sessionId('a')],
      from: 1_000,
      to: 2_000,
    })).toEqual({ sessionIds: ['a'], from: 1_000, to: 2_000 })
  })

  it('rejects an empty session list', () => {
    expect(timelineRequestSchema.safeParse({ sessionIds: [] }).success).toBe(false)
  })

  it('rejects more sessions than the cap', () => {
    const ids = Array.from({ length: MAX_TIMELINE_SESSIONS + 1 }, (_, index) => sessionId(`s${index}`))
    expect(timelineRequestSchema.safeParse({ sessionIds: ids }).success).toBe(false)
  })

  it('rejects an empty session id', () => {
    expect(timelineRequestSchema.safeParse({ sessionIds: [sessionId('')] }).success).toBe(false)
  })

  it('rejects from > to', () => {
    expect(timelineRequestSchema.safeParse({
      sessionIds: [sessionId('a')],
      from: 2_000,
      to: 1_000,
    }).success).toBe(false)
  })

  it('rejects fractional and negative bounds', () => {
    expect(timelineRequestSchema.safeParse({ sessionIds: [sessionId('a')], from: 1.5 }).success).toBe(false)
    expect(timelineRequestSchema.safeParse({ sessionIds: [sessionId('a')], to: -1 }).success).toBe(false)
  })
})

describe('timelineValueSchema', () => {
  it('accepts a valid series payload', () => {
    const value = {
      sessions: [{
        sessionId: 'a',
        series: [{ time: 1_000, cacheRead: 1, input: 2, output: 3 }],
      }],
    }
    expect(timelineValueSchema.parse(value)).toEqual(value)
  })

  it('rejects negative counts and fractional timestamps', () => {
    expect(timelineValueSchema.safeParse({
      sessions: [{ sessionId: 'a', series: [{ time: 1_000, cacheRead: -1, input: 2, output: 3 }] }],
    }).success).toBe(false)
    expect(timelineValueSchema.safeParse({
      sessions: [{ sessionId: 'a', series: [{ time: 1.5, cacheRead: 1, input: 2, output: 3 }] }],
    }).success).toBe(false)
  })
})
