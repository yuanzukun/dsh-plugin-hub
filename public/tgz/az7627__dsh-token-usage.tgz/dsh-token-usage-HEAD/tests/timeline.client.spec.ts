/** Pure timeline math: presets, local-calendar bucketing, exact formatting. */
import { describe, expect, it } from 'vitest'
import {
  MAX_TIMELINE_BUCKETS,
  axisLabel,
  bucketPreset,
  bucketStartLocal,
  endOfDayLocal,
  enumerateBucketStarts,
  fallbackSessionLabel,
  formatDateInput,
  formatTokensExact,
  parseCustomBucketMinutes,
  parseDateInput,
  projectTimeline,
  rangeBounds,
  sumTotals,
} from '../src/client/timeline.ts'

/** Epoch ms for a local wall-clock instant (TZ-independent via Date parts). */
function localMs(year: number, month: number, day: number, hour = 0, minute = 0): number {
  return new Date(year, month - 1, day, hour, minute).getTime()
}

describe('bucketStartLocal', () => {
  it('aligns hour and quarter-hour buckets to local wall clock', () => {
    expect(bucketStartLocal(localMs(2026, 8, 10, 14, 37), 3_600_000))
      .toBe(localMs(2026, 8, 10, 14))
    expect(bucketStartLocal(localMs(2026, 8, 10, 14, 37), 900_000))
      .toBe(localMs(2026, 8, 10, 14, 30))
  })

  it('aligns daily buckets to local midnight', () => {
    expect(bucketStartLocal(localMs(2026, 8, 10, 14, 37), 86_400_000))
      .toBe(localMs(2026, 8, 10))
  })
})

describe('enumerateBucketStarts', () => {
  it('emits contiguous buckets covering the inclusive span', () => {
    const first = localMs(2026, 8, 10, 14)
    expect(enumerateBucketStarts(first, localMs(2026, 8, 10, 16), 3_600_000))
      .toEqual([14, 15, 16].map(hour => localMs(2026, 8, 10, hour)))
  })

  it('returns null beyond the bucket cap', () => {
    const first = localMs(2026, 1, 1)
    const last = first + (MAX_TIMELINE_BUCKETS + 1) * 3_600_000
    expect(enumerateBucketStarts(first, last, 3_600_000)).toBeNull()
  })

  it('returns the single bucket when first equals last', () => {
    const first = localMs(2026, 8, 10, 14)
    expect(enumerateBucketStarts(first, first, 3_600_000)).toEqual([first])
  })

  it('ends the day with a partial bucket for a non-divisor duration', () => {
    // 7-minute buckets from midnight: …, 23:48, 23:55 (the 23:55-24:00 tail is partial).
    const first = localMs(2026, 8, 10, 23, 48)
    expect(enumerateBucketStarts(first, localMs(2026, 8, 10, 23, 59), 7 * 60_000))
      .toEqual([localMs(2026, 8, 10, 23, 48), localMs(2026, 8, 10, 23, 55)])
  })

  it('spans consecutive days with a non-divisor duration', () => {
    const first = localMs(2026, 8, 10, 23, 48)
    const starts = enumerateBucketStarts(first, localMs(2026, 8, 11, 0, 20), 7 * 60_000)
    expect(starts).toEqual([
      localMs(2026, 8, 10, 23, 48),
      localMs(2026, 8, 10, 23, 55),
      localMs(2026, 8, 11, 0, 0),
      localMs(2026, 8, 11, 0, 7),
      localMs(2026, 8, 11, 0, 14),
    ])
  })
})

describe('sumTotals', () => {
  it('sums the three disjoint buckets and their total', () => {
    expect(sumTotals([
      { time: 1, cacheRead: 1, input: 2, output: 3 },
      { time: 2, cacheRead: 4, input: 5, output: 6 },
    ])).toEqual({ cacheRead: 5, input: 7, output: 9, total: 21 })
  })

  it('returns zeros for an empty series', () => {
    expect(sumTotals([])).toEqual({ cacheRead: 0, input: 0, output: 0, total: 0 })
  })
})

describe('rangeBounds', () => {
  it('computes the from bound for windowed presets and none for all', () => {
    const now = 1_000_000_000
    expect(rangeBounds('7d', now)).toEqual({ from: now - 7 * 86_400_000 })
    expect(rangeBounds('30d', now)).toEqual({ from: now - 30 * 86_400_000 })
    expect(rangeBounds('all', now)).toEqual({})
  })

  it('throws for an unknown preset key', () => {
    expect(() => bucketPreset('1w' as never)).toThrow(/unexpected preset key/)
    expect(() => rangeBounds('1y' as never, 0)).toThrow(/unexpected preset key/)
  })
})

describe('projectTimeline', () => {
  const hour = 3_600_000

  it('is empty when no points exist', () => {
    expect(projectTimeline([{ sessionId: 'a', series: [] }], hour)).toEqual({ kind: 'empty' })
  })

  it('fills every bucket of the span, including activity gaps', () => {
    const start = localMs(2026, 8, 10, 14)
    const result = projectTimeline([{
      sessionId: 'a',
      series: [
        { time: start, cacheRead: 1, input: 2, output: 3 },
        { time: start + 2 * hour, cacheRead: 4, input: 5, output: 6 },
      ],
    }], hour)
    expect(result.kind).toBe('ok')
    if (result.kind !== 'ok') return
    expect(result.projection.buckets).toEqual([
      { start, cacheRead: 1, input: 2, output: 3 },
      { start: start + hour, cacheRead: 0, input: 0, output: 0 },
      { start: start + 2 * hour, cacheRead: 4, input: 5, output: 6 },
    ])
    expect(result.projection.totals).toEqual({ cacheRead: 5, input: 7, output: 9, total: 21 })
  })

  it('aggregates across sessions and keeps per-session totals', () => {
    const start = localMs(2026, 8, 10, 14)
    const result = projectTimeline([
      { sessionId: 'a', series: [{ time: start, cacheRead: 1, input: 2, output: 3 }] },
      { sessionId: 'b', series: [{ time: start, cacheRead: 4, input: 5, output: 6 }] },
    ], hour)
    expect(result.kind).toBe('ok')
    if (result.kind !== 'ok') return
    expect(result.projection.totals).toEqual({ cacheRead: 5, input: 7, output: 9, total: 21 })
    expect(result.projection.perSession).toEqual({
      a: { cacheRead: 1, input: 2, output: 3, total: 6 },
      b: { cacheRead: 4, input: 5, output: 6, total: 15 },
    })
  })

  it('anchors the span on the requested window around the points', () => {
    const from = localMs(2026, 8, 10, 12)
    const result = projectTimeline(
      [{ sessionId: 'a', series: [
        { time: localMs(2026, 8, 10, 11, 30), cacheRead: 1, input: 0, output: 0 },
        { time: localMs(2026, 8, 10, 14, 30), cacheRead: 1, input: 0, output: 0 },
      ] }],
      hour,
      from,
      localMs(2026, 8, 10, 15),
    )
    expect(result.kind).toBe('ok')
    if (result.kind !== 'ok') return
    expect(result.projection.buckets.map(bucket => bucket.start))
      .toEqual([12, 13, 14].map(hour => localMs(2026, 8, 10, hour)))
  })

  it('reports an oversized span instead of truncating', () => {
    const first = localMs(2026, 1, 1)
    const result = projectTimeline(
      [{ sessionId: 'a', series: [
        { time: first, cacheRead: 1, input: 0, output: 0 },
        { time: first + (MAX_TIMELINE_BUCKETS + 1) * hour, cacheRead: 1, input: 0, output: 0 },
      ] }],
      hour,
    )
    expect(result).toEqual({ kind: 'too-many-buckets', count: MAX_TIMELINE_BUCKETS + 2 })
  })

  it('is empty when every point falls outside the requested window', () => {
    const result = projectTimeline(
      [{ sessionId: 'a', series: [
        { time: localMs(2026, 8, 10, 11), cacheRead: 1, input: 0, output: 0 },
      ] }],
      hour,
      localMs(2026, 8, 10, 12),
      localMs(2026, 8, 10, 12, 30),
    )
    expect(result).toEqual({ kind: 'empty' })
  })
})

describe('formatTokensExact and axis labels', () => {
  it('groups thousands exactly without abbreviation', () => {
    expect(formatTokensExact(517)).toBe('517')
    expect(formatTokensExact(1_234_567)).toBe('1,234,567')
    expect(formatTokensExact(0)).toBe('0')
  })

  it('labels sub-day buckets as HH:mm and daily buckets as MM-DD', () => {
    const start = localMs(2026, 8, 5, 9, 5)
    expect(axisLabel(start, 3_600_000)).toBe('09:05')
    expect(axisLabel(start, 86_400_000)).toBe('08-05')
    expect(axisLabel(localMs(2026, 11, 23), 86_400_000)).toBe('11-23')
  })

  it('returns an empty label for invalid times', () => {
    expect(axisLabel(Number.NaN, 3_600_000)).toBe('')
  })
})

describe('fallbackSessionLabel', () => {
  it('shortens an id to its first segment', () => {
    expect(fallbackSessionLabel('abc123-def456')).toBe('abc123…')
    expect(fallbackSessionLabel('abc123')).toBe('abc123')
  })
})

describe('custom granularity and date helpers', () => {
  it('parses in-range integer minute counts into bucket ms', () => {
    expect(parseCustomBucketMinutes('30')).toBe(30 * 60_000)
    expect(parseCustomBucketMinutes('1440')).toBe(86_400_000)
    expect(parseCustomBucketMinutes(' 7 ')).toBe(7 * 60_000)
  })

  it('rejects out-of-range, fractional, and non-numeric minute counts', () => {
    expect(parseCustomBucketMinutes('0')).toBeNull()
    expect(parseCustomBucketMinutes('1441')).toBeNull()
    expect(parseCustomBucketMinutes('7.5')).toBeNull()
    expect(parseCustomBucketMinutes('abc')).toBeNull()
    expect(parseCustomBucketMinutes('')).toBeNull()
  })

  it('formats and parses yyyy-MM-dd date values symmetrically', () => {
    const day = localMs(2026, 8, 5)
    expect(formatDateInput(day)).toBe('2026-08-05')
    expect(parseDateInput('2026-08-05')).toBe(day)
    expect(parseDateInput('2026-8-5')).toBeNull()
    expect(parseDateInput('not-a-date')).toBeNull()
    expect(parseDateInput('2026-02-30')).toBeNull()
  })

  it('computes the inclusive local end of day', () => {
    expect(endOfDayLocal(localMs(2026, 8, 5))).toBe(localMs(2026, 8, 6) - 1)
  })
})
