/** Host fold: one point per usage-carrying assistant message, with window filtering. */
import { describe, expect, it } from 'vitest'
import { foldUsageSeries } from '../src/fold.ts'

function assistantEvent(seq: number, time: number, usage?: object): never {
  return {
    type: 'assistant/message',
    seq,
    time,
    data: {
      turn: 1,
      step: seq,
      message: { role: 'assistant', content: [] },
      ...(usage === undefined ? {} : { usage }),
    },
  } as never
}

describe('foldUsageSeries', () => {
  it('folds each usage-carrying step into one point with disjoint buckets', () => {
    const series = foldUsageSeries([
      assistantEvent(0, 1_000, { inputTokens: 10, outputTokens: 20, cacheReadTokens: 30 }),
      assistantEvent(1, 2_000, { inputTokens: 5, outputTokens: 0, cacheWriteTokens: 7 }),
    ])
    expect(series).toEqual([
      { time: 1_000, cacheRead: 30, input: 10, output: 20 },
      { time: 2_000, cacheRead: 0, input: 12, output: 0 },
    ])
  })

  it('skips events without usage and other event kinds', () => {
    const series = foldUsageSeries([
      { type: 'turn/start', seq: 0, time: 500, data: { turn: 1 } } as never,
      assistantEvent(1, 1_000),
      assistantEvent(2, 2_000, { inputTokens: 1, outputTokens: 2 }),
    ])
    expect(series).toEqual([{ time: 2_000, cacheRead: 0, input: 1, output: 2 }])
  })

  it('skips all-zero usage reports', () => {
    const series = foldUsageSeries([assistantEvent(0, 1_000, { inputTokens: 0, outputTokens: 0 })])
    expect(series).toEqual([])
  })

  it('filters points to the inclusive window', () => {
    const events = [
      assistantEvent(0, 1_000, { inputTokens: 1, outputTokens: 0 }),
      assistantEvent(1, 2_000, { inputTokens: 2, outputTokens: 0 }),
      assistantEvent(2, 3_000, { inputTokens: 3, outputTokens: 0 }),
    ]
    expect(foldUsageSeries(events, 2_000, 3_000)).toEqual([
      { time: 2_000, cacheRead: 0, input: 2, output: 0 },
      { time: 3_000, cacheRead: 0, input: 3, output: 0 },
    ])
    expect(foldUsageSeries(events, 2_000)).toHaveLength(2)
    expect(foldUsageSeries(events, undefined, 2_000)).toHaveLength(2)
  })

  it('preserves log order and defaults missing cache fields to zero', () => {
    const series = foldUsageSeries([
      assistantEvent(0, 1_000, { inputTokens: 3, outputTokens: 4, cacheReadTokens: 5, cacheWriteTokens: 6 }),
      assistantEvent(1, 2_000, { inputTokens: 1, outputTokens: 2 }),
    ])
    expect(series).toEqual([
      { time: 1_000, cacheRead: 5, input: 9, output: 4 },
      { time: 2_000, cacheRead: 0, input: 1, output: 2 },
    ])
  })
})
