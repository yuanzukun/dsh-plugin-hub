// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor } from '@testing-library/react'
import type { SessionListState, WorkspaceListState } from '@deepseek-ai/dsh-client-runtime/client'

const echartsMock = vi.hoisted(() => ({
  use: vi.fn(),
  init: vi.fn(() => ({ setOption: vi.fn(), dispose: vi.fn(), resize: vi.fn() })),
}))
vi.mock('echarts/core', () => ({
  use: (...components: unknown[]): void => { echartsMock.use(...components) },
  init: (): unknown => echartsMock.init(),
}))
vi.mock('echarts/charts', () => ({ BarChart: 'bar-chart' }))
vi.mock('echarts/components', () => ({
  DataZoomComponent: 'data-zoom',
  GridComponent: 'grid',
  LegendComponent: 'legend',
  TooltipComponent: 'tooltip',
}))
vi.mock('echarts/renderers', () => ({ CanvasRenderer: 'canvas' }))

import { UsageHeaderAction, type UsageHeaderActionProps } from '../src/client/UsageHeaderAction.tsx'
import { zh } from '../src/client/locales.ts'

const t: UsageHeaderActionProps['t'] = key => (zh as Record<string, string>)[key] ?? key
const HOUR = 3_600_000

function sessions(): SessionListState {
  return {
    ids: ['s1' as never],
    byId: { s1: { sessionId: 's1', blank: false, projectionValues: { title: '会话一' } } },
    current: 's1',
    phase: 'ready',
    subagentsByParent: {},
    jobsBySession: {},
  } as unknown as SessionListState
}

function workspaces(): WorkspaceListState {
  return {
    workspaces: [],
    archivedSessionIds: [],
    state: 'ready',
    phase: 'ready',
    error: null,
  } as unknown as WorkspaceListState
}

function mountAction() {
  const fetchTimeline = vi.fn()
  fetchTimeline.mockResolvedValue({
    sessions: [{
      sessionId: 's1',
      series: [{ time: Date.now() - HOUR, cacheRead: 10, input: 20, output: 30 }],
    }],
  })
  const props = {
    sessionId: 's1' as never,
    useSessions: (selector: (value: SessionListState) => unknown) => selector(sessions()),
    useWorkspaces: (selector: (value: WorkspaceListState) => unknown) => selector(workspaces()),
    fetchTimeline,
    t,
  } as unknown as UsageHeaderActionProps
  const view = render(<UsageHeaderAction {...props} />)
  return { view, fetchTimeline }
}

afterEach(() => {
  cleanup()
  vi.clearAllMocks()
})

describe('UsageHeaderAction', () => {
  it('renders the header button closed and opens the column on click', async () => {
    const { fetchTimeline } = mountAction()
    const button = screen.getByRole('button', { name: '用量统计' })
    expect(button.getAttribute('aria-expanded')).toBe('false')
    fireEvent.click(button)
    expect(button.getAttribute('aria-expanded')).toBe('true')
    expect(await screen.findByText('Token 用量统计')).toBeTruthy()
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
  })

  it('closes through the header control, the toggle button, and Escape', async () => {
    const { fetchTimeline } = mountAction()
    fireEvent.click(screen.getByRole('button', { name: '用量统计' }))
    expect(await screen.findByText('Token 用量统计')).toBeTruthy()
    expect(fetchTimeline).toHaveBeenCalledWith(
      expect.objectContaining({ sessionIds: ['s1'] }),
      expect.anything(),
    )
    fireEvent.click(screen.getByRole('button', { name: '关闭' }))
    await waitFor(() => { expect(screen.queryByText('Token 用量统计')).toBeNull() })
    fireEvent.click(screen.getByRole('button', { name: '用量统计' }))
    expect(await screen.findByText('Token 用量统计')).toBeTruthy()
    fireEvent.keyDown(document, { key: 'Escape' })
    await waitFor(() => { expect(screen.queryByText('Token 用量统计')).toBeNull() })
  })

  it('cancels the exit when reopened during closing without refetching', async () => {
    const { fetchTimeline } = mountAction()
    fireEvent.click(screen.getByRole('button', { name: '用量统计' }))
    await screen.findByText('Token 用量统计')
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
    fireEvent.click(screen.getByRole('button', { name: '关闭' }))
    fireEvent.click(screen.getByRole('button', { name: '用量统计' }))
    await new Promise(resolve => { setTimeout(resolve, 300) })
    expect(screen.queryByText('Token 用量统计')).toBeTruthy()
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
  })
})
