/** Browser fetch controller: wire validation and failure classification. */
import { describe, expect, it, vi } from 'vitest'
import type { ClientConnectionRpc } from '@deepseek-ai/dsh-client-connection/client'
import { fetchTimeline, UsageFetchError } from '../src/client/controller.ts'

type TimelineCall = ClientConnectionRpc['call']

/** One rpc stub plus its addressable mock. */
interface RpcStub {
  rpc: ClientConnectionRpc
  call: ReturnType<typeof vi.fn<TimelineCall>>
}

function rpc(): RpcStub {
  const call = vi.fn<TimelineCall>()
  return { rpc: { call }, call }
}

const request = { sessionIds: ['a'] as never } as never

describe('fetchTimeline', () => {
  it('calls the /usage channel and returns the validated value', async () => {
    const stub = rpc()
    stub.call.mockResolvedValue({
      ok: true,
      value: { sessions: [{ sessionId: 'a', series: [{ time: 1_000, cacheRead: 1, input: 2, output: 3 }] }] },
    })
    await expect(fetchTimeline(stub.rpc, request)).resolves.toEqual({
      sessions: [{ sessionId: 'a', series: [{ time: 1_000, cacheRead: 1, input: 2, output: 3 }] }],
    })
    expect(stub.call).toHaveBeenCalledWith('/usage', 'timeline', { sessionIds: ['a'] }, undefined)
  })

  it('classifies a host error by its code', async () => {
    const stub = rpc()
    stub.call.mockResolvedValue({
      ok: false,
      error: { code: 'session-not-found', message: 'session "x" not found', details: { sessionId: 'x' as never } },
    })
    const error = await fetchTimeline(stub.rpc, request).then(
      () => null,
      (reason: unknown) => reason as UsageFetchError,
    )
    expect(error).toBeInstanceOf(UsageFetchError)
    expect(error?.code).toBe('session-not-found')
    expect(error?.message).toBe('session "x" not found')
  })

  it('classifies a thrown transport failure as transport', async () => {
    const stub = rpc()
    stub.call.mockRejectedValue(new Error('HTTP 500'))
    const error = await fetchTimeline(stub.rpc, request).then(
      () => null,
      (reason: unknown) => reason as UsageFetchError,
    )
    expect(error?.code).toBe('transport')
    expect(error?.message).toBe('HTTP 500')
  })

  it('classifies a non-Error transport failure by its string form', async () => {
    const stub = rpc()
    stub.call.mockRejectedValue('boom')
    const error = await fetchTimeline(stub.rpc, request).then(
      () => null,
      (reason: unknown) => reason as UsageFetchError,
    )
    expect(error?.code).toBe('transport')
    expect(error?.message).toBe('boom')
  })

  it('classifies an unparseable response value as transport', async () => {
    const stub = rpc()
    stub.call.mockResolvedValue({ ok: true, value: { sessions: 'not-a-list' } })
    const error = await fetchTimeline(stub.rpc, request).then(
      () => null,
      (reason: unknown) => reason as UsageFetchError,
    )
    expect(error?.code).toBe('transport')
    expect(error?.message).toContain('invalid usage.timeline response')
  })

  it('validates the outbound request before calling', async () => {
    const stub = rpc()
    await expect(fetchTimeline(stub.rpc, { sessionIds: [] })).rejects.toThrow()
    expect(stub.call).not.toHaveBeenCalled()
  })

  it('forwards the caller signal', async () => {
    const stub = rpc()
    stub.call.mockResolvedValue({ ok: true, value: { sessions: [] } })
    const abort = new AbortController()
    await fetchTimeline(stub.rpc, request, abort.signal)
    expect(stub.call).toHaveBeenCalledWith('/usage', 'timeline', expect.anything(), abort.signal)
  })
})
