/** Pure echarts option builder: series/stack/zoom structure, colors, tooltip text. */
import { describe, expect, it } from 'vitest'
import {
  CHART_ZOOM_WINDOW_BUCKETS,
  buildUsageOption,
  normalizeTick,
  readUsageColors,
  usageTooltip,
} from '../src/client/chart-option.ts'

const colors = {
  cacheRead: '#a',
  input: '#b',
  output: '#c',
  text: '#d',
  grid: '#e',
}

const labels = { cacheRead: '缓存输入', input: '输入', output: '输出' }

function buckets(count: number): { start: number; cacheRead: number; input: number; output: number }[] {
  return Array.from({ length: count }, (_, index) => ({
    start: index * 3_600_000,
    cacheRead: index,
    input: index + 1,
    output: index + 2,
  }))
}

describe('buildUsageOption', () => {
  it('builds three stacked series over the bucket starts with exact tooltips', () => {
    const option = buildUsageOption(buckets(2), 3_600_000, colors, labels)
    const series = (option.series ?? []) as { name: string; stack: string; data: number[] }[]
    expect(series.map(entry => entry.name)).toEqual(['缓存输入', '输入', '输出'])
    expect(series.every(entry => entry.stack === 'usage')).toBe(true)
    expect(series[0]?.data).toEqual([0, 1])
    expect((option.xAxis as { data: number[] }).data).toEqual([0, 3_600_000])
    expect(option.dataZoom).toEqual([])
  })

  it('adds an inside plus slider zoom with a trailing window for long spans', () => {
    const option = buildUsageOption(buckets(CHART_ZOOM_WINDOW_BUCKETS + 1), 3_600_000, colors, labels)
    const zoom = option.dataZoom as { type?: string; start?: number; end?: number }[]
    expect(zoom.map(entry => entry.type)).toEqual(['inside', 'slider'])
    expect(zoom[1]?.end).toBe(100)
    expect(zoom[1]?.start).toBeLessThan(100)
  })

  it('formats axis labels through the local wall clock, whatever tick shape echarts passes', () => {
    const option = buildUsageOption(buckets(1), 3_600_000, colors, labels)
    const axis = option.xAxis as { axisLabel?: { formatter?: (tick: unknown) => string } }
    const start = new Date(2026, 7, 10, 9, 5).getTime()
    expect(axis.axisLabel?.formatter?.(start)).toBe('09:05')
    // ECharts' label-layout path wraps ticks as { value } and some paths
    // stringify them; both must format, and garbage must stay empty.
    expect(axis.axisLabel?.formatter?.({ value: start })).toBe('09:05')
    expect(axis.axisLabel?.formatter?.(String(start))).toBe('09:05')
    expect(axis.axisLabel?.formatter?.({ value: 'not-a-time' })).toBe('')
  })

  it('wires the tooltip formatter onto exact grouped series lines', () => {
    const start = new Date(2026, 7, 10, 9, 5).getTime()
    const option = buildUsageOption(
      [{ start, cacheRead: 1, input: 2, output: 3 }],
      3_600_000,
      colors,
      labels,
    )
    const tooltip = option.tooltip as { formatter?: (params: unknown) => string }
    expect(tooltip.formatter?.([
      { axisValue: start, seriesName: '输入', value: 1_234_567 },
      { axisValue: start, seriesName: '输出', value: 42 },
    ])).toBe('09:05<br/>输入：1,234,567<br/>输出：42')
  })
})

describe('normalizeTick', () => {
  it('accepts numbers, numeric strings, and wrapped tick objects', () => {
    expect(normalizeTick(1_000)).toBe(1_000)
    expect(normalizeTick('2000')).toBe(2_000)
    expect(normalizeTick({ value: 3_000 })).toBe(3_000)
    expect(normalizeTick({ value: '4000' })).toBe(4_000)
  })

  it('returns NaN for unusable values', () => {
    expect(normalizeTick(undefined)).toBeNaN()
    expect(normalizeTick({ value: 'garbage' })).toBeNaN()
    expect(normalizeTick('')).toBeNaN()
    expect(normalizeTick(null)).toBeNaN()
  })
})

describe('readUsageColors', () => {
  it('resolves theme tokens and falls back when absent', () => {
    const colorsNow = readUsageColors()
    expect(typeof colorsNow.cacheRead).toBe('string')
    expect(colorsNow.cacheRead.length).toBeGreaterThan(0)
    expect(colorsNow).toHaveProperty('input')
    expect(colorsNow).toHaveProperty('output')
    expect(colorsNow).toHaveProperty('text')
    expect(colorsNow).toHaveProperty('grid')
  })
})

describe('usageTooltip', () => {
  it('renders the bucket label and exact series lines', () => {
    const start = new Date(2026, 7, 10, 9, 5).getTime()
    const html = usageTooltip([
      { axisValue: start, seriesName: '输入', value: 1_234_567 },
      { axisValue: start, seriesName: '输出', value: 42 },
    ], 3_600_000)
    expect(html).toBe('09:05<br/>输入：1,234,567<br/>输出：42')
  })

  it('normalizes wrapped and stringified axis values', () => {
    const start = new Date(2026, 7, 10, 9, 5).getTime()
    expect(usageTooltip([{ axisValue: { value: start }, seriesName: '输出', value: 7 }], 3_600_000))
      .toBe('09:05<br/>输出：7')
    expect(usageTooltip([{ axisValue: String(start), seriesName: '输出', value: 7 }], 3_600_000))
      .toBe('09:05<br/>输出：7')
  })

  it('renders nothing for an empty payload', () => {
    expect(usageTooltip([], 3_600_000)).toBe('')
  })

  it('accepts a single item', () => {
    const start = new Date(2026, 7, 10, 9, 5).getTime()
    expect(usageTooltip({ axisValue: start, seriesName: '输出', value: 7 }, 3_600_000)).toBe('09:05<br/>输出：7')
  })
})
