// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render, screen, waitFor, within } from '@testing-library/react'
import type { SessionListState, WorkspaceListState } from '@deepseek-ai/dsh-client-runtime/client'

const echartsMock = vi.hoisted(() => ({
  use: vi.fn(),
  init: vi.fn(() => ({ setOption: vi.fn(), dispose: vi.fn(), resize: vi.fn() })),
}))
vi.mock('echarts/core', () => ({
  use: (...components: unknown[]): void => { echartsMock.use(...components) },
  init: (): unknown => echartsMock.init(),
}))
vi.mock('echarts/charts', () => ({ BarChart: 'bar-chart' }))
vi.mock('echarts/components', () => ({
  DataZoomComponent: 'data-zoom',
  GridComponent: 'grid',
  LegendComponent: 'legend',
  TooltipComponent: 'tooltip',
}))
vi.mock('echarts/renderers', () => ({ CanvasRenderer: 'canvas' }))

import { PANEL_WIDTH_FALLBACK_MAX, UsagePanel, maxPanelWidth, type UsagePanelProps } from '../src/client/UsagePanel.tsx'
import { readUsageColors } from '../src/client/chart-option.ts'
import { zh } from '../src/client/locales.ts'
import { MAX_TIMELINE_BUCKETS } from '../src/client/timeline.ts'

const t: UsagePanelProps['t'] = key => (zh as Record<string, string>)[key] ?? key
const HOUR = 3_600_000

type FetchTimelineMock = ReturnType<typeof vi.fn<UsagePanelProps['fetchTimeline']>>

function sessionsState(ids: string[], titles: Record<string, string>): SessionListState {
  return {
    ids: ids as never,
    byId: Object.fromEntries(ids.map(id => [id, {
      sessionId: id,
      blank: false,
      projectionValues: { title: titles[id] ?? null },
    }])),
    current: ids[0],
    phase: 'ready',
    subagentsByParent: {},
    jobsBySession: {},
  } as unknown as SessionListState
}

function workspacesState(archivedSessionIds: string[]): WorkspaceListState {
  return {
    workspaces: [],
    archivedSessionIds: archivedSessionIds as never,
    state: 'ready',
    phase: 'ready',
    error: null,
  } as unknown as WorkspaceListState
}

function mountPanel(
  overrides: Partial<UsagePanelProps> = {},
  configure?: (fetchTimeline: FetchTimelineMock) => void,
  archived: string[] = [],
) {
  const fetchTimeline = vi.fn<UsagePanelProps['fetchTimeline']>(async () => ({ sessions: [] }))
  configure?.(fetchTimeline)
  const onRequestClose = vi.fn()
  const sessions = sessionsState(['s1', 's2'], { s1: '会话一', s2: '会话二' })
  const props: UsagePanelProps = {
    sessionId: 's1' as never,
    useSessions: selector => selector(sessions),
    useWorkspaces: selector => selector(workspacesState(archived)),
    fetchTimeline,
    onRequestClose,
    onExited: vi.fn(),
    closing: false,
    t,
    ...overrides,
  }
  const view = render(<UsagePanel {...props} />)
  return { view, fetchTimeline, onRequestClose, sessions }
}

function seriesFor(sessionId: string, points: { time: number; cacheRead: number; input: number; output: number }[]) {
  return { sessionId, series: points }
}

afterEach(() => {
  cleanup()
  vi.clearAllMocks()
  document.body.innerHTML = ''
  localStorage.clear()
})

describe('UsagePanel', () => {
  it('fetches the current conversation on open and renders exact totals and the table', async () => {
    const start = Date.now() - 2 * 3_600_000
    const { fetchTimeline } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [
        { time: start, cacheRead: 12_345, input: 1_234_567, output: 89 },
      ])],
    }))
    expect(await screen.findByText('Token 用量统计')).toBeTruthy()
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
    const request = fetchTimeline.mock.calls[0]?.[0]
    expect(request?.sessionIds).toEqual(['s1'])
    expect(request?.from).toBeLessThanOrEqual(Date.now() - 29 * 86_400_000)
    expect((await screen.findAllByText('1,234,567')).length).toBeGreaterThan(0)
    expect(screen.getAllByText('12,345').length).toBeGreaterThan(0)
    expect(screen.getAllByText('89').length).toBeGreaterThan(0)
    expect(screen.getAllByText('1,247,001').length).toBeGreaterThan(0)
    expect(screen.getAllByText('会话一').length).toBeGreaterThan(0)
  })

  it('defaults to the current conversation and lists the others unchecked', async () => {
    mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    expect(await screen.findByRole('checkbox', { name: '会话一', checked: true })).toBeTruthy()
    expect(screen.getByRole('checkbox', { name: '会话二', checked: false })).toBeTruthy()
  })

  it('aggregates across selected conversations through the select-all shortcut', async () => {
    const { fetchTimeline } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    await screen.findByRole('checkbox', { name: '会话一' })
    fireEvent.click(screen.getByRole('button', { name: '全选' }))
    expect(screen.getByRole('checkbox', { name: '会话二', checked: true })).toBeTruthy()
    const last = fetchTimeline.mock.calls.at(-1)?.[0]
    expect(last?.sessionIds).toEqual(['s1', 's2'])
  })

  it('refetches on range changes and keeps granularity client-side', async () => {
    const { fetchTimeline } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    await screen.findByRole('checkbox', { name: '会话一' })
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
    fireEvent.click(screen.getByRole('button', { name: '15 分钟' }))
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
    fireEvent.click(screen.getByRole('button', { name: '近 7 天' }))
    expect(fetchTimeline).toHaveBeenCalledTimes(2)
    const request = fetchTimeline.mock.calls[1]?.[0]
    expect(request?.from).toBeLessThanOrEqual(Date.now() - 6 * 86_400_000)
  })

  it('shows the empty notice when the selected conversations have no usage', async () => {
    mountPanel({}, fetch => fetch.mockResolvedValue({ sessions: [seriesFor('s1', [])] }))
    expect(await screen.findByText('所选对话暂无用量数据')).toBeTruthy()
  })

  it('shows the error state with the host message and retries', async () => {
    const { fetchTimeline } = mountPanel({}, fetch => fetch.mockRejectedValue(new Error('persistence down')))
    expect(await screen.findByText('加载失败：persistence down')).toBeTruthy()
    fireEvent.click(screen.getByRole('button', { name: '重试' }))
    expect(fetchTimeline).toHaveBeenCalledTimes(2)
  })

  it('shows the string form of a non-Error rejection', async () => {
    mountPanel({}, fetch => fetch.mockRejectedValue('boom'))
    expect(await screen.findByText('加载失败：boom')).toBeTruthy()
  })

  it('asks for a coarser granularity when the span exceeds the bucket cap', async () => {
    const start = Date.now() - 10 * 86_400_000
    mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [
        { time: start, cacheRead: 1, input: 0, output: 0 },
        { time: start + (MAX_TIMELINE_BUCKETS + 1) * HOUR, cacheRead: 1, input: 0, output: 0 },
      ])],
    }))
    expect(await screen.findByText('时间跨度过大，请选择更粗的分度或更短的时间范围')).toBeTruthy()
  })

  it('keeps at least one conversation selected and closes on Escape', async () => {
    const { onRequestClose } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    const box = await screen.findByRole('checkbox', { name: '会话一' })
    fireEvent.click(box)
    expect(screen.getByRole('checkbox', { name: '会话一', checked: true })).toBeTruthy()
    fireEvent.keyDown(document, { key: 'Escape' })
    expect(onRequestClose).toHaveBeenCalledOnce()
  })

  it('resets the selection when the current conversation changes', async () => {
    const { fetchTimeline, view } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    await screen.findByRole('checkbox', { name: '会话一' })
    fireEvent.click(screen.getByRole('button', { name: '全选' }))
    view.rerender(<UsagePanel
      sessionId={'s2' as never}
      useSessions={selector => selector(sessionsState(['s1', 's2'], { s1: '会话一', s2: '会话二' }))}
      useWorkspaces={selector => selector(workspacesState([]))}
      fetchTimeline={fetchTimeline}
      onRequestClose={vi.fn()}
      onExited={vi.fn()}
      closing={false}
      t={t}
    />)
    expect(await screen.findByRole('checkbox', { name: '会话一', checked: false })).toBeTruthy()
    expect(screen.getByRole('checkbox', { name: '会话二', checked: true })).toBeTruthy()
  })

  it('toggles individual conversations on and off and resets through 仅当前', async () => {
    const { fetchTimeline } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    const second = await screen.findByRole('checkbox', { name: '会话二' })
    fireEvent.click(second)
    expect(screen.getByRole('checkbox', { name: '会话二', checked: true })).toBeTruthy()
    fireEvent.click(screen.getByRole('checkbox', { name: '会话二' }))
    expect(screen.getByRole('checkbox', { name: '会话二', checked: false })).toBeTruthy()
    expect(fetchTimeline).toHaveBeenCalledTimes(3)
    fireEvent.click(screen.getByRole('button', { name: '仅当前' }))
    expect(screen.getByRole('checkbox', { name: '会话一', checked: true })).toBeTruthy()
    expect(screen.getByRole('checkbox', { name: '会话二', checked: false })).toBeTruthy()
  })

  it('drops an aborted in-flight fetch instead of surfacing its rejection', async () => {
    mountPanel({}, fetch => fetch.mockImplementation(
      (_request, signal) => new Promise((_resolve, reject) => {
        signal?.addEventListener('abort', () => { reject(new Error('aborted')) })
      }),
    ))
    await screen.findByRole('checkbox', { name: '会话一' })
    fireEvent.click(screen.getByRole('button', { name: '近 7 天' }))
    expect(await screen.findByRole('status', { name: '加载中…' })).toBeTruthy()
    expect(screen.queryByText(/加载失败/)).toBeNull()
  })

  it('ignores non-Escape key presses', async () => {
    const { onRequestClose } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    await screen.findByRole('checkbox', { name: '会话一' })
    fireEvent.keyDown(document, { key: 'a' })
    expect(onRequestClose).not.toHaveBeenCalled()
  })

  it('falls back to a shortened id for untitled conversations and hides blank ones', async () => {
    const fetchTimeline = vi.fn<UsagePanelProps['fetchTimeline']>(async () => ({ sessions: [] }))
    const state = sessionsState(['s1', 's2', 's3'], { s1: '会话一' })
    const byId = state.byId as Record<string, unknown>
    byId['s2'] = { sessionId: 's2', blank: true, projectionValues: { title: null } }
    render(<UsagePanel
      sessionId={'s1' as never}
      useSessions={selector => selector(state)}
      useWorkspaces={selector => selector(workspacesState([]))}
      fetchTimeline={fetchTimeline}
      onRequestClose={vi.fn()}
      onExited={vi.fn()}
      closing={false}
      t={t}
    />)
    expect(await screen.findByRole('checkbox', { name: 's3' })).toBeTruthy()
    expect(screen.queryByRole('checkbox', { name: 's2' })).toBeNull()
  })

  it('hides archived conversations by default and reveals them through the toggle', async () => {
    mountPanel({}, fetch => fetch.mockResolvedValue({ sessions: [seriesFor('s1', [])] }), ['s2'])
    await screen.findByRole('checkbox', { name: '会话一' })
    expect(screen.queryByRole('checkbox', { name: '会话二' })).toBeNull()
    fireEvent.click(screen.getByRole('checkbox', { name: '显示已归档' }))
    expect(screen.getByRole('checkbox', { name: '会话二' })).toBeTruthy()
  })

  it('hides subagent conversations by default and reveals them through the toggle', async () => {
    const { sessions } = mountPanel({}, fetch => fetch.mockResolvedValue({ sessions: [seriesFor('s1', [])] }))
    const byId = sessions.byId as Record<string, unknown>
    byId['s2'] = { sessionId: 's2', blank: false, origin: 'subagent', projectionValues: { title: '子代理' } }
    await screen.findByRole('checkbox', { name: '会话一' })
    expect(screen.queryByRole('checkbox', { name: '子代理' })).toBeNull()
    fireEvent.click(screen.getByRole('checkbox', { name: '含子代理会话' }))
    expect(screen.getByRole('checkbox', { name: '子代理' })).toBeTruthy()
  })

  it('applies a custom minute granularity client-side and rejects invalid values', async () => {
    const { fetchTimeline } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    await screen.findByRole('checkbox', { name: '会话一' })
    const bucketGroup = screen.getByRole('group', { name: '分度' })
    fireEvent.click(within(bucketGroup).getByRole('button', { name: '自定义' }))
    const input = screen.getByRole('spinbutton', { name: '自定义' })
    fireEvent.change(input, { target: { value: '7' } })
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
    fireEvent.change(input, { target: { value: '0' } })
    expect(screen.getByText('请输入 1~1440 的整数分钟')).toBeTruthy()
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
  })

  it('fetches a custom inclusive-day range from the date pickers and rejects inverted ranges', async () => {
    const { fetchTimeline } = mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [seriesFor('s1', [])],
    }))
    await screen.findByRole('checkbox', { name: '会话一' })
    expect(fetchTimeline).toHaveBeenCalledTimes(1)
    const rangeGroup = screen.getByRole('group', { name: '时间范围' })
    fireEvent.click(within(rangeGroup).getByRole('button', { name: '自定义' }))
    fireEvent.change(screen.getByLabelText('起'), { target: { value: '2026-08-01' } })
    fireEvent.change(screen.getByLabelText('止'), { target: { value: '2026-08-10' } })
    // One fetch for the switch itself, one per date change: mount + 3.
    await waitFor(() => { expect(fetchTimeline).toHaveBeenCalledTimes(4) })
    const request = fetchTimeline.mock.calls.at(-1)?.[0]
    expect(request?.from).toBe(new Date(2026, 7, 1).getTime())
    expect(request?.to).toBe(new Date(2026, 7, 11).getTime() - 1)
    fireEvent.change(screen.getByLabelText('起'), { target: { value: '2026-08-20' } })
    expect(screen.getByText('起止日期无效')).toBeTruthy()
    expect(fetchTimeline).toHaveBeenCalledTimes(4)
  })

  it('reserves its width from the layout center column and yields to the details column', async () => {
    // Browser-normalized grid serialization (0px, comma space) plus a nested
    // scrollport, exercising the token matcher and the scrollport climb.
    class ResizeObserverMock {
      static active: ResizeObserverMock[] = []
      readonly callback: () => void
      constructor(callback: () => void) {
        this.callback = callback
        ResizeObserverMock.active.push(this)
      }
      observe(): void { this.callback() }
      disconnect(): void {}
    }
    globalThis.ResizeObserver = ResizeObserverMock as unknown as typeof ResizeObserver

    const frame = document.createElement('div')
    frame.style.gridTemplateColumns = '264px minmax(0px, 1fr) 0px'
    const sidebar = document.createElement('div')
    const center = document.createElement('div')
    const wrapper = document.createElement('div')
    const scrollport = document.createElement('div')
    scrollport.dataset.conversationScroll = 'true'
    wrapper.append(scrollport)
    center.append(wrapper)
    const details = document.createElement('div')
    frame.append(sidebar, center, details)
    document.body.append(frame)

    const { view } = mountPanel({}, fetch => fetch.mockResolvedValue({ sessions: [seriesFor('s1', [])] }))
    const dialog = await screen.findByRole('dialog', { name: 'Token 用量统计' })
    expect(center.style.marginRight).toBe('360px')
    expect(dialog.style.right).toBe('0px')

    frame.style.gridTemplateColumns = '264px minmax(0px, 1fr) 400px'
    for (const observer of ResizeObserverMock.active) observer.callback()
    expect(dialog.style.right).toBe('400px')

    view.unmount()
    expect(center.style.marginRight).toBe('')
    delete (globalThis as { ResizeObserver?: unknown }).ResizeObserver
  })

  it('resizes through the drag handle and persists the width', async () => {
    const { fetchTimeline } = mountPanel({}, fetch => fetch.mockResolvedValue({ sessions: [seriesFor('s1', [])] }))
    const panel = await screen.findByRole('dialog', { name: 'Token 用量统计' })
    const handle = panel.querySelector('div') as HTMLDivElement
    Object.assign(handle, {
      setPointerCapture: vi.fn(),
      releasePointerCapture: vi.fn(),
    })
    fireEvent.pointerDown(handle, { clientX: 400, pointerId: 1 })
    fireEvent.pointerMove(handle, { clientX: 340, pointerId: 1 })
    expect(panel.style.width).toBe('420px')
    expect(localStorage.getItem('dsh-token-usage.width')).toBe('420')
    fireEvent.pointerUp(handle, { clientX: 340, pointerId: 1 })
  })

  it('derives the drag ceiling from half the conversation area', () => {
    const frame = document.createElement('div')
    frame.style.gridTemplateColumns = '264px minmax(0px, 1fr) 400px'
    expect(maxPanelWidth(frame, 1024)).toBe(300)
    frame.style.gridTemplateColumns = '264px minmax(0px, 1fr) 0px'
    expect(maxPanelWidth(frame, 1024)).toBe(380)
    expect(maxPanelWidth(null, 1024)).toBe(PANEL_WIDTH_FALLBACK_MAX)
  })

  it('clamps the drag width to half the conversation area', async () => {
    class ResizeObserverMock {
      static active: ResizeObserverMock[] = []
      readonly callback: () => void
      constructor(callback: () => void) {
        this.callback = callback
        ResizeObserverMock.active.push(this)
      }
      observe(): void {}
      disconnect(): void {}
    }
    globalThis.ResizeObserver = ResizeObserverMock as unknown as typeof ResizeObserver
    const frame = document.createElement('div')
    frame.style.gridTemplateColumns = '264px minmax(0px, 1fr) 0px'
    const center = document.createElement('div')
    const scrollport = document.createElement('div')
    scrollport.dataset.conversationScroll = 'true'
    center.append(scrollport)
    frame.append(document.createElement('div'), center, document.createElement('div'))
    document.body.append(frame)

    const { view } = mountPanel({}, fetch => fetch.mockResolvedValue({ sessions: [seriesFor('s1', [])] }))
    const panel = await screen.findByRole('dialog', { name: 'Token 用量统计' })
    const handle = panel.querySelector('div') as HTMLDivElement
    Object.assign(handle, {
      setPointerCapture: vi.fn(),
      releasePointerCapture: vi.fn(),
    })
    fireEvent.pointerDown(handle, { clientX: 400, pointerId: 1 })
    // A 760px-wide drag request clamps to (1024 - 264) / 2 = 380.
    fireEvent.pointerMove(handle, { clientX: -400, pointerId: 1 })
    expect(panel.style.width).toBe('380px')
    view.unmount()
    delete (globalThis as { ResizeObserver?: unknown }).ResizeObserver
  })

  it('clamps a stored width to the conversation area on open', async () => {
    class ResizeObserverMock {
      static active: ResizeObserverMock[] = []
      readonly callback: () => void
      constructor(callback: () => void) {
        this.callback = callback
        ResizeObserverMock.active.push(this)
      }
      observe(): void {}
      disconnect(): void {}
    }
    globalThis.ResizeObserver = ResizeObserverMock as unknown as typeof ResizeObserver
    localStorage.setItem('dsh-token-usage.width', '5000')
    const frame = document.createElement('div')
    frame.style.gridTemplateColumns = '264px minmax(0px, 1fr) 0px'
    const center = document.createElement('div')
    const scrollport = document.createElement('div')
    scrollport.dataset.conversationScroll = 'true'
    center.append(scrollport)
    frame.append(document.createElement('div'), center, document.createElement('div'))
    document.body.append(frame)

    const { view } = mountPanel({}, fetch => fetch.mockResolvedValue({ sessions: [seriesFor('s1', [])] }))
    const panel = await screen.findByRole('dialog', { name: 'Token 用量统计' })
    expect(panel.style.width).toBe('380px')
    view.unmount()
    delete (globalThis as { ResizeObserver?: unknown }).ResizeObserver
  })

  it('releases the center margin and reports exit when closing', async () => {
    class ResizeObserverMock {
      static active: ResizeObserverMock[] = []
      readonly callback: () => void
      constructor(callback: () => void) {
        this.callback = callback
        ResizeObserverMock.active.push(this)
      }
      observe(): void { this.callback() }
      disconnect(): void {}
    }
    globalThis.ResizeObserver = ResizeObserverMock as unknown as typeof ResizeObserver
    const frame = document.createElement('div')
    frame.style.gridTemplateColumns = '264px minmax(0px, 1fr) 0px'
    const center = document.createElement('div')
    const scrollport = document.createElement('div')
    scrollport.dataset.conversationScroll = 'true'
    center.append(scrollport)
    frame.append(document.createElement('div'), center, document.createElement('div'))
    document.body.append(frame)

    const fetchTimeline = vi.fn<UsagePanelProps['fetchTimeline']>(async () => ({
      sessions: [seriesFor('s1', [])],
    }))
    const onExited = vi.fn()
    const sessions = sessionsState(['s1', 's2'], { s1: '会话一', s2: '会话二' })
    const props = (closing: boolean): UsagePanelProps => ({
      sessionId: 's1' as never,
      useSessions: selector => selector(sessions),
      useWorkspaces: selector => selector(workspacesState([])),
      fetchTimeline,
      onRequestClose: vi.fn(),
      onExited,
      closing,
      t,
    })
    const view = render(<UsagePanel {...props(false)} />)
    const dialog = await screen.findByRole('dialog', { name: 'Token 用量统计' })
    expect(center.style.marginRight).toBe('360px')
    view.rerender(<UsagePanel {...props(true)} />)
    expect(center.style.marginRight).toBe('0px')
    dialog.dispatchEvent(new Event('transitionend'))
    expect(onExited).toHaveBeenCalledOnce()
    view.unmount()
    expect(center.style.marginRight).toBe('')
    delete (globalThis as { ResizeObserver?: unknown }).ResizeObserver
  })

  it('reports exit immediately under reduced motion', async () => {
    const matchMedia = vi.fn(() => ({ matches: true }))
    window.matchMedia = matchMedia as unknown as typeof window.matchMedia
    const onExited = vi.fn()
    const { view } = mountPanel({ onExited }, fetch => fetch.mockResolvedValue({ sessions: [seriesFor('s1', [])] }))
    await screen.findByRole('dialog', { name: 'Token 用量统计' })
    const sessions = sessionsState(['s1', 's2'], { s1: '会话一', s2: '会话二' })
    const fetchTimeline = vi.fn<UsagePanelProps['fetchTimeline']>(async () => ({ sessions: [] }))
    view.rerender(<UsagePanel
      sessionId={'s1' as never}
      useSessions={selector => selector(sessions)}
      useWorkspaces={selector => selector(workspacesState([]))}
      fetchTimeline={fetchTimeline}
      onRequestClose={vi.fn()}
      onExited={onExited}
      closing
      t={t}
    />)
    expect(onExited).toHaveBeenCalledOnce()
    delete (window as { matchMedia?: unknown }).matchMedia
  })

  it('sorts the per-conversation table by total descending', async () => {
    const start = Date.now() - 2 * HOUR
    mountPanel({}, fetch => fetch.mockResolvedValue({
      sessions: [
        seriesFor('s1', [{ time: start, cacheRead: 0, input: 10, output: 0 }]),
        seriesFor('s2', [{ time: start, cacheRead: 0, input: 100, output: 0 }]),
      ],
    }))
    await screen.findByText('Token 用量统计')
    fireEvent.click(screen.getByRole('button', { name: '全选' }))
    const rows = await screen.findAllByRole('row')
    const firstDataRow = rows[1]?.textContent ?? ''
    expect(firstDataRow).toContain('会话二')
  })

  it('resolves chart colors from theme tokens', async () => {
    document.documentElement.style.setProperty('--dsw-alias-state-warn-primary', '#123456')
    const colors = readUsageColors()
    expect(colors.cacheRead).toBe('#123456')
    expect(colors.input.length).toBeGreaterThan(0)
  })
})
