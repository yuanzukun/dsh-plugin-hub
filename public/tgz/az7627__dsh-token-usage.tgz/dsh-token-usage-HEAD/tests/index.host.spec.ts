/**
 * Host half of the usage timeline channel: registration, payload validation,
 * the live-session direct fold, the persisted batch projection, the
 * sequential fallback, error classification, cancellation, and the point cap.
 */

import { describe, expect, it, vi } from 'vitest'
import type { RpcResult } from '@deepseek-ai/dsh-host-apiproxy/api'
import { apply } from '../src/index.ts'
import { MAX_TIMELINE_POINTS } from '../src/fold.ts'
import type { UsageTimelineValue } from '../src/schemas.ts'

/** One assistant/message event carrying the requested usage. */
function usageEvent(time: number, cacheRead = 0, input = 0, output = 0): unknown {
  return {
    type: 'assistant/message',
    time,
    data: { usage: { inputTokens: input, outputTokens: output, cacheReadTokens: cacheRead } },
  }
}

interface SessionsFace {
  get(id: string): { events: readonly unknown[] } | undefined
}

interface BootOptions {
  sessions?: SessionsFace
  readSession?: ReturnType<typeof vi.fn>
  projectMany?: ReturnType<typeof vi.fn>
}

/** Boot the host plugin over fake services and capture the registered handler. */
function boot(options: BootOptions = {}) {
  const sessions = options.sessions ?? { get: () => undefined }
  const query = {
    readSession: options.readSession ?? vi.fn(),
    ...(options.projectMany === undefined ? {} : { projectMany: options.projectMany }),
  }
  let handler: ((endpoint: string, payload: unknown, signal: AbortSignal) => Promise<RpcResult<unknown>>) | undefined
  const connection = {
    rpc: {
      handle: vi.fn((_channel: string, registered: typeof handler) => {
        handler = registered
        return async () => {}
      }),
    },
  }
  const ctx = {
    get: (name: string) => {
      if (name === 'connection') return connection
      if (name === 'sessionQuery') return query
      if (name === 'sessions') return sessions
      return undefined
    },
    effect: vi.fn((setup: () => unknown) => {
      setup()
      return () => {}
    }),
  }
  apply(ctx as never)
  const call = (
    endpoint: string,
    payload: unknown,
    signal: Partial<AbortSignal> = { aborted: false },
  ): Promise<RpcResult<unknown>> => (handler as never)(endpoint, payload, signal as AbortSignal)
  return { call, connection, query }
}

function okValue(result: RpcResult<unknown>): UsageTimelineValue {
  if (!result.ok) throw new Error(`expected ok result, got ${JSON.stringify(result)}`)
  return result.value as UsageTimelineValue
}

describe('token-usage host channel', () => {
  it('registers the /usage channel with trusted-host authority (remote phones can read it)', () => {
    const { connection } = boot()
    expect(connection.rpc.handle).toHaveBeenCalledWith('/usage', expect.any(Function), { authority: 'trusted-host' })
  })

  it('rejects unknown endpoints and invalid payloads as bad-request', async () => {
    const { call } = boot()
    const unknown = await call('other', {})
    expect(unknown).toMatchObject({ ok: false, error: { code: 'bad-request' } })
    const invalid = await call('timeline', { sessionIds: [] })
    expect(invalid).toMatchObject({ ok: false, error: { code: 'bad-request' } })
  })

  it('folds live sessions directly without touching the query service', async () => {
    const { call, query } = boot({
      sessions: {
        get: id => id === 's1' ? { events: [usageEvent(1000, 5, 10, 20)] } : undefined,
      },
    })
    const result = await call('timeline', { sessionIds: ['s1'] })
    expect(okValue(result)).toEqual({
      sessions: [{ sessionId: 's1', series: [{ time: 1000, cacheRead: 5, input: 10, output: 20 }] }],
    })
    expect(query.readSession).not.toHaveBeenCalled()
  })

  it('batches persisted sessions through the query projector', async () => {
    const projectMany = vi.fn(async (ids: string[], project: (source: { events: readonly unknown[] }) => unknown) => {
      const points = project({ events: [usageEvent(2000, 0, 0, 7)] })
      return ids.map(id => ({ sessionId: id, status: 'fulfilled', value: points }))
    })
    const { call, query } = boot({ projectMany })
    const result = await call('timeline', { sessionIds: ['s1', 's2'] })
    expect(okValue(result).sessions).toEqual([
      { sessionId: 's1', series: [{ time: 2000, cacheRead: 0, input: 0, output: 7 }] },
      { sessionId: 's2', series: [{ time: 2000, cacheRead: 0, input: 0, output: 7 }] },
    ])
    expect(projectMany).toHaveBeenCalledWith(['s1', 's2'], expect.any(Function), expect.anything())
    expect(query.readSession).not.toHaveBeenCalled()
  })

  it('folds a live session and a persisted one in one request', async () => {
    const projectMany = vi.fn(async (ids: string[], project: (source: { events: readonly unknown[] }) => unknown) => {
      const points = project({ events: [usageEvent(2000, 0, 0, 7)] })
      return ids.map(id => ({ sessionId: id, status: 'fulfilled', value: points }))
    })
    const { call } = boot({
      sessions: { get: id => id === 's1' ? { events: [usageEvent(1000, 1, 0, 0)] } : undefined },
      projectMany,
    })
    const result = await call('timeline', { sessionIds: ['s1', 's2'] })
    expect(okValue(result).sessions.map(entry => entry.sessionId)).toEqual(['s1', 's2'])
    expect(projectMany).toHaveBeenCalledWith(['s2'], expect.any(Function), expect.anything())
  })

  it('falls back to sequential readSession when the projector is absent', async () => {
    const readSession = vi.fn(async (id: string) => ({ events: [usageEvent(3000, 0, 1, 0)] }))
    const { call } = boot({ readSession })
    const result = await call('timeline', { sessionIds: ['s1', 's2'] })
    expect(okValue(result).sessions).toHaveLength(2)
    expect(readSession).toHaveBeenCalledTimes(2)
    expect(readSession).toHaveBeenNthCalledWith(1, 's1')
    expect(readSession).toHaveBeenNthCalledWith(2, 's2')
  })

  it('classifies a rejected missing session as session-not-found', async () => {
    const projectMany = vi.fn(async () => [{
      sessionId: 's1',
      status: 'rejected',
      reason: Object.assign(new Error('gone'), { code: 'SESSION_QUERY_SESSION_NOT_FOUND' }),
    }])
    const { call } = boot({ projectMany })
    const result = await call('timeline', { sessionIds: ['s1'] })
    expect(result).toMatchObject({ ok: false, error: { code: 'session-not-found' } })
  })

  it('classifies other projection rejections and throws as internal', async () => {
    const rejected = boot({
      projectMany: vi.fn(async () => [{ sessionId: 's1', status: 'rejected', reason: new Error('disk') }]),
    })
    const rejectedResult = await rejected.call('timeline', { sessionIds: ['s1'] })
    expect(rejectedResult).toMatchObject({ ok: false, error: { code: 'internal', message: 'disk' } })

    const thrown = boot({
      projectMany: vi.fn(async () => { throw new Error('backend down') }),
    })
    const thrownResult = await thrown.call('timeline', { sessionIds: ['s1'] })
    expect(thrownResult).toMatchObject({ ok: false, error: { code: 'internal', message: 'backend down' } })
  })

  it('maps readSession failures onto the same codes in the fallback path', async () => {
    const missing = boot({
      readSession: vi.fn(async () => {
        throw Object.assign(new Error('gone'), { code: 'SESSION_QUERY_SESSION_NOT_FOUND' })
      }),
    })
    const missingResult = await missing.call('timeline', { sessionIds: ['s1'] })
    expect(missingResult).toMatchObject({ ok: false, error: { code: 'session-not-found' } })

    const broken = boot({
      readSession: vi.fn(async () => { throw new Error('io') }),
    })
    const brokenResult = await broken.call('timeline', { sessionIds: ['s1'] })
    expect(brokenResult).toMatchObject({ ok: false, error: { code: 'internal', message: 'io' } })
  })

  it('reports cancellation when the carrier aborts during a batch', async () => {
    const signal: { aborted: boolean } = { aborted: false }
    const projectMany = vi.fn(async () => {
      signal.aborted = true
      return []
    })
    const { call } = boot({ projectMany })
    const result = await call('timeline', { sessionIds: ['s1'] }, signal)
    expect(result).toMatchObject({ ok: false, error: { code: 'cancelled' } })
  })

  it('reports an already-aborted carrier before any read', async () => {
    const { call, query } = boot({
      sessions: { get: () => ({ events: [usageEvent(1, 1, 0, 0)] }) },
    })
    const result = await call('timeline', { sessionIds: ['s1'] }, { aborted: true })
    expect(result).toMatchObject({ ok: false, error: { code: 'cancelled' } })
    expect(query.readSession).not.toHaveBeenCalled()
  })

  it('fails the request when the combined points exceed the cap', async () => {
    const events = Array.from({ length: MAX_TIMELINE_POINTS + 1 }, (_, index) => usageEvent(index, 1, 0, 0))
    const { call } = boot({
      sessions: { get: () => ({ events }) },
    })
    const result = await call('timeline', { sessionIds: ['s1'] })
    expect(result).toMatchObject({
      ok: false,
      error: { code: 'bad-request', message: expect.stringContaining('too large') },
    })
  })

  it('folds only points inside the requested window', async () => {
    const { call } = boot({
      sessions: {
        get: () => ({ events: [usageEvent(1, 1, 0, 0), usageEvent(5, 0, 1, 0), usageEvent(9, 0, 0, 1)] }),
      },
    })
    const result = await call('timeline', { sessionIds: ['s1'], from: 3, to: 6 })
    expect(okValue(result).sessions[0]?.series).toEqual([{ time: 5, cacheRead: 0, input: 1, output: 0 }])
  })
})
