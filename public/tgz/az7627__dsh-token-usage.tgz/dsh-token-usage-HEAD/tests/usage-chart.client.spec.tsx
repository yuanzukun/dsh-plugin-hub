// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from 'vitest'
import { cleanup, fireEvent, render } from '@testing-library/react'

const echartsMock = vi.hoisted(() => ({
  use: vi.fn(),
  init: vi.fn(),
  setOption: vi.fn(),
  dispose: vi.fn(),
  resize: vi.fn(),
}))

vi.mock('echarts/core', () => ({
  use: (...components: unknown[]): void => { echartsMock.use(...components) },
  init: (): unknown => {
    echartsMock.init()
    return { setOption: echartsMock.setOption, dispose: echartsMock.dispose, resize: echartsMock.resize }
  },
}))
vi.mock('echarts/charts', () => ({ BarChart: 'bar-chart' }))
vi.mock('echarts/components', () => ({
  DataZoomComponent: 'data-zoom',
  GridComponent: 'grid',
  LegendComponent: 'legend',
  TooltipComponent: 'tooltip',
}))
vi.mock('echarts/renderers', () => ({ CanvasRenderer: 'canvas' }))

import { UsageChart } from '../src/client/UsageChart.tsx'

const colors = { cacheRead: '#a', input: '#b', output: '#c', text: '#d', grid: '#e' }
const labels = { cacheRead: '缓存输入', input: '输入', output: '输出' }
const buckets = [{ start: 0, cacheRead: 1, input: 2, output: 3 }]

afterEach(() => {
  cleanup()
  vi.clearAllMocks()
})

describe('UsageChart', () => {
  it('registers the modular echarts components and inits one instance', () => {
    render(<UsageChart buckets={buckets} bucketMs={3_600_000} colors={colors} labels={labels} className="chart" />)
    expect(echartsMock.use).toHaveBeenCalledWith(['bar-chart', 'grid', 'tooltip', 'legend', 'data-zoom', 'canvas'])
    expect(echartsMock.init).toHaveBeenCalledOnce()
    expect(echartsMock.setOption).toHaveBeenCalledOnce()
  })

  it('pushes a fresh option when the buckets change', () => {
    const view = render(<UsageChart buckets={buckets} bucketMs={3_600_000} colors={colors} labels={labels} className="chart" />)
    view.rerender(<UsageChart
      buckets={[{ start: 3_600_000, cacheRead: 0, input: 0, output: 5 }]}
      bucketMs={3_600_000}
      colors={colors}
      labels={labels}
      className="chart"
    />)
    expect(echartsMock.setOption).toHaveBeenCalledTimes(2)
    const option = echartsMock.setOption.mock.calls[1]?.[0] as { series?: { data: number[] }[] }
    expect(option.series?.[2]?.data).toEqual([5])
  })

  it('resizes with the window and disposes on unmount', () => {
    const view = render(<UsageChart buckets={buckets} bucketMs={3_600_000} colors={colors} labels={labels} className="chart" />)
    fireEvent(window, new Event('resize'))
    expect(echartsMock.resize).toHaveBeenCalledOnce()
    view.unmount()
    expect(echartsMock.dispose).toHaveBeenCalledOnce()
  })

  it('resizes with its container when the panel width changes', () => {
    class ResizeObserverMock {
      static active: ResizeObserverMock[] = []
      readonly callback: () => void
      constructor(callback: () => void) {
        this.callback = callback
        ResizeObserverMock.active.push(this)
      }
      observe(): void {}
      disconnect(): void {}
    }
    globalThis.ResizeObserver = ResizeObserverMock as unknown as typeof ResizeObserver
    render(<UsageChart buckets={buckets} bucketMs={3_600_000} colors={colors} labels={labels} className="chart" />)
    expect(ResizeObserverMock.active).toHaveLength(1)
    ResizeObserverMock.active[0]?.callback()
    expect(echartsMock.resize).toHaveBeenCalledOnce()
    delete (globalThis as { ResizeObserver?: unknown }).ResizeObserver
  })
})
