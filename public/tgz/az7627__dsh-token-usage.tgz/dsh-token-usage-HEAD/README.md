# @az7627/dsh-token-usage

DeepSeek Harness 插件：在 Web 对话视图统计 token 用量（分时段堆叠柱状图 + 精确到个位的总计）。npm 包名带作用域（无作用域的 `dsh-token-usage` 已被他人占用）。

- 会话头右缘「用量统计」按钮 → 右侧抽屉
- 对话多选（默认当前对话 / 全选 / 仅当前）
- 分度：15 分钟 / 1 小时 / 1 天；范围：近 7 天 / 近 30 天 / 全部
- 三桶：缓存输入（`cacheReadTokens`）、输入（`inputTokens + cacheWriteTokens`）、输出（`outputTokens`）
- ECharts 堆叠柱状图（本地时区日历对齐）、精确到个位的 tooltip、总计与每对话明细
- 数据来自会话日志重放（`/usage` RPC 通道），历史对话装上即有数据

## 安装到你的 dsh

### 从 npm 安装（推荐）

```sh
# 首次安装（会把它挂进 ~/.dsh/profiles/web 的 bundle 列表）
npx @deepseek-ai/dsh plugin --profile web add @az7627/dsh-token-usage

# 重启你的 dsh web 后生效
npx @deepseek-ai/dsh web
```

- 更新：重新执行上面的 add（pnpm 会装最新版）
- 卸载：`npx @deepseek-ai/dsh plugin --profile web remove @az7627/dsh-token-usage`

### 本地开发（link 安装）

```sh
npx @deepseek-ai/dsh plugin --profile web add <本目录的绝对路径>
```

改完源码 `pnpm run build` 后重启 `npx @deepseek-ai/dsh web` 即生效，无需重新 add。

## 开发

```sh
pnpm install     # 依赖（zod 运行期；echarts 打进浏览器 bundle）
pnpm run build   # tsc + tsdown → lib/index.js（宿主半）+ lib/client.js（浏览器半）
pnpm test        # vitest（组件测试 mock 了 echarts）
```

类型检查依赖同目录下 `deepseek-harness` 源码树里已构建的 `lib/types`（仅编译期引用，运行期全部由 dsh 安装提供）。
