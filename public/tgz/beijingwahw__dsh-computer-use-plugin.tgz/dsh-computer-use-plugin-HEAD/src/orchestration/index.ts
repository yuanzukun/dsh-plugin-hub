// src/orchestration/index.ts
// D-6 多智能体协作中枢 —— DSH 插件入口（第六器官降生）。
// 物理法则合规：
//   一切皆插件     → 标准 apply(ctx, config)，name/inject 导出
//   依赖驱动加载   → inject: tools（必需）+ dsh.sandbox? / dsh.cognition? / dsh.quality-doctor?（可选，
//                    缺席时流水线仍加载，对应工位能力诚实降级 —— 服务就绪后经事件自动咬合）
//   可逆注册与隔离 → 一切监听与内存资源随 ctx.effect 登记清理（Cordis 注册即效果模型）
//   事件总线通信   → 与 D-1/D-4/D-5 零直接调用，咬合只走事件
//   可观测性对齐   → 流水线账本复用 D-5 sandboxLog（'pipeline-*' 链段，append-only 哈希链）
// 零侵入红线：不修改任何既有文件 —— 与 D-5 插件（sandbox-execution-plugin）并存为第六器官，
//            同一 D-5 引擎实例经服务注入共享（双插件单器官）。
import type { Context } from '@deepseek-ai/cordis';
import { defineTool } from '@deepseek-ai/dsh-tools';
import { PipelineOrchestratorImpl } from './pipeline';
import { createDefaultIdGenerator } from '../sandbox/types';
import { COGNITION_PLAN_READY_EVENT, onDoctorVerdict } from '../sandbox/events';
import type { DoctorVerdictPayload } from '../doctorEvents';
import { GOAL_MAX_CHARS, SUCCESS_CRITERIA_MAX_CHARS } from './contracts';
import type { AttemptRecord, IntentPayload, PipelineConfig, PipelineReport } from './contracts';
import type { SandboxAction } from '../sandbox/types';
import { isGlmConfigured } from '../vlm/glmClient';

export { PipelineOrchestratorImpl } from './pipeline';
export { DefaultVisionStation, DefaultDecisionStation, DefaultExecutionStation } from './stations';
export { createStructuredFromUiExtractor, createTraditionalFromOcr, createSemanticFromVlm } from './visionAdapters';
export { GOAL_MAX_CHARS, SUCCESS_CRITERIA_MAX_CHARS } from './contracts';
export type {
  PipelineConfig, PipelineOrchestrator, PipelineReport, PipelineVerdict,
  IntentPayload, AttemptRecord, ScenePatch, UIElement, AtomicAction, ExecutionResult,
  AttentionEnvelope, PerceptionRequest, DecisionContext, NeedGrounding,
} from './contracts';

export const name = 'orchestration-plugin';

// 可选依赖 '?' 语法：缺席不阻断加载，对应能力诚实降级
export const inject = ['tools', 'dsh.sandbox?', 'dsh.cognition?', 'dsh.quality-doctor?'];

// D-6 中枢人格（四工位行为准则内嵌于工具描述 —— DSH 模式：工具即角色的躯壳）
const PIPELINE_DOCTRINE =
  'You are the Multi-Agent Orchestration Hub — the central nervous system of this digital organism. ' +
  'ATTENTION ISOLATION: each station sees only its envelope (vision never sees intent; execution never sees rationale). ' +
  'CONTRACT-DRIVEN: stations exchange only strongly-typed structures, never prose. ' +
  'HONEST FAILURE: any station failure is captured structurally and routed — cancelled never retries; ' +
  'timeout kills one attempt, not the pipeline. ' +
  'TOKEN DISCIPLINE: reports are compact numbers + a reportPath handle; the conversation sees results, never noise.';

/** D-6 配置缺省（cordis.yml 覆盖；魔法数字不落代码常量的例外 —— 本表即缺省契约）。
 *  consumePlanReady 缺省 false —— P1-3 仲裁立法：plan-ready 通道归 D-7 主消费，
 *  D-6 显式 opt-in 才夺回（同通道双流水线执行 = 物理级事故）。 */
const DEFAULT_CONFIG: PipelineConfig = {
  maxDecisionRetries: 3,
  regionGrid: { cols: 2, rows: 2 },
  stationTokenBudgets: { vision: 2000, decision: 8000, execution: 0 },
  rehearseBeforeExecute: true,
  attemptTimeoutMs: 30000,
  perceptionDeadlineMs: 10000,
  consumePlanReady: false,
};

// ─── 内部状态（模块级：工具闭包与事件处理器共享；reset 归零）───
// 有界化（风险加固）：长会话下 run/判决持续到达，无界 Map = 缓慢泄漏 ——
// FIFO 上限淘汰最旧记录（工具面的历史查询语义本就是"近期可查"）。

const MAX_LIVE_REPORTS = 200;
const MAX_VERDICT_INDEX = 500;

/** L 纪元：intent id 铸造走 IdGenerator —— types 立法的 kind='intent' 预留兑现 */
const intentIdGen = createDefaultIdGenerator();

const inflightReports = new Map<string, PipelineReport>();
const attemptVerdicts = new Map<string, DoctorVerdictPayload>(); // key: verdict.subject（三方言）

/** 有界 Map 写入：重写刷新插入序，超限 FIFO 淘汰最旧键（Map 迭代序 = 插入序） */
function boundedSet<K, V>(map: Map<K, V>, key: K, value: V, cap: number): void {
  map.delete(key);
  map.set(key, value);
  while (map.size > cap) {
    const oldest = map.keys().next().value;
    if (oldest === undefined) break;
    map.delete(oldest);
  }
}

/** 判决 → 在册报告补写（J 纪元修正）。
 *  配对方言（按优先序）：
 *    ① 运行时真方言 —— subject = attempt.result.rehearsalChainId
 *       （`chain-exec-${intentRef}-${seq}`，执行工位铸造）—— D-4 doctorChannel
 *       发射的 subject 就是 rehearsal 的 chainId，精确无歧义；
 *    ② 遗留约定方言 —— subject = `${intentRef}:${seq}`（测试契约保留）。
 *  旧实现只认 ②，而全库唯一发射方 doctorChannel 用的是 chainId 方言 ⇒
 *  索引与补写永恒空转。 */

/** run 结束后的迟到判决回收：run 在途时到达的判决只进了索引 —— J 纪元补上
 *  出环回收（终局验收 = 最后一条 attempt 的 doctorVerdict，契约 §7）。
 *  D-4 终局判决的两种上交（J 纪元升级 —— 七态枚举无死态）：
 *    rejected    ⇒ 'rejected'（否决权：任务不许按"完成"交付）
 *    needs_review ⇒ 'escalated'（仅当报告自称 completed —— 硬证据说成了，
 *                   但 D-4 要求复核 ⇒ 上交人类裁决，而非静默放行）。
 *  导出供 epochJ 执法（index 参数可注入测试索引）。 */
export function backfillVerdict(report: PipelineReport, payload: DoctorVerdictPayload): void {
  for (const attempt of report.attempts) {
    if (attempt.result.rehearsalChainId === payload.subject) {
      attempt.doctorVerdict = payload;
      return;
    }
  }
  const sep = payload.subject.lastIndexOf(':');
  if (sep <= 0) return;
  const intentRef = payload.subject.slice(0, sep);
  if (intentRef !== report.intentRef) return;
  const seq = Number(payload.subject.slice(sep + 1));
  if (!Number.isInteger(seq)) return;
  const attempt = report.attempts.find(a => a.seq === seq);
  if (attempt) attempt.doctorVerdict = payload;
}

export function reconcileVerdicts(
  report: PipelineReport,
  index: Map<string, DoctorVerdictPayload> = attemptVerdicts,
): void {
  const subjects = new Set<string>();
  for (const a of report.attempts) {
    if (a.result.rehearsalChainId) subjects.add(a.result.rehearsalChainId);
    subjects.add(`${report.intentRef}:${a.seq}`);
  }
  for (const subject of subjects) {
    const payload = index.get(subject);
    if (payload && !report.attempts.some(a => a.doctorVerdict === payload)) {
      backfillVerdict(report, payload);
    }
  }
  const last = report.attempts[report.attempts.length - 1];
  const lastVerdict = last?.doctorVerdict?.verdict;
  if (lastVerdict === 'rejected' && report.verdict !== 'rejected') {
    report.verdict = 'rejected';
    report.terminalReason = `rejected by D-4 doctor verdict (chainTip ${last!.doctorVerdict!.chainTip})`.slice(0, 120);
  } else if (lastVerdict === 'needs_review' && report.verdict === 'completed') {
    report.verdict = 'escalated';
    report.terminalReason = `hard evidence says done but D-4 demands review (chainTip ${last!.doctorVerdict!.chainTip}) — escalated to human`.slice(0, 120);
  }
}

/** budgetMs 域判别：正有限数才合法（负数瞬死 / NaN 永不超时都毒化 intent 层时钟） */
function isPositiveFinite(n: unknown): n is number {
  return typeof n === 'number' && Number.isFinite(n) && n > 0;
}

export async function apply(ctx: Context, config?: Partial<PipelineConfig>): Promise<void> {
  console.log('[Orchestration] Initializing Multi-Agent Orchestration Hub (D-6)...');

  const orchestrator = new PipelineOrchestratorImpl();

  // 《异常诚实分层契约》D-7 修正案对齐（P0-1）：configure Result 降级（运行层，永不 throw）；
  // 加载门收口于本 apply —— Result !ok ⇒ throw 拒绝带病上线
  const merged: PipelineConfig = { ...DEFAULT_CONFIG, ...config };
  const cfgResult = orchestrator.configure(merged);
  if (!cfgResult.ok) {
    throw new Error(`[Orchestration] invalid configuration — ${cfgResult.error.field}: ${cfgResult.error.reason}`);
  }

  // ── 可选服务探测（dsh.sandbox：D-5 引擎实例 —— 执行工位预演通道）──
  // 探测侧收窄：只有 rehearse 方法在场的对象才构成合法 SandboxStationView（诚实降级）
  const rawSandbox = (ctx as any).get?.('dsh.sandbox') as {
    rehearse?: (chain: { id: string; actions: SandboxAction[]; origin: 'cognition' | 'manual' }) => Promise<{
      verdict: 'passed' | 'failed' | 'degraded' | 'aborted';
      reportPath: string;
    }>;
  } | undefined;
  const sandboxService = rawSandbox?.rehearse
    ? (rawSandbox as { rehearse: NonNullable<typeof rawSandbox.rehearse> })
    : null;

  // ── 工位接线（默认骨架；适配器注入真机源 —— index.ts 是唯一接线点）──
  const { DefaultVisionStation, DefaultDecisionStation, DefaultExecutionStation } =
    await import('./stations');

  // L1/L2/L3 供给三级制（P1-4 适配器落地）：外部 D-3 服务优先 → 插件自身能力
  // 回退（uiExtractor L1 / textReader OCR L2，经 visionAdapters 适配）→ 双缺席诚实降级。
  // system（nut-js 原生）动态引入：沙箱/无屏环境 import 失败 ⇒ 回退源缺席，零污染。
  let structuredSource = (ctx as any).get?.('dsh.vision.structured') ?? null;
  let traditionalSource = (ctx as any).get?.('dsh.vision.traditional') ?? null;
  // 纪元 Ω：semantic 源改为 let —— 自铸分支（VLM 云脑）可能补位（宿主源仍优先）
  let semanticSource = (ctx as any).get?.('dsh.vision.semantic') ?? null;
  // D-6 自铸源记账：回退分支构造的源才是 D-6 属主权可及的（外部源归外部注册方）
  const ownedSources: Array<[string, unknown]> = [];
  if (!structuredSource || !traditionalSource) {
    try {
      const { createStructuredFromUiExtractor, createTraditionalFromOcr } =
        await import('./visionAdapters');
      const { system } = await import('../system');
      if (!structuredSource) {
        structuredSource = createStructuredFromUiExtractor({
          screenSize: () => system.getScreenSize(),
        });
        ownedSources.push(['dsh.vision.structured', structuredSource]);
      }
      if (!traditionalSource) {
        traditionalSource = createTraditionalFromOcr({
          capture: () => system.captureScreen(),
          screenSize: () => system.getScreenSize(),
        });
        ownedSources.push(['dsh.vision.traditional', traditionalSource]);
      }
      console.log('[Orchestration] internal vision adapters wired (L1 a11y / L2 OCR — fallback layer).');
    } catch {
      // 原生依赖缺席（沙箱/无屏）：回退源缺席 —— 三级漏斗诚实降级（既有行为）
      console.log('[Orchestration] internal vision adapters unavailable (native deps absent) — honest degradation.');
    }
  }

  // 纪元 Ω（云脑皮层）：L3 语义源自铸一档 —— 宿主未供 'dsh.vision.semantic'
  // 且云脑可用（插件 config.vlmApiKey 已铸单例，或环境变量已配置）时由
  // GLM 接地器官补位。「宿主 ctx.get 优先、缺席自铸」立法不变 —— 只加不自夺。
  if (!semanticSource) {
    const vlmKeyInConfig = typeof (config as any)?.vlmApiKey === 'string'
      && (config as any).vlmApiKey.trim().length > 0;
    if (vlmKeyInConfig || isGlmConfigured()) {
      try {
        const { createSemanticFromVlm } = await import('./visionAdapters');
        const { system } = await import('../system');
        // W8-B2 接线（DEBTS D-B3 SoM 种子投喂面通电）：somMarkers 端口接 som.ts
        // 的供源工装（W8-A3 备好并经 w8.organwiring 测试证明接入即生效 —— 推荐形态
        // `createSomMarkerSeedSupply({ screenSize, capture })`：a11y 元素 + OCR 词
        // 双通道铸种，交互置信键诚实缺席 —— 组合根绝不 import interactivityProbe
        //（会污染 D-6 模块图，som.ts 顶部纪律同源）。缺省零行为双闸：som.sparseBudget
        // 缺省 0 ⇒ applySparseSom 预算闸先行放行原图（供给口根本不被调用）；
        // 预算开 ⇒ 供给口调用时动态装载 uiExtractor/textReader（模块图零污染）。
        const { createSomMarkerSeedSupply } = await import('../vlm/som');
        semanticSource = createSemanticFromVlm({
          capture: () => system.captureScreen(),
          screenSize: () => system.getScreenSize(),
          somMarkers: createSomMarkerSeedSupply({
            capture: () => system.captureScreen(),
            screenSize: () => system.getScreenSize(),
          }),
        });
        ownedSources.push(['dsh.vision.semantic', semanticSource]);
        console.log('[Orchestration] VLM semantic source wired (Ω cloud cortex — L3 grounding).');
      } catch {
        console.log('[Orchestration] VLM semantic source unavailable — L3 honest degradation.');
      }
    }
  }

  // L 纪元服务归属法（#6 兑现）：外部源缺席时 D-6 以自带回退源成为
  // 'dsh.vision.structured' / 'dsh.vision.traditional'（纪元 Ω 起：缺席时
  // 'dsh.vision.semantic' 亦同）的天然属主 —— 向总线自荐，其余消费方（含未来
  // 的独立视觉插件）从此有可探测的注册方。只自荐 D-6 自己铸造的源；外部源在场
  // ⇒ 属主权归外部注册方，不覆写（单属主铁律）。宿主无 set 面 ⇒ 注册不成立，
  // 各消费方保持既有诚实降级（与 D-5/D-7 同律）。
  const selfRegisteredVision: string[] = [];
  for (const [name, source] of ownedSources) {
    try {
      (ctx as any).set?.(name, source);
      selfRegisteredVision.push(name);
    } catch { /* 注册失败 = 旁路义务：消费方降级路径不变 */ }
  }
  if (selfRegisteredVision.length > 0) {
    console.log(`[Orchestration] vision services self-registered: ${selfRegisteredVision.join(', ')} (host bus accepted).`);
  }

  const vision = new DefaultVisionStation({
    structured: structuredSource,
    traditional: traditionalSource,
    semantic: semanticSource,
  });

  // 决策工位：ChatFn 经 ctx.get('dsh.cognition') 注入（planner 方言）；
  // 缺席 ⇒ chat:null ⇒ decide 恒回 NeedGrounding（P0-5：消灭运行层 throw 闭包 ——
  // 通道缺席是可降级状态，不是异常；伪造一个必炸的 chat 是异常不诚实）
  // O 纪元（#8）：chat 包装计量 —— 决策工位自报探针（chars/4 的消耗估计，
  // 成功往返才计费）。探针经 wire 的 usageMeter 进 finalReport。
  const rawCognition = (ctx as any).get?.('dsh.cognition') as
    | { chat?: (prompt: string) => Promise<string> }
    | undefined;
  let decisionTokensUsed = 0;
  const meteredChat = rawCognition?.chat
    ? async (prompt: string): Promise<string> => {
        const raw = await rawCognition.chat!(prompt);
        decisionTokensUsed += Math.ceil((prompt.length + raw.length) / 4);
        return raw;
      }
    : undefined;
  const decision = new DefaultDecisionStation({
    chat: meteredChat ?? null,
  });

  // 宿主执行通道：宿主动作工具面经 ctx.get('dsh.host-executor') 注入；缺席 = 开发者预览
  const hostExecutor = (ctx as any).get?.('dsh.host-executor') ?? null;

  const execution = new DefaultExecutionStation({
    sandbox: sandboxService ?? null,
    host: hostExecutor,
    rehearseBeforeExecute: merged.rehearseBeforeExecute,
  });

  orchestrator.wire(
    {
      vision, decision, execution,
      emit: (ev, p) => { try { (ctx as any).emit(ev, p); } catch { /* 发射失败是旁路义务 */ } },
      // O 纪元（#8）：决策工位自报探针（chat 包装器累计）；vision/execution
      // 未装探针 ⇒ 报告 0（未计量 ≠ 未消耗 —— 命名 Reported 如实申报）
      usageMeter: { decision: () => decisionTokensUsed },
    },
    {
      reportDir: (config as any)?.reportDir ?? '',
      // ΝΩ-26（四修之四）：D-4 判决回收内联进 persistReport 之前 —— 报告一次
      // 成稿，盘上 verdict 与内存同刻（旧序 run 返回后才 reconcile ⇒ 盘上停旧）。
      // run 返回后的外层 reconcileVerdicts 保留（幂等）：兜住落盘与返回之间
      // 理论上迟到的判决，内存面永不落单。
      reconcileReport: (report) => reconcileVerdicts(report, attemptVerdicts),
    },
  );

  // ── 事件总线接线（与 D-1/D-4 的唯一咬合通道）──

  // D-1 意图投喂：cognition/plan-ready 到达即启动流水线（中枢主循环入口）
  // P1-3 消费门控：consumePlanReady=false（缺省）让渡 D-7 主消费 —— 同通道双流水线
  // 执行 = 物理级事故；true = 显式夺回（仅 D-7 缺席部署时合法）。
  // 载荷宽容解码：ActionChain（既有方言）或 IntentPayload（D-6 方言）皆可入环。
  if (merged.consumePlanReady) {
    // P1-3 仲裁执法：夺回即响亮警告 —— 同通道双消费 = 同意图双流水线并发执行
    // （双份烧钱、报告互覆）。唯一合法拓扑：D-7 缺席或 consumePlanReady=false。
    console.warn('[Orchestration] WARNING: consuming plan-ready channel (consumePlanReady=true). ' +
      'Dual-pipeline execution will occur if D-7 also consumes — ensure D-7 is absent ' +
      'or its consumePlanReady=false before proceeding.');
    (ctx as any).on(COGNITION_PLAN_READY_EVENT, async (payload: any) => {
      const intent: IntentPayload | null = normalizeIntent(payload);
      if (!intent) {
        console.warn('[Orchestration] plan-ready payload unrecognizable — ignored (honest degradation).');
        return;
      }
      const report = await orchestrator.run(intent);
      reconcileVerdicts(report); // J 纪元：在途到达的判决出环回收 + D-4 否决权兑现
      boundedSet(inflightReports, intent.id, report, MAX_LIVE_REPORTS);
      console.log(`[Orchestration] Pipeline ${intent.id}: verdict=${report.verdict} ` +
        `attempts=${report.attempts.length} budgets(v/d/e)=${report.tokenBudgetsGranted.vision}/${report.tokenBudgetsGranted.decision}/${report.tokenBudgetsGranted.execution} ` +
        `report=${report.reportPath}`);
    });
  } else {
    console.log('[Orchestration] plan-ready channel conceded to D-7 (P1-3 arbitration default; ' +
      'set consumePlanReady=true to reclaim — only legal when D-7 is absent).');
  }

  // D-4 判决回执：索引 + 在册报告补写（异步验收闭环 —— AttemptRecord 全粒度）
  onDoctorVerdict(ctx, (payload: DoctorVerdictPayload) => {
    boundedSet(attemptVerdicts, payload.subject, payload, MAX_VERDICT_INDEX);
    // J 纪元修正：配对按 backfillVerdict 的双方言（rehearsalChainId 精确匹配 +
    // `${intentRef}:${seq}` 遗留约定）—— 旧实现只认后者，而真实发射方
    // （doctorChannel）的 subject 是 chainId 方言，补写通道永恒空转。
    for (const report of inflightReports.values()) {
      backfillVerdict(report, payload);
    }
  });

  // 宿主管线观察透传（与 D-5 共享同一嗅探源 —— 不重复监听，D-5 已挂 onHostToolPost）
  // D-6 无需指纹：门禁主权在 D-5。此处空置为注释说明（零重复监听原则）。

  // ── 工具面（对话流只见紧凑数字 + reportPath 句柄）──

  ctx.tools.register(defineTool({
    name: 'run_pipeline',
    description: PIPELINE_DOCTRINE + ' Run the four-station pipeline (vision→decision→execution→verification) '
      + 'for a goal. Returns compact numbers only (verdict, attempts, token usage); full evidence goes to reportPath.',
    parameters: {
      goal: { type: 'string', required: true, description: `Abstract goal (<=${GOAL_MAX_CHARS} chars, e.g. "sign in to the portal").` },
      success_criteria: { type: 'string', description: `Verifiable completion criteria (<=${SUCCESS_CRITERIA_MAX_CHARS} chars).` },
      budget_ms: { type: 'number', description: 'Optional wall-clock budget for the whole pipeline.' },
    },
    output: { schema: { type: 'string' }, render: (_a: any, v: any) => [{ type: 'text', text: v }] },
    async execute(args: any) {
      try {
        const intent: IntentPayload = {
          id: intentIdGen.next('intent'),
          goal: String(args.goal ?? '').slice(0, GOAL_MAX_CHARS),
          successCriteria: args.success_criteria ? String(args.success_criteria).slice(0, SUCCESS_CRITERIA_MAX_CHARS) : undefined,
          budgetMs: isPositiveFinite(args.budget_ms) ? args.budget_ms : undefined,
          source: 'user',
        };
        if (!intent.goal) return JSON.stringify({ status: 'FAILED', reason: 'goal is required' });
        const report = await orchestrator.run(intent);
        reconcileVerdicts(report); // J 纪元：在途判决回收 + D-4 否决权兑现
        boundedSet(inflightReports, intent.id, report, MAX_LIVE_REPORTS);
        // 紧凑数字战报（Token 纪律）：全量证据在 reportPath
        return JSON.stringify({
          status: report.verdict === 'completed' ? 'SUCCESS' : 'FAILED',
          verdict: report.verdict,
          intent_id: report.intentRef,
          attempts: report.attempts.length,
          terminal_reason: report.terminalReason,
          token_budgets_granted: report.tokenBudgetsGranted,
          chain_tip: report.chainTip,
          report: report.reportPath,
        });
      } catch (e: any) {
        return JSON.stringify({ status: 'FAILED', reason: `malformed input: ${e?.message ?? 'unknown error'}` });
      }
    },
  }));

  ctx.tools.register(defineTool({
    name: 'query_attempt_verdict',
    description: 'Query the D-4 doctor verdict for a pipeline attempt (subject convention: "<intent_id>:<seq>"). '
      + 'Asynchronous verdicts may arrive after the pipeline report is persisted — this reads the live index.',
    parameters: {
      subject: { type: 'string', required: true, description: 'Attempt subject, e.g. "intent-tool-xxx:1".' },
    },
    output: { schema: { type: 'string' }, render: (_a: any, v: any) => [{ type: 'text', text: v }] },
    async execute(args: any) {
      const subject = String(args.subject ?? '');
      const v = attemptVerdicts.get(subject);
      if (!v) return JSON.stringify({ status: 'NOT_FOUND', subject });
      return JSON.stringify({
        status: 'FOUND',
        verdict: v.verdict,
        score: v.score,
        chain_tip: v.chainTip,
        rationale: v.rationale ?? null,
      });
    },
  }));

  ctx.tools.register(defineTool({
    name: 'get_pipeline_report',
    description: 'Fetch a persisted pipeline report by intent id (compact summary; full evidence at reportPath).',
    parameters: {
      intent_id: { type: 'string', required: true, description: 'Intent id from run_pipeline output.' },
    },
    output: { schema: { type: 'string' }, render: (_a: any, v: any) => [{ type: 'text', text: v }] },
    async execute(args: any) {
      const report = inflightReports.get(String(args.intent_id ?? ''));
      if (!report) return JSON.stringify({ status: 'NOT_FOUND', intent_id: args.intent_id });
      return JSON.stringify({
        status: 'FOUND',
        verdict: report.verdict,
        attempts: report.attempts.map(a => ({
          seq: a.seq, attempt: a.attempt, kind: a.action.kind,
          effect: a.result.effectDetected, failure: a.result.failure?.kind ?? null,
          doctor: a.doctorVerdict?.verdict ?? null,
        })),
        token_budgets_granted: report.tokenBudgetsGranted,
        report: report.reportPath,
      });
    },
  }));

  ctx.tools.register(defineTool({
    name: 'verify_pipeline_log',
    description: 'Verify the append-only hash chain of the pipeline session log (tamper-evidence audit).',
    parameters: {},
    output: { schema: { type: 'string' }, render: (_a: any, v: any) => [{ type: 'text', text: v }] },
    async execute() {
      const r = orchestrator.verifyLog();
      if (!r.ok) return JSON.stringify({ status: 'FAILED', reason: r.error.reason });
      return JSON.stringify({
        status: 'SUCCESS',
        chain_intact: r.value.ok,
        entries: r.value.length,
        broken_at: r.value.brokenAt,
      });
    },
  }));

  console.log('[Orchestration] 4 pipeline tools registered (run_pipeline / query_attempt_verdict / get_pipeline_report / verify_pipeline_log).');
  console.log(sandboxService
    ? '[Orchestration] D-5 sandbox service detected — rehearsals before execution enabled.'
    : '[Orchestration] D-5 sandbox service absent — execution without rehearsal (honest degradation).');
  console.log(meteredChat
    ? '[Orchestration] D-1 cognition chat channel detected — decision station armed.'
    : '[Orchestration] D-1 cognition chat channel absent — decisions degrade to need-grounding (honest).');

  // ── 可逆注册：一切资源登记清理（Cordis 注册即效果模型）──
  ctx.effect(() => {
    console.log('[Orchestration] Unloading, rolling back resources...');
    return () => {
      orchestrator.reset(); // 内存态归零：账本窗口/自定义分区计数
      inflightReports.clear();
      attemptVerdicts.clear();
      console.log('[Orchestration] Unloaded. Zero residue.');
    };
  });

  console.log('[Orchestration] Initialization complete! The pipeline stands ready.');
}

// ─── 载荷归一化：cognition/plan-ready 的宽容解码（ActionChain | IntentPayload 皆可）───

function normalizeIntent(payload: any): IntentPayload | null {
  if (!payload || typeof payload !== 'object') return null;
  // D-6 方言：已是 IntentPayload（goal 非空才入环 —— 空 goal 意图是死意图）
  if (typeof payload.id === 'string' && typeof payload.goal === 'string' && payload.goal) {
    return {
      id: payload.id,
      goal: String(payload.goal).slice(0, GOAL_MAX_CHARS),
      successCriteria: payload.successCriteria ? String(payload.successCriteria).slice(0, SUCCESS_CRITERIA_MAX_CHARS) : undefined,
      budgetMs: isPositiveFinite(payload.budgetMs) ? payload.budgetMs : undefined,
      source: payload.source === 'cognition' ? 'cognition' : 'user',
      planVersion: payload.planVersion,
    };
  }
  // 既有方言：D-1 的 CognitionPlanReadyPayload.chain（ActionChain）
  if (payload.chain && Array.isArray(payload.chain.actions) && payload.chain.actions.length > 0) {
    const chain = payload.chain;
    const goal = `execute ${chain.actions.length}-step action chain (${chain.actions.map((a: any) => a.kind).slice(0, 5).join('→')}${chain.actions.length > 5 ? '…' : ''})`;
    return {
      id: `intent-from-${chain.id}`,
      goal: goal.slice(0, GOAL_MAX_CHARS),
      successCriteria: undefined,
      budgetMs: isPositiveFinite(chain.budgetMs) ? chain.budgetMs : undefined,
      source: 'cognition',
      planVersion: payload.planVersion,
    };
  }
  return null;
}
