// src/tools/qualityCheckup.ts
// D-4 质量医生的唯一出诊台。人格内嵌于工具描述（DSH 模式：工具即角色的躯壳）。
// 生命周期：惰性 configure（首次调用时用插件配置装配）—— 对 index.ts 零侵入。
// Token 纪律：对话流只进摘要；全量证据落盘 doctor-report.json。
import { defineTool } from '@deepseek-ai/dsh-tools';
import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { Config } from '../config';
import { doctor, DOCTOR_RULES, ensureDoctorConfigured } from '../qualityDoctor';
import { telemetry } from '../telemetry';
import { toolErr, toolOk } from '../toolResult';
import { notary } from '../notary/index';

export function createQualityCheckupTool(config: Config): ToolDefinition {
  return defineTool({
    name: 'quality_checkup',
    description:
      'You are the Quality Doctor — the immune system of this digital organism. ' +
      'GENESIS FIRST: a cute feature that breaks an iron law is a tumor, not a gift. ' +
      'EVIDENCE OR SILENCE: every finding cites file:line and the exact snippet. ' +
      'PRESCRIBE, DON\'T OPERATE: you diagnose always; mechanical fixes only under explicit authorization. ' +
      'Actions: diagnose (audit code genes + causal chain), heal (apply mechanical fixes — requires ' +
      'explicit authorize=true, max_risk="mechanical", dry_run=false), lessons (evolution memory), ' +
      'self_audit (rule coverage of the six genesis laws), notarize (epoch Π: mint a notarial anchor ' +
      'over the journal — chain tip + MMR root + timestamp — then verify the four badges).',
    parameters: {
      action: {
        type: 'string', required: true,
        description: 'diagnose | heal | lessons | self_audit | notarize',
      },
      files: {
        type: 'string',
        description: '[diagnose] Comma-separated sourceRoot-relative files for incremental audit (omit = full scan).',
      },
      include_chain_audit: {
        type: 'boolean',
        description: '[diagnose] Include causal-chain legality audit (default true).',
      },
      authorize: {
        type: 'boolean',
        description: '[heal] Explicit authorization for mechanical fixes. Default false.',
      },
      max_risk: {
        type: 'string',
        description: '[heal] "none" (default) or "mechanical". Structural fixes are proposals only, forever.',
      },
      dry_run: {
        type: 'boolean',
        description: '[heal] Preview patches without writing (default true).',
      },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) {
      const t0 = Date.now();
      // Δ 纪元（安全外围#5）：全工具面唯一无兜底的 execute —— diagnose/heal 直扫
      // 文件系统与规则引擎，任何异常（IO/规则缺陷/记忆损坏）都会裸抛炸穿工具
      // 管线。包 try：异常降级为 toolErr 结构化锚点（action 名保留，模型可换轻
      // 动作自愈），失败计入遥测。
      try {
        const cfgErr = await ensureDoctorConfigured(config);
        if (cfgErr) {
          telemetry.observe('quality_checkup', 'FAILED', Date.now() - t0);
          return JSON.stringify({ status: 'FAILED', reason: cfgErr });
        }

        if (args.action === 'diagnose') {
          const files = args.files?.split(',').map((s: string) => s.trim()).filter(Boolean);
          const report = await doctor.diagnose(
            files && files.length > 0
              ? { files, includeChainAudit: args.include_chain_audit !== false }
              : { includeChainAudit: args.include_chain_audit !== false },
          );
          telemetry.observe('quality_checkup',
            report.findings.some(f => f.severity === 'critical') ? 'UNKNOWN' : 'SUCCESS', Date.now() - t0);
          const sev = (s: string) => report.findings.filter(f => f.severity === s).length;
          // Token 纪律：Top-3 一行式发现；全量证据在磁盘报告
          const top3 = report.findings.slice(0, 3)
            .map(f => `${f.severity} ${f.ruleId} ${f.location.file}:${f.location.line} — ${f.evidence}`)
            .join('\n  ');
          return JSON.stringify({
            status: 'SUCCESS',
            score: report.score,
            genesis_verdict: report.genesisVerdict,
            findings_total: report.findings.length,
            severity: { critical: sev('critical'), major: sev('major'), minor: sev('minor'), info: sev('info') },
            by_category: report.byCategory,
            incremental: report.incremental,
            trend: report.trend,
            warnings: report.warnings,
            top_findings: report.findings.length > 0 ? `\n  ${top3}` : ' (clean)',
            full_report: doctor.reportPath(),
          }, null, 2);
        }

        if (args.action === 'heal') {
          const report = await doctor.diagnose();
          const result = await doctor.heal(report, {
            maxRisk: args.max_risk === 'mechanical' ? 'mechanical' : 'none',
            authorized: args.authorize === true,
            dryRun: args.dry_run !== false,
          });
          telemetry.observe('quality_checkup', 'SUCCESS', Date.now() - t0);
          return JSON.stringify({
            status: 'SUCCESS',
            applied: result.applied.length,
            proposed_only: result.proposed.length,
            rejected: result.rejected,
            note: result.proposed.length > 0
              ? 'Proposals are NOT applied. Structural surgery stays human-authorized.'
              : undefined,
            full_report: doctor.reportPath(),
          }, null, 2);
        }

        if (args.action === 'lessons') {
          telemetry.observe('quality_checkup', 'SUCCESS', Date.now() - t0);
          const m = doctor.memory();
          return JSON.stringify({
            status: 'SUCCESS',
            total_diagnoses: m.totalDiagnoses,
            total_fixes_applied: m.totalFixesApplied,
            last_baseline: m.lastReport,
            lessons: m.lessons.map(l =>
              `${l.ruleId} ×${l.occurrences} (first ${new Date(l.firstSeen).toISOString().slice(0, 10)}): ${l.note}`),
          }, null, 2);
        }

        if (args.action === 'self_audit') {
          telemetry.observe('quality_checkup', 'SUCCESS', Date.now() - t0);
          const audit = doctor.auditSelf();
          return JSON.stringify({
            status: 'SUCCESS',
            covered_laws: audit.coveredLaws,
            missing_laws: audit.missingLaws,
            rule_count: audit.ruleCount,
            config_valid: audit.configValid,
            config_errors: audit.configErrors,
            registry: DOCTOR_RULES.map(r => `${r.id} [${r.severity}/${r.category}]`),
          }, null, 2);
        }

        if (args.action === 'notarize') {
          // 纪元 Π（可公证行为账本）：铸一枚行为公证锚（journal 链尖 + MMR 根 +
          // 时间戳背书）并跑四绿章核验 —— agent 的行为史从此可对外公证。
          // 配置面：单例惰性兜底装配（index.ts 的显式接线优先 —— ensureConfigured
          // 只在从未装配时生效）；notaryEndpoint 空 = 本地时间锚（零网络、诚实标注）。
          notary.ensureConfigured({
            endpoint: config.notaryEndpoint ?? '',
            tracePath: config.notaryTracePath ?? '',
          });
          const anchor = await notary.anchorOnce();
          const report = notary.verifyNotary();
          telemetry.observe('quality_checkup', report.ok ? 'SUCCESS' : 'UNKNOWN', Date.now() - t0);
          // 四件套出证：章状态 + detail + 锚计数 + 时间戳来源（红章=篡改/降级证据，
          // n/a=诚实降级 —— 两者的恢复指引分叉写在 next_step）
          return toolOk(
            'quality_checkup notarize — minted a notarial anchor over the journal (seq + chain tip + MMR root + timestamp) and verified the four badges',
            {
              anchor_minted: anchor !== null,
              anchor_seq: anchor?.seq ?? null,
              timestamp_source: anchor?.timestamp.source ?? report.lastAnchor?.source ?? 'none',
              anchors_total: report.anchors,
              notary_ok: report.ok,
              badges: Object.fromEntries(
                Object.entries(report.badges).map(([name, b]) => [name, `${b.status} — ${b.detail}`]),
              ),
              last_anchor: report.lastAnchor,
            },
            report.ok
              ? 'All checkable badges hold (n/a badges are honest degradations, not failures). ' +
                'Re-run notarize after meaningful action bursts to keep the notarial chain fresh; ' +
                'export the notaryTracePath JSONL for external audit.'
              : 'A red badge means tampering or inconsistency was detected — read its detail ' +
                '(entry index / anchor number) and treat the journal as compromised evidence; ' +
                'compare with the on-disk JSONL before drawing conclusions.',
          );
        }

        telemetry.observe('quality_checkup', 'FAILED', Date.now() - t0);
        return JSON.stringify({
          status: 'FAILED',
          reason: `unknown action "${args.action}" — use diagnose | heal | lessons | self_audit | notarize`,
        });
      } catch (error: any) {
        // 结构化兜底：绝不裸抛（四件套齐全，action 名保留 —— 模型知道哪次出诊炸了）
        telemetry.observe('quality_checkup', 'FAILED', Date.now() - t0);
        return toolErr(
          `quality_checkup "${args?.action ?? 'unknown'}" crashed during execution.`,
          error?.message ?? String(error),
          'The doctor hit an internal error (not a fault in your invocation). ' +
            'Retry with a lighter action (lessons | self_audit), or narrow diagnose with the files parameter. ' +
            'If it keeps crashing, omit files for a full-scan retry and report the error above.',
        );
      }
    },
  });
}
