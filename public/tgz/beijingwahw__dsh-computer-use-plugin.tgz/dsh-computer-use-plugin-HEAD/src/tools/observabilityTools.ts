// src/tools/observabilityTools.ts（ΑΩ-R29 头注修正：原误记 src/observabilityTools.ts）
// 第七轮创新的工具面：把「系统的自我认知」暴露给模型与用户。
//   get_metrics     —— 运行指标 + 模型自省洞见（noop 率高的工具直接点名）
//   verify_journal  —— 哈希链审计：证明行动日志未被篡改（或定位第一个断点）
//   self_diagnose   —— 子系统活体检查（preflight）：截图管线/感知管线/记忆体/审计链
//   save_checkpoint —— 手动快照全部认知态（里程碑保护；卸载时另有自动档）
// 设计原则：观测是旁路义务 —— 任何检查失败都返回结构化报告，绝不抛异常中断任务。
import { defineTool } from '@deepseek-ai/dsh-tools';
import type { Config } from '../config';
// ΑΝΒ-4（D5 缺席披露 · 通道 c）：组合根装配完成时记的工具面披露账
//（mounted/absent 计数 + 缺席键名清单 —— metricsDashboard 值面导入 config 同律）。
import { getToolFaceDisclosure } from '../config';
import { telemetry } from '../telemetry';
import { journal } from '../journal';
import { uiMemory } from '../uiMemory';
import { skillLibrary } from '../skillLibrary';
import { failureMemory } from '../failureMemory';
import { saveCheckpoint } from '../checkpoint';
import { system } from '../system';
import { dhash } from '../perceptualHash';
import { diagnose, bayesianBelief, LOOP_ENTROPY_MIN_ACTIONS, LOOP_PHRASE_MIN_ACTIONS } from '../diagnosis';
import { fitReactPhases } from '../phaseHmm';
import { reactTraceProperties, mineTraceProperties, enforceMinedProperties, type MinedProperty, type TraceEntry } from '../ltlf';
import { Telemetry } from '../telemetry';
import { organCensus } from '../organCensus';
// 纪元 Ι（自我模型）：经验胜任度后验单例 —— get_metrics 的自省面（路径显式指到
// 桶文件，目录导入在 Node strip 装载器是 ERR_UNSUPPORTED_DIR_IMPORT，Λ-4 同律）。
import { selfModel } from '../selfmodel/index';

// W6-2（doctor smell.magic-number 清偿）：高 noop 洞见判据（数值逐位不变）
// —— noop 率 ≥40% 且 ≥5 次调用的工具进入会诊信号（CognitionSignals 文档同源）。
const NOOP_INSIGHT_RATE_PCT = 40;
const NOOP_INSIGHT_MIN_CALLS = 5;

// ── ΤΕΛ-1（C2-9 主题1 A 级 · enforceMinedProperties 生产接线）：挖掘性质执法基线 ──
//
// 会话内单例（进程生命周期 —— 与 journal 同寿）：{props, traceLen}。首次
// self_diagnose 立法（全迹挖掘）；此后每次诊断对 traceLen 之后的新段执法，
// 然后重立法。journal 复位（unload 的 journal.reset / 测试隔离）⇒ 迹变短 ⇒
// 基线失效重铸。纯内存、绝不外抛 —— 观察式旁路（self_diagnose 的设计原则）。
let minedInvariantBaseline: { props: MinedProperty[]; traceLen: number } | null = null;

/** ΤΕΛ-1：mine→enforce 闭环的会话内执法器（self_diagnose 内消费）。
 *  返回 check 行或 null（无可报 —— 诚实缺席：无基线可立法/无新段可执法/
 *  全程异常吞掉均不出行）。立法窗口按 MINE_MIN_SUPPORT 由挖掘器自判。 */
function enforceMinedInvariants(
  entries: readonly TraceEntry[],
): { subsystem: string; status: 'GREEN' | 'AMBER'; detail: string } | null {
  try {
    // 基线失效防御：journal 复位后迹变短 ⇒ 旧法对新世界无管辖权，重开立法窗
    if (minedInvariantBaseline !== null && entries.length < minedInvariantBaseline.traceLen) {
      minedInvariantBaseline = null;
    }
    if (minedInvariantBaseline === null) {
      const props = mineTraceProperties(entries);
      if (props.length === 0) return null; // 迹不足以立法（< 支持度门槛或无一铁律）—— 诚实缺席
      minedInvariantBaseline = { props, traceLen: entries.length };
      return {
        subsystem: 'mined-invariant-enforcement',
        status: 'GREEN',
        detail: `${props.length} mined invariant(s) legislated on ${entries.length}-step history ` +
          `(e.g. ${props[0]!.formula}); future self_diagnose runs enforce them on new trace segments.`,
      };
    }
    const seg = entries.slice(minedInvariantBaseline.traceLen);
    if (seg.length === 0) {
      return {
        subsystem: 'mined-invariant-enforcement',
        status: 'GREEN',
        detail: `${minedInvariantBaseline.props.length} invariant(s) armed; no new trace since last diagnosis — nothing to enforce.`,
      };
    }
    const verdicts = enforceMinedProperties(seg, minedInvariantBaseline.props);
    const violated = verdicts.filter(v => v.violations.length > 0);
    // 重立法（世界变了/没变都要以最新全迹为准 —— 零反例律自动淘汰被违反的旧法）
    const reLegislated = mineTraceProperties(entries);
    minedInvariantBaseline = reLegislated.length > 0
      ? { props: reLegislated, traceLen: entries.length }
      : null;
    if (violated.length > 0) {
      return {
        subsystem: 'mined-invariant-enforcement',
        status: 'AMBER',
        detail: violated.slice(0, 3).map(v =>
          `${v.id} violated at segment step(s) ${v.violations.slice(0, 3).join(',')}`).join('; ') +
          (violated.length > 3 ? ` +${violated.length - 3} more` : '') +
          ' — the world changed (or the law was overfitted); violated invariants are dropped from the re-legislated baseline.',
      };
    }
    return {
      subsystem: 'mined-invariant-enforcement',
      status: 'GREEN',
      detail: `${verdicts.length} invariant(s) hold on ${seg.length} new step(s) — baseline re-legislated.`,
    };
  } catch {
    return null; // 执法是旁路：任何故障零行零影响（self_diagnose 观察式铁律）
  }
}

export function createGetMetricsTool() {
  return defineTool({
    name: 'get_metrics',
    description:
      'Returns runtime telemetry: per-tool success/no-op rates, latency percentiles (P50/P95/P99), ' +
      'and memory hit rates, plus actionable insights about your own recent performance. ' +
      'Call this when you suspect you are repeating ineffective actions.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute() {
      const insights = telemetry.insights();
      // F-2 极值延迟洞见：ξ ≥ 0.25 的重尾点名（P99 看不见的黑天鹅，p999 外推给数字）
      // I-2 法医升级：拟合优度不合格时如实降级 —— 不可信的估计宁可不出手
      const tail = telemetry.tailReport();
      if (tail && tail.xi >= 0.25 && tail.fit === 'ok') {
        insights.push(`HEAVY LATENCY TAIL (ξ=${tail.xi}): occasional extreme stalls are structural, not bad luck — ` +
          `p99.9 extrapolates to ~${tail.p999}ms. Prefer fewer, larger actions over rapid retries in this regime.`);
      }
      if (tail && tail.fit === 'poor') {
        insights.push(`TAIL ESTIMATE UNRELIABLE (Anderson-Darling A²=${tail.adStat} > 3): the latency tail does not ` +
          'follow a GPD shape — treat any p99.9 extrapolation skeptically until more samples arrive.');
      }
      // F-4 行为复杂度洞见：动作流近周期（屏幕可能不变而动作在转 —— 行为侧卡死签名）。
      // 判据双臂：归一化熵率 ≤0.3（渐近域）或 短语数 ≤6 且样本 ≥LOOP_PHRASE_MIN_ACTIONS（短序列的
      // 倍增签名 —— 归一化在小 n 时通胀，短语绝对数不受此影响）
      // W6-2：阈值具名自 diagnosis（与 isLoop 同律 —— 一处立法），数值逐位不变。
      const behav = journal.actionComplexity();
      const nearPeriodic =
        (behav.normalized !== null && behav.normalized <= 0.3 && behav.length >= LOOP_ENTROPY_MIN_ACTIONS) ||
        (behav.phrases <= 6 && behav.length >= LOOP_PHRASE_MIN_ACTIONS);
      if (nearPeriodic) {
        insights.push(`LOW BEHAVIORAL COMPLEXITY (${behav.phrases} phrases / ${behav.length} actions, ` +
          `entropy-rate ${behav.normalized}): your action stream is near-periodic — you are probably spinning. ` +
          'Break the cycle: what_if for counterfactual routes, match_skill for a verified path, or ask the user.');
      }
      // G-2 变点洞见（O 纪元 #27：双边 —— 恶化 + 痊愈都是 regime 变点）
      const regimeShifts = telemetry.regimeShifts();
      for (const rs of regimeShifts) {
        if (rs.direction === 'up') {
          insights.push(`REGIME SHIFT: ${rs.tool} failure rate has JUMPED recently (CUSUM ${rs.cusum} ≥ 2.5 vs ` +
            `baseline ${Math.round(rs.baselineFailureRate * 100)}%, ${rs.baselineSource}) — the environment changed under you. ` +
            'Re-observe with take_screenshot; what worked before may need a new route now.');
        } else {
          insights.push(`RECOVERY SHIFT: ${rs.tool} failure rate has DROPPED recently (CUSUM ${rs.cusum} ≥ 2.5 vs ` +
            `baseline ${Math.round(rs.baselineFailureRate * 100)}%, ${rs.baselineSource}) — the environment healed or a fix landed. ` +
            'Routes that were abandoned as broken may work again: retry once and re-verify.');
        }
      }
      // G-6 行为长程依赖：Hurst > 0.6 ⇒ 失败扎堆（持续性强）—— 失败后立即重试是最差策略
      const H = telemetry.hurst();
      if (H !== null && H > 0.6) {
        insights.push(`STREAKY OUTCOMES (Hurst H=${H}): failures cluster in time — after a failure the next attempt ` +
          'is MORE likely to fail too. Do not blind-retry: switch modality (press_hotkey), zoom_inspect, or recall_ui immediately.');
      }
      // H-4 联合诊断皮层：多引擎信号会诊（症候群 > 孤立异常 —— 规则可审计）
      // W6-2：noop 洞见判据具名（CognitionSignals.highNoopTools 文档同源：≥40% 且 ≥5 调用）
      const highNoopTools = telemetry.snapshot().tools
        .filter(t => t.noop_rate !== null && t.noop_rate >= NOOP_INSIGHT_RATE_PCT && t.calls >= NOOP_INSIGHT_MIN_CALLS)
        .map(t => t.tool);
      const dx = diagnose({
        regimeShiftTools: regimeShifts.filter(r => r.direction === 'up').map(r => r.tool),
        hurst: H,
        behavior: behav,
        heavyLatencyTail: !!(tail && tail.xi >= 0.25),
        highNoopTools,
      });
      if (dx) {
        insights.push(`DIAGNOSIS [${dx.syndrome}]: ${dx.diagnosis} → ${dx.prescription}`);
      }
      // K 纪元（留白兑现）：贝叶斯信念侧写 —— 规则表给处方，信念表给证据组合
      // 的全景（含未被规则命中的竞争假设）；后验和 = 1（枚举精确归一）。
      const belief = bayesianBelief({
        shifted: regimeShifts.length > 0,
        hurstHigh: H === null ? null : H > 0.6,
        loop: !!(behav && behav.normalized !== null &&
          ((behav.normalized <= 0.3 && behav.length >= LOOP_ENTROPY_MIN_ACTIONS) || (behav.phrases <= 6 && behav.length >= LOOP_PHRASE_MIN_ACTIONS))),
        heavyTail: !!(tail && tail.xi >= 0.25),
        highNoop: highNoopTools.length > 0,
      });
      if (belief) {
        const top = belief[0];
        insights.push(`BELIEF (bayesian): ${top.syndrome} p=${top.posterior}` +
          (belief[1] ? ` | runner-up ${belief[1].syndrome} p=${belief[1].posterior}` : ''));
      }
      // H-3 Thompson 模态仲裁：后验抽样推荐（探索与利用按证据强度成比例）
      const modality = telemetry.suggestModality();
      // I-3 HMM 相态透视：Viterbi 解码当前行为相态（隐态：progress/retry/explore/stuck）
      const phase = fitReactPhases(journal.list(true).map(e => e.tool));
      if (phase && (phase.current === 'stuck' || phase.occupancy.stuck >= 0.4)) {
        insights.push(`PHASE PORTRAIT (HMM): currently ${phase.current.toUpperCase()} ` +
          `(stuck occupancy ${(phase.occupancy.stuck * 100).toFixed(0)}%, longest run ${phase.longestStuckRun}) — ` +
          'the hidden mode behind your action stream is grinding. Change the unit of work: bigger steps, different modality.');
      }
      // I-5 置换检验：两模态显著差的证书（精确枚举 —— 无渐近假设的小样本正道）
      const toolList = telemetry.snapshot().tools.filter(t => t.calls >= 8);
      for (let i = 0; i < toolList.length; i++) {
        for (let j = i + 1; j < toolList.length; j++) {
          const a = toolList[i], b = toolList[j];
          const stat = Telemetry.permutationTest2Prop(
            Math.round(((a.success_rate ?? 0) / 100) * a.calls), a.calls,
            Math.round(((b.success_rate ?? 0) / 100) * b.calls), b.calls,
          );
          if (stat && stat.pValue < 0.05) {
            const better = (a.success_rate ?? 0) >= (b.success_rate ?? 0) ? a.tool : b.tool;
            const worse = better === a.tool ? b.tool : a.tool;
            insights.push(`CERTIFIED SIGNIFICANCE (${stat.mode}, p=${stat.pValue.toFixed(3)}): ` +
              `${better} is reliably more effective than ${worse} — prefer ${better} when both apply.`);
          }
        }
      }
      // I-6 一阶随机占优：延迟的全序裁决（每个分位都不晚才算快 —— 交叉分布不裁）
      const domPairs = telemetry.latencyDominancePairs();
      for (const d of domPairs.slice(0, 3)) {
        // K 纪元后配对含 SSD（二阶）裁决 —— 分位可交叉但坏尾累积更轻，措辞须按 order 区分
        insights.push(`LATENCY DOMINANCE: ${d.faster} stochastically dominates ${d.slower} ` +
          (d.order === 'SSD'
            ? '(second-order: lower bad-tail accumulation at every threshold, percentiles may cross).'
            : '(faster at every percentile — no trade-off).'));
      }
      // 纪元 Ι（自我模型）自省面：最擅长/最不擅长的（动作类×场景桶）格子各 3 条
      // + 总格子数 + 总证据量 ——「知道自己不擅长什么」正是本纪元的立意。
      // introspect 禁用时返回 null ⇒ 字段整体缺席（既有字段与结构零变化）。
      const smView = selfModel.introspect(3);
      // ΑΝΒ-4（D5 缺席披露 · 通道 c）：工具面挂载/缺席计数 + 缺席键名
      //（组合根未记账 —— 如裸测试语境 —— ⇒ 字段整体缺席，不伪造观察）。
      const toolFace = getToolFaceDisclosure();
      return JSON.stringify({
        status: 'SUCCESS',
        metrics: telemetry.snapshot(),
        ...(toolFace ? {
          tool_face: {
            mounted_tools: toolFace.mounted,
            absent_tools: toolFace.absentTools.length,
            absent_gates: toolFace.absentGates.map(g => ({ key: g.key, tools: g.tools, gate_on: g.gateOn })),
          },
        } : {}),
        ...(tail ? { latency_tail: tail } : {}),
        behavioral_complexity: behav,
        ...(regimeShifts.length > 0 ? { regime_shifts: regimeShifts } : {}),
        ...(H !== null ? { outcome_hurst: H } : {}),
        ...(dx ? { diagnosis: dx } : {}),
        ...(modality ? { modality_arbitration: modality } : {}),
        ...(phase ? { react_phase: { current: phase.current, occupancy: phase.occupancy, longest_stuck_run: phase.longestStuckRun } } : {}),
        ...(domPairs.length > 0 ? { latency_dominance: domPairs } : {}),
        ...(smView ? { selfModel: smView } : {}),
        insights: insights.length > 0
          ? insights
          : ['No anomalies detected. Keep using verify-effective strategies.'],
      }, null, 2);
    },
  });
}

export function createVerifyJournalTool() {
  return defineTool({
    name: 'verify_journal',
    description:
      'Audits the action journal hash chain (SHA-256, tamper-evident). ' +
      'OK = the recorded history is provably intact. A broken index means the log was modified ' +
      'after the fact — treat everything after that point as untrusted.',
    parameters: {
      tail: { type: 'number', description: 'Also show the last N entries (default 5).' },
    },
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute(args) {
      const v = journal.verify();
      const n = Math.min(Math.max(args.tail ?? 5, 0), 20);
      // n=0 必须显式给空数组：slice(-0) === slice(0) 会倾倒整个日志（上限 1000 条）
      const tail = (n === 0 ? [] : journal.list().slice(-n)).map((e, i) =>
        `${i + 1}. ${e.tool} ${e.status}${e.effect_detected === false ? ' (no effect)' : ''} ${e.hash?.slice(0, 12) ?? ''}`);
      return JSON.stringify({
        status: v.ok ? 'SUCCESS' : 'FAILED',
        state_anchor: {
          chain_integrity: v.ok ? 'INTACT' : 'BROKEN',
          entries: v.length,
          first_broken_at_index: v.brokenAt,
        },
        recent_entries: tail,
        next_step: v.ok
          ? undefined
          : `The journal chain breaks at entry #${v.brokenAt}. Entries after it are not trustworthy; ` +
            'investigate what modified the log before replaying anything from it.',
      }, null, 2);
    },
  });
}

export function createSelfDiagnoseTool(config: Config) {
  return defineTool({
    name: 'self_diagnose',
    description:
      'Runs live health checks on all subsystems: screen capture pipeline, perceptual hashing, ' +
      'memory stores (UI/skills/failures), journal audit chain, and telemetry. ' +
      'Call this at session start, or whenever tool results seem inconsistent with reality.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute() {
      const checks: Array<{ subsystem: string; status: 'GREEN' | 'AMBER' | 'RED'; detail: string }> = [];

      // 1. 截图管线（一切视觉能力的地基）
      try {
        const buf = await system.captureScreen();
        checks.push({ subsystem: 'screen-capture', status: buf.length > 0 ? 'GREEN' : 'RED', detail: `${buf.length} bytes` });
        // 2. 感知管线：对真实截图像指纹（端到端活体检测，非单测）
        const hash = await dhash(buf);
        checks.push({
          subsystem: 'perceptual-hash',
          status: /^[01]{64}$/.test(hash) ? 'GREEN' : 'RED',
          detail: `fingerprint ${hash.slice(0, 12)}…`,
        });
      } catch (e: any) {
        checks.push({ subsystem: 'screen-capture', status: 'RED', detail: e.message });
        checks.push({ subsystem: 'perceptual-hash', status: 'RED', detail: 'skipped (capture failed)' });
      }

      // 3. 记忆体
      checks.push({ subsystem: 'ui-memory', status: uiMemory.size > 0 ? 'GREEN' : 'AMBER', detail: `${uiMemory.size} landmark(s)` });
      checks.push({ subsystem: 'skill-library', status: skillLibrary.list().length > 0 ? 'GREEN' : 'AMBER', detail: `${skillLibrary.list().length} skill(s)` });
      checks.push({ subsystem: 'failure-memory', status: failureMemory.size > 0 ? 'GREEN' : 'AMBER', detail: `${failureMemory.size} record(s)` });

      // 4. 审计链
      const v = journal.verify();
      checks.push({
        subsystem: 'journal-chain',
        status: v.ok ? 'GREEN' : 'RED',
        detail: v.ok ? `${v.length} entries intact` : `BROKEN at #${v.brokenAt}`,
      });

      // 5. 全局运行指标
      const snap = telemetry.snapshot();
      checks.push({
        subsystem: 'telemetry',
        status: 'GREEN',
        detail: `${snap.global.calls} calls, success ${snap.global.success_rate ?? '-'}%, noop ${snap.global.noop_rate ?? '-'}%`,
      });

      // 6. 干跑模式警示（动作全部只记录不执行 —— 非常容易忘记）
      if (config.dryRun) {
        checks.push({ subsystem: 'dry-run-mode', status: 'AMBER', detail: 'ACTIONS ARE NOT EXECUTED (dryRun=true)' });
      }

      // 7. I-1 LTLf 形式性质：ReAct 教义的可机检判决（违例逐位定位）
      const traceProps = reactTraceProperties(
        journal.list(true).map(e => ({ tool: e.tool, observed: e.observe !== undefined, effect: e.effect_detected })),
      );
      const propViolations = traceProps.filter(p => p.violations.length > 0);
      if (propViolations.length > 0) {
        checks.push({
          subsystem: 'react-temporal-properties',
          status: 'AMBER',
          detail: propViolations.map(p => `${p.id} ×${p.violations.length} @${p.violations.slice(0, 3).join(',')}`).join('; '),
        });
      } else if (traceProps.length > 0) {
        checks.push({ subsystem: 'react-temporal-properties', status: 'GREEN', detail: 'all LTLf properties hold' });
      }

      // O 纪元（#23）：性质挖掘 —— 行动迹自动铸造的时序不变量（支持度成文；
      // 弱模式不立 —— 性质库是判据不是倾向表）
      const fullTrace = journal.list(true).map(e => ({
        tool: e.tool, observed: e.observe !== undefined, effect: e.effect_detected,
      }));
      const mined = mineTraceProperties(fullTrace);
      if (mined.length > 0) {
        checks.push({
          subsystem: 'mined-temporal-invariants',
          status: 'GREEN',
          detail: mined.slice(0, 4).map(m => `${m.formula} (${m.support}×)`).join('; ') +
            (mined.length > 4 ? ` +${mined.length - 4} more` : ''),
        });
      }

      // ΤΕΛ-1（C2-9 主题1 A 级 · enforceMinedProperties 生产接线）：挖掘性质的
      // 在线执法 —— mine→enforce 闭环（S-5 立法注释：「性质库从描述统计升格为
      // 在线规约」此前只有前半句通电）。会话内基线立法制：首次诊断把全迹挖掘
      // 铸为性质基线；此后每次诊断对**上次诊断以来的新迹段**执法 —— 违例 =
      // 世界变了或立法过拟合（两者都该被看见，AMBER 上报）；随后以全迹重立法
      // （挖掘零反例律保证被违反的性质自然出局 —— 世界变了，旧法作废）。
      // 基线随 journal 复位（迹变短）⇒ 视为新一轮立法窗口。观察式旁路铁律：
      // 一切异常吞掉、零违例可报时不出行（诚实缺席，不凑行数）。
      const enforcement = enforceMinedInvariants(fullTrace);
      if (enforcement !== null) {
        checks.push(enforcement);
      }

      // U 纪元（U-4 自省层）：器官册 census —— 33 件数学器官逐件点名
      const census = organCensus();
      checks.push({
        subsystem: 'organ-census',
        status: census.degraded.length === 0 ? 'GREEN' : 'AMBER',
        detail: census.degraded.length === 0
          ? `${census.healthy}/${census.total} organs healthy`
          : `degraded: ${census.degraded.join(', ')} (${census.healthy}/${census.total} healthy)`,
      });

      const red = checks.filter(c => c.status === 'RED').length;
      const amber = checks.filter(c => c.status === 'AMBER').length;
      return JSON.stringify({
        status: red > 0 ? 'FAILED' : 'SUCCESS',
        state_anchor: {
          overall: red > 0 ? 'RED' : amber > 0 ? 'AMBER' : 'GREEN',
          red, amber, green: checks.length - red - amber,
        },
        checks,
        next_step: red > 0
          ? 'Critical subsystem(s) down. Do NOT attempt UI automation until the RED items are fixed ' +
            '(check display/access permissions first — headless environments cannot capture screens).'
          : amber > 0 && config.dryRun
            ? 'Healthy but in dry-run mode: actions will be logged, not executed.'
            : 'All critical subsystems healthy. Proceed with the task.',
      }, null, 2);
    },
  });
}

export function createSaveCheckpointTool(config: Config) {
  return defineTool({
    name: 'save_checkpoint',
    description:
      'Snapshots the entire cognitive state (UI memory, skills, failure memory, journal chain, metrics) ' +
      'to the configured checkpoint file (atomic write). Call it after completing valuable milestones ' +
      'so a crash can never erase them. Requires checkpointPath in config.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: (_args, value) => [{ type: 'text', text: value }],
    },
    async execute() {
      const r = saveCheckpoint(config.checkpointPath);
      return r.ok
        ? `[System]: Checkpoint saved atomically (${r.steps} journal entries chained). ` +
          'Crash-safe from this point on.'
        : `[Error]: Checkpoint not saved — ${r.error}`;
    },
  });
}
