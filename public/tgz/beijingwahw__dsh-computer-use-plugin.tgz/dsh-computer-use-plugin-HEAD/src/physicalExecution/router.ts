// src/physicalExecution/router.ts
// D-5 SandboxAction → 微服务动作路由。
//
// 造物主契约（Step 1 §五）：
//   - 将 D-7 的动作词汇表（kind + args）路由到对应的微服务调用
//   - 失败一律映射为 ExecutionResult.failure.kind（对齐 D-7 §173）
//   - 物理执行不做效果验证（D-5 sandbox 的活）—— effectDetected 恒 null
//   - rehearsed 恒 false（物理执行 = 真 deliver，非预演）
//
// 路由表：
//   click_mouse    → adapter.clickMouse
//   type_text      → adapter.typeText
//   scroll_page    → adapter.scrollPage
//   press_hotkey   → adapter.pressHotkey
//   drag_mouse     → adapter.dragMouse
//   switch_tab     → adapter.pressHotkey [ctrl+tab]（全平台 —— Cmd+Tab 是应用切换器）
//   switch_window  → adapter.switchWindow 或 pressHotkey [alt+tab]
//   dismiss_popup  → adapter.pressHotkey [esc]
//   noop           → 直接 ok（不调用微服务）
//
// 世界级创新升级：集成 CapabilityCache —— switch_window 路由前先查能力 map，
//   - native       → 调 /v1/switch_window（让 Python 端处理失败降级）
//   - hotkey_only  → 直接调 pressHotkey，跳过一次网络往返
//   - unavailable  → 直接返回错误，不发请求
// 当 Python 端 fallback 触发，Reactive 同步 capability map。
import type { SandboxAction } from '../sandbox/types';
import type {
  ExecutionFailureKind, ExecutionResult, PhysicalActionRouter,
  PhysicalExecutionAdapter, PhysicalError,
} from './contracts.js';
import { PhysicalErrorKind } from './contracts.js';
import {
  CapabilityCache, syncCapabilityFromSwitchWindowResult,
} from './capabilityCache.js';

/** 默认操作延迟（用于 noop 与延迟路径） */
const NOOP_LATENCY_MS = 0;

/** D-5 物理执行路由器实现 */
export class PhysicalActionRouterImpl implements PhysicalActionRouter {
  private readonly _capability: CapabilityCache;
  private readonly adapter: PhysicalExecutionAdapter;

  constructor(
    adapter: PhysicalExecutionAdapter,
    capability?: CapabilityCache,
  ) {
    this.adapter = adapter;
    this._capability = capability ?? new CapabilityCache();
  }

  /** 暴露 capability cache 给调用方（启动期探活后 sync） */
  get capability(): CapabilityCache {
    return this._capability;
  }

  /** 运行层方法：永不抛错 —— 失败入 ExecutionResult.failure。
   *  ΠΑΝ-64（止损链断裂修复）：第三可选参 signal —— 接收（d7HostPort 经
   *  SignalDispatch seam 下发的 ExecutionOrder.signal）并透传给全部动作方法
   *  （→ adapter → microFetch 组合超时断流）。signal 缺席 ⇒ 旧路径逐字节。 */
  async dispatch(action: SandboxAction, seq: number, signal?: AbortSignal): Promise<ExecutionResult> {
    const startedAt = Date.now();

    // noop：直接返回，不调用微服务
    if (action.kind === 'noop') {
      return {
        seq,
        effectDetected: null,
        latencyMs: NOOP_LATENCY_MS,
        rehearsed: false,
      };
    }

    try {
      const result = await this.route(action, signal);
      const latencyMs = Date.now() - startedAt;
      if (!result.ok) {
        return this.toFailureResult(seq, latencyMs, result.error);
      }
      return {
        seq,
        effectDetected: null,  // 物理执行不做效果验证
        latencyMs,
        rehearsed: false,      // 真 deliver，非预演
      };
    } catch (e: any) {
      // 理论不可达：adapter 已是 Result 降级；此处仅兜底
      const latencyMs = Date.now() - startedAt;
      return {
        seq,
        effectDetected: false,
        latencyMs,
        rehearsed: false,
        failure: {
          kind: 'host-error',
          detail: `router unexpected error: ${e?.message ?? 'unknown'}`,
        },
      };
    }
  }

  /** 单动作路由 —— 派发到对应 adapter 方法（ΠΑΝ-64：signal 随路由透传全动作面） */
  private async route(
    action: SandboxAction,
    signal?: AbortSignal,
  ): Promise<
    { ok: true; value: unknown } | { ok: false; error: PhysicalError }
  > {
    switch (action.kind) {
      case 'click_mouse': {
        const args = action.args ?? {};
        // J 纪元修正（诚实话义前置）：x/y 缺失/非法时旧实现静默缺省 0.5 ——
        // 畸形 args 不会报错而是点击屏幕中心（真实点击！）。域外拒绝：
        // 指针动作必须有显式坐标，gate-rejected 先于物理执行。
        if (!Number.isFinite(Number(args?.x)) || !Number.isFinite(Number(args?.y))) {
          return {
            ok: false,
            error: {
              kind: PhysicalErrorKind.INVALID_ARGS,
              detail: 'click_mouse requires finite normalized x/y (got ' +
                `${JSON.stringify(args?.x)}, ${JSON.stringify(args?.y)} — refusing to click screen center by default)`,
            },
          };
        }
        return this.adapter.clickMouse({
          x: num(args.x, 0.5),
          y: num(args.y, 0.5),
          button: asButton(args.button),
          dryRun: bool(args.dry_run),
          signal,
        });
      }
      case 'type_text': {
        const args = action.args ?? {};
        if (typeof args.text !== 'string') {
          return {
            ok: false,
            error: {
              kind: PhysicalErrorKind.INVALID_ARGS,
              detail: `type_text requires a string text (got ${typeof args.text})`,
            },
          };
        }
        return this.adapter.typeText({
          text: args.text,
          clearFirst: bool(args.clear_first ?? args.clearFirst),
          dryRun: bool(args.dry_run),
          signal,
        });
      }
      case 'scroll_page': {
        const args = action.args ?? {};
        return this.adapter.scrollPage({
          direction: asDirection(args.direction),
          amount: num(args.amount, 3),
          dryRun: bool(args.dry_run),
          signal,
        });
      }
      case 'press_hotkey': {
        const args = action.args ?? {};
        const keys = Array.isArray(args.keys) ? args.keys.filter((k): k is string => typeof k === 'string') : [];
        return this.adapter.pressHotkey({ keys, dryRun: bool(args.dry_run), signal });
      }
      case 'drag_mouse': {
        const args = action.args ?? {};
        const start = args.start ?? { x: args.startX, y: args.startY };
        const end = args.end ?? { x: args.endX, y: args.endY };
        // J 纪元修正：drag 坐标缺失/非法时旧实现静默缺省 0 —— 点到屏幕左上角。
        // 与 click 同律域外拒绝（指针动作必须显式给坐标）。
        for (const [label, pt] of [['start', start], ['end', end]] as const) {
          if (!Number.isFinite(Number(pt?.x)) || !Number.isFinite(Number(pt?.y))) {
            return {
              ok: false,
              error: {
                kind: PhysicalErrorKind.INVALID_ARGS,
                detail: `drag_mouse requires finite normalized ${label}.x/y (got ` +
                  `${JSON.stringify(pt?.x)}, ${JSON.stringify(pt?.y)})`,
              },
            };
          }
        }
        return this.adapter.dragMouse({
          start: { x: num(start?.x, 0), y: num(start?.y, 0) },
          end: { x: num(end?.x, 0), y: num(end?.y, 0) },
          dryRun: bool(args.dry_run),
          signal,
        });
      }
      case 'switch_tab': {
        // J 纪元修正：所有平台统一 Ctrl+Tab —— 注释自己写明"Cmd+Tab 切换
        // 应用、Ctrl+Tab 切换标签页"，旧代码却在 darwin 选 cmd（switch_tab
        // 实际切换应用，与动作名相悖；主流浏览器在 macOS 同样支持 Ctrl+Tab）。
        return this.adapter.pressHotkey({ keys: ['ctrl', 'tab'], signal });
      }
      case 'switch_window': {
        const args = action.args ?? {};
        const keyword = typeof args.keyword === 'string' ? args.keyword : '';
        const route = this._capability.switchWindowRoute();

        // 路径 1：hotkey_only 或缺 keyword —— 直接走 hotkey 快速路径（跳过一次网络往返）
        if (route === 'hotkey_only' || !keyword) {
          const mod = process.platform === 'darwin' ? 'cmd' : 'alt';
          return this.adapter.pressHotkey({ keys: [mod, 'tab'], signal });
        }

        // 路径 2：unavailable —— 直接返回错误，不发请求
        if (route === 'unavailable') {
          return {
            ok: false,
            error: {
              kind: PhysicalErrorKind.WINDOW_UNAVAILABLE,
              detail: 'window management is unavailable (check health)',
            },
          };
        }

        // 路径 3：native 或 unknown —— 调 /v1/switch_window，让 Python 端处理失败降级
        const result = await this.adapter.switchWindow({ keyword, signal });
        if (result.ok) {
          // Reactive 同步：Python 端可能 fallback 到 hotkey_only（method 变化时立即更新缓存）
          syncCapabilityFromSwitchWindowResult(this._capability, result.value);
          return result;
        }

        // 请求失败：若是 capability 探测过的 native 失败，回退到 hotkey（防硬阻塞）
        // ΝΩ-27：回退前先探活 —— 旧实现对任何失败无条件再发一次 hotkey 请求，
        // 服务已死/不应答时第二跳必再吃满超时（双倍超时）。先 /v1/health 轻量
        // 探活：死服务连接拒绝即时回、活服务毫秒级应答 —— 不活则如实回传原
        // 错误，不再发起注定超时的 hotkey（adapter.health 的缓存受 TTL 约束，
        // 缓存过期后死服务必现形；缓存新鲜时误判「活」的代价只是一次快速
        // ECONNREFUSED，非超时）。
        if (route === 'native' && result.error.kind !== PhysicalErrorKind.WINDOW_UNAVAILABLE) {
          if (!(await this.serviceAlive())) {
            return result; // 服务已死：hotkey 走同一服务，发了也白发
          }
          const mod = process.platform === 'darwin' ? 'cmd' : 'alt';
          const hotkeyResult = await this.adapter.pressHotkey({ keys: [mod, 'tab'], signal });
          if (hotkeyResult.ok) {
            // 降级成功：标记能力为 hotkey_only（Reactive 同步）
            this._capability.updateSwitchWindowMethod('hotkey_only');
          }
          return hotkeyResult;
        }

        return result;
      }
      case 'dismiss_popup': {
        // 降级为 Esc
        return this.adapter.pressHotkey({ keys: ['esc'], signal });
      }
      // noop 在 dispatch() 入口已提前返回 —— 永不抵达此处（不可达分支已移除）
      default:
        return {
          ok: false,
          error: {
            kind: PhysicalErrorKind.INVALID_ARGS,
            detail: `unknown action kind: ${(action as { kind?: string }).kind}`,
          },
        };
    }
  }

  /** PhysicalError → ExecutionResult.failure 映射 */
  private toFailureResult(
    seq: number,
    latencyMs: number,
    error: PhysicalError,
  ): ExecutionResult {
    return {
      seq,
      effectDetected: false,
      latencyMs,
      rehearsed: false,
      failure: {
        kind: this.mapErrorKind(error.kind),
        detail: `[${error.kind}] ${error.detail}`,
      },
    };
  }

  /** PhysicalErrorKind → ExecutionFailureKind 映射（对齐 D-7 §173）。
   *  ΝΩ-27：细分透传 —— 与 PhysicalErrorKind 同构（旧实现 14 压 2，
   *  unauthorized/element_not_found/internal_error 不可区分，上层重试策略
   *  失去判据）。timeout 二元保留（D-7 超时预算语义同一性）；其余 12 种
   *  snake_case → kebab-case 一一对应；detail 保留 [snake_case] 结构化前缀。 */
  private mapErrorKind(kind: PhysicalErrorKind): ExecutionFailureKind {
    switch (kind) {
      case 'client_timeout':
      case 'action_timeout':
        return 'timeout';
      case 'invalid_args':
        return 'invalid-args';
      case 'out_of_bounds':
        return 'out-of-bounds';
      case 'unknown_button':
        return 'unknown-button';
      case 'unknown_key':
        return 'unknown-key';
      case 'element_not_found':
        return 'element-not-found';
      case 'screen_capture_failed':
        return 'screen-capture-failed';
      case 'ocr_unavailable':
        return 'ocr-unavailable';
      case 'vlm_unavailable':
        return 'vlm-unavailable';
      case 'window_unavailable':
        return 'window-unavailable';
      case 'unauthorized':
        return 'unauthorized';
      case 'internal_error':
        return 'internal-error';
      case 'transport_error':
        return 'transport-error';
      default:
        return 'host-error';
    }
  }

  /** ΝΩ-27：回退前探活 —— 服务是否仍应答（/v1/health 轻量往返）。
   *  adapter 契约永不抛错；此处 try/catch 兜底（防御深度，探活失败=不活）。 */
  private async serviceAlive(): Promise<boolean> {
    try {
      const health = await this.adapter.health();
      return health.ok;
    } catch {
      return false;
    }
  }
}

// ─── 类型守卫 / 安全转换（容错的 args 解析）───

function num(v: unknown, fallback: number): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback;
}

function bool(v: unknown): boolean | undefined {
  return typeof v === 'boolean' ? v : undefined;
}

function asButton(v: unknown): 'left' | 'right' | 'middle' | undefined {
  return v === 'left' || v === 'right' || v === 'middle' ? v : undefined;
}

function asDirection(v: unknown): 'up' | 'down' | 'left' | 'right' {
  return v === 'up' || v === 'down' || v === 'left' || v === 'right' ? v : 'down';
}
