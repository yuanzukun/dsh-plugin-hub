// src/knowledge/pipeline.ts
// W6-2 结构性保留（doctor smell.over-engineering 登记）：D-7 知识管线编排器 —— 感知/决策/执行三工位的单文件主权（信封铸造权/失败路由/时间治理收口于此），拆分违背四大主权收口设计。
// D-7 隐知识增强流水线编排器 —— PipelineOrchestrator 桩实现（契约见 contracts.ts §13）。
// 四大主权（全部收口于本文件）：
//   1. 信封铸造权：五工位信封的唯一构造者（注意力隔离的物理执法点 —— 工位只见信封内物）
//   2. 防卡顿守卫：KnowledgeBase.query 与 VisionStation.perceive 并行触发；
//      检索越 knowledgeTimeout（默认 50ms）⇒ 直接降级无隐知识模式，绝不阻塞流水线
//   3. 失败路由：cancelled / timed-out 不入重试（给已终止的尝试重规划是无意义烧钱）；
//      其余失败按 retryPolicy 指数退避重试（capped at maxBackoffMs）
//   4. 闭环进化：验收后打包 ExecutionOutcome → KnowledgeBase.learnFromOutcome（旁路义务：
//      学习失败只告警，绝不击穿流水线）
// 《异常诚实分层契约》D-7 修正案：configure = 运行层可重配方法 —— Result 降级，严禁
//   throw（验收修复项 #2）；wire = 加载层（throw 合法，由 apply 收口）；run = 永不抛错。
import { existsSync, mkdirSync, renameSync, writeFileSync } from 'fs';
import { join } from 'path';
import type {
  AttentionEnvelope, AtomicAction, ConfigError, DecisionContext,
  ExecutionOutcome, ExecutionResult, FailureFeedback, IntentPayload, KnowledgeBase,
  KnowledgeInjection, KnowledgeQuery, NeedGrounding, OutcomeSettlement, PerceptionRequest,
  PipelineConfig, PipelineOrchestrator, PipelineReport, PipelineVerdict, Result, ScenePatch,
  VisionStation, DecisionStation, ExecutionStation, WorldModel, SurpriseReport,
} from './contracts';
import { DoctorVerdictBridge } from './adapters';
import { distillInjection } from './knowledgeBase';
import { InMemoryWorldModel, transitionActionKey, WORLD_MODEL_MERGE_SWEEP_TYPES } from './worldModel';
import { InMemoryKnowledgeBase } from './knowledgeBase';
import { ReflexiveDecisionStation } from './stations';
import { KnowledgePersistence } from './persistence';
import { MetricsLedger, type RunMetricRecord } from './metrics';
// ΝΩ-28 任务1（M5 奖励接线）：run-end 收割逐类别记忆操作成败 → insert 臂记账
//（memoryOps.ts 的老虎机反馈通道 —— 此前全库零生产调用，本线接通闭环）。
import { harvestMemoryOpRewards, applyHarvestedRewards } from './memoryOps';
import {
  emitKnowledgeAttempt, emitKnowledgeLearned, emitKnowledgeRunEnd,
  type KnowledgeAttemptPayload, type KnowledgeLearnedPayload,
} from './events';
import { sandboxLog } from '../sandbox/log';
import { validatePipelineConfig, DEFAULT_REGION_GRID } from './configValidator';
import { P } from './params';

/** 防爆环上限（结构保险丝：任何纪元的最大决策轮数） */
const MAX_ROUNDS = 1000;

/**
 * L3 升级阈值（预测编码铁律：惊讶计费器）—— 认知参数，收编 params.ts。
 * 形式推导：bits = −log₂p，3 bits ⇔ 预期概率 ≤12.5%；
 * 「3 不是 2 或 4」由校准基准的分离带测量定标（熟悉底噪 vs 新世界信号）。
 */

/** D-7 链段入账（P1-5 可观测性对齐：复用 sandboxLog append-only 哈希链，
 *  kind 前缀 'knowledge-'）。旁路义务：落盘失败由 SandboxLog 内部吞错，
 *  绝不阻断流水线；同步段原子（chainTip 读写无竞态）。 */
function logKnowledge(
  kind: 'knowledge-retrieval' | 'knowledge-attempt' | 'knowledge-learned' |
    'knowledge-internal-fault' | 'knowledge-run-end' | 'knowledge-consolidated' |
    'world-transition',
  data: Record<string, unknown>,
): void {
  void sandboxLog.append(kind, data);
}

/** 工位依赖束（index.ts 唯一接线点注入） */
export interface KnowledgePipelineDeps {
  vision: VisionStation;
  decision: DecisionStation;
  execution: ExecutionStation;
  knowledge: KnowledgeBase;
  /** D-4 判决桥（P0-4 验收门：结算 = 学习的前置条件 —— verdict 即时结算 / run-end 冲账） */
  verdictBridge: DoctorVerdictBridge;
  /**
   * 世界模型（预测编码基底 —— 可选注入）：缺席 ⇒ 流水线自建内存实例。
   * 惊讶计费器在此接线：预测误差 ≥ L3_ESCALATION_BITS ⇒ 下轮 forceL3。
   */
  worldModel?: WorldModel;
  /** 事件发射面（null-safe：发射失败是旁路义务，绝不阻断主流程） */
  emit?: (event: string, payload: object) => void;
}

/** wire 选项（生命周期资产的路由表） */
export interface WireOptions {
  /** 结构化报告落盘目录（既有语义） */
  reportDir?: string;
  /**
   * 跨会话状态目录（反遗忘接线）：在场 ⇒ wire 时水合（空脑或旧脑），
   * 每 run-end 原子落盘。缺席 ⇒ 遗忘症模式（旧行为，兼容）。
   */
  stateDir?: string;
  /** 认知仪表盘账本路径（JSONL）：在场 ⇒ 每 run-end 追加一行指标 */
  metricsPath?: string;
}

/** NeedGrounding 判别（D-7 方言：reason/focus 双字段在场即判 —— 无 kind 判别式） */
function isNeedGrounding(output: AtomicAction | NeedGrounding): output is NeedGrounding {
  return typeof (output as NeedGrounding).reason === 'string' &&
    typeof (output as NeedGrounding).focus === 'string' &&
    !('kind' in output);
}

/** 场景紧凑摘要（隐知识检索的 sceneDescription 铸造源 —— Token 纪律） */
function summarizeScene(scene: ScenePatch[]): string {
  return scene
    .map(p => `${p.region.id}:${p.funnelDepth}${p.elements.length ? `(${p.elements.slice(0, 3).map(e => e.name).join(',')})` : ''}`)
    .join('; ')
    .slice(0, 200);
}

export class KnowledgePipelineOrchestrator implements PipelineOrchestrator {
  private cfg: PipelineConfig | null = null;
  private deps: KnowledgePipelineDeps | null = null;
  /** 世界模型（wire 时铸造 —— 缺席注入 ⇒ 内建实例；跨 run 存活：经验不因一次 run 归零） */
  private worldModel: WorldModel | null = null;
  private reportDir = '';
  private persistence: KnowledgePersistence | null = null;
  private metrics: MetricsLedger | null = null;
  private reportCounter = 0; // 报告文件名防碰撞序号（同 intent 同毫秒不互相覆盖）
  /**
   * ΠΑΝ-44（收割水位线）：上次 run-end 奖励收割的墙钟。同一证据只计一次 ——
   * 条目 updatedAt 冻结（query 只递增 usageCount 不动 updatedAt）导致 7 天窗口
   * 内每个 run-end 都把同一批条目重新收割、向 insert 臂重复记伯努利试验
   * （C1-8 H3：Beta 后验 n 被系统性膨胀，MEMORY_OP_FEEDBACK_GATE=8 形同虚设）。
   * 修正：只收割 updatedAt > 水位线的新证据；收割即推进水位线。复证
   * （reinforceEntry 刷新 updatedAt）视为新证据状态可再计一次 —— 文档在案。
   * 水位线是进程内状态（不随 stateDir 持久化）：进程重启后窗口内条目会再计
   * 一次 —— 账本（EvidenceLedger）同为进程内状态，两侧口径一致。
   */
  private lastHarvestAt = 0;

  /**
   * 运行层可重配方法（D-7 修正案 / 验收修复项 #2）：Result 降级，严禁 throw。
   * 校验 + 缺省归一化收口于 configValidator（纯函数守卫模块）——
   * 域外拒绝（对齐 makeScore 哲学），首个错误即返回，field 精确定位。
   */
  configure(config: PipelineConfig): Result<void, ConfigError> {
    const r = validatePipelineConfig(config);
    if (!r.ok) return r;
    this.cfg = r.value;
    return { ok: true, value: undefined };
  }

  /** 工位注入（加载层方言：throw 合法 —— 站点缺席即拒绝出生，由 apply 收口） */
  wire(deps: KnowledgePipelineDeps, opts?: WireOptions): void {
    if (!this.cfg) throw new Error('[KnowledgePipeline] configure() must precede wire()');
    if (!deps.vision || !deps.decision || !deps.execution || !deps.knowledge || !deps.verdictBridge) {
      throw new Error('[KnowledgePipeline] all stations plus knowledge base and verdict bridge are required');
    }
    this.deps = deps;
    this.worldModel = deps.worldModel ?? new InMemoryWorldModel();
    this.reportDir = opts?.reportDir ?? '';
    // 反遗忘接线：stateDir 在场 ⇒ wire 时水合旧脑（旁路义务：水合失败 ⇒ warn +
    // 空脑开局 —— 记忆的缺席不该让机器人失能，但必须被听见）
    if (opts?.stateDir) {
      this.persistence = new KnowledgePersistence(opts.stateDir);
      if (deps.knowledge instanceof InMemoryKnowledgeBase && this.worldModel instanceof InMemoryWorldModel) {
        const r = this.persistence.load(deps.knowledge, this.worldModel);
        if (!r.ok) {
          console.warn(`[KnowledgePipeline] state hydrate degraded: ${r.error.message}`);
          // J 纪元修正：损坏的状态文件**改名保留**而非被首个 run-end 覆写。
          // persistence 的契约是"损坏交上层决定"，但旧实现的"决定"是 warn 后
          // 照常 save —— 损坏数据无声丢失。改名 `.corrupt-<ts>` 后：新状态
          // 干净起步，旧档可取证。
          this.quarantineCorruptState();
        }
      } else {
        console.warn('[KnowledgePipeline] stateDir set but organs are not in-memory snapshots — skipping hydrate');
      }
    }
    this.metrics = opts?.metricsPath ? new MetricsLedger(opts.metricsPath) : null;
  }

  /** 损坏状态隔离（旁路义务：永不抛错；尽力而为） */
  private quarantineCorruptState(): void {
    try {
      const dir = this.persistence?.stateDir;
      if (!dir) return;
      const stamp = Date.now();
      for (const name of ['knowledge.json', 'world-model.json']) {
        const p = join(dir, name);
        if (existsSync(p)) {
          renameSync(p, `${p}.corrupt-${stamp}`);
          console.warn(`[KnowledgePipeline] quarantined corrupt state file: ${p}.corrupt-${stamp}`);
        }
      }
    } catch { /* 隔离失败不阻断启动 —— 语义退化为覆写，仍优于失能 */ }
  }

  /** 运行层入口（契约：永不抛错）。意外 = 结构化 failed 报告，交 D-4 裁决 */
  async run(intent: IntentPayload): Promise<PipelineReport> {
    const startedAt = Date.now();
    if (!this.cfg || !this.deps) {
      return this.finalReport(intent, 'failed', 'orchestrator not configured/wired', [], null, startedAt);
    }
    const cfg = this.cfg;
    const deps = this.deps;
    const outcomes: ExecutionOutcome[] = [];
    let knowledgeUsed: KnowledgeInjection | null = null;

    try {
      let verdict: PipelineVerdict | null = null;
      let terminalReason = '';
      let retryCount = 0;
      let seq = 0;
      let feedback: FailureFeedback | undefined;
      let lastSceneSummary = ''; // 并行语义：检索的 sceneDescription 只能用上一轮场景
      // ── 预测编码回路状态（惊讶计费器）──
      // O 纪元（#20）：run 级快照 —— fork 隔离本 run 的定型/入账，run 终
      // merge 重放回共享模型（J 纪元只隔离了 pendingTransition，typeOf 的
      // 中途铸造仍跨 run 互污；并发 fork 的同号类型在 merge 时重铸新 id）。
      const sharedModel = this.worldModel; // wire 铸造，跨 run 存活（run 内非空 —— 见顶部守卫）
      const worldModel = sharedModel instanceof InMemoryWorldModel ? sharedModel.fork() : sharedModel;
      // 合并先行标志：checkpointState（落盘/仪表盘）消费共享模型，必须在 merge
      // 之后观测 —— finally 侧不再重复合并（merge 重放日志，非幂等）
      let forkMerged = false;
      try {
      let pendingTransition: { fromTypeId: string; actionKey: string; seq: number; success: boolean } | null = null;
      let escalateL3 = false; // 上轮到达意外 ⇒ 本轮动用贵眼睛（L1/L2 免费看熟悉，L3 付费看意外）
      // ── 认知仪表盘计数器（证据先于修辞：每轮的感知/成本/经验命中如实入账）──
      let roundsTotal = 0;
      let l3Rounds = 0;
      let knowledgeRounds = 0;
      // ── 消融执法（科学义务）：'always' 恒开 / 'never' 恒关 / 'surprise' 计费器独裁 ──
      const ablation = cfg.ablation ?? { disableKnowledge: false, l3Policy: 'surprise' as const };

      for (let round = 0; round < MAX_ROUNDS; round++) {
        // overall 时钟：预算耗尽 ⇒ verdict='timeout'（部分轨迹保留）
        if (Date.now() - startedAt > cfg.timeout.overall) {
          verdict = 'timeout';
          terminalReason = `overall budget ${cfg.timeout.overall}ms exhausted`;
          break;
        }

        // ── 并行双触发：感知 + 隐知识检索（数据流三段论 #2 —— 防卡顿铁律）──
        roundsTotal += 1;
        const forceL3 = ablation.l3Policy === 'always'
          ? true
          : ablation.l3Policy === 'never' ? false : escalateL3;
        // J 纪元修正：本轮 forceL3 消费后即失能 —— 升级权只能由**本轮的**
        // 转移结算重新授予。旧实现只在结算成功时赋值（含 false），但结算
        // 失败/场景不可见时保持旧值 —— 一次惊讶后 L3 持续计费多轮（粘性），
        // 白烧 VLM 预算直到某次成功结算。
        escalateL3 = false;
        if (forceL3) l3Rounds += 1;
        const visionEnv: AttentionEnvelope<'vision', PerceptionRequest> = {
          station: 'vision',
          payload: {
            grid: cfg.regionGrid ?? DEFAULT_REGION_GRID,
            // 惊讶计费器：预测误差是 L3 的唯一合法开火权（d7HostPort 将其译为
            // funnelCeiling='L3' —— 每一次 VLM 开销都有惊讶背书，入链可审计）
            forceL3,
            snapshotId: undefined,
          },
          tokenBudget: cfg.stationTokenBudgets!.vision,
        };
        // ── 并行双触发：感知 + 隐知识检索（数据流三段论 #2 —— 防卡顿铁律）──
        // O 纪元（#26）：firstRoundSerialKnowledge=true 时首轮串行 —— 先感知
        // 拿新鲜场景摘要，再检索（场景信号入查询，精度换延迟，仅首轮；
        // 后续轮并行不动 —— 上一轮场景天然在场）。
        const firstRoundSerial = round === 0 && cfg.firstRoundSerialKnowledge === true
          && !ablation.disableKnowledge;
        let scene: ScenePatch[] = [];
        let injection: KnowledgeInjection | null = null;
        if (firstRoundSerial) {
          const perceiveCtrl = new AbortController();
          scene = await this.withTimeout(
            deps.vision.perceive(visionEnv, perceiveCtrl.signal),
            cfg.timeout.perPerception,
            [],
            perceiveCtrl,
          );
          lastSceneSummary = summarizeScene(scene);
          injection = await this.queryKnowledgeGuarded(intent, lastSceneSummary);
        } else {
          const perceiveCtrl = new AbortController();
          [scene, injection] = await Promise.all([
            this.withTimeout(
              deps.vision.perceive(visionEnv, perceiveCtrl.signal),
              cfg.timeout.perPerception,
              [], // 感知超时 = 空场景（决策下轮 NeedGrounding 诚实暴露）
              perceiveCtrl,
            ),
            ablation.disableKnowledge
              ? Promise.resolve(null) // 消融：无隐知识模式（检索侧断电）
              : this.queryKnowledgeGuarded(intent, lastSceneSummary),
          ]);
          lastSceneSummary = summarizeScene(scene);
        }
        if (injection) knowledgeRounds += 1;
        knowledgeUsed = injection ?? knowledgeUsed;

        // ── 预测编码回路：到达场景定型；待结算转移先惊讶后学习 ──
        // 顺序即语义：surprise 在 observe 之前（误差是学习信号 —— 先测误差，再入账）。
        // 看不见（typeOf=null）⇒ 转移悬置（失明轮丢信息是感知的诚实代价，绝不虚构定型）。
        const currentTypeId = worldModel!.typeOf(scene);
        if (currentTypeId && pendingTransition) {
          const sr: Result<SurpriseReport, unknown> = worldModel!.surprise(
            pendingTransition.fromTypeId, pendingTransition.actionKey, currentTypeId);
          if (sr.ok) {
            const observed = worldModel!.observe(
              pendingTransition.fromTypeId, pendingTransition.actionKey,
              currentTypeId, pendingTransition.success);
            if (observed.ok) {
              escalateL3 = sr.value.novel || sr.value.bits >= P.L3_ESCALATION_BITS;
              logKnowledge('world-transition', {
                intentId: intent.id, seq: pendingTransition.seq,
                from: pendingTransition.fromTypeId, action: pendingTransition.actionKey,
                to: currentTypeId, bits: sr.value.bits, novel: sr.value.novel,
                evidence: sr.value.evidence, l3Escalated: escalateL3,
              });
            }
          }
          pendingTransition = null; // 结算即清（一次性 —— 转移是证据不是滚动债务）
        }

        // ── 决策（信封铸造权：intent + scene + 隐知识注入 ≤300 字符，无截图字节）──
        const decisionCtx: DecisionContext = {
          intent,
          scene,
          knowledgeContext: injection ?? undefined,
          previousResults: intent.previousResults,
        };
        const decisionEnv: AttentionEnvelope<'decision', DecisionContext> = {
          station: 'decision',
          payload: decisionCtx,
          tokenBudget: cfg.stationTokenBudgets!.decision,
        };
        const decideCtrl = new AbortController();
        const output = await this.withTimeout(
          deps.decision.decide(decisionEnv, feedback, decideCtrl.signal),
          cfg.timeout.perStep,
          { reason: `decision step timeout after ${cfg.timeout.perStep}ms`, focus: 'full-scene' } satisfies NeedGrounding,
          decideCtrl,
        );

        // NeedGrounding 路由：桩纪元无 L3 兜底通道 ⇒ 诚实终局（grounding 批准回路是留白）
        if (isNeedGrounding(output)) {
          verdict = 'failed';
          terminalReason = `need-grounding: ${output.reason} (focus: ${output.focus})`;
          break;
        }

        // ── 执行（信封铸造权：零模型肌肉，tokenBudget 恒 0）──
        const action = output;
        seq += 1;
        const execEnv: AttentionEnvelope<'execution', AtomicAction> = {
          station: 'execution',
          payload: action,
          tokenBudget: cfg.stationTokenBudgets!.execution,
        };
        // ΠΑΝ-43~48 修复潮对接点：执行步超时的止损 abort —— signal 经工位透传到
        // 宿主端口的实际派发（超时的动作不再于后台飞行；D-5 微服务断流）。
        // 工位/端口不消费 signal 时由其内层超时兜底（浪费窗口有界，零回归）。
        const execCtrl = new AbortController();
        const result = await this.withTimeout(
          deps.execution.execute(execEnv, execCtrl.signal),
          cfg.timeout.perStep,
          {
            action,
            status: 'failure',
            durationMs: cfg.timeout.perStep,
            failure: { kind: 'timeout', detail: `execution step timeout after ${cfg.timeout.perStep}ms` },
          } satisfies ExecutionResult,
          execCtrl,
        );

        // ── 闭环进化（数据流三段论 #4 + P0-4 验收门）：打包 outcome → 结算 → 学习 ──
        // 学习的前置条件 = 结算：D-4 回执在场 ⇒ 即时结算（verdict 路径）；
        // 回执缺席 ⇒ 挂账 pending，run-end 冲账兜底 —— 未结算的 outcome 绝不进学习。
        const outcome: ExecutionOutcome = {
          intent,
          action,
          result,
          retryCount,
          totalDurationMs: Date.now() - startedAt,
        };
        outcomes.push(outcome);
        // ── 预测编码回路：本动作的转移挂账（下轮感知到达时结算 —— 成败已知，去向待察）──
        if (currentTypeId) {
          pendingTransition = {
            fromTypeId: currentTypeId,
            actionKey: transitionActionKey(action),
            seq,
            success: result.status === 'success',
          };
        }
        const settlement = deps.verdictBridge.trySettle(seq, outcome);
        if (settlement) {
          this.learnSettled(settlement);
        } else {
          deps.verdictBridge.defer(seq, outcome); // 验收门等待室
        }
        logKnowledge('knowledge-attempt', {
          intentId: intent.id, seq, actionKind: action.kind, status: result.status,
          failureKind: result.failure?.kind ?? null, retryCount,
        });
        this.safeEmit('attempt', {
          intentId: intent.id, seq, actionKind: action.kind, status: result.status,
          failureKind: result.failure?.kind ?? null,
        });

        // ── 失败路由：cancelled / timed-out 直达终局，绝不入重试循环 ──
        if (result.status !== 'failure') {
          verdict = result.status === 'success' ? 'completed' : 'degraded';
          terminalReason = result.status === 'success'
            ? 'goal achieved (hard evidence: execution success)'
            : 'completed with degraded verification (effect unverified)';
          break;
        }
        const kind = result.failure?.kind ?? 'host-error';
        if (kind === 'cancelled' || kind === 'timed-out') {
          verdict = 'aborted';
          terminalReason = `external termination (${kind}): ${result.failure?.detail ?? 'unknown'}`;
          break;
        }
        if (retryCount >= cfg.retryPolicy.maxRetries) {
          verdict = 'failed';
          terminalReason = `retries exhausted (${retryCount}): ${kind} at seq ${seq} — ${result.failure?.detail ?? 'unknown'}`;
          break;
        }
        retryCount += 1;
        feedback = { reason: result.failure?.detail ?? 'unknown failure', retryCount };
        // 退避受 overall 预算约束（风险加固）：睡眠绝不超过剩余预算 ——
        // 轮首时钟只查一次，裸睡 maxBackoffMs 会让 run 超冲 overall 达一个退避周期
        const remaining = cfg.timeout.overall - (Date.now() - startedAt);
        await this.sleep(Math.max(0, Math.min(
          cfg.retryPolicy.backoffMs * 2 ** (retryCount - 1),
          cfg.retryPolicy.maxBackoffMs,
          remaining,
        )));
      }

      verdict ??= 'failed';
      terminalReason ||= `no progress possible after ${outcomes.length} outcome(s)`;
      this.settlePending(intent.id); // P0-4 终局冲账：本 intent 的挂账在此结算学习
      const consolidation = this.consolidateKnowledge(intent.id, outcomes.length); // 神经元纪元：run-end 入睡（旁路）
      // O 纪元（#20）：合并先行 —— checkpointState 的落盘/仪表盘读共享模型，
      // 旧序（先 checkpoint 后 finally-merge）落盘的是**上一 run 结束时**的世界
      // 模型，本轮全部观察跨会话丢失（"反遗忘"对 worldModel 永不生效）。
      if (!forkMerged && worldModel !== sharedModel &&
          worldModel instanceof InMemoryWorldModel && sharedModel instanceof InMemoryWorldModel) {
        sharedModel.merge(worldModel);
        forkMerged = true;
      }
      // ΠΑΝ-47（世界模型有界化 · 接线）：fork 重放回共享模型后、落盘前，类型数
      // 过碎片收拢阈值 ⇒ 维护幕（mergeSimilarTypes 收拢 + 容量上界驱逐最弱类型，
      // 见 InMemoryWorldModel.maintainCapacity）。触发条件在**共享模型**上检查
      //（fork 内不维护 —— merge/evict 不进 journal，重放等价性优先）；落盘在
      // 维护之后 ⇒ world-model.json 快照有界。旁路义务：维护异常只记链不击穿报告。
      if (sharedModel instanceof InMemoryWorldModel &&
          sharedModel.stats().types >= WORLD_MODEL_MERGE_SWEEP_TYPES) {
        try {
          const maintained = sharedModel.maintainCapacity();
          if (maintained.merged.length > 0 || maintained.evicted.length > 0) {
            logKnowledge('world-transition', {
              intentId: intent.id, maintenance: 'world-model-bounded',
              merged: maintained.merged.length, evicted: maintained.evicted.length,
              types: sharedModel.stats().types,
            });
          }
        } catch {
          // 维护是旁路义务：失败绝不击穿 run 报告（下一 run-end 的触发条件会再试）
        }
      }
      this.checkpointState(intent.id, verdict, { roundsTotal, l3Rounds, knowledgeRounds, executions: outcomes.length }, consolidation, startedAt); // 反遗忘 + 仪表盘
      return this.finalReport(intent, verdict, terminalReason, outcomes, knowledgeUsed, startedAt);
      } finally {
        // O 纪元（#20）：run 终合并 —— fork 的操作日志重放回共享模型（双出口共用；
        // 异常出口同样合并已发生的观察；正常出口已在 checkpoint 前合并，不重复）
        if (!forkMerged &&
            worldModel !== sharedModel &&
            worldModel instanceof InMemoryWorldModel && sharedModel instanceof InMemoryWorldModel) {
          sharedModel.merge(worldModel);
        }
      }
    } catch (e: unknown) {
      // 运行层兜底：任何意外 ⇒ 结构化 failed（契约 —— 永不抛错）
      const msg = e instanceof Error ? e.message : String(e);
      logKnowledge('knowledge-internal-fault', { intentId: intent.id, detail: msg.slice(0, 200) });
      this.settlePending(intent.id); // 冲账例外无豁免：已发生的 outcome 照常结算（内部故障 ≠ 证据销毁）
      return this.finalReport(intent, 'failed', `internal pipeline fault: ${msg}`, outcomes, knowledgeUsed, startedAt);
    }
  }

  /** 生命周期归零（Result 降级 —— 账本审计语义） */
  dispose(): Result<void, Error> {
    try {
      const r = this.deps?.knowledge.dispose();
      this.deps = null;
      this.cfg = null;
      this.worldModel = null;
      this.reportDir = '';
      if (r && !r.ok) return { ok: false, error: r.error };
      return { ok: true, value: undefined };
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      return { ok: false, error: new Error(`dispose fault: ${msg}`) };
    }
  }

  // ─── 私有主权域 ───

  /**
   * P0-4 终局冲账（run 双出口共用）：本 intent 的 pending 结算 → 逐笔学习。
   * 迟到回执在场 ⇒ settledBy='verdict'（证据后到不是沉默）；缺席 ⇒ 'run-end'
   * （诚实降级：学习不因 D-4 沉默而缺席，结算单如实标注证据缺席）。
   * 作用域限定（风险加固）：只冲本 intent 挂账 —— 并发 run 时绝不越权结算
   * 他人的等待室（验收门语义不被他人的终局时钟劫持）。
   * 幂等：冲账即清空等待室（settleAll 契约）—— 双出口至多各冲一次。
   */
  private settlePending(intentId: string): void {
    if (!this.deps) return;
    for (const settlement of this.deps.verdictBridge.settleAll(intentId)) {
      this.learnSettled(settlement);
    }
  }

  /**
   * 睡眠整合（神经纪元）：run-end 冲账结算完成后触发 —— 情景记忆聚类蒸馏为
   * 语义记忆（海马体→皮层）。旁路义务：整合失败/缺席（接口未实现）只记链，
   * 绝不击穿流水线；「做梦」是资产增值，不是主路债务。
   * 消融执法：disableKnowledge ⇒ 不做梦（对照组的睡眠也该被消融 —— 否则
   * 「关知识」的对照组仍在偷偷进化，实验就是假的）。
   */
  private consolidateKnowledge(intentId: string, outcomeCount: number): number {
    if (!this.deps?.knowledge.consolidate) return 0; // 可选能力缺席 ⇒ 诚实跳过
    if (this.cfg?.ablation?.disableKnowledge) return 0; // 消融：睡眠断电
    try {
      const r = this.deps.knowledge.consolidate();
      if (!r.ok) {
        logKnowledge('knowledge-internal-fault', {
          intentId, phase: 'consolidate', field: r.error.field, reason: r.error.reason,
        });
        return 0;
      }
      logKnowledge('knowledge-consolidated', {
        intentId, outcomeCount,
        episodes: r.value.episodes, clusters: r.value.clusters,
        consolidated: r.value.consolidated, episodedDecayed: r.value.episodedDecayed,
        durationMs: r.value.durationMs,
      });
      return r.value.consolidated;
    } catch {
      // 违约抛错：旁路义务，静默降级 —— 睡眠失败不影响清醒时的成绩
      return 0;
    }
  }

  /**
   * run-end 检查点（证据先于修辞的落账面）：
   *   1. 仪表盘：一行 RunMetricRecord 追加 JSONL（旁路义务）
   *   2. 反遗忘：两器官原子落盘（旁路义务 —— 落盘失败绝不击穿 run 报告）
   *   3. ΝΩ-28 任务1（M5 奖励接线）：库存快照 + 仪表盘窗口 → 逐类别成败收割 →
   *      insert 臂记账（条目在场 = 入库操作的产物 —— applyHarvestedRewards 缺省臂）。
   *      旁路义务：收割/记账永不抛；仪表盘缺席 ⇒ 无反馈源 ⇒ 诚实跳过（不记噪声账）；
   *      消融执法：disableKnowledge ⇒ 奖励通道同律断电（对照组的老虎机也不许偷学
   *      —— 与 learnSettled/consolidateKnowledge 的消融先例同律）。
   */
  private checkpointState(
    intentId: string,
    verdict: PipelineVerdict,
    counters: { roundsTotal: number; l3Rounds: number; knowledgeRounds: number; executions: number },
    consolidated: number,
    startedAt: number,
  ): void {
    try {
      const wmStats = this.worldModel instanceof InMemoryWorldModel ? this.worldModel.stats() : { types: 0, observations: 0 };
      const kbCount = this.deps?.knowledge instanceof InMemoryKnowledgeBase
        ? this.deps.knowledge.snapshot().length : 0;
      if (this.metrics) {
        this.metrics.record({
          ts: Date.now(),
          intentId,
          verdict,
          rounds: counters.roundsTotal,
          executions: counters.executions,
          durationMs: Date.now() - startedAt,
          l3Rounds: counters.l3Rounds,
          knowledgeRounds: counters.knowledgeRounds,
          knowledgeEntries: kbCount,
          worldTypes: wmStats.types,
          worldObservations: wmStats.observations,
          consolidated,
        });
      }
      if (this.persistence && this.deps?.knowledge instanceof InMemoryKnowledgeBase &&
          this.worldModel instanceof InMemoryWorldModel) {
        const r = this.persistence.save(this.deps.knowledge, this.worldModel);
        if (!r.ok) logKnowledge('knowledge-internal-fault', { intentId, phase: 'persist', reason: r.error.message.slice(0, 160) });
      }
      // M5 奖励闭环：metrics.readAll 含本轮刚落账的行（appendFileSync 同步 flush），
      // 收割窗口（7 天缺省）内逐条目判成败 —— 键在此时首次入册（台账律），
      // sleep 第④幕 convergeMemoryOps 消费同一账本收敛阈值。
      // ΠΑΝ-44（同证据单次计数）：只收割 updatedAt > lastHarvestAt 的**新证据**
      //（水位线见字段注记），收割后推进水位线 —— Beta 后验 n 恢复真实样本量
      //（旧实现：窗口内每个 run-end 对同一批 updatedAt 冻结的条目重复记账）。
      if (this.metrics && !this.cfg?.ablation?.disableKnowledge &&
          this.deps?.knowledge instanceof InMemoryKnowledgeBase) {
        const freshEvidence = this.deps.knowledge.snapshot()
          .filter(e => e.updatedAt > this.lastHarvestAt);
        if (freshEvidence.length > 0) {
          const trials = harvestMemoryOpRewards(freshEvidence, this.metrics.readAll().records);
          applyHarvestedRewards(trials, 'insert');
        }
        this.lastHarvestAt = Date.now();
      }
    } catch {
      // 检查点整体旁路：仪表盘/落盘/奖励收割的缺席不该让认知失能
    }
  }

  /**
   * 隐知识检索守卫（防卡顿铁律的执法点）：与感知并行触发；越 knowledgeTimeout 或
   * 检索失败/违约 ⇒ 返回 null（无隐知识模式降级）—— 隐知识缺席是旁路，绝不阻塞流水线。
   */
  private async queryKnowledgeGuarded(
    intent: IntentPayload, sceneSummary: string,
  ): Promise<KnowledgeInjection | null> {
    if (!this.cfg || !this.deps) return null;
    const cfg = this.cfg;
    const query: KnowledgeQuery = {
      sceneDescription: sceneSummary,
      intentDescription: intent.description,
      maxResults: cfg.knowledgeMaxResults,
    };
    let timer: ReturnType<typeof setTimeout> | undefined;
    const startedAt = Date.now();
    try {
      const timeoutP = new Promise<null>(resolve => {
        timer = setTimeout(() => resolve(null), cfg.knowledgeTimeout);
      });
      // 契约上 query 是同步 Result —— 经 microtask 脱离关键路径（未来异步实现零改造接入）
      const queryP = Promise.resolve().then(() => this.deps!.knowledge.query(query));
      const winner = await Promise.race([queryP, timeoutP]);
      if (winner === null) {
        // 检索历史入链（P1-5）：超时降级也是可审计的历史（旁路义务，不占检索预算）
        logKnowledge('knowledge-retrieval', { intentId: intent.id, outcome: 'timeout', budgetMs: cfg.knowledgeTimeout });
        return null; // 超时降级：无隐知识模式（防卡顿铁律）
      }
      if (!winner.ok) {
        logKnowledge('knowledge-retrieval', { intentId: intent.id, outcome: 'error', field: winner.error.field });
        return null; // 检索失败降级：旁路义务，不击穿流水线
      }
      // 事后守卫：同步阻塞型实现无法被 race 抢占（事件循环被占）—— 墙钟越限同样降级
      if (Date.now() - startedAt > cfg.knowledgeTimeout) {
        logKnowledge('knowledge-retrieval', { intentId: intent.id, outcome: 'overtime', elapsedMs: Date.now() - startedAt });
        return null;
      }
      logKnowledge('knowledge-retrieval', {
        intentId: intent.id, outcome: 'hit', entries: winner.value.entries.length,
        latencyMs: winner.value.latencyMs,
      });
      return distillInjection(winner.value, cfg.knowledgeMaxChars);
    } catch {
      return null; // 违约抛错降级：同上
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  /** 步超时包裹：越限 ⇒ fallback + 止损 abort（杀一刀且断其后路 —— 超时的感知/
   *  决策不再于后台烧 VLM/HTTP 资源；工位不支持消费 signal 时由其内层超时兜底，
   *  浪费窗口仍有界）；违约抛错 ⇒ fallback（纵深防御） */
  private async withTimeout<T>(p: Promise<T>, timeoutMs: number, fallback: T, abort?: AbortController): Promise<T> {
    let timer: ReturnType<typeof setTimeout> | undefined;
    try {
      return await Promise.race([
        p,
        new Promise<T>(resolve => {
          timer = setTimeout(() => {
            abort?.abort();
            resolve(fallback);
          }, timeoutMs);
        }),
      ]);
    } catch {
      return fallback;
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  /** 闭环进化旁路（P0-4 验收门执法点）：只消费已结算的 outcome ——
   *  learnFromOutcome 失败/违约只静默（学习绝不能杀死执行报告）。
   *  学习历史入链（P1-5）：每笔 auto-learn 都是防篡改账本上的一行。 */
  private learnSettled(settlement: OutcomeSettlement): void {
    if (this.cfg?.ablation?.disableKnowledge) return; // 消融：学习断电（对照组不进化）
    try {
      const r = this.deps?.knowledge.learnFromOutcome(settlement.outcome);
      if (r && !r.ok) {
        console.warn(`[KnowledgePipeline] learnFromOutcome degraded: ${r.error.field}: ${r.error.reason}`);
        // ΠΑΝ-48（DS-4 接线缝兑现）：容量拒绝 = 学习闭环断裂（满库且全
        // manual/import 主权条目无 auto-learn 可驱逐）——「探针失败 ⇒ auto-learn
        // 亲证压制诞生 ⇒ 不再探针」的知识闭环在此断线，跨 run 的探针续护必须
        // 由进程级闩锁接管（此前 stations.ts 的 escalateProbeLatch 声明了本接线
        // 缝但无人调用 —— 注释承诺的保护是死代码，C1-8 H5）。只对真实
        // ReflexiveDecisionStation 工位上报（instanceof 收窄 —— 注入的测试桩
        // 无此升级面，测试端口不变）；上报永不抛（工位守卫 + 本层 try 兜底）。
        if (r.error?.field === 'capacity') {
          const decision = this.deps?.decision;
          if (decision instanceof ReflexiveDecisionStation) {
            decision.escalateProbeLatch(settlement.outcome.intent.id);
            logKnowledge('knowledge-internal-fault', {
              intentId: settlement.outcome.intent.id,
              phase: 'probe-latch-escalated',
              reason: 'learnFromOutcome capacity rejection — process-level probe latch armed (1h decay)',
            });
          }
        }
        return;
      }
      logKnowledge('knowledge-learned', {
        intentId: settlement.outcome.intent.id,
        subject: settlement.subject,
        settledBy: settlement.settledBy,
        actionKind: settlement.outcome.action.kind,
        status: settlement.outcome.result.status,
      });
      this.safeEmit('learned', {
        intentId: settlement.outcome.intent.id,
        category: settlement.outcome.result.status === 'failure' ? 'error-pattern' : 'workflow',
        retryCount: settlement.outcome.retryCount,
        settledBy: settlement.settledBy,
        learnedAt: Date.now(),
      });
    } catch {
      // 违约抛错：旁路义务，静默降级
    }
  }

  /** 事件发射守卫（发射失败是旁路义务 —— 绝不阻断主流程） */
  private safeEmit(kind: 'attempt' | 'learned', payload: KnowledgeAttemptPayload | KnowledgeLearnedPayload): void {
    if (!this.deps?.emit) return;
    if (kind === 'attempt') emitKnowledgeAttempt(this.deps.emit, payload as KnowledgeAttemptPayload);
    else emitKnowledgeLearned(this.deps.emit, payload as KnowledgeLearnedPayload);
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private finalReport(
    intent: IntentPayload,
    verdict: PipelineVerdict,
    terminalReason: string,
    outcomes: ExecutionOutcome[],
    knowledgeUsed: KnowledgeInjection | null,
    startedAt: number,
  ): PipelineReport {
    const report: PipelineReport = {
      intentId: intent.id,
      verdict,
      outcomes,
      knowledgeUsed,
      terminalReason: terminalReason.slice(0, 120), // Token 纪律：对话流只进这一行
      reportPath: this.persistReport(intent.id, verdict, { outcomes, startedAt, knowledgeUsed }),
      chainTip: sandboxLog.tip, // P1-5：报告锚定链尖端（D-6 同方言，D-4 审计定位）
    };
    logKnowledge('knowledge-run-end', {
      intentId: report.intentId,
      verdict: report.verdict,
      outcomes: report.outcomes.length,
      knowledgeUsed: report.knowledgeUsed !== null,
      reportPath: report.reportPath,
    });
    if (this.deps?.emit) {
      emitKnowledgeRunEnd(this.deps.emit, {
        intentId: report.intentId,
        verdict: report.verdict,
        outcomes: report.outcomes.length,
        knowledgeUsed: report.knowledgeUsed !== null,
        reportPath: report.reportPath,
        endedAt: Date.now(),
      });
    }
    return report;
  }

  /** 结构化落盘（Token 纪律：对话流只回句柄；失败降级 'in-memory' 并 warn）。
   *  文件名带进程内序号（风险加固）：同 intent 同毫秒的并发报告不互相覆盖。
   *  intentId 收敛到文件名安全字符（风险加固）：宿主可传任意 id ——
   *  `../` / 盘符 / 路径分隔符不得逃出 reportDir（路径遍历闸门）。 */
  private persistReport(intentId: string, verdict: string, extra: Record<string, unknown>): string {
    if (!this.reportDir) return 'in-memory';
    try {
      mkdirSync(this.reportDir, { recursive: true });
      this.reportCounter += 1;
      const safeId = intentId.replace(/[^A-Za-z0-9._-]+/g, '_');
      const full = join(this.reportDir, `knowledge-${safeId}-${Date.now()}-${this.reportCounter}.json`);
      writeFileSync(full, JSON.stringify({ intentId, verdict, ...extra }, null, 2), 'utf8');
      return full;
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      console.warn(`[KnowledgePipeline] report persist failed: ${msg}`);
      return 'in-memory';
    }
  }
}
