// src/uiMemory.ts
// 突破二：场景式 UI 记忆（Episodic Landmark Memory）。
// 滑动窗口只记得「最近几张图」；本模块让 Agent 拥有跨任务的位置记忆：
// 「上次在 VS Code 里，设置按钮在 (0.93, 0.04)」—— 成功点击过的目标被记为
// landmark，之后用自然语言召回，直接获得高置信坐标先验（仍需截图验证）。
// 检索打分 = 文本重合度 + 成功次数加成 + 时间衰减 + 场景指纹匹配加成，全部本地零成本。
import { similarity } from './perceptualHash';

/** Y-8：地标放射性半衰期（小时）—— 一周（测试的事实源） */
export const LANDMARK_HALF_LIFE_H = 168;

export interface Landmark {
  id: number;
  description: string;            // 模型对目标的自然语言描述
  appHint?: string;               // 可选的应用/上下文线索
  sceneHash?: string;             // 记忆形成时的整屏指纹：场景匹配加成的事实源
  regionHash?: string;            // 目标邻域外观指纹：点击前核实「目标还在原位」的事实源
  normalized: { x: number; y: number };
  successCount: number;           // 该位置被验证成功的次数
  lastUsedAt: number;
}

/** 分词：拉丁词 + CJK 单字 + CJK 二元组 —— 中英混合描述都能命中 */
export function tokenize(text: string): string[] {
  const latin = text.toLowerCase().match(/[a-z0-9]+/g) ?? [];
  const cjk = text.match(/[\u4e00-\u9fff]/g) ?? [];
  const bigrams: string[] = [];
  for (let i = 0; i < cjk.length - 1; i++) bigrams.push(cjk[i] + cjk[i + 1]);
  return [...latin, ...cjk, ...bigrams];
}

/** 重合系数：|A∩B| / min(|A|,|B|)，短查询也能命中长描述 */
export function overlapCoefficient(a: string[], b: string[]): number {
  if (a.length === 0 || b.length === 0) return 0;
  const setB = new Set(b);
  const inter = a.filter(t => setB.has(t)).length;
  return inter / Math.min(a.length, b.length);
}

class UIMemory {
  private landmarks: Landmark[] = [];
  private capacity = 200;
  private nextId = 1;

  configure(capacity: number) {
    this.capacity = capacity;
  }

  reset() {
    this.landmarks = [];
  }

  /** 记录（或强化）一个 landmark：同描述就近复用，成功次数 +1；sceneHash/regionHash 记录当时外观 */
  remember(description: string, x: number, y: number, appHint?: string, sceneHash?: string, regionHash?: string): Landmark {
    const existing = this.landmarks.find(l =>
      l.description.toLowerCase() === description.toLowerCase() &&
      Math.abs(l.normalized.x - x) < 0.02 && Math.abs(l.normalized.y - y) < 0.02,
    );
    if (existing) {
      existing.successCount++;
      existing.lastUsedAt = Date.now();
      existing.sceneHash = sceneHash ?? existing.sceneHash;   // 场景指纹滚动更新
      existing.regionHash = regionHash ?? existing.regionHash; // 目标外观滚动更新
      return existing;
    }

    const landmark: Landmark = {
      id: this.nextId++,
      description,
      appHint,
      sceneHash,
      regionHash,
      normalized: { x, y },
      successCount: 1,
      lastUsedAt: Date.now(),
    };
    this.landmarks.push(landmark);

    // 容量驱逐：优先淘汰「低成功 + 陈旧」的条目
    // P2b-2（缺陷修复，出处=全库遍历报告）：旧公式 successCount × lastUsedAt 是
    // 量纲失衡的乘积排序 —— lastUsedAt（epoch 毫秒，~1.8e12）与 successCount
    //（1~几十）相乘后，乘积序实际只被相对离散度更大的那一维决定（同会话内地标
    // 时间戳的相对差 <0.1%，成功计数的相对差可达几十倍 ⇒ 新旧地标的排序话语权
    // 被成功数独占，「陈旧该逐」的设计维度近乎为零），「低成功 + 陈旧」的二维
    // 意图退化成一维。新公式把两维各自归一到可比尺度再相乘：
    //   score = log1p(successCount) × 2^(-ageH / LANDMARK_HALF_LIFE_H)
    // · log1p：成功计数压到 [0.69, ~4]（s=1..50）—— 保序但边际递减（第 50 次
    //   成功不该有第 1 次的 50 倍权重），同新近度下 score 退化为 log1p(s)，
    //   成功计数独占话语（s=8 是 s=1 的 3.2 倍 —— 真实话语权，不再被 epoch
    //   毫秒基数淹没）；
    // · 半衰因子：复用库内放射性半衰期常量 LANDMARK_HALF_LIFE_H=168h（Y-8 立法，
    //   recall 的信任衰减同族同源 —— 同一地标在「召回打分」与「容量驱逐」按
    //   同一时钟衰变，不引入新魔法数）。陈旧惩罚呈指数：一周减半、两周 1/4。
    // 两维都有真实否决权：成功再多也敌不过时间 —— s=100（log1p≈4.6）在 3 个
    // 半衰期后衰减 8 倍至 ~0.58，低于新鲜 s=1 的 0.69 ⇒ 该逐；时间再新也挡不住
    // 成功劣势 —— 同龄下 s=1 恒败给 s=8。
    if (this.landmarks.length > this.capacity) {
      const now = Date.now();
      const keepScore = (l: Landmark) =>
        Math.log1p(l.successCount) * Math.pow(2, -((now - l.lastUsedAt) / 3_600_000) / LANDMARK_HALF_LIFE_H);
      this.landmarks.sort((a, b) => keepScore(b) - keepScore(a));
      this.landmarks = this.landmarks.slice(0, this.capacity);
    }
    return landmark;
  }

  /** 按 ID 精确取回 landmark（记忆预验用）；不存在返回 undefined */
  get(id: number): Landmark | undefined {
    return this.landmarks.find(l => l.id === id);
  }

  get size(): number {
    return this.landmarks.length;
  }

  /** checkpoint 序列化：完整内存态 + ID 发号器进度 */
  dump(): { landmarks: Landmark[]; nextId: number } {
    return { landmarks: this.landmarks, nextId: this.nextId };
  }

  restore(data: { landmarks?: Landmark[]; nextId?: number } | undefined): void {
    if (!data?.landmarks) return;
    this.landmarks = data.landmarks;
    this.nextId = data.nextId ?? (this.landmarks.at(-1)?.id ?? 0) + 1;
  }

  /**
   * 召回 top-k：score = overlap + 0.05*min(successCount,6) + 时间衰减 + 场景匹配加成。
   * currentSceneHash 与 landmark 形成时同场景（相似度>=0.9）⇒ +0.3 强加成 ——
   * 「还是那个界面」时，历史坐标的置信度显著更高。
   */
  recall(query: string, k = 5, currentSceneHash?: string): Array<Landmark & { score: number }> {
    const qTokens = tokenize(query);
    const now = Date.now();
    return this.landmarks
      .map(l => {
        const lTokens = tokenize(l.description + ' ' + (l.appHint ?? ''));
        const text = overlapCoefficient(qTokens, lTokens);
        // S 纪元（S-4）：Beta(1,1) 后验信任 —— (s+1)/(s+2) 取代线性截断 min(s,6)。
        // 实际值域 [0.10→0.15)（s=0 起 0.10，渐近 0.15）：Y 纪元真机电池验证后的
        // 现行刻度，信任项刻意轻于文本重合/场景加成（0.3 档）。式中 0.3 只是
        // 与旧 0.05×min(s,6) 上界的量纲溯源，不构成值域承诺（勿据其反推量级）。
        // Y 纪元（Y-8）：放射性衰变半衰期 —— 信任再高也要随时间衰变：
        // w(t) = 2^(-t/T½)，T½ = 168h（一周）。UI 演化令旧地标的先验价值
        // 指数衰减；成功使用重置衰变时钟（remember 强化时 lastUsedAt 已滚动）。
        const ageH = (now - l.lastUsedAt) / 3_600_000;
        const decay = Math.pow(2, -ageH / 168);
        const trust = (0.3 * ((l.successCount + 1) / (l.successCount + 2)) * (1 / 3) + 0.05) * decay;
        const recency = 0.1 * Math.exp(-ageH / 24);
        const stale = ageH > 2 * 168;
        let sceneBonus = 0;
        if (currentSceneHash && l.sceneHash && similarity(currentSceneHash, l.sceneHash) >= 0.9) {
          sceneBonus = 0.3;
        }
        return { ...l, stale, decay: Math.round(decay * 1000) / 1000, score: Math.round((text + trust + recency + sceneBonus) * 1000) / 1000 };
      })
      // 设计决策（J 纪元立法，此前无文档）：信任/新近分量可独立过线 —— 零文本
      // 重合的地标允许作为 top-k 填充（探索性召回：老位置即使换任务也有先验价值）。
      // 若需严格文本相关，把过滤改为 overlap > 0 || sceneMatch 即可 —— 行为变更
      // 需同步 uiMemory.test 的阈值断言。
      .sort((a, b) => b.score - a.score)
      .slice(0, k);
  }
}

// 单例：跨会话的肌肉记忆
export const uiMemory = new UIMemory();
