// src/kernel/productionSpecs.ts
// W6-1（doctor 债清偿·smell.over-engineering）：从 kernel/index.ts 提取的生产内核
// 入册单数据面 —— 纯数据（ReadonlyArray<ProductionKernelParamSpec>），零逻辑零副作用，
// 逐字节搬运（数值/键名/注记零变更）；index.ts 保留桶职责与 registerProductionKernels()。
//
// ΝΩ-6（安全参数分池）：入册单为参数增补 safetyCritical 标记 —— 承载安全语义
// 结构前提的键（uncertainty.highProceed 的「高危无免检直通道」、宪法两律、popup
// 施密特对等安全语义键）隔离出自动校准池：KernelCalibrator.tick 对其跳过自动
// 校准（值只经 gym 实验室 → 显式 promoteFrom 通道移动；见 calibrator.ts 的
// 立法注释）。标记只在本册声明（register 的 normalizeSpec 不透传未知字段 ——
// 注册表条目零形状变化），SAFETY_CRITICAL_KERNEL_KEYS 为其唯一派生只读视图。
import type { KernelParamSpec } from './registry';

/**
 * 生产内核规格：KernelParamSpec + ΝΩ-6 安全分池标记。
 * safetyCritical 仅由本册数据面声明（不进 KernelParamSpec / 注册表存储 —— 注册表
 * 形状零变化），registerProductionKernels 的 `{ ...spec }` 展开传入 register 时
 * 被 normalizeSpec 静默丢弃（无害超额字段）。
 */
export interface ProductionKernelParamSpec extends KernelParamSpec {
  /**
   * ΝΩ-6 安全分池标记：true ⇒ 该键承载安全语义的结构前提（校准器的阈学习可能
   * 静默放宽它）⇒ KernelCalibrator.tick 跳过自动校准并立 skipped-safety-critical
   * 报告；换值唯一合法通道 = gym 实验室进化 → 显式 promoteFrom。缺席 = 普通键。
   */
  safetyCritical?: boolean;
}

/**
 * 生产内核入册单：Θ-4 + Ξ-D 接线的全部读点键（R3-3 后 60 键 / 21 读点文件）。
 * min/max 按 census 区间；defaultValue = 各读点现行字面量（零行为变化的锚）；
 * organ 为消费器官名（与 gym LAB_KERNEL_SPECS 同一词表 + 新器官扩展）。
 *
 * 诚实否决记录（审了不接 —— 与接线同等立档在案）：
 *   · BM25 k1/b（semanticHash 检索层）：模块立法「值即设计非旋钮」—— k1/b 是
 *     排名函数的形状参数而非可进化阈值，接线只会把立法降格为旋钮；
 *   · policyEngine 七处效用基线（escalate/utility 诸常量）：进化价值低 ——
 *     它们只在日志/注记里排序次序，不参与任何判决翻转。
 */
export const PRODUCTION_KERNEL_SPECS: ReadonlyArray<ProductionKernelParamSpec> = [
  // ── 感知器官（worldSnapshot.snapshotChanged 的 dhash 汉明容差） ──
  {
    key: 'world.hammingTolerance',
    organ: 'perception',
    defaultValue: 3,
    min: 1,
    max: 8,
    note: 'snapshotChanged 的 dhash 汉明容差：距离 ≤ 容差视为像素未动（缺省 3；与训练营 LAB_KERNEL_SPECS 同键同区间）',
  },
  // ── 仲裁器官（vlm/arbitration 的双源融合判据） ──
  {
    key: 'arbitration.iouThreshold',
    organ: 'arbitration',
    defaultValue: 0.5,
    min: 0.3,
    max: 0.8,
    note: '双源元素融合的 IoU 配对门限（缺省 0.5）',
  },
  {
    key: 'arbitration.agreementBonus',
    organ: 'arbitration',
    defaultValue: 0.15,
    min: 0,
    max: 0.3,
    note: '双源一致元素的置信加成，融合置信 = min(1,(cv+cl)/2+此值)（缺省 0.15）',
  },
  {
    key: 'arbitration.textSimilarity',
    organ: 'arbitration',
    defaultValue: 0.8,
    min: 0.5,
    max: 0.95,
    note: 'arbitrateText 的归一化 Levenshtein 相似判决线（缺省 0.8）',
  },
  // ── 策略器官（autonomy/policyEngine 的元素匹配置信门槛） ──
  {
    key: 'policy.matchConfident',
    organ: 'policy',
    defaultValue: 0.55,
    min: 0.3,
    max: 0.9,
    note: '判据-元素匹配置信门槛：最佳候选得分低于此值 ⇒ uncertain（缺省 0.55）',
  },
  {
    key: 'policy.tieGap',
    organ: 'policy',
    defaultValue: 0.05,
    min: 0.01,
    max: 0.2,
    note: '候选并列判定：最佳与次佳得分差小于此值 ⇒ uncertain（缺省 0.05）',
  },
  // ── 策略器官（autonomy/counterfactual 效用权重三键 —— ΝΩ-10 与 tieGap 同律入册）──
  {
    key: 'policy.progressWeight',
    organ: 'policy',
    defaultValue: 0.5,
    min: 0,
    max: 1,
    note: 'Φ-9 反事实效用进展权重缺省（U = w_p·progress + w_i·info − w_r·risk；缺省 0.5 = counterfactualUtil.DEFAULT_WEIGHTS.progress 字面量锚，未注册回声零漂移；调用方显式 ctx.weights 仍最高优先）',
  },
  {
    key: 'policy.infoWeight',
    organ: 'policy',
    defaultValue: 0.3,
    min: 0,
    max: 1,
    note: 'Φ-9 反事实效用信息增益权重缺省（缺省 0.3 = DEFAULT_WEIGHTS.info 字面量锚；三键全被置 0 时 resolveWeights 整组回退模块字面量——纪元 Δ 全零设防不随内核漂移）',
  },
  {
    key: 'policy.riskWeight',
    organ: 'policy',
    defaultValue: 0.2,
    min: 0,
    max: 1,
    note: 'Φ-9 反事实效用风险惩罚权重缺省（缺省 0.2 = DEFAULT_WEIGHTS.risk 字面量锚；风险分层分表 RISK_SCORES 的量级由此键放大/收敛）',
  },
  // ── 认识论器官（autonomy/uncertainty 的校准常数与三档双阈值） ──
  {
    key: 'uncertainty.alpha',
    organ: 'uncertainty',
    defaultValue: 4,
    min: 1,
    max: 10,
    note: 'Beta 式校准 α（自报可信 ⇒ 确实可信的先验强度；缺省 4，与 β=1 联合得 eff 值域 [0.2,0.8]）',
  },
  {
    key: 'uncertainty.beta',
    organ: 'uncertainty',
    defaultValue: 1,
    min: 0.5,
    max: 5,
    note: 'Beta 式校准 β（自报不可信 ⇒ 其实可信的底噪强度；缺省 1）',
  },
  {
    key: 'uncertainty.highProceed',
    organ: 'uncertainty',
    defaultValue: 0.85,
    min: 0.7,
    max: 1,
    safetyCritical: true,
    note: 'high 档 proceed 直放线（缺省 0.85 > 校准值域上限 0.8 —— 高危无免检直通道的刻意设计）。ΝΩ-6 safetyCritical：本键区间 [0.7,1] 与校准值域 [0.2,0.8] 交叠，在线校准器的阈学习可能把值学到 ≤0.8 ⇒ proceed×high 从不可达变可达、静默拆掉金丝雀守卫的设计前提 —— 故隔离出自动校准池，换值仅经 gym→显式 promoteFrom',
  },
  {
    key: 'uncertainty.highVlm',
    organ: 'uncertainty',
    defaultValue: 0.6,
    min: 0.4,
    max: 0.8,
    note: 'high 档云脑复核线（缺省 0.6）',
  },
  {
    key: 'uncertainty.mediumProceed',
    organ: 'uncertainty',
    defaultValue: 0.7,
    min: 0.55,
    max: 0.9,
    note: 'medium 档 proceed 直放线（缺省 0.7）',
  },
  {
    key: 'uncertainty.mediumVlm',
    organ: 'uncertainty',
    defaultValue: 0.45,
    min: 0.3,
    max: 0.65,
    note: 'medium 档云脑复核线（缺省 0.45）',
  },
  {
    key: 'uncertainty.lowProceed',
    organ: 'uncertainty',
    defaultValue: 0.5,
    min: 0.35,
    max: 0.8,
    note: 'low 档 proceed 直放线（缺省 0.5）',
  },
  {
    key: 'uncertainty.lowVlm',
    organ: 'uncertainty',
    defaultValue: 0.3,
    min: 0.15,
    max: 0.5,
    note: 'low 档云脑复核线（缺省 0.3）',
  },
  // ── OCR 器官（textReader 的词置信截断线） ──
  {
    key: 'ocr.wordConfidenceFloor',
    organ: 'ocr',
    defaultValue: 60,
    min: 30,
    max: 90,
    note: 'legacy tesseract 词级置信截断线：confidence ≤ 此值的词被滤除（缺省 60）',
  },
  // ── 接地器官（vlm/grounding 的 NMS 去冗余阈） ──
  {
    key: 'grounding.nmsIou',
    organ: 'grounding',
    defaultValue: 0.6,
    min: 0.4,
    max: 0.8,
    note: 'NMS 去冗余 IoU 阈：≥ 此值视为同一元素的重复检出（缺省 0.6）',
  },
  // ── 技能器官（skillLibrary.match 的入口场景同屏判据） ──
  {
    key: 'skill.sceneGate',
    organ: 'skill',
    defaultValue: 0.9,
    min: 0.7,
    max: 0.98,
    note: '技能匹配的入口场景指纹相似门：dhash 相似 ≥ 此值给同屏加成（缺省 0.9）',
  },
  {
    key: 'skill.sceneBonus',
    organ: 'skill',
    defaultValue: 0.3,
    min: 0,
    max: 0.5,
    note: '技能匹配的同屏加成分值（缺省 0.3）',
  },
  // ══ 纪元 Ξ（Ξ-D 二梯队全接线）：以下 37 键为第二梯队读点 ══

  // ── 判决器官（policyEngine 预算红线 + vlm/verdict 双脑融合判据） ──
  {
    key: 'policy.budgetStepsLow',
    organ: 'policy',
    defaultValue: 2,
    min: 1,
    max: 5,
    note: '预算升级红线：剩余步数 ≤ 此值 ⇒ escalate 上游（缺省 2）',
  },
  {
    key: 'policy.budgetMsLow',
    organ: 'policy',
    defaultValue: 15000,
    min: 1000,
    max: 60000,
    note: '预算升级红线：剩余毫秒 ≤ 此值 ⇒ escalate 上游（缺省 15000）',
  },
  {
    key: 'verdict.fuseBonus',
    organ: 'verdict',
    defaultValue: 0.1,
    min: 0,
    max: 0.3,
    note: 'fuseWithPixelEvidence 双脑一致判「有效果」的置信加成（缺省 0.1，封顶 1）',
  },
  {
    key: 'verdict.conservativeCap',
    organ: 'verdict',
    defaultValue: 0.6,
    min: 0.3,
    max: 0.9,
    note: 'fuseWithPixelEvidence 分歧/不确定判决的保守置信帽：min(vlmConf, 此值)（缺省 0.6）',
  },

  // ── 验证器官（actionVerifier 轮询/判距/pHash 门 + oscillationTracker 循环谱） ──
  {
    key: 'verify.phashGate',
    organ: 'verify',
    defaultValue: 0.9,
    min: 0.7,
    max: 0.98,
    note: 'pHash 频谱佐证门：前后相似度 < 此值 = 频谱域看到变化（缺省 0.9；双读点同键同步）',
  },
  {
    key: 'verify.stableGap',
    organ: 'verify',
    defaultValue: 1,
    min: 0,
    max: 6,
    note: '稳定帧判距：dhash 汉明距离 ≤ 此值视为同帧（缺省 1；双读点同键同步）',
  },
  {
    key: 'verify.pollMs',
    organ: 'verify',
    defaultValue: 150,
    min: 30,
    max: 1000,
    note: '动作后稳定轮询间隔 ms（缺省 150；消费处 Math.max(1,…) 防 0 忙等）',
  },
  {
    key: 'verify.settleFactor',
    organ: 'verify',
    defaultValue: 4,
    min: 1,
    max: 10,
    note: '自适应等待窗倍率：maxWaitMs = settleMs × 此值（缺省 4；消费处 Math.max(1,…) 防 0 清零）',
  },
  {
    key: 'osc.ringSize',
    organ: 'oscillation',
    defaultValue: 12,
    min: 4,
    max: 64,
    note: '振荡检测观测窗帧数（缺省 12 = 3×maxPeriod 4；结构序守护：消费处 ringSize = Math.max(3*maxPeriod, round(v)) —— 窗容不下 3 份周期块时自抬到结构下限）',
  },
  {
    key: 'osc.maxPeriod',
    organ: 'oscillation',
    defaultValue: 4,
    min: 1,
    max: 6,
    note: '循环谱检测的最大周期 p（缺省 4；探测序 p=1..此值，p=1 语义 = 旧版行为回归）',
  },
  {
    key: 'osc.fuzzTol',
    organ: 'oscillation',
    defaultValue: 6,
    min: 0,
    max: 12,
    note: '循环检测的 dhash 汉明容差位（缺省 6/64 —— 与既视感同律；0 = 精确匹配特例）',
  },

  // ── 记忆器官（skillLibrary 评分 / orchestrator 仲裁 / failureMemory 召回 / contextManager 既视感） ──
  {
    key: 'skill.scoreFloor',
    organ: 'skill',
    defaultValue: 0.15,
    min: 0,
    max: 0.5,
    note: '技能匹配入选地板：综合分 ≤ 此值的候选被滤除（缺省 0.15）',
  },
  {
    key: 'skill.reliabilityWeight',
    organ: 'skill',
    defaultValue: 0.3,
    min: 0,
    max: 1,
    note: '技能评分的贝叶斯可靠度权重（缺省 0.3）',
  },
  {
    key: 'skill.ciDiscount',
    organ: 'skill',
    defaultValue: 0.1,
    min: 0,
    max: 0.3,
    note: '技能评分的 95% CI 半宽折扣（缺省 0.1 —— 只做同均值平票裁决，不做主排序信号）',
  },
  {
    key: 'skill.recencyHalfLifeH',
    organ: 'skill',
    defaultValue: 72,
    min: 1,
    max: 720,
    note: '技能新近度半衰期（小时；缺省 72 —— 三天前的技能贡献减半；消费处 Math.max(1,…) 防除零）',
  },
  {
    key: 'orch.skillReliability',
    organ: 'orchestration',
    defaultValue: 0.5,
    min: 0,
    max: 1,
    note: '子代理技能通道可用性判据的可靠度门（缺省 0.5 —— Laplace 0/0=0.5 不入场）',
  },
  {
    key: 'orch.skillScore',
    organ: 'orchestration',
    defaultValue: 0.45,
    min: 0,
    max: 1,
    note: '子代理技能通道可用性判据的相关度门（缺省 0.45 —— 可靠不等于相关）',
  },
  {
    key: 'orch.emaAlpha',
    organ: 'orchestration',
    defaultValue: 0.15,
    min: 0.01,
    max: 0.9,
    note: '通道 EMA 成功率平滑系数 α（缺省 0.15；消费处夹 [0.01,0.9] —— α=0 冻结学习、α=1 退化成逐次覆写）',
  },
  {
    key: 'failure.score2Floor',
    organ: 'failure',
    defaultValue: 0.2,
    min: 0,
    max: 0.6,
    note: '失败记忆相关性闸门：legacy 加权和 score2 ≤ 此值不召回（缺省 0.2 —— R-6 之前的既有阈值语义）',
  },
  {
    key: 'failure.rrfK',
    organ: 'failure',
    defaultValue: 60,
    min: 10,
    max: 200,
    note: 'RRF 倒数排名融合的平滑常数 k（缺省 60 —— TREC 2003 Cormack 惯例；消费处 round 整数化）',
  },
  {
    key: 'failure.sceneBonus',
    organ: 'failure',
    defaultValue: 0.4,
    min: 0,
    max: 0.8,
    note: '失败记忆的同场景脉冲分值（缺省 0.4 —— 场景指纹通道的 0/此值 二值证据）',
  },
  {
    key: 'ctx.flashbackSim',
    organ: 'context',
    defaultValue: 0.85,
    min: 0.5,
    max: 0.98,
    note: '既视感双指共识门：库存 pHash 与当前帧相似度 ≥ 此值才闪回（缺省 0.85）',
  },

  // ── 治理器官（popupDetector 施密特全套）—— 结构序守护见各 note ──
  {
    key: 'popup.priorWeight',
    organ: 'popup',
    defaultValue: 0.05,
    min: 0.01,
    max: 0.3,
    note: '贝叶斯弹窗信念先验（缺省 0.05 —— 世界大多数时刻没有弹窗；构造/reset 时读）',
  },
  {
    key: 'popup.evidenceGeo',
    organ: 'popup',
    defaultValue: 4.0,
    min: 1,
    max: 6,
    safetyCritical: true,
    note: '几何证据强度（nats；缺省 4.0 —— 单帧几何 ⇒ 后验 ≈0.98 立即 ON）。结构序守护：语义 ≥ 几何是模块立法 —— specs 层 sem 下限 5、消费处再 Math.max(sem, geo) 兜序（geo 可探至 6 越过 sem 下限，越序值就地抬正）。ΝΩ-6 safetyCritical：「单帧几何立即越过 ON 线」是弹窗态机的安全语义前提，阈学习可能把它削到迟滞带内 —— 施密特对等安全语义键，隔离出自动校准池（仅经 gym→显式 promoteFrom 换值）',
  },
  {
    key: 'popup.evidenceSem',
    organ: 'popup',
    defaultValue: 5.0,
    min: 5,
    max: 10,
    safetyCritical: true,
    note: '语义证据强度（nats；缺省 5.0 —— 词表命中是确定性更强的信号）。下限取 5 而非 6：缺省 5.0 必须落在区间内（入册值 = 字面量的零行为铁律优先于区间美学），「geo 上限 < sem 下限」的结构序由消费处 Math.max(sem, geo) 兜底保证。ΝΩ-6 safetyCritical：语义 ≥ 几何的模块立法驻留此键 —— 施密特对等安全语义键，隔离出自动校准池（仅经 gym→显式 promoteFrom 换值）',
  },
  {
    key: 'popup.evidenceClean',
    organ: 'popup',
    defaultValue: -1.5,
    min: -4,
    max: -0.5,
    safetyCritical: true,
    note: '清洁帧证据强度（nats；缺省 −1.5 —— 单帧清洁把 ON 态拉入迟滞带但不放行）。ΝΩ-6 safetyCritical：「清洁不立即放行」是施密特迟滞的回程安全语义（削弱它 ⇒ ON 态被单帧噪声解除）—— 施密特对等安全语义键，隔离出自动校准池（仅经 gym→显式 promoteFrom 换值）',
  },
  {
    key: 'popup.onThreshold',
    organ: 'popup',
    defaultValue: 0.6,
    min: 0.55,
    max: 0.9,
    safetyCritical: true,
    note: '施密特触发 ON 线：belief ≥ 此值进入弹窗态（缺省 0.6）。结构序守护：off 区间上限 0.5 < 本区间下限 0.55（specs 层不交叠），消费处再 Math.min(off, on) 兜序 —— 施密特退化为逐帧抖动是结构崩坏，非旋钮。ΝΩ-6 safetyCritical：施密特触发本体 —— 隔离出自动校准池（仅经 gym→显式 promoteFrom 换值）',
  },
  {
    key: 'popup.offThreshold',
    organ: 'popup',
    defaultValue: 0.35,
    min: 0.1,
    max: 0.5,
    safetyCritical: true,
    note: '施密特触发 OFF 线：belief ≤ 此值退出弹窗态（缺省 0.35）。区间上限 0.5 < onThreshold 区间下限 0.55 —— 迟滞带恒非负宽的结构保证（消费处 Math.min(off, on) 二道兜底）。ΝΩ-6 safetyCritical：施密特触发本体 —— 隔离出自动校准池（仅经 gym→显式 promoteFrom 换值）',
  },
  {
    key: 'popup.geoLow',
    organ: 'popup',
    defaultValue: 0.55,
    min: 0.2,
    max: 0.9,
    note: '几何比之一：中心标准差 < 全图标准差 × 此值（缺省 0.55 —— 更均匀；服务端/legacy 双路径同键同步）',
  },
  {
    key: 'popup.geoHigh',
    organ: 'popup',
    defaultValue: 1.15,
    min: 1.0,
    max: 2.0,
    note: '几何比之二：中心均值 > 全图均值 × 此值（缺省 1.15 —— 更亮；下限 1.0 = 中心不暗于全图的结构语义）',
  },

  // ── 云脑计量器官（vlm/metering 熔断 + quantumSense 去重 + vlm/codec 编码缺省） ──
  {
    key: 'vlm.breakerFailures',
    organ: 'metering',
    defaultValue: 5,
    min: 2,
    max: 20,
    note: 'VlmApiBreaker 熔断阈：连续失败 ≥ 此值 ⇒ open（缺省 5；读点在构造器缺省参 —— set 后新实例生效，显式入参压过注册表）',
  },
  {
    key: 'vlm.breakerCooldownMs',
    organ: 'metering',
    defaultValue: 60000,
    min: 5000,
    max: 600000,
    note: 'VlmApiBreaker 冷却期 ms：期满自动回 closed（缺省 60000；半开语义惰性判定）',
  },
  // ── R5-4（视觉外包经济面）：两枚 0/1 语义缓存开关入册 ──
  // 病灶（R3-3 GAP-1 同款）：消费点一直在（vlm/grounding.ts 读
  // grounding.semanticCache、tools/askScreen.ts 读 ask.semanticCache），但键
  // 从未入册 ⇒ kernelRegistry.set 返回 {ok:false,reason:'unregistered'} 静默
  // 拒收 —— 宿主在 kernel-state.json 根本开不了。入册缺省 0=关（零回归铁律，
  // W5-4⑧「同输入双调必须两次真实进 VLM」契约不受扰），开关权交宿主。
  {
    key: 'grounding.semanticCache',
    organ: 'grounding',
    defaultValue: 0,
    min: 0,
    max: 1,
    note: 'ΝΩ-48 同屏 grounding 语义缓存开关（0/1，缺省 0=关）：同 dhash+同问+同脑 30s 窗内回放缓存（零编码零拨号，命中注记 grounding-cache-hit）；开 = 显式放弃同输入双调的确定性幂等语义',
  },
  {
    key: 'ask.semanticCache',
    organ: 'vlm',
    defaultValue: 0,
    min: 0,
    max: 1,
    note: 'R5-4 ask_screen 同屏同问语义回放开关（0/1，缺省 0=关）：同屏指纹+同问 30s 窗内直接回放答案（零 VLM 拨号，回执 answer_source=semantic-cache-hit）—— 验证类重复问的去重闸',
  },
  {
    key: 'quantum.iou',
    organ: 'quantum',
    defaultValue: 0.5,
    min: 0.3,
    max: 0.8,
    note: '叠加态标注的白盒元素去重 IoU 门（缺省 0.5；或中心点互相包含）',
  },
  {
    key: 'codec.maxDim',
    organ: 'codec',
    defaultValue: 1568,
    min: 512,
    max: 4096,
    note: 'encodeForVlm 缺省长边上限：超过则等比缩小（缺省 1568 —— VLM 最佳分辨率带宽；缺省单点全辖六个调用方）',
  },
  {
    key: 'codec.quality',
    organ: 'codec',
    defaultValue: 80,
    min: 50,
    max: 95,
    note: 'encodeForVlm 缺省 JPEG 质量 1-100（缺省 80 —— UI 文字边缘清晰且体积可控）',
  },
  // ── R3-3（GAP-2 VlmBudget 可调）：任务级视觉配额双键 —— 读点在
  // autonomy/runtime 的 createExecute 构造期（resolveVlmBudget），缺省 =
  // codec.ts DEFAULT_MAX_IMAGES/DEFAULT_MAX_BYTES 字面量锚 ⇒ 入册前后读数
  // 同值（零行为变化律）；set 后新任务生效（每任务铸新闸）。
  {
    key: 'codec.maxImagesPerTask',
    organ: 'codec',
    defaultValue: 200,
    min: 1,
    max: 2000,
    note: 'R3-3（GAP-2）：VlmBudget 每任务图数配额（缺省 200 = codec.DEFAULT_MAX_IMAGES 字面量锚；下限 1 —— 本键是经济闸不是视觉开关，关视觉另有通道）',
  },
  {
    key: 'codec.maxBytesPerTask',
    organ: 'codec',
    defaultValue: 536870912,
    min: 16777216,
    max: 2147483648,
    note: 'R3-3（GAP-2）：VlmBudget 每任务字节配额（缺省 512MB = codec.DEFAULT_MAX_BYTES 字面量锚；区间 16MB-2GB）',
  },

  // ── 宪法器官（Ξ-C 已在 gym 实验室入册接线；生产册此补 specs，读点不动） ──
  {
    key: 'constitution.maxNoEffect',
    organ: 'constitution',
    defaultValue: 3,
    min: 2,
    max: 6,
    safetyCritical: true,
    note: '宪法卡死律阈值：连续无效果步上限（缺省 3；与 gym LAB_CONSTITUTION_KERNEL_SPECS 同键同区间 —— 晋升面就绪）。ΝΩ-6 safetyCritical：宪法律是安全硬顶 —— 隔离出自动校准池，生产换值仅经 gym 实验室进化 → 显式 promoteFrom',
  },
  {
    key: 'constitution.maxSteps',
    organ: 'constitution',
    defaultValue: 40,
    min: 10,
    max: 80,
    safetyCritical: true,
    note: '宪法步数律硬顶：累计步数上限（缺省 40；与 gym 同键同区间）。ΝΩ-6 safetyCritical：宪法律是安全硬顶 —— 隔离出自动校准池，生产换值仅经 gym 实验室进化 → 显式 promoteFrom',
  },
];

/**
 * ΝΩ-6 安全分池的只读视图：PRODUCTION_KERNEL_SPECS 中 safetyCritical === true 的
 * 键集（单一事实源 —— 手写清单会被 specs 演进悄悄甩脱）。KernelCalibrator 缺省
 * 以此为跳过集（可经 CalibratorOptions.safetyCriticalKeys 显式注入覆盖：实验室
 * 恢复进化用空集，属显式行为；生产路径绝不注入）。
 */
export const SAFETY_CRITICAL_KERNEL_KEYS: ReadonlySet<string> = new Set<string>(
  PRODUCTION_KERNEL_SPECS.filter(s => s.safetyCritical === true).map(s => s.key),
);
