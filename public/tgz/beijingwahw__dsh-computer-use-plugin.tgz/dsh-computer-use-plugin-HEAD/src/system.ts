// src/system.ts
// 系统层：所有平台差异与底层 IO 的唯一归宿（防腐层）。
//
// 批次 E 迁移后的接线路由（本轮修复）：
//   默认 → D-5 物理微服务（physicalBackend：截图叠加/指纹/键鼠/感知全在服务端）
//   DSH_FORCE_LEGACY_SYSTEM=1 → 原生依赖懒加载（宿主自行安装 nut-js 等时可用）
//
// 教训（真机执法战果）：批次 E 删除了四个原生依赖却只留下迁移指引错误——
// D-1 工具层（模型实际调用的 20+ 工具）从未接到 D-5，真机安装里
// take_screenshot / click_mouse 100% 抛错。防腐层的意义正是在于：换底层
// 只改本文件，全部工具无感继承。
import type { Config } from './config';
import { serialize } from './ioMutex';
import * as backend from './physicalBackend';
import type { OverlayBox } from './physicalBackend';

export { serialize };

// ─── legacy 路径（DSH_FORCE_LEGACY_SYSTEM=1 时启用）───

const MIGRATION_NOTICE =
  'Legacy native dependency (@nut-tree/nut-js / screenshot-desktop / sharp / tesseract.js) ' +
  'removed in batch E. The default execution path is now the D-5 Python microservice ' +
  '(physicalBackend). If you must use the old D-1 native stack, reinstall the 4 removed ' +
  'packages and set DSH_FORCE_LEGACY_SYSTEM=1 as environment variable.';

function legacyError(dep: string, extraHint?: string): Error {
  const envOk = process.env.DSH_FORCE_LEGACY_SYSTEM === '1';
  if (envOk) {
    return new Error(
      `[system.ts] Lazy import of '${dep}' failed (it's not installed). ` +
      `DSH_FORCE_LEGACY_SYSTEM=1 is set but package is absent. Install it via npm.`,
    );
  }
  return new Error(
    `[system.ts] '${dep}' is removed (batch-E migration). ${MIGRATION_NOTICE}` +
    (extraHint ? ` Hint: ${extraHint}` : ''),
  );
}

function forceLegacy(): boolean {
  return process.env.DSH_FORCE_LEGACY_SYSTEM === '1';
}

interface NutJSApi {
  mouse: any;
  keyboard: any;
  screen: any;
  Button: { LEFT: any; RIGHT: any; MIDDLE: any };
  Key: Record<string, any>;
}

let _nutJS: NutJSApi | null = null;
let _nutJSError: Error | null = null;

async function _getNutJS(): Promise<NutJSApi> {
  if (_nutJS) return _nutJS;
  if (_nutJSError) throw _nutJSError;
  try {
    const mod: any = await import('@nut-tree/nut-js');
    const api: NutJSApi = {
      mouse: mod.mouse,
      keyboard: mod.keyboard,
      screen: mod.screen,
      Button: mod.Button,
      Key: mod.Key,
    };
    if (api.mouse && typeof api.mouse.config !== 'undefined') {
      try { api.mouse.config.FAILSAFE = true; } catch { /* noop */ }
    }
    _nutJS = api;
    return api;
  } catch (e: any) {
    _nutJSError = legacyError('@nut-tree/nut-js',
      'Mouse/keyboard actions now route through D-5 Python microservice by default.');
    _nutJSError.cause = e;
    throw _nutJSError;
  }
}

let _screenshotFn: (() => Promise<Buffer>) | null = null;
let _screenshotError: Error | null = null;

async function _getScreenshotFn(): Promise<() => Promise<Buffer>> {
  if (_screenshotFn) return _screenshotFn;
  if (_screenshotError) throw _screenshotError;
  try {
    const mod = await import('screenshot-desktop');
    const fn = mod.default ?? mod;
    _screenshotFn = () => fn();
    return _screenshotFn;
  } catch (e: any) {
    _screenshotError = legacyError('screenshot-desktop',
      'The default path uses the D-5 service for capture + overlay + hashes.');
    _screenshotError.cause = e;
    throw _screenshotError;
  }
}

async function _getKey(keyName: string): Promise<any> {
  const fallbackMap: Record<string, string> = {
    ctrl: 'LeftControl', cmd: 'LeftSuper', alt: 'LeftAlt', shift: 'LeftShift',
    enter: 'Enter', tab: 'Tab', space: 'Space', backspace: 'Backspace',
    delete: 'Delete', esc: 'Escape',
    // R2-2: 导航/编辑键 + 全字母表（原 a/c/v/z 子集收口）—— 与 pressHotkey 的
    // HOTKEY_WHITELIST_KEYS（no31 漂移防线强制同源）及 python _KEY_MAP 三层收敛。
    // 根因：白名单缺 s ⇒ ctrl+s 被协议层拒绝（R1-8 冒烟遗留①）；字母/导航和弦
    // 属应用内安全面，系统级危险和弦仍由 hotkeyBlacklist 独立执法不受本扩员影响。
    home: 'Home', end: 'End', pageup: 'PageUp', pagedown: 'PageDown',
    up: 'Up', down: 'Down', left: 'Left', right: 'Right',
    f1: 'F1', f2: 'F2', f3: 'F3', f4: 'F4', f5: 'F5',
    f6: 'F6', f7: 'F7', f8: 'F8', f9: 'F9', f10: 'F10',
    f11: 'F11', f12: 'F12',
    a: 'A', b: 'B', c: 'C', d: 'D', e: 'E', f: 'F', g: 'G', h: 'H', i: 'I',
    j: 'J', k: 'K', l: 'L', m: 'M', n: 'N', o: 'O', p: 'P', q: 'Q', r: 'R',
    s: 'S', t: 'T', u: 'U', v: 'V', w: 'W', x: 'X', y: 'Y', z: 'Z',
  };
  const name = keyName.toLowerCase();
  try {
    const nj = await _getNutJS();
    // fallbackMap 的值是 nut-js 枚举成员名（PascalCase）—— 必须经 nj.Key 再索引
    // 取枚举值；直接回传字符串名，pressKey 收到的是非法键（legacy 热键全灭的隐形根因）
    return nj.Key[name] ?? nj.Key[fallbackMap[name]] ?? keyName;
  } catch {
    return fallbackMap[name] ?? keyName;
  }
}

// ─── 显示信息接口（导出保持不变）───

export interface DisplayInfo {
  name: string;
  x: number; y: number;
  width: number; height: number;
}

// ─── 模块级状态（保持原有可变模式 —— 插件单例）───

let dryRun = false;
let windowDelegate: ((keyword: string) => Promise<void | { matched?: string | null }>) | null = null;

// W6-2（doctor smell.over-engineering 清偿）：P1-3 热键黑名单执法面已分区提取至
// system.hotkeyPolicy.ts（行为零变化；nut-js 导入铁律仍只在本文件）；导入面不变 —— 再分发。
import { hotkeyBlacklistHit, HOTKEY_BLACKLIST_MARKER, getHotkeyBlacklistCsv, setHotkeyBlacklistCsv } from './system.hotkeyPolicy';
export { hotkeyBlacklistHit, isHotkeyBlacklistError, HOTKEY_BLACKLIST_MARKER } from './system.hotkeyPolicy';
// R2-3（焦点保卫）：切窗成功 ⇒ 记账目标窗（type_text 前置校验的复焦依据）。
// 纯记账旁路 —— recordTargetWindow 永不抛，缺席时焦点保卫按「无复焦依据」降级。
import { recordTargetWindow } from './windowFocusGuard';



function guardDryRun(action: string, detail: unknown): boolean {
  if (!dryRun) return false;
  console.log(`[dry-run] ${action}`, detail);
  return true;
}

// ─── W6R-A8：openUrl 壳层启动通道的可注入缝（先例：_legacyDeps._resetSharpCache_forTest）───
// 测试注入假 spawn 捕获 (cmd, argv, opts)，断言启动面安全属性：数组形态、
// 无 cmd /c、无手工引号。默认 null = 真实 child_process.spawn；仅供测试，
// 宿主永不触碰。防御式：注入非函数一律按 null（真实通道）处理。
type SpawnLike = (
  cmd: string,
  args: readonly string[],
  opts: { detached: boolean; stdio: 'ignore' },
) => { on(ev: 'error', cb: (e: Error) => void): unknown; unref(): void };
let openUrlSpawnOverride: SpawnLike | null = null;
export function _setOpenUrlSpawnForTest(fn: SpawnLike | null): void {
  openUrlSpawnOverride = typeof fn === 'function' ? fn : null;
}


// ─── ΝΩ-25：switchWindowByTitle 的后端缺席判定（结构化优先）───
// 旧实现用正则匹配错误消息文本（/spawn_failed|ECONNREFUSED/…）—— 消息是给
// 人读的方言，措辞变更即静默改道。physicalBackend 的错误出口（ΝΩ-25）已把
// Result 失败臂的 kind 透传到 error.kind；本层改读结构化通道，消息正则降为
// 最后兜底（仅服务于无 kind 的外来 Error）。
/** 缺席类 kind：后端不在场/已死/起不来 —— 委托通道应接管 */
const ABSENCE_KINDS: ReadonlySet<string> = new Set([
  'window_unavailable',                                                    // 窗口后端缺席（pygetwindow 不可用）
  'transport_error',                                                       // ECONNREFUSED/连接断开 —— 服务已死
  'client_timeout',                                                        // 探活/请求超时
  'spawn_failed', 'startup_timeout', 'crashed', 'port_squatted',           // ensureBackend 启动链失败（serviceManager 方言）
]);
/** 兜底正则：仅无 kind 通道的外来 Error（与旧判定的消息方言一致 —— 零回归） */
const ABSENCE_MSG_FALLBACK = /window_unavailable|spawn_failed|startup_timeout|adapter unavailable|ECONNREFUSED/;

/** 结构化优先的缺席判定：有 kind ⇒ 只认 kind（消息文本不再参与路由） */
function backendAbsence(e: unknown): boolean {
  const kind = (e as { kind?: unknown } | null | undefined)?.kind;
  if (typeof kind === 'string' && kind !== '') return ABSENCE_KINDS.has(kind);
  return ABSENCE_MSG_FALLBACK.test(String((e as { message?: unknown })?.message ?? ''));
}

export const system = {
  /** 应用插件配置；D-5 路径下仅 dryRun 生效（服务端无鼠标速度概念） */
  async configure(config: Config): Promise<void> {
    dryRun = config.dryRun;
    // P1-3：热键黑名单随配置接线（cordis.yml 的 hotkeyBlacklist 直达执法点）
    if (typeof config.hotkeyBlacklist === 'string') setHotkeyBlacklistCsv(config.hotkeyBlacklist);
    if (forceLegacy()) {
      try {
        const nj = await _getNutJS();
        if (nj.mouse?.config?.mouseSpeed != null) {
          nj.mouse.config.mouseSpeed = config.mouseSpeed;
        }
      } catch { /* 无 nut-js：静默跳过，执行时会给出清晰错误 */ }
    }
  },

  /** 屏幕截图（纯净 PNG，无叠加层）—— OCR/记忆预验等下游消费 */
  async captureScreen(): Promise<Buffer> {
    if (forceLegacy()) {
      const fn = await _getScreenshotFn();
      return await fn();
    }
    return backend.captureCleanPng();
  },

  /**
   * 处理截图（D-5 默认路径主入口）：服务端一次往返完成
   * SoM 叠加（网格/准星/元素框）+ 缩放 + JPEG 编码 + 指纹 + 变化门控。
   */
  async captureScreenWithOverlay(opts: backend.CaptureOptions = {}): Promise<backend.ProcessedCapture> {
    return backend.captureProcessed(opts);
  },

  /** 屏幕尺寸 */
  async getScreenSize(): Promise<{ width: number; height: number }> {
    if (forceLegacy()) {
      const nj = await _getNutJS();
      return {
        width: typeof nj.screen.width === 'function' ? await nj.screen.width() : (nj.screen.width as number),
        height: typeof nj.screen.height === 'function' ? await nj.screen.height() : (nj.screen.height as number),
      };
    }
    return backend.getScreenSize();
  },

  async getMousePosition(): Promise<{ x: number; y: number }> {
    if (forceLegacy()) {
      const nj = await _getNutJS();
      return await nj.mouse.getPosition();
    }
    // 像素域（与旧 nut-js 语义一致 —— crosshair/多屏感知的调用方都按像素消费）
    return backend.getCursor();
  },

  async getAllDisplays(): Promise<DisplayInfo[]> {
    if (forceLegacy()) {
      const nj = await _getNutJS();
      const raw = await nj.screen.getAllDisplays();
      return raw.map((d: any) => ({
        name: d.name ?? `Display@${d.x},${d.y}`,
        x: d.x, y: d.y, width: d.width, height: d.height,
      }));
    }
    const displays = await backend.getDisplays();
    return displays.map(d => ({
      name: d.name, x: d.x, y: d.y, width: d.width, height: d.height,
    }));
  },

  async getActiveDisplay(): Promise<DisplayInfo> {
    const [pos, displays] = await Promise.all([this.getMousePosition(), this.getAllDisplays()]);
    // pos 与 displays 均为像素域（与旧 nut-js 语义一致）
    return displays.find(d =>
      pos.x >= d.x && pos.x <= d.x + d.width &&
      pos.y >= d.y && pos.y <= d.y + d.height,
    ) ?? displays[0];
  },

  async clickMouse(x: number, y: number, button: string = 'left'): Promise<void> {
    if (guardDryRun('clickMouse', { x, y, button })) return;
    if (forceLegacy()) {
      const [nj, btn] = await Promise.all([_getNutJS(), _getButton(button)]);
      if (!btn) throw new Error(`Unknown mouse button: ${button}`);
      await serialize(async () => {
        await nj.mouse.move([{ x, y }]);
        await nj.mouse.click(btn);
      });
      return;
    }
    // 像素 → 归一化（D-5 契约域）；越界夹取防微浮点溢出
    const size = await backend.getScreenSize();
    const nx = Math.min(1, Math.max(0, x / size.width));
    const ny = Math.min(1, Math.max(0, y / size.height));
    // D-1 物理躯体公理：动作派发入互斥队列（legacy 路径与 typeText/drag 同律；
    // pressHotkey 例外 —— shaper 的 set_zoom 在 serialize 内复用本管线，嵌套即死锁）
    // ΤΕΛ-5 D-G23：取消端口接线 —— serialize 超时即 abort 底层 D-5 调用
    //（signal → microFetch 断流），挂死调用的恢复通路不再缺席；abort 后的
    // 迟来终局由 ioMutex 吞错镜像吸收，队列串行公理不变。
    const io = new AbortController();
    await serialize(
      () => backend.clickMouse(nx, ny, button as 'left' | 'right' | 'middle', dryRun, undefined, io.signal),
      undefined,
      () => io.abort(),
    );
  },

  /**
   * 移动鼠标（无点击）—— Z-1 交互性探针的悬停动作。
   * 零破坏语义：绝不按下；探针调用方负责 dwell 观察与位置复位。
   */
  async moveMouse(x: number, y: number, durationMs = 0): Promise<void> {
    if (guardDryRun('moveMouse', { x, y })) return;
    if (forceLegacy()) {
      const nj = await _getNutJS();
      await serialize(() => nj.mouse.move([{ x, y }]));
      return;
    }
    const size = await backend.getScreenSize();
    const nx = Math.min(1, Math.max(0, x / size.width));
    const ny = Math.min(1, Math.max(0, y / size.height));
    // ΤΕΛ-5 D-G23：取消端口接线（同 clickMouse 律 —— 超时 abort 底层 D-5 调用）
    const io = new AbortController();
    await serialize(
      () => backend.moveMouse(nx, ny, durationMs, dryRun, io.signal),
      undefined,
      () => io.abort(),
    );
  },

  async typeText(text: string, clearFirst: boolean = false): Promise<void> {
    if (guardDryRun('typeText', { text: text.substring(0, 30), clearFirst })) return;
    if (forceLegacy()) {
      const nj = await _getNutJS();
      const isMac = process.platform === 'darwin';
      const modKey = await _getKey(isMac ? 'cmd' : 'ctrl');
      const keyA = await _getKey('a');
      const keyBack = await _getKey('backspace');
      await serialize(async () => {
        if (clearFirst) {
          await nj.keyboard.pressKey(modKey, keyA);
          await nj.keyboard.releaseKey(modKey, keyA);
          await nj.keyboard.pressKey(keyBack);
          await nj.keyboard.releaseKey(keyBack);
        }
        await nj.keyboard.type(text);
      });
      return;
    }
    // ΤΕΛ-5 D-G23：取消端口接线（同 clickMouse 律 —— 超时 abort 底层 D-5 调用）
    const io = new AbortController();
    await serialize(
      () => backend.typeText(text, clearFirst, dryRun, undefined, io.signal),
      undefined,
      () => io.abort(),
    );
  },

  async dragMouse(start: { x: number; y: number }, end: { x: number; y: number }): Promise<void> {
    if (guardDryRun('dragMouse', { start, end })) return;
    if (forceLegacy()) {
      const [nj, btnLeft] = await Promise.all([_getNutJS(), _getButton('left')]);
      await serialize(async () => {
        await nj.mouse.move([{ x: start.x, y: start.y }]);
        await nj.mouse.pressButton(btnLeft);
        await nj.mouse.move([{ x: end.x, y: end.y }]);
        await nj.mouse.releaseButton(btnLeft);
      });
      return;
    }
    // 像素 → 归一化（D-5 契约域）
    const size = await backend.getScreenSize();
    const clamp01 = (v: number, max: number) => Math.min(1, Math.max(0, v / max));
    // ΤΕΛ-5 D-G23：取消端口接线（同 clickMouse 律 —— 超时 abort 底层 D-5 调用）
    const io = new AbortController();
    await serialize(
      () => backend.dragMouse(
        { x: clamp01(start.x, size.width), y: clamp01(start.y, size.height) },
        { x: clamp01(end.x, size.width), y: clamp01(end.y, size.height) },
        dryRun,
        undefined,
        io.signal,
      ),
      undefined,
      () => io.abort(),
    );
  },

  async scroll(direction: 'up' | 'down' | 'left' | 'right', amount: number): Promise<void> {
    if (guardDryRun('scroll', { direction, amount })) return;
    if (forceLegacy()) {
      const nj = await _getNutJS();
      await serialize(async () => {
        switch (direction) {
          case 'up': await nj.mouse.scrollUp(amount); break;
          case 'down': await nj.mouse.scrollDown(amount); break;
          case 'left': await nj.mouse.scrollLeft(amount); break;
          case 'right': await nj.mouse.scrollRight(amount); break;
        }
      });
      return;
    }
    // ΤΕΛ-5 D-G23：取消端口接线（同 clickMouse 律 —— 超时 abort 底层 D-5 调用）
    const io = new AbortController();
    await serialize(
      () => backend.scrollPage(direction, amount, dryRun, undefined, io.signal),
      undefined,
      () => io.abort(),
    );
  },

  async pressHotkey(keys: string[]): Promise<void> {
    // P1-3：dryRun 照旧只记录（不执行 = 无拦截必要；提示词调试要能看到完整热键轨迹）
    if (guardDryRun('pressHotkey', { keys })) return;
    // P1-3：系统级热键黑名单执法 —— 归一和弦命中条目 / 含黑名单单键 ⇒ 拒绝。
    // 在 legacy 与 D-5 两条路径之前拦截（逃逸动作哪条躯体都不许碰）
    const hit = hotkeyBlacklistHit(keys, getHotkeyBlacklistCsv());
    if (hit !== null) {
      throw new Error(
        `${HOTKEY_BLACKLIST_MARKER} 系统级热键被黑名单拦截: chord "${keys.join('+')}" ` +
        `hits blacklist entry "${hit}" — system-level hotkeys (window close / OS shell) are ` +
        `rejected outright; use regular channels (click UI controls / switch_window / open_url)`,
      );
    }
    if (forceLegacy()) {
      const [nj, ...mapped] = await Promise.all([
        _getNutJS(),
        ...keys.map(k => _getKey(k)),
      ]);
      if (mapped.some(m => m == null)) {
        throw new Error(`Unrecognized key names in combination: [${keys.join(', ')}]`);
      }
      await serialize(async () => {
        await nj.keyboard.pressKey(...mapped);
        await nj.keyboard.releaseKey(...mapped);
      });
      return;
    }
    await backend.pressHotkey(keys, dryRun);
  },

  setWindowDelegate(fn: ((keyword: string) => Promise<void | { matched?: string | null }>) | null): void {
    windowDelegate = fn;
  },

  async switchWindowByTitle(keyword: string): Promise<{ method: string; matched: string | null }> {
    // Y6 通道仲裁修正：原生 python 后端优先，D-2 委托降为后备。
    // 旧实现委托一经注入即独占 —— 而 raise_window 委托（PowerShell）无标题
    // 回执（focus_handoff 取证因此永远缺席）、无本地化别名、失败时不给可用
    // 窗口清单。原生路径（pygetwindow）三样俱全。委托保留给"无 python 后端"
    // 的环境 —— 那才是 D-2 设计它的场景。
    // ΝΩ-25：缺席判定改 error.kind 优先（backendAbsence），消息正则仅兜底。
    // R2-3：切换成功且带回执 ⇒ 记账目标窗（宿主自抬抢焦后 type_text 前置
    // 校验的复焦依据；纯旁路，失败零影响）。
    if (!forceLegacy()) {
      try {
        const r = await backend.switchWindow(keyword);
        if (r.method !== 'hotkey_only') {
          if (r.matched) recordTargetWindow({ keyword, matchedTitle: r.matched });
          return { method: r.method, matched: r.matched ?? null };
        }
      } catch (e: any) {
        // 后端缺席（无 python 服务/窗口后端不可用）→ 委托接管；
        // element_not_found 是真实未命中 → 如实上抛（错误里带可用窗口清单）。
        if (!backendAbsence(e)) throw e;
      }
    }
    if (windowDelegate) {
      const r = await windowDelegate(keyword);
      // 委托方言无标题回执时 matched=null —— 取证降级到工具层 OCR 路径
      const matched = r?.matched ?? null;
      if (matched) recordTargetWindow({ keyword, matchedTitle: matched });
      return { method: 'delegate', matched };
    }
    if (forceLegacy()) {
      throw new Error(
        'Window management is not available in this environment. ' +
        'Install a window-management provider, or switch windows via the press_hotkey tool.',
      );
    }
    throw new Error('native window switch unavailable; use press_hotkey alt+tab');
  },

  /**
   * R2-3（焦点保卫）：前台窗口标题只读探测 —— type_text 前置焦点校验的数据源。
   * 绝不抛：通道缺席（无 python 后端 / 窗口后端不可用 / legacy 路径无此能力）
   * ⇒ null（调用方按「不可校验」诚实降级）。空标题（桌面焦点）亦归一为 null。
   */
  async getForegroundWindowTitle(): Promise<string | null> {
    if (forceLegacy()) return null; // legacy 栈无窗口读取面 —— 诚实缺席
    try {
      const r = await backend.getActiveWindow();
      const t = typeof r?.title === 'string' ? r.title.trim() : '';
      return t !== '' ? t : null;
    } catch {
      return null;
    }
  },

  /**
   * 用操作系统默认浏览器打开 URL（AA-1 世界跳转引擎的躯体）。
   *
   * 壳层动作，非屏幕交互 —— 不经 D-5 物理微服务（那里是键鼠/截图的躯体），
   * 直接调用平台 opener：win=rundll32 FileProtocolHandler / darwin=open / linux=xdg-open。
   * 调用方（open_url 工具）负责 URL 安检（scheme 白名单）；本层只管
   * 忠实把已安检的 URL 交给壳层并报告启动方式。fire-and-forget：浏览器
   * 的启动成败由世界回击（take_screenshot / switch_window）验证，本层
   * 不伪造「已打开」。
   */
  async openUrl(url: string): Promise<{ method: string }> {
    if (guardDryRun('openUrl', { url })) return { method: 'dry-run' };
    const { spawn } = await import('child_process');
    // fire-and-forget 的另一半：spawn 失败（ENOENT/EACCES，如缺失 xdg-open）经
    // 异步 'error' 事件到达 —— 无监听即 uncaught exception 炸宿主进程。启动成败
    // 本就由世界回击验证（见 JSDoc），此处只封崩溃面
    if (process.platform === 'win32') {
      // W6R-A8 shell 启动面加固：弃 cmd.exe /c start。cmd 解析层会展开
      // %VAR% 环境变量、把 & | > , 当命令语法 —— 旧实现的手工引号只包住
      // 外层，URL 内部字符仍身处一个 shell 解释器。改走
      // rundll32 url.dll,FileProtocolHandler：不经 shell 解析、不做变量
      // 展开，URL 作为独立 argv 数组元素原样直达（spawn 数组形态 = 无
      // 字符串拼接、无手工引号、无 windowsVerbatimArguments）。
      // FileProtocolHandler 与 start 同落 ShellExecute 的默认协议处理器
      // —— 功能等价，解释层更少。
      const launch = openUrlSpawnOverride ?? (spawn as unknown as SpawnLike);
      const child = launch('rundll32.exe', ['url.dll,FileProtocolHandler', url], {
        detached: true, stdio: 'ignore',
      });
      child.on('error', () => {
        // rundll32 不可用（ENOENT/EACCES）⇒ 回退 explorer.exe <url>：
        // 同样数组参数、同样不经 shell —— 回退通道不得比主通道更宽。
        // 回退成败仍由世界回击验证（fire-and-forget 契约不变），此处只封崩溃面。
        try {
          const fb = launch('explorer.exe', [url], { detached: true, stdio: 'ignore' });
          fb.on('error', () => {});
          fb.unref();
        } catch { /* 永不因回退失败炸宿主（防御式吞异常） */ }
      });
      child.unref();
      return { method: 'rundll32:FileProtocolHandler' };
    }
    if (process.platform === 'darwin') {
      const child = spawn('open', [url], { detached: true, stdio: 'ignore' });
      child.on('error', () => {});
      child.unref();
      return { method: 'open' };
    }
    const child = spawn('xdg-open', [url], { detached: true, stdio: 'ignore' });
    child.on('error', () => {});
    child.unref();
    return { method: 'xdg-open' };
  },
};

async function _getButton(button: string): Promise<any> {
  const fallbackMap: Record<string, string> = {
    left: 'LEFT', right: 'RIGHT', middle: 'MIDDLE',
  };
  try {
    const nj = await _getNutJS();
    // 同 _getKey：fallbackMap 的值须再经 nj.Button 索引取枚举值，不能回传字符串名
    return nj.Button[button as 'LEFT' | 'RIGHT' | 'MIDDLE'] ?? nj.Button[fallbackMap[button] as 'LEFT' | 'RIGHT' | 'MIDDLE'] ?? fallbackMap[button];
  } catch {
    return fallbackMap[button] ?? button;
  }
}

export type { OverlayBox };
