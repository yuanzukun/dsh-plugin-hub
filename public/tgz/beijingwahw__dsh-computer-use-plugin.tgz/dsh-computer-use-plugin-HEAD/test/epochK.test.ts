// test/epochK.test.ts
// K 纪元（留白兑现）：代码诚实声明的留白 —— 逐一落成并锁死。
// 虚拟屏模拟器 / WindowsAdapter / Actor 双通道 / 贝叶斯会诊 / SSD / 同形字 / 可播种 RNG。
import { test, beforeEach, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'fs';
import { stopBackend } from '../src/physicalBackend.ts';

import { VirtualScreen } from '../src/sandbox/virtualScreen.ts';
import { SandboxEngineImpl } from '../src/sandbox/engine.ts';
import { sandboxLog } from '../src/sandbox/log.ts';
import { WindowsAdapter, NullAdapter } from '../src/environmentShaper.ts';
import { shaper } from '../src/environmentShaper.ts';
import { createActor } from '../src/orchestrator.ts';
import { bayesianBelief } from '../src/diagnosis.ts';
import { Telemetry } from '../src/telemetry.ts';
import { matchesRiskPatterns } from '../src/riskGate.ts';
import { journal } from '../src/journal.ts';
import { swarm } from '../src/swarm.ts';
import { makeScore } from '../src/doctorEvents.ts';
import { DOCTOR_RULES } from '../src/doctorRules.ts';
import type { ScanContext } from '../src/qualityDoctor.ts';
import type { VirtualWidget } from '../src/sandbox/types.ts';

const BTN: VirtualWidget = { role: 'button', name: 'save', rect: { x: 0.1, y: 0.1, width: 0.2, height: 0.1 } };
const INPUT: VirtualWidget = { role: 'textbox', name: 'search', rect: { x: 0.5, y: 0.5, width: 0.3, height: 0.08 }, acceptsText: true };
const SCENE: VirtualWidget[] = [BTN, INPUT];

function engine(): { eng: SandboxEngineImpl; cleanup: () => void } {
  const eng = new SandboxEngineImpl(null);
  eng.configure({});
  return { eng, cleanup: () => { eng.reset(); } };
}

beforeEach(() => { sandboxLog.reset(); });

// Actor/验证链会懒拉起 D-5 物理服务（本地有 python 即真实 spawn）。测试进程无
// 卸载钩子 —— 不关停则子进程占住事件循环，node --test 永不退出（CI 上 python
// 缺席时快速失败不触发，故只在开发者本机显形）
after(async () => {
  await stopBackend();
});

// ─── K-1 虚拟屏模拟器：排练验证层的第一块真证据 ───

test('K-1a: 命中点击 + element-level 期望 ⇒ passed（D-5 首次真实可达）', async () => {
  const { eng, cleanup } = engine();
  const out = await eng.rehearse({
    id: 'chain-k1a', origin: 'manual',
    entrySceneFingerprint: 'ab'.repeat(32),
    virtualScene: SCENE,
    actions: [{ kind: 'click_mouse', args: { x: 0.15, y: 0.12 }, expect: { scale: 'element-level' } }],
  });
  assert.equal(out.verdict, 'passed', '证据在场且无反证 —— passed 不再是不可达态');
  assert.equal(out.verificationLayers.length, 2, 'L1-pixel + L4-expectation 两层生效');
  assert.equal(out.score, makeScore(50), '两层 / 四层 = 50 分');
  assert.equal(out.entrySceneFingerprint, 'ab'.repeat(32), '固化入口指纹随行');
  assert.equal(out.steps[0].effectDetected, true);
  assert.equal(out.steps[0].expectationMet, true);
  cleanup();
});

test('K-1b: 落空点击 ⇒ failed + failedAtIndex（世界回击进入排练）', async () => {
  const { eng, cleanup } = engine();
  const out = await eng.rehearse({
    id: 'chain-k1b', origin: 'manual', virtualScene: SCENE,
    actions: [{ kind: 'click_mouse', args: { x: 0.9, y: 0.9 } }],
  });
  assert.equal(out.verdict, 'failed');
  assert.equal(out.failedAtIndex, 0);
  assert.equal(out.steps[0].effectDetected, false, '命中测试 = L1 反证');
  cleanup();
});

test('K-1c: 无场景 ⇒ degraded 零回归（诚实缺席语义不变）', async () => {
  const { eng, cleanup } = engine();
  const out = await eng.rehearse({
    id: 'chain-k1c', origin: 'manual',
    actions: [{ kind: 'click_mouse', args: { x: 0.15, y: 0.12 }, expect: { scale: 'element-level' } }],
  });
  assert.equal(out.verdict, 'degraded');
  assert.equal(out.steps[0].effectDetected, null);
  cleanup();
});

test('K-1d: 点击聚焦输入框 + type + text-level 期望 ⇒ 文字核验通过；错文本 ⇒ 反证', async () => {
  const { eng, cleanup } = engine();
  const ok = await eng.rehearse({
    id: 'chain-k1d-ok', origin: 'manual', virtualScene: SCENE,
    actions: [
      { kind: 'click_mouse', args: { x: 0.6, y: 0.54 } },
      { kind: 'type_text', args: { text: 'hello world' }, expect: { scale: 'text-level', expectedText: 'hello' } },
    ],
  });
  assert.equal(ok.verdict, 'passed');
  assert.equal(ok.steps[1].expectationMet, true);

  const bad = await eng.rehearse({
    id: 'chain-k1d-bad', origin: 'manual', virtualScene: SCENE,
    actions: [
      { kind: 'click_mouse', args: { x: 0.6, y: 0.54 } },
      { kind: 'type_text', args: { text: 'hello' }, expect: { scale: 'text-level', expectedText: 'goodbye' } },
    ],
  });
  assert.equal(bad.verdict, 'failed', '预期文本未上屏 = L4 反证');
  cleanup();
});

test('K-1e: 固化端到端 —— passed × 医生 approved ⇒ 肌肉记忆首次真实入库', async () => {
  const { eng, cleanup } = engine();
  const out = await eng.rehearse({
    id: 'chain-k1e', origin: 'manual',
    entrySceneFingerprint: 'cd'.repeat(32),
    virtualScene: SCENE,
    actions: [{ kind: 'click_mouse', args: { x: 0.15, y: 0.12 }, expect: { scale: 'element-level' } }],
  });
  assert.equal(out.verdict, 'passed');
  const r = eng.tryConsolidate({
    subject: 'chain-k1e', chainTip: out.chainTip, verdict: 'approved',
    score: makeScore(100)!, rationale: 'clean',
  });
  assert.equal(r.ok, true);
  assert.ok(r.value, '双闸门放行 —— 固化不再是永恒 freeze');
  const recall = eng.recallMuscleMemory('save button');
  assert.ok(recall.ok && recall.value.length >= 1, '入库即可召回');
  cleanup();
});

test('K-1f: VirtualScreen 纯语义 —— page-level 期望诚实 null；畸形控件拒收', () => {
  const vs = new VirtualScreen([{ role: 'x', name: 'y', rect: { x: NaN, y: 0, width: 1, height: 1 } }]);
  assert.ok(vs.isEmpty, 'NaN rect ⇒ 拒收（诚实缺席优于毒化命中测试）');
  const vs2 = new VirtualScreen([BTN]);
  const ev = vs2.applyAction({ kind: 'click_mouse', args: { x: 0.15, y: 0.12 }, expect: { scale: 'page-level' } });
  assert.equal(ev.effectDetected, true);
  assert.equal(ev.expectationMet, null, '无导航模型 —— page-level 不可判（诚实 null）');
});

// ─── K-2 WindowsAdapter：预留槽落成（注入纪律）───

/**
 * W6R-A8：假 exec 扮演 powershell 的解码半边 —— -EncodedCommand 载荷
 * （UTF-16LE base64）解码回脚本原文，后续断言照旧面向脚本语义。
 */
function decodePsArgs(args: string[]): string {
  const last = String(args[args.length - 1] ?? '');
  return args.includes('-EncodedCommand')
    ? Buffer.from(last, 'base64').toString('utf16le')
    : last;
}

function fakePS(hooks?: { onCmd?: (args: string[]) => void; geo?: string }) {
  const calls: string[] = []; // 每次调用的解码后 PS 脚本（W6R-A8：EncodedCommand 通道）
  return {
    calls,
    adapter: new WindowsAdapter({
      probe: () => true,
      exec: async (_cmd, args) => {
        const script = decodePsArgs(args);
        calls.push(script);
        hooks?.onCmd?.(args);
        if (script.includes('MainWindowHandle')) return { stdout: '4242\n' };
        if (script.includes('GetWindowRect')) return { stdout: hooks?.geo ?? '10,20,800,600,0\n' };
        return { stdout: 'True\n' };
      },
    }),
  };
}

test('K-2a: 能力探测 —— PowerShell 在场 ⇒ 窗口四动作 + launch_app；set_contrast 官方 API 在场', async () => {
  const { adapter } = fakePS();
  const caps = await adapter.capabilities();
  // R2-5：launch_app 无条件在场（Node 内建 spawn 直启，零 PS 依赖 —— 沙箱预置
  // GUI 应用窗口的唯一可靠通道）；其余五 kind 语义零回归
  assert.deepEqual([...caps].sort(), ['launch_app', 'maximize_window', 'move_window', 'raise_window', 'set_contrast', 'set_zoom']);
});

test('K-2b: raise_window 发出 PS 命令且标题注入面闭合（单引号加倍）', async () => {
  const { adapter, calls } = fakePS();
  await adapter.apply({ kind: 'raise_window', titleHint: "O'Brien" });
  const script = calls.join(' ');
  assert.ok(script.includes(`'*' + 'O''Brien' + '*'`), 'PS 字面量转义闭合注入面');
  assert.ok(script.includes('SetForegroundWindow'), 'P/Invoke 置前');
});

test('K-2c: move_window 捕获几何快照；undo 按 SetWindowPos 精确归位', async () => {
  const { adapter, calls } = fakePS();
  const recipe = await adapter.apply({ kind: 'move_window', titleHint: 'app', x: 100, y: 200 });
  assert.deepEqual(recipe.before, { x: 10, y: 20, width: 800, height: 600, maximized: false });
  await adapter.undo(recipe);
  const all = calls.join(' ');
  assert.ok(all.includes('SetWindowPos'), 'undo 走 P/Invoke 归位');
});

test('K-2d: genesis 规则演化 —— 真实源码零违规；裸调用形态仍被拦截', async () => {
  const self = readFileSync(new URL('../src/environmentShaper.ts', import.meta.url), 'utf8');
  const ctx = (sources: Array<{ path: string; content: string }>): ScanContext => ({
    sources, chain: { entries: [], chainIntact: true }, snapshot: null,
    config: {} as never, warn: () => {},
  });
  // 真实实现（注入式）⇒ 零发现
  const real = await DOCTOR_RULES.find(r => r.id === 'genesis.premature-impl')!
    .scan(ctx([{ path: 'environmentShaper.ts', content: self }]));
  assert.equal(real.length, 0, '注入式实现合法');
  // 裸调用形态（无 this.execFn）⇒ 仍违规
  const rogue = 'class WindowsAdapter {\n  go() { execFile("powershell", []); }\n}\nexport class NullAdapter {}\n';
  const bad = await DOCTOR_RULES.find(r => r.id === 'genesis.premature-impl')!
    .scan(ctx([{ path: 'environmentShaper.ts', content: rogue }]));
  assert.equal(bad.length, 1, '不可测接线仍被守卫拦截');
});

test('K-2e: shaper 测试注入面 —— NullAdapter 锁死空能力路径', async () => {
  shaper.setAdapterForTest(new NullAdapter());
  assert.equal(shaper.capabilities().size, 0);
  const r = await shaper.apply({ kind: 'raise_window', titleHint: 'X' });
  assert.equal(r.ok, false);
  assert.ok(r.reason!.includes('capabilities'));
});

// ─── K-3 Actor 双通道 ───

test('K-3a: agents 服务优先 —— run 通道直通 + 故障诚实 FAILED', async () => {
  const actor = createActor({ getAgentsRun: () => async (t, sys) => `[SUCCESS] agents:${t}:${sys.length > 0}` });
  assert.match(await actor('open settings'), /\[SUCCESS\] agents:open settings:true/);
  const failing = createActor({ getAgentsRun: () => { throw new Error('boom'); } });
  assert.match(await failing('x'), /\[FAILED\] agents service fault: boom/);
});

test('K-3b: 技能重放回退 —— 可靠匹配逐步重放并回写可靠度', async () => {
  const outcomes: Array<[number, boolean]> = [];
  const actor = createActor({
    matchSkill: () => [{ id: 7, reliability: 0.75, steps: [{ tool: 'click_mouse', args: { x: 0.1, y: 0.1 } }] }],
    replayStep: async () => '{"status": "SUCCESS"}',
    recordOutcome: (id, ok) => outcomes.push([id, ok]),
  });
  assert.match(await actor('click save'), /\[SUCCESS\] replayed skill 7/);
  assert.deepEqual(outcomes, [[7, true]]);
});

test('K-3c: 不可靠技能（Laplace 0/0 = 0.5）不入场；双缺席诚实 FAILED', async () => {
  const actor = createActor({
    matchSkill: () => [{ id: 1, reliability: 0.5, steps: [{ tool: 'noop', args: {} }] }],
    replayStep: async () => 'ok',
  });
  assert.match(await actor('x'), /\[FAILED\] no actors channel/);
  const none = createActor({});
  assert.match(await none('x'), /\[FAILED\] no actors channel/);
});

// ─── K-4 贝叶斯会诊 ───

test('K-4: 后验侧写 —— 单信号归因 / 全缺席诚实 null / 归一性', () => {
  const onlyNoop = bayesianBelief({ shifted: null, hurstHigh: null, loop: null, heavyTail: null, highNoop: true });
  assert.ok(onlyNoop);
  assert.equal(onlyNoop[0].syndrome, 'blind-clicking', '唯一 noop 证据 ⇒ blind-clicking 主导');
  const sum = onlyNoop.reduce((a, b) => a + b.posterior, 0);
  assert.ok(Math.abs(sum - 1) < 0.01, `后验和 = 1（枚举精确归一），实际 ${sum}`);
  const combined = bayesianBelief({ shifted: true, hurstHigh: true, loop: null, heavyTail: null, highNoop: false });
  assert.equal(combined![0].syndrome, 'shift-and-cluster', 'shift×hurst 组合 ⇒ 双重恶性主导');
  assert.equal(bayesianBelief({ shifted: null, hurstHigh: null, loop: null, heavyTail: null, highNoop: null }), null);
  assert.equal(bayesianBelief({ shifted: false, hurstHigh: false, loop: false, heavyTail: false, highNoop: false }), null, '全阴 = 健康（诚实的缺席）');
});

// ─── K-5 SSD + 可播种 RNG ───

test('K-5: SSD 裁决 FSD 交叉分布；seededUniform 确定性', () => {
  assert.equal(Telemetry.firstOrderStochasticDominance([10, 50], [20, 30]), 'none', 'FSD 交叉（I-6 既知）');
  assert.equal(Telemetry.secondOrderStochasticDominance([10, 50], [20, 30]), 'B', 'SSD：一致者(B)占优 —— 部分序留白兑现');
  assert.equal(Telemetry.secondOrderStochasticDominance([1, 2], [10, 20]), 'A', 'FSD ⊂ SSD：全序占优保持');
  const rng1 = Telemetry.seededUniform(42), rng2 = Telemetry.seededUniform(42);
  const s1 = Array.from({ length: 8 }, rng1), s2 = Array.from({ length: 8 }, rng2);
  assert.deepEqual(s1, s2, '同种子同序列（MC p 值可复现）');
});

// ─── K-6 同形字归一 ───

test('K-6: 西里尔/全角同形字命中风险词；正常文本零误伤', () => {
  const RISK = 'password,发送';
  // 西里尔 а + leet 0（三重混淆叠加）
  const cyr = 'p\u0430ssw0rd';
  assert.ok(matchesRiskPatterns(cyr, RISK), `西里尔同形 + leet 双层混淆命中（${cyr}）`);
  // 全角 ｐ
  assert.ok(matchesRiskPatterns('\uff41assword', RISK) === false || matchesRiskPatterns('\uff50assword', RISK), '全角映射生效');
  assert.ok(matchesRiskPatterns('\uff50assword', RISK), '全角 ｐ → p 命中');
  // 正常中文（归一化不误伤 —— E-6 控制组语义保持）
  assert.ok(matchesRiskPatterns('点击发送按钮', RISK), '正常路径零回归');
  assert.ok(!matchesRiskPatterns('view report', RISK));
});

// ─── K 纪元补全：虚拟屏 scroll / hotkey 证据（最后一个架构留白落成）───

test('K-7a: 可滚动容器 ⇒ scroll 产出 L1 证据；无容器 ⇒ 诚实反证', async () => {
  const LIST: VirtualWidget = { role: 'list', name: 'records', rect: { x: 0.1, y: 0.3, width: 0.8, height: 0.5 }, scrollable: true };
  const { eng, cleanup } = engine();
  const ok = await eng.rehearse({
    id: 'chain-k7a-ok', origin: 'manual',
    virtualScene: [LIST],
    actions: [{ kind: 'scroll_page', args: { direction: 'down', amount: 3 } }],
  });
  assert.equal(ok.verdict, 'passed');
  assert.equal(ok.steps[0]!.effectDetected, true);
  const st = ok.steps[0];
  assert.ok(st && (st.note ?? '').includes('offset 3'), `偏移记账入注：${st?.note}`);
  const none = await eng.rehearse({
    id: 'chain-k7a-none', origin: 'manual',
    virtualScene: [BTN], // 无可滚动容器
    actions: [{ kind: 'scroll_page', args: { direction: 'down', amount: 3 } }],
  });
  assert.equal(none.verdict, 'failed');
  assert.equal(none.steps[0].effectDetected, false, '无处可滚 = 世界回击');
  cleanup();
});

test('K-7b: esc 关闭弹窗 ⇒ L1 证据；无弹窗 ⇒ 诚实反证；其他热键缺席', async () => {
  const POPUP: VirtualWidget = { role: 'dialog', name: 'confirm', rect: { x: 0.3, y: 0.3, width: 0.4, height: 0.3 }, popup: true };
  const { eng, cleanup } = engine();
  const ok = await eng.rehearse({
    id: 'chain-k7b-ok', origin: 'manual',
    virtualScene: [BTN, POPUP],
    actions: [{ kind: 'press_hotkey', args: { keys: ['esc'] } }],
  });
  assert.equal(ok.verdict, 'passed');
  const st = ok.steps[0];
  assert.ok(st !== undefined && (st.note ?? '').includes('dismissed popup confirm'));
  const none = await eng.rehearse({
    id: 'chain-k7b-none', origin: 'manual',
    virtualScene: [BTN],
    actions: [{ kind: 'press_hotkey', args: { keys: ['esc'] } }],
  });
  assert.equal(none.verdict, 'failed', '无弹窗可关 = esc 无效果');
  const other = await eng.rehearse({
    id: 'chain-k7b-other', origin: 'manual',
    virtualScene: [BTN, POPUP],
    actions: [{ kind: 'press_hotkey', args: { keys: ['ctrl', 'w'] } }],
  });
  assert.equal(other.verdict, 'degraded', '非 esc 热键：无键盘状态模型 ⇒ 诚实缺席（非反证）');
  cleanup();
});

// ─── L 纪元：服务归属决策 + 契约占位激活 + TODO 兑现 ───

test('L-1: 属主插件自荐注册 —— 宿主有 set ⇒ 上总线；无 set ⇒ 降级不变', async () => {
  const { toSandboxDoctorView } = await import('../src/doctorChannel.ts');
  const doc = { reportPath: () => '/tmp/r.json', memory: () => ({ totalDiagnoses: 3, lastReport: { score: 85 } }) };
  const view = toSandboxDoctorView(doc);
  assert.equal(view.reportPath(), '/tmp/r.json');
  assert.equal(view.memory().totalDiagnoses, 3);
  // SandboxDoctorView 编译期执法：门面形状即契约（错误形状 = 编译错误）
  const _typeEnforce: import('../src/sandbox/types.ts').SandboxDoctorView = view;
  void _typeEnforce;
});

test('L-2: hasVerificationLayer 活引用 —— 四层在场性判据可判', async () => {
  const { hasVerificationLayer } = await import('../src/sandbox/index.ts');
  const { SandboxEngineImpl } = await import('../src/sandbox/engine.ts');
  const eng = new SandboxEngineImpl(null); eng.configure({});
  const out = await eng.rehearse({
    id: 'chain-l2', origin: 'manual', virtualScene: SCENE,
    actions: [{ kind: 'click_mouse', args: { x: 0.15, y: 0.12 }, expect: { scale: 'element-level' } }],
  });
  assert.equal(hasVerificationLayer(out, 'L1-pixel'), true);
  assert.equal(hasVerificationLayer(out, 'L4-expectation'), true);
  assert.equal(hasVerificationLayer(out, 'L2-diff'), false);
  eng.reset();
});

test('L-3: idGen 接线位兑现 —— intent 铸造走 IdGenerator（防撞三重奏）', async () => {
  const { createDefaultIdGenerator } = await import('../src/sandbox/types.ts');
  const gen = createDefaultIdGenerator();
  const a = gen.next('intent'), b = gen.next('intent');
  assert.notEqual(a, b, '连续铸造不撞号');
  assert.match(a, /^intent-/, "kind='intent' 预留兑现（types 立法）");
  // run_pipeline 工具面同律（编译期：orchestration/index 已改用 intentIdGen）
  const src = readFileSync(new URL('../src/orchestration/index.ts', import.meta.url), 'utf8');
  assert.ok(src.includes("intentIdGen.next('intent')"), '工具铸造接线在位');
});

test('L-4: auditGuard TODO 兑现 —— 审计行携带风险语境（消费 J 纪元体系）', async () => {
  const src = readFileSync(new URL('../src/guards/auditGuard.ts', import.meta.url), 'utf8');
  assert.ok(!src.includes('TODO: 接入 DSH Approval'), 'TODO 已兑现移除');
  assert.ok(src.includes('matchesRiskPatterns'), '审计消费风险闸门语境');
  // 行为验证：风险词文本命中
  const { matchesRiskPatterns } = await import('../src/riskGate.ts');
  assert.ok(matchesRiskPatterns('my password is 123', 'password'));
  assert.ok(!matchesRiskPatterns('hello world', 'password'));
});

test('L-5: 服务自荐注册 —— sandbox/knowledge 插件向宿主总线上线', async () => {
  // 编译期：两插件源码含 set?. 自荐注册（宿主裁决架构决策成文）
  // ΠΑΝ-39：D-5 装配面收口至 sandbox/apply.ts（applySandboxStack 单一装配函数），
  // 自荐注册代码随之移驻 —— 断言面对齐新装配文件（index.ts 壳化为一行挂线）。
  const sbx = readFileSync(new URL('../src/sandbox/apply.ts', import.meta.url), 'utf8');
  const knw = readFileSync(new URL('../src/knowledge/index.ts', import.meta.url), 'utf8');
  assert.ok(sbx.includes("set?.('dsh.sandbox'"), 'D-5 自荐注册 dsh.sandbox');
  assert.ok(knw.includes("set?.('dsh.knowledge-pipeline'"), 'D-7 自荐注册 dsh.knowledge-pipeline');
  // 行为验证：假宿主接受注册（on/effect 旁路 stub —— apply 只走到注册即验证）
  const registered = new Map<string, unknown>();
  const calls: string[] = [];
  const fakeCtx = {
    set: (n: string, v: unknown) => registered.set(n, v),
    on: (ev: string) => { calls.push(ev); },
    get: (_n: string) => undefined, // 服务探测：全部缺席（诚实降级路径）
    effect: () => { /* 生命周期登记 no-op */ },
    tools: { register: () => { calls.push('tool'); } },
  };
  const { name, apply } = await import('../src/sandbox/index.ts');
  assert.equal(name, 'sandbox-execution-plugin');
  await apply(fakeCtx as never, {});
  assert.ok(registered.has('dsh.sandbox'), '假宿主总线上线成功');
});

// ─── M 纪元：五项"值即边界"兑现的执法 ───

test('M-1: set_contrast 落成 —— SPI 官方 API + undo 还原 flags', async () => {
  const { WindowsAdapter } = await import('../src/environmentShaper.ts');
  const caps = await new WindowsAdapter({ probe: () => true, exec: async () => ({ stdout: '0' }) }).capabilities();
  assert.ok(caps.has('set_contrast'), '能力申报（L 纪元落成）');
  const scripts: string[] = [];
  const a = new WindowsAdapter({ probe: () => true, exec: async (_c, args) => {
    // W6R-A8：-EncodedCommand 载荷解码回脚本原文（假 exec 扮演 powershell 解码半边）
    const last = String(args[args.length - 1]);
    scripts.push(args.includes('-EncodedCommand') ? Buffer.from(last, 'base64').toString('utf16le') : last);
    return { stdout: '4\n' }; // GET 返回 flags=4（HCF_ON 位清除 —— 翻转可观测）
  } });
  const recipe = await a.apply({ kind: 'set_contrast' });
  assert.equal(recipe.before?.theme, '4', 'undo 快照 = apply 前原 flags');
  // HC_DECL 声明同时含 GetHC/SetHC 定义 ⇒ 用调用点判：`::GetHC()` 与 `::SetHC(7)`
  assert.ok(scripts.some(x => x.includes('::GetHC()')), 'GET 调用点在场');
  assert.ok(scripts.some(x => x.includes('::SetHC(5')), 'SET = 原 flags(4)|HCF_ON(1) = 5');
  await a.undo(recipe);
  const undoScript = scripts[scripts.length - 1];
  assert.ok(/SetHC\(5\)|SetHC\(4\)/.test(undoScript), `undo 还原关闭位（5&~1=4）：${undoScript.slice(-30)}`);
});

test('M-2: homoglyph 算术全表 —— 数学字母/带圈/上标族命中风险词', async () => {
  const { matchesRiskPatterns } = await import('../src/riskGate.ts');
  const R = 'password';
  // 数学粗体 𝐩𝐚𝐬𝐬𝐰𝐨𝐫𝐝（U+1D434 系小写斜体）
  const mk = (base: number, letters: string) => [...letters].map(c => String.fromCodePoint(base + (c.charCodeAt(0) - 97))).join('');
  assert.ok(matchesRiskPatterns(mk(0x1d400, 'password'), R), '数学粗体 𝐩𝐚𝐬𝐬𝐰𝐨𝐫𝐝');
  assert.ok(matchesRiskPatterns(mk(0x1d434, 'password'), R), '数学斜体');
  assert.ok(matchesRiskPatterns(mk(0x24d0, 'password'), R), '带圈 ⓐ 系');
  assert.ok(matchesRiskPatterns(String.fromCharCode(0xff50) + 'assword', R), '全角（回归保持）');
  assert.ok(!matchesRiskPatterns(mk(0x1d400, 'viewreport'), R), '正常词不误伤');
});

test('M-3: CPT 蒸馏标定 —— 一致性可测 + 数据血缘成文', async () => {
  const { calibrateCptFromRules } = await import('../src/diagnosis.ts');
  const r = calibrateCptFromRules();
  assert.equal(r.enumerated, 32, '32 组合全枚举');
  assert.ok(r.ruleFired > 0, `规则 oracle 有判（${r.ruleFired} 组合）`);
  assert.ok(r.agreement >= 0.0, `拟合一致率 = ${r.agreement}（血缘：规则表 oracle + 计数平滑 + 专家收缩）`);
  // 拟合表完整：六症候群 × 五信号，值域合法
  for (const v of Object.values(r.cpt) as number[][]) {
    assert.equal(v.length, 5);
    for (const p of v) assert.ok(p > 0 && p < 1, `CPT 值域 (0,1)：${p}`);
  }
});

test('M-4: SO_PEERCRED 服务半边 —— scope 注入器 + pid 刻度（跨平台纯测）', async () => {
  // peercred 模块在 Windows 上 read_peer_pid 恒 None / make 协议 None —— 纯语义可测
  // TS 侧无法直载 .py —— 用源码断言（编译执法）：
  const src = readFileSync(new URL('../python_service/dsh_physical/peercred.py', import.meta.url), 'utf8');
  assert.ok(src.includes('SO_PEERCRED = 17'), 'ucred 常量');
  assert.ok(src.includes('peer_pid') && src.includes('scope'), 'scope 注入（对端 PID 刻度进 auth）');
  assert.ok(src.includes('make_peercred_protocol'), 'uvicorn http= 插件位工厂');
  const srv = readFileSync(new URL('../python_service/dsh_physical/server.py', import.meta.url), 'utf8');
  assert.ok(srv.includes('http=_peercred_http'), 'UDS 分支接线');
  assert.ok(srv.includes('SO_PEERCRED peer pid'), 'auth 中间件 pid 逐位相等校验');
});

// ΝΩ-38 诚实度修正：原唯一断言 assert.ok(true)（永真）——清单核对非可执行断言，改 {skip} 计数诚实。
test('M-5: 虚拟屏 scroll/hotkey —— K 终章已交付（本项清单核对，零改动）', { skip: '申报性清单核对：原唯一断言 assert.ok(true) 永真——scroll/hotkey 实证在上方 K-7a/K-7b，本项无可执行断言（清单第 3 项实际剩余：drag/switch）（ΝΩ-38）' });

// ─── ΝΩ-30：虚拟屏证据强度 —— z-order/遮挡、scroll 方向化、长 name 对照 ───

test('ΝΩ-30a: z-order/遮挡 —— popup 铸高层点击不可穿透；显式 z 同律；无 z 场景零回归', () => {
  const UNDER: VirtualWidget = { role: 'button', name: 'under', rect: { x: 0.3, y: 0.3, width: 0.4, height: 0.3 } };
  const POPUP_OVER: VirtualWidget = { role: 'dialog', name: 'modal', rect: { x: 0.35, y: 0.35, width: 0.2, height: 0.15 }, popup: true };
  // 弹窗排场景序**之后**也遮下层 —— 旧行为穿透命中 under（本工单修复的缺陷）
  const vs = new VirtualScreen([UNDER, POPUP_OVER]);
  assert.equal(vs.widgetAt(0.45, 0.42)?.name, 'modal', '命中自顶向下：popup 缺省铸高层');
  const ev = vs.applyAction({ kind: 'click_mouse', args: { x: 0.45, y: 0.42 } } as never);
  assert.ok(ev.note.includes('modal'), `点击命中弹窗而非穿透：${ev.note}`);
  // 被遮挡控件在弹窗覆盖区不可点；覆盖区外下层仍可点
  assert.equal(vs.widgetAt(0.32, 0.55)?.name, 'under', '弹窗覆盖区外下层可点');
  // 显式 z：非 popup 控件亦可铸层（调用方主权）—— 高 z 遮低 z
  const vs2 = new VirtualScreen([
    { role: 'button', name: 'base', rect: { x: 0.1, y: 0.1, width: 0.3, height: 0.2 }, z: 1 },
    { role: 'button', name: 'top', rect: { x: 0.15, y: 0.12, width: 0.2, height: 0.1 }, z: 5 },
  ]);
  assert.equal(vs2.widgetAt(0.2, 0.15)?.name, 'top', '显式 z 高者在上');
  // 无 z 场景零回归：同层按场景序（首个命中 = 旧行为逐字节不变）
  const vs3 = new VirtualScreen([UNDER, { role: 'button', name: 'over', rect: { x: 0.35, y: 0.35, width: 0.2, height: 0.15 } }]);
  assert.equal(vs3.widgetAt(0.45, 0.42)?.name, 'under', '无 z 同层 = 场景序');
});

test('ΝΩ-30b: esc 关最上层弹窗（非场景序首个）+ 逐层剥离', () => {
  const BACKDROP: VirtualWidget = { role: 'dialog', name: 'backdrop', rect: { x: 0.2, y: 0.2, width: 0.6, height: 0.6 }, popup: true };
  const TOAST: VirtualWidget = { role: 'dialog', name: 'toast', rect: { x: 0.3, y: 0.3, width: 0.3, height: 0.2 }, popup: true, z: 20 };
  // BACKDROP 场景序在前，但 TOAST 显式 z=20 在最上 —— 旧实现会关 backdrop（缺陷）。
  // BTN 作背景（两弹窗消亡后世界非空 —— esc 反证路径可判）
  const vs = new VirtualScreen([BTN, BACKDROP, TOAST]);
  const e1 = vs.applyAction({ kind: 'press_hotkey', args: { keys: ['esc'] } } as never);
  assert.ok(e1.note.includes('dismissed popup toast'), `esc 关最上层（z 最高）：${e1.note}`);
  const e2 = vs.applyAction({ kind: 'press_hotkey', args: { keys: ['esc'] } } as never);
  assert.ok(e2.note.includes('dismissed popup backdrop'), `剥离后次层成最上：${e2.note}`);
  const e3 = vs.applyAction({ kind: 'press_hotkey', args: { keys: ['esc'] } } as never);
  assert.equal(e3.effectDetected, false, '弹窗全消 ⇒ esc 反证（K-7b 语义零回归）');
  // 同 z 弹窗（同为缺省铸层）⇒ 同层场景序首个 = 旧方言不变
  const twin = new VirtualScreen([
    { role: 'dialog', name: 'first', rect: { x: 0.2, y: 0.2, width: 0.5, height: 0.5 }, popup: true },
    { role: 'dialog', name: 'second', rect: { x: 0.3, y: 0.3, width: 0.3, height: 0.3 }, popup: true },
  ]);
  const t1 = twin.applyAction({ kind: 'press_hotkey', args: { keys: ['esc'] } } as never);
  assert.ok(t1.note.includes('dismissed popup first'), `同层按场景序：${t1.note}`);
});

test('ΝΩ-30c: scroll 方向化 —— 带符号分轴记账 + 落点坐标参与证据', () => {
  const LIST: VirtualWidget = { role: 'list', name: 'records', rect: { x: 0.1, y: 0.3, width: 0.8, height: 0.5 }, scrollable: true };
  const vs = new VirtualScreen([LIST]);
  const d1 = vs.applyAction({ kind: 'scroll_page', args: { direction: 'down', amount: 3 } } as never);
  assert.ok(d1.note.includes('offset 3'), `down 加：${d1.note}`);
  const u1 = vs.applyAction({ kind: 'scroll_page', args: { direction: 'up', amount: 2 } } as never);
  assert.ok(u1.note.includes('offset 1'), `up 减（3−2=1，旧恒增模型得 5）：${u1.note}`);
  const u2 = vs.applyAction({ kind: 'scroll_page', args: { direction: 'up', amount: 1 } } as never);
  assert.ok(u2.note.includes('offset 0'), `回到原点：${u2.note}`);
  const r1 = vs.applyAction({ kind: 'scroll_page', args: { direction: 'right', amount: 4 } } as never);
  assert.ok(/offset x=4/.test(r1.note), `横轴分轴（left/right 同理）：${r1.note}`);
  // 落点坐标参与证据：落点在可滚动容器 ⇒ 证据且落点入注；落在非滚动控件 ⇒ 反证
  const at = vs.applyAction({ kind: 'scroll_page', args: { direction: 'down', amount: 1, x: 0.5, y: 0.5 } } as never);
  assert.equal(at.effectDetected, true, '落点在容器内');
  assert.ok(at.note.includes('at (0.50,0.50)'), `落点入注：${at.note}`);
  const miss = new VirtualScreen([LIST, { role: 'button', name: 'b', rect: { x: 0.1, y: 0.02, width: 0.2, height: 0.05 } }]);
  const me = miss.applyAction({ kind: 'scroll_page', args: { direction: 'down', amount: 1, x: 0.15, y: 0.04 } } as never);
  assert.equal(me.effectDetected, false, '落点在非滚动控件 ⇒ 反证（不可隔空找容器）');
  // 未知方向：无世界模型 ⇒ 诚实缺席（非反证）
  const weird = vs.applyAction({ kind: 'scroll_page', args: { direction: 'sideways', amount: 1 } } as never);
  assert.equal(weird.effectDetected, null, '未知方向 = 诚实缺席');
});

test('ΝΩ-30d: 长 name 对照 —— 截断 20→64（>20 字 expectedText 不再结构性失败）', () => {
  const name50 = 'submit the quarterly financial report summary'; // 45 字（旧截断 20 时 L3 必假）
  const vs = new VirtualScreen([{ role: 'button', name: name50, rect: { x: 0.3, y: 0.3, width: 0.3, height: 0.08 } }]);
  const ev = vs.applyAction({
    kind: 'click_mouse', args: { x: 0.4, y: 0.34 },
    expect: { scale: 'text-level', expectedText: name50 },
  } as never);
  assert.equal(ev.expectationMet, true, `45 字名全文入 L3 瞄准对照：${ev.note}`);
  assert.ok(ev.layers.includes('L3-semantic'), 'L3 层激活');
  // 防御上限仍在：>64 字截断 ⇒ 超出部分读不出（65+ 字 expectedText 诚实反证）
  const name70 = 'y'.repeat(70);
  const vs2 = new VirtualScreen([{ role: 'button', name: name70, rect: { x: 0.3, y: 0.3, width: 0.3, height: 0.08 } }]);
  const ev2 = vs2.applyAction({
    kind: 'click_mouse', args: { x: 0.4, y: 0.34 },
    expect: { scale: 'text-level', expectedText: name70 },
  } as never);
  assert.equal(ev2.expectationMet, false, '70 字名截 64 ⇒ 超出部分不可对照');
});


// ─── N 纪元：三项残差根除的执法 ───

test('N-1: swarm 跨会话水位 —— 恢复后同批日志零二次入账', async () => {
  const h = 'ab'.repeat(32);
  for (let i = 0; i < 3; i++) {
    await journal.append({ ts: Date.now(), tool: 'click_mouse', args: { x: 0.1, y: 0.1 }, status: 'SUCCESS', effect_detected: true, observe: `#${i} dHash=${h}` });
  }
  swarm.crystalize();
  const before = swarm.report().topRoutes[0]?.attempts ?? 0;
  const dump = swarm.dump();
  swarm.reset(); // 模拟跨会话（身份游标失效 —— 旧残差场景）
  swarm.restore(dump as never);
  const added = swarm.crystalize();
  assert.equal(added, 0, '水位跳过已消费前缀（旧残差：+3 重复入账）');
  assert.equal(swarm.report().topRoutes[0]?.attempts ?? 0, before, 'attempts 不膨胀');
});

test('N-2: 审批盲区根除 —— 双通道全沉默的点击被硬前置拒绝', async () => {
  const { createClickMouseTool } = await import('../src/tools/clickMouse.ts');
  const tool = createClickMouseTool({ enableApprovalGate: true, dangerPatterns: 'send' } as never);
  // O 纪元（#18）：法则上移一层 —— target_description 升格 schema 必填，
  // 双沉默点击在协议层即被 dsh-tools 拒（ToolArgsError），不再到达运行时。
  // N 纪元的运行时 undescribed-click 硬前置保留为纵深防御（非 schema 调用方）。
  await assert.rejects(
    (tool as unknown as { execute: (a: unknown) => Promise<string> })
      .execute({ x: 0.5, y: 0.5 }), // 无 target_description / 无 expected_text
    (e: Error & { violations?: string[] }) => {
      assert.match(e.message, /missing required property "target_description"/, '协议层硬前置');
      assert.ok((e.violations ?? []).some(v => v.includes('target_description')), '违规清单点名');
      return true;
    },
    '缺描述点击必须被 schema 层拒绝（#18 协议强制）');
  // 闸门关闭 ⇒ 描述在场的点击不受审批域影响（语义只属审批域）
  const off = createClickMouseTool({ enableApprovalGate: false, dangerPatterns: '' } as never);
  const out2 = await (off as unknown as { execute: (a: unknown) => Promise<string> })
    .execute({ x: 0.5, y: 0.5, target_description: 'some button' });
  assert.notEqual(JSON.parse(out2).status, 'ACTION_REQUIRED');
});

test('N-3: 虚拟屏 drag/switch_window 证据（真实剩余留白补全）', async () => {
  const { eng, cleanup } = engine();
  const drag = await eng.rehearse({
    id: 'chain-n3-drag', origin: 'manual', virtualScene: SCENE,
    actions: [{ kind: 'drag_mouse', args: { startX: 0.15, startY: 0.12, endX: 0.6, endY: 0.6 } }],
  });
  assert.equal(drag.verdict, 'passed', '抓取按钮拖走 = L1 证据');
  const grabAir = await eng.rehearse({
    id: 'chain-n3-air', origin: 'manual', virtualScene: SCENE,
    actions: [{ kind: 'drag_mouse', args: { startX: 0.9, startY: 0.9, endX: 0.5, endY: 0.5 } }],
  });
  assert.equal(grabAir.verdict, 'failed', '抓空 = 反证');
  const win = await eng.rehearse({
    id: 'chain-n3-win', origin: 'manual', virtualScene: SCENE,
    actions: [{ kind: 'switch_window', args: { titleKeyword: 'search' } }],
  });
  assert.equal(win.verdict, 'passed', '标题命中 search 输入框 = 聚焦转移');
  const noWin = await eng.rehearse({
    id: 'chain-n3-nowin', origin: 'manual', virtualScene: SCENE,
    actions: [{ kind: 'switch_window', args: { titleKeyword: 'nonexistent' } }],
  });
  assert.equal(noWin.verdict, 'failed', '无匹配 = 反证');
  cleanup();
});
