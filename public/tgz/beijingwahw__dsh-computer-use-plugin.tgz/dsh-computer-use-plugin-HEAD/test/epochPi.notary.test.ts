// test/epochPi.notary.test.ts
// 纪元 Π（可公证行为账本）执法测试 —— Π-1~Π-5：
//   Π-1 锚链成链：两锚互链（prev=前锚 hash）、JSONL 落盘两行、断尾半行容忍重读 + 治疗写
//   Π-2 篡改翻红：锚定后篡改 journal 历史行 ⇒ chain-integrity 红、ok=false
//   Π-3 RFC3161：请求体合法 DER（sha256 OID + nonce 可解出）、Content-Type 正确；
//        假回执（内嵌正确 imprint+nonce）⇒ imprintVerified=true、source='rfc3161'；
//        fetch 拒绝/超时 ⇒ source='local' 回退 + 注记；endpoint='' ⇒ fetch 零调用
//   Π-4 MMR 章：诚实 journal ⇒ mmr-membership 绿；replay-consistency='n/a' 且理由在场
//   Π-5 notarize 工具动作：quality_checkup 分发走通、四章报告返回；autoAnchor 开关面在册
//   Π-6 auxChains 双账覆盖（ΑΩ-R42）：在场收集/缺席字段缺席/锚后篡改 drift 注记不翻章/
//        驱逐与旧锚 n/a/哈希域覆盖
//   Π-7 journalDisk 旁链（ΝΩ-21 驱逐盲区清偿）：磁盘 JSONL 整体指纹登记进锚哈希域与
//        TSA 摘要域；磁盘篡改/截断 ⇒ disk-chain-drift 注记（保守不翻章）；容量驱逐
//        （③-b n/a）时 drift 证词仍在场 —— 盲区就此有证可举；诚实增长前缀复现
//   Π-8 自适应锚频（ΝΩ-21/NO-3）：shouldAnchor 纯函数 / anchorCadence 注记 / 章③
//        补锚提示 / notaryAutoAnchorIfDue 卸载接线面（不引入后台定时器）
// 全离线：journal 单例 reset 直喂、假 fetch、注入时钟与 CSPRNG（确定性）。
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import type { Config } from '../src/config';
import {
  notary, notaryAutoAnchorIfConfigured, notaryAutoAnchorIfDue, shouldAnchor,
  ADAPTIVE_ANCHOR_THRESHOLD, anchorHash, canonical, sha256Hex,
  type AnchorRecord, type NotarizableLedger,
} from '../src/notary/index.ts';
import { journal } from '../src/journal.ts';
import { sandboxLog } from '../src/sandbox/log.ts';
import { derRead, derChildren, derEncode } from '../src/notary/rfc3161.ts';
import { createQualityCheckupTool } from '../src/tools/qualityCheckup.ts';
import { doctor } from '../src/qualityDoctor.ts';

// ─── 测试基建：确定性时钟 / 种子 CSPRNG / journal 播种 ───

/** 固定时钟（2025-01-01T00:00:00Z —— 锚记录时间戳确定性） */
const fixedClock = (): number => 1735689600000;

// ─── 事件循环保活（DEBTS D-G1 悬挂收口债）───
// (c) 段「挂起不答」假 TSA 的等待，其结算依赖 AbortSignal.timeout 的内部定时器
// （src/notary/rfc3161.ts requestRfc3161Timestamp —— Node 官方文档明示该定时器
// unref、不保活事件循环；生产宿主恒有 stdio/服务器句柄在场，abort 照常触发）。
// 裸 node:test 子进程里无其他 ref'd 句柄 ⇒ 事件循环先行排干 ⇒ 根测试收割在途
// 用例（cancelledByParent："Promise resolution is still pending but the event
// loop has already resolved"），其后排队用例（Π-4/Π-5）连带未跑。测试侧对策：
// 等待期间持一枚 ref'd 保活定时器、finally 收口 —— 若产品真挂死，保活到期后
// 循环照常排干、收割照常发生（防御不失守）。
/** 持一枚 ref'd 保活定时器；返回收口函数（clearTimeout —— 调用方必须在 finally 里执行） */
function keepEventLoopAlive(ms: number): () => void {
  const t = setTimeout(() => { /* 保活哨：正常路径等不到这里触发 */ }, ms);
  return () => clearTimeout(t);
}

/** 种子伪随机（仅测试 —— 生产 nonce 走 crypto.randomBytes；两实例同种子 ⇒ 同字节流） */
function makeRandom(seed: number): (n: number) => Uint8Array {
  let s = seed >>> 0 || 1;
  return (n: number) => {
    const out = new Uint8Array(n);
    for (let i = 0; i < n; i++) {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      out[i] = (s >>> 16) & 0xff;
    }
    return out;
  };
}

/** 复刻 notary.mintNonce 的正号位规约（首字节 MSB 清零 + 置低位 —— 与请求 nonce 对照用） */
function asMintedNonce(raw: Uint8Array): Uint8Array {
  const out = Uint8Array.from(raw);
  out[0] = (out[0] & 0x7f) | 0x01;
  return out;
}

/** journal 播种：reset 后喂 n 条确定性动作（click_mouse ∈ ACTION_TOOLS，直接入链） */
async function seedJournal(n: number): Promise<void> {
  journal.reset();
  for (let i = 0; i < n; i++) {
    await journal.append({
      ts: 1700000000 + i, tool: 'click_mouse',
      args: { x: (i + 1) / 10, y: 0.5 }, status: 'SUCCESS', effect_detected: true,
    });
  }
}

function hex(b: Uint8Array): string {
  return Buffer.from(b.buffer, b.byteOffset, b.byteLength).toString('hex');
}

function concat(...parts: Uint8Array[]): Uint8Array {
  const out = new Uint8Array(parts.reduce((s, p) => s + p.length, 0));
  let off = 0;
  for (const p of parts) { out.set(p, off); off += p.length; }
  return out;
}

// ─── Π-3 的假 TSA：从请求 DER 里取出 digest 与 nonce，铸内嵌两者的最小 DER 回执 ───

const OID = (bytes: number[]) => derEncode(0x06, Uint8Array.from(bytes));
const SHA256_OID_ARMS = [0x60, 0x86, 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01];
const ID_CT_TSTINFO_ARMS = [0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x09, 0x10, 0x01, 0x04];

/** 最小 TimeStampResp：PKIStatus=granted + ContentInfo[0]{ mock TSTInfo（imprint+nonce 内嵌） } */
function buildTimestampReply(req: Uint8Array): Uint8Array {
  const root = derRead(req)!;
  const kids = derChildren(root, req);
  const imprint = derChildren(kids[1], req); // [version, messageImprint, nonce, certReq]
  const digest = req.subarray(imprint[1].contentStart, imprint[1].contentEnd);
  const nonce = req.subarray(kids[2].contentStart, kids[2].contentEnd);
  const tstInfo = derEncode(0x30, concat(
    derEncode(0x02, Uint8Array.of(1)),                                    // version
    OID(ID_CT_TSTINFO_ARMS),                                              // policy（mock：任意合法 OID）
    derEncode(0x30, concat(                                               // messageImprint —— 内嵌正确摘要
      derEncode(0x30, OID(SHA256_OID_ARMS)),
      derEncode(0x04, digest),
    )),
    derEncode(0x02, Uint8Array.of(0x0a)),                                 // serialNumber
    derEncode(0x18, new TextEncoder().encode('20260102030405Z')),         // genTime
    derEncode(0x02, nonce),                                               // nonce 回显
  ));
  const contentInfo = derEncode(0x30, concat(OID(ID_CT_TSTINFO_ARMS), derEncode(0xa0, tstInfo)));
  const statusInfo = derEncode(0x30, derEncode(0x02, Uint8Array.of(0)));  // PKIStatus = 0 (granted)
  return derEncode(0x30, concat(statusInfo, contentInfo));
}

// ─── Π-1 锚链成链 ───

test('Π-1: 两锚互链（第二锚 prev=第一锚 hash）+ JSONL 两行 + 断尾半行容忍读/治疗写', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pi-notary-1-'));
  const trace = join(dir, 'anchors.jsonl');
  try {
    notary.reset();
    notary.configure({ endpoint: '', tracePath: trace });
    await seedJournal(3);

    const a1 = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x2a) });
    const a2 = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x2b) });
    assert.ok(a1 && a2, '两锚铸成');
    assert.equal(a1.prevAnchorHash, null, '首锚 prev 为 null 哨兵');
    assert.equal(a2.prevAnchorHash, a1.hash, '第二锚链接第一锚（锚自链）');
    assert.match(a1.hash, /^[0-9a-f]{64}$/, '锚 hash = sha256 hex');
    // 账本快照三件套忠实映射 journal 公开面
    assert.equal(a1.seq, 3);
    assert.equal(a1.chainTip, journal.tip);
    assert.equal(a1.mmrRoot, journal.mmrRoot());

    const lines = readFileSync(trace, 'utf8').split('\n').filter(l => l.trim() !== '');
    assert.equal(lines.length, 2, 'notaryTracePath 落两行');
    assert.equal(JSON.parse(lines[1]).hash, a2.hash, '磁盘行与内存锚同一');

    // 断尾：第二行截半（无尾换行 —— 模拟进程被杀）⇒ 重读不炸，半行被容忍
    const torn = lines[0] + '\n' + lines[1].slice(0, Math.floor(lines[1].length / 2));
    writeFileSync(trace, torn, 'utf8');
    notary.reset();
    notary.configure({ endpoint: '', tracePath: trace });
    assert.equal(notary.anchorCount, 1, '断尾半行被容忍（完好行照常铸回）');
    assert.equal(notary.lastError, null, '容忍不是故障（lastError 干净）');

    // 治疗写：续锚前先把断尾封口 —— 半行不再粘进新行
    const a3 = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x2c) });
    assert.ok(a3);
    assert.equal(a3.prevAnchorHash, JSON.parse(lines[0]).hash, '治疗后续锚接回完好尾锚');
    const parsed: string[] = [];
    for (const l of readFileSync(trace, 'utf8').split('\n')) {
      if (l.trim() === '') continue;
      try { parsed.push(JSON.parse(l).hash); } catch { /* 治疗封口后的断尾残骸 —— 非行 */ }
    }
    assert.deepEqual(parsed, [JSON.parse(lines[0]).hash, a3.hash], '断口封行后恰好两枚完好锚');
  } finally {
    notary.reset();
    rmSync(dir, { recursive: true, force: true });
  }
});

// ─── Π-2 篡改翻红 ───

test('Π-2: 锚定后篡改 journal 历史行 ⇒ chain-integrity 红、ok=false（前缀重走同翻红）', async () => {
  notary.reset();
  notary.configure({ endpoint: '', tracePath: '' }); // 纯内存锚链
  await seedJournal(4);
  const a = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x33) });
  assert.ok(a);

  // 篡改历史第 2 条（锚已宣誓的字节域）—— list(false) 返回的就是 journal 内部条目对象
  const entries = journal.list(false);
  (entries[1] as { status: string }).status = 'TAMPERED';

  const r = notary.verifyNotary();
  assert.equal(r.badges['chain-integrity'].status, 'red', '全链校验翻红');
  assert.match(r.badges['chain-integrity'].detail, /entry 1/, '断点定位到被篡改条目');
  assert.equal(r.badges['timestamp-anchor'].status, 'red', '前缀重走发现链尖复算失配');
  assert.equal(r.ok, false, '任一红章 ⇒ 整体 ok=false');
});

// ─── Π-3 RFC 3161 ───

test('Π-3: 请求 DER 合法（sha256 OID+nonce 可解）/ Content-Type 正确 / 回执核验 / 回退 / 零调用', async () => {
  notary.reset();
  notary.configure({ endpoint: '', tracePath: '' });
  await seedJournal(2);

  // (a) 假 TSA：回执内嵌请求自身的 digest+nonce ⇒ imprintVerified=true、source='rfc3161'
  let calls = 0;
  let capturedUrl = '';
  let capturedHeaders: Record<string, string> = {};
  let capturedBody: Uint8Array | null = null;
  const fetchReceipt = (async (url: unknown, init: { headers: Record<string, string>; body: Uint8Array }) => {
    calls++;
    capturedUrl = String(url);
    capturedHeaders = init.headers;
    capturedBody = init.body;
    const reply = buildTimestampReply(init.body);
    return {
      ok: true, status: 200,
      arrayBuffer: async () =>
        reply.buffer.slice(reply.byteOffset, reply.byteOffset + reply.byteLength) as ArrayBuffer,
    };
  }) as unknown as typeof fetch;

  const peek = makeRandom(0x2a); // 同种子预演 —— 复算 anchorOnce 将铸出的 nonce
  const expectedNonce = asMintedNonce(peek(16));
  const a = await notary.anchorOnce({
    endpoint: 'https://tsa.example/tsr', fetchImpl: fetchReceipt,
    now: fixedClock, random: makeRandom(0x2a),
  });
  assert.ok(a);
  assert.equal(a.timestamp.source, 'rfc3161', '回执取得 ⇒ 第三方源');
  assert.equal(a.timestamp.imprintVerified, true, 'imprint+nonce 均对上');
  assert.ok(a.timestamp.token, 'token 原始字节留存（base64）');
  assert.equal(calls, 1, '单次尝试');
  assert.equal(capturedUrl, 'https://tsa.example/tsr');
  assert.equal(capturedHeaders['content-type'], 'application/timestamp-query', 'RFC 3161 线协议头');

  // 请求体是合法 DER：TimeStampReq ::= SEQUENCE{ INTEGER 1, messageImprint, nonce, certReq TRUE }
  const req = capturedBody!;
  const root = derRead(req);
  assert.ok(root && root.tag === 0x30 && root.end === req.length, '单一完整 DER SEQUENCE');
  const kids = derChildren(root!, req);
  assert.equal(kids.length, 4, 'version / messageImprint / nonce / certReq 四元');
  assert.equal(kids[0].tag === 0x02 && req[kids[0].contentStart], 1, 'version=1');
  const imprintKids = derChildren(kids[1], req);
  const algKids = derChildren(imprintKids[0], req);
  assert.equal(algKids[0].tag, 0x06, 'hashAlgorithm 是 OID');
  assert.equal(hex(req.subarray(algKids[0].contentStart, algKids[0].contentEnd)), '608648016503040201',
    'sha256 OID 2.16.840.1.101.3.4.2.1 可解出');
  assert.equal(imprintKids[1].tag === 0x04 && imprintKids[1].contentEnd - imprintKids[1].contentStart, 32,
    'hashedMessage = 32 字节 sha256 摘要');
  assert.equal(kids[2].tag, 0x02, 'nonce 是 INTEGER');
  assert.deepEqual(req.subarray(kids[2].contentStart, kids[2].contentEnd), expectedNonce,
    'nonce 与注入 CSPRNG 输出一致（正号位规约）');
  assert.equal(kids[3].tag === 0x01 && req[kids[3].contentStart], 0xff, 'certReq=TRUE');

  // 留存 token 可离线复核：核验章 ③ 重走通过（零网络）
  const r = notary.verifyNotary();
  assert.equal(r.badges['timestamp-anchor'].status, 'green');
  assert.match(r.badges['timestamp-anchor'].detail, /re-verified offline/, 'token imprint+nonce 离线复核在场');
  assert.equal(r.ok, true);

  // (b) fetch 拒绝 ⇒ 诚实本地回退 + 注记（绝不谎称第三方）
  const fetchReject = (async () => { throw new Error('network unreachable'); }) as unknown as typeof fetch;
  const b = await notary.anchorOnce({
    endpoint: 'https://tsa.example/tsr', fetchImpl: fetchReject,
    now: fixedClock, random: makeRandom(0x44),
  });
  assert.ok(b);
  assert.equal(b.timestamp.source, 'local', '回退为本地时间锚');
  assert.ok(b.timestamp.note && /rfc3161 fallback/.test(b.timestamp.note) && /network unreachable/.test(b.timestamp.note),
    '回退注记携带失败事实');
  assert.equal(b.timestamp.imprintVerified, undefined, '无回执即无核验标志（不虚标）');

  // (c) 超时（挂起不答，abort 信号触发）⇒ 同律回退
  const fetchHang = (async (_url: unknown, init: { signal?: AbortSignal }) => {
    return new Promise<never>((_resolve, reject) => {
      init?.signal?.addEventListener('abort', () => reject(new Error('aborted: tsa timeout')), { once: true });
    });
  }) as unknown as typeof fetch;
  // 收口债 D-G1：本段等待依赖 AbortSignal.timeout(40) 的内部 unref 定时器 ——
  // 持保活定时器（宽放 1s）防裸测试进程事件循环先行排干；finally 收口，
  // 断言失败也不残留句柄（见文件头工坊注释）。
  const releaseLoop = keepEventLoopAlive(1_000);
  let c: Awaited<ReturnType<typeof notary.anchorOnce>>;
  try {
    c = await notary.anchorOnce({
      endpoint: 'https://tsa.example/tsr', fetchImpl: fetchHang, timeoutMs: 40,
      now: fixedClock, random: makeRandom(0x55),
    });
  } finally {
    releaseLoop();
  }
  assert.ok(c);
  assert.equal(c.timestamp.source, 'local', '超时 ⇒ 本地回退');
  assert.match(c.timestamp.note ?? '', /aborted: tsa timeout/, '注记携带超时事实');

  // (d) endpoint='' ⇒ 零网络（spy 计数 = 0）
  notary.reset();
  notary.configure({ endpoint: '', tracePath: '' });
  await seedJournal(1);
  let spyCalls = 0;
  const spy = (async () => {
    spyCalls++;
    return { ok: true, status: 200, arrayBuffer: async () => new ArrayBuffer(0) };
  }) as unknown as typeof fetch;
  const d = await notary.anchorOnce({ fetchImpl: spy, now: fixedClock, random: makeRandom(0x66) });
  assert.ok(d);
  assert.equal(d.timestamp.source, 'local');
  assert.equal(spyCalls, 0, 'endpoint 空 ⇒ fetch 零调用（零网络承诺）');
});

// ─── Π-4 MMR 章 + 诚实 n/a ───

test('Π-4: 诚实 journal ⇒ mmr-membership 绿（静止对锚根/增长对当前根）；replay-consistency 诚实 n/a', async () => {
  notary.reset();
  notary.configure({ endpoint: '', tracePath: '' });
  await seedJournal(5);
  const a = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x77) });
  assert.ok(a);

  const r = notary.verifyNotary();
  assert.equal(r.badges['chain-integrity'].status, 'green');
  assert.equal(r.badges['mmr-membership'].status, 'green', '包含证明对锚根验证通过');
  assert.match(r.badges['mmr-membership'].detail, /ANCHOR/);
  assert.equal(r.badges['timestamp-anchor'].status, 'green');
  // 章④：诚实降级 —— n/a 而非虚假的绿，理由在场
  assert.equal(r.badges['replay-consistency'].status, 'n/a');
  assert.ok(r.badges['replay-consistency'].detail.length > 20, 'n/a 理由说明在场');
  assert.equal(r.ok, true, 'n/a 不算失败');

  // 增长世界：锚后 journal 追加 —— MMR 追加型，旧叶不可能消失 ⇒ 章对「当前根」仍绿
  await journal.append({ ts: 1700000005, tool: 'scroll_page', args: { direction: 'down' }, status: 'SUCCESS' });
  const r2 = notary.verifyNotary();
  assert.equal(r2.badges['mmr-membership'].status, 'green');
  assert.match(r2.badges['mmr-membership'].detail, /CURRENT/, '增长世界对当前根验证（形态如实标注）');
  assert.equal(r2.ok, true);
});

// ─── Π-5 notarize 工具动作 + autoAnchor 开关面 ───

interface Executable { execute(args: unknown): Promise<string> }

test('Π-5: quality_checkup notarize 分发走通（四章报告 + 锚计数 + 时间戳来源）；开关面在册', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pi-notarize-'));
  try {
    // 预装配（与 P-5 同法：报告路径已设 ⇒ ensureDoctorConfigured 直通，不付真扫描）
    await doctor.configure({ sourceRoot: resolve(process.cwd(), 'src'), memoryPath: join(dir, 'mem.json'), strict: false });
    const cfg = {
      doctorMemoryPath: join(dir, 'mem.json'),
      notaryEndpoint: '', notaryTracePath: '', notaryAutoAnchor: false,
    } as unknown as Config;
    const tool = createQualityCheckupTool(cfg);

    await seedJournal(2);
    notary.reset();
    const out = await (tool as Executable).execute({ action: 'notarize' });
    const o = JSON.parse(out);
    assert.equal(o.status, 'SUCCESS', '四件套出证');
    assert.equal(o.state_anchor.anchor_minted, true);
    assert.equal(o.state_anchor.anchors_total, 1);
    assert.equal(o.state_anchor.timestamp_source, 'local', 'endpoint 空 ⇒ 诚实本地源');
    assert.equal(o.state_anchor.notary_ok, true);
    for (const badge of ['chain-integrity', 'mmr-membership', 'timestamp-anchor', 'replay-consistency']) {
      assert.ok(o.state_anchor.badges[badge], `章 ${badge} 在报告里`);
      assert.match(o.state_anchor.badges[badge], /^(green|red|n\/a) — /, '章形态：status — detail');
    }
    assert.equal(o.state_anchor.badges['replay-consistency'].startsWith('n/a — '), true, '重放章诚实 n/a');

    // 现有分发语义零变化：未知动作仍是 FAILED（理由串含 notarize 提示）
    const unknown = JSON.parse(await (tool as Executable).execute({ action: 'nope' }));
    assert.equal(unknown.status, 'FAILED');
    assert.match(unknown.reason, /unknown action/);
    assert.match(unknown.reason, /notarize/);

    // 开关面在册：notaryAutoAnchorIfConfigured —— 假 ⇒ 零行为；真 ⇒ 铸一枚（fire-and-forget）
    assert.equal(typeof notaryAutoAnchorIfConfigured, 'function', '开关面导出在册');
    notary.reset();
    notaryAutoAnchorIfConfigured({ notaryAutoAnchor: false, notaryEndpoint: '', notaryTracePath: '' });
    assert.equal(notary.anchorCount, 0, '开关假 ⇒ 不铸锚');
    notaryAutoAnchorIfConfigured({ notaryAutoAnchor: true, notaryEndpoint: '', notaryTracePath: '' });
    await new Promise(resolve_ => setTimeout(resolve_, 20)); // fire-and-forget 落账（本地锚路径同步即可完成，留拍宽限）
    assert.equal(notary.anchorCount, 1, '落账后恰好一枚自动锚');
    assert.equal(notary.lastAnchor()?.seq, 2, '锚覆盖当前 journal 条数');
    // null/undefined 配置面：零行为不炸（防御）
    notaryAutoAnchorIfConfigured(null);
    notaryAutoAnchorIfConfigured(undefined);
  } finally {
    notary.reset();
    rmSync(dir, { recursive: true, force: true });
  }
});

// ─── Π-6 ΑΩ-R42：旁链双账覆盖 ───

test('Π-6: auxChains 双账覆盖 —— 在场收集/沙箱缺席字段缺席/锚后篡改注记 drift 不翻章/驱逐与旧锚 n/a/哈希域覆盖', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pi-notary-6-'));
  const trace = join(dir, 'anchors.jsonl');
  try {
    // (a) 沙箱缺席 ⇒ 字段缺席（诚实，不伪造空链）
    sandboxLog.reset();
    notary.reset();
    notary.configure({ endpoint: '', tracePath: '' });
    await seedJournal(2);
    const bare = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x61) });
    assert.ok(bare);
    assert.equal(bare.auxChains, undefined, '沙箱未启用 ⇒ 字段缺席');
    assert.equal('auxChains' in bare, false, '键不落（canonical 缺席语义 —— 与旧锚逐字节同形态）');
    let r = notary.verifyNotary();
    assert.match(r.badges['timestamp-anchor'].detail, /no aux-chain snapshot on record/, '注记级 n/a 在场');
    assert.equal(r.lastAnchor?.auxChains, null, '报告投影 null 诚实标注');

    // (b) 沙箱在场 ⇒ 三元组忠实映射账本公开面（条数 + 尾哈希）；复算一致 ⇒ 注记在场
    for (let i = 0; i < 3; i++) await sandboxLog.append('observation', { i });
    const aux1 = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x62) });
    assert.ok(aux1);
    assert.deepEqual(aux1.auxChains, [{ chainName: 'sandboxLog', seq: 3, chainTip: sandboxLog.tip }],
      '三元组 = (chainName, 条数, 尾哈希)');
    r = notary.verifyNotary();
    assert.equal(r.badges['timestamp-anchor'].status, 'green', '复算一致 ⇒ 绿');
    assert.match(r.badges['timestamp-anchor'].detail, /re-walk over 3 entries reproduces its chainTip/);
    assert.equal(r.badges['replay-consistency'].status, 'n/a', 'observation 非排练段 —— 重放章不受旁链快照牵连');
    assert.equal(r.ok, true);
    assert.deepEqual(r.lastAnchor?.auxChains, [{ chainName: 'sandboxLog', seq: 3, chainTip: sandboxLog.tip }],
      '报告投影如实（下游独立复核入口）');

    // (c) 哈希域覆盖：改 auxChains 一字节（seq 3→4）⇒ 锚 hash 失配
    const domain = { ...aux1 } as Partial<AnchorRecord>;
    delete domain.hash;
    assert.equal(anchorHash(domain as Omit<AnchorRecord, 'hash'>), aux1.hash, '原记录重算一致');
    const tampered = { ...aux1, auxChains: [{ chainName: 'sandboxLog', seq: 4, chainTip: aux1.auxChains![0].chainTip }] };
    const tDomain = { ...tampered } as Partial<AnchorRecord>;
    delete tDomain.hash;
    assert.notEqual(anchorHash(tDomain as Omit<AnchorRecord, 'hash'>), tampered.hash, '改一字节 ⇒ 锚 hash 变');

    // (d) 锚后篡改 sandboxLog 一条 ⇒ 复核注记 aux-chain-drift 可见、章不翻红
    (sandboxLog.list()[1] as { data: Record<string, unknown> }).data.i = 999;
    r = notary.verifyNotary();
    assert.equal(r.badges['timestamp-anchor'].status, 'green', '注记级核验不翻章（锚定 ≠ 内容为真）');
    assert.match(r.badges['timestamp-anchor'].detail, /aux-chain-drift/, 'drift 证词在场');
    assert.match(r.badges['timestamp-anchor'].detail, /learning history drifted/);
    assert.equal(r.ok, true, '旁链漂移不算整体失败 —— 判据面隔离');

    // (e) 旁链容量驱逐（链基前滚）⇒ 重算不可得 ⇒ 诚实 n/a（不虚算不误报）
    sandboxLog.configure('', 2);
    sandboxLog.reset();
    for (let i = 0; i < 3; i++) await sandboxLog.append('observation', { i });
    const aux2 = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x63) });
    assert.ok(aux2 && aux2.auxChains && aux2.auxChains[0].seq === 2, '存活窗口计数（驱逐后 2/3）');
    r = notary.verifyNotary();
    assert.equal(r.badges['timestamp-anchor'].status, 'green');
    assert.match(r.badges['timestamp-anchor'].detail, /not recomputable/, '驱逐 ⇒ 诚实 n/a 注记');

    // (f) 旧锚兼容：手铸 pre-ΑΩ-R42 形态锚行（无 auxChains 键）⇒ 水合重读不炸、章③绿 + n/a 注记
    const legacySeed = {
      seq: 2, chainTip: journal.tip, mmrRoot: journal.mmrRoot(),
      timestamp: { source: 'local' as const, anchoredAt: 1735689600000, nonce: 'bg==' },
      prevAnchorHash: null,
    };
    writeFileSync(trace, JSON.stringify({ ...legacySeed, hash: anchorHash(legacySeed) }) + '\n', 'utf8');
    notary.reset();
    notary.configure({ endpoint: '', tracePath: trace });
    assert.equal(notary.anchorCount, 1, '旧锚行铸回（水合路径防御式）');
    r = notary.verifyNotary();
    assert.equal(r.badges['timestamp-anchor'].status, 'green', '旧锚（无 auxChains）核验照常');
    assert.match(r.badges['timestamp-anchor'].detail, /no aux-chain snapshot on record/);
    assert.equal(r.lastAnchor?.auxChains, null, '旧锚投影 null（不追溯、不误判）');
  } finally {
    sandboxLog.reset();
    sandboxLog.configure('', 2000);
    notary.reset();
    rmSync(dir, { recursive: true, force: true });
  }
});

// ─── Π-7 ΝΩ-21：journalDisk 旁链（容量驱逐盲区的磁盘取证面） ───

test('Π-7: journalDisk 旁链 —— 磁盘指纹登记/哈希域与 TSA 摘要域覆盖/篡改与截断 drift 注记不翻章/驱逐盲区有证可举/诚实增长前缀复现', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'pi-notary-7-'));
  const disk = join(dir, 'journal.jsonl');
  try {
    // (a) 路径未配 ⇒ journalDisk 不登记（诚实缺席 —— 与沙箱缺席同律）
    sandboxLog.reset();
    notary.reset();
    notary.configure({ endpoint: '', tracePath: '' });
    await seedJournal(2);
    const bare = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x71) });
    assert.ok(bare);
    assert.equal(bare.auxChains, undefined, '沙箱与磁盘路径皆缺席 ⇒ 旁链字段缺席');

    // (b) 配路径 + 3 行账本文件 ⇒ 登记 (journalDisk, 3, sha256(3 行字节))
    const threeLines = '{"tool":"click_mouse","i":1}\n{"tool":"click_mouse","i":2}\n{"tool":"scroll_page","i":3}\n';
    writeFileSync(disk, threeLines, 'utf8');
    const expectedTip = sha256Hex(threeLines);
    notary.reset();
    notary.configure({ endpoint: '', tracePath: '', journalDiskPath: disk });
    const a = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x72) });
    assert.ok(a);
    assert.deepEqual(a.auxChains, [{ chainName: 'journalDisk', seq: 3, chainTip: expectedTip }],
      '三元组 = (journalDisk, 完整行数, 前 N 行字节整体 sha256)');
    let r = notary.verifyNotary();
    assert.equal(r.badges['timestamp-anchor'].status, 'green', '复算一致 ⇒ 绿');
    assert.match(r.badges['timestamp-anchor'].detail,
      /journalDisk re-hash over the sworn 3-line prefix reproduces its fingerprint/, '复算注记在场');
    assert.equal(r.ok, true);

    // (c) 哈希域覆盖：改 journalDisk 三元组一字节（seq 3→4）⇒ 锚 hash 失配
    const domain = { ...a } as Partial<AnchorRecord>;
    delete domain.hash;
    assert.equal(anchorHash(domain as Omit<AnchorRecord, 'hash'>), a.hash, '原记录重算一致');
    const tampered = { ...a, auxChains: [{ chainName: 'journalDisk', seq: 4, chainTip: expectedTip }] };
    const tDomain = { ...tampered } as Partial<AnchorRecord>;
    delete tDomain.hash;
    assert.notEqual(anchorHash(tDomain as Omit<AnchorRecord, 'hash'>), tampered.hash, '改一字节 ⇒ 锚 hash 变');

    // (d) TSA 摘要域覆盖：假 TSA 捕获请求 —— imprint = sha256(canonical(载荷含 journalDisk))
    notary.reset();
    notary.configure({ endpoint: '', tracePath: '', journalDiskPath: disk });
    await seedJournal(2);
    let capturedBody: Uint8Array | null = null;
    const spyTsa = (async (_url: unknown, init: { headers: Record<string, string>; body: Uint8Array }) => {
      capturedBody = init.body;
      const reply = buildTimestampReply(init.body);
      return {
        ok: true, status: 200,
        arrayBuffer: async () => reply.buffer.slice(reply.byteOffset, reply.byteOffset + reply.byteLength) as ArrayBuffer,
      };
    }) as unknown as typeof fetch;
    const d = await notary.anchorOnce({
      endpoint: 'https://tsa.example/tsr', fetchImpl: spyTsa,
      now: fixedClock, random: makeRandom(0x73),
    });
    assert.ok(d && capturedBody);
    const req = capturedBody as Uint8Array;
    const kids = derChildren(derRead(req)!, req);
    const imprintKids = derChildren(kids[1], req);
    const digestBytes = req.subarray(imprintKids[1].contentStart, imprintKids[1].contentEnd);
    const expected = sha256Hex(canonical({
      seq: journal.list(false).length,
      chainTip: journal.tip,
      mmrRoot: journal.mmrRoot(),
      prevAnchorHash: null, // 本测 reset 后首锚
      auxChains: [{ chainName: 'journalDisk', seq: 3, chainTip: expectedTip }],
    }));
    assert.equal(Buffer.from(digestBytes.buffer, digestBytes.byteOffset, digestBytes.byteLength).toString('hex'), expected,
      'RFC 3161 摘要域覆盖磁盘指纹（第三方回执绑定磁盘史）');

    // (e) 磁盘篡改（重写第 2 行、行数不变）⇒ disk-chain-drift 注记在场、章不翻红
    writeFileSync(disk, '{"tool":"click_mouse","i":1}\n{"tool":"click_mouse","i":"TAMPERED"}\n{"tool":"scroll_page","i":3}\n', 'utf8');
    r = notary.verifyNotary();
    assert.equal(r.badges['timestamp-anchor'].status, 'green', '注记级核验不翻章（锚定 ≠ 内容为真 —— R42 同律）');
    assert.match(r.badges['timestamp-anchor'].detail, /disk-chain-drift/, 'drift 证词在场');
    assert.match(r.badges['timestamp-anchor'].detail, /disk journal rewritten after anchoring/);
    assert.equal(r.ok, true, '磁盘漂移不算整体失败 —— 判据面隔离');

    // (f) 驱逐盲区端到端：容量驱逐后 ③-b 诚实 n/a —— 但 drift 证词仍随章③ detail 在场
    //     （③-d 先于驱逐早退执行 —— 盲区就此有证可举；磁盘史改回篡改前的主张由 (e) 覆盖，
    //      此处直接以「篡改文件 + 驱逐链基」的复合形态执法）
    const evictedLedger: NotarizableLedger = {
      entries: () => journal.list(false),
      tip: () => journal.tip,
      base: () => 'evicted-hash-not-genesis', // 链基前滚 ⇒ ③-b 前缀重走不可得
      verify: () => journal.verify(),
      mmrRoot: () => journal.mmrRoot(),
      mmrProof: (i) => journal.mmrProof(i),
    };
    r = notary.verifyNotary({ ledger: evictedLedger });
    assert.equal(r.badges['timestamp-anchor'].status, 'n/a', '驱逐 ⇒ 章③诚实 n/a（既有语义不动）');
    assert.match(r.badges['timestamp-anchor'].detail, /capacity eviction advanced the chain base/, '驱逐事实申报');
    assert.match(r.badges['timestamp-anchor'].detail, /disk-chain-drift/, '盲区窗口内磁盘史被动过 —— 证词仍随章在场');

    // (g) 诚实增长（追加第 4 行 —— append-only）⇒ 前 3 行前缀重算复现
    writeFileSync(disk, threeLines + '{"tool":"type_text","i":4}\n', 'utf8');
    r = notary.verifyNotary();
    assert.match(r.badges['timestamp-anchor'].detail,
      /journalDisk re-hash over the sworn 3-line prefix reproduces its fingerprint \(file grew to 4 lines since — append-only, prefix intact\)/,
      '增长世界前缀复现（append-only 语义如实标注）');

    // (h) 截断（仅剩 1 行 < 誓言 3 行）⇒ fewer-lines drift 注记
    writeFileSync(disk, '{"tool":"click_mouse","i":1}\n', 'utf8');
    r = notary.verifyNotary();
    assert.match(r.badges['timestamp-anchor'].detail, /disk-chain-drift/);
    assert.match(r.badges['timestamp-anchor'].detail, /now holds 1 complete lines/, '截断形态如实申报');

    // (i) 核验端无路径：journalDisk 在册但未配 journalDiskPath ⇒ 诚实 n/a 注记
    notary.configure({ endpoint: '', tracePath: '', journalDiskPath: '' });
    r = notary.verifyNotary();
    assert.match(r.badges['timestamp-anchor'].detail,
      /journalDisk chain on record but no journal disk path configured/, '无路径 ⇒ 不可重算的诚实申报');
  } finally {
    sandboxLog.reset();
    notary.reset();
    rmSync(dir, { recursive: true, force: true });
  }
});

// ─── Π-8 ΝΩ-21（NO-3）：自适应锚频 ───

test('Π-8: shouldAnchor 纯函数 / anchorCadence 注记与章③补锚提示 / notaryAutoAnchorIfDue 卸载接线面', async () => {
  notary.reset();
  notary.configure({ endpoint: '', tracePath: '' });
  await seedJournal(2);
  // (a) 纯函数：严格大于阈值才补（50 ⇒ false，51 ⇒ true）；NaN/负数防御；阈值可注入
  assert.equal(shouldAnchor(0), false);
  assert.equal(shouldAnchor(ADAPTIVE_ANCHOR_THRESHOLD), false, '等于阈值不补（严格大于）');
  assert.equal(shouldAnchor(ADAPTIVE_ANCHOR_THRESHOLD + 1), true);
  assert.equal(shouldAnchor(Number.NaN), false, 'NaN ⇒ false（绝不抛）');
  assert.equal(shouldAnchor(6, 5), true, '阈值注入面');
  assert.equal(typeof notaryAutoAnchorIfDue, 'function', '卸载接线面导出在册');

  // (b) 锚后增量 ≤ 阈 ⇒ anchorCadence 如实、无提示
  const a = await notary.anchorOnce({ now: fixedClock, random: makeRandom(0x81) });
  assert.ok(a);
  let r = notary.verifyNotary();
  assert.deepEqual(r.anchorCadence, { entriesSinceLastAnchor: 0, threshold: 50, due: false }, '注记字段如实');
  assert.equal(r.badges['timestamp-anchor'].detail.includes('adaptive-anchor hint'), false, '未超阈 ⇒ 无提示');

  // (c) 增量超阈（2 → 53）⇒ due=true + 章③ detail 补锚提示（quality_checkup notarize
  //     输出的 badges 投影即可见 —— 「在 notarize 旁提示」的最小接线）
  for (let i = 0; i < 51; i++) {
    await journal.append({ ts: 1700000100 + i, tool: 'scroll_page', args: { direction: 'down' }, status: 'SUCCESS' });
  }
  r = notary.verifyNotary();
  assert.deepEqual(r.anchorCadence, { entriesSinceLastAnchor: 51, threshold: 50, due: true }, '增量 51 超阈');
  assert.match(r.badges['timestamp-anchor'].detail, /adaptive-anchor hint \(NO-3\): journal grew 51 entries since the last anchor/,
    '补锚提示随章③ detail 在场');
  assert.equal(r.badges['timestamp-anchor'].status, 'green', '提示不翻章（注记级）');

  // (d) 卸载接线面：开关假 ⇒ 零行为；真且超阈 ⇒ 补铸一枚（fire-and-forget）
  notaryAutoAnchorIfDue({ notaryAutoAnchor: false, notaryEndpoint: '', notaryTracePath: '' });
  assert.equal(notary.anchorCount, 1, '开关假 ⇒ 不铸锚');
  notaryAutoAnchorIfDue({ notaryAutoAnchor: true, notaryEndpoint: '', notaryTracePath: '' });
  await new Promise(resolve_ => setTimeout(resolve_, 20)); // fire-and-forget 落账宽限
  assert.equal(notary.anchorCount, 2, '超阈 ⇒ 卸载路径补铸一枚');
  const after = notary.lastAnchor();
  assert.equal(after?.seq, journal.list(false).length, '补锚覆盖当前 journal 条数（增量归零）');
  // 补锚后增量归零 ⇒ 再触发零行为（幂等不重复铸）
  notaryAutoAnchorIfDue({ notaryAutoAnchor: true, notaryEndpoint: '', notaryTracePath: '' });
  await new Promise(resolve_ => setTimeout(resolve_, 20));
  assert.equal(notary.anchorCount, 2, '增量已归零 ⇒ 不再补铸');
  notaryAutoAnchorIfDue(null); // 防御：null 配置不炸
});
