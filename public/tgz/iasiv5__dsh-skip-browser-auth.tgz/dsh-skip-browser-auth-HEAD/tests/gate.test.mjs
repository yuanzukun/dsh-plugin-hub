// 门控探针与行绑定表达式的真值矩阵 + 真实路径断言（计划 Task 5 Step 1；
// 2026-09-05 事故后探针改为双锚点：宿主 runtime 本体 + 官方 connection 包）。
import test from 'node:test'
import assert from 'node:assert/strict'
import { createRequire } from 'node:module'
import {
  COMPATIBILITY_PROFILES,
  CONNECTION_PACKAGE,
  DESKTOP_HOST_PACKAGE,
  GATE_RUNTIME_PACKAGE,
  GATE_VERSIONS,
  GATE_VERSION,
  GATE_ANCHOR_PACKAGES,
  GATE_PROFILE_EXPRESSION,
  GATE_PROBE_EXPRESSION,
  GATE_ROW_ALLOWED_EXPRESSION,
  GATE_ROW_ALLOWED_EXPRESSION_V4,
  evaluateGate,
  resolveCompatibilityProfile,
} from '../lib/gate.js'
import { writeGateFixtures, dispatchingResolveSync } from './helpers/gate-fixture.mjs'

const ENTRY_KEY = Symbol.for('cordis.entry')

// 与 vendor/loader/src/config/utils.ts 相同的求值语义：with(ctx) + eval。
function evaluateWith(ctx, expr) {
  return new Function('ctx', 'expr', 'with (ctx) { return eval(expr) }')(ctx, expr)
}

// 构造探针 fake ctx：resolveSync 按 specifier 分发到各锚点 fixture。
function probeCtx(urls, { version = 'v2', throwOnResolve = false, withLoader = true } = {}) {
  if (!withLoader) return { baseUrl: 'file:///fake/base/' }
  return {
    baseUrl: 'file:///fake/base/',
    loader: {
      internal: {
        version,
        resolveSync: dispatchingResolveSync(urls, { throwOnResolve }),
      },
    },
  }
}

// 构造行绑定 fake ctx：symbol entry 提供当前 entry，探针走真实 fixture url。
function rowCtx(official, urls, { rootResolve } = {}) {
  const parent = { tree: { resolve: () => official } }
  official.parent = parent
  const ctx = {
    baseUrl: 'file:///fake/base/',
    [ENTRY_KEY]: { parent },
    loader: {
      internal: { version: 'v2', resolveSync: dispatchingResolveSync(urls) },
      ...(rootResolve === 'throws' ? { resolve: () => { throw new Error('root loader resolve must not be used') } } : {}),
    },
  }
  return ctx
}

function officialRow(overrides = {}) {
  return {
    options: { id: 'connection', name: CONNECTION_PACKAGE },
    disabled: true,
    ...overrides,
  }
}

test('gate constants have the pinned profile and anchor values', () => {
  assert.equal(CONNECTION_PACKAGE, '@deepseek-ai/dsh-client-connection')
  assert.equal(GATE_RUNTIME_PACKAGE, '@deepseek-ai/dsh')
  assert.equal(GATE_VERSION, '0.1.2-rc.1')
  assert.deepEqual([...GATE_VERSIONS], ['0.1.2-rc.1', '0.1.5-rc.1', '0.1.5-rc.2', '0.1.7-rc.1', '0.1.7-rc.2', '0.2.0-rc.1', '0.2.0-rc.2', '0.2.1-rc.1', '0.2.1-rc.2'])
  assert.deepEqual(COMPATIBILITY_PROFILES.map(profile => profile.id), ['legacy-web-v1', 'carrier-neutral-v2', 'carrier-neutral-v3', 'carrier-neutral-v4'])
  // 锚点顺序：宿主 runtime 本体在前（版本段即宿主版本），被替换对象在后。
  assert.deepEqual([...GATE_ANCHOR_PACKAGES], ['@deepseek-ai/dsh', '@deepseek-ai/dsh-client-connection'])
  // 宿主 profile 门控（2026-10-07）：desktop 信号包常量与 web-only 策略。
  assert.equal(DESKTOP_HOST_PACKAGE, '@deepseek-ai/dsh-desktop-host')
  for (const profile of COMPATIBILITY_PROFILES) {
    assert.deepEqual([...profile.hostProfiles], ['web'], `profile ${profile.id} must stay web-only`)
  }
})

test('compatibility profiles match complete runtime/connection pairs only', () => {
  assert.equal(resolveCompatibilityProfile('0.1.2-rc.1', '0.1.2-rc.1')?.id, 'legacy-web-v1')
  assert.equal(resolveCompatibilityProfile('0.1.5-rc.1', '0.1.5-rc.1')?.id, 'carrier-neutral-v2')
  assert.equal(resolveCompatibilityProfile('0.1.5-rc.2', '0.1.5-rc.2')?.id, 'carrier-neutral-v2')
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.1', '0.1.7-rc.1')?.id, 'carrier-neutral-v3')
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.2', '0.1.7-rc.2')?.id, 'carrier-neutral-v3')
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.1', '0.2.0-rc.1')?.id, 'carrier-neutral-v3')
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.2', '0.2.0-rc.2')?.id, 'carrier-neutral-v3')
  assert.equal(resolveCompatibilityProfile('0.2.1-rc.1', '0.2.1-rc.1')?.id, 'carrier-neutral-v4')
  assert.equal(resolveCompatibilityProfile('0.2.1-rc.2', '0.2.1-rc.2')?.id, 'carrier-neutral-v4')
  // v4 代际内的跨 patch 混合（0.2.1-rc.1 ↔ 0.2.1-rc.2 任一方向）：字节级同代码
  // 不改判，白名单只认完整版本对（§5.10）。
  assert.equal(resolveCompatibilityProfile('0.2.1-rc.1', '0.2.1-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.1-rc.2', '0.2.1-rc.1'), undefined)
  // 同代际内的跨 patch 版本混合同样是事故形态，必须 dormant。
  assert.equal(resolveCompatibilityProfile('0.1.2-rc.1', '0.1.5-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.5-rc.1', '0.1.2-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.5-rc.1', '0.1.5-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.5-rc.2', '0.1.5-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.1', '0.1.7-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.2', '0.1.7-rc.1'), undefined)
  // v3 代际内的跨 minor 混合（0.1.7 ↔ 0.2.0 任一方向）：字节级同代码不改判，
  // 白名单只认完整版本对。
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.1', '0.2.0-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.2', '0.2.0-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.1', '0.1.7-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.1', '0.1.7-rc.2'), undefined)
  // v3 代际内的跨 patch 混合（0.2.0-rc.1 ↔ 0.2.0-rc.2 任一方向）：字节级同代码
  // 不改判，白名单只认完整版本对（§5.7）。
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.1', '0.2.0-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.2', '0.2.0-rc.1'), undefined)
  // 跨 minor 混合对 rc.2 同样成立（0.1.7 ↔ 0.2.0-rc.2 任一方向）。
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.1', '0.2.0-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.2', '0.2.0-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.2', '0.1.7-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.2', '0.1.7-rc.2'), undefined)
  // 跨代际混合（0.2.0 ↔ 0.2.1-rc.1 任一方向）：0.2.1 是真实契约变化（§5.8），
  // 与 0.2.0 绝不放行混合，白名单只认完整版本对。
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.1', '0.2.1-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.2', '0.2.1-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.1-rc.1', '0.2.0-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.1-rc.1', '0.2.0-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.2', '0.2.1-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.1-rc.1', '0.1.7-rc.2'), undefined)
  // 跨代际混合同理（0.1.5 ↔ 0.1.7/0.2.0 任一方向）。
  assert.equal(resolveCompatibilityProfile('0.1.5-rc.2', '0.1.7-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.2', '0.1.5-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.5-rc.2', '0.1.7-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.7-rc.1', '0.1.5-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('0.1.5-rc.2', '0.2.0-rc.1'), undefined)
  assert.equal(resolveCompatibilityProfile('0.2.0-rc.1', '0.1.5-rc.2'), undefined)
  assert.equal(resolveCompatibilityProfile('9.9.9', '9.9.9'), undefined)
})

test('profile expression recognizes exact pairs and active probes', async (t) => {
  const rc1 = await writeGateFixtures(t, {
    runtimeVersion: '0.1.2-rc.1',
    connectionVersion: '0.1.2-rc.1',
  })
  const rc15 = await writeGateFixtures(t, {
    runtimeVersion: '0.1.5-rc.1',
    connectionVersion: '0.1.5-rc.1',
  })
  const rc152 = await writeGateFixtures(t, {
    runtimeVersion: '0.1.5-rc.2',
    connectionVersion: '0.1.5-rc.2',
  })
  const rc17 = await writeGateFixtures(t, {
    runtimeVersion: '0.1.7-rc.2',
    connectionVersion: '0.1.7-rc.2',
  })
  const rc171 = await writeGateFixtures(t, {
    runtimeVersion: '0.1.7-rc.1',
    connectionVersion: '0.1.7-rc.1',
  })
  const rc20 = await writeGateFixtures(t, {
    runtimeVersion: '0.2.0-rc.1',
    connectionVersion: '0.2.0-rc.1',
  })
  const rc202 = await writeGateFixtures(t, {
    runtimeVersion: '0.2.0-rc.2',
    connectionVersion: '0.2.0-rc.2',
  })
  const rc211 = await writeGateFixtures(t, {
    runtimeVersion: '0.2.1-rc.1',
    connectionVersion: '0.2.1-rc.1',
  })
  const rc212 = await writeGateFixtures(t, {
    runtimeVersion: '0.2.1-rc.2',
    connectionVersion: '0.2.1-rc.2',
  })
  assert.equal(evaluateWith(probeCtx(rc1.urls), GATE_PROFILE_EXPRESSION), 'legacy-web-v1')
  assert.equal(evaluateWith(probeCtx(rc1.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateWith(probeCtx(rc15.urls), GATE_PROFILE_EXPRESSION), 'carrier-neutral-v2')
  assert.equal(evaluateWith(probeCtx(rc15.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateWith(probeCtx(rc152.urls), GATE_PROFILE_EXPRESSION), 'carrier-neutral-v2')
  assert.equal(evaluateWith(probeCtx(rc152.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateWith(probeCtx(rc17.urls), GATE_PROFILE_EXPRESSION), 'carrier-neutral-v3')
  assert.equal(evaluateWith(probeCtx(rc17.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateWith(probeCtx(rc171.urls), GATE_PROFILE_EXPRESSION), 'carrier-neutral-v3')
  assert.equal(evaluateWith(probeCtx(rc171.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateWith(probeCtx(rc20.urls), GATE_PROFILE_EXPRESSION), 'carrier-neutral-v3')
  assert.equal(evaluateWith(probeCtx(rc20.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateWith(probeCtx(rc202.urls), GATE_PROFILE_EXPRESSION), 'carrier-neutral-v3')
  assert.equal(evaluateWith(probeCtx(rc202.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateWith(probeCtx(rc211.urls), GATE_PROFILE_EXPRESSION), 'carrier-neutral-v4')
  assert.equal(evaluateWith(probeCtx(rc211.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateWith(probeCtx(rc212.urls), GATE_PROFILE_EXPRESSION), 'carrier-neutral-v4')
  assert.equal(evaluateWith(probeCtx(rc212.urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateGate(probeCtx(rc17.urls)), true)
  assert.equal(evaluateGate(probeCtx(rc171.urls)), true)
  assert.equal(evaluateGate(probeCtx(rc20.urls)), true)
  assert.equal(evaluateGate(probeCtx(rc202.urls)), true)
  assert.equal(evaluateGate(probeCtx(rc211.urls)), true)
  assert.equal(evaluateGate(probeCtx(rc212.urls)), true)
})

test('profile expression rejects mixed and unknown pairs', async (t) => {
  const mixed = await writeGateFixtures(t, {
    runtimeVersion: '0.1.2-rc.1',
    connectionVersion: '0.1.5-rc.1',
  })
  const crossPatch = await writeGateFixtures(t, {
    runtimeVersion: '0.1.5-rc.1',
    connectionVersion: '0.1.5-rc.2',
  })
  const crossGeneration = await writeGateFixtures(t, {
    runtimeVersion: '0.1.7-rc.2',
    connectionVersion: '0.1.5-rc.2',
  })
  // v3 代际内的跨 patch 混合（rc.1 ↔ rc.2 任一方向）同样是事故形态。
  const crossPatch17 = await writeGateFixtures(t, {
    runtimeVersion: '0.1.7-rc.1',
    connectionVersion: '0.1.7-rc.2',
  })
  const crossPatch17Reverse = await writeGateFixtures(t, {
    runtimeVersion: '0.1.7-rc.2',
    connectionVersion: '0.1.7-rc.1',
  })
  // v3 代际内的跨 minor 混合（0.1.7 ↔ 0.2.0 任一方向）同样是事故形态。
  const crossMinor = await writeGateFixtures(t, {
    runtimeVersion: '0.1.7-rc.2',
    connectionVersion: '0.2.0-rc.1',
  })
  const crossMinorReverse = await writeGateFixtures(t, {
    runtimeVersion: '0.2.0-rc.1',
    connectionVersion: '0.1.7-rc.2',
  })
  // v3 代际内的跨 patch 混合（0.2.0-rc.1 ↔ 0.2.0-rc.2 任一方向）同样是事故形态。
  const crossPatch20 = await writeGateFixtures(t, {
    runtimeVersion: '0.2.0-rc.1',
    connectionVersion: '0.2.0-rc.2',
  })
  const crossPatch20Reverse = await writeGateFixtures(t, {
    runtimeVersion: '0.2.0-rc.2',
    connectionVersion: '0.2.0-rc.1',
  })
  // 跨代际混合（0.2.0 ↔ 0.2.1-rc.1 任一方向）：§5.8 定谳的真实契约变化，
  // 混合对必须 dormant（carrier-neutral-v3 与 v4 绝不混跑）。
  const crossGeneration21 = await writeGateFixtures(t, {
    runtimeVersion: '0.2.0-rc.2',
    connectionVersion: '0.2.1-rc.1',
  })
  const crossGeneration21Reverse = await writeGateFixtures(t, {
    runtimeVersion: '0.2.1-rc.1',
    connectionVersion: '0.2.0-rc.2',
  })
  // v4 代际内的跨 patch 混合（0.2.1-rc.1 ↔ 0.2.1-rc.2 任一方向）同样是事故形态。
  const crossPatch21 = await writeGateFixtures(t, {
    runtimeVersion: '0.2.1-rc.1',
    connectionVersion: '0.2.1-rc.2',
  })
  const crossPatch21Reverse = await writeGateFixtures(t, {
    runtimeVersion: '0.2.1-rc.2',
    connectionVersion: '0.2.1-rc.1',
  })
  const unknown = await writeGateFixtures(t, {
    runtimeVersion: '9.9.9',
    connectionVersion: '9.9.9',
  })
  assert.equal(evaluateWith(probeCtx(mixed.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(mixed.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossPatch.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossPatch.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossGeneration.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossGeneration.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossPatch17.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossPatch17.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossPatch17Reverse.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossPatch17Reverse.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossMinor.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossMinor.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossMinorReverse.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossMinorReverse.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossPatch20.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossPatch20.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossPatch20Reverse.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossPatch20Reverse.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossGeneration21.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossGeneration21.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossGeneration21Reverse.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossGeneration21Reverse.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossPatch21.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossPatch21.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(crossPatch21Reverse.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(crossPatch21Reverse.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(unknown.urls), GATE_PROFILE_EXPRESSION), null)
  assert.equal(evaluateWith(probeCtx(unknown.urls), GATE_PROBE_EXPRESSION), false)
})

test('probe accepts the whitelisted pnpm version segments on both anchors (v2 form)', async (t) => {
  const { urls } = await writeGateFixtures(t)
  assert.equal(evaluateWith(probeCtx(urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateGate(probeCtx(urls)), true) // evaluateGate 求值同一探针
})

test('probe rejects a bundled rc.1 connection on a 0.1.1-rc.2 host (the 2026-09-05 incident)', async (t) => {
  // 事故形态：插件自带（或 profile 抬升）的 connection 副本是真实 0.1.2-rc.1，
  // 但宿主 runtime 本体是 0.1.1-rc.2。旧探针据此自我满足并禁用官方行；
  // 修复后 runtime 锚点必须否决。
  const { urls } = await writeGateFixtures(t, {
    runtimeVersion: '0.1.1-rc.2',
    connectionVersion: GATE_VERSION,
  })
  assert.equal(evaluateWith(probeCtx(urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateGate(probeCtx(urls)), false)
})

test('probe rejects per-anchor version drift in either direction', async (t) => {
  const runtimeDrift = await writeGateFixtures(t, {
    runtimeVersion: '9.9.9',
    connectionVersion: GATE_VERSION,
  })
  const connectionDrift = await writeGateFixtures(t, {
    runtimeVersion: GATE_VERSION,
    connectionVersion: '0.1.1-rc.2',
  })
  const bothDrift = await writeGateFixtures(t, { runtimeVersion: '9.9.9', connectionVersion: '9.9.9' })
  assert.equal(evaluateWith(probeCtx(runtimeDrift.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(connectionDrift.urls), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(bothDrift.urls), GATE_PROBE_EXPRESSION), false)
})

test('probe rejects manifest drift under a whitelisted path segment', async (t) => {
  const { urls } = await writeGateFixtures(t, {
    runtimeVersion: { segment: GATE_VERSION, manifest: '9.9.9' },
  })
  // 路径段全对、runtime manifest 漂移：段分支短路放行（不读 manifest）；
  // 该漂移由 apply 内 backstop 读 manifest 兜底（见 host-apply.test.mjs）。
  assert.equal(evaluateWith(probeCtx(urls), GATE_PROBE_EXPRESSION), true)
  const connectionManifestDrift = await writeGateFixtures(t, {
    connectionVersion: { segment: GATE_VERSION, manifest: '9.9.9' },
  })
  assert.equal(evaluateWith(probeCtx(connectionManifestDrift.urls), GATE_PROBE_EXPRESSION), true)
})

test('probe rejects an npm layout without a version segment (non-file URLs, nothing to read)', async (t) => {
  const urls = {
    [`${GATE_RUNTIME_PACKAGE}/package.json`]: 'file:///repo/node_modules/@deepseek-ai/dsh/package.json',
    [`${CONNECTION_PACKAGE}/package.json`]: 'file:///repo/node_modules/@deepseek-ai/dsh-client-connection/package.json',
  }
  assert.equal(evaluateWith(probeCtx(urls), GATE_PROBE_EXPRESSION), false)
})

test('probe accepts npm flat layouts via the manifest fallback (dshm deployments)', async (t) => {
  // dshm 以 npm 语义落地：真实目录、URL 无版本段、manifest 版本 0.1.2-rc.1。
  const { urls } = await writeGateFixtures(t, { layout: 'npm' })
  assert.equal(evaluateWith(probeCtx(urls), GATE_PROBE_EXPRESSION), true)
  assert.equal(evaluateGate(probeCtx(urls)), true)
})

test('probe rejects npm flat layouts whose manifests drift off the whitelist', async (t) => {
  // npm 布局下的事故形态：宿主 rc.2 + 连接 rc.1 → runtime 锚点否决。
  const oldHost = await writeGateFixtures(t, {
    layout: 'npm',
    runtimeVersion: '0.1.1-rc.2',
    connectionVersion: GATE_VERSION,
  })
  assert.equal(evaluateWith(probeCtx(oldHost.urls), GATE_PROBE_EXPRESSION), false)
  // 连接锚点漂移同理。
  const drifted = await writeGateFixtures(t, {
    layout: 'npm',
    runtimeVersion: GATE_VERSION,
    connectionVersion: '9.9.9',
  })
  assert.equal(evaluateWith(probeCtx(drifted.urls), GATE_PROBE_EXPRESSION), false)
})

test('probe manifest fallback fails closed on unreadable or malformed manifests', async (t) => {
  const { writeFile } = await import('node:fs/promises')
  const runtimeKey = `${GATE_RUNTIME_PACKAGE}/package.json`
  const connectionKey = `${CONNECTION_PACKAGE}/package.json`
  // 指向不存在的文件：readFileSync 抛出 → dormant。
  const missing = await writeGateFixtures(t, { layout: 'npm' })
  const missingUrls = {
    [runtimeKey]: `${missing.tmp}/npm-flat/absent/@deepseek-ai/dsh/package.json`,
    [connectionKey]: missing.urls[connectionKey],
  }
  assert.equal(evaluateWith(probeCtx(missingUrls), GATE_PROBE_EXPRESSION), false)
  // manifest 是非法 JSON：JSON.parse 抛出 → dormant。
  const malformed = await writeGateFixtures(t, { layout: 'npm' })
  await writeFile(`${malformed.tmp}/npm-flat/node_modules/@deepseek-ai/dsh/package.json`, '{not json', 'utf8')
  assert.equal(evaluateWith(probeCtx(malformed.urls), GATE_PROBE_EXPRESSION), false)
})

test('probe manifest fallback requires process.getBuiltinModule (fail-closed without it)', async (t) => {
  const { urls } = await writeGateFixtures(t, { layout: 'npm' })
  const original = process.getBuiltinModule
  try {
    // 模拟 Node <22.3：getBuiltinModule 不可用 → 无法同步读 manifest → dormant。
    delete process.getBuiltinModule
    assert.equal(evaluateWith(probeCtx(urls), GATE_PROBE_EXPRESSION), false)
  } finally {
    process.getBuiltinModule = original
  }
})

test('probe keeps the documented path-segment precedence: segment mismatch is not rescued by the manifest', async (t) => {
  // pnpm 段 9.9.9、盘上 manifest 是白名单版本：段分支短路判否，不读 manifest
  // 救援（与 README 行为矩阵一致：manifest 漂移只在段真时由 backstop 兜底）。
  const { urls } = await writeGateFixtures(t, {
    connectionVersion: { segment: '9.9.9', manifest: GATE_VERSION },
  })
  assert.equal(evaluateWith(probeCtx(urls), GATE_PROBE_EXPRESSION), false)
})

test('probe also works in the v1 resolveSync form', async (t) => {
  const { urls } = await writeGateFixtures(t)
  assert.equal(evaluateWith(probeCtx(urls, { version: 'v1' }), GATE_PROBE_EXPRESSION), true)
})

test('probe fails closed when loader/internal is missing, resolveSync throws, or url is not a string', async (t) => {
  const { urls } = await writeGateFixtures(t)
  assert.equal(evaluateWith(probeCtx(urls, { withLoader: false }), GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith({ baseUrl: 'file:///fake/base/', loader: {} }, GATE_PROBE_EXPRESSION), false)
  assert.equal(evaluateWith(probeCtx(urls, { throwOnResolve: true }), GATE_PROBE_EXPRESSION), false)
  const badUrlCtx = probeCtx(urls)
  badUrlCtx.loader.internal.resolveSync = () => ({ url: 42 })
  assert.equal(evaluateWith(badUrlCtx, GATE_PROBE_EXPRESSION), false)
})

test('probe fails closed when any anchor does not resolve (missing runtime fallback)', async (t) => {
  const { urls } = await writeGateFixtures(t)
  // runtime 锚点解析不到（如过旧宿主无 fallback、或非 pnpm 布局）→ dormant。
  const connectionKey = `${CONNECTION_PACKAGE}/package.json`
  const withoutRuntime = { [connectionKey]: urls[connectionKey] }
  assert.equal(evaluateWith(probeCtx(withoutRuntime), GATE_PROBE_EXPRESSION), false)
  // connection 锚点解析不到同理。
  const runtimeKey = `${GATE_RUNTIME_PACKAGE}/package.json`
  const withoutConnection = { [runtimeKey]: urls[runtimeKey] }
  assert.equal(evaluateWith(probeCtx(withoutConnection), GATE_PROBE_EXPRESSION), false)
})

test('row gate passes only for a same-group, name-matching, disabled official row with a true probe', async (t) => {
  const { urls } = await writeGateFixtures(t)
  const ctx = rowCtx(officialRow(), urls)
  assert.equal(evaluateWith(ctx, GATE_ROW_ALLOWED_EXPRESSION), true)
})

test('row gate fails when the official row is not disabled (even with a correct name)', async (t) => {
  const { urls } = await writeGateFixtures(t)
  const ctx = rowCtx(officialRow({ disabled: false }), urls)
  assert.equal(evaluateWith(ctx, GATE_ROW_ALLOWED_EXPRESSION), false)
})

test('row gate fails on a sibling name mismatch', async (t) => {
  const { urls } = await writeGateFixtures(t)
  const ctx = rowCtx(officialRow({ options: { id: 'connection', name: '@deepseek-ai/dsh-client-connection-wrong' } }), urls)
  assert.equal(evaluateWith(ctx, GATE_ROW_ALLOWED_EXPRESSION), false)
})

test('row gate fails when the sibling row does not exist (resolve throws)', async (t) => {
  const { urls } = await writeGateFixtures(t)
  const parent = { tree: { resolve: () => { throw new Error('cannot resolve entry connection') } } }
  const ctx = {
    baseUrl: 'file:///fake/base/',
    [ENTRY_KEY]: { parent },
    loader: { internal: { version: 'v2', resolveSync: dispatchingResolveSync(urls) } },
  }
  assert.equal(evaluateWith(ctx, GATE_ROW_ALLOWED_EXPRESSION), false)
})

test('row gate fails for a same-name row in another group (official.parent !== self.parent)', async (t) => {
  const { urls } = await writeGateFixtures(t)
  const official = officialRow()
  official.parent = { tree: { resolve: () => official } } // 官方行登记在另一个组
  const selfParent = { tree: { resolve: () => official } } // self 所在组解析到的却是那一行
  const ctx = {
    baseUrl: 'file:///fake/base/',
    [ENTRY_KEY]: { parent: selfParent },
    loader: { internal: { version: 'v2', resolveSync: dispatchingResolveSync(urls) } },
  }
  assert.equal(evaluateWith(ctx, GATE_ROW_ALLOWED_EXPRESSION), false)
})

test('row gate stays dormant when the probe is false even if a later layer forced disabled: true', async (t) => {
  // 事故形态的组合期投影：connection 路径段/版本对、官方行被（后续层）强制
  // disabled，但宿主 runtime 是 0.1.1-rc.2 → 行绑定内嵌探针必须否决。
  const { urls } = await writeGateFixtures(t, {
    runtimeVersion: '0.1.1-rc.2',
    connectionVersion: GATE_VERSION,
  })
  const ctx = rowCtx(officialRow({ disabled: true }), urls)
  assert.equal(evaluateWith(ctx, GATE_ROW_ALLOWED_EXPRESSION), false)
})

test('row gate does not depend on the root Loader resolve', async (t) => {
  const { urls } = await writeGateFixtures(t)
  // 根 Loader resolve 抛错（或不存在）时，symbol 路径仍完整判定。
  const okCtx = rowCtx(officialRow(), urls, { rootResolve: 'throws' })
  assert.equal(evaluateWith(okCtx, GATE_ROW_ALLOWED_EXPRESSION), true)
  const dormantCtx = rowCtx(officialRow({ disabled: false }), urls, { rootResolve: 'throws' })
  assert.equal(evaluateWith(dormantCtx, GATE_ROW_ALLOWED_EXPRESSION), false)
  const noRootResolveCtx = rowCtx(officialRow(), urls)
  delete noRootResolveCtx.loader.resolve
  assert.equal(evaluateWith(noRootResolveCtx, GATE_ROW_ALLOWED_EXPRESSION), true)
})

test('row bindings partition generations: the legacy row never fires on a v4 pair and vice versa', async (t) => {
  // §5.9 两行拆分的不变量：同一 pair fixture 上，webRuntime 行（≤0.2.0）与
  // webStartup 行（0.2.1+）的放行集合必须互斥——0.2.1 宿主上旧行若放行，其
  // inject 的 webRuntime 服务在上游已不存在。
  const v3Pair = await writeGateFixtures(t, {
    runtimeVersion: '0.2.0-rc.2',
    connectionVersion: '0.2.0-rc.2',
  })
  const v4Pair = await writeGateFixtures(t, {
    runtimeVersion: '0.2.1-rc.1',
    connectionVersion: '0.2.1-rc.1',
  })
  // v3 pair：旧行放行、v4 行拒绝。
  const legacyOnV3 = rowCtx(officialRow(), v3Pair.urls)
  assert.equal(evaluateWith(legacyOnV3, GATE_ROW_ALLOWED_EXPRESSION), true)
  assert.equal(evaluateWith(legacyOnV3, GATE_ROW_ALLOWED_EXPRESSION_V4), false)
  // v4 pair：v4 行放行、旧行拒绝。
  const v4OnV4 = rowCtx(officialRow(), v4Pair.urls)
  assert.equal(evaluateWith(v4OnV4, GATE_ROW_ALLOWED_EXPRESSION_V4), true)
  assert.equal(evaluateWith(v4OnV4, GATE_ROW_ALLOWED_EXPRESSION), false)
  // 更早代际（0.1.x）：v4 行一律拒绝。
  const legacyV2 = await writeGateFixtures(t, {
    runtimeVersion: '0.1.7-rc.2',
    connectionVersion: '0.1.7-rc.2',
  })
  const earlyCtx = rowCtx(officialRow(), legacyV2.urls)
  assert.equal(evaluateWith(earlyCtx, GATE_ROW_ALLOWED_EXPRESSION), true)
  assert.equal(evaluateWith(earlyCtx, GATE_ROW_ALLOWED_EXPRESSION_V4), false)
})

test('real installed layout resolves through a pnpm version segment (pnpm-only; Task 11 covers the real machine)', (t) => {
  const require = createRequire(import.meta.url)
  let manifestUrl
  try {
    manifestUrl = require.resolve('@deepseek-ai/dsh-client-connection/package.json')
  } catch {
    t.skip('dependency not resolvable from the test workspace')
    return
  }
  if (!/@deepseek-ai\+dsh-client-connection@0\.1\.2-rc\.1_/.test(manifestUrl)) {
    t.skip(`non-pnpm layout: ${manifestUrl}`)
    return
  }
  assert.match(manifestUrl, /@deepseek-ai\+dsh-client-connection@0\.1\.2-rc\.1_/)
})

test('published manifest pollution invariant: the repo itself must not resolve @deepseek-ai/dsh', () => {
  // 探针第一锚点只可能来自 runtime fallback。若本仓库（devDependencies 之外）
  // 能解析到 @deepseek-ai/dsh，链接安装/开发环境就会重新引入自我满足风险。
  const require = createRequire(import.meta.url)
  let resolved = null
  try {
    resolved = require.resolve('@deepseek-ai/dsh/package.json')
  } catch {}
  assert.equal(resolved, null, `@deepseek-ai/dsh must not be resolvable from the plugin tree, got ${String(resolved)}`)
})

// —— host profile 门控（web-only / desktop 休眠，2026-10-07 任务书 §2）——
// desktop specifier 在本组用例中硬编码：实现前先红（Task 2），常量值由「gate
// constants」用例在实现任务中钉住，避免用例间循环依赖。
const DESKTOP_SPECIFIER = '@deepseek-ai/dsh-desktop-host/package.json'

// 包装 resolveSync：仅拦截 desktop specifier 的返回/抛错，其余走按 specifier 分发的 fake。
function interceptDesktop(ctx, intercept) {
  const base = ctx.loader.internal.resolveSync
  ctx.loader.internal.resolveSync = (...args) => {
    const specifier = typeof args[1] === 'object' ? args[1].specifier : args[0]
    if (specifier === DESKTOP_SPECIFIER) return intercept()
    return base(...args)
  }
  return ctx
}

test('desktop-host present on a whitelisted pair forces the probe dormant', async (t) => {
  const { urls } = await writeGateFixtures(t, { desktopHost: true })
  assert.equal(evaluateGate(probeCtx(urls)), false)
  assert.equal(evaluateWith(probeCtx(urls), GATE_PROFILE_EXPRESSION), null)
})

test('desktop-host absent keeps web behavior (resolver returns null treated as absent)', async (t) => {
  const { urls } = await writeGateFixtures(t)
  assert.equal(evaluateGate(probeCtx(urls)), true)
})

test('desktop-host lookup throwing is treated as absent (web continues)', async (t) => {
  const { urls } = await writeGateFixtures(t)
  const ctx = interceptDesktop(probeCtx(urls), () => { throw new Error('desktop lookup boom') })
  assert.equal(evaluateGate(ctx), true)
})

test('desktop-host resolving to a non-string url is treated as absent', async (t) => {
  const { urls } = await writeGateFixtures(t)
  const ctx = interceptDesktop(probeCtx(urls), () => ({ url: 123 }))
  assert.equal(evaluateGate(ctx), true)
})

test('desktop launcher argv forces the probe dormant even when the package is unreachable', async (t) => {
  // 2026-10-08 0.3.8 事故修复：desktop profile 为 hoisted 布局，dsh-desktop-host
  // 只在 app.asar 内、自 ctx.baseUrl 不可达（0.3.6 据此误判 web 并在 desktop 激活）。
  // 但 desktop 宿主进程 argv 恒带 dsh-desktop-host 入口脚本（官方
  // isPackagedDesktopArgv 同款 launcher fact）——本用例注入 ctx.process 模拟
  // Windows 宿主 argv（反斜杠路径），desktop-host 包不注册（= 不可达）。
  const { urls } = await writeGateFixtures(t)
  const ctx = probeCtx(urls)
  ctx.process = {
    execPath: 'C:\\Program Files\\nodejs\\node.exe',
    argv: [
      'C:\\Users\\ies\\AppData\\Local\\Programs\\deepseek\\DeepSeek Harness.exe',
      'C:\\Users\\ies\\AppData\\Local\\Programs\\deepseek\\resources\\app.asar\\node_modules\\@deepseek-ai\\dsh-desktop-host\\lib\\index.js',
      'C:\\Users\\ies\\AppData\\Local\\Programs\\deepseek\\resources\\dsh',
      'C:\\Users\\ies\\.dsh\\profiles\\desktop',
    ],
  }
  assert.equal(evaluateGate(ctx), false)
  assert.equal(evaluateWith(ctx, GATE_PROFILE_EXPRESSION), null)
})

test('non-node host binary fails the web proof and stays dormant (default-deny)', async (t) => {
  // 2026-10-08 融合：激活需要正向 web 证明——宿主二进制基名必须为 node/node.exe。
  // desktop 变体即便改名启动器（argv 无 dsh-desktop-host），Electron run-as-node
  // 的 execPath 也非 node ⇒ 休眠（0.3.6 事故形态的 unknown-variant 兜底）。
  const { urls } = await writeGateFixtures(t)
  const ctx = probeCtx(urls)
  ctx.process = {
    execPath: 'C:\\Users\\ies\\AppData\\Local\\Programs\\deepseek\\DeepSeek Harness.exe',
    argv: ['C:\\Users\\ies\\.dsh\\profiles\\desktop'],
  }
  assert.equal(evaluateGate(ctx), false)
  assert.equal(evaluateWith(ctx, GATE_PROFILE_EXPRESSION), null)
})

test('host argv without the desktop launcher stays web (web runtime zero-change guard)', async (t) => {
  // 不注入 ctx.process：bare process 落回测试运行器全局（argv 无 dsh-desktop-host）。
  // 显式钉住：web 侧宿主进程 argv 不触发 desktop 判别，行为与 0.3.6 逐字节一致。
  const { urls } = await writeGateFixtures(t)
  assert.equal(evaluateGate(probeCtx(urls)), true)
})

test('web proof accepts node binaries across Windows/macOS/Linux shapes', async (t) => {
  // 跨平台矩阵（Windows/macOS/Linux × web）：execPath 基名大小写归一后 ∈
  // {node, node.exe, nodejs, nodejs.exe} ⇒ 正向 web 证明成立，正常激活。
  const shapes = [
    ['/usr/bin/node', 'linux systemd/web'],
    ['/home/u/.nvm/versions/node/v22.19.0/bin/node', 'linux nvm'],
    ['/opt/homebrew/bin/node', 'macOS homebrew'],
    ['/usr/local/bin/nodejs', 'linux debian legacy alias'],
    ['C:\\Program Files\\nodejs\\node.exe', 'windows system'],
    ['C:\\Users\\ies\\AppData\\Roaming\\nvm\\v22.19.0\\node.exe', 'windows nvm-windows'],
  ]
  for (const [execPath, label] of shapes) {
    const { urls } = await writeGateFixtures(t)
    const ctx = probeCtx(urls)
    ctx.process = { execPath, argv: [execPath, '/x/entry.js'] }
    assert.equal(evaluateGate(ctx), true, `web proof failed for ${label}: ${execPath}`)
  }
})

test('desktop execPath binaries across platforms fail the web proof', async (t) => {
  // desktop 三平台宿主二进制（Electron run-as-node）恒非 node 系 ⇒ 休眠。
  const shapes = [
    ['C:\\Users\\ies\\AppData\\Local\\Programs\\deepseek\\DeepSeek Harness.exe', 'windows'],
    ['/Applications/DeepSeek.app/Contents/MacOS/DeepSeek Harness', 'macOS'],
    ['/opt/deepseek-harness/deepseek-harness', 'linux'],
  ]
  for (const [execPath, label] of shapes) {
    const { urls } = await writeGateFixtures(t)
    const ctx = probeCtx(urls)
    ctx.process = { execPath, argv: [execPath, '/x/profiles/desktop'] }
    assert.equal(evaluateGate(ctx), false, `desktop binary not denied for ${label}: ${execPath}`)
  }
})

test('grandchild node loader on the desktop slot stays dormant (2026-10-07/08 incident shape)', async (t) => {
  // 0.3.9 事故修复：desktop 宿主为多进程树（Electron main → dsh-desktop-host →
  // 纯 node 子进程跑 loader），0.3.8 的 argv/execPath 信号瞄错进程层双双落空。
  // 槽位判别：ctx.baseUrl 目录基名 === 'desktop'（官方客户端恒用 desktop 槽位）
  // ⇒ 无论宿主进程树形状如何，一律休眠。本用例完整复刻事故形态：
  // 纯 node execPath + 无 dsh-desktop-host 的 argv + desktop 槽位 + 白名单 pair。
  const { urls } = await writeGateFixtures(t, { runtimeVersion: '0.2.0-rc.2', connectionVersion: '0.2.0-rc.2' })
  const ctx = probeCtx(urls)
  ctx.baseUrl = 'file:///C:/Users/ies/.dsh/profiles/desktop/'
  ctx.process = {
    execPath: 'C:\\Program Files\\nodejs\\node.exe',
    argv: ['C:\\Program Files\\nodejs\\node.exe', 'C:\\x\\resources\\dsh', 'C:\\Users\\ies\\.dsh\\profiles\\desktop'],
  }
  assert.equal(evaluateGate(ctx), false)
  assert.equal(evaluateWith(ctx, GATE_PROFILE_EXPRESSION), null)
})

test('web and headless slots keep activating with a node host (slot matrix)', async (t) => {
  for (const base of ['file:///home/ubuntu/.dsh/profiles/web/', 'file:///home/u/.dsh/profiles/headless/']) {
    const { urls } = await writeGateFixtures(t)
    const ctx = probeCtx(urls)
    ctx.baseUrl = base
    ctx.process = { execPath: '/usr/bin/node', argv: ['/usr/bin/node', '/x/dsh'] }
    assert.equal(evaluateGate(ctx), true, `slot ${base} must stay active with a node host`)
  }
})

test('desktop resolver THROWING on the desktop-host specifier stays dormant (0.3.8-0.3.10 incident regression)', async (t) => {
  // 2026-10-08 真机实证（gate-probe ENV）：desktop 的 resolver 对 dsh-desktop-host
  // 抛 "Cannot find package"（web 机返回 null）——0.3.8-0.3.10 的共享 try 结构下，
  // 信号①的 throw 直接跳到 catch 并落 'web'，跳过信号②②′③ ⇒ desktop 误激活。
  // 本用例完整复刻真机形态：resolver 对 desktop-host 抛错 + 宿主 argv 恒带
  // dsh-desktop-host + desktop 槽位 + Electron execPath + 白名单 pair (0.2.0-rc.2)。
  const { urls } = await writeGateFixtures(t, { runtimeVersion: '0.2.0-rc.2', connectionVersion: '0.2.0-rc.2' })
  const ctx = probeCtx(urls)
  ctx.baseUrl = 'file:///C:/Users/ies/.dsh/profiles/desktop/'
  ctx.process = {
    execPath: 'C:\\Users\\ies\\AppData\\Local\\Programs\\DeepSeek Harness\\DeepSeek Harness.exe',
    argv: [
      'C:\\Users\\ies\\AppData\\Local\\Programs\\DeepSeek Harness\\DeepSeek Harness.exe',
      'C:\\Users\\ies\\AppData\\Local\\Programs\\DeepSeek Harness\\resources\\app.asar\\dsh\\node_modules\\@deepseek-ai\\dsh-desktop-host\\lib\\index.js',
      'C:\\Users\\ies\\AppData\\Local\\Programs\\DeepSeek Harness\\resources\\app.asar\\dsh',
      'C:\\Users\\ies\\.dsh\\profiles\\desktop',
    ],
  }
  ctx.loader.internal.resolveSync = (base, request) => {
    const specifier = typeof request === 'string' ? request : request.specifier
    if (specifier === '@deepseek-ai/dsh-desktop-host/package.json') {
      throw new Error("Cannot find package '@deepseek-ai/dsh-desktop-host' imported from 'C:\\Users\\ies\\.dsh\\profiles\\desktop\\'")
    }
    if (specifier === '@deepseek-ai/dsh/package.json') return { url: urls['@deepseek-ai/dsh/package.json'] }
    if (specifier === '@deepseek-ai/dsh-client-connection/package.json') return { url: urls['@deepseek-ai/dsh-client-connection/package.json'] }
    return null
  }
  assert.equal(evaluateGate(ctx), false)
  assert.equal(evaluateWith(ctx, GATE_PROFILE_EXPRESSION), null)
})

test('signal isolation: each desktop signal failing or throwing leaves the others decisive', async (t) => {
  // argv 无标记 + 槽位非 desktop + desktop-host 抛错，但 execPath 非 node
  // ⇒ 信号③（default-deny）独立生效 ⇒ 休眠。
  const { urls } = await writeGateFixtures(t)
  const ctx = probeCtx(urls)
  ctx.baseUrl = 'file:///home/u/.dsh/profiles/web/'
  ctx.process = { execPath: '/opt/deepseek-harness/deepseek-harness', argv: ['/opt/deepseek-harness/deepseek-harness', '/x/entry.js'] }
  const base = ctx.loader.internal.resolveSync.bind(ctx.loader.internal)
  ctx.loader.internal.resolveSync = (...args) => {
    const specifier = typeof args[1] === 'object' ? args[1].specifier : args[0]
    if (specifier === '@deepseek-ai/dsh-desktop-host/package.json') throw new Error('boom')
    return base(...args)
  }
  assert.equal(evaluateGate(ctx), false)
})
