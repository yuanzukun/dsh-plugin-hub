# Compatibility Profile 审计与扩展指南

本文件记录 DSH Skip Browser Auth 的版本兼容性决策。它回答两个问题：

1. 某个 DSH 版本能否安全激活 BrowserAuth Replacement？
2. 新版本是加入现有兼容代际，还是必须新增 host/client 分支？

## 1. 0.1.2 与 0.1.5 的 GitHub 审计

审计对象：

- [DeepSeek Harness v0.1.5-rc.1 release notes](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.1.5-rc.1)
- [v0.1.2-rc.1 → v0.1.5-rc.1 compare](https://github.com/deepseek-ai/deepseek-harness/compare/dsh-v0.1.2-rc.1...dsh-v0.1.5-rc.1)
- [0.1.2 connection/index.ts](https://raw.githubusercontent.com/deepseek-ai/deepseek-harness/dsh-v0.1.2-rc.1/packages/client/connection/src/index.ts)
- [0.1.5 connection/index.ts](https://raw.githubusercontent.com/deepseek-ai/deepseek-harness/dsh-v0.1.5-rc.1/packages/client/connection/src/index.ts)
- [0.1.2 connection/rpc-host.ts](https://raw.githubusercontent.com/deepseek-ai/deepseek-harness/dsh-v0.1.2-rc.1/packages/client/connection/src/rpc-host.ts)
- [0.1.5 connection/rpc-host.ts](https://raw.githubusercontent.com/deepseek-ai/deepseek-harness/dsh-v0.1.5-rc.1/packages/client/connection/src/rpc-host.ts)
- [Discussion #6105：`connection.rpc.handle()` 405](https://github.com/deepseek-ai/deepseek-harness/discussions/6105)
- [Discussion #6111：dedicated channels never register](https://github.com/deepseek-ai/deepseek-harness/discussions/6111)

### 1.1 API 差异

| 维度 | `0.1.2-rc.1` | `0.1.5-rc.1` | 对本插件的影响 |
| --- | --- | --- | --- |
| Connection 注入 | `webServer` + `credentials` | Connection 行只注入 `credentials`，Web carrier 通过 `ctx.inject(['webServer'])` | 不能共用旧版 DI 假设 |
| HostConnectionService | 旧版 HTTP `/api` carrier | carrier-neutral registry | 必须按 profile 加载 runtime module |
| Fetch route | GET/HEAD exact route | 增加 POST、`requestBody`、`requestBodyMode` | 旧 buffered bridge 不能完整表达 0.1.5 |
| Generic RPC | `rpc.handle()` 旧 route 语义 | `rpc.handle()` 可能因 owner context 缺 webServer 返回 405 | carrier-neutral adapter 绑定 carrier owner |
| Browser client | rc12 bundle | rc15 bundle 增加 recovery config/global | 不能 re-ID 旧 bundle 冒充新 bundle |
| 其它开发者 API | 旧版 contracts | Session V3、Session lifecycle、Agent/Inbox/Web panel 等变更 | 本插件只声明 Connection replacement 范围 |

**判断**：`0.1.5-rc.1` 不能直接加入旧版单一 adapter。它必须拥有独立 profile、host adapter 和 client variant。

## 2. Profile 数据模型

单一事实源在 `src/compatibility.ts`：

```ts
const COMPATIBILITY_PROFILES = [
  {
    id: 'legacy-web-v1',
    pairs: [{ runtime: '0.1.2-rc.1', connection: '0.1.2-rc.1' }],
    hostAdapter: 'legacy-web',
    clientVariant: 'rc12',
    requiresRecoveryGlobal: false,
    hostProfiles: ['web'],
    status: 'active',
  },
  {
    id: 'carrier-neutral-v2',
    pairs: [
      { runtime: '0.1.5-rc.1', connection: '0.1.5-rc.1' },
      { runtime: '0.1.5-rc.2', connection: '0.1.5-rc.2' },
    ],
    hostAdapter: 'carrier-neutral',
    clientVariant: 'rc15',
    requiresRecoveryGlobal: true,
    hostProfiles: ['web'],
    status: 'active',
  },
] as const
```

实现细节：

- `pairs` 是完整 runtime/connection 版本对；不能拆成两个独立集合。
- `GATE_VERSIONS` 只用于诊断/文档和旧内部 fixture 兼容，不是 profile 选择逻辑。
- `GATE_PROFILE_EXPRESSION` 返回 profile id 或 `null`。
- `GATE_PROBE_EXPRESSION` 只对 `status: 'active'` 的 profile 返回 true。
- patch 把 profile id 传给插件行；host backstop 再以 manifest 验证一遍。
- host 通过 `__DSH_SKIP_BROWSER_AUTH_PROFILE__` 把同一个 profile id 传给 client dispatcher。
- `hostProfiles`：允许激活的宿主 profile 集合，当前恒为 `['web']`（web-only）；探针表达式与 apply backstop 双层校验，语义见 §7。
- 测试层版本清单一律派生（2026-10-25 起）：gate / audit-candidate / manifest / docs-sync 的版本断言从本表与 fixture 登记表（`tests/fixtures/registry.mjs`）循环生成，**禁止逐版本落测试文件**——`tests/structure.test.mjs` 守卫 `active-rcNXX`/`npm-flat-rcNXX` 命名回潮并锁定登记表与本表的双向镜像。

### 2.1 安全不变量

以下任一情况都必须 dormant 或 fail loud：

```text
runtime=0.1.2-rc.1 + connection=0.1.5-rc.1
runtime=0.1.5-rc.1 + connection=0.1.2-rc.1
runtime/connection 未知
path segment 与 manifest 漂移
patch config profile 与 manifest profile 不一致
profile 为 candidate 或没有实现 adapter/client
```

不能使用：

```ts
version >= '0.1.2'
version.startsWith('0.1.')
allowedRuntime.includes(runtime) && allowedConnection.includes(connection)
```

## 3. Host adapter seam

公共 host `apply()` 只做：

1. trustedHosts / body limit 校验
2. gate backstop
3. 选择 profile
4. 通过 Loader 取得当前 runtime 的 connection module
5. 创建对应 `HostRuntime`
6. 注册 Web route、index global 和 attachments 检查
7. 输出固定 warning

### 3.1 `legacy-web` adapter

`legacy-web-v1` 保留：

- 0.1.2 `HostConnectionService` 核心方法
- `/api` prefix route
- 全量 buffered bridge
- 0.1.2 official client factory

### 3.2 `carrier-neutral` adapter

`carrier-neutral-v2` 负责：

- 通过 `ctx.loader.internal.import('@deepseek-ai/dsh-client-connection')` 使用当前 runtime module
- 要求 handler 提供 `requestBodyMode()`
- 支持 exact `/api/...` POST Fetch route 和 streaming body
- 在 replacement instance 上把 `rpc.handle()` 的 physical route owner 绑定到有 `webServer` 的 carrier context，修复 0.1.5 公开的 405 回归
- 注入 profile global 与 recovery global
- 不修改官方包源码、不修改系统服务、不把所有版本的 `inject` 改成并集

该 adapter 的 register seam 是针对 0.1.5 契约的局部兼容层，不是对 DSH 本体的永久 monkey patch；未来上游修复后，应以源码/实测/无副作用三条证据重新评估是否退役。

## 4. Client variant seam

`scripts/build-client-variants.mjs` 从各 exact dev source 生成 dispatcher：

| Profile | Source | Dispatcher 选择 |
| --- | --- | --- |
| `legacy-web-v1` | `@deepseek-ai/dsh-client-connection@0.1.2-rc.1/client` | profile global = `legacy-web-v1` |
| `carrier-neutral-v2` | `@deepseek-ai/dsh-client-connection@0.1.5-rc.1/client` | profile global = `carrier-neutral-v2` |
| `carrier-neutral-v3` | `@deepseek-ai/dsh-client-connection@0.1.7-rc.2/client` | profile global = `carrier-neutral-v3`（服务 v3 全部 pair，见 §5.5） |
| `carrier-neutral-v4` | `@deepseek-ai/dsh-client-connection@0.2.1-rc.1` 的 `lib/client.browser.js`（0.2.1 拆分 browser/node 入口；`require.resolve` 默认 conditions 命中 node 入口，构建脚本经 package.json 定位浏览器入口） | profile global = `carrier-neutral-v4` |

构建和测试要求：

- 两个官方 wrapper 各自做 anchor 检查。
- 最终只注册 `@iasiv5/dsh-skip-browser-auth` 一个 ModuleLoader id。
- 缺失/未知 profile 直接抛错，不 fallback 到其它 variant。
- 两个 factory 分别 materialize；external require、`inject`、`apply` 和 recovery global 分别验证。
- 0.1.2 client 不能作为 0.1.5 client 的替代证明。

## 5. 新版本进入流程

> 自动化辅助（2026-09-29 起）：`npm run audit-candidate -- <candidate-version>`
> （`scripts/audit-candidate.mjs`）以白名单最新 pair 为基准，拉取 8 个锚点包的
> 两版 tarball 逐字节对比并判级 `RE-PUBLISH` / `REPUBLISH-WITH-REVIEW` /
> `CONTRACT-CHANGED`（含 web-app connection 行截取对比与 runtime chunk 重命名的
> loader seam 抽查）。它只覆盖 §5.1 第 1–3 条的机器可判部分，并打印建议 pair
> 片段；第 4–6 条（gate/混合负例、真实 fixture 组合测试、实机 active checklist）
> 仍必须人工完成。判级依据与本节各审计记录的人工判据一致。

### 5.0 republish 收编触点清单（registry 时代；2026-10-25 表驱动化，取代 15 文件版 runbook）

> 适用范围不变：§5.1 收编（republish 族，追加 pair 即可）。CONTRACT-CHANGED 走 §5.2 新代际，需另建 adapter/client variant 与 bundle patch 行，触点是本清单的超集，不适用。别名约定：rc.NXX = 新版本去点紧凑别名（0.2.1-rc.3 → rc213，先例 rc152/rc171/rc20/rc202/rc211/rc212/rc213）。`lib/` 与仓库根 `cordis.patch.yml` 是 `npm run build` 的产物，永远不手改。

按序核对（旧清单的 gate/audit-candidate 字面量两处坑与逐版本测试文件三步已随派生化消灭）：

1. `npm run audit-candidate -- <candidate>` 判级——RE-PUBLISH / REPUBLISH-WITH-REVIEW 才走本清单（退出码 0）；
2. `src/compatibility.ts`：相应代际 `pairs` 追加 pair + 代际注释补一段审计结论指针（§5.N）；
3. `tests/fixtures/registry.mjs`：`VERSION_FIXTURES` 追加一行条目（`version` / `profileId` / `aliasSuffix` / `aliases` 三件）——active-generations 的 active 全链路与相邻对 dormant、npm-flat-generations 循环、manifest 别名守卫、gate 派生断言与安装器 `installSpecs()` **全部自动纳入**；装/升前先 `npm run test:fixtures -- --check` 零安装验在场，缺再 `npm run test:fixtures` 以别名安装真实包；
4. 文档五件：`README.md`（版本列表×2、代际分组句、兼容表 pair 行、提示块行、mixed text 例）、`GLOSSARY.md`（profile 行、whitelist 行）、`docs/DESIGN.md`（代际表、不得激活清单、行状态表）、本文（§5.N 审计记录 + §6 已通过行）、`CHANGELOG.md` 新条目——README/GLOSSARY/DESIGN 由 docs-sync 强制（存在性 + 代际分组位置感知），漏改直接红；
5. `package.json` description 版本列表 → `npm version <x.y.z> --no-git-tag-version --ignore-scripts`（同步 lock 根字段两处，know-how 031 同款纪律）；description 紧凑记法展开与白名单的**有序相等**由 docs-sync 强制；
6. `npm run test:all` 全绿（失败数必须为 0；恒定 1 skip 为环境条件项）→ commit + tag + push，发布轮询按 know-how 018。

代码侧触点合计两处（步骤 2 + 步骤 3）。旧版 15 文件/11 步清单见 git 历史（2026-10-24 及以前）；「字面量漏改烧一整轮 `test:all`」的坑位已不存在。

### 5.1 加入已有 profile

只有以下条件全部满足，才可把新版本对追加到既有 `pairs`：

1. runtime/connection 的 host 入口、构造器、`requestRejection`、`createSharedFetchHandler`、route/body contract 与该 profile 完全一致。
2. 现有 host adapter 无需分支即可正确工作。
3. 现有 client variant 的 bundle 与 browser boot/global contract 完全一致。
4. pnpm/npm 两种布局、v1/v2 resolver、path/manifest drift 测试通过。
5. 真实 npm package fixture 与表驱动组合套件通过（`tests/composition/active-generations.test.mjs` 全版本循环 + `tests/composition/npm-flat-generations.test.mjs`；fixture 由 `npm run test:fixtures` 以别名安装，登记表见 `tests/fixtures/registry.mjs`）。
6. 真实 DSH 版本完成 active checklist，记录状态码、warning 和卸载恢复。

### 5.2 新增 profile

若出现以下任一差异，必须新增 profile：

- `inject` 或 DI topology 改变
- HostConnectionService 构造器/公开方法或 owner 语义改变
- route kind/method/body mode 改变
- BrowserAuth stub 消费方法改变
- client bundle 需要新 global、recovery、external 或 ModuleLoader 形状
- 官方 release/issue 证明旧 adapter 会产生 4xx、405、静默 route 丢失或错误身份行为

新增 profile 的顺序：

1. 在 `src/compatibility.ts` 增加新 profile/pair，先设为 `candidate`。
2. 新建 host adapter 和 client variant；公共 `apply()` 不添加版本分支。
3. 增加真实 package fixture、gate/DI/route/body/client 测试。
4. 通过全量组合与真实部署验证后，将 profile 改为 `active`。
5. 更新 README、CONTEXT、DESIGN、本文件和版本矩阵。

### 5.3 审计记录：`0.1.5-rc.2` 加入 `carrier-neutral-v2`（2026-09-10）

结论：**rc.2 通过 §5.1 全部条件，作为新 pair 加入既有代际**，未新增 adapter/client variant。

审计方法：从 npm 拉取四个锚点包的 `0.1.5-rc.1` 与 `0.1.5-rc.2` tarball 做 `diff -r` 逐字节对比：

| 包 | rc.1 → rc.2 代码差异 |
| --- | --- |
| `@deepseek-ai/dsh`（runtime 本体，探针第一锚点） | 无（仅 package.json version/依赖区间 bump） |
| `@deepseek-ai/dsh-client-connection`（被替换对象 + client variant 源） | 无（仅 package.json bump；`lib/`、`client/` 逐字节一致） |
| `@deepseek-ai/dsh-host-webserver`（DI/web carrier 契约） | 无（仅 package.json version bump） |
| `@deepseek-ai/dsh-web-app`（浏览器壳） | 无（仅 package.json bump） |

即 `0.1.5-rc.2` 是 rc.1 的**依赖版本对齐重发布**：§5.1 的第 1–3 条（host 入口/构造器/`requestRejection`/`createSharedFetchHandler`/route/body 契约、adapter 无分支、client bundle 契约）由逐字节一致直接满足；第 4–5 条由本轮新增测试满足：

- gate 探针/profile 解析：rc.2 精确对正例；`rc.1 runtime + rc.2 connection` 同代际跨 patch 混合负例（必须 dormant）。
- 真实 npm fixture：`install-rc15-fixture.mjs` 追加 `*-rc152` 别名（真实 `0.1.5-rc.2` 包），`tests/composition/active-rc152.test.mjs` 用真实 rc.2 包复刻 full active checklist（host/client/RPC/streaming Fetch/trust fence），并断言跨 patch 混合 dormant。

第 6 条（真实 DSH `0.1.5-rc.2` 宿主 active checklist）待宿主升级后按 DESIGN 清单执行。

### 5.4 审计记录：`0.1.7-rc.2` 新增 `carrier-neutral-v3`（2026-09-26）

结论：**`0.1.7-rc.2` 是真实契约变化而非重发布，按 §5.2 新增 profile `carrier-neutral-v3`、host adapter `carrier-neutral-017` 与 client variant `rc17`**，未改动既有代际。

审计方法：从 npm 拉取四个锚点包的 `0.1.5-rc.2` 与 `0.1.7-rc.2` tarball 做 `diff -r` 逐包对比（四包全部有真实代码差异，直接排除 §5.1 加入既有代际的可能），再对 connection 包 `lib/index.js` 做逐行对照。与插件相关的契约差异：

| 维度 | `0.1.5-rc.2` | `0.1.7-rc.2` | v3 适配 |
| --- | --- | --- | --- |
| `HostConnectionService` 构造器 | `(ctx, trustedHosts, browserAuth)` | 相同 | 沿用 runtime module 实例化 |
| 准入 | `requestRejection(req)` | 新增 `admit(req)` → `{peer}`/`{rejection}`；内部经新依赖 `dsh-scope` 建 `OperatorPeer`，作为 RPC handler 第 4 参传入 | route 改走 `admit()`；peer 语义由 runtime module 自带 |
| 共享 `/api` route | `bridge()` 直调 | `webCtx.waterfall('connection/request', req, res, next)` 包裹 bridge（listener 可否决/改写请求） | adapter 复刻 waterfall；经真实组合测试断言 sibling 插件监听器可见、403 拒绝不进瀑布 |
| `register(owner, channel, handler)` | `owner.effect(() => owner.webServer.register(route))` | 结构相同 | v2 的 405 修复（register owner 绑定到有 webServer 的 ctx）原样保留 |
| BrowserAuth 消费 | `authenticatedUrl` 重写 pathname `/`；token 清理 303 → `/` | mount-preserving：保留 mount；303 → `./` | trusted-auth stub 新增 `mount-preserving` 语义，由 profile 显式选择（v1/v2 保持 `root`） |
| RPC 响应 | JSON | 可携带 attachments（multipart），在 `rpcFetchHandler` 内部 | 对插件透明 |
| 浏览器 client | 221KB bundle | 重写为 59KB；ModuleLoader 提取锚点各恰出现 1 次；globals 仍为 `__DSH_CONNECTION_RECOVERY__` + `__DSH_TRANSPORT__`（均可选）；无外部 require | 新 client variant `rc17` 机械提取，dispatcher 显式选择 |
| `dsh-host-webserver` | — | 仅注释级 diff | 无 |
| 官方 connection 行（web-app patch） | `id/name/inject:[webRuntime]/config` | 逐字段一致 | 行绑定 patch 结构不变 |
| cordis / loader | 4.0.2 / 1.0.3 | 4.0.4 / 1.0.5；`waterfall` 两版同实现；loader internal v1/v2 `resolveSync` 契约逐字一致 | gate 双签名处理仍有效；devDeps cordis 升 4.0.4 以满足 rc17 peer `~4.0.4` 并保持单一实例 |

新增测试（§5.2 第 3 步）：

- `tests/composition/active-rc17.test.mjs`：真实 npm `0.1.7-rc.2` 三包组合——行状态、index profile marker + recovery global、303 `./`、dedicated RPC 200（405 回归）+ OperatorPeer 第 4 参、streaming Fetch route、`connection/request` 瀑布对 sibling 可见且仅覆盖共享 `/api`（与官方一致）、evil host 403、双向跨代际混合 dormant。
- `tests/composition/npm-flat-rc17.test.mjs`：npm 扁平布局（dshm 形态）manifest 回退激活。
- `tests/gate.test.mjs`：`0.1.7-rc.2` 精确对正例与跨代际混合负例。
- `tests/trusted-auth.test.mjs`：`mount-preserving` 语义（303 `./`、URL 保留 mount、栅栏行为不变）。
- `tests/host-apply.test.mjs`：direct 上下文 pinned 0.1.2 模块缺 `admit()` 时 fail loud（不猜测、不降级）。
- `tests/manifest.test.mjs`：rc17 dev-only 别名不变量。

第 4 条（布局/resolver/drift 测试）由全量 `npm run test:all`（新增 `test:rc17-fixture`）覆盖。第 5–6 条（真实部署 active checklist + 回滚演练）已于 2026-09-26 在本机 `0.1.7-rc.2` 宿主完成，记录见 `docs/DESIGN.md` 实机验证一节。

### 5.5 审计记录：`0.1.7-rc.1` 加入 `carrier-neutral-v3`（2026-09-26）

结论：**rc.1 通过 §5.1 全部条件，作为新 pair 加入既有代际**，未新增 adapter/client variant。

审计方法：从 npm 拉取锚点包的 `0.1.7-rc.1` 与 `0.1.7-rc.2` tarball 做 `diff -r` 逐字节对比。除 §5.3/§5.4 的四个锚点包外，本轮额外覆盖 `dsh-scope`（`admit()`/OperatorPeer 的实现来源）、`dsh-host-frontend-static` 与 boot 层 `dsh-app-boot`：

| 包 | rc.1 → rc.2 代码差异 |
| --- | --- |
| `@deepseek-ai/dsh-client-connection`（被替换对象 + client variant 源） | 无（仅 package.json 版本/依赖区间 bump；`lib/`、`client/` 逐字节一致） |
| `@deepseek-ai/dsh-host-webserver`（DI/web carrier 契约） | 无（仅 package.json bump） |
| `@deepseek-ai/dsh-scope`（`admit()`/OperatorPeer 来源） | 无（仅 package.json bump） |
| `@deepseek-ai/dsh-host-frontend-static` | 无（仅 package.json bump） |
| `@deepseek-ai/dsh-web-app`（浏览器壳 + 官方 patch） | `cordis.patch.yml` 仅**新增行**（`time-context`/`schedule`/`shortcuts`/`ui-shortcuts`）与 schedule 注释改写；`connection` 行（`id/name/inject/config`）逐字段一致；package.json 为依赖 bump 与新增包（schedule、time-context、shortcuts 等） |
| `@deepseek-ai/dsh`（runtime 本体，探针第一锚点） | 有 diff 但语义无关：`bin.js`/`profile-boot.js` 仅 chunk 哈希重命名的 import 引用；重命名 chunk 逐一配对对比——**plugin chunk（ModuleLoader，gate 依赖的 loader seam 所在）逐字节一致**，profile-boot chunk 新增 `reportSkippedBundles` 调用（纯诊断，见下行），dump-config chunk 为 CLI 内部签名调整 |
| `@deepseek-ai/dsh-app-boot`（boot 层，profile patch 读取） | 有 diff 但语义无关：skipped-bundle 从「边加载边打印」重构为「收集进 `profile.skippedBundles`、由 launcher 一次性打印」（加载与 patch 应用语义不变）；`OPTIONAL_BUNDLES` 追加 experimental 包；resolver 错误消息格式化。`readProfilePatches`/`loadOverlayPatches` 契约不变 |

即 `0.1.7-rc.2` 相对 rc.1 是「插件契约面上的等价重发布 + 无关诊断演进」：§5.1 第 1–3 条（host 入口/构造器/`admit()`/`createSharedFetchHandler`/route/body 契约、adapter 无分支、client bundle 契约）由逐字节一致与 connection 行逐字段一致直接满足；rc17 client variant 以 profile id 单一来源同时服务两个 pair。第 4–5 条由本轮新增测试满足：

- gate 探针/profile 解析：rc.1 精确对正例；`0.1.7-rc.1 runtime + 0.1.7-rc.2 connection` 及反向**同代际跨 patch 混合负例**（必须 dormant）；`0.1.5-rc.2 ↔ 0.1.7-rc.1` 跨代际混合负例。
- 真实 npm fixture：`install-rc17-fixture.mjs` 追加 `*-rc171` 别名（真实 `0.1.7-rc.1` 包），`tests/composition/active-rc171.test.mjs` 用真实 rc.1 包复刻 full active checklist（行状态、index profile marker + recovery global、mount-preserving 303 `./`、dedicated RPC 200 + OperatorPeer 第 4 参、waterfall 对 sibling 可见且 403 不进瀑布、streaming Fetch route），并断言同代际跨 patch 双向 dormant 与跨代际 dormant。
- `tests/composition/npm-flat-rc17.test.mjs` 追加 rc.1 manifest 回退激活用例（dshm npm 扁平形态）。
- `tests/manifest.test.mjs`：rc171 保持 fixture-only 别名——不进 dependencies，也不进 devDependencies（client variant 构建锚点保持 rc17 单一来源，避免出现第二个 0.1.7 构建输入）。

第 6 条（真实 DSH `0.1.7-rc.1` 宿主 active checklist）待宿主运行 rc.1 时按 DESIGN 清单执行；本机宿主为 `0.1.7-rc.2`，其 checklist 已完成（§5.4）。

### 5.6 审计记录：`0.2.0-rc.1` 加入 `carrier-neutral-v3`（2026-09-29）

结论：**`0.2.0-rc.1` 通过 §5.1 全部条件，作为新 pair 加入既有代际**，未新增 adapter/client variant。虽然 semver 上是跨 minor（0.1.7 → 0.2.0），但代际由契约决定而非版本号：审计显示它在插件契约面上是 `0.1.7-rc.2` 的**依赖对齐重发布**，与 §5.3（`0.1.5-rc.2`）同类。

审计方法：从 npm 拉取锚点包的 `0.1.7-rc.2` 与 `0.2.0-rc.1` tarball 做 `diff -r` 逐包对比（锚点集合同 §5.5）：

| 包 | 0.1.7-rc.2 → 0.2.0-rc.1 代码差异 |
| --- | --- |
| `@deepseek-ai/dsh-client-connection`（被替换对象 + client variant 源） | 无（仅 package.json 版本/依赖区间 bump；`lib/`、`client/` 逐字节一致） |
| `@deepseek-ai/dsh-host-webserver`（DI/web carrier 契约） | 无（仅 package.json version bump） |
| `@deepseek-ai/dsh-scope`（`admit()`/OperatorPeer 来源） | 无（仅 package.json 版本/依赖区间 bump） |
| `@deepseek-ai/dsh-invariants` | 无（仅 package.json version bump） |
| `@deepseek-ai/dsh-host-frontend-static` | 无（仅 package.json 版本/依赖区间 bump） |
| `@deepseek-ai/dsh`（runtime 本体，探针第一锚点） | 无 `lib` 代码 diff（`diff -rq` 仅 package.json 不同）：全量依赖区间 bump 0.1.7-rc.2 → 0.2.0-rc.1、键重排、新增 `dsh-experimental-schedule-bundle`；ModuleLoader chunk 因此逐字节一致 |
| `@deepseek-ai/dsh-app-boot`（boot 层，profile patch 读取） | `lib/index.js` 仅一行：`OPTIONAL_BUNDLES` 追加 `@deepseek-ai/dsh-experimental-schedule-bundle`；`readProfilePatches`/`loadOverlayPatches` 契约不变（与 §5.5 同类的 OPTIONAL_BUNDLES 演进） |
| `@deepseek-ai/dsh-web-app`（浏览器壳 + 官方 patch） | `cordis.patch.yml` 仅增删 telemetry/product-analytics/schedule/session-log 行，**`connection` 行逐字段一致**（id/name/inject/config 未动）；package.json 为依赖 bump 与包进出（`dsh-client-product-analytics`、`dsh-host-product-telemetry-otel`、`dsh-client-ui-settings-session-log` 进，`dsh-schedule`/`dsh-time-context`/`dsh-client-ui-schedule` 出），均不涉及 connection 行 |

即 `0.2.0-rc.1` 相对 `0.1.7-rc.2` 是「插件契约面上的等价重发布 + 无关遥测/日程演进」：§5.1 第 1–3 条（host 入口/构造器/`admit()`/`createSharedFetchHandler`/route/body 契约、adapter 无分支、client bundle 契约）由逐字节一致与 connection 行逐字段一致直接满足；rc17 client variant 继续以 profile id 单一来源服务全部三个 pair。第 4–5 条由本轮新增测试满足：

- gate 探针/profile 解析：`0.2.0-rc.1` 精确对正例；`0.1.7-rc.2 runtime + 0.2.0-rc.1 connection` 及反向**同代际跨 minor 混合负例**（必须 dormant）；`0.1.5-rc.2 ↔ 0.2.0-rc.1` 跨代际混合负例。
- 真实 npm fixture：`install-rc17-fixture.mjs` 追加 `*-rc20` 别名（真实 `0.2.0-rc.1` 包），`tests/composition/active-rc20.test.mjs` 用真实 0.2.0-rc.1 包复刻 full active checklist（行状态、index profile marker + recovery global、mount-preserving 303 `./`、dedicated RPC 200 + OperatorPeer 第 4 参、waterfall 对 sibling 可见且 403 不进瀑布、streaming Fetch route），并断言跨 minor 混合双向 dormant。
- `tests/composition/npm-flat-rc17.test.mjs` 追加 0.2.0-rc.1 manifest 回退激活用例（dshm npm 扁平形态）。
- `tests/manifest.test.mjs`：rc20 保持 fixture-only 别名——不进 dependencies，也不进 devDependencies（client variant 构建锚点保持 rc17 单一来源，避免出现第二个 0.1.x/0.2.x 构建输入）。

第 6 条（真实 DSH `0.2.0-rc.1` 宿主 active checklist）待宿主升级后按 DESIGN 清单执行；本机宿主当前仍为 `0.1.7-rc.2`（其 checklist 已完成，§5.4）。

### 5.7 审计记录：`0.2.0-rc.2` 加入 `carrier-neutral-v3`（2026-09-29）

结论：**`0.2.0-rc.2` 通过 §5.1 全部条件，作为新 pair 加入既有代际**，未新增 adapter/client variant。

审计方法：从 npm 拉取锚点包的 `0.2.0-rc.1` 与 `0.2.0-rc.2` tarball 做 `diff -rq` 逐包对比（锚点集合同 §5.5/§5.6）：

| 包 | rc.1 → rc.2 代码差异 |
| --- | --- |
| `@deepseek-ai/dsh-client-connection`（被替换对象 + client variant 源） | 无（仅 package.json bump；`lib/`、`client/` 逐字节一致） |
| `@deepseek-ai/dsh-host-webserver`（DI/web carrier 契约） | 无（仅 package.json bump） |
| `@deepseek-ai/dsh-scope`（`admit()`/OperatorPeer 来源） | 无（仅 package.json bump） |
| `@deepseek-ai/dsh-invariants` | 无（仅 package.json bump） |
| `@deepseek-ai/dsh-host-frontend-static` | 无（仅 package.json bump） |
| `@deepseek-ai/dsh-app-boot`（boot 层，profile patch 读取） | 无（仅 package.json bump） |
| `@deepseek-ai/dsh-web-app`（浏览器壳 + 官方 patch） | 无代码 diff（仅 package.json bump）——`cordis.patch.yml` 逐字节一致，`connection` 行原样 |
| `@deepseek-ai/dsh`（runtime 本体，探针第一锚点） | 有 diff 但语义无关：`lib/bin.js` 与 `lib/types/{args,bin,plugin}.d.ts` 为 **Desktop 保留 profile 的插件管理 CLI** 演进（`manageDesktopProfile`、`runProfilePnpm`、`requireDesktopProfile`、`withFileLock`）；ModuleLoader chunk 哈希重命名（`plugin-DkYIj96-` → `plugin-BGnVfe_D`），全部 34 行变更落在上述 CLI 区，对 `resolveSync` 的用法逐行一致（vendor loader seam 零变化）；`package.json` 为全量依赖区间 bump；README* 为文档 |

即 `0.2.0-rc.2` 相对 `0.2.0-rc.1` 是「插件契约面上的等价重发布 + 无关 Desktop CLI 演进」：§5.1 第 1–3 条（host 入口/构造器/`admit()`/`createSharedFetchHandler`/route/body 契约、adapter 无分支、client bundle 契约）由逐字节一致、connection 行逐字段一致与 loader seam 零变化直接满足；rc17 client variant 继续以 profile id 单一来源服务全部四个 pair。第 4–5 条由本轮新增测试满足：

- gate 探针/profile 解析：`0.2.0-rc.2` 精确对正例；`0.2.0-rc.1 runtime + 0.2.0-rc.2 connection` 及反向**同代际跨 patch 混合负例**（必须 dormant）；`0.1.7 ↔ 0.2.0-rc.2` 跨 minor 混合与 `0.1.5 ↔ 0.2.0-rc.2` 跨代际混合负例。
- 真实 npm fixture：`install-rc17-fixture.mjs` 追加 `*-rc202` 别名（真实 `0.2.0-rc.2` 包），`tests/composition/active-rc202.test.mjs` 用真实 rc.2 包复刻 full active checklist（行状态、index profile marker + recovery global、mount-preserving 303 `./`、dedicated RPC 200 + OperatorPeer 第 4 参、waterfall 对 sibling 可见且 403 不进瀑布、streaming Fetch route），并断言同代际跨 patch 混合双向 dormant。
- `tests/composition/npm-flat-rc17.test.mjs` 追加 0.2.0-rc.2 manifest 回退激活用例（dshm npm 扁平形态）。
- `tests/manifest.test.mjs`：rc202 保持 fixture-only 别名——不进 dependencies，也不进 devDependencies（client variant 构建锚点保持 rc17 单一来源）。

第 6 条（真实 DSH `0.2.0-rc.2` 宿主 active checklist）随本机宿主当日升级（0.2.0-rc.1 → 0.2.0-rc.2）按 DESIGN 清单执行并留档。

### 5.8 审计记录：`0.2.1-rc.1` 判为 CONTRACT-CHANGED，不加 pair（2026-10-17）

结论：**`0.2.1-rc.1` 未通过 §5.1，按 §5.2 需要新代际**（新 host adapter + 新 client variant + patch 模板适配）。本轮**不加 pair**：插件在 0.2.1 宿主上继续自动休眠（fail-closed，官方 BrowserAuth 行为分毫不变——这是设计内的安全态，不是故障）。

审计方法：`npm run audit-candidate -- 0.2.1-rc.1`（基准 `0.2.0-rc.2`，机器初判 CONTRACT-CHANGED，退出码 3）。脚本本轮新增 `missing-in-candidate` 定级（`@deepseek-ai/dsh-invariants` 在 0.2.1 线**从未发布**，`npm pack` 报 ETARGET——`--silent` 会吞掉错误行，失败后须以不带 `--silent` 的 `npm view` 复核定性）。锚点包逐包结果：

| 包 | 0.2.0-rc.2 → 0.2.1-rc.1 差异 | 判定 |
| --- | --- | --- |
| `@deepseek-ai/dsh-client-connection`（被替换对象 + client variant 源） | `lib/index.js` **488 行 diff**：`OperatorPeer` 改名/重构为 **`Peer`**（`types/operator-peer.d.ts` → `types/peer.d.ts`，新增 `peers` Map 台账/`ownsSocket`/`admitConnection()`/release-dispose 语义）；新增 **`CONNECT_PATH = "/connect"`** 导出与 exact route（`connection.authorizeConnect(req, res)`，socket 连接协议：`types/connect-protocol.d.ts`、`types/client/socket.d.ts`）；官方共享路由的 bridge 调用签名变化：`bridge(req, res, fetchHandler, maxRequestBodyBytes)` → `bridge(req, res, fetchHandler, **admission.peer**, maxRequestBodyBytes)`；`lib/client.js` 拆分为 **`lib/client.browser.js`（60601B）+ `lib/client.node.js`**；新增 `locale/`。`HostConnectionService` 构造器签名 `(ctx, trustedHosts, browserAuth)` **未变** | **替换面实质重构 [阻断]** |
| `@deepseek-ai/dsh-host-webserver`（DI/web carrier 契约） | `lib/index.js` 338 行 diff（无 `webRuntime`/`webStartup` 字样——改名不在本包） | 代码 diff [阻断] |
| `@deepseek-ai/dsh-scope`（v3 准入来源） | **剥离 invariants**：`lib/invariant.js`、`lib/types/invariant.d.ts` 删除；package.json 移除 `@deepseek-ai/dsh-invariants` 依赖 | 代码 diff [阻断] |
| `@deepseek-ai/dsh-invariants` | 0.2.1 线未发布于 npm（0.2.0-rc.2 后停更；scope 已同步移除其依赖） | missing-in-candidate [人工定性：随 scope 剥离，属同一重构] |
| `@deepseek-ai/dsh-host-frontend-static` | 仅 package.json/README/docs | 无阻断 |
| `@deepseek-ai/dsh-app-boot`（boot 层） | `lib/index.js` + profile-resolution 类型重排；新增 `types/official-bundles*.d.ts` 三件 | REVIEW（无替换面语义，但本轮随整体不收编） |
| `@deepseek-ai/dsh-web-app`（浏览器壳 + 官方 patch） | **connection 行漂移**：`inject: [webRuntime]` → `[webStartup]`、`trustedHosts: !!js ctx.webRuntime.trustedHosts` → `ctx.webStartup.trustedHosts`（注释并声明「listener 的 bind IP 单独接受，不在本表」）；`lib/startup.js`、`types/startup.d.ts`、四个 presets patch 变化；新增 `lib/public-url-*.js` chunk 与 `locale/startup/` | **connection 行漂移 [阻断]** |
| `@deepseek-ai/dsh`（runtime 本体） | `lib/profile-boot.js`、`types/{dump-config,dump-config-schema,args,profile-boot}.d.ts` 越出 Desktop CLI/types 良性白名单；4 个 chunk 哈希重命名且内容有差异（`plugin-`/`profile-boot-`/`dump-config*`，loader seam 抽查 `resolveSync` 用法逐行一致） | runtime diff 越出白名单 [阻断] |

即 0.2.1-rc.1 是 0.1.x→0.2.0 之后的**第二次实质契约演进**（connection 半区的 Peer/连接协议重构 + web app 层 `webRuntime`→`webStartup`），不是 0.2.0-rc.1/rc.2 型的依赖对齐重发布。§5.1 第 1–3 条多条不满足；第 4–6 条未执行（前置第 1–3 条已不成立）。

对 §5.2 新代际（`carrier-neutral-v4`，命名届时定）的影响面事实清单：

1. **host adapter**：官方 `/api` 路由 handler 须复刻 `admit()` → waterfall → `bridge(req, res, fetchHandler, admission.peer, maxRequestBodyBytes)` 新签名；官方另挂 `/connect` exact route（`authorizeConnect`）——Replacement 是否复刻该通道须在 v4 设计中决策（BrowserAuth 替换范围随之扩大）；`admit()`/`createSharedFetchHandler`/构造器签名延续，v3 的三处 seam 检查形态仍可沿用作代际守卫（`admit` 存在性不足以区分 v3/v4，需新增锚点如 `CONNECT_PATH`/`authorizeConnect`）。
2. **patch 模板**：`trusted-connection` 行的 `config.trustedHosts` 表达式在 0.2.1 宿主须读 `ctx.webStartup.trustedHosts`（`webRuntime` 停用）；单一静态 patch 服务多代际 ⇒ 表达式须跨代际防御（try/catch 或 `??` 回退，沿用探针同款纪律），并吸收「bind IP 单独接受」的 trustedHosts 语义变化。
3. **client variant**：官方 browser bundle 内容变化且拆分（browser/node 两件），rc17 变体不能再服务 0.2.1 ⇒ 新 variant 锚定 0.2.1-rc.1 的 `lib/client.browser.js`（fixture 别名 `*-rc211`；devDependencies 继续零锚点，构建输入单一来源纪律不变）。
4. **scope 链**：0.2.1 的 connection 仍 peer `dsh-scope@0.2.1-rc.1`，但其已无 invariants 下挂——v4 fixture 的 rc211 别名共享 scope 安装时不再需要 invariants。

0.2.1 宿主上现版本插件的行为：双锚点 `0.2.1-rc.1` 不在白名单 ⇒ 探针 `null` ⇒ 官方行 enabled、trusted 行 disabled，安静休眠（判别法同 know-how 016）。**勿在 0.2.1 宿主上 pin `trusted-connection` 行**（0.3.12 的 apply 权威判别会拦住 desktop，但 web 上 pinned 行的 `ctx.webRuntime.trustedHosts` 组合层风险未验，v4 落地前不做该形态）。

### 5.9 收编记录：新增 `carrier-neutral-v4` 代际服务 `0.2.1-rc.1`（2026-10-17）

结论：**按 §5.2 新增代际并实现完毕**（0.4.0）：新 host adapter `carrier-neutral-021`、新 client variant `rc21`、bundle patch 双行代际拆分、`*-rc211` 真实 npm fixture 与全套组合测试。§5.1 第 1–5 条由实现 + 测试满足；第 6 条（真实 0.2.1 宿主 active checklist）待宿主升级后按 DESIGN 清单执行并回填 §6/§7.7。

实现要点（与 §5.8 影响面清单逐条对应）：

1. **host adapter（`src/adapters/carrier-neutral-021.ts`）**：逐行复刻官方 0.2.1 apply 的路由面——`/api` prefix 路由 `admit()` → `connection/request` 瀑布 → `bridgeWithPeer(req, res, fetchHandler, admission.peer, maxRequestBodyBytes)`；新增 exact `/connect` 路由整体委托 `connection.authorizeConnect(req, res)`（注册顺序照抄官方：/api 在前、/connect 在后）。代际 seam 守卫 = `CONNECT_PATH` 导出 + `authorizeConnect` 方法（0.1.7/0.2.0 模块在此确定性报错——`admit()` 存在性已不足以区分代际）；`register()` carrier 绑定包装与 017 同款（405 修复语义不变）。
2. **bridge（`src/bridge.ts`）**：抽取共享 `bridgeRequest`，新增 `bridgeWithPeer` 把 admission Peer 透传 `apiHandler.fetch(request, peer)`（官方 0.2.1 bridge 唯一语义差异）；v3 适配器继续调用原 `bridge`，代际不互串。
3. **trusted-auth 四方法 stub（`src/trusted-auth.ts`）**：新增 `authorizeConnect(req, res, secure?, publish?)`——interactions 声明校验逐字对齐官方（400 兜底，客户端协议契约）；成功路径复刻官方 302 `./api/remote.mux` 重定向形态，但**不铸造身份 cookie、不调用 publish**（trusted-network 无身份可铸造；publish 会生成无 cookie 引用的孤儿 operator 台账）。后续 `/api` 请求由 `admit()` 恒准为 owner-principal `browserPeer`（官方 `Peer`，principal owner——exact Fetch route 的 owner 守卫天然放行），mux 连接不依赖该 cookie。`authorizeIndex`/`isAuthenticated` 签名兼容 0.2.1 新增的 `secure` 尾参（stub 忽略）。
4. **bundle patch 双行拆分（`write-patch.mjs` + `gate.ts`）**：行绑定表达式按代际参数化——`trusted-connection`（inject `webRuntime`，≤0.2.0，绑定集合排除 v4）与 `trusted-connection-021`（inject `webStartup`，绑定集合仅 v4）。两集合由 `compatibility.ts` 单表派生、互斥由测试锁定（gate.test/patch.test 分区断言）：任何宿主上至多一行激活，0.2.1 宿主上旧行因 webRuntime 服务不复存在而必然 dormant。`trusted-connection-021` 的 `config.trustedHosts` 读 `ctx.webStartup.trustedHosts`——逐字对齐官方 0.2.1 patch connection 行的同款迁移（webRuntime → webStartup 改名 + 语义收窄为显式 `--trusted-host` 值，bind IP 由连接服务单独接受）。
5. **client variant（`build-client-variants.mjs`）**：`rc21` 锚定 devDep `dsh-client-connection-rc21@npm:@deepseek-ai/dsh-client-connection@0.2.1-rc.1` 的 `lib/client.browser.js`（0.2.1 拆分 browser/node 入口，`require.resolve` 默认 conditions 命中 node 入口，故经 package.json 定位浏览器入口）；anchor 检查与其它 variant 同款。`tests/manifest.test.mjs` 看护 rc211 fixture 别名不进清单、rc21 devDep 精确 pin。
6. **fixture（`install-rc17-fixture.mjs`）**：`*-rc211` 别名安装真实 0.2.1-rc.1 的 connection/frontend-static/webserver。0.2.1 connection 的 scope peer 是 0.2.1-rc.1，但其消费面（scope `lib/index.js`，`createScope`）与 0.1.7-rc.2 逐字节一致（§5.8：仅独立 `invariant.js` 被剥离），共享 hoisted scope 副本无行为差异——rc20/rc202 先例，论证留档于脚本注释。

第 4–5 条测试证据（本轮新增，全量 177 跑 176 过 0 败 1 skip）：

- gate 探针/profile 解析：`0.2.1-rc.1` 精确对正例（探针 + `evaluateGate`）；`0.2.0-rc.1/rc.2 ↔ 0.2.1-rc.1` 与 `0.1.7-rc.2 ↔ 0.2.1-rc.1` 跨代际混合负例（必须 dormant）；行绑定代际分区断言（v3 pair 上 v4 行拒绝、v4 pair 上旧行拒绝、0.1.x 上 v4 行拒绝）。
- 真实 npm fixture 组合（`tests/composition/active-rc211.test.mjs`）：full active checklist 用真实 0.2.1-rc.1 包复刻——行状态（官方行 disabled、021 行 enabled、旧行 disabled）、index profile marker `carrier-neutral-v4` + recovery global、mount-preserving 303 `./`、dedicated RPC 200 + Peer 第 4 参、瀑布对 sibling 可见且 403 不进瀑布、streaming Fetch route、**`/connect` 交换端点**（trusted 302 `./api/remote.mux`、interactions 违例 400、evil host 403）；跨代际混合双向 dormant（0.2.0-rc.2 ↔ 0.2.1-rc.1，且两行均 disabled）。
- `tests/composition/npm-flat-rc17.test.mjs` 追加 0.2.1-rc.1 manifest 回退激活用例（dshm npm 扁平形态，`trusted-connection-021` 行激活）。
- patch 结构断言（`tests/patch.test.mjs`）：双行插入结构与求值行为（v4 pair 仅 webStartup 行激活、v3 pair 仅 webRuntime 行激活、desktop 信号下两行均 dormant）。

第 6 条（真实 DSH `0.2.1-rc.1` 宿主 active checklist）：待宿主升级后按 DESIGN 清单执行；预期断言 = 横幅逐字输出、无 token `GET /` 200、伪造 Host 403、`/?token=x` 303 `./`、`/connect` 302 `./api/remote.mux`、本 boot 守卫零 `skipping profile bundle`。

### 5.10 审计记录：`0.2.1-rc.2` 加入 `carrier-neutral-v4`（2026-10-17）

结论：**`0.2.1-rc.2` 通过 §5.1 全部条件，作为第二个 pair 加入 `carrier-neutral-v4`**，未新增 adapter/client variant（rc21 继续锚定 0.2.1-rc.1，不引入第二个 0.2.1 线构建输入）。

审计方法：`npm run audit-candidate -- 0.2.1-rc.2`（基准自动取 `0.2.1-rc.1`；脚本本轮新增 missing-in-base / missing-both-sides 定级——白名单基准本身也可能停更，实证即本例）。逐包结果：

| 包 | 0.2.1-rc.1 → 0.2.1-rc.2 差异 |
| --- | --- |
| `@deepseek-ai/dsh-client-connection` / `dsh-host-webserver` / `dsh-scope` / `dsh-host-frontend-static` / `dsh-app-boot` / `dsh`（runtime 本体） | 均仅 package.json/README/docs（本轮回**零代码 diff**，连 runtime 的 Desktop CLI 白名单区都没动） |
| `@deepseek-ai/dsh-invariants` | 两侧均未发布（0.2.1 线停更延续，无对比物，非差异） |
| `@deepseek-ai/dsh-web-app` | `cordis.patch.yml` 仅**新增一行** `- id: ui-deepseek-model-label-1017`（新 client-ui 插件行；§5.6 先例：非 connection 行可进出）；**connection 行逐字段一致** |

即 `0.2.1-rc.2` 是继 0.2.0-rc.2 之后又一个标准 rc.2 型「契约面等价重发布」。第 4–5 条由本轮测试满足：

- gate 探针/profile 解析：`0.2.1-rc.2` 精确对正例；`0.2.1-rc.1 runtime + 0.2.1-rc.2 connection` 及反向**同代际跨 patch 混合负例**（必须 dormant）。
- 真实 npm fixture：`install-rc17-fixture.mjs` 追加 `*-rc212` 别名（真实 0.2.1-rc.2 包），`tests/composition/active-rc212.test.mjs` 用真实 rc.2 包复刻 full active checklist（行状态、index marker、mount-preserving 303、dedicated RPC + Peer 第 4 参、瀑布可见性、streaming Fetch、`/connect` 302/400/403），并断言同代际跨 patch 混合双向 dormant。
- `tests/composition/npm-flat-rc17.test.mjs` 追加 0.2.1-rc.2 manifest 回退激活用例。
- `tests/manifest.test.mjs`：rc212 保持 fixture-only 别名。

第 6 条（真实 DSH 0.2.1 宿主 active checklist）与 §5.9 的清单合并——宿主升级时以实际安装的 0.2.1 版本为准执行并回填。

### 5.11 审计记录：`0.2.1-rc.3` 加入 `carrier-neutral-v4`（2026-10-24）

结论：**`0.2.1-rc.3` 通过 §5.1 全部条件，作为第三个 pair 加入 `carrier-neutral-v4`**，未新增 adapter/client variant（rc21 继续锚定 0.2.1-rc.1，不引入第二个 0.2.1 线构建输入）。

审计方法：`npm run audit-candidate -- 0.2.1-rc.3`（基准自动取 `0.2.1-rc.2`）。逐包结果：

| 包 | 0.2.1-rc.2 → 0.2.1-rc.3 差异 |
| --- | --- |
| `@deepseek-ai/dsh-client-connection` / `dsh-host-webserver` / `dsh-scope` / `dsh-host-frontend-static` / `dsh-app-boot` / `dsh`（runtime 本体） | 均仅 package.json/README/docs |
| `@deepseek-ai/dsh-invariants` | 两侧均未发布（0.2.1 线停更延续，无对比物，非差异） |
| `@deepseek-ai/dsh-web-app` | `cordis.patch.yml` 仅**新增一行** `- id: entry-customization`（`@deepseek-ai/dsh-client-ui-entry-customization`，Region-local More menus；§5.6/§5.10 先例：非 connection 行可进出）；**connection 行逐字段一致**；`presets/` 逐字节一致 |

即 `0.2.1-rc.3` 是继 0.2.1-rc.2 之后又一个标准 rc.2 型「契约面等价重发布」。第 4–5 条由本轮测试满足：

- gate 探针/profile 解析：`0.2.1-rc.3` 精确对正例；`0.2.1-rc.2 runtime + 0.2.1-rc.3 connection` 及反向**同代际跨 patch 混合负例**（必须 dormant）。
- 真实 npm fixture：`install-rc17-fixture.mjs` 追加 `*-rc213` 别名（真实 0.2.1-rc.3 包），`tests/composition/active-rc213.test.mjs` 用真实 rc.3 包复刻 full active checklist（行状态、index marker、mount-preserving 303、dedicated RPC + Peer 第 4 参、瀑布可见性、streaming Fetch、`/connect` 302/400/403），并断言同代际跨 patch 混合双向 dormant。
- `tests/composition/npm-flat-rc17.test.mjs` 追加 0.2.1-rc.3 manifest 回退激活用例。
- `tests/manifest.test.mjs`：rc213 保持 fixture-only 别名。

第 6 条（真实 DSH 0.2.1 宿主 active checklist）已在 2026-10-25 的 DSH Web `0.2.1-rc.3` 宿主通过：启动日志出现 BrowserAuth 跳过横幅，未携带 token 的 `GET /` 返回 200；本次启动日志无 profile 守卫拒载或未激活记录。Desktop 仍按设计休眠。

### 5.12 审计记录：`0.2.1-rc.4` 加入 `carrier-neutral-v4`（2026-10-28）

结论：**`0.2.1-rc.4` 通过 §5.1 全部条件，作为第四个 pair 加入 `carrier-neutral-v4`**，未新增 adapter/client variant（rc21 继续锚定 0.2.1-rc.1，不引入第二个 0.2.1 线构建输入）。

审计方法：`npm run audit-candidate -- 0.2.1-rc.4`（基准自动取 `0.2.1-rc.3`）。逐包结果：

| 包 | 0.2.1-rc.3 → 0.2.1-rc.4 差异 |
| --- | --- |
| `@deepseek-ai/dsh-client-connection` / `dsh-host-webserver` / `dsh-scope` / `dsh-host-frontend-static` / `dsh-app-boot` / `dsh-web-app` / `dsh`（runtime 本体） | 均仅 package.json/README/docs |
| `@deepseek-ai/dsh-invariants` | 两侧均未发布（0.2.1 线停更延续，无对比物，非差异） |

即 `0.2.1-rc.4` 是 0.2.1 线至今最干净的一次「契约面等价重发布」——首个 web-app patch **零 diff** 的收编轮（rc.2 增 `ui-deepseek-model-label-1017`、rc.3 增 `entry-customization`，本轮无任何 ADDED 行），connection 行逐字段一致。第 4–5 条由本轮测试满足：

- gate 探针/profile 解析：`0.2.1-rc.4` 精确对正例；同代际跨 patch 混合负例由 gate 全 N×N 循环自动覆盖（必须 dormant）。
- 真实 npm fixture：登记表追加 `*-rc214` 别名（真实 0.2.1-rc.4 包），`active-generations` / `npm-flat-generations` 循环套件自动扩展到 rc.4（full active checklist + `/connect` 302/400/403 + 同代际跨 patch 混合双向 dormant）。
- `tests/manifest.test.mjs`：rc214 保持 fixture-only 别名。

第 6 条（真实 DSH 0.2.1 宿主 active checklist）待宿主升级 `0.2.1-rc.4` 后按清单执行并回填（BrowserAuth 跳过横幅 + 无 token `GET /` 200）。

### 5.13 审计记录：`0.2.1-rc.5` 加入 `carrier-neutral-v4`（2026-10-30）

结论：**`0.2.1-rc.5` 通过 §5.1 全部条件，作为第五个 pair 加入 `carrier-neutral-v4`**，未新增 adapter/client variant（rc21 继续锚定 0.2.1-rc.1，不引入第二个 0.2.1 线构建输入）。

审计方法：`npm run audit-candidate -- 0.2.1-rc.5`（基准自动取 `0.2.1-rc.4`）。逐包结果：

| 包 | 0.2.1-rc.4 → 0.2.1-rc.5 差异 |
| --- | --- |
| `@deepseek-ai/dsh-client-connection` / `dsh-host-webserver` / `dsh-scope` / `dsh-host-frontend-static` / `dsh-app-boot` / `dsh-web-app` / `dsh`（runtime 本体） | 均仅 package.json/README/docs |
| `@deepseek-ai/dsh-invariants` | 两侧均未发布（0.2.1 线停更延续，无对比物，非差异） |

即 `0.2.1-rc.5` 连续第二轮「契约面等价重发布」，web-app patch 连续第二轮 **零 diff**，connection 行逐字段一致。第 4–5 条由本轮测试满足：

- gate 探针/profile 解析：`0.2.1-rc.5` 精确对正例；同代际跨 patch 混合负例由 gate 全 N×N 循环自动覆盖（必须 dormant）。
- 真实 npm fixture：登记表追加 `*-rc215` 别名（真实 0.2.1-rc.5 包），`active-generations` / `npm-flat-generations` 循环套件自动扩展到 rc.5（full active checklist + `/connect` 302/400/403 + 同代际跨 patch 混合双向 dormant）。
- `tests/manifest.test.mjs`：rc215 保持 fixture-only 别名。

第 6 条（真实 DSH 0.2.1 宿主 active checklist）已在 2026-10-30 的 DSH Web `0.2.1-rc.5` 宿主（npm -g 裸装形态）通过：启动日志出现 BrowserAuth 跳过横幅恰一次，未携带 token 的 `GET /` 返回 200，`skipping profile bundle` 为 0；`did not activate=1` + `waiting for service: webRuntime`=1 为 0.4.x 双代门控既有基线，非回归。

### 5.14 审计记录：`0.2.2-rc.1` 加入 `carrier-neutral-v4`（2026-11-04）

结论：**`0.2.2-rc.1` 经逐维替换面审计后通过 §5.1 全部条件，作为第六个 pair 加入 `carrier-neutral-v4`**，未新增 adapter/client variant（rc21 继续锚定 0.2.1-rc.1，不引入第二个构建输入）。本轮为**首个机器判级 CONTRACT-CHANGED 而逐维人工定性收编**的轮次：机械判级的全部阻断项均被逐文件对照定性为「非替换面」。0.2.2-rc.1 是新 minor 线首轮（dist-tag `next`），非 rc.N 顺延。

审计方法：`npm run audit-candidate -- 0.2.2-rc.1`（基准自动取 `0.2.1-rc.5`，机器初判 CONTRACT-CHANGED，退出码 3——阻断项为未配对 locale 文件与四个锚点包的真实代码 diff）；随后对八个锚点包两版 tarball 逐文件 `diff` 人工定性。逐包结果：

| 包 | 0.2.1-rc.5 → 0.2.2-rc.1 差异 | 人工定性 |
| --- | --- | --- |
| `@deepseek-ai/dsh-client-connection` | 仅 `lib/types/client/index.d.ts` 新增可选 `resolveAsset?`（worker 隧道资产解析器，缺省缺席）+ 新增 `locale/` 六件 | **替换面逐字节一致**：`lib/index.js`（admit/Peer/authorizeConnect/bridge/createSharedFetchHandler 全部在内）与 `lib/client.browser.js`（rc21 构建锚）均无 diff；类型为增量可选成员 [非阻断] |
| `@deepseek-ai/dsh-host-webserver` | 新增 resource 路由形态（route/fallback 可给 `{ resource }` 应答 GET/HEAD、`readResource()`/`serveResource()`/`writeResponse()`），`collectIndexInjections`/`renderIndex` 加 `peer` 尾参；types 同步 | handler 路由分发逐行为等价：`responderFor` 分支里 function（含旧 handler fallback）仍走 `await responder(req, res)` 原语义，resource 是并行新增路径；`register(handler)`、route 匹配（exact + 最长 prefix）、waterfall 契约未动 [非阻断] |
| `@deepseek-ai/dsh-scope` | 仅 package.json/README/docs | 无阻断 |
| `@deepseek-ai/dsh-invariants` | 两侧均未发布（0.2.1 线停更延续，无对比物，非差异） | — |
| `@deepseek-ai/dsh-host-frontend-static` | fallback 由 handler 重构为 resource 形态注册；非索引文件新增弱 ETag/304 缓存；`authorizeIndex` 消费改为「Fetch Request + writeHead/end shim，返回 falsy 时以 shim 收集值构造 refusal Response」 | shim 逐字模拟 node res 语义，**官方 browserAuth（web-app `lib/` 全量零 diff）零改动即兼容即活证据**；插件 stub 的 `authorizeIndex` 只读 `.method`/`.url`/`.headers`，trust-fence 自带 `headers instanceof Headers` 双形态分支（`ConnectionTrustRequest` 类型注释即「Fetch 或 node:http 双表示」），Fetch Request 入参天然兼容；新消费 `ctx.connection.browserPeer` 为官方 `HostConnectionService` 自有属性（两代 connection lib 逐字同款、各 4 处，替换服务即官方类实例化，构造时自注册 `ctx.connection`）[非阻断] |
| `@deepseek-ai/dsh-app-boot` | `lib/index.js` 重构：新增 `dsh.bundle.platforms` 可选声明（未声明 = 全平台放行，`assertBundlePlatform` 对 `void 0` 早退）+ startup-diagnostics；`official-bundles*.d.ts` 三件移出至新包 `@deepseek-ai/dsh-official-bundles`（`PROFILE_TEMPLATES`/`DEFAULT_PROFILE_BUNDLES` 新家）；worker bootstrap 同步 | 平台门为 OS 维度（`process.platform`）且可选字段缺省放行（插件包无此字段）；profile patch 读取链 imports（`readProfilePatches`/`loadOverlayPatches`/`reportSkippedBundles`/`PROFILE_PATCH_FILENAME`）逐字一致 [非阻断] |
| `@deepseek-ai/dsh-web-app` | `lib/` 全量零 diff；四个 patch YAML 变化均为 UI bundle 行增删（`message-quotes`/`ui-file-drag`/`deliverable-file-references`/`ui-file-actions`/`ui-context-menu` 增，`ui-deepseek-model-label-1017`/`tool-subagent-list-agents` 删）+ tools 行 PTC env seam 移除 | **connection 行逐字段一致**（审计脚本实测）；gate 行绑定断言的官方行 id/name 形状不变 [非阻断] |
| `@deepseek-ai/dsh`（runtime 本体） | `lib/bin.js`/`lib/profile-boot.js` 越出良性白名单；4 个 chunk 改名且内容有差异 | chunk diff 逐行核对：全部为 import 重排（chunk 哈希改名联动 + `PROFILE_TEMPLATES`/`DEFAULT_PROFILE_BUNDLES` 改从 `dsh-official-bundles` 导入），`authorizeIndex`/BrowserAuth/trustedHosts/connection 零命中；loader seam `resolveSync` 用法逐行一致（审计脚本实测）；gate 探针读 `@deepseek-ai/dsh/package.json` manifest 版本不受影响 [非阻断] |

即 0.2.2-rc.1 的机械阻断项 = 未配对 locale 文件（机械分类器不豁免 locale）+ webserver/frontend-static/app-boot/runtime 的**非替换面**代码演进；§5.1 第 1–3 条（host 入口/构造器/`requestRejection`/`createSharedFetchHandler`/route/body 契约、adapter 无分支、client bundle 契约）由「逐字节一致 + 逐行为等价」直接满足，不满足任一条即不得收编（本轮如 frontend-static shim 语义有出入，第 5 条组合测试会红，fail-closed）。第 4–5 条由本轮测试满足：

- gate 探针/profile 解析：`0.2.2-rc.1` 精确对正例；同代际跨 minor 混合负例由 gate 全 N×N 循环自动覆盖（必须 dormant）。
- 真实 npm fixture：登记表追加 `*-rc221` 别名（真实 0.2.2-rc.1 包），`active-generations` / `npm-flat-generations` 循环套件自动扩展到 0.2.2-rc.1（full active checklist + `/connect` 302/400/403 + 同代际跨 minor 混合双向 dormant）——**组合套件直接运行真实 0.2.2-rc.1 的 webserver（resource 分发）与 frontend-static（shim + `browserPeer` 消费），本轮两项新消费面由实证覆盖，非纯推理**。
- `tests/manifest.test.mjs`：rc221 保持 fixture-only 别名。

第 6 条（真实 DSH 0.2.2 宿主 active checklist）已在 2026-11-04 的 DSH Web `0.2.2-rc.1` 宿主（Host A＝pnpm runtime 形态）通过：启动日志出现 BrowserAuth 跳过横幅恰一次，未携带 token 的 `GET /` 返回 200；`skipping profile bundle` 恰 1 条且为第三方 dsh-ops@0.4.4（其 `engines.dsh` 上界 `<0.2.2-0` 排除 rc.1，与本插件无关），本插件守卫零拒载。Desktop 仍按设计休眠。

### 5.15 审计记录：`0.2.2-rc.2` 加入 `carrier-neutral-v4`（2026-11-12）

结论：**`0.2.2-rc.2` 经打包层审计后通过 §5.1 全部条件，作为第七个 pair 加入 `carrier-neutral-v4`**，未新增 adapter/client variant（rc21 继续锚定 0.2.1-rc.1，不引入第二个构建输入）。本轮机械判级 CONTRACT-CHANGED 的全部阻断项均为打包层：rc.2 起锚点包 tarball 随附源码与 sourcemap（release note「npm 安装与桌面端随附对应版本的源码和文档」），两处核心 bundle 改为压缩重打包，runtime tarball 新增随附文档树。

审计方法：`npm run audit-candidate -- 0.2.2-rc.2`（基准自动取 `0.2.2-rc.1`，机器初判 CONTRACT-CHANGED，退出码 3）；随后对保留的审计目录逐文件人工定性，压缩重打包按语义面复核（导出面/handle 键集合经 Node vm 实例化 `apply()` 对比）。逐包结果：

| 包 | 0.2.2-rc.1 → 0.2.2-rc.2 差异 | 人工定性 |
| --- | --- | --- |
| `@deepseek-ai/dsh-client-connection` | `lib/client.browser.js` 由 pretty（1522 行）改为 minified 单行重打包；新增全部 `*.map` 与 `src/**` | **替换面逐字节一致**：`lib/index.js` 与 `lib/client.node.js` 无 diff；同名 `lib/types/**/*.d.ts` 12 件零差异；压缩 bundle 在 vm 中 `apply()` 实例化后 handle 逐键等价（generation/state `{getSnapshot,subscribe}`/rpc `{call}`/openWebSocket/reconnect/registerGenerationSource/start/interactions/isLoopback），导出面同为 `{RpcId,apply,inject,installConnection,transportError}`，ModuleLoader id 与 `inject=[]` 一致，`__DSH_TRANSPORT__`/`__DSH_CONNECTION_RECOVERY__` 消费一致，multipart 二进制解析 rc.1 已有非新增 [非阻断] |
| `@deepseek-ai/dsh-host-webserver` | 仅新增 `*.map` 与 `src/**` | `lib/index.js` 与同名 d.ts 逐字节一致 [非阻断] |
| `@deepseek-ai/dsh-scope` | 仅新增 `*.map` 与 `src/**` | `lib/index.js` 与同名 d.ts 逐字节一致 [非阻断] |
| `@deepseek-ai/dsh-invariants` | 两侧均未发布（该线停更延续，无对比物，非差异） | — |
| `@deepseek-ai/dsh-host-frontend-static` | 仅新增 `*.map` 与 `src/**` | `lib/index.js` 与同名 d.ts 逐字节一致 [非阻断] |
| `@deepseek-ai/dsh-app-boot` | `lib/index.js` 增 `wsl` 平台准入（`assertBundlePlatform` 可选 `facts` 参数 + `@deepseek-ai/dsh-native-command` 依赖）与 `.env` home 层 `DEEPSEEK_BASE_URL`/`DEEPSEEK_SEARCH_BASE_URL` 白名单；`bundle-platform.d.ts`/`index.d.ts` 同步；新增 `*.map` 与 `src/**` | REVIEW 类：平台门为本插件不声明的可选字段（缺省放行），`.env` 白名单与 BrowserAuth/connection 无关；`compatibility-preflight.d.ts` rc.1 已存在（本轮仅新增 .map），插件兼容预检层非本轮新增 [非阻断] |
| `@deepseek-ai/dsh-web-app` | 四个 patch YAML 变化均为非 connection 行（presets 增 `tool-subagent-control.interrupt:false`、`tool-office` 行、`skill-filesystem.customSkillDirs`，根 patch 增 `mcp-manager`/`ui-account-notifications`/office kit 行等）+ 新增 `*.map` 与 `src/**` | **connection 行逐字段一致**（审计脚本实测）；gate 行绑定断言的官方行 id/name 形状不变 [非阻断] |
| `@deepseek-ai/dsh`（runtime 本体） | `lib/profile-boot.js` 增 `userAgentProfile` 再导出（release note「模型请求的 User-Agent 增加启动配置标记」）；`lib/bin.js` 压缩重打包（白名单内 Desktop CLI）；4 个 chunk 改名且内容有差异；`lib/dump-config-DuXZcU0e.js`（90 字节垫片）单侧移除；新增随附 `docs/` 文档树（含 png/svg/json 静态资产）与 `*.map`、`src/**`、`lib/types/installed-bin.d.ts` | loader seam `resolveSync` 用法逐行一致（审计脚本实测 4/4）；垫片唯一长标识符已被 rc.2 lib 覆盖；gate 探针读 `@deepseek-ai/dsh/package.json` manifest 版本不受影响 [非阻断] |

即 0.2.2-rc.2 的机械阻断项 = 打包清单变化（`src/`+sourcemap 单侧出现、压缩重打包计为代码 diff、docs 资产非 `.md` 计为未配对代码文件）；§5.1 第 1–3 条由「逐字节一致 + 语义面等价」直接满足，不满足任一条即不得收编（如 client handle 契约有出入，第 5 条组合测试会红，fail-closed）。第 4–5 条由本轮测试满足：

- gate 探针/profile 解析：`0.2.2-rc.2` 精确对正例；同代际跨 patch 混合负例由 gate 全 N×N 循环自动覆盖（必须 dormant）。
- 真实 npm fixture：登记表追加 `*-rc222` 别名（真实 0.2.2-rc.2 包），`active-generations` / `npm-flat-generations` 循环套件自动扩展到 0.2.2-rc.2（full active checklist + `/connect` 302/400/403 + 同代际跨 patch 混合双向 dormant）——组合套件直接运行真实 0.2.2-rc.2 的 webserver 与 frontend-static 包。
- `tests/manifest.test.mjs`：rc222 保持 fixture-only 别名。

第 6 条（真实 DSH 0.2.2-rc.2 宿主 active checklist）已在 2026-11-12 的 DSH Web `0.2.2-rc.2` 宿主（Host A＝pnpm runtime 形态，宿主 runtime 与本插件 0.4.9 同日装机）通过：每次 boot 启动日志出现 BrowserAuth 跳过横幅恰一次（当日 16:05/16:10 两次 boot 共 2 条，16:10 那次为宿主 app-exit 自重启机制所致、非崩溃），未携带 token 的 `GET /` 返回 200 且为应用壳（`__DSH_BOOT__` 在场），`skipping profile bundle` 为 0——第三方 dsh-ops 已发 0.5.4（engines 放宽至 `<0.2.3-0`），§7.7/§5.14 时代的守卫拒载基线自然解除；`did not activate` 与 `waiting for service:` 均为 0。Desktop 仍按设计休眠。

### 5.16 审计记录：`0.2.2-rc.3` 加入 `carrier-neutral-v4`（2026-11-13）

结论：**`0.2.2-rc.3` 通过 §5.1 全部条件，作为第八个 pair 加入 `carrier-neutral-v4`**，未新增 adapter/client variant（rc21 继续锚定 0.2.1-rc.1，不引入第二个构建输入）。

审计方法：`npm run audit-candidate -- 0.2.2-rc.3`（基准自动取 `0.2.2-rc.2`）。机器判级 **RE-PUBLISH**（退出码 0，§5.13 以来首个非 CONTRACT-CHANGED 轮）：八个锚点包全部仅 package.json/README/docs 差异，`@deepseek-ai/dsh-invariants` 两侧均未发布（该线停更延续，无对比物），web-app patch 连续第三轮零 diff（connection 行逐字段一致）。§5.1 第 4–5 条由本轮测试满足：

- gate 探针/profile 解析：`0.2.2-rc.3` 精确对正例；同代际跨 patch 混合负例由 gate 全 N×N 循环自动覆盖（必须 dormant）。
- 真实 npm fixture：登记表追加 `*-rc223` 别名（真实 0.2.2-rc.3 包），`active-generations` / `npm-flat-generations` 循环套件自动扩展到 0.2.2-rc.3（full active checklist + `/connect` 302/400/403 + 同代际跨 patch 混合双向 dormant）——组合套件直接运行真实 0.2.2-rc.3 的 webserver 与 frontend-static 包。
- `tests/manifest.test.mjs`：rc223 保持 fixture-only 别名。

第 6 条（真实 DSH 0.2.2-rc.3 宿主 active checklist）待宿主升级 0.2.2-rc.3 后按 DESIGN 清单执行并回填本条与 README 状态列。

## 6. 当前验证状态

已通过：

- profile exact pair、mixed pair、unknown pair、path/manifest drift、npm/pnpm fallback
- 0.1.2-rc.1 legacy active composition
- 0.1.5-rc.1 真实 npm package carrier-neutral composition
- 0.1.5-rc.2 真实 npm package carrier-neutral composition（含跨 patch 混合 dormant，见 §5.3）
- 0.1.5-rc.1 `connection.rpc.handle()` dedicated channel 不再返回 405
- 0.1.5-rc.1 exact `/api` streaming Fetch route
- 0.1.5-rc.1 recovery/profile index globals
- 0.1.7-rc.2 真实 npm package carrier-neutral-v3 composition（§5.4：admit/OperatorPeer、waterfall、303 `./`、dedicated RPC 非 405、双向跨代际混合 dormant、npm flat 布局）
- 0.1.7-rc.1 真实 npm package carrier-neutral-v3 composition（§5.5：full active checklist、同代际跨 patch 混合双向 dormant、跨代际 dormant、npm flat 布局）
- 0.2.0-rc.1 真实 npm package carrier-neutral-v3 composition（§5.6：full active checklist、跨 minor 混合双向 dormant、跨代际 dormant、npm flat 布局）
- 0.2.0-rc.2 真实 npm package carrier-neutral-v3 composition（§5.7：full active checklist、同代际跨 patch 混合双向 dormant、npm flat 布局）
- 0.2.1-rc.1 真实 npm package carrier-neutral-v4 composition（§5.9：full active checklist、`/connect` 交换端点、跨代际混合双向 dormant、行代际分区、npm flat 布局）
- 0.2.1-rc.2 真实 npm package carrier-neutral-v4 composition（§5.10：full active checklist、`/connect` 交换端点、同代际跨 patch 混合双向 dormant、npm flat 布局）
- 0.2.1-rc.3 真实 npm package carrier-neutral-v4 composition（§5.11：full active checklist、`/connect` 交换端点、同代际跨 patch 混合双向 dormant、npm flat 布局）
- 0.2.1-rc.4 真实 npm package carrier-neutral-v4 composition（§5.12：full active checklist、`/connect` 交换端点、同代际跨 patch 混合双向 dormant、npm flat 布局）
- 0.2.1-rc.5 真实 npm package carrier-neutral-v4 composition（§5.13：full active checklist、`/connect` 交换端点、同代际跨 patch 混合双向 dormant、npm flat 布局）
- 0.2.2-rc.1 真实 npm package carrier-neutral-v4 composition（§5.14：full active checklist、`/connect` 交换端点、同代际跨 minor 混合双向 dormant、npm flat 布局）
- 0.2.2-rc.2 真实 npm package carrier-neutral-v4 composition（§5.15：full active checklist、`/connect` 交换端点、同代际跨 patch 混合双向 dormant、npm flat 布局）
- 0.2.2-rc.3 真实 npm package carrier-neutral-v4 composition（§5.16：full active checklist、`/connect` 交换端点、同代际跨 patch 混合双向 dormant、npm flat 布局）
- rc2 dormant 基线
- 三个官方 client factory materialization 和 unknown profile fail-closed
- `npm run test:all`：三代际全量测试通过；真实机器 pnpm layout 检查按当前环境条件跳过。
- 真实 DSH `0.1.7-rc.2` 宿主 active checklist + 卸载回滚演练（2026-09-26，见 `docs/DESIGN.md`）。
- 真实 DSH `0.2.0-rc.1` 宿主 active checklist（2026-09-29：宿主当日运行 rc.1，`/` 200、BrowserAuth skipped 横幅在案）。
- host profile 门控（§7）：desktop 桩包在场 + 白名单 pair ⇒ 组合级整体休眠；desktop-host 查询抛错/空值/怪值按包不存在处理（web 继续）。

尚未宣称：

- 在真实运行 DSH `0.1.5-rc.1` 服务上的 active 部署结果。该验证应按 `docs/DESIGN.md` active checklist 执行并记录。
- 在真实运行 DSH `0.1.5-rc.2` 服务上的 active 部署结果（升级宿主后按同一清单执行）。
- 在真实运行 DSH `0.1.7-rc.1` 服务上的 active 部署结果（宿主运行 rc.1 时按同一清单执行）。
- 在真实运行 DSH `0.2.0-rc.2` 服务上的 active 部署结果（宿主已于 2026-09-29 升级 rc.2；本插件 0.3.5 装机后按 DESIGN 清单执行并回填本节）。
- 在真实运行 DSH `0.2.1-rc.1` 服务上的 active 部署结果（宿主升级 0.2.1 后按 DESIGN 清单执行并回填；届时 §7.7 同步补 web 零回归断言）。

已知无关问题（非本插件职责，记录备查）：同宿主上第三方插件对 0.1.7 的不适配——`dsh-auth` 的 `/auth/login` 在 edge 请求下因 `ctx.settings.get()`（其源码自注的 rc.1 shim）对 0.1.7 settings API 抛 TypeError；`modsearch` 报 `scope.settings.register is not a function`（同一 settings API 变化）；`copilot-authorization` 与官方 `dsh-authorization` 服务重名冲突。定性依据：dsh-auth 代码不依赖 connection 服务（登录页渲染路径无 connection 消费）；该 TypeError 首次出现于 2026-09-26 宿主升级 0.1.7 之后，与本插件激活无关（升级后至插件激活前 `/auth/login` 零访问，TypeError 首次触发于插件激活 51 秒后的 edge 请求，与同 boot 的 modsearch/settings 报错同源）。未做卸载态下的 edge 复现差分。

## 7. Host profile policy

> 2026-10-07 定稿（任务书 §0-§4 + 实机实测）。决策不重开；本节是 host profile 维度的唯一权威记录处。

### 7.1 判定依据

desktop 上 Electron 启动自带 token ⇒ 插件收益趋零；desktop 无版本审计、无实机 active checklist；插件经 dsh-m 公开分发且 agent 是第一安装群体 ⇒ 需要代码级护栏而非文档约定。**拦「激活」不拦「安装」**：desktop 上可装、但必须休眠（dormant，非 fail-loud、非市场层拒装）。

### 7.2 信号与语义（0.3.8 三重判别，default-deny）

设计公理（0.3.6 事故后确立，跨 Windows/macOS/Linux 全平台生效）：**激活需要正向 web 证明，休眠不需要理由**——误激活 desktop ⇒ 宿主不可启动；误休眠 web ⇒ 回到 token 输入且一分钟可定位（know-how 016 判别法）。伤害不对称 ⇒ 举证责任在激活侧。

| # | 判别 | 信号 | 命中判定 |
| --- | --- | --- | --- |
| ① | desktop 否决 | `resolveSync(ctx.baseUrl, 'dsh-desktop-host/package.json')` 得合法 `{url: string}`（表达式层内联 + `detectHostProfile()` 镜像）。**注意平台差异**：该包不可达时，web 机 resolver 返回 null，desktop 机 resolver **抛错**（真机探针实证）——两平台都要落到「非 desktop」分支 | desktop ⇒ 休眠 |
| ② | desktop 否决 | 宿主进程 `process.argv` 含 `dsh-desktop-host`（desktop 宿主以 `[execPath, dsh-desktop-host/lib/index.js, <dsh>, <profileDir>, …]` 启动；与官方 dsh-plugin-manager `isPackagedDesktopArgv` 同款 launcher fact） | desktop ⇒ 休眠 |
| ②′ | desktop 否决 | `ctx.baseUrl` 目录基名（大小写归一）=== `desktop`——desktop 客户端恒以 profiles/desktop 槽位启动 loader（官方 `desktopProfileDirFromArgv` 契约），**进程树形状无关**（0.3.8 事故形态：宿主以纯 node 子进程跑 loader，argv/execPath 双双落空） | desktop ⇒ 休眠 |
| ③ | web 证明 | 宿主二进制 `process.execPath` 基名（大小写归一）∈ {node, node.exe, nodejs, nodejs.exe}——Windows/macOS/Linux web 全形态（systemd/docker/nvm/fnm/volta/mise/直接 node）经解释器 exec 后恒为 node 系二进制；desktop 宿主（Electron run-as-node）恒非 node 系 | 不成立 ⇒ desktop ⇒ 休眠 |

判定式：①∨②′∨② 命中 或 ③ 不成立 ⇒ desktop（休眠）；全否 ⇒ web，继续版本对判定。**实现纪律（0.3.11 事故教训）：每个信号必须独立 try/catch——信号①在 desktop 上的 throw 绝不允许跳过其余信号**。resolver 缺失 ⇒ 探针 `null`（休眠）。检测异常的 fail-closed 兜底是版本对判定本身：真异常时双锚点同样解析失败 ⇒ `null`。

### 7.3 fail-closed 语义（双层）

- 探针层（表达式）：desktop ⇒ `GATE_PROFILE_EXPRESSION` 为 `null`（由白名单表条目 `hostProfiles: ['web']` 条件统一拒绝，策略单一来源 `src/compatibility.ts`）⇒ 官方行 enabled、trusted 行 disabled、apply 不运行——安静休眠，与未知版本对同形态（判别法见 know-how 016）。
- backstop 层（`assertGateBackstop`）：desktop ⇒ fail loud，完整文案 `@iasiv5/dsh-skip-browser-auth: desktop profile not supported; disable or uninstall the plugin (@deepseek-ai/dsh-desktop-host present)`——仅防「patch 激活但不应激活」的绕过态。**0.3.12 起本分支由 apply 前置判别承接（desktop ⇒ 静默休眠 no-op，见 §7.8），正常不可达，保留为纵深防御**。

### 7.4 残余风险与事故记录（书面化）

- **【事故 2026-10-07/08，两阶段缺陷，已修复于 0.3.10；探针/crash log 实证 2026-10-08】**
  - 宿主架构（探针实证）：desktop 宿主为多进程树——Electron main → ChildProcess（dsh-desktop-host/lib/index.js，**loader 与插件在此进程内**，Electron run-as-node，node 24.18.1）；信号①的 desktop-host 包在 app.asar 内、自 profile baseUrl **不可达**（THROW: Cannot find package）；信号②（argv[1] 恒含 dsh-desktop-host）、信号②′（baseUrl 槽位=desktop）、信号③（execPath 为 Electron exe 非 node）在该进程**全部成立**。
  - ① 0.3.6：仅凭信号①误判 web ⇒ 激活 ⇒ "Desktop Host authentication failed"。
  - ② 0.3.8/0.3.9：宿主侧判别已正确休眠，但**客户端半区**漏修——休眠时宿主仍注入 client bundle 且不注入 profile global，client dispatcher 读缺失 global 直接 throw ⇒ 客户端启动链断裂 ⇒ dsh-desktop-host 读 `undefined.authenticatedUrl`（crash-2026-10-07T17-11-31 / 17-35-15 host.log 实证，两版签名一致）。
  - **0.3.10 修复 = 客户端 dispatcher 休眠静默 no-op（绝不 throw、绝不猜测变体）**；宿主侧三信号 + 槽位判别保留。
  - 教训：**休眠必须全链路静默（宿主行、客户端 bundle、配置表达式），任何半区的 throw 都可能炸宿主；desktop 实机验证前置为该维度变更的发布门禁（0.3.10 起执行）**。
- desktop 未来若移除/改名信号包 ⇒ 信号①失效，但②②′③仍在 ⇒ 仍休眠（①自 0.3.8 起已非唯一判据）。
- **【事件 2026-10-11，非崩溃、报错风暴，收编于 0.3.12（§7.8）】**：desktop 上用户层 patch 按行 id 写 `- id: trusted-connection  disabled: false`（dsh-m 插件开关 / `dsh plugin add` enable 通道的标准产物，2026-10-11 Windows 实机实录）合法覆盖自门控 `!!js` disabled 表达式 ⇒ 行强制 active、apply 被调 ⇒ 0.3.11 及以前 backstop fail loud，且每次任意插件开关触发热重载都弹 `desktop profile not supported`。教训：**组合期门控可被用户层合法覆盖，不承担语义；apply 内判定才是权威**；良态强制启用必须静默休眠而非报错。
- 对偶风险（web 侧反向污染）：web profile 下第三方插件经 hoisted 抬升携带 `@deepseek-ai/dsh-desktop-host` 依赖（gate.ts 头注记载的同类抬升遮蔽机制）⇒ 信号①误真 ⇒ 本插件安静休眠——方向 fail-closed，最坏损失是本插件不工作，无安全暴露；且信号③（web 宿主为 node 二进制）不受抬升影响，仍为独立兜底。本仓库自身不可能引入该包：manifest 不变量（红线：dependencies 禁止任何 `@deepseek-ai` 包）+ `tests/manifest.test.mjs` 看护。
- desktop runtime 版本对（如 0.2.0-rc.2）与 web 白名单共享 ⇒ 判别信号失效时存在误激活暴露。兜底：任何新 runtime 版本进入白名单前必须走 §5.1 审计流程（届时必然重审 desktop 形态）+ 下述解冻条件。

### 7.5 解冻条件（本次不实现）

同时满足才允许把 `'desktop'` 加入 hostProfiles：

1. 出现真实 desktop 需求；
2. desktop 信号 + fixture 全套验证；
3. desktop 实机 checklist（无 token `GET /` 401→200、伪造 Host → 403、`/?token=x` → 303、卸载后官方行为原样恢复）+ 暴露模型书面化（回环绑定 + 本机进程可信度假设）。基线形态见 `docs/DESKTOP-DORMANT-CHECKLIST.md`。

### 7.6 实机事实（2026-10-07）

- desktop runtime 0.2.0-rc.2（`dsh --version` 与 runtime.json `desktopVersion` 双证）；Desktop Web GUI 以 127.0.0.1:19387 仅回环绑定（netstat 实证）。
- BrowserAuth 激活中：无 token `GET /` → 401；伪造 Host → 401（休眠态无栅栏，401 即正确，勿误判）。
- `app.asar/dsh/node_modules/@deepseek-ai/dsh-desktop-host/` 存在（堆栈实证）；web runtime 树无此包（web 机 `ls ~/.dsh/profiles/node_modules/@deepseek-ai/ | grep -c "dsh-desktop-host$"` = 0，2026-10-07 复核）。
- fixture 层实测补充：rc202 官方组合休眠态在最小 fixture 下 `/`、`/api/*` 均为 404 空体（0.2.0 代际 frontend-static 走 registerFallback + authorizeIndex(BrowserAuth)，无凭据最小环境不服务索引；webserver 默认 404 空体，与 0.1.1-rc.2 代际的 `'not found'` 文本体不同），见 `tests/composition/desktop-dormant.test.mjs` 注释。

### 7.7 实机状态（发版后回填）

- web 0.2.0-rc.2 升级零回归断言（历版全过）：0.3.6（2026-10-07 22:44）、0.3.8（2026-10-08 01:41）、0.3.9（01:41 修复版）、0.3.10（02:23）、0.3.11（10:23:24 重启后横幅逐字输出、无 token `GET /` 200、伪造 Host 403、`/?token=x` 303 `location: ./`）；web profile 预检 `grep -c "dsh-desktop-host$"` = 0。
- desktop dormant 基线断言（0.3.11）：**已通过（2026-10-08，Windows 实机）**——安装 0.3.11 后 Desktop 正常启动（不再崩溃）、无 "BrowserAuth has been skipped" 横幅、休眠态无 token 访问 401×2 符合预期、GUI 与 agent 会话正常。0.3.6-0.3.10 在 desktop 均无法启动（§7.4 事故），desktop 用户请使用 0.3.11+。

### 7.8 运行时权威休眠（0.3.12，用户层 pin 覆盖收编）

- **分层语义**：组合期 `!!js` 表达式 = 优化（避免无谓 apply；可被用户层 id-pin 合法覆盖——dsh-m 开关 / `dsh plugin add` enable 通道的标准产物，见 §7.4 事件 2026-10-11——因此不承担语义）；**apply 内宿主判别 = 唯一权威**。
- **apply 结构（0.3.12）**：① 最前置 `detectHostProfile()`（resolver 允许 undefined，信号①自行消化；槽位/argv/execPath 信号不依赖 resolver）——desktop ⇒ 固定文案 `desktop host detected — dormant by design (web-only plugin); official connection untouched. Safe to uninstall.` + return（零 throw、零配置校验、零副作用）；② web 路径照旧：配置校验 → backstop 四类契约破坏 fail loud。backstop 内的 desktop throw 保留为纵深防御（正常不可达）。
- **不变量**：desktop 激活三关不减（镜像判 web ∧ 白名单 pair ∧ binding 完好）；官方 connection 行表达式、client 半区（0.3.10 inert no-op）、web 全路径零改动；新增路径仅纯函数判定 + 一行 `console.warn`，无文件/网络/服务操作。
- **§7.4 四类历史模式预演（2026-10-11 会话留档）**：①2026-09-10 apply-throw 崩溃循环——desktop 分支零 throw，不回归；②0.3.6 组合期误判——激活三关未减，镜像判对时 no-op 优于 throw（throw→行失败→官方行若已被误禁→connection 缺失，两版同等，0.3.12 不恶化）；③0.3.8/0.3.9 client 半区——0.3.10 已修，pinned 态不注入 global ⇒ client 走同一 inert 路径，与实机 PASS 的休眠基线运行时同态；④0.3.11 信号控制流——不触碰 `detectHostProfile`/表达式，每信号独立 try/catch 原样。
- **desktop 实机 checklist 新增断言（0.3.12 起）**：pin 态（`disabled: false` 在用户层在场）下 dsh-m 开关任意插件零报错横幅、日志恰一行 dormant 通知、Desktop 正常启动。
