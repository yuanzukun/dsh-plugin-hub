# 更新日志

本文件格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，版本号遵循语义化版本。
逐版列出面向使用者的变更及当时兼容的 DSH 版本对；白名单之外的版本对插件**自动休眠**，官方行为分毫不变
（详见 [README · 兼容版本与 profile](./README.md#兼容版本与-profile)）。

## [0.4.1] - 2026-10-17

- 新增 DSH `0.2.1-rc.2` 支持：`npm run audit-candidate` 审计为契约面等价重发布（REPUBLISH-WITH-REVIEW）——connection/webserver/scope/frontend-static/app-boot/runtime 全部仅 manifest bump（本轮回零代码 diff），web-app patch 仅新增非 connection 行（`ui-deepseek-model-label-1017`），**connection 行逐字段一致**；按 §5.1 作为第二个 pair 并入 `carrier-neutral-v4`（docs/COMPATIBILITY.md §5.10），未新增 adapter/client variant
- 测试：真实 0.2.1-rc.2 npm fixture 组合套件（full active checklist + `/connect` 302/400/403 + 同代际跨 patch 混合双向 dormant）+ npm flat 回退用例 + gate/patch/manifest 断言
- 审计脚本 `audit-candidate.mjs` 新增 missing-in-base / missing-both-sides 定级：白名单基准本身也可能停更（实证：以 0.2.1-rc.1 为基准时 invariants 两侧均无 0.2.1 线版本）——两侧均缺不构成差异、不降级判级
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.7-rc.1`、`0.1.7-rc.2`、`0.2.0-rc.1`、`0.2.0-rc.2`、`0.2.1-rc.1`、`0.2.1-rc.2`

## [0.4.0] - 2026-10-17

- **新增 DSH `0.2.1-rc.1` 支持（新代际 `carrier-neutral-v4`，非白名单追加）**：`npm run audit-candidate` 契约审计定谳 0.2.1 为真实契约变化（CONTRACT-CHANGED，docs/COMPATIBILITY.md §5.8），按 §5.2 立项实现新代际——新 host adapter `carrier-neutral-021`（`admit()` → 瀑布 → `admission.peer` 透传 bridge + 新 `/connect` 交换通道 + 代际 seam 守卫）、新 `rc21` client variant（锚定 0.2.1 官方 browser 入口 `lib/client.browser.js`）、bundle patch 双行代际拆分（`trusted-connection` 服务 ≤0.2.0 / `trusted-connection-021` 服务 0.2.1+，webRuntime/webStartup 互斥绑定，逐字对齐官方 patch connection 行的同款迁移）、trusted-auth 四方法 stub（新增 `authorizeConnect` 交换：interactions 校验逐字对齐 + 官方成功重定向形态，无身份 cookie）
- §5.8 审计证据要点：connection `OperatorPeer`→`Peer`（peer 台账/principal）重构、bridge 签名新增 `admission.peer`、client bundle 拆分 browser/node、官方 patch `webRuntime`→`webStartup`、scope 剥离 invariants（该包 0.2.1 线停发）；`HostConnectionService` 构造器签名未变
- 测试：真实 0.2.1-rc.1 npm fixture 组合全套（full active checklist、`/connect` 302/400/403、跨代际混合双向 dormant、行代际分区）+ npm flat 回退用例 + gate/patch 结构断言；全量 177 跑 176 过 0 败 1 skip
- **实机 active checklist 待宿主升级 0.2.1 后按 DESIGN 清单执行并回填**（§5.9 第 6 条）；0.2.1 宿主上旧版插件保持安静休眠（官方行为不变）
- 审计脚本 `audit-candidate.mjs` 新增 `missing-in-candidate` 定级：锚点包候选版未发布于 npm 时给出机器初判（至多 REPUBLISH-WITH-REVIEW）而非硬崩；`npm pack --silent` 会吞 ETARGET 错误行，失败后改以不带 `--silent` 的 `npm view` 复核定性
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.7-rc.1`、`0.1.7-rc.2`、`0.2.0-rc.1`、`0.2.0-rc.2`、`0.2.1-rc.1`

## [0.3.12] - 2026-10-11

- **修复 desktop 被用户层强制启用时的报错风暴（pin 覆盖收编，运行时权威休眠）**：dsh-m 插件开关 / `dsh plugin add` enable 通道按行 id 向用户 patch 层写 `- id: trusted-connection  disabled: false`，合法覆盖本插件自门控的 `!!js` disabled 表达式 ⇒ 行强制 active、apply 被调 ⇒ 0.3.11 及以前 backstop fail loud（`desktop profile not supported; disable or uninstall the plugin`），DSH Desktop 上每次开关任意插件触发热重载都弹报错（2026-10-11 Windows 实机实录）
- 修复 = `apply()` 最前置宿主判别：desktop ⇒ 静默休眠 no-op（一行可 grep 通知、零 throw、零配置校验、零副作用）——**apply 内判定是唯一权威，组合期表达式降级为优化**（可被用户层 pin 合法覆盖，不再承担语义）
- 语义对齐：0.3.10 已把客户端半区改为休眠静默 no-op，本版把宿主半区 desktop 分支对齐同一哲学；§7.4 教训（任何半区的 throw 都可能炸宿主）由「desktop 可达的残余 throw」收敛为「仅 web 契约破坏时 throw」
- **web 侧行为零变化**：desktop 分支在 web 不可达（槽位/argv/execPath 组合信号）；锚点解析失败、版本对不在白名单、profile mismatch、binding violated 四类 fail loud 全保留；兼容 DSH 版本对不变
- desktop 实机 checklist 前置门禁照旧执行，并新增断言：pin 态下 dsh-m 开关任意插件零报错横幅；四类历史崩溃模式逐条预演零回归（docs/COMPATIBILITY.md §7.8）
- 测试基建 Windows 可移植修复（helper/脚本层，产品代码零变更）：fixture 脚本 `spawnSync npm`（ENOENT→EINVAL，改 `node npm-cli.js` 直启）、compose 行清单 `{{ROOT}}` 替换改为对象树递归 + `resolve()` 归一（JSON 非法转义 + 混合分隔符触发 frontend-static 路径守卫误报 403 两处）——组合套件自此 Windows 全绿（169 跑 168 过 0 fail 1 skip），web 全白名单 pair 激活/休眠路径本地可证

## [0.3.11] - 2026-10-08

- **修复 desktop 判别的真正根因（控制流缺陷）**：desktop 的 resolver 对 `dsh-desktop-host` 是 **throw**（真机探针实证："Cannot find package…"），而 web 机返回 null——0.3.8-0.3.10 的判别表达式把四个信号放在**同一个共享 try** 里，信号①的 throw 会直接跳到 catch 并落 `'web'`，**跳过 argv/槽位/execPath 全部后续信号** ⇒ 在 desktop 误激活 ⇒ 官方 connection 行被禁用 + backstop fail-loud 使行回滚 ⇒ connection 服务缺失 ⇒ `dsh-desktop-host` 读 `undefined.authenticatedUrl` 启动失败
- 修复 = 每个信号独立 try/catch（任一信号失败/抛错不再影响其余信号），default-deny 语义不变；新增真机形态回归测试（resolver throw + 宿主 argv + desktop 槽位 + Electron execPath + 白名单 pair ⇒ 必须休眠）
- web 侧行为零变化（web resolver 返回 null，判别路径与 0.3.10 一致）；兼容版本对不变
- desktop 实机复核清单：docs/DESKTOP-DORMANT-CHECKLIST.md

## [0.3.10] - 2026-10-08

- **修复 desktop 崩溃的真正根因（客户端半区）**：client dispatcher 在 `__DSH_SKIP_BROWSER_AUTH_PROFILE__` 缺失（休眠）时此前直接 throw，会打断 desktop 宿主的客户端启动链 ⇒ `dsh-desktop-host` 读 `undefined.authenticatedUrl` 启动失败（crash-2026-10-07T17-35 host.log 实证）。现改为休眠静默 no-op（inert namespace，绝不 throw、绝不猜测变体）
- 0.3.9 的安装槽位判别保留（desktop 槽位 ⇒ 宿主侧休眠，crash log 证实 desktop 宿主为多进程树：Electron main → dsh-desktop-host → loader）
- web 侧行为零变化：web 激活路径不变；web 休眠时（未知版本对）client bundle 也不再抛错，官方 client 照常工作
- desktop 实机复核清单：docs/DESKTOP-DORMANT-CHECKLIST.md（正常启动、无横幅、401×2）

## [0.3.9] - 2026-10-08

- 修复：desktop 判别新增**安装槽位信号**（`ctx.baseUrl` 目录基名 === `desktop` ⇒ 休眠）——crash log（`crash-2026-10-07T17-11-31-064Z-host.log`）证实 desktop 宿主为多进程树（Electron main → dsh-desktop-host → 纯 node 子进程跑 loader），0.3.8 的 argv/execPath 信号瞄错进程层仍误判 web；槽位为官方 `desktopProfileDirFromArgv` 契约（desktop 客户端恒用 `profiles/desktop` 槽位），与进程树形状无关
- web 侧行为零变化：web/headless 槽位 + node 宿主照常激活；兼容版本对不变
- desktop 实机复核：见 docs/DESKTOP-DORMANT-CHECKLIST.md（0.3.9 需在 desktop 实机验证正常启动 + 无横幅 + 401×2 后方可视为闭环）

## [0.3.8] - 2026-10-08

- 修复 desktop 门控缺陷：0.3.6 的 desktop 判别仅依赖「dsh-desktop-host 包可解析」，而 desktop profile 为 hoisted 物化布局、该包在 app.asar 内不可达 ⇒ 误判 web ⇒ Replacement 在 desktop 激活 ⇒ "Desktop Host authentication failed" 启动失败（desktop 用户请直接升级本版）
- 新判别（default-deny，三重）：desktop 否决 = 宿主 argv 含 `dsh-desktop-host`（官方 isPackagedDesktopArgv 同款 launcher fact）∨ desktop-host 包可解析；web 证明 = 宿主二进制为 node/node.exe——非 node 二进制或未知宿主一律休眠
- web 侧行为零变化：宿主二进制为 node 时判别结果与 0.3.6 一致；兼容 DSH 版本对不变（`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.7-rc.1`、`0.1.7-rc.2`、`0.2.0-rc.1`、`0.2.0-rc.2`）
- 事故记录与残余风险见 docs/COMPATIBILITY.md §7.4/§7.6；desktop 实机复核清单见 docs/DESKTOP-DORMANT-CHECKLIST.md

## [0.3.6] - 2026-10-07

- 新增宿主 profile 门控：仅支持 web profile；desktop profile（存在 `dsh-desktop-host` 的环境）一律自动休眠（设计行为），探针与 `apply()` backstop 双层 fail-closed
- web 侧兼容版本对不变：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.7-rc.1`、`0.1.7-rc.2`、`0.2.0-rc.1`、`0.2.0-rc.2`
- 新增 `scripts/audit-candidate.mjs`（`npm run audit-candidate -- <version>`）：以白名单最新 pair 为基准自动完成 docs/COMPATIBILITY.md §5.1 第 1–3 条的锚点包 tarball 审计，判级 `RE-PUBLISH` / `REPUBLISH-WITH-REVIEW` / `CONTRACT-CHANGED`（含 connection 行对比与 loader seam 抽查）；离线纯函数单测见 tests/audit-candidate.test.mjs（原 Unreleased 条目随本版发布）
- 新增 `docs/DESKTOP-DORMANT-CHECKLIST.md`（desktop 机休眠基线验证清单）

## [0.3.5] - 2026-09-29

- 新增 DSH `0.2.0-rc.2` 支持（npm diff 审计：插件契约面与 `0.2.0-rc.1` 逐字节一致的依赖对齐重发布 + 无关 Desktop 插件管理 CLI 演进，并入 `carrier-neutral-v3`，见 docs/COMPATIBILITY.md §5.7）
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.7-rc.1`、`0.1.7-rc.2`、`0.2.0-rc.1`、`0.2.0-rc.2`

## [0.3.4] - 2026-09-29

- 新增 DSH `0.2.0-rc.1` 支持（npm diff 审计：插件契约面与 `0.1.7-rc.2` 逐字节一致的依赖对齐重发布，并入 `carrier-neutral-v3`，见 docs/COMPATIBILITY.md §5.6）
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.7-rc.1`、`0.1.7-rc.2`、`0.2.0-rc.1`

## [0.3.3] - 2026-09-28

- 纯版本号 bump（仅 package.json version，无代码变更）

## [0.3.2] - 2026-09-28

- 修复：connection-runtime 固定开发副本改为按需动态加载，避免部分环境下加载报错
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.7-rc.1`、`0.1.7-rc.2`

## [0.3.1] - 2026-09-26

- 新增 `carrier-neutral-v3` 代际，适配 DSH `0.1.7-rc.1` / `0.1.7-rc.2`：`admit()`/OperatorPeer 准入、`connection/request` waterfall、mount-preserving BrowserAuth 与 0.1.7 client variant
- 修复：干净工作树上 `npm ci` 可复现（此前导致 CI 发布 ERESOLVE）
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`、`0.1.7-rc.1`、`0.1.7-rc.2`

## [0.2.2] - 2026-09-14

- package.json 描述对齐市场收录文案（描述元数据由插件自管，无功能变更）
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`

## [0.2.1] - 2026-09-10

- 新增 DSH `0.1.5-rc.2` 支持（rc.2 为 rc.1 代码逐字节一致的重新发布版，并入 `carrier-neutral-v2`）
- 仓库 `.npmrc` 固定公共 registry（CI 可移植）
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`、`0.1.5-rc.2`

## [0.2.0] - 2026-09-10

- 多代际兼容 profile：新增 DSH `0.1.5-rc.1`（`carrier-neutral-v2`：carrier-neutral HostConnectionService + 0.1.5 client variant，含 dedicated RPC 非 405 与 exact `/api` Fetch route 适配）；`0.1.2-rc.1` 维持 `legacy-web-v1`
- 兼容 DSH：`0.1.2-rc.1`、`0.1.5-rc.1`

## [0.1.3] - 2026-09-05

- 许可证规范化：标准 MIT 模板，上游声明移入 [NOTICE](./NOTICE)
- 兼容 DSH：`0.1.2-rc.1`

## [0.1.2] - 2026-09-05

- 门控探测锚定宿主运行时（而非随包 connection 副本）；npm flat 布局下经 manifest 回退确认版本
- 兼容 DSH：`0.1.2-rc.1`

## [0.1.1] - 2026-09-05

- 发布链修复：lockfile resolved URL 固定 registry.npmjs.org、补 repository 元数据（npm provenance 校验）
- 补充状态徽章与兼容版本表
- 兼容 DSH：`0.1.2-rc.1`

## [0.1.0] - 2026-09-05

- 首发：DSH `0.1.2-rc.1`（`legacy-web-v1`）自动跳过 BrowserAuth，打开 Web 地址即可直接使用，无需抄启动 URL 里的随机 token
- 精确版本对门控 + 自门控 bundle patch：版本不匹配 / 解析失败自动休眠，官方行为分毫不变
- 兼容 DSH：`0.1.2-rc.1`

[Unreleased]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.4.1...HEAD
[0.4.1]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.12...v0.4.0
[0.3.12]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.11...v0.3.12
[0.3.11]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.10...v0.3.11
[0.3.10]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.9...v0.3.10
[0.3.9]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.8...v0.3.9
[0.3.8]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.6...v0.3.8
[0.3.6]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.5...v0.3.6
[0.3.5]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.4...v0.3.5
[0.3.4]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.3...v0.3.4
[0.3.3]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.2...v0.3.3
[0.3.2]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.2.2...v0.3.1
[0.2.2]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.1.3...v0.2.0
[0.1.3]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/iasiv5/dsh-skip-browser-auth/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/iasiv5/dsh-skip-browser-auth/releases/tag/v0.1.0
