// 以别名安装真实 0.1.5 组合测试产物：--no-save --package-lock=false。
// fixture 只改变 node_modules；脚本用安装前后的文件快照证明 package.json/
// package-lock.json 未被临时安装改写。需要 npm 网络访问。
import { execFileSync } from 'node:child_process'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'

const root = dirname(dirname(fileURLToPath(import.meta.url)))
const trackedFiles = ['package.json', 'package-lock.json']
const before = new Map(trackedFiles.map((file) => [file, readFileSync(join(root, file), 'utf8')]))
const childEnv = { ...process.env }
for (const key of ['npm_config_allow_scripts', 'NPM_CONFIG_ALLOW_SCRIPTS']) delete childEnv[key]

// 跨平台 npm 调用：Windows 上 spawnSync 禁止直接起 .cmd（CVE-2024-27980，EINVAL），
// 改为 node <npm-cli.js> 直启（npm-cli.js 恒在 <node 目录>/node_modules/npm/bin/）。
function runNpm(args, opts) {
  if (process.platform === 'win32') {
    const npmCli = join(dirname(process.execPath), 'node_modules', 'npm', 'bin', 'npm-cli.js')
    return execFileSync(process.execPath, [npmCli, ...args], opts)
  }
  return execFileSync('npm', args, opts)
}

runNpm([
  'install',
  '--no-save',
  '--package-lock=false',
  '--ignore-scripts',
  '--force',
  // Keep both real generations in node_modules: npm's peer resolver otherwise
  // removes the older aliases when the second generation is installed alone.
  // rc152 aliases carry the 0.1.5-rc.2 republish (rc.1-identical code, bumped
  // manifest) so composition tests exercise the exact versions the gate pins.
  'dsh-client-connection-rc2@npm:@deepseek-ai/dsh-client-connection@0.1.1-rc.2',
  'frontend-static-rc2@npm:@deepseek-ai/dsh-host-frontend-static@0.1.1-rc.2',
  '@deepseek-ai/dsh-host-apiproxy@0.1.1-rc.2',
  'dsh-client-connection-rc15@npm:@deepseek-ai/dsh-client-connection@0.1.5-rc.1',
  'frontend-static-rc15@npm:@deepseek-ai/dsh-host-frontend-static@0.1.5-rc.1',
  'webserver-rc15@npm:@deepseek-ai/dsh-host-webserver@0.1.5-rc.1',
  'dsh-client-connection-rc152@npm:@deepseek-ai/dsh-client-connection@0.1.5-rc.2',
  'frontend-static-rc152@npm:@deepseek-ai/dsh-host-frontend-static@0.1.5-rc.2',
  'webserver-rc152@npm:@deepseek-ai/dsh-host-webserver@0.1.5-rc.2',
], { cwd: root, stdio: 'inherit', env: childEnv })

for (const file of trackedFiles) {
  const after = readFileSync(join(root, file), 'utf8')
  if (after !== before.get(file)) throw new Error(`rc15 fixture install modified ${file}`)
}
console.log('rc15 fixture installed; package.json and package-lock.json unchanged')
