/**
 * dsh-adhd-copilot — ADHD behavioral coaching skill for DeepSeek Harness.
 *
 * Packages the ADHD Copilot coaching methodology (SKILL.md + 11 references/
 * files, shipped verbatim under skills/adhd-copilot/) as a DSH plugin with
 * one agent-callable tool:
 *
 *   - adhd_breakdown : scan the user's task + state signals, route through
 *     the eight modules (M1 task-breaker, M2 external-brain,
 *     M3 dopamine-architect, M4 body-double, M5 interest-gamifier,
 *     M6 time-auditor, M7 adhd-reset, M8 router) and produce a structured
 *     single-next-action coaching breakdown following the skill's core
 *     workflow: pre-flight gate → state classification → minimal action
 *     (1-3 steps) → self-contained execution → optional feedback.
 *
 * Pure ESM, zero build step, zero runtime dependencies. The tool is
 * registered via raw ctx.tools.register (ToolSchema.parameters is plain
 * JSON Schema), so the published package needs nothing beyond cordis.
 *
 * Note: DSH ships no confirmed `skills` service in the reference agent, so
 * this plugin deliberately registers ONLY the tool (safer). The verbatim
 * skill content under skills/adhd-copilot/ is the deliverable value and is
 * packaged into the npm artifact via the `files` field.
 */

export const name = 'dsh-adhd-copilot'
export const inject = ['tools']

// ---------------------------------------------------------------- methodology

export const MODULES = {
  M1: {
    title: '任务破碎机',
    name: 'Task Breaker',
    state: 'A 启动困难',
    ref: 'M1-task-breaker.md',
    whyNow: '启动最难：第一个动作必须明显、微小、现在就能做。一次只给 1-3 步，每步 <60 秒，跑完再要。',
    timebox: '第一步 <60 秒；1-3 步为一轮，跑完再要',
    energy: '低',
  },
  M2: {
    title: '外部大脑',
    name: 'External Brain',
    state: 'B 事情太多',
    ref: 'M2-external-brain.md',
    whyNow: '大脑清空，消除未完成事项的认知负载。现在区只留 1 件事 + 唯一 Next Action，其余全部进"稍后"或"废弃"。',
    timebox: '现在区只留 1 件事 + 唯一 Next Action',
    energy: '低',
  },
  M3: {
    title: '多巴胺建筑师',
    name: 'Dopamine Architect',
    state: 'E 没动力',
    ref: 'M3-dopamine-architect.md',
    whyNow: '按能量水平配置刺激，维持动力。先问电量，再按电量配菜单（开胃菜 / 主菜 / 配菜）。',
    timebox: '开胃菜 5 分钟 / 主菜 20 分钟 / 配菜 10 分钟（可调）',
    energy: '按电量 10% / 30% / 60% / 90%',
  },
  M4: {
    title: '起跑与回归仪式',
    name: 'Launch & Return Ritual',
    state: 'C 容易分心',
    ref: 'M4-body-double.md',
    whyNow: '利用社交在场感促进启动。诚实版：AI 无法在执行期间出现 → 给一份自足启动指令，用户能带走执行。',
    timebox: '最小动作 <60 秒；检查点全可选',
    energy: '中（需要陪伴启动）',
  },
  M5: {
    title: '兴趣游戏化',
    name: 'Interest Gamifier',
    state: '仅 opt-in',
    ref: 'M5-interest-gamifier.md',
    whyNow: '仅当用户明确要求（opt-in）。先问叙事风格（RPG / 认真 / 极简），尊重选择；包装后必须给即时奖励。',
    timebox: '与包装后的任务一致',
    energy: '低-中',
  },
  M6: {
    title: '时间审计员',
    name: 'Time Auditor',
    state: 'D 时间误估',
    ref: 'M6-time-auditor.md',
    whyNow: '纠正低估时间的认知偏差。预计 vs 现实三部分（准备 / 执行 / 中断缓冲），单次审计即可。',
    timebox: '建议 = 准备 15 + 执行 + 中断缓冲 20 分钟',
    energy: '低',
  },
  M7: {
    title: '失败重启',
    name: 'ADHD Reset',
    state: 'F 自责',
    ref: 'M7-adhd-reset.md',
    whyNow: '从自责中恢复行动力。最高优先级、最短响应。停止评价 → 缩小目标 → 一个 30 秒动作。',
    timebox: '30 秒',
    energy: '最低（先恢复连接，不要求完成）',
  },
  M8: {
    title: '选路器',
    name: 'Router',
    state: 'G 不知道怎么做',
    ref: 'M8-router.md',
    whyNow: '缓解"不知道怎么做 / 怎么选"的决策瘫痪。2-3 个框架生成 → 陷阱标注 → 强烈收敛到 1 个行动。',
    timebox: '第一步 <60 秒',
    energy: '低-中',
  },
}

// Signal keywords per state-scanner.md. Keywords are hints, not hard routing.
const SIGNALS = {
  F: {
    module: 'M7',
    keywords: ['自责', '又失败', '我怎么这么差', '没做完', '又没做成', '很自责', '觉得自己差', 'failed again', 'failed', 'guilt'],
  },
  E: {
    module: 'M3',
    keywords: ['没劲', '无聊', '不想做', '没动力', '太无聊', '没意思', 'bored', 'no motivation', 'unmotivated'],
  },
  B: {
    module: 'M2',
    keywords: ['好多事', '事情太多', '脑子乱', '不知道先做哪个', '太多', 'overwhelm', 'too many', '一堆'],
  },
  A: {
    module: 'M1',
    keywords: ['做不了', '拖着', '拖了', '拖延', '动不了', '启动', '不敢开始', '不知道怎么开始', 'procrastinat', 'can\'t start'],
  },
  C: {
    module: 'M4',
    keywords: ['坐不住', '分心', '看手机', '容易分心', '一会看看别的', 'distract'],
  },
  D: {
    module: 'M6',
    keywords: ['怎么花这么久', '低估', '花了很久', '感觉马上完成', 'took longer', 'underestimate'],
  },
  G: {
    module: 'M8',
    keywords: ['该怎么做', '怎么选', '不知道怎么做', '不会做', '拿不准', 'how to'],
  },
}

// 混合状态按 情绪 > 结构 > 启动 处理：F / E 先处理，再 B 清理，最后 A 启动。
const STATE_PRIORITY = ['F', 'E', 'B', 'A', 'C', 'D', 'G']

/**
 * Scan text for state signals and return the dominant { state, module }.
 * Returns { state: null, module: null } when no signal is strong enough
 * (fuzzy → the caller should offer the self-service menu instead).
 */
export function scanState(text = '') {
  const lower = String(text).toLowerCase()
  for (const state of STATE_PRIORITY) {
    const { module, keywords } = SIGNALS[state]
    if (keywords.some((k) => lower.includes(k.toLowerCase()))) return { state, module }
  }
  return { state: null, module: null }
}

const splitList = (value) =>
  String(value ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)

const firstAction = (task) => `打开与「${task}」相关的文件或页面（30 秒内）`

// ---------------------------------------------------------------- module builders

const buildPreflight = () => ({
  module: null,
  direct: true,
  state: '无任务信号',
  moduleName: null,
  whyNow: 'Pre-flight 门：请求很小或无任务信号（闲聊）→ 直接回答，不套流程，skill 静默，零干扰。',
  nextAction: null,
  steps: [],
  timeboxEstimate: null,
  energyRequired: null,
})

const buildFuzzy = ({ task }) => ({
  module: null,
  selfServiceMenu: true,
  state: '信号模糊',
  moduleName: null,
  whyNow: '信号模糊 → 给自助菜单（用户自选 = 掌控感 + 防误判）。关键词仅作提示，不是硬性路由。',
  nextAction: '选一个最接近的状态（A-G）',
  steps: [],
  timeboxEstimate: null,
  energyRequired: null,
  task,
  menu: [
    'A 不想开始（任务瘫痪）',
    'B 事情太多，脑子乱',
    'C 坐不住，容易分心',
    'D 以为很快能完，结果没完',
    'E 没劲，太无聊',
    'F 又没做成，很自责',
    'G 不知道这个任务该怎么做',
  ],
})

const buildM1 = ({ task }) => {
  const s1 = firstAction(task)
  const s2 = `写下这一行标题：「${task}」`
  return {
    module: 'M1',
    state: 'A 启动困难',
    moduleName: '任务破碎机 (Task Breaker)',
    whyNow: MODULES.M1.whyNow,
    nextAction: s1,
    steps: [s1, s2],
    timeboxEstimate: '第一步 <60 秒；本轮 2 步，跑完再要下一步',
    energyRequired: '低（仅需打开文件）',
    followUp: '做完回复"完成"（可选，不阻塞）。你开始了，这一步就成了。',
  }
}

const buildM2 = ({ task, parked, dropped }) => {
  const parkedItems = splitList(parked)
  const droppedItems = splitList(dropped)
  const action = '打开空白文档，写第一段'
  return {
    module: 'M2',
    state: 'B 事情太多',
    moduleName: '外部大脑 (External Brain)',
    whyNow: MODULES.M2.whyNow,
    nextAction: `现在只做「${task}」；唯一 Next Action：${action}`,
    steps: [action],
    parked: parkedItems,
    dropped: droppedItems,
    timeboxEstimate: '现在区只留 1 件事 + 唯一 Next Action',
    energyRequired: '低',
    followUp: '其余全部进"稍后"或"废弃"。不管理所有事，只寻找 Next Action。',
  }
}

const buildM3 = ({ task, battery }) => {
  const appetizer = '开胃菜（5 分钟）：站起来拉伸 1 分钟，或听 1 首快节奏歌'
  const main = `主菜（20 分钟）：${task}——只找 3 个案例 / 只写第一段，而非完成整个`
  const side = '配菜（10 分钟）：低压创意活动（涂鸦 / 整理桌面一角）'
  if (battery === undefined) {
    return {
      module: 'M3',
      state: 'E 没动力',
      moduleName: '多巴胺建筑师 (Dopamine Architect)',
      whyNow: MODULES.M3.whyNow,
      askEnergy: true,
      nextAction: '先回答：现在电量多少？🔋 10% / 30% / 60% / 90%',
      steps: [],
      timeboxEstimate: '开胃菜 5 分钟 / 主菜 20 分钟 / 配菜 10 分钟（时间为建议值，用户可调）',
      energyRequired: '未知（先问电量）',
    }
  }
  if (battery <= 30) {
    return {
      module: 'M3',
      state: 'E 没动力',
      moduleName: '多巴胺建筑师 (Dopamine Architect)',
      whyNow: '电量 <30%：轻启动。开胃菜 + 第一步，绝不硬上 20 分钟主菜。',
      nextAction: appetizer,
      steps: [appetizer, '主菜降级：只做第一步——打开文件，读标题'],
      battery,
      timeboxEstimate: '开胃菜 5 分钟 → 主菜降级为 1 步（<60 秒）',
      energyRequired: `🔋 ${battery}%（低电量，轻启动）`,
      followUp: '做完第一步就停下。回来了再说。',
    }
  }
  if (battery <= 60) {
    return {
      module: 'M3',
      state: 'E 没动力',
      moduleName: '多巴胺建筑师 (Dopamine Architect)',
      whyNow: MODULES.M3.whyNow,
      nextAction: appetizer,
      steps: [appetizer, main, side],
      battery,
      timeboxEstimate: '开胃菜 5 分钟 → 主菜 20 分钟 → 配菜 10 分钟',
      energyRequired: `🔋 ${battery}%（标准菜单）`,
    }
  }
  return {
    module: 'M3',
    state: 'E 没动力',
    moduleName: '多巴胺建筑师 (Dopamine Architect)',
    whyNow: MODULES.M3.whyNow,
    nextAction: appetizer,
    steps: [appetizer, main, side],
    battery,
    timeboxEstimate: '标准菜单，可加量（开胃菜 5 分钟 → 主菜 20 分钟 → 配菜 10 分钟）',
    energyRequired: `🔋 ${battery}%（高电量，可加量）`,
  }
}

const buildM4 = ({ task }) => {
  const action = `打开与「${task}」相关的文档，写下今天的日期`
  return {
    module: 'M4',
    state: 'C 容易分心',
    moduleName: '起跑与回归仪式 (Launch & Return Ritual)',
    whyNow: MODULES.M4.whyNow,
    nextAction: action,
    steps: [`确认目标：「${task}」（一句话）`, `最小动作：${action}`],
    timeboxEstimate: '最小动作 <60 秒；检查点全可选',
    energyRequired: '中（需要陪伴启动）',
    closing: '我在这，你去做。做完了回来或不回来都行。',
    statusCard: '[M4 · 已完成：起跑]',
    followUp: '回来后凭状态卡承接进度，可确认完成项 + 庆祝 + 下一步。',
  }
}

const buildM5 = ({ task, narrative }) => {
  if (!narrative) {
    return {
      module: 'M5',
      state: '仅 opt-in',
      moduleName: '兴趣游戏化 (Interest Gamifier)',
      whyNow: MODULES.M5.whyNow,
      askNarrative: true,
      nextAction: '先回答：想要哪种叙事风格？RPG / 认真 / 极简',
      steps: [],
      timeboxEstimate: '与包装后的任务一致',
      energyRequired: '视电量而定',
    }
  }
  const story = {
    rpg: `把「${task}」包装成剧情：「整理数据宝库，找到隐藏漏洞」。`,
    serious: `去掉所有装饰，直接按 M1 规则给出 1-3 步。`,
    minimal: `极简版：只给第一步，不加任何叙事。`,
  }[narrative]
  return {
    module: 'M5',
    state: '仅 opt-in',
    moduleName: '兴趣游戏化 (Interest Gamifier)',
    whyNow: story,
    nextAction: `开始任务叙事的第一步：${firstAction(task)}`,
    steps: [firstAction(task)],
    timeboxEstimate: '与任务一致',
    energyRequired: '低-中',
    reward: '完成当前阶段后解锁即时奖励（如 10 分钟自由时间）。',
  }
}

const buildM6 = ({ task, estimatedMinutes }) => {
  const est = Math.max(1, Math.round(Number(estimatedMinutes) || 60))
  const prep = 15
  const buffer = 20
  const total = est + prep + buffer
  return {
    module: 'M6',
    state: 'D 时间误估',
    moduleName: '时间审计员 (Time Auditor)',
    whyNow: MODULES.M6.whyNow,
    nextAction: `按现实三部分重新预算「${task}」的耗时`,
    steps: [
      `你的预计：${est} 分钟`,
      `现实：准备 ${prep} 分钟（找资料、开环境）+ 执行 ${est} 分钟 + 中断缓冲 ${buffer} 分钟`,
      `建议：约 ${total} 分钟`,
    ],
    estimatedMinutes: est,
    timeboxEstimate: `建议约 ${total} 分钟（准备 ${prep} + 执行 ${est} + 中断缓冲 ${buffer}）`,
    energyRequired: '低',
    followUp: '仅当用户主动回报实际耗时 → 当次修正。不承诺"我记住了，下次更准"。',
  }
}

const buildM7 = ({ task }) => {
  const action = `打开与「${task}」相关的文件`
  return {
    module: 'M7',
    state: 'F 自责',
    moduleName: '失败重启 (ADHD Reset)',
    whyNow: MODULES.M7.whyNow,
    nextAction: action,
    steps: [
      '停止评价：现在不是解决人生问题，只是恢复行动。',
      '缩小目标：不完成任务，只恢复连接。',
      `一个 30 秒动作：${action}，打开就行。`,
    ],
    timeboxEstimate: '30 秒',
    energyRequired: '最低（先恢复连接，不要求完成）',
    tone: '内建"失败可原谅"。不评判、不说教、不灌鸡汤。',
  }
}

const buildM8 = ({ task }) => {
  return {
    module: 'M8',
    state: 'G 不知道怎么做',
    moduleName: '选路器 (Router)',
    whyNow: MODULES.M8.whyNow,
    nextAction: firstAction(task),
    steps: [
      '速通版：只做最核心的部分，跳过铺垫。（陷阱：跳过的可能正好是基础）',
      '10 岁版：把每个环节问成"为什么"，像讲故事。（陷阱：容易陷入科普刷视频）',
      '审计版：列出必须交付的，删掉多余的。（陷阱：列清单本身可能变成拖延）',
    ],
    timeboxEstimate: '第一步 <60 秒',
    energyRequired: '低-中',
    recommendation: '我推荐速通版，因为目标明确。',
  }
}

// ---------------------------------------------------------------- pure core

/**
 * Produce a structured single-next-action coaching breakdown for a task.
 *
 * Follows the ADHD Copilot core workflow:
 *   1. Pre-flight gate (no task → silent, no process).
 *   2. State classification (strong signal → module; fuzzy → self-service menu).
 *   3. Minimal action (1-3 steps, first step <60 s).
 *   4. Self-contained instruction (no requirement to come back).
 *   5. Optional feedback reinforcement (non-blocking follow-up).
 *
 * @param {object} input
 *   - task: the task / stuck signal (required).
 *   - context: extra signals (e.g. "拖了一周了", "又失败了").
 *   - battery: 10 | 30 | 60 | 90 (M3 dopamine architect).
 *   - narrative: 'rpg' | 'serious' | 'minimal' (M5 interest gamifier, opt-in).
 *   - estimatedMinutes: user's own estimate (M6 time auditor).
 *   - parked / dropped: comma-separated "稍后" / "废弃" lists (M2 external brain).
 * @returns {object} breakdown with module, nextAction, whyNow, timeboxEstimate,
 *   energyRequired, steps and module-specific fields.
 */
export function adhdBreakdown({ task, context = '', battery, narrative, estimatedMinutes, parked, dropped } = {}) {
  // 1. Pre-flight gate
  if (!String(task ?? '').trim()) return buildPreflight()

  // 2. State classification
  const scan = scanState(`${task} ${context}`)
  if (!scan.module) return buildFuzzy({ task })

  const base = { task: String(task).trim(), context: String(context).trim() }
  let built
  switch (scan.module) {
    case 'M1': built = buildM1(base); break
    case 'M2': built = buildM2({ ...base, parked, dropped }); break
    case 'M3': built = buildM3({ ...base, battery }); break
    case 'M4': built = buildM4(base); break
    case 'M5': built = buildM5({ ...base, narrative }); break
    case 'M6': built = buildM6({ ...base, estimatedMinutes }); break
    case 'M7': built = buildM7(base); break
    case 'M8': built = buildM8(base); break
  }
  return { ...built, task: base.task, context: base.context }
}

/**
 * Render a breakdown as coaching markdown, honoring the seven output
 * disciplines: first line is an action, numbered steps ≤3, ends with a
 * 30-second next step, no hollow praise.
 */
export function renderBreakdown(b) {
  if (b.module === null) {
    if (b.direct) return '（无任务信号：保持静默，零干扰。）'
    if (b.selfServiceMenu) {
      return [
        '信号不够明确，先选一个最接近的状态（自选 = 掌控感 + 防误判）：',
        ...b.menu.map((m, i) => `${i + 1}. ${m}`),
        '选完告诉 AI 状态字母，再给对应模块的最小行动。',
      ].join('\n')
    }
  }

  switch (b.module) {
    case 'M1':
      return [
        `${b.task}，先别想完成。只做第一步：`,
        ...b.steps.map((s, i) => `${i + 1}. ${s}`),
        '',
        '每步 <60 秒。做完回复"完成"（可选，不阻塞）。你开始了，这一步就成了。',
      ].join('\n')
    case 'M2': {
      const lines = ['现在：', `任务：${b.task}`, `下一行动：${b.steps[0]}`, '', '稍后：']
      lines.push(...(b.parked.length ? b.parked.map((p) => `- ${p}`) : ['- （空）']))
      lines.push('', '废弃：')
      lines.push(...(b.dropped.length ? b.dropped.map((d) => `- ${d}`) : ['- （空）']))
      lines.push('', '现在区只留 1 件事 + 唯一 Next Action。其余全在"稍后"或"废弃"。')
      return lines.join('\n')
    }
    case 'M3': {
      if (b.askEnergy) return '现在电量多少？🔋 10% / 30% / 60% / 90%'
      if (b.battery <= 30) {
        return [
          `电量 🔋${b.battery}%，轻启动：`,
          `1. ${b.steps[0]}`,
          `2. ${b.steps[1]}`,
          '',
          '做完第一步就停下。回来了再说。',
        ].join('\n')
      }
      return [...b.steps.map((s, i) => `${i + 1}. ${s}`), '', '时间为建议值，可调。'].join('\n')
    }
    case 'M4':
      return [
        `目标：${b.task}（一句话）`,
        `现在只做：${b.nextAction}`,
        '',
        b.closing,
      ].join('\n')
    case 'M5': {
      if (b.askNarrative) return '想要哪种叙事风格？RPG / 认真 / 极简。尊重你的选择。'
      return [
        `任务叙事：${b.task}——${b.whyNow}`,
        `即时奖励：${b.reward}`,
        `第一步：${b.nextAction}`,
      ].join('\n')
    }
    case 'M6':
      return [
        `你的预计：${b.estimatedMinutes} 分钟`,
        '现实：',
        `- 准备：15 分钟（找资料、开环境）`,
        `- 执行：${b.estimatedMinutes} 分钟`,
        '- 中断缓冲：20 分钟',
        `建议：约 ${b.estimatedMinutes + 15 + 20} 分钟`,
      ].join('\n')
    case 'M7':
      return [
        `没做完，说明任务对你来说太难启动，不代表你差。`,
        `现在不做任务，只做一个 30 秒动作：${b.nextAction}。打开就行。`,
      ].join('\n')
    case 'M8':
      return [
        `${b.task}，3 种做法：`,
        ...b.steps.map((s, i) => `${i + 1}. ${s}`),
        '',
        b.recommendation,
        `先做第一步：${b.nextAction}`,
      ].join('\n')
    default:
      return JSON.stringify(b, null, 2)
  }
}

// ---------------------------------------------------------------- tool

const renderText = (_args, value) => [{ type: 'text', text: value }]

export function apply(ctx) {
  ctx.tools.register({
    name: 'adhd_breakdown',
    description:
      'ADHD behavioral coaching: guides a user who is procrastinating, stuck starting, overwhelmed, ' +
      'distracted, underestimating time, unmotivated, or guilty about unfinished work. ' +
      'Scans the task + context for state signals and routes through the ADHD Copilot modules ' +
      '(M1 task breaker, M2 external brain, M3 dopamine architect, M4 launch & return ritual, ' +
      'M5 interest gamifier (opt-in), M6 time auditor, M7 failure reset, M8 router), then returns ' +
      'a structured single-next-action coaching breakdown. Call it instead of dumping a full plan: ' +
      'always push only the next step, never require finishing everything.',
    parameters: {
      type: 'object',
      properties: {
        task: {
          type: 'string',
          description: 'The task the user is stuck on or wants to start. Required.',
        },
        context: {
          type: 'string',
          description: 'Extra signals: how long they have been stuck, their own words (e.g. "拖了一周了", "又失败了", "太多了"), obstacles.',
        },
        battery: {
          type: 'integer',
          enum: [10, 30, 60, 90],
          description: 'Energy level for the dopamine architect module (M3). Ask the user if unknown.',
        },
        narrative: {
          type: 'string',
          enum: ['rpg', 'serious', 'minimal'],
          description: 'Narrative style for the interest gamifier module (M5). Only when opt-in.',
        },
        estimatedMinutes: {
          type: 'integer',
          description: 'The user\'s own time estimate in minutes, for the time auditor module (M6).',
        },
        parked: {
          type: 'string',
          description: 'Comma-separated tasks to park as "稍后" for the external brain module (M2).',
        },
        dropped: {
          type: 'string',
          description: 'Comma-separated tasks to drop as "废弃" for the external brain module (M2).',
        },
      },
      required: ['task'],
    },
    output: {
      schema: { type: 'string' },
      render: renderText,
    },
    async execute(args) {
      return renderBreakdown(adhdBreakdown(args))
    },
  })
}
