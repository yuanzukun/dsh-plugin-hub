import { test } from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, readdirSync, statSync } from 'node:fs'
import { join } from 'node:path'
import { fileURLToPath } from 'node:url'
import { adhdBreakdown, renderBreakdown, scanState, MODULES } from '../src/index.js'

const PLUGIN_ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..')
const SKILL_DIR = join(PLUGIN_ROOT, 'skills', 'adhd-copilot')

const REF_FILES = [
  'core-workflow.md',
  'M1-task-breaker.md',
  'M2-external-brain.md',
  'M3-dopamine-architect.md',
  'M4-body-double.md',
  'M5-interest-gamifier.md',
  'M6-time-auditor.md',
  'M7-adhd-reset.md',
  'M8-router.md',
  'output-discipline.md',
  'state-scanner.md',
]

test('SKILL.md exists with YAML frontmatter name/description', () => {
  const raw = readFileSync(join(SKILL_DIR, 'SKILL.md'), 'utf8')
  assert.ok(raw.startsWith('---'), 'starts with YAML frontmatter')
  assert.match(raw, /^name:\s*adhd-copilot$/m, 'frontmatter name')
  assert.match(raw, /^description:\s*"/m, 'frontmatter description')
})

test('all 11 references/*.md exist and are non-empty', () => {
  const dir = join(SKILL_DIR, 'references')
  const files = readdirSync(dir).filter((f) => f.endsWith('.md'))
  assert.equal(files.length, 11, 'exactly 11 reference files')
  for (const ref of REF_FILES) {
    const p = join(dir, ref)
    assert.ok(statSync(p).isFile(), `${ref} exists`)
    assert.ok(readFileSync(p, 'utf8').trim().length > 0, `${ref} is non-empty`)
  }
})

test('copied skill files match the source verbatim', (t) => {
  const source = join(PLUGIN_ROOT, '..', '..', 'adhd-copilot', 'skills', 'adhd-copilot')
  if (!statSync(source, { throwIfNoEntry: false })) {
    t.skip('source skill directory not present')
    return
  }
  const targets = ['SKILL.md', ...REF_FILES.map((f) => join('references', f))]
  for (const rel of targets) {
    assert.equal(
      readFileSync(join(SKILL_DIR, rel), 'utf8'),
      readFileSync(join(source, rel), 'utf8'),
      `${rel} is a verbatim copy`,
    )
  }
})

test('scanState routes signal keywords to the right module', () => {
  assert.deepEqual(scanState('我拖着不写周报'), { state: 'A', module: 'M1' })
  assert.deepEqual(scanState('好多事情脑子乱'), { state: 'B', module: 'M2' })
  assert.deepEqual(scanState('太无聊了不想做'), { state: 'E', module: 'M3' })
  assert.deepEqual(scanState('坐不住总看手机'), { state: 'C', module: 'M4' })
  assert.deepEqual(scanState('又失败了，我怎么这么差'), { state: 'F', module: 'M7' })
  assert.deepEqual(scanState('不知道这个任务该怎么做'), { state: 'G', module: 'M8' })
  assert.deepEqual(scanState('怎么花这么久，感觉马上就能完成'), { state: 'D', module: 'M6' })
  assert.deepEqual(scanState('今天天气不错'), { state: null, module: null })
})

test('adhdBreakdown returns nextAction for a sample task', () => {
  const b = adhdBreakdown({ task: '我拖着不写周报，两周了' })
  assert.equal(b.module, 'M1')
  assert.ok(b.nextAction, 'has nextAction')
  assert.ok(b.whyNow, 'has whyNow')
  assert.ok(b.timeboxEstimate, 'has timeboxEstimate')
  assert.ok(b.energyRequired, 'has energyRequired')
  assert.ok(Array.isArray(b.steps) && b.steps.length >= 1 && b.steps.length <= 3, '1-3 steps only')
  const md = renderBreakdown(b)
  assert.ok(md.startsWith('我拖着不写周报，两周了'), 'first line names the task')
  assert.match(md, /每步 <60 秒/, 'mentions the 60s discipline')
})

test('adhdBreakdown pre-flight gate: no task stays silent', () => {
  const b = adhdBreakdown({})
  assert.equal(b.module, null)
  assert.equal(b.direct, true)
  assert.equal(b.nextAction, null)
})

test('adhdBreakdown fuzzy signals offer the self-service menu', () => {
  const b = adhdBreakdown({ task: '帮我看看这个项目怎么办' })
  assert.equal(b.module, null)
  assert.equal(b.selfServiceMenu, true)
  assert.equal(b.menu.length, 7)
  const md = renderBreakdown(b)
  assert.match(md, /A 不想开始/, 'menu item A present')
  assert.match(md, /G 不知道这个任务该怎么做/, 'menu item G present')
})

test('adhdBreakdown M3 dopamine architect asks for battery when unknown', () => {
  const b = adhdBreakdown({ task: '太无聊了，不想写作业', battery: undefined })
  assert.equal(b.module, 'M3')
  assert.equal(b.askEnergy, true)
})

test('adhdBreakdown M3 low battery produces a light start', () => {
  const b = adhdBreakdown({ task: '太无聊了，不想写作业', battery: 10 })
  assert.equal(b.module, 'M3')
  assert.match(b.timeboxEstimate, /主菜降级/, 'low battery never gets a 20-min main course')
  const md = renderBreakdown(b)
  assert.match(md, /轻启动/, 'rendered as a light start')
})

test('adhdBreakdown M7 failure reset is the shortest response', () => {
  const b = adhdBreakdown({ task: '我又没做完，我怎么这么差' })
  assert.equal(b.module, 'M7')
  assert.equal(b.timeboxEstimate, '30 秒')
  assert.ok(b.steps.length <= 3)
})

test('MODULES exposes M1-M8 with references', () => {
  assert.deepEqual(Object.keys(MODULES), ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8'])
  for (const key of Object.keys(MODULES)) {
    assert.ok(MODULES[key].ref.endsWith('.md'), `${key} has a reference file`)
    assert.ok(MODULES[key].title, `${key} has a title`)
  }
})
