'use strict';

// 目标模式：V2/publish 上下文运行时的行为与产物接线锁。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { REPO_ROOT } = require('../scripts/lib/chunk-decode.mjs');
const { createContextRuntime } = require('../src/host/domains/enhance/context.cjs');

function makeRuntime(overrides) {
  const logs = [];
  const marks = [];
  const timers = [];
  const deps = {
    hlog: (...args) => logs.push(args.join(' ')),
    collectStream: async () => ({ kind: 'ok', text: '{}' }),
    buildWebQuery: () => 'query',
    extractHistory: () => [],
    extractHistoryConclusions: () => [],
    extractKeywords: () => ['keyword'],
    inferFocusRules: () => [],
    parseTaskProgress: () => ({ focus: [] }),
    rankFiles: () => [],
    resolveScanLimit: () => 5,
    shouldIgnoreFile: () => false,
    snippetFromLines: () => '',
    modeTable: {
      base: { phaseA: 'none', phaseB: 'none', phaseC: 'none' },
      publish: { phaseA: 'none', phaseB: 'none', phaseC: 'inject' },
    },
    defaultMode: 'base',
    stageHistory: 'history', stageAnalyze: 'analyze', stageFiles: 'files',
    stageEvents: 'events', stageContext: 'context',
    v2HistoryLimit: 10, v2HistoryMaxChars: 100, v2MsgSeqScan: 10,
    v2ProgressMaxTokens: 100, v2ProgressOutputLimit: 100, v2ProgressTimeoutMs: 100,
    v2SearchEventsTimeoutMs: 100, v2WorkspaceIgnoreDirs: new Set(),
    v2WorkspaceTimeoutMs: 100, scanFileListMax: 10, snippetBudget: 100,
    webMemoMax: 100, webRefMax: 1000, webSearchMaxResults: 3, webSearchTimeoutMs: 100,
    contentFallbackScan: 3, taskAnalysisPrompt: 'TASK',
    buildContextBlock: (progress, files, events, budget) => 'BLOCK:' + files.length + ':' + events.length + ':' + budget,
  };
  const rt = createContextRuntime(Object.assign(deps, overrides || {}));
  return { rt, logs, marks, timers };
}

function timer() {
  const callbacks = [];
  return {
    callbacks,
    api: { timeout: (cb, ms) => { callbacks.push({ cb, ms }); return () => {}; } },
  };
}

test('CRT-01 startWaitAbort 在预算 0/无 timer 时立即超时', async () => {
  const { rt } = makeRuntime();
  const gate = rt.startWaitAbort(null, 0);
  assert.equal(gate.timedOut(), true);
  assert.deepEqual(await gate.race(new Promise(() => {})), { timedOut: true });
  gate.dispose();
});

test('CRT-02 startWaitAbort 到点后吞掉底层迟到值并置超时', async () => {
  const t = timer();
  const { rt } = makeRuntime();
  const gate = rt.startWaitAbort(t.api, 100);
  let resolveLate;
  const late = new Promise((resolve) => { resolveLate = resolve; });
  const raced = gate.race(late);
  t.callbacks[0].cb();
  assert.equal(gate.timedOut(), true);
  assert.deepEqual(await raced, { timedOut: true });
  resolveLate('late');
  gate.dispose();
});

test('CRT-03 base 无检索：空块、none 日志、context 进度', async () => {
  const { rt, marks } = makeRuntime();
  const out = await rt.buildV2ContextBlock({}, 's', 'text', { mode: 'base', context: { budgetChars: 100 } }, (stage) => marks.push(stage));
  assert.deepEqual(out, { block: '', log: 'none', webTopics: [], webMemoText: '' });
  assert.deepEqual(marks, ['context']);
});

test('CRT-04 publish 保留模式块、网络参考与跨轮主题/摘要', async () => {
  const web = { search: async () => ({ sources: [{ title: 'T', url: 'u', summary: 'S' }] }) };
  const t = timer();
  const { rt } = makeRuntime();
  const services = { web, webPlan: [{ query: 'topic' }], scenario: 'game', delta: null, timer: t.api };
  const out = await rt.buildV2ContextBlock(services, 's', 'text', { mode: 'publish', context: { budgetChars: 1000 } }, () => {});
  assert.match(out.block, /^BLOCK:0:0:1000/);
  assert.match(out.block, /【网络参考】/);
  assert.deepEqual(out.webTopics, [{ query: 'topic', hits: 1 }]);
  assert.match(out.webMemoText, /『topic』：T——S/);
});

test('CRT-05 产物内联上下文运行时，startWaitAbort/buildV2ContextBlock 已接线', () => {
  const host = fs.readFileSync(path.join(REPO_ROOT, 'plugin-host.js'), 'utf8');
  assert.ok(host.includes('"src/host/domains/enhance/context.cjs"'));
  assert.ok(host.includes('"src/host/domains/enhance/context.cjs"'));
  assert.ok(host.includes('contextRuntime.startWaitAbort'));
  assert.ok(host.includes('contextRuntime.buildV2ContextBlock'));
  assert.equal((host.match(/require\(/g) || []).length, 0);
});
