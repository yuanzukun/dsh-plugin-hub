'use strict';

// 目标模式：模型 RPC 普通模块的注册面与返回结构锁。
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { REPO_ROOT } = require('../scripts/lib/chunk-decode.mjs');
const { createModelsRpc } = require('../src/host/domains/models/rpc.cjs');

function makeRpc(services, overrides) {
  const logs = [];
  const errors = [];
  const deps = {
    ctx: { get: (name) => services[name] || null, timer: { timeout: () => () => {} } },
    hlog: (...args) => logs.push(args.join(' ')),
    herr: (...args) => errors.push(args.join(' ')),
    resolveModelInfoCached: async () => ({ reasoning: { efforts: [{ id: 'high', name: 'High' }], defaultEffort: 'high' }, context: { window: 1000 }, defaultMaxTokens: 100 }),
    resolveAdaptiveChain: async () => [{ provider: 'p', model: 'm' }],
    pingStream: async () => ({ ok: true, latencyMs: 12, tokensPerSecond: 100, ttftMs: 100 }),
    friendlyMessage: (x) => 'MSG:' + (x && x.code || '?'),
    estimateBaseModeSeconds: () => 1,
    estimateLiteModeSeconds: () => 2,
    extractModelRouteFromEvents: () => ({ model: 'm' }),
    accumulateProjectionStats: () => {},
    summarizeModelStats: () => ({ ttftMs: 1, tokensPerSecond: 1 }),
  };
  return { rpc: createModelsRpc(Object.assign(deps, overrides || {})), logs, errors };
}

test('HMR-01 注册面恰为原有六个 models RPC', () => {
  const { rpc } = makeRpc({});
  assert.deepEqual([...rpc.handlers.keys()], [
    'models/list', 'models/resolve', 'models/current', 'models/autochain', 'models/test', 'models/stats',
  ]);
});

test('HMR-02 models/list 映射 provider/model，单个模型列表失败降级为空', async () => {
  const llm = {
    listProviders: () => [{ id: 'p1', name: 'One' }, { id: 'p2', name: 'Two' }],
    listModels: async (id) => { if (id === 'p2') throw new Error('bad'); return [{ id: 'm1', name: '' }]; },
  };
  const { rpc } = makeRpc({ llm });
  const out = await rpc.handlers.get('models/list')();
  assert.deepEqual(out, { ok: true, providers: [
    { provider: 'p1', name: 'One', models: [{ id: 'm1', name: 'm1' }] },
    { provider: 'p2', name: 'Two', models: [] },
  ] });
});

test('HMR-03 models/resolve 输出 reasoning/context/defaultMaxTokens，并原样返回 provider/model', async () => {
  const llm = { resolveModelInfo: async () => ({}) };
  const { rpc } = makeRpc({ llm });
  const out = await rpc.handlers.get('models/resolve')({ provider: 'p', model: 'm', noCache: true });
  assert.equal(out.ok, true);
  assert.equal(out.provider, 'p');
  assert.equal(out.model, 'm');
  assert.deepEqual(out.reasoning, { efforts: [{ id: 'high', name: 'High' }], defaultEffort: 'high' });
  assert.deepEqual(out.context, { window: 1000 });
  assert.equal(out.defaultMaxTokens, 100);
});

test('HMR-04 models/current 严格过滤空选择并保留可选 reasoningEffort', async () => {
  const adm = { currentSelection: () => ({ provider: 'p', model: 'm', reasoningEffort: 'max' }) };
  const ok = await makeRpc({ agentDefaultModel: adm }).rpc.handlers.get('models/current')();
  assert.deepEqual(ok, { ok: true, provider: 'p', model: 'm', reasoningEffort: 'max' });
  const emptyAdm = { currentSelection: () => ({ provider: '', model: 'm' }) };
  const empty = await makeRpc({ agentDefaultModel: emptyAdm }).rpc.handlers.get('models/current')();
  assert.equal(empty.code, 'EMPTY');
});

test('HMR-05 models/autochain 与 models/test 保持原参数形态与估算字段', async () => {
  const llm = { stream: () => ({}), resolveCallConfig: async () => {} };
  const { rpc } = makeRpc({ llm, agentDefaultModel: {} });
  const chain = await rpc.handlers.get('models/autochain')({ noCache: true });
  assert.deepEqual(chain, { ok: true, chain: [{ provider: 'p', model: 'm' }] });
  const probe = await rpc.handlers.get('models/test')({ provider: 'p', model: 'm', inputChars: 100 });
  assert.equal(probe.ok, true);
  assert.equal(probe.estimatedBaseSeconds, 1);
  assert.equal(probe.estimatedLiteSeconds, 2);
});

test('HMR-06 产物内联模型 RPC 模块，15 条 RPC 面不变', () => {
  const host = fs.readFileSync(path.join(REPO_ROOT, 'plugin-host.js'), 'utf8');
  assert.ok(host.includes('"src/host/domains/models/rpc.cjs"'));
  assert.ok(host.includes('"src/host/domains/models/rpc.cjs"'));
  assert.ok(host.includes("harness.handle(name, handler)"));
  assert.equal((host.match(/require\(/g) || []).length, 0);
});
