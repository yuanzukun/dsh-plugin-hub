'use strict';

// 语音热键普通模块（构建期由客户端运行时内联）。
// 纯函数与 VoiceHotkeyHost 的行为不变；宿主、配置、纠错状态和计时器均显式注入。

function voiceHotkeyDisplay(combo) {
  const parts = String(combo || '').split('+').filter(Boolean);
  if (!parts.length) return '';
  const last = parts[parts.length - 1];
  const key = last === 'Backquote' ? '`' : last;
  return parts.length > 1 ? parts.slice(0, -1).concat(key).join('+') : key;
}

function createVoiceHotkey(deps) {
  const d = deps && typeof deps === 'object' ? deps : {};
  const rpcMethods = d.rpcMethods && typeof d.rpcMethods === 'object' ? d.rpcMethods : {};
  const React = d.React;
  const host = d.host;
  const voiceCfgState = d.voiceCfgState;
  const subscribeVoiceConfig = d.subscribeVoiceConfig;
  const isEnhancing = d.isEnhancing;
  const subscribe = d.subscribe;
  const storeFor = d.storeFor;
  const notify = d.notify;
  const enhance = d.enhance;
  const timerSvc = d.timerSvc;
  const officialVoiceBridge = d.officialVoiceBridge;
  const makeT = d.makeT;
  const ZH = d.ZH;
  const MarqueeSelect = d.MarqueeSelect;
  const CollapsibleSection = d.CollapsibleSection;
  const setInterval = d.setInterval;
  const clearInterval = d.clearInterval;
  const setTimeout = d.setTimeout;
  const navigator = d.navigator;
  const window = d.window;
  const configState = d.configState;
  const markCorrectionSkipped = d.markCorrectionSkipped;
  const markCorrectionStarted = d.markCorrectionStarted;
  const markCorrectionSettled = d.markCorrectionSettled;
  const markCorrectionFailed = d.markCorrectionFailed;
  const notifyCorrection = d.notifyCorrection;
  const correctionState = d.correctionState;
  const planVoicePostprocess = d.planVoicePostprocess;
  const voicePostprocessHas = d.voicePostprocessHas;
  const stripFillers = d.stripFillers;
  const runFiller = d.runFiller;
// P1-a（2026-10-13 缩批）：热键通道 —— 自 mic-button.js / voice-insert.js **整段搬出**。
// P2-补做·热键改走官方路径（2026-10-13 · UD-0016 / CHG-011）：**形态变更** ——
//   热键不再自建采集链（自行取麦 / 自行录音 / 自行停止 / 自行调 voice/transcribe 已退役），
//   改为**派发点击官方录制按钮**：热键 = **远程按一下官方按钮** = **一条链、一个状态**
//   （相位 / 电平条 / 停止按钮 / 上限计时器 / 转写 / 写回全部归官方）。
//   本文件的四项增值一项未丢：① 热键解析与匹配（纯函数，行为逐字不变）
//   ② 静音监测（改由官方语音桥模块的包装 VAD 承担 —— 见该文件 §VAD）
//   ③ 自动增强（本文件在两个出口触发：官方成功写回后 / 官方失败出口时按 autoEnhance 判定）
//   ④ 规整（host 侧 lib/asr.cjs，与采集无关）。
// 结构：
//   · 纯函数：parseVoiceHotkey / matchVoiceHotkey / voiceHotkeyDisplay（行为与改前逐字一致）
//   · press 语义：点按=开始 / 再按结束；长按(≥500ms)松开即结束（官方 `finish()` 自带转写，
//     故官方链上不存在「松开后再缓冲识别」的概念 ⇒ 长按 = 「按住说话、松开停止」）
//   · VoiceHotkeyHost：无 UI 的接线组件 —— 占用 conversation.input.right（**不是**官方
//     conversation.input.activity 槽位）以取得本会话 inputActions/input，从而驱动
//     「派发点击官方开始 / 停止」+ 官方链路收尾后的自动增强。
/* UD-0055 / UD-0057（学习词典）：实现全部来自契约层 lib/voice-config.cjs。
   ⛔ 此处不重写归一/替换/学习逻辑（避免第三份白名单，同族缺陷 M-2/M-3）。
   取具说明：本段写在工厂正文内（测试夹具 factoryBody 只取第一处行注释之后的正文），
   并用 typeof 守卫 —— 真实运行时由 app.cjs 注入 deps；测试沙箱按位置参数注入、没有 deps 对象。 */
const _dictDeps = (typeof d !== 'undefined' && d && typeof d === 'object') ? d : {};
const saveVoiceCfg = typeof _dictDeps.saveVoiceCfg === 'function' ? _dictDeps.saveVoiceCfg : null;
const applyVoiceDictionaryFn = typeof _dictDeps.applyVoiceDictionary === 'function' ? _dictDeps.applyVoiceDictionary : null;
const learnVoiceDictionaryDiffFn = typeof _dictDeps.learnVoiceDictionaryDiff === 'function' ? _dictDeps.learnVoiceDictionaryDiff : null;

const VOICE_LONG_PRESS_MS = 500;     // 按住 ≥500ms 判定为长按（松开即停官方）
const VOICE_RELEASE_BUFFER_MS = 500; // 长按松开后 0.5s 收尾缓冲（官方仍在采集时再点一次停止）
// F-18 修复（2026-10-13·收尾批）：长按松开时**启动尚未落地**（官方相位仍在 requesting / 尚无可点停止按钮）
// 的有界补停窗口与步进。语义来自 README 承诺的「长按 = 松开停止」：**松开即停不得因启动未落地而落空**。
const VOICE_RELEASE_DEFER_MS = 100;   // 补停轮询步进
const VOICE_RELEASE_DEFER_MAX = 12;   // 上限 12 × 100ms ≈ 1.2s（覆盖官方「请求中 → 采集中」的过渡窗口）

function parseVoiceHotkey(combo) {
  const parts = String(combo || '').split('+').map((s) => s.trim()).filter(Boolean);
  const out = { ctrl: false, alt: false, shift: false, meta: false, code: null };
  for (const p of parts) {
    if (p === 'Ctrl') out.ctrl = true;
    else if (p === 'Alt') out.alt = true;
    else if (p === 'Shift') out.shift = true;
    else if (p === 'Meta') out.meta = true;
    else if (!out.code) out.code = p;
    else return null;
  }
  return out.code ? out : null;
}

function matchVoiceHotkey(e, hk) {
  return hk && e.ctrlKey === hk.ctrl && e.altKey === hk.alt && e.shiftKey === hk.shift && e.metaKey === hk.meta && e.code === hk.code;
}

// ── 接线组件：无 UI（只取本会话 input/inputActions 并挂热键监听）───────────────
function VoiceHotkeyHost(props) {
  const useInputHook = typeof props.useInput === 'function' ? props.useInput : null;
  const inputSnap = useInputHook ? useInputHook((s) => s) : null;
  const sessionId = (props.session && props.session.sessionId) || props.sessionId;
  const input = inputSnap || props.input || {};
  const draft = typeof input.draft === 'string' ? input.draft : '';
  const inputActions = props.inputActions;

  const [cfgVer, setCfgVer] = React.useState(0);
  const statusRef = React.useRef('idle');     // idle | recording（= 已向官方派发过开始）
  const draftRef = React.useRef(draft);
  const draftSeenRef = React.useRef(draft);   // 上一次已观测到的草稿（官方写回前后判据）
  draftRef.current = draft;
  draftSeenRef.current = draft;
  const pressStartRef = React.useRef(0);
  const pressStatusRef = React.useRef(null);
  const longReleaseRef = React.useRef(false);
  // ⚠ CHG-098：本次**按下之前**官方是否已在采集（相位真值快照）⇒ 点按分支据此分流
  const pressWasRecordingRef = React.useRef(false);
  // F-18：本次按下**之前**的官方会话结束时刻基线。用于判「本轮按下所开的会话是否已收尾」
  //   （收尾即「松开即停」的目标已达成 ⇒ 补停应判成功，**不得**误报失败 —— 实测 (c) 形态即为该例）。
  const releaseEndedBaseRef = React.useRef(0);
  // 官方路径的自动增强：官方会话结束后，等待**官方自己的转写写回**落地，再按 autoEnhance 触发。
  // 为何用有限轮轮询而不只依赖 bridge 通知：写回发生在官方内部（不触发 bridge 事件），
  // 无事件可监听 ⇒ 必须主动重读草稿。上限约 12s（官方转写已在 stop 前完成，此处只等写回）。
  const officialEndRef = React.useRef(0);      // 已消费的官方结束时刻
  const officialBaseRef = React.useRef(null);  // 本会话**开始时**的草稿基线（判写回落地用，见 arm 注释）
  // ⚠ UD-0055 / UD-0057（学习词典 · 采集侧）：**机器最后一次写进草稿的文本**。
  //   语义 = 「这条草稿里，哪一段不是用户自己打的」。用户随后手改 ⇒ 下一次会话开始时
  //   草稿 ≠ 本快照 ⇒ 差异即「用户纠正」，由契约层 `learnVoiceDictionaryDiff` 判断是否够形近。
  //   ⚠ 凡是**机器**写草稿的地方都必须打卡（清口水词 / 纠错 / 增强 / 词典替换），
  //     否则会把机器改动误学成「用户纠正」。
  const machineTextRef = React.useRef(null);
  const noteMachineText = (text) => { if (typeof text === 'string') machineTextRef.current = text; };
  // 词典条目当前值（读配置；host 与 client 同形，见 `M-3`）
  const dictionaryEntries = () => {
    const v = voiceCfgState && voiceCfgState.value ? voiceCfgState.value : null;
    const dic = v && v.dictionary && Array.isArray(v.dictionary.entries) ? v.dictionary.entries : [];
    return dic;
  };
  // 机器侧写回**全部落地后**打一次快照：轮询到「不在增强中 且 草稿连续两次不变」才算稳定。
  //   为什么需要它：增强是异步写回（`helpers.enhance` → `safeSetDraft`），热键侧看不到那一次写。
  //   为什么用轮询而不是改 helpers：⛔ 本批不动增强链路，采集侧不得反向污染它。
  const armMachineSnapshot = (sid) => {
    const take = () => {
      let last = null;
      let stable = 0;
      let tries = 0;
      const poll = () => {
        tries += 1;
        const t = draftRef.current;
        if (t === last) stable += 1; else { last = t; stable = 0; }
        const busy = typeof isEnhancing === 'function' ? !!isEnhancing(sid) : false;
        if (!busy && stable >= 1 && typeof t === 'string' && t !== '') { noteMachineText(t); return true; }
        return tries > 60;                                    // 60 × 300ms ≈ 18s 上限
      };
      if (poll()) return;
      if (timerSvc && typeof timerSvc.interval === 'function') {
        let dispose = null;
        const stop = () => { try { if (typeof dispose === 'function') dispose(); } catch (e) { /* 忽略 */ } };
        const id = timerSvc.interval(() => { if (poll()) stop(); }, 300);
        dispose = typeof id === 'function' ? id : () => {};
      }
    };
    try { take(); } catch (e) { /* 保守：快照失败不影响语音链 */ }
  };
  // 把「用户纠正」并回配置（同 from 合并由契约层归一负责；此处只做拼接 + 调既有保存入口）。
  const learnFromDraft = () => {
    if (typeof learnVoiceDictionaryDiffFn !== 'function') return;
    const machine = machineTextRef.current;
    const edited = draftRef.current;
    if (typeof machine !== 'string' || typeof edited !== 'string') return;
    if (!machine || !edited || machine === edited) return;
    let candidates = [];
    try { candidates = learnVoiceDictionaryDiffFn(machine, edited) || []; } catch (e) { candidates = []; }
    if (!candidates.length) return;
    const merged = dictionaryEntries().concat(candidates);
    if (typeof saveVoiceCfg === 'function') {
      try { saveVoiceCfg({ dictionary: { entries: merged } }); } catch (e) { /* 保守：学习失败不影响语音链 */ }
    }
  };
  const officialWaitRef = React.useRef(null);  // 等待写回的快照 { draft, tries, stop }

  React.useEffect(() => subscribeVoiceConfig(() => setCfgVer((n) => n + 1)), []);

  // ⚠ CHG-098：点按分支的**分流判据源** —— 官方是否「此刻确在采集」（相位真值）。
  //   优先用桥的快照（同一语义，且测试/运行期一致）；桥不可用时**回退**为 DOM 相位查询。
  //   ⚠ 回退**不得**用 `statusRef`：那正是本缺陷的根源（同一次按键刚置真）。
  // ⚠ CHG-105（线二现场失效 · 本批核心）：**相位真值必须读官方渲染的相位**。
  //   病历（实测）：本函数原读 `snapshot().recording` —— 而该字段 = `!!b.active`
  //   （官方是否仍**占用语音入口**），**不是**「是否确在采集」。
  //   官方在「未识别」（feedback）时 `active` **仍为真**（快照 `recording=true`），
  //   而相位已不再是 recording ⇒ 旧读法会把「未识别」**误判为「正在录」**
  //   ⇒ `pressStart` 不调 `startRec()`（线二的 retry 锚永远没机会），且 `pressEnd` 反而派发**停止**
  //   ⇒ 用户看到「按了没反应」/「不能继续识别」。
  //   处置：**用桥已导出的同语义面** `officialCapturing()`（= 相位真值），
  //   不可用时回退同一判据的 DOM 查询—— **用既有机制，不新造机制**。
  function officialRecordingNow() {
    try {
      if (typeof officialVoiceBridge !== 'undefined' && officialVoiceBridge
        && typeof officialVoiceBridge.officialCapturing === 'function') {
        return officialVoiceBridge.officialCapturing() === true;
      }
    } catch (e) { /* 桥不可用 ⇒ 落回 DOM 查询 */ }
    try {
      if (typeof document !== 'undefined' && typeof document.querySelector === 'function') {
        return !!document.querySelector('[data-voice-activity="recording"]');
      }
    } catch (e) { /* DOM 不可用 ⇒ 视为未在录（保守：不派发停止） */ }
    return false;
  }

  // ── 官方路径自动增强（含失败出口）────────────────────────────────────────────
  React.useEffect(() => {
    if (typeof officialVoiceBridge === 'undefined' || !officialVoiceBridge
      || typeof officialVoiceBridge.subscribe !== 'function') return undefined;

    // ══ CHG-143：语音纠错（**独立语音增值步** · 与自动增强并联）═══════════════════════════
    // 用户第三轮架构澄清（逐字）：「纠错**可以独立存在**的，比如说纠错功能打开的话提示詞自动增强
    //   没有打开的话，语言输入识别完成之后会**自动的使用纠错然后就结束**，如果自动增强和语言纠错
    //   都打开的话那就是语言输入完成之后**先纠错然后接着增强**…**并不是集成绑定在提示詞增强一起的**」
    // ⇒ 组合判定（**两个独立开关**）：
    //     纠错关 + 增强关 ⇒ 不动（不发任何调用）
    //     纠错关 + 增强开 ⇒ 只增强
    //     纠错开 + 增强关 ⇒ **只纠错**（**不得**出现增强调用）
    //     纠错开 + 增强开 ⇒ **先纠错 → 再增强**（顺序由控制流保证：增强在纠错 settle 之后发起）
    // ⚠ 手动 ✨ 增强**不经过本函数** ⇒ 天然零纠错调用（用户第四项裁定 ⇒ 由调用方显式区分来源）。
    // ⚠ `typeof` 守卫（与既有 timerSvc/fillerState 同款）：测试沙箱以 `new Function(...)`
    //   只求值本 chunk ⇒ 作用域内可能**无** `correctionState`/`notifyCorrection`（它们由
    //   correction.js chunk 声明）⇒ 裸引用会抛 ReferenceError。生产 bundle 内均已声明。
    const corrState = (typeof correctionState !== 'undefined' && correctionState) ? correctionState : null;
    const corrNotify = (typeof notifyCorrection === 'function') ? notifyCorrection : () => {};
    const correctionCfgOn = () => {
      const c = voiceCfgState.value && voiceCfgState.value.correction;
      return !!(c && c.enabled === true);
    };
    // 「识别完成」这一点上的**唯一调度口**：按两个开关的组合决定发不发、发哪个、什么顺序。
    // ⚠ 会话归属批（2026-10-19）：四个 markCorrection* 都带上**本会话的 sessionId** ——
    //   相位是「刚刚这一次执行」的事实，必须记在**发起它的那个会话**名下，否则切到别的会话时
    //   那颗按钮会把上一个会话的失败当成自己的（用户报障：「切到其他会话显示纠错失败」）。
    //   ⛔ 本批只**传归属**，不改判据与触发时机（四组合逻辑逐字未动）。
    // 目标模式第二批：动作顺序改由共享纯计划决定（不再在此内联第二份四组合分支）。
    // 计划只负责“哪些步骤、什么顺序”；下面的执行器负责各步骤的副作用，失败语义保持原样。
    const planVoiceSteps = (typeof planVoicePostprocess === 'function')
      ? planVoicePostprocess({
        fillerEnabled: !!(voiceCfgState.value && voiceCfgState.value.filler && voiceCfgState.value.filler.enabled !== false),
        correctionEnabled: correctionCfgOn(),
        autoEnhanceEnabled: !!(voiceCfgState.value && voiceCfgState.value.autoEnhance === true),
      })
      : null;
    const wantPostprocessStep = (step) => (planVoiceSteps
      ? voicePostprocessHas(planVoiceSteps, step)
      : step === 'correction'
        ? correctionCfgOn()
        : step === 'enhance'
          ? !!(voiceCfgState.value && voiceCfgState.value.autoEnhance === true)
          : false);
    const runCorrectionThenMaybeEnhance = () => {
      const wantCorrect = wantPostprocessStep('correction');
      const wantEnhance = wantPostprocessStep('enhance');
      const doEnhance = () => { if (wantEnhance) fire(); armMachineSnapshot(sessionId); };
      if (!wantCorrect) {
        // 开关关闭 ⇒ 记为**跳过**（可见：区分“没跑因开关”与“跑了没事”），不静默
        if (typeof markCorrectionSkipped === 'function') markCorrectionSkipped('disabled', sessionId);
        doEnhance();
        return;
      }
      // 纠错开：先纠错；纠错失败/拿不到结果 ⇒ **仍按 autoEnhance 继续**（不得吞掉增强）
      try {
        const api = (typeof host !== 'undefined' && host && typeof host.call === 'function') ? host : null;
        if (!api) { doEnhance(); return; }
        const cur0 = draftRef.current;
        if (typeof cur0 !== 'string' || cur0.trim() === '') { doEnhance(); return; }
        // ⚠ UD-0055 / UD-0057（学习词典 · 生效侧）：发纠错**之前**先做**纯字面替换**。
        //   · 只替换 = 不改写语义；空词典 / 全停用 ⇒ `applied === 0` ⇒ 草稿**逐字不变**（不写回）。
        //   · ⛔ 不走纠错提示词、⛔ 不改 `VOICE_CORRECT` 的调用形态（`text` 仍是整段草稿）。
        let cur = cur0;
        if (typeof applyVoiceDictionaryFn === 'function') {
          try {
            const rep = applyVoiceDictionaryFn(cur0, dictionaryEntries());
            if (rep && typeof rep.text === 'string' && rep.applied > 0 && rep.text !== cur0) {
              cur = rep.text;
              if (inputActions && typeof inputActions.setDraft === 'function') {
                try { inputActions.setDraft(cur); draftRef.current = cur; noteMachineText(cur); } catch (e) { /* 保守：写失败不改草稿 */ }
              }
            }
          } catch (e) { cur = cur0; /* 保守：词典异常不改草稿 */ }
        }
        const config = (typeof configState !== 'undefined' && configState && configState.value) ? configState.value : {};
        // ⚠ CHG-184（纠错状态可视化批）：相位由 correction.js 的 markCorrection* 三件**统一结算**
        //   （started / settled / failed）—— ⛔ 此处不再自行增减 correctionState 的计数。
        if (typeof markCorrectionStarted === 'function') markCorrectionStarted(sessionId);
        api.call(rpcMethods.VOICE_CORRECT, { sessionId: sessionId, text: cur, config: config }).then((res) => {
          const r = res && typeof res === 'object' ? res : {};
          if (typeof markCorrectionSettled === 'function') markCorrectionSettled(r, cur, sessionId);
          if (r.ok === true && typeof r.text === 'string' && r.text.trim() !== '' && r.text !== cur) {
            if (inputActions && typeof inputActions.setDraft === 'function') {
              try { inputActions.setDraft(r.text); draftRef.current = r.text; noteMachineText(r.text); } catch (e) { /* 保守：写失败不改草稿 */ }
            }
          }
          corrNotify();
          doEnhance();
        }).catch(() => {
          if (typeof markCorrectionFailed === 'function') markCorrectionFailed('NETWORK', sessionId);
          corrNotify();
          doEnhance();                                   // 纠错不可达 ⇒ 不阻断增强
        });
      } catch (e) {
        doEnhance();
      }
    };
    const fire = () => {
      if (!(voiceCfgState.value && voiceCfgState.value.autoEnhance === true)) return;
      if (typeof enhance !== 'function') return;
      enhance(sessionId, draftRef.current, inputActions, draftRef);
    };
    // ⚠ CHG-117（规整改造批 · 清口水词）：识别文本写回草稿**之后**，本地做一次纯规则清理。
    //   · 开关：`voice.filler.enabled`（默认开）；**关闭即整体跳过**（并记一次 skipped ⇒ 可见）。
    //   · 只做删除（不改写/不新增/不改语义/不纠错）；误删防护在 `filler.js` 内（白名单 + 位置保护）。
    //   · 失败/异常一律**不改草稿**（保守：宁可不清理，也不弄坏用户原文）。
    const applyFillerToDraft = () => {
      try {
        if (typeof stripFillers !== 'function' || typeof runFiller !== 'function') return;
        const cur = draftRef.current;
        if (typeof cur !== 'string' || cur === '') return;
        const cfg = voiceCfgState.value && voiceCfgState.value.filler ? voiceCfgState.value.filler : {};
        // 目标模式第二批：清理开关也由同一份后处理计划取真值（与 planning 侧同口径）。
        const fillerAllowed = wantPostprocessStep('filler') || (!planVoiceSteps && cfg.enabled !== false);
        const r = runFiller(cur, fillerAllowed);
        if (!r || r.changed !== true || typeof r.text !== 'string' || r.text === '') return;
        // ⚠ 只在前缀增量上应用（官方刚写入的那段）；避免把用户早先手写的内容一并改动。
        //   简化且安全的判据：仅当**清理后文本**是原文的子序列式删减（长度更短且逐段包含）时才写回。
        if (r.text.length >= cur.length) return;
        if (inputActions && typeof inputActions.setDraft === 'function') {
          inputActions.setDraft(r.text);
          draftRef.current = r.text;
          noteMachineText(r.text);
        }
      } catch (e) { /* 保守：清理异常不影响写回链路 */ }
    };
    const check = () => {
      const w = officialWaitRef.current;
      if (!w) return;
      // 写回已落地 = 草稿非空 且 ≠ 会话起点基线。⚠ 这里必须在**装臂后立刻**也能命中：
      //   官方顺序是 `insertText` → `setPhase("idle")` ⇒ 收口时写回**往往已落地**
      //   ⇒ 若只在「收口之后又变化」才判落地，就永远等不到（实测 V-5 断点）。
      if (draftRef.current && draftRef.current !== w.draft) {
        officialWaitRef.current = null;
        if (w.stop) w.stop();
        // ⚠ CHG-117（规整改造）：官方写回**落地后**先跑「清口水词」（本地纯规则）。
        //   时机：此处正是"官方把识别文本写进草稿"的判定点 ⇒ 清理作用于**新写入的那段**。
        applyFillerToDraft();
        // CHG-143：识别完成 → （开关组合）先纠错、再按需增强
        runCorrectionThenMaybeEnhance();
        return;
      }
      w.tries += 1;
      if (w.tries > 40) { officialWaitRef.current = null; if (w.stop) w.stop(); }  // 40 × 300ms ≈ 12s
    };
    // ⚠ 基线必须取**会话开始时**的草稿，不能取「收口那一刻」的草稿（本批真实语音链实测命中）：
    //   官方 `finish()` 的顺序是 `insertText(...)` **然后** `setPhase("idle")`（官方 client.js 实读）
    //   ⇒ 相位节点消失（bridge 判「会话收口」）时，写回**已经落地** ⇒ 若此刻才快照基线，
    //   基线 = 写回后的草稿 ⇒ 之后永远测不到 delta ⇒ **自动增强永不触发**（实测：草稿 50→75 但零 [enhance] 行）。
    //   故：会话**开始**时记基线（`officialBaseRef`），收口后等「草稿 ≠ 基线」即视为写回落地。
    const arm = (base) => {
      const prev = officialWaitRef.current;
      if (prev && prev.stop) prev.stop();
      const w = { draft: (typeof base === 'string' ? base : draftRef.current), tries: 0, stop: null };
      officialWaitRef.current = w;
      const tick = () => check();
      // 立即判一次：写回可能**已经**在收口前落地（官方 insertText → setPhase("idle") 的固有顺序）
      tick();
      if (timerSvc && typeof timerSvc.interval === 'function') {
        const disposer = timerSvc.interval(tick, 300);
        w.stop = () => { try { if (typeof disposer === 'function') disposer(); } catch (e) { /* 忽略 */ } };
      } else {
        const id = setInterval(tick, 300);
        w.stop = () => { try { clearInterval(id); } catch (e) { /* 忽略 */ } };
      }
    };

    return officialVoiceBridge.subscribe(() => {
      const snap = officialVoiceBridge.snapshot();
      if (!snap) return;
      // 会话**开始**（相位出现）⇒ 记基线草稿 + 重置本会话的收口标记
      // ⚠ 字段名以 `snapshot()` 实际导出为准：它暴露的是 `recording`（= bus.active），**不是** `active`。
      //   （我第一版写成 `snap.active` ⇒ 恒 undefined ⇒ 基线永不记录 ⇒ 写回先于收口时永远测不到 delta。）
      if (snap.recording && !snap.lastEndedAt) {
        // ⚠ UD-0055 / UD-0057（学习词典 · 采集侧）：用户按下录音 = 上一轮编辑**已结束**。
        //   此刻草稿 vs 机器输出快照 ⇒ 差异即「用户纠正」（形近才入库，筛选在契约层）。
        //   ⚠ 必须在记录新基线**之前**取，否则基线已被本轮草稿覆盖（比不到差异）。
        if (typeof officialBaseRef.current !== 'string') { learnFromDraft(); machineTextRef.current = null; officialBaseRef.current = draftRef.current; }
        return;
      }
      if (!snap.lastEndedAt) return;
      if (snap.lastEndedAt === officialEndRef.current) return;   // 同一会话只装臂一次
      officialEndRef.current = snap.lastEndedAt;
      // ⚠ CHG-105（线二现场失效 · 本批核心）：**会话结束时必须复位 `statusRef`**。
      //   病历（现场第 4 块不通过 · “未识别状态使用热键不能继续识别”）：
      //     `statusRef` 的语义是「**已向官方派发过开始**」，它只在三处复位（:208/:212 派发失败、
      //     :226 我们自己派发了停止）—— 而**会话以 `feedback`（未识别）收场时无人复位**
      //     （官方自己结束、我们从未派发停止）⇒ `statusRef` 永远卡在 `'recording'`。
      //     而 `pressStart` 的入口守卫（:289 `if (!wasRecordingAtPress && statusRef.current !== 'idle') return;`）
      //     会把第二次按下**整个吞掉** ⇒ 根本没走到 `startRec()` ⇒ 桥侧线二的 retry 锚
      //     （`OVB_RETRY_LABELS`）**永远没机会被调到** ⇒ 用户看到「按了没反应」。
      //   处置：在**本 effect（已在消费 `lastEndedAt` 的同一信号）**内复位—— **用既有信号/既有机制，不新造机制**。
      //   ⚠ 不可改具 **:289 的守卫本体**：它在「已派发开始、官方尚未落地」的
      //     请求窗口内防**重复开始**（F-18/CHG-098 依赖它）—— 那个作用必须保留。
      if (statusRef.current !== 'idle') statusRef.current = 'idle';
      const base = (typeof officialBaseRef.current === 'string') ? officialBaseRef.current : draftRef.current;
      officialBaseRef.current = null;                            // 供下一会话重新记录
      // ⚠ 官方失败出口（相位 feedback 收尾）⇒ **不进入**「等写回 → 自动增强」：
      //   官方此时没有写回可等，进入等写回只会空转到 12s 上限（既有缺口修复）。
      //   改为按 autoEnhance 立即判定一次（此时草稿 = 用户原话，增强仍是有意义的动作）。
      if (snap.endedInFeedback) { runCorrectionThenMaybeEnhance(); return; }
      arm(base);
    });
  }, [sessionId, inputActions]);

  // ── 热键监听：仅在「已启用且有组合键」时安装 ────────────────────────────────
  const hkCfg = voiceCfgState.value && voiceCfgState.value.hotkey ? voiceCfgState.value.hotkey : null;
  const hkEnabled = !!(hkCfg && hkCfg.enabled && hkCfg.combo);
  React.useEffect(() => {
    if (!hkEnabled) return undefined;              // 未启用 ⇒ 不装监听（UI 已明示「未设置」）
    const hk = parseVoiceHotkey(hkCfg.combo);
    if (!hk) return undefined;
    const onKeyDown = (e) => {
      if (typeof window !== 'undefined' && window.__voiceHotkeyCapturing) return;
      if (e.repeat || !matchVoiceHotkey(e, hk)) return;
      e.preventDefault(); e.stopPropagation();
      pressStart();
    };
    const onKeyUp = (e) => {
      if (typeof window !== 'undefined' && window.__voiceHotkeyCapturing) return;
      if (!matchVoiceHotkey(e, hk)) return;
      e.preventDefault(); e.stopPropagation();
      pressEnd();
    };
    window.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('keyup', onKeyUp, true);
    return () => {
      window.removeEventListener('keydown', onKeyDown, true);
      window.removeEventListener('keyup', onKeyUp, true);
    };
  }, [cfgVer, hkEnabled, sessionId]);

  // 热键 → 派发点击官方开始按钮（唯一能驱动官方整条链的路径）
  function startRec() {
    const st = storeFor(sessionId);
    const res = (typeof officialVoiceBridge !== 'undefined' && officialVoiceBridge
      && typeof officialVoiceBridge.startOfficial === 'function')
      ? officialVoiceBridge.startOfficial()
      : { started: false, via: 'bridge-unavailable' };
    if (res.started) {
      statusRef.current = 'recording';
      if (st.error === 'VOICE_BUSY' || st.error === 'VOICE_OFFICIAL_UNAVAILABLE') { st.error = null; notify(sessionId); }
    } else if (res.via === 'already-capturing') {
      // 官方采集中再按热键：给可见提示（不改行为）
      st.error = 'VOICE_BUSY'; notify(sessionId);
      statusRef.current = 'idle';
    } else {
      // 官方开始按钮不存在 / 派发失败（如官方未就绪、按钮 disabled）⇒ 不得静默失败
      st.error = 'VOICE_OFFICIAL_UNAVAILABLE'; notify(sessionId);
      statusRef.current = 'idle';
    }
  }

  // 热键 → 派发点击官方停止按钮（走完官方 finish()：相位收尾 → 转写 → 写回）
  // 派发一次停止；**返回是否真的停掉了**（供 F-18 判断「是否需要在启动落地后补停」）。
  //   ⚠ 关键实测事实：派发点击开始后、官方相位进入 `recording` 之前存在一个**过渡窗口**
  //   （相位仍在 requesting、官方停止按钮尚未挂载、MediaRecorder 尚未被捕获）⇒ 此刻调用停止会
  //   以 `via:'no-active-session'` 无效果返回（`stopClicks` 不增）。这正是 F-18 的真实可达形态。
  function stopAndTranscribe(delayMs) {
    const run = () => {
      let r = { stopped: false, via: 'bridge-unavailable' };
      if (typeof officialVoiceBridge !== 'undefined' && officialVoiceBridge
        && typeof officialVoiceBridge.stopOfficial === 'function') r = officialVoiceBridge.stopOfficial();
      statusRef.current = 'idle';
      return r && r.stopped === true;
    };
    if (delayMs && timerSvc && typeof timerSvc.timeout === 'function') { timerSvc.timeout(run, delayMs); return null; }
    if (delayMs) { setTimeout(run, delayMs); return null; }
    return run();
  }

  // 读桥快照（官方路径的**权威实况**；本组件的 statusRef 只反映「派发过开始」，不反映官方是否已落地）
  function bridgeSnap() {
    try {
      if (typeof officialVoiceBridge === 'undefined' || !officialVoiceBridge) return null;
      if (typeof officialVoiceBridge.snapshot !== 'function') return null;
      return officialVoiceBridge.snapshot();
    } catch (e) { return null; }
  }
  // 「本轮按下所开的会话**已经收尾**」——收尾（无论成功写回还是失败出口）即说明官方已不在采集，
  // 「松开即停」的目标已达成 ⇒ 补停应判**成功**，不得因「停不掉」而误报失败。
  function sessionEndedSincePress() {
    const snap = bridgeSnap();
    if (!snap) return false;
    const base = releaseEndedBaseRef.current || 0;
    return !!snap.lastEndedAt && snap.lastEndedAt !== base;
  }

  // F-18 消费逻辑：长按松开时启动尚未落地 ⇒ **有界补停**，使「松开即停」最终成立。
  //   为何用「桥实况」而不是 statusRef 作为落地判据：startRec 是同步返回，若启动被外部延后落地，
  //   statusRef 会停在 'idle' 而桥已在采集 ⇒ 只有读桥才看得见。
  //   为何有界：无界轮询会在「启动始终没落地」时空转到会话结束（既有教训：等待必须封顶）。
  function scheduleDeferredStop() {
    let tries = 0;
    const finish = (ok) => {
      longReleaseRef.current = false;
      if (!ok) {
        // A③：窗口用尽仍未看到官方采集 ⇒ 明确告知「松开即停未能执行」（不得静默）
        const st = storeFor(sessionId);
        if (st.error !== 'VOICE_BUSY') { st.error = 'VOICE_OFFICIAL_UNAVAILABLE'; notify(sessionId); }
      }
    };
    const tick = () => {
      if (longReleaseRef.current !== true) return;   // 已被消费/复位（如另一次按下重置）
      tries += 1;
      // 每次 tick **真派发一次停止**，并以「停是否真的生效」为唯一判据（不猜相位、不看 statusRef）
      const ok = stopAndTranscribe(0);
      if (ok === true) { finish(true); return; }
      // 停不掉但**本轮会话已收尾**（成功/失败出口，如静音自动停已抢先完成）⇒ 目标已达成，
      //   ⚠ 必须判成功：否则会对「其实已经停了」的会话误报一次补停失败（读数说反话）。
      if (sessionEndedSincePress()) { finish(true); return; }
      if (tries >= VOICE_RELEASE_DEFER_MAX) { finish(false); return; }
      if (timerSvc && typeof timerSvc.timeout === 'function') { timerSvc.timeout(tick, VOICE_RELEASE_DEFER_MS); return; }
      if (typeof setTimeout === 'function') { setTimeout(tick, VOICE_RELEASE_DEFER_MS); return; }
      finish(false);
    };
    tick();   // 立即判一次：启动可能已在本轮事件循环内落地
  }

  function pressStart() {
    // ⚠ CHG-098：入口守卫**放宽** —— 旧写法 `if (statusRef.current !== 'idle') return;`
    //   会在「上一次点按已把官方开启」（statusRef='recording'）时把**第二次点按整个挡掉**
    //   ⇒ 设计里的「再按结束」永远不可达。
    //   现按**相位真值**分流：官方确在录 ⇒ 允许进入（这一次点按 = 点一下官方「停止」）；
    //   官方未在录但 statusRef 已非 idle（= 已派发开始、官方尚未落地）⇒ 仍挡（防重复开始）。
    const wasRecordingAtPress = officialRecordingNow();
    if (!wasRecordingAtPress && statusRef.current !== 'idle') return;
    pressStartRef.current = Date.now();
    // ⚠ CHG-098（2026-10-15 点按语义修复批）：记录「**本次按下之前**官方是否已在采集」。
    //   为什么必须用**相位真值**而不是 `statusRef`：`statusRef` 在 `startRec()` 里
    //   **被同一次按下刚置真**（见 startRec 内 `statusRef.current = 'recording'`）⇒
    //   拿它判「是否早已在录」会把「我刚开启」误当成「早已在录」
    //   ⇒ 点按分支立刻派发停止 ⇒ 录音被掐断成 <100ms（真机 blob 110B、官方 decodeAudioData 抛错）。
    //   相位真值 = 官方**自己渲染**的 `[data-voice-activity="recording"]`（桥已提供同一语义的读取面），
    //   它只反映「官方此刻确在采集中」，与本次派发是否成功**无关** ⇒ 两者可区分。
    pressWasRecordingRef.current = wasRecordingAtPress;
    pressStatusRef.current = 'idle';
    longReleaseRef.current = false;   // F-18：新一次按下复位待补停标记（防上一轮的补停追到本轮会话）
    const snap0 = bridgeSnap();
    releaseEndedBaseRef.current = snap0 ? (snap0.lastEndedAt || 0) : 0;   // F-18：记本轮会话起点基线
    // ⚠ CHG-098：官方**确已在录** ⇒ 本次按下是「第二次点按」⇒ **不**再派发开始
    //   （旧写法无条件 `startRec()` ⇒ 会走 `already-capturing` 分支写 `VOICE_BUSY`，
    //     既掩盖用户意图，也会破坏紧随其后的长按补停判据）。
    if (!wasRecordingAtPress) startRec();
  }
  function pressEnd() {
    const s = pressStatusRef.current;
    pressStatusRef.current = null;
    if (s === null) return;
    const long = (Date.now() - pressStartRef.current) >= VOICE_LONG_PRESS_MS;
    // 长按：松开即停官方（README 承诺的语义，**不得因「启动尚未落地」而落空**）
    if (long) {
      // F-18 修复：两条进入补停的路径都要覆盖 ——
      //   ① 松开时组件认为已在录（statusRef==='recording'）但**停止派发太早**（相位仍在 requesting、
      //      无停止按钮）⇒ `stopAndTranscribe` 返回 false ⇒ 仍需补停（**这是实测可达的真实形态**）；
      //   ② 松开时启动状态尚未置位（statusRef!=='recording'）⇒ 直接补停。
      //   此前实现对①②都只写 `longReleaseRef` 而**无人消费** ⇒ 「松开即停」静默落空且不留读数。
      const stopped = (statusRef.current === 'recording') ? stopAndTranscribe(0) : false;
      if (stopped !== true) {
        longReleaseRef.current = true;
        scheduleDeferredStop();
      }
      return;
    }
    // 点按 = **模拟点击官方按钮一次**（用户钉死的语义）：
    //   · 按下前官方**已在录** ⇒ 这一次点按等价于点「停止并识别」⇒ 结束（= 设计里的「再按结束」）；
    //   · 按下前官方**未在录** ⇒ 这一次点按等价于点「开始录音」⇒ **到此为止**，
    //     官方继续录，**不得**因松手而派发停止。
    //   ⚠ CHG-098（本批修复）：旧实现写的是 `if (statusRef.current === 'recording') stopAndTranscribe(0)` ——
    //     而 `statusRef` 在 `startRec()` 里**被同一次按下刚置真** ⇒ 该条件恒真 ⇒ 一次点按派发「开始+停止」
    //     ⇒ 录音 <100ms ⇒ 官方 `decodeAudioData` 抛 `EncodingError`（真机 blob 110B）。
    //     现改用「**按下之前**的相位真值」判据 ⇒ 「我刚开启」与「早已在录」可区分。
    if (pressWasRecordingRef.current === true) stopAndTranscribe(0);
  }

  return null; // 无 UI：仅接线（不占官方 conversation.input.activity 槽位）
}


  return { parseVoiceHotkey, matchVoiceHotkey, voiceHotkeyDisplay, VoiceHotkeyHost };
}

module.exports = { createVoiceHotkey, voiceHotkeyDisplay };
