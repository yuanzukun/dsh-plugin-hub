// ============================================================================
// CHG-117（2026-10-16 · 规整改造批）：**清口水词** —— 本地纯规则清理器。
//   · 用户决定（UD-0026/UD-0028/UD-0031）：**不调大模型**；**只清口水词**；
//     **不改写 / 不新增 / 不改语义 / 不纠错**（原话直出）。
//   · 落点：client 半部本地执行（原规整挂在 host RPC `voice/transcribe` 上，
//     而该 RPC 自「自建采集链退役」后已无调用方 ⇒ 整链未接通，`CHG-115` 定位）。
//   · ⚠ 本模块**只做删除**：任何"改写/替换/补字"都不属于本功能。
//   · ⚠ 误删防护（四件，缺一不可）：
//       ① 只删**孤立出现**的语气词（词中/词首不删 —— 见下「位置保护」）；
//       ② **白名单**（易误伤的真实词 / 儿化音 / 叠词词表）；
//       ③ **可配置 + 可关闭**（`voice.filler.enabled`，关闭即整体跳过）；
//       ④ **可见性**（清理几处 / 是否被跳过 —— 见 `fillerSnapshot()`，
//          设置页渲染，**不得静默失效**，承 `CHG-115` `I-2`）。
// ============================================================================

// ── ① 语气词词表 ───────────────────────────────────────────────────────────
// 「可单独删」的单字语气词：不承载语义，且**极少**充当真实词的头/尾（仍有位置保护兜底）。
var FILLER_CHARS = ['嗯', '呃', '唔', '诶', '嘿', '唷'];
// 既可能是语气词、也可能是**真实词头/词尾**的单字 ⇒ 仅当**孤立出现**才删（位置保护更严）。
//  ⚠ 「儿」**不在表内**：它是儿化构词成分，不是语气词（它的保护改为「左邻是词字符则不动」+ 白名单）。
var FILLER_CHARS_GUARDED = ['啊', '呀', '哦', '噢', '哎', '唉', '哟', '嘛', '咧', '咯', '喽'];
// 多字话语标记：**只在「孤立」或「即时重复」时**删（"然后我们做X"里的"然后"是真实连接词，删了会改语义）。
//  ⚠ 分两档（判据不同）：
//   · **无歧义话语标记**（"就是说"/"那个啥"…）—— 出现即为口水词 ⇒ 任一侧是边界即删；
//   · **有歧义**（"那个"/"然后"/"其实"…）—— 也可能是真实指代/连接词
//     （"那个文件"/"然后我们执行"）⇒ **仅在严格孤立或即时重复时**删，否则**保留**。
var FILLER_PHRASES_HARD = ['就是说', '那个啥', '怎么说呢', '你知道'];
var FILLER_PHRASES = ['那个', '这个', '就是', '然后', '其实', '反正'];

// ── ② 白名单（易误伤词表）────────────────────────────────────────────────────
// 真实词：整体**保护**，落在其中/跨越其中的语气词一律不删。
var FILLER_PROTECTED = [
  '阿姨', '啊呀', '哎哟', '哎呀', '哦豁', '嗯哼', '唉呀',
  '女儿', '儿子', '耳朵', '木耳', '银耳', '顺耳', '入耳', '刺耳', '悦耳', '耳目', '耳熟',
  // ── CHG-121 收尾批（2026-10-16）：儿化音白名单**加固**（防将来词表扩张）─────────────
  //   ⚠ 定性（先量后补）：现行**无**风险 —— 「儿」不在 `FILLER_CHARS` / `FILLER_CHARS_GUARDED`
  //     任一张表内，且位置保护已挡住「两侧都是词字符」的词中「儿」；只读实测原文不变（读数见报告 §2）。
  //     本块是**加固**（防将来词表扩张），不是已发生缺陷的补救。
  //   逐条理由（若「儿」入表、且左邻落在**边界**侧（句首/标点后）时会被怎样）：
  //     · 一会儿 / 这会儿 / 那会儿 / 多会儿 / 等会儿 —— 时间量词+儿化；左邻「会」在句首或标点之后
  //       **不是词字符** ⇒ 位置保护夹不住 ⇒ 会被删成「一会 / 这会」（单因子变异实测 5/5 被改坏）；
  //     · 有点儿 / 一点儿 / 差点儿 —— 程度副词+儿化；左邻「有 / 一 / 差」同样可能落在边界侧；
  //     · 玩儿 / 门儿 / 事儿 / 味儿 / 劲儿 / 空儿 —— 单字词根+儿化，左邻为标点/空白时即为边界；
  //     · 头儿 / 苗儿 / 伴儿 —— 名词化儿尾，同上。
  '一会儿', '这会儿', '那会儿', '多会儿', '等会儿',
  '有点儿', '一点儿', '差点儿',
  '玩儿', '门儿', '事儿', '味儿', '劲儿', '空儿',
  '头儿', '苗儿', '伴儿',
  '哪儿', '那儿', '这儿', '那么儿', '这哪儿', '目标', '目的',
  '哦哦', '哈哈', '嘿嘿', '呵呵', '嘻嘻', '哎呀呀',
];
// 叠词白名单：字形重复但**是真实词**（不得按「即时重复」折叠）。
var FILLER_REDUP_SAFE = ['看看', '试试', '想想', '听听', '说说', '走走', '聊聊', '等等', '慢慢', '好好',
  '天天', '人人', '家家', '件件', '样样', '刚刚', '常常', '往往', '渐渐', '偏偏', '明明', '白白',
  '爸爸', '妈妈', '哥哥', '姐姐', '弟弟', '妹妹', '叔叔', '阿姨', '爷爷', '奶奶', '宝宝', '娃娃',
  '谢谢', '悄悄', '偷偷', '轻轻', '静静', '默默', '紧紧', '深深'];

// ── 位置 / 边界判据 ─────────────────────────────────────────────────────────
// 「词字符」= 中日韩表意文字 / 拉丁字母 / 数字 / 下划线 —— 用于判「是否处在词中」。
function isWordChar(ch) {
  if (!ch) return false;
  var c = ch.charCodeAt(0);
  if (c >= 19968 && c <= 40959) return true;        // CJK 统一表意 (U+4E00–U+9FFF)
  if (c >= 13312 && c <= 19903) return true;        // CJK 扩展 A (U+3400–U+4DBF)
  if (c >= 12352 && c <= 12543) return true;        // 假名 (U+3040–U+30FF)
  if (c >= 44032 && c <= 55215) return true;        // 谚文 (U+AC00–U+D7AF)
  if ((c >= 65 && c <= 90) || (c >= 97 && c <= 122)) return true;   // 拉丁 A-Z / a-z
  if (c >= 48 && c <= 57) return true;              // 数字 0-9
  return ch === '_';
}
// 拉长音 / 停顿符：紧邻语气词时视为「边界」（"嗯——" / "嗯……" 是明显的口水音）。
function isPauseChar(ch) {
  return ch === '—' || ch === '～' || ch === '~' || ch === '…' || ch === '·';
}
// 「边界」= 标点 / 空白 / 停顿符（非词字符即边界；词字符与停顿符之外都算）。
function isBoundary(ch) {
  if (ch === undefined || ch === null || ch === '') return true;  // 串首/串尾
  return !isWordChar(ch);
}
// 严格孤立：左右两侧都是**非停顿的**边界（标点/空白/串首尾）——不含「拉长音」。
function isStrictlyIsolated(text, i, j) {
  return isBoundary(i === 0 ? '' : text[i - 1]) && isBoundary(j >= text.length ? '' : text[j]);
}
// 「不处在词中」= **任一侧**是词边界（标点 / 空白 / 串首尾 / 拉长音）。
//   ⚠ 这是单字语气词的判据（口语里语气词后可直接接内容词：「嗯那个…」「呃我觉得…」）。
//   ⚠ 两侧**都是**词字符 ⇒ 身在词中 ⇒ **不删**（如「那个儿化音」的「儿」被词字符夹住）。
function notInsideWord(text, i, j) {
  var L = i === 0 ? '' : text[i - 1];
  var R = j >= text.length ? '' : text[j];
  return (isBoundary(L) || isPauseChar(L)) || (isBoundary(R) || isPauseChar(R));
}
// 位置保护：候选是否落在某个白名单词之内（或与之相邻构成真实词）。
function isProtected(text, i, j) {
  for (var k = 0; k < FILLER_PROTECTED.length; k++) {
    var w = FILLER_PROTECTED[k];
    var from = 0, at;
    while ((at = text.indexOf(w, from)) !== -1) {
      // 重叠即保护（候选与该真实词共用任一字符）
      if (at < j && i < at + w.length) return true;
      from = at + 1;
    }
  }
  return false;
}

// ── ③ 三类清理 ──────────────────────────────────────────────────────────────

// (a) 即时重复词：多字单元重复 ≥2 次 ⇒ 留 1；单字重复 ≥3 次 ⇒ 留 1。
//     ⚠ 叠词白名单（看看/谢谢/爸爸…）不折叠；长度 ≥2 的单元才算重复。
function collapseRedup(text, removed) {
  var out = text;
  // 多字单元：最短 2 字、最长 4 字
  for (var len = 4; len >= 2; len--) {
    var i = 0;
    while (i + len * 2 <= out.length) {
      var unit = out.slice(i, i + len);
      if (unit.trim() === '' || /[\s，。！？、；：""''（）()\-—…]/.test(unit)) { i++; continue; }
      if (FILLER_REDUP_SAFE.indexOf(unit) !== -1) { i++; continue; }
      var end = i + len, n = 1;
      while (out.slice(end, end + len) === unit) { end += len; n++; }
      if (n >= 2) {
        removed.push({ kind: 'redup', text: unit, count: n });
        out = out.slice(0, i + len) + out.slice(end);
        i += len;
      } else i++;
    }
  }
  // 单字重复 ≥3（"我我我"）
  var k = 0;
  while (k < out.length) {
    var ch = out[k];
    if (!isWordChar(ch)) { k++; continue; }
    var e = k + 1, c = 1;
    while (out[e] === ch) { e++; c++; }
    if (c >= 3 && FILLER_REDUP_SAFE.indexOf(ch + ch) === -1) {
      removed.push({ kind: 'redup', text: ch, count: c });
      out = out.slice(0, k + 1) + out.slice(e);
      k += 1;
    } else k = e;
  }
  return out;
}

// (b) 语气词删除
function removeFillers(text, removed) {
  var out = text;
  // 多字短语（长优先，避免"那个啥"被"那个"抢先拆掉）
  var phrases = FILLER_PHRASES_HARD.map(function (w) { return { w: w, hard: true }; })
    .concat(FILLER_PHRASES.map(function (w) { return { w: w, hard: false }; }))
    .sort(function (a, b) { return b.w.length - a.w.length; });
  for (var p = 0; p < phrases.length; p++) {
    var W = phrases[p].w;
    var hard = phrases[p].hard;
    var pos = 0;
    var idx;
    while ((idx = out.indexOf(W, pos)) !== -1) {
      var j = idx + W.length;
      var repeated = out.slice(j, j + W.length) === W;   // 即时重复（"就是就是" ⇒ (a) 也可能已折叠）
      var isolated = hard ? notInsideWord(out, idx, j) : isStrictlyIsolated(out, idx, j);
      if (!isProtected(out, idx, j) && (isolated || repeated)) {
        removed.push({ kind: 'filler', text: W, count: 1 });
        out = out.slice(0, idx) + out.slice(j);
        pos = idx;
      } else pos = idx + 1;
    }
  }
  // 单字语气词（可单独删）
  out = removeCharSet(out, FILLER_CHARS, false, removed);
  // 单字语气词（仅孤立才删）
  out = removeCharSet(out, FILLER_CHARS_GUARDED, true, removed);
  return out;
}

function removeCharSet(text, chars, _unused, removed) {
  var out = text, i = 0;
  while (i < out.length) {
    var ch = out[i];
    if (chars.indexOf(ch) === -1) { i++; continue; }
    var j = i + 1;
    // ① 白名单（真实词 / 叹词）—— 整体保护
    if (isProtected(out, i, j)) { i++; continue; }
    // ② 位置保护：**两侧都是词字符** ⇒ 身在词中（构词成分，如"那个**儿**"的"儿"）⇒ 不删。
    //   ⚠ 判据唯一（不再单列等价分支）：`notInsideWord` = 「任一侧是词边界」
    //   ⇒ 其否定恰好 = 「两侧都是词字符」，故此处**只保留这一条**（避免同义判据重复）。
    if (!notInsideWord(out, i, j)) { i++; continue; }
    removed.push({ kind: 'filler', text: ch, count: 1 });
    out = out.slice(0, i) + out.slice(j);
  }
  return out;
}

// (c) 收尾：清理因删除留下的空白/标点冗余（**不新增任何字符**）
function tidy(text) {
  return text
    .replace(/[ \t]{2,}/g, ' ')              // 连续空格合一
    .replace(/\s+([，。！？、；：])/g, '$1')      // 标点前空白
    .replace(/([，。！？、；：])\1{1,}/g, '$1')     // 重复标点合一
    // ⚠ 被删语气词留下的**孤立拉长音/停顿符**（"嗯——那我们开始" ⇒ "——那我们开始"）⇒ 一并删掉。
    //   仍属"只删"：不新增任何字符。
    .replace(/^[\s—～~…·]+/, '')
    .replace(/[\s—～~…·]+$/, '')
    .replace(/^\s*[，。！？、；：]+/, '')          // 串首孤立标点
    .replace(/[，。！？、；：]+$/, function (m) { return m.length > 1 ? m[0] : m; })
    .trim();
}

// ── 对外主函数 ──────────────────────────────────────────────────────────────
/** 纯函数：清理口水词。返回 {text, changed, removed, count}。 */
function stripFillers(input) {
  if (typeof input !== 'string' || input === '') return { text: input, changed: false, removed: [], count: 0 };
  var removed = [];
  var out = collapseRedup(input, removed);
  out = removeFillers(out, removed);
  out = tidy(out);
  // ⚠ 兜底：清理器**只许做减法** —— 若出现任何新增字符，判为异常并**原样返回**（保守）
  if (out.length > input.length) return { text: input, changed: false, removed: [], count: 0 };
  return { text: out, changed: out !== input, removed: removed, count: removed.length };
}

// ── ④ 可见性：统计 + 订阅（设置页渲染，不得静默）──────────────────────────────
var fillerState = { runs: 0, cleaned: 0, removedTotal: 0, skipped: 0, lastText: '', lastRemoved: [], lastAt: 0, lastSkipReason: '', legacyChecked: false, legacyCleaned: false, legacyAt: 0 };
var fillerListeners = new Set();
function notifyFiller() { for (var fn of Array.from(fillerListeners)) { try { fn(); } catch (e) { /* 忽略 */ } } }
function subscribeFiller(fn) { fillerListeners.add(fn); return function () { fillerListeners.delete(fn); }; }
function fillerSnapshot() {
  return { runs: fillerState.runs, cleaned: fillerState.cleaned, removedTotal: fillerState.removedTotal,
    skipped: fillerState.skipped, lastRemoved: fillerState.lastRemoved.slice(), lastAt: fillerState.lastAt,
    lastSkipReason: fillerState.lastSkipReason,
    // CHG-117：旧父键 `voice.refine` 一次性清理的**可见**读数（用户裁定 2：不得静默删）
    legacyChecked: fillerState.legacyChecked === true,
    legacyCleaned: fillerState.legacyCleaned === true,
    legacyAt: fillerState.legacyAt || 0 };
}
/** 带可见性的执行入口：`enabled=false` ⇒ 记为**跳过**（可见），不静默。 */
function runFiller(text, enabled) {
  if (enabled !== true) {
    fillerState.runs += 1; fillerState.skipped += 1;
    fillerState.lastSkipReason = 'disabled'; fillerState.lastAt = Date.now();
    notifyFiller();
    return { text: text, changed: false, removed: [], count: 0, skipped: true, reason: 'disabled' };
  }
  var r = stripFillers(text);
  fillerState.runs += 1; fillerState.lastAt = Date.now();
  if (r.changed) { fillerState.cleaned += 1; fillerState.removedTotal += r.count; fillerState.lastRemoved = r.removed; fillerState.lastSkipReason = ''; }
  notifyFiller();
  return r;
}


// 目标模式：清口水词以普通 CommonJS 模块承载；导出面与旧 chunk 的顶层声明逐项一致。
module.exports = {
  isWordChar,
  isPauseChar,
  isBoundary,
  isStrictlyIsolated,
  notInsideWord,
  isProtected,
  collapseRedup,
  removeFillers,
  removeCharSet,
  tidy,
  stripFillers,
  notifyFiller,
  subscribeFiller,
  fillerSnapshot,
  runFiller,
  FILLER_CHARS,
  FILLER_CHARS_GUARDED,
  FILLER_PHRASES_HARD,
  FILLER_PHRASES,
  FILLER_PROTECTED,
  FILLER_REDUP_SAFE,
  fillerState,
  fillerListeners,
};
