import { CLASSES, STYLE_TAG_ID } from './constants'

/**
 * One stylesheet shipped as an owned `<style data-plugin-css>` tag, the
 * convention the client module system records (`ClientModuleRecord.styles`) and
 * drops with the bundle. No CSS-in-JS runtime is bundled: the plugin stays
 * independent of any host application's styling stack. Colours come from the
 * platform's design tokens, with plain fallbacks for a host that lacks them.
 */
const CSS = `
.${CLASSES.root}{display:grid;gap:12px;color:var(--dsw-alias-label-primary,inherit);font-size:13px;line-height:20px}
.${CLASSES.header}{display:grid;gap:2px}
.${CLASSES.title}{margin:0;font-size:14px;font-weight:600;line-height:22px}
.${CLASSES.description}{margin:0;color:var(--dsw-alias-label-secondary,inherit)}
.${CLASSES.help}{margin:0;color:var(--dsw-alias-label-caption,inherit);font-size:12px;line-height:18px}
.${CLASSES.error}{margin:0;color:var(--dsw-alias-state-error-primary,#d63e3e)}
.${CLASSES.success}{margin:0;color:var(--dsw-alias-state-success-primary,inherit)}
.${CLASSES.section}{display:grid;gap:8px}
.${CLASSES.sectionTitle}{margin:0;font-size:12px;font-weight:600;color:var(--dsw-alias-label-secondary,inherit)}
.${CLASSES.list}{display:grid;gap:0;margin:0;padding:0;list-style:none;border:.5px solid var(--dsw-alias-border-l4,rgba(127,127,127,.25));border-radius:16px;overflow:hidden}
.${CLASSES.row}{display:flex;align-items:center;gap:12px;padding:10px 12px;border-top:.5px solid var(--dsw-alias-border-l4,rgba(127,127,127,.25))}
.${CLASSES.row}:first-child{border-top:0}
.${CLASSES.rowText}{display:grid;gap:2px;min-width:0;flex:1 1 auto}
.${CLASSES.rowName}{display:flex;align-items:center;gap:6px;font-weight:500;overflow-wrap:anywhere}
.${CLASSES.rowMeta}{color:var(--dsw-alias-label-caption,inherit);font-size:12px;line-height:18px;overflow-wrap:anywhere;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;line-clamp:2;overflow:hidden}
.dsh-tool-activator-chip{display:inline-flex;align-items:center;flex:0 0 auto;height:18px;padding:0 6px;border-radius:9px;font-size:11px;font-weight:400;line-height:16px;color:var(--dsw-alias-label-secondary,inherit);background:var(--dsw-alias-bg-layer-2,rgba(127,127,127,.12))}
.dsh-tool-activator-switch{box-sizing:border-box;position:relative;flex:0 0 auto;width:36px;height:20px;padding:2px;border:0;border-radius:10px;background:var(--dsw-alias-border-l3,rgba(127,127,127,.4));cursor:pointer}
.dsh-tool-activator-switch[aria-checked=true]{background:var(--dsw-alias-brand-primary,#4d6bfe)}
.dsh-tool-activator-switch:disabled{cursor:default;opacity:.5}
.dsh-tool-activator-switch:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#4d6bfe);outline-offset:2px}
.dsh-tool-activator-switch-thumb{display:block;width:16px;height:16px;border-radius:50%;background:var(--dsw-alias-label-primary-foreground,#fff);transition:transform .12s ease}
.dsh-tool-activator-switch[aria-checked=true] .dsh-tool-activator-switch-thumb{transform:translate(16px)}
.${CLASSES.setting}{display:flex;align-items:center;gap:12px;padding:10px 12px;border-top:.5px solid var(--dsw-alias-border-l4,rgba(127,127,127,.25))}
.${CLASSES.setting}:first-child{border-top:0}
.${CLASSES.settingIcon}{display:inline-flex;align-items:center;justify-content:center;width:14px;height:14px;border:.5px solid var(--dsw-alias-border-l3,rgba(127,127,127,.45));border-radius:50%;color:var(--dsw-alias-label-caption,inherit);font-size:10px;line-height:1;cursor:help}
.${CLASSES.groups}{display:grid;gap:10px}
.${CLASSES.group}{display:grid;gap:0;border:.5px solid var(--dsw-alias-border-l4,rgba(127,127,127,.25));border-radius:12px;overflow:hidden}
.${CLASSES.groupHeader}{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 12px;background:var(--dsw-alias-bg-layer-2,rgba(127,127,127,.06))}
.${CLASSES.groupBody}{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px 12px;padding:0}
.dsh-tool-activator-group-filter{flex:1 1 auto;min-width:120px}
.${CLASSES.field}{display:grid;gap:4px;min-width:0}
.${CLASSES.fieldWide}{grid-column:1/-1}
.${CLASSES.fieldLabel}{color:var(--dsw-alias-label-secondary,inherit);font-size:12px}
.${CLASSES.choices}{display:flex;flex-wrap:wrap;gap:4px 12px;max-height:160px;overflow:auto}
.${CLASSES.choice}{font-size:12px}
.${CLASSES.toolbar}{display:flex;align-items:center;flex-wrap:wrap;gap:8px}
.dsh-tool-activator-input{box-sizing:border-box;width:100%;min-width:0;height:28px;padding:0 8px;border:.5px solid var(--dsw-alias-border-l4,rgba(127,127,127,.3));border-radius:8px;color:var(--dsw-alias-label-primary,inherit);background:var(--dsw-alias-bg-layer-1,transparent);font:inherit;font-size:12px}
.dsh-tool-activator-input:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#4d6bfe);outline-offset:1px}
.dsh-tool-activator-checkbox{display:inline-flex;align-items:center;gap:6px;cursor:pointer}
.dsh-tool-activator-checkbox:has(input:disabled){cursor:default;opacity:.5}
.dsh-tool-activator-button{display:inline-flex;align-items:center;height:28px;padding:0 10px;border:.5px solid transparent;border-radius:8px;color:var(--dsw-alias-label-primary,inherit);background:0 0;font:inherit;font-size:12px;cursor:pointer}
.dsh-tool-activator-button-outline{border-color:var(--dsw-alias-border-l4,rgba(127,127,127,.3))}
.dsh-tool-activator-button-primary{background:var(--dsw-alias-brand-primary,#4d6bfe);color:var(--dsw-alias-label-primary-foreground,#fff)}
.dsh-tool-activator-button:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover,rgba(127,127,127,.08))}
.dsh-tool-activator-button:disabled{opacity:.5;cursor:default}
.dsh-tool-activator-tooltip-anchor{display:inline-flex;align-items:center}
.dsh-tool-activator-collapsible{display:grid;border:.5px solid var(--dsw-alias-border-l4,rgba(127,127,127,.25));border-radius:16px;overflow:hidden}
.dsh-tool-activator-collapsible-header{display:flex;align-items:center;gap:8px;padding:8px 12px;background:var(--dsw-alias-bg-layer-2,rgba(127,127,127,.06))}
.dsh-tool-activator-collapsible-toggle{display:flex;align-items:center;gap:6px;flex:1 1 auto;min-width:0;padding:0;border:0;background:0 0;color:inherit;font:inherit;text-align:left;cursor:pointer}
.dsh-tool-activator-collapsible-toggle:focus-visible{outline:2px solid var(--dsw-alias-brand-primary,#4d6bfe);outline-offset:2px}
.dsh-tool-activator-collapsible-label{font-size:12px;font-weight:600;color:var(--dsw-alias-label-secondary,inherit);overflow-wrap:anywhere}
.dsh-tool-activator-collapsible-chevron{display:inline-block;flex:0 0 auto;font-size:10px;line-height:1;color:var(--dsw-alias-label-caption,inherit);transition:transform .12s ease}
.dsh-tool-activator-collapsible-chevron[data-open]{transform:rotate(90deg)}
.dsh-tool-activator-collapsible-actions{display:flex;align-items:center;gap:8px;flex:0 0 auto}
.dsh-tool-activator-collapsible-body{display:grid;gap:8px;padding:10px 12px}
.dsh-tool-activator-collapsible-body[hidden]{display:none}
`

export function ownedStyleTag(): HTMLStyleElement | null {
  return document.querySelector<HTMLStyleElement>(`style[data-plugin-css="${STYLE_TAG_ID}"]`)
}

export function mountToolActivatorStyles(): () => void {
  if (typeof document === 'undefined')
    return () => {}
  if (ownedStyleTag() !== null)
    return () => {}
  const tag = document.createElement('style')
  tag.dataset.plugin = 'dsh-tool-activator'
  tag.dataset.pluginCss = STYLE_TAG_ID
  tag.textContent = CSS
  document.head.append(tag)
  return () => tag.remove()
}
