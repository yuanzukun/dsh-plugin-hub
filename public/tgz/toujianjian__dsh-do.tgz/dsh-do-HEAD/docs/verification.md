# 验证记录

## 第十二轮（Docker 暴力测试：随机+敌意输入下修掉恢复路径两个真实缺陷）

方法不是"点几下"，而是把**可达输入面**机器化：`test-docker/brute/` 下三套 Tier 1（纯函数 29,886 次调用；检查点存储的真实文件系统行为：12×60 并发写、4000 文件、畸形布局、FIFO、40 次 SIGKILL、读写竞态、符号链接、id 遍历；`readJsonBody` + 设置路由 handler 的 13 个正例与 300 次方法/头/体模糊），加一套 Tier 2（容器里起真实 web020 部署，压它自己的 `/dsh-do/settings`：250 并发读、200 次写、90 次滥用）。判据不只是"不抛异常"：**被接受的值必须落在文档化定义域内**，否则状态面板就是在说谎。

完整方法与逐项结果见 `test-docker/brute/README.md`；一键复跑 `docker exec dsh-env bash /root/brute/run-all.sh`。

### 缺陷 1（中）：一个畸形检查点让**所有**循环都无法恢复

`parseCheckpoint` 的诊断把未信任值交给 `String()`：

```ts
if (version !== 1) return { ok: false, error: `... unsupported version ${String(version)}` }   // 旧代码
```

当 `version` 带一个**非函数的自有 `toString`**（`{"toString":null}` / `{"toString":7}`）时，`String()` 抛 `TypeError`，逃出 `parseCheckpoint` → 逃出 `LoopStore.load()`（那里没有 try）→ `restore()` 只打一条 warn，**其余健康检查点一个都不恢复**。所有 armed 循环重启后静默停摆。

一个容易搞错的细节：`{"toString": …}` 只遮蔽同名属性，**同名 accessor 不会**触发（属性名不同）；真正致命的是"值不是函数"。

**修复**：新增 `describeValue()`，只回显 JSON 标量、对象/数组只报种类，**永不触发用户态转换**；三处 `String()` 全部替换。同时在 `load()` 里把 `parseCheckpoint` 包进 try/catch 兜底——解析器以后再出任何意外也只丢那一个文件。

### 缺陷 2（中低）：检查点目录里的 FIFO 让恢复永久挂起

`load()` 不判类型直接 `readFile`：无写端的 FIFO 永不返回（`/dev/zero` 会无限读），而 `await restore` 排在注册 `/loop` 与循环工具**之前**，于是插件"静默半死"——进程活着，命令全没了。同一根因下，一个超大假文件会被整个读进内存。

**修复**：读前 `lstat`（不跟随链接），只接受 `isFile()`。符号链接也拒——它不是本 store 写的，写穿过去还会落到目录外。

### 复测

- `node --test test/*.test.mjs`：**219 用例 / 194 通过 / 0 失败 / 25 跳过**（跳过的是真实组合层，容器里跑）。本轮 +4 条：`a checkpoint whose version cannot be stringified is skipped, not thrown`、`checkpoint diagnostics describe hostile scalars without coercing them`、`LoopStore ignores non-regular files instead of blocking on them`（Windows 上符号链接/`mkfifo` 不可用时自动跳过），另有一条 `armed terminal phase` 具体化断言。
- `repro-poison.mjs` 从"load() 抛错、丢光全部检查点"变为"`unsupported version an object` + 返回 1 个循环"。
- 暴力套件：`run-store` / `run-http` 由 fail 转 **ok=true**；`web-load`（真实 web020）**ok=true**，250 并发读 250×200，90 次滥用后服务仍正常、设置段未被改动。

### 仍未修（低危，留给用户定夺）

1. **`canonicalizeArguments` 深嵌套栈溢出**：`sortJsonValue` 递归，5000 层即 `RangeError`；而 `JSON.parse` 可解析到 12000 层，故该输入在模型侧可达。出现在工具钩子里，会让一次调用抛错而不是退化为"不检测"。
2. **canonical 化对极少数畸形键不幂等**：1500 个敌意值中 2 个满足 `canonicalize(parse(canonicalize(v))) ≠ canonicalize(v)`，后果是重复调用漏检。见证已保存（`test-docker/brute/hunt-canonical.mjs`），尚未最小化到能定根因的形状。

### 顺带记录的边界

- 0.2.0-rc.2 的真实 web 部署上，**设置写入整体被宿主拒绝**（`500 dsh: profile reload requires the root Include entry`，见第九轮）。不是本插件缺陷，但意味着那条部署上设置"能读不能存"，revision 围栏/409 生成路径走不到。
- 该部署里 dsh-do 的设置段名实际是 **`do`**，而路由的 `READ_NAMESPACES` 白名单写的是 `dsh-do`；这段能出现在 GET 里靠的是 `isDoSection()` 形状兜底。建议对齐（或断言 `settingsNamespace()` 的真实取值），否则形状一变这段会静默消失。
- `lib/types/*.js`（未打包产物）依赖 rc.6 的 `@deepseek-ai/dsh-settings` 导出（`deepEqualJson` 等），0.2.0-rc.2 已无这些符号；发布的 `lib/index.js` 是自包含 bundle 所以不受影响，但**任何按目录深导入内部模块的代码**都必须配 rc.6。套件的搭法见 `test-docker/brute/setup-nm.sh`。
- SIGKILL 打断原子写会残留 `.tmp`（实测每次最多 1 个）；`load()` 忽略但从不清理。


## 第八轮（重试配置的真实读写语义：用真 schema 验证，推翻我自己的三条假设）

目标 (a)：`llm-pi-ai` 嵌套 `retryPolicy` 的真实读写。新增 `test/retry-policy-real.test.mjs`（8 条真实依赖用例），把真实服务的 `settings` 与**真实的 `RetryPolicySchema`**（从运行时 `@deepseek-ai/dsh-llm` 导入，非手写）组合起来。

### 被真实依赖推翻的三条假设（都是我的错，不是产品缺陷）

1. **以为退避参数是 schema 字段。** 真实 `RetryPolicySchema` 只带 `maxRetries`、`retryableCodes` 与 `mode`；`initialDelayMs` / `maxDelayMs` / `jitterRatio` 是 `resolveRetryPolicy()` 在适配器解析时补的，**不在 section schema 里**。
2. **以为用户层不写 `mode` 就会被拒。** 实际 section 解析是**「组合条目 base + 用户层」叠加**：只要 base 已带 `mode`，用户层写半截对象照样解析成功。
3. **以为"必须整对象写入"是普遍约束。** 它只在**base 未提供 `retryPolicy`** 时才成立——那时没有任何层能补出必需的判别字段，半截写入才被拒。

### 得到证实的结论

- **路径级写入保留兄弟字段**：对真实的 union schema，`providers.<id>.retryPolicy.maxRetries` 这样写下去，`mode` 与 `retryableCodes` 都原样保留（`applyPathOp` 逐层 spread）。同一个 revision-fenced 请求里连写多个叶子也成立。
- **`mode` 确为必需且是 `const`**：`{maxRetries:3}`（无 mode）且 base 无 policy 时被拒；未知 mode 被拒；`unset mode` 在无 base 兜底时被拒。
- **`RetryPolicySchema = z.union([normal, always])`**：`always` 分支是独立成员且**不含 `retryableCodes`**，页面可切换。
- 这些拒绝都不是 `SETTINGS_CONFLICT`——与第六轮的状态码分类自洽。

### 工具坑（已记入记忆）

用 `Promise.all` 并发 `import()` 运行时模块会触发 `ERR_REQUIRE_ESM_RACE_CONDITION`（cosmokit "not yet fully loaded"）；改成**顺序加载**即可。

### 复测

- `npm test`：**143 用例 / 143 通过 / 0 失败 / 0 跳过**（本轮 +8）。
- `lib/` 已随完整构建同步。本轮**无产品代码改动**，仅新增验证与文档。

## 第七轮（循环为何"自己停了"：查证为官方契约，非缺陷）

**现象**：重启后检查点显示 `loop-198697e0 | phase=active | armed=false | rounds=1/12`，且写入时间 **19:58:53 不在任何重启边界上**——是运行期被 disarm 的。`armed=false` 意味着循环**不会自行继续**。

**查证方法**：①逐行比对官方 `dsh-goal-round-driver` 的 disarm 触发点；②解压真实会话日志取 `turn/end` 的 `reason`。

**结论：与官方契约逐行一致，不是本插件的偏差。** 官方驱动对 turn/end 的处理是：

```js
case "turn/end":
    if (event.data.reason.kind === "max-tokens") { disarm(state); return; }   // ← 与本插件相同
    if (event.data.reason.kind !== "aborted") return;
    if (state.attempt?.phase === "claimed" || state.attempt?.phase === "admitted") state.attempt.cancelled = true;
    else disarm(state);
```

真实日志（12441 帧 / 19650 事件）里 `turn/end` 共 30 次，其中 **`max-tokens` 出现 2 次**，另有多轮 `aborted`（`reason.kind: "user"`，即真人插话接管）。admitted 的 loop 轮次恰好 2 个（`loop-ab9b7d6d` round 1、`loop-198697e0` round 1），与实测吻合。因此 `armed=false` 是**"长回合撞 max-tokens / 真人接管"按设计暂停**的结果。

**故本轮不改动驱动语义**——改了就会与官方 goal 的行为分叉。

### 由此暴露的一个真实体验缺口（待用户决定）

循环被暂停后**没有任何面向用户的提示**：检查点里 `armed=false`，用户必须主动敲 `/loop` 才知道它停了。而官方 goal 体系暂停的是 goal 对象，由 goal UI 显著展示。这是"长回合撞 max-tokens → 循环静默停止"的体验问题，属于**新增可见性**（例如暂停时输出一条提示），不是修既有缺陷——按规矩先报给用户定夺，未擅自实现。

### 工具教训（非产品缺陷）

会话日志 `session.jsonl.zstd` 是**多帧 zstd**（每次 append 一帧）。Node 的 `zstdDecompressSync` **只解第一帧**，直接整体解压只会得到 1 个事件，极易误判成"日志是空的/格式变了"。正确做法：按魔数 `28 B5 2F FD` 切帧后逐帧解压（本轮 1 → 12441 帧）。

## 第六轮（用真实依赖替代假服务，暴露设置路由两个真实缺陷）

方法：不再依赖手写假服务，而是**挂载出厂的文件 provider**（`@deepseek-ai/dsh-settings-file`，与 web profile 实际运行的同一张依赖图），让被测的 `mutate` / `applyPathOp` / revision 围栏 / schema 解析 / 失败机器码都是部署真正会跑的那一套。新增 `test/settings-real.test.mjs`（6 条），仅在设置 `DSH_COMPOSITION_RUNTIME_MANIFEST` 时实跑（沿用仓库既有的真实 Loader lane 约定）。

### 先读真实语义，再定判据

`dsh-settings` 的 `applyPathOp` 逐层 `{...section, [head]: …}` 递归 → **深层路径写入天然保留兄弟字段**（"不碰兄弟字段"这条主张由此首次得到实证，此前只是断言）。同时读出三条假服务从未模拟的契约：①空路径 `set` 是**整段替换**且**要求 plain object**，否则抛 `TypeError`；②revision 校验发生在**写入队列内部**；③只有原始段真的变化才 `bumpRevision`（无操作写入不涨版本）。

### 缺陷 1：解析器放过非对象根写入

`parseSettingsWriteRequest` 对空路径只检查 `'value' in op`，不管类型。而真实服务的 `applyPathOp` 对非 plain object 的根写入抛 `TypeError`。结果是**一个畸形请求以服务内部错误的形式冒出**，并被旧代码一律报成 409。注释里本就写着"requires a plain object"，代码却没实现——文档意图与实现不一致。

**修复**：解析器新增 `isPlainObjectValue`（拒绝标量、null、数组、类实例），对该情形返回 400 并给出面向请求本身的说明。

### 缺陷 2：所有写入失败一律 409

真实 `SettingsConflictError` 带一个**文档化的稳定机器码**：

```ts
readonly code = "SETTINGS_CONFLICT";   // "Stable machine code for wire layers mapping this to their own taxonomy"
```

上游明确说了这是给**线层**做分类用的，而旧路由把 `mutate` 的**任何**失败都报成 409——等于告诉页面"你的副本过期了，重新加载"，而真实原因可能是请求畸形、schema 拒绝、命名空间未注册或 provider 只读。

**修复**：按机器码分类——`code === 'SETTINGS_CONFLICT'` → 409；`TypeError`（op 形状 / 非 JSON 数据 / 根写入类型）→ 400；其余（未注册、已销毁、只读）→ 500。并**回显机器码**，让页面不必解析文案。

### 附带发现：假服务与真实契约的偏差（由红测暴露）

改完状态码后两条既有用例转红——因为**假服务的冲突错误没有 `code`**，按真实契约判定就成了 500。这正是本轮方法的意义：假服务掩盖了它自己没模拟的契约。已按真实语义修正假服务（补上 `SETTINGS_CONFLICT` 机器码），并把"未注册命名空间"的断言改为 500 且明确 `code` 为 undefined。

### 未改动（留待用户决定）

**写路径没有命名空间白名单**：读路径限定 `READ_NAMESPACES`，写路径把任何 `ns` 直接交给服务。因为同源策略已保护、且页面只写它读到过的命名空间，本轮未收紧（收紧属于设计变更）。若要与读路径对齐，可在解析器里限定 `ns ∈ READ_NAMESPACES`，那样"未注册命名空间"就会变成干净的 400。

### 复测

- `npm test`：**135 用例 / 135 通过 / 0 失败 / 0 跳过**（本轮 +7）。
- 双端 typecheck 干净；`lib/` 已随 `npm test` 的完整构建同步。
- **本轮改动尚未部署到 web profile**（部署需重启，会打断正在运行的验证循环）。

## 第五轮（真实使用发现的缺陷：`/loop` 建好循环但首轮不跑）

### 现象与证据

用户实际输入 `/loop 你看看，现在可以用了` 后反馈"没有开始"。磁盘检查点 `~/.dsh/loops/loop-<id>.json` 显示循环**创建成功**（`phase: active`、`armed: true`、`objective` 正确、`maxRounds: 20`、`intervalMs: 600000`），但 **`roundsStarted: 0`** —— 轮次从未被 admit。即：命令被处理了、循环看起来完全健康，却一轮都没跑。

### 根因

驱动的全部唤醒来源都是 **agent 生命周期事件**（`agent/status` 转 `idle`、inbox 变化、`session/event`、以及装载时对既有 agent 的一次性扫描）。而**执行斜杠命令不产生任何状态迁移**——命令"不发送给模型"，agent 本来就 idle、执行完仍然 idle，所以 `agent/status` 永远不会因这次操作而触发。同时 `LoopController.commit()` 只写检查点，**不通知任何人**。结果：新建的循环只能干等下一次与它无关的 idle 迁移（例如用户再发一条普通消息）才可能被驱动看到。

**官方对照（决定性证据）**：`@deepseek-ai/dsh-goal-round-driver` 的监听器清单里有一条本插件缺失的唤醒——`ctx.on("goal/changed", ({ agent }) => { …; requestDrive(state) })`（其 `readyToDrive` 与本插件逐条一致，同样强制 `status === "idle"`）。所以 `/goal` 能在命令执行后立刻起跑，正是靠这条信号。

**上游契约对照**：Claude Code 还原源码 `src/skills/bundled/loop.ts` 第 67 行明确写着 *"**Then immediately execute the parsed prompt now** — don't wait for the first cron fire."*。本插件的 interval 解析规则（前导 interval token、尾部 `every <N><unit>` 从句、默认 10m、"check every PR" 不算 interval）与它逐行一致，唯独这条"立即执行"契约没有被兑现。

### 修复

1. `src/controller.ts`：新增导出类型 `LoopChangeNotifier` 与 `setNotifier()`；`commit()` 在**仅当 `phase === 'active' && armed`** 时调用通知（终态与 pause 刻意静默）。通知抛错被捕获并记 warn，**绝不连累触发它的那次变更**。
2. `src/driver.ts`：`installLoopDriver` 改为返回 `LoopDriverHandle { nudge(sessionId) }`，内部把 sessionId 装成 `SessionId` 找活 agent 并 `requestDrive`。找不到 agent 时安全返回；驱动的 pass 会重读实时状态，循环未 armed/active 时自然不排队。
3. `src/index.ts`：装配期把 `controller.setNotifier` 接到 `driver.nudge`，并在 `yield` 的 teardown 里解绑，保证已销毁的驱动不会被后续变更调用。
4. `src/driver.ts`（同轮补的第二个缺口）：`agent/session-start` 时也 `requestDrive`。**重启恢复的循环不走 `commit()`**（`restore()` 直接写入注册表，不触发通知），而重启后 agent 是在插件装载**之后**才出现的，因此也错过装载期的追赶扫描——两处都够不着，恢复的 armed 循环会一直静默到某次无关的 idle 迁移。会话启动是最后一个能唤醒它的时机。

### 本轮新增测试（+5，共 127）

| 用例 | 锁定的契约 |
| --- | --- |
| starting a loop on an already-idle agent queues the first round at once | **修复本身**：驱动已装载后再 `start`，首个 round 立刻排队 |
| without the change sink the same start stays dormant (the reported failure) | **对照组**：不接通知时同一次 `start` 不排队、循环仍 armed —— 精确复现用户遇到的故障 |
| the controller notifies only for armed active loops | 通知时机：create/resume/edit 通知；pause、complete、cancel 静默 |
| a failing change sink never fails the mutation that caused it | 通知抛错时循环仍创建成功，且留下 warn |
| detaching the sink stops wakeups, so a disposed driver is never called | teardown 解绑有效 |

测试脚手架新增 `deferStart` / `wireNotifier` 两个选项：`deferStart` 复刻"驱动已装载、循环后创建"的真实顺序（默认顺序只覆盖装载时的追赶扫描）。

### 复测

- `npm test`（完整构建 + 真实 Loader + 真实 `CommandRuntime`）：**127 用例 / 127 通过 / 0 失败 / 0 跳过**。
- 双端 `tsc --noEmit` 干净。

### 有意保留的差异（对照 Claude Code）

- **裸 `/loop`**：Claude Code 打印 usage，本插件打印当前循环状态。保留本插件行为——需求是"像 `/goal` 那样用斜杠命令继续"，`/goal` 的裸调用正是显示状态。
- **调度模型**：Claude Code 的 `/loop` 是一个 skill，由**模型**解析后再调用 cron 工具（带 `DEFAULT_MAX_AGE_DAYS` 过期）；本插件由代码确定性解析、以"轮次间最小延迟"驱动（见第三轮设计决策），不引入 cron 与过期语义。

## 第四轮（本轮：`/loop` 节奏执行、TUI 兼容、真实 Loader 复验）

### 已通过

- `npm run typecheck`：Host 与 Client 双 `tsc --noEmit` 通过。
- `npm test`（完整构建 + `node --test test/*.test.mjs`）：**122 个用例，122 通过，0 失败，0 跳过**。
- **真实 Loader 用例已实跑**（本轮首次）：设置 `DSH_COMPOSITION_RUNTIME_MANIFEST` 为本机 DSH 的 `package.json` 后，`test/composition.test.mjs` 的 `installed Loader mounts the single bundle row and removes it cleanly` 由跳过转为通过——真实 `cordis-plugin-loader` 挂载本插件的唯一 `insert` 行，断言 entry fiber 达到 ACTIVE、注册与卸载都干净、且 `ctx.get('webServer') === undefined`。累计 0 跳过。
- **真实 `CommandRuntime` 用例**：`/loop` 的注册不再只由手写假 registry 覆盖，而是挂载真实的 `@deepseek-ai/dsh-commands`，经真实 `normalizeDefinition` 校验、`list()`/`find()` 解析、并以真实 `CommandInvocation` 形状驱动 handler；同时断言卸载插件会**释放命令名**（否则重载会重复注册或留下绑死已销毁 controller 的陈旧 handler）。
- 基线对比：47（初始）→ 50（审计轮）→ 98（第三轮）→ 121（节奏与 TUI）→ **122**（本轮）。
- 单一插件约束仍然成立：`cordis.patch.yml` 仍只有一条 `insert`，`id: do` / `name: dsh-do`，由 `test/package.test.mjs` 断言；真实 Loader 用例再次确认该行能独立挂载并卸载。
- 构建产物已同步：`lib/`、`lib/types/`、`lib/client.js` 均由本轮源码重新生成。
- 本轮构建哈希：Host `lib/index.js` = `C9B45224565257D7DFB94D795C0B7C710D0C1A42CBD3CA21D75F9CEBD62BED6A`（Host 半是确定性构建，多次重建同哈希）；Client `lib/client.js` 每次重建都会变，见"发现：客户端构建非确定性"。

### TUI（`dsh-tui`）组合验证

`dsh-tui` 即 `@huiliyi37/dsh-tianshu-tui` v0.1.1-rc.6，profile 位于 `~/.dsh/profiles/tui`，组成 = `@deepseek-ai/dsh-base` + `@huiliyi37/dsh-tianshu-tui`（只 insert 一行 `tui-runner`）。

- 把本轮 tarball 装入该 profile 后 `dsh --profile tui --dump-config` 输出同时包含 `- id: tui-runner / name: '@huiliyi37/dsh-tianshu-tui'` 与 **唯一的** `- id: do / name: dsh-do`（`config` 为 `defaultMaxRounds: 20 / checkpointDir: '' / persist: true`）。
- 该 profile 提供 `agents` / `tools` / `systemPrompt` / `commands` / `settings` / `compaction`，**没有 `webServer`** —— 因此 dsh-do 的硬注入与各可选门控全部满足，Web 专属的 `/dsh-do/settings` 路由正确地不安装。
- 组合打印不等于运行期行为：TUI 内的 `/loop` 实际交互仍须人工在 TTY 里验收（见"尚未声称完成"）。

### 本轮发现并修复的真实缺陷

1. **`intervalMs` 只被解析、持久化与展示，驱动从不执行它**（`src/driver.ts`）：`/loop 5m <obj>` 与状态行都宣称"every 5m"，但驱动会在每轮空闲后立即续排下一轮，等于界面在说谎，且"有节奏"的循环会连发烧完整轮预算。已实现轮次间最小间隔：首轮立即执行，其后各轮等到 `上次排队时刻 + intervalMs`；等待用受 fiber 管理的定时器，暂停/取消/编辑/卸载都会取消它，且过期的唤醒会重新读取循环状态而不会补排（`src/loop.ts` 新增 `MAX_TIMER_DELAY_MS`，同时作为检查点 `intervalMs` 的上界，防止手改检查点造出无法调度的节奏）。
2. **`intervalMs` 在检查点里没有任何测试**：`parseCheckpoint` 的注释明确写着"静默丢弃会把有节奏的循环变成连烧预算的循环"，但该行为无覆盖。已补：往返持久化、无节奏保持无节奏、6 种非法形状（错类型/0/负数/小数/非有限/超定时器上限）被拒、上限本身被接受。
3. **`start` 丢弃用户刚输入的目标**（`src/controller.ts`，经用户授权后修）：对已 pause 的活跃循环执行 `/loop <新目标>` 会静默保留旧目标，用户看到"目标被保留"才知道自己打的字被丢掉了。已改为整条替换（新 id、预算归零）并明确告知。
4. **（自查更正，原非既有缺陷）**：armed 冲突提示原文为 `inspect it with loop_status, stop it with loop_cancel, or let it finish` —— 这三处引用**都真实存在，原文没有缺陷**。本轮为配合新语义补上 `/loop edit` 指引，我在改写时一度写进并不存在的 `loop_edit` 工具，已更正为 `/loop edit`。记录在此以免被误读成"修了一个不存在的 bug"。

### 已排查但证伪（未改动）

- **`commands.register()` 丢弃 disposer 是否会泄漏注册**：`CommandRuntime.register` 内部是 `this.layers.effect(this.ctx, …)`，从实现看像是绑在服务自身的 ctx 上（那样插件卸载就不会撤销注册）。用真实 `@deepseek-ai/dsh-commands` 做对照实验后**证伪**：丢弃 disposer 与显式 `ctx.effect(() => dispose())` 两种写法，在插件 fiber 卸载后注册**都已消失**。故未改动 `installLoopCommand`。教训：不该凭"读了一遍实现"就断定缺陷。
- **`loop_start` 与 `/loop` 是否重复注册**：两者共用同一个 `LoopController` 与 `executeLoopCommand`，不存在两套状态机；真实 Loader 用例与真实 `CommandRuntime` 用例各自断言了注册与卸载的干净性。

### 本轮新增测试

| 文件 | 用例数 | 本轮新增覆盖 |
| --- | --- | --- |
| `test/driver.test.mjs` | 18（+4） | 有节奏时首轮立即、其后被扣住直到间隔到点；无节奏仍立即续跑；卸载取消待唤醒；等待期间暂停后过期唤醒不会补排 |
| `test/checkpoint.test.mjs` | 18（+9） | `intervalMs` 往返、无节奏保持、6 种非法形状被拒、定时器上限被接受 |
| `test/tui.test.mjs` | 6 | `tui.commands` 注册/反注册、无会话提示、错误回显、契约形状校验、`ctx.inject` 门控在服务缺失时不动作 |
| `test/command.test.mjs` | 18（+2） | `/loop` 语法、节奏渲染往返、完整生命周期、paused 循环被整条替换且 `edit` 保留预算、**真实 `CommandRuntime` 契约与卸载释放** |
| `test/loop-detect.test.mjs` | 10 | 规范化、连续链推进、判定、提示渲染 |
| `test/settings.test.mjs` | 24 | 路由校验、真实注册与热更新、嵌套写入不碰兄弟字段、revision 围栏 409 |

## 第三轮（`/loop` 命令、重试配置面板、循环检测）

### 已通过

- `npm run typecheck`：Host 与 Client 双 `tsc --noEmit` 通过。
- `npm test`（完整构建 + `node --test test/*.test.mjs`）：**99 个用例，98 通过，0 失败，1 跳过**（跳过的仍是需 `DSH_COMPOSITION_RUNTIME_MANIFEST` 的真实 Loader 用例）。
- 基线对比：本轮开始时为 47 通过 / 1 跳过（审计轮修复后 50 / 1）；本轮新增 48 个用例。
- 单一插件约束仍然成立：`cordis.patch.yml` 仍只有一条 `insert`，`id: do` / `name: dsh-do`，由 `test/package.test.mjs` 断言。
- 构建产物已同步：`lib/`、`lib/types/`、`lib/client.js` 均由本轮源码重新生成。

### 本轮新增测试

| 文件 | 用例数 | 覆盖 |
| --- | --- | --- |
| `test/command.test.mjs` | 14 | `/loop` 语法（前导/尾部间隔、动词优先级、`every` 消歧）、节奏渲染往返、完整生命周期、已 armed 拒绝、disarmed 重新 arm **保留原目标**、终态替换、缺失状态 |
| `test/loop-detect.test.mjs` | 10 | 深度键排序规范化、连续链推进/重置、判定（阈值/驱动接管/预算耗尽/开关）、提示词渲染与截断 |
| `test/settings.test.mjs` | 24 | 路由请求校验（19 种非法形状）、`readSettingsView` 命名空间收窄、重试草稿读写/校验/构建、路径级 save/reset、目标发现与选择、`isOverridden` 语义、循环草稿往返、**真实 `installDoSettings` 注册 + 热更新**、**真实路由端到端读写 + 嵌套写入不碰兄弟字段 + revision 围栏 409 + 未注册命名空间 + 守卫顺序** |

### 本轮发现并修复的真实缺陷

1. **空 path 被拒**（`src/settings-route.ts`）：面板保存循环配置发送的是命名空间根写入（`path: []`，`applyPathOp` 明确支持），而路由把空 path 判为非法 —— 保存必然失败。已改为允许空 path（仍校验每段是非空字符串）。
2. **恢复提示谎报压缩**（`src/loop-detect.ts`）：`compact: false` 时正文仍告诉模型"历史刚被压缩"。已让续跑句跟随同一开关。
3. 上一轮已修（本轮回归仍覆盖）：`aiInstall` 缺 `signal`、检查点可选字符串静默丢弃、`armed` 与终态自相矛盾。

### 设计决策（需用户确认后才可推翻）

- **`disarmed → 重新 arm` 已被用户明确推翻（本轮改动）**：原设计对已 disarm 的活跃循环再次 `/loop <objective>` 或 `loop_start` 时**保留已存目标**，只是重新 arm。用户答复"都可以"授权推翻。现语义：paused 循环被**整条替换**——新目标、新预算、新节奏，并明确告知"原目标与已用轮次已被替换"。实现上刻意**铸造新 loop id**：已 admit 轮次是从带该 id 的会话事件里数出来的，所以换 id 才真正重置预算；同时它让仍带旧 id 的在途轮次预约失效，旧循环排队的轮次不可能被 admit 进新循环。armed 的循环仍报错，不会被覆盖。`/loop edit <objective>` 保留为"保留已用轮次的中途修正"路径。
- **检测器不中断有驱动接管的会话**：读源码确认官方 `dsh-goal-round-driver`（第 222 行）与本插件 `driver.ts` 都会在**已 admit 的轮次被取消时暂停其机制**。因此检测器在有 armed 循环/目标时只投递纠正提示，不 `cancel`，避免悄悄停掉用户正在跑的循环。

## 第二轮（审计轮）

### 已通过

- `pnpm typecheck`：Host 与 Client 通过。
- `pnpm build`：Host 与 Client bundle 通过；tsdown external/noExternal 存在弃用警告，不影响构建。
- 设置 `DSH_COMPOSITION_RUNTIME_MANIFEST` 指向本机 DSH package.json 后，`node --test test/*.test.mjs`：48/48 通过，0 跳过。
- `git diff --check`：通过。
- 临时 DSH_HOME 安装 tarball：成功；`--dump-config` 为唯一 `id: do / name: dsh-do`。
- 最终临时安装 Host SHA256 与源码 bundle 一致：`BBD0B03734760BBF750905CBC10A52B324FA24762A2088A70C6B9C6F5F0BB7F2`。

### 测试类型

- composition：真实 Cordis、AgentRegistry、SystemPrompt、ToolRuntime，以及安装版 Loader；覆盖依赖等待、四工具注册、重启/卸载、提示与事件清理。Loader 从 patch 提取单行，在内存中改为入口 URL，禁用持久化。不是完整 Web boot。
- driver：实际驱动/controller/Inbox，可控事件；14 项覆盖预算、取消、竞争消息、恢复屏障与卸载。
- ai-install：实际 handler，可控 service 与临时目录；覆盖成功创建、setup 失败回滚、依赖预检、防跨站、方法与 JSON 校验。
- Client：纯状态/请求通道/响应解析测试，不是 DOM 端到端测试。

## 发布及部署边界

正式 Web 安装路径：`C:\Users\Huawei\.dsh\profiles\web\node_modules\dsh-do`。用户明确要求"不用备份旧版"后，已通过 `dsh plugin --profile web add` 安装修复包，并通过 `dsh plugin --profile web install` 恢复一次无关插件依赖树（`ssh2` 缺失）。重启后新错误日志为空，页面返回 200，POST 到 `/dsh-do/ai-install` 使用 `text/plain` 时按预期返回 415。

**注意**：上述部署仍是**审计轮**的产物，不包含本轮（`/loop`、设置面板、循环检测）的代码。本轮改动只完成到源码 + 构建 + 测试，**尚未重新部署到 web profile**，因此浏览器里看不到 dsh-DO 设置页，`/loop` 也还不可用。需要重新打包安装并重启 profile 才能验收。

本轮临时安装目录：`C:\Users\Huawei\AppData\Local\Temp\dsh-do-verify-88ebf6340bc0410abf54435a951aae4e`。
最终测试包：该目录下 `dsh-do-verified-final.tgz`。这是临时验收产物，不应作为长期依赖路径。

同路径同版本 tarball 重装曾显示 Already up to date 却保留旧字节；改用新 tarball 文件名后安装，并用 SHA256 校验才确认更新。之后发布需使用新版本或唯一包路径，不以退出码代替产物身份校验。

临时安装有 peer dependency 提示；真实 Loader 测试复用已安装框架依赖，未证明临时 profile 可独立完整启动。

## 尚未声称完成

- **TUI 内的交互验收**：`--dump-config` 已证明组合成立，但还没有在真实 TTY 里敲过 `/loop`（TUI 需要交互终端，无法在本会话内自动完成）。
- Playwright/真实浏览器的窄屏、焦点、右键交互验收；本轮新增的设置页交互（保存/重置/409 冲突提示）**已确认产物送达浏览器**（见下），但人工点选尚未做。
- 使用实际模型凭证的循环任务、`/loop` 斜杠命令、外部 GitHub 插件安装，以及**模型循环检测的真实触发**（需要真实模型真的陷入重复调用）。
- GitHub 推送或发布。

## 本轮部署（已完成）

第四轮代码已部署到 web profile 并重启验证：

- 打包到新目录 `C:\Users\Huawei\.dsh\local-packages\dsh-do\deploy-cf9d1ed3c6872fc53d84f3e03113737a\dsh-do-0.1.0.tgz`（**新 spec 路径**，避免 pnpm 按"版本号+spec"命中缓存而静默不更新），由 `dsh plugin --profile web add` 写入依赖并保留 `dsh.profile.bundles`（前后均为 16 项，未增未减）。
- 安装副本与打包内产物**逐字节一致**（`lib/index.js` = `C9B45224…`、`lib/client.js` = `2B40EF7A…`）。Host 半至今仍与仓库当前构建同哈希（`C9B45224…`）；Client 半因下述构建非确定性而每次重建都会变，已验证为**功能等价的同源构建**。
- `dsh --profile web --dump-config` 仍输出唯一的 `id: do / name: dsh-do` 行，config 正确。
- 重启后由**新进程**持有 3080 端口（`Get-NetTCPConnection` 确认 OwningProcess 为新 pid），`GET /` 返回 200。
- **端到端确认**：`GET /plugins/dsh-do/client.js` 返回 200 / 57923 字节，且包含 `断连重试策略`、`模型循环检测`、`DoSettingsPage`、`/dsh-do/settings`、`settings.section` 全部新标记 —— 即新客户端产物确实送达浏览器。
- 另一个同名 `node` 进程（路径含 `profiles\web`）经查是 Blender 插件的 `runtime\server.mjs --port 9877`，不是竞争的 DSH 实例。
- web profile 配置备份在 `%TEMP%\dsh-do-web-backup\`（`package.json` 与 `cordis.patch.yml`）。

## 发现（构建工具链，非产品缺陷）：客户端构建非确定性

同源连续三次 `npm run build:client` 产出**三个不同的** `lib/client.js` 哈希（`35097957…` / `4F7FBF19…` / `998A1DCD…`）。

- 逐字节比对定位到差异：打包器为 CSS modules 生成的类名映射**key 顺序不稳定**（一次是 `heading,cancel,card,…`，另一次是 `card,input,actions,heading,…`）。
- 判定为纯重排序：两次构建**字节多重集完全相同**、长度相同（59855）、行数相同（1454），差异行只是"对象最后一项无尾逗号"的语法产物 —— 同一查找表的排列，运行期行为一致。
- 影响：①仓库提交 `lib/` 产物，因此**每次构建都会弄脏工作区**，无法用哈希证明"lib 已同步"（本项目的同步性只能用"构建时间晚于源码时间 + 测试通过"来主张）；②客户端资源的 `?rev=` 缓存戳每次构建都变。
- **未修**：消除它需要在打包器层面固定 CSS module 的发射顺序，超出用户要求的范围，故仅记录不擅改。产物功能不受影响。

## 待用户确认才能动的设计取舍

（无。`disarmed → 重新 arm 保留原目标` 已获用户明确授权推翻，见第四轮"设计决策"。）

第四轮部署包保存在 `C:\Users\Huawei\.dsh\local-packages\dsh-do\deploy-cf9d1ed3c6872fc53d84f3e03113737a\dsh-do-0.1.0.tgz`（上一轮的 `deploy-f71cbce0…` 保留未删）。web profile 以固定本地包依赖，不是 GitHub 依赖。按用户要求未备份旧版；未直接覆盖 node_modules，未启动替代服务器。

TUI profile 的安装前备份保存在 `%TEMP%\dsh-do-tui-backup\`（`package.json` 与 `cordis.patch.yml`），用于必要时还原该 profile。

第二轮 Host SHA256：`BBD0B03734760BBF750905CBC10A52B324FA24762A2088A70C6B9C6F5F0BB7F2`。
第二轮 Client SHA256：`8CC88802094D43A6EAA60E00ABA639A2ABF0E6EB57F60F200C3C5E7AB1A724E4`。

## 第六轮（本轮：DSH 多版本适配）

用户在装有 Docker 的机器上要求"多测几个容器版本，适配 0.1.5-rc.3"。本机在用 DSH 0.1.0-rc.8，而 0.1.5-rc.3 起平台 API 有实质性变更，因此本轮把验证从"单版本组合打印"推进到**四个真实 TTY 组合**。

### 发现并修复的两处不兼容

**1）`agent.session.events` 在 0.1.5-rc.3 被移除（真实崩溃）**

0.1.5-rc.3 之前，会话日志由 `Session` 的 getter 暴露：`get events(): readonly SessionEvent[]`。0.1.5-rc.3 删掉了该 getter，改为 `snapshotEvents(fromSeq?, toSeqExclusive?)`（物化半开区间的冻结快照，无参即整段日志）与 `ownEvents()`（**排除** fork 继承前缀）。dsh-do 两处读旧 getter，于是 `/loop` 直接失败：

```
❯ /loop 验证状态栏循环段
⚠ 命令执行失败: agent.session.events is not iterable
⏸ driver-failed · the loop driver failed: agent.session.events is not iterable
```

两处调用点都要**完整日志**（`admittedRounds` 统计已承认轮次、`openTurn` 从尾部回溯回合边界），所以对应物是 `snapshotEvents()` 而**不是** `ownEvents()`。新增 `src/session-log.ts` 的 `readSessionEvents()` 按能力探测：优先新访问器，缺失则回退旧 getter，两者皆无或形状不认识时返回空日志而非抛错——这两处一个在驱动轮次记账上、一个在工具调用内，抛错的代价远大于数错。回退方向已核实：本机 0.1.0-rc.8 的 `dsh-session` 里没有 `snapshotEvents`/`ownEvents`，只有 `get events()`，因此老版本走的是回退分支。

**2）TUI 状态栏补丁的调用形状变了**

`@huiliyi37/dsh-tianshu-tui` 0.1.2-rc.31 与 1.0.0-rc.2 把 `projectStatusPanel(...)` 的调用从单行 `{ width: snapshot.cols }` 改成跨行展开并多了 `sessionTotals`，旧补丁的锚点找不到（`FAILED call site: anchor not found`，退出码 3）。补丁脚本改为同时支持两种调用形状（都是 `optional`），并把调用点形状列为 `REQUIRED` 标记——形状再变时**明确失败并不写文件**，而不是静默打歪。

**3）`peerDependencies` 未覆盖 0.2.x（被平台主动拒绝装载）**

dsh 0.2.0-rc.2 有版本闸门，按 `peerDependencies` 拒绝不匹配的插件，dsh-do 的 `^0.1.0-rc.6` 覆盖不到 0.2.x：

```
dsh: skipping profile bundle "dsh-do": Error: Plugin dsh-do@0.1.0 is incompatible with
dsh 0.2.0-rc.2: peerDependencies {"@deepseek-ai/dsh-agent":"^0.1.0-rc.6", ...}
```

`^0.1.0-rc.6 || ^0.2.0-rc.1` 是向后兼容的放宽（0.1.x 仍全部命中）。**先验证后放宽**：用放宽后的构建装进 0.2.0-rc.2 profile，`id: do` 被接纳，且在真实 TTY 里 `/loop` 与 `◆ 循环` 段都正常（见下表），才保留该改动。

### 版本矩阵（均为容器内真实 TTY 实跑）

Docker 环境：`test-docker/`，Debian + Node 24 + pnpm + 真实 PTY（`script`），每个组合重建一个独立 profile，`--dump-config` 断言 `id: do` 存在，再进 TUI 敲 `/loop` 与 `/status`。

| dsh | dsh-tui | 组合接纳 `id: do` | `/loop` | `◆ 循环` 段 | 备注 |
| --- | --- | --- | --- | --- | --- |
| 0.1.0-rc.8 | 0.1.1-rc.6 | 是 | `Loop started` | 渲染 | 旧路径回归（旧 getter + 旧单行调用形状） |
| 0.1.5-rc.3 | 0.1.2-rc.31 | 是 | `Loop restarted` | 轮次 + 暂停原因 | **本轮目标版本**；修复后才通 |
| 0.1.7-rc.2 | 0.1.2-rc.31 | 是 | 正常 | 轮次 + 暂停原因 | 启动期另有 `typert-loader … has no create() factory`，来自 TUI 与 DSH 自身错配，与 dsh-do 无关 |
| 0.2.0-rc.2 | 1.0.0-rc.2 | 是（放宽 peer 后） | `Loop restarted` | 轮次 + 暂停原因 | 未放宽前被闸门拒绝 |

**Web 组合（`dsh --profile <p>`，无 TUI）**

| dsh | 客户端产物 | `/dsh-do/settings` 读 | 备注 |
| --- | --- | --- | --- |
| 0.1.0-rc.8 | `GET /plugins/dsh-do/client.js` → 200 | 四段含 `dsh-do` | 本机在用版本；本轮回归确认未受影响 |
| 0.2.0-rc.2 | `GET /plugins/??dsh-do/client.js&rev=…` → 200 / 64227 字节 | 四段含 `do` | 裸路径 404 属平台换形状；写入受平台缺陷阻塞 |

四个组合的启动期错误里**没有一条**来自 dsh-do。0.1.5-rc.3 与 0.2.0-rc.2 上循环还实际推进到「↻ 轮次 1/20」——容器用的是哑元凭证，第 1 轮必然因模型调用失败而暂停，这恰好证明**驱动被唤醒并真的跑了第 1 轮**，且暂停原因 `agent-error · the agent reported an error while the loop was running` 正确显示在状态栏上。

### 复测

- `npm run typecheck`：Host 与 Client 双 `tsc --noEmit` 干净。
- `npm test`（完整构建 + 真实 Loader）：**207 用例 / 207 通过 / 0 失败 / 0 跳过**（上一轮 198，本轮 +9：新增 `test/dsh-020-compat.test.mjs`，钉住 `plainSettings` 的活引用解包与"每次读都重解包"、`isDoSection` 按字段识别、`installDoSettings` 在无 `register` 的服务上不抛错且仍跟随活值、`adaptSettingsAccess` 两代形状、`resolveDoNamespace`、以及 `Config` 的特性探测）。
- 本轮 Host 构建哈希：`lib/index.js` = `569AA7F50C0CC3FD…`（122474 字节；容器 web020 安装副本哈希与之一致）；`lib/types/session-log.js` = `33CD73B39136ECB077AFF6B9E84EF4280087F37C55E2AE6A778B60BD9BF6B728`。
- 上一轮（TUI 多版本）的 Host 构建哈希为 `EF1276525D7A79EF6F98FD2F041A749D8FCE40BC967C93FE7DFA32836303B1EF`。

### 黑窗补丁：已撤销，且上游已自行修好

上一轮为本机 Windows 加的 `windowsHide` 补丁**已撤销**：本机 `node_modules` 里被改的文件逐字节还原为发布 tarball（sha256 `F3A11B8AD2D3E01CA9943E9EC919465D8D4525E60FDD6904DA0D4494FE00C247`），补丁脚本从仓库删除。原因是上游已经修了，且修得比补丁更贴切：0.1.5-rc.3 起 `dsh-subprocess-local` 在 spawn 处带 `windowsHide: platform === "win32"`（只在真的会有控制台时隐藏），0.1.7-rc.2 / 0.2.0-rc.2 类似。

**需要明确告知用户**：本机当前在用的 0.1.0-rc.8 只写 `detached: platform !== "win32"`，**没有** `windowsHide`——所以**在升级到 ≥0.1.5-rc.3 之前，黑窗会回来**。这是上游版本差异，不是本插件能修的层。

### 容器脚手架的坑（非产品缺陷，已记入 `test-docker/README.md`）

- **凭证文件格式跨版本变过**：0.1.5-rc.3 起 dsh 自己写的正是数字 `version: 1`，而 0.1.0-rc.8 要求 `version` 是**字符串**——数字会让 `dsh-credentials-local` 抛 TypeError 并把整个 profile 启动打掉。同时 TUI 0.1.2-rc.x 的首次运行会弹「设置 DeepSeek API Key」引导吞掉所有按键。故 `seed-credentials.sh` 分 `seed` / `clear` 两种模式。
- **`cordis-plugin-hmr` 钉子只对 rc.8 需要**：rc.8 的 `dsh-app-boot` 调 `hmr.registerConfig`，而全新安装解析到的 1.0.19 已删除该 API（本机在用的是 1.0.17）。0.1.5-rc.3 起 `dsh-base` 自己精确依赖 1.0.17，hmr 甚至不在依赖树里，故 `matrix-version.sh` 只在 `0.1.0-rc.8` 时注入该 override。
- PowerShell 里 `docker exec … bash -c '<多语句>'` 会返回空输出或截断（大输出尤其），须改为"写 `.sh` → `docker cp` → 执行 → 落盘 → 再 `docker cp` 出来读"。

### Web 半在 0.2.0-rc.2 上的适配（本轮）

上表四个组合都是 TUI，Web 半从未在 0.2.x 上起过。本轮把 Web 组合补上，并修掉它暴露的真实缺口。

**4）`@deepseek-ai/dsh-settings` 在 0.2.x 被重新设计，dsh-do 的设置段整个不出现**

0.2.0-rc.2 的 `dsh-settings` 导出只剩 `SettingsConflictError, SettingsForms, default, redactSecrets`——`installSettingsSection`、`settingsNamespace`、`deepEqualJson`、`SettingsProvider` 以及 `register(ns, schema, options)` **全部移除**。段不再由插件注册，而是由**插件条目自己的 `Config`** 派生，并以 **profile 条目 id** 为键（`describe()` 的注释原文：*Forms keyed by unique profile entry ids*）。

但仅此还不够：`describe()` 里有

```js
const form = volatileForm(schema)
if (form === undefined) return []
```

而 `volatileForm()` **只保留被标了 `.volatile()` 的字段**（*Select fields whose nearest volatile ancestor makes them editable without remounting*）。dsh-do 的 `Config` 一个标记都没有，于是整段被跳过——实测 `/dsh-do/settings` 只回 `agent-default-model / llm-pi-ai / llm-deepseek` **三个**段，`dsh-do` 缺席（同机 0.1.0-rc.8 上则是四个，含 `dsh-do`）。

**踩到的第二个坑**：`.volatile()` 是较晚的 schemastery 才有的方法。本机在用的 schemastery 是 **3.18.1**（本机 dsh 0.1.0-rc.8 profile 与仓库 devDependency 都是它），**运行时根本没有这个方法**，`typeof b.volatile === 'undefined'`、调用即 `TypeError`；容器 profile 解析到 3.18.4 才有。无条件调用会让插件在用户本机**直接装载失败**。故加了特性探测 `volatile()`，只在方法存在时套用；标记在根节点上一次即可（根 `meta.volatile` 为真时 `volatileForm` 直接返回整份 schema）。

**第三个坑**：`.volatile()` 的**值**不是原值，而是 `Object.freeze({ get, [Symbol.for("cosmokit.volatile.write")] })` 这样的活引用（这也正是"不重挂载即可生效"的实现方式：引用被原地更新）。平台自己的 `plainConfig()` 就是靠 `isVolatile()` 解包。dsh-do 直接读 `config.persist` 会拿到一个恒真的对象。故新增 `plainSettings()`，**每次访问都重新解包、绝不缓存**——缓存会让"活"变回"死"。用 `Symbol.for(...)` 判定，与平台同协议、跨副本安全、零新依赖。

**第四个坑**：0.2.x 的段键是 profile 条目 id（本部署为 `do`），而该 id 属于部署方、插件无从预知。故段一律**按字段形状识别**（含 `defaultMaxRounds` + `loopDetection` + `autoContinue`），`dsh-do` 这个注册名只作 0.1.x 的快路径。Host 侧（`settings-route.ts` 的 `readSettingsView`）与 Client 侧（新增 `resolveDoNamespace`）都如此，设置页不再硬编码 `dsh-do`。

**第五个坑**：`/do-config` 原本以 `typeof service.get === 'function'` 守卫，0.2.x 的 `SettingsForms` 没有 `get`，于是命令会**静默降级**成"当前组合没有挂载 settings 服务"这句误导性提示。新增 `adaptSettingsAccess()`，把两代服务统一成同一个访问面（0.1.x 直用；0.2.x 以 `describe()` 读、`mutate()` 写并顺带解析条目 id）。

**实测结果（容器 profile `web020` = dsh 0.2.0-rc.2 + dsh-web-app 0.2.0-rc.2）**

| 检查项 | 结果 |
| --- | --- |
| profile 接纳 `id: do` | 是（放宽 peer 后），`--dump-config` 1266 行无 skipping/incompatible |
| 启动期错误 | 无 |
| 壳 HTML 里 dsh-do 的客户端模块清单 | `{"id":"dsh-do","url":"plugins/??dsh-do/client.js&rev=…","inject":["@deepseek-ai/dsh-client-runtime","@deepseek-ai/dsh-client-ui-primitives"]}` |
| 客户端产物 | `GET /plugins/??dsh-do/client.js&rev=…` → **200 / 64227 字节**，含 `断连重试策略`、`模型循环检测`、`DoSettingsPage`、`settings.section`、`resolveDoNamespace` |
| `GET /dsh-do/settings` | **200**，段为 `agent-default-model, llm-pi-ai, llm-deepseek, `**`do`**，且 `do` 段带**完整**六个顶层字段（嵌套对象齐全） |
| `POST /dsh-do/settings` | **500 `dsh: profile reload requires the root Include entry`**（平台侧，见下） |

注意 0.2.x 的客户端产物**不再**挂在裸路径上：`GET /plugins/dsh-do/client.js` 返回 404，真实地址是组合 URL `plugins/??dsh-do/client.js&rev=…`（`@deepseek-ai/dsh-client-modules` 的组合模块系统）。**这不是 dsh-do 的缺陷**，是平台换了 URL 形状；0.1.x 上裸路径仍可用。

### 仍未声称完成

- **0.2.0 的设置「保存」走不通，但根因在平台**：`POST /dsh-do/settings` 返回 500 `dsh: profile reload requires the root Include entry`。**对照实验证明与 dsh-do 无关**——写平台自带的 `agent-default-model` 段报**完全相同**的错。该错来自 `@deepseek-ai/dsh-app-boot` 的 `reconcileProfilePatches()`：它要求启动时 `mountRootInclude()` 已把 root Include entry 注册进 `bootstrapIncludes` WeakMap，而 0.2.0-rc.2 上该注册未发生。读路径完全正常（见下），写路径是 0.2.x 从「写 settings.yaml」改成「改 profile patch + 重载 profile」后新引入的，属平台侧问题，dsh-do 只如实透传平台原文并以 500 归类。**待上游修复后需重验保存。**
- ~~**真实模型凭证下的端到端 loop**~~：**已用本地 mock LLM 补上**（见文末「第九轮」）——多轮推进（3 轮，实测间隔 59.948s / 59.998s）与 `loop_done` 收尾、`phase=completed` 均已实测。**仍未验的是「真实模型」下的多轮质量**，不是循环机器本身。
- `dsh plugin allow-version` 的确切用法未查明（静默无输出且闸门未解除），本轮是靠放宽 `peerDependencies` 走通的。
- **Web 半在 0.1.5-rc.3 上仍未起过**：本轮补上了 0.2.0-rc.2 的 Web 组合，0.1.5-rc.3 的 Web 组合仍只有 TUI 证据。

## 第九轮（真实 TUI 多轮循环：用本地 mock LLM 把「一轮轮跑下去」测出来）

**要补的缺口**：容器一贯用哑元凭证，循环第 1 轮就因 `llm-deepseek: no API key` 报错暂停，于是「多轮推进」与「`loop_done` 收尾」始终无法验证。真实凭证会烧额度，而且容器必须联网——联网又会让 TUI 自我升级把 profile 弄坏。

**做法**：把 provider 的 baseURL 指到容器内的 mock，循环就能真跑，且完全不需要外网。

| 环节 | 做法 |
| --- | --- |
| endpoint 覆盖 | `dsh --profile tui --patch /root/mock-patch.yml`，patch 为 `- id: llm-deepseek` + `config.baseURL: http://127.0.0.1:8899`（**不改 profile 本体**） |
| 凭证 | `DEEPSEEK_API_KEY=dummy-mock-key`：`dsh-credentials-local` 的优先级是**继承进程环境（胜出，只读）** > `$DSH_HOME/.credentials.yaml` > `cwd/.env` > `$DSH_HOME/.env` |
| mock | `test-docker/mock-llm.mjs`：DeepSeek 兼容 SSE（`POST /chat/completions`、`stream:true`、末行 `data: [DONE]`；chunk 形如 `{choices:[{delta:{content\|tool_calls},finish_reason}]}`，`finish_reason` 只认 `stop`/`tool_calls`/`length`） |
| 剧本 | 按请求体里最后一个 `Round: N/M` 判定轮次：第 1、2 轮回文本，**第 3 轮调用 `loop_done`** |
| 驱动 | `test-docker/verify-loop-multiround.sh`（TUI 真实 PTY：`/loop 1m <目标>` → 等 150s → `/status`） |

**为什么容器可以保持断网**：mock 跑在容器 localhost，不需要外网——既免掉真实凭证，也避开了 TUI 自我升级。注意 TUI 的最短节奏是 **1 分钟**（`MIN_INTERVAL_MS = 60000`，写 `30s` 会被抬上去），3 轮约 2 分钟。

### 实测结果（容器 `dsh-env` / profile `tui` = dsh 0.1.0-rc.8 + tui 0.1.1-rc.6 + dsh-do `7082BFB3ECF67CF2`）

mock 侧收到 4 个请求（独立计数，与界面互证）：

```
08:07:54.224  round=1  text
08:08:54.172  round=2  text        ← +59.948s
08:09:54.170  round=3  loop_done   ← +59.998s
08:09:54.217  wrapup   wrapup-text ← +47ms
```

会话日志（多帧 zstd 逐帧解码）给出的完整逐轮记录：

```
seq=7   user/message source={kind:"loop", loopId:"loop-c713613e", round:1}
seq=16  assistant/message "mock 第 1 轮：继续推进目标。"
seq=18  turn/end reason={kind:"completed"}
seq=23  user/message source={kind:"loop", loopId:"loop-c713613e", round:2}
seq=29  assistant/message "mock 第 2 轮：继续推进目标。"
seq=31  turn/end reason={kind:"completed"}
seq=36  user/message source={kind:"loop", loopId:"loop-c713613e", round:3}
seq=42  assistant/message tool-call loop_done {summary:"mock 在第 3 轮判定目标达成"}
seq=44  tool/result                      ← loop_done 真的执行了
seq=49  user/message source={plugin:"dsh-do", form:"notice", summary:"loop_done: 多轮循环验证目标"}
seq=55  assistant/message "循环已完成：mock 在第 3 轮调用 loop_done 收尾。"
```

检查点（`loop-c713613e`）：

```json
{ "objective": "多轮循环验证目标", "maxRounds": 20, "intervalMs": 60000,
  "phase": "completed", "armed": false, "roundsStarted": 3,
  "completedSummary": "mock 在第 3 轮判定目标达成" }
```

`/status` 面板：`◆ 循环 · 已结束` / `多轮循环验证目标` / `↻ 轮次 3/20`；状态行 `API ✓`；启动期无错误；pty 以超时收割退出（非崩溃）。

### 由此证实的四件事

1. **TUI 里 `/loop` 端到端可用**：命令入口、状态机、驱动、状态显示、收尾，全链路。
2. **驱动唤醒补丁在生产生效**：斜杠命令不产生任何 agent 生命周期事件，而第 1 轮在命令后 **59ms** 内就入队并发出了请求——只可能是 `LoopChangeNotifier → nudge` 这条路径（此前只有单测证据，见第五轮）。
3. **节奏是被强制执行的**：请求 `1m`，实测两轮间隔 **59.948s / 59.998s**。
4. **`loop_done` 收尾链路完整**：工具执行 → dsh-do 写入 notice → 收尾提示词 → 模型写结束语 → `phase=completed` 且落 `completedSummary`。

### 边界（勿过度声称）

- mock 只证明**循环机器**正确，不证明真实模型下的多轮质量；真实凭证下的端到端仍属未验。
- 本轮只测了 tui profile（0.1.0-rc.8）；0.1.5 / 0.1.7 / 0.2.0 组合未做多轮。
- 测完已把容器恢复原样（凭证文件、全局 CLI 版本、网络）。

## 第十轮（模型自动切换：对照实验证实「先重试、后切换」）

**要验的**：`modelFallback` 在**真实 429** 下是否真的切换模型（此前只有单测；真实限流下的行为未验）。

**做法**：同一个 mock，让**主模型一律回 HTTP 429、其它模型回 200**，两组之间唯一变量就是开关。

| | 做法 |
| --- | --- |
| mock | `test-docker/mock-llm-fallback.mjs`：按请求体里的 `model` 判定——主模型（`deepseek-v4-flash`）回 429，其它模型回 200；200 的回复文本里**自报模型名**，界面直接可读 |
| 429 响应体 | `{"error":{"message":"Rate limit reached for requests","type":"rate_limit_error"}}`。**刻意不含 quota 字样**——provider 的 `httpErrorCode()` 会把 `[error.code, error.type, error.message]` 拼串**先**判 `isQuotaExceededError()`，命中就变成 QUOTA 码，测不到 RATE_LIMIT 路径 |
| 实验组 | `test-docker/mock-fallback-patch.yml`：`modelFallback.enabled: true`、候选 `deepseek-official/deepseek-v4-pro` |
| 对照组 | 同一份 mock，patch 里不写 `modelFallback`（默认 `false`） |
| 驱动 | `test-docker/verify-model-fallback.sh`（两轮真实 PTY） |

**wire 事实（从真实 provider / dsh-llm 读出来的）**：HTTP 429 → 错误码 `RATE_LIMIT`；官方 `dsh-llm-retry` 默认 `maxRetries=5`、初始 500ms 指数退避、`maxDelayMs=10000`、`jitterRatio=0.1`，且 `RATE_LIMIT` **属于可重试码**；dsh-do 的默认触发码是 `RATE_LIMIT / QUOTA / SERVER / TIMEOUT / TRANSPORT / EMPTY_RESPONSE`（`enabled` 默认 `false`、`candidates` 默认空）。

### 实测结果

| | 主模型 429 次数 | 候选模型 200 | 界面 |
| --- | --- | --- | --- |
| 对照组（开关关） | 7 | 0 | `x Rate limit reached for requests`，无回复 |
| 实验组（开关开） | 7 | **1**（`deepseek-v4-pro`） | **「我是 deepseek-v4-pro，由本地 mock 应答。」**，无报错 |

实验组主模型的请求时刻与间隔：

```
08:40:49.906  初始
08:40:50.402  +497ms
08:40:51.508  +1106ms
08:40:53.427  +1919ms
08:40:57.572  +4145ms
08:41:04.855  +7283ms                    ← 第 5 次重试（初始 + maxRetries 5）
08:41:04.871  deepseek-v4-pro → 200      ← 仅隔 16ms
```

退避实测 497/1106/1919/4145/7283ms，与 500/1000/2000/4000/8000 ±10% 抖动吻合；主模型请求数正好是「1 次初始 + 5 次重试」，等于 `DEFAULT_MAX_RETRIES`。（另有 1 次同刻的 429 来自会话标题生成，与切换无关。）

### 由此证实的四件事

1. **顺序正确**：官方重试**先跑完**（5 次退避 ≈ 15.5s）才轮到 dsh-do 切换——不是一遇错就跳模型。
2. **真的换了模型**：mock 侧看到发往 `deepseek-v4-pro` 的请求，界面回复也自报 `deepseek-v4-pro`。
3. **切换是即时的**：重试链放弃后 **16ms** 内就发出了候选模型的请求。
4. **对照组如实失败**：同一份 mock 下关掉开关即请求全败并报错——证明起作用的确实是 fallback，而不是别的什么。

### 边界（勿过度声称）

- 只验了**单候选 + 单一触发码**（`RATE_LIMIT`）。多候选依次降级，以及 `QUOTA` / `SERVER` / `TIMEOUT` / `TRANSPORT` / `EMPTY_RESPONSE` 各码，未逐一分测。
- **「粘性」未单独验**（切换保持到真人消息为止；loop 轮次、插件 notice、自动续写都不重置）——本轮是单轮对话，没有可观察的重置点。
- 日志行 `dsh-do: … switching agent "…" to …` 走 `ctx.logger.info`，TUI 界面不回显、容器里也未见日志文件，故本轮证据取自 **mock 侧请求序列 + 界面回复**。

## 第十一轮（TUI 配置界面重做 + 修掉「所有值都显示 —」的真实回归）

**用户的诉求**：TUI 里的配置界面能不能更好看些、支持鼠标操作。选定路线 =「先美化 dsh-do 自己的 `/do-config`，同时给上游提需求」，**不动 TUI 的 `/config` 面板**。

### 1）界面重做（`/do-config`）

原来是一行一个字段的平铺列表（`defaultMaxRounds = 20    # 说明`），13 行糊成一片。现在：

```
╭─ dsh-DO 设置 ───────────────────────────────────────╮
│ 改 /do-config <路径> <值>      看 /do-config <路径> │
│ 还原 /do-config reset <路径>   文件 /do-config file │
╰─────────────────────────────────────────────────────╯
◆ 循环 · 每轮推进与检查点
   defaultMaxRounds                25
   checkpointDir                   ""
   persist                         true
◆ 自动继续 · 输出被 token 上限截断时接着写
   autoContinue.enabled            true
   autoContinue.maxContinuations   3
   autoContinue.onlyWhileLooping   true
◆ 模型自动切换 · 模型报错时改用候选模型（已关闭）
   modelFallback.enabled           false
   modelFallback.candidates        []
   modelFallback.triggerCodes      RATE_LIMIT, QUOTA, SERVER, TIMEOUT, TRANSPORT, EMPTY_RESPONSE
◆ 循环检测 · 重复调用同一工具时干预
   loopDetection.enabled           true
   loopDetection.repeatThreshold   4
   loopDetection.compact           true
   loopDetection.maxInterventions  2
改完立即生效，无需重启；也可以直接编辑设置文件里的 dsh-do: 段。
```

要点：**四个分组**（循环 / 自动继续 / 模型自动切换 / 循环检测）各带一句用途；盒子是矩形（自检发现过一版 `renderBox` 的头部宽度算成 `inner+1`、与主体 `inner+2` 不齐，已修并加回归测试）；**所有值对齐到同一列**，且**宽字符按两格算**（`displayWidth()` 自己算 CJK/全角/emoji，不能用 `String.length`，否则中文说明会把列推歪）；某组开关关掉时组标题追加 `（已关闭）`。

**配色只用 ANSI 属性（粗体 `1` / 暗色 `2`），绝不用颜色**：插件够不到 TUI 主题，硬编码色号在浅色终端上会糊。且**只在 TUI 路径上开**——harness 的 `commands` 服务（web/headless）渲染纯文本，转义序列会原样显示出来。实测 TUI 里 ANSI 真的透传：抓到的原始流里有 22 个 `ESC[1m`、21 个 `ESC[2m`，剥掉后与纯文本逐字相同。

### 2）真实回归：`/do-config` 在 0.1.x 上所有值都是 `—`

美化做完去真实 TUI 里验收，发现**13 个字段全是 `—`**。先自查：把本轮的 `src/config-command.ts` stash 掉重建，**依旧全 `—`** —— 不是本轮引入的。

**对照实验定性**：同一个容器、同一个 profile、同一份 `settings.yaml`，换回**已发布的 0.1.0** 构建 → 值全部正常（`loopDetection.repeatThreshold = 4`、`modelFallback.triggerCodes = RATE_LIMIT, QUOTA, …`）。所以这是 **`8e658cb`（适配 0.2.0-rc.2 那个提交）引入的回归**。

**逐步缩小**：

| 步骤 | 观察 | 结论 |
| --- | --- | --- |
| 真实 TUI 跑 `/do-config` | 无「没有挂载 settings 服务」那句 | 服务在、`adaptSettingsAccess` 没返回 undefined |
| `/do-config defaultMaxRounds 25` | `settings.yaml` 真的写入 `dsh-do: defaultMaxRounds: 25`，但确认行回读仍是 `—（已保存，立即生效）` | **写正常、读空** |
| 临时探针打印服务形状 | `register=fn get=fn mutate=fn describe=fn`，`get(DSH_DO_NS)={}` | `register` **存在**，guard 通过、注册发生了；但段解析成**空对象** |
| 加 `DSH_DO_NO_VOLATILE=1` 开关关掉 volatile 标记 | `get(DSH_DO_NS)={"defaultMaxRounds":25,"persist":true,"loopDetection":{…},"autoContinue":{…},…}` | **根因锁定** |

**根因**：`Config = volatile(z.object({…}))`（为 0.2.x 能显示该段而加的标记）。容器里 schemastery 是 **3.18.4，`.volatile()` 存在**，于是标记**真的被套用**了；而 0.1.x 的 settings 服务把带该标记的 schema 解析成**活引用对象**（只有 symbol 键，`JSON.stringify` 就是 `{}`），`readPath` 自然什么都找不到 → 全 `—`。

`plainSettings()` 的文档早就写明「**每次访问都必须经它解包，且绝不缓存**」，`/do-config` 却直接用了 `settings.get()` 的原始值 —— **违反了自己模块的契约**。

**修复**：读取统一过 `readSection()`（= `plainSettings(settings.get(DSH_DO_NS))`），列表、`show`、以及 `set`/`reset` 的回读三处全部改走它。**没有动 volatile 标记本身**——0.2.x 靠它才显示该段，动了会砸掉已验的 0.2.x。

**复测**（volatile 标记保持开启，即原失败条件）：真实 TUI 里 `/do-config` 现在显示真值，连 `settings.yaml` 里的用户覆盖 `defaultMaxRounds: 25` 都正确读到。

新增回归测试「a live section reference is unwrapped, so no field renders as unset」：假服务 `get()` 返回一个带 `Symbol.for('cosmokit.volatile.write')` 的活引用，断言列表**不含 `—`** 且含具体默认值、`show` 也解包。**已验证该测试有牙齿**——把 `readSection` 退回原始 `get()` 后它立刻转红（`fail 1`），恢复修复后转绿。

### 3）鼠标操作：TUI 侧目前做不到（已另开上游需求）

查证结论：`@huiliyi37/dsh-tianshu-tui` 的 `lib/index.js` 里明确写着「鼠标事件（SGR mouse protocol）— 暂不处理」，全文件搜 `1000h / 1006h / 1002h / 1003h / 1004h` **一处都没有** —— 终端鼠标模式从未被打开（只有 `?1049h` 备用屏）。所以鼠标点击在 TUI 里**不是配置问题，是能力缺失**。

另外，TUI **内部**是有 overlay 体系的（`OverlayEngine` / `OverlayController` / `OverlayRenderer`，`render(width, height) → string[]`；`/config`、命令面板、keymap、搜索都是 overlay），但**没有对插件开放**：插件唯一的扩展点是 `ctx.provide('tui.commands', registry)`，而命令 `run()` 拿到的是 Cordis `Context`，**够不到 overlay 控制器**。因此「插件注册一个全屏可点面板」这条路当前不存在。

故本轮只美化 `/do-config`（零补丁、零风险），并把「① 开放 overlay 扩展点 ② 支持鼠标」作为需求提给上游，**不擅自改 TUI 的 `/config` 面板**。

### 4）0.2.0-rc.2 上的复验（同一份代码，输出逐字节相同）

初版报告把「0.2.x 的 TUI 组合本轮未跑界面」列为边界。补验后发现**这里根本没有版本差异**——美化是 `renderConfigListing` 的事，与 dsh 代数无关。

真实组合：容器 profile `v020` = dsh **0.2.0-rc.2** + `@huiliyi37/dsh-tianshu-tui` **1.0.0-rc.2**，装**同一份**构建后跑 `/do-config`。从 0.1.x 与 0.2.0 两次抓取里各抽出 22 行列表（盒子 4 行 + 4 个分组头 + 13 个字段行 + 页脚）逐行 diff：

```
6c6
<    defaultMaxRounds                25
---
>    defaultMaxRounds                20
```

**只差一行**，且差的不是渲染：`25` 是 0.1.x 那次测试时我造进 `settings.yaml` 的覆盖值，`20` 是 v020 没有覆盖时的 schema 默认值。盒子、四个分组头、其余 12 个字段行、页脚**逐字节相同**。

**样式（粗体/暗色）也逐字节相同**，这条单独查过，因为差点被一个假象带偏：整份录制里的 `ESC[1m`/`ESC[2m` 计数在三次抓取里是 22/21、10/0、29/27 —— 数字对不上源码期望的 18/18。原因是**全文计数被 TUI 自己的界面样式主导**（状态栏、提示行、补全列表都在用 bold/dim），而且第一次抓取时 API Key 模态还没关掉、列表压根没渲染完（那次的 `dim: 0` 就是这么来的，不是 TUI 吞了样式）。

改用 `test-docker/raw-sgr.mjs` 只看**列表区域**的原始字节后，结论明确：

```
<ESC>[1m◆ 循环<ESC>[0m<ESC>[2m · 每轮推进与检查点<ESC>[0m
   <ESC>[2mdefaultMaxRounds<ESC>[0m                <ESC>[1m20<ESC>[0m
```

组标题 `ESC[1m`（粗体）、组说明 `ESC[2m`（暗色）、路径暗色、值粗体——**四种样式在 0.2.0 上一个不少**。

（顺带解释了抓取里列表被输入框"切开"的现象：TUI 每 commit 一行就重绘一次自己的框，用 `ESC[11A` + `ESC[0J` 就地覆盖。剥 ANSI 时把光标定位一起剥掉了，于是重绘帧被摊平成独立行；真实终端里看到的是连续列表。）

**补验时先踩到的坑（真实用户会踩，已写进 README）**：`v020` 里装的是 peer 范围放宽**之前**的旧 tarball，于是 dsh 的版本闸门把 dsh-do 整个跳过：

```
dsh: skipping profile bundle "dsh-do": Plugin dsh-do@0.1.0 is incompatible with dsh 0.2.0-rc.2:
peerDependencies {"@deepseek-ai/dsh-agent":"^0.1.0-rc.6", …}
```

症状极具误导性：**dsh 自身一切正常，只是 `/do-config` 与 `/loop` 一起消失**；又因为命令没注册，在 TUI 里敲 `/do-config` 会被当成**普通消息发给模型**（抓取里能看到「⠋ 理解」和随后的 API 报错），看起来像"命令坏了"，而不像"插件压根没装载"。重装（`dsh plugin --profile v020 add <新 tarball>`）后 `--dump-config` 里 `skipping profile bundle` 归 0、dsh-do 进组合，`/do-config` 立刻恢复且就是美化版。**插件侧无需改动**（peer 范围早已放宽），这是安装陈旧导致的，故只补文档。

### 复测

- `pnpm build`：Host 与 Client 双目标干净。
- `node --test test/*.test.mjs`：**211 用例 / 187 通过 / 0 失败 / 24 跳过**（本轮 +1 条，即上面的活引用解包回归测试）。
- 真实 TUI（容器 `dsh-env` / profile `tui` = dsh 0.1.0-rc.8 + tui 0.1.1-rc.6）：盒子是矩形、值列唯一、13 个字段全部显示真值。
- 真实 TUI（容器 `dsh-env` / profile `v020` = dsh 0.2.0-rc.2 + tui 1.0.0-rc.2）：同一份构建，列表与 0.1.x **逐字节相同**（含粗体/暗色，见第 4 节）。

**复现脚本**

| 脚本 | 用途 |
| --- | --- |
| `test-docker/capture-do-config.sh [profile]` | 真实 PTY 跑 TUI、敲 `/do-config`，剥 ANSI 出「用户看到的样子」（本轮界面与真值验收就是它）。默认 profile `tui`，可传 `v020` |
| `test-docker/raw-sgr.mjs <raw> [锚点]` | 只看锚点附近的原始字节，判断插件发出的样式有没有被 TUI 吞掉。**全文 SGR 计数不可用**，原因见第 4 节 |
| `test-docker/capture-config-panel.sh` | 同样方式抓 TUI 内置 `/config` 面板，用来证明它**只读**（没有选择、没有键盘导航、不调 `permission.set`），故本轮不动它 |
| `scripts/verify-tui-registration.mjs` | 用**已安装的真实 TUI 包**导出的 `SlashCommandRegistry` 验证 `/do-config` 与 `/loop` 真能注册进去 —— 第三方包不在本仓库依赖里，这一环装不进 `node --test` |

### 边界（勿过度声称）

- 美化已在 **0.1.x 与 0.2.x 两侧真实 TUI** 上验收，且两侧输出逐字节相同（见上）。
- 0.2.x 那侧**只验了展示与命令注册**；`/do-config` 的**写入**（`set`/`reset`）在 0.2.x 上未跑——0.2.x 的写入走 profile patch，平台侧另有已知阻塞（`500 root Include entry`，见第九轮）。
- 鼠标仍不可用（见第 3 节），与版本无关。
- 容器里 0.1.x 探针用的 `settings.yaml`（含 `dsh-do: defaultMaxRounds: 25`）是**测试产物**，已随容器恢复清掉；上面 diff 里那一行差异就是它。



