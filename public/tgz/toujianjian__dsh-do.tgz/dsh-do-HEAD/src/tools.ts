/**
 * Model-facing `loop_start`, `loop_status`, `loop_done`, and `loop_cancel`
 * tools over the persisted same-session loop domain.
 *
 * @module dsh-do/tools
 */
import type { Context } from '@deepseek-ai/cordis'
import type { Agent } from '@deepseek-ai/dsh-agent'
import { createUserMessage, HarnessError } from '@deepseek-ai/dsh-llm'
import type { SessionEvent } from '@deepseek-ai/dsh-session'
import { defineTool, type GenericCallView } from '@deepseek-ai/dsh-tools'
import type { ContentBlock } from '@deepseek-ai/dsh-llm'
import type { LoopController } from './controller.js'
import { effectiveRounds, isLoopSource, type LoopState } from './loop.js'
import { renderLoopWrapupContext } from './prompt.js'
import { readSessionEvents } from './session-log.js'
import { doNoticeSource } from './source.js'

/** Execution-time authority checks for the model-facing loop tools. */

function reject(message: string, code = 'LOOP_TOOL_AUTHORITY_REQUIRED'): never {
	throw new HarnessError(message, code)
}

/** Locate the open turn enclosing a model tool call. */
function openTurn(agent: Agent): { events: readonly SessionEvent[] } {
	const events = readSessionEvents(agent.session)
	for (let index = events.length - 1; index >= 0; index -= 1) {
		const boundary = events[index]
		if (boundary?.type === 'turn/end') {
			reject('loop tools require an open model turn', 'LOOP_TOOL_DRIVER_REQUIRED')
		}
		if (boundary?.type === 'turn/start') return { events: events.slice(index + 1) }
	}
	return reject('loop tools require an open model turn', 'LOOP_TOOL_DRIVER_REQUIRED')
}

/** Authenticated loop tool execution: the exact live calling agent and its current turn window. */
export interface LoopToolExecution {
	readonly agent: Agent
	readonly events: readonly SessionEvent[]
}

function loopToolExecution(ctx: Context, exec: { agent?: Agent }): LoopToolExecution {
	const agent = exec.agent
	if (agent === undefined) return reject('loop tools require a calling agent', 'LOOP_TOOL_AGENT_REQUIRED')
	if (ctx.agents.get(agent.id) !== agent || agent.status !== 'running' || ctx.agents.currentInitiator() !== agent) {
		return reject('loop tools require the exact live calling agent inside its active driver', 'LOOP_TOOL_DRIVER_REQUIRED')
	}
	return { agent, ...openTurn(agent) }
}

/**
 * Whether host-attested human input appears in the current root-agent turn.
 * An omitted source resolves to `user`, so non-human producers must supply
 * their own source rather than inheriting this authority.
 */
function hasDirectHumanInput(ctx: Context, execution: LoopToolExecution): boolean {
	if (!ctx.agents.roots().includes(execution.agent)) return false
	return execution.events.some((event) => event.type === 'user/message' && event.data.source.kind === 'user')
}

/** Require authority originating in a human message accepted by a runtime root. */
function requireDirectHuman(ctx: Context, execution: LoopToolExecution): void {
	if (!hasDirectHumanInput(ctx, execution)) {
		reject('this loop operation requires a direct human turn on a top-level agent')
	}
}

/** Whether this turn is the current loop's exact admitted round. */
function isMatchingLoopRound(execution: LoopToolExecution, loop: LoopState): boolean {
	const rounds = effectiveRounds(execution.agent, loop)
	return execution.events.some(
		(event) =>
			event.type === 'user/message' &&
			isLoopSource(event.data.source) &&
			event.data.source.loopId === loop.id &&
			event.data.source.round === rounds,
	)
}

/** Resolve completion authority from either direct human input or the exact loop round. */
function completionAuthority(ctx: Context, execution: LoopToolExecution, loop: LoopState): { kind: 'direct-human' } | { kind: 'loop-round' } {
	if (hasDirectHumanInput(ctx, execution)) return { kind: 'direct-human' }
	if (isMatchingLoopRound(execution, loop)) return { kind: 'loop-round' }
	return reject('loop_done and loop_cancel require a direct human turn or the current loop round')
}

/** Compact canonical view of one loop, matching the output schema. */
/** Every recorded stop cause, as the output schema advertises them. */
const PAUSE_REASON_CODES = ['round-cancelled', 'round-aborted', 'max-tokens', 'agent-error', 'driver-failed', 'restart']

export interface LoopView {
	loop: {
		id: string
		objective: string
		phase: LoopState['phase']
		armed: boolean
		/**
		 * Why an active-but-disarmed loop stopped. The model needs this: without it
		 * `armed: false` alone does not say whether to wait, retry, or ask.
		 */
		pausedReason?: { code: string; message: string; at: number }
		roundsStarted: number
		maxRounds: number
		blockedReason?: { code: string; message: string }
		completedSummary?: string
		cancelledReason?: string
		startedAt: number
		updatedAt: number
	} | null
}

/** Stable compact model result; `armed` is an observation, not replay state. */
function loopValue(agent: Agent, loop: LoopState | undefined): LoopView {	if (loop === undefined) return { loop: null }
	return {
		loop: {
			id: loop.id,
			objective: loop.objective,
			phase: loop.phase,
			armed: loop.armed,
			...(loop.pausedReason === undefined || loop.phase !== 'active' || loop.armed
				? {}
				: { pausedReason: { code: loop.pausedReason.code, message: loop.pausedReason.message, at: loop.pausedReason.at } }),
			roundsStarted: effectiveRounds(agent, loop),
			maxRounds: loop.maxRounds,
			...(loop.blockedReason === undefined
				? {}
				: { blockedReason: { code: loop.blockedReason.code, message: loop.blockedReason.message } }),
			...(loop.completedSummary === undefined ? {} : { completedSummary: loop.completedSummary }),
			...(loop.cancelledReason === undefined ? {} : { cancelledReason: loop.cancelledReason }),
			startedAt: loop.startedAt,
			updatedAt: loop.updatedAt,
		},
	}
}

/** Reusable canonical output declaration for all four loop controls. */
const LOOP_OUTPUT = {
	schema: {
		type: 'object',
		additionalProperties: false,
		properties: {
			loop: {
				required: true,
				oneOf: [
					{ type: 'null' },
					{
						type: 'object',
						additionalProperties: false,
						properties: {
							id: { type: 'string', required: true },
							objective: { type: 'string', required: true },
							phase: { type: 'string', required: true, enum: ['active', 'completed', 'blocked', 'cancelled'] },
							armed: { type: 'boolean', required: true },
							pausedReason: {
								type: 'object',
								additionalProperties: false,
								properties: {
									code: { type: 'string', required: true, enum: PAUSE_REASON_CODES },
									message: { type: 'string', required: true },
									at: { type: 'number', required: true },
								},
							},
							roundsStarted: { type: 'integer', required: true },
							maxRounds: { type: 'integer', required: true },
							blockedReason: {
								type: 'object',
								additionalProperties: false,
								properties: {
									code: { type: 'string', required: true },
									message: { type: 'string', required: true },
								},
							},
							completedSummary: { type: 'string' },
							cancelledReason: { type: 'string' },
							startedAt: { type: 'number', required: true },
							updatedAt: { type: 'number', required: true },
						},
					},
				],
			},
		},
	} as const,
	render: (_args: unknown, value: unknown): ContentBlock[] => [{ type: 'text', text: JSON.stringify(value) }],
}

/** Generic, args-only pending presentation shared by the loop tools. */
function present(title: string, kind: 'read' | 'other', rawInput?: unknown): GenericCallView {
	return { card: 'generic', title, kind, ...(rawInput === undefined ? {} : { rawInput }) }
}

const START_DESCRIPTION =
	'Start one Claude Code-style autonomous loop for the current session: the driver then auto-continues across turns, re-queueing the objective as <loop_round> prompts until the model calls loop_done, the round budget is exhausted, or the loop is cancelled. Use when a direct human request is a long-running objective that should keep iterating in this same session. If an active loop exists but is disarmed (e.g. after a cancelled round), it is replaced by this objective with a fresh round budget. An armed loop is never clobbered: inspect it with loop_status, stop it with loop_cancel, or let it finish. Execution rejects non-human and subagent authority.'

const STATUS_DESCRIPTION =
	'Read the current loop for this session, including its exact id, objective, phase, rounds started, round budget, blocked reason when present, and whether it is armed to continue. Call this before loop_done or loop_cancel.'

const DONE_DESCRIPTION =
	'Mark the current loop complete with an optional short summary. Allowed only from a direct human turn or the current loop round; otherwise rejected. When called from a loop round, the driver ends the autonomous run and asks the model to write the closing message.'

const CANCEL_DESCRIPTION =
	'Mark the current loop cancelled with an optional concrete reason. Allowed only from a direct human turn or the current loop round; otherwise rejected. When called from a loop round, the driver ends the autonomous run and asks the model to write the closing message.'

/** Register the four loop tools. */
export function registerLoopTools(ctx: Context, controller: LoopController, config: { defaultMaxRounds: () => number }): void {
	ctx.tools.register(
		defineTool({
			name: 'loop_start',
			description: START_DESCRIPTION,
			parameters: {
				objective: {
					type: 'string',
					required: true,
					description: 'The concrete completion objective to keep iterating toward across turns.',
				},
				max_rounds: {
					type: 'number',
					description: 'Optional positive safe-integer cap on automatic continuation rounds (defaults to the configured defaultMaxRounds).',
				},
			},
			output: LOOP_OUTPUT,
			execute(args, exec) {
				const execution = loopToolExecution(ctx, exec)
				requireDirectHuman(ctx, execution)
				const maxRounds = args.max_rounds === undefined ? config.defaultMaxRounds() : args.max_rounds
				if (!Number.isSafeInteger(maxRounds) || maxRounds < 1) {
					throw new HarnessError('max_rounds must be a positive safe integer', 'LOOP_TOOL_INVALID_ROUNDS')
				}
				const loop = controller.start(execution.agent.session.id, args.objective, maxRounds)
				return Promise.resolve(loopValue(execution.agent, loop))
			},
			presentCall: (args) => present('Start loop', 'other', args.objective),
		}),
	)
	ctx.tools.register(
		defineTool({
			name: 'loop_status',
			description: STATUS_DESCRIPTION,
			parameters: {},
			output: LOOP_OUTPUT,
			execute(_args, exec) {
				const execution = loopToolExecution(ctx, exec)
				return Promise.resolve(loopValue(execution.agent, controller.get(execution.agent.session.id)))
			},
			presentCall: () => present('Read loop status', 'read'),
		}),
	)
	ctx.tools.register(
		defineTool({
			name: 'loop_done',
			description: DONE_DESCRIPTION,
			parameters: {
				summary: {
					type: 'string',
					description: 'Optional one-line summary of what was achieved.',
				},
			},
			output: LOOP_OUTPUT,
			execute(args, exec) {
				const execution = loopToolExecution(ctx, exec)
				const agent = execution.agent
				const loop = controller.get(agent.session.id)
				if (loop === undefined || loop.phase !== 'active') {
					return Promise.reject(new HarnessError('loop_done requires an active loop for this session', 'LOOP_NOT_ACTIVE'))
				}
				completionAuthority(ctx, execution, loop)
				if (isMatchingLoopRound(execution, loop)) {
					exec.deferContext(
						createUserMessage({
							content: renderLoopWrapupContext(loop.objective, {
								kind: 'completed',
								...(args.summary === undefined ? {} : { summary: args.summary }),
							}),
							source: doNoticeSource(`loop_done: ${loop.objective}`),
						}),
					)
				}
				return Promise.resolve(loopValue(agent, controller.complete(agent.session.id, args.summary)))
			},
			presentCall: (args) => present('Complete loop', 'other', args.summary),
		}),
	)
	ctx.tools.register(
		defineTool({
			name: 'loop_cancel',
			description: CANCEL_DESCRIPTION,
			parameters: {
				reason: {
					type: 'string',
					description: 'Optional concrete reason the loop cannot continue.',
				},
			},
			output: LOOP_OUTPUT,
			execute(args, exec) {
				const execution = loopToolExecution(ctx, exec)
				const agent = execution.agent
				const loop = controller.get(agent.session.id)
				if (loop === undefined || loop.phase !== 'active') {
					return Promise.reject(new HarnessError('loop_cancel requires an active loop for this session', 'LOOP_NOT_ACTIVE'))
				}
				completionAuthority(ctx, execution, loop)
				if (isMatchingLoopRound(execution, loop)) {
					exec.deferContext(
						createUserMessage({
							content: renderLoopWrapupContext(loop.objective, {
								kind: 'cancelled',
								...(args.reason === undefined ? {} : { reason: args.reason }),
							}),
							source: doNoticeSource(`loop_cancel: ${loop.objective}`),
						}),
					)
				}
				return Promise.resolve(loopValue(agent, controller.cancel(agent.session.id, args.reason)))
			},
			presentCall: (args) => present('Cancel loop', 'other', args.reason),
		}),
	)
}
