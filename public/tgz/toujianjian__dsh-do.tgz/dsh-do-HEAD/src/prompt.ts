/**
 * Model-visible prompt renderers for loop rounds and closing wrapups.
 * Pure functions: identical inputs produce identical blocks.
 *
 * @module dsh-do/prompt
 */
import type { ContentBlock } from '@deepseek-ai/dsh-llm'

/**
 * Render the complete round instruction retained in session history.
 * @param objective - the loop's concrete completion objective.
 * @param round - the next positive round number.
 * @param maxRounds - the loop's round budget.
 * @returns a fresh one-block prompt for `Agent.followup()`.
 */
export function renderLoopRoundPrompt(objective: string, round: number, maxRounds: number): ContentBlock[] {
	return [
		{
			type: 'text',
			text: `<loop_round>
Objective: ${JSON.stringify(objective)}
Round: ${round}/${maxRounds}

Continue working toward the objective in this same session. Treat the current workspace, tool results, and durable session state as authoritative; inspect them instead of assuming earlier narration is still current. Make concrete progress and verify the result. If the objective is achieved, call loop_done with a short summary. If you are genuinely blocked, call loop_cancel with the concrete reason. Otherwise leave the loop active for the next round.
</loop_round>`,
		},
	]
}

/** One autonomous ending that concludes a loop. */
export type LoopEnding = { kind: 'completed'; summary?: string } | { kind: 'cancelled'; reason?: string }

/**
 * Render the notice written into the conversation when the driver stops
 * continuing an active loop.
 *
 * A stopped loop used to be indistinguishable from a working one: the round
 * simply stopped arriving and nothing said why. This notice closes that gap by
 * reporting the cause where the rounds were visible, and restating how to
 * resume, so the human does not have to inspect a checkpoint file to find out.
 * @param reason - the recorded stop cause.
 * @param loopId - the stopped loop's identity, echoed for `/loop` follow-ups.
 * @returns a fresh one-block notice for `Agent.followup()`.
 */
export function renderLoopPauseNotice(reason: { readonly code: string; readonly message: string }, loopId?: string): ContentBlock[] {
	const identity = loopId === undefined ? '' : `\nLoop: ${loopId}`
	return [
		{
			type: 'text',
			text: `<loop_paused>
The autonomous loop has stopped continuing and will not queue another round on its own.
Cause (${reason.code}): ${reason.message}${identity}

This is a pause, not an ending: the objective and the rounds already spent are preserved. The human can resume it with \`/loop resume\`, or replace it with \`/loop <new objective>\`; the model can resume it with loop_start. Rounds already completed remain in this session. Do not silently retry the stopped round.
</loop_paused>`,
		},
	]
}

/**
 * Render the closing-message instruction injected after an autonomous loop
 * round reports `loop_done` or `loop_cancel`, so the model still addresses
 * the user once before the turn ends.
 * @param objective - the terminal loop's objective, echoed for grounding.
 * @param ending - the validated terminal report.
 * @returns a fresh one-block context for `ToolRunContext.deferContext()`.
 */
export function renderLoopWrapupContext(objective: string, ending: LoopEnding): ContentBlock[] {
	const heading = `Objective: ${JSON.stringify(objective)}\n`
	if (ending.kind === 'completed') {
		const detail = ending.summary === undefined ? '' : `Summary: ${JSON.stringify(ending.summary)}\n`
		return [
			{
				type: 'text',
				text: `<loop_complete>
${heading}${detail}The loop is complete and this autonomous run is ending. Write the closing message to the user now: state the outcome, summarize what was done and how it was verified, and point to the concrete results (files, commits, or other artifacts). Report only what earlier rounds and tool results in this session actually establish; when a detail is not in the session, say so instead of inventing it. Note anything the user should review or do next. Address the user directly. Do not call any more tools in this run; further work waits for the user's next instruction.
</loop_complete>`,
			},
		]
	}
	const detail = ending.reason === undefined ? '' : `Reason: ${JSON.stringify(ending.reason)}\n`
	return [
		{
			type: 'text',
			text: `<loop_cancelled>
${heading}${detail}The loop is cancelled and this autonomous run is ending. Write the closing message to the user now: state what has been completed so far, describe the concrete blocking condition and what you tried, and say exactly what you need from the user to continue. Report only what earlier rounds and tool results in this session actually establish; when a detail is not in the session, say so instead of inventing it. Address the user directly. Do not call any more tools in this run; further work waits for the user's next instruction.
</loop_cancelled>`,
		},
	]
}
