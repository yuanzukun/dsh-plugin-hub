import { readFile, writeFile } from 'node:fs/promises'

const files = ['src/generated/remote.js', 'src/generated/typert.host.js']
const markerEnd = 'const _mindspace_dsh_session_memory_sessionMemory_compactionPolicy$schema ='
const schemas = String.raw`const _sessionMemoryPerson$schema = z.object({
  'id': z.string().readonly(), 'name': z.string().readonly(), 'information': z.string().readonly(),
  'preference': z.string().readonly(), 'relationship': z.string().readonly(),
  'source': z.union([z.literal("user"), z.literal("extracted")]).readonly(),
  'evidenceSeqs': z.array(z.number()).readonly(), 'updatedAt': z.number().readonly(),
}).readonly()
const _sessionMemoryItem$schema = z.object({
  'id': z.string().readonly(), 'category': z.string().readonly(), 'text': z.string().readonly(),
  'source': z.union([z.literal("user"), z.literal("extracted")]).readonly(), 'evidenceSeqs': z.array(z.number()).readonly(),
}).readonly()
const _sessionModeMemory$schema = z.object({
  'people': z.array(_sessionMemoryPerson$schema).readonly(), 'assistantSetting': z.string().readonly(),
  'assistantState': z.string().readonly(), 'assistantRequirements': z.array(_sessionMemoryItem$schema).readonly(),
  'memories': z.array(_sessionMemoryItem$schema).readonly(),
}).readonly()
const _pendingWrite$schema = z.object({
  'id': z.string().readonly(), 'fromMode': z.union([z.literal("chat"), z.literal("work")]).readonly(),
  'targetMode': z.union([z.literal("chat"), z.literal("work")]).readonly(), 'instruction': z.string().readonly(),
  'suggestedAction': z.union([z.literal("set_assistant_setting"), z.literal("set_assistant_state"), z.literal("add_person"), z.literal("update_person"), z.literal("remove_person"), z.literal("upsert_item"), z.literal("remove_item")]).readonly(),
  'suggestedSection': z.union([z.literal("assistantRequirements"), z.literal("memories"), z.undefined()]).readonly(),
  'sourceSeqs': z.array(z.number()).readonly(), 'createdAt': z.number().readonly(),
}).readonly()
const _bridge$schema = z.object({ 'transitionNote': z.string().readonly(), 'pendingWrites': z.array(_pendingWrite$schema).readonly() }).readonly()
const _sessionMemoryDocument$schema = z.object({
  'version': z.literal(5).readonly(), 'revision': z.number().readonly(),
  'activeMode': z.union([z.literal("chat"), z.literal("work")]).readonly(),
  'modeSource': z.union([z.literal("user"), z.literal("model"), z.literal("migration")]).readonly(),
  'modeReason': z.string().readonly(), 'chat': _sessionModeMemory$schema, 'work': _sessionModeMemory$schema,
  'bridge': _bridge$schema, 'updatedAt': z.number().readonly(),
}).readonly()
const _sessionMemoryActivity$schema = z.object({
  'id': z.string().readonly(), 'sourceSeqs': z.array(z.number()).readonly(),
  'operation': z.union([z.literal("append"), z.literal("merge"), z.literal("replace"), z.literal("skip"), z.literal("switch"), z.literal("stage"), z.literal("consume")]).readonly(),
  'section': z.union([z.literal("people"), z.literal("assistantSetting"), z.literal("assistantState"), z.literal("assistantRequirements"), z.literal("memories"), z.literal("bridge")]).readonly(),
  'mode': z.union([z.literal(null), z.literal("chat"), z.literal("work")]).readonly(),
  'before': z.union([z.literal(null), z.string()]).readonly(), 'after': z.union([z.literal(null), z.string()]).readonly(),
  'reason': z.string().readonly(), 'at': z.number().readonly(),
}).readonly()
const _deepseek_ai_dsh_session_memory_governance_sessionMemory_get_result$schema = z.object({
  'document': _sessionMemoryDocument$schema, 'memoryActivity': z.array(_sessionMemoryActivity$schema).readonly(),
})
const _deepseek_ai_dsh_session_memory_governance_sessionMemory_replace_parameter_0$schema = z.intersection(z.string(), z.unknown())
const _deepseek_ai_dsh_session_memory_governance_sessionMemory_replace_parameter_1$schema = z.object({
  'expectedRevision': z.number().readonly(), 'activeMode': z.union([z.literal("chat"), z.literal("work")]).readonly(),
  'modeSource': z.union([z.literal("user"), z.literal("model"), z.literal("migration")]).readonly(), 'modeReason': z.string().readonly(),
  'chat': _sessionModeMemory$schema, 'work': _sessionModeMemory$schema, 'bridge': _bridge$schema,
})
const _deepseek_ai_dsh_session_memory_governance_sessionMemory_replace_result$schema = z.union([z.object({
  'ok': z.literal(true).readonly(), 'value': z.object({ 'document': _sessionMemoryDocument$schema, 'memoryActivity': z.array(_sessionMemoryActivity$schema).readonly() }).readonly(),
}), z.object({
  'ok': z.literal(false).readonly(), 'error': z.object({
    'code': z.union([z.literal("stale-revision"), z.literal("invalid-document"), z.literal("text-too-large")]).readonly(), 'message': z.string().readonly(),
  }).readonly(),
})])
const _mindspace_dsh_session_memory_sessionMemory_compactionStatus$schema = z.object({
  'providerAvailable': z.boolean().readonly(), 'provider': z.string().readonly(), 'model': z.string().readonly(),
  'contextWindow': z.union([z.literal(null), z.number()]).readonly(), 'estimatedTokens': z.number().readonly(),
  'thresholdTokens': z.union([z.literal(null), z.number()]).readonly(),
  'effectiveRetainTokens': z.union([z.literal(null), z.number()]).readonly(),
  'utilizationRatio': z.union([z.literal(null), z.number()]).readonly(),
  'state': z.union([z.literal("disabled"), z.literal("unavailable"), z.literal("waiting"), z.literal("due")]).readonly(),
  'lastCompaction': z.union([z.literal(null), z.object({
    'kind': z.union([z.literal("automatic"), z.literal("manual")]).readonly(),
    'status': z.union([z.literal("completed"), z.literal("failed"), z.literal("running")]).readonly(),
    'at': z.number().readonly(), 'error': z.string().readonly(),
  }).readonly()]).readonly(),
}).readonly()

`

for (const file of files) {
  const source = await readFile(new URL(`../${file}`, import.meta.url), 'utf8')
  const start = source.indexOf('const _sessionMemoryPerson$schema =')
  const end = source.indexOf(markerEnd)
  if (start < 0 || end <= start) throw new Error(`Cannot locate generated schema block in ${file}`)
  let next = source.slice(0, start) + schemas + source.slice(end)
  if (file.endsWith('typert.host.js')) {
    const modelStart = next.indexOf('\n  model: {')
    if (modelStart >= 0) next = `${next.slice(0, modelStart)}\n}\n`
  }
  // DSH 0.2 materializes strict codecs through factories. Keep the schema
  // member too, so the same descriptors still work on the supported 0.1 line.
  // Normalize existing pairs as well, making repeated builds idempotent.
  next = next.replace(/\bschema:\s*([A-Za-z0-9_$]+\$schema)(?:, create: \(\) => \1)?\b/g,
    (_match, symbol) => `schema: ${symbol}, create: () => ${symbol}`)
  await writeFile(new URL(`../${file}`, import.meta.url), next)
}
