# opencode-usage

English | [中文](README.zh.md)

OpenCode Go quota badge plugin (bundle) — shows rolling / weekly / monthly quota usage and reset times for OpenCode Go right in the dsh Web UI.

## Screenshot

![OpenCode Go quota badge in the composer dock](docs/screenshot.png)

![OpenCode Go quota badge in the composer dock](docs/screenshot.en.png)

## Features

- Renders the three quota windows (rolling / weekly / monthly) as colored percentages (green → amber → red by usage) with reset countdowns in the composer dock
- Shows the last fetch time ("updated M/D HH:mm"), switching to "updating…" while a refresh is in flight
- Click the "OpenCode Go" label to refresh the quota manually
- Auto-refreshes every 5 minutes
- The API key lives only inside the harness process: resolved per request through the credentials service, passed to curl via an environment variable, never serialized to the browser or logs

## Install

This package follows the official [dsh bundle](https://github.com/deepseek-ai/deepseek-harness) format: it ships prebuilt artifacts (`lib/` is committed to the repo) and has no install scripts, so a git install needs **no** pnpm `allowBuilds` grant.

```sh
dsh plugin --profile web add github:AmaTsumeAkira/opencode-usage
```

Or install from a local directory:

```sh
dsh plugin --profile web add ./opencode-usage
```

Uninstall:

```sh
dsh plugin --profile web remove opencode-usage
```

## Credentials

The plugin reads `OPENCODE_GO_API_KEY` through the official credentials service (either the environment or `~/.dsh/.credentials.yaml`):

```yaml
# ~/.dsh/.credentials.yaml
OPENCODE_GO_API_KEY: your-opencode-go-api-key
```

Without a configured key the badge shows "获取失败" (fetch failed).

## Layout

```
opencode-usage/
├── package.json       # dsh.bundle + dsh.client(web) manifest
├── cordis.patch.yml   # plugin row insertion layer
├── lib/index.js       # host half: /opencode-usage route (ESM, zero deps)
└── lib/client.js      # browser half: composer-dock badge (__ModuleLoader__ format)
```

## License

MIT
