# opencode-usage

[English](README.md) | 中文

OpenCode Go 订阅额度徽章插件（bundle）——在 dsh Web 界面显示 OpenCode Go 滚动 / 周 / 月三个窗口的额度用量与重置时间。

## 截图

![对话输入区中的 OpenCode Go 额度徽章](docs/screenshot.png)

![对话输入区中的 OpenCode Go 额度徽章](docs/screenshot.en.png)

## 功能

- 在对话输入区（composer dock）显示三个窗口的用量百分比（颜色随用量变化：绿 → 黄 → 红）与重置倒计时
- 显示最近一次数据获取时间（「更新 M/D HH:mm」），刷新期间显示「更新中…」
- 点击「OpenCode Go」文字可手动刷新额度
- 每 5 分钟自动刷新一次
- API 密钥只存在于 harness 进程内：通过凭据服务逐请求解析，经 curl 环境变量传递，绝不序列化到浏览器或日志

## 安装

本包是官方 [dsh bundle](https://github.com/deepseek-ai/deepseek-harness) 格式：发布即预构建产物（`lib/` 随仓库分发），无任何 install 脚本，因此 git 安装**不需要** pnpm 的 `allowBuilds` 授权。

```sh
dsh plugin --profile web add github:AmaTsumeAkira/opencode-usage
```

或从本地目录安装：

```sh
dsh plugin --profile web add ./opencode-usage
```

卸载：

```sh
dsh plugin --profile web remove opencode-usage
```

## 配置凭据

插件通过官方凭据服务读取 `OPENCODE_GO_API_KEY`（环境变量或 `~/.dsh/.credentials.yaml` 均可）：

```yaml
# ~/.dsh/.credentials.yaml
OPENCODE_GO_API_KEY: your-opencode-go-api-key
```

未配置凭据时，徽章显示「获取失败」。

## 结构

```
opencode-usage/
├── package.json       # dsh.bundle + dsh.client(web) manifest
├── cordis.patch.yml   # 插件行插入层
├── lib/index.js       # host 半部：/opencode-usage 路由（ESM，零依赖）
└── lib/client.js      # 浏览器半部：composer dock 徽章（__ModuleLoader__ 格式）
```

## 许可

MIT
