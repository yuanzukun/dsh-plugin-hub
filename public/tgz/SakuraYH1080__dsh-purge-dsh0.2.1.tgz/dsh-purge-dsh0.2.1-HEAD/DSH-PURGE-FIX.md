# dsh-purge 修复说明（DSH 0.2.1-rc.2 / cwd 提示词变量）

日期：2026-10-21
状态：**已修复并落到本机 desktop profile，插件保持未启用**，由用户自行启用检测。

## 问题表现

DSH 升级到 **0.2.1-rc.2** 后启用 dsh-purge（1.1.71），新对话全部起不来，报错形如：

```
unknown prompt variable "{{cwd}}" in section "deployment:persona-suffix";
registered variables: provider, model
```

## 根因

- 0.2.1-rc.2 的 `dsh-agent-loop` 只注册 `provider`、`model` 两个提示词变量
  （`D:\dsh\resources\app.asar\dsh\node_modules\@deepseek-ai\dsh-agent-loop\lib\index.js` 第 1607–1608 行）。
- 0.2.0 时代存在的 `cwd` 变量已删除，工作目录改由 `working-directory` 运行时上下文下发
  （`@deepseek-ai/dsh-system-prompt` 的 `renderPrompt` 对仍参与插值的段逐个解析 `{{...}}`，
  未知变量直接 throw）。
- 旧 bundle patch 把 `personaSuffix` 写死成 `Your working directory is {{cwd}}.`，
  于是每一轮 `renderPrompt` 都抛异常 —— 这就是“cwd 方面的问题”。

## 本次修改（`fixed/dsh-purge-1.1.73`）

1. `cordis.patch.yml`：删除写死的 `personaSuffix: ... {{cwd}} ...`（过期代码）。
   工作目录由宿主上下文下发；身份尾句改由 `lib/identity.js` 运行时补 `CWD_ONLY_SUFFIX`。
2. `lib/identity.js`
   - `DSH_INTERPOLATE_ALLOWED` 去掉 0.2.0 时代的 `cwd`（只保留 `model`、`provider`）；
   - 新增 `fillCwdPlaceholders()`；
   - `escapeDshInterpolation()` 先把 `{{cwd}}` 落成普通文本；
   - `rewritePromptAssembly()` 末尾加一道“cwd 闸”：仍在插值的宿主段如残留 `{{cwd}}`，
     统一替换为 `provided in the runtime context`，保证任何旧配置都不会再炸；
   - 保留对旧配置文本的识别（`isCwdOnlyText` 等），避免旧值漏过去。
3. `lib/index.js`：`dsh-purge:post` 段的 `postPrompt` 走 `fillCwdPlaceholders()`，
   用户自己写过的 postPrompt 里残留 `{{cwd}}` 也不会再触发 renderPrompt 异常。
4. `lib/desktop.js`：保留前次修复 —— 中文用户名路径（`C:\Users\雫\...`）下
   `.cmd` 启动器会按 ANSI 代码页读参数导致“应用后不重启”；改为纯 ASCII 启动器 +
   环境变量传命令行。
5. 清理过期文件：`.backup-cwdfix-212947/`（旧版 core/identity/patch 备份）、
   `%SystemDrive%/`（误拷的 Windows 缓存）、`.github/`、`.gitignore`、`.npmignore`。
6. `package.json`：`dshTarget` 由 `0.2.0-rc.2` 改为 `0.2.1-rc.2`。

## 落位与备份

- 已替换：`C:\Users\雫\.dsh\profiles\desktop\node_modules\dsh-purge`
  （版本 `1.1.73+dsh0.2.1`，106 个文件，与修复树逐文件一致）。
- 原 1.1.71 备份：`D:\dsh插件\backup\deploy3-2026-10-21T12-57-59\dsh-purge-old`
- **未启用**：profile 的 `dsh.profile.bundles` 里没有 `dsh-purge`。

## 启用方式（由用户执行）

- 在插件管理里打开 dsh-purge；或向
  `C:\Users\雫\.dsh\profiles\desktop\package.json` 的 `dsh.profile.bundles`
  加入 `"dsh-purge"`，重启 DSH / 让插件管理器热挂载。

## 静态验证（未启用插件）

- 修复树与安装副本各 106 个文件、3,527,747 字节，逐一 SHA-256 一致；
- 全部 `.js/.mjs` `node --check` 通过；
- bundle patch 可被 YAML 正常解析（`!!js` 自定义 tag），`system-prompt` 配置已无 `personaSuffix`；
- 针对 0.2.1-rc.2 真实 `@deepseek-ai/dsh-system-prompt` 源码：
  - #66（renderPrompt/interpolate guard）3 个锚点全部命中；
  - #40（complete section / requiredContexts）0.2.1 正则锚点命中；
- 用旧 `personaSuffix: Your working directory is {{cwd}}.` 模拟装配：
  输出段中已无 `{{cwd}}` 泄漏，`working-directory` 运行时上下文保留。

## 注意：依赖 spec 仍是 git 1.1.71

profile 的 `dependencies.dsh-purge` 仍为
`git+https://github.com/SakuraYH1080/dsh-purge.git`（lock 里是 1.1.71）。
如果之后在插件管理器里“更新/重装” dsh-purge，或对 profile 跑 `pnpm install`，
node_modules 会被还原成 1.1.71，需重新覆盖：

```powershell
$src = 'D:\dsh插件\fixed\dsh-purge-1.1.73'
$dst = 'C:\Users\雫\.dsh\profiles\desktop\node_modules\dsh-purge'
Remove-Item -LiteralPath $dst -Recurse -Force
Copy-Item -LiteralPath $src -Destination $dst -Recurse -Force
```
