# NOTICE — 来源、署名与修改说明 / Provenance, attribution and changes

## 原始项目 / Original project

- **dsh-purge** — https://github.com/YuJunZhiXue/dsh-purge
- 原始作者 / Original author: **YuJunZhiXue** (https://github.com/YuJunZhiXue)
- License: **MIT**，完整版权声明见本仓库 [LICENSE](LICENSE)（Copyright (c) 2026 小杨）。
- 原项目在 README 中明确要求：二次开发/借用名称、思路、代码或提示词时必须署名原作者并注明源仓库
  （"Attribution required" / "If you build on this, see Attribution required"）。
  本仓库据此保留并展示上述署名，**未**声称对原始代码、提示词、文档或 "dsh-purge" 名称拥有版权。

## 本仓库基线 / Base of this repository

- 基线来自 **[2540656380/dsh-purge](https://github.com/2540656380/dsh-purge)**（原项目的第三方 fork），
  版本 `1.1.73+dsh0.2.1`（对应 DeepSeek Harness 0.2.1 适配分支）。
- 该基线的原创部分同样归原作者 YuJunZhiXue；基线自身的改动版权归其 fork 作者。

## 本仓库相对基线的修改 / Changes in this repository

1. **DSH 0.2.1-rc.2 的 cwd 提示词变量兼容（核心修复）**
   - DSH 0.2.1 的 agent-loop 只注册 `provider`、`model` 两个提示词变量，删除了 0.2.0 的 `cwd`；
     旧 bundle patch 中写死的 `personaSuffix: Your working directory is {{cwd}}.`
     会让每轮 `renderPrompt` 抛 `unknown prompt variable "{{cwd}}"`，插件启用后新对话全部失败。
   - 移除写死的 `{{cwd}}` 尾句；`lib/identity.js` 删除过期的 `cwd` 允许项，新增
     `fillCwdPlaceholders()`，在装配末尾对仍参与插值的宿主段统一兜底；
     `lib/index.js` 对 `postPrompt` 段做同样处理。旧配置/旧提示词中残留的 `{{cwd}}` 不再导致崩溃。
2. **Windows 中文用户名路径下的"应用后不重启"修复**
   - `.cmd` 启动器按系统 ANSI 代码页读参数，中文用户名路径（如 `C:\Users\雫\...`）会被解成乱码，
     PowerShell 报"找不到路径"，换包脚本永远不启动。
   - 改为纯 ASCII 启动器 + 通过环境变量传递完整命令行（Windows 环境块是 Unicode）。
3. **适配备注**
   - `package.json` 的 `dshTarget` 由 `0.2.0-rc.2` 更新为 `0.2.1-rc.2`。
4. **清理过期文件**
   - 移除 `.backup-cwdfix-212947/`（旧版 core/identity/patch 备份）、`%SystemDrive%/`（误拷的 Windows 缓存）、
     `.github/`、`.gitignore`、`.npmignore` 等与运行无关的历史产物。
   - 更详细的逐项说明见 [DSH-PURGE-FIX.md](DSH-PURGE-FIX.md)。

## 声明 / Statement

- 本仓库**非商业**，不用于出售或付费转售，仅供学习、技术参考与本地官方 Harness 的自用适配。
- 与原始项目相同的合规声明继续适用：仅用于本机官方 DeepSeek Harness、离线合成环境与合规实验环境。
