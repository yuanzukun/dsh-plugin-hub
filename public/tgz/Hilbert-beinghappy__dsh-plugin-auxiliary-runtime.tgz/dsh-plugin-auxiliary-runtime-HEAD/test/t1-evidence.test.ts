import { createHash } from 'node:crypto'
import { existsSync, readFileSync } from 'node:fs'
import { homedir } from 'node:os'
import { join, sep } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'
import {
  AUXILIARY_IDENTITY,
  DUMP_ABSENT,
  dumpEvidenceContradictions,
  dumpFlagsAgree,
  hasExactAuxiliaryIdentity,
  hasExactClarifyIdentity,
  hasExactSeekTtyIdentity,
  inspectDump,
} from '../scripts/lib/dump.mjs'
import {
  FETCH_READY_TIMEOUT_MS,
  FETCH_REMOTE_TIMEOUT_MS,
  assertIsolatedHome,
  boundedFetchInit,
  classifyCancel,
  classifyGetSurface,
  classifyRunAbsence,
  classifySnapshot,
  deriveRegistrationMode,
  installOfficialDsh,
  isolatedHome,
  officialRequest,
  probeWorkDir,
  verifyReleaseAsset,
  writeEvidence,
} from '../scripts/lib/harness.mjs'
import {
  envWithoutProviderKeys,
  isProviderEnvKey,
  sanitizeT1,
  userValueAsset,
  validateT1Evidence,
} from '../scripts/lib/sanitize.mjs'
import {
  PINNED_DSH_VERSION,
  PLUGIN_VERSION,
  REGISTRATION_DERIVATION,
  RELEASE_TGZ_NAME,
  assertPinnedDshVersion,
  parseT1Args,
} from '../scripts/lib/versions.mjs'
import { buildEvidence, formatT1Report } from '../scripts/t1-lifecycle.mjs'

const root = fileURLToPath(new URL('..', import.meta.url))

function officialThenAuxiliaryDump() {
  return `# == @deepseek-ai/dsh-base\n${'x'.repeat(4500)}\n${AUXILIARY_IDENTITY}\n`
}

function snapshotPosted(capabilityOverrides: Record<string, unknown> = {}) {
  const value = {
    official: { uncachedInputTokens: 1, outputTokens: 2, cacheReadTokens: 3, cacheWriteTokens: 4 },
    auxiliary: { uncachedInputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheWriteTokens: 0 },
    combined: { uncachedInputTokens: 1, outputTokens: 2, cacheReadTokens: 3, cacheWriteTokens: 4 },
    capability: {
      ok: true,
      reason: 'session is not live',
      hostConfirmed: false,
      hostVersion: 'unknown',
      singleProcess: true,
      domain: true,
      storageDomain: true,
      sessions: true,
      llm: true,
      officialProjection: false,
      ...capabilityOverrides,
    },
    sessionId: 'must-not-leak',
  }
  return {
    status: 200,
    json: { type: 'server-response', result: { ok: true, value } },
    value,
  }
}

function cancelPosted() {
  const value = { callId: 'must-not-leak', failure: { category: 'unavailable', code: 'CALL_NOT_FOUND' } }
  return {
    status: 200,
    json: { type: 'server-response', result: { ok: true, value } },
    value,
  }
}

function liveProbe() {
  const snapshot = classifySnapshot(snapshotPosted())
  const cancel = classifyCancel(cancelPosted())
  const run = { present: false, absent: true, statusClass: 'not-found' }
  return {
    snapshot,
    cancel,
    run,
    diy: {
      absent: true,
      clarify: { statusClass: 'ok', diySignature: false },
      auxiliary: { statusClass: 'not-found', diySignature: false },
    },
    registrationMode: deriveRegistrationMode(snapshot, cancel, run),
    registrationDerivation: REGISTRATION_DERIVATION,
    harnessCreatedSession: false,
    harnessInvokedRun: false,
  }
}

describe('T1 dump identity uses the complete dump', () => {
  it('does not claim absent when Auxiliary sits after the first 4000 chars', () => {
    const dump = officialThenAuxiliaryDump()
    expect(inspectDump(dump.slice(0, 4000)).excerpt).toBe(DUMP_ABSENT)
    const inspected = inspectDump(dump)
    expect(inspected.auxiliary).toBe(true)
    expect(inspected.onlyAuxiliary).toBe(true)
    expect(inspected.excerpt).toBe(AUXILIARY_IDENTITY)
    expect(dumpEvidenceContradictions([{
      label: 'after add',
      raw: dump,
      ...inspected,
    }])).toEqual([])
  })

  it('does not treat purpose clarify or a seektty substring as sibling plugins', () => {
    const dump = [
      '# == @deepseek-ai/dsh-base',
      "purpose: 'clarify'",
      'compaction and session-title stay official',
      '# comment about seektty marketplace docs',
      '  name: seektty/startup',
      AUXILIARY_IDENTITY,
    ].join('\n')
    const inspected = inspectDump(dump)
    expect(hasExactClarifyIdentity(dump)).toBe(false)
    expect(hasExactSeekTtyIdentity(dump)).toBe(false)
    expect(inspected.onlyAuxiliary).toBe(true)
    expect(inspected.excerpt).toBe(AUXILIARY_IDENTITY)
  })

  it('requires the Auxiliary section/id/name triple inside the same block', () => {
    expect(inspectDump('# == dsh-plugin-auxiliary-runtime\n- id: auxiliary-runtime\n').auxiliary).toBe(false)
    expect(inspectDump(`${AUXILIARY_IDENTITY}\n# == dsh-plugin-clarify\n- id: clarify\n  name: dsh-plugin-clarify`).onlyAuxiliary).toBe(false)
    expect(inspectDump([
      AUXILIARY_IDENTITY,
      '# == seektty',
      '- id: tui-runner',
      '  name: seektty',
    ].join('\n')).onlyAuxiliary).toBe(false)
  })

  it('does not combine identity lines across different # == sections', () => {
    const crossed = [
      '# == dsh-plugin-auxiliary-runtime',
      '- id: clarify',
      '  name: dsh-plugin-clarify',
      '# == dsh-plugin-clarify',
      '- id: auxiliary-runtime',
      '  name: dsh-plugin-auxiliary-runtime',
      '# == @deepseek-ai/dsh-base',
      '- id: tui-runner',
      '  name: seektty',
    ].join('\n')
    expect(hasExactAuxiliaryIdentity(crossed)).toBe(false)
    expect(hasExactClarifyIdentity(crossed)).toBe(false)
    expect(hasExactSeekTtyIdentity(crossed)).toBe(false)
    expect(inspectDump(crossed).onlyAuxiliary).toBe(false)
    expect(inspectDump([
      '# == seektty',
      '  name: seektty/startup',
      '# == @deepseek-ai/dsh-base',
      '  name: seektty',
      AUXILIARY_IDENTITY,
    ].join('\n')).onlyAuxiliary).toBe(true)
  })

  it('keeps remove dumps on the fixed absent marker', () => {
    const dump = `# == @deepseek-ai/dsh-base\n${'y'.repeat(100)}\n`
    const inspected = inspectDump(dump)
    expect(inspected.auxiliary).toBe(false)
    expect(inspected.excerpt).toBe(DUMP_ABSENT)
    expect(dumpFlagsAgree({
      label: 'after remove',
      ...inspected,
    })).toEqual([])
  })

  it('fails when boolean flags and normalized excerpt disagree', () => {
    const dump = officialThenAuxiliaryDump()
    const errors = dumpEvidenceContradictions([{
      label: 'dump after add',
      raw: dump,
      auxiliary: true,
      clarify: false,
      seektty: false,
      onlyAuxiliary: true,
      excerpt: DUMP_ABSENT,
    }])
    expect(errors.some((item) => item.includes('excerpt'))).toBe(true)
  })
})

describe('T1 Remote classification', () => {
  it('accepts missing-sentinel snapshot only with documented keys and a safe missing-session outcome', () => {
    const classified = classifySnapshot(snapshotPosted())
    expect(classified.live).toBe(true)
    expect(classified.missingSession).toBe(true)
    expect(classified.pluginHostVersionState).toBe('unconfirmed')
    expect(classified.hostVersionAcceptable).toBe(true)
    expect(classified.capability.hostConfirmed).toBe(false)
    expect(classified.capability.ok).toBe(true)
    expect(classified).not.toHaveProperty('hostVersionPinned')
    expect(classified.officialBuckets).toBe(true)
    expect(classified.auxiliaryBuckets).toBe(true)
    expect(classified.combinedBuckets).toBe(true)
    expect(classified.hasOfficial).toBe(true)
    expect(classified.hasAuxiliary).toBe(true)
    expect(classified.hasCombined).toBe(true)
    expect(classified.hasCapability).toBe(true)
    expect(classified).not.toHaveProperty('official')
    expect(JSON.stringify(classified)).not.toMatch(/uncachedInputTokens|must-not-leak|"hostVersion"\s*:|compatibilityWarning/)
    const looseReason = snapshotPosted()
    looseReason.value.capability.reason = 'session missing from public sessions service'
    expect(classifySnapshot(looseReason).live).toBe(false)
    expect(classifySnapshot({
      json: { type: 'server-response', result: { ok: true, value: { official: {}, capability: { reason: 'session is not live' } } } },
      value: { official: {}, capability: { reason: 'session is not live' } },
    }).live).toBe(false)
  })

  it('accepts unknown plugin host version only with capability.ok=true', () => {
    const unknownOk = classifySnapshot(snapshotPosted())
    expect(unknownOk.live).toBe(true)
    expect(unknownOk.pluginHostVersionState).toBe('unconfirmed')
    expect(unknownOk.hostVersionAcceptable).toBe(true)
    expect(unknownOk.capability.hostConfirmed).toBe(false)
    const unknownClosed = classifySnapshot(snapshotPosted({ ok: false }))
    expect(unknownClosed.live).toBe(false)
    expect(unknownClosed.pluginHostVersionState).toBe('unconfirmed')
    expect(unknownClosed.hostVersionAcceptable).toBe(false)
    expect(unknownClosed.capability.ok).toBe(false)
    expect(JSON.stringify(unknownOk)).not.toContain('unknown')
  })

  it('rejects a concrete non-pinned plugin host version and accepts the exact pin', () => {
    const wrong = classifySnapshot(snapshotPosted({ hostVersion: '0.1.1-rc.1', hostConfirmed: false }))
    expect(wrong.live).toBe(false)
    expect(wrong.pluginHostVersionState).toBe('rejected')
    expect(wrong.hostVersionAcceptable).toBe(false)
    expect(JSON.stringify(wrong)).not.toContain('0.1.1-rc.1')
    const otherPin = classifySnapshot(snapshotPosted({ hostVersion: '0.1.0-rc.8', hostConfirmed: true }))
    expect(otherPin.live).toBe(false)
    expect(otherPin.pluginHostVersionState).toBe('rejected')
    const pinned = classifySnapshot(snapshotPosted({ hostVersion: PINNED_DSH_VERSION, hostConfirmed: true }))
    expect(pinned.live).toBe(true)
    expect(pinned.pluginHostVersionState).toBe('pinned')
    expect(pinned.hostVersionAcceptable).toBe(true)
    expect(pinned.capability.hostConfirmed).toBe(true)
    expect(JSON.stringify(pinned)).not.toMatch(/"hostVersion"\s*:|compatibilityWarning/)
  })

  it('accepts missing-sentinel cancel only as successful CALL_NOT_FOUND', () => {
    const classified = classifyCancel(cancelPosted())
    expect(classified.live).toBe(true)
    expect(classified.coarseStatus).toBe('CALL_NOT_FOUND')
    expect(JSON.stringify(classified)).not.toContain('must-not-leak')
    expect(classifyCancel({
      json: { type: 'server-response', result: { ok: false, error: { code: 'CALL_NOT_FOUND' } } },
    }).live).toBe(false)
  })

  it('treats only an HTTP 404 unclaimed route as /run absence', () => {
    expect(classifyRunAbsence({ status: 404 }).present).toBe(false)
    expect(classifyRunAbsence({
      status: 404,
      json: { type: 'server-response', result: { ok: false, error: { code: 'METHOD_NOT_FOUND' } } },
    }).present).toBe(true)
    expect(classifyRunAbsence({
      status: 200,
      json: { type: 'server-response', result: { ok: false, error: { code: 'UNAVAILABLE' } } },
      error: { code: 'UNAVAILABLE' },
    }).present).toBe(true)
    expect(classifyRunAbsence({
      status: 200,
      json: { type: 'server-response', result: { ok: true, value: { status: 'failed', usage: {}, callId: 'x' } } },
      value: { status: 'failed', usage: {}, callId: 'x' },
    }).present).toBe(true)
    expect(classifyRunAbsence({ status: 403 }).present).toBe(true)
    expect(classifyRunAbsence({ status: 500, json: undefined }).present).toBe(true)
    expect(classifyRunAbsence({ status: 200, json: undefined }).present).toBe(true)
    expect(classifyRunAbsence({}).present).toBe(true)
  })

  it('does not require GET 404 for DIY absence when the stock SPA returns 200', () => {
    const spa = classifyGetSurface(200, '<div id="root"></div>')
    expect(spa.statusClass).toBe('ok')
    expect(spa.diySignature).toBe(false)
    expect(classifyGetSurface(200, 'window.CLARIFY_REMOTE = "/api/"').diySignature).toBe(true)
  })

  it('derives typert.register only when both remotes are live and run is absent', () => {
    const snapshot = classifySnapshot(snapshotPosted())
    const cancel = classifyCancel(cancelPosted())
    expect(deriveRegistrationMode(snapshot, cancel, { present: false })).toBe('typert.register')
    expect(deriveRegistrationMode(snapshot, cancel, { present: true })).toBe('blocked')
    expect(deriveRegistrationMode({ live: false }, cancel, { present: false })).toBe('blocked')
  })

  it('sends only a single args object on the official envelope', () => {
    const request = officialRequest('auxiliary-runtime/snapshot', { sessionId: 't1-missing-session' })
    expect(request.payload).toEqual({ args: { sessionId: 't1-missing-session' } })
    expect(Object.keys(request.payload)).toEqual(['args'])
  })
})

describe('T1 sanitizer, assets, and isolation', () => {
  it('strips provider env keys by name without copying those values', () => {
    expect(isProviderEnvKey('OPENAI_API_KEY')).toBe(true)
    expect(isProviderEnvKey('AUTHORIZATION')).toBe(true)
    expect(isProviderEnvKey('FOO_AUTHORIZATION')).toBe(true)
    expect(isProviderEnvKey('FOOAUTHORIZATION')).toBe(false)
    expect(isProviderEnvKey('DSH_HOME')).toBe(false)
    const isolated = envWithoutProviderKeys({
      PATH: '/usr/bin',
      OPENAI_API_KEY: 'sk-secret',
      DSH_HOME: '/safe',
    }, { DSH_HOME: '/probe' })
    expect(isolated).toEqual({ PATH: '/usr/bin', DSH_HOME: '/probe' })
    expect(JSON.stringify(isolated)).not.toContain('sk-secret')
  })

  it('refuses the user HOME and ~/.dsh', () => {
    expect(() => assertIsolatedHome(homedir())).toThrow(/HOME/)
    expect(() => assertIsolatedHome(join(homedir(), '.dsh'))).toThrow(/\.dsh/)
  })

  it('validates the isolated home before destructive cleanup', () => {
    const srcFile = join(root, 'src', 'capability.ts')
    const userDsh = join(homedir(), '.dsh')
    const userDshExisted = existsSync(userDsh)
    expect(existsSync(srcFile)).toBe(true)
    expect(() => isolatedHome(PINNED_DSH_VERSION, `..${sep}..${sep}..${sep}src`)).toThrow(/probe-work/)
    expect(() => isolatedHome(`..${sep}..${sep}src`, 't1')).toThrow(/0\.1\.1-rc\.2/)
    expect(() => assertIsolatedHome(join(root, 'src'))).toThrow(/probe-work/)
    expect(existsSync(srcFile)).toBe(true)
    expect(existsSync(userDsh)).toBe(userDshExisted)
    const home = isolatedHome(PINNED_DSH_VERSION, 't1-review')
    expect(home.startsWith(join(root, '.probe-work') + sep)).toBe(true)
    expect(home.includes(`${sep}homes${sep}t1-review`)).toBe(true)
  })

  it('pins probe work, official install, and evidence writes to 0.1.1-rc.2 before any path is built', () => {
    const srcFile = join(root, 'src', 'capability.ts')
    const gitDir = join(root, '.git')
    const evidenceJson = join(root, 'docs/t1-evidence', PINNED_DSH_VERSION, 't1-lifecycle.json')
    const evidenceBefore = existsSync(evidenceJson) ? readFileSync(evidenceJson, 'utf8') : undefined
    expect(existsSync(srcFile)).toBe(true)
    expect(assertPinnedDshVersion(PINNED_DSH_VERSION)).toBe(PINNED_DSH_VERSION)
    expect(() => assertPinnedDshVersion(`..${sep}src`)).toThrow(/0\.1\.1-rc\.2/)
    expect(() => probeWorkDir(`..${sep}src`)).toThrow(/0\.1\.1-rc\.2/)
    expect(() => probeWorkDir('0.1.0-rc.8')).toThrow(/0\.1\.1-rc\.2/)
    expect(() => installOfficialDsh(`..${sep}src`)).toThrow(/0\.1\.1-rc\.2/)
    expect(() => writeEvidence(`..${sep}..${sep}.git`, 'config', 'no')).toThrow(/0\.1\.1-rc\.2/)
    expect(() => writeEvidence('0.1.0-rc.8', 't1-lifecycle.json', { verdict: '通过' })).toThrow(/0\.1\.1-rc\.2/)
    expect(probeWorkDir(PINNED_DSH_VERSION)).toBe(join(root, '.probe-work', PINNED_DSH_VERSION))
    expect(existsSync(srcFile)).toBe(true)
    expect(existsSync(gitDir)).toBe(true)
    if (evidenceBefore !== undefined) {
      expect(readFileSync(evidenceJson, 'utf8')).toBe(evidenceBefore)
    }
  })

  it('exposes bounded fetch init with AbortSignal timeouts', () => {
    expect(FETCH_READY_TIMEOUT_MS).toBeGreaterThan(0)
    expect(FETCH_READY_TIMEOUT_MS).toBeLessThanOrEqual(5_000)
    expect(FETCH_REMOTE_TIMEOUT_MS).toBeGreaterThan(FETCH_READY_TIMEOUT_MS)
    expect(FETCH_REMOTE_TIMEOUT_MS).toBeLessThanOrEqual(15_000)
    const ready = boundedFetchInit(FETCH_READY_TIMEOUT_MS)
    expect(ready.signal).toBeInstanceOf(AbortSignal)
    expect(ready.signal?.aborted).toBe(false)
    const remote = boundedFetchInit(FETCH_REMOTE_TIMEOUT_MS, { method: 'POST' })
    expect(remote.method).toBe('POST')
    expect(remote.signal).toBeInstanceOf(AbortSignal)
    const owned = new AbortController()
    expect(boundedFetchInit(FETCH_REMOTE_TIMEOUT_MS, { signal: owned.signal }).signal).toBe(owned.signal)
    expect(() => boundedFetchInit(0)).toThrow(/timeoutMs/)
  })

  it('rejects --from-pack and any Host other than 0.1.1-rc.2', () => {
    expect(() => parseT1Args(['--from-pack'])).toThrow(/from-pack/)
    expect(() => parseT1Args(['--dsh-version', '0.1.0-rc.8'])).toThrow(/0\.1\.1-rc\.2/)
    expect(parseT1Args(['--dsh-version', PINNED_DSH_VERSION, '--tgz', 'dsh-plugin-auxiliary-runtime-0.1.1.tgz']).dshVersion).toBe(PINNED_DSH_VERSION)
  })

  it('requires the exact release basename before checksum bool can be true', () => {
    const bytes = Buffer.from('release-bytes')
    const digest = createHash('sha256').update(bytes).digest('hex')
    const sums = `${digest}  ${RELEASE_TGZ_NAME}\n`
    function readRelease(path: string, encoding?: string): string | Buffer {
      if (encoding === 'utf8' || path.endsWith('SHA256SUMS')) return sums
      return path.endsWith('0.1.0.tgz') ? Buffer.from('other') : bytes
    }
    expect(verifyReleaseAsset({
      tgz: `/tmp/${RELEASE_TGZ_NAME}`,
      sha256sums: '/tmp/SHA256SUMS',
      readFile: readRelease,
    }).checksumVerified).toBe(true)
    expect(verifyReleaseAsset({
      tgz: '/tmp/dsh-plugin-auxiliary-runtime-0.1.0.tgz',
      sha256sums: '/tmp/SHA256SUMS',
      readFile: readRelease,
    }).checksumVerified).toBe(false)
  })

  it('drops usage integers, ids, dump, and html from evidence', () => {
    const cleaned = sanitizeT1({
      sessionId: 'sess-1',
      official: { uncachedInputTokens: 9, outputTokens: 8, cacheReadTokens: 7, cacheWriteTokens: 6 },
      dump: officialThenAuxiliaryDump(),
      html: '<!doctype html>',
      hostVersion: '0.1.1-rc.2',
      compatibilityWarning: 'host version is unconfirmed',
      harnessCreatedSession: false,
      coarseStatus: 'CALL_NOT_FOUND',
    })
    expect(cleaned).toEqual({ harnessCreatedSession: false, coarseStatus: 'CALL_NOT_FOUND' })
  })
})

describe('T1 evidence builder and repository gates', () => {
  it('builds a passing schema without claiming a new baseline or release', () => {
    const probe = liveProbe()
    const evidence = buildEvidence({
      asset: { basename: RELEASE_TGZ_NAME, checksumVerified: true, source: 'from-release' },
      steps: [
        { name: 'plugin add', ok: true },
        { name: 'dump after add', ok: true, excerpt: AUXILIARY_IDENTITY, onlyAuxiliary: true },
        { name: 'dump after remove', ok: true, excerpt: DUMP_ABSENT },
        { name: 'dump after re-add', ok: true, excerpt: AUXILIARY_IDENTITY, onlyAuxiliary: true },
      ],
      contradictions: [],
      dumpAfterAdd: { auxiliary: true, clarify: false, seektty: false, onlyAuxiliary: true, excerpt: AUXILIARY_IDENTITY },
      dumpAfterRemove: { auxiliary: false, clarify: false, seektty: false, onlyAuxiliary: false, excerpt: DUMP_ABSENT },
      dumpAfterReadd: { auxiliary: true, clarify: false, seektty: false, onlyAuxiliary: true, excerpt: AUXILIARY_IDENTITY },
      remoteAfterAdd: probe,
      remoteAfterReadd: probe,
    })
    expect(userValueAsset(evidence.asset)).toBe(true)
    expect(validateT1Evidence(evidence)).toEqual({ ok: true, errors: [] })
    expect(evidence.verdict).toBe('通过')
    expect(evidence.registrationMode).toBe('typert.register')
    expect(evidence.jointBaselineClaim).toBe(false)
    expect(evidence.newReleaseClaim).toBe(false)
    expect(evidence.harnessCreatedSession).toBe(false)
    expect(evidence.harnessInvokedRun).toBe(false)
    expect(evidence.pluginVersion).toBe(PLUGIN_VERSION)
    expect(evidence.dshVersion).toBe(PINNED_DSH_VERSION)
    expect(evidence.remote.afterAdd.snapshot.pluginHostVersionState).toBe('unconfirmed')
    expect(evidence.remote.afterAdd.snapshot.hostVersionAcceptable).toBe(true)
    expect(evidence.remote.afterAdd.snapshot.capability.ok).toBe(true)
    expect(evidence.remote.afterAdd.snapshot.capability.hostConfirmed).toBe(false)
    expect(JSON.stringify(evidence)).not.toMatch(/uncachedInputTokens|sessionId|must-not-leak|<!doctype|"hostVersion"\s*:|compatibilityWarning/)
    expect(formatT1Report(evidence)).toMatch(/不把 0\.1\.1 写成新推荐联合基线/)
    expect(formatT1Report(evidence)).toMatch(/dsh --version/)
    expect(formatT1Report(evidence)).toMatch(/unconfirmed/)
    expect(formatT1Report(evidence)).toMatch(/不把这写成 host-confirmed/)
  })

  it('rejects a hand-claimed 通过 when checksum, remotes, or baseline flags disagree', () => {
    const probe = liveProbe()
    const evidence = buildEvidence({
      asset: { basename: RELEASE_TGZ_NAME, checksumVerified: true, source: 'from-release' },
      steps: [
        { name: 'plugin add', ok: true },
        { name: 'dump after add', ok: true, excerpt: AUXILIARY_IDENTITY, onlyAuxiliary: true },
        { name: 'dump after remove', ok: true, excerpt: DUMP_ABSENT },
        { name: 'dump after re-add', ok: true, excerpt: AUXILIARY_IDENTITY, onlyAuxiliary: true },
      ],
      contradictions: [],
      dumpAfterAdd: { auxiliary: true, clarify: false, seektty: false, onlyAuxiliary: true, excerpt: AUXILIARY_IDENTITY },
      dumpAfterRemove: { auxiliary: false, clarify: false, seektty: false, onlyAuxiliary: false, excerpt: DUMP_ABSENT },
      dumpAfterReadd: { auxiliary: true, clarify: false, seektty: false, onlyAuxiliary: true, excerpt: AUXILIARY_IDENTITY },
      remoteAfterAdd: probe,
      remoteAfterReadd: probe,
    })
    expect(validateT1Evidence(evidence).ok).toBe(true)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      asset: { ...evidence.asset, checksumVerified: false },
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      lifecycle: { verdict: '阻塞', failed: ['plugin add'] },
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      layers: { ...evidence.layers, consistency: { ok: false, contradictions: ['crossed'] } },
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      registrationMode: 'blocked',
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      remote: { afterAdd: { ...probe, snapshot: { ...probe.snapshot, live: false } }, afterReadd: probe },
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      remote: { afterAdd: probe, afterReadd: { ...probe, cancel: { ...probe.cancel, live: false } } },
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      remote: { afterAdd: { ...probe, diy: { ...probe.diy, absent: false } }, afterReadd: probe },
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      jointBaselineClaim: true,
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      newReleaseClaim: true,
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      remote: {
        afterAdd: { ...probe, snapshot: { ...probe.snapshot, pluginHostVersionState: 'rejected', hostVersionAcceptable: false } },
        afterReadd: probe,
      },
    }).ok).toBe(false)
    expect(validateT1Evidence({
      ...evidence,
      verdict: '通过',
      remote: {
        afterAdd: { ...probe, snapshot: { ...probe.snapshot, capability: { ...probe.snapshot.capability, ok: false } } },
        afterReadd: probe,
      },
    }).ok).toBe(false)
  })

  it('allows missing T1 evidence before --write and validates both files when either appears', () => {
    const jsonPath = join(root, 'docs/t1-evidence', PINNED_DSH_VERSION, 't1-lifecycle.json')
    const reportPath = join(root, 'docs/t1-evidence', PINNED_DSH_VERSION, 't1-report.md')
    const jsonExists = existsSync(jsonPath)
    const reportExists = existsSync(reportPath)
    if (!jsonExists && !reportExists) return
    expect(jsonExists).toBe(true)
    expect(reportExists).toBe(true)
    const evidence = JSON.parse(readFileSync(jsonPath, 'utf8')) as ReturnType<typeof buildEvidence>
    expect(validateT1Evidence(evidence)).toEqual({ ok: true, errors: [] })
    expect(evidence.verdict).toBe('通过')
    const report = readFileSync(reportPath, 'utf8')
    expect(report.length).toBeGreaterThan(0)
    const blob = `${JSON.stringify(evidence)}\n${report}`
    expect(blob).not.toMatch(/uncachedInputTokens|sessionId|<!doctype html/i)
    expect(blob).not.toMatch(/\/Users\/|DSH_HOME=\//)
  })

  it('keeps CI offline and does not add a release lifecycle job', () => {
    const ci = readFileSync(join(root, '.github/workflows/ci.yml'), 'utf8')
    expect(ci).toMatch(/pnpm test/)
    expect(ci).not.toMatch(/t1-lifecycle|--install-dsh|t1:matrix|@deepseek-ai\/dsh@/)
  })

  it('keeps the harness from creating a Session, opening a browser, or guessing payload shapes', () => {
    const lifecycle = readFileSync(join(root, 'scripts/t1-lifecycle.mjs'), 'utf8')
    const harness = readFileSync(join(root, 'scripts/lib/harness.mjs'), 'utf8')
    const source = `${lifecycle}\n${harness}`
    expect(source).not.toMatch(/session\.create|sessions\.create|workspace\.create/)
    expect(source).toMatch(/--no-open/)
    expect(source).toMatch(/--port', '0'/)
    expect(harness).toMatch(/refusing to probe 3080/)
    expect(source).toMatch(/payload: \{ args \}/)
    expect(source).not.toMatch(/payload:\s*\{\s*sessionId/)
    expect(source).not.toMatch(/from ['"]\.\.\/src/)
    expect(harness).toMatch(/refusing to probe 3080/)
    expect(harness).toMatch(/env:\s*envWithoutProviderKeys\(process\.env\)/)
    const fetchLines = harness.split('\n').filter((line) => line.includes('fetch('))
    expect(fetchLines.length).toBeGreaterThanOrEqual(4)
    expect(fetchLines.every((line) => line.includes('boundedFetchInit'))).toBe(true)
  })
})
