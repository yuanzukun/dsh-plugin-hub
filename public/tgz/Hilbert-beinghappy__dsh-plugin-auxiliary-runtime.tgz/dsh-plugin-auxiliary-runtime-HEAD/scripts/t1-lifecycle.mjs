#!/usr/bin/env node
import { rmSync } from 'node:fs'
import { basename, resolve } from 'node:path'
import { pathToFileURL } from 'node:url'
import {
  DUMP_ABSENT,
  communityPluginsAbsent,
  dumpEvidenceContradictions,
} from './lib/dump.mjs'
import {
  isolatedHome,
  isolatedProcessEnv,
  probeAuxiliaryRemote,
  remoteLive,
  resolveDshBin,
  runDsh,
  spawnDsh,
  stopChild,
  summarizeDumpStep,
  verifyReleaseAsset,
  waitForPrintedOrigin,
  writeEvidence,
} from './lib/harness.mjs'
import { sanitizeT1, userValueAsset, validateT1Evidence } from './lib/sanitize.mjs'
import {
  PINNED_DSH_VERSION,
  PLUGIN_NAME,
  PLUGIN_VERSION,
  REGISTRATION_DERIVATION,
  T1_PROTOCOL,
  parseT1Args,
  requireReleaseAssets,
} from './lib/versions.mjs'

/**
 * @param {{
 *   asset?: { basename?: string, checksumVerified?: boolean, source?: string },
 *   steps?: Array<{ name: string, ok?: boolean, excerpt?: string, onlyAuxiliary?: boolean }>,
 *   contradictions?: string[],
 *   dumpAfterAdd?: object,
 *   dumpAfterRemove?: object,
 *   dumpAfterReadd?: object,
 *   remoteAfterAdd?: object,
 *   remoteAfterReadd?: object,
 * }} input
 */
export function buildEvidence(input) {
  const dumpConsistency = {
    ok: (input.contradictions ?? []).length === 0,
    contradictions: input.contradictions ?? [],
  }
  const failed = (input.steps ?? []).filter((step) => step.ok === false).map((step) => step.name)
  const lifecycleVerdict = failed.length === 0 ? '通过' : '阻塞'
  const remoteAfterAdd = input.remoteAfterAdd
  const remoteAfterReadd = input.remoteAfterReadd
  const registrationMode = remoteAfterAdd?.registrationMode === 'typert.register'
    && remoteAfterReadd?.registrationMode === 'typert.register'
    ? 'typert.register'
    : 'blocked'
  const evidence = {
    protocol: T1_PROTOCOL,
    verdict: lifecycleVerdict === '通过' && dumpConsistency.ok && userValueAsset(input.asset)
      && registrationMode === 'typert.register'
      ? '通过'
      : '阻塞',
    dshVersion: PINNED_DSH_VERSION,
    pluginVersion: PLUGIN_VERSION,
    asset: {
      basename: input.asset?.basename,
      checksumVerified: input.asset?.checksumVerified === true,
      source: 'from-release',
    },
    harnessCreatedSession: false,
    harnessInvokedRun: false,
    jointBaselineClaim: false,
    newReleaseClaim: false,
    registrationMode,
    registrationDerivation: REGISTRATION_DERIVATION,
    lifecycle: { verdict: lifecycleVerdict, failed },
    layers: {
      afterAdd: publicDump(input.dumpAfterAdd),
      afterRemove: publicDump(input.dumpAfterRemove),
      afterReadd: publicDump(input.dumpAfterReadd),
      consistency: dumpConsistency,
    },
    remote: {
      afterAdd: publicRemote(remoteAfterAdd),
      afterReadd: publicRemote(remoteAfterReadd),
    },
    steps: (input.steps ?? []).map((step) => ({
      name: step.name,
      ok: step.ok === true,
      ...step.excerpt ? { excerpt: step.excerpt } : {},
      ...typeof step.onlyAuxiliary === 'boolean' ? { onlyAuxiliary: step.onlyAuxiliary } : {},
    })),
  }
  return sanitizeT1(evidence)
}

export function formatT1Report(evidence) {
  return `# Auxiliary Runtime standalone T1（${evidence.dshVersion}）

> 本报告只记录隔离 web Profile 上、无 SeekTTY / 无 Clarify 的 standalone lifecycle。
> 不把 ${evidence.pluginVersion} 写成新推荐联合基线，也不把本轮写成新 Release。
> T1 Host pin 权威是独立观测的 \`dsh --version\` 与 \`evidence.dshVersion\`。stock ${evidence.dshVersion} 上插件内部版本报告为 unconfirmed（\`hostConfirmed=false\` 是诚实事实）；T1 不把这写成 host-confirmed。

## 总结论

| 项 | 结论 |
| --- | --- |
| standalone T1 | ${evidence.verdict} |
| dump 仅 Auxiliary（三社区插件之中） | ${evidence.layers?.consistency?.ok ? '通过' : '阻塞'} |
| snapshot / cancel 信封 | ${evidence.registrationMode} |
| plugin-internal version | add=${evidence.remote?.afterAdd?.snapshot?.pluginHostVersionState}/${evidence.remote?.afterAdd?.snapshot?.hostVersionAcceptable} re-add=${evidence.remote?.afterReadd?.snapshot?.pluginHostVersionState}/${evidence.remote?.afterReadd?.snapshot?.hostVersionAcceptable} |
| 联合基线声明 | ${evidence.jointBaselineClaim === true ? '违规' : '未声明'} |

## 资产

- basename：\`${evidence.asset?.basename}\`
- source：\`${evidence.asset?.source}\`
- checksumVerified：\`${evidence.asset?.checksumVerified === true}\`

## dump

- after add：\`onlyAuxiliary=${evidence.layers?.afterAdd?.onlyAuxiliary}\` / \`${evidence.layers?.afterAdd?.excerpt}\`
- after remove：\`auxiliary=${evidence.layers?.afterRemove?.auxiliary}\` / \`${evidence.layers?.afterRemove?.excerpt}\`
- after re-add：\`onlyAuxiliary=${evidence.layers?.afterReadd?.onlyAuxiliary}\` / \`${evidence.layers?.afterReadd?.excerpt}\`

## Remote

- registrationMode：\`${evidence.registrationMode}\`
- 推导：${evidence.registrationDerivation}
- Host pin：\`dsh --version\` / \`dshVersion=${evidence.dshVersion}\`
- plugin-internal after add：state=\`${evidence.remote?.afterAdd?.snapshot?.pluginHostVersionState}\` acceptable=\`${evidence.remote?.afterAdd?.snapshot?.hostVersionAcceptable}\` hostConfirmed=\`${evidence.remote?.afterAdd?.snapshot?.capability?.hostConfirmed}\`
- plugin-internal after re-add：state=\`${evidence.remote?.afterReadd?.snapshot?.pluginHostVersionState}\` acceptable=\`${evidence.remote?.afterReadd?.snapshot?.hostVersionAcceptable}\` hostConfirmed=\`${evidence.remote?.afterReadd?.snapshot?.capability?.hostConfirmed}\`
- harnessCreatedSession：\`${evidence.harnessCreatedSession}\`
- harnessInvokedRun：\`${evidence.harnessInvokedRun}\`
`
}

function publicDump(dump) {
  if (!dump) return undefined
  return {
    auxiliary: dump.auxiliary === true,
    clarify: dump.clarify === true,
    seektty: dump.seektty === true,
    onlyAuxiliary: dump.onlyAuxiliary === true,
    excerpt: dump.excerpt,
  }
}

function publicRemote(probe) {
  if (!probe) return undefined
  return {
    snapshot: probe.snapshot,
    cancel: probe.cancel,
    run: probe.run,
    diy: probe.diy,
    registrationMode: probe.registrationMode,
    harnessCreatedSession: false,
    harnessInvokedRun: false,
  }
}

export async function runT1Lifecycle(argv = process.argv.slice(2)) {
  const parsed = requireReleaseAssets(parseT1Args(argv))
  const asset = verifyReleaseAsset({
    tgz: parsed.tgz,
    sha256sums: parsed.sha256sums,
  })
  if (basename(parsed.tgz) !== asset.basename || !asset.checksumVerified) {
    throw new Error('阻塞：release tgz basename or SHA256SUMS verification failed')
  }
  const dshBin = resolveDshBin({
    dshBin: parsed.dshBin,
    version: parsed.dshVersion,
    install: parsed.installDsh,
  })
  const home = isolatedHome(parsed.dshVersion, 't1')
  const env = isolatedProcessEnv(home)
  const steps = []
  const dumps = []
  let child
  let remoteAfterAdd
  let remoteAfterReadd
  const remember = (step) => {
    steps.push(step)
    console.log(`${step.ok ? 'PASS' : 'FAIL'} ${step.name}`)
    return step
  }
  try {
    const observed = runDsh(dshBin, ['--version'], env).trim()
    remember({ name: 'dsh --version', ok: observed === PINNED_DSH_VERSION })
    if (observed !== PINNED_DSH_VERSION) throw new Error('dsh --version is not 0.1.1-rc.2')
    const initDump = summarizeDumpStep('init dump', runDsh(dshBin, ['--profile', 'web', '--dump-config'], env), 'absent')
    remember({
      name: initDump.name,
      ok: communityPluginsAbsent(initDump),
      excerpt: initDump.excerpt,
    })
    if (!communityPluginsAbsent(initDump)) throw new Error('init dump is not free of Auxiliary, Clarify, and SeekTTY')
    step('plugin add', () => runDsh(dshBin, ['plugin', '--profile', 'web', 'add', parsed.tgz], env))
    const dumpAfterAdd = summarizeDumpStep(
      'dump after add',
      runDsh(dshBin, ['--profile', 'web', '--dump-config'], env),
      'only-auxiliary',
    )
    dumps.push({ label: dumpAfterAdd.name, ...dumpAfterAdd })
    remember({
      name: dumpAfterAdd.name,
      ok: dumpAfterAdd.onlyAuxiliary === true,
      excerpt: dumpAfterAdd.excerpt,
      onlyAuxiliary: dumpAfterAdd.onlyAuxiliary,
    })
    if (dumpAfterAdd.onlyAuxiliary !== true) throw new Error('dump after add is not only Auxiliary among the three community plugins')
    remoteAfterAdd = await bootAndProbe(dshBin, env, (next) => { child = next })
    remember({ name: 'boot and probe after add', ok: remoteLive(remoteAfterAdd) })
    step('plugin remove', () => runDsh(dshBin, ['plugin', '--profile', 'web', 'remove', PLUGIN_NAME], env))
    const dumpAfterRemove = summarizeDumpStep(
      'dump after remove',
      runDsh(dshBin, ['--profile', 'web', '--dump-config'], env),
      'absent',
    )
    dumps.push({ label: dumpAfterRemove.name, ...dumpAfterRemove })
    remember({
      name: dumpAfterRemove.name,
      ok: communityPluginsAbsent(dumpAfterRemove),
      excerpt: dumpAfterRemove.excerpt,
    })
    if (!communityPluginsAbsent(dumpAfterRemove)) throw new Error('dump after remove is not DUMP_ABSENT')
    step('plugin re-add', () => runDsh(dshBin, ['plugin', '--profile', 'web', 'add', parsed.tgz], env))
    const dumpAfterReadd = summarizeDumpStep(
      'dump after re-add',
      runDsh(dshBin, ['--profile', 'web', '--dump-config'], env),
      'only-auxiliary',
    )
    dumps.push({ label: dumpAfterReadd.name, ...dumpAfterReadd })
    remember({
      name: dumpAfterReadd.name,
      ok: dumpAfterReadd.onlyAuxiliary === true,
      excerpt: dumpAfterReadd.excerpt,
      onlyAuxiliary: dumpAfterReadd.onlyAuxiliary,
    })
    if (dumpAfterReadd.onlyAuxiliary !== true) throw new Error('dump after re-add is not only Auxiliary among the three community plugins')
    remoteAfterReadd = await bootAndProbe(dshBin, env, (next) => { child = next })
    remember({ name: 'boot and probe after re-add', ok: remoteLive(remoteAfterReadd) })
    const contradictions = dumpEvidenceContradictions(dumps)
    remember({
      name: 'dump evidence consistency',
      ok: contradictions.length === 0,
    })
    const evidence = buildEvidence({
      asset,
      steps,
      contradictions,
      dumpAfterAdd,
      dumpAfterRemove,
      dumpAfterReadd,
      remoteAfterAdd,
      remoteAfterReadd,
    })
    const validated = validateT1Evidence(evidence)
    if (!validated.ok) evidence.verdict = '阻塞'
    if (parsed.write) {
      writeEvidence(PINNED_DSH_VERSION, 't1-lifecycle.json', evidence)
      writeEvidence(PINNED_DSH_VERSION, 't1-report.md', formatT1Report(evidence))
    }
    console.log(`T1 verdict=${evidence.verdict} registration=${evidence.registrationMode}`)
    if (evidence.verdict !== '通过') process.exitCode = 1
    return evidence
  } catch (error) {
    const failed = remember({
      name: 'lifecycle',
      ok: false,
    })
    const evidence = buildEvidence({
      asset,
      steps: [...steps.filter((item) => item !== failed), { name: 'lifecycle', ok: false }],
      contradictions: ['lifecycle threw before completion'],
      dumpAfterAdd: emptyDump(),
      dumpAfterRemove: emptyDump(),
      dumpAfterReadd: emptyDump(),
    })
    evidence.verdict = '阻塞'
    if (parsed.write) {
      writeEvidence(PINNED_DSH_VERSION, 't1-lifecycle.json', evidence)
      writeEvidence(PINNED_DSH_VERSION, 't1-report.md', formatT1Report(evidence))
    }
    console.error(error instanceof Error ? error.message : error)
    process.exitCode = 1
    return evidence
  } finally {
    await stopChild(child)
    try {
      rmSync(home, { recursive: true, force: true })
    } catch {
      // cleanup best-effort
    }
  }

  function step(name, fn) {
    try {
      fn()
      return remember({ name, ok: true })
    } catch {
      remember({ name, ok: false })
      throw new Error(`T1 step failed: ${name}`)
    }
  }
}

function emptyDump() {
  return {
    auxiliary: false,
    clarify: false,
    seektty: false,
    onlyAuxiliary: false,
    excerpt: DUMP_ABSENT,
  }
}

async function bootAndProbe(dshBin, env, retain) {
  const child = spawnDsh(dshBin, ['--profile', 'web', '--port', '0', '--no-open'], env)
  retain?.(child)
  let output = ''
  child.stdout.on('data', (chunk) => { output += chunk })
  child.stderr.on('data', (chunk) => { output += chunk })
  try {
    const waited = await waitForPrintedOrigin(child, () => output)
    const probe = await probeAuxiliaryRemote(waited.origin)
    return probe
  } finally {
    await stopChild(child)
    retain?.(undefined)
  }
}

const isMain = Boolean(process.argv[1])
  && import.meta.url === pathToFileURL(resolve(process.argv[1])).href
if (isMain) {
  await runT1Lifecycle()
}
