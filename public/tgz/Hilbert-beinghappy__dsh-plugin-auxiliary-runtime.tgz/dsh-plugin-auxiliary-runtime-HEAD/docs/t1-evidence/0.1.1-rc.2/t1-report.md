# Auxiliary Runtime standalone T1（0.1.1-rc.2）

> 本报告只记录隔离 web Profile 上、无 SeekTTY / 无 Clarify 的 standalone lifecycle。
> 不把 0.1.1 写成新推荐联合基线，也不把本轮写成新 Release。
> T1 Host pin 权威是独立观测的 `dsh --version` 与 `evidence.dshVersion`。stock 0.1.1-rc.2 上插件内部版本报告为 unconfirmed（`hostConfirmed=false` 是诚实事实）；T1 不把这写成 host-confirmed。

## 总结论

| 项 | 结论 |
| --- | --- |
| standalone T1 | 通过 |
| dump 仅 Auxiliary（三社区插件之中） | 通过 |
| snapshot / cancel 信封 | typert.register |
| plugin-internal version | add=unconfirmed/true re-add=unconfirmed/true |
| 联合基线声明 | 未声明 |

## 资产

- basename：`dsh-plugin-auxiliary-runtime-0.1.1.tgz`
- source：`from-release`
- checksumVerified：`true`

## dump

- after add：`onlyAuxiliary=true` / `# == dsh-plugin-auxiliary-runtime
- id: auxiliary-runtime
  name: dsh-plugin-auxiliary-runtime`
- after remove：`auxiliary=false` / `dsh-plugin-auxiliary-runtime not found`
- after re-add：`onlyAuxiliary=true` / `# == dsh-plugin-auxiliary-runtime
- id: auxiliary-runtime
  name: dsh-plugin-auxiliary-runtime`

## Remote

- registrationMode：`typert.register`
- 推导：derived from official POST /api/auxiliary-runtime/snapshot and /cancel server-response liveness plus /run method absence; not a direct read of lastAuxiliaryRuntimeRegistration()
- Host pin：`dsh --version` / `dshVersion=0.1.1-rc.2`
- plugin-internal after add：state=`unconfirmed` acceptable=`true` hostConfirmed=`false`
- plugin-internal after re-add：state=`unconfirmed` acceptable=`true` hostConfirmed=`false`
- harnessCreatedSession：`false`
- harnessInvokedRun：`false`
