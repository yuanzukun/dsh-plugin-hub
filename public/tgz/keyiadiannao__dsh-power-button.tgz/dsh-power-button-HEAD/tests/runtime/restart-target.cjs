'use strict'
// Minimal stand-in for a restarted DSH instance: serves the ONE endpoint the
// restart helper polls (/api/dsh-power-button/health) with a fixed instanceId.
// The runtime E2E drives the REAL generated helper against two of these
// processes (old → killed → new) so the whole chain — pid exit, port release,
// session quiescence, env-token relaunch, health confirmation — runs against
// real processes, real PIDs and a real TCP port without needing a real DSH.
const http = require('node:http')
const fs = require('node:fs')

const args = process.argv.slice(2)
function argOf(name) {
  const i = args.indexOf(name)
  return i >= 0 && i + 1 < args.length ? args[i + 1] : undefined
}
// `--port 0` is the case this stand-in has to cover as well as a fixed port:
// the OS picks the real one, and the test needs to learn it before it can tell
// the helper which port to wait for.
const PORT = Number(argOf('--port'))
const PORT_FILE = argOf('--port-file')
// Where the helper writes the restart marker. The real DSH instance claims its
// restart identity only when the launch token AND this file agree, so a target
// that ignored the file would report a restart the real one could never prove.
const MARKER = argOf('--marker')
const INSTANCE_ID = argOf('--instance-id') ?? 'unknown-instance'
const FORGET_RESTART = args.includes('--forget-restart')
// The environment-refresh test needs to know what THIS process actually
// inherited, which only the successor itself can report.
const DUMP_ENV = argOf('--dump-env')
const DUMP_ENV_FILE = argOf('--dump-env-file')
if (DUMP_ENV !== undefined && DUMP_ENV_FILE !== undefined) {
  try { fs.writeFileSync(DUMP_ENV_FILE, process.env[DUMP_ENV] ?? '', 'utf8') } catch { /* best-effort */ }
}
if (!Number.isInteger(PORT) || PORT < 0) {
  console.error('usage: node restart-target.cjs --port <n> [--port-file <path>] --instance-id <id>')
  process.exit(2)
}

const server = http.createServer((req, res) => {
  /** True when the marker on disk carries this launch's restart id. */
  function markerAgrees() {
    if (MARKER === undefined) return true
    try {
      return JSON.parse(fs.readFileSync(MARKER, 'utf8')).restartId === process.env.DSH_POWER_RESTART_ID
    } catch {
      // No marker, or an unreadable one: the claim cannot be proved, exactly as
      // in the real host where a failed marker write leaves it unclaimable.
      return false
    }
  }
  const url = new URL(req.url ?? '/', 'http://x')
  if (req.method === 'GET' && url.pathname === '/api/dsh-power-button/health') {
    // Mirror the real plugin: a process relaunched by the helper inherits
    // DSH_POWER_RESTART_ID and reports the restart identity on /health —
    // unless the test passes --forget-restart to simulate an instance that
    // cannot prove its restart (manual boot, foreign instance).
    const body = { ok: true, instanceId: INSTANCE_ID }
    if (process.env.DSH_POWER_RESTART_ID && !FORGET_RESTART && markerAgrees()) {
      body.restart = { restartId: process.env.DSH_POWER_RESTART_ID }
    }
    res.writeHead(200, { 'content-type': 'application/json' })
    res.end(JSON.stringify(body))
    return
  }
  res.writeHead(404, { 'content-type': 'application/json' })
  res.end(JSON.stringify({ ok: false, error: 'not the health endpoint' }))
})
server.listen(PORT, '127.0.0.1', () => {
  const bound = server.address().port
  // Report the port the OS actually granted, so a --port 0 run is observable.
  if (PORT_FILE !== undefined) {
    try { fs.writeFileSync(PORT_FILE, String(bound), 'utf8') } catch { /* best-effort */ }
  }
  console.log(`target ${INSTANCE_ID} listening on ${bound}`)
})
