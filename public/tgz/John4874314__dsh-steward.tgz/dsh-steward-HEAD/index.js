/**
 * chat-manager (Host half)
 *
 * 两件事：
 *  1. 每个新对话在自己的工作区目录下建一个独立文件夹（默认关闭，可在 DSH 设置里打开）。
 *  2. 提供 /chat-delete 命令，供客户端「删除对话」使用：归档会话、可选删除会话日志、
 *     可选删除该对话的文件夹。
 *
 * 客户端通过 ctx.remote.commands.execute(agent, '/chat-delete ...', [], signal) 调用，
 * 这样删除这类破坏性操作只有一份实现，UI 与命令不会各写一套。
 */

import {
  mkdir, rm, stat, readdir, readFile, writeFile, copyFile, cp, rename, unlink,
} from 'node:fs/promises'
import { join, resolve, sep, dirname, basename, isAbsolute } from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath, pathToFileURL } from 'node:url'
import { randomBytes } from 'node:crypto'
import { spawn, execFile } from 'node:child_process'

/**
 * 尽力拿到 schemastery。
 *
 * 不用静态 `import`：那是加载期的硬失败 —— 一旦 harness 升级、profile 重建、
 * 或者这个链接被清掉，整个插件模块都会导入失败（插件虽不会拖垮 harness，
 * 但会永久不可用，而且报错发生在最早期，很难看出原因）。
 * 这里改成运行时尝试，拿不到就退化成"没有 Config 表单"，其余功能照常。
 */
const Schema = await (async () => {
  /**
   * 依次尝试各个来源，**逐个 await**。
   *
   * 不能先把两个 import() 都创建出来再 Promise.all —— 那会让 schemastery 的
   * CJS 入口（它 require 了 ESM 的 cosmokit）和另一个 import 同时进行，
   * 触发 ERR_REQUIRE_ESM_RACE_CONDITION。串行就没这个问题。
   */
  const sources = []

  // 1) 直接按包名解析（插件自己 node_modules 里有链接时走这条）
  sources.push(() => import('@deepseek-ai/schemastery'))

  // 2) 从宿主 profile 解析。resolve() 给的是 Windows 路径，
  //    ESM 的 import() 只吃 URL，直接传路径会抛 ERR_UNSUPPORTED_ESM_URL_SCHEME。
  sources.push(() => {
    const requireFromProfile = createRequire(join(process.env.DSH_PROFILE_DIR ?? '.', 'package.json'))
    return import(pathToFileURL(requireFromProfile.resolve('@deepseek-ai/schemastery')).href)
  })

  for (const load of sources) {
    try {
      const mod = await load()
      const schema = mod?.default ?? mod
      if (typeof schema?.object === 'function') return schema
    } catch {
      // 换下一个来源
    }
  }
  return undefined
})()

export const name = 'dsh-steward'

/**
 * 宿主 Context 也是受限代理：凡是要 ctx.xxx 访问的服务都得在这里声明，
 * 否则调用时直接抛 "cannot get property ... without inject"。
 *
 * 只放必需项：commands 与 workspaceRegistry（读/改目录、切工作目录都是可选的，
 * 用 ctx.get 弱取，缺失时优雅降级，不让整个插件卡在等待依赖上）。
 */
export const inject = [
  'commands',           // 注册 /chat-* 命令
  'workspaceRegistry',  // 归档会话
]

/**
 * 声明 Config，DSH 设置页才会为这个插件生成可编辑的表单。
 *
 * `.volatile()` 是关键：settings 服务只把 volatile 字段投影成表单、并允许写回，
 * 普通字段只读也不出现在表单里。改这个开关不需要重挂插件，所以正合适。
 *
 * 拿不到 schemastery 时不导出 Config（而不是导出一个坏对象）：
 * 插件会失去设置页表单，但目录开关仍然读 json 配置、命令仍然可用。
 */
export const Config = Schema === undefined
  ? undefined
  : Schema.object({
    folder: Schema.object({
      enabled: Schema.boolean().default(false)
        .description('每个新对话在工作区里自动创建一个独立文件夹'),
      trigger: Schema.union(['first-message', 'created']).default('first-message')
        .description('first-message：发出第一条消息时创建；created：会话一创建就创建'),
      template: Schema.string().default('chat-{date}-{time}')
        .description('文件夹名模板，支持 {date} {time} {datetime} {id} {title}'),
      useAsWorkingDirectory: Schema.boolean().default(false)
        .description('同时把该会话的工作目录切到新建的文件夹'),
    }).description('对话文件夹').volatile(),
    guardrails: Schema.object({
      // 默认关闭：装一个插件就改写全局 AGENTS.md 是越权的，应由用户自己打开。
      install: Schema.boolean().default(false)
        .description('把「运行三原则」写进 /AGENTS.md（对所有工作区生效）'),
    }).description('运行守则').volatile(),
    sessionLog: Schema.object({
      enabled: Schema.boolean().default(true)
        .description('把该对话的完整日志导出成可读的「交接日志.md」放进对话文件夹'),
      maxMessages: Schema.number().step(1).min(0).default(400)
        .description('最多导出多少条消息（0 = 不限制）。超出时保留最近的'),
      includeTools: Schema.boolean().default(true)
        .description('日志里是否包含工具调用与结果'),
    }).description('交接日志').volatile(),
  })

const DEFAULTS = {
  // 默认 **不** 写入全局 AGENTS.md。装个插件就改所有工作区的提示词属于越权，
  // 想要三原则的人在设置页自己打开。
  guardrails: { install: false },
  folder: {
    enabled: false,
    trigger: 'first-message',
    template: 'chat-{date}-{time}',
    useAsWorkingDirectory: false,
  },
  sessionLog: {
    enabled: true,
    maxMessages: 400,
    includeTools: true,
  },
}

/** volatile 字段运行时是包装对象，取真实值要解包。 */
function unwrap(value) {
  if (value !== null && typeof value === 'object' && typeof value.get === 'function') {
    try {
      return value.get()
    } catch {
      return value
    }
  }
  return value
}

function folderConfig(config) {
  const folder = unwrap(config?.folder)
  return { ...DEFAULTS.folder, ...(folder ?? {}) }
}

function sessionLogConfig(config) {
  const log = unwrap(config?.sessionLog)
  return { ...DEFAULTS.sessionLog, ...(log ?? {}) }
}

function pad(value) {
  return String(value).padStart(2, '0')
}

function stamp(date) {
  const d = date.getFullYear()
  const m = pad(date.getMonth() + 1)
  const day = pad(date.getDate())
  const hh = pad(date.getHours())
  const mm = pad(date.getMinutes())
  const ss = pad(date.getSeconds())
  return { date: `${d}${m}${day}`, time: `${hh}${mm}${ss}`, datetime: `${d}${m}${day}-${hh}${mm}${ss}` }
}

/** 目录名里不能出现的字符统一换成 -，避免建出非法文件夹。 */
function sanitize(name) {
  const cleaned = name
    .replace(/[<>:"/\\|?*\u0000-\u001f]/g, '-')
    .replace(/^[\s.]+|[\s.]+$/g, '')
    .slice(0, 80)
  return cleaned || 'chat'
}

function folderName(template, sessionId, title, now) {
  const parts = stamp(now)
  const rendered = String(template ?? DEFAULTS.folder.template)
    .replace(/\{datetime\}/g, parts.datetime)
    .replace(/\{date\}/g, parts.date)
    .replace(/\{time\}/g, parts.time)
    .replace(/\{id\}/g, String(sessionId).slice(0, 8))
    .replace(/\{title\}/g, title ?? '')
  return sanitize(rendered)
}

/** 会话日志根目录：$DSH_HOME/sessions。找不到就返回 undefined，调用方跳过。 */
function sessionsRoot() {
  const home = process.env.DSH_HOME
  if (typeof home !== 'string' || home.length === 0) return undefined
  return join(home, 'sessions')
}

/**
 * 精确找到某个会话的日志目录。
 *
 * 目录名形如 "$DSH_HOME/sessions/<cwd转义>/session-<uuid>"。
 * 注意 SessionId 本身**已经带 `session-` 前缀**（DSH_SESSION_ID 就是
 * "session-86b1641f-…"），所以不能再无条件拼接，否则会拼成
 * "session-session-…" 而永远找不到 —— 那会让删除静默退化成只归档。
 */
function logDirName(sessionId) {
  const id = String(sessionId)
  return id.startsWith('session-') ? id : `session-${id}`
}

async function findSessionLogDir(sessionId) {
  const root = sessionsRoot()
  if (root === undefined) return undefined
  const target = logDirName(sessionId)

  let entries
  try {
    entries = await readdir(root, { withFileTypes: true })
  } catch {
    return undefined
  }

  for (const entry of entries) {
    if (!entry.isDirectory()) continue
    const direct = join(root, entry.name)
    if (entry.name === target) return direct

    // 一级子目录（按工作区分组）里再找一次
    let children
    try {
      children = await readdir(direct, { withFileTypes: true })
    } catch {
      continue
    }
    for (const child of children) {
      if (child.isDirectory() && child.name === target) return join(direct, child.name)
    }
  }
  return undefined
}

/** 会话 id → 文件夹路径的持久登记表，重启后仍能定位到对话文件夹。 */
function registryPath() {
  const home = process.env.DSH_HOME
  if (typeof home !== 'string' || home.length === 0) return undefined
  return join(home, 'chat-manager-folders.json')
}

async function loadRegistry() {
  const file = registryPath()
  if (file === undefined) return new Map()
  try {
    const raw = await readFile(file, 'utf8')
    const parsed = JSON.parse(raw)
    if (parsed !== null && typeof parsed === 'object') {
      return new Map(Object.entries(parsed).filter(([, value]) => typeof value === 'string'))
    }
  } catch {
    // 文件不存在或损坏，从空表开始
  }
  return new Map()
}

async function saveRegistry(map) {
  const file = registryPath()
  if (file === undefined) return
  try {
    await writeFile(file, JSON.stringify(Object.fromEntries(map), null, 2), 'utf8')
  } catch (error) {
    ctxWarn(`dsh-steward: 无法保存文件夹登记表: ${error?.message ?? error}`)
  }
}

function ctxWarn(message) {
  process.stderr.write(`${message}\n`)
}

/* ================================================================== */
/* 回收站：删除先进这里，可恢复                                         */
/* ================================================================== */

/**
 * 回收站根目录。
 *
 * 为什么放在 $DSH_HOME 而不是工作区：工作区里的东西属于用户任务产物，
 * 插件自己的临时数据不该混进去。$DSH_HOME/trash 和 $DSH_HOME/sessions
 * 在同一个卷上，移动会话日志目录可以用 rename（O(1)，不复制字节）。
 */
function trashRoot() {
  const home = process.env.DSH_HOME
  if (typeof home !== 'string' || home.length === 0) return undefined
  return join(home, 'trash')
}

function newTrashId() {
  const d = new Date()
  const p = (n) => String(n).padStart(2, '0')
  const stamp = `${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}`
  return `${stamp}-${randomBytes(3).toString('hex')}`
}

/**
 * 移动一个路径，跨卷时退化成"复制 + 删源"。
 *
 * rename 只在同一卷内成立。会话日志一定和 trash 同卷（都在 $DSH_HOME 下），
 * 但对话文件夹在用户工作区，可能是另一个盘，所以必须有兜底。
 */
async function movePath(from, to) {
  try {
    await rename(from, to)
    return 'moved'
  } catch (error) {
    if (error?.code !== 'EXDEV' && error?.code !== 'EPERM' && error?.code !== 'EACCES') throw error
    await cp(from, to, { recursive: true, force: true })
    await rm(from, { recursive: true, force: true })
    return 'copied'
  }
}

/** 递归统计一个目录的字节数与文件数；不存在返回 {bytes:0, files:0}。 */
async function measure(dir) {
  const result = { bytes: 0, files: 0 }
  async function walk(current) {
    let entries
    try {
      entries = await readdir(current, { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries) {
      const path = join(current, entry.name)
      if (entry.isDirectory()) {
        await walk(path)
        continue
      }
      if (!entry.isFile()) continue
      try {
        const info = await stat(path)
        result.bytes += info.size
        result.files += 1
      } catch {
        // 统计不上就跳过，不让体检因为一个坏文件失败
      }
    }
  }
  await walk(dir)
  return result
}

/** 读一条回收站记录；损坏或缺失返回 undefined。 */
async function readTrashEntry(dir) {
  try {
    const raw = await readFile(join(dir, 'meta.json'), 'utf8')
    const meta = JSON.parse(raw)
    if (meta === null || typeof meta !== 'object') return undefined
    return meta
  } catch {
    return undefined
  }
}

/** 列出回收站全部条目，按删除时间倒序（最新在前）。 */
async function listTrash() {
  const root = trashRoot()
  if (root === undefined) return []
  let entries
  try {
    entries = await readdir(root, { withFileTypes: true })
  } catch {
    return []
  }
  const items = []
  for (const entry of entries) {
    if (!entry.isDirectory()) continue
    const dir = join(root, entry.name)
    const meta = await readTrashEntry(dir)
    if (meta === undefined) continue
    const size = await measure(dir)
    items.push({ ...meta, dir, bytes: size.bytes, files: size.files })
  }
  items.sort((a, b) => Number(b.deletedAt ?? 0) - Number(a.deletedAt ?? 0))
  return items
}

/* ================================================================== */
/* 备份目录：用户自己决定留还是删                                        */
/* ================================================================== */

function backupRoot() {
  const home = process.env.DSH_HOME
  if (typeof home !== 'string' || home.length === 0) return undefined
  return join(home, 'backups')
}

/** 备份目录的占用情况：条目数、总字节、最早/最新时间。 */
async function backupInfo() {
  const root = backupRoot()
  if (root === undefined) return { dir: '', exists: false, entries: 0, bytes: 0, oldest: null, newest: null }
  let entries
  try {
    entries = await readdir(root, { withFileTypes: true })
  } catch {
    return { dir: root, exists: false, entries: 0, bytes: 0, oldest: null, newest: null }
  }
  const size = await measure(root)
  let oldest = null
  let newest = null
  for (const entry of entries) {
    try {
      const info = await stat(join(root, entry.name))
      const time = info.mtimeMs
      if (oldest === null || time < oldest) oldest = time
      if (newest === null || time > newest) newest = time
    } catch {
      // 单个条目读不到不影响汇总
    }
  }
  return {
    dir: root,
    exists: true,
    entries: entries.length,
    bytes: size.bytes,
    files: size.files,
    oldest,
    newest,
  }
}

/** 打开一个目录（资源管理器）。宿主侧用 explorer，其它平台用系统默认打开器。 */
function openDirectory(path) {
  const platform = process.platform
  const command = platform === 'win32' ? 'explorer.exe' : platform === 'darwin' ? 'open' : 'xdg-open'
  try {
    const child = spawn(command, [path], { detached: true, stdio: 'ignore', windowsHide: false })
    child.on('error', () => {})
    child.unref()
    return true
  } catch {
    return false
  }
}

/**
 * 用系统默认程序打开一个**文件**。
 *
 * Windows 上用 `rundll32 url.dll,FileProtocolHandler` 而不是 `cmd /c start`：
 * 后者要把路径拼进命令行，路径里有 `&`、`^`、`(` 时会被 cmd 解释掉；
 * rundll32 的路径是作为独立 argv 传的，不经过 shell 解析，才不会被文件名坑到。
 */
function openFile(path) {
  const platform = process.platform
  const argv = platform === 'win32'
    ? ['rundll32.exe', ['url.dll,FileProtocolHandler', path]]
    : platform === 'darwin'
      ? ['open', [path]]
      : ['xdg-open', [path]]
  try {
    const child = spawn(argv[0], argv[1], { detached: true, stdio: 'ignore', windowsHide: false })
    child.on('error', () => {})
    child.unref()
    return true
  } catch {
    return false
  }
}

/** 在文件管理器里**定位并选中**一个文件（Windows 是 explorer /select，macOS 是 open -R）。 */
function revealFile(path) {
  const platform = process.platform
  const argv = platform === 'win32'
    ? ['explorer.exe', [`/select,${path}`]]
    : platform === 'darwin'
      ? ['open', ['-R', path]]
      : ['xdg-open', [dirname(path)]]
  try {
    const child = spawn(argv[0], argv[1], { detached: true, stdio: 'ignore', windowsHide: false })
    child.on('error', () => {})
    child.unref()
    return true
  } catch {
    return false
  }
}

/** 常见图片/文档 MIME → 扩展名。附件对象在磁盘上没有后缀，物化时要补一个。 */
const MEDIA_EXT = {
  'image/png': '.png',
  'image/jpeg': '.jpg',
  'image/gif': '.gif',
  'image/webp': '.webp',
  'image/svg+xml': '.svg',
  'image/bmp': '.bmp',
  'image/avif': '.avif',
  'application/pdf': '.pdf',
  'text/plain': '.txt',
  'text/markdown': '.md',
  'application/json': '.json',
}

/**
 * 在 DSH 的附件库里找一个内容对象。
 *
 * 三处可能的落点（都按 sha256 内容寻址）：
 *   - `attachments/v1/files/<p>/<digest>/<原文件名>`  ← 最理想，带原名和后缀
 *   - `attachments/v1/file-objects/<p>/<digest>`     ← 通用文件的原始字节
 *   - `attachments/v1/objects/<p>/<digest>`          ← 图片的原始字节（无后缀）
 * 浏览器里显示的那张图可能是服务端转码过的「请求版」，
 * 所以最后再去 `cache/attachments/request-images/` 兜一次。
 */
async function findAttachmentObject(sha) {
  const home = process.env.DSH_HOME
  if (typeof home !== 'string' || home.length === 0) return undefined
  if (!/^[0-9a-f]{64}$/i.test(sha)) return undefined
  const digest = sha.toLowerCase()
  const prefix = digest.slice(0, 2)
  const base = join(home, 'attachments', 'v1')

  // 1) 带原文件名的硬链接目录（打开/在文件夹中显示都最友好）
  const namedDir = join(base, 'files', prefix, digest)
  try {
    const names = await readdir(namedDir)
    if (names.length > 0) {
      const p = join(namedDir, names[0])
      const info = await stat(p)
      if (info.isFile()) return { path: p, hasExtension: true }
    }
  } catch {
    // 没有这个目录就继续往下找
  }

  // 2) 通用文件对象 / 3) 图片对象（都没有后缀）
  for (const p of [
    join(base, 'file-objects', prefix, digest),
    join(base, 'objects', prefix, digest),
  ]) {
    try {
      const info = await stat(p)
      if (info.isFile()) return { path: p, hasExtension: false }
    } catch {
      // 不是这里
    }
  }

  // 4) 转码缓存：文件名规则不完全等于 digest，按包含关系兜一次（只扫一层）
  const cacheDir = join(home, 'cache', 'attachments', 'request-images')
  try {
    for (const name of await readdir(cacheDir)) {
      if (!name.includes(digest)) continue
      const p = join(cacheDir, name)
      const info = await stat(p)
      if (info.isFile()) return { path: p, hasExtension: true }
    }
  } catch {
    // 没这个缓存目录
  }

  return undefined
}

/**
 * 把没有后缀的附件对象物化成「有名字、有后缀」的文件，好让系统能按类型打开。
 *
 * 为什么不直接打开对象本身：`attachments/v1/objects/68/6814...` 没有扩展名，
 * Windows 不知道用什么程序打开它，只会弹「你想如何打开此文件」。
 * 物化目录固定在插件自己的缓存下，重复打开复用同一份，不会越攒越多。
 */
async function materializeAttachment(source, name, mediaType) {
  const home = process.env.DSH_HOME
  if (typeof home !== 'string' || home.length === 0) return source
  const dir = join(home, 'cache', 'dsh-steward', 'attachments', basename(dirname(source)))
  let fileName = sanitize(String(name ?? '')).trim()
  if (fileName.length === 0) fileName = 'attachment'
  // 名字里已经没有后缀时，用 MIME 补一个
  if (!/\.[A-Za-z0-9]{1,10}$/.test(fileName)) {
    const ext = MEDIA_EXT[String(mediaType ?? '').toLowerCase()]
    if (ext !== undefined) fileName += ext
  }
  const target = join(dir, fileName)
  try {
    const [a, b] = await Promise.all([stat(source), stat(target).catch(() => undefined)])
    if (b !== undefined && b.size === a.size) return target
    await mkdir(dir, { recursive: true })
    await copyFile(source, target)
    return target
  } catch {
    return source
  }
}

/** 另存为：复制到目标目录，同名自动加序号，绝不覆盖用户已有文件。 */
async function saveCopyTo(source, targetDir) {
  const info = await stat(source)
  if (!info.isFile()) throw new Error('这个条目不是文件，无法另存')
  const name = basename(source)
  let target = resolve(targetDir, name)
  let counter = 1
  while (true) {
    try {
      await stat(target)
      const dot = name.lastIndexOf('.')
      const base = dot > 0 ? name.slice(0, dot) : name
      const ext = dot > 0 ? name.slice(dot) : ''
      target = resolve(targetDir, `${base} (${counter})${ext}`)
      counter += 1
    } catch {
      break
    }
  }
  await copyFile(source, target)
  return target
}

/**
 * 在工作目录下按**文件名**找一个文件。
 *
 * 为什么需要：对话里那个「交接日志.md」chip 只把**文件名**放在 DOM 的 title 上，
 * 完整路径在 React props 里拿不到。所以只能拿文件名回磁盘找。
 *
 * 三条克制：
 *  - 深度上限 4 层，别把整个盘扫一遍；
 *  - 跳过 node_modules / .git / 各类构建产物目录，它们既慢又不是用户想打开的；
 *  - 最多返回若干个候选，由调用方判断「唯一命中」才用 —— 同名文件多的时候
 *    宁可让用户改用别的方式，也不要猜错一个打开。
 */
const SEARCH_SKIP_DIRS = new Set([
  'node_modules', '.git', '.svn', '.hg', 'dist', 'build', 'out', 'target',
  '.next', '.nuxt', '.cache', '.venv', 'venv', '__pycache__', '.idea', '.vscode',
])

async function findFilesByName(root, name, limit = 8, maxDepth = 4) {
  const found = []
  const wanted = String(name).toLowerCase()
  const queue = [{ dir: root, depth: 0 }]
  let visited = 0

  while (queue.length > 0 && found.length < limit && visited < 4000) {
    const { dir, depth } = queue.shift()
    let entries
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch {
      continue
    }
    for (const entry of entries) {
      visited += 1
      if (visited >= 4000) break
      const full = join(dir, entry.name)
      if (entry.isDirectory()) {
        if (depth >= maxDepth) continue
        if (SEARCH_SKIP_DIRS.has(entry.name)) continue
        // 隐藏目录（.开头）通常是配置/缓存，不进去
        if (entry.name.startsWith('.')) continue
        queue.push({ dir: full, depth: depth + 1 })
        continue
      }
      if (entry.isFile() && entry.name.toLowerCase() === wanted) {
        found.push(full)
        if (found.length >= limit) break
      }
    }
  }
  return found
}

/** 插件自己的配置持久化文件（放在 $DSH_HOME，和会话记录分开）。 */
function configPath() {
  const home = process.env.DSH_HOME
  if (typeof home !== 'string' || home.length === 0) return undefined
  return join(home, 'chat-manager-config.json')
}

async function readConfigFile() {
  const file = configPath()
  if (file === undefined) return {}
  try {
    const raw = await readFile(file, 'utf8')
    const parsed = JSON.parse(raw)
    return parsed !== null && typeof parsed === 'object' ? parsed : {}
  } catch {
    return {}
  }
}

async function writeConfigFile(next) {
  const file = configPath()
  if (file === undefined) return
  try {
    await writeFile(file, JSON.stringify(next, null, 2), 'utf8')
  } catch (error) {
    ctxWarn(`dsh-steward: 无法保存配置: ${error?.message ?? error}`)
  }
}

export function apply(ctx, config) {
  // 运行守则：无论后面发生什么，先尝试把三原则写进全局 AGENTS.md。
  // 内部全部 try/catch，失败只会让守则不生效，不会影响插件其余功能。
  try {
    void (async () => {
      // 等用户设置加载完再决定，避免和文件里的开关打架
      const saved = await readConfigFile().catch(() => ({}))
      const flag = (saved.guardrails ?? {}).install
      // 只有**显式**为 true 才写。以前这里是 `!== false`，undefined 会被判成开启，
      // 于是"默认关闭"根本不起作用 —— 装完就往全局 AGENTS.md 里塞东西。
      const enabled = flag === true
      await installGuardrails(enabled)
    })().catch(() => {})
  } catch {
    // 忽略
  }

  const folder = folderConfig(config)
  const created = new Set()
  /** 会话 id → 本插件为它建好的绝对路径，删除对话时据此定位，避免猜测。 */
  const createdFolders = new Map()
  /** 会话 id → 上次写交接日志的时间，用来做节流，避免每个事件都重写整份文档。 */
  const logWritten = new Map()
  /** 设置页写入的覆盖值（文件里的），异步载入。 */
  let savedFolder = undefined
  let savedGuardrails = undefined
  let savedSessionLog = undefined

  // 异步载入持久登记表与用户设置；载入完成前的删除请求会走显式路径
  /**
   * 登记表就绪信号。
   *
   * 必须在 ensureFolder 里 await 它：loadRegistry 是异步的，而 session/created
   * 和第一条 user/message 可能早于它完成。不等待的话，ensureFolder 看到空表
   * 就会为已有会话再建一个目录 —— 又是一次重复。
   */
  const registryReady = loadRegistry().then((saved) => {
    for (const [id, path] of saved) {
      if (!createdFolders.has(id)) createdFolders.set(id, path)
    }
  }).catch(() => {})
  void registryReady
  void readConfigFile().then((saved) => {
    if (saved !== null && typeof saved === 'object') {
      if (saved.folder !== undefined) savedFolder = saved.folder
      if (saved.guardrails !== undefined) savedGuardrails = saved.guardrails
      if (saved.sessionLog !== undefined) savedSessionLog = saved.sessionLog
    }
  })

  /** 每次现读：设置页改了开关，这里要立刻看到新值，不能用启动时的快照。 */
  function currentFolder() {
    const fromConfig = folderConfig(config)
    // 配置文件优先（用户在设置页打开/关闭过），没有就用 patch/schema 的声明值
    return { ...fromConfig, ...(savedFolder ?? {}) }
  }

  /** 交接日志的生效配置，同样每次现读。 */
  function currentSessionLog() {
    const fromConfig = sessionLogConfig(config)
    return { ...fromConfig, ...(savedSessionLog ?? {}) }
  }

  /** 弱取一个宿主服务：未注入时 ctx.xxx 会直接抛错，ctx.get 才是安全的探测方式。 */
  function service(name) {
    try {
      return ctx.get?.(name) ?? undefined
    } catch {
      return undefined
    }
  }

  function baseDirectory(session) {
    try {
      const directory = service('workingDirectory')?.get?.(session)
      if (typeof directory === 'string' && directory.length > 0) return directory
    } catch {
      // 落到持久化 header 上
    }
    return session?.header?.cwd
  }

  /**
   * 为一个**新会话**建它自己的工作文件夹。
   *
   * 语义边界（用户明确要求）：
   *   - 一个「对话」= 侧边栏里的一行 = 一个 Session。
   *   - 同一个 Session 里的多轮消息**不**再建目录。
   *   - 目录建在**该会话自己的工作区目录**下，不是插件安装目录、也不是别的会话的目录。
   *
   * 去重必须跨进程重启有效：早先只用内存 Set 判断「建过了」，插件一重挂
   * （改代码后 disable/enable）Set 就空了，于是同一个会话又建一个新目录 ——
   * 这就是工作区里堆了十几个空 chat-* 目录的原因。
   * 现在以**持久登记表**为准：登记表里有这个 session id，就直接复用那条路径。
   */
  async function ensureFolder(session) {
    const id = session?.id
    if (id === undefined) return
    if (created.has(id)) return

    // 开关关着就什么都不做；监听常驻，打开开关后无需重挂插件即可生效
    const folder = currentFolder()
    if (folder.enabled !== true) return

    const header = session?.header
    // 子代理跟随父会话目录，不单独建
    if (header?.origin === 'subagent' || header?.parentSession !== undefined) return

    // 先查持久登记表：这个会话已经有自己的目录了，就不再建第二个
    await registryReady
    const known = createdFolders.get(id)
    if (known !== undefined && known.length > 0) {
      created.add(id)
      // 目录被人手动删掉时补建回同一路径，而不是另起一个新名字
      try {
        await mkdir(known, { recursive: true })
      } catch (error) {
        ctxWarn(`dsh-steward: 无法补建 ${known}: ${error?.message ?? error}`)
        return
      }
      // 老会话的目录是上个版本建的，里面还没有交接日志；这里补一份，
      // 否则升级后旧对话永远等不到它的第一份日志。
      void writeSessionLog(id, known).catch(() => {})
      return
    }

    const base = baseDirectory(session)
    if (typeof base !== 'string' || base.length === 0) return

    let title
    try {
      title = service('sessionTitle')?.get?.(session)?.title
    } catch {
      title = undefined
    }

    const baseResolved = resolve(base)
    const target = resolve(join(baseResolved, folderName(folder.template, id, title, new Date())))
    // 解析后必须仍在工作区内，否则拒绝
    if (target !== baseResolved && !target.startsWith(baseResolved + sep)) return

    // 先占位再 await，避免同一会话的并发事件（created + 第一条消息）各建一个
    created.add(id)

    try {
      await mkdir(target, { recursive: true })
      createdFolders.set(id, target)
      await saveRegistry(createdFolders)
    } catch (error) {
      ctxWarn(`dsh-steward: 无法创建 ${target}: ${error?.message ?? error}`)
      created.delete(id)
      return
    }

    // 目录刚建好就落一份交接日志：哪怕用户马上走开，文件夹里也有东西可读，
    // 不至于留下一个空目录让人猜"这里原本要放什么"。
    void writeSessionLog(id, target).catch(() => {})

    if (folder.useAsWorkingDirectory === true) {
      const agents = service('agents')
      const workingDirectory = service('workingDirectory')
      const agent = agents?.get?.(id)
      if (agent !== undefined && typeof workingDirectory?.set === 'function') {
        try {
          await workingDirectory.set(agent, target)
        } catch (error) {
          ctxWarn(`dsh-steward: 无法切换工作目录: ${error?.message ?? error}`)
        }
      }
    }
  }

  // 两个监听都常驻注册，是否建目录由 ensureFolder 每次现读开关决定，
  // 这样在设置页打开/关闭后立刻生效，不需要重新挂载插件。
  ctx.on('session/created', (session) => {
    if (currentFolder().trigger !== 'created') return
    void ensureFolder(session)
  })

  ctx.on('session/event', (session, event) => {
    if (currentFolder().trigger === 'created') return
    if (event?.type !== 'user/message') return
    void ensureFolder(session)
  })

  /* ------------------------------------------------------------------ */
  /* 一·六、交接日志的触发时机                                            */
  /* ------------------------------------------------------------------ */

  /** 写日志的最小间隔：一次轮次里可能有几十个事件，不能每个都重写整份文档。 */
  const SESSION_LOG_MIN_GAP_MS = 4000

  /**
   * 在轮次结束时刷新交接日志。
   *
   * 为什么挂在 `turn/end` 而不是每条消息：交接文档是"整份重写"，
   * 挂在每条消息上会让长对话的文件 IO 变得很重。一轮结束时写一次，
   * 既保证文档始终反映最新状态，又把写入次数压到轮次量级。
   */
  async function refreshSessionLog(session) {
    const cfg = currentSessionLog()
    if (cfg.enabled !== true) return

    const id = session?.id
    if (id === undefined) return

    await registryReady
    const folderPath = createdFolders.get(id)
    if (folderPath === undefined || folderPath.length === 0) return

    // 节流：同一会话 4 秒内只写一次
    const last = logWritten.get(id) ?? 0
    if (Date.now() - last < SESSION_LOG_MIN_GAP_MS) return

    await writeSessionLog(id, folderPath)
  }

  ctx.on('session/event', (session, event) => {
    if (event?.type !== 'turn/end') return
    void refreshSessionLog(session)
  })

  // 会话归档/结束时再补一次，保证"最后一条"不会因为节流被漏掉
  ctx.on('session/end-seed', (session) => {
    void refreshSessionLog(session)
  })

  /* ------------------------------------------------------------------ */
  /* 二、/chat-delete：删除对话                                          */
  /* ------------------------------------------------------------------ */

  function parseArgs(rawInput) {
    const tokens = String(rawInput ?? '').trim().split(/\s+/).filter(Boolean)
    const options = { sessionId: undefined, folderPath: undefined, deleteFolder: false, title: undefined }
    for (const token of tokens) {
      if (token === '--with-folder') options.deleteFolder = true
      else if (token.startsWith('--session=')) options.sessionId = token.slice('--session='.length)
      else if (token.startsWith('--folder=')) options.folderPath = token.slice('--folder='.length)
      else if (token.startsWith('--title64=')) {
        try {
          options.title = Buffer.from(token.slice('--title64='.length), 'base64').toString('utf8')
        } catch {
          options.title = undefined
        }
      }
    }
    return options
  }

  /**
   * 确定要删除的对话文件夹。
   *
   * 只接受两个可信来源，绝不猜测：
   *  1. 调用方显式传入的路径（客户端会先给用户看清楚）；
   *  2. 本插件建过的目录 —— 建目录时把 “会话 id → 绝对路径” 记在这张表里。
   *
   * 两者都没有就返回 undefined：宁可不删，也不误删别人的文件夹。
   */
  function resolveChatFolder(sessionId, explicitPath) {
    if (typeof explicitPath === 'string' && explicitPath.length > 0) return resolve(explicitPath)
    const known = createdFolders.get(sessionId)
    return known === undefined ? undefined : resolve(known)
  }

  /**
   * 删除一个对话 —— 进回收站，不直接抹掉。
   *
   * 顺序刻意固定：归档 → 通知界面移除 → **移动**日志目录进回收站
   * → 可选移动对话文件夹进回收站 → 写一条 meta.json。
   *
   * 为什么先移动再写 meta：移动是可能失败的那一步。先写 meta 而移动失败，
   * 回收站里就会留下一条指向不存在内容的记录，恢复时才发现是空的。
   */
  async function deleteConversation({ sessionId, deleteFolder, folderPath, title }) {
    const notes = []
    const root = trashRoot()
    if (root === undefined) {
      return { ok: false, text: '无法确定回收站位置：DSH_HOME 未设置' }
    }

    // 1) 归档：让它从侧边栏消失，并停掉正在跑的工作
    try {
      const registry = service('workspaceRegistry')
      if (registry === undefined || typeof registry.archiveSession !== 'function') {
        return { ok: false, text: '归档失败：归档服务不可用（workspaceRegistry）' }
      }
      await registry.archiveSession(sessionId, { stopActivity: true })
    } catch (error) {
      return { ok: false, text: `归档失败：${error?.message ?? error}` }
    }

    // 2) 先通知客户端移除这一行。
    //    侧边栏的行来自客户端缓存；sessions.refresh() 走 mergeOrderedBaseline，
    //    会把旧条目合并回来，光刷新移不掉。所以发官方移除事件：
    //    宿主 emit → 客户端 handleSessionRemoved → 该行立即消失（不必重启）。
    //    必须在移动文件之前发：事件按 session 资源做访问控制，记录还在时才送得出去。
    try {
      ctx.emit?.('api-session/removed', sessionId)
    } catch {
      // 发不出去时，下次启动仍会重建列表
    }

    // 3) 把会话日志目录移进回收站 —— 这是"删除"，但可恢复。
    const logDir = await findSessionLogDir(sessionId)
    if (logDir === undefined) {
      return {
        ok: false,
        text: `未找到该对话的记录目录（${logDirName(sessionId)}），已归档但记录仍在。`
          + `请确认 DSH_HOME 是否正确：${sessionsRoot() ?? '(未设置)'}`,
      }
    }

    const trashId = newTrashId()
    const entryDir = join(root, trashId)
    try {
      await mkdir(entryDir, { recursive: true })
      await movePath(logDir, join(entryDir, 'session'))
      notes.push('会话记录已移入回收站')
    } catch (error) {
      // 移动失败就清掉半成品目录，别留垃圾
      await rm(entryDir, { recursive: true, force: true }).catch(() => {})
      return { ok: false, text: `会话记录移入回收站失败：${error?.message ?? error}` }
    }

    // 记录已经不在原位了，归档集合里那条就是悬空 id：清掉它，
    // 否则每次启动都会带着一个指向空目录的归档记录。
    try {
      const registry = service('workspaceRegistry')
      if (typeof registry?.unarchiveSession === 'function') {
        await registry.unarchiveSession(sessionId)
      }
    } catch {
      // 清不掉也不影响删除结果
    }

    // 4) 可选：把该对话的文件夹也移进回收站（不是删除）
    let folderTrashed = false
    let folderOrigin
    if (deleteFolder === true) {
      const resolved = resolveChatFolder(sessionId, folderPath)
      if (resolved === undefined) {
        notes.push('不知道该对话的文件夹，未处理文件夹')
      } else {
        try {
          const info = await stat(resolved)
          if (!info.isDirectory()) {
            notes.push('目标不是文件夹，已跳过')
          } else {
            // 安全闸：拒绝盘符根、$DSH_HOME 本身、工作区目录本身这类目标
            const home = process.env.DSH_HOME ? resolve(process.env.DSH_HOME) : undefined
            const session = service('sessions')?.get?.(sessionId)
            const base = session !== undefined ? baseDirectory(session) : undefined
            const workspaceDir = typeof base === 'string' && base.length > 0 ? resolve(base) : undefined
            const tooShallow = dirname(resolved) === resolved
            const isWorkspaceRoot = workspaceDir !== undefined && resolved === workspaceDir
            if (tooShallow || isWorkspaceRoot || (home !== undefined && resolved === home)) {
              notes.push('目标路径过于宽泛，已拒绝处理')
            } else {
              await movePath(resolved, join(entryDir, 'folder'))
              createdFolders.delete(sessionId)
              void saveRegistry(createdFolders)
              folderTrashed = true
              folderOrigin = resolved
              notes.push('对话文件夹已移入回收站')
            }
          }
        } catch (error) {
          if (error?.code === 'ENOENT') notes.push('对话文件夹不存在，已跳过')
          else notes.push(`文件夹移入回收站失败：${error?.message ?? error}`)
        }
      }
    }

    // 5) 写元数据。这是回收站条目的唯一身份来源，写不进去就把内容退回去。
    const meta = {
      id: trashId,
      sessionId,
      title: typeof title === 'string' ? title : '',
      deletedAt: Date.now(),
      cwd: (() => {
        try {
          const session = service('sessions')?.get?.(sessionId)
          return session !== undefined ? baseDirectory(session) : undefined
        } catch {
          return undefined
        }
      })(),
      hasSession: true,
      hasFolder: folderTrashed,
      folderOrigin,
      logDirName: logDirName(sessionId),
      // 记下它原来所在的父目录：恢复时按原样放回，不靠猜工作区目录的转义规则
      logParent: dirname(logDir),
    }
    try {
      await writeFile(join(entryDir, 'meta.json'), JSON.stringify(meta, null, 2), 'utf8')
    } catch (error) {
      // 元数据写不进去，这条记录就永远无法恢复 —— 退回原位比留一条坏记录好
      try {
        await movePath(join(entryDir, 'session'), logDir)
        if (folderTrashed && folderOrigin !== undefined) {
          await movePath(join(entryDir, 'folder'), folderOrigin)
        }
        await rm(entryDir, { recursive: true, force: true })
      } catch {
        // 退不回去也没别的办法了，至少把原因报出来
      }
      return { ok: false, text: `回收站记录写入失败，已尽量退回：${error?.message ?? error}` }
    }

    return {
      ok: true,
      text: `对话已移入回收站（可恢复）：${notes.join('；')}`,
      trashId,
    }
  }

  /** 恢复一条回收站记录：会话日志回原位，文件夹回原路径。 */
  async function restoreTrash(trashId) {
    const root = trashRoot()
    if (root === undefined) return { ok: false, text: '无法确定回收站位置：DSH_HOME 未设置' }
    const entryDir = join(root, String(trashId))
    const meta = await readTrashEntry(entryDir)
    if (meta === undefined) return { ok: false, text: '回收站里没有这条记录' }

    const notes = []
    const sessionPart = join(entryDir, 'session')
    if (await exists(sessionPart)) {
      const target = await originalSessionDir(meta)
      if (target === undefined) return { ok: false, text: '无法确定会话记录的原位置' }
      try {
        await mkdir(dirname(target), { recursive: true })
        await movePath(sessionPart, target)
        notes.push('会话记录已恢复')
      } catch (error) {
        return { ok: false, text: `会话记录恢复失败：${error?.message ?? error}` }
      }
    }

    const folderPart = join(entryDir, 'folder')
    if (await exists(folderPart)) {
      const target = typeof meta.folderOrigin === 'string' && meta.folderOrigin.length > 0
        ? meta.folderOrigin
        : undefined
      if (target === undefined) {
        notes.push('文件夹原路径未知，内容留在回收站')
      } else {
        try {
          await mkdir(dirname(target), { recursive: true })
          await movePath(folderPart, target)
          notes.push('对话文件夹已恢复')
          if (typeof meta.sessionId === 'string') {
            createdFolders.set(meta.sessionId, resolve(target))
            void saveRegistry(createdFolders)
          }
        } catch (error) {
          notes.push(`文件夹恢复失败：${error?.message ?? error}`)
        }
      }
    }

    // 文件类条目：回收站里放的就是那个文件本身，直接搬回原路径
    if (meta.kind === 'file') {
      let names = []
      try {
        names = await readdir(entryDir)
      } catch {
        names = []
      }
      const payload = names.find((name) => name !== 'meta.json')
      const target = typeof meta.folderOrigin === 'string' ? meta.folderOrigin : undefined
      if (payload !== undefined && target !== undefined) {
        try {
          await mkdir(dirname(target), { recursive: true })
          await movePath(join(entryDir, payload), target)
          notes.push('文件已恢复')
        } catch (error) {
          return { ok: false, text: `文件恢复失败：${error?.message ?? error}` }
        }
      }
    }

    // 会话回来了，就别再归档它
    try {
      const registry = service('workspaceRegistry')
      if (typeof registry?.unarchiveSession === 'function' && typeof meta.sessionId === 'string') {
        await registry.unarchiveSession(meta.sessionId)
      }
    } catch {
      // 恢复本身已经成功，归档状态清不掉不影响
    }

    // 内容都搬走了，记录本身没用了
    await rm(entryDir, { recursive: true, force: true }).catch(() => {})
    return { ok: true, text: `已恢复：${notes.join('；') || '（记录为空）'}` }
  }

  /** 会话日志的"原位"：优先用删除时记下的工作区路径重建目录名。 */
  async function originalSessionDir(meta) {
    const root = sessionsRoot()
    if (root === undefined) return undefined
    const target = logDirName(meta.sessionId ?? '')
    // 删除时记录过它所在的父目录，直接用最准
    if (typeof meta.logParent === 'string' && meta.logParent.length > 0) {
      return join(meta.logParent, target)
    }
    // 没有父目录记录时，按工作区重建一次（和 DSH 自己的目录规则一致）
    const cwd = typeof meta.cwd === 'string' && meta.cwd.length > 0 ? resolve(meta.cwd) : undefined
    if (cwd !== undefined) {
      const escaped = cwd.replace(/[:\\/]+/g, (match) => (match.includes(':') ? match.replace(':', '') : '-'))
      return join(root, escaped, target)
    }
    return join(root, target)
  }

  /** 彻底删除一条回收站记录（不可恢复）。 */
  async function purgeTrash(trashId) {
    const root = trashRoot()
    if (root === undefined) return { ok: false, text: '无法确定回收站位置：DSH_HOME 未设置' }
    const entryDir = join(root, String(trashId))
    if (!(await exists(entryDir))) return { ok: false, text: '回收站里没有这条记录' }
    try {
      await rm(entryDir, { recursive: true, force: true })
      return { ok: true, text: '已彻底删除' }
    } catch (error) {
      return { ok: false, text: `彻底删除失败：${error?.message ?? error}` }
    }
  }

  /** 清空整个回收站。 */
  async function emptyTrash() {
    const root = trashRoot()
    if (root === undefined) return { ok: false, text: '无法确定回收站位置：DSH_HOME 未设置' }
    const items = await listTrash()
    let removed = 0
    for (const item of items) {
      try {
        await rm(item.dir, { recursive: true, force: true })
        removed += 1
      } catch {
        // 单个删不掉就继续，最后报总数
      }
    }
    return { ok: true, text: `已清空 ${removed} 条记录`, removed }
  }

  /** 清空备份目录（用户要求：不让备份长期占空间，但由用户自己按按钮）。 */
  async function clearBackups() {
    const root = backupRoot()
    if (root === undefined) return { ok: false, text: '无法确定备份目录：DSH_HOME 未设置' }
    const info = await backupInfo()
    try {
      await rm(root, { recursive: true, force: true })
      return { ok: true, text: `已清空备份目录（${info.entries} 项，${formatBytes(info.bytes)}）`, ...info }
    } catch (error) {
      return { ok: false, text: `清空备份失败：${error?.message ?? error}` }
    }
  }

  function formatBytes(bytes) {
    const n = Number(bytes ?? 0)
    if (!Number.isFinite(n) || n <= 0) return '0 B'
    const units = ['B', 'KB', 'MB', 'GB', 'TB']
    let value = n
    let unit = 0
    while (value >= 1024 && unit < units.length - 1) {
      value /= 1024
      unit += 1
    }
    return `${value < 10 && unit > 0 ? value.toFixed(1) : Math.round(value)} ${units[unit]}`
  }

  async function exists(path) {
    try {
      await stat(path)
      return true
    } catch {
      return false
    }
  }

  /* ------------------------------------------------------------------ */
  /* 三、命令：删除对话 / 查询对话文件夹                                  */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-delete',
      description: '删除一个对话：归档它，删除会话记录，并可同步删除对话文件夹。',
      handler: async (invocation) => {
        const options = parseArgs(invocation.rawInput)
        if (options.sessionId === undefined || options.sessionId.length === 0) {
          return { kind: 'error', text: '缺少 --session=<会话 id>' }
        }
        const result = await deleteConversation(options)
        return result.ok ? { kind: 'success', text: result.text } : { kind: 'error', text: result.text }
      },
    })
  }, 'dsh-steward: /chat-delete')

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-folder',
      description: '查询一个对话自己的文件夹路径（用于删除前确认）。',
      handler: (invocation) => {
        const options = parseArgs(invocation.rawInput)
        if (options.sessionId === undefined || options.sessionId.length === 0) {
          return { kind: 'error', text: '缺少 --session=<会话 id>' }
        }
        const folderPath = resolveChatFolder(options.sessionId, options.folderPath)
        return { kind: 'success', text: folderPath ?? '' }
      },
    })
  }, 'dsh-steward: /chat-folder')

  /* ------------------------------------------------------------------ */
  /* 四、/chat-config：设置页读写                                        */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
﻿      name: 'chat-config',
      description: '读取或修改设置（对话文件夹、运行守则）。',
      handler: async (invocation) => {
        const raw = String(invocation.rawInput ?? '').trim()
        const saved = await readConfigFile()

        // getall：给设置页一次拿走全部开关状态
        if (raw === 'getall') {
          const folder = { ...folderConfig(config), ...(saved.folder ?? {}) }
          const guard = (saved.guardrails ?? {}).install
          const sessionLog = { ...sessionLogConfig(config), ...(saved.sessionLog ?? {}) }
          return {
            kind: 'success',
            text: JSON.stringify({
              folder: folder.enabled === true,
              // 默认关闭：只有用户显式打开过才是 true
              guardrails: guard === true,
              sessionLog: sessionLog.enabled === true,
            }),
          }
        }

        if (raw === '' || raw === 'get') {
          const folder = { ...folderConfig(config), ...(saved.folder ?? {}) }
          return { kind: 'success', text: String(folder.enabled === true) }
        }

        // folder.enabled=true|false  guardrails.enabled=true|false  sessionLog.enabled=true|false
        const match = /^(folder|guardrails|sessionLog)\.enabled\s*=\s*(true|false)$/i.exec(raw)
        if (match === null) {
          return {
            kind: 'error',
            text: '用法：/chat-config get | getall | folder.enabled=true|false | guardrails.enabled=true|false | sessionLog.enabled=true|false',
          }
        }

        const which = match[1].toLowerCase()
        const value = match[2].toLowerCase() === 'true'
        const next = which === 'folder'
          ? { ...saved, folder: { ...(saved.folder ?? {}), enabled: value } }
          : which === 'guardrails'
            ? { ...saved, guardrails: { ...(saved.guardrails ?? {}), install: value } }
            : { ...saved, sessionLog: { ...(saved.sessionLog ?? {}), enabled: value } }

        await writeConfigFile(next)
        if (which === 'folder') savedFolder = next.folder
        else if (which === 'guardrails') savedGuardrails = next.guardrails
        else savedSessionLog = next.sessionLog

        // 打开守则时立刻写一遍，不必等下次启动
        if (which === 'guardrails' && value === true) {
          try {
            await installGuardrails(true)
          } catch {
            // 写不进去不影响设置保存
          }
        }

        return { kind: 'success', text: String(value) }
      },
    })
  }, 'dsh-steward: /chat-config')

  /* ------------------------------------------------------------------ */
  /* 四·五、/chat-session-log：手动导出某个对话的交接日志                  */
  /* ------------------------------------------------------------------ */

  /**
   * 为什么要有手动命令：自动导出只在「建目录时」和「轮次结束」触发，
   * 而用户可能想把一个**历史对话**（早于本功能、或当时开关是关的）
   * 也导出成交接文档。手动命令补的就是这个缺口。
   */
  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-session-log',
      description: '把某个对话的日志导出成「交接日志.md」，放进它的对话文件夹。',
      handler: async (invocation) => {
        const tokens = String(invocation.rawInput ?? '').trim().split(/\s+/).filter(Boolean)
        let sessionId
        let explicitFolder
        let force = false
        for (const token of tokens) {
          if (token === '--force') force = true
          else if (token.startsWith('--session=')) sessionId = token.slice('--session='.length)
          else if (token.startsWith('--folder64=')) {
            try {
              explicitFolder = Buffer.from(token.slice('--folder64='.length), 'base64').toString('utf8')
            } catch {
              explicitFolder = undefined
            }
          } else if (token.startsWith('--folder=')) explicitFolder = token.slice('--folder='.length)
        }

        if (sessionId === undefined) return { kind: 'error', text: '缺少 --session=<会话 id>' }

        await registryReady
        const folderPath = resolveChatFolder(sessionId, explicitFolder)
        if (folderPath === undefined) {
          return { kind: 'error', text: '这个对话还没有自己的文件夹，先打开「每个新对话一个文件夹」或指定 --folder=' }
        }

        const cfg = currentSessionLog()
        if (cfg.enabled !== true && force !== true) {
          return { kind: 'error', text: '交接日志开关是关的；加 --force 可强制导出一次' }
        }

        // 手动导出时绕过节流，用户点了就要立刻看到结果
        logWritten.delete(sessionId)
        await writeSessionLog(sessionId, folderPath)
        const written = logWritten.get(sessionId)

        if (written === undefined) {
          return { kind: 'error', text: `导出失败，请查看插件日志（目标目录：${folderPath}）` }
        }
        return { kind: 'success', text: join(folderPath, '交接日志.md') }
      },
    })
  }, 'dsh-steward: /chat-session-log')

  /* ------------------------------------------------------------------ */
  /* 四·六、/chat-attachment：图片与附件的「打开 / 定位 / 另存为」        */
  /* ------------------------------------------------------------------ */

  /**
   * 为什么需要这条命令：
   *
   * 对话里的图片是浏览器里的 blob: URL，文档是 DSH 附件库里的内容对象，
   * 两者都没有「用户可见的磁盘路径」。浏览器又碰不到文件系统，
   * 所以「打开图片 / 打开它所在的文件夹」必须由宿主来做。
   *
   * 传递方式上刻意**不传图片字节**：
   * 命令会原样记进会话日志，把 80KB 的 base64 塞进去会污染对话、也慢。
   * 改成客户端算 sha256（WebCrypto，64 个字符），宿主按内容寻址去附件库里找 —— 
   * DSH 的附件按 sha256 存，哈希就是天然的主键。
   */
  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-attachment',
      description: '打开对话里的图片/附件，或定位它所在的文件夹。',
      handler: async (invocation) => {
        const tokens = String(invocation.rawInput ?? '').trim().split(/\s+/).filter(Boolean)
        const options = { op: 'open', sha: undefined, path: undefined, name: undefined, media: undefined, targetDir: undefined, sessionId: undefined, search: false }
        // 同名多份时的补充说明（在路径分支里赋值，在 probe 里回给客户端）。
        // 提到这个作用域是因为它跨越了「定位来源」和「返回结果」两段。
        let othersNote = ''
        const decode = (v) => {
          try {
            return Buffer.from(v, 'base64').toString('utf8')
          } catch {
            return undefined
          }
        }
        for (const token of tokens) {
          if (token.startsWith('--op=')) options.op = token.slice(5).toLowerCase()
          else if (token.startsWith('--sha=')) options.sha = token.slice(6).trim()
          else if (token.startsWith('--path64=')) options.path = decode(token.slice(9))
          else if (token.startsWith('--name64=')) options.name = decode(token.slice(9))
          else if (token.startsWith('--media64=')) options.media = decode(token.slice(10))
          else if (token.startsWith('--target64=')) options.targetDir = decode(token.slice(11))
          else if (token.startsWith('--session=')) options.sessionId = token.slice(10)
          else if (token === '--search') options.search = true
        }

        if (!['open', 'reveal', 'saveas', 'probe'].includes(options.op)) {
          return { kind: 'error', text: '用法：--op=open|reveal|saveas|probe，来源用 --sha=<sha256> 或 --path64=<base64 路径>' }
        }

        // 1) 定位来源
        let source
        if (typeof options.sha === 'string' && options.sha.length > 0) {
          const found = await findAttachmentObject(options.sha)
          if (found === undefined) {
            return {
              kind: 'error',
              text: '在附件库里找不到这张图片（可能只是本地预览，还没随消息发出去）',
            }
          }
          // 没有后缀的对象先物化，否则系统不知道用什么程序打开
          source = found.hasExtension
            ? found.path
            : await materializeAttachment(found.path, options.name, options.media)
        } else if (typeof options.path === 'string' && options.path.length > 0) {
          let candidate = options.path.trim().replace(/^@/, '').replace(/^["']|["']$/g, '')
          if (!isAbsolute(candidate)) {
            const base = await sessionBaseDirectory(options.sessionId)
            if (base === undefined) return { kind: 'error', text: '相对路径需要一个会话工作目录，请带上 --session=' }
            candidate = resolve(base, candidate)
          } else {
            candidate = resolve(candidate)
          }
          let exists = true
          try {
            await stat(candidate)
          } catch {
            exists = false
          }
          // --search：按文件名在工作目录里找。
          //
          // 专供对话里那个「@引用」chip —— 它 DOM 上只有文件名，没有完整路径。
          // 这里刻意**不先看 candidate 是否存在**：`@交接日志.md` 到底指根目录那份
          // 还是 docs 里那份，光看文件名无从判断，先命中根目录反而是更可能错的那个。
          // 所以统一走搜索；命中多份时取最浅的，并把其余候选记下来告诉用户。
          if (options.search === true) {
            const base = await sessionBaseDirectory(options.sessionId)
            if (base === undefined) return { kind: 'error', text: `这个路径不存在：${candidate}` }
            const hits = await findFilesByName(base, basename(candidate))
            if (hits.length === 0) {
              return { kind: 'error', text: `在工作目录里找不到「${basename(candidate)}」` }
            }
            if (hits.length > 1) {
              // 多份同名：取**路径最短**的那份（层级最浅）。
              //
              // 依据是 DSH 自己的语义：chip 的 path 相对会话 cwd，
              // `@交接日志.md` 指的就是 cwd 下那一份；只有用户当初写 `@docs/x.md`
              // 时 label 才丢掉目录，那种情况浅层优先也最接近原意。
              // 不静默：把「还有几份同名」记下来，动作完成后一并告诉用户。
              const sorted = hits.slice().sort((a, b) => a.length - b.length || a.localeCompare(b))
              candidate = sorted[0]
              othersNote = `还有 ${sorted.length - 1} 个同名文件：${sorted.slice(1).join('、')}`
            } else {
              candidate = hits[0]
            }
          } else if (!exists) {
            return { kind: 'error', text: `这个路径不存在：${candidate}` }
          }
          source = candidate
        } else {
          return { kind: 'error', text: '缺少来源：--sha=<sha256> 或 --path64=<base64 路径>' }
        }

        const info = await stat(source).catch(() => undefined)
        if (info === undefined) return { kind: 'error', text: `读不到这个文件：${source}` }

        if (options.op === 'probe') {
          return {
            kind: 'success',
            text: JSON.stringify({
              path: source,
              isDirectory: info.isDirectory(),
              size: info.size,
              // 同名多份时的提示，客户端会显示在菜单里，让用户知道开的是哪一个
              ...(othersNote.length > 0 ? { note: othersNote } : {}),
            }),
          }
        }

        if (options.op === 'saveas') {
          if (typeof options.targetDir !== 'string' || options.targetDir.length === 0) {
            return { kind: 'error', text: '缺少 --target64=<目标目录>' }
          }
          try {
            return { kind: 'success', text: await saveCopyTo(source, options.targetDir) }
          } catch (error) {
            return { kind: 'error', text: `另存为失败：${error?.message ?? error}` }
          }
        }

        if (options.op === 'reveal') {
          if (info.isDirectory()) {
            openDirectory(source)
            return { kind: 'success', text: source }
          }
          revealFile(source)
          return { kind: 'success', text: source }
        }

        // op=open
        if (info.isDirectory()) {
          openDirectory(source)
          return { kind: 'success', text: source }
        }
        openFile(source)
        return { kind: 'success', text: source }
      },
    })
  }, 'dsh-steward: /chat-attachment')

  /**
   * 会话的工作目录：优先问 workingDirectory 服务，退到持久化 header。
   * 相对路径（`docs/PRD.md`）要靠它拼成绝对路径。
   */
  async function sessionBaseDirectory(sessionId) {
    if (typeof sessionId !== 'string' || sessionId.length === 0) return undefined
    try {
      const session = service('sessions')?.get?.(sessionId)
      if (session !== undefined) {
        const fromService = baseDirectory(session)
        if (typeof fromService === 'string' && fromService.length > 0) return fromService
      }
    } catch {
      // 落到会话头
    }
    try {
      const controller = service('sessionController')
      if (controller !== undefined && typeof controller.inspect === 'function') {
        const inspection = await controller.inspect(sessionId)
        const cwd = inspection?.meta?.cwd
        if (typeof cwd === 'string' && cwd.length > 0) return cwd
      }
    } catch {
      // 没辙了
    }
    return undefined
  }

  /* ------------------------------------------------------------------ */
  /* 五、/chat-file：把交付物坐标解析成真实路径，并执行文件动作          */
  /* ------------------------------------------------------------------ */

  /* ------------------------------------------------------------------ */
  /* 一·五、交接日志：把会话日志导出成可读的 Markdown                     */
  /* ------------------------------------------------------------------ */

  /**
   * 清掉混在用户消息里的系统注入内容。
   *
   * 为什么必须清：DSH 每轮都会把 `<system-reminder>`（内含 AGENTS.md 全文）
   * 拼进用户消息。实测一份 1.2 万条事件的对话里，这类内容占了 **48%** 的篇幅，
   * 而且同一份守则重复上千遍 —— 交接文档会从"能读"变成"没法读"。
   * 这里只保留人真正说过的话。
   */
  function stripInjected(text) {
    if (typeof text !== 'string' || text.length === 0) return ''
    let out = text
    // system-reminder 整块（含未闭合的残缺块）
    out = out.replace(/<system-reminder>[\s\S]*?<\/system-reminder>/gi, '')
    out = out.replace(/<system-reminder>[\s\S]*$/gi, '')
    // 有些版本用 guardrails / instructions 包裹
    out = out.replace(/<!--\s*guardrails:begin[\s\S]*?guardrails:end\s*-->/gi, '')
    out = out.replace(/<!--\s*dsh-steward:begin[\s\S]*?dsh-steward:end\s*-->/gi, '')
    // 行内残留的标签
    out = out.replace(/<\/?(?:system-reminder|instructions)>/gi, '')
    // 运行时快照：每次请求都会附一段 "Current runtime context..."（工作目录、沙箱策略、
    // GUI 端口）。实测这类块永远独占一个 text block 且从该行开始，
    // 所以只在**整块开头**命中时才整段丢弃 —— 万一用户真的在正文里提到这句话，不会被误删。
    if (/^\s*Current runtime context\b/i.test(out)) return ''
    // 同类注入：时间/时区补丁。它们和用户的话拼在同一个 block 里，
    // 只能按行剔除（这些句子不可能出自用户之口）。
    out = out
      .replace(/^.*Time sampled while preparing turn\b.*$/gim, '')
      .replace(/^.*Browser time zone for this request:.*$/gim, '')
      .replace(/^.*Elapsed since the preceding (?:step context|model-visible message):.*$/gim, '')
    return out.replace(/\n{3,}/g, '\n\n').trim()
  }

  /**
   * 把 `data.content` 数组拍平成纯文本。
   *
   * 为什么不用现成的渲染：日志里可能混着文本、图片、文件引用、工具结果，
   * 交接时人只想读文字。这里只挑 text 段，其余用一行占位符带过，
   * 既保留"这里原本有什么"的信息，又不把 base64 之类塞进文档。
   */
  function flattenContent(content) {
    if (typeof content === 'string') return stripInjected(content)
    if (!Array.isArray(content)) return ''
    const parts = []
    for (const block of content) {
      if (block === null || typeof block !== 'object') continue
      if (block.type === 'text' && typeof block.text === 'string') {
        parts.push(stripInjected(block.text))
      } else if (block.type === 'image') {
        parts.push('_[图片]_')
      } else if (block.type === 'file' || block.type === 'attachment') {
        const name = block.path ?? block.name ?? block.fileName
        parts.push(`_[附件：${typeof name === 'string' ? name : '未命名'}]_`)
      } else if (typeof block.text === 'string') {
        // 兜底：有些块带 text 但 type 不叫 text
        parts.push(stripInjected(block.text))
      }
    }
    return parts.filter((p) => p.length > 0).join('\n').trim()
  }

  /** 把一条工具调用压成一行，避免日志被 JSON 淹没。 */
  function describeToolCall(event) {
    const data = event?.data ?? {}
    const name = data.name ?? data.toolName ?? data.tool ?? '工具'
    const callId = data.callId ?? data.id ?? ''
    let args = data.arguments ?? data.args ?? data.input
    if (typeof args === 'string') {
      try { args = JSON.parse(args) } catch { /* 保持原样 */ }
    }
    let brief = ''
    if (args !== null && typeof args === 'object') {
      // 挑最像"在做什么"的字段，别把整个参数倒出来
      const pick = args.path ?? args.file_path ?? args.command ?? args.query ?? args.pattern ?? args.url
      if (typeof pick === 'string') brief = pick.length > 160 ? pick.slice(0, 160) + '…' : pick
      else {
        const json = JSON.stringify(args)
        brief = json.length > 160 ? json.slice(0, 160) + '…' : json
      }
    } else if (typeof args === 'string') {
      brief = args.length > 160 ? args.slice(0, 160) + '…' : args
    }
    // 多行命令/JSON 压成一行：日志里一条工具只占一行，否则 markdown 列表会被撑散
    brief = brief.replace(/\s+/g, ' ').trim()
    return { name: String(name), callId: String(callId), brief }
  }

  /**
   * 工具结果压成一行：成功/失败 + 前若干字符。
   *
   * 注意：会话日志里的 tool/result 不是平铺的，真实形状是
   *   { data: { turn, step, message: { role:'tool', toolCallId, source:{callId},
   *            content:[{type:'text',text}], isError } } }
   * 所以 callId / isError / 正文都得从 data.message 里取，
   * 只读 data.callId 会全部落空（表现为日志里每条工具都写"未返回"）。
   */
  function describeToolResult(event) {
    const data = event?.data ?? {}
    const message = data.message ?? {}
    const callId = String(
      message.toolCallId ?? message.source?.callId ?? data.callId ?? data.id ?? '',
    )
    const failed = message.isError === true || data.isError === true
      || message.error !== undefined || data.error !== undefined
    let text = ''
    if (Array.isArray(message.content)) text = flattenContent(message.content)
    else if (typeof message.content === 'string') text = message.content
    else if (typeof data.result === 'string') text = data.result
    else if (typeof data.output === 'string') text = data.output
    else if (typeof data.text === 'string') text = data.text
    else if (Array.isArray(data.content)) text = flattenContent(data.content)
    else if (data.result !== undefined) {
      try { text = JSON.stringify(data.result) } catch { text = '' }
    }
    const err = message.error ?? data.error
    if (typeof err === 'string') text = err
    else if (err !== undefined && text.length === 0) {
      try { text = JSON.stringify(err) } catch { text = '' }
    }
    const flat = text.replace(/\s+/g, ' ').trim()
    return {
      callId,
      failed,
      brief: flat.length > 200 ? flat.slice(0, 200) + '…' : flat,
    }
  }

  function formatClock(ms) {
    const n = Number(ms)
    if (!Number.isFinite(n) || n <= 0) return ''
    try {
      return new Date(n).toLocaleString('zh-CN', { hour12: false })
    } catch {
      return ''
    }
  }

  /**
   * 单条消息的字符上限。
   *
   * 为什么要截：长对话里单条助手回复可能上万字（含大段代码），
   * 全量保留会让交接文档膨胀到几 MB，反而没人读。
   * 交接需要的是"这段在讲什么"，不是逐字复现 —— 超长时保留头尾。
   */
  const MESSAGE_CHAR_LIMIT = 4000

  function clipMessage(text, limit) {
    const max = Number.isFinite(limit) && limit > 0 ? limit : MESSAGE_CHAR_LIMIT
    if (typeof text !== 'string') return ''
    if (text.length <= max) return text
    // 头尾各留一半：开头交代意图，结尾常有结论
    const half = Math.floor((max - 60) / 2)
    const omitted = text.length - half * 2
    return `${text.slice(0, half)}\n\n_……（此处省略 ${omitted} 字）……_\n\n${text.slice(-half)}`
  }

  /**
   * 把会话事件渲染成一份「交接日志.md」。
   *
   * 目标读者是**接手的人**（也可能是几天后的自己），所以：
   *   - 开头给一段概览：会话 id、工作目录、模型、起止时间、消息数
   *   - 正文按轮次推进：用户说了什么、助手回了什么、调了哪些工具
   *   - 工具调用压成单行，避免正文被参数淹没
   *   - 结尾附上本次会话产生的文件（交付物），交接时最需要这个
   */
  function renderSessionLog({ sessionId, title, events, meta, options }) {
    const cfg = options ?? {}
    const includeTools = cfg.includeTools !== false
    const limit = Number.isFinite(cfg.maxMessages) ? cfg.maxMessages : 2000

    const head = events.find((e) => e?.type === 'session')
    const createdAt = head?.createdAt ?? meta?.createdAt
    const cwd = head?.cwd ?? meta?.cwd ?? ''

    // 收集消息（保持原有顺序），工具事件按 callId 挂到对应的调用上。
    // 少数历史会话的 tool/result 不带 callId，这时按出现顺序兜底配对，
    // 总比在日志里写一片"未返回"要好。
    const rows = []
    const toolResults = new Map()
    const orphanResults = []
    for (const event of events) {
      if (event?.type === 'tool/result') {
        const r = describeToolResult(event)
        if (r.callId.length > 0) toolResults.set(r.callId, r)
        else orphanResults.push(r)
      }
    }

    for (const event of events) {
      const type = event?.type
      if (type === 'user/message') {
        const text = flattenContent(event.data?.content ?? event.data?.message?.content)
        if (text.length > 0) rows.push({ kind: 'user', time: event.time, text })
      } else if (type === 'assistant/message') {
        const message = event.data?.message ?? event.data
        const text = flattenContent(message?.content)
        const model = message?.source?.model ?? event.data?.model
        if (text.length > 0) rows.push({ kind: 'assistant', time: event.time, text, model })
      } else if (type === 'tool/call' && includeTools) {
        const call = describeToolCall(event)
        const result = toolResults.get(call.callId) ?? orphanResults.shift()
        rows.push({ kind: 'tool', time: event.time, call, result })
      } else if (type === 'compaction/summary') {
        const text = flattenContent(event.data?.content ?? event.data?.summary)
        if (text.length > 0) rows.push({ kind: 'note', time: event.time, text: `（上下文已压缩）\n${text}` })
      } else if (type === 'deliverables/presented') {
        const files = Array.isArray(event.data?.files) ? event.data.files
          : Array.isArray(event.data?.presented) ? event.data.presented : []
        for (const f of files) {
          if (typeof f?.path === 'string') rows.push({ kind: 'file', time: event.time, path: f.path, description: f.description })
        }
      }
    }

    // 超限时保留最近的 N 条消息（工具行不占额度，否则长任务会把对话挤掉）
    let kept = rows
    let dropped = 0
    if (limit > 0) {
      const talk = rows.filter((r) => r.kind === 'user' || r.kind === 'assistant')
      if (talk.length > limit) {
        const cutoff = talk[talk.length - limit]
        const at = rows.indexOf(cutoff)
        dropped = talk.length - limit
        kept = rows.slice(at)
      }
    }

    const lines = []
    lines.push(`# 交接日志 · ${title ?? sessionId}`)
    lines.push('')
    lines.push('> 本文件由 dsh-steward 自动生成，随对话推进而更新。')
    lines.push('> 用途：把当前对话的任务状态交给别人（或未来的自己）接手。')
    lines.push('')
    lines.push('## 概览')
    lines.push('')
    lines.push('| 项目 | 值 |')
    lines.push('| --- | --- |')
    lines.push(`| 会话 ID | \`${sessionId}\` |`)
    if (typeof title === 'string' && title.length > 0) lines.push(`| 标题 | ${title} |`)
    lines.push(`| 工作目录 | \`${cwd}\` |`)
    if (createdAt !== undefined) lines.push(`| 创建时间 | ${formatClock(createdAt)} |`)
    lines.push(`| 导出时间 | ${formatClock(Date.now())} |`)
    const userCount = rows.filter((r) => r.kind === 'user').length
    const assistantCount = rows.filter((r) => r.kind === 'assistant').length
    const toolCount = rows.filter((r) => r.kind === 'tool').length
    lines.push(`| 消息数 | 用户 ${userCount} / 助手 ${assistantCount}${includeTools ? ` / 工具 ${toolCount}` : ''} |`)
    if (dropped > 0) lines.push(`| 已省略 | 较早的 ${dropped} 条消息（超出上限 ${limit}） |`)
    lines.push('')

    // 交付物单独列一节：交接时最需要知道"这次产出了什么"
    const produced = rows.filter((r) => r.kind === 'file')
    if (produced.length > 0) {
      lines.push('## 产出的文件')
      lines.push('')
      const seen = new Set()
      for (const f of produced) {
        if (seen.has(f.path)) continue
        seen.add(f.path)
        const desc = typeof f.description === 'string' && f.description.length > 0 ? ` — ${f.description}` : ''
        lines.push(`- \`${f.path}\`${desc}`)
      }
      lines.push('')
    }

    lines.push('## 对话记录')
    lines.push('')

    let turn = 0
    let clippedChars = 0
    const clip = (text) => {
      const out = clipMessage(text, MESSAGE_CHAR_LIMIT)
      if (out.length < text.length) clippedChars += text.length - out.length
      return out
    }
    for (const row of kept) {
      if (row.kind === 'user') {
        turn += 1
        lines.push(`### ${turn}. 用户`)
        lines.push('')
        if (row.time !== undefined) lines.push(`_${formatClock(row.time)}_`)
        lines.push('')
        lines.push(clip(row.text))
        lines.push('')
      } else if (row.kind === 'assistant') {
        lines.push('**助手**' + (typeof row.model === 'string' ? `（${row.model}）` : ''))
        lines.push('')
        lines.push(clip(row.text))
        lines.push('')
      } else if (row.kind === 'tool') {
        const status = row.result === undefined ? '未返回' : row.result.failed ? '失败' : '完成'
        const brief = row.call.brief.length > 0 ? ` · ${row.call.brief}` : ''
        lines.push(`- \`${row.call.name}\` [${status}]${brief}`)
        if (row.result !== undefined && row.result.brief.length > 0 && row.result.failed) {
          lines.push(`  - 错误：${row.result.brief}`)
        }
      } else if (row.kind === 'note') {
        lines.push('---')
        lines.push('')
        lines.push(row.text)
        lines.push('')
        lines.push('---')
        lines.push('')
      } else if (row.kind === 'file') {
        lines.push(`- 产出：\`${row.path}\``)
      }
    }

    if (kept.length === 0) {
      lines.push('_（这个对话还没有可记录的内容）_')
      lines.push('')
    } else if (clippedChars > 0) {
      lines.push('---')
      lines.push('')
      lines.push(`_部分消息过长已截断，共省略约 ${clippedChars} 字。完整原文见 \`$DSH_HOME/sessions/\`。_`)
      lines.push('')
    }

    return lines.join('\n')
  }

  /**
   * 没标题时的兜底：拿第一条"真正有内容"的用户消息当标题。
   *
   * 为什么不能用 events[0]：第一段往往只有 `<system-reminder>`（注入的守则全文），
   * 剥掉之后是空的；也可能只有一句「你好」。所以取第一条剥完还剩 4 个字以上的。
   */
  function deriveTitle(events, fallback) {
    for (const event of events) {
      if (event?.type !== 'user/message') continue
      const text = flattenContent(event.data?.content ?? event.data?.message?.content)
      const flat = text.replace(/\s+/g, ' ').trim()
      if (flat.length < 4) continue
      return flat.length > 40 ? `${flat.slice(0, 40)}…` : flat
    }
    return fallback
  }

  /**
   * 把某个会话的日志写进它的对话文件夹。
   *
   * 为什么不做成"每次事件都追加"：会话日志是**多帧 zstd 压缩**的追加式文件，
   * 增量解析容易和写入竞态。这里改成"整份重新生成、原子覆盖"，
   * 每次轮次结束重写一次，代价可控、结果永远自洽。
   */
  async function writeSessionLog(sessionId, folderPath) {
    const cfg = currentSessionLog()
    if (cfg.enabled !== true) return
    if (typeof folderPath !== 'string' || folderPath.length === 0) return

    const controller = service('sessionController')
    if (controller === undefined || typeof controller.inspect !== 'function') return

    let inspection
    try {
      inspection = await controller.inspect(sessionId)
    } catch (error) {
      ctxWarn(`dsh-steward: 读取会话日志失败（${sessionId}）：${error?.message ?? error}`)
      return
    }
    const events = Array.isArray(inspection?.events) ? inspection.events : []
    if (events.length === 0) return

    let title
    try {
      const session = service('sessions')?.get?.(sessionId)
      title = service('sessionTitle')?.get?.(session)?.title
    } catch {
      title = undefined
    }
    // 没有标题时退回"第一条用户消息"，比在文档头上写一串会话 id 好认得多。
    if (typeof title !== 'string' || title.trim().length === 0) {
      title = deriveTitle(events, sessionId)
    }

    let markdown
    try {
      markdown = renderSessionLog({
        sessionId,
        title,
        events,
        meta: inspection?.meta,
        options: cfg,
      })
    } catch (error) {
      ctxWarn(`dsh-steward: 生成交接日志失败（${sessionId}）：${error?.message ?? error}`)
      return
    }

    const target = join(folderPath, '交接日志.md')
    // 先写临时文件再改名：避免写到一半崩溃留下半截文档
    const temp = `${target}.tmp`
    try {
      // 目录可能被人手动删掉，或 --folder= 指到一个还不存在的路径；
      // 这里补一次 mkdir，否则 writeFile 直接 ENOENT，日志永远写不出来。
      await mkdir(folderPath, { recursive: true })
      await writeFile(temp, markdown, 'utf8')
      await rename(temp, target)
      logWritten.set(sessionId, Date.now())
    } catch (error) {
      ctxWarn(`dsh-steward: 写入交接日志失败（${target}）：${error?.message ?? error}`)
      await rm(temp, { force: true }).catch(() => {})
    }
  }

  /**
   * 从会话事件里找出某个交付物文件。
   *
   * 界面上的文件行只有 (sessionId, seq, index) 这组授权坐标，没有路径；
   * 「复制路径」「另存为」都需要真实路径，所以按坐标回到事件里取。
   */
  async function resolvePresentedFile(sessionId, seq, index) {
    const controller = service('sessionController')
    if (controller === undefined || typeof controller.inspect !== 'function') return undefined
    const inspection = await controller.inspect(sessionId)
    const events = Array.isArray(inspection?.events) ? inspection.events : []

    const session = service('sessions')?.get?.(sessionId)
    const base = session !== undefined ? baseDirectory(session) : inspection?.meta?.cwd

    for (const event of events) {
      if (event?.seq !== seq) continue
      const data = event.data
      if (data === null || typeof data !== 'object') continue

      const files = Array.isArray(data.files)
        ? data.files
        : Array.isArray(data.presented) ? data.presented : undefined
      if (files === undefined) continue
      const picked = files[index]
      if (picked === undefined || typeof picked.path !== 'string') continue
      return { path: absolutePath(base, picked.path), description: picked.description }
    }
    return undefined
  }

  /** 把相对路径按工作目录补成绝对路径；已经是绝对路径就原样返回。 */
  function absolutePath(base, target) {
    if (typeof target !== 'string' || target.length === 0) return target
    if (/^[A-Za-z]:[\\/]/.test(target) || target.startsWith('\\\\') || target.startsWith('/')) return target
    return typeof base === 'string' && base.length > 0 ? resolve(base, target) : target
  }

  /**
   * 只允许 http/https 的 URL 走浏览器通道。
   *
   * 为什么必须白名单：`javascript:`、`data:`、`file:` 这些协议被系统 shell 打开时
   * 可能执行任意代码，而 URL 来自对话内容，是模型可以影响的输入。
   */
  function isSafeWebUrl(value) {
    if (typeof value !== 'string' || value.length === 0) return false
    let parsed
    try {
      parsed = new URL(value)
    } catch {
      return false
    }
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false
    // 带账号密码的 URL 会在地址栏里伪造可信来源，直接拒绝
    if (parsed.username !== '' || parsed.password !== '') return false
    return true
  }

  /**
   * 列出这台机器上能处理 http/https 的浏览器。
   *
   * 为什么读注册表而不是问 Electron：浏览器不是"文件关联应用"，
   * `workspacePathApplications` 只认文件扩展名，查不到浏览器。
   *
   * 全部包在 try 里：拿不到就返回空数组，菜单退化成"只在默认浏览器打开"。
   */
  async function listBrowsers() {
    if (process.platform !== 'win32') return []
    const run = (file, args) => new Promise((done) => {
      try {
        execFile(file, args, { windowsHide: true, timeout: 8000 }, (error, stdout) => {
          done(error ? '' : String(stdout ?? ''))
        })
      } catch {
        done('')
      }
    })

    const script = [
      '$ErrorActionPreference="SilentlyContinue"',
      '$roots=@(',
      '"HKLM:\\SOFTWARE\\Clients\\StartMenuInternet",',
      '"HKLM:\\SOFTWARE\\WOW6432Node\\Clients\\StartMenuInternet",',
      '"HKCU:\\SOFTWARE\\Clients\\StartMenuInternet")',
      '$out=@()',
      'foreach($r in $roots){',
      '  Get-ChildItem $r | ForEach-Object {',
      '    $k=$_.PSChildName',
      '    $cmd=(Get-ItemProperty "$($_.PSPath)\\shell\\open\\command")."(default)"',
      '    if($cmd){ $out += [pscustomobject]@{ id=$k; name=$k; cmd=$cmd } }',
      '  }',
      '}',
      'if($out.Count -eq 0){ "[]" } else { $out | ConvertTo-Json -Compress }',
    ].join('; ')

    const raw = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', script])
    if (raw.trim().length === 0) return []
    let parsed
    try {
      parsed = JSON.parse(raw)
    } catch {
      return []
    }
    const rows = Array.isArray(parsed) ? parsed : [parsed]
    const seen = new Set()
    const list = []
    for (const row of rows) {
      const id = typeof row?.id === 'string' ? row.id : ''
      const cmd = typeof row?.cmd === 'string' ? row.cmd : ''
      if (id.length === 0 || cmd.length === 0 || seen.has(id)) continue
      seen.add(id)
      list.push({ id, name: id, command: cmd })
    }
    return list
  }

  function parseFileArgs(rawInput) {
    const tokens = String(rawInput ?? '').trim().split(/\s+/).filter(Boolean)
    const options = {
      action: 'path', sessionId: undefined, seq: undefined, index: undefined,
      application: undefined, targetDir: undefined, path: undefined, newName: undefined,
      url: undefined, browser: undefined,
    }
    for (const token of tokens) {
      if (token.startsWith('--session=')) options.sessionId = token.slice('--session='.length)
      else if (token.startsWith('--seq=')) options.seq = Number(token.slice('--seq='.length))
      else if (token.startsWith('--index=')) options.index = Number(token.slice('--index='.length))
      else if (token.startsWith('--application=')) options.application = token.slice('--application='.length)
      else if (token.startsWith('--browser=')) options.browser = token.slice('--browser='.length)
      else if (token.startsWith('--url64=')) {
        try {
          options.url = Buffer.from(token.slice('--url64='.length), 'base64').toString('utf8')
        } catch {
          options.url = undefined
        }
      }
      else if (token.startsWith('--target=')) options.targetDir = token.slice('--target='.length)
      else if (token.startsWith('--name64=')) {
        try {
          options.newName = Buffer.from(token.slice('--name64='.length), 'base64').toString('utf8')
        } catch {
          options.newName = undefined
        }
      }
      else if (token.startsWith('--target64=')) {
        try {
          options.targetDir = Buffer.from(token.slice('--target64='.length), 'base64').toString('utf8')
        } catch {
          options.targetDir = undefined
        }
      }
      else if (token.startsWith('--path64=')) {
        // 路径用 base64 传：Windows 路径常含空格，直接拼进命令行会被拆断。
        try {
          options.path = Buffer.from(token.slice('--path64='.length), 'base64').toString('utf8')
        } catch {
          options.path = undefined
        }
      }
      else if (token.startsWith('--path=')) options.path = token.slice('--path='.length)
      else if (token.startsWith('--action=')) options.action = token.slice('--action='.length)
    }
    return options
  }

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-file',
      description: '解析对话里交付物文件的真实路径，或对它执行打开 / 显示位置 / 查询可用应用。',
      handler: async (invocation) => {
        const options = parseFileArgs(invocation.rawInput)

        /* ---- 网址动作：不涉及文件路径，必须在解析 path 之前分流 ---- */

        // 列出浏览器：给右键菜单的「用其它浏览器打开」子菜单提供数据
        if (options.action === 'browsers') {
          try {
            const browsers = await listBrowsers()
            return { kind: 'success', text: JSON.stringify({ browsers }) }
          } catch (error) {
            return { kind: 'error', text: `读取浏览器列表失败：${error?.message ?? error}` }
          }
        }

        // 用指定浏览器打开 URL。--browser 为空时交给系统默认浏览器。
        if (options.action === 'open-url') {
          if (!isSafeWebUrl(options.url)) {
            return { kind: 'error', text: '只允许打开 http/https 网址' }
          }
          try {
            if (typeof options.browser === 'string' && options.browser.length > 0) {
              // 指定浏览器：先找到它的启动命令，再把 URL 作为参数拉起。
              // 命令形如 `"C:\...\chrome.exe" --single-argument %1`，%1 是占位符。
              const browsers = await listBrowsers()
              const hit = browsers.find((one) => one.id === options.browser)
              if (hit === undefined) return { kind: 'error', text: `没找到浏览器：${options.browser}` }
              const match = /^\s*"([^"]+)"|^\s*(\S+)/.exec(hit.command)
              const exe = match?.[1] ?? match?.[2]
              if (exe === undefined || exe.length === 0) {
                return { kind: 'error', text: `无法解析浏览器启动命令：${options.browser}` }
              }
              const child = spawn(exe, [options.url], { detached: true, stdio: 'ignore', windowsHide: false })
              child.on('error', () => {})
              child.unref()
              return { kind: 'success', text: options.url }
            }
            if (process.platform === 'win32') {
              const child = spawn('cmd.exe', ['/c', 'start', '', options.url], {
                detached: true, stdio: 'ignore', windowsHide: true,
              })
              child.on('error', () => {})
              child.unref()
              return { kind: 'success', text: options.url }
            }
            const opener = process.platform === 'darwin' ? 'open' : 'xdg-open'
            const child = spawn(opener, [options.url], { detached: true, stdio: 'ignore' })
            child.on('error', () => {})
            child.unref()
            return { kind: 'success', text: options.url }
          } catch (error) {
            return { kind: 'error', text: `打开网址失败：${error?.message ?? error}` }
          }
        }

        let found
        if (typeof options.path === 'string' && options.path.length > 0) {
          // 直接给了路径（右键菜单走这条）：不必再回查事件
          found = { path: options.path }
        } else {
          if (options.sessionId === undefined) return { kind: 'error', text: '缺少 --session=<会话 id>' }
          if (!Number.isFinite(options.seq) || !Number.isFinite(options.index)) {
            return { kind: 'error', text: '缺少 --seq=<序号> 或 --index=<索引>' }
          }
          try {
            found = await resolvePresentedFile(options.sessionId, options.seq, options.index)
          } catch (error) {
            return { kind: 'error', text: `读取交付物失败：${error?.message ?? error}` }
          }
        }
        if (found === undefined) return { kind: 'error', text: '没找到这个文件（可能已被移动或删除）' }

        if (options.action === 'path') return { kind: 'success', text: found.path }

        // 在终端中打开：在该文件所在目录起一个终端窗口。
        // 用系统自带的终端，不自建 PTY —— 那会把插件和终端生命周期绑在一起。
        if (options.action === 'terminal') {
          const dir = dirname(found.path)
          const platform = process.platform
          const argv = platform === 'win32'
            ? ['cmd.exe', ['/c', 'start', '', 'cmd.exe', '/k', `cd /d "${dir}"`]]
            : platform === 'darwin'
              ? ['open', ['-a', 'Terminal', dir]]
              : ['x-terminal-emulator', ['--working-directory', dir]]
          try {
            const child = spawn(argv[0], argv[1], { detached: true, stdio: 'ignore', windowsHide: false })
            child.on('error', () => {})
            child.unref()
            return { kind: 'success', text: dir }
          } catch (error) {
            return { kind: 'error', text: `打开终端失败：${error?.message ?? error}` }
          }
        }

        // 重命名：同目录内改文件名，不覆盖已有文件。
        if (options.action === 'rename') {
          if (typeof options.newName !== 'string' || options.newName.trim().length === 0) {
            return { kind: 'error', text: '缺少新文件名' }
          }
          const dir = dirname(found.path)
          const cleaned = sanitize(options.newName.trim())
          const target = resolve(dir, cleaned)
          // 只允许改同一目录里的名字，不允许借重命名把文件挪到别处
          if (dirname(target) !== resolve(dir)) {
            return { kind: 'error', text: '新名字不能包含路径分隔符' }
          }
          if (target === resolve(found.path)) return { kind: 'success', text: target }
          if (await exists(target)) {
            return { kind: 'error', text: `同名文件已存在：${cleaned}` }
          }
          try {
            await rename(found.path, target)
            return { kind: 'success', text: target }
          } catch (error) {
            return { kind: 'error', text: `重命名失败：${error?.message ?? error}` }
          }
        }

        // 移到回收站：文件进 $DSH_HOME/trash/files/<id>/，可恢复。
        if (options.action === 'trash') {
          const root = trashRoot()
          if (root === undefined) return { kind: 'error', text: '无法确定回收站位置：DSH_HOME 未设置' }
          const id = `file-${newTrashId()}`
          const entryDir = join(root, id)
          try {
            await mkdir(entryDir, { recursive: true })
            const name = basename(found.path)
            await movePath(found.path, join(entryDir, name))
            const info = await stat(join(entryDir, name)).catch(() => undefined)
            await writeFile(join(entryDir, 'meta.json'), JSON.stringify({
              id,
              kind: 'file',
              sessionId: options.sessionId,
              title: name,
              deletedAt: Date.now(),
              folderOrigin: found.path,
              hasSession: false,
              hasFolder: true,
              bytes: info?.size ?? 0,
            }, null, 2), 'utf8')
            return { kind: 'success', text: join(entryDir, name) }
          } catch (error) {
            await rm(entryDir, { recursive: true, force: true }).catch(() => {})
            return { kind: 'error', text: `移到回收站失败：${error?.message ?? error}` }
          }
        }

        // 另存为：把文件复制到调用方已经选好的目录，保持原文件名。
        if (options.action === 'saveas') {
          if (typeof options.targetDir !== 'string' || options.targetDir.length === 0) {
            return { kind: 'error', text: '缺少 --target=<目标目录>' }
          }
          try {
            const info = await stat(found.path)
            if (!info.isFile()) return { kind: 'error', text: '这个条目不是文件，无法另存' }
            const name = found.path.split(/[\\/]/).pop() ?? 'file'
            let target = resolve(options.targetDir, name)
            // 目标已存在就加序号，不覆盖用户已有文件
            let counter = 1
            while (true) {
              try {
                await stat(target)
                const dot = name.lastIndexOf('.')
                const base = dot > 0 ? name.slice(0, dot) : name
                const ext = dot > 0 ? name.slice(dot) : ''
                target = resolve(options.targetDir, `${base} (${counter})${ext}`)
                counter += 1
              } catch {
                break
              }
            }
            await copyFile(found.path, target)
            return { kind: 'success', text: target }
          } catch (error) {
            return { kind: 'error', text: `另存为失败：${error?.message ?? error}` }
          }
        }

        // 文件信息：大小、修改时间、类型。给菜单顶部的说明行用。
        if (options.action === 'info') {
          try {
            const info = await stat(found.path)
            return {
              kind: 'success',
              text: JSON.stringify({
                path: found.path,
                size: info.size,
                isDirectory: info.isDirectory(),
                modifiedAt: info.mtimeMs,
              }),
            }
          } catch (error) {
            return { kind: 'error', text: `读取文件信息失败：${error?.message ?? error}` }
          }
        }

        // 读文本内容：只读，且限制大小，避免把几百 MB 的文件读进内存再塞回消息通道。
        if (options.action === 'read') {
          const MAX_BYTES = 512 * 1024
          try {
            const info = await stat(found.path)
            if (!info.isFile()) return { kind: 'error', text: '这个条目不是文件' }
            if (info.size > MAX_BYTES) {
              return { kind: 'error', text: `文件太大（${Math.round(info.size / 1024)} KB），超过 512 KB 上限` }
            }
            const text = await readFile(found.path, 'utf8')
            return { kind: 'success', text }
          } catch (error) {
            return { kind: 'error', text: `读取文件失败：${error?.message ?? error}` }
          }
        }

        // 解压：用系统自带的 bsdtar（libarchive），原生支持 zip / tar 等格式，不引入第三方依赖。
        // 解到与压缩包同名的目录，已存在就拒绝，避免覆盖用户文件。
        if (options.action === 'extract') {
          const info = await stat(found.path).catch(() => undefined)
          if (info === undefined || !info.isFile()) return { kind: 'error', text: '这个条目不是文件，无法解压' }
          const dir = dirname(found.path)
          const stem = basename(found.path).replace(/\.(zip|7z|tar|tgz|tar\.gz|tar\.bz2|tar\.xz|gz|bz2|xz|rar)$/i, '')
          const target = resolve(dir, stem.length > 0 ? stem : 'extracted')
          if (target === resolve(found.path)) return { kind: 'error', text: '解压目标不能是压缩包自己' }
          if (await exists(target)) return { kind: 'error', text: `目标目录已存在：${target}` }
          try {
            await mkdir(target, { recursive: true })
            const code = await new Promise((done) => {
              const child = spawn('tar.exe', ['-xf', found.path, '-C', target], {
                windowsHide: true, stdio: 'ignore',
              })
              child.on('error', () => done(-1))
              child.on('exit', (exitCode) => done(exitCode ?? -1))
            })
            if (code !== 0) {
              await rm(target, { recursive: true, force: true }).catch(() => {})
              return { kind: 'error', text: `解压失败（tar 退出码 ${code}）` }
            }
            return { kind: 'success', text: target }
          } catch (error) {
            await rm(target, { recursive: true, force: true }).catch(() => {})
            return { kind: 'error', text: `解压失败：${error?.message ?? error}` }
          }
        }

        const controller = service('sessionController')

        if (options.action === 'applications') {
          if (controller === undefined || typeof controller.workspacePathApplications !== 'function') {
            return { kind: 'error', text: '当前环境无法查询打开方式' }
          }
          try {
            const apps = await controller.workspacePathApplications(
              { path: found.path }, new AbortController().signal,
            )
            const list = (Array.isArray(apps) ? apps : []).map((app) => ({
              id: String(app.id),
              name: String(app.name),
              isDefault: app.default === true,
            }))
            return { kind: 'success', text: JSON.stringify({ path: found.path, applications: list }) }
          } catch (error) {
            return { kind: 'error', text: `查询打开方式失败：${error?.message ?? error}` }
          }
        }

        if (controller === undefined || typeof controller.openWorkspacePath !== 'function') {
          return { kind: 'error', text: '当前环境不支持打开文件（openWorkspacePath 不可用）' }
        }
        try {
          await controller.openWorkspacePath({
            path: found.path,
            ...(options.action === 'reveal' ? { action: 'reveal' } : {}),
            ...(options.application !== undefined ? { application: options.application } : {}),
          }, new AbortController().signal)
          return { kind: 'success', text: found.path }
        } catch (error) {
          return { kind: 'error', text: `打开失败：${error?.message ?? error}` }
        }
      },
    })
  }, 'dsh-steward: /chat-file')

  /* ------------------------------------------------------------------ */
  /* 六、/chat-delete-batch：批量删除（同样进回收站）                     */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-delete-batch',
      description: '批量删除对话：逐个归档并移入回收站，可一并处理各自的文件夹。',
      handler: async (invocation) => {
        const tokens = String(invocation.rawInput ?? '').trim().split(/\s+/).filter(Boolean)
        const options = { sessionIds: [], deleteFolder: false }
        for (const token of tokens) {
          if (token === '--with-folder') options.deleteFolder = true
          else if (token.startsWith('--sessions=')) {
            // 逗号分隔；会话 id 里不会有逗号，所以不需要转义
            options.sessionIds = token.slice('--sessions='.length).split(',').filter(Boolean)
          }
        }
        if (options.sessionIds.length === 0) {
          return { kind: 'error', text: '缺少 --sessions=<id1,id2,...>' }
        }

        const results = []
        for (const sessionId of options.sessionIds) {
          try {
            const result = await deleteConversation({
              sessionId,
              deleteFolder: options.deleteFolder,
              folderPath: undefined,
            })
            results.push({ sessionId, ok: result.ok === true, text: result.text })
          } catch (error) {
            results.push({ sessionId, ok: false, text: String(error?.message ?? error) })
          }
        }

        const ok = results.filter((item) => item.ok).length
        return {
          kind: ok > 0 ? 'success' : 'error',
          text: JSON.stringify({ total: results.length, ok, failed: results.length - ok, results }),
        }
      },
    })
  }, 'dsh-steward: /chat-delete-batch')

  /* ------------------------------------------------------------------ */
  /* 七、/chat-trash：回收站（列表 / 恢复 / 彻底删除 / 清空）             */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-trash',
      description: '回收站：list 列出、restore 恢复、purge 彻底删除一条、empty 清空。',
      handler: async (invocation) => {
        const tokens = String(invocation.rawInput ?? '').trim().split(/\s+/).filter(Boolean)
        const action = (tokens[0] ?? 'list').toLowerCase()
        const arg = tokens[1]

        if (action === 'list') {
          const items = await listTrash()
          return {
            kind: 'success',
            text: JSON.stringify({
              total: items.length,
              bytes: items.reduce((sum, item) => sum + (item.bytes ?? 0), 0),
              items: items.map((item) => ({
                id: item.id,
                kind: item.kind === 'file' ? 'file' : 'conversation',
                sessionId: item.sessionId,
                title: item.title ?? '',
                deletedAt: item.deletedAt ?? 0,
                bytes: item.bytes ?? 0,
                hasFolder: item.hasFolder === true,
                folderOrigin: item.folderOrigin ?? '',
              })),
            }),
          }
        }

        if (action === 'restore') {
          if (arg === undefined) return { kind: 'error', text: '缺少回收站条目 id' }
          const result = await restoreTrash(arg)
          return result.ok ? { kind: 'success', text: result.text } : { kind: 'error', text: result.text }
        }

        if (action === 'purge') {
          if (arg === undefined) return { kind: 'error', text: '缺少回收站条目 id' }
          const result = await purgeTrash(arg)
          return result.ok ? { kind: 'success', text: result.text } : { kind: 'error', text: result.text }
        }

        if (action === 'empty') {
          const result = await emptyTrash()
          return result.ok ? { kind: 'success', text: result.text } : { kind: 'error', text: result.text }
        }

        return { kind: 'error', text: '用法：/chat-trash list | restore <id> | purge <id> | empty' }
      },
    })
  }, 'dsh-steward: /chat-trash')

  /* ------------------------------------------------------------------ */
  /* 七、/chat-backup：备份目录（查看占用 / 清空 / 打开文件夹）            */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-backup',
      description: '备份目录：info 查看占用、clear 一键清空、open 打开文件夹让用户自己取舍。',
      handler: async (invocation) => {
        const action = String(invocation.rawInput ?? '').trim().toLowerCase() || 'info'

        if (action === 'info') {
          const info = await backupInfo()
          return {
            kind: 'success',
            text: JSON.stringify({
              dir: info.dir,
              exists: info.exists === true,
              entries: info.entries ?? 0,
              bytes: info.bytes ?? 0,
              human: formatBytes(info.bytes ?? 0),
              oldest: info.oldest,
              newest: info.newest,
            }),
          }
        }

        if (action === 'clear') {
          const result = await clearBackups()
          return result.ok ? { kind: 'success', text: result.text } : { kind: 'error', text: result.text }
        }

        if (action === 'open') {
          const info = await backupInfo()
          if (info.exists !== true) return { kind: 'success', text: `备份目录还不存在：${info.dir}` }
          const opened = openDirectory(info.dir)
          return opened
            ? { kind: 'success', text: info.dir }
            : { kind: 'error', text: '无法打开文件夹（当前环境不支持）' }
        }

        return { kind: 'error', text: '用法：/chat-backup info | clear | open' }
      },
    })
  }, 'dsh-steward: /chat-backup')

  /* ------------------------------------------------------------------ */
  /* 八、/chat-doctor：体检（全部只读）                                   */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-doctor',
      description: '自检：守则块、配置、孤儿文件夹、回收站与备份占用，一次报清楚。',
      handler: async () => {
        const report = await runDoctor()
        return { kind: 'success', text: JSON.stringify(report) }
      },
    })
  }, 'dsh-steward: /chat-doctor')

  async function runDoctor() {
    const checks = []
    const home = process.env.DSH_HOME

    // 1) 守则块
    try {
      const target = home === undefined ? undefined : join(home, 'AGENTS.md')
      let text
      if (target === undefined) throw new Error('DSH_HOME 未设置')
      text = await readFile(target, 'utf8')
      const begin = (text.match(/dsh-steward:begin/g) ?? []).length
      const end = (text.match(/dsh-steward:end/g) ?? []).length
      const legacy = (text.match(/guardrails:begin/g) ?? []).length
      checks.push({
        id: 'guardrails',
        status: begin === 1 && end === 1 && legacy === 0 ? 'ok' : 'warn',
        detail: begin === 1 && end === 1
          ? `守则块完整（${Buffer.byteLength(text, 'utf8')} 字节）`
          : `标记不配对：begin=${begin} end=${end}${legacy > 0 ? `，还残留 ${legacy} 段旧标记` : ''}`,
      })
    } catch (error) {
      checks.push({ id: 'guardrails', status: 'warn', detail: `读不到 AGENTS.md：${error?.message ?? error}` })
    }

    // 2) 设置表单（Config 是否投影出来）
    checks.push({
      id: 'config-schema',
      status: Config === undefined ? 'warn' : 'ok',
      detail: Config === undefined
        ? '拿不到 schemastery，设置页表单缺失（功能仍可用）'
        : '设置表单可用',
    })

    // 3) 配置文件
    try {
      const saved = await readConfigFile()
      checks.push({
        id: 'config-file',
        status: 'ok',
        detail: `配置文件可读：folder.enabled=${(saved.folder ?? {}).enabled === true}，`
          + `guardrails.install=${(saved.guardrails ?? {}).install === true}`,
      })
    } catch (error) {
      checks.push({ id: 'config-file', status: 'warn', detail: `配置文件读取失败：${error?.message ?? error}` })
    }

    // 4) 孤儿文件夹：登记表里指向的目录还在不在、以及工作区里 chat-* 有没有对应会话
    try {
      const registry = await loadRegistry()
      const missing = []
      for (const [id, path] of registry) {
        if (!(await exists(path))) missing.push({ id, path })
      }
      checks.push({
        id: 'folder-registry',
        status: missing.length === 0 ? 'ok' : 'warn',
        detail: missing.length === 0
          ? `登记表 ${registry.size} 条，全部存在`
          : `${missing.length}/${registry.size} 条登记指向的目录已不存在`,
        missing: missing.slice(0, 20),
      })
    } catch (error) {
      checks.push({ id: 'folder-registry', status: 'warn', detail: `登记表检查失败：${error?.message ?? error}` })
    }

    // 5) 回收站
    try {
      const items = await listTrash()
      const bytes = items.reduce((sum, item) => sum + (item.bytes ?? 0), 0)
      checks.push({
        id: 'trash',
        status: 'ok',
        detail: items.length === 0 ? '回收站为空' : `回收站 ${items.length} 条，占 ${formatBytes(bytes)}`,
        entries: items.length,
        bytes,
      })
    } catch (error) {
      checks.push({ id: 'trash', status: 'warn', detail: `回收站检查失败：${error?.message ?? error}` })
    }

    // 6) 备份占用
    try {
      const info = await backupInfo()
      checks.push({
        id: 'backups',
        status: info.exists !== true || (info.bytes ?? 0) === 0 ? 'ok' : 'info',
        detail: info.exists !== true
          ? '备份目录还不存在'
          : `备份 ${info.entries} 项，占 ${formatBytes(info.bytes ?? 0)}`,
        dir: info.dir,
        entries: info.entries ?? 0,
        bytes: info.bytes ?? 0,
      })
    } catch (error) {
      checks.push({ id: 'backups', status: 'warn', detail: `备份目录检查失败：${error?.message ?? error}` })
    }

    return {
      at: Date.now(),
      home: home ?? '',
      checks,
      problems: checks.filter((item) => item.status === 'warn').length,
    }
  }

  /* ------------------------------------------------------------------ */
  /* 九、/chat-guardrails：守则全文 / 预览 / 恢复默认                     */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-guardrails',
      description: '守则：get 返回全文与写入状态，preview 返回将会写入的内容，restore 用内置版本覆盖。',
      handler: async (invocation) => {
        const action = String(invocation.rawInput ?? '').trim().toLowerCase() || 'get'

        let rules
        try {
          const source = guardrailsSource()
          if (source === undefined) throw new Error('内置守则文件不可用')
          rules = await readFile(source, 'utf8')
        } catch (error) {
          return { kind: 'error', text: `读取内置守则失败：${error?.message ?? error}` }
        }

        if (action === 'get' || action === 'preview') {
          const home = process.env.DSH_HOME
          const target = home === undefined ? undefined : join(home, 'AGENTS.md')
          let current
          try {
            current = target === undefined ? undefined : await readFile(target, 'utf8')
          } catch {
            current = undefined
          }
          const installed = typeof current === 'string'
            && current.includes(GUARDRAIL_BEGIN)
            && current.includes(GUARDRAIL_END)
          return {
            kind: 'success',
            text: JSON.stringify({
              path: target ?? '',
              installed,
              rules: rules.trim(),
              // preview：把"写入后会变成什么样"整段给出来，让用户先看再决定
              next: action === 'preview' ? composeGuardrails(current, rules) : undefined,
            }),
          }
        }

        if (action === 'restore') {
          const home = process.env.DSH_HOME
          if (home === undefined) return { kind: 'error', text: 'DSH_HOME 未设置' }
          const target = join(home, 'AGENTS.md')
          let current
          try {
            current = await readFile(target, 'utf8')
          } catch {
            current = undefined
          }
          // 覆盖前先备份，符合守则自己的原则三
          if (current !== undefined) {
            try {
              const dir = join(home, 'backups')
              await mkdir(dir, { recursive: true })
              const stamp = new Date().toISOString().replace(/[:.]/g, '-')
              await copyFile(target, join(dir, `AGENTS.md.${stamp}.bak`))
            } catch (error) {
              return { kind: 'error', text: `备份失败，已放弃写入：${error?.message ?? error}` }
            }
          }
          try {
            await writeFile(target, composeGuardrails(current, rules), 'utf8')
            return { kind: 'success', text: '已用内置版本恢复守则段' }
          } catch (error) {
            return { kind: 'error', text: `写入失败：${error?.message ?? error}` }
          }
        }

        return { kind: 'error', text: '用法：/chat-guardrails get | preview | restore' }
      },
    })
  }, 'dsh-steward: /chat-guardrails')

  /* ------------------------------------------------------------------ */
  /* 十、/chat-open-folder：打开某个对话自己的文件夹                      */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-open-folder',
      description: '打开某个对话自己的文件夹（在资源管理器里）。',
      handler: async (invocation) => {
        const options = parseArgs(invocation.rawInput)
        if (options.sessionId === undefined || options.sessionId.length === 0) {
          return { kind: 'error', text: '缺少 --session=<会话 id>' }
        }
        const folderPath = resolveChatFolder(options.sessionId, options.folderPath)
        if (folderPath === undefined) {
          return { kind: 'error', text: '这个对话没有登记过的文件夹' }
        }
        if (!(await exists(folderPath))) {
          return { kind: 'error', text: `文件夹已不存在：${folderPath}` }
        }
        const opened = openDirectory(folderPath)
        return opened
          ? { kind: 'success', text: folderPath }
          : { kind: 'error', text: '无法打开文件夹（当前环境不支持）' }
      },
    })
  }, 'dsh-steward: /chat-open-folder')

  /* ------------------------------------------------------------------ */
  /* 十一、/chat-folder-audit：找出并清理多建出来的空对话文件夹           */
  /* ------------------------------------------------------------------ */

  ctx.effect(() => {
    return ctx.commands.register({
      name: 'chat-folder-audit',
      description: '检查对话文件夹：找出空目录与孤儿登记；可把多余的空目录移进回收站。',
      handler: async (invocation) => {
        const mode = String(invocation.rawInput ?? '').trim().toLowerCase() || 'list'
        const registry = await loadRegistry()

        // 登记表里指向的目录，是"有主"的
        const owned = new Set([...registry.values()].map((p) => resolve(p).toLowerCase()))

        // 扫所有工作区根目录下的 chat-*（模板前缀可配，这里按登记表反推前缀更稳）
        const template = currentFolder().template ?? DEFAULTS.folder.template
        const prefix = String(template).split('{')[0] || 'chat-'

        const roots = new Set()
        for (const path of registry.values()) roots.add(dirname(resolve(path)))
        // 再加上所有已知工作区目录
        try {
          const registrySvc = service('workspaceRegistry')
          for (const workspace of registrySvc?.list?.() ?? []) {
            if (typeof workspace?.path === 'string') roots.add(resolve(workspace.path))
          }
        } catch {
          // 拿不到工作区列表就只扫登记表所在的目录
        }

        const empty = []
        const unowned = []
        for (const root of roots) {
          let entries
          try {
            entries = await readdir(root, { withFileTypes: true })
          } catch {
            continue
          }
          for (const entry of entries) {
            if (!entry.isDirectory() || !entry.name.startsWith(prefix)) continue
            const full = resolve(join(root, entry.name))
            const isOwned = owned.has(full.toLowerCase())
            let count = 0
            try {
              count = (await readdir(full)).length
            } catch {
              continue
            }
            if (!isOwned) {
              unowned.push({ path: full, empty: count === 0, entries: count })
            } else if (count === 0) {
              empty.push({ path: full })
            }
          }
        }

        const missing = []
        for (const [id, path] of registry) {
          if (!(await exists(path))) missing.push({ sessionId: id, path })
        }

        if (mode === 'list') {
          return {
            kind: 'success',
            text: JSON.stringify({
              registered: registry.size,
              unowned: unowned.length,
              emptyOwned: empty.length,
              missing: missing.length,
              unownedList: unowned.slice(0, 50),
              emptyList: empty.slice(0, 50),
              missingList: missing.slice(0, 50),
            }),
          }
        }

        // clean：把**未被登记**的空目录移进回收站（不是直接删）
        if (mode === 'clean') {
          const root = trashRoot()
          if (root === undefined) return { kind: 'error', text: '无法确定回收站位置：DSH_HOME 未设置' }
          const moved = []
          const skipped = []
          for (const item of unowned) {
            if (!item.empty) {
              skipped.push({ path: item.path, reason: 'not-empty' })
              continue
            }
            const id = `folder-${newTrashId()}`
            const entryDir = join(root, id)
            try {
              await mkdir(entryDir, { recursive: true })
              await movePath(item.path, join(entryDir, 'folder'))
              await writeFile(join(entryDir, 'meta.json'), JSON.stringify({
                id,
                kind: 'folder',
                title: basename(item.path),
                deletedAt: Date.now(),
                folderOrigin: item.path,
                hasSession: false,
                hasFolder: true,
              }, null, 2), 'utf8')
              moved.push(item.path)
            } catch (error) {
              await rm(entryDir, { recursive: true, force: true }).catch(() => {})
              skipped.push({ path: item.path, reason: String(error?.message ?? error) })
            }
          }
          return {
            kind: 'success',
            text: JSON.stringify({ moved: moved.length, skipped: skipped.length, movedList: moved.slice(0, 50), skipped }),
          }
        }

        return { kind: 'error', text: '用法：/chat-folder-audit list | clean' }
      },
    })
  }, 'dsh-steward: /chat-folder-audit')
}

﻿/* ================================================================== */
/* 运行守则：把三原则写进 $DSH_HOME/AGENTS.md                          */
/* ================================================================== */
/*
 * 这段来自原来的 guardrails 插件，合并进来后仍保持它最重要的性质：
 * 任何一步失败都只是"守则没写入"，绝不抛错到 harness。
 */

const GUARDRAIL_BEGIN = '<!-- dsh-steward:begin 由 dsh-steward 维护，请勿手改本段 -->'
const GUARDRAIL_END = '<!-- dsh-steward:end -->'
/* 兼容旧标记：早期单独安装 guardrails 时写的是 guardrails:begin/end */
const LEGACY_BEGIN = '<!-- guardrails:begin'
const LEGACY_END = '<!-- guardrails:end -->'

function guardrailsSource() {
  try {
    return fileURLToPath(new URL('./AGENTS.guardrails.md', import.meta.url))
  } catch {
    return undefined
  }
}

/** 用新标记段替换旧内容；同时清理旧插件留下的 guardrails 段，避免重复。 */
function composeGuardrails(existing, rules) {
  const block = `${GUARDRAIL_BEGIN}\n${rules.trim()}\n${GUARDRAIL_END}`
  let text = typeof existing === 'string' ? existing : ''

  // 先摘掉旧插件的段落
  const lb = text.indexOf(LEGACY_BEGIN)
  const le = text.indexOf(LEGACY_END)
  if (lb >= 0 && le > lb) {
    text = `${text.slice(0, lb)}${text.slice(le + LEGACY_END.length)}`
  }

  const begin = text.indexOf(GUARDRAIL_BEGIN)
  const end = text.indexOf(GUARDRAIL_END)
  if (begin >= 0 && end > begin) {
    return `${text.slice(0, begin)}${block}${text.slice(end + GUARDRAIL_END.length)}`
      .replace(/\n{3,}/g, '\n\n')
  }
  if (text.trim().length === 0) return `${block}\n`
  return `${text.trimEnd()}\n\n${block}\n`
}

async function installGuardrails(settings) {
  if (settings !== true) return
  const home = process.env.DSH_HOME
  if (typeof home !== 'string' || home.length === 0) return

  const source = guardrailsSource()
  if (source === undefined) return

  let rules
  try {
    rules = await readFile(source, 'utf8')
  } catch {
    return
  }
  if (typeof rules !== 'string' || rules.trim().length === 0) return

  const target = join(home, 'AGENTS.md')
  let current
  try {
    current = await readFile(target, 'utf8')
  } catch {
    current = undefined
  }

  const next = composeGuardrails(current, rules)
  if (current === next) return

  // 覆盖前先备份，符合它自己的原则三
  if (current !== undefined) {
    try {
      const backupDir = join(home, 'backups')
      await mkdir(backupDir, { recursive: true })
      const stamp = new Date().toISOString().replace(/[:.]/g, '-')
      await copyFile(target, join(backupDir, `AGENTS.md.${stamp}.bak`))
    } catch {
      return
    }
  }

  try {
    await mkdir(dirname(target), { recursive: true })
    await writeFile(target, next, 'utf8')
  } catch {
    // 写不进去也只是守则没生效
  }
}
