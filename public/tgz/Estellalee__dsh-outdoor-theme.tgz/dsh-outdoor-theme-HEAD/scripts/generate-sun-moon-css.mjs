/**
 * 生成「太阳东升西落」浅色空态背景 CSS（outdoor-sun-moon.css）
 * --------------------------------------------------------------
 * 把 6 个时段（夜晚/日出/上午/正午/下午/日落）的 SVG 转成 data-URI，
 * 写进 CSS，由 body[data-sun-phase="..."] 决定显示哪一张。
 *
 * 运行：node scripts/generate-sun-moon-css.mjs
 * 产物：../outdoor-sun-moon.css
 */
import { writeFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const OUT = fileURLToPath(new URL("../outdoor-sun-moon.css", import.meta.url));

/* ---------- 三层远山 + 雪线 + 云雾 + 星星（与 demo 完全一致） ---------- */
const RIDGES = {
  far:  "M0 600 C80 570 150 585 240 545 C300 518 350 500 430 520 C500 538 540 470 620 505 C700 538 760 510 860 520 C950 528 1010 485 1100 505 C1180 522 1260 495 1350 515 C1440 535 1500 520 1600 545 L1600 900 L0 900 Z",
  mid:  "M0 680 C120 640 200 660 320 620 C400 595 460 625 560 595 C640 572 700 620 820 585 C920 556 980 600 1100 575 C1200 553 1280 600 1400 585 C1500 572 1560 600 1600 590 L1600 900 L0 900 Z",
  near: "M0 760 C140 720 240 745 380 700 C480 668 560 710 700 680 C820 654 900 700 1040 675 C1160 653 1260 700 1400 685 C1500 673 1570 700 1600 695 L1600 900 L0 900 Z"
};
const SNOW = '<path d="M545 480 L560 472 L572 480 L586 474 L600 482 L612 476 L620 490 L606 494 L592 489 L578 497 L564 491 Z" fill="#FFFFFF" opacity="0.85"/>';
const FOG_DAY = '<g fill="#FFFFFF">'
  + '<ellipse cx="420" cy="655" rx="180" ry="15" opacity="0.28"/>'
  + '<ellipse cx="1000" cy="725" rx="230" ry="17" opacity="0.22"/>'
  + '<ellipse cx="1340" cy="615" rx="160" ry="13" opacity="0.25"/>'
  + '</g>';
const FOG_NIGHT = '<g fill="#9FB0C0">'
  + '<ellipse cx="420" cy="655" rx="180" ry="15" opacity="0.16"/>'
  + '<ellipse cx="1000" cy="725" rx="230" ry="17" opacity="0.13"/>'
  + '<ellipse cx="1340" cy="615" rx="160" ry="13" opacity="0.15"/>'
  + '</g>';
const STARS = '<g fill="#E8F0F8">'
  + '<circle cx="150" cy="90" r="2" opacity="0.9"/>'
  + '<circle cx="320" cy="150" r="1.4" opacity="0.7"/>'
  + '<circle cx="480" cy="70" r="2.2" opacity="0.95"/>'
  + '<circle cx="660" cy="130" r="1.4" opacity="0.6"/>'
  + '<circle cx="860" cy="80" r="2" opacity="0.9"/>'
  + '<circle cx="1060" cy="160" r="1.4" opacity="0.7"/>'
  + '<circle cx="1240" cy="60" r="2.4" opacity="0.95"/>'
  + '<circle cx="1440" cy="140" r="1.4" opacity="0.6"/>'
  + '<circle cx="220" cy="200" r="1.4" opacity="0.7"/>'
  + '<circle cx="760" cy="190" r="1.8" opacity="0.85"/>'
  + '<circle cx="1350" cy="220" r="1.4" opacity="0.7"/>'
  + '<circle cx="90" cy="260" r="1.6" opacity="0.8"/>'
  + '<circle cx="540" cy="240" r="1.3" opacity="0.7"/>'
  + '<circle cx="1180" cy="250" r="1.5" opacity="0.8"/>'
  + '</g>';

/* ---------- 六个时段（6 / 9 / 12 / 15 / 18 / 20 边界） ---------- */
const PHASES = [
  {
    id: 'night', name: '夜晚',
    sky: [['0','#223046'],['0.55','#33465C'],['1','#3C4E63']],
    mtn: { far:['#2B3B46','#1F2D35'], mid:['#2C3A31','#1F2C24'], near:['#233429','#162117'] },
    night: true, moon: [1100, 220]
  },
  {
    id: 'dawn', name: '日出',
    sky: [['0','#FDF2DF'],['0.5','#FFE3B3'],['1','#FFC98A']],
    mtn: { far:['#A8B6BE','#8FA0AA'], mid:['#AEBDA0','#8EA184'], near:['#93A678','#6F8357'] },
    sun: [280, 560], glow: '#FFB36B'
  },
  {
    id: 'morning', name: '上午',
    sky: [['0','#E9F3F6'],['0.6','#F6F1E2'],['1','#F1E4C6']],
    mtn: { far:['#A9B8C0','#91A3AC'], mid:['#AFC0A1','#90A386'], near:['#94A77A','#708458'] },
    sun: [520, 360], glow: '#FFD98A'
  },
  {
    id: 'noon', name: '正午',
    sky: [['0','#CBE7F4'],['0.6','#EAF4EE'],['1','#E7EBD8']],
    mtn: { far:['#A6B7C0','#8EA2AC'], mid:['#AEC0A0','#8FA284'], near:['#93A678','#6E8356'] },
    sun: [800, 200], glow: '#FFE9A8'
  },
  {
    id: 'afternoon', name: '下午',
    sky: [['0','#F5EEDC'],['0.6','#FBE9CC'],['1','#F7DDB4']],
    mtn: { far:['#A8B7BF','#8FA1AB'], mid:['#AEBEA0','#8EA184'], near:['#93A678','#6F8357'] },
    sun: [1080, 360], glow: '#FFCF7A'
  },
  {
    id: 'dusk', name: '日落',
    sky: [['0','#F3D9D9'],['0.5','#FFC98A'],['1','#FF9A5E']],
    mtn: { far:['#B0A8A0','#998E86'], mid:['#A89B86','#8A7E6C'], near:['#8C8268','#6D644E'] },
    sun: [1320, 560], glow: '#FF8C42'
  }
];

function buildSvg(ph) {
  const skyStops = ph.sky.map(([o, c]) => `<stop offset="${o}" stop-color="${c}"/>`).join('');
  const mk = (a) => `<stop offset="0" stop-color="${a[0]}"/><stop offset="1" stop-color="${a[1]}"/>`;
  let celestial = '', celestialGrads = '';
  if (ph.sun) {
    const [x, y] = ph.sun;
    celestialGrads = `<radialGradient id="glow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="${ph.glow}" stop-opacity="0.55"/><stop offset="1" stop-color="${ph.glow}" stop-opacity="0"/></radialGradient>`;
    celestial = `<circle cx="${x}" cy="${y}" r="120" fill="url(#glow)"/><circle cx="${x}" cy="${y}" r="36" fill="#FFF4C8"/><circle cx="${x}" cy="${y}" r="36" fill="#FFE08A" opacity="0.4"/>`;
  } else if (ph.moon) {
    const [x, y] = ph.moon;
    celestialGrads = `<radialGradient id="glow" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#DCE8F5" stop-opacity="0.4"/><stop offset="1" stop-color="#DCE8F5" stop-opacity="0"/></radialGradient>`;
    celestial = `<circle cx="${x}" cy="${y}" r="100" fill="url(#glow)"/>`
      + `<circle cx="${x}" cy="${y}" r="30" fill="#F4F8FC"/>`
      + `<circle cx="${x-9}" cy="${y-6}" r="6" fill="#D6E2EE" opacity="0.7"/>`
      + `<circle cx="${x+8}" cy="${y+8}" r="4" fill="#D6E2EE" opacity="0.6"/>`
      + `<circle cx="${x+4}" cy="${y-10}" r="3" fill="#D6E2EE" opacity="0.5"/>`;
  }
  const stars = ph.night ? STARS : '';
  const fog = ph.night ? FOG_NIGHT : FOG_DAY;
  const snow = ph.night ? '' : SNOW;
  const ridge = `<path d="${RIDGES.far}" fill="url(#rf)" opacity="0.55"/>`
    + `<path d="${RIDGES.mid}" fill="url(#rm)" opacity="0.75"/>`
    + `<path d="${RIDGES.near}" fill="url(#rn)" opacity="0.95"/>`;

  return `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="900" viewBox="0 0 1600 900" preserveAspectRatio="xMidYMax slice">`
    + `<defs><linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">${skyStops}</linearGradient>`
    + `<linearGradient id="rf" x1="0" y1="0" x2="0" y2="1">${mk(ph.mtn.far)}</linearGradient>`
    + `<linearGradient id="rm" x1="0" y1="0" x2="0" y2="1">${mk(ph.mtn.mid)}</linearGradient>`
    + `<linearGradient id="rn" x1="0" y1="0" x2="0" y2="1">${mk(ph.mtn.near)}</linearGradient>`
    + `${celestialGrads}</defs>`
    + `<rect width="1600" height="900" fill="url(#sky)"/>`
    + stars
    + ridge
    + snow
    + fog
    + celestial
    + `</svg>`;
}

/* ---------- 生成 CSS ---------- */
const header = `/* ============================================================
   山野皮肤 · 浅色模式 · 太阳东升西落（按当前时间自动切换）
   由 generate-sun-moon-css.mjs 生成，勿手改；改源脚本后重新运行。
   时段：夜晚 20:00–05:59 / 日出 06:00–08:59 / 上午 09:00–11:59
         正午 12:00–14:59 / 下午 15:00–17:59 / 日落 18:00–19:59
   ============================================================ */`;

const blocks = PHASES.map((ph) => {
  const uri = "data:image/svg+xml," + encodeURIComponent(buildSvg(ph));
  return `/* ${ph.name} */\nhtml body[data-outdoor]:not([data-ds-dark-theme])[data-sun-phase="${ph.id}"] .wSkVaW_root[data-phase="hero"] {\n  background-image: url("${uri}");\n  background-size: cover;\n  background-position: center bottom;\n  background-repeat: no-repeat;\n}`;
});

writeFileSync(OUT, `${header}\n\n${blocks.join("\n\n")}\n`, "utf8");
console.log(`written: ${OUT}`);
