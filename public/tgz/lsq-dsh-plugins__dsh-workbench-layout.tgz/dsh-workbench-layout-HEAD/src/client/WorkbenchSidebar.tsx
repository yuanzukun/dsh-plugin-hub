import { useEffect } from 'react'
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots'
import type { WorkbenchController } from './controller.ts'
import type { WorkbenchKey } from './locales.ts'
import { FileTree } from './FileTree.tsx'
import { GitPanel } from './GitPanel.tsx'
import { TerminalPanel } from './TerminalPanel.tsx'
import { useWorkbench } from './use-workbench.ts'
import { WorkbenchRail } from './WorkbenchRail.tsx'
import { resolveWorkbenchWorkspace } from './workspace-binding.ts'
import css from './Workbench.module.css'

export type WorkbenchSidebarProps = PropsRuntime<'sidebar.workspaces'> & PropsLocale<'workbench'> & {
  controller: WorkbenchController
}

/** Sidebar replacement body; the official shell, brand, controls, and settings stay mounted. */
export function WorkbenchSidebar({ wide, expandSidebar, useSessions, useWorkspaces, controller, t }: WorkbenchSidebarProps) {
  const state = useWorkbench(controller)
  const sessionId = useSessions(snapshot => snapshot.current)
  const workspace = useWorkspaces(snapshot => resolveWorkbenchWorkspace(
    snapshot.items,
    sessionId,
    snapshot.recentWorkspaceId,
  ))
  const workspaceId = workspace?.workspaceId
  useEffect(() => { controller.setWorkspace(workspaceId) }, [controller, workspaceId])
  if (!wide) {
    return (
      <WorkbenchRail
        controller={controller}
        workspaceId={workspaceId}
        expandSidebar={expandSidebar}
        t={t}
      />
    )
  }
  return (
    <div className={css.sidebarBody}>
      {state.sidebarMode === 'git'
        ? <GitPanel controller={controller} workspaceId={workspaceId} t={t} />
        : state.sidebarMode === 'terminal'
          ? <TerminalPanel controller={controller} workspaceId={workspaceId} t={t} />
          : <FileTree controller={controller} workspaceId={workspaceId} workspacePath={workspace?.path} t={t} />}
    </div>
  )
}
