# 更新日志 (Changelog)

本项目的所有重要变更都会记录在此文件中。

格式基于 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/)，
版本号遵循 [语义化版本](https://semver.org/lang/zh-CN/)。

## [0.3.2] - 2026-09-30

### 修复

- 适配 DSH 0.2.0：设置页的「宠物」入口不再消失（此前只在 `settings.section` 已被声明时才注册成功）
  - 根因：`settings.section` 由 `ui-settings-general` 在注册侧边栏外壳时才声明，而它何时激活由自身的 `inject` 集合决定，所以直接调用 `slots.register()` 的成败完全取决于激活顺序。0.2.0 给 `ui-settings-general` 的 `inject` 加了 `shortcuts`（要先等 `ui-shortcuts` 提供服务），声明因此变晚；本插件只依赖 `slots`，会先激活，注册被 `slot "settings.section" is not declared` 拒绝并被 `try/catch` 吞掉，设置页静默少一项
  - 修法：改走声明感知的 `ctx.slots.inject('settings.section', …)`——声明已存在时立即注册，否则等声明出现后自动注册，声明消失时自动注销。两种顺序都正确，0.1.7 与 0.2.0 均为同一份代码，无需分叉
  - 顺带修正宠物根节点上的 `data-card-state` 诊断属性：它此前用「register 是否返回 disposer」判断，而 `inject` 在等待期间也会返回停止函数，会把未挂载误报为 `ok`；现在按真实挂载状态更新

## [0.3.1] - 2026-09-24

### 修复

- 适配 DSH 0.1.7：client 端 `inject` 不再声明 `settingsScope`（该服务在 0.1.7 中已被移除，新 API 为 `configForms`）
  - 本插件的设置面板一直走自身 HTTP API，client 半从未真正使用 `settingsScope`，移除声明后旧版 DSH 同样正常
  - 此前在 DSH 0.1.7-rc.1 上会因等待不存在的服务导致插件永远 pending、无法激活

## [0.3.0] - 2026-08-19

### 新增

- 悬停互动增加「思考 review」动作：鼠标移上宠物时，随机展示「挥手 waving」或「思考 review」
  - 此前悬停固定展示挥手；「思考」原本只出现在设置页状态预览里（无对应 DSH 事件），现在真实互动中也能看到

### 变更

- 悬停动画由固定挥手改为随机二选一（50% 挥手 / 50% 思考），播完 1.6 秒后恢复实时状态

## [0.2.0] - 2026-08-19

### 新增

- 右下角悬浮宠物：可拖拽、点击展开菜单；状态随 DSH agent 活动实时切换
- 精灵动作状态机（9 行）：空闲 / 向右跑 / 向左跑 / 挥手 / 跳跃 / 失败 / 等待 / 奔跑 / 思考（仅预览）
- DSH 事件联动：任务开始跳跃、执行中奔跑（左右轮播）、完成挥手、失败、等待批准等
- 独立设置页（设置 → 宠物）：大小（40%–150%）、启用/关闭、宠物切换、删除
- 图库：搜索（名称/类型）、精灵图预览、总数统计、加载更多
- 一键安装：粘贴安装代码 / 宠物链接 / slug 即可安装宠物
- 内置 4 个《全职猎人》宠物（Gon 小杰 / Killua 奇犽 / Kurapika 酷拉皮卡 / Leorio 雷欧力），首次激活自动播种到 `~/.petdex/pets/`，同名不覆盖、删除不复活
- 数据与 Petdex 桌面端兼容共用（`~/.petdex/pets/<slug>/`：pet.json + spritesheet）
- SSE 实时推送状态变化（`/petdex-pet/events`）