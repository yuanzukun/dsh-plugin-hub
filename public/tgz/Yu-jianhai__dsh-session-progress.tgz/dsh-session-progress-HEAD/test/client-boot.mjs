/**
 * Boots the browser half against a stub DOM and drives real SSE frames.
 *
 * The band is painted entirely by `render()` writing `--dsp-p` into the
 * dynamic stylesheet, and the frame handler swallows exceptions -- so a
 * single undefined identifier inside `render()` makes the band vanish with
 * no visible error. Only running the factory catches that class of bug.
 */
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const sheets = []
const errors = []

const makeStyle = (tag) => ({
  tag,
  attrs: {},
  style: {},
  textContent: '',
  setAttribute(name, value) {
    this.attrs[name] = value
  },
  remove() {
    const index = sheets.indexOf(this)
    if (index >= 0) sheets.splice(index, 1)
  },
  appendChild() {},
})

const ReactStub = {
  createElement: (type, props, ...children) => ({ type, props, children }),
  useState: (initial) => [typeof initial === 'function' ? initial() : initial, () => {}],
  useEffect() {},
  useLayoutEffect() {},
  useMemo: (factory) => factory(),
  useCallback: (fn) => fn,
  useRef: (value) => ({ current: value }),
}

const streamHandlers = new Map()
let constructed = 0

class EventSourceStub {
  constructor(url) {
    this.url = url
    constructed += 1
  }

  addEventListener(name, handler) {
    streamHandlers.set(name, handler)
  }

  close() {}
}

const svgs = []

globalThis.window = globalThis
globalThis.document = {
  createElement: (tag) => makeStyle(tag),
  // The water filter is an <svg><filter>; the plugin appends it to <body>.
  createElementNS: (namespace, tag) => {
    const node = makeStyle(tag)
    node.namespaceURI = namespace
    node.setAttribute = (name, value) => {
      node.attributes = node.attributes || {}
      node.attributes[name] = String(value)
    }
    node.style = {}
    node.innerHTML = ''
    svgs.push(node)
    return node
  },
  head: {
    append(...nodes) {
      sheets.push(...nodes)
    },
    appendChild(node) {
      sheets.push(node)
    },
  },
  body: {
    appendChild(node) {
      svgs.push(node)
    },
    hasAttribute: () => false,
  },
  documentElement: { style: {}, attributes: [] },
  getElementById: () => null,
  querySelectorAll: () => [],
  addEventListener() {},
  removeEventListener() {},
}
globalThis.getComputedStyle = () => ({
  colorScheme: 'dark',
  backgroundColor: 'rgb(23, 24, 28)',
})
globalThis.MutationObserver = class {
  observe() {}
  disconnect() {}
}
globalThis.matchMedia = () => ({
  matches: true,
  addEventListener() {},
  removeEventListener() {},
})
const fetchUrls = []
globalThis.fetch = async (url) => {
  fetchUrls.push(String(url))
  return {
    ok: true,
    json: async () => ({
      version: 1,
      config: { color: '#90AFFF', opacity: 0.6, style: 'band', intervalMs: 30000 },
      effort: 'off',
      total: 0,
      entries: [],
    }),
  }
}
globalThis.EventSource = EventSourceStub
const realError = console.error
console.error = (...args) => {
  errors.push(args.map(String).join(' '))
  realError(...args)
}

let clientModule = null
globalThis.__ModuleLoader__ = {
  load({ factory }) {
    clientModule = factory((name) => (name === 'react' ? ReactStub : {}))
  },
}

const moduleUrl = pathToFileURL(
  path.join(import.meta.dirname, '..', 'lib', 'client.js'),
).href
await import(moduleUrl)

assert.ok(clientModule, 'the factory ran and exported a module')
assert.equal(clientModule.name, 'dsh-session-progress-client')

const injected = []
const cleanups = []
const ctx = {
  effect(fn) {
    const cleanup = fn()
    cleanups.push(cleanup)
    return cleanup
  },
  slots: {
    inject(name) {
      injected.push(name)
    },
    register() {
      return () => {}
    },
  },
}

clientModule.apply(ctx)

const sheetOf = (suffix) => sheets.find((item) => item.attrs['data-plugin-css'] === suffix)
const base = sheetOf('dsh-session-progress')
const lookSheet = sheetOf('dsh-session-progress-look')
const dynamic = sheetOf('dsh-session-progress-rules')
const theme = sheetOf('dsh-session-progress-theme')

assert.ok(base, 'base stylesheet injected')
assert.ok(lookSheet, 'look stylesheet injected')
assert.ok(dynamic, 'dynamic stylesheet injected')
assert.ok(theme, 'theme stylesheet injected')
assert.ok(sheets.indexOf(base) < sheets.indexOf(lookSheet), 'look sheet comes after base')
assert.match(lookSheet.textContent, /#90AFFF/i, 'look sheet painted the default colour at boot')
// A column body is a flex container with a definite height in the rail panel,
// so its children shrink instead of overflowing: twelve archived turns got
// squashed to 39px each and the column never grew a scrollbar (0.8.1). Nothing
// inside a column may shrink; the geometry itself is checked in
// dev/history-scroll.html, this only stops the rule from being dropped.
assert.match(base.textContent, /\.dsp-column-body > \*/)
// One sample is one line and the raw JSON is behind a click (0.10.0): the
// eight-field meta row plus a <pre> under every sample is what made the log
// look like a dump.
// The water filter must actually exist in the document, or `url(#dsp-water)`
// silently paints nothing and the two higher qualities look like `low`.
// A frozen panel is usually a frozen poll loop, so the request must carry the
// client tag and a beat counter: `/debug` shows exactly where the loop stopped.
// The panels only run inside a real React render, which this harness does not
// perform, so the request shape is guarded at the source level instead.
const clientSource = readFileSync(new URL('../lib/client.js', import.meta.url), 'utf8')
assert.ok(clientSource.includes('&beat=${logStore.beat}&client=${CLIENT_TAG}'), 'the log poll identifies the client build')
assert.ok(clientSource.includes('&applied=${logStore.applied}'), 'the log poll reports which version it holds')
assert.ok(clientSource.includes('AbortSignal.timeout(LOG_FETCH_MS)'), 'a hung poll cannot stall the panel forever')
assert.ok(clientSource.includes('logStore.inflightSince'), 'a hung request is forgiven by the watchdog')
assert.ok(svgs.some((node) => String(node.innerHTML).includes('feDisplacementMap')), 'water filter injected')
assert.ok(svgs.some((node) => String(node.innerHTML).includes('id="dsp-water"')), 'water filter is addressable')
assert.match(base.textContent, /\.dsp-row-line/)
assert.match(base.textContent, /\.dsp-row-detail/)
assert.match(base.textContent, /\.dsp-row-note\s*\{[\s\S]*?text-overflow: ellipsis/)
// The flowing highlight lives on ::before and must not outlive the band: it is
// clipped to the filled width and its opacity rides --dsp-o, so a row that is
// not running shows nothing at all.
// Band motion (drift / cross / rainbow) is generated into the look sheet because
// its travel comes from the period constant. UI motion inside the log panel is
// static and allowed to live here — but the two must not get mixed up.
assert.doesNotMatch(
  base.textContent,
  /@keyframes\s+dsp-(drift|cross|rainbow|flow)/,
  'band keyframes belong to the look sheet, not the base sheet',
)
assert.match(base.textContent, /@keyframes dsp-unfold/, 'expanding a row unfolds it')
assert.match(base.textContent, /@keyframes dsp-panel-in/, 'the panel itself arrives')
assert.match(
  base.textContent,
  /@media \(prefers-reduced-motion: reduce\) \{[\s\S]*?\.dsp-row-detail[\s\S]*?animation: none/,
  'the panel motion respects a reduced-motion preference',
)
assert.match(base.textContent, /::before\s*\{[\s\S]*?animation: none;/)
assert.match(base.textContent, /width: var\(--dsp-p, 0%\)/, 'the sweep is bounded by its own width, not a clip')
assert.match(base.textContent, /::before\s*\{[\s\S]*?opacity: var\(--dsp-o/)
assert.match(base.textContent, /flex: none/)
assert.equal(constructed, 1, 'one progress stream opened')
assert.ok(injected.includes('sidebar.panellist'), 'rail entry registered')
assert.ok(injected.includes('main'), 'panel body registered')

// The initial /config fetch paints the saved look before any frame arrives.
await new Promise((resolve) => setTimeout(resolve, 0))
assert.match(lookSheet.textContent, /#90AFFF/i)

// A frame carrying one running session must reach the dynamic sheet. With a
// ReferenceError inside render() this stays empty and the band disappears.
const emit = (payload) => {
  const handler = streamHandlers.get('message')
  assert.ok(handler, 'message handler attached')
  handler({ data: JSON.stringify(payload) })
}

emit({
  type: 'progress',
  sessions: [{ id: 'session-abc-123', p: 62, o: 0.6 }],
  look: { color: '#90AFFF', opacity: 0.6, style: 'band' },
})

assert.equal(errors.length, 0, `frame handled without errors, got: ${errors.join(' | ')}`)
assert.match(dynamic.textContent, /--dsp-p:62%/, 'painted the session progress')
assert.match(dynamic.textContent, /--dsp-o:0\.6/, 'painted the opacity')

// A host broadcast of a different look repaints the band.
emit({
  type: 'progress',
  sessions: [{ id: 'session-abc-123', p: 62, o: 0.5 }],
  look: { color: '#FF8800', opacity: 0.5, style: 'glow' },
})
assert.match(lookSheet.textContent, /#FF8800/, 'broadcast look applied')
assert.match(lookSheet.textContent, /box-shadow/, 'glow style applied')

// An unsaved preview survives the next broadcast (the 0.4.1 regression is
// covered directly in test/look.mjs; here we only need the empty-frame path).
emit({ type: 'progress', sessions: [], look: { color: '#FF8800', opacity: 0.5, style: 'glow' } })
assert.equal(dynamic.textContent, '', 'empty frame clears every rule')

for (const cleanup of cleanups) {
  if (typeof cleanup === 'function') cleanup()
}
assert.equal(sheets.length, 0, 'cleanup removed every stylesheet')

console.error = realError
console.log('client boot assertions passed')
