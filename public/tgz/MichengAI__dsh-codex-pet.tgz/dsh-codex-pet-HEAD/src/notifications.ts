/** 多会话通知与真实交互适配；不打开后台会话、不替用户作决定。 */
import { IDLE, selectActivity, type Activity } from './model.ts';
import { selectedSessionId, type Sessions, type Store } from './activity.ts';
export interface Question { id: string; question: string; detail?: string; options?: { label: string; description?: string }[]; multiSelect?: boolean }
export interface Answers { answers: { id: string; selected: string[]; custom?: string }[] }
export interface Pending {
  kind?: unknown; key?: string; sessionId?: string; toolName?: string; reason?: string;
  questions?: readonly Question[];
  answer?: (value: any) => Promise<void>;
}
export interface Notice extends Activity {
  id: string; token: string; updatedAt: number;
  request?: { key: string; kind: string; toolName?: string; reason?: string; questions?: readonly Question[] };
}
export interface NotificationState { items: Notice[]; activity: Activity; hidden: number }
/** 用户关掉通知时记下的两件事：
 *  mark —— 宿主 SessionSummary.updatedAt（最后一条用户消息时间），只在用户发新消息时前进；
 *  token —— 引擎本地的 `${round}:${requestKey}`，用来区分同一会话里的第几轮。
 *  单看 token 跨引擎会复用（round 从 0 起算），单看 mark 又会漏掉同一句话排队的下一轮，
 *  所以两个都留，跨引擎再用 record.fresh 兜住「引擎刚启动、还没观察过任何轮次」的情形。 */
export interface DismissedNotice { mark: number; token: string; pose: string }
/**
 * 已知边界（不是缺陷，改不了也不打算改）：
 * 1. 宿主 lastPromptAt 只认 `source.kind === 'user'` 的消息；插件注入的 prompt（如 simplify 的
 *    followup）不推进 mark，所以「关掉通知 → 收起宠物 → 该会话被这类注入跑完 → 再展开」会被旧记录压住。
 *    同一引擎内不受影响：注入会产生 turn/start，round 变化后 token 不同，照常提醒。
 * 2. 收起期间「队列里自动跑的下一轮」同样没有新消息，也会被压住（与更早的 token-only 方案一致）。
 */
export type NoticeCommand = { type: 'open'; id: string; token: string } | { type: 'dismiss'; id: string; token: string } | { type: 'approve' | 'reject' | 'answer'; id: string; token: string; requestKey: string; answers?: Answers } | { type: 'stop'; id: string; token: string } | { type: 'restore' };
type RecordState = { fresh?: boolean; round: number; running: boolean; completion: boolean; error: string | null; revision: number; updatedAt: number; lastPose: string; requestKey?: string; awaitingStart?: boolean; finished?: string; snapshotError?: string | null; suppressStopCompletion?: boolean };
const priority: Record<string, number> = { waiting: 0, failed: 1, review: 2, running: 3 };
const lifetime: Record<string, number> = { failed: 3600000, waiting: 86400000, review: 604800000 };
export function validateAnswers(questions: readonly Question[], value: Answers | undefined): Answers {
  if (!value || !Array.isArray(value.answers) || value.answers.length !== questions.length) throw new Error('请回答所有问题');
  const ids = new Set<string>();
  for (const answer of value.answers) {
    const question = questions.find(q => q.id === answer.id);
    if (!question || ids.has(answer.id) || !Array.isArray(answer.selected)) throw new Error('问题已变化，请重新回答');
    ids.add(answer.id);
    if (new Set(answer.selected).size !== answer.selected.length || answer.selected.some(label => !question.options?.some(option => option.label === label))) throw new Error('选项无效');
    if (answer.custom !== undefined && (typeof answer.custom !== 'string' || answer.custom.length > 10000)) throw new Error('回答过长');
    if (!answer.selected.length && !answer.custom?.trim()) throw new Error('请回答所有问题');
    if (!question.multiSelect && (answer.selected.length > 1 || (answer.selected.length > 0 && !!answer.custom?.trim()))) throw new Error('单选问题只能提交一种回答');
  }
  return value;
}
/** carried：跨引擎实例保留的「已关闭通知」记录，收起/展开宠物后不会重复弹出。 */
export function createNotifications(sessions: Sessions, pending: Store<ReadonlyMap<string, Pending>>, notify: (state: NotificationState) => void, now = Date.now, carried: Map<string, DismissedNotice> = new Map()) {
  const records = new Map<string, RecordState>();
  const bindings = new Map<string, { binding: NonNullable<ReturnType<Sessions['binding']>>; off: () => void }>();
  const dismissed = carried;
  const busy = new Set<string>();
  const answered = new Set<string>();
  let state: NotificationState = { items: [], activity: IDLE, hidden: 0 }, latestFirst = false;
  let publishing = false;
  let lastPublished = '';
  /** 会话冷却后仍保留绑定的宽限时间：留出读到最后一次错误/完成状态的机会。 */
  const HOT_GRACE_MS = 30_000;
  /** 每个会话最近一次「值得通知」的时间戳，决定是否还需要打开（retain）该会话。 */
  const hotUntil = new Map<string, number>();
  const releaseBinding = (id: string) =>
    (sessions as Sessions & { releaseBinding?(id: string): void }).releaseBinding?.(id);
  const publish = () => {
    if (publishing) return;
    publishing = true;
    try {
      // 目录清理一轮只做一次：以前每次 binding() 都要全量扫一遍，热点会话多时是 N×M。
      (sessions as Sessions & { sweepBindings?(): void }).sweepBindings?.();
      const list = sessions.list.getSnapshot(), requests = pending.getSnapshot(), statuses = sessions.status?.getSnapshot();
      const current = selectedSessionId(list);
      const stamp = now();
      // 子代理由宿主路由管理，不能作为独立通知绑定或操作。
      const ids = new Set(list.ids.filter(id => list.byId[id] && list.byId[id].origin !== 'subagent'));
      for (const id of records.keys()) if (!ids.has(id)) { records.delete(id); dismissed.delete(id); hotUntil.delete(id); }
      for (const [id, bound] of bindings) if (!ids.has(id)) { bound.off(); bindings.delete(id); records.delete(id); dismissed.delete(id); hotUntil.delete(id); }
      const items: Notice[] = []; let hidden = 0;
      for (const id of ids) {
        const row = list.byId[id]; if (!row) continue;
        const status = statuses?.get(id);
        const request = requests.get(id);
        // 打开会话（retain → open）会把该会话历史全量拉到客户端，代价随会话数线性增长。
        // 因此只有真可能产生通知的会话才打开：运行中 / 等待处理 / 有新完成 / 当前会话。
        // 目录行只有 running/origin（SessionSummary），待处理与未读完成只能看 sessionStatus。
        const active = !!status?.running || !!row.running || !!request || !!status?.pendingInteraction || !!status?.completionUnread || id === current;
        if (active) hotUntil.set(id, stamp + HOT_GRACE_MS);
        const hot = active || (hotUntil.get(id) ?? 0) > stamp;
        if (!hot) {
          hotUntil.delete(id);
          const previous = bindings.get(id);
          if (previous) { previous.off(); bindings.delete(id); }
          releaseBinding(id);
          // 冷却且没有任何历史通知的会话（绝大多数）完全不参与本轮计算。
          if (!records.has(id)) continue;
        }
        const binding = hot ? sessions.binding(id) : undefined;
        let record = records.get(id);
        if (!record) { record = { fresh: true, round: 0, running: row.running, completion: !!status?.completionUnread, error: null, revision: binding?.eventSource?.getSnapshot().revision ?? -1, updatedAt: row.updatedAt ?? now(), lastPose: '' }; records.set(id, record); }
        const previous = bindings.get(id);
        if (binding && (previous?.binding.session !== binding.session || previous.binding.eventSource !== binding.eventSource)) {
          previous?.off();
          record.revision = binding.eventSource?.getSnapshot().revision ?? record.revision;
          const offSession = binding.session.subscribe(publish), offEvents = binding.eventSource?.subscribe(publish);
          bindings.set(id, { binding, off: () => { offSession(); offEvents?.(); } });
        }
        const snapshot = binding?.session.getSnapshot();
        // 当前详细快照为准；后台 running 使用持续更新的列表，避免冷快照覆盖它。
        const running = status?.running ?? (id === current ? snapshot?.running ?? row.running : row.running);
        if (running && !record.running) { record.fresh = false; record.round++; record.awaitingStart = true; record.finished = undefined; record.completion = false; record.error = null; record.suppressStopCompletion = false; record.updatedAt = now(); }
        const events = binding?.eventSource?.getSnapshot();
        if (events && record.revision !== events.revision) {
          record.revision = events.revision;
          if (events.change.kind === 'append') for (const entry of events.change.entries) {
            if (entry.type !== 'event') continue;
            if (entry.event.type === 'turn/start') { record.fresh = false; if (!record.awaitingStart) record.round++; record.awaitingStart = false; record.finished = undefined; record.completion = false; record.error = null; }
            if (entry.event.type === 'turn/end') { record.finished = entry.event.data?.reason?.kind; record.completion = record.finished === 'completed'; record.updatedAt = now(); }
          } else if (events.change.kind === 'replace') record.suppressStopCompletion = true;
        }
        const stopped = !running && record.running;
        record.running = running;
        // 未打开会话时读不到 Agent 错误快照，保留上一次记录到的错误即可。
        if (snapshot !== undefined) {
          const agentError = snapshot.lastAgentError ?? snapshot.promptError?.error?.message ?? null;
          if (agentError && agentError !== record.snapshotError) record.error = agentError;
          record.snapshotError = agentError;
        }
        // 主视图完成往往不设 completionUnread；没有 turn/end 时用运行下落补完成，历史 replace 不补。
        if (stopped && !record.suppressStopCompletion && !record.finished && !record.error) { record.completion = true; record.updatedAt = now(); }
        if (status?.completionUnread && !running && (!record.finished || record.finished === 'completed')) record.completion = true;
        const activity = selectActivity([{ id, title: row.title ?? row.displayTitle, running, waiting: !!request, error: running ? null : record.error, completed: !running && record.completion }]);
        if (activity.pose === 'idle') continue;
        if ((record.lastPose && record.lastPose !== activity.pose) || record.requestKey !== request?.key) record.updatedAt = now();
        record.lastPose = activity.pose; record.requestKey = request?.key;
        const token = `${record.round}:${request?.key ?? ''}`;
        // 只有「同一次完成」才保持隐藏：用户又发消息（mark 前进）或本轮已变（token 变）都重新提醒；
        // 引擎刚启动时 round 从 0 起算，用 fresh 表示「还没观察过轮次」，此时认 mark 就够。
        const muted = dismissed.get(id);
        // pose 也参与判断：关掉「运行中」的通知不该顺带吞掉这一轮完成后的提醒。
        if (
          muted !== undefined &&
          muted.pose === activity.pose &&
          muted.mark === (row.updatedAt ?? 0) &&
          (muted.token === token || record.fresh === true)
        ) { hidden++; continue; }
        const ttl = lifetime[activity.pose]; if (ttl && now() - record.updatedAt >= ttl) continue;
        items.push({ ...activity, id, token, updatedAt: record.updatedAt, request: request && typeof request.key === 'string' ? { key: request.key, kind: String(request.kind), toolName: request.toolName, reason: request.reason, questions: request.questions } : undefined });
      }
      items.sort((a, b) => (latestFirst ? 0 : priority[a.pose] - priority[b.pose]) || b.updatedAt - a.updatedAt || a.id.localeCompare(b.id));
      state = { items, hidden, activity: items[0] ?? IDLE };
      const signature = JSON.stringify(state);
      if (signature !== lastPublished) { lastPublished = signature; notify(state); }
    } finally { publishing = false; }
  };
  const offList = sessions.list.subscribe(publish), offPending = pending.subscribe(publish), offStatus = sessions.status?.subscribe(publish);
  publish(); const timer = setInterval(publish, 1000);
  return {
    getSnapshot: () => state,
    sort(latest: boolean) { latestFirst = latest; publish(); },
    async command(command: NoticeCommand): Promise<void> {
      if (command.type === 'restore') { dismissed.clear(); publish(); return; }
      const item = state.items.find(item => item.id === command.id && item.token === command.token);
      if (!item) throw new Error('这条通知已更新，请使用最新通知');
      if (command.type === 'dismiss') { dismissed.set(item.id, { mark: sessions.list.getSnapshot().byId[item.id]?.updatedAt ?? 0, token: item.token, pose: item.pose }); publish(); return; }
      if (command.type === 'open') {
        if (!sessions.open) throw new Error('宿主未提供打开会话能力');
        sessions.open(item.id);
        if (item.pose === 'review') dismissed.set(item.id, { mark: sessions.list.getSnapshot().byId[item.id]?.updatedAt ?? 0, token: item.token, pose: item.pose });
        publish();
        return;
      }
      if (command.type === 'stop') {
        if (item.pose !== 'running') throw new Error('任务状态已变化');
        const session = sessions.binding(item.id)?.session;
        if (!session?.cancel) throw new Error('宿主未提供停止任务能力');
        if (busy.has(item.id)) throw new Error('正在提交，请勿重复操作');
        busy.add(item.id);
        try { const result = await session.cancel(); if (!result.ok) throw new Error(result.error?.message ?? '停止失败'); } finally { busy.delete(item.id); }
        return;
      }
      const request = pending.getSnapshot().get(item.id);
      if (!request || request.key !== command.requestKey || request.sessionId && request.sessionId !== item.id || !request.answer) throw new Error('请求已结束或已更换，请查看最新会话');
      if (answered.has(request.key!)) throw new Error('该请求已经提交');
      if (busy.has(item.id)) throw new Error('正在提交，请勿重复操作');
      let answer: unknown;
      if (request.kind === 'approval' && (command.type === 'approve' || command.type === 'reject')) answer = command.type === 'approve' ? 'allowed-once' : 'rejected';
      else if ((request.kind === 'question' || request.kind === 'plan-review') && command.type === 'answer') answer = validateAnswers(request.questions ?? [], command.answers);
      else throw new Error('此请求不支持该操作');
      busy.add(item.id);
      try { await request.answer(answer); answered.add(request.key!); } finally { busy.delete(item.id); publish(); }
    },
    dispose() { offList(); offPending(); offStatus?.(); clearInterval(timer); for (const value of bindings.values()) value.off(); bindings.clear(); },
  };
}
