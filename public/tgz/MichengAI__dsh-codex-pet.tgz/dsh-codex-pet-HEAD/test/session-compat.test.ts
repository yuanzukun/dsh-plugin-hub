import test from 'node:test';
import assert from 'node:assert/strict';
import { compatibleSessions } from '../src/session-compat.ts';
import { selectedSessionId, type Sessions } from '../src/activity.ts';

test('打开会话只走传入的导航，不再回退宿主 sessions.open', () => {
  const opened: string[] = [];
  const withNavigate = compatibleSessions({
    list: {},
    binding: () => undefined,
    async create() { return 's'; },
  } as unknown as Sessions, id => opened.push(id));
  withNavigate.open!('s1');
  assert.deepEqual(opened, ['s1']);
  const missing = compatibleSessions({
    list: {},
    binding: () => undefined,
    open(id: string) { opened.push(`host:${id}`); },
    async create() { return 's'; },
  } as unknown as Sessions);
  assert.equal(missing.open, undefined);
  assert.deepEqual(opened, ['s1']);
});

test('binding 缺失时用 retain 补观察引用，离开目录后释放', () => {
  const released: string[] = [];
  const session = { getSnapshot: () => ({ running: false, lastAgentError: 'boom' }), subscribe: () => () => {} };
  const eventSource = { getSnapshot: () => ({ revision: 0, change: { kind: 'replace', entries: [] } }), subscribe: () => () => {} };
  const list = { ids: ['s1'], byId: { s1: { id: 's1', running: false } } };
  const listeners = new Set<() => void>();
  const sessions = compatibleSessions({
    list: { getSnapshot: () => list, subscribe: (fn: () => void) => { listeners.add(fn); return () => listeners.delete(fn); } },
    binding: () => undefined,
    retain(id: string, options: { source: string }) {
      assert.equal(id, 's1');
      assert.equal(options.source, 'controllerOperation');
      return { binding: { session, eventSource }, ready: Promise.resolve(), release() { released.push(id); } };
    },
  } as unknown as Sessions);
  const bound = sessions.binding('s1');
  assert.equal(bound?.session.getSnapshot().lastAgentError, 'boom');
  assert.equal(bound?.eventSource, eventSource);
  list.ids = [];
  for (const listener of listeners) listener();
  sessions.binding('gone');
  assert.deepEqual(released, ['s1']);
});

test('收起宠物时 releaseBindings 释放全部 retain，再展开会重新 retain', () => {
  const released: string[] = [];
  let retains = 0;
  const session = { getSnapshot: () => ({ running: false, lastAgentError: null }), subscribe: () => () => {} };
  const eventSource = { getSnapshot: () => ({ revision: 0, change: { kind: 'replace', entries: [] } }), subscribe: () => () => {} };
  const list = { ids: ['s1', 's2'], byId: { s1: { id: 's1', running: false }, s2: { id: 's2', running: false } } };
  const sessions = compatibleSessions({
    list: { getSnapshot: () => list, subscribe: () => () => {} },
    binding: () => undefined,
    retain(id: string) {
      retains += 1;
      return { binding: { session, eventSource }, ready: Promise.resolve(), release() { released.push(id); } };
    },
  } as unknown as Sessions);
  sessions.binding('s1');
  sessions.binding('s2');
  assert.equal(retains, 2);
  sessions.releaseBindings();
  assert.deepEqual(released, ['s1', 's2']);
  // 收起后再展开宠物必须能重新拿到绑定。
  sessions.binding('s1');
  assert.equal(retains, 3);
});

test('通知引擎释放会话不会掐断创建流程持有的同一会话', () => {
  const released: string[] = [];
  let retains = 0;
  const session = { getSnapshot: () => ({ running: false, lastAgentError: null }), subscribe: () => () => {} };
  const eventSource = { getSnapshot: () => ({ revision: 0, change: { kind: 'replace', entries: [] } }), subscribe: () => () => {} };
  const list = { ids: ['s1'], byId: { s1: { id: 's1', running: false } } };
  const sessions = compatibleSessions({
    list: { getSnapshot: () => list, subscribe: () => () => {} },
    binding: () => undefined,
    retain() {
      retains += 1;
      return { binding: { session, eventSource }, ready: Promise.resolve(), release() { released.push('s1'); } };
    },
  } as unknown as Sessions);
  // 创建流程与通知引擎同时需要同一会话：只应打开一次。
  sessions.binding('s1', 'creation');
  sessions.binding('s1');
  assert.equal(retains, 1);
  // 收起宠物只摘掉通知引擎的持有，创建流程的会话仍在。
  sessions.releaseBindings();
  assert.deepEqual(released, []);
  sessions.releaseBinding('s1', 'creation');
  assert.deepEqual(released, ['s1']);
});

test('取绑定不再全量扫描目录，清理交给每轮一次 sweepBindings', () => {
  let reads = 0;
  const session = { getSnapshot: () => ({ running: false, lastAgentError: null }), subscribe: () => () => {} };
  const eventSource = { getSnapshot: () => ({ revision: 0, change: { kind: 'replace', entries: [] } }), subscribe: () => () => {} };
  const list = { ids: ['s1'], byId: { s1: { id: 's1', running: false } } };
  const sessions = compatibleSessions({
    list: { getSnapshot: () => { reads += 1; return list; }, subscribe: () => () => {} },
    binding: () => undefined,
    retain() { return { binding: { session, eventSource }, ready: Promise.resolve(), release() {} }; },
  } as unknown as Sessions);
  sessions.binding('s1');
  sessions.binding('s1');
  assert.equal(reads, 0);
  sessions.sweepBindings!();
  assert.equal(reads, 1);
});

test('当前会话只认 retainedBy.mainView', () => {
  assert.equal(selectedSessionId({
    ids: ['a', 'b'],
    byId: { a: { id: 'a', running: false }, b: { id: 'b', running: true, retainedBy: { mainView: 1 } } },
  }), 'b');
  assert.equal(selectedSessionId({
    ids: ['a'],
    byId: { a: { id: 'a', running: true } },
  }), undefined);
});
