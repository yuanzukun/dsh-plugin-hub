# dsh-session-sidebar

[![Listed on dsh-plugin.org](https://dsh-plugin.org/badges/listed.svg)](https://dsh-plugin.org/plugins/quentincrane/dsh-session-sidebar)
[![npm version](https://img.shields.io/npm/v/dsh-session-sidebar.svg?style=flat&color=38bdf8)](https://www.npmjs.com/package/dsh-session-sidebar)
[![license](https://img.shields.io/badge/license-MIT-10b981.svg?style=flat)](https://opensource.org/licenses/MIT)
[![DSH Compatibility](https://img.shields.io/badge/DSH-Web%20%7C%20Desktop-purple.svg)](https://github.com/deepseek-ai/deepseek-harness)

简体中文 | [English](README.en.md)

在 DeepSeek Harness（DSH）里同时开很多会话时，原生侧边栏只按工作区把列表铺开，哪个还在后台跑、哪个卡在审批等你处理、哪个已经跑完但还没看，往往得挨个点进去才知道。

`dsh-session-sidebar` 参考了 Codex 桌面端的侧边栏设计，同时支持 DSH Web 和 Desktop。它主要加了两样东西：集中看运行状态和未读消息的**活动视图**，以及排在工作区列表上方、方便跨项目整理常用会话的**独立置顶区**。

## 预览

![会话侧边栏全功能演示](./docs/sidebar-demo.gif)

- **置顶与拖拽排序**：常用会话既可以留在原工作区里置顶，也可以拎到顶部的独立「置顶区」（自动附带 `📁 来源工作区` 徽章）；可在菜单中切换 `按会话选择` / `独立置顶区` / `工作区内置顶`，按住会话行上下拖动即可调整顺序。
- **活动视图与优先级聚合**：点侧栏顶部的铃铛（或按 `⌥⌘U` / `Ctrl+Alt+U`）切过去，正在跑（带转圈与并发计数）、等审批、以及刚跑完还没看的会话都会收在最上面的「优先级」里，看完可以一键全部标为已读。

## 安装

Web 端和 Desktop 端的 profile 是分开的，用哪边就装哪边：

```sh
# DSH Web
dsh plugin --profile web add github:QuentinCrane/dsh-session-sidebar

# DSH Desktop
dsh plugin --profile desktop add github:QuentinCrane/dsh-session-sidebar
```

装完后刷新页面（Web）或重启客户端（Desktop）就会直接接管侧边栏，不用额外改配置文件。

> **Desktop 提示**：刚装好的 DSH Desktop 需要先打开一次客户端让它生成默认 profile，完全退出后再运行 Desktop 自带的 `dsh` 命令。如果终端里找不到 `dsh`，可以在应用菜单的 **Manage dsh Command** 里开启，详见[官方说明](https://github.com/deepseek-ai/deepseek-harness/blob/master/apps/desktop/README.md#bundled-command-runtime)。

本地调试源码时，用 `link:` 指向仓库绝对路径即可（路径含空格或 `&` 等特殊字符时记得加引号）：

```sh
dsh plugin --profile <profile> add "link:/path/to/dsh-session-sidebar"
```

## 功能与用法

### 活动视图

点侧栏顶部的铃铛按钮，或按 `⌥⌘U`（macOS）/ `Ctrl+Alt+U`（Windows、Linux）就能切换到活动视图；侧边栏收起成窄栏时点铃铛也会直接展开。后台有跑完还没看的会话时铃铛会亮蓝点，有会话卡住等你操作时亮黄点。

视图最上面的「优先级」区域会集中列出正在运行的会话（带子任务并发数）、卡在 `待审批` / `计划待审` / `待回答` 等你处理的会话，以及跑完还没点开过的未读会话（点开看一眼就会自动消掉未读）。点「优先级」右侧的 `...` 还能把已置顶或带定时任务的会话也放进来，或者开启「仅未读与运行中」、一键「全部标为已读」。

「优先级」下面按今天、昨天、星期几和具体日期排列各工作区的最近对话，每条都会带上所属工作区名称和两行最新回复预览。如果默认快捷键跟别的插件冲突，可以在 DSH 快捷键设置里搜「活动视图」改掉。

### 会话置顶

原生侧边栏只能把会话固定在它所属的工作区里。装上插件后，点侧栏右上角的设置按钮可以在三种置顶展示方式之间切换：

- **按会话选择**（`hybrid`，默认）：每条会话的 `...` 菜单里同时有「置顶到置顶区」和「在工作区置顶」，两边随时能互移。跨项目常看的会话可以放到最上面，只跟单个仓库有关的留在原目录里。
- **独立置顶区**（`space`）：所有置顶统一收进工作区列表上方的「置顶区」，每条后面都会标出来自哪个工作区。
- **工作区内置顶**（`workspace`）：隐藏顶部置顶区，跟原生侧边栏一样只固定在各自工作区最上面。

在默认的「按会话选择」模式下，把会话放到顶部置顶区后，原工作区里默认还会保留它。不想两边重复看到的话，点「置顶区」右侧的 `...` 勾上「置顶后从原工作区隐藏」就行；同一个菜单里还能改悬停图钉的默认置顶位置，以及没有置顶时是否保留空的置顶区标题。

### 分组、排序与搜索

常规侧边栏支持**按工作区**、**按工作区树**（根据目录路径自动把子目录缩进到父工作区下面）和**单列表**三种视图。在置顶区、工作区内部或单列表里，直接按住会话行上下拖动就能切到手动排序并记住顺序，随时也能在右上角设置里切回按最近更新排序。

顶部的搜索框除了即时过滤会话标题和工作区名，停顿一下还会全文搜索历史聊天内容（按 `Esc` 清空退出）。其余常用的会话与工作区操作（重命名、分叉会话、手动标为已读/未读、复制 Session ID、归档筛选、新建工作区时的目录选择弹窗）也都完整保留；归档正在运行的会话前会先弹窗确认停止。

## Agent 工具（`activity_pins`）

插件同时给模型注册了一个 `activity_pins` 工具，和前端侧边栏读写同一份状态。不想手动翻列表时，可以在对话里直接让 Agent 处理，比如：

- 「帮我看看现在有哪些会话还在跑，或者跑完了我还没看的」
- 「把当前这个会话置顶到顶部置顶区，并且在原工作区里隐藏掉」
- 「把所有未读会话都标成已读」

支持的 `action` 参数：

| `action` | 说明 | 可选参数 |
|---|---|---|
| `list_activity` | 列出各工作区会话的运行状态、未读标记和最新回复摘要 | — |
| `list_pins` | 按当前顺序返回所有已置顶会话及其所在位置（`space` / `workspace`） | — |
| `status` | 查看当前的置顶模式、默认置顶目标、已读基线和活动视图设置 | — |
| `pin_space` / `pin_workspace` | 把指定会话置顶到顶部置顶区，或在所属工作区内置顶 | `session_id` |
| `unpin` | 取消置顶（同步更新原生的 `workspaceRegistry`） | `session_id` |
| `set_pin_mode` | 修改全局置顶模式与置顶区显示选项 | `pin_mode`, `default_pin_target`, `hide_space_pins_in_workspace`, `always_show_pin_space` |
| `mark_read` / `mark_unread` | 手动把某条会话标为已读或未读 | `session_id` |
| `mark_all_read` | 把当前所有未读会话全部标为已读 | — |
| `set_activity_prefs` | 修改活动视图筛选偏好 | `show_priority_section`, `include_pinned_in_priority`, `include_scheduled_in_priority`, `unread_only` |

## 常见问题与卸载

**Web 里装好了，为什么打开 Desktop 还是原来的侧边栏？**

两边的 profile 相互独立，需要带 `--profile desktop` 再装一次（装之前记得先启动过一次 Desktop 客户端）。

**重启 DSH 之后置顶或已读状态丢了？**

状态默认存在 Host 的 `storageDomain`（`dsh-session-sidebar`）里，只有存储域打开失败时才会退回内存模式。请检查当前运行的 DSH profile 和安装插件时指定的是否一致。

**怎么停用或卸载？**

在对应 profile 的插件列表里移除 `dsh-session-sidebar`（或删掉配置中由 `cordis.patch.yml` 注入的插件条目），刷新或重启 DSH 就会恢复原生侧边栏。已保存的置顶和已读记录会留在存储域里，以后重新启用还能接着用。

## 实现与本地开发

为了算未读状态去把所有历史会话全读一遍太重了，所以插件通过 `ctx.sessionProjections`（`dshSessionSidebar`）在回合推进时增量记录结束时间和清洗过 Markdown 的最新回复摘要。置顶位置、手动排序和已读时间戳保存在 Host 的 `storageDomain` 里，并与原生的 `workspaceRegistry` 置顶双向同步；前端的视图偏好存在浏览器 `localStorage` 中，目录展开状态则直接与原生侧栏共用 `dsh.workspace.view.v5`，切换置顶或已读时不会把已展开的文件夹收起。

目录结构：

- `src/state.js`：不依赖 DOM 和网络的纯状态逻辑（投影折叠、未读判定、置顶 reducer）。
- `index.js`：Host 入口，注册会话投影、`storageDomain` 存储、`/dsh-session-sidebar/api` 接口和 `activity_pins` 工具。
- `client.js`：浏览器端界面，挂载 `sidebar.workspaces` 与 `shell.overlay` 插槽，使用 `--dsw-*` 主题变量适配亮暗色。
- `test/`：状态逻辑与客户端渲染单测。
- `docs/generate_demo_gifs.py`：生成 `docs/` 下中英文演示图的脚本（依赖 `pillow`，装有 `ffmpeg` 时体积更小）。

本地检查与单测：

```sh
npm run check
npm test
```

## License

MIT © [Quentin Crane](https://github.com/QuentinCrane)
