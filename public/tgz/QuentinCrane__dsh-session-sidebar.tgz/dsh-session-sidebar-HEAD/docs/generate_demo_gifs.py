#!/usr/bin/env python3
"""Generate the schematic demo GIFs used by README.md / README.en.md.

These GIFs are *drawn illustrations* of the sidebar interaction, not screen
recordings of a running DSH instance. Replace the files in docs/ with real
captures whenever they are available.

Run with a conda-managed Python (never the system Python):

    conda create -n dsh-docs python=3.12 pillow
    conda activate dsh-docs
    python docs/generate_demo_gifs.py

ffmpeg is optional: when present, frames are encoded with a generated global
palette (smaller, cleaner GIFs); otherwise Pillow's own GIF writer is used.
"""

from __future__ import annotations

import math
import os
import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageChops, ImageColor, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
OUT_DIR = ROOT / "docs"
FRAME_ROOT = Path("/tmp/dsh-session-sidebar-demo")

W, H = 760, 510          # final GIF size, design coordinates (top-left origin)
S = 2                    # supersampling factor
FPS = 10
DURATION = 8.0
FRAME_COUNT = int(FPS * DURATION)

WIN = (24, 24, 712, 422)          # x, y, w, h  -> right 736, bottom 446
SIDEBAR_X, SIDEBAR_W = 24, 286   # sidebar right edge = 310
HEADER_Y, HEADER_H = 58, 44
CONTENT_Y = 102

HEITI_LIGHT = "/System/Library/Fonts/STHeiti Light.ttc"
HEITI_MEDIUM = "/System/Library/Fonts/STHeiti Medium.ttc"

C = {
    "bg": "#eef2f8",
    "window": "#ffffff",
    "titlebar": "#f7f9fc",
    "sidebar": "#f9fbfd",
    "border": "#e4e9f1",
    "divider": "#e9edf4",
    "text": "#1e293b",
    "sub": "#64748b",
    "muted": "#94a3b8",
    "hover": "#eef4ff",
    "blue": "#2563eb",
    "blue_soft": "#dbeafe",
    "blue_line": "#93c5fd",
    "cyan": "#38bdf8",
    "amber": "#f59e0b",
    "amber_soft": "#fef3c7",
    "green": "#10b981",
    "bubble_me": "#e6f1ff",
    "bubble_ai": "#f3f6fa",
    "menu_shadow": "#cbd5e1",
}

T = {
    "zh": {
        "disclaimer": "交互示意 · 非实机录屏",
        "product": "dsh-session-sidebar · DSH Web",
        "app": "DeepSeek Harness",
        "workspaces": "工作区",
        "activity": "活动",
        "priority": "优先级",
        "today": "今天",
        "pinned": "置顶区",
        "search": "搜索会话或工作区…",
        "running": "运行中",
        "pending": "待审批",
        "unread": "运行完未查看",
        "subtasks": "2 个子任务运行中",
        "waiting": "等待工具审批",
        "just_now": "刚刚完成",
        "empty": "暂无进行中的会话",
        "all_read": "已全部标为已读",
        "mark_all_read": "全部标为已读",
        "unread_only": "仅未读与运行中",
        "scheduled": "定时任务",
        "pinned_to_space": "已置顶到置顶区",
        "manual_order": "已切换为手动排序",
        "pin_to_space": "置顶到置顶区",
        "pin_in_workspace": "在工作区置顶",
        "mark_read": "标为已读",
        "rename": "重命名",
        "fork": "分叉会话",
        "archive": "归档会话",
        "copy_id": "复制 Session ID",
        "pin_mode": "置顶展示方式",
        "mode_hybrid": "按会话选择",
        "mode_space": "独立置顶区",
        "mode_workspace": "工作区内置顶",
        "group_by": "分组方式",
        "order_by": "排序方式",
        "source": "来源工作区",
        "input": "给 Agent 发送消息…",
        "chat_title": "修复侧栏状态同步",
        "msg_me_1": "把未读和运行中的会话都汇总到侧栏",
        "msg_ai_1": "好的，我会接入会话状态投影，并聚合",
        "msg_ai_2": "跨工作区的运行中与未读会话。",
        "msg_me_2": "再加一个独立置顶区吧",
        "msg_ai_3": "已更新：置顶区与工作区同级排布。",
        "status_line": "2 个子任务运行中",
        "ws1": "rma-trace",
        "ws2": "dsh-session-sidebar",
        "ws3": "design-notes",
        "s1": "修复侧栏状态同步",
        "s2": "核对活动视图边界情况",
        "s3": "数据库索引优化",
        "s4": "接入工具审批流程",
        "s5": "补齐 Agent 工具单测",
        "s6": "整理 v0.2 发布说明",
        "s7": "交互稿评审",
        "card1": "修复侧栏状态同步",
        "card2": "接入工具审批流程",
        "card3": "整理 v0.2 发布说明",
        "steps_activity": ["① 点击铃铛进入活动视图", "② 运行中 / 待审批 / 未读实时汇聚", "③ 一键全部标为已读"],
        "steps_pins": ["① 会话菜单选择置顶位置", "② 独立置顶区显示来源工作区", "③ 切换置顶模式", "④ 拖拽调整顺序"],
    },
    "en": {
        "disclaimer": "Schematic demo · not a screen recording",
        "product": "dsh-session-sidebar · DSH Web",
        "app": "DeepSeek Harness",
        "workspaces": "Workspaces",
        "activity": "Activity",
        "priority": "Priority",
        "today": "Today",
        "pinned": "Pinned",
        "search": "Search sessions or workspaces…",
        "running": "Running",
        "pending": "Approval needed",
        "unread": "Completed, unread",
        "subtasks": "2 subagents running",
        "waiting": "Waiting for tool approval",
        "just_now": "Completed just now",
        "empty": "No chats in progress",
        "all_read": "All marked as read",
        "mark_all_read": "Mark all as read",
        "unread_only": "Unread & running only",
        "scheduled": "Scheduled tasks",
        "pinned_to_space": "Pinned to Pinned list",
        "manual_order": "Switched to manual order",
        "pin_to_space": "Pin to Pinned list",
        "pin_in_workspace": "Pin in workspace",
        "mark_read": "Mark as read",
        "rename": "Rename",
        "fork": "Fork session",
        "archive": "Archive session",
        "copy_id": "Copy Session ID",
        "pin_mode": "Pin display mode",
        "mode_hybrid": "Per session",
        "mode_space": "Pinned list",
        "mode_workspace": "Inside workspace",
        "group_by": "Group by",
        "order_by": "Order by",
        "source": "Source workspace",
        "input": "Message the agent…",
        "chat_title": "Fix sidebar state sync",
        "msg_me_1": "Show running and unread chats in the sidebar",
        "msg_ai_1": "Sure — I'll use session projections and",
        "msg_ai_2": "aggregate activity across workspaces.",
        "msg_me_2": "Add a standalone Pinned list too",
        "msg_ai_3": "Done: Pinned now sits beside Workspaces.",
        "status_line": "2 subagents running",
        "ws1": "rma-trace",
        "ws2": "dsh-session-sidebar",
        "ws3": "design-notes",
        "s1": "Fix sidebar state sync",
        "s2": "Check activity view edge cases",
        "s3": "Database index tuning",
        "s4": "Wire up approval flow",
        "s5": "Add agent tool tests",
        "s6": "Draft v0.2 release notes",
        "s7": "Review interaction mockups",
        "card1": "Fix sidebar state sync",
        "card2": "Wire up approval flow",
        "card3": "Draft v0.2 release notes",
        "steps_activity": ["1 · Toggle Activity View", "2 · Live running / pending / unread", "3 · Mark all as read"],
        "steps_pins": ["1 · Pin from session menu", "2 · Pinned list shows source workspace", "3 · Switch pin mode", "4 · Drag to reorder"],
    },
}


def tr(key: str, lang: str) -> str:
    return T[lang][key]


# --------------------------------------------------------------------------- #
# Drawing helpers
# --------------------------------------------------------------------------- #

_FONT_CACHE: dict[tuple, ImageFont.FreeTypeFont] = {}


def col(value):
    """Normalize hex/3-tuple colors to opaque RGBA so overlays fully cover."""
    if value is None:
        return None
    if isinstance(value, str):
        return (*ImageColor.getrgb(value), 255)
    if isinstance(value, tuple) and len(value) == 3:
        return (*value, 255)
    return value


def font(size: float, bold: bool = False) -> ImageFont.FreeTypeFont:
    key = (round(size * S, 1), bold)
    if key not in _FONT_CACHE:
        _FONT_CACHE[key] = ImageFont.truetype(
            HEITI_MEDIUM if bold else HEITI_LIGHT,
            max(1, int(round(size * S))),
            index=1,  # Heiti SC face
        )
    return _FONT_CACHE[key]


class Canvas:
    """A transparent RGBA layer whose API uses 1x design coordinates."""

    def __init__(self) -> None:
        self.im = Image.new("RGBA", (W * S, H * S), (0, 0, 0, 0))
        self.d = ImageDraw.Draw(self.im, "RGBA")

    def box(self, x, y, w, h):
        return [x * S, y * S, (x + w) * S, (y + h) * S]

    def rect(self, x, y, w, h, fill=None, outline=None, width=1):
        self.d.rectangle(self.box(x, y, w, h), fill=col(fill),
                         outline=col(outline), width=max(1, int(width * S)))

    def rr(self, x, y, w, h, r=8, fill=None, outline=None, width=1):
        self.d.rounded_rectangle(self.box(x, y, w, h), radius=r * S,
                                 fill=col(fill), outline=col(outline),
                                 width=max(1, int(width * S)))

    def ellipse(self, x, y, w, h, fill=None, outline=None, width=1):
        self.d.ellipse(self.box(x, y, w, h), fill=col(fill),
                       outline=col(outline), width=max(1, int(width * S)))

    def line(self, points, fill, width=1):
        self.d.line([(px * S, py * S) for px, py in points], fill=col(fill),
                    width=max(1, int(width * S)), joint="curve")

    def polygon(self, points, fill=None, outline=None, width=1):
        pts = [(px * S, py * S) for px, py in points]
        self.d.polygon(pts, fill=col(fill))
        if outline:
            self.d.line(pts + [pts[0]], fill=col(outline),
                        width=max(1, int(width * S)), joint="curve")

    def arc(self, x, y, w, h, start, end, fill, width=1):
        self.d.arc(self.box(x, y, w, h), start, end, fill=col(fill),
                   width=max(1, int(width * S)))

    def text(self, s, x, y, size=11, color=None, bold=False,
             anchor="lm", max_w=None):
        f = font(size, bold)
        if max_w is not None:
            limit = max_w * S
            if f.getlength(s) > limit:
                while s and f.getlength(s + "…") > limit:
                    s = s[:-1]
                s += "…"
        self.d.text((x * S, y * S), s, font=f,
                    fill=col(color or C["text"]), anchor=anchor)

    def paste(self, layer, alpha=1.0):
        other = layer.im if isinstance(layer, Canvas) else layer
        if alpha < 1.0:
            other = other.copy()
            a = other.getchannel("A").point(lambda v: int(v * alpha))
            other.putalpha(a)
        self.im.alpha_composite(other)


def dot(c: Canvas, x, y, d, color):
    c.ellipse(x - d / 2, y - d / 2, d, d, fill=color)


def icon_bell(c: Canvas, cx, cy, color, active=False):
    if active:
        c.rr(cx - 11, cy - 11, 22, 22, 7, fill=C["blue_soft"])
    c.ellipse(cx - 5, cy - 5.5, 10, 9, fill=color)
    c.rect(cx - 5.5, cy - 0.5, 11, 5, fill=color)
    c.rect(cx - 7, cy + 3.5, 14, 1.6, fill=color)
    dot(c, cx, cy + 7, 2.6, color)


def icon_search(c: Canvas, cx, cy, color):
    c.ellipse(cx - 5.5, cy - 5.5, 9, 9, outline=color, width=1.4)
    c.line([(cx + 3.5, cy + 3.5), (cx + 7, cy + 7)], color, 1.4)


def icon_sliders(c: Canvas, cx, cy, color):
    for i, off in enumerate((-4, 0, 4)):
        y = cy + off
        c.line([(cx - 7, y), (cx + 7, y)], color, 1.2)
        dot(c, cx + (-3 if i == 0 else 3 if i == 1 else -1), y, 3.4, color)


def icon_dots(c: Canvas, cx, cy, color):
    for off in (-4, 0, 4):
        dot(c, cx + off, cy, 2.2, color)


def icon_folder(c: Canvas, x, y, color):
    c.rr(x, y + 1.5, 13, 9, 2.2, fill=color)
    c.rect(x + 1, y, 6, 3, fill=color)


def icon_pin(c: Canvas, cx, cy, color):
    c.ellipse(cx - 4, cy - 5.5, 8, 6, fill=color)
    c.rect(cx - 2.6, cy - 1, 5.2, 5, fill=color)
    c.polygon([(cx - 2.6, cy + 3), (cx + 2.6, cy + 3), (cx, cy + 7)],
              fill=color)


def icon_clock(c: Canvas, cx, cy, color):
    c.ellipse(cx - 5, cy - 5, 10, 10, outline=color, width=1.3)
    c.line([(cx, cy - 2.5), (cx, cy), (cx + 2.5, cy + 1)], color, 1.2)


def icon_check(c: Canvas, x, y, color):
    c.line([(x, y + 2), (x + 3, y + 5), (x + 7, y - 2)], color, 1.5)


def spinner(c: Canvas, cx, cy, angle):
    for i in range(8):
        a = math.radians(angle + i * 45)
        px, py = cx + math.cos(a) * 5.2, cy + math.sin(a) * 5.2
        shade = ["#bfdbfe", "#93c5fd", "#60a5fa", "#3b82f6",
                 "#2563eb", "#1d4ed8", "#3b82f6", "#60a5fa"][(i + int(angle / 45)) % 8]
        dot(c, px, py, 2.6, shade)


def cursor(c: Canvas, x, y):
    pts = [(x, y), (x, y + 17), (x + 4.2, y + 13), (x + 7.4, y + 19.5),
           (x + 10.4, y + 18), (x + 7.2, y + 11.5), (x + 12.6, y + 11)]
    c.polygon(pts, fill="#ffffff", outline="#1e293b", width=1.2)


def click_ripple(c: Canvas, x, y, p):
    if p <= 0 or p >= 1:
        return
    r = 5 + 16 * p
    c.ellipse(x - r, y - r, r * 2, r * 2,
              outline=(37, 99, 235, int(180 * (1 - p))), width=1.4)


# --------------------------------------------------------------------------- #
# Static chrome
# --------------------------------------------------------------------------- #

def draw_background(lang, steps, active_step):
    c = Canvas()
    c.rect(0, 0, W, H, fill=C["bg"])
    c.text(tr("disclaimer", lang), 24, 12, 9.5, C["sub"], anchor="lm")
    f = font(9.5)
    c.text(tr("product", lang), W - 24 - f.getlength(tr("product", lang)) / S,
           12, 9.5, C["sub"], anchor="lm")

    # Window shadow (cheap layered offset instead of a blur pass).
    x, y, w, h = WIN
    c.rr(x + 2, y + 6, w, h, 16, fill="#dfe6f0")
    c.rr(x + 1, y + 3, w, h, 16, fill="#e5ebf3")

    # Step chips under the window.
    cx = 24
    for i, label in enumerate(steps):
        f = font(10)
        chip_w = f.getlength(label) / S + 26
        active = i == active_step
        c.rr(cx, 460, chip_w, 30, 8,
             fill="#e0f2fe" if active else "#ffffff",
             outline="#7dd3fc" if active else C["border"], width=1)
        c.text(label, cx + 13, 475, 10,
               "#0369a1" if active else C["sub"], bold=active, anchor="lm")
        cx += chip_w + 8
    return c


def draw_window_base():
    """White window, title bar, sidebar/main split. No sidebar content."""
    c = Canvas()
    x, y, w, h = WIN
    c.rr(x, y, w, h, 16, fill=C["window"], outline=C["border"], width=1)
    c.rr(x, y, w, 50, 16, fill=C["titlebar"])
    c.rect(x, y + 34, w, 16, fill=C["titlebar"])
    c.line([(x, y + 34), (x + w, y + 34)], C["divider"], 1)
    for i, col in enumerate(("#ff5f57", "#febc2e", "#28c840")):
        dot(c, x + 18 + i * 13, y + 17, 7, col)
    c.text("DeepSeek Harness", x + 62, y + 17, 10.5, C["sub"], anchor="lm")
    c.rect(SIDEBAR_X, HEADER_Y, SIDEBAR_W, h - 34, fill=C["sidebar"])
    c.line([(SIDEBAR_X + SIDEBAR_W, HEADER_Y),
            (SIDEBAR_X + SIDEBAR_W, y + h)], C["divider"], 1)
    return c


def draw_main_area(lang):
    """The (static) conversation pane on the right, for visual context."""
    c = Canvas()
    x, y, w, h = WIN
    left = SIDEBAR_X + SIDEBAR_W
    c.text(tr("chat_title", lang), left + 18, y + 52, 12.5, C["text"], bold=True)
    icon_dots(c, x + w - 20, y + 52, C["muted"])
    c.line([(left, y + 72), (x + w, y + 72)], C["divider"], 1)

    def bubble(bx, by, bw, bh, lines, me):
        c.rr(bx, by, bw, bh, 10, fill=C["bubble_me"] if me else C["bubble_ai"])
        for i, (text, size, col) in enumerate(lines):
            c.text(text, bx + 12, by + 15 + i * 16, size, col, anchor="lm",
                   max_w=bw - 22)

    bubble(470, 112, 246, 36, [(tr("msg_me_1", lang), 10.5, C["text"])], True)
    bubble(326, 160, 306, 58,
           [(tr("msg_ai_1", lang), 10.5, C["text"]),
            (tr("msg_ai_2", lang), 10.5, C["text"])], False)
    bubble(510, 232, 206, 36, [(tr("msg_me_2", lang), 10.5, C["text"])], True)
    bubble(326, 280, 306, 58,
           [(tr("msg_ai_3", lang), 10.5, C["text"]),
            ("", 10.5, C["text"])], False)
    for i, seg in enumerate(((0, 180), (0, 240), (0, 130))):
        c.rect(338, 306 + i * 11, seg[1], 4, fill="#dde5ef")
    dot(c, 332, 358, 6, C["cyan"])
    c.text(tr("status_line", lang), 342, 358, 9.5, C["sub"])

    c.rr(left + 16, 396, x + w - left - 32, 38, 10,
         fill="#ffffff", outline=C["border"], width=1)
    c.text(tr("input", lang), left + 30, 415, 10.5, C["muted"])
    c.ellipse(x + w - 44, 404, 22, 22, fill=C["blue"])
    c.polygon([(x + w - 36, 410), (x + w - 27, 415), (x + w - 36, 420)],
              fill="#ffffff")
    return c


def draw_header(lang, title, bell_active=False, badge=0, pulse=0.0):
    c = Canvas()
    c.text(title, SIDEBAR_X + 16, HEADER_Y + 22, 14.5, C["text"], bold=True)
    bx, by = 218, HEADER_Y + 22
    icon_bell(c, bx, by, "#475569" if not bell_active else C["blue"], bell_active)
    icon_search(c, 250, by, C["sub"])
    icon_sliders(c, 282, by, C["sub"])
    if badge >= 1:
        r = 3.1 + (0.4 * math.sin(pulse * 6) if pulse else 0)
        dot(c, bx + 10, by - 10, r * 2, C["blue"])
    if badge >= 2:
        dot(c, bx - 10, by - 10, 6, C["amber"])
    c.line([(SIDEBAR_X, HEADER_Y + HEADER_H),
            (SIDEBAR_X + SIDEBAR_W, HEADER_Y + HEADER_H)], C["divider"], 1)
    return c


def draw_search_box(lang):
    c = Canvas()
    c.rr(SIDEBAR_X + 12, 110, SIDEBAR_W - 24, 28, 8,
         fill="#ffffff", outline=C["border"], width=1)
    icon_search(c, SIDEBAR_X + 26, 124, C["muted"])
    c.text(tr("search", lang), SIDEBAR_X + 40, 124, 10, C["muted"])
    return c


def group_header(c, y, label, right=None):
    icon_folder(c, SIDEBAR_X + 14, y + 8, C["sub"])
    c.text(label, SIDEBAR_X + 34, y + 13, 11, C["sub"], bold=True)
    if right:
        icon_dots(c, SIDEBAR_X + SIDEBAR_W - 18, y + 13, C["muted"])


def session_row(c, y, title, sub, *, icon="dot", color=None, pill=None,
                hover=False, selected=False, time_text=None, badge=None,
                h=40, offset=0, sub_indent=0, dragging=False):
    x = SIDEBAR_X + 8
    w = SIDEBAR_W - 16
    yy = y + offset
    if dragging:
        c.rr(x - 2, yy - 2, w + 4, h + 2, 8,
             fill="#ffffff", outline=C["blue_line"], width=1.2)
    elif hover or selected:
        c.rr(x, yy, w, h - 2, 7, fill=C["hover"])
    if selected:
        c.rect(x, yy + 8, 2.5, h - 18, fill=C["blue"])
    if icon == "spinner":
        spinner(c, x + 15, yy + 20, color or 0)
    elif icon == "dot":
        dot(c, x + 15, yy + 20, 7, color or C["blue"])
    elif icon == "amber":
        dot(c, x + 15, yy + 20, 7, C["amber"])
    elif icon == "clock":
        icon_clock(c, x + 15, yy + 20, C["sub"])
    elif icon == "pin":
        icon_pin(c, x + 15, yy + 20, C["blue"])
    elif icon == "none":
        pass
    tx = x + 30
    c.text(title, tx, yy + 14, 11, C["text"], bold=selected, max_w=w - 62)
    c.text(sub, tx + sub_indent, yy + 29, 9.5, C["muted"],
           max_w=w - 62 - sub_indent)
    if sub_indent:
        icon_folder(c, tx, yy + 24, C["muted"])
    if pill:
        pf = font(8.5)
        pw = pf.getlength(pill) / S + 14
        c.rr(x + w - pw - 8, yy + 7, pw, 16, 8,
             fill=C["amber_soft"] if icon == "amber" else C["blue_soft"])
        c.text(pill, x + w - pw - 1, yy + 15, 8.5,
               "#b45309" if icon == "amber" else "#1d4ed8", anchor="mm")
    elif time_text:
        c.text(time_text, x + w - 8, yy + 14, 9, C["muted"], anchor="rm")
    if badge:
        bf = font(8.5)
        bw = bf.getlength(badge) / S + 12
        c.rr(tx, yy + 34, bw, 14, 5, fill="#e8eef8")
        c.text(badge, tx + bw / 2, yy + 41, 8.5, C["sub"], anchor="mm")


def priority_card(c, y, title, sub, *, stage, spinner_angle, lang, empty=False):
    x, w, h = SIDEBAR_X + 12, SIDEBAR_W - 24, 58
    c.rr(x, y, w, h, 9, fill="#ffffff", outline=C["border"], width=1)
    if stage == 0:
        c.rect(x, y + 10, 3, h - 20, fill=C["blue"])
        spinner(c, x + 18, y + 20, spinner_angle)
    elif stage == 1:
        c.rect(x, y + 10, 3, h - 20, fill=C["amber"])
        dot(c, x + 18, y + 20, 7, C["amber"])
    else:
        c.rect(x, y + 10, 3, h - 20, fill=C["cyan"])
        dot(c, x + 18, y + 20, 7, C["blue"])
    label = tr("running" if stage == 0 else "pending" if stage == 1 else "unread", lang)
    f = font(9)
    lw = f.getlength(label) / S + 14
    c.rr(x + w - lw - 10, y + 9, lw, 17, 8,
         fill=C["blue_soft"] if stage != 1 else C["amber_soft"])
    c.text(label, x + w - lw / 2 - 10, y + 17.5, 9,
           "#1d4ed8" if stage != 1 else "#b45309", anchor="mm")
    c.text(title, x + 32, y + 19, 11.2, C["text"], bold=True,
           max_w=w - lw - 50)
    c.text(sub, x + 32, y + 39, 9.5, C["sub"], max_w=w - 46)


def popover(c, x, y, w, items, header=None, highlight=-1, checks=()):
    item_h = 25
    head_h = 24 if header else 0
    h = head_h + len(items) * item_h + 12
    c.rr(x + 2, y + 4, w, h, 10, fill="#dbe3ee")
    c.rr(x, y, w, h, 10, fill="#ffffff", outline=C["border"], width=1)
    if header:
        c.text(header, x + 14, y + 14, 9.5, C["muted"], bold=True)
        c.line([(x + 10, y + head_h + 2), (x + w - 10, y + head_h + 2)],
               C["divider"], 1)
    for i, item in enumerate(items):
        iy = y + head_h + 6 + i * item_h
        if i == highlight:
            c.rr(x + 6, iy, w - 12, item_h - 3, 6, fill=C["hover"])
        c.text(item, x + 16, iy + 11, 10.2,
               C["blue"] if i == highlight else C["text"])
        if i in checks:
            icon_check(c, x + w - 24, iy + 8, C["blue"])


def toast(c, text, alpha, lang):
    if alpha <= 0:
        return
    f = font(10.5)
    w = min(f.getlength(text) / S + 34, 230)
    x = SIDEBAR_X + (SIDEBAR_W - w) / 2
    layer = Canvas()
    layer.rr(x, 400, w, 30, 9, fill="#1e293b")
    layer.text(text, x + w / 2, 415, 10.5, "#ffffff", anchor="mm")
    c.paste(layer, alpha)


# --------------------------------------------------------------------------- #
# Sidebar views
# --------------------------------------------------------------------------- #

def workspace_view(lang, *, pinned=False, pin_rows=0, hover_row=None,
                   workspace_pin=False, pin_mode="hybrid", drag=False,
                   drag_offset=0, order_swapped=False, badge=0, pulse=0.0):
    c = Canvas()
    c.paste(draw_header(lang, tr("workspaces", lang), badge=badge, pulse=pulse))
    top = 0
    if pinned:
        group_header(c, 108, tr("pinned", lang), right=True)
        rows = [tr("s1", lang), tr("s4", lang)][:max(1, pin_rows)]
        if order_swapped and len(rows) > 1:
            rows = [rows[1], rows[0]]
        sources = {tr("s1", lang): tr("ws1", lang),
                   tr("s4", lang): tr("ws2", lang)}
        if drag and len(rows) > 1:
            # Draw the stationary row first, then the dragged row on top.
            session_row(c, 180, rows[1], sources[rows[1]],
                        icon="pin", h=44, sub_indent=18)
            if drag_offset > 20:
                c.line([(SIDEBAR_X + 12, 228),
                        (SIDEBAR_X + SIDEBAR_W - 12, 228)], C["blue"], 1.6)
            session_row(c, 134, rows[0], sources[rows[0]],
                        icon="pin", h=44, offset=drag_offset,
                        sub_indent=18, dragging=True)
        else:
            for i, title in enumerate(rows):
                session_row(c, 134 + i * 46, title, sources[title],
                            icon="pin", h=44, sub_indent=18)
        top = 46 * len(rows) + 12
    else:
        c.paste(draw_search_box(lang))

    base = 148 + top
    group_header(c, base, tr("ws1", lang))
    # Space-level pins are hidden in their origin workspace in this demo.
    rows1 = [tr("s2", lang), tr("s3", lang)] if pinned else [
        tr("s1", lang), tr("s2", lang), tr("s3", lang)]
    for i, title in enumerate(rows1[:3]):
        y = base + 26 + i * 42
        is_pin = workspace_pin and i == 0
        session_row(c, y, title, tr("ws1", lang),
                    icon="pin" if is_pin else "none",
                    selected=is_pin,
                    hover=hover_row == (1, i),
                    time_text="2m")
        if hover_row == (1, i):
            icon_pin(c, SIDEBAR_X + SIDEBAR_W - 44, y + 20, C["blue"])
            icon_dots(c, SIDEBAR_X + SIDEBAR_W - 22, y + 20, C["sub"])
    base2 = base + 26 + len(rows1[:3]) * 42 + 6
    group_header(c, base2, tr("ws2", lang))
    rows2 = [tr("s5", lang)] if pinned and pin_rows >= 2 else [
        tr("s4", lang), tr("s5", lang)]
    for i, title in enumerate(rows2):
        y = base2 + 26 + i * 42
        if y < 446:
            session_row(c, y, title, tr("ws2", lang),
                        hover=hover_row == (2, i), time_text="1h")
            if hover_row == (2, i):
                icon_pin(c, SIDEBAR_X + SIDEBAR_W - 44, y + 20, C["blue"])
                icon_dots(c, SIDEBAR_X + SIDEBAR_W - 22, y + 20, C["sub"])
    return c


def activity_view(lang, *, stage, spinner_angle, read=False, badge=0,
                  pulse=0.0, menu=False, menu_highlight=-1):
    c = Canvas()
    c.paste(draw_header(lang, tr("activity", lang), bell_active=True,
                        badge=badge, pulse=pulse))
    group_header(c, 108, tr("priority", lang), right=True)
    if read:
        c.rr(SIDEBAR_X + 12, 140, SIDEBAR_W - 24, 186, 10,
             fill="#ffffff", outline=C["border"], width=1)
        icon_check(c, SIDEBAR_X + 129, 212, "#93c5fd")
        c.text(tr("empty", lang), SIDEBAR_X + SIDEBAR_W / 2, 252, 10.5,
               C["muted"], anchor="mm")
    else:
        priority_card(c, 140, tr("card1", lang),
                      tr("ws1", lang) + " · " + (tr("subtasks", lang) if stage == 0
                                                else tr("waiting", lang) if stage == 1
                                                else tr("just_now", lang)),
                      stage=stage, spinner_angle=spinner_angle, lang=lang)
        priority_card(c, 204, tr("card2", lang),
                      tr("ws2", lang) + " · " + tr("waiting", lang),
                      stage=1, spinner_angle=spinner_angle, lang=lang)
        priority_card(c, 268, tr("card3", lang),
                      tr("ws3", lang) + " · " + tr("just_now", lang),
                      stage=2, spinner_angle=spinner_angle, lang=lang)
    group_header(c, 334, tr("today", lang))
    session_row(c, 360, tr("s2", lang),
                tr("ws1", lang) + " · " + tr("msg_ai_1", lang),
                icon="none", time_text="10:24")
    session_row(c, 402, tr("s5", lang),
                tr("ws2", lang) + " · " + tr("msg_ai_3", lang),
                icon="none", time_text="09:41")
    if menu:
        popover(c, 132, 126, 190,
                [tr("unread_only", lang), tr("scheduled", lang),
                 tr("mark_all_read", lang)],
                header=tr("priority", lang), highlight=menu_highlight)
    return c


# --------------------------------------------------------------------------- #
# Timeline helpers
# --------------------------------------------------------------------------- #

def clamp(v, lo=0.0, hi=1.0):
    return max(lo, min(hi, v))


def seg(t, a, b):
    return clamp((t - a) / (b - a))


def ease(v):
    return v * v * (3 - 2 * v)


def lerp(a, b, p):
    return a + (b - a) * p


def activity_state(t):
    s = {
        "view": "workspace", "view_alpha": 0.0, "badge": 2, "pulse": t,
        "spinner": t * 220, "stage": 0, "read": False,
        "menu": False, "menu_hl": -1, "toast": "", "toast_a": 0.0,
        "pointer": None, "click": 0.0, "step": 0, "reset": 0.0,
    }
    if t < 1.2:
        s["pointer"] = None
    elif t < 2.0:
        p = ease(seg(t, 1.2, 1.9))
        s["pointer"] = (lerp(430, 218, p), lerp(300, 80, p))
        if t > 1.85:
            s["click"] = seg(t, 1.85, 2.0)
    elif t < 2.6:
        s["view_alpha"] = ease(seg(t, 2.0, 2.6))
        s["pointer"] = (218, 80)
        s["step"] = 1
    elif t < 4.6:
        s["view_alpha"] = 1.0
        s["stage"] = 0 if t < 3.3 else 1 if t < 4.0 else 2
        s["step"] = 1
        s["pointer"] = None
    elif t < 5.6:
        s["view_alpha"] = 1.0
        s["stage"] = 2
        s["step"] = 2
        p = ease(seg(t, 4.6, 5.0))
        s["pointer"] = (lerp(218, 286, p), lerp(80, 121, p))
        s["menu"] = t >= 5.0
        s["menu_hl"] = 2 if t >= 5.25 else -1
        if 5.4 <= t <= 5.6:
            s["click"] = seg(t, 5.4, 5.6)
    elif t < 6.8:
        s["view_alpha"] = 1.0
        s["stage"] = 2
        s["read"] = True
        s["badge"] = 0
        s["step"] = 2
        s["toast"] = "all_read"
        s["toast_a"] = min(seg(t, 5.65, 5.9), 1 - seg(t, 6.4, 6.8))
        s["pointer"] = (286, 121)
    elif t < 7.4:
        s["view_alpha"] = 1 - ease(seg(t, 6.8, 7.4))
        s["read"] = False
        s["badge"] = 2
        s["step"] = 0
        s["pointer"] = (218, 80)
        if 6.8 <= t <= 7.0:
            s["click"] = seg(t, 6.8, 7.0)
    else:
        s["step"] = 0
    return s


def pins_state(t):
    s = {
        "pinned": False, "pin_rows": 0, "hover": None, "mode": "hybrid",
        "workspace_pin": False, "menu": None, "menu_hl": -1, "checks": (),
        "toast": "", "toast_a": 0.0, "pointer": None, "click": 0.0,
        "drag": False, "drag_offset": 0.0, "swapped": False,
        "step": 0, "reset": 0.0,
    }
    if t < 1.0:
        s["hover"] = (1, 1)
    elif t < 1.8:
        s["hover"] = (1, 1)
        p = ease(seg(t, 1.0, 1.3))
        s["pointer"] = (lerp(330, 288, p), lerp(300, 242, p))
        if 1.3 <= t <= 1.5:
            s["click"] = seg(t, 1.3, 1.5)
        s["menu"] = "session" if t >= 1.5 else None
    elif t < 2.8:
        s["hover"] = (1, 1)
        s["menu"] = "session"
        s["menu_hl"] = 0 if t >= 2.0 else -1
        s["pointer"] = (212, 288)
        if 2.6 <= t <= 2.8:
            s["click"] = seg(t, 2.6, 2.8)
    elif t < 3.8:
        s["pinned"] = True
        s["pin_rows"] = 1
        s["step"] = 1
        s["toast"] = "pinned_to_space"
        s["toast_a"] = min(seg(t, 2.85, 3.05), 1 - seg(t, 3.5, 3.8))
        s["pointer"] = (212, 288)
    elif t < 4.8:
        s["pinned"] = True
        s["pin_rows"] = 2
        s["step"] = 2
        p = ease(seg(t, 3.8, 4.2))
        s["pointer"] = (lerp(212, 282, p), lerp(288, 80, p))
        if 4.2 <= t <= 4.4:
            s["click"] = seg(t, 4.2, 4.4)
        s["menu"] = "settings" if t >= 4.4 else None
        s["menu_hl"] = 2 if t >= 4.55 else -1
        s["checks"] = (0,)
        if 4.65 <= t <= 4.8:
            s["click"] = seg(t, 4.65, 4.8)
    elif t < 5.7:
        s["pinned"] = False
        s["workspace_pin"] = True
        s["mode"] = "workspace"
        s["step"] = 2
        s["pointer"] = (212, 288)
    elif t < 6.1:
        s["pinned"] = True
        s["pin_rows"] = 2
        s["mode"] = "space"
        s["step"] = 2
        s["pointer"] = (212, 288)
    elif t < 6.9:
        s["pinned"] = True
        s["pin_rows"] = 2
        s["mode"] = "space"
        s["step"] = 3
        s["drag"] = True
        s["drag_offset"] = 46 * ease(seg(t, 6.1, 6.9))
        s["pointer"] = (120, lerp(154, 200, ease(seg(t, 6.1, 6.9))))
    elif t < 7.2:
        s["pinned"] = True
        s["pin_rows"] = 2
        s["mode"] = "space"
        s["step"] = 3
        s["swapped"] = True
        s["toast"] = "manual_order"
        s["toast_a"] = min(seg(t, 6.9, 7.02), 1 - seg(t, 7.1, 7.2))
    else:
        s["pinned"] = True
        s["pin_rows"] = 2
        s["mode"] = "space"
        s["step"] = 3
        s["swapped"] = True
        s["reset"] = ease(seg(t, 7.25, 8.0))
    return s


# --------------------------------------------------------------------------- #
# Frame composition
# --------------------------------------------------------------------------- #

def activity_content(state, lang):
    layer = Canvas()
    if 0 < state["view_alpha"] < 1:
        a = workspace_view(lang, badge=2)
        b = activity_view(lang, stage=state["stage"],
                          spinner_angle=state["spinner"],
                          badge=state["badge"], pulse=state["pulse"])
        layer.paste(Image.blend(a.im, b.im, state["view_alpha"]))
    elif state["view_alpha"] >= 1:
        layer.paste(activity_view(lang, stage=state["stage"],
                                  spinner_angle=state["spinner"],
                                  read=state["read"], badge=state["badge"],
                                  pulse=state["pulse"], menu=state["menu"],
                                  menu_highlight=state["menu_hl"]))
    else:
        layer.paste(workspace_view(lang, badge=state["badge"],
                                   pulse=state["pulse"]))
    if state["toast_a"] > 0:
        toast(layer, tr(state["toast"], lang), state["toast_a"], lang)
    return layer


def pins_content(state, lang):
    layer = workspace_view(lang, pinned=state["pinned"],
                           pin_rows=state["pin_rows"], hover_row=state["hover"],
                           workspace_pin=state["workspace_pin"],
                           pin_mode=state["mode"], drag=state["drag"],
                           drag_offset=state["drag_offset"],
                           order_swapped=state["swapped"])
    if state["menu"] == "session":
        popover(layer, 150, 254, 196,
                [tr("pin_to_space", lang), tr("pin_in_workspace", lang),
                 tr("mark_read", lang), tr("rename", lang), tr("fork", lang),
                 tr("archive", lang), tr("copy_id", lang)],
                highlight=state["menu_hl"])
    elif state["menu"] == "settings":
        popover(layer, 108, 106, 210,
                [tr("mode_hybrid", lang), tr("mode_space", lang),
                 tr("mode_workspace", lang), tr("group_by", lang),
                 tr("order_by", lang)],
                header=tr("pin_mode", lang), highlight=state["menu_hl"],
                checks=state["checks"])
    if state["toast_a"] > 0:
        toast(layer, tr(state["toast"], lang), state["toast_a"], lang)
    return layer


def compose(scene, lang, t):
    state = activity_state(t) if scene == "activity" else pins_state(t)
    steps = tr("steps_activity" if scene == "activity" else "steps_pins", lang)
    base = draw_background(lang, steps, state["step"])

    win = draw_window_base()
    win.paste(draw_main_area(lang))
    content = (activity_content(state, lang) if scene == "activity"
               else pins_content(state, lang))
    if state["reset"] > 0:
        initial_state = (activity_state(0.0) if scene == "activity"
                         else pins_state(0.0))
        initial = (activity_content(initial_state, lang) if scene == "activity"
                   else pins_content(initial_state, lang))
        blended = Image.blend(content.im, initial.im, state["reset"])
        content = Canvas()
        content.paste(blended)
    win.paste(content)

    x, y, w, h = WIN
    mask = Image.new("L", (W * S, H * S), 0)
    ImageDraw.Draw(mask).rounded_rectangle(
        [x * S, y * S, (x + w) * S, (y + h) * S], radius=16 * S, fill=255)
    alpha = ImageChops.multiply(win.im.getchannel("A"), mask)
    win.im.putalpha(alpha)

    final = Canvas()
    final.paste(base)
    final.paste(win)
    if state["pointer"] and state["reset"] < 0.5:
        cursor(final, *state["pointer"])
    if state["click"] > 0 and state["pointer"]:
        click_ripple(final, *state["pointer"], state["click"])
    return final.im.convert("RGB").resize((W, H), Image.LANCZOS)


# --------------------------------------------------------------------------- #
# Encoding
# --------------------------------------------------------------------------- #

def encode(scene, lang, frames):
    name = f"demo-{scene}.{lang}.gif"
    out = OUT_DIR / name
    frame_dir = FRAME_ROOT / f"{scene}.{lang}"
    frame_dir.mkdir(parents=True, exist_ok=True)
    for i, frame in enumerate(frames):
        frame.save(frame_dir / f"frame_{i:03d}.png")

    ffmpeg = shutil.which("ffmpeg")
    encoded = False
    if ffmpeg:
        cmd = [
            ffmpeg, "-y", "-loglevel", "error",
            "-framerate", str(FPS),
            "-i", str(frame_dir / "frame_%03d.png"),
            "-filter_complex",
            "[0:v]split[a][b];[a]palettegen=max_colors=96:stats_mode=full[p];"
            "[b][p]paletteuse=dither=bayer:bayer_scale=2",
            "-loop", "0", str(out),
        ]
        # conda's libiconv can shadow the system one ffmpeg was linked against.
        env = os.environ.copy()
        env.pop("DYLD_LIBRARY_PATH", None)
        try:
            subprocess.run(cmd, check=True, env=env, capture_output=True)
            encoded = True
        except (subprocess.CalledProcessError, OSError):
            encoded = False
    if not encoded:
        palettes = [f.quantize(colors=96, method=Image.Quantize.FASTOCTREE,
                               dither=Image.Dither.NONE) for f in frames]
        palettes[0].save(out, save_all=True, append_images=palettes[1:],
                         duration=int(1000 / FPS), loop=0, disposal=2)
    print(f"  {name}: {out.stat().st_size / 1024:.0f} KB")


def main():
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for scene in ("activity", "pins"):
        for lang in ("zh", "en"):
            print(f"rendering {scene}.{lang} …", flush=True)
            frames = [compose(scene, lang, i / FPS) for i in range(FRAME_COUNT)]
            encode(scene, lang, frames)
    print("done")


if __name__ == "__main__":
    main()
