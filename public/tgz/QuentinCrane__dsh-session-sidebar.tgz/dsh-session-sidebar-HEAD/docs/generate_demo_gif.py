#!/usr/bin/env python3
"""Generate an authentic, high-fidelity demo GIF for dsh-session-sidebar.

Philosophy (aligned with dsh-combo):
- 100% authentic browser rendering matching the real DSH UI (light theme, system fonts, native SVGs).
- Dynamic, punchy showcase of the two killer features:
  1. Dual Pinning: Pin session from workspace to standalone Pinned Space with source workspace badge.
  2. Activity View: Notification bell triage, real-time Priority cards (running spinner,
     amber approval alert, blue unread dot), and one-click "全部标为已读" with toast feedback.
- Buttery-smooth macOS cursor easing, live rotating spinner, and clean looping under 130KB.
"""

from __future__ import annotations

import math
import os
import shutil
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
OUT_PATH = ROOT / "docs" / "sidebar-demo.gif"
STATES_DIR = Path("/tmp/dsh_states")
FRAMES_DIR = Path("/tmp/dsh_final_frames")

STATES_DIR.mkdir(parents=True, exist_ok=True)
FRAMES_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# 1. Authentic Chromium States Definition
# ---------------------------------------------------------------------------
COMMON_CSS = """
* { box-sizing: border-box; margin: 0; padding: 0; user-select: none; }
body {
  width: 528px;
  height: 580px;
  background: #f5f5f4;
  font-family: -apple-system, BlinkMacSystemFont, "SF Pro Text", "PingFang SC", "Hiragino Sans GB", sans-serif;
  color: #1f2937;
  overflow: hidden;
  padding: 16px 16px 12px 20px;
}
.top-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 36px;
  margin-bottom: 6px;
}
.pin-toggle-btn {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 14.5px;
  font-weight: 600;
  color: #1f2937;
}
.header-actions {
  display: flex;
  align-items: center;
  gap: 14px;
  color: #4b5563;
}
.bell-wrap {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}
.bell-badge {
  position: absolute;
  top: -2px;
  right: -2px;
  width: 7px;
  height: 7px;
  border-radius: 999px;
  background: #111827;
}
.empty-pin-hint {
  padding-left: 24px;
  font-size: 13.5px;
  color: #9ca3af;
  margin-bottom: 18px;
}
.projects-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 32px;
  font-size: 14px;
  font-weight: 600;
  color: #1f2937;
  margin-bottom: 8px;
}
.projects-actions {
  display: flex;
  align-items: center;
  gap: 12px;
  color: #4b5563;
}
.ws-row {
  display: flex;
  align-items: center;
  gap: 7px;
  font-size: 14px;
  font-weight: 600;
  color: #111827;
  height: 30px;
  margin-bottom: 4px;
}
.session-list {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding-left: 20px;
}
.session-row {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 34px;
  padding: 0 10px;
  border-radius: 7px;
  font-size: 13.5px;
  color: #374151;
}
.session-row.selected {
  background: #e4e4e7;
  color: #111827;
  font-weight: 500;
}
.session-row.hovered {
  background: #f3f4f6;
}
.session-title {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: 1;
}
.session-tail {
  font-size: 12.5px;
  color: #9ca3af;
  margin-left: 12px;
  flex: none;
}
.spinner-placeholder {
  width: 15px;
  height: 15px;
  flex: none;
}
.more-link {
  padding-left: 30px;
  font-size: 13px;
  color: #9ca3af;
  height: 28px;
  display: flex;
  align-items: center;
  margin-top: 4px;
}
.ws-tag {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 2px 7px;
  border-radius: 4px;
  background: #e5e7eb;
  color: #4b5563;
  font-size: 11px;
  line-height: 16px;
  flex: none;
  margin-left: 8px;
}
.context-menu {
  position: absolute;
  top: 142px;
  left: 180px;
  width: 250px;
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.12), 0 8px 10px -6px rgba(0, 0, 0, 0.08);
  padding: 4px;
  z-index: 100;
  font-size: 13px;
}
.menu-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 7px 10px;
  border-radius: 5px;
  color: #374151;
  cursor: pointer;
}
.menu-item.active {
  background: #eff6ff;
  color: #2563eb;
  font-weight: 500;
}
.menu-sep {
  height: 1px;
  background: #e5e7eb;
  margin: 4px 6px;
}
.menu-desc {
  padding: 4px 10px 6px;
  font-size: 11px;
  color: #9ca3af;
}

/* Activity View */
.act-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 36px;
  margin-bottom: 12px;
}
.act-title-wrap {
  display: flex;
  align-items: center;
  gap: 8px;
}
.act-title {
  font-size: 15px;
  font-weight: 600;
  color: #111827;
}
.badge-count {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: 1px 7px;
  border-radius: 999px;
  background: #fef3c7;
  color: #d97706;
  border: 1px solid #f59e0b;
  font-size: 11px;
  font-weight: 600;
}
.bell-active-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: #eff6ff;
  color: #2563eb;
}
.act-sec-title {
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 12px;
  font-weight: 600;
  color: #6b7280;
  margin-bottom: 8px;
  padding: 0 4px;
}
.act-cards {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-bottom: 16px;
}
.act-card {
  position: relative;
  background: #ffffff;
  border: 1px solid #e5e7eb;
  border-radius: 8px;
  padding: 9px 12px 9px 14px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.04);
}
.act-card-bar {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 3.5px;
  border-radius: 8px 0 0 8px;
}
.act-card-top {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.act-card-title {
  font-size: 13.5px;
  font-weight: 600;
  color: #111827;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.act-card-sub {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 12px;
}
.toast-pill {
  position: absolute;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%);
  background: #ffffff;
  border: 1px solid #10b981;
  border-radius: 999px;
  padding: 7px 16px;
  font-size: 12.5px;
  color: #065f46;
  font-weight: 500;
  display: flex;
  align-items: center;
  gap: 6px;
  box-shadow: 0 10px 15px -3px rgba(16, 185, 129, 0.15), 0 4px 6px -4px rgba(0, 0, 0, 0.1);
}
"""

SVG_PIN = '<svg width="15" height="15" viewBox="0 0 16 16" fill="currentColor"><path d="M9.8 2.3 13.7 6.2l-1.5 1.5-.9-.3-2.5 2.5.4 2.1-1.1 1.1-2.5-2.5-2.9 2.9-.7-.7 2.9-2.9-2.5-2.5L3.5 6.3l2.1.4 2.5-2.5-.3-.9 2-1Z"/></svg>'
SVG_CHEVRON = '<svg width="11" height="11" viewBox="0 0 12 12" fill="none" style="transform:rotate(90deg)"><path d="M4.25 2.5 7.75 6l-3.5 3.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>'
SVG_BELL = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 2.25C5.93 2.25 4.25 3.93 4.25 6v2.35c0 .62-.25 1.21-.68 1.65L2.75 10.8h10.5l-.82-.8a2.33 2.33 0 0 1-.68-1.65V6c0-2.07-1.68-3.75-3.75-3.75Z" stroke="currentColor" stroke-width="1.35" stroke-linejoin="round"/></svg>'
SVG_SEARCH = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="7.1" cy="7.1" r="4.4" stroke="currentColor" stroke-width="1.35"/><path d="m10.5 10.5 3 3" stroke="currentColor" stroke-width="1.35" stroke-linecap="round"/></svg>'
SVG_DOTS = '<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><circle cx="3.5" cy="8" r="1.15"/><circle cx="8" cy="8" r="1.15"/><circle cx="12.5" cy="8" r="1.15"/></svg>'
SVG_PLUS = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 3.25v9.5M3.25 8h9.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>'
SVG_FOLDER = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M2.25 4.25A1.25 1.25 0 0 1 3.5 3h2.85l1.3 1.5h4.85a1.25 1.25 0 0 1 1.25 1.25v6a1.25 1.25 0 0 1-1.25 1.25h-9a1.25 1.25 0 0 1-1.25-1.25v-7.5Z" stroke="currentColor" stroke-width="1.3" stroke-linejoin="round"/></svg>'
SVG_BACK = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M12.5 8H3.5M7 4.5 3.5 8 7 11.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
SVG_CHECK = '<svg width="13" height="13" viewBox="0 0 16 16" fill="none"><path d="m3.3 8.3 3 3 6.4-6.6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'

html_state1 = f"""<!doctype html><html><head><meta charset="utf-8"><style>{COMMON_CSS}</style></head><body>
  <div class="top-header">
    <div class="pin-toggle-btn">{SVG_PIN}<span>置顶区</span>{SVG_CHEVRON}</div>
    <div class="header-actions">
      <div class="bell-wrap">{SVG_BELL}<span class="bell-badge"></span></div>
      {SVG_SEARCH}{SVG_DOTS}
    </div>
  </div>
  <div class="empty-pin-hint">暂无置顶会话</div>
  <div class="projects-header">
    <div style="display:flex;align-items:center;gap:6px;"><span>项目</span>{SVG_CHEVRON}</div>
    <div class="projects-actions">{SVG_DOTS}{SVG_PLUS}</div>
  </div>
  <div class="ws-row">{SVG_FOLDER}<span>dsh-act&pins</span></div>
  <div class="session-list">
    <div class="session-row selected"><span class="session-title">你能不能模仿 dsh-combo 那...</span><div class="spinner-placeholder"></div></div>
    <div class="session-row"><span class="session-title">功能补齐插件命名建议</span><span class="session-tail">52分钟</span></div>
    <div class="session-row"><span class="session-title">插件 Bug 修复</span><span class="session-tail">2小时</span></div>
    <div class="session-row"><span class="session-title">模仿 Codex 的工作区对话列...</span><span class="session-tail">3小时</span></div>
    <div class="session-row"><span class="session-title">模仿参考项目编写 README...</span><span class="session-tail">3小时</span></div>
  </div>
  <div class="more-link">再显示 1 条</div>
  <div class="ws-row" style="margin-top:14px;">{SVG_FOLDER}<span>newest</span></div>
</body></html>"""

html_state2 = f"""<!doctype html><html><head><meta charset="utf-8"><style>{COMMON_CSS}</style></head><body>
  <div class="top-header">
    <div class="pin-toggle-btn">{SVG_PIN}<span>置顶区</span>{SVG_CHEVRON}</div>
    <div class="header-actions">
      <div class="bell-wrap">{SVG_BELL}<span class="bell-badge"></span></div>
      {SVG_SEARCH}{SVG_DOTS}
    </div>
  </div>
  <div class="empty-pin-hint">暂无置顶会话</div>
  <div class="projects-header">
    <div style="display:flex;align-items:center;gap:6px;"><span>项目</span>{SVG_CHEVRON}</div>
    <div class="projects-actions">{SVG_DOTS}{SVG_PLUS}</div>
  </div>
  <div class="ws-row">{SVG_FOLDER}<span>dsh-act&pins</span></div>
  <div class="session-list">
    <div class="session-row selected"><span class="session-title">你能不能模仿 dsh-combo 那...</span><div class="spinner-placeholder"></div></div>
    <div class="session-row hovered">
      <span class="session-title">功能补齐插件命名建议</span>
      <span style="color:#2563eb;display:flex;">{SVG_DOTS}</span>
    </div>
    <div class="session-row"><span class="session-title">插件 Bug 修复</span><span class="session-tail">2小时</span></div>
    <div class="session-row"><span class="session-title">模仿 Codex 的工作区对话列...</span><span class="session-tail">3小时</span></div>
    <div class="session-row"><span class="session-title">模仿参考项目编写 README...</span><span class="session-tail">3小时</span></div>
  </div>
  <div class="more-link">再显示 1 条</div>
  <div class="ws-row" style="margin-top:14px;">{SVG_FOLDER}<span>newest</span></div>

  <div class="context-menu">
    <div class="menu-item active">
      <div style="display:flex;align-items:center;gap:8px;">{SVG_PIN}<span>置顶到置顶区</span></div>
      {SVG_CHECK}
    </div>
    <div class="menu-item">
      <div style="display:flex;align-items:center;gap:8px;">{SVG_PIN}<span>在工作区置顶</span></div>
    </div>
    <div class="menu-sep"></div>
    <div class="menu-desc">置顶展示方式: 按会话单独双选 (Hybrid)</div>
  </div>
</body></html>"""

html_state3 = f"""<!doctype html><html><head><meta charset="utf-8"><style>{COMMON_CSS}</style></head><body>
  <div class="top-header">
    <div class="pin-toggle-btn">
      {SVG_PIN}<span>置顶区</span>
      <span style="font-size:11px;font-weight:600;padding:1px 6px;border-radius:999px;background:#e0e7ff;color:#4338ca;">1</span>
      {SVG_CHEVRON}
    </div>
    <div class="header-actions">
      <div class="bell-wrap">{SVG_BELL}<span class="bell-badge"></span></div>
      {SVG_SEARCH}{SVG_DOTS}
    </div>
  </div>

  <div class="session-list" style="padding-left:4px;margin-bottom:12px;">
    <div class="session-row" style="background:#eff6ff;border:1px solid #bfdbfe;">
      <div style="display:flex;align-items:center;gap:6px;min-width:0;flex:1;">
        {SVG_PIN}
        <span class="session-title" style="font-weight:500;color:#1e40af;">功能补齐插件命名建议</span>
      </div>
      <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
    </div>
  </div>

  <div class="projects-header">
    <div style="display:flex;align-items:center;gap:6px;"><span>项目</span>{SVG_CHEVRON}</div>
    <div class="projects-actions">{SVG_DOTS}{SVG_PLUS}</div>
  </div>
  <div class="ws-row">{SVG_FOLDER}<span>dsh-act&pins</span></div>
  <div class="session-list">
    <div class="session-row selected"><span class="session-title">你能不能模仿 dsh-combo 那...</span><div class="spinner-placeholder"></div></div>
    <div class="session-row"><span class="session-title">插件 Bug 修复</span><span class="session-tail">2小时</span></div>
    <div class="session-row"><span class="session-title">模仿 Codex 的工作区对话列...</span><span class="session-tail">3小时</span></div>
    <div class="session-row"><span class="session-title">模仿参考项目编写 README...</span><span class="session-tail">3小时</span></div>
  </div>
  <div class="more-link">再显示 1 条</div>
  <div class="ws-row" style="margin-top:14px;">{SVG_FOLDER}<span>newest</span></div>
</body></html>"""

html_state4 = f"""<!doctype html><html><head><meta charset="utf-8"><style>{COMMON_CSS}</style></head><body>
  <div class="act-header">
    <div class="act-title-wrap">
      <span style="color:#4b5563;cursor:pointer;">{SVG_BACK}</span>
      <span class="act-title">活动</span>
      <span class="badge-count">3</span>
    </div>
    <div class="header-actions">
      <div class="bell-active-btn">{SVG_BELL}</div>
      {SVG_SEARCH}{SVG_DOTS}
    </div>
  </div>

  <div class="act-sec-title">
    <span>优先级 · PRIORITY</span>
    <span style="color:#2563eb;cursor:pointer;">全部标为已读</span>
  </div>

  <div class="act-cards">
    <div class="act-card">
      <div class="act-card-bar" style="background:#10b981;"></div>
      <div class="act-card-top">
        <span class="act-card-title">你能不能模仿 dsh-combo 那...</span>
        <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
      </div>
      <div class="act-card-sub" style="color:#10b981;">
        <div class="spinner-placeholder"></div>
        <span>运行中 · 2 个子任务并发调度</span>
        <span style="margin-left:auto;color:#9ca3af;font-size:11.5px;">刚刚</span>
      </div>
    </div>

    <div class="act-card">
      <div class="act-card-bar" style="background:#f59e0b;"></div>
      <div class="act-card-top">
        <span class="act-card-title">插件 Bug 修复</span>
        <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
      </div>
      <div class="act-card-sub" style="color:#d97706;">
        <span style="width:7px;height:7px;border-radius:999px;background:#f59e0b;flex:none;"></span>
        <span>等待工具审批 · bash (执行单测与打包)</span>
        <span style="margin-left:auto;color:#9ca3af;font-size:11.5px;">12s</span>
      </div>
    </div>

    <div class="act-card">
      <div class="act-card-bar" style="background:#2563eb;"></div>
      <div class="act-card-top">
        <span class="act-card-title">功能补齐插件命名建议</span>
        <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
      </div>
      <div class="act-card-sub" style="color:#2563eb;">
        <span style="width:7px;height:7px;border-radius:999px;background:#2563eb;flex:none;"></span>
        <span>已完成 · 助手回复待查看</span>
        <span style="margin-left:auto;color:#9ca3af;font-size:11.5px;">1m</span>
      </div>
    </div>
  </div>

  <div class="act-sec-title">
    <span>今天 · TODAY</span>
  </div>
  <div class="act-card" style="box-shadow:none;background:#fafafa;">
    <div class="act-card-top">
      <span class="act-card-title" style="color:#4b5563;">模仿 Codex 的工作区对话列表</span>
      <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
    </div>
    <div style="font-size:12px;color:#9ca3af;">已接入会话状态投影与未读聚合</div>
  </div>
</body></html>"""

html_state5 = f"""<!doctype html><html><head><meta charset="utf-8"><style>{COMMON_CSS}</style></head><body>
  <div class="act-header">
    <div class="act-title-wrap">
      <span style="color:#4b5563;cursor:pointer;">{SVG_BACK}</span>
      <span class="act-title">活动</span>
      <span class="badge-count">2</span>
    </div>
    <div class="header-actions">
      <div class="bell-active-btn">{SVG_BELL}</div>
      {SVG_SEARCH}{SVG_DOTS}
    </div>
  </div>

  <div class="act-sec-title">
    <span>优先级 · PRIORITY</span>
    <span style="color:#9ca3af;">已全部标为已读</span>
  </div>

  <div class="act-cards">
    <div class="act-card">
      <div class="act-card-bar" style="background:#10b981;"></div>
      <div class="act-card-top">
        <span class="act-card-title">你能不能模仿 dsh-combo 那...</span>
        <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
      </div>
      <div class="act-card-sub" style="color:#10b981;">
        <div class="spinner-placeholder"></div>
        <span>运行中 · 2 个子任务并发调度</span>
        <span style="margin-left:auto;color:#9ca3af;font-size:11.5px;">刚刚</span>
      </div>
    </div>

    <div class="act-card">
      <div class="act-card-bar" style="background:#f59e0b;"></div>
      <div class="act-card-top">
        <span class="act-card-title">插件 Bug 修复</span>
        <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
      </div>
      <div class="act-card-sub" style="color:#d97706;">
        <span style="width:7px;height:7px;border-radius:999px;background:#f59e0b;flex:none;"></span>
        <span>等待工具审批 · bash (执行单测与打包)</span>
        <span style="margin-left:auto;color:#9ca3af;font-size:11.5px;">12s</span>
      </div>
    </div>

    <div class="act-card">
      <div class="act-card-bar" style="background:#9ca3af;"></div>
      <div class="act-card-top">
        <span class="act-card-title" style="color:#6b7280;font-weight:500;">功能补齐插件命名建议</span>
        <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
      </div>
      <div class="act-card-sub" style="color:#9ca3af;">
        <span>已读 · 会话状态机同步已完成</span>
        <span style="margin-left:auto;color:#9ca3af;font-size:11.5px;">1m</span>
      </div>
    </div>
  </div>

  <div class="act-sec-title">
    <span>今天 · TODAY</span>
  </div>
  <div class="act-card" style="box-shadow:none;background:#fafafa;">
    <div class="act-card-top">
      <span class="act-card-title" style="color:#4b5563;">模仿 Codex 的工作区对话列表</span>
      <div class="ws-tag">{SVG_FOLDER}<span>dsh-act&pins</span></div>
    </div>
    <div style="font-size:12px;color:#9ca3af;">已接入会话状态投影与未读聚合</div>
  </div>

  <div class="toast-pill">
    <span style="color:#10b981;display:flex;">{SVG_CHECK}</span>
    <span>已全部标为已读</span>
  </div>
</body></html>"""

def capture_states():
    states = [
        ("state1_idle", html_state1),
        ("state2_menu", html_state2),
        ("state3_pinned", html_state3),
        ("state4_activity", html_state4),
        ("state5_cleared", html_state5),
    ]
    for name, html in states:
        html_file = STATES_DIR / f"{name}.html"
        png_file = STATES_DIR / f"{name}.png"
        html_file.write_text(html, encoding="utf-8")
        cmd = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "--headless", "--disable-gpu", "--no-sandbox", "--disable-crash-reporter",
            "--user-data-dir=/tmp/chrome-test",
            "--window-size=528,580",
            f"--screenshot={png_file}",
            str(html_file)
        ]
        subprocess.run(cmd, check=True)
    print("All Chromium states captured.")

# ---------------------------------------------------------------------------
# 2. Frame Synthesis & Animation
# ---------------------------------------------------------------------------
def lerp(a, b, t):
    return a + (b - a) * t

def ease_in_out(t):
    return t * t * (3 - 2 * t)

def draw_cursor(d, cx, cy, click=False):
    pts = [
        (cx, cy),
        (cx, cy + 15),
        (cx + 4, cy + 12),
        (cx + 7, cy + 18),
        (cx + 9, cy + 17),
        (cx + 6, cy + 11),
        (cx + 11, cy + 11),
    ]
    s_pts = [(x + 1, y + 1.5) for x, y in pts]
    d.polygon(s_pts, fill=(0, 0, 0, 120))
    d.polygon(pts, fill=(255, 255, 255, 255))
    d.line(pts + [pts[0]], fill=(30, 30, 35, 255), width=1)
    if click:
        d.ellipse([cx - 8, cy - 8, cx + 8, cy + 8], outline=(37, 99, 235, 220), width=2)

def draw_animated_spinner(im, cx, cy, radius, angle, color=(17, 24, 39, 255)):
    d = ImageDraw.Draw(im)
    d.ellipse([cx - radius, cy - radius, cx + radius, cy + radius], outline=(209, 213, 219, 255), width=2)
    d.arc([cx - radius, cy - radius, cx + radius, cy + radius], start=angle, end=angle + 90, fill=color, width=2)

def main():
    if not (STATES_DIR / "state1_idle.png").exists():
        capture_states()

    im_state1 = Image.open(STATES_DIR / "state1_idle.png").convert("RGBA")
    im_state2 = Image.open(STATES_DIR / "state2_menu.png").convert("RGBA")
    im_state3 = Image.open(STATES_DIR / "state3_pinned.png").convert("RGBA")
    im_state4 = Image.open(STATES_DIR / "state4_activity.png").convert("RGBA")
    im_state5 = Image.open(STATES_DIR / "state5_cleared.png").convert("RGBA")

    total_frames = 50
    fps = 10

    print("Compositing 50 animation frames...")
    for f in range(total_frames):
        if 0 <= f <= 6:
            base = im_state1.copy()
        elif 7 <= f <= 11:
            base = im_state2.copy()
        elif 12 <= f <= 21:
            base = im_state3.copy()
        elif 22 <= f <= 33:
            base = im_state4.copy()
        elif 34 <= f <= 43:
            base = im_state5.copy()
        else:
            base = im_state3.copy()

        angle = (f * 36) % 360

        # Rotate spinner cleanly inside placeholder
        if 0 <= f <= 11:
            draw_animated_spinner(base, 497, 186, 7, angle, color=(17, 24, 39, 255))
        elif 12 <= f <= 21 or f >= 44:
            draw_animated_spinner(base, 497, 186, 7, angle, color=(17, 24, 39, 255))
        elif 22 <= f <= 43:
            draw_animated_spinner(base, 42, 132, 7, angle, color=(16, 185, 129, 255))

        cur_x, cur_y = 0, 0
        cur_click = False

        if 0 <= f <= 7:
            t = ease_in_out(min(1.0, f / 6.5))
            cur_x = lerp(380, 485, t)
            cur_y = lerp(450, 222, t)
            cur_click = (f == 7)
        elif 8 <= f <= 11:
            t = ease_in_out(min(1.0, (f - 7) / 4.0))
            cur_x = lerp(485, 260, t)
            cur_y = lerp(222, 168, t)
            cur_click = (f == 11)
        elif 12 <= f <= 21:
            t = ease_in_out(min(1.0, (f - 11) / 9.0))
            cur_x = lerp(260, 440, t)
            cur_y = lerp(168, 34, t)
            cur_click = (f == 21)
        elif 22 <= f <= 33:
            t = ease_in_out(min(1.0, (f - 22) / 10.0))
            cur_x = lerp(440, 480, t)
            cur_y = lerp(34, 72, t)
            cur_click = (f == 33)
        elif 34 <= f <= 42:
            t = ease_in_out(min(1.0, (f - 34) / 7.0))
            cur_x = lerp(480, 52, t)
            cur_y = lerp(72, 34, t)
            cur_click = (f == 42)
        else:
            t = ease_in_out(min(1.0, (f - 43) / 6.0))
            cur_x = lerp(52, 480, t)
            cur_y = lerp(34, 520, t)

        d = ImageDraw.Draw(base)
        draw_cursor(d, cur_x, cur_y, click=cur_click)

        base.save(FRAMES_DIR / f"frame_{f:03d}.png")

    print("Encoding with ffmpeg (palettegen diff mode)...")
    cmd = [
        "/opt/homebrew/bin/ffmpeg", "-y",
        "-framerate", str(fps),
        "-i", str(FRAMES_DIR / "frame_%03d.png"),
        "-vf", "split[s0][s1];[s0]palettegen=max_colors=128:reserve_transparent=0:stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=3:diff_mode=rectangle",
        str(OUT_PATH)
    ]
    subprocess.run(cmd, check=True)
    print(f"Generated {OUT_PATH} (size: {OUT_PATH.stat().st_size} bytes)")

if __name__ == "__main__":
    main()
