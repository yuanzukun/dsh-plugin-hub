/**
 * dsh-session-sidebar — Host plugin entry.
 *
 * Responsibilities:
 * 1. Register the `dshSessionSidebar` session projection unit (`ctx.sessionProjections`)
 *    so assistant reply snippets and turn completion timestamps fold incrementally
 *    and reach the browser without cold-session reads.
 * 2. Persist dual-pin scopes (`space` vs `workspace`), pin mode, and session
 *    read/unread watermarks in `ctx.storageDomain`.
 * 3. Expose one shared operation surface to both the Web UI (`/dsh-session-sidebar/api`)
 *    and the Agent (`activity_pins` tool), keeping `workspaceRegistry` pins in sync.
 */

import {
  PROJECTION_KEY,
  DOMAIN_NAME,
  API_ROUTE,
  TOOL_NAME,
  PIN_MODES,
  PIN_TARGETS,
  initProjectionState,
  foldSessionActivity,
  SessionSidebarProjectionSchema,
  createInitialGlobalState,
  SessionSidebarGlobalStateSchema,
  resolveEffectivePinScope,
  computeSessionUnread,
  reducePinSession,
  reduceUnpinSession,
  reduceReorderSpacePins,
  reduceSetPinConfig,
  reduceMarkRead,
  reduceMarkUnread,
  reduceMarkAllRead,
  reduceSetActivityPrefs,
} from './src/state.js'

export const name = 'dsh-session-sidebar'
export const inject = ['sessionProjections']

/** Every `activity_pins` action, in the order the tool advertises them. */
export const TOOL_ACTIONS = [
  'status',
  'list_activity',
  'list_pins',
  'pin_space',
  'pin_workspace',
  'unpin',
  'set_pin_mode',
  'mark_read',
  'mark_unread',
  'mark_all_read',
  'set_activity_prefs',
]

function readRequestJson(req, maxBytes = 65536) {
  return new Promise((resolve, reject) => {
    const chunks = []
    let total = 0
    req.on('data', (chunk) => {
      total += chunk.length
      if (total > maxBytes) {
        reject(new Error('Request body is too large.'))
        req.destroy()
        return
      }
      chunks.push(chunk)
    })
    req.on('end', () => {
      if (chunks.length === 0) {
        resolve({})
        return
      }
      try {
        const text = Buffer.concat(chunks).toString('utf8')
        resolve(text.trim() === '' ? {} : JSON.parse(text))
      } catch (error) {
        reject(error)
      }
    })
    req.on('error', reject)
  })
}

function sendJson(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
  })
  res.end(JSON.stringify(payload))
}

/**
 * Call a pin/unpin method on the optional `workspaceRegistry` service.
 * Returns false when the service or method is missing, or when the call rejects.
 */
async function pinInRegistry(registry, method, sessionId) {
  if (!registry || typeof registry[method] !== 'function') return false
  try {
    await registry[method](sessionId)
    return true
  } catch (_error) {
    return false
  }
}

function createMemoryStore() {
  let state = createInitialGlobalState()
  return {
    get: () => state,
    set: async (next) => {
      state = SessionSidebarGlobalStateSchema.parse(next)
      return state
    },
  }
}

export function apply(ctx) {
  // 1. Incremental per-session projection for assistant preview & turn completion timestamp
  ctx.sessionProjections.register({
    key: PROJECTION_KEY,
    stateVersion: 1,
    stateSchema: SessionSidebarProjectionSchema,
    init: () => initProjectionState(),
    apply: (state, event) => foldSessionActivity(state, event),
    wire: {
      viewSchema: SessionSidebarProjectionSchema,
      view: (state) => state,
    },
  })

  // 2. Durable global state backed by storageDomain (with clean memory fallback during boot/teardown)
  const fallbackStore = createMemoryStore()
  let domainHandle = null
  let domainReadyPromise = null
  let disposed = false
  let writeChain = Promise.resolve()

  ctx.effect(() => {
    disposed = false
    return () => {
      disposed = true
      const openDomain = domainHandle
      domainHandle = null
      if (openDomain !== null) {
        openDomain.close().catch(() => {})
      }
    }
  }, 'dsh-session-sidebar: domain lifecycle')

  ctx.inject(['storageDomain'], (storageCtx) => {
    storageCtx.effect(() => {
      let active = true
      domainReadyPromise = storageCtx.storageDomain.open({
        name: DOMAIN_NAME,
        version: 1,
        layout: 'single',
        global: {
          schema: SessionSidebarGlobalStateSchema,
          initial: createInitialGlobalState(),
        },
        tables: {},
      }).then((domain) => {
        if (!active || disposed) {
          domain.close().catch(() => {})
          return null
        }
        domainHandle = domain
        return domain
      }).catch((error) => {
        ctx.logger?.warn?.(`dsh-session-sidebar: storageDomain open fallback (${String(error)})`)
        return null
      })

      return () => {
        active = false
        const current = domainHandle
        domainHandle = null
        domainReadyPromise = null
        if (current !== null) {
          current.close().catch(() => {})
        }
      }
    }, 'dsh-session-sidebar: open storage domain')
  })

  async function readState() {
    if (domainHandle === null && domainReadyPromise !== null) {
      await domainReadyPromise
    }
    if (domainHandle !== null) {
      return domainHandle.global.get()
    }
    return fallbackStore.get()
  }

  function mutateState(reducer) {
    const nextOp = writeChain.then(async () => {
      const current = await readState()
      const next = SessionSidebarGlobalStateSchema.parse(reducer(current))
      if (domainHandle !== null) {
        await domainHandle.global.set(next)
      } else {
        await fallbackStore.set(next)
      }
      return next
    })
    writeChain = nextOp.then(() => {}, () => {})
    return nextOp
  }

  async function collectHostSessions(signal) {
    const workspaceRegistry = ctx.get('workspaceRegistry')
    const sessionController = ctx.get('sessionController')
    const workspaces = workspaceRegistry ? workspaceRegistry.list() : []
    const pinnedSessionIds = workspaceRegistry ? [...workspaceRegistry.pinnedSessionIds] : []
    const archivedSessionIds = workspaceRegistry ? [...workspaceRegistry.archivedSessionIds] : []

    const workspaceBySession = new Map()
    for (const ws of (workspaces ?? [])) {
      for (const sid of (ws.sessionIds ?? [])) {
        if (!workspaceBySession.has(sid)) {
          workspaceBySession.set(sid, {
            workspaceId: ws.id,
            title: ws.title,
            path: ws.path,
          })
        }
      }
    }

    let summaries = []
    if (sessionController !== undefined) {
      const abortSignal = signal ?? AbortSignal.timeout(5000)
      const listed = await sessionController.list({}, abortSignal)
      summaries = listed?.items ?? []
    }

    return {
      workspaces,
      pinnedSessionIds,
      archivedSessionIds,
      workspaceBySession,
      summaries,
    }
  }

  /**
   * Shared business operation dispatcher used by BOTH the Web UI and Agent Tool.
   */
  async function executeOperation(rawAction, params = {}, signal) {
    const action = typeof rawAction === 'string' ? rawAction.trim() : ''
    try {
      switch (action) {
        case 'status': {
          const state = await readState()
          return { ok: true, state }
        }

        case 'pin_space':
        case 'pin_workspace':
        case 'pin': {
          const sessionId = typeof (params.sessionId ?? params.session_id) === 'string'
            ? (params.sessionId ?? params.session_id).trim()
            : ''
          if (!sessionId) {
            return { ok: false, error: 'Provide session_id for this action.' }
          }
          const target = action === 'pin_space'
            ? 'space'
            : action === 'pin_workspace'
              ? 'workspace'
              : (PIN_TARGETS.includes(params.target) ? params.target : undefined)

          // The registry is optional: keep the requested scope even if it fails.
          const workspaceRegistry = ctx.get('workspaceRegistry')
          const registryPinned = await pinInRegistry(workspaceRegistry, 'pinSession', sessionId)
          const state = await mutateState((cur) => reducePinSession(cur, sessionId, target))
          return {
            ok: true,
            sessionId,
            pinScope: state.pinScopes[sessionId],
            registrySynced: registryPinned,
            pinnedSessionIds: workspaceRegistry ? [...workspaceRegistry.pinnedSessionIds] : [],
            state,
          }
        }

        case 'unpin': {
          const sessionId = typeof (params.sessionId ?? params.session_id) === 'string'
            ? (params.sessionId ?? params.session_id).trim()
            : ''
          if (!sessionId) {
            return { ok: false, error: 'Provide session_id for this action.' }
          }
          const workspaceRegistry = ctx.get('workspaceRegistry')
          const registrySynced = await pinInRegistry(workspaceRegistry, 'unpinSession', sessionId)
          const state = await mutateState((cur) => reduceUnpinSession(cur, sessionId))
          return {
            ok: true,
            sessionId,
            registrySynced,
            pinnedSessionIds: workspaceRegistry ? [...workspaceRegistry.pinnedSessionIds] : [],
            state,
          }
        }

        case 'reorder_space_pins': {
          const sessionIds = params.sessionIds ?? params.session_ids
          if (!Array.isArray(sessionIds)) {
            return { ok: false, error: 'sessionIds must be an array of session ids.' }
          }
          const state = await mutateState((cur) => reduceReorderSpacePins(cur, sessionIds))
          return { ok: true, spaceOrder: state.spaceOrder, state }
        }

        case 'set_pin_mode':
        case 'set_pin_config': {
          const pinMode = params.pinMode ?? params.pin_mode
          const defaultPinTarget = params.defaultPinTarget ?? params.default_pin_target
          if (pinMode !== undefined && !PIN_MODES.includes(pinMode)) {
            return { ok: false, error: `pin_mode must be one of: ${PIN_MODES.join(', ')}.` }
          }
          if (defaultPinTarget !== undefined && !PIN_TARGETS.includes(defaultPinTarget)) {
            return { ok: false, error: `default_pin_target must be one of: ${PIN_TARGETS.join(', ')}.` }
          }
          const patch = {
            pinMode,
            defaultPinTarget,
            hideSpacePinsInWorkspace: params.hideSpacePinsInWorkspace ?? params.hide_space_pins_in_workspace,
            alwaysShowPinSpace: params.alwaysShowPinSpace ?? params.always_show_pin_space,
            pinSpaceExpanded: params.pinSpaceExpanded ?? params.pin_space_expanded,
          }
          const state = await mutateState((cur) => reduceSetPinConfig(cur, patch))
          return { ok: true, state }
        }

        case 'mark_read': {
          const sessionId = typeof (params.sessionId ?? params.session_id) === 'string'
            ? (params.sessionId ?? params.session_id).trim()
            : ''
          if (!sessionId) {
            return { ok: false, error: 'Provide session_id for this action.' }
          }
          const ts = typeof params.timestamp === 'number' && Number.isFinite(params.timestamp)
            ? params.timestamp
            : Date.now()
          const state = await mutateState((cur) => reduceMarkRead(cur, sessionId, ts))
          return { ok: true, sessionId, readAt: state.readAt[sessionId], state }
        }

        case 'mark_unread': {
          const sessionId = typeof (params.sessionId ?? params.session_id) === 'string'
            ? (params.sessionId ?? params.session_id).trim()
            : ''
          if (!sessionId) {
            return { ok: false, error: 'Provide session_id for this action.' }
          }
          const state = await mutateState((cur) => reduceMarkUnread(cur, sessionId))
          return { ok: true, sessionId, unread: true, state }
        }

        case 'mark_all_read': {
          let ids = params.sessionIds ?? params.session_ids
          if (!Array.isArray(ids) || ids.length === 0) {
            const { summaries } = await collectHostSessions(signal)
            ids = summaries.map((s) => s.sessionId)
          }
          const now = Date.now()
          const state = await mutateState((cur) => reduceMarkAllRead(cur, ids, now))
          return { ok: true, markedCount: ids.length, state }
        }

        case 'set_activity_prefs': {
          const patch = {
            showPrioritySection: params.showPrioritySection ?? params.show_priority_section,
            includePinnedInPriority: params.includePinnedInPriority ?? params.include_pinned_in_priority,
            includeScheduledInPriority: params.includeScheduledInPriority ?? params.include_scheduled_in_priority,
            unreadOnly: params.unreadOnly ?? params.unread_only,
          }
          const state = await mutateState((cur) => reduceSetActivityPrefs(cur, patch))
          return { ok: true, activityPrefs: state.activityPrefs, state }
        }

        case 'list_activity':
        case 'list_pins': {
          const state = await readState()
          const { pinnedSessionIds, archivedSessionIds, workspaceBySession, summaries } = await collectHostSessions(signal)
          const pinnedSet = new Set(pinnedSessionIds)
          const archivedSet = new Set(archivedSessionIds)

          const items = []
          for (const s of summaries) {
            if (s.origin === 'subagent' || s.blank || archivedSet.has(s.sessionId)) continue
            const ws = workspaceBySession.get(s.sessionId)
            const titleVal = s.projections?.values?.title
            const title = typeof titleVal === 'string'
              ? titleVal
              : (typeof titleVal?.title === 'string' ? titleVal.title : '')
            const proj = s.projections?.values?.[PROJECTION_KEY] ?? {}
            const pinScope = resolveEffectivePinScope(s.sessionId, pinnedSet.has(s.sessionId), state)
            const unread = computeSessionUnread({
              sessionId: s.sessionId,
              running: s.running,
              lastTurnEndAt: proj.lastTurnEndAt ?? 0,
              updatedAt: s.updatedAt,
            }, state)

            if (action === 'list_pins' && pinScope === null) continue

            items.push({
              sessionId: s.sessionId,
              title: title || s.title || 'Untitled session',
              workspaceId: ws?.workspaceId ?? null,
              workspaceTitle: ws?.title ?? (s.cwd ? s.cwd.split(/[/\\]/).filter(Boolean).pop() ?? '' : ''),
              running: s.running,
              unread,
              pinScope,
              updatedAt: s.updatedAt,
              lastTurnEndAt: proj.lastTurnEndAt ?? 0,
              lastAssistantSnippet: proj.lastAssistantSnippet ?? '',
            })
          }

          if (action === 'list_pins') {
            const orderMap = new Map(state.spaceOrder.map((id, idx) => [id, idx]))
            items.sort((a, b) => {
              if (a.pinScope !== b.pinScope) return a.pinScope === 'space' ? -1 : 1
              const oa = orderMap.get(a.sessionId) ?? 999999
              const ob = orderMap.get(b.sessionId) ?? 999999
              if (oa !== ob) return oa - ob
              return b.updatedAt - a.updatedAt
            })
          } else {
            items.sort((a, b) => {
              if (a.running !== b.running) return a.running ? -1 : 1
              if (a.unread !== b.unread) return a.unread ? -1 : 1
              return b.updatedAt - a.updatedAt
            })
          }

          return {
            ok: true,
            pinMode: state.pinMode,
            defaultPinTarget: state.defaultPinTarget,
            runningCount: items.filter((i) => i.running).length,
            unreadCount: items.filter((i) => i.unread).length,
            items,
          }
        }

        default:
          return { ok: false, error: `Unknown action '${action}'. Use one of: ${TOOL_ACTIONS.join(', ')}.` }
      }
    } catch (error) {
      return {
        ok: false,
        error: error instanceof Error ? error.message : String(error),
      }
    }
  }

  // 3. Authenticated Web route consumed by the Client sidebar UI
  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(() => webCtx.webServer.register({
      kind: 'exact',
      path: API_ROUTE,
      handler: async (req, res) => {
        const rejection = ctx.get('connection')?.requestRejection(req)
        if (rejection !== undefined) {
          sendJson(res, rejection, { ok: false, error: 'Unauthorized.' })
          return
        }

        if (req.method === 'GET') {
          const result = await executeOperation('status')
          sendJson(res, 200, result)
          return
        }

        if (req.method === 'POST') {
          let body
          try {
            body = await readRequestJson(req)
          } catch (error) {
            sendJson(res, 400, {
              ok: false,
              error: error instanceof Error ? error.message : 'Invalid JSON body.',
            })
            return
          }
          const result = await executeOperation(body?.action, body)
          sendJson(res, result.ok ? 200 : 400, result)
          return
        }

        sendJson(res, 405, { ok: false, error: 'Method not allowed.' })
      },
    }), 'dsh-session-sidebar: api route')
  })

  // 4. Agent Tool sharing the exact same Host operation surface
  ctx.inject(['tools'], (toolsCtx) => {
    toolsCtx.effect(() => toolsCtx.tools.register({
      name: TOOL_NAME,
      description: 'Inspect running and unread sessions, mark them read or unread, and manage dual pinning: a standalone Pinned list or inside a workspace.',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: TOOL_ACTIONS,
            description: 'Operation to run.',
          },
          session_id: {
            type: 'string',
            description: 'Session to act on (pin_space, pin_workspace, unpin, mark_read, mark_unread).',
          },
          pin_mode: {
            type: 'string',
            enum: PIN_MODES,
            description: 'Pin presentation: hybrid (per session), space (all pins in the Pinned list), or workspace (all pins inside their workspace).',
          },
          default_pin_target: {
            type: 'string',
            enum: PIN_TARGETS,
            description: 'Quick-pin target in hybrid mode.',
          },
          hide_space_pins_in_workspace: {
            type: 'boolean',
            description: 'Omit Pinned-space sessions from their workspace list.',
          },
          always_show_pin_space: {
            type: 'boolean',
            description: 'Keep the Pinned list header visible when it is empty.',
          },
          show_priority_section: {
            type: 'boolean',
            description: 'Show the Priority section at the top of the activity view.',
          },
          include_pinned_in_priority: {
            type: 'boolean',
            description: 'Include pinned sessions in the Priority section.',
          },
          include_scheduled_in_priority: {
            type: 'boolean',
            description: 'Include sessions with active schedules in the Priority section.',
          },
          unread_only: {
            type: 'boolean',
            description: 'Show only running and unread sessions in the activity view.',
          },
        },
        required: ['action'],
        additionalProperties: false,
      },
      output: {
        schema: {
          type: 'object',
          properties: {
            ok: { type: 'boolean' },
          },
          required: ['ok'],
          additionalProperties: true,
        },
        render(_args, value) {
          return [{ type: 'text', text: JSON.stringify(value, null, 2) }]
        },
      },
      isConcurrencySafe(args) {
        const a = args?.action
        return a === 'status' || a === 'list_activity' || a === 'list_pins'
      },
      async execute(args, exec) {
        return executeOperation(args?.action, args ?? {}, exec?.signal)
      },
    }), 'dsh-session-sidebar: agent tool')
  })
}
