/**
 * dsh-session-sidebar — Client UI plugin (browser bundle).
 *
 * Occupies `sidebar.workspaces` at `priority: -10` and registers a floating
 * popover/modal/toast layer in `shell.overlay`.
 *
 * Key capabilities:
 * 1. Codex-inspired Activity View (`查看活动` / `⌥⌘U`):
 *    - Bell button with live running/unread indicator and active accent state.
 *    - `优先级` (Priority) card section for running, pending-interaction, and
 *      unread completed chats (plus optional Pinned / Scheduled chats), with
 *      the Codex `...` menu (`优先事项部分`, `已置顶`, `定时任务`, `仅未读与运行中`,
 *      `全部标为已读`, `归档聊天`).
 *    - Date-grouped feed (`今天`, `昨天`, `星期X`, date) showing each chat's
 *      source workspace and 2-line latest assistant reply preview.
 * 2. Dual Session Pinning:
 *    - Standalone top-level pinned area placed strictly ABOVE the project list.
 *    - Explicit choice between Original DSH Pinning (in-workspace) vs Standalone
 *      Pinned-area pinning (global + per-session hybrid).
 * 3. FLIP Transition Animations (AnimatedRows) matching native DSH:
 *    - Smooth 200ms glide on row movement/reordering, 100ms fade on enter/exit.
 *    - Chevron rotation transitions and hover marquee title scrolling.
 *    - Workspace expansion state 100% isolated and synced with native
 *      `dsh.workspace.view.v5` in localStorage so pinning/reading never collapses folders.
 * 4. Single trailing status spinner (strictly one spinner on active running rows).
 */
window.__ModuleLoader__.load({
  id: 'dsh-session-sidebar',
  factory(require) {
    const React = require('react')
    const {
      createElement: h,
      Fragment,
      Component,
      createRef,
      useState,
      useEffect,
      useLayoutEffect,
      useMemo,
      useRef,
      useCallback,
      useSyncExternalStore,
    } = React

    const PLUGIN_ID = 'dsh-session-sidebar'
    const LOCALE_NS = 'dsh-session-sidebar'
    const PROJECTION_KEY = 'dshSessionSidebar'
    const API_URL = '/dsh-session-sidebar/api'
    const DSH_NATIVE_VIEW_KEY = 'dsh.workspace.view.v5'
    const VIEW_STORAGE_KEY = 'dsh-session-sidebar:view:v2'
    const CACHE_STORAGE_KEY = 'dsh-session-sidebar:host-cache:v1'
    const FLAT_ORDER_KEY = '__flat_session_order__'
    const SESSION_WATERMARK_BASE = 5
    const SESSION_WATERMARK_AUTO_MAX = 50
    const SEARCH_DEBOUNCE_MS = 250
    const SEARCH_MAX_CHARS = 500

    // Mirrors DSH's motion tokens: --ds-transition-duration(-fast) and
    // --ds-ease-in-out. CSS reads the vars; the Web Animations API needs literals.
    const ROW_FADE_MS = 100
    const ROW_GLIDE_MS = 200
    const ROW_EASING = 'cubic-bezier(0.4, 0, 0.2, 1)'

    // -------------------------------------------------------------------------
    // Bilingual Dictionaries
    // -------------------------------------------------------------------------
    const zh = {
      'section.workspaces': '工作区',
      'section.projects': '项目',
      'section.sessions': '会话',
      'section.activity': '活动',
      'section.pinnedSpace': '置顶区',
      'section.priority': '优先级',
      'section.ungrouped': '未分组',
      'workspace.defaultName': '默认工作区',
      'workspace.add': '添加工作区',
      'session.new': '新会话',
      'session.untitled': '未命名会话',
      'activity.open': '打开活动视图',
      'activity.close': '关闭活动视图',
      'activity.backToWorkspaces': '返回工作区',
      'activity.empty': '暂无进行中的会话',
      'activity.emptyAll': '暂无最近活动',
      'activity.priorityEmpty': '暂无运行中或未读的会话',
      'activity.menu.show': '显示',
      'activity.menu.prioritySection': '优先级',
      'activity.menu.pinned': '已置顶',
      'activity.menu.scheduled': '定时任务',
      'activity.menu.unreadOnly': '仅未读与运行中',
      'activity.menu.markAllRead': '全部标为已读',
      'activity.menu.archiveChats': '查看归档会话',
      'activity.menu.backToNormal': '退出归档筛选',
      'pinSpace.empty': '暂无置顶会话',
      'pinSpace.options': '置顶区选项',
      'pinMode.label': '置顶展示方式',
      'pinMode.workspace': '工作区内置顶',
      'pinMode.space': '独立置顶区',
      'pinMode.hybrid': '按会话选择',
      'pinDefault.label': '快捷置顶位置',
      'pinDefault.space': '独立置顶区',
      'pinDefault.workspace': '工作区内',
      'pinOption.hideInWorkspace': '置顶后从原工作区隐藏',
      'pinOption.alwaysShowSpace': '没有置顶时仍显示置顶区',
      'menu.pinToSpace': '置顶到置顶区',
      'menu.unpinFromSpace': '从置顶区移除',
      'menu.moveToSpace': '移到置顶区',
      'menu.pinInWorkspace': '在工作区置顶',
      'menu.unpinInWorkspace': '取消工作区置顶',
      'menu.moveToWorkspacePin': '移到工作区',
      'menu.pinSession': '置顶会话',
      'menu.unpin': '取消置顶',
      'menu.markRead': '标为已读',
      'menu.markUnread': '标为未读',
      'menu.renameSession': '重命名',
      'menu.forkSession': '分叉会话',
      'menu.archiveSession': '归档会话',
      'menu.unarchiveSession': '取消归档',
      'menu.copySessionId': '复制 Session ID',
      'action.pinSpace': '置顶到置顶区',
      'action.pinWorkspace': '在工作区内置顶',
      'action.unpin': '取消置顶',
      'action.archive': '归档会话',
      'action.unarchive': '取消归档',
      'viewOptions.label': '视图与置顶设置',
      'groupBy.label': '分组方式',
      'groupBy.workspace': '按工作区',
      'groupBy.workspaceTree': '按工作区树',
      'groupBy.flat': '单列表',
      'orderBy.label': '排序方式',
      'orderBy.updated': '最近更新',
      'orderBy.manual': '手动排序',
      'filterBy.label': '归档筛选',
      'filter.hideArchived': '隐藏已归档',
      'filter.showArchived': '全部会话',
      'filter.onlyArchived': '仅已归档',
      'search.label': '搜索会话',
      'search.placeholder': '搜索会话或工作区…',
      'search.clear': '清除搜索',
      'search.pending': '搜索历史消息…',
      'search.noMatches': '没有匹配的会话',
      'search.hasMore': '仅显示前 {n} 条结果',
      'sessions.expandCount': '再显示 {n} 条',
      'sessions.collapse': '收起',
      'empty.workspace': '此工作区暂无会话',
      'empty.none': '暂无会话',
      'empty.noneArchived': '暂无已归档会话',
      'empty.viewOthers': '返回正常会话列表',
      'status.subagents': '{n} 个子任务运行中',
      'status.approval': '待审批',
      'status.planReview': '计划待审',
      'status.answer': '待回答',
      'status.unread': '运行完未查看',
      'status.scheduled': '含定时任务',
      'date.today': '今天',
      'date.yesterday': '昨天',
      'date.weekday.0': '星期日',
      'date.weekday.1': '星期一',
      'date.weekday.2': '星期二',
      'date.weekday.3': '星期三',
      'date.weekday.4': '星期四',
      'date.weekday.5': '星期五',
      'date.weekday.6': '星期六',
      'date.ymd': '{y}年{m}月{d}日',
      'date.md': '{m}月{d}日',
      'time.now': '刚刚',
      'time.minutes': '{n}分钟',
      'time.hours': '{n}小时',
      'time.days': '{n}天',
      'time.months': '{n}个月',
      'time.years': '{n}年',
      'workspace.actions': '工作区操作',
      'workspace.newSession': '在此工作区新建会话',
      'workspace.rename': '重命名工作区',
      'workspace.delete': '删除工作区',
      'workspace.deleteDesc': '“{name}”将从侧栏移除，文件夹与会话记录会保留。',
      'workspace.conflict': '已存在同名工作区',
      'workspace.browseTitle': '选择工作区文件夹',
      'workspace.selectThisFolder': '选择当前文件夹',
      'workspace.parentDir': '上级目录',
      'session.renameTitle': '重命名会话',
      'session.stopArchiveTitle': '停止并归档此会话？',
      'session.stopArchiveDesc': '“{name}”仍在运行，归档前会先停止。',
      'session.stopArchiveConfirm': '停止并归档',
      'session.actions': '会话操作',
      'session.unarchive': '取消归档',
      'modal.cancel': '取消',
      'modal.confirm': '确认',
      'toast.copied': 'Session ID 已复制',
      'toast.archived': '会话已归档',
      'toast.archivedNotOpenable': '已归档会话，取消归档后可打开',
      'toast.error': '操作失败：{message}',
    }

    const en = {
      'section.workspaces': 'Workspaces',
      'section.projects': 'Projects',
      'section.sessions': 'Sessions',
      'section.activity': 'Activity',
      'section.pinnedSpace': 'Pinned',
      'section.priority': 'Priority',
      'section.ungrouped': 'Ungrouped',
      'workspace.defaultName': 'Default workspace',
      'workspace.add': 'Add workspace',
      'session.new': 'New Session',
      'session.untitled': 'Untitled',
      'activity.open': 'Open activity view',
      'activity.close': 'Close activity view',
      'activity.backToWorkspaces': 'Back to workspaces',
      'activity.empty': 'No chats in progress',
      'activity.emptyAll': 'No recent activity',
      'activity.priorityEmpty': 'No running or unread chats',
      'activity.menu.show': 'Show',
      'activity.menu.prioritySection': 'Priority',
      'activity.menu.pinned': 'Pinned',
      'activity.menu.scheduled': 'Scheduled tasks',
      'activity.menu.unreadOnly': 'Unread & running only',
      'activity.menu.markAllRead': 'Mark all as read',
      'activity.menu.archiveChats': 'View archived sessions',
      'activity.menu.backToNormal': 'Exit archived filter',
      'pinSpace.empty': 'No pinned sessions yet',
      'pinSpace.options': 'Pinned list options',
      'pinMode.label': 'Pin display mode',
      'pinMode.workspace': 'Inside workspace',
      'pinMode.space': 'Pinned list',
      'pinMode.hybrid': 'Per session',
      'pinDefault.label': 'Quick-pin target',
      'pinDefault.space': 'Pinned list',
      'pinDefault.workspace': 'Inside workspace',
      'pinOption.hideInWorkspace': 'Hide pinned sessions from their workspace',
      'pinOption.alwaysShowSpace': 'Show the Pinned list when empty',
      'menu.pinToSpace': 'Pin to Pinned list',
      'menu.unpinFromSpace': 'Remove from Pinned list',
      'menu.moveToSpace': 'Move to Pinned list',
      'menu.pinInWorkspace': 'Pin in workspace',
      'menu.unpinInWorkspace': 'Unpin in workspace',
      'menu.moveToWorkspacePin': 'Move into workspace',
      'menu.pinSession': 'Pin session',
      'menu.unpin': 'Unpin session',
      'menu.markRead': 'Mark as read',
      'menu.markUnread': 'Mark as unread',
      'menu.renameSession': 'Rename',
      'menu.forkSession': 'Fork session',
      'menu.archiveSession': 'Archive session',
      'menu.unarchiveSession': 'Unarchive session',
      'menu.copySessionId': 'Copy Session ID',
      'action.pinSpace': 'Pin to Pinned list',
      'action.pinWorkspace': 'Pin in workspace',
      'action.unpin': 'Unpin',
      'action.archive': 'Archive session',
      'action.unarchive': 'Unarchive',
      'viewOptions.label': 'View & pin options',
      'groupBy.label': 'Group by',
      'groupBy.workspace': 'Workspace',
      'groupBy.workspaceTree': 'Workspace tree',
      'groupBy.flat': 'Single list',
      'orderBy.label': 'Order by',
      'orderBy.updated': 'Last updated',
      'orderBy.manual': 'Manual',
      'filterBy.label': 'Archived filter',
      'filter.hideArchived': 'Hide archived',
      'filter.showArchived': 'All sessions',
      'filter.onlyArchived': 'Archived only',
      'search.label': 'Search sessions',
      'search.placeholder': 'Search sessions or workspaces…',
      'search.clear': 'Clear search',
      'search.pending': 'Searching history…',
      'search.noMatches': 'No matching sessions',
      'search.hasMore': 'Showing the first {n} matches',
      'sessions.expandCount': '{n} more',
      'sessions.collapse': 'Show less',
      'empty.workspace': 'No sessions in this workspace',
      'empty.none': 'No sessions yet',
      'empty.noneArchived': 'No archived sessions',
      'empty.viewOthers': 'Back to active sessions',
      'status.subagents': '{n} subagents running',
      'status.approval': 'Approval needed',
      'status.planReview': 'Plan review',
      'status.answer': 'Waiting for answer',
      'status.unread': 'Completed, unread',
      'status.scheduled': 'Scheduled',
      'date.today': 'Today',
      'date.yesterday': 'Yesterday',
      'date.weekday.0': 'Sunday',
      'date.weekday.1': 'Monday',
      'date.weekday.2': 'Tuesday',
      'date.weekday.3': 'Wednesday',
      'date.weekday.4': 'Thursday',
      'date.weekday.5': 'Friday',
      'date.weekday.6': 'Saturday',
      'date.ymd': '{y}-{m}-{d}',
      'date.md': '{m}/{d}',
      'time.now': 'now',
      'time.minutes': '{n}m',
      'time.hours': '{n}h',
      'time.days': '{n}d',
      'time.months': '{n}mo',
      'time.years': '{n}y',
      'workspace.actions': 'Workspace actions',
      'workspace.newSession': 'New session in workspace',
      'workspace.rename': 'Rename workspace',
      'workspace.delete': 'Delete workspace',
      'workspace.deleteDesc': 'Removes “{name}” from the sidebar. Files and session logs are kept.',
      'workspace.conflict': 'A workspace with that name already exists.',
      'workspace.browseTitle': 'Choose workspace folder',
      'workspace.selectThisFolder': 'Select this folder',
      'workspace.parentDir': 'Parent directory',
      'session.renameTitle': 'Rename session',
      'session.stopArchiveTitle': 'Stop and archive session?',
      'session.stopArchiveDesc': '“{name}” is still running. Archiving stops it first.',
      'session.stopArchiveConfirm': 'Stop and archive',
      'session.actions': 'Session actions',
      'session.unarchive': 'Unarchive',
      'modal.cancel': 'Cancel',
      'modal.confirm': 'Confirm',
      'toast.copied': 'Session ID copied',
      'toast.archived': 'Session archived',
      'toast.archivedNotOpenable': 'Archived session. Unarchive it to open.',
      'toast.error': 'Action failed: {message}',
    }

    // -------------------------------------------------------------------------
    // Stylesheet — strictly using ONLY Theme.listTokens
    // -------------------------------------------------------------------------
    const CSS = `
@keyframes dshApSpin {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

@keyframes dshApFadeIn {
  from { opacity: 0; transform: translateY(2px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes dshApSlideDown {
  from { opacity: 0; transform: translateY(-5px); }
  to { opacity: 1; transform: translateY(0); }
}

@keyframes dshApPopoverIn {
  from {
    opacity: 0;
    transform: scale(0.96) translateY(-4px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

@keyframes dshApTooltipIn {
  from {
    opacity: 0;
    transform: translateY(-3px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes dshApToastIn {
  from {
    opacity: 0;
    transform: translate(-50%, 8px);
  }
  to {
    opacity: 1;
    transform: translate(-50%, 0);
  }
}

@keyframes dshApModalIn {
  from {
    opacity: 0;
    transform: scale(0.96) translateY(6px);
  }
  to {
    opacity: 1;
    transform: scale(1) translateY(0);
  }
}

@keyframes dshApDropIndicator {
  from {
    opacity: 0;
    transform: scaleX(0.8);
  }
  to {
    opacity: 1;
    transform: scaleX(1);
  }
}

@keyframes dshApBackdropIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

/* A ring on its own layer: opacity + scale stay on the compositor, unlike a
   pulsing box-shadow, which would repaint the sidebar every frame. */
@keyframes dshApBadgeRing {
  0% {
    transform: scale(0.85);
    opacity: 0.8;
  }
  70%, 100% {
    transform: scale(2.2);
    opacity: 0;
  }
}

@keyframes dshApToastOut {
  from {
    opacity: 1;
    transform: translate(-50%, 0);
  }
  to {
    opacity: 0;
    transform: translate(-50%, 6px);
  }
}

.dshAp_root {
  box-sizing: border-box;
  min-height: 0;
  flex: 1;
  display: flex;
  flex-direction: column;
  color: var(--dsw-alias-label-primary);
  font-size: 13.5px;
  padding-right: 4px;
}

/* Expanding the rail into the full sidebar: one short fade, never on re-render. */
.dshAp_rootWide {
  animation: dshApFadeIn var(--ds-transition-duration) var(--ds-ease-in-out);
}

.dshAp_rail {
  padding-right: 0;
  align-items: center;
  gap: 4px;
}

.dshAp_railBtn {
  position: relative;
  width: 36px;
  height: 36px;
  border-radius: var(--dsw-radius-sm);
  border: none;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  transition: background var(--ds-transition-duration-fast) var(--ds-ease-in-out), color var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_railBtn:hover {
  background: var(--dsw-alias-interactive-bg-hover);
  color: var(--dsw-alias-label-primary);
}

.dshAp_railBtnActive {
  background: color-mix(in srgb, var(--dsw-alias-brand-primary) 15%, transparent);
  color: var(--dsw-alias-brand-primary);
}

.dshAp_header {
  box-sizing: border-box;
  height: 32px;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 0 4px 0 6px;
  margin-bottom: 2px;
  flex: none;
}

.dshAp_actHeader {
  border-bottom: 1px solid var(--dsw-alias-border-l1);
  margin-bottom: 4px;
  animation: dshApSlideDown var(--ds-transition-duration) var(--ds-ease-in-out);
}

.dshAp_headerTitle {
  font-size: 12.5px;
  font-weight: 600;
  letter-spacing: 0.01em;
  color: var(--dsw-alias-label-secondary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  user-select: none;
  margin-right: auto;
  display: inline-flex;
  align-items: center;
  gap: 5px;
}

.dshAp_headerActions {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  flex: none;
}

.dshAp_iconBtn {
  position: relative;
  width: 26px;
  height: 26px;
  border-radius: var(--dsw-radius-sm);
  border: none;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  flex: none;
  transition: background var(--ds-transition-duration-fast) var(--ds-ease-in-out), color var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_iconBtn:hover {
  background: var(--dsw-alias-interactive-bg-hover);
  color: var(--dsw-alias-label-primary);
}

.dshAp_iconBtn:focus-visible,
.dshAp_row:focus-visible,
.dshAp_actRow:focus-visible,
.dshAp_menuItem:focus-visible {
  outline: var(--dsw-focus-ring-width, 2px) solid var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary));
  outline-offset: -2px;
}

.dshAp_bellBtnActive {
  background: color-mix(in srgb, var(--dsw-alias-brand-primary) 16%, transparent);
  color: var(--dsw-alias-brand-primary);
}

.dshAp_bellBtnActive:hover {
  background: color-mix(in srgb, var(--dsw-alias-brand-primary) 22%, transparent);
  color: var(--dsw-alias-brand-primary);
}

.dshAp_bellBadge {
  position: absolute;
  top: 3px;
  right: 3px;
  min-width: 7px;
  height: 7px;
  border-radius: 999px;
  background: var(--dsw-alias-brand-primary);
  box-shadow: 0 0 0 1.5px var(--dsw-specific-sidebar-fill);
  pointer-events: none;
}

.dshAp_bellBadgeWarn {
  background: var(--dsw-alias-state-warn-primary);
}

.dshAp_bellBadgeWarn::after {
  content: '';
  position: absolute;
  inset: 0;
  border-radius: inherit;
  border: 1.5px solid var(--dsw-alias-state-warn-primary);
  transform-origin: center;
  animation: dshApBadgeRing 2.4s var(--ds-ease-in-out) infinite;
  will-change: transform, opacity;
}

.dshAp_searchBar {
  flex: 1;
  min-width: 0;
  height: 28px;
  border-radius: var(--dsw-radius-sm);
  background: var(--dsw-alias-bg-layer-2);
  border: 1px solid var(--dsw-alias-border-l1);
  display: flex;
  align-items: center;
  padding: 0 6px;
  gap: 5px;
  animation: dshApSlideDown var(--ds-transition-duration) var(--ds-ease-in-out);
}

.dshAp_searchBar:focus-within {
  border-color: var(--dsw-alias-brand-primary);
}

.dshAp_searchInput {
  flex: 1;
  min-width: 0;
  border: none;
  outline: none;
  background: transparent;
  color: var(--dsw-alias-label-primary);
  font-size: 12.5px;
  line-height: 18px;
  padding: 0;
}

.dshAp_searchInput::placeholder {
  color: var(--dsw-alias-label-secondary);
  opacity: 0.72;
}

.dshAp_searchClear {
  width: 18px;
  height: 18px;
  border-radius: 999px;
  border: none;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  flex: none;
}

.dshAp_searchClear:hover {
  color: var(--dsw-alias-label-primary);
  background: var(--dsw-alias-interactive-bg-hover);
}

.dshAp_scrollArea {
  position: relative;
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overflow-x: hidden;
  padding-bottom: 14px;
  overscroll-behavior: contain;
  /* Same gutter the native session list reserves, so rows never shift. */
  scrollbar-gutter: stable;
}

.dshAp_treeContainer {
  position: relative;
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.dshAp_viewFadeIn {
  animation: dshApFadeIn var(--ds-transition-duration) var(--ds-ease-in-out);
}

.dshAp_exits {
  contain: strict;
  pointer-events: none;
  position: absolute;
  inset: 0;
  overflow: clip;
}

/* Codex Pinned Header above Projects */
.dshAp_pinnedTopSection {
  display: flex;
  flex-direction: column;
  margin-bottom: 4px;
}

.dshAp_pinnedTopHeader {
  height: 28px;
  padding: 0 4px 0 6px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 5px;
  color: var(--dsw-alias-label-secondary);
  font-size: 12px;
  font-weight: 500;
  user-select: none;
}

.dshAp_pinnedTopToggleBtn {
  border: none;
  background: transparent;
  padding: 2px 4px;
  border-radius: var(--dsw-radius-xs);
  color: var(--dsw-alias-label-secondary);
  font-size: 12.5px;
  font-weight: 500;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.dshAp_pinnedTopToggleBtn:hover {
  background: var(--dsw-alias-interactive-bg-hover);
  color: var(--dsw-alias-label-primary);
}

.dshAp_pinnedTopTitle {
  font-size: 12.5px;
  font-weight: 500;
  color: var(--dsw-alias-label-secondary);
  letter-spacing: 0.01em;
}

.dshAp_subHeaderActions {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 1px;
  flex: none;
}

.dshAp_subHeaderCount {
  min-width: 17px;
  height: 17px;
  padding: 0 5px;
  border-radius: var(--dsw-radius-sm);
  background: var(--dsw-alias-interactive-bg-active);
  color: var(--dsw-alias-label-secondary);
  font-size: 10.5px;
  font-weight: 600;
  line-height: 17px;
  text-align: center;
  flex: none;
  box-sizing: border-box;
}

/* Codex "项目 ⌄" Section Header */
.dshAp_projectsHeader {
  box-sizing: border-box;
  height: 30px;
  padding: 0 4px 0 8px;
  margin-top: 4px;
  margin-bottom: 2px;
  display: flex;
  align-items: center;
  gap: 4px;
  color: var(--dsw-alias-label-secondary);
  user-select: none;
}

.dshAp_projectsToggleBtn {
  border: none;
  background: transparent;
  padding: 2px 4px;
  border-radius: var(--dsw-radius-xs);
  color: var(--dsw-alias-label-secondary);
  font-size: 12.5px;
  font-weight: 500;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.dshAp_projectsToggleBtn:hover {
  background: var(--dsw-alias-interactive-bg-hover);
  color: var(--dsw-alias-label-primary);
}

.dshAp_projectsHeaderActions {
  margin-left: auto;
  display: inline-flex;
  align-items: center;
  gap: 2px;
}

.dshAp_miniBtn {
  width: 22px;
  height: 22px;
  border-radius: var(--dsw-radius-xs);
  border: none;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  padding: 0;
  transition: background var(--ds-transition-duration-fast) var(--ds-ease-in-out), color var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_miniBtn:hover {
  background: var(--dsw-alias-interactive-bg-hover);
  color: var(--dsw-alias-label-primary);
}

/* Workspace Group Row */
.dshAp_wsGroup {
  display: flex;
  flex-direction: column;
  position: relative;
}

.dshAp_dropBefore::before,
.dshAp_dropAfter::after {
  content: '';
  position: absolute;
  left: 8px;
  right: 8px;
  height: 2px;
  border-radius: 2px;
  background: var(--dsw-alias-brand-primary);
  pointer-events: none;
  z-index: 3;
  animation: dshApDropIndicator var(--ds-transition-duration-fast) var(--ds-ease-in-out);
  transform-origin: center;
}

.dshAp_dropBefore::before { top: -1px; }
.dshAp_dropAfter::after { bottom: -1px; }

.dshAp_wsRow {
  height: 32px;
  padding: 0 6px 0 calc(8px + var(--dsh-ws-indent, 0px));
  border-radius: var(--dsw-radius-sm);
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  user-select: none;
  color: var(--dsw-alias-label-primary);
  transition: background var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_wsRow:hover,
.dshAp_wsRowMenuOpen {
  background: var(--dsw-alias-interactive-bg-hover);
}

.dshAp_wsIconWrap {
  width: 16px;
  height: 16px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--dsw-alias-label-secondary);
  flex: none;
}

.dshAp_wsIconActive {
  color: var(--dsw-alias-brand-primary);
}

.dshAp_wsChevron {
  display: none;
}

.dshAp_wsRow:hover .dshAp_wsChevron,
.dshAp_wsRowMenuOpen .dshAp_wsChevron {
  display: inline-flex;
}

.dshAp_wsRow:hover .dshAp_wsFolder,
.dshAp_wsRowMenuOpen .dshAp_wsFolder {
  display: none;
}

.dshAp_wsTitle {
  flex: 1;
  min-width: 0;
  font-size: 13.5px;
  font-weight: 500;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.dshAp_wsHoverActions {
  display: none;
  align-items: center;
  gap: 1px;
  flex: none;
}

.dshAp_wsRow:hover .dshAp_wsHoverActions,
.dshAp_wsRowMenuOpen .dshAp_wsHoverActions {
  display: inline-flex;
}

/* Session Row (Workspace & Pinned Space) */
.dshAp_row {
  position: relative;
  height: 32px;
  padding: 0 6px 0 calc(8px + var(--dsh-ws-indent, 0px));
  border-radius: var(--dsw-radius-sm);
  display: flex;
  align-items: center;
  gap: 5px;
  cursor: pointer;
  user-select: none;
  color: var(--dsw-alias-label-primary);
  transition: background var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_rowIndented {
  padding-left: calc(18px + var(--dsh-ws-indent, 0px));
}

.dshAp_row:hover,
.dshAp_rowMenuOpen {
  background: var(--dsw-alias-interactive-bg-hover);
}

.dshAp_rowSelected {
  background: var(--dsw-alias-interactive-bg-active);
  font-weight: 500;
}

.dshAp_rowSelected:hover {
  background: var(--dsw-alias-interactive-bg-active);
}

.dshAp_rowArchived {
  opacity: 0.62;
}

.dshAp_leadCell {
  width: 16px;
  height: 16px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex: none;
  color: var(--dsw-alias-label-secondary);
}

.dshAp_rowTitle {
  flex: 1;
  min-width: 0;
  font-size: 13.5px;
  line-height: 20px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

@media (hover: hover) {
  .dshAp_row:hover .dshAp_rowTitle,
  .dshAp_rowMenuOpen .dshAp_rowTitle {
    text-overflow: clip;
  }
}

.dshAp_rowTitle[data-scrolled] {
  mask-image: linear-gradient(90deg, transparent, #000 12px);
  -webkit-mask-image: linear-gradient(90deg, transparent, #000 12px);
}

.dshAp_rowTitle[data-clipped] {
  mask-image: linear-gradient(270deg, transparent, #000 12px);
  -webkit-mask-image: linear-gradient(270deg, transparent, #000 12px);
}

.dshAp_rowTitle[data-scrolled][data-clipped] {
  mask-image: linear-gradient(90deg, transparent, #000 12px calc(100% - 12px), transparent);
  -webkit-mask-image: linear-gradient(90deg, transparent, #000 12px calc(100% - 12px), transparent);
}

.dshAp_rowTitleUnread {
  font-weight: 600;
}

.dshAp_wsSourceTag {
  max-width: 96px;
  padding: 1px 6px;
  border-radius: var(--dsw-radius-xs);
  background: var(--dsw-alias-interactive-bg-hover);
  color: var(--dsw-alias-label-secondary);
  font-size: 11px;
  line-height: 16px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: inline-flex;
  align-items: center;
  gap: 3px;
  flex: none;
}

.dshAp_rowTail {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  flex: none;
  color: var(--dsw-alias-label-secondary);
  font-size: 11.5px;
}

.dshAp_rowHoverActions {
  display: none;
  align-items: center;
  gap: 1px;
  flex: none;
}

.dshAp_row:hover .dshAp_rowTailHideOnHover,
.dshAp_rowMenuOpen .dshAp_rowTailHideOnHover {
  display: none;
}

.dshAp_row:hover .dshAp_rowHoverActions,
.dshAp_rowMenuOpen .dshAp_rowHoverActions {
  display: inline-flex;
}

.dshAp_emptyHint {
  padding: 4px 10px 6px calc(24px + var(--dsh-ws-indent, 0px));
  font-size: 12.5px;
  color: var(--dsw-alias-label-secondary);
  opacity: 0.72;
  user-select: none;
}

.dshAp_overflowBtn {
  border: none;
  background: transparent;
  color: var(--dsw-alias-label-secondary);
  font-size: 12.5px;
  line-height: 26px;
  height: 26px;
  padding: 0 10px 0 calc(26px + var(--dsh-ws-indent, 0px));
  text-align: left;
  cursor: pointer;
  border-radius: var(--dsw-radius-sm);
  opacity: 0.85;
  transition: background var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_overflowBtn:hover {
  opacity: 1;
  color: var(--dsw-alias-label-primary);
  background: var(--dsw-alias-interactive-bg-hover);
}

.dshAp_dot {
  width: 7px;
  height: 7px;
  border-radius: 999px;
  flex: none;
}

.dshAp_dotUnread {
  background: var(--dsw-alias-brand-primary);
}

.dshAp_dotWarn {
  background: var(--dsw-alias-state-warn-primary);
}

.dshAp_spinner {
  animation: dshApSpin 0.95s linear infinite;
  color: var(--dsw-alias-label-secondary);
  flex: none;
  display: inline-flex;
}

.dshAp_spinnerAccent {
  color: var(--dsw-alias-brand-primary);
}

/* Codex-Style Activity View */
.dshAp_actSection {
  display: flex;
  flex-direction: column;
  gap: 3px;
  margin-bottom: 10px;
}

.dshAp_actGroupTitle {
  height: 24px;
  padding: 0 8px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 12px;
  font-weight: 600;
  color: var(--dsw-alias-label-secondary);
  user-select: none;
}

.dshAp_priorityCard {
  position: relative;
  border-radius: var(--dsw-radius-md);
  padding: 8px 10px;
  margin: 0 2px;
  background: var(--dsw-alias-bg-layer-2);
  border: 1px solid var(--dsw-alias-border-l1);
  display: flex;
  flex-direction: column;
  gap: 3px;
  cursor: pointer;
  user-select: none;
  transition: background var(--ds-transition-duration-fast) var(--ds-ease-in-out), border-color var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_priorityCard:hover {
  background: var(--dsw-alias-interactive-bg-active);
  border-color: var(--dsw-alias-border-l2);
}

.dshAp_priorityCardSelected {
  border-color: color-mix(in srgb, var(--dsw-alias-brand-primary) 55%, var(--dsw-alias-border-l1));
  background: color-mix(in srgb, var(--dsw-alias-brand-primary) 9%, var(--dsw-alias-bg-layer-1));
}

.dshAp_actRow {
  position: relative;
  border-radius: var(--dsw-radius-sm);
  padding: 7px 8px;
  margin: 0 2px;
  display: flex;
  flex-direction: column;
  gap: 3px;
  cursor: pointer;
  user-select: none;
  transition: background var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_actRow:hover,
.dshAp_actRowMenuOpen {
  background: var(--dsw-alias-interactive-bg-hover);
}

.dshAp_actRowSelected {
  background: var(--dsw-alias-interactive-bg-active);
}

.dshAp_actTopLine {
  display: flex;
  align-items: center;
  gap: 6px;
  min-width: 0;
}

.dshAp_actTitle {
  flex: 1;
  min-width: 0;
  font-size: 13.5px;
  line-height: 19px;
  color: var(--dsw-alias-label-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.dshAp_actTitleUnread {
  font-weight: 600;
}

.dshAp_actWsName {
  max-width: 38%;
  font-size: 12.5px;
  line-height: 18px;
  color: var(--dsw-alias-label-secondary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex: none;
}

.dshAp_actSubLine {
  display: flex;
  align-items: center;
  gap: 5px;
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-label-secondary);
  min-width: 0;
}

.dshAp_actSnippet {
  font-size: 12px;
  line-height: 17px;
  color: var(--dsw-alias-label-secondary);
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
  word-break: break-word;
}

.dshAp_actHoverMenuBtn {
  display: none;
}

.dshAp_actRow:hover .dshAp_actHoverMenuBtn,
.dshAp_actRowMenuOpen .dshAp_actHoverMenuBtn,
.dshAp_priorityCard:hover .dshAp_actHoverMenuBtn {
  display: inline-flex;
}

.dshAp_emptyBlock {
  padding: 28px 14px;
  text-align: center;
  color: var(--dsw-alias-label-secondary);
  font-size: 12.5px;
  line-height: 18px;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}

.dshAp_linkBtn {
  border: 1px solid var(--dsw-alias-border-l2);
  background: var(--dsw-alias-bg-layer-1);
  color: var(--dsw-alias-label-primary);
  border-radius: var(--dsw-radius-sm);
  padding: 4px 10px;
  font-size: 12px;
  cursor: pointer;
}

.dshAp_linkBtn:hover {
  background: var(--dsw-alias-bg-layer-2);
}

.dshAp_popover {
  position: fixed;
  z-index: 9000;
  min-width: 208px;
  max-width: 286px;
  padding: 5px;
  border-radius: var(--dsw-radius-md);
  background: var(--dsw-alias-bg-overlay);
  border: 1px solid var(--dsw-alias-border-l1);
  box-shadow: 0 10px 28px color-mix(in srgb, var(--dsw-alias-label-primary) 16%, transparent);
  color: var(--dsw-alias-label-primary);
  display: flex;
  flex-direction: column;
  gap: 1px;
  box-sizing: border-box;
  transform-origin: top right;
  animation: dshApPopoverIn var(--ds-transition-duration) var(--ds-ease-in-out);
}

.dshAp_menuSectionLabel {
  padding: 5px 10px 3px;
  font-size: 11.5px;
  font-weight: 500;
  color: var(--dsw-alias-label-secondary);
  user-select: none;
}

.dshAp_menuSep {
  height: 1px;
  margin: 4px 6px;
  background: var(--dsw-alias-border-l1);
}

.dshAp_menuItem {
  width: 100%;
  min-height: 31px;
  padding: 4px 10px;
  border: none;
  border-radius: var(--dsw-radius-sm);
  background: transparent;
  color: var(--dsw-alias-label-primary);
  font-size: 13px;
  line-height: 19px;
  text-align: left;
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  box-sizing: border-box;
}

.dshAp_menuItem:hover:not(:disabled) {
  background: var(--dsw-alias-interactive-bg-hover);
}

.dshAp_menuItem:disabled {
  opacity: 0.42;
  cursor: default;
}

.dshAp_menuItemDanger {
  color: var(--dsw-alias-state-error-primary);
}

.dshAp_menuItemIcon {
  width: 16px;
  height: 16px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--dsw-alias-label-secondary);
  flex: none;
}

.dshAp_menuItemDanger .dshAp_menuItemIcon {
  color: var(--dsw-alias-state-error-primary);
}

.dshAp_menuItemText {
  flex: 1;
  min-width: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.dshAp_menuItemCheck {
  width: 16px;
  height: 16px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  color: var(--dsw-alias-label-primary);
  flex: none;
}

.dshAp_tooltip {
  position: fixed;
  z-index: 9200;
  padding: 5px 9px;
  border-radius: var(--dsw-radius-sm);
  background: var(--dsw-alias-label-primary);
  color: var(--dsw-alias-bg-base);
  font-size: 12px;
  line-height: 17px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
  pointer-events: none;
  white-space: nowrap;
  box-shadow: 0 6px 18px color-mix(in srgb, var(--dsw-alias-label-primary) 22%, transparent);
  animation: dshApTooltipIn var(--ds-transition-duration-fast) var(--ds-ease-in-out);
}

.dshAp_tooltipKbd {
  padding: 1px 5px;
  border-radius: var(--dsw-radius-xs);
  background: color-mix(in srgb, var(--dsw-alias-bg-base) 18%, transparent);
  font-size: 11px;
  font-family: inherit;
}

.dshAp_toast {
  position: fixed;
  bottom: 22px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 9600;
  padding: 8px 14px;
  border-radius: var(--dsw-radius-sm);
  background: var(--dsw-alias-bg-overlay);
  border: 1px solid var(--dsw-alias-border-l1);
  box-shadow: 0 8px 24px color-mix(in srgb, var(--dsw-alias-label-primary) 18%, transparent);
  color: var(--dsw-alias-label-primary);
  font-size: 13px;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  animation: dshApToastIn var(--ds-transition-duration) var(--ds-ease-in-out);
}

.dshAp_toastLeaving {
  animation: dshApToastOut var(--ds-transition-duration-fast) var(--ds-ease-in-out) forwards;
}

.dshAp_modalBackdrop {
  position: fixed;
  inset: 0;
  z-index: 9500;
  background: var(--dsw-alias-bg-mask-1);
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 16px;
  animation: dshApBackdropIn var(--ds-transition-duration) var(--ds-ease-in-out);
}

.dshAp_modalCard {
  width: 100%;
  max-width: 420px;
  border-radius: var(--dsw-radius-md);
  background: var(--dsw-alias-bg-overlay);
  border: 1px solid var(--dsw-alias-border-l1);
  padding: 18px;
  box-shadow: 0 18px 42px color-mix(in srgb, var(--dsw-alias-label-primary) 24%, transparent);
  color: var(--dsw-alias-label-primary);
  display: flex;
  flex-direction: column;
  gap: 12px;
  animation: dshApModalIn var(--ds-transition-duration) var(--ds-ease-in-out);
}

.dshAp_modalTitle {
  font-size: 15px;
  font-weight: 600;
  margin: 0;
}

.dshAp_modalDesc {
  font-size: 13px;
  line-height: 19px;
  color: var(--dsw-alias-label-secondary);
  margin: 0;
}

.dshAp_modalInput {
  width: 100%;
  box-sizing: border-box;
  height: 34px;
  border-radius: var(--dsw-radius-sm);
  border: 1px solid var(--dsw-alias-border-l2);
  background: var(--dsw-alias-bg-layer-1);
  color: var(--dsw-alias-label-primary);
  padding: 0 10px;
  font-size: 13.5px;
  outline: none;
}

.dshAp_modalInput:focus {
  border-color: var(--dsw-alias-brand-primary);
}

.dshAp_dirList {
  max-height: 240px;
  overflow-y: auto;
  border: 1px solid var(--dsw-alias-border-l1);
  border-radius: var(--dsw-radius-sm);
  background: var(--dsw-alias-bg-layer-1);
  padding: 4px;
  display: flex;
  flex-direction: column;
  gap: 1px;
}

.dshAp_modalError {
  font-size: 12px;
  color: var(--dsw-alias-state-error-primary);
}

.dshAp_modalFooter {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  margin-top: 4px;
}

.dshAp_btn {
  height: 32px;
  padding: 0 14px;
  border-radius: var(--dsw-radius-sm);
  font-size: 13px;
  font-weight: 500;
  cursor: pointer;
  border: 1px solid var(--dsw-alias-border-l2);
  background: var(--dsw-alias-bg-layer-1);
  color: var(--dsw-alias-label-primary);
}

.dshAp_btn:hover:not(:disabled) {
  background: var(--dsw-alias-bg-layer-2);
}

.dshAp_btn:disabled {
  opacity: 0.45;
  cursor: default;
}

.dshAp_btnPrimary {
  border-color: transparent;
  background: var(--dsw-alias-brand-primary);
  color: var(--dsw-alias-bg-base);
}

.dshAp_btnDanger {
  border-color: var(--dsw-alias-state-error-primary);
  color: var(--dsw-alias-state-error-primary);
}

/* Single-list ("In one list") section header above every session row. */
.dshAp_flatHeader {
  box-sizing: border-box;
  height: 26px;
  padding: 0 4px 0 8px;
  margin: 2px 0 3px;
  display: flex;
  align-items: center;
  gap: 5px;
  color: var(--dsw-alias-label-secondary);
  font-size: 12px;
  font-weight: 600;
  user-select: none;
}

@media (prefers-reduced-motion: reduce) {
  .dshAp_popover,
  .dshAp_tooltip,
  .dshAp_toast,
  .dshAp_modalBackdrop,
  .dshAp_modalCard,
  .dshAp_toastLeaving,
  .dshAp_rootWide,
  .dshAp_viewFadeIn,
  .dshAp_header,
  .dshAp_actHeader,
  .dshAp_searchBar,
  .dshAp_bellBadgeWarn::after,
  .dshAp_dropBefore::before,
  .dshAp_dropAfter::after {
    animation: none;
  }

  .dshAp_row,
  .dshAp_wsRow,
  .dshAp_actRow,
  .dshAp_priorityCard,
  .dshAp_iconBtn,
  .dshAp_railBtn,
  .dshAp_miniBtn,
  .dshAp_searchClear {
    transition: none;
  }
}
`

    // -------------------------------------------------------------------------
    // Clean Inline SVG Icons
    // -------------------------------------------------------------------------
    function IconBell({ size = 16, filled = false }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('path', {
          d: 'M8 2.25C5.93 2.25 4.25 3.93 4.25 6v2.35c0 .62-.25 1.21-.68 1.65L2.75 10.8h10.5l-.82-.8a2.33 2.33 0 0 1-.68-1.65V6c0-2.07-1.68-3.75-3.75-3.75Z',
          stroke: 'currentColor',
          strokeWidth: '1.35',
          strokeLinejoin: 'round',
          fill: filled ? 'color-mix(in srgb, currentColor 18%, transparent)' : 'none',
        }),
        h('path', {
          d: 'M6.5 12.5a1.6 1.6 0 0 0 3 0',
          stroke: 'currentColor',
          strokeWidth: '1.35',
          strokeLinecap: 'round',
        }),
      )
    }

    function IconPin({ size = 14, filled = false }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('path', {
          d: 'M9.8 2.3 13.7 6.2l-1.5 1.5-.9-.3-2.5 2.5.4 2.1-1.1 1.1-2.5-2.5-2.9 2.9-.7-.7 2.9-2.9-2.5-2.5L3.5 6.3l2.1.4 2.5-2.5-.3-.9 2-1Z',
          stroke: 'currentColor',
          strokeWidth: '1.25',
          strokeLinejoin: 'round',
          fill: filled ? 'currentColor' : 'none',
        }),
      )
    }

    function IconFolder({ size = 15, open = false }) {
      return open
        ? h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
          h('path', {
            d: 'M2 4.2A1.2 1.2 0 0 1 3.2 3h2.9l1.2 1.4h5.5A1.2 1.2 0 0 1 14 5.6v1.1H3.4L2 12V4.2Z',
            stroke: 'currentColor',
            strokeWidth: '1.3',
            strokeLinejoin: 'round',
          }),
          h('path', {
            d: 'M2 12.2 3.5 7h10.8l-1.4 5.2a1 1 0 0 1-.96.74H2.95A.95.95 0 0 1 2 12.2Z',
            stroke: 'currentColor',
            strokeWidth: '1.3',
            strokeLinejoin: 'round',
          }),
        )
        : h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
          h('path', {
            d: 'M2.25 4.25A1.25 1.25 0 0 1 3.5 3h2.85l1.3 1.5h4.85a1.25 1.25 0 0 1 1.25 1.25v6a1.25 1.25 0 0 1-1.25 1.25h-9a1.25 1.25 0 0 1-1.25-1.25v-7.5Z',
            stroke: 'currentColor',
            strokeWidth: '1.3',
            strokeLinejoin: 'round',
          }),
        )
    }

    function IconChevron({ size = 12, expanded = false }) {
      return h('svg', {
        width: size,
        height: size,
        viewBox: '0 0 12 12',
        fill: 'none',
        'aria-hidden': 'true',
        style: {
          transform: expanded ? 'rotate(90deg)' : 'rotate(0deg)',
          transition: 'transform var(--ds-transition-duration) var(--ds-ease-in-out)',
        },
      }, h('path', {
        d: 'M4.25 2.5 7.75 6l-3.5 3.5',
        stroke: 'currentColor',
        strokeWidth: '1.4',
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
      }))
    }

    function IconArrowLeft({ size = 14 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('path', { d: 'M12.5 8H3.5M7 4.5 3.5 8 7 11.5', stroke: 'currentColor', strokeWidth: '1.4', strokeLinecap: 'round', strokeLinejoin: 'round' }),
      )
    }

    function IconSearch({ size = 15 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('circle', { cx: '7.1', cy: '7.1', r: '4.4', stroke: 'currentColor', strokeWidth: '1.35' }),
        h('path', { d: 'm10.5 10.5 3 3', stroke: 'currentColor', strokeWidth: '1.35', strokeLinecap: 'round' }),
      )
    }

    function IconPlus({ size = 15 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('path', { d: 'M8 3.25v9.5M3.25 8h9.5', stroke: 'currentColor', strokeWidth: '1.4', strokeLinecap: 'round' }),
      )
    }

    function IconDots({ size = 15 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('circle', { cx: '3.5', cy: '8', r: '1.15', fill: 'currentColor' }),
        h('circle', { cx: '8', cy: '8', r: '1.15', fill: 'currentColor' }),
        h('circle', { cx: '12.5', cy: '8', r: '1.15', fill: 'currentColor' }),
      )
    }

    function IconSliders({ size = 15 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('path', { d: 'M2.5 5h11M2.5 11h11', stroke: 'currentColor', strokeWidth: '1.3', strokeLinecap: 'round' }),
        h('circle', { cx: '6', cy: '5', r: '1.7', fill: 'var(--dsw-alias-bg-base)', stroke: 'currentColor', strokeWidth: '1.3' }),
        h('circle', { cx: '10.2', cy: '11', r: '1.7', fill: 'var(--dsw-alias-bg-base)', stroke: 'currentColor', strokeWidth: '1.3' }),
      )
    }

    function IconCheck({ size = 14 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('path', { d: 'm3.3 8.3 3 3 6.4-6.6', stroke: 'currentColor', strokeWidth: '1.55', strokeLinecap: 'round', strokeLinejoin: 'round' }),
      )
    }

    function IconClose({ size = 12 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 12 12', fill: 'none', 'aria-hidden': 'true' },
        h('path', { d: 'm3 3 6 6M9 3l-6 6', stroke: 'currentColor', strokeWidth: '1.4', strokeLinecap: 'round' }),
      )
    }

    function IconSpinner({ size = 13.5, accent = true }) {
      return h('span', { className: `dshAp_spinner${accent ? ' dshAp_spinnerAccent' : ''}`, 'aria-hidden': 'true' },
        h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none' },
          h('circle', {
            cx: '8',
            cy: '8',
            r: '5.75',
            stroke: 'currentColor',
            strokeOpacity: '0.24',
            strokeWidth: '1.6',
          }),
          h('path', {
            d: 'M8 2.25a5.75 5.75 0 0 1 5.75 5.75',
            stroke: 'currentColor',
            strokeWidth: '1.6',
            strokeLinecap: 'round',
          }),
        ),
      )
    }

    function IconEdit({ size = 14 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('path', { d: 'M10.9 2.6a1.4 1.4 0 0 1 2 2l-7.2 7.2-2.7.7.7-2.7 7.2-7.2Z', stroke: 'currentColor', strokeWidth: '1.25', strokeLinejoin: 'round' }),
      )
    }

    function IconBranch({ size = 14 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('circle', { cx: '4.5', cy: '4', r: '1.6', stroke: 'currentColor', strokeWidth: '1.25' }),
        h('circle', { cx: '11.5', cy: '5.5', r: '1.6', stroke: 'currentColor', strokeWidth: '1.25' }),
        h('circle', { cx: '4.5', cy: '12', r: '1.6', stroke: 'currentColor', strokeWidth: '1.25' }),
        h('path', { d: 'M4.5 5.6v4.8M11.5 7.1c0 2-1.8 2.4-4 2.4H4.5', stroke: 'currentColor', strokeWidth: '1.25', strokeLinecap: 'round' }),
      )
    }

    function IconArchive({ size = 14 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('rect', { x: '2.2', y: '2.8', width: '11.6', height: '2.8', rx: '0.8', stroke: 'currentColor', strokeWidth: '1.25' }),
        h('path', { d: 'M3.2 5.6v6.6c0 .6.5 1 1 1h7.6c.5 0 1-.4 1-1V5.6M6.5 8.5h3', stroke: 'currentColor', strokeWidth: '1.25', strokeLinecap: 'round' }),
      )
    }

    function IconCopy({ size = 14 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('rect', { x: '5.4', y: '5.4', width: '7.8', height: '7.8', rx: '1.4', stroke: 'currentColor', strokeWidth: '1.25' }),
        h('path', { d: 'M3.5 10.4H3a1.2 1.2 0 0 1-1.2-1.2V3A1.2 1.2 0 0 1 3 1.8h6.2A1.2 1.2 0 0 1 10.4 3v.5', stroke: 'currentColor', strokeWidth: '1.25', strokeLinecap: 'round' }),
      )
    }

    function IconTrash({ size = 14 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('path', { d: 'M3 4.5h10M6.2 4.5V3.2c0-.4.3-.7.7-.7h2.2c.4 0 .7.3.7.7v1.3M4.3 4.5l.6 8.3c0 .6.5 1 1.1 1h4c.6 0 1.1-.4 1.1-1l.6-8.3', stroke: 'currentColor', strokeWidth: '1.25', strokeLinecap: 'round', strokeLinejoin: 'round' }),
      )
    }

    function IconClock({ size = 13 }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('circle', { cx: '8', cy: '8', r: '5.5', stroke: 'currentColor', strokeWidth: '1.25' }),
        h('path', { d: 'M8 5v3.2l2.2 1.4', stroke: 'currentColor', strokeWidth: '1.25', strokeLinecap: 'round', strokeLinejoin: 'round' }),
      )
    }

    function IconMailDot({ size = 14, unread = false }) {
      return h('svg', { width: size, height: size, viewBox: '0 0 16 16', fill: 'none', 'aria-hidden': 'true' },
        h('circle', {
          cx: '8',
          cy: '8',
          r: '4.5',
          stroke: 'currentColor',
          strokeWidth: '1.35',
          fill: unread ? 'currentColor' : 'none',
        }),
      )
    }

    // -------------------------------------------------------------------------
    // Native-matching FLIP AnimatedRows Component
    // -------------------------------------------------------------------------
    function sameRowKeys(prev, next) {
      if (prev.length !== next.length) return false
      for (let i = 0; i < prev.length; i++) {
        if (prev[i] !== next[i]) return false
      }
      return true
    }

    function rowIntersects(rect, viewport) {
      return rect.bottom > viewport.top && rect.top < viewport.bottom && rect.right > viewport.left && rect.left < viewport.right
    }

    class AnimatedRows extends Component {
      armed = false
      listRef = createRef()
      overlayRef = createRef()
      movements = new Map()
      exits = new Map()

      getSnapshotBeforeUpdate(prevProps) {
        const list = this.listRef.current
        if (
          !this.armed ||
          sameRowKeys(prevProps.rowKeys || [], this.props.rowKeys || []) ||
          prevProps.resetKey !== this.props.resetKey ||
          prevProps.ready === false ||
          this.props.ready === false ||
          list === null ||
          typeof list.animate !== 'function' ||
          (typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches)
        ) {
          return null
        }
        const viewport = list.getBoundingClientRect()
        const positions = this.readPositions()
        const nextKeys = new Set(this.props.rowKeys || [])
        const removed = new Map()
        for (const [key, row] of positions) {
          if (nextKeys.has(key) || !rowIntersects(row.rect, viewport)) continue
          const clone = row.element.cloneNode(true)
          clone.removeAttribute('data-row-key')
          clone.inert = true
          clone.style.setProperty('--dsh-ws-indent', getComputedStyle(row.element).getPropertyValue('--dsh-ws-indent'))
          removed.set(key, { ...row, element: clone })
        }
        return { positions, removed }
      }

      componentDidUpdate(prevProps, _prevState, snapshot) {
        if (snapshot === null) {
          if (
            !sameRowKeys(prevProps.rowKeys || [], this.props.rowKeys || []) ||
            prevProps.resetKey !== this.props.resetKey ||
            prevProps.ready !== this.props.ready
          ) {
            this.clear()
          }
          return
        }
        this.cancelMovements()
        const list = this.listRef.current
        const overlay = this.overlayRef.current
        if (!list || !overlay) return
        const viewport = list.getBoundingClientRect()
        const origin = overlay.getBoundingClientRect()
        const positions = this.readPositions()

        for (const [key, row] of positions) {
          this.removeExit(key)
          const prevRow = snapshot.positions.get(key)
          if (!rowIntersects(row.rect, viewport) && (prevRow === undefined || !rowIntersects(prevRow.rect, viewport))) continue
          if (prevRow === undefined) {
            this.move(row.element, [{ opacity: 0 }, { opacity: 1 }], ROW_FADE_MS)
            continue
          }
          const dx = prevRow.rect.left - row.rect.left
          const dy = prevRow.rect.top - row.rect.top
          if (dx === 0 && dy === 0 && prevRow.opacity === 1) continue
          this.move(row.element, [
            { transform: `translate(${dx}px, ${dy}px)`, opacity: prevRow.opacity },
            { transform: 'translate(0, 0)', opacity: 1 },
          ], ROW_GLIDE_MS)
        }

        for (const [key, row] of snapshot.removed) {
          const { element } = row
          this.removeExit(key)
          Object.assign(element.style, {
            position: 'absolute',
            margin: '0',
            transform: 'none',
            boxSizing: 'border-box',
            left: `${row.rect.left - origin.left}px`,
            top: `${row.rect.top - origin.top}px`,
            width: `${row.rect.width}px`,
            height: `${row.rect.height}px`,
          })
          element.style.willChange = 'opacity'
          overlay.append(element)
          const animation = element.animate([{ opacity: row.opacity }, { opacity: 0 }], {
            duration: ROW_FADE_MS,
            easing: ROW_EASING,
            fill: 'forwards',
          })
          this.exits.set(key, { element, animation })
          animation.onfinish = () => { this.removeExit(key) }
        }
      }

      componentWillUnmount() {
        this.clear()
      }

      readPositions() {
        const rows = this.listRef.current ? this.listRef.current.querySelectorAll('[data-row-key]') : []
        return new Map(Array.from(rows, (element) => [
          element.dataset.rowKey,
          {
            element,
            rect: element.getBoundingClientRect(),
            opacity: this.movements.has(element) ? Number(getComputedStyle(element).opacity) : 1,
          },
        ]))
      }

      move(element, keyframes, duration) {
        // Promote before the first frame so the row animates on its own layer
        // instead of repainting the list.
        element.style.willChange = 'transform, opacity'
        const animation = element.animate(keyframes, {
          duration,
          easing: ROW_EASING,
        })
        this.movements.set(element, animation)
        animation.onfinish = () => {
          element.style.willChange = ''
          this.movements.delete(element)
          animation.cancel()
        }
      }

      cancelMovements() {
        for (const [element, anim] of this.movements) {
          anim.onfinish = null
          anim.cancel()
          element.style.willChange = ''
        }
        this.movements.clear()
      }

      removeExit(key) {
        const exit = this.exits.get(key)
        if (!exit) return
        exit.animation.onfinish = null
        exit.animation.cancel()
        exit.element.remove()
        this.exits.delete(key)
      }

      clear() {
        this.cancelMovements()
        for (const key of this.exits.keys()) this.removeExit(key)
      }

      render() {
        return h(Fragment, null,
          h('div', {
            ref: this.listRef,
            className: this.props.className,
            role: 'tree',
            'aria-label': this.props.label,
            onPointerDownCapture: () => { this.armed = true },
            onKeyDownCapture: () => { this.armed = true },
          }, this.props.children),
          h('div', {
            ref: this.overlayRef,
            className: 'dshAp_exits',
            'aria-hidden': 'true',
          }),
        )
      }
    }

    // -------------------------------------------------------------------------
    // Title Marquee on Hover (native DSH feel)
    // -------------------------------------------------------------------------
    const raf = (cb) => (typeof requestAnimationFrame === 'function'
      ? requestAnimationFrame(cb)
      : setTimeout(() => cb(Date.now()), 16))
    const caf = (handle) => {
      if (typeof cancelAnimationFrame === 'function') cancelAnimationFrame(handle)
      else clearTimeout(handle)
    }

    /** Drive the fade masks the stylesheet keys off data-scrolled/data-clipped. */
    function markTitleEdges(el) {
      if (!el) return
      const max = el.scrollWidth - el.clientWidth
      if (el.scrollLeft > 1) el.dataset.scrolled = ''
      else delete el.dataset.scrolled
      if (max > 1 && el.scrollLeft < max - 1) el.dataset.clipped = ''
      else delete el.dataset.clipped
    }

    function useTitleMarquee(titleRef) {
      const frame = useRef(0)
      useEffect(() => () => {
        caf(frame.current)
        const el = titleRef.current
        if (el) {
          delete el.dataset.scrolled
          delete el.dataset.clipped
        }
      }, [titleRef])
      return useMemo(() => ({
        enter: () => {
          const el = titleRef.current
          if (!el) return
          const range = el.scrollWidth - el.clientWidth
          if (range <= 8) {
            markTitleEdges(el)
            return
          }
          markTitleEdges(el)
          if (typeof window !== 'undefined' && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            el.scrollLeft = range
            markTitleEdges(el)
            return
          }
          caf(frame.current)
          let prev
          let pos = 0
          const step = (time) => {
            pos += prev === undefined ? 0 : (time - prev) * 0.03
            prev = time
            el.scrollLeft = Math.min(pos, range)
            markTitleEdges(el)
            if (pos < range) frame.current = raf(step)
          }
          frame.current = raf(step)
        },
        leave: () => {
          caf(frame.current)
          const el = titleRef.current
          if (!el) return
          el.scrollLeft = 0
          delete el.dataset.scrolled
          delete el.dataset.clipped
        },
      }), [titleRef])
    }

    // -------------------------------------------------------------------------
    // Lightweight Observable Store Helper
    // -------------------------------------------------------------------------
    // Unvalidated on read so writes keep keys owned by other plugins.
    function loadNativeWorkspaceView() {
      if (typeof localStorage === 'undefined') return {}
      try {
        const raw = localStorage.getItem(DSH_NATIVE_VIEW_KEY)
        if (raw) {
          const parsed = JSON.parse(raw)
          if (parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed
        }
      } catch (_err) {}
      return {}
    }

    function pickChoice(value, allowed, fallback) {
      return allowed.includes(value) ? value : fallback
    }

    function pickPlainObject(value, fallback) {
      return value !== null && typeof value === 'object' && !Array.isArray(value) ? { ...value } : fallback
    }

    /** Mirror a group-expansion change into the native view record. */
    function writeNativeGroupExpansion(groupExpansion) {
      if (typeof localStorage === 'undefined') return
      try {
        const current = loadNativeWorkspaceView()
        localStorage.setItem(DSH_NATIVE_VIEW_KEY, JSON.stringify({ ...current, groupExpansion }))
      } catch (_err) {}
    }

    function createMiniStore(initialValue, storageKey) {
      let state = initialValue
      if (storageKey && typeof localStorage !== 'undefined') {
        try {
          const raw = localStorage.getItem(storageKey)
          if (raw) {
            const parsed = JSON.parse(raw)
            if (parsed !== null && typeof parsed === 'object') {
              state = { ...initialValue, ...parsed }
              if (storageKey === VIEW_STORAGE_KEY) {
                state.activityOpen = false
              }
            }
          }
        } catch (_err) {}
      }
      const listeners = new Set()
      return {
        getSnapshot: () => state,
        subscribe(fn) {
          listeners.add(fn)
          return () => listeners.delete(fn)
        },
        set(updater) {
          const next = typeof updater === 'function' ? updater(state) : updater
          if (Object.is(next, state)) return
          state = next
          if (storageKey && typeof localStorage !== 'undefined') {
            try {
              const toSave = storageKey === VIEW_STORAGE_KEY ? { ...state, activityOpen: false } : state
              localStorage.setItem(storageKey, JSON.stringify(toSave))
            } catch (_err) {}
          }
          for (const fn of listeners) {
            try { fn() } catch (_err) {}
          }
        },
      }
    }

    function useMiniStore(store, selector = (s) => s) {
      return useSyncExternalStore(
        store.subscribe,
        () => selector(store.getSnapshot()),
        () => selector(store.getSnapshot()),
      )
    }

    // -------------------------------------------------------------------------
    // Pure Time, Path & Ordering Helpers
    // -------------------------------------------------------------------------
    function formatRelativeTime(ts, now, t) {
      const diff = Math.max(0, now - (ts || 0))
      if (diff < 60_000) return t('time.now')
      if (diff < 3_600_000) return t('time.minutes', { n: Math.floor(diff / 60_000) })
      if (diff < 86_400_000) return t('time.hours', { n: Math.floor(diff / 3_600_000) })
      if (diff < 30 * 86_400_000) return t('time.days', { n: Math.floor(diff / 86_400_000) })
      if (diff < 365 * 86_400_000) return t('time.months', { n: Math.floor(diff / (30 * 86_400_000)) })
      return t('time.years', { n: Math.floor(diff / (365 * 86_400_000)) })
    }

    function startOfLocalDay(ms) {
      const d = new Date(ms)
      d.setHours(0, 0, 0, 0)
      return d.getTime()
    }

    function formatActivityDateBucket(ts, now, t) {
      const targetDay = startOfLocalDay(ts || now)
      const today = startOfLocalDay(now)
      const dayDiff = Math.round((today - targetDay) / 86_400_000)
      if (dayDiff <= 0) return { key: 'today', label: t('date.today') }
      if (dayDiff === 1) return { key: 'yesterday', label: t('date.yesterday') }
      const d = new Date(ts)
      if (dayDiff < 7) {
        const w = d.getDay()
        return { key: `weekday-${targetDay}`, label: t(`date.weekday.${w}`) }
      }
      const nowYear = new Date(now).getFullYear()
      if (d.getFullYear() === nowYear) {
        return {
          key: `md-${targetDay}`,
          label: t('date.md', { m: d.getMonth() + 1, d: d.getDate() }),
        }
      }
      return {
        key: `ymd-${targetDay}`,
        label: t('date.ymd', { y: d.getFullYear(), m: d.getMonth() + 1, d: d.getDate() }),
      }
    }

    function basenameOfPath(p) {
      if (!p || typeof p !== 'string') return ''
      const trimmed = p.replace(/[/\\]+$/, '')
      const idx = Math.max(trimmed.lastIndexOf('/'), trimmed.lastIndexOf('\\'))
      return trimmed.slice(idx + 1) || p
    }

    function normalizeFolderPath(p) {
      if (!p) return ''
      const normalized = (/^[A-Za-z]:[/\\]/.test(p) || p.startsWith('\\\\')) ? p.replaceAll('\\', '/') : p
      return normalized.replace(/\/+$/, '')
    }

    function findParentWorkspacePath(path, allPaths) {
      const child = normalizeFolderPath(path)
      let best
      let bestLen = -1
      for (const candidate of allPaths) {
        const root = normalizeFolderPath(candidate)
        if (root.length > bestLen && child !== root && child.startsWith(`${root}/`)) {
          best = candidate
          bestLen = root.length
        }
      }
      return best
    }

    function resolvePinScope(sessionId, isHostPinned, hostState) {
      if (!isHostPinned) return null
      if (hostState.pinMode === 'workspace') return 'workspace'
      if (hostState.pinMode === 'space') return 'space'
      const explicit = hostState.pinScopes?.[sessionId]
      if (explicit === 'space' || explicit === 'workspace') return explicit
      return hostState.defaultPinTarget === 'workspace' ? 'workspace' : 'space'
    }

    function checkSessionUnread(info, hostState) {
      const { sessionId, running, completionUnread, lastTurnEndAt, updatedAt, isMain } = info
      if (running) return false
      if (hostState.forceUnread?.[sessionId] === true) return true
      if (isMain) return false
      const seenAt = hostState.readAt?.[sessionId] ?? hostState.baselineAt ?? 0
      if (completionUnread && (hostState.readAt?.[sessionId] ?? 0) < Math.max(lastTurnEndAt || 0, updatedAt || 0)) {
        return true
      }
      if ((lastTurnEndAt || 0) > seenAt) return true
      return false
    }

    function orderIdsByRecency(ids, byId) {
      return [...ids]
        .filter((id) => byId[id] !== undefined)
        .sort((a, b) => {
          const diff = (byId[b]?.updatedAt ?? 0) - (byId[a]?.updatedAt ?? 0)
          if (diff !== 0) return diff
          return a < b ? -1 : 1
        })
    }

    function reconcileAccountOrder(memberIds, savedOrder, byId) {
      const memberSet = new Set(memberIds.filter((id) => byId[id] !== undefined))
      const result = []
      const seen = new Set()
      for (const id of savedOrder ?? []) {
        if (memberSet.has(id) && !seen.has(id)) {
          result.push(id)
          seen.add(id)
        }
      }
      for (const id of orderIdsByRecency(memberIds, byId)) {
        if (!seen.has(id)) {
          result.push(id)
          seen.add(id)
        }
      }
      return result
    }

    function clampPopoverPosition(rect, width = 224, estimatedHeight = 260, align = 'end') {
      const vw = typeof window !== 'undefined' ? window.innerWidth : 1200
      const vh = typeof window !== 'undefined' ? window.innerHeight : 800
      let left = align === 'end' ? rect.right - width : rect.left
      if (left + width > vw - 8) left = Math.max(8, vw - width - 8)
      if (left < 8) left = 8
      let top = rect.bottom + 5
      if (top + estimatedHeight > vh - 10 && rect.top - estimatedHeight > 10) {
        top = Math.max(8, rect.top - estimatedHeight - 5)
      }
      return { left, top }
    }

    // -------------------------------------------------------------------------
    // Client Plugin Activation
    // -------------------------------------------------------------------------
    const inject = [
      'slots',
      'sessions',
      'workspaces',
      'uiWorkspace',
      'locale',
      'layout',
      'remote',
    ]

    function apply(ctx) {
      // Inject scoped CSS and clean up on plugin unload
      ctx.effect(() => {
        if (typeof document === 'undefined') return undefined
        const tag = document.createElement('style')
        tag.dataset.plugin = PLUGIN_ID
        tag.textContent = CSS
        document.head.appendChild(tag)
        return () => tag.remove()
      }, `${PLUGIN_ID}: styles`)

      // Register bilingual dictionaries using 3-argument plugin namespace overload
      ctx.effect(() => {
        const offZh = ctx.locale.register(LOCALE_NS, 'zh', zh)
        const offEn = ctx.locale.register(LOCALE_NS, 'en', en)
        return () => {
          offZh?.()
          offEn?.()
        }
      }, `${PLUGIN_ID}: locale`)

      // Shared Host state store
      const initialHostState = {
        revision: 0,
        baselineAt: Date.now(),
        pinMode: 'hybrid',
        defaultPinTarget: 'space',
        hideSpacePinsInWorkspace: true,
        alwaysShowPinSpace: true,
        pinSpaceExpanded: true,
        pinScopes: {},
        spaceOrder: [],
        readAt: {},
        forceUnread: {},
        activityPrefs: {
          showPrioritySection: true,
          includePinnedInPriority: false,
          includeScheduledInPriority: false,
          unreadOnly: false,
        },
      }
      const hostStore = createMiniStore(initialHostState, CACHE_STORAGE_KEY)

      // Local UI store (initialized from native DSH workspace view for persistent groupExpansion & modes)
      const nativeDshView = loadNativeWorkspaceView()
      const initialUiState = {
        activityOpen: false,
        projectsExpanded: true,
        groupBy: pickChoice(nativeDshView.groupBy, ['workspace', 'workspace-tree', 'flat'], 'workspace'),
        orderBy: pickChoice(nativeDshView.orderBy, ['updated', 'manual'], 'updated'),
        archivedFilter: pickChoice(nativeDshView.archivedFilter, ['default', 'show', 'only'], 'default'),
        groupExpansion: pickPlainObject(nativeDshView.groupExpansion, {}),
        sessionOrderByAccount: pickPlainObject(nativeDshView.sessionOrderByAccount, {}),
      }
      const uiStore = createMiniStore(initialUiState, VIEW_STORAGE_KEY)

      // Ephemeral overlay store (`shell.overlay`)
      const overlayStore = createMiniStore({
        popover: null,
        tooltip: null,
        modal: null,
        toast: null,
        toastLeaving: false,
      })

      const TOAST_VISIBLE_MS = 2600
      const TOAST_EXIT_MS = 160
      let toastTimer = null
      let toastExitTimer = null
      const showToast = (message) => {
        if (toastTimer) clearTimeout(toastTimer)
        if (toastExitTimer) clearTimeout(toastExitTimer)
        overlayStore.set((c) => ({ ...c, toast: message, toastLeaving: false }))
        toastTimer = setTimeout(() => {
          // Play the exit animation before dropping the toast.
          overlayStore.set((c) => (c.toast === null ? c : { ...c, toastLeaving: true }))
          toastExitTimer = setTimeout(() => {
            overlayStore.set((c) => ({ ...c, toast: null, toastLeaving: false }))
          }, TOAST_EXIT_MS)
        }, TOAST_VISIBLE_MS)
      }
      ctx.effect(() => () => {
        if (toastTimer) clearTimeout(toastTimer)
        if (toastExitTimer) clearTimeout(toastExitTimer)
      }, `${PLUGIN_ID}: toast timer`)

      // Scheduled session IDs source
      const scheduledSessionsStore = createMiniStore({ ids: [] })

      async function refreshScheduledCatalog() {
        const scheduleApi = ctx.remote?.schedule
        if (!scheduleApi || typeof scheduleApi.catalog !== 'function') return
        try {
          const res = await scheduleApi.catalog()
          const entries = Array.isArray(res) ? res : (res?.ok ? res.value : [])
          if (Array.isArray(entries)) {
            const activeIds = [...new Set(
              entries
                .filter((r) => r && r.status === 'active' && typeof r.sessionId === 'string')
                .map((r) => r.sessionId),
            )]
            scheduledSessionsStore.set({ ids: activeIds })
          }
        } catch (_err) {}
      }

      async function syncFromHost() {
        try {
          const res = await fetch(API_URL, {
            method: 'GET',
            credentials: 'same-origin',
            headers: { Accept: 'application/json' },
          })
          if (!res.ok) return
          const payload = await res.json()
          if (payload?.ok && payload.state) {
            // Ignore replies older than the optimistic revision.
            hostStore.set((current) => (Number(payload.state.revision) >= Number(current.revision)
              ? payload.state
              : current))
          }
        } catch (_err) {}
      }

      async function callHostAction(action, body = {}, optimisticUpdater) {
        if (typeof optimisticUpdater === 'function') {
          hostStore.set(optimisticUpdater)
        }
        try {
          const res = await fetch(API_URL, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {
              'Content-Type': 'application/json',
              Accept: 'application/json',
            },
            body: JSON.stringify({ action, ...body }),
          })
          const payload = await res.json().catch(() => null)
          if (payload?.ok && payload.state) {
            hostStore.set((current) => (Number(payload.state.revision) >= Number(current.revision)
              ? payload.state
              : current))
          } else if (!res.ok) {
            await syncFromHost()
          }
          return payload ?? { ok: false, error: `HTTP ${res.status}` }
        } catch (error) {
          await syncFromHost()
          return { ok: false, error: error instanceof Error ? error.message : String(error) }
        }
      }

      ctx.effect(() => {
        syncFromHost()
        refreshScheduledCatalog()
        const offReset = ctx.on('connection/reset', () => {
          syncFromHost()
          refreshScheduledCatalog()
        })
        const offWs = typeof ctx.workspaces?.list?.subscribe === 'function'
          ? ctx.workspaces.list.subscribe(() => { syncFromHost() })
          : () => {}
        const offSchedule = typeof ctx.remote?.$on === 'function'
          ? ctx.remote.$on('schedule/changed', () => refreshScheduledCatalog())
          : () => {}
        return () => {
          offReset()
          offWs()
          offSchedule()
        }
      }, `${PLUGIN_ID}: host sync`)

      // Register Codex-style ⌥⌘U shortcut to toggle Activity View
      const shortcutsService = ctx.get('shortcuts')
      if (shortcutsService && typeof shortcutsService.register === 'function') {
        ctx.effect(() => {
          try {
            const t = ctx.locale.bind(LOCALE_NS)
            return shortcutsService.register({
              id: 'dsh-session-sidebar.toggle-activity',
              label: () => t('activity.open'),
              aliases: ['activity view', 'unread chats', 'codex', 'inbox', '活动视图', '未读对话'],
              defaults: {
                'desktop:macos': { code: 'KeyU', modifiers: ['primary', 'alt'] },
                'desktop:windows': { code: 'KeyU', modifiers: ['primary', 'alt'] },
                'desktop:linux': { code: 'KeyU', modifiers: ['primary', 'alt'] },
                'web:macos': { code: 'KeyU', modifiers: ['primary', 'alt'] },
                'web:windows': { code: 'KeyU', modifiers: ['primary', 'alt'] },
              },
              regions: ['page', 'editable'],
              modals: [],
              resolve: () => ({
                status: 'handled',
                run: () => {
                  uiStore.set((cur) => ({ ...cur, activityOpen: !cur.activityOpen }))
                },
              }),
            })
          } catch (_err) {
            return undefined
          }
        }, `${PLUGIN_ID}: shortcut`)
      }

      // Pin through uiWorkspace (it keeps native pin order); workspaces is the fallback.
      async function callPinService(method, sessionId) {
        const owner = typeof ctx.uiWorkspace?.[method] === 'function'
          ? ctx.uiWorkspace
          : (typeof ctx.workspaces?.[method] === 'function' ? ctx.workspaces : null)
        if (owner === null) return false
        try {
          await owner[method](sessionId)
          return true
        } catch (_err) {
          return false
        }
      }

      const operations = {
        pinToSpace: async (sessionId) => {
          const prev = hostStore.getSnapshot()
          await callPinService('pinSession', sessionId)
          return callHostAction('pin_space', { sessionId }, (s) => ({
            ...s,
            revision: (s.revision ?? 0) + 1,
            pinScopes: { ...s.pinScopes, [sessionId]: 'space' },
            spaceOrder: [sessionId, ...(s.spaceOrder ?? []).filter((id) => id !== sessionId)],
          })).then((r) => {
            if (!r?.ok) hostStore.set(prev)
            return r
          })
        },
        pinInWorkspace: async (sessionId) => {
          const prev = hostStore.getSnapshot()
          await callPinService('pinSession', sessionId)
          return callHostAction('pin_workspace', { sessionId }, (s) => ({
            ...s,
            revision: (s.revision ?? 0) + 1,
            pinScopes: { ...s.pinScopes, [sessionId]: 'workspace' },
            spaceOrder: (s.spaceOrder ?? []).filter((id) => id !== sessionId),
          })).then((r) => {
            if (!r?.ok) hostStore.set(prev)
            return r
          })
        },
        unpin: async (sessionId) => {
          await callPinService('unpinSession', sessionId)
          return callHostAction('unpin', { sessionId }, (s) => {
            const nextScopes = { ...s.pinScopes }
            delete nextScopes[sessionId]
            return {
              ...s,
              revision: (s.revision ?? 0) + 1,
              pinScopes: nextScopes,
              spaceOrder: (s.spaceOrder ?? []).filter((id) => id !== sessionId),
            }
          })
        },
        reorderSpacePins: (sessionIds) => callHostAction(
          'reorder_space_pins',
          { sessionIds },
          (s) => ({ ...s, revision: (s.revision ?? 0) + 1, spaceOrder: sessionIds }),
        ),
        setPinConfig: (patch) => callHostAction(
          'set_pin_config',
          patch,
          (s) => ({ ...s, ...patch, revision: (s.revision ?? 0) + 1 }),
        ),
        markRead: (sessionId, ts = Date.now()) => callHostAction(
          'mark_read',
          { sessionId, timestamp: ts },
          (s) => {
            const nextForce = { ...s.forceUnread }
            delete nextForce[sessionId]
            return {
              ...s,
              revision: (s.revision ?? 0) + 1,
              readAt: { ...s.readAt, [sessionId]: Math.max(s.readAt?.[sessionId] ?? 0, ts) },
              forceUnread: nextForce,
            }
          },
        ),
        markUnread: (sessionId) => callHostAction(
          'mark_unread',
          { sessionId },
          (s) => ({
            ...s,
            revision: (s.revision ?? 0) + 1,
            forceUnread: { ...s.forceUnread, [sessionId]: true },
          }),
        ),
        markAllRead: (sessionIds) => {
          const now = Date.now()
          return callHostAction('mark_all_read', { sessionIds }, (s) => {
            const nextRead = { ...s.readAt }
            for (const id of sessionIds ?? []) {
              nextRead[id] = Math.max(nextRead[id] ?? 0, now)
            }
            return {
              ...s,
              revision: (s.revision ?? 0) + 1,
              baselineAt: Math.max(s.baselineAt ?? 0, now),
              readAt: nextRead,
              forceUnread: {},
            }
          })
        },
        setActivityPrefs: (patch) => callHostAction(
          'set_activity_prefs',
          patch,
          (s) => ({
            ...s,
            revision: (s.revision ?? 0) + 1,
            activityPrefs: { ...s.activityPrefs, ...patch },
          }),
        ),
        archiveSessionWithConfirm: (sessionId, displayTitle, t) => {
          ctx.uiWorkspace.archiveSession(sessionId).then(() => {
            showToast(t('toast.archived'))
          }).catch((err) => {
            const code = err?.rpcError?.code
            if (code === 'workspace/session-active') {
              overlayStore.set((c) => ({
                ...c,
                modal: {
                  kind: 'stop-archive',
                  sessionId,
                  title: displayTitle,
                },
              }))
              return
            }
            showToast(t('toast.error', { message: err instanceof Error ? err.message : String(err) }))
          })
        },
      }

      const closePopover = () => {
        overlayStore.set((cur) => (cur.popover === null ? cur : { ...cur, popover: null }))
      }

      const openPopover = (id, anchorEl, render, align = 'end', width = 224) => {
        if (!anchorEl || typeof anchorEl.getBoundingClientRect !== 'function') return
        const rect = anchorEl.getBoundingClientRect()
        overlayStore.set((cur) => ({
          ...cur,
          tooltip: null,
          popover: cur.popover?.id === id ? null : { id, anchorEl, rect, align, width, render },
        }))
      }

      const showTooltip = (anchorEl, label, shortcut) => {
        if (!anchorEl || typeof anchorEl.getBoundingClientRect !== 'function') return
        const rect = anchorEl.getBoundingClientRect()
        overlayStore.set((cur) => (cur.popover ? cur : {
          ...cur,
          tooltip: { rect, label, shortcut },
        }))
      }

      const hideTooltip = () => {
        overlayStore.set((cur) => (cur.tooltip === null ? cur : { ...cur, tooltip: null }))
      }

      const triggerAddWorkspace = async (t) => {
        let picked
        try {
          picked = await ctx.uiWorkspace.pickDirectory()
        } catch (_err) {
          // No native picker: use the in-app browser.
          overlayStore.set((c) => ({ ...c, modal: { kind: 'browse-dir' } }))
          return
        }
        if (typeof picked !== 'string' || picked === '') return
        try {
          const ws = await ctx.workspaces.create({ path: picked })
          ctx.uiWorkspace.startSession(ws.workspaceId, { clearPreviousDraft: false })
        } catch (err) {
          showToast(t('toast.error', { message: err instanceof Error ? err.message : String(err) }))
        }
      }

      // -----------------------------------------------------------------------
      // Floating Overlay Component (`shell.overlay` registrant)
      // -----------------------------------------------------------------------
      function SessionSidebarOverlay({ t }) {
        const overlay = useMiniStore(overlayStore)
        const popoverRef = useRef(null)

        // Menus read host/view state at render time; repaint them when it changes.
        const hostRevision = useMiniStore(hostStore, (s) => s.revision)
        const viewSignature = useMiniStore(
          uiStore,
          (s) => `${s.activityOpen}:${s.archivedFilter}:${s.groupBy}:${s.orderBy}`,
        )
        const popoverSignature = `${hostRevision}:${viewSignature}`

        useEffect(() => {
          if (!overlay.popover && !overlay.modal) return undefined
          const onKeyDown = (e) => {
            if (e.key === 'Escape') {
              if (overlay.popover) closePopover()
              else if (overlay.modal) overlayStore.set((c) => ({ ...c, modal: null }))
            }
          }
          const onPointerDown = (e) => {
            if (!overlay.popover) return
            if (popoverRef.current && popoverRef.current.contains(e.target)) return
            if (overlay.popover.anchorEl && overlay.popover.anchorEl.contains(e.target)) return
            closePopover()
          }
          // A fixed-position menu would drift from its anchor on scroll.
          const onScroll = (e) => {
            if (!overlay.popover) return
            if (popoverRef.current && popoverRef.current.contains(e.target)) return
            closePopover()
          }
          document.addEventListener('keydown', onKeyDown)
          document.addEventListener('pointerdown', onPointerDown, true)
          document.addEventListener('scroll', onScroll, true)
          return () => {
            document.removeEventListener('keydown', onKeyDown)
            document.removeEventListener('pointerdown', onPointerDown, true)
            document.removeEventListener('scroll', onScroll, true)
          }
        }, [overlay.popover, overlay.modal])

        const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/i.test(navigator.platform || navigator.userAgent)

        return h(Fragment, null,
          overlay.popover && (() => {
            const pos = clampPopoverPosition(
              overlay.popover.rect,
              overlay.popover.width ?? 224,
              270,
              overlay.popover.align ?? 'end',
            )
            return h('div', {
              ref: popoverRef,
              role: 'menu',
              className: 'dshAp_popover',
              'data-sig': popoverSignature,
              style: { left: `${pos.left}px`, top: `${pos.top}px`, minWidth: `${overlay.popover.width ?? 214}px` },
              onClick: (e) => e.stopPropagation(),
            }, overlay.popover.render(closePopover))
          })(),
          overlay.tooltip && (() => {
            const vw = typeof window !== 'undefined' ? window.innerWidth : 1200
            const left = Math.max(8, Math.min(vw - 190, overlay.tooltip.rect.left + overlay.tooltip.rect.width / 2 - 60))
            const top = overlay.tooltip.rect.bottom + 7
            return h('div', {
              className: 'dshAp_tooltip',
              role: 'tooltip',
              style: { left: `${left}px`, top: `${top}px` },
            },
              h('span', null, overlay.tooltip.label),
              overlay.tooltip.shortcut && h('kbd', { className: 'dshAp_tooltipKbd' },
                overlay.tooltip.shortcut === 'act-toggle' ? (isMac ? '⌥⌘U' : 'Ctrl+Alt+U') : overlay.tooltip.shortcut,
              ),
            )
          })(),
          overlay.modal && h(OverlayModalDialog, {
            modal: overlay.modal,
            onClose: () => overlayStore.set((c) => ({ ...c, modal: null })),
            t,
          }),
          overlay.toast && h('div', {
            className: `dshAp_toast${overlay.toastLeaving ? ' dshAp_toastLeaving' : ''}`,
            role: 'status',
          }, overlay.toast),
        )
      }

      // DirectoryListing exposes `crumbs` (not `breadcrumbs`); derive the parent from it.
      function toDirState(listing) {
        const payload = listing !== null && typeof listing === 'object' ? listing : {}
        const path = typeof payload.path === 'string' ? payload.path : ''
        const crumbs = Array.isArray(payload.crumbs) ? payload.crumbs : []
        let parent = crumbs.length >= 2 && typeof crumbs[crumbs.length - 2]?.path === 'string'
          ? crumbs[crumbs.length - 2].path
          : null
        if (parent === null) {
          const normalized = path.replace(/[/\\]+$/, '')
          const cut = Math.max(normalized.lastIndexOf('/'), normalized.lastIndexOf('\\'))
          if (cut > 0) parent = normalized.slice(0, cut)
        }
        const entries = Array.isArray(payload.entries) ? payload.entries : []
        return {
          path,
          entries: entries
            .filter((entry) => entry !== null && typeof entry === 'object' && typeof entry.name === 'string')
            .map((entry) => ({
              ...entry,
              path: typeof entry.path === 'string' && entry.path !== ''
                ? entry.path
                : `${path.replace(/[/\\]+$/, '')}/${entry.name}`,
            })),
          parent,
          loading: false,
        }
      }

      function OverlayModalDialog({ modal, onClose, t }) {
        const [draft, setDraft] = useState(modal.initialTitle ?? '')
        const [busy, setBusy] = useState(false)
        const [error, setError] = useState(null)
        const [dirState, setDirState] = useState({ path: undefined, entries: [], parent: null, loading: false })
        const inputRef = useRef(null)

        useLayoutEffect(() => {
          setDraft(modal.initialTitle ?? '')
          setBusy(false)
          setError(null)
          if (modal.kind === 'rename-ws' || modal.kind === 'rename-session') {
            setTimeout(() => {
              inputRef.current?.focus()
              inputRef.current?.select()
            }, 20)
          }
        }, [modal])

        useEffect(() => {
          if (modal.kind !== 'browse-dir') return undefined
          let active = true
          const loadDir = (targetPath) => {
            setDirState((s) => ({ ...s, loading: true }))
            ctx.uiWorkspace.listDirectory(targetPath).then((listing) => {
              if (!active) return
              setDirState(toDirState(listing))
            }).catch((err) => {
              if (!active) return
              setError(err instanceof Error ? err.message : String(err))
              setDirState((s) => ({ ...s, loading: false }))
            })
          }
          loadDir(undefined)
          return () => { active = false }
        }, [modal])

        if (modal.kind === 'rename-ws' || modal.kind === 'rename-session') {
          const isWs = modal.kind === 'rename-ws'
          const trimmed = draft.trim()
          const duplicate = isWs && trimmed !== '' && (modal.existingTitles ?? []).some(
            (w) => w.workspaceId !== modal.workspaceId && w.title === trimmed,
          )
          const disabled = busy || trimmed === '' || (isWs && trimmed === modal.initialTitle) || duplicate
          const submit = () => {
            if (disabled) return
            setBusy(true)
            setError(null)
            const actionPromise = isWs
              ? ctx.workspaces.rename(modal.workspaceId, trimmed)
              : ctx.sessions.using(modal.sessionId, { source: 'controllerOperation' }, (ref) => ref.binding.session.rename(trimmed)).then((res) => {
                if (res && res.ok === false) throw new Error(res.error?.message || 'Rename failed')
              })
            actionPromise
              .then(() => onClose())
              .catch((err) => {
                setBusy(false)
                setError(err instanceof Error ? err.message : String(err))
              })
          }
          const titleLabel = isWs ? t('workspace.rename') : t('session.renameTitle')
          return h('div', { className: 'dshAp_modalBackdrop', onClick: () => !busy && onClose() },
            h('div', {
              className: 'dshAp_modalCard',
              role: 'dialog',
              'aria-modal': 'true',
              'aria-label': titleLabel,
              onClick: (e) => e.stopPropagation(),
            },
              h('h3', { className: 'dshAp_modalTitle' }, titleLabel),
              h('input', {
                ref: inputRef,
                className: 'dshAp_modalInput',
                value: draft,
                disabled: busy,
                onChange: (e) => {
                  setDraft(e.target.value)
                  setError(null)
                },
                onKeyDown: (e) => {
                  if (e.key === 'Enter' && !e.nativeEvent.isComposing) {
                    e.preventDefault()
                    submit()
                  }
                },
              }),
              duplicate && h('div', { className: 'dshAp_modalError' }, t('workspace.conflict', { name: trimmed })),
              error && h('div', { className: 'dshAp_modalError' }, error),
              h('div', { className: 'dshAp_modalFooter' },
                h('button', { type: 'button', className: 'dshAp_btn', disabled: busy, onClick: onClose }, t('modal.cancel')),
                h('button', { type: 'button', className: 'dshAp_btn dshAp_btnPrimary', disabled, onClick: submit }, t('modal.confirm')),
              ),
            ),
          )
        }

        if (modal.kind === 'delete-ws') {
          const confirmDelete = () => {
            if (busy) return
            setBusy(true)
            setError(null)
            ctx.workspaces.delete(modal.workspaceId)
              .then(() => onClose())
              .catch((err) => {
                setBusy(false)
                setError(err instanceof Error ? err.message : String(err))
              })
          }
          return h('div', { className: 'dshAp_modalBackdrop', onClick: () => !busy && onClose() },
            h('div', {
              className: 'dshAp_modalCard',
              role: 'dialog',
              'aria-modal': 'true',
              'aria-label': t('workspace.delete'),
              onClick: (e) => e.stopPropagation(),
            },
              h('h3', { className: 'dshAp_modalTitle' }, t('workspace.delete')),
              h('p', { className: 'dshAp_modalDesc' }, t('workspace.deleteDesc', { name: modal.title })),
              error && h('div', { className: 'dshAp_modalError' }, error),
              h('div', { className: 'dshAp_modalFooter' },
                h('button', { type: 'button', className: 'dshAp_btn', disabled: busy, onClick: onClose }, t('modal.cancel')),
                h('button', { type: 'button', className: 'dshAp_btn dshAp_btnDanger', disabled: busy, onClick: confirmDelete }, t('workspace.delete')),
              ),
            ),
          )
        }

        if (modal.kind === 'stop-archive') {
          const confirmStopArchive = () => {
            if (busy) return
            setBusy(true)
            setError(null)
            ctx.uiWorkspace.archiveSession(modal.sessionId, { stopActivity: true })
              .then(() => {
                onClose()
                showToast(t('toast.archived'))
              })
              .catch((err) => {
                setBusy(false)
                setError(err instanceof Error ? err.message : String(err))
              })
          }
          return h('div', { className: 'dshAp_modalBackdrop', onClick: () => !busy && onClose() },
            h('div', {
              className: 'dshAp_modalCard',
              role: 'dialog',
              'aria-modal': 'true',
              'aria-label': t('session.stopArchiveTitle'),
              onClick: (e) => e.stopPropagation(),
            },
              h('h3', { className: 'dshAp_modalTitle' }, t('session.stopArchiveTitle')),
              h('p', { className: 'dshAp_modalDesc' }, t('session.stopArchiveDesc', { name: modal.title })),
              error && h('div', { className: 'dshAp_modalError' }, error),
              h('div', { className: 'dshAp_modalFooter' },
                h('button', { type: 'button', className: 'dshAp_btn', disabled: busy, onClick: onClose }, t('modal.cancel')),
                h('button', { type: 'button', className: 'dshAp_btn dshAp_btnDanger', disabled: busy, onClick: confirmStopArchive }, t('session.stopArchiveConfirm')),
              ),
            ),
          )
        }

        if (modal.kind === 'browse-dir') {
          const navigateTo = (nextPath) => {
            setError(null)
            setDirState((s) => ({ ...s, loading: true }))
            ctx.uiWorkspace.listDirectory(nextPath).then((listing) => {
              setDirState(toDirState(listing))
            }).catch((err) => {
              setError(err instanceof Error ? err.message : String(err))
              setDirState((s) => ({ ...s, loading: false }))
            })
          }
          const chooseCurrent = () => {
            if (!dirState.path || busy) return
            setBusy(true)
            ctx.workspaces.create({ path: dirState.path }).then((ws) => {
              onClose()
              ctx.uiWorkspace.startSession(ws.workspaceId, { clearPreviousDraft: false })
            }).catch((err) => {
              setBusy(false)
              setError(err instanceof Error ? err.message : String(err))
            })
          }
          return h('div', { className: 'dshAp_modalBackdrop', onClick: () => !busy && onClose() },
            h('div', {
              className: 'dshAp_modalCard',
              role: 'dialog',
              'aria-modal': 'true',
              'aria-label': t('workspace.browseTitle'),
              onClick: (e) => e.stopPropagation(),
            },
              h('h3', { className: 'dshAp_modalTitle' }, t('workspace.browseTitle')),
              dirState.path && h('div', { className: 'dshAp_modalDesc', style: { wordBreak: 'break-all' } }, dirState.path),
              h('div', { className: 'dshAp_dirList' },
                dirState.parent && h('button', {
                  type: 'button',
                  className: 'dshAp_menuItem',
                  onClick: () => navigateTo(dirState.parent),
                },
                  h('span', { className: 'dshAp_menuItemIcon' }, h(IconFolder, { size: 14 })),
                  h('span', { className: 'dshAp_menuItemText' }, t('workspace.parentDir')),
                ),
                dirState.entries.map((entry) => {
                  const full = entry.path ?? `${(dirState.path || '').replace(/\/+$/, '')}/${entry.name}`
                  return h('button', {
                    key: full,
                    type: 'button',
                    className: 'dshAp_menuItem',
                    onClick: () => navigateTo(full),
                  },
                    h('span', { className: 'dshAp_menuItemIcon' }, h(IconFolder, { size: 14 })),
                    h('span', { className: 'dshAp_menuItemText' }, entry.name),
                  )
                }),
              ),
              error && h('div', { className: 'dshAp_modalError' }, error),
              h('div', { className: 'dshAp_modalFooter' },
                h('button', { type: 'button', className: 'dshAp_btn', disabled: busy, onClick: onClose }, t('modal.cancel')),
                h('button', {
                  type: 'button',
                  className: 'dshAp_btn dshAp_btnPrimary',
                  disabled: busy || !dirState.path,
                  onClick: chooseCurrent,
                }, t('workspace.selectThisFolder')),
              ),
            ),
          )
        }

        return null
      }

      // -----------------------------------------------------------------------
      // One session row. A component, so each row owns its marquee hooks.
      // -----------------------------------------------------------------------
      function SessionRow(props) {
        const {
          node,
          contextKey,
          t,
          now,
          selected,
          menuOpen,
          indented,
          showWorkspaceBadge,
          quickPinTarget,
          canDrag,
          dropHalf,
          dragArmed,
          onOpen,
          onOpenMenu,
          onArchiveToggle,
          onPinToggle,
          onRename,
          onDragStart,
          onDragOver,
          onDrop,
          onDragEnd,
        } = props

        const titleRef = useRef(null)
        const marquee = useTitleMarquee(titleRef)

        // Strictly ONE spinner: ONLY on the right tail, NEVER on the left.
        let leadElement = null
        if (!node.archived && !node.blank) {
          if (node.pendingKind) {
            leadElement = h('span', {
              className: 'dshAp_dot dshAp_dotWarn',
              title: t(`status.${node.pendingKind === 'plan-review' ? 'planReview' : node.pendingKind === 'question' ? 'answer' : 'approval'}`),
            })
          } else if (node.unread && !node.activeRun) {
            leadElement = h('span', { className: 'dshAp_dot dshAp_dotUnread', title: t('status.unread') })
          } else if (node.scheduled && !node.activeRun) {
            leadElement = h('span', { title: t('status.scheduled') }, h(IconClock, { size: 12.5 }))
          }
        }

        return h('div', {
          'data-row-key': `session:${contextKey}:${node.id}`,
          className: [
            'dshAp_row',
            indented ? 'dshAp_rowIndented' : '',
            selected ? 'dshAp_rowSelected' : '',
            menuOpen ? 'dshAp_rowMenuOpen' : '',
            node.archived ? 'dshAp_rowArchived' : '',
            dropHalf === 'before' ? 'dshAp_dropBefore' : '',
            dropHalf === 'after' ? 'dshAp_dropAfter' : '',
          ].filter(Boolean).join(' '),
          role: 'treeitem',
          'aria-selected': selected,
          tabIndex: 0,
          draggable: canDrag,
          onDragStart: canDrag ? onDragStart : undefined,
          onDragOver: dragArmed ? onDragOver : undefined,
          onDrop: dragArmed ? onDrop : undefined,
          onDragEnd: canDrag ? onDragEnd : undefined,
          onDoubleClick: node.blank ? undefined : (e) => {
            e.stopPropagation()
            onRename()
          },
          onMouseEnter: marquee.enter,
          onMouseLeave: marquee.leave,
          onKeyDown: (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault()
              onOpen()
            }
          },
          onClick: onOpen,
        },
          h('span', { className: 'dshAp_leadCell' }, leadElement),
          h('span', {
            ref: titleRef,
            className: `dshAp_rowTitle${node.unread ? ' dshAp_rowTitleUnread' : ''}`,
          }, node.title),
          showWorkspaceBadge && h('span', {
            className: 'dshAp_wsSourceTag',
            title: node.workspaceLabel,
          },
            h(IconFolder, { size: 11 }),
            node.workspaceLabel,
          ),
          !node.blank && h('span', { className: 'dshAp_rowTail dshAp_rowTailHideOnHover' },
            node.activeRun
              ? h(IconSpinner, { size: 13, accent: true })
              : h('span', null, formatRelativeTime(node.updatedAt, now, t)),
            node.pinScope === 'workspace' && !showWorkspaceBadge && !node.archived && h(IconPin, { size: 12.5, filled: true }),
          ),
          !node.blank && h('span', {
            className: 'dshAp_rowHoverActions',
            onClick: (e) => e.stopPropagation(),
          },
            h('button', {
              type: 'button',
              className: 'dshAp_miniBtn',
              'aria-label': t('session.actions'),
              onClick: (e) => {
                e.stopPropagation()
                onOpenMenu(e.currentTarget)
              },
            }, h(IconDots, { size: 14 })),
            h('button', {
              type: 'button',
              className: 'dshAp_miniBtn',
              'aria-label': t(node.archived ? 'action.unarchive' : 'action.archive'),
              onMouseEnter: (e) => showTooltip(e.currentTarget, t(node.archived ? 'action.unarchive' : 'action.archive')),
              onMouseLeave: hideTooltip,
              onClick: (e) => {
                e.stopPropagation()
                hideTooltip()
                onArchiveToggle()
              },
            }, h(IconArchive, { size: 13.5 })),
            !node.archived && h('button', {
              type: 'button',
              className: 'dshAp_miniBtn',
              'aria-label': t(node.isHostPinned ? 'action.unpin' : (quickPinTarget === 'workspace' ? 'action.pinWorkspace' : 'action.pinSpace')),
              onMouseEnter: (e) => showTooltip(
                e.currentTarget,
                t(node.isHostPinned ? 'action.unpin' : (quickPinTarget === 'workspace' ? 'action.pinWorkspace' : 'action.pinSpace')),
              ),
              onMouseLeave: hideTooltip,
              onClick: (e) => {
                e.stopPropagation()
                hideTooltip()
                onPinToggle()
              },
            }, h(IconPin, { size: 13.5, filled: node.isHostPinned })),
          ),
        )
      }

      // -----------------------------------------------------------------------
      // Main Sidebar Browser (`sidebar.workspaces` winner at priority -10)
      // -----------------------------------------------------------------------
      function CodexWorkspaceSidebar(props) {
        const {
          wide,
          expandSidebar,
          useWorkspaces,
          useSessions,
          useSessionStatus,
          usePanelInfo,
          t,
        } = props

        const hostState = useMiniStore(hostStore)
        const ui = useMiniStore(uiStore)
        const activePopoverId = useMiniStore(overlayStore, (s) => s.popover?.id ?? null)
        const scheduledIds = useMiniStore(scheduledSessionsStore, (s) => s.ids)

        const list = (useSessions ? useSessions((s) => s) : null) ?? { ids: [], byId: {}, projectionsBySession: {} }
        const statuses = (useSessionStatus ? useSessionStatus((s) => s) : null) ?? new Map()
        const panelActive = usePanelInfo ? usePanelInfo((info) => info?.activePanelId !== null) : false
        const storedWorkspaces = (useWorkspaces ? useWorkspaces((s) => s?.items) : null) ?? []
        const archivedSessionIds = (useWorkspaces ? useWorkspaces((s) => s?.archivedSessionIds) : null) ?? []
        const pinnedSessionIds = (useWorkspaces ? useWorkspaces((s) => s?.pinnedSessionIds) : null) ?? []

        const [searchOpen, setSearchOpen] = useState(false)
        const [query, setQuery] = useState('')
        const [remoteSearch, setRemoteSearch] = useState({ query: '', status: 'idle', items: [], hasMore: false })
        const [watermarks, setWatermarks] = useState({})
        const [dragSession, setDragSession] = useState(null)
        const [dragWorkspace, setDragWorkspace] = useState(null)

        const searchInputRef = useRef(null)
        const hydratedProjectionsRef = useRef(new Set())
        const prevMainRef = useRef(null)

        // Keep relative timestamps fresh while idle.
        const [now, setNow] = useState(() => Date.now())
        useEffect(() => {
          const timer = window.setInterval(() => setNow(Date.now()), 60_000)
          return () => window.clearInterval(timer)
        }, [])

        const rawWsList = Array.isArray(storedWorkspaces)
          ? storedWorkspaces
          : (Array.isArray(storedWorkspaces?.items) ? storedWorkspaces.items : [])
        const rawArchived = Array.isArray(archivedSessionIds)
          ? archivedSessionIds
          : (Array.isArray(archivedSessionIds?.archivedSessionIds) ? archivedSessionIds.archivedSessionIds : [])
        const rawPinned = Array.isArray(pinnedSessionIds)
          ? pinnedSessionIds
          : (Array.isArray(pinnedSessionIds?.pinnedSessionIds) ? pinnedSessionIds.pinnedSessionIds : [])

        const defaultWsName = t('workspace.defaultName')
        const workspaces = useMemo(() => rawWsList.map((ws) => ({
          ...ws,
          displayTitle: ws.title === 'default-workspace' ? defaultWsName : ws.title,
        })), [rawWsList, defaultWsName])

        const archivedSet = useMemo(() => new Set(rawArchived), [rawArchived])
        const pinnedSet = useMemo(() => new Set(rawPinned), [rawPinned])
        const scheduledSet = useMemo(() => new Set(Array.isArray(scheduledIds) ? scheduledIds : []), [scheduledIds])

        const mainSessionSummary = useMemo(
          () => Object.values(list?.byId ?? {}).find((s) => (s?.retainedBy?.mainView ?? 0) > 0),
          [list?.byId],
        )
        const mainId = mainSessionSummary ? (mainSessionSummary.id ?? mainSessionSummary.sessionId) : undefined
        const selectedSessionId = panelActive ? undefined : mainId

        // Auto-mark main session as read when viewed or when a turn finishes while viewing it
        const mainProjEndAt = mainId ? (list?.projectionsBySession?.[mainId]?.values?.[PROJECTION_KEY]?.lastTurnEndAt ?? 0) : 0
        const mainUpdatedAt = mainSessionSummary?.updatedAt ?? 0
        useEffect(() => {
          if (!selectedSessionId) return
          const justSwitched = prevMainRef.current !== selectedSessionId
          prevMainRef.current = selectedSessionId
          const readMark = hostState.readAt?.[selectedSessionId] ?? 0
          const forced = hostState.forceUnread?.[selectedSessionId] === true
          const targetTs = Math.max(mainUpdatedAt, mainProjEndAt)
          if (justSwitched && forced) {
            operations.markRead(selectedSessionId, Math.max(Date.now(), targetTs))
          } else if (targetTs > 0 && targetTs > readMark) {
            operations.markRead(selectedSessionId, Math.max(Date.now(), targetTs))
          }
        }, [selectedSessionId, mainUpdatedAt, mainProjEndAt, hostState.readAt, hostState.forceUnread])

        // Ensure currently active session's workspace is permanently recorded as expanded
        useEffect(() => {
          if (!selectedSessionId) return
          const owningWs = workspaces.find((w) => (w.sessionIds ?? []).includes(selectedSessionId))
          if (owningWs && ui.groupExpansion[owningWs.workspaceId] !== true) {
            const nextExpansion = { ...ui.groupExpansion, [owningWs.workspaceId]: true }
            uiStore.set((c) => ({ ...c, groupExpansion: nextExpansion }))
            writeNativeGroupExpansion(nextExpansion)
          }
        }, [selectedSessionId, workspaces])

        // Lazily hydrate cold-session snippet projections when Activity View opens
        useEffect(() => {
          if (!ui.activityOpen) return undefined
          syncFromHost()
          if (typeof ctx.sessions?.refreshProjections !== 'function') return undefined
          let cancelled = false
          const candidates = (list?.ids ?? [])
            .filter((id) => {
              const s = list?.byId?.[id]
              if (!s || s.blank || s.origin === 'subagent') return false
              if (hydratedProjectionsRef.current.has(id)) return false
              const existing = list?.projectionsBySession?.[id]?.values?.[PROJECTION_KEY]
                ?? s.projectionValues?.[PROJECTION_KEY]
              return existing === undefined
            })
            .slice(0, 24)

          ;(async () => {
            for (const sid of candidates) {
              if (cancelled) break
              hydratedProjectionsRef.current.add(sid)
              try {
                await ctx.sessions.refreshProjections(sid)
              } catch (_err) {}
            }
          })()
          return () => { cancelled = true }
        }, [ui.activityOpen, list?.ids?.length])

        const workspaceBySession = useMemo(() => {
          const map = new Map()
          for (const ws of workspaces) {
            for (const sid of (ws.sessionIds ?? [])) {
              if (!map.has(sid)) {
                map.set(sid, ws)
              }
            }
          }
          return map
        }, [workspaces])

        const enrichedById = useMemo(() => {
          const out = new Map()
          for (const rawId of (list?.ids ?? [])) {
            const summary = list?.byId?.[rawId]
            if (!summary) continue
            const id = summary.id ?? summary.sessionId ?? rawId
            if (summary.origin === 'subagent') continue
            const status = statuses?.get ? statuses.get(id) : undefined
            const proj = list?.projectionsBySession?.[id]?.values?.[PROJECTION_KEY]
              ?? summary.projectionValues?.[PROJECTION_KEY]
              ?? {}
            const subCatalog = list?.projectionsBySession?.[id]?.values?.subagentCatalog
            const runningSubagents = Array.isArray(subCatalog)
              ? subCatalog.reduce((acc, child) => acc + (((((statuses?.get ? statuses.get(child.id)?.running : undefined) ?? list?.byId?.[child.id]?.running) === true) ? 1 : 0)), 0)
              : 0

            const running = (status?.running ?? summary.running) === true
            const pendingKind = ['approval', 'plan-review', 'question'].includes(status?.pendingInteraction?.kind)
              ? status.pendingInteraction.kind
              : undefined
            const archived = archivedSet.has(id)
            const isHostPinned = !archived && pinnedSet.has(id)
            const pinScope = resolvePinScope(id, isHostPinned, hostState)
            const ws = workspaceBySession.get(id)
            const wsLabel = ws ? ws.displayTitle : (basenameOfPath(summary.cwd) || t('section.ungrouped'))

            const unread = !archived && !summary.blank && checkSessionUnread({
              sessionId: id,
              running: running || runningSubagents > 0,
              completionUnread: status?.completionUnread === true,
              lastTurnEndAt: proj.lastTurnEndAt ?? 0,
              updatedAt: summary.updatedAt ?? 0,
              isMain: id === selectedSessionId,
            }, hostState)

            out.set(id, {
              id,
              rawTitle: summary.blank ? '' : (summary.title?.trim() ?? ''),
              title: summary.blank
                ? t('session.new')
                : (summary.title?.trim() || t('session.untitled')),
              blank: summary.blank === true,
              running,
              runningSubagents,
              activeRun: running || runningSubagents > 0,
              pendingKind,
              unread,
              archived,
              isHostPinned,
              pinScope,
              scheduled: scheduledSet.has(id),
              workspaceId: ws?.workspaceId,
              workspaceLabel: wsLabel,
              updatedAt: summary.updatedAt ?? 0,
              lastTurnEndAt: proj.lastTurnEndAt ?? 0,
              snippet: proj.lastAssistantSnippet ?? '',
            })
          }
          return out
        }, [
          list,
          statuses,
          archivedSet,
          pinnedSet,
          scheduledSet,
          hostState,
          workspaceBySession,
          selectedSessionId,
          t,
        ])

        const activityStats = useMemo(() => {
          let runningCount = 0
          let unreadCount = 0
          let pendingCount = 0
          for (const node of enrichedById.values()) {
            if (node.blank || node.archived) continue
            if (node.pendingKind) pendingCount += 1
            if (node.activeRun) runningCount += 1
            else if (node.unread) unreadCount += 1
          }
          return {
            runningCount,
            unreadCount,
            pendingCount,
            totalAttention: runningCount + unreadCount + pendingCount,
          }
        }, [enrichedById])

        const handleOpenSession = useCallback((sessionId) => {
          const node = enrichedById.get(sessionId)
          if (node?.archived) {
            showToast(t('toast.archivedNotOpenable'))
            return
          }
          if (node && !node.blank) {
            operations.markRead(sessionId, Math.max(Date.now(), node.updatedAt, node.lastTurnEndAt))
          }
          ctx.uiWorkspace.openSession(sessionId)
        }, [enrichedById, t])

        const trimmedQuery = query.replaceAll('\0', '').slice(0, SEARCH_MAX_CHARS).trim()
        useEffect(() => {
          if (trimmedQuery === '') {
            setRemoteSearch({ query: '', status: 'idle', items: [], hasMore: false })
            return undefined
          }
          const controller = new AbortController()
          setRemoteSearch({ query: trimmedQuery, status: 'loading', items: [], hasMore: false })
          const timer = window.setTimeout(() => {
            ctx.sessions.search(trimmedQuery, controller.signal).then((res) => {
              if (controller.signal.aborted) return
              if (res.ok) {
                setRemoteSearch({
                  query: trimmedQuery,
                  status: 'ready',
                  items: res.value.items ?? [],
                  hasMore: Boolean(res.value.hasMore),
                })
              } else {
                setRemoteSearch({ query: trimmedQuery, status: 'error', items: [], hasMore: false })
              }
            }).catch(() => {
              if (!controller.signal.aborted) {
                setRemoteSearch({ query: trimmedQuery, status: 'error', items: [], hasMore: false })
              }
            })
          }, SEARCH_DEBOUNCE_MS)
          return () => {
            window.clearTimeout(timer)
            controller.abort()
          }
        }, [trimmedQuery])

        // Esc closes search unless a menu or dialog owns the key.
        useEffect(() => {
          if (!searchOpen) return undefined
          const onKeyDown = (e) => {
            if (e.key !== 'Escape') return
            const stage = overlayStore.getSnapshot()
            if (stage.modal !== null || stage.popover !== null) return
            setQuery('')
            setSearchOpen(false)
          }
          document.addEventListener('keydown', onKeyDown)
          return () => document.removeEventListener('keydown', onKeyDown)
        }, [searchOpen])

        const dragActive = dragSession !== null || dragWorkspace !== null
        useEffect(() => {
          if (!dragActive) return undefined
          const onDragOver = (e) => {
            e.preventDefault()
            if (e.dataTransfer) e.dataTransfer.dropEffect = 'move'
          }
          const onDrop = (e) => e.preventDefault()
          document.addEventListener('dragover', onDragOver)
          document.addEventListener('drop', onDrop)
          return () => {
            document.removeEventListener('dragover', onDragOver)
            document.removeEventListener('drop', onDrop)
          }
        }, [dragActive])

        // Session "..." Menu
        const openSessionActionsMenu = useCallback((node, anchorEl) => {
          const popId = `session-menu:${node.id}`
          openPopover(popId, anchorEl, (dismiss) => {
            const curHost = hostStore.getSnapshot()
            const effectiveScope = resolvePinScope(node.id, node.isHostPinned, curHost)
            const inSpace = effectiveScope === 'space'
            const inWs = effectiveScope === 'workspace'

            return h(Fragment, null,
              // Pin options depending on global pinMode
              !node.archived && curHost.pinMode === 'workspace' && h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  if (node.isHostPinned) operations.unpin(node.id)
                  else operations.pinInWorkspace(node.id)
                },
              },
                h('span', { className: 'dshAp_menuItemIcon' }, h(IconPin, { filled: node.isHostPinned })),
                h('span', { className: 'dshAp_menuItemText' }, t(node.isHostPinned ? 'menu.unpin' : 'menu.pinSession')),
                node.isHostPinned && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              !node.archived && curHost.pinMode !== 'workspace' && h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  if (inSpace) operations.unpin(node.id)
                  else operations.pinToSpace(node.id)
                },
              },
                h('span', { className: 'dshAp_menuItemIcon' }, h(IconPin, { filled: inSpace })),
                h('span', { className: 'dshAp_menuItemText' },
                  t(inSpace ? 'menu.unpinFromSpace' : (inWs ? 'menu.moveToSpace' : 'menu.pinToSpace')),
                ),
                inSpace && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              !node.archived && curHost.pinMode === 'hybrid' && h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  if (inWs) operations.unpin(node.id)
                  else operations.pinInWorkspace(node.id)
                },
              },
                h('span', { className: 'dshAp_menuItemIcon' }, h(IconFolder, { size: 14 })),
                h('span', { className: 'dshAp_menuItemText' },
                  t(inWs ? 'menu.unpinInWorkspace' : (inSpace ? 'menu.moveToWorkspacePin' : 'menu.pinInWorkspace')),
                ),
                inWs && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              // Mark read/unread
              !node.archived && !node.activeRun && h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  if (node.unread) {
                    operations.markRead(node.id, Math.max(Date.now(), node.updatedAt, node.lastTurnEndAt))
                  } else {
                    operations.markUnread(node.id)
                  }
                },
              },
                h('span', { className: 'dshAp_menuItemIcon' }, h(IconMailDot, { unread: !node.unread })),
                h('span', { className: 'dshAp_menuItemText' }, t(node.unread ? 'menu.markRead' : 'menu.markUnread')),
              ),
              h('div', { className: 'dshAp_menuSep' }),
              // Rename
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  overlayStore.set((c) => ({
                    ...c,
                    modal: {
                      kind: 'rename-session',
                      sessionId: node.id,
                      initialTitle: node.rawTitle,
                    },
                  }))
                },
              },
                h('span', { className: 'dshAp_menuItemIcon' }, h(IconEdit, {})),
                h('span', { className: 'dshAp_menuItemText' }, t('menu.renameSession')),
              ),
              // Fork
              !node.archived && h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  ctx.uiWorkspace.forkSession(node.id).catch((err) => {
                    showToast(t('toast.error', { message: err instanceof Error ? err.message : String(err) }))
                  })
                },
              },
                h('span', { className: 'dshAp_menuItemIcon' }, h(IconBranch, {})),
                h('span', { className: 'dshAp_menuItemText' }, t('menu.forkSession')),
              ),
              // Archive / Unarchive
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  if (node.archived) {
                    ctx.uiWorkspace.unarchiveSession(node.id).catch(() => {})
                  } else {
                    operations.archiveSessionWithConfirm(node.id, node.title, t)
                  }
                },
              },
                h('span', { className: 'dshAp_menuItemIcon' }, h(IconArchive, {})),
                h('span', { className: 'dshAp_menuItemText' }, t(node.archived ? 'menu.unarchiveSession' : 'menu.archiveSession')),
              ),
              // Copy Session ID
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  if (navigator.clipboard?.writeText) {
                    navigator.clipboard.writeText(node.id).then(() => showToast(t('toast.copied'))).catch(() => {})
                  }
                },
              },
                h('span', { className: 'dshAp_menuItemIcon' }, h(IconCopy, {})),
                h('span', { className: 'dshAp_menuItemText' }, t('menu.copySessionId')),
              ),
            )
          }, 'end', 236)
        }, [t])

        // Collapsed Rail Mode
        if (!wide) {
          return h('div', { className: 'dshAp_root dshAp_rail' },
            h('button', {
              type: 'button',
              className: `dshAp_railBtn${ui.activityOpen ? ' dshAp_railBtnActive' : ''}`,
              'aria-label': t(ui.activityOpen ? 'activity.close' : 'activity.open'),
              'aria-pressed': ui.activityOpen,
              onMouseEnter: (e) => showTooltip(e.currentTarget, t(ui.activityOpen ? 'activity.close' : 'activity.open'), 'act-toggle'),
              onMouseLeave: hideTooltip,
              onClick: () => {
                hideTooltip()
                uiStore.set((c) => {
                  const next = !c.activityOpen
                  if (next && typeof expandSidebar === 'function') expandSidebar()
                  return { ...c, activityOpen: next }
                })
              },
            },
              h(IconBell, { size: 18, filled: ui.activityOpen }),
              activityStats.totalAttention > 0 && h('span', {
                className: `dshAp_bellBadge${activityStats.pendingCount > 0 ? ' dshAp_bellBadgeWarn' : ''}`,
              }),
            ),
            h('button', {
              type: 'button',
              className: 'dshAp_railBtn',
              'aria-label': t('search.label'),
              onMouseEnter: (e) => showTooltip(e.currentTarget, t('search.label')),
              onMouseLeave: hideTooltip,
              onClick: () => {
                hideTooltip()
                setSearchOpen(true)
                if (typeof expandSidebar === 'function') expandSidebar()
                setTimeout(() => searchInputRef.current?.focus(), 260)
              },
            }, h(IconSearch, { size: 18 })),
            h('button', {
              type: 'button',
              className: 'dshAp_railBtn',
              'aria-label': t('workspace.add'),
              onMouseEnter: (e) => showTooltip(e.currentTarget, t('workspace.add')),
              onMouseLeave: hideTooltip,
              onClick: () => {
                hideTooltip()
                triggerAddWorkspace(t)
              },
            }, h(IconPlus, { size: 18 })),
          )
        }

        const bellLabel = t(ui.activityOpen ? 'activity.close' : 'activity.open')

        // View & Pinning Options Menu (Dropdown)
        const openViewOptionsMenu = (anchorEl) => {
          openPopover('view-options', anchorEl, (dismiss) => {
            const curUi = uiStore.getSnapshot()
            const curHost = hostStore.getSnapshot()
            const pickGroup = (mode) => {
              uiStore.set((c) => ({ ...c, groupBy: mode }))
              try {
                const curNative = loadNativeWorkspaceView()
                localStorage.setItem(DSH_NATIVE_VIEW_KEY, JSON.stringify({ ...curNative, groupBy: mode }))
              } catch (_err) {}
              dismiss()
            }
            const pickOrder = (mode) => {
              uiStore.set((c) => ({ ...c, orderBy: mode }))
              try {
                const curNative = loadNativeWorkspaceView()
                localStorage.setItem(DSH_NATIVE_VIEW_KEY, JSON.stringify({ ...curNative, orderBy: mode }))
              } catch (_err) {}
              dismiss()
            }
            const pickArchive = (mode) => {
              uiStore.set((c) => ({ ...c, archivedFilter: mode }))
              try {
                const curNative = loadNativeWorkspaceView()
                localStorage.setItem(DSH_NATIVE_VIEW_KEY, JSON.stringify({ ...curNative, archivedFilter: mode }))
              } catch (_err) {}
              dismiss()
            }
            const pickPinMode = (mode) => {
              operations.setPinConfig({ pinMode: mode })
              dismiss()
            }
            return h(Fragment, null,
              h('div', { className: 'dshAp_menuSectionLabel' }, t('pinMode.label')),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickPinMode('workspace') },
                h('span', { className: 'dshAp_menuItemText' }, t('pinMode.workspace')),
                curHost.pinMode === 'workspace' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickPinMode('space') },
                h('span', { className: 'dshAp_menuItemText' }, t('pinMode.space')),
                curHost.pinMode === 'space' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickPinMode('hybrid') },
                h('span', { className: 'dshAp_menuItemText' }, t('pinMode.hybrid')),
                curHost.pinMode === 'hybrid' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('div', { className: 'dshAp_menuSep' }),
              h('div', { className: 'dshAp_menuSectionLabel' }, t('groupBy.label')),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickGroup('workspace') },
                h('span', { className: 'dshAp_menuItemText' }, t('groupBy.workspace')),
                curUi.groupBy === 'workspace' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickGroup('workspace-tree') },
                h('span', { className: 'dshAp_menuItemText' }, t('groupBy.workspaceTree')),
                curUi.groupBy === 'workspace-tree' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickGroup('flat') },
                h('span', { className: 'dshAp_menuItemText' }, t('groupBy.flat')),
                curUi.groupBy === 'flat' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('div', { className: 'dshAp_menuSep' }),
              h('div', { className: 'dshAp_menuSectionLabel' }, t('orderBy.label')),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickOrder('updated') },
                h('span', { className: 'dshAp_menuItemText' }, t('orderBy.updated')),
                curUi.orderBy === 'updated' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickOrder('manual') },
                h('span', { className: 'dshAp_menuItemText' }, t('orderBy.manual')),
                curUi.orderBy === 'manual' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('div', { className: 'dshAp_menuSep' }),
              h('div', { className: 'dshAp_menuSectionLabel' }, t('filterBy.label')),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickArchive('default') },
                h('span', { className: 'dshAp_menuItemText' }, t('filter.hideArchived')),
                curUi.archivedFilter === 'default' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickArchive('show') },
                h('span', { className: 'dshAp_menuItemText' }, t('filter.showArchived')),
                curUi.archivedFilter === 'show' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', { type: 'button', role: 'menuitem', className: 'dshAp_menuItem', onClick: () => pickArchive('only') },
                h('span', { className: 'dshAp_menuItemText' }, t('filter.onlyArchived')),
                curUi.archivedFilter === 'only' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
            )
          }, 'end', 260)
        }

        // Pinned Space Options Menu
        const openPinSpaceOptionsMenu = (anchorEl) => {
          openPopover('pin-space-options', anchorEl, (dismiss) => {
            const curHost = hostStore.getSnapshot()
            const toggleHideInWs = () => {
              operations.setPinConfig({ hideSpacePinsInWorkspace: !curHost.hideSpacePinsInWorkspace })
              dismiss()
            }
            const toggleAlwaysShow = () => {
              operations.setPinConfig({ alwaysShowPinSpace: !curHost.alwaysShowPinSpace })
              dismiss()
            }
            const pickDefaultTarget = (target) => {
              operations.setPinConfig({ defaultPinTarget: target })
              dismiss()
            }
            const pickPinMode = (mode) => {
              operations.setPinConfig({ pinMode: mode })
              dismiss()
            }

            return h(Fragment, null,
              h('div', { className: 'dshAp_menuSectionLabel' }, t('pinSpace.options')),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: toggleHideInWs,
              },
                h('span', { className: 'dshAp_menuItemText' }, t('pinOption.hideInWorkspace')),
                curHost.hideSpacePinsInWorkspace && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: toggleAlwaysShow,
              },
                h('span', { className: 'dshAp_menuItemText' }, t('pinOption.alwaysShowSpace')),
                curHost.alwaysShowPinSpace && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('div', { className: 'dshAp_menuSep' }),
              h('div', { className: 'dshAp_menuSectionLabel' }, t('pinDefault.label')),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => pickDefaultTarget('space'),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('pinDefault.space')),
                curHost.defaultPinTarget === 'space' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => pickDefaultTarget('workspace'),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('pinDefault.workspace')),
                curHost.defaultPinTarget === 'workspace' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('div', { className: 'dshAp_menuSep' }),
              h('div', { className: 'dshAp_menuSectionLabel' }, t('pinMode.label')),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => pickPinMode('hybrid'),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('pinMode.hybrid')),
                curHost.pinMode === 'hybrid' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => pickPinMode('space'),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('pinMode.space')),
                curHost.pinMode === 'space' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => pickPinMode('workspace'),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('pinMode.workspace')),
                curHost.pinMode === 'workspace' && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
            )
          }, 'end', 260)
        }

        // Activity Options Menu
        const openActivityOptionsMenu = (anchorEl) => {
          openPopover('activity-options', anchorEl, (dismiss) => {
            const prefs = hostStore.getSnapshot().activityPrefs
            const curArchived = uiStore.getSnapshot().archivedFilter
            const unreadIds = [...enrichedById.values()]
              .filter((n) => !n.blank && !n.archived)
              .map((n) => n.id)
            const hasUnread = activityStats.unreadCount > 0

            return h(Fragment, null,
              h('div', { className: 'dshAp_menuSectionLabel' }, t('activity.menu.show')),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => operations.setActivityPrefs({ showPrioritySection: !prefs.showPrioritySection }),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('activity.menu.prioritySection')),
                prefs.showPrioritySection && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => operations.setActivityPrefs({ includePinnedInPriority: !prefs.includePinnedInPriority }),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('activity.menu.pinned')),
                prefs.includePinnedInPriority && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => operations.setActivityPrefs({ includeScheduledInPriority: !prefs.includeScheduledInPriority }),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('activity.menu.scheduled')),
                prefs.includeScheduledInPriority && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => operations.setActivityPrefs({ unreadOnly: !prefs.unreadOnly }),
              },
                h('span', { className: 'dshAp_menuItemText' }, t('activity.menu.unreadOnly')),
                prefs.unreadOnly && h('span', { className: 'dshAp_menuItemCheck' }, h(IconCheck, {})),
              ),
              h('div', { className: 'dshAp_menuSep' }),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                disabled: !hasUnread,
                onClick: () => {
                  dismiss()
                  operations.markAllRead(unreadIds)
                },
              },
                h('span', { className: 'dshAp_menuItemText' }, t('activity.menu.markAllRead')),
              ),
              h('button', {
                type: 'button',
                role: 'menuitem',
                className: 'dshAp_menuItem',
                onClick: () => {
                  dismiss()
                  uiStore.set((c) => ({
                    ...c,
                    activityOpen: false,
                    archivedFilter: curArchived === 'only' ? 'default' : 'only',
                  }))
                },
              },
                h('span', { className: 'dshAp_menuItemText' },
                  t(curArchived === 'only' ? 'activity.menu.backToNormal' : 'activity.menu.archiveChats'),
                ),
              ),
            )
          }, 'start', 216)
        }

        // ---------------------------------------------------------------------
        // Row element builder: no hooks here, SessionRow owns them.
        // ---------------------------------------------------------------------
        const renderSessionRow = (node, options = {}) => {
          const {
            contextKey = '',
            indented = false,
            showWorkspaceBadge = false,
            orderedIds = [],
            onReorder,
          } = options
          const canDrag = !node.blank && !node.archived && typeof onReorder === 'function'
          const sameDragContext = dragSession !== null && dragSession.contextKey === contextKey
          const dropHalf = sameDragContext && dragSession.overId === node.id ? dragSession.half : null
          const quickPinTarget = hostState.pinMode === 'workspace'
            ? 'workspace'
            : (hostState.pinMode === 'space' ? 'space' : hostState.defaultPinTarget)

          return h(SessionRow, {
            key: `${contextKey}:${node.id}`,
            contextKey,
            node,
            t,
            now,
            selected: node.id === selectedSessionId,
            menuOpen: activePopoverId === `session-menu:${node.id}`,
            indented,
            showWorkspaceBadge,
            quickPinTarget,
            canDrag,
            dragArmed: sameDragContext,
            dropHalf,
            onOpen: () => handleOpenSession(node.id),
            onOpenMenu: (anchorEl) => openSessionActionsMenu(node, anchorEl),
            onRename: () => overlayStore.set((c) => ({
              ...c,
              modal: { kind: 'rename-session', sessionId: node.id, initialTitle: node.rawTitle },
            })),
            onArchiveToggle: () => {
              if (node.archived) {
                ctx.uiWorkspace.unarchiveSession(node.id).catch(() => {})
                return
              }
              operations.archiveSessionWithConfirm(node.id, node.title, t)
            },
            onPinToggle: () => {
              if (node.isHostPinned) operations.unpin(node.id)
              else if (quickPinTarget === 'workspace') operations.pinInWorkspace(node.id)
              else operations.pinToSpace(node.id)
            },
            onDragStart: (e) => {
              e.dataTransfer.effectAllowed = 'move'
              e.dataTransfer.setData('text/plain', node.id)
              setDragSession({ contextKey, sessionId: node.id, overId: null, half: null })
            },
            onDragOver: (e) => {
              if (!dragSession || dragSession.sessionId === node.id) return
              e.preventDefault()
              const rect = e.currentTarget.getBoundingClientRect()
              const half = e.clientY < rect.top + rect.height / 2 ? 'before' : 'after'
              setDragSession((cur) => (cur ? { ...cur, overId: node.id, half: node.blank ? 'after' : half } : null))
            },
            onDrop: (e) => {
              e.preventDefault()
              if (!dragSession || dragSession.sessionId === node.id) {
                setDragSession(null)
                return
              }
              const rect = e.currentTarget.getBoundingClientRect()
              const half = node.blank ? 'after' : (e.clientY < rect.top + rect.height / 2 ? 'before' : 'after')
              const without = orderedIds.filter((id) => id !== dragSession.sessionId)
              const idx = without.indexOf(node.id)
              if (idx !== -1) {
                without.splice(idx + (half === 'after' ? 1 : 0), 0, dragSession.sessionId)
                onReorder(without)
              }
              setDragSession(null)
            },
            onDragEnd: () => setDragSession(null),
          })
        }

        // ---------------------------------------------------------------------
        // Render 1: Activity View
        // ---------------------------------------------------------------------
        const renderActivityView = () => {
          const prefs = hostState.activityPrefs
          const allNodes = [...enrichedById.values()]
            .filter((n) => !n.blank && !n.archived)
            .sort((a, b) => Math.max(b.updatedAt, b.lastTurnEndAt) - Math.max(a.updatedAt, a.lastTurnEndAt))

          const isPriorityNode = (n) => {
            if (n.activeRun || n.pendingKind !== undefined || n.unread) return true
            if (prefs.includePinnedInPriority && n.pinScope !== null) return true
            if (prefs.includeScheduledInPriority && n.scheduled) return true
            return false
          }

          const priorityNodes = prefs.showPrioritySection
            ? allNodes.filter(isPriorityNode).sort((a, b) => {
              if (a.activeRun !== b.activeRun) return a.activeRun ? -1 : 1
              if ((a.pendingKind !== undefined) !== (b.pendingKind !== undefined)) {
                return a.pendingKind !== undefined ? -1 : 1
              }
              if (a.unread !== b.unread) return a.unread ? -1 : 1
              return Math.max(b.updatedAt, b.lastTurnEndAt) - Math.max(a.updatedAt, a.lastTurnEndAt)
            })
            : []

          const priorityIds = new Set(priorityNodes.map((n) => n.id))
          const feedCandidates = allNodes.filter((n) => {
            if (priorityIds.has(n.id)) return false
            if (prefs.unreadOnly) return n.activeRun || n.pendingKind !== undefined || n.unread
            return true
          })

          const dateGroups = []
          const groupMap = new Map()
          for (const node of feedCandidates) {
            const ts = Math.max(node.updatedAt, node.lastTurnEndAt)
            const bucket = formatActivityDateBucket(ts, now, t)
            let grp = groupMap.get(bucket.key)
            if (!grp) {
              grp = { key: bucket.key, label: bucket.label, items: [] }
              groupMap.set(bucket.key, grp)
              dateGroups.push(grp)
            }
            grp.items.push(node)
          }

          const rowKeys = []
          if (prefs.showPrioritySection) {
            rowKeys.push('act:priority:header')
            for (const p of priorityNodes) rowKeys.push(`act:priority:${p.id}`)
          }
          for (const dg of dateGroups) {
            rowKeys.push(`act:date:${dg.key}`)
            for (const item of dg.items) rowKeys.push(`act:item:${item.id}`)
          }
          if (dateGroups.length === 0 && priorityNodes.length === 0) rowKeys.push('act:empty')

          return h(AnimatedRows, {
            key: 'activity',
            className: 'dshAp_treeContainer dshAp_viewFadeIn',
            label: t('section.activity'),
            ready: list?.phase !== 'loading',
            rowKeys,
            resetKey: 'activity',
          },
            // Priority section
            prefs.showPrioritySection && h('div', { key: 'act:priority', className: 'dshAp_actSection' },
              h('div', {
                'data-row-key': 'act:priority:header',
                className: 'dshAp_actGroupTitle',
              },
                h('span', null, t('section.priority')),
                h('button', {
                  type: 'button',
                  className: 'dshAp_miniBtn',
                  'aria-label': t('activity.menu.show'),
                  onClick: (e) => {
                    e.stopPropagation()
                    openActivityOptionsMenu(e.currentTarget)
                  },
                }, h(IconDots, { size: 14 })),
              ),
              priorityNodes.length === 0
                ? h('div', { className: 'dshAp_emptyHint', style: { paddingLeft: '10px' } }, t('activity.priorityEmpty'))
                : priorityNodes.map((node) => {
                  const selected = node.id === selectedSessionId
                  const statusBadge = node.pendingKind === 'approval'
                    ? t('status.approval')
                    : node.pendingKind === 'plan-review'
                      ? t('status.planReview')
                      : node.pendingKind === 'question'
                        ? t('status.answer')
                        : (node.runningSubagents > 0 && !node.running ? t('status.subagents', { n: node.runningSubagents }) : null)
                  return h('div', {
                    key: node.id,
                    'data-row-key': `act:priority:${node.id}`,
                    className: `dshAp_priorityCard${selected ? ' dshAp_priorityCardSelected' : ''}`,
                    role: 'button',
                    tabIndex: 0,
                    onClick: () => handleOpenSession(node.id),
                    onKeyDown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleOpenSession(node.id) } },
                  },
                    h('div', { className: 'dshAp_actTopLine' },
                      node.unread && !node.activeRun && h('span', { className: 'dshAp_dot dshAp_dotUnread' }),
                      node.pendingKind && h('span', { className: 'dshAp_dot dshAp_dotWarn' }),
                      h('span', { className: `dshAp_actTitle${node.unread ? ' dshAp_actTitleUnread' : ''}` }, node.title),
                      h('span', { className: 'dshAp_actWsName' }, node.workspaceLabel),
                      node.activeRun && h(IconSpinner, { size: 14, accent: true }),
                      h('button', {
                        type: 'button',
                        className: 'dshAp_miniBtn dshAp_actHoverMenuBtn',
                        'aria-label': t('session.actions'),
                        onClick: (e) => {
                          e.stopPropagation()
                          openSessionActionsMenu(node, e.currentTarget)
                        },
                      }, h(IconDots, { size: 14 })),
                    ),
                    h('div', { className: 'dshAp_actSubLine' },
                      h(IconFolder, { size: 12.5 }),
                      h('span', { style: { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' } },
                        statusBadge ? `${node.workspaceLabel} · ${statusBadge}` : node.workspaceLabel,
                      ),
                    ),
                    node.snippet && !node.activeRun && h('div', { className: 'dshAp_actSnippet' }, node.snippet),
                  )
                }),
            ),

            // Date groups
            dateGroups.length === 0 && priorityNodes.length === 0
              ? h('div', { key: 'act:empty', 'data-row-key': 'act:empty', className: 'dshAp_emptyBlock' },
                h(IconBell, { size: 22 }),
                h('div', null, t(prefs.unreadOnly ? 'activity.empty' : 'activity.emptyAll')),
              )
              : dateGroups.map((grp) => h('div', { key: grp.key, className: 'dshAp_actSection' },
                h('div', {
                  'data-row-key': `act:date:${grp.key}`,
                  className: 'dshAp_actGroupTitle',
                },
                  h('span', null, grp.label),
                ),
                grp.items.map((node) => {
                  const selected = node.id === selectedSessionId
                  const menuOpen = activePopoverId === `session-menu:${node.id}`
                  return h('div', {
                    key: node.id,
                    'data-row-key': `act:item:${node.id}`,
                    className: `dshAp_actRow${selected ? ' dshAp_actRowSelected' : ''}${menuOpen ? ' dshAp_actRowMenuOpen' : ''}`,
                    role: 'button',
                    tabIndex: 0,
                    onClick: () => handleOpenSession(node.id),
                    onKeyDown: (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleOpenSession(node.id) } },
                  },
                    h('div', { className: 'dshAp_actTopLine' },
                      node.unread && !node.activeRun && h('span', { className: 'dshAp_dot dshAp_dotUnread' }),
                      h('span', { className: `dshAp_actTitle${node.unread ? ' dshAp_actTitleUnread' : ''}` }, node.title),
                      h('span', { className: 'dshAp_actWsName' }, node.workspaceLabel),
                      node.activeRun && h(IconSpinner, { size: 13.5, accent: true }),
                      h('button', {
                        type: 'button',
                        className: 'dshAp_miniBtn dshAp_actHoverMenuBtn',
                        'aria-label': t('session.actions'),
                        onClick: (e) => {
                          e.stopPropagation()
                          openSessionActionsMenu(node, e.currentTarget)
                        },
                      }, h(IconDots, { size: 14 })),
                    ),
                    h('div', { className: 'dshAp_actSnippet' },
                      node.snippet || formatRelativeTime(node.updatedAt, now, t),
                    ),
                  )
                }),
              )),
          )
        }

        // ---------------------------------------------------------------------
        // Render 2: Codex Normal View (置顶 strictly ABOVE 项目 ⌄)
        // ---------------------------------------------------------------------
        const renderNormalView = () => {
          const isSessionVisibleInFilter = (node) => {
            if (!node) return false
            if (node.blank && node.id !== selectedSessionId) return false
            if (ui.archivedFilter === 'default') return !node.archived
            if (ui.archivedFilter === 'only') return node.archived
            return true
          }

          // Standalone pinned area: shown above the project list unless pinMode is 'workspace'
          const showTopPinSpace = ui.archivedFilter !== 'only' && hostState.pinMode !== 'workspace'
          const rawSpacePinIds = showTopPinSpace
            ? rawPinned.filter((id) => {
              const node = enrichedById.get(id)
              return node && !node.blank && !node.archived && node.pinScope === 'space'
            })
            : []
          const orderRank = new Map((hostState.spaceOrder ?? []).map((id, i) => [id, i]))
          const spacePinNodes = [...rawSpacePinIds]
            .sort((a, b) => {
              const ra = orderRank.get(a)
              const rb = orderRank.get(b)
              if (ra !== undefined && rb !== undefined) return ra - rb
              if (ra !== undefined) return -1
              if (rb !== undefined) return 1
              return 0
            })
            .map((id) => enrichedById.get(id))
            .filter(Boolean)

          const renderTopPinSpace = showTopPinSpace && (spacePinNodes.length > 0 || hostState.alwaysShowPinSpace)
          const spacePinSet = new Set(spacePinNodes.map((n) => n.id))

          const owningWsId = enrichedById.get(selectedSessionId)?.workspaceId
          const isGroupExpanded = (grp) => (Object.hasOwn(ui.groupExpansion, grp.key)
            ? Boolean(ui.groupExpansion[grp.key])
            : (grp.workspaceId !== undefined && grp.workspaceId === owningWsId) || workspaces.length <= 6)

          // One derivation feeds the FLIP row keys and the rows alike.
          const sliceVisible = (grp) => {
            let autoReq = SESSION_WATERMARK_BASE
            let nonBlankIdx = 0
            for (const s of grp.sessions) {
              if (s.blank) continue
              nonBlankIdx += 1
              if (nonBlankIdx <= SESSION_WATERMARK_AUTO_MAX && (s.activeRun || s.pendingKind || s.unread || s.id === selectedSessionId)) {
                autoReq = Math.max(autoReq, nonBlankIdx)
              }
            }
            const stored = watermarks[grp.key] ?? SESSION_WATERMARK_BASE
            const wm = Math.max(autoReq, stored)
            let count = 0
            const visibleSessions = grp.sessions.filter((s) => {
              if (s.blank) return true
              count += 1
              return count <= wm
            })
            return {
              wm,
              visibleSessions,
              hiddenCount: grp.sessions.length - visibleSessions.length,
              manuallyRaised: stored > autoReq,
            }
          }

          const orderSessions = (ids) => {
            const blanks = []
            const wsPins = []
            const ordinary = []
            for (const id of ids) {
              const node = enrichedById.get(id)
              if (!node) continue
              if (node.blank) blanks.push(node)
              else if (node.pinScope === 'workspace') wsPins.push(node)
              else ordinary.push(node)
            }
            // The blank the user is currently editing leads its list.
            blanks.sort((a, b) => (b.id === selectedSessionId ? 1 : 0) - (a.id === selectedSessionId ? 1 : 0))
            return [...blanks, ...wsPins, ...ordinary]
          }

          const collectMembers = (rawMemberIds) => {
            const visibleIds = (rawMemberIds ?? []).filter((id) => {
              const node = enrichedById.get(id)
              if (!isSessionVisibleInFilter(node)) return false
              if (hostState.hideSpacePinsInWorkspace && spacePinSet.has(id)) return false
              return true
            })
            const base = ui.orderBy === 'manual'
              ? reconcileAccountOrder(visibleIds, ui.sessionOrderByAccount[ui.groupBy === 'flat' ? FLAT_ORDER_KEY : ''], list.byId)
              : orderIdsByRecency(visibleIds, list.byId)
            return orderSessions(base)
          }

          const flatMode = ui.groupBy === 'flat'

          // Single list: every session is one top-level row with a workspace badge.
          const flatNodes = flatMode
            ? orderSessions(
              ui.orderBy === 'manual'
                ? reconcileAccountOrder(
                  list.ids.filter((id) => {
                    const node = enrichedById.get(id)
                    if (!isSessionVisibleInFilter(node)) return false
                    if (hostState.hideSpacePinsInWorkspace && spacePinSet.has(id)) return false
                    return true
                  }),
                  ui.sessionOrderByAccount[FLAT_ORDER_KEY],
                  list.byId,
                )
                : orderIdsByRecency(
                  list.ids.filter((id) => {
                    const node = enrichedById.get(id)
                    if (!isSessionVisibleInFilter(node)) return false
                    if (hostState.hideSpacePinsInWorkspace && spacePinSet.has(id)) return false
                    return true
                  }),
                  list.byId,
                ),
            )
            : []

          // Grouped workspace items
          const accountedSet = new Set(workspaces.flatMap((ws) => ws.sessionIds ?? []))
          const ungroupedIds = list.ids.filter((id) => !accountedSet.has(id) && enrichedById.has(id))
          const parentMap = buildParentWorkspaceMap(ui.groupBy === 'workspace-tree', workspaces)

          const groupEntries = []
          if (!flatMode) {
            for (const ws of workspaces) {
              const sessions = collectMembers(ws.sessionIds)
              if (ui.archivedFilter === 'only' && sessions.length === 0) continue
              groupEntries.push({
                key: ws.workspaceId,
                workspaceId: ws.workspaceId,
                label: ws.displayTitle,
                rawTitle: ws.title,
                path: ws.path,
                sessions,
              })
            }
            const straySessions = collectMembers(ungroupedIds)
            if (straySessions.length > 0) {
              groupEntries.push({
                key: '',
                workspaceId: undefined,
                label: t('section.ungrouped'),
                rawTitle: '',
                path: undefined,
                sessions: straySessions,
              })
            }
          }

          const renderedKeys = new Set(groupEntries.map((g) => g.key))
          const childrenByParent = new Map()
          for (const g of groupEntries) {
            let parent = parentMap.get(g.key)
            while (parent !== undefined && !renderedKeys.has(parent)) {
              parent = parentMap.get(parent)
            }
            const arr = childrenByParent.get(parent) ?? []
            arr.push(g)
            childrenByParent.set(parent, arr)
          }
          const rootGroups = childrenByParent.get(undefined) ?? []

          // Collect animated rowKeys for FLIP transition
          const rowKeys = []
          if (renderTopPinSpace) {
            rowKeys.push('pinned-space:header')
            if (hostState.pinSpaceExpanded) {
              for (const n of spacePinNodes) rowKeys.push(`session:space:${n.id}`)
            }
          }
          const collectGroupRowKeys = (grp) => {
            rowKeys.push(`ws:${grp.key}`)
            if (!isGroupExpanded(grp)) return
            const childGroups = childrenByParent.get(grp.key) ?? []
            for (const child of childGroups) collectGroupRowKeys(child)
            if (grp.sessions.length === 0 && childGroups.length === 0) {
              rowKeys.push(`empty:${grp.key}`)
              return
            }
            const { visibleSessions, hiddenCount, manuallyRaised } = sliceVisible(grp)
            for (const s of visibleSessions) rowKeys.push(`session:ws:${grp.key}:${s.id}`)
            if (hiddenCount > 0 || manuallyRaised) rowKeys.push(`overflow:${grp.key}`)
          }
          if (flatMode) {
            rowKeys.push('flat:header')
            if (ui.projectsExpanded) {
              for (const n of flatNodes) rowKeys.push(`session:flat:${n.id}`)
              if (flatNodes.length === 0) rowKeys.push('empty:flat')
            }
          } else {
            rowKeys.push('projects:header')
            if (ui.projectsExpanded) {
              if (rootGroups.length === 0) {
                rowKeys.push('empty:all')
              } else {
                for (const rg of rootGroups) collectGroupRowKeys(rg)
              }
            }
          }

          const toggleProjects = () => {
            uiStore.set((c) => ({ ...c, projectsExpanded: !c.projectsExpanded }))
          }

          // Bell + search live on whichever header is visible, never twice.
          const headerActions = h('div', { className: 'dshAp_projectsHeaderActions' },
            !renderTopPinSpace && h('button', {
              type: 'button',
              className: `dshAp_iconBtn${ui.activityOpen ? ' dshAp_bellBtnActive' : ''}`,
              'aria-label': bellLabel,
              'aria-pressed': ui.activityOpen,
              onMouseEnter: (e) => showTooltip(e.currentTarget, bellLabel, 'act-toggle'),
              onMouseLeave: hideTooltip,
              onClick: () => {
                hideTooltip()
                uiStore.set((c) => ({ ...c, activityOpen: !c.activityOpen }))
              },
            },
              h(IconBell, { size: 15 }),
              activityStats.totalAttention > 0 && h('span', {
                className: `dshAp_bellBadge${activityStats.pendingCount > 0 ? ' dshAp_bellBadgeWarn' : ''}`,
              }),
            ),
            !renderTopPinSpace && h('button', {
              type: 'button',
              className: 'dshAp_iconBtn',
              'aria-label': t('search.label'),
              onMouseEnter: (e) => showTooltip(e.currentTarget, t('search.label')),
              onMouseLeave: hideTooltip,
              onClick: () => {
                hideTooltip()
                setSearchOpen(true)
                setTimeout(() => searchInputRef.current?.focus(), 20)
              },
            }, h(IconSearch, { size: 15 })),
            // `...` Options Menu (Pin display mode, group/order, archive filter)
            h('button', {
              type: 'button',
              className: 'dshAp_iconBtn',
              'aria-label': t('viewOptions.label'),
              onMouseEnter: (e) => showTooltip(e.currentTarget, t('viewOptions.label')),
              onMouseLeave: hideTooltip,
              onClick: (e) => {
                hideTooltip()
                openViewOptionsMenu(e.currentTarget)
              },
            }, h(IconDots, { size: 15 })),
            // `+` Add Workspace Button
            h('button', {
              type: 'button',
              className: 'dshAp_iconBtn',
              'aria-label': t('workspace.add'),
              onMouseEnter: (e) => showTooltip(e.currentTarget, t('workspace.add')),
              onMouseLeave: hideTooltip,
              onClick: () => {
                hideTooltip()
                triggerAddWorkspace(t)
              },
            }, h(IconPlus, { size: 15 })),
          )

          // Top 置顶 Header
          const topPinnedSection = renderTopPinSpace && h('div', {
            key: 'pinned-space',
            'data-row-key': 'pinned-space:header',
            className: 'dshAp_pinnedTopSection',
          },
            h('div', { className: 'dshAp_pinnedTopHeader' },
              h('button', {
                type: 'button',
                className: 'dshAp_pinnedTopToggleBtn',
                'aria-expanded': hostState.pinSpaceExpanded,
                onClick: () => operations.setPinConfig({ pinSpaceExpanded: !hostState.pinSpaceExpanded }),
              },
                h(IconPin, { size: 13, filled: true }),
                h('span', { className: 'dshAp_pinnedTopTitle' }, t('section.pinnedSpace')),
                spacePinNodes.length > 0 && h('span', { className: 'dshAp_subHeaderCount' }, spacePinNodes.length),
                h(IconChevron, { size: 11, expanded: hostState.pinSpaceExpanded }),
              ),
              // Top-right controls when the Pinned list sits at the top
              h('div', { className: 'dshAp_subHeaderActions' },
                h('button', {
                  type: 'button',
                  className: `dshAp_iconBtn${ui.activityOpen ? ' dshAp_bellBtnActive' : ''}`,
                  'aria-label': bellLabel,
                  'aria-pressed': ui.activityOpen,
                  onMouseEnter: (e) => showTooltip(e.currentTarget, bellLabel, 'act-toggle'),
                  onMouseLeave: hideTooltip,
                  onClick: () => {
                    hideTooltip()
                    uiStore.set((c) => ({ ...c, activityOpen: !c.activityOpen }))
                  },
                },
                  h(IconBell, { size: 15, filled: ui.activityOpen }),
                  activityStats.totalAttention > 0 && h('span', {
                    className: `dshAp_bellBadge${activityStats.pendingCount > 0 ? ' dshAp_bellBadgeWarn' : ''}`,
                  }),
                ),
                h('button', {
                  type: 'button',
                  className: 'dshAp_iconBtn',
                  'aria-label': t('search.label'),
                  onMouseEnter: (e) => showTooltip(e.currentTarget, t('search.label')),
                  onMouseLeave: hideTooltip,
                  onClick: () => {
                    hideTooltip()
                    setSearchOpen(true)
                    setTimeout(() => searchInputRef.current?.focus(), 20)
                  },
                }, h(IconSearch, { size: 15 })),
                h('button', {
                  type: 'button',
                  className: 'dshAp_iconBtn',
                  'aria-label': t('pinSpace.options'),
                  onMouseEnter: (e) => showTooltip(e.currentTarget, t('pinSpace.options')),
                  onMouseLeave: hideTooltip,
                  onClick: (e) => {
                    hideTooltip()
                    openPinSpaceOptionsMenu(e.currentTarget)
                  },
                }, h(IconDots, { size: 14 })),
              ),
            ),
            hostState.pinSpaceExpanded && (
              spacePinNodes.length === 0
                ? h('div', { className: 'dshAp_emptyHint' }, t('pinSpace.empty'))
                : spacePinNodes.map((node) => renderSessionRow(node, {
                  contextKey: 'space',
                  indented: false,
                  showWorkspaceBadge: true,
                  orderedIds: spacePinNodes.map((n) => n.id),
                  onReorder: (nextIds) => operations.reorderSpacePins(nextIds),
                }))
            ),
          )

          // Projects header: `项目 ⌄               ... +`
          const projectsHeader = h('div', {
            key: 'projects:header',
            'data-row-key': 'projects:header',
            className: 'dshAp_projectsHeader',
          },
            h('button', {
              type: 'button',
              className: 'dshAp_projectsToggleBtn',
              'aria-expanded': ui.projectsExpanded,
              onClick: toggleProjects,
            },
              h('span', null, t('section.projects')),
              h(IconChevron, { size: 11, expanded: ui.projectsExpanded }),
            ),
            headerActions,
          )

          // Single-list header: `会话 ... +`
          const flatHeader = h('div', {
            key: 'flat:header',
            'data-row-key': 'flat:header',
            className: 'dshAp_projectsHeader',
          },
            h('button', {
              type: 'button',
              className: 'dshAp_projectsToggleBtn',
              'aria-expanded': ui.projectsExpanded,
              onClick: toggleProjects,
            },
              h('span', null, t('section.sessions')),
              h(IconChevron, { size: 11, expanded: ui.projectsExpanded }),
            ),
            headerActions,
          )

          const emptyAllBlock = h('div', { key: 'empty:all', 'data-row-key': 'empty:all', className: 'dshAp_emptyBlock' },
            h('div', null, t(ui.archivedFilter === 'only' ? 'empty.noneArchived' : 'empty.none')),
            ui.archivedFilter === 'only' && h('button', {
              type: 'button',
              className: 'dshAp_linkBtn',
              onClick: () => uiStore.set((c) => ({ ...c, archivedFilter: 'default' })),
            }, t('empty.viewOthers')),
          )

          const renderFlatBody = () => {
            if (flatNodes.length === 0) {
              return h('div', { key: 'empty:flat', 'data-row-key': 'empty:flat', className: 'dshAp_emptyBlock' },
                h('div', null, t(ui.archivedFilter === 'only' ? 'empty.noneArchived' : 'empty.none')),
                ui.archivedFilter === 'only' && h('button', {
                  type: 'button',
                  className: 'dshAp_linkBtn',
                  onClick: () => uiStore.set((c) => ({ ...c, archivedFilter: 'default' })),
                }, t('empty.viewOthers')),
              )
            }
            const flatIds = flatNodes.map((n) => n.id)
            return flatNodes.map((node) => renderSessionRow(node, {
              contextKey: 'flat',
              indented: false,
              showWorkspaceBadge: true,
              orderedIds: flatIds,
              onReorder: (nextIds) => {
                uiStore.set((c) => ({
                  ...c,
                  orderBy: 'manual',
                  sessionOrderByAccount: { ...c.sessionOrderByAccount, [FLAT_ORDER_KEY]: nextIds },
                }))
              },
            }))
          }

          const renderWorkspaceGroup = (grp, depth) => {
            const expanded = isGroupExpanded(grp)
            const childGroups = childrenByParent.get(grp.key) ?? []
            const { wm, visibleSessions, hiddenCount, manuallyRaised } = sliceVisible(grp)

            const wsMenuId = `ws-menu:${grp.key}`
            const wsMenuOpen = activePopoverId === wsMenuId
            const wsDropMarker = grp.workspaceId !== undefined && dragWorkspace?.overId === grp.workspaceId
              ? dragWorkspace.half
              : null

            return h('div', {
              key: `ws:${grp.key}`,
              'data-row-key': `ws:${grp.key}`,
              className: [
                'dshAp_wsGroup',
                wsDropMarker === 'before' ? 'dshAp_dropBefore' : '',
                wsDropMarker === 'after' ? 'dshAp_dropAfter' : '',
              ].filter(Boolean).join(' '),
              style: { '--dsh-ws-indent': `${depth * 12}px` },
            },
              h('div', {
                className: `dshAp_wsRow${wsMenuOpen ? ' dshAp_wsRowMenuOpen' : ''}`,
                role: 'treeitem',
                'aria-expanded': expanded,
                draggable: grp.workspaceId !== undefined,
                onDragStart: grp.workspaceId === undefined ? undefined : (e) => {
                  e.dataTransfer.effectAllowed = 'move'
                  e.dataTransfer.setData('text/plain', grp.workspaceId)
                  setDragWorkspace({ workspaceId: grp.workspaceId, overId: null, half: null })
                },
                onDragOver: (dragWorkspace === null || grp.workspaceId === undefined) ? undefined : (e) => {
                  if (dragWorkspace.workspaceId === grp.workspaceId) return
                  e.preventDefault()
                  const rect = e.currentTarget.getBoundingClientRect()
                  const half = e.clientY < rect.top + rect.height / 2 ? 'before' : 'after'
                  setDragWorkspace((cur) => (cur ? { ...cur, overId: grp.workspaceId, half } : null))
                },
                onDrop: (dragWorkspace === null || grp.workspaceId === undefined) ? undefined : (e) => {
                  e.preventDefault()
                  const srcId = dragWorkspace?.workspaceId
                  setDragWorkspace(null)
                  if (!srcId || srcId === grp.workspaceId) return
                  const rect = e.currentTarget.getBoundingClientRect()
                  const half = e.clientY < rect.top + rect.height / 2 ? 'before' : 'after'
                  const siblings = workspaces.map((w) => w.workspaceId)
                  const targetIdx = siblings.indexOf(grp.workspaceId)
                  if (targetIdx === -1) return
                  const anchor = half === 'before' ? grp.workspaceId : siblings[targetIdx + 1]
                  if (anchor !== srcId && typeof ctx.workspaces.insertBefore === 'function') {
                    ctx.workspaces.insertBefore(srcId, anchor).catch(() => {})
                  }
                },
                onDragEnd: grp.workspaceId === undefined ? undefined : () => setDragWorkspace(null),
                onClick: () => {
                  const nextExpansion = { ...ui.groupExpansion, [grp.key]: !expanded }
                  uiStore.set((c) => ({ ...c, groupExpansion: nextExpansion }))
                  writeNativeGroupExpansion(nextExpansion)
                },
              },
                h('span', { className: `dshAp_wsIconWrap dshAp_wsFolder${grp.workspaceId === owningWsId ? ' dshAp_wsIconActive' : ''}` },
                  h(IconFolder, { size: 15, open: expanded }),
                ),
                h('span', { className: 'dshAp_wsIconWrap dshAp_wsChevron' },
                  h(IconChevron, { size: 12, expanded }),
                ),
                h('span', { className: 'dshAp_wsTitle', title: grp.path || grp.label }, grp.label),
                grp.workspaceId !== undefined && h('span', {
                  className: 'dshAp_wsHoverActions',
                  onClick: (e) => e.stopPropagation(),
                },
                  h('button', {
                    type: 'button',
                    className: 'dshAp_miniBtn',
                    'aria-label': t('workspace.actions'),
                    onClick: (e) => {
                      e.stopPropagation()
                      openPopover(wsMenuId, e.currentTarget, (dismiss) => h(Fragment, null,
                        h('button', {
                          type: 'button',
                          role: 'menuitem',
                          className: 'dshAp_menuItem',
                          onClick: () => {
                            dismiss()
                            overlayStore.set((c) => ({
                              ...c,
                              modal: {
                                kind: 'rename-ws',
                                workspaceId: grp.workspaceId,
                                initialTitle: grp.label,
                                existingTitles: workspaces.map((w) => ({ workspaceId: w.workspaceId, title: w.displayTitle })),
                              },
                            }))
                          },
                        },
                          h('span', { className: 'dshAp_menuItemIcon' }, h(IconEdit, {})),
                          h('span', { className: 'dshAp_menuItemText' }, t('workspace.rename')),
                        ),
                        h('button', {
                          type: 'button',
                          role: 'menuitem',
                          className: 'dshAp_menuItem dshAp_menuItemDanger',
                          onClick: () => {
                            dismiss()
                            overlayStore.set((c) => ({
                              ...c,
                              modal: {
                                kind: 'delete-ws',
                                workspaceId: grp.workspaceId,
                                title: grp.label,
                              },
                            }))
                          },
                        },
                          h('span', { className: 'dshAp_menuItemIcon' }, h(IconTrash, {})),
                          h('span', { className: 'dshAp_menuItemText' }, t('workspace.delete')),
                        ),
                      ), 'end', 184)
                    },
                  }, h(IconDots, { size: 14 })),
                  h('button', {
                    type: 'button',
                    className: 'dshAp_miniBtn',
                    'aria-label': t('workspace.newSession'),
                    onMouseEnter: (e) => showTooltip(e.currentTarget, t('workspace.newSession')),
                    onMouseLeave: hideTooltip,
                    onClick: (e) => {
                      e.stopPropagation()
                      hideTooltip()
                      const nextExpansion = { ...ui.groupExpansion, [grp.key]: true }
                      uiStore.set((c) => ({ ...c, groupExpansion: nextExpansion }))
                      writeNativeGroupExpansion(nextExpansion)
                      ctx.uiWorkspace.startSession(grp.workspaceId)
                    },
                  }, h(IconPlus, { size: 14.5 })),
                ),
              ),

              expanded && childGroups.map((child) => renderWorkspaceGroup(child, depth + 1)),

              expanded && (
                grp.sessions.length === 0 && childGroups.length === 0
                  ? h('div', { key: `empty:${grp.key}`, 'data-row-key': `empty:${grp.key}`, className: 'dshAp_emptyHint' }, t('empty.workspace'))
                  : visibleSessions.map((node) => renderSessionRow(node, {
                    contextKey: `ws:${grp.key}`,
                    indented: true,
                    showWorkspaceBadge: false,
                    orderedIds: grp.sessions.map((s) => s.id),
                    onReorder: (nextIds) => {
                      uiStore.set((c) => ({
                        ...c,
                        orderBy: 'manual',
                        sessionOrderByAccount: { ...c.sessionOrderByAccount, [grp.key]: nextIds },
                      }))
                    },
                  }))
              ),

              expanded && (hiddenCount > 0 || manuallyRaised) && h('button', {
                type: 'button',
                key: `overflow:${grp.key}`,
                'data-row-key': `overflow:${grp.key}`,
                className: 'dshAp_overflowBtn',
                onClick: () => {
                  if (hiddenCount === 0 && manuallyRaised) {
                    setWatermarks((m) => {
                      const next = { ...m }
                      delete next[grp.key]
                      return next
                    })
                  } else {
                    setWatermarks((m) => ({
                      ...m,
                      [grp.key]: hiddenCount <= SESSION_WATERMARK_BASE ? Number.MAX_SAFE_INTEGER : wm + SESSION_WATERMARK_BASE,
                    }))
                  }
                },
              }, hiddenCount > 0 ? t('sessions.expandCount', { n: hiddenCount }) : t('sessions.collapse')),
            )
          }

          return h(AnimatedRows, {
            key: 'normal',
            className: 'dshAp_treeContainer dshAp_viewFadeIn',
            label: t('section.projects'),
            ready: list?.phase !== 'loading',
            rowKeys,
            resetKey: `normal/${ui.groupBy}/${ui.orderBy}/${ui.archivedFilter}`,
          },
            topPinnedSection,
            flatMode ? flatHeader : projectsHeader,
            ui.projectsExpanded && (
              flatMode
                ? renderFlatBody()
                : (rootGroups.length === 0
                  ? emptyAllBlock
                  : rootGroups.map((grp) => renderWorkspaceGroup(grp, 0)))
            ),
          )
        }

        const renderSearchView = () => {
          const q = trimmedQuery.toLowerCase()
          const isVisible = (n) => {
            if (!n || n.blank) return false
            if (ui.archivedFilter === 'default') return !n.archived
            if (ui.archivedFilter === 'only') return n.archived
            return true
          }

          const snippetById = new Map()
          for (const hit of remoteSearch.items ?? []) {
            if (!snippetById.has(hit.sessionId)) snippetById.set(hit.sessionId, hit.snippet)
          }

          const matched = []
          const seen = new Set()
          const allByRecency = [...enrichedById.values()]
            .filter(isVisible)
            .sort((a, b) => b.updatedAt - a.updatedAt)

          for (const node of allByRecency) {
            if (node.title.toLowerCase().includes(q) || node.workspaceLabel.toLowerCase().includes(q)) {
              seen.add(node.id)
              matched.push(node)
            }
          }
          for (const hit of remoteSearch.items ?? []) {
            const node = enrichedById.get(hit.sessionId)
            if (node && isVisible(node) && !seen.has(node.id)) {
              seen.add(node.id)
              matched.push(node)
            }
          }

          const limit = ctx.sessions.searchResultLimit || 50
          const shown = matched.slice(0, limit)
          const pending = remoteSearch.status === 'loading'
          const rowKeys = shown.map((n) => `search:${n.id}`)
          if (shown.length === 0) rowKeys.push(pending ? 'search:pending' : 'search:none')
          if (remoteSearch.hasMore || matched.length > limit) rowKeys.push('search:more')

          return h(AnimatedRows, {
            key: 'search',
            className: 'dshAp_treeContainer dshAp_viewFadeIn',
            label: t('search.label'),
            ready: list?.phase !== 'loading',
            rowKeys,
            resetKey: 'search',
          },
            shown.map((node) => {
              const selected = node.id === selectedSessionId
              const snippet = snippetById.get(node.id) || node.snippet
              return h('div', {
                key: `search:${node.id}`,
                'data-row-key': `search:${node.id}`,
                className: `dshAp_actRow${selected ? ' dshAp_actRowSelected' : ''}`,
                role: 'treeitem',
                tabIndex: 0,
                'aria-selected': selected,
                onClick: () => handleOpenSession(node.id),
                onKeyDown: (e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault()
                    handleOpenSession(node.id)
                  }
                },
              },
                h('div', { className: 'dshAp_actTopLine' },
                  node.unread && !node.activeRun && h('span', { className: 'dshAp_dot dshAp_dotUnread' }),
                  h('span', { className: 'dshAp_actTitle' }, node.title),
                  h('span', { className: 'dshAp_actWsName' }, node.workspaceLabel),
                  node.activeRun && h(IconSpinner, { size: 13, accent: true }),
                  node.archived && h('button', {
                    type: 'button',
                    className: 'dshAp_linkBtn',
                    onClick: (e) => {
                      e.stopPropagation()
                      ctx.uiWorkspace.unarchiveSession(node.id)
                    },
                  }, t('session.unarchive')),
                ),
                snippet && h('div', { className: 'dshAp_actSnippet' }, snippet),
              )
            }),
            pending && shown.length === 0 && h('div', { key: 'search:pending', 'data-row-key': 'search:pending', className: 'dshAp_emptyBlock' }, t('search.pending')),
            !pending && shown.length === 0 && h('div', { key: 'search:none', 'data-row-key': 'search:none', className: 'dshAp_emptyBlock' }, t('search.noMatches')),
            (remoteSearch.hasMore || matched.length > limit) && h('div', { key: 'search:more', 'data-row-key': 'search:more', className: 'dshAp_emptyHint' },
              t('search.hasMore', { n: limit }),
            ),
          )
        }

        return h('div', { className: 'dshAp_root dshAp_rootWide' },
          // Top Search Bar (when search is open)
          searchOpen && h('div', { className: 'dshAp_header' },
            h('div', { className: 'dshAp_searchBar' },
              h(IconSearch, { size: 13.5 }),
              h('input', {
                ref: searchInputRef,
                className: 'dshAp_searchInput',
                type: 'text',
                value: query,
                placeholder: t('search.placeholder'),
                onChange: (e) => setQuery(e.target.value),
                onKeyDown: (e) => {
                  if (e.key === 'Escape') {
                    setQuery('')
                    setSearchOpen(false)
                  }
                },
              }),
              h('button', {
                type: 'button',
                className: 'dshAp_searchClear',
                'aria-label': t('search.clear'),
                onClick: () => {
                  setQuery('')
                  setSearchOpen(false)
                },
              }, h(IconClose, { size: 11 })),
            ),
          ),

          // Activity View Header (when in Activity View and search is closed)
          !searchOpen && ui.activityOpen && h('div', { className: 'dshAp_header dshAp_actHeader' },
            h('button', {
              type: 'button',
              className: 'dshAp_iconBtn',
              'aria-label': t('activity.backToWorkspaces'),
              onMouseEnter: (e) => showTooltip(e.currentTarget, t('activity.backToWorkspaces')),
              onMouseLeave: hideTooltip,
              onClick: () => {
                hideTooltip()
                uiStore.set((c) => ({ ...c, activityOpen: false }))
              },
            }, h(IconArrowLeft, { size: 14 })),
            h('span', { className: 'dshAp_headerTitle' },
              t('section.activity'),
              activityStats.totalAttention > 0 && h('span', { className: 'dshAp_subHeaderCount' }, activityStats.totalAttention),
            ),
            h('div', { className: 'dshAp_headerActions' },
              h('button', {
                type: 'button',
                className: 'dshAp_iconBtn dshAp_bellBtnActive',
                'aria-label': t('activity.close'),
                onMouseEnter: (e) => showTooltip(e.currentTarget, t('activity.close'), 'act-toggle'),
                onMouseLeave: hideTooltip,
                onClick: () => {
                  hideTooltip()
                  uiStore.set((c) => ({ ...c, activityOpen: false }))
                },
              },
                h(IconBell, { size: 15, filled: true }),
                activityStats.totalAttention > 0 && h('span', {
                  className: `dshAp_bellBadge${activityStats.pendingCount > 0 ? ' dshAp_bellBadgeWarn' : ''}`,
                }),
              ),
              h('button', {
                type: 'button',
                className: 'dshAp_iconBtn',
                'aria-label': t('search.label'),
                onMouseEnter: (e) => showTooltip(e.currentTarget, t('search.label')),
                onMouseLeave: hideTooltip,
                onClick: () => {
                  hideTooltip()
                  setSearchOpen(true)
                  setTimeout(() => searchInputRef.current?.focus(), 20)
                },
              }, h(IconSearch, { size: 15 })),
              h('button', {
                type: 'button',
                className: 'dshAp_iconBtn',
                'aria-label': t('activity.menu.show'),
                onMouseEnter: (e) => showTooltip(e.currentTarget, t('activity.menu.show')),
                onMouseLeave: hideTooltip,
                onClick: (e) => {
                  hideTooltip()
                  openActivityOptionsMenu(e.currentTarget)
                },
              }, h(IconDots, { size: 14 })),
            ),
          ),

          // Main Scrollable Area with FLIP AnimatedRows
          h('div', { className: 'dshAp_scrollArea' },
            trimmedQuery !== ''
              ? renderSearchView()
              : ui.activityOpen
                ? renderActivityView()
                : renderNormalView(),
          ),
        )
      }

      function buildParentWorkspaceMap(enabled, workspaces) {
        if (!enabled) return new Map()
        const byPath = new Map(workspaces.map((w) => [w.path, w.workspaceId]))
        const allPaths = [...byPath.keys()]
        const out = new Map()
        for (const ws of workspaces) {
          const parentPath = findParentWorkspacePath(ws.path, allPaths)
          out.set(ws.workspaceId, parentPath ? byPath.get(parentPath) : undefined)
        }
        return out
      }

      // -----------------------------------------------------------------------
      // Slot Registrations (shell.overlay + sidebar.workspaces at priority -10)
      // -----------------------------------------------------------------------
      ctx.slots.inject('shell.overlay', () => ctx.slots.register({
        name: 'shell.overlay',
        id: 'dsh-session-sidebar.overlay',
        order: 55,
        locale: LOCALE_NS,
      }, SessionSidebarOverlay))

      ctx.slots.inject('sidebar.workspaces', () => ctx.slots.register({
        name: 'sidebar.workspaces',
        priority: -10,
        locale: LOCALE_NS,
      }, CodexWorkspaceSidebar))
    }

    return { name: PLUGIN_ID, inject, apply }
  },
})
