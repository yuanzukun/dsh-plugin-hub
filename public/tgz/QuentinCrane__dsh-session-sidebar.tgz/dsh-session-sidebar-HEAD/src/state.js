/**
 * dsh-session-sidebar — Pure state schemas, session projection fold, and reducers.
 *
 * Kept free of Cordis, DOM, and network dependencies so every rule is
 * deterministic and unit-testable in plain Node.
 */

export const PROJECTION_KEY = 'dshSessionSidebar'
export const DOMAIN_NAME = 'dsh-session-sidebar'
export const API_ROUTE = '/dsh-session-sidebar/api'
export const TOOL_NAME = 'activity_pins'

export const PIN_MODES = ['hybrid', 'space', 'workspace']
export const PIN_TARGETS = ['space', 'workspace']

/**
 * Convert raw message content blocks into a clean, single-paragraph snippet
 * suitable for Codex-style 2-line activity previews.
 */
export function extractMessageSnippet(content, maxChars = 180) {
  let parts = []
  if (typeof content === 'string') {
    parts = [content]
  } else if (Array.isArray(content)) {
    for (const block of content) {
      if (typeof block === 'string') {
        parts.push(block)
      } else if (block !== null && typeof block === 'object' && block.type === 'text' && typeof block.text === 'string') {
        parts.push(block.text)
      }
    }
  }
  if (parts.length === 0) return ''
  let text = parts.join(' ')
  // Strip fenced code blocks into inline placeholders or inner text
  text = text.replace(/```[\w-]*\n?([\s\S]*?)```/g, (_m, code) => {
    const firstLine = String(code ?? '').trim().split('\n')[0] ?? ''
    return firstLine ? ` ${firstLine} ` : ' '
  })
  // Strip markdown images and keep link labels
  text = text.replace(/!\[([^\]]*)\]\([^)]*\)/g, '$1')
  text = text.replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
  // Strip headings, blockquotes, list bullets, and inline formatting tokens
  text = text.replace(/(^|\s)#{1,6}\s+/g, ' ')
  text = text.replace(/[*_~`]+/g, '')
  text = text.replace(/\s+/g, ' ').trim()
  if (text.length <= maxChars) return text
  return `${text.slice(0, maxChars).trimEnd()}…`
}

export function initProjectionState() {
  return {
    lastAssistantSnippet: '',
    lastAssistantAt: 0,
    lastUserAt: 0,
    lastTurnStartAt: 0,
    lastTurnEndAt: 0,
    lastTurnReason: '',
    turnCount: 0,
  }
}

/**
 * Pure synchronous projection fold for `ctx.sessionProjections`.
 * Returns the exact `state` reference when an event does not change tracked fields.
 */
export function foldSessionActivity(state, event) {
  if (!event || typeof event !== 'object' || event.ignorable === true) return state
  const time = typeof event.time === 'number' && Number.isFinite(event.time) ? event.time : 0

  switch (event.type) {
    case 'user/message': {
      const nextUserAt = Math.max(state.lastUserAt, time)
      if (nextUserAt === state.lastUserAt) return state
      return {
        ...state,
        lastUserAt: nextUserAt,
      }
    }
    case 'assistant/message': {
      const message = event.data?.message
      const content = message?.content ?? message?.text ?? event.data?.text
      const snippet = extractMessageSnippet(content)
      const nextAssistantAt = Math.max(state.lastAssistantAt, time)
      const nextSnippet = snippet !== '' ? snippet : state.lastAssistantSnippet
      if (nextSnippet === state.lastAssistantSnippet && nextAssistantAt === state.lastAssistantAt) {
        return state
      }
      return {
        ...state,
        lastAssistantSnippet: nextSnippet,
        lastAssistantAt: nextAssistantAt,
      }
    }
    case 'turn/start': {
      const nextStartAt = Math.max(state.lastTurnStartAt, time)
      if (nextStartAt === state.lastTurnStartAt) return state
      return {
        ...state,
        lastTurnStartAt: nextStartAt,
      }
    }
    case 'turn/end': {
      const reasonKind = typeof event.data?.reason?.kind === 'string' ? event.data.reason.kind : 'completed'
      const nextEndAt = Math.max(state.lastTurnEndAt, time)
      return {
        ...state,
        lastTurnEndAt: nextEndAt,
        lastTurnReason: reasonKind,
        turnCount: (state.turnCount || 0) + 1,
      }
    }
    default:
      return state
  }
}

function makeSchema(parseFn, rejectNull = false) {
  return {
    parse(value) {
      if (rejectNull && (value === null || typeof value !== 'object' || Array.isArray(value))) {
        throw new TypeError('Expected a non-null plain object')
      }
      return parseFn(value)
    },
    safeParse(value) {
      try {
        return { success: true, data: this.parse(value) }
      } catch (error) {
        return { success: false, error }
      }
    },
  }
}

export const SessionSidebarProjectionSchema = makeSchema((value) => {
  const raw = value !== null && typeof value === 'object' ? value : {}
  const num = (v) => {
    const n = Number(v)
    return Number.isFinite(n) && n >= 0 ? n : 0
  }
  return {
    lastAssistantSnippet: typeof raw.lastAssistantSnippet === 'string' ? raw.lastAssistantSnippet : '',
    lastAssistantAt: num(raw.lastAssistantAt),
    lastUserAt: num(raw.lastUserAt),
    lastTurnStartAt: num(raw.lastTurnStartAt),
    lastTurnEndAt: num(raw.lastTurnEndAt),
    lastTurnReason: typeof raw.lastTurnReason === 'string' ? raw.lastTurnReason : '',
    turnCount: Math.floor(num(raw.turnCount)),
  }
})

export function createInitialGlobalState(now = Date.now()) {
  return {
    revision: 1,
    baselineAt: now,
    pinMode: 'hybrid',
    defaultPinTarget: 'space',
    hideSpacePinsInWorkspace: true,
    alwaysShowPinSpace: true,
    pinSpaceExpanded: true,
    pinScopes: {},
    spaceOrder: [],
    readAt: {},
    forceUnread: {},
    activityPrefs: {
      showPrioritySection: true,
      includePinnedInPriority: false,
      includeScheduledInPriority: false,
      unreadOnly: false,
    },
  }
}

export const SessionSidebarGlobalStateSchema = makeSchema((raw) => {
  const revision = Number(raw.revision)
  const baselineAt = Number(raw.baselineAt)
  const pinScopes = {}
  if (raw.pinScopes !== null && typeof raw.pinScopes === 'object' && !Array.isArray(raw.pinScopes)) {
    for (const [k, v] of Object.entries(raw.pinScopes)) {
      if (typeof k === 'string' && k !== '' && PIN_TARGETS.includes(v)) {
        pinScopes[k] = v
      }
    }
  }
  const spaceOrder = Array.isArray(raw.spaceOrder)
    ? [...new Set(raw.spaceOrder.filter((id) => typeof id === 'string' && id !== ''))]
    : []

  const readAt = {}
  if (raw.readAt !== null && typeof raw.readAt === 'object' && !Array.isArray(raw.readAt)) {
    for (const [k, v] of Object.entries(raw.readAt)) {
      const ts = Number(v)
      if (typeof k === 'string' && k !== '' && Number.isFinite(ts) && ts > 0) {
        readAt[k] = ts
      }
    }
  }

  const forceUnread = {}
  if (raw.forceUnread !== null && typeof raw.forceUnread === 'object' && !Array.isArray(raw.forceUnread)) {
    for (const [k, v] of Object.entries(raw.forceUnread)) {
      if (typeof k === 'string' && k !== '' && v === true) {
        forceUnread[k] = true
      }
    }
  }

  const prefs = raw.activityPrefs !== null && typeof raw.activityPrefs === 'object' ? raw.activityPrefs : {}

  return {
    revision: Number.isInteger(revision) && revision >= 1 ? revision : 1,
    baselineAt: Number.isFinite(baselineAt) && baselineAt > 0 ? baselineAt : Date.now(),
    pinMode: PIN_MODES.includes(raw.pinMode) ? raw.pinMode : 'hybrid',
    defaultPinTarget: PIN_TARGETS.includes(raw.defaultPinTarget) ? raw.defaultPinTarget : 'space',
    hideSpacePinsInWorkspace: raw.hideSpacePinsInWorkspace !== false,
    alwaysShowPinSpace: raw.alwaysShowPinSpace !== false,
    pinSpaceExpanded: raw.pinSpaceExpanded !== false,
    pinScopes,
    spaceOrder,
    readAt,
    forceUnread,
    activityPrefs: {
      showPrioritySection: prefs.showPrioritySection !== false,
      includePinnedInPriority: prefs.includePinnedInPriority === true,
      includeScheduledInPriority: prefs.includeScheduledInPriority === true,
      unreadOnly: prefs.unreadOnly === true,
    },
  }
}, true)

/**
 * Determine where a pinned session renders:
 * - `'space'`: inside the standalone top-level 《置顶》 space (with source workspace badge)
 * - `'workspace'`: pinned at the top of its own workspace folder
 * - `null`: not pinned
 */
export function resolveEffectivePinScope(sessionId, isHostPinned, state) {
  if (!isHostPinned) return null
  if (state.pinMode === 'space') return 'space'
  if (state.pinMode === 'workspace') return 'workspace'
  const explicit = state.pinScopes?.[sessionId]
  if (PIN_TARGETS.includes(explicit)) return explicit
  return PIN_TARGETS.includes(state.defaultPinTarget) ? state.defaultPinTarget : 'space'
}

/**
 * Determine whether a session has unviewed completed activity or explicit unread flag.
 */
export function computeSessionUnread(info, state) {
  const {
    sessionId,
    running = false,
    completionUnread = false,
    lastTurnEndAt = 0,
    updatedAt = 0,
    isMain = false,
  } = info

  if (running) return false
  if (state.forceUnread?.[sessionId] === true) return true
  if (isMain) return false

  const seenAt = state.readAt?.[sessionId] ?? state.baselineAt ?? 0
  if (completionUnread && (state.readAt?.[sessionId] ?? 0) < Math.max(lastTurnEndAt, updatedAt)) {
    return true
  }
  if (lastTurnEndAt > seenAt) {
    return true
  }
  return false
}

export function reducePinSession(state, sessionId, target) {
  const resolvedTarget = PIN_TARGETS.includes(target)
    ? target
    : (PIN_TARGETS.includes(state.defaultPinTarget) ? state.defaultPinTarget : 'space')
  const nextScopes = { ...state.pinScopes, [sessionId]: resolvedTarget }
  const nextSpaceOrder = resolvedTarget === 'space'
    ? [sessionId, ...state.spaceOrder.filter((id) => id !== sessionId)]
    : state.spaceOrder.filter((id) => id !== sessionId)
  return {
    ...state,
    revision: state.revision + 1,
    pinScopes: nextScopes,
    spaceOrder: nextSpaceOrder,
  }
}

export function reduceUnpinSession(state, sessionId) {
  const nextScopes = { ...state.pinScopes }
  delete nextScopes[sessionId]
  return {
    ...state,
    revision: state.revision + 1,
    pinScopes: nextScopes,
    spaceOrder: state.spaceOrder.filter((id) => id !== sessionId),
  }
}

export function reduceReorderSpacePins(state, sessionIds) {
  const clean = Array.isArray(sessionIds)
    ? [...new Set(sessionIds.filter((id) => typeof id === 'string' && id !== ''))]
    : state.spaceOrder
  return {
    ...state,
    revision: state.revision + 1,
    spaceOrder: clean,
  }
}

export function reduceSetPinConfig(state, patch) {
  return {
    ...state,
    revision: state.revision + 1,
    pinMode: PIN_MODES.includes(patch?.pinMode) ? patch.pinMode : state.pinMode,
    defaultPinTarget: PIN_TARGETS.includes(patch?.defaultPinTarget) ? patch.defaultPinTarget : state.defaultPinTarget,
    hideSpacePinsInWorkspace: typeof patch?.hideSpacePinsInWorkspace === 'boolean'
      ? patch.hideSpacePinsInWorkspace
      : state.hideSpacePinsInWorkspace,
    alwaysShowPinSpace: typeof patch?.alwaysShowPinSpace === 'boolean'
      ? patch.alwaysShowPinSpace
      : state.alwaysShowPinSpace,
    pinSpaceExpanded: typeof patch?.pinSpaceExpanded === 'boolean'
      ? patch.pinSpaceExpanded
      : state.pinSpaceExpanded,
  }
}

export function reduceMarkRead(state, sessionId, timestamp = Date.now()) {
  const prevRead = state.readAt?.[sessionId] ?? 0
  const hadForce = state.forceUnread?.[sessionId] === true
  const nextTs = Math.max(prevRead, timestamp)
  if (!hadForce && nextTs === prevRead) return state
  const nextForce = { ...state.forceUnread }
  delete nextForce[sessionId]
  return {
    ...state,
    revision: state.revision + 1,
    readAt: { ...state.readAt, [sessionId]: nextTs },
    forceUnread: nextForce,
  }
}

export function reduceMarkUnread(state, sessionId) {
  if (state.forceUnread?.[sessionId] === true) return state
  return {
    ...state,
    revision: state.revision + 1,
    forceUnread: { ...state.forceUnread, [sessionId]: true },
  }
}

export function reduceMarkAllRead(state, sessionIds, timestamp = Date.now()) {
  const ids = Array.isArray(sessionIds) ? sessionIds.filter((id) => typeof id === 'string' && id !== '') : []
  const nextRead = { ...state.readAt }
  for (const id of ids) {
    nextRead[id] = Math.max(nextRead[id] ?? 0, timestamp)
  }
  return {
    ...state,
    revision: state.revision + 1,
    baselineAt: Math.max(state.baselineAt, timestamp),
    readAt: nextRead,
    forceUnread: {},
  }
}

export function reduceSetActivityPrefs(state, patch) {
  const cur = state.activityPrefs
  return {
    ...state,
    revision: state.revision + 1,
    activityPrefs: {
      showPrioritySection: typeof patch?.showPrioritySection === 'boolean' ? patch.showPrioritySection : cur.showPrioritySection,
      includePinnedInPriority: typeof patch?.includePinnedInPriority === 'boolean' ? patch.includePinnedInPriority : cur.includePinnedInPriority,
      includeScheduledInPriority: typeof patch?.includeScheduledInPriority === 'boolean' ? patch.includeScheduledInPriority : cur.includeScheduledInPriority,
      unreadOnly: typeof patch?.unreadOnly === 'boolean' ? patch.unreadOnly : cur.unreadOnly,
    },
  }
}
