/**
 * Render smoke tests for the browser bundle.
 *
 * The client plugin is a self-registering window script, so this harness wires
 * the minimum DSH surface it touches (slot registry, stores, workspace/session
 * controllers) and mounts the real `sidebar.workspaces` component in linkedom.
 * Each test re-evaluates the bundle so module-level stores start clean.
 *
 * Labels come from the plugin's own `zh` dictionary, read out of client.js, so
 * copy changes never desynchronise the assertions.
 */
import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { createRequire } from 'node:module'
import { parseHTML } from 'linkedom'

const require = createRequire(import.meta.url)
const React = require('react')
const { createRoot } = require('react-dom/client')
const { act } = React

// ---------------------------------------------------------------------------
// DOM bootstrap (must exist before client.js evaluates)
// ---------------------------------------------------------------------------
// linkedom loads in milliseconds where jsdom costs ~30s on this machine, and it
// covers the DOM surface these assertions touch.
const { document, window } = parseHTML('<!doctype html><html><body></body></html>')
globalThis.window = window
globalThis.document = document
Object.defineProperty(globalThis, 'navigator', { value: window.navigator, configurable: true, writable: true })
globalThis.HTMLElement = window.HTMLElement
globalThis.Node = window.Node
globalThis.Event = window.Event
globalThis.IS_REACT_ACT_ENVIRONMENT = true

// The bundle reaches for browser APIs linkedom does not implement.
const storage = new Map()
window.localStorage = {
  getItem: (key) => (storage.has(key) ? storage.get(key) : null),
  setItem: (key, value) => { storage.set(key, String(value)) },
  removeItem: (key) => { storage.delete(key) },
  clear: () => { storage.clear() },
}
Object.defineProperty(globalThis, 'localStorage', { value: window.localStorage, configurable: true, writable: true })

// Node's timer functions, captured before the window facade wraps them.
const nativeSetTimeout = globalThis.setTimeout.bind(globalThis)
const nativeClearTimeout = globalThis.clearTimeout.bind(globalThis)
const nativeSetInterval = globalThis.setInterval.bind(globalThis)
const nativeClearInterval = globalThis.clearInterval.bind(globalThis)

// Rows hold a 60s clock interval; track every interval the bundle creates so the
// file can release them and the runner exits right after the assertions.
const liveIntervals = new Set()
window.setTimeout = (fn, ms, ...rest) => nativeSetTimeout(fn, ms, ...rest)
window.clearTimeout = (id) => nativeClearTimeout(id)
window.setInterval = (fn, ms, ...rest) => {
  const id = nativeSetInterval(fn, ms, ...rest)
  liveIntervals.add(id)
  return id
}
window.clearInterval = (id) => {
  liveIntervals.delete(id)
  nativeClearInterval(id)
}
window.requestAnimationFrame = (cb) => nativeSetTimeout(() => cb(Date.now()), 16)
window.cancelAnimationFrame = (id) => nativeClearTimeout(id)
globalThis.requestAnimationFrame = window.requestAnimationFrame
globalThis.cancelAnimationFrame = window.cancelAnimationFrame
window.matchMedia = () => ({
  matches: false,
  addListener() {},
  removeListener() {},
  addEventListener() {},
  removeEventListener() {},
})
// linkedom exposes Event but no MouseEvent/KeyboardEvent subclasses.
window.MouseEvent = window.Event
window.KeyboardEvent = window.Event
globalThis.MouseEvent = window.Event
window.getComputedStyle = () => ({ opacity: '1', getPropertyValue: () => '' })
globalThis.getComputedStyle = window.getComputedStyle
window.Element.prototype.getBoundingClientRect = () => ({
  top: 0, bottom: 0, left: 0, right: 0, width: 0, height: 0, x: 0, y: 0,
})

test.after(() => {
  for (const id of liveIntervals) clearInterval(id)
  liveIntervals.clear()
})

// The bundle kicks off background host syncs from effects; those legitimately
// resolve outside act(), so keep the report readable.
const consoleError = console.error
console.error = (...args) => {
  if (typeof args[0] === 'string' && args[0].includes('not wrapped in act')) return
  consoleError(...args)
}

// ---------------------------------------------------------------------------
// Dictionary — the plugin's real zh strings, parsed from its source
// ---------------------------------------------------------------------------
const PLUGIN_SOURCE = readFileSync(new URL('../client.js', import.meta.url), 'utf8')
const ZH_BLOCK = PLUGIN_SOURCE.slice(
  PLUGIN_SOURCE.indexOf('    const zh = {'),
  PLUGIN_SOURCE.indexOf('    const en = {'),
)
const DICT = Object.fromEntries(
  [...ZH_BLOCK.matchAll(/^\s*'([^']+)':\s*'(.*)',$/gm)].map((m) => [m[1], m[2]]),
)
assert.ok(Object.keys(DICT).length > 100, 'dictionary parsed')

const t = (key, params) => {
  const template = DICT[key] ?? key.split('.').pop()
  if (!params) return template
  return template.replace(/\{(\w+)\}/g, (_m, name) => String(params[name] ?? ''))
}

const fire = (element, type) => element.dispatchEvent(new window.Event(type, { bubbles: true }))

// ---------------------------------------------------------------------------
// Harness
// ---------------------------------------------------------------------------
function createStore(initial) {
  let state = initial
  const listeners = new Set()
  return {
    get: () => state,
    set(patch) {
      state = { ...state, ...patch }
      for (const fn of listeners) fn()
    },
    hook(selector) {
      return React.useSyncExternalStore(
        (fn) => {
          listeners.add(fn)
          return () => listeners.delete(fn)
        },
        () => selector(state),
        () => selector(state),
      )
    },
  }
}

function initialHostState() {
  return {
    revision: 1,
    baselineAt: 1,
    pinMode: 'hybrid',
    defaultPinTarget: 'space',
    hideSpacePinsInWorkspace: true,
    alwaysShowPinSpace: true,
    pinSpaceExpanded: true,
    pinScopes: {},
    spaceOrder: [],
    readAt: {},
    forceUnread: {},
    activityPrefs: {
      showPrioritySection: true,
      includePinnedInPriority: false,
      includeScheduledInPriority: false,
      unreadOnly: false,
    },
  }
}

let importSeq = 0

async function createHarness() {
  document.body.innerHTML = ''
  storage.clear()

  const sessionsStore = createStore({ phase: 'ready', ids: [], byId: {}, projectionsBySession: {} })
  const workspacesStore = createStore({ items: [], archivedSessionIds: [], pinnedSessionIds: [] })
  const statusStore = createStore(new Map())
  const panelStore = createStore({ activePanelId: null })

  const calls = { pin: [], unpin: [], open: [], archive: [] }
  // Mirrors the shipped service: pinning drives the registry, which is what
  // makes the row actually move (and therefore what FLIP animates).
  const uiWorkspace = {
    pinSession: async (id) => {
      calls.pin.push(id)
      const pinned = workspacesStore.get().pinnedSessionIds ?? []
      if (!pinned.includes(id)) workspacesStore.set({ pinnedSessionIds: [...pinned, id] })
    },
    unpinSession: async (id) => {
      calls.unpin.push(id)
      const pinned = workspacesStore.get().pinnedSessionIds ?? []
      workspacesStore.set({ pinnedSessionIds: pinned.filter((pinnedId) => pinnedId !== id) })
    },
    openSession: (id) => { calls.open.push(id) },
    archiveSession: async (id) => { calls.archive.push(id) },
    unarchiveSession: async () => {},
    forkSession: async () => {},
    startSession: () => {},
    pickDirectory: async () => null,
    listDirectory: async () => ({ path: '/tmp', entries: [], crumbs: [{ name: 'tmp', path: '/tmp' }] }),
  }

  let hostState = initialHostState()
  const requests = []
  globalThis.fetch = async (url, init = {}) => {
    requests.push({ url: String(url), init })
    let next = hostState
    if (init.method === 'POST') {
      const body = JSON.parse(init.body)
      next = { ...hostState, revision: hostState.revision + 1 }
      if (body.action === 'pin_space') {
        next.pinScopes = { ...hostState.pinScopes, [body.sessionId]: 'space' }
        next.spaceOrder = [body.sessionId, ...hostState.spaceOrder]
      }
      if (body.action === 'pin_workspace') {
        next.pinScopes = { ...hostState.pinScopes, [body.sessionId]: 'workspace' }
      }
      if (body.action === 'unpin') {
        const scopes = { ...hostState.pinScopes }
        delete scopes[body.sessionId]
        next.pinScopes = scopes
        next.spaceOrder = hostState.spaceOrder.filter((id) => id !== body.sessionId)
      }
      hostState = next
    }
    return { ok: true, status: 200, json: async () => ({ ok: true, state: next }) }
  }

  let entry = null
  window.__ModuleLoader__ = {
    load({ id, factory }) {
      entry = {
        id,
        exports: factory((name) => {
          if (name === 'react') return React
          throw new Error(`unexpected require: ${name}`)
        }),
      }
    },
  }
  // Fresh URL per harness → fresh module-level stores.
  await import(`../client.js?h=${(importSeq += 1)}`)
  assert.ok(entry, 'client bundle registered itself')
  // DSH refuses to load the bundle unless this id matches package.json `name`.
  assert.equal(entry.id, 'dsh-session-sidebar', 'module loader id matches package name')

  const registered = { sidebar: null, overlay: null }
  const ctx = {
    effect(fn) {
      const cleanup = fn()
      return typeof cleanup === 'function' ? cleanup : () => {}
    },
    on: () => () => {},
    get: () => undefined,
    logger: { warn() {}, info() {} },
    locale: { register: () => () => {}, bind: () => t },
    slots: {
      inject(_name, cb) { cb() },
      register(def, Component) {
        if (def.name === 'sidebar.workspaces') registered.sidebar = Component
        if (def.name === 'shell.overlay') registered.overlay = Component
        return () => {}
      },
    },
    sessions: {
      search: async () => ({ ok: true, value: { items: [], hasMore: false } }),
      refreshProjections: async () => {},
      searchResultLimit: 20,
      using: async (_id, _opts, fn) => fn({ binding: { session: { rename: async () => ({ ok: true, value: {} }) } } }),
    },
    workspaces: {
      create: async () => ({ workspaceId: 'ws-new' }),
      rename: async () => {},
      delete: async () => {},
      insertBefore: async () => {},
    },
    uiWorkspace,
    layout: {},
    remote: {},
  }
  entry.exports.apply(ctx)
  assert.ok(registered.sidebar, 'sidebar.workspaces registrant captured')

  const mounted = []
  const overlayRoots = []

  function mountOverlay() {
    const host = document.createElement('div')
    document.body.appendChild(host)
    const root = createRoot(host)
    overlayRoots.push(root)
    act(() => { root.render(React.createElement(registered.overlay, { t })) })
    return host
  }

  function mount() {
    const container = document.createElement('div')
    document.body.appendChild(container)
    const root = createRoot(container)
    mounted.push(root)
    const props = {
      wide: true,
      expandSidebar: () => {},
      useSessions: (sel) => sessionsStore.hook(sel),
      useWorkspaces: (sel) => workspacesStore.hook(sel),
      useSessionStatus: (sel) => statusStore.hook(sel),
      usePanelInfo: (sel) => panelStore.hook(sel),
      t,
    }
    act(() => { root.render(React.createElement(registered.sidebar, props)) })
    return container
  }

  function seed({ sessions, workspaces, pinned = [], archived = [] }) {
    const byId = {}
    for (const s of sessions) byId[s.id] = s
    sessionsStore.set({ ids: sessions.map((s) => s.id), byId })
    workspacesStore.set({ items: workspaces, pinnedSessionIds: pinned, archivedSessionIds: archived })
  }

  function clickMenu(container, label, menuLabel = DICT['viewOptions.label']) {
    const anchor = container.querySelector(`[aria-label="${menuLabel}"]`)
    assert.ok(anchor, `menu anchor ${menuLabel} present`)
    act(() => fire(anchor, 'click'))
    const host = mountOverlay()
    const item = [...host.querySelectorAll('[role="menuitem"]')].find((el) => el.textContent.includes(label))
    assert.ok(item, `menu item ${label} present`)
    act(() => fire(item, 'click'))
    return host
  }

  function cleanup() {
    for (const root of mounted) act(() => root.unmount())
    for (const root of overlayRoots) act(() => root.unmount())
    mounted.length = 0
    overlayRoots.length = 0
    document.body.innerHTML = ''
  }

  return {
    mount,
    mountOverlay,
    seed,
    clickMenu,
    cleanup,
    calls,
    requests,
    rowKeys: (container) => [...container.querySelectorAll('[data-row-key]')].map((el) => el.dataset.rowKey),
    byText: (container, selector, text) => [...container.querySelectorAll(selector)].find((el) => el.textContent.includes(text)),
  }
}

function makeSession(id, title, extra = {}) {
  return {
    id,
    title,
    blank: false,
    origin: 'user',
    updatedAt: Date.now() - 60_000,
    running: false,
    retainedBy: {},
    projectionValues: {},
    ...extra,
  }
}

const flush = async () => {
  await Promise.resolve()
  await Promise.resolve()
  await new Promise((resolve) => nativeSetTimeout(resolve, 0))
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------
test('renders workspace groups, session rows and the pinned area header', async () => {
  const h = await createHarness()
  try {
    h.seed({
      sessions: [
        makeSession('s1', '修复侧栏动画'),
        makeSession('s2', '数据库课程设计'),
        makeSession('s3', '复盘 PR #15'),
      ],
      workspaces: [{ workspaceId: 'ws-1', title: 'rma-trace', path: '/tmp/rma', sessionIds: ['s1', 's2', 's3'] }],
      pinned: ['s2'],
    })
    const container = h.mount()

    assert.ok(container.querySelector('.dshAp_root'), 'root rendered')
    assert.deepEqual(h.rowKeys(container), [
      'pinned-space:header',
      'session:space:s2',
      'projects:header',
      'ws:ws-1',
      'session:ws:ws-1:s1',
      'session:ws:ws-1:s3',
    ])
    assert.ok(h.byText(container, '.dshAp_wsSourceTag', 'rma-trace'), 'pinned row carries a source badge')
    assert.equal(container.querySelectorAll('.dshAp_row').length, 3)
  } finally {
    h.cleanup()
  }
})

test('changing the session count does not violate hook order', async () => {
  const h = await createHarness()
  try {
    const container = h.mount()
    // The old inline row helper added one useRef/useMemo pair per row to the
    // parent's hook list, so this loop is the regression that used to throw.
    for (let count = 1; count <= 6; count += 1) {
      const sessions = Array.from({ length: count }, (_v, i) => makeSession(`s${i}`, `会话${i}`))
      act(() => {
        h.seed({
          sessions,
          workspaces: [{ workspaceId: 'ws-1', title: 'rma-trace', path: '/tmp/rma', sessionIds: sessions.map((s) => s.id) }],
        })
      })
      // The default watermark shows five rows; the rest sit behind "n more".
      assert.equal(
        container.querySelectorAll('.dshAp_row').length,
        Math.min(count, 5),
        `rendered ${Math.min(count, 5)} of ${count} rows`,
      )
      if (count > 5) {
        assert.ok(container.querySelector('.dshAp_overflowBtn'), 'overflow row appears past the watermark')
      }
    }
  } finally {
    h.cleanup()
  }
})

test('collapsing a workspace hides only its sessions and keeps the header', async () => {
  const h = await createHarness()
  try {
    h.seed({
      sessions: [makeSession('s1', '会话一'), makeSession('s2', '会话二')],
      workspaces: [{ workspaceId: 'ws-1', title: 'rma-trace', path: '/tmp/rma', sessionIds: ['s1', 's2'] }],
    })
    const container = h.mount()
    act(() => fire(container.querySelector('.dshAp_wsRow'), 'click'))

    const keys = h.rowKeys(container)
    assert.ok(keys.includes('ws:ws-1'))
    assert.ok(!keys.includes('session:ws:ws-1:s1'))
    assert.equal(container.querySelectorAll('.dshAp_row').length, 0)
  } finally {
    h.cleanup()
  }
})

test('「单列表」 grouping renders one flat list with workspace badges', async () => {
  const h = await createHarness()
  try {
    h.seed({
      sessions: [makeSession('s1', '会话一'), makeSession('s2', '会话二')],
      workspaces: [
        { workspaceId: 'ws-1', title: 'rma-trace', path: '/tmp/rma', sessionIds: ['s1'] },
        { workspaceId: 'ws-2', title: 'dsh-session-sidebar', path: '/tmp/pins', sessionIds: ['s2'] },
      ],
    })
    const container = h.mount()
    h.clickMenu(container, DICT['groupBy.flat'])

    const keys = h.rowKeys(container)
    assert.ok(keys.includes('flat:header'), 'flat header rendered')
    assert.ok(keys.includes('session:flat:s1'))
    assert.ok(keys.includes('session:flat:s2'))
    assert.ok(!container.querySelector('.dshAp_wsRow'), 'no workspace header in flat mode')
    assert.equal(container.querySelectorAll('.dshAp_wsSourceTag').length, 2, 'every flat row shows its workspace badge')
  } finally {
    h.cleanup()
  }
})

test('quick pin goes through uiWorkspace and the host API', async () => {
  const h = await createHarness()
  try {
    h.seed({
      sessions: [makeSession('s1', '会话一')],
      workspaces: [{ workspaceId: 'ws-1', title: 'rma-trace', path: '/tmp/rma', sessionIds: ['s1'] }],
    })
    const container = h.mount()

    const pinBtn = container.querySelector(`[aria-label="${DICT['action.pinSpace']}"]`)
    assert.ok(pinBtn, 'quick pin button rendered')
    await act(async () => {
      fire(pinBtn, 'click')
      await flush()
    })

    assert.deepEqual(h.calls.pin, ['s1'], 'native pin service used')
    const post = h.requests.find((r) => r.init?.method === 'POST')
    assert.ok(post, 'host API called')
    assert.equal(JSON.parse(post.init.body).action, 'pin_space')
  } finally {
    h.cleanup()
  }
})

test('archived sessions cannot be opened and surface a toast', async () => {
  const h = await createHarness()
  try {
    h.seed({
      sessions: [makeSession('s1', '归档会话')],
      workspaces: [{ workspaceId: 'ws-1', title: 'rma-trace', path: '/tmp/rma', sessionIds: ['s1'] }],
      archived: ['s1'],
    })
    const container = h.mount()
    // Archived rows are hidden by the default filter; switch to "archived only".
    const overlayHost = h.clickMenu(container, DICT['filter.onlyArchived'])

    const row = container.querySelector('.dshAp_row')
    assert.ok(row, 'archived row visible under the archived filter')
    act(() => fire(row, 'click'))

    assert.deepEqual(h.calls.open, [], 'archived session not opened')
    assert.ok(h.byText(overlayHost, '.dshAp_toast', '取消归档'), 'toast explains why')
  } finally {
    h.cleanup()
  }
})

test('the activity view lists running and unread chats', async () => {
  const h = await createHarness()
  try {
    h.seed({
      sessions: [
        makeSession('s1', '运行中的任务', { running: true }),
        makeSession('s2', '完成的对话', {
          projectionValues: { dshSessionSidebar: { lastTurnEndAt: Date.now(), lastAssistantSnippet: '已完成修改。' } },
        }),
        makeSession('s3', '空闲的旧对话'),
      ],
      workspaces: [{ workspaceId: 'ws-1', title: 'rma-trace', path: '/tmp/rma', sessionIds: ['s1', 's2', 's3'] }],
    })
    const container = h.mount()

    const bell = container.querySelector(`[aria-label="${DICT['activity.open']}"]`)
    assert.ok(bell, 'bell button rendered')
    act(() => fire(bell, 'click'))

    assert.ok(container.querySelector('.dshAp_actHeader'), 'activity header shown')
    assert.ok(container.querySelectorAll('.dshAp_priorityCard').length >= 1, 'priority cards rendered')
    assert.ok(h.byText(container, '.dshAp_actSection', DICT['date.today']), 'date-grouped feed rendered')
  } finally {
    h.cleanup()
  }
})

test('pin changes animate rows instead of snapping (FLIP stays enabled)', async () => {
  const h = await createHarness()
  const originalRect = window.Element.prototype.getBoundingClientRect
  const originalAnimate = window.Element.prototype.animate
  let animations = 0
  try {
    h.seed({
      sessions: [makeSession('s1', '会话一'), makeSession('s2', '会话二')],
      workspaces: [{ workspaceId: 'ws-1', title: 'rma-trace', path: '/tmp/rma', sessionIds: ['s1', 's2'] }],
    })
    const container = h.mount()

    // linkedom reports empty rects and has no Web Animations API; supply just
    // enough for the FLIP pass to consider rows visible and observable.
    window.Element.prototype.getBoundingClientRect = () => ({
      top: 0, bottom: 32, left: 0, right: 200, width: 200, height: 32, x: 0, y: 0,
    })
    window.Element.prototype.animate = function animate() {
      animations += 1
      return { cancel() {}, onfinish: null }
    }

    // Motion only starts after the first pointer/key input inside the list.
    act(() => fire(container.querySelector('.dshAp_treeContainer'), 'pointerdown'))

    const pinBtns = container.querySelectorAll(`[aria-label="${DICT['action.pinSpace']}"]`)
    assert.equal(pinBtns.length, 2, 'both rows offer the quick pin')
    await act(async () => {
      fire(pinBtns[1], 'click')
      await flush()
      await flush()
    })

    assert.ok(animations > 0, 'FLIP animations ran for the entering/leaving rows')
    assert.ok(h.rowKeys(container).includes('session:space:s2'), 'row moved into the pinned area')
  } finally {
    window.Element.prototype.getBoundingClientRect = originalRect
    if (originalAnimate === undefined) delete window.Element.prototype.animate
    else window.Element.prototype.animate = originalAnimate
    h.cleanup()
  }
})
