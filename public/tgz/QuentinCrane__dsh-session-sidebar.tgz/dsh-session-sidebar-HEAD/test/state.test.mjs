import test from 'node:test'
import assert from 'node:assert/strict'

import {
  extractMessageSnippet,
  initProjectionState,
  foldSessionActivity,
  SessionSidebarGlobalStateSchema,
  createInitialGlobalState,
  resolveEffectivePinScope,
  computeSessionUnread,
  reducePinSession,
  reduceUnpinSession,
  reduceMarkRead,
  reduceMarkUnread,
  reduceMarkAllRead,
} from '../src/state.js'
import { apply, name as pluginName } from '../index.js'

test('extractMessageSnippet strips markdown and clamps length', () => {
  const snippet = extractMessageSnippet([
    {
      type: 'text',
      text: '## 评估结果\n满足。按你列出的**四项要求**，查看 [报告](https://example.com) 如下：\n```sql\nSELECT * FROM users;\n```',
    },
  ], 60)
  assert.ok(!snippet.includes('##'))
  assert.ok(!snippet.includes('**'))
  assert.ok(snippet.includes('满足。按你列出的四项要求'))
  assert.ok(snippet.length <= 61)
})

test('foldSessionActivity preserves reference on unrelated events and folds assistant/turn events', () => {
  const s0 = initProjectionState()
  const s1 = foldSessionActivity(s0, { type: 'tool/call', time: 1000, data: {} })
  assert.equal(s1, s0)

  const s2 = foldSessionActivity(s1, {
    type: 'assistant/message',
    time: 2000,
    data: { message: { content: [{ type: 'text', text: '已完成修改并验证通过。' }] } },
  })
  assert.equal(s2.lastAssistantSnippet, '已完成修改并验证通过。')
  assert.equal(s2.lastAssistantAt, 2000)

  const s3 = foldSessionActivity(s2, {
    type: 'turn/end',
    time: 2500,
    data: { reason: { kind: 'completed' } },
  })
  assert.equal(s3.lastTurnEndAt, 2500)
  assert.equal(s3.lastTurnReason, 'completed')
  assert.equal(s3.turnCount, 1)
})

test('SessionSidebarGlobalStateSchema rejects null sentinel for storageDomain compatibility', () => {
  assert.equal(SessionSidebarGlobalStateSchema.safeParse(null).success, false)
  const valid = SessionSidebarGlobalStateSchema.safeParse(createInitialGlobalState(1000))
  assert.equal(valid.success, true)
})

test('dual pin scopes and unread state transitions', () => {
  let state = createInitialGlobalState(1000)
  state = reducePinSession(state, 'sess-1', 'space')
  state = reducePinSession(state, 'sess-2', 'workspace')

  assert.equal(resolveEffectivePinScope('sess-1', true, state), 'space')
  assert.equal(resolveEffectivePinScope('sess-2', true, state), 'workspace')
  assert.equal(resolveEffectivePinScope('sess-1', false, state), null)

  // Session finishing after baselineAt is unread until marked read
  assert.equal(
    computeSessionUnread({ sessionId: 'sess-1', running: false, lastTurnEndAt: 2000, updatedAt: 2000 }, state),
    true,
  )
  state = reduceMarkRead(state, 'sess-1', 2500)
  assert.equal(
    computeSessionUnread({ sessionId: 'sess-1', running: false, lastTurnEndAt: 2000, updatedAt: 2000 }, state),
    false,
  )

  // Explicit markUnread overrides readAt until marked read again
  state = reduceMarkUnread(state, 'sess-1')
  assert.equal(
    computeSessionUnread({ sessionId: 'sess-1', running: false, lastTurnEndAt: 2000, updatedAt: 2000 }, state),
    true,
  )
  state = reduceMarkAllRead(state, ['sess-1'], 3000)
  assert.equal(
    computeSessionUnread({ sessionId: 'sess-1', running: false, lastTurnEndAt: 2000, updatedAt: 2000 }, state),
    false,
  )

  state = reduceUnpinSession(state, 'sess-1')
  assert.equal(state.pinScopes['sess-1'], undefined)
})

test('Host apply registers projection and tool and executes pin/read actions', async () => {
  let registeredProjection = null
  let registeredTool = null
  const pinned = new Set()

  const mockWorkspaceRegistry = {
    list: () => [{ id: 'ws-1', title: 'mysql大作业', path: '/tmp/mysql', sessionIds: ['s-1', 's-2'] }],
    get pinnedSessionIds() { return [...pinned] },
    get archivedSessionIds() { return [] },
    async pinSession(id) { pinned.add(id) },
    async unpinSession(id) { pinned.delete(id) },
  }

  const mockSessionController = {
    async list() {
      return {
        items: [
          {
            sessionId: 's-1',
            running: true,
            blank: false,
            updatedAt: 5000,
            projections: { values: { title: '附录 B 核心代码与测试记录索引', dshSessionSidebar: { lastTurnEndAt: 0, lastAssistantSnippet: '' } } },
          },
          {
            sessionId: 's-2',
            running: false,
            blank: false,
            updatedAt: 4000,
            projections: { values: { title: '规划数据库课程设计报告', dshSessionSidebar: { lastTurnEndAt: 9999999999999, lastAssistantSnippet: '已完成规划。' } } },
          },
        ],
      }
    },
  }

  const mockCtx = {
    sessionProjections: {
      register(def) {
        registeredProjection = def
        return () => {}
      },
    },
    tools: {
      register(def) {
        registeredTool = def
        return () => {}
      },
    },
    effect(fn) {
      const cleanup = fn()
      return typeof cleanup === 'function' ? cleanup : () => {}
    },
    inject(deps, cb) {
      if (deps.includes('tools')) cb(mockCtx)
      return () => {}
    },
    get(name) {
      if (name === 'workspaceRegistry') return mockWorkspaceRegistry
      if (name === 'sessionController') return mockSessionController
      return undefined
    },
  }

  apply(mockCtx)
  assert.ok(registeredProjection)
  assert.ok(registeredTool)
  // Identity locks: package name and projection key must stay in sync.
  assert.equal(pluginName, 'dsh-session-sidebar')
  assert.equal(registeredProjection.key, 'dshSessionSidebar')

  const pinRes = await registeredTool.execute({ action: 'pin_space', session_id: 's-2' }, {})
  assert.equal(pinRes.ok, true)
  assert.equal(pinRes.pinScope, 'space')
  assert.equal(pinned.has('s-2'), true)

  const actRes = await registeredTool.execute({ action: 'list_activity' }, {})
  assert.equal(actRes.ok, true)
  assert.equal(actRes.runningCount, 1)
  assert.equal(actRes.unreadCount, 1)
  assert.equal(actRes.items[0].workspaceTitle, 'mysql大作业')
})

test('extractMessageSnippet supports string content and fallback', () => {
  const snippet = extractMessageSnippet('直接以字符串形式返回的消息内容')
  assert.equal(snippet, '直接以字符串形式返回的消息内容')
})

test('running session does not report unread even with forceUnread', () => {
  const state = { forceUnread: { 's-1': true } }
  assert.equal(computeSessionUnread({ sessionId: 's-1', running: true }, state), false)
  assert.equal(computeSessionUnread({ sessionId: 's-1', running: false }, state), true)
})
