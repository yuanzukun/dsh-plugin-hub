package setup

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/mnemon-dev/mnemon/internal/memory/setup/assets"
)

func TestPromptDirHonorsMnemonDataDir(t *testing.T) {
	custom := t.TempDir()
	t.Setenv("MNEMON_DATA_DIR", custom)

	got, err := promptDir()
	if err != nil {
		t.Fatalf("promptDir: %v", err)
	}
	want := filepath.Join(custom, "prompt")
	if got != want {
		t.Fatalf("promptDir = %q, want %q", got, want)
	}
}

func TestPromptDirFallsBackToHomeWhenEnvUnset(t *testing.T) {
	t.Setenv("MNEMON_DATA_DIR", "")
	fakeHome := t.TempDir()
	t.Setenv("HOME", fakeHome)

	got, err := promptDir()
	if err != nil {
		t.Fatalf("promptDir: %v", err)
	}
	want := filepath.Join(fakeHome, ".mnemon", "prompt")
	if got != want {
		t.Fatalf("promptDir = %q, want %q", got, want)
	}
}

func TestWritePromptFilesWritesUnderMnemonDataDir(t *testing.T) {
	custom := t.TempDir()
	t.Setenv("MNEMON_DATA_DIR", custom)

	path, err := WritePromptFiles()
	if err != nil {
		t.Fatalf("WritePromptFiles: %v", err)
	}

	wantDir := filepath.Join(custom, "prompt")
	if path != wantDir {
		t.Fatalf("returned path = %q, want %q", path, wantDir)
	}

	for _, name := range []string{"guide.md", "skill.md"} {
		full := filepath.Join(wantDir, name)
		info, err := os.Stat(full)
		if err != nil {
			t.Fatalf("stat %s: %v", full, err)
		}
		if info.Size() == 0 {
			t.Fatalf("%s is empty", full)
		}
	}
}

func TestClaudeMemoryInstructionsKeepSubagentsLeafWriters(t *testing.T) {
	tests := []struct {
		name string
		body string
		want []string
	}{
		{
			name: "guide",
			body: string(assets.ClaudeGuide),
			want: []string{
				"The sub-agent is the leaf memory writer",
				"Do NOT ask the memory sub-agent to delegate again",
			},
		},
		{
			name: "skill",
			body: string(assets.ClaudeSkill),
			want: []string{
				"Main conversation: never run `remember` or `link` directly",
				"Memory sub-agent: you are the leaf writer",
				"do not spawn another sub-agent",
			},
		},
		{
			name: "stop hook",
			body: string(assets.ClaudeStopHook),
			want: []string{
				`"hook_event_name"[[:space:]]*:[[:space:]]*"SubagentStop"`,
				"complete it directly with mnemon remember/link",
				"do not spawn another sub-agent",
			},
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			for _, want := range tt.want {
				if !strings.Contains(tt.body, want) {
					t.Fatalf("%s is missing %q", tt.name, want)
				}
			}
		})
	}
}

func TestCollidesWithUserConfigHomeInstall(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("CLAUDE_CONFIG_DIR", "")
	t.Chdir(home)

	if !collidesWithUserConfig(".claude") {
		t.Fatal("project-local .claude with cwd == $HOME must collide with ~/.claude")
	}

	proj := t.TempDir()
	t.Chdir(proj)
	if collidesWithUserConfig(".claude") {
		t.Fatal("genuine project-local install must not collide")
	}
}

func TestCollidesWithUserConfigResolvesSymlinks(t *testing.T) {
	base := t.TempDir()
	real := filepath.Join(base, "realhome")
	link := filepath.Join(base, "linkhome")
	if err := os.MkdirAll(filepath.Join(real, ".claude"), 0755); err != nil {
		t.Fatal(err)
	}
	if err := os.Symlink(real, link); err != nil {
		t.Fatal(err)
	}
	t.Setenv("HOME", link) // $HOME reached via symlink
	t.Setenv("CLAUDE_CONFIG_DIR", "")
	t.Chdir(real) // cwd is the physical path

	if !collidesWithUserConfig(".claude") {
		t.Fatal("symlinked $HOME vs physical cwd must still be detected as a collision")
	}
}

func TestCollidesWithUserConfigHonorsClaudeConfigDir(t *testing.T) {
	home := t.TempDir()
	relocated := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("CLAUDE_CONFIG_DIR", relocated)
	t.Chdir(home)

	// With the user config relocated, ~/.claude is NOT the global file.
	if collidesWithUserConfig(".claude") {
		t.Fatal("cwd == $HOME must not collide when CLAUDE_CONFIG_DIR points elsewhere")
	}

	// But installing into the relocated dir itself is a collision.
	t.Chdir(filepath.Dir(relocated))
	if !collidesWithUserConfig(filepath.Base(relocated)) {
		t.Fatal("install targeting the CLAUDE_CONFIG_DIR dir must collide")
	}
}

func TestClaudeRegisterHooksCollisionWritesAbsoluteCommands(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("CLAUDE_CONFIG_DIR", "")
	t.Chdir(home)

	if _, err := ClaudeRegisterHooks(".claude", HookSelection{Remind: true, Nudge: true}); err != nil {
		t.Fatalf("register: %v", err)
	}
	data, err := ReadJSONFile(filepath.Join(home, ".claude", "settings.json"))
	if err != nil {
		t.Fatal(err)
	}
	hooks := data["hooks"].(map[string]any)
	for _, ev := range []string{"SessionStart", "UserPromptSubmit", "Stop"} {
		entry := hooks[ev].([]any)[0].(map[string]any)["hooks"].([]any)[0].(map[string]any)
		cmd := strings.Trim(entry["command"].(string), `"`) // Windows commands are quoted
		if !filepath.IsAbs(cmd) {
			t.Fatalf("%s command must be absolute in the user-global file, got %q", ev, cmd)
		}
	}
}

func TestClaudeRegisterHooksProjectLocalStaysRelative(t *testing.T) {
	home := t.TempDir()
	proj := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("CLAUDE_CONFIG_DIR", "")
	t.Chdir(proj)

	if _, err := ClaudeRegisterHooks(".claude", HookSelection{}); err != nil {
		t.Fatalf("register: %v", err)
	}
	data, err := ReadJSONFile(filepath.Join(proj, ".claude", "settings.json"))
	if err != nil {
		t.Fatal(err)
	}
	hooks := data["hooks"].(map[string]any)
	entry := hooks["SessionStart"].([]any)[0].(map[string]any)["hooks"].([]any)[0].(map[string]any)
	if cmd := entry["command"].(string); filepath.IsAbs(cmd) {
		t.Fatalf("genuine project-local install must keep existing relative form, got %q", cmd)
	}
}

func TestAddClaudeHooksSelectiveWindowsQuotesForwardSlashPaths(t *testing.T) {
	for _, tc := range []struct{ name, dir, prefix string }{
		{"global", `C:\Users\John Smith\.claude\hooks\mnemon`, "C:/Users/John Smith/.claude/hooks/mnemon"},
		{"project-local", `.claude\hooks\mnemon`, ".claude/hooks/mnemon"},
		{"trailing separator", `C:\u\.claude\hooks\mnemon\`, "C:/u/.claude/hooks/mnemon"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			data := map[string]any{}
			addClaudeHooksSelective(data, tc.dir, HookSelection{Remind: true, Nudge: true, Compact: true}, "windows")
			hooks := data["hooks"].(map[string]any)
			for ev, script := range map[string]string{
				"SessionStart": "prime.sh", "UserPromptSubmit": "user_prompt.sh",
				"Stop": "stop.sh", "PreCompact": "compact.sh",
			} {
				entry := hooks[ev].([]any)[0].(map[string]any)["hooks"].([]any)[0].(map[string]any)
				want := `"` + tc.prefix + "/" + script + `"`
				if got := entry["command"].(string); got != want {
					t.Fatalf("%s command = %q, want %q", ev, got, want)
				}
			}
		})
	}
}

func TestAddClaudeHooksSelectiveNonWindowsKeepsBarePaths(t *testing.T) {
	data := map[string]any{}
	addClaudeHooksSelective(data, "/home/u/.claude/hooks/mnemon", HookSelection{Remind: true}, "linux")
	hooks := data["hooks"].(map[string]any)
	entry := hooks["SessionStart"].([]any)[0].(map[string]any)["hooks"].([]any)[0].(map[string]any)
	if got, want := entry["command"].(string), filepath.Join("/home/u/.claude/hooks/mnemon", "prime.sh"); got != want {
		t.Fatalf("non-Windows command = %q, want %q", got, want)
	}
}

func TestAddClaudeHooksSelectiveWindowsReplacesQuotedMnemonHooks(t *testing.T) {
	data := map[string]any{}
	addClaudeHooksSelective(data, `C:\u\.claude\hooks\mnemon`, HookSelection{}, "windows")
	addClaudeHooksSelective(data, `C:\u\.claude\hooks\mnemon`, HookSelection{}, "windows")
	if n := len(data["hooks"].(map[string]any)["SessionStart"].([]any)); n != 1 {
		t.Fatalf("re-registering must replace the quoted hook, got %d entries", n)
	}
}
