#!/usr/bin/env bash
#
# Mnemon E2E visual test
# Usage: ./scripts/e2e_test.sh
#
set -euo pipefail

# ── Colors ────────────────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
BOLD='\033[1m'
DIM='\033[2m'
RESET='\033[0m'

PASS=0
FAIL=0
TOTAL=0

# ── Helpers ───────────────────────────────────────────────────────────
banner() {
  echo ""
  echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
  echo -e "${BOLD}${CYAN}  $1${RESET}"
  echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
}

step() {
  echo ""
  echo -e "  ${YELLOW}▸${RESET} ${BOLD}$1${RESET}"
}

show_json() {
  echo "$1" | jq '.' 2>/dev/null | head -"${2:-20}" | sed 's/^/    /'
}

pass() {
  local label="$1"; local detail="$2"
  TOTAL=$((TOTAL + 1)); PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} $label ${DIM}$detail${RESET}"
}

fail() {
  local label="$1"; local detail="$2"
  TOTAL=$((TOTAL + 1)); FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} $label ${DIM}$detail${RESET}"
}

# assert_contains LABEL JSON NEEDLE
assert_contains() {
  if echo "$2" | grep -q "$3"; then
    pass "$1" "(contains: $3)"
  else
    fail "$1" "(expected: $3)"
  fi
}

# assert_not_contains LABEL JSON NEEDLE
assert_not_contains() {
  if echo "$2" | grep -q "$3"; then
    fail "$1" "(should NOT contain: $3)"
  else
    pass "$1" "(absent: $3)"
  fi
}

# assert_jq LABEL JSON JQ_FILTER EXPECTED
# e.g. assert_jq "total is 1" "$OUT" '.total_insights' '1'
assert_jq() {
  local label="$1" json="$2" filter="$3" expected="$4"
  local actual
  actual=$(echo "$json" | jq -r "$filter" 2>/dev/null || echo "__ERROR__")
  if [ "$actual" = "$expected" ]; then
    pass "$label" "($filter == $expected)"
  else
    fail "$label" "($filter: expected=$expected, got=$actual)"
  fi
}

# assert_jq_gte LABEL JSON JQ_FILTER EXPECTED
assert_jq_gte() {
  local label="$1" json="$2" filter="$3" expected="$4"
  local actual
  actual=$(echo "$json" | jq -r "$filter" 2>/dev/null || echo "0")
  if [ "$actual" -ge "$expected" ] 2>/dev/null; then
    pass "$label" "($filter=$actual >= $expected)"
  else
    fail "$label" "($filter: expected >= $expected, got=$actual)"
  fi
}

# assert_jq_lte LABEL JSON JQ_FILTER EXPECTED
assert_jq_lte() {
  local label="$1" json="$2" filter="$3" expected="$4"
  local actual
  actual=$(echo "$json" | jq -r "$filter" 2>/dev/null || echo "0")
  if [ "$actual" -le "$expected" ] 2>/dev/null; then
    pass "$label" "($filter=$actual <= $expected)"
  else
    fail "$label" "($filter: expected <= $expected, got=$actual)"
  fi
}

extract_id() {
  echo "$1" | jq -r '.id'
}

# ── Setup ─────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
TESTDATA=$(mktemp -d "${TMPDIR:-/tmp}/mnemon-e2e.XXXXXX")
TESTDIR="$TESTDATA/m1"
M="$TESTDATA/mnemon"

cleanup() {
  if [ "${E2E_KEEP:-0}" = 1 ]; then
    echo -e "  ${DIM}Test data preserved at: $TESTDATA/${RESET}"
    return
  fi
  if [ -d "$TESTDATA" ] && [ ! -L "$TESTDATA" ]; then
    case "$(basename "$TESTDATA")" in
      mnemon-e2e.??????) rm -rf -- "$TESTDATA" ;;
      *) echo "refusing to remove unexpected E2E directory: $TESTDATA" >&2 ;;
    esac
  fi
}
trap cleanup EXIT

banner "Building mnemon"
cd "$PROJECT_DIR"
go build -o "$M" .
echo -e "  ${GREEN}✔${RESET} Binary built: $M"

mkdir -p "$TESTDIR"
echo -e "  ${DIM}Test data: $TESTDATA/${RESET}"

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 0: Store Management & Data Isolation"
# ══════════════════════════════════════════════════════════════════════

STORE_DIR="$TESTDATA/store_test"
mkdir -p "$STORE_DIR"

step "store list — empty on fresh dir"
OUT=$($M --data-dir "$STORE_DIR" store list)
assert_contains "no stores message" "$OUT" "no stores yet"

step "store create — create stores"
OUT=$($M --data-dir "$STORE_DIR" store create default)
assert_contains "created default" "$OUT" 'Created store "default"'
OUT=$($M --data-dir "$STORE_DIR" store create work)
assert_contains "created work" "$OUT" 'Created store "work"'

step "store create — reject duplicate"
OUT=$($M --data-dir "$STORE_DIR" store create work 2>&1 || true)
assert_contains "rejects duplicate" "$OUT" "already exists"

step "store create — reject invalid name"
OUT=$($M --data-dir "$STORE_DIR" store create ".bad" 2>&1 || true)
assert_contains "rejects invalid" "$OUT" "invalid store name"

step "store list — shows created stores"
OUT=$($M --data-dir "$STORE_DIR" store list)
assert_contains "lists default" "$OUT" "default"
assert_contains "lists work" "$OUT" "work"

step "store set — switch active store"
$M --data-dir "$STORE_DIR" store set work
OUT=$($M --data-dir "$STORE_DIR" store list)
assert_contains "work is active" "$OUT" "* work"

step "store set — reject nonexistent"
OUT=$($M --data-dir "$STORE_DIR" store set nonexistent 2>&1 || true)
assert_contains "rejects missing" "$OUT" "does not exist"

step "store remove — cannot remove active store"
OUT=$($M --data-dir "$STORE_DIR" store remove work 2>&1 || true)
assert_contains "rejects active removal" "$OUT" "cannot remove the active store"

step "store remove — remove inactive store"
$M --data-dir "$STORE_DIR" store create temp
OUT=$($M --data-dir "$STORE_DIR" store remove temp)
assert_contains "removed temp" "$OUT" 'Removed store "temp"'

step "data isolation — memories in different stores are isolated"
MNEMON_STORE=default $M --data-dir "$STORE_DIR" remember --no-diff "I am in default store" --cat fact --imp 3 > /dev/null
MNEMON_STORE=work $M --data-dir "$STORE_DIR" remember --no-diff "I am in work store" --cat fact --imp 3 > /dev/null

OUT=$(MNEMON_STORE=default $M --data-dir "$STORE_DIR" search "default store")
assert_contains "default finds own data" "$OUT" "I am in default store"
assert_not_contains "default not finds work data" "$OUT" "I am in work store"

OUT=$(MNEMON_STORE=work $M --data-dir "$STORE_DIR" search "work store")
assert_contains "work finds own data" "$OUT" "I am in work store"
assert_not_contains "work not finds default data" "$OUT" "I am in default store"

step "MNEMON_STORE env — overrides active file"
# Active is "work", but env says "default"
OUT=$(MNEMON_STORE=default $M --data-dir "$STORE_DIR" status)
assert_contains "env override db path" "$OUT" "data/default/mnemon.db"

step "migration — moves legacy DB to data/default/"
MIGRATE_DIR="$TESTDATA/migrate_test"
mkdir -p "$MIGRATE_DIR"
# Create legacy-layout DB
$M --data-dir "$MIGRATE_DIR" remember --no-diff "legacy insight" --cat fact --imp 3 > /dev/null 2>&1 || true
# Force migration by removing data dir if it was auto-created
if [ -d "$MIGRATE_DIR/data" ]; then
  # The openDB already created data layout — test is moot, skip
  pass "migration" "(auto-migrated by openDB)"
else
  # Legacy mnemon.db should exist
  OUT=$($M --data-dir "$MIGRATE_DIR" status)
  assert_contains "migrated db path" "$OUT" "data/default/mnemon.db"
fi

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 1: Basic CRUD"
# ══════════════════════════════════════════════════════════════════════

step "remember — store insight with tags"
OUT=$($M --data-dir "$TESTDIR" remember --no-diff "User prefers Qdrant for vector DB" --cat preference --imp 4 --tags "tool,db")
show_json "$OUT" 20
ID1=$(extract_id "$OUT")
assert_jq "category is preference" "$OUT" '.category' 'preference'
assert_jq "importance is 4"        "$OUT" '.importance' '4'
assert_contains "tags include tool" "$OUT" '"tool"'
assert_contains "entities has Qdrant" "$OUT" '"Qdrant"'

step "readonly recall — absolute and relative data paths preserve the database"
cp "$TESTDIR/data/default/mnemon.db" "$TESTDATA/readonly-before.db"
OUT=$("$M" --data-dir "$TESTDIR" --store default --readonly recall "" --basic --limit 100000)
assert_jq "readonly absolute path finds the seed" "$OUT" '.[0].id' "$ID1"
OUT=$(cd "$TESTDATA" && "$M" --data-dir "m1" --store default --readonly recall "Qdrant" --basic --limit 6)
assert_jq "readonly relative path finds the seed" "$OUT" '.[0].id' "$ID1"
if cmp -s "$TESTDATA/readonly-before.db" "$TESTDIR/data/default/mnemon.db"; then
  pass "readonly recall preserves database bytes" "(including counters and oplog)"
else
  fail "readonly recall preserves database bytes" "(database changed)"
fi
for suffix in -wal -shm -journal; do
  if [ -e "$TESTDIR/data/default/mnemon.db$suffix" ]; then
    fail "readonly recall creates no $suffix sidecar" "(sidecar exists)"
  else
    pass "readonly recall creates no $suffix sidecar" "(absent)"
  fi
done

step "recall — keyword search (compact default)"
OUT=$($M --data-dir "$TESTDIR" recall "Qdrant")
show_json "$OUT" 10
assert_contains "found Qdrant insight" "$OUT" "User prefers Qdrant"
assert_contains "compact has confidence" "$OUT" '"confidence"'
assert_not_contains "compact omits signals" "$OUT" '"signals"'
assert_not_contains "compact omits anchor_count" "$OUT" '"anchor_count"'

step "recall --brief → show — bounded discovery then full content"
OUT=$($M --data-dir "$TESTDIR" recall "Qdrant" --brief --excerpt-chars 20)
assert_jq "brief excerpt is bounded" "$OUT" '.results[0].excerpt | length <= 20' 'true'
assert_not_contains "brief omits full content field" "$OUT" '"content"'
assert_contains "brief points to full lookup" "$OUT" 'mnemon show <id>'
SHOW_OUT=$($M --data-dir "$TESTDIR" show "$ID1")
assert_contains "show restores full content" "$SHOW_OUT" 'User prefers Qdrant for vector DB'
assert_jq "show returns requested id" "$SHOW_OUT" '.id' "$ID1"
OUT=$($M --data-dir "$TESTDIR" recall "Qdrant" --basic --brief --excerpt-chars 20)
assert_jq "basic brief uses the same bounded projection" "$OUT" '.results[0].excerpt | length <= 20' 'true'
OUT=$($M --data-dir "$TESTDIR" recall "Qdrant" --brief --verbose 2>&1 || true)
assert_contains "brief and verbose are mutually exclusive" "$OUT" 'cannot be used together'

step "recall — no match returns sparse hint (compact)"
OUT=$($M --data-dir "$TESTDIR" recall "nonexistent_xyz")
assert_contains "sparse hint" "$OUT" "sparse_results"

step "recall --verbose — full payload"
OUT=$($M --data-dir "$TESTDIR" recall "Qdrant" --verbose)
assert_contains "verbose has meta" "$OUT" '"meta"'
assert_contains "verbose has signals" "$OUT" '"signals"'
assert_contains "verbose has anchor_count" "$OUT" '"anchor_count"'

step "status — statistics"
OUT=$($M --data-dir "$TESTDIR" status)
show_json "$OUT"
assert_jq "total is 1"          "$OUT" '.total_insights' '1'
assert_jq "preference count"    "$OUT" '.by_category.preference' '1'
assert_jq "no deleted insights" "$OUT" '.deleted_insights' '0'

step "forget — soft delete"
OUT=$($M --data-dir "$TESTDIR" forget "$ID1")
show_json "$OUT"
assert_jq "status is deleted" "$OUT" '.status' 'deleted'

OUT=$($M --data-dir "$TESTDIR" status)
assert_jq "total now 0"    "$OUT" '.total_insights'   '0'
assert_jq "deleted now 1"  "$OUT" '.deleted_insights'  '1'

step "remember diff — distinct subjects retain independent facts without embeddings"
DIFF_DIR="$TESTDATA/distinct-facts"
diff_cli() {
  MNEMON_EMBED_ENDPOINT="http://127.0.0.1:1" MNEMON_MAX_INSIGHTS=1000 \
    "$M" --data-dir "$DIFF_DIR" --store default "$@"
}
FACT_ALPHA="Project Alpha uses PostgreSQL database for persistent application storage"
FACT_BETA="Project Beta uses PostgreSQL database for persistent application storage"
ALPHA_OUT=$(diff_cli remember "$FACT_ALPHA" --cat fact --imp 5)
BETA_OUT=$(diff_cli remember "$FACT_BETA" --cat fact --imp 5)
ALPHA_ID=$(extract_id "$ALPHA_OUT")
BETA_ID=$(extract_id "$BETA_OUT")
assert_jq "first fact is added" "$ALPHA_OUT" '.action' 'added'
assert_jq "distinct subject is added" "$BETA_OUT" '.action' 'added'
assert_jq "UPDATE remains advisory" "$BETA_OUT" '.diff_suggestion' 'UPDATE'
assert_jq "distinct fact has no replaced id" "$BETA_OUT" 'has("replaced_id")' 'false'
assert_jq "embedding endpoint is unavailable" "$BETA_OUT" '.embedded' 'false'
assert_jq "Alpha remains addressable" "$(diff_cli show "$ALPHA_ID")" '.content' "$FACT_ALPHA"
assert_jq "Beta remains addressable" "$(diff_cli show "$BETA_ID")" '.content' "$FACT_BETA"
OUT=$(diff_cli recall "Project Alpha storage")
assert_contains "recall retains Alpha" "$OUT" "$FACT_ALPHA"
assert_contains "recall retains Beta" "$OUT" "$FACT_BETA"
OUT=$(diff_cli status)
assert_jq "both facts are active" "$OUT" '.total_insights' '2'
assert_jq "no fact was soft-deleted" "$OUT" '.deleted_insights' '0'

step "remember diff — exact repeats skip, changed values need deliberate forgetting"
OUT=$(diff_cli remember "$FACT_BETA" --cat fact --imp 5)
assert_jq "exact repeat skips" "$OUT" '.action' 'skipped'
assert_jq "repeat identifies existing Beta" "$OUT" '.replaced_id' "$BETA_ID"
OUT=$(diff_cli remember "Project Alpha uses SQLite database for persistent application storage" --cat fact --imp 5)
CORRECTED_ID=$(extract_id "$OUT")
assert_jq "changed value is added" "$OUT" '.action' 'added'
assert_jq "all three facts are active" "$(diff_cli status)" '.total_insights' '3'
assert_jq "explicit forget deletes selected Alpha" "$(diff_cli forget "$ALPHA_ID")" '.status' 'deleted'
assert_jq "corrected fact remains addressable" "$(diff_cli show "$CORRECTED_ID")" '.id' "$CORRECTED_ID"
assert_jq "unrelated Beta remains addressable" "$(diff_cli show "$BETA_ID")" '.id' "$BETA_ID"

step "remember diff — near duplicate subjects are both stored"
DIFF_DIR="$TESTDATA/distinct-long-facts"
FACT_DETAILS=" with indexed customer records, transaction history, audit events, replication, backups, failover, monitoring, access controls, migrations, connection pooling, and disaster recovery"
diff_cli remember "$FACT_ALPHA$FACT_DETAILS" --cat fact --imp 5 > /dev/null
OUT=$(diff_cli remember "$FACT_BETA$FACT_DETAILS" --cat fact --imp 5)
assert_jq "near duplicate is added" "$OUT" '.action' 'added'
assert_jq "heuristic duplicate remains advisory" "$OUT" '.diff_suggestion' 'DUPLICATE'
assert_jq "both long facts are active" "$(diff_cli status)" '.total_insights' '2'

step "import diff — retain distinct subjects and reuse exact duplicate ids"
DIFF_DIR="$TESTDATA/distinct-import-facts"
jq -n --arg alpha "$FACT_ALPHA" --arg beta "$FACT_BETA" '{schema_version: "1", insights: [
  {content: $alpha, category: "fact", importance: 5},
  {content: $beta, category: "fact", importance: 5},
  {content: $alpha, category: "fact", importance: 5}
]}' > "$TESTDATA/distinct-import.json"
OUT=$(diff_cli import "$TESTDATA/distinct-import.json")
assert_jq "import adds both subjects" "$OUT" '.imported' '2'
assert_jq "import never auto-replaces" "$OUT" '.updated' '0'
assert_jq "import skips one exact repeat" "$OUT" '.skipped' '1'
assert_jq "import preserves exact duplicate index mapping" "$OUT" '.results[0].id == .results[2].id' 'true'
assert_jq "both imported facts remain active" "$(diff_cli status)" '.total_insights' '2'

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 2: Graph Edge Auto-Generation"
# ══════════════════════════════════════════════════════════════════════

# Fresh DB for cleaner edge tests
TESTDIR2="$TESTDATA/m2"
mkdir -p "$TESTDIR2"

step "remember 3 insights — check temporal + causal edges"
OUT1=$($M --data-dir "$TESTDIR2" remember --no-diff "User prefers Qdrant for vector DB" --cat preference --imp 4)
ID_A=$(extract_id "$OUT1")
assert_jq "first: no temporal" "$OUT1" '.edges_created.temporal' '0'

sleep 1  # ensure distinct timestamps

OUT2=$($M --data-dir "$TESTDIR2" remember --no-diff "Chose Qdrant because of Rust performance" --cat decision --imp 5)
ID_B=$(extract_id "$OUT2")
assert_jq "second: 2 temporal" "$OUT2" '.edges_created.temporal' '2'
assert_jq "second: 1 causal"   "$OUT2" '.edges_created.causal'   '1'

sleep 1

OUT3=$($M --data-dir "$TESTDIR2" remember --no-diff "Qdrant benchmark shows 10ms p99 latency" --cat fact --imp 3)
ID_C=$(extract_id "$OUT3")
assert_jq_gte "third: >= 2 temporal (backbone + proximity)" "$OUT3" '.edges_created.temporal' '2'

step "status — verify edge count"
OUT=$($M --data-dir "$TESTDIR2" status)
assert_jq_gte "edges >= 5" "$OUT" '.edge_count' '5'

step "related — temporal traversal from B"
OUT=$($M --data-dir "$TESTDIR2" related "$ID_B" --edge temporal)
show_json "$OUT" 20
assert_contains "finds A via temporal" "$OUT" "$ID_A"
assert_contains "finds C via temporal" "$OUT" "$ID_C"

step "related — causal traversal from B"
OUT=$($M --data-dir "$TESTDIR2" related "$ID_B" --edge causal)
show_json "$OUT" 10
assert_contains "finds A via causal" "$OUT" "$ID_A"

step "Entity extraction — CamelCase"
OUT=$($M --data-dir "$TESTDIR2" remember --no-diff "We use HttpServer and DataStore in the project" --cat fact)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_contains "HttpServer extracted" "$OUT" '"HttpServer"'
assert_contains "DataStore extracted"  "$OUT" '"DataStore"'
ID_D=$(extract_id "$OUT")

sleep 1

step "Entity edge — shared entity creates link"
OUT=$($M --data-dir "$TESTDIR2" remember --no-diff "HttpServer handles all API requests" --cat fact)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')  edges: $(echo "$OUT" | jq -c '.edges_created')${RESET}"
assert_jq_gte "entity edges created (bidirectional)" "$OUT" '.edges_created.entity' '2'
ID_E=$(extract_id "$OUT")

step "Entity edge — bidirectional traversal"
OUT=$($M --data-dir "$TESTDIR2" related "$ID_E" --edge entity)
assert_contains "E → D via entity" "$OUT" "$ID_D"
OUT=$($M --data-dir "$TESTDIR2" related "$ID_D" --edge entity)
assert_contains "D → E via entity (reverse)" "$OUT" "$ID_E"

step "Entity extraction — file paths"
OUT=$($M --data-dir "$TESTDIR2" remember --no-diff "Config lives at ./cmd/root.go and internal/memory/store/db.go" --cat fact)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_contains "file path extracted" "$OUT" './cmd/root.go'

step "Entity extraction — Chinese book titles"
OUT=$($M --data-dir "$TESTDIR2" remember --no-diff "推荐阅读《深入理解计算机系统》这本书" --cat fact)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_contains "Chinese title extracted" "$OUT" '深入理解计算机系统'

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 3: Search + Diff"
# ══════════════════════════════════════════════════════════════════════

step "search — token-scored search"
OUT=$($M --data-dir "$TESTDIR2" search "Rust performance")
show_json "$OUT" 15
assert_contains "finds decision insight" "$OUT" "Chose Qdrant"
assert_contains "has score field"        "$OUT" '"score"'

step "search --brief — bounded discovery projection"
OUT=$($M --data-dir "$TESTDIR2" search "Rust performance" --brief --excerpt-chars 18)
assert_jq "search brief excerpt is bounded" "$OUT" '.results[0].excerpt | length <= 18' 'true'
assert_contains "search brief points to full lookup" "$OUT" 'mnemon show <id>'

step "search — no match returns []"
OUT=$($M --data-dir "$TESTDIR2" search "zzz_no_match_zzz")
assert_jq "empty array" "$OUT" 'length' '0'


# ══════════════════════════════════════════════════════════════════════
banner "Milestone 4: Intent-Aware Smart Recall"
# ══════════════════════════════════════════════════════════════════════

# Fresh DB for multi-level traversal test
TESTDIR3="$TESTDATA/m4"
mkdir -p "$TESTDIR3"

step "multi-level traversal — build A→B→C causal chain"
# A: anchor (keyword-matched), B: 1-hop, C: 2-hop (only reachable with depth>=2)
OUT_X=$($M --data-dir "$TESTDIR3" remember --no-diff "Alpha service handles request routing" --cat fact --imp 3)
ID_X=$(extract_id "$OUT_X")

sleep 1

OUT_Y=$($M --data-dir "$TESTDIR3" remember --no-diff "Request routing uses Alpha service because of low latency" --cat decision --imp 4)
ID_Y=$(extract_id "$OUT_Y")
assert_jq_gte "Y has causal edge to X" "$OUT_Y" '.edges_created.causal' '1'

sleep 1

OUT_Z=$($M --data-dir "$TESTDIR3" remember --no-diff "Low latency achieved because of edge caching" --cat fact --imp 3)
ID_Z=$(extract_id "$OUT_Z")
assert_jq_gte "Z has causal edge to Y" "$OUT_Z" '.edges_created.causal' '1'

step "multi-level traversal — smart recall finds depth-2 node"
OUT=$($M --data-dir "$TESTDIR3" recall "why Alpha service routing" --smart --verbose)
echo -e "    ${DIM}intent: $(echo "$OUT" | jq -r '.results[0].intent // "N/A"')  results: $(echo "$OUT" | jq '.results | length')${RESET}"
echo "$OUT" | jq -r '.results[] | "    \(.via)\t\(.score | tostring | .[:6])\t\(.insight.content[:50])"' 2>/dev/null
assert_contains "finds anchor X (Alpha)" "$OUT" "$ID_X"
assert_contains "finds depth-1 Y (routing)" "$OUT" "$ID_Y"
assert_contains "finds depth-2 Z (caching)" "$OUT" "$ID_Z"

step "smart recall — WHY intent"
OUT=$($M --data-dir "$TESTDIR2" recall "why did we choose Qdrant" --smart --verbose)
echo -e "    ${DIM}intent: $(echo "$OUT" | jq -r '.results[0].intent // "N/A"')  results: $(echo "$OUT" | jq '.results | length')${RESET}"
assert_contains "intent is WHY" "$OUT" '"WHY"'
assert_contains "finds Qdrant insight" "$OUT" "Qdrant"

step "smart recall — WHEN intent"
OUT=$($M --data-dir "$TESTDIR2" recall "when did we choose vector db" --smart --verbose)
echo -e "    ${DIM}intent: $(echo "$OUT" | jq -r '.results[0].intent // "N/A"')  results: $(echo "$OUT" | jq '.results | length')${RESET}"
assert_contains "intent is WHEN" "$OUT" '"WHEN"'

step "smart recall — graph augments results"
OUT=$($M --data-dir "$TESTDIR2" recall "why Qdrant performance" --smart --verbose)
COUNT=$(echo "$OUT" | jq '.results | length')
TOTAL=$((TOTAL + 1))
if [ "$COUNT" -ge 2 ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} Returns multiple results ${DIM}(count=$COUNT)${RESET}"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Expected >= 2 results, got $COUNT"
fi

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 5: Semantic Edges (Claude-in-the-loop)"
# ══════════════════════════════════════════════════════════════════════

step "remember — output includes semantic_candidates field"
TESTDIR5="$TESTDATA/m5"
mkdir -p "$TESTDIR5"
OUT=$($M --data-dir "$TESTDIR5" remember --no-diff "Go is great for building CLI tools" --cat fact --imp 3)
assert_contains "has semantic_candidates" "$OUT" '"semantic_candidates"'
assert_jq "semantic field is 0 in edges_created" "$OUT" '.edges_created.semantic' '0'
ID_S1=$(extract_id "$OUT")

sleep 1

step "remember — similar content generates candidates"
OUT=$($M --data-dir "$TESTDIR5" remember --no-diff "Building CLI tools in Go is efficient" --cat fact --imp 3)
assert_contains "has semantic_candidates" "$OUT" '"semantic_candidates"'
ID_S2=$(extract_id "$OUT")
# Should find the first insight as a candidate (high token overlap)
SC_COUNT=$(echo "$OUT" | jq '.semantic_candidates | length')
TOTAL=$((TOTAL + 1))
if [ "$SC_COUNT" -ge 1 ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} Found $SC_COUNT semantic candidate(s)"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Expected >= 1 semantic candidates, got $SC_COUNT"
fi

step "remember — unrelated content has fewer candidates"
OUT=$($M --data-dir "$TESTDIR5" remember --no-diff "Xylophone zebra quantum platypus" --cat fact --imp 2)
SC_COUNT=$(echo "$OUT" | jq '.semantic_candidates | length')
# With embeddings, generic similarity may still produce low-score candidates (cosine > 0.30).
# Verify count is within bounds (≤ maxSemanticCandidates=5).
assert_jq_lte "unrelated: limited candidates" "$OUT" '.semantic_candidates | length' '5'

step "link — create semantic edge"
OUT=$($M --data-dir "$TESTDIR5" link "$ID_S1" "$ID_S2" --type semantic --weight 0.85)
show_json "$OUT" 10
assert_jq "status is linked" "$OUT" '.status' 'linked'
assert_jq "edge type is semantic" "$OUT" '.edge_type' 'semantic'
assert_contains "created_by claude" "$OUT" '"created_by"'

step "link — verify bidirectional edges"
OUT=$($M --data-dir "$TESTDIR5" related "$ID_S1" --edge semantic)
assert_contains "S1 → S2 via semantic" "$OUT" "$ID_S2"
OUT=$($M --data-dir "$TESTDIR5" related "$ID_S2" --edge semantic)
assert_contains "S2 → S1 via semantic (reverse)" "$OUT" "$ID_S1"

step "link — weight validation"
OUT=$($M --data-dir "$TESTDIR5" link "$ID_S1" "$ID_S2" --type semantic --weight 1.5 2>&1 || true)
assert_contains "rejects weight > 1.0" "$OUT" "weight must be"

step "link — nonexistent insight"
OUT=$($M --data-dir "$TESTDIR5" link "$ID_S1" "nonexistent-id-000" --type semantic --weight 0.5 2>&1 || true)
assert_contains "rejects missing insight" "$OUT" "not found"

step "smart recall — semantic edges participate in traversal"
OUT=$($M --data-dir "$TESTDIR5" recall "Go CLI" --smart --verbose)
COUNT=$(echo "$OUT" | jq '.results | length')
TOTAL=$((TOTAL + 1))
if [ "$COUNT" -ge 2 ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} Semantic-linked insights found ${DIM}(count=$COUNT)${RESET}"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Expected >= 2 results via semantic edges, got $COUNT"
fi

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 6: Retention Lifecycle (effective_importance)"
# ══════════════════════════════════════════════════════════════════════

TESTDIR6="$TESTDATA/m6"
mkdir -p "$TESTDIR6"

step "setup — create insights with varying importance"
$M --data-dir "$TESTDIR6" remember --no-diff "Critical architecture decision: use SQLite" --cat decision --imp 5 > /dev/null
sleep 1
$M --data-dir "$TESTDIR6" remember --no-diff "Minor note about formatting" --cat general --imp 1 > /dev/null
ID_LOW=$(extract_id "$($M --data-dir "$TESTDIR6" remember --no-diff "Temporary context note" --cat context --imp 1)")
sleep 1
$M --data-dir "$TESTDIR6" remember --no-diff "Important user preference for dark mode" --cat preference --imp 4 > /dev/null

step "remember — output includes effective_importance and auto_pruned"
OUT=$($M --data-dir "$TESTDIR6" remember --no-diff "Test insight for lifecycle" --cat fact --imp 3)
assert_contains "has effective_importance" "$OUT" '"effective_importance"'
assert_contains "has auto_pruned" "$OUT" '"auto_pruned"'
assert_jq "auto_pruned is 0 (under cap)" "$OUT" '.auto_pruned' '0'

step "gc — suggest mode returns candidates with effective_importance"
OUT=$($M --data-dir "$TESTDIR6" gc --threshold 0.7)
show_json "$OUT" 25
assert_contains "has candidates field" "$OUT" '"candidates"'
assert_contains "has actions field"    "$OUT" '"actions"'
assert_contains "has max_insights"     "$OUT" '"max_insights"'
assert_jq "total_insights is 5" "$OUT" '.total_insights' '5'

step "gc — low-importance non-immune insights appear as candidates"
CAND_COUNT=$(echo "$OUT" | jq '.candidates_found')
TOTAL=$((TOTAL + 1))
if [ "$CAND_COUNT" -ge 1 ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} Found $CAND_COUNT GC candidate(s)"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Expected >= 1 GC candidates, got $CAND_COUNT"
fi

step "gc — candidates have effective_importance and immune fields"
FIRST=$(echo "$OUT" | jq '.candidates[0]')
assert_contains "has effective_importance" "$FIRST" '"effective_importance"'
assert_contains "has days_since"           "$FIRST" '"days_since_access"'
assert_contains "has immune field"         "$FIRST" '"immune"'

step "gc — immune insights (imp>=4) are excluded from candidates"
# Check that no candidate has importance >= 4
HIGH_IMP=$(echo "$OUT" | jq '[.candidates[] | select(.insight.importance >= 4)] | length')
assert_jq "no high-imp candidates" "$OUT" '[.candidates[] | select(.insight.importance >= 4)] | length' '0'

step "gc --keep — boost retention"
OUT=$($M --data-dir "$TESTDIR6" gc --keep "$ID_LOW")
show_json "$OUT" 10
assert_jq "status is retained" "$OUT" '.status' 'retained'
assert_jq "access count boosted" "$OUT" '.new_access' '3'
assert_contains "has effective_importance" "$OUT" '"effective_importance"'
assert_contains "has immune field"         "$OUT" '"immune"'

step "gc — kept insight becomes immune (access_count >= 3)"
OUT_AFTER=$($M --data-dir "$TESTDIR6" gc --threshold 0.7)
KEPT_STILL=$(echo "$OUT_AFTER" | jq --arg id "$ID_LOW" '[.candidates[].insight.id] | index($id)')
TOTAL=$((TOTAL + 1))
if [ "$KEPT_STILL" = "null" ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} Boosted insight is now immune (not in candidates)"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Boosted insight should be immune but still in candidates"
fi

step "gc --keep — nonexistent insight"
OUT=$($M --data-dir "$TESTDIR6" gc --keep "nonexistent-id-000" 2>&1 || true)
assert_contains "rejects missing insight" "$OUT" "not found"

step "gc — high threshold returns more candidates"
OUT=$($M --data-dir "$TESTDIR6" gc --threshold 2.0)
HIGH_COUNT=$(echo "$OUT" | jq '.candidates_found')
TOTAL=$((TOTAL + 1))
if [ "$HIGH_COUNT" -ge "$CAND_COUNT" ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} Higher threshold → more candidates ($HIGH_COUNT >= $CAND_COUNT)"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Expected higher threshold to find more candidates"
fi

# ══════════════════════════════════════════════════════════════════════
banner "Observability: Operation Log"
# ══════════════════════════════════════════════════════════════════════

step "log — shows operations from TESTDIR2"
OUT=$($M --data-dir "$TESTDIR2" log --limit 30)
echo "$OUT" | head -10 | sed 's/^/    /'
assert_contains "log has remember ops" "$OUT" "remember"
assert_contains "log has recall ops"   "$OUT" "recall"

step "log — shows link and gc operations"
OUT=$($M --data-dir "$TESTDIR5" log --limit 30)
assert_contains "log has link ops" "$OUT" "link"

OUT=$($M --data-dir "$TESTDIR6" log --limit 30)
assert_contains "log has gc ops" "$OUT" "gc"

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 7: Embedding Support (Ollama)"
# ══════════════════════════════════════════════════════════════════════

step "embed --status — always works (even without Ollama)"
TESTDIR7="$TESTDATA/m7"
mkdir -p "$TESTDIR7"
$M --data-dir "$TESTDIR7" remember --no-diff "Embedding test insight one" --cat fact --imp 3 > /dev/null
$M --data-dir "$TESTDIR7" remember --no-diff "Embedding test insight two" --cat fact --imp 3 > /dev/null
OUT=$($M --data-dir "$TESTDIR7" embed --status)
show_json "$OUT"
assert_jq "total_insights is 2" "$OUT" '.total_insights' '2'
assert_contains "has ollama_available" "$OUT" '"ollama_available"'
assert_contains "has coverage field" "$OUT" '"coverage"'

# Check if Ollama is available for the remaining tests
OLLAMA_OK=$(echo "$OUT" | jq -r '.ollama_available')
if [ "$OLLAMA_OK" = "true" ]; then
  step "remember — auto-embeds when Ollama available"
  OUT=$($M --data-dir "$TESTDIR7" remember --no-diff "This insight should be auto-embedded" --cat fact --imp 3)
  assert_jq "embedded is true" "$OUT" '.embedded' 'true'
  ID_E1=$(extract_id "$OUT")

  step "embed --all — backfill un-embedded insights"
  # Create an insight without auto-embedding by pointing Ollama to a dead endpoint
  MNEMON_EMBED_ENDPOINT="http://127.0.0.1:1" $M --data-dir "$TESTDIR7" remember --no-diff "Un-embedded test insight" --cat fact --imp 2 > /dev/null

  # Backfill all — should find the un-embedded one
  OUT=$($M --data-dir "$TESTDIR7" embed --all)
  show_json "$OUT"
  assert_jq "backfill status" "$OUT" '.status' 'backfill_complete'
  assert_contains "has succeeded count" "$OUT" '"succeeded"'

  step "embed --status — verify coverage after backfill"
  OUT=$($M --data-dir "$TESTDIR7" embed --status)
  assert_jq "all embedded" "$OUT" '.coverage' '100%'

  step "recall --smart — uses hybrid search with embeddings"
  OUT=$($M --data-dir "$TESTDIR7" recall "embedding test" --smart --verbose)
  COUNT=$(echo "$OUT" | jq '.results | length')
  TOTAL=$((TOTAL + 1))
  if [ "$COUNT" -ge 1 ]; then
    PASS=$((PASS + 1))
    echo -e "    ${GREEN}✔${RESET} Smart recall with embeddings works ${DIM}(count=$COUNT)${RESET}"
  else
    FAIL=$((FAIL + 1))
    echo -e "    ${RED}✘${RESET} Expected >= 1 results, got $COUNT"
  fi
else
  echo -e "  ${DIM}  Ollama not available — skipping embedding integration tests${RESET}"
  echo -e "  ${DIM}  Install: brew install ollama && ollama pull nomic-embed-text${RESET}"

  step "remember — embedded=false when Ollama unavailable"
  OUT=$($M --data-dir "$TESTDIR7" remember --no-diff "This insight will not be embedded" --cat fact --imp 3)
  assert_jq "embedded is false" "$OUT" '.embedded' 'false'
fi

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 8: Causal Candidates (2-hop BFS Neighborhood)"
# ══════════════════════════════════════════════════════════════════════

TESTDIR8="$TESTDATA/m8"
mkdir -p "$TESTDIR8"

step "causal candidates — output includes causal_candidates field"
OUT=$($M --data-dir "$TESTDIR8" remember --no-diff "Causal test baseline insight about caching" --cat fact --imp 3)
assert_contains "has causal_candidates" "$OUT" '"causal_candidates"'
ID_CC1=$(extract_id "$OUT")

step "causal candidates — BFS finds neighbors via edges"
sleep 1
OUT=$($M --data-dir "$TESTDIR8" remember --no-diff "Chose Redis because of latency requirements in caching" --cat decision --imp 4)
assert_contains "has causal_candidates" "$OUT" '"causal_candidates"'
ID_CC2=$(extract_id "$OUT")
CC_COUNT=$(echo "$OUT" | jq '.causal_candidates | length')
TOTAL=$((TOTAL + 1))
if [ "$CC_COUNT" -ge 1 ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} Found $CC_COUNT causal candidate(s) via BFS"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Expected >= 1 causal candidates, got $CC_COUNT"
fi

step "causal candidates — candidate has hop and via_edge fields"
if [ "$CC_COUNT" -ge 1 ]; then
  FIRST_CC=$(echo "$OUT" | jq '.causal_candidates[0]')
  assert_contains "has hop" "$FIRST_CC" '"hop"'
  assert_contains "has via_edge" "$FIRST_CC" '"via_edge"'
  assert_contains "has causal_signal" "$FIRST_CC" '"causal_signal"'
  assert_contains "has suggested_sub_type" "$FIRST_CC" '"suggested_sub_type"'
fi

step "causal candidates — hop-2 discovery via graph"
sleep 1
OUT=$($M --data-dir "$TESTDIR8" remember --no-diff "Edge caching reduces Redis load significantly" --cat fact --imp 3)
ID_CC3=$(extract_id "$OUT")
CC_COUNT2=$(echo "$OUT" | jq '.causal_candidates | length')
TOTAL=$((TOTAL + 1))
if [ "$CC_COUNT2" -ge 2 ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} Found $CC_COUNT2 candidates (includes hop-2 via BFS)"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Expected >= 2 causal candidates (hop-1 + hop-2), got $CC_COUNT2"
fi

step "entity extraction — dictionary-based (tech terms)"
TESTDIR_DICT="$TESTDATA/m_dict"
mkdir -p "$TESTDIR_DICT"
OUT=$($M --data-dir "$TESTDIR_DICT" remember --no-diff "We use React and TypeScript with Redis for caching" --cat fact --imp 3)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_contains "React extracted via dictionary" "$OUT" '"React"'
assert_contains "TypeScript extracted via dictionary" "$OUT" '"TypeScript"'
assert_contains "Redis extracted via dictionary" "$OUT" '"Redis"'

step "entity extraction — acronyms (ALLCAPS)"
OUT=$($M --data-dir "$TESTDIR_DICT" remember --no-diff "The API uses gRPC and JWT for authentication over HTTP" --cat fact --imp 3)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_contains "API extracted" "$OUT" '"API"'
assert_contains "JWT extracted" "$OUT" '"JWT"'
assert_contains "HTTP extracted" "$OUT" '"HTTP"'

step "entity extraction — stopwords not extracted"
OUT=$($M --data-dir "$TESTDIR_DICT" remember --no-diff "IF YOU CAN SEE THE WAY TO DO IT" --cat fact --imp 2)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_not_contains "IF not extracted" "$OUT" '"IF"'
assert_not_contains "YOU not extracted" "$OUT" '"YOU"'

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 9: LLM Entity Injection (--entities flag)"
# ══════════════════════════════════════════════════════════════════════

TESTDIR9="$TESTDATA/m9"
mkdir -p "$TESTDIR9"

step "--entities — LLM-provided entities appear in output"
OUT=$($M --data-dir "$TESTDIR9" remember --no-diff "The new caching layer improves performance significantly" --cat fact --imp 3 --entities "caching-layer,performance-optimization")
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_contains "LLM entity present" "$OUT" '"caching-layer"'
assert_contains "LLM entity present" "$OUT" '"performance-optimization"'

step "--entities — merges with regex-extracted entities"
OUT=$($M --data-dir "$TESTDIR9" remember --no-diff "We deploy HttpServer on Docker with Redis" --cat fact --imp 3 --entities "deployment-pipeline,high-availability")
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
# LLM-provided
assert_contains "LLM entity: deployment-pipeline" "$OUT" '"deployment-pipeline"'
assert_contains "LLM entity: high-availability" "$OUT" '"high-availability"'
# Regex/dictionary-extracted
assert_contains "regex entity: HttpServer" "$OUT" '"HttpServer"'
assert_contains "dict entity: Docker" "$OUT" '"Docker"'
assert_contains "dict entity: Redis" "$OUT" '"Redis"'

step "--entities — creates entity edges with shared LLM entities"
OUT=$($M --data-dir "$TESTDIR9" remember --no-diff "Upgrading the caching layer for better throughput" --cat decision --imp 4 --entities "caching-layer,throughput")
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')  edges: $(echo "$OUT" | jq -c '.edges_created')${RESET}"
# "caching-layer" is shared with the first insight → should create entity edges
assert_jq_gte "entity edges from shared LLM entity" "$OUT" '.edges_created.entity' '2'

step "--entities — no flag still works (regex only)"
OUT=$($M --data-dir "$TESTDIR9" remember --no-diff "Python and FastAPI are great for prototyping" --cat fact --imp 3)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_contains "dict entity: Python" "$OUT" '"Python"'
assert_contains "dict entity: FastAPI" "$OUT" '"FastAPI"'

step "--entity-mode provided — only LLM-provided entities are used"
OUT=$($M --data-dir "$TESTDIR9" remember --no-diff "We deploy HttpServer on Docker with Redis" --cat fact --imp 3 --entities "strict-entity" --entity-mode provided)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_contains "provided entity present" "$OUT" '"strict-entity"'
assert_not_contains "regex entity omitted in provided mode" "$OUT" '"HttpServer"'
assert_not_contains "dict entity omitted in provided mode" "$OUT" '"Docker"'

step "--entity-mode auto — ignores LLM-provided entities"
OUT=$($M --data-dir "$TESTDIR9" remember --no-diff "We deploy HttpServer on Docker with Redis" --cat fact --imp 3 --entities "ignored-entity" --entity-mode auto)
echo -e "    ${DIM}entities: $(echo "$OUT" | jq -c '.entities')${RESET}"
assert_not_contains "provided entity ignored in auto mode" "$OUT" '"ignored-entity"'
assert_contains "regex entity present in auto mode" "$OUT" '"HttpServer"'
assert_contains "dict entity present in auto mode" "$OUT" '"Docker"'

# ══════════════════════════════════════════════════════════════════════
banner "Milestone 10: Auto-Prune Lifecycle"
# ══════════════════════════════════════════════════════════════════════

TESTDIR10="$TESTDATA/m10"
mkdir -p "$TESTDIR10"

step "auto-prune — default grace protects a same-second write burst"
for i in 1 2 3; do
  OUT=$(MNEMON_MAX_INSIGHTS=2 $M --data-dir "$TESTDIR10" remember --no-diff "Low importance note $i" --cat general --imp 1)
done
assert_jq "newborn memories are not pruned" "$OUT" '.auto_pruned' '0'
assert_jq "newborn prune id list is empty" "$OUT" '.auto_pruned_ids | length' '0'

step "auto-prune — explicit zero grace returns ids and durable audit rows"
OUT=$(MNEMON_MAX_INSIGHTS=2 MNEMON_AUTO_PRUNE_MIN_AGE=0 $M --data-dir "$TESTDIR10" remember --no-diff "High importance decision" --cat decision --imp 5)
assert_jq "two excess memories are pruned" "$OUT" '.auto_pruned' '2'
assert_jq "pruned ids match count" "$OUT" '.auto_pruned_ids | length' '2'
PRUNED_PREFIX=$(echo "$OUT" | jq -r '.auto_pruned_ids[0][0:8]')
LOG_OUT=$($M --data-dir "$TESTDIR10" log --limit 20)
assert_contains "auto-prune operation is visible" "$LOG_OUT" "auto-prune"
assert_contains "auto-prune log names returned id" "$LOG_OUT" "$PRUNED_PREFIX"

step "auto-prune — effective_importance varies by importance level"
# imp=5 should have much higher EI than imp=1
OUT_HIGH=$($M --data-dir "$TESTDIR10" gc --threshold 999)
# All non-immune candidates should be imp=1 or 2
TOTAL=$((TOTAL + 1))
IMMUNE_IN_CAND=$(echo "$OUT_HIGH" | jq '[.candidates[] | select(.immune == true)] | length')
if [ "$IMMUNE_IN_CAND" = "0" ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} No immune insights in candidates"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Found $IMMUNE_IN_CAND immune insights in candidates"
fi

step "effective_importance — high imp > low imp"
EI_LOW=$(echo "$OUT_HIGH" | jq '.candidates[0].effective_importance')
EI_CONTEXT=$($M --data-dir "$TESTDIR10" remember --no-diff "Another high imp fact" --cat fact --imp 5 | jq '.effective_importance')
TOTAL=$((TOTAL + 1))
# EI for imp=5 should be > EI for imp=1
LOW_INT=$(echo "$EI_LOW" | awk '{printf "%d", $1 * 1000}')
HIGH_INT=$(echo "$EI_CONTEXT" | awk '{printf "%d", $1 * 1000}')
if [ "$HIGH_INT" -gt "$LOW_INT" ]; then
  PASS=$((PASS + 1))
  echo -e "    ${GREEN}✔${RESET} imp=5 EI ($EI_CONTEXT) > imp=1 EI ($EI_LOW)"
else
  FAIL=$((FAIL + 1))
  echo -e "    ${RED}✘${RESET} Expected imp=5 EI > imp=1 EI (got $EI_CONTEXT vs $EI_LOW)"
fi


# ══════════════════════════════════════════════════════════════════════
banner "Milestone 11: Smart Recall Reranking + Signals"
# ══════════════════════════════════════════════════════════════════════

step "smart recall — --intent override"
OUT=$($M --data-dir "$TESTDIR3" recall "Alpha service" --smart --intent WHY --verbose)
assert_jq "intent is WHY" "$OUT" '.meta.intent' 'WHY'
assert_jq "intent_source is override" "$OUT" '.meta.intent_source' 'override'

step "smart recall — auto-detected intent source"
OUT=$($M --data-dir "$TESTDIR3" recall "why Alpha service routing" --smart --verbose)
assert_jq "intent_source is auto" "$OUT" '.meta.intent_source' 'auto'

step "smart recall — multilingual intent and language-independent override"
while IFS='|' read -r language expected query; do
  OUT=$($M --data-dir "$TESTDIR3" recall "$query" --verbose)
  assert_jq "$language automatic intent" "$OUT" '.meta.intent' "$expected"
  assert_jq "$language automatic source" "$OUT" '.meta.intent_source' 'auto'
  OUT=$($M --data-dir "$TESTDIR3" recall "$query" --intent GENERAL --verbose)
  assert_jq "$language override wins" "$OUT" '.meta.intent' 'GENERAL'
  assert_jq "$language override source" "$OUT" '.meta.intent_source' 'override'
done <<'INTENT_CASES'
Traditional Chinese|WHY|為什麼選擇 Alpha？
Hindi|WHY|हमने Alpha क्यों चुना?
Spanish|WHEN|¿Cuándo elegimos Alpha?
Arabic|ENTITY|ما هو Alpha؟
French|ENTITY|Qu’est-ce que Alpha ?
Bengali|ENTITY|Alpha কী?
Portuguese|WHY|Alpha por quê?
Indonesian|WHEN|Kapan memilih Alpha?
Russian|WHY|Почему выбрали Alpha?
German|ENTITY|Was ist Alpha?
General|GENERAL|Alpha index tuning
Unicode boundary|GENERAL|Alpha কখনো कब्ज যখন
Ambiguous|GENERAL|¿Por qué y cuándo elegimos Alpha?
Mixed conflict|GENERAL|Why Alpha, wann gewählt?
Mixed agreement|WHY|Pourquoi Alpha, why?
INTENT_CASES

step "smart recall — multilingual intent is reported even with no results"
OUT=$($M --data-dir "$TESTDATA/intent-empty" recall "हमने PostgreSQL कब चुना?" --verbose)
assert_jq "empty store temporal intent" "$OUT" '.meta.intent' 'WHEN'
assert_jq "empty store automatic source" "$OUT" '.meta.intent_source' 'auto'
assert_jq "empty store results" "$OUT" '.results | length' '0'
OUT=$($M --data-dir "$TESTDATA/intent-empty" recall "PostgreSQL いつ?" --intent WHEN --verbose)
assert_jq "unsupported form override" "$OUT" '.meta.intent' 'WHEN'
assert_jq "unsupported form override source" "$OUT" '.meta.intent_source' 'override'

step "smart recall — signals metadata present"
OUT=$($M --data-dir "$TESTDIR3" recall "Alpha service routing" --smart --verbose)
FIRST=$(echo "$OUT" | jq '.results[0]')
assert_contains "has signals" "$FIRST" '"signals"'
assert_contains "has keyword signal" "$FIRST" '"keyword"'
assert_contains "has graph signal" "$FIRST" '"graph"'

step "smart recall — meta fields present"
assert_contains "has anchor_count" "$OUT" '"anchor_count"'
assert_contains "has traversed" "$OUT" '"traversed"'
assert_jq_gte "anchor_count >= 1" "$OUT" '.meta.anchor_count' '1'

step "smart recall — invalid intent rejected"
OUT=$($M --data-dir "$TESTDIR3" recall "test" --smart --intent INVALID 2>&1 || true)
assert_contains "rejects invalid intent" "$OUT" "unknown intent"

# ── Report ────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${BOLD}${CYAN}  Results${RESET}"
echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo ""
echo -e "  Total:  ${BOLD}$TOTAL${RESET}"
echo -e "  Passed: ${GREEN}${BOLD}$PASS${RESET}"
if [ "$FAIL" -gt 0 ]; then
  echo -e "  Failed: ${RED}${BOLD}$FAIL${RESET}"
fi
echo ""

if [ "$FAIL" -gt 0 ]; then
  echo -e "  ${RED}${BOLD}FAIL${RESET}"
  exit 1
else
  echo -e "  ${GREEN}${BOLD}ALL PASSED ✔${RESET}"
  exit 0
fi
