# <img src="docs/images/icon.svg" width="44" height="44" alt="" align="top"> dsh-ux-plus

给 DSH Web 对话界面收纳的各种界面小改进。每项功能都有独立开关，位于 **设置 → UX Plus**，切换即时生效。

[![CI](https://github.com/plyflai/dsh-ux-plus/actions/workflows/ci.yml/badge.svg)](https://github.com/plyflai/dsh-ux-plus/actions/workflows/ci.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)

[English](./README.md) · **简体中文**

**当前适配：[DeepSeek Harness 0.2.1-rc.1](https://github.com/deepseek-ai/deepseek-harness/releases/tag/dsh-v0.2.1-rc.1) 的 Web 界面。**

## 0.4.0 新增 — 切走标签页，图标替你看

白鲸 favicon 保持原形，叠上三个信号：

- 白鲸**呼吸**（缓慢渐隐渐显）— 有会话在算
- **绿鲸** — 有跑完的还没打开看
- **橙点闪烁** — 有东西等你点

三个信号互相独立、可同时出现；没事时保持原样。[详见下方](#标签页注意力指示灯)

## 功能

| 功能 | 做什么 | 预览 |
| --- | --- | --- |
| 标签页注意力指示灯 | 标签页图标在有事时呼吸、变绿、闪橙点——切走也看得见。 | — |
| 最近活动排序 | 正在推进的会话收进一块淡绿底 Active 区（带状态点）；历史整体藏在区下面，入口是宿主的【展开其余 N 个会话】；闲置一天的工作区自己收起，悬停显示距今时间。 | <img src="docs/images/recency-folded.png" width="200" alt="Active 区与钉在下方的展开按钮"> |
| 对话字号与宽度 | 给对话区选舒服的字号和阅读宽度，不用放大整个界面。 | <img src="docs/images/typography.png" width="300" alt="对话区渲染效果"> |
| 复制会话 ID | 会话菜单一键复制会话 ID，用于 `--session` 续接、定位记录。 | <img src="docs/images/session-menu.png" width="200" alt="会话三点菜单"> |
| 继承对话 | 在会话菜单里选个模型：同工作区开新会话，读完旧对话接着推进。 | <img src="docs/images/inherit-picker.png" width="200" alt="继承对话的模型选择浮层"> |
| 提问结果默认展开 | 提问结束后问题和答案保持展开，回看少一次点击。 | — |

## 功能详解

### 标签页注意力指示灯

图标仍是宿主的白鲸——本功能只在有事时给它上色、让它呼吸、或加一颗点。

| 标签页在说 | 含义 |
| --- | --- |
| 白鲸**呼吸**（缓慢渐隐渐显） | 任意被统计的会话在计算 |
| **绿鲸** | 有跑完的会话还没被打开——与工作区列表的绿点严格一致 |
| **橙点闪烁** | 有东西在等你点（审批、提问、计划确认） |
| 原样白鲸 | 什么事都没有；宿主图标原样还回去 |

呼吸有 35% 透明度下限、闪烁刻意不对称，后台标签页被节流到约每秒一跳时提醒依然可见；切回标签页的瞬间从可见帧重启周期。子代理与空会话永不点亮标签页。明暗两套主题都保留；染不了色时静默不做事。关掉开关不留残留。

### 最近活动排序

最近聊过的排最前，回到刚才的项目不用翻。只改视觉顺序，宿主的排序设置与数据不动。

**Active 区。** 运行中、或 24 小时内动过的会话，收进一整块连续的淡绿底：26px 紧凑行，行首是状态点——橙色呼吸（等你回复）、蓝色转圈（运行中）、绿色实心（跑完没看）。工作区标题用最多三颗纯色点提示被藏住的注意力，计数在 tooltip 里。

**历史整体隐藏。** 不加自己的折叠行——宿主的【展开其余 N 个会话】就是唯一入口，钉在 Active 块正下方。点一次展开：每一行出现，按钮回到列表最下方，看起来和宿主原生展开一模一样；点【收起】再次折回。

<table><tr>
<td width="50%"><img src="docs/images/recency-folded.png" width="100%" alt="折叠态：Active 块，按钮钉在正下方"></td>
<td width="50%"><img src="docs/images/recency-expanded.png" width="100%" alt="展开态：全部可见，按钮在列表最下方"></td>
</tr></table>

**闲置瘦身。** 超过 24 小时没动的工作区在打开页面时自动收起一次，悬停显示距今时间（刚刚 / N分钟 / N小时 / N天）。有运行中或待回复会话的工作区不会被自动收起。

重排不跟你抢鼠标：指针在列表里或有菜单打开时暂停，而你自己的操作（切视图选项、点展开按钮）在点击当帧直接重绘。行位置带短促滑翔（`prefers-reduced-motion` 下关闭），分区按定时心跳重算（跨过 24 小时线自动入眠），宿主渲染竞态下保持上一次自洽的样子、不闪。

### 对话字号与宽度

对话区默认 14px。在 **设置 → 通用 → 对话区** 单独调大字号、收窄阅读宽度——只作用于会话内容，不改整个界面。

### 会话菜单：复制会话 ID 与继承对话

每个会话行的三点菜单追加两项（在置顶、重命名等原生项之前）：

- **会话 ID** — 一键复制到剪贴板，用于 `--session` 续接、日志定位。
- **继承对话** — 点击位置弹出模型选择浮层。选定后：同工作区新建会话、切到所选模型、投递继承提示词（总结并接着推进，越近的轮次权重越高）、自动跳过去。原会话完全不受影响。适合长会话换更贵的模型收尾、或提供方限流时换条路继续。

### 提问结果默认展开

`ask_user_question` 卡片结束后，问题和答案保持展开——回看决定少一次点击。

### 设置

**设置 → UX Plus**：六项功能独立开关，默认全开，切换即时生效。

![UX Plus 设置页](docs/images/settings.png)

## 安装

需要 Node.js ≥ 22、PATH 中的 pnpm，以及一个 DSH Web profile。

```bash
dsh plugin --profile <name> add github:plyflai/dsh-ux-plus
```

安装后重启该 profile。开关在 **设置 → UX Plus**（默认开启、即时生效）；对话字号和宽度在 **设置 → 通用 → 对话区**。

## 兼容性

- 仅面向 DSH 的 **Web 界面**（浏览器），不适用于终端 TUI。
- 所有功能都挂在宿主公开扩展点上，不修改宿主源码；任何一项都可单独关闭。
- 宿主升级可能调整内部 DOM 与插槽契约；如遇失效请提 issue。

## 开发

```bash
npm install
npm test        # node --test，含构建产物与注入依赖的静态断言
npm run build   # tsdown 产出 lib/client.js（经典脚本，随仓库提交）
```

- 每个功能是一个 `features/<name>/` 私有模块（host + client 两半），在 `src/index.js` 与 `src/switches.js` 的功能清单里注册，不是独立插件。
- 客户端资源打包为单个经典脚本注入 `window.__ModuleLoader__`，外部依赖严格限制在宿主提供的模块种子内，构建脚本会校验。
- 每次推送到 main 会在下方更新记录追加一条，并同步 [CHANGELOG.md](CHANGELOG.md)。

## 更新记录

最近三条；完整历史见 [CHANGELOG.md](CHANGELOG.md)。

- **v0.4.5 · 2026-10-18** — 图标改为贴纸式：去掉背景板，只留鲸鱼 + UX+，白色描边沿整体轮廓走一圈（UX+ 保留自己的白描边）。功能无变化。
- **v0.4.4 · 2026-10-18** — 图标微调：白边改绕整个圆角外形（不再勾 UX+ 字母），README 内联图标加大到 44px。功能无变化。

## License

[MIT](LICENSE) © 2026 plyflai
