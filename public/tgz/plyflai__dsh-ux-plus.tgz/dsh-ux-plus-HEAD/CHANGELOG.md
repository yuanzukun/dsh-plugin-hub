# Changelog

## 0.5.16 — 2026-10-21

Docs only, no source or bundle change.

- 功能表里的预览图从 markdown `![](…)` 换成带 `width="170"` 的 `<img>`，预览列不再按图片原始宽度（560px）撑开。
- 量到的效果（GitHub 的 markdown 样式 + 1012px 容器，headless Chrome 实测）：中间列 270px → 575px，预览列 536px → 160px，表宽不变。
- 只改表格里的 5 张图；「功能详解」里的整幅截图保持原尺寸。
- 两个更新记录各 +1 行（0.5.16）、−1 行（0.5.11）。

## 0.5.15 — 2026-10-21

Docs only, no source or bundle change.

- 功能表的 bullet 收短到「用户能感知到的 UX 关键信息」：删掉呼吸 3.6 秒/35% 下限、橙点 450ms 3 帧、order 50/60、26px 行高、隐藏工作区路径、输入法回车、`--session` 等实现细节与剂量数字。
- 行数不变（7 个功能），bullet 从 51 条收到 27 条；每行只回答「在哪、怎么点、看得见什么、失败什么样」。
- 顺手修掉 0.5.14 引入的一处坏链接：预览图误写成 `~assets/images/…`，改回仓库里真实存在的 `docs/images/…`（中英两版共 5 处），并用脚本核对全部图片路径存在。
- 两个更新记录各 +1 行（0.5.15）、−1 行（0.5.10），保持五条。

## 0.5.14 — 2026-10-21

Docs only, no source or bundle change.

- The Features / 功能 table is rewritten: every one of the seven rows now carries its complete interaction detail as bullets — where the control lives, how it triggers, what states you see, how a failure reads, and what switching the feature off leaves behind.
- Two behaviours that only existed in code are now documented: the newest session floats to the top of its block, and a workspace with running or waiting members moves up to "now".
- Wording checked against the implementation: the quick-search model list is flat with `provider · model` on each row (not grouped), and the two session-menu items register at order 50 and 60, ahead of the host's pin (100) and rename (200).
- Both update logs gained the v0.5.14 bullet and dropped v0.5.9, keeping five entries newest-first.

## 0.5.13 — 2026-10-20

Docs only.

- Both README update logs are sorted by version — strictly newest-first — again: the 0.5.8 through 0.5.12 bullets had been appended underneath 0.5.1 (the anchor for each edit was the first bullet it found, not the top of the list), which left the log reading 0.5.7 → 0.5.6 → … → 0.5.1 → 0.5.12 → … → 0.5.8 → 0.5.0.
- The README log now lists only the five most recent entries, newest first; everything older lives in this CHANGELOG. Its intro line says so instead of the old "three most recent entries".
- `npm test` 137/137, `npm run build` unchanged, no source or bundle change.

## 0.5.12 — 2026-10-20

- The running ring (a 15px circle carrying the number of live search sessions) is replaced by a chat bubble: one 14px outline icon in the same 20px slot, no digits, so the glyph never changes shape or width under the pointer.
- Both states come from one node: the bubble outline is always drawn, the filled dot (`data-qs="run-dot"`) is hidden while nothing runs and blinks gently (`ux-plus-qs-blink`, disabled under `prefers-reduced-motion: reduce`) while a search is live. `data-state` still drives the color — tertiary when idle, primary while running.
- A click is unchanged in meaning: it opens the newest session this box started, running or not. The tooltip/aria-label now reads `打开最近的搜索会话：<title>` (plus `（正在运行）` when that session is live) instead of a count.
- `svgIcon()` accepts `{ d, fill, qs }` path specs besides plain strings, so a solid shape and a switchable part can live in the same icon.
- Tests 137/137: the mount case asserts the button/glyph shape, the painted dot and the idle:display-none rule; the behaviour case asserts state + tooltip instead of a count.
- Docs: the feature table row, the paragraph under the typed screenshot and both screenshots were redrawn for the bubble.

## 0.5.11 — 2026-10-20

- 运行环语义改为「我的搜索会话」：候选来源 = 搜索专用工作区的 `sessionIds` + 本实例刚创建还没登记的（`state.extraHidden`）+ 本地历史里的 sessionId，按 `updatedAt` 从新到旧排序；环上的数字 = 其中正在跑的条数（子代理不计）。
- 点击永远打开最新那条，**不再以「是否正在跑」为条件**——答案出来了、会话停了，这一下依旧回得去；0.5.10 把搜索会话整个排除在环外，点下去落在侧边栏的普通会话上。
- 移除 0.5.8 的「2 个以上点开列表」面板（`openRunningPanel`）及其样式与文案；`onRunsClick()` 现在只有一条路径。
- 文案：`runningNone/runningCount/runningTitle` → `ringEmpty/ringOpen/ringRunning`；空态「还没有搜索会话」，有待回会话时「打开最近的搜索会话：<标题>」，有在跑时「{n} 个搜索会话在跑 · 点击回到最近一个」。
- 样式：`cursor: default` 从 `data-state="idle"` 挪到 `aria-disabled="true"`，因此压暗但仍然可点。
- 文档：中英文运行环说明改写；`docs/images/quick-search-running.png` 不再引用（列表已不存在）。
- 测试：两条用例按新语义重写（计数 + 永远回最新 / 只回搜索会话不回普通会话），导航退路用例改为挂在搜索会话上；`tests/workspace-quick-search.test.mjs` 21 条全过，全套 137 条全过。

## 0.5.10 — 2026-10-20

- 修复：运行环会把搜索专用工作区（`~/.dsh-ux-plus/search`）里的会话也算作「正在运行」，点下去就把人带进那个被隐藏的工作区。现在 `runningSessions()` 用 `ownedBySearch()` 过滤三类会话：`state.extraHidden`（本实例刚创建、还没进工作区的）、搜索工作区 `sessionIds` 里的、以及 `cwd` 正好等于搜索目录的。
- 结果：运行环只反映用户在侧边栏能看到的世界；只有搜索任务在跑时环保持压暗状态，点击不会跳到隐藏工作区。
- 测试：新增「运行环忽略搜索专用工作区」用例（工作区成员 / cwd 命中 / 正常会话三种情况），`tests/workspace-quick-search.test.mjs` 21 条全过，全套 137 条全过。

## 0.5.9 — 2026-10-19

- 修复：点击运行环（或历史列表里的某一行）打不开会话时，界面完全没有反应。现在 `openSessionById` 走两条路——先调宿主 `uiWorkspace.openSession`，异常或服务缺失时退回到点击宿主自己的会话行（`[data-row-key="session:<id>"]`）；两条都失败时把原因写进搜索框下方的状态行（`openFailed` = 「打不开这个会话：…」），不再静默。
- 两条入口（历史行、运行环的单个/列表行、回车提交后的跳转）都收敛到同一个 `openSessionById`，行为一致。
- 测试：新增「导航被拒时退回点宿主行」「两条路都不通时状态行报错」两条用例，`node --test tests/workspace-quick-search.test.mjs` 20 条全过，全套 136 条全过。

## 0.5.8 — 2026-10-19

- 搜索框右侧新增「正在运行」环（数字环）：15px 圆环 + 计数，0 时压暗不可点，1 个会话时点一下直接跳过去，2 个以上点开列表（标题 + 距今时间，按最近活动排序）。只数顶层会话，`origin === 'subagent'` 的不计入；数据直接读 `sessions.list` 的 `running` 字段，不额外轮询。
- 几何：圆环放在输入框外面（20px 槽 + 4px 间距），输入框相应收窄 24px；为让提示语仍完整，框内左右内边距 8px → 6px、图标间距 6px → 4px（左右仍对称）。
- 环的状态随会话列表实时刷新（会话开始/结束、切换语言都会重绘）；列表打开期间若运行数降到 1，列表自动关闭。
- 文档：`docs/images/quick-search.png` 与 `quick-search-typed.png` 重画（新几何 + 运行环），新增 `quick-search-running.png`（环显示 3 时的列表）；中英文说明同步。
- 测试：新增「运行环计数 / 单个直接跳 / 多个开列表」用例，`node --test tests/workspace-quick-search.test.mjs` 18 条全过，全套 134 条全过。

## 0.5.7 — 2026-10-19

- 文档重写为「先说卖点」：省掉「先建一个工作区」的交互成本——想到什么直接问、直接搜。首屏新增段、功能表行、功能详解三处开场同一句话，机制细节（回车、隐藏工作区）挪到卖点之后。
- 功能表「预览」列补上 `docs/images/quick-search.png`，与其他已在表中带图的功能一致（此前这一行是 `—`）。
- 英文 README 同步（`the "create a workspace first" step is gone`）。
- 无代码变化。

## 0.5.6 — 2026-10-19

- 提示语文案改为 `直接搜，不用工作区`（英文 `Just search, no workspace`），`placeholder` 与 `aria-label` 同源。
- 取舍：`回车开启新会话` 描述的是机制（回车 / 新会话），`直接搜，不用工作区` 描述的是手感（随手可搜、不必先建工作区）；术语只出现一次且在后半句，读起来不像说明书。
- 斜体 + `opacity: 0.7` 保持不变；测试断言同步改成等值断言。
- 文档：`docs/images/quick-search.png` 与 `quick-search-typed.png` 两张截图（空态 / 输入态），插在「工作区快速搜索」一节；截图是静态重建的界面，不含任何本机路径、账号或真实会话内容。

## 0.5.5 — 2026-10-19

- 提示语改为单句 `回车开启新会话`（英文 `Press Enter to start a new session`）：去掉 `搜索…` 前缀与括号说明，`placeholder` 与 `aria-label` 同源。
- 提示语样式：`[data-qs="input"]::placeholder` 增加 `font-style: italic` 与 `opacity: 0.7`，与宿主其他控件的中性占位提示区分开，输入内容后对比更明显。
- 测试：占位断言由 `includes('搜索')` 改成等值断言，并新增斜体 / 透明度两条样式断言。

## 0.5.4 — 2026-10-19

- 外框不再左右各留 8px：`boxCss()` 里 `[data-dsh-ux-plus="quick-search"][data-ux-plus-instance]` 的 `padding` 由 `6px 8px` 改成 `6px var(--dsh-session-list-edge-inset, 12px) 6px 0`。宿主的 `.regionArea`（`margin-left:-4px / padding-left:4px / margin-right:-12px`）本来就是非对称的，搜索框作为它的第一个子元素，对称内边距只会让左边缘比会话行深 8px、右边缘比【工作区】控件横冲出去 4px —— 这就是「左侧多出一块空白」。
- 框内几何不变：`[data-qs="field"]` 仍是 `padding: 0 8px`、三枚图标同为 22px 槽，两端视觉留白各 13px（含 1px 边框）。
- 验证：用宿主真实 CSS 变量（`--dsh-sidebar-inline-padding:12px`、`--dsh-session-list-edge-inset`、`.regionArea`/`.browser`/`.list`/`.row` 的边距）搭了一个静态侧边栏，无头 Chrome 量到 fieldLeft−rowLeft = 0.0、fieldRight−headerPillRight = 0.0、左右 gutter 各 13.0px。
- 测试：新增一条断言，要求外框的 `padding` 以宿主变量取右侧内边距、左侧为 0。

## 0.5.3 — 2026-10-19

- 快速搜索的样式规则按实例 token 收窄：`boxCss()` 的 `scope` / `menu` 选择器由 `[data-dsh-ux-plus="…"]` 改成 `[data-dsh-ux-plus="…"][data-ux-plus-instance]`，旧 bundle 的样式表即使更晚插入、与我们的规则同权重，也无法再改到新框的内边距与图标槽（此前只有前端节点带 token，样式仍是裸属性选择器）。
- 隐藏旧框的那条规则保持裸选择器 `:not([data-ux-plus-instance])`，并补注释说明为什么只有它不收紧：它必须能匹配到没有我们 token 的残留节点。
- 验证：无头 Chrome 里故意把 0.5.1 的样式表追加在末尾，量到 `paddingLeft: 8px`、左右 gutter 13px / 13px；测试新增一条断言「我们的几何规则带实例 token」。

## 0.5.2 — 2026-10-19

- 左右 gutter 对称：`[data-qs="field"]` 的内边距由 `0 4px 0 8px` 改成 `0 8px`，放大镜的槽由 16px 改成 22px —— 与右侧模型/历史图标同为 22px 槽、同为 8px 内边距，两端视觉留白一致。
- 不再出现两个搜索框：每个 bundle 实例生成一次性 `INSTANCE_TOKEN`，写在自己创建的框与两个弹窗上（`data-ux-plus-instance`）；样式表内 `[data-ux-plus-instance]` 缺省即 `display: none !important`，于是被热替换掉的旧实例留在 DOM 里的框只会被隐藏 —— 隐藏而非删除，避免与仍存活的旧实例互相抢插。整页刷新会彻底清掉残留节点。
- 测试：挂载用例新增三条断言（框带实例 token、样式表含旧框隐藏规则、左右图标槽宽度与两端内边距相等）。

## 0.5.1 — 2026-10-19

- 模型选择器收成一枚小图标（芯片，无文字）：点开是自己的模型菜单，当前项打勾、每行带 `provider · model` 次要信息；选了非默认模型时图标右下角出现小圆点，悬停提示里带模型名。菜单与历史弹窗共用锚定、外点关闭、Esc 关闭与 resize 重定位逻辑，同一图标再点一次收起。
- 搜索框对齐修正：图标统一成 `display: block` 的 16/14px 方块，按钮命中区 22×22，输入框 `align-self: stretch` + 固定行高，整条控制行按几何居中（不再受文字基线与原生下拉高度影响）；容器加 `box-sizing: border-box; width: 100%` 并左右对称内边距。
- 回车即搜的根因修复：`remote.$host.home` 要到连接的第一个 ready 帧才有值，而原实现在挂载时读一次，ready 帧晚到就让搜索框永久报「找不到主目录」。现在目录按需解析（`searchDir()`），隐藏工作区的 CSS 每轮调度重算且只在文本变化时写入样式表，连接就绪后回车直接搜索。
- 测试：模型菜单用例改写（图标结构、打勾、二次点击收起、只写一次 `selectModel`、重挂载保留选择），新增「home 迟到」用例；`tests/workspace-quick-search.test.mjs` 17 个用例，全库 133 个通过。
- README 两处说明与实现对齐：模型选择器改为图标入口；回车是单行输入框的直接提交（不再声称 Shift+回车换行，实现从来没有换行能力）。

## 0.5.0 — 2026-10-19

- 新增功能「工作区快速搜索」（`features/workspace-quick-search`）：侧边栏【自动化任务】下方常驻一个搜索框（放大镜在左），回车即用当前模型开一个**普通会话**——同一个聊天界面、同一套宿主行为，只是这个会话落在隐藏工作区里。
- 隐藏工作区：`<主目录>/.dsh-ux-plus/search`，包宿主半体首次使用时 `mkdirSync` 建好，浏览器半体再 `workspaces.create({path})` 注册；客户端按路径过滤，隐藏工作区的分组头与其中会话行都不渲染，当前会话所在分组也不会因此被强制展开。
- 模型选择器：极小下拉，只列模型名（provider 归组不进标签），不改就用宿主默认；选中值记在 `localStorage`，同一会话内只 `selectModel` 一次。
- 历史：右侧时钟图标开弹窗，最近 50 次搜索（按会话去重、最新在前、带相对时间），点一条回到那次会话；失效会话在打开弹窗时被剪掉，可一键清空。
- 侧边栏收成窄栏（rail，没有 `[role="tree"]`）时整个搜索框不渲染，展开后自动回来；开关关闭时隐藏工作区的 CSS 同步撤除，那些会话立刻回到侧边栏。
- 新增 16 个测试（`tests/workspace-quick-search.test.mjs`）与 `tests/temp-home.mjs` 辅助；`tests/switches.test.mjs` 的冻结列表升到 7 项。

## 0.4.5 — 2026-10-18

- 图标改为贴纸式（die-cut）：去掉圆角背景板，透明底，只留黑鲸 + 黑 UX+；白色描边沿「鲸鱼+UX+」整体轮廓走一圈（30px，鲸鱼组内按 scale 折算），UX+ 保留自己的白描边（14px）与鲸鱼分离。
- 功能无变化。

## 0.4.4 — 2026-10-18

- 图标微调：去掉 UX+ 字母上的浅色描边（白圈），白边改绕整个圆角外形（深色背景下轮廓干净）；README 标题前内联图标 30px → 44px。
- 功能无变化。

## 0.4.3 — 2026-10-18

- 新增项目图标：宿主黑鲸原路径 + 斜体衬线「UX+」压右下角（浅色描边分离），`docs/images/icon.svg`（矢量）与 `icon-512.png`（头像用）入库；README（中英）标题前内联 30px 小图标。
- 功能无变化。

## 0.4.2 — 2026-10-17

- 修复截图主题：Active 块两张截图此前用浅色 token 渲染（暗底黑字）。fixture 的 body 挂上宿主的 `data-ds-dark-theme` 后重拍，标题、时间标、展开按钮全部走宿主暗色主题的真实取值。
- 功能无变化。

## 0.4.1 — 2026-10-17

- 文档重写：README（中英）收紧为「说重点」风格——新功能「标签页注意力指示灯」提到页首，各节删掉机制性铺陈，只留用户可见的行为；更新记录同步瘦身。
- Active 块新增两张截图（折叠态 / 展开态）：真实宿主 CSS + 当前功能模块 + 合成数据渲染，不含任何真实会话数据；删除旧图 idle-collapse.png。
- 功能无变化。

## 0.4.0 — 2026-10-17

- 新功能「标签页注意力指示灯」（`attention-favicon`）：宿主的白鲸 favicon 保持原形，只在有事可说时给它上色、让它呼吸、或加一颗点。三个**互相独立、可同屏**的信号——白鲸**呼吸**（任意会话在算：3.6 秒一条 **20 fps、72 帧余弦**的**渐隐渐显**，不是闪烁）、**绿鲸**（有跑完没看的会话：整条鲸鱼换成绿色）、**橙点快速闪烁**（有东西等你点：审批 / 提问 / 计划确认）。三者可同时出现——「渐隐渐显的绿鲸 + 闪烁橙点」就是「跑完没看 + 等你点 + 还在算」的画面；都没有时覆盖链接直接摘除、宿主图标原样显示。
- 绿鲸与工作区严格一致：favicon 的绿鲸只看宿主的 `completionUnread`——与工作区列表绿点同一个来源，工作区有绿点 favicon 才变绿，本功能不自造影子状态（宿主只把「非当前会话」的完成记为未读，`ui-session` index.ts:489，favicon 跟随同一语义）。
- 闪烁 / 呼吸的机制与抗节流：SMIL 动画在 Chromium 的 SVG favicon 里只渲染首帧、后台标签页的 JS 定时器会被节流到约每分钟一次，因此动画走「定时器切换预烘 SVG data URL」这条路：单个 50 ms（20 fps）定时器驱动两个周期——呼吸是每 tick 一帧的余弦采样（相邻帧差 ≤ 0.03，看着是呼吸不是闪），闪烁每 3 tick 换一帧、保持 450 ms 的三帧亮两帧节奏，透明度有 35% 的下限——无论节流把定时器冻在哪一帧，提醒都仍然可见。帧按（染色, 透明度, 点）三元组惰性构建并缓存，72×3 的组合不预先付费。
- 呼吸只数「在算且没等你点」的会话：宿主的 agent 状态只有 idle/running 两值，ask_user / 审批挂起时 step 的 promise 未落地、相位仍是 running（`packages/core/agent-loop/src/agent.ts:141`），所以「等你点」的会话在宿主事实里就是 running——本功能把它从呼吸里剔除，等待只由橙点表达，白鲸不替它呼吸。
- 节流冻结与恢复：后台标签页的定时器会被 Chrome 钳到约每秒一跳。橙点在后台**每跳换一帧**（亮 2 秒灭 1 秒——慢而稳定，冻住的帧仍有 2/3 概率是亮帧），前台节奏不变（450 ms）。恢复只发生在真正的 hidden→visible **边沿**：某些环境会反复派发 spurious 的 visible 事件，若每个事件都重置周期，闪烁就被钉死在亮帧（用户报告「前台静止橙点」的直接原因）。dispose 同时摘掉该监听。
- 子代理与空会话一律不计入（沿用 `workspace-recency-order` 的过滤），一堆并发子代理不会把白鲸永久染橙。宿主 favicon 的明暗两套（`/favicon.svg` 黑鲸 / `/favicon-dark.svg` 白鲸）都保留，覆盖链接带同样的 `prefers-color-scheme` media，绿鲸染的是当前主题那条鲸；读不到图标文件、或鲸鱼路径上没有可接管的十六进制填充（绿鲸信号会静默失效）则整个功能静默不做事。关掉开关即停定时器、摘覆盖链接、退订，不留残留。
- 修复：点击【N 条历史会话】之后列表会**闪烁一下**（用户报告）。根因是宿主 `AnimatedRows` 的入场动画：每次 commit 后，进入的行淡入 100ms、被移动的行用 WAAPI transform 滑翔 200ms（`AnimatedRows.tsx:5-6`），而本功能「回答这次点击」的重绘恰好落在 commit 当口——动画进行中改写行高与 order，宿主滑翔的终点因此失准；后续重绘的内联 FLIP transform 又与宿主的 WAAPI transform 抢同一个属性（WAAPI 压过内联值，动画一结束内联值整段砸落）。现在回答点击的那次重绘**等宿主滑翔落定**再化妆（`HOST_GLIDE_MS` 220ms；展开本身宿主已渲染上屏，等的只是装饰），也不在滑翔中做 FLIP。
- 折叠细条**整个退役**（用户决定：那根横线多余——复用宿主自己的【展开其余 x 个会话】就够了）。删掉本功能注入的细条（`ensureFoldBar`/`barLine`/`foldBarText` 等约 200 行），折叠改由宿主的展开按钮全权代言：有 Active 块**且宿主放出了这个按钮**的工作区，休眠行整体 `display:none` 收起（行仍在 DOM、rank 照排），按钮钉在 Active 块正下方（rank 槽留在两块之间，Active 里有几条都钉得住）——**点第一次之前只看得到 Active 块**（宿主 5 条配额渲染出的休眠行不再从按钮下面漏出来，用户截图报告的那条「1 天」即此）。按钮点击经 `markUserActionOn`（WeakSet 每元素一次）做两件事：按点击当口的 `aria-expanded` **开合**本工作区（false=展开：记入 revealed——页面级 Set，不持久化；true=宿主的【收起】：移出 revealed，下一次重绘重新折叠）并标记用户操作——回答它的重绘因此穿透防打扰暂停、等宿主滑翔落定（上一条机制），展开后**永不把刚渲染的行折回**（增量展开中途 `aria-expanded` 仍为 false，跟着它当场折回正是此前「点了又退回去」的根因）。展开态同时把按钮放回宿主原生的末位（所有会话最下方）——钉位只属于折叠态，展开后的列表看起来和宿主原生展开一模一样；没有 Active 块、或宿主没有放出按钮（小工作区全量渲染）则完全不折叠——没有控件就没有找回行的路。此前用户报告的「点了又退回去 / 要点两次 / 和【展开】冲突」三个问题随细条一并消失——同一时刻列表尾部只有一个控件。
- 适配宿主 0.2.1-rc.1 的**水位线截断模型**（用户报告：带运行中会话的工作区绿底消失、折叠的历史从按钮下面自己冒出来）。宿主换了列表截断的实现：不再是「运行中行豁免 + 5 条 idle 配额」，而是 **watermark**——blank 行恒显，前 `watermark` 条非 blank 行显示（**运行中行同样消耗水位**），基线 = max(5, 前 50 条里最靠后的注意行（运行 / 子代理运行 / 等待 / 未读完成 / 当前）)，用户每次点【展开】+5（`WorkspaceBrowser.tsx:55-105, 640-660`）。本功能的截断复算还停在旧模型：凡有运行中行的工作区都复算出比 DOM 多一行的切片 → 计数门失配 → 漂移交还宿主——而交还正是「拆绿底 + 还原 display」，两个症状同时出现。现在复算改为水位线模型，且**水位直接从 DOM 反推**（`watermark = domCount - blank`）：基线抬升、用户点击、宿主内部状态全都收敛成 DOM 已经报出的一个数，复算切片与 DOM 恒等；旧的「必须是 5 的倍数」漂移判据随之删除（新宿主下它只会误伤），漂移检测改由「DOM 行数多于 store 能解释的行数」与配对信任检查承担（0.3.2 的竞态保护语义不变）。`rowExempt` / `runningChildCount` / `COLLAPSED_SESSION_LIMIT` 随旧模型删除。
- 测试：`tests/attention-favicon.test.mjs` 覆盖纯层模型（三层独立、混合也呼吸、**等待不呼吸**——running+pending 只亮橙点、一等待一计算仍呼吸、子代理过滤）、帧周期（余弦平滑：72 帧、相邻帧差 ≤ 0.03、35% 下限、前半程单调渐隐；闪烁 450 ms / 2/3 占空比）、纯帧构建（绿鲸接管路径填充且不动根标签、呼吸组只包鲸鱼不包点、无可染色填充的底图拒绝、非法底图拒绝）与假 DOM 下的客户端（明暗双链接、50ms 单定时器驱动双周期、静止绿鲸不起定时器、等待会话只闪橙点白鲸不动、切回标签页从亮帧恢复、spurious visible 事件不重置周期、后台每 tick 换一帧、工作区一致性——当前会话跑完但未读标志为假时什么都不亮、底图不可染色与取图失败都降级为空操作、dispose 无残留）。`tests/recency-order.test.mjs` 改写：宿主按钮钉在 Active 块正下方且休眠行整体收起（块增大 pin 跟随、转 Active 的行离开折叠、点击揭示并在后续重绘里保持展开）、没有宿主按钮的工作区一行都不藏、全休眠工作区按钮留原生末位（出现 Active 后钉位且行收起）、宿主按钮点击穿透暂停（React 式 stub：点击渲染新行、零 store 信号，当次重绘就上新行 rank 并揭示折叠块）、回答宿主展开的重绘延迟 220ms 而环境重绘保持 0ms、增量截断宿主上第一次点击展开后不回弹且 pin 全程不位移、漂移交还宿主时按钮不再被隐藏。水位线适配：运行中行消耗水位的两个生产形态（运行中 + 4 休眠：绿底与折叠同时保住；运行中 + 4 Active：整块带底、无折叠、按钮钉块底）、漂移夹具改为「store 叫不出名字的幽灵行」（已知成员的尾行追加在新模型下正是宿主的正常增长，不再是漂移）、fail-closed 用例改为 DOM 多于 store。`tests/switches.test.mjs`、`tests/patch.test.mjs` 的冻结清单加入 `attention-favicon`。`npm test` 116 项全绿，`npm run build` 通过 R10 产物门。

## 0.3.2 — 2026-10-16

- 修复：Active 区的淡绿底会在使用过程中突然消失（用户报告「绿色的效果没了」）。根因两条。① 会话行的数量校验：某次重绘里 DOM 的行数与本功能的复算结果对不上时（宿主先渲染出新行、store 稍后才发布，或本功能对「豁免行」的建模与宿主不一致），`orderRows` 会放弃这一层，交给 `absorbHostTruncation` 收尾，而收尾会 detach 掉整块绿底、却保留全部行内样式（26px 紧凑行框、状态点、order）——所以用户看到的正是「只有绿底没了」。② 防打扰暂停把它变成了永久：补算的重绘在指针停留于列表内时被推迟，两个有上限的重试定时器本身也是环境重绘、同样被推迟，于是绿底要等 pointerout 才回来。
- 修复：暂停有了寿命。两次重试用完之后，即使指针仍在列表内、也没有任何外部信号，重绘也会照常执行一次（走强制路径、不带 FLIP）。额度只由「暂停解除」刷新，不由此前那次穿透重绘刷新——否则每次重绘都会重新武装两次重试，在指针停留期间变成每约 1.5 秒一次的无休止重绘。
- 修复：宿主「先渲染、数据后到」的短暂竞态不再拆除 Active 区。工作区在连续 3 次（`DRIFT_GRACE_PASSES`）解释不了行数的重绘里保持上一次自洽的样子——底色、折叠、顺序一起保留，只有超过宽限仍对不上的形态才走原来的「交还宿主」路径。
- 测试三条（`tests/recency-order.test.mjs`）：短暂漂移保住绿底、持续漂移仍交还宿主、暂停寿命耗尽后补算且额度不被穿透重绘重新武装；三条在修复前失败。真实 Chromium + 宿主真实 CSS 的探针（`/tmp/uxplus-probe/probe5.mjs`）复现并验证：修复前 drift 那一刻 band 为 null（行仍是 26px 紧凑行框），修复后 band 稳定 26px，指针停留、重试耗尽后依然如此。

## 0.3.1 — 2026-10-16

- 修复：指针停在会话树内时点击「N 条历史会话」细条没有反应。细条点击会先把这次操作记成用户操作（`USER_ACTION_MS = 1000` 窗口），此后窗口内的重绘不再被防打扰暂停拦下——展开 / 收起与点击同帧生效。宿主自带「展开其余 N 个会话」按钮被本功能接管时，点击仍代理给宿主按钮，宿主重渲染会再触发一次重绘，窗口保证那一次也能跑完，两侧状态因此收敛一致（细条只在宿主按钮确实不存在时才由本功能自己开合）。
- 防打扰暂停不再自锁：被推迟的重绘改由两个有上限的定时器兜底重试（`DEFER_RETRY_MS = [300, 1200]`，各自最多一次），此前只要指针停在列表里又没有后续事件，被推迟的重绘就永远等不到补算。命中上限后 `dirty` 标记仍保留，指针离开、菜单关闭或下一次数据 / 视图信号到来时照常补算。
- 切换宿主的视图选项（分组方式 / 排序方式 / 筛选会话）同样穿透暂停：视图签名变化时强制重排且不带 FLIP，重绘与点击同帧。
- 回归测试两条（`tests/recency-order.test.mjs`）：「指针在树内时点细条必须展开」与「冻结期间点细条走宿主代理路径时，宿主自己的 `aria-expanded` 翻转也要被后续重绘采纳」。两条在 0.3.0 的代码上都失败、修复后通过；另用真实 Chromium + 宿主真实 CSS 的探针复现并验证：修复前真实 hover + click 之后休眠行仍是 `display: none`、细条仍显示「2 条历史会话」，修复后行恢复、细条变「收起历史会话」且 `aria-expanded=true`。

## 0.3.0 — 2026-10-15

- 「最近活动排序」的分层模型重写为**分区模型**：唯一判据是最后活动时间——正在运行、或 24 小时内有过活动的会话组成 **Active 区**（区内按活动时间倒序，整块带连续淡绿底、首尾行圆角），其余全部进入**休眠区**。等待回复 / 未读超过 24 小时不再永久钉顶：它们和普通会话一样按时入眠。Active 区靠底色与状态点区分，不再靠把行撑高。
- **会话行统一改紧凑**：所有会话行都写成同一个 26px 行框（`height` 26px + `box-sizing: border-box`、上下 1px / 左右内容 6px 内边距、4px 行距），标题 13px / 行高 18px、时间标 10px / 行高 14px，比宿主的 32px / 14px 更紧，长列表读起来像侧栏而不是一叠卡片。休眠行共用同一行框、只补约 0.5 透明度；归档行保持宿主原样（不写紧凑值），因为归档行必须能撑出这个行框。所有写入的属性都经样式缓存逐项还原，`dispose()` 后宿主 32px / 14px / 6px 行距原样回来。
- 行首状态点取代一切文字状态：待回复 = 橙色实心点 + 2 秒呼吸光晕；运行中 = 蓝色圆环 spinner（旋转）；未读 = 绿色实心点；无状态 = 无点。每颗点都带 `title` 与 `aria-label`（跟随界面语言：待回复 / 运行中 / 未读 ↔ waiting / running / unread）。宿主自绘的状态点在同一行会被隐藏，不会出现两颗点；未读压矮行高的「微缩行」删除。
- 休眠区默认收起成一条细条：居中文字「N 条历史会话」+ 两侧 1px 细线（本功能唯一保留的文字）。点击一次展开整块——同样的 26px 紧凑行框、整行约 0.5 透明度、每行各自保留状态点；展开后的行不会自己回到 Active 区，除非它真的产生了新活动。宿主自带的「展开其余 N 个会话」由同一根细条接管：它藏起来的条数并入细条计数，按钮隐藏。
- 工作区标题徽章改为**纯色点**：Active 区内有待回复 / 未读 / 运行中时，最多三颗 7px 圆点并排（橙 / 绿 / 蓝），计数文本保留在 `title` 与 `aria-label`（如「2 待回复 · 1 未读」）。休眠区的状态永不上浮——只有 Active 区参与徽章。
- 时间标改为**悬停显示**：注入保留、默认透明，行悬停时经样式表淡入，菜单打开时让位给操作按钮。分区在数据变更之外还跟随 60 秒心跳重算一次（覆盖 5 分钟的休眠区重判要求），跨区移动照旧走 180ms FLIP，悬停 / 菜单冻结照旧生效。
- 修复 FLIP 动画残留：真实浏览器里 `setTimeout(0)` 会抢在下一帧（最长约 16ms）之前，因此一次重排常常落在「动画开始」与「释放帧」之间——那次重排把行贴回静止位、同时把该行移出动画集合，而随后执行的释放帧仍会无条件写回 inline `transition`，留下一个任何重排、任何 `dispose()` 都不会再回收的属性。释放帧现在以「是否仍在动画集合内」作为所有权判据，被抢走的行一律不写。（同一现象在 jsdom 里时序不同，已按真实顺序补测试。）
- 保留不变：工作区 24 小时空闲自动收起、会话状态服务缺失时降级为纯时间排序（此时无分区、无状态点、无细条）、`dispose()` 全量还原（状态点、细条、徽章、分区属性、样式表与全部监听）。无新增依赖。

## 0.2.0 — 2026-10-15

- 「最近活动排序」升级为**活跃度排序**：会话行不再只按时间排，先按注意力状态分层——等待回复（橘点）与正在运行（转圈）的会话钉在分组顶部，未读完成的会话（绿点）其次，当前会话钉在「最近」区顶部；有运行中 / 等待回复会话的工作区，其分组也会相应上浮。超过 7 天未读的会话视觉变暗（只变颜色、不换位），绿点永不因时间流逝自动消失——「未读」是事实，不是待办。
- 沉睡会话自动瘦身：组内超过 7 天没有活动的会话渲染为紧凑行（小字号、矮行高），第 4 条起折叠进「折叠更早 · N 条 · 最近时间」一行，点击一次全部展开；展开后同一页面内不再重新折叠。
- 注意力冒泡：需要关注的会话被宿主收起、5 条限额或本功能折叠藏住时，工作区行右侧出现计数徽标（如「2 待回复 · 1 未读」），可见后自动消失；有运行中或等待回复会话的工作区不再被闲置自动收起。
- 交互保护：鼠标停在会话树内或有菜单打开时暂停重排（推迟、不丢弃）；行位置变化带 180ms FLIP 过渡（`prefers-reduced-motion` 下自动关闭）；工作区分组排序带迟滞（活动差距超过 5 分钟才换序），沉睡行不会因「刚被读过」弹回顶部。
- 实现仍全部走 CSS 与 DOM 样式写入，不碰宿主数据与 store；会话状态服务不可用时自动降级为纯时间排序。全部行为挂在「最近活动排序」同一个开关下，关闭即无痕。

## 0.1.7 — 2026-10-14

- README 改版：英文版（`README.md`）为主文档，中文版拆分为 `README.zh-CN.md`，两份文档顶部互设语言链接；功能案例图并入功能表格的「预览」列；更新记录只保留最近三条，其余指向本文件。

## 0.1.6 — 2026-10-14

- 「闲置工作区收起」不再是独立功能，并入「最近活动排序」（`workspace-recency-order`）：24 小时无活动自动收起与距今未更新时间标共用排序的同一开关、同一活动口径、同一套调度（观察器 / 订阅 / 60s 定时）；`workspace-idle-collapse` 功能与其开关移除，设置页回到五项。行为不变：每个工作区每次页面加载最多自动收起一次、手动展开后不再收起、无活动信号不打标不收起、时间标跟随语言与主题。

## 0.1.5 — 2026-10-14

- 新增「闲置工作区收起」：工作区超过 24 小时没有实际活动（空会话与子代理会话不算，与「最近活动排序」同一活动口径）就在打开页面时自动收起一次——每个工作区每次页面加载最多自动收起一次，手动重新展开后不再被收起。同时每个有活动信号的工作区行右侧显示距今未更新的时间标（刚刚 / N分钟 / N小时 / N天 / N个月 / N年），分桶阈值、字号（10px/16px）、颜色（`--dsw-alias-label-tertiary`）与悬停 / 菜单展开时隐藏的行为都对齐宿主会话行时间；文案跟随 DSH 语言，明暗主题自适应。关闭开关即移除全部标签与样式，不留痕迹。

## 0.1.4 — 2026-10-13

- UX Plus 设置页文案跟随 DSH 语言：五个功能行的标题与说明改为中英双语（新增 `ux-plus-settings` 语言命名空间，由每个功能模块自带的 `settingsMessages` 装配），中文界面显示中文、英文界面显示英文，切换语言即时生效，无需刷新。分区名 `UX Plus` 保持品牌名不翻译。

## 0.1.3 — 2026-10-12

- 新增「继承对话」：会话行三点菜单里多一项（排在「会话ID」下方，不覆盖它）。点击弹出模型选择浮层，选定模型后在当前工作区开一个新会话、切到该模型，并投递一条提示词让新会话总结被继承会话的进度（越近轮次注意力越高）。浮层锚定在点击处，支持 Esc、点击外部和右上角关闭；模型列表加载失败或创建失败时保留浮层可重试，重试复用已建好的会话，不重复创建。
- 修复继承对话浮层不跟随浅色主题：面板底色 / 描边此前引用了宿主不存在的 `--dsw-alias-bg-elevated` / `--dsw-border-strong`，永远落到深色兜底色；改用宿主真实存在的 `--dsw-alias-bg-layer-2` / `--dsw-alias-border-l2`，明暗主题都正确，模型行补上悬停高亮。
- README 增加「功能详解」：逐项配界面截图（会话菜单、继承对话浮层、设置页、对话区渲染），并补兼容性说明与开发指引。

## 0.1.2 — 2026-10-12

- 提问展开样式收敛为单层浅蓝：去掉 0.1.1 在外层提问行铺的 20% 通知蓝底（与内层问答卡片叠成两层），只保留问答卡片一层（14% 铺底 + 45% 边框）。问答文字分层：答案与判定保持白色（`label-primary`），原始问题降为 `label-secondary` 并比正文字号小 1px，一眼区分问与答。

## 0.1.1 — 2026-10-11

- 提问块改用通知蓝：自动展开后的问答不再是一片单色灰字——整块铺通知色底（`--dsw-alias-button-info-fill`，随明暗主题切换），问题、答案、标题、摘要用白色，跳过占位与箭头等次要元素用白色弱化档。正在等待回答的那条同样铺蓝底，只是文字保持宿主原样（不打断流光动画）。全部颜色走设计令牌，不写死色值。
- 修复组内会话行排序静默失效：侧栏处于「手动排序」（拖动过一次会话行就会自动进入，宿主 stores.ts:104）或筛选处于「全部对话 / 仅显示已归档」时，插件的行复刻与宿主渲染顺序对不上号，直接放弃写入顺序——表现为正在运行的会话不在最上面、20 天前的旧会话压顶、归档也不改变位置。复刻现已跟随宿主的归档三态、置顶前置分区与手动排序完整规则（含归档沉底与 fork 位置）。
- 修复折叠分组里行排序整段失效：宿主渲染折叠分组时，把「正在运行」以及「子代理在跑」的会话行排除在 5 行配额之外（`rows/WorkspaceBrowser.tsx:55-70`），而配额本身是分组级状态（5、展开更多 +5、全部显示即 Infinity）。旧复刻只豁免空白行、且把配额写死成 5，于是只要分组里有一个正在跑的会话，复刻出的行数就比 DOM 少一行，数量闸门触发后整段行层放弃写入——表现为「正在跑的会话被更旧的会话压顶」。复刻现已跟随宿主的豁免规则（blank / running / 运行中的子代理父行），并从 DOM 反推当前配额（展开过 5→10→… 也对得上）；行数解释不通时仍照旧放弃写入，不做猜测。
- 手动排序模式下插件仍按最近活动排序（用户显式置顶的会话与当前空白会话保留宿主位置），侧栏不再冻结在陈旧位置。
- 行层放弃写入时留下可诊断痕迹：`localStorage.setItem('dsh.ux-plus.recency.debug', '1')` 后重载，控制台按 (分组, 原因, 详情) 去重输出 `[ux-plus:recency]` 一行。

## 0.1.0 — 2026-10-09

- 将对话区字号与宽度、复制会话 ID、工作区最近活动排序整合为一个 DSH 插件。
- 增加提问结束后默认展开问题与答案的功能。
- 在设置最外层增加 UX Plus 入口。功能默认开启，单项开关即时生效并持久化。
- 工作区分组和组内会话按更新时间降序、相同时间按 ID 升序排列。当前未命名的新会话保持首位。
- 修复归档会话让工作区分组下滑的跳动：分组的活动时间不再排除已归档会话，归档或恢复某个对话时外侧文件夹保持原位；组内会话行仍按宿主规则隐藏已归档会话。
- 对话区字号与宽度沿用原 `ui-tweak` 设置 namespace，功能开关使用 `ux-plus` namespace。
- 适配 DeepSeek Harness 0.2.0-rc.1 的配置表单接口，支持功能开关和对话排版设置。
- 分发宿主 ESM 入口和构建后的经典脚本客户端。
- 使用 MIT 许可证，在 GitHub 公开源码、测试与构建配置。

已知限制：紧凑模式中的工具调用组仍需手动展开；部分宿主版本卸载后会保留 profile 中的 `ux-plus` 开关覆盖行。
