/**
 * dsh-ux-plus feature module: Workspace recency order.
 *
 * Frozen feature id `workspace-recency-order`.
 *
 * D5 contract surface (consumed by the package host and client halves):
 *   feature.host(ctx)      -> disposer. No-op for this feature (no host-side
 *                             settings section; the package host registers
 *                             the ux-plus switch instead).
 *   feature.client(ctx, deps) -> disposer. Client-side installation: the
 *                             grouped Workspace tree's visual recency
 *                             ordering — group layer (workspace sections by
 *                             their latest member session activity, freshest
 *                             first; archive-invariant, so archiving a
 *                             conversation never moves its workspace section)
 *                             plus row layer (each section's own
 *                             session rows by session updatedAt). Only the
 *                             visual order changes: React child order,
 *                             host store state (orderBy /
 *                             sessionOrderByAccount) and host data stay
 *                             intact. Same switch, same activity signal:
 *                             the idle sub-behavior additionally collapses
 *                             workspaces idle for over 24 hours (once per
 *                             workspace per page load, through the host's
 *                             own row click handler — the persisted view
 *                             store is never touched) and labels every
 *                             workspace row with its host-styled age
 *                             ("多久没更新"). The disposer restores every
 *                             cached original style, removes all labels and
 *                             the style tag, and removes all
 *                             listeners/observers/subscriptions/timers —
 *                             immediate, no refresh, no residue (off ==
 *                             never installed).
 *   attach / dispose        - host-side installation/uninstallation aliases
 *                             (P1 test surface, retained).
 *
 * deps (client, supplied by the package client half):
 *   sessions   - the soft-fetched sessions service (needs `.list`).
 *   workspaces - the soft-fetched workspaces service (needs `.list`).
 *
 * Both are soft lookups: the package's settings section must never fail to
 * mount because one of them is absent, so a missing (or list-less)
 * dependency degrades this feature to a no-op disposer (no console error,
 * no PAGEERROR).
 *
 * DOM contract (host ui-workspace, read-only facts — plan §2):
 *   - the grouped tree is a role="tree" element whose direct children are
 *     group sections (the host's .groupSection divs); each section's direct
 *     children are, in order: the group header row (role="treeitem"
 *     carrying aria-expanded — possibly nested one span wrapper deep), an
 *     optional role="group" container with nested sections (workspace-tree
 *     mode), the session rows (role="treeitem" without aria-expanded, each
 *     wrapped in one span), and an optional overflow button (the section's
 *     only <button>, "展开更多").
 *   - the tree is found structurally: any role="tree" whose direct children
 *     include a group-section header qualifies. The flat list and the
 *     search tree carry no such headers, so they never match — no section
 *     counting anywhere (the legacy count-and-compare finder is gone).
 *   - rows are matched to sessions by replaying the host's own row projection
 *     and only then pairing positionally (the host exposes no id on row
 *     elements). The replay mirrors the host pipeline exactly, in order:
 *     recency or the reconciled manual order over the account's members
 *     (tree.ts:144-200 — pins, the archive partition and fork placement
 *     included), the current blank pinned first (tree.ts:214-220), the host
 *     visibility filter following the user's archivedFilter
 *     (tree.ts:229-253), then the host section partition that fronts blanks
 *     and non-archived pinned rows (tree.ts:273-287). A count mismatch or a
 *     failed pairing-trust check makes the row layer a no-op for that section
 *     (the group layer is unaffected) and logs one trace line when
 *     `dsh.ux-plus.recency.debug` is on.
 *   - the replay is only how rows get identified. The order this feature
 *     WRITES is recency in both sort modes, except the current blank row and
 *     non-archived pinned rows, which keep the host's rendered positions — so
 *     a sidebar left in 手动排序 (the host flips to it silently on the first
 *     row drag, stores.ts:104) still surfaces the conversation you are in.
 *
 * Route 1 (pure CSS): the tree and every section become flex columns and
 * each child receives a computed `order` (group rank 0..n-1; row rank 10+;
 * overflow button last), with flex-shrink pinned to 0 so single-line rows
 * are never compressed (plan G4). Every written style property is cached on
 * first write and fully restored on dispose (plan W-6).
 */

export const id = 'workspace-recency-order'
export const title = 'Workspace recency order'
export const description = 'Visually reorder workspace groups and their session rows by most recent activity, collapse workspaces idle for 24 hours, and label how long ago each was last active.'
export const hasGear = false
/** Settings-row copy, assembled into the `ux-plus-settings` namespace. */
export const settingsMessages = {
  zh: { title: '最近活动排序', description: '最近聊过的工作区和会话自动排到前面；超过 24 小时没有更新的工作区自动收起（每次打开页面每个工作区最多一次），并在行右侧显示距今未更新的时间标。' },
  en: { title: 'Workspace recency order', description: 'Visually reorder workspace groups and their session rows by most recent activity, collapse workspaces idle for 24 hours, and label how long ago each was last active.' },
}

// ---------------------------------------------------------------------------
// Client-side behavior.
// ---------------------------------------------------------------------------

/** Host collapsed-row limit (rows/WorkspaceBrowser.tsx:44). */
const COLLAPSED_SESSION_LIMIT = 5

/** Descendant-walk depth cap (host nesting: tree > section > group > section). */
const WALK_DEPTH = 8

/** The host's persisted workspace-view store key (ui-workspace stores.ts:64-100). Read-only. */
const VIEW_STORE_KEY = 'dsh.workspace.view.v5'

/** The host's ungrouped-bucket account key (ui-workspace tree.ts:21). */
const UNGROUPED_KEY = ''

/**
 * Row-layer bail-out trace. Off by default (zero console noise); flip with
 * `localStorage.setItem('dsh.ux-plus.recency.debug', '1')` then reload. Each
 * distinct (account, reason, detail) prints once, so a persisting bail-out
 * stays diagnosable without streaming. This exists because the row layer's
 * fail-closed path used to be invisible: a drifted host replay simply meant
 * "the plugin does nothing", indistinguishable from the plugin being disabled.
 */
const TRACE_KEY = 'dsh.ux-plus.recency.debug'
const traceSeen = new Set()

function traceSkip(account, reason, detail) {
  let on = false
  try {
    on = window.localStorage.getItem(TRACE_KEY) === '1'
  } catch {
    return
  }
  if (!on) return
  const signature = `${account}|${reason}|${detail}`
  if (traceSeen.has(signature)) return
  // Bounded: a long-lived session with churning accounts forgets old lines.
  if (traceSeen.size > 200) traceSeen.clear()
  traceSeen.add(signature)
  console.debug(`[ux-plus:recency] row layer off for "${account || 'ungrouped'}": ${reason} (${detail})`)
}

/** Host Windows-path normalization (tree.ts:513-517). */
function folderPath(path) {
  const windows = /^[A-Za-z]:[/\\]/.test(path) || path.startsWith('\\\\')
  return (windows ? path.replaceAll('\\', '/') : path).replace(/\/+$/, '')
}

/**
 * Nearest registered ancestor by host path prefix (host convention,
 * tree.ts:519-538): case-sensitive, longest matching path wins.
 * @returns the owning parent path, or undefined for a root workspace.
 */
function owningParentFolder(path, parents) {
  const child = folderPath(path)
  let owner = undefined
  let length = -1
  for (const parent of parents) {
    const root = folderPath(parent)
    if (root.length > length && child !== root && child.startsWith(`${root}/`)) {
      owner = parent
      length = root.length
    }
  }
  return owner
}

/**
 * Most recent non-blank, non-subagent update in a workspace (the group-layer
 * activity signal; no-update groups carry -Infinity).
 *
 * Archive state is deliberately NOT an input. The host keeps an archived
 * session in its workspace `sessionIds` slot (workspace/src/index.ts:336-339:
 * "Archiving never touches workspace accounting"), so archiving or restoring a
 * conversation leaves this maximum untouched — the workspace section keeps its
 * rank. Excluding archived members instead made the freshest session's
 * archive drop the whole workspace to its next-newest member's timestamp: a
 * jump caused purely by hiding a row, not by any change in activity.
 */
function latestSessionUpdate(workspace, byId) {
  let latest = Number.NEGATIVE_INFINITY
  for (const sessionId of workspace.sessionIds) {
    const session = byId[sessionId]
    if (session === undefined || session.blank || session.origin === 'subagent') continue
    if (session.updatedAt > latest) latest = session.updatedAt
  }
  return latest
}

// ---------------------------------------------------------------------------
// Idle sub-behavior (same switch, same activity signal as the group layer):
//   - a workspace whose latest real activity is older than 24 hours collapses
//     automatically — at most once per workspace per page load, so a manual
//     re-expand is never fought;
//   - every workspace row with real activity carries an age label on its
//     right ("how long since this workspace was last updated"), rendered
//     exactly like the host's session-row time cell (10px/16px,
//     `--dsw-alias-label-tertiary`, hidden while the row is hovered or its
//     menu is open, where the action buttons take the space).
// Workspace rows are the divs carrying `data-row-key="workspace:<id>"`
// (Rows.tsx:245; the group key IS the workspaceId, tree.ts:26-32; the
// ungrouped bucket's key is '' and is skipped). Each row is role="treeitem"
// with aria-expanded and onClick={onToggle} (Rows.tsx:247-248), so a
// programmatic click() toggles the group through the host's own handler —
// this feature never touches the persisted view store.
// ---------------------------------------------------------------------------

/** Idle threshold: no real activity for 24 hours. */
const IDLE_MS = 24 * 60 * 60 * 1000

/** Label refresh cadence on an otherwise idle page (ms). */
const AGE_TICK_MS = 60 * 1000

/** `data-row-key` prefix of workspace rows (Rows.tsx:245). */
const ROW_PREFIX = 'workspace:'

/** Marker attribute carried by the injected label element. */
const LABEL_ATTR = 'data-dsh-ux-plus'
const LABEL_VALUE = 'workspace-age'

/** Host session-time buckets (locales.ts): 60s / 60m / 24h / 30d / 12mo. */
const MINUTE_MS = 60 * 1000
const HOUR_MS = 60 * MINUTE_MS
const DAY_MS = 24 * HOUR_MS
const MONTH_MS = 30 * DAY_MS
const YEAR_MS = 12 * MONTH_MS

/**
 * Host-shaped relative age ("多久没更新" label text).
 * @param {string} locale - active locale id ('zh' prefix wins, else en).
 * @param {number} ageMs - now - latest activity (ms, clamped at 0).
 * @returns {string} label text, e.g. '3小时' / '2d'.
 */
export function ageLabel(locale, ageMs) {
  const age = Math.max(0, ageMs)
  const zh = typeof locale === 'string' && locale.toLowerCase().startsWith('zh')
  if (age < MINUTE_MS) return zh ? '刚刚' : 'now'
  if (age < HOUR_MS) return zh ? `${Math.floor(age / MINUTE_MS)}分钟` : `${Math.floor(age / MINUTE_MS)}m`
  if (age < DAY_MS) return zh ? `${Math.floor(age / HOUR_MS)}小时` : `${Math.floor(age / HOUR_MS)}h`
  if (age < MONTH_MS) return zh ? `${Math.floor(age / DAY_MS)}天` : `${Math.floor(age / DAY_MS)}d`
  if (age < YEAR_MS) return zh ? `${Math.floor(age / MONTH_MS)}个月` : `${Math.floor(age / MONTH_MS)}mo`
  return zh ? `${Math.floor(age / YEAR_MS)}年` : `${Math.floor(age / YEAR_MS)}y`
}

/** The injected age label among a row's direct children, or null. */
function findAgeLabel(row) {
  for (const child of row.children) {
    if (child.dataset && child.dataset.dshUxPlus === LABEL_VALUE) return child
  }
  return null
}

/** The host row's actions span (the label sits before it), or null. */
function findRowActions(row) {
  for (const child of row.children) {
    if (typeof child.className === 'string' && child.className.includes('rowActions')) return child
  }
  return null
}

/** Remove this feature's age label from a row (idempotent). */
function removeAgeLabel(row) {
  const label = findAgeLabel(row)
  if (label !== null) label.remove()
}

/**
 * Host row visibility (tree.ts:229-253 `sessionVisible`): subagent sessions
 * never render; a blank row renders only while it is the current session;
 * archived rows follow the user's archived filter — 'default' hides them,
 * 'show' mixes them into their kept slots, 'only' restricts the list to them.
 * The filter is an input, not a constant: hard-coding 'default' made this
 * replay disagree with the host the moment the sidebar was set to show
 * archives, and the row layer then failed its count check and no-op'd.
 */
function rowVisible(session, id, currentId, archived, archivedFilter) {
  if (session === undefined || session.origin === 'subagent') return false
  if (session.blank === true && id !== currentId) return false
  if (archivedFilter === 'show') return true
  if (archivedFilter === 'only') return archived.has(id)
  return !archived.has(id)
}

/**
 * Host recency projection (tree.ts:144-157): known members newest first,
 * session id as the deterministic tie-break; members without a summary are
 * omitted until theirs arrives.
 */
function orderByRecency(memberIds, byId) {
  const known = []
  for (const id of memberIds) {
    const session = byId[id]
    if (session === undefined) continue
    known.push({ id, updatedAt: session.updatedAt })
  }
  known.sort((a, b) => (a.updatedAt !== b.updatedAt
    ? b.updatedAt - a.updatedAt
    : a.id < b.id ? -1 : 1))
  return known.map((member) => member.id)
}

/**
 * Host manual-order reconciliation (tree.ts:166-200), ported exactly: retained
 * saved slots first, then non-archived pinned members, then the remaining
 * known members by recency, then archived members last; a new fork is spliced
 * in front of its parent. `rowState` carries the registry-global pin and
 * archive sets — omitting them (the historical 3-argument shape) made this
 * replay drop the pin block and the archive partition, so its result no longer
 * matched what the host renders and the row layer silently stopped pairing.
 */
function reconcileManualOrder(memberIds, savedOrder, byId, rowState) {
  const members = new Map(memberIds.map((id) => [id, id]))
  const included = new Set()
  const ordered = []
  for (const key of savedOrder ?? []) {
    const id = members.get(key)
    if (id === undefined || included.has(key)) continue
    ordered.push(id)
    included.add(key)
  }
  const archived = new Set(rowState && rowState.archived ? rowState.archived : [])
  const pins = []
  for (const sessionId of (rowState && rowState.pinned ? rowState.pinned : [])) {
    const id = members.get(sessionId)
    if (id === undefined || included.has(id) || archived.has(id) || byId[id] === undefined) continue
    pins.push(id)
    included.add(id)
  }
  const ordinary = []
  const archives = []
  for (const id of orderByRecency(memberIds.filter((id) => !included.has(id)), byId)) {
    if (archived.has(id)) archives.push(id)
    else ordinary.push(id)
  }
  const result = [...pins, ...ordered, ...ordinary, ...archives]
  const pending = new Set(ordinary)
  const placeFork = (id) => {
    if (!pending.delete(id)) return
    const parentId = byId[id] && byId[id].parentId
    if (parentId === undefined || parentId === id || !result.includes(parentId)) return
    placeFork(parentId)
    result.splice(result.indexOf(id), 1)
    result.splice(result.indexOf(parentId), 0, id)
  }
  for (const id of [...ordinary].reverse()) placeFork(id)
  return result
}

/**
 * Host section partition (tree.ts:273-287 `sectionMembers`), applied AFTER the
 * order projection and the visibility filter: blank placeholders first, then
 * non-archived pinned rows, then the rest in the projected order. The host
 * runs it on every group and flat list, so a section holding a pinned session
 * renders that session ahead of the projected order — replaying without it
 * pairs DOM rows against the wrong sessions.
 */
function sectionPartition(ids, data) {
  const placeholders = []
  const leading = []
  const rest = []
  for (const id of ids) {
    const session = data.byId[id]
    if (session === undefined) continue
    if (session.blank === true) placeholders.push(id)
    else if (!data.archived.has(id) && data.pinned.has(id)) leading.push(id)
    else rest.push(id)
  }
  return [...placeholders, ...leading, ...rest]
}

/**
 * Host blank pinning (tree.ts:194-200): the selected blank row first, no
 * duplicate slot.
 */
function pinCurrentBlank(order, currentBlank) {
  if (currentBlank === undefined) return [...order]
  return [currentBlank, ...order.filter((id) => id !== currentBlank)]
}

/**
 * The live host ordering inputs, read from the host store's own persisted
 * snapshot (read-only, W-2). The host writes the whole workspace-view state
 * to the key on every change (store/src/index.ts:146-166), so it is the live
 * orderBy / sessionOrderByAccount — no subscription needed, and this feature
 * never writes to it. Absent/unreadable state falls back to the host default
 * view (orderBy 'updated').
 */
function readViewStore() {
  try {
    const raw = window.localStorage.getItem(VIEW_STORE_KEY)
    if (raw === null) return null
    const state = JSON.parse(raw)
    if (state === null || typeof state !== 'object') return null
    return state
  } catch (err) {
    return null
  }
}

function viewOrdering() {
  const state = readViewStore()
  // The host's own default when the key is absent or unreadable.
  const archivedFilter = state !== null
    && (state.archivedFilter === 'show' || state.archivedFilter === 'only')
    ? state.archivedFilter
    : 'default'
  if (state === null || state.orderBy !== 'manual') return { orderBy: 'updated', saved: undefined, archivedFilter }
  const saved = state.sessionOrderByAccount
  return {
    orderBy: 'manual',
    saved: saved !== null && typeof saved === 'object' ? saved : undefined,
    archivedFilter,
  }
}

/**
 * The host's actual rendered row order for one section account
 * (WorkspaceBrowser.tsx:804-838 + tree.ts:144-212): the recency or manual
 * projection over the account's members, the current blank pinned first,
 * then the host visibility filter. For the ungrouped bucket this is exactly
 * what the host's double projection (orderedUngrouped over the already
 * projected bucket order) collapses to, because the projected order covers
 * every stray member.
 */
function renderedOrder(memberIds, key, data, view) {
  const byId = data.byId
  const base = view.orderBy === 'manual'
    ? reconcileManualOrder(memberIds, view.saved ? view.saved[key] : undefined, byId,
      { pinned: data.pinned, archived: data.archived })
    : orderByRecency(memberIds, byId)
  const currentBlank = data.currentId !== undefined && memberIds.includes(data.currentId)
    && byId[data.currentId] !== undefined && byId[data.currentId].blank === true
    ? data.currentId
    : undefined
  return sectionPartition(
    pinCurrentBlank(base, currentBlank)
      .filter((id) => rowVisible(byId[id], id, data.currentId, data.archived, view.archivedFilter)),
    data,
  )
}

/**
 * Host row-exemption rule (rows/WorkspaceBrowser.tsx:55-70): a row is exempt
 * from the collapsed idle quota when it is blank, running, or a parent with a
 * running subagent. Only idle rows count against the quota, so a collapsed
 * section renders more than COLLAPSED_SESSION_LIMIT rows whenever it holds a
 * running conversation (1 running + 5 idle is the common shape) — the exact
 * case where a blank-only port replays a shorter slice, trips the count gate
 * and leaves the section's row layer silently off (stale row on top, running
 * session below it).
 */
function rowExempt(session, id, data) {
  return Boolean(session.blank) || Boolean(session.running) || runningChildCount(data, id) > 0
}

/**
 * The host's running-subagent count for one parent row (tree.ts:390-395):
 * the session's `subagentCatalog` projection values, counting children whose
 * live row reports running. The host reads the ui-session status store first
 * and falls back to the list row; this feature owns no statuses service, so
 * it reads the same fallback (`byId[childId].running`). A divergence only
 * lowers the exemption count, which the count gate then fails closed on — it
 * can never paint a wrong order.
 */
function runningChildCount(data, parentId) {
  const projections = data.projectionsBySession
  const catalog = projections !== undefined && projections !== null
    ? projections[parentId]?.values?.subagentCatalog
    : undefined
  if (!Array.isArray(catalog)) return 0
  let count = 0
  for (const child of catalog) {
    const row = data.byId[child.id]
    if (row !== undefined && row.running === true) count += 1
  }
  return count
}

/**
 * The host's collapsed slice (rows/WorkspaceBrowser.tsx:55-70) over the
 * replayed row order: every exempt row keeps its rendered position, and only
 * the first `limit` idle rows survive. `limit` is the host's PER-GROUP React
 * state — 5, then +5 per "展开更多" click, Infinity once nothing is hidden
 * (WorkspaceBrowser.tsx:300/581-601) — so callers must not assume the 5
 * default; collapsedShown derives the live quota from the DOM.
 */
function collapsedRows(ids, data, limit = COLLAPSED_SESSION_LIMIT) {
  let idle = 0
  return ids.filter((id) => {
    if (rowExempt(data.byId[id], id, data)) return true
    if (idle >= limit) return false
    idle += 1
    return true
  })
}

/**
 * The slice the host actually rendered, given the row count the DOM shows.
 *
 * A truncated section renders `totalExempt + limit` rows, so the live quota
 * is derivable: `limit = domCount - exempt`. The host only ever uses 5, 10,
 * 15… (the +5 step) or the whole list, so a count that does not land on a
 * multiple of COLLAPSED_SESSION_LIMIT is drift, not a quota — the default is
 * handed to the count gate, which fails closed instead of guessing.
 *
 * @returns {string[] | null} the slice, or null when the whole group is
 * folded (no rows rendered while the replay expects rows).
 */
function collapsedShown(expected, data, domCount) {
  if (domCount >= expected.length) return expected
  if (domCount === 0) return null
  const exempt = expected.filter((id) => rowExempt(data.byId[id], id, data)).length
  const limit = domCount - exempt
  return collapsedRows(expected, data, limit > 0 && limit % COLLAPSED_SESSION_LIMIT === 0
    ? limit
    : COLLAPSED_SESSION_LIMIT)
}

/**
 * Pairing-trust check before any row order is written (W-2 fallback —
 * "presentation never guesses"): each paired row must confirm the pairing
 * from its own visible text. An ordinary row confirms when one of its LEAF
 * elements (an element with no element children, the row itself included)
 * carries normalized text starting with the session's normalized
 * displayTitle. The host renders the title in its own leaf span (Rows.tsx
 * title span, then the time leaf), so the status badge the host renders in
 * the row's preceding status slot (visually-hidden labels that still land in
 * textContent) no longer breaks the check: a status leaf carries status
 * copy, which does not start with the session's title, and the trailing time
 * leaf cannot confirm either. The row's own whole text (the historical
 * signal, now whitespace-normalized) is an additional confirming source: it
 * keeps rows confirmable when the title text is split across sibling leaves
 * and matches what the host DOM reports for the row wrapper. A blank row
 * renders a localized label this feature cannot know, so it is pinned to its
 * position instead: the host's pinCurrentBlank invariant puts a visible blank
 * row at index 0. Failure boundaries: a row with neither its whole text nor
 * any leaf confirming the title, an empty or non-string displayTitle, or a
 * blank row anywhere but index 0, fails closed (the whole section's row
 * layer no-ops); the check is positional and prefix-anchored (no substring
 * match), so one title prefixing another row's text cannot cross-align.
 */
function pairingTrustworthy(rows, shown, byId) {
  return firstUnpairedRow(rows, shown, byId) === -1
}

/**
 * Index of the first paired row that does not confirm its session, or -1 when
 * every pairing is confirmed. Same rule `pairingTrustworthy` documents; the
 * index exists so a bail-out can say where it broke instead of saying nothing.
 */
function firstUnpairedRow(rows, shown, byId) {
  for (let i = 0; i < shown.length; i += 1) {
    const session = byId[shown[i]]
    if (session === undefined) return i
    if (session.blank === true) {
      if (i !== 0) return i
      continue
    }
    const title = session.displayTitle
    if (typeof title !== 'string' || title === '') return i
    const target = normalizeText(title)
    if (target === '') return i
    if (!rowCarriesTitle(rows[i], target)) return i
  }
  return -1
}

/**
 * True when the row's whole text, or a leaf element (no element children) in
 * its subtree, has normalized text starting with the normalized title. The
 * row's whole text is the historical pairing signal (in the host DOM, the
 * wrapper's textContent is the row's leading text); the leaf walk is what
 * makes host-shaped rows confirmable despite the status badge the host
 * renders before the title — the title span is a leaf, the status leaf is
 * not the title, and the time leaf cannot confirm. Walking element children
 * (not querySelectorAll) keeps this identical for the host DOM and for the
 * plain-object row fixtures in tests.
 */
function rowCarriesTitle(row, target) {
  if (normalizeText(row.textContent).startsWith(target)) return true
  for (const child of row.children) {
    if (leafConfirms(child, target)) return true
  }
  return false
}

/** True when a leaf element (no element children) in the subtree does. */
function leafConfirms(el, target) {
  if (el.children.length === 0) return normalizeText(el.textContent).startsWith(target)
  for (const child of el.children) {
    if (leafConfirms(child, target)) return true
  }
  return false
}

/**
 * The ungrouped bucket's members: every session no workspace claims (host
 * accounting, WorkspaceBrowser.tsx:809-812 — hidden members included).
 */
function ungroupedMembers(data) {
  const owned = new Set()
  for (const workspace of data.items) {
    for (const sessionId of workspace.sessionIds) owned.add(sessionId)
  }
  return Object.keys(data.byId).filter((id) => !owned.has(id))
}

/** A group header row: role="treeitem" carrying aria-expanded. */
function isHeaderRow(element) {
  return element.getAttribute('role') === 'treeitem' && element.hasAttribute('aria-expanded')
}

/** A session row: role="treeitem" without aria-expanded. */
function isSessionRow(element) {
  return element.getAttribute('role') === 'treeitem' && !element.hasAttribute('aria-expanded')
}

/** True when element (or a descendant within WALK_DEPTH) is a group header row. */
function hasHeaderRow(element, depth) {
  if (depth > WALK_DEPTH) return false
  if (isHeaderRow(element)) return true
  for (const child of element.children) {
    if (hasHeaderRow(child, depth + 1)) return true
  }
  return false
}

/** True when element (or a descendant within WALK_DEPTH) is a session row. */
function hasSessionRow(element, depth) {
  if (depth > WALK_DEPTH) return false
  if (isSessionRow(element)) return true
  for (const child of element.children) {
    if (hasSessionRow(child, depth + 1)) return true
  }
  return false
}

/** A group section: a tree child carrying a section header row. */
function isSection(element) {
  return hasHeaderRow(element, 0)
}

/**
 * The section's session-row children (direct children whose subtree is a
 * session row). The host wraps each row in one span, so the styled element
 * is the direct child — that is the flex item receiving `order`.
 */
function rowChildren(section) {
  const rows = []
  for (const child of section.children) {
    if (child.getAttribute('role') === 'group') continue
    if (child.tagName === 'BUTTON') continue
    if (isSection(child)) continue
    if (hasSessionRow(child, 0)) rows.push(child)
  }
  return rows
}

/** The section's nested-group container (<div role="group">), or null. */
function groupContainer(section) {
  for (const child of section.children) {
    if (child.getAttribute('role') === 'group') return child
  }
  return null
}

/** The section's overflow ("展开更多") button, or null while absent. */
function overflowButton(section) {
  for (const child of section.children) {
    if (child.tagName === 'BUTTON') return child
  }
  return null
}

/** The group is collapsed when the overflow button is present and unexpanded. */
function sectionCollapsed(section) {
  const button = overflowButton(section)
  return button !== null && button.getAttribute('aria-expanded') === 'false'
}

/**
 * Style writes with original caching (plan W-6): the first write of a
 * property caches the element's current value; clear() puts every cached
 * original back and forgets all records.
 */
function makeStyleCache() {
  const records = new Map()
  function write(element, property, value) {
    let cached = records.get(element)
    if (cached === undefined) {
      cached = {}
      records.set(element, cached)
    }
    if (cached[property] === undefined) cached[property] = element.style[property]
    element.style[property] = value
  }
  function clear() {
    for (const [element, cached] of records) {
      for (const property of Object.keys(cached)) element.style[property] = cached[property]
    }
    records.clear()
  }
  return { write, clear }
}

/**
 * The ungrouped bucket's activity: latest session owned by no workspace. Same
 * archive-invariance rule as latestSessionUpdate — a stray conversation being
 * archived must not move the bucket either.
 */
function bucketActivity(data) {
  const owned = new Set()
  for (const workspace of data.items) {
    for (const sessionId of workspace.sessionIds) owned.add(sessionId)
  }
  let latest = Number.NEGATIVE_INFINITY
  for (const session of Object.values(data.byId)) {
    if (session.origin === 'subagent' || session.blank) continue
    if (owned.has(session.id)) continue
    if (session.updatedAt > latest) latest = session.updatedAt
  }
  return latest
}

/** A workspace's nested children in host order (workspace-tree mode). */
function childrenOf(workspace, data) {
  const parents = data.items.map((item) => item.path)
  const out = []
  for (const item of data.items) {
    if (owningParentFolder(item.path, parents) === workspace.path) out.push(item)
  }
  return out
}

/**
 * W-2 row layer: the section's own session rows in recency order (same ruler
 * as the host's orderByRecency: updatedAt desc, id asc on ties).
 *
 * Rows are paired after replaying the host's actual row projection (the
 * derived order, not the model's member order — `renderedOrder`) and the host
 * collapse rule; a count mismatch or a failed pairing-trust check makes this
 * section's row layer a no-op (the group layer is unaffected). A bail-out is
 * logged once per distinct reason (`traceSkip`) — silently doing nothing is
 * what let a drifted host replay pass unnoticed in production.
 *
 * The collapse replay is part of that contract: the rendered slice exempts
 * blank, running and running-subagent rows from the idle quota (rowExempt)
 * and uses the group's live quota derived from the DOM (collapsedShown). A
 * blank-only fixed-5 port matched only idle sections; on a section with a
 * running session it replayed one row short, tripped the count gate and left
 * the whole row layer off — the running conversation stayed below a stale
 * one, which is precisely what this feature exists to prevent.
 *
 * Two row classes keep the host's rendered positions instead of being
 * re-ranked: the current blank row (host pinCurrentBlank invariant,
 * tree.ts:214-220) and non-archived pinned rows (host sectionMembers fronts
 * them, tree.ts:273-287). Re-ranking a pin would fight an explicit user
 * action; everything else is ranked by recency, in both sort modes — that is
 * what this feature promises, and it is why a sidebar left in 手动排序 no
 * longer freezes stale positions.
 */
function orderRows(section, account, data, view) {
  const expected = renderedOrder(account.memberIds, account.key, data, view)
  const rows = rowChildren(section)
  const shown = sectionCollapsed(section) ? collapsedShown(expected, data, rows.length) : expected
  // A folded group renders no rows at all: there is nothing to order, and a
  // count trace here would be noise (the group layer still runs).
  if (shown === null) return
  if (rows.length !== shown.length) {
    traceSkip(account.key, 'count', `dom ${rows.length} vs replay ${shown.length}`)
    return
  }
  const unpaired = firstUnpairedRow(rows, shown, data.byId)
  if (unpaired !== -1) {
    traceSkip(account.key, 'pairing', `row ${unpaired} of ${shown.length}`)
    return
  }
  const entries = shown.map((id, index) => ({ session: data.byId[id], element: rows[index] }))
  const leading = []
  const ranked = []
  entries.forEach((entry, index) => {
    const blankFront = index === 0 && entry.session.blank === true
    const pinnedFront = !blankFront && !data.archived.has(entry.session.id)
      && data.pinned.has(entry.session.id)
    if (blankFront || pinnedFront) leading.push(entry)
    else ranked.push(entry)
  })
  ranked.sort((a, b) => b.session.updatedAt - a.session.updatedAt
    || (a.session.id < b.session.id ? -1 : a.session.id > b.session.id ? 1 : 0))
  leading.concat(ranked).forEach((entry, rank) => {
    data.styles.write(entry.element, 'order', String(10 + rank))
    data.styles.write(entry.element, 'flexShrink', '0')
  })
  // The overflow button stays last no matter what.
  const button = overflowButton(section)
  if (button !== null) data.styles.write(button, 'order', '999')
}

/** Collapse whitespace runs and trim (header-text comparison). */
function normalizeText(value) {
  return (typeof value === 'string' ? value : '').replace(/\s+/g, ' ').trim()
}

/** The final segment of a host path (backslashes normalized by folderPath). */
function pathBasename(path) {
  return typeof path === 'string' ? folderPath(path).split('/').pop() : ''
}

/**
 * The section's group header row: the first role="treeitem" carrying
 * aria-expanded in the section's subtree (host DOM contract — possibly one
 * span wrapper deep), or null. Mirrors hasHeaderRow's walk.
 */
function sectionHeaderRow(section, depth) {
  if (depth > WALK_DEPTH) return null
  if (isHeaderRow(section)) return section
  for (const child of section.children) {
    const found = sectionHeaderRow(child, depth + 1)
    if (found !== null) return found
  }
  return null
}

/**
 * Group-layer pairing trust (Q8): a same-count workspace reorder leaves the
 * store snapshot in the new order while the DOM still renders the old
 * section order for one frame, and positional pairing would then pair each
 * section with the wrong workspace. A section's header text is the
 * workspace's title (or its path basename), so the pairing is confirmed only
 * when the header starts with one of those; an empty header text is no
 * signal, not a failure, and a workspace with neither carries no candidate.
 */
function sectionPairingTrusted(section, workspace) {
  const row = sectionHeaderRow(section, 0)
  const text = row === null ? '' : normalizeText(row.textContent)
  if (text === '') return true
  const candidates = [normalizeText(workspace.title), normalizeText(pathBasename(workspace.path))]
    .filter((candidate) => candidate !== '')
  if (candidates.length === 0) return true
  return candidates.some((candidate) => text.startsWith(candidate))
}

/**
 * Order one level: the container's section children (DOM order) are matched
 * to the workspaces at that level (host order; the trailing ungrouped bucket
 * section is the only tolerated extra, top level only), receive their
 * visual rank, their row ordering, and then their nested level. A count
 * mismatch, or a header that cannot confirm its paired workspace, makes the
 * whole level a no-op — presentation never guesses.
 */
function orderLevel(container, workspaces, topLevel, data, view) {
  const sections = []
  for (const child of container.children) {
    if (isSection(child)) sections.push(child)
  }
  const pairs = []
  if (sections.length === workspaces.length) {
    for (let i = 0; i < sections.length; i += 1) {
      pairs.push({ section: sections[i], workspace: workspaces[i] })
    }
  } else if (topLevel && sections.length === workspaces.length + 1) {
    for (let i = 0; i < workspaces.length; i += 1) {
      pairs.push({ section: sections[i], workspace: workspaces[i] })
    }
    pairs.push({ section: sections[sections.length - 1], workspace: null }) // ungrouped bucket
  } else {
    return
  }
  // Q8 gate: a same-count workspace reorder can leave the store snapshot in
  // the new order while the DOM still renders the old one for one frame, so
  // positional pairing may pair a section with the wrong workspace — every
  // non-bucket pair's header text must confirm its paired workspace
  // (starts with the title or the path basename) or the whole level no-ops
  // without writing a single order (the next pass repaints once the DOM
  // has caught up; an empty header is no signal, never a failure).
  for (const pair of pairs) {
    if (pair.workspace !== null && !sectionPairingTrusted(pair.section, pair.workspace)) return
  }
  // W-1 group layer: freshest activity first, no-activity last, ties keep
  // the host's existing order (stable sort on the original index).
  const ranked = pairs.map((pair, index) => ({
    section: pair.section,
    workspace: pair.workspace,
    index,
    activity: pair.workspace === null
      ? bucketActivity(data)
      : latestSessionUpdate(pair.workspace, data.byId),
  }))
  ranked.sort((a, b) => {
    if (a.activity === b.activity) return a.index - b.index
    if (a.activity === Number.NEGATIVE_INFINITY) return 1
    if (b.activity === Number.NEGATIVE_INFINITY) return -1
    return b.activity - a.activity
  })
  ranked.forEach((entry, rank) => {
    const { section, workspace } = entry
    data.styles.write(section, 'display', 'flex')
    data.styles.write(section, 'flexDirection', 'column')
    data.styles.write(section, 'flexShrink', '0')
    data.styles.write(section, 'order', String(rank))
    data.styles.write(section, 'marginTop', rank === 0 ? '0px' : '4px')
    // W-2 row layer for every section: workspaces by their own account, the
    // ungrouped bucket by the host's ungrouped account.
    const account = workspace === null
      ? { memberIds: ungroupedMembers(data), key: UNGROUPED_KEY }
      : { memberIds: workspace.sessionIds, key: workspace.workspaceId }
    orderRows(section, account, data, view)
    // Nested level: the group container's sections, same rules, no bucket.
    const containerDiv = groupContainer(section)
    if (containerDiv !== null) {
      data.styles.write(containerDiv, 'display', 'flex')
      data.styles.write(containerDiv, 'flexDirection', 'column')
      data.styles.write(containerDiv, 'flexShrink', '0')
      orderLevel(containerDiv, childrenOf(workspace, data), false, data, view)
    }
  })
}

/**
 * Install the feature's client-side behavior.
 * @param {object} ctx - the client plugin context (unused; contract shape).
 * @param {object} deps - { sessions, workspaces } (see module header).
 * @returns {() => void} disposer: clears the pending timer, disconnects the
 *   observer, unsubscribes both lists, and restores all cached original
 *   styles (off == never installed).
 */
export function client(ctx, deps) {
  const sessionsService = deps && deps.sessions
  const workspacesService = deps && deps.workspaces
  const sessions = sessionsService && sessionsService.list
  const workspaces = workspacesService && workspacesService.list
  if (!sessions || !workspaces
    || typeof sessions.getSnapshot !== 'function' || typeof sessions.subscribe !== 'function'
    || typeof workspaces.getSnapshot !== 'function' || typeof workspaces.subscribe !== 'function') {
    return () => {}
  }

  const styles = makeStyleCache()
  let timer = null
  let ageTimer = null
  let disposed = false
  /** Workspace ids already auto-collapsed during this page load. */
  const collapsedOnce = new Set()

  // Hover/menu dismissal mirroring the host's `.sessionRow:hover .time`
  // rule (Rows.module.css:279-282): the action buttons take the space.
  const styleTag = document.createElement('style')
  styleTag.dataset.dshUxPlus = 'idle-collapse-css'
  styleTag.textContent =
    `[data-row-key^="${ROW_PREFIX}"]:hover > [${LABEL_ATTR}="${LABEL_VALUE}"],`
    + `[data-row-key^="${ROW_PREFIX}"].menuOpen > [${LABEL_ATTR}="${LABEL_VALUE}"] { display: none; }`
  document.head.appendChild(styleTag)

  /** Active locale id for the age labels, defensively ('zh' when absent). */
  function activeLocale() {
    const locale = ctx && ctx.locale
    if (locale && typeof locale.getSnapshot === 'function') {
      try {
        const snapshot = locale.getSnapshot()
        if (snapshot && typeof snapshot.active === 'string') return snapshot.active
      } catch { /* fall through to the default */ }
    }
    return 'zh'
  }

  /** Snapshot the live lists; null while either list is not ready. */
  function readData() {
    const sessionSnapshot = sessions.getSnapshot()
    const workspaceSnapshot = workspaces.getSnapshot()
    if (sessionSnapshot.phase !== 'ready' || workspaceSnapshot.phase !== 'ready') return null
    const byId = sessionSnapshot.byId
    const items = workspaceSnapshot.items
    const archived = new Set(workspaceSnapshot.archivedSessionIds)
    // Registry-global pin set, same snapshot as the archive set
    // (workspace/src/index.ts:731-738; the host reads the very same triple in
    // client/navigation.ts:254). Pinned rows lead their section, so the row
    // replay needs them to pair against what the host renders.
    const pinned = new Set(workspaceSnapshot.pinnedSessionIds ?? [])
    // Mirror the host's current-session lookup (WorkspaceBrowser.tsx:804-808,
    // mainSessionId; the panelActive `current` at :220-224 only drives
    // auto-expand and highlight, never row existence).
    let currentId = undefined
    for (const session of Object.values(byId)) {
      if (session.retainedBy && session.retainedBy.mainView > 0) {
        currentId = session.id
        break
      }
    }
    return {
      byId,
      items,
      archived,
      pinned,
      currentId,
      // Subagent catalogs: the host's running-subagent exemption reads them
      // through the same list snapshot (tree.ts:390-395), so the row replay
      // can mirror it without a statuses service.
      projectionsBySession: sessionSnapshot.projectionsBySession,
      styles,
    }
  }

  /**
   * Locate the grouped tree structurally: a role="tree" whose direct
   * children include group sections. Flat and search trees have no section
   * headers, so they never qualify (no section counting anywhere).
   * @returns {{tree: Element, sections: Element[]}} | null
   */
  function findTree() {
    const trees = document.querySelectorAll('[role="tree"]')
    for (const tree of trees) {
      const sections = []
      for (const child of tree.children) {
        if (isSection(child)) sections.push(child)
      }
      if (sections.length > 0) return { tree, sections }
    }
    return null
  }

  /** One full pass: structural find, then the two-layer reorder. */
  function reorder() {
    const data = readData()
    if (data === null) {
      styles.clear()
      return
    }
    const found = findTree()
    if (found === null) {
      styles.clear()
      return
    }
    const parents = data.items.map((item) => item.path)
    const roots = data.items.filter((item) => owningParentFolder(item.path, parents) === undefined)
    if (found.sections.length !== roots.length && found.sections.length !== roots.length + 1) {
      styles.clear()
      return
    }
    const view = viewOrdering()
    styles.write(found.tree, 'display', 'flex')
    styles.write(found.tree, 'flexDirection', 'column')
    orderLevel(found.tree, roots, true, data, view)
  }

  /**
   * Idle sub-behavior pass: label every workspace row with activity and
   * collapse idle ones once. Independent of the reorder (a bail-out there
   * never suppresses labels here); shares the same debounced schedule.
   */
  function idlePass() {
    const data = readData()
    if (data === null) return
    const rows = document.querySelectorAll(`[data-row-key^="${ROW_PREFIX}"]`)
    const now = Date.now()
    const locale = activeLocale()
    for (const row of rows) {
      const rowKey = row.getAttribute('data-row-key')
      const workspaceId = typeof rowKey === 'string' ? rowKey.slice(ROW_PREFIX.length) : ''
      const workspace = workspaceId === UNGROUPED_KEY
        ? undefined
        : data.items.find((item) => item.workspaceId === workspaceId)
      if (workspace === undefined) { removeAgeLabel(row); continue }
      const latest = latestSessionUpdate(workspace, data.byId)
      if (latest === Number.NEGATIVE_INFINITY) { removeAgeLabel(row); continue }
      const idle = now - latest > IDLE_MS
      let label = findAgeLabel(row)
      if (label === null) {
        label = document.createElement('span')
        label.dataset.dshUxPlus = LABEL_VALUE
        label.style.flex = 'none'
        label.style.fontSize = '10px'
        label.style.lineHeight = '16px'
        label.style.color = 'var(--dsw-alias-label-tertiary, #8a8f98)'
        label.style.pointerEvents = 'none'
        label.style.whiteSpace = 'nowrap'
        const actions = findRowActions(row)
        if (actions !== null && typeof row.insertBefore === 'function') row.insertBefore(label, actions)
        else row.appendChild(label)
      }
      label.textContent = ageLabel(locale, now - latest)
      if (idle && !collapsedOnce.has(workspaceId)) {
        collapsedOnce.add(workspaceId)
        if (row.getAttribute('aria-expanded') === 'true' && typeof row.click === 'function') row.click()
      }
    }
  }

  function schedule() {
    if (disposed || timer !== null) return
    timer = window.setTimeout(function () {
      timer = null
      if (disposed) return
      reorder()
      idlePass()
    }, 0)
  }

  const observer = new MutationObserver(schedule)
  if (document.body !== null) observer.observe(document.body, { childList: true, subtree: true })
  const disposeSessions = sessions.subscribe(schedule)
  const disposeWorkspaces = workspaces.subscribe(schedule)
  const locale = ctx && ctx.locale
  const disposeLocale = locale && typeof locale.subscribe === 'function' ? locale.subscribe(schedule) : null
  // Age labels must age on an otherwise idle page (no store traffic).
  if (typeof window.setInterval === 'function') ageTimer = window.setInterval(schedule, AGE_TICK_MS)
  schedule()

  // No ctx.effect: this feature owns its resources and hands back the exact
  // cleanup (legacy cleanup contract, retained). The package client half
  // holds the disposer; the plugin-level unmount (and each switch-off)
  // calls it.
  return function cleanup() {
    disposed = true
    if (timer !== null) window.clearTimeout(timer)
    if (ageTimer !== null && typeof window.clearInterval === 'function') window.clearInterval(ageTimer)
    observer.disconnect()
    disposeSessions()
    disposeWorkspaces()
    if (typeof disposeLocale === 'function') disposeLocale()
    for (const row of document.querySelectorAll(`[data-row-key^="${ROW_PREFIX}"]`)) removeAgeLabel(row)
    styleTag.remove()
    styles.clear()
  }
}

// ---------------------------------------------------------------------------
// D5 contract implementation.
// ---------------------------------------------------------------------------

/** Currently installed host-side disposer, or undefined while detached. */
let release = undefined

/**
 * Install the feature's host-side behavior (none for this feature).
 * @param {object} ctx - the plugin context.
 * @returns {() => void} the disposer for this installation.
 */
export function attach(ctx) {
  dispose()
  release = () => {
    release = undefined
  }
  return release
}

/** Tear down the current host-side installation; idempotent. */
export function dispose() {
  const current = release
  release = undefined
  if (current !== undefined) current()
}

/** D5 contract view consumed by the package host and client halves. */
export const feature = {
  id,
  title,
  description,
  hasGear,
  settingsMessages,
  host: (ctx) => attach(ctx),
  client: (ctx, deps) => client(ctx, deps),
}
