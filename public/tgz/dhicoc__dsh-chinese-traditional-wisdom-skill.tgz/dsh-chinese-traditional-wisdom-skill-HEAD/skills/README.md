<p align="center">
  <img src="chinese-traditional-wisdom-ai-agent-workflow.png" alt="Chinese Traditional Wisdom Skill" width="140" />
</p>

<h1 align="center">Chinese Traditional Wisdom Skill</h1>
<p align="center">中国传统文化整体智慧咨询 Skill</p>

<p align="center">
  面向人生困惑、健康调养、事业决策、婚恋、择居、占问与传统文化学习的本地参考工具。
</p>

<p align="center">
  🌐 <a href="README_en.md">English</a>
</p>

<p align="center">
  Stable release: <strong>v1.0.0</strong> · <a href="CHANGELOG.md">Changelog</a> · <a href="https://github.com/dhicoc/chinese-traditional-wisdom-skill/releases/tag/v1.0.0">Release Notes</a>
</p>

<p align="center">
  <a href="#能做什么">能做什么</a> ·
  <a href="#开始使用">开始使用</a> ·
  <a href="#准备哪些信息">准备哪些信息</a> ·
  <a href="#如何理解结果">如何理解结果</a> ·
  <a href="#进阶使用">进阶使用</a>
</p>

> **传统文化参考，非绝对预测。** 本 Skill 提供结构化计算、传统文化解释与建设性建议；不构成医疗诊断、治疗方案、投资建议或对现实结果的保证。

## 这是什么

Chinese Traditional Wisdom Skill 是一个本地优先的传统文化咨询 Skill。它帮助你把问题整理为适合查询的输入，使用本地确定性引擎生成可复核的盘面、日期、干支或规则结果，再将这些结果与传统文化解释、现实中的审慎建议分层呈现。

你可以将它用于理解传统文化框架，也可以把它当作一次咨询的辅助工具：先看结构化事实，再看传统解释，最后结合自己的实际处境作出判断。

```text
你的问题
  → 选择合适的传统文化场景
  → 本地引擎计算可复核事实
  → 传统文化解释与建设性建议
  → 明确限制、免责声明与下一步行动
```

- **本地优先**：核心计算在本地运行，不需要把完整生辰上传至远程服务。
- **不让模型猜算**：盘面、干支、数值、映射与规则匹配由本地引擎产生；模型不得自行推演或补全。
- **结果可区分**：区分本地计算事实、传统解释和现实建议，避免把文化阐释误当作确定结论。
- **适合持续使用**：可在 Dashboard 浏览，也可由支持本地 Skill 的 AI Agent 调用。

## 能做什么

| 你的问题或目标 | 可使用的传统文化场景 | 你会获得什么 |
|---|---|---|
| 想了解出生时间对应的四柱结构 | 八字、喜用神、神煞、流年与动态层 | 四柱、五行、十神、大运、小运及指定日期的流年、流月、流日 |
| 想从紫微视角整理人生议题 | 紫微斗数 | 宫位、星曜与结构化盘面信息 |
| 面对一个具体问题，希望借助占问整理思路 | 六爻、梅花易数、奇门遁甲、大六壬、太乙、测字 | 起局或起卦结果、可复核规则事实与传统解释边界 |
| 想选择日期或规划日常节律 | 黄历、择日、星宿、节律、五运六气 | 日期信息、宜忌参考、节律与季节性文化参考 |
| 想了解居家环境的传统文化视角 | 飞星、八宅、形势与方位参考 | 本地映射与规则结果，供空间整理时参考 |
| 想了解体质倾向或日常调养思路 | 体质问卷、五运六气、养生联合分析 | 文化参考与生活方式建议；症状或疾病问题应先咨询医生 |
| 想讨论姓名、梦境、婚恋或人生选择 | 姓名、解梦、合婚、年度/月度联合分析 | 结构化参考信息与非宿命化的讨论框架 |

### Dashboard 完整功能目录

Dashboard 当前提供以下 **24 个工作区**；其中计算型页面直接调用本地 TypeScript 引擎，知识型与本地存储页面会明确标示其参考或数据边界。

| 分类 | 功能 | 主要内容 |
|---|---|---|
| 命理排盘 | 八字命盘 | 四柱、五行、十神、喜用神、神煞、大运、小运与目标日期动态层 |
| 命理排盘 | 紫微斗数 | 十二宫、主辅星、四化与结构化命盘 |
| 占测 | 六爻占卜 | 铜钱、时间或手动起卦；纳甲、六亲、六神、世应与变卦 |
| 占测 | 梅花易数 | 时间/数字起卦、体用、动爻、互卦、变卦与错综卦 |
| 占测 | 奇门遁甲 | 时家奇门九宫、门星神、三奇六仪、值符值使与格局提示 |
| 占测 | 大六壬 | 天地盘、四课、三传、神煞与格局参考 |
| 占测 | 太乙神数 | 太乙落宫、主客算、四将与传统格局参考 |
| 占测 | 皇极经世 | 元会运世、正卦/世卦/年卦与长期周期参考 |
| 占测 | 测字 · 字占 | 笔画数理、字义五行、字形结构与可选八字补益 |
| 历法与日用 | 每日黄历 | 宜忌、吉凶时辰、节气与物候民俗参考 |
| 历法与日用 | 二十八星宿 | 当日值宿、本命星宿、四象、七曜、宜忌与星图 |
| 历法与日用 | 五运六气 | 岁运、司天、在泉与六步客气 |
| 历法与日用 | 每日节律 | 十二时辰、经络对应与养生节律文化参考 |
| 历法与日用 | 袁天罡称骨 | 依全局生辰计算农历骨重与称骨歌诀参考 |
| 日用民俗 | 姓名五行 | 笔画、五行、三才、五格与喜用神补强参考 |
| 日用民俗 | 周公解梦 | 梦象检索、现代解读与古文断语参考 |
| 堪舆风水 | 风水罗盘 | 二十四山、八卦方位与相关知识说明 |
| 堪舆风水 | 流年飞星 | 指定年份的九宫飞星结构参考 |
| 堪舆风水 | 八宅大游年 | 命卦、宅卦、东/西四命与游年结构参考 |
| 综合参考 | 联合分析 | 年度、月度、决策、空间时间、三式、择日、合婚与日常调养等组合入口 |
| 健康文化参考 | 体质辨识 | 九种体质问卷评分、雷达图与调养提示；不替代医疗服务 |
| 知识与数据 | 古籍阅读 | 30 篇本地典籍书库，以及文王六十四卦卦序、矩阵、爻形定位、原文和错综互变关系 |
| 知识与数据 | 本地历史与收藏 | 默认不保存；保存前预览，支持脱敏摘要、自动过期、一键清空和可复核结果包导入/导出 |
| 开发与验证 | 测试控制台 | 查看本地测试注册项与开发验证信息 |

Dashboard 还提供：全局生辰资料管理、真太阳时核验/民用时间降级状态、命令面板导航、页面摘要复制、结构化报告导出，以及本地历史记录。

> **关于工具数量：** Dashboard 的 24 个工作区是面向使用者的页面入口；项目另有 **32 个本地 CLI 工具**，其中包含真太阳时预处理、底层排盘/日用计算、体质问卷和多种联合分析。CLI 工具可与 Dashboard 页面一对多对应，完整名称、输入契约与可运行 fixture 见 [tool-index.md](tool-index.md)。

## 开始使用

### 方式一：在 Dashboard 中使用

适合希望浏览盘面、修改输入并查看可视化结果的用户。

完整安装会同时安装 TypeScript 权威运行时和 Python 离线交叉验证依赖：

```powershell
scripts\setup.bat
pnpm dev
```

Linux/macOS：

```bash
./scripts/setup.sh
pnpm dev
```

也可只在已经完成依赖安装的环境中直接进入 Dashboard：

```bash
cd apps/visual
pnpm dev
```

项目使用 Node `24.12.x`、pnpm `10.26.1` 与 `pnpm-lock.yaml` 固定依赖版本；不要生成或提交 `package-lock.json`。打开本地地址后，选择相应页面并填写必要信息。Dashboard 使用本地 TypeScript 引擎计算；结果中的 `local-exact`、`local-approx`、民俗体验、演示或降级状态会说明其计算口径与可用性。

### 方式二：通过 AI Agent 使用 Skill

将本仓库作为本地 Skill 安装或加载后，先让 Agent 阅读 [SKILL.md](SKILL.md) 与 [RULES.md](RULES.md)。Agent 应当：

1. 先理解你的问题、场景和所缺信息；缺少必要输入时向你追问，而不是猜填。
2. 选择本地工具计算确定性事实；不得把模型记忆或参考文本冒充为本次计算结果。
3. 将计算事实、传统文化解释、现实建议和免责声明分开说明。

AI Agent 的完整调用约定见 [README_AI.md](README_AI.md)。

## 准备哪些信息

不同场景所需信息不同。只提供与问题有关的信息即可；不确定的字段应明确说明，不要为了“凑全”而猜测。

| 场景 | 通常需要的信息 | 使用前提示 |
|---|---|---|
| 八字、紫微、合婚等出生盘 | 公历出生年月日、时分、性别；必要时包括出生地 | 出生时分会影响结果；不知道时分时，应使用明确的限制说明 |
| 真太阳时复核 | 出生记录、已核验的出生地点经度、IANA 时区、出生当日 UTC 偏移、夏令时和 `utcOffsetEvidence` | 无法可靠核验时，只能按民用时间计算，并标注“未完成真太阳时复核” |
| 占问 | 清晰的问题、起卦/起局时间或指定方式 | 一次只聚焦一个可描述的问题，避免把占问代替现实决策程序 |
| 风水与空间 | 坐向、建造/入住年份、空间信息或照片描述 | 不要据此替代建筑安全、消防、法律或专业装修意见 |
| 体质与调养 | 问卷回答、日常习惯和主观感受 | 症状、疾病、用药或急性不适应优先咨询医生 |

### 关于真太阳时

民用出生时间不等于真太阳时。本 Skill 提供 `resolve_true_solar_time` 作为本地校正入口，但只有在地点与历史时区证据已经外部核验时，才能使用 `trueSolarBirth` 或 `trueSolarResolution` 并标记为真太阳时结果。

无法可靠核验时，可以在知情前提下使用民用时间路径：`timeBasis: 'civil-unverified'` 与 `civilFallbackConfirmed: true`。该结果必须显示“未完成真太阳时复核”，不能称为真太阳时结果。

## 如何理解结果

一次好的使用方式，是将输出分为三层阅读：

1. **本地计算事实**：如四柱、日期、干支、宫位、映射、数值和规则关系。这些来自本次本地引擎结果。
2. **传统文化解释**：如不同流派对结构的含义、象征和思考角度。它们属于文化参考，不是客观预测。
3. **现实行动建议**：如沟通、记录、休息、寻求专业协助或重新评估选择。它们应保持建设性、非宿命化，并由你结合实际情况决定是否采用。

### 八字动态层

需要查看指定日期的大运、小运、流年、流月或流日时，使用既有 `bazi_calculate` 并提供严格格式的 `transitDate: "YYYY-MM-DD"`。结果仍为本次 `ToolEnvelope`，动态事实位于 `ToolEnvelope.data.transit`。

小运按虚岁定位。若 `minor.source` 为 `lunar-exact`，表示结果来自本地历法序列；若为 `local-fallback`，表示采用确定性本地降级规则，解读时必须披露。干支关系只说明可复核的规则事实，不能直接推出事业、婚恋、健康、财富或其他现实结果。

详细的动态层输入、输出和 claims 说明见 [bootstrap/bazi-engine.md](bootstrap/bazi-engine.md)。

## 使用边界与隐私

- 不把传统文化结果当作绝对预测，也不以此替代个人判断、法律意见、财务建议或医疗服务。
- 健康问题出现症状、急性不适或持续困扰时，应优先就医；本 Skill 不提供诊断、处方或替代治疗建议。
- 不要在长期日志、公开案例或提交记录中保存完整生辰、精确地点或可识别身份信息。
- 不确定、不完整或无法核验的输入必须保留限制说明；不得将近似、演示或民用时间结果表述为精确结论。

完整伦理与安全规则见 [RULES.md](RULES.md)。

## 进阶使用

### 本地 CLI

开发者或支持 CLI 的 Agent 可直接运行本地工具：

```bash
cd apps/visual
pnpm install --frozen-lockfile
pnpm engine <tool> <input-json-file>
```

需要比较明确规则配置时，可运行：

```bash
pnpm engine:compare-rules src/__fixtures__/analysis/rule-comparison-bazi.success.json
```

`engine:compare-rules` 是 32 工具之外的独立只读分析入口，只比较结构化字段并列出每个规则来源，不推荐或裁定某一流派。

查询《周易》六十四卦时，可按编号、卦名、上下卦或六爻结构调用：

```bash
pnpm engine:iching-lookup src/__fixtures__/analysis/iching-lookup.success.json
```

`engine:iching-lookup` 同样不增加 registry 工具数；它只返回本地规范卦序、原文、错综互卦和显式动爻所成变卦，不由模型自行换算。

在尚未确定工具和参数时，可先运行只读规划器：

```bash
pnpm engine:plan --query "想看今年事业"
```

规划器不排盘、不计算，也不回显原始咨询内容；它只列出候选工具、缺失字段、风险提示和建议深度。输入方式和输出字段见 `tool-index.md`。

除 `resolve_true_solar_time` 直接返回 `TrueSolarTimeResolution` 外，CLI 返回 JSON `ToolEnvelope`。呈现确定性事实前，应只从本次 `ToolEnvelope.data` 提取结构化 claims，再调用对应本地 `validate*Claims(data, claims)` 核验；该校验不能验证自由文本、传统解释、建议或预测。

标准 success fixture、所有工具名与 CLI 示例见 [tool-index.md](tool-index.md)。

### 关键资源

| 资源 | 用途 |
|---|---|
| [SKILL.md](SKILL.md) | Skill 路由、调用顺序与输出规范 |
| [RULES.md](RULES.md) | 伦理、隐私、健康与输入完整性边界 |
| [README_AI.md](README_AI.md) | AI Agent 的本地调用说明与故障处理 |
| [tool-index.md](tool-index.md) | 32 个本地工具、标准 fixture 与 CLI 参考 |
| [skill-evals/README.md](skill-evals/README.md) | 19 项本地 Skill 行为契约与 `pnpm eval:skill` 使用说明 |
| [v1.0.0 Release](https://github.com/dhicoc/chinese-traditional-wisdom-skill/releases/tag/v1.0.0) | 安装包、Release Notes、Manifest 与 SHA256SUMS |
| [`bootstrap/`](bootstrap/) | 八字、紫微、六爻、梅花、风水等领域的详细说明 |
| [`apps/visual/`](apps/visual/) | Dashboard、纯 TypeScript 引擎与测试 |
| [knowledge-base/manifest.generated.json](knowledge-base/manifest.generated.json) | 古籍、映射与 reference 的稳定 ID、来源状态、许可证状态和 SHA-256 校验 |
| [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md) | 运行库与捆绑数据集的来源和发布治理要求 |

### 本地数据分片与性能预算

大型字义、古籍全文索引和解梦全量库均由源数据生成分片：字义 32 片、全文索引 4 片、解梦 22 片。`pnpm check:bundle-budget` 在生产构建后检查首屏、gzip chunk、分片源文件和已移除的 12MB 公共单文件，CI 不通过提高 Vite 告警阈值掩盖回归。

### 开发验证

改动引擎、输入契约、Dashboard 或公开文档后，在 `apps/visual` 运行：

```bash
pnpm typecheck
pnpm test:unit
pnpm test
node scripts/check-doc-contracts.mjs
pnpm build
pnpm test:e2e
```

文档契约检查会确保公开工具清单、CLI、fixture 和关键使用约定保持一致。仅修改文档时，至少运行文档契约检查与 `git diff --check`；完整质量门以根 `package.json`、`.github/workflows/ci.yml` 和 `tool-index.md` 为准。

## 仓库结构

```text
apps/visual/
  scripts/run-engine.ts        # 本地 CLI 入口
  src/legacy/                  # 纯 TypeScript 引擎、ToolEnvelope 与校验器
  src/__fixtures__/local-tools/# CLI 标准输入样例
bootstrap/                     # 分领域使用说明
knowledge-base/                # 传统文化资料与本地确定性映射表
templates/                     # 报告模板
SKILL.md                       # Skill 主入口
RULES.md                       # 安全与伦理规则
```
