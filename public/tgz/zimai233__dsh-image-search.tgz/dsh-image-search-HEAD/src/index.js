/**
 * dsh-image-search — multi-engine reverse image search aggregator for DeepSeek Harness.
 *
 * The vision ecosystem does OCR and UI restoration, but nothing aggregates
 * reverse-image lookups across Google Lens / Baidu / Yandex / TinEye / Bing /
 * Sogou / SauceNAO / IQDB / Ascii2d. This plugin is the aggregation wedge: it
 * turns a single public image URL into one search URL per engine — pure URL
 * construction, zero network calls, dependency-free.
 *
 * Pure ESM, zero build step — the published package is the runtime code.
 */

import { defineTool } from '@deepseek-ai/dsh-tools'

export const name = 'dsh-image-search'
export const inject = ['tools']

// ---------------------------------------------------------------- pure core

/**
 * Supported reverse-image search engines.
 *
 * `template` uses the `{IMAGE_URL}` placeholder. When `encode` is true the
 * image URL is `encodeURIComponent`-encoded before substitution (query-string
 * engines); when false it is inserted verbatim (path-style engines that need
 * the raw URL).
 */
export const ENGINES = [
  { id: 'google', name: 'Google Lens', group: '通用', template: 'https://lens.google.com/uploadbyurl?url={IMAGE_URL}', encode: true },
  { id: 'baidu', name: '百度识图', group: '通用', template: 'https://graph.baidu.com/upload?image={IMAGE_URL}', encode: true },
  { id: 'yandex', name: 'Yandex', group: '通用', template: 'https://yandex.com/images/search?rpt=imageview&url={IMAGE_URL}', encode: true },
  { id: 'tineye', name: 'TinEye', group: '通用', template: 'https://tineye.com/search?url={IMAGE_URL}', encode: true },
  { id: 'bing', name: 'Bing 视觉搜索', group: '通用', template: 'https://www.bing.com/images/searchbyimage?cbir=sbi&imgurl={IMAGE_URL}', encode: true },
  { id: 'sogou', name: '搜狗识图', group: '通用', template: 'https://pic.sogou.com/ris?query={IMAGE_URL}', encode: true },
  { id: 'saucenao', name: 'SauceNAO', group: '插画/动漫', template: 'https://saucenao.com/search.php?url={IMAGE_URL}', encode: false },
  { id: 'iqdb', name: 'IQDB', group: '插画/动漫', template: 'https://iqdb.org/?url={IMAGE_URL}', encode: false },
  { id: 'ascii2d', name: 'Ascii2d', group: '插画/动漫', template: 'https://ascii2d.net/search/url/{IMAGE_URL}', encode: false },
]

/**
 * Build reverse-image search URLs for a public image URL.
 *
 * @param {string} imageUrl - Public image URL to search for.
 * @param {object} [opts]
 *   - engines: comma-separated string or array of engine ids to include.
 *     Unknown ids are skipped gracefully.
 *   - group: exact group filter (e.g. '通用' or '插画/动漫').
 * @returns {Array<{ id, name, group, url }>} One entry per matched engine.
 */
export function buildEngineUrls(imageUrl, { engines, group } = {}) {
  const want = typeof engines === 'string'
    ? engines.split(',').map((s) => s.trim()).filter(Boolean)
    : engines
  return ENGINES
    .filter((e) => !group || e.group === group)
    .filter((e) => !want || want.includes(e.id))
    .map((e) => ({
      id: e.id,
      name: e.name,
      group: e.group,
      url: e.template.replace('{IMAGE_URL}', e.encode ? encodeURIComponent(imageUrl) : imageUrl),
    }))
}

/**
 * Group all engines by their `group` field.
 * @returns {Record<string, Array>} e.g. { '通用': [...], '插画/动漫': [...] }
 */
export function groupEngines() {
  const out = {}
  for (const e of ENGINES) {
    ;(out[e.group] ??= []).push(e)
  }
  return out
}

// ---------------------------------------------------------------- tools

const renderText = (_args, value) => [{ type: 'text', text: value }]

export function apply(ctx) {
  ctx.tools.register(defineTool({
    name: 'image_search_urls',
    description:
      'Build reverse-image search URLs for a public image across all supported engines ' +
      '(Google Lens, Baidu, Yandex, TinEye, Bing, Sogou, SauceNAO, IQDB, Ascii2d). ' +
      'Pure URL construction — no network requests are made. ' +
      'Returns a JSON array of { id, name, group, url }. ' +
      'Optionally filter by comma-separated engine ids or by group.',
    parameters: {
      imageUrl: { type: 'string', required: true, description: 'Public image URL to search for.' },
      engines: { type: 'string', description: 'Optional comma-separated engine ids, e.g. "google,saucenao". Unknown ids are skipped.' },
      group: { type: 'string', description: 'Optional group filter, e.g. "通用" or "插画/动漫".' },
    },
    output: {
      schema: { type: 'string' },
      render: renderText,
    },
    async execute(args) {
      return JSON.stringify(buildEngineUrls(args.imageUrl, { engines: args.engines, group: args.group }))
    },
  }))

  ctx.tools.register(defineTool({
    name: 'image_search_engines',
    description:
      'List all supported reverse-image search engines grouped by category. ' +
      'Returns a JSON object keyed by group ("通用" and "插画/动漫"), each value an ' +
      'array of { id, name, group, template, encode }. Use this to discover engine ids.',
    parameters: {},
    output: {
      schema: { type: 'string' },
      render: renderText,
    },
    async execute() {
      return JSON.stringify(groupEngines(), null, 2)
    },
  }))

  ctx.tools.register(defineTool({
    name: 'image_search_best',
    description:
      'Return a human-readable markdown summary of reverse-image search URLs for a ' +
      'public image: a summary line plus one bullet link per engine. ' +
      'Optionally filter by comma-separated engine ids. ' +
      'Pure URL construction — no network requests are made.',
    parameters: {
      imageUrl: { type: 'string', required: true, description: 'Public image URL to search for.' },
      engines: { type: 'string', description: 'Optional comma-separated engine ids, e.g. "google,saucenao". Unknown ids are skipped.' },
    },
    output: {
      schema: { type: 'string' },
      render: renderText,
    },
    async execute(args) {
      const urls = buildEngineUrls(args.imageUrl, { engines: args.engines })
      const lines = urls.map((u) => `- [${u.name}](<${u.url}>)（${u.group}）`)
      return [
        `Reverse-image search for \`${args.imageUrl}\` across ${urls.length} engine(s):`,
        '',
        ...lines,
      ].join('\n')
    },
  }))
}
