import { test } from 'node:test'
import assert from 'node:assert/strict'
import { ENGINES, buildEngineUrls, groupEngines } from '../src/index.js'

test('buildEngineUrls substitutes correctly for google (encoded) and saucenao (not encoded)', () => {
  const urls = buildEngineUrls('https://example.com/img.png')
  assert.equal(urls.length, 9)
  const google = urls.find((u) => u.id === 'google')
  const saucenao = urls.find((u) => u.id === 'saucenao')
  assert.equal(google.url, 'https://lens.google.com/uploadbyurl?url=' + encodeURIComponent('https://example.com/img.png'))
  assert.equal(saucenao.url, 'https://saucenao.com/search.php?url=https://example.com/img.png')
  // every built URL has the image URL substituted and no placeholder left behind
  for (const u of urls) assert.ok(!u.url.includes('{IMAGE_URL}'))
})

test('all 9 engines are exposed and grouped', () => {
  assert.equal(ENGINES.length, 9)
  const grouped = groupEngines()
  const all = Object.values(grouped).flat()
  assert.equal(all.length, 9)
  assert.deepEqual(new Set(all.map((e) => e.id)), new Set([
    'google', 'baidu', 'yandex', 'tineye', 'bing', 'sogou', 'saucenao', 'iqdb', 'ascii2d',
  ]))
  assert.ok(grouped['通用'].length >= 6)
  assert.ok(grouped['插画/动漫'].length === 3)
})

test('group filter works', () => {
  const urls = buildEngineUrls('https://example.com/img.png', { group: '插画/动漫' })
  assert.equal(urls.length, 3)
  assert.deepEqual(urls.map((u) => u.id).sort(), ['ascii2d', 'iqdb', 'saucenao'])
  assert.ok(urls.every((u) => u.group === '插画/动漫'))
})

test('unknown engine id is skipped gracefully', () => {
  const urls = buildEngineUrls('https://example.com/img.png', { engines: 'google,no-such-engine' })
  assert.equal(urls.length, 1)
  assert.equal(urls[0].id, 'google')
  // array form works too, and empty selection yields an empty result without throwing
  const arr = buildEngineUrls('https://example.com/img.png', { engines: ['tineye'] })
  assert.equal(arr.length, 1)
  assert.equal(arr[0].id, 'tineye')
})
