import * as THREE from 'three';
import type { TextScriptBinding } from './text-script.js';
export interface TextLayoutOptions {
    limitwidth?: boolean;
    maxwidth?: number;
}
export interface TextTextureOptions extends TextMeasureOptions {
    color?: [number, number, number];
    brightness?: number;
    width: number;
    height: number;
    verticalAlign?: string;
    alignment?: string;
}
export interface TextMeasureOptions extends TextLayoutOptions {
    font?: string;
    pointsize?: number;
    padding?: number;
    horizontalAlign?: string;
}
export interface TextLayout {
    width: number;
    height: number;
    textWidth: number;
    textHeight: number;
}
export declare function measureTextLayout(text: string, opts?: TextMeasureOptions): TextLayout;
export declare function textCanvasSize(text: string, opts?: TextMeasureOptions): {
    w: number;
    h: number;
};
export interface TextAlignments {
    halign: 'left' | 'center' | 'right';
    valign: 'top' | 'center' | 'bottom';
}
export declare function textAlignments(horizontalAlign?: string, verticalAlign?: string, alignment?: string, anchor?: string): TextAlignments;
export declare function textLayerOffset(layout: TextLayout, horizontalAlign: string | undefined, verticalAlign: string | undefined, alignment: string | undefined, scale: readonly number[], anchor?: string): [number, number];
export declare function drawTextToCanvas(canvas: HTMLCanvasElement, text: string, opts: TextTextureOptions): void;
export declare function createTextTexture(text: string, opts: TextTextureOptions): THREE.CanvasTexture;
export interface ClockDriver {
    /** 文本变化时重绘 canvas 并返回 true（调用方据此置 texture.needsUpdate）。 */
    update(now: Date): boolean;
    /** 最近一次文本的实测布局；文本变化后调用方据此同步 quad 尺寸与锚点偏移。 */
    readonly layout: TextLayout;
}
export declare function createScriptDriver(canvas: HTMLCanvasElement, opts: TextTextureOptions, binding: TextScriptBinding, initialText?: string): ClockDriver;
export declare function createClockDriver(canvas: HTMLCanvasElement, opts: TextTextureOptions, props: Record<string, unknown>, initialText: string): ClockDriver;
