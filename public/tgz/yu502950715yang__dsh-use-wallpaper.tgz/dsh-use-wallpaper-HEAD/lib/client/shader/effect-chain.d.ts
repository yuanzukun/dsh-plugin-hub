import { type UniformValue } from './uniform-binder.js';
export interface CompiledEffectPass {
    vertSrc: string;
    fragSrc: string;
    rawVert: string;
    rawFrag: string;
    combos: Record<string, number>;
    uniforms: Map<string, UniformValue>;
    textureSlots: (string | null)[];
    samplerModes: Record<string, string>;
    samplerNames: string[];
    blendMode: string;
    target: string | null;
    bind: {
        name: string;
        index: number;
    }[];
    fboScale: Record<string, number>;
}
export declare function resolveEffectChain(sceneEffect: {
    file: string;
    passes?: unknown[];
}, loadFile: (name: string) => Promise<Uint8Array | null>): Promise<CompiledEffectPass[] | null>;
