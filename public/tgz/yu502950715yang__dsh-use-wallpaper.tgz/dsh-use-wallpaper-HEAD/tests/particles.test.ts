import { describe, expect, it } from 'vitest';
import { createParticleSystem, alphaAt } from '../src/client/particles.js';
import { particlesFromSpec } from '../src/client/scene-assets.js';

const emitter = { rate: 10, directions: [1, 0, 0], distanceMin: 0, distanceMax: 5 };
const init = {
  lifetimeMin: 1, lifetimeMax: 1,
  sizeMin: 8, sizeMax: 20,
  velocityMin: [0, 0, 0] as [number, number, number],
  velocityMax: [1, 0, 0] as [number, number, number],
};

describe('createParticleSystem', () => {
  it('emits particles at rate and caps at maxParticles', () => {
    const ps = createParticleSystem(emitter, init, { maxParticles: 100 });
    for (let i = 0; i < 10; i++) ps.update(0.1); // 累计 1s，rate=10 → 约10个
    expect(ps.count()).toBeGreaterThanOrEqual(8);
    expect(ps.count()).toBeLessThanOrEqual(12);
  });
  it('removes particles after lifetime elapses', () => {
    const ps = createParticleSystem(emitter, init, { maxParticles: 100 });
    ps.update(0.5);  // 发射 5 个
    ps.update(1.0);  // 再过 1s → 第一批已到寿命（lifetime=1）
    expect(ps.count()).toBeLessThanOrEqual(10);
    ps.update(2.0);  // 全部过期
    expect(ps.count()).toBe(0);
  });
  it('moves particles along velocity', () => {
    const ps = createParticleSystem(
      { ...emitter, distanceMin: 0, distanceMax: 0 }, // 初始位置为 0，便于观察位移
      init,
      { maxParticles: 10 },
    );
    ps.update(0.1); // 发射 1 个（life 0.9）
    ps.update(0.1); // 再发射 1 个（两个粒子均存活，life 0.8/0.9）
    const before = [...ps.positions()]; // 拷贝快照，避免引用同一 Float32Array
    ps.update(0.05); // 无新发射（accumulator=0.5<1），仅按 velocity 移动
    const after = [...ps.positions()];
    for (let i = 0; i < ps.count(); i++) {
      // velocity ∈ [0,1]x → x 单调不减；比较的是旧值 vs 新值（真实断言）
      expect(after[i * 3]).toBeGreaterThanOrEqual(before[i * 3]);
    }
  });
  it('is deterministic given a fixed seed', () => {
    const a = createParticleSystem(emitter, init, { maxParticles: 10, seed: 42 });
    const b = createParticleSystem(emitter, init, { maxParticles: 10, seed: 42 });
    const c = createParticleSystem(emitter, init, { maxParticles: 10, seed: 43 });
    a.update(0.5); b.update(0.5); c.update(0.5); // 存活 5 个，positions 含 rand 派生值
    expect([...a.positions()]).toEqual([...b.positions()]); // 同 seed 完全一致
    // 反证：不同 seed 产物不同，证明断言确实比较了 rand 派生值
    expect([...a.positions()]).not.toEqual([...c.positions()]);
  });
});

describe('alphaAt', () => {
  it('alpha 随寿命线性衰减', () => {
    expect(alphaAt(0.2, 4, 5)).toBeCloseTo(0.16, 5);
    expect(alphaAt(0.2, 0, 5)).toBe(0);
  });
});

describe('T4.4 粒子负 scale 镜像前置（模拟在局部坐标生成）', () => {
  it('粒子位置相对发射原点（局部坐标，|pos| ≤ distanceMax）——points.scale 的负 scale.y 才能绕对象原点镜像', () => {
    // 镜像语义：负 scale.y 由渲染侧 points.scale.set(s[0], s[1], ...) 施加，绕**对象原点**
    // 翻转整个粒子云。前置条件 = 模拟输出局部坐标（否则负 scale 会绕世界原点缩放，
    // 镜像位置错乱）。断言位置量级 ≤ 发射距离（局部），而非场景量级（960/540 级）。
    const ps = createParticleSystem(
      { rate: 50, directions: [1, 1, 0], distanceMin: 0, distanceMax: 5 },
      { ...init, lifetimeMin: 5, lifetimeMax: 5, velocityMin: [0, 0, 0], velocityMax: [0, 0, 0] },
      { maxParticles: 100, seed: 7 },
    );
    ps.update(1); // 累计 1s，rate=50 → 约 50 个
    const pos = ps.positions();
    for (let i = 0; i < ps.count(); i++) {
      const x = pos[i * 3];
      const y = pos[i * 3 + 1];
      expect(Math.hypot(x, y)).toBeLessThanOrEqual(5.01);
    }
  });
});

describe('particlesFromSpec alpha', () => {
  it('解析 alpharandom → alphaMin/alphaMax', () => {
    const spec = particlesFromSpec(JSON.parse(JSON.stringify({
      emitter: [{ rate: 1.5 }],
      initializer: [
        { name: 'lifetimerandom', min: 3, max: 5 },
        { name: 'alpharandom', min: 0.15, max: 0.2 },
      ],
    })));
    expect(spec?.init.alphaMin).toBe(0.15);
    expect(spec?.init.alphaMax).toBe(0.2);
  });

  it('无 alpharandom 时 alpha 缺省 1', () => {
    const spec = particlesFromSpec({ emitter: [{ rate: 1 }], initializer: [] });
    expect(spec?.init.alphaMin).toBeUndefined();
  });
});
