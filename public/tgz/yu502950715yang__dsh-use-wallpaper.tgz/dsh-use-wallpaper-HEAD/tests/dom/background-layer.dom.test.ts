import { afterEach, describe, expect, it, vi } from 'vitest';
import {
  createBackgroundLayer,
  WEB_RESIZE_RELOAD_DELAY_MS,
  WEB_RESIZE_RELOAD_TIMEOUT_MS,
} from '../../src/client/background-layer.js';

afterEach(() => { vi.useRealTimers(); });

describe('createBackgroundLayer (DOM)', () => {
  it('renders image into fill and toggles kenburns class', () => {
    document.body.innerHTML = '';
    const root = document.createElement('div');
    document.body.appendChild(root);
    const layer = createBackgroundLayer(root);
    layer.showImage('/p.gif', false);
    const img = root.querySelector('.wp-bg-fill img') as HTMLImageElement;
    expect(img).not.toBeNull();
    expect(img.src).toContain('/p.gif');
    expect(img.classList.contains('wp-kenburns')).toBe(false);
    layer.showImage('/q.jpg', true);
    const img2 = root.querySelector('.wp-bg-fill img') as HTMLImageElement;
    expect(img2.classList.contains('wp-kenburns')).toBe(true);
  });
  it('applies overlay opacity', () => {
    const root = document.createElement('div');
    const layer = createBackgroundLayer(root);
    layer.setOverlayOpacity(0.5);
    const overlay = root.querySelector('.wp-bg-overlay') as HTMLElement;
    expect(overlay.style.opacity).toBe('0.5');
  });
  it('sets data-we-wallpaper on body when wallpaper active, removes when none', () => {
    document.body.innerHTML = '';
    document.body.removeAttribute('data-we-wallpaper');
    const root = document.createElement('div');
    document.body.appendChild(root);
    const layer = createBackgroundLayer(root);
    expect(document.body.hasAttribute('data-we-wallpaper')).toBe(false);
    layer.showImage('/p.gif', false);
    expect(document.body.getAttribute('data-we-wallpaper')).toBe('true');
    layer.showNone();
    expect(document.body.hasAttribute('data-we-wallpaper')).toBe(false);
  });
  it('keeps data-we-wallpaper across media switches, clears on showNone', () => {
    document.body.innerHTML = '';
    document.body.removeAttribute('data-we-wallpaper');
    const root = document.createElement('div');
    document.body.appendChild(root);
    const layer = createBackgroundLayer(root);
    layer.showImage('/a.jpg', true);
    layer.showVideo('/b.mp4');
    expect(document.body.getAttribute('data-we-wallpaper')).toBe('true');
    layer.showNone();
    expect(document.body.hasAttribute('data-we-wallpaper')).toBe(false);
  });

  it('showSceneCanvas 把模糊层 canvas 的缓冲对齐前景（不再停在 300×150 被 CSS 拉伸）', () => {
    // 2026-09-10 Task5：模糊层 canvas 若保持 HTML 默认 300×150，会被
    // `.wp-scene-blur{width:100%;height:100%;transform:scale(1.1)}` 放大到全屏（模糊/失真），
    // 且 DOM 序在前 → `document.querySelector('canvas')` 读到它而非真正渲染的 canvas。
    document.body.innerHTML = '';
    const root = document.createElement('div');
    document.body.appendChild(root);
    const layer = createBackgroundLayer(root);
    const fg = document.createElement('canvas');
    fg.width = 3840; // 视口 1920 × dpr 2
    fg.height = 2160;
    const blur = document.createElement('canvas');
    expect(blur.width).toBe(300); // HTML 默认值
    layer.showSceneCanvas(fg, blur);
    expect(blur.width).toBe(3840);
    expect(blur.height).toBe(2160);
    expect(blur.classList.contains('wp-scene-blur')).toBe(true);
    expect(fg.classList.contains('wp-scene-canvas')).toBe(true);
  });

  // AGENT.md §5.30：无 allow-same-origin 的沙箱是 opaque origin，壁纸自己的 img/video 也算跨源，
  // WebGL texImage2D 会抛 SecurityError（web 壁纸空白）⇒ 改用另一回环主机名承载壁纸。
  it('showWeb：另一回环主机名可达时跨源承载，并保留 allow-same-origin', async () => {
    document.body.innerHTML = '';
    const root = document.createElement('div');
    document.body.appendChild(root);
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue({} as Response);
    try {
      const layer = createBackgroundLayer(root);
      layer.showWeb('/wallpapers/web/9/index.html');
      await vi.waitFor(() => expect(root.querySelector('.wp-bg-fill iframe')).not.toBeNull());
      const frame = root.querySelector('.wp-bg-fill iframe') as HTMLIFrameElement;
      // jsdom 的 location 是 http://localhost:3000 → 应为互换后的 127.0.0.1
      expect(frame.getAttribute('src')).toBe('http://127.0.0.1:3000/wallpapers/web/9/index.html');
      expect(frame.getAttribute('sandbox')).toBe('allow-scripts allow-same-origin');
      expect(frame.getAttribute('allow')).toBe('autoplay; fullscreen');
      expect(frame.getAttribute('scrolling')).toBe('no'); // 壁纸是背景：不允许子帧滚动条吃掉视口
      expect(fetchSpy).toHaveBeenCalledWith(
        'http://127.0.0.1:3000/wallpapers/web/9/index.html',
        expect.objectContaining({ mode: 'no-cors' }),
      );
    } finally {
      fetchSpy.mockRestore();
    }
  });

  it('showWeb：另一主机名不可达时退回同源 + 纯 allow-scripts 沙箱', async () => {
    document.body.innerHTML = '';
    const root = document.createElement('div');
    document.body.appendChild(root);
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockRejectedValue(new TypeError('network error'));
    try {
      const layer = createBackgroundLayer(root);
      layer.showWeb('/wallpapers/web/9/index.html');
      await vi.waitFor(() => expect(root.querySelector('.wp-bg-fill iframe')).not.toBeNull());
      const frame = root.querySelector('.wp-bg-fill iframe') as HTMLIFrameElement;
      expect(frame.getAttribute('src')).toBe('http://localhost:3000/wallpapers/web/9/index.html');
      expect(frame.getAttribute('sandbox')).toBe('allow-scripts');
    } finally {
      fetchSpy.mockRestore();
    }
  });

  // 桌面壳（DeepSeek Harness 桌面版）用自定义协议 dsh-app://app 承载 GUI：没有可互换的回环主机名，
  // 但有官方接缝 __DSH_TRANSPORT__.streamBaseUrl（宿主真实 HTTP origin）⇒ 用它承载壁纸，
  // 壁纸与自身资源同源（WebGL 贴图可用）、与宿主页仍跨源（隔离不降级）。
  it('showWeb：有 __DSH_TRANSPORT__ 时用宿主 HTTP origin 承载，且不探活', async () => {
    document.body.innerHTML = '';
    const root = document.createElement('div');
    document.body.appendChild(root);
    const g = globalThis as { __DSH_TRANSPORT__?: unknown };
    g.__DSH_TRANSPORT__ = { ownsHost: true, streamBaseUrl: 'http://127.0.0.1:19387' };
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockRejectedValue(new TypeError('no network in test'));
    try {
      const layer = createBackgroundLayer(root);
      layer.showWeb('/wallpapers/web/3789244610/index.html');
      await vi.waitFor(() => expect(root.querySelector('.wp-bg-fill iframe')).not.toBeNull());
      const frame = root.querySelector('.wp-bg-fill iframe') as HTMLIFrameElement;
      expect(frame.getAttribute('src')).toBe('http://127.0.0.1:19387/wallpapers/web/3789244610/index.html');
      expect(frame.getAttribute('sandbox')).toBe('allow-scripts allow-same-origin');
      expect(frame.getAttribute('scrolling')).toBe('no');
      // transport origin 由桌面壳保证可达（它自己就用它做流式传输）⇒ 不做 no-cors 探活
      expect(fetchSpy).not.toHaveBeenCalled();
    } finally {
      delete g.__DSH_TRANSPORT__;
      fetchSpy.mockRestore();
    }
  });

  // 启动首帧的跨源子帧视口竞态（2026-09-30 真机 bug，用户报「启动桌面版时壁纸加载不出来，
  // 调整窗口大小才出现」）：未挂载的 iframe 一旦有 src 就立刻开始加载，而**跨源子帧（OOPIF）**
  // 冷启动时父帧尚未给它分配盒子尺寸 ⇒ 子帧读到 `window.innerWidth/Height = 0`。壁纸
  // `3789244610` 初始化时把视口快照成画布尺寸（自身无 resize 监听）⇒ 画布永远 0×0、画面空白，
  // 直到一次窗口 resize 触发重建 iframe（站点实例已存在、尺寸正确）才显示。
  // ⇒ 不变量：**先挂载 + 强制一次布局，之后才赋 src**。
  it('showWeb：iframe 先挂载并强制布局，之后才赋 src（否则跨源子帧视口为 0）', async () => {
    document.body.innerHTML = '';
    const root = document.createElement('div');
    document.body.appendChild(root);
    const g = globalThis as { __DSH_TRANSPORT__?: unknown };
    g.__DSH_TRANSPORT__ = { ownsHost: true, streamBaseUrl: 'http://127.0.0.1:19387' };
    const seen: Array<{ connected: boolean; src: string | null }> = [];
    const rectSpy = vi.spyOn(HTMLIFrameElement.prototype, 'getBoundingClientRect').mockImplementation(function (this: HTMLIFrameElement) {
      if (this.classList.contains('wp-scene-canvas')) {
        seen.push({ connected: this.isConnected, src: this.getAttribute('src') });
      }
      return { width: 1280, height: 820 } as DOMRect;
    });
    try {
      const layer = createBackgroundLayer(root);
      layer.showWeb('/wallpapers/web/3789244610/index.html');
      await vi.waitFor(() => expect(root.querySelector('.wp-bg-fill iframe')).not.toBeNull());
      const frame = root.querySelector('.wp-bg-fill iframe') as HTMLIFrameElement;
      expect(seen.length).toBeGreaterThan(0);
      expect(seen[0].connected).toBe(true); // 强制布局发生在**挂载之后**
      expect(seen[0].src).toBeNull();       // 且发生在**赋 src 之前**
      expect(frame.getAttribute('src')).toBe('http://127.0.0.1:19387/wallpapers/web/3789244610/index.html');
      expect(frame.getAttribute('sandbox')).toBe('allow-scripts allow-same-origin');
    } finally {
      rectSpy.mockRestore();
      delete g.__DSH_TRANSPORT__;
    }
  });

  it('showWeb：探活未落地就切换壁纸时，旧 iframe 不再落地', async () => {
    document.body.innerHTML = '';
    const root = document.createElement('div');
    document.body.appendChild(root);
    let release: (v: unknown) => void = () => {};
    const pending = new Promise((res) => { release = res; });
    const fetchSpy = vi.spyOn(globalThis, 'fetch').mockReturnValue(pending as Promise<Response>);
    try {
      const layer = createBackgroundLayer(root);
      layer.showWeb('/wallpapers/web/9/index.html');
      layer.showVideo('/v.mp4'); // 期间切换 → 递增 frameToken
      release({});
      await new Promise((r) => setTimeout(r, 0));
      expect(root.querySelector('.wp-bg-fill iframe')).toBeNull();
      expect(root.querySelector('.wp-bg-fill video')).not.toBeNull();
    } finally {
      fetchSpy.mockRestore();
    }
  });

  // 省电（2026-09-21）：视频壁纸停/续播；web 壁纸在 iframe 内，插件无法控制。
  it('setPaused：视频壁纸暂停/恢复，且暂停态下换壁纸的新视频同样不播', () => {
    document.body.innerHTML = '';
    const root = document.createElement('div');
    document.body.appendChild(root);
    const pauseSpy = vi.spyOn(window.HTMLMediaElement.prototype, 'pause').mockImplementation(() => {});
    const playSpy = vi.spyOn(window.HTMLMediaElement.prototype, 'play').mockResolvedValue(undefined as never);
    try {
      const layer = createBackgroundLayer(root);
      layer.showVideo('/a.mp4');
      expect(pauseSpy).not.toHaveBeenCalled();
      layer.setPaused(true);
      expect(pauseSpy).toHaveBeenCalledTimes(1);
      layer.setPaused(false);
      expect(playSpy).toHaveBeenCalledTimes(1);
      // 暂停态下切壁纸：新视频也不播（否则「暂停」会被换壁纸悄悄解除）
      layer.setPaused(true); // 第 2 次：暂停当前视频
      layer.showVideo('/b.mp4'); // 第 3 次：新视频仍处暂停态
      expect(pauseSpy).toHaveBeenCalledTimes(3);
      expect(root.querySelectorAll('.wp-bg-fill video')).toHaveLength(1);
    } finally {
      pauseSpy.mockRestore();
      playSpy.mockRestore();
    }
  });

  // web 壁纸自适应（2026-09-22 用户报告「调整浏览器大小时不跟着自适应」）：本库部分 web 壁纸
  // 的脚本在初始化时把画布尺寸**快照**成 window.innerWidth/Height（`3789244610` 即如此，
  // 全 bundle 无 resize 监听）。headless 实测：宿主 iframe 与子帧视口都正确跟随，瓶颈在壁纸内部；
  // 跨源 iframe 无法注入脚本 ⇒ 只能按新视口**重建 iframe** 让壁纸重新初始化（重建实测有效）。
  describe('web 壁纸 resize 自适应', () => {
    const setViewport = (w: number, h: number) => {
      Object.defineProperty(window, 'innerWidth', { value: w, configurable: true });
      Object.defineProperty(window, 'innerHeight', { value: h, configurable: true });
    };
    const resetViewport = () => {
      Reflect.deleteProperty(window, 'innerWidth');
      Reflect.deleteProperty(window, 'innerHeight');
    };
    const framesOf = (root: HTMLElement) => [...root.querySelectorAll('.wp-bg-fill iframe')] as HTMLIFrameElement[];
    const flush = async () => { for (let i = 0; i < 8; i += 1) await Promise.resolve(); };
    async function setupWeb(root: HTMLElement, fetchSpy: ReturnType<typeof vi.spyOn>) {
      const layer = createBackgroundLayer(root);
      layer.showWeb('/wallpapers/web/9/index.html');
      await flush(); // 探活是 promise 链，落地不需真实时间
      expect(framesOf(root)).toHaveLength(1);
      return { layer, frame: framesOf(root)[0] };
    }

    it('resize 后用新视口重建；新帧就绪前旧帧仍在画面里', async () => {
      vi.useFakeTimers();
      document.body.innerHTML = '';
      const root = document.createElement('div');
      document.body.appendChild(root);
      setViewport(1280, 720);
      const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue({} as Response);
      try {
        const { frame: old } = await setupWeb(root, fetchSpy);
        setViewport(900, 520);
        window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_DELAY_MS);

        const pending = framesOf(root);
        expect(pending).toHaveLength(2); // 预载帧已挂、旧帧未撤（避免白屏）
        expect(pending[0]).toBe(old);
        expect(pending[1].style.visibility).toBe('hidden');
        expect(pending[1].getAttribute('src')).toBe(old.getAttribute('src')); // 复用探活结果
        expect(pending[1].getAttribute('scrolling')).toBe('no');

        pending[1].dispatchEvent(new Event('load'));
        expect(framesOf(root)).toHaveLength(1);
        expect(framesOf(root)[0]).toBe(pending[1]);
        expect(framesOf(root)[0].style.visibility).toBe('');
      } finally {
        fetchSpy.mockRestore(); resetViewport(); vi.useRealTimers();
      }
    });

    it('桌面壳：resize 重建复用 transport origin（不探活）', async () => {
      vi.useFakeTimers();
      document.body.innerHTML = '';
      const root = document.createElement('div');
      document.body.appendChild(root);
      setViewport(1280, 720);
      const g = globalThis as { __DSH_TRANSPORT__?: unknown };
      g.__DSH_TRANSPORT__ = { streamBaseUrl: 'http://127.0.0.1:19387' };
      const fetchSpy = vi.spyOn(globalThis, 'fetch').mockRejectedValue(new TypeError('no network in test'));
      try {
        const { frame: old } = await setupWeb(root, fetchSpy);
        expect(old.getAttribute('src')).toBe('http://127.0.0.1:19387/wallpapers/web/9/index.html');
        setViewport(900, 520);
        window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_DELAY_MS);
        const pending = framesOf(root);
        expect(pending).toHaveLength(2); // 旧帧 + 预载帧
        expect(pending[1].getAttribute('src')).toBe('http://127.0.0.1:19387/wallpapers/web/9/index.html');
        expect(pending[1].getAttribute('sandbox')).toBe('allow-scripts allow-same-origin');
        expect(fetchSpy).not.toHaveBeenCalled();
      } finally {
        delete g.__DSH_TRANSPORT__;
        fetchSpy.mockRestore(); resetViewport(); vi.useRealTimers();
      }
    });

    it('尺寸未变（只有 resize 事件）不重建', async () => {
      vi.useFakeTimers();
      document.body.innerHTML = '';
      const root = document.createElement('div');
      document.body.appendChild(root);
      setViewport(1280, 720);
      const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue({} as Response);
      try {
        await setupWeb(root, fetchSpy);
        window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_DELAY_MS * 3);
        expect(framesOf(root)).toHaveLength(1);
      } finally {
        fetchSpy.mockRestore(); resetViewport(); vi.useRealTimers();
      }
    });

    it('非 web 背景（图片/视频）不因 resize 重建', async () => {
      vi.useFakeTimers();
      document.body.innerHTML = '';
      const root = document.createElement('div');
      document.body.appendChild(root);
      setViewport(1280, 720);
      try {
        const layer = createBackgroundLayer(root);
        layer.showImage('/p.gif', false);
        setViewport(640, 360);
        window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_DELAY_MS * 3);
        expect(framesOf(root)).toHaveLength(0);
        expect(root.querySelector('.wp-bg-fill img')).not.toBeNull();
      } finally {
        resetViewport(); vi.useRealTimers();
      }
    });

    it('连续 resize 只重建一次（debounce 合并）', async () => {
      vi.useFakeTimers();
      document.body.innerHTML = '';
      const root = document.createElement('div');
      document.body.appendChild(root);
      setViewport(1280, 720);
      const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue({} as Response);
      try {
        await setupWeb(root, fetchSpy);
        setViewport(1000, 600); window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(100);
        setViewport(1100, 700); window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(100);
        setViewport(1200, 800); window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_DELAY_MS);
        expect(framesOf(root)).toHaveLength(2); // 旧帧 + 唯一一个预载帧
      } finally {
        fetchSpy.mockRestore(); resetViewport(); vi.useRealTimers();
      }
    });

    it('预载期间切换壁纸：迟到的预载帧不落地', async () => {
      vi.useFakeTimers();
      document.body.innerHTML = '';
      const root = document.createElement('div');
      document.body.appendChild(root);
      setViewport(1280, 720);
      const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue({} as Response);
      try {
        const { layer } = await setupWeb(root, fetchSpy);
        setViewport(900, 520);
        window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_DELAY_MS);
        const pending = framesOf(root)[1];
        layer.showImage('/p.gif', false);
        pending.dispatchEvent(new Event('load'));
        expect(framesOf(root)).toHaveLength(0);
        expect(root.querySelector('.wp-bg-fill img')).not.toBeNull();
      } finally {
        fetchSpy.mockRestore(); resetViewport(); vi.useRealTimers();
      }
    });

    it('预载超时：撤掉预载帧、保留旧帧（宁可尺寸不对也不留白）', async () => {
      vi.useFakeTimers();
      document.body.innerHTML = '';
      const root = document.createElement('div');
      document.body.appendChild(root);
      setViewport(1280, 720);
      const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue({} as Response);
      try {
        const { frame: old } = await setupWeb(root, fetchSpy);
        setViewport(900, 520);
        window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_DELAY_MS);
        expect(framesOf(root)).toHaveLength(2);
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_TIMEOUT_MS);
        expect(framesOf(root)).toHaveLength(1);
        expect(framesOf(root)[0]).toBe(old);
      } finally {
        fetchSpy.mockRestore(); resetViewport(); vi.useRealTimers();
      }
    });

    it('showNone 后再 resize 不重建', async () => {
      vi.useFakeTimers();
      document.body.innerHTML = '';
      const root = document.createElement('div');
      document.body.appendChild(root);
      setViewport(1280, 720);
      const fetchSpy = vi.spyOn(globalThis, 'fetch').mockResolvedValue({} as Response);
      try {
        const { layer } = await setupWeb(root, fetchSpy);
        layer.showNone();
        setViewport(900, 520);
        window.dispatchEvent(new Event('resize'));
        await vi.advanceTimersByTimeAsync(WEB_RESIZE_RELOAD_DELAY_MS * 3);
        expect(framesOf(root)).toHaveLength(0);
      } finally {
        fetchSpy.mockRestore(); resetViewport(); vi.useRealTimers();
      }
    });
  });

  // 文字可读性（2026-10-01，用户报告「某些壁纸文字看不清」）：设置面板可手动指定文字色，
  // 并可开文字描边（对立色阴影）——描边与背景无关，是亮暗差异大的壁纸上的兜底层。
  // 两者都写在 documentElement 的 CSS 变量上（styles.ts 的消费者就近读取，无需重写样式）。
  describe('setChatFg / setChatOutline（文字颜色与描边变量）', () => {
    const root = () => { document.body.innerHTML = ''; const el = document.createElement('div'); document.body.appendChild(el); return el; };
    const cleanup = () => {
      document.documentElement.style.removeProperty('--wp-chat-fg');
      document.documentElement.style.removeProperty('--wp-chat-outline');
    };

    it('setChatFg 写 --wp-chat-fg；空值移除变量（回主题默认）', () => {
      cleanup();
      const layer = createBackgroundLayer(root());
      layer.setChatFg('#ffffff');
      expect(document.documentElement.style.getPropertyValue('--wp-chat-fg')).toBe('#ffffff');
      layer.setChatFg('');
      expect(document.documentElement.style.getPropertyValue('--wp-chat-fg')).toBe('');
      cleanup();
    });

    it('setChatOutline 按文字色亮度写对立色阴影（亮字深边 / 暗字亮边）', () => {
      cleanup();
      const layer = createBackgroundLayer(root());
      layer.setChatOutline('#ffffff', 2);
      expect(document.documentElement.style.getPropertyValue('--wp-chat-outline')).toContain('rgba(0,0,0,');
      layer.setChatOutline('#000000', 2);
      expect(document.documentElement.style.getPropertyValue('--wp-chat-outline')).toContain('rgba(255,255,255,');
      cleanup();
    });

    it('0 档移除描边变量（默认无描边，既有观感不变）', () => {
      cleanup();
      const layer = createBackgroundLayer(root());
      layer.setChatOutline('#ffffff', 1);
      expect(document.documentElement.style.getPropertyValue('--wp-chat-outline')).not.toBe('');
      layer.setChatOutline('#ffffff', 0);
      expect(document.documentElement.style.getPropertyValue('--wp-chat-outline')).toBe('');
      cleanup();
    });

    it('无文字色 / 非法颜色时不留下任何描边值（不把任意串写进样式）', () => {
      cleanup();
      const layer = createBackgroundLayer(root());
      layer.setChatOutline('', 3);
      expect(document.documentElement.style.getPropertyValue('--wp-chat-outline')).toBe('');
      layer.setChatOutline('red;background:url(x)', 3);
      const v = document.documentElement.style.getPropertyValue('--wp-chat-outline');
      expect(v).toContain('rgba(255,255,255,');
      expect(v).not.toContain('url(');
      cleanup();
    });
  });

  // v0.8 显示效果：适配模式与 KenBurns 支持运行期切换（不重建媒体元素）。
  it('setFitMode 对当前图片/视频生效，stretch → object-fit:fill', () => {
    const layer = createBackgroundLayer(document.createElement('div'));
    layer.showImage('/a.jpg', false);
    layer.setFitMode('contain');
    expect((layer.root.querySelector('img') as HTMLImageElement).style.objectFit).toBe('contain');
    layer.setFitMode('stretch');
    expect((layer.root.querySelector('img') as HTMLImageElement).style.objectFit).toBe('fill');
  });

  it('setKenBurns 对当前图片即时增删 class', () => {
    const layer = createBackgroundLayer(document.createElement('div'));
    layer.showImage('/a.jpg', true);
    layer.setKenBurns(true);
    expect(layer.root.querySelector('img')?.classList.contains('wp-kenburns')).toBe(true);
    layer.setKenBurns(false);
    expect(layer.root.querySelector('img')?.classList.contains('wp-kenburns')).toBe(false);
  });

  // 回归（v0.8 review）：kenBurns=false 必须作为用户状态留在 layer，否则启动/回退路径的 showImage 会覆盖它。
  it('先 setKenBurns(false) 再 showImage 普通 jpg，仍不加 wp-kenburns', () => {
    const layer = createBackgroundLayer(document.createElement('div'));
    layer.setKenBurns(false); // 启动时 applySettingsToLayer 先于 select，此刻还没有图片
    layer.showImage('/a.jpg', true);
    expect(layer.root.querySelector('img')?.classList.contains('wp-kenburns')).toBe(false);
  });

  // GIF 预览以 showImage(..., false) 显示：面板开关不得把它重新打开（既有 per-wallpaper 语义）。
  it('setKenBurns(true) 不复活 GIF 预览的 Ken Burns', () => {
    const layer = createBackgroundLayer(document.createElement('div'));
    layer.showImage('/p.gif', false);
    layer.setKenBurns(true);
    expect(layer.root.querySelector('img')?.classList.contains('wp-kenburns')).toBe(false);
  });

  it('setKenBurns 对普通 jpg 仍可启停', () => {
    const layer = createBackgroundLayer(document.createElement('div'));
    layer.showImage('/a.jpg', true);
    layer.setKenBurns(false);
    expect(layer.root.querySelector('img')?.classList.contains('wp-kenburns')).toBe(false);
    layer.setKenBurns(true);
    expect(layer.root.querySelector('img')?.classList.contains('wp-kenburns')).toBe(true);
  });

  it('换壁纸后不继承上一张的 Ken Burns 许可', () => {
    const layer = createBackgroundLayer(document.createElement('div'));
    layer.showImage('/a.jpg', true);
    layer.showImage('/p.gif', false);
    layer.setKenBurns(true);
    expect(layer.root.querySelector('img')?.classList.contains('wp-kenburns')).toBe(false);
  });

  // v0.8 视频编码兜底：showVideo 三态（error = 编码不支持 / loadeddata = 可播 / 1.5s 超时）。
  it('视频 loadeddata → ok；error → unsupported', async () => {
    const layer = createBackgroundLayer(document.createElement('div'));
    const p1 = layer.showVideo('/ok.mp4');
    layer.root.querySelector('video')!.dispatchEvent(new Event('loadeddata'));
    await expect(p1).resolves.toBe('ok');

    const p2 = layer.showVideo('/bad.mp4');
    layer.root.querySelector('video')!.dispatchEvent(new Event('error'));
    await expect(p2).resolves.toBe('unsupported');
  });

  it('视频 1.5s 内无 loadeddata → timeout', async () => {
    vi.useFakeTimers();
    const layer = createBackgroundLayer(document.createElement('div'));
    const p = layer.showVideo('/slow.mp4');
    await vi.advanceTimersByTimeAsync(1600);
    await expect(p).resolves.toBe('timeout');
    vi.useRealTimers();
  });

  it('视频事件落地后清除超时定时器（不留悬挂 timer）', async () => {
    vi.useFakeTimers();
    const layer = createBackgroundLayer(document.createElement('div'));
    const p = layer.showVideo('/ok.mp4');
    layer.root.querySelector('video')!.dispatchEvent(new Event('loadeddata'));
    await expect(p).resolves.toBe('ok');
    expect(vi.getTimerCount()).toBe(0);
    vi.useRealTimers();
  });
});

